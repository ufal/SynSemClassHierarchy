<G-vec00566-002-s207><cart.karren><en> You can simply remove the item from your cart.
<G-vec00566-002-s207><cart.karren><de> Sie können den Artikel von Ihrem Karren einfach entfernen.
<G-vec00566-002-s208><cart.karren><en> Well, the cart is ready now - and we can start to install the goods next.
<G-vec00566-002-s208><cart.karren><de> So, der Karren ist damit fertig - jetzt kann es demnächst an's Einräumen gehen.
<G-vec00566-002-s209><cart.karren><en> What is most important of all to realise for those who promote a sharing economy in its presently limited forms, is that we are putting the cart before the horse if we believe that a community vision of sharing is a lasting solution to humanity’s problems, before millions of people have arisen in peaceful protest for governments to share the world’s resources along the lines indicated above.
<G-vec00566-002-s209><cart.karren><de> Worüber sich alle, die eine Sharing Economy in ihren derzeit begrenzten Formen fördern, klar werden müssen, ist, dass wir den Karren vor das Pferd spannen, wenn wir glauben, dass eine Gemeinschaftsvision des Teilens eine dauerhafte Lösung für die Probleme der Menschheit ist, bevor Millionen von Menschen sich in friedlichem Protest versammelt haben und von Ihren Regierungen verlangen, die Ressourcen der Welt entlang der oben genannten Linien zu teilen.
<G-vec00566-002-s210><cart.karren><en> They could take only with them what they themselves could carry, or would fit onto a cart.
<G-vec00566-002-s210><cart.karren><de> Sie durften nur das mitnehmen, was sie tragen konnten oder was auf einen Karren passte.
<G-vec00566-002-s211><cart.karren><en> A cart of pumpkins seemingly started to move on its own.
<G-vec00566-002-s211><cart.karren><de> Ein Karren voller Kürbisse setzte sich scheinbar von allein in Bewegung.
<G-vec00566-002-s212><cart.karren><en> A dozen cave dwellers helped carry the raft, others helped pull the cart.
<G-vec00566-002-s212><cart.karren><de> Ein Dutzend Höhlenbewohner schleppte das Floß, andere zogen den Karren.
<G-vec00566-002-s213><cart.karren><en> The next time she was born a calf and was again castrated, and as a bullock pulled a plow and a cart.
<G-vec00566-002-s213><cart.karren><de> Als nächstes wurde sie als Kalb geboren und wieder kastriert, und als Ochse zog sie Pflug und Karren.
<G-vec00566-002-s214><cart.karren><en> Then click on the vegetable on your cart that you want to use as seed, and then click on the field on which this vegetable should be planted.
<G-vec00566-002-s214><cart.karren><de> Anschließend klickt man die Ware auf dem Karren an, die man anpflanzen will, und klickt dann auf das Feld auf dem diese Ware angepflanzt werden soll.
<G-vec00566-002-s215><cart.karren><en> Thus, the cart remains in the same spot.
<G-vec00566-002-s215><cart.karren><de> Deshalb blieb der Karren an seiner Stelle stehen.
<G-vec00566-002-s216><cart.karren><en> Summoned by the Foreman, the industrious workers returned to the cart.
<G-vec00566-002-s216><cart.karren><de> Die betriebsamen Arbeiter wurden vom Vorabeiter zu dem Karren zurückgerufen.
<G-vec00566-002-s217><cart.karren><en> One day he was pushing his cart through the forest when off to the side he saw a large bare mountain. He had never seen it before, so he stopped and looked at it with amazement.
<G-vec00566-002-s217><cart.karren><de> Einmal fuhr er mit seinem Karren durch den Wald, da erblickte er zur Seite einen großen kahlen Berg, und weil er den noch nie gesehen hatte, hielt er still und betrachtete ihn mit Verwunderung.
<G-vec00566-002-s218><cart.karren><en> A horse and cart were available to take people to and from the fishing village.
<G-vec00566-002-s218><cart.karren><de> Es wurde ein Transportdienst mit Pferd und Karren eingeführt, um die Leute zur Herberge zu bringen.
<G-vec00566-002-s219><cart.karren><en> I have looked back many times to see who was pushing my cart, but my eyes saw no one.
<G-vec00566-002-s219><cart.karren><de> Ich habe mich oft umgeschaut, um zu sehen, wer meinen Karren schob, aber ich habe niemanden gesehen.
<G-vec00566-002-s220><cart.karren><en> In fairness to her, her cart is still broken, so the news of One Tamriel took a very long time to reach her ears.
<G-vec00566-002-s220><cart.karren><de> Der Fairness halber muss man sagen, dass ihr Karren kaputt ist, weshalb die Neuigkeiten bezüglich „One Tamriel“ sie erst sehr spät erreichten.
<G-vec00566-002-s221><cart.karren><en> Some of us are so busy that we feel like a cart pulled by a dozen work animals—each straining in a different direction.
<G-vec00566-002-s221><cart.karren><de> Manche von uns sind so sehr eingespannt, dass sie sich wie in einem Karren vorkommen, der von einem Dutzend Arbeitstieren gezogen wird – nur, dass jedes in eine andere Richtung davonstiebt.
<G-vec00566-002-s222><cart.karren><en> The circus master drives a big cart around the rink.
<G-vec00566-002-s222><cart.karren><de> Der Zirkusdirektor fährt mit einem großen Karren auf die Piste.
<G-vec00566-002-s223><cart.karren><en> The parties of the Communist International try to appeal especially to the more revolutionary workers by denouncing the League [of Nations] (a denunciation that is an apology), by asking for ‘workers’ sanctions,’ and then nevertheless saying: ‘We must use the League when it is for sanctions.’ They seek to hitch the revolutionary workers to the shafts so that they can draw the cart of the League.’’
<G-vec00566-002-s223><cart.karren><de> Die Parteien der Kommunistischen Internationale versuchen vor allem an die revolutionäreren Arbeiter zu appellieren, indem sie den Völkerbund dafür denunzieren (eine Denunziation, die eine Entschuldigung ist), dass er „Arbeiter“-Sanktionen fordert und dann doch sagen: „Wir müssen den Völkerbund benutzen, wenn er für Sanktionen ist.“ Sie versuchen, die revolutionären Arbeiter vor die Deichsel zu spannen, so dass sie den Karren des Völkerbunds ziehen können.
<G-vec00566-002-s224><cart.karren><en> He buys a cart a little bit later, then swap it for a van and a little later against a fleet of vans.
<G-vec00566-002-s224><cart.karren><de> Wenig später kauft er sich einen Karren, tauscht ihn dann gegen einen Lieferwagen aus und wenig später gegen eine ganze Flotte von Lieferwagen.
<G-vec00566-002-s225><cart.karren><en> The episode ends when Rarity and Pinkie Pie, who were left behind during the chase, use a hoof-powered railroad cart to travel home.
<G-vec00566-002-s225><cart.karren><de> Am Schluss der Episode sieht man Rarity und Pinkie Pie, die nach dem Sturz vom Karren zurückgelassen worden waren, gemeinsam auf einer handbetriebenen Draisine heimwärts fahren.
