<G-vec00684-002-s064><comb.durchkämmen><en> Both here and in the Czech Republic, young photographers comb the streets of their cities on the look-out for style-conscious people.
<G-vec00684-002-s064><comb.durchkämmen><de> Hier wie dort durchkämmen junge Fotografen auf der Suche nach stilvollen Mitmenschen die Straßen ihrer Stadt.
<G-vec00684-002-s065><comb.durchkämmen><en> Following this, hair needs to be combed through with the comb given to take out the lice.
<G-vec00684-002-s065><comb.durchkämmen><de> Verwenden Sie eventuell eine Pflegespülung, so lassen sich die Haare besser mit dem Läusekamm durchkämmen.
<G-vec00684-002-s066><comb.durchkämmen><en> They do not filter free-swimming plankton, but comb the sea-bottom for crustaceans, worms, mollusks und other similar animals.
<G-vec00684-002-s066><comb.durchkämmen><de> Sie filtern nicht Plankton im Freiwasser, sondern durchkämmen den Meeresboden nach Krebsen, Würmern, Schnecken und anderen Kleintieren.
<G-vec00684-002-s067><comb.durchkämmen><en> Our buyers systematically comb through the world market for new products and evaluate promising candidates.
<G-vec00684-002-s067><comb.durchkämmen><de> Unsere Einkäufer durchkämmen systematisch den Weltmarkt nach Neuheiten und evaluieren vielversprechende Kandidaten.
<G-vec00684-002-s068><comb.durchkämmen><en> With the Tangle Teezer, a hairbrush made of flexible plastic and soft synthetic bristles, you can comb through wet and dry hair without tearing or pulling.
<G-vec00684-002-s068><comb.durchkämmen><de> Mit dem Tangle Teezer, einer Haarbürste aus flexiblem Kunststoff und weichen Synthetikborsten, können Sie nasses und trockenes Haar ganz ohne Reißen und Ziepen durchkämmen.
<G-vec00684-002-s069><comb.durchkämmen><en> It leaves the hair fragrant, silky and easy to comb.
<G-vec00684-002-s069><comb.durchkämmen><de> Die Haare sind duftig, geschmeidig und lassen sich gut durchkämmen.
<G-vec00684-002-s070><comb.durchkämmen><en> The more frequently patrols comb an area, the more animals there are and the more biodiversity there is.
<G-vec00684-002-s070><comb.durchkämmen><de> Je öfter die Patrouillen ein Waldgebiet durchkämmen, umso mehr Tiere gibt es und umso größer ist die Artenvielfalt.
<G-vec00684-002-s071><comb.durchkämmen><en> With the Bye bye Tangle Brush, struggling to comb your hair will very much be a thing of the past.
<G-vec00684-002-s071><comb.durchkämmen><de> Bye bye Tangle Brush Probleme beim Durchkämmen deiner Haare gehören mit der Bye Bye Tangle Brush eindeutig der Vergangenheit an.
<G-vec00684-002-s072><comb.durchkämmen><en> After shampooing, apply a tennis ball-sized amount on towel-dried hair, comb through and style your hair as usual.
<G-vec00684-002-s072><comb.durchkämmen><de> Nach der Haarwäsche eine tennisballgroße Menge im handtuchtrockenen Haar verteilen, durchkämmen und wie gewohnt frisieren.
<G-vec00684-002-s073><comb.durchkämmen><en> Spray the coat from a distance of 30 cm and leave two minutes to take effect. Then comb the hair thoroughly.
<G-vec00684-002-s073><comb.durchkämmen><de> Aus einem Abstand von 30 cm auf das Fell sprühen, 2 minuten einwirken lassen und die Haare ordentlich durchkämmen.
<G-vec00684-002-s074><comb.durchkämmen><en> What’s more, finding the right insights and optimization potential can sometimes feel like something from a Where’s Waldo book. You have to comb through a lot of detail before you can find the right piece of information.
<G-vec00684-002-s074><comb.durchkämmen><de> Die richtigen Insights zu finden und das Potenzial zu optimieren fühlt sich manchmal an wie eine Nadel im Heuhaufen zu finden: man muss jedes kleinste Detail durchkämmen um die richtigeInformation zu finden.
<G-vec00684-002-s075><comb.durchkämmen><en> For an even application, use your fingers or a brush to comb through.
<G-vec00684-002-s075><comb.durchkämmen><de> Für eine gleichmäßige Anwendung mit den Fingern oder einem Pinsel durchkämmen.
<G-vec00684-002-s076><comb.durchkämmen><en> Spray generously and evenly onto towel dried hair and comb.
<G-vec00684-002-s076><comb.durchkämmen><de> Großzügig und gleichmäßig in das handtuchtrockene Haar sprühen und durchkämmen.
<G-vec00684-002-s077><comb.durchkämmen><en> Apply to damp/towel-dried hair and comb through for even distribution.
<G-vec00684-002-s077><comb.durchkämmen><de> Auf feuchtes/handtuchtrockenes Haar auftragen und für eine gleichmäßige Verteilung durchkämmen.
<G-vec00684-002-s078><comb.durchkämmen><en> Apply to clean damp hair, massage and comb through.
<G-vec00684-002-s078><comb.durchkämmen><de> Auf gereinigtes, feuchtes Haar auftragen, einmassieren und durchkämmen.
<G-vec00684-002-s079><comb.durchkämmen><en> They ask Anna in the patrol car and comb through the streets of Moabit.
<G-vec00684-002-s079><comb.durchkämmen><de> Sie bitten Anna in den Streifenwagen und durchkämmen die Straßen von Moabit.
<G-vec00684-002-s086><comb.kämmen><en> After 2 hours it is necessary to comb the hair again and then wash it.
<G-vec00684-002-s086><comb.kämmen><de> Nach 2 Stunden muss das Haar erneut gekämmt und anschließend gewaschen werden.
<G-vec00684-002-s087><comb.kämmen><en> Carefully comb every part of the hair with a fine tooth head lice comb.
<G-vec00684-002-s087><comb.kämmen><de> Anschließend muss das gesamte Haar sorgfältig mit einem Läusekamm gekämmt werden.
<G-vec00684-002-s088><comb.kämmen><en> The first mascot of the Kozel brewery was a calf-size goat and the keeper used to comb its hair for hours.
<G-vec00684-002-s088><comb.kämmen><de> Das erste Maskottchen der Brauerei war groß wie ein Kalb, sein Fell wurde von unserem „Bock-Pfleger“ stundenlang gekämmt.
<G-vec00684-002-s168><comb.kämmen><en> 1 Comb your hair while it's still wet.
<G-vec00684-002-s168><comb.kämmen><de> 1 Kämme deine Haare, wenn sie noch nass sind.
<G-vec00684-002-s169><comb.kämmen><en> If you’re cutting your hair wet, shampoo and condition it, remove excess water by wrapping your hair in a towel and squeezing it, then comb your damp hair straight.
<G-vec00684-002-s169><comb.kämmen><de> Shampooniere und spüle deine Haare, entferne überschüssiges Wasser (indem du die Haare in ein Handtuch einwickelst und drückst) und kämme die feuchten Haare dann glatt, falls du deine Haare nass schneidest.
<G-vec00684-002-s170><comb.kämmen><en> Always start from the ends of your hair first; never comb straight down from the roots.
<G-vec00684-002-s170><comb.kämmen><de> Beginne immer zuerst an den Enden deiner Haare und kämme niemals gerade von den Wurzeln nach unten.
<G-vec00684-002-s171><comb.kämmen><en> Comb your hair with a boar-bristle brush or finger comb
<G-vec00684-002-s171><comb.kämmen><de> Kämme dir die Haare mit einer Bürste aus Schweineborsten.
<G-vec00684-002-s172><comb.kämmen><en> Create a classy hairstyle - cut, dye, comb and style Linda’s hair.
<G-vec00684-002-s172><comb.kämmen><de> Mach ihr eine noble Frisur - schneide, färbe, kämme und style Lindas Haare.
<G-vec00684-002-s173><comb.kämmen><en> 1 Comb your hair and wrap a hair tie around your wrist.
<G-vec00684-002-s173><comb.kämmen><de> 1 Kämme deine Haare und bringe sie alle auf die linke oder auf die rechte Seite.
<G-vec00684-002-s174><comb.kämmen><en> Comb and brush your hair every day.
<G-vec00684-002-s174><comb.kämmen><de> Kämme und bürste dein Haar täglich.
<G-vec00684-002-s175><comb.kämmen><en> Comb out your hair with a wide-tooth comb.
<G-vec00684-002-s175><comb.kämmen><de> Kämme deine Haare mit einem breitzinkigen Kamm durch.
<G-vec00684-002-s176><comb.kämmen><en> Thoroughly comb throughout your being and throughout your outer life and strip away or transform all the expired elements.
<G-vec00684-002-s176><comb.kämmen><de> Kämme sorgfältig durch dein Sein und durch dein äußeres Leben und streife ab oder transformiere alle abgelaufenen Elemente.
<G-vec00684-002-s177><comb.kämmen><en> Always use the recommended Rapunzel® wide-toothed comb for curly and afro-textured hair.
<G-vec00684-002-s177><comb.kämmen><de> Benutzen Sie beim Bürsten immer die von Rapunzel empfohlenen breit gezinkten Kämme für lockiges/krauses Haar.
<G-vec00684-002-s178><comb.kämmen><en> Comb instead of brushing.
<G-vec00684-002-s178><comb.kämmen><de> Kämme statt zu bürsten.
<G-vec00684-002-s179><comb.kämmen><en> I bought a brow pomade from p2 (shade 020) which I fill my eyebrows with and then comb them through for a more natural effect.
<G-vec00684-002-s179><comb.kämmen><de> Dann warte ich bis der Concealer vollständig eingezogen ist (habe mir eine Brow Pomade von p2 (Farbe 020) gekauft mit der ich meine Augenbrauen ausfülle und kämme sie anschließend für einen natürlicheren Effekt durch.
<G-vec00684-002-s180><comb.kämmen><en> 1 Comb your hair, put on deodorant, and wear a nice outfit.
<G-vec00684-002-s180><comb.kämmen><de> 1 Kämme deine Haare, verwende Deodorant und trage ein schönes Outfit.
<G-vec00684-002-s181><comb.kämmen><en> Get your hair wet and comb it.
<G-vec00684-002-s181><comb.kämmen><de> Mach deine Haare nass und kämme sie durch.
<G-vec00684-002-s182><comb.kämmen><en> Comb her hair and create a whole new look for her.
<G-vec00684-002-s182><comb.kämmen><de> Kämme ihr Haar und zaubere einen neuen Look für sie.
<G-vec00684-002-s183><comb.kämmen><en> Comb your hair, trim your beard regularly, and keep your fingernails short and clean.
<G-vec00684-002-s183><comb.kämmen><de> Kämme dich, stutze regelmäßig deinen Bart und halte Fingernägel kurz und sauber.
<G-vec00684-002-s184><comb.kämmen><en> Comb over the top, revealing a part on one side of your head.
<G-vec00684-002-s184><comb.kämmen><de> Kämme die Oberseite über, wodurch du auf einer Seite deines Kopfes einen Teil freilegst.
<G-vec00684-002-s185><comb.kämmen><en> Be sure to comb the serum through all of your hair, saturating all of the strands as you go.
<G-vec00684-002-s185><comb.kämmen><de> Kämme das Serum auf jeden Fall durch deine ganzen Haare und durchtränke dabei alle Strähnen.
<G-vec00684-002-s186><comb.kämmen><en> Let the curls cool and then comb through with the ghd detangling comb to break up the look.
<G-vec00684-002-s186><comb.kämmen><de> Kämme die Locken mit dem ghd detangling comb durch, um die Locken für eine natürliche Textur aufzulockern.
<G-vec00684-002-s187><comb.kämmen><en> Just spray on your roots and comb through your hair to remove odors and soak up excess oils.
<G-vec00684-002-s187><comb.kämmen><de> Sprayen Sie es einfach auf die Wurzeln und kämmen es durch das Haar um Gerüche zu entfernen und überschüssige Öle aufzusaugen.
<G-vec00684-002-s188><comb.kämmen><en> You need to comb your hair exclusively in a dry state.
<G-vec00684-002-s188><comb.kämmen><de> Sie müssen Ihr Haar ausschließlich trocken kämmen.
<G-vec00684-002-s189><comb.kämmen><en> Depending on the product and hairstyle, you may want to apply the styling product before you comb your hair.
<G-vec00684-002-s189><comb.kämmen><de> Du solltest das Stylingprodukt – abhängig von Produkt und Frisur - vielleicht vor dem Kämmen anwenden.
<G-vec00684-002-s190><comb.kämmen><en> It is enough to comb the dog 2-3 times a week.
<G-vec00684-002-s190><comb.kämmen><de> Es ist genug, um den Hund 2-3 mal pro Woche zu kämmen.
<G-vec00684-002-s191><comb.kämmen><en> While still wet with mascara, comb your lashes (moving up, out and away from eyes).
<G-vec00684-002-s191><comb.kämmen><de> Anwendung Kämmen Sie die noch feuchten Wimpern (nach oben, außen und von den Augen weg).
<G-vec00684-002-s192><comb.kämmen><en> After applying the balm mask the hair shines and looks silky, is better to comb, and is always obedient.
<G-vec00684-002-s192><comb.kämmen><de> Nach der Anwendung der Balsam-Maske glänzt das Haar und sieht seidig aus, ist besser zu kämmen, und ist immer gehorsam.
<G-vec00684-002-s193><comb.kämmen><en> The spray is ultra dry and without difficulty from him at any time simply hair comb.
<G-vec00684-002-s193><comb.kämmen><de> Das Spray ist extrem trocken und ohne Schwierigkeiten von ihm jederzeit einfach Haare kämmen.
<G-vec00684-002-s194><comb.kämmen><en> Starting from the roots, you need to comb them - the stronger the bouffant, the thinner and easier the strands will be painted.
<G-vec00684-002-s194><comb.kämmen><de> Ausgehend von den Wurzeln müssen Sie sie kämmen - je stärker der Bouffant, desto dünner und leichter werden die Strähnen bemalt.
<G-vec00684-002-s195><comb.kämmen><en> Tip: Use the ghd tail comb to gently back comb and elevate your hair.
<G-vec00684-002-s195><comb.kämmen><de> Tipp: Verwende den ghd carbon tail comb, um Deine Haare sanft nach oben zu kämmen und anzuheben.
<G-vec00684-002-s196><comb.kämmen><en> Before leaving home in the mornings, we must wash our face and comb our hair.
<G-vec00684-002-s196><comb.kämmen><de> Bevor wir morgens das Haus verlassen, waschen wir uns das Gesicht und kämmen uns die Haare.
<G-vec00684-002-s197><comb.kämmen><en> c. Comb with a wire brush after dry.
<G-vec00684-002-s197><comb.kämmen><de> c. Nach dem Trocknen mit einer Drahtbürste kämmen.
<G-vec00684-002-s198><comb.kämmen><en> 2018 All the mothers, while still waiting for their daughter, are already beginning to mentally dress and comb their little princess.
<G-vec00684-002-s198><comb.kämmen><de> 2018 Alle Mütter, während sie noch auf ihre Tochter warten, fangen an, ihre kleine Prinzessin geistig anzuziehen und zu kämmen.
<G-vec00684-002-s199><comb.kämmen><en> The beard shines, smells and is easy to comb.
<G-vec00684-002-s199><comb.kämmen><de> Der Bart glänzt, duftet und lässt sich leicht kämmen.
<G-vec00684-002-s200><comb.kämmen><en> The hair is easy to comb and receives softness and shine.
<G-vec00684-002-s200><comb.kämmen><de> Das Haar lässt sich leicht kämmen und erhält Geschmeidigkeit und Glanz.
<G-vec00684-002-s201><comb.kämmen><en> This amazing serum makes hair smooth and easy to comb.
<G-vec00684-002-s201><comb.kämmen><de> Diese erstaunliche Serum macht das Haar glatt und leicht zu kämmen.
<G-vec00684-002-s202><comb.kämmen><en> Then brush or comb your hair before blow-drying your hair until it is almost dry.
<G-vec00684-002-s202><comb.kämmen><de> Bürsten oder kämmen Sie das Haar dann einmal durch und föhnen Sie es fast trocken.
<G-vec00684-002-s203><comb.kämmen><en> Styling: Apply styling mousse to your hair and comb it straight.
<G-vec00684-002-s203><comb.kämmen><de> So geht’s: Verteilen Sie etwas Schaumfestiger im Haar und kämmen Sie es glatt.
<G-vec00684-002-s204><comb.kämmen><en> All Galagos comb themselves or mutually with the tooth-comb formed from the low edge-teeth.
<G-vec00684-002-s204><comb.kämmen><de> Alle Galagos kämmen sich selbst oder gegenseitig mit dem aus den unteren Schneidezähnen gebildeten Zahnkamm.
<G-vec00684-002-s205><comb.kämmen><en> Comb hair then apply TIGI Copyright Split End Repair Cream through mid-lengths and ends.
<G-vec00684-002-s205><comb.kämmen><de> Kämmen Sie das Haar durch und tragen Sie dann den TIGI Copyright Hitzeschutz auf.
<G-vec00684-002-s206><comb.kämmen><en> Not just how to comb them or cut them.
<G-vec00684-002-s206><comb.kämmen><de> Nicht nur, wie man sie kämmt oder schneidet.
<G-vec00684-002-s207><comb.kämmen><en> Cut, color, comb and blow-dry lifelike hair on two different cute characters.
<G-vec00684-002-s207><comb.kämmen><de> Schneidet, färbt, kämmt und föhnt lebensechtes Haar an zwei verschiedenen, süßen Figuren.
