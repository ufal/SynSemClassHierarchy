<G-vec00859-002-s087><concentrate.fokussieren><en> “In light of our free cash flow generation, our efforts in 2018 will initially concentrate on measures which can be implemented quickly and will not cause major one-off costs,” explains Ute Wolf, CFO of Evonik.
<G-vec00859-002-s087><concentrate.fokussieren><de> „Auch mit Blick auf unsere Free Cashflow-Generierung fokussieren wir uns im Jahr 2018 zunächst auf Maßnahmen, die wir schnell umsetzen können und die keine hohen Einmalkosten verursachen“, erläutert Ute Wolf, Finanzchefin von Evonik.
<G-vec00859-002-s088><concentrate.fokussieren><en> We are active in private banking and concentrate fully on our core business of investment advisory and asset management.
<G-vec00859-002-s088><concentrate.fokussieren><de> Wir sind im Private Banking tätig und fokussieren uns auf unsere Kernkompetenzen in der Anlageberatung und Vermögensverwaltung.
<G-vec00859-002-s089><concentrate.fokussieren><en> As well as the fundamental principles and tools of business management, we concentrate specifically on subjects relevant to industry: processes and process management, logistics and supply chain management, financial controlling and management accounting, as well as customer orientation and marketing.
<G-vec00859-002-s089><concentrate.fokussieren><de> Neben allen grundlegenden Konzepten und Instrumenten der Betriebswirtschaft fokussieren wir uns speziell auf die industrierelevanten Themen: Prozesse und deren Optimierung (Prozessmanagement), Logistik und Supply Chain Management, Controlling und Führen mit Zahlen sowie Kundenorientierung und Marketing.
<G-vec00859-002-s090><concentrate.fokussieren><en> We concentrate on what really matters: results.
<G-vec00859-002-s090><concentrate.fokussieren><de> Wir fokussieren uns auf das, was zählt: Ergebnisse.
<G-vec00859-002-s091><concentrate.fokussieren><en> As a leading investment advisor, we concentrate exclusively on investments in wind and solar parks.
<G-vec00859-002-s091><concentrate.fokussieren><de> Als führender auf Nachhaltigkeit spezialisierter Berater fokussieren wir uns ausschließlich auf Investitionen in Wind- und Solarparks.
<G-vec00859-002-s092><concentrate.fokussieren><en> That’s why we concentrate on what our clients really need to be successful.
<G-vec00859-002-s092><concentrate.fokussieren><de> Deshalb fokussieren wir uns auf das, was unsere Kunden wirklich brauchen, um erfolgreich zu sein.
<G-vec00859-002-s053><concentrate.konzentrieren><en> The target groups of our company are for the time being great investors as well as financially highly settled customers, because in the beginning we will concentrate in offering high-quality product range.
<G-vec00859-002-s053><concentrate.konzentrieren><de> Die Zielgruppe unserer Gesellschaft richtet sich vorerst sowohl auf Großinvestoren, als auch auf finanziell hoch angesiedelte Klienten, da wir uns anfangs darauf konzentrieren werden, eine qualitativ hochwertige Produktpallette anzubieten.
<G-vec00859-002-s054><concentrate.konzentrieren><en> This way the customer and the dealer can concentrate on choosing a “base car”, while we do the conversion work.
<G-vec00859-002-s054><concentrate.konzentrieren><de> So können sich Kunde und Händler darauf konzentrieren, ein „Basisauto“ auszuwählen – wir übernehmen dann den Umbau.
<G-vec00859-002-s055><concentrate.konzentrieren><en> We must concentrate our full forces upon it.
<G-vec00859-002-s055><concentrate.konzentrieren><de> Wir müssen unsere ganzen Kräfte darauf konzentrieren.
<G-vec00859-002-s056><concentrate.konzentrieren><en> Do not trust these instructions and concentrate on how to delete KEYHolder.
<G-vec00859-002-s056><concentrate.konzentrieren><de> Vertrauen Sie diese Anweisungen nicht und darauf konzentrieren Sie, wie Sie KEYHolder löschen.
<G-vec00859-002-s057><concentrate.konzentrieren><en> I also have to concentrate on not going nuts at race weekends.
<G-vec00859-002-s057><concentrate.konzentrieren><de> Zudem muss ich mich an den Rennwochenenden darauf konzentrieren, nicht zu verkrampfen.
<G-vec00859-002-s058><concentrate.konzentrieren><en> Our infrastructure is organised in the way that allows you to concentrate yourself fully on your core competences.
<G-vec00859-002-s058><concentrate.konzentrieren><de> Unsere Infrastruktur ist darauf ausgerichtet, dass Sie sich voll auf Ihre Kernkompetenzen konzentrieren können.
<G-vec00859-002-s059><concentrate.konzentrieren><en> This means that you can relax and concentrate on having fun every time you log in and play, safe in the knowledge that you are experiencing the safest Poker
<G-vec00859-002-s059><concentrate.konzentrieren><de> Das bedeutet, dass Sie sich entspannen und darauf konzentrieren können, Spaß zu haben, wenn Sie sich anmelden und spielen, in dem sicheren Wissen, dass Sie die sichersten Online Spielautomaten in der Umgebung erleben können.
<G-vec00859-002-s060><concentrate.konzentrieren><en> More consciousness and alertness than normal I felt as though I was in a state of meditation, only I did not initiate the meditation nor did I have to concentrate to keep it.
<G-vec00859-002-s060><concentrate.konzentrieren><de> Mehr Bewusstheit und Wachheit als normal Ich fühlte mich wie in einem Zustand von Meditation, nur dass ich diese Meditation weder begann noch mich darauf konzentrieren musste sie zu halten.
<G-vec00859-002-s061><concentrate.konzentrieren><en> Joining forces with the finest suppliers in Ibiza allows me to fully concentrate on organizing and styling an unforgettable wedding day that fully reflects your personalities and desires.
<G-vec00859-002-s061><concentrate.konzentrieren><de> Die Zusammenarbeit mit den besten Anbietern auf Ibiza, Formentera und Mallorca ermöglicht es mir, mich darauf zu konzentrieren, was ich am besten kann – eine unvergessliche Feier, eure Traumhochzeit mit und für euch umzusetzen.
<G-vec00859-002-s062><concentrate.konzentrieren><en> This way, we can concentrate our efforts on improving the most visited areas, and help users find what they’re looking for more easily.
<G-vec00859-002-s062><concentrate.konzentrieren><de> So können wir uns darauf konzentrieren, die am meisten besuchten Bereiche zu verbessern und damit der Nutzer besser findet, was er sucht.
<G-vec00859-002-s063><concentrate.konzentrieren><en> "We will now concentrate on making our data accessible in the form of the best possible maps, spectra and various catalogues to support the work of present and future astronomers.
<G-vec00859-002-s063><concentrate.konzentrieren><de> "Wir werden unsere Arbeit jetzt darauf konzentrieren, die Daten in Form möglichst perfekter Karten, Spektren und verschiedener Kataloge zugänglich zu machen, um so die Astronomen bei ihren laufenden und künftigen Arbeiten zu unterstützen.
<G-vec00859-002-s064><concentrate.konzentrieren><en> Though I’m trying really hard to keep up with what’s going on in Switzerland, I’m home here now and I have to concentrate on what’s happening in my new homeland.
<G-vec00859-002-s064><concentrate.konzentrieren><de> Auch wenn ich wirklich bemüht bin, mich über die Vorgänge in der Schweiz auf dem Laufenden zu halten, so bin ich nun doch hier zuhause und ich sollte mich darauf konzentrieren, was in meiner neuen Heimat vor sich geht.
<G-vec00859-002-s065><concentrate.konzentrieren><en> We* want to concentrate on uniting different fights and to especially give a voice those who haven’t found an advocacy group in networks that already exist.
<G-vec00859-002-s065><concentrate.konzentrieren><de> Dabei wollen wir* uns darauf konzentrieren, die verschiedenen Kämpfe zu vereinen und besonders denjenigen eine Stimme zu geben, die bisher keine Lobby in bestehenden Netzwerken gefunden haben.
<G-vec00859-002-s066><concentrate.konzentrieren><en> When curing yourself this way you have to concentrate your thoughts in order to heal yourself directly from nature.
<G-vec00859-002-s066><concentrate.konzentrieren><de> Wenn Sie sich auf diese Weise heilen, müssen Sie ihren Gedanken darauf konzentrieren, dass man direkt von der Natur geheilt wird.
<G-vec00859-002-s067><concentrate.konzentrieren><en> If we read this with our ego we immediately think “my experience is that getting what I want in the world brings me happiness, so I will continue to concentrate on meeting my physical and psychological needs”.
<G-vec00859-002-s067><concentrate.konzentrieren><de> Wenn wir dies mit unserem Ego lesen, denken wir sofort: "Meine Erfahrung ist, dass das, was ich in der Welt will, mich glücklich macht, also werde ich mich weiterhin darauf konzentrieren, meine physischen und psychologischen Bedürfnisse zu erfüllen".
<G-vec00859-002-s068><concentrate.konzentrieren><en> If you've found the cause of the problem, you only need to concentrate on the solution.
<G-vec00859-002-s068><concentrate.konzentrieren><de> Wenn du die Ursache für das Problem gefunden hast, musst du dich nur noch auf die Lösung konzentrieren.
<G-vec00859-002-s069><concentrate.konzentrieren><en> Whether on easy terrain, on forest tracks or in town, this versatile eBike allows you to fully concentrate on enjoying your biking experience with the support of the sporty Bosch Performance CX motor.
<G-vec00859-002-s069><concentrate.konzentrieren><de> Reservieren Details Ob in sanftem Gelände, auf Waldwegen oder in der Stadt, mit diesem vielseitigen Trekking eBike kannst Du Dich ganz auf den Fahrspaß konzentrieren.
<G-vec00859-002-s070><concentrate.konzentrieren><en> If you’ve ever tried to concentrate when your nose won’t stop running or your eyes are streaming, you will know how difficult it can be.
<G-vec00859-002-s070><concentrate.konzentrieren><de> Wenn Du jemals versucht hast, Dich zu konzentrieren, während Deine Nase nicht aufhört zu laufen oder Deine Augen tränen, wirst Du wissen, wie schwierig es sein kann.
<G-vec00859-002-s071><concentrate.konzentrieren><en> The two included cable guides keep the cable securely on the headband during jogging tours or rough MTB rides, so that you can fully concentrate on the track ahead.
<G-vec00859-002-s071><concentrate.konzentrieren><de> Die beiden mitgelieferten Kabelführungen halten die Stromverbindungen beim Joggen und bei ruppigen Fahrten mit dem MTB sicher am Kopfband, damit sie nicht störend mitschwingen und du dich voll auf die Strecke konzentrieren kannst.
<G-vec00859-002-s072><concentrate.konzentrieren><en> Add to cart Add a White ambiance downlight with warm white to cool daylight to help you relax, read, concentrate, or energize.
<G-vec00859-002-s072><concentrate.konzentrieren><de> Nutze einen White Ambiance Spot mit warmweißem bis tageslichtweißem Licht, damit Du besser entspannen, lesen, Dich konzentrieren oder mit frischer Energie aufladen kannst.
<G-vec00859-002-s073><concentrate.konzentrieren><en> Last but not least, our work models provide you with ample time to concentrate on your studies parallel to your work – and in between to broaden your horizon with travel and semesters abroad.
<G-vec00859-002-s073><concentrate.konzentrieren><de> Last but not least, geben Dir unsere flexiblen Modelle ausreichend Freiraum, um Dich parallel auf Dein Studium zu konzentrieren – und zwischendurch im Urlaub oder Auslandssemester Deinen Horizont zu erweitern.
<G-vec00859-002-s074><concentrate.konzentrieren><en> I have said that we are always with you and it is true, but to feel it you must draw back from your vital and be able to concentrate in your inner being.
<G-vec00859-002-s074><concentrate.konzentrieren><de> Ich habe gesagt, dass wir immer bei dir sind, und das ist wahr; um es aber zu fühlen, musst du dich von deinem Vital zurückziehen und in der Lage sein, dich in deinem inneren Wesen zu konzentrieren.
<G-vec00859-002-s075><concentrate.konzentrieren><en> The upper material provides good ventilation so that your foot does not overheat and you can concentrate fully on your run.
<G-vec00859-002-s075><concentrate.konzentrieren><de> Das Obermaterial sorgt für eine gute Belüftung damit dein Fuß nicht überhitzt und du dich voll auf deinen Lauf konzentrieren kannst.
<G-vec00859-002-s076><concentrate.konzentrieren><en> Comfort and maximal freedom of movement so you can fully concentrate on your workout and give your all.
<G-vec00859-002-s076><concentrate.konzentrieren><de> So kannst du dich ganz auf dein Workout konzentrieren und das Maximum aus dir rausholen.
<G-vec00859-002-s077><concentrate.konzentrieren><en> The ab straps support your elbows and take the pressure off your shoulders and arms, so you can concentrate fully on the abs workout.
<G-vec00859-002-s077><concentrate.konzentrieren><de> Die Bauchtrainingsschlaufen stützen dabei deine Ellenbogen und nehmen dir den Druck von den Schultern und Armen, sodass du dich vollends auf das Bauchtraining konzentrieren kannst.
<G-vec00859-002-s078><concentrate.konzentrieren><en> With the S.Light 30 Zip-on from ABS you can fully concentrate on your turns in deep snow.
<G-vec00859-002-s078><concentrate.konzentrieren><de> Mit dem S.Light 30 Zip-on von ABS kannst Du Dich voll auf deine Turns im Tiefschnee konzentrieren.
<G-vec00859-002-s079><concentrate.konzentrieren><en> It makes you feel sleepy and foggy, it can give you headaches and make it difficult to concentrate.
<G-vec00859-002-s079><concentrate.konzentrieren><de> Es macht dich schläfrig und benebelt, es kann Kopfschmerzen verursachen und es schwierig für dich machen, dich zu konzentrieren.
<G-vec00859-002-s080><concentrate.konzentrieren><en> Just a day or two to assess and concentrate.
<G-vec00859-002-s080><concentrate.konzentrieren><de> Nur einen Tag oder zwei, um eine Bestandsaufnahme zu machen und dich zu konzentrieren.
<G-vec00859-002-s081><concentrate.konzentrieren><en> Thanks to the hood, you can isolate yourself from the world and concentrate fully on skating; It also keeps you warm and reliably protects against wind.
<G-vec00859-002-s081><concentrate.konzentrieren><de> Dank der Kapuze bist du von der Welt abgeschottet und kannst dich ganz aufs Rollen konzentrieren; zudem hält sie warm und schützt zuverlässig vor Wind.
<G-vec00859-002-s082><concentrate.konzentrieren><en> You must concentrate hard, like me.
<G-vec00859-002-s082><concentrate.konzentrieren><de> Du mußt dich konzentrieren, wie ich.
<G-vec00859-002-s083><concentrate.konzentrieren><en> As a crowdfunding platform provider, you should be able to concentrate on your tasks in business development and target group marketing.
<G-vec00859-002-s083><concentrate.konzentrieren><de> Als Crowdfunding Plattform Anbieter sollst Du Dich auf Deine Aufgaben im Business Development und im Zielgruppenmarketing konzentrieren können.
<G-vec00859-002-s084><concentrate.konzentrieren><en> At this point, your project working directory is exactly the way it was before you started working on issue #53, and you can concentrate on your hotfix.
<G-vec00859-002-s084><concentrate.konzentrieren><de> Zu diesem Zeitpunkt befindet sich das Arbeitsverzeichnis des Projektes in exakt dem gleichen Zustand, in dem es sich befand, als Du mit der Arbeit an Issue #53 begonnen hast und Du kannst Dich direkt auf Deinen Hotfix konzentrieren.
<G-vec00859-002-s085><concentrate.konzentrieren><en> This can make it difficult to concentrate on studying.
<G-vec00859-002-s085><concentrate.konzentrieren><de> Das kann es dir erschweren, dich auf das Lernen zu konzentrieren.
<G-vec00859-002-s086><concentrate.konzentrieren><en> It doesn’t matter how often or how long you’re lost in thought, because it’s just important that you recognize it and then concentrate on your breath again.
<G-vec00859-002-s086><concentrate.konzentrieren><de> Es ist egal wie oft und wie lange du in deine Gedanken versunken bist, denn es ist wichtig, dass du es bemerkst und dich dann wieder auf deinen Atem zu konzentrieren.
<G-vec00859-002-s093><concentrate.konzentrieren><en> I could concentrate much more on the spoken word with two sticks and a string between my fingers - and so do I today.
<G-vec00859-002-s093><concentrate.konzentrieren><de> Ganz im Gegenteil - ich habe mich schon immer viel besser auf das gesprochene Wort konzentrieren können, wenn ich ein Paar Nadeln und ein Knäuel Wolle zwischen den Fingern hatte.
<G-vec00859-002-s094><concentrate.konzentrieren><en> So you can sit back and concentrate on your cooking skills.
<G-vec00859-002-s094><concentrate.konzentrieren><de> Damit Sie sich voll und ganz auf Ihre Kochkünste konzentrieren können.
<G-vec00859-002-s095><concentrate.konzentrieren><en> The caching issues are the same as for Phase 1, so in this Phase we can fully concentrate on the new main technical challenge of creating an augmentation syntax that can deal with the diversity and power of Wikidata.
<G-vec00859-002-s095><concentrate.konzentrieren><de> Die Caching-Probleme sind die gleichen wie für die Phase 1, so dass wir uns in dieser Phase voll und ganz auf die wichtigste neue technischen Herausforderung konzentrieren können: Die Anreicherungs-Syntax, die mit der Vielfalt und Mächtigkeit von Wikidata umgehen kann.
<G-vec00859-002-s096><concentrate.konzentrieren><en> From additional focal points for different scenes to a new focus algorithm, the AF lets the photographer concentrate on the composition.
<G-vec00859-002-s096><concentrate.konzentrieren><de> Von zusätzlichen Fokuspunkten für verschiedene Situationen bis hin zu einem neuen Fokus Algorithmus, durch den sich der Fotograf ganz auf die Komposition konzentrieren kann.
<G-vec00859-002-s097><concentrate.konzentrieren><en> The optimum in-office ANC and immersive stereo of the Voyager Focus UC provides the ultimate experience - concentrate on calls or listen to music in comfort.
<G-vec00859-002-s097><concentrate.konzentrieren><de> Dank der hochmodernen aktiven und passiven Rauschunterdrückung und dem Stereo-Sound können Sie sich mit dem Voyager Focus UC ganz auf Ihre Arbeit oder Ihre Musik konzentrieren.
<G-vec00859-002-s098><concentrate.konzentrieren><en> ... offers you the chance to take a step back and concentrate fully on God for 6 months.
<G-vec00859-002-s098><concentrate.konzentrieren><de> ... bietet dir die Möglichkeit, dich ein halbes Jahr voll und ganz auf Gott zu konzentrieren.
<G-vec00859-002-s099><concentrate.konzentrieren><en> With almost exclusively Russian-speaking Natives, we exclude possible language barriers, thus we can fully concentrate on the needs of your customers.
<G-vec00859-002-s099><concentrate.konzentrieren><de> Mit fast ausschließlich Russisch-sprechenden Natives, schließen wir mögliche Sprachbarrieren aus und können uns voll und ganz auf die Bedürfnisse Ihrer Kunden konzentrieren.
<G-vec00859-002-s100><concentrate.konzentrieren><en> But in 2012 I decided to concentrate my efforts on powder. I hired people and rented space.
<G-vec00859-002-s100><concentrate.konzentrieren><de> Aber 2012 beschloss ich, mich ganz auf das Pulver zu konzentrieren, Leute einzustellen und Räume zu mieten.
<G-vec00859-002-s101><concentrate.konzentrieren><en> With us, IT teams in companies will be able to fully concentrate on the transformation process in the future, instead of mastering the technological complexity on their own.
<G-vec00859-002-s101><concentrate.konzentrieren><de> Mit uns können sich IT-Teams in Unternehmen künftig voll und ganz auf den Transformationsprozess konzentrieren, anstatt selbst die Technologiekomplexität in Eigenregie zu meistern.
<G-vec00859-002-s102><concentrate.konzentrieren><en> Dad, please keep an eye on Mathilda and explain what I'm doing so I can concentrate on the procedure.
<G-vec00859-002-s102><concentrate.konzentrieren><de> Papa du behältst bitte Mathilda im Auge und erklärst ihr mein Vorgehen, damit ich mich ganz auf den Eingriff konzentrieren kann.
<G-vec00859-002-s174><concentrate.konzentrieren><en> After chanting OM concentrate for a few minutes on your body and be conscious of your existence in its entirety - physically, mentally and spiritually.
<G-vec00859-002-s174><concentrate.konzentrieren><de> Nach dem OM-Singen konzentriere dich einige Minuten lang auf deinen Körper und sei dir deines Daseins in seiner Ganzheit bewußt – körperlich, geistig und seelisch.
<G-vec00859-002-s175><concentrate.konzentrieren><en> Develop all the skills of your character harmoniously or choose to concentrate on one skill and become a master.
<G-vec00859-002-s175><concentrate.konzentrieren><de> Entwickle alle Fähigkeiten Deines Charakters gleichzeitig oder konzentriere Dich auf eine Fähigkeit und meistere sie.
<G-vec00859-002-s176><concentrate.konzentrieren><en> Concentrate on the Navel Chakra and what it stands for, at the spine, slightly above the navel.
<G-vec00859-002-s176><concentrate.konzentrieren><de> Konzentriere dich auf das Nabelchakra an der Wirbelsäule, etwas über dem Nabel, und darauf, was es darstellt.
<G-vec00859-002-s177><concentrate.konzentrieren><en> Concentrate on the here and now, on what you are doing at the moment, on your body’s movements, your cleaning cloth and your scrubbing brush.
<G-vec00859-002-s177><concentrate.konzentrieren><de> Konzentriere Dich auf das Hier und Jetzt, auf das, was Du gerade tust, auf die Bewegungen Deines Körpers, Deines Lappens, Deines Schrubbers.
<G-vec00859-002-s178><concentrate.konzentrieren><en> Always be careful, concentrate, follow the instructions, and follow the tips on the side.
<G-vec00859-002-s178><concentrate.konzentrieren><de> Gehe dabei stets behutsam vor, konzentriere Dich, befolge die Anweisungen und beachte die Hinweise an der Seite.
<G-vec00859-002-s179><concentrate.konzentrieren><en> Concentrate on the task, not the bloody audience.
<G-vec00859-002-s179><concentrate.konzentrieren><de> Konzentriere dich auf deine Aufgabe, nicht auf das verdammte Publikum.
<G-vec00859-002-s180><concentrate.konzentrieren><en> Look at this clip, totally concentrate on my voice and you will love it even more afterwards.
<G-vec00859-002-s180><concentrate.konzentrieren><de> Sieh dir diesen Clip an, tauche immer mehr ab, lass dich fallen und konzentriere dich auf meine Stimme.
<G-vec00859-002-s181><concentrate.konzentrieren><en> At this point you should only concentrate on moving forward (a little) and creating a small hop, nothing else.
<G-vec00859-002-s181><concentrate.konzentrieren><de> Konzentriere dich in dieser Phase darauf die Arme auszustrecken und einen kleinen Hopser zu machen bevor du am Rücken landest.
<G-vec00859-002-s182><concentrate.konzentrieren><en> Rather concentrate on these little ones I have sent you, I love to see them dancing with Me.
<G-vec00859-002-s182><concentrate.konzentrieren><de> Vielmehr konzentriere dich auf diese Kleinen, die Ich dir geschickt habe, Ich liebe es, sie mit Mir tanzen zu sehen.
<G-vec00859-002-s183><concentrate.konzentrieren><en> If the exercises are very new to you and you are having difficulty harmonizing your breathing with them, then first concentrate on carrying out the movements while continuing to breathe in a way that suits you.
<G-vec00859-002-s183><concentrate.konzentrieren><de> Wenn die Übungen für dich noch ganz neu sind und du Schwierigkeiten damit hast, den Atem mit den Bewegungen in Einklang zu bringen, dann konzentriere dich zunächst auf die Ausführung der Bewegungen und atme so weiter, wie es für dich gut passt.
<G-vec00859-002-s184><concentrate.konzentrieren><en> Concentrate on your game, we bring you the right equipment.
<G-vec00859-002-s184><concentrate.konzentrieren><de> Konzentriere dich auf dein Spiel, wir bringen dir die richtige Ausrüstung.
<G-vec00859-002-s185><concentrate.konzentrieren><en> One principle that I personally like, for example, is: concentrate on the low hanging fruits; in other words: try, learn, try, learn, try.
<G-vec00859-002-s185><concentrate.konzentrieren><de> Ein Grundsatz, der mir persönlich gefällt, ist zum Beispiel: Konzentriere dich auf die low hanging fruits; also: ausprobieren, lernen, ausprobieren, lernen, ausprobieren.
<G-vec00859-002-s186><concentrate.konzentrieren><en> Concentrate and focus on the person who is speaking.
<G-vec00859-002-s186><concentrate.konzentrieren><de> Konzentriere dich auf die Person, die gerade spricht.
<G-vec00859-002-s187><concentrate.konzentrieren><en> Concentrate on positive thoughts such as good friends, times, laughter, and the like.
<G-vec00859-002-s187><concentrate.konzentrieren><de> Konzentriere dich auf positive Gedanken, wie zum Beispiel auf gute Freunde, auf schöne Zeiten und ähnliche Dinge.
<G-vec00859-002-s188><concentrate.konzentrieren><en> Concentrate on your feelings, forget about the hectic.
<G-vec00859-002-s188><concentrate.konzentrieren><de> Konzentriere dich auf deine Gefühle, vergiss die Hektik.
<G-vec00859-002-s189><concentrate.konzentrieren><en> Do not use filters or effects, rather concentrate on brightness, contrast and sharpening.
<G-vec00859-002-s189><concentrate.konzentrieren><de> Lass die Finger von grausamen Filtern oder Effekten und konzentriere dich auf die Belichtungsstufen.
<G-vec00859-002-s190><concentrate.konzentrieren><en> Concentrate on every step – your brain has to get used to the new way of moving.
<G-vec00859-002-s190><concentrate.konzentrieren><de> Konzentriere dich auf jeden Schritt – dein Gehirn muss sich erst an die neuen Bewegungsabläufe gewöhnen.
<G-vec00859-002-s191><concentrate.konzentrieren><en> Eyes: Close your eyes. Breath: Concentrate on your breath.
<G-vec00859-002-s191><concentrate.konzentrieren><de> Schließe deine Augen und konzentriere dich auf deinen Atem .
<G-vec00859-002-s192><concentrate.konzentrieren><en> {Concentrate on any tension in your face and take a deep breath in.
<G-vec00859-002-s192><concentrate.konzentrieren><de> 4 Konzentriere dich auf jede mögliche Anspannung in deinem Gesicht und atme tief ein.
<G-vec00859-002-s193><concentrate.konzentrieren><en> Finally, I concentrate on the dust content of Cassiopeia A.
<G-vec00859-002-s193><concentrate.konzentrieren><de> Weiterhin konzentriere ich mich auf eine Untersuchung des Staubgehaltes von Cassiopeia A.
<G-vec00859-002-s194><concentrate.konzentrieren><en> Even the studies have taken off, I concentrate much easier and I am determined to pass the exam that I got stuck on.
<G-vec00859-002-s194><concentrate.konzentrieren><de> Auch habe ich das Studium aufgenommen, konzentriere mich viel leichter und bin fest entschlossen, die Prüfung zu bestehen, die noch bevorsteht.
<G-vec00859-002-s195><concentrate.konzentrieren><en> I tend to concentrate mainly on technical translations (mostly automotive with forays into construction, energy, IT and so on), but with a healthy amount of marketing and sometimes other topics thrown in.
<G-vec00859-002-s195><concentrate.konzentrieren><de> Ich konzentriere mich hauptsächlich auf technische Übersetzungen (meistens aus dem Automobilsektor, hin und wieder mit einem kleinen Ausflug in den Bereich Bau, Energie, IT und so weiter), bearbeite aber auch einiges aus dem Bereich Marketing und manchmal auch aus anderen Gebieten, so dass es nicht langweilig wird.
<G-vec00859-002-s196><concentrate.konzentrieren><en> I concentrate on a certain idea or story.
<G-vec00859-002-s196><concentrate.konzentrieren><de> Ich konzentriere mich auf eine Idee oder eine Geschichte.
<G-vec00859-002-s197><concentrate.konzentrieren><en> I concentrate on putting one hand over the other.
<G-vec00859-002-s197><concentrate.konzentrieren><de> Ich konzentriere mich auf die nächsten Griffe.
<G-vec00859-002-s198><concentrate.konzentrieren><en> “Admittedly, I don’t always concentrate one hundred percent on what’s being said, and sometimes I’m not even consciously listening.
<G-vec00859-002-s198><concentrate.konzentrieren><de> «Zugegeben, ich konzentriere mich nicht immer 100-prozentig auf den Text und höre manchmal auch unbewusst zu.
<G-vec00859-002-s199><concentrate.konzentrieren><en> I avoid unnecessary appointments and concentrate fully on my priorities: skiing.
<G-vec00859-002-s199><concentrate.konzentrieren><de> Unnötige Termine lasse ich aus und konzentriere mich voll auf mein Kerngeschäft: Skifahren.
<G-vec00859-002-s200><concentrate.konzentrieren><en> I concentrate.
<G-vec00859-002-s200><concentrate.konzentrieren><de> Ich konzentriere mich.
<G-vec00859-002-s201><concentrate.konzentrieren><en> I will concentrate on two major American variants of the divine interpreter; namely the figure of the sly B'rer Rabbit and the figure of the root doctor and conjure-man in the hoodoo tradition.To illustrate Esu's development from his African roots to his American relatives, I intend to give a basic insight into his original, African characteristics.
<G-vec00859-002-s201><concentrate.konzentrieren><de> Ich konzentriere mich auf zwei wesentliche Varianten des "göttlichen Dolmetschers" Esu, nämlich auf die Figur des listigen B'rer Rabbit und der des spirituellen Naturheilers und Zauberers, dem Hoodoo Priester.Um die Entwicklung von Esu zu seinen amerikanischen Verwandten zu verdeutlichen, arbeite ich mich von seinen ursprünglichen, afrikanischen, Charakteristiken durch bis hin zu seinen, oben erwähnten, neuen Varianten, die in der Afroamerikanischen Literatur zum Tragen kommen.
<G-vec00859-002-s202><concentrate.konzentrieren><en> These elements help the practitioner to concentrate and increase energy throughout the practice.
<G-vec00859-002-s202><concentrate.konzentrieren><de> Diese Elemente helfen dem Praktizierenden, sich während der gesamten Übung zu konzentrieren und die Energie zu erhöhen.
<G-vec00859-002-s203><concentrate.konzentrieren><en> Special mirrors in solar thermal parabolic trough power plants concentrate the solar radiation onto a receiver, where it is converted into heat by an absorber. Heat is carried away from the absorber by a heat transfer fluid.
<G-vec00859-002-s203><concentrate.konzentrieren><de> In solarthermischen Parabolrinnenkraftwerken konzentrieren spezielle Spiegel die Solarstrahlung auf einen Wärmeempfänger, in dem ein Wärmeträgerfluid die Solarstrahlung aufnimmt und in Hochtemperaturwärme umwandelt.
<G-vec00859-002-s204><concentrate.konzentrieren><en> The ThyssenKrupp Group plans to concentrate its main corporate head offices at two sites in the coming years.
<G-vec00859-002-s204><concentrate.konzentrieren><de> Der ThyssenKrupp Konzern plant, in den nächsten Jahren seine wesentlichen Verwaltungen auf zwei Standorte zu konzentrieren.
<G-vec00859-002-s205><concentrate.konzentrieren><en> First, it allowed me to concentrate deeply on each assignment and to work very efficiently while I worked.
<G-vec00859-002-s205><concentrate.konzentrieren><de> Erstens konnte ich mich so völlig auf jede Aufgabe konzentrieren und diese sehr effizient abarbeiten.
<G-vec00859-002-s207><concentrate.konzentrieren><en> Parties maximize their chances of winning seats if they concentrate their limited resources on the home localities of leading party members.
<G-vec00859-002-s207><concentrate.konzentrieren><de> Parteien maximieren ihre Wahlchancen, wenn sie ihre begrenzten Ressourcen auf die Heimatorte führender Parteimitglieder konzentrieren.
<G-vec00859-002-s208><concentrate.konzentrieren><en> It extends the existing functionality to many, easy-to-use features, which especially in instances or the farms of monsters reduces the number of clicks through automation of loot-and dice processes, which causes that the player can concentrate on the important things significantly better.
<G-vec00859-002-s208><concentrate.konzentrieren><de> Es erweitert die bestehende Funktionalität um viele, einfach zu bedienende Funktionen, wodurch vor allem in Instanzen oder beim Farmen von Monstern die Anzahl der Klicks durch Automatisierung der Loot- und Würfelprozesse drastisch reduziert wird, wodurch man sich als Spieler auf die wichtigen Dinge deutlich besser konzentrieren kann.
<G-vec00859-002-s209><concentrate.konzentrieren><en> In mindfulness meditation we learn to focus our concentration willingly. From moment to moment we try to concentrate on those things, on which we actually want to concentrate.
<G-vec00859-002-s209><concentrate.konzentrieren><de> In der Achtsamkeitsmeditation lernen wir, unsere Konzentration willentlich zu fokussieren – uns von Moment zu Moment auf Dinge zu konzentrieren, auf die wir uns tatsächlich konzentrieren möchten.
<G-vec00859-002-s211><concentrate.konzentrieren><en> A study conducted in early 2004 by the Beckman Institute at the University of Illinois proved that people who are physically fit have significantly shorter response times, can concentrate better and make fewer mistakes.
<G-vec00859-002-s211><concentrate.konzentrieren><de> Eine Studie des Beckman-Institutes der University of Illinois in Urbana in den USA hat Anfang 2004 ergeben, dass körperlich fitte Menschen deutlich kürzere Reaktionszeiten haben, sich besser konzentrieren können und weniger Fehler machen.
<G-vec00859-002-s212><concentrate.konzentrieren><en> When the pupils become restless during the lesson, cannot concentrate anymore, then phases of relaxation could help.
<G-vec00859-002-s212><concentrate.konzentrieren><de> Wenn die Schüler im Unterricht unruhig werden, sich nicht mehr konzentrieren, dann können u. a. Entspannungsphasen helfen.
<G-vec00859-002-s213><concentrate.konzentrieren><en> The geometry has a deliberately low-key feel so that the driver can concentrate fully on the driving experience,” explains Domagoj Dukec.
<G-vec00859-002-s213><concentrate.konzentrieren><de> Die Geometrie nimmt sich bewusst zurück, sodass der Fahrer sich komplett auf das Fahrerlebnis konzentrieren kann“, führt Domagoj Dukec weiter aus.
<G-vec00859-002-s214><concentrate.konzentrieren><en> It allows the company V-Zug to concentrate its manufacturing process on the Northern part of the site, freeing the Southern part for third party development.
<G-vec00859-002-s214><concentrate.konzentrieren><de> Er ermöglicht der Firma V-Zug alle ihre Prozesse auf dem Nordareal zu konzentrieren und so das Südareal freizuspielen.
<G-vec00859-002-s215><concentrate.konzentrieren><en> Instead of focusing only on adding new skills to your A-game, concentrate on eliminating big leaks in your C-game.
<G-vec00859-002-s215><concentrate.konzentrieren><de> Anstatt dich einseitig auf die Verbesserung deines A-Games zu konzentrieren, solltest du die größten Leaks in deinem C-Game ausmerzen.
<G-vec00859-002-s216><concentrate.konzentrieren><en> A network of experts and consultants enables us to exclusively employ specialists for the diverse aspects of our projects and concentrate our capacity on our core competence.
<G-vec00859-002-s216><concentrate.konzentrieren><de> Ein Netzwerk von Fachplanern und Beratern ermöglicht uns, ausschließlich Spezialisten für die verschiedenen Aspekte unserer Projekte einzusetzen und unsere eigene Kapazität auf unsere Kernkompetenz zu konzentrieren.
<G-vec00859-002-s217><concentrate.konzentrieren><en> So concentrate your attacks and destroy your enemy there and do not attack on many different places to only damage the enemy.
<G-vec00859-002-s217><concentrate.konzentrieren><de> Deshalb die Angriffe konzentrieren und dort den Feind vernichten und nicht an möglichst vielen Stellen angreifen und den Feind nur beschädigen.
<G-vec00859-002-s218><concentrate.konzentrieren><en> If your stomach is upset, then naturally you cannot sit, you cannot concentrate.
<G-vec00859-002-s218><concentrate.konzentrieren><de> Wenn euer Magen verstimmt ist, könnt ihr natürlich nicht meditieren oder euch konzentrieren.
<G-vec00859-002-s219><concentrate.konzentrieren><en> So you can relax and just concentrate on your core business.
<G-vec00859-002-s219><concentrate.konzentrieren><de> So können Sie sich entspannen und auf Ihr Kerngeschäft konzentrieren.
<G-vec00859-002-s220><concentrate.konzentrieren><en> We almost always try to concentrate our projects on Berlin, on the current reality, on what is happening here on our doorstep.
<G-vec00859-002-s220><concentrate.konzentrieren><de> Wir versuchen uns fast immer in unseren Projekten auf Berlin zu konzentrieren, auf die jetzige Lebensrealität, auf das, was hier vor unserer Haustür stattfindet.
<G-vec00859-002-s221><concentrate.konzentrieren><en> In Shanghai there concentrate deep and dynamic transformation processes on a economic, technological and societal level in an exemplary manner.
<G-vec00859-002-s221><concentrate.konzentrieren><de> In Shanghai konzentrieren sich tiefgreifende, dynamische Transformationsprozesse auf wirtschaftlicher, technologischer und gesellschaftlicher Ebene in exemplarischer Weise.
<G-vec00859-002-s222><concentrate.konzentrieren><en> Free to concentrate on what really matters.
<G-vec00859-002-s222><concentrate.konzentrieren><de> Konzentrieren Sie sich auf das, was für Sie wichtig ist.
<G-vec00859-002-s223><concentrate.konzentrieren><en> Concentrate on problem areas, impurities and blackheads.
<G-vec00859-002-s223><concentrate.konzentrieren><de> Konzentrieren Sie sich auf Problembereiche, Unreinheiten und Mitesser.
<G-vec00859-002-s224><concentrate.konzentrieren><en> About the Majors The Bachelors of Fine Arts (B.F.A.) students concentrate on multimedia and graphic design or studio art.
<G-vec00859-002-s224><concentrate.konzentrieren><de> Über den Majors Die Bachelor of Fine Arts (BFA) Studenten konzentrieren sich auf Multimedia und Grafik-Design oder Studio-Kunst.
<G-vec00859-002-s225><concentrate.konzentrieren><en> Concentrate on the propulsion and landing phases of your stride.
<G-vec00859-002-s225><concentrate.konzentrieren><de> Konzentrieren Sie sich auf die Abdruck- und die Landephase.
<G-vec00859-002-s226><concentrate.konzentrieren><en> The majority of external service providers concentrate on the classical service areas such as cleaning, repairs, mobility, and care taking.
<G-vec00859-002-s226><concentrate.konzentrieren><de> Die meisten externen Anbieter konzentrieren sich auf die klassischen Dienstleistungsbereiche wie Reparatur, Reinigung, Mobilität und Betreuung.
<G-vec00859-002-s227><concentrate.konzentrieren><en> Laser devices used for the treatment of skin anomalies and age-specific modifications mainly concentrate on destroying tissue parts in extremely small skin areas.
<G-vec00859-002-s227><concentrate.konzentrieren><de> Lasergeräte, die für die Behandlung von Hautanomalien und altersbedingter Veränderungen eingesetzt werden, konzentrieren sich im Wesentlichen auf die Zerstörung von Gewebeteilen auf kleinstem Raum.
<G-vec00859-002-s228><concentrate.konzentrieren><en> The double-round headlights positioned wide on the vehicle’s exterior concentrate on what’s important: the road.
<G-vec00859-002-s228><concentrate.konzentrieren><de> Die weit außen positionierten Doppelrundscheinwerfer konzentrieren sich auf das Wesentliche: die Straße.
<G-vec00859-002-s229><concentrate.konzentrieren><en> Many weight loss medication concentrate on day time weight reduction only, ignoring the reality that sleep is essential for your weight loss success.
<G-vec00859-002-s229><concentrate.konzentrieren><de> Die meisten Gewichtsverlust Pillen konzentrieren sich auf Tageszeit Gewichtsverlust nur, ignoriert die Tatsache, dass der Schlaf für Ihre Diät Erfolg entscheidend ist.
<G-vec00859-002-s230><concentrate.konzentrieren><en> Within the framework of the subject measurement- and control technology the research activities concentrate on theoretical and practical tasks of modelling, designing and implementing control technological systems.
<G-vec00859-002-s230><concentrate.konzentrieren><de> Im Rahmen des Fachgebietes Mess- Steuerungs- und Regelungstechnik konzentrieren sich die Forschungsaktivitäten auf theoretische und praktische Arbeiten zu Modellbildung, Entwurf und Implementierung von regelungstechnischen Systemen.
<G-vec00859-002-s231><concentrate.konzentrieren><en> Now concentrate on the chosen chakra, expressing in the teachings – be it a tone – the name of the demon connected to it and remove it from a familiar need.
<G-vec00859-002-s231><concentrate.konzentrieren><de> Konzentrieren Sie sich nun auf das auserwählte Chakra und drücken Sie in den Lehren – ein Ton – den Namen des Dämons, der mit ihm verbunden ist, und entfernen Sie ihn von einem vertrauten Bedürfnis.
<G-vec00859-002-s232><concentrate.konzentrieren><en> End users Concentrate on your work and stop wasting time with IT limitations.
<G-vec00859-002-s232><concentrate.konzentrieren><de> Endanwender Konzentrieren Sie sich auf Ihre Arbeit und verschwenden Sie keine Zeit mehr mit Einschränkungen durch die IT.
<G-vec00859-002-s233><concentrate.konzentrieren><en> Concentrate on your core competencies and let us take care of all assignments in staffing services – reliably and efficiently.
<G-vec00859-002-s233><concentrate.konzentrieren><de> Konzentrieren Sie sich auf Ihre Kernkompetenzen und lassen Sie sämtliche Aufgaben bezüglich Ihres Personalmanagements zuverlässig und effizient von uns erledigen.
<G-vec00859-002-s234><concentrate.konzentrieren><en> At RECYCLING-TECHNIK Dortmund you will be able to get your completely furnished stand without any effort and can therefore concentrate on making business with interested companies for two days
<G-vec00859-002-s234><concentrate.konzentrieren><de> Beziehen Sie einfach ohne jeglichen Aufwand Ihren fertigen, komplett möblierten Messestand und konzentrieren Sie sich dann für zwei Tage auf die Geschäfte mit interessierten Firmen.
<G-vec00859-002-s235><concentrate.konzentrieren><en> steers your vehicle, allowing you to concentrate fully on your work.
<G-vec00859-002-s235><concentrate.konzentrieren><de> Der SmartPilot lenkt Ihr Fahrzeug, Sie konzentrieren sich voll auf Ihre Arbeit.
<G-vec00859-002-s236><concentrate.konzentrieren><en> Concentrate on core TEM objectives and TEM strategic initiatives rather than hosting, infrastructure, and connectivity issues
<G-vec00859-002-s236><concentrate.konzentrieren><de> Konzentrieren Sie sich auf die Hauptziele –und Strategien der TEM –Initiative anstatt auf die Bereitstellung, Infrastruktur und Konnektivität.
<G-vec00859-002-s237><concentrate.konzentrieren><en> DVV International activities therefore concentrate on projects which benefit the most socially disadvantaged sectors of the population.
<G-vec00859-002-s237><concentrate.konzentrieren><de> Die Maßnahmen von DVV International konzentrieren sich daher auf Projekte, die den sozial am meisten benachteiligten Bevölkerungsgruppen zu Gute kommen.
<G-vec00859-002-s238><concentrate.konzentrieren><en> Concentrate on the clever colleagues who already master their challenges.
<G-vec00859-002-s238><concentrate.konzentrieren><de> Konzentrieren Sie sich auf gute Leute, die ihre Herausforderungen bereits meistern.
<G-vec00859-002-s239><concentrate.konzentrieren><en> Research and studies concentrate on digital media both as technology in the context of design and planning as well as being constituent component of a planned society.
<G-vec00859-002-s239><concentrate.konzentrieren><de> Forschung und Lehre konzentrieren sich auf digitale Medien sowohl als Technologie hinter Design und Planung als auch als konstitutiver Bestandteil der geplanten Gesellschaft.
<G-vec00859-002-s240><concentrate.konzentrieren><en> We also concentrate on the same element that made Spacelab a success — pilot projects.
<G-vec00859-002-s240><concentrate.konzentrieren><de> Zudem konzentrieren wir uns auf das, was auch das Spacelab erfolgreich gemacht hat — die Pilotprojekte.
<G-vec00859-002-s241><concentrate.konzentrieren><en> We concentrate on areas that promote our role as a “good neighbor” of the communities in which we operate worldwide. We also focus on projects that can benefit from our core areas of expertise as an automobile manufacturer as well as our specific know-how.
<G-vec00859-002-s241><concentrate.konzentrieren><de> Wir konzentrieren uns auf Handlungsfelder, die unserer Rolle als »guter Nachbar« an den Standorten weltweit förderlich sind, und auf Projekte, die von unserer Kernkompetenz als Automobilhersteller ebenso wie von unserem spezifischen Wissen profitieren können.
<G-vec00859-002-s242><concentrate.konzentrieren><en> We concentrate on niche categories, in which we strive to achieve market leadership.
<G-vec00859-002-s242><concentrate.konzentrieren><de> Wir konzentrieren uns auf Nischenmärkte, in denen wir die Marktführerschaft anstreben.
<G-vec00859-002-s243><concentrate.konzentrieren><en> Our vision is to concentrate on the essentials without any unnecessary frills. In the new Jacob’s Restaurant, guests will be able to experience simplicity at its best,” explains Thomas Martin.
<G-vec00859-002-s243><concentrate.konzentrieren><de> Wir konzentrieren uns auf das Wesentliche mit der Vision, die Küche im besten Sinne zu vereinfachen: Im neuen Jacobs Restaurant erlebt der Gast ‚Einfachheit auf höchstem Niveau‘“, so Thomas Martin.
<G-vec00859-002-s244><concentrate.konzentrieren><en> We concentrate on creating a customised database of the recipients, as well as on the highest possible deliverability of the e-mails, which we monitor and measure.
<G-vec00859-002-s244><concentrate.konzentrieren><de> Wir konzentrieren uns auf die Schaffung einer bestmöglich zugeschnittenen Empfängerdatenbank sowie auf eine gleichermaßen hohe Lieferbarkeit der E-Mails, die wir überwachen und messen.
<G-vec00859-002-s245><concentrate.konzentrieren><en> In the interests of optimum functionality and competitiveness, we concentrate first and foremost on elastic infill granules made of EPDM variants (GOLD
<G-vec00859-002-s245><concentrate.konzentrieren><de> Für ein Optimum an Funktionalität und Wetterbeständigkeit konzentrieren wir uns dabei vor allem auf elastische Einfüllgranulate aus EPDM-Varianten (Ethylen-Propylen-Dien-Kautschuk).
<G-vec00859-002-s246><concentrate.konzentrieren><en> For pulling and pulled units, we concentrate on chassis elements that achieve these goals.
<G-vec00859-002-s246><concentrate.konzentrieren><de> Für ziehende und gezogene Einheiten konzentrieren wir uns auf Fahrwerkelemente, die diese Ziele erreichen.
<G-vec00859-002-s247><concentrate.konzentrieren><en> Following an analysis of your target market, we will concentrate on the essentials.
<G-vec00859-002-s247><concentrate.konzentrieren><de> Nach einer Analyse Ihres Zielmarktes konzentrieren wir uns auf das Wesentliche.
<G-vec00859-002-s248><concentrate.konzentrieren><en> We continue to consistently concentrate on the development, design and production of systems and integratable machines for dry work – for textile service providers of every size.
<G-vec00859-002-s248><concentrate.konzentrieren><de> Wir konzentrieren uns weiterhin konsequent auf die Entwicklung, Konstruktion und Produktion von Systemanlagen und integrationsfähigen Maschinen im trockenen Bereich – für Textile Dienstleister jeder Unternehmensgröße.
<G-vec00859-002-s249><concentrate.konzentrieren><en> Finally, we concentrate on protein variants that arise by alternative splicing events.
<G-vec00859-002-s249><concentrate.konzentrieren><de> Im letzten Teil der Arbeit konzentrieren wir uns auf Proteinvarianten, die sich durch alternatives Spleißen ergeben.
<G-vec00859-002-s250><concentrate.konzentrieren><en> After discussing some general results we concentrate on the rational unibranch case, i.e., the case where the associated maximal order is local again, with residue field equal to the ground field.
<G-vec00859-002-s250><concentrate.konzentrieren><de> Nach Diskussion einiger allgemeiner Resultate konzentrieren wir uns auf den rationalen einzweigigen Fall, d.h., den Fall wo die assoziierte Hauptordnung wieder lokal ist, mit Restklassenkörper gleich dem Grundkörper.
<G-vec00859-002-s251><concentrate.konzentrieren><en> In this book, we concentrate on the SP waveguide configurations ensuring nanoscale confinement and review the current status of this rapidly emerging field, considering different configurations being developed for nanoscale plasmonic guides and circuits.
<G-vec00859-002-s251><concentrate.konzentrieren><de> In diesem Buch konzentrieren uns wir auf die SP-Hohlleiterkonfigurationen, nanoscale Beschränkung sicherstellend und wiederholen den aktuellen Status dieses schnell auftauchenden Bereichs, in Betracht der verschiedenen Konfigurationen, die für nanoscale plasmonic Anleitungen und Schaltungen sich entwickelt werden.
<G-vec00859-002-s252><concentrate.konzentrieren><en> We concentrate on our core business to provide the highest level of expertise within our portfolio.
<G-vec00859-002-s252><concentrate.konzentrieren><de> Wir konzentrieren uns auf unser Kerngeschäft, um das größtmögliche Expertenwissen innerhalb unseres Fachbereichs bereitzustellen.
<G-vec00859-002-s253><concentrate.konzentrieren><en> But let’s not digress and concentrate on the technical provision of the feature.
<G-vec00859-002-s253><concentrate.konzentrieren><de> Aber schweifen wir nicht ab und konzentrieren wir uns auf die technische Bereitstellung des Features.
<G-vec00859-002-s254><concentrate.konzentrieren><en> For now, we will concentrate on the renal aspects.
<G-vec00859-002-s254><concentrate.konzentrieren><de> Für den Augenblick konzentrieren wir uns auf die renalen Aspekte.
<G-vec00859-002-s255><concentrate.konzentrieren><en> As a specialist within the ALHO Group, we concentrate on the production of high-quality space solutions - from simple standard containers to complex container buildings.
<G-vec00859-002-s255><concentrate.konzentrieren><de> Als Spezialist innerhalb der ALHO Gruppe konzentrieren wir uns auf die Herstellung hochwertiger Raumlösungen – von einfachen Standard-Containern bis zu komplexen Containergebäuden.
<G-vec00859-002-s256><concentrate.konzentrieren><en> We concentrate on roadway security industry for greater than 11 years.
<G-vec00859-002-s256><concentrate.konzentrieren><de> Wir konzentrieren uns auf Fahrbahnbewachungsgewerbe für größer als 11 Jahre.
<G-vec00859-002-s257><concentrate.konzentrieren><en> We concentrate on loans secured by property liens.
<G-vec00859-002-s257><concentrate.konzentrieren><de> Wir konzentrieren uns auf grundpfandrechtlich besicherte gewerbliche Kredite.
<G-vec00859-002-s258><concentrate.konzentrieren><en> In this workshop we concentrate on sour, salty and sweet.
<G-vec00859-002-s258><concentrate.konzentrieren><de> In diesem Workshop konzentrieren wir uns auf sauer, salzig und süß.
<G-vec00859-002-s259><concentrate.konzentrieren><en> Directional Shape Directional Shape The classic snowboard shape, designed to be ridden with a slightly longer nose than tail to concentrate pop in the tail while still giving you plenty of float, flow, and control to rip any terrain or condition.
<G-vec00859-002-s259><concentrate.konzentrieren><de> Tip und Tail sträuben sich mit einem Early Rise außerhalb der Füße, für das verkantungsfreie, leichte Feeling, das du eigentlich von einem Rocker erwarten mit einer etwas längeren Nose als Tail zu fahren, was den Pop im Tail konzentriert, während du immer noch genug Float, Flow und Kontrolle hast, jedes Gelände bei allen Bedingungen zu bewältigen.
<G-vec00859-002-s260><concentrate.konzentrieren><en> Directional Shape Directional Shape The classic snowboard shape, designed to be ridden with a slightly longer nose than tail to concentrate pop in the tail while still giving you plenty of float, flow, and control to rip any terrain or condition.
<G-vec00859-002-s260><concentrate.konzentrieren><de> Mit einer schwungvollen Federung verteilt Camber das Gewicht gleichmäßig über die gesamte Länge des Boards für eine klassische Snowboard-Form wurde entwickelt, um mit einer etwas längeren Nose als Tail zu fahren, was den Pop im Tail konzentriert, während du immer noch genug Float, Flow und Kontrolle hast, jedes Gelände bei allen Bedingungen zu bewältigen.
<G-vec00859-002-s261><concentrate.konzentrieren><en> Alternately contracting the muscles to the front and then the rear and then concentrate on achieving a gentle contraction somewhere in the middle, you are now one step closer to Mula Bandha.
<G-vec00859-002-s261><concentrate.konzentrieren><de> Kombinierst Du die vordere und die hintere Kontraktion und konzentriert sie zu einer sanftern mittleren Kontraktion, bist Du noch einen Schritt näher an Mula-Bandha.
<G-vec00859-002-s262><concentrate.konzentrieren><en> The Elector, becoming impatient because of the Danish landing, ordered his troops to land at the nearest point, since based on his understanding (he knew nothing of the Swedish retreat), he feared that Sweden would concentrate their attack on the Danes.
<G-vec00859-002-s262><concentrate.konzentrieren><de> Der Kurfürst befahl, aufgrund der dänischen Landung ungeduldig geworden, am nächstbesten Punkt anzulanden, da er nach seinem Informationsstand (er wusste nichts vom schwedischen Rückzug) fürchtete, die Schweden würden konzentriert die Dänen angreifen.
<G-vec00859-002-s263><concentrate.konzentrieren><en> They concentrate in the region of Spiš (5) followed by the group of central Slovakia mining towns (4).
<G-vec00859-002-s263><concentrate.konzentrieren><de> Am stärksten konzentriert sind sie in der Region Spiš (5) und der Region der mittelslowakischen Bergbaustädte (4).
<G-vec00859-002-s264><concentrate.konzentrieren><en> CutGenic for women by Bodyraise is a cream, made to concentrate on women's more problematic areas in the body, such as the abdomen, thighs, hips and arms.
<G-vec00859-002-s264><concentrate.konzentrieren><de> CutGenic For Women von BodyRaise wurde dafür entwickelt, konzentriert auf die Problemzonen des weiblichen Körpers wie Bauch, Schenkel, Hüften und Arme zu wirken.
<G-vec00859-002-s265><concentrate.konzentrieren><en> In order to produce tea extract, it is necessary to extract the aqueous tea solution and concentrate the tea leaves.
<G-vec00859-002-s265><concentrate.konzentrieren><de> Um Tee-Extrakt zu gewinnen, extrahiert man die wässrige Teelösung und konzentriert die Teeblätter.
<G-vec00859-002-s266><concentrate.konzentrieren><en> I think I'm really getting too old to concentrate on work at 2:30 in the night.
<G-vec00859-002-s266><concentrate.konzentrieren><de> Ich werde offenbar einfach zu alt um nachts um 2:30 Uhr noch konzentriert arbeiten zu können.
<G-vec00859-002-s267><concentrate.konzentrieren><en> The Skyline cab spoils your ears with a very low noise level, so that you can concentrate on your work, even after many long hours.
<G-vec00859-002-s267><concentrate.konzentrieren><de> Um auch noch nach vielen Stunden konzentriert arbeiten zu können, verwöhnt die Skyline Kabine Ihre Ohren mit einem niedrigen Geräuschpegel.
<G-vec00859-002-s268><concentrate.konzentrieren><en> This means that while there is a condensation for low temperatures, the Gibbs measure does not concentrate around the patterns.
<G-vec00859-002-s268><concentrate.konzentrieren><de> Dies bedeutet, daß, obwohl das Gibbsmaß sich bei kleinen Temperaturen auf einer kleinen Teilmenge des Zustandsraumes konzentriert, dies nicht in der Nähe der Muster geschieht.
<G-vec00859-002-s269><concentrate.konzentrieren><en> Newbies mostly concentrate themselves to solid and well-priced effect brands like Boss or Joyo.
<G-vec00859-002-s269><concentrate.konzentrieren><de> Meist konzentriert man sich als Anfänger erst einmal auf solide und preiswerte Effektmarken, wie Boss oder vielleicht Joyo .
<G-vec00859-002-s270><concentrate.konzentrieren><en> The origins of dyscalculia are varied, but Dr. Kaufmann will concentrate on the form of the disorder associated with particular genetic defects.
<G-vec00859-002-s270><concentrate.konzentrieren><de> Die Ursachen von Dyskalkulien sind zwar vielfältig, doch konzentriert Dr. Kaufmann ihre Untersuchungen auf jene Form, die mit bestimmten Erberkrankungen einhergeht.
<G-vec00859-002-s271><concentrate.konzentrieren><en> During the course of Heyform's jockeying for market position the company will concentrate solely on the automobile industry.
<G-vec00859-002-s271><concentrate.konzentrieren><de> Im Zuge der Marktpositionierung von Heyform wird das Geschäft ausschließlich auf die Automobilindustrie konzentriert.
<G-vec00859-002-s272><concentrate.konzentrieren><en> By moving from Stuttgart to Bietigheim-Bissingen in mid-2009, Dürr will concentrate its activities in the areas of paint, assembly, and environmental systems.
<G-vec00859-002-s272><concentrate.konzentrieren><de> Mit dem Umzug von Stuttgart nach Bietigheim-Bissingen Mitte 2009 konzentriert Dürr seine Lackier-, Montage- und Umwelttechnikaktivitäten.
<G-vec00859-002-s273><concentrate.konzentrieren><en> The classic arrangement into single and double offices is ideal for when there are confidential matters to be discussed or staff need to concentrate particularly closely on their work.
<G-vec00859-002-s273><concentrate.konzentrieren><de> Die klassische Aufteilung in Einzel und Doppelbüros ist dort ideal, wo vertrauliche Dinge behandelt werden oder die Mitarbeiter besonders konzentriert arbeiten müssen.
<G-vec00859-002-s274><concentrate.konzentrieren><en> The extraordinary Authentic Formula in this Bottle is very dense and concentrate so it is recommended to mix it inside The Nuru Mixing Bowl with water, on a ratio of one part of Gel Nuru to three parts of water for a Nuru Massage or use it straight out of the bottle for Shower/Tub play.
<G-vec00859-002-s274><concentrate.konzentrieren><de> Die außergewöhnliche Authentische Formel in dieser Flasche ist sehr dicht und konzentriert, daher ist es empfehlenswert, sie in der Nuru Schale mit Wasser im Verhältnis ein Teil Nuru Gel zu drei Teilen Wasser für eine Nuru Massage zu mischen, oder verwenden Sie die Flasche für Dusch-/Wannenspiele.
<G-vec00859-002-s275><concentrate.konzentrieren><en> The latest investment is a line used to concentrate whey by reverse osmosis.
<G-vec00859-002-s275><concentrate.konzentrieren><de> Die jüngste Investition ist eine Linie, mit der Molke durch Umkehrosmose konzentriert wird.
<G-vec00859-002-s276><concentrate.konzentrieren><en> It does this by using a Fresnel lens to concentrate the direct sunlight on thin focal lines.
<G-vec00859-002-s276><concentrate.konzentrieren><de> Dabei wird eine Fresnel-Linse verwendet, die das direkte Sonnenlicht in dünnen Brennlinien konzentriert.
<G-vec00859-002-s277><concentrate.konzentrieren><en> A: If you beg for advice in this matter, we will say only this: perhaps best to concentrate all, and we do mean all, energies upon this matter and the seriousness therein during communications.
<G-vec00859-002-s277><concentrate.konzentrieren><de> A: Wenn ihr in dieser Sache um Rat bittet, werden wir nur das sagen: es ist möglicherweise am Besten, wenn während des Kommunizierens alle, und wir meinen tatsächlich alle, Energien auf diese Angelegenheit und die darin innewohnende Ernsthaftigkeit konzentriert werden.
<G-vec00859-002-s278><concentrate.konzentrieren><en> He doesn’t concentrate on the raft, but goes looking for what happened just before and just after the disaster.
<G-vec00859-002-s278><concentrate.konzentrieren><de> Er konzentriert sich nicht auf das Floß, sondern versucht herauszufinden, was genau vor und genau nach der Katastrophe geschah.
<G-vec00859-002-s279><concentrate.konzentrieren><en> You hear, see, and read very little about Pierre Charpin – the French designer avoids the limelight, preferring to concentrate on his work.
<G-vec00859-002-s279><concentrate.konzentrieren><de> Nur wenig hört, sieht oder liest man über Pierre Charpin – der französische Designer meidet das Rampenlicht und konzentriert sich lieber auf seine Arbeit.
<G-vec00859-002-s280><concentrate.konzentrieren><en> The qualification programmes concentrate on students, doctoral candidates and postdocs.
<G-vec00859-002-s280><concentrate.konzentrieren><de> Das Qualifizierungsangebot konzentriert sich auf Studierende, Promovierende und Postdocs.
<G-vec00859-002-s281><concentrate.konzentrieren><en> School clothing marks a turning point like “professional clothing”: those who wear them become part of a community and concentrate almost automatically on the task, in this case the school-related aspects.
<G-vec00859-002-s281><concentrate.konzentrieren><de> Schulkleidung setzt wie „Berufskleidung“ eine Zäsur: Wer sie trägt, wird Teil einer Gemeinschaft und konzentriert sich wie von selbst auf die Aufgabe, in diesem Fall das Schulische.
<G-vec00859-002-s282><concentrate.konzentrieren><en> Swiss Life/Rentenanstalt will concentrate on its life insurance business for the future.
<G-vec00859-002-s282><concentrate.konzentrieren><de> Die Rentenanstalt/Swiss Life konzentriert sich künftig auf das Lebensversicherungsgeschäft.
<G-vec00859-002-s283><concentrate.konzentrieren><en> It will concentrate on the critical zone that begins below the root-filled soil layer.
<G-vec00859-002-s283><concentrate.konzentrieren><de> Er konzentriert sich auf den Bereich der „Kritischen Zone", der unterhalb der intensiv durchwurzelten Bodenschicht beginnt.
<G-vec00859-002-s284><concentrate.konzentrieren><en> It will concentrate on the critical zone that begins below the root-filled soil layer.
<G-vec00859-002-s284><concentrate.konzentrieren><de> Er konzentriert sich auf den Bereich der „Kritischen Zone“, der unterhalb der intensiv durchwurzelten Bodenschicht beginnt.
<G-vec00859-002-s285><concentrate.konzentrieren><en> In children under the age of three, the pain does not mainly concentrate in one place.
<G-vec00859-002-s285><concentrate.konzentrieren><de> Bei Kindern unter drei Jahren konzentriert sich der Schmerz nicht hauptsächlich an einem Ort.
<G-vec00859-002-s286><concentrate.konzentrieren><en> For this reason, we shall concentrate on the area between the stanchions.
<G-vec00859-002-s286><concentrate.konzentrieren><de> Somit konzentriert sich unser Augenmerk auf die Fläche zwischen den Rungen.
<G-vec00859-002-s287><concentrate.konzentrieren><en> If we concentrate on these hands we will often be able to knock one or two bad players out of the tournament, simply by virtue of having the better hand.
<G-vec00859-002-s287><concentrate.konzentrieren><de> Konzentriert man sich auf diese Hände, wird man oftmals den ein oder anderen schlechten Spieler aus dem Turnier nehmen, da man schlichtweg die bessere Hand hat.
<G-vec00859-002-s288><concentrate.konzentrieren><en> Phoenix will initially concentrate on power plant construction in the US market.
<G-vec00859-002-s288><concentrate.konzentrieren><de> Phoenix konzentriert sich im US Markt zunächst auf den Kraftwerksbau.
<G-vec00859-002-s289><concentrate.konzentrieren><en> Allowing you to concentrate on the essentials.
<G-vec00859-002-s289><concentrate.konzentrieren><de> Hier konzentriert man sich auf das Wesentliche.
<G-vec00859-002-s290><concentrate.konzentrieren><en> We concentrate†on the development of innovative seeds for the needs of a rapidly changing society.
<G-vec00859-002-s290><concentrate.konzentrieren><de> KWS konzentriert sich auf die Entwicklung von innovativem Saatgut für den Bedarf einer sich rasant wandelnden Gesellschaft.
<G-vec00859-002-s291><concentrate.konzentrieren><en> 1937 brought a strategic refocusing, as the company was fully taken over by Schering AG: from this point onwards, production began to concentrate on chemical/technical products, but manufactured pharmaceuticals at an increasing rate as well.
<G-vec00859-002-s291><concentrate.konzentrieren><de> 1937 erfolgt mit der kompletten Übernahme durch die Schering AG eine strategische Neupositionierung: Ab jetzt konzentriert sich die Produktion auf chemisch-technische, aber zunehmend auch pharmazeutische Erzeugnisse.
<G-vec00859-002-s292><concentrate.konzentrieren><en> (Arvato Systems) Gütersloh/Cologne – Future-oriented IT specialist Arvato Systems to concentrate on the creation and development of their software products for broadcast and media, without however compromising enterprise business growth.
<G-vec00859-002-s292><concentrate.konzentrieren><de> (Arvato Systems) Gütersloh/Köln – Als zukunftsorientierter IT-Experte konzentriert sich Arvato Systems im Bereich Broadcast- und Medienlösungen auf die Entwicklung und Herstellung eigener Software-Produkte, ohne dabei den Ausbau des Enterprise-Business zu vernachlässigen.
<G-vec00859-002-s293><concentrate.konzentrieren><en> He gives pride of place to selected ingredients, only then does he concentrate on the execution.
<G-vec00859-002-s293><concentrate.konzentrieren><de> Er gibt ausgewählten Zutaten den Vorzug, erst dann konzentriert er sich auf deren Ausführung.
<G-vec00859-002-s294><concentrate.konzentrieren><en> 2018 will see the MAN Group focus on the following areas: the Company will continue to concentrate on measures to optimize processes and cost structures.
<G-vec00859-002-s294><concentrate.konzentrieren><de> Im Jahr 2018 stehen für die MAN Gruppe folgende Themen im Mittelpunkt: Das Unternehmen konzentriert sich weiterhin auf Maßnahmen zur Optimierung von Prozessen und Kostenstrukturen.
<G-vec00859-002-s295><concentrate.konzentrieren><en> It is for this reason that the University of Bayreuth has chosen to concentrate its efforts on six faculties, making sure that their research and teaching is nurtured and fostered across the board.
<G-vec00859-002-s295><concentrate.konzentrieren><de> Aus diesem Grund konzentriert sich die Universität Bayreuth bewusst auf sechs Fakultäten, um diese in Forschung und Lehre in der ganzen Bandbreite fördern und unterstützen zu können.
<G-vec00859-002-s296><concentrate.konzentrieren><en> Research Our main research activities concentrate on labour market policy, regional and social policy, education training and job qualification, equal opportunities, and structural fund interventions in Austria and the Eastern European neighbour states.
<G-vec00859-002-s296><concentrate.konzentrieren><de> Forschung Unsere Forschungstätigkeit konzentriert sich auf Arbeitsmarkt-, Regional- und Sozialpolitik, Weiterbildung und berufliche Qualifizierung, Chancengleichheit und Strukturfonds-Interventionen in Österreich und den osteuropäischen Nachbarstaaten.
<G-vec00859-002-s297><concentrate.konzentrieren><en> But tomorrow is a new day and I will fully concentrate on the task ahead.
<G-vec00859-002-s297><concentrate.konzentrieren><de> Aber morgen ist ein neuer Tag und ich werde mich voll auf die bevorstehende Aufgabe konzentrieren.
<G-vec00859-002-s298><concentrate.konzentrieren><en> I need to concentrate hard to understand, and even harder to talk.
<G-vec00859-002-s298><concentrate.konzentrieren><de> Ich muss mich schwer konzentrieren, um zu verstehen, und noch schwerer, um zu reden.
<G-vec00859-002-s299><concentrate.konzentrieren><en> Feeling helpless, I decided to forget about it and concentrate on Fa-study.
<G-vec00859-002-s299><concentrate.konzentrieren><de> In meiner Hilflosigkeit entschloss ich mich, es zu vergessen und mich auf das Fa-Lernen zu konzentrieren.
<G-vec00859-002-s300><concentrate.konzentrieren><en> And then I can concentrate on my work.
<G-vec00859-002-s300><concentrate.konzentrieren><de> Dann kann ich mich auch auf meine Arbeit konzentrieren.
<G-vec00859-002-s301><concentrate.konzentrieren><en> In my lecture I will mainly concentrate on the first two areas. The third, which in some respects is closely connected to the second, can only be treated in passing here.
<G-vec00859-002-s301><concentrate.konzentrieren><de> In meinem Vortrag werde ich mich vor allem auf die beiden ersten Bereiche konzentrieren; der dritte, der in mehrfacher Hinsicht mit dem zweiten eng verknüpft ist, kann in diesem Rahmen nur am Rande behandelt werden.
<G-vec00859-002-s302><concentrate.konzentrieren><en> The 300 SLR gave me the reassurance to be able to concentrate fully on the race and winning.
<G-vec00859-002-s302><concentrate.konzentrieren><de> Der 300 SLR gab mir das gute Gefühl, mich ganz auf das Rennen und den Sieg konzentrieren zu können.
<G-vec00859-002-s303><concentrate.konzentrieren><en> I try to concentrate on myself.
<G-vec00859-002-s303><concentrate.konzentrieren><de> Ich probiere, mich auf mich selbst zu konzentrieren.
<G-vec00859-002-s304><concentrate.konzentrieren><en> So now I can again concentrate on the fight against the weather.
<G-vec00859-002-s304><concentrate.konzentrieren><de> Jetzt kann ich mich also wieder auf den Kampf mit dem Wetter konzentrieren.
<G-vec00859-002-s305><concentrate.konzentrieren><en> My thoughts, nerves and even mood evened out and I found it way easier to concentrate on the tasks at hand.
<G-vec00859-002-s305><concentrate.konzentrieren><de> Meine Gedanken, Nerven und sogar meine Stimmung pendelten sich ein und ich fand es viel einfacher, mich auf die vorhandenen Aufgaben zu konzentrieren.
<G-vec00859-002-s306><concentrate.konzentrieren><en> I couldn't concentrate on those things any longer because it hurt enough that it was distracting me.
<G-vec00859-002-s306><concentrate.konzentrieren><de> Ich konnte mich nicht länger auf jene Dinge konzentrieren, weil es genug weh tat, dass es mich ablenkte.
<G-vec00859-002-s307><concentrate.konzentrieren><en> As I am concerned with theatricality and public space, I will concentrate on examples of a theatrical re-staging of the founding moment of antagonism.
<G-vec00859-002-s307><concentrate.konzentrieren><de> Da wir hier mit Theatralizität und Öffentlichkeit beschäftigt sind, werde ich mich auf Beispiele theatraler Wiederinszenierung des gründenden Moments des Antagonismus konzentrieren.
<G-vec00859-002-s308><concentrate.konzentrieren><en> Then the priest asked me to close my eyes and concentrate.
<G-vec00859-002-s308><concentrate.konzentrieren><de> Dann bat er mich, meine Augen zu schließen und mich zu konzentrieren.
<G-vec00859-002-s309><concentrate.konzentrieren><en> I have discussed the LBP extensively in my two previous articles, so that I will concentrate here on the new energies that are flooding earth and humanity since the opening of the stargate 11.11.11 with our help and are now contributing decisively to the acceleration of the LBP in all incarnated human beings.
<G-vec00859-002-s309><concentrate.konzentrieren><de> Ich habe den LKP in meinen beiden vorangegangenen Artikeln ausführlich diskutiert, so dass ich mich hier auf die neuen Energien konzentrieren werde, welche die Erde und die Menschheit seit der Öffnung des Sternentors 11.11.11 mit unserer Hilfe überfluten und nun entscheidend zur Beschleunigung des LKP in allen inkarnierten Menschen beitragen.
<G-vec00859-002-s310><concentrate.konzentrieren><en> I need to concentrate.
<G-vec00859-002-s310><concentrate.konzentrieren><de> Ich muss mich konzentrieren.
<G-vec00859-002-s311><concentrate.konzentrieren><en> It helps me to concentrate during phone calls and meetings.
<G-vec00859-002-s311><concentrate.konzentrieren><de> Das hilft mir, mich zu konzentrieren.
<G-vec00859-002-s312><concentrate.konzentrieren><en> I’m usually a bit obsessive about counting steps but somehow I couldn’t concentrate anymore.
<G-vec00859-002-s312><concentrate.konzentrieren><de> Ich bin ja eigentlich ein obsessiver Treppenstufenzähler, aber ich konnte mich nicht mehr konzentrieren.
<G-vec00859-002-s313><concentrate.konzentrieren><en> I did earn some quite good bucks with it, but because of my other business ventures, wasn’t able to concentrate on using it with full capacity.
<G-vec00859-002-s313><concentrate.konzentrieren><de> Ich habe ein bisschen Geld damit verdient, aber durch meine anderen Pflichten, konnte ich mich nicht nur auf diesen Bot konzentrieren.
<G-vec00859-002-s314><concentrate.konzentrieren><en> As they are the only thing visible, I have virtually no other choice than to concentrate on the scene.
<G-vec00859-002-s314><concentrate.konzentrieren><de> So bleibt mir gar nichts anderes übrig, als mich auf diese Szene zu konzentrieren.
<G-vec00859-002-s315><concentrate.konzentrieren><en> You have to continue to network, you cannot rest your mind, hide yourself, and concentrate only on your book for the next few hours.
<G-vec00859-002-s315><concentrate.konzentrieren><de> Ich muss vernetzt bleiben, ich kann nicht abschalten, mich verstecken und mich nur auf das Buch konzentrieren für die nächsten paar Stunden.
<G-vec00859-002-s371><concentrate.konzentrieren><en> We provide a worry-free package, as a full-service provider, so that you can fully concentrate on your core business. Visit our website Thermal Management Services Imprint
<G-vec00859-002-s371><concentrate.konzentrieren><de> Als Full-Service-Anbieter erhalten Sie von uns ein Rundum-Paket, damit Sie sich ganz auf Ihr Kerngeschäft, die sichere und pünktliche Beförderung von Personen und Waren, konzentrieren können.
<G-vec00859-002-s372><concentrate.konzentrieren><en> He will concentrate on key relationships with ultra high net worth individuals in Switzerland and select international markets, and support the ongoing expansion of that business.
<G-vec00859-002-s372><concentrate.konzentrieren><de> Er wird sich auf Schlüsselbeziehungen zu sehr vermögenden Kunden in der Schweiz und in ausgewählten internationalen Märkten konzentrieren und den weiteren Ausbau dieses Geschäfts unterstützen.
<G-vec00859-002-s373><concentrate.konzentrieren><en> The user has to put it on and is then asked to concentrate his attention on a flame placed in front of him or her.
<G-vec00859-002-s373><concentrate.konzentrieren><de> Der/die BesucherIn setzt diese Vorrichtung auf und muss sich dann auf eine vor ihm/ihr platzierte Flamme konzentrieren.
<G-vec00859-002-s374><concentrate.konzentrieren><en> Forne had to force his raging emotions down to concentrate on the here and now.
<G-vec00859-002-s374><concentrate.konzentrieren><de> Forne zwang seine tobenden Emotionen nieder, um sich auf das hier und jetzt zu konzentrieren.
<G-vec00859-002-s375><concentrate.konzentrieren><en> The volunteers, as a result, can concentrate entirely on their activities.
<G-vec00859-002-s375><concentrate.konzentrieren><de> Die Ehrenamtlichen können sich so ganz auf ihre Aktivitäten konzentrieren.
<G-vec00859-002-s376><concentrate.konzentrieren><en> He who cleans too methodically, assuming this methodology requires a certain amount of mental concentration, finds it hard to concentrate on the program.
<G-vec00859-002-s376><concentrate.konzentrieren><de> Wer zu methodisch putzt, solange diese Methodik einen gewissen Geistesaufwand benötigt, kann sich schwer auf die Sendung konzentrieren.
<G-vec00859-002-s377><concentrate.konzentrieren><en> A large German employment agency wanted to concentrate exclusively on its core business and outsource the service desk to a specialist.
<G-vec00859-002-s377><concentrate.konzentrieren><de> Ein großer deutscher Arbeitsvermittler wollte sich ausschließlich auf sein Kerngeschäft konzentrieren und den Service Desk an einen Spezialisten auslagern.
<G-vec00859-002-s379><concentrate.konzentrieren><en> Travelers can concentrate now to the usual threats and don’t need to watch for mass of madness mummies behind each tree.
<G-vec00859-002-s379><concentrate.konzentrieren><de> Der Reisende kann sich jetzt wieder auf die üblichen Bedrohungen konzentrieren und muss nicht mehr damit rechnen, dass hinter jedem Baum eine verrückte Mumie lauert.
<G-vec00859-002-s380><concentrate.konzentrieren><en> Absolutely annoying, however is the background music which in parts is waaaaay to loud - to the point where you have to concentrate on what Adam is saying....
<G-vec00859-002-s380><concentrate.konzentrieren><de> Absolut nervig hingegen ist die Hintergrundmusik, die in Teilen so laut ist, dass man sich auf das, was Adam so erzahlt schon sehr konzentrieren muss.
<G-vec00859-002-s381><concentrate.konzentrieren><en> A professional management team takes care of long-term, reliable quality on site, while a highly developed IT infrastructure and competent full-service solutions, such as interior design, IT and facility services, enable the companies based here to concentrate on their core business.
<G-vec00859-002-s381><concentrate.konzentrieren><de> Ein professionelles Management-Team sorgt für eine langfristige und zuverlässige Qualität am Standort, während eine hochentwickelte IT-Infrastruktur und kompetente Full Service-Leistungen, wie Raumgestaltung, IT- und Facility-Services es den ansässiges Unternehmen ermöglichen, sich auf ihr Kerngeschäft zu konzentrieren.
<G-vec00859-002-s382><concentrate.konzentrieren><en> When the airlines gradually increase their offerings again, they will concentrate on the lucrative routes with high margins.
<G-vec00859-002-s382><concentrate.konzentrieren><de> Wenn die Airlines ihr Angebot nach und nach wieder hochfahren, werden sie sich auf die lukrativen Strecken mit hohen Margen konzentrieren.
<G-vec00859-002-s383><concentrate.konzentrieren><en> Noise can also affect performance when carrying out difficult assignments due to inability to concentrate.
<G-vec00859-002-s383><concentrate.konzentrieren><de> Lärm kann auch die Leistung beim Ausführen schwieriger Aufgaben beeinträchtigen, weil man sich nicht konzentrieren kann.
<G-vec00859-002-s384><concentrate.konzentrieren><en> Combined with intuitive point and click flight planning and automatic anti-collision systems managed by artificial intelligence, allows the remote operator to concentrate on the mission at hand.
<G-vec00859-002-s384><concentrate.konzentrieren><de> In Kombination mit intuitiver Point-and-Click-Flugplanung und automatischen, durch künstliche Intelligenz gesteuerten Kollisionsschutzsystemen kann der Remote-Benutzer sich auf die vor ihm liegende Mission konzentrieren.
<G-vec00859-002-s385><concentrate.konzentrieren><en> Because of the calm sea and the peace around one, one could concentrate all the more on the sky with its millions of shades of grey.
<G-vec00859-002-s385><concentrate.konzentrieren><de> Wegen der stillen See und der Ruhe um einen herum konnte man sich um so mehr auf den Himmel mit seinen Millionen von Schattierungen von Grau konzentrieren.
<G-vec00859-002-s386><concentrate.konzentrieren><en> You delve into nature, and because you have to concentrate much on the course, you strike up a deeper relationship with your surroundings.
<G-vec00859-002-s386><concentrate.konzentrieren><de> Man taucht ein in die Natur und weil man sich auf die Strecke viel mehr konzentrieren muss, geht man eine tiefere Beziehung mit der Umgebung ein.
<G-vec00859-002-s387><concentrate.konzentrieren><en> So that you can fully concentrate on your conference, we offer you our Superior Conference Package for 10 or more persons.
<G-vec00859-002-s387><concentrate.konzentrieren><de> Damit Sie sich optimal auf Ihre Konferenz konzentrieren können, bieten wir Ihnen bereits ab einer Teilnehmerzahl von 10 Personen unsere Superior Tagungspauschale an.
<G-vec00859-002-s388><concentrate.konzentrieren><en> The previous mother company of TechniSat Automotive, TechniSat Digital GmbH from Daun, will concentrate immediately on the business division “Consumer Electronics” and develop this field of business independently.
<G-vec00859-002-s388><concentrate.konzentrieren><de> Die bisherige Muttergesellschaft von TechniSat Automotive, die TechniSat Digital GmbH aus Daun, wird sich ab sofort auf den Geschäftsbereich „Consumer Electronics“ konzentrieren und dieses Geschäftsfeld eigenständig weiterentwickeln.
<G-vec00859-002-s389><concentrate.konzentrieren><en> With all the pre-exhibition stress, he had to concentrate on what was essential.
<G-vec00859-002-s389><concentrate.konzentrieren><de> Im Vormessestress musste auch er sich auf das Wesentliche konzentrieren.
<G-vec00859-002-s390><concentrate.konzentrieren><en> The name should cause the dog to concentrate on the owner, and the team "to me" - to approach.
<G-vec00859-002-s390><concentrate.konzentrieren><de> Der Name sollte dazu führen, dass sich der Hund auf den Besitzer konzentriert und das Team "zu mir" - zu kommen.
<G-vec00859-002-s391><concentrate.konzentrieren><en> From now on, Geistlich Pharma PTY Ltd. will supply and serve specialists in oral hard and soft tissue regeneration, whereas Henry Schein as the distribution partner will concentrate on the general dental practitioners.
<G-vec00859-002-s391><concentrate.konzentrieren><de> Künftig beliefert und betreut Geistlich Pharma PTY Ltd. Spezialisten der Hart- und Weichgeweberegeneration, während sich Henry Schein als Distributionspartner auf allgemein praktizierende Zahnärzte konzentriert.
<G-vec00859-002-s392><concentrate.konzentrieren><en> Better results can be achieved if you concentrate on the essential issues.
<G-vec00859-002-s392><concentrate.konzentrieren><de> Bessere Ergebnisse kann man dann erzielen, wenn man sich auf das Wesentliche konzentriert.
<G-vec00859-002-s393><concentrate.konzentrieren><en> If you concentrate on one of them you will automatically jeopardise the achievement of the others.
<G-vec00859-002-s393><concentrate.konzentrieren><de> Wer sich auf eines konzentriert, benachteiligt naturgemäß die Erreichbarkeit der anderen.
<G-vec00859-002-s394><concentrate.konzentrieren><en> The Full Moon accelerates plant growth, so plants grow more vigorously during this time. The gravitational force of the moon also makes the sap move upwards and concentrate in their leaves, buds and upper parts, leaving the roots energy-deprived.
<G-vec00859-002-s394><concentrate.konzentrieren><de> Doch Vollmond sorgt nicht nur dafür, dass sie stärker wachsen; die Gravitationskraft des Mondes lässt den Saft eurer Pflanzen nach oben strömen, wobei er sich in den Blättern, Buds und höheren Teilen konzentriert und die Energie aus den Wurzeln schwindet.
<G-vec00859-002-s395><concentrate.konzentrieren><en> The vicious circle of violence can be broken by healing justice which does not concentrate exclusively on the punishment of the perpetrator alone, necessary as it is, but supports the victims of violence and their families and makes efforts to combat the causes of violent crimes.
<G-vec00859-002-s395><concentrate.konzentrieren><de> Eine heilende Gerechtigkeit, die sich nicht auf die notwendige Bestrafung der Täter allein konzentriert, sondern Opfer von Gewalttaten und deren Angehörige unterstützt und sich für die Bekämpfung der Ursachen von Gewaltverbrechen einsetzt, kann dagegen den Teufelskreis der Gewalt durchbrechen.
<G-vec00859-002-s396><concentrate.konzentrieren><en> Partial successes are most common, if one does not concentrate exactly.
<G-vec00859-002-s396><concentrate.konzentrieren><de> Teilerfolge sind am häufigsten, wenn man sich nicht genau konzentriert..
<G-vec00859-002-s397><concentrate.konzentrieren><en> While these Japanese giants (they are the fifth largest games company in the world) still concentrate on software titles for PCs and consoles, they are responsible for a handful of popular pokie games, including Rocky, Money in the Bank and Lucky Dice.
<G-vec00859-002-s397><concentrate.konzentrieren><de> Obwohl dieser japanische Riese (es ist das fünftgrößte Spiele-Unternehmen der Welt) sich noch immer auf Software-Titel für PCs und Konsolen konzentriert, ist die Firma für eine Handvoll beliebter Slots-Spiele verantwortlich, einschließlich Rocky, Money in the Bank und Lucky Dice.
<G-vec00859-002-s398><concentrate.konzentrieren><en> Memories only seem to be colourful at first; the more you concentrate, the paler their tinting becomes, until at last they fade to black and white, or vanish altogether.
<G-vec00859-002-s398><concentrate.konzentrieren><de> Erinnerungen erscheinen zunächst farbig zu sein, aber je stärker man sich auf sie konzentriert, umso blasser wird das Kolorit, bis es umschlägt in Schwarzweiss oder das Bild völlig verschwindet.
<G-vec00859-002-s399><concentrate.konzentrieren><en> The role of the poster is of indispensable value in postmodern times whose overwhelming flood of images tends to make people confused, as posters concentrate on only essential information.
<G-vec00859-002-s399><concentrate.konzentrieren><de> Gerade angesichts der überbordenden Bilderflut der Postmoderne, die dazu führt, dass der Mensch den Überblick verliert, ist das Plakat, das sich auf das Wesentliche konzentriert, von unverzichtbarem Wert.
<G-vec00859-002-s400><concentrate.konzentrieren><en> It is no coincidence that Morrison does not wish to be a design hero, wants as a person to remain low key and prefers to concentrate on his work than on communicating it.
<G-vec00859-002-s400><concentrate.konzentrieren><de> Dass Morrison kein Held des Designs sein möchte, sich entsprechend als Person zurücknimmt und sich lieber auf die eigene Arbeit als auf deren Kommunikation konzentriert, kommt nicht von ungefähr.
<G-vec00859-002-s401><concentrate.konzentrieren><en> We really tried to aim for something more dynamic that would concentrate on the combat.
<G-vec00859-002-s401><concentrate.konzentrieren><de> Wir haben versucht, etwas Dynamischeres zu schaffen, das sich völlig auf den Kampf konzentriert.
<G-vec00859-002-s402><concentrate.konzentrieren><en> Since there are many plants that suit the white-tailed bumblebee with its short mouth parts, a conclusion could be that the species does not concentrate on a few nectar plants but visits many flowers, exploring and pollinating them.
<G-vec00859-002-s402><concentrate.konzentrieren><de> Weil es viele Pflanzen gibt, die der hellgelben Erdhummel mit ihrem kurzen Mundwerkzeug gelegen kommen, könnte der Schluss gezogen werden, dass sich die Art nicht auf einige wenige Nektarpflanzen konzentriert, sondern viele Blumen besucht, sie erkundet und bestäubt.
<G-vec00859-002-s403><concentrate.konzentrieren><en> Our presence here today very clearly expresses our sincere desire to remove all the ecclesial obstacles that are not dogmatic or essential, so that we may concentrate our concern on the study of the essential differences and dogmatic truths that have divided our Churches until now, as well as on the way of living the Christian truth of the united Church.
<G-vec00859-002-s403><concentrate.konzentrieren><de> Unsere heutige Anwesenheit hier drückt in aller Deutlichkeit unser aufrichtiges Verlangen nach der Überwindung aller kirchlichen Hindernisse aus, die nicht dogmatischer und wesensmäßiger Natur sind, damit sich unser Interesse auf das Studium der wesentlichen Unterschiede und der dogmatischen Wahrheiten konzentriert, die bis heute unseren Kirchen gemeinsam sind, sowie auf die Art und Weise, die christliche Wahrheit der geeinten Kirche zu leben.
<G-vec00859-002-s404><concentrate.konzentrieren><en> The focus areas of Ecofys and Wageningen University complement each other ideally: while Ecofys will provide expert knowledge of the UN climate negotiations and policies in the energy sector, Wageningen University will concentrate on non-CO2 emissions and forestry.
<G-vec00859-002-s404><concentrate.konzentrieren><de> Die Kernkompetenzen von Ecofys und der Universität ergänzen sich dabei ideal: Ecofys wird vor allem Fachwissen zu den UN Klimaverhandlungen und Politiken im Energiesektor beisteuern, während die Universität Wageningen sich auf nicht-CO2 Emissionen und Forstwirtschaft konzentriert.
<G-vec00859-002-s405><concentrate.konzentrieren><en> He spoke slowly, and so quietly that one had to concentrate to hear him in the noisy canteen.
<G-vec00859-002-s405><concentrate.konzentrieren><de> Er sprach langsam und so leise vor sich hin, dass man ihm in der lauten Kantine, konzentriert zuhören musste, um mitzukommen.
<G-vec00859-002-s406><concentrate.konzentrieren><en> Increasingly it seems that a company concentrate solely on the speed of the new mounter that should be purchased.
<G-vec00859-002-s406><concentrate.konzentrieren><de> Es kann vorkommen, dass sich eine Firma ausschließlich auf die Geschwindigkeit des neu zu erwerbenden Bestückers konzentriert.
<G-vec00859-002-s407><concentrate.konzentrieren><en> In 2012 NIVELCO Process Control Co. celebrates its 30th anniversary. On this occasion NIVELCO Company profile 2012 is launched to introduce the company founded in 1982 to concentrate on the manufacture of industrial level measurement and control products.
<G-vec00859-002-s407><concentrate.konzentrieren><de> Anlässlich dieser Gelegenheit bringen wir das NIVELCO Firmenprofil 2012 heraus um die Firma, die 1982 gegründet wurde und sich auf die Entwicklung und Herstellung von Füllstandmess- und Regelgeräten konzentriert, vorzustellen.
<G-vec00859-002-s430><concentrate.konzentrieren><en> The bankers wish us to forget all this and concentrate on the urgency of saving the banks.
<G-vec00859-002-s430><concentrate.konzentrieren><de> Nun wollen all die Banken, dass wir dies mal eben vergessen und uns auf die Dringlichkeit der Rettung der Banken konzentrieren.
<G-vec00859-002-s431><concentrate.konzentrieren><en> Geoff Simmonds enthuses: “Thanks to our collaboration with Linde, we can concentrate on what is really important to us, and don’t have to worry about things outside of our core business.”
<G-vec00859-002-s431><concentrate.konzentrieren><de> Geoff Simmonds ist begeistert: Durch die Zusammenarbeit mit Linde können wir uns auf das konzentrieren, was wirklich wichtig ist und müssen uns nicht mehr über Dinge den Kopf zerbrechen, die nicht zu unserem Kerngeschäft gehören.
<G-vec00859-002-s432><concentrate.konzentrieren><en> But more importantly we were taught the importance of a clear mind bereft of unsavoury thoughts and ability to concentrate.
<G-vec00859-002-s432><concentrate.konzentrieren><de> Als viel wichtiger wurde uns der Wert eines klaren Geistes ohne schwer verdauliche Gedanken beigebracht und die Fähigkeit, uns zu konzentrieren.
<G-vec00859-002-s433><concentrate.konzentrieren><en> As a leading provider of professional German translations, we will concentrate on what we do best, allowing you to do what you do best.
<G-vec00859-002-s433><concentrate.konzentrieren><de> Als führender Anbieter von professionellen Übersetzungen in die und aus der deutschen Sprache werden wir uns auf das konzentrieren, was wir am besten können, damit Sie das tun können, was Sie am besten können.
<G-vec00859-002-s434><concentrate.konzentrieren><en> That, therefore, is precisely what we should now concentrate on.
<G-vec00859-002-s434><concentrate.konzentrieren><de> Genau darauf sollten wir uns deshalb jetzt auch konzentrieren.
<G-vec00859-002-s435><concentrate.konzentrieren><en> In addition to the characteristics mentioned already – to persevere and stay the course – we were given particular advice regarding financing. We were advised to not concentrate too much on our own shares in the beginning, and to collect as much investment capital as possible instead.
<G-vec00859-002-s435><concentrate.konzentrieren><de> Neben der bereits erwähnten Eigenschaft, beharrlich zu bleiben und durchzuhalten, wurde uns insbesondere zum Thema Finanzierung geraten, uns am Anfang nicht zu sehr auf die eigenen Anteile zu konzentrieren, sondern alles Investitionskapital mitzunehmen, das wir kriegen können.
<G-vec00859-002-s436><concentrate.konzentrieren><en> We need to concentrate instead on that part of our mission which is still ahead of us, yet to be fulfilled. 3.
<G-vec00859-002-s436><concentrate.konzentrieren><de> Wir müssen uns auf den Teil unseres Auftrags konzentrieren, der noch vor uns liegt, statt auf den, der schon ausgeführt worden ist.
<G-vec00859-002-s437><concentrate.konzentrieren><en> Only by differentiation, thus distinguishing what is important and what is not, we can concentrate on the essentials and are able to act.
<G-vec00859-002-s437><concentrate.konzentrieren><de> Erst indem wir differenzieren, also unterscheiden, was wichtig und was unwichtig ist, können wir uns auf das Wesentliche konzentrieren und werden dadurch handlungsfähig.
<G-vec00859-002-s438><concentrate.konzentrieren><en> Our strategic focus means we concentrate on issues of long-term, sustainable development of firms, both shaping and being shaped by their (economic, social, and natural) environment.
<G-vec00859-002-s438><concentrate.konzentrieren><de> Unser strategischer Fokus bedeutet, dass wir uns auf die langfristige und nachhaltige Entwicklung von Unternehmen konzentrieren, die von ihrer (ökonomischen, sozialen und natürlichen) Umwelt beeinflusst werden als auch diese selbst beeinflussen.
<G-vec00859-002-s439><concentrate.konzentrieren><en> There is single-pointed meditation like for instance, Vipassana or Zen meditation where we concentrate on one point (e.g., an object or the breath) without letting our minds wander.
<G-vec00859-002-s439><concentrate.konzentrieren><de> Es gibt einsgerichtete Meditation, wie zum Beispiel Vipassana- oder Zen-Meditation, bei denen wir uns auf einen Punkt (zum Beispiel ein Gegenstand oder den Atem) konzentrieren, ohne den Geist abschweifen zu lassen.
<G-vec00859-002-s440><concentrate.konzentrieren><en> Cigar wooden box is the cigar accessores, and we never leave the cigar box when we are concentrate on cigars,
<G-vec00859-002-s440><concentrate.konzentrieren><de> Zigarrenholzkiste ist der Zugang zu Zigarren, und wir verlassen die Zigarrenschachtel niemals, wenn wir uns auf Zigarren konzentrieren.
<G-vec00859-002-s441><concentrate.konzentrieren><en> Since we have previously discussed the different types of stereo microscope, we will now concentrate on the different types of mono, compound microscopes.
<G-vec00859-002-s441><concentrate.konzentrieren><de> Da wir die unterschiedlichen Stereomikroskoptypen bereits eingehend besprochen haben, werden wir uns nun auf die verschiedenen Mono, Compound Mikroskope konzentrieren.
<G-vec00859-002-s442><concentrate.konzentrieren><en> Due to its widespread popularity and ease of use, in the rest of this activity we will concentrate specifically on Skype, although much of the general information is also relevant for the other audio-conferencing tools.
<G-vec00859-002-s442><concentrate.konzentrieren><de> Infolge ihrer weitverbreiteten Popularität und einfachen Benutzung werden wir uns in dem restlichen Teil dieser Aktivität speziell auf Skype konzentrieren, obwohl der größte Teil der generellen Informationen auch für andere Audio-Konferenz-Tools relevant ist.
<G-vec00859-002-s443><concentrate.konzentrieren><en> We want to concentrate on what the customer really needs.
<G-vec00859-002-s443><concentrate.konzentrieren><de> Wir wollen uns auf das konzentrieren, was der Kunde wirklich braucht.
<G-vec00859-002-s444><concentrate.konzentrieren><en> "In the years to come, we want to concentrate even more strongly on the central future topics of the automotive industry," explains HELLA CEO Dr. Rolf Breidenbach.
<G-vec00859-002-s444><concentrate.konzentrieren><de> "Wir wollen uns zukünftig noch stärker auf die zentralen Zukunftsthemen der Automobilbranche konzentrieren", sagt Dr. Rolf Breidenbach, Vorsitzender der HELLA Geschäftsführung.
<G-vec00859-002-s445><concentrate.konzentrieren><en> We will review each site, making sure to concentrate on factors that are important to a player.
<G-vec00859-002-s445><concentrate.konzentrieren><de> Wir bewerten jede Website, wobei wir darauf achten, dass wir uns auf jene für Spieler wichtige Faktoren konzentrieren.
<G-vec00859-002-s446><concentrate.konzentrieren><en> Ever since the beginning of the fighting – meaning any fighting in the last years, but let's concentrate on the recent escalation of violence between Israel and Hamas in Gaza – all major TV channels in Israel switch their normal programming to 24-hour "special" news programs, and in the "special" news programs we get a loop of recent pictures: grainy rockets move through a night sky, a hole in the ceiling of a hit house, a group of reserve soldiers lazying around, waiting for instructions.
<G-vec00859-002-s446><concentrate.konzentrieren><de> Seit Beginn der Kämpfe – eigentlich aller Kämpfe der vergangenen Jahre –, doch wir wollen uns auf die aktuelle Gewalteskalation zwischen Hamas und Gaza konzentrieren – haben alle großen TV-Sender ihr normales Programm durch ein 24-Stunden "Sonder"-Nachrichtenprogramm ersetzt, welches in Dauerschleife die aktuellsten Bilder liefert: eine über den Nachthimmel fliegende Rakete, ein Loch im Dach eines getroffenen Hauses, eine Gruppe träge herumsitzender und auf Instruktionen wartender Reservesoldaten.
<G-vec00859-002-s447><concentrate.konzentrieren><en> In the future, we will concentrate more strongly on what we do best and continue to develop Jenoptik to a focused photonics company.
<G-vec00859-002-s447><concentrate.konzentrieren><de> Wir wollen uns künftig noch stärker auf das konzentrieren, was wir am besten können und so die Jenoptik zu einem fokussierten Photonik-Konzern weiterentwickeln.
<G-vec00859-002-s448><concentrate.konzentrieren><en> The effect of this is similar to rebooting a computer: If the activity of the prefrontal cortex is temporarily shut down, we can concentrate better during the movement and think more clearly afterwards.
<G-vec00859-002-s448><concentrate.konzentrieren><de> Die Wirkung dessen ist ähnlich einem Neustart bei einem Computer: Wird die Aktivität des präfrontalen Cortex zeitweise runtergefahren, können wir uns danach besser konzentrieren und klarer denken.
<G-vec00859-002-s087><concentrate.sich_fokussieren><en> “In light of our free cash flow generation, our efforts in 2018 will initially concentrate on measures which can be implemented quickly and will not cause major one-off costs,” explains Ute Wolf, CFO of Evonik.
<G-vec00859-002-s087><concentrate.sich_fokussieren><de> „Auch mit Blick auf unsere Free Cashflow-Generierung fokussieren wir uns im Jahr 2018 zunächst auf Maßnahmen, die wir schnell umsetzen können und die keine hohen Einmalkosten verursachen“, erläutert Ute Wolf, Finanzchefin von Evonik.
<G-vec00859-002-s088><concentrate.sich_fokussieren><en> We are active in private banking and concentrate fully on our core business of investment advisory and asset management.
<G-vec00859-002-s088><concentrate.sich_fokussieren><de> Wir sind im Private Banking tätig und fokussieren uns auf unsere Kernkompetenzen in der Anlageberatung und Vermögensverwaltung.
<G-vec00859-002-s089><concentrate.sich_fokussieren><en> As well as the fundamental principles and tools of business management, we concentrate specifically on subjects relevant to industry: processes and process management, logistics and supply chain management, financial controlling and management accounting, as well as customer orientation and marketing.
<G-vec00859-002-s089><concentrate.sich_fokussieren><de> Neben allen grundlegenden Konzepten und Instrumenten der Betriebswirtschaft fokussieren wir uns speziell auf die industrierelevanten Themen: Prozesse und deren Optimierung (Prozessmanagement), Logistik und Supply Chain Management, Controlling und Führen mit Zahlen sowie Kundenorientierung und Marketing.
<G-vec00859-002-s090><concentrate.sich_fokussieren><en> We concentrate on what really matters: results.
<G-vec00859-002-s090><concentrate.sich_fokussieren><de> Wir fokussieren uns auf das, was zählt: Ergebnisse.
<G-vec00859-002-s091><concentrate.sich_fokussieren><en> As a leading investment advisor, we concentrate exclusively on investments in wind and solar parks.
<G-vec00859-002-s091><concentrate.sich_fokussieren><de> Als führender auf Nachhaltigkeit spezialisierter Berater fokussieren wir uns ausschließlich auf Investitionen in Wind- und Solarparks.
<G-vec00859-002-s092><concentrate.sich_fokussieren><en> That’s why we concentrate on what our clients really need to be successful.
<G-vec00859-002-s092><concentrate.sich_fokussieren><de> Deshalb fokussieren wir uns auf das, was unsere Kunden wirklich brauchen, um erfolgreich zu sein.
<G-vec00859-002-s068><concentrate.sich_konzentrieren><en> If you've found the cause of the problem, you only need to concentrate on the solution.
<G-vec00859-002-s068><concentrate.sich_konzentrieren><de> Wenn du die Ursache für das Problem gefunden hast, musst du dich nur noch auf die Lösung konzentrieren.
<G-vec00859-002-s069><concentrate.sich_konzentrieren><en> Whether on easy terrain, on forest tracks or in town, this versatile eBike allows you to fully concentrate on enjoying your biking experience with the support of the sporty Bosch Performance CX motor.
<G-vec00859-002-s069><concentrate.sich_konzentrieren><de> Reservieren Details Ob in sanftem Gelände, auf Waldwegen oder in der Stadt, mit diesem vielseitigen Trekking eBike kannst Du Dich ganz auf den Fahrspaß konzentrieren.
<G-vec00859-002-s070><concentrate.sich_konzentrieren><en> If you’ve ever tried to concentrate when your nose won’t stop running or your eyes are streaming, you will know how difficult it can be.
<G-vec00859-002-s070><concentrate.sich_konzentrieren><de> Wenn Du jemals versucht hast, Dich zu konzentrieren, während Deine Nase nicht aufhört zu laufen oder Deine Augen tränen, wirst Du wissen, wie schwierig es sein kann.
<G-vec00859-002-s071><concentrate.sich_konzentrieren><en> The two included cable guides keep the cable securely on the headband during jogging tours or rough MTB rides, so that you can fully concentrate on the track ahead.
<G-vec00859-002-s071><concentrate.sich_konzentrieren><de> Die beiden mitgelieferten Kabelführungen halten die Stromverbindungen beim Joggen und bei ruppigen Fahrten mit dem MTB sicher am Kopfband, damit sie nicht störend mitschwingen und du dich voll auf die Strecke konzentrieren kannst.
<G-vec00859-002-s072><concentrate.sich_konzentrieren><en> Add to cart Add a White ambiance downlight with warm white to cool daylight to help you relax, read, concentrate, or energize.
<G-vec00859-002-s072><concentrate.sich_konzentrieren><de> Nutze einen White Ambiance Spot mit warmweißem bis tageslichtweißem Licht, damit Du besser entspannen, lesen, Dich konzentrieren oder mit frischer Energie aufladen kannst.
<G-vec00859-002-s073><concentrate.sich_konzentrieren><en> Last but not least, our work models provide you with ample time to concentrate on your studies parallel to your work – and in between to broaden your horizon with travel and semesters abroad.
<G-vec00859-002-s073><concentrate.sich_konzentrieren><de> Last but not least, geben Dir unsere flexiblen Modelle ausreichend Freiraum, um Dich parallel auf Dein Studium zu konzentrieren – und zwischendurch im Urlaub oder Auslandssemester Deinen Horizont zu erweitern.
<G-vec00859-002-s074><concentrate.sich_konzentrieren><en> I have said that we are always with you and it is true, but to feel it you must draw back from your vital and be able to concentrate in your inner being.
<G-vec00859-002-s074><concentrate.sich_konzentrieren><de> Ich habe gesagt, dass wir immer bei dir sind, und das ist wahr; um es aber zu fühlen, musst du dich von deinem Vital zurückziehen und in der Lage sein, dich in deinem inneren Wesen zu konzentrieren.
<G-vec00859-002-s075><concentrate.sich_konzentrieren><en> The upper material provides good ventilation so that your foot does not overheat and you can concentrate fully on your run.
<G-vec00859-002-s075><concentrate.sich_konzentrieren><de> Das Obermaterial sorgt für eine gute Belüftung damit dein Fuß nicht überhitzt und du dich voll auf deinen Lauf konzentrieren kannst.
<G-vec00859-002-s076><concentrate.sich_konzentrieren><en> Comfort and maximal freedom of movement so you can fully concentrate on your workout and give your all.
<G-vec00859-002-s076><concentrate.sich_konzentrieren><de> So kannst du dich ganz auf dein Workout konzentrieren und das Maximum aus dir rausholen.
<G-vec00859-002-s077><concentrate.sich_konzentrieren><en> The ab straps support your elbows and take the pressure off your shoulders and arms, so you can concentrate fully on the abs workout.
<G-vec00859-002-s077><concentrate.sich_konzentrieren><de> Die Bauchtrainingsschlaufen stützen dabei deine Ellenbogen und nehmen dir den Druck von den Schultern und Armen, sodass du dich vollends auf das Bauchtraining konzentrieren kannst.
<G-vec00859-002-s078><concentrate.sich_konzentrieren><en> With the S.Light 30 Zip-on from ABS you can fully concentrate on your turns in deep snow.
<G-vec00859-002-s078><concentrate.sich_konzentrieren><de> Mit dem S.Light 30 Zip-on von ABS kannst Du Dich voll auf deine Turns im Tiefschnee konzentrieren.
<G-vec00859-002-s079><concentrate.sich_konzentrieren><en> It makes you feel sleepy and foggy, it can give you headaches and make it difficult to concentrate.
<G-vec00859-002-s079><concentrate.sich_konzentrieren><de> Es macht dich schläfrig und benebelt, es kann Kopfschmerzen verursachen und es schwierig für dich machen, dich zu konzentrieren.
<G-vec00859-002-s080><concentrate.sich_konzentrieren><en> Just a day or two to assess and concentrate.
<G-vec00859-002-s080><concentrate.sich_konzentrieren><de> Nur einen Tag oder zwei, um eine Bestandsaufnahme zu machen und dich zu konzentrieren.
<G-vec00859-002-s081><concentrate.sich_konzentrieren><en> Thanks to the hood, you can isolate yourself from the world and concentrate fully on skating; It also keeps you warm and reliably protects against wind.
<G-vec00859-002-s081><concentrate.sich_konzentrieren><de> Dank der Kapuze bist du von der Welt abgeschottet und kannst dich ganz aufs Rollen konzentrieren; zudem hält sie warm und schützt zuverlässig vor Wind.
<G-vec00859-002-s082><concentrate.sich_konzentrieren><en> You must concentrate hard, like me.
<G-vec00859-002-s082><concentrate.sich_konzentrieren><de> Du mußt dich konzentrieren, wie ich.
<G-vec00859-002-s083><concentrate.sich_konzentrieren><en> As a crowdfunding platform provider, you should be able to concentrate on your tasks in business development and target group marketing.
<G-vec00859-002-s083><concentrate.sich_konzentrieren><de> Als Crowdfunding Plattform Anbieter sollst Du Dich auf Deine Aufgaben im Business Development und im Zielgruppenmarketing konzentrieren können.
<G-vec00859-002-s084><concentrate.sich_konzentrieren><en> At this point, your project working directory is exactly the way it was before you started working on issue #53, and you can concentrate on your hotfix.
<G-vec00859-002-s084><concentrate.sich_konzentrieren><de> Zu diesem Zeitpunkt befindet sich das Arbeitsverzeichnis des Projektes in exakt dem gleichen Zustand, in dem es sich befand, als Du mit der Arbeit an Issue #53 begonnen hast und Du kannst Dich direkt auf Deinen Hotfix konzentrieren.
<G-vec00859-002-s085><concentrate.sich_konzentrieren><en> This can make it difficult to concentrate on studying.
<G-vec00859-002-s085><concentrate.sich_konzentrieren><de> Das kann es dir erschweren, dich auf das Lernen zu konzentrieren.
<G-vec00859-002-s086><concentrate.sich_konzentrieren><en> It doesn’t matter how often or how long you’re lost in thought, because it’s just important that you recognize it and then concentrate on your breath again.
<G-vec00859-002-s086><concentrate.sich_konzentrieren><de> Es ist egal wie oft und wie lange du in deine Gedanken versunken bist, denn es ist wichtig, dass du es bemerkst und dich dann wieder auf deinen Atem zu konzentrieren.
<G-vec00859-002-s174><concentrate.sich_konzentrieren><en> After chanting OM concentrate for a few minutes on your body and be conscious of your existence in its entirety - physically, mentally and spiritually.
<G-vec00859-002-s174><concentrate.sich_konzentrieren><de> Nach dem OM-Singen konzentriere dich einige Minuten lang auf deinen Körper und sei dir deines Daseins in seiner Ganzheit bewußt – körperlich, geistig und seelisch.
<G-vec00859-002-s175><concentrate.sich_konzentrieren><en> Develop all the skills of your character harmoniously or choose to concentrate on one skill and become a master.
<G-vec00859-002-s175><concentrate.sich_konzentrieren><de> Entwickle alle Fähigkeiten Deines Charakters gleichzeitig oder konzentriere Dich auf eine Fähigkeit und meistere sie.
<G-vec00859-002-s176><concentrate.sich_konzentrieren><en> Concentrate on the Navel Chakra and what it stands for, at the spine, slightly above the navel.
<G-vec00859-002-s176><concentrate.sich_konzentrieren><de> Konzentriere dich auf das Nabelchakra an der Wirbelsäule, etwas über dem Nabel, und darauf, was es darstellt.
<G-vec00859-002-s177><concentrate.sich_konzentrieren><en> Concentrate on the here and now, on what you are doing at the moment, on your body’s movements, your cleaning cloth and your scrubbing brush.
<G-vec00859-002-s177><concentrate.sich_konzentrieren><de> Konzentriere Dich auf das Hier und Jetzt, auf das, was Du gerade tust, auf die Bewegungen Deines Körpers, Deines Lappens, Deines Schrubbers.
<G-vec00859-002-s178><concentrate.sich_konzentrieren><en> Always be careful, concentrate, follow the instructions, and follow the tips on the side.
<G-vec00859-002-s178><concentrate.sich_konzentrieren><de> Gehe dabei stets behutsam vor, konzentriere Dich, befolge die Anweisungen und beachte die Hinweise an der Seite.
<G-vec00859-002-s179><concentrate.sich_konzentrieren><en> Concentrate on the task, not the bloody audience.
<G-vec00859-002-s179><concentrate.sich_konzentrieren><de> Konzentriere dich auf deine Aufgabe, nicht auf das verdammte Publikum.
<G-vec00859-002-s180><concentrate.sich_konzentrieren><en> Look at this clip, totally concentrate on my voice and you will love it even more afterwards.
<G-vec00859-002-s180><concentrate.sich_konzentrieren><de> Sieh dir diesen Clip an, tauche immer mehr ab, lass dich fallen und konzentriere dich auf meine Stimme.
<G-vec00859-002-s181><concentrate.sich_konzentrieren><en> At this point you should only concentrate on moving forward (a little) and creating a small hop, nothing else.
<G-vec00859-002-s181><concentrate.sich_konzentrieren><de> Konzentriere dich in dieser Phase darauf die Arme auszustrecken und einen kleinen Hopser zu machen bevor du am Rücken landest.
<G-vec00859-002-s182><concentrate.sich_konzentrieren><en> Rather concentrate on these little ones I have sent you, I love to see them dancing with Me.
<G-vec00859-002-s182><concentrate.sich_konzentrieren><de> Vielmehr konzentriere dich auf diese Kleinen, die Ich dir geschickt habe, Ich liebe es, sie mit Mir tanzen zu sehen.
<G-vec00859-002-s183><concentrate.sich_konzentrieren><en> If the exercises are very new to you and you are having difficulty harmonizing your breathing with them, then first concentrate on carrying out the movements while continuing to breathe in a way that suits you.
<G-vec00859-002-s183><concentrate.sich_konzentrieren><de> Wenn die Übungen für dich noch ganz neu sind und du Schwierigkeiten damit hast, den Atem mit den Bewegungen in Einklang zu bringen, dann konzentriere dich zunächst auf die Ausführung der Bewegungen und atme so weiter, wie es für dich gut passt.
<G-vec00859-002-s184><concentrate.sich_konzentrieren><en> Concentrate on your game, we bring you the right equipment.
<G-vec00859-002-s184><concentrate.sich_konzentrieren><de> Konzentriere dich auf dein Spiel, wir bringen dir die richtige Ausrüstung.
<G-vec00859-002-s185><concentrate.sich_konzentrieren><en> One principle that I personally like, for example, is: concentrate on the low hanging fruits; in other words: try, learn, try, learn, try.
<G-vec00859-002-s185><concentrate.sich_konzentrieren><de> Ein Grundsatz, der mir persönlich gefällt, ist zum Beispiel: Konzentriere dich auf die low hanging fruits; also: ausprobieren, lernen, ausprobieren, lernen, ausprobieren.
<G-vec00859-002-s186><concentrate.sich_konzentrieren><en> Concentrate and focus on the person who is speaking.
<G-vec00859-002-s186><concentrate.sich_konzentrieren><de> Konzentriere dich auf die Person, die gerade spricht.
<G-vec00859-002-s187><concentrate.sich_konzentrieren><en> Concentrate on positive thoughts such as good friends, times, laughter, and the like.
<G-vec00859-002-s187><concentrate.sich_konzentrieren><de> Konzentriere dich auf positive Gedanken, wie zum Beispiel auf gute Freunde, auf schöne Zeiten und ähnliche Dinge.
<G-vec00859-002-s188><concentrate.sich_konzentrieren><en> Concentrate on your feelings, forget about the hectic.
<G-vec00859-002-s188><concentrate.sich_konzentrieren><de> Konzentriere dich auf deine Gefühle, vergiss die Hektik.
<G-vec00859-002-s189><concentrate.sich_konzentrieren><en> Do not use filters or effects, rather concentrate on brightness, contrast and sharpening.
<G-vec00859-002-s189><concentrate.sich_konzentrieren><de> Lass die Finger von grausamen Filtern oder Effekten und konzentriere dich auf die Belichtungsstufen.
<G-vec00859-002-s190><concentrate.sich_konzentrieren><en> Concentrate on every step – your brain has to get used to the new way of moving.
<G-vec00859-002-s190><concentrate.sich_konzentrieren><de> Konzentriere dich auf jeden Schritt – dein Gehirn muss sich erst an die neuen Bewegungsabläufe gewöhnen.
<G-vec00859-002-s191><concentrate.sich_konzentrieren><en> Eyes: Close your eyes. Breath: Concentrate on your breath.
<G-vec00859-002-s191><concentrate.sich_konzentrieren><de> Schließe deine Augen und konzentriere dich auf deinen Atem .
<G-vec00859-002-s192><concentrate.sich_konzentrieren><en> {Concentrate on any tension in your face and take a deep breath in.
<G-vec00859-002-s192><concentrate.sich_konzentrieren><de> 4 Konzentriere dich auf jede mögliche Anspannung in deinem Gesicht und atme tief ein.
<G-vec00859-002-s193><concentrate.sich_konzentrieren><en> Finally, I concentrate on the dust content of Cassiopeia A.
<G-vec00859-002-s193><concentrate.sich_konzentrieren><de> Weiterhin konzentriere ich mich auf eine Untersuchung des Staubgehaltes von Cassiopeia A.
<G-vec00859-002-s194><concentrate.sich_konzentrieren><en> Even the studies have taken off, I concentrate much easier and I am determined to pass the exam that I got stuck on.
<G-vec00859-002-s194><concentrate.sich_konzentrieren><de> Auch habe ich das Studium aufgenommen, konzentriere mich viel leichter und bin fest entschlossen, die Prüfung zu bestehen, die noch bevorsteht.
<G-vec00859-002-s195><concentrate.sich_konzentrieren><en> I tend to concentrate mainly on technical translations (mostly automotive with forays into construction, energy, IT and so on), but with a healthy amount of marketing and sometimes other topics thrown in.
<G-vec00859-002-s195><concentrate.sich_konzentrieren><de> Ich konzentriere mich hauptsächlich auf technische Übersetzungen (meistens aus dem Automobilsektor, hin und wieder mit einem kleinen Ausflug in den Bereich Bau, Energie, IT und so weiter), bearbeite aber auch einiges aus dem Bereich Marketing und manchmal auch aus anderen Gebieten, so dass es nicht langweilig wird.
<G-vec00859-002-s196><concentrate.sich_konzentrieren><en> I concentrate on a certain idea or story.
<G-vec00859-002-s196><concentrate.sich_konzentrieren><de> Ich konzentriere mich auf eine Idee oder eine Geschichte.
<G-vec00859-002-s197><concentrate.sich_konzentrieren><en> I concentrate on putting one hand over the other.
<G-vec00859-002-s197><concentrate.sich_konzentrieren><de> Ich konzentriere mich auf die nächsten Griffe.
<G-vec00859-002-s198><concentrate.sich_konzentrieren><en> “Admittedly, I don’t always concentrate one hundred percent on what’s being said, and sometimes I’m not even consciously listening.
<G-vec00859-002-s198><concentrate.sich_konzentrieren><de> «Zugegeben, ich konzentriere mich nicht immer 100-prozentig auf den Text und höre manchmal auch unbewusst zu.
<G-vec00859-002-s199><concentrate.sich_konzentrieren><en> I avoid unnecessary appointments and concentrate fully on my priorities: skiing.
<G-vec00859-002-s199><concentrate.sich_konzentrieren><de> Unnötige Termine lasse ich aus und konzentriere mich voll auf mein Kerngeschäft: Skifahren.
<G-vec00859-002-s200><concentrate.sich_konzentrieren><en> I concentrate.
<G-vec00859-002-s200><concentrate.sich_konzentrieren><de> Ich konzentriere mich.
<G-vec00859-002-s201><concentrate.sich_konzentrieren><en> I will concentrate on two major American variants of the divine interpreter; namely the figure of the sly B'rer Rabbit and the figure of the root doctor and conjure-man in the hoodoo tradition.To illustrate Esu's development from his African roots to his American relatives, I intend to give a basic insight into his original, African characteristics.
<G-vec00859-002-s201><concentrate.sich_konzentrieren><de> Ich konzentriere mich auf zwei wesentliche Varianten des "göttlichen Dolmetschers" Esu, nämlich auf die Figur des listigen B'rer Rabbit und der des spirituellen Naturheilers und Zauberers, dem Hoodoo Priester.Um die Entwicklung von Esu zu seinen amerikanischen Verwandten zu verdeutlichen, arbeite ich mich von seinen ursprünglichen, afrikanischen, Charakteristiken durch bis hin zu seinen, oben erwähnten, neuen Varianten, die in der Afroamerikanischen Literatur zum Tragen kommen.
<G-vec00859-002-s221><concentrate.sich_konzentrieren><en> In Shanghai there concentrate deep and dynamic transformation processes on a economic, technological and societal level in an exemplary manner.
<G-vec00859-002-s221><concentrate.sich_konzentrieren><de> In Shanghai konzentrieren sich tiefgreifende, dynamische Transformationsprozesse auf wirtschaftlicher, technologischer und gesellschaftlicher Ebene in exemplarischer Weise.
<G-vec00859-002-s222><concentrate.sich_konzentrieren><en> Free to concentrate on what really matters.
<G-vec00859-002-s222><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich auf das, was für Sie wichtig ist.
<G-vec00859-002-s223><concentrate.sich_konzentrieren><en> Concentrate on problem areas, impurities and blackheads.
<G-vec00859-002-s223><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich auf Problembereiche, Unreinheiten und Mitesser.
<G-vec00859-002-s224><concentrate.sich_konzentrieren><en> About the Majors The Bachelors of Fine Arts (B.F.A.) students concentrate on multimedia and graphic design or studio art.
<G-vec00859-002-s224><concentrate.sich_konzentrieren><de> Über den Majors Die Bachelor of Fine Arts (BFA) Studenten konzentrieren sich auf Multimedia und Grafik-Design oder Studio-Kunst.
<G-vec00859-002-s225><concentrate.sich_konzentrieren><en> Concentrate on the propulsion and landing phases of your stride.
<G-vec00859-002-s225><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich auf die Abdruck- und die Landephase.
<G-vec00859-002-s226><concentrate.sich_konzentrieren><en> The majority of external service providers concentrate on the classical service areas such as cleaning, repairs, mobility, and care taking.
<G-vec00859-002-s226><concentrate.sich_konzentrieren><de> Die meisten externen Anbieter konzentrieren sich auf die klassischen Dienstleistungsbereiche wie Reparatur, Reinigung, Mobilität und Betreuung.
<G-vec00859-002-s227><concentrate.sich_konzentrieren><en> Laser devices used for the treatment of skin anomalies and age-specific modifications mainly concentrate on destroying tissue parts in extremely small skin areas.
<G-vec00859-002-s227><concentrate.sich_konzentrieren><de> Lasergeräte, die für die Behandlung von Hautanomalien und altersbedingter Veränderungen eingesetzt werden, konzentrieren sich im Wesentlichen auf die Zerstörung von Gewebeteilen auf kleinstem Raum.
<G-vec00859-002-s228><concentrate.sich_konzentrieren><en> The double-round headlights positioned wide on the vehicle’s exterior concentrate on what’s important: the road.
<G-vec00859-002-s228><concentrate.sich_konzentrieren><de> Die weit außen positionierten Doppelrundscheinwerfer konzentrieren sich auf das Wesentliche: die Straße.
<G-vec00859-002-s229><concentrate.sich_konzentrieren><en> Many weight loss medication concentrate on day time weight reduction only, ignoring the reality that sleep is essential for your weight loss success.
<G-vec00859-002-s229><concentrate.sich_konzentrieren><de> Die meisten Gewichtsverlust Pillen konzentrieren sich auf Tageszeit Gewichtsverlust nur, ignoriert die Tatsache, dass der Schlaf für Ihre Diät Erfolg entscheidend ist.
<G-vec00859-002-s230><concentrate.sich_konzentrieren><en> Within the framework of the subject measurement- and control technology the research activities concentrate on theoretical and practical tasks of modelling, designing and implementing control technological systems.
<G-vec00859-002-s230><concentrate.sich_konzentrieren><de> Im Rahmen des Fachgebietes Mess- Steuerungs- und Regelungstechnik konzentrieren sich die Forschungsaktivitäten auf theoretische und praktische Arbeiten zu Modellbildung, Entwurf und Implementierung von regelungstechnischen Systemen.
<G-vec00859-002-s231><concentrate.sich_konzentrieren><en> Now concentrate on the chosen chakra, expressing in the teachings – be it a tone – the name of the demon connected to it and remove it from a familiar need.
<G-vec00859-002-s231><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich nun auf das auserwählte Chakra und drücken Sie in den Lehren – ein Ton – den Namen des Dämons, der mit ihm verbunden ist, und entfernen Sie ihn von einem vertrauten Bedürfnis.
<G-vec00859-002-s232><concentrate.sich_konzentrieren><en> End users Concentrate on your work and stop wasting time with IT limitations.
<G-vec00859-002-s232><concentrate.sich_konzentrieren><de> Endanwender Konzentrieren Sie sich auf Ihre Arbeit und verschwenden Sie keine Zeit mehr mit Einschränkungen durch die IT.
<G-vec00859-002-s233><concentrate.sich_konzentrieren><en> Concentrate on your core competencies and let us take care of all assignments in staffing services – reliably and efficiently.
<G-vec00859-002-s233><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich auf Ihre Kernkompetenzen und lassen Sie sämtliche Aufgaben bezüglich Ihres Personalmanagements zuverlässig und effizient von uns erledigen.
<G-vec00859-002-s234><concentrate.sich_konzentrieren><en> At RECYCLING-TECHNIK Dortmund you will be able to get your completely furnished stand without any effort and can therefore concentrate on making business with interested companies for two days
<G-vec00859-002-s234><concentrate.sich_konzentrieren><de> Beziehen Sie einfach ohne jeglichen Aufwand Ihren fertigen, komplett möblierten Messestand und konzentrieren Sie sich dann für zwei Tage auf die Geschäfte mit interessierten Firmen.
<G-vec00859-002-s235><concentrate.sich_konzentrieren><en> steers your vehicle, allowing you to concentrate fully on your work.
<G-vec00859-002-s235><concentrate.sich_konzentrieren><de> Der SmartPilot lenkt Ihr Fahrzeug, Sie konzentrieren sich voll auf Ihre Arbeit.
<G-vec00859-002-s236><concentrate.sich_konzentrieren><en> Concentrate on core TEM objectives and TEM strategic initiatives rather than hosting, infrastructure, and connectivity issues
<G-vec00859-002-s236><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich auf die Hauptziele –und Strategien der TEM –Initiative anstatt auf die Bereitstellung, Infrastruktur und Konnektivität.
<G-vec00859-002-s237><concentrate.sich_konzentrieren><en> DVV International activities therefore concentrate on projects which benefit the most socially disadvantaged sectors of the population.
<G-vec00859-002-s237><concentrate.sich_konzentrieren><de> Die Maßnahmen von DVV International konzentrieren sich daher auf Projekte, die den sozial am meisten benachteiligten Bevölkerungsgruppen zu Gute kommen.
<G-vec00859-002-s238><concentrate.sich_konzentrieren><en> Concentrate on the clever colleagues who already master their challenges.
<G-vec00859-002-s238><concentrate.sich_konzentrieren><de> Konzentrieren Sie sich auf gute Leute, die ihre Herausforderungen bereits meistern.
<G-vec00859-002-s239><concentrate.sich_konzentrieren><en> Research and studies concentrate on digital media both as technology in the context of design and planning as well as being constituent component of a planned society.
<G-vec00859-002-s239><concentrate.sich_konzentrieren><de> Forschung und Lehre konzentrieren sich auf digitale Medien sowohl als Technologie hinter Design und Planung als auch als konstitutiver Bestandteil der geplanten Gesellschaft.
<G-vec00859-002-s240><concentrate.sich_konzentrieren><en> We also concentrate on the same element that made Spacelab a success — pilot projects.
<G-vec00859-002-s240><concentrate.sich_konzentrieren><de> Zudem konzentrieren wir uns auf das, was auch das Spacelab erfolgreich gemacht hat — die Pilotprojekte.
<G-vec00859-002-s241><concentrate.sich_konzentrieren><en> We concentrate on areas that promote our role as a “good neighbor” of the communities in which we operate worldwide. We also focus on projects that can benefit from our core areas of expertise as an automobile manufacturer as well as our specific know-how.
<G-vec00859-002-s241><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf Handlungsfelder, die unserer Rolle als »guter Nachbar« an den Standorten weltweit förderlich sind, und auf Projekte, die von unserer Kernkompetenz als Automobilhersteller ebenso wie von unserem spezifischen Wissen profitieren können.
<G-vec00859-002-s242><concentrate.sich_konzentrieren><en> We concentrate on niche categories, in which we strive to achieve market leadership.
<G-vec00859-002-s242><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf Nischenmärkte, in denen wir die Marktführerschaft anstreben.
<G-vec00859-002-s243><concentrate.sich_konzentrieren><en> Our vision is to concentrate on the essentials without any unnecessary frills. In the new Jacob’s Restaurant, guests will be able to experience simplicity at its best,” explains Thomas Martin.
<G-vec00859-002-s243><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf das Wesentliche mit der Vision, die Küche im besten Sinne zu vereinfachen: Im neuen Jacobs Restaurant erlebt der Gast ‚Einfachheit auf höchstem Niveau‘“, so Thomas Martin.
<G-vec00859-002-s244><concentrate.sich_konzentrieren><en> We concentrate on creating a customised database of the recipients, as well as on the highest possible deliverability of the e-mails, which we monitor and measure.
<G-vec00859-002-s244><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf die Schaffung einer bestmöglich zugeschnittenen Empfängerdatenbank sowie auf eine gleichermaßen hohe Lieferbarkeit der E-Mails, die wir überwachen und messen.
<G-vec00859-002-s245><concentrate.sich_konzentrieren><en> In the interests of optimum functionality and competitiveness, we concentrate first and foremost on elastic infill granules made of EPDM variants (GOLD
<G-vec00859-002-s245><concentrate.sich_konzentrieren><de> Für ein Optimum an Funktionalität und Wetterbeständigkeit konzentrieren wir uns dabei vor allem auf elastische Einfüllgranulate aus EPDM-Varianten (Ethylen-Propylen-Dien-Kautschuk).
<G-vec00859-002-s246><concentrate.sich_konzentrieren><en> For pulling and pulled units, we concentrate on chassis elements that achieve these goals.
<G-vec00859-002-s246><concentrate.sich_konzentrieren><de> Für ziehende und gezogene Einheiten konzentrieren wir uns auf Fahrwerkelemente, die diese Ziele erreichen.
<G-vec00859-002-s247><concentrate.sich_konzentrieren><en> Following an analysis of your target market, we will concentrate on the essentials.
<G-vec00859-002-s247><concentrate.sich_konzentrieren><de> Nach einer Analyse Ihres Zielmarktes konzentrieren wir uns auf das Wesentliche.
<G-vec00859-002-s248><concentrate.sich_konzentrieren><en> We continue to consistently concentrate on the development, design and production of systems and integratable machines for dry work – for textile service providers of every size.
<G-vec00859-002-s248><concentrate.sich_konzentrieren><de> Wir konzentrieren uns weiterhin konsequent auf die Entwicklung, Konstruktion und Produktion von Systemanlagen und integrationsfähigen Maschinen im trockenen Bereich – für Textile Dienstleister jeder Unternehmensgröße.
<G-vec00859-002-s249><concentrate.sich_konzentrieren><en> Finally, we concentrate on protein variants that arise by alternative splicing events.
<G-vec00859-002-s249><concentrate.sich_konzentrieren><de> Im letzten Teil der Arbeit konzentrieren wir uns auf Proteinvarianten, die sich durch alternatives Spleißen ergeben.
<G-vec00859-002-s250><concentrate.sich_konzentrieren><en> After discussing some general results we concentrate on the rational unibranch case, i.e., the case where the associated maximal order is local again, with residue field equal to the ground field.
<G-vec00859-002-s250><concentrate.sich_konzentrieren><de> Nach Diskussion einiger allgemeiner Resultate konzentrieren wir uns auf den rationalen einzweigigen Fall, d.h., den Fall wo die assoziierte Hauptordnung wieder lokal ist, mit Restklassenkörper gleich dem Grundkörper.
<G-vec00859-002-s251><concentrate.sich_konzentrieren><en> In this book, we concentrate on the SP waveguide configurations ensuring nanoscale confinement and review the current status of this rapidly emerging field, considering different configurations being developed for nanoscale plasmonic guides and circuits.
<G-vec00859-002-s251><concentrate.sich_konzentrieren><de> In diesem Buch konzentrieren uns wir auf die SP-Hohlleiterkonfigurationen, nanoscale Beschränkung sicherstellend und wiederholen den aktuellen Status dieses schnell auftauchenden Bereichs, in Betracht der verschiedenen Konfigurationen, die für nanoscale plasmonic Anleitungen und Schaltungen sich entwickelt werden.
<G-vec00859-002-s252><concentrate.sich_konzentrieren><en> We concentrate on our core business to provide the highest level of expertise within our portfolio.
<G-vec00859-002-s252><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf unser Kerngeschäft, um das größtmögliche Expertenwissen innerhalb unseres Fachbereichs bereitzustellen.
<G-vec00859-002-s253><concentrate.sich_konzentrieren><en> But let’s not digress and concentrate on the technical provision of the feature.
<G-vec00859-002-s253><concentrate.sich_konzentrieren><de> Aber schweifen wir nicht ab und konzentrieren wir uns auf die technische Bereitstellung des Features.
<G-vec00859-002-s254><concentrate.sich_konzentrieren><en> For now, we will concentrate on the renal aspects.
<G-vec00859-002-s254><concentrate.sich_konzentrieren><de> Für den Augenblick konzentrieren wir uns auf die renalen Aspekte.
<G-vec00859-002-s255><concentrate.sich_konzentrieren><en> As a specialist within the ALHO Group, we concentrate on the production of high-quality space solutions - from simple standard containers to complex container buildings.
<G-vec00859-002-s255><concentrate.sich_konzentrieren><de> Als Spezialist innerhalb der ALHO Gruppe konzentrieren wir uns auf die Herstellung hochwertiger Raumlösungen – von einfachen Standard-Containern bis zu komplexen Containergebäuden.
<G-vec00859-002-s256><concentrate.sich_konzentrieren><en> We concentrate on roadway security industry for greater than 11 years.
<G-vec00859-002-s256><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf Fahrbahnbewachungsgewerbe für größer als 11 Jahre.
<G-vec00859-002-s257><concentrate.sich_konzentrieren><en> We concentrate on loans secured by property liens.
<G-vec00859-002-s257><concentrate.sich_konzentrieren><de> Wir konzentrieren uns auf grundpfandrechtlich besicherte gewerbliche Kredite.
<G-vec00859-002-s258><concentrate.sich_konzentrieren><en> In this workshop we concentrate on sour, salty and sweet.
<G-vec00859-002-s258><concentrate.sich_konzentrieren><de> In diesem Workshop konzentrieren wir uns auf sauer, salzig und süß.
<G-vec00859-002-s278><concentrate.sich_konzentrieren><en> He doesn’t concentrate on the raft, but goes looking for what happened just before and just after the disaster.
<G-vec00859-002-s278><concentrate.sich_konzentrieren><de> Er konzentriert sich nicht auf das Floß, sondern versucht herauszufinden, was genau vor und genau nach der Katastrophe geschah.
<G-vec00859-002-s279><concentrate.sich_konzentrieren><en> You hear, see, and read very little about Pierre Charpin – the French designer avoids the limelight, preferring to concentrate on his work.
<G-vec00859-002-s279><concentrate.sich_konzentrieren><de> Nur wenig hört, sieht oder liest man über Pierre Charpin – der französische Designer meidet das Rampenlicht und konzentriert sich lieber auf seine Arbeit.
<G-vec00859-002-s280><concentrate.sich_konzentrieren><en> The qualification programmes concentrate on students, doctoral candidates and postdocs.
<G-vec00859-002-s280><concentrate.sich_konzentrieren><de> Das Qualifizierungsangebot konzentriert sich auf Studierende, Promovierende und Postdocs.
<G-vec00859-002-s281><concentrate.sich_konzentrieren><en> School clothing marks a turning point like “professional clothing”: those who wear them become part of a community and concentrate almost automatically on the task, in this case the school-related aspects.
<G-vec00859-002-s281><concentrate.sich_konzentrieren><de> Schulkleidung setzt wie „Berufskleidung“ eine Zäsur: Wer sie trägt, wird Teil einer Gemeinschaft und konzentriert sich wie von selbst auf die Aufgabe, in diesem Fall das Schulische.
<G-vec00859-002-s282><concentrate.sich_konzentrieren><en> Swiss Life/Rentenanstalt will concentrate on its life insurance business for the future.
<G-vec00859-002-s282><concentrate.sich_konzentrieren><de> Die Rentenanstalt/Swiss Life konzentriert sich künftig auf das Lebensversicherungsgeschäft.
<G-vec00859-002-s283><concentrate.sich_konzentrieren><en> It will concentrate on the critical zone that begins below the root-filled soil layer.
<G-vec00859-002-s283><concentrate.sich_konzentrieren><de> Er konzentriert sich auf den Bereich der „Kritischen Zone", der unterhalb der intensiv durchwurzelten Bodenschicht beginnt.
<G-vec00859-002-s284><concentrate.sich_konzentrieren><en> It will concentrate on the critical zone that begins below the root-filled soil layer.
<G-vec00859-002-s284><concentrate.sich_konzentrieren><de> Er konzentriert sich auf den Bereich der „Kritischen Zone“, der unterhalb der intensiv durchwurzelten Bodenschicht beginnt.
<G-vec00859-002-s285><concentrate.sich_konzentrieren><en> In children under the age of three, the pain does not mainly concentrate in one place.
<G-vec00859-002-s285><concentrate.sich_konzentrieren><de> Bei Kindern unter drei Jahren konzentriert sich der Schmerz nicht hauptsächlich an einem Ort.
<G-vec00859-002-s286><concentrate.sich_konzentrieren><en> For this reason, we shall concentrate on the area between the stanchions.
<G-vec00859-002-s286><concentrate.sich_konzentrieren><de> Somit konzentriert sich unser Augenmerk auf die Fläche zwischen den Rungen.
<G-vec00859-002-s287><concentrate.sich_konzentrieren><en> If we concentrate on these hands we will often be able to knock one or two bad players out of the tournament, simply by virtue of having the better hand.
<G-vec00859-002-s287><concentrate.sich_konzentrieren><de> Konzentriert man sich auf diese Hände, wird man oftmals den ein oder anderen schlechten Spieler aus dem Turnier nehmen, da man schlichtweg die bessere Hand hat.
<G-vec00859-002-s288><concentrate.sich_konzentrieren><en> Phoenix will initially concentrate on power plant construction in the US market.
<G-vec00859-002-s288><concentrate.sich_konzentrieren><de> Phoenix konzentriert sich im US Markt zunächst auf den Kraftwerksbau.
<G-vec00859-002-s289><concentrate.sich_konzentrieren><en> Allowing you to concentrate on the essentials.
<G-vec00859-002-s289><concentrate.sich_konzentrieren><de> Hier konzentriert man sich auf das Wesentliche.
<G-vec00859-002-s290><concentrate.sich_konzentrieren><en> We concentrate†on the development of innovative seeds for the needs of a rapidly changing society.
<G-vec00859-002-s290><concentrate.sich_konzentrieren><de> KWS konzentriert sich auf die Entwicklung von innovativem Saatgut für den Bedarf einer sich rasant wandelnden Gesellschaft.
<G-vec00859-002-s291><concentrate.sich_konzentrieren><en> 1937 brought a strategic refocusing, as the company was fully taken over by Schering AG: from this point onwards, production began to concentrate on chemical/technical products, but manufactured pharmaceuticals at an increasing rate as well.
<G-vec00859-002-s291><concentrate.sich_konzentrieren><de> 1937 erfolgt mit der kompletten Übernahme durch die Schering AG eine strategische Neupositionierung: Ab jetzt konzentriert sich die Produktion auf chemisch-technische, aber zunehmend auch pharmazeutische Erzeugnisse.
<G-vec00859-002-s292><concentrate.sich_konzentrieren><en> (Arvato Systems) Gütersloh/Cologne – Future-oriented IT specialist Arvato Systems to concentrate on the creation and development of their software products for broadcast and media, without however compromising enterprise business growth.
<G-vec00859-002-s292><concentrate.sich_konzentrieren><de> (Arvato Systems) Gütersloh/Köln – Als zukunftsorientierter IT-Experte konzentriert sich Arvato Systems im Bereich Broadcast- und Medienlösungen auf die Entwicklung und Herstellung eigener Software-Produkte, ohne dabei den Ausbau des Enterprise-Business zu vernachlässigen.
<G-vec00859-002-s293><concentrate.sich_konzentrieren><en> He gives pride of place to selected ingredients, only then does he concentrate on the execution.
<G-vec00859-002-s293><concentrate.sich_konzentrieren><de> Er gibt ausgewählten Zutaten den Vorzug, erst dann konzentriert er sich auf deren Ausführung.
<G-vec00859-002-s294><concentrate.sich_konzentrieren><en> 2018 will see the MAN Group focus on the following areas: the Company will continue to concentrate on measures to optimize processes and cost structures.
<G-vec00859-002-s294><concentrate.sich_konzentrieren><de> Im Jahr 2018 stehen für die MAN Gruppe folgende Themen im Mittelpunkt: Das Unternehmen konzentriert sich weiterhin auf Maßnahmen zur Optimierung von Prozessen und Kostenstrukturen.
<G-vec00859-002-s295><concentrate.sich_konzentrieren><en> It is for this reason that the University of Bayreuth has chosen to concentrate its efforts on six faculties, making sure that their research and teaching is nurtured and fostered across the board.
<G-vec00859-002-s295><concentrate.sich_konzentrieren><de> Aus diesem Grund konzentriert sich die Universität Bayreuth bewusst auf sechs Fakultäten, um diese in Forschung und Lehre in der ganzen Bandbreite fördern und unterstützen zu können.
<G-vec00859-002-s296><concentrate.sich_konzentrieren><en> Research Our main research activities concentrate on labour market policy, regional and social policy, education training and job qualification, equal opportunities, and structural fund interventions in Austria and the Eastern European neighbour states.
<G-vec00859-002-s296><concentrate.sich_konzentrieren><de> Forschung Unsere Forschungstätigkeit konzentriert sich auf Arbeitsmarkt-, Regional- und Sozialpolitik, Weiterbildung und berufliche Qualifizierung, Chancengleichheit und Strukturfonds-Interventionen in Österreich und den osteuropäischen Nachbarstaaten.
<G-vec00859-002-s297><concentrate.sich_konzentrieren><en> But tomorrow is a new day and I will fully concentrate on the task ahead.
<G-vec00859-002-s297><concentrate.sich_konzentrieren><de> Aber morgen ist ein neuer Tag und ich werde mich voll auf die bevorstehende Aufgabe konzentrieren.
<G-vec00859-002-s298><concentrate.sich_konzentrieren><en> I need to concentrate hard to understand, and even harder to talk.
<G-vec00859-002-s298><concentrate.sich_konzentrieren><de> Ich muss mich schwer konzentrieren, um zu verstehen, und noch schwerer, um zu reden.
<G-vec00859-002-s299><concentrate.sich_konzentrieren><en> Feeling helpless, I decided to forget about it and concentrate on Fa-study.
<G-vec00859-002-s299><concentrate.sich_konzentrieren><de> In meiner Hilflosigkeit entschloss ich mich, es zu vergessen und mich auf das Fa-Lernen zu konzentrieren.
<G-vec00859-002-s300><concentrate.sich_konzentrieren><en> And then I can concentrate on my work.
<G-vec00859-002-s300><concentrate.sich_konzentrieren><de> Dann kann ich mich auch auf meine Arbeit konzentrieren.
<G-vec00859-002-s301><concentrate.sich_konzentrieren><en> In my lecture I will mainly concentrate on the first two areas. The third, which in some respects is closely connected to the second, can only be treated in passing here.
<G-vec00859-002-s301><concentrate.sich_konzentrieren><de> In meinem Vortrag werde ich mich vor allem auf die beiden ersten Bereiche konzentrieren; der dritte, der in mehrfacher Hinsicht mit dem zweiten eng verknüpft ist, kann in diesem Rahmen nur am Rande behandelt werden.
<G-vec00859-002-s302><concentrate.sich_konzentrieren><en> The 300 SLR gave me the reassurance to be able to concentrate fully on the race and winning.
<G-vec00859-002-s302><concentrate.sich_konzentrieren><de> Der 300 SLR gab mir das gute Gefühl, mich ganz auf das Rennen und den Sieg konzentrieren zu können.
<G-vec00859-002-s303><concentrate.sich_konzentrieren><en> I try to concentrate on myself.
<G-vec00859-002-s303><concentrate.sich_konzentrieren><de> Ich probiere, mich auf mich selbst zu konzentrieren.
<G-vec00859-002-s304><concentrate.sich_konzentrieren><en> So now I can again concentrate on the fight against the weather.
<G-vec00859-002-s304><concentrate.sich_konzentrieren><de> Jetzt kann ich mich also wieder auf den Kampf mit dem Wetter konzentrieren.
<G-vec00859-002-s305><concentrate.sich_konzentrieren><en> My thoughts, nerves and even mood evened out and I found it way easier to concentrate on the tasks at hand.
<G-vec00859-002-s305><concentrate.sich_konzentrieren><de> Meine Gedanken, Nerven und sogar meine Stimmung pendelten sich ein und ich fand es viel einfacher, mich auf die vorhandenen Aufgaben zu konzentrieren.
<G-vec00859-002-s306><concentrate.sich_konzentrieren><en> I couldn't concentrate on those things any longer because it hurt enough that it was distracting me.
<G-vec00859-002-s306><concentrate.sich_konzentrieren><de> Ich konnte mich nicht länger auf jene Dinge konzentrieren, weil es genug weh tat, dass es mich ablenkte.
<G-vec00859-002-s307><concentrate.sich_konzentrieren><en> As I am concerned with theatricality and public space, I will concentrate on examples of a theatrical re-staging of the founding moment of antagonism.
<G-vec00859-002-s307><concentrate.sich_konzentrieren><de> Da wir hier mit Theatralizität und Öffentlichkeit beschäftigt sind, werde ich mich auf Beispiele theatraler Wiederinszenierung des gründenden Moments des Antagonismus konzentrieren.
<G-vec00859-002-s308><concentrate.sich_konzentrieren><en> Then the priest asked me to close my eyes and concentrate.
<G-vec00859-002-s308><concentrate.sich_konzentrieren><de> Dann bat er mich, meine Augen zu schließen und mich zu konzentrieren.
<G-vec00859-002-s309><concentrate.sich_konzentrieren><en> I have discussed the LBP extensively in my two previous articles, so that I will concentrate here on the new energies that are flooding earth and humanity since the opening of the stargate 11.11.11 with our help and are now contributing decisively to the acceleration of the LBP in all incarnated human beings.
<G-vec00859-002-s309><concentrate.sich_konzentrieren><de> Ich habe den LKP in meinen beiden vorangegangenen Artikeln ausführlich diskutiert, so dass ich mich hier auf die neuen Energien konzentrieren werde, welche die Erde und die Menschheit seit der Öffnung des Sternentors 11.11.11 mit unserer Hilfe überfluten und nun entscheidend zur Beschleunigung des LKP in allen inkarnierten Menschen beitragen.
<G-vec00859-002-s310><concentrate.sich_konzentrieren><en> I need to concentrate.
<G-vec00859-002-s310><concentrate.sich_konzentrieren><de> Ich muss mich konzentrieren.
<G-vec00859-002-s311><concentrate.sich_konzentrieren><en> It helps me to concentrate during phone calls and meetings.
<G-vec00859-002-s311><concentrate.sich_konzentrieren><de> Das hilft mir, mich zu konzentrieren.
<G-vec00859-002-s312><concentrate.sich_konzentrieren><en> I’m usually a bit obsessive about counting steps but somehow I couldn’t concentrate anymore.
<G-vec00859-002-s312><concentrate.sich_konzentrieren><de> Ich bin ja eigentlich ein obsessiver Treppenstufenzähler, aber ich konnte mich nicht mehr konzentrieren.
<G-vec00859-002-s313><concentrate.sich_konzentrieren><en> I did earn some quite good bucks with it, but because of my other business ventures, wasn’t able to concentrate on using it with full capacity.
<G-vec00859-002-s313><concentrate.sich_konzentrieren><de> Ich habe ein bisschen Geld damit verdient, aber durch meine anderen Pflichten, konnte ich mich nicht nur auf diesen Bot konzentrieren.
<G-vec00859-002-s314><concentrate.sich_konzentrieren><en> As they are the only thing visible, I have virtually no other choice than to concentrate on the scene.
<G-vec00859-002-s314><concentrate.sich_konzentrieren><de> So bleibt mir gar nichts anderes übrig, als mich auf diese Szene zu konzentrieren.
<G-vec00859-002-s315><concentrate.sich_konzentrieren><en> You have to continue to network, you cannot rest your mind, hide yourself, and concentrate only on your book for the next few hours.
<G-vec00859-002-s315><concentrate.sich_konzentrieren><de> Ich muss vernetzt bleiben, ich kann nicht abschalten, mich verstecken und mich nur auf das Buch konzentrieren für die nächsten paar Stunden.
<G-vec00859-002-s371><concentrate.sich_konzentrieren><en> We provide a worry-free package, as a full-service provider, so that you can fully concentrate on your core business. Visit our website Thermal Management Services Imprint
<G-vec00859-002-s371><concentrate.sich_konzentrieren><de> Als Full-Service-Anbieter erhalten Sie von uns ein Rundum-Paket, damit Sie sich ganz auf Ihr Kerngeschäft, die sichere und pünktliche Beförderung von Personen und Waren, konzentrieren können.
<G-vec00859-002-s372><concentrate.sich_konzentrieren><en> He will concentrate on key relationships with ultra high net worth individuals in Switzerland and select international markets, and support the ongoing expansion of that business.
<G-vec00859-002-s372><concentrate.sich_konzentrieren><de> Er wird sich auf Schlüsselbeziehungen zu sehr vermögenden Kunden in der Schweiz und in ausgewählten internationalen Märkten konzentrieren und den weiteren Ausbau dieses Geschäfts unterstützen.
<G-vec00859-002-s373><concentrate.sich_konzentrieren><en> The user has to put it on and is then asked to concentrate his attention on a flame placed in front of him or her.
<G-vec00859-002-s373><concentrate.sich_konzentrieren><de> Der/die BesucherIn setzt diese Vorrichtung auf und muss sich dann auf eine vor ihm/ihr platzierte Flamme konzentrieren.
<G-vec00859-002-s374><concentrate.sich_konzentrieren><en> Forne had to force his raging emotions down to concentrate on the here and now.
<G-vec00859-002-s374><concentrate.sich_konzentrieren><de> Forne zwang seine tobenden Emotionen nieder, um sich auf das hier und jetzt zu konzentrieren.
<G-vec00859-002-s375><concentrate.sich_konzentrieren><en> The volunteers, as a result, can concentrate entirely on their activities.
<G-vec00859-002-s375><concentrate.sich_konzentrieren><de> Die Ehrenamtlichen können sich so ganz auf ihre Aktivitäten konzentrieren.
<G-vec00859-002-s376><concentrate.sich_konzentrieren><en> He who cleans too methodically, assuming this methodology requires a certain amount of mental concentration, finds it hard to concentrate on the program.
<G-vec00859-002-s376><concentrate.sich_konzentrieren><de> Wer zu methodisch putzt, solange diese Methodik einen gewissen Geistesaufwand benötigt, kann sich schwer auf die Sendung konzentrieren.
<G-vec00859-002-s377><concentrate.sich_konzentrieren><en> A large German employment agency wanted to concentrate exclusively on its core business and outsource the service desk to a specialist.
<G-vec00859-002-s377><concentrate.sich_konzentrieren><de> Ein großer deutscher Arbeitsvermittler wollte sich ausschließlich auf sein Kerngeschäft konzentrieren und den Service Desk an einen Spezialisten auslagern.
<G-vec00859-002-s379><concentrate.sich_konzentrieren><en> Travelers can concentrate now to the usual threats and don’t need to watch for mass of madness mummies behind each tree.
<G-vec00859-002-s379><concentrate.sich_konzentrieren><de> Der Reisende kann sich jetzt wieder auf die üblichen Bedrohungen konzentrieren und muss nicht mehr damit rechnen, dass hinter jedem Baum eine verrückte Mumie lauert.
<G-vec00859-002-s380><concentrate.sich_konzentrieren><en> Absolutely annoying, however is the background music which in parts is waaaaay to loud - to the point where you have to concentrate on what Adam is saying....
<G-vec00859-002-s380><concentrate.sich_konzentrieren><de> Absolut nervig hingegen ist die Hintergrundmusik, die in Teilen so laut ist, dass man sich auf das, was Adam so erzahlt schon sehr konzentrieren muss.
<G-vec00859-002-s381><concentrate.sich_konzentrieren><en> A professional management team takes care of long-term, reliable quality on site, while a highly developed IT infrastructure and competent full-service solutions, such as interior design, IT and facility services, enable the companies based here to concentrate on their core business.
<G-vec00859-002-s381><concentrate.sich_konzentrieren><de> Ein professionelles Management-Team sorgt für eine langfristige und zuverlässige Qualität am Standort, während eine hochentwickelte IT-Infrastruktur und kompetente Full Service-Leistungen, wie Raumgestaltung, IT- und Facility-Services es den ansässiges Unternehmen ermöglichen, sich auf ihr Kerngeschäft zu konzentrieren.
<G-vec00859-002-s382><concentrate.sich_konzentrieren><en> When the airlines gradually increase their offerings again, they will concentrate on the lucrative routes with high margins.
<G-vec00859-002-s382><concentrate.sich_konzentrieren><de> Wenn die Airlines ihr Angebot nach und nach wieder hochfahren, werden sie sich auf die lukrativen Strecken mit hohen Margen konzentrieren.
<G-vec00859-002-s383><concentrate.sich_konzentrieren><en> Noise can also affect performance when carrying out difficult assignments due to inability to concentrate.
<G-vec00859-002-s383><concentrate.sich_konzentrieren><de> Lärm kann auch die Leistung beim Ausführen schwieriger Aufgaben beeinträchtigen, weil man sich nicht konzentrieren kann.
<G-vec00859-002-s384><concentrate.sich_konzentrieren><en> Combined with intuitive point and click flight planning and automatic anti-collision systems managed by artificial intelligence, allows the remote operator to concentrate on the mission at hand.
<G-vec00859-002-s384><concentrate.sich_konzentrieren><de> In Kombination mit intuitiver Point-and-Click-Flugplanung und automatischen, durch künstliche Intelligenz gesteuerten Kollisionsschutzsystemen kann der Remote-Benutzer sich auf die vor ihm liegende Mission konzentrieren.
<G-vec00859-002-s385><concentrate.sich_konzentrieren><en> Because of the calm sea and the peace around one, one could concentrate all the more on the sky with its millions of shades of grey.
<G-vec00859-002-s385><concentrate.sich_konzentrieren><de> Wegen der stillen See und der Ruhe um einen herum konnte man sich um so mehr auf den Himmel mit seinen Millionen von Schattierungen von Grau konzentrieren.
<G-vec00859-002-s386><concentrate.sich_konzentrieren><en> You delve into nature, and because you have to concentrate much on the course, you strike up a deeper relationship with your surroundings.
<G-vec00859-002-s386><concentrate.sich_konzentrieren><de> Man taucht ein in die Natur und weil man sich auf die Strecke viel mehr konzentrieren muss, geht man eine tiefere Beziehung mit der Umgebung ein.
<G-vec00859-002-s387><concentrate.sich_konzentrieren><en> So that you can fully concentrate on your conference, we offer you our Superior Conference Package for 10 or more persons.
<G-vec00859-002-s387><concentrate.sich_konzentrieren><de> Damit Sie sich optimal auf Ihre Konferenz konzentrieren können, bieten wir Ihnen bereits ab einer Teilnehmerzahl von 10 Personen unsere Superior Tagungspauschale an.
<G-vec00859-002-s388><concentrate.sich_konzentrieren><en> The previous mother company of TechniSat Automotive, TechniSat Digital GmbH from Daun, will concentrate immediately on the business division “Consumer Electronics” and develop this field of business independently.
<G-vec00859-002-s388><concentrate.sich_konzentrieren><de> Die bisherige Muttergesellschaft von TechniSat Automotive, die TechniSat Digital GmbH aus Daun, wird sich ab sofort auf den Geschäftsbereich „Consumer Electronics“ konzentrieren und dieses Geschäftsfeld eigenständig weiterentwickeln.
<G-vec00859-002-s389><concentrate.sich_konzentrieren><en> With all the pre-exhibition stress, he had to concentrate on what was essential.
<G-vec00859-002-s389><concentrate.sich_konzentrieren><de> Im Vormessestress musste auch er sich auf das Wesentliche konzentrieren.
<G-vec00859-002-s390><concentrate.sich_konzentrieren><en> The name should cause the dog to concentrate on the owner, and the team "to me" - to approach.
<G-vec00859-002-s390><concentrate.sich_konzentrieren><de> Der Name sollte dazu führen, dass sich der Hund auf den Besitzer konzentriert und das Team "zu mir" - zu kommen.
<G-vec00859-002-s391><concentrate.sich_konzentrieren><en> From now on, Geistlich Pharma PTY Ltd. will supply and serve specialists in oral hard and soft tissue regeneration, whereas Henry Schein as the distribution partner will concentrate on the general dental practitioners.
<G-vec00859-002-s391><concentrate.sich_konzentrieren><de> Künftig beliefert und betreut Geistlich Pharma PTY Ltd. Spezialisten der Hart- und Weichgeweberegeneration, während sich Henry Schein als Distributionspartner auf allgemein praktizierende Zahnärzte konzentriert.
<G-vec00859-002-s392><concentrate.sich_konzentrieren><en> Better results can be achieved if you concentrate on the essential issues.
<G-vec00859-002-s392><concentrate.sich_konzentrieren><de> Bessere Ergebnisse kann man dann erzielen, wenn man sich auf das Wesentliche konzentriert.
<G-vec00859-002-s393><concentrate.sich_konzentrieren><en> If you concentrate on one of them you will automatically jeopardise the achievement of the others.
<G-vec00859-002-s393><concentrate.sich_konzentrieren><de> Wer sich auf eines konzentriert, benachteiligt naturgemäß die Erreichbarkeit der anderen.
<G-vec00859-002-s394><concentrate.sich_konzentrieren><en> The Full Moon accelerates plant growth, so plants grow more vigorously during this time. The gravitational force of the moon also makes the sap move upwards and concentrate in their leaves, buds and upper parts, leaving the roots energy-deprived.
<G-vec00859-002-s394><concentrate.sich_konzentrieren><de> Doch Vollmond sorgt nicht nur dafür, dass sie stärker wachsen; die Gravitationskraft des Mondes lässt den Saft eurer Pflanzen nach oben strömen, wobei er sich in den Blättern, Buds und höheren Teilen konzentriert und die Energie aus den Wurzeln schwindet.
<G-vec00859-002-s395><concentrate.sich_konzentrieren><en> The vicious circle of violence can be broken by healing justice which does not concentrate exclusively on the punishment of the perpetrator alone, necessary as it is, but supports the victims of violence and their families and makes efforts to combat the causes of violent crimes.
<G-vec00859-002-s395><concentrate.sich_konzentrieren><de> Eine heilende Gerechtigkeit, die sich nicht auf die notwendige Bestrafung der Täter allein konzentriert, sondern Opfer von Gewalttaten und deren Angehörige unterstützt und sich für die Bekämpfung der Ursachen von Gewaltverbrechen einsetzt, kann dagegen den Teufelskreis der Gewalt durchbrechen.
<G-vec00859-002-s396><concentrate.sich_konzentrieren><en> Partial successes are most common, if one does not concentrate exactly.
<G-vec00859-002-s396><concentrate.sich_konzentrieren><de> Teilerfolge sind am häufigsten, wenn man sich nicht genau konzentriert..
<G-vec00859-002-s397><concentrate.sich_konzentrieren><en> While these Japanese giants (they are the fifth largest games company in the world) still concentrate on software titles for PCs and consoles, they are responsible for a handful of popular pokie games, including Rocky, Money in the Bank and Lucky Dice.
<G-vec00859-002-s397><concentrate.sich_konzentrieren><de> Obwohl dieser japanische Riese (es ist das fünftgrößte Spiele-Unternehmen der Welt) sich noch immer auf Software-Titel für PCs und Konsolen konzentriert, ist die Firma für eine Handvoll beliebter Slots-Spiele verantwortlich, einschließlich Rocky, Money in the Bank und Lucky Dice.
<G-vec00859-002-s398><concentrate.sich_konzentrieren><en> Memories only seem to be colourful at first; the more you concentrate, the paler their tinting becomes, until at last they fade to black and white, or vanish altogether.
<G-vec00859-002-s398><concentrate.sich_konzentrieren><de> Erinnerungen erscheinen zunächst farbig zu sein, aber je stärker man sich auf sie konzentriert, umso blasser wird das Kolorit, bis es umschlägt in Schwarzweiss oder das Bild völlig verschwindet.
<G-vec00859-002-s399><concentrate.sich_konzentrieren><en> The role of the poster is of indispensable value in postmodern times whose overwhelming flood of images tends to make people confused, as posters concentrate on only essential information.
<G-vec00859-002-s399><concentrate.sich_konzentrieren><de> Gerade angesichts der überbordenden Bilderflut der Postmoderne, die dazu führt, dass der Mensch den Überblick verliert, ist das Plakat, das sich auf das Wesentliche konzentriert, von unverzichtbarem Wert.
<G-vec00859-002-s400><concentrate.sich_konzentrieren><en> It is no coincidence that Morrison does not wish to be a design hero, wants as a person to remain low key and prefers to concentrate on his work than on communicating it.
<G-vec00859-002-s400><concentrate.sich_konzentrieren><de> Dass Morrison kein Held des Designs sein möchte, sich entsprechend als Person zurücknimmt und sich lieber auf die eigene Arbeit als auf deren Kommunikation konzentriert, kommt nicht von ungefähr.
<G-vec00859-002-s401><concentrate.sich_konzentrieren><en> We really tried to aim for something more dynamic that would concentrate on the combat.
<G-vec00859-002-s401><concentrate.sich_konzentrieren><de> Wir haben versucht, etwas Dynamischeres zu schaffen, das sich völlig auf den Kampf konzentriert.
<G-vec00859-002-s402><concentrate.sich_konzentrieren><en> Since there are many plants that suit the white-tailed bumblebee with its short mouth parts, a conclusion could be that the species does not concentrate on a few nectar plants but visits many flowers, exploring and pollinating them.
<G-vec00859-002-s402><concentrate.sich_konzentrieren><de> Weil es viele Pflanzen gibt, die der hellgelben Erdhummel mit ihrem kurzen Mundwerkzeug gelegen kommen, könnte der Schluss gezogen werden, dass sich die Art nicht auf einige wenige Nektarpflanzen konzentriert, sondern viele Blumen besucht, sie erkundet und bestäubt.
<G-vec00859-002-s403><concentrate.sich_konzentrieren><en> Our presence here today very clearly expresses our sincere desire to remove all the ecclesial obstacles that are not dogmatic or essential, so that we may concentrate our concern on the study of the essential differences and dogmatic truths that have divided our Churches until now, as well as on the way of living the Christian truth of the united Church.
<G-vec00859-002-s403><concentrate.sich_konzentrieren><de> Unsere heutige Anwesenheit hier drückt in aller Deutlichkeit unser aufrichtiges Verlangen nach der Überwindung aller kirchlichen Hindernisse aus, die nicht dogmatischer und wesensmäßiger Natur sind, damit sich unser Interesse auf das Studium der wesentlichen Unterschiede und der dogmatischen Wahrheiten konzentriert, die bis heute unseren Kirchen gemeinsam sind, sowie auf die Art und Weise, die christliche Wahrheit der geeinten Kirche zu leben.
<G-vec00859-002-s404><concentrate.sich_konzentrieren><en> The focus areas of Ecofys and Wageningen University complement each other ideally: while Ecofys will provide expert knowledge of the UN climate negotiations and policies in the energy sector, Wageningen University will concentrate on non-CO2 emissions and forestry.
<G-vec00859-002-s404><concentrate.sich_konzentrieren><de> Die Kernkompetenzen von Ecofys und der Universität ergänzen sich dabei ideal: Ecofys wird vor allem Fachwissen zu den UN Klimaverhandlungen und Politiken im Energiesektor beisteuern, während die Universität Wageningen sich auf nicht-CO2 Emissionen und Forstwirtschaft konzentriert.
<G-vec00859-002-s405><concentrate.sich_konzentrieren><en> He spoke slowly, and so quietly that one had to concentrate to hear him in the noisy canteen.
<G-vec00859-002-s405><concentrate.sich_konzentrieren><de> Er sprach langsam und so leise vor sich hin, dass man ihm in der lauten Kantine, konzentriert zuhören musste, um mitzukommen.
<G-vec00859-002-s406><concentrate.sich_konzentrieren><en> Increasingly it seems that a company concentrate solely on the speed of the new mounter that should be purchased.
<G-vec00859-002-s406><concentrate.sich_konzentrieren><de> Es kann vorkommen, dass sich eine Firma ausschließlich auf die Geschwindigkeit des neu zu erwerbenden Bestückers konzentriert.
<G-vec00859-002-s407><concentrate.sich_konzentrieren><en> In 2012 NIVELCO Process Control Co. celebrates its 30th anniversary. On this occasion NIVELCO Company profile 2012 is launched to introduce the company founded in 1982 to concentrate on the manufacture of industrial level measurement and control products.
<G-vec00859-002-s407><concentrate.sich_konzentrieren><de> Anlässlich dieser Gelegenheit bringen wir das NIVELCO Firmenprofil 2012 heraus um die Firma, die 1982 gegründet wurde und sich auf die Entwicklung und Herstellung von Füllstandmess- und Regelgeräten konzentriert, vorzustellen.
<G-vec00859-002-s430><concentrate.sich_konzentrieren><en> The bankers wish us to forget all this and concentrate on the urgency of saving the banks.
<G-vec00859-002-s430><concentrate.sich_konzentrieren><de> Nun wollen all die Banken, dass wir dies mal eben vergessen und uns auf die Dringlichkeit der Rettung der Banken konzentrieren.
<G-vec00859-002-s431><concentrate.sich_konzentrieren><en> Geoff Simmonds enthuses: “Thanks to our collaboration with Linde, we can concentrate on what is really important to us, and don’t have to worry about things outside of our core business.”
<G-vec00859-002-s431><concentrate.sich_konzentrieren><de> Geoff Simmonds ist begeistert: Durch die Zusammenarbeit mit Linde können wir uns auf das konzentrieren, was wirklich wichtig ist und müssen uns nicht mehr über Dinge den Kopf zerbrechen, die nicht zu unserem Kerngeschäft gehören.
<G-vec00859-002-s432><concentrate.sich_konzentrieren><en> But more importantly we were taught the importance of a clear mind bereft of unsavoury thoughts and ability to concentrate.
<G-vec00859-002-s432><concentrate.sich_konzentrieren><de> Als viel wichtiger wurde uns der Wert eines klaren Geistes ohne schwer verdauliche Gedanken beigebracht und die Fähigkeit, uns zu konzentrieren.
<G-vec00859-002-s433><concentrate.sich_konzentrieren><en> As a leading provider of professional German translations, we will concentrate on what we do best, allowing you to do what you do best.
<G-vec00859-002-s433><concentrate.sich_konzentrieren><de> Als führender Anbieter von professionellen Übersetzungen in die und aus der deutschen Sprache werden wir uns auf das konzentrieren, was wir am besten können, damit Sie das tun können, was Sie am besten können.
<G-vec00859-002-s434><concentrate.sich_konzentrieren><en> That, therefore, is precisely what we should now concentrate on.
<G-vec00859-002-s434><concentrate.sich_konzentrieren><de> Genau darauf sollten wir uns deshalb jetzt auch konzentrieren.
<G-vec00859-002-s435><concentrate.sich_konzentrieren><en> In addition to the characteristics mentioned already – to persevere and stay the course – we were given particular advice regarding financing. We were advised to not concentrate too much on our own shares in the beginning, and to collect as much investment capital as possible instead.
<G-vec00859-002-s435><concentrate.sich_konzentrieren><de> Neben der bereits erwähnten Eigenschaft, beharrlich zu bleiben und durchzuhalten, wurde uns insbesondere zum Thema Finanzierung geraten, uns am Anfang nicht zu sehr auf die eigenen Anteile zu konzentrieren, sondern alles Investitionskapital mitzunehmen, das wir kriegen können.
<G-vec00859-002-s436><concentrate.sich_konzentrieren><en> We need to concentrate instead on that part of our mission which is still ahead of us, yet to be fulfilled. 3.
<G-vec00859-002-s436><concentrate.sich_konzentrieren><de> Wir müssen uns auf den Teil unseres Auftrags konzentrieren, der noch vor uns liegt, statt auf den, der schon ausgeführt worden ist.
<G-vec00859-002-s437><concentrate.sich_konzentrieren><en> Only by differentiation, thus distinguishing what is important and what is not, we can concentrate on the essentials and are able to act.
<G-vec00859-002-s437><concentrate.sich_konzentrieren><de> Erst indem wir differenzieren, also unterscheiden, was wichtig und was unwichtig ist, können wir uns auf das Wesentliche konzentrieren und werden dadurch handlungsfähig.
<G-vec00859-002-s438><concentrate.sich_konzentrieren><en> Our strategic focus means we concentrate on issues of long-term, sustainable development of firms, both shaping and being shaped by their (economic, social, and natural) environment.
<G-vec00859-002-s438><concentrate.sich_konzentrieren><de> Unser strategischer Fokus bedeutet, dass wir uns auf die langfristige und nachhaltige Entwicklung von Unternehmen konzentrieren, die von ihrer (ökonomischen, sozialen und natürlichen) Umwelt beeinflusst werden als auch diese selbst beeinflussen.
<G-vec00859-002-s439><concentrate.sich_konzentrieren><en> There is single-pointed meditation like for instance, Vipassana or Zen meditation where we concentrate on one point (e.g., an object or the breath) without letting our minds wander.
<G-vec00859-002-s439><concentrate.sich_konzentrieren><de> Es gibt einsgerichtete Meditation, wie zum Beispiel Vipassana- oder Zen-Meditation, bei denen wir uns auf einen Punkt (zum Beispiel ein Gegenstand oder den Atem) konzentrieren, ohne den Geist abschweifen zu lassen.
<G-vec00859-002-s440><concentrate.sich_konzentrieren><en> Cigar wooden box is the cigar accessores, and we never leave the cigar box when we are concentrate on cigars,
<G-vec00859-002-s440><concentrate.sich_konzentrieren><de> Zigarrenholzkiste ist der Zugang zu Zigarren, und wir verlassen die Zigarrenschachtel niemals, wenn wir uns auf Zigarren konzentrieren.
<G-vec00859-002-s441><concentrate.sich_konzentrieren><en> Since we have previously discussed the different types of stereo microscope, we will now concentrate on the different types of mono, compound microscopes.
<G-vec00859-002-s441><concentrate.sich_konzentrieren><de> Da wir die unterschiedlichen Stereomikroskoptypen bereits eingehend besprochen haben, werden wir uns nun auf die verschiedenen Mono, Compound Mikroskope konzentrieren.
<G-vec00859-002-s442><concentrate.sich_konzentrieren><en> Due to its widespread popularity and ease of use, in the rest of this activity we will concentrate specifically on Skype, although much of the general information is also relevant for the other audio-conferencing tools.
<G-vec00859-002-s442><concentrate.sich_konzentrieren><de> Infolge ihrer weitverbreiteten Popularität und einfachen Benutzung werden wir uns in dem restlichen Teil dieser Aktivität speziell auf Skype konzentrieren, obwohl der größte Teil der generellen Informationen auch für andere Audio-Konferenz-Tools relevant ist.
<G-vec00859-002-s443><concentrate.sich_konzentrieren><en> We want to concentrate on what the customer really needs.
<G-vec00859-002-s443><concentrate.sich_konzentrieren><de> Wir wollen uns auf das konzentrieren, was der Kunde wirklich braucht.
<G-vec00859-002-s444><concentrate.sich_konzentrieren><en> "In the years to come, we want to concentrate even more strongly on the central future topics of the automotive industry," explains HELLA CEO Dr. Rolf Breidenbach.
<G-vec00859-002-s444><concentrate.sich_konzentrieren><de> "Wir wollen uns zukünftig noch stärker auf die zentralen Zukunftsthemen der Automobilbranche konzentrieren", sagt Dr. Rolf Breidenbach, Vorsitzender der HELLA Geschäftsführung.
<G-vec00859-002-s445><concentrate.sich_konzentrieren><en> We will review each site, making sure to concentrate on factors that are important to a player.
<G-vec00859-002-s445><concentrate.sich_konzentrieren><de> Wir bewerten jede Website, wobei wir darauf achten, dass wir uns auf jene für Spieler wichtige Faktoren konzentrieren.
<G-vec00859-002-s446><concentrate.sich_konzentrieren><en> Ever since the beginning of the fighting – meaning any fighting in the last years, but let's concentrate on the recent escalation of violence between Israel and Hamas in Gaza – all major TV channels in Israel switch their normal programming to 24-hour "special" news programs, and in the "special" news programs we get a loop of recent pictures: grainy rockets move through a night sky, a hole in the ceiling of a hit house, a group of reserve soldiers lazying around, waiting for instructions.
<G-vec00859-002-s446><concentrate.sich_konzentrieren><de> Seit Beginn der Kämpfe – eigentlich aller Kämpfe der vergangenen Jahre –, doch wir wollen uns auf die aktuelle Gewalteskalation zwischen Hamas und Gaza konzentrieren – haben alle großen TV-Sender ihr normales Programm durch ein 24-Stunden "Sonder"-Nachrichtenprogramm ersetzt, welches in Dauerschleife die aktuellsten Bilder liefert: eine über den Nachthimmel fliegende Rakete, ein Loch im Dach eines getroffenen Hauses, eine Gruppe träge herumsitzender und auf Instruktionen wartender Reservesoldaten.
<G-vec00859-002-s447><concentrate.sich_konzentrieren><en> In the future, we will concentrate more strongly on what we do best and continue to develop Jenoptik to a focused photonics company.
<G-vec00859-002-s447><concentrate.sich_konzentrieren><de> Wir wollen uns künftig noch stärker auf das konzentrieren, was wir am besten können und so die Jenoptik zu einem fokussierten Photonik-Konzern weiterentwickeln.
<G-vec00859-002-s448><concentrate.sich_konzentrieren><en> The effect of this is similar to rebooting a computer: If the activity of the prefrontal cortex is temporarily shut down, we can concentrate better during the movement and think more clearly afterwards.
<G-vec00859-002-s448><concentrate.sich_konzentrieren><de> Die Wirkung dessen ist ähnlich einem Neustart bei einem Computer: Wird die Aktivität des präfrontalen Cortex zeitweise runtergefahren, können wir uns danach besser konzentrieren und klarer denken.
