<G-vec00118-002-s025><downgrade.degradieren><en> Through this migration programme, the former dictator Suharto (in power from 1967 to 1998) planned on the one hand to relieve the population pressure on overcrowded islands such as Java, and at the same time to downgrade the native peoples of Papua to a minority status.
<G-vec00118-002-s025><downgrade.degradieren><de> Der ehemaligen Diktator Suharto (an der Macht von 1967 bis 1998) plante, mit den Umsiedlungen einerseits die überbevölkerten Inseln wie Java zu entlasten und andererseits die indigene Bevölkerung Papuas zu einer Minderheit zu degradieren.
<G-vec00118-002-s026><downgrade.degradieren><en> Never take Growth Hormone close to bedtime as this will eventually downgrade the natural productions.
<G-vec00118-002-s026><downgrade.degradieren><de> Nehmen Sie nie Wachstums-Hormon nah an Schlafenszeit, da dieses schließlich die natürlichen Produktionen degradiert.
<G-vec00118-002-s020><downgrade.downgraden><en> During or after this trial, you can either purchase Explore Professional or downgrade to the free version, Explore Lite.
<G-vec00118-002-s020><downgrade.downgraden><de> Nach Ablauf des Testzeitraums können Sie entweder Explore Professional abonnieren oder auf die kostenlose Version, Explore Lite, downgraden.
<G-vec00118-002-s022><downgrade.downgraden><en> You can upgrade or downgrade your plan at any time.
<G-vec00118-002-s022><downgrade.downgraden><de> Sie können Ihren Account jederzeit upgraden oder downgraden.
<G-vec00118-002-s028><downgrade.downgraden><en> It is worth noting that in order for the automatic update to work, the computer must be connected to the Internet (perhaps when connecting the MESSOA device the computer temporarily did not have the Internet connection or a WiFi signal was weak making it impossible to download the MESSOA LPR606 IP Camera Firmware Downgrade driver).
<G-vec00118-002-s028><downgrade.downgraden><de> Es lohnt sich daran zu denken, dass damit die automatische Aktualisierung funktionieren könnte, der Computer an das Internet angeschlossen sein muss (kann sein, dass während des Anschließens des Geräts MESSOA der Computer momentan keine Internetverbindung hatte, oder das WLAN Signal zu schwach war, was das Downloaden des Treibers MESSOA LPR606 IP Camera Firmware Downgrade nicht möglich machte).
<G-vec00118-002-s029><downgrade.downgraden><en> CentOS Solaris, FreeBSD Knowledgebase-Artikel How to downgrade license keys in My VMware.
<G-vec00118-002-s029><downgrade.downgraden><de> Informationen hierzu finden Sie im Knowledgebase-Artikel How to downgrade license keys in My VMware.
<G-vec00118-002-s030><downgrade.downgraden><en> The steps to downgrade a BIOS to an older version are exactly the same as for upgrading to a newer version.
<G-vec00118-002-s030><downgrade.downgraden><de> Die Schritte zum Downgrade eines BIOS auf eine ältere Version sind genau die gleichen wie beim Upgrade auf eine neuere Version.
<G-vec00118-002-s031><downgrade.downgraden><en> Up- or downgrade your subscription at any time.
<G-vec00118-002-s031><downgrade.downgraden><de> Ein Up- oder Downgrade des Abonnements ist jederzeit möglich.
<G-vec00118-002-s032><downgrade.downgraden><en> ⬇To downgrade from Plus to the Standard plan, choose Change to the Standard plan.
<G-vec00118-002-s032><downgrade.downgraden><de> ⬇Wenn du ein Downgrade von Plus auf den Standard-Plan vornehmen möchtest, wähle Zum Standard-Plan wechseln aus.
<G-vec00118-002-s033><downgrade.downgraden><en> If a BIOS with Intel® ME must be downgraded and the downgrade will affect the Intel® ME version, the Recovery BIOS Update is the only method you can use.
<G-vec00118-002-s033><downgrade.downgraden><de> Wenn ein BIOS mit Intel® Me heruntergestuft werden muss und sich die Downgrade auf die Intel® Me-Version auswirkt, ist das Wiederherstellungs-BIOS-Update die einzige Methode, die Sie verwenden können.
<G-vec00118-002-s034><downgrade.downgraden><en> The rights granted in this terms do not include the right to use a previous version of the software than the purchased version (no “downgrade right”).
<G-vec00118-002-s034><downgrade.downgraden><de> Die in diesem Supportvertrag gewährten Rechte beinhalten nicht das Recht, anstelle der erworbenen Softwareversion eine Vorgängerversion der Software zu nutzen (kein Downgrade Recht).
<G-vec00118-002-s035><downgrade.downgraden><en> I haven’t found a solution except downgrade yet.
<G-vec00118-002-s035><downgrade.downgraden><de> Eine Lösung außer Downgrade habe ich noch nicht gefunden.
<G-vec00118-002-s036><downgrade.downgraden><en> Upgrade / Downgrade or Cancel at any time.
<G-vec00118-002-s036><downgrade.downgraden><de> Jederzeit Upgrade, Downgrade oder Kündigung möglich.
<G-vec00118-002-s037><downgrade.downgraden><en> The downgrade takes effect after your current monthly or annual subscription ends.
<G-vec00118-002-s037><downgrade.downgraden><de> Das Downgrade wird wirksam, sobald Ihr aktuelles Monats- oder Jahresabonnement abläuft.
<G-vec00118-002-s038><downgrade.downgraden><en> The included Windows XP Professional downgrade DVD that is included, with which Windows Vista can be waivered on if wanted, should be interesting for a few companies and users who still rely on Windows XP.
<G-vec00118-002-s038><downgrade.downgraden><de> Interessant für einige Unternehmen und User, die noch auf Windows XP setzen, ist die beigelegte Windows XP Professional Downgrade DVD, mit der man bei Bedarf auf Windows Vista verzichten kann.
<G-vec00118-002-s039><downgrade.downgraden><en> A downgrade to Windows XP is possible according to the manufacturer, corresponding drivers are made available for download on their website when supplying the serial number (unverified).
<G-vec00118-002-s039><downgrade.downgraden><de> Ein Downgrade auf Windows XP ist laut Hersteller möglich, entsprechende Treiber werden (unüberprüfterweise), unter Angabe der Seriennummer auf der Herstellerseite zum Download zur Verfügung gestellt.
<G-vec00118-002-s040><downgrade.downgraden><en> That means that anyone wishing to upgrade or downgrade to iOS 8.1.1 can no longer do so.
<G-vec00118-002-s040><downgrade.downgraden><de> Achtung werte Jailbreaker, ein Update oder Downgrade auf iOS 8.1.1 beziehungsweise die Wiederherstellung auf diese Version ist nicht mehr möglich.
<G-vec00118-002-s041><downgrade.downgraden><en> After installing this firmware, a downgrade to an earlier firmware version is not possible.
<G-vec00118-002-s041><downgrade.downgraden><de> Nach Installation dieser Firmware ist ein Downgrade zu einer früheren Firmware-Version nicht möglich.
<G-vec00118-002-s042><downgrade.downgraden><en> Manufacturers from time to time issue new versions of the MESSOA LPR606 IP Camera Firmware Downgrade software, repairing the errors they find that may cause problems with the MESSOA devices.
<G-vec00118-002-s042><downgrade.downgraden><de> Die Produzenten geben von Zeit zu Zeit neue Versionen der Software MESSOA LPR606 IP Camera Firmware Downgrade heraus.
<G-vec00118-002-s043><downgrade.downgraden><en> The downgrade in the USA was quickly made the scapegoat, but this downgrade was more than overdue and not really a surprise to the market.
<G-vec00118-002-s043><downgrade.downgraden><de> Schnell war das Downgrade der USA als Übeltäter ausgemacht, doch war diese Herabstufung eher überfällig, als für die Märkte überraschend.
<G-vec00118-002-s044><downgrade.downgraden><en> If this has not happened, without a manual MESSOA LPR606 IP Camera Firmware Downgrade driver installation your device may not work properly or may not use all of its features.
<G-vec00118-002-s044><downgrade.downgraden><de> Wenn es so nicht gekommen ist, dann kann Ihr Gerät ohne die manuelle Installation des Treibers MESSOA LPR606 IP Camera Firmware Downgrade nicht richtig funktionieren, oder kann alle seine Möglichkeiten nicht nutzen.
<G-vec00118-002-s045><downgrade.downgraden><en> Hewn (downgrade) PERFECTLY all kinds of leathers, Gamuzones, and Other Synthetic Materials.
<G-vec00118-002-s045><downgrade.downgraden><de> Hewn (Downgrade) PERFEKT alle Arten von Leder, Gamuzones und anderen synthetischen Materialien.
<G-vec00118-002-s046><downgrade.downgraden><en> Plan Management: Enables the creation of packages with various up- and downgrade strategies, different signup flows, specific consumer vouchers, discounts, one-off charge, etc.
<G-vec00118-002-s046><downgrade.downgraden><de> Plan Management: Ermöglicht die Erstellung von Paketen mit diversen Up- and Downgrade Strategien, unterschiedlichen Signup-Flows, kundenspezifischen Gutscheinen, Rabatten, einmaligen Gebühren, etc.
<G-vec00118-002-s047><downgrade.downgraden><en> Move all the products for which this upgrade applies from the first column in the table to the second column entitled Downgrade from.
<G-vec00118-002-s047><downgrade.downgraden><de> Ziehen Sie alle Produkte, auf die dieses Downgrade anwendbar sein soll, von der ersten Spalte der Tabelle in die Spalte Downgrade von.
<G-vec00118-002-s048><downgrade.downgraden><en> A small downgrade in size and weight.
<G-vec00118-002-s048><downgrade.downgraden><de> Ein kleines Downgrade in Sachen Größe und Gewicht.
<G-vec00118-002-s061><downgrade.downgraden><en> If you downgrade to a lower paying plan, you will be charged the new plan immediately and your old plan will stop billing.
<G-vec00118-002-s061><downgrade.downgraden><de> Wenn Sie zu einem günstigeren Tarif downgraden, zahlen Sie sofort den neuen Tarif während der bisherige Tarif nicht weiter berechnet wird.
<G-vec00118-002-s062><downgrade.downgraden><en> If you wish to downgrade your phone, then you can change its system version before clicking on the “Start” button.
<G-vec00118-002-s062><downgrade.downgraden><de> Wenn Sie Ihr Telefon downgraden möchten, können Sie dessen Systemversion ändern, bevor Sie auf die Schaltfläche "Starten" klicken.
<G-vec00118-002-s063><downgrade.downgraden><en> In this case, we will pick the standard mode as we wish to downgrade from iOS Beta without any loss of data.
<G-vec00118-002-s063><downgrade.downgraden><de> In diesem Fall wählen wir den Standardmodus, da wir von iOS Beta ohne Datenverlust downgraden möchten.
<G-vec00118-002-s064><downgrade.downgraden><en> In such case, it is better you downgrade your iPhone to the previous version.
<G-vec00118-002-s064><downgrade.downgraden><de> In diesem Fall sollten Sie Ihr iPhone auf die vorherige Version downgraden.
<G-vec00118-002-s065><downgrade.downgraden><en> Let your dealer downgrade your device.
<G-vec00118-002-s065><downgrade.downgraden><de> Lassen Sie das Gerät von Ihrem Fachhändler downgraden.
<G-vec00118-002-s066><downgrade.downgraden><en> The Essentials subscription you can customize, order, up- and downgrade or cancel at any time in the online shop.
<G-vec00118-002-s066><downgrade.downgraden><de> Die Essentials kannst du hier im Online Shop beliebig konfigurieren, bestellen, jederzeit flexibel up- und downgraden sowie kündigen.
<G-vec00118-002-s067><downgrade.downgraden><en> iMyFone Fixppo enables you to downgrade your iOS to the previous version without jailbreak if you don't like the latest version released by Apple.
<G-vec00118-002-s067><downgrade.downgraden><de> Mit iMyFone Fixppo können Sie Ihr iOS auf die vorherige Version ohne Jailbreak downgraden, wenn Ihnen die neueste Version von Apple nicht gefällt.
<G-vec00118-002-s068><downgrade.downgraden><en> Upgrade, downgrade, or cancel any time.
<G-vec00118-002-s068><downgrade.downgraden><de> Jederzeit upgraden, downgraden oder kündigen.
<G-vec00118-002-s069><downgrade.downgraden><en> But a priori from a factory reset in 1.5.3 (without reflashing by usb) there the Store is HS and I need to downgrade again....
<G-vec00118-002-s069><downgrade.downgraden><de> Aber a priori von einem Werksreset in 1.5.3 (ohne erneutes Flashen durch USB) dort ist der Store HS und ich muss erneut downgraden....
<G-vec00118-002-s070><downgrade.downgraden><en> Check here how you can upgrade and downgrade.
<G-vec00118-002-s070><downgrade.downgraden><de> Hier erklären wir, wie das Upgraden und Downgraden funktioniert.
<G-vec00118-002-s071><downgrade.downgraden><en> Therefore you will not be able to downgrade back to an older version of the plugin.
<G-vec00118-002-s071><downgrade.downgraden><de> Aus diesem Grund ist ein Downgraden auf die vorherige Version des Plugins nicht möglich.
<G-vec00118-002-s073><downgrade.downgraden><en> The software is an indispensable tool that allows Apple users to save their iOS devices' SHSH files in order to fix a faulty or buggy firmware or downgrade to an older version of iOS even after Apple has "kick out" the old iOS version from entering the Apple universe.
<G-vec00118-002-s073><downgrade.downgraden><de> Die Software ist ein unverzichtbares Hilfsmittel, das es Apple-Nutzern ermöglicht, die SHSS-Dateien ihres iOS-Geräts zu speichern, um eine fehlerhafte oder verbuggte Firmware zu reparieren oder auf eine ältere Version von iOS downzugraden, selbst nachdem Apple die alte iOS-Version „vor die Tür gesetzt“ hat und sie nicht mehr im Apple-Universum zulässt.
<G-vec00118-002-s074><downgrade.downgraden><en> If the given language does not exist, or no translation data is available for the language, setLocale() tries to downgrade to the language without the region if any was given.
<G-vec00118-002-s074><downgrade.downgraden><de> Wenn die angegebene Sprache nicht existiert oder keine übersetzten Daten für diese Sprache vorhanden sind, versucht setLocale() auf die Sprache ohne Region downzugraden, wenn diese angegeben wurde.
<G-vec00118-002-s075><downgrade.downgraden><en> Find in this article 2 essential guides to downgrade iOS 14 without hassle.
<G-vec00118-002-s075><downgrade.downgraden><de> In diesem Artikel finden Sie 2 einfache Anleitungen, um iOS 14 ohne Probleme downzugraden.
<G-vec00118-002-s077><downgrade.downgraden><en> Unfortunately it is not possible to downgrade to a lower firmware version.
<G-vec00118-002-s077><downgrade.downgraden><de> Ein Downgrade auf eine niedrigere Firmwareversion ist leider nicht möglich.
<G-vec00118-002-s078><downgrade.downgraden><en> If you wish to downgrade to older versions of MySQL/InnoDB, you can request the old format with ROW_FORMAT=REDUNDANT.
<G-vec00118-002-s078><downgrade.downgraden><de> Wenn Sie ein Downgrade auf eine ältere MySQL-Version durchführen wollen, können Sie das alte Format mit ROW_FORMAT=REDUNDANT anfordern.
<G-vec00118-002-s079><downgrade.downgraden><en> Note: If you intend to use 5MP image sensors on an M15, D15 or S15 camera that is currently running this software release, you need to downgrade the camera to the newest software release 4.3.2.77 for 5MP cameras.
<G-vec00118-002-s079><downgrade.downgraden><de> Hinweis: Wenn eine Kamera vom Typ M15, D15 oder S15, auf der schon diese Software-Version läuft, mit 5MP-Sensoren betrieben werden soll, muss ein Downgrade auf die neueste auch für 5MP-Sensoren freigegebene Version 4.3.2.77 durchgeführt werden.
<G-vec00118-002-s080><downgrade.downgraden><en> If you want to downgrade, you need to cancel your current subscription, and subscribe again to the new one.
<G-vec00118-002-s080><downgrade.downgraden><de> Für ein Downgrade musst du dein aktuelles Abo kündigen und dich für ein neues registrieren.
<G-vec00118-002-s081><downgrade.downgraden><en> WebServer Dedicated *It is only possible to downgrade from WebServer Dedicated to WebHosting or WebServer upon expiry of minimum contract lifetime.
<G-vec00118-002-s081><downgrade.downgraden><de> *Ein Downgrade von WebServer Dedicated in eine der beiden anderen Produktgruppen ist erst nach Ablauf der Mindestvertragslaufzeit möglich.
<G-vec00118-002-s087><downgrade.downgraden><en> However, you can still login and renew the subscription anytime or downgrade back to FREE.
<G-vec00118-002-s087><downgrade.downgraden><de> Sie können sich allerdings weiterhin anmelden und jederzeit das Abonnement fortsetzen oder wieder auf FREE downgraden.
<G-vec00118-002-s130><downgrade.downgraden><en> You can identify your downgrade using the upgrade ID.
<G-vec00118-002-s130><downgrade.downgraden><de> Mit der Upgrade-ID können Sie Ihr Downgrade identifizieren.
<G-vec00118-002-s089><downgrade.herabstufen><en> After the expiration date, your account will then downgrade to a LastPass Free account, which will still provide you with access to all of your passwords and stored data within your Vault but will no longer allow you to use Premium features.
<G-vec00118-002-s089><downgrade.herabstufen><de> Nach dem Ablaufdatum wird Ihr Konto auf ein LastPass-Free-Konto herabgestuft, das Ihnen weiterhin Zugriff auf Ihre gesamten Passwörter und gespeicherten Daten in Ihrem Vault bietet, Ihnen jedoch die Nutzung der Premium-Funktionen nicht mehr ermöglicht.
<G-vec00118-002-s090><downgrade.herabstufen><en> You can easily upgrade, downgrade, or cancel your plan when your needs change.
<G-vec00118-002-s090><downgrade.herabstufen><de> Sie können den Plan problemlos heraufstufen, herabstufen oder beenden, wenn sich Ihre Anforderungen ändern.
<G-vec00118-002-s091><downgrade.herabstufen><en> "When these agencies opportunistically downgrade a country's rating, the consequences are enormous and they make it particularly difficult for governments to deal successfully with problems.
<G-vec00118-002-s091><downgrade.herabstufen><de> Wenn diese Agenturen das Rating eines Landes in opportunistischer Weise herabstufen, sind die Folgen enorm, und sie machen es für die Regierungen besonders schwer, Probleme erfolgreich anzugehen.
<G-vec00118-002-s092><downgrade.herabstufen><en> We will also share how you can prevent these cookies from being stored however this may downgrade or 'break' certain elements of the functionality of the site.
<G-vec00118-002-s092><downgrade.herabstufen><de> Wir teilen auch mit, wie Sie verhindern können, dass diese Cookies gespeichert werden, dies kann jedoch bestimmte Elemente der Website-Funktionalität herabstufen oder “brechen”.
<G-vec00118-002-s093><downgrade.herabstufen><en> We will also share how you can prevent these cookies from being stored however this may downgrade or 'break' certain elements of the sites functionality. How We Use Cookies
<G-vec00118-002-s093><downgrade.herabstufen><de> Wir werden auch mitteilen, wie Sie verhindern können, dass diese Cookies gespeichert werden, dies kann jedoch bestimmte Elemente der Website-Funktionalität herabstufen oder "brechen".
<G-vec00118-002-s099><downgrade.herabstufen><en> Change the plan of Chat to Lite to downgrade the subscription to the free plan.
<G-vec00118-002-s099><downgrade.herabstufen><de> Ändern Sie den Plan von Chat zu Lite, um das Abonnement auf einen kostenlosen Plan herabzustufen.
<G-vec00118-002-s100><downgrade.herabstufen><en> However, a marginally less favourable environment forces theScreener to downgrade slightly the title, which now shows an overall rating of Slightly Positive.
<G-vec00118-002-s100><downgrade.herabstufen><de> Ein weniger günstiges Umfeld zwingt theScreener jedoch dazu, den Titel leicht herabzustufen, der jetzt den Gesamteindruck Eher Positiv erreicht.
<G-vec00118-002-s112><downgrade.herabstufen><en> You can upgrade, downgrade or cancel your chosen Subscription Plan through our website.
<G-vec00118-002-s112><downgrade.herabstufen><de> Du kannst das von dir ausgewählte Abonnement über unsere Website hinaufstufen, herabstufen oder stornieren.
<G-vec00118-002-s126><downgrade.herabstufen><en> Downgrade the agent by selecting End-user as the new Role.
<G-vec00118-002-s126><downgrade.herabstufen><de> Stufen Sie den Agenten herab, indem Sie Endbenutzer als neue Rolle auswählen.
<G-vec00118-002-s101><downgrade.herunterstufen><en> We will also share how you can prevent these cookies from being stored however this may downgrade or 'break' certain elements of the sites functionality.
<G-vec00118-002-s101><downgrade.herunterstufen><de> Wir werden auch mitteilen, wie Sie verhindern können, dass diese Cookies gespeichert werden, was jedoch dazu führen kann, dass bestimmte Elemente der Funktionalität der Website heruntergestuft oder unterbrochen werden.
<G-vec00118-002-s102><downgrade.herunterstufen><en> If a member of the tournament staff gives a player erroneous information that causes them to commit a violation, the Head Judge is authorized to downgrade the penalty.
<G-vec00118-002-s102><downgrade.herunterstufen><de> Falls ein Mitglied der Turnierleitung einem Spieler falsche Informationen gibt, die dazu führen, dass der Spieler einen Regelverstoß begeht, kann der Head Judge den Penalty herunterstufen.
<G-vec00118-002-s103><downgrade.herunterstufen><en> You can cancel or downgrade your storage plan from your device at any time.
<G-vec00118-002-s103><downgrade.herunterstufen><de> Sie können Ihren Speicherplan auf Ihrem Gerät jederzeit kündigen oder herunterstufen.
<G-vec00118-002-s104><downgrade.herunterstufen><en> The application can fix all kinds of minor or major issues with iOS devices and can also downgrade them without any unwanted data loss.
<G-vec00118-002-s104><downgrade.herunterstufen><de> Die Anwendung kann alle Arten von kleinen oder großen Problemen mit iOS-Geräten beheben und sie auch ohne unerwünschten Datenverlust herunterstufen.
<G-vec00118-002-s105><downgrade.herunterstufen><en> If you have upgraded your iPhone to iOS 12 but you don’t like it and would like to downgrade it to iOS 11, then you can learn how to downgrade iOS 12 Beta to iOS 11 from the article.
<G-vec00118-002-s105><downgrade.herunterstufen><de> Wenn Sie Ihr iPhone auf iOS 12 aktualisiert haben, es aber nicht mögen und es auf iOS 11 herunterstufen möchten, dann können Sie im Artikel erfahren, wie Sie iOS 12 Beta auf iOS 11 herunterstufen können.
<G-vec00118-002-s107><downgrade.herunterstufen><en> Note: If you downgrade your plan, we're happy to transfer your credits to another workspace.
<G-vec00118-002-s107><downgrade.herunterstufen><de> Hinweis: Wenn du deinen Plan herunterstufst, können wir dein Guthaben gerne auf einen anderen Workspace übertragen.
<G-vec00118-002-s110><downgrade.herunterstufen><en> In that case you are advised to upgrade (or maybe even downgrade) the system version or automate running of the “no vstack” command.
<G-vec00118-002-s110><downgrade.herunterstufen><de> In diesem Fall wird empfohlen, die Systemversion zu aktualisieren (oder vielleicht sogar herunterzustufen) oder den Befehl no vstack zu automatisieren.
<G-vec00118-002-s111><downgrade.herunterstufen><en> Then, download the firmware Tenorshare ReiBoot provide or import those you have already saved and start to downgrade the iOS version of your iPhone.
<G-vec00118-002-s111><downgrade.herunterstufen><de> Schritt 2: Laden Sie die Firmware herunter, die von Tenorshare ReiBoot bereitgestellt wird, oder importieren Sie die bereits gespeicherten Dateien und fangen Sie an, die iOS-Version Ihres iPhones herunterzustufen.
<G-vec00118-002-s125><downgrade.herunterstufen><en> We will also share how you can prevent these cookies from being stored however this may downgrade or 'break' certain elements of the sites functionality.
<G-vec00118-002-s125><downgrade.herunterstufen><de> Wir erklären auch, wie Sie die Verwendung dieser Cookies verhindern können, die gespeichert werden, aber dies kann einige Elemente der Struktur der Website herunterstufen oder "Bruch".
<G-vec00118-002-s117><downgrade.mindern><en> We are obliged to render the tour with the granted features and without any flaws that will invalidate or downgrade the value or the qualification for ordinary benefit or benefit assumed by the contract.
<G-vec00118-002-s117><downgrade.mindern><de> Wir sind verpflichtet, die Reise so zu erbringen, dass Sie die zugesicherten Eigenschaften aufweist und nicht mit Fehlern behaftet ist, die den Wert oder die Tauglichkeit zu dem gewöhnlichen oder nach dem Vertrag vorausgesetzten Nutzen aufheben oder Mindern.
<G-vec00118-002-s121><downgrade.reduzieren><en> Downgrade all WATER monsters in both players' hands and on the field by 1 Level.
<G-vec00118-002-s121><downgrade.reduzieren><de> Reduziere die Stufe aller WASSER Monster in den Händen beider Spieler und auf dem Spielfeld um 1.
<G-vec00118-002-s114><downgrade.verringern><en> FORTRESS DOWNGRADE Each League should strive to downgrade other Leagues' Fortresses for two main reasons.
<G-vec00118-002-s114><downgrade.verringern><de> Jede Liga sollte aus zwei Gründen danach streben, die Festungen anderer Ligen im Level zu verringern.
<G-vec00118-002-s132><downgrade.verringern><en> You might need to temporarily downgrade your iCloud storage until you switch to the new country or region.
<G-vec00118-002-s132><downgrade.verringern><de> Möglicherweise müssen Sie bis zur Umstellung auf das neue Land oder die neue Region vorübergehend Ihren iCloud-Speicherplatz verringern.
