<G-vec00206-001-s076><amount.sich_belaufen><en> It is expected to amount to about EUR 3.5 billion,.
<G-vec00206-001-s076><amount.sich_belaufen><de> Sie dürften sich auf rund 3,5 Mrd EUR belaufen.
<G-vec00206-001-s077><amount.sich_belaufen><en> Requests from the EPO for related services are expected to amount to 80 times for Lot 1 and some 20 times for Lot 2 in the first contractual year; both figures are expected to decline slowly the coming years.
<G-vec00206-001-s077><amount.sich_belaufen><de> Anfragen vom EPA für entsprechende Dienste belaufen sich nach Erwartung auf 80 Mal für Los 1 und etwa 20 Mal für Los 2 im ersten Vertragsjahr: für Beide wird die kommenden Jahre mit einem langsamen Rückgang gerechnet.
<G-vec00206-001-s078><amount.sich_belaufen><en> Now, however, estimated the Ministry of Finance, the savings on interest will amount to $ 7.7 billion, including $ 3.3 billion in 2007-2009.
<G-vec00206-001-s078><amount.sich_belaufen><de> Nun aber, schГ¤tzungsweise das Ministerium der Finanzen, die Einsparungen bei den Zinsen belaufen sich auf $ 7.7 Milliarden, darunter 3,3 Milliarden Dollar im Zeitraum 2007-2009.
<G-vec00206-001-s079><amount.sich_belaufen><en> The monthly condominium fees amount to € 210 per month.
<G-vec00206-001-s079><amount.sich_belaufen><de> Die monatlichen Gebühren Eigentumswohnung zu 210 € pro Monat belaufen.
<G-vec00206-001-s080><amount.sich_belaufen><en> The investment costs for the infrastructure project amount to approximately 600 million euros.
<G-vec00206-001-s080><amount.sich_belaufen><de> Die Investitionskosten fÃ1⁄4r das Infrastrukturprojekt belaufen sich auf circa 600 Millionen Euro.
<G-vec00206-001-s081><amount.sich_belaufen><en> The Director for the development of the American continent by APM Terminals, Paul Gallie, announced that the investment will amount to about one billion dollars and that the new terminal will generate approximately one thousand direct jobs during the construction phase of 'plant and 450 during the first phase of activity of the terminal.The Government of the Central American nation has stated that the investment will be 948 million dollars, of which 648 million in the first three years for the execution of works and purchase of equipment and other distributed 300 million during the remainder of the concession, after this period, the infrastructure and port facilities will pass to the State.
<G-vec00206-001-s081><amount.sich_belaufen><de> Der Direktor für die Entwicklung des amerikanischen Kontinents durch APM Terminals, Paul Gallie, angekündigt, dass die Investition wird auf rund eine Milliarde Dollar belaufen und dass das neue Terminal wird rund tausend neue direkte Arbeitsplätze während der Bauphase zu generieren 'Pflanze und 450 in der ersten Phase der Tätigkeit des Terminals.Die Regierung des mittelamerikanischen Landes hat erklärt, dass die Investition 948 Millionen Dollar, von denen 648 Millionen in den ersten drei Jahren für die Ausführung von Bauleistungen und den Kauf von Geräten und anderen verteilten 300 Millionen während der Rest der Konzession, nachdem dieses Zeitraums wird die Infrastruktur und Hafenanlagen an den Staat übergeben.
<G-vec00206-001-s082><amount.sich_belaufen><en> The production costs of the DropStop® amount to a few centimes per piece.
<G-vec00206-001-s082><amount.sich_belaufen><de> Die Herstellungskosten des DropStop® belaufen sich auf wenige Rappen pro Stück.
<G-vec00206-001-s083><amount.sich_belaufen><en> When simultaneous operation of the computer,refrigerator, hair dryer, washing machine, iron and kettle in the shield machine work, turn off the electricity because the power in this case amount to 4.2 kilowatts.
<G-vec00206-001-s083><amount.sich_belaufen><de> Bei gleichzeitigem Betrieb des Computers,Kühlschrank, Fön, Waschmaschine, Bügeleisen und Wasserkocher in der Schildmaschine Arbeit, die Elektrizität, weil die Macht in diesem Fall belaufen sich auf 4,2 Kilowatt auszuschalten.
<G-vec00206-001-s084><amount.sich_belaufen><en> The 2 month supply or 2 containers will absolutely amount to $140 & 3 container supply amounted to $187 merely.
<G-vec00206-001-s084><amount.sich_belaufen><de> Die 2-Monats-Versorgung oder 2 Flaschen absolut belaufen sich auf $ 140 und 3 Behälter Versorgung beliefen sich bis zu $ 187 nur.
<G-vec00206-001-s085><amount.sich_belaufen><en> Depreciation and amortization are expected to be in the region of EUR 1 billion, whereby about EUR 90 million of that amount are related to amortization resulting from purchase price allocation mainly of International Rectifier.Â
<G-vec00206-001-s085><amount.sich_belaufen><de> Die Abschreibungen sollten sich auf etwa 1 Milliarde Euro belaufen, wovon rund 90 Millionen Euro auf Abschreibungen aus Kaufpreisallokationen hauptsächlich im Zusammenhang mit dem Erwerb von International Rectifier entfallen.
<G-vec00206-001-s086><amount.sich_belaufen><en> The official rents are relatively high and amount to approximately 100 EUR per day plus fuel, drivers included.
<G-vec00206-001-s086><amount.sich_belaufen><de> Die offiziellen Mietpreise sind relativ hoch und belaufen sich etwa auf 100 EUR pro Tag plus Sprit, meistens ist der Fahrer inklusive.
<G-vec00206-001-s087><amount.sich_belaufen><en> The business website portfolio.hu predicts that in Hungary, between 2014 and 2020, the development budget will amount to 23.6 billion euros.
<G-vec00206-001-s087><amount.sich_belaufen><de> Laut Prognose des Wirtschaftsportals portfolio.hu soll sich das EU- Entwicklungsbudget für Ungarn zwischen 2014 und 2020 auf 23,6 Milliarden Euro belaufen.
<G-vec00206-001-s088><amount.sich_belaufen><en> According to the cost estimate, the investment costs will amount to CHF 2.5 million which it is planned will be financed internally by the Group.
<G-vec00206-001-s088><amount.sich_belaufen><de> Die Investitionskosten belaufen sich gemäß Kostenvoranschlag auf CHF 2.5 Mio., welche aus eigenen Mitteln finanziert werden sollen.
<G-vec00206-001-s089><amount.sich_belaufen><en> Costs The tuition fees for the 19-day course amount to 6,950 Euro plus statutory VAT .
<G-vec00206-001-s089><amount.sich_belaufen><de> Kosten Die StudiengebÃ1⁄4hren fÃ1⁄4r den 19-tägigen Kurs belaufen sich auf 6.950 Euro zzgl.
<G-vec00206-001-s090><amount.sich_belaufen><en> Back in 1990, the losses incurred by the US savings and loan associations were said to amount to some 600 to 800 billion dollars.
<G-vec00206-001-s090><amount.sich_belaufen><de> Um 1990 war die Rede davon, die Verluste der US-amerikanischen Sparkassen würden sich auf 600 bis 800 Milliarden Dollar belaufen.
<G-vec00206-001-s091><amount.sich_belaufen><en> The repair costs with Canon amount to approx.
<G-vec00206-001-s091><amount.sich_belaufen><de> Die Reparaturkosten bei Canon belaufen sich auf ca.
<G-vec00206-001-s092><amount.sich_belaufen><en> Total costs (fees and taxes) amount to about 10–12% of the property’s purchase price.
<G-vec00206-001-s092><amount.sich_belaufen><de> Die Gesamtkosten (Gebühren und Steuern) belaufen sich auf etwa 10 – 12% des Kaufpreises der Immobilie.
<G-vec00206-001-s093><amount.sich_belaufen><en> The contract with the U.S. National Football League (NFL) is particularly important: it is expected to amount to around 220 million U.S. dollars in support from Nike.
<G-vec00206-001-s093><amount.sich_belaufen><de> Besonders der Vertrag mit der US-amerikanischen National Football League (NFL) schlägt dabei ins Gewicht: Der soll sich bisher auf rund 220 Millionen US-Dollar Unterstützung von Nike belaufen.
<G-vec00206-001-s094><amount.sich_belaufen><en> Cash flow from operations will remain strong. The projected restructuring costs will amount to CHF 200–300 million.
<G-vec00206-001-s094><amount.sich_belaufen><de> Der operative Cashflow dürfte stark bleiben, während sich die Restrukturierungskosten voraussichtlich auf CHF 200 bis CHF 300 Millionen belaufen werden.
<G-vec00206-001-s114><amount.betragen><en> The minimum distance of motor and sailboats with less than twelve meters in length to the coast amount to 50 meters, and for longer boats it is 150 meters.
<G-vec00206-001-s114><amount.betragen><de> Die Mindestabstände von Motor- und Segelbooten mit weniger als 12 Meter Länge zur Küste betragen 50 Meter, bei längeren Schiffen 150 Meter.
<G-vec00206-001-s115><amount.betragen><en> The cost per unit of the purchased goods and services as well as the process costs amount to an average of more than 50% of the overall costs of a company.
<G-vec00206-001-s115><amount.betragen><de> Die Stückkosten der eingekauften Güter und Leistungen sowie die Prozesskosten betragen durchschnittlich über 50% der Gesamtkosten eines Unternehmens.
<G-vec00206-001-s116><amount.betragen><en> """We build plants of sizes 5 to 8 MW, which means that the plot sizes alone should amount to 80,000 and 150,000 mÂ2,"" says Andreas Fleischmann."
<G-vec00206-001-s116><amount.betragen><de> """Wir bauen Anlagen, die 5 bis 8 MW groß sind, das bedeutet, dass allein die Grundstücksflächen zwischen 80.000 und 150.000 m2 betragen müssen"", so Andreas Fleischmann."
<G-vec00206-001-s117><amount.betragen><en> If the annual targets are exceeded, the performance bonus may also exceed the target bonus; however, it may not amount to more than 200% of the target bonus (cap).
<G-vec00206-001-s117><amount.betragen><de> Werden die jährlich festgelegten Jahresziele übertroffen, kann der Performance Bonus über dem Zielbonus liegen; er kann jedoch maximal 200 Prozent des Zielbonus (Cap) betragen.
<G-vec00206-001-s118><amount.betragen><en> Negative oxygen ions and negative ions amount to up to 10,000,000 ions/cc.
<G-vec00206-001-s118><amount.betragen><de> Negative Sauerstoffionen und negative Ionen betragen bis zu 10 Millionen Ionen/cmÂ3.
<G-vec00206-001-s119><amount.betragen><en> If the goods are stored by the seller then the storage costs amount to 0.25% of the invoiced amount of the stored items for delivery per lapsed week.
<G-vec00206-001-s119><amount.betragen><de> Bei Lagerung durch den Verkäufer betragen die Lagerkosten 0,25% des Rechnungsbetrages der zu lagernden Liefergegenstände pro abgelaufene Woche.
<G-vec00206-001-s120><amount.betragen><en> According to the latest calculations, the construction costs amount in total to about 76 million Euros gross.
<G-vec00206-001-s120><amount.betragen><de> Nach aktuellen Berechnungen betragen die Baukosten insgesamt rund 76 Millionen Euro brutto.
<G-vec00206-001-s121><amount.betragen><en> Such funding can amount to as much as 65% of the calculated budget.
<G-vec00206-001-s121><amount.betragen><de> Diese Finanzierungsanteile können bis zu 65% des kalkulierten Budgets betragen.
<G-vec00206-001-s122><amount.betragen><en> The cost of the standard test amount to 5,000 to 6,000 €. The cost of the United Nations Transportation (UN-T) Test is included in the price. This is cheaper than building an own lab, since the investment for a company-owned laboratory can amount to several million euros.
<G-vec00206-001-s122><amount.betragen><de> Die Kosten für den Standard Test, der übrigens die gesetzlich weltweit vorgeschriebene UN-T Prüfung (United Nations Transportation Test - Transportvorschriften für Lithiumbatterien) beinhaltet, betragen etwa 5.000 bis 6.000 Euro.“ Günstiger, als ein eigenes Labor aufzubauen, in das nach Steinkes Angaben problemlos mehrere Millionen Euro investiert werden können.
<G-vec00206-001-s123><amount.betragen><en> The course fees at the beginning of the 2018 academic year amount to EUR 630 per month.
<G-vec00206-001-s123><amount.betragen><de> Die Studiengebühren zum Studienbeginn 2018 betragen 630 Euro pro Monat.
<G-vec00206-001-s124><amount.betragen><en> The data transmission rates amount to 10 MT and more, whereby advancements offer such as SCSI 2, nearly SCSI, Wide SCSI and other higher rates and make additionally a connection possible of more devices.
<G-vec00206-001-s124><amount.betragen><de> Die Übertragungsraten betragen 10 MB und mehr, wobei Weiterentwicklungen wie SCSI 2, Fast SCSI, Wide SCSI und andere höhere Raten bieten und zusätzlich einen Anschluss von mehr Geräten ermöglichen.
<G-vec00206-001-s125><amount.betragen><en> 2 By law, the amount you repay monthly must be at least 5.6% of your outstanding balance.
<G-vec00206-001-s125><amount.betragen><de> 2 Die monatliche Rückzahlung muss gesetzlich mindestens 5,6% Ihres geschuldeten Saldos betragen.
<G-vec00206-001-s126><amount.betragen><en> amount to a lump sum of 6.95 Euros.
<G-vec00206-001-s126><amount.betragen><de> betragen pauschal 6,95 Euro.
<G-vec00206-001-s127><amount.betragen><en> The yearly capacity will amount to in the normal operation 180,000 tons, with peak load up to 220.000 tons.
<G-vec00206-001-s127><amount.betragen><de> Die Jahreskapazität wird im Normalbetrieb 180.000 Tonnen betragen, bei Spitzenlast bis zu 220.000 Tonnen.
<G-vec00206-001-s128><amount.betragen><en> To continuously win in such situations our chances of winning have to amount to at least 50%.
<G-vec00206-001-s128><amount.betragen><de> Um auf Dauer in solchen Situationen zu gewinnen muss unsere Gewinnerwartung (Gewinnchance) mindestens 33% (2 zu 1) betragen.
<G-vec00206-001-s129><amount.betragen><en> 9.2 The extrajudicial costs will amount to fifteen per cent (15%) maximum of the amount or amounts owed, with a minimum of € 40.
<G-vec00206-001-s129><amount.betragen><de> 9.2 Die außergerichtlichen Inkassokosten betragen höchstens 15 % der Forderung(en) und mindestens 40,- €.
<G-vec00206-001-s130><amount.betragen><en> This influence varies but can by all means amount up to 30%.
<G-vec00206-001-s130><amount.betragen><de> Dieser Einfluß kann durchaus 30% +- betragen.
<G-vec00206-001-s131><amount.betragen><en> The submitted estimates of the damage to municipalities amount to 613,000 euros. About 552,000 euros are being called for, because the various municipalities were able to take on some parts of the costs.
<G-vec00206-001-s131><amount.betragen><de> Die eingereichten Schätzungen der Schäden der Gemeinden betragen 613.000 Euro.Angefordert werden in etwa 552.000 Euro, denn einige Kostenanteile konnten von verschiedenen Gemeinden übernommen werden.
<G-vec00206-001-s132><amount.betragen><en> With respect to expropriation, the Arbitral Tribunal ruled that Respondent’s emergency measures did not amount to a loss of Claimant’s property right or concession.
<G-vec00206-001-s132><amount.betragen><de> In Bezug auf Enteignung, das Schiedsgericht entschieden, dass Respondents Notfallmaßnahmen nicht zu einem Verlust der des Antragstellers Eigentumsrecht oder Konzession zu betragen hat.
<G-vec00206-002-s133><amount.betragen><en> The difference between both of them, should amount to about ten degrees, with red wine.
<G-vec00206-002-s133><amount.betragen><de> Die Differenz zwischen beiden sollte beim Rotwein etwa zehn Grad betragen.
<G-vec00206-002-s134><amount.betragen><en> The costs for pupils of the secondary schools amount to 250 € per year.
<G-vec00206-002-s134><amount.betragen><de> Die Kosten für Schüler der weiterführenden Schulen betragen 250 € jährlich.
<G-vec00206-002-s135><amount.betragen><en> These collection costs amount to no more than: 15% for outstanding amounts up to EUR 2,500.00; 10% for the following EUR 2,500.00; and 5% for the following EUR 5,000.00, with a minimum of EUR 40.00.
<G-vec00206-002-s135><amount.betragen><de> Diese Inkassokosten betragen maximal: 15% für offene Beträge bis EUR 2.500; 10% auf die darauf folgenden EUR 2.500; und 5% auf die folgenden EUR 5.000 bei einem Minimum von EUR 40,-.
<G-vec00206-002-s136><amount.betragen><en> If you send or receive an international personal payment using your PayPal balance or bank account, PayPal will charge a cross border fee, which can range from 0.5% to 2% of the payment amount.
<G-vec00206-002-s136><amount.betragen><de> Wenn Sie eine internationale persönliche Zahlung mithilfe Ihres PayPal-Guthabens oder Bankkontos überweisen oder empfangen, berechnet PayPal eine Auslandsgebühr, die zwischen 0,5 % und 2 % des Zahlungsbetrags betragen kann.
<G-vec00206-002-s137><amount.betragen><en> Politicians and economy experts are asking the question whether the economic upswing will amount to 1,3 or 2,0 or 0,9 percent, but companies of all kind and all sizes are wasting a multiple of that.
<G-vec00206-002-s137><amount.betragen><de> Politiker und Wirtschaftsexperten fragen, ob der Aufschwung 1.3, 2.0 oder 0.9 Prozent betragen wird, doch Unternehmen aller Art und aller Größen vergeuden das Vielfache davon.
<G-vec00206-002-s138><amount.betragen><en> 100 PLN amount to one stamp.
<G-vec00206-002-s138><amount.betragen><de> 100 PLN betragen einen Stempel.
<G-vec00206-002-s139><amount.betragen><en> (4) The shipping costs amount to 3,99 Euro.
<G-vec00206-002-s139><amount.betragen><de> (4) Die Versandkosten betragen 3,99 Euro.
<G-vec00206-002-s140><amount.betragen><en> The total investment including project-related debt financing will amount to approximately EUR 19 million.
<G-vec00206-002-s140><amount.betragen><de> Das Gesamtinvestitionsvolumen inklusive der projektbezogenen Fremdfinanzierung wird rund 19 Millionen Euro betragen.
<G-vec00206-002-s141><amount.betragen><en> These collection costs amount to a maximum of: 15% over outstanding amounts up to € 2,500, =; 10% over the next € 2,500, = and 5% over the next € 5,000, = with a minimum of € 40, =.
<G-vec00206-002-s141><amount.betragen><de> Diese Inkasso-Kosten betragen maximal: 15% von noch nicht beglichenen Beträgen bis € 2.500,- 10% über die nachfolgenden € 2.500,- und 5% über die nachfolgenden € 5.000,- mit einem Minimum von € 40,-.
<G-vec00206-002-s142><amount.betragen><en> The solid content of the feeding medium may amount to far above 50 %.
<G-vec00206-002-s142><amount.betragen><de> Der Feststoffgehalt des Fördermediums kann bis weit über 50 % betragen.
<G-vec00206-002-s143><amount.betragen><en> 2) The value of purchases made in the online store AGDhome.pl, has to be 300.00 PLN, gross amount
<G-vec00206-002-s143><amount.betragen><de> 2) Der Wert der im Online-Shop AGDhome.pl gekauften Waren muss bei einem einmaligen Kaufvorgang mindestens 300,00 Zloty brutto betragen.
<G-vec00206-002-s144><amount.betragen><en> The costs for a dog at a campsite amount to €5 per night, and up to €40 per period (weekend, midweek or week) in one of our holiday homes.
<G-vec00206-002-s144><amount.betragen><de> Die Kosten für einen Hund betragen auf einem Camping-Stellplatz € 5,-- pro Nacht und in einem Ferienhaus € 40,-- pro Urlaubsperiode (Wochenende, Kurzwoche oder ganze Woche).
<G-vec00206-002-s145><amount.betragen><en> The dimensions of the clock amount to 30 x 30 cm.
<G-vec00206-002-s145><amount.betragen><de> Die Abmessungen der Uhr betragen 30 x 30 cm.
<G-vec00206-002-s146><amount.betragen><en> These collection fees amount to a maximum of: 15% over any outstanding amounts up to € 2,500.=; 10% over the following € 2,500.= and 5% over the following € 5,000.= with a minimum of € 40.=.
<G-vec00206-002-s146><amount.betragen><de> Diese Inkassokosten betragen maximal: 15% über den ausstehenden Betrag bis zu € 2.500, =; 10% über die nächsten € 2.500, = und 5% über die nächsten € 5.000, = mit einem Minimum von € 40, =.
<G-vec00206-002-s147><amount.betragen><en> The full amount of the lower EBITDA will impact free cash flow, which will now thus amount to at least € 6 million.
<G-vec00206-002-s147><amount.betragen><de> Das reduzierte EBITDA wirkt sich auch in voller Höhe auf den Free Cashflow aus, der somit nun mindestens 6 Millionen Euro betragen wird.
<G-vec00206-002-s148><amount.betragen><en> These collection costs amount to a maximum of: 15% on outstanding amounts up to € 2,500; 10% on the subsequent € 2,500 and 5% on the next € 5,000, = with a minimum of € 40.
<G-vec00206-002-s148><amount.betragen><de> Diese Inkassokosten betragen maximal 15 % für ausstehende Beträge bis zu 2.500,00 €, 10 % für die darauf folgenden 2.500,00 € und 5 % für alle hierauf folgenden Beträge, mindestens jedoch 40,00 €.
<G-vec00206-002-s149><amount.betragen><en> Construction costs amount to 120 million Swiss francs. The operating fund of 50 million Swiss francs is intended to cover possible operating losses, maintenance and refurbishment costs.
<G-vec00206-002-s149><amount.betragen><de> Die Baukosten betragen 120 Millionen Schweizer Franken und der Betriebsfonds wird 50 Millionen Schweizer Franken umfassen und allfällige Betriebsdefizite, Unterhalt und Erneuerungen decken.
<G-vec00206-002-s150><amount.betragen><en> The costs of constructing a data centre can amount to thousands of euros per square meter; whereas, the costs of rental include both lower utility and management costs.
<G-vec00206-002-s150><amount.betragen><de> Die Kosten für den Aufbau eines Datenzentrums betragen auch mehrere tausend Euro pro Quadratmeter, bei einer Anmietung fallen die Kosten für Nutzung und Verwaltung geringer aus.
<G-vec00206-002-s151><amount.betragen><en> for the infringements referred to in points 1, 6, 7, 8 and 9 of Section II of Annex III, the fines shall amount to at least EUR 50 000 and shall not exceed EUR 150 000;
<G-vec00206-002-s151><amount.betragen><de> „d) Bei Verstößen nach Anhang III Abschnitt II Nummern 1, 6, 7, 8 und 9 betragen die Geldbußen mindestens 50 000 EUR und nicht mehr als 150 000 EUR.
