<G-vec00748-002-s019><brew.aufbrühen><en> For high grade tea such as "gunpowder" types, steeping time may be as few as 10 seconds on first brew.
<G-vec00748-002-s019><brew.aufbrühen><de> Für einen hochwertigen Tee wie "Gunpowder"-Sorten kann die Dauer beim ersten Aufbrühen nur 10 Sekunden betragen.
<G-vec00748-002-s020><brew.aufbrühen><en> The never ending search for quality buchu as well as the time it took to brew and strain the leaves, gave her the idea to produce the first 100% pure buchu teabags in South Africa and probably the world.
<G-vec00748-002-s020><brew.aufbrühen><de> Die mühsame endende Suche nach qualitativ hochwertigem Buchu und die Zeit zum Aufbrühen und anschließend Abseihen der Blätter brachten sie auf die Idee, den ersten 100%igen Buchu-Tee in Südafrika und wohl auch weltweit anzubieten.
<G-vec00748-002-s021><brew.aufbrühen><en> Do not use too much water to brew, avoiding excessive pressure inside the bottle.
<G-vec00748-002-s021><brew.aufbrühen><de> Verwenden Sie nicht zu viel Wasser zum Aufbrühen und vermeiden Sie übermäßigen Druck in der Flasche.
<G-vec00748-002-s022><brew.aufbrühen><en> Method of Preparation:Pour one filter bag with 200-300 ml of boiling water and brew for 3-5 minutes.
<G-vec00748-002-s022><brew.aufbrühen><de> Zubereitung: Zwei Teelöffel der Mischung wird für 15-20 min in 200-300 ml kochendem Wasser aufgebrüht.
<G-vec00748-002-s023><brew.aufbrühen><en> Raw, green beans need to be roasted before they can make a brew.
<G-vec00748-002-s023><brew.aufbrühen><de> Rohe, grüne Bohnen müssen geröstet werden, bevor sie aufgebrüht werden können.
<G-vec00748-002-s035><brew.brauen><en> With this kit you can brew the popular Czech classic which is a light, refreshing and thirst-quenching beer great for all occasions.
<G-vec00748-002-s035><brew.brauen><de> Mit diesem Set kannst Du das beliebte, klassische, tschechische Bier brauen - das leichte, erfrischende und durststillende Bier für alle Arten von Anlässen.
<G-vec00748-002-s036><brew.brauen><en> Some 30 years later, in 1420, Munich Town Hall decided to store or "lager" the brew before sale.
<G-vec00748-002-s036><brew.brauen><de> Die Münchener Stadtverwaltung befahl rund 30 Jahre später, 1420, das Bier nach dem Brauen eine Zeitlang zu lagern.
<G-vec00748-002-s042><brew.brauen><en> They select the finest ingredients and use traditional handcrafting methods to brew delicious full-flavoured beers, such as Buck’s Head Double IPA, Hilden Irish Stout and Twisted Hop Pale Ale.
<G-vec00748-002-s042><brew.brauen><de> Hier vereinen sich die besten Zutaten und traditionelles Handwerk, um köstliche, würzige Biere wie Buck’s Head Double IPA, Hilden Irish Stout und Twisted Hop Pale Ale zu brauen.
<G-vec00748-002-s043><brew.brauen><en> With our Cold Pads you can brew your own Cold Brew easily.
<G-vec00748-002-s043><brew.brauen><de> Mit unseren Cold Pads kannst Du Dir Deinen Cold Brew ganz einfach selbst brauen.
<G-vec00748-002-s044><brew.brauen><en> Modern design allows you to brew your tea with complete ease.
<G-vec00748-002-s044><brew.brauen><de> Modernes Design ermöglicht es Ihnen, Ihren Tee mit voller Leichtigkeit zu brauen.
<G-vec00748-002-s045><brew.brauen><en> In an ultramodern brewery it is very hard to brew an incomparably tasting beer based on traditional monastery recipes in a way the beer connoisseurs appreciate.
<G-vec00748-002-s045><brew.brauen><de> Besonders anspruchsvoll ist die Herausforderung auf Grundlage überlieferter Klosterrezepte in einer hochmodernen Brauerei unvergleichlich schmeckende Biere zu brauen, wie sie die Bierkenner in unserer Zeit bevorzugen.
<G-vec00748-002-s046><brew.brauen><en> AMABUKI sake is an exeption since we mostly brew a dry style of sake.
<G-vec00748-002-s046><brew.brauen><de> Die Sake von AMABUKI fallen hierbei etwas aus der Norm, da wir fast nur trockene Sake brauen.
<G-vec00748-002-s047><brew.brauen><en> Than brew it again and you can enjoy it.
<G-vec00748-002-s047><brew.brauen><de> Dann brauen Sie es wieder und Sie können es genießen.
<G-vec00748-002-s048><brew.brauen><en> A. Vogel bioSnacky Alfalfa 40g In the tiny brew seeds concentrated power sits.
<G-vec00748-002-s048><brew.brauen><de> A.Vogel - bioSnacky Alfalfa - 40g Im winzigen brauen Samen sitzt geballte Kraft.
<G-vec00748-002-s049><brew.brauen><en> Hone your magical crafts and share the enchantment: Learn to cast spells and find rare ingredients to brew elixirs, so you can charm or hex your Sims’ lives.
<G-vec00748-002-s049><brew.brauen><de> Trainieren Sie Ihre magischen Kräfte und teilen Sie den Zauber: Lernen Sie Zauber zu wirken und finden Sie seltene Zutaten, um Elixiere zu brauen und so das Leben Ihrer Sims zu verzaubern oder zu verhexen.
<G-vec00748-002-s050><brew.brauen><en> Depending on the season, we brew special beers like for example a wheat beer, a Christmas beer or a March beer.
<G-vec00748-002-s050><brew.brauen><de> Je nach Jahreszeit brauen wir ein Spezialbier wie zum Beispiel ein Weizenbier, einen Weihnachtsbock oder ein Märzenbier.
<G-vec00748-002-s051><brew.brauen><en> So you can brew competitively - even with constant changes in the market.
<G-vec00748-002-s051><brew.brauen><de> So brauen Sie wettbewerbsfähig – auch bei ständigen Veränderungen auf dem Markt.
<G-vec00748-002-s052><brew.brauen><en> Ideal option - coffee beans, which you yourself can grind, and then brew.
<G-vec00748-002-s052><brew.brauen><de> Ideale Option - Kaffeebohnen, die Sie selbst mahlen und dann brauen können.
<G-vec00748-002-s053><brew.brauen><en> You are in good company with the big Braumeister: on our menu you will find breweries, inns and restaurants that brew with the big Braumeister.
<G-vec00748-002-s053><brew.brauen><de> Mit dem großen Braumeister sind Sie in guter Gesellschaft: Auf unserer Karte finden Sie Brauereien, Gasthäuser und Restaurants, die mit dem großen Braumeister brauen.
<G-vec00748-002-s054><brew.brauen><en> Much as James likes experimenting with the brewing process, when it comes to his ingredients he’s very traditional in his thinking: “I want to brew beer as naturally as possible.
<G-vec00748-002-s054><brew.brauen><de> So gerne James beim Brauen auch experimentiert, was seine Zutaten angeht denkt er sehr traditionell: „Ich möchte so natürlich wie möglich Bier brauen.
<G-vec00748-002-s055><brew.brauen><en> We are BREWDAZ: Seven beerlovers from Zürich with the goal to brew innovative specialty beers.
<G-vec00748-002-s055><brew.brauen><de> Wir sind die BREWDAZ: sieben Zürcher Bierliebhaber, die sich zu einer Brewderschaft zusammengeschlossen haben, um innovative Spezialbiere zu brauen.
<G-vec00748-002-s056><brew.brauen><en> Today, we still brew our beers at Gusswerk, and in a way you can call us sedentary gypsy brewers: in contrast to classic gypsy brewers, who produce their beer (or have it produced) at various breweries, we brew our beers almost exclusively at Gusswerk, strictly according to our own specifications.
<G-vec00748-002-s056><brew.brauen><de> Auch heute noch brauen wir unsere Biere im Gusswerk, und so könnte man uns als sesshafte Wanderbrauer bezeichnen, denn im Gegensatz zu klassischen Gypsy Brauern, welche in vielen verschiedenen Brauereien produzieren (lassen), brauen wir unsere Biere nach unseren Vorstellungen beinahe ausschließlich im Gusswerk.
<G-vec00748-002-s058><brew.brauen><en> Gatecrashers[edit | edit source] Lambert will help me brew the potion. First, I need to bring him a mineral from the evening hall on the upper floor and some alcohol from the armory.
<G-vec00748-002-s058><brew.brauen><de> Ungeladene Gäste[Bearbeiten | Quelltext bearbeiten] Lambert wird mir helfen, den Trank zu brauen, aber zuerst muss ich ihm ein Mineral aus dem Gesellschaftssaal im Obergeschoss und etwas Alkohol aus der Waffenkammer holen.
<G-vec00748-002-s059><brew.brauen><en> The good people of Appenzell do not restrict themselves to the production of cheese – to a secret recipe as is well known - but also brew excellent beer.
<G-vec00748-002-s059><brew.brauen><de> Eisgekühltes Appenzeller Bier für Challenge-Sieger und VIPs Die Appenzeller produzieren nicht nur Käse – bekanntlich nach Geheimrezeptur, sondern brauen auch ausgezeichnete Biere.
<G-vec00748-002-s060><brew.brauen><en> Franconian breweries still brew with heart and passion and you can taste that.
<G-vec00748-002-s060><brew.brauen><de> Fränkische Brauereien brauen eben noch mit Herz und Leidenschaft und das schmeckt man.
<G-vec00748-002-s061><brew.brauen><en> In our brewery, we brew beer according to old practices that are traditional for Czech beers.
<G-vec00748-002-s061><brew.brauen><de> In unserer Brauerei brauen wir das Bier nach alten Methoden, die für den tschechischen Biertyp traditionell sind.
<G-vec00748-002-s062><brew.brauen><en> In her honor we brew Barbara since 1954.
<G-vec00748-002-s062><brew.brauen><de> Ihr zu Ehren brauen wir seit 1954 das Barbara.
<G-vec00748-002-s063><brew.brauen><en> If you prefer hot teas, then brew the dogrose with the addition of your favorite herbs, and put a cup of natural honey and a lemon slice.
<G-vec00748-002-s063><brew.brauen><de> Wenn Sie heiße Tees bevorzugen, dann brauen Sie die Heckenrose mit dem Zusatz Ihrer Lieblingskräuter, und fügen Sie eine Tasse natürlichen Honig und eine Zitronenscheibe hinzu.
<G-vec00748-002-s064><brew.brauen><en> Brew and insist for a long time (5-7 hours).
<G-vec00748-002-s064><brew.brauen><de> Brauen Sie und bestehen Sie für eine lange Zeit (5-7 Stunden).
<G-vec00748-002-s065><brew.brauen><en> German English Brew your own beer – ideal for business, club excursions, birthdays or other celebrations.
<G-vec00748-002-s065><brew.brauen><de> Brauen Sie Ihr eigenes Bier – ideal für Firmen- und Vereinsausflüge, Geburtstage, Kundentagungen und Jubiläen.
<G-vec00748-002-s066><brew.brauen><en> Easily brew your own authentic drip coffee, for a sip of aromatic relaxation.
<G-vec00748-002-s066><brew.brauen><de> Brauen Sie einfach Ihren eigenen authentischen Filterkaffee für einen Schluck aromatischer Entspannung.
<G-vec00748-002-s123><brew.brauen><en> In addition, there is an unknown number of hobby brewers, who brew beer on a small scale for their personal use.
<G-vec00748-002-s123><brew.brauen><de> Darüber hinaus gibt es eine unbekannte Zahl von Hobbybrauern, die das Bier in geringen Mengen für den Eigenbedarf brauen.
<G-vec00748-002-s124><brew.brauen><en> The visitors to the Stary Browar Rzeszowski have a chance to visit a brewhouse where brewers brew beer in front of guests’ eyes as well as see a lagering cellar with steel fermenting tanks.
<G-vec00748-002-s124><brew.brauen><de> Die Besucher von Stary Browar Rzeszowski haben die Möglichkeit, einen kleinen Tour durch das Brauhaus zu machen, in dem die Brauer das Bier vor den Augen der Gäste brauen, sowie den Lagerraum mit Stahl-Tank-Fermentern anzuschauen.
<G-vec00748-002-s127><brew.brauen><en> Offering exceptional reliability and optimal processability, BEST Red X® can be employed to brew consistently fiery beers with intense reddish hues.
<G-vec00748-002-s127><brew.brauen><de> Dadurch ist bei höchstmöglicher Prozesssicherheit und optimaler Verarbeitbarkeit sichergestellt, dass reproduzierbar glanzfeine Biere mit intensiv roten Farben gebraut werden können.
<G-vec00748-002-s128><brew.brauen><en> They no longer brew beer here, but the atmosphere gives you the feeling of being in a real brewery.
<G-vec00748-002-s128><brew.brauen><de> Bier wird hier oben keines mehr gebraut aber die Einrichtung vermittelt das Gefühl man ist in einer echten Brauerei.
<G-vec00748-002-s129><brew.brauen><en> They brew in a “micro”, a small experimental and specialty brewhouse (in Riegle language called manufactory), which they equipped about ten years ago after father and son took a trip through the USA and visited 36 microbreweries to understand what they were doing.
<G-vec00748-002-s129><brew.brauen><de> Gebraut werden die in einer „Micro“, einem kleinen Versuchs- und Spezialitätensudhaus (im Riegele-Sprech eine “Manufaktur”), das sie vor gut zehn Jahren eingerichtet haben, nach dem Vater und Sohn Priller-Riegele durch die USA getourt waren und 36 Microbreweries besucht hatten, um zu verstehen, was die da so machen.
<G-vec00748-002-s130><brew.brauen><en> Our beers have a high, consistent of quality, we brew with valuable ingredients artisanal and reliable.
<G-vec00748-002-s130><brew.brauen><de> Mit wertvollen Zutaten handwerklich und zuverlässig gebraut besitzen unsere Biere eine gleichbleibend, hohe Qualität.
<G-vec00748-002-s131><brew.brauen><en> Brew tea, add a stick of cinnamon, grated ginger and let it brew 10 minutes.
<G-vec00748-002-s131><brew.brauen><de> Gebraut Tee, fügen Sie eine Stange Zimt, geriebener Ingwer und lassen Sie es 10 Minuten brauen.
<G-vec00748-002-s132><brew.brauen><en> Braybrooke Beer Co. does not brew classic “craft beers”.
<G-vec00748-002-s132><brew.brauen><de> Bei Braybrooke Beer Co. werden keine klassischen »Craft Biere« gebraut.
<G-vec00748-002-s160><brew.kochen><en> I brew the first coffee of the day in the galley, with a full view of the harbour and the fjord.
<G-vec00748-002-s160><brew.kochen><de> Den ersten Kaffee des Tages koche ich in der Küche mit vollem Ausblick auf den Hafen und die Förde.
<G-vec00748-002-s161><brew.kochen><en> Brew and cool ¼ cup green tea.
<G-vec00748-002-s161><brew.kochen><de> Koche ¼ Tasse grünen Tee und lasse ihn abkühlen.
<G-vec00748-002-s162><brew.kochen><en> Later in the cabin I brew a coffee that we enjoy on our balcony while far below us the occasional pling can be heard of shuffle board gambling fellows.
<G-vec00748-002-s162><brew.kochen><de> Später in der Kabine koche ich uns einen Kaffee, den wir auf unserem Balkon genießen, während von weit unter uns das gelegentliche Pling von Shufflebord spielenden Mitreisenden zu uns hoch klingt.
<G-vec00748-002-s163><brew.kochen><en> Brew up a cup of peppermint, ginger, chamomile, rosemary, or ginseng tea to drink several times a day.
<G-vec00748-002-s163><brew.kochen><de> Koche eine Tasse Pfefferminz, Ingwer, Kamille, Rosmarin oder Ginsengtee und trinke ihn mehrere Male täglich.
<G-vec00748-002-s164><brew.kochen><en> You can use to brew fresh coffee.
<G-vec00748-002-s164><brew.kochen><de> Sie können damit frischen Kaffee kochen.
<G-vec00748-002-s165><brew.kochen><en> People chew it, smoke it, brew it or add it to food.
<G-vec00748-002-s165><brew.kochen><de> Die Leute kauen sie, rauchen sie, kochen sie auf oder mischen sie unters Essen.
<G-vec00748-002-s166><brew.kochen><en> Our machines can brew up to 10 cups of coffee thanks to the large capacity carafe.
<G-vec00748-002-s166><brew.kochen><de> Dank der großen Kanne können unsere Maschinen bis zu 10 Tassen Kaffee kochen.
<G-vec00748-002-s167><brew.kochen><en> Simply brew a cup of chamomile tea, remove the tea bag and let it cool, then place it gently over your eye.
<G-vec00748-002-s167><brew.kochen><de> Lassen Sie nach dem Kochen einer Tasse Kamillentees den Beutel einfach abkühlen und legen Sie ihn auf das infizierte Auge.
