<G-vec00910-002-s018><defuse.entschärfen><en> But despite Macron’s attempt to defuse the situation, the explosion of anger and frustration at years of austerity and inequality has acquired a logic of its own, and it will not be easy to put the genie back in the bottle.
<G-vec00910-002-s018><defuse.entschärfen><de> Trotz des aktuellen Versuchs von Macron, die Lage zu entschärfen, hat dieser Ausbruch des Zorns und der Frustration über Jahre der Sparpolitik und über die wachsende Ungleichheit eine eigene Logik angenommen, und es wird nicht so einfach sein, den Geist in die Flasche zurückzubefördern.
<G-vec00910-002-s021><defuse.entschärfen><en> With our change management consulting, we defuse this conflict. We understand adaptive IT management as the creation of an information technology that is aimed at immediate value add for the organization.
<G-vec00910-002-s021><defuse.entschärfen><de> Mit unserer Change-Management-Beratung entschärfen wir diesen Konflikt: Adaptives IT-Management verstehen wir als das Schaffen einer Informationstechnologie, die auf unmittelbare Mehrwerte für die Organisation ausgerichtet ist.
<G-vec00910-002-s022><defuse.entschärfen><en> In 2015 we developed a process with various focal points and escalation levels for our employees to identify potential conflicts and defuse them in dialog.
<G-vec00910-002-s022><defuse.entschärfen><de> Dazu haben wir im Jahr 2015 einen Prozess mit verschiedenen Anlaufstellen und Eskalationsstufen für unsere Mitarbeiter entwickelt, um mögliche Konflikte zu erkennen und diese im Dialog zu entschärfen.
<G-vec00910-002-s025><defuse.entschärfen><en> Defuse the bomb by clicking the colors in the same order as the computer does.
<G-vec00910-002-s025><defuse.entschärfen><de> Entschärfe die Bombe durch Anklicken der Farben in derselben Folge, wie der Computer das macht.
<G-vec00910-002-s026><defuse.entschärfen><en> It is not possible to defuse the problem here through direct financing”.
<G-vec00910-002-s026><defuse.entschärfen><de> Es ist nicht möglich, das Problem hier durch die direkte Finanzierung zu entschärfen".
<G-vec00910-002-s027><defuse.entschärfen><en> Some are happy about it and believe that the security problems will defuse afterwards.
<G-vec00910-002-s027><defuse.entschärfen><de> Die einen freuen sich und glauben, dass sich danach die Sicherheitsprobleme entschärfen.
<G-vec00910-002-s028><defuse.entschärfen><en> Your objective in this cool batman game is to help Fatman defuse the bombs and save the city using his jumping prowess and fatarang.
<G-vec00910-002-s028><defuse.entschärfen><de> Ihr Ziel in diesem coolen Batman-Spiel soll helfen, Fatman, die Bomben zu entschärfen, und speichern Sie die Stadt mit seinen springenden Tapferkeit und Fatarang.
<G-vec00910-002-s029><defuse.entschärfen><en> Priority-Guards is able to defuse many dangerous situations with psychological and tactical strategies.
<G-vec00910-002-s029><defuse.entschärfen><de> Die Priority-Guards kann durch psychologisches und taktisches Auftreten vielfach gefährliche Situationen entschärfen.
<G-vec00910-002-s030><defuse.entschärfen><en> There was no willingness to dilute or defuse the righteous anger that was directed at the galleries like a shotgun blast.
<G-vec00910-002-s030><defuse.entschärfen><de> Man war nicht bereit den gerechtfertigten Zorn, der sich wie der Schuss aus einer Schrotflinte gegen die Kunstgalerien entlud, zu verwässern oder zu entschärfen.
<G-vec00910-002-s031><defuse.entschärfen><en> International contact groups have tried to defuse the conflict.
<G-vec00910-002-s031><defuse.entschärfen><de> Internationale Kontaktgruppen haben versucht, den Konflikt zu entschärfen.
<G-vec00910-002-s032><defuse.entschärfen><en> Active Brake Assist: Active Brake Assist with cross-traffic function is able to help the driver avoid impending collisions with vehicles ahead, stationary or crossing vehicles and with people if the driver fails to take any action to defuse the dangerous situation.
<G-vec00910-002-s032><defuse.entschärfen><de> Aktiver Brems-Assistent: Der Aktive Brems-Assistent mit Kreuzungsfunktion kann den Fahrer im Straßenverkehr bei der Vermeidung drohender Kollisionen mit stehenden, vorausfahrenden oder querenden Fahrzeugen sowie Personen unterstützen, wenn der Fahrer keine Aktivitäten zeigt, um die Gefahrensituation zu entschärfen.
<G-vec00910-002-s033><defuse.entschärfen><en> Defuse Eliminate or reduce the risk of unwanted triggering or release of the charge(s) of ammunition whose safety condition is or may be impaired, with the aim of making ammunition safe for handling and transport.
<G-vec00910-002-s033><defuse.entschärfen><de> Entschärfen Beseitigen oder Herabsetzen des Risikos einer ungewollten Auslösung oder Freisetzung der Wirkladung(en) von Munition, deren sicherheitstechnischer Zustand beeinträchtigt ist oder sein kann, mit dem Ziel, die Munition handhabungs- und transportsicher zu machen.
<G-vec00910-002-s034><defuse.entschärfen><en> Such serious statements should defuse the situation.
<G-vec00910-002-s034><defuse.entschärfen><de> Solche ernstgemeinten Aussagen sollten die Situation entschärfen.
<G-vec00910-002-s035><defuse.entschärfen><en> Because of their high adaptability large dolphins are held by the military in the USA and in Russia, in order to install, for example naval mines at hostile ships or defuse mines.
<G-vec00910-002-s035><defuse.entschärfen><de> Wegen der hohen Lernfähigkeit werden Große Tümmler vom Militär in den USA und in Russland gehalten, um beispielsweise Seeminen an feindlichen Schiffen zu installieren oder Minen zu entschärfen.
<G-vec00910-002-s036><defuse.entschärfen><en> You will only want to defuse the bomb if you are playing on the Counter-Terrorist team.
<G-vec00910-002-s036><defuse.entschärfen><de> Nur wenn du im Anti-Terroristen-Team spielst, ist es dein Ziel, die Bombe zu entschärfen.
<G-vec00910-002-s037><defuse.entschärfen><en> You'll have to defuse the bomb first (pay attention on the number at the bottom right corner).
<G-vec00910-002-s037><defuse.entschärfen><de> Du musst zuerst die Bombe entschärfen (achte auf die Zahlen in der unteren rechten Ecke).
<G-vec00910-002-s038><defuse.entschärfen><en> Delenn tries to work with an old rival to defuse a brewing Minbari civil war.
<G-vec00910-002-s038><defuse.entschärfen><de> Delenn versucht mit einem alten Rivalen zusammenzuarbeiten, um die drohende Gefahr eines Bürgerkriegs auf Minbar zu entschärfen.
<G-vec00910-002-s039><defuse.entschärfen><en> State Department representatives repeatedly evaded questions about whether the US approved of the strikes or viewed them as cutting across its attempt to defuse tensions in the region.
<G-vec00910-002-s039><defuse.entschärfen><de> Vertreter des Außenministeriums wichen wiederholt Fragen aus, ob die USA die Schläge billigten, oder ob sie ihren Bemühungen, die Spannungen in der Region zu entschärfen, in die Quere kämen.
<G-vec00910-002-s040><defuse.entschärfen><en> The fragrance helps to defuse an odor that arises during a diaper change.
<G-vec00910-002-s040><defuse.entschärfen><de> Der Duft hilft, einen Geruch zu entschärfen, der während einer Windeländerung entsteht.
<G-vec00910-002-s041><defuse.entschärfen><en> Together with the Commission, the Austrian Presidency was able to defuse this crisis in the early stages, but the problem continues to exist.
<G-vec00910-002-s041><defuse.entschärfen><de> Die österreichische Ratspräsidentschaft hat gemeinsam mit der Kommission in den ersten Tagen diese Krise entschärfen können, aber die Probleme sind noch immer vorhanden.
<G-vec00910-002-s042><defuse.entschärfen><en> On the contrary. The job of a prudent foreign policy is and must be to prevent wars, defuse conflicts and lessen suffering through courage and drive.
<G-vec00910-002-s042><defuse.entschärfen><de> Im Gegenteil: Aufgabe kluger Außenpolitik ist es und muss es sein, durch Mut und Tatkraft Kriege zu verhindern, Konflikte zu entschärfen, Leid zu lindern.
<G-vec00910-002-s043><defuse.entschärfen><en> But this does not mean that we can defuse any crisis by means of preventive action or clever intervention.
<G-vec00910-002-s043><defuse.entschärfen><de> Aber das heißt nicht, dass wir jede Krise durch Prävention oder intelligentes Eingreifen entschärfen können.
<G-vec00910-002-s044><defuse.entschärfen><en> In the face of the activities of 500,000 participants in the struggles, the General Confederation of Employers' Associations of the Metal Industry and the leadership of the Metal Workers Industrial Union (IGM) backed out in order to defuse the situation.
<G-vec00910-002-s044><defuse.entschärfen><de> Aufgrund der Aktivitäten in den Kämpfen mit 500.000 Beteiligten machten Gesamtmetall und die IG Metallführung einen Rückzieher, um die Situation zu entschärfen.
<G-vec00910-002-s045><defuse.entschärfen><en> Global Risk operatives defuse explosives and interfere with the ghost team.
<G-vec00910-002-s045><defuse.entschärfen><de> Die Agenten der Global Risk entschärfen die Sprengstoffe und behindern das Geisterteam.
<G-vec00910-002-s046><defuse.entschärfen><en> Sit down in a relaxed spot and think about what you can do yourself in order to a) defuse the situation b) bring back your inner balance.
<G-vec00910-002-s046><defuse.entschärfen><de> Setzen Sie sich in entspannter Atmosphäre hin, und überlegen Sie sich, was Sie selbst tun können, um a) die Situation zu entschärfen b) was Sie ins Gleichgewicht bringen könnte.
<G-vec00910-002-s047><defuse.entschärfen><en> Defuse 100 bombs successfully
<G-vec00910-002-s047><defuse.entschärfen><de> Entschärfen Sie erfolgreich 100 Bomben.
<G-vec00910-002-s048><defuse.entschärfen><en> According to Weiler, the declaration of human rights was able to “settle warlike conflicts” and “defuse others in time” (IE, p. 223).
<G-vec00910-002-s048><defuse.entschärfen><de> Durch die Erklärung der Menschenrechte konnten, so Weiler, «kriegerische Konflikte beendet» und «andere rechtzeitig entschärft» werden (IE, S. 223).
<G-vec00910-002-s049><defuse.entschärfen><en> By your actions and your approach, your way of looking at things, your desires and above all your sensitivity, you discredit and defuse the kind of talk that is intent on sowing division, the kind of talk that is intent on excluding or rejecting those who are not “like us”.
<G-vec00910-002-s049><defuse.entschärfen><de> Ihr, mit euren Gesten und eurem Verhalten, mit euren Blicken, Wünschen und vor allem mit eurer Sensibilität widerlegt und entschärft ihr all jene Reden, die darauf bedacht sind, Spaltung hervorzurufen, jene Reden, die mit aller Kraft diejenigen ausschließen und vertreiben wollen, die „nicht wie wir sind“.
<G-vec00910-002-s050><defuse.entschärfen><en> There are also indications that a particular time element is involved and all the forces of darkness seek to deceive and obfuscate at levels never before achieved in order to distract, confuse, dilute and defuse the abilities of those who may be the bearers of the circuits of change for all humanity.
<G-vec00910-002-s050><defuse.entschärfen><de> Es gibt auch Anzeichen dafür, dass dabei ein besonderer “Zeitfaktor” eine Rolle spielt und dass all die Kräfte der Dunkelheit versuchen auf nie zuvor dagewesene Weise zu täuschen und zu verwirren, damit die Fähigkeiten jener, die die Träger der “Schaltkreise der Veränderung” für die ganze Menschheit sein könnten, abgelenkt, durcheinander gebracht, geschwächt und entschärft werden.
<G-vec00910-002-s051><defuse.entschärfen><en> This, says Sophie, was the perfect way to defuse the situation and make sure that she didn’t offend the two men.
<G-vec00910-002-s051><defuse.entschärfen><de> Auf diese Weise habe sie die Situation perfekt entschärft und die beiden Männer nicht verärgert, sagt Sophie.
<G-vec00910-002-s057><defuse.entschärfen><en> In far as those signing are laypeople they want to encourage each other to increasingly take upon themselves the task of dialogue without restriction and segregation and thereby defuse possibly arising competition situations and keep them away from the monastic Sangha.
<G-vec00910-002-s057><defuse.entschärfen><de> Soweit die Zeichnenden Laienanhänger sind, wollen sie sich gegenseitig ermutigen vermehrt die Aufgabe des Dialoges ohne Abgrenzung in Formen einer Religion zu übernehmen und damit eine eventuell Entstehende Konkurenzsituation entschärfen und aus den Belangen der klösterlichen Sangha halten.
<G-vec00910-002-s062><defuse.entschärfen><en> Strengthening regional, community-oriented agricultural systems can at least help to defuse this crisis.
<G-vec00910-002-s062><defuse.entschärfen><de> Die Stärkung regionaler, gemeinwesenorientierter Agrarsysteme kann helfen, dieses Problem zumindest ein wenig zu entschärfen.
<G-vec00910-002-s064><defuse.entschärfen><en> The historical-critical method as well as multi-perspective and controversial portrayal can defuse this circumstance, but not override it, because of the interpretative power over the selection (selectivity).
<G-vec00910-002-s064><defuse.entschärfen><de> Historisch-kritische Methode sowie Multiperspektivität und Kontroversität der Darstellung können diesen Umstand sehr entschärfen, aber aufgrund der Deutungsmacht über die Auswahl (Selektivität) nicht aufheben.
<G-vec00910-002-s065><defuse.entschärfen><en> Knowing the mechanism, it is possible to derive an effective handling to defuse it.
<G-vec00910-002-s065><defuse.entschärfen><de> Die Kenntnis dieses Mechanismus ermöglicht es, eine wirksame Lösung abzuleiten, um die Situation zu entschärfen.
<G-vec00910-002-s066><defuse.entschärfen><en> Learn how to defuse the situation or be prepared to fight for your own self-preservation.
<G-vec00910-002-s066><defuse.entschärfen><de> Lerne solche Situationen zu entschärfen oder sei auf einen Kampf aus Selbstschutz vorbereitet.
<G-vec00910-002-s068><defuse.entschärfen><en> One of the players takes on the role of the Unexpected Hero, who finds a bomb and tries to defuse it.
<G-vec00910-002-s068><defuse.entschärfen><de> Einer der Spieler übernimmt die Rolle des Helden wider Willen, der die Bombe findet und versucht, sie zu entschärfen.
<G-vec00910-002-s060><defuse.minimieren><en> But a healthy diet and regular exercise could help defuse the effects of stress once your head hits the pillow.
<G-vec00910-002-s060><defuse.minimieren><de> Allerdings könnten eine gesunde Ernährung und regelmäßiger Sport dazu beitragen, die Auswirkungen von Stress zu minimieren, sobald du dich hinlegst.
<G-vec00910-002-s061><defuse.stoppen><en> Meanwhile, the government has been using all resources at their disposal to try to contain and defuse the movement.
<G-vec00910-002-s061><defuse.stoppen><de> In der Zwischenzeit nutzte die Regierung alle ihnen zur Verfügung stehenden Mittel, um die Bewegung einzudämmen und zu stoppen.
<G-vec00910-002-s023><defuse.zerstreuen><en> The alliance of the predominately Sunni Muslim Palestinian resistance movements and the Free Patriotic Movement, Lebanon’s largest Christian political party, with predominately Shiite Muslim Iran and Hezbollah should defuse such a perception that the US and its allies are trying to cultivate. Mahdi Darius Nazemroaya for RT
<G-vec00910-002-s023><defuse.zerstreuen><de> Das Bündnis der vorherrschend sunnitischen palästinensischen Widerstandsbewegung und der Freien patriotischen Bewegung, immerhin die größte christliche politische Partei des Libanon, mit dem mehrheitlich schiitischen Iran und der Hisbollah sollte endgültig die Wahrnehmung zerstreuen, die die USA und ihre Verbündeten aufrecht zu erhalten versuchen.
