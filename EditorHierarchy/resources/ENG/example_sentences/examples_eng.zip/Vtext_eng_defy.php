<G-vec00461-002-s082><defy.sich_widersetzen><en> To defy dangers or indecision.
<G-vec00461-002-s082><defy.sich_widersetzen><de> Sich Gefahren oder Unentschlossenheit zu widersetzen.
<G-vec00461-002-s083><defy.sich_widersetzen><en> However, these experimental structures that defy state standards create conflict between Reynolds and the authorities, who are backed by big business.
<G-vec00461-002-s083><defy.sich_widersetzen><de> Diese experimentellen Strukturen, die sich den staatlichen Standards widersetzen, schaffen jedoch einen Konflikt zwischen Reynolds und den Behörden, die von Grossunternehmen unterstützt werden.
<G-vec00461-002-s058><defy.trotzen><en> Following the example of our divine Lord and Redeemer, thou didst defy unjust power and help the needy with prayer and deed.
<G-vec00461-002-s058><defy.trotzen><de> Dem Beispiel unseres göttlichen Herrn und Erlösers folgend, hast du der ungerechten Gewalt getrotzt und den Notleidenden durch Gebet und Tat geholfen.
<G-vec00461-002-s133><defy.widersetzen><en> In the midst of this struggle, the idea dawned on me that we can only find the safest place if we collectively manage to defy the pressure of extreme economic constraints, do not blindly believe everything we are told and wrongly assume that statements are absolute scientific truths.
<G-vec00461-002-s133><defy.widersetzen><de> In diesem Ringen wuchs meine Einsicht, dass der sicherste Ort nur dort zu finden sein kann, wo es uns als Kollektiv gelingt, uns dem Druck extremer ökonomischer Sachzwänge zu widersetzen, nicht zu Gläubigen zu werden und Behauptungen nicht voreilig als letzte wissenschaftliche Wahrheiten zu missverstehen.
<G-vec00461-002-s134><defy.widersprechen><en> Mini-skirts in winter seem to defy common sense.
<G-vec00461-002-s134><defy.widersprechen><de> Miniröcke im Winter scheinen dem gesunden Menschenverstand zu widersprechen.
<G-vec00461-002-s135><defy.widersprechen><en> The desire to control one’s own destiny, to carve one’s own path and defy expectations, is a road few of us ever dare to travel.
<G-vec00461-002-s135><defy.widersprechen><de> … aber dem Verlangen zu folgen, Herr über sein eigenes Schicksal zu sein, seinen eigenen Weg zu gehen und Erwartungen zu widersprechen, ist eine Entscheidung, die nur wenige von uns zu treffen wagen.
<G-vec00461-002-s137><defy.widerstehen><en> Humans living under these types of laws have no humanity, no truth—they all defy the truth, and are hostile to God.
<G-vec00461-002-s137><defy.widerstehen><de> Menschen, die unter dieser Art von Gesetzen leben, haben keine Menschlichkeit, keine Wahrheit – sie alle widerstehen der Wahrheit und sind Gott feindlich gesinnt.
<G-vec00461-002-s138><defy.widerstehen><en> It seems to defy the interpretation as well as restrictions of dental steroids.
<G-vec00461-002-s138><defy.widerstehen><de> Es scheint, die Interpretation und die Grenzen von oralen Steroiden zu widerstehen.
<G-vec00461-002-s139><defy.widerstehen><en> It seems to defy the definition and also limitations of dental steroids.
<G-vec00461-002-s139><defy.widerstehen><de> Es scheint, die Auslegung und die Einschränkungen von oralen Steroiden zu widerstehen.
<G-vec00739-002-s019><defy.ankämpfen><en> It is unique, thanks to the cultivation that seems to defy logic and patience, with regards to fighting the harshness of the valley’s porphyry soils.
<G-vec00739-002-s019><defy.ankämpfen><de> Zudem sieht man Anbaugebiete, die, wie es scheint, Logik und Geduld herausfordernd auf eine harte Probe stellen und schon jahrzehntelang unerbittlich gegen die Natur, mit ihrem unbarmherzigem Gestein, anzukämpfen scheinen.
<G-vec00739-002-s024><defy.ankämpfen><en> On the provisioning side, we need security built for the way cloud works, built to take advantage of the shape of the Internet — not try to defy it.
<G-vec00739-002-s024><defy.ankämpfen><de> Was die Bereitstellung angeht, benötigen wir Sicherheit, die optimal zur Funktionsweise der Cloud passt und die Eigenschaften des Internets zu ihrem Vorteil nutzt – und nicht dagegen ankämpft.
<G-vec00739-002-s021><defy.bekämpfen><en> Defy the aging process with products that release dead cell buildup, unblock pores, soothe and condition, firm up sags and wrinkles, and infuse your skin with moisture.
<G-vec00739-002-s021><defy.bekämpfen><de> Bekämpfen Sie den Alterungsprozess mit Produkten, die abgestorbene Zellen entfernen, Poren befreien, die Haut beruhigen und pflegen sowie erschlaffte Haut und Fältchen straffen.
<G-vec00739-002-s022><defy.bezwingen><en> The men, dressed in carnival clothes (not forgetting the wig, glitter, false eyelashes and 8 centimetre high heels), try to defy the laws of gravity, avoiding obstacles on the cobbled streets of the city centre.
<G-vec00739-002-s022><defy.bezwingen><de> Die männlichen Teilnehmer – natürlich im passenden Karnevalskostüm mit Perücke, Glitzer-Make-Up und künstlichen Wimpern – versuchen, auf mehr als 8 Zentimetern hohen High-Heels die Schwerkraft und die Hindernisse der Pflastersteingassen des Stadtzentrums zu bezwingen.
<G-vec00739-002-s088><defy.bieten><en> We want to defy the loss of dining culture and the rapid spread of fast food.
<G-vec00739-002-s088><defy.bieten><de> Wir wollen dem Verlust der Esskultur und der rasanten Ausbreitung des „Fast Food“ die Stirn bieten.
<G-vec00739-002-s089><defy.bieten><en> Composite technologists continue to introduce new material combinations that defy the capabilities of traditional machining methods.
<G-vec00739-002-s089><defy.bieten><de> Verbundwerkstoff-Verfahrenstechniker stellen immer neue Werkstoffkombinationen vor, die den Fähigkeiten herkömmlicher maschineller Bearbeitungsmethoden die Stirn bieten.
<G-vec00739-002-s090><defy.bieten><en> But often queer spaces come with inherent phobias against men who are “effeminate”, women who are not, and a whole range of identities and behaviors that defy the gender binary.
<G-vec00739-002-s090><defy.bieten><de> Doch an solchen queeren Orten trifft man oft auch auf gewisse Vorbehalte gegen Männer, die „verweiblicht” seien, gegen Frauen, die es nicht sind, und gegenüber einer ganzen Reihe von Identitäten und Verhaltensweisen, die der Genderbinarität die Stirn bieten.
<G-vec00739-002-s091><defy.bieten><en> In fact, this clandestine nature helped it to survive as a way to defy Spanish culture and reaffirm identity.[14]
<G-vec00739-002-s091><defy.bieten><de> Tatsächlich verhalf die Heimlichkeit dem Papier zu überleben und so der spanischen Kultur die Stirn zu bieten und die eigene Identität zu bekräftigen[12].
<G-vec00739-002-s049><defy.entziehen><en> But the Holocaust and our attempts at understanding it defy that closure.
<G-vec00739-002-s049><defy.entziehen><de> Der Holocaust und unsere Versuche, ihn zu verstehen, entziehen sich diesem Verständnis jedoch.
<G-vec00739-002-s080><defy.entziehen><en> They all let things happen that defy all logic, amaze and enchant.
<G-vec00739-002-s080><defy.entziehen><de> Sie alle lassen Dinge geschehen, die sich jeglicher Logik entziehen, staunen lassen und verzaubern.
<G-vec00739-002-s081><defy.entziehen><en> The Icelander blends opulent, classical compositions and contemporary electronic influences into songs that defy any comparison.
<G-vec00739-002-s081><defy.entziehen><de> Der Isländer vermengt opulente, klassische Kompositionen mit modernen elektronischen Einflüssen und schafft mit diesen Mitteln Songs, die sich jeglicher Vergleichbarkeit entziehen.
<G-vec00739-002-s052><defy.herausfordern><en> We do the incredible; we defy the impossible; we conquer the unknown.
<G-vec00739-002-s052><defy.herausfordern><de> •Wir tun das Unglaubliche; wir fordern das Unmögliche heraus; wir erobern das Unbekannte.
<G-vec00739-002-s060><defy.herausfordern><en> You’re going to defy him for the throne.
<G-vec00739-002-s060><defy.herausfordern><de> Du wirst ihn um den Thron herausfordern.
<G-vec00739-002-s084><defy.sein><en> You always defy authority, unless, of course, you are the authority.
<G-vec00739-002-s084><defy.sein><de> Sie sind immer der Autorität ausgesetzt, es sei denn, Sie sind selbstverständlich die Autorität.
<G-vec00739-002-s049><defy.sich_entziehen><en> But the Holocaust and our attempts at understanding it defy that closure.
<G-vec00739-002-s049><defy.sich_entziehen><de> Der Holocaust und unsere Versuche, ihn zu verstehen, entziehen sich diesem Verständnis jedoch.
<G-vec00739-002-s080><defy.sich_entziehen><en> They all let things happen that defy all logic, amaze and enchant.
<G-vec00739-002-s080><defy.sich_entziehen><de> Sie alle lassen Dinge geschehen, die sich jeglicher Logik entziehen, staunen lassen und verzaubern.
<G-vec00739-002-s081><defy.sich_entziehen><en> The Icelander blends opulent, classical compositions and contemporary electronic influences into songs that defy any comparison.
<G-vec00739-002-s081><defy.sich_entziehen><de> Der Isländer vermengt opulente, klassische Kompositionen mit modernen elektronischen Einflüssen und schafft mit diesen Mitteln Songs, die sich jeglicher Vergleichbarkeit entziehen.
<G-vec00739-002-s057><defy.sich_stellen><en> The curators have set out to question and even defy our received notions of the Subcontinent, presenting a sort of counter-colonial response to the official Western history of photography.
<G-vec00739-002-s057><defy.sich_stellen><de> Die Kuratoren haben unsere allgemeine Sicht des Subkontinents in Frage gestellt und sogar herausgefordert, indem sie eine Art antikoloniale Antwort auf die offizielle westliche Fotografiegeschichte präsentieren.
<G-vec00739-002-s064><defy.standhalten><en> It soon became clear that this structure would not be able to defy the forces of nature for very long.
<G-vec00739-002-s064><defy.standhalten><de> Dass diese den Naturgewalten nur für kurze Zeit standhalten würde, war bald klar.
<G-vec00739-002-s087><defy.standhalten><en> While Morrow was at Momentum Labs working as a top engineer, Doctor Lucy Bauer and her husband Joseph spearheaded a project to build a machine that could defy the laws of physics to generate materials.
<G-vec00739-002-s087><defy.standhalten><de> Während Morrow bei Momentum Labs als Topingenieur arbeitete, führten Doctor Lucy Bauer und ihr Ehemann Joseph ein Projekt zum Bau einer Maschine, die den Gesetzen der Physik standhalten konnte, um Materialien zu erzeugen.
<G-vec00739-002-s057><defy.stellen><en> The curators have set out to question and even defy our received notions of the Subcontinent, presenting a sort of counter-colonial response to the official Western history of photography.
<G-vec00739-002-s057><defy.stellen><de> Die Kuratoren haben unsere allgemeine Sicht des Subkontinents in Frage gestellt und sogar herausgefordert, indem sie eine Art antikoloniale Antwort auf die offizielle westliche Fotografiegeschichte präsentieren.
<G-vec00739-002-s048><defy.trotzen><en> Thickly packed to defy the ice cold, he was getting colder and colder, so he shouted loudly, "That shitty Berlin winter."
<G-vec00739-002-s048><defy.trotzen><de> Dick eingepackt, um der Eiseskälte zu trotzen, wurde ihm trotz allem immer kälter, so dass er laut "Dieser schxxx Berliner Winter“ rief.
<G-vec00739-002-s065><defy.trotzen><en> It’s for those who defy the architects of life and put up their own blueprint.
<G-vec00739-002-s065><defy.trotzen><de> Es ist für jene, die den Lebensarchitekten trotzen und Ihre eigenen Blueprints erstellen.
<G-vec00739-002-s069><defy.trotzen><en> The expressive pose of this woman with hat and skirt, are synonymous with the strength and courage to stand firm and defy even the most burning situations. Unique
<G-vec00739-002-s069><defy.trotzen><de> Die ausdrucksstarke Pose dieser Frau mit Hut und Rock, stehen als Synonym für Kraft und Mut, sich fest zu positionieren und auch den brennendsten Situationen zu trotzen.
<G-vec00739-002-s093><defy.trotzen><en> "Defy your own group.
<G-vec00739-002-s093><defy.trotzen><de> "Trotze deine eigene Gruppe.
<G-vec00739-002-s094><defy.trotzen><en> No, no, I defy distress and torment.
<G-vec00739-002-s094><defy.trotzen><de> Nein, nein, ich trotze Not und Plagen.
<G-vec00739-002-s095><defy.trotzen><en> I defy you Zeus.
<G-vec00739-002-s095><defy.trotzen><de> Ich trotze dir, Zeus.
<G-vec00739-002-s096><defy.trotzen><en> Free your mind and defy gravity in more than 60 compelling and unique puzzles, requiring all your wits and agility.
<G-vec00739-002-s096><defy.trotzen><de> Trotze der Schwerkraft in über 60 fesselnden und einzigartigen Rätseln, welche Verstand und Geschicklichkeit erfordern.
<G-vec00739-002-s097><defy.trotzen><en> Rollercoaster Lagoon: Defy gravity in a tropical paradise, racing on magnetic tracks.
<G-vec00739-002-s097><defy.trotzen><de> Rollercoaster Lagoon – fahre auf magnetischen Strecken und trotze der Schwerkraft.
<G-vec00739-002-s098><defy.trotzen><en> Defy the elements with Nike Shield running shoes and clothes
<G-vec00739-002-s098><defy.trotzen><de> Trotze den Elementen mit Nike Shield Running Schuhen und Bekleidung.
<G-vec00739-002-s099><defy.trotzen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00739-002-s099><defy.trotzen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00739-002-s100><defy.trotzen><en> We believe in the power of integration to defy uncertainty, creating opportunity and providing investors with confidence in their investment decisions and outcomes.
<G-vec00739-002-s100><defy.trotzen><de> Wir glauben an die Kraft der Integration, um der Unsicherheit zu trotzen, Chancen zu nutzen und Investoren Vertrauen bezüglich ihrer Investmententscheidungen und -ergebnisse zu geben.
<G-vec00739-002-s101><defy.trotzen><en> But even wooden bathroom accessories can defy humidity and bacteria - for example, utensils made of teak wood, bamboo or resistant oak.
<G-vec00739-002-s101><defy.trotzen><de> Aber auch Bad-Accessoires aus Holz können Feuchtigkeit und Bakterien trotzen – so zum Beispiel Utensilien aus Teakholz, Bambusholz oder resistentem Eichenholz.
<G-vec00739-002-s102><defy.trotzen><en> Because we believe that one is never too old to defy gravity, to lose ground under one’s feet, to watch people grow and shrink with their own eyes and to be inspired by optical illusions.
<G-vec00739-002-s102><defy.trotzen><de> Denn wir glauben, dass man nie zu alt ist, um der Schwerkraft zu trotzen, den Boden unter den Füßen zu verlieren, Menschen mit den eigenen Augen beim Wachsen und Schrumpfen zu beobachten und sich von optischen Täuschungen begeistern zu lassen.
<G-vec00739-002-s103><defy.trotzen><en> But, sisters and brothers, this historical situation is like a landscape in the Alps, where great masses of snow lie stored on high peaks, which have defied all storms for centuries and seem ready to defy the influence of sun, rain, and tempests for several hundreds of years to come.
<G-vec00739-002-s103><defy.trotzen><de> Aber, Genossinnen und Genossen, es ist in dieser geschichtlichen Situation wie in einer Alpenlandschaft, wo auf hoher Bergesspitze riesige Schneemassen lagern, die seit Jahrhunderten allen Wettern getrotzt haben, und die noch für Jahrhunderte allen Einflüssen der Sonne, des Regens, des Sturmes zu trotzen scheinen.
<G-vec00739-002-s104><defy.trotzen><en> Advantage: They defy wind and weather, are maintenance-free and durable.
<G-vec00739-002-s104><defy.trotzen><de> Vorteil: Sie trotzen Wind und Wetter, sind wartungsfrei und langlebig.
<G-vec00739-002-s105><defy.trotzen><en> R74241.4961 100% Polyester In this Protex Stretch Blouson you defy wind and weather, the quality is water repellent, windproof and breathable.
<G-vec00739-002-s105><defy.trotzen><de> R74241.4961 100% Polyester In diesem Protex Stretch Blouson trotzen Sie Wind und Wetter, die Qualität ist wasserabweisend, winddicht und atmungsaktiv.
<G-vec00739-002-s106><defy.trotzen><en> It appears to defy the definition and constraints of dental steroids.
<G-vec00739-002-s106><defy.trotzen><de> Es scheint, die Bedeutung und den Zwängen der oralen Steroiden zu trotzen.
<G-vec00739-002-s107><defy.trotzen><en> The solid concrete walls and the generous processing of the Corten steel effortlessly defy the elements and promise the residents protection and security the whole year round.
<G-vec00739-002-s107><defy.trotzen><de> Die massiven Betonwände und die großzügige Verarbeitung des Cortenstahls trotzen mühelos den Elementen und versprechen den Bewohnern das ganze Jahr über Schutz und Geborgenheit.
<G-vec00739-002-s108><defy.trotzen><en> Regionally, Saudi Arabia and the United Arab Emirates are now seeking ways to compensate for the loss of Syria as a place where they could defy and bleed Iran.
<G-vec00739-002-s108><defy.trotzen><de> „Regional suchen Saudi-Arabien und die Vereinigten Arabischen Emirate nun nach Wegen, den Verlust Syriens an einem Ort auszugleichen, wo sie dem Iran trotzen und ihn ausbluten könnten.
<G-vec00739-002-s109><defy.trotzen><en> Yet the knowledge of the pure truth, My obvious help and the hope of My coming and life in paradise on the new earth will give you the strength to persevere and to defy every onslaught on part of the worldly authority.
<G-vec00739-002-s109><defy.trotzen><de> Doch das Wissen um die reine Wahrheit, Meine offensichtliche Hilfe und die Hoffnung auf Mein Kommen und das Leben im Paradies auf der neuen Erde wird euch Kraft geben, auszuhalten und jedem Ansturm von seiten weltlicher Macht zu trotzen.
<G-vec00739-002-s110><defy.trotzen><en> Description: Walking across the marble floor in the covered Galleria Vittorio Emanuele II is a party and the shops here are chic, upscale, chicst: the prices in the beautiful windows defy any imagination.
<G-vec00739-002-s110><defy.trotzen><de> Beschreibung: Zu Fuß über den Marmorboden in der überdachten Galleria Vittorio Emanuele II ist eine Partei und die Geschäfte hier sind chic, hochwertig, chicst: die Preise in den schönen Fenstern trotzen jede Vorstellungskraft.
<G-vec00739-002-s111><defy.trotzen><en> They climb walls, jump from roof to roof and defy gravity: The enthusiasts of the trendy urban sport ‘Parkour’ overcome any apparently insurmountable obstacle with athletic top performance.
<G-vec00739-002-s111><defy.trotzen><de> Sie gehen Wände hoch, springen von Dach zu Dach und trotzen der Schwerkraft: Die Anhänger der urbanen Trendsportart „Parkour“ überrennen mit athletischen Höchstleistungen jedes noch so unüberwindbar scheinende Hindernis.
<G-vec00739-002-s112><defy.trotzen><en> They both defy a "pet" coaching point of The Darts Performance Centre which is where a player should stand on the oche.
<G-vec00739-002-s112><defy.trotzen><de> Sie beide trotzen einem unserer Lieblings Trainings Aspekte - nämlich dem Thema, wo ein Spieler am Oche stehen sollte.
<G-vec00739-002-s113><defy.trotzen><en> Combined with the best efficiency and a very long life time the PULS power supplies defy the inhospitable conditions on the ocean.
<G-vec00739-002-s113><defy.trotzen><de> Kombiniert mit dem besten Wirkungsgrad und einer sehr langen Lebensdauer trotzen die PULS Netzteile den unwirtlichen Bedingungen auf hoher See.
<G-vec00739-002-s114><defy.trotzen><en> The probably world’s best trapeze artists will again defy the laws of gravity and overcome the limits of the human anatomy.
<G-vec00739-002-s114><defy.trotzen><de> Die wohl besten Artisten der Welt trotzen wieder einmal den Gesetzen der Schwerkraft und überwinden die Grenzen menschlicher Anatomie.
<G-vec00739-002-s115><defy.trotzen><en> In order to defy the dangers, Zack Zero has a few unusual abilities to explore.
<G-vec00739-002-s115><defy.trotzen><de> Um den Gefahren zu trotzen, hat Zack Zero ein paar ausgefallene Fähigkeiten im Gepäck.
<G-vec00739-002-s116><defy.trotzen><en> Accordingly, the components for the cube-shaped high-power contacts, referred to as REDCUBE terminals, need to be particularly robust and shock resistant since they have to defy curbs, tram tracks or hard cobblestones and withstand high temperatures.
<G-vec00739-002-s116><defy.trotzen><de> Dementsprechend müssen Bauteile wie die würfelförmigen Hochstromkontakte, sogenannte REDCUBE Terminals, besonders robust und erschütterungserprobt sein, denn es gilt Randsteinen, Straßenbahnschienen oder hartem Pflaster zu trotzen und hohe Temperaturen auszuhalten.
<G-vec00739-002-s117><defy.trotzen><en> It is a parallel world whose inhabitants seek to defy the modern world.
<G-vec00739-002-s117><defy.trotzen><de> Es ist eine Parallelwelt, in der man der Moderne trotzen will.
<G-vec00739-002-s118><defy.trotzen><en> In this demanding work, they had learned the laws of nature, yet at times, when the winds were adverse and waves shook their boats, they had to defy the elements.
<G-vec00739-002-s118><defy.trotzen><de> In diesem anstrengenden Beruf haben sie die Gesetze der Natur erlernt und manchmal mussten sie ihnen trotzen, wenn die Winde ungünstig waren und die Wellen die Boote durchschüttelten.
<G-vec00739-002-s119><defy.trotzen><en> For example, in order for the control blocks to be able to defy the extreme operating conditions, the engineers used special steel with a hard-wearing coating.
<G-vec00739-002-s119><defy.trotzen><de> Damit beispielsweise die Steuerblöcke den extremen Einsatzbedingungen trotzen können, setzten die Ingenieure speziellen Stahl mit widerstandsfähiger Beschichtung ein.
<G-vec00739-002-s120><defy.trotzen><en> As they prepared to depart St Petersburg, 197 Duma deputies signed a petition urging others to defy the tsar and continue meeting in Vyborg, Finland.
<G-vec00739-002-s120><defy.trotzen><de> Als sie sich darauf vorbereiteten, Sankt Petersburg zu verlassen, unterzeichneten die Abgeordneten der 197-Duma eine Petition, in der sie andere aufforderten, dem Zaren zu trotzen und sich weiterhin in Vyborg, Finnland, zu treffen.
<G-vec00739-002-s121><defy.trotzen><en> Defy gravity with a cologne that will make you feel like EUPHORIC.
<G-vec00739-002-s121><defy.trotzen><de> Trotzen Sie der Schwerkraft mit einem Cologne, das Ihnen ein geradezu schwereloses Gefühl verleiht.
<G-vec00739-002-s122><defy.trotzen><en> Defy gravity 150ft off the cliffs with the Giant Swing, and go from max G to pure freefall on the super-sized swing.
<G-vec00739-002-s122><defy.trotzen><de> Trotzen Sie auf der Giant Swing 45 Meter über den Klippen der Schwerkraft und beschleunigen Sie auf der übergroßen Schaukel von 0 auf 100 in die völlige Schwerelosigkeit.
<G-vec00739-002-s123><defy.trotzen><en> Defy the elements - rely on this orbital shaker's unique construction to deliver exceptional speed control, accuracy and durability under the most extreme environmental conditions.
<G-vec00739-002-s123><defy.trotzen><de> Trotzen Sie den Elementen – verlassen Sie sich auf die einzigartige Bauweise dieses Orbitalschüttlers, um eine außergewöhnliche Drehzahlkontrolle, Genauigkeit und Langlebigkeit unter den extremsten Umgebungsbedingungen zu gewährleisten.
<G-vec00739-002-s124><defy.trotzen><en> Some of us simply defy the traditional traits assigned to our dates of birth. It's quite normal to have many traits from many signs.
<G-vec00739-002-s124><defy.trotzen><de> Einige von uns trotzen einfach den typischen Eigenschaften, die man unserem Geburtsdatum zuordnet und es ist völlig normal, viele Merkmale diverser Tierkreiszeichen zu haben.
<G-vec00739-002-s125><defy.trotzen><en> This mask is geared to defy the aging process and helps the skin to quickly achieve a radiant and fresh look.
<G-vec00739-002-s125><defy.trotzen><de> Die Maske trotzt dem Alterungsprozess und verleiht der Haut schnell eine strahlende und frische Erscheinung.
<G-vec00739-002-s132><defy.trotzen><en> Rock, rigor… and refuge A minuscule warm nest amid an ocean of rock and ice, high-altitude refuges are a haven of peace to defy the demons of the cold night.
<G-vec00739-002-s132><defy.trotzen><de> Wie eine Insel der Wärme verankert in einem Meer aus Stein und Eis, so ist die Hütte im Hochgebirge ist ein Hort des Friedens, welcher den Dämonen der Nacht trotzt.
<G-vec00739-002-s128><defy.vernichten><en> Choose to be a great paladin and save the people like the narrator wants you to, or decide to defy him.
<G-vec00739-002-s128><defy.vernichten><de> Suche dir aus, ein großartiger Paladin zu sein und rette die Menschen, wie es der Erzähler von dir verlangt, oder vernichte sie.
<G-vec00739-002-s131><defy.weigern><en> Large-sized private enterprises that resort to laying off staff or that seek to defy the national plan of hiring and the sliding scale of working hours will have to be expropriated without compensation;
<G-vec00739-002-s131><defy.weigern><de> Großunternehmen, die Personal abbauen oder sich weigern den nationalen Beschäftigungsplan umzusetzen oder die gleitende Skala der Arbeitszeit anzuwenden, werden entschädigungslos enteignet.
<G-vec00739-002-s082><defy.widersetzen><en> To defy dangers or indecision.
<G-vec00739-002-s082><defy.widersetzen><de> Sich Gefahren oder Unentschlossenheit zu widersetzen.
<G-vec00739-002-s083><defy.widersetzen><en> However, these experimental structures that defy state standards create conflict between Reynolds and the authorities, who are backed by big business.
<G-vec00739-002-s083><defy.widersetzen><de> Diese experimentellen Strukturen, die sich den staatlichen Standards widersetzen, schaffen jedoch einen Konflikt zwischen Reynolds und den Behörden, die von Grossunternehmen unterstützt werden.
<G-vec00739-002-s142><defy.überwinden><en> Drivers seem to defy gravity on their bikes, motorcycles, trucks and cars attempting unbelievable dares.
<G-vec00739-002-s142><defy.überwinden><de> Die Fahrer scheinen die Schwerkraft zu überwinden auf ihren Bikes, Motorrädern, in ihren Trucks und Autos, mit denen sie unglaubliche, waghalsige Manöver ausprobieren.
<G-vec00739-002-s143><defy.überwinden><en> Discover how video fuels the future of work and how IT can help the entire organization defy distance.
<G-vec00739-002-s143><defy.überwinden><de> Erfahren Sie, wie Videofunktionen den Arbeitsplatz der Zukunft fördern und wie die IT dem gesamten Unternehmen dabei helfen kann, Distanzen zu überwinden.
<G-vec00739-002-s144><defy.überwinden><en> The delicate shapes and lines of ink wash painting and abstract drawing seem to defy gravity and float on the white paper background.
<G-vec00739-002-s144><defy.überwinden><de> Die zarten Formen und Linien der Tuschmalerei und der abstrakten Zeichnung scheinen die Schwerkraft zu überwinden und auf dem weißen Papiergrund zu schweben.
