<G-vec01070-002-s035><amuse.amüsieren><en> The half hour when they can amuse themselves there – together with all the nurses and therapists who don’t have other duties at that time – is a real highpoint for everyone.
<G-vec01070-002-s035><amuse.amüsieren><de> Die halbe Stunde, in der sie sich dort mit allen abkömmlichen Krankenschwestern und Therapeutinnen amüsieren, ist für sie ein besonderer Höhepunkt.
<G-vec01070-002-s036><amuse.amüsieren><en> Your masterpiece can be in black and white or in color.Just a few clicks of the mouse and you will easily make a mini-comic, thereby amuse and amaze your friends.
<G-vec01070-002-s036><amuse.amüsieren><de> Ihr Meisterwerk kann schwarz-weiß oder in Farbe sein.In nur ein paar Mausklicks können Sie einen Mini-Comic machen und Ihre Freunde damit amüsieren und überraschen.
<G-vec01070-002-s037><amuse.amüsieren><en> Yes, unfortunately, there are such women who thus simply amuse their ego.
<G-vec01070-002-s037><amuse.amüsieren><de> Ja, leider gibt es solche Frauen, die ihr Ego einfach nur amüsieren.
<G-vec01070-002-s038><amuse.amüsieren><en> In the U4 you can be who you are, you can amuse yourself without losing face.
<G-vec01070-002-s038><amuse.amüsieren><de> Im U4 kann man sein, wer man ist, kann sich amüsieren, ohne das Gesicht zu verlieren.
<G-vec01070-002-s039><amuse.amüsieren><en> A gifted raconteur, his stories of the sea, his corporate years with Revlon and stint as a limbo dancer are sure to amuse enlighten and entertain.
<G-vec01070-002-s039><amuse.amüsieren><de> Ein begabter Autor, seine Geschichten über das Meer, seine Geschäftsjahre mit Revlon und seine Tätigkeit als Limbo-Tänzer werden Sie mit Sicherheit amüsieren, unterhalten und unterhalten.
<G-vec01070-002-s040><amuse.amüsieren><en> Traditional transvestite show-programs, Singing Queens, Miss Div also can either amuse or disappoint.
<G-vec01070-002-s040><amuse.amüsieren><de> Traditionelle Transvestiten-Shows, Singing Queens, Miss Div kann entweder amüsieren oder enttäuschen.
<G-vec01070-002-s041><amuse.amüsieren><en> And that is why our press was protected by the First Amendment– the only business in America specifically protected by the Constitution- -not primarily to amuse and entertain, not to emphasize the trivial and the sentimental, not to simply "give the public what it wants"–but to inform, to arouse, to reflect, to state our dangers and our opportunities, to indicate our crises and our choices, to lead, mold, educate and sometimes even anger public opinion.
<G-vec01070-002-s041><amuse.amüsieren><de> Die Presse ist nicht deshalb das einzige Geschäft, das durch die Verfassung spezifisch geschützt wird, um zu amüsieren und Leser zu gewinnen, nicht um das Triviale und Sentimale zu fördern, nicht um das Publikum immer das zu geben, was es gerade will, sondern um über Gefahren und Möglichkeiten zu informieren, um aufzurütten und zu reflektieren, um unsere Krisen festzustellen und unsere Möglichkeiten aufzuzeigen, um zu führen, zu formen, zu bilden, und manchmal sogar die öffentliche Meinung herauszufordern.
<G-vec01070-002-s042><amuse.amüsieren><en> The Game will not only amuse you but develop your spatial imagination as well.
<G-vec01070-002-s042><amuse.amüsieren><de> Das Spiel wird Sie nicht nur amüsieren, aber Ihre Raumeinbildungskraft ebenso entwickeln.
<G-vec01070-002-s043><amuse.amüsieren><en> For a large ring pacifier is easy to hold, the baby can look at it, twirl it in pens, wave it - in response it will quietly "sound" and thus amuse the child.
<G-vec01070-002-s043><amuse.amüsieren><de> Für einen großen Ring ist der Schnuller einfach zu halten, das Baby kann es betrachten, es in Stifte drehen, es winken - als Antwort wird es leise "klingen" und so das Kind amüsieren.
<G-vec01070-002-s044><amuse.amüsieren><en> They amuse themselves by making fun of those who follow the true religion by accusing them of being brainwashed.
<G-vec01070-002-s044><amuse.amüsieren><de> Sie amüsieren sich, indem sie sich über diejenigen, die der wahren Religion folgen, lustig machen, indem sie diesen vorwerfen, einer Gehirnwäsche unterzogen worden zu sein.
<G-vec01070-002-s045><amuse.amüsieren><en> Evolutionists really amuse me.
<G-vec01070-002-s045><amuse.amüsieren><de> Vertreter der Evolutionstheorie amüsieren mich wirklich.
<G-vec01070-002-s046><amuse.amüsieren><en> Amuse yourself at any one of the world-class theme parks.
<G-vec01070-002-s046><amuse.amüsieren><de> Amüsieren Sie sich in einem der erstklassigen Freizeitparks.
<G-vec01070-002-s047><amuse.amüsieren><en> Entertain your family with your holiday photos on Picasa or amuse yourself with funny YouTube videos.
<G-vec01070-002-s047><amuse.amüsieren><de> Unterhalten Sie Ihre ganze Familie mit ihren Urlaubsfotos auf Picasa oder amüsieren Sie sich mit lustigen YouTube-Videos.
<G-vec01070-002-s048><amuse.amüsieren><en> It seems to amuse him now, after so many years in China.
<G-vec01070-002-s048><amuse.amüsieren><de> Sie scheint ihn inzwischen zu amüsieren, nach all den Jahren in China.
<G-vec01070-002-s049><amuse.amüsieren><en> David knew even then, though, such an idea would amuse or, in some cases, perhaps scandalize many of the other people he knew who weren’t Catholic.
<G-vec01070-002-s049><amuse.amüsieren><de> David wusste schon damals, dass eine solche Idee viele der anderen Leute, die er kannte, die nicht katholisch waren, amüsieren oder in manchen Fällen sogar skandalisieren würde.
<G-vec01070-002-s050><amuse.amüsieren><en> The place where you can amuse yourselves even if you must be careful.
<G-vec01070-002-s050><amuse.amüsieren><de> Die Stelle, wo Sie sich amüsieren können, auch wenn Sie vorsichtig sein müssen.
<G-vec01070-002-s051><amuse.amüsieren><en> We know that there are lots of adult chat providing websites in today’s times, but none of them are like us, because we have the kind of quality and the quantity that will definitely amuse you and make your dick damn hard.
<G-vec01070-002-s051><amuse.amüsieren><de> Wir wissen, dass es heutzutage eine Menge Chats für Erwachsene gibt, die Websites anbieten, aber keiner von ihnen gleicht uns, weil wir die Qualität und Quantität haben, die Sie definitiv amüsieren und Ihren Schwanz verdammt steif machen.
<G-vec01070-002-s052><amuse.amüsieren><en> Metal Frame Swimming Pools are a great choice for a family swimming pool, perfect for the summer holidays to have a swimming pool for the kids to mess around in and if you and your family spend a lot of time in the garden this summer whilst the Olympics are on then the Metal Frame Pool is the ideal addition to your list of “essentials” that will amuse the kids and adults this Summer.
<G-vec01070-002-s052><amuse.amüsieren><de> Es ist eine gute Wahl für ein Familienschwimmbad, ideal für die Sommerferien, um ein Schwimmbad für die Kinder zu haben, um herumzulaufen und wenn Sie und Ihre Familie im Sommer in diesem Sommer viel Zeit verbringen, während die Olympischen Spiele dann sind Die Metallrahmen-Pool ist die ideale Ergänzung zu Ihrer Liste von "Essentials", die die Kinder und Erwachsene in diesem Sommer amüsieren wird.
<G-vec01070-002-s053><amuse.amüsieren><en> But I thought you just wanted to amuse yourself with me.
<G-vec01070-002-s053><amuse.amüsieren><de> Aber ich dachte, du wolltest dich mit mir nur amüsieren...
<G-vec01070-002-s054><amuse.amüsieren><en> During this strange zazen, I simply presented our practice to the spectators, trying to enlighten, amuse and intrigue them.
<G-vec01070-002-s054><amuse.amüsieren><de> In diesem seltsamen Zazen präsentiere ich den Zuschauern einfach unsere Praxis, indem ich versuche, sie aufzuklären, zu amüsieren, zu erstaunen.
<G-vec01070-002-s055><amuse.amüsieren><en> Where ZERO, Fluxus, and Pop amuse themselves.
<G-vec01070-002-s055><amuse.amüsieren><de> Hier amüsiert sich Zero, Fluxus, Pop.
<G-vec01070-002-s056><amuse.amüsieren><en> So Abu Abdillah (a.s.) held him close to him embracing him and said to him: "May my father and mother be ransomed for you, O you who does not amuse nor play”.
<G-vec01070-002-s056><amuse.amüsieren><de> Da hielt Abu Abdillah a.s. ihn nahe an sich, umarmte ihn und sagte zu ihm: Möge mein Vater und meine Mutter für dich hingegeben werden, oh du, der sich weder amüsiert noch spielt”.
<G-vec01070-002-s076><amuse.amüsieren><en> Of course, the Odessa humor will amuse you and will certainly lift your spirits.
<G-vec01070-002-s076><amuse.amüsieren><de> Natürlich wird der Odessa-Humor Sie amüsieren und sicherlich Ihre Stimmung heben.
<G-vec01070-002-s077><amuse.amüsieren><en> Fo's strength is in the creation of texts that simultaneously amuse, engage and provide perspectives.
<G-vec01070-002-s077><amuse.amüsieren><de> Die Stärke Fos liegt darin, daß er Texte schafft, die gleichzeitig amüsieren, engagieren und Perspektiven vermitteln.
<G-vec01070-002-s058><amuse.belustigen><en> Some parents also did not understand the request correctly: it was not a matter of " delivering" the children - "of letting "amuse" and of taking afterwards again.
<G-vec01070-002-s058><amuse.belustigen><de> Einige Eltern verstanden auch das Anliegen nicht richtig: es galt nicht, die Kinder "abzuliefern" - "belustigen" zu lassen und anschließend wieder mitzunehmen.
<G-vec01070-002-s059><amuse.belustigen><en> Birds, who are in the habit to amuse themselves over the surface of the water at night, seem not to love them very much; but the fish are jumping out of the water to catch them.
<G-vec01070-002-s059><amuse.belustigen><de> Vögel, die zur Nacht sich über dem Wasserspiegel zu belustigen pflegen, scheinen sie nicht sehr zu lieben; aber die Fische springen ihnen aus dem Wasser entgegen.
<G-vec01070-002-s062><amuse.bespaßen><en> And besides, in time he could even amuse the pets, so that they’re not bored.
<G-vec01070-002-s062><amuse.bespaßen><de> Und außerdem könnte er in der Zeit auch die Haustiere bespaßen, damit es denen nicht zu langweilig wird.
<G-vec01070-002-s064><amuse.bringen><en> To astonish, surprise and amuse the person passing in the street, enticing them to question their own relationship to the city and the greener world.
<G-vec01070-002-s064><amuse.bringen><de> Überraschen, erstaunen, den Passanten ansprechen und ihn dazu bringen, seine Beziehung zu Stadt und Pflanzenwelt zu hinterfragen.
<G-vec01070-002-s080><amuse.bringen><en> And to amuse them a little... So please, accept my invitation and come to spend a great winter holiday with high-quality relaxation and a smile on your face.
<G-vec01070-002-s080><amuse.bringen><de> Und dabei ihnen auch etwas Spaß zu bringen… Nehmen Sie also meine Einladung an und genießen Sie bei uns einen angenehmen Winterurlaub mit toller Entspannung und einem Lächeln auf dem Gesicht.
<G-vec01070-002-s065><amuse.erfreuen><en> In this park, artists show their sculptures and mazes, bird ponds and children's playgrounds amuse the little ones.
<G-vec01070-002-s065><amuse.erfreuen><de> Im Park, eine der wenigen Grünflächen im dicht bebauten Kowloon, präsentieren Künstler ihre Skulpturen; Irrgarten, Vogelteiche und Kinderspielplätze erfreuen die Kleinen.
<G-vec01070-002-s066><amuse.erheitern><en> Especially during a holiday in South Tyrol you want to savor some of it, because you can enjoy it, want to revel in it, or simply because you like to amuse yourself.
<G-vec01070-002-s066><amuse.erheitern><de> Gerade im Urlaub in Südtirol möchten Sie einige davon auskosten, weil Sie sich daran erfreuen können, darin schwelgen wollen, oder ganz einfach, weil Sie sich erheitern möchten.
<G-vec01070-002-s067><amuse.erheitern><en> "The grotesque may amuse and frighten at the same time, appear ludicrous, absurd or uncanny.
<G-vec01070-002-s067><amuse.erheitern><de> „Das Groteske kann zugleich erheitern und erschrecken, lächerlich wirken, absurd oder unheimlich.
<G-vec01070-002-s068><amuse.erheitern><en> In mid-August the two badger cubs who had grown appreciably during summer appeared too but did not amuse viewers all too often with their presence.
<G-vec01070-002-s068><amuse.erheitern><de> Mitte August erschienen auch die zwei Dachsjungen, die merklich gewachsen waren, aber sie erheiterten die Zuschauer nicht zu oft mit ihrer Anwesenheit.
<G-vec01070-002-s082><amuse.erheitern><en> As a competence, improvisation enriches our mental flexibility and diversity, as a form of stage art it can intrigue and amuse audience and actors alike.
<G-vec01070-002-s082><amuse.erheitern><de> Als Fähigkeit bereichert uns Improvisation durch gedankliche Flexibilität und Vielfalt, als Theaterkunst kann es Publikum wie Auftretende faszinieren und erheitern.
<G-vec01070-002-s073><amuse.machen><en> Using and subverting the digital realm to confront, amuse and distort, the artists presented in FEELING MYSELF are both artist and subject.
<G-vec01070-002-s073><amuse.machen><de> Digitale Techniken nutzend und unterwandernd, machen sich die in FEELING MYSELF präsentierten Künstlerinnen selbst zum Gegenstand der eigenen Arbeit.
<G-vec01070-002-s074><amuse.machen><en> We used to amuse ourselves by cynically dissecting spiritual beliefs and practices when we might have observed that many spiritually-minded persons of all races, colors, and creeds were demonstrating a degree of stability, happiness and usefulness which we should have sought ourselves.
<G-vec01070-002-s074><amuse.machen><de> Wir machten uns noch einen Spaß daraus, spirituelle Überzeugungen anderer und darauf fußendes Handeln in spöttischer und zynischer Weise zu zerpflücken, während wir besser zur Kenntnis genommen hätten, daß viele spirituell orientierte Menschen aller Rassen, Farben und Bekenntnisse einen Grad von Stabilität, Zufriedenheit und Nützlichkeit aufzuweisen hatten, den wir selbst hätten anstreben sollen.
<G-vec01070-002-s081><amuse.machen><en> Players often pretend to violate the rules, score an own goal, and amuse us as much as they can.
<G-vec01070-002-s081><amuse.machen><de> Die Spieler geben oft vor, die Regeln zu verletzen, ein eigenes Tor zu erzielen und uns so viel Spaß wie möglich zu machen.
<G-vec01070-002-s020><amuse.unterhalten><en> The people who visit a fair don’t go there only to amuse themselves, but also to exchange news, to share tips and to gossip.
<G-vec01070-002-s020><amuse.unterhalten><de> Aber all die Leute, die den Jahrmarkt besuchen, gehen da ja nicht nur hin, um unterhalten zu werden, sondern auch, um sich untereinander auszutauschen, Neuigkeiten, Tipps und Tratsch zu erfahren.
<G-vec01070-002-s083><amuse.unterhalten><en> We strongly believe that after this year's great interest and extended submission deadlines, remarkable works and projects will amuse us during the ceremony.
<G-vec01070-002-s083><amuse.unterhalten><de> Nach dem diesjährigen enormen Interesse und dem verlängerten Einsendeschluss glauben wir fest daran, im Rahmen der Feierlichkeiten von bemerkenswerten Arbeiten und Projekten unterhalten zu werden.
<G-vec01070-002-s084><amuse.unterhalten><en> And also to amuse them.
<G-vec01070-002-s084><amuse.unterhalten><de> Und auch, um sie zu unterhalten.
<G-vec01070-002-s085><amuse.unterhalten><en> These particular casinos are able to make money, while the members of the casinos are able to amuse themselves in an assortment of ways.
<G-vec01070-002-s085><amuse.unterhalten><de> Diese besonderen Casinos sind in der Lage, Geld zu verdienen, während die Mitglieder des Casinos in der Lage sind, sich zu unterhalten in einer Auswahl von Möglichkeiten.
<G-vec01070-002-s086><amuse.unterhalten><en> The Lizards also took an immense fancy to him, and when he grew tired of running about and flung himself down on the grass to rest, they played and romped all over him, and tried to amuse him in the best way they could.
<G-vec01070-002-s086><amuse.unterhalten><de> Auch die Eidechsen fassten große Zuneigung zu ihm, und als er vom Umherlaufen müde wurde und sich ins Gras niederwarf, um auszuruhen, spielten und tollten sie auf ihm herum und versuchten ihn so gut zu unterhalten, wie sie nur konnten.
<G-vec01070-002-s087><amuse.unterhalten><en> The Lizards also took an immense fancy to him, and when he grew tired of running about and flung himself down on the grass to rest, they played and romped all over him, and tried to amuse him in the best way they could.
<G-vec01070-002-s087><amuse.unterhalten><de> Die Eidechsen faßten auch eine große Vorliebe für ihn, und als er müde war, umherzulaufen, und sich ins Gras warf, um zu ruhen, da spielten und balgten sie sich auf ihm herum und versuchten ihn so gut, wie sie konnten, zu unterhalten.
<G-vec01070-002-s088><amuse.unterhalten><en> You can amuse your invited guests with comic skits on the naval theme, dance numbers and small theatrical performances with the participation of girls dressed in costumes of maritime style.
<G-vec01070-002-s088><amuse.unterhalten><de> Sie können Ihre eingeladenen Gäste mit komischen Sketchen über das Marinethema, Tanznummern und kleine Theateraufführungen mit der Teilnahme von Mädchen in Kostümen des maritimen Stils unterhalten.
<G-vec01070-002-s089><amuse.unterhalten><en> Make yourself comfortable and let this casting amuse you.
<G-vec01070-002-s089><amuse.unterhalten><de> Mach es dir gemütlich und lass dich von diesem Casting unterhalten.
<G-vec01070-002-s090><amuse.unterhalten><en> But advertising must return to its effectiveness: it must convince and not amuse at all costs.
<G-vec01070-002-s090><amuse.unterhalten><de> Selbst die Werbung muss auf ihre Wirkung zurückkommen: Sie muss überzeugen und nicht um jeden Preis unterhalten.
<G-vec01070-002-s099><amuse.unterhalten><en> At a certain period of our lives, each of us sooner or later starts meditating on how to amuse our future calm leisure, and what to leave behind for our offspring.
<G-vec01070-002-s099><amuse.unterhalten><de> Zu einer gewissen Zeit unseres Lebens, beginnt jeden von uns früher oder später zu meditieren, wie wir unsere zukünftige ruhige Freizeit unterhalten werden, und was für unsere Nachkommen hinterlassen.
<G-vec01070-002-s096><amuse.vergnügen><en> They amuse themselves in the pool and under the shower.
<G-vec01070-002-s096><amuse.vergnügen><de> Beide vergnügen sich im Pool und unter der Dusche.
<G-vec01070-002-s097><amuse.vergnügen><en> The children amuse themselves in the unique playroom, while parents quietly chat.
<G-vec01070-002-s097><amuse.vergnügen><de> Die Kinder vergnügen sich in der einzigartigen Spielzimmer, während die Eltern ruhig unterhalten.
<G-vec01070-002-s100><amuse.vergnügen><en> You have nothing to lose in doing this, of this I can assure you, and you might amuse yourself for a time.
<G-vec01070-002-s100><amuse.vergnügen><de> Du hast nichts dabei zu verlieren, sage ich Dir, und vielleicht macht es Dir eine zeitlang Vergnügen.
