<G-vec00503-002-s010><confide.anvertrauen><en> It is so important to remember, however, that our life is a gift from God, and that we must depend on him, confide in him, and turn towards him always.
<G-vec00503-002-s010><confide.anvertrauen><de> Dabei ist es doch so wichtig, nicht zu vergessen, dass unser Leben ein Geschenk Gottes ist; dass wir uns Gott anvertrauen, auf ihn vertrauen und uns stets an ihn wenden dürfen.
<G-vec00503-002-s012><confide.erzählen><en> Confide in someone you trust.
<G-vec00503-002-s012><confide.erzählen><de> Erzähle es jemandem, dem du vertraust.
<G-vec00503-002-s013><confide.eröffnen><en> You cannot pray to a chemical formula, supplicate a mathematical equation, worship a hypothesis, confide in a postulate, commune with a process, serve an abstraction, or hold loving fellowship with a law.
<G-vec00503-002-s013><confide.eröffnen><de> Ihr könnt nicht zu einer chemischen Formel beten, eine mathematische Gleichung anflehen, eine Hypothese verehren, euch einem Postulat eröffnen, mit einem Prozess in Verbindung treten, einer Abstraktion dienen oder mit einem Gesetz liebevolle Kameradschaft pflegen.
<G-vec00503-002-s017><confide.können><en> Documentation of Abstract Time and again, I come to think of Comte de Virieu (David Allen Rivera), a Mason from the Martiniste lodge at Lyons, upon his return home, when questioned about the Congress (Wilhelmsbad 1781 – where the Illuminati tookcontrol of the Freemason lodges, said: “I will not confide them to you.
<G-vec00503-002-s017><confide.können><de> Immer wieder muss ich an die Worte des Comte de Virieu (David Allen Rivera), Freimaurer aus der Martiniste Loge in Lyon, denken, der nach seiner Rückkehr nach Hause, als er über den Kongress (Wilhelmsbad 1781) - wo die Illuminaten die Kontrolle über die Freimaurerlogen übernahmen – befragt wurde, sagte: “Ich werde Ihnen nichts verraten, ich kann nur sagen, dass alles sehr viel ernster ist, als Sie denken.
<G-vec00503-002-s018><confide.lassen><en> Confide in Him “Seek counsel from your priesthood leaders, especially your bishop.
<G-vec00503-002-s018><confide.lassen><de> „Lasst euch von euren Priestertumsführern beraten, vor allem vom Bischof.
<G-vec00503-002-s019><confide.setzen><en> They confide in a much stronger power.
<G-vec00503-002-s019><confide.setzen><de> Sie setzen auf eine viel stärkere Macht.
<G-vec00503-002-s020><confide.setzen><en> Even opinion leaders from the economic and political elite of developing and emerging countries confide on digitalization in order to predict their home countries a hopeful future.
<G-vec00503-002-s020><confide.setzen><de> Auch Meinungsbildner aus der wirtschaftlichen und politischen Elite von Entwicklungs- und Schwellenländern setzen auf Digitalisierung, um ihren Heimatländern eine hoffnungsvolle Zukunft vorauszusagen.
<G-vec00503-002-s024><confide.sich_anvertrauen><en> If you confide in your friend, this situation will definitely run well for you.
<G-vec00503-002-s024><confide.sich_anvertrauen><de> Wenn Sie sich Ihrem Freund anvertrauen, wird diese Situation definitiv gut für Sie verlaufen.
<G-vec00503-002-s026><confide.trauen><en> They expect a lot from their audience, but confide greatly in its capabilities at the same time.
<G-vec00503-002-s026><confide.trauen><de> Sie verlangen dem Zuhörer einiges ab, trauen ihm aber auch einiges zu.
<G-vec00503-002-s037><confide.vertrauen><en> But Mary did confide to her sister Salome that she thought her son was destined to become a great teacher.
<G-vec00503-002-s037><confide.vertrauen><de> Aber Maria vertraute ihrer Schwester Salome an, sie glaube, ihr Sohn sei bestimmt, ein großer Lehrer zu werden.
<G-vec00503-002-s038><confide.überlassen><en> Do not confide your secret desires to chance but book a seductive escort lady with class, which satisfies your desires with discretion.
<G-vec00503-002-s038><confide.überlassen><de> Überlassen Sie Ihre geheimsten Wünsche nicht dem Zufall, sondern buchen Sie eine verführerische Escortlady mit Niveau, welche Ihre Wünsche mit Diskretion erfüllt.
