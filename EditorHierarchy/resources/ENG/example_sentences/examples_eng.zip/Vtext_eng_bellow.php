<G-vec00426-002-s042><bellow.brüllen><en> The heat begins in september-october and in this time one can hear the bellow of the deers.
<G-vec00426-002-s042><bellow.brüllen><de> Die Paarung beginnt im September-Oktober und in dieser Zeit hört man das Brüllen der Bullen.
