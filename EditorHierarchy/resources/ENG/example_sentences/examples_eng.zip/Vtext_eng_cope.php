<G-vec00301-001-s036><cope.bewältigen><en> Such devices can not cope with the heat the room with very high ceilings, as all the warm air will accumulate at the top.
<G-vec00301-001-s036><cope.bewältigen><de> Solche Geräte können nicht mit der Wärme den Raum mit sehr hohen Decken, wie alle die warme Luft an der Spitze ansammeln bewältigen.
<G-vec00301-001-s037><cope.bewältigen><en> "Because they hide so much, they have to go outside to be ""flushed"" to address openly to be, so a healthy dose of disrespect and a touch of arrogance are ingredients that we can use if we these parasites cope."
<G-vec00301-001-s037><cope.bewältigen><de> "Weil sie so viel zu verbergen, mÃ1⁄4ssen sie nach draußen gehen ""gespÃ1⁄4lt"" werden offen anzusprechen sein, so dass eine gesunde Portion Respektlosigkeit und einem Hauch von Arroganz sind Zutaten, die wir verwenden können, wenn wir diese Parasiten bewältigen."
<G-vec00301-001-s038><cope.bewältigen><en> At this time we will see how the prisoners manage to handle their feelings of anger and trying to cope with his life behind bars.
<G-vec00301-001-s038><cope.bewältigen><de> Zu diesem Zeitpunkt werden wir sehen, wie die Gefangenen gelingt, ihre Gefühle von Wut und mit seinem Leben hinter Gittern zu bewältigen versucht zu behandeln.
<G-vec00301-001-s039><cope.bewältigen><en> Because sea salt air and acid atmosphere very quickly corrode zinc surface, but they cannot cope with the polymer coating.
<G-vec00301-001-s039><cope.bewältigen><de> Da Meersalz Luft und sauren Atmosphäre sehr schnell Zinkoberfläche korrodieren, aber sie können nicht mit der Polymerbeschichtung bewältigen.
<G-vec00301-001-s040><cope.bewältigen><en> "To cope with future crises, the UN Secretary General has stated the urgent need for ""leadership from a central political authority whose remit includes all of those (health and non-health) sectors""."
<G-vec00301-001-s040><cope.bewältigen><de> "Um künftige Krisen zu bewältigen hat der UN-Generalsekretär die dringende Notwendigkeit von ""Führung durch eine zentrale politische Autorität, deren Zuständigkeit alle Sektoren (den Gesundheitssektor und darüber hinaus) umfasst"", erklärt."
<G-vec00301-001-s041><cope.bewältigen><en> Many special trains were deployed to cope with the new increase in traffic volume.
<G-vec00301-001-s041><cope.bewältigen><de> Zahlreiche Sonderzüge wurden eingesetzt, um das wieder ansteigende Verkehrsaufkommen zu bewältigen.
<G-vec00301-001-s042><cope.bewältigen><en> It starts producing more and more blood cells to cope with the emergency.
<G-vec00301-001-s042><cope.bewältigen><de> Sie beginnt immer mehr Blutzellen zu produzieren, um diesen Notfall zu bewältigen.
<G-vec00301-001-s043><cope.bewältigen><en> 3.easy to cope with not easy to damage.
<G-vec00301-001-s043><cope.bewältigen><de> 3.easy zu bewältigen nicht leicht zu beschädigen.
<G-vec00301-001-s044><cope.bewältigen><en> Playing with tools in a workshop is both an opportunity for a child to spend time in an interesting way and to develop craft skills, and an opportunity to train their imagination, enabling them to better cope with the challenges of everyday life.
<G-vec00301-001-s044><cope.bewältigen><de> Das Spielen mit Werkzeugen in einer Werkstatt ist für ein Kind sowohl eine Gelegenheit, Zeit auf interessante Weise zu verbringen und handwerkliche Fähigkeiten zu entwickeln, als auch seine Phantasie zu schulen, was es ihm ermöglicht, die Herausforderungen des Alltags besser zu bewältigen.
<G-vec00301-001-s045><cope.bewältigen><en> Once completed, Crossrail and the Grand Paris projects should ensure London and Paris are able to cope with the expected influx of new workers over the coming decades.
<G-vec00301-001-s045><cope.bewältigen><de> Nach der Fertigstellung sollten Crossrail und die Projekte von Grand Paris gewährleisten, dass London und Paris den erwarteten Zustrom neuer Arbeitskräfte in den kommenden Jahrzehnten bewältigen können.
<G-vec00301-001-s046><cope.bewältigen><en> Healing powder helps to cope with the consequences of chemical and radiation therapy in the treatment of cancer.
<G-vec00301-001-s046><cope.bewältigen><de> Heilpulver hilft, die Folgen der chemischen und Strahlentherapie bei der Behandlung von Krebs zu bewältigen.
<G-vec00301-001-s047><cope.bewältigen><en> Where to Buy Intivar In Vryheid South Africa And The Way Intivar Could Affect Your Sexual Lifestyle Instantly In case you have hassles with tightening the vagina, loosened vagina, vaginal dryness or possibly techniques to raise your sexual drive, you should definitely understand how difficult it truly is to cope with.
<G-vec00301-001-s047><cope.bewältigen><de> Bezugsquellen Intivar In Vryheid Südafrika und der Weg Intivar konnte sofort Auswirkungen auf Ihre sexuelle Lifestyle Falls Sie Probleme mit Anziehen der Vagina, gelockert Vagina, vaginale Trockenheit oder möglicherweise Techniken, um Ihre sexuellen Antrieb zu erhöhen, sollten Sie unbedingt verstehen, wie schwierig es ist wirklich ist zu bewältigen.
<G-vec00301-001-s048><cope.bewältigen><en> Disadvantages of the combined system arethe need to turn on and off the fan, to help cope with what equipment ventilation small inexpensive timer or timer.
<G-vec00301-001-s048><cope.bewältigen><de> Nachteile des kombinierten Systems sinddie Notwendigkeit, auf und neben dem Lüfter zu drehen, mit dem, was Ausrüstung Belüftung kleinen, billigen Timer oder Zeitgeber zu bewältigen.
<G-vec00301-001-s049><cope.bewältigen><en> The courses aim at enabling the participants to acquire a standard pronunciation and intonation of the French language as well as a basic knowledge of grammar and vocabulary needed to cope successfully, both in writing and orally, in key communicative situations of every day life as a student and in a professional environment.
<G-vec00301-001-s049><cope.bewältigen><de> Ziel der Ausbildung ist es, eine normgerechte Aussprache und Intonation der französischen Sprache, Kenntnisse grundlegender lexikalischer und grammatischer Inhalte sowie eine elementare Kommunikationsfähigkeit zu erwerben, um wichtige ausgewählte Situationen des Studien-und Berufsalltags schriftlich und mündlich bewältigen zu können.
<G-vec00301-001-s050><cope.bewältigen><en> In Nigeria he now calls for upgrading Africa ́s infrastructure so that young Africans stay at home – saying Europe cannot cope with these migration flows.
<G-vec00301-001-s050><cope.bewältigen><de> In Nigeria fordert er nun, die Infrastruktur Afrikas zu verbessern, damit junge Afrikaner zu Hause bleiben – und sagt, Europa könne diese Migrationsströme nicht bewältigen.
<G-vec00301-001-s051><cope.bewältigen><en> The development of the necessary skills to cope and manage daily life better: problem-solving, goal-setting, decision-making, using resources effectively, managing pain, fatigue, anger, depression, etc.
<G-vec00301-001-s051><cope.bewältigen><de> Die Entwicklung der notwendigen Fähigkeiten, um das tägliche Leben besser zu bewältigen und zu managen: Problemlösung, Zielsetzung, Entscheidungsfindung, effektiver Einsatz von Ressourcen, Umgang mit Schmerzen, Müdigkeit, Wut, Depressionen usw.
<G-vec00301-001-s052><cope.bewältigen><en> Most of the church body is sound asleep and has no idea what they are facing or how to cope with it.
<G-vec00301-001-s052><cope.bewältigen><de> Der Großteil der Kirche ist in einem tiefen Schlaf und hat keine Ahnung, was ihnen bevorsteht oder wie dies zu bewältigen ist.
<G-vec00301-001-s053><cope.bewältigen><en> Göppel MaxiTrain can become an alternative to standard buses that do not always cope with huge passenger traffic on a number of very busy routes of Dresdner Verkehrsbetriebe AG.
<G-vec00301-001-s053><cope.bewältigen><de> Der Göppel MaxiTrain kann zur Alternative für Standardbusse werden, die zur Zeit den riesigen Fahrgaststrom auf den extrem belasteten Linien der Dresdner Verkehrsbetriebe AG nicht bewältigen.
<G-vec00301-001-s054><cope.bewältigen><en> Employees will ask for subsidies because of a reduction in their salaries due to the fewer working hours and we aren’t sure how to cope with this,” the Korea Employers Federation said in a statement.
<G-vec00301-001-s054><cope.bewältigen><de> "Die Mitarbeiter werden in ihrer Gehälter aufgrund einer Reduktion für Subventionen bitten aufgrund der weniger Arbeitszeit und wir sind nicht sicher, wie dies zu bewältigen "", sagte der Korea Arbeitgeberverband in einer Erklärung."
<G-vec00301-001-s055><cope.bewältigen><en> Any biological system processing acoustic signals has to cope with reflections interfering with the original signal.
<G-vec00301-001-s055><cope.bewältigen><de> Jedes biologische System, das akustische Signale verarbeitet, muss Störungen des originalen Signals auf Grund von Reflektionen (Echos) bewältigen können.
<G-vec00301-001-s056><cope.bewältigen><en> "Systematic gaining knowledge about the media will learn to better cope with the negative phenomena that are associated with the media "", Markovic said."
<G-vec00301-001-s056><cope.bewältigen><de> "Systematische Gewinnung des Wissens über die Medien erfahren, mit den negativen Erscheinungen besser bewältigen zu können, die mit den Medien verbunden sind "", Markovic sagte."
<G-vec00301-001-s057><cope.bewältigen><en> That's why with railway incidents the command personnel should immediately be increased to cope with the extremely high workload.
<G-vec00301-001-s057><cope.bewältigen><de> "Deshalb sollte beim Stichwort Bahnereignis sofort die Führung ""hochgefahren werden"", um die extrem hohe Arbeitsbelastung bewältigen zu können."
<G-vec00301-001-s058><cope.bewältigen><en> Comprehensive selection, the latest technology, competent advice, and a specialist service: Doctor, therapists and patients receive everything they need here to enable them to cope with the challenges of home life and the workplace.
<G-vec00301-001-s058><cope.bewältigen><de> Umfassende Auswahl, neueste Technik, kompetente Beratung und fachmännischer Service: Bei uns erhalten Ärzte, Therapeuten, Patienten und externe Kunden alles, was sie brauchen, damit sie zu Hause und am Arbeitsplatz ihre Aufgaben bewältigen können.
<G-vec00301-001-s059><cope.bewältigen><en> The number of hours of instruction is decreasing to enable teachers to cope with the massive influx of pupils.
<G-vec00301-001-s059><cope.bewältigen><de> Die Anzahl der Unterrichtsstunden sinkt, damit die Lehrer den Ansturm an Schülern bewältigen können.
<G-vec00301-001-s060><cope.bewältigen><en> """Healthy ageing is not just about prolonging life. It is about promoting the necessary means to enable older people to continue to participate in society and to cope with daily life,"" said Dr. Elizabeth Mestheneos, President of the AGE Platform Europe, a network of about 150 organizations focusing on people aged 50+."
<G-vec00301-001-s060><cope.bewältigen><de> """Gesundes Altern trägt nicht nur zur Lebensverlängerung bei, sondern ermöglicht älteren Menschen eine höhere Lebensqualität, indem sie so lang wie möglich am gesellschaftlichen Leben teilnehmen und ihren Alltag bewältigen können"", sagte Dr. Elizabeth Mestheneos, Präsidentin der AGE Platform Europe, einem Netzwerk aus rund 150 Organisationen von und für Menschen ab 50 Jahren, das sich für die Anliegen, Ziele und Interessen der 150 Millionen Senioren innerhalb der Europäischen Union einsetzt."
<G-vec00301-001-s061><cope.bewältigen><en> The basis enabling our STRESSLESS ropes to cope with the challenges they are exposed to as carrying ropes is the proven sliding guide process.
<G-vec00301-001-s061><cope.bewältigen><de> Damit unsere STRESSLESS Seile derartige Einsätze als Tragseile bewältigen können, basieren sie auf dem bewährten Verfahren der Gleitführung.
<G-vec00301-001-s062><cope.bewältigen><en> (23.01.2019) Exploring Foreign Worlds with Robot Teams Autonomous machines are to jointly cope with difficult tasks in the deep sea or on Mars.
<G-vec00301-001-s062><cope.bewältigen><de> (23.01.2019) Mit Roboterteams fremde Welten erkunden Autonome Maschinen sollen in der Tiefsee oder auf dem Mars gemeinsam schwierige Aufgaben bewältigen können.
<G-vec00301-001-s063><cope.bewältigen><en> a profit power commensurate with the objectives in order to cope with the future successfully.
<G-vec00301-001-s063><cope.bewältigen><de> eine den Zielen angemessene Ertragskraft, um die Zukunft erfolgreich bewältigen zu können.
<G-vec00301-001-s064><cope.bewältigen><en> In order to cope with complex and extremely demanding logistics challenges, METRO LOGISTICS works with selected outstanding logistics service companies which provide a capable transnational transport network with their own hubs.
<G-vec00301-001-s064><cope.bewältigen><de> Um die komplexen, außerordentlich anspruchsvollen logistischen Herausforderungen bewältigen zu können, arbeitet die METRO LOGISTICS mit ausgewählten Logistikdienstleistern zusammen, die über ein leistungsfähiges, flächendeckendes Transportnetzwerk mit Umschlagplätzen verfügen.
<G-vec00301-001-s065><cope.bewältigen><en> One has grown used to the four-year rhythm at which the focus on sculptural art comes to Biel where, at a convenient venue, Switzerland presents the way its artists cope with space and matter in these turbulent times.
<G-vec00301-001-s065><cope.bewältigen><de> Man hat sich daran gewöhnt, daß Biel alle vier Jahre zum Brennpunkt der plastischen Kunst geworden ist, wo die Schweiz auf überschaubarem Platz darlegt, wie sie auf künstlerische Weise Raum und Materie in bewegter Zeit bewältigt.
<G-vec00301-001-s066><cope.bewältigen><en> In the end, the woman no longer cope with his body.
<G-vec00301-001-s066><cope.bewältigen><de> Am Ende bewältigt die Frau nicht mehr mit seinem Körper.
<G-vec00301-001-s067><cope.bewältigen><en> The smart SILENO is suitable for lawn areas of up to 1,000 mÂ2 and, thanks to its powerful rear-wheel drive, is even able to cope with uneven ground and inclines of up to 35 percent.
<G-vec00301-001-s067><cope.bewältigen><de> Der smart SILENO ist für Rasenflächen bis 1.000 Quadratmeter geeignet und bewältigt mit dem kraftvollen Hinterradantrieb unebenes Gelände und sogar Steigungen bis 35 Prozent.
<G-vec00301-001-s068><cope.bewältigen><en> """Allianz continues to cope successfully with the impact of the ongoing financial markets crisis on our business."
<G-vec00301-001-s068><cope.bewältigen><de> """Die Allianz bewältigt die Auswirkungen der Finanzmarktkrise auf das Geschäft weiterhin erfolgreich."
<G-vec00301-001-s069><cope.bewältigen><en> The smart SILENO+ is suitable for lawn areas of up to 1,300 m2 and, thanks to its powerful rear-wheel drive, is able to cope with uneven ground and even with inclines of up to 35 percent.
<G-vec00301-001-s069><cope.bewältigen><de> Der smart SILENO+ ist für Rasenflächen bis 1.300 Quadratmeter geeignet und bewältigt mit dem kraftvollen Hinterradantrieb unebenes Gelände und sogar Steigungen bis 35 Prozent.
<G-vec00301-001-s108><cope.können><en> Believe me, this is the way most people cope.
<G-vec00301-001-s108><cope.können><de> Glauben Sie mir, dies ist die Art und Weise die meisten Menschen damit umgehen.
<G-vec00301-001-s109><cope.können><en> In earlier times, many books were proscribed by the church because they were considered to be harmful to the general public and one didn't credit the normal people with the ability to cope with them.
<G-vec00301-001-s109><cope.können><de> Früher wurden viele Bücher auf den Index der Kirche gestellt, weil man sie für die Allgemeinheit schädlich hielt und man dem allgemeinen Volk nicht zugetraut hat, damit umgehen zu können.
<G-vec00301-001-s110><cope.können><en> In working out a potential solution to the problem based upon the surmise that it was due to the unusually high geological activity in the area, Joachim developed two prototypes which, he believed, would cope with this particular problem.
<G-vec00301-001-s110><cope.können><de> Indem er eine Lösung für das Problem suchte, welche auf die Annahme, daß die außergewöhnlich starken geologischen Instabilität in dem Gebiet das eigentliche Problem ist, hat Joachim zwei Prototypen entwickelt wo er annahm, daß diese damit umgehen könnten.
<G-vec00301-001-s111><cope.können><en> "Because ""cardiopatitis"" is not recognised as an illness, people with it neither know that they have it, nor how to cope with it."
<G-vec00301-001-s111><cope.können><de> Weil Kardiopatitis nicht offiziell als Krankheit gilt, wissen Betroffene wahrscheinlich gar nicht, dass sie daran leiden – und noch weniger, wie sie damit umgehen sollen.
<G-vec00301-001-s112><cope.können><en> I think being the partner of a musician is not always that easy, as you need to accept and cope with the other's passion for music.
<G-vec00301-001-s112><cope.können><de> Ich glaube als Partner eines Musikers ist es nicht immer einfach, die Leidenschaft gegenüber der Musik zu akzeptieren und damit umgehen zu können.
<G-vec00301-001-s113><cope.umgehen><en> However, we have to cope with it.
<G-vec00301-001-s113><cope.umgehen><de> Allerdings haben wir, damit umzugehen.
<G-vec00301-001-s114><cope.umgehen><en> While embarrassing, there are definite approaches to cope with it.
<G-vec00301-001-s114><cope.umgehen><de> Während peinlich, gibt es bestimmte Vorgehensweisen, damit umzugehen.
<G-vec00301-001-s115><cope.umgehen><en> Most people who are faced with the problem of infestation by bedbugs, try to cope with it on their own.
<G-vec00301-001-s115><cope.umgehen><de> Die meisten Menschen, die mit dem Problem des Befalls durch Bettwanzen konfrontiert sind, versuchen selbstständig damit umzugehen.
<G-vec00301-001-s116><cope.umgehen><en> It is used in case the patient has panic fear of dental intervention and can not cope with it.
<G-vec00301-001-s116><cope.umgehen><de> Um sie zurückgegriffen, wenn der Patient panichesiky Angst vor Zahnbehandlungen, und nicht in der Lage, damit umzugehen.
<G-vec00301-001-s117><cope.umgehen><en> "Indeed far from being an alternative to the neo-liberal type of globalisation, such a politics accepts the basic tenets of neo-liberal orthodoxy and limits itself to helping people to cope with what is perceived as a ""fate""by making themselves ""employable""."
<G-vec00301-001-s117><cope.umgehen><de> "Solche Politik akzeptiert - in Wahrheit weit entfernt von einer Alternative zur neoliberalen Form der Globalisierung - die grundlegenden Lehren neoliberaler Orthodoxie und beschränkt sich darauf, den Leuten zu helfen, damit umzugehen, was als ""Schicksal"" wahrgenommen wird, und zwar dadurch, sie ""employable"" zu machen."
<G-vec00301-001-s118><cope.umgehen><en> Getting to cope with it even the kids, but then comes to the professionals of the case.
<G-vec00301-001-s118><cope.umgehen><de> Anreise, damit umzugehen, auch die Kinder, aber dann kommt zu den Profis der Fall.
<G-vec00301-001-s119><cope.umgehen><en> Even inexperienced users to cope with it.
<G-vec00301-001-s119><cope.umgehen><de> Auch für unerfahrene Benutzer, damit umzugehen.
<G-vec00301-001-s120><cope.umgehen><en> Withdrawal symptoms, acute and protracted, are described along with an explanation of why they may occur and how to cope with them.
<G-vec00301-001-s120><cope.umgehen><de> Entwöhnungs-/ Entzugssymptome, akut oder protahiert werden beschrieben, und es wird erklärt, warum diese auftreten und wie damit umzugehen ist.
<G-vec00301-001-s121><cope.umgehen><en> Ideal - electronic tonometers, to cope with them quite easily.
<G-vec00301-001-s121><cope.umgehen><de> Ideal - elektronische Tonometer, um ganz leicht damit umzugehen.
<G-vec00301-001-s122><cope.umgehen><en> """We know about the huge responsibility that rests with us and we also know how to cope with it."
<G-vec00301-001-s122><cope.umgehen><de> """Wir wissen welche Verantwortung auf uns lastet und wissen auch damit umzugehen."
<G-vec00301-001-s123><cope.umgehen><en> As the level of pressure gets too great, stress eventually surpasses our ability to cope with it in a positive way.
<G-vec00301-001-s123><cope.umgehen><de> Da das Niveau der Druck zu groß wird, übertrifft Stress schließlich unsere Fähigkeit, in einer positiven Weise damit umzugehen.
<G-vec00301-001-s124><cope.umgehen><en> The focus is on withdrawal symptoms, and how to cope with them if they occur.
<G-vec00301-001-s124><cope.umgehen><de> Die Hauptaufmerksamkeit hier gilt den Entzugssymptomen und wie damit umzugehen ist, wenn sie auftreten.
<G-vec00301-001-s125><cope.umgehen><en> The budding architects learn to cope with the fact that their work is publicly visible in the shared space – this is part of the deal.
<G-vec00301-001-s125><cope.umgehen><de> Quasi frei Haus lernen die angehenden Architektinnen und Architekten damit umzugehen, dass ihre Arbeiten im geteilten Raum öffentlich sichtbar sind.
<G-vec00301-001-s126><cope.umgehen><en> The guide 'Culture Shock' - How to Deal with the Challenges of Studying Abroad (PDF, 201 KB) helps you prevent, recognize and cope with 'culture shock'.
<G-vec00301-001-s126><cope.umgehen><de> Der Ratgeber Culture shock - how to deal with the cahllenges of studying abroad (PDF, 201 KB) (nur in Englisch verfÃ1⁄4gbar) hilft Ihnen, einen «Kulturschock» zu vermeiden, zu erkennen und damit umzugehen.
<G-vec00301-001-s127><cope.umgehen><en> For long-term changes necessary to understand what is going on with your hormone levels and that will cope with that.
<G-vec00301-001-s127><cope.umgehen><de> Um eine dauerhafte Veränderung Sie müssen verstehen, was passiert mit Ihren Hormonhaushalt und was wird damit umzugehen.
<G-vec00301-001-s128><cope.zurechtkommen><en> And if the adult already has skills to resist to various attacks in the party, children can not always cope with it.
<G-vec00301-001-s128><cope.zurechtkommen><de> Und wenn der erwachsene Mensch die Fertigkeiten schon hat, verschiedenen Ausfällen zur Seite entgegenzustehen, so können die Kinder nicht immer damit zurechtkommen.
<G-vec00301-001-s129><cope.zurechtkommen><en> They have to cope with accompanying a loved one through all phases of a potentially short course of an illness that can have serious functional, cognitive and psychological consequences for persons affected and, in the worst case, can end fatally.
<G-vec00301-001-s129><cope.zurechtkommen><de> Diese müssen damit zurechtkommen, einen nahestehenden Menschen durch alle Phasen eines potenziell kurzen Krankheitsverlaufs zu begleiten, der für den Betroffenen schwerwiegende funktionale, kognitive und psychologische Folgen haben kann und im schlechtesten Fall tödlich endet.
<G-vec00301-001-s130><cope.zurechtkommen><en> We all have to cope with that.
<G-vec00301-001-s130><cope.zurechtkommen><de> Damit müssen wir alle zurechtkommen.
<G-vec00301-001-s131><cope.zurechtkommen><en> If a child has this kind of problems and parents understand that they cannot cope with them on their own, then it is necessary to contact a professional.
<G-vec00301-001-s131><cope.zurechtkommen><de> Wenn ein Kind solche Probleme hat und die Eltern verstehen, dass sie nicht alleine damit zurechtkommen, ist es notwendig, sich an einen Fachmann zu wenden.
<G-vec00301-001-s132><cope.zurechtkommen><en> If nevertheless you doubt that will be able independently to cope with it, our article to you in the help.
<G-vec00301-001-s132><cope.zurechtkommen><de> Wenn doch Sie bezweifeln, dass damit selbständig, so unser Artikel Ihnen in die Hilfe zurechtkommen können.
<G-vec00301-001-s133><cope.zurechtkommen><en> How they cope is not something independent from the objective physical world; rather it is a product of that world.
<G-vec00301-001-s133><cope.zurechtkommen><de> Wie sie damit zurechtkommen, ist nicht etwas von der objektiven physischen Welt Unabhängiges; sie ist vielmehr ein Produkt jener Welt.
<G-vec00301-001-s139><cope.ertragen><en> This alone makes life difficult to cope with.
<G-vec00301-001-s139><cope.ertragen><de> Das allein macht das Leben schwer zu ertragen.
<G-vec00301-001-s140><cope.ertragen><en> This unpredictability and lack of a sense of security may be difficult for people to cope with.
<G-vec00301-001-s140><cope.ertragen><de> Diese Unvorhersehbarkeit und das Fehlen von Sicherheit könnte für einige Menschen schwer zu ertragen sein.
<G-vec00301-001-s141><cope.ertragen><en> The breathing and relaxation exercises learned during birth preparation courses make it easier for the expectant mother to cope with her contractions.
<G-vec00301-001-s141><cope.ertragen><de> Mit den Atem- und Entspannungsübungen, die Sie während des Geburtsvorbereitungskurses gelernt haben, ertragen Sie die Wehen leichter.
<G-vec00301-001-s142><cope.ertragen><en> My dear, life gets harder to cope with every day.
<G-vec00301-001-s142><cope.ertragen><de> Meine Liebe, das Leben ist mit jedem Tag schwerer zu ertragen.
<G-vec00301-001-s143><cope.ertragen><en> Earlier on I could only cope with the pain by taking enzymes.
<G-vec00301-001-s143><cope.ertragen><de> Ich konnte früher die Schmerzen nur mit Enzymen ertragen.
<G-vec00301-001-s163><cope.fertigwerden><en> This simple composition helps to cope with emotional stress, anxiety and insomnia, it improves mood under constant psychological stress («manager syndrome»), helps against headaches associated with nervous tension and migraine.
<G-vec00301-001-s163><cope.fertigwerden><de> Diese einfache Zusammensetzung hilft mit emotionalem Stress, Angstzuständen und Schlaflosigkeit fertig zu werden, es verbessert die Stimmung unter ständigem psychischem Stress („Manager-Syndrom“), hilft gegen Kopfschmerzen, die mit Nervosität und Migräne zusammenhängen.
<G-vec00301-001-s164><cope.fertigwerden><en> It may shock those of us who are over blameless and sinless, but the business is very easy to cope with corruption.
<G-vec00301-001-s164><cope.fertigwerden><de> Es kann Schock diejenigen von uns, über untadelig und ohne Sünde sind, aber das Geschäft ist sehr einfach, mit der Korruption fertig zu werden.
<G-vec00301-001-s165><cope.fertigwerden><en> Acquiring new powers, the sorceress made available new magical possibilities, and so with each new level they are able to cope with the increasingly complex and more powerful enemy.
<G-vec00301-001-s165><cope.fertigwerden><de> Erwerb neuer Kompetenzen, machte die Zauberin verfügbaren neuen magischen Möglichkeiten, und so mit jeder neuen Ebene sind sie in der Lage, mit der zunehmend komplexer und mächtiger Feind fertig zu werden.
<G-vec00301-001-s166><cope.fertigwerden><en> To cope with sleeping disorder or many other health problems, the fundamental step is to take enough nutrients for a healthy body.
<G-vec00301-001-s166><cope.fertigwerden><de> Um mit Schlafstörungen oder vielen anderen Gesundheitsproblemen fertig zu werden, ist der grundlegende Schritt, ausreichend Nährstoffe für einen gesunden Körper zu sich zu nehmen.
<G-vec00301-001-s167><cope.fertigwerden><en> So I was forced to cope – by pretending they didn't exist.
<G-vec00301-001-s167><cope.fertigwerden><de> So war ich fertig zu werden gezwungen - indem er vorgibt, sie nicht existieren.
<G-vec00301-001-s168><cope.fertigwerden><en> Sadly, in the wake of the bombings that took place in London last July, your country still has to cope with acts of indiscriminate violence directed against members of the public.
<G-vec00301-001-s168><cope.fertigwerden><de> Bedauerlicherweise muss Ihr Land infolge der im vergangenen Juli in London verübten Bombenanschläge immer noch mit willkürlichen Gewaltakten fertig werden, die gegen Personen des öffentlichen Lebens gerichtet sind.
<G-vec00301-001-s169><cope.fertigwerden><en> Many children, it would seem, not bad cope with the preparation for the lessons.
<G-vec00301-001-s169><cope.fertigwerden><de> Viele Kinder scheinen mit der Vorbereitung auf den Unterricht nicht schlecht fertig zu werden.
<G-vec00301-001-s170><cope.fertigwerden><en> Physiotherapy may be needed to improve musculoskeletal function, while psychological and social support for the patient and the family helps them to cope with the stress and strains of a chronic disease.
<G-vec00301-001-s170><cope.fertigwerden><de> Zur Verbesserung der Funktion des Bewegungsapparates kann Physiotherapie notwendig sein, während eine psychologische und soziale Beratung des Patienten und seiner Angehörigen dabei helfen kann, mit dem Stress und den Belastungen einer chronischen Erkrankung fertig zu werden.
<G-vec00301-001-s171><cope.fertigwerden><en> According to the CA model of Porter, a competitive strategy takes offensive or defensive action to create a defendable position in an industry, in order to cope successfully with competitive forces and generate a superior Return on Investment.
<G-vec00301-001-s171><cope.fertigwerden><de> Nach dem Wettbewerbsvorteil-Modell von Porter ergreift eine Wettbewerbsstrategie offensive oder defensive Maßnahmen, um eine zu verteidigende Position in einer Industrie zu schaffen, und um mit konkurrierenden Kräften erfolgreich fertig zu werden und höheren Kapitalrendite zu erzeugen.
<G-vec00301-001-s172><cope.fertigwerden><en> To cope with excess fluid, the heart must pump harder, squeezing its muscles with more force to fill the extra volume.
<G-vec00301-001-s172><cope.fertigwerden><de> Um mit überschüssiger Flüssigkeit fertig zu werden, muss das Herz stärker pumpen und seine Muskeln mit mehr Kraft zusammendrücken, um das zusätzliche Volumen zu füllen.
<G-vec00301-001-s173><cope.fertigwerden><en> Careful attention must be given to ensure that the poorest people are helped to take advantage of the new opportunities and to cope with the impacts of a more open system of world trade.
<G-vec00301-001-s173><cope.fertigwerden><de> Es muss sorgfältig darauf geachtet und dafür gesorgt werden, dass den ärmsten Menschen dabei geholfen wird, sich die neuen Chancen zu Nutze zu machen und mit den Auswirkungen eines offeneren Welthandelssystems fertig zu werden.
<G-vec00301-001-s174><cope.fertigwerden><en> Thus, only the transfected cells should be protected from the drug, or be able to survive as they have the necessary gene to cope with the changed growth condition.
<G-vec00301-001-s174><cope.fertigwerden><de> So nur die transfected Zellen sollten vor der Droge geschÃ1⁄4tzt werden, oder sind in der Lage zu Ã1⁄4berleben, da sie das notwendige Gen haben, zum mit der geänderten Wachstumszustand fertig zu werden.
<G-vec00301-001-s175><cope.fertigwerden><en> "By the ever growing need of expansion, the European states, hostile to one another but unable to cope with one another, would continue to hinder each other in the execution of their ""mission"" in the Near East, Africa and Asia, and they would everywhere be forced back by the United States of North America, and by Japan."
<G-vec00301-001-s175><cope.fertigwerden><de> Die europäischen Staaten, die einander feindlich sind, aber unfähig, mit einander fertig zu werden, würden einander bei ihrem Bedürfnis nach zunehmender Ausdehnung sich weiter bei der Durchführung ihrer »Mission« im Nahen Osten, in Afrika und Asien Knüppel zwischen die Beine werfen und dann überall von den Vereinigten Staaten und Japan zurückgedrängt werden.
<G-vec00301-001-s176><cope.fertigwerden><en> To cope with this negative effect, it is necessary to take special anti-hypertensive agents.
<G-vec00301-001-s176><cope.fertigwerden><de> Um mit diesem negativen Effekt fertig zu werden, ist es notwendig, spezielle blutdrucksenkende Mittel einzunehmen.
<G-vec00301-001-s177><cope.fertigwerden><en> Instead we must challenge them to do political work by themselves, to thoroughly educate them for it and help them to cope with the petty-bourgeois antiauthoritarian mode of thinking.
<G-vec00301-001-s177><cope.fertigwerden><de> Sondern wir müssen sie herausfordern, selbst Politik zu machen, müssen sie gründlich dafür ausbilden und ihnen helfen, mit der kleinbürgerlich-antiautoritären Denkweise fertig zu werden.
<G-vec00301-001-s178><cope.fertigwerden><en> It is easy to cope with and not easy to damage.
<G-vec00301-001-s178><cope.fertigwerden><de> Fertig zu werden ist einfach, mit und nicht einfach zu beschädigen.
<G-vec00301-001-s179><cope.fertigwerden><en> """I'd never think that a simple cream could cope with skin problems."
<G-vec00301-001-s179><cope.fertigwerden><de> """Ich hätte nie gedacht, dass eine simple Maske mit den Problemen der Haut fertig werden könnte."
<G-vec00301-001-s180><cope.fertigwerden><en> In order to cope with the new situation, this will force the body to start multiplying the cells that make up the penis tissues and to increase both the length and girth of the penis.
<G-vec00301-001-s180><cope.fertigwerden><de> Um mit der neuen Situation fertig zu werden, wird dies den Körper zu zwingen, starten Multiplikation der Zellen, aus denen der Penis Gewebe und sowohl die Länge und Umfang des Penis zu erhöhen.
<G-vec00301-001-s181><cope.fertigwerden><en> In this article we will discuss ways to cope with those feelings.
<G-vec00301-001-s181><cope.fertigwerden><de> In diesem Artikel besprechen wir die Möglichkeiten, mit diesen Gefühlen fertig zu werden.
<G-vec00301-001-s182><cope.fertigwerden><en> The project forms part of the Action Plan for Managua designed by the Nicaraguan Government with a view to both increasing mobility within the capital and enhancing the city’s ability to cope with possible natural disasters.
<G-vec00301-001-s182><cope.fertigwerden><de> Das Projekt fällt unter den Aktionsplan für Managua, den die nicaraguanische Regierung entwickelt hat, um die Mobilität in der Hauptstadt zu verbessern und der Stadt Mittel an die Hand zu geben, um mit möglichen Naturkatastrophen fertigzuwerden.
<G-vec00301-001-s183><cope.fertigwerden><en> Italy and Greece are especially affected by the events in Albania and Portugal takes pains to cope with her African heritage.
<G-vec00301-001-s183><cope.fertigwerden><de> Italien und Griechenland sind besonders betroffen von dem, was in Albanien vorgeht, und Portugal hat Mühe, mit seinem afrikanischen Erbe fertigzuwerden.
<G-vec00301-001-s184><cope.fertigwerden><en> Therefore man can certainly still suffer according to the body, but always only then, when he does not listen to the ideas of the soul, when earth still burdens him now and again and he seeks to cope with it, instead of consulting the soul, i.e. seriously turns away from worldly thoughts and seeks help in trouble from the soul, which then presents the groundlessness of earthly worries to him and just refers him to divine love, which always helps, where help is expected believingly.
<G-vec00301-001-s184><cope.fertigwerden><de> Also kann wohl der Mensch dem Körper nach noch leiden, doch immer nur dann, wenn er den Vorstellungen der Seele kein Gehör schenkt, wenn die Erde noch zuweilen ihn belastet und er mit ihr fertigzuwerden sucht, anstatt die Seele zu Rate zu ziehen, d.h. ernstlich sich abwendet von weltlichen Gedanken und Hilfe in der Not bei der Seele sucht, die ihm dann die Grundlosigkeit irdischer Sorge vorstellt und ihn nur an die göttliche Liebe verweiset, die stets hilft, wo die Hilfe gläubig erwartet wird.
<G-vec00301-001-s185><cope.fertigwerden><en> Throughout the developing world, most health-care systems are designed to cope with episodes of infectious disease.
<G-vec00301-001-s185><cope.fertigwerden><de> In den Entwicklungsländern sind die meisten Gesundheitssysteme inzwischen darauf ausgelegt, mit Episoden von Infektionskrankheiten fertigzuwerden.
<G-vec00301-001-s186><cope.fertigwerden><en> In addition, they have brought in hundreds of medical professionals and Volunteer Ministers to help Haitians cope with their losses and rebuild their lives.
<G-vec00301-001-s186><cope.fertigwerden><de> Außerdem kamen sie mit Hunderten von medizinischen Fachleuten und Ehrenamtlichen Geistlichen, um den Haitianern zu helfen, mit ihren Verlusten fertigzuwerden und ihr Leben wieder aufzubauen.
<G-vec00301-001-s187><cope.fertigwerden><en> """I would like to help people to cope better with all the stress of hectic everyday life and to find true inner peace"", says Vikramjit Singh."
<G-vec00301-001-s187><cope.fertigwerden><de> """Ich möchte Menschen helfen, mit den Anstrengungen des hektischen Alltagslebens besser fertigzuwerden und inneren Frieden zu finden"", so Vikramjit Singh."
<G-vec00301-001-s205><cope.werden><en> The fabric and leather variants exhibit above-average light and colour fastness values to cope with the high levels of solar radiation.
<G-vec00301-001-s205><cope.werden><de> Die Stoff- und Ledervarianten besitzen überdurchschnittliche Licht- und Farbechtheitswerte, um der hohen Sonneneinstrahlung gerecht zu werden.
<G-vec00301-001-s206><cope.werden><en> Important alterations in carbohydrate metabolism arise in the mother during the pregnancy in order to cope with the fetal needs and to prepare for lactation.
<G-vec00301-001-s206><cope.werden><de> Man beachte, dass während der Schwangerschaft wichtige Veränderungen im Kohlenhydrat - Metabolismus auftreten, um den fetalen Bedürfnissen gerecht zu werden und die Laktation vorzubereiten.
<G-vec00301-001-s207><cope.werden><en> In regard to the state farms, it must be said that they still fail to cope with their tasks.
<G-vec00301-001-s207><cope.werden><de> Was die Sowjetwirtschaften betrifft, so muss man sagen, dass sie ihren Aufgaben immer noch nicht gerecht werden.
<G-vec00301-001-s208><cope.werden><en> Suspended ceiling with mirrored panels and cope with the task.
<G-vec00301-001-s208><cope.werden><de> Abgehängte Decke mit gespiegelten Platten und mit der Aufgabe gerecht zu werden.
<G-vec00301-001-s209><cope.werden><en> In order to cope with the limited installation space available in the backhoe loader, DEUTZ's engineers developed a special solution by combining the particularly slim agricultural machinery variant of the TCD 3.6 with components from industrial applications.
<G-vec00301-001-s209><cope.werden><de> Um den kompakten Platzverhältnissen des Baggerladers gerecht zu werden, haben die DEUTZ-Ingenieure eine spezielle Lösung entwickelt, indem sie die besonders schmale Landtechnikvariante des TCD 3.6 mit Komponenten aus Industrieanwendungen kombiniert haben.
<G-vec00301-001-s210><cope.werden><en> In order to better cope with the circumstances of the technical and medical environment, this work is based on a prioritization of vital signs according to the health state of the patient.
<G-vec00301-001-s210><cope.werden><de> Um den Gegebenheiten des technischen und medizinischen Umfeldes besser gerecht zu werden, stutzt sich diese Arbeit auf eine Priorisierung der Vitaldaten entsprechend des Gesundheitszustandes des Patienten.
<G-vec00301-001-s211><cope.werden><en> For this reason, Fuzhou Huacai puts emphasis on high productivity and high-speed printing to cope with the customers' demands.
<G-vec00301-001-s211><cope.werden><de> Daher legt Fuzhou Huacai Wert auf hohe Produktivität und hohe Geschwindigkeiten, um den Anforderungen der Kunden gerecht zu werden.
<G-vec00301-001-s212><cope.werden><en> Good practices and agronomy: to ensure results for the farm; to cope with all soil, crop and forage conditions; to ensure animal welfare, and feed them high quality rations,
<G-vec00301-001-s212><cope.werden><de> Praktische Erfahrung und Agronomie: um ein landwirtschaftliches Ergebnis zu gewährleisten, um allen Boden-, Anbau- und Futterbedingungen gerecht zu werden, um das Wohlergehen der Tiere zu respektieren und dem Vieh eine hochwertige Ernährung zu garantieren.
<G-vec00301-001-s213><cope.werden><en> Greece, which ever since 2010 has been struggling immensely to deal with its own financial crisis, cannot cope with the many arrivals.
<G-vec00301-001-s213><cope.werden><de> Griechenland, das seit 2010 massiv mit der Finanzkrise zu kämpfen hat, kann den vielen Ankömmlingen nicht gerecht werden.
<G-vec00301-001-s214><cope.werden><en> These methods should allow for near real-time updating of relevant parameters in order to cope with the development of the city.
<G-vec00301-001-s214><cope.werden><de> Diese Methoden sollen die Aktualisierung von relevanten Parametern in beinahe Echtzeit ermöglichen, um der Stadtentwicklung gerecht zu werden.
<G-vec00301-001-s215><cope.werden><en> The systems have to cope with a wide range of ambient conditions depending on location.
<G-vec00301-001-s215><cope.werden><de> In Abhängigkeit des Standortes müssen die Systeme den unterschiedlichsten Umweltbedingungen gerecht werden.
<G-vec00301-001-s216><cope.werden><en> In order to cope with the large customer demand the workforce at the CountÂ ́s brewery is presently working every day from 4 a.m. in the morning until 10 p.m. at night and during the record month of June it was even filling round the clock.
<G-vec00301-001-s216><cope.werden><de> "Um der großen Nachfrage der Kunden gerecht zu werden, wird in der Gräflichen Brauerei derzeit täglich von 4 Uhr morgens bis 22 Uhr abends gearbeitet, und im Rekordmonat Juni wurde sogar rund um die Uhr abgefüllt, ""sonst wären wir nicht nachgekommen"", erinnert sich der Braumeister."
<G-vec00301-001-s217><cope.werden><en> If people stand up for the overcoming of the in the course of history emerged juxtaposition or even conflicts, they deserve attention and gratitude. For it is important for them that the internal and external unity of Christendom can be experienced. This union must characterize the Church as People of God, Body of Christ and Temple of the Holy Spirit, so that she is able to cope with her mission.
<G-vec00301-001-s217><cope.werden><de> Wenn Menschen sich für die Überwindung ihres im Laufe der Geschichte aufgebrochenen Neben- oder gar Gegeneinanders einsetzen, verdienen sie Aufmerksamkeit und Dankbarkeit; denn es liegt ihnen daran, dass die innere und äußere Einheit der Christenheit, die ja die Kirche als Gottes Volk und Leib Christi und Tempel des Heiligen Geistes kennzeichnen soll, damit sie ihrem Auftrag gerecht zu werden vermag, erfahrbar ist.
<G-vec00301-001-s218><cope.werden><en> Over the next three years schools in Croydon must provide an additional 2100 secondary places and 5182 places in primary schools to cope with expected increased demand.
<G-vec00301-001-s218><cope.werden><de> In den kommenden drei Jahren müssen in Croydon 2100zusätzliche Plätze an weiterführenden Schulen und 5182Grundschulplätze geschaffen werden, um dem erwarteten Anstieg der Nachfrage gerecht zu werden.
<G-vec00301-001-s219><cope.werden><en> To cope with the great diversity of empirical educational research, the services of other relevant research data centers and research institutes will be integrated in the network's existing offer.
<G-vec00301-001-s219><cope.werden><de> Um der Vielfalt der empirischen Bildungsforschung nachhaltig gerecht werden zu können, werden die Services weiterer relevanter Forschungsdatenzentren(FDZ) und Forschungsinstitutionen mit dem bestehenden Angebot verknüpft.
<G-vec00301-001-s220><cope.werden><en> In addition, the company is building other production sites in Slovenia to cope with the growing demand for drive technology.
<G-vec00301-001-s220><cope.werden><de> Darüber hinaus errichtet der Konzern weitere Produktionsstandorte in Slowenien, um der wachsenden Nachfrage nach Antriebstechnik gerecht zu werden.
<G-vec00301-001-s221><cope.werden><en> To cope with the always changing customer and market requirements, Juki now sells complete line solutions since the beginning of 2013
<G-vec00301-001-s221><cope.werden><de> Um den immer wechselnden Anforderungen der Kunden und auch des Marktes gerecht zu werden, verkauft Juki seit Anfang 2013 vollständige Linienlösungen.
<G-vec00301-001-s222><cope.werden><en> Dissolve as soon as possible and let each country cope with its own problems (interest adjustment, devaluation), and let independent politicians find appropriate solutions in informal frameworks - without aiming at world government, which would only multiply EU problems
<G-vec00301-001-s222><cope.werden><de> Sich möglichst bald auflösen, jedes Land seinen eigenen spezifischen Problemen (Zinsanpassung, Abwertung) gerecht werden – und unabhängige Politiker geeignete Lösungen im informellen Rahmen finden lassen - ohne auf die Weltregierung zu zielen, die nur die EU-Probleme um ein Vielfaches vermehren wird.
<G-vec00301-001-s223><cope.werden><en> To cope with the demanding environment of the various industries, Sefar has developed a Smart Fabric range in order to maximize the customer`s value.
<G-vec00301-001-s223><cope.werden><de> Für einen optimalen Kundennutzen und um dem anspruchsvollen Umfeld der verschiedenen Anwendungsbereichen gerecht zu werden, hat Sefar eine Reihe von Smart Fabrics entwickelt.
<G-vec00301-001-s224><cope.sein><en> The cables previously used, which hung down from the crane, led to many breakdowns in the past and were not able to cope with metalworking conditions.
<G-vec00301-001-s224><cope.sein><de> Die vorher eingesetzten, am Kran hängenden Leitungen, führten in der Vergangenheit zu vielen Ausfällen und waren den Ansprüchen in der Metallverarbeitung nicht gewachsen.
<G-vec00301-001-s225><cope.sein><en> But as long as human substances were still clinging to My body I also had to endure human suffering and torments which, last but not least, also included the inner distress of not being able to cope with My task.... for I knew what it would mean were I to fail in the battle against the one who was, is and will remain everyone’s enemy for eternities to come.
<G-vec00301-001-s225><cope.sein><de> Solange aber Meinem Körper noch Menschliches anhaftete, musste Ich auch menschliche Leiden und Qualen erdulden, wozu nicht zuletzt die inneren Bedrängnisse gehörten, Meiner Aufgabe nicht gewachsen zu sein.... denn Ich wußte, was es hieß, wenn Ich versagte im Kampf gegen den, der euer aller Feind war und ist und bleiben wird noch Ewigkeiten hindurch.
<G-vec00301-001-s226><cope.sein><en> And, if in the underdeveloped countries and wild tribes this mechanism still serves to preserve life and health, in developed countries where food for the majority of the population is abundant and easily accessible, brain programming for consumption of products such as sugars and fats has turned into its opposite and It causes serious harm to the health of people who are unable to cope with the instincts laid down by nature.
<G-vec00301-001-s226><cope.sein><de> Wenn dieser Mechanismus in den unterentwickelten Ländern und wilden Stämmen immer noch der Erhaltung von Leben und Gesundheit dient, in Industrieländern, in denen die Bevölkerungsmehrheit reichlich vorhanden ist und leicht verfügbar ist, hat das Gehirn, das für den Verzehr von Nahrungsmitteln wie Zucker und Fetten programmiert ist, sein Gegenteil und das Gegenteil erreicht Es verursacht schwere gesundheitliche Schäden für Menschen, die den von der Natur festgelegten Instinkten nicht gewachsen sind.
<G-vec00301-001-s227><cope.sein><en> Those who remain in the old field will no longer be able to cope with the challenges of the new time.
<G-vec00301-001-s227><cope.sein><de> Wer im alten Feld bleibt, wird den Anforderungen der neuen Zeit nicht mehr gewachsen sein.
<G-vec00301-001-s228><cope.sein><en> It controls all airport processes centrally and so efficiently that the airport operators are able to cope with the growing requirements demanded in international aviation management.
<G-vec00301-001-s228><cope.sein><de> Es steuert alle Flughafenprozesse zentral und so effizient, dass die Flughafenbetreiber den zunehmenden Anforderungen an internationales Aviation-Management gewachsen sind.
<G-vec00301-001-s229><cope.sein><en> Innovative technologies are needed in order to cope with future requirements in air traffic.
<G-vec00301-001-s229><cope.sein><de> Um den zukünftigen Anforderungen im Luftverkehr gewachsen zu sein, bedarf es innovativer Technologien.
<G-vec00301-001-s230><cope.sein><en> It should help to strengthen the we feeling, because only together we will be able to cope with the challenges of a constantly changing world.
<G-vec00301-001-s230><cope.sein><de> Er soll dazu beitragen, das Wir -Gefühl zu stärken, denn nur gemeinsam werden wir den Herausforderungen einer sich ständig verändernden Welt gewachsen sein.
<G-vec00301-001-s231><cope.sein><en> At the same time, the integration mechanism between the managers needs to stay up to speed to cope with the centrifugal forces that will pull each one of them to focus excessively in their individual tasks—perhaps subordinating the goal of the company.
<G-vec00301-001-s231><cope.sein><de> Gleichzeitig muss der Integrationsmechanismus zwischen den Managern den Anforderungen gewachsen sein, und ein Gegengewicht darstellen zu den Zentrifugalkräften die jeden von ihnen in Richtung ihrer individuellen Aufgaben ziehen - und sie auf das Unternehmensziel ausrichten.
<G-vec00301-001-s232><cope.sein><en> All our packs are rigorously tested in order to cope with the usual activities required of flying and travel.
<G-vec00301-001-s232><cope.sein><de> Alle unsere Rucksäcke werden umfassenden Tests unterzogen, um der beim Fliegen und Reisen üblichen Beanspruchung gewachsen zu sein.
<G-vec00301-001-s233><cope.sein><en> To cope with the ever-increasing volumes of freight traffic, the world's largest sea lock is currently being built in Antwerp.
<G-vec00301-001-s233><cope.sein><de> Um dem stetig wachsenden Güterverkehr auch zukünftig gewachsen zu sein, baut Antwerpen derzeit die größte Seeschleuse der Welt.
<G-vec00301-001-s234><cope.sein><en> At the time the world economic crisis struck in the late twenties, the unemployment insurance had not yet been able to build up any financial reserves and was not able to cope with the enormous financial burden placed on it by spiralling mass unemployment.
<G-vec00301-001-s234><cope.sein><de> Bis zum Ausbruch der Weltwirtschaftskrise konnte die Arbeitslosenversicherung keine finanziellen Reserven bilden und war der finanziellen Belastung nicht gewachsen, die ihr durch die anschwellende Massenarbeitslosigkeit auferlegt wurde.
<G-vec00301-001-s235><cope.sein><en> people in search of the right tools enabling them to cope with a leading position in the non-profit sector
<G-vec00301-001-s235><cope.sein><de> Menschen, die nach den geeigneten Werkzeugen streben, um einer leitenden Position im gemeinnützigen Bereich gewachsen zu sein.
<G-vec00301-001-s236><cope.sein><en> Due to their highly corrosive nature, inline flow measurement technologies often can not cope with the harsh conditions.
<G-vec00301-001-s236><cope.sein><de> Aufgrund der stark korrosiven Stoffeigenschaften, sind inline Durchflussmesstechnologien diesen Bedingungen oftmals nicht gewachsen.
<G-vec00301-001-s237><cope.sein><en> "Dirk Roth, the managing director of AGRO, says this about his experience with the Weidemann machines: ""They are very sturdy machines with good engines that are able to cope with our high requirements."
<G-vec00301-001-s237><cope.sein><de> "Dirk Roth, der Geschäftsführer der AGRO sagt zu seinen Erfahrungen mit den Weidemann Maschinen: ""Es sind sehr robuste Maschinen mit guten Motoren, die unseren hohen Anforderungen gewachsen sind."
<G-vec00301-001-s238><cope.sein><en> The coastal defense was unable to cope with this heavy storm.
<G-vec00301-001-s238><cope.sein><de> Die Küste war diesem schweren Sturm nicht gewachsen.
<G-vec00301-001-s239><cope.sein><en> But when the waiter came and Jean had to translate the wishes of his wife, he showed not te be able to cope with this.
<G-vec00301-001-s239><cope.sein><de> Aber als der Kellner kam und er die Wünsche seiner Frau übersetzen sollte, zeigte er sich dieser Aufgabe nicht gewachsen.
<G-vec00301-001-s240><cope.sein><en> "Already become ""traditional"" electromagneticRadars that fix the speed of movement, as well as installed on some routes video surveillance cameras do not cope with their duties."
<G-vec00301-001-s240><cope.sein><de> "Bereits ""traditionell"" elektromagnetisch gewordenRadar, die die Geschwindigkeit des Verkehrs zu beheben, sowie auf einigen Routen Videoüberwachungskameras installiert sind nicht ihren Aufgaben gewachsen."
<G-vec00301-001-s241><cope.sein><en> An alarming number of young singers are not able to cope with these demands, particularly as the support through their music school ends with the graduation.
<G-vec00301-001-s241><cope.sein><de> Diesen Anforderungen ist eine erschreckend große Zahl von jungen Sängern nicht gewachsen, unter anderem, weil mit dem Studium auch die Betreuung durch die Hochschule endet.
<G-vec00301-001-s242><cope.sein><en> Our dedicated crew can cope with any kind of logistic challenges.
<G-vec00301-001-s242><cope.sein><de> Unsere engagierte Crew ist allen logistischen Herausforderungen gewachsen.
<G-vec00301-001-s256><cope.klarkommen><en> I have observed this before, that’s why I think it’s so important that Jonas works in a group now, because he has to learn to cope with situations like this.
<G-vec00301-001-s256><cope.klarkommen><de> Dies habe ich hier und da schon mal beobachtet, deshalb finde ich es auch jetzt so wichtig, dass Jonas in einer Gruppe arbeitet, denn genau mit solchen Situationen muss er auch lernen klar zu kommen.
<G-vec00301-001-s257><cope.klarkommen><en> The open layout of the Aseptic Unit and the carefully planned layout of the Command Centre and interconnecting hatches between the two means the facility will be able to cope with the expected growth in demand over the next decade.
<G-vec00301-001-s257><cope.klarkommen><de> Der offene Grundriss der Aseptischen Einheit und der sorgfältig geplante Grundriss des Steuerzentrums sowie die verbindenden Materialschleusen ermöglichen, dass die Einrichtung mit dem erwarteten Nachfragewachstum in der folgenden Dekade klar kommen wird.
<G-vec00301-001-s258><cope.klarkommen><en> Illness, natural catastrophes, war, your children, who can't cope with the situation, or just the realisation that now and here isn't the right time to execute such a project.
<G-vec00301-001-s258><cope.klarkommen><de> Krankheit, Naturkatastrophen, Kriege, Kinder die mit der Situation gar nicht klar kommen wollen oder die Erkenntnis das man hier und jetzt so ein Projekt nicht Leid los durchführen kann, können Gründe für einen Reiseabbruch darstellen.
<G-vec00301-001-s259><cope.klarkommen><en> It was when I went to the cinema and I was worried whether I would cope with the loudness and with Dolby Surround.
<G-vec00301-001-s259><cope.klarkommen><de> Ich ging ins Kino und war besorgt, ob ich mit der Lautstärke und mit Dolby Surround klar kommen würde.
<G-vec00301-001-s260><cope.klarkommen><en> How William and Michael have coped with, what they had to do to cope with the loss, shocked one or the other maybe, but so think Racer.
<G-vec00301-001-s260><cope.klarkommen><de> Wie William und Michael das verkraftet haben, was sie tun mussten um mit dem Verlust klar zu kommen, schockiert den ein oder anderen vielleicht, Aber so denken Racer.
<G-vec00301-001-s261><cope.klarkommen><en> But her sewing machine also has to cope with leather and vinyl, and the B 770 QE does all this with precise, uniform stitch formation.
<G-vec00301-001-s261><cope.klarkommen><de> Aber auch mit Leder und Vinyl muss die Nähmaschine klar kommen, und die B 770 QE erledigt all dies mit einem klaren, gleichmässigen Stichbild.
<G-vec00301-001-s262><cope.klarkommen><en> Permanent stations on the Antarctic ice sheet have developed a variety of strategies to cope with snow accumulation, especially as snow drift tends to bury any object.
<G-vec00301-001-s262><cope.klarkommen><de> Für feste Stationen auf dem antarktischen Inlandeis wurden verschiedene Strategien entwickelt, um mit dem Schnee und den Schneewehungen klar zu kommen; das Einfachste ist, Gebäudewände zu verstärken und den Schnee anhäufen zu lassen, so wie die deutsche Georg von Neumayer Station auf dem Ekstroem Eisschelf.
<G-vec00301-001-s263><cope.klarkommen><en> Though Thailand should be the better team in terms of play, it remains to be seen how the Thais can cope with the robust game manner of Singapore.
<G-vec00301-001-s263><cope.klarkommen><de> Zwar sollte Thailand in der Lage sein, das Finale spielerisch zu dominieren, es bleibt aber die Frage offen, wie Thailand mit der robusten Spielweise des Gegners klarkommen wird.
<G-vec00301-001-s264><cope.klarkommen><en> You now have fine antennas for subliminal negatives (Venus in tension with Pluto), perhaps you even have a real enemy image that you cannot cope with.
<G-vec00301-001-s264><cope.klarkommen><de> Sie haben jetzt feine Antennen für unterschwellig Negatives (Venus in Spannung zu Pluto), vielleicht haben Sie sogar ein richtiges Feindbild, mit dem Sie nicht klarkommen.
<G-vec00301-001-s265><cope.klarkommen><en> We keep two original pig breeds on our farm, as they cope very well with the natural weather conditions.
<G-vec00301-001-s265><cope.klarkommen><de> Ritzinger Hof Wir halten auf unserem Hof zwei ursprüngliche Schweinerassen, da diese mit den natürlichen Wetterbedingungen sehr gut klarkommen.
<G-vec00301-001-s266><cope.klarkommen><en> Software design based on loose coupling makes it possible to build flexible software systems that cope better with changes, since dependencies between the participants are minimized.
<G-vec00301-001-s266><cope.klarkommen><de> Softwaredesign auf Basis von loser Kopplung ermöglicht es, flexible Softwaresysteme aufzubauen, die mit Veränderungen besser klarkommen, da die Abhängigkeiten zwischen den Teilnehmern minimiert werden.
<G-vec00301-001-s267><cope.klarkommen><en> After all, you have to cope with your impressions and have to find the right way to apply the impulses in the right moment and form.
<G-vec00301-001-s267><cope.klarkommen><de> Schließlich mußt Du mit dem Wahrgenommenen erstmal klarkommen und den richtigen Weg finden, die Impulse anzuwenden oder im richtigen Moment oder in der richtigen Form auszusprechen.
<G-vec00301-001-s268><cope.klarkommen><en> So whoever wanted to be happy here, had to cope with the house spectre of Sir Francis.
<G-vec00301-001-s268><cope.klarkommen><de> Wer immer also hier glücklich werden wollte, musste mit dem Hausgespenst Sir Francis klarkommen.
<G-vec00301-001-s269><cope.zurechtkommen><en> Blades easily cope with soft, braided lines - that makes them irreplaceable for carp and spinning rigs production.
<G-vec00301-001-s269><cope.zurechtkommen><de> Klingen kommen mit weichen, geflochtenen Schnüren problemlos zurecht - das macht sie für die Herstellung von Karpfen und Spinnruten unersetzlich.
<G-vec00301-001-s270><cope.zurechtkommen><en> The joint ventures well cope with this task...
<G-vec00301-001-s270><cope.zurechtkommen><de> Mit dieser Aufgabe kommen sp gut zurecht...
<G-vec00301-001-s271><cope.zurechtkommen><en> Solvents cost quite much, however they very effectively cope with removal of old paint.
<G-vec00301-001-s271><cope.zurechtkommen><de> Die Lösungsmittel stehen ziemlich teuer, jedoch kommen sie mit der Entfernung der alten Farbe sehr wirksam zurecht.
<G-vec00301-001-s272><cope.zurechtkommen><en> "Here only we ""cope"" with them differently: someone well ""reads out"" and understands emotions of other people, and someone even in own plainly cannot understand."
<G-vec00301-001-s272><cope.zurechtkommen><de> "Nur kommen""wir mit ihnen verschieden""zurecht: jemand lest""gut""aus und versteht die Emotionen anderer Menschen, und jemand kann sogar in eigen vernünftig, sich nicht zurechtfinden."
<G-vec00301-001-s273><cope.zurechtkommen><en> The currently existing tracking systems cannot cope with the difficult conditions on construction sites and must be adapted.
<G-vec00301-001-s273><cope.zurechtkommen><de> Die derzeit vorhandenen Trackingsysteme kommen mit den schwierigen Verhältnissen auf Baustellen nicht zurecht und müssen daher entsprechend angepasst werden.
<G-vec00301-001-s274><cope.zurechtkommen><en> Even foreign students who do their studies in the English-language programs cope better when they learn German.
<G-vec00301-001-s274><cope.zurechtkommen><de> Doch selbst ausländische Studierende, die in englischsprachigen Programmen eingeschrieben sind, kommen besser zurecht, wenn sie Deutsch lernen.
<G-vec00301-001-s275><cope.zurechtkommen><en> Nowadays the inhabitants of the Chekists Village enjoy living in the heart of the city, but have to cope in their own ways with the actual lack of kitchens.
<G-vec00301-001-s275><cope.zurechtkommen><de> Die zeitgenössischen Bewohner des Tschekisten-Städtchens genießen das Leben im Zentrum der Stadt, und jeder kommt auf seine Weise mit dem Mangel an einer Küche zurecht.
<G-vec00301-001-s276><cope.zurechtkommen><en> Despite the high degree of stress suffered by individuals who have recently been bereaved, the majority of individuals cope with their loss and only a minority will develop a mental disorder such as a major depressive episode.
<G-vec00301-001-s276><cope.zurechtkommen><de> Trotz des hohen Grades des Stresses, den die Personen erlitten haben, die vor kurzem jemanden durch den Tod verloren, kommt die Mehrheit der Betroffenen mit dem Verlust zurecht, und nur eine Minderheit entwickelt eine geistige Störung wie eine tiefere depressive Episode.
<G-vec00301-001-s277><cope.zurechtkommen><en> With him cope anyone who wants to carry out the cultivation of oyster mushrooms.
<G-vec00301-001-s277><cope.zurechtkommen><de> Mit ihm kommt jeder zurecht, der den Anbau von Austernpilzen betreiben will.
<G-vec00301-001-s278><cope.zurechtkommen><en> All of them perfectly smell and perfectly cope with a problem of clarification and refreshing of hair.
<G-vec00301-001-s278><cope.zurechtkommen><de> Aller diese riechen sehr gut und ausgezeichnet kommt mit der Aufgabe der Säuberung und osweschenija das Haar zurecht.
<G-vec00301-001-s279><cope.zurechtkommen><en> And not everyone can cope with this form of learning - some can learn better if the material is taught on fixed dates through the lectures of the teachers.
<G-vec00301-001-s279><cope.zurechtkommen><de> Und nicht jeder kommt mit dieser Lernform zurecht – mancher kann besser lernen, wenn der Stoff zu festen Terminen durch den Vortrag der Lehrenden vermittelt wird.
<G-vec00301-001-s280><cope.zurechtkommen><en> is a well-balanced dynamics which reproduces small as well as large loudspeaker jumps out of nowhere - provided the player can cope with its high impedance.
<G-vec00301-001-s280><cope.zurechtkommen><de> ist ein ausgemachter Dynamiker der kleine wie große Lautstärkesprünge wie aus dem Nichts nachvollzieht – vorausgesetzt, der Zuspieler kommt mit seiner hohen Impedanz zurecht.
<G-vec00301-001-s300><cope.meistern><en> My main focus is on counseling clients in astrology and psychological counseling and all personality issues, relationship and partnership issues and concerns, life counseling and coaching, psychology, crisis+conflict management and prevention, interpersonal communication, personal coaching and astro-coaching for personality development and to cope with life.
<G-vec00301-001-s300><cope.meistern><de> Schwerpunktmäßig berate ich Klienten in Astrologie und der psychologischen Beratung, in Persönlichkeitsfragen und -themen, Beziehungs- und Partnerschaftbesthemen, Lebensthemen, der Psychologie, des Krisen-/Konfliktmanagements und Prävention, der zwischenmenschlichen Kommunikation, des Personal + Life Coachings und Astro-Coachings zur Persönlichkeitsentwicklung und um das Leben zu meistern.
<G-vec00301-001-s301><cope.meistern><en> During the forthcoming time of adversity you will all need strength from Me.... for you will be not be able to cope with your circumstances in an earthly way; only with My help will you succeed.
<G-vec00301-001-s301><cope.meistern><de> In der kommenden Notzeit brauchet ihr alle Kraft aus Mir.... denn irdisch werdet ihr nicht eure Lebenslage meistern können; nur mit Meiner Hilfe wird es euch gelingen.
<G-vec00301-001-s302><cope.meistern><en> Business enterprises that recognize these challenges early and successfully cope with them will develop new business models to ensure their survival in the markets of the future.
<G-vec00301-001-s302><cope.meistern><de> Unternehmen, die diese Herausforderungen frühzeitig erkennen und meistern, werden sich mit neuen Geschäftsmodellen in den Märkten der Zukunft behaupten.
<G-vec00301-001-s303><cope.meistern><en> It initially discusses your individual way of tackling the challenges that you face and how you can best cope with your existence.
<G-vec00301-001-s303><cope.meistern><de> Es geht also zunächst um Ihre individuelle Art, wie Sie die Herausforderungen, vor die Sie gestellt sind, anpacken und auf welche Weise Sie Ihr Dasein am besten meistern.
<G-vec00301-001-s304><cope.meistern><en> A public agency for low-cost housing is set up to try and cope with the acute housing shortage.
<G-vec00301-001-s304><cope.meistern><de> Um die Wohnungskrise zu meistern, wird ein öffentliches Amt fürgünstige Wohnungen eingerichtet.
<G-vec00301-001-s305><cope.meistern><en> The documentary series DICING WITH DEATH is about people who cope with life under tough conditions.
<G-vec00301-001-s305><cope.meistern><de> DICING WITH DEATH ist eine Doku-Serie über Menschen, die unter harten Bedingungen das Leben meistern.
<G-vec00301-001-s306><cope.meistern><en> Tutima Glashütte's new M2 Seven Seas - the titanium watch built to cope with the toughest challenges.
<G-vec00301-001-s306><cope.meistern><de> Die M2 Seven Seas von Tutima Glashütte – das neue Modell in Titan, gebaut um härteste Herausforderungen zu meistern.
<G-vec00301-001-s307><cope.meistern><en> Prostheses help people cope with everyday life and participate in society after having lost their limbs.
<G-vec00301-001-s307><cope.meistern><de> Prothesen helfen Menschen bei Verlust von Extremitäten wieder den Alltag zu meistern und an der Gesellschaft teilzuhaben.
<G-vec00301-001-s308><cope.meistern><en> These consequences of the provision challenged are acceptable only if the persons involved are effectively helped to cope with their situation.
<G-vec00301-001-s308><cope.meistern><de> Diese Folgen der angegriffenen Regelung sind nur zumutbar, wenn den Betroffenen wirksam geholfen wird, ihre Lage zu meistern.
<G-vec00301-001-s309><cope.meistern><en> Thus, it is an intriguing and worthwhile academic challenge to use structural engineering to cope with non-technical problems and remove obstacles.
<G-vec00301-001-s309><cope.meistern><de> Es ist somit eine reizvolle und lohnende wissenschaftliche Herausforderung, mit einer bautechnischen Idee auch nicht-technische Probleme zu meistern und Hindernisse abzubauen.
<G-vec00301-001-s310><cope.meistern><en> It is meant to prepare our community to cope with the accelerating changes that are occurring in the world about us and to place the community in a position both to withstand the weight of the accompanying tests and challenges and to make more visible a pattern of functioning to which the world can turn for aid and example in the wake of a tumultuous transition.
<G-vec00301-001-s310><cope.meistern><de> Er soll unsere Gemeinde darauf vorbereiten, die sich beschleunigenden Veränderungen zu meistern, die sich in der Welt um uns vollziehen, und die Gemeinde in die Lage versetzen, sowohl der Wucht der damit verbundenen Prüfungen und Herausforderungen zu widerstehen als auch ein funktionierendes Modell deutli- cher sichtbar zu machen, dem sich die Welt um Hilfe suchend und als Beispiel in den Nachwehen eines tu- multartigen Übergangs zuwenden kann.
<G-vec00301-001-s311><cope.meistern><en> In order to learn a piece of music off by heart, one has to cope with certain obstacles in the lessons: “You sit down at the piano and play a Bach fugue.
<G-vec00301-001-s311><cope.meistern><de> "Um ein Stück auswendig zu lernen, hat man im Unterricht gewisse Hürden zu meistern: ""Man setzt sich ans Klavier, spielt eine Bach-Fuge."
<G-vec00301-001-s312><cope.meistern><en> In the course of our lives we are required again and again to cope with transitions to new chapters in our lives. Consequently we face new and changing challenges.
<G-vec00301-001-s312><cope.meistern><de> Im Laufe unseres Lebens sind wir immer wieder gefordert, Übergange zu neuen Lebensabschnitten zu meistern und in der Folge veränderten Herausforderungen zu begegnen.
<G-vec00301-001-s313><cope.meistern><en> The balance between tradition and innovation assigns the company time and again new challenges which are essential to cope with.
<G-vec00301-001-s313><cope.meistern><de> Logistikzentrum Die Balance zwischen Tradition und Innovation stellt das Unternehmen immer wieder vor neue Herausforderungen, die es zu meistern gilt.
<G-vec00301-001-s314><cope.meistern><en> """The RiskMonitor survey shows that institutional investors in Europe trust the framework they are operating in and are generally confident of their ability to cope with the challenges in this space"", says Elizabeth Corley, noting that many regulations have a considerable impact on investment decisions and regulators are becoming more inclined to address systemic risks which could impact capital markets."
<G-vec00301-001-s314><cope.meistern><de> """Die ""RiskMonitor""-Umfrage zeigt, dass institutionelle Anleger in Europa Vertrauen zu den rechtlichen und strukturellen Rahmenbedingungen haben, in dem sie sich bewegen, und dass sie insgesamt zuversichtlich sind, die Herausforderungen in diesem Feld zu meistern"", sagt Elizabeth Corley, nicht ohne zu erwähnen, dass eine Vielzahl an Regulierungen einen erheblichen Einfluss auf Anlageentscheidungen und Regulierungsbehörden verstärkt Systemrisiken für die Kapitalmärkte im Blick hätten."
<G-vec00301-001-s315><cope.meistern><en> In 2012, convinced that the precious metal is the best safety net to cope with crisis situations and ensure the monetary independence of Switzerland, some representatives of the conservative right launched the initiative “Save Switzerland’s Gold” which calls for a topping up of national reserves of the precious metal. So far, the initiative has won only limited support around the country.
<G-vec00301-001-s315><cope.meistern><de> "In der festen Überzeugung, dass dieses Edelmetall die beste Wertanlage darstellt, um Krisensituationen zu meistern und die Währungsunabhängigkeit der Schweiz zu sichern, lancierten einige rechts-konservative Politiker 2012 die Volksinitiative ""Rettet unser Schweizer Gold"", die verlangt, die Goldreserven der Nationalbank wieder aufzustocken."
<G-vec00301-001-s316><cope.meistern><en> They think they can cope with their situation, both mentally and financially.
<G-vec00301-001-s316><cope.meistern><de> Sie glauben, dass sie ihre Situation sowohl physisch als auch finanziell meistern können.
<G-vec00301-001-s317><cope.meistern><en> But we confront these challenges with stable and cooperative relations to our clients and staff, a customized and attractive service offering and the strong bond with the ESG Group, in order to cope with the crisis without substantial prejudice and emerge from it strengthened“, said Ferdinand Stocker, Chief Executive Officer of ServiceXpert.
<G-vec00301-001-s317><cope.meistern><de> Doch mit stabilen und partnerschaftlichen Beziehungen zu unseren Kunden und Mitarbeitern, einem kundenspezifischen, attraktiven Leistungsangebot und dem engen Verbund mit der ESG-Gruppe stellen wir uns diesen Herausforderungen, um die Krise substanziell unbeschadet zu meistern und gestärkt aus ihr hervorzugehen“, so Ferdinand Stocker, Geschäftsführer der ServiceXpert.
<G-vec00301-001-s318><cope.meistern><en> It is the first chair stair lift which has been designed to cope with the most varied weather conditions; sunshine, rain or snow.
<G-vec00301-001-s318><cope.meistern><de> Er ist der erste Stuhltreppenlift, der konstruiert wurde zum Meistern der verschiedensten Wetterlagen; Sonnenschein, Regen oder Schnee.
<G-vec00301-001-s324><cope.zurechtkommen><en> Storage of cheese Often we do not reflect from rules of storage of products — simply we push them in the refrigerator, thinking that he will cope with everything.
<G-vec00301-001-s324><cope.zurechtkommen><de> Die Aufbewahrung des Käses Oft denken wir von die Regeln der Aufbewahrung der Lebensmittel nicht nach — einfach stopfen wir sie in den Kühlschrank hinein, denkend, dass er selbst mit allem zurechtkommen wird.
<G-vec00301-001-s325><cope.zurechtkommen><en> Women speak about some physical support with which with great success could cope, and men rejoice that now they have a personal slave who will clean, erase and prepare days.
<G-vec00301-001-s325><cope.zurechtkommen><de> Die Frauen sagen über irgendwelche physische Unterstützung, mit der mit dem großen Erfolg selbst zurechtkommen könnten, und die Männer freuen sich, dass jetzt sie eine persönliche Sklavin haben, die von den Tagen entfernen wird, zu waschen und vorzubereiten.
<G-vec00301-001-s326><cope.zurechtkommen><en> Often we do not reflect from rules of storage of products — simply we push them in the refrigerator, thinking that he will cope with everything.
<G-vec00301-001-s326><cope.zurechtkommen><de> Oft denken wir von die Regeln der Aufbewahrung der Lebensmittel nicht nach — einfach stopfen wir sie in den Kühlschrank hinein, denkend, dass er selbst mit allem zurechtkommen wird.
<G-vec00301-001-s327><cope.zurechtkommen><en> During this period it is better not to disturb a female — she perfectly will cope with everything.
<G-vec00301-001-s327><cope.zurechtkommen><de> In dieser Periode ist es besser nicht, das Weibchen zu beunruhigen — sie ist mit allem selbst schön wird zurechtkommen.
<G-vec00301-001-s328><cope.zurechtkommen><en> Of course, it is better to entrust wedding manicure to professionals but if this option for any reasons does not suit you, you can quite cope with this task and at home.
<G-vec00301-001-s328><cope.zurechtkommen><de> Natürlich, die Hochzeitsmaniküre ist es besser, den Spezialisten, aber anzuvertrauen wenn diese Variante aus irgendwelchen Gründen Ihnen nicht herankommt, Sie können mit dieser Aufgabe und selbst zu Hause vollkommen zurechtkommen.
<G-vec00301-001-s336><cope.standhalten><en> 10 But they were unable to cope with the wisdom and the Spirit with which he was speaking.
<G-vec00301-001-s336><cope.standhalten><de> Act 6:10 Aber sie vermochten der Weisheit und dem Geist nicht standzuhalten, mit dem er sprach.
<G-vec00301-001-s337><cope.standhalten><en> The existence of a functioning market economy as well as the capacity to cope with competitive pressure and market forces within the Union.
<G-vec00301-001-s337><cope.standhalten><de> Funktionsfähige Marktwirtschaft sowie die Fähigkeit, dem Wettbewerbsdruck und den Marktkräften innerhalb der Union standzuhalten.
<G-vec00301-001-s338><cope.standhalten><en> It should be able to cope with competitive pressure and market forces within the Union in the medium term, provided that it accelerates the implementation of its comprehensive structural reform programme.
<G-vec00301-001-s338><cope.standhalten><de> Das Land dürfte mittelfristig in der Lage sein, dem Wettbewerbsdruck und den Marktkräften in der Union standzuhalten, sofern es die Umsetzung seines umfassenden Strukturreformprogramms beschleunigt.
<G-vec00301-001-s339><cope.standhalten><en> The country should be able to cope with competitive pressures and market forces within the Union in the medium term, provided that it vigorously implements its reform programme in order to reduce significant structural weaknesses.
<G-vec00301-001-s339><cope.standhalten><de> Das Land dürfte mittelfristig in der Lage sein, dem Wettbewerbsdruck und den Marktkräften in der Union standzuhalten, vorausgesetzt, es führt sein Reformprogramm konsequent durch und beseitigt die noch bestehenden massiven Mängel.
<G-vec00301-001-s340><cope.standhalten><en> These require the prospective members (i) to have stable institutions guaranteeing democracy, the rule of law, human rights and the respect for and protection of minorities, and (ii) to have a functioning market economy as well as the capacity to cope with competitive pressure, in order to be able to take on the obligations of membership, including the aims of political, economic and monetary union.
<G-vec00301-001-s340><cope.standhalten><de> Diese fordern von zukünftigen Mitgliedern (a) institutionelle Stabilität als Garantie für demokratische und rechtsstaatliche Ordnung, für die Wahrung der Menschenrechte sowie die Achtung und den Schutz von Minderheiten und (b) eine funktionsfähige Marktwirtschaft sowie die Fähigkeit, dem Wettbewerbsdruck standzuhalten, um in der Lage zu sein, die aus einer Mitgliedschaft erwachsenden Verpflichtungen zu übernehmen und sich die Ziele der politischen Union sowie der Wirtschafts- und Währungsunion zu eigen zu machen.
<G-vec00301-001-s360><cope.können><en> For example, you can cope with your fears and learn to keep emotions under control with the help of hypnosis.
<G-vec00301-001-s360><cope.können><de> Zum Beispiel können Sie mit Ihren Ängsten umgehen und lernen, die Emotionen mit Hilfe von Hypnose unter Kontrolle zu halten.
<G-vec00301-001-s361><cope.können><en> There is also the added benefit of enriching your life in some way, which can actually help you cope with stress even when you're not engaged in your hobby.
<G-vec00301-001-s361><cope.können><de> Es gibt auch den zusätzlichen Vorteil, bereichern Ihr Leben in irgendeiner Weise, die wirklich helfen, können Sie mit Stress umgehen auch wenn Sie nicht in Ihr Hobby beschäftigt.
<G-vec00301-001-s362><cope.können><en> Many doctors recommend a great golf as a sport when it is so gentle on the body and that it is a sport you can customize to suit their abilities and what you can cope with.
<G-vec00301-001-s362><cope.können><de> Viele Ärzte empfehlen beim Golf als Sport, wie es so sanft auf den Körper ist und es ist eine Sportart, die Sie an die eigenen Fähigkeiten anpassen und was man umgehen kann.
<G-vec00301-001-s363><cope.können><en> We must all remember that while HIV/AIDS affects both rich and poor, the poor are much more vulnerable to infection, and much less able to cope with the disease once infected.
<G-vec00301-001-s363><cope.können><de> Wir dürfen nie vergessen, dass Aids zwar Reiche wie Arme gefährdet, aber dass die Armen für eine Infektion deutlich anfälliger sind und mit der Krankheit auch wesentlich schlechter umgehen können.
<G-vec00301-001-s364><cope.können><en> Then as now, these messengers appear all around us, not merely to incite us to discover how to cope with life's difficulties and dangers, but to inspire us to transcend them once and for all.
<G-vec00301-001-s364><cope.können><de> Wenn nun diese Boten rund um uns erscheinen, laden sie nicht nur dazu ein zu erforschen, wie wir mit den Schwierigkeiten und Gefahren umgehen sollen, sondern inspirieren uns auch dazu diese ein für alle mal zu durchdringen.
<G-vec00301-001-s365><cope.können><en> Their relation to food makes them unhappy and they are not being able to cope with food in a proper way.
<G-vec00301-001-s365><cope.können><de> Ihre Beziehung zum Essen macht sie unglücklich und sie können mit Essen nicht mehr angemessen umgehen.
<G-vec00301-001-s366><cope.können><en> You will certainly have the ability to cope up with the circumstance with a fresh as well as increased mind.
<G-vec00301-001-s366><cope.können><de> Sie werden in der Lage sein, mit der Situation umgehen sich mit einem frischen sowie verbessertem Geist.
<G-vec00301-001-s367><cope.können><en> It depends how well a species can cope with fluctuating environmental conditions such as changing water temperatures and lower pH values.
<G-vec00301-001-s367><cope.können><de> Es kommt darauf an, wie gut eine Art mit schwankenden Umweltbedingungen, wie wechselnden Wassertemperaturen und niedrigeren pH-Werten umgehen kann.
<G-vec00301-001-s368><cope.können><en> Methionine is the result, a substance the body can cope with much better.
<G-vec00301-001-s368><cope.können><de> Es entsteht das Methionin, womit der Körper besser umgehen kann.
<G-vec00301-001-s369><cope.können><en> With very little kids, as practice shows, you have to cope with other methods.
<G-vec00301-001-s369><cope.können><de> Bei sehr kleinen Kindern müssen Sie, wie die Praxis zeigt, mit anderen Methoden umgehen.
<G-vec00301-001-s370><cope.können><en> Now Eva is free again, but can't really cope with her child and sends Jasmin away again and again.
<G-vec00301-001-s370><cope.können><de> Jetzt ist Eva wieder auf freiem Fuß, kann mit Ihrem Kind schwer umgehen und schickt die hartnäckige Jasmin immer wieder weg.
<G-vec00301-001-s371><cope.können><en> Do not think that any adult can easily cope with them.
<G-vec00301-001-s371><cope.können><de> Denken Sie nicht, dass jeder Erwachsene leicht mit ihnen umgehen kann.
<G-vec00301-001-s372><cope.können><en> The build daemon software can't cope with this new character yet, though.
<G-vec00301-001-s372><cope.können><de> Die Build-Daemon-Software kann allerdings noch nicht mit diesem neuen Zeichen umgehen.
<G-vec00301-001-s373><cope.können><en> Many girls do not believe that such a tool can cope with this problem.
<G-vec00301-001-s373><cope.können><de> Viele Mädchen glauben nicht, dass ein solches Werkzeug mit diesem Problem umgehen kann.
<G-vec00301-001-s374><cope.können><en> Nepal Jam by ACE Seeds is a compact and strong cannabis strain with good to high resistances to spider mites, powdery mildew, botrytis and cold climates - she can even cope with sudden weather caprices.
<G-vec00301-001-s374><cope.können><de> Nepal Jam von ACE Seeds ist eine kompakte und starke Cannabis Sorte mit guten bis sehr guten Resistenzen gegen Spinnmilben, Mehltau, Botrytis und kühlere Klimazonen - sie kann sogar mit plötzlichen Wetterkapriolen umgehen.
<G-vec00301-001-s375><cope.können><en> This option is meant to solve frame-order issues when encoding to container formats like AVI that cannot cope with out-of-order frames.
<G-vec00301-001-s375><cope.können><de> Diese Option ist dazu gedacht, Probleme mit der Framereihenfolge zu lösen bei der Encodierung in Containerformate wie AVI, die mit aus der Reihenfolge gekommenen Frames nicht umgehen können.
<G-vec00301-001-s376><cope.können><en> Enterprises therefore have to find a way of being able to cope with the ongoing changes in their systems.
<G-vec00301-001-s376><cope.können><de> Unternehmen müssen daher Mittel finden, mit der laufenden Veränderungen ihrer Systeme umgehen zu können.
<G-vec00301-001-s377><cope.können><en> A serious psychotherapist can cope constructively with your criticism.
<G-vec00301-001-s377><cope.können><de> Ein seriös ausgebildeter Psychotherapeut kann mit Kritik konstruktiv umgehen.
<G-vec00301-001-s378><cope.können><en> Tell us why your strengths make you ideal for the vacancy – and also tell us how you cope with your weak points.
<G-vec00301-001-s378><cope.können><de> Sagen Sie uns, warum Sie mit Ihren Stärken zur Stelle passen – und wie Sie mit Ihren Schwächen umgehen.
<G-vec00301-001-s379><cope.können><en> We are working on further measures to improve earnings, which will enable us to cope with greater headwinds, too,” said Simone Menne, Member of the Executive Board and CFO at Deutsche Lufthansa AG.
<G-vec00301-001-s379><cope.können><de> Wir arbeiten an weiteren Maßnahmen zur Ergebnisverbesserung, um auch mit zusätzlichem Gegenwind umgehen zu können“, sagte Simone Menne, Vorstand Finanzen und Aviation Services der Deutschen Lufthansa AG.
<G-vec00301-001-s380><cope.können><en> Your doctor may also suggest that you speak with a counselor to learn how to better cope with IBS.
<G-vec00301-001-s380><cope.können><de> Ihr Arzt kann Ihnen auch vorschlagen, dass Sie mit einem Berater sprechen, um zu lernen, wie Sie besser mit IBS umgehen können.
<G-vec00301-001-s381><cope.können><en> "Nils Muižnieks ""Serbia needs to strengthen its asylum system and reception capacities in order to cope with the ever increasing number of arrivals, in particular from war-torn Syria."
<G-vec00301-001-s381><cope.können><de> "Nils Muižnieks ""Serbien muss sein Asylsystem und seine Aufnahmekapazitäten verstärken, um mit der steigenden Zahl neuer Flüchtlinge, insbesondre aus dem vom Krieg gezeichneten Syrien, umgehen zu können."
<G-vec00301-001-s382><cope.können><en> To cope with this stigma, learn about the amazing individual that is you, and help others learn about you too.
<G-vec00301-001-s382><cope.können><de> Um mit diesen Stigmen umgehen zu können, lerne, was für ein erstaunliches Individuum du bist und hilf anderen dabei, mehr über dich zu erfahren.
<G-vec00301-001-s383><cope.können><en> In an experiment, a WSL research team led by Christoph Bachofen, joined by colleagues from the ETH Zurich and the University of Basel, tried to 'kill two birds with one stone', first by testing how two-year-old Scots pines and black pines of different origins, ranging from the Alps to the Mediterranean, cope with lengthy droughts.
<G-vec00301-001-s383><cope.können><de> Mit einem Experiment schlug ein WSL-Forscherteam um Christoph Bachofen zusammen mit Kollegen der ETH Zürich und der Universität Basel nun gleich zwei Fliegen mit einer Klappe: Es testete, wie zweijährige Wald- und Schwarzföhren verschiedener Herkünfte von den Alpen bis zum Mittelmeer mit langen Trockenperioden umgehen können.
<G-vec00301-001-s384><cope.können><en> There is an opinion that the more the testicles, the better they cope with their functions.
<G-vec00301-001-s384><cope.können><de> Es besteht die Meinung, dass die Hoden umso besser mit ihren Funktionen umgehen können.
<G-vec00301-001-s385><cope.umgehen><en> Therefore the inability of a person to cope with stress in life and the causes of his unhappiness arise mainly from basic undesirable qualities in his personality and anxiety caused due to past incidents or unfinished business.
<G-vec00301-001-s385><cope.umgehen><de> Somit wird die Unfähigkeit eines Menschen, im Leben mit Stress umzugehen hauptsächlich durch unerwünschte Mängel in seiner Persönlichkeit und einer Angst aufgrund vergangener Ereignisse oder unerledigte Angelegenheiten verursacht.
<G-vec00301-001-s386><cope.umgehen><en> Sascha lives in an ugly housing project and has found her own way to cope with the trauma.
<G-vec00301-001-s386><cope.umgehen><de> Sascha lebt in einer hässlichen Hochhaussiedlung und hat ihre ganz eigene Art, mit dem Trauma, dass ihre Mutter vom Stiefvater getötet wurde, umzugehen.
<G-vec00301-001-s387><cope.umgehen><en> His attempts to cope with his helplessness, his hate, and his longing for revenge are doomed to failure and consequently lead to catastrophe.
<G-vec00301-001-s387><cope.umgehen><de> Seine Versuche, mit seiner Hilflosigkeit, seinem Hass und seinen Rachegelüsten umzugehen, sind zum Scheitern verurteilt und führen konsequent in die Katastrophe.
<G-vec00301-001-s388><cope.umgehen><en> An individual's inability to cope with stress and strain causes unhappiness.
<G-vec00301-001-s388><cope.umgehen><de> Die Unfähigkeit mit Stress und Belastung umzugehen, macht unglücklich.
<G-vec00301-001-s389><cope.umgehen><en> Microsensor measurements on the cold-water coral Desmophyllum dianthus offer insight into instantaneous physiological processes and help to understand possible mechanisms to cope with future climate conditions.
<G-vec00301-001-s389><cope.umgehen><de> Mikrosensormessungen an der Kaltwasserkoralle Desmophyllum dianthus geben Einblick in unmittelbare physiologische Prozesse und helfen uns herauszufinden, ob diese Koralle Mechanismen hat, um mit zukünftigen Klimabedingungen umzugehen.
<G-vec00301-001-s390><cope.umgehen><en> The drink helps to cope with stress, which is often the cause of the progression of the disease, the systematic occurrence of hypertensive crises.
<G-vec00301-001-s390><cope.umgehen><de> Trinken hilft, mit Stress umzugehen, der häufig die Ursache für das Fortschreiten der Krankheit ist, das systematische Auftreten hypertensiver Krisen.
<G-vec00301-001-s391><cope.umgehen><en> To do this, you need to avoid excitement and stress, as well as learn to cope with them.
<G-vec00301-001-s391><cope.umgehen><de> Um dies zu tun, müssen Sie Aufregung und Stress vermeiden und lernen, mit ihnen umzugehen.
<G-vec00301-001-s392><cope.umgehen><en> We know how to cope with risks like these, and can help others to do so, too.
<G-vec00301-001-s392><cope.umgehen><de> Wir wissen mit solchen Risiken umzugehen und können auch anderen helfen.
<G-vec00301-001-s393><cope.umgehen><en> It’s pretty harder at times to cope with the teens as their universe is entirely different from the adults.
<G-vec00301-001-s393><cope.umgehen><de> Es ist manchmal schwieriger, mit den Jugendlichen umzugehen, da ihr Universum sich von den Erwachsenen völlig unterscheidet.
<G-vec00301-001-s394><cope.umgehen><en> Games and stories help the young visitors cope with their new situation.
<G-vec00301-001-s394><cope.umgehen><de> Spiele und Geschichte helfen den jungen Besuchern dabei, mit der neuen Situation umzugehen.
<G-vec00301-001-s395><cope.umgehen><en> Describe your ability to cope with stressful situations.
<G-vec00301-001-s395><cope.umgehen><de> Beschreiben Sie Ihre Fähigkeit, mit stressigen Situationen umzugehen.
<G-vec00301-001-s396><cope.umgehen><en> And who has to cope with the truth.
<G-vec00301-001-s396><cope.umgehen><de> Und derjenige, der mit der Wahrheit umzugehen hat.
<G-vec00301-001-s397><cope.umgehen><en> Our aim is to train self-confident, critical and creative architects who are in a position to cope with changing professional circumstances.
<G-vec00301-001-s397><cope.umgehen><de> Es ist unser Ziel, selbstbewusste, kritische und kreative Architekten auszubilden, die in der Lage sind, mit den sich ändernden beruflichen Rahmenbedingungen umzugehen.
<G-vec00301-001-s398><cope.umgehen><en> - I do not envy our coaches, who find it difficult to cope with the emotions.
<G-vec00301-001-s398><cope.umgehen><de> - Ich weiß nicht Neid unserer Coaches, die es schwierig, mit den Emotionen umzugehen.
<G-vec00301-001-s399><cope.umgehen><en> But there are techniques that can help you to cope.
<G-vec00301-001-s399><cope.umgehen><de> Aber es gibt Techniken, damit umzugehen.
<G-vec00301-001-s400><cope.umgehen><en> On the contrary, it points to a crisis of inadequacy resulting from an inability to cope with stress.
<G-vec00301-001-s400><cope.umgehen><de> Im Gegenteil, es deutet auf eine Unzulänglichkeitskrise hin, die aus einer Unfähigkeit, mit Stress umzugehen, resultiert.
<G-vec00301-001-s401><cope.umgehen><en> Many children adopt strategies to cope with CVD, so much so that as many as 80% leave primary school not knowing that they have this condition.
<G-vec00301-001-s401><cope.umgehen><de> Viele Kinder entwickeln so gute Strategien mit CVD umzugehen, dass etwa 80% von ihnen die Grundschule verlassen ohne von ihrer CVD zu wissen.
<G-vec00301-001-s402><cope.umgehen><en> Log in Cultural Intelligence (CQ) is the ability to cope with national, corporate and vocational cultures as described by Christopher Earley and Elaine Mosakowski in HBR of October 2004.
<G-vec00301-001-s402><cope.umgehen><de> Kulturelle Intelligenz (Cq) ist die Fähigkeit, mit nationalen, unternehmerischen und beruflichen Kulturen umzugehen, wie durch Christopher Earley und Elaine Mosakowski in der HBR von Oktober 2004 beschrieben.
<G-vec00301-001-s403><cope.umgehen><en> Their survival instinct manifested itself in various games, toys and pictures that they created in an effort to cope with the horrors they faced.
<G-vec00301-001-s403><cope.umgehen><de> Im Versuch mit dem Horror, den sie erlebten, umzugehen, kreierten diese Kinder Spiele, Bilder und Spielzeug, in denen sich ihr Überlebenswille spiegelt.
<G-vec00301-001-s404><cope.verkraften><en> Marguerite de la Motte had to cope with some stroke of fates personally.
<G-vec00301-001-s404><cope.verkraften><de> Privat musste Marguerite de la Motte viele Schicksalsschläge verkraften.
<G-vec00301-001-s405><cope.verkraften><en> His wife helped John Nash to cope with his illness.
<G-vec00301-001-s405><cope.verkraften><de> Seine Frau half John Nash die Krankheit zu verkraften.
<G-vec00301-001-s406><cope.verkraften><en> Our tool makes email migrations a simple and straightforward task that virtually any user can easily cope with.
<G-vec00301-001-s406><cope.verkraften><de> Unser Tool macht e-Mail Migrationen eine einfache und unkomplizierte-Aufgabe, der praktisch jeder Benutzer leicht zu verkraften.
<G-vec00301-001-s407><cope.verkraften><en> That is also why he already had to cope with a bad stroke of fate.
<G-vec00301-001-s407><cope.verkraften><de> Genau deshalb hatte er auch schon einen schweren Schicksalsschlag zu verkraften.
<G-vec00301-001-s408><cope.verkraften><en> In an interview for the Christmas issue of the Süddeutsche Zeitung, Ramsauer said that he wanted any increase in the volume of freight transport “to be put onto the railways as much as possible” since the road network would not be able to “cope” with the extra load.
<G-vec00301-001-s408><cope.verkraften><de> Ramsauer hatte sich in einem zu Weihnachten veröffentlichten Interview mit der Süddeutschen Zeitung dafür ausgesprochen, den Zuwachs des Güterverkehrsaufkommens „möglichst vollständig auf die Schiene zu bringen“, da das Straßennetz diesen Zuwachs nicht „verkraften“ könne.
<G-vec00301-001-s409><cope.verkraften><en> There are experiences which we find great, and others that are difficult to cope with.
<G-vec00301-001-s409><cope.verkraften><de> Es gibt Erfahrungen, die wir toll finden, und andere, die schwer zu verkraften sind.
<G-vec00301-001-s410><cope.verkraften><en> In a certain sense, you always play with full commitment and this makes it extremely hard for you to cope with possible losses.
<G-vec00301-001-s410><cope.verkraften><de> In gewisser Weise spielen Sie stets mit vollem Einsatz und können so etwaige Verluste nur äußerst schwer verkraften.
<G-vec00301-001-s411><cope.verkraften><en> She sees herself having to move into a council flat and tells Adam that there is no way that the house could be sold: It is just about large enough for the children and herself and in any event Jack has started bed-wetting again and would be unable to cope with moving.
<G-vec00301-001-s411><cope.verkraften><de> Sie stellt sich vor, dass sie in eine Sozialwohnung ziehen muss und sagt, dass unter keinen Umständen das Haus verkauft werden kann, weil es gerade groß genug für sie und die Kinder ist und außerdem Jack wieder mit Bettnässen angefangen hat und er einen Umzug auch jetzt gerade nicht verkraften könnte.
<G-vec00301-001-s412><cope.verkraften><en> An impressive re-enactment, in which Juan Manuel Fangio must cope with the death of his friend, racing driver Onofre Marimon, shows the potential consequences.
<G-vec00301-001-s412><cope.verkraften><de> Die möglichen Folgen zeigt ein eindrucksvolles Re-Enactment, in dem Juan Manuel Fangio den Tod seines Rennfahrerfreunds Onofre Marimon verkraften muss.
<G-vec00301-001-s413><cope.verkraften><en> Danger is imminent: Every fourth German digital company (25%) had to cope with at least one cyber damage in the past.
<G-vec00301-001-s413><cope.verkraften><de> Und die Gefahr ist real: Jedes vierte deutsche Digitalunternehmen (25%) hatte in der Vergangenheit bereits mindestens einen Cyberschaden zu verkraften.
<G-vec00301-001-s414><cope.verkraften><en> In London the top-class marathon of the year will be held on Sunday, although the organizers had to cope with the pull out of Paul Tergat (Kenya) and Paula Radcliffe (Great Britain) due to injury.
<G-vec00301-001-s414><cope.verkraften><de> In London wird am Sonntag der hochkarätigste Marathon des Jahres gestartet, obwohl die Organisatoren die verletzungsbedingten Absagen der beiden Weltrekordler Paul Tergat (Kenia) und Paula Radcliffe (Großbritannien) verkraften musste.
<G-vec00301-001-s415><cope.verkraften><en> In the present Sakutaro revisits old places from his memory and tries to finally cope with the death of his girlfriend several years ago.
<G-vec00301-001-s415><cope.verkraften><de> In der Gegenwart sucht Sakutaro alte Orte wieder auf und versucht endlich den Tod seiner Freundin vor etlichen Jahren verkraften zu können.
<G-vec00301-001-s416><cope.verkraften><en> "However, in her book ""Raubkind"" she also relates that the late discovery of his origins was an existential turning point in the man's life and difficult for him to cope with."
<G-vec00301-001-s416><cope.verkraften><de> "In ihrem Buch ""Raubkind"" erzählt sie aber auch, dass die späte Aufdeckung seiner Herkunft ein existenzieller Einschnitt im Leben des Mannes und nur schwer für ihn zu verkraften war."
<G-vec00301-001-s417><cope.verkraften><en> The rise in the sea level also takes its toll, particularly in the vast delta areas of the country.” Traditionally held species such as carp, catfish and perch are not able to cope with the resulting severe fluctuations of the salt content of the water.
<G-vec00301-001-s417><cope.verkraften><de> Auch der Anstieg des Meeresspiegels fordert seinen Tribut, insbesondere in den riesigen Deltagebieten des Landes.“ Die resultierenden starken Schwankungen im Salzgehalt des Wassers sind für die traditionell gehaltenen Arten wie Karpfen, Wels und Barsch nicht zu verkraften.
<G-vec00301-001-s418><cope.verkraften><en> Their use should be limited to situations in which the financial system is unable to cope with cyclical downturns or unexpected major incidents or needs help in recovering from them following a period of correction.
<G-vec00301-001-s418><cope.verkraften><de> Ihr Einsatz soll auf Situationen beschränkt werden, in denen das Finanzsystem nicht in der Lage ist, zyklische Abschwünge oder größere unerwartete Ereignisse zu verkraften und sich nach einer Korrekturphase selbstständig davon zu erholen.
<G-vec00301-001-s419><cope.verkraften><en> The land can no longer cope with the immense amount of up to 90,000 m3 of waste water a day.
<G-vec00301-001-s419><cope.verkraften><de> Die ungeheure Menge von bis zu 90.000 Kubikmeter Abwasser täglich konnte das Gelände nicht mehr verkraften.
<G-vec00301-001-s420><cope.verkraften><en> The girl herself can not cope with such a negative, so she should help her.
<G-vec00301-001-s420><cope.verkraften><de> Das Mädchen selbst kann solch ein Negativ nicht verkraften, also sollte sie ihr helfen.
<G-vec00301-001-s421><cope.verkraften><en> In our view the eurozone economy could cope with both a degree of currency appreciation as well as a throttling back of QE.
<G-vec00301-001-s421><cope.verkraften><de> Unseres Erachtens kann die EWU-Wirtschaft sowohl eine gewisse Wechselkursaufwertung als auch eine Drosselung von QE verkraften.
<G-vec00301-001-s422><cope.verkraften><en> And cope with the speed that is an essential feature of the games industry where IT projects are not planned over years but over weeks; where development, delivery and constant improvement take place in rapid cycles.
<G-vec00301-001-s422><cope.verkraften><de> Und das Tempo verkraften, das in der Games-Branche herrscht: Hier werden IT-Projekte nicht über Jahre geplant, sondern über Wochen, in schnellen Zyklen wird entwickelt, ausgeliefert und immer wieder verfeinert.
<G-vec00301-001-s423><cope.verkraften><en> Now I am not intending to bemoan the loss of this collective regimentation, but the practice shows that the vast majority was hardly able to cope with this turn taken by historical development.
<G-vec00301-001-s423><cope.verkraften><de> Nun möchte ich keineswegs dieser kollektiven Reglementierung nachweinen, jedoch zeigt die Praxis, dass dieser Sprung in der Entwicklung der Geschichte von den meisten kaum verkraftet wurde.
<G-vec00301-001-s424><cope.verkraften><en> Everyone who found it difficult to cope with his absence from the stage can breath a sigh of relief at last: the critical parade crossover musician from Salzkammergut yodels again.
<G-vec00301-001-s424><cope.verkraften><de> Alle, die seinen Bühnenabschied nur schwer verkraftet haben, können endlich aufatmen: Der kritische Parade-Crossovermusiker aus dem Salzkammergut jodelt wieder.
<G-vec00301-001-s425><cope.verkraften><en> The sintered base can also cope with stone contacts to a certain degree without any problems.
<G-vec00301-001-s425><cope.verkraften><de> Die gesinterte Base verkraftet auch den ein oder anderen Steinkontakt ohne Probleme.
<G-vec00301-001-s426><cope.verkraften><en> Peter nearly couldn't cope with it....
<G-vec00301-001-s426><cope.verkraften><de> Das hat Peter fast nicht verkraftet....
<G-vec00301-001-s427><cope.verkraften><en> Whether the German electricity grid will easily be able to cope with the additional charging requirements of EVs, however, depends largely on how the vehicles are charged.
<G-vec00301-001-s427><cope.verkraften><de> Ob das deutsche Stromnetz die zusätzlichen Ladeleistungen der Elektrofahrzeuge problemlos verkraftet, hängt allerdings stark davon ab, wie Elektrofahrzeuge geladen werden.
<G-vec00301-001-s461><cope.zurechtkommen><en> Current projects study olfaction, archaeal transcription, aggregate structure and formation in pharmaceutical preparations, and development of methodologies to cope with non-ideal highly concentrated solutions.
<G-vec00301-001-s461><cope.zurechtkommen><de> Im Moment laufen Projekte über Geruchswahrnehmung, Transkription bei Archaebakterien, Struktur und Bildung von Aggregaten in pharmazeutischen Präparaten, sowie die Entwicklung von Methoden, um mit nicht-idealen hochkonzentrierten Lösungen zurecht zu kommen.
<G-vec00301-001-s462><cope.zurechtkommen><en> All passengers (international or domestic) who require oxygen but will be able to cope with portable oxygen concentrator and their medical condition permit use of POC.
<G-vec00301-001-s462><cope.zurechtkommen><de> Alle Passagiere (Inlands- oder Auslandsflüge), die Sauerstoff benötigen, jedoch mit einem tragbaren Sauerstoffkonzentrator zurecht kommen und deren Gesundheitszustand dies auch zulässt.
<G-vec00301-001-s463><cope.zurechtkommen><en> To be able to cope with the big differences from one region to another, and from one crop to another, a more flexible global agricultural trading system would be needed, MÃ1⁄4ller says.
<G-vec00301-001-s463><cope.zurechtkommen><de> Um mit den großen Unterschieden von einer Region zur anderen und von einer Pflanze zur anderen zurecht zu kommen, wäre ein flexibleres weltweites Handelssystem für landwirtschaftliche Güter nötig, so Müller.
<G-vec00301-001-s464><cope.zurechtkommen><en> The constantly evolving threat landscape and increasingly complex networks and IT environments are driving greater demand for dependable security solutions that can cope with the latest threats.
<G-vec00301-001-s464><cope.zurechtkommen><de> Die sich kontinuierlich ausweitende Gefährdungslage und die wachsende Komplexität von Netzwerken und IT-Umgebungen generieren eine steigende Nachfrage nach verlässlichen Security-Lösungen, die auch mit den neuesten Bedrohungen zurecht kommen.
<G-vec00301-001-s465><cope.zurechtkommen><en> They will try to destroy it, they cannot cope with the good energy of love.
<G-vec00301-001-s465><cope.zurechtkommen><de> Sie werden versuchen sie zu zerstören, weil sie mit der guten Energie der Liebe nicht zurecht kommen.
<G-vec00301-001-s466><cope.zurechtkommen><en> But we promised to tell you how the ice plant manages to cope with such great heat.
<G-vec00301-001-s466><cope.zurechtkommen><de> Wir sind noch Antwort schuldig, wie es die Mittagsblume schafft, mit solch großer Hitze zurecht zu kommen.
<G-vec00301-001-s467><cope.zurechtkommen><en> See 2) below. When it is difficult to cope and/or hard to carry on, MORE FREQUENT use of Vita Fons II is called for.
<G-vec00301-001-s467><cope.zurechtkommen><de> Wenn Sie nicht mehr zurecht kommen und Ihnen das Weitermachen schwerfällt, dann sind noch häufigere Behandlungen mit Vita Fons II erforderlich (siehe 4).
<G-vec00301-001-s468><cope.zurechtkommen><en> It shall cope with the minerals contained in tap water (water hardness).
<G-vec00301-001-s468><cope.zurechtkommen><de> Es muss mit den in Leitungswasser enthaltenen Mineralstoffen (Wasserhärte) zurecht kommen.
<G-vec00301-001-s469><cope.zurechtkommen><en> Luckily I had great support from my family who time after time helped to cope with this difficult situation.
<G-vec00301-001-s469><cope.zurechtkommen><de> Glücklicherweise genoss ich die Unterstützung meiner Familie, die mir immer wieder half, mit der schwierigen Situation zurecht zu kommen.
<G-vec00301-001-s470><cope.zurechtkommen><en> Consequently, the public offices – also due to their political and social mandate – have to cope with all change.
<G-vec00301-001-s470><cope.zurechtkommen><de> So müssen die Behörden – auch aufgrund des politischen und gesellschaftlichen Auftrags – mit jedem Wandel zurecht kommen.
<G-vec00301-001-s471><cope.zurechtkommen><en> The Roman scribes tended to slant these letters, particularly with the increased use of papyrus, in order to cope better with the grooved structure of their writing surface.
<G-vec00301-001-s471><cope.zurechtkommen><de> Ältere Römische Kursive Besonders durch den vermehrten Gebrauch von Papyrus tendierte der römische Schreiber zur Schrägstellung der Buchstaben, um mit der Rillenstruktur seines Schriftstücks besser zurecht zu kommen.
<G-vec00301-001-s472><cope.zurechtkommen><en> It Boosts: (1) Growth of the entire being via increase of (a) empathy and (b) ability to cope.
<G-vec00301-001-s472><cope.zurechtkommen><de> Verstärkt: (1) die Entwicklung/ Wachstum des gesamten Wesens durch eine Steigerung an a) Empathie und b) die Fähigkeit zurecht zu kommen.
<G-vec00301-001-s473><cope.zurechtkommen><en> The Afghani purple Indicas were bred by the Dutch Passion masters with local Sativas, to achieve a fast finishing purple strain that would be hardy enough to cope with the European harsh climate and short summer.
<G-vec00301-001-s473><cope.zurechtkommen><de> Die afghanischen lila Indicas wurden von den Dutch Passion Meistern mit lokalen Sativas gezüchtet, um eine schnell abschließende lila Sorte zu schaffen, die robust genug wäre, mit dem rauen europäischen Klima und den kurzen Sommern zurecht zu kommen.
<G-vec00301-001-s474><cope.zurechtkommen><en> The BurnBooster slimming diet supplement has been developed for people who can not cope with diets and go to the gym, and who intend or need to get rid of a few unnecessary kilograms.
<G-vec00301-001-s474><cope.zurechtkommen><de> Das BurnBooster Schlankheitspräparat wurde für Menschen entwickelt, die mit Diäten nicht zurecht kommen und ins Fitnessstudio gehen und einige unnötige Kilos loswerden wollen oder müssen.
<G-vec00301-001-s475><cope.zurechtkommen><en> When there are enough patents applying to one product it becomes hard to cope with the patent system at all.
<G-vec00301-001-s475><cope.zurechtkommen><de> Wenn genügend Patente auf ein Produkt anwendbar sind, wird es schwierig, mit dem Patentsystem überhaupt zurecht zu kommen.
<G-vec00301-001-s476><cope.zurechtkommen><en> Bacopa Monnieri belongs a group of substances known as adaptogens, which can help your body and your mind to cope better with mental and physical stress.
<G-vec00301-001-s476><cope.zurechtkommen><de> Bacopa Monnieri gehört zur Gruppe der Adaptogene, die Deinem Körper und Deinem Geist dabei helfen, besser mit mentalem und körperlichem Stress zurecht zu kommen.
<G-vec00301-001-s477><cope.zurechtkommen><en> And during all of that time there will have to be some kind of a heavy totalitarian infrastructure in order to cope with this on-going emergency and re-build.
<G-vec00301-001-s477><cope.zurechtkommen><de> Und während dieser Zeit wird es eine Art strenge totalitäre Infrastruktur geben müssen, um mit dieser Serie von Notfällen zurecht zu kommen und den Wiederaufbau zu bewirken.
<G-vec00301-001-s478><cope.zurechtkommen><en> Humor, after all, is a suitable means to cope with the worst—as Nikita Diakur's Ugly attests, in which the world is coming apart at the seams.
<G-vec00301-001-s478><cope.zurechtkommen><de> Überhaupt ist Humor ein probates Mittel, um mit dem Schlimmsten zurecht zu kommen – so auch in Nikita Diakurs Ugly, in dem die Welt aus den Fugen gerät.
<G-vec00301-001-s479><cope.zurechtkommen><en> They should give you the (true) impression that they are quite able to cope with their own lives.
<G-vec00301-001-s479><cope.zurechtkommen><de> Man soll den (wahrhaftigen) Eindruck haben, dass sie mit ihrem eigenen Leben zurecht kommen.
<G-vec00301-001-s480><cope.zurechtkommen><en> By the way, the floor lamp put near a desk can perfectly cope with illumination of its surface at work, replacing a desk lamp or a sconce.
<G-vec00301-001-s480><cope.zurechtkommen><de> Ã brigens kann gestellt neben dem Schreibtisch torscher mit der Beleuchtung seiner Oberfläche bei der Arbeit sehr gut zurechtkommen, die Tischlampe oder den Wandleuchter ersetzend.
<G-vec00301-001-s481><cope.zurechtkommen><en> Their elimination – a success basis therefore after classes with experts of people will be able to cope with ease with the appetite and quite simply transfers restrictions which are imposed on a daily diet by any diet.
<G-vec00301-001-s481><cope.zurechtkommen><de> Ihre Liquidation – die Grundlage des Erfolges, deshalb nach den Beschäftigungen mit den Fachkräften der Mensch mit der Leichtigkeit kann mit dem Appetit zurechtkommen und ziemlich einfach verlegt die Beschränkungen, die auf die tägliche Ration eine beliebige Diät auflegt.
<G-vec00301-001-s482><cope.zurechtkommen><en> The motif presented a serious challenge to Abbott: “This boat was rising and lowering, and I had a tremendous depth of field to cope with here.
<G-vec00301-001-s482><cope.zurechtkommen><de> Das Motiv stellt für Abbott eine echte Herausforderung dar: „Andauernd hebte und senkte sich das Boot und ich musste mit dieser enormen Schärfentiefe zurechtkommen.
<G-vec00301-001-s483><cope.zurechtkommen><en> Each athlete is allowed 90 seconds and the entire team assembles to see how the horses cope with the gigantic stadium.
<G-vec00301-001-s483><cope.zurechtkommen><de> 90 Sekunden stehen jedem Athleten zu und stets versammelt sich das ganze Team um zu sehen, wie die Pferde mit dem riesigen Stadion zurechtkommen.
<G-vec00301-001-s484><cope.zurechtkommen><en> Chocolate pie with condensed milk The chocolate pie with condensed milk prepares simply and even the most inexperienced hostesses without effort will cope with this recipe.
<G-vec00301-001-s484><cope.zurechtkommen><de> Die Schokoladentorte mit der verdickten Milch Die Schokoladentorte mit der verdickten Milch bereitet sich einfach vor und sogar die am meisten unerfahrenen Hauswirtinnen werden mit diesem Rezept mühelos zurechtkommen.
<G-vec00301-001-s485><cope.zurechtkommen><en> • useful properties in boiled beet are lost absolutely slightly therefore it will also successfully cope with clearing, laxative, normalizing work of intestines and liver functions.
<G-vec00301-001-s485><cope.zurechtkommen><de> • verlieren sich die nützlichen Eigenschaften in otwarnoj der Rübe ganz unbedeutend, deshalb sie wird auch erfolgreich mit reinigend, slabitelnoj, normalisierend die Arbeit des Darms und der Leber von den Funktionen zurechtkommen.
<G-vec00301-001-s486><cope.zurechtkommen><en> Work simple, will easily cope with it even the child.
<G-vec00301-001-s486><cope.zurechtkommen><de> Die Arbeit unkompliziert, mit ihr werden sogar das Kind leicht zurechtkommen.
<G-vec00301-001-s487><cope.zurechtkommen><en> This hand-made article from vegetables very simple in production therefore children in kindergarten will easily cope with it.
<G-vec00301-001-s487><cope.zurechtkommen><de> Diese kleine Arbeit aus dem Gemüse sehr einfach in der Herstellung, deshalb mit ihr werden die Kinder im Kindergarten leicht zurechtkommen.
<G-vec00301-001-s488><cope.zurechtkommen><en> She will perfectly cope with nausea and a congestion of ears.
<G-vec00301-001-s488><cope.zurechtkommen><de> Sie wird mit der Übelkeit und saloschennostju der Ohren ausgezeichnet zurechtkommen.
<G-vec00301-001-s489><cope.zurechtkommen><en> Anyone who reduces the financial pressure by living cheaply and buying cheaply will also cope with a comparatively low salary.
<G-vec00301-001-s489><cope.zurechtkommen><de> Wer den finanziellen Druck mindert, indem er günstig wohnt und günstig einkauft, wird auch mit einem vergleichsweise geringen Gehalt zurechtkommen.
<G-vec00301-001-s490><cope.zurechtkommen><en> However, in the new series, the couple is waiting for even greater problems, and we just have to watch how the characters of Olga and Victor will cope with their changes in life.
<G-vec00301-001-s490><cope.zurechtkommen><de> Doch in der neuen Serie wartet das Paar auf noch größere Probleme und wir müssen nur zusehen, wie die Charaktere von Olga und Victor mit ihren Veränderungen im Leben zurechtkommen.
<G-vec00301-001-s491><cope.zurechtkommen><en> On the water, however, they appear as good swimmers and divers, who cope well even with strong swell.
<G-vec00301-001-s491><cope.zurechtkommen><de> Auf dem Wasser zeigen sie sich aber als gute Schwimmer und Taucher, die selbst bei starkem Seegang gut zurechtkommen.
<G-vec00301-001-s492><cope.zurechtkommen><en> Properly chosen pills for high blood pressure during pregnancy can cope with arterial hypertension and significantly improve the condition of a woman.
<G-vec00301-001-s492><cope.zurechtkommen><de> Richtig ausgewählte Pillen für Bluthochdruck während der Schwangerschaft können mit arterieller Hypertonie zurechtkommen und den Zustand einer Frau signifikant verbessern.
<G-vec00301-001-s493><cope.zurechtkommen><en> To remain beautiful winter - a difficult task, but by means of our councils, you will cope with it.
<G-vec00301-001-s493><cope.zurechtkommen><de> Ein schöner Winter - die Aufgabe nicht aus den Lungen, aber mit Hilfe unserer Räte zu bleiben, Sie werden mit ihr zurechtkommen.
<G-vec00301-001-s494><cope.zurechtkommen><en> And if many of us cope with elimination of heartburn, having taken medicine for it, pregnant women are not able to afford their application.
<G-vec00301-001-s494><cope.zurechtkommen><de> Und wenn viele uns mit der Beseitigung des Sodbrennens zurechtkommen, die Arznei von ihr eingenommen, können sich so die schwangeren Frauen ihre Anwendung nicht gönnen.
<G-vec00301-001-s495><cope.zurechtkommen><en> And when the amount of harmful foods in our diet becomes more than beneficial, the intestines no longer cope.
<G-vec00301-001-s495><cope.zurechtkommen><de> Und wenn die Menge an schädlichen Lebensmitteln in unserer Ernährung mehr als vorteilhaft ist, werden die Eingeweide nicht länger zurechtkommen.
<G-vec00301-001-s496><cope.zurechtkommen><en> The authors show that dragonfly species which breed in pools and ponds are better able to cope with climate change than species whose habitats are streams and rivers.
<G-vec00301-001-s496><cope.zurechtkommen><de> Es zeigte sich, dass Libellenarten, deren Larven in Tümpeln und Teichen leben, mit dem Klimawandel besser zurechtkommen als ihre in Bächen und Flüssen lebenden Artgenossen.
<G-vec00301-001-s497><cope.zurechtkommen><en> And nevertheless to cope with introduction it is possible if to solve one uneasy problem – to stimulate the personnel to CRM-system use.
<G-vec00301-001-s497><cope.zurechtkommen><de> Und dennoch mit der Einführung zurechtkommen es kann, wenn eine komplizierte Aufgabe zu lösen – das Personal zur Nutzung des CRM-Systems zu fördern.
<G-vec00301-001-s498><cope.zurechtkommen><en> It would easily cope with the seasonal changes in ambient temperature, which had wreaked havoc with condensation in the past.
<G-vec00301-001-s498><cope.zurechtkommen><de> Dieses System würde problemlos mit jahreszeitlich bedingten Schwankungen der Umgebungstemperatur zurechtkommen, etwas, das die Kondensation in der Vergangenheit extrem beeinträchtigt hatte.
<G-vec00301-001-s499><cope.zurechtkommen><en> The child can serve himself, and the mother will not worry that her son will not cope.
<G-vec00301-001-s499><cope.zurechtkommen><de> Das Kind kann sich selbst bedienen, und die Mutter macht sich keine Sorgen, dass ihr Sohn nicht zurechtkommt.
<G-vec00301-001-s500><cope.zurechtkommen><en> However, parents today are not easy to get a suitable powder that will cope with pollution.
<G-vec00301-001-s500><cope.zurechtkommen><de> Eltern sind jedoch heutzutage nicht leicht, ein geeignetes Pulver zu erhalten, das mit der Umweltverschmutzung zurechtkommt.
<G-vec00301-001-s501><cope.zurechtkommen><en> "a little Competition by a principle ""ъюыiчюTъш"" is held;: each of participants sings the necessary song line who in turn does not cope with the task - leaves competition."
<G-vec00301-001-s501><cope.zurechtkommen><de> "verlassen Wird der Wettbewerb nach dem Prinzip ""ъюыiчюTъш"" durchgeführt;: jeder der Teilnehmer singt die nötige Liederzeile, wer mit der Aufgabe seinerseits nicht zurechtkommt - tritt den Wettbewerb aus."
<G-vec00301-001-s502><cope.zurechtkommen><en> If the extract in a bathroom does not cope with the function, it is possible to recommend more often to air the room.
<G-vec00301-001-s502><cope.zurechtkommen><de> Wenn der Abzug im Badezimmer mit der Funktion nicht zurechtkommt, kann man öfter empfehlen, das Zimmer zu lüften.
<G-vec00301-001-s503><cope.zurechtkommen><en> As a result, any external irritation can be a strong shock, with which the body can not cope.
<G-vec00301-001-s503><cope.zurechtkommen><de> Als Folge davon kann jede äußere Reizung ein starker Schock sein, mit dem der Körper nicht zurechtkommt.
<G-vec00301-001-s504><cope.zurechtkommen><en> There is an increased salivation, with which the child can not cope on his own, because still does not know how to regulate the amount of saliva in the mouth.
<G-vec00301-001-s504><cope.zurechtkommen><de> Es gibt einen erhöhten Speichelfluss, mit dem das Kind alleine nicht zurechtkommt, weil weiß immer noch nicht, wie man die Speichelmenge im Mund reguliert.
<G-vec00301-001-s505><cope.zurechtkommen><en> But if you manage to cope with the conditions here at the Nordschleife in other cars, you will in most cases also succeed with the Cayman.
<G-vec00301-001-s505><cope.zurechtkommen><de> Aber wenn man auf der Nordschleife auch mit anderen Autos zurechtkommt, dann klappt es in den meisten Fällen auch mit dem Cayman.
<G-vec00301-001-s506><cope.zurechtkommen><en> Often children are taught too special technicians who help them to cope with problems in study.
<G-vec00301-001-s506><cope.zurechtkommen><de> Oft unterrichten die Kinder speziell technikam auch, die ihnen helfen, mit den Problemen im Studium zurechtzukommen.
<G-vec00301-001-s507><cope.zurechtkommen><en> If not to carry out any measures in order that healing began quicker, it is necessary to wait from one and a half to two weeks is rather decent interval of time so it is better to try to cope independently with trouble, and for this purpose it is necessary to know how to get rid of cold on lips.
<G-vec00301-001-s507><cope.zurechtkommen><de> Wenn keine Maße nicht zu verwirklichen damit die Heilung schneller angefangen hat, so muss man von anderthalb bis zu zwei Wochen warten ist ein genug anständiger Zeitraum, so dass es besser ist, sich selbständig zu bemühen mit der Unannehmlichkeit zurechtzukommen, und muss man dazu wissen, wie der Erkältung auf den Lippen zu entgehen.
<G-vec00301-001-s508><cope.zurechtkommen><en> Effect — adrenaline emission therefore process of fight by how to cope with excitement, gains other character.
<G-vec00301-001-s508><cope.zurechtkommen><de> Der Effekt — der Auswurf des Adrenalins, deshalb den Prozess des Kampfes dem, wie mit der Aufregung zurechtzukommen, erwirbt anderen Charakter.
<G-vec00301-001-s509><cope.zurechtkommen><en> And especially, to cope with the husband's insults.
<G-vec00301-001-s509><cope.zurechtkommen><de> Und ja besonders, mit den Beleidigungen des Mannes zurechtzukommen.
<G-vec00301-001-s510><cope.zurechtkommen><en> Zangya, who was naturally calculating and reasoned, found it increasingly difficult to cope with the wild orders of her master.
<G-vec00301-001-s510><cope.zurechtkommen><de> Zangya, welche von Natur aus eher berechnend und vernünftig war, fand es immer schwerer, mit den wilden Befehlen ihres Meisters zurechtzukommen.
<G-vec00301-001-s511><cope.zurechtkommen><en> Pilots, fortunately, managed to cope with severe weather conditions, and the plane landed at the airport safely.
<G-vec00301-001-s511><cope.zurechtkommen><de> Die Piloten, haben zum Glück geschaffen, mit den schweren Wetterbedingungen zurechtzukommen, und das Flugzeug ist im Flughafen günstig gelandet.
<G-vec00301-001-s512><cope.zurechtkommen><en> First of all it is necessary to tell that the child is capable to cope with such task even.
<G-vec00301-001-s512><cope.zurechtkommen><de> Vor allem muss man sagen, dass mit solcher Aufgabe fähig ist, sogar das Kind zurechtzukommen.
<G-vec00301-001-s513><cope.zurechtkommen><en> Your organism for itself solves how to cope with excitement, without having asked anybody the right decision.
<G-vec00301-001-s513><cope.zurechtkommen><de> Ihr Organismus für sich entscheidet sich, wie mit der Aufregung zurechtzukommen, niemanden die richtige Lösung gefragt.
<G-vec00301-001-s514><cope.zurechtkommen><en> At each point in history, human beings have to find some way to cope with the needs of material survival.
<G-vec00301-001-s514><cope.zurechtkommen><de> Zu jedem Zeitpunkt in der Geschichte müssen die Menschen irgendeine Weise finden, um mit den Bedürfnissen des materiellen Überlebens zurechtzukommen.
<G-vec00301-001-s515><cope.zurechtkommen><en> He will help to cope with complexes and to lift a self-assessment.
<G-vec00301-001-s515><cope.zurechtkommen><de> Er wird helfen, mit den Komplexen zurechtzukommen und, die Selbsteinschätzung zu heben.
<G-vec00301-001-s516><cope.zurechtkommen><en> Only regular and competent leaving will help to cope with all these problems.
<G-vec00301-001-s516><cope.zurechtkommen><de> Wird helfen, mit dieser Problemen nur der regelmäßige und sachkundige Abgang zurechtzukommen.
<G-vec00301-001-s517><cope.zurechtkommen><en> We know that cannabis abuse is rather common among patients with schizophrenia, maybe sometimes a rather bad attempt to cope with psychotic symptoms or irritability or hallucinations.
<G-vec00301-001-s517><cope.zurechtkommen><de> Es ist bekannt, dass Cannabis-Konsum relativ häufig unter Schizophreniepatienten vorkommt; vielleicht ein eher schlechter Versuch, mit psychotischen Symptomen, Verwirrung oder Halluzinationen zurechtzukommen.
<G-vec00301-001-s518><cope.zurechtkommen><en> The heated towel rail will help to cope with a fungus problem in a bathroom to you also.
<G-vec00301-001-s518><cope.zurechtkommen><de> Mit dem Problem gribka im Badezimmer Ihnen auch zurechtzukommen wird polotenzessuschitel helfen.
<G-vec00301-001-s519><cope.zurechtkommen><en> The hawthorn proved as the effective national medicine helping to cope with many problems in an organism long ago.
<G-vec00301-001-s519><cope.zurechtkommen><de> Der Weißdorn hat sich als wirksames Volksmedikament, helfend seit langem bewährt, mit vielen Problemen im Organismus zurechtzukommen.
<G-vec00301-001-s520><cope.zurechtkommen><en> Poisoning at pregnancy it is easier and safer to warn, than then to cope with its consequences.
<G-vec00301-001-s520><cope.zurechtkommen><de> Die Vergiftung bei der Schwangerschaft ist es leichter und zu benachrichtigen, als später sicherer, mit seinen Folgen zurechtzukommen.
<G-vec00301-001-s521><cope.zurechtkommen><en> However the beauty absolutely optional demands the victims and instead of a knife of the plastic surgeon the body mesotherapy will help to cope with cellulitis.
<G-vec00301-001-s521><cope.zurechtkommen><de> Jedoch fordert die Schönheit die Opfer ganz unverbindlich und anstelle des Messers des plastischen Chirurgen mit der Zellulitis wird helfen, die Mesotherapie des Körpers zurechtzukommen.
<G-vec00301-001-s522><cope.zurechtkommen><en> It needed some time to cope with the dress and to rise.
<G-vec00301-001-s522><cope.zurechtkommen><de> Ihr wurde eine bestimmte Zeit benötigt, um mit dem Kleid zurechtzukommen und, aufzustehen.
<G-vec00301-001-s523><cope.zurechtkommen><en> Products with the content of calcium as anything else will help to cope with a high pressure.
<G-vec00301-001-s523><cope.zurechtkommen><de> Die Lebensmittel mit dem Inhalt des Kalziums wie nichts anderes werden helfen, mit dem hohen Druck zurechtzukommen.
<G-vec00301-001-s524><cope.zurechtkommen><en> Because the condition can cause pain, discomfort, bleeding, and emotional distress, you may find the condition difficult to cope with at first.
<G-vec00301-001-s524><cope.zurechtkommen><de> Da diese Krankheit Schmerzen, Unbehagen, Blutungen, und emotionales Leid verursachen kann, kann es schwierig sein, mit ihr zurechtzukommen.
<G-vec00301-001-s538><cope.überwinden><en> Sandseter asserts that children need to experience the excitement of height and speed to enable them to cope with anxieties later in life.
<G-vec00301-001-s538><cope.überwinden><de> Denn laut Sandseter brauchen Kinder eine aufregende Auseinandersetzung mit Höhe und Geschwindigkeit, um spätere Ängste zu überwinden.
<G-vec00301-001-s539><cope.überwinden><en> Ginseng is an adaptogenic herb, its nutrients help our bodies cope with the effort, stress and fast pace brought on by everyday life.
<G-vec00301-001-s539><cope.überwinden><de> Ginseng ist ein adaptogenes Kraut, dessen Nährstoffe unser Körper helfen, Anstrengung, Stress und die Schnelllebigkeit des Lebens zu überwinden.
<G-vec00301-001-s540><cope.überwinden><en> We provide support with developing concepts, and we help to keep the focus on the essentials and to cope with bottlenecks during difficult phases of the implementation.
<G-vec00301-001-s540><cope.überwinden><de> Wir unterstützen die Entwicklung von Konzepten und helfen, in schwierigen Phasen der Umsetzung das Wesentliche im Auge zu behalten und Engpässe zu überwinden.
<G-vec00301-001-s541><cope.überwinden><en> There is no labyrinth to cope with - excluded...
<G-vec00301-001-s541><cope.überwinden><de> Es gibt kein Labyrinth oder sonstige Irrgärten zu überwinden - ausgenommen...
<G-vec00301-001-s542><cope.überwinden><en> Central questions in this endeavor are whether the digital mind helps us to cope with conflicts or whether it sparks new tensions and how it changes our identity.
<G-vec00301-001-s542><cope.überwinden><de> Eine zentrale Frage ist dabei jene, ob dieses digitale Gedächtnis hilft, Konflikte zu überwinden, ob es neue Spannungen nährt und wie es unsere Identität verändert.
<G-vec00205-002-s019><cope.aussetzen><en> Therefore, numerical tests can be a good indicator for the employer to better understand how you cope in stressful situations.
<G-vec00205-002-s019><cope.aussetzen><de> Der zusätzliche Stressfaktor, dem du ausgesetzt wirst gibt dem Arbeitgeber ein besseres Verständnis, wie du in bestimmten Situationen reagierst.
<G-vec00205-002-s020><cope.aussetzen><en> Our senses have to cope with a constant stream of sensory input.
<G-vec00205-002-s020><cope.aussetzen><de> Unsere Sinne sind ständig einem Sturm von Sinneseindrücken ausgesetzt.
<G-vec00205-002-s021><cope.aussetzen><en> Crew members have to cope with a very dynamic working environment and are constantly on the move.
<G-vec00205-002-s021><cope.aussetzen><de> Die Crew-Mitglieder sind ständig unterwegs und sind einem sehr dynamischen Arbeitsumfeld ausgesetzt.
<G-vec00205-002-s022><cope.aussetzen><en> This is a particular challenge when planning future smart grids that have to cope with volatile conditions anyway.
<G-vec00205-002-s022><cope.aussetzen><de> Für die Planung der intelligenten Netze der Zukunft, die ohnehin volatilen Bedingungen ausgesetzt sind, ist dies eine Herausforderung.
<G-vec00205-002-s023><cope.begegnen><en> To cope with these challenges products are often developed in cooperation networks and designed following modular approaches.
<G-vec00205-002-s023><cope.begegnen><de> Um diesen Herausforderungen zu begegnen, werden Produkte heutzutage häufig in Kooperationsnetzwerken entwickelt und nach Baukastenprinzipen gestaltet.
<G-vec00205-002-s024><cope.begegnen><en> Even "off-line" companies must compete with these circumstances and have to develop strategies how to cope with these requirements.
<G-vec00205-002-s024><cope.begegnen><de> Auch "Offline"-Unternehmen müssen sich zukünftig daran messen lassen und Strategien entwickeln, wie sie diesen Anforderungen begegnen wollen.
<G-vec00205-002-s025><cope.begegnen><en> Regular water applications help to actively improve the quality of life for the individual, getting them fit and mentally strong enough to cope with everyday life.
<G-vec00205-002-s025><cope.begegnen><de> Regelmäßige Wasseranwendungen tragen dazu bei, aktiv die persönliche Lebensqualität zu steigern und dem Alltag fit und mental gestärkt zu begegnen.
<G-vec00205-002-s026><cope.begegnen><en> And for this reason, the French experience shows that in addition to adapted legislation, associations, the police force and the media are well able to cope with the most urgent problems.
<G-vec00205-002-s026><cope.begegnen><de> Und dazu zeigt die französische Erfahrung, daß außer einer angepaßten Gesetzgebung die Vereinigungen, die polizeilichen Dienste und die Medien bei weitem ausreichen, um den dringendsten Problemen zu begegnen.
<G-vec00205-002-s027><cope.begegnen><en> End of January 2015 until end of November 2016: During this time you will have to cope with powerful outside forces that seem to take no regard of your individual ego.
<G-vec00205-002-s027><cope.begegnen><de> Anfang März 2015 bis Ende Oktober 2017: Während dieser Zeit begegnen Sie mächtigen äußeren Kräften, in Anbetracht derer Ihr individuelles Ego unwichtig zu sein scheint.
<G-vec00205-002-s028><cope.begegnen><en> Lithuania continued to progress towards a functioning market economy and was set to cope with competitive pressure and market forces within the Union in the medium term.
<G-vec00205-002-s028><cope.begegnen><de> Litauen hat weitere Fortschritte bei der Einrichtung einer funktionsfähigen Marktwirtschaft gemacht und sollte mittelfristig in der Lage sein, dem Druck des Wettbewerbs und den Marktkräften innerhalb der Union zu begegnen.
<G-vec00205-002-s029><cope.begegnen><en> Article 3 (chapter D) introduces a framework consisting of four routes of organizational design adaptation which multi-channel retailers can adopt to structurally cope with the fundamental change in consumer behavior.
<G-vec00205-002-s029><cope.begegnen><de> Aufsatz 3 (Kapitel D) führt ein Rahmenmodell ein, welches in vier idealtypischen Ansätzen aufzeigt, wie Multi-Channel Händler ihre Organisationsstruktur anpassen können, um dem disruptiven Wandel im Konsumentenverhalten zu begegnen.
<G-vec00205-002-s030><cope.begegnen><en> At least here and there politicians or state institutions expressly give theologians the task of examining the interreligious dialogue so that they, on the basis of the results, are able better to cope with the societal problems.
<G-vec00205-002-s030><cope.begegnen><de> Immerhin gibt es hier und da den ausdrücklich vorgetragenen Auftrag an Theologen durch Politiker oder staatliche Institutionen, den interreligiösen Dialog zu untersuchen, um aufgrund der Ergebnisse gesellschaftlichen Schwierigkeiten besser begegnen zu können.
<G-vec00205-002-s031><cope.begegnen><en> In order to cope with this issue, ESA is currently looking for solutions to put ENVISAT into a lower orbit and to eventually let the satellite securely burn up when re-entering the Earth’s atmosphere.
<G-vec00205-002-s031><cope.begegnen><de> Um der Situation zu begegnen, sucht die ESA zurzeit nach Lösungsansätzen, um ENVISAT auf eine tiefere Umlaufbahn zu bringen und schließlich in der Erdatmosphäre kontrolliert und sicher verglühen zu lassen.
<G-vec00205-002-s062><cope.bewältigen><en> Bespoke and modular equipment We pride ourselves in supplying equipment to suit every purpose, client and budget, from affordable entry-level machines to equipment designed to cope with high-speed, high-volume production.
<G-vec00205-002-s062><cope.bewältigen><de> Wir setzen unseren Ehrgeiz daran, Ausrüstung zu liefern, die sich für jeden Zweck, jeden Kunden und jedes Budget eignet – von preiswerten Einstiegsmaschinen bis hin zu einer Ausrüstung, die eine hochvolumige Produktion mit hoher Geschwindigkeit bewältigt.
<G-vec00205-002-s063><cope.bewältigen><en> It is suitable for lawn areas of up to 1,000 m² and, thanks to its powerful rear-wheel drive, is able to cope with uneven ground and even with inclines of up to 35 percent.
<G-vec00205-002-s063><cope.bewältigen><de> Er ist für Rasenflächen bis 1000 Quadratmeter geeignet und bewältigt mit dem kraftvollen Hinterradantrieb unebenes Gelände und sogar Steigungen bis 35 Prozent.
<G-vec00205-002-s064><cope.bewältigen><en> Recovery Explorer Professional is a robust instrument that will cope even with most challenging data loss tasks that technical experts may come across with.
<G-vec00205-002-s064><cope.bewältigen><de> Recovery Explorer Professional ist ein robustes Werkzeug, das auch die schwierigsten Datenverlust-Aufgaben, die technischen Experten begegnen können, bewältigt.
<G-vec00205-002-s065><cope.bewältigen><en> Work is carried out using the very latest tools and machinery, with a 3 shift operation in order to be able to easily cope with larger capacities.
<G-vec00205-002-s065><cope.bewältigen><de> Gearbeitet wird mit einem hochmodernen Werkzeug- und Maschinenpark im 3-Schicht-Betrieb, sodass auch größere Kapazitäten problemlos bewältigt werden können.
<G-vec00205-002-s066><cope.bewältigen><en> Rail-bound trains are the only means of transport that can be used underground on branching lines to cope with inclines of more than 13 degrees.
<G-vec00205-002-s066><cope.bewältigen><de> Entgleisungssichere Bahnen sind die einzigen, mit denen untertägig in verzweigten Strecken Steigungen von mehr als 13 Grad bewältigt werden können.
<G-vec00205-002-s067><cope.bewältigen><en> The motor's performance data opens up new possibilities for users. It can cope with extremely heavy working loads, doesn't take up as much space, and with it being 50 percent lighter, the output shaft has less weight to deal with.
<G-vec00205-002-s067><cope.bewältigen><de> Die Leistungsdaten des Motors eröffnen Anwendern neue Möglichkeiten: Er bewältigt schwerste Arbeitslasten, benötigt weniger Raum und wirkt durch seine um 50 Prozent reduzierte Masse mit geringerem Gewicht auf die Abtriebswelle.
<G-vec00205-002-s068><cope.bewältigen><en> "Allianz continues to cope successfully with the impact of the ongoing financial markets crisis on our business.
<G-vec00205-002-s068><cope.bewältigen><de> "Die Allianz bewältigt die Auswirkungen der Finanzmarktkrise auf das Geschäft weiterhin erfolgreich.
<G-vec00205-002-s218><cope.klarkommen><en> Be especially wary of abusing alcohol if you are a man, as there is evidence that men are more likely to drink to cope with loss than are women.
<G-vec00205-002-s218><cope.klarkommen><de> Sei als Mann bei Alkoholmissbrauch vorsichtig, da bewiesen wurde, dass Männer wahrscheinlicher trinken, um mit einem Verlust klarzukommen, als Frauen.
<G-vec00205-002-s219><cope.klarkommen><en> Overall, the realization remains that Bayern will often have no other choice but to cope with over 60% ball possession.
<G-vec00205-002-s219><cope.klarkommen><de> Insgesamt bleibt die Erkenntnis, dass die Bayern oft keine andere Wahl haben werden, als mit über 60% Ballbesitz klarzukommen.
<G-vec00205-002-s220><cope.klarkommen><en> When leaving this level you only need 2 keys to be able to cope in level 8.
<G-vec00205-002-s220><cope.klarkommen><de> Beim Verlassen dieses Levels braucht man lediglich 2 Schlüssel, um in Level 8 klarzukommen.
<G-vec00205-002-s221><cope.klarkommen><en> Stop worrying about why your son needs a drink before he can face his morning classes, or why your daughter went out and got pregnant. Just help them cope with the reality of life.
<G-vec00205-002-s221><cope.klarkommen><de> Macht euch nicht länger Sorgen darüber, warum euer Sohn einen Schluck trinken muss, bevor er morgens in die Schule gehen kann oder warum eure Tochter losgezogen ist und schwanger wurde, helft ihnen einfach, mit der Realität des Lebens klarzukommen.
<G-vec00205-002-s222><cope.kommen><en> The social benefit is often not enough, and the meals we have distributed now will help them to cope for the rest of the month,” says Wenzel.
<G-vec00205-002-s222><cope.kommen><de> Die Sozialhilfe reicht oft nicht und die Mahlzeiten, die wir verteilt haben, helfen ihnen, den Rest des Monats über die Runden zu kommen“, sagt Wenzel.
<G-vec00205-002-s223><cope.kommen><en> Increased energy consumption can also occur in skin cells when they need to cope with stress or make repairs.
<G-vec00205-002-s223><cope.kommen><de> Auch in Hautzellen kann es zu einem erhöhten Energieverbrauch kommen, wenn sie Stress abwehren oder Reparaturen ausführen müssen.
<G-vec00205-002-s224><cope.kommen><en> The Big Brutes will cope with water, oil and sludges with ease, even those containing lumps and other solids.
<G-vec00205-002-s224><cope.kommen><de> Die Big Brutes kommen problemlos mit Wasser, Öl und Schlamm zurecht, selbst wenn Klumpen und andere Feststoffe darin enthalten sind.
<G-vec00205-002-s225><cope.kommen><en> They also cope well with loamy sandy soils and lighter loess and gravel soils, if rainfall and distribution are appropriate.
<G-vec00205-002-s225><cope.kommen><de> Sie kommen auch mit lehmigen Sandböden und leichteren Löss- und Schotterböden gut zurecht – hier ist eine ausreichende Niederschlagsmenge relevant.
<G-vec00205-002-s226><cope.kommen><en> On top of that, you have to cope with unreliable lead times.
<G-vec00205-002-s226><cope.kommen><de> Dazu kommen die unzuverlässigen Durchlaufzeiten.
<G-vec00205-002-s227><cope.kommen><en> The Brutus is not the only product of JPAmplifiers, the main focus of Joaquim Pinto is namely a Tube Amplifier called Viriatus who is said to cope with each speaker and it's supposed to be very special, too.
<G-vec00205-002-s227><cope.kommen><de> Der Brutus ist nicht das einzige Produkt von JPAmplifiers, das Hauptaugenmerk von Joaquim Pinto gilt nämlich einem Röhren-Vollverstärker namens Viriatus, der dem Hörensagen nach mit jedem Lautsprecher klar kommen und auch sonst was ganz besonderes sein soll.
<G-vec00205-002-s228><cope.kommen><en> In addition, it has to cope with restrictions typical for DTR laptops: weight, noise, and battery life.
<G-vec00205-002-s228><cope.kommen><de> Hinzu kommen die üblichen DTR-Einschränkungen beim Gewicht, der Lautstärke und der Akkulaufzeit.
<G-vec00205-002-s229><cope.kämpfen><en> In 2005 alone, we had to cope with two disasters of truly dramatic proportions.
<G-vec00205-002-s229><cope.kämpfen><de> Allein im Jahr 2005 hatten wir mit zwei Katastrophen zu kämpfen, die dramatische Ausmaße annahmen.
<G-vec00205-002-s230><cope.kämpfen><en> Moreover, besides this, my mother has a huge number of other problems with which she has to cope.
<G-vec00205-002-s230><cope.kämpfen><de> Darüber hinaus hat meine Mutter eine Vielzahl anderer Probleme, mit denen sie zu kämpfen hat.
<G-vec00205-002-s231><cope.kämpfen><en> The Berlin group “Los ninguneados” together with local and other activists of The VOICE underlined in their opening speech the situation of being “closed-up”, with which refugees and migrants have to cope.
<G-vec00205-002-s231><cope.kämpfen><de> Die Berliner Gruppe „Los ninguneados“, zusammen mit örtlichen und angereisten Aktivisten von „The VOICE“ betonten in ihrer einführenden Ansprache die Situation des Eingeschlossenseins, mit der Flüchtlinge und MigrantInnen zu kämpfen haben.
<G-vec00205-002-s232><cope.kämpfen><en> If during a screening process a crack occurs in the mesh or the machine has to cope with too much product, the online particle measuring device JEL Horus ensures early detecting of the problem, hence avoiding high consequential costs.
<G-vec00205-002-s232><cope.kämpfen><de> Sollte beim Siebprozess das Siebgewebe reißen oder die Maschine mit zu viel Produkt zu kämpfen haben, sorgt die Online-Partikelmessung der JEL Horus für ein frühzeitiges Erkennen des Problems und damit zur Vermeidung von eventuell hohen Folgekosten.
<G-vec00205-002-s233><cope.kämpfen><en> Mining companies who have to cope with an increased power demand, who are in search for a reliable and efficient off-grid energy supply or who want to replace their existing, very expensive rental power plant, find a solid partner in ABC.
<G-vec00205-002-s233><cope.kämpfen><de> Bergbauunternehmen, die mit einem erhöhten Strombedarf zu kämpfen haben, die eine zuverlässige und effiziente netzunabhängige Energieversorgung suchen oder ihr bestehendes, überteuertes Mietkraftwerk ersetzen wollen, finden in ABC einen verlässlichen Partner.
<G-vec00205-002-s234><cope.kämpfen><en> The international community has to cope with many attacks.
<G-vec00205-002-s234><cope.kämpfen><de> Die internationale Gemeinschaft hat mit vielen Angriffen zu kämpfen.
<G-vec00205-002-s235><cope.kämpfen><en> Back in Europe I still have to cope with the weather.
<G-vec00205-002-s235><cope.kämpfen><de> Mit dem Wetter habe ich bis heute noch zu kämpfen.
<G-vec00205-002-s236><cope.kämpfen><en> Particularly older care staff often find it hard to cope with the physical strain and leave the profession before they reach retirement age even though they don’t actually want to.
<G-vec00205-002-s236><cope.kämpfen><de> Besonders ältere Pflegekräfte kämpfen oft mit den körperlichen Belastungen und scheiden vorzeitig aus dem Beruf aus, obwohl sie es eigentlich nicht wollen.
<G-vec00205-002-s246><cope.meistern><en> To cope with these challenges in the future, an economic, ecological, efficient and secure power supply through a holistic view of the involved processes is required.
<G-vec00205-002-s246><cope.meistern><de> Um in diesem Umfeld auch in Zukunft die Herausforderungen einer ökonomischen, ökologischen, effizienten und sicheren Energieversorgung zu meistern, bedarf es einer ganzheitlichen Betrachtung der an der Energieversorgung beteiligten Prozesse.
<G-vec00205-002-s247><cope.meistern><en> Depending on the number of people in the household, this amounts to a good 200,000 uses that the mixer tap has to cope with over the years.
<G-vec00205-002-s247><cope.meistern><de> Je nach Haushaltsgröße kommen so über die Jahre gut 200.000 Einsätze zusammen, die eine Mischbatterie zu meistern hat.
<G-vec00205-002-s248><cope.meistern><en> Freshness, strength and stamina are prerequisites to cope with the daily challenges.
<G-vec00205-002-s248><cope.meistern><de> Frische, Kraft und Ausdauer sind Voraussetzungen dafür, die täglichen Herausforderungen zu meistern.
<G-vec00205-002-s249><cope.meistern><en> I strongly identify with the company and the work of my predecessor, and this has helped me to cope with the challenges raised in the establishment of my own company.
<G-vec00205-002-s249><cope.meistern><de> Ich identifiziere mich stark mit dem Unternehmen und der Arbeit meines Vorgängers und dies hat mir geholfen, die Herausforderungen, die die Gründung einer eigenen Firma mit sich bringen, zu meistern.
<G-vec00205-002-s250><cope.meistern><en> While the complexity and the number of users have grown in recent years, thanks to CPCM, we have been able to cope with them without additional resources, and without piling up overtime day in day out.
<G-vec00205-002-s250><cope.meistern><de> In den letzten Jahren haben zwar sowohl die Komplexität als auch die Nutzerzahlen zugenommen, aber dank der Unterstützung durch MicroNova konnten wir beides ohne zusätzliche Ressourcen meistern – und ohne jeden Tag Überstunden anzuhäufen.
<G-vec00205-002-s251><cope.meistern><en> We want to provide our members with the best possible support in order to cope with this process.
<G-vec00205-002-s251><cope.meistern><de> Dabei möchten wir unseren Mitgliedern bestmögliche Hilfestellung leisten, damit sie diesen Prozess meistern.
<G-vec00205-002-s252><cope.meistern><en> As your direct contact persons in the field of tires and wheels we are ready and willing to help you cope with your day-to-day business.
<G-vec00205-002-s252><cope.meistern><de> Als direkte Ansprechpartner/innen im Bereich Reifen und Felgen stehen wir Ihnen gerne zur Verfügung, um gemeinsam das tägliche Geschäft zu meistern.
<G-vec00205-002-s253><cope.meistern><en> After all, the best social and employment protection they can offer a worker is to fight and help to ensure that the adoption of the tools that enable the worker to cope with the adversities of unemployment is successfully implemented.
<G-vec00205-002-s253><cope.meistern><de> Denn der beste soziale und beschäftigungsrelevante Schutz, den sie einem Arbeitnehmer anbieten können, ist, darum zu kämpfen und dazu beizutragen, dass die Aneignung der Werkzeuge, die den Arbeitnehmer in die Lage versetzen, die Widrigkeiten der Arbeitslosigkeit zu meistern, erfolgreich umgesetzt wird.
<G-vec00205-002-s254><cope.meistern><en> In order to cope with life they need physical, mental, emotional and spiritual strength.
<G-vec00205-002-s254><cope.meistern><de> Um das Leben zu meistern brauchen sie körperliche, geistige, emotionale und spirituelle Stärke.
<G-vec00205-002-s255><cope.meistern><en> Even schoolchildren will be able to cope with this task.
<G-vec00205-002-s255><cope.meistern><de> Auch Schüler werden diese Aufgabe meistern können.
<G-vec00205-002-s257><cope.meistern><en> Trust in ourselves to cope with the unknown.
<G-vec00205-002-s257><cope.meistern><de> Vertrauen in uns selbst, um das Ungewisse zu meistern.
<G-vec00205-002-s258><cope.meistern><en> By the end of the course, you'll be confident enough to cope with meetings and presentations, deal with business correspondence and present arguments successfully in French.
<G-vec00205-002-s258><cope.meistern><de> Nach dem Kurs sind Sie in der Lage, Meetings und Vorträge souverän zu meistern, geschäftlichen Schriftverkehr zu erledigen und erfolgreich auf Französisch zu argumentieren.
<G-vec00205-002-s259><cope.meistern><en> To help patients cope better with their often stressful life situations, playrooms, a roof garden and well-equipped lounges with flat screens and laptops should make their time in hospital as pleasant as possible.
<G-vec00205-002-s259><cope.meistern><de> Damit die Patienten ihre oftmals belastende Lebenssituation besser meistern können, sollen beispielsweise Spielzimmer, ein Dachgarten und gut ausgestattete Aufenthaltsräume mit Flatscreens und Laptops die Zeit im Krankenhaus so angenehm wie nur möglich machen.
<G-vec00205-002-s260><cope.meistern><en> A sensitive task like cleanroom cleaning requires experienced staff that know the procedures and challenges of cleanrooms and can cope with these with complete reliability.
<G-vec00205-002-s260><cope.meistern><de> Eine sensible Aufgabe wie die Reinraumreinigung erfordert versiertes Personal, das die Abläufe und Herausforderungen im Reinraum kennt und mit hundertprozentiger Zuverlässigkeit meistern kann.
<G-vec00205-002-s261><cope.meistern><en> The strength they draw from playing together helps them to cope with their everyday life.
<G-vec00205-002-s261><cope.meistern><de> Die Kraft, die sie aus dem gemeinsamen Spiel schöpfen, hilft ihnen, ihren Alltag zu meistern.
<G-vec00205-002-s262><cope.meistern><en> With the inlingua company service, your employees learn to cope with foreign language situations confidently and effortlessly.
<G-vec00205-002-s262><cope.meistern><de> Denn mit dem inlingua Firmenservice lernen Ihre Mitarbeiter, fremdsprachliche Situationen selbstbewusst und mühelos zu meistern.
<G-vec00205-002-s263><cope.meistern><en> Our weigh modules are designed to cope with such circumstances.
<G-vec00205-002-s263><cope.meistern><de> Unsere Wägemodule sind dafür konzipiert, solche Bedingungen im Handumdrehen zu meistern.
<G-vec00205-002-s265><cope.standhalten><en> Considerable reforms and investments are needed to enable it to cope over the long term with competitive pressure and market forces within the Union.
<G-vec00205-002-s265><cope.standhalten><de> Umfassende Reformen und erhebliche Investitionen sind erforderlich, damit das Land dem Wettbewerbsdruck und den Marktkräften innerhalb der Union langfristig standhalten kann.
<G-vec00205-002-s266><cope.standhalten><en> Zenith utilises special frame structures, which can cope very well with high vibration loading, for all its concrete block machines.
<G-vec00205-002-s266><cope.standhalten><de> Zenith verwendet für alle Betonsteinmaschinen spezielle Rahmenausführungen, die der sehr hohen Vibrationsbelastung sehr gut standhalten.
<G-vec00205-002-s267><cope.standhalten><en> The intelligent system architecture of FirstSpirit makes it possible to implement complex lottery portals that can also cope with future extensions.
<G-vec00205-002-s267><cope.standhalten><de> Durch die intelligente Systemarchitektur von FirstSpirit können komplexe Lotterieportale realisiert werden, die auch künftigen Erweiterungen standhalten.
<G-vec00205-002-s268><cope.standhalten><en> Curing systems must be able to cope with the heavy strains of everyday production.
<G-vec00205-002-s268><cope.standhalten><de> Härtungssysteme müssen harten Belastungen im Produktionsalltag standhalten.
<G-vec00205-002-s269><cope.standhalten><en> It should be able to cope with competitive pressures and market forces within the Union in the medium term, provided that it vigorously implements its reform programme in order to reduce significant structural weaknesses.
<G-vec00205-002-s269><cope.standhalten><de> Um dem Wettbewerbsdruck und den Marktkräften in der Union mittelfristig standhalten zu können, muss das Land sein Rechtssystem weiter reformieren und stärken und sein Reformprogramm zur Reduzierung der strukturellen Mängel umsetzen.
<G-vec00205-002-s270><cope.standhalten><en> Despite of all your efforts in the field of automation and maximum cost efficiency of manufactoring processes, you are not able to cope with cost pressure in Germany or Europe? - We can offer you our knowledge and skills in shifting your production to Eastern Europe and the Far East.
<G-vec00205-002-s270><cope.standhalten><de> Dort wo Sie alle Möglichkeiten der Automatisierung und Prozesskostenoptimierung ausgeschöpft haben und trotzdem dem Kostendruck in der Fertigung in Deutschland nicht standhalten können, sind wir Ihr Partner bei der Verlagerung in Länder in Osteuropa oder Fernost.
<G-vec00205-002-s271><cope.standhalten><en> When the block storage facility was no longer able to cope with the requirements of a modern business, the company opted to build a new automatic high-bay warehouse.
<G-vec00205-002-s271><cope.standhalten><de> Da das Blocklager den Anforderungen eines modernen Betriebes nicht mehr standhalten konnte, entschied man sich für den Neubau eines automatischen Hochregallagers.
<G-vec00205-002-s272><cope.stemmen><en> In the past, the entire group of companies has been able to cope with massive challenges that were happening from time to time and this is what makes us watch out for the future so positively.
<G-vec00205-002-s272><cope.stemmen><de> Die gesamte Unternehmensgruppe konnte in der Vergangenheit immer wieder enorme Herausforderungen stemmen und genau deshalb blicken wir sehr positiv in die Zukunft.
<G-vec00205-002-s273><cope.stemmen><en> With a general changeover to the 4-day week, the many small and medium-sized companies that characterise the German economic landscape would hardly be able to cope with such a wage compensation with reduced hours.
<G-vec00205-002-s273><cope.stemmen><de> Bei einer generellen Umstellung auf die 4-Tage-Woche könnten die vielen kleinen und mittelständischen Unternehmen, die die deutsche Wirtschaftslandschaft prägen einen solchen Lohnausgleich bei Stundenreduzierung jedoch wohl kaum stemmen.
<G-vec00205-002-s274><cope.stemmen><en> That starts with the raw material and ends with expert, long-standing partners who can even cope with exceptional capacity requirements together with us.
<G-vec00205-002-s274><cope.stemmen><de> Das beginnt beim Rohmaterial und endet bei kompetenten, langjährigen Partnern, die gemeinsam mit uns auch ausgefallene Kapazitätsanforderungen stemmen.
<G-vec00205-002-s275><cope.stemmen><en> In the meantime, the rotation has become a necessary standard, which is the only way for a team to cope with the heavy workload in today’s schedule with a much more intensive playing style.
<G-vec00205-002-s275><cope.stemmen><de> Mittlerweile ist die Rotation zum notwendigen Standard geworden, nur so kann eine Mannschaft die Dreifachbelastung in der heutigen Zeit mit deutlich intensiverer Spielweise noch stemmen.
<G-vec00205-002-s110><cope.umgehen><en> With education comes understanding and an increased ability to cope.
<G-vec00205-002-s110><cope.umgehen><de> Mit dem Wissen kommt Verständnis und eine bessere Fähigkeit, damit umzugehen.
<G-vec00205-002-s111><cope.umgehen><en> Specialists write fairy tales that help children discover emotions in themselves, learn to understand and cope with them.
<G-vec00205-002-s111><cope.umgehen><de> Spezialisten schreiben Märchen, die Kindern helfen, Emotionen in sich selbst zu entdecken, zu verstehen und damit umzugehen.
<G-vec00205-002-s112><cope.umgehen><en> The degree of imbalance due to nervous shock depends on how stress is perceived and how to cope with it.
<G-vec00205-002-s112><cope.umgehen><de> Der Grad des Ungleichgewichts aufgrund eines Nervenschocks hängt davon ab, wie Stress wahrgenommen wird und wie damit umzugehen ist.
<G-vec00205-002-s113><cope.umgehen><en> Simple thoughts will remain for a while until mankind will have learned how to cope with them.
<G-vec00205-002-s113><cope.umgehen><de> Einfache Gedanken bleiben eine Weile, bis der Menschen lernt damit umzugehen.
<G-vec00205-002-s114><cope.umgehen><en> It is very difficult to cope with it on your own, so it is also better to consult a specialist.
<G-vec00205-002-s114><cope.umgehen><de> Es ist sehr schwierig, alleine damit umzugehen, daher ist es auch besser, einen Spezialisten zu konsultieren.
<G-vec00205-002-s360><cope.verkraften><en> Physical stress as an example is the “wear and tear” on the body, which the body cannot cope with.
<G-vec00205-002-s360><cope.verkraften><de> Körperlicher Stress als Beispiel ist die “Abnutzung” des Körpers, die der Körper nicht verkraften kann.
<G-vec00205-002-s361><cope.verkraften><en> Of course, it actually is a lot – and I have to cope with even more than before because these matters are very hard.
<G-vec00205-002-s361><cope.verkraften><de> Natürlich, es ist wirklich sehr viel – und zu verkraften habe ich noch mehr als früher, denn diese Dinge sind ganz besonders hart.
<G-vec00205-002-s362><cope.verkraften><en> The term “resilience” originated from biology, referring to how organisms cope with ecological stress.
<G-vec00205-002-s362><cope.verkraften><de> Der Begriff Resilienz stammt aus der Biologie und beschreibt die Fähigkeit von Organismen oder Ökosystemen, externe Störungen zu verkraften.
<G-vec00205-002-s363><cope.verkraften><en> Due to overcapacities and poor cost focus, weaker traditional airlines are more unlikely to be able to cope with high energy prices.
<G-vec00205-002-s363><cope.verkraften><de> Die angeschlagenen traditionellen Fluggesellschaften dürften auf Grund von Überkapazitäten und schlechtem Kostenmanagement größte Mühe bekunden, die hohen Energiepreise zu verkraften.
<G-vec00205-002-s364><cope.verkraften><en> This continuous burden, however, is not one every servant of the Lord can cope with bodily or mentally.
<G-vec00205-002-s364><cope.verkraften><de> Diese Dauerbelastung kann jedoch nicht jeder Diener des Herrn körperlich und seelisch verkraften.
<G-vec00205-002-s365><cope.verkraften><en> own life is insane, because the human is not able to cope with this truth.
<G-vec00205-002-s365><cope.verkraften><de> Die wirkliche Wahrheit der Zukunft des eigenen Lebens zu kennen ist Wahnsinn, denn der Mensch vermag diese Wahrheit nicht zu verkraften.
<G-vec00205-002-s367><cope.verkraften><en> Given that the Eastern Bloc states could barely cope with the required investments in high technology, and that even constructing a conventional tank required twice the effort – Soviet labour productivity being half that of the United States – the economic defeat of actually-existing socialism was already on the horizon years before the eventual collapse.
<G-vec00205-002-s367><cope.verkraften><de> Da die Oststaaten die Investitionen in Hochtechnologie kaum verkraften konnten und auch der Bau jedes konventionellen Panzers und jedes Flugzeugs den doppelten Aufwand erforderte, war die ökonomische Niederlage des real existierenden Sozialismus erwartbar.
<G-vec00205-002-s368><cope.verkraften><en> According to the government there are more of these animals than the country can cope with.
<G-vec00205-002-s368><cope.verkraften><de> Denn laut Regierung gibt es inzwischen mehr dieser Raubtiere, als das Land verkraften kann.
<G-vec00205-002-s369><cope.verkraften><en> It is true, I was still very young at that time, just 11 years old, and it was my own wish that Sfath let me see what I had lived through, but I was already able to cope with it well then, but I really couldn't accept it, and indeed not to this day, because killing defenceless people, as is also the case with the statutory death penalty, means nothing more and nothing less than a murderous slaughter.
<G-vec00205-002-s369><cope.verkraften><de> Es stimmt, damals war ich noch sehr jung, gerademal 11 Jahre alt, und es war mein eigener Wunsch, dass mich Sfath das Erlebte schauen ließ, doch ich konnte es schon damals gut verkraften, doch eben akzeptieren konnte ich es nicht, und zwar bis heute nicht, denn Wehrlose zu töten, wie das auch bei der gesetzlichen Todesstrafe der Fall ist, bedeutet nichts mehr und nichts weniger, als ein mörderisches Abschlachten.
<G-vec00205-002-s370><cope.verkraften><en> Now you don’t rush to drink that little container of milk because your constitution would not be able to cope with it.
<G-vec00205-002-s370><cope.verkraften><de> Nun beeilst du dich nicht, diesen kleinen Becher Milch zu trinken, weil deine Konstitution das nicht verkraften würde.
<G-vec00205-002-s371><cope.verkraften><en> Some banks would not be able to cope with that, so there would have to be new aid programs.
<G-vec00205-002-s371><cope.verkraften><de> Das würden einige Banken nicht verkraften, also müsste es neue Hilfsprogramme geben.
<G-vec00205-002-s372><cope.verkraften><en> In view of the volume of Greek government bonds in April 2010, the banks concerned probably would have been able to cope had the bonds failed.
<G-vec00205-002-s372><cope.verkraften><de> Angesichts des im April 2010 zur Debatte stehenden Volumens griechischer Staatsanleihen, die hätten ausfallen können, wäre dies für die beteiligten Banken wahrscheinlich zu verkraften gewesen.
<G-vec00205-002-s373><cope.verkraften><en> There are other students who are in a similar situation as you who also have to cope with the death of a parent.
<G-vec00205-002-s373><cope.verkraften><de> Es gibt andere Studierende, die in einer ähnlichen Situation wie Sie sind, die auch den Tod eines Elternteils verkraften müssen.
<G-vec00205-002-s374><cope.verkraften><en> With a high level of species or genetic diversity, ecosystems can cope much better with this change.
<G-vec00205-002-s374><cope.verkraften><de> Mit einer hohen Arten- oder genetischen Vielfalt können sie diesen Wandel viel besser verkraften.
<G-vec00205-002-s375><cope.verkraften><en> The idea is as of a wooden house like a "piece of furniture " – from pine and beech wood, i.e. those species of trees that are becoming more and more important in German forests, because they cope better with the local temperature rise of global climate change.
<G-vec00205-002-s375><cope.verkraften><de> Vorgesehen ist ein Holzhaus wie ein „großes „Möbelstück“ – aus Tannen- und Buchenholz, also solchen Bäumen, die zukünftig in deutschen Wäldern an Bedeutung zunehmen, weil sie den Temperaturanstieg durch den Klimawandel gut verkraften.
<G-vec00205-002-s376><cope.verkraften><en> Despite their small dimensions, wheel bearings have to cope with significant load changes.
<G-vec00205-002-s376><cope.verkraften><de> So müssen Radlager auf kleinster Fläche große Lastwechsel verkraften.
<G-vec00205-002-s377><cope.verkraften><en> However, this mass of humanity means that, in every regard, ever more means are required for humanity's daily requirement and for the obtaining of energy than nature, and the planet, with its resources and the atmosphere, is able to cope with.
<G-vec00205-002-s377><cope.verkraften><de> Diese Masse Menschheit bedeutet aber, dass in jeder Beziehung immer mehr Mittel für den menschheitlich täglichen Bedarf und für die Energiegewinnung erforderlich sind, als die Natur und der Planet mit seinen Ressourcen und der Atmosphäre zu verkraften vermag.
<G-vec00205-002-s189><cope.wachsen><en> I gave up various jobs because I couldn’t cope with the demands.
<G-vec00205-002-s189><cope.wachsen><de> Verschiedene Arbeitsstellen gab ich auf, weil ich den Anforderungen nicht gewachsen war.
<G-vec00205-002-s190><cope.wachsen><en> If you're still afraid that your beloved plants won't be able to cope with the heat, grab the latest interior hit: the crochet cactus.
<G-vec00205-002-s190><cope.wachsen><de> Und wer jetzt immer noch Angst davor hat, dass die geliebten Pflanzen der Hitze nicht gewachsen sind, greift einfach zum neuesten Interior-Hit: dem Häkelkaktus.
<G-vec00205-002-s191><cope.wachsen><en> Electricity networks in scarcely populated rural regions must be able to cope simultaneously with the small local requirements and continual increase in decentralised electricity generation.
<G-vec00205-002-s191><cope.wachsen><de> Stromnetze in dünn besiedelten ländlichen Regionen müssen gleichzeitig einem geringen örtlichen Bedarf und einer weiter steigenden dezentralen Einspeisung gewachsen sein.
<G-vec00205-002-s192><cope.wachsen><en> He himself can not cope with his mood for the time being.
<G-vec00205-002-s192><cope.wachsen><de> Er selbst wird seiner Stimmung vorerst nicht gewachsen sein.
<G-vec00205-002-s193><cope.wachsen><en> In southern Upper Swabia, where milk was in abundance, small village dairies had previously processed their own milk but were unable to cope with the requirements of nationwide commercialization.
<G-vec00205-002-s193><cope.wachsen><de> Zuvor wurde im milchreichen südlichen Oberschwaben die Milch in kleinen Dorfmolkereien verarbeitet, die den Anforderungen an eine überregionale Vermarktung nicht gewachsen waren.
<G-vec00205-002-s194><cope.wachsen><en> Between all of this, new interdependencies are constantly emerging, so that responsibility in a company and for a company not only requires an almost limitless expansion of the field of vision, but also the ability and willingness to cope with the ever-increasing complexity of the situation.
<G-vec00205-002-s194><cope.wachsen><de> Zwischen all dem entstehen ständig neue Verflechtungen, so dass Verantwortung in einem Unternehmen und für ein Unternehmen nicht nur eine beinahe grenzenlose Ausweitung des Blickfeldes erfordert, sondern auch die Fähigkeit und Bereitschaft, der zunehmenden Komplexität gewachsen zu sein.
<G-vec00205-002-s195><cope.wachsen><en> It signals: I can no longer cope, I am losing my (previous) sovereignty, my assurance in what I am and what I do.
<G-vec00205-002-s195><cope.wachsen><de> Es signalisiert: Ich bin dem nicht mehr gewachsen, verliere meine (alte) Souveränität, Daseins- und Verhaltenssicherheit.
<G-vec00205-002-s196><cope.wachsen><en> The Scan Handles are resistant to drops and temperature fluctuations and are thus able to cope particularly with harsh environmental conditions.
<G-vec00205-002-s196><cope.wachsen><de> Die Scan Handles widerstehen Stürzen und Temperaturschwankungen und sind damit auch besonders rauen Umgebungsbedingungen gewachsen.
<G-vec00205-002-s197><cope.wachsen><en> With a service life of 20 years and the ability to update the firmware on the chip, the TPM is able to cope with long-term security risks that may be encountered in an industrial environment.
<G-vec00205-002-s197><cope.wachsen><de> Mit einer Lebensdauer von 20 Jahren und der Updatefähigkeit der Firmware auf dem Chip, ist das TPM langfristigen Sicherheitsrisiken, die im industriellen Umfeld auftreten können, gewachsen.
<G-vec00205-002-s198><cope.wachsen><en> There were too long distances between all the departments and the workshop could no longer cope with the volume of work.
<G-vec00205-002-s198><cope.wachsen><de> Es gab zu lange Wege zwischen den Abteilungen, und die Werkstatt war dem Volumen nicht mehr gewachsen.
<G-vec00205-002-s199><cope.wachsen><en> Transcendence as a metaphysical concept appears as a universal code of ethics, a norm of behavior, a value to cope with.
<G-vec00205-002-s199><cope.wachsen><de> Als metaphysische Vorstellung erscheint Transzendenz als universeller ethischer Kodex, als Verhaltensnorm ein bestimmter Wert, dem der Mensch sich gewachsen zeigen muss.
<G-vec00205-002-s200><cope.wachsen><en> Many of the oil binding products currently on the market are unable to cope with external influences: granular absorption agents, for instance, can be carried away by wind and water.
<G-vec00205-002-s200><cope.wachsen><de> Viele heute auf dem Markt erhältliche Ölbinder sind äußeren Einflüssen nicht gewachsen; granulare Absorptionsmittel können durch Wind und Wasser mitgerissen werden.
<G-vec00205-002-s201><cope.wachsen><en> These are cost-intensive and cannot fully cope with the challenges of modern banking.
<G-vec00205-002-s201><cope.wachsen><de> Sie sind kostenintensiv und den Herausforderungen des modernen Bankgeschäftes nur unzureichend gewachsen.
<G-vec00205-002-s202><cope.wachsen><en> With SAP HCM you can cope with the world’s increasing legal requirements and boost the efficiency of your HR department.
<G-vec00205-002-s202><cope.wachsen><de> Durch SAP HCM sind Sie den weltweit steigenden rechtlichen Anforderungen gewachsen und steigern die Effizienz Ihrer Personalabteilung.
<G-vec00205-002-s203><cope.wachsen><en> And to cope with all weather fluctuations, the Aletsch Arena is equipped with 260 snowmaking systems, which can supply 62% of the ski area with snow.
<G-vec00205-002-s203><cope.wachsen><de> Und um allen Wetterschwankungen gewachsen zu sein, ist die Aletsch Arena mit 260 Beschneiungsanlagen ausgestattet, die 62 % des Skigebiets mit Schnee versorgen können.
<G-vec00205-002-s204><cope.wachsen><en> Digital cameras simply can't cope with the very intensive interplay of light and shadow.
<G-vec00205-002-s204><cope.wachsen><de> Dem dann besonders intensiven Licht- und Schattenspiel sind handelsübliche Digitalkameras einfach nicht gewachsen.
<G-vec00205-002-s205><cope.wachsen><en> Cities in Viet Nam overly rely on drainage systems that are not able to cope with the rapid urban development.
<G-vec00205-002-s205><cope.wachsen><de> Die Städte verlassen sich allzu sehr auf Entwässerungssysteme, die der schnellen Stadtentwicklung nicht gewachsen sind.
<G-vec00205-002-s206><cope.wachsen><en> We reach the city via an old lifting bridge, which is no longer able to cope with traffic.
<G-vec00205-002-s206><cope.wachsen><de> Wir erreichen die Stadt über eine alte Hubbrücke, die dem Verkehr nicht mehr gewachsen ist.
<G-vec00205-002-s207><cope.wachsen><en> Unfortunately, I am no longer able to cope with the time constraints, which means that I want to put it in good hands.
<G-vec00205-002-s207><cope.wachsen><de> Leider bin ich der zeitlichen Belastung nicht mehr gewachsen, wodurch ich ihn in gute Hände abgeben möchte.
<G-vec00205-002-s170><cope.werden><en> Greece, which ever since 2010 has been struggling immensely to deal with its own financial crisis, cannot cope with the more than 100'000 refugees and migrants in the country.
<G-vec00205-002-s170><cope.werden><de> Griechenland, das seit 2010 massiv mit der Finanzkrise zu kämpfen hat, kann den über 100 000 Flüchtlingen, Migrantinnen und Migranten nicht gerecht werden.
<G-vec00205-002-s171><cope.werden><en> In order to cope with our international customers it was decided to have everything in English language which is not trilingual.
<G-vec00205-002-s171><cope.werden><de> Um unseren internationalen Kunden gerecht zu werden, wurde alles was bisher nicht 3-sprachig verfügbar war nun in englischer Sprache abgebildet.
<G-vec00205-002-s172><cope.werden><en> In order to cope with them, VISUS has integrated a resource planner for on-call duty into its system.
<G-vec00205-002-s172><cope.werden><de> Um diesen gerecht zu werden, hat VISUS einen Dienstplaner für Bereitschaftsdienste in sein System integriert.
<G-vec00205-002-s173><cope.werden><en> To adequately cope with the various issues that people come to us with, we offer different types of counselling.
<G-vec00205-002-s173><cope.werden><de> Um den unterschiedlichen Problemstellungen, mit denen Ratsuchende zu uns kommen, angemessen gerecht zu werden, bieten wir unterschiedliche Beratungsformen an.
<G-vec00205-002-s174><cope.werden><en> NEXT SUBline SUBline carp mono has been specifically designed by Team Korda to cope with all extreme fishing requirements.
<G-vec00205-002-s174><cope.werden><de> NEXT SUBline SUBline Karpfenschnur ist speziell durch das Team Korda entwickelt worden, um alle Anforderungen bei extremen Angelsituationen gerecht zu werden.
<G-vec00205-002-s175><cope.werden><en> Trying to cope with the dizziness from high technology, we have come back to appreciate all natural – our food, clothing, shelter.
<G-vec00205-002-s175><cope.werden><de> In einem Versuch, dem Schwindel von den Hochtechnologien gerecht zu werden, beginnen wir wiederum alles Natürliche zu schätzen: Nahrung, Kleidung, Wohnen.
<G-vec00205-002-s176><cope.werden><en> To cope with ever-growing data volume, we don’t need to introduce any changes to the software each time the amount of data increases.
<G-vec00205-002-s176><cope.werden><de> Um dem ständig wachsenden Datenvolumen gerecht zu werden, müssen wir bei jeder Erhöhung der Datenmenge keine Änderungen an der Software vornehmen.
<G-vec00205-002-s177><cope.werden><en> All products and processes within our company are adjusted to cope with this high standard.
<G-vec00205-002-s177><cope.werden><de> Sämtliche Produkte und Prozesse innerhalb unseres Unternehmens sind darauf abgestimmt diesem hohen Anspruch gerecht zu werden.
<G-vec00205-002-s178><cope.werden><en> Humankind has to cope with this fate of having spirit.
<G-vec00205-002-s178><cope.werden><de> Die Menschheit muss sich dem Schicksal, den Geist zu haben, stellen und ihm gerecht werden.
<G-vec00205-002-s179><cope.werden><en> And so we witness his swift ascent against the opposition of his besotted parents, against the school and every educational institute unable to cope with his extreme talent, against everything which was there before him and fails to give him unconditional love, against everything that is not on his side and refuses to grant him unlimited power, against the rest of a world which is majorly out of... but we’ve had that already.
<G-vec00205-002-s179><cope.werden><de> Und so erleben wir seinen rasanten Aufstieg, gegen den Widerstand seiner hingerissenen Eltern, gegen die Schule und alle Bildungsinstitutionen, die seiner Höchstbegabung nicht gerecht werden können, gegen alles, was vor ihm da war und ihn nicht bedingungslos liebt, gegen alles, was nicht für ihn ist und sich weigert, ihn mit grenzenloser Macht auszustatten, gegen den Rest einer Welt, die aus den Fugen – aber das hatten wir schon.
<G-vec00205-002-s180><cope.werden><en> However, this isn’t enough to cope with the specific aspects of the mobile domain.
<G-vec00205-002-s180><cope.werden><de> Doch dies genügt nicht mehr, um den Besonderheiten der mobilen Welt gerecht zu werden.
<G-vec00205-002-s181><cope.werden><en> An innovative tyre design with good grip to cope with the higher power output and speeds of fast e-bikes.
<G-vec00205-002-s181><cope.werden><de> Ein innovatives Reifendesign mit gutem Grip, um der höheren Leistung von S-Pedelecs gerecht zu werden.
<G-vec00205-002-s182><cope.werden><en> It documents the failings of state police forces that operate outside the law, lack sufficient ethical and professional standards, are overstretched and outmatched by criminal elements, and unable to cope with increasing demands and public expectations.
<G-vec00205-002-s182><cope.werden><de> Der Bericht beschreibt das Verhalten von Polizeikräften, die außerhalb des Gesetzes mit ungenügenden ethischen und professionellen Richtlinien arbeiten, kriminellem Einfluss unterliegen und den steigenden Anforderungen und öffentlichen Erwartung nicht gerecht werden können.
<G-vec00205-002-s183><cope.werden><en> They must give fresh heart to each other and give courage; united they must ask for my help and expect it believingly; every opportunity they must use to hear my word, to practise love and to commune with me intimately, so that they again and again can go strengthened to the dayís work and cope with the demands of the world, as far as they cannot be avoided.
<G-vec00205-002-s183><cope.werden><de> Sie müssen einander aufrichten und sich Mut zusprechen, sie müssen vereint Meine Hilfe erbitten und gläubig erwarten, sie müssen sich jede Gelegenheit zunutze machen, Mein Wort zu hören, die Liebe zu üben und innere Zwiesprache zu halten mit Mir, auf daß sie immer wieder gekräftigt an ihr Tagewerk gehen können und den Anforderungen der Welt gerecht werden, soweit sie nicht umgangen werden können.
<G-vec00205-002-s185><cope.werden><en> To cope with all aspects of these research topics, the RA is supported and carried by scientists of 7 chairs of the University of Hagen.
<G-vec00205-002-s185><cope.werden><de> Um allen Aspekten dieser Forschung gerecht zu werden, wird dieser Forschungsschwerpunkt durch Wissenschaftler von 7 Lehrgebieten der FernUniversität in Hagen unterstützt und getragen.
<G-vec00205-002-s186><cope.werden><en> Competitiveness can only be guaranteed if the staff can cope with all factors.
<G-vec00205-002-s186><cope.werden><de> Wettbewerbsfähigkeit kann nur gewährleistet werden, wenn die Mitarbeiter allen Faktoren gerecht werden können.
<G-vec00205-002-s187><cope.werden><en> In order to cope the increasing mobility requirements in industry and trade, GEDORE offers with its WorkMo® system a flexible solution for a safe and fast transport.
<G-vec00205-002-s187><cope.werden><de> Um den steigenden Mobilitätsansprüchen in Industrie und Handwerk gerecht zu werden, bietet GEDORE mit seinem WorkMo® System eine flexible Lösung für den sicheren und schnellen Transport an.
<G-vec00205-002-s188><cope.werden><en> The inadequate sound-proofing properties of glass could no longer cope with this level of noise.
<G-vec00205-002-s188><cope.werden><de> Die unzureichenden schalldämmenden Eigenschaften von Glas konnten derartigen akustischen Anforderungen nicht mehr gerecht werden.
<G-vec00205-002-s295><cope.zurechtkommen><en> To cope with the harsh environmental conditions on the silo roof, the plumb bob offers an aluminium housing with protection IP66.
<G-vec00205-002-s295><cope.zurechtkommen><de> Um mit den rauen Umgebungsbedingungen auf dem Silodach zurechtzukommen, ist das Lotmessgerät in einem Aluminium-Gehäuse der Schutzart IP66 untergebracht.
<G-vec00205-002-s296><cope.zurechtkommen><en> They must be accurately calibrated and have a wide dynamic range (60 to 100 dBs or more) to cope with light rain at long-range and heavy rain near to the radar site.
<G-vec00205-002-s296><cope.zurechtkommen><de> Sie müssen deshalb genau geeicht werden und einen breiten dynamischen Bereich (60 bis 100 dB oder mehr) überstreichen, um sowohl mit leichtem Regen in großer Entfernung als auch mit starkem Regen im Nahbereich zurechtzukommen.
<G-vec00205-002-s298><cope.zurechtkommen><en> My approach is to assume that everyone is just doing their best to cope and to survive.
<G-vec00205-002-s298><cope.zurechtkommen><de> Mein Ansatz lautet: Jeder unternimmt sein Bestes, um zurechtzukommen und zu überleben.
<G-vec00205-002-s299><cope.zurechtkommen><en> European countries will need to strengthen and adapt their health services to cope with the potential impacts of climate change in their area.
<G-vec00205-002-s299><cope.zurechtkommen><de> Die europäischen Länder müssen ihre Gesundheitsdienste stärken und anpassen, um mit den möglichen Auswirkungen des Klimawandels in diesem Bereich zurechtzukommen.
<G-vec00205-002-s474><cope.überfordern><en> If certain micronutrients such as vitamins, minerals, trace elements are permanently lacking in our diet, the immune system cannot perform properly anymore and is unable to cope.
<G-vec00205-002-s474><cope.überfordern><de> Fehlen bestimmte Mikronährstoffe wie Vitamine, Mineralstoffe, Spurenelemente dauerhaft in unserer Nahrung, so kann das Immunsystem nicht mehr genug leisten und reagiert überfordert.
<G-vec00205-002-s475><cope.überfordern><en> The wind vane now is unable to cope with.
<G-vec00205-002-s475><cope.überfordern><de> Die Windsteueranlage ist nun überfordert.
<G-vec00205-002-s476><cope.überfordern><en> For the DEKRA product experts, the result of this random sampling is a sign that the supply chain often struggles to cope with the notification duties under REACH.
<G-vec00205-002-s476><cope.überfordern><de> Für die Produktexperten von DEKRA ist diese Stichprobe ein Zeichen, dass die Lieferkette mit den Auskunftspflichten nach REACH häufig überfordert ist.
<G-vec00205-002-s477><cope.überfordern><en> Charitable organisations like the Red Cross or Caritas can barely cope.
<G-vec00205-002-s477><cope.überfordern><de> Hilfsorganisationen wie das Rote Kreuz oder die Caritas sind restlos überfordert.
<G-vec00205-002-s478><cope.überfordern><en> Given their significant budget deficits, many countries are unable to cope and are looking for alternative financing solutions in order to implement their infrastructure projects.
<G-vec00205-002-s478><cope.überfordern><de> Angesichts erheblicher Haushaltsdefizite sind viele Länder hier überfordert und suchen nach alternativen Finanzierungslösungen bei der Umsetzung ihrer Infrastrukturprojekte.
<G-vec00205-002-s479><cope.überfordern><en> Desiree was just talked into taking over the ex-wives restaurant and is completely unable to cope.
<G-vec00205-002-s479><cope.überfordern><de> Desiree hat sich breitschlagen lassen, das Restaurant der Exfrau zu übernehmen und ist völlig überfordert.
<G-vec00205-002-s480><cope.überfordern><en> Although he was very confused and unable to cope with the new situation, he gets used to it and the fact that he was snapped out of his normal life, which has already bored him for a while.
<G-vec00205-002-s480><cope.überfordern><de> Anfänglich etwas überfordert mit seiner neuen Situation lebt er sich schnell ein und ist eher über den Umstand erfreut, dass er aus dem Alltag seiner Heimat gerissen wurde, welcher ihm schon seit einiger Zeit die Nerven raubte.
<G-vec00205-002-s481><cope.überfordern><en> Both Mali and Niger, unable to cope economically with famine, and plagued by weak, authoritarian governments, faced dissent in all communities.
<G-vec00205-002-s481><cope.überfordern><de> In Mali und im Niger waren die autoritären aber schwachen Regierungen wirtschaftlich mit den Hungersnöten überfordert, was zu hoher Aufregung in den Gemeinden der Länder führte.
<G-vec00205-002-s482><cope.überfordern><en> Unable to cope, too, Isabel was forced to leave her country in 1868 as a result of a revolt.
<G-vec00205-002-s482><cope.überfordern><de> Auch Isabella war überfordert und musste 1868 auf Grund eines Aufstands ihr Land verlassen.
<G-vec00205-002-s483><cope.überfordern><en> Trying to lip read what was said is futile, as ear and brain are not able to cope with the complex acoustic environment.
<G-vec00205-002-s483><cope.überfordern><de> Krampfhaft versucht mancher aus den Lippenbewegungen das Gesprochene abzulesen - umsonst, Gehör und Gehirn sind in dieser akustischen Umgebung überfordert.
<G-vec00205-002-s484><cope.überfordern><en> “[The refugee deal] was never a pretty thing, but it had several advantages: it was practical because the EU member states clearly couldn't cope with their own outer borders.
<G-vec00205-002-s484><cope.überfordern><de> „Schön war [der Flüchtlingsdeal] nie, aber es sprach einiges dafür: Praktische Gründe, weil die EU-Mitgliedsstaaten mit ihren eigenen Außengrenzen definitiv überfordert waren.
<G-vec00205-002-s485><cope.überfordern><en> Many aid organizations are unable to cope because of a lack of financial support for the people in need.
<G-vec00205-002-s485><cope.überfordern><de> Viele Hilfsorganisationen sind überfordert, weil es an finanzieller Unterstützung für die Notleidenden fehlt.
<G-vec00719-002-s032><cope.bewältigen><en> Obviously we cannot cope with this task alone.
<G-vec00719-002-s032><cope.bewältigen><de> Diese Aufgabe können wir nicht allein bewältigen.
<G-vec00719-002-s033><cope.bewältigen><en> Furthermore, although the transmitting side and the receiving side can use either the same address or different addresses depending on a transmission method, this is reduced to a matter of whether the transmitting side and the receiving side manage the table commonly or independently, either of which the present embodiment can cope with.
<G-vec00719-002-s033><cope.bewältigen><de> Obwohl die übertragende Seite und die empfangende Seite abhängig von einem Übertragungsverfahren entweder die gleiche Adresse oder unterschiedliche Adressen verwenden können, wird dies außerdem auf eine Angelegenheit reduziert, ob die übertragende Seite und die empfangende Seite die Tabelle gemeinsam oder unabhängig voneinander verwalten, wobei das vorliegende Ausführungsbeispiel beide bewältigen kann.
<G-vec00719-002-s034><cope.bewältigen><en> That's really hard to cope with, because I tend to get carried away by it, and end up being hurt myself.
<G-vec00719-002-s034><cope.bewältigen><de> Es ist wirklich schwer, dies zu bewältigen, weil ich dazu neige, es mit mir mitzutragen und es endet damit, daß ich mir selbst wehtue.
<G-vec00719-002-s035><cope.bewältigen><en> We can only cope with these challenges if we work closely with new and existing suppliers.
<G-vec00719-002-s035><cope.bewältigen><de> Diese können wir nur erfolgreich bewältigen, wenn wir eng mit neuen und bestehenden Zulieferern zusammenarbeiten.
<G-vec00719-002-s036><cope.bewältigen><en> Because of ignorance, novice athletes begin to make themselves cocktails from a gainer to help the body, as they think, cope with the loads it receives during exercise.
<G-vec00719-002-s036><cope.bewältigen><de> Aus Unwissenheit beginnen sich Anfänger-Athleten selbst Cocktails von einem Gewinner zu machen, der dem Körper dabei hilft, die Belastungen zu bewältigen, die er während des Trainings erhält.
<G-vec00719-002-s037><cope.bewältigen><en> So, it helped me cope.
<G-vec00719-002-s037><cope.bewältigen><de> Also, sie hat mir geholfen zu bewältigen.
<G-vec00719-002-s038><cope.bewältigen><en> That is, simple and light structures such as garages and old buildings, which have been created in brick construction are to cope with it.
<G-vec00719-002-s038><cope.bewältigen><de> Das heißt, einfache und leichte Bauwerke wie Garagen und alte Gebäude, welche in Ziegelbauweise erstellt worden sind, sind damit zu bewältigen.
<G-vec00719-002-s039><cope.bewältigen><en> Thus, the use of milk, dairy products and commonly available products, such as iodine or hydrogen peroxide, allows you to cope with many problems in growing cucumbers and get a good harvest.
<G-vec00719-002-s039><cope.bewältigen><de> Fazit Durch die Verwendung von Milch, Milchprodukten und allgemein erhältlichen Produkten wie Jod oder Wasserstoffperoxid können Sie viele Probleme beim Anbau von Gurken bewältigen und eine gute Ernte erzielen.
<G-vec00719-002-s040><cope.bewältigen><en> 'Blue Design' A balancing gives us energy to cope with the increasingly hectic daily lives quietly and calmly.
<G-vec00719-002-s040><cope.bewältigen><de> Eine ausgleichende Energie vermittelt uns 'Blue Design', um den zunehmend hektischen Alltag ruhig und gelassen zu bewältigen.
<G-vec00719-002-s041><cope.bewältigen><en> Your body doesn't do this to make you look sexy, it does it as a response to the stress of the workout, so it can cope more easily next time.
<G-vec00719-002-s041><cope.bewältigen><de> Ihr Körper tut dies nicht, um Sie gut aussehen zu lassen, sondern als eine Reaktion auf den Stress des Trainings, sodass er diesen Stress beim nächsten Mal leichter bewältigen kann.
<G-vec00719-002-s042><cope.bewältigen><en> Bicycle rides on retired train rails, along rivers, through the pretty High Fens or the national park Eifel: All these paths have a manageable length, the inclines are easy to cope with and next to the paths there is a lot to discover and experience.
<G-vec00719-002-s042><cope.bewältigen><de> Radtouren auf stillgelegten Bahntrassen, entlang von Flüssen, durch das schöne Hohe Venn oder den Nationalpark Eifel: All diese Wege sind von der Länge her überschaubar, von den Anstiegen her leicht zu bewältigen und links und rechts der Wege gibt es viel zu entdecken und zu erleben.
<G-vec00719-002-s043><cope.bewältigen><en> Two front hydraulic couplers provide hydraulic service for implements and, with an overall lift capacity of just over 5,000 kg, the MF 8600 Series tractor will cope admirably with heavy-duty applications.
<G-vec00719-002-s043><cope.bewältigen><de> Die zwei optionalen Fronthydraulikkupplungen dienen der hydraulischen Versorgung der Frontarbeitsgeräte, und mit einer Hubkraft von knapp über 5000 kg bewältigen die Traktoren der Baureihe MF 8600 auch anspruchsvolle Anwendungen mühelos.
<G-vec00719-002-s044><cope.bewältigen><en> In addition, there are many lines of medical cosmetics that can easily cope with similar problems.
<G-vec00719-002-s044><cope.bewältigen><de> Darüber hinaus gibt es viele Linien von medizinischen Kosmetika, die ähnliche Probleme leicht bewältigen können.
<G-vec00719-002-s045><cope.bewältigen><en> We even had to postpone some appointments to next week as in-house collection presentations since we were unable to cope with the sheer numbers.
<G-vec00719-002-s045><cope.bewältigen><de> Einige Termine mussten wir gar als Hausvorlage auf die nächste Woche verschieben, da wir den Andrang nicht bewältigen konnten.
<G-vec00719-002-s046><cope.bewältigen><en> This challenge could only by immigration from the outside to cope with, according to the authors.
<G-vec00719-002-s046><cope.bewältigen><de> Diese Herausforderung lasse sich nur durch Einwanderung von außen bewältigen, so die Autoren.
<G-vec00719-002-s047><cope.bewältigen><en> I also use social media to help me cope with my chronic illness.
<G-vec00719-002-s047><cope.bewältigen><de> Ich benutze social media auch dafür, mir zu helfen meine Krankheit zu bewältigen.
<G-vec00719-002-s048><cope.bewältigen><en> The car parks of hotels and exhibition centres have to be able to cope with a large number of possible usage needs, often round the clock.
<G-vec00719-002-s048><cope.bewältigen><de> Hotels und Veranstaltungszentren Besonders gastfreundlich Die Parkanlagen von Hotels und Veranstaltungszentren haben eine Vielzahl von Nutzungswünschen, oft rund um die Uhr, zu bewältigen.
<G-vec00719-002-s049><cope.bewältigen><en> The EU should convene a humanitarian conference aimed at helping Syria's neighbouring countries to cope with the still-growing influx of refugees, said the European Parliament in a resolution passed on Wednesday.
<G-vec00719-002-s049><cope.bewältigen><de> In einer am Mittwoch beschlossenen Resolution betont das Parlament die Notwendigkeit einer Konferenz über humanitäre Hilfe der EU, die Syriens Nachbarstaaten verhelfen soll, die stetig wachsenden Flüchtlingsströme zu bewältigen.
<G-vec00719-002-s050><cope.bewältigen><en> My dear, you need to learn to cope better with the terrible stress of your life.
<G-vec00719-002-s050><cope.bewältigen><de> Meine Liebe, du musst lernen, diesen schrecklichen Stress in deinem Leben besser zu bewältigen.
<G-vec00719-002-s051><cope.bewältigwn><en> The controller has to cope with various operating modes of the overall system, e.g.
<G-vec00719-002-s051><cope.bewältigwn><de> Die Regelung muss alle unterschiedlichen Betriebs-Phasen des Gesamtsystems bewältigen können.
<G-vec00719-002-s052><cope.bewältigwn><en> Thirdly, the course of steroids with the use of morehard drugs should be postponed whenever possible, at a time when light drugs will no longer cope with the main task.
<G-vec00719-002-s052><cope.bewältigwn><de> Drittens, der Verlauf der Steroide mit der Verwendung von mehrharte Drogen sollten wann immer möglich verschoben werden, zu einer Zeit, in der leichte Drogen die Hauptaufgabe nicht mehr bewältigen können.
<G-vec00719-002-s053><cope.bewältigwn><en> Opt for a lump-sum of up to €1,000,000/$1,200,000 to cope with unexpected expenses if you become disabled (depending on the degree of your disability).
<G-vec00719-002-s053><cope.bewältigwn><de> Wählen Sie ein Kapital bis zu 1 000 000 €/$, damit Ihre Mitarbeiter im Falle einer Invalidität (in Abhängigkeit vom festgestellten Invaliditätsgrad) unvorhergesehene Ausgaben bewältigen können.
<G-vec00719-002-s054><cope.bewältigwn><en> The number of hours of instruction is decreasing to enable teachers to cope with the massive influx of pupils.
<G-vec00719-002-s054><cope.bewältigwn><de> Die Anzahl der Unterrichtsstunden sinkt, damit die Lehrer den Ansturm an Schülern bewältigen können.
<G-vec00719-002-s055><cope.bewältigwn><en> Not only the growing flood of data, but also the increasing demands of fast access to information and instant communication leads to new technical innovations to cope with the large amounts of data.
<G-vec00719-002-s055><cope.bewältigwn><de> Nicht nur die wachsende Datenflut, sondern auch die steigenden Ansprüche an den schnellen Zugriff auf Information und Just-in-Time Kommunikation führen zu immer neuen technischen Innovationen, um die sehr großen Mengen an Daten bewältigen zu können.
<G-vec00719-002-s056><cope.bewältigwn><en> A dream showers with rainshower and side showers need a larger shower channel in order to cope with the large amounts of water.
<G-vec00719-002-s056><cope.bewältigwn><de> Eine Traumdusche mit Rainshower und Seitenbrausen bedarf einer größeren Duschrinne, um die großen Wassermengen bewältigen zu können.
<G-vec00719-002-s057><cope.bewältigwn><en> But for us (and maybe for you too) travelling long term means that our wallets (and growing bellies) can't cope with three meals out a day.
<G-vec00719-002-s057><cope.bewältigwn><de> Aber für uns (und vielleicht auch für manche Leser) bedeutet das Langfristige Reisen, dass unsere Geldbörsen (und wachsende Bäuche) keine drei Mahlzeiten pro Tag bewältigen können.
<G-vec00719-002-s058><cope.bewältigwn><en> It was a sweeping success and in order to cope with the flood of orders, the company had to be expanded.
<G-vec00719-002-s058><cope.bewältigwn><de> Der Erfolg war durchschlagend und um die Auftragsflut bewältigen zu können, musste das Unternehmen erweitert werden.
<G-vec00719-002-s059><cope.bewältigwn><en> Nevertheless, I have been searching a long time for Little Lamb graduates and also questioning the present day elementary school students to find out how well they managed the transition to elementary school and to follow and cope with the curriculum.
<G-vec00719-002-s059><cope.bewältigwn><de> Nichts desto trotz bin ich schon lange auf der Suche nach Little Lambs Abgängern und heutigen Grundschülern, um herauszufinden, wie gut sie den Übergang geschafft und den Schulunterricht verfolgen und bewältigen können.
<G-vec00719-002-s060><cope.bewältigwn><en> It takes into consideration the support offered by the phenomenon of social referencing in order to cope with emotional challenges that are usually associated with familiarization.
<G-vec00719-002-s060><cope.bewältigwn><de> Sie nimmt in den Blick, welche Hilfestellung das Phänomen von Social Referencing bieten kann, um emotionale Herausforderungen, die meist mit der Eingewöhnung einher gehen, bewältigen zu können.
<G-vec00719-002-s061><cope.bewältigwn><en> So far, too few Member States have responded to these calls, and a large number of resources must still be provided for Serbia, Slovenia and Croatia to cope with the current situation.
<G-vec00719-002-s061><cope.bewältigwn><de> Bislang haben zu wenige Mitgliedstaaten auf diese Aufrufe reagiert, und eine Vielzahl von Ressourcen muss noch bereitgestellt werden, damit Serbien, Slowenien und Kroatien die derzeitige Situation bewältigen können.
<G-vec00719-002-s062><cope.bewältigwn><en> Bespoke and modular equipment We pride ourselves in supplying equipment to suit every purpose, client and budget, from affordable entry-level machines to equipment designed to cope with high-speed, high-volume production.
<G-vec00719-002-s062><cope.bewältigwn><de> Wir setzen unseren Ehrgeiz daran, Ausrüstung zu liefern, die sich für jeden Zweck, jeden Kunden und jedes Budget eignet – von preiswerten Einstiegsmaschinen bis hin zu einer Ausrüstung, die eine hochvolumige Produktion mit hoher Geschwindigkeit bewältigt.
<G-vec00719-002-s063><cope.bewältigwn><en> It is suitable for lawn areas of up to 1,000 m² and, thanks to its powerful rear-wheel drive, is able to cope with uneven ground and even with inclines of up to 35 percent.
<G-vec00719-002-s063><cope.bewältigwn><de> Er ist für Rasenflächen bis 1000 Quadratmeter geeignet und bewältigt mit dem kraftvollen Hinterradantrieb unebenes Gelände und sogar Steigungen bis 35 Prozent.
<G-vec00719-002-s064><cope.bewältigwn><en> Recovery Explorer Professional is a robust instrument that will cope even with most challenging data loss tasks that technical experts may come across with.
<G-vec00719-002-s064><cope.bewältigwn><de> Recovery Explorer Professional ist ein robustes Werkzeug, das auch die schwierigsten Datenverlust-Aufgaben, die technischen Experten begegnen können, bewältigt.
<G-vec00719-002-s065><cope.bewältigwn><en> Work is carried out using the very latest tools and machinery, with a 3 shift operation in order to be able to easily cope with larger capacities.
<G-vec00719-002-s065><cope.bewältigwn><de> Gearbeitet wird mit einem hochmodernen Werkzeug- und Maschinenpark im 3-Schicht-Betrieb, sodass auch größere Kapazitäten problemlos bewältigt werden können.
<G-vec00719-002-s066><cope.bewältigwn><en> Rail-bound trains are the only means of transport that can be used underground on branching lines to cope with inclines of more than 13 degrees.
<G-vec00719-002-s066><cope.bewältigwn><de> Entgleisungssichere Bahnen sind die einzigen, mit denen untertägig in verzweigten Strecken Steigungen von mehr als 13 Grad bewältigt werden können.
<G-vec00719-002-s067><cope.bewältigwn><en> The motor's performance data opens up new possibilities for users. It can cope with extremely heavy working loads, doesn't take up as much space, and with it being 50 percent lighter, the output shaft has less weight to deal with.
<G-vec00719-002-s067><cope.bewältigwn><de> Die Leistungsdaten des Motors eröffnen Anwendern neue Möglichkeiten: Er bewältigt schwerste Arbeitslasten, benötigt weniger Raum und wirkt durch seine um 50 Prozent reduzierte Masse mit geringerem Gewicht auf die Abtriebswelle.
<G-vec00719-002-s068><cope.bewältigwn><en> "Allianz continues to cope successfully with the impact of the ongoing financial markets crisis on our business.
<G-vec00719-002-s068><cope.bewältigwn><de> "Die Allianz bewältigt die Auswirkungen der Finanzmarktkrise auf das Geschäft weiterhin erfolgreich.
<G-vec00719-002-s208><cope.klarkommen><en> So, you need to be able to cope with his and the committee's decisions when you make a suggestion.
<G-vec00719-002-s208><cope.klarkommen><de> Also müsst ihr mit seinen oder den Entscheidungen des Komitees klar kommen können, wenn ihr einen Vorschlag macht.
<G-vec00719-002-s209><cope.klarkommen><en> Furthermore, we can help you gain a complete business view of your whole enterprise by applying enterprise modeling methodologies, tools and techniques or help your IT organization to cope better with the complexity of the applications landscape, data models, and their relationship to your business processes.
<G-vec00719-002-s209><cope.klarkommen><de> Zusätzlich können wir Ihnen helfen, einen vollständigen Überblick über Ihr Unternehmen zu gewinnen, indem wir Methoden, Werkzeuge und Techniken zur Unternehmensmodellierung anwenden oder auch indem wir Ihrer IT-Abteilung helfen, besser mit der komplexen Applikationsarchitektur, mit den Datenmodellen und deren Beziehung zu Ihren Geschäftsprozessen klar zu kommen.
<G-vec00719-002-s210><cope.klarkommen><en> They need more niacin in order to cope with eating inappropriate foods.
<G-vec00719-002-s210><cope.klarkommen><de> Sie brauchen mehr Niacin, um mit der falschen Ernährungsweise klar zu kommen.
<G-vec00719-002-s211><cope.klarkommen><en> The murderer is a product of modern Japanese society where privileged people raise children who cannot cope with the privileges and run wild.
<G-vec00719-002-s211><cope.klarkommen><de> Der Mörder ist ein Produkt der modernen japanischen Gesellschaft, wo privilegierte Menschen Kinder in die Welt setzen, die wiederum mit den ererbten Privilegien nicht klar kommen und außer Kontrolle geraten.
<G-vec00719-002-s212><cope.klarkommen><en> The A component pump is of the hardened type to cope with the abrasive fillers and the B component is the precision, low speed version due to the wide metering ratio and different material viscosities.
<G-vec00719-002-s212><cope.klarkommen><de> Die A-Komponenten-Pumpe ist gehärtet, um so mit den abrasiven Füllstoffen klar zu kommen, die B-Komponenten-Pumpe ist die Präzisionsversion für geringe Geschwindigkeit, da es ein breites MV und unterschiedlichste Materialviskositäten gibt.
<G-vec00719-002-s213><cope.klarkommen><en> Woods of the desert lead a life full of privation, but their scent is, similar to great wines, which have to cope with a lot of rock and little soil, something special.
<G-vec00719-002-s213><cope.klarkommen><de> Hölzer der Wüste führen ein entbehrungsreiches Leben, doch ihr Duft ist, ähnlich wie bei großen Weinen, die mit viel Fels und wenig Erde klarkommen müssen, etwas Besonderes.
<G-vec00719-002-s215><cope.klarkommen><en> If you can’t cope with adversity and uncertainty, you’re going to be toast in the coming years.
<G-vec00719-002-s215><cope.klarkommen><de> Wenn Sie nicht mit Widrigkeiten und Unsicherheit klarkommen, dann werden Sie in den nächsten Jahren erledigt sein.
<G-vec00719-002-s216><cope.klarkommen><en> I also enjoy ‘fish out of water’ stories, where a character must cope somewhere completely new.
<G-vec00719-002-s216><cope.klarkommen><de> Ich mag auch „Fisch außerhalb des Wassers“-Geschichten, also Geschichten, in denen ein Charakter in einer komplett neuen Umgebung klarkommen muss.
<G-vec00719-002-s414><cope.zurechtkommen><en> This research will provide new insights into how organisms cope with the effect of climate change, disease, and human alterations of their natural habitat.
<G-vec00719-002-s414><cope.zurechtkommen><de> Diese Forschungen werden zeigen, wie Organismen mit Klimaveränderungen, Krankheitserregern und menschlichen Einflüssen zurecht kommen.
<G-vec00719-002-s415><cope.zurechtkommen><en> The son of the company founder, Toyoda, had already begun to “streamline” the manufacturing process during the wartime period in the middle of the century and to cope with the difficult conditions through “just-in-time” delivery.
<G-vec00719-002-s415><cope.zurechtkommen><de> Der Sohn der Unternehmens Gründers, Toyoda, hatte bereits während den Kriegszeiten Mitte des Jahrhunderts begonnen den Herstellungsprozess zu „verschlanken“ und durch „Just-in-time“-Lieferung mit den schwierigen Bedingungen zurecht zu kommen.
<G-vec00719-002-s416><cope.zurechtkommen><en> DOC DOTHTML It often happens that in spite of the appropriate software to support the file type, we cannot cope with it.
<G-vec00719-002-s416><cope.zurechtkommen><de> Es kommt häufig vor, dass wir trotz der installierten entsprechenden Software für die Bedienung einer bestimmten Art von Datei, mit ihrer Bedienung nicht zurecht kommen.
<G-vec00719-002-s417><cope.zurechtkommen><en> She is generally a bit more resolute than me and asked me to be more relaxed, as the Australians would also be able to cope with these animals.
<G-vec00719-002-s417><cope.zurechtkommen><de> Sie ist grundsätzlich resoluter als ich und bat mich also, doch bitte ein bisschen gelassener zu sein, die Australier würden hier ja schließlich auch zurecht kommen.
<G-vec00719-002-s419><cope.zurechtkommen><en> These are for the leisure cyclist that has a good level of physical fitness and who can cope with the occasional challenging steep hill.
<G-vec00719-002-s419><cope.zurechtkommen><de> Sie eignen sich für Freizeitfahrer, die körperlich fit sind und hin und wieder mit einem anspruchsvolleren, steilen Hügel zurecht kommen.
<G-vec00719-002-s420><cope.zurechtkommen><en> They should take into consideration that, without German language skills, it is difficult to cope in everyday life, to find work or to study.
<G-vec00719-002-s420><cope.zurechtkommen><de> Denn ohne Deutschkenntnisse ist es schwierig, im Alltag zurecht zu kommen, eine Arbeit zu finden oder zu studieren.
<G-vec00719-002-s424><cope.zurechtkommen><en> Greater Burdock was therefore always used where the body had to cope with many toxins.
<G-vec00719-002-s424><cope.zurechtkommen><de> Deshalb wurde die Klette immer schon dort eingesetzt, wo der Körper mit zu vielen Giftstoffen zurecht kommen musste.
<G-vec00719-002-s425><cope.zurechtkommen><en> These are all requirements that the highly shielded and therefore inflexible OnPremises IT environments can no longer cope with.
<G-vec00719-002-s425><cope.zurechtkommen><de> All das sind Anforderungen mit denen die stark abgeschirmten und dadurch unflexiblen OnPremises IT-Umgebungen nicht mehr zurecht kommen.
<G-vec00719-002-s426><cope.zurechtkommen><en> Still struggling to cope with the loss of their immortality, the night elves must prepare to stand against any threat as Azeroth itself breaks apart at the seams.
<G-vec00719-002-s426><cope.zurechtkommen><de> Während sie immer noch versuchen, mit dem Verlust ihrer Unsterblichkeit zurecht zu kommen, müssen die Nachtelfen sich nun darauf vorbereiten, den Herausforderungen in einem Azeroth entgegenzutreten, das an allen Nähten zu brechen droht.
<G-vec00719-002-s427><cope.zurechtkommen><en> An abortion usually entails difficulties for the mother to cope with the situation.
<G-vec00719-002-s427><cope.zurechtkommen><de> Die Abtreibung zieht gewöhnlich eine Schwierigkeit der Mutter, mit dieser Situation zurecht zu kommen, nach sich.
<G-vec00719-002-s429><cope.zurechtkommen><en> The vacuum ejector needed to cope with leaking around the terminals, and also be powerful enough to help lift the terminals into the tubes and not have the other terminals affected by a missed pick.
<G-vec00719-002-s429><cope.zurechtkommen><de> Der Vakuumejektor muss mit der Leckage, die um die Pole herum entsteht zurecht kommen und stark genug sein, um die Pole in die Metallröhrchen zu ziehen, ohne dass dabei die anderen Pole durch einen verpassten Hebevorgang beeinträchtigt werden.
<G-vec00719-002-s430><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the 3GP to MP4 file extension.
<G-vec00719-002-s430><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der PRPROJ-Datei in die MP4-Datei zurechtkommen.
<G-vec00719-002-s431><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the LIT to PDF file extension.
<G-vec00719-002-s431><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der LIT-Datei in die EPUB-Datei zurechtkommen.
<G-vec00719-002-s432><cope.zurechtkommen><en> Adolescence is often a difficult phase of development and brings a number of physical and psychological changes, with which adolescents have to cope for now.
<G-vec00719-002-s432><cope.zurechtkommen><de> Die Pubertät ist eine oft schwierige Entwicklungsphase und bringt eine Reihe körperlicher und seelischer Veränderungen mit sich, mit denen Heranwachsende erst einmal zurechtkommen müssen.
<G-vec00719-002-s433><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the PEF to MRW file extension.
<G-vec00719-002-s433><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der MRW-Datei in die ARW-Datei zurechtkommen.
<G-vec00719-002-s434><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the ODG to GIF file extension.
<G-vec00719-002-s434><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der GIF-Datei in die PDF-Datei zurechtkommen.
<G-vec00719-002-s435><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the BMP to TIF file extension.
<G-vec00719-002-s435><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der TIF-Datei in die BMP-Datei zurechtkommen.
<G-vec00719-002-s436><cope.zurechtkommen><en> Powell Peralta updated their SSF formula to be able to cope with more course terrain
<G-vec00719-002-s436><cope.zurechtkommen><de> Powell Peralta hat die beliebte SSF-Formel überarbeitet, damit die Cruiser-Rollen auch mit schwierigem Gelände optimal zurechtkommen.
<G-vec00719-002-s437><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the RAW to PNG file extension.
<G-vec00719-002-s437><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der AEP-Datei in die PNG-Datei zurechtkommen.
<G-vec00719-002-s438><cope.zurechtkommen><en> «Indonesian → Lithuanian» online translator will perfectly cope with texts of technical, legal, scientific, economic and medical nature.
<G-vec00719-002-s438><cope.zurechtkommen><de> «Albanisch → Litauisch» Online-Übersetzer wird perfekt mit Texten von technischer, rechtlicher, wissenschaftlicher, wirtschaftlicher und medizinischer Art zurechtkommen.
<G-vec00719-002-s439><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the AVI to XVID file extension.
<G-vec00719-002-s439><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der XVID-Datei in die AVI-Datei zurechtkommen.
<G-vec00719-002-s440><cope.zurechtkommen><en> Today, we’re changing the way people earn a living and how businesses cope with fluctuating demand.
<G-vec00719-002-s440><cope.zurechtkommen><de> Dabei verändern wir, wie Arbeitnehmer ihren Lebensunterhalt verdienen und Unternehmen mit schwankenden Nachfragen zurechtkommen.
<G-vec00719-002-s441><cope.zurechtkommen><en> «Norwegian → Galician» online translator will perfectly cope with texts of technical, legal, scientific, economic and medical nature.
<G-vec00719-002-s441><cope.zurechtkommen><de> «Serbisch → Norwegisch» Online-Übersetzer wird perfekt mit Texten von technischer, rechtlicher, wissenschaftlicher, wirtschaftlicher und medizinischer Art zurechtkommen.
<G-vec00719-002-s442><cope.zurechtkommen><en> They left everything behind and must now cope in a new world, that's very different from anything they've ever known.
<G-vec00719-002-s442><cope.zurechtkommen><de> Sie haben alles zurückgelassen und müssen nun in einer neuen Welt zurechtkommen, die ganz anders ist als alles, was Sie bisher gekannt haben.
<G-vec00719-002-s443><cope.zurechtkommen><en> «Indonesian → Igbo» online translator will perfectly cope with texts of technical, legal, scientific, economic and medical nature.
<G-vec00719-002-s443><cope.zurechtkommen><de> «Indonesisch → Aserbaidschanisch» Online-Übersetzer wird perfekt mit Texten von technischer, rechtlicher, wissenschaftlicher, wirtschaftlicher und medizinischer Art zurechtkommen.
<G-vec00719-002-s444><cope.zurechtkommen><en> Everybody in this world has to cope with a lot of difficulties.
<G-vec00719-002-s444><cope.zurechtkommen><de> Jeder auf dieser Welt muss mit einer Menge von Schwierigkeiten zurechtkommen.
<G-vec00719-002-s445><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the TDL to ACCDB file extension.
<G-vec00719-002-s445><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der TDL-Datei in die ACCDB-Datei zurechtkommen.
<G-vec00719-002-s446><cope.zurechtkommen><en> At Extension.info, in addition to the list of applications supporting file extensions, you will also find file converters that are able to cope with the conversion of the AWP to LWP file extension.
<G-vec00719-002-s446><cope.zurechtkommen><de> Auf der Seite Extension.info finden Sie außer der Liste mit Applikationen, die Dateiendungen unterstützen, Dateikonverter, die ohne Probleme mit der Konvertierung der Endung der AWP-Datei in die AWW-Datei zurechtkommen.
<G-vec00719-002-s447><cope.zurechtkommen><en> For this reason, by virtue of our many years of experience as an automotive supplier we are developing products that can cope with difficult ambient conditions and high quality standards.
<G-vec00719-002-s447><cope.zurechtkommen><de> Deshalb entwickeln wir mit unserer langjährigen Erfahrung als Automobilzulieferer Produkte, welche mit schwierigen Umgebungsbedingungen und hohen Qualitätsanforderungen zurechtkommen.
<G-vec00719-002-s448><cope.zurechtkommen><en> We are curious how we will cope with the altitude.
<G-vec00719-002-s448><cope.zurechtkommen><de> Wir sind gespannt, wie wir mit der Höhe zurechtkommen werden.
<G-vec00719-002-s449><cope.zurechtkommen><en> However, just like the story of the Danish storyteller, the musical tells of the struggle between good and evil, and that love can cope with any cold.
<G-vec00719-002-s449><cope.zurechtkommen><de> Wie auch die Geschichte des dänischen Geschichtenerzählers erzählt das Musical vom Kampf zwischen Gut und Böse, und dass die Liebe mit jeder Kälte zurechtkommt.
<G-vec00719-002-s450><cope.zurechtkommen><en> a little Competition by a principle quot is held;: each of participants sings the necessary song line who in turn does not cope with the task - leaves competition.
<G-vec00719-002-s450><cope.zurechtkommen><de> Wird der Wettbewerb nach dem Prinzip quot durchgeführt;: jeder der Teilnehmer singt die nötige Liederzeile, wer mit der Aufgabe seinerseits nicht zurechtkommt - tritt den Wettbewerb aus.
<G-vec00719-002-s452><cope.zurechtkommen><en> She immediately undergoes an attack of the immune system and moves to places where immunity can not cope - in the heart, nerve tissue, tendons.
<G-vec00719-002-s452><cope.zurechtkommen><de> Sie unterzieht sich sofort einem Angriff des Immunsystems und bewegt sich an Orte, an denen die Immunität nicht zurechtkommt - im Herzen, im Nervengewebe, in den Sehnen.
<G-vec00719-002-s454><cope.zurechtkommen><en> With regard to the management of childbirth, you will not be offered anesthesia, stimulation or cesarean section, if the doctors believe that the body will cope on its own.
<G-vec00719-002-s454><cope.zurechtkommen><de> In Bezug auf das Geburtsmanagement wird Ihnen keine Anästhesie, Stimulation oder Kaiserschnitt angeboten, wenn die Ärzte glauben, dass der Körper alleine zurechtkommt.
<G-vec00719-002-s455><cope.zurechtzukommen><en> Besides effective and well-tolerated products for skin cleansing and care you can obtain there treatments to support the medical therapy and help you to cope best with the signs of skin impurities or acne by adequate skin care. You might like these products:
<G-vec00719-002-s455><cope.zurechtzukommen><de> Hier werden neben wirksamen und verträglichen Reinigungs- und Pflegeprodukten auch unterstützende Behandlungen angeboten, die helfen, mit den Zeichen unreiner Haut oder Akne durch Hautpflege am besten zurechtzukommen und die ärztliche Behandlung am wirkungsvollsten zu unterstützen.
<G-vec00719-002-s456><cope.zurechtzukommen><en> The Goodyear Wrangler DuraTrac has been developed to cope with the toughest terrains, including sand dunes, sharp edged gravel, riverbeds and high angle mountain roads, all of which the participants will encounter during their adventures.
<G-vec00719-002-s456><cope.zurechtzukommen><de> Der Goodyear Wrangler DuraTrac wurde dafür entwickelt, auch mit dem schwierigsten Gelände zurechtzukommen, einschließlich Sanddünen, scharfkantigem Schotter, Flussbetten und verwinkelten Gebirgsstraßen – und während dieses Abenteuers werden die Teilnehmer mit all diesen Geländearten konfrontiert.
<G-vec00719-002-s457><cope.zurechtzukommen><en> Of course, it is about human beings and their self-delusions about their complicated relationships. And it is also about their attempts to cope in a changing world.
<G-vec00719-002-s457><cope.zurechtzukommen><de> Es geht darin natürlich um Menschen, um ihre Lebenslügen und vertrackten Beziehungen – und um ihre Versuche, in einer sich wandelnden Welt zurechtzukommen.
<G-vec00719-002-s458><cope.zurechtzukommen><en> Beginning in 1883, he helped Prince Bismarck cope with his gargantuan appetite for food, drink, and tobacco.
<G-vec00719-002-s458><cope.zurechtzukommen><de> Ab 1883 half er Fürst Bismarck, mit seinem riesigen Appetit auf Essen, Trinken und Tabak zurechtzukommen.
<G-vec00719-002-s459><cope.zurechtzukommen><en> They use complex mechanisms to cope with their environmental conditions," said the researcher.
<G-vec00719-002-s459><cope.zurechtzukommen><de> Sie nutzen komplexe Mechanismen, um mit ihren Umweltbedingungen zurechtzukommen“, sagt die Forscherin.
<G-vec00719-002-s460><cope.zurechtzukommen><en> Many people find that it can also lead to increased energy levels, as well as improved appetite and sleep, an enhanced sense of overall well-being and a better ability to cope with the stresses of life.
<G-vec00719-002-s460><cope.zurechtzukommen><de> Viele Patienten sagen, dass Akupunktur auch zu mehr Energie führt, sowie auch zu verbessertem Appetit und besserem Schlaf, einem besseren allgemeinen Wohlbefinden und sie hilft einem auch dabei, besser mit dem Stress des Alltags zurechtzukommen.
<G-vec00719-002-s461><cope.zurechtzukommen><en> In the process, the administration has taken a new view of the ramshackle condition of its infrastructure, such as bridges, streets, and railroads. That is no longer regarded as being a more or less economically relevant defect which can be regulated locally and which the individual states have to cope with as much as their budgets and interests allow, but as a national problem and a serious obstacle to restoring America’s industrial landscape.
<G-vec00719-002-s461><cope.zurechtzukommen><de> Dabei kommt der Regierung der marode Zustand der Infrastruktur, von Brücken, Straßen und Eisenbahnlinien neu in den Blick: Nicht mehr als örtlich zu regelnder, mehr oder weniger ökonomisch relevanter Missstand, mit dem die Einzelstaaten je nach Budget und Interesse zurechtzukommen haben, vielmehr als nationale Notlage und ernstes Hindernis für den Wiederaufbau der amerikanischen Industrielandschaft.
<G-vec00719-002-s462><cope.zurechtzukommen><en> Mind: no chance, we have been used to separation, it is familiar and I help you to cope with it.
<G-vec00719-002-s462><cope.zurechtzukommen><de> Verstand: Keine Chance, wir haben uns doch schon an die Trennung gewöhnt, es ist vertraut und ich helf dir doch, mit der Trennung zurechtzukommen.
<G-vec00719-002-s463><cope.zurechtzukommen><en> Mental and emotional symptoms of mental illness and depression include: confusion, sudden and extreme mood changes, isolation from friends, unable to cope with everyday problems, and increased anger or violence.
<G-vec00719-002-s463><cope.zurechtzukommen><de> Zu den psychischen und emotionalen Symptomen einer psychischen Störung und Depression gehören: Verwirrung, plötzliche und extreme Stimmungsschwankungen, Isolierung von Freunden, Unfähigkeit, mit alltäglichen Problemen zurechtzukommen und erhöhte Reizbarkeit und Gewaltbereitschaft.
<G-vec00719-002-s464><cope.zurechtzukommen><en> Of course, it is a big challenge at the beginning to cope with so many children who all have their own characters but the longer I took care of them the funnier it became.
<G-vec00719-002-s464><cope.zurechtzukommen><de> Natürlich ist es am Anfang eine Herausforderung auch mal alleine mit so vielen Kindern, die alle einen komplett unterschiedlichen Charakter haben, zurechtzukommen.
<G-vec00719-002-s465><cope.zurechtzukommen><en> Friends were not allowed to associate with me and all I had was my music (this i am thankful for because it's lead me to having a successful music career today!) Up until 4 years ago, I never thought twice about the incident but my anger outbursts and inability to cope with life brought me to a psychologist, and slowly the atrocities of the past revealed themselves.
<G-vec00719-002-s465><cope.zurechtzukommen><de> Freunde durften keinen Umgang mit mir haben, und alles, was ich hatte, war meine Musik (dafür bin ich dankbar, denn meine Wutausbrüche und die Unfähigkeit, mit dem Leben zurechtzukommen, brachten mich zu einem Psychologen, und langsam kamen die Scheußlichkeiten der Vergangenheit heraus.
<G-vec00719-002-s466><cope.zurechtzukommen><en> Polishing nail files won't help to cope with this problem but only will aggravate it.
<G-vec00719-002-s466><cope.zurechtzukommen><de> Die polirowotschnyje Nagelfeilen werden nicht helfen, mit diesem Problem zurechtzukommen, und nur werden sie verstärken.
<G-vec00719-002-s467><cope.zurechtzukommen><en> What probably helps me most to cope with my mobile data limits is the fact that I just don’t open certain apps without wi-fi connection.
<G-vec00719-002-s467><cope.zurechtzukommen><de> Was mir wohl am meisten dabei hilft, mit meinem Datenvolumen zurechtzukommen, ist, dass ich bestimmte Apps prinzipiell nicht ohne WLAN öffne.
<G-vec00719-002-s468><cope.zurechtzukommen><en> As causes for that Freud sees possible character traits, like domineeringness, and the fundamental problem for an enlightener to cope with such a tribe still full of primordial ideas like the Hebrews of then.
<G-vec00719-002-s468><cope.zurechtzukommen><de> Als Ursachen sieht Freud hierfür mögliche Charaktereigenschaften wie Herrschsucht und das grundsätzliche Problem für einen Aufklärer, mit einem solchen noch mit ursprünglichen Vorstellungen behafteten Stamm wie den damaligen Hebräern zurechtzukommen.
<G-vec00719-002-s469><cope.zurechtzukommen><en> It is about attempts to cope with regulations and cultural requirements that literally bind the body like a corset, but also stripping this off and being resistant.
<G-vec00719-002-s469><cope.zurechtzukommen><de> Es geht um Versuche, mit Reglementierungen und kulturellen Anforderungen, die den Körper buchstäblich wie ein Korsett einschnüren, zurechtzukommen, aber auch dieses abzustreifen und widerständig zu sein.
<G-vec00719-002-s470><cope.zurechtzukommen><en> Having less, consuming less, is the most powerful way we can minimize the damage that we do, while also preparing ourselves to cope with the changes that we cannot prevent.
<G-vec00719-002-s470><cope.zurechtzukommen><de> Weniger zu haben, weniger zu konsumieren ist die wirksamste Art, wie wir den Schaden, den wir verursachen, begrenzen und uns gleichzeitig darauf vorbereiten können, mit den Veränderungen, die wir nicht abwenden können, zurechtzukommen.
<G-vec00719-002-s471><cope.zurechtzukommen><en> There is a set of the ancient recipes helping to cope with a difficult problem.
<G-vec00719-002-s471><cope.zurechtzukommen><de> Es gibt eine Menge der altertümlichen Rezepte, helfend, mit dem komplizierten Problem zurechtzukommen.
<G-vec00719-002-s472><cope.zurechtzukommen><en> But at the same time, they have not yet equipped their Union - our Union —with the instruments needed to cope with this new reality.
<G-vec00719-002-s472><cope.zurechtzukommen><de> Sie haben aber ihre Union – unsere Union – noch nicht mit den Instrumenten versehen, die erforderlich sind, um mit diesen neuen Gegebenheiten zurechtzukommen.
<G-vec00719-002-s473><cope.zurechtzukommen><en> Because the condition can cause pain, discomfort, bleeding, and emotional distress, you may find the condition difficult to cope with at first.
<G-vec00719-002-s473><cope.zurechtzukommen><de> Da diese Krankheit Schmerzen, Unbehagen, Blutungen, und emotionales Leid verursachen kann, kann es schwierig sein, mit ihr zurechtzukommen.
