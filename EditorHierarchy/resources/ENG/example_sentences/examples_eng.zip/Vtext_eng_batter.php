<G-vec00789-002-s142><batter.aufbrauchen><en> Repeat until batter is gone.
<G-vec00789-002-s142><batter.aufbrauchen><de> Genau so wiederholen bis der Teig aufgebraucht ist.
<G-vec00789-002-s058><batter.erschüttern><en> God weaves that "crown of righteousness" for us (II Tm 4: 8) as the reward for our fidelity to him which we were able to preserve, even when storms batter our heart and mind.
<G-vec00789-002-s058><batter.erschüttern><de> Gott flicht für uns diesen »Kranz der Gerechtigkeit« (2 Tim 4,8), der unsere Treue zu ihm belohnen wird, die wir auch in den stürmischen Zeiten, die unser Herz und unsere Sinne erschüttern, bewahrt haben.
<G-vec00789-002-s169><batter.verbrauchen><en> Keep the pancakes warm by keeping them covered in the oven until all the batter has been used up.
<G-vec00789-002-s169><batter.verbrauchen><de> Palatschinken zugedeckt im Ofen warm halten, bis der gesamte Teig verbraucht ist.
