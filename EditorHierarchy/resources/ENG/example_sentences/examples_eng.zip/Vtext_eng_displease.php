<G-vec00231-001-s004><displease.missfallen><en> No-one should build his house even a hair’s width higher than his neighbor, give it no other form and do not set it a hair outside or inside the straightest line; for such a thing would displease the great spirit, and He would not bless such a disorderly house.
<G-vec00231-001-s004><displease.missfallen><de> Niemand erbaue sein Haus auch nur um ein Haarbreit größer denn sein Nachbar, gebe ihm auch keine andere Gestalt und setze es ja nicht um ein Haar außerhalb oder innerhalb der geradesten Linie; denn solches würde dem Grossgeiste missfallen, und Er würde nicht segnen solch ein unordentliches Haus.
<G-vec00231-001-s006><displease.missfallen><en> For example, if you love somebody, you would not like to do something to displease that person.
<G-vec00231-001-s006><displease.missfallen><de> Wenn ihr zum Beispiel jemand liebt, würdet ihr nicht etwas tun, um dieser Person zu missfallen.
<G-vec00231-001-s007><displease.missfallen><en> Satan triumphed in that he had caused him to displease God, and he exulted, and told the angels that when the Saviour of the world should come to redeem man, he could overcome him.
<G-vec00231-001-s007><displease.missfallen><de> Satan triumphierte darüber, dass er Mose dazu gebracht hatte, Gott zu missfallen und er frohlockte und erzählte den Engeln, wenn der Heiland der Welt kommen sollte, um den Menschen zu erlösen, dann könnte er ihn überwinden.
<G-vec00231-001-s008><displease.missfallen><en> Remove your focus from the things in life that displease you and you will not attract them to you.
<G-vec00231-001-s008><displease.missfallen><de> Entfernen Sie den Fokus von den Dingen im Leben, die missfallen, und du wirst nicht gewinnen sie Ihnen.
<G-vec00231-001-s009><displease.missfallen><en> Our falls do not displease Him as much as our getting back up and pressing on pleases Him.
<G-vec00231-001-s009><displease.missfallen><de> Unser Fall missfällt Ihm nicht so sehr, wie es Ihn erfreut, wenn wir wieder aufstehen und weitergehen.
<G-vec00231-001-s010><displease.missfallen><en> "Coubertin substantiated this procedure with the fact that an obligation could ""displease mature men...""."
<G-vec00231-001-s010><displease.missfallen><de> "Coubertin begründet dieses Vorgehen damit, dass eine Verpflichtung den ""reifen Männern... mißfallen"" könnte."
<G-vec00231-001-s011><displease.missfallen><en> For most of her life, her social atmosphere has been occupied solely by other gargoyles, which began to displease her as she reached adolescence.
<G-vec00231-001-s011><displease.missfallen><de> Für die meisten von ihrem Leben, hat ihre gesellschaftliche Atmosphäre allein durch andere Wasserspeier, die ihr mißfallen, als sie begann Adoleszenz erreicht besetzt worden.
<G-vec00231-001-s012><displease.missfallen><en> A small oddity that displease the President of Georgia Mikheil Saakashvili has happened today during a visit to Batumi, the Acting President of Moldova Mihai Ghimpu.
<G-vec00231-001-s012><displease.missfallen><de> Eine kleine Kuriosität, dass der Präsident Georgiens Michail Saakaschwili mißfallen hat heute passiert bei einem Besuch in Batumi, der amtierenden Präsidentin der Republik Moldau Mihai Ghimpu.
<G-vec00231-001-s014><displease.machen><en> So there are times when you know the right thing to do is going to displease other people and there's no way around it.
<G-vec00231-001-s014><displease.machen><de> Also sind da Zeiten, wenn du weißt, das Richtige, was zu tun ist, wird andere Leute unzufrieden machen, und es gibt keinen Weg drum herum.
<G-vec00231-002-s006><displease.missfallen><en> It is not to displease me besides, the plastic being more and more controversial.
<G-vec00231-002-s006><displease.missfallen><de> Es ist mir nicht zu missfallen, da der Kunststoff immer kontroverser wird.
