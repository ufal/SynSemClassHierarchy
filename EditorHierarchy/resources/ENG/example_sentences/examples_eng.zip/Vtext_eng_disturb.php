<G-vec00547-001-s039><disturb.belästigen><en> "As he once said, ""The diseases of the body are few, far fewer than the diseases of the heart and mind."" It's possible to find people who have lived to the age of 50 or 60 without having suffered from diseases of the body, but as for diseases of the heart and mind, they constantly disturb ordinary people everywhere."
<G-vec00547-001-s039><disturb.belästigen><de> So wie er einst sagte: „Die Krankheiten des Körpers sind wenige, viel mehr gibt es an Krankheiten für Herz und Geist.“ Es ist möglich Leute zu finden, die bis ins Alter von 50 oder 60 nicht an Krankheiten des Körpers gelitten haben, aber Krankheiten des Herzens und des Geistes belästigen gewöhnliche Leute stets überall.
<G-vec00547-001-s040><disturb.belästigen><en> The member furthermore agrees not to disturb other members or third parties when using OPENPUZZLE.
<G-vec00547-001-s040><disturb.belästigen><de> Das Mitglied verpflichtet sich ferner, durch die Nutzung von OPENPUZZLE andere Mitglieder oder Dritte nicht zu belästigen.
<G-vec00547-001-s041><disturb.belästigen><en> It's possible to find people who have lived to the age of 50 or 60 without having suffered from diseases of the body, but as for diseases of the heart and mind, they constantly disturb ordinary people everywhere.
<G-vec00547-001-s041><disturb.belästigen><de> Es ist möglich Leute zu finden, die bis ins Alter von 50 oder 60 nicht an Krankheiten des Körpers gelitten haben, aber Krankheiten des Herzens und des Geistes belästigen gewöhnliche Leute stets überall.
<G-vec00547-001-s042><disturb.belästigen><en> Visitors can be refused admittance to performance venues if there is reason to assume that they will disrupt the performance or disturb other visitors.
<G-vec00547-001-s042><disturb.belästigen><de> Besuchern kann der Zutritt zu den Spielstätten verweigert werden, wenn Anlass zu der Annahme besteht, dass sie die Vorstellungen stören oder andere Besucher belästigen.
<G-vec00547-001-s043><disturb.belästigen><en> "Disrupt the flow of forums, events, or other Program activities with vulgar language, abusiveness, use of excessive shouting [all caps] in an attempt to disturb other users, ""spamming"" or flooding [posting repetitive text]."
<G-vec00547-001-s043><disturb.belästigen><de> "Den Ablauf von Foren, Events oder anderen Programmaktivitäten mit vulgärer Sprache, Beleidigungen, übertriebener Verwendung der Großschreibung (""Shouting"") beeinträchtigen, mit dem Ziel andere Teilnehmer zu belästigen oder mit Spam-Texten zu überhäufen (Posten sich wiederholender Texte)."
<G-vec00547-001-s044><disturb.belästigen><en> Now I won't disturb you anymore, so you that can get some peace to remember your loved ones, who no longer are among us...
<G-vec00547-001-s044><disturb.belästigen><de> Nun möchte ich sie nicht weiter belästigen, so dass sie nun in Frieden an ihre Ihre Lieben gedenken können, die nicht mehr unter uns weilen....
<G-vec00547-001-s045><disturb.belästigen><en> Farmers will be grateful if you will avoid treading on fields and meadows, re-close fences and not disturb grazing animals.
<G-vec00547-001-s045><disturb.belästigen><de> Die Bauern werden Ihnen dankbar sein, wenn Sie Wiesen und Felder nicht zertreten, die Gatter der Umzäunungen wieder schließen und die Tiere auf der Weide nicht belästigen.
<G-vec00547-001-s046><disturb.beunruhigen><en> This situation has begun to disturb Czechoslovakia, Poland and other COMECON member countries, which are turning to other markets to fulfil their needs for oil and raw materials.
<G-vec00547-001-s046><disturb.beunruhigen><de> Diese Zustände beunruhigen bereits die Tschechoslowakei, Polen und andere RGW-Staaten, die sich gezwungen sehen, sich an andere Länder zu wenden, um ihre Bedürfnis an Erdöl und Rahstoffen zu befriedigen.
<G-vec00547-001-s047><disturb.beunruhigen><en> At first sight, from such plain transport about two wheels in life only the advantage is introduced: to move on the scooter quicker, than to walk, fuel prices do not disturb, traffic jams do not disturb, physical activity increases and is capable to replace full-fledged morning exercises.
<G-vec00547-001-s047><disturb.beunruhigen><de> Anscheinend, von solchem einfachen Transport über zwei Räder ins Leben wird nur der Nutzen hineingelegt: sich auf dem Roller zu bewegen es ist schneller, als, zu Fuß zu gehen, die Preise für den Brennstoff beunruhigen nicht, die Autopfropfen stören nicht, die physische Aktivität nimmt zu und ist fähig, die vollwertige Morgengymnastik zu ersetzen.
<G-vec00547-001-s048><disturb.beunruhigen><en> "Throughout many years images ""-pыxTpы№"" disturb creative imagination of the composer."
<G-vec00547-001-s048><disturb.beunruhigen><de> "Während vieler Jahre die Gestalten ""-pыxTpы№"" beunruhigen die schöpferische Einbildung des Komponisten."
<G-vec00547-001-s049><disturb.beunruhigen><en> Do not recommend to replace a mimosa — without emergency you should not disturb this plant.
<G-vec00547-001-s049><disturb.beunruhigen><de> Die Mimose umzusetzen empfehlen nicht — ohne äußerste Notwendigkeit, diese Pflanze zu beunruhigen kostet nicht.
<G-vec00547-001-s050><disturb.beunruhigen><en> Indeed, “if anything should rightly disturb us and trouble our consciences, it is the fact that so many of our brothers and sisters are living without the strength, light and consolation born of friendship with Jesus Christ, without a community of faith to support them, without meaning and a goal in life” (Evangelii Gaudium, 49).
<G-vec00547-001-s050><disturb.beunruhigen><de> »Wenn uns etwas in heilige Sorge versetzen und unser Gewissen beunruhigen soll, dann ist es die Tatsache, dass so viele unserer Brüder und Schwestern ohne die Kraft, das Licht und den Trost der Freundschaft mit Jesus Christus leben, ohne eine Glaubensgemeinschaft, die sie aufnimmt, ohne einen Horizont von Sinn und Leben.« (Apostolisches Schreiben Evangelii gaudium, 49).
<G-vec00547-001-s051><disturb.beunruhigen><en> It is desirable to choose such place where nobody will disturb you.
<G-vec00547-001-s051><disturb.beunruhigen><de> Es wäre wünschenswert, solche Stelle zu wählen, wo Sie niemand beunruhigen wird.
<G-vec00547-001-s052><disturb.beunruhigen><en> It seemed that even the clicks of a lock of the camera which suddenly rushed into the temple not in forces to disturb this trembling reverential spirit.
<G-vec00547-001-s052><disturb.beunruhigen><de> Es Schien, dass sogar die in den Tempel plötzlich eindringenden Nasenstüber des Verschlusses des Fotoapparates nicht in den Kräften, diese scheue andachtsvolle Einstellung zu beunruhigen.
<G-vec00547-001-s053><disturb.beunruhigen><en> The remained days before childbirth do not disturb a female at all, let she will equip the dwelling to the taste.
<G-vec00547-001-s053><disturb.beunruhigen><de> Die bleibenden Tage beunruhigen Sie bis zur Geburt keinesfalls das Weibchen, wenn auch sie die Behausung nach dem Geschmack gestalten wird.
<G-vec00547-001-s054><disturb.beunruhigen><en> "In order to neglect nothing and considering the geopolitical stake of the moment, an exaggerated media campaign on the Ebola virus is ongoing ""to preoccupy"" and disturb minds in order to distract them with respect to the coming elections."
<G-vec00547-001-s054><disturb.beunruhigen><de> "Um nichts zu vernachlässigen und angesichts des geopolitischen Einsatzes des Momentes, wird eine immense Medienkampagne über den Virus Ebola ausgelöst, um die Geister zu ""beunruhigen"" und Sorgen zu bereiten, um sie bezüglich der bevorstehenden Wahlen aus dem Konzept zu bringen."
<G-vec00547-001-s055><disturb.beunruhigen><en> No one can disturb your happy disposition.
<G-vec00547-001-s055><disturb.beunruhigen><de> Niemand kann euer fröhliches Gemüt beunruhigen.
<G-vec00547-001-s056><disturb.beunruhigen><en> But war wounds that remained in soul, do not know time, even decades later disturb silent pain of memoirs heart.
<G-vec00547-001-s056><disturb.beunruhigen><de> Aber die Wunden des Krieges, was in der Seele blieben, wissen die Zeit nicht, vom leisen Schmerz der Erinnerungen sogar nach den Dutzenden der Jahre beunruhigen das Herz.
<G-vec00547-001-s057><disturb.beunruhigen><en> To find a way home or the nearest snackbar in an unfamiliar place, it is not obligatory to disturb passersby, police officers at all or to look for shop with cards – enough in advance to install the navigator on phone.
<G-vec00547-001-s057><disturb.beunruhigen><de> Um den Weg nach Hause oder die nächste Imbissstube an der unbekannten Stelle zu finden, ist es ganz nicht obligatorisch, der Passanten zu beunruhigen, die Polizisten oder das Geschäft mit den Karten – genug im Voraus zu suchen, der Navigator auf das Telefon festzustellen.
<G-vec00547-001-s058><disturb.beunruhigen><en> They began to disturb both the balloons very much.
<G-vec00547-001-s058><disturb.beunruhigen><de> Diese fingen an, die beiden Ballons sehr zu beunruhigen.
<G-vec00547-001-s059><disturb.beunruhigen><en> During this period it is better not to disturb a female — she perfectly will cope with everything.
<G-vec00547-001-s059><disturb.beunruhigen><de> In dieser Periode ist es besser nicht, das Weibchen zu beunruhigen — sie ist mit allem selbst schön wird zurechtkommen.
<G-vec00547-001-s060><disturb.beunruhigen><en> In I part written in the form of a toccata, with its continuous motornostju, disturb the images, forcing to recollect the Liturgical symphony of Oneggera and Shostakovich's Seventh symphony for these images are sated by cold, mechanically invariable movement of spiteful brutal character.
<G-vec00547-001-s060><disturb.beunruhigen><de> Im I. Teil, der in Kondition tokkaty geschrieben ist, mit ihrer ununterbrochen motornostju, beunruhigen die Gestalten, zwingend, sich über die Liturgitscheski Sinfonie Oneggera und der Siebenten Sinfonie Schostakowitschs zu erinnern, weil diese Gestalten mit der kalten, mechanisch unveränderlichen Bewegung des bösen unmenschlichen Charakters gesättigt sind.
<G-vec00547-001-s061><disturb.beunruhigen><en> I prefer to accept things, even if they disturb my personal ideas, but I understand why questions are asked and I believe that, according to what I have been able to see, there are in this phenomenon of Medjugorje essential things, but there are also parasites.
<G-vec00547-001-s061><disturb.beunruhigen><de> Ich nehme lieber Dinge an, auch wenn sie meine persönlichen Ideen beunruhigen, aber ich verstehe, dass Fragen gestellt werden und glaube, dass es nach dem, was ich sehen konnte, in diesem Phänomen Medjugorje wichtige Dinge gibt, aber es gibt auch Parasiten.
<G-vec00547-001-s062><disturb.beunruhigen><en> To search for them and we did not begin to disturb.
<G-vec00547-001-s062><disturb.beunruhigen><de> Zu suchen und Sie wir zu beunruhigen wurden nicht.
<G-vec00547-001-s063><disturb.beunruhigen><en> At whom the child is engaged houses in music, someone has a house cinema and at viewing of films would not like to disturb house, the head is ill someone, and he wishes to retire from the noisy company.
<G-vec00547-001-s063><disturb.beunruhigen><de> Bei wem sich das Kind zu Hause mit der Musik beschäftigt, jemand hat das häusliche Kino und bei der Durchsicht der Filme wollte häuslich nicht beunruhigen, bei jemandem tut der Kopf weh, und er will sich von der lärmenden Gesellschaft zurückziehen.
<G-vec00547-001-s064><disturb.beunruhigen><en> Therefore very conflicting opinions from critics, paid for their evaluations, disturb me.
<G-vec00547-001-s064><disturb.beunruhigen><de> Deshalb beunruhigen mich sehr widersprüchliche Meinungen von Kritikern, die dafür bezahlt werden.
<G-vec00547-001-s076><disturb.stören><en> The bacteria ARD are not numerous but it is precisely them that provoke complications. It is hard to define the bacterial origin of ARD as the symptoms of bacterial and virus processes are similar (fever, a cold, cough, sore throat), therefore, to be on the safe side, a doctor prescribes antibiotics irrelevant in case of viral infection and in most cases are harmful because they disturb biocenosis of airways and metabolism in general.
<G-vec00547-001-s076><disturb.stören><de> Es ist kompliziert solche Diagnose wie „akute Respirationskrankheit bakterieller Ursache“ zu stellen, weil die Symptome von bakteriellen und Virusvorgängen ähnlich sind (Fieber, Schnupfen, Husten, Halsschmerzen), deshalb, um sich gegen jedes Risiko abuisichern, verschreibt der Arzt Antibiotika, die bei der Virusinfektion nutzlos, und in den meisten Fällen sogar schädlich sind, weil sie die Biozönose der Atemwege und den Stoffwechsel im allgemeinen stören.
<G-vec00547-001-s077><disturb.stören><en> Sometimes reflection do disturb people and they start judging themselves up in this alone time so, it is preferred that people at that time should prefer to do or attend gatherings and meetings.
<G-vec00547-001-s077><disturb.stören><de> Manchmal sind die Leute Reflexion stören, und sie beginnen zu urteilen, sich in dieser Zeit allein, so, wird es bevorzugt, dass die Menschen damals Versammlungen zu tun oder besuchen sollten bevorzugen und Treffen.
<G-vec00547-001-s082><disturb.stören><en> We have therefore written instructions to accompany this video, and there is no sound to disturb while watching.
<G-vec00547-001-s082><disturb.stören><de> Wir haben daher schriftliche Erklärungen, die die Videos begleiten und Sie werden beim Anschauen des Videos nicht durch Geräusche gestört.
<G-vec00547-001-s083><disturb.stören><en> There is nothing to disturb you.
<G-vec00547-001-s083><disturb.stören><de> Hier wird man durch nichts gestört.
<G-vec00547-001-s084><disturb.durcheinanderbringen><en> Treatment of this type with mineral fertilisers can disturb the steady rhythm in the life of the soil.
<G-vec00547-001-s084><disturb.durcheinanderbringen><de> Diese Vorgehensweise, also das Düngen mit mineralischen Düngern, kann das Gleichgewicht in der Erde durcheinander bringen.
<G-vec00547-001-s085><disturb.durcheinanderbringen><en> However, changed weather conditions or unclear traffic situations might disturb this interaction.
<G-vec00547-001-s085><disturb.durcheinanderbringen><de> Allerdings können veränderte Witterungsbedingungen oder unübersichtliche Verkehrssituationen dieses Zusammenspiel durcheinander bringen.
<G-vec00547-001-s086><disturb.durcheinanderbringen><en> Emotional tension may disturb your life during this time, and you may need to struggle to break free of old patterns of relating.
<G-vec00547-001-s086><disturb.durcheinanderbringen><de> Emotionale Spannungen könnten Ihr Leben in dieser Phase durcheinander bringen, und Sie müssen vielleicht kämpfen, um sich von alten Beziehungsmustern zu befreien.
<G-vec00547-001-s089><disturb.stören><en> You're right, you wouldn’t disturb the fish and you could approach much closer.
<G-vec00547-001-s089><disturb.stören><de> Richtig, die Fische werden nicht mehr gestört und Du kommst näher an sie heran.
<G-vec00547-001-s090><disturb.stören><en> When he tries to find out more about its origins, he learns that the people around him are not at all interested in helping him and don't want him to disturb them in their daily routines.
<G-vec00547-001-s090><disturb.stören><de> Auf der Suche nach Informationen zu deren Herkunft muss er jedoch bald feststellen, dass seine Mitmenschen nicht daran interessiert sind, ihm weiterzuhelfen, sondern sich vor allem in ihrer alltäglichen Routine gestört fühlen.
<G-vec00547-001-s091><disturb.stören><en> Namely In the Florijan workshop there are people with special needs and we must take care not to disturb them.
<G-vec00547-001-s091><disturb.stören><de> Die Werkstatt Florian beherbergt nämlich Menschen mit besonderen Bedürfnissen und wir achten selbstverständlich darauf, dass die Abläufe dort nicht gestört werden.
<G-vec00547-001-s092><disturb.stören><en> Apple Watch Series 3 Garmin Vivoactive 3 The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s092><disturb.stören><de> Apple Watch Series 3 Garmin Vivoactive 3 Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s093><disturb.stören><en> There are cases when in such a remission the fibroid did not disturb throughout life.
<G-vec00547-001-s093><disturb.stören><de> Es gibt Fälle, in denen bei einer solchen Remission das Myom während des gesamten Lebens nicht gestört wurde.
<G-vec00547-001-s094><disturb.stören><en> Holiday House Butterflies of the Tatras – the perfect place for a family vacation where you will not disturb anyone.
<G-vec00547-001-s094><disturb.stören><de> Ferienhaus Butterflies der Tatra – der perfekte Ort für einen Familienurlaub, wo man nicht gestört wird jemand.
<G-vec00547-001-s095><disturb.stören><en> Garmin Vivomove HR Nokia Steel HR 36mm The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s095><disturb.stören><de> Garmin Vivomove HR Nokia Steel HR 36mm Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s096><disturb.stören><en> Samsung Gear S3 Frontier LTE Samsung Gear Sport The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s096><disturb.stören><de> Samsung Gear S3 Frontier LTE Samsung Gear Sport Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s097><disturb.stören><en> Huawei Watch 2 Classic Polar Vantage V (medium / large) The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s097><disturb.stören><de> Huawei Watch 2 Classic Polar Vantage V (medium / large) Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s098><disturb.stören><en> These observation paths do not disturb the wild animals in their respective reservations.
<G-vec00547-001-s098><disturb.stören><de> Dabei werden die Wildtiere in dem entsprechenden Reservat nicht gestört.
<G-vec00547-001-s099><disturb.stören><en> They seemed to be a family with small children who liked running around in their place and the parents apparently couldn't keep their children to be quiet so as not to disturb other occupants in the building.
<G-vec00547-001-s099><disturb.stören><de> Sie schienen eine Familie mit kleinen Kindern, die gern in der Wohnung herumliefen, zu sein und die Eltern konnten Ihre Kinder nicht ruhig stellen, sodass sie die anderen Bewohner des Gebäudes nicht gestört hätten.
<G-vec00547-001-s100><disturb.stören><en> Many of us think that this happens exclusively in older men, but in fact, problems with potency often disturb young men.
<G-vec00547-001-s100><disturb.stören><de> Viele von uns denken, dass es nur bei älteren Männern ist, aber das Problem mit der Potenz oft gestört und jungen Leute in der Tat.
<G-vec00547-001-s101><disturb.stören><en> This means that that here on a daily basis it is not recommended to play loud music, make excessive noise or behave loudly in the company not to disturb other visitors who have come to enjoy the nature and the quietness of the Gauja.
<G-vec00547-001-s101><disturb.stören><de> Das bedeutet, dass rs im Alltag nicht empfohlen wird laut Musik zu spielen, zu stark zu lärmen oder laut in einer Clique zu unterhalten, damit andere Besucher nicht gestört werden, die Natur und Ruhe von Gauja genießen wollen.
<G-vec00547-001-s102><disturb.stören><en> Biologists are concerned that clouding of the near-surface waters could disturb the growth of algae and other planktonic organisms.
<G-vec00547-001-s102><disturb.stören><de> Biologen befürchten nämlich, dass durch eine Trübung der oberflächennahen Gewässer das Wachstum von Algen und anderen Planktonorganismen gestört werden könnte.
<G-vec00547-001-s103><disturb.stören><en> Mobvoi TicWatch Pro Samsung Gear S3 Frontier LTE The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s103><disturb.stören><de> Mobvoi TicWatch Pro Samsung Gear S3 Frontier LTE Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s104><disturb.stören><en> This process does not disturb the filling of PETRA III and consequently the photon science user run.
<G-vec00547-001-s104><disturb.stören><de> Außerdem wird die Versorgung von PETRA III und damit der Photon-Science-Nutzerbetrieb nicht gestört.
<G-vec00547-001-s105><disturb.stören><en> Garmin Vivoactive 3 Huawei Watch 2 Classic The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s105><disturb.stören><de> Garmin Vivoactive 3 Huawei Watch 2 Classic Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s106><disturb.stören><en> And thanks to adjustable resource usage restrictions, any of the scheduled tasks won't ever disturb you while you work or play on your computer.
<G-vec00547-001-s106><disturb.stören><de> Und dank der einstellbaren Ressourcennutzungsbeschränkungen werden Sie während der Arbeit oder der Wiedergabe auf Ihrem Computer durch keine der geplanten Aufgaben gestört.
<G-vec00547-001-s107><disturb.stören><en> It is quite possible that if a too intense Ananda is allowed before the purity and peace are in the nature, it may disturb the system — though I don't know whether there is any instance of madness as a consequence.
<G-vec00547-001-s107><disturb.stören><de> * Es ist durchaus möglich, dass das Körpersystem gestört wird, wenn man einen zu intensiven Ananda zulässt, bevor sich Reinheit und Friede in der Natur gefestigt haben; es ist mir aber kein Fall von Wahnsinn als Folgeerscheinung bekannt.
<G-vec00547-001-s108><disturb.stören><en> Garmin Vivomove HR MyKronoz ZeSport2 The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s108><disturb.stören><de> Garmin Vivomove HR MyKronoz ZeSport2 Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s109><disturb.stören><en> Animal owners are required to pick up their animals’ physiological needs and make sure that they do not disturb the other guests of the campsite.
<G-vec00547-001-s109><disturb.stören><de> Die Besitzer sind verpflichtet die körperlichen Bedürfnisse ihrer Tiere zu entsorgen und sicherzustellen, dass die anderen Gäste des Campingplatzes nicht gestört werden.
<G-vec00547-001-s110><disturb.stören><en> Garmin Vivosmart 4 (large) The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s110><disturb.stören><de> Garmin Vivosmart 4 (large) Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s111><disturb.stören><en> The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s111><disturb.stören><de> Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s112><disturb.stören><en> Apple Watch Series 3 Fitbit Versa The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s112><disturb.stören><de> Apple Watch Series 3 Fitbit Versa Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s113><disturb.stören><en> Don't disturb breeding birds.
<G-vec00547-001-s113><disturb.stören><de> Brütende Vögel dürfen nicht gestört werden.
<G-vec00547-001-s114><disturb.stören><en> Samsung Galaxy Watch Samsung Gear Sport The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s114><disturb.stören><de> Samsung Galaxy Watch Samsung Gear Sport Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s115><disturb.stören><en> Fitbit Versa Samsung Galaxy Watch The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s115><disturb.stören><de> Fitbit Versa Samsung Galaxy Watch Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s116><disturb.stören><en> If an interested visitor wants to ask a question to the judge, he is advised not to disturb the judge.
<G-vec00547-001-s116><disturb.stören><de> Will ein interessierter Zuschauer einen Richter etwas fragen, wird ihm bedeutet, der Richter wolle nicht gestört werden.
<G-vec00547-001-s117><disturb.stören><en> Garmin Fenix 5S Suunto 9 The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s117><disturb.stören><de> Garmin Fenix 5S Suunto 9 Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s118><disturb.stören><en> MyKronoz ZeSport2 Samsung Galaxy Watch The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s118><disturb.stören><de> MyKronoz ZeSport2 Samsung Galaxy Watch Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s119><disturb.stören><en> Garmin Vivomove HR Samsung Galaxy Watch The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s119><disturb.stören><de> Garmin Vivomove HR Samsung Galaxy Watch Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s120><disturb.stören><en> It is advisable for them not to swim away from the island due to unpredictable sea currents and good dolphins, which are not allowed to disturb.
<G-vec00547-001-s120><disturb.stören><de> Den Schwimmern wird ans Herz gelegt sich nicht allzu weit von der Küste zu entfernen, da die Meeresströmungen ständig wechseln und sich in der Nähe Delfine befinden, die nicht gestört werden dürfen.
<G-vec00547-001-s121><disturb.stören><en> Apple Watch Series 4 MyKronoz ZeSport2 The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s121><disturb.stören><de> Apple Watch Series 4 MyKronoz ZeSport2 Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s122><disturb.stören><en> Garmin Vivomove HR Huawei Watch GT The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s122><disturb.stören><de> Garmin Vivomove HR Huawei Watch GT Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s123><disturb.stören><en> Fitbit Charge 3 Garmin Vivomove HR The device can wake you using vibration, so as not to disturb anyone else sleeping in the room.
<G-vec00547-001-s123><disturb.stören><de> Fitbit Charge 3 Garmin Vivomove HR Das Gerät kann Sie durch Vibration wecken, sodass keine anderen schlafenden Personen im Raum gestört werden.
<G-vec00547-001-s124><disturb.stören><en> Therefore, I will continue to disturb people from their tranquillity in order to keep them awake.
<G-vec00547-001-s124><disturb.stören><de> Und darum störe Ich die Menschen immer wieder aus ihrer Ruhe auf, um sie wach zu halten.
<G-vec00547-001-s125><disturb.stören><en> Don't disturb breeding pair during the heat cycle.
<G-vec00547-001-s125><disturb.stören><de> Störe das Zuchtpaar während der Hitze nicht.
<G-vec00547-001-s126><disturb.stören><en> And when the greatest battle takes place, it is unforgivable to disturb the formation.
<G-vec00547-001-s126><disturb.stören><de> Und wenn die größte Schlacht ausgetragen wird, ist es unverzeihlich, die Formation zu stören.
<G-vec00547-001-s127><disturb.stören><en> Treaded tires, especially when speeding around curves, can cause erosion of the soil and disturb habitats.
<G-vec00547-001-s127><disturb.stören><de> Runderneuerte Reifen, vor allem, wenn die Beschleunigung in Kurven, kann die Bodenerosion verursachen und stören Lebensräume.
<G-vec00547-001-s128><disturb.stören><en> Make babies cry in the church. Make children disturb, compel the youths to chat and browse with their mobile phones, shoot arrows of dozing and make people sleep during sermons.
<G-vec00547-001-s128><disturb.stören><de> Während der Predigten bringt Babys zum Weinen, Kinder zum Stören, junge Leute zum Chatten und Surfen mit ihren Handys; und sendet Schlafpfeile, damit die Leute schlafen.
<G-vec00547-001-s129><disturb.stören><en> Be careful that your children do not exceed these limits, disturb other tenants and / or mistreat facilities and garden.
<G-vec00547-001-s129><disturb.stören><de> Achten Sie darauf, dass Ihre Kinder nicht überschreiten diese Grenzen, stören andere Mieter und / oder mißhandeln Einrichtungen und Garten.
<G-vec00547-001-s130><disturb.stören><en> Don't disturb wild life during the trek.
<G-vec00547-001-s130><disturb.stören><de> Bitte nicht stören wildes Leben während des Trekkings.
<G-vec00547-001-s131><disturb.stören><en> These questions disturb many users.
<G-vec00547-001-s131><disturb.stören><de> Diese Fragen stören viele Benutzer.
<G-vec00547-001-s132><disturb.stören><en> Now of course I certainly don´t want to compare my little book of illustrations with these world famous movies, but such pictures of Maasai girls would certainly disturb the balance of the book and would not be appropriate in this situation, since the Maasai do not live a folklore life in reality and their future certainly is everything but rosy.
<G-vec00547-001-s132><disturb.stören><de> Nun will ich natürlich nicht mein kleines Bilderbüchlein mit solchen filmischen Weltereignissen vergleichen, aber solche Bilder von Maasaimädchen würden sicher das Gleichgewicht des Buches stören, und auch der Situation nicht angemessen sein.
<G-vec00547-001-s133><disturb.stören><en> Yes, Mother....In fact, there are many things trying to disturb me.
<G-vec00547-001-s133><disturb.stören><de> Ja... Tatsächlich versuchen viele Dinge, mich zu stören.
<G-vec00547-001-s134><disturb.stören><en> We carefully considered what kind of bonuses should be included in Romantika because we did not want to disturb the atmosphere the album radiates when listened to.
<G-vec00547-001-s134><disturb.stören><de> Wir haben überlegt, was man als Bonus auf die CD packen können, denn wir hatten Angst, die beim Zuhören entstehende Atmosphäre zu stören.
<G-vec00547-001-s135><disturb.stören><en> If they decide to email me anyway, despite my “Do Not Disturb” status, they will be warned that the email probably won’t be read, will be archived and become dusty, and that they’ll have to send a follow up message to me in a few days because I’ll have completely flaked on replying.
<G-vec00547-001-s135><disturb.stören><de> "Wenn sie sich entscheiden, E-Mail mir trotzdem, obwohl ich ""Nicht stören""-Status, werden sie darauf hingewiesen werden, dass die E-Mail wahrscheinlich nicht gelesen werden, werden archiviert und zu staubig, und dass sie sich an ein Follow-up-Mitteilung für mich in ein paar Tagen, da ich völlig Flocken auf Antwort."
<G-vec00547-001-s136><disturb.stören><en> We are eager for a shortcut to get rid of all the symptoms as quick as possible, in order not to disturb our fast-paced modern lifestyle.
<G-vec00547-001-s136><disturb.stören><de> Wir sind begierig nach einer Abkürzung um uns so schnell wie möglich von all unserem Symptomen zu befreien, damit wir unseren schnellen modernen Lebensstil nicht stören.
<G-vec00547-001-s137><disturb.stören><en> "On the boat "" NEW "" can organize all kinds of celebrations, because we did not tied to schedules, do not disturb any neighbors, your group will remain "" together "" throughout the party."
<G-vec00547-001-s137><disturb.stören><de> "Auf dem Schiff ""NOVA"" können alle Arten von Feiern zu organisieren, weil wir nicht um Zeitpläne gebunden, keine Nachbarn zu stören, Ihre Gruppe wird in der ganzen Partei ""zusammen"" bleiben ."
<G-vec00547-001-s138><disturb.stören><en> So many animals to see and do not disturb.
<G-vec00547-001-s138><disturb.stören><de> So viele Tiere zu sehen und nicht zu stören.
<G-vec00547-001-s139><disturb.stören><en> The part of the narrator and the loud notes on the brass give rise to a very interesting rhythm, although the pathos of the narrated text may disturb the modern listener.
<G-vec00547-001-s139><disturb.stören><de> Die Rhythmik des Sprecheranteils und der Schläge der Blechinstrumente ist sehr interessant, obwohl der pathetische Sprechtext den Zuhörer von heute auch stören kann.
<G-vec00547-001-s140><disturb.stören><en> Rhodiola is to avoid the evening because it may disturb sleep.
<G-vec00547-001-s140><disturb.stören><de> Rhodiola ist, um den Abend zu vermeiden, weil sie schlafen können stören.
<G-vec00547-001-s141><disturb.stören><en> External factors like high temperature, high pressure, extreme pH, or solvents can disturb the protein structure and are therefore avoided in FPLC.
<G-vec00547-001-s141><disturb.stören><de> Externe Faktoren wie hohe Temperatur, hoher Druck, extremer pH-Wert oder Lösungsmittel können die Proteinstruktur stören und werden daher bei FPLC vermieden.
<G-vec00547-001-s142><disturb.stören><en> Before playing your slideshow, you might want to turn on Do Not Disturb on your Mac and iOS device .
<G-vec00547-001-s142><disturb.stören><de> "Weitere Informationen Bevor Sie Ihre Präsentation vorführen, können Sie auf Ihrem Mac und iOS-Gerät die Option ""Nicht stören"" aktivieren."
<G-vec00547-001-s143><disturb.stören><en> The truthful colour rendering does not disturb the natural colours of the products.
<G-vec00547-001-s143><disturb.stören><de> Die Farbwiedergabe nicht zu stören die natürlichen Farben der Produkte.
<G-vec00547-001-s144><disturb.stören><en> It is therefore important that people who need to communicate sit near each other while, at the same time, different work groups must be sufficiently separated acoustically not to disturb each other.
<G-vec00547-001-s144><disturb.stören><de> Daher ist es wichtig, dass Personen, welche kommunizieren und gleichzeitig sich in der Nähe anderer Personen befinden, sich nicht gegenseitig stören, sondern eine bestmögliche akustische Privatsphäre vorfinden.
<G-vec00547-001-s145><disturb.stören><en> These structures disturb echolocation calls, and thus the bat's ability to navigate.
<G-vec00547-001-s145><disturb.stören><de> Diese Strukturen stören die Echolokationsrufe und somit die Orientierung der Fledermäuse.
<G-vec00547-001-s146><disturb.stören><en> Do not disturb birds by mimicking calls or song.
<G-vec00547-001-s146><disturb.stören><de> Stören Sie die Vögel nicht, indem sie Rufe und Vogelgesang nachmachen.
<G-vec00547-001-s147><disturb.stören><en> It is a secure space into which other professionals will not wander – they do not disturb sessions in progress.
<G-vec00547-001-s147><disturb.stören><de> Es ist ein sicherer Platz, in den andere Fachleute nicht wandern - sie stören nicht die laufenden Sitzungen.
<G-vec00547-001-s148><disturb.stören><en> They disturb communication but also stimulate it.
<G-vec00547-001-s148><disturb.stören><de> Sie stören die Kommunikation, aber treiben sie auch an.
<G-vec00547-001-s149><disturb.stören><en> So, we are not going to jump straight in to everything that is new that we have been promised, but clearly once we ascend, then all these beautiful changes we've been hearing about like the crystalline buildings, the free energy, the light everywhere, the conditions of joy and happiness and harmony, with none of the lower energies there to disturb it or poison it - they can't exist in that high vibration...so, it will be absolutely beautiful and a happy situation to be in.
<G-vec00547-001-s149><disturb.stören><de> So werden wir nicht einfach hineinspringen in all das Neue, was uns da verheißen wurde, sondern erst mit dem Aufstieg werden all die wunderbaren Veränderungen eintreten, über die wir gehört haben: die kristallinen Bauten, die freie Energie, das LICHT überall, die Voraussetzungen für Freude, Glück und Harmonie – ohne die niederen Energien, die sie stören oder vergiften könnten, denn sie können ja auf jener höheren Frequenz-Ebene nicht existieren; – somit wird es eine absolut wunderschöne und glückliche Situation sein, in der man leben kann.
<G-vec00547-001-s150><disturb.stören><en> Wood's air cleaners have no flashing lights, lit displays or other features that will disturb your sleep.
<G-vec00547-001-s150><disturb.stören><de> Wood's Luftreiniger haben kein Licht, Display oder andere Extras, die Ihren Schlaf stören könnten oder unnötig mehr Strom konsumieren.
<G-vec00547-001-s151><disturb.stören><en> With Do Not Disturb While Driving, iPhone won’t interrupt you with messages, calls or notifications until you reach your destination.
<G-vec00547-001-s151><disturb.stören><de> Mit „Beim Fahren nicht stören“ unterbricht dich dein iPhone nicht mit Nach richten, Anrufen oder Benachrich tigungen, bis du dein Ziel erreicht hast.
<G-vec00547-001-s152><disturb.stören><en> Do Not Disturb eliminates distractions from calls and notifications for a specified period of time.
<G-vec00547-001-s152><disturb.stören><de> Mit „Nicht stören“ wirst du eine bestimmte Zeit lang nicht mehr von Anrufen und Benachrich tigungen abgelenkt.
<G-vec00547-001-s153><disturb.stören><en> Price/Performance Size Great quality, fits perfectly, does not disturb our dog at all, because it is very light.
<G-vec00547-001-s153><disturb.stören><de> Preis-/Leistung Größe Super Qualität, Passt ausgezeichnet, stört unsren Hund gar nicht, da er sehr leicht ist.
<G-vec00547-001-s154><disturb.stören><en> It is the simplest method, which does not disturb the cytoplasmic structure of the recipient.
<G-vec00547-001-s154><disturb.stören><de> Es geht um die einfachste Methode, die die Zytoplasmastruktur der Empfängerin nicht stört.
<G-vec00547-001-s155><disturb.stören><en> If you're in full work mode and need to minimise disruption, you might want to keep your iPhone X face down so the screen doesn't disturb you.
<G-vec00547-001-s155><disturb.stören><de> Wenn Sie in vollem Arbeitsmodus sind und die Störung minimieren müssen, möchten Sie vielleicht Ihr iPhone X mit dem Gesicht nach unten halten, damit der Bildschirm Sie nicht stört.
<G-vec00547-001-s156><disturb.stören><en> But this doesn’t disturb the function at all.
<G-vec00547-001-s156><disturb.stören><de> Dies stört die Funktion jedoch keineswegs.
<G-vec00547-001-s157><disturb.stören><en> The parties involved in the project have again admitted to try to schedule the investment of high importance in Tihany's life so that it will hardly disturb the guests arriving in the tourist season.
<G-vec00547-001-s157><disturb.stören><de> Die Projektparteien haben wieder bestätigt, sie werden alles Mögliche machen, damit die Investition von großer Bedeutung im Leben von Tihany die Besucher kaum stört.
<G-vec00547-001-s158><disturb.stören><en> Another thing that air traffic has done for the airlines to disturb fewer people is that they have added flight paths.
<G-vec00547-001-s158><disturb.stören><de> Eine andere Sache, Flugverkehr für die Fluggesellschaften getan, um weniger Menschen stört ist, dass sie Flugrouten aufgenommen.
<G-vec00547-001-s159><disturb.stören><en> "That sounds mostly somewhat monotonous to nice and doesn't disturb, but is sometimes a bit nerving like ""Dad has got a new home organ""."
<G-vec00547-001-s159><disturb.stören><de> "Das klingt meistens etwas monoton bis ganz nett und stört nicht, aber manchmal auch etwas nervig nach ""Papi hat eine Heimorgel bekommen""."
<G-vec00547-001-s160><disturb.stören><en> Enjoy a lavish celebration attended by up to 220 guests and no one will disturb you.
<G-vec00547-001-s160><disturb.stören><de> Feiern Sie mit bis zu 220 Gästen ein rauschendes Fest und niemand stört Sie.
<G-vec00547-001-s161><disturb.stören><en> Price/Performance Size Fits perfectly and does not disturb at all.
<G-vec00547-001-s161><disturb.stören><de> Preis-/Leistung Größe Passt perfekt und stört überhaupt nicht.
<G-vec00547-001-s162><disturb.stören><en> During such a period of assimilation of the consciousness do not disturb it with problems.
<G-vec00547-001-s162><disturb.stören><de> Während einer solchen Periode der Assimilation des Bewußtseins stört es nicht mit Problemen.
<G-vec00547-001-s163><disturb.stören><en> If the obsession does not disturb you and does not influence on people around, you should not struggle with it, everything is normal.
<G-vec00547-001-s163><disturb.stören><de> Wenn die aufdringliche Idee Sie nicht stört beeinflusst Umgebung nicht, braucht man, mit ihr nicht zu kämpfen, ist alles normal.
<G-vec00547-001-s164><disturb.stören><en> Former chief engineer of Disney ABC TV Group believes, Intelsat plan that does not disturb the system of satellite distribution of content in the US, because the interests of all users.
<G-vec00547-001-s164><disturb.stören><de> Der ehemalige Chefingenieur von Disney ABC-TV-Gruppe glaubt, Intelsat Plan, der nicht das System der Satelliten Verteilung von Inhalten in den USA nicht stört, weil die Interessen aller Nutzer.
<G-vec00547-001-s165><disturb.stören><en> Since it has no loud propeller, it does not disturb animals in their habitat.
<G-vec00547-001-s165><disturb.stören><de> Da er ohne laute Propeller auskommt, stört er Tiere nicht in ihrem Lebensraum.
<G-vec00547-001-s166><disturb.stören><en> It can run smoothly the whole night and does not disturb sleep, on the contrary - it improves its quality and the user becomes more relaxed, the fog allows you to relax and minimize the accumulated stress during the day.
<G-vec00547-001-s166><disturb.stören><de> Es kann die ganze Nacht ohne Probleme laufen und stört den Schlaf nicht, im Gegenteil - es verbessert seine Qualität und der Benutzer wird entspannter, der Nebel ermöglicht es Ihnen, sich zu entspannen und den angesammelten Stress während des Tages zu minimieren.
<G-vec00547-001-s167><disturb.stören><en> It is important that hair did not disturb, and laying was fast and simple.
<G-vec00547-001-s167><disturb.stören><de> Es ist wichtig, dass das Haar nicht stört, und das Verpacken war schnell und einfach.
<G-vec00547-001-s168><disturb.stören><en> That's why in some moments I especially bless celibacy and above all chastity, for example before certain tomboys feminists who thank God does not disturb my male senses putting a strain, as it might disturb a quintessence of beauty and femininity as the Lady Monica Bellucci, putting myself in this sense to the test. Reply
<G-vec00547-001-s168><disturb.stören><de> Aus diesem Grund in einigen Momenten ich besonders Zölibat segnen und vor allem Keuschheit, beispielsweise vor bestimmten tomboys Feministinnen die Gott sei Dank nicht stört meine männlichen Sinne eine Belastung setzen, wie es vielleicht ein Inbegriff von Schönheit und Weiblichkeit als Lady Monica Bellucci stören, setze mich in diesem Sinne auf die Probe.
<G-vec00547-001-s169><disturb.stören><en> Although the openings in the frame, such as for loudspeakers, micro-USB connections or SIM slides, do not look quite as elegant as with an aluminum frame, this does not disturb everyday life.
<G-vec00547-001-s169><disturb.stören><de> Zwar sehen die Öffnungen im Rahmen, etwa für Lautsprecher, Micro-USB-Anschluss oder SIM-Schlitten, nicht ganz so elegant aus wie bei einem Alu-Rahmen, aber das stört im Alltag nicht.
<G-vec00547-001-s170><disturb.stören><en> The beautiful headdress for all witch queens is made of a light material, so that it never gets heavy on your head and does not disturb you while dancing or other activities.
<G-vec00547-001-s170><disturb.stören><de> Der attraktive Hut für alle Hexenköniginnen ist aus einem leichten Material hergestellt, so dass er nie schwer wird auf dem Kopf und Dich nicht beim Tanzen oder sonstigen Aktivitäten stört.
<G-vec00547-001-s171><disturb.stören><en> The simple touch gesture to extend the booking process is minimally invasive and does not disturb our designers and developers during their creative processes.
<G-vec00547-001-s171><disturb.stören><de> Durch die einfache Touch-Geste zur Verlängerung der Buchung ist der Vorgang minimal invasiv und stört so unsere Designer und Developer nicht während ihrer kreativen Prozesse.
<G-vec00547-001-s172><disturb.stören><en> It means that anyone can enjoy the countryside in Sweden as long as they do it responsibly and do not disturb nature.
<G-vec00547-001-s172><disturb.stören><de> Es bedeutet, dass jeder die Natur in Schweden genießen kann, solange man dies verantwortungsbewusst tut und die Natur nicht stört oder zerstört.
<G-vec00547-001-s173><disturb.stören><en> In the next 20 years, we want to invite more people to come and see how it's possible to live in a way that doesn't disturb nature, but regenerates her.
<G-vec00547-001-s173><disturb.stören><de> In den nächsten 20 Jahren wollen wir mehr Menschen einladen können, damit sie eine Lebensweise kennenlernen, welche die Natur nicht stört und zerstört, sondern unterstützt.
<G-vec00547-001-s174><disturb.stören><en> As the cries of the cats that was drilled skull were really heartbreaking, This good son of St. Francis of Assisi, such was the sadistic vivisector Father Agostino Gemelli, before the severed his vocal cords so did not disturb us with their screams of pain, then if anything, during those free operations and scientifically useless torture, perhaps as a good Franciscan even sang: «Laudato they, I' Lord, cum tucte the creature kills » [cf.
<G-vec00547-001-s174><disturb.stören><de> Als die Schreie der Katzen, der Schädel gebohrt wurde, waren wirklich herzzerreißende, Dieser gute Sohn des heiligen Franz von Assisi, so groß war die sadistisch Vivisector Pater Agostino Gemelli, bevor der seine Stimmbänder durchtrennt, so störte uns nicht mit ihren Schmerzensschreie, dann, wenn etwas, während dieses Ablaufs im Betrieb und wissenschaftlich nutzlos Folter, vielleicht als ein guter Franziskaner sang sogar: «Laudato sie, meine' Lord, cum tucte die Kreatur tötet » [CF.
<G-vec00547-001-s175><disturb.stören><en> Though close to the bustling streets of Les Halles, it was on a quiet side street, so there was little noise to disturb my sleep.
<G-vec00547-001-s175><disturb.stören><de> Obwohl in der Nähe der geschäftigen Straßen von Les Halles, lag sie in einer ruhigen Seitenstraße, somit gab es kaum Lärm, der meinen Schlaf störte.
<G-vec00547-001-s176><disturb.stören><en> I asked him whether it didn't disturb him that I had told his children so much about evolution and nothing about creationism.
<G-vec00547-001-s176><disturb.stören><de> Ich fragte ihn, ob es ihn nicht störte, dass ich seinen Kindern so viel über die Evolution und gar nichts über den Kreationismus erzählt hatte.
<G-vec00547-001-s177><disturb.stören><en> The observations started nearly a week after full moon so that the moon did not disturb my observations any more.
<G-vec00547-001-s177><disturb.stören><de> Der Anfang der Beobachtungen lag fast eine Woche nach Vollmond, so dass der Mond nicht mehr störte.
<G-vec00547-001-s178><disturb.stören><en> The compartment door hides in a wall therefore try to consider the correct arrangement of the handle that it did not disturb.
<G-vec00547-001-s178><disturb.stören><de> Die Tür-Abteil verbirgt sich in die Wand, deshalb bemühen Sie sich, die richtige Anordnung des Griffes zu berücksichtigen, damit sie nicht störte.
<G-vec00547-001-s179><disturb.stören><en> "It was namely not so simple to work out the restriction, issued by many as ""reform"", in a social sphere, at the sight of which the hard-hearted occidental observers do not believe their eyes (while they said, it is impossible, that the scientist earn such a low salary), what however did not disturb most of the Hungarian politicians recruited also among the intellectuals, ascertaining, that we must set an end to the comfortable life of the university teachers in the form of a restrictive reform."
<G-vec00547-001-s179><disturb.stören><de> "Es war naemlich nicht so einfach die von vielen als ""Reform"" ausgegebene Restruktion an einer sozialen Sphaere durchzuführen, bei deren Anblick die hartherzigsten westlichen Beobachter den eigenen Augen nicht trauen (indem sie sagen, es ist unmöglich, dass diese Wissenschaftler so einen niedrigen Lohn haben), was aber die meistens ebenfalls aus Intellektuellen rekrutierten ungarischen Politiker nicht daran störte, festzustellen, man muss dem bequemen Leben der Hochschullehrer in der Gestalt einer restriktiven Reform ein Ende setzen."
<G-vec00547-001-s180><disturb.stören><en> Let's tell if one child already goes to school, and the second was not above preschool age yet, it is important to divide accurately a working zone and a zone for games that children did not disturb each other.
<G-vec00547-001-s180><disturb.stören><de> Sagen wir, wenn ein Kind in die Schule schon geht, und zweiter ist aus dem vorschulischen Alter noch nicht hinausgegangen, es ist wichtig, die Arbeitszone und die Zone für die Spiele deutlich zu teilen, damit die Kinder einander nicht störten.
<G-vec00547-001-s181><disturb.stören><en> Materials stack so that they did not disturb to pass of workers and transportation of materials.
<G-vec00547-001-s181><disturb.stören><de> Die Materialien legen so, dass sie den Durchgang der Arbeiter und die Beförderung der Materialien nicht störten.
<G-vec00547-001-s182><disturb.stören><en> We had a rental car and so did not disturb the narrow streets and the partly very bad surface.
<G-vec00547-001-s182><disturb.stören><de> Wir hatten ein Mietauto und so störten die engen Straßen und der teilweise sehr schlechte Belag nicht.
<G-vec00547-001-s183><disturb.stören><en> Also, we saw 'sex tourists' in the hotel, they do not disturb you, but they are also not very kind.
<G-vec00547-001-s183><disturb.stören><de> Auch wir hatten die Sextouristen im Hotel, die zwar nicht störten, aber schön ist das auch nicht gerade.
<G-vec00547-001-s184><disturb.stören><en> The air planes did not disturb us.
<G-vec00547-001-s184><disturb.stören><de> Die Flieger störten uns nicht.
<G-vec00547-001-s185><disturb.stören><en> Meanwhile the social revolutionary measures, carried out via bureaucratic military means, not only did not disturb our, dialectic, definition of the USSR as a degenerated workers' state, but gave it the most incontrovertible corroboration.
<G-vec00547-001-s185><disturb.stören><de> Unterdessen störten die revolutionären sozialen Maßnahmen, die mit Hilfe bürokratischer militärischer Mittel durchgeführt wurden, nicht nur unsere dialektische Definition der UdSSR als degeneriertem Arbeiterstaat nicht, sondern bekräftigten sie unumstößlich.
<G-vec00547-001-s186><disturb.stören><en> She bought some kind of powerful tool and processed the apartment, but many remained alive and continue to disturb.
<G-vec00547-001-s186><disturb.stören><de> Sie kaufte ein mächtiges Werkzeug und bearbeitete die Wohnung, aber viele blieben am Leben und störten weiter.
<G-vec00547-001-s197><disturb.unterbrechen><en> These bumps and lesions on the skin make the individual experiencing them uneasy, and also they could disturb others that remain in close call with the influenced individual.
<G-vec00547-001-s197><disturb.unterbrechen><de> Diese Unebenheiten und auch auf der Haut Wunden machen die Person des Umgang mit ihnen unangenehm, und auch sie können andere unterbrechen, die in engen Kontakt mit der betroffenen Person geben.
<G-vec00547-001-s198><disturb.unterbrechen><en> These bumps and lesions on the skin make the individual experiencing from them awkward, and also they can disturb others who are in close call with the influenced individual.
<G-vec00547-001-s198><disturb.unterbrechen><de> Diese Unebenheiten und auch auf der Haut Wunden machen die Person, mit ihnen zu kämpfen unruhig, und sie können andere unterbrechen, die mit der betroffenen Person in engen Kontakt bleiben.
<G-vec00547-001-s199><disturb.unterbrechen><en> "On those occasions I would instruct my wife or secretary, ""Let no one -- nothing -- disturb me."
<G-vec00547-001-s199><disturb.unterbrechen><de> "Bei diesen Gelegenheiten instruierte ich meine Frau oder meine Sekretärin: ""Laß niemanden und nichts mich unterbrechen."
<G-vec00547-001-s200><disturb.unterbrechen><en> Said the paralytic: “Master, I would not disturb your teaching, but I am determined to be made whole.
<G-vec00547-001-s200><disturb.unterbrechen><de> Der Gelähmte sprach: „Meister, ich würde deine Rede lieber nicht unterbrechen, aber ich bin entschlossen, geheilt zu werden.
<G-vec00547-001-s201><disturb.unterbrechen><en> "Said the paralytic: ""Master, I would not disturb your teaching, but I am determined to be made whole."
<G-vec00547-001-s201><disturb.unterbrechen><de> "Der Gelähmte sprach: ""Meister, ich würde deine Rede lieber nicht unterbrechen, aber ich bin entschlossen, geheilt zu werden."
<G-vec00547-001-s204><disturb.verstören><en> Yet Holl's images disturb in their double faced perspective.
<G-vec00547-001-s204><disturb.verstören><de> Holls Bilder jedoch verstören in ihrer Doppelgesichtigkeit.
<G-vec00547-001-s205><disturb.verstören><en> Countries are striving, at this time, to do the least that will disturb their populace, already uneasy due to weather and crop changes and a world-wide depression not yet called that openly.
<G-vec00547-001-s205><disturb.verstören><de> Länder erstreben zu dieser Zeit, das Geringste zu tun, was ihre Bevölkerung verstören wird, die schon wegen der Wetter- und Ernteveränderungen und einer weltweiten, jedoch nicht so offen benannten Depression unruhig ist.
<G-vec00547-001-s206><disturb.verstören><en> The din may rather disturb those who visit the site through the camera.
<G-vec00547-001-s206><disturb.verstören><de> Das Getöse mag eher diejenigen verstören, die den Platz mittels der Kamera besuchen.
<G-vec00547-001-s207><disturb.verstören><en> Art invests in the street to reinvent it rather than to comment on it, to disturb it rather than to assert it.
<G-vec00547-001-s207><disturb.verstören><de> Kunst auf der Straße sollte diese eher neu erfinden, statt sie nur zu kommentieren, sollte mehr verstören, statt etwas zu bekräftigen.
<G-vec00547-001-s208><disturb.verstören><en> Landings of our craft and open contact will begin to take place, but it will be done with care not to overwhelm you or disturb those who find it difficult to accept us.
<G-vec00547-001-s208><disturb.verstören><de> Es werden allmählich die Landungen unserer Raumschiffe und der offenen Kontakt mit euch stattfinden, doch dies mit Behutsamkeit, um euch nicht zu überfordern oder jene zu verstören, die noch Schwierigkeiten damit haben, uns zu akzeptieren.
<G-vec00547-001-s209><disturb.verstören><en> If, as a bodhisattva, we're trying to make others happy and help them to gain peace of mind, to disturb their minds with harsh words is the opposite, so it makes our bodhisattva behavior decline .
<G-vec00547-001-s209><disturb.verstören><de> Wenn wir als Bodhisattva versuchen, andere glücklich zu machen und ihnen zu innerem Frieden zu verhelfen, handeln wir natürlich genau gegenteilig, wenn wir ihren Geist mit barschen Worten verstören; somit wird dadurch unser Bodhisattva-Verhalten verschlechtert.
<G-vec00547-001-s210><disturb.verstören><en> They are brutal and poetic – dazzle and disturb.
<G-vec00547-001-s210><disturb.verstören><de> Sie sind brutal und poetisch – blenden und verstören.
<G-vec00547-001-s211><disturb.verstören><en> The unfair, using chicanery, terroristic, inhuman, barbarian, tataric, destroying, bestial and unmethodical exceptive laws destroy and disturb the people, bind the liberty, are uncivilized and cement a power, which is not supported by the people but is forced upon it.
<G-vec00547-001-s211><disturb.verstören><de> Die ungerechten, schikanösen, terroristischen, unmenschlichen, barbarischen, tatarischen, vernichtenden, viehischen und planlosen Ausnahmegesetze zerstören und verstören das Volk, fesseln die Freiheit, sind unzivilisiert und zementieren eine Macht, die nicht vom Volk unterstützt wird sondern ihm aufgezwungen ist.
<G-vec00547-001-s212><disturb.stören><en> So, put away your ‘Do Not Disturb’ sign, and the plans for your cabin in the hills.
<G-vec00547-001-s212><disturb.stören><de> Darum verwerft euer „Bitte nicht stören“-Schild und die Pläne für eure Höhle in Hügeln.
<G-vec00547-001-s213><disturb.stören><en> So, put away your 'Do Not Disturb' sign, and the plans for your cabin in the hills.
<G-vec00547-001-s213><disturb.stören><de> "Darum verwerft euer ""Bitte nicht stören""-Schild und die Pläne für eure Höhle in Hügeln."
<G-vec00547-001-s216><disturb.beunruhigen><en> To protect the mountain nature: Do not leave any garbage behind, avoid loud noise, stay on the paths, do not disturb game and animals on pasture, do not touch plants and respect protected areas.
<G-vec00547-001-s216><disturb.beunruhigen><de> Respekt für die Natur - Zum Schutz der Bergnatur: Keine Abfälle zurücklassen, Lärm vermeiden, auf den Wegen bleiben, Wild- und Weidetiere nicht beunruhigen, Pflanzen unberührt lassen und Schutzgebiete respektieren.
<G-vec00547-001-s217><disturb.beunruhigen><en> To protect the natural mountain areas, do not leave rubbish behind, stay on the paths, do not disturb wild animals or livestock, do not touch the plants, and respect protected areas.
<G-vec00547-001-s217><disturb.beunruhigen><de> Zum Schutz der Bergnatur: Keine Abfälle zurücklassen, Lärm vermeiden, auf den Wegen bleiben, Wild- und Weidetiere nicht beunruhigen, Pflanzen unberührt lassen und Schutzgebiete respektieren.
<G-vec00372-002-s019><disturb.aufstören><en> Everything is to serve to that end, to disturb men from their indifferent state; to turn their thoughts towards the forthcoming, of which they certainly have knowledge, only do not believe in it.
<G-vec00372-002-s019><disturb.aufstören><de> Alles soll nur dazu dienen, die Menschen aus ihrem gleichgültigen Zustand aufzustören, ihre Gedanken hinzuwenden auf das Bevorstehende, von dem sie wohl Kenntnis haben, nur nicht daran glauben.
<G-vec00372-002-s020><disturb.aufstören><en> But now they shall clearly hear My voice and not be able to close their ears, for humanity's indifference motivates Me to disturb them and shake them out of their tranquillity, their worldly spirit.... so that no one will be able to claim that he received no warning.
<G-vec00372-002-s020><disturb.aufstören><de> Nun aber sollen sie Meine Stimme deutlich hören und ihre Ohren nicht verschließen können, denn die Gleichgültigkeit der Menschheit veranlaßt Mich dazu, sie aufzustören und ihre Ruhe, ihren Weltgeist zu erschüttern.... auf daß keiner sagen kann, ungewarnt geblieben zu sein.
<G-vec00372-002-s021><disturb.beeinflussen><en> You should also use a condom when you have sex. This is because the alkaline pH value of semen can disturb the acidic environment of the vagina.
<G-vec00372-002-s021><disturb.beeinflussen><de> Verwenden Sie zudem während des Geschlechtsverkehrs ein Kondom, denn auch Sperma kann den Säuregehalt der Scheide beeinflussen.
<G-vec00372-002-s022><disturb.beeinflussen><en> I was afraid that it would have too many weak points or even worse, it could disturb my image of Roman / Greek mythology (because of the maze).
<G-vec00372-002-s022><disturb.beeinflussen><de> Ich hatte Angst, dass es zu viele Schwächen hätte oder eben noch schlimmer, es meine Liebe für die Römische/ Griechische Mythologie beeinflussen könnte (wegen des Labyrinths).
<G-vec00372-002-s028><disturb.beeinträchtigen><en> Possible movement of water while measuring will not disturb the accuracy because the signalling system can be turned off when needed.
<G-vec00372-002-s028><disturb.beeinträchtigen><de> Eine mögliche Bewegung von Wasser während der Messung beeinträchtigt die Genauigkeit nicht, da das Signalsystem bei Bedarf abgeschaltet werden kann.
<G-vec00372-002-s029><disturb.beeinträchtigen><en> At the same time, the EU wants to safeguard some core principles: protecting the autonomy of its decision-making process; making sure that a non-member of the Union cannot have the same benefits as a member; and following on from that, ensuring that the settlement with the UK does not disturb defence relationships with other third countries.
<G-vec00372-002-s029><disturb.beeinträchtigen><de> Gleichzeitig will die EU einige Grundprinzipien wahren: die Autonomie ihres Entscheidungsprozesses, den Grundsatz, dass ein Nicht-Mitglied der Union nicht dieselben Vorzüge wie ein Mitglied genießen kann, und darauf aufbauend die Sicherheit, dass die Einigung mit Großbritannien die Verteidigungsbeziehungen zu anderen Drittländern nicht beeinträchtigt.
<G-vec00372-002-s030><disturb.beeinträchtigen><en> Feelings of frustration are likely to disturb your personal life right now, and you may experience disappointment, indecision or hurt in your close relationships.
<G-vec00372-002-s030><disturb.beeinträchtigen><de> Ihr Privatleben könnte jetzt von Frustrationen beeinträchtigt werden, und Sie erleben vielleicht Enttäuschungen, Unentschlossenheit oder Verletzungen in engen Beziehungen.
<G-vec00372-002-s034><disturb.belästigen><en> Disrupt the flow of forums, events, or other Program activities with vulgar language, abusiveness, use of excessive shouting [all caps] in an attempt to disturb other users, "spamming" or flooding [posting repetitive text].
<G-vec00372-002-s034><disturb.belästigen><de> Den Ablauf von Foren, Events oder anderen Programmaktivitäten mit vulgärer Sprache, Beleidigungen, übertriebener Verwendung der Großschreibung („Shouting“) beeinträchtigen, mit dem Ziel andere Teilnehmer zu belästigen oder mit Spam-Texten zu überhäufen (Posten sich wiederholender Texte).
<G-vec00372-002-s035><disturb.belästigen><en> Entry can be denied if there is a reasonable assumption that the patron will interrupt the performance or disturb other patrons.
<G-vec00372-002-s035><disturb.belästigen><de> Der Zutritt kann verweigert werden, wenn die begründete Vermutung besteht, dass der Besucher die Vorstellung stören oder andere Besucher belästigen wird.
<G-vec00372-002-s037><disturb.belästigen><en> - This App can emit strobe light that might disturb people with epilepsy.
<G-vec00372-002-s037><disturb.belästigen><de> Hinweis: Diese App kann Stroboskoplicht ausstrahlen, das Personen mit Epilepsie belästigen kann.
<G-vec00372-002-s038><disturb.belästigen><en> In case 8.0 is already running, i.e not crashing when starting Firefox, this update doesn't really help anything, and we're avoiding to send people an update when they have no benefit of it, so we don't disturb them.
<G-vec00372-002-s038><disturb.belästigen><de> Wenn 8.0 schon läuft, also nicht beim Start abstürzt, dann bringt dieses Update nicht wirklich etwas, und Leute ein Update zu schicken, das nichts bringt, ist eher kontraproduktiv, wir sollten sie damit nicht belästigen.
<G-vec00372-002-s039><disturb.beunruhigen><en> 44 “But reports out of the east* and out of the north will disturb him, and he will go out in a great rage to annihilate and to devote many to destruction.
<G-vec00372-002-s039><disturb.beunruhigen><de> 44 Doch Berichte aus dem Osten* und aus dem Norden werden ihn beunruhigen, und er wird rasend vor Wut ausziehen, um viele auszulöschen und restlos zu vernichten*.
<G-vec00372-002-s040><disturb.beunruhigen><en> Understand that because you do not see what should happen, many emotions are experienced by you which either please or disturb you.
<G-vec00372-002-s040><disturb.beunruhigen><de> Verstehe, dass du, weil du nicht siehst, was geschehen sollte, viele Emotionen erlebst, die dich entweder erfreuen oder beunruhigen.
<G-vec00372-002-s057><disturb.führen><en> It can increase your risk of high blood pressure and diabetes, and disturb your sleep.
<G-vec00372-002-s057><disturb.führen><de> Sie können die Gefahr von Bluthochdruck und Diabetes erhöhen und zu Schlafstörungen führen.
<G-vec00372-002-s058><disturb.führen><en> Additionally, the NK cells recognize aged cells in the body that concentrate in older tissue and can disturb the metabolism.
<G-vec00372-002-s058><disturb.führen><de> Zusätzlich können die NK-Zellen minderwertige Zellen im Körper erkennen, die sich im alternden Gewebe anreichern und zu Stoffwechselstörungen führen können.
<G-vec00372-002-s109><disturb.stören><en> Prepare ahead of time so you don't disturb the mother and babies for the first week after birth.
<G-vec00372-002-s109><disturb.stören><de> Bereite alles im Voraus vor, damit du die Mutter und die Babys in der ersten Woche nach der Geburt nicht störst.
<G-vec00372-002-s110><disturb.stören><en> He, who’ll rip your head off if you disturb his sleep.
<G-vec00372-002-s110><disturb.stören><de> Er, der dir deinen Kopf abreißt, wenn du seinen Schlaf störst.
<G-vec00372-002-s142><disturb.verstören><en> The good news is that you can discover how to be a Yes to how your life is unfolding in the moment and then miraculously, disturbing forces cease to disturb.
<G-vec00372-002-s142><disturb.verstören><de> Die gute Nachricht ist, dass du entdecken kannst, wie es ist, ein Ja dazu zu sein, wie sich dein Leben im Augenblick entfaltet und dann auf wunderbare Weise störende Kräfte aufhören zu verstören.
<G-vec00372-002-s143><disturb.verstören><en> The thought of the finiteness should not paralyze us nor disturb.
<G-vec00372-002-s143><disturb.verstören><de> Der Gedanke sollte uns weder lähmen noch verstören.
