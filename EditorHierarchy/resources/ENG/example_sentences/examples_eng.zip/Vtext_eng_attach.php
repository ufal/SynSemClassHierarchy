<G-vec00407-001-s032><attach.befestigen><en> Let's attach the sheet edge to a bottom an adhesive tape or glue.
<G-vec00407-001-s032><attach.befestigen><de> Wir werden den Rand des Blattes am Grund vom Klebeband oder dem Leim befestigen.
<G-vec00407-001-s033><attach.befestigen><en> Further it is necessary only to hide under decorative caps of a junction of threads and to attach a fastener to a ready necklace.
<G-vec00407-001-s033><attach.befestigen><de> Weiter bleibt es nur übrig, unter dekorativ kolpatschkami die Verbindungsstellen der Fäden zu verbergen und, am fertigen Kollier den Verschluss zu befestigen.
<G-vec00407-001-s034><attach.befestigen><en> When the connector is housed in the body, the cable becomes a loop that allows you to attach the power bank to a keychain or other accessories.
<G-vec00407-001-s034><attach.befestigen><de> Wenn der Stecker im Gehäuse untergebracht ist, wird das Kabel zu einer Schlaufe, mit der Sie das Netzteil am Schlüsselbund oder anderen Zubehörteilen befestigen können.
<G-vec00407-001-s035><attach.befestigen><en> With these you can attach this mysterious mask to your head.
<G-vec00407-001-s035><attach.befestigen><de> Mit diesen kannst du diese geheimnisvolle Maske gut am Kopf befestigen.
<G-vec00407-001-s036><attach.befestigen><en> The Basil Magnolia Saddle Cover is available in beautiful teal blue and is easy to attach to the saddle of your bike.
<G-vec00407-001-s036><attach.befestigen><de> Der Basil Magnolia Sattelüberzug ist in der Farbe blau erhältlich und lässt sich einfach am Sattel Ihres Fahrrads befestigen.
<G-vec00407-001-s037><attach.befestigen><en> Take advantage of a convenient and practical way to attach your phone to the car dashboard.
<G-vec00407-001-s037><attach.befestigen><de> Nutzen Sie die praktische und praktische Möglichkeit, Ihr Telefon am Armaturenbrett des Fahrzeugs zu befestigen.
<G-vec00407-001-s038><attach.befestigen><en> Good to know:Both bags are quick and easy to attach and remove again with the Legend Gear SLS Saddle Strap, which can be ordered separately.
<G-vec00407-001-s038><attach.befestigen><de> Gut zu wissen:Beide Taschen lassen sich mit dem separat erhältlichen Legend Gear Satteltaschen-Halter SLS mit wenigen Handgriffen am Motorrad befestigen und abnehmen.
<G-vec00407-001-s039><attach.befestigen><en> Comes complete with scabbard and button to attach to belt.
<G-vec00407-001-s039><attach.befestigen><de> Mit dem Knopf lässt sich das Schwert am Gürtel befestigen.
<G-vec00407-001-s040><attach.befestigen><en> "In particular, for fastening it is possible to use polyurethane foam, glue ""liquid nails"" or ""Dragon"". After material is reliably attached to a door cloth, from above it is possible to attach a piece of the laminated DVP of the corresponding size or to use any obivochny material."
<G-vec00407-001-s040><attach.befestigen><de> "Insbesondere kann man für die Befestigung den Montageschaum, den Leim «die flüssigen Nägel» oder ""der Drache"" verwenden., Nachdem das Material am Türleinen sicher befestigt ist, kann man das Stück laminirowannogo DWP des entsprechenden Umfanges oben befestigen oder, irgendwelchen obiwotschnyj das Material zu verwenden."
<G-vec00407-001-s041><attach.befestigen><en> You also get two stroller clips, so you can easily attach your new favorite bag to the stroller.
<G-vec00407-001-s041><attach.befestigen><de> Außerdem bekommt du noch zwei Kinderwagenclips, damit du deine neue Lieblingstasche ganz einfach am Kinderwagen befestigen kannst.
<G-vec00407-001-s042><attach.befestigen><en> You can either carry the bag with the padded shoulder strap or simply attach it to the i2 frame.
<G-vec00407-001-s042><attach.befestigen><de> Du kannst die Tasche entweder mit dem gepolsterten Schultergurt tragen oder diese auch einfach am Gestell des i2 befestigen.
<G-vec00407-001-s043><attach.befestigen><en> You can easily attach the basket to your handlebars with the Basil KF handlebar holder (sold separately).
<G-vec00407-001-s043><attach.befestigen><de> Auf unserer Webseite findest du den Basil KF Lenkerhalter, mit dem du den Korb einfach am Lenker befestigen kannst.
<G-vec00407-001-s044><attach.befestigen><en> To attach them to each other pins.
<G-vec00407-001-s044><attach.befestigen><de> Ihr Freund am Freund von den Stecknadeln zu befestigen.
<G-vec00407-001-s045><attach.befestigen><en> I sew historic bustle dresses and I was looking for a solution to gather up the top coat, where it is not necessary to attach it to the petticoat.
<G-vec00407-001-s045><attach.befestigen><de> Ich nähe historische Tournüren-Kleider und war auf der Suche nach einer Lösung zum Raffen des Überrocks, bei der es nicht nötig ist, den Überrock am Unterrock zu befestigen.
<G-vec00407-001-s065><attach.befestigen><en> The easiest way of sealing the screen is to attach stencils from papers or foils to it.
<G-vec00407-001-s065><attach.befestigen><de> Die einfachste Methode ist, an der Siebunterseite präparierte Papiere oder Schneidefilme zu befestigen, aus denen das Motiv scherenschnittartig herausgearbeitet wurde.
<G-vec00407-001-s066><attach.befestigen><en> Attach notices or photos quickly and easily to your pinboard or notice board with these pins.
<G-vec00407-001-s066><attach.befestigen><de> An einer Pinnwand oder einem Memoboard genutzt, lassen sich mit den Pins Notizzettel und Fotos schnell und einfach befestigen.
<G-vec00407-001-s067><attach.befestigen><en> Located in the grass or on the supports they attach to any corner of the earth charm.
<G-vec00407-001-s067><attach.befestigen><de> Das Hotel liegt im Gras oder auf den Stützen sie an jeder Ecke der Erde Charme befestigen.
<G-vec00407-001-s068><attach.befestigen><en> Finally, a special cement-based adhesive is used to attach the veneers.
<G-vec00407-001-s068><attach.befestigen><de> Am Ende werden wir mit einem speziellen Klebezement die Veneers an den Zähnen befestigen.
<G-vec00407-001-s069><attach.befestigen><en> Supported by new sensors Attach to the back of the back cover Watch 4 and a processor more powerful, applications dedicated to outdoor activities and sports have been greatly developed.
<G-vec00407-001-s069><attach.befestigen><de> Unterstützt von neue Sensoren An der Rückseite der hinteren Abdeckung befestigen Uhr 4 und ein Prozessor leistungsstärkere Anwendungen, die sich für Outdoor-Aktivitäten und Sportarten einsetzen, wurden stark entwickelt.
<G-vec00407-001-s070><attach.befestigen><en> This LED / LCD / Plasma TV wall bracket is supplied with all necessary materials to easily attach it to the wall.
<G-vec00407-001-s070><attach.befestigen><de> Diese LED / LCD / Plasma TV-Wandhalterung wird mit allen notwendigen Materialien geliefert, um sie einfach an der Wand zu befestigen.
<G-vec00407-001-s071><attach.befestigen><en> The bag is almost ready, it is necessary only to attach to it suitable handles.
<G-vec00407-001-s071><attach.befestigen><de> Die Tasche ist tatsächlich fertig, es bleibt nur übrig, an ihr die herankommenden Griffe zu befestigen.
<G-vec00407-001-s072><attach.befestigen><en> A favourite pastime for many seafaring scientists (worldwide), is to paint styrofoam cups, attach them to their equipment and to send everything to the bottom of the sea.
<G-vec00407-001-s072><attach.befestigen><de> Eine der Lieblingsbeschäftigungen vieler seefahrender Wissenschaftler*innen (weltweit) ist es Styroportrinkbecher zu bemalen, an den Geräten zu befestigen und in die Tiefsee hinab zu lassen.
<G-vec00407-001-s073><attach.befestigen><en> Thanks to the mount as a combination of eye and crook, you can attach the Trammel Hook to a tripod or at a crossbar over your fire cooking place.
<G-vec00407-001-s073><attach.befestigen><de> Dank der praktischen Aufhängung – einer Kombination aus Öse und einer Biegung – kannst du den Kesselhaken sowohl an deinem Dreibein als auch an der Querstange deiner Kochstelle über dem Feuer befestigen.
<G-vec00407-001-s074><attach.befestigen><en> That who hangs up posters or the similar materials, calculated that they can be changed, we recommend to attach to a wall a lath, using screws with shkantami (drawing in the middle on the right see), we bore through in a lath small apertures.
<G-vec00407-001-s074><attach.befestigen><de> Von dem, man wer die Plakate oder die ähnlichen Materialien, die auf berechnet sind hängt, dass sie ständig tauschen kann, wir empfehlen, an der Wand die Leiste zu befestigen, die Schrauben mit schkantami verwendend (siehe die Zeichnung Mitte rechts), durchbohren wir in der Leiste die kleinen Öffnungen.
<G-vec00407-001-s075><attach.befestigen><en> Self drilling screws used to attach drywall to heavy gauge metal.
<G-vec00407-001-s075><attach.befestigen><de> Bohrschrauben zur Trockenmauer an dickem Metall zu befestigen.
<G-vec00407-001-s076><attach.befestigen><en> With this Power Core interchangeable robot combination system, MINI-CONS and drone vehicles (sold separately) can attach to power up any Commander figure.
<G-vec00407-001-s076><attach.befestigen><de> Mit dieser Power Core austauschbar Kombination Roboter-System kann der Mini-Cons und drone Fahrzeuge (separat erhältlich) an die Macht bis alle Commander Figur befestigen.
<G-vec00407-001-s077><attach.befestigen><en> Each keyring figure is around 3.5cm tall and comes complete with a ring to attach to your keys, bag or other items.
<G-vec00407-001-s077><attach.befestigen><de> Jeder Schlüsselanhänger ist rund 3,5 cm groß und kommt mit einem Ring, um Ihre Schlüssel oder an einer Tasche oder an andere Gegenstände zu befestigen.
<G-vec00407-001-s078><attach.befestigen><en> This one is equipped with a carabiner, so you can easily attach the flask to your backpack.
<G-vec00407-001-s078><attach.befestigen><de> An diesem befindet sich ein Karabiner, sodass du das gute Stück problemlos an deinem Rucksack befestigen kannst.
<G-vec00407-001-s079><attach.befestigen><en> Nike + iPod collects workout data from a wireless sensor (sold separately) that you attach to your shoe.
<G-vec00407-001-s079><attach.befestigen><de> """Nike + iPod"" erhält die Trainingsdaten von einem drahtlosen Sensor (separat erhältlich), den Sie an Ihrem Schuh befestigen."
<G-vec00407-001-s080><attach.befestigen><en> This saddlebag has 2 Velcro strips that you attach to the rings on the front of your saddle.
<G-vec00407-001-s080><attach.befestigen><de> Diese Satteltasche hat 2 Klettbänder, die Sie an den Ringen an der Vorderseite Ihres Sattels befestigen.
<G-vec00407-001-s081><attach.befestigen><en> Wooden designs in design position lift slings for what them attach to designs, and then suspend to a hook of the elevating mechanism.
<G-vec00407-001-s081><attach.befestigen><de> Die hölzernen Konstruktionen in die Projektlage heben stropami, wofür sie an den Konstruktionen befestigen, und dann hängen zum Haken des Hebemechanismus auf.
<G-vec00407-001-s082><attach.befestigen><en> It could in fact assist to expand the breast by enhancing fatty tissue as well as ligaments giving support as well as form to the breast, while also lengthening the air ducts that attach to the nipple area, for fuller as well as stronger breasts.
<G-vec00407-001-s082><attach.befestigen><de> Es könnte in der Tat helfen, die Brust zu erweitern, indem Fettgewebe sowie Bänder zu verbessern sowie Form auf die Brust geben Unterstützung, während auch die Luftkanäle Verlängerung, die an der Brustwarze Bereich befestigen, für vollere sowie stärkere Brüste.
<G-vec00407-001-s083><attach.anbringen><en> Let the band air dry thoroughly before you attach it to your Apple Watch.
<G-vec00407-001-s083><attach.anbringen><de> Lassen Sie das Armband gründlich trocknen, bevor Sie es an Ihrer Apple Watch anbringen.
<G-vec00407-001-s084><attach.anbringen><en> In order to securely attach this decoration, it should be applied immediately after the nail polish.
<G-vec00407-001-s084><attach.anbringen><de> Um diese Dekoration sicher anbringen, sollte es unmittelbar nach dem Nagellack aufgetragen werden.
<G-vec00407-001-s085><attach.anbringen><en> You can attach the zipper wound to any body and get a realistic result.
<G-vec00407-001-s085><attach.anbringen><de> Du kannst die Sekret-Wunde an einer beliebigen Körperstelle anbringen und erhältst ein realistisches Ergebnis.
<G-vec00407-001-s086><attach.anbringen><en> Attach comprehensive, clear information to the product.
<G-vec00407-001-s086><attach.anbringen><de> Ausführliche Informationen übersichtlich am Produkt anbringen.
<G-vec00407-001-s087><attach.anbringen><en> Our advise: First attach a solid rubber band to the roller and connect the main line to it.
<G-vec00407-001-s087><attach.anbringen><de> Unser Rat: An die Rolle erst ein festes Gummiband anbringen und an ihm die Hauptschnur verbinden.
<G-vec00407-001-s088><attach.anbringen><en> Anyway, who like to reduce the SSD temperature, could perform an active SSD cooling by direct ventilation or attach commercially available silicone heat transfer pads to the top of the PCB.
<G-vec00407-001-s088><attach.anbringen><de> Wer die SSD Temperatur dennoch reduzieren möchte, könnte beispielsweise eine aktive SSD Kühlung durch direkte Belüftung vornehmen oder handelsübliche Silikon Wärmeleitpads zur Verteilung der Hitze auf der Platinenoberseite anbringen.
<G-vec00407-001-s089><attach.anbringen><en> You can attach the material either directly onto the wall or onto plywood attached to the wall.
<G-vec00407-001-s089><attach.anbringen><de> Sie können das Material entweder direkt auf der Wand oder auf einem Trägermaterial aus Sperrholz anbringen, das an der Wand befestigt wird.
<G-vec00407-001-s090><attach.anbringen><en> The devilishly good-looking Demon Horns are easy to attach and convince with their fantastic looks.
<G-vec00407-001-s090><attach.anbringen><de> Die teuflisch gut aussehenden Dämonen Hörner lassen sich einfach anbringen und überzeugen durch ihr fantastisches Aussehen.
<G-vec00407-001-s091><attach.anbringen><en> As a last step, copy the confirmed RMA form with the assigned RMA number twice: please attach one copy to a clearly visible position on the outside of the packaging on all your return consignments.
<G-vec00407-001-s091><attach.anbringen><de> Kopieren Sie als letzten Schritt das bestätigte RMA-Formular mit der erteilten RMA-Nummer zweimal: eine Ausfertigung bitte deutlich sichtbar an der Außenseite der Verpackung all Ihrer Rücksendungen anbringen, die zweite Ausfertigung dem Produkt beilegen.
<G-vec00407-001-s092><attach.anbringen><en> Tip: Who like to reduce the SSD temperature, for example can a) adjust the energy saving settings or b) perform an active SSD cooling by direct ventilation or c) attach commercially available silicone heat transfer pads to the top and bottom of the PCB.
<G-vec00407-001-s092><attach.anbringen><de> Tipp: Wer die SSD Temperatur reduzieren möchte, könnte beispielsweise a) den Energiesparmodus anpassen oder b) eine aktive SSD Kühlung durch direkte Belüftung vornehmen oder c) handelsübliche Silikon Wärmeleitpads zur Verteilung der Hitze auf der Platinen Ober- und Unterseite anbringen.
<G-vec00407-001-s093><attach.anbringen><en> as an option, you can attach brochure trays made of satin acrylic.
<G-vec00407-001-s093><attach.anbringen><de> optional können sie prospektablagen aus mattem acrylglas anbringen.
<G-vec00407-001-s094><attach.anbringen><en> The Creepy Wall Deco Flame monster is a foil that you can easily attach to the wall with zips or double-sided tape and reuse.
<G-vec00407-001-s094><attach.anbringen><de> Die Gruselige Wanddeko Flammenmonster ist eine Folie die du ganz leicht mit Reißzwecken oder doppelseitigen Klebeband an der Wand anbringen und wiederverwenden kannst.
<G-vec00407-001-s095><attach.anbringen><en> Choose between various sizes of your Keuco Edition 300 light mirror, regardless of whether you want attach it vertically or horizontally above the basin.
<G-vec00407-001-s095><attach.anbringen><de> Wählen Sie zwischen verschiedenen Größen, unabhängig davon, ob Sie Ihn vertikal oder horizontal über dem Waschtisch anbringen wollen.
<G-vec00407-001-s096><attach.anbringen><en> You can glue the wooden clips on picture frames or wooden baskets, so you can attach pictures or small pieces of paper.
<G-vec00407-001-s096><attach.anbringen><de> Sie können die Holzklammern auf Bilderrahmen oder Holzkörbe kleben, so lassen sich Bilder oder kleine Zettel anbringen.
<G-vec00407-001-s097><attach.anbringen><en> You can attach it wherever you want.
<G-vec00407-001-s097><attach.anbringen><de> Sie können ihn anbringen, wo Sie möchten.
<G-vec00407-001-s098><attach.anbringen><en> "Indeed, this unique BDSM device will allow you to attach an ultra powerful clitoral vibrator such as a ""Magic Wand"" while you linger on your partner by subjecting her to all kinds of sexual abuse..."
<G-vec00407-001-s098><attach.anbringen><de> "Mit diesem einzigartigen BDSM-Gerät können Sie einen ultra-leistungsfähigen Klitorisvibrator vom Typ ""Magic Wand"" anbringen, während Sie bei Ihrem Partner verweilen, indem Sie ihn allen Arten von sexuellem Missbrauch aussetzen....."
<G-vec00407-001-s099><attach.anbringen><en> has all functions of Stella 1 and offers additionally support brackets, in order to attach the system simply and fast at posts, bars and tubes.
<G-vec00407-001-s099><attach.anbringen><de> verfügt über alle Funktionen von Stella 1 und bietet eine zusätzliche Befestigungsmanschette, um das System einfach und schnell an Pfosten, Stangen und Rohren anbringen zu können.
<G-vec00407-001-s100><attach.anbringen><en> The scrubber has a handy ring to hang it on a keychain, attach it to a hook in the kitchen, etc.
<G-vec00407-001-s100><attach.anbringen><de> Der Wäscher hat ein handliches Ring auf einem Schlüsselbund zu hängen, es an einen Haken in der Küche anbringen, etc.
<G-vec00407-001-s101><attach.anbringen><en> You can either attach directly a wire to one of the entrances (as in the example below, in the small oscillating circuit above left), or a probe on a wire to pull.
<G-vec00407-001-s101><attach.anbringen><de> Sie können entweder einen Draht bis einen der Eingänge (wie im Beispiel unten, im kleinen Schwingungskreis über links) oder eine Prüfspitze auf einem Draht direkt anbringen, um zu ziehen.
<G-vec00407-001-s102><attach.anfügen><en> The Airwheel X3 comes with training wheels that you can attach via screws to the bottom of the foot platforms and a safety strap whilst you get the hang of things.
<G-vec00407-001-s102><attach.anfügen><de> Der Airwheel X3 kommt mit Stützrädern, die Sie anfügen können über Schrauben an den unteren Rand der Fuß-Plattformen und einem Sicherheitsriemen während Sie die Dinge hängen.
<G-vec00407-001-s103><attach.anfügen><en> For more information, see How to attach a data disk to a Windows virtual machine in the Azure portal .
<G-vec00407-001-s103><attach.anfügen><de> Weitere Informationen finden Sie unter Anfügen eines verwalteten Datenträgers an einen virtuellen Windows-Computer im Azure-Portal .
<G-vec00407-001-s104><attach.anfügen><en> Click on ‘Attach File’ (or similar option).
<G-vec00407-001-s104><attach.anfügen><de> "Klicken Sie auf ""Datei anfügen"" (oder die entsprechende Option)."
<G-vec00407-001-s105><attach.anfügen><en> This article is a tutorial about how to attach tasks to email in Microsoft Outlook.
<G-vec00407-001-s105><attach.anfügen><de> Dieser Artikel enthält ein Lernprogramm zum Anfügen von Aufgaben an E-Mails in Microsoft Outlook.
<G-vec00407-001-s106><attach.anfügen><en> 6 clothespins wood with black and white patterns pen, question mark, pea balls, snowflakes, to decorate a gift box or attach a note.
<G-vec00407-001-s106><attach.anfügen><de> 6 Wäscheklammern Holz mit schwarzen und weißen Muster Stift, Fragezeichen, Erbsen Bälle, Schneeflocken, ein Geschenk-Box zu dekorieren oder eine Notiz anfügen.
<G-vec00407-001-s107><attach.anfügen><en> Attach file Adds a file saved in MeXX as an attachment to the current e-mail.
<G-vec00407-001-s107><attach.anfügen><de> Datei anfügen Fügt eine in MeXX gespeicherte Datei als Anlage an die aktuelle E-Mail an.
<G-vec00407-001-s108><attach.anfügen><en> Secure Mail users can attach files from their Citrix Files repository without needing to download the file to the device.
<G-vec00407-001-s108><attach.anfügen><de> Benutzer von Secure Mail können Dateien aus ihrem Citrix Files-Repository anfügen, ohne die Datei auf das Gerät herunterzuladen.
<G-vec00407-001-s109><attach.anfügen><en> You can even import contacts from your e-mail address book in a few clicks and attach a message.
<G-vec00407-001-s109><attach.anfügen><de> Sie können auch Kontakte aus Ihrem E-Mail-Adressbuch mit ein paar Klicks importieren und eine Nachricht anfügen.
<G-vec00407-001-s110><attach.anfügen><en> A faster experience — Outlook.com Beta comes with a “more responsive web development framework”, an optimized look with a “modern conversation style”, and a new “design to let you see, read and attach files and photos faster”.
<G-vec00407-001-s110><attach.anfügen><de> Ein schneller Erfahrung — Outlook.com Beta kommt mit einem “mehr responsive web development framework”, einer optimierten Optik mit einem “modernen Konversation Stil”, und ein neues “design, damit Sie sehen, Lesen und anfügen von Dateien und Fotos schneller”.
<G-vec00407-001-s111><attach.anfügen><en> You can also attach one or several files to help us to reproduce your problem.
<G-vec00407-001-s111><attach.anfügen><de> Sie können andere Dateien anfügen, um uns die Reproduktion ihres Problems zu erleichtern.
<G-vec00407-001-s112><attach.anfügen><en> One must attach, however, that an amendment was never carried out since the beginning of the Bordelaise classification and furthermore either this would not be possible in opinion of all connoisseurs of win.
<G-vec00407-001-s112><attach.anfügen><de> Man muss jedoch anfügen, dass seit Beginn der Bordelaiser Klassifizierung noch nie eine Änderung vorgenommen wurde und dies nach Meinung aller Weinkenner auch weiterhin nicht möglich sein würde.
<G-vec00407-001-s113><attach.anfügen><en> Cut off the excess around the edges and attach as a crust.
<G-vec00407-001-s113><attach.anfügen><de> Überstehende Streifen abschneiden und als seitliche Ränder anfügen.
<G-vec00407-001-s114><attach.anfügen><en> Once created, you can check the Attach a signature box on the posting form to add your signature. You can also add a signature by default to all your posts by checking the appropriate radio button in the User Control Panel.
<G-vec00407-001-s114><attach.anfügen><de> Du kannst auch standardmäßig eine Signatur an alle Beiträge anhängen, indem Du im Profil die entsprechende Option auswählst (Du kannst das Anfügen einer Signatur immer noch verhindern, indem Du die Signaturoption beim Beitragsschreiben abschaltest).
<G-vec00407-001-s115><attach.anfügen><en> Microsoft Outlook 2016 supports to list the most recent items in the Recent Items drop down list, and then you can attach recent documents/items from it quickly.
<G-vec00407-001-s115><attach.anfügen><de> Microsoft Outlook 2016 unterstützt, um die neuesten Elemente in der Liste aufzulisten Neue Artikel Dropdown-Liste, und Sie können dann die letzten Dokumente / Elemente schnell anfügen.
<G-vec00407-001-s116><attach.anfügen><en> -- Collaborate -- Built for Office 365, Planner lets you work together on the same tasks, attach captured photos directly to them, and even have conversations around tasks without switching between apps.
<G-vec00407-001-s116><attach.anfügen><de> – Zusammenarbeit – Mit Planner, einem für Office 365 konzipierten Werkzeug, können Sie gemeinsam an den gleichen Aufgaben arbeiten, erfasste Fotos direkt an sie anfügen und sogar Gespräche rund um Ihre Aufgaben führen, ohne die Anwendung zu wechseln.
<G-vec00407-001-s117><attach.anfügen><en> Comes with manual and with an adhesive to attach to the table.
<G-vec00407-001-s117><attach.anfügen><de> Kommt mit Anleitung und mit einem Klebstoff an die Tabelle anfügen.
<G-vec00407-001-s118><attach.anfügen><en> "Probably, this is the reason for that thing called ""chemistry,"" but whatever label people attach to this kind of attraction, one thing is for sure: the effect that pheromones bring is not mere speculation but a proven fact."
<G-vec00407-001-s118><attach.anfügen><de> "Wahrscheinlich, dies ist der Grund für dieses Ding namens ""Chemie"", aber anfügen was Etikett die Menschen zu dieser Art von Anziehung, eine Sache ist sicher: die Wirkung, die Pheromone zu bringen ist nicht bloße Spekulation aber eine erwiesene Tatsache."
<G-vec00407-001-s119><attach.anfügen><en> "Then, when creating your label on FedEx Ship Manager, you can select ""Attach from Document Preparation Center"" to upload the document you previously created."
<G-vec00407-001-s119><attach.anfügen><de> "Wenn Sie dann Ihr Etikett im FedEx Ship Manager erstellen, können Sie die Option ""Vom Center Dokumentenvorbereitung anfügen"" auswählen, um Ihr zuvor erstelltes Dokument hochzuladen."
<G-vec00407-001-s120><attach.anfügen><en> If the Attach database filename box contains the name of a primary file, the database described by the primary file is attached as a database using the database name specified in the Change the default database to box.
<G-vec00407-001-s120><attach.anfügen><de> Wenn das Feld Datenbank-Dateinamen anfügen den Namen einer primären Datei enthält, wird die durch die primäre Datei beschriebene Datenbank als Datenbank mithilfe des im Feld Die Standarddatenbank ändern auf angegebenen Datenbanknamens angefügt.
<G-vec00407-001-s121><attach.anbringen><en> This means that it must be possible to attach and/or secure load securing materials to the cargo unit in such a way that the load can be adequately secured while remaining undamaged.
<G-vec00407-001-s121><attach.anbringen><de> Das heißt, dass Ladungssicherungsmaterialien so an der Ladeeinheit angebracht und/oder befestigt werden können, dass eine ausreichende Sicherung der Ladung möglich ist und die Ladung dabei unversehrt bleibt.
<G-vec00407-001-s122><attach.anbringen><en> Plywood or foam would need to be accordingly thick, to make them easier to attach to the frame.
<G-vec00407-001-s122><attach.anbringen><de> Sperrholz oder Schaumstoff müssen entsprechend dick sein, damit sie leichter an den Rahmen angebracht werden können.
<G-vec00407-001-s123><attach.anbringen><en> This item comes with the numbers 1?9 and the letters a?f that you can simply attach by sticking them on.
<G-vec00407-001-s123><attach.anbringen><de> Die mitgelieferten Zahlen von 1 - 9 und die Buchstaben von a - f können einfach durch Aufkleben angebracht werden.
<G-vec00407-001-s124><attach.anbringen><en> Easy assembly, simply attach the legs
<G-vec00407-001-s124><attach.anbringen><de> Einfache Montage, nur die Beine müssen angebracht werden.
<G-vec00407-001-s125><attach.anbringen><en> Use the anti-gravity device in front of the door, this will attach it to the underside of the door, allowing it to rise halfway.
<G-vec00407-001-s125><attach.anbringen><de> Benutze die Antigrav-Einheit vor der Tür, dadurch wird sie an die Unterseite der Tür angebracht und die Tür wird halb hochgehoben.
<G-vec00407-001-s126><attach.anbringen><en> This is a white iron sheet to which you can attach magnets.
<G-vec00407-001-s126><attach.anbringen><de> Es handelt sich hier um eine weiße Eisenfolie, auf der Magnete angebracht werden können.
<G-vec00407-001-s127><attach.anbringen><en> Description The pump is equipped with suction cups so that you can attach it to the bottom of the reservoir.
<G-vec00407-001-s127><attach.anbringen><de> Stück Beschreibung Die Pumpe ist mit Saugnäpfen ausgestattet, so dass sie am Boden eines Reservoirs angebracht werden kann.
<G-vec00407-001-s128><attach.anbringen><en> In the actual application of the research project, the aim is to attach an S3 label like an adhesive strip to a Festo pneumatic drive.
<G-vec00407-001-s128><attach.anbringen><de> Im konkreten Anwendungsfall des Forschungsprojekts soll ein S3-Label wie ein Klebestreifen auf einem pneumatischen Antrieb von Festo angebracht werden.
<G-vec00407-001-s129><attach.anbringen><en> On the other hand, girth hitches can also be used to fasten slings to trees and to attach a personal anchor sling to a harness and carabiner.
<G-vec00407-001-s129><attach.anbringen><de> Zum anderen können mittels Ankerstich Schlingen an Bäumen fixiert oder eine Selbstsicherungsschlinge am Gurt und in Karabinern angebracht werden.
<G-vec00407-001-s130><attach.anbringen><en> Assembly required, simply attach the legs
<G-vec00407-001-s130><attach.anbringen><de> Geringfügige Montage erforderlich, die Beine müssen angebracht werden.
<G-vec00407-001-s131><attach.anbringen><en> This package label will be sent to you via e-mail which you then will have to print out and attach to the package.
<G-vec00407-001-s131><attach.anbringen><de> Dieser Paketaufschriftzettelwird Ihnen dann per E-mail zugeschickt und muss ausgedruckt und auf dem Paket angebracht werden.
<G-vec00407-001-s132><attach.anbringen><en> They easily attach with velcro or magnets to the furniture and turn them into highly decorative acoustic surfaces.
<G-vec00407-001-s132><attach.anbringen><de> Sie werden einfach mit Magnetband oder Klettband auf den zu verblendeten Seiten der Möbel angebracht und machen aus diesen akustisch wirksame Oberflächen, die überdies sehr dekorativ aussehen.
<G-vec00407-001-s133><attach.anbringen><en> This item contains an universal accessory connector type #3 that can be used to attach accessories to the handlebar for the Bugaboo Bee or the Bugaboo Donkey.
<G-vec00407-001-s133><attach.anbringen><de> Artikelcode Dieser Artikel enthält ein Universal-Zubehör-Verbindungsstück vom Typ 3, mit dem Bugaboo Accessoires am Schiebebügel des Bugaboo Bee oder Bugaboo Donkey angebracht werden können.
<G-vec00407-001-s134><attach.anheften><en> These are hard, brown shields that attach themselves to the bottom of the leaves.
<G-vec00407-001-s134><attach.anheften><de> Dies sind harte, braune Schilder, die sich an der Unterseite der Blätter anheften.
<G-vec00407-001-s135><attach.anheften><en> That Passanten replace and attach the amber STIX elsewhere, with it a quite desired side effect is: „The viralen effects are unbelievable “, are pleased Karsten Warrink, managing director of AMBERME dia., „the funny motives provoke for carrying forward.
<G-vec00407-001-s135><attach.anheften><de> Dass Passanten die amber STIX ablösen und anderswo anheften, ist da-bei ein durchaus erwünschter Nebeneffekt: „Die viralen Effekte sind un-glaublich“, freut sich Karsten Warrink, Geschäftsführer von AMBERME-DIA, „Die witzigen Motive reizen zum Mitnehmen.
<G-vec00407-001-s136><attach.anheften><en> Mantis can possess people or attach closely to their energy system.
<G-vec00407-001-s136><attach.anheften><de> Mantis können Menschen besetzen oder sich nahe an Menschen anheften.
<G-vec00407-001-s137><attach.anheften><en> On the opposite side of the walker, they then unblock a separate row, to which the cylinder’s feet can now attach.
<G-vec00407-001-s137><attach.anheften><de> Auf der gegenüberliegenden Seite des Läufers wird wiederum eine bis dahin blockierte Reihe freigegeben – und die Füßchen des Zylinders können sich dort anheften.
<G-vec00407-001-s138><attach.anheften><en> Through folding and attachment of other helix molecules, capsules are developed that can attach themselves with embedded enzymes or other agents targeted on sick cells.
<G-vec00407-001-s138><attach.anheften><de> Durch Faltung und Anlagerung von anderen Helix-Molekülen entstehen daraus Kapseln, die sich mit eingeschlossenen Enzymen oder anderen Wirkstoffen gezielt an kranke Zellen anheften können.
<G-vec00407-001-s139><attach.anheften><en> - would attach itself.
<G-vec00407-001-s139><attach.anheften><de> – selbst anheften würde.
<G-vec00407-001-s140><attach.anheften><en> The live recordings document how, within hours of being transplanted, the hematopoietic stem cells attach themselves to the inner vessel walls in the bone marrow and start to migrate into the surrounding tissue – their niche.
<G-vec00407-001-s140><attach.anheften><de> Die live-Aufnahmen dokumentieren, wie sich die hämatopoetischen Stammzellen innerhalb von Stunden nach der Transplantation an die Gefäßinnenwand im Knochenmark anheften und anfangen, in das umliegende Gewebe – ihre Nische – zu migrieren.
<G-vec00407-001-s141><attach.anheften><en> You should attach it to the minutes after they're transcribed.
<G-vec00407-001-s141><attach.anheften><de> Du solltest diese an das Protokoll anheften, nachdem du es abgetippt hast.
<G-vec00407-001-s143><attach.anhängen><en> Note: The Insert > Attach File > Recent Item is new in Outlook 2016, therefore this method does not work in earlier Outlook versions.
<G-vec00407-001-s143><attach.anhängen><de> Text: Das Einsatz > Datei anhängen > Neuestes Objekt ist in Outlook 2016 neu, daher funktioniert diese Methode in früheren Outlook-Versionen nicht.
<G-vec00407-001-s144><attach.anhängen><en> Wallee allows you to fully customize order emails, invoices or any other document that you wish to attach to communications with your customers via our built in resource editor.
<G-vec00407-001-s144><attach.anhängen><de> Wallee ermöglicht es Ihnen, Bestell-E-Mails, Rechnungen oder andere Dokumente, die Sie an die Kommunikation mit Ihren Kunden über unseren integrierten Ressourcen-Editor anhängen möchten, vollständig anzupassen.
<G-vec00407-001-s145><attach.anhängen><en> The PowerPoint export can now attach slides to an existing PPTX file.
<G-vec00407-001-s145><attach.anhängen><de> Der PowerPoint-Export kann jetzt Folien an eine bestehende PPTX-Datei anhängen.
<G-vec00407-001-s146><attach.anhängen><en> "External files, text, HTML or image files can be imported in the same place with the button ""Instead, attach a file as a signature""."
<G-vec00407-001-s146><attach.anhängen><de> "Als externe Dateien können an gleicher Stelle über den Button ""Stattdessen eine Datei als Signatur anhängen"" Text-, HTML - oder Grafikdateien eingebunden werden."
<G-vec00407-001-s147><attach.anhängen><en> - The photograph you attach must be recent passport-size.
<G-vec00407-001-s147><attach.anhängen><de> - Das Foto, das Sie anhängen müssen neue Pass Größe sein.
<G-vec00407-001-s148><attach.anhängen><en> In the document that you attach you count some of the most significant changes.
<G-vec00407-001-s148><attach.anhängen><de> In dem Dokument, das Sie anhängen Sie zählen einige der wichtigsten Änderungen.
<G-vec00407-001-s149><attach.anhängen><en> You can then attach the new HTML document instead of your Word document.
<G-vec00407-001-s149><attach.anhängen><de> Sie können dann das neue HTML-Dokument anstelle Ihres Word-Dokumentes anhängen.
<G-vec00407-001-s150><attach.anhängen><en> 系 xì: (attach) is not used alone.
<G-vec00407-001-s150><attach.anhängen><de> 系 xì: (Anhängen) wird nicht alleine verwendet.
<G-vec00407-001-s151><attach.anhängen><en> Some items can be combined or used in attach.
<G-vec00407-001-s151><attach.anhängen><de> Einige Artikel können kombiniert oder benutzt werden anhängen.
<G-vec00407-001-s152><attach.anhängen><en> Add unique effects, apply different filters, place text on images, attach stickers, and much more with the Photo Editor tool accessed from the CraterTM Editor.
<G-vec00407-001-s152><attach.anhängen><de> Sie können einzigartige Effekte hinzufügen, verschiedene Filter anwenden, Texte auf Bildern platzieren, Sticker anhängen, und noch vieles mehr mit dem Photo Editor Werkzeug des CraterTM Editors.
<G-vec00407-001-s153><attach.anhängen><en> One can also attach an existing file that will serve as a signature.
<G-vec00407-001-s153><attach.anhängen><de> Man kann auch eine vorhandene Datei anhängen, die als Signatur dienen.
<G-vec00407-001-s154><attach.anhängen><en> Outgoing attachments [top] To send a file stored on your computer, click on Attach and then select Attachments .To send a file already stored in the Documents, click on Attach and then select Documents .
<G-vec00407-001-s154><attach.anhängen><de> Anlagen zum Versand [top] Um eine Datei, die auf Ihrem Computer gespeichert ist, zu versenden, klicken Sie auf Anhängen und wählen Sie dann Anhang .Um eine Datei zu senden, die bereits in den Dokumenten abgespeichert ist, klicken Sie auf Anhängen und wählen Sie dann Dokumente .
<G-vec00407-001-s156><attach.anhängen><en> And the Radical Universal Aero panniers are made to attach to a mesh seat.
<G-vec00407-001-s156><attach.anhängen><de> Die Radical Universal Aero-Taschen sind für's Anhängen an den Spannsitz gedacht.
<G-vec00407-001-s157><attach.anhängen><en> You can attach (or link) a Document to a Contact.
<G-vec00407-001-s157><attach.anhängen><de> Sie können ein Dokument einem Kontakt anhängen (oder mit ihm verlinken).
<G-vec00407-001-s158><attach.anhängen><en> Alternatively, you can attach an existing photo, video, or GIF by choosing from the thumbnails alongside the camera button or by tapping the gallery icon .
<G-vec00407-001-s158><attach.anhängen><de> Stattdessen kannst du ein vorhandenes Foto, Video oder GIF anhängen, indem du eines aus den Thumbnails neben dem Kamera-Button auswählst oder das Galeriesymbol antippst.
<G-vec00407-001-s159><attach.anhängen><en> To use our services, you don't even need to attach any credit card or other payment information.
<G-vec00407-001-s159><attach.anhängen><de> Um unsere Dienste nutzen zu können, müssen Sie nicht einmal Kreditkarten- oder andere Zahlungsinformationen anhängen.
<G-vec00407-001-s160><attach.anhängen><en> Select Attach a copy of the sent fax if you want to receive copies of the faxes that you send with the receipts.
<G-vec00407-001-s160><attach.anhängen><de> Aktivieren Sie Kopie des gesendeten Faxes anhängen, wenn Sie mit der Empfangsbestätigung eine Kopie der gesendeten Faxnachricht empfangen möchten.
<G-vec00407-001-s161><attach.anhängen><en> Hotmail doesn't want us to attach our pictures to the mails we are going to send and it takes dozens of connection- attempts before we can get our latest diary-update on the way to Dirk Borchers, our webmaster in Bremen.
<G-vec00407-001-s161><attach.anhängen><de> Hotmail wollte uns nicht Bilder an unsere Mail anhängen lassen und erst nach etlichen Einwahlversuchen konnten die letzten Tagebucheintragungen auf den Weg nach Bremen zu Dirk Borchers, unserem Webmaster und Dominique, unserer fleißigen Übersetzerin, gesendet werden.
<G-vec00407-001-s162><attach.anschließen><en> You can attach to our flow rate meter modules with its 16 digital inputs up to 8 flow rate meters with foam probes or alternatively barrel-empty detectors.
<G-vec00407-001-s162><attach.anschließen><de> An unsere Durchflusszählermodule (FRM: Flow Rate Meter) mit insgesamt 16digitalen Eingängen können Sie bis zu 8Durchflusszähler mit Schaumsonde oder alternativ Fassleermelder anschließen.
<G-vec00407-001-s163><attach.anschließen><en> So, for the sake of survival, alliances are useful; if you find a leader or group that serves your purpose then why not attach yourself for a while until your progeny is ready to challenge the ideological blood line.
<G-vec00407-001-s163><attach.anschließen><de> Also, um des Überlebens Willen sind Allianzen nützlich; wenn du einen Anführer oder eine Gruppe findest, die für deine Zwecke nützlich sind, warum sich nicht eine Weile anschließen, bis deine Nachkommenschaft dazu bereit ist, die ideologische Blutlinie herauszufordern.
<G-vec00407-001-s164><attach.anschließen><en> The Seneye Float is designed to be used with the Seneye Reef and offers flexibility for customers who do not wish to use the sucker to attach the Seneye device.
<G-vec00407-001-s164><attach.anschließen><de> Die Seneye Float ist entworfen, um mit dem Seneye Reef genutzt werden und bietet Flexibilität für Kunden, die nicht wollen, um den Sauger zu verwenden, um die Seneye Gerät anschließen.
<G-vec00407-001-s165><attach.anschließen><en> Attach the pump to the extension connector and pump about 50 times.
<G-vec00407-001-s165><attach.anschließen><de> Die Velopumpe ans Ventil anschließen und ungefähr 50 x pumpen.
<G-vec00407-001-s166><attach.anschließen><en> During the miner procedures the linked malware can attach to currently running Windows services and also third-party mounted applications.
<G-vec00407-001-s166><attach.anschließen><de> Während der miner Verfahren können die verknüpfte Malware aktuell laufenden Windows-Dienste anschließen und auch von Drittanbietern montiert Anwendungen.
<G-vec00407-001-s167><attach.anschließen><en> Their fresh look and superb quality will enable developers to attach a genuinely professional feel to their project interfaces.
<G-vec00407-001-s167><attach.anschließen><de> Ihre frischen Look und hervorragende Qualität ermöglicht es Entwicklern, eine wirklich professionellen Look zu ihrem Projekt-Schnittstellen anschließen.
<G-vec00407-001-s168><attach.anschließen><en> But you can also, of course, attach a hose for an external condensate drain.
<G-vec00407-001-s168><attach.anschließen><de> Natürlich können Sie aber auch einen Schlauch für einen externen Kondensatablauf anschließen.
<G-vec00407-001-s169><attach.anschließen><en> It can be even more perfect if we attach this USB drive to a nice lanyard.
<G-vec00407-001-s169><attach.anschließen><de> Es kann noch perfekter sein, wenn wir diesen USB-Stick an eine schöne Lanyard anschließen.
<G-vec00407-001-s170><attach.anschließen><en> You do not need to attach the All-In-One to a computer to make copies, to print photos stored on memory cards, or to print photos directly from a digital camera using PictBridge.
<G-vec00407-001-s170><attach.anschließen><de> Sie müssen den All-In-One nicht an einen Computer anschließen, um Kopien zu erstellen, um auf Ihren Speicherkarten gespeicherte Fotos zu drucken oder um Fotos mithilfe von PictBridge direkt von einer Digitalkamera zu drucken.
<G-vec00407-001-s171><attach.anschließen><en> The cars will attach themselves once you park correctly.
<G-vec00407-001-s171><attach.anschließen><de> Die Autos werden sich anschließen, wenn Sie richtig parken.
<G-vec00407-001-s172><attach.anschließen><en> Audio devices attach to the connector of the central unit, insert the plug into the player outputs are available on the left and the right.
<G-vec00407-001-s172><attach.anschließen><de> Audio-Geräte an den Anschluss der Zentraleinheit anschließen, stecken Sie den Stecker in die Spieler-Ausgänge sind auf der linken und der rechten Seite zur Verfügung.
<G-vec00407-001-s173><attach.anschließen><en> Of course, the new iPadOS will also allow you to attach a controller, gamepad or gaming joystick.
<G-vec00407-001-s173><attach.anschließen><de> Mit dem neuen iPadOS können Sie natürlich auch einen Controller, ein Gamepad oder einen Gaming-Joystick anschließen.
<G-vec00407-001-s174><attach.anschließen><en> To listen to the radio, you need to attach a compatible headset to the device.
<G-vec00407-001-s174><attach.anschließen><de> Um Radio zu hören, müssen Sie ein kompatibles Headset an das Gerät anschließen.
<G-vec00407-001-s175><attach.anschließen><en> "A Swiss study found out that ""...the users of Italian descent seem to attach more to certain persons than to institutions."
<G-vec00407-001-s175><attach.anschließen><de> "In einer Studie aus der Schweiz wurde herausgefunden, dass ""...sich Drogenkonsumenten italienischer Abstammung eher bestimmten Personen als Institutionen anschließen."
<G-vec00407-001-s176><attach.anschließen><en> Its slender housing measures only 11 cm long and 2 cm wide, including a connection to which you can attach your sensor directly, without a cable.
<G-vec00407-001-s176><attach.anschließen><de> Sein schlankes Gehäuse ist nur 11 cm lang und 2 cm breit – einschließlich eines Anschlusses, an den Sie Ihren Sensor direkt, also ohne Kabel, anschließen können.
<G-vec00407-001-s177><attach.anschließen><en> Galleon products range from Atomic clock that attach to a standalone PC's to Atomic Clocks that Attach to a Windows time Server.
<G-vec00407-001-s177><attach.anschließen><de> Galleon Produkte reichen von Atomuhr, die auf einem eigenständigen PC anschließen ist die Atomuhren, die ein Befestigen Windows-Zeit-Server.
<G-vec00407-001-s178><attach.anschließen><en> Afterwards simply attach the keyboard to the USB 3.0 port, in order to get into the UEFI Setup and to be able to setup all necessary settings.
<G-vec00407-001-s178><attach.anschließen><de> Danach einfach die Tastatur am USB 3.0 Port anschließen, um ins UEFI Setup zu gelangen und alle Einstellungen vornehmen zu können.
<G-vec00407-001-s179><attach.anschließen><en> If you need to work with the system disk, in order to get access to it, you will have to extract it from the machine and attach it to another computer as a secondary disk or boot your Mac in a safe environment using UFS Explorer Backup and Emergency Recovery CD.
<G-vec00407-001-s179><attach.anschließen><de> Wenn Sie mit dem Systemlaufwerk arbeiten, um Zugriff darauf zu erhalten, müssen Sie das vom Computer extrahieren und als sekundäre Festplatte an einen anderen Computer anschließen oder Ihren Mac in einer sicheren Umgebung mit UFS Explorer Backup and Emergency Recovery CD starten.
<G-vec00407-001-s180><attach.anschließen><en> You should attach the grass bag to the unit and you are ready to move the mower to perform the job.
<G-vec00407-001-s180><attach.anschließen><de> Sie sollten den Grassack an das Gerät anschließen und Sie sind bereit, den Mäher zu bewegen, um die Aufgabe zu erledigen.
<G-vec00407-001-s181><attach.anbringen><en> It is not necessary to attach the CE marking to an electrical device.
<G-vec00407-001-s181><attach.anbringen><de> Für elektrische Geräte und Apparate ist es nicht erforderlich, die CE-Kennzeichnung auf dem Produkt selbst anzubringen.
<G-vec00407-001-s182><attach.anbringen><en> Keep in mind that you will be allowed to attach pics when you have posted, at least, 15 messages on this forum.
<G-vec00407-001-s182><attach.anbringen><de> Im Verstand halten, daß dir erlaubt wirst, pics, wenn du mindestens bekanntgegeben hast 15 Anzeigen anzubringen auf diesem Forum.
<G-vec00407-001-s183><attach.anbringen><en> The optical selection of the sensor makes it possible to attach the sensor in any chosen geometry.
<G-vec00407-001-s183><attach.anbringen><de> Das optische Auslesen des Sensors erlaubt es, den Sensor in jeder beliebigen Geometrie anzubringen.
<G-vec00407-001-s184><attach.anbringen><en> Hang tags are cardboard blanks, which can be printed on front and back, and are equipped with hole punching to attach threads.
<G-vec00407-001-s184><attach.anbringen><de> weitere Infos Anhängeetiketten Anhängeetiketten sind auf der Vorder- und Rückseite bedruckbare Kartonzuschnitte, die mit einer Lochstanzung ausgestattet sind, um Fäden anzubringen.
<G-vec00407-001-s185><attach.anbringen><en> It is self-adhesive and easy to attach.
<G-vec00407-001-s185><attach.anbringen><de> Er ist selbstklebend und leicht anzubringen.
<G-vec00407-001-s186><attach.anbringen><en> 5.12 The seller is not entitled to attach links to external websites to his online-shop in any form.
<G-vec00407-001-s186><attach.anbringen><de> 5.12 Der Verkäufer ist in seinem Shop nicht dazu berechtigt, Links, die auf externe Webseiten verweisen, in irgendeiner Form anzubringen.
<G-vec00407-001-s187><attach.anbringen><en> The reduced tag size allows users to attach them even to small metallic carriers.
<G-vec00407-001-s187><attach.anbringen><de> Durch die reduzierte Größe des Datenträgers, ist es möglich, die Tags an kleine metallische Posten von außen anzubringen.
<G-vec00407-001-s188><attach.anbringen><en> You are then ready to attach your spanking implement.
<G-vec00407-001-s188><attach.anbringen><de> Sie sind dann bereit, Ihr Prügelgerät anzubringen.
<G-vec00407-001-s189><attach.anbringen><en> Segway Switzerland offers you the following handbooks and instructions for your records, to help you understand your Segway PT or to attach further or new components.
<G-vec00407-001-s189><attach.anbringen><de> Segway Switzerland bietet Ihnen die nachfolgenden Handbücher und Anleitungen, um Ihren Segway PT zu verstehen oder um weitere oder neue Bestandteile anzubringen.
<G-vec00407-001-s190><attach.anbringen><en> Even LEICA's included strap is the perfect length right out of the box, and much easier to attach, adjust and remove than anything else.
<G-vec00407-001-s190><attach.anbringen><de> Sogar der Leica-Gurt hat die perfekte Länge, so wie er aus der Box kommt, und er ist viel einfacher anzubringen, einzustellen und abzunehmen als jeder andere.
<G-vec00407-001-s191><attach.anbringen><en> This mount enables you to attach your Garmin VIRB Ultra 30 on your wrist or other round objects with a diameter up to 203 mm.
<G-vec00407-001-s191><attach.anbringen><de> Diese Halterung ermöglicht es Ihnen die Garmin VIRB Ultra 30 an Ihrem Hangelenk oder an runden Objekten mit einem Durchmesser von bis zu 203 mm anzubringen.
<G-vec00407-001-s192><attach.anbringen><en> For easy access to this little tool, you would need a golf hat clip to carry it along to attach on your hat.
<G-vec00407-001-s192><attach.anbringen><de> Für den einfachen Zugriff auf dieses kleine Werkzeug benötigen Sie einen Golfhutclip, um es an Ihrem Hut anzubringen.
<G-vec00407-001-s193><attach.anbringen><en> Easy to attach, long enough to keep the leash away from the wheel when the dog is not pulling and a 90 degree angle is no problem.
<G-vec00407-001-s193><attach.anbringen><de> Leicht anzubringen, lang genug um die Leine vom Rad weg zu halten wenn der Hund mal nicht so zieht und eine 90 Gradabwinkelung ist auch kein Problem.
<G-vec00407-001-s194><attach.anbringen><en> They are available in three quality levels Basixx, Axxent and Luxxus and are easy to attach.
<G-vec00407-001-s194><attach.anbringen><de> Sie sind in drei Qualitätsstufen Basixx, Axxent und Luxxus erhältlich und sind problemlos anzubringen.
<G-vec00407-001-s195><attach.anbringen><en> The process of free Christian ecard advertising allows Christians from all over the world to have access to information and products offered by a particular organization providing Christian ecards.In addition to a personalized text, a free Christian ecard allows a consumer to create different backgrounds, images and music to attach to their Christian ecards.
<G-vec00407-001-s195><attach.anbringen><de> Der Prozeß des freien christlichen ecard Annoncierens erlaubt Christen von auf der ganzen Erde, Zugang zu den Informationen und Produkte durch eine bestimmte Organisation anbieten zu lassen, die christliche ecards bereitstellt.Zusätzlich zu einem personifizierten Text erlaubt ein freies christliches ecard einem Verbraucher, unterschiedliche Hintergründe, Bilder und Musik zu verursachen, um zu ihren christlichen ecards anzubringen.
<G-vec00407-001-s196><attach.anbringen><en> The rings on each side of the ball allow you to attach a chain or other BDSM accessory.
<G-vec00407-001-s196><attach.anbringen><de> Die Ringe auf jeder Seite des Balls ermöglichen Ihnen, eine Kette oder anderes BDSM-Zubehör anzubringen.
<G-vec00407-001-s197><attach.anbringen><en> It was important not to put the magnets on too early, otherwise the metal chips could have loosened from the paint and attach to the magnets.
<G-vec00407-001-s197><attach.anbringen><de> Es war wichtig, die Magnete nicht zu früh anzubringen, da sich ansonsten die Metallspäne aus der Farbe gelöst und an die Magnete geheftet hätten.
<G-vec00407-001-s198><attach.anbringen><en> This would reduce their extension to less than an inch. I bought a packet of wood screws and of washers to attach the sign to the end of the broom and drilled four more holes at the bottom to provide additional strength.
<G-vec00407-001-s198><attach.anbringen><de> Ich kaufte ein Paket der hölzernen Schrauben und der Unterlegscheiben, um das Zeichen zum Ende des Besens anzubringen und bohrte vier weitere Löcher an der Unterseite, um zusätzliche Stärke zur Verfügung zu stellen.
<G-vec00407-001-s199><attach.anbringen><en> What I missed: A possibility to attach the mobile phone, because navigation is also necessary here.
<G-vec00407-001-s199><attach.anbringen><de> Was ich vermisst habe: Eine Möglichkeit das Handy anzubringen, denn Navigation ist auch hier nötig.
<G-vec00407-001-s200><attach.anhängen><en> Tags: The new configuration object class “Tag” allows to attach short texts to almost any other object.
<G-vec00407-001-s200><attach.anhängen><de> Tags: Die neue Konfigurations-Objektklasse „Tag“ erlaubt es, kurze Texte an fast alle anderen Objekte anzuhängen.
<G-vec00407-001-s201><attach.anhängen><en> To attach a data point to the trend log, press the Add... button and select the reg_1_Read register which was created previously.
<G-vec00407-001-s201><attach.anhängen><de> Um einen Datenpunkt an den Trendlog anzuhängen, drücken Sie auf die Schaltfläche Add... und wählen das vorher erzeugte Register reg_1_Read aus.
<G-vec00407-001-s202><attach.anhängen><en> If you want to add images that you found on the Web, you either have to download them or attach their link instead which may take quite some time as you need to open a web browser, open an image search site or a site images are hosted on, download the image or copy the link, and attach it to the message.
<G-vec00407-001-s202><attach.anhängen><de> Wenn Sie möchten, fügen Sie Bilder hinzu, die Sie auf dem Web gefunden werden, müssen Sie entweder herunterladen oder befestigen Sie Ihren link stattdessen kann einige Zeit dauern, wie Sie benötigen, öffnen Sie einen Webbrowser, öffnen Sie eine Bild-such-Website oder einer Website, die Bilder gehostet werden, laden Sie das Bild oder den link kopieren und es an die Nachricht anzuhängen.
<G-vec00407-001-s203><attach.anhängen><en> • Navigate to the folder where the PatXML document is saved and click Open to attach the document.
<G-vec00407-001-s203><attach.anhängen><de> • Gehen Sie zu dem Ordner, in dem das PatXML- Dokument gespeichert ist, und klicken Sie auf Öffnen, um das Dokument anzuhängen.
<G-vec00407-001-s204><attach.anhängen><en> Copy All Open Files: Copies all open Word documents and allows you paste them to any file location or to attach in emails.
<G-vec00407-001-s204><attach.anhängen><de> Kopiere alle geöffneten Dateien: Kopiert alle geöffneten Word-Dokumente und ermöglicht es Ihnen, sie an einem beliebigen Speicherort einzufügen oder in E-Mails anzuhängen.
<G-vec00407-001-s205><attach.anhängen><en> When it comes to Mac mind mapping software, you get what you pay for. Using MindView Mac as your mind mapping software brings you the power of 6 interchangeable views, the ability to take notes, attach files and add visuals to the branches.
<G-vec00407-001-s205><attach.anhängen><de> Bei Verwendung von MindView Mac als Ihre Mind Mapping-Software profitieren Sie von 6 frei wählbaren Ansichten, der Möglichkeit, Notizen zu machen, Dateien anzuhängen und den Zweigen Grafiken hinzuzufügen.
<G-vec00407-001-s206><attach.anhängen><en> From now on, there is no need to copy files back and forth between your PC and external devices or worry about the size of the files as you try to attach them to an email.
<G-vec00407-001-s206><attach.anhängen><de> Von nun an müssen Sie Dateien nicht mehr zwischen Ihrem PC und externen Geräten kopieren oder sich um die Größe von Dateien sorgen, wenn Sie versuchen, diese an eine eMail anzuhängen.
<G-vec00407-001-s207><attach.anhängen><en> You can attach cover letters, CVs, certificates and other attachments.
<G-vec00407-001-s207><attach.anhängen><de> Sie haben die Möglichkeit Anschreiben, Lebensläufe, Zeugnisse und andere Anlagen anzuhängen.
<G-vec00407-001-s208><attach.anhängen><en> It is now also possible to attach external files to a directory.
<G-vec00407-001-s208><attach.anhängen><de> Es ist jetzt auch möglich, externe Dateien an ein Verzeichnis anzuhängen.
<G-vec00407-001-s209><attach.anhängen><en> In the case of equipment self-made, the participants must attach the wiring diagram of the apparatus used .
<G-vec00407-001-s209><attach.anhängen><de> Bei geräten autocostruite die teilnehmer müssen anzuhängen, den schaltplan des gerätes verwendet .
<G-vec00407-001-s210><attach.anhängen><en> MAPI is a standard interface that allows WinZip and other programs (including Windows itself) to instruct your email program to create a new message, attach a file to it, etc.
<G-vec00407-001-s210><attach.anhängen><de> Die MAPI-Standardschnittstelle ermöglicht WinZip und anderen Anwendungen (einschließlich Windows selbst), Ihr E-Mail-Programm zu steuern und beispielsweise anzuweisen, eine neue Nachricht zu erstellen oder eine Datei anzuhängen.
<G-vec00407-001-s211><attach.anhängen><en> After you successfully attach the trailer, from that point on you get to drive a trailer truck.
<G-vec00407-001-s211><attach.anhängen><de> Nachdem Sie den Trailer erfolgreich anzuhängen, von da an um einen Anhänger LKW fahren zu bekommen.
<G-vec00407-001-s231><attach.befestigen><en> Heal the cat and attach the normal people.
<G-vec00407-001-s231><attach.befestigen><de> Heile die Katze und befestige die normalen Menschen.
<G-vec00407-001-s232><attach.befestigen><en> Sketch your design onto the stone directly using your wax pencil or marker, or attach the stencil to your stone.
<G-vec00407-001-s232><attach.befestigen><de> Skizziere mit deinem Wachsstift oder -marker dein Design direkt auf den Stein oder befestige die Schablone an deinem Stein.
<G-vec00407-001-s233><attach.befestigen><en> I like to attach it to almost every position I use my big dildo;) My fantasy knows no boundaries ..
<G-vec00407-001-s233><attach.befestigen><de> Ich befestige es gerne an fast jeder Position die ich mit meinem großen Dildo mache;) Meine Fantasie kennt keine Grenzen.
<G-vec00407-001-s234><attach.befestigen><en> Attach the bat house to the intended site.
<G-vec00407-001-s234><attach.befestigen><de> Befestige das Fledermaushäuschen an der vorgesehenen Stelle.
<G-vec00407-001-s235><attach.befestigen><en> Place Kai in the capsule, attach the blade and dragon wings, then pull the rip cord.
<G-vec00407-001-s235><attach.befestigen><de> Setz dann Kai in die Kapsel, befestige die Klinge und die Drachenflügel und zieh am Zugriemen.
<G-vec00407-001-s236><attach.befestigen><en> Attach the roof.
<G-vec00407-001-s236><attach.befestigen><de> Befestige das Dach.
<G-vec00407-001-s237><attach.befestigen><en> Attach a small cluster of feathers to the stick.
<G-vec00407-001-s237><attach.befestigen><de> Befestige ein kleines Bündel Federn am Stab.
<G-vec00407-001-s238><attach.befestigen><en> I mainly attach the leash on front to have more control (there are a lot of people complaining about the back hook wearing out nylon fast but it's too early to tell).
<G-vec00407-001-s238><attach.befestigen><de> Ich befestige die Leine hauptsächlich an der Front, um mehr Kontrolle zu haben (es gibt eine Menge Leute, die sich über den hinteren Haken beschweren, der das Nylon schnell abnutzt, aber es ist noch zu früh, um dies zu beurteilen).
<G-vec00407-001-s239><attach.befestigen><en> Please create your free Royal mail returns label here and attach this to the outside of your package.
<G-vec00407-001-s239><attach.befestigen><de> Drucke hier dein Etikett für kostenlose Rücksendung mit Royal Mail aus und befestige es an der Außenseite deiner Sendung.
<G-vec00407-001-s240><attach.befestigen><en> Attach the yarn to your crochet hook with a slipknot, then work up a foundation chain of 200 chain stitches.
<G-vec00407-001-s240><attach.befestigen><de> Befestige das Garn mit einem Slipknoten auf der Häkelnadel und häkle dann eine Luftmaschenkette aus 200 Luftmaschen.
<G-vec00407-001-s241><attach.befestigen><en> Attach the end of the string to a stick.
<G-vec00407-001-s241><attach.befestigen><de> Befestige das Ende der Schnur an einem Stab.
<G-vec00407-001-s242><attach.befestigen><en> Simply attach the minifigure to her LEGO Toy Tag and place her on the LEGO Toy Pad to bring her to life in the game.
<G-vec00407-001-s242><attach.befestigen><de> Befestige die Minifigur einfach an ihrem LEGO Tag und platziere sie auf dem LEGO Toypad, um sie im Spiel zum Leben zu erwecken.
<G-vec00407-001-s243><attach.befestigen><en> Attach the solar panel.
<G-vec00407-001-s243><attach.befestigen><de> Befestige das Solarpanel.
<G-vec00407-001-s244><attach.befestigen><en> Attach the bottom of the film.
<G-vec00407-001-s244><attach.befestigen><de> Befestige den unteren Teil der Folie.
<G-vec00407-001-s245><attach.befestigen><en> When you attach the base station to Isofix, this device provides more stability and greater security.
<G-vec00407-001-s245><attach.befestigen><de> Wenn Sie die Basisstation mit Isofix befestigen, sorgt diese Vorrichtung für mehr Stabilität und einer höheren Sicherheit.
<G-vec00407-001-s246><attach.befestigen><en> For this purpose it is necessary to plan a pencil a form and to attach wires in the relevant provision by means of thin tacks or stripes of an adhesive tape.
<G-vec00407-001-s246><attach.befestigen><de> Dazu muss man planen Bleistift die Form und die Leitungen in der entsprechenden Lage mit Hilfe fein gwosdikow oder polossotschek des Klebebandes befestigen.
<G-vec00407-001-s247><attach.befestigen><en> The saddle bagag has three karabiner hooks for easy, secure mounting to the saddle and a set of leather strings on each side to attach further luggage. (Jackets, blankets...)
<G-vec00407-001-s247><attach.befestigen><de> Die Tasche hat drei Karabinerhaken zur Befestigung am Sattel und pro Seite jeweils ein Paar Lederlaschen, um weiteres Gepäck (Jacke, Decke…) zu befestigen.
<G-vec00407-001-s248><attach.befestigen><en> The Selflock Hook Easy Wide is a fast and simple way to attach devices to a truss.
<G-vec00407-001-s248><attach.befestigen><de> Der Selflock Haken Easy Wide ist eine schnelle und einfache Möglichkeit, Geräte an einer Traverse zu befestigen.
<G-vec00407-001-s249><attach.befestigen><en> You are able to attach with YOOX through an range of social networking stations.
<G-vec00407-001-s249><attach.befestigen><de> Sie sind in der Lage, zu befestigen mit YOOX über eine Reihe von social-networking-Stationen.
<G-vec00407-001-s250><attach.befestigen><en> But at the seeming external simplicity such hairdresses are not always simple performed by: it is simple to comb hair and to attach a veil will be obviously insufficiently for creation of a beautiful wedding hairdress.
<G-vec00407-001-s250><attach.befestigen><de> Aber bei der scheinenden äußerlichen Einfachheit sind solche Frisuren nicht in der Erfüllung immer einfach: einfach wird rastschessat das Haar den Schleier offenbar ungenügend für die Bildung der schönen Hochzeitsfrisur eben befestigen.
<G-vec00407-001-s251><attach.befestigen><en> Easy to attach and operate . 3
<G-vec00407-001-s251><attach.befestigen><de> Einfach zu befestigen und zu betreiben.
<G-vec00407-001-s252><attach.befestigen><en> Gel extra strong, alcohol-free, to give form and attach hairstyles for a more defined look.
<G-vec00407-001-s252><attach.befestigen><de> Gel extra stark, alkoholfrei, nach Form zu geben und befestigen Frisuren für eine definierte Look.
<G-vec00407-001-s253><attach.befestigen><en> Construct a jumper on the floor and ceiling at the required distance from the wall and attach.
<G-vec00407-001-s253><attach.befestigen><de> Konstruieren Sie einen Jumper auf dem Boden und die Decke im erforderlichen Abstand von der Wand und befestigen.
<G-vec00407-001-s254><attach.befestigen><en> Critical has also included a magnetic mount with both tattoo power supplies, allowing artists to attach them to any magnetic surface, making them easy to reach while tattooing.
<G-vec00407-001-s254><attach.befestigen><de> Critical enthält auch eine Magnethalterung, die es Tätowierern ermöglicht, sie auf jeder magnetischen Oberfläche zu befestigen, sodass die beim Tätowieren leicht zu erreichen sind.
<G-vec00407-001-s255><attach.befestigen><en> The monster can attach a sticky thread to the wall and pull itself to move around, but it moves straight only, so you have to figure out how to navigate the level.
<G-vec00407-001-s255><attach.befestigen><de> Das Monster können einen sticky Thread an der Wand befestigen und ziehen sich bewegen, aber es bewegt sich gerade nur, Sie müssen also herausfinden, wie die Ebene navigieren.
<G-vec00407-001-s256><attach.befestigen><en> These silicone AirPod covers attach effortlessly to your earphones, providing a way to keep them safe, clean and looking great.
<G-vec00407-001-s256><attach.befestigen><de> Diese Silikon-AirPod-Abdeckungen lassen sich mühelos an Ihren Kopfhörern befestigen und bieten eine Möglichkeit, sie sicher, sauber und schön zu halten.
<G-vec00407-001-s257><attach.befestigen><en> It can also damage the lining of the bladder allowing the bacteria to attach more readily.
<G-vec00407-001-s257><attach.befestigen><de> Es kann auch die Auskleidung der die Bakterien ermöglicht Blase beschädigen leichter zu befestigen.
<G-vec00407-001-s258><attach.befestigen><en> This plate holder comes complete with stainless steel mounting material to attach your license plate to the plate holder.
<G-vec00407-001-s258><attach.befestigen><de> Dieser Plattenhalter wird komplett mit Edelstahl-Befestigungsmaterial geliefert, um Ihr Nummernschild am Plattenhalter zu befestigen.
<G-vec00407-001-s259><attach.befestigen><en> A possible application: Attach the inventory list directly on the steel shelf.
<G-vec00407-001-s259><attach.befestigen><de> Ein möglicher Einsatzbereich: Die Inventurliste direkt am Stahlregal befestigen.
<G-vec00407-001-s260><attach.befestigen><en> Velcro fasteners allow you to attach the RX-9T to the ceiling of a car, for example.
<G-vec00407-001-s260><attach.befestigen><de> Mit Klettverschlüssen können Sie das RX-9T beispielsweise an der Decke eines Autos befestigen.
<G-vec00407-001-s261><attach.befestigen><en> Sony Alpha A6300 Sony Alpha a6500 A hot shoe can be used to attach an external flash, as well as light meters, viewfinders, rangefinders and other attachments.
<G-vec00407-001-s261><attach.befestigen><de> Sony Alpha A6300 Sony Alpha a6500 Ein Zubehörschuh (Hot shoe) kann benutzt werden, um ein externes Blitzgerät zu befestigen, sowie Belichtungsmesser, Bildsucher, Entfernungsmesser und andere Geräte.
<G-vec00407-001-s262><attach.befestigen><en> This allows you to attach the battery adapter to your camera.
<G-vec00407-001-s262><attach.befestigen><de> Dadurch können sie den Batterieadapter an ihrer Kamera befestigen.
<G-vec00407-001-s263><attach.befestigen><en> I folded the butterfly wings where they attach to the body, using a ruler to make the fold straight.
<G-vec00407-001-s263><attach.befestigen><de> Ich gefaltet die Schmetterlingsflügel wo befestigen sie auf den Körper, mit einem Lineal die Falte gerade machen.
<G-vec00407-001-s264><attach.befestigen><en> • Locate the drain hose located in the installation kit and attach the fitting to the drain fitting on the back of the ADVANTAGE Plus.
<G-vec00407-001-s264><attach.befestigen><de> • Nehmen Sie den Ableitungsschlauch, der im Installationskit enthalten ist, und befestigen Sie in am Abflussanschluss auf der Rückseite des ADVANTAGE Plus.
<G-vec00407-001-s265><attach.befestigen><en> Also, the proper technique for carrying a canoe overland as well as how to safely and securely attach the canoe to your vehicle at trips end are important things that you will learn when you take wilderness canoes training.
<G-vec00407-001-s265><attach.befestigen><de> Auch die richtige Technik für die Durchführung ein Kanu Overland und wie sicher und befestigen Sie das Kanu an Ihrem Fahrzeug auf Reisen Ende sind wichtige Dinge, die man lernt, wenn man Wildnis Kanus Ausbildung übernehmen wird.
<G-vec00407-001-s266><attach.befestigen><en> Remove the receiver and attach the hose to the boss on its side then attach the other end to the boss on the left side of the Tremblr.
<G-vec00407-001-s266><attach.befestigen><de> Entfernen Sie den Empfänger und befestigen Sie den Schlauch an der Seite auf der Nabe und befestigen Sie das andere Ende an der Nabe auf der linken Seite des Tremblr.
<G-vec00407-001-s268><attach.befestigen><en> Attach it to those small plastic container, stick it on drawers or any storage box and simply use a pen to write on it what you have stored inside.
<G-vec00407-001-s268><attach.befestigen><de> Befestigen Sie es auf Untergründen, kleben Sie es auf Schubladen oder eine beliebige Aufbewahrungsbox und schreiben Sie einfach mit einem Stift auf das, was Sie darin aufbewahrt haben.
<G-vec00407-001-s269><attach.befestigen><en> Attach the reader to your carâ€2s 16-pin port, which is usually located under the steering wheel.
<G-vec00407-001-s269><attach.befestigen><de> Befestigen Sie den Leser am 16-poligen Anschluss Ihres Autos, der sich normalerweise unter dem Lenkrad befindet.
<G-vec00407-001-s270><attach.befestigen><en> Attach any cinema lens to the viewfinder to get a true rendering of the image.
<G-vec00407-001-s270><attach.befestigen><de> Befestigen Sie jedes beliebige Filmobjektiv am Bildsucher um eine getreue photorealistische Visualisierung zu erhalten.
<G-vec00407-001-s271><attach.befestigen><en> By means of kruglogubets unbend connecting ringlets, fix them on caps and attach to them both parts of a lock.
<G-vec00407-001-s271><attach.befestigen><de> Bei der Hilfe kruglogubzew biegen Sie die Anschlussringel auseinander, festigen Sie sie auf den Blindverschlüssen und befestigen Sie an ihm beide Teile samotschka.
<G-vec00407-001-s272><attach.befestigen><en> Attach the cover reverse steps 1 and 2
<G-vec00407-001-s272><attach.befestigen><de> Befestigen Sie die Abdeckung entgegengesetzt der Schritte 1 und 2.
<G-vec00407-001-s273><attach.befestigen><en> Then you can place the bicycles one by one in the adjustable wheel channels and attach the frame brackets to the bicycles.
<G-vec00407-001-s273><attach.befestigen><de> Dann können Sie die Fahrräder nacheinander in die verstellbaren Radschienen, und befestigen Sie die Rahmenhalterungen an den Rädern.
<G-vec00407-001-s274><attach.befestigen><en> The vitreous is replaced by gas or silicone oil, in order to attach the retina again. Precaution
<G-vec00407-001-s274><attach.befestigen><de> Der Glaskörper wird durch Gas oder Silikonöl ersetzt, um die Netzhaut wieder zu befestigen, da sie nur durch den Druck des Glaskörpers in ihrer Lage gehalten wird.
<G-vec00407-001-s275><attach.befestigen><en> then attach any cold object to the damaged area - meat from the freezer, cold metal, or, ideally, an ice pack.
<G-vec00407-001-s275><attach.befestigen><de> Befestigen Sie dann einen kalten Gegenstand an der beschädigten Stelle - Fleisch aus dem Gefrierschrank, kaltes Metall oder idealerweise einen Eisbeutel.
<G-vec00407-001-s276><attach.befestigen><en> Attach the drive bracket to the machine using the nuts on the top bars.
<G-vec00407-001-s276><attach.befestigen><de> Befestigen Sie unter Verwendung der Muttern an den oberen Gewindestangen die Halteklammer an der Maschine.
<G-vec00407-001-s277><attach.befestigen><en> Simply attach the dartboard surrounds around the dartboard, clamps easily around a standard bristle dartboard, no fixings required.
<G-vec00407-001-s277><attach.befestigen><de> Befestigen Sie einfach die Dartscheibe umgibt auf der Dartscheibe, Klemmen Dartscheibe leicht um eine Standard-Borsten, keine Befestigungen erforderlich.
<G-vec00407-001-s278><attach.befestigen><en> PicNClic - Attach audio to picture, click the mouse or tap the screen to move to the next photo and sound clip.
<G-vec00407-001-s278><attach.befestigen><de> PicNClic - Befestigen Sie Audio zum Bild, klicken Sie mit der Maus oder auf den Bildschirm tippen, um zum nächsten Foto und Soundclip zu bewegen.
<G-vec00407-001-s279><attach.befestigen><en> Attach rods and springs to investigate simple pendulums, spring oscillations, Hooke's Law and rotational motion.
<G-vec00407-001-s279><attach.befestigen><de> Befestigen Sie Stäbe und Federn aneinander, um einfache Pendel, Federschwingungen, Hookesches Gesetz und Rotationsbewegung zu untersuchen.
<G-vec00407-001-s280><attach.befestigen><en> That it was not necessary to hold a hose a hand, to a wall at convenient height attach capture which will allow to place a grid in any position so that the water stream fell slantwise on shoulders and a thorax bathing irrespective of its growth.
<G-vec00407-001-s280><attach.befestigen><de> Damit man den Schlauch von der Hand nicht halten musste, befestigen Sie an der Wand in der bequemen Höhe die Ergreifung, die zulassen wird das Netz in einer beliebigen Lage so, dass der Strahl des Wassers zu unterbringen fiel schief auf die Schultern und den Brustkorb badend unabhängig von seiner Größe.
<G-vec00407-001-s281><attach.befestigen><en> Then, attach the clip to your monitor.
<G-vec00407-001-s281><attach.befestigen><de> Befestigen Sie den Clip dann an Ihrem Monitor.
<G-vec00407-001-s282><attach.befestigen><en> How to use it: Insert the photo into the frame from below and attach it to the twine with a clip.
<G-vec00407-001-s282><attach.befestigen><de> Wie man es benutzt: Legen Sie das Foto von unten in den Rahmen und befestigen Sie es mit einem Clip am Garn.
<G-vec00407-001-s283><attach.befestigen><en> Ligands contain polyunsaturated fatty acids that attach themselves to cholesterol and transport it to the liver for elimination, a function that avoids metabolic syndrome linked to hypertension
<G-vec00407-001-s283><attach.befestigen><de> Liganden enthalten ungesättigte Fettsäuren die sich an das Cholesterin befestigt und es zur Leber zur Beseitigung transportieren, eine Funktion die das metabolische Syndrom das zum Bluthochdruck führt verhindert.
<G-vec00407-001-s284><attach.befestigen><en> Made of a light Styrofoam tipped with a fishing line mount and a string to attach it to rod pod or rest.
<G-vec00407-001-s284><attach.befestigen><de> Hergestellt aus leichtem Styropor, ausgestattet mit einem Griff für die Angelschnur sowie mit einer Schnur, die an einem Träger oder Ständer befestigt ist.
<G-vec00407-001-s285><attach.befestigen><en> The Hartan Parasol is an ideal shade and is easy to attach at the Hartan stroller.
<G-vec00407-001-s285><attach.befestigen><de> Der Hartan Sonnenschirm ist ein idealer Schattenspender und wird einfach am Hartan Kinderwagen befestigt.
<G-vec00407-001-s286><attach.befestigen><en> They are easy to attach and are available in three different colors.
<G-vec00407-001-s286><attach.befestigen><de> Sie können einfach befestigt werden und sind dazu in drei unterschiedlichen Farben erhältlich.
<G-vec00407-001-s287><attach.befestigen><en> On the back there is a fastening, which makes it easy to attach, for example, to the belt in the trousers.
<G-vec00407-001-s287><attach.befestigen><de> Auf der Rückseite befindet sich eine Halterung, die zum Beispiel an dem Gürtel in der Hose leicht befestigt werden kann.
<G-vec00407-001-s288><attach.befestigen><en> These parts will attach securely to your engine in the space provided.
<G-vec00407-001-s288><attach.befestigen><de> Diese Teile können sicher an Ihrem Motor an der dafür vorgesehenen Stelle befestigt werden.
<G-vec00407-001-s289><attach.befestigen><en> The collar is a pretty standard design featuring a shiny riveted 'D' ring on the front for the leash to attach to.
<G-vec00407-001-s289><attach.befestigen><de> Das Halsband ist ein hübsches Standarddesign mit einem glänzenden D-Ring auf der Vorderseite, an dem die Leine befestigt werden kann.
<G-vec00407-001-s290><attach.befestigen><en> They will simply attach around your nipples thanks to their closure system.
<G-vec00407-001-s290><attach.befestigen><de> Sie werden einfach mit ihrem Schliesssystem um Ihre Brustwarzen befestigt.
<G-vec00407-001-s291><attach.befestigen><en> Thanks to the extremely strong embedded magnets, you can safely attach at least 8 knives with a weight of up to 900Â g.
<G-vec00407-001-s291><attach.befestigen><de> Dank der extrem starken verbauten Magnete können an diesem Messerblock mindestens 8 Messer mit bis zu 900 g Gewicht sicher befestigt werden.
<G-vec00407-001-s292><attach.befestigen><en> We do the third couple and we attach it to the first to two.
<G-vec00407-001-s292><attach.befestigen><de> Wir machen das dritte Paar und ist sie an ersten zwei befestigt.
<G-vec00407-001-s293><attach.befestigen><en> It's easy and fast to attach the Buggie to the double bass: the adjustable double belt system attaches to the neck of the double bass with a sturdy elastic strap, while the lower end of the Bass Buggie attaches to the endpin, which does not have to be removed.
<G-vec00407-001-s293><attach.befestigen><de> Der Bass Buggie kann in sehr kurzer Zeit am Kontrabass befestigt werden: das einstellbare Gürtelsystem wird mit einer strapazierfähigen, elastischen Schlaufe am Hals angebracht, während das andere Ende des Bass Buggies am Stachelhalter befestigt wird.
<G-vec00407-001-s294><attach.befestigen><en> The two support brackets are then deployed. These are used to attach the concreting platform to the formwork.
<G-vec00407-001-s294><attach.befestigen><de> Danach werden die beiden Anhängungen aufgeklappt, mit der die Betonierbühne an der Schalung befestigt wird.
<G-vec00407-001-s295><attach.befestigen><en> This wooden model, proposed by Master Series, is easy to install and has two removable fasteners, to attach to your subject's ankles.
<G-vec00407-001-s295><attach.befestigen><de> Dieses Holzmodell von Master Series ist einfach zu installieren und hat zwei abnehmbare Befestigungselemente, die an den Knöcheln des Untergebenen befestigt werden.
<G-vec00407-001-s296><attach.befestigen><en> It can also be used to attach paintings to the inside of transportation crates.
<G-vec00407-001-s296><attach.befestigen><de> So können Gemälde auch im Inneren der Transportkiste befestigt werden.
<G-vec00407-001-s297><attach.befestigen><en> The magnetic frames ensure that you can easily attach the various filters to the filter holder.
<G-vec00407-001-s297><attach.befestigen><de> Die Magnetrahmen sorgen dafür, dass die verschiedenen Filter einfach am Filterhalter befestigt werden können.
<G-vec00407-001-s298><attach.befestigen><en> In order to use it even more easily, but also in all situations, Doc Johnson has supplied this dildo with a Vac-U-Lock removable suction cup, which will attach securely to any smooth, flat surface.
<G-vec00407-001-s298><attach.befestigen><de> Um ihn noch einfacher, aber auch in allen Situationen benutzen zu können, liefert Doc Johnson diesen Dildo mit einem abnehmbaren Vac-U-Lock Saugnapf, der sicher an jeder glatten, ebenen Oberfläche befestigt werden kann.
<G-vec00407-001-s299><attach.befestigen><en> The larva to become an oyster needs to attach to a wall somewhere.
<G-vec00407-001-s299><attach.befestigen><de> Die Larve, die eine Auster werden soll, muss irgendwo an einer Wand befestigt werden.
<G-vec00407-001-s300><attach.befestigen><en> The white charging cable has a round head with two magnetic buttons that attach securely to your toy.
<G-vec00407-001-s300><attach.befestigen><de> Das weisse Ladekabel hat einen runden Kopf mit zwei Magnettasten, die sicher an Ihrem Sextoy befestigt werden können.
<G-vec00407-001-s301><attach.befestigen><en> Two brass mounting screws are provided to attach the cartridge to the shell.
<G-vec00407-001-s301><attach.befestigen><de> Mit den beiden mitgelieferten Messingschrauben wird der Tonabnehmer an der Headshell befestigt.
<G-vec00407-001-s321><attach.beifügen><en> You can unsubscribe at any time by following a link which we attach to all e-mails or by sending a message to the contact details set out above.
<G-vec00407-001-s321><attach.beifügen><de> Sie können sich jederzeit über einen Link, den wir jeder E-Mail beifügen, oder durch eine Nachricht an die oben angegebenen Kontaktdaten abmelden.
<G-vec00407-001-s322><attach.beifügen><en> If the TOP is to be dealt with in a particular Rectorate meeting, please attach an explanation/reason.
<G-vec00407-001-s322><attach.beifügen><de> Sitzungsdatum Wenn der TOP in einer bestimmten Rektoratssitzung behandelt werden soll, bitte Erläuterung/Begründung beifügen.
<G-vec00407-001-s323><attach.beifügen><en> As evidence of their entitlement, the heirs must attach copies of all documents which are liable to prove their entitlements.
<G-vec00407-001-s323><attach.beifügen><de> Als Berechtigungsnachweise müssen die Erben Kopien sämtlicher Dokumente beifügen, die ihre Anspruchsberechtigung nachweisen.
<G-vec00407-001-s324><attach.beifügen><en> Here you have the possibility to attach a file to your application.
<G-vec00407-001-s324><attach.beifügen><de> Hier haben Sie die Möglichkeit ihrer Bewerbung eine Datei beifügen.
<G-vec00407-001-s325><attach.beifügen><en> Attach my proof (invoice...).
<G-vec00407-001-s325><attach.beifügen><de> Meinen Beleg beifügen (Rechnung...).
<G-vec00407-001-s326><attach.beifügen><en> The list of mandatory schedules has changed – for instance, corporations are no longer required to attach an extract from the Commercial Register, or similar register, if the information is available on a remote access basis.
<G-vec00407-001-s326><attach.beifügen><de> Es kommt zu Änderungen in der Aufzählung der Pflichtanlagen – die Firmen zum Beispiel werden nicht mehr den Auszug aus dem Handelsregister oder einem anderen ähnlichen Register beifügen müssen, in dem sie eingetragen sind, sofern die in diesen Registern enthaltenen Angaben durch Fernzugriff ermittelbar sind.
<G-vec00407-001-s327><attach.beifügen><en> I will attach some of my bridal photos.
<G-vec00407-001-s327><attach.beifügen><de> Ich werde einige meiner Brautfotos beifügen.
<G-vec00407-001-s328><attach.beifügen><en> Send us a picture of your smile by Email (Attachment on Contact Form) or via Facebook (send a message and attach your smile).
<G-vec00407-001-s328><attach.beifügen><de> Schicke das Smile Foto per Email (Attachment im Kontakt-Formular) oder via Facebook (Message schicken und Bild beifügen).
<G-vec00407-001-s329><attach.beifügen><en> If you wish to attach a document to your email message, log in to My SVB with your DigiD code.
<G-vec00407-001-s329><attach.beifügen><de> "Wenn Sie eine Anlage beifügen wollen, melden Sie sich mit Ihrem DigiD über ""Meine SVB"" an."
<G-vec00407-001-s330><attach.beifügen><en> You are welcome to attach graphics, pictures or schematic representations.
<G-vec00407-001-s330><attach.beifügen><de> Gerne können Sie Grafiken, Bilder oder schematische Darstellungen beifügen.
<G-vec00407-001-s331><attach.beifügen><en> When you return goods, you can attach a copy of the invoice and write whether you want the money back or the goods exchanged with another product.
<G-vec00407-001-s331><attach.beifügen><de> Wenn Sie Waren zurückschicken, können Sie eine Kopie der Rechnung beifügen und schreiben, ob Sie das Geld zurückgeben oder die Waren mit einem anderen Produkt austauschen möchten.
<G-vec00407-001-s332><attach.beifügen><en> You can attach up to ten photographic or other graphic reproductions as representation of the design, particularly, to show the design from different angles.
<G-vec00407-001-s332><attach.beifügen><de> Sie können als Wiedergabe bis zu zehn Fotos oder sonstige grafische Darstellungen des Designs beifügen, insbesondere um das Design aus verschiedenen Perspektiven zu zeigen.
<G-vec00407-001-s333><attach.beifügen><en> When applying for admission through uni-assist, you always have to attach all certificates documenting your qualifications stated in the application form.
<G-vec00407-001-s333><attach.beifügen><de> Grundsätzlich müssen Sie alle Bildungsnachweise beifügen, die Ihre im Antragsformular angegebenen Qualifikationen belegen.
<G-vec00407-001-s334><attach.beifügen><en> Applicants who wish to explain unavoidable delays in their career development must therefore explicitly state the relevant circumstances in the proposal, covering letter and curriculum vitae and if necessary (if the circumstance is not self-explanatory) attach a short explanation.
<G-vec00407-001-s334><attach.beifügen><de> Antragstellende, die sich auf unvermeidbare Verzögerungen im wissenschaftlichen Werdegang berufen möchten, müssen daher im Antrag, im Anschreiben und im Lebenslauf ausdrücklich auf den jeweiligen Umstand hinweisen und gegebenenfalls (sofern dieser Umstand nicht selbsterklärend ist) eine kurze Erläuterung beifügen.
<G-vec00407-001-s335><attach.beifügen><en> If you would like to submit photos of antiques or art that you would like one of our purchase quote, you can use the forms that are listed below (you can attach all photos you want).
<G-vec00407-001-s335><attach.beifügen><de> Wenn Sie Fotos von Antiquitäten oder der Kunst, dass Sie eines unserer Einkaufsangebot gerne einreichen möchten, können Sie die Formulare, die unten aufgeführt sind (Sie können alle gewünschten Fotos beifügen).
<G-vec00407-001-s336><attach.beifügen><en> if the texts are not written in one of the five languages of publication (German, English, Spanish, Italian, French), please attach a brief summary in one of these languages.
<G-vec00407-001-s336><attach.beifügen><de> Für den Fall, daß diese Texte nicht in einer der fünf Sprachen geschrieben worden sind (deutsch, englisch, spanisch, italienisch, französisch), eine kurze Zusammenfassung in einer dieser Sprachen beifügen.
<G-vec00407-001-s337><attach.beimessen><en> We therefore reaffirm the importance we attach to mutually advantageous transatlantic defence industrial cooperation.
<G-vec00407-001-s337><attach.beimessen><de> Wir bekräftigen daher die Wichtigkeit, die wir einer für beide Seiten vorteilhaften transatlantischen Zusammenarbeit der Rüstungsindustrien beimessen.
<G-vec00407-001-s338><attach.beimessen><en> The SNB will, therefore, continue to attach great importance to the exchange rate when determining its monetary policy.
<G-vec00407-001-s338><attach.beimessen><de> Daher wird die SNB bei der Festlegung ihrer Geldpolitik dem Wechselkurs weiterhin große Bedeutung beimessen.
<G-vec00407-001-s339><attach.beimessen><en> With their mostly spectacularly appearances the car manufacturers demonstrate which importance they attach to the classic world fair.
<G-vec00407-001-s339><attach.beimessen><de> Die Autohersteller demonstrieren mit ihren meist spektakulären Auftritten, welchen Stellenwert die der Klassik-Weltmesse beimessen.
<G-vec00407-001-s340><attach.beimessen><en> Rooms are very clean, with window/balcony in every room, all rooms with attach bath, hot & cold shower.
<G-vec00407-001-s340><attach.beimessen><de> Zimmer sind sehr sauber, mit Fenster / Balkon in jedem Zimmer, alle Zimmer mit Bad beimessen, heiß & kalt Dusche.
<G-vec00407-001-s341><attach.beimessen><en> That being said, the concepts differ from each other in terms of the relative importance they attach to economic, social and environmental concerns and the prominence they give to present and future human welfare.
<G-vec00407-001-s341><attach.beimessen><de> Die Konzepte unterscheiden sich gleichwohl darin, welche relative Bedeutung sie jeweils ökonomischen, sozialen und ökologischen Belangen beimessen und welchen Stellenwert sie der menschlichen Wohlfahrt in Gegenwart und Zukunft zubilligen.
<G-vec00407-001-s342><attach.beimessen><en> "Through his arguments, Rid sets himself against the contentions of the ""mainstream"" military and security experts who attach ever-increasing importance to the Internet as a theatre of war and who put the threat it poses to modern, networked societies on a par with the menace of nuclear weapons."
<G-vec00407-001-s342><attach.beimessen><de> "Rid stellt sich in seiner Argumentation gegen die Vorstellung des ""Mainstreams"" der Militärs und Sicherheitsexperten, die dem Kriegsschauplatz Internet immer größere Bedeutung beimessen und die Bedrohung für die modernen, vernetzten Gesellschaften sogar mit der Bedrohung durch Nuklearwaffen in Kontext setzen."
<G-vec00407-001-s343><attach.beimessen><en> ◆ To assure to get good result, the asphalt binder that used to attach the Paving Mat to the road must be hot asphalt, but not emulsified asphalt.
<G-vec00407-001-s343><attach.beimessen><de> ◆ Versichern um gutes Ergebnis, der Asphalt-Binder zu erhalten, mit dem die Straße die Matte ebnet beimessen muss Heißasphalt, aber nicht emulgierte Asphalt sein.
<G-vec00407-001-s344><attach.beimessen><en> "The only important question is what social or moral significance we attach to their ""symptoms""."
<G-vec00407-001-s344><attach.beimessen><de> "Die einzig wichtige Frage ist, welche moralische oder soziale Bedeutung wir ihren „Symptomen"" beimessen."
<G-vec00407-001-s345><attach.beimessen><en> Evidently it’s a task to which many people attach great importance.
<G-vec00407-001-s345><attach.beimessen><de> Es handelt sich offensichtlich um eine Aufgabe, der viele große Bedeutung beimessen.
<G-vec00407-001-s346><attach.beimessen><en> The location of the Fraunhofer Project Group at BioPark Regensburg strongly believes that external university research institutes attach importance to dialogue with the University.
<G-vec00407-001-s346><attach.beimessen><de> Die Ansiedlung der Fraunhofer Projektgruppe im BioPark Regensburg bekundet das Gewicht, das außeruniversitäre Forschungsstätten dem Dialog mit der Universität beimessen.
<G-vec00407-001-s347><attach.beimessen><en> A client survey conducted by LGT in German-speaking countries in 2018 confirms that private banking clients from Germany, Austria and Switzerland attach great importance to sustainability.
<G-vec00407-001-s347><attach.beimessen><de> Eine 2018 im deutschsprachigen Raum durchgeführte Kundenbefragung der LGT bestätigt, dass Private-Banking-Kunden aus Deutschland, Österreich und der Schweiz dem Thema Nachhaltigkeit viel Bedeutung beimessen.
<G-vec00407-001-s349><attach.beimessen><en> 1622 You need not trouble yourself much about X's ideas or attach importance to them.
<G-vec00407-001-s349><attach.beimessen><de> Du brauchst dich über Xs Ideen nicht sehr zu beunruhigen oder ihnen große Wichtigkeit beimessen.
<G-vec00407-001-s350><attach.beimessen><en> For 2015 we were able to almost double our exhibition space, which underscores the great importance we attach to this venue.
<G-vec00407-001-s350><attach.beimessen><de> Dass wir unsere Ausstellungsfläche in 2015 nahezu verdoppeln konnten, zeigt deutlich, welchen hohen Stellenwert wir der Ambiente beimessen.
<G-vec00407-001-s351><attach.beimessen><en> Those who believe in the ambivalence of everything good and bad, and are convinced to be able to actively influence this in their favour through ritually correct behaviour, will attach above-average importance to the rites within their culture.
<G-vec00407-001-s351><attach.beimessen><de> Wer an die Ambivalenz aller guten und schlechten Dinge glaubt und davon überzeugt ist, diese durch rituell korrektes Verhalten aktiv zu seinen Gunsten beeinflussen zu können, wird dem Ritual im Rahmen seiner Kultur überdurchschnittliche Bedeutung beimessen.
<G-vec00407-001-s626><attach.verbinden><en> And outside the studio, artistic practices attach to urban and planetary infrastructures and other sorts of expanded sites of practice that acknowledge one more thing: the materiality of the digital is not reducible to the screen, not to software, and not even to hardware.
<G-vec00407-001-s626><attach.verbinden><de> Und außerhalb des Ateliers verbinden sich künstlerische Praktiken mit städtischen und globalen Infrastrukturen und anderweitigen erweiterten Stätten der Praxis, die einen weiteren Aspekt anerkennen: Die Materialität des Digitalen ist nicht auf den Bildschirm, die Software, nicht einmal auf die Hardware reduzierbar.
<G-vec00407-001-s627><attach.verbinden><en> It is possible to arrive and differently: to the wind wheel established on a mast to attach the compressor which will be through a pipe or small diameter a flexible hose to swing in water air. On the hose end there should be a spray.
<G-vec00407-001-s627><attach.verbinden><de> Man kann und anders handeln: zum Windrad, das auf dem Mast bestimmt ist, den Kompressor zu verbinden, der durch das Rohr oder des kleinen Durchmessers der flexible Schlauch wird ins Wasser die Luft zu schwingen.
<G-vec00407-001-s628><attach.verbinden><en> On the outer edge of the package you can select which greeting you want to attach to the gift or what the occasion for the gift is.
<G-vec00407-001-s628><attach.verbinden><de> Auf der Außenkante der Verpackung können Sie ankreuzen, welchen guten Wunsch Sie mit dem Geschenk verbinden möchten oder was der Anlass für das Geschenk ist.
<G-vec00407-001-s629><attach.verbinden><en> Juwelier Kamerbeek BV has the right to reject orders or attach specific terms and conditions to the delivery, unless expressly stated otherwise.
<G-vec00407-001-s629><attach.verbinden><de> Juwelier Kamerbeek BV hat das Recht, Bestellungen abzulehnen oder gewisse Bedingungen mit der Lieferung zu verbinden, es sei denn, es wurde ausdrücklich anders bestimmt.
<G-vec00407-001-s630><attach.verbinden><en> Water heaters attach To a flue pipes from a roofing steel in the thickness of 0,8-1 mm, and diameter of connecting pipes should be not less than 80 mm for ГB-50 mm and ГB-80 mm and not 100 mm - for ГB-120.
<G-vec00407-001-s630><attach.verbinden><de> Die Wasserwärmer verbinden An den Schornstein von den Rohren aus dem Dachstahl von der Dicke 0,8-1 mm, wobei der Durchmesser der Anschlussrohre nicht weniger als 80 mm für AГB-50 mm und AГB-80 mm nicht 100 mm - für AГB-120 sein soll.
<G-vec00407-001-s631><attach.verbinden><en> Techniques derived from earlier forms of collage can help us move beyond the rather antiquated obsession with digital and analog, and toward discussions that attach to technical media culture and the arts in new ways.
<G-vec00407-001-s631><attach.verbinden><de> Techniken, die aus früheren Formen der Collage abgeleitet sind, können uns helfen, über die eher antiquierte Obsession mit dem Digitalen und Analogen hinaus zu kommen und uns Diskussionen zuzuwenden, die sich auf neue Weisen mit technischer Medienkultur und den Künsten verbinden.
<G-vec00407-001-s632><attach.verbinden><en> Velcro straps attach the Caddy securely to the saddle rails and seat post.
<G-vec00407-001-s632><attach.verbinden><de> Klettbänder verbinden die Tasche sicher mit den Sattelstreben und der Sattelstütze.
<G-vec00407-001-s633><attach.verbinden><en> Polonium, cerium, and alkylating agents attach to each other in random combinations, yet only one of the many different combinations is ever found in cancer patients and is never found in healthy people.
<G-vec00407-001-s633><attach.verbinden><de> Cerium und Alkylierungsmittel verbinden sich in zufälligen Kombinationen miteinander, bislang wurde nur eine der vielen verschiedenen Kommbination in Krebspatienten gefunden, aber nie bei gesunden Menschen.
<G-vec00407-001-s634><attach.verbinden><en> The mind can attach itself to the body, to every single cell of the body, and it can detach itself from it.
<G-vec00407-001-s634><attach.verbinden><de> Der Verstand kann sich mit dem Leib verbinden, mit jeder einzelnen Zelle des Leibes, und er kann sich davon lösen.
<G-vec00407-001-s635><attach.verbinden><en> The striking contrast of jet black and red gold plays across the design of the unusual oval dial, set almost like a jewel between the extra-long lugs which attach it to the luxurious satin strap.
<G-vec00407-001-s635><attach.verbinden><de> Das ungewöhnliche ovale Zifferblatt, das fast wie ein Juwel zwischen den extralangen Bandanstößen sitzt, die es mit dem edlen Satinarmband verbinden, spielt mit dem eindrucksvollen Kontrast zwischen tiefem Schwarz und Rotgold.
<G-vec00407-001-s636><attach.verbinden><en> To move and attach the selected tracks, right click with the mouse over one of them and select “Move” from the context menu.
<G-vec00407-001-s636><attach.verbinden><de> Um ausgewählte Gleisabschnitte zu verschieben und zu verbinden, klicken Sie ein Element des Abschnitts mit der rechten Maustaste an und wählen Sie “Verschieben”.
<G-vec00407-001-s637><attach.verbinden><en> In this menu item you can attach a disk image to 1 of the 4 virtual disk drives.
<G-vec00407-001-s637><attach.verbinden><de> In dieser Menüwahl können Sie eine Diskette zu einem der 4 virtuellen Laufwerke verbinden.
<G-vec00407-001-s638><attach.verbinden><en> All posts Engine mounts attach the engine to the pylons.
<G-vec00407-001-s638><attach.verbinden><de> Alle Beiträge Triebwerksaufhängungen verbinden das Triebwerk mit der Triebwerksgondel.
<G-vec00407-001-s639><attach.verbinden><en> the Copper attach to a flue by means of pipes from a roofing tin (thickness of 0,8-1 mm), diameter of connecting pipes is not less diameter of a branch pipe.
<G-vec00407-001-s639><attach.verbinden><de> den Kessel verbinden an den Schornstein mit Hilfe der Rohre aus dach- schesti (die Dicke 0,8-1 mm), den Durchmesser der Anschlussrohre gibt es mehreren Durchmesser des Stutzens nicht.
<G-vec00407-001-s640><attach.verbinden><en> We attach emotions to results because that’s the best way to move towards success, whatever the pursuit may be.
<G-vec00407-001-s640><attach.verbinden><de> Wir verbinden Emotionen zu Ergebnissen, denn das ist die beste Art, erfolgreich zu sein, egal, wonach wir streben.
<G-vec00407-001-s641><attach.verbinden><en> One example of the fruits of the meeting of the General Chapter is the Confraternity of St. Peter itself. Six years ago it was suggested by a number of priests that a group be established for the laity which would allow them to concretely attach themselves spiritually to the work of our Society of Apostolic Life.
<G-vec00407-001-s641><attach.verbinden><de> Ein Beispiel für die Früchte des Generalkapitels ist die Konfraternität selbst: Vor sechs Jahren brachte eine Reihe von Priestern das Anliegen vor, für die Gläubigen eine konkrete Möglichkeit zu schaffen, sich geistlich mit dem Wirken unserer Gesellschaft apostolischen Lebens zu verbinden.
<G-vec00407-001-s642><attach.verbinden><en> DEFAULTMEDIASERVER specifies the media server to which you want the Desktop Agent to attach after installation.
<G-vec00407-001-s642><attach.verbinden><de> DEFAULTMEDIASERVER gibt den Medienserver an, mit dem Sie Desktop Agent nach Installation verbinden möchten.
<G-vec00407-001-s643><attach.verbinden><en> It aids to create breast cells and enlarge the breasts by lengthening the ducts that attach to the nipple, along with boost the cellulite as well as tendons which offer breasts their assistance and shape.
<G-vec00407-001-s643><attach.verbinden><de> Es hilft Brustgewebe sowie zu erweitern, um die Brüste zu entwickeln, indem die Kanäle erstrecken, die auf die Brustwarze verbinden, zusammen mit den Fettzellen steigen und auch Bänder, die Brüste ihre Unterstützung und auch bilden.
<G-vec00407-001-s644><attach.verbinden><en> The reversible USB 3.1 Type-C™ connector is the same at both ends and on both sides, so it's easy to attach.
<G-vec00407-001-s644><attach.verbinden><de> Der wendbare USB 3.1 Type-CTM-Stecker ist auf beiden Seiten sowie an beiden Enden identisch und deshalb viel einfacher zu verbinden.
<G-vec00407-001-s645><attach.verbinden><en> Note: If you want to perform AVCHD video file recovery from any external drive, then attach it to the computer on which you have installed the software.
<G-vec00407-001-s645><attach.verbinden><de> Hinweis: Wenn Sie die AVCHD-Videodateiwiederherstellung von einem externen Laufwerk durchführen möchten, verbinden Sie sie mit dem Computer, auf dem Sie die Software installiert haben.
<G-vec00407-001-s646><attach.verbinden><en> To serve, pour 6 to 8 ounces into a very clean glass bottle, attach nipple and set in a pan of simmering water.
<G-vec00407-001-s646><attach.verbinden><de> Um zu dienen, gießen Sie 6 - 8 Unzen in die sehr reine Glasflasche aus, verbinden Sie cocok und den Satz im Kochtopf des Kochens des Wassers.
<G-vec00407-001-s647><attach.verbinden><en> Insert the cables plug and then attach the other end to a power source to commence charging.
<G-vec00407-001-s647><attach.verbinden><de> Stecken Sie den Kabelstecker ein und verbinden Sie das andere Ende mit einer Stromquelle, um mit dem Aufladen zu beginnen.
<G-vec00407-001-s648><attach.verbinden><en> Attach devices to theRing networkorEthernetshape using the shape's built-in connectors.
<G-vec00407-001-s648><attach.verbinden><de> Verbinden Sie die Geräte durch den eingebauten Verbinder mit den Formen Ringnetz oder Ethernet.
<G-vec00407-001-s649><attach.verbinden><en> The way it works is relatively simple: Each player generate a ‘seed’ (a string of random characters) and attach it to the create or join request.
<G-vec00407-001-s649><attach.verbinden><de> Die Funktionsweise ist relativ einfach: Jeder Spieler erzeugt eine ‚Samen‘ (eine Folge von zufälligen Zeichen) und verbinden Sie es mit dem Erstellen oder Anforderung beitreten.
<G-vec00407-001-s650><attach.verbinden><en> Start up a spiral from an additional wire on 15 rounds, attach a small branch and make 15 more turns.
<G-vec00407-001-s650><attach.verbinden><de> Lassen Sie die Spirale aus dem zusätzlichen Draht auf 15 Windungen, verbinden Sie klein wetotschku und machen Sie noch 15 Wendungen.
<G-vec00407-001-s651><attach.verbinden><en> In the case where you have formatted the entire hard drive, disconnect the hard drive and attach it to a healthy computer (having the recovery software) as a secondary drive.
<G-vec00407-001-s651><attach.verbinden><de> In dem Fall, dass Sie die gesamte Festplatte formatiert, trennen Sie die Festplatte und verbinden Sie es mit einem gesunden Computer (mit der Wiederherstellung-Software) als sekundäres Laufwerk.
<G-vec00407-001-s652><attach.verbinden><en> Attach the second branch and make 15 more spiral turns.
<G-vec00407-001-s652><attach.verbinden><de> Verbinden Sie zweite wetotschku und machen Sie noch 15 Windungen der Spirale.
<G-vec00407-001-s653><attach.verbinden><en> Attach the other end of the wire at the edge of the reflector.
<G-vec00407-001-s653><attach.verbinden><de> Das andere Ende des Fadens verbinden Sie mit einer Heftklammer am Parabolspiegel.
<G-vec00407-001-s654><attach.verbinden><en> Attach one end of the USB to the printer and the other end to the printer server.
<G-vec00407-001-s654><attach.verbinden><de> Verbinden Sie das eine Ende des USB-Kabels mit dem Drucker und das andere mit dem Druckserver.
<G-vec00407-001-s655><attach.verbinden><en> 2.2 Accessing Removable Media # To access CDs/DVDs or flash disks, insert or attach the medium.
<G-vec00407-001-s655><attach.verbinden><de> Zum Zugriff auf CDs/DVDs oder Flashlaufwerke legen Sie das entsprechende Medium ein (oder verbinden Sie das Medium).
<G-vec00519-002-s128><attach.anbringen><en> On such boards it is possible to attach leaflets with examples, different reminders or notes from my mother.
<G-vec00519-002-s128><attach.anbringen><de> Auf solchen Tafeln können Prospekte mit Beispielen, verschiedenen Erinnerungen oder Notizen von meiner Mutter angebracht werden.
<G-vec00519-002-s129><attach.anbringen><en> Silicone cardholder with 3M tape to attach it to the back of your smartphone.
<G-vec00519-002-s129><attach.anbringen><de> Der Halter kann auf der Rückseite Ihres Smartphones angebracht werden.
<G-vec00519-002-s131><attach.anbringen><en> While the Wii Remote solved a variety of problems and won over its critics, we were then faced with a new challenge. In order to actually play with the Wii Remote, we needed to attach a sensor to the TV.
<G-vec00519-002-s131><attach.anbringen><de> Während die Wii-Fernbedienung zwar eine Reihe von Problemen gelöst und auch die Kritiker überzeugt hat, trat für uns eine neue Herausforderung auf: Um mit der Wii-Fernbedienung zu spielen, musste ein Sensor am Fernsehgerät angebracht werden.
<G-vec00519-002-s132><attach.anbringen><en> Quickly personalise your inflatable SUP with a variety of different coloured bungee cords to attach to your cargo tie down points.
<G-vec00519-002-s132><attach.anbringen><de> GEPÄCK-SPANNGURT Personalisiere dein aufblasbares SUP mit verschiedenfarbigen Spanngurten, die an den Gepäcksystembefestigungen angebracht werden können.
<G-vec00519-002-s133><attach.anbringen><en> You can also use a laser level, which may be easier and more accurate (there are many models that can attach to a wall).
<G-vec00519-002-s133><attach.anbringen><de> Du kannst auch eine Wasserwaage mit Laser benutzen, was einfacher und genauer sein könnte (es gibt viele Modelle, die an der Wand angebracht werden können).
<G-vec00519-002-s134><attach.anbringen><en> USD Cart (0) indicators and sidelights that magnetically attach to the handlebar ends of your bicycle.
<G-vec00519-002-s134><attach.anbringen><de> WingLights 360 sind unsere originalen, hochwertigen Fahrtrichtungsanzeiger, die an den Lenkerenden Ihres Fahrrads angebracht werden.
<G-vec00519-002-s135><attach.anbringen><en> Can now attach extended QD mag.
<G-vec00519-002-s135><attach.anbringen><de> Erweitertes QD-Magazin kann nun angebracht werden.
<G-vec00519-002-s200><attach.anfügen><en> Select a file to attach it to your email.
<G-vec00519-002-s200><attach.anfügen><de> Wählen Sie eine Datei, um sie zu Ihrer e-Mail anzufügen.
<G-vec00519-002-s201><attach.anfügen><en> Or click Attach Item to attach Outlook items, such as email messages, tasks, contacts, or calendar items.
<G-vec00519-002-s201><attach.anfügen><de> Sie können auch auf Element anfügen klicken, um Outlook-Elemente anzufügen, wie E-Mail-Nachrichten, Aufgaben, Kontakte oder Kalenderelemente.
<G-vec00519-002-s202><attach.anfügen><en> If, acting on the results of this investigation, the Entrepreneur has sound reasons for not concluding the contract, he is lawfully entitled to refuse an order or request supported by reasons, or to attach special terms to the implementation.
<G-vec00519-002-s202><attach.anfügen><de> Wenn der Unternehmer, der auf dieser Untersuchung beruht, gute Gründe hat, den Vertrag nicht abzuschließen, ist er berechtigt, eine Bestellung oder Anfrage abzulehnen, zu motivieren oder besondere Bedingungen an die Ausführung anzufügen.
<G-vec00519-002-s203><attach.anfügen><en> The customer is also obliged to declare himself as sender in every message and - subject to further legal provisions - to attach an imprint with at least the address and a telephone contact option.
<G-vec00519-002-s203><attach.anfügen><de> Der Kunde ist zudem verpflichtet, sich in jeder Nachricht als Absender auszuweisen und – vorbehältlich weitergehender gesetzlicher Bestimmungen – ein Impressum mit mindestens der Anschrift sowie einer telefonischen Kontaktmöglichkeit anzufügen.
<G-vec00519-002-s204><attach.anfügen><en> To attach a file to a new post, simply click the [Manage Attachments] button at the bottom of the post composition page, and locate the file that you want to attach from your local hard drive.
<G-vec00519-002-s204><attach.anfügen><de> Um eine Datei einem neuen Beitrag anzufügen, klicke den [Dateianhänge] Knopf unten auf der Beitragsseite, wähle die Datei, die du von deinem lokalen Laufwerk anfügen willst, und klicke auf [Speichern].
<G-vec00519-002-s205><attach.anfügen><en> To send us your screenshots please click here, you have the possibility to attach files.
<G-vec00519-002-s205><attach.anfügen><de> Auf unserem Kontaktformular haben Sie die Möglichkeit, Dateien anzufügen.
<G-vec00519-002-s206><attach.anfügen><en> The administrator may allow you to use the attachment feature of this board, which gives you the ability to attach files of certain types to your posts.
<G-vec00519-002-s206><attach.anfügen><de> Der Administrator kann Ihnen erlauben, Anhänge an Ihre Beiträge anzufügen.
<G-vec00519-002-s207><attach.anfügen><en> If you are attempting to attach a database, retry the operation with the correct files.
<G-vec00519-002-s207><attach.anfügen><de> Falls Sie eine Datenbank anzufügen versuchen, wiederholen Sie den Vorgang mit den richtigen Dateien.
<G-vec00519-002-s550><attach.anhängen><en> Once per turn: You can target 1 Special Summoned monster your opponent controls; attach it to this card as a face-up Xyz Material.
<G-vec00519-002-s550><attach.anhängen><de> Einmal pro Spielzug: Du kannst 1 als Spezialbeschwörung beschworenes Monster wählen, das dein Gegner kontrolliert; hänge es als offenes Xyz-Material an diese Karte an.
<G-vec00519-002-s551><attach.anhängen><en> In words: Add 25 to the ones digit and attach the square of the ones digit.
<G-vec00519-002-s551><attach.anhängen><de> Umsetzung: Addiere zur Einerziffer 25 und hänge das Quadrat der Einerziffer an.
<G-vec00519-002-s552><attach.anhängen><en> If you are interested in working with us, fill out the following information and attach your curriculum.
<G-vec00519-002-s552><attach.anhängen><de> Wenn du Interesse daran hast mit uns zusammenzuarbeiten, fülle einfach die nachfolgenden Informationen aus und hänge deinen Lebenslauf an.
<G-vec00519-002-s553><attach.anhängen><en> Attach 2 or 3 photos, with the best quality possible, of your accessory entry.
<G-vec00519-002-s553><attach.anhängen><de> Hänge auch 2 bis 3 Fotos deines Accessoires an, in möglichst hoher Qualität und Auflösung.
<G-vec00519-002-s554><attach.anhängen><en> Don't attach Graphics or Photos or long dissertations or your life history.
<G-vec00519-002-s554><attach.anhängen><de> Hänge keine Graphiken oder Photos an oder lange Dissertationen oder deine Lebensgeschichte.
<G-vec00519-002-s555><attach.anhängen><en> Attach that image to the ticket.
<G-vec00519-002-s555><attach.anhängen><de> Hänge dieses Bild an das Ticket an.
<G-vec00519-002-s556><attach.anhängen><en> Place Gollum and Bilbo Baggins in the riddle area and attach Bilbo's Magic Ring to Bilbo Baggins.
<G-vec00519-002-s556><attach.anhängen><de> Lege Gollum und Bilbo Beutlin in die Rätselzone und hänge Bilbos magischer Ring an Bilbo Beutlin an.
<G-vec00519-002-s557><attach.anhängen><en> Attach the file to a new e-mail and send it to your own e-mail address.
<G-vec00519-002-s557><attach.anhängen><de> Hänge die Datei an eine neue E-Mail an und sende sie an deine eigene E-Mail-Adresse.
<G-vec00519-002-s558><attach.anhängen><en> Attach additional documents and associate them with notebook pages.
<G-vec00519-002-s558><attach.anhängen><de> Hänge zusätzliche Dokumente an und verbinde sie mit den Notizbuchseiten.
<G-vec00519-002-s559><attach.anhängen><en> There are many attach for those untrained who can try.
<G-vec00519-002-s559><attach.anhängen><de> Es gibt viele Hänge an denen sich Ungeübte probieren können.
<G-vec00519-002-s170><attach.anschließen><en> Alternatively, use the line in with an aux lead (not included) and attach an ipod/MP3 player.
<G-vec00519-002-s170><attach.anschließen><de> Alternativ können Sie über den Line-Eingang und ein Aux-Kabel (nicht enthalten) einen iPod oder MP3-Player anschließen.
<G-vec00519-002-s171><attach.anschließen><en> Neither it plays DVDs, nor one can attach a Projector.
<G-vec00519-002-s171><attach.anschließen><de> Weder spielt er DVDs, noch kann man einen Projector anschließen.
<G-vec00519-002-s173><attach.anschließen><en> PC measurement with external DAQ systems has established in measurement technology: Connect a DAQ device to the notebook, attach signals, and measure.
<G-vec00519-002-s173><attach.anschließen><de> In der Messtechnik hat sich das Messen am PC mit externen Messgeräten etabliert: Messgerät ans Notebook anstecken, Signale anschließen und messen.
<G-vec00519-002-s174><attach.anschließen><en> By implementing 3.5mm stereo microphone connection the USB audio adapter equips you with the ability to attach an external stereo microphone as needed.
<G-vec00519-002-s174><attach.anschließen><de> Durch Implementieren eines 3,5-mm-Stereo-Mikrofonanschlusses ermöglicht der USB-Audioadapter bei Bedarf das Anschließen eines externen Stereomikrofons.
<G-vec00519-002-s175><attach.anschließen><en> To do this, you must attach a simple metal wire to the bank.
<G-vec00519-002-s175><attach.anschließen><de> Um dies zu tun, müssen Sie einen einfachen Metalldraht an die Bank anschließen.
<G-vec00519-002-s176><attach.anschließen><en> The connection may not operate correctly if you attach the camera to the computer via a USB hub.
<G-vec00519-002-s176><attach.anschließen><de> Die Verbindung funktioniert möglicherweise nicht einwandfrei, wenn Sie die Kamera über einen USB-Hub an den Computer anschließen.
<G-vec00519-002-s177><attach.anschließen><en> Cookies are the main method used but sometimes information is stored and retrieved using other technologies, such as file transfer and Web API’s (Web Application Programming Interfaces) e.g. when you attach a TomTom device to your computer.
<G-vec00519-002-s177><attach.anschließen><de> TomTom verwendet hauptsächlich Cookies, gelegentlich kommen jedoch auch andere Technologien wie Dateiübertragungen oder Web-APIs (Web-Programmierschnittstellen) zum Einsatz, um Daten zu speichern und abzurufen, zum Beispiel dann, wenn Sie ein TomTom-Gerät an Ihren Computer anschließen.
<G-vec00519-002-s178><attach.anschließen><en> Plus, use the high-performance USB 3.0 port** to attach a storage device and quickly transfer large files or share devices across your Wi-Fi network.
<G-vec00519-002-s178><attach.anschließen><de> Sie können ein Speichergerät an den leistungsstarken USB-3.0-Anschluss** anschließen, große Dateien sehr schnell übertragen oder Geräte im ganzen WLAN nutzen.
<G-vec00519-002-s179><attach.anschließen><en> A Swiss study found out that "…the users of Italian descent seem to attach more to certain persons than to institutions.
<G-vec00519-002-s179><attach.anschließen><de> In einer Studie aus der Schweiz wurde herausgefunden, dass "…sich Drogenkonsumenten italienischer Abstammung eher bestimmten Personen als Institutionen anschließen.
<G-vec00519-002-s180><attach.anschließen><en> With its 13.3 inch screen it has a good size for working and thanks to its Dolby Atmos sound which is quite the novelty in notebooks you can also use it to watch TV series and movies without having to attach speakers.
<G-vec00519-002-s180><attach.anschließen><de> Eine erfreuliche Neuheit ist auch der Dolby Atmos Sound, durch den man das Gerät für’s Anschauen von TV-Serien oder Filme nutzen kann, ohne dabei Lautsprecher anschließen zu müssen – und trotzdem hat man tollen, mitreißenden Sound.
<G-vec00519-002-s034><attach.befestigen><en> This classic touring pack shines with a well-organized compartments: gear, drink bottle or rain jacket have easy-access storage in the spacious main compartment; trekking poles are easy to attach to the outside.
<G-vec00519-002-s034><attach.befestigen><de> Generell punktet dieser klassische Tourenrucksack mit einer gut organisierten Taschenaufteilung: In den geräumigen Taschen können Ausrüstung, Trinkflasche oder Regenjacke schnell zugänglich verstaut werden, die Wanderstöcke lassen sich einfach außen am Rucksack befestigen.
<G-vec00519-002-s035><attach.befestigen><en> Upon entering the store, customers pick up a hand-held scanner and attach this to a holder fitted to the shopping trolley handle.
<G-vec00519-002-s035><attach.befestigen><de> Am Markteingang nimmt der Kunde einen Handscanner mit und kann diesen an einer, am Einkaufswagengriff angebrachten, Halterung bequem befestigen.
<G-vec00519-002-s036><attach.befestigen><en> That piece was simply glued to the front of the box from the inside, right behind the port cut-out in order to have a larger gluing surface to attach the pipe to the subwoofer enclosure.
<G-vec00519-002-s036><attach.befestigen><de> Dieses klebte ich mit Holzkleber direkt hinter den Ausschnitt für das Bassreflexrohr in der Vorderseite der Box, um die Klebefläche, mit Hilfe derer ich das Rohr am Gehäuse befestigen würde, zu vergrößern.
<G-vec00519-002-s037><attach.befestigen><en> A convenient method of magnification, these loupes easily attach to the frames of any regular eyeglasses.
<G-vec00519-002-s037><attach.befestigen><de> Eine bequeme Art der Vergrößerung: Diese Lupe läßt sich leicht am Rahmen Ihrer Brille befestigen.
<G-vec00519-002-s038><attach.befestigen><en> This kit allows customers to attach their own equipment to Ergotron carts that include a t-slot channel.
<G-vec00519-002-s038><attach.befestigen><de> Mit diesem Satz kann der Kunde am Ergotron-Wagen mit einem T-Nut-Kanal seine eigene Ausrüstung befestigen.
<G-vec00519-002-s039><attach.befestigen><en> Skymax-102: used the TeleVue 10 mm eyepiece, I got more pixels at the Skymax-127 (Saturn: 330 to 350), but was regrettably not able to attach the camera to this eyepiece.
<G-vec00519-002-s039><attach.befestigen><de> Mit dem TeleVue 10 mm-Okular habe ich am Skymax-127 eine höhere Pixelgröße erreicht (Saturn: 330 bis 350), konnte aber leider die Kamera nicht am Okular befestigen.
<G-vec00519-002-s040><attach.befestigen><en> You can protect yourself from heavy rain with a rain cape or use a special umbrella that you can attach to your body.
<G-vec00519-002-s040><attach.befestigen><de> Sollte der Regen zu stark werden, kann man sich mit einem Regencape vor Nässe schützen oder einen Spezial-Regenschirm verwenden, den man am Körper befestigen kann.
<G-vec00519-002-s041><attach.befestigen><en> Convenient to prepare at home: attach the charms in advance to a jump ring, so you only have to bend open the eye with your round nose pliers so you can very quickly attach the charm to any jewellery.
<G-vec00519-002-s041><attach.befestigen><de> Praktisch um zuhause vorzubereiten: Befestigen Sie die Anhänger schon mal an einen Bindering, dann brauchen Sie nur noch die Öse mit einer Biegezange zu öffnen und am gewünschten Schmuck zu befestigen.
<G-vec00519-002-s373><attach.beifügen><en> Students should also attach a listing of current grades and a valid certificate of enrollment.
<G-vec00519-002-s373><attach.beifügen><de> Studenten sollten zusätzlich den aktuellen Notenspiegel sowie eine gültige Immatrikulationsbescheinigung beifügen.
<G-vec00519-002-s374><attach.beifügen><en> * Learners must attach a copy / scan of their training contract
<G-vec00519-002-s374><attach.beifügen><de> * Lernende müssen eine/n Kopie/Scan des Lehrvertrages beifügen.
<G-vec00519-002-s375><attach.beifügen><en> It may attach an opinion to the requests for amending budgets from the other institutions.
<G-vec00519-002-s375><attach.beifügen><de> Sie kann den von den anderen Organen und Einrichtungen unterbreiteten Berichtigungshaushaltsplänen eine Stellungnahme beifügen.
<G-vec00519-002-s377><attach.beifügen><en> A taxpayer who has sold or exchanged a building from their private assets may complete Form 700 and attach it to their income tax return (Form 100).
<G-vec00519-002-s377><attach.beifügen><de> Der Steuerpflichtige, der eine in Luxemburg gelegene Immobilie aus seinem Privatvermögen verkauft oder getauscht hat, kann den Vordruck 700 ausfüllen und seiner Einkommensteuererklärung (Vordruck 100) beifügen.
<G-vec00519-002-s378><attach.beifügen><en> In addition to the documents referred to in paragraph 1 the budgetary authority may attach any other relevant documents to the budget.
<G-vec00519-002-s378><attach.beifügen><de> (2) Neben den unter Nummer 1 genannten Dokumenten kann die Haushaltsbehörde dem Haushaltsplan auch andere sachdienliche Dokumente beifügen.
<G-vec00519-002-s379><attach.beifügen><en> Please request us by email to obtain an RMA number that you attach to the returning parcel .
<G-vec00519-002-s379><attach.beifügen><de> Bitte fordern Sie per Email eine RMA-Nummer an, die Sie der Rücksendung beifügen.
<G-vec00519-002-s380><attach.beifügen><en> In addition, you can easily attach photos and documents.
<G-vec00519-002-s380><attach.beifügen><de> Außerdem können Sie bequem Fotos und Dokumente beifügen.
<G-vec00519-002-s381><attach.beifügen><en> The Commission shall forward them to the budget authority of the Communities and may attach an opinion along with an alternative estimate.
<G-vec00519-002-s381><attach.beifügen><de> Die Kommission übermittelt diese Unterlagen der Haushaltsbehörde der Gemeinschaften; sie kann ihnen eine Stellungnahme sowie einen abweichenden Voranschlag beifügen.
<G-vec00519-002-s383><attach.beifügen><en> You can include a gift message with your order that we will attach to.
<G-vec00519-002-s383><attach.beifügen><de> Wenn Du möchtest, kannst Du eine Widmung schreiben, die wir der Bestellung beifügen werden.
<G-vec00519-002-s384><attach.beifügen><en> • If someone acts on your behalf, you must attach a copy of your ID, or sign it with your electronic signature.
<G-vec00519-002-s384><attach.beifügen><de> • Wenn Sie von jemandem vertreten werden, müssen Sie eine Kopie Ihres Ausweises beifügen oder mit Ihrer elektronischen Unterschrift unterschreiben.
<G-vec00519-002-s385><attach.beifügen><en> Whenever the application for postal voting is submitted by post, the Luxembourg voter domiciled abroad has to attach a copy of their valid ID card or passport.
<G-vec00519-002-s385><attach.beifügen><de> Wird der Antrag auf Zulassung zur Briefwahl auf dem Postweg gestellt, muss der im Ausland ansässige Wähler eine Kopie seines gültigen Personalausweises/Reisepasses beifügen.
<G-vec00519-002-s386><attach.beifügen><en> The audit trail report includes the following details: user IP address, Browser and Platform which were being used when the registered event occurred, Date and time of the event, name of the User who performed the operation, portal Page where the action has been performed, generic Action Type (for example, download, attach, updated access), specific Action (for example, Projects [Product development and promotion].
<G-vec00519-002-s386><attach.beifügen><de> Der Audit-Trail-Bericht enthält folgende Details: die IP-Adresse des Benutzers, Browser und Plattform, die bei der Entstehung des Ereignisses genutzt wird, Datum und Zeit des Ereignisses, Name des Benutzers, der die Operation durchgeführt hat, die Seite des Portals, wo die Aktion durchgeführt wurde, allgeneiner Typ der Aktion (z.B., herunterladen, beifügen, Aktualisierung des Zugriffs), spezifische Aktion (z.B., Projekte [Produktentwicklung und Förderung].
<G-vec00519-002-s387><attach.beifügen><en> In order to exercise his rights, the user must send a written statement indicating the right he wishes to exercise and attach a document that proves his identity and his postal or e-mail address for the purposes of notification.
<G-vec00519-002-s387><attach.beifügen><de> Um ihre Rechte ausüben zu können, müssen die Nutzer eine schriftliche Erklärung über das Recht, das sie ausüben möchten, abgeben und ein Dokument beifügen, das ihre Identität und ihre Post- oder E-Mail-Adresse für die Benachrichtigung bestätigt.
<G-vec00519-002-s390><attach.beilegen><en> You need to attach a credit card and buy an emoji for your favourite live- streamers; these emojis can be converted into cash.
<G-vec00519-002-s390><attach.beilegen><de> Sie müssen eine Kreditkarte beilegen und ein Emoji für Ihre Lieblings-Live-Streamer kaufen; diese Emojis können in Geld umgewandelt werden.
<G-vec00519-002-s391><attach.beilegen><en> In this case, you have to attach a list of all of your courses (ToR - Transcript of Records) to your application and additional descriptions of relevant courses and course contents.
<G-vec00519-002-s391><attach.beilegen><de> Sie müssen Ihrer Bewerbung eine Kurs- und Bewertungsübersicht (Transcript of Records) beilegen, bei der alle Veranstaltungen des Erststudiums ausgewiesen sind sowie Beschreibungen der relevanten Kurse und Kursinhalte.
<G-vec00519-002-s392><attach.beilegen><en> If your charger at the user terminals were (connectors) installed, please be sure to Attach the counterpart with matching standard port so that the service without having to redo the device can be connected.
<G-vec00519-002-s392><attach.beilegen><de> Falls am Ladegerät benutzerspezifische Anschlüsse (Steckverbinder) angebracht wurden, bitte unbedingt das Gegenstück mit passendem Standardanschluss beilegen, so dass beim Service ohne Nacharbeiten das Gerät angeschlossen werden kann.
<G-vec00519-002-s393><attach.beilegen><en> These two witness and the two contractual parties should attach copies of their identification to the agreements.
<G-vec00519-002-s393><attach.beilegen><de> Diese Zeugen sowie die beiden Vertragsparteien sollten Kopien ihrer jeweiligen Ausweispapiere dem Vertrag beilegen.
<G-vec00519-002-s394><attach.beilegen><en> If you sell physical products via Digistore24, you can attach a delivery note to the shipment so that the customer knows the return address in the event of a return.
<G-vec00519-002-s394><attach.beilegen><de> Wenn Sie über Digistore24 physische Produkte verkaufen, können Sie der Sendung einen Lieferschein beilegen, sodass der Kunde im Falle einer Rücksendung die Rücksendeadresse kennt.
<G-vec00519-002-s395><attach.beilegen><en> By validating this form you generate a page to be printed that we invite you to attach to your sample.
<G-vec00519-002-s395><attach.beilegen><de> Mit der Bestätigung dieses Formulars wird eine druckfähige Seite generiert, die Sie nach dem Ausdrucken bitte Ihrer Probe beilegen.
<G-vec00519-002-s396><attach.beilegen><en> After reception the merchandise value will be fully refunded to your Bank or PayPal account or your credit card within 14 days if you meet the terms as described above. Please attach the required banking details.
<G-vec00519-002-s396><attach.beilegen><de> Wir erstatten dir den Betrag der zurückgesendeten Waren innerhalb von 14 Tagen auf dein Bankkonto, die benötigten Bankdaten bitte beilegen.
<G-vec00519-002-s397><attach.beilegen><en> Free message When ordering, you can choose if you want us to attach a message instead of the invoice.
<G-vec00519-002-s397><attach.beilegen><de> Kostenlose Grußnachricht Beim Bestellen kannst Du auswählen, ob wir statt der Rechnung eine Grußnachricht beilegen sollen.
<G-vec00519-002-s398><attach.beilegen><en> You can either attach your payment to your order form (see accepted payment methods), or wait until you receive your invoice to make your payment.
<G-vec00519-002-s398><attach.beilegen><de> Sie können entweder die Bestätigung der Überweisung Ihrem Bestellformular beilegen oder auf die Rechnung warten und im Anschluss bezahlen (siehe zugelassene Arten der Zahlung).
<G-vec00519-002-s399><attach.beilegen><en> If you are submitting a bug report you may want to attach this information to the bug report.
<G-vec00519-002-s399><attach.beilegen><de> Wenn Sie einen Fehlerbericht einschicken, sollten Sie diese Informationen dem Bericht beilegen.
<G-vec00519-002-s400><attach.beilegen><en> If the property is to be rented out as a weekend home in Puerto de la Cruz, tourists and visitors may attach more importance on other facilities, for example closeness to bars, pool, restaurants, beaches, golf clubs and other sports.
<G-vec00519-002-s400><attach.beilegen><de> Wenn das Eigentum als ein Wochenende nach Hause in Puerto de la Cruz ausvermietet werden soll, können Touristen und Besucher mehr Bedeutung auf anderen Möglichkeiten, zum Beispiel Nähe zu Bars, Lache, Restaurants, Stränden, Golfklubs und anderen Sportarten beilegen.
<G-vec00519-002-s401><attach.beilegen><en> We pack your mix in a gift box and if you wish you can also create a message or attach a greetings card.
<G-vec00519-002-s401><attach.beilegen><de> Wir verpacken deinen Mix in einer Geschenkbox und wenn du willst, kannst du noch einen Grußtext beilegen.
<G-vec00519-002-s402><attach.beimessen><en> According to the high importance we attach to the careful handling of personal information, we have prepared these guidelines for data protection at Mondial.
<G-vec00519-002-s402><attach.beimessen><de> Gemäß der hohen Bedeutung, die wir einem sorgfältigen Umgang mit persönlichen Daten beimessen, haben wir die vorliegenden Richtlinien für den Datenschutz bei Mondial ausgearbeitet.
<G-vec00519-002-s403><attach.beimessen><en> The aim of the surveys was to find out more about the importance that respondents attach to the different fields of action of sustainable corporate management and how they assess the status of Deka Group's sustainability performance in the respective field of action.
<G-vec00519-002-s403><attach.beimessen><de> Ziel der Befragungen war es, mehr darüber zu erfahren, welche Bedeutung die Befragten den unterschiedlichen Handlungsfeldern einer nachhaltigen Unternehmensführung beimessen und wie sie den Stand der Nachhaltigkeitsleistung der Deka-Gruppe im jeweiligen Handlungsfeld bewerten.
<G-vec00519-002-s404><attach.beimessen><en> The diverse requirements of a transport chain and controlling them in the best possible way for our customers requires perfect teamwork, which we attach the highest priority to.
<G-vec00519-002-s404><attach.beimessen><de> Die vielfältigen Anforderungen einer Transportkette zu berücksichtigen und kundenoptimal zu steuern erfordert perfekte Teamarbeit, welcher wir oberste Priorität beimessen.
<G-vec00519-002-s405><attach.beimessen><en> If you are the very person attach great importance to time and emotion, you should come here and never miss this wrist watch.
<G-vec00519-002-s405><attach.beimessen><de> Wenn Sie der wirklichen Person Zeit und Emotion große Bedeutung beimessen, Sie sollten kommen und nie die Chance entgehen.
<G-vec00519-002-s406><attach.beimessen><en> This demonstrates the high level of importance that we attach to a collaboration between companies and universities in making the latest technological advances available to patients and doctors.
<G-vec00519-002-s406><attach.beimessen><de> Dies zeigt die hohe Bedeutung, die wir der Zusammenarbeit zwischen Unternehmen und Universitäten beimessen, um neuste technologische Entwicklungen Patienten und Ärzten zur Verfügung zu stellen.
<G-vec00519-002-s407><attach.beimessen><en> He further added that Thai enterprises should attach importance to the Belt and Road Initiative and view it as an opportunity to access more consumers in Asia and establish connections with foreign businesses.
<G-vec00519-002-s407><attach.beimessen><de> Er addierte weiter, dass thailändische Unternehmen Bedeutung zur Gurt-und Straßen-Initiative beimessen und sie als Gelegenheit ansehen sollten, auf mehr Verbraucher in Asien zuzugreifen und Verbindungen mit Auslandsgeschäften herzustellen.
<G-vec00519-002-s409><attach.beimessen><en> If you have no ashes needed by others, no one will attach any value to you.
<G-vec00519-002-s409><attach.beimessen><de> Einem Menschen, dessen Asche nicht von seinem Nachbarn benötigt wird, wird niemand irgendeinen Wert beimessen.
<G-vec00519-002-s410><attach.beimessen><en> Enables You To Attach A Cowbell To Your Setup
<G-vec00519-002-s410><attach.beimessen><de> Können Sie Ihr Setup eine Kuhglocke beimessen.
<G-vec00519-002-s411><attach.beimessen><en> This Privacy Policy has been created in order that you understand the importance that we attach to this issue and our commitment to ensure that we comply with UK legislation in this area.
<G-vec00519-002-s411><attach.beimessen><de> Diese Datenschutzrichtlinien wurden erstellt, um die Bedeutung, die wir diesem Thema beimessen, zu verdeutlichen ebenso wie unsere Verpflichtung zu gewährleisten, dass wir in diesem Bereich in Übereinstimmung mit der britischen Gesetzgebung handeln.
<G-vec00519-002-s412><attach.beimessen><en> Of course, nitrophoska has some drawbacks, but many gardeners are so in love with this fertilizer that they do not attach much importance to them.
<G-vec00519-002-s412><attach.beimessen><de> Natürlich hat Nitrophoska einige Nachteile, aber viele Gärtner sind so in diesen Dünger verliebt, dass sie ihm nicht viel Bedeutung beimessen.
<G-vec00519-002-s413><attach.beimessen><en> We know that you attach great importance to privacy.
<G-vec00519-002-s413><attach.beimessen><de> Wir wissen, dass Sie dem Thema Datenschutz große Bedeutung beimessen.
<G-vec00519-002-s414><attach.beimessen><en> In this context, marked by the importance that the framers of the Treaty attach to observance of budgetary discipline and by the aim of the rules laid down for applying budgetary discipline, those rules are to be given an interpretation which ensures that they are fully effective.
<G-vec00519-002-s414><attach.beimessen><de> In diesem Zusammenhang, der durch die Bedeutung, die die Verfasser des Vertrages der Wahrung der Haushaltsdisziplin beimessen, und durch die Zielsetzung der zur Umsetzung dieser Disziplin vorgesehenen Vorschriften gekennzeichnet ist, ist den genannten Vorschriften eine Auslegung zu geben, die ihre volle praktische Wirksamkeit sichert.
<G-vec00519-002-s415><attach.beimessen><en> We reaffirm that back then and today we attach the utmost importance to the goal of European unity on the basis of human rights, fundamental freedoms, democracy and the rule of law and that we will continue to do all we can to further the cohesion of a European Union in which borders are overcome and we strengthen what we share.
<G-vec00519-002-s415><attach.beimessen><de> Wir bekräftigen, dass wir damals wie heute dem Ziel der Europäischen Einheit auf der Grundlage der Menschenrechte, Grundfreiheiten, Demokratie und Rechtsstaatlichkeit höchste Bedeutung beimessen und uns für den Zusammenhalt einer Europäischen Union, in der die Grenzen überwunden werden und das Gemeinsame gestärkt wird, weiter mit allen Kräften einsetzen werden.
<G-vec00519-002-s416><attach.beimessen><en> The importance we attach to the law of chastity explains our commitment to the pattern of marriage that originated with Adam and Eve and has continued through the ages as God’s pattern for the procreative relationship between His sons and daughters and for the nurturing of His children.
<G-vec00519-002-s416><attach.beimessen><de> Daraus, dass wir dem Gesetz der Keuschheit eine solche Bedeutung beimessen, erklärt sich auch, dass wir uns für die Form der Ehe einsetzen, die mit Adam und Eva angefangen hat und die zu allen Zeiten das Modell Gottes für diejenige Beziehung zwischen seinen Söhnen und Töchtern war, bei der es um die Fortpflanzung und die Versorgung seiner Kinder geht.
<G-vec00519-002-s417><attach.beimessen><en> The BMZ’s special initiative One World, No Hunger, which was launched in 2015 and in which Benin is a major participant, underlines the importance the two Governments attach to fighting hunger.
<G-vec00519-002-s417><attach.beimessen><de> Die im Jahr 2015 gestartete BMZ-Sonderinitiative "Eine Welt ohne Hunger", an der Benin maßgeblich partizipiert, unterstreicht die Bedeutung, die beide Regierungen der Bekämpfung des Hungers beimessen.
<G-vec00519-002-s418><attach.beimessen><en> It shows not only what importance we attach to this forum but also what importance we attach to German-Russian relations.
<G-vec00519-002-s418><attach.beimessen><de> Dies zeigt, welche Bedeutung wir diesem Forum beimessen, aber auch, welche Bedeutung wir den deutsch-russischen Beziehungen beimessen.
<G-vec00519-002-s420><attach.beimessen><en> This moment to which we dedicate so much effort, to which we attach so much meaning and without which there would be no yesterday and today, lasts only a brief instant.
<G-vec00519-002-s420><attach.beimessen><de> Einen kurzen Augenblick nur währt dieser Moment, dem wir uns mit so viel Mühen widmen, dem wir so viel Bedeutung beimessen und ohne den es kein Gestern und kein Morgen geben würde.
<G-vec00519-002-s448><attach.bringen><en> Simply attach the Limpet through the pre-cut holes in the rear of the awning and fasten to a smooth caravan surface.
<G-vec00519-002-s448><attach.bringen><de> Bringen Sie das Limpet einfach mithilfe der vorgestanzten Löcher an der Rückseite des Vorzelts an und befestigen Sie es an einer glatten Wohnwagen-Oberfläche.
<G-vec00519-002-s449><attach.bringen><en> Attach the pump to the package and it is ready to be used for the next two months(the Vitamin C expires after two months).
<G-vec00519-002-s449><attach.bringen><de> Bringen Sie die Pumpe an die Verpackung an und es ist bereit für die nächsten zwei Monate (das Vitamin C läuft nach zwei Monaten).
<G-vec00519-002-s450><attach.bringen><en> Attach the Xbox 360 Wireless Networking Adaptor to the back of your Xbox 360 console by inserting the plastic tabs on the adaptor into the slots on the back of your console.
<G-vec00519-002-s450><attach.bringen><de> Bringen Sie den Wireless LAN Adapter für Xbox 360 an der Rückseite der Xbox 360 Konsole an, indem Sie die Kunststofflaschen des Adapters in die Schlitze an der Konsolenrückseite einrasten lassen.
<G-vec00519-002-s451><attach.bringen><en> Attach a glass needle onto the microinjector and use your forceps to break the tip of the needle to the desired width.
<G-vec00519-002-s451><attach.bringen><de> Bringen Sie ein Glas Nadel auf die Mikroinjektor und nutzen Sie Ihre Zange an der Spitze der Nadel auf die gewünschte Breite zu brechen.
<G-vec00519-002-s452><attach.bringen><en> Attach front and rear ends of the front deflector on the door frame (if you don’t fit it well you are still able to remove it and attach again at this stage).
<G-vec00519-002-s452><attach.bringen><de> Bringen Sie vorderen und hinteren Enden der vorderen Abweiser am Türrahmen (wenn Sie es nicht gut passen, sind Sie noch zu diesem Zeitpunkt in der Lage, es zu entfernen und wieder anbringen).
<G-vec00519-002-s453><attach.bringen><en> Now take the "top card" (mother), attach it to the canvas, carefully align and draw a thin pencil.
<G-vec00519-002-s453><attach.bringen><de> Nehmen Sie nun das "oberste Karte" (Mutter), bringen Sie ihn auf die Leinwand, sorgfältig ausrichten und einen dünnen Bleistift zeichnen.
<G-vec00519-002-s454><attach.bringen><en> Attach the LM-10, LM-20, LM-30, or kickstand and slide it all the way up so it sits snug against the top of the mount. Product Videos
<G-vec00519-002-s454><attach.bringen><de> Bringen Sie die Modelle LM-10, LM-20, LM-30 oder den Seitenständer an und schieben Sie sie ganz nach oben, damit sie bündig an der Oberseite der Objektivaufnahme anliegen.
<G-vec00519-002-s455><attach.bringen><en> Attach the trailer with your monster truck racing and drive through city roads.
<G-vec00519-002-s455><attach.bringen><de> Bringen Sie den Anhänger mit schweren Lkw und fahren durch die Berge.
<G-vec00519-002-s456><attach.bringen><en> Following is an example for average carbonation in beer: Chill the beer to 40 F. Adjust the regulator to 2 PSI and attach the gas disconnect.
<G-vec00519-002-s456><attach.bringen><de> Das folgende Beispiel zeigt die durchschnittliche Karbonisierung von Bier: Kühlen Sie das Bier auf 40 F. Stellen Sie den Regler auf 2 PSI ein und bringen Sie den Gastrennschalter an.
<G-vec00519-002-s457><attach.bringen><en> Attach the brackets to the wall and place the beautiful board on top.
<G-vec00519-002-s457><attach.bringen><de> Bringen Sie die Halterungen an der Wand an und platzieren Sie das schöne Brett darauf.
<G-vec00519-002-s458><attach.bringen><en> • Attach the battery pack to the camcorder correctly (p. 11).
<G-vec00519-002-s458><attach.bringen><de> Bringen Sie den Akku richtig am Camcorder an (S. 9).
<G-vec00519-002-s459><attach.bringen><en> Attach to the suspension rails and fix them with screws.
<G-vec00519-002-s459><attach.bringen><de> Bringen Sie den Aufhängungsschienen und befestigen Sie sie mit Schrauben.
<G-vec00519-002-s460><attach.bringen><en> Simply attach the “magic box” to the shelf placing the promotional product inside it.
<G-vec00519-002-s460><attach.bringen><de> Bringen Sie den „Wunderkasten“ am Regal an und platzieren das Aktionsprodukt darin.
<G-vec00519-002-s461><attach.bringen><en> Remove the address stick with your details and attach the label featuring the engelbert strauss address.
<G-vec00519-002-s461><attach.bringen><de> Entfernen Sie den Adressaufkleber mit Ihren Empfänger-Daten und bringen Sie das Paket-Etikett mit der engelbert strauss Empfänger-Adresse auf.
<G-vec00519-002-s462><attach.bringen><en> Attach two brackets to the wall, and install them on the cut sheet of plywood.Then followed attach a sheet of drywall with a hole.Another sheet of drywall that has no cutout is attached below.
<G-vec00519-002-s462><attach.bringen><de> Bringen Sie zwei Halterungen an der Wand, und installieren Sie sie auf dem Einzelblatt aus Sperrholz.Dann folgte ein Blatt Trockenbau mit einem Loch befestigen.Ein anderes Blatt Trockenbau, die keine Aussparung hat, ist unten angehängt.
<G-vec00519-002-s463><attach.bringen><en> Attach the smallest sandpaper to the polishing bar, apply grease to it and treat the damaged area.
<G-vec00519-002-s463><attach.bringen><de> Bringen Sie das kleinste Schleifpapier an der Polierleiste an, tragen Sie Fett darauf auf und behandeln Sie die beschädigte Stelle.
<G-vec00519-002-s464><attach.bringen><en> Attach your GoPro to surf boards, kayaks, sups, boats and other shiny surfaces where there is a need to put your GoPro fixed.
<G-vec00519-002-s464><attach.bringen><de> Bringen Sie Ihre GoPro zu Surfbretter, Kajaks, Sups, Boote und andere glänzende Oberflächen, wo es notwendig ist, Ihre GoPro fixiert zu setzen.
<G-vec00519-002-s465><attach.bringen><en> Attach receipt of payment of registration fees.
<G-vec00519-002-s465><attach.bringen><de> Bringen Sie den Eingang der Teilnahmegebühren.
<G-vec00519-002-s466><attach.bringen><en> Attach the transmitter near the IR-receiver on the connected product to ensure remote control operation.
<G-vec00519-002-s466><attach.bringen><de> Bringen Sie den Sender in der Nähe des IR-Empfängers am angeschlossenen Gerät an, um dieses mit der Fernbedienung steuern zu können.
<G-vec00519-002-s498><attach.fixieren><en> GRIFFIN Crimp Tubes attach beads and stones firmly to the wire or beading cord without the need for glue.
<G-vec00519-002-s498><attach.fixieren><de> Quetschröhrchen GRIFFIN Crimps fixieren Perlen und Steine an Drähten und Perlseiden ohne den Einsatz von Klebstoff.
<G-vec00519-002-s499><attach.fixieren><en> Compression straps attach the contents, while hip and chest straps keep it firmly on your back when required. Details:
<G-vec00519-002-s499><attach.fixieren><de> Seitliche Kompressionsriemen fixieren den Inhalt, bei Bedarf halten Brust- und Bauchgurt den Rucksack eng am Rücken.
<G-vec00519-002-s500><attach.fixieren><en> The “smart thing” about the Smart-card is its slim format and the suction cups, which make it possible to attach the power bank to the reverse side of the smartphone during the charging process.
<G-vec00519-002-s500><attach.fixieren><de> Das „Smarte“ an der Smart-card sind ihr schlankes Format und die Saugnäpfe, die es ermöglichen, die Powerbank während des Ladevorgangs auf der Rückseite des Smartphones zu fixieren.
<G-vec00519-002-s501><attach.fixieren><en> 4 tie downs can be added to attach and tide the machine on a trailer (they are not meant to lift the machine).
<G-vec00519-002-s501><attach.fixieren><de> 4 (nicht zum Anheben der Maschine gedachte) Verzurrvorrichtungen können zum Fixieren der Maschine auf einem Hänger angebracht werden.
<G-vec00519-002-s502><attach.fixieren><en> Twelve laser weld seams attach the silencer in the slide ring seal right down to the micrometer.
<G-vec00519-002-s502><attach.fixieren><de> Zwölf Laserschweiß- nähte fixieren den Dämpfer in der Gleitringdichtung mikrometergenau.
<G-vec00519-002-s503><attach.fixieren><en> Your customers can attach the individual packaging modules to a customizable dimpled mat with a single click – and thus design their own customized drawer insert.
<G-vec00519-002-s503><attach.fixieren><de> Ihre Kunden fixieren die einzelnen Verpackungsmodule mit nur einem Klick auf einer individuell zuschneidbaren Noppenmatte – und stellen sich so ihren individuellen Schubladeneinsatz zusammen.
<G-vec00519-002-s504><attach.fixieren><en> The ergonomically cut model offers outstanding little details, such as pockets on both sides, the full-length zipper with chin protector, and the practical thumb holes to attach the hoodie to your hands.
<G-vec00519-002-s504><attach.fixieren><de> Das ergonomisch geschnittene Modell besticht aber auch durch seine kleinen Details, wie beidseitige Taschen, den durchgehenden Reißverschluss mit Kinnschutz und die praktischen Daumenlöcher, um den Hoodie an den Händen zu fixieren.
<G-vec00519-002-s505><attach.fixieren><en> Once centered, lightly rub the center of the material to attach it to the adhesive.
<G-vec00519-002-s505><attach.fixieren><de> Wenn das Dokument mittig ausgerichtet ist, reiben Sie leicht über die Mitte, um es am Klebestreifen zu fixieren.
<G-vec00519-002-s506><attach.fixieren><en> For transporting the umbrella, you can attach the umbrella in its breathable bag to the side of your backpack.
<G-vec00519-002-s506><attach.fixieren><de> Zum Transport können Sie den hochwertigen Schirm in einer atmungsaktiven Hülle am Rucksack seitlich fixieren.
<G-vec00519-002-s507><attach.fügen><en> In addition, we attach the comparative values of all wholesale and retail companies saved in our database to each evaluation, depending on the trade in focus.
<G-vec00519-002-s507><attach.fügen><de> Darüber hinaus fügen wir jeder Auswertung, je nach Handelsschwerpunkt, die Vergleichswerte aller in unserer Datenbank gespeicherten Unternehmen des Groß- oder Einzelhandels bei.
<G-vec00519-002-s508><attach.fügen><en> We attach a link to CyberSource’s privacy policy which explains how your personal information will be used.
<G-vec00519-002-s508><attach.fügen><de> Wir fügen einen Link zu den Datenschutzrichtlinien von CyberSource Corporation bei; dort wird erläutert, wie Ihre personenbezogenen Daten genutzt werden.
<G-vec00519-002-s509><attach.fügen><en> If you have a court order or other relevant legal documentation, please attach a copy when submitting your request (see “File attachments” section).
<G-vec00519-002-s509><attach.fügen><de> Wenn Sie eine gerichtliche Anordnung oder eine andere relevante rechtliche Dokumentation haben, fügen Sie bitte eine Kopie als Anlage zum Antrag bei (siehe Abschnitt für Datei-Anlagen).
<G-vec00519-002-s510><attach.fügen><en> Please send your application to jobsnoSpam@noSpamyada.eu and attach your cover letter, résumé, and references as PDF files.
<G-vec00519-002-s510><attach.fügen><de> Bitte schicken Sie Ihre Bewerbung an jobsnoSpam@noSpamyada.eu und fügen Sie Ihr Anschreiben, Ihren Lebenslauf und Zeugnisse als PDF-Datei an.
<G-vec00519-002-s511><attach.fügen><en> Fill in the form below and attach two recent photographs.
<G-vec00519-002-s511><attach.fügen><de> Füllen Sie das nachstehende Formular aus und fügen zwei Fotos jüngeren Datums bei.
<G-vec00519-002-s512><attach.fügen><en> If you want more information about the characteristics of it, we attach the following link.
<G-vec00519-002-s512><attach.fügen><de> Wenn Sie mehr Informationen über die Eigenschaften davon wünschen, fügen wir den folgenden Link bei.
<G-vec00519-002-s513><attach.fügen><en> When you purchase our equipment, we attach detailed instructions for use of this tool.
<G-vec00519-002-s513><attach.fügen><de> Wenn Sie unsere Ausrüstung kaufen, fügen wir detaillierte Anweisungen für die Verwendung dieses Tools.
<G-vec00519-002-s514><attach.fügen><en> We will ask you for the address where you would like the order to be delivered, and we will not attach any receipts for purchases made in this manner.
<G-vec00519-002-s514><attach.fügen><de> Wir brauchen Ihre Lieferadresse, an welche die Bestellung gesendet werden soll und fügen der Bestellung dann keine Rechnung bei.
<G-vec00519-002-s515><attach.fügen><en> Please attach your company profile to your application along with information indicating which products you would like to supply to ept.
<G-vec00519-002-s515><attach.fügen><de> Fügen Sie Ihrer Bewerbung bitte ein Unternehmensprofil bei und für welche Produkte Sie sich bei ept als Lieferant vorstellen möchten.
<G-vec00519-002-s516><attach.fügen><en> To ensure a fast and adequate solution, please attach the text of the received error message to your inquiry. Start own inquiry.
<G-vec00519-002-s516><attach.fügen><de> Für eine schnelle und korrekte Lösung Ihres Anliegens fügen Sie Ihrer Anfrage bitte den Text der Fehlermeldung, die Sie erhalten bei.
<G-vec00519-002-s517><attach.fügen><en> Follow If you see a error during gameplay, please attach a screenshot or video.
<G-vec00519-002-s517><attach.fügen><de> Wenn Sie während des Spiels einen Fehler bemerken, fügen Sie bitte einen Screenshot oder ein Video bei.
<G-vec00519-002-s518><attach.fügen><en> Complete the withdrawal form in Appendix 1 to these Terms and Conditions (or draft another express declaration), attach it to the package in which you are returning the products to us (in correspondence to the contract that you wish to withdraw from) and send the package to us in accordance with the return policies under section 2.15.
<G-vec00519-002-s518><attach.fügen><de> (a) Füllen Sie das Widerrufsformular in Anhang 1 zu diesen Allgemeinen Geschäftsbedingungen (oder eine andere eindeutige Erklärung) aus, fügen es dem Paket bei, mit dem Sie die Produkte (die den Vertrag betreffen, den Sie widerrufen möchten) an uns zurückschicken, und schicken das Paket gemäß den Rücksenderichtlinien in Abschnitt 2.15 an uns.
<G-vec00519-002-s519><attach.fügen><en> If paying by bank transfer, please attach your registration form to the bank transfer form.
<G-vec00519-002-s519><attach.fügen><de> Wenn Sie Ihre Zahlung per Banküberweisung vornehmen, fügen Sie dem Überweisungsformular bitte das Anmeldeformular bei.
<G-vec00519-002-s520><attach.fügen><en> Please make sure to attach a price list to your catalog or at least give an overview of your business, your terms, price examples.
<G-vec00519-002-s520><attach.fügen><de> Bitte stellen Sie uns eine Preisliste bereit und fügen diese dem Katalog Ihrer Produkte bei oder geben Sie uns zumindest bitte einen Überblick über Ihr Unternehmen, Ihre Bedingungen sowie einige Preisbeispiele.
<G-vec00519-002-s540><attach.hinzufügen><en> Attach files I have read the privacy policy and agree.
<G-vec00519-002-s540><attach.hinzufügen><de> Dateien hinzufügen Ich habe die Dateschutzbestimmugen gelesen und stimme ihnen zu.
<G-vec00519-002-s541><attach.hinzufügen><en> You can preview the diagnostic information and then save it to a file that you can attach in your support request.
<G-vec00519-002-s541><attach.hinzufügen><de> Sie erhalten eine Vorschau der Diagnoseinformationen und können diese auf eine Datei speichern, die Sie der Anfrage hinzufügen können.
<G-vec00519-002-s542><attach.hinzufügen><en> For example, I might wish to attach a living room to a listing.
<G-vec00519-002-s542><attach.hinzufügen><de> Ich könnte der Auflistung zum Beispiel ein Wohnzimmer hinzufügen wollen.
<G-vec00519-002-s543><attach.hinzufügen><en> If you are applying for any other country, you can usually attach it.
<G-vec00519-002-s543><attach.hinzufügen><de> Wenn du dich für ein anderes Land bewirbst, kannst du es normalerweise hinzufügen.
<G-vec00519-002-s544><attach.hinzufügen><en> It is best if you know the metrics and then search for “attach measurement value” in the selection box.
<G-vec00519-002-s544><attach.hinzufügen><de> Am Besten ist, wenn man die Metrik kennt und im Auswahlfeld der Funktion „Messwert hinzufügen“ danach sucht.
<G-vec00519-002-s545><attach.hinzufügen><en> In case of problems during the import of files, please let us know via our support forums (please attach file). This allows us to improve the import functionality of Track My Trip accordingly.
<G-vec00519-002-s545><attach.hinzufügen><de> Sollte es beim Import von Dateien aus anderen Quellen zu Problemen kommen, teilen Sie uns dieses bitte über unsere Foren mit (bitte Datei hinzufügen), damit die Import-Funktionalität von Track My Trip entsprechend erweitert werden kann.
<G-vec00519-002-s546><attach.hinzufügen><en> Attach photo: (max.
<G-vec00519-002-s546><attach.hinzufügen><de> Foto hinzufügen: (max.
<G-vec00519-002-s547><attach.hinzufügen><en> Now they can attach that fundraiser to a live video.
<G-vec00519-002-s547><attach.hinzufügen><de> Diese Spendenaktion können Sie jetzt einem Live-Video hinzufügen.
<G-vec00519-002-s548><attach.hinzufügen><en> In order to make the Warsaw City Card your personal WKM you only need to fill an application form in, attach a photo and submit them in one of the ZTM Passenger Service Centres.
<G-vec00519-002-s548><attach.hinzufügen><de> Damit die Warschauer Citycard zu Ihrer persönlichen WKM wird, muss man nur den Antrag ausfüllen, das Foto hinzufügen und in einer der Fahrgast-Servicestellen von ZTM einreichen.
<G-vec00519-002-s549><attach.hinzufügen><en> With the project management functionality in SOLIDWORKS Manage, organizations can plan each stage of their projects, assign resources and tasks, and attach required documentation to the project.
<G-vec00519-002-s549><attach.hinzufügen><de> Mit der Projektmanagement-Funktion in SOLIDWORKS Manage, können Unternehmen jeden Abschnitt ihrer Projekte planen, Ressourcen und Aufgaben zuordnen und zum Projekt die erforderliche Dokumentation hinzufügen.
<G-vec00519-002-s575><attach.hängen><en> Create a request to Kaspersky Lab Technical Support via My Kaspersky. Attach the KL_syscure.zip file to your request.
<G-vec00519-002-s575><attach.hängen><de> Senden Sie eine Anfrage an den Support via My Kaspersky und hängen Sie an Ihre Anfrage das Archiv KL_syscure.zip an.
<G-vec00519-002-s576><attach.hängen><en> When the restore task completes, detach the restored disks from the new VM and attach them to the required VM using the information in "Detaching and Reattaching Storage" of the vSphere Data Protection Administration Guide.
<G-vec00519-002-s576><attach.hängen><de> Wenn die Wiederherstellungsaufgabe abgeschlossen ist, trennen Sie die wiederhergestellten Festplatten von der neuen VM und hängen Sie sie unter Verwendung der Informationen aus dem Abschnitt „Trennen und erneutes Anbinden von Speicher“ im Administratorhandbuch für vSphere Data Protection an die erforderliche VM an.
<G-vec00519-002-s577><attach.hängen><en> If you are not sure which size to choose, please contact our customer service by email and attach the size and photo of your sofa.
<G-vec00519-002-s577><attach.hängen><de> Hinweis: Wenn Sie nicht sicher sind, welche Größe Sie wählen sollen, wenden Sie sich bitte per E-Mail an unseren Kundenservice und hängen Sie die Größe und das Foto Ihres Sofas an.
<G-vec00519-002-s578><attach.hängen><en> Perfect to protect your sofa from pets Schwarz) If you are not sure which size to choose, please contact our customer service by email and attach the size and photo of your sofa.
<G-vec00519-002-s578><attach.hängen><de> (Schutz vor Verschmutzungen Ihres Sofa)Hinweis: Wenn Sie nicht sicher sind, welche Größe Sie wählen sollen, wenden Sie sich bitte per E-Mail an unseren Kundenservice und hängen Sie die Größe und das Foto Ihres Sofas an.
<G-vec00519-002-s579><attach.hängen><en> Tie the strap around your chest, just below the chest muscles, and attach the hook to the other end of the strap.
<G-vec00519-002-s579><attach.hängen><de> Legen Sie den Gurt unterhalb der Brustmuskulatur um die Brust und hängen Sie den Haken am anderen Ende des Gurtes ein.
<G-vec00519-002-s580><attach.hängen><en> Connect you One Drive and Nozbe accounts and attach your One Drive files to tasks and projects or access project-relevant files directly from Nozbe.
<G-vec00519-002-s580><attach.hängen><de> Verbinden Sie One Drive mit dem Nozbe Konto und hängen Sie Ihre One Drive-Dateien an Aufgaben und Projekte oder greifen Sie direkt von Nozbe aus auf die projektrelevanten Dateien.
<G-vec00519-002-s582><attach.hängen><en> If he refuses to sign the document, draw up a corresponding act, and then attach it to the order or below his signature, put a note on it on the document.
<G-vec00519-002-s582><attach.hängen><de> Wenn er sich weigert, das Dokument zu unterzeichnen, erstellen Sie eine entsprechende Handlung, und hängen Sie es dann an die Bestellung oder unter seine Unterschrift an, und notieren Sie sie auf dem Dokument.
<G-vec00519-002-s583><attach.hängen><en> Attach sticky notes to docs and websites.
<G-vec00519-002-s583><attach.hängen><de> Hängen Sie Haftnotizen an Dokumente und Websites.
<G-vec00519-002-s584><attach.hängen><en> Simply fill in the form below and attach your comprehensive application documents.
<G-vec00519-002-s584><attach.hängen><de> F√ľllen Sie dazu das unten stehende Formular aus und hängen Sie Ihre aussagekräftigen Bewerbungsunterlagen an.
<G-vec00519-002-s585><attach.hängen><en> Please enter your e-mail address and a brief description on this page and attach your file(s).
<G-vec00519-002-s585><attach.hängen><de> Bitte geben Sie auf dieser Seite Ihre E-Mail Adresse und eine kurze Beschreibung ein und hängen Sie Ihre Datei(en) an.
<G-vec00519-002-s586><attach.hängen><en> Then attach the chain and large stone.
<G-vec00519-002-s586><attach.hängen><de> Dann hängen Sie die Kette und große Klunker.
<G-vec00519-002-s587><attach.hängen><en> Attach trace files and the Updater.ini configuration file to your request.
<G-vec00519-002-s587><attach.hängen><de> Hängen Sie die Konfigurationsdatei Updater.ini und Protokolldateien an Ihre Anfrage an.
<G-vec00519-002-s588><attach.knüpfen><en> If, acting on the results of this investigation, Babboe has sound reason not to conclude the agreement, Babboe is lawfully entitled to refuse an order or request, or to attach special terms to the implementation.
<G-vec00519-002-s588><attach.knüpfen><de> Wenn Babboe aufgrund dieser Nachforschungen gute Gründe hat, den Vertrag nicht abzuschließen, ist Babboe berechtigt, eine Bestellung oder Anfrage abzuweisen oder die Ausführung an besondere Bedingungen zu knüpfen.
<G-vec00519-002-s589><attach.knüpfen><en> If the entrepreneur on the basis of this investigation has good reasons not to enter into the agreement, he is entitled to refuse an order or request motivated or to attach special conditions to the execution.
<G-vec00519-002-s589><attach.knüpfen><de> Falls der Unternehmer aufgrund dieser Nachforschung gute Gründe hat die Vereinbarung nicht einzugehen, ist er berechtigt eine Bestellung oder Anfrage nicht anzunehmen oder die Durchführung an besondere Bedingungen zu knüpfen.
<G-vec00519-002-s590><attach.knüpfen><en> If Apollyon is justified, based on this investigation, not to enter into the contract, he is entitled to refuse an order or to attach special conditions.
<G-vec00519-002-s590><attach.knüpfen><de> Wenn der Unternehmer auf Grund dieser Untersuchung vernünftige Gründe hat, den Vertrag nicht einzugehen, ist er berechtigt, die Ausführung einer Bestellung oder Anfrage zu verweigern oder diese an besondere Bedingungen zu knüpfen.
<G-vec00519-002-s591><attach.knüpfen><en> If the entrepreneur on the basis of this investigation has good reasons not to enter into the agreement, he is entitled to refuse an order or request motivated or to attach special conditions to the execution.
<G-vec00519-002-s591><attach.knüpfen><de> Hat der Unternehmer aufgrund dieser Untersuchung gute Gründe, den Vertrag nicht zu schließen, so ist er berechtigt, eine Bestellung oder Anfrage abzulehnen, oder an die Ausführung besondere Bedingungen zu knüpfen.
<G-vec00519-002-s593><attach.knüpfen><en> The superstition which seafaring men attach to this relic, as to its being an omen of “good luck” or as a preservative against drowning, is based on the fact that as it was a protection to the embryo from adverse elements in the pre-natal world, so it may now in the physical world protect from the dangers of the water which corresponds with the astral light and the elements which, though they are called physical, are none the less occult and originates in the astral world.
<G-vec00519-002-s593><attach.knüpfen><de> Der Aberglaube, den die Seefahrer an dieses Relikt knüpfen, weil es ein Omen des „Glücks“ oder ein Konservierungsmittel gegen das Ertrinken ist, beruht auf der Tatsache, dass es dem Embryo Schutz vor schädlichen Elementen in der Vorgeburt bot Welt, so kann es jetzt in der physischen Welt vor den Gefahren des Wassers schützen, das dem astralen Licht und den Elementen entspricht, die, obwohl sie physisch genannt werden, nichtsdestoweniger okkult sind und aus der astralen Welt stammen.
<G-vec00519-002-s594><attach.knüpfen><en> Birthday, anniversary or birth of a child: There are many opportunities more closely to attach the relationship with a customer.
<G-vec00519-002-s594><attach.knüpfen><de> Geburtstag, Jubiläum oder Geburt eines Kindes: Es gibt viele Gelegenheiten, die Beziehung zu einem Kunden enger zu knüpfen.
<G-vec00519-002-s596><attach.knüpfen><en> Our people in Palestine should not need to wait for any aid from countries that attach humiliating conditions to every dollar or euro they pay despite their historical and moral responsibility for our plight.
<G-vec00519-002-s596><attach.knüpfen><de> Unser Volk in Palästina sollte nicht auf Hilfe von Ländern warten müssen, die demütigende Bedingungen an jeden Dollar oder Euro knüpfen, den sie trotz ihrer historischen und moralischen Verantwortung für unsern Kampf zahlen.
<G-vec00519-002-s597><attach.knüpfen><en> But these four conditions are only the chief points which relate to the subject; a number of local and special circumstances attach themselves to these, and often attain to an influence more decisive and important than that of the principal ones themselves.
<G-vec00519-002-s597><attach.knüpfen><de> Aber diese vier Bedingungen sind nur die Hauptverhältnisse, welche den Gegenstand umfassen; es knüpfen sich daran eine Menge örtlicher und individueller Umstände, die oft sehr viel wichtiger und durchgreifender werden als die Hauptverhältnisse selbst.
<G-vec00519-002-s634><attach.legen><en> That means in concrete terms: We accomplish all processes starting with the slaughter, butchering and finishing of the products through to the packaging and finally the delivery of the orders – and attach great importance to flexibility and individuality.
<G-vec00519-002-s634><attach.legen><de> Das heißt konkret: Wir übernehmen alle Vorgänge beginnend bei der Schlachtung, Zerlegung und Veredelung der Produkte über die Verpackung bis hin zur Lieferung der Bestellungen – und legen dabei großen Wert auf Flexibilität und Individualität.
<G-vec00519-002-s635><attach.legen><en> As a pioneer of directly excited screening technology, we understand this problem and attach great importance to screening machines with automatic mesh cleaning mechanisms.
<G-vec00519-002-s635><attach.legen><de> Als Pionier der direkt erregten Siebtechnologie verstehen wir dieses Problem und legen dabei Wert auf Siebmaschinen mit automatischer Siebgewebereinigung.
<G-vec00519-002-s636><attach.legen><en> We attach great importance to a uniform look and feel to the product images.
<G-vec00519-002-s636><attach.legen><de> Wir legen dabei viel Wert auf ein einheitliches Look & Feel der Produktbilder.
<G-vec00519-002-s637><attach.legen><en> Our consultants, architects and project managers attach great importance to a precise analysis of your specific customer environment in order to develop tailor-made concepts and solutions for the smooth running of your infrastructure processes.
<G-vec00519-002-s637><attach.legen><de> Unsere Berater, Architekten und Projekt Manager legen dabei großen Wert auf eine genaue Analyse Ihrer spezifischen Kundenumgebung, um im Anschluss maßgeschneiderte Konzepte und Lösungen für den reibungslosen Ablauf Ihrer Infrastruktur Prozesse zu erarbeiten.
<G-vec00519-002-s638><attach.legen><en> We attach great importance while on a high quality of the raw materials, which we take from selected suppliers from the region if possible in organic quality.
<G-vec00519-002-s638><attach.legen><de> Wir legen dabei sehr viel Wert auf eine hohe Qualität der Rohstoffe, welche wir von ausgesuchten Lieferanten aus der Region nach Möglichkeit in Bioqualität beziehen.
<G-vec00519-002-s639><attach.legen><en> In doing so we attach great importance on up-to-dateness.
<G-vec00519-002-s639><attach.legen><de> Ganz besonderen Wert legen wir dabei auf Aktualität.
<G-vec00519-002-s640><attach.legen><en> We not only attach a great deal of value to standard packaging that is visually faultless, but we are happy to help you in developing extraordinary and attractive solutions, too.
<G-vec00519-002-s640><attach.legen><de> Wir legen dabei nicht nur großen Wert auf eine optisch einwandfreie Standardverpackung, sondern helfen Ihnen auch gern bei der Entwicklung von außergewöhnlichen und ansprechenden Lösungen.
<G-vec00519-002-s641><attach.legen><en> We attach great importance to easy-to-use, manageable programs.
<G-vec00519-002-s641><attach.legen><de> Wir legen dabei großen Wert auf einfach nutzbare, überschaubare Programme.
<G-vec00519-002-s658><attach.schließen><en> Simply attach a standard LPG reusable cylinder with propane-butane or pure propane to the unit and switch your ROTHENBERGER INDUSTRIAL forced air heater on.
<G-vec00519-002-s658><attach.schließen><de> Schließen Sie einfach eine handelsübliche LPG-Mehrwegflasche mit Propan-Butan- oder reinem Propangas an das Gerät an und schalten Sie die ROTHENBERGER INDUSTRIAL Heizkanone ein.
<G-vec00519-002-s659><attach.schließen><en> Simply attach your computer to the TVS-1282T3 with a Thunderbolt™ 3 cable, and you will find the TVS-1282T3 in Finder/File Explorer with accessible shared folders available for you.
<G-vec00519-002-s659><attach.schließen><de> Schließen Sie einfach Ihren Computer über ein Thunderbolt™-3-Kabel an das TVS-1282T3 an und Sie erhalten in Finder/Explorer Zugriff auf die Freigabeordner des TVS-1282T3.
<G-vec00519-002-s660><attach.schließen><en> Just attach your DSLR or CCD camera using the optional TSFA2 or M48 screwed adapter (TSFOC-M48) and you have optimal photographical opportunities.
<G-vec00519-002-s660><attach.schließen><de> Schließen Sie einfach Ihre DSLR oder CCD Kamera über den 2" Fokaladapter (TSFA2) oder über den M48 Schraubadapter (TSFOC-M48) an, stellen Sie scharf und schon haben sie die optimale fotografische Leistung zur Verfügung.
<G-vec00519-002-s661><attach.schließen><en> Attach a pair of Joy-Con controllers and verify that they appear on the Controllers screen.
<G-vec00519-002-s661><attach.schließen><de> Schließen Sie ein Paar Joy-Con-Controller an die Konsole an und stecken Sie das Netzteil ein.
<G-vec00519-002-s662><attach.schließen><en> Pull it out, attach the included MP3 Radio Player with the music of your favorite cat or dog and pack the player with its cable in the bag.
<G-vec00519-002-s662><attach.schließen><de> Ziehen Sie es heraus, schließen Sie den mitgelieferten MP3-Radio Player mit der Lieblingsmusik Ihrer Katze oder Hund an und verstauen den Player samt Kabel in der Tasche.
<G-vec00519-002-s663><attach.schließen><en> If you need to use a different resolution than those available on the built-in display, attach an external display via HDMI, Thunderbolt, or DisplayPort.
<G-vec00519-002-s663><attach.schließen><de> Wenn Sie eine andere Auflösung benötigen als auf dem integrierten Display verfügbar ist, schließen Sie einen externen Monitor über den HDMI-, Thunderbolt- oder DisplayPort-Anschluss an.
<G-vec00519-002-s664><attach.schließen><en> Attach the drive to a heat sink with large cooling ribs to create a fully passively cooled drive, or mount the drive on a plate which is cooled by liquid to create a liquid-cooled solution.
<G-vec00519-002-s664><attach.schließen><de> Schließen Sie den Frequenzumrichter an einen Kühlkörper mit großen Kühlrippen an, um eine vollständige Passivkühlung des Frequenzumrichters zu erzielen, oder montieren Sie den Frequenzumrichter auf einer flüssigkeitsgekühlten Platte, um eine Flüssigkeitskühlung zu erzielen.
<G-vec00519-002-s665><attach.schließen><en> Attach any number Display and/or Repeater units to extend the distance over another 100 meters (330 feet) with each component without compromising image quality. Features Specifications
<G-vec00519-002-s665><attach.schließen><de> Schließen Sie eine beliebige Anzahl von Anzeigegeräten und/oder Repeatern an, um die Distanz für jede weitere Komponente um weitere über 100 Meter (330 Fuß) auszuweiten, ohne dass die Bildqualität beeinträchtigt wird.
<G-vec00519-002-s666><attach.schließen><en> Attach the included CORSAIR iCUE cable to a USB header on your motherboard and download the free CORSAIR iCUE software to unlock even more power.
<G-vec00519-002-s666><attach.schließen><de> Schließen Sie das mitgelieferte CORSAIR iCUE-Kabel an einen USB-Header des Motherboards an und laden Sie die kostenlose CORSAIR iCUE-Software herunter, um den Kühler noch leistungsstärker zu machen.
<G-vec00519-002-s667><attach.schließen><en> Attach your peripherals to Surface Dock and then attach the magnetic Surface Connect cable to your device.
<G-vec00519-002-s667><attach.schließen><de> Schließen Sie Ihre Peripheriegeräte an das Surface Dock an und stecken Sie dann das magnetische Surface Connect-Kabel in Ihr Gerät ein.
<G-vec00519-002-s668><attach.schließen><en> Attach three Mac® workstations to the TVS-1282T3 via Thunderbolt™ 3 ports for online video editing, while the remaining Thunderbolt™ 3 port is used for storage expansion by connecting up to six NAS expansion enclosures (TX-500P / TX-800P).
<G-vec00519-002-s668><attach.schließen><de> Schließen Sie über die Thunderbolt™-3-Ports zur Online-Videobearbeitung drei Mac®-Workstations an das TVS-1282T3 an, während der verbleibende Thunderbolt™-3-Port der Speichererweiterung durch Anschluss von bis zu sechs NAS-Erweiterungsgehäusen (TX-500P / TX-800P) dient.
<G-vec00519-002-s669><attach.schließen><en> If you have the original lid, attach it to the Intel NUC before returning it.
<G-vec00519-002-s669><attach.schließen><de> Falls Sie die Original Abdeckung haben, schließen Sie Sie an das Intel NUC an, bevor Sie Sie zurücksenden.
<G-vec00519-002-s670><attach.schließen><en> Attach the large, rectangular connector to any USB port on your computer.
<G-vec00519-002-s670><attach.schließen><de> Schließen Sie den großen rechteckigen Stecker an einem beliebigen Anschluss Ihres Computers an.
<G-vec00519-002-s709><attach.verbinden><en> Just attach them to the board’s connectors.
<G-vec00519-002-s709><attach.verbinden><de> Verbinden Sie sie einfach mit den Anschlüssen der Platine.
<G-vec00519-002-s710><attach.verbinden><en> Attach LTC Client EA to all MT4 client accounts you want to copy the trades to.
<G-vec00519-002-s710><attach.verbinden><de> Verbinden Sie LTC Client EA mit allen MT4-Kundenkonten, auf die Sie die Trades kopieren möchten.
<G-vec00519-002-s711><attach.verbinden><en> Attach the meter cable to the connector coming from the front frame tube.
<G-vec00519-002-s711><attach.verbinden><de> Verbinden Sie die aus dem Rahmen und der Elektronikanzeige kommenden Leitungen miteinander.
<G-vec00519-002-s712><attach.verbinden><en> After successful TrueFit installation attach Noahlink Wireless to any USB port on the PC using the supplied US cable.
<G-vec00519-002-s712><attach.verbinden><de> Nach erfolgreicher Installation der TrueFit verbinden Sie Noahlink Wireless mithilfe des beigelegten USB-Kabels mit einem beliebigen USB-Anschluss des Computers.
<G-vec00519-002-s713><attach.verbinden><en> Attach optional Steering Wheels to make this Wheel Base compatible to Xbox One®.
<G-vec00519-002-s713><attach.verbinden><de> Verbinden Sie optional erhältliche Lenkräder, um diese Wheel Base mit der Xbox One® kompatibel zu machen.
<G-vec00519-002-s714><attach.verbinden><en> They attach importance to combining the past with the present.
<G-vec00519-002-s714><attach.verbinden><de> Dabei verbinden sie die Vergangenheit mit der Gegenwart.
<G-vec00519-002-s715><attach.verbinden><en> Attach a PC VGA port to a Customer Support
<G-vec00519-002-s715><attach.verbinden><de> Verbinden Sie einen PC-VGA-Port mit einer Switchbox.
<G-vec00519-002-s716><attach.verbinden><en> If you have a network-enabled FARO dongle or portlock, attach it to the server.
<G-vec00519-002-s716><attach.verbinden><de> Wenn Sie einen netzwerkaktivierten FARO-Dongle oder Port Lock haben, verbinden Sie es mit dem Server.
<G-vec00519-002-s717><attach.verbinden><en> Attach a PC VGA port to a switchbox 5,99 € exc VAT
<G-vec00519-002-s717><attach.verbinden><de> Verbinden Sie einen PC-VGA-Port mit einer zurzeit bestmöglichen Verbindungsqualität.
<G-vec00519-002-s719><attach.verbinden><en> Attach the GPS to your computer with the cable.
<G-vec00519-002-s719><attach.verbinden><de> Verbinden Sie das GPS-Gerät mit dem Computer.
<G-vec00519-002-s720><attach.verbinden><en> Attach the other end of the strap to the other eyelet in the same way.
<G-vec00519-002-s720><attach.verbinden><de> Verbinden Sie das andere Ende des Trageriemens auf gleiche Weise mit der anderen Ose.
<G-vec00519-002-s721><attach.verknüpfen><en> This tool will search your database for pieces of information which are not connected to anything else, and then allow you to edit and attach the information or remove them.
<G-vec00519-002-s721><attach.verknüpfen><de> Dieses Werkzeug durchsucht deine Datenbank nach nicht verwendeten Informationen und ermöglicht dir diese anschließend zu bearbeiten, zu verknüpfen oder zu entfernen.
<G-vec00519-002-s722><attach.verknüpfen><en> Jump XL can attach further conditions to a reservation.
<G-vec00519-002-s722><attach.verknüpfen><de> Jump XL Braunschweig kann mit einer Reservierung nähere Bedingungen verknüpfen.
<G-vec00519-002-s723><attach.verknüpfen><en> Your name, village, country, horoscope, forecasts, many such things get attached to you or others attach them to you.
<G-vec00519-002-s723><attach.verknüpfen><de> Euer Name, Ort, Land, Horoskop, die Voraussagen für euch und vieles mehr verknüpfen sich mit eurer Persönlichkeit oder werden euch von anderen zugewiesen.
<G-vec00519-002-s724><attach.verknüpfen><en> They have learned how to attach the names of famous scientists to research that those scientists have not even looked at. This is a common occurrence.
<G-vec00519-002-s724><attach.verknüpfen><de> Sie haben gelernt, die Namen berühmter Wissenschaftler mit der Forschung zu verknüpfen, Wissenschaftler allerdings, die ihre Nase unter Umständen nicht ein einzige Mal in die betreffende Forschungsarbeit hineingesteckt haben.
<G-vec00519-002-s725><attach.verknüpfen><en> Select the file you want to attach to this product.
<G-vec00519-002-s725><attach.verknüpfen><de> Wählen Sie die Datei aus, die Sie mit diesem Produkt verknüpfen möchten.
<G-vec00519-002-s726><attach.verknüpfen><en> If the operator under this investigation was justified not to enter into the agreement, he is entitled to refuse an order or request or to attach special conditions to the implementation. 5.
<G-vec00519-002-s726><attach.verknüpfen><de> Wenn der Online-Shop aufgrund dieser Erkenntnisse gute Gründe hat, den Vertrag nicht abzuschließen, ist er berechtigt, eine Bestellung oder Anfrage zu verweigern oder an die Ausführung besondere Bedingungen zu verknüpfen.
<G-vec00519-002-s727><attach.verknüpfen><en> If, acting on the results of this investigation, the Entrepreneur has sound reasons for not concluding the contract, he is lawfully entitled to refuse an order or request supported by reasons, or to attach special terms to the implementation.
<G-vec00519-002-s727><attach.verknüpfen><de> Falls der Unternehmer aufgrund dieser Untersuchung gute Gründe hat, den Vertrag nicht einzugehen, ist er berechtig mit Begründung eine Bestellung oder Anfrage abzulehnen oder mit der Ausführung besondere Bedingungen zu verknüpfen.
<G-vec00519-002-s729><attach.verknüpfen><en> Formula Games is entitled to refuse orders or to attach certain conditions to the delivery, unless explicitly stated otherwise.
<G-vec00519-002-s729><attach.verknüpfen><de> Formula Games ist berechtigt, Bestellungen abzulehnen oder bestimmte Bedingungen mit der Lieferung zu verknüpfen, sofern nicht ausdrücklich etwas anderes angegeben ist.
