<G-vec00623-002-s038><combine.bündeln><en> Best practice guidelines: The USK offers different themed guidelines which combine the long experience of the USK in the field of youth protection.
<G-vec00623-002-s038><combine.bündeln><de> Leitfäden: Die Handlungsempfehlungen bündeln die langjährige Erfahrung der USK und dienen als wertvolle Nachschlagwerke für die praktische Arbeit.
<G-vec00623-002-s039><combine.bündeln><en> A differentiating feature of Atos’ FinLab is the ability to create customer-specific end-to-end journeys (Loans Origination, My Finance Pal 2.0, and Digital Assistant), which combine bundled services and APIs of various Fintech solutions.
<G-vec00623-002-s039><combine.bündeln><de> Ein besonderes Leistungsmerkmal von Atos FinLab besteht in kundenspezifischen End-to-End-Abläufen (Darlehensanbahnung, My Finance Pal 2.0 und Digital Assistant), die Dienste und APIs verschiedener FinTech-Lösungen bündeln.
<G-vec00623-002-s040><combine.bündeln><en> Flying once over the Saarland Informatics Campus: Five international research institutes and three networked departments of Saarland University combine their expertise here to cover the entire spectrum of computer science.
<G-vec00623-002-s040><combine.bündeln><de> Einmal über den Saarland Informatics Campus fliegen: Fünf internationale Forschungsinstitute und drei vernetzte Fachrichtungen der Universität des Saarlandes bündeln hier ihre Kompetenzen, um das gesamte Spektrum der Informatik abzudecken.
<G-vec00623-002-s041><combine.bündeln><en> To accomplish this, we combine our experience and expertise from the LISSMAC business segments and offer integrated comprehensive solutions from a single source.
<G-vec00623-002-s041><combine.bündeln><de> Dafür bündeln wir unsere Erfahrung und Kompetenzen aus unseren Geschäftsfeldern und liefern integrierte Komplettlösungen aus einer Hand.
<G-vec00623-002-s042><combine.bündeln><en> The direct exchange enables us to combine our know-how and to optimise processes together.
<G-vec00623-002-s042><combine.bündeln><de> Der direkte Austausch ermöglicht es uns, unser Know-how zu bündeln und gemeinsam Prozesse zu optimieren.
<G-vec00623-002-s043><combine.bündeln><en> They will have to hide in various places (there is a lot of them here and there is always a choice), combine their efforts for survival, look for weapons and try to do everything in order not to find themselves in a hopeless situation.
<G-vec00623-002-s043><combine.bündeln><de> Sie müssen sich an verschiedenen Orten verstecken (es gibt viele von ihnen hier und es gibt immer eine Wahl), ihre Überlebensbemühungen bündeln, nach Waffen suchen und versuchen, alles zu tun, um nicht in eine hoffnungslose Situation zu geraten.
<G-vec00623-002-s044><combine.bündeln><en> “We want to combine all customer communication across all channels under one interface.
<G-vec00623-002-s044><combine.bündeln><de> „Unser Anspruch ist die komplette Kundenkommunikation über alle Kanäle unter einer Oberfläche zu bündeln.
<G-vec00623-002-s045><combine.bündeln><en> The director’s work finally allowed me to combine all my interests and skills.
<G-vec00623-002-s045><combine.bündeln><de> Die Arbeit als Regisseurin ermöglichte es mir schließlich, alle meine Interessen und Fähigkeiten zu bündeln.
<G-vec00623-002-s046><combine.bündeln><en> Our aim is to intelligently connect people, brands and machines, and to combine the strength and potential of our global manufacturing and logistics partnerships in order to take long-term advantage of the resulting synergies.
<G-vec00623-002-s046><combine.bündeln><de> Wir streben an, Menschen, Marken und Maschinen intelligent zu vernetzen und so die Kräfte und Potenziale unserer weltweiten Fertigung und Logistik zu bündeln, um so die daraus entstehenden Synergien für die Wettbewerbs- und Zukunftsfähigkeit unseres Unternehmens nachhaltig zu nutzen.
<G-vec00623-002-s047><combine.bündeln><en> In order to determine the quantity considered for the scale price, you can flexibly "combine" different products and variants.
<G-vec00623-002-s047><combine.bündeln><de> Und für die Ermittlung der für einen Staffelpreis zugrundeliegenden Menge können Sie zudem Produkte und Varianten übergreifend "bündeln".
<G-vec00623-002-s048><combine.bündeln><en> Well-known banks and service providers of the banking sector combine - under the direction of Fraunhofer IAO - their knowledge and expertise to gain a steady competitive advantage by means of innovative approaches.
<G-vec00623-002-s048><combine.bündeln><de> Unter wissenschaftlicher Leitung des Fraunhofer IAO bündeln hierzu namhafte Banken und Dienstleister der Branche ihre Kompetenzen, um sich mittels neuartiger Gestaltungsansätze einen kontinuierlichen Wettbewerbsvorsprung zu erarbeiten.
<G-vec00623-002-s049><combine.bündeln><en> Losberger and De Boer had worked together quite a few times already, when in 2017 both companies decided to join forces and combine their extensive knowledge, experience, capacity and market share to move forward together, as Losberger De Boer.
<G-vec00623-002-s049><combine.bündeln><de> Losberger und De Boer hatten früher schon einige Male zusammengearbeitet, als sich beide Unternehmen 2017 dazu entschlossen, ihre Kräfte zu bündeln und ihr umfangreiches Wissen, ihre Erfahrung, ihre Kapazitäten und ihren Marktanteil zusammenzubringen, um gemeinsam als Losberger De Boer voranzukommen.
<G-vec00623-002-s050><combine.bündeln><en> The scientists of the Department of Computer Science combine their diverse research activities in six research areas.
<G-vec00623-002-s050><combine.bündeln><de> Die Wissenschaftlerinnen und Wissenschaftler des Fachbereichs Informatik bündeln ihre vielfältigen Forschungsaktivitäten in sechs Forschungsschwerpunkte.
<G-vec00623-002-s051><combine.bündeln><en> The two companies, which have been at the forefront of innovation in enterprise and consumer IoT, will combine teams and technologies to create an end-to-end solution that is ideal for data-intensive industries that need real-time performance monitoring, data intelligence, and predictive analytics.
<G-vec00623-002-s051><combine.bündeln><de> Die beiden Firmen, die bereits seit Jahren an der Spitze innovativer Geschäfts- und Konsumenten-IoT-Services liegen, werden Arbeitskräfte und Technologien bündeln, um eine End-to-End Lösung herzustellen, die sich ideal für Unternehmen mit hohem Datenaufkommen eignet und die Echtzeit-Visualisierung, Datenintelligenz sowie prognosefähige Analysen anbietet.
<G-vec00623-002-s052><combine.bündeln><en> Structured funds that combine public funds with the capital of private investors thus represent an important instrument in environmental and climate financing for KfW.
<G-vec00623-002-s052><combine.bündeln><de> Strukturierte Fonds, die öffentliche Mittel mit dem Kapital privater Investoren bündeln, stellen daher für die KfW ein wichtiges Instrument in der Umwelt-und Klimafinanzierung dar.
<G-vec00623-002-s053><combine.bündeln><en> So now, it’s only logical to combine these activities in a subsidiary and work with strong partners to parlay that.” says Dan Maag, CEO of PANTALEON Entertainment AG.
<G-vec00623-002-s053><combine.bündeln><de> Nun ist es nur konsequent, diese Aktivitäten in einem Tochterunternehmen zu bündeln und gemeinsam mit starken Partnern weiter auszubauen“, so Dan Maag, Vorstand der PANTALEON Entertainment AG.
<G-vec00623-002-s054><combine.bündeln><en> At our three locations, we combine a high level of competency with years of experience in commercial and public law as well as, with our joining forces of top experts in the field, in criminal law.
<G-vec00623-002-s054><combine.bündeln><de> An unseren drei Standorten bündeln wir große Kompetenz und langjährige Erfahrung im Wirtschaftsrecht und öffentlichen Recht sowie im Strafrecht.
<G-vec00623-002-s055><combine.bündeln><en> “We are excited to partner with Broadcast Solutions again and combine our expertise even more.
<G-vec00623-002-s055><combine.bündeln><de> "Wir freuen uns, wieder mit Broadcast Solutions zusammenzuarbeiten und unser gemeinsames Know-how zu bündeln.
<G-vec00623-002-s056><combine.bündeln><en> We need to pool resources, combine infrastructures, and unite our negotiating power vis-a-vis third countries.
<G-vec00623-002-s056><combine.bündeln><de> Wir müssen unsere Kräfte bündeln, unsere Infrastrukturen vernetzen und unsere Verhandlungsmacht gegenüber Drittländern stärken, indem wir mit einer Stimme sprechen.
<G-vec00623-002-s095><combine.kombinieren><en> If you combine it with exercise routine (at least 20 minutes daily) will accelerate the results.
<G-vec00623-002-s095><combine.kombinieren><de> Wenn sie die Diät auch mit Routine-Übung kombinieren (mindestens 20 Minuten täglich) beschleunigen sie die Ergebnisse.
<G-vec00623-002-s096><combine.kombinieren><en> Your Cloudera instructor will combine lecture, demonstrations, and open discussion to ensure that you get maximum benefit, strengthening your competence in the concepts covered that week.
<G-vec00623-002-s096><combine.kombinieren><de> Ihr Cloudera-Dozent wird die Vorlesung, Präsentationen und offenen Diskussionen kombinieren, um sicherzustellen, dass Sie alle Vorteile nutzen und Ihre Fähigkeiten im Rahmen der in dieser Woche behandelten Themen vertiefen.
<G-vec00623-002-s097><combine.kombinieren><en> You can also combine your School Sports project with teaching English.
<G-vec00623-002-s097><combine.kombinieren><de> Du hast außerdem die Möglichkeit, das Schulsport – Projekt mit dem Unterrichten von Englisch zu kombinieren.
<G-vec00623-002-s098><combine.kombinieren><en> It will combine ideas covered in earlier modules in particular Stochastic Models, Contingencies and Probability and Statistics.
<G-vec00623-002-s098><combine.kombinieren><de> Es wird die Ideen kombinieren, die in früheren Modulen in den Bereichen Stochastische Modelle, Eventualfälle und Wahrscheinlichkeit und Statistik behandelt wurden.
<G-vec00623-002-s099><combine.kombinieren><en> If you combine chalkboard paint with magnetic paint there is no limit to your creativity: Use magnets on the same surface you write on with chalk.
<G-vec00623-002-s099><combine.kombinieren><de> Wenn Sie die Tafelfarbe mit Magnetfarbe kombinieren, sind den Ideen keine Grenzen gesetzt: Verwenden Sie Magnete auf der gleichen Oberfläche, auf der Sie mit Kreide zeichnen oder schreiben.
<G-vec00623-002-s100><combine.kombinieren><en> DanCenter may combine data about your bookings, your search behaviour, your settings on our website or in the app, your favourites, and our communication with you.
<G-vec00623-002-s100><combine.kombinieren><de> DanCenter kann die Daten zu Ihren Buchungen, Ihrem Suchverhalten, Ihren Einstellungen auf unserer Webseite oder in unserer App, Ihre Favoriten und unsere Kommunikation mit Ihnen kombinieren.
<G-vec00623-002-s101><combine.kombinieren><en> In this case, you can combine finger technology with a pen.
<G-vec00623-002-s101><combine.kombinieren><de> In diesem Fall können Sie die Fingertechnologie mit einem Stift kombinieren.
<G-vec00623-002-s102><combine.kombinieren><en> Double protection: with Swiss Life Protection, you can combine disability insurance and term life insurance in a single contract – based entirely on your individual needs.
<G-vec00623-002-s102><combine.kombinieren><de> Doppelt geschützt: Mit Swiss Life Protection können Sie die Erwerbsunfähigkeits- mit der Todesfallversicherung in einem einzigen Vertrag kombinieren – ganz nach Ihrem individuellen Bedarf.
<G-vec00623-002-s103><combine.kombinieren><en> Lodgings in the complex include only suites (in total 2000 beds), divided in three zones - Zelenika, Marina and Pelikan and combine the convenience of modern life with the aura of old Bulgarian Revival period architecture.
<G-vec00623-002-s103><combine.kombinieren><de> Die Quartiere im Komplex sind nur Apartaments (insgesamt 2000 Betten), die in drei Zonen - Zelenika, Marina und Pelikan, verteilt werden und die die Bequemlichkeiten des modernen Lebens mit der Atmosphaere der alten bulgarischen Architektur aus der Periode der Wiedergeburt kombinieren.
<G-vec00623-002-s104><combine.kombinieren><en> However, for most things a bit of imagination and intuition can help to combine several basic rules of maths and physics to do things that actually look quite clever.
<G-vec00623-002-s104><combine.kombinieren><de> In den meisten Fällen ist es aber so, dass ein bisschen Vorstellungskraft und Intuition schon sehr dabei helfen, die grundsätzlichen Regeln aus Mathematik und Physik zu kombinieren, so dass das Resultat ganz vernünftig aussieht.
<G-vec00623-002-s105><combine.kombinieren><en> Guests will have the opportunity to combine relaxation and excellent cuisine offered by the brilliant chef with Gallura natural beauties discovery.
<G-vec00623-002-s105><combine.kombinieren><de> Sie können die Entspannung und die ausgezeichnete Küche des Chefkochs mit der Entdeckung der Naturschönheiten der Region Gallura kombinieren.
<G-vec00623-002-s106><combine.kombinieren><en> Most restaurants recognized the possibilities hidden in wine-tourism therefore they bravely combine classic and modern dishes with typical Eger wines.
<G-vec00623-002-s106><combine.kombinieren><de> Aus diesem Grund können Sie mutig die klassischen und modernen Gerichte mit den typischen Egerer Weinen kombinieren.
<G-vec00623-002-s107><combine.kombinieren><en> Combine perfecting the French language with discovering the professional world. Quote upon request
<G-vec00623-002-s107><combine.kombinieren><de> Die Perfektionierung der französischen Sprache und die Entdeckung der Berufswelt kombinieren.
<G-vec00623-002-s108><combine.kombinieren><en> The goal is to only combine prepared food and dishes throughout the week.
<G-vec00623-002-s108><combine.kombinieren><de> Das Ziel ist es, unter der Woche nur noch die bereits vorbereiteten Zutaten immer neu zu kombinieren.
<G-vec00623-002-s109><combine.kombinieren><en> We may combine information about you from a visit to one OTT Hydromet Site with information about you from visits to other OTT Hydromet Sites.
<G-vec00623-002-s109><combine.kombinieren><de> Wir können die Sie betreffenden Daten, die bei einem Besuch bei einer Website von OTT Hydromet erhoben wurden, mit den Sie betreffenden Informationen kombinieren, die bei Besuchen bei anderen Websites von OTT Hydromet erhoben wurden.
<G-vec00623-002-s110><combine.kombinieren><en> If you combine Briox Scanner/Archive with Briox Time and Invoicing, you can expand your time invoices with detailed attachments.
<G-vec00623-002-s110><combine.kombinieren><de> Wenn Sie die Briox Scanner App mit der Briox Zeiterfassung und Briox Rechnung kombinieren, können Sie Ihre Rechnungen mit detaillierten Anhängen versehen.
<G-vec00623-002-s111><combine.kombinieren><en> Through this network, the small and medium-sized enterprises and the research institute can combine their long-standing experience and competences in the area of satellite services, software development and maritime services and fall back on the existing infrastructure of the project's partners - for example for receiving and processing the data.
<G-vec00623-002-s111><combine.kombinieren><de> Durch diesen Verbund können die die kleinen und mittelständischen Unternehmen und das Forschungsinstitut ihre langjährigen Erfahrungen und Kompetenzen im Bereich der Satellitendienste, Softwareentwicklung und maritimen Dienstleistungen kombinieren und auf die bereits vorhandene Infrastruktur der Projektpartner - etwa zum Empfangen und Verarbeiten der Daten - zurückgreifen.
<G-vec00623-002-s112><combine.kombinieren><en> Surrounded by pine forest and peaceful bays, and just a stone’s throw from town, Aminess Sirena is a destination for anyone looking to combine relaxation in nature with trips to town.
<G-vec00623-002-s112><combine.kombinieren><de> Umgeben von einem Kiefernwald und stillen Buchten in Stadtnähe ist Aminess Sirena ideal für alle, die Entspannung und Natur mit Stadtausflügen kombinieren.
<G-vec00623-002-s113><combine.kombinieren><en> In addition, you can combine oils for a perfect hair repairing cocktail.
<G-vec00623-002-s113><combine.kombinieren><de> Außerdem ist es möglich, die Öle zu kombinieren, um so einen perfekten Haar-Reparatur-Cocktail zu erstellen.
<G-vec00623-002-s247><combine.kombinieren><en> When I wear a dress for everyday, I combine it more often with comfortable shoes to feel good all day and not to overdressed.
<G-vec00623-002-s247><combine.kombinieren><de> Wenn ich sie alltäglich trage, kombiniere ich dazu eher ein bequemes Schuhwerk, um mich einfach den ganzen Tag wohlzufühlen und nicht overdressed zu wirken.
<G-vec00623-002-s248><combine.kombinieren><en> Combine your favourite reusable cup.
<G-vec00623-002-s248><combine.kombinieren><de> Kombiniere Deinen Lieblings-Mehrwegbecher.
<G-vec00623-002-s249><combine.kombinieren><en> I combine multiple purchases when I can.
<G-vec00623-002-s249><combine.kombinieren><de> Ich kombiniere mehrere Einkäufe, wann immer ich kann.
<G-vec00623-002-s250><combine.kombinieren><en> I combine the box with the white lid and with the Create Me tea light holders on the matching tray.
<G-vec00623-002-s250><combine.kombinieren><de> Ich kombiniere die Box mit dem weißen Deckel und mit den Create Me Teelichthaltern auf dem passenden Tablett.
<G-vec00623-002-s251><combine.kombinieren><en> I combine my super short tennis pants with three different tops: A white tank top, a grey T-shirt and a black sweatshirt.
<G-vec00623-002-s251><combine.kombinieren><de> Meine super kurze Tennishose kombiniere ich mit drei verschiedenen Oberteilen: Ein weißes Tanktop, ein grauses T-Shirt und ein schwarzes Sweatshirt.
<G-vec00623-002-s252><combine.kombinieren><en> Quickly generate documents Combine all your project information into one professional quote with the click of a button.
<G-vec00623-002-s252><combine.kombinieren><de> Schnell Dokumente erstellen Kombiniere alle Projektinformationen auf Knopfdruck zu einem professionellen Angebot.
<G-vec00623-002-s253><combine.kombinieren><en> In the office, I combine it with a blazer, waistbelt and ankle boots.
<G-vec00623-002-s253><combine.kombinieren><de> Im Büro kombiniere ich es mit Blazer, Taillengürtel und Stiefeletten.
<G-vec00623-002-s254><combine.kombinieren><en> I combine my constellation work with energy work and singing / sound, which releases blockages much more quickly.
<G-vec00623-002-s254><combine.kombinieren><de> Ich kombiniere meine Aufstellungsarbeit mit Energiearbeit und Gesang/Klang, was Blockaden wesentlich schneller löst.
<G-vec00623-002-s255><combine.kombinieren><en> With this I follow an important rule to make the look seem not too black and not boring: I combine my outfit with a statement accessory – an eye catcher that contrasts to the rest of the rather simple look.
<G-vec00623-002-s255><combine.kombinieren><de> Dazu befolge ich eine wichtige Regel, damit das Outfit nicht zu schwarz und dadurch vielleicht sogar ein bisschen langweilig wirkt: Ich kombiniere den Look mit einem besonderen Statement-Accessoire – also einem Eyecatcher, der im Kontrast zu dem restlichen, eher schlichten Outfit steht.
<G-vec00623-002-s256><combine.kombinieren><en> Combine sounds and loops, play software instruments and drag & drop to apply effects. It's simple.
<G-vec00623-002-s256><combine.kombinieren><de> Kombiniere Sounds und Loops, spiele Software-Instrumente ein und wende Effekte per Drag & Drop an – so einfach, wie noch nie.
<G-vec00623-002-s258><combine.kombinieren><en> Take the DELE preparation course or combine a group Spanish course in Malaga with private lessons, in order to communicte with group mates and to solve your personal questions.
<G-vec00623-002-s258><combine.kombinieren><de> Entscheide Dich für den DELE Vorbereitungskurs oder kombiniere einen Spanischkurs in Malaga mit Privatstunden.
<G-vec00623-002-s259><combine.kombinieren><en> I love to combine them with my typical pastel shades!
<G-vec00623-002-s259><combine.kombinieren><de> Gerne kombiniere ich sie zu zarten Pastellfarben.
<G-vec00623-002-s260><combine.kombinieren><en> Discover ancient Unknown Scrolls and combine them for better attacks and protection from your enemies. Fast paced gameplay
<G-vec00623-002-s260><combine.kombinieren><de> Entdecke die alten unbekannten Schriftrollen und kombiniere sie, um sie besser anzugreifen und vor deinen Feinden zu schützen.
<G-vec00623-002-s261><combine.kombinieren><en> I combine it with a tight black body with a lace adornment, which makes the trousers look even more elegant.
<G-vec00623-002-s261><combine.kombinieren><de> Ich kombiniere sie mit einem eng anliegenden schwarzen Body mit einer Spitzenverzierung, was die Hose noch eleganter wirken lässt.
<G-vec00623-002-s262><combine.kombinieren><en> Light: Combine natural with artificial light: place different-sized block candles in groups, and opt for floor lamps with wooden legs.
<G-vec00623-002-s262><combine.kombinieren><de> Licht: Kombiniere natürliches und künstliches Licht: Unterschiedlich hohe Blockkerzen in Gruppen aufstellen, Stehlampen mit Holzbeinen wählen.
<G-vec00623-002-s263><combine.kombinieren><en> Combine the scenic surroundings of our language school in Turrialba with adrenaline packed white water rafting or hikes up an active volcano.
<G-vec00623-002-s263><combine.kombinieren><de> Kombiniere einen Spanisch Sprachkurs in Turrialba, der Stadt mit dem malerischen Hintergrund, mit Adrenalin beim Wießwasserraften oder der Besteigung eines aktiven Vulkans.
<G-vec00623-002-s264><combine.kombinieren><en> Combine them with maternity tights or leggings, cosy jumpers or warming cardigans and nursing ponchos.
<G-vec00623-002-s264><combine.kombinieren><de> Kombiniere sie dazu mit Umstandstrumpfhosen oder Umstandsleggings, cosy Pullovern oder wärmenden Cardigans und Still-Ponchos.
<G-vec00623-002-s265><combine.kombinieren><en> Combine this thong with a matching bra for a complete set.
<G-vec00623-002-s265><combine.kombinieren><de> Kombiniere ihn mit einem passenden BH, um das Set zu vervollständigen.
<G-vec00623-002-s266><combine.kombinieren><en> Brands like William Hill, PaddyPower and Betfair combine their players on a shared poker software back-end.
<G-vec00623-002-s266><combine.kombinieren><de> Marken wie William Hill, PaddyPower und Betfair kombinieren ihre Spieler zu einer gemeinsamen Poker Software Back-End.
<G-vec00623-002-s267><combine.kombinieren><en> We combine in-depth machine learning expertise with the necessary strategy and business experience to successfully apply the technologies in the corporate environment.
<G-vec00623-002-s267><combine.kombinieren><de> Wir kombinieren tiefgehende Machine Learning Expertise mit der nötigen Strategie- und Business-Erfahrung, um die Technologien erfolgreich im Geschäftsumfeld anzuwenden.
<G-vec00623-002-s268><combine.kombinieren><en> However you can combine it also with the Maximum Krea-Genic Kapseln or Krea-Genic Powder Formula.
<G-vec00623-002-s268><combine.kombinieren><de> Du kannst es aber auch mit den Maximum Krea-Genic Kapseln oder Krea-Genic Powder Formula kombinieren.
<G-vec00623-002-s269><combine.kombinieren><en> Our customise your trip tool gives you the chance to combine two or more places, so you can make the most of every experience and enjoy twice the holiday.
<G-vec00623-002-s269><combine.kombinieren><de> Unser Tool 'Individuelle Reisegestaltung' gibt Ihnen die Möglichkeit, zwei oder mehr Reiseziele zu kombinieren, um so jede Destination in vollen Zügen zu genießen und Ihren Urlaub doppelt so schön zu machen.
<G-vec00623-002-s270><combine.kombinieren><en> The rural hotels in La Orotava are a fantastic option in this sense, as they combine solitude with the peacefulness of the countryside, which is often missing in our everyday routines.
<G-vec00623-002-s270><combine.kombinieren><de> Eine fantastische Option dafür bieten die Landhotels in Mestre, da sie Ruhe nd Entspanntheit des ländlichen Ambientes mit der Natur kombinieren, fernab vom Alltag.
<G-vec00623-002-s271><combine.kombinieren><en> Finally, SPD may combine the information that you provide with other information held by SPD or that is received from third parties.
<G-vec00623-002-s271><combine.kombinieren><de> SPD ist letztlich berechtigt, die von Ihnen bereitgestellten Daten mit anderen Daten von SPD oder Daten von Dritten zu kombinieren.
<G-vec00623-002-s272><combine.kombinieren><en> He goes on to remark that “typically, organizations need to combine multiple technologies or vendors by themselves to create this kind of process behavior today.”
<G-vec00623-002-s272><combine.kombinieren><de> Weiter merkt er an, dass „Organisationen typischerweise mehrere Technologien oder Anwender in Eigenregie kombinieren müssen, um diese Art von Prozessverhalten heute zu bewirken“.
<G-vec00623-002-s273><combine.kombinieren><en> We can combine internet, vending machine with traditional channel commercial chain code based on Cloud Service.
<G-vec00623-002-s273><combine.kombinieren><de> Wir können Internet, Automaten kombinieren mit dem kommerziellen Kettencode des traditionellen Kanals, der auf Wolken-Service basiert.
<G-vec00623-002-s274><combine.kombinieren><en> It is always fun to combine different sizes from the same family.
<G-vec00623-002-s274><combine.kombinieren><de> Immer schön, verschiedene Größen der gleichen Familie zu kombinieren.
<G-vec00623-002-s275><combine.kombinieren><en> It is not always possible to combine two rooms.
<G-vec00623-002-s275><combine.kombinieren><de> Es ist nicht immer möglich, zwei Räume zu kombinieren.
<G-vec00623-002-s276><combine.kombinieren><en> We combine methodology with empirical research since methodology always refers to specific matching between theory, object of research and methods.
<G-vec00623-002-s276><combine.kombinieren><de> Wir kombinieren Methodologie mit empirischer Forschung, da Methodologie sich immer auch auf spezifische Passungsverhältnisse von Theorie, Gegenstand und Methode bezieht.
<G-vec00623-002-s277><combine.kombinieren><en> We may also obtain information about you from other sources and link or combine that with information we collect on our websites.
<G-vec00623-002-s277><combine.kombinieren><de> Wir können auch Daten über Sie von anderen Quellen beziehen, und diese mit den auf unseren Websites erhobenen Daten verknüpfen oder kombinieren.
<G-vec00623-002-s278><combine.kombinieren><en> It is the ability to combine the interests of all stakeholders in the shipping chain.
<G-vec00623-002-s278><combine.kombinieren><de> Es ist die Fähigkeit, die Interessen aller Beteiligten in der Kette Versand zu kombinieren.
<G-vec00623-002-s279><combine.kombinieren><en> We try to combine the two.
<G-vec00623-002-s279><combine.kombinieren><de> Wir versuchen, beides zu kombinieren.
<G-vec00623-002-s280><combine.kombinieren><en> HIGH WAIST For those who want to combine a comfort fit with a sexy silhouette; meet our high waist Push-Up and thank us later.
<G-vec00623-002-s280><combine.kombinieren><de> HIGH WAIST Für diejenigen, die eine bequeme Passform mit einer sexy Silhouette kombinieren wollen: triff unsere High-Waist Push-Up Jeans und dank uns später.
<G-vec00623-002-s281><combine.kombinieren><en> Even with little ecologically correct clothes you can always combine new styles.
<G-vec00623-002-s281><combine.kombinieren><de> Schon mit wenig ökologisch korrekter Kleidung lassen sich immer neue Styles kombinieren.
<G-vec00623-002-s282><combine.kombinieren><en> These shorts combine EXO muscle support, compression and postural support in key areas to improve performance and recovery.
<G-vec00623-002-s282><combine.kombinieren><de> Diese Shorts kombinieren EXO Muskelunterstützung, Kompression und kontrollierte Körperhaltung, um bessere Performance und schnellere Erholung zu ermöglichen.
<G-vec00623-002-s283><combine.kombinieren><en> However, you may take the same two parts hydrogen and combine it with one part sulphur (instead of oxygen), and that produces H2S, hydrogen sulphide, which is very lethal, indeed.
<G-vec00623-002-s283><combine.kombinieren><de> Wenn wir allerdings die zwei Teile Wasserstoff mit einem Teil Schwefel (statt Sauerstoff) kombinieren, bekommen wir H2S, Schwefelwasserstoff, eine absolut tödliche Substanz.
<G-vec00623-002-s284><combine.kombinieren><en> Reflecting details and new cheery colors are fun to combine with Reima outerwear and accessories.
<G-vec00623-002-s284><combine.kombinieren><de> Reflektierende Details und neue, fröhliche Farben lassen sich toll mit der Reima Outdoor-Kleidung und Accessoires kombinieren.
<G-vec00623-002-s286><combine.kombinieren><en> Or combine these products for a complete recycling system.
<G-vec00623-002-s286><combine.kombinieren><de> Oder kombinieren Sie diese Produkte für ein vollständiges Recycling-System.
<G-vec00623-002-s287><combine.kombinieren><en> Combine a city break in Rome with a beach holiday in Sorrento or on the Amalfi Coast.
<G-vec00623-002-s287><combine.kombinieren><de> Kombinieren Sie einen Städtetrip in Rom mit einem Strandurlaub in Sorrento oder an der Amalfiküste.
<G-vec00623-002-s288><combine.kombinieren><en> Combine your mesh bracelet with this mesh necklace.
<G-vec00623-002-s288><combine.kombinieren><de> Kombinieren Sie Ihr Mesh-Armband mit dieser Mesh-Halskette.
<G-vec00623-002-s289><combine.kombinieren><en> Combine it with a dimmer on the chandelier, and adjust it the way you like.
<G-vec00623-002-s289><combine.kombinieren><de> Kombinieren Sie dies mit einem Dimmer am Kronleuchter und richten Sie alles ganz nach Ihren Wünschen ein.
<G-vec00623-002-s290><combine.kombinieren><en> Combine your company event or your private event with a special adrenaline rush.
<G-vec00623-002-s290><combine.kombinieren><de> Kombinieren Sie Ihre Firmenveranstaltung oder Ihr Privat-Event mit einem besonderen Adrenalinkick.
<G-vec00623-002-s291><combine.kombinieren><en> Depending on your requirements, combine the products, services and express versions for the best logistics solution for your parcel shipment.
<G-vec00623-002-s291><combine.kombinieren><de> Kombinieren Sie je nach Anforderung die Produkte, Services und Express Varianten für die beste Logistiklösung für Ihren Paketversand.
<G-vec00623-002-s292><combine.kombinieren><en> Tipp: Combine your Camper Tour with a guided canoe on the Yukon River or a hiking trip in the Kluane National Park and explore the true Yukon wilderness.
<G-vec00623-002-s292><combine.kombinieren><de> Tipp: Kombinieren Sie Ihre Wohnmobil Rundreise mit einer einwöchigen geführten Kanutour auf dem Yukon River oder einer Wandertour im Kluane National Park und entdecken Sie den wahren Yukon.
<G-vec00623-002-s293><combine.kombinieren><en> Combine your pair of espadrilles with another accessory just as feminine and chic, the woven hat.
<G-vec00623-002-s293><combine.kombinieren><de> Kombinieren Sie Ihr Paar Espadrilles mit einem weiteren Accessoire, das ebenso feminin und chic ist, dem geflochtenen Hut.
<G-vec00623-002-s294><combine.kombinieren><en> Store your make-up in one of our make-up bags and combine it with a matching toilet bag or provide your kitchen with new life with our tea towels and cloths.
<G-vec00623-002-s294><combine.kombinieren><de> Bewahren Sie Ihr Make Up in einem unserer Make Up-Beutel auf und kombinieren Sie ihn mit einem passenden Kulturbeutel auf Reisen oder hauchen Sie Ihrer Küche mit Geschirrtüchern und Topflappen neues Leben ein.
<G-vec00623-002-s295><combine.kombinieren><en> Combine the necklace with the matching bracelet for a beautiful set.
<G-vec00623-002-s295><combine.kombinieren><de> Kombinieren Sie die Halskette mit dem passenden Armband für ein schönes Set.
<G-vec00623-002-s296><combine.kombinieren><en> Learn more about the versatile possibilities of customizable multi touch software: Combine apps to more complex projects for use at the point of sale, information, entertainment and collaboration.
<G-vec00623-002-s296><combine.kombinieren><de> Lernen Sie mehr über die vielfältigen Einsatzmöglichkeiten anpassbarer Multi Touch Software: Kombinieren Sie Apps zu komplexeren Projekten für den Einsatz am Point of Sale, Information, Entertainment und Kollaboration.
<G-vec00623-002-s297><combine.kombinieren><en> Combine one or more data feeds with API calls for even more possibilities!
<G-vec00623-002-s297><combine.kombinieren><de> Kombinieren Sie einen oder mehrere Produkt-Feeds mit API-Aufrufen für mehr Möglichkeiten.
<G-vec00623-002-s298><combine.kombinieren><en> Combine the intellectual productivity of your seminar participants with physical counterbalance right outside the front door.
<G-vec00623-002-s298><combine.kombinieren><de> Kombinieren Sie die geistige Produktivität Ihrer Seminarteilnehmer mit dem körperlichem Ausgleich, direkt vor der Haustüre.
<G-vec00623-002-s299><combine.kombinieren><en> Combine the chandelier with the surroundings.
<G-vec00623-002-s299><combine.kombinieren><de> Kombinieren Sie den Kronleuchter mit der Umgebung.
<G-vec00623-002-s300><combine.kombinieren><en> Combine DVD trays with our DVD packaging for optimal attachment of the data carrier.
<G-vec00623-002-s300><combine.kombinieren><de> Kombinieren Sie DVD-Trays mit unseren DVD-Verpackungen, um die Datenträger optimal zu befestigen.
<G-vec00623-002-s301><combine.kombinieren><en> Combine your exhibition days with an overnight stay at Hotel Houten, free parking and free Wi-Fi just 10 minutes from the Jaarbeurs.
<G-vec00623-002-s301><combine.kombinieren><de> Kombinieren Sie Ihre Ausstellungstage mit einer Übernachtung im Hotel Houten, kostenfreien Parkplätzen und kostenlosem WLAN nur 10 Minuten von den Jaarbeurs entfernt.
<G-vec00623-002-s302><combine.kombinieren><en> Combine well to the boys wallpaper and borders also substances and use our sewing service for a finished curtain, bedding or pillows.
<G-vec00623-002-s302><combine.kombinieren><de> Kombinieren Sie auch zu den Jungen Tapeten und Borten auch Stoffe und nutze Sie unseren Nähservice für eine Fertig-Gardine, Bettwäsche oder auch Kissen.
<G-vec00623-002-s303><combine.kombinieren><en> In all possible ways, combine rest.
<G-vec00623-002-s303><combine.kombinieren><de> Kombinieren Sie auf alle möglichen Arten Ruhe.
<G-vec00623-002-s304><combine.kombinieren><en> BACK With their large pilot shape, these mix-material frames combine metal and acetate in a perfect match for oval and square face shapes.
<G-vec00623-002-s304><combine.kombinieren><de> Diese aus verschiedenen Materialien bestehende Fassung in der Form einer großen Pilotenbrille kombiniert Metall und Azetat und eignet sich perfekt für ovale wie auch eckigere Gesichtskonturen.
<G-vec00623-002-s305><combine.kombinieren><en> Combine this with the visions of the SUN exploding, Gaia disappearing, and the messages of completion, and we have a very mystical, beautiful, highly esoteric passage.
<G-vec00623-002-s305><combine.kombinieren><de> Kombiniert dies mit den Visionen davon, daß die Sonne explodiert, Gaia verschwindet, und den Botschaften des Abschließens, und wir haben einen sehr mystischen, schönen, hoch esoterischen Übergang.
<G-vec00623-002-s306><combine.kombinieren><en> Our Medical Device Manufacturing services combine our expertise and Direct Metal Printing capabilities for prototyping, trial series, and large volume manufacturing for implants and instrumentation used for orthopedic, spinal, CMF, dental, and veterinary applications. Learn more Healthcare Solutions
<G-vec00623-002-s306><combine.kombinieren><de> Unser Service zur Fertigung von Medizinprodukten kombiniert unsere Kompetenzen und unseren Direktmetalldruck zur Herstellung von Prototypen, Probeserien und großen Stückzahlen für Implantate und Instrumente in den Bereichen Orthopädie, Wirbelsäulenbehandlung, CMF, Zahnheilkunde und Veterinärmedizin.
<G-vec00623-002-s307><combine.kombinieren><en> Our digital learning programs – whether Integrated Learning Experience, hosted on Miller Heiman Group’s platform or managed on your own learning system – feature an intuitive, professional user experience that combine the best aspects of classroom teaching with the efficiency of online learning.
<G-vec00623-002-s307><combine.kombinieren><de> Unabhängig davon, ob es sich um ein auf der Plattform der Miller Heiman Group gehostetes Programm oder um ein auf Ihrem eigenen Lernsystem verwaltetes Programm handelt, bieten unsere Digital Learning-Programme eine intuitive, professionelle Benutzererfahrung, die die Vorteile von Präsenztrainings mit der Effizienz des Online-Lernens kombiniert.
<G-vec00623-002-s308><combine.kombinieren><en> This recipe will combine a number of rare items and produce a random new rare item.
<G-vec00623-002-s308><combine.kombinieren><de> Dieses Rezept kombiniert eine Anzahl an seltenen Gegenständen und produziert einen zufälligen neuen seltenen Gegenstand.
<G-vec00623-002-s309><combine.kombinieren><en> Nokian Tyres' revolutionary All-Weather concept combine reliable winter safety with the precise driving stability and firm handling of our summer tyres.
<G-vec00623-002-s309><combine.kombinieren><de> Das revolutionäre Allwetter-Konzept der Nokian Reifen kombiniert zuverlässige Sicherheit im Winter mit der präzisen Fahrstabilität und dem kontrollierten Handling unserer Sommerreifen.
<G-vec00623-002-s310><combine.kombinieren><en> Silicone bracelets and necklaces, which combine the power of magnets with negative ions, are particularly popular with athletes and health-conscious people.
<G-vec00623-002-s310><combine.kombinieren><de> Bei Sportlern und gesundheitsbewussten Menschen besonders beliebt: Negativ-Ionen-Armbänder und Halsketten, die die Kraft der Magnete mit den Negativ-Ionen kombiniert.
<G-vec00623-002-s311><combine.kombinieren><en> If you combine bamboo, verbascum or heuchera with attractive ferns, you get an airy and light combination which gives even the dullest garden a fairytale aura. Show Hide Cancel
<G-vec00623-002-s311><combine.kombinieren><de> Kombiniert man Bambus, Königskerzen oder Heuchera mit den attraktiven Schmuckstücken, hat man eine luftig-leichte Kombination, die selbst dem langweiligsten Gartenfleck eine märchenhafte Aura verleiht.
<G-vec00623-002-s312><combine.kombinieren><en> We will use a variety of somatic tools to guide us through this exploration and combine them with other movement techniques.
<G-vec00623-002-s312><combine.kombinieren><de> Eine Reihe von somatischen tools kombiniert mit Bewegungstechniken, werden uns in diese Erkundung leiten.
<G-vec00623-002-s313><combine.kombinieren><en> It will combine design and manufacturing techniques clubbed with advanced materials that have not been researched till date.
<G-vec00623-002-s313><combine.kombinieren><de> Der Ansatz des ITA verknüpft Design- und Fertigungstechniken, die mit fortschrittlichen Materialien kombiniert werden, die bisher in diesem Zusammenhang noch nicht erforscht wurden.
<G-vec00623-002-s314><combine.kombinieren><en> For today’s post I decided to combine blue denim with black/grey denim and my rough Dr. Martens.
<G-vec00623-002-s314><combine.kombinieren><de> Für den heutigen Post habe ich eine blaue Jeansbluse mit einer schwarz-grauen Jeans kombiniert und dazu meine derben Dr. Martens getragen.
<G-vec00623-002-s315><combine.kombinieren><en> Both methods can combine with polarization analysis, and with parallel wavelength detection.
<G-vec00623-002-s315><combine.kombinieren><de> Beide Versionen können mit Polaristions-Analyse und mit paralleler Wellenlängen-Detektion kombiniert werden.
<G-vec00623-002-s316><combine.kombinieren><en> During these past winter weeks, I figured, that I can combine it with more than only cami dresses and tops and now the turtleneck has become a wardrobe essential for me!
<G-vec00623-002-s316><combine.kombinieren><de> Über die letzten Winterwochen hinweg habe ich meinen Rollkragenpullover immer häufiger getragen und kombiniert und nun gehört er definitiv auch zu den Basics in meinen Kleiderschrank.
<G-vec00623-002-s317><combine.kombinieren><en> Vogel also worked with a code system to match the statements and combine their evaluation. The private sector as a starting point
<G-vec00623-002-s317><combine.kombinieren><de> Zugleich arbeitete Dominik Vogel mit einem Codesystem, um die Aussagen einander zuordnen und kombiniert auswerten zu können.
<G-vec00623-002-s318><combine.kombinieren><en> G-LOFT is the first insulating material to combine the advantages of natural down with the robustness of synthetic fibres.
<G-vec00623-002-s318><combine.kombinieren><de> Als erstes Isoliermaterial kombiniert G-Loft die Vorzüge natürlicher Daunen mit der Unempfindlichkeit der Kunstfaser.
<G-vec00623-002-s319><combine.kombinieren><en> In 1948 Japan introduced a national stud registryandthe regional breeding programs united in order to combine the best characteristics of a number of breeds.
<G-vec00623-002-s319><combine.kombinieren><de> Im Jahre 1948 begann Japan die Führung eines nationalen Zuchtbuches, in dem verschiedene Zuchtprogramme mit dem Ziel, die allerbesten Eigenschaften in einigen wenigen Rassen zu vereinigen, kombiniert wurden.
<G-vec00623-002-s320><combine.kombinieren><en> In this WP the partners are to combine their ideas/approaches during the planning phases of the regional projects.
<G-vec00623-002-s320><combine.kombinieren><de> Innerhalb dieses Arbeitspakets sollen die Projektpartner während der Planungsphase ihre Ideen und Herangehensweisen in den regionalen Pilotprojekten kombiniert umsetzen.
<G-vec00623-002-s321><combine.kombinieren><en> Contrasting slate-grey underside. To combine with any Fendi bag thanks to the palladium-finish double spring clip that may be attached to handles and shoulder strap hooks.
<G-vec00623-002-s321><combine.kombinieren><de> Kann dank der zwei Federklammern mit Palladium-Finish, die an Henkeln und Schulterriemen-Ringen befestigt werden können, mit jeder Fendi Tasche kombiniert werden.
<G-vec00623-002-s322><combine.kombinieren><en> Google will not combine the visitor's IP address with other information available to Google.
<G-vec00623-002-s322><combine.kombinieren><de> Google kombiniert die IP-Adresse des Besuchers nicht mit anderen Daten, über die Google verfügt.
<G-vec00623-002-s323><combine.kombinieren><en> These materials have different physical properties and varying thicknesses that combine to provide the required barrier performance.
<G-vec00623-002-s323><combine.kombinieren><de> Diese Materialien besitzen unterschiedliche physikalische Eigenschaften und verschiedene Dicken, die kombiniert werden, um die gewünschte Barriere-Schutzfunktion zu erhalten.
<G-vec00623-002-s324><combine.kombinieren><en> If the queries to union are very different, you might encounter a situation where an output field must combine data of different data types.
<G-vec00623-002-s324><combine.kombinieren><de> Wenn die Abfragen zur Union-Abfrage sehr unterschiedlich sind, kommt es vielleicht zu einer Situation, bei der in einem Ausgabefeld Daten verschiedener Typen kombiniert werden müssen.
<G-vec00623-002-s325><combine.kombinieren><en> In the eyes of the interior aesthete, it was at best a highly unwieldy although functional object - and in any case, difficult to combine with the rest of the interior.
<G-vec00623-002-s325><combine.kombinieren><de> In den Augen der Innendesign-Ästheten handelte es sich allenfalls um ein funktionales Objekt, das aber unpraktisch war und kaum mit der Wohnungseinrichtung kombiniert werden konnte.
<G-vec00623-002-s326><combine.kombinieren><en> Cool print is nice to combine with different kind of outfits – and the result is irresistible.
<G-vec00623-002-s326><combine.kombinieren><de> Der coole Druck kann leicht mit verschiedenen Outfits kombiniert werden – und das Ergebnis ist unwiderstehlich.
<G-vec00623-002-s327><combine.kombinieren><en> Description The cube is, because of the flat wicker design, easy to combine with other garden furniture.
<G-vec00623-002-s327><combine.kombinieren><de> Bezeichnung Der Cube kann durch sein Design aus flachem Wicker einfach mit anderen Gartenmöbeln kombiniert werden.
<G-vec00623-002-s328><combine.kombinieren><en> It is frequently possible to combine process steps based on different principles in our systems.
<G-vec00623-002-s328><combine.kombinieren><de> Oft können dabei prinzipiell unterschiedliche Prozessschritte in unseren Systemen kombiniert werden.
<G-vec00623-002-s329><combine.kombinieren><en> For that subtle feminine note, combine them with jeans and sneakers or with a suit at work. It even works as an accessory.
<G-vec00623-002-s329><combine.kombinieren><de> Ob sie im Alltag zu Jeans und Sneakers kombiniert werden, oder im Büro zu einem Anzug, Lingerie Oberteile bringen in jedem Fall eine subtil feminine Note mit sich.
<G-vec00623-002-s330><combine.kombinieren><en> You can apply multiple targeting items to a preference item and select the logical operation (AND or OR) by which to combine each targeting item with the preceding one.
<G-vec00623-002-s330><combine.kombinieren><de> Sie können mehrere Zielelemente auf ein Einstellungselement anwenden und die logische Operation (UND oder ODER) auswählen, mit der die einzelnen Zielelemente mit dem jeweils vorhergehenden kombiniert werden sollen.
<G-vec00623-002-s331><combine.kombinieren><en> During the course you will learn how to combine the habitat of humans, animals and plants in a sustainable way by considering the needs of all.
<G-vec00623-002-s331><combine.kombinieren><de> Während des Permakultur-Zertifikatskurses erfährst du, wie das Zusammenleben von Menschen, Tieren und Pflanzen symbiotisch kombiniert werden kann, um die Bedürfnisse aller zu berücksichtigen.
<G-vec00623-002-s332><combine.kombinieren><en> According to experts and policy makers, the Directive on Human Trafficking sets a good example of how to combine prevention, protection of victims and punishment of perpetrators.
<G-vec00623-002-s332><combine.kombinieren><de> Nach Ansicht von Experten und politischen Entscheidungsträgern stellt die Richtlinie zum Menschenhandel ein gutes Beispiel dafür dar, wie Prävention, Opferschutz und Bestrafung der Täter kombiniert werden sollten.
<G-vec00623-002-s333><combine.kombinieren><en> Of course, a great photo book has to combine good design with even better photography.
<G-vec00623-002-s333><combine.kombinieren><de> Natürlich muss in einem guten Fotobuch gutes Design mit noch besserer Fotografie kombiniert werden.
<G-vec00623-002-s334><combine.kombinieren><en> By rotating three mechanical disks, it was possible to combine concepts so as to form sentences supposed to serve as proof of God.
<G-vec00623-002-s334><combine.kombinieren><de> Mittels Drehung dreier mechanischer Scheiben konnten Begriffe kombiniert werden und ergaben so Sätze, die als Gottesbeweis gelten sollten.
<G-vec00623-002-s335><combine.kombinieren><en> Pick the color, pattern, form of nose or ears of your puppy just as you wish, combine different features and create numerous puppies to share with your friends.
<G-vec00623-002-s335><combine.kombinieren><de> Nach Belieben können beispielsweise Farbe und Musterung des Fells, Form der Nase und Ohren und vieles mehr bestimmt und kombiniert werden.
<G-vec00623-002-s336><combine.kombinieren><en> This would combine the performance and handling of a modern bike with the more traditional styling – and at the time I wasn’t aware of anyone else going down this path with a Speed Triple.
<G-vec00623-002-s336><combine.kombinieren><de> Auf diese Weise könnten Leistung und Fahrverhalten eines modernen Motorrads mit der traditionelleren Optik kombiniert werden – und zu der Zeit kannte ich niemanden, der das mit einer Speed Triple vorhatte.
<G-vec00623-002-s337><combine.kombinieren><en> For economic reasons, it is possible to combine this system with Hook-On ceiling elements (type 3/4).
<G-vec00623-002-s337><combine.kombinieren><de> Aus wirtschaftlichem Aspekt kann dieses System mit eingehängten Deckenelementen (Typ 3/4) kombiniert werden.
<G-vec00623-002-s338><combine.kombinieren><en> Of course you can combine all these.
<G-vec00623-002-s338><combine.kombinieren><de> Selbstverständlich können diese kombiniert werden.
<G-vec00623-002-s339><combine.kombinieren><en> The farm shop is open Thursday, Friday and Saturday, pay a visit to the shop, and combine it with a visit to our dairy, which has been producing dairy products since 1887.
<G-vec00623-002-s339><combine.kombinieren><de> Der Hofladen ist offen Donnerstag, Freitag und Samstag und kann mit einem Besuch bei unserer Molkerei kombiniert werden, wo seit 1887 Milcherzeugnisse hergestellt worden sind.
<G-vec00623-002-s340><combine.kombinieren><en> Financial incentives should combine Union and national measures.
<G-vec00623-002-s340><combine.kombinieren><de> Bei den finanziellen Anreizen sollen Maßnahmen der Union und nationale Maßnahmen kombiniert werden.
<G-vec00623-002-s341><combine.kombinieren><en> Upon request, you can rent individual rooms or combine your booking with events at the Convention Centre, linked with an indoor covered passage.
<G-vec00623-002-s341><combine.kombinieren><de> Auf Anfrage können einzelne Räume gemietet werden oder Ihre Buchung kann mit Veranstaltungen im Kongresszentrum kombiniert werden, da die Villa Ciani durch eine überdachte Passage mit dem Kongresszentrum verbunden ist.
<G-vec00623-002-s361><combine.kombinieren><en> State of the art LED units have been added to the range, allowing you to combine design and energy efficiency.
<G-vec00623-002-s361><combine.kombinieren><de> Die Serie wurde durch hochmoderne LED-Einheiten ergänzt, die es Ihnen ermöglichen, Design und Energieeffizienz miteinander zu kombinieren.
<G-vec00623-002-s362><combine.kombinieren><en> It only makes sense to combine several different methods and figure out which one works best for you: sticky notes, watching foreign films, writing your own hip-hop lyrics in French, cooking recipes … creativity has no limits.
<G-vec00623-002-s362><combine.kombinieren><de> Es ist sinnvoll, unterschiedliche Methoden miteinander zu kombinieren und auszuprobieren, was für dich funktioniert: Beschrifte Klebezettel, schau fremdsprachige Filme an, schreibe deine eigenen Hiphop-Rhymes auf Französisch, koche Rezepte nach … der Kreativität sind keine Grenzen gesetzt.
<G-vec00623-002-s363><combine.kombinieren><en> He established EVS in a bid to combine as many of his interests and skills as possible, mainly languages and business acumen.
<G-vec00623-002-s363><combine.kombinieren><de> EVS hat er gegründet, um möglichst viele seiner Interessen und Fähigkeiten, allen voran Sprachen und Wirtschaft, miteinander zu kombinieren.
<G-vec00623-002-s364><combine.kombinieren><en> All the better that I am now able to combine my passion for University and work.
<G-vec00623-002-s364><combine.kombinieren><de> Umso größer ist meine Freude natürlich nun darüber, dass ich meine Interessen in Studium und Beruf miteinander kombinieren kann.
<G-vec00623-002-s365><combine.kombinieren><en> The capital of Germany will be the ideal place for you to combine gambling and Christmas.
<G-vec00623-002-s365><combine.kombinieren><de> Die Hauptstadt von Deutschland ist der ideale Ort, um Glücksspiele und Weihnachten miteinander zu kombinieren.
<G-vec00623-002-s366><combine.kombinieren><en> You can of course combine all three walks.
<G-vec00623-002-s366><combine.kombinieren><de> Natürlich können Sie aber auch alle drei Wanderungen miteinander kombinieren.
<G-vec00623-002-s367><combine.kombinieren><en> For everyone, who would love to combine golf with culinary experiences, this package is the perfect one!
<G-vec00623-002-s367><combine.kombinieren><de> FAVORITE’s GOLFEN & GENIEßEN Für alle, die Golf und Kulinarik miteinander kombinieren möchten ist dieses Arrangement genau richtig.
<G-vec00623-002-s368><combine.kombinieren><en> We have 30 years of experience developing hybrid cannabis strains that combine the effects of indica and sativa.
<G-vec00623-002-s368><combine.kombinieren><de> Bereits seit 30 Jahren entwickeln wir hybride Cannabissorten, die die Wirkungen von Indica und Sativa miteinander kombinieren.
<G-vec00623-002-s369><combine.kombinieren><en> If you need to store or ship an extra-large item, you can combine two ordinary cardboard boxes.
<G-vec00623-002-s369><combine.kombinieren><de> Falls du einen besonders großen Artikel aufbewahren oder verschicken musst, kannst du zwei gewöhnliche Pappkartons miteinander kombinieren.
<G-vec00623-002-s370><combine.kombinieren><en> By now you know that I love to combine different styles and opposites and this time, I combined some fishnet tights and leather elements with a playful flower print with ruffles.
<G-vec00623-002-s370><combine.kombinieren><de> Ihr wisst mittlerweile ja schon, wie ich es liebe Stilbrüche miteinander zu kombinieren und dieses Mal habe ich eine Netzstrumpfhose und Leder mit einem verspielten Blümchenprint mit Rüschen kombiniert.
<G-vec00623-002-s371><combine.kombinieren><en> BaidingerBusiness is a full-service agency and acts like an external department for following areas: databases, events, exhibitions, marketing, communication & PR Their USP: they combine all 4 sub-areas and use them efficient for their clients.
<G-vec00623-002-s371><combine.kombinieren><de> BaidingerBusiness ist eine Full-Service Agentur und fungiert als externe Abteilung auf Abruf in den Bereichen: Datenbanken, Events, Messen, Marketing, Kommunikation & PR Ihre USP ist es, diese 4 Teilbereiche miteinander zu kombinieren und effizient – für ihre Kunden – einzusetzen.
<G-vec00623-002-s372><combine.kombinieren><en> To consider all these various indicators, a trader needs to perfectly combine different tools of technical and fundamental analysis.
<G-vec00623-002-s372><combine.kombinieren><de> Um all diese verschiedenen Indikatoren zu berücksichtigen, muss ein Trader verschiedene Tools zur technischen und fundamentalen Analyse perfekt miteinander kombinieren.
<G-vec00623-002-s373><combine.kombinieren><en> But at the beginning of the millennium, it was not so easy to collect the right metadata and combine it.
<G-vec00623-002-s373><combine.kombinieren><de> Doch Anfang des Jahrtausends war es noch nicht so leicht, die richtigen Metadaten zu erheben und miteinander zu kombinieren.
<G-vec00623-002-s374><combine.kombinieren><en> We have maintained the essence and naturalness of the pieces that faithfully recreate a natural appearance, resulting in collections of original and exclusive floor and wall tile – pieces that manage to masterfully combine contemporary style with elegance.
<G-vec00623-002-s374><combine.kombinieren><de> Wesen und Natur der Teile spiegeln weiterhin die Natur wider und bilden Kollektionen mit originellen und exklusiven Boden- und Wandfliesen, die Zeitgeist und Eleganz meisterlich miteinander kombinieren.
<G-vec00623-002-s375><combine.kombinieren><en> Customers can obtain the modules individually, combine them as required and upgrade them at any time.
<G-vec00623-002-s375><combine.kombinieren><de> Kunden können die Module einzeln beziehen, miteinander kombinieren und jederzeit erweitern.
<G-vec00623-002-s376><combine.kombinieren><en> The Group’s know-how in terms of acquisitions and integration, and its ability to combine organic growth and external growth have enabled it to reach critical mass in Italy and Switzerland.
<G-vec00623-002-s376><combine.kombinieren><de> Die Fähigkeit der Gruppe, neue Firmen zu integrieren und so organisches und externes Wachstum miteinander zu kombinieren, hat ihr zu einer kritischen Größe in Italien und der Schweiz verholfen.
<G-vec00623-002-s377><combine.kombinieren><en> Designed with six extruders, three in each coating/laminating unit, it is possible to combine up to eleven layers in one production run.
<G-vec00623-002-s377><combine.kombinieren><de> Ausgelegt mit sechs Extrudern, drei in jeder Beschichtungs-/Kaschiereinheit, besteht die Möglichkeit, bis zu elf Schichten in einem Produktionsschritt miteinander zu kombinieren.
<G-vec00623-002-s378><combine.kombinieren><en> Level 10: You can combine any amount of attack blows.
<G-vec00623-002-s378><combine.kombinieren><de> Stufe 10: Du kannst beliebig viele Angriffsschläge miteinander kombinieren.
<G-vec00623-002-s379><combine.kombinieren><en> Here you can combine culture, nature and shopping effortlessly.
<G-vec00623-002-s379><combine.kombinieren><de> Hier kannst du Kultur, Natur und Shopping ganz einfach miteinander kombinieren.
<G-vec00623-002-s437><combine.kombinieren><en> We combine certified best practices with performance management tools that include predictive analytics.
<G-vec00623-002-s437><combine.kombinieren><de> Lesen Sie mehr Wir kombinieren bewährte Best Practices mit vorausschauendem Performance Management.
<G-vec00623-002-s438><combine.kombinieren><en> With this economic canopy, you can flexibly combine thermally active and passive areas.
<G-vec00623-002-s438><combine.kombinieren><de> Mit diesem wirtschaftlichen Segel sind Sie flexibel, da Sie thermisch aktive und passive Bereiche kombinieren können.
<G-vec00623-002-s439><combine.kombinieren><en> The Elite Wellcare is designed to combine the comfort of your home with the functionality of a nursing bed.
<G-vec00623-002-s439><combine.kombinieren><de> Mit der Elite Wellcare können Sie den Komfort Ihres Hauses mit der Funktionalität eines Pflegebettes kombinieren.
<G-vec00623-002-s440><combine.kombinieren><en> You can use your accumulated Sats to purchase gift cards and mobile refills directly with your rewards balance earnings, or you can also use your rewards balance earnings to combine with your existing Bitcoin, or USD/EUR balance, to purchase gift cards or mobile refills.
<G-vec00623-002-s440><combine.kombinieren><de> Sie können Ihre angesammelten Sats verwenden, um Geschenkkarten und mobile Nachfüllungen direkt mit Ihren Prämienguthabeneinnahmen zu kaufen, oder Sie können Ihre Prämienguthabeneinnahmen auch verwenden, um sie mit Ihrem vorhandenen Bitcoin- oder USD / EUR-Guthaben zu kombinieren, um Geschenkkarten oder mobile Nachfüllungen zu kaufen.
<G-vec00623-002-s441><combine.kombinieren><en> Combine them with a more elegant top and create a professional look with a casual feeling.
<G-vec00623-002-s441><combine.kombinieren><de> Sie können Sie mit einem eleganteren Oberteil kombinieren und einen professionellen Look mit Casual Feeling kreieren.
<G-vec00623-002-s442><combine.kombinieren><en> It’s amazing what answers are concealed in this data – and all the more can be revealed when you combine the data with other information (maintenance reports, production and repair records, and much more).
<G-vec00623-002-s442><combine.kombinieren><de> Es ist erstaunlich, welche Antworten in diesen Daten verborgen sind, erst recht, wenn Sie sie mit anderen Informationen (Wartungsberichte, Produktions- und Reparaturhistorien, Wetterdaten, und vieles mehr) kombinieren.
<G-vec00623-002-s443><combine.kombinieren><en> A classic and solid option for your formal attire yet versatile enough to combine with casual and stylish looks too.
<G-vec00623-002-s443><combine.kombinieren><de> Eine klassische und solide Option für Ihre formelle Kleidung, aber auch vielseitig genug, um sie mit lässigen und stilvollen Looks zu kombinieren.
<G-vec00623-002-s444><combine.kombinieren><en> Use our configurator to combine the various components.
<G-vec00623-002-s444><combine.kombinieren><de> Nutzen Sie unseren Konfigurator, um gewünschte Bauteile zu kombinieren.
<G-vec00623-002-s445><combine.kombinieren><en> With the function filters to combine the color search with additional search criteria such as season, effort, style, space and technology.
<G-vec00623-002-s445><combine.kombinieren><de> Mit der Funktion Filter können Sie die Farbsuche mit weiteren Suchkriterien wie Saison, Aufwand, Stil, Raum und Technik kombinieren.
<G-vec00623-002-s446><combine.kombinieren><en> If even that isn’t sufficient, you can combine an ND filter with a polarizing filter.
<G-vec00623-002-s446><combine.kombinieren><de> Falls dies nicht ausreicht, dann können Sie den ND-Filter mit einem Polfilter kombinieren.
<G-vec00623-002-s447><combine.kombinieren><en> Consider using server virtualization to combine the performance and security of a dedicated single-tenant environment with the cost-efficiency of a cloud-like infrastructure deployment model.
<G-vec00623-002-s447><combine.kombinieren><de> Mithilfe der Server-Virtualisierung können Sie die Leistungsfähigkeit und Sicherheit einer dedizierten Single-Tenant-Umgebung mit der Kosteneffizienz eines cloudähnlichen Infrastruktur-Implementierungsmodells kombinieren.
<G-vec00623-002-s449><combine.kombinieren><en> Of course, you can also come to us for delicious drinks, such as homemade iced tea to combine with the best ever fries.
<G-vec00623-002-s449><combine.kombinieren><de> Selbstverständlich sind Sie für herrliche Getränke wie hausgemachten Eistee, den Sie mit den besten Pommes Frites kombinieren können, bei uns an der richtigen Stelle.
<G-vec00623-002-s450><combine.kombinieren><en> In case of your benchmark project aiming at product improvement: We offer advice on how to combine the positive properties of your product with those Sitemap Contact Downloads
<G-vec00623-002-s450><combine.kombinieren><de> Wenn Sie Ihr Benchmark-Projekt gezielt zur Produktverbesserung einsetzen wollen, beraten wir Sie gerne, wie Sie die positiven Eigenschaften Ihres Produkts mit denen des Wettbewerbsprodukts kombinieren können.
<G-vec00623-002-s451><combine.kombinieren><en> You can use each option separately as well, or combine them to clean your floor in one go.
<G-vec00623-002-s451><combine.kombinieren><de> Sie können beide Optionen auch getrennt verwenden oder sie kombinieren, um Ihren Boden in einem Schritt zu reinigen.
<G-vec00623-002-s452><combine.kombinieren><en> ML systems can analyze all the data we have on shoppers, combine that with specific device and publisher formatting requirements and brand guidelines, and create a totally customized ad for an individual shopper in milliseconds.
<G-vec00623-002-s452><combine.kombinieren><de> Hier spielen ML-Systeme ihre Stärke aus: Sie können alle Käuferdaten analysieren, sie mit den spezifischen Anforderungen von Geräten, Publishern oder Markenrichtlinien kombinieren und die sich daraus ergebende Anzeige exakt auf einen Kunden abstimmen – und das in Millisekunden.
<G-vec00623-002-s453><combine.kombinieren><en> Combine with metal or semi-precious beads for some interesting designs. Was £0.78
<G-vec00623-002-s453><combine.kombinieren><de> Sie lassen sich mit Metall- oder Halbedelsteinperlen zu interessanten Designs kombinieren.
<G-vec00623-002-s454><combine.kombinieren><en> Combine your first entry with the search criteria offered below.
<G-vec00623-002-s454><combine.kombinieren><de> Sie kombinieren den ersten Eintrag mit den darunter angebotenen Suchkriterien.
<G-vec00623-002-s455><combine.kombinieren><en> Now you can combine simple and secure electronic payments with rich and timely remittance advice.
<G-vec00623-002-s455><combine.kombinieren><de> Reduzieren Sie die Nachfragen zum Zahlungsstatus um 60–80 %, indem Sie einfache und sichere elektronische Zahlungen mit einer umfassenden und frühzeitigen Zahlungsankündigung kombinieren.
<G-vec00623-002-s494><combine.sich_verbinden><en> The robust nature of ceramic rolling elements can be seen clearly from the example of a spindle bearing: the new high performance spindle bearing series RS and the thermally robust cylindrical bearing TR combine very high speed capability with high load carrying capacity and resistance under a wide variety of operating conditions.
<G-vec00623-002-s494><combine.sich_verbinden><de> Wie robust die Keramik-Wälzkörper sind, wird am Beispiel des Spindellagers deutlich: Mit der neuen Hochleistungs-Spindellagerbaureihe RS und dem thermisch robusten Zylinderrollenlager TR verbinden sich höchste Drehzahleignung mit hoher Belastbarkeit und Unempfindlichkeit bei unterschiedlichsten Betriebsbedingungen.
<G-vec00623-002-s495><combine.sich_verbinden><en> ...combine in Eichstätt.
<G-vec00623-002-s495><combine.sich_verbinden><de> ...verbinden sich in Eichstätt zu einer Einheit.
<G-vec00623-002-s496><combine.sich_verbinden><en> The sensors combine chemically with the component surfaces,” according to Dipl.-Ing.me.
<G-vec00623-002-s496><combine.sich_verbinden><de> Die Sensoren verbinden sich chemisch mit den Bauteiloberflächen“, sagt Dipl.-Ing.me.
<G-vec00623-002-s497><combine.sich_verbinden><en> Space, warm light, superior design and amazing views combine to an impressive real estate here.
<G-vec00623-002-s497><combine.sich_verbinden><de> Geräumigkeit, warmes Licht, hochwertiges Design und atemberaubende Aussicht verbinden sich hier zu einer beeindruckenden Immobilie.
<G-vec00623-002-s498><combine.sich_verbinden><en> Art and history combine in this former home of the popes – now a major museum celebrating thousands of years of the applied arts.
<G-vec00623-002-s498><combine.sich_verbinden><de> Kunst und Geschichte verbinden sich in diesem ehemaligen Zuhause der Päpste, das heute ein bedeutendes Museum ist, das Tausende von Jahren der angewandten Kunst feiert.
<G-vec00623-002-s499><combine.sich_verbinden><en> The glass surfaces serve as projection surfaces reflecting this growth: In the artistic design individual circles combine playfully reflecting the activities of the growing group.
<G-vec00623-002-s499><combine.sich_verbinden><de> Die Glasflächen werden zu Projektionsflächen dieses Wachstums, denn in der künstlerischen Gestaltung verbinden sich einzelne farbige Kreise spielerisch zu einer wachsenden Gruppe.
<G-vec00623-002-s500><combine.sich_verbinden><en> Clear shapes and organically flowing elements combine the Keramag iCon bathroom series, an extensive interior design concept standing for individual room design due to its large variety of single components.
<G-vec00623-002-s500><combine.sich_verbinden><de> Klare Konturen und organisch fließende Elemente verbinden sich bei der Keramag iCon Badmöbel Serie, einem umfangreichen Raumgestaltungskonzept, welches mit seiner Vielzahl an einzelnen Komponenten für eine individuelle Raumgestaltung steht.
<G-vec00623-002-s501><combine.sich_verbinden><en> Ripe plum, cherry and blackberry aromas combine with liquorice, black pepper, cocoa, chestnuts, and graphite notes.
<G-vec00623-002-s501><combine.sich_verbinden><de> Die Aromen von Pflaumen, Kirschen und reifen Brombeeren verbinden sich mit Noten von Lakritze, schwarzem Pfeffer, Kakao, Kastanien und Grafit.
<G-vec00623-002-s502><combine.sich_verbinden><en> A TPU heel cage and forefoot panels combine with minimal loops in order to shape its unorthodox lacing system.
<G-vec00623-002-s502><combine.sich_verbinden><de> Ein TPU-Fersenkäfig und Vorfußeinsätze verbinden sich mit minimalen Schlaufen, um das unorthodoxe Schnürsystem zu formen.
<G-vec00623-002-s503><combine.sich_verbinden><en> Email Description Urban style and ethnic inspiration combine in the new City bag in Texture calfskin, a precious leather featuring a natural fine grain that enhances the military-inspired nuance.
<G-vec00623-002-s503><combine.sich_verbinden><de> Email Beschreibung Urbaner Stil und ethnische Inspiration verbinden sich in der neuen City-Tasche aus Texture-Kalbleder, einem kostbaren Material.
<G-vec00623-002-s504><combine.sich_verbinden><en> These particles combine with lighter quarks to form bound states, the "mesons".
<G-vec00623-002-s504><combine.sich_verbinden><de> Diese Teilchen verbinden sich mit anderen, leichteren Quarks zu gebundenen Zuständen, den "Mesonen".
<G-vec00623-002-s505><combine.sich_verbinden><en> These combine with ferricyanide ions into the complex salt known as Prussian blue, a dark blue pigment that is deposited onto the surface of the mesh as scaffold-like nanocubes.
<G-vec00623-002-s505><combine.sich_verbinden><de> Diese verbinden sich mit Eisen (III) -cyanidionen zu dem komplexen Salz, das als Preußischblau bekannt ist, einem dunkelblauen Pigment, das auf der Oberfläche des Netzes als gerüstartige Nanowürfel abgelagert wird.
<G-vec00623-002-s506><combine.sich_verbinden><en> Art and technology combine as ideas are turned into designs for print or the web.
<G-vec00623-002-s506><combine.sich_verbinden><de> Kunst und Technologie verbinden sich, wenn Ideen in Designs für Print oder Web umgesetzt werden.
<G-vec00623-002-s507><combine.sich_verbinden><en> Body, breath, feeling and thinking combine and strength, flexibility, stamina and coordination develop almost effortlessly.
<G-vec00623-002-s507><combine.sich_verbinden><de> Körper, Atem, Fühlen und Denken verbinden sich und Kraft, Flexibilität, Ausdauer und Koordination entwickeln sich beinahe mühelos.
<G-vec00623-002-s508><combine.sich_verbinden><en> Here technical excellence and quality combine to form this new aesthetic Matt Case
<G-vec00623-002-s508><combine.sich_verbinden><de> Hier verbinden sich technische Exzellenz und Qualität zu dieser neuen Ästhetik.
<G-vec00623-002-s509><combine.sich_verbinden><en> Its active hydrogen and hydroxyl groups combine with the sulfhydryl group in the urea structure near the metal nickel to oxidize the sulfhydryl group into a disulfide bridge (- SS-) reduces the activity of urease.
<G-vec00623-002-s509><combine.sich_verbinden><de> Seine aktiven Wasserstoff- und Hydroxylgruppen verbinden sich mit der Sulfhydrylgruppe in der Harnstoffstruktur in der Nähe des Metallnickels, um die Sulfhydrylgruppe zu einer Disulfidbrücke (- SS-) zu oxidieren, die die Urease-Aktivität verringert.
<G-vec00623-002-s510><combine.sich_verbinden><en> Nose: Tempting sherry-sweet malty tones combine with delicate smokiness, releasing subtle spices.
<G-vec00623-002-s510><combine.sich_verbinden><de> Nase: Verführerische Sherry-Süße mit malzigen Tönen verbinden sich mit zartem Rauch und Würze.
<G-vec00623-002-s512><combine.sich_verbinden><en> Thus, the suspense the music produces is already evident: ancient Nordic wind instruments meet customary Swiss alphorns barely two centuries old and combine with the still comparatively youthful saxophone to create a musical uniformity of sound for which there is no comparison.
<G-vec00623-002-s512><combine.sich_verbinden><de> Damit zeigt sich schon der Spannungsbogen, den die Musik schlägt: Uralte nordische Blasinstrumente treffen auf kaum ein paar Jahrhunderte alte, in der Schweiz gebräuchliche Alphörner und verbinden sich mit dem vergleichsweise noch jugendlichen Saxophon zu einer musikalischen Klangeinheit, der es an Vergleichen fehlt.
<G-vec00623-002-s589><combine.sich_vereinen><en> Simplicity, elegance and sensuality combine in this sheath wedding dress.
<G-vec00623-002-s589><combine.sich_vereinen><de> Schlichtheit, Eleganz und Sinnlichkeit vereinen sich in diesem schmal geschnittenen Brautkleid.
<G-vec00623-002-s590><combine.sich_vereinen><en> $99.99 Contemporary design and relevant features combine to deliver a stylish laptop backpack perfect for work, school or travel.
<G-vec00623-002-s590><combine.sich_vereinen><de> Zeitgemäßes Design und wichtige Funktionen vereinen sich in einem eleganten Laptop-Rucksack, der optimal für die Arbeit, die Schule oder Reisen geeignet ist.
<G-vec00623-002-s591><combine.sich_vereinen><en> ZARGES products combine the multiple benefits of the light metal material aluminium such as high stability with low weight, corrosion resistance and flexibility of use.
<G-vec00623-002-s591><combine.sich_vereinen><de> In ZARGES-Produkten vereinen sich die vielfältigen Vorteile des Leichtmetall-Werkstoffs Aluminium wie hohe Stabilität bei geringem Gewicht, Korrosionsfestigkeit sowie Flexibilität im Einsatz.
<G-vec00623-002-s592><combine.sich_vereinen><en> Stop in a wild behind a wild during a falling wild respin and the wilds will combine and turn the reel completely wild for a single spin – covering it with 3 wild symbols.
<G-vec00623-002-s592><combine.sich_vereinen><de> Wenn du während der Fallende-Wild-Symbole-Respins ein Wild-Symbol hinter einem Wild-Symbol erhältst, vereinen sich die Wild-Symbole und verwandeln die Walze für einen einzigen Dreh in eine Wild-Walze – sie bedecken sie also mit 3 Wild-Symbolen.
<G-vec00623-002-s593><combine.sich_vereinen><en> Delicate floral chords and fresh head notes combine with a warm base to form a modern fragrance brimming with simple elegance.
<G-vec00623-002-s593><combine.sich_vereinen><de> Feminine Blumenakkorde und frische Kopfnoten vereinen sich mit einer warmen Basis zu einer modernen Duftkomposition voll schlichter Eleganz.
<G-vec00623-002-s595><combine.sich_vereinen><en> The treatments and programmes arranged by the spa establishment of Cervia combine with the mild climate and the numerous fun opportunities the area offers and contribute to regenerate both body and mind.
<G-vec00623-002-s595><combine.sich_vereinen><de> Kur und Vergnügen befinden sich auf diesem Gebiet des “Meeres und des Grüns” und vereinen sich mit dem Gesundheitsklima und den zahlreichen Vergnügungsangeboten für Touristen- ein Touch von Gesundheit für Körper und Geist.
<G-vec00623-002-s596><combine.sich_vereinen><en> Scan-Line 10 + 20 + 30 combine the traditional characteristics of the stove and the thermal mass stove.
<G-vec00623-002-s596><combine.sich_vereinen><de> Beim Scan-Line 10, 20 und 30 vereinen sich die Vorteile eines Kaminofens mit den traditionellen Eigenschaften eines gemauerten Ofens.
<G-vec00623-002-s597><combine.sich_vereinen><en> The lightness and strength of carbon fibre and aramid fibres combine with an attractive design and distinctive racing finishing in an accessory that offers maximum protection in the event of a slip and enhances the Panigale's sporty and elegant soul. Composition fibre rear mudguard
<G-vec00623-002-s597><combine.sich_vereinen><de> Die Leichtigkeit und Widerstandsfähigkeit der Kohlefaser und Aramidfasern vereinen sich mit einem ansprechenden Design und dem typischem Racing-Finish, in einem Zubehörteil, das maximalen Schutz im Falle des Abrutschens bietet sowie die sportliche und elegante Seele der Panigale betont.
<G-vec00623-002-s598><combine.sich_vereinen><en> In our sweet factory we combine experience with science and technology to the high art of confectionary production.
<G-vec00623-002-s598><combine.sich_vereinen><de> In unserer Konfekt-Manufaktur vereinen sich Liebe zur Sache und langjährige Erfahrung mit Wissenschaft und Technik zur hohen Kunst der Pralinen-Erzeugung.
<G-vec00623-002-s599><combine.sich_vereinen><en> Lisbon's sophisticated shopping centres (considered as one of the best cities in Europe for shopping), luxury hotels and fine accommodation, including apartments, hostels, pousadas and villas, gastronomy and culture combine with the climate to make this a great destination, 12 months of the year.
<G-vec00623-002-s599><combine.sich_vereinen><de> Die anspruchsvollen Einkaufszentren, die Lissabon zu einer der besten Einkaufsadressen Europas machen, die excellenten Luxus-Hotels und Unterkünfte wie Apartments, Hostels, Herrenhäuser, Schlösser und Villen, sowie die Gastronomie und Kultur vereinen sich mit dem angenehmen Klima und machen Lissabon zu einem der besten Reiseziele 12 Monate im Jahr.
<G-vec00623-002-s600><combine.sich_vereinen><en> The delicious "dessert" notes of Girl Scout Cookies and Do-Si-Dos combine to create an unprecedented flavour experience reminiscent of freshly baked biscuits.
<G-vec00623-002-s600><combine.sich_vereinen><de> Die köstlichen "Dessert"-Noten von Girl Scout Cookies und Do-Si-Dos vereinen sich in einem beispiellosen Geschmackserlebnis, das an frisch gebackene Kekse erinnert.
<G-vec00623-002-s601><combine.sich_vereinen><en> The most demanding requirements in terms of design and quality combine with the demand to bring the world closer to the wearer.
<G-vec00623-002-s601><combine.sich_vereinen><de> Höchste Anforderungen an Design und Qualität vereinen sich mit dem Anspruch, der Lebenswelt der Träger nahe zu sein.
<G-vec00623-002-s602><combine.sich_vereinen><en> Beauty, light riding and character combine in this athlete.
<G-vec00623-002-s602><combine.sich_vereinen><de> Schönheit, Leichtrittigkeit und Charakter vereinen sich in diesem Sportler.
<G-vec00623-002-s603><combine.sich_vereinen><en> They combine German engineering and business know-how to create a powerful strategy.
<G-vec00623-002-s603><combine.sich_vereinen><de> So vereinen sich deutsche Ingenieurskunst und wirtschaftswissenschaftliches Know-How zu einer schlagkräftigen Strategie.
<G-vec00623-002-s604><combine.sich_vereinen><en> In it combine aerodynamic shape and high mechanical strength by Swiss precision.
<G-vec00623-002-s604><combine.sich_vereinen><de> In ihr vereinen sich Aerodynamische Form und hohe mechanische Belastbarkeit durch Schweizer Präzision.
<G-vec00623-002-s605><combine.sich_vereinen><en> Warm, dark vocals combine with insanely catchy synth sounds to form a fervent album of electronic music.
<G-vec00623-002-s605><combine.sich_vereinen><de> Warme, dunkle Vocals vereinen sich mit Ohrwurmverdächtigen Synthiesounds zu einem leidenschaftlichen Album elektronischer Musik.
<G-vec00623-002-s607><combine.sich_vereinen><en> The unfailing passion and enduring emotion combine to create watches of timeless nature, much like the classic cars that they honor.
<G-vec00623-002-s607><combine.sich_vereinen><de> Die unerschöpfliche Leidenschaft und lang währende Emotion vereinen sich in der Kreation von Uhren mit zeitlosem Charakter, wie bei den klassischen Rennwagen, denen sie Tribut zollen.
<G-vec00623-002-s380><combine.verbinden><en> This professional outing will allow you to better combine your work and personal life.
<G-vec00623-002-s380><combine.verbinden><de> Mit diesem professionellen Ausflug können Sie Ihre Arbeit und Ihr persönliches Leben besser miteinander verbinden.
<G-vec00623-002-s381><combine.verbinden><en> Our aim is to combine innovation and competitiveness.
<G-vec00623-002-s381><combine.verbinden><de> Unser Anspruch ist es, Innovation und Wettbewerbsfähigkeit miteinander zu verbinden.
<G-vec00623-002-s382><combine.verbinden><en> Hotel Overview Located in the very heart of the airport, the Best Western Marseille Aeroport is the preferred place to combine business and leisure.
<G-vec00623-002-s382><combine.verbinden><de> Dank seiner Lage im Herzen des Flughafens wird dieses Best Western Marseille Aeroport Hotel gern gewählt, um Geschäft und Freizeit miteinander zu verbinden.
<G-vec00623-002-s383><combine.verbinden><en> Seminar hotel in The Saas Valley To combine work and relaxation, must not be nice illusion.
<G-vec00623-002-s383><combine.verbinden><de> Romantischer Urlaub in Österreich und Entspannung miteinander zu verbinden, muss keine schöne Illusion sein.
<G-vec00623-002-s384><combine.verbinden><en> In the light of this capital truth of faith and of reason at the same time, it was once again possible, in 2000, to combine faith and knowledge.
<G-vec00623-002-s384><combine.verbinden><de> Im Licht dieser grundlegenden Wahrheit des Glaubens und zugleich der Vernunft ist es im dritten Jahrtausend wieder möglich, Glaube und Wissenschaft miteinander zu verbinden.
<G-vec00623-002-s385><combine.verbinden><en> Women should be motivated to combine a family with a job.
<G-vec00623-002-s385><combine.verbinden><de> Frauen sollen motiviert werden, Familie und Beruf miteinander zu verbinden.
<G-vec00623-002-s386><combine.verbinden><en> The store includes solutions that combine outstanding efficiency with product enhancement and improved food safety.
<G-vec00623-002-s386><combine.verbinden><de> Der Markt wurde vor kurzem eröffnet und mit Lösungen ausgestattet, die exzellente Effizienz, Produktaufwertung und optimale Food Safety miteinander verbinden.
<G-vec00623-002-s387><combine.verbinden><en> The Park, with its thermal swimming pools, is the environment in which relaxation, nature and comfort combine to give you exactly what you expect from your holiday.
<G-vec00623-002-s387><combine.verbinden><de> Der Park, mit seinen Thermalbädern, ist die geeignete Umgebung in der sich Relax, Natur und Wohlbefinden miteinander verbinden um Ihnen genau dies zu schenken was Sie sich von Ihrem Urlaub erwarten.
<G-vec00623-002-s388><combine.verbinden><en> On snowy winter days, you can explore Salzburg in peace and harmoniously combine culture and nature.
<G-vec00623-002-s388><combine.verbinden><de> An verschneiten Wintertagen kann man Salzburg in Ruhe erkunden und Kultur und Natur harmonisch miteinander verbinden.
<G-vec00623-002-s389><combine.verbinden><en> Other accessories than half sidewalls are roof covers, Safety Packs, ground bars, flooring, curtains, overhang, weight discs, sandbags, rain gutters, and connectors if you want to combine two or more gazebos.
<G-vec00623-002-s389><combine.verbinden><de> Andere Zubehörartikel neben der halben Seitenwände sind Dachplanen, Sicherheitspakete, Bodenleisten, Böden, Vorhänge, Überhänge, Gewichte, Sandtaschen, Regenrinnen und Konnektoren, falls Sie zwei oder mehrere Zelte miteinander verbinden möchten.
<G-vec00623-002-s390><combine.verbinden><en> The prize is awarded annually to projects that combine research findings with commercial applications.
<G-vec00623-002-s390><combine.verbinden><de> Der Preis wird jährlich an Projekte verliehen, die Forschungsergebnisse und kommerzielle Anwendung miteinander verbinden.
<G-vec00623-002-s391><combine.verbinden><en> This already illustrated a distinctive feature of video art, namely the ability to combine real areas of space, temporal sequences and constructed realities.
<G-vec00623-002-s391><combine.verbinden><de> Schon hier zeigt sich die Besonderheit der Videokunst, reale Räume, zeitliche Abläufe und konstruierte Wirklichkeiten miteinander zu verbinden.
<G-vec00623-002-s392><combine.verbinden><en> Would you like to combine two or more canopy tents to a cluster, our joining element is the ideal tool.
<G-vec00623-002-s392><combine.verbinden><de> Möchten Sie zwei oder mehrere Faltpavillons miteinander verbinden, dann ist unsere Verbindungsklemme ideal für Sie.
<G-vec00623-002-s393><combine.verbinden><en> Our new rubric "translational case examples" shows how we combine basic research and clinical questions and what drives our science.
<G-vec00623-002-s393><combine.verbinden><de> Unsere neue Rubrik "Translationale Fallbeispiele" zeigen Ihnen, wie wir Grundlagenwissenschaften und Klinik miteinander verbinden und was unsere Wissenschaft antreibt.
<G-vec00623-002-s394><combine.verbinden><en> It is also not permissible to combine separate items belonging to different embodiments described in one and the same document, unless such combination has specifically been suggested (see T 305/87).
<G-vec00623-002-s394><combine.verbinden><de> Ebenso wenig ist es zulässig, verschiedene Bestandteile unterschiedlicher Ausführungsformen, die in ein und demselben Dokument beschrieben sind, miteinander zu verbinden, sofern nicht im Dokument selbst eine solche Verbindung nahegelegt wird (siehe T 305/87).
<G-vec00623-002-s395><combine.verbinden><en> The aim is to combine tradition and modernity, while preserving the special family character of the house, in order to continue writing history.
<G-vec00623-002-s395><combine.verbinden><de> Ziel ist es Tradition und Modernität miteinander zu verbinden, und dabei den besonderen, von der Familie geprägten Charakter des Hauses zu bewahren um weiterhin Geschichte zu schreiben.
<G-vec00623-002-s396><combine.verbinden><en> Suitable for quick Ø60 standard pole installation, it also has a double light angle (360°, 180°) to satisfy every lighting project that wishes to combine aesthetics and functionality.
<G-vec00623-002-s396><combine.verbinden><de> SOC wurde für die schnelle Montage an Ø60 Standardmasten entworfen und verfügt über einen doppelten Beleuchtungswinkel (360°, 180°), um jedes Lichtprojekt zu befriedigen, das Ästhetik und Funktionalität miteinander verbinden möchte.
<G-vec00623-002-s397><combine.verbinden><en> This way, I can combine my great passion for music and art!
<G-vec00623-002-s397><combine.verbinden><de> So kann ich meine zweigroßen Leidenschaften für Musik und Kunst miteinander verbinden.
<G-vec00623-002-s398><combine.verbinden><en> It is the ideal place to combine health, wellbeing and relaxation, while also enjoying the food and wine in our restaurant.
<G-vec00623-002-s398><combine.verbinden><de> Die richtige Wahl, um Gesundheit, Wellness, Entspannung sowie Wein- und Gaumenfreuden in unserem Restaurant miteinander zu verbinden.
<G-vec00623-002-s456><combine.verbinden><en> Combine at least 3 bubbles of the same color to remove them from the playing field.
<G-vec00623-002-s456><combine.verbinden><de> Verbinde mindestens 3 Bubbles derselben Farbe, um sie vom Feld zu entfernen.
<G-vec00623-002-s458><combine.verbinden><en> Combine your passion for animals and giving back to society by improving the ever-present problem of stray animals on the streets of Santiago.
<G-vec00623-002-s458><combine.verbinden><de> Verbinde deine Leidenschaft für Tiere mit einer guten Tat, indem du zur Verbesserung der Leidenssituation von Strassenhunden und -katzen in Santiago beiträgst und streunenden Tieren ein neues Zuhause suchst.
<G-vec00623-002-s459><combine.verbinden><en> Approach I combine profound IT skills and knowledge about information management in the business organisation with long term experience in the telco sector and particularly in the area of services.
<G-vec00623-002-s459><combine.verbinden><de> Beratungsansatz Ich verbinde fundierte IT-Kenntnisse und Wissen über das Informationsmanagement in der Organisation mit umfangreicher Erfahrung im Telekommunikations- und insbesondere im Servicebereich.
<G-vec00623-002-s460><combine.verbinden><en> As a rule, I combine comments with an "appreciation" at the same time.
<G-vec00623-002-s460><combine.verbinden><de> In der Regel verbinde ich einen Kommentar deshalb auch zugleich mit einem "Lob".
<G-vec00623-002-s461><combine.verbinden><en> I combine original game mechanics with beautiful graphics and intuitive controls.
<G-vec00623-002-s461><combine.verbinden><de> Ich verbinde originelle Spielideen mit ansprechender Grafik und eingängigen Bedienkonzepten.
<G-vec00623-002-s462><combine.verbinden><en> Take a few of the most beautiful lakes in Austria, combine them with the soft hills of the Salzburg Alpine foothills and fine tune all this with an imposing view of one of the highest mountains of the Central Alps.
<G-vec00623-002-s462><combine.verbinden><de> Man nehme einige der schönsten Seen Österreichs, verbinde sie mit den sanften Hügeln des Salzburger Alpenvorlandes und verfeinere sie mit einem imposanten Blick auf die höchsten Gipfel der Zentralalpen.
<G-vec00623-002-s463><combine.verbinden><en> Combine letters in a layer to form a word.
<G-vec00623-002-s463><combine.verbinden><de> Verbinde Buchstaben in einer Ebene um ein Wort zu formen .
<G-vec00623-002-s464><combine.verbinden><en> Today, I combine my multi-faceted trainer/coach know-how together with my diverse experience as a manager in a food company where hierarchy plays an important role.
<G-vec00623-002-s464><combine.verbinden><de> Heute verbinde ich mein inzwischen sehr umfangreiches Trainer/Coach-Know How mit meiner mannigfaltigen Erfahrung als Managerin in Unternehmen mit flachen Hierarchien in der Lebensmittel-Branche.
<G-vec00623-002-s465><combine.verbinden><en> I combine this interest in biological mechanisms with an interest in new technologies and methods, in the hope of developing a new generation of optical microscopy devices.
<G-vec00623-002-s465><combine.verbinden><de> Ich verbinde mein Interesse an biologischen Mechanismen mit dem Interesse an neuen Technologien und Methoden, um eine neue Gerätegeneration in der Lichtmikroskopie zu entwickeln.
<G-vec00623-002-s466><combine.verbinden><en> Help Anna and Elsa and combine at least 3 bubbles of the same color in this magical bubble shooter game.
<G-vec00623-002-s466><combine.verbinden><de> Hilf Anna und Elsa und verbinde in diesem zauberhaften Bubble Shooter mindestens 3 gleiche Bläschen.
<G-vec00623-002-s467><combine.verbinden><en> I combine this know-how with extensive experience in the European and Austrian Research, Technology and Innovation (promotion) system: I worked in the European Commission, in the Austrian Ministry of Science and Research and in the Austrian Research Promotion Agency (FFG) in programme management and Human Resources.
<G-vec00623-002-s467><combine.verbinden><de> Dieses Know-how verbinde ich mit umfangreicher Erfahrung in der europäischen und österreichischen Forschungs-, Technologie- und Innovationsförderung (FTI-Förderung): Ich war in der EU-Kommission, im österreichischen Wissenschaftsministerium und in der österreichischen Forschungsförderungsgesellschaft (FFG) in der Förderungsabwicklung und im Programm-Management tätig.
<G-vec00623-002-s468><combine.verbinden><en> I've got a few of them and apply them individually, or combine them to create the finest blends to treat my body, face, hair and nails.
<G-vec00623-002-s468><combine.verbinden><de> Ich habe ein paar Öle und verwende sie getrennt oder verbinde, um wunderbare Mischungen für Körper, Gesicht, Haare und Nägel zu bekommen.
<G-vec00623-002-s469><combine.verbinden><en> Experience the taste of energy in concentrated form and combine passion with pleasure.
<G-vec00623-002-s469><combine.verbinden><de> Erlebe den Geschmack der Energie in konzentrierter Form und verbinde Leidenschaft mit Genuss.
<G-vec00623-002-s470><combine.verbinden><en> Ocean guardians - travel across underwater world, get treasures, fight against underwater villains, combine identical objects on the playing field.
<G-vec00623-002-s470><combine.verbinden><de> Reise in Ocean Guardians durch eine Unterwasserwelt, sammle Schätze, bekämpfe Bösewichte unter Wasser und verbinde identische Gegenstände auf dem Spielfeld.
<G-vec00623-002-s471><combine.verbinden><en> I combine methods to translate human needs and realities into concepts with a deep understanding of interactive technologies’ logic, possibilities and shortcomings.
<G-vec00623-002-s471><combine.verbinden><de> Ich verbinde Methoden die menschliche Bedürfnisse und Lebenswelten in Konzepte übersetzen mit einem tiefgehenden Verständnis für die Logik, Möglichkeiten, aber auch Unzulänglichkeiten interaktiver Technologien.
<G-vec00623-002-s472><combine.verbinden><en> In the case of the photo drawings, I combine two media to create one.
<G-vec00623-002-s472><combine.verbinden><de> Bei den Photozeichnungen verbinde ich zwei Medien zu einem.
<G-vec00623-002-s473><combine.verbinden><en> Lioba Visser: Since our course (Business Management) has a mandatory practical semester, I thought that I would combine the necessary with the interesting and go abroad.
<G-vec00623-002-s473><combine.verbinden><de> Lioba Visser: Da in unserem Studiengang (Betriebswirtschaft) ein Praxissemester obligatorisch ist, dachte ich mir, ich verbinde das Notwendige mit dem Interessanten und gehe ins Ausland.
<G-vec00623-002-s474><combine.verbinden><en> In my work, I combine Asian techniques and the structural approach of Western knowledge.
<G-vec00623-002-s474><combine.verbinden><de> Hierbei verbinde ich asiatische Techniken mit strukturiertem westlichen Wissen.
<G-vec00623-002-s475><combine.verbinden><en> The restoration process took around five years, our main concern at all times being to maintain the authentic feel of the houses and combine it with modern comforts.
<G-vec00623-002-s475><combine.verbinden><de> Das Verfahren der Wiedererrichtung dauerte ungefähr 5 Jahre und während dieser Zeit war unsere Hauptaufgabe den Originalcharakter der Häuser zu erhalten und mit modernen Bequemlichkeiten zu verbinden.
<G-vec00623-002-s476><combine.verbinden><en> Mexico's major cities combine modernity with characteristics from the times of the Maya and Aztecs.
<G-vec00623-002-s476><combine.verbinden><de> Mexikos Großstädte verbinden die Moderne mit Charakteristika aus den Zeiten der Maya und Azteken.
<G-vec00623-002-s478><combine.verbinden><en> His works, almost invariably conceived as series, combine elements of reportage with lyrical subjectivity and a symbolic aesthetic which seems almost calligraphic in its harsh contrasts between black and white.
<G-vec00623-002-s478><combine.verbinden><de> Seine nahezu ausnahmslos in Serien konzipierten Arbeiten verbinden Elemente der Reportage mit lyrischer Subjektivität und einer zeichenhaften, in ihren harten Schwarzweiß-Kontrasten fast kalligrafischen Ästhetik.
<G-vec00623-002-s479><combine.verbinden><en> As a long-standing company, we combine our many years of experience and proven products of modern manufacturing to one competitive unit: Our expertise for your success.
<G-vec00623-002-s479><combine.verbinden><de> Als Traditionsunternehmen verbinden wir unsere langjährige Erfahrung und bewährte Produkte modernster Fertigungstechnik zu einer wettbewerbsstarken Einheit: Unsere Kompetenz für Ihren Erfolg.
<G-vec00623-002-s480><combine.verbinden><en> Explore exciting historical trails that combine impressive natural and cultural landscapes with regional history and specialties in the most beautiful regions of Switzerland.
<G-vec00623-002-s480><combine.verbinden><de> Lernen Sie eindrückliche historische Wege kennen, welche attraktive Natur- und Kulturlandschaften mit regionaler Geschichte und Spezialitäten in den schönsten Regionen der Schweiz verbinden.
<G-vec00623-002-s481><combine.verbinden><en> The design of the label, born from the decide to combine artistic creativity and territorial identity, is a tribute to the Trentino painter Fortunato Depero, a key proponent of the Second Futurism artistic movement.
<G-vec00623-002-s481><combine.verbinden><de> Das Label ist eine Hommage an Fortunato Depero, den berühmten Trentiner Maler des zweiten Futurismus, und entstand aus dem Wunsch heraus, künstlerische Kreativität und territoriale Identität zu verbinden.
<G-vec00623-002-s482><combine.verbinden><en> All our hotels, residences and resorts combine pleasure with hospitality in a refined atmosphere where our visitors’ well-being is the only thing that matters.
<G-vec00623-002-s482><combine.verbinden><de> Alle unsere Hotels, Residences und Resorts verbinden in einer besonderen Atmosphäre Vergnügen mit Gastfreundlichkeit, bei der das Wohlbefinden unserer Gäste für uns immer an erster Stelle steht.
<G-vec00623-002-s483><combine.verbinden><en> Stefan Diez, a former student of Grcic, also likes to focus on the essential in his creations: The name "THIS THAT OTHER" (after a famous card trick) refers to a chair, small armchair and a stool, which combine round shapes with a modern, youthful spirit and rational details.
<G-vec00623-002-s483><combine.verbinden><de> Auch Stefan Diez, einst Schüler Grcics, betont in seinen Entwürfen gerne das Essenzielle: Hinter dem Namen "THIS THAT OTHER" (benannt nach einem berühmten Kartentrick) verbergen sich ein Stuhl, ein kleiner Sessel und ein Hocker, die runde Formen mit modernem, jugendlichem Zeitgeist und rationalen Details verbinden.
<G-vec00623-002-s484><combine.verbinden><en> It has a relaxation area where you can combine work and pleasure or simply enjoy a chilling moment.
<G-vec00623-002-s484><combine.verbinden><de> Sie haben ein Entspannungsbereich, in dem Sie Arbeit oder Vergnügen verbinden oder einfach einen Moment der Ruhe genießen können.
<G-vec00623-002-s485><combine.verbinden><en> In this framework too, Autoclima has been able to combine the project capability and the production flexibility for offering to the Customers both combinations: customized and specific systems and products derived from the universal components Catalogue.
<G-vec00623-002-s485><combine.verbinden><de> Auch in diesem Bereich ist es Autoclima gelungen, die Projekt Fähigkeiten und die Flexibilität in der Produktion, für das Angebot beider Kombinationen für die Kunden zu verbinden: Maßgeschneiderte und spezifische Systeme und Produkte, die aus dem universellen Komponenten Katalog abgeleitet sind.
<G-vec00623-002-s486><combine.verbinden><en> Lidzbark Warminski Poland, For those who prefer to combine leisure with work, the KRASICKI Hotel has prepared a wide range of conference services.
<G-vec00623-002-s486><combine.verbinden><de> Für diejenigen, die Entspannung mit Arbeit verbinden möchten, hat Hotel Krasicki ein umfangreiches Angebot zu Konferenzdienstleistungen vorbereitet.
<G-vec00623-002-s487><combine.verbinden><en> Panorama-Alm The Panorama-Alm holiday huts in Sölden in the Ötz Valley combine modern comfort with Tyrolean mountain style and a unique panoramic view.
<G-vec00623-002-s487><combine.verbinden><de> Die Ferienhütten der Panorama-Alm in Sölden im Ötztal verbinden modernen Komfort mit Tiroler Almstil und einem einmaligen Panoramablick.
<G-vec00623-002-s488><combine.verbinden><en> Perfectly combine can be in South Africa hunting, family and culture.
<G-vec00623-002-s488><combine.verbinden><de> Perfekt verbinden lassen sich in Südafrika Jagd, Familie und Kultur.
<G-vec00623-002-s489><combine.verbinden><en> Our spas combine the most advanced spa technology with world-class construction techniques to ensure your enjoyment for years to come.
<G-vec00623-002-s489><combine.verbinden><de> Unsere Whirlpools verbinden die fortschrittlichste Whirlpooltechnologie mit erstklassigen Herstellungstechniken für ein jahrelanges Vergnügen an unseren Whirlpools.
<G-vec00623-002-s490><combine.verbinden><en> We combine the memory of the ideas of Rosa Luxemburg and Karl Liebknecht with the demands in the struggles of our time: We demonstrate for peace and international solidarity, against exploitation, against the dismantling of democratic rights and the increase of fascist dangers.
<G-vec00623-002-s490><combine.verbinden><de> Wir verbinden das Gedenken an die Ideen von Rosa Luxemburg und Karl Liebknecht mit den Forderungen in den Kämpfen unserer Zeit: Wir demonstrieren für Frieden und internationale Solidarität, gegen Ausbeutung, gegen den Abbau demokratischer Rechte und das Anwachsen faschistischer Gefahren.
<G-vec00623-002-s491><combine.verbinden><en> The mobile construction cranes in the MK series combine the mobility of a classic mobile crane with the functional benefits of a tower crane.
<G-vec00623-002-s491><combine.verbinden><de> Mobilbaukrane der Baureihe MK verbinden die Mobilität eines klassischen Fahrzeugkrans mit den funktionalen Vorteilen eines Turmdrehkrans.
<G-vec00623-002-s492><combine.verbinden><en> We combine an in-depth knowledge of Malaysia’s multicultural and growing market with years of communications expertise across many industries.
<G-vec00623-002-s492><combine.verbinden><de> Wir verbinden fundierte Kenntnisse des größten Marktes in Europa mit langjähriger Erfahrung in vielen Kommunikationsdisziplinen und für zahlreiche Branchen.
<G-vec00623-002-s493><combine.verbinden><en> This model is the answer to how to combine classics with modern.
<G-vec00623-002-s493><combine.verbinden><de> Dieses Modell ist die Antwort auf die Frage, wie sich Klassik und Moderne verbinden.
<G-vec00623-002-s494><combine.verbinden><en> The robust nature of ceramic rolling elements can be seen clearly from the example of a spindle bearing: the new high performance spindle bearing series RS and the thermally robust cylindrical bearing TR combine very high speed capability with high load carrying capacity and resistance under a wide variety of operating conditions.
<G-vec00623-002-s494><combine.verbinden><de> Wie robust die Keramik-Wälzkörper sind, wird am Beispiel des Spindellagers deutlich: Mit der neuen Hochleistungs-Spindellagerbaureihe RS und dem thermisch robusten Zylinderrollenlager TR verbinden sich höchste Drehzahleignung mit hoher Belastbarkeit und Unempfindlichkeit bei unterschiedlichsten Betriebsbedingungen.
<G-vec00623-002-s495><combine.verbinden><en> ...combine in Eichstätt.
<G-vec00623-002-s495><combine.verbinden><de> ...verbinden sich in Eichstätt zu einer Einheit.
<G-vec00623-002-s496><combine.verbinden><en> The sensors combine chemically with the component surfaces,” according to Dipl.-Ing.me.
<G-vec00623-002-s496><combine.verbinden><de> Die Sensoren verbinden sich chemisch mit den Bauteiloberflächen“, sagt Dipl.-Ing.me.
<G-vec00623-002-s497><combine.verbinden><en> Space, warm light, superior design and amazing views combine to an impressive real estate here.
<G-vec00623-002-s497><combine.verbinden><de> Geräumigkeit, warmes Licht, hochwertiges Design und atemberaubende Aussicht verbinden sich hier zu einer beeindruckenden Immobilie.
<G-vec00623-002-s498><combine.verbinden><en> Art and history combine in this former home of the popes – now a major museum celebrating thousands of years of the applied arts.
<G-vec00623-002-s498><combine.verbinden><de> Kunst und Geschichte verbinden sich in diesem ehemaligen Zuhause der Päpste, das heute ein bedeutendes Museum ist, das Tausende von Jahren der angewandten Kunst feiert.
<G-vec00623-002-s499><combine.verbinden><en> The glass surfaces serve as projection surfaces reflecting this growth: In the artistic design individual circles combine playfully reflecting the activities of the growing group.
<G-vec00623-002-s499><combine.verbinden><de> Die Glasflächen werden zu Projektionsflächen dieses Wachstums, denn in der künstlerischen Gestaltung verbinden sich einzelne farbige Kreise spielerisch zu einer wachsenden Gruppe.
<G-vec00623-002-s500><combine.verbinden><en> Clear shapes and organically flowing elements combine the Keramag iCon bathroom series, an extensive interior design concept standing for individual room design due to its large variety of single components.
<G-vec00623-002-s500><combine.verbinden><de> Klare Konturen und organisch fließende Elemente verbinden sich bei der Keramag iCon Badmöbel Serie, einem umfangreichen Raumgestaltungskonzept, welches mit seiner Vielzahl an einzelnen Komponenten für eine individuelle Raumgestaltung steht.
<G-vec00623-002-s501><combine.verbinden><en> Ripe plum, cherry and blackberry aromas combine with liquorice, black pepper, cocoa, chestnuts, and graphite notes.
<G-vec00623-002-s501><combine.verbinden><de> Die Aromen von Pflaumen, Kirschen und reifen Brombeeren verbinden sich mit Noten von Lakritze, schwarzem Pfeffer, Kakao, Kastanien und Grafit.
<G-vec00623-002-s502><combine.verbinden><en> A TPU heel cage and forefoot panels combine with minimal loops in order to shape its unorthodox lacing system.
<G-vec00623-002-s502><combine.verbinden><de> Ein TPU-Fersenkäfig und Vorfußeinsätze verbinden sich mit minimalen Schlaufen, um das unorthodoxe Schnürsystem zu formen.
<G-vec00623-002-s503><combine.verbinden><en> Email Description Urban style and ethnic inspiration combine in the new City bag in Texture calfskin, a precious leather featuring a natural fine grain that enhances the military-inspired nuance.
<G-vec00623-002-s503><combine.verbinden><de> Email Beschreibung Urbaner Stil und ethnische Inspiration verbinden sich in der neuen City-Tasche aus Texture-Kalbleder, einem kostbaren Material.
<G-vec00623-002-s504><combine.verbinden><en> These particles combine with lighter quarks to form bound states, the "mesons".
<G-vec00623-002-s504><combine.verbinden><de> Diese Teilchen verbinden sich mit anderen, leichteren Quarks zu gebundenen Zuständen, den "Mesonen".
<G-vec00623-002-s505><combine.verbinden><en> These combine with ferricyanide ions into the complex salt known as Prussian blue, a dark blue pigment that is deposited onto the surface of the mesh as scaffold-like nanocubes.
<G-vec00623-002-s505><combine.verbinden><de> Diese verbinden sich mit Eisen (III) -cyanidionen zu dem komplexen Salz, das als Preußischblau bekannt ist, einem dunkelblauen Pigment, das auf der Oberfläche des Netzes als gerüstartige Nanowürfel abgelagert wird.
<G-vec00623-002-s506><combine.verbinden><en> Art and technology combine as ideas are turned into designs for print or the web.
<G-vec00623-002-s506><combine.verbinden><de> Kunst und Technologie verbinden sich, wenn Ideen in Designs für Print oder Web umgesetzt werden.
<G-vec00623-002-s507><combine.verbinden><en> Body, breath, feeling and thinking combine and strength, flexibility, stamina and coordination develop almost effortlessly.
<G-vec00623-002-s507><combine.verbinden><de> Körper, Atem, Fühlen und Denken verbinden sich und Kraft, Flexibilität, Ausdauer und Koordination entwickeln sich beinahe mühelos.
<G-vec00623-002-s508><combine.verbinden><en> Here technical excellence and quality combine to form this new aesthetic Matt Case
<G-vec00623-002-s508><combine.verbinden><de> Hier verbinden sich technische Exzellenz und Qualität zu dieser neuen Ästhetik.
<G-vec00623-002-s509><combine.verbinden><en> Its active hydrogen and hydroxyl groups combine with the sulfhydryl group in the urea structure near the metal nickel to oxidize the sulfhydryl group into a disulfide bridge (- SS-) reduces the activity of urease.
<G-vec00623-002-s509><combine.verbinden><de> Seine aktiven Wasserstoff- und Hydroxylgruppen verbinden sich mit der Sulfhydrylgruppe in der Harnstoffstruktur in der Nähe des Metallnickels, um die Sulfhydrylgruppe zu einer Disulfidbrücke (- SS-) zu oxidieren, die die Urease-Aktivität verringert.
<G-vec00623-002-s510><combine.verbinden><en> Nose: Tempting sherry-sweet malty tones combine with delicate smokiness, releasing subtle spices.
<G-vec00623-002-s510><combine.verbinden><de> Nase: Verführerische Sherry-Süße mit malzigen Tönen verbinden sich mit zartem Rauch und Würze.
<G-vec00623-002-s512><combine.verbinden><en> Thus, the suspense the music produces is already evident: ancient Nordic wind instruments meet customary Swiss alphorns barely two centuries old and combine with the still comparatively youthful saxophone to create a musical uniformity of sound for which there is no comparison.
<G-vec00623-002-s512><combine.verbinden><de> Damit zeigt sich schon der Spannungsbogen, den die Musik schlägt: Uralte nordische Blasinstrumente treffen auf kaum ein paar Jahrhunderte alte, in der Schweiz gebräuchliche Alphörner und verbinden sich mit dem vergleichsweise noch jugendlichen Saxophon zu einer musikalischen Klangeinheit, der es an Vergleichen fehlt.
<G-vec00623-002-s513><combine.verbinden><en> Combine sport offers with your destination city as conveniently, independently and...
<G-vec00623-002-s513><combine.verbinden><de> Verbinden Sie bequem Sport mit Ihrer Zielstadt,...
<G-vec00623-002-s514><combine.verbinden><en> Combine innovative forms of presentation, collaboration and management in one single, uniquely intuitive user interface.
<G-vec00623-002-s514><combine.verbinden><de> Verbinden Sie innovative Präsentationsformen, Kollaboration und Management in einer einzigartig intuitiven Anwendung.
<G-vec00623-002-s515><combine.verbinden><en> 1 Review Combine stops at two of Jamaica's top natural attractions—Dunn's River Falls and the Blue Hole—in a single tour from Ocho Rios.
<G-vec00623-002-s515><combine.verbinden><de> Verbinden Sie den Besuch zu zwei beliebten Naturattraktionen Jamaikas – Blue Hole und Dunn's River Falls – auf einer einzigen Tour ab Ocho Rios.
<G-vec00623-002-s516><combine.verbinden><en> They produce high-quality buildings that combine tradition with modernism, sustainability and a striking aesthetic. Technical specifications
<G-vec00623-002-s516><combine.verbinden><de> Mit hohen Ansprüchen verbinden sie Tradition mit Moderne, Nachhaltigkeit mit Ästhetik, Architekturtheorie mit Baupraxis.
<G-vec00623-002-s517><combine.verbinden><en> Combine the New Year's day concert of the Salon Orchestra Alt-Wien with a four-course dinner at the Restaurant Johann.
<G-vec00623-002-s517><combine.verbinden><de> Verbinden Sie das Neujahrskonzert des Salonorchesters Alt-Wien mit einem viergängigen Dinner im Restaurant Johann.
<G-vec00623-002-s518><combine.verbinden><en> Let yourself be inspired by Palladium - combine practical benefits with attractive design in a storage solution.
<G-vec00623-002-s518><combine.verbinden><de> Lassen sie sich von dem Gerätehaus Palladium begeistern - verbinden sie praktischen Nutzen mit ansprechendem Design in einer Aufbewahrungslösung.
<G-vec00623-002-s519><combine.verbinden><en> It is the perfect way to combine work and pleasure in an effective and exciting manner – as either a one-day experience, or participating in a several day programme with overnight accommodation directly on site.
<G-vec00623-002-s519><combine.verbinden><de> So verbinden Sie Arbeit und Vergnügen auf wirkungsvolle und spannende Weise – entweder als Tagesangebot oder als mehrtägiges Programm mit Übernachtung direkt vor Ort.
<G-vec00623-002-s520><combine.verbinden><en> Combine a city break in Los Angeles with a relaxing stay in the desert oasis of Palm Springs.
<G-vec00623-002-s520><combine.verbinden><de> Verbinden Sie einen Besuch von Los Angeles mit einem entspannenden Aufenthalt in der Wüstenoase von Palm Springs.
<G-vec00623-002-s521><combine.verbinden><en> Combine relaxation, culture and outdoor activities with an hotel deal.
<G-vec00623-002-s521><combine.verbinden><de> Verbinden Sie Entspannung, Kultur und Outdoor-Aktivitäten mit einem Hotelangebot von uns.
<G-vec00623-002-s522><combine.verbinden><en> So grab your family and combine tobogganing excitement with a short alpine hike, a fun stop at an alpine hut and finally the run down into the valley.
<G-vec00623-002-s522><combine.verbinden><de> Schnappen Sie doch Ihre Familie und verbinden Sie das Rodelvergnügen mit einer kleinen Bergwanderung, Almhüttengaudi und abschließender Talfahrt.
<G-vec00623-002-s523><combine.verbinden><en> Combine an exciting shopping tour at OUTLETCITY METZINGEN with a luxurious stay at Le Méridien Stuttgart and indulge yourself in our wellness & fitness center Le SPA.
<G-vec00623-002-s523><combine.verbinden><de> Verbinden Sie eine aufregende Shoppingtour in der OUTLETCITY METZINGEN mit einem luxuriösen Aufenthalt im Le Méridien Stuttgart und lassen Sie sich in unserem großen Wellness- und Fitnessbereich Le SPA verwöhnen.
<G-vec00623-002-s524><combine.verbinden><en> Combine your visit to Noctalis with a performance of the Karl-May-Spiele or a nice bicycle tour and have an all-day outing. Karl-May-Spiele
<G-vec00623-002-s524><combine.verbinden><de> Verbinden Sie Ihren Besuch im Noctalis mit einer Vorstellung der Karl-May-Spiele oder einer schönen Fahrradtour und machen so daraus einen ganztägigen Ausflug.
<G-vec00623-002-s525><combine.verbinden><en> Combine Innovative Style With Music, play free Dress Up games online.
<G-vec00623-002-s525><combine.verbinden><de> Verbinden Sie Innovative Stil mit Musik, Spielfreie Dress Up Spiele online.
<G-vec00623-002-s526><combine.verbinden><en> Combine low cost and high performance Our engineers have been optimizing the companies' capabilities in hosting and maintaining state-of-the-art trading infrastructure since 2002
<G-vec00623-002-s526><combine.verbinden><de> Verbinden Sie niedrige Kosten mit hoher Leistung Unsere Ingenieure haben unsere Hosting- und Servicekompetenzen für hochmoderne Trading-Infrastruktur seit Jahren optimiert.
<G-vec00623-002-s527><combine.verbinden><en> Combine your conference at the Hotel Alpenblick with some days off in the beautiful landscape around Ohlstadt.
<G-vec00623-002-s527><combine.verbinden><de> Verbinden Sie Ihre Tagung mit einigen freien Tagen in der herrlichen Landschaft rund um Ohlstadt.
<G-vec00623-002-s528><combine.verbinden><en> In the new "aged wood design" these tones combine to produce an extremely graceful ambience of colour that is rich in contrasts.
<G-vec00623-002-s528><combine.verbinden><de> Im neuen "Alt-holz-Design" verbinden sie sich zu manchem kontrastreichen, überaus brillant anmutenden Farbambiente.
<G-vec00623-002-s529><combine.verbinden><en> Do not combine this drug with an antifungal (active drug against fungi).
<G-vec00623-002-s529><combine.verbinden><de> Verbinden Sie dieses Medikament nicht mit einem Antipilz (aktiv Medikament gegen Pilze).
<G-vec00623-002-s530><combine.verbinden><en> 7 days bed and breakfast or accommodation with half board including 3 days Tabaluga kiddies-adventure program Combine your family holidays in the Tirolean mountains with a traditional houses.
<G-vec00623-002-s530><combine.verbinden><de> 7 Tage Übernachtung mit Frühstück oder Halbpension inklusive kostenloser Kinderbetreuung mit tollem Abenteuerprogramm Verbinden Sie Ihren Familienurlaub in der atemberaubenden Tiroler Bergwelt...
<G-vec00623-002-s531><combine.verbinden><en> Choose either one of our packages for a day, multi-day trips or let your wanderlust run free and combine your cruise with a getaway in our seaside town.
<G-vec00623-002-s531><combine.verbinden><de> Wählen Sie eines unserer Pauschalen für Tages- oder Mehrtagesreisen oder Sie lassen sich vom Fernweh packen und verbinden Sie Ihre Kreuzfahrt mit einem Kurzurlaub in unserer Seestadt.
<G-vec00623-002-s532><combine.verbinden><en> The charm of the historic listed architecture and the contemporary interior combine for a wonderful creation: Guests at the 3-star Superior Mercure am...
<G-vec00623-002-s532><combine.verbinden><de> Der Charme der historischen denkmalgeschützen Architektur verbindet sich mit dem zeitgemäßen Interieur zu einer gelungenen Einheit: 2018 komplett reno...
<G-vec00623-002-s533><combine.verbinden><en> Our plows, furrow presses, cultivators, compact discs and rotary harrows have numerous well-designed details and extremely powerful electronics to combine operating comfort with maximum safety and reliability of use both for conventional and conservative processing.
<G-vec00623-002-s533><combine.verbinden><de> Saat Unsere Pflüge, Furchenpressen, Grubber, Compact Discs und Kreiseleggen verfügen über zahlreiche durchdachte Details und eine äußerst leistungsstarke Elektronik, die Bedienkomfort mit maximaler Sicherheit und Zuverlässigkeit für die konventionelle und konservative Verarbeitung verbindet.
<G-vec00623-002-s534><combine.verbinden><en> He combine in his works his skills in photography and painting.
<G-vec00623-002-s534><combine.verbinden><de> In diesen Werken verbindet er seine Fähigkeiten als Fotograf und Maler.
<G-vec00623-002-s535><combine.verbinden><en> Cambridge Technology Partners is able to combine over two decades of experience, professional expertise and technological know-how with the dedication and commitment of its 300 employees.
<G-vec00623-002-s535><combine.verbinden><de> Cambridge Technology Partners verbindet über zwei Jahrzehnte Erfahrung, Fachkompetenz und Technologiewissen mit dem Engagement seiner 300 Mitarbeitenden.
<G-vec00623-002-s536><combine.verbinden><en> The steel profile modules from Strasser combine the better mechanical properties of steel compared to aluminum with the flexibility of modern profile systems.
<G-vec00623-002-s536><combine.verbinden><de> Der Stahlprofilbaukasten von Strasser verbindet die besseren mechanischen Eigenschaften von Stahl im Vergleich zu Aluminium mit der Flexibilität moderner Profilbaukästen.
<G-vec00623-002-s537><combine.verbinden><en> The PUB Pilsner Unique Bar is a concept of restaurants, where they combine a tasty food, the highest quality beer and an awesome fun!
<G-vec00623-002-s537><combine.verbinden><de> The PUB Pilsner Unique Bar ist ein Restaurantkonzept, das Gastronomie von höchster Qualität, köstliches Bier und tolle Unterhaltung verbindet.
<G-vec00623-002-s538><combine.verbinden><en> We combine only the best local dishes with selected nuances of international cuisine in the À La Carte Restaurant Sofija.
<G-vec00623-002-s538><combine.verbinden><de> Die Küche verbindet die besten lokalen Gerichte mit ausgewählten Geschmacksnuancen internationaler Küchen.
<G-vec00623-002-s539><combine.verbinden><en> The new hybrid Heritage Black Bay Chrono chronograph dares to combine the aquatic heritage represented by the Black Bay family with the queen of the racetrack, the chronograph.
<G-vec00623-002-s539><combine.verbinden><de> Der neue Heritage Black Bay Chrono ist ein Hybrid, der das aquatische Erbe, repräsentiert durch die Black Bay Linie, mit dem König der Rennstrecke, dem Chronographen, verbindet.
<G-vec00623-002-s540><combine.verbinden><en> I consider it exceptionally important to observe that Paul here does not combine the category of fulfillment with the category of promises, only that of their confirmation.
<G-vec00623-002-s540><combine.verbinden><de> Ich halte es für außerordentlich wichtig, dass Paulus mit den Verheißungen hier nicht die Kategorie der Erfüllung verbindet, sondern der Bestätigung.
<G-vec00623-002-s541><combine.verbinden><en> Internationally successful and at home in South Tyrol, the certified high-tech natural cosmetics combine the best of both worlds: microtechnologically refined active ingredients and the unique synergies of healing plants are implemented in an individual treatment concept.
<G-vec00623-002-s541><combine.verbinden><de> International erfolgreich und in Südtirol zuhause, verbindet die zertifizierte High-Tech Naturkosmetik das Beste aus zwei Welten: Mikrotechnologisch verfeinerte Wirkstoffe und die einzigartigen Synergien der Heilpflanzen werden in einem individuellen Behandlungskonzept umgesetzt.
<G-vec00623-002-s542><combine.verbinden><en> The "Young Family Home" cooperation houses made in collaboration between furniture maker IKEA, the German lifestyle magazine ZUHAUSE WOHNEN and SchwörerHaus, combine young, spirited interior design with modern, family-friendly architecture.
<G-vec00623-002-s542><combine.verbinden><de> Die Kooperationshäuser "Young Family Home" mit Möbelhersteller IKEA, Lifestyle Magazin ZUHAUSE WOHNEN und SchwörerHaus verbindet junge, mutige Einrichtung mit moderner und familienfreundlicher Architektur.
<G-vec00623-002-s543><combine.verbinden><en> It will run freely through the plot and finally combine with the entry square made of stone blocks, on which there will be some parapets installed with seating.
<G-vec00623-002-s543><combine.verbinden><de> Sie wird auf eine leichte Weise durch das Grundstück führen und verbindet sich mit der Einfahrt aus Steinplatten, auf der Mäuerchen mit Sitzmöglichkeit entstehen.
<G-vec00623-002-s544><combine.verbinden><en> 2009 she started to combine her love to both, architecture and painting, in architectural illustrations.
<G-vec00623-002-s544><combine.verbinden><de> Seit 2009 verbindet sie ihre Liebe zu beidem, der Architektur und der Malerei, in der Architektur-Illustration.
<G-vec00623-002-s545><combine.verbinden><en> It’s a good opportunity to combine leisure and sport and to discover the "Momò" part of our wonderful Lake Ceresio.
<G-vec00623-002-s545><combine.verbinden><de> Es verbindet Freizeit und Sport miteinander und ermöglicht den "Momò – Teil“ unseres herrlichen Ceresio-Sees zu entdecken.
<G-vec00623-002-s546><combine.verbinden><en> The decor and interiors of the hotel combine alpine charm with modern elements and features.
<G-vec00623-002-s546><combine.verbinden><de> Die Ausstattung und Einrichtung des Hotels verbindet alpinen Charme mit modernen Stilelementen und stylischen Ausstattungsmerkmalen.
<G-vec00623-002-s547><combine.verbinden><en> The authors of God 9.0 combine integral awareness with spiritual profundity and theological expertise.
<G-vec00623-002-s547><combine.verbinden><de> * "Das Autorenteam von Gott 9.0 verbindet integrale Erkenntnis mit spiritueller Tiefe und theologischer Expertise.
<G-vec00623-002-s548><combine.verbinden><en> Materials such as cow dung, kumkuma powder, incense, and coconut fibers, as well as hairs, needles, and threads combine connotations of everyday use with a poetic charge and refer to urban and rural life in India.
<G-vec00623-002-s548><combine.verbinden><de> Der künstlerische Einsatz von Kuhdung, Kumkum-Pulver, Weihrauch, Kokosfasern, aber auch Haaren, Nadeln oder Fäden verbindet Konnotationen von Alltagsgebrauch mit einer poetischen Aufladung und bezieht sich für die Künstlerin auf das städtische wie ländliche Leben in Indien.
<G-vec00623-002-s549><combine.verbinden><en> These landscaped terraces on the gorge's slope, in the manner of hanging gardens, recreate the landscaping tradition of Islamic Spain and combine it with the European style.
<G-vec00623-002-s549><combine.verbinden><de> Es handelt sich um mehrere begrünte, abgestufte Terrassen, die die gärtnerische Tradition des maurischen Spaniens mit westeuropäischen Elementen verbindet.
<G-vec00623-002-s550><combine.verbinden><en> Mirjam of Wedding Guru had an idea in her head of creating a theme at the beach that would combine Tiffany teal and a beach breeze.
<G-vec00623-002-s550><combine.verbinden><de> Mirjam von Wedding Guru hatte die Idee im Kopf eine Styling zu kreieren, dass die blaue Farbe von Tiffany und eine Meeresbrise verbindet.
<G-vec00623-002-s570><combine.vereinen><en> The accredited degree programs for working professionals at the School of Business, Economics and Society are based on modern approaches that combine academic knowledge and practical methodological skills with interdisciplinary strategies for management tasks.
<G-vec00623-002-s570><combine.vereinen><de> Das akkreditierte Weiterbildungsangebot am Fachbereich Wirtschafts- und Sozialwissenschaften setzt auf methodisch moderne Ansätze, die wissenschaftlich fundierte Kenntnisse und praxisnahe Methodik sowie interdisziplinäre Kompetenzvermittlung für konkrete Managementaufgaben vereinen.
<G-vec00623-002-s571><combine.vereinen><en> 03.04.2017 The confocal chromatic confocalDT 2421 and 2422 controllers combine precision and high speeds in distance and thickness measurements on various surfaces.
<G-vec00623-002-s571><combine.vereinen><de> Schnelle, präzise Dickenmessung in der chromatischen Controller confocalDT 2421 und 2422 vereinen Präzision und hohe Geschwindigkeit bei Abstands- und Dickenmessungen auf verschiedenen Oberflächen.
<G-vec00623-002-s572><combine.vereinen><en> Carefully coordinated active ingredients combine to form a highly effective care complex.
<G-vec00623-002-s572><combine.vereinen><de> Sorgfältig abgestimmte Wirkstoffe vereinen sich zu einem hochwirksamen Pflegekomplex für stark beanspruchtes Haar.
<G-vec00623-002-s573><combine.vereinen><en> Cognitive solutions combine technical and industry-specific content with highly modern methods of machine learning to promote research.
<G-vec00623-002-s573><combine.vereinen><de> Kognitive Ansätze vereinen technische und industrielle Kenntnisse mit hochmodernen Techniken des Maschinenlernens, um mithilfe entsprechender Vorhersagemodelle die Forschung zu beschleunigen.
<G-vec00623-002-s574><combine.vereinen><en> Large-sized RP bending rolls able to effectively combine the speed of a bending roll with the versatility of a press brake.
<G-vec00623-002-s574><combine.vereinen><de> Rundbiegemaschinen RP mit großen Abmessungen, die die Geschwindigkeit einer Rundbiegemaschine mit der Vielseitigkeit einer Biegepresse erfolgreich vereinen können.
<G-vec00623-002-s575><combine.vereinen><en> Analogue body micelle technology is the first to combine long- and short-chain hyaluronic acid.
<G-vec00623-002-s575><combine.vereinen><de> Körperanaloge Mizelltechnologie vermag erstmals lang- und kurzkettiges Hyaluron zu vereinen.
<G-vec00623-002-s576><combine.vereinen><en> Developed for commercial, light industrial, HVAC, residential and DIY applications, the Fluke 323, 324 and 325 True-rms Clamp Meters combine functionality with value.
<G-vec00623-002-s576><combine.vereinen><de> Die Echteffektiv-Strommesszangen Fluke 323, 324 und 325 wurden für Anwendungen in Elektroinstallation, industrieller und gewerblicher Elektrik, HLK- und Haustechnik entwickelt und vereinen Funktionalität und Mehrwert.
<G-vec00623-002-s577><combine.vereinen><en> The formula consists of a special mix of natural ingredients with tried and tested residential properties which combine the power of various weight loss items in just one tablet.
<G-vec00623-002-s577><combine.vereinen><de> Die Formel besteht aus einer speziellen Mischung aus natürlichen Komponenten und getesteten Wohnobjekten, die die Kraft verschiedener Gewichtsverlust-Produkte in nur einer Tablette vereinen.
<G-vec00623-002-s578><combine.vereinen><en> Hard case Paddock Scuderia Ferrari iPhone 6/6S Plus Hard case Urban shades combine the unique sporting spirit of the Scuderia Ferrari with the grit and determination of those who wear the city on their skin.
<G-vec00623-002-s578><combine.vereinen><de> Kollektion Off Track Kleider in städtischen Farben vereinen den unverwechselbaren sportlichen Stil der Scuderia Ferrari mit der Rasse von Leuten, die die Stadt auf der Haut tragen.
<G-vec00623-002-s579><combine.vereinen><en> With the merger, Nets and Concardis Group combine market-leading positions as payment service champions in the Nordics and German-speaking parts of Europe.
<G-vec00623-002-s579><combine.vereinen><de> Mit dem Zusammenschluss vereinen Nets und Concardis Group nun ihre Positionen als Marktführer der Payment-Branche in Nordeuropa und der DACH-Region.
<G-vec00623-002-s580><combine.vereinen><en> We strive to combine the wonderful natural setting of the Black Forest with exceptional, high-quality culinary experiences.
<G-vec00623-002-s580><combine.vereinen><de> Unser Ziel ist es, die wunderbare Schwarzwald-Natur mit höchstem Anspruch und kulinarischem Genuss zu vereinen.
<G-vec00623-002-s581><combine.vereinen><en> These facilities form larger industrial sites that combine civil, building, storage, transmission, and generation infrastructure.
<G-vec00623-002-s581><combine.vereinen><de> Diese Anlagen bilden umfassende Industriestandorte, die Tiefbau-, Gebäude-, Speicher-, Übertragungs- und Erzeugungsinfrastruktur vereinen.
<G-vec00623-002-s582><combine.vereinen><en> electronic Mood The many genres of Latin music combine joy and melancholic longing.
<G-vec00623-002-s582><combine.vereinen><de> Die vielen Genres der lateinamerikanischen Musik vereinen Lebensfreude und melancholische Sehnsucht.
<G-vec00623-002-s583><combine.vereinen><en> BODY i Intensity is the overall taste experience, where aroma and body combine together and deliver a different degree of sensation allowing us to categorize tastes ranging from rich, balanced and refined,
<G-vec00623-002-s583><combine.vereinen><de> Die Intensität ist das gesamte Geschmackserlebnis, bei dem sich Aroma und Körper vereinen und einen unterschiedlichen Empfindungsgrad liefern, so dass wir die Geschmäcker von reich, ausgewogen und raffiniert bis hin zu frisch und aromatisch einordnen können.
<G-vec00623-002-s584><combine.vereinen><en> Therefore, the ELBOW GUARDS of this series combine all features you could wish for: a hard shell cap, breathable fabrics, velcros for a secure hold and durability.
<G-vec00623-002-s584><combine.vereinen><de> Die ELBOW GUARDS der Serie vereinen daher alle Features, die du dir wünschen kannst: eine Hartschalenkappe, atmungsaktive Funktionsmaterialien, Klettverschlüsse für einen sicheren Halt und Strapazierfähigkeit.
<G-vec00623-002-s585><combine.vereinen><en> We from Almdorf Haidenberg in Pustertal combine pleasure, hospitality and culture to your perfect Alpine holiday in South Tyrol.
<G-vec00623-002-s585><combine.vereinen><de> Wir vom Almdorf Haidenberg im Pustertal vereinen Genuss, Gastfreundschaft und Kultur zu Ihrem perfekten Almurlaub in Südtirol.
<G-vec00623-002-s586><combine.vereinen><en> Piezoceramic drives combine exactly these characteristics.
<G-vec00623-002-s586><combine.vereinen><de> Piezokeramische Antriebe vereinen genau diese Merkmale.
<G-vec00623-002-s587><combine.vereinen><en> All our projects combine this special lifestyle with a modern and at the same time timeless architectural language that ensures a long-term investment in value.
<G-vec00623-002-s587><combine.vereinen><de> Alle unsere Projekte vereinen diesen besonderen Lebensstil mit einer modernen und gleichzeitig zeitlosen Architektursprache, die eine langfristige Wertanlage sicherstellen.
<G-vec00623-002-s588><combine.vereinen><en> Jimdo continually aims to combine the strengths of data-driven, innovative and agile technologies with the desires and budget of a broad User base.
<G-vec00623-002-s588><combine.vereinen><de> Jimdo zielt stets darauf ab, die Stärken von datengetriebenen, innovativen und agilen Technologien mit den Wünschen und dem Budget des breiten Anwenderspektrums zu vereinen.
<G-vec00623-002-s589><combine.vereinen><en> Simplicity, elegance and sensuality combine in this sheath wedding dress.
<G-vec00623-002-s589><combine.vereinen><de> Schlichtheit, Eleganz und Sinnlichkeit vereinen sich in diesem schmal geschnittenen Brautkleid.
<G-vec00623-002-s590><combine.vereinen><en> $99.99 Contemporary design and relevant features combine to deliver a stylish laptop backpack perfect for work, school or travel.
<G-vec00623-002-s590><combine.vereinen><de> Zeitgemäßes Design und wichtige Funktionen vereinen sich in einem eleganten Laptop-Rucksack, der optimal für die Arbeit, die Schule oder Reisen geeignet ist.
<G-vec00623-002-s591><combine.vereinen><en> ZARGES products combine the multiple benefits of the light metal material aluminium such as high stability with low weight, corrosion resistance and flexibility of use.
<G-vec00623-002-s591><combine.vereinen><de> In ZARGES-Produkten vereinen sich die vielfältigen Vorteile des Leichtmetall-Werkstoffs Aluminium wie hohe Stabilität bei geringem Gewicht, Korrosionsfestigkeit sowie Flexibilität im Einsatz.
<G-vec00623-002-s592><combine.vereinen><en> Stop in a wild behind a wild during a falling wild respin and the wilds will combine and turn the reel completely wild for a single spin – covering it with 3 wild symbols.
<G-vec00623-002-s592><combine.vereinen><de> Wenn du während der Fallende-Wild-Symbole-Respins ein Wild-Symbol hinter einem Wild-Symbol erhältst, vereinen sich die Wild-Symbole und verwandeln die Walze für einen einzigen Dreh in eine Wild-Walze – sie bedecken sie also mit 3 Wild-Symbolen.
<G-vec00623-002-s593><combine.vereinen><en> Delicate floral chords and fresh head notes combine with a warm base to form a modern fragrance brimming with simple elegance.
<G-vec00623-002-s593><combine.vereinen><de> Feminine Blumenakkorde und frische Kopfnoten vereinen sich mit einer warmen Basis zu einer modernen Duftkomposition voll schlichter Eleganz.
<G-vec00623-002-s595><combine.vereinen><en> The treatments and programmes arranged by the spa establishment of Cervia combine with the mild climate and the numerous fun opportunities the area offers and contribute to regenerate both body and mind.
<G-vec00623-002-s595><combine.vereinen><de> Kur und Vergnügen befinden sich auf diesem Gebiet des “Meeres und des Grüns” und vereinen sich mit dem Gesundheitsklima und den zahlreichen Vergnügungsangeboten für Touristen- ein Touch von Gesundheit für Körper und Geist.
<G-vec00623-002-s596><combine.vereinen><en> Scan-Line 10 + 20 + 30 combine the traditional characteristics of the stove and the thermal mass stove.
<G-vec00623-002-s596><combine.vereinen><de> Beim Scan-Line 10, 20 und 30 vereinen sich die Vorteile eines Kaminofens mit den traditionellen Eigenschaften eines gemauerten Ofens.
<G-vec00623-002-s597><combine.vereinen><en> The lightness and strength of carbon fibre and aramid fibres combine with an attractive design and distinctive racing finishing in an accessory that offers maximum protection in the event of a slip and enhances the Panigale's sporty and elegant soul. Composition fibre rear mudguard
<G-vec00623-002-s597><combine.vereinen><de> Die Leichtigkeit und Widerstandsfähigkeit der Kohlefaser und Aramidfasern vereinen sich mit einem ansprechenden Design und dem typischem Racing-Finish, in einem Zubehörteil, das maximalen Schutz im Falle des Abrutschens bietet sowie die sportliche und elegante Seele der Panigale betont.
<G-vec00623-002-s598><combine.vereinen><en> In our sweet factory we combine experience with science and technology to the high art of confectionary production.
<G-vec00623-002-s598><combine.vereinen><de> In unserer Konfekt-Manufaktur vereinen sich Liebe zur Sache und langjährige Erfahrung mit Wissenschaft und Technik zur hohen Kunst der Pralinen-Erzeugung.
<G-vec00623-002-s599><combine.vereinen><en> Lisbon's sophisticated shopping centres (considered as one of the best cities in Europe for shopping), luxury hotels and fine accommodation, including apartments, hostels, pousadas and villas, gastronomy and culture combine with the climate to make this a great destination, 12 months of the year.
<G-vec00623-002-s599><combine.vereinen><de> Die anspruchsvollen Einkaufszentren, die Lissabon zu einer der besten Einkaufsadressen Europas machen, die excellenten Luxus-Hotels und Unterkünfte wie Apartments, Hostels, Herrenhäuser, Schlösser und Villen, sowie die Gastronomie und Kultur vereinen sich mit dem angenehmen Klima und machen Lissabon zu einem der besten Reiseziele 12 Monate im Jahr.
<G-vec00623-002-s600><combine.vereinen><en> The delicious "dessert" notes of Girl Scout Cookies and Do-Si-Dos combine to create an unprecedented flavour experience reminiscent of freshly baked biscuits.
<G-vec00623-002-s600><combine.vereinen><de> Die köstlichen "Dessert"-Noten von Girl Scout Cookies und Do-Si-Dos vereinen sich in einem beispiellosen Geschmackserlebnis, das an frisch gebackene Kekse erinnert.
<G-vec00623-002-s601><combine.vereinen><en> The most demanding requirements in terms of design and quality combine with the demand to bring the world closer to the wearer.
<G-vec00623-002-s601><combine.vereinen><de> Höchste Anforderungen an Design und Qualität vereinen sich mit dem Anspruch, der Lebenswelt der Träger nahe zu sein.
<G-vec00623-002-s602><combine.vereinen><en> Beauty, light riding and character combine in this athlete.
<G-vec00623-002-s602><combine.vereinen><de> Schönheit, Leichtrittigkeit und Charakter vereinen sich in diesem Sportler.
<G-vec00623-002-s603><combine.vereinen><en> They combine German engineering and business know-how to create a powerful strategy.
<G-vec00623-002-s603><combine.vereinen><de> So vereinen sich deutsche Ingenieurskunst und wirtschaftswissenschaftliches Know-How zu einer schlagkräftigen Strategie.
<G-vec00623-002-s604><combine.vereinen><en> In it combine aerodynamic shape and high mechanical strength by Swiss precision.
<G-vec00623-002-s604><combine.vereinen><de> In ihr vereinen sich Aerodynamische Form und hohe mechanische Belastbarkeit durch Schweizer Präzision.
<G-vec00623-002-s605><combine.vereinen><en> Warm, dark vocals combine with insanely catchy synth sounds to form a fervent album of electronic music.
<G-vec00623-002-s605><combine.vereinen><de> Warme, dunkle Vocals vereinen sich mit Ohrwurmverdächtigen Synthiesounds zu einem leidenschaftlichen Album elektronischer Musik.
<G-vec00623-002-s607><combine.vereinen><en> The unfailing passion and enduring emotion combine to create watches of timeless nature, much like the classic cars that they honor.
<G-vec00623-002-s607><combine.vereinen><de> Die unerschöpfliche Leidenschaft und lang währende Emotion vereinen sich in der Kreation von Uhren mit zeitlosem Charakter, wie bei den klassischen Rennwagen, denen sie Tribut zollen.
<G-vec00623-002-s627><combine.vereinen><en> The new RS 14 series power generators combine powerful performance with a modern operating concept.
<G-vec00623-002-s627><combine.vereinen><de> Der Stromerzeuger der neuen RS 14 Baureihe vereint volle Leistungsfähigkeit mit einem modernen Bedienkonzept.
<G-vec00623-002-s628><combine.vereinen><en> yellow Sporty, stylish, super lightweight – the STRATOFLY glasses by RUDY PROJECT combine all of your wishes.
<G-vec00623-002-s628><combine.vereinen><de> Details Sportlich, stylisch, superleicht – die STRATOFLY Brille von RUDY PROJECT vereint alle deine Wünsche.
<G-vec00623-002-s629><combine.vereinen><en> I am happy there is a brand which can successfully combine those two aspects and create perfect makeup brushes.
<G-vec00623-002-s629><combine.vereinen><de> Ich bin erfreut, dass es eine Marke gibt, die diese beiden Aspekte zu einem Ganzen vereint und die perfekten Make-up Pinsel entwickelt hat.
<G-vec00623-002-s630><combine.vereinen><en> Loge", "Duke's Residence" or "Alp Frenzy" and the tasteful furnishings combine Bavarian country house charm with modern materials.
<G-vec00623-002-s630><combine.vereinen><de> Loge", „Herzog’s Residenz" oder „Almenrausch" und die geschmackvolle Einrichtung vereint leichtes bayerisches Landhausflair mit modernen Materialien.
<G-vec00623-002-s631><combine.vereinen><en> Papanatas by Eli carries children’s shoes that combine traditional models with modern styles.
<G-vec00623-002-s631><combine.vereinen><de> Papanatas by Eli führt Kinderschuhe, die traditionelle Modelle sowie moderne Styles vereint.
<G-vec00623-002-s632><combine.vereinen><en> The platform will combine all key functions for the monitoring and documentation of machine data under a single user interface.
<G-vec00623-002-s632><combine.vereinen><de> Die Plattform vereint unter einer einzigen Bedienoberfläche alle wichtigen Funktionen für die Überwachung und Dokumentation der Maschinendaten.
<G-vec00623-002-s633><combine.vereinen><en> Elfab combine CAD/CAM design with precision manufacturing all from one location.
<G-vec00623-002-s633><combine.vereinen><de> Elfab vereint CAD/CAM-Design und Präzisionsfertigung an einem Standort.
<G-vec00623-002-s634><combine.vereinen><en> Both types of companies - the LLC and the Corporation - combine a number of properties that are advantageous for entrepreneurs.
<G-vec00623-002-s634><combine.vereinen><de> Beide Unternehmensformen – die LLC und die Corporation – vereint eine ganze Reihe an Eigenschaften, die vorteilhaft für Gründer sind.
<G-vec00623-002-s635><combine.vereinen><en> Rainbow … Special pigments in this dispersion combine typical metallic effects with the expressive spectra of a rainbow.
<G-vec00623-002-s635><combine.vereinen><de> Composite Beweglich Leichtbau Flexibel Durch spezielle Pigmente vereint diese Dispersion typische Metallic-Effekte mit dem ausdrucksstarken Spektrum eines Regenbogens.
<G-vec00623-002-s636><combine.vereinen><en> Especially their Instax product line has gained in popularity and is well received by younger generations since these cameras combine quality with simplicity.
<G-vec00623-002-s636><combine.vereinen><de> Vor allem die Instax-Reihe hat an Beliebtheit gewonnen und kommt gerade bei der jüngeren Generation sehr gut an, da sie Qualität und Einfachheit vereint.
<G-vec00623-002-s637><combine.vereinen><en> The founding team consists of a carefully chosen mixture of engineering and business experts – including machine-to-machine communication professor James Gross (KTH Stockholm, Sweden) – they combine more than 25 years of scientific/engineering and more than 10 years of top management consulting experience.
<G-vec00623-002-s637><combine.vereinen><de> Das Gründerteam um Professor James Gross (Professor für Maschine-zu-Maschine Kommunikation an der KTH Stockholm, Schweden) vereint mehr als 25 Jahre wissenschaftliches Arbeiten im IKT Bereich sowie mehr als zehn Jahre in Strategischer Top-Management Beratung auf sich.
<G-vec00623-002-s638><combine.vereinen><en> The majority of the people of the Macau Peninsula combine Eastern and Western culture, there are also historical sites such as old European Baroque and traditional Chinese buildings and influences.
<G-vec00623-002-s638><combine.vereinen><de> Die Mehrheit der Bewohner der Halbinsel Macau vereint östliche und westliche Kultur, historische Stätten wie das alte europäische Barock und traditionelle chinesische Gebäude und Einflüsse.
<G-vec00623-002-s639><combine.vereinen><en> Today, the Hamilton headquarters are located in Biel, Switzerland, and combine the technical finesse of Swiss precision with longstanding American design elements.
<G-vec00623-002-s639><combine.vereinen><de> Heute hat der Hersteller seinen Sitz in Biel und vereint nun schweizerische Präzision mit seinem amerikanischen Erbe.
<G-vec00623-002-s640><combine.vereinen><en> This allows the company from Tuttlingen in southern Germany to combine its efforts to achieve the highest level of customer satisfaction with constant product optimization.
<G-vec00623-002-s640><combine.vereinen><de> Damit vereint das Unternehmen aus dem süddeutschen Tuttlingen sein Bestreben nach höchster Kundenzufriedenheit und ständiger Produktoptimierung.
<G-vec00623-002-s641><combine.vereinen><en> Buy Buy Zip-up hoodies combine the advantages of a sweatshirt with the benefits of a jacket, making them perfect sports companions, e.g.
<G-vec00623-002-s641><combine.vereinen><de> Eine Sweatjacke vereint die Vorzüge eines Sweatshirts mit dem Nutzen einer Jacke.
<G-vec00623-002-s642><combine.vereinen><en> Manuals Reviews Our wall clock uses high-quality materials to combine design and quality.
<G-vec00623-002-s642><combine.vereinen><de> Kundenmeinungen Durch den Einsatz hochwertiger Materialien vereint unsere Wanduhr Design und Qualität.
<G-vec00623-002-s643><combine.vereinen><en> The stronger, lighter, more rigid framework combine ride comfort with safety.
<G-vec00623-002-s643><combine.vereinen><de> Der stabilere, leichtere und steifere Rahmen vereint Fahrkomfort und Sicherheit.
<G-vec00623-002-s644><combine.vereinen><en> One challenge that will remain is eliminating people’s fear of the unknown and showing them the opportunities we have when we combine AI with human creativity.
<G-vec00623-002-s644><combine.vereinen><de> Eine Herausforderung wird dabei weiter darin bestehen, den Menschen ihre Sorge vor dem Unbekannten zu nehmen und die Chancen zu verdeutlichen, die entstehen, wenn man die Möglichkeiten der KI mit menschlicher Kreativität vereint.
<G-vec00623-002-s645><combine.vereinen><en> As a team we decided to combine our strengths and interests in order to help others experience the power and innovation of interdisciplinary teams and human-centered design.
<G-vec00623-002-s645><combine.vereinen><de> Als Team haben wir unsere Stärken und Interessen vereint, um anderen Menschen die Kraft und das Innovationspotenzial von interdisziplinärer Teamarbeit und menschenzentriertem Design näherzubringen.
<G-vec00623-002-s608><combine.vereinigen><en> Visit card of our town is an unique opportunity to combine several types of relaxation.
<G-vec00623-002-s608><combine.vereinigen><de> Eine einzigartige Gelegenheit, verschiedene Erholungsarte zu vereinigen, ist wahrscheinlich die Hauptbesonderheit unserer Stadt.
<G-vec00623-002-s609><combine.vereinigen><en> The new K&F NOMOS subwoofers combine two highly welcome features – signifi can't musicality paired with astounding performance.
<G-vec00623-002-s609><combine.vereinigen><de> Die neuen K&F NOMOS-Subwoofer vereinigen zwei höchst willkommene Eigenschaften: spürbare Musikalität, gepaart mit erstaunlicher Leistungsfähigkeit.
<G-vec00623-002-s610><combine.vereinigen><en> One could eliminate that and combine them both in the second question, if it were possible to assert that because of her singing our people are unconditionally devoted to Josephine.
<G-vec00623-002-s610><combine.vereinigen><de> Man könnte sie streichen und gänzlich mit der zweiten Frage vereinigen, wenn sich etwa behaupten ließe, daß das Volk wegen des Gesanges Josefine bedingungslos ergeben ist.
<G-vec00623-002-s611><combine.vereinigen><en> These elegant and filigran Earrings combine style and elegance into a real eye-catcher.
<G-vec00623-002-s611><combine.vereinigen><de> Diese eleganten und filigranen Ohrringe vereinigen Stil und Eleganz zu einem wahren Hingucker.
<G-vec00623-002-s612><combine.vereinigen><en> There are a lot of Six Sigma software tools trying to combine all Six Sigma methods in one tool.
<G-vec00623-002-s612><combine.vereinigen><de> Es gibt eine Vielzahl von Six Sigma-Softwaretools, die versuchen, alle Six Sigma-Methoden in einem Tool zu vereinigen.
<G-vec00623-002-s613><combine.vereinigen><en> We combine the advantages of a global industrial organization with the efficiency of a medium-sized company.
<G-vec00623-002-s613><combine.vereinigen><de> Wir vereinigen die Vorteile eines globalen Industrieunternehmens mit den kurzen Wegen eines Mittelständlers.
<G-vec00623-002-s614><combine.vereinigen><en> Team The three founders combine their experience and expertise of over 500 film productions of every
<G-vec00623-002-s614><combine.vereinigen><de> Team Die drei Firmengründer vereinigen Erfahrung und Kompetenz aus über 500 betreuten Filmproduktionen jeden Genres.
<G-vec00623-002-s615><combine.vereinigen><en> Bedroom with double bed or 2 single beds, LCD TV, bathroom with hydro-massage para comparar el efecto visual de diferentes tipos de letra e Te Idyllic suites aimed at the corporate market to combine business and leisure and the comfort of feeling right at home.
<G-vec00623-002-s615><combine.vereinigen><de> Schlafzimmer mit Doppelbett oder zwei Einzelbetten, TV LCD, Bad mit Traumsuiten angelehnt an den Corporate-Markt, um mit der Sensation sich wie zu Hause zu fühlen, Business und Freizeit zu vereinigen.
<G-vec00623-002-s616><combine.vereinigen><en> In its endeavours to combine craft, technology and industry in order to lend a new aesthetic quality to all of the arts, Bauhaus became – and remains – the most important source of inspiration for modernity.
<G-vec00623-002-s616><combine.vereinigen><de> In dem Bestreben, Handwerk, Technik und Industrie zu vereinigen, um allen Künsten eine neue ästhetische Qualität zu geben, wird es zum wichtigsten und bis heute wegweisenden Impulsgeber der Moderne.
<G-vec00623-002-s617><combine.vereinigen><en> Back in 2017, with a desire to combine the two musical worlds that had given him so much, Mullaert scored and performed a collaborative concert with musicians of the Tonhalle Orchestra Zürich, one of Europe’s best symphony orchestras. An immersive audio visual performance, it took place at the spectacular Tonhalle concert hall in Zurich as part of their tonhalleLATE series.
<G-vec00623-002-s617><combine.vereinigen><de> Aus dem Wunsch heraus, die beiden musikalischen Welten zu vereinigen, die ihm selbst so viel gegeben haben, komponierte er Musik, die er 2017 zusammen mit Musikern des Tonhalle-Orchesters Zürich, einem der besten Symphonieorchester Europas, in einer eindringlichen audiovisuellen Performance im Rahmen der Reihe tonhalleLATE in der spektakulären Züricher Tonhalle zur Aufführung brachte.
<G-vec00623-002-s618><combine.vereinigen><en> The real pearl of the complex is its beautiful "Garden", with its own restaurant, pizzeria, bar, ice-cream parlour, outdoor heated swimming pool with comfortable beach chairs, solarium and play area, where nature and relaxation combine in perfect harmony.
<G-vec00623-002-s618><combine.vereinigen><de> Das Aushängeschild der Anlage ist der wunderschöne Garten "Garden", ausgestattet mit Restaurant, Pizzeria, Bar, Eisdiele, geheiztem Schwimmbad mit bequemen Strandliegen, Solarium und Spielpark, wo sich Natur nd Entspannung in einer Synthese perfekter Harmonie vereinigen.
<G-vec00623-002-s619><combine.vereinigen><en> But functionality never stands in the way of design – quite the contrary in fact: models such as RB3447 001, RB4171 622/8G or RB4171 710/T5 combine timeless attractiveness with the hottest fashion trends.
<G-vec00623-002-s619><combine.vereinigen><de> Doch die Funktionalität steht dem Design nie im Weg, im Gegenteil: Modelle wie RB3447 001, RB4171 622/8G oder RB4171 710/T5 vereinigen zeitlose Attraktivität mit den angesagten Modetrends.
<G-vec00623-002-s620><combine.vereinigen><en> These pioneers combine a market share of more than 80%, and the connection of your company to these marketplaces could almost be regarded as mandatory for a successful rollout.
<G-vec00623-002-s620><combine.vereinigen><de> Diese Pioniere vereinigen einen Marktanteil von über 80 % und die Anbindung Ihres Unternehmens an diese Marktplätze könnte fast schon als verpflichtend für einen erfolgreichen Rollout gesehen werden.
<G-vec00623-002-s621><combine.vereinigen><en> The HEUFT laboratories combine a wide variety of basic knowledge with decades of experience which has been applied in inspection, transport, sorting and labelling technology.
<G-vec00623-002-s621><combine.vereinigen><de> Die HEUFT Laboratorien vereinigen breitgefächertes Grundlagenwissen mit jahrzehntelanger Anwendungserfahrung in der Inspektions-, Transport-, Sortier- und Etikettiertechnik.
<G-vec00623-002-s622><combine.vereinigen><en> The materials combine the properties of steel and cemented carbide and are highly resistant to wear.
<G-vec00623-002-s622><combine.vereinigen><de> Die Werkstoffe vereinigen die Eigenschaften von Stahl und Hartmetall und sind hochverschleißfest.
<G-vec00623-002-s623><combine.vereinigen><en> There is no doubt, a clear lack of such integration possibilities would know how to combine the big macro-economic and other processes in a general show and in functions.
<G-vec00623-002-s623><combine.vereinigen><de> Es besteht ohne Zweifel ein deutlicher Mangel an solchen Integrationsmöglichkeiten, die die großen makroökonomischen und anderen Prozesse in einer Gesamtschau und in Funktionen zu vereinigen wüssten.
<G-vec00623-002-s624><combine.vereinigen><en> With combined schemes, it is possible to use special, flexible routes, reduce the costs of transportation, combine geographically distant points of arrival and departure, and provide fast transport.
<G-vec00623-002-s624><combine.vereinigen><de> Dank der Zusammenstellung kombinierter Schemen ist es möglich, eine flexible und geeignete Route zu legen, die Transportkosten zu senken, geografisch entfernte Ankunfts- und Abfahrtsorte zu vereinigen und eine schnelle Transportgeschwindigkeit bereitzustellen.
<G-vec00623-002-s625><combine.vereinigen><en> As a result of many years of experience, our pellet machines combine reliability, efficiency, energy savings and high productivity.
<G-vec00623-002-s625><combine.vereinigen><de> Als Ergebnis unserer langjährigen Erfahrung, unsere Maschinen vereinigen Zuverlässigkeit, Effizienz, Energieeinsparung und hohe Produktivität.
<G-vec00623-002-s626><combine.vereinigen><en> The tradition of building log houses in Latvia goes way back in time – we only had to take the best of these traditions and combine them with contemporary solutions and modern technologies.
<G-vec00623-002-s626><combine.vereinigen><de> Der Blockbau in Lettland hat eine lange Tradition – wir mussten nur das Beste finden und es mit modernen Lösungen und Technologien vereinigen.
<G-vec00623-002-s646><combine.verknüpfen><en> Thus, the very efficient, simple and precise mechanisms of charge manipulation well established in semiconductor electronics can be transferred to the world of spintronic and thereby combine semiconductor physics with magnetism.
<G-vec00623-002-s646><combine.verknüpfen><de> Damit können die sehr einfachen und präzisen Steuerungsmöglichkeiten, die in der Halbleiterelektronik für Ladung und Ladungsfluss existieren, in den Bereich der Spintronik übertragen werden und so die Welt der Halbleiter mit der Welt des Magnetismus verknüpfen.
<G-vec00623-002-s647><combine.verknüpfen><en> To this end, we combine traditional handicraft with contemporary zeitgeist.
<G-vec00623-002-s647><combine.verknüpfen><de> Dabei verknüpfen wir das originäre Handwerk mit dem aktuellen Zeitgeist.
<G-vec00623-002-s648><combine.verknüpfen><en> The web shops combine the classic features of an online shop with the complex requirements of warehouse management and logistics systems.
<G-vec00623-002-s648><combine.verknüpfen><de> Die Webshops verknüpfen die klassischen Funktionen eines Online-Shops mit den komplexen Anforderungen von Warenwirtschafts- und Logistiksystemen.
<G-vec00623-002-s649><combine.verknüpfen><en> You will combine theory directly with practice in tutorials and projects.
<G-vec00623-002-s649><combine.verknüpfen><de> Die Theorie verknüpfen Sie in Übungen und Projekten direkt mit der Praxis.
<G-vec00623-002-s650><combine.verknüpfen><en> They combine these with their cultural values which shapes their projects: clarity, quality, personality and inspiration.
<G-vec00623-002-s650><combine.verknüpfen><de> Sie verknüpfen dies mit ihren kulturellen Werten, die ihre Projekte prägen: Klarheit, Qualität, Persönlichkeit und Inspiration.
<G-vec00623-002-s651><combine.verknüpfen><en> We combine strategic stock locations with bonded warehouses to cover the full transportation and customs clearance service spectrum.
<G-vec00623-002-s651><combine.verknüpfen><de> Wir verknüpfen Strategic-Stock-Locations mit Bonded Warehouse und unterstützen unsere Kunden als Full-Service-Dienstleister in allen transporttechnischen Fragen und bei der Zollabfertigung.
<G-vec00623-002-s652><combine.verknüpfen><en> It’s the perfect way to combine comfort with an authentic experience of baccarat.
<G-vec00623-002-s652><combine.verknüpfen><de> Der perfekte Weg, um Komfort mit dem authentischen Baccarat Casino Erlebnis zu verknüpfen.
<G-vec00623-002-s653><combine.verknüpfen><en> They combine classic advertising with a digital component with the NFC headrest.
<G-vec00623-002-s653><combine.verknüpfen><de> Sie verknüpfen mit der NFC Kopfstütze die klassische Werbung mit einer digitalen Komponente.
<G-vec00623-002-s654><combine.verknüpfen><en> General planners and specialists, basic and practical engineers combine comprehensive expertise in all areas of activity for optimized, economic and future-oriented solutions.
<G-vec00623-002-s654><combine.verknüpfen><de> Generalisten und Spezialisten, Theoretiker und Praktiker verknüpfen umfassendes Fachwissen in allen Tätigkeitsgebieten zu optimalen wirtschaftlichen und zukunftsweisenden Lösungen.
<G-vec00623-002-s655><combine.verknüpfen><en> We combine expert knowledge with technological proficiency to make your project a success.
<G-vec00623-002-s655><combine.verknüpfen><de> Wir verknüpfen Fach- und Technologiekompetenz und führen Projekte zum Erfolg.
<G-vec00623-002-s656><combine.verknüpfen><en> With our experience as service partner in engineering and site infrastructure we combine the knowledge of plant construction with practical industrial know-how. This expertise is completely applicable to optimization and maintenance.
<G-vec00623-002-s656><combine.verknüpfen><de> Mit Praxiserfahrung als Technik - und Infrastrukturdienstleister verknüpfen wir Know-how für Anlagenerrichtung mit dem Wissen über die laufende Serviceleistung, seien es Optimierungen oder Instandhaltung.
<G-vec00623-002-s657><combine.verknüpfen><en> Besides lots of fun and action, LSD as main sponsor raffled a superb WEBER gas grill among all the guests. It was great to combine the real game world with the digital one.
<G-vec00623-002-s657><combine.verknüpfen><de> Neben jeder Menge Spaß und Action konnten die Gäste an unserem Messestand die reale Spielwelt mit der digitalen verknüpfen.
<G-vec00623-002-s658><combine.verknüpfen><en> In addition, if you have consented to the use of your data for the purposes of sending newsletters, we will process the data for direct marketing purposes and combine it in a customer profile with other information that BERNINA has saved about you.
<G-vec00623-002-s658><combine.verknüpfen><de> Sofern Sie darüber hinaus in die Verwendung Ihrer Daten für den Versand von Newslettern zugestimmt haben, verarbeiten wir die Daten für Zwecke der Direktwerbung und verknüpfen sie mit anderen Informationen, die BERNINA über Sie gespeichert hat, in einem Kundenprofil.
<G-vec00623-002-s659><combine.verknüpfen><en> In some instances, we may combine Other Data with Personal Data.
<G-vec00623-002-s659><combine.verknüpfen><de> In einigen Fällen können wir sonstige Informationen mit personenbezogenen Informationen verknüpfen.
<G-vec00623-002-s660><combine.verknüpfen><en> If we do combine non-personal information with personal information the combined information will be treated as personal information for as long as it remains combined.
<G-vec00623-002-s660><combine.verknüpfen><de> Für den Fall, dass wir nicht-personenbezogene Daten mit personenbezogenen Daten verknüpfen, werden diese verknüpften Daten, solange sie verknüpft bleiben, als personenbezogene Daten behandelt.
<G-vec00623-002-s661><combine.verknüpfen><en> We may also evaluate your personal data and combine this with other personal data, for example with non-personalized statistical data and other personal data that we have collected about you in order to extrapolate information about your preferences and interest in certain products or services.
<G-vec00623-002-s661><combine.verknüpfen><de> Wir können Ihre Personendaten auch auswerten und mit anderen Personendaten verknüpfen, zum Beispiel mit nicht personenbezogenen statistischen Angaben und mit anderen Personendaten, die wir über Sie erhoben haben, um daraus Angaben über Ihre Vorlieben und Affinitäten zu bestimmten Produkten oder Dienstleistungen abzuleiten.
<G-vec00623-002-s662><combine.verknüpfen><en> From Amstetten to Zwettl, female and male district commissioners made use of the opportunity to combine their conference with the exchange of experiences with the power plant operator VERBUND.
<G-vec00623-002-s662><combine.verknüpfen><de> Von Amstetten bis Zwettl nutzten die Bezirkshauptfrauen und -männer die Gelegenheit, ihre Konferenz mit dem Erfahrungsaustausch mit dem Kraftwerksbetreiber VERBUND zu verknüpfen.
<G-vec00623-002-s663><combine.verknüpfen><en> However, Maori and Pacific ethnic groups combine high fertility rates with much lower female employment rates.
<G-vec00623-002-s663><combine.verknüpfen><de> Jedoch verknüpfen die ethnischen Gruppen der Maori und des pazifischen Raums hohe Fertilitätsraten mit viel niedrigeren Beschäftigungsquoten von Frauen.
<G-vec00623-002-s664><combine.verknüpfen><en> So you can optimally combine a bachelor's degree and professional activities together.
<G-vec00623-002-s664><combine.verknüpfen><de> So können Sie Bachelor-Studium und Berufstätigkeit optimal miteinander verknüpfen.
<G-vec00623-002-s703><combine.zusammenfassen><en> There are many factors involved in the deployment of metallic paneling. To hide technology, divide or combine structures, as protection, or for practical or decorative reasons.
<G-vec00623-002-s703><combine.zusammenfassen><de> Technologie verbergen, Strukturen aufteilen oder zusammenfassen, als Schutz, aus Zweckmäßigkeit oder aus dekorativen Aspekten – für den Einsatz von Verkleidungen aus metallischen Werkstoffen sprechen viele Faktoren.
<G-vec00623-002-s704><combine.zusammenfassen><en> If there are documents with different taxation bases for a partial payment transaction, you cannot combine them in a final invoice.
<G-vec00623-002-s704><combine.zusammenfassen><de> Wenn zu einem Anzahlungsgeschäft Belege mit unterschiedlichen Besteuerungsgrundlagen existieren, dann können Sie diese nicht in einer Schlussrechnung zusammenfassen.
<G-vec00623-002-s705><combine.zusammenfassen><en> What’s more, the motif of the communication campaign had to combine the focal points of lighting and building technology.
<G-vec00623-002-s705><combine.zusammenfassen><de> Zudem musste die Kommunikationskampagne die Schwerpunkte Licht und Gebäudetechnik in einem Motiv zusammenfassen.
<G-vec00623-002-s706><combine.zusammenfassen><en> As an end product of the events, the participants could create their own tasks in the portal and combine them into a trail around the school.
<G-vec00623-002-s706><combine.zusammenfassen><de> Als Endprodukt der Veranstaltungen konnten die TeilnehmerInnen ihre eigenen Aufgaben im Portal anlegen und zu einem Trail rund um die Schule zusammenfassen.
<G-vec00623-002-s707><combine.zusammenfassen><en> For your convenience you can combine fresh, dry and frozen items all in one order.
<G-vec00623-002-s707><combine.zusammenfassen><de> Sie können einfach frische, getrocknete und tiefgefrorene Produkte in einer Bestellung zusammenfassen.
<G-vec00623-002-s708><combine.zusammenfassen><en> This video shows you how to sort and combine several files of a recording.
<G-vec00623-002-s708><combine.zusammenfassen><de> Dieses Video zeigt Ihnen wie Sie die Teildateien einer Aufzeichnung sortieren und zusammenfassen können.
<G-vec00623-002-s709><combine.zusammenfassen><en> If you already have three separate images, you can combine them into a single RGB file by using the Set Channels effect.
<G-vec00623-002-s709><combine.zusammenfassen><de> Wenn Sie bereits über drei separate Bilder verfügen, können Sie diese mithilfe des Effekts „Kanäle festlegen“ in einer einzigen RGB-Datei zusammenfassen.
<G-vec00623-002-s710><combine.zusammenfassen><en> A legislative proposal is attached to the Strategy which will combine the existing Framework Directive on air quality, its ‘daughter’ Directives and a Decision on exchange of information.
<G-vec00623-002-s710><combine.zusammenfassen><de> Mit der Strategie geht ein Vorschlag für eine Rechtsvorschrift einher, die die bestehende Luftqualitäts-Rahmenrichtlinie, ihre ‚Tochterrichtlinien’ und eine Entscheidung über den Informationsaustausch zusammenfassen wird.
<G-vec00623-002-s711><combine.zusammenfassen><en> For example, you can combine purchasing managers with one selection code.
<G-vec00623-002-s711><combine.zusammenfassen><de> So können Sie Einkaufsleiter unter einem Selektionscode zusammenfassen.
<G-vec00623-002-s712><combine.zusammenfassen><en> Because our program may combine carriage return / line feed sequences into straight line feeds, our output may be smaller than our input.
<G-vec00623-002-s712><combine.zusammenfassen><de> Dadurch das unser Programm Wagenrücklauf/Zeilenvorschub-Sequenzen in einfache Zeilenvorschübe zusammenfassen könnte, könnte unsere Ausgabe kleiner sein als unsere Eingabe.
<G-vec00623-002-s713><combine.zusammenfassen><en> • You can also combine several pages into a Page Overview.
<G-vec00623-002-s713><combine.zusammenfassen><de> • Du kannst aber auch mehrere Pages zu einer Page Overview (Seitenübersicht) zusammenfassen.
<G-vec00623-002-s714><combine.zusammenfassen><en> Featuring a new one-touch convenience eco button, which is easily found on the front panel and acts as a default setting once turned on, you can now combine two pages into one document.
<G-vec00623-002-s714><combine.zusammenfassen><de> Mit einem einfachen Knopfdruck auf dem Bediendisplay aktivieren Sie die One-Touch-Eco-Funktion und können jeweils zwei Seiten zu einer Druckseite zusammenfassen.
<G-vec00623-002-s715><combine.zusammenfassen><en> First we can fill the text in the background with any colour, several colours or even a texture, and if we go to the upper later (with diffused borders) one can combine it in a couple of ways: First by multiplication....
<G-vec00623-002-s715><combine.zusammenfassen><de> Zuerst können wir den Text im Hintergrund mit irgendeiner oder mehreren Farben oder sogar mit Texturen ausfüllen und wenn wir uns mit der oberen Schicht (die mit verwischter Kante) später befassen, können wir sie auf mehrere Arten zusammenfassen: zuerst durch Multiplikation....
<G-vec00623-002-s716><combine.zusammenfassen><en> You can combine several words with quotation marks into a search key.
<G-vec00623-002-s716><combine.zusammenfassen><de> Mit Anführungszeichen können Sie mehrere Worte zu einem Suchbegriff zusammenfassen.
<G-vec00623-002-s717><combine.zusammenfassen><en> In this statement, we also explain how we may combine Online Information with Other Information and how we then use the combined information.
<G-vec00623-002-s717><combine.zusammenfassen><de> Des Weiteren beschreiben wir in dieser Erklärung, wie wir Online-Informationen mit Sonstigen Informationen zusammenfassen können und wie wir diese Aggregierten Informationen dann verwenden.
<G-vec00623-002-s718><combine.zusammenfassen><en> New: The email task allows you to combine HTML emails.
<G-vec00623-002-s718><combine.zusammenfassen><de> Neu: Das E-Mail-Plugin kann jetzt auch HTML-E-Mails zusammenfassen.
<G-vec00623-002-s719><combine.zusammenfassen><en> - You can combine several Excel worksheets into a single document.
<G-vec00623-002-s719><combine.zusammenfassen><de> - Sie können mehrere Excel-Arbeitsblätter in einem einzigen Dokument zusammenfassen.
<G-vec00623-002-s720><combine.zusammenfassen><en> Depending on the organization of your company you can create one user for each sales agent, or combine several sales agents under one user.
<G-vec00623-002-s720><combine.zusammenfassen><de> Je nach Ihrer Unternehmensorganisation können Sie je Vertreter einen Benutzer anlegen oder mehrere Vertreter unter einem Benutzer zusammenfassen.
<G-vec00623-002-s721><combine.zusammenfassen><en> In Advanced mode, all these panels are available, you can drag them in any position, combine with other panels, scale them or minimize.
<G-vec00623-002-s721><combine.zusammenfassen><de> In dem Erweiterten Modus lassen sich alle Bedienfelder beliebig anordnen, mit anderen Bedienfelder zusammenfassen, skalieren und ein-/ausblenden.
<G-vec00623-002-s722><combine.zusammenführen><en> RF Combiner and Divider RF Combiner and Divider RF combiners and dividers, also known as combiners and splitters, are multi-port devices and modules that combine or split RF signals between a single port and the other ports.
<G-vec00623-002-s722><combine.zusammenführen><de> RF-Kombinator und Teiler RF-Kombinator und Teiler RF-Kombinatoren und Teiler, auch als Combiner und Splitter bekannt, sind Bauteile mit mehreren Anschlüssen und Modulen, die RF-Signale zwischen einem einzelnen Anschluss und anderen Anschlüssen zusammenführen oder splitten.
<G-vec00623-002-s723><combine.zusammenführen><en> We develop apps with an edutainment factor, which playfully combine real, historical, fantastic but also serious content with AR functions.
<G-vec00623-002-s723><combine.zusammenführen><de> Wir entwickeln Apps mit Edutainment Faktor, die mit AR-Funktionen reale, historische, fantastische aber auch ernste Inhalte spielerisch zusammenführen.
<G-vec00623-002-s724><combine.zusammenführen><en> Drag files or emails directly into the Combine Files interface.
<G-vec00623-002-s724><combine.zusammenführen><de> Ziehen Sie Dateien oder E-Mails direkt in die Schnittstelle „Dateien zusammenführen“.
<G-vec00623-002-s725><combine.zusammenführen><en> We may combine the Personal and Other Information collected on the Sites with information collected from or about you in other contexts.
<G-vec00623-002-s725><combine.zusammenführen><de> Wir können Persönliche und Sonstige Daten, die wir direkt von Ihnen erfassen, mit anderen Daten von Ihnen zusammenführen, die wir in einem anderen Zusammenhang erfasst haben, zum Beispiel auf den Seiten.
<G-vec00623-002-s726><combine.zusammenführen><en> Similarly, to combine a set of split files, drag one or more of the files onto Archiver and click Combine.
<G-vec00623-002-s726><combine.zusammenführen><de> Um geteilte Dateien zu kombinieren, bewege eines oder mehrere der Teile in Archiver und click "Zusammenführen".
<G-vec00623-002-s727><combine.zusammenführen><en> We are characterized by the fact that we combine our extensive technical knowledge with broad industry expertise and many years of experience.
<G-vec00623-002-s727><combine.zusammenführen><de> Uns zeichnet aus, dass wir unser umfangreiches, technisches Wissen mit einer breiten Branchenexpertise und langjähriger Erfahrung zusammenführen.
<G-vec00623-002-s728><combine.zusammenführen><en> In this statement, we also explain how we may combine Online Information with Other Information about you and how we then use the combined information.
<G-vec00623-002-s728><combine.zusammenführen><de> Des Weiteren beschreiben wir in dieser Erklärung, wie wir Online-Informationen mit Sonstigen Informationen zusammenführen und wie wir diese Zusammengeführten Informationen dann verwenden.
<G-vec00623-002-s729><combine.zusammenführen><en> It is possible to combine SSD and SATA/SAS disks and achieve much greater I/O performance while still maintaining larger capacity of the standard drives.
<G-vec00623-002-s729><combine.zusammenführen><de> Sie können Ihre SSD- und SATA/SAS-Laufwerke zusammenführen und so die maximale Kapazität UND die maximale I/O-Rate bekommen.
<G-vec00623-002-s730><combine.zusammenführen><en> According to the information provided by Google, however, Google will not combine the user's IP address with other data stored by the user.
<G-vec00623-002-s730><combine.zusammenführen><de> Google wird Ihre IP-Adresse jedoch nicht mit anderen von Ihnen gespeicherten Daten zusammenführen.
<G-vec00623-002-s732><combine.zusammenführen><en> If we combine demographic or similar information with the Personal Information we collect, we will treat the combined information as Personal Information under this Privacy Policy. Supplemented Data
<G-vec00623-002-s732><combine.zusammenführen><de> Wenn wir demographische oder ähnliche Informationen mit den von uns erfassten personenbezogenen Daten zusammenführen, behandeln wir die zusammengeführten Informationen als personenbezogene Daten laut dieser Datenschutzrichtlinie.
<G-vec00623-002-s733><combine.zusammenführen><en> We will also have told you for what purpose we will share and combine your data.
<G-vec00623-002-s733><combine.zusammenführen><de> Sie wurden dann ebenfalls darüber informiert, zu welchem Zweck wir Ihre Daten weitergeben oder zusammenführen.
<G-vec00623-002-s734><combine.zusammenführen><en> “The integration will combine two of the leading global industry players, which share a long-standing tradition of industrial culture, world-class innovation capabilities, and a strong leadership in their respective markets,” said Dr. Bernd Scheifele.
<G-vec00623-002-s734><combine.zusammenführen><de> “Die Integration wird zwei weltweit erfolgreiche Unternehmen der Branche zusammenführen, die beide über eine lange industrielle Tradition, erstklassige Innovationsfähigkeit und starke Stellungen in ihren jeweiligen Märkten verfügen“, sagt Dr. Bernd Scheifele.
<G-vec00623-002-s735><combine.zusammenführen><en> In the Quick Start section, click Combine Files.
<G-vec00623-002-s735><combine.zusammenführen><de> Klicken Sie im Schnellstartbereich auf Seiten zusammenführen.
<G-vec00623-002-s736><combine.zusammenführen><en> As part of the online advertising programmes your personal data may be shared with third parties, who will combine it with data that they hold about you in order to tailor adverts that appear on third-party websites (which may be our own adverts, or adverts we serve on behalf of third parties).
<G-vec00623-002-s736><combine.zusammenführen><de> Im Rahmen von Online-Werbeprogrammen können Ihre persönlichen Daten mit Dritten geteilt werden, die diese mit Ihren Daten über Sie zusammenführen, um Werbung, die auf Websites Dritter angezeigt wird, anzupassen (dies können unsere eigenen Anzeigen oder Anzeigen sein, die wir im Auftrag Dritter anbieten).
<G-vec00623-002-s737><combine.zusammenführen><en> Fiery FreeForm allows you to combine static and dynamic content to create a personalised printed document.
<G-vec00623-002-s737><combine.zusammenführen><de> Mit Fiery FreeForm können Sie statische und variable Inhalte zu einem personalisierten Druckerzeugnis zusammenführen.
<G-vec00623-002-s738><combine.zusammenführen><en> Combine files into a single PDF document, or create compact PDF packages.
<G-vec00623-002-s738><combine.zusammenführen><de> Zusammenführen von Dateien zu einem einzigen PDF-Dokument oder Erstellen kompakter PDF-Pakete.
<G-vec00623-002-s739><combine.zusammenführen><en> The Combine Files interface is displayed with the toolbar at the top.
<G-vec00623-002-s739><combine.zusammenführen><de> Die Schnittstelle „Dateien zusammenführen“ wird mit der Symbolleiste oben angezeigt.
