<G-vec01049-002-s475><close_in.einschließen><en> To contact your fairy hold the pendant in your hand, close your eyes and meditate for a few minutes about the guidance or help you need.
<G-vec01049-002-s475><close_in.einschließen><de> Um die Elfe zu kontaktieren, halte ihr Abbild in Deinen Händen, schließe die Augen und meditiere einige Minuten über die Führung oder Hilfestellung, die Du benötigst.
<G-vec01049-002-s476><close_in.einschließen><en> ⇒ Once the glass jar is full, fill with distilled water until all the shredded cabbage is covered and top with the two cabbage leaves, close the lid.
<G-vec01049-002-s476><close_in.einschließen><de> ⇒ Wenn der Glaskrug gefüllt und zusammen gepresst ist, fülle ihn mit dem destillierten Wasser auf, füge die noch ganzen Blätter hinzu und schließe das Ganze mit dem Deckel.
<G-vec01049-002-s477><close_in.einschließen><en> Rooms How can I close the bottom of the bath.
<G-vec01049-002-s477><close_in.einschließen><de> Zimmer Wie schließe ich den Boden des Bades.
<G-vec01049-002-s478><close_in.einschließen><en> Close your eyes and flip a coin.
<G-vec01049-002-s478><close_in.einschließen><de> Schließe deine Augen und wirf eine Münze.
<G-vec01049-002-s479><close_in.einschließen><en> Aham Brahma Asmi and Tat Tvam Asi. your Ishta Devata for a few minutes and close your eyes.
<G-vec01049-002-s479><close_in.einschließen><de> Betrachte das Bild deiner persönlichen Gottheit (IshtaDevata) ein paar Minuten lang und schließe die Augen.
<G-vec01049-002-s480><close_in.einschließen><en> Train your fighter, master blows and receptions, engage with faceless enemies and close a gate of shadows in Shadow fight 2.
<G-vec01049-002-s480><close_in.einschließen><de> Trainiere deinen Kämpfer, erlerne Schläge und Techniken, bekämpfe die gesichtslosen Feinde und schließe das Schattentor im Spiel Shadow fight 2.
<G-vec01049-002-s481><close_in.einschließen><en> If possible, close your eyes for a moment and ask what it is.
<G-vec01049-002-s481><close_in.einschließen><de> 5Wenn möglich, schließe deine Augen einen Augenblick und frage, was es ist.
<G-vec01049-002-s482><close_in.einschließen><en> Must last until I close December.
<G-vec01049-002-s482><close_in.einschließen><de> Muss reichen, bis ich Dezember schließe.
<G-vec01049-002-s483><close_in.einschließen><en> Close your eyes, shut out the rest of the world, and think about your affirmations.
<G-vec01049-002-s483><close_in.einschließen><de> Schließe Deine Augen, ziehe Dich vom Rest der Welt zurück und denke über Deine Affirmationen nach.
<G-vec01049-002-s484><close_in.einschließen><en> To resolve this issue, please close and restart Destiny to initiate your update.
<G-vec01049-002-s484><close_in.einschließen><de> Um diesen Fehler zu beheben, schließe Destiny und starte es erneut, um das Update zu beginnen.
<G-vec01049-002-s485><close_in.einschließen><en> 6 Add the right kind of washing fluid and close the door.
<G-vec01049-002-s485><close_in.einschließen><de> Gib die richtige Art von Waschmittel in die Trommel und schließe die Tür.
<G-vec01049-002-s486><close_in.einschließen><en> 6 Close the Settings tab.
<G-vec01049-002-s486><close_in.einschließen><de> Schließe den Tab "Einstellungen".
<G-vec01049-002-s487><close_in.einschließen><en> I will close with another example of institutionalized "intersectional" feminism in action: Alicia's Iraqi parents took her to Sweden when she was four.
<G-vec01049-002-s487><close_in.einschließen><de> Ich schließe mit einem weiteren Beispiel für institutionalisierten "intersektionellen" Feminismus in Aktion: Alicias irakische Eltern brachten sie mit vier Jahren nach Schweden.
<G-vec01049-002-s488><close_in.einschließen><en> I sit in the open jeep and close my eyes for a moment.
<G-vec01049-002-s488><close_in.einschließen><de> Ich sitze im offenen Jeep und schließe für einen Moment die Augen.
<G-vec01049-002-s489><close_in.einschließen><en> When you wake up and remember your dream, write it down in your dream journal, then close your eyes and focus on the dream.
<G-vec01049-002-s489><close_in.einschließen><de> Wenn du aufwachst und dich an deinen Traum erinnerst, dann schreibe es in deinem Traumtagebuch auf, schließe dann die Augen erneut und konzentriere dich auf den Traum.
<G-vec01049-002-s490><close_in.einschließen><en> Click on the Facebook share icon and remember to close the window that now opens.
<G-vec01049-002-s490><close_in.einschließen><de> Klick auf die Teilen-Funktion für Facebook, schließe das sich öffnende Fenster aber wieder.
<G-vec01049-002-s491><close_in.einschließen><en> Before I close I will give you a loose guideline for a happily abundant life.
<G-vec01049-002-s491><close_in.einschließen><de> Bevor ich schließe, werde euch eine lose Leitlinie für ein glückliches Leben der Fülle geben.
<G-vec01049-002-s492><close_in.einschließen><en> Close the door as much as possible and look for uneven lines.
<G-vec01049-002-s492><close_in.einschließen><de> Schließe die Tür so weit es eben geht und schau nach Unebenheiten.
<G-vec01049-002-s493><close_in.einschließen><en> Now, close your eyes (after you're done reading this) and imagine Hollywood movie sets, beautiful historic districts, or foreign and exotic locales teeming with vibrant and interesting people who hang on your every word.
<G-vec01049-002-s493><close_in.einschließen><de> Schließe nun die Augen (nachdem du den Artikel zu Ende gelesen hast) und stell dir die Kulissen in Hollywood vor, schöne historische Stadtteile, oder fremde und exotische Lokalitäten, voll lebendiger und interessanter Leute, die an deinen Lippen hängen.
<G-vec01049-002-s494><close_in.einschließen><en> The upcoming twelfth Tolkien Seminar of the German Tolkien Society is set to close this gap with a variety of papers.
<G-vec01049-002-s494><close_in.einschließen><de> Dem wird das kommende zwölfte Tolkien-Seminar der Deutschen Tolkien Gesellschaft mit einer Reihe von Vorträgen nachkommen, die diese Lücke schließen helfen.
<G-vec01049-002-s495><close_in.einschließen><en> Open the lid of the ground coffee chute for at least 5 seconds and then close it again.
<G-vec01049-002-s495><close_in.einschließen><de> Öffnen Sie den Deckel des Pulverschachts für mindestens 5 Sekunden und schließen Sie ihn danach wieder.
<G-vec01049-002-s496><close_in.einschließen><en> Close the doors of the car and after a few minutes all the contents inside the car have been emptied.
<G-vec01049-002-s496><close_in.einschließen><de> Türen des Wagens schließen und nach wenigen Minuten hat sich der gesamte Inhalt im Wageninneren entleert.
<G-vec01049-002-s497><close_in.einschließen><en> Setup is complete now and you can go to the Garmin portal to get familiar with the program and to enter your personal settings, or you can close the window.
<G-vec01049-002-s497><close_in.einschließen><de> Die Konfiguration ist abgeschlossen und Sie können jetzt zum Garmin Portal gehen und sich mit dem Programm vertraut machen sowie Ihre individuellen Einstellungen vornehmen oder das Fenster schließen.
<G-vec01049-002-s498><close_in.einschließen><en> The owners of Mantic Forums reserve the right to remove, edit, move or close any content item for any reason. Contact Us Mantic Games
<G-vec01049-002-s498><close_in.einschließen><de> Die Eigentümer von STAR TREK Online Info - Das Deutsche STO Community Forum haben das Recht, Themen und Beiträge zu löschen, zu bearbeiten, zu verschieben oder zu schließen.
<G-vec01049-002-s499><close_in.einschließen><en> The titanic three—Google, Facebook and Apple—have access to most of that data, and their army of engineers still haven’t managed to completely close that gap.
<G-vec01049-002-s499><close_in.einschließen><de> Obwohl die drei Giganten Google, Facebook und Apple Zugriff auf einen Großteil dieser Daten haben, hat es ihr Heer an Ingenieuren immer noch nicht fertig gebracht, diese Lücke vollständig zu schließen.
<G-vec01049-002-s500><close_in.einschließen><en> Close straps prior to washing.
<G-vec01049-002-s500><close_in.einschließen><de> Verschlüsse zum Waschen schließen.
<G-vec01049-002-s501><close_in.einschließen><en> When the plants grow to a height of 10 cm, they need to mow and close up in the soil.
<G-vec01049-002-s501><close_in.einschließen><de> Wenn die Pflanzen eine Höhe von 10 cm erreichen, müssen sie im Boden mähen und sich schließen.
<G-vec01049-002-s502><close_in.einschließen><en> (2) The users oblige to close contracts only through BAGEMA.
<G-vec01049-002-s502><close_in.einschließen><de> (2) Die Nutzer verpflichten sich Verträge nur über BAGEMA zu schließen.
<G-vec01049-002-s503><close_in.einschließen><en> The owners of RC Forumz - Dedicated to RC Discussions reserve the right to remove, edit, move or close any content item for any reason.
<G-vec01049-002-s503><close_in.einschließen><de> Die Eigentümer von Bym.de-Community haben das Recht, Themen und Beiträge zu löschen, zu bearbeiten, zu verschieben oder zu schließen.
<G-vec01049-002-s504><close_in.einschließen><en> The owners of this forum reserve the right to remove, edit, move or close any thread for any reason.
<G-vec01049-002-s504><close_in.einschließen><de> Die Eigentümer von GIMP-Forum 3.0 haben das Recht, Themen und Beiträge zu löschen, zu bearbeiten, zu verschieben oder zu schließen.
<G-vec01049-002-s505><close_in.einschließen><en> After the digital revolution, these companies were not able to compete against digital TV and online videos and had to close one after the other.
<G-vec01049-002-s505><close_in.einschließen><de> Nach der digitalen Revolution (digitales Fernsehen und Online-Videos) waren diese Betriebe nicht mehr konkurrenzfähig und mussten nach und nach schließen.
<G-vec01049-002-s506><close_in.einschließen><en> To contact emergency services providers from your device, close Lync for iPad, and use your device’s dial pad.
<G-vec01049-002-s506><close_in.einschließen><de> Schließen Sie zum Kontaktieren eines Anbieters für Notfalldienste Lync für iPhone, und verwenden Sie die Wähltastatur Ihres Geräts.
<G-vec01049-002-s507><close_in.einschließen><en> Allthough we never had to overcome a step when we had to get to the toilets it has been really narrow every single time. I really did need help because there were no handholds and I could not get into the toilet with my wheelchair because then I could not close the door anymore.
<G-vec01049-002-s507><close_in.einschließen><de> Man musste zwar nie eine Stufe überwinden - zum Glück - aber es war eng und ich war immer auf Hilfe angewiesen denn es gab auch keine Haltegriffe und ich konnte nicht direkt zum WC reinfahren denn dann hätte man die Türe nicht mehr schließen können.
<G-vec01049-002-s508><close_in.einschließen><en> As an emissions-free, purely electric-driven car sharing solution, SVEN should close the gap between personal and public transportation.
<G-vec01049-002-s508><close_in.einschließen><de> Es soll als emissionsfreie, rein elektrische betriebene Carsharing-Lösung die Lücke zwischen Individual- und öffentlichem Personennahverkehr schließen.
<G-vec01049-002-s509><close_in.einschließen><en> To do this, open OneNote 2016 for Windows, click the arrow next to your notebook name, find the notebook you deleted, right-click it, and choose Close This Notebook.
<G-vec01049-002-s509><close_in.einschließen><de> Dazu öffnen Sie OneNote 2016 für Windows, klicken Sie auf den Pfeil neben dem Notizbuchnamen, suchen Sie das Notizbuch, das Sie gelöscht haben, klicken Sie mit der rechten Maustaste darauf, und wählen Sie Dieses Notizbuch schließen aus.
<G-vec01049-002-s510><close_in.einschließen><en> You will have to close all the necessary facilities: Commercial Centre La Valentine, Restaurants, Cinema, Pub and small businesses (bakery, et accueil parfait .
<G-vec01049-002-s510><close_in.einschließen><de> Sie haben alle notwendigen Einrichtungen zu schließen: Einkaufszentrum La Valentine, Restaurants, Kino, Pub und kleine Unternehmen (Bäckerei, Kiosk,...) und in der Nähe von Scharen von kleinen Dörfern der Provence: Aubagne (Stadt von Marcel Pagnol) Allauch....
<G-vec01049-002-s511><close_in.einschließen><en> Use the ◄/► buttons for adjustment. To close the dialog and complete this operation, press KEYSTONE button again.
<G-vec01049-002-s511><close_in.einschließen><de> Verwenden Sie die Cursortasten ▲/▼zur Korrektur der Verzerrung.Drücken Sie die KEYSTONE-Taste erneut zum Schließen des Dialogs und Beenden dieses Vorgangs.
<G-vec01049-002-s512><close_in.einschließen><en> FileMaker Pro Advanced allows you to prompt networked clients to close the shared file when you close the file, change the sharing conditions for the file, exit FileMaker Pro Advanced, or perform a task that requires all clients to close the file.
<G-vec01049-002-s512><close_in.einschließen><de> FileMaker Pro gibt Ihnen die Möglichkeit, Clients im Netzwerk aufzufordern, die gemeinsam genutzte Datei zu schließen, wenn Sie die Datei schließen, die Sharing-Voraussetzungen für die Datei ändern, FileMaker Pro beenden oder eine Aufgabe ausführen, für die alle Clients die Datei schließen müssen.
<G-vec01049-002-s513><close_in.einschließen><en> Close the roulade.
<G-vec01049-002-s513><close_in.einschließen><de> Schließen Sie die Roulade.
<G-vec01049-002-s514><close_in.einschließen><en> Close the flag design without saving any changes.
<G-vec01049-002-s514><close_in.einschließen><de> Schließen Sie den „Flag“-Entwurf, ohne Änderungen zu speichern.
<G-vec01049-002-s515><close_in.einschließen><en> C Close the scanner unit .
<G-vec01049-002-s515><close_in.einschließen><de> D Schließen Sie langsam die Scannereinheit.
<G-vec01049-002-s516><close_in.einschließen><en> Close the window "Prioritize Application".
<G-vec01049-002-s516><close_in.einschließen><de> Schließen Sie das Fenster "Belegwünsche priorisieren".
<G-vec01049-002-s517><close_in.einschließen><en> Open and close the front cover to resume printing.
<G-vec01049-002-s517><close_in.einschließen><de> Öffnen und schließen Sie die obere Abdeckung, und öffnen Sie dann schnell das Ausgabefach.
<G-vec01049-002-s518><close_in.einschließen><en> Close the box and tape it securely.
<G-vec01049-002-s518><close_in.einschließen><de> Schließen Sie den Karton und kleben Sie ihn mit Klebeband sicher zu.
<G-vec01049-002-s519><close_in.einschließen><en> Send a document from Paris, sign it in Tokyo, and close business in minutes.
<G-vec01049-002-s519><close_in.einschließen><de> Versenden Sie ein Dokument aus Paris, unterschreiben Sie es in Tokio oder San Francisco und schließen Sie Geschäfte in Minuten ab.
<G-vec01049-002-s520><close_in.einschließen><en> Close the Programs window, and the Control Panel window.
<G-vec01049-002-s520><close_in.einschließen><de> Schließen Sie das Fenster Software und die Systemsteuerung.
<G-vec01049-002-s521><close_in.einschließen><en> Close User Manager.
<G-vec01049-002-s521><close_in.einschließen><de> Schließen Sie den Benutzer-Manager.
<G-vec01049-002-s522><close_in.einschließen><en> Close the window Local Security Policy (Windows Vista) / Local Security Settings (Windows XP).
<G-vec01049-002-s522><close_in.einschließen><de> Schließen Sie das Fenster Lokale Sicherheitsrichtlinie (Windows Vista) / Lokale Sicherheitseinstellungen (Windows XP).
<G-vec01049-002-s523><close_in.einschließen><en> Place the grow kit without the lid inside the plastic bag and close the bag by folding the top, you can fasten this with the 2 paperclips.
<G-vec01049-002-s523><close_in.einschließen><de> Legen Sie den Cubenisanbaukasten ohne den Deckel innerhalb der Plastiktasche und schließen Sie die Tasche, indem Sie die Spitze falten; Sie können das mit 2 Hefklammern befestigen.
<G-vec01049-002-s524><close_in.einschließen><en> Close the window when you are done.
<G-vec01049-002-s524><close_in.einschließen><de> Schließen Sie das Fenster, wenn Sie fertig sind.
<G-vec01049-002-s525><close_in.einschließen><en> Close the shutter by pulling at the key.
<G-vec01049-002-s525><close_in.einschließen><de> Schließen Sie die Klappe, indem Sie am Schlüssel ziehen.
<G-vec01049-002-s526><close_in.einschließen><en> Click "Ok" and close the Services app window.
<G-vec01049-002-s526><close_in.einschließen><de> Klicken Sie auf "OK" und schließen Sie das Service-App-Fenster.
<G-vec01049-002-s527><close_in.einschließen><en> Use our wire racks to keep your wine in order and close at hand.
<G-vec01049-002-s527><close_in.einschließen><de> Benutzen Sie unsere Drahtgitter, um Ihren Wein im Auftrag zu halten und schließen Sie zur Hand.
<G-vec01049-002-s528><close_in.einschließen><en> Close the dialog box.
<G-vec01049-002-s528><close_in.einschließen><de> Schließen Sie das Dialogfeld.
<G-vec01049-002-s529><close_in.einschließen><en> Close the Preferences window.
<G-vec01049-002-s529><close_in.einschließen><de> Schließen Sie das Fenster Einstellungen.
<G-vec01049-002-s530><close_in.einschließen><en> Now close the dialog box.
<G-vec01049-002-s530><close_in.einschließen><de> Schließen Sie nun das Dialogfeld.
<G-vec01049-002-s531><close_in.einschließen><en> Close the error message pop-up window and Qlik NPrinting Designer.
<G-vec01049-002-s531><close_in.einschließen><de> Schließen Sie das Popup-Fenster mit der Fehlermeldung und Qlik NPrinting Designer.
