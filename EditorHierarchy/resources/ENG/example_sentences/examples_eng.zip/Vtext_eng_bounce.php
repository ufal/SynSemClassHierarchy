<G-vec00109-002-s207><bounce.springen><en> Without BGP, IP packets would bounce around the Internet randomly from AS to AS, like a driver trying to reach their destination by guessing which roads to take.
<G-vec00109-002-s207><bounce.springen><de> Ohne BGP würden IP-Pakete im Internet wahllos von AS zu AS hin und her springen, wie ein Fahrer, der versucht, sein Ziel zu erreichen, indem er aufs Geratewohl entscheidet, welche Straße er nehmen muss.
<G-vec00109-002-s208><bounce.springen><en> The spring will allow the swing to gently bounce while swinging.
<G-vec00109-002-s208><bounce.springen><de> Die Feder erlaubt der Schaukel während dem Schwingen auch leichtes Springen.
<G-vec00109-002-s209><bounce.springen><en> When you dribble, bounce the ball no higher than your waist.
<G-vec00109-002-s209><bounce.springen><de> Wenn Du dribbelst, lasse den Ball nie höher als Deine Hüfte springen.
<G-vec00109-002-s210><bounce.springen><en> USDCHF is close to the lower bound of a rising channel that has been in place for the past two months and could well bounce from there.
<G-vec00109-002-s210><bounce.springen><de> Das Währungspaar USD/CHF liegt in der Nähe der unteren Grenze eines aufsteigenden Kanals, der bereits die vergangenen zwei Monate besteht, und könnte sehr gut von dort aus springen.
<G-vec00109-002-s211><bounce.springen><en> new CAN'T STOP ME PART 2 If R - Pyroclasm tries to bounce to a target that becomes untargetable, it'll seek out a new target instead of fizzling out on the spot Smite (Twisted Treeline)
<G-vec00109-002-s211><bounce.springen><de> neu NICHTS HÄLT MICH AUF, TEIL 2 Falls R – Pyroklasmus versucht, zu einem Ziel zu springen, das plötzlich nicht ins Ziel genommen werden kann, sucht es sich ein anderes Ziel, anstatt an Ort und Stelle im Sand zu verlaufen.
<G-vec00109-002-s212><bounce.springen><en> Cars were swerving in both directions, drivers not knowing which direction the tire would bounce next.
<G-vec00109-002-s212><bounce.springen><de> Die Autos wichen in beide Richtungen aus, denn die Fahrer wussten nicht, wohin der Reifen als Nächstes springen würde.
<G-vec00109-002-s213><bounce.springen><en> The keyboard arrow keys to move Mario, you can bounce with the space key.
<G-vec00109-002-s213><bounce.springen><de> Die Pfeiltasten auf der Tastatur, um Mario zu bewegen, können Sie mit der Leertaste springen.
<G-vec00109-002-s214><bounce.springen><en> Fish Bounce is one of our selected Cat Games.
<G-vec00109-002-s214><bounce.springen><de> Fisch Springen ist eins unserer ausgewählten Katzen Spiele.
<G-vec00109-002-s215><bounce.springen><en> BEATTY: Well, I've seen fire bend around corners, seen it bounce like a rubber ball.
<G-vec00109-002-s215><bounce.springen><de> FAILEY: Wissen sie, ich haben Feuer um Ecken biegen sehen, ich sah es springen wie einen Gummiball.
<G-vec00109-002-s216><bounce.springen><en> Whilst I was away my bunnies grew up fast – they are now five times the size from when they were born only two weeks ago and bounce around my lounge with endless energy.
<G-vec00109-002-s216><bounce.springen><de> Während ich weg war, sind meine Kaninchen schnell groß geworden – sie sind nun fünfmal so groß wie bei ihrer Geburt und springen mit endloser Energie in meiner Lounge herum.
<G-vec00109-002-s217><bounce.springen><en> It detects and minimizes machine bounce by automatically controlling the throttle during operation, with no operator intervention required.
<G-vec00109-002-s217><bounce.springen><de> Sie erkennt und minimiert ein Springen der Maschine durch automatische Drosselklappenregelung während des Betriebs, ohne dass der Fahrer eingreifen müsste.
<G-vec00109-002-s218><bounce.springen><en> Rubber band balls are extremely dense, so after a certain point they'll be too heavy to bounce without breaking something.
<G-vec00109-002-s218><bounce.springen><de> Gummibandbälle sind extrem dicht, also sind sie über einen bestimmten Punkt hinaus zu schwer, um zu springen, ohne etwas kaputt zu machen.
<G-vec00109-002-s219><bounce.springen><en> Air Space is offering booking sessions online for the team games – crazy jumping, beat the bulge and get fit, improve trampoline skills, boogie while you bounce.
<G-vec00109-002-s219><bounce.springen><de> Air Space bietet Online-Buchungssitzungen für die Mannschaftsspiele an - verrücktes Springen, Ausbeulen und Fit werden, Trampolin-Fähigkeiten verbessern, Boogie, während Sie springen.
<G-vec00109-002-s220><bounce.springen><en> The white decor helps prevent the room from appearing harsh and really allows the light to bounce into the room.
<G-vec00109-002-s220><bounce.springen><de> Der weiße Dekor verhindert, dass der Raum hart erscheint und lässt das Licht in den Raum springen.
<G-vec00109-002-s221><bounce.springen><en> The yellow bubbles show the way to Dragee’s lair where he is waiting to lead the kids in active programmes where they can bounce, swim, and play with other kids their age.
<G-vec00109-002-s221><bounce.springen><de> Seine Gelben Blasen zeigen, wo die Kinder die aktiven, sportlichen Programme finden, bei denen sie nach Lust und Laune mit den anderen springen, schwimmen, Ball spielen können.
<G-vec00109-002-s222><bounce.springen><en> Some teachers bounce back and forth between topics.
<G-vec00109-002-s222><bounce.springen><de> Manche Lehrer springen zwischen Themen vor und zurück.
<G-vec00109-002-s223><bounce.springen><en> It really does not need to be even more stressful by forcing travelers to bounce back and forth between many websites, apps, and telephone calls.
<G-vec00109-002-s223><bounce.springen><de> Es muss wirklich nicht noch stressiger sein, wenn Reisende gezwungen werden, zwischen vielen Websites, Apps und Telefonanrufen hin und her zu springen.
<G-vec00109-002-s224><bounce.springen><en> In other words, visitors and customers who visit your landing page bounce off, before they even give you a chance to convert them.
<G-vec00109-002-s224><bounce.springen><de> In anderen Worten, die Besucher und Kunden, die Deine Landing Page besuchen, springen ab, bevor Du überhaupt die Chance auf eine Conversion hast.
<G-vec00109-002-s225><bounce.springen><en> You can sit on it, bounce on it and enjoy unique, intense pleasures.
<G-vec00109-002-s225><bounce.springen><de> Sie können sich darauf setzen oder springen und ebenso originelle wie intensive Sexsitzungen genießen.
<G-vec00109-002-s226><bounce.springen><en> With stronger bungees, the deceleration phase is shorter and you tend to bounce higher above the mat.
<G-vec00109-002-s226><bounce.springen><de> Bei stärkeren Seilringen wird die Abbremsphase dagegen kürzer, man springt mehr nach oben von der Matte ab.
<G-vec00109-002-s227><bounce.springen><en> Too stiff, or stiff in the wrong places, and it wants to ricochet and bounce, instead of float and flow.
<G-vec00109-002-s227><bounce.springen><de> Zu steif oder steif an den falschen Stellen und das Fahrwerk schlägt aus und springt, anstatt zu schweben und zu gleiten.
<G-vec00109-002-s228><bounce.springen><en> Note Apply pressure to corner with right-hand thumb when opening or closing load lever - otherwise lever will bounce back (as a mouse trap) causing bent contacts.
<G-vec00109-002-s228><bounce.springen><de> Druck auf die Ecke mit dem rechten Daumen beim Öffnen oder Schließen des Last Hebels auftragen-sonst springt der Hebel zurück (als Maus Falle), was zu gebogenen Kontakten führt.
<G-vec00109-002-s229><bounce.springen><en> With springs but no shock absorbers, the vehicle is able to absorb bumps, but the undampened suspension means that the vehicle continues to bounce and causes the tyres to leave the road.
<G-vec00109-002-s229><bounce.springen><de> Mit Federn, aber ohne Stoßdämpfer, ist das Fahrzeug in der Lage, Stöße zu absorbieren, aber die ungedämpfte Federung führt dazu, dass das Fahrzeug weiter springt und die Räder die Bodenhaftung verlieren.
