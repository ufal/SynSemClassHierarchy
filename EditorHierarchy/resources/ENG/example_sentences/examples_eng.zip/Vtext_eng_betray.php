<G-vec00671-002-s025><betray.ausliefern><en> So from that time he sought opportunity to betray Him.
<G-vec00671-002-s025><betray.ausliefern><de> 16 Und von da an suchte er eine Gelegenheit, dass er ihn ausliefere.
<G-vec00671-002-s026><betray.ausliefern><en> Reclining at table with his disciples, Jesus was deeply troubled and testified, "Amen, amen, I say to you, one of you will betray me."
<G-vec00671-002-s026><betray.ausliefern><de> Nach diesen Worten wurde Jesus im Geiste erschüttert und bezeugte: Amen, amen, ich sage euch: Einer von euch wird mich ausliefern.
<G-vec00671-002-s027><betray.ausliefern><en> 2 The evening meal was in progress, and the devil had already prompted Judas, the son of Simon Iscariot, to betray Jesus.
<G-vec00671-002-s027><betray.ausliefern><de> 2 Es fand ein Mahl statt und der Teufel hatte Judas, dem Sohn des Simon Iskariot, schon ins Herz gegeben, ihn auszuliefern.
<G-vec00671-002-s029><betray.ausliefern><en> 16 And from that moment he sought an opportunity to betray him.
<G-vec00671-002-s029><betray.ausliefern><de> Von da an suchte er nach einer Gelegenheit, ihn auszuliefern.
<G-vec00671-002-s057><betray.ausliefern><en> 10 And then many will fall away and betray one another and hate one another.
<G-vec00671-002-s057><betray.ausliefern><de> 10 Und viele werden zu Fall kommen und einander ausliefern und einander hassen.
<G-vec00671-002-s058><betray.ausliefern><en> 12Now the brother shall betray the brother to death, and the father the son; and children shall rise up against [their] parents, and shall cause them to be put to death.
<G-vec00671-002-s058><betray.ausliefern><de> 12 Brüder werden einander dem Tod ausliefern und Väter ihre Kinder, und die Kinder werden sich gegen ihre Eltern auflehnen und sie in den Tod schicken.
<G-vec00671-002-s071><betray.ausliefern><en> 16 And from that moment he sought an opportunity to betray him.
<G-vec00671-002-s071><betray.ausliefern><de> Von da an suchte er nach einer günstigen Gelegenheit, ihn auszuliefern.
<G-vec00671-002-s086><betray.ausliefern><en> 12 Now the brother shall betray the brother to death, and the father the son; and children shall rise up against their parents, and shall cause them to be put to death.
<G-vec00671-002-s086><betray.ausliefern><de> 12 Und ein Bruder wird seinen Bruder zum Tode ausliefern und ein Vater sein Kind, und Kinder werden sich gegen ihre Eltern erheben und sie töten.
<G-vec00671-002-s024><betray.ausnutzen><en> We all share information about ourselves with others, trusting they will not betray us with that knowledge.
<G-vec00671-002-s024><betray.ausnutzen><de> Wir alle teilen Informationen über uns selbst mit anderen, im Vertrauen, dass dieses Wissen nicht von den anderen ausgenutzt wird.
<G-vec00671-002-s095><betray.begehen><en> But in this way, they removed the real problem facing revolutionaries in coming to grips with what happened in Russia: the need to understand that proletarian organisations can degenerate and even betray under the enormous pressure of the existing social order and its ideology.
<G-vec00671-002-s095><betray.begehen><de> Doch auf diese Weise entledigten sie sich des wahren Problems, mit dem Revolutionäre konfrontiert waren, wenn sie sich mit dem auseinandersetzten, was in Russland geschehen war: die Notwendigkeit zu verstehen, dass proletarische Organisationen unter dem enormen Druck der existierenden Ordnung und ihrer Ideologie degenerieren, ja sogar Verrat begehen können.
<G-vec00671-002-s034><betray.betrügen><en> He accepted Islam as a matter of formality, though he would later betray the Muslims as the leader of the ‘hypocrites.’
<G-vec00671-002-s034><betray.betrügen><de> Er nahm formell den Islam an, aber später betrog er die Muslime als der Führer der "Heuchler".
<G-vec00671-002-s035><betray.betrügen><en> She did not betray me, for my imagination had already pictured everything that she has done.
<G-vec00671-002-s035><betray.betrügen><de> Sie hat mich nicht betrogen, denn meine Phantasie hat alles was sie getan hat, sich längst vorgestellt gehabt .
<G-vec00671-002-s036><betray.betrügen><en> I could not betray her with any other girl.
<G-vec00671-002-s036><betray.betrügen><de> Noch nie habe ich sie mit einem anderen Mädchen betrogen.
<G-vec00671-002-s037><betray.betrügen><en> Maybe he didn’t actually betray you, but the circumstances of life simply brought distance into what once was a close relationship, and so you feel betrayed.
<G-vec00671-002-s037><betray.betrügen><de> Möglicherweise hat er dich nicht wirklich betrogen, aber die Umstände des Lebens brachten einfach Distanz in eine enge Beziehung hinein und so fühlst du dich betrogen oder verraten.
<G-vec00671-002-s038><betray.betrügen><en> If you believe in something or someone and they betray you or disappoint you, it can be very painful and it can often have fatal consequences.
<G-vec00671-002-s038><betray.betrügen><de> Wenn du an etwas oder jemanden glaubst und dann betrogen und enttäuscht wirst, dann schmerzt das nicht nur, sondern kann oftmals auch fatale Konsequenzen mit sich bringen.
<G-vec00671-002-s039><betray.betrügen><en> Sometimes in collaboration with Yu Chunyan, Xiao Lihua and Zhang Jing, they used the so-called verdict to force the practitioner to "confess," to enter guilty pleas or betray their fellow practitioners.
<G-vec00671-002-s039><betray.betrügen><de> Manchmal setzten sie in Zusammenarbeit mit Yu Chunyan, Xiao Lihua und Zhang Jing das sogenannte Verdikt ein, Praktizierende zum „Beichten“ zu zwingen, Schuldanerkenntnisse einzugehen oder ihre Mitpraktizierenden zu betrügen.
<G-vec00671-002-s040><betray.betrügen><en> We note that the evildoers want the students to"make a clean break" and "confess without being prompted," betray their friends, and also "persuade other practitioners to give up Falun Gong" by citing ones so-called experience.
<G-vec00671-002-s040><betray.betrügen><de> Wir merken an, dass der Wunsch der Übeltäter ist, dass die Studenten einen „klaren Bruch“ machen, dass sie „gestehen ohne gefragt zu werden“, dass sie ihre Freunde betrügen und auch dass sie „andere Praktizierende überreden, Falun Gong aufzugeben“ indem sie ihre eigene so genannte Erfahrung erzählen.
<G-vec00671-002-s041><betray.betrügen><en> Yosuke Saito: I said this several times and on different occasions: We don’t want to betray our fans.
<G-vec00671-002-s041><betray.betrügen><de> Yosuke Saito: Ich habe es schon mehrere Male zu unterschiedlichen Gelegenheiten gesagt: Wir werden unsere Fans nicht betrügen.
<G-vec00671-002-s042><betray.betrügen><en> You have suppressed Barbara's comments, and in my opinion, you even betray new readers with it, too, because you present comments to them that once read differently; very important parts are missing.
<G-vec00671-002-s042><betray.betrügen><de> Sie haben Barbaras Kommentare unterschlagen und Sie betrügen damit meines Erachtens sogar auch die neuen Leserinnen und Leser, weil sie ihnen Kommentare vorlegen, die einmal anders gelautet haben; es fehlen sehr wichtige Teile.
<G-vec00671-002-s043><betray.betrügen><en> In reality, we are prisoners - the missionary continues – pretending to be free, to move, talk, act and betray.
<G-vec00671-002-s043><betray.betrügen><de> In Wirklichkeit sind wir die Geiseln“, so der Missionar weiter, „wir sind nur dem Anschein nach frei und können uns bewegen, sprechen, handeln und betrügen.
<G-vec00671-002-s044><betray.betrügen><en> It would be extremely tragic if in front of me, and, when I am giving the guidance, a person pretends to comply, only to betray hypocrisy when dealing with the reality.
<G-vec00671-002-s044><betray.betrügen><de> Es wäre äußerst tragisch, wenn eine Person vor mir, während ich die Führung gebe, vortäuscht zuzustimmen, nur um in Wirklichkeit heuchlerisch zu betrügen.
<G-vec00671-002-s045><betray.betrügen><en> She could not betray me.
<G-vec00671-002-s045><betray.betrügen><de> Mich konnte sie nicht betrügen.
<G-vec00671-002-s046><betray.betrügen><en> Jiang Zemin has used money and personal benefits as bait to induce people to betray their conscience.
<G-vec00671-002-s046><betray.betrügen><de> Jiang Zemin hat Geld und persönliche Vorteile als Köder verwendet, um die Menschen dazu zu bringen ihre Gewissen zu betrügen.
<G-vec00671-002-s047><betray.betrügen><en> You are the Creator, and I am a creature: I should not betray You and live under the domain of Satan, nor should I be exploited by Satan.
<G-vec00671-002-s047><betray.betrügen><de> Du bist der Schöpfer und ich bin ein Geschöpf: Ich sollte Dich nicht betrügen und unter der Domäne Satans leben, noch sollte ich mich von Satan ausnutzen lassen.
<G-vec00671-002-s048><betray.betrügen><en> It was impossible for Mr. Niu Xigong to betray Falun Gong, from which he had benefitted so much, as he knew that Falun Gong had given him a second life.
<G-vec00671-002-s048><betray.betrügen><de> Es kam für Herrn Niu nicht in Frage Falun Gong zu betrügen, weil er erstens sehr viele Vorteile davon erfuhr und zweitens dadurch ein zweites Leben bekam.
<G-vec00671-002-s049><betray.betrügen><en> We can betray our brain by persuading ourselves: That doesn’t matter.
<G-vec00671-002-s049><betray.betrügen><de> Unseren Verstand können wir betrügen, indem wir uns einreden: Das macht doch nichts.
<G-vec00671-002-s050><betray.betrügen><en> You betray us both with your actions.
<G-vec00671-002-s050><betray.betrügen><de> Ihr betrügt uns beide mit Euren Taten.
<G-vec00671-002-s076><betray.hintergehen><en> Asked why they did not use classic placebos, respondents said they did not want to betray patients.
<G-vec00671-002-s076><betray.hintergehen><de> Auf die Frage, warum sie keine klassischen Placebos einsetzen, gaben die Befragten an, sie würden die Patienten nicht hintergehen wollen.
<G-vec00671-002-s077><betray.hintergehen><en> They can only deceive Him, blaspheme against Him, and betray Him, and all that they live out reveals the nature of Satan.
<G-vec00671-002-s077><betray.hintergehen><de> Sie können Ihn nur betrügen, gegen Ihn lästern und Ihn hintergehen, und alles, was sie ausleben, offenbart die Natur Satans.
<G-vec00671-002-s078><betray.hintergehen><en> We work with the architecture and the history of the venues and influence, transform and betray urban structures.
<G-vec00671-002-s078><betray.hintergehen><de> Wir arbeiten mit der Architektur und Geschichte unserer Spielorte und beeinflussen, transformieren und hintergehen urbane Strukturen.
<G-vec00671-002-s089><betray.sein><en> O you who have believed, do not betray Allah and the Messenger or betray your trusts while you know [the consequence].
<G-vec00671-002-s089><betray.sein><de> O die ihr glaubt, handelt nicht untreu gegen Allah und den Gesandten, noch seid wissentlich untreu in eurer Treuhandschaft.
<G-vec00671-002-s021><betray.verraten><en> These days, there are many people who do evil and betray their parents’ grace.
<G-vec00671-002-s021><betray.verraten><de> Heutzutage gibt es viele Menschen, die ihren Eltern Böses antun und ihre Güte verraten.
<G-vec00671-002-s031><betray.verraten><en> As she could think of no way to guess the riddle, she ordered her maid to steal at night into the Prince's bedroom and to listen, for she thought that he might perhaps talk aloud in his dreams and so betray the secret.
<G-vec00671-002-s031><betray.verraten><de> Da sie sich nicht zu helfen wußte, befahl sie ihrer Magd, in das Schlafgemach des Herrn zu schleichen, da sollte sie seine Träume behorchen, und dachte, er rede vielleicht im Schlaf und verrate das Rätsel.
<G-vec00671-002-s059><betray.verraten><en> And then many will be offended, will betray one another, and will hate one another.
<G-vec00671-002-s059><betray.verraten><de> 10 Und dann werden viele Anstoß nehmen, einander verraten und einander hassen.
<G-vec00671-002-s060><betray.verraten><en> “Then many shall be scandalized and shall betray one another and shall hate one another.
<G-vec00671-002-s060><betray.verraten><de> Mt 24,10 Manche werden sich vom Glauben abwenden, einander verraten und hassen.
<G-vec00671-002-s067><betray.verraten><en> Anyone who loves his earthly life will find his heart beating anxiously and will observe the worldly power's law and hence betray his Lord and Saviour for the sake of earthly success.
<G-vec00671-002-s067><betray.verraten><de> Wer sein irdisches Leben lieb hat, dessen Herz wird ängstlich schlagen, und er wird den Geboten der weltlichen Macht nachkommen, also seinen Herrn und Heiland verraten um irdischen Erfolges willen.
<G-vec00671-002-s073><betray.verraten><en> Living Bible) Jesus has even more to us, when we betray him, as long as we live, we can come to him and ask for forgiveness, no matter what we have done.
<G-vec00671-002-s073><betray.verraten><de> (HfA) Jesus haelt sogar dann noch zu uns, wenn wir ihn verraten, solange wir leben, koennen wir zu ihm kommen und um Vergebung bitten, egal was wir getan haben.
<G-vec00671-002-s074><betray.verraten><en> He is always ready to go against his own judgments, betray his inferiors and the norms of his unit to obey his boss's orders.
<G-vec00671-002-s074><betray.verraten><de> Um den Befehlen des Bosses zu gehorchen, ist er immer bereit, gegen sein eigenes Urteil zu handeln, seine Untergebenen zu verraten und die Normen seiner Einheit.
<G-vec00671-002-s079><betray.verraten><en> 18 While they were at the table eating, Jesus said, “I tell you the truth, one of you eating with me will betray me.”
<G-vec00671-002-s079><betray.verraten><de> 18 Und als sie zu Tische saßen und aßen, sprach Jesus: Wahrlich, ich sage euch: Einer unter euch, der mit mir isset, wird mich verraten.
<G-vec00671-002-s080><betray.verraten><en> The men of the Church may either serve the Church or betray her.
<G-vec00671-002-s080><betray.verraten><de> Die Kirchenmänner können der Kirche dienen oder sie verraten.
<G-vec00671-002-s082><betray.verraten><en> Unfortunately, the young man did not want to betray the recipe.
<G-vec00671-002-s082><betray.verraten><de> Leider wollte mir der junge Mann nicht das Rezept verraten.
<G-vec00671-002-s092><betray.verraten><en> Rather, I believe Jesus wept inside as Judas walked out of the Upper Room to betray Him.
<G-vec00671-002-s092><betray.verraten><de> Ich glaube vielmehr, dass Jesus innerlich weinte, als Judas den oberen Raum verlie, um Ihn zu verraten.
<G-vec00671-002-s096><betray.verraten><en> I don't think I betray too much when I notice that opposing couples attract each other...
<G-vec00671-002-s096><betray.verraten><de> Ich denke nicht, dass ich zu viel verrate, wenn ich bemerke, dass sich gegensätzliche Paare anziehen...
<G-vec00671-002-s097><betray.verraten><en> On higher difficulties and playthroughs with only one save file and permadeath this creates the following dilemma: “Do I betray them early on, shoot them in the back and save me a lot of trouble in the end, or do I go so far as to only shot them in the legs at the end, but risk my save file in the process?” I still have memories of being resuscitated only to have used that opportunity to shot my savior in the back afterwards.
<G-vec00671-002-s097><betray.verraten><de> Auf höheren Schwierigkeitsgraden und Playthroughs mit nur einem Savefile und Permadeath kommt man so zu folgendem Dilemma: „Verrate ich alle bereits am Anfang, schieße jedem in den Rücken und erspare mir somit den ganzen Mist oder gehe ich so weit als das ich versuche jedem am Ende nur ins Bein zu schießen und riskiere dabei meinen Speicherstand?“ Ich erinnere mich noch immer daran geheilt worden zu sein nur um meiner Retterin selbst danach hinterrücks in den Kopf zu schießen und ihre Desert Eagle mitzunehmen.
<G-vec00671-002-s098><betray.verraten><en> So I have explicitly come up with something for you;) More I do not betray at this point, slave pig.
<G-vec00671-002-s098><betray.verraten><de> Also habe ich mir explizit für dich etwas einfallen lassen;) Mehr verrate ich an dieser Stelle nicht, Sklavenschwein.
<G-vec00671-002-s099><betray.verraten><en> Do not betray your principles, blindly following the crowd.
<G-vec00671-002-s099><betray.verraten><de> Verrate deine Prinzipien nicht und folge blind der Menge.
<G-vec00671-002-s100><betray.verraten><en> So if you want to go it alone, make friends, build alliances, and even betray that friend, Live as you please.
<G-vec00671-002-s100><betray.verraten><de> Also, wenn du es alleine machen willst, mach Freunde, bilde Allianzen und verrate sogar diesen Freund Live, wie es dir gefällt.
<G-vec00671-002-s101><betray.verraten><en> Typically, the object labeling format of the meme is used to reference historical and fictional events where several people or things betray or attack an individual.
<G-vec00671-002-s101><betray.verraten><de> Üblicherweise wird das Objektbeschriftungsformat des Memes verwendet, um historische oder fiktive Ereignisse zu beschreiben, in denen mehrere Menschen oder Dinge ein Individuum verraten oder angreifen.
<G-vec00671-002-s102><betray.verraten><en> Following Ohgi's suggestion, the Black Knights decided to betray Lelouch in exchange for the liberation of Japan.
<G-vec00671-002-s102><betray.verraten><de> Nach Ohgi's Vorschlag beschlossen sie, im Austausch für ein freies Japan Lelouch zu verraten.
<G-vec00671-002-s103><betray.verraten><en> For Jesus knew from the beginning who they were who did not believe, and who it was that would betray Him.
<G-vec00671-002-s103><betray.verraten><de> Jesus wusste nämlich von Anfang an, welche es waren, die nicht glaubten, und wer ihn verraten würde.
<G-vec00671-002-s104><betray.verraten><en> You promised me not to betray Torchwood again.
<G-vec00671-002-s104><betray.verraten><de> Du hast mir versprochen, Torchwood nicht mehr zu verraten.
<G-vec00671-002-s105><betray.verraten><en> 67:1.2 In the course of this inspection Satan informed Caligastia of Lucifer's then proposed "Declaration of Liberty," and as we now know, the Prince agreed to betray the planet upon the announcement of the rebellion.
<G-vec00671-002-s105><betray.verraten><de> 67:1.2 (754.3) Im Verlaufe dieser Inspektion setzte Satan Caligastia über Luzifers damals beabsichtigte „Freiheitserklärung“ ins Bild, und wie wir heute wissen, willigte der Fürst ein, den Planeten bei Bekanntmachung der Rebellion zu verraten.
<G-vec00671-002-s106><betray.verraten><en> What the new version brings with you, we betray you.
<G-vec00671-002-s106><betray.verraten><de> Was die neue Version mit sich bringt, verraten wir euch.
<G-vec00671-002-s107><betray.verraten><en> It is difficult to imagine a scenario with improved minority rights and Turkish decentralisation with the MHP unless the party is willing to betray its chauvinist principles in exchange for a share in power, something it has done before.
<G-vec00671-002-s107><betray.verraten><de> Mehr Minderheitenrechte und eine Dezentralisierung der Türkei sind mit der MHP schwerlich denkbar – es sei denn, die Partei wäre bereit, als Gegenleistung für eine Beteiligung an der Macht ihre chauvinistischen Prinzipien zu verraten, was sie nicht das erste Mal täte.
<G-vec00671-002-s108><betray.verraten><en> 13:21 When Jesus had thus said, he was troubled in spirit, and testified, and said, Verily, verily, I say to you, that one of you will betray me.
<G-vec00671-002-s108><betray.verraten><de> 13:21 Da solches Jesus gesagt hatte, ward er betrübt im Geist und zeugete und sprach: Wahrlich, wahrlich, ich sage euch, einer unter euch wird mich verraten.
<G-vec00671-002-s109><betray.verraten><en> After the practitioners were assigned to other wards, for the next three months, the guards continued to transfer them in order to make the practitioners betray Falun Gong.
<G-vec00671-002-s109><betray.verraten><de> Nachdem die Praktizierenden anderen Abteilungen zugewiesen wurden, transferierten die Wachen sie nach den nächsten drei Monaten weiter, um sie soweit zu bringen, den Meister und Dafa zu verraten.
<G-vec00671-002-s110><betray.verraten><en> I will betray him to you.
<G-vec00671-002-s110><betray.verraten><de> Ich will ihn euch verraten.
<G-vec00671-002-s111><betray.verraten><en> Our philosophers will discuss all the shortcomings of the various beliefs of the goyim, BUT NO ON WILL EVER BRING UNDER DISCUSSION OUR FAITH FROM ITS TRUE POINT OF VIEW SINCE THIS WILL BE FULLY LEARNED BY NONE SAVE OURS, WHO WILL NEVER DARE TO BETRAY ITS SECRETS.
<G-vec00671-002-s111><betray.verraten><de> Unsere Philosophen werden alle Mängel der christlichen Religion besprechen; niemals wird aber jemand unsere Religion von ihren wahren Gesichtspunkten aus einer Beurteilung unterziehen, weil sie niemand wirklich erfassen wird, ausgenommen die Unserigen, die niemals ihre Geheimnisse verraten werden.
<G-vec00671-002-s112><betray.verraten><en> She, unlike the "reasonable person" will not betray and will not give up, will not change her mind to another master.
<G-vec00671-002-s112><betray.verraten><de> Sie, anders als die "vernünftige Person" wird nicht verraten und wird nicht aufgeben, wird ihre Meinung zu einem anderen Master nicht ändern.
<G-vec00671-002-s113><betray.verraten><en> “The voices, captured on a tape of Fire Department radio transmissions, betray no fear.
<G-vec00671-002-s113><betray.verraten><de> „Die Stimmen auf der Aufzeichnung der Funksprüche der Feuerwehr verraten keine Angst.
<G-vec00671-002-s114><betray.verraten><en> And still also this state will change; the effect of counter forces will first be very weak, then will recognizably become stronger all the time - because the spiritual that is bound in the creation again gets to be embodied as man and so that it again matures differently, so that talents and desires in the state as man emerge that demand a greater change, that still again betray a faint resistance against me, and therefore men again will live on earth, which require special, effective means of education - and then it will be necessary to give them knowledge about the effects of a life that does not fulfil my will.
<G-vec00671-002-s114><betray.verraten><de> Und doch wird auch dieser Zustand sich verändern, das Einwirken von Gegenkräften wird erst ganz schwach, dann immer stärker werdend zu erkennen sein - denn es gelangt wieder das in der Schöpfung gebundene Geistige zur Verkörperung als Mensch, und es ist dieses wieder verschieden ausgereift, so daß im Stadium als Mensch Anlagen und Triebe hervortreten, die eine größere Wandlung erfordern, die immer noch einen leisen Widerstand gegen Mich verraten, und darum wieder Menschen auf Erden leben werden, die besonderer, wirksamer Erziehungsmittel bedürfen - und dann wird es nötig sein, ihnen Kenntnis zu geben von der Auswirkung eines Lebenswandels, der nicht Meinem Willen entspricht.
<G-vec00671-002-s115><betray.verraten><en> The Roman Pontiff would betray his vocation and his service to the People of God if he suffocated the real presence of God in history, in the very places where it is found most readily: in the Scriptures, the people, and in particular in those who suffer isolation and pain.
<G-vec00671-002-s115><betray.verraten><de> Der Papst würde seine Berufung und seinen Dienst verraten, wenn er die Realpräsenz Gottes in der Geschichte unterdrücken würde, wo auch immer sie zu finden ist: in der Heiligen Schrift, in den Sakramenten und im Volk, besonders unter den Ausgegrenzten und Notleidenden.
<G-vec00671-002-s116><betray.verraten><en> And as they sat and did eat, Jesus said, Verily I say unto you, One of you which eateth with me shall betray me.
<G-vec00671-002-s116><betray.verraten><de> 18 Und als sie bei Tisch waren und aßen, sprach Jesus: Wahrlich, ich sage euch: Einer unter euch, der mit mir isst, wird mich verraten.
<G-vec00671-002-s117><betray.verraten><en> 18 And as they were at table eating, Jesus said, "Truly, I say to you, one of you will betray me, one who is eating with me."
<G-vec00671-002-s117><betray.verraten><de> 21 Und da sie aßen, sprach er: Wahrlich, ich sage euch: Einer unter euch wird mich verraten.
<G-vec00671-002-s118><betray.verraten><en> I have chosen to contact you after my prayers and i believe that you will not betray my trust.
<G-vec00671-002-s118><betray.verraten><de> Ich habe mich entschieden, um Sie nach meiner Gebete wenden, und ich glaube, dass Sie nicht verraten mein Vertrauen.
<G-vec00671-002-s119><betray.verraten><en> 18As they sat and were eating, Jesus said, ⟨“Most certainly I tell you, one of you will betray me—he who eats with me.”⟩
<G-vec00671-002-s119><betray.verraten><de> 18Und als sie zu Tische saßen und aßen, sprach Jesus: Wahrlich, ich sage euch: Einer unter euch, der mit mir isset, wird mich verraten.
<G-vec00671-002-s120><betray.verraten><en> The French workers must not remain inactive in the face of an aristocratic, monarchist and military invasion unless they wished to betray not only their cause but the cause of socialism. A victory for Germany would be a victory for European reaction.
<G-vec00671-002-s120><betray.verraten><de> Gegenüber einer aristokratischen, monarchischen, militärischen Invasion dürften die französischen Arbeiter nicht untätig bleiben, wenn sie nicht nur ihre eigene Sache, sondern auch die Sache des Sozialismus nicht verraten wollten; der Sieg Deutschlands sei der Sieg der europäischen Reaktion.
<G-vec00671-002-s121><betray.verraten><en> 21. and as they were eating, he said, “Truly, I tell you that one of you will betray me.” 22.
<G-vec00671-002-s121><betray.verraten><de> 21 Und während sie aßen, sprach er: Amen, ich sage euch: Einer von euch wird mich verraten und ausliefern.
<G-vec00671-002-s122><betray.verraten><en> The evening meal was being served, and the devil had already prompted Judas Iscariot, son of Simon, to betray Jesus.
<G-vec00671-002-s122><betray.verraten><de> 2 Es fand ein Mahl statt, und der Teufel hatte Judas, dem Sohn des Simon Iskariot, schon ins Herz gegeben, ihn zu verraten und auszuliefern.
<G-vec00671-002-s123><betray.verraten><en> That is so al-'Azeez will know that I did not betray him in [his] absence and that Allah does not guide the plan of betrayers.
<G-vec00671-002-s123><betray.verraten><de> Dies ist, damit er weiß, daß ich ihn nicht in seiner Abwesenheit verraten habe und daß Allah die List der Verräter nicht gelingen läßt.
<G-vec00671-002-s124><betray.verraten><en> Then you should be as wise as serpents and as harmless as doves.... but you should not betray Me....
<G-vec00671-002-s124><betray.verraten><de> Dann sollet ihr klug sein wie die Schlangen und sanft wie die Tauben.... aber verraten sollet ihr Mich nicht....
<G-vec00671-002-s125><betray.verraten><en> [11] For he knew who was going to betray him, and that was why he said ‘You are not all clean.’
<G-vec00671-002-s125><betray.verraten><de> Er wusste nämlich, wer ihn verraten würde; darum sagte er: Ihr seid nicht alle rein.
<G-vec00671-002-s126><betray.verraten><en> Seeing how important an organ of locomotion the tail is in most aquatic animals, its general presence and use for many purposes in so many land animals, which in their lungs or modified swimbladders betray their aquatic origin, may perhaps be thus accounted for.
<G-vec00671-002-s126><betray.verraten><de> Wenn man beobachtet, was für ein wichtiges Organ des Ortswechsels der Schwanz für die meisten Wasser-Thiere ist, so lässt sich seine allgemeine Anwesenheit und Verwendung zu mancherlei Zwecken bei so vielen Land-Thieren, welche durch modifizirte Schwimmblasen oder Lungen ihre Abstammung aus dem Wasser verrathen, ganz wohl begreifen.
<G-vec00671-002-s127><betray.verraten><en> Upon recognizing the Queen of Navarre the young Huguenot realized that there was some mistake; but he dared not speak, fearing a cry from Marguerite would betray him.
<G-vec00671-002-s127><betray.verraten><de> Als der junge Mann die Königin von Navarra erkannte, begriff er, daß eine Verwechselung stattfand, aber er wagte es nicht, zu sprechen, aus Furcht, ein Schrei der Königin könnte ihn verrathen.
<G-vec00671-002-s128><betray.verraten><en> My best-loved wickedness and art is it, that my silence hath learned not to betray itself by silence.
<G-vec00671-002-s128><betray.verraten><de> Meine liebste Bosheit und Kunst ist es, dass mein Schweigen lernte, sich nicht durch Schweigen zu verrathen.
<G-vec00671-002-s129><betray.verraten><en> michelle shook her head as she again began to feel her body betray her.
<G-vec00671-002-s129><betray.verraten><de> Michelle schüttelte den Kopf als sie spürte das ihr Körper sie schon wieder verriet.
<G-vec00671-002-s130><betray.verraten><en> And never, under any circumstances, did he betray his comrades; neither imprisonment nor beatings could make him do so.
<G-vec00671-002-s130><betray.verraten><de> Auf keinen Fall verriet er jemals einen Kameraden – nicht Prügel noch Rutenstreiche konnte ihn dazu bringen.
<G-vec00671-002-s131><betray.verraten><en> 16And from that time he sought opportunity to betray him.
<G-vec00671-002-s131><betray.verraten><de> 16Und von da an suchte er eine Gelegenheit, dass er ihn verriete.
<G-vec00671-002-s132><betray.verraten><en> 2And supper being ended, the devil having now put into the heart of Judas Iscariot, Simon’s son, to betray him; 3Jesus knowing that the Father had given all things into his hands, and that he was come from God, and went to God; 4He riseth from supper, and laid aside his garments; and took a towel, and girded himself.
<G-vec00671-002-s132><betray.verraten><de> Und nach dem Abendessen – als schon der Teufel dem Judas, dem Sohn des Simon Iskariot, ins Herz gegeben hatte, dass er ihn verriete; Jesus aber wusste, dass ihm der Vater alles in seine Hände gegeben hatte und dass er von Gott gekommen war und zu Gott ging – da stand er vom Mahl auf, legte seine Kleider ab und nahm einen Schurz und umgürtete sich.
<G-vec00671-002-s133><betray.verraten><en> And Judas Iscariot, one of the twelve, went unto the chief priests, to betray him unto them.
<G-vec00671-002-s133><betray.verraten><de> Und Judas Ischariot, einer von den Zwoelfen, ging hin zu den Hohenpriestern, dass er ihn verriete.
<G-vec00671-002-s134><betray.verraten><en> MAY I AT THIS POINT EMPHASISE THE HIGH LEVEL OF CONFIDENTIALITY, WHICH THIS BUSINESS DEMANDS, AND HOPE YOU WILL NOT BETRAY THE TRUST AND CONFIDENCE, WHICH I REPOSE IN YOU IN CONCLUSION,
<G-vec00671-002-s134><betray.verraten><de> MAG I AN DIESEM PUNKT Das HOHE NIVEAU VON ONFIDENTIALITY HERVORHEBEN, DAS DIESES GESCHÄFT VERLANGT, UND HOFFT SIE VERRÄT NICHT Das VERTRAUEN UND Das VERTRAUEN,DIE Ich IN IHNEN Mich AUSRUHE.
<G-vec00671-002-s135><betray.verraten><en> But ostentation of avoidance or public cuttings are not included in the necessity and betray feelings that equally ought to be overcome.
<G-vec00671-002-s135><betray.verraten><de> Ein Zur-Schau-Stellen des Meidens oder ein öffentliches Schneiden ist aber hierin nicht mit einbezogen und verrät Gefühle, die überwunden werden müssen.
<G-vec00671-002-s136><betray.verraten><en> The sunny and easygoing air that is encapsulated in its name does not betray the delivery of functionality:...
<G-vec00671-002-s136><betray.verraten><de> Die sonnige und unbekümmerte Luft, die in seinem Namen eingekapselt wird, verrät nicht die Anlieferung der...
<G-vec00671-002-s137><betray.verraten><en> Whether we want or non our body betray our true feelings and thoughts.
<G-vec00671-002-s137><betray.verraten><de> Ob wir wollen oder nicht – unser Körper verrät unsere wahren Gefühle und Gedanken.
<G-vec00671-002-s139><betray.verraten><en> Jesus said: “Friend, you betray me with a kiss!”.
<G-vec00671-002-s139><betray.verraten><de> Jesus sagte: „Mein Freund, mit einem Kuss verrätst Du mich!“.
<G-vec00671-002-s142><betray.verraten><en> Everyone who determinedly rejects their demand of denying Me will be treated brutally, and in the face of this many will weaken and betray Me without resistance, for they lack the strength of faith which arises from the pure truth.
<G-vec00671-002-s142><betray.verraten><de> Brutal werden sie an allen handeln, die ihr Ansinnen, Mich zu verleugnen, entschlossen ablehnen, und angesichts dessen werden viele schwach werden und widerstandslos Mich verraten, denn ihnen fehlt die Kraft des Glaubens, die aus der reinen Wahrheit entspringt.
