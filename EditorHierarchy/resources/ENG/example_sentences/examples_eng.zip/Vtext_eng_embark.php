<G-vec00038-002-s088><embark.beginnen><en> As we embark on a new century, let us resolve to adopt a way of life that can be sustained right through it.
<G-vec00038-002-s088><embark.beginnen><de> Lassen Sie uns zu Beginn des neuen Jahrhunderts eine Lebensweise finden, die das ganze Jahrhundert lang Bestand haben kann.
<G-vec00038-002-s089><embark.beginnen><en> Depending on your physical condition when you embark on your exercise program, you may need to consult with a health care professional for help increasing to the intensity required to lower your insulin level.
<G-vec00038-002-s089><embark.beginnen><de> Abhängig von Ihrer körperlichen Verfassung beim Beginn Ihres Trainingsprogramms sollten Sie möglicherweise einen Arzt konsultieren, der Ihnen hilft, die für eine Senkung des Insulinspiegels erforderliche Trainingsintensität zu erhöhen.
<G-vec00038-002-s090><embark.beginnen><en> Select your side, fight against your enemies, embark various quests to find and unite the broken pieces of the heart stone.
<G-vec00038-002-s090><embark.beginnen><de> Wähle deine Seite aus, kämpfe gegen deine Feinde und beginne viele Quests, um alle zerbrochenen Teile des Herzsteines zu finden und zusammenzufügen.
<G-vec00038-002-s091><embark.beginnen><en> Tides of War: Embark on a journey where new content drops continuously transport you and your Company to a huge variety of key WW2 locations, where new battlefields and gear await.
<G-vec00038-002-s091><embark.beginnen><de> Kriegsverlauf: Beginne eine Reise, bei der neue Inhalte dich und deine Kompanie kontinuierlich zu entscheidenden Schauplätzen des Zweiten Weltkriegs bringen, wo dich neue Schlachtfelder und Ausrüstung erwarten.
<G-vec00038-002-s092><embark.beginnen><en> It tells us that it is now ready and if you want you can embark tonight instead of tomorrow, as planned.
<G-vec00038-002-s092><embark.beginnen><de> Es sagt uns, dass sie nun bereit ist und wenn Sie wollen, können Sie heute Abend statt von morgen beginnen, wie geplant.
<G-vec00038-002-s093><embark.beginnen><en> In other words, when the flesh of God is able to embark upon new work among man, and He begins to do the work He must do without obstruction, and when He feels that all has been accomplished, He has already seen the end.
<G-vec00038-002-s093><embark.beginnen><de> Mit anderen Worten: Wenn das Fleisch Gottes in der Lage ist, neue Werke unter den Menschen zu beginnen und Er beginnt, ohne Behinderung das Werk zu tun, was er tun muss, und wenn Er spürt, dass alles vollbracht ist – hat Er bereits das Ende gesehen.
<G-vec00038-002-s094><embark.beginnen><en> This made such a strong impression on her that she immediately decided to embark on a further course of training – this time as a homeopath.
<G-vec00038-002-s094><embark.beginnen><de> Dies war ein so prägendes Erlebnis, dass sie danach sofort eine weitere Ausbildung beginnen wollte - die zur Homöopathin.
<G-vec00038-002-s095><embark.beginnen><en> The governments of member states will then have to embark on an official process of negotiation.
<G-vec00038-002-s095><embark.beginnen><de> Danach beginnen die EU-Mitgliedsstaaten mit den offiziellen Verhandlungen.
<G-vec00038-002-s096><embark.beginnen><en> We can embark on this adventure alone or in cooperative mode, along with three other friends to hunt the world's most dangerous beasts.
<G-vec00038-002-s096><embark.beginnen><de> Wir können dieses Abenteuer alleine oder im kooperativen Modus beginnen, zusammen mit drei anderen Freunden, um die gefährlichsten Tiere der Welt zu jagen.
<G-vec00038-002-s097><embark.beginnen><en> He’s an excellent drummer and was also kind enough to embark on this journey with me for me first album, so it’s been important to me to keep this tradition alive.
<G-vec00038-002-s097><embark.beginnen><de> Er ist ein ausgezeichneter Schlagzeuger und war auch so freundlich, diese Reise mit mir mit meinem ersten Album zu beginnen, deshalb war es mir wichtig, diese Tradition am Leben zu halten.
<G-vec00038-002-s098><embark.beginnen><en> You will embark on this interesting adventure accompanied by a licensed guide who will introduce you to the world of truffles.
<G-vec00038-002-s098><embark.beginnen><de> Dieses interessante Abenteuer beginnen Sie in Begleitung eines lizenzierten Führers, der Sie in die Welt der Trüffel führen wird.
<G-vec00038-002-s099><embark.beginnen><en> They often wish to embark upon or continue a course of study here – but since documents and a command of the language are missing, this is, however, not always easy.
<G-vec00038-002-s099><embark.beginnen><de> Oft wollen sie hier ein Studium beginnen oder fortführen – weil Papiere und Sprachkenntnisse fehlen, ist das aber nicht immer leicht.
<G-vec00038-002-s100><embark.beginnen><en> We are about to embark on doing genomic studies on patients with Fibromyalgia.
<G-vec00038-002-s100><embark.beginnen><de> Wir sind im Begriff, mit dem Durchführen von genomischen Untersuchungen über Patienten mit Fibromyalgia zu beginnen.
<G-vec00038-002-s101><embark.beginnen><en> During a workshop initiated by the filmmaker for women in this community, they address their memories and their traumas and embark on a process of transformation during which they come into view as self-determining subjects rather than as victims.
<G-vec00038-002-s101><embark.beginnen><de> In einem von der Filmemacherin initiierten Workshop für Frauen aus der Community verarbeiten sie ihre Erinnerungen und Traumata und beginnen einen Transformationsprozess, in dessen Verlauf sie nicht als Opfer, sondern als selbstermächtigte Subjekte sichtbar werden.
<G-vec00038-002-s102><embark.beginnen><en> Collect your handy multilingual guidebook containing fascinating background into the Doge's Palace, St. Mark's Square and a detailed map with all necessary information about the public boat transportation in the city before you embark on your Venetian adventure.
<G-vec00038-002-s102><embark.beginnen><de> Sie erhalten Ihren praktischen mehrsprachigen Reiseführer mit faszinierendem Hintergrundwissen über den Dogenpalast, den Markusplatz und eine detaillierte Karte mit allen notwendigen Informationen über den öffentlichen Schiffsverkehr in der Stadt, bevor Sie Ihr venezianisches Abenteuer beginnen.
<G-vec00038-002-s103><embark.beginnen><en> Embark on a fascinating journey on the Virtual Science Trail here.
<G-vec00038-002-s103><embark.beginnen><de> Beginnen Sie hier ihre faszinierende Reise auf dem Virtuellen Wissenspfad.
<G-vec00038-002-s104><embark.beginnen><en> Embark on the journey from Dilli Village before trekking through eucalypt forest, over sand flats and finally to deep, freshwater lakes.
<G-vec00038-002-s104><embark.beginnen><de> Beginnen Sie die Reise vom Dilli Village aus, bevor Sie durch Eukalyptuswälder, über Sandflächen und schließlich zu tiefen, Süßwasserseen wandern.
<G-vec00038-002-s105><embark.beginnen><en> This is where visitors embark on a multimedia journey experience on wheels.
<G-vec00038-002-s105><embark.beginnen><de> Hier beginnt für die Besucher die multimediale Reise durch die Erlebniswelt auf Rädern.
<G-vec00038-002-s106><embark.beginnen><en> Lead the Macedonian faction as Alexander the Great, and embark upon a daring conquest of the all-powerful Persian Empire.
<G-vec00038-002-s106><embark.beginnen><de> Kommandiere die makedonische Seite als Alexander der Große und beginnt einen wagemutigen Feldzug, um das übermächtige Perserreich zu erobern.
<G-vec00038-002-s107><embark.beginnen><en> Lucien and Marguerite embark upon a game that is a mixture of persecution and seduction.
<G-vec00038-002-s107><embark.beginnen><de> Zwischen Lucien und Marguerite beginnt ein Spiel zwischen Verfolgung und Verführung.
<G-vec00038-002-s108><embark.beginnen><en> But then he notices strange things happening at the house next door and may have even witnessed a murder. When he and his grandmother begin to investigate, they embark on the adventure of the lives.
<G-vec00038-002-s108><embark.beginnen><de> Als er jedoch im Nachbarhaus seltsame Dinge und vielleicht sogar einen Mord beobachtet, beginnt er mit seiner Grossmutter zu ermitteln.
<G-vec00038-002-s259><embark.starten><en> However, it's been 15 years since the residents of Kamikatsu, a small town in the south of Japan, in the Tokushima Prefecture on Shikoku Island, decided to embark on a zero-waste program.
<G-vec00038-002-s259><embark.starten><de> Kamikatsu zeigt neue Wege im Abfallmanagement Es ist 15 Jahre her, dass die Bewohner der kleinen Stadt Kamikatsu auf der Insel Shikoku beschlossen haben, ein Null-Abfall-Programm zu starten.
<G-vec00038-002-s260><embark.starten><en> In 1999, Mariano García and Javier Zaccagnini decided to embark on a new project: a modern winery in the town of Quintanilla de Arriba (Valladolid).
<G-vec00038-002-s260><embark.starten><de> Im Jahre 1999 entschieden sich Mariano García und Javier Zaccagnini ein neues Projekt zu starten: eine moderne Bodega, gelegen in Quintanilla de Arriba (Valladolid).
<G-vec00038-002-s261><embark.starten><en> From the Ashrams that Gandhiji established teams of volunteers were daily sent out into the villages to embark on programmes of education on cleanliness and hygiene and encouragement to spin and farm to become self sufficient.
<G-vec00038-002-s261><embark.starten><de> Von den Ashrams, die Gandhiji etablierte, wurden täglich Mannschaften von Freiwilligen in die Dörfer gesandt, um Bildungsprogramme für Hygiene und Sauberkeit zu starten und Unterstützung für Weben und Landwirtschaft für die Selbstversorgung zu leisten.
<G-vec00038-002-s262><embark.starten><en> Enhanced with new ideas, new products, a new software, new international target markets and, above all, a new, demonic marketing facelift, bavarianDEMON, with its long-standing development experience, will now embark on a new era.
<G-vec00038-002-s262><embark.starten><de> Angereichert mit neuen Ideen, neuen Produkten, neuer Software, neuen internationalen Zielmärkten - und vor allem einem neuen, dämonischen Marketing-Gesicht wird bavarianDEMON mit dieser langjährigen Entwicklungserfahrung nun in eine neue Ära starten.
<G-vec00038-002-s263><embark.starten><en> Embark on an epic single-player campaign comprising more than 150 challenging quests.
<G-vec00038-002-s263><embark.starten><de> Starten Sie in eine epische Einzelspieler-Kampagne mit mehr als 150 Herausforderungen.
<G-vec00038-002-s264><embark.starten><en> Embark on your lifelong journey in one of the world's most romantic settings.
<G-vec00038-002-s264><embark.starten><de> Starten Sie an einem der romantischsten Orte der Welt in Ihr gemeinsames Leben.
