<G-vec00296-002-s417><divide.(sich)_teilen><en> If you divide the position “current expenses” by about 6 kitten in a year, you’ll already get 920,00 €.
<G-vec00296-002-s417><divide.(sich)_teilen><de> Teilt man die Position “laufende Kosten” durch etwa 6 Katzenbabies im Jahr, kommt man bereits auf knapp 920,00 €.
<G-vec00296-002-s418><divide.(sich)_teilen><en> The client then works in tandem with the Speed Server to intelligently divide your Internet traffic and deliver the combined speed of all available Internet connections.
<G-vec00296-002-s418><divide.(sich)_teilen><de> Der Client arbeitet dann mit dem Speed-Server zusammen, teilt Ihren Internet Traffic intelligent auf und stellt die kombinierte Geschwindigkeit aller verfügbaren Internetverbindungen zur Verfügung.
<G-vec00296-002-s419><divide.(sich)_teilen><en> If, therefore, you divide 1000 mm by the number of holes, you will know the mesh width.
<G-vec00296-002-s419><divide.(sich)_teilen><de> Teilt man also 1000 mm durch die Anzahl der Maschen, ergibt sich die Maschenbreite.
<G-vec00296-002-s420><divide.(sich)_teilen><en> You divide up the day how you want, and feel free to share ideas with people in the office who are not part of your own department.
<G-vec00296-002-s420><divide.(sich)_teilen><de> Man teilt den Tag nach eigenen Vorstellungen ein und fühlt sich frei, auch mit Kollegen aus anderen Abteilungen Ideen auszutauschen.
<G-vec00296-002-s421><divide.(sich)_teilen><en> They revolutionise the principles of baking and dough processing because they divide as well as shape (or "mould") the dough balls, all in one machine. They replace a divider and a moulder (please refer to "divider-shapers" in the machine range).
<G-vec00296-002-s421><divide.(sich)_teilen><de> Dieses Gerät hat das Prinzip der Brotherstellung und der Teigverarbeitung revolutioniert, denn es teilt und formt (oder "wirkt") die Teiglinge mit nur einer Maschine.Es ersetzt einen Teiler und eine Wirkmaschine in der Maschinen-Produktpalette.
<G-vec00296-002-s422><divide.(sich)_teilen><en> Divide ye like your enemies, in Houses, and lay your laws in set sequence from the center, again like the enemy Corners of the House of Troubles, and see yourself thence as timber, or mud-slats, or sheets of resin.
<G-vec00296-002-s422><divide.(sich)_teilen><de> Teilt euch auf, wie eure Feinde, in Häuser, und legt eure Gesetze in einer Ordnung, vom Zentrum ausgehend, fest, wieder wie die feindlichen Ecken des Hauses der Sorgen, und seht euch selbst daher als Bauholz, oder Lehmziegel oder Schichten aus Harz.
<G-vec00296-002-s423><divide.(sich)_teilen><en> Important for you: a&o will gladly divide the rooms up for you – profit from our experience.
<G-vec00296-002-s423><divide.(sich)_teilen><de> Wichtig für Sie: a&o teilt gern Zimmer für Sie zu – Profitieren Sie von unserer Erfahrung.
<G-vec00296-002-s424><divide.(sich)_teilen><en> Each car will divide after hit - unless it will be as small as possible.
<G-vec00296-002-s424><divide.(sich)_teilen><de> Jedes Auto teilt nach Hit - es sei denn, es wird so klein wie möglich.
<G-vec00296-002-s425><divide.(sich)_teilen><en> The Engagement Rate is calculated by taking the total PTAT (people talking about this) and divide by the total number of likes.
<G-vec00296-002-s425><divide.(sich)_teilen><de> Engagementgrad: 0.07% Die Engagementrate wird berechnet, indem man den PTAT (people talking about this) durch die Anzahl an Likes teilt.
<G-vec00296-002-s426><divide.(sich)_teilen><en> APLUS will detect crossing points and divide the line into separate dimension lines.
<G-vec00296-002-s426><divide.(sich)_teilen><de> APLUS erkennt die Schnittpunkte und teilt die Linie in einzelne Bemaßungslinien.
<G-vec00296-002-s427><divide.(sich)_teilen><en> The Immigration Service does not divide people into groups based on religion or ethnicity, which means that people from different sides of a conflict may end up living together.
<G-vec00296-002-s427><divide.(sich)_teilen><de> Die Zuwanderungsbehörde teilt Menschen nicht auf Grund von Religion oder Ethnie in Gruppen ein, was bedeutet, dass es vorkommen kann, dass Menschen aus verschiedenen Seiten eines Konflikts zusammen leben müssen.
<G-vec00296-002-s428><divide.(sich)_teilen><en> Please divide the minutes by 60, and format cells to display numbers with 2 decimals.
<G-vec00296-002-s428><divide.(sich)_teilen><de> Bitt teilt dafür die Minuten durch 60 und formatiert die Zelle als Ziffer mit zwei Dezimalstellen.
<G-vec00296-002-s429><divide.(sich)_teilen><en> But if you divide the tunnel into two halves and design each section completely differently, the tiled wall part can suddenly enhance the whole space to the extent that it becomes delightful.
<G-vec00296-002-s429><divide.(sich)_teilen><de> Doch wenn man den Tunnel in zwei Hälften teilt und komplett anders gestaltet, erfährt der keramische Wandteil plötzlich eine Aufwertung, der wir uns sogar erfreuen können.
<G-vec00296-002-s430><divide.(sich)_teilen><en> Benjamin shall ravin [as] a wolf: in the morning he shall devour the prey, and at night he shall divide the spoil.
<G-vec00296-002-s430><divide.(sich)_teilen><de> 27 Benjamin ist ein reißender Wolf: / Am Morgen frisst er die Beute, / am Abend teilt er den Fang.
<G-vec00296-002-s431><divide.(sich)_teilen><en> If you divide a country along linguistic lines, you have to take into account, that there are areas of mixed language that do not fit into your scheme.
<G-vec00296-002-s431><divide.(sich)_teilen><de> Teilt man ein Land entlang sprachlicher Linien, so muss man berücksichtigen, daß es gemischtsprachige Gebiete gibt, die nicht in so ein Schema passen.
<G-vec00296-002-s432><divide.(sich)_teilen><en> The analysis will divide the area to be lit into specific zones to determine where the luminaires and the sensors should be installed.
<G-vec00296-002-s432><divide.(sich)_teilen><de> Diese Analyse teilt die Fläche in einzelne Zonen auf um zu bestimmen, wie viele Leuchten wo installiert werden sollten.
<G-vec00296-002-s433><divide.(sich)_teilen><en> You simply divide it with the fork!
<G-vec00296-002-s433><divide.(sich)_teilen><de> Man teilt ihn schlicht mit der Gabel.
<G-vec00296-002-s434><divide.(sich)_teilen><en> Sometimes the larger kitchen will divide the kitchen into a cooking area and a preparation area, so that kitchen cooking can be performed better, and the operating people do not interfere with each other.
<G-vec00296-002-s434><divide.(sich)_teilen><de> Manchmal teilt die größere Küche die Küche in einen Kochbereich und einen Vorbereitungsbereich auf, so dass das Kochen in der Küche besser durchgeführt werden kann und sich die Bedienungspersonen nicht gegenseitig behindern.
<G-vec00296-002-s435><divide.(sich)_teilen><en> In the 7 questions version of the game, you just divide the questions between the players.
<G-vec00296-002-s435><divide.(sich)_teilen><de> In der 7-Fragen-Variante des Spiels, teilt ihr die 21 Fragen einfach zwischen den Spielern auf.
<G-vec00296-002-s057><divide.aufteilen><en> This simply means that water will divide (dissociate)into these two components.
<G-vec00296-002-s057><divide.aufteilen><de> Dies bedeutet einfach, dass Wasser sich in diese beiden Komponenten aufteilt (disoziiert).
<G-vec00296-002-s058><divide.aufteilen><en> For larger rounds it is particularly fun, if you divide into the individual houses and each house must drink in certain scenes.
<G-vec00296-002-s058><divide.aufteilen><de> Für größere Runden macht es besonders Spaß, wenn ihr euch in die einzelnen Häuser aufteilt und jedes Haus bei gewissen Szenen trinken muss.
<G-vec00296-002-s059><divide.aufteilen><en> User groups are groups of users that divide the community into manageable sections administrators can work with.
<G-vec00296-002-s059><divide.aufteilen><de> Benutzergruppen sind Gruppen von Mitgliedern, die die Mitglieder des Boards in für die Board-Administration verwaltbare Einheiten aufteilt.
<G-vec00296-002-s060><divide.aufteilen><en> When hunt- ing, the pod will divide into several small groups.
<G-vec00296-002-s060><divide.aufteilen><de> Seine Jagdtechnik besteht im Aufspüren von Fischschwärmen, wobei eine Schule sich in Gruppen aufteilt.
<G-vec00296-002-s061><divide.aufteilen><en> To add support for an extra monitor without adding or replacing a graphics card, you can use Matrox Graphics eXpansion Modules (GXMs)—small, external boxes that connect to the monitor connector of your computer and divide the signal for two or three separate monitors.
<G-vec00296-002-s061><divide.aufteilen><de> Upgraden von Laptops für Mehrfach-Display Damit ein zusätzlicher Monitor unterstützt wird, ohne eine Grafikkarte hinzuzufügen, können Sie Matrox Grafik-Erweiterungsmodule (GXMs) verwenden – kleine, externe Kästen, die an den Monitoranschluss Ihres Computers angeschlossen werden und das Signal für zwei oder drei separate Monitore aufteilt.
<G-vec00296-002-s089><divide.austeilen><en> 6Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.
<G-vec00296-002-s089><divide.austeilen><de> Denn du sollst diesem Volk das Land zum Erbe austeilen, das zu geben ich ihren Vätern geschworen habe.
<G-vec00296-002-s090><divide.austeilen><en> And ye shall divide this land unto you according to the tribes of Israel.
<G-vec00296-002-s090><divide.austeilen><de> 21 Also sollt ihr das Land austeilen unter die Stämme Israels.
<G-vec00296-002-s091><divide.austeilen><en> So shall you divide this land to you according to the tribes of Israel.
<G-vec00296-002-s091><divide.austeilen><de> Also sollt ihr das Land austeilen unter die Stämme Israels.
<G-vec00296-002-s092><divide.austeilen><en> 14 "You shall divide it for an inheritance, each one equally with the other; for I swore to give it to your forefathers, and this land shall fall to you as an inheritance.
<G-vec00296-002-s092><divide.austeilen><de> 47:14 Und ihr sollt's gleich austeilen, einem wie dem andern; denn ich habe meine Hand aufgehoben, das Land euren Vätern und euch zum Erbteil zu geben.
<G-vec00296-002-s093><divide.austeilen><en> 13: Thus says the Lord GOD: "These are the boundaries by which you shall divide the land for inheritance among the twelve tribes of Israel. Joseph shall have two portions.
<G-vec00296-002-s093><divide.austeilen><de> 13So spricht Gott, der HERR: Das ist die Grenze, innert welcher ihr den zwölf Stämmen Israels das Land zum Erbe austeilen sollt; dem Joseph gehören zwei Lose.
<G-vec00296-002-s094><divide.austeilen><en> 34:17 These are the names of the men that shall divide the land unto you for inheritance: Eleazar the priest, and Joshua the son of Nun.
<G-vec00296-002-s094><divide.austeilen><de> 34:17 Das sind die Namen der Männer, die euch das Land als Erbe austeilen sollen: der Priester Eleasar und Josua, der Sohn des Nun.
<G-vec00296-002-s095><divide.austeilen><en> This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord Jehovah.
<G-vec00296-002-s095><divide.austeilen><de> Das ist das Land, das ihr austeilen sollt zum Erbteil unter die Stämme Israels; und das sollen ihre Erbteile sein, spricht der HERR HERR.
<G-vec00296-002-s096><divide.austeilen><en> Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.
<G-vec00296-002-s096><divide.austeilen><de> Sei getrost und unverzagt; denn du sollst diesem Volk das Land austeilen, das ich ihren Vätern geschworen habe, daß ich's ihnen geben wollte.
<G-vec00296-002-s097><divide.austeilen><en> This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord GOD.
<G-vec00296-002-s097><divide.austeilen><de> Das ist das Land, das ihr austeilen sollt zum Erbteil unter die Staemme Israels; und das sollen ihre Erbteile sein, spricht der HERR HERR.
<G-vec00296-002-s098><divide.austeilen><en> 47:13Thus saith the Lord Jehovah: This shall be the border, whereby ye shall divide the land for inheritance according to the twelve tribes of Israel: Joseph shall have two portions.
<G-vec00296-002-s098><divide.austeilen><de> 13 So spricht der Herr HERR: Dies sind die Grenzen, nach denen ihr das Land sollt austeilen den zwölf Stämmen Israels; denn zwei Teile gehören dem Stamm Joseph.
<G-vec00296-002-s099><divide.austeilen><en> 6 Be strong and 'quit thyself like a man, for thou shalt divide the land to this people, which I sware to give to † your fathers.
<G-vec00296-002-s099><divide.austeilen><de> 6 Sei getrost und unverzagt; denn du sollst diesem Volk das Land austeilen, das ich ihren Vätern geschworen habe, daß ich's ihnen geben wollte.
<G-vec00296-002-s100><divide.austeilen><en> 16 Though he heap up silver as the dust, and prepare clothing as the clay; 17 He may prepare it, but the just shall put it on; and the innocent shall divide the silver.
<G-vec00296-002-s100><divide.austeilen><de> 16 Wenn er Geld zusammenbringt wie Staub und sammelt Kleider wie Lehm, 17 so wird er es wohl bereiten; aber der Gerechte wird es anziehen, und der Unschuldige wird das Geld austeilen.
<G-vec00296-002-s101><divide.austeilen><en> Ben Iamin is a ravishing wolf. In the morning he shall devour his prey, and at night he shall divide his spoil.
<G-vec00296-002-s101><divide.austeilen><de> 27Benjamin ist ein reißender Wolf; des Morgens wird er Raub fressen, aber des Abends wird er den Raub austeilen.
<G-vec00296-002-s102><divide.austeilen><en> 28 Command Josue, and encourage and strengthen him: for he shall go before this people, and shall divide unto them the land which thou shalt see.
<G-vec00296-002-s102><divide.austeilen><de> Und gebiete dem Josua, daß er getrost und unverzagt sei; denn er soll über den Jordan ziehen vor dem Volk her und soll ihnen das Land austeilen, das du sehen wirst.
<G-vec00296-002-s147><divide.dividieren><en> Divide your annual gross income by 12 to determine your average monthly income.
<G-vec00296-002-s147><divide.dividieren><de> Dividiere dein jährliches Bruttoeinkommen durch 12, um dein durchschnittliches monatliches Einkommen zu bestimmen.
<G-vec00296-002-s148><divide.dividieren><en> Add the last number of the fourth marker and divide the result by the top number on the first marker from the bottom.
<G-vec00296-002-s148><divide.dividieren><de> Addiere dazu die unterste Zahl auf dem vierten Schild von oben und dividiere das ganze durch die oberste Zahl auf dem ersten Schild von unten.
<G-vec00296-002-s149><divide.dividieren><en> Convert the first letter into a number (A=1, B=2...), divide it by 2 in oder to derive G.
<G-vec00296-002-s149><divide.dividieren><de> Wandle den ersten Buchstaben in eine Zahl (A=1, B=2,...) um, dividiere sie durch 2 um G zu erhalten.
<G-vec00296-002-s150><divide.dividieren><en> 1 Divide your monthly debt by your monthly income.
<G-vec00296-002-s150><divide.dividieren><de> 1 Dividiere deine monatlichen Schulden durch dein monatliches Einkommen.
<G-vec00296-002-s151><divide.dividieren><en> Divide the distance by 4 and write the number down as G.
<G-vec00296-002-s151><divide.dividieren><de> Dividiere die Wegstrecke durch 4 und notiere dir die Zahl als G.
<G-vec00296-002-s181><divide.einteilen><en> It is best to divide your expenses into categories, and list the total amount spent per category.
<G-vec00296-002-s181><divide.einteilen><de> Es ist das Beste, deine Ausgaben in Kategorien einzuteilen und die Gesamtausgaben pro Kategorie anzugeben.
<G-vec00296-002-s182><divide.einteilen><en> They used their powers to form the five elements (metal, wood, water, fire, and earth), establish five seasons (spring, fall, winter, summer, and late summer), and divide the world into five regions (north, south, east, west, and center).
<G-vec00296-002-s182><divide.einteilen><de> Sie setzten ihre Kräfte ein, um die fünf Elemente hervorzubringen (Metall, Holz, Wasser, Feuer und Erde) und die fünf Jahreszeiten zu erschaffen (Frühling, Herbst, Winter, Sommer und Spätsommer), und die Welt in fünf Regionen einzuteilen (Norden, Süden, Osten, Westen und die Mitte).
<G-vec00296-002-s183><divide.einteilen><en> All editors of ASA Maestro provide a customizable ability to divide text into logical parts (regions).
<G-vec00296-002-s183><divide.einteilen><de> Alle Editoren von MS SQL Maestro ermöglichen den Text in logische Teile einzuteilen.
<G-vec00296-002-s184><divide.einteilen><en> It would be a mistake to divide the history of the Arctic simply into two periods, before and after the arrival of the Europeans.
<G-vec00296-002-s184><divide.einteilen><de> Es wäre falsch, die geschichtliche Entwicklung der Arktis in nur zwei Zeiträume einzuteilen, vor und nach dem Eindringen der Europäer.
<G-vec00296-002-s185><divide.einteilen><en> To divide my everyday life into time for duty and time for seeing is the wrong approach.
<G-vec00296-002-s185><divide.einteilen><de> Meinen Alltag einzuteilen in Zeit für Pflicht und Zeit für Sehen ist der falsche Ansatz.
<G-vec00296-002-s186><divide.einteilen><en> Please note: It's not an easy task to divide the catalog into categories.
<G-vec00296-002-s186><divide.einteilen><de> Bitte beachten Sie, dass es nur schwer möglich ist, den Katalog in Kategorien einzuteilen.
<G-vec00296-002-s187><divide.einteilen><en> Since the animals do not care about administrative borders determined by humans, it makes sense to divide the animals into biological units, so-called populations.
<G-vec00296-002-s187><divide.einteilen><de> Da Tiere sich nicht um die administrativen Grenzen des Menschen kümmern, ist es sinnvoll die Bestände in biologische Einheiten, die Populationen, einzuteilen.
<G-vec00296-002-s188><divide.einteilen><en> De prime abord, I do not proceed from “concepts,” hence neither from the “concept of value,” and am therefore in no way concerned to “divide” it.
<G-vec00296-002-s188><divide.einteilen><de> De prime abord gehe ich nicht aus von „Begriffen“, also auch nicht vom „Wertbegriff“, und habe diesen daher auch in p. 369keiner Weise „einzuteilen“.
<G-vec00296-002-s189><divide.einteilen><en> In the Winter, the Lech Ski School offers a special treat for our young guests: up to 14 years of age everyone can be taken and picked up just paying child’s fare, and depending on the car rental, an attempt is made to divide teen groups so that everyone can enjoy them
<G-vec00296-002-s189><divide.einteilen><de> Im Winter bietet die Skischule Lech für unsere jungen Gäste ein besonderes Zuckerl: bis 14 Jahre fahren alle zum Kindertarif und je nach Fahrkönnen wird versucht, Teenie-Gruppen einzuteilen, damit es auch allen mehr Spaß macht.
<G-vec00296-002-s190><divide.entzweien><en> Abandoning malicious speech, he abstains from malicious speech; he does not repeat elsewhere what he has heard here in order to divide [those people] from these, nor does he repeat to these people what he has heard elsewhere in order to divide [these people] from those; thus he remains one who reunites those who are divided, a promoter of friendships, who enjoys concord, rejoicrs in concord, delights in concord, a speaker of words that promote concord.
<G-vec00296-002-s190><divide.entzweien><de> Er enthält sich davon, gehässig zu sprechen, indem er es aufgegeben hat, gehässig zu sprechen; er verbreitet nicht woanders, was er hier gehört hat, um jene Menschen von den Menschen hier zu entzweien, auch verbreitet er nicht hier, was er woanders gehört hat, um diese Menschen von jenen Menschen dort zu entzweien; somit ist er einer, der diejenigen vereint, die vorher entzweit waren, einer, der Freundschaft fördert, Eintracht genießt, sich über Eintracht freut, an Eintracht Entzücken findet, jemand, der Worte äußert, die Eintracht säen.
<G-vec00296-002-s191><divide.entzweien><en> Dogmas divide, but living faith connects.
<G-vec00296-002-s191><divide.entzweien><de> Dogmen entzweien, gelebter Glaube aber verbindet.
<G-vec00296-002-s192><divide.entzweien><en> Obviously there are a lot of possible reasons, and while we should not divide over secondary issues, both sides agree that we must divide when it comes to primary issues.
<G-vec00296-002-s192><divide.entzweien><de> Offensichtlich gibt es viele Gründe, und während wir uns nicht wegen sekundärer Themen spalten sollten, so stimmen doch beide Seiten überein, das wir uns entzweien müssen, wenn es um elementare Fragen geht.
<G-vec00296-002-s193><divide.entzweien><en> Out of the Darkness will come the Light, you will see your fellow human beings and you will realise that what divides you was falsely placed there to divide you and give them excuses to go to War.
<G-vec00296-002-s193><divide.entzweien><de> Aus der Dunkelheit wird das Licht kommen, ihr werdet eure Mitmenschen sehen und erkennen, dass das was euch voneinander unterscheidet, fälschlicherweise zwischen euch aufgebaut wurde, um euch zu entzweien und ihnen einen Grund für Krieg zu geben.
<G-vec00296-002-s210><divide.gliedern><en> Twelve-tone scale and twelve-color circle are similar, both divide the octave space into 12 steps.
<G-vec00296-002-s210><divide.gliedern><de> Zwölftonleiter und Zwölffarbenkreis sind gleichartig, beide gliedern den Oktavraum in 12 Stufen.
<G-vec00296-002-s211><divide.gliedern><en> Now we are able to divide a space, open it up and join it with the landscape, so that we may fulfil the spatial needs of modern man.
<G-vec00296-002-s211><divide.gliedern><de> Erst jetzt kann man den Raum gliedern, öffnen und mit der Landschaft verbinden, um das Raumbedürfnis des heutigen Menschen zu erfüllen.
<G-vec00296-002-s212><divide.gliedern><en> Vertical window panels divide up the facade; the chimney lies right in the line of vision when looking down the pathway.
<G-vec00296-002-s212><divide.gliedern><de> Vertikale Fensterstreifen gliedern die Fassade, der Kamin liegt genau in der Blickachse der Erschließung.
<G-vec00296-002-s213><divide.gliedern><en> The appended narrow elements divide the room without encroaching on the living space.
<G-vec00296-002-s213><divide.gliedern><de> Die angehängten, filigran anmutenden Elemente gliedern den Raum, ohne die Wohnfläche zu beinträchtigen.
<G-vec00296-002-s214><divide.gliedern><en> The support frame, which is visible from outside, and the displayed intermediate lesenes divide the facade, which comes across as something between tectonic plates and an abstract grid.
<G-vec00296-002-s214><divide.gliedern><de> Das außen sichtbare Tragskelett und die dazwischen abgebildeten Lisenen gliedern die Fassade, die einen Zustand zwischen Tektonik und abstraktem Gitter vermittelt.
<G-vec00296-002-s215><divide.gliedern><en> Production part PREFA invest, a.s. we can divide into the basic segments: production and extraction of aggregates, production and sale of transport concrete, prefabricated custom construction, tubing and shaft program, concrete paving and bricks, commercial prefabricated.
<G-vec00296-002-s215><divide.gliedern><de> Produktionsteil PREFA invest, a.s. Wir können uns in die grundlegenden Segmente gliedern: Produktion und Gewinnung von Zuschlagstoffen, Herstellung und Verkauf von Transportbeton, vorgefertigte Spezialkonstruktion, Rohr- und Schachtprogramm, Betonpflaster und Ziegel, Fertigteilgewerbebau.
<G-vec00296-002-s216><divide.gliedern><en> Garden paths not only divide the site into zones, but also give it a neat, neat appearance.
<G-vec00296-002-s216><divide.gliedern><de> Gartenwege gliedern das Gelände nicht nur in Zonen, sondern geben ihm auch eine gepflegte, gepflegte Erscheinung.
<G-vec00296-002-s217><divide.gliedern><en> Sub-forms are used to divide a lengthy form into several logically connected portions.
<G-vec00296-002-s217><divide.gliedern><de> Subformulare eignen sich dazu, sehr lange Formulare in mehrere logisch zusammenhängende Blöcke zu gliedern.
<G-vec00296-002-s218><divide.gliedern><en> The two huge rod-shaped building elements divide the complex into a studio and workshop stage, a large hall and a stage at the lakeside.
<G-vec00296-002-s218><divide.gliedern><de> Die beiden überdimensionalen stabförmigen Gebäudeelemente gliedern den Komplex in Studio- und Werkstattbühne, Großer Saal und Seetribüne.
<G-vec00296-002-s219><divide.gliedern><en> Large shelve elements satisfy the extensive need for storage room and divide the open-space into smaller, yet fully interconnected units of communicative work.
<G-vec00296-002-s219><divide.gliedern><de> Sehr große Stauraumanforderungen wurden übersetzt in Regalelemente, die den Raum gliedern und kleinere Einheiten entstehen lassen, gleichzeitig aber auch kommunikatives Arbeiten ermöglichen.
<G-vec00296-002-s220><divide.gliedern><en> The myth rooms tell the story of the Mercedes-Benz brand and divide them into themes and epochs.
<G-vec00296-002-s220><divide.gliedern><de> Die Mythosräume erzählen die Geschichte der Marke Mercedes-Benz und gliedern sie in Themen und Epochen.
<G-vec00296-002-s221><divide.gliedern><en> Additionally, you can then divide your services into different categories.
<G-vec00296-002-s221><divide.gliedern><de> Ihre Leistungen können Sie dann zusätzlich in unterschiedliche Kategorien gliedern.
<G-vec00296-002-s222><divide.gliedern><en> In this way we succeed in surveying into the field belonging to the Spirits of Form and as abnormal Spirits of Form to bear one humanity, and that the belated Spirits of Motion enter into the field belonging to the Spirits of Form and as abnormal Spirits of Form divide up all humanity upon the globe into the several races.
<G-vec00296-002-s222><divide.gliedern><de> Wir gewinnen dadurch die Urnschau 'über den ganzen Erdenplaneten, finden den Erdenplaneten dazu bestimmt, eine Menschheit zu tragen durch die normalen Geister der Form, finden, daß sich die zurückgebliebenen Geister der Bewegung in dieses Terrain der Geister der Form hineinbegeben und als abnorme Geister der Form das Menschentum auf dem ganzen Erdenrund in die einzelnen Rassen gliedern.
<G-vec00296-002-s223><divide.gliedern><en> In order to divide the room visually and functionally, we use combinations of straight and curved elements, creating lines, curves and even radii," says Kraling.
<G-vec00296-002-s223><divide.gliedern><de> Um den Raum optisch und funktional zu gliedern, nutzen wir Kombinationen gerader und abgerundeter Elemente, bilden Linien, Kurven und sogar Radien“, sagt Kräling.
<G-vec00296-002-s224><divide.graben><en> On one side stands Moscow, which – with its self-imposed isolation from the West and rejection of the norms and processes of constitutional democracy – offers a geostrategic anchor and point of orientation for the region’s autocracies. However, it also expects loyalty, and its intransigence is gradually deepening the divide with the West.
<G-vec00296-002-s224><divide.graben><de> Auf der einen Seite steht Moskau, das mit seiner Abgrenzung vom Westen und seiner Abkehr von Normen und Prozessen der rechtsstaatlichen Demokratie den Autokratien der Region einen geostrategischen Anker und politische Orientierung bietet, aber auch Loyalität erwartet und mit seiner Kompromisslosigkeit sukzessive den Graben zum Westen vertieft.
<G-vec00296-002-s225><divide.graben><en> There is a deep divide between the paternalism of the Asian city state and the democracy of the Swiss Confederation.
<G-vec00296-002-s225><divide.graben><de> Zwischen dem Paternalismus des Stadtstaates und der Demokratie der Eidgenossenschaft klafft ein tiefer Graben.
<G-vec00296-002-s226><divide.graben><en> From the vantage point of three interdisciplinary research departments – the Department of Archaeogenetics (Director Johannes Krause), the Department of Archaeology (Director Nicole Boivin), and the Department of Cultural and Linguistic Evolution (Director Russell Gray) – the MPI-SHH pursues an integrative approach to the study of human history that bridges the traditional divide between the natural sciences and the humanities.
<G-vec00296-002-s226><divide.graben><de> Mit seinen drei interdisziplinären Abteilungen – der Abteilung für Archäogenetik (Direktor Johannes Krause), der Abteilung für Archäologie (Direktorin Nicole Boivin) sowie der Abteilung für Sprach- und Kulturevolution (Direktor Russell Gray) – verfolgt das Institut eine dezidiert integrierende Wissenschaft der Menschheitsgeschichte, die den traditionellen Graben zwischen Natur- und Geisteswissenschaften überwindet.
<G-vec00296-002-s227><divide.graben><en> This is even evident to people like Friedrich Merz, whose job description includes keeping the divide as narrow as possible.
<G-vec00296-002-s227><divide.graben><de> Das fällt selbst Leuten wie Friedrich Merz auf, zu dessen Jobbeschreibung es gehört, den Graben kleinzuhalten.
<G-vec00296-002-s378><divide.sich_teilen><en> Each day, the cells of the human body divide billions of times; this also requires duplication of their genetic information.
<G-vec00296-002-s378><divide.sich_teilen><de> Die Zellen des menschlichen Körpers und die darin enthaltene Erbinformation teilen sich milliardenfach, jeden Tag.
<G-vec00296-002-s379><divide.sich_teilen><en> They extend along the coast for more than 250km and divide into numerous layers.
<G-vec00296-002-s379><divide.sich_teilen><de> Sie erstrecken sich entlang der Küste mehr als 250km und teilen sich in vielen Schichten.
<G-vec00296-002-s380><divide.sich_teilen><en> Amphibola bests break into shorter fibers or divide into thinner fibers along their longitudinal cleavage.
<G-vec00296-002-s380><divide.sich_teilen><de> Amphibolasbeste brechen zu kürzeren Fasern oder teilen sich entlang Ihrer Längsspaltbarkeit zu dünneren Fasern.
<G-vec00296-002-s381><divide.sich_teilen><en> Employers and employees divide social security contributions in half.
<G-vec00296-002-s381><divide.sich_teilen><de> Arbeitgeber/in und Arbeitnehmer/in teilen sich die Sozialbeiträge hälftig.
<G-vec00296-002-s382><divide.sich_teilen><en> At this point the production lines divide again: some of the salmon fillets are taken away to be packaged as finished products, while the rest are cut into portion-sized pieces and then packaged up.
<G-vec00296-002-s382><divide.sich_teilen><de> Hier teilen sich die Produktionslinien erneut: Ein Teil der Lachsfilets wird als fertiges Produkt der Verpackung zugeführt, der andere Teil wird in Portionsstücke geschnitten und anschließend verpackt.
<G-vec00296-002-s383><divide.sich_teilen><en> these 15 exclusive housing units divide each other in nine, or six, apartments in two building structures, through which the distance to the the next neighbor was extended and your privacy is being protected optimally.
<G-vec00296-002-s383><divide.sich_teilen><de> Die 15 exklusiven Wohneinheiten teilen sich zu neun beziehungsweise sechs Wohnungen auf zwei Baukörper auf, wodurch die Entfernung zum nächsten Nachbarn erweitert wurde und Ihre Privatsphäre optimal geschützt wird.
<G-vec00296-002-s384><divide.sich_teilen><en> The latter divide into three LFOs and a CV modulation sequence.
<G-vec00296-002-s384><divide.sich_teilen><de> Letztere teilen sich in drei LFOs und eine CV-Sequenz auf.
<G-vec00296-002-s385><divide.sich_teilen><en> Some cells divide repeatedly, while others appear to develop into more mature cell types that no longer divide.
<G-vec00296-002-s385><divide.sich_teilen><de> Einige dieser Zellen teilen sich wiederholt, während andere sich zu ausgereiften, spezialisierten Zelltypen entwickeln, die sich nicht mehr vermehren können.
<G-vec00296-002-s386><divide.sich_teilen><en> Typically, slot machines divide by 32, 64,128, 256 or 512.
<G-vec00296-002-s386><divide.sich_teilen><de> Gewöhnlich teilen sich Spielautomaten durch 32, 64.128, 256 oder 512.
<G-vec00296-002-s387><divide.sich_teilen><en> Further crushing of the blastomeres does not occur synchronously: some cells divide faster, some slower, resulting in the formation of a morula (the so-called stage of development of the human embryo, numbering about a hundred cells).
<G-vec00296-002-s387><divide.sich_teilen><de> Eine weitere Zerkleinerung der Blastomeren findet nicht synchron statt: einige Zellen teilen sich schneller, einige langsamer, was zur Bildung einer Morula führt (das sogenannte Entwicklungsstadium des menschlichen Embryos, das etwa 100 Zellen umfasst).
<G-vec00296-002-s388><divide.sich_teilen><en> Once inside the erythrocytes, they divide again and ultimately destroy them.
<G-vec00296-002-s388><divide.sich_teilen><de> Im Inneren der Erythrocyten teilen sie sich erneut und zerstören diese schließlich.
<G-vec00296-002-s389><divide.sich_teilen><en> Almost all long-distance trains travelling from Munich to the north of Germany run in combination to Nuremberg over the high-speed link and then divide up from here.
<G-vec00296-002-s389><divide.sich_teilen><de> Fast alle von München nach Norden führenden Fernverkehrsverbindungen laufen heute gebündelt über die Schnellfahrstrecke nach Nürnberg und teilen sich erst hier auf.
<G-vec00296-002-s390><divide.sich_teilen><en> This room is easy enough to organize and divide into zones.
<G-vec00296-002-s390><divide.sich_teilen><de> Das Zimmer ist einfach genug, um zu organisieren und teilen sich in Zonen.
<G-vec00296-002-s391><divide.sich_teilen><en> They are made homogeneous, or divide into several sectors, creating the effect of the gallery.
<G-vec00296-002-s391><divide.sich_teilen><de> Sie werden homogen gemacht oder teilen sich in mehrere Sektoren auf, wodurch die Wirkung der Galerie entsteht.
<G-vec00296-002-s392><divide.sich_teilen><en> Activated T cells divide every 4-5 hours, much faster than other cell types in the body.
<G-vec00296-002-s392><divide.sich_teilen><de> Aktivierte T-Zellen teilen sich alle 4-5 Stunden, viel schneller als andere Zelltypen des Körpers.
<G-vec00296-002-s303><divide.spalten><en> Stand and believe the simplicity of salvation; for vain theologies divide those who do not understand the simplicity and the pureness of the gospel.
<G-vec00296-002-s303><divide.spalten><de> Steht und glaubt an die Einfachheit der Erlösung; denn vergebliche Gotteslehren spalten jene, die die Einfachheit und die Reinheit der Heilsbotschaft nicht verstehen.
<G-vec00296-002-s304><divide.spalten><en> It is the sign and proof of God's victory over the forces of evil which divide humanity.
<G-vec00296-002-s304><divide.spalten><de> Sie ist Zeichen und Beweis für den Sieg Gottes über die Kräfte des Bösen, die die Menschheit spalten.
<G-vec00296-002-s305><divide.spalten><en> 14:7 Nevertheless these all of you shall not eat of them that chew the cud, or of them that divide the cloven hoof; as the camel, and the hare, and the coney: for they chew the cud, but divide not the hoof; therefore they are unclean unto you.
<G-vec00296-002-s305><divide.spalten><de> 14:7 Das sollt ihr aber nicht essen von dem, das wiederkäut, und von dem, das die Klauen spaltet: das Kamel, der Hase und Kaninchen, die wiederkäuen und doch ihre Klauen nicht spalten, sollen euch unrein sein; 14:8 das Schwein, ob es wohl die Klauen spaltet, so wiederkäut es doch nicht: es soll euch unrein sein.
<G-vec00296-002-s306><divide.spalten><en> „We look forward to playing our part in shaping the association for living together in diversity,“ says Peter Oppinger, Head of Global Marketing with the VAG Group. However, „If we manage to incorporate consistent values for all and develop ideas to unite instead of divide, we will be making the Mannheim Statement a sustained living declaration, also on the part of companies operating internationally here in our city.
<G-vec00296-002-s306><divide.spalten><de> “Wir freuen uns darüber, die Vereinigung für ein Zusammenleben in Vielfalt mit zu gestalten”, so Peter Oppinger, Leiter Globales Marketing der VAG-Gruppe, aber: “Wenn es uns gelingt, für alle stimmige Werte zu verankern und Ideen zu entwickeln, die verbinden, statt spalten, werden wir die Mannheimer Erklärung auch seitens der international tätigen Unternehmen hier in der Stadt nachhaltig mit Leben erfüllen”.
<G-vec00296-002-s307><divide.spalten><en> This move is simply intended to divide and demobilise the protests and give the government time to gather its breath and regroup.
<G-vec00296-002-s307><divide.spalten><de> Mit diesem Schachzug will die Regierung die Proteste spalten und demobilisieren, um eine Verschnaufpause zu bekommen und sich neu aufstellen zu können.
<G-vec00296-002-s308><divide.spalten><en> New tax rules divide owners.
<G-vec00296-002-s308><divide.spalten><de> Neue Steuerregeln spalten Eigentümer.
<G-vec00296-002-s309><divide.spalten><en> In order to digest foods and recycle the proteins of the billions of cells that die each day in every human being, a delicate and complex balance must be maintained within each cell between the proteases, which divide proteins, natural protease inhibitors, which provisionally block the action of the proteases, and protease activators, which reactivate them.
<G-vec00296-002-s309><divide.spalten><de> Um die Nahrung zu verdauen und die Proteine der Milliarden von Zellen, die täglich in jedem Menschen sterben, zu entsorgen, existiert in jeder Zelle ein empfindliches und sehr komplexes Gleichgewicht unter den Proteasen, die die Proteine spalten, zum einen die natürlichen Proteasehemmer, die vorübergehend die Wirkung der Proteasen desaktivieren und zum anderen die Proteaseaktivatoren, die sie wieder zum Einsatz bringen lassen.
<G-vec00296-002-s310><divide.spalten><en> When one steps forward, then will others step up in solidarity and move this world forward and reject the perverse manipulations of groups and governments to control and divide men and nations.
<G-vec00296-002-s310><divide.spalten><de> Wenn einer vorwärts geht, dann werden andere in Solidarität vortreten und diese Welt voran bringen und die perversen Manipulationen von Gruppen und Regierungen ablehnen, Menschen und Nationen zu kontrollieren und zu spalten.
<G-vec00296-002-s311><divide.spalten><en> These unions that participated in this labor mobilization are acutely aware of how racist attacks are used to divide and weaken labor.
<G-vec00296-002-s311><divide.spalten><de> Diese Gewerkschaften, die an der Arbeiter-Mobilisierung beteiligt waren, sind sich darüber tatsächlich bewusst, wie rassistische Angriffe benutzt werden, um die Arbeiterbewegung zu spalten und zu schwächen.
<G-vec00296-002-s312><divide.spalten><en> It is not new but they made it more concrete: they divide refugees in the groups of good and bad.
<G-vec00296-002-s312><divide.spalten><de> Es ist nicht neu, aber jetzt haben sie es konkret gemacht: Sie spalten Geflüchtete in Gut und Böse.
<G-vec00296-002-s313><divide.spalten><en> Contrary to the city center, which for the majority of those passing through is big, bright, sparkling and inviting to use, acts of repression have the goal of incapacitating activists, and to socially marginalize and divide movements.
<G-vec00296-002-s313><divide.spalten><de> Entgegen der Innenstadt, die auf den Großteil der Passant_innen groß, hell, glitzernd und zum Konsum einladend wirkt, haben Repressionen das Ziel, Aktivist_innen handlungsunfähig zu machen, sozial auszugrenzen und soziale Bewegungen zu spalten.
<G-vec00296-002-s314><divide.spalten><en> It’s almost as if players like games which get bigger and better over time with free updates, rather than ones which divide and drain players with a swarm of paid DLC.
<G-vec00296-002-s314><divide.spalten><de> Es ist fast so, als mögen die Spieler Titel, die mit der Zeit und kostenlosen Updates größer und besser werden, statt solcher, die die Spielerbasis mit einem Bezahl-DLC-Schwarm spalten.
<G-vec00296-002-s315><divide.spalten><en> This potential threat should unite – rather than divide – us.
<G-vec00296-002-s315><divide.spalten><de> Diese potenzielle Bedrohung sollte uns einigen – nicht spalten.
<G-vec00296-002-s316><divide.spalten><en> "Even four years after Jiang's regime started to persecute Falun Gong, the Chinese Consulate in Toronto is still using hateful propaganda and manipulating measures to divide Canadian communities.
<G-vec00296-002-s316><divide.spalten><de> Sogar vier Jahre nachdem das Regime Jiangs die Verfolgung von Falun Gong begonnen hatte, setzt das chinesische Konsulat immer noch Hasspropaganda und manipulierende Maßnahmen ein, um die kanadischen Gemeinden zu spalten.
<G-vec00296-002-s317><divide.spalten><en> The Christians in Corinth are described here by Paul as being carnal because they follow men; they have started to divide themselves into groups showing preference to specific people.
<G-vec00296-002-s317><divide.spalten><de> Die Christen in Korinth werden hier von Paulus als fleischlich bezeichnet, da sie Menschen folgen: sie haben begonnen sich in Gruppen zu spalten indem sie Vorliebe für bestimmte Personen zeigen.
<G-vec00296-002-s318><divide.spalten><en> We are not going to let the state split divide us into “good” and “bad” protestors.
<G-vec00296-002-s318><divide.spalten><de> Wir lassen uns nicht spalten in “gute” und “böse” Demonstrierende.
<G-vec00296-002-s319><divide.spalten><en> “A 'leftist' candidate can't win because he'd divide his own camp.
<G-vec00296-002-s319><divide.spalten><de> „Ein 'linker' Kandidat kann nicht siegen, denn er würde sein eigenes Lager spalten.
<G-vec00296-002-s320><divide.spalten><en> Racist immigration and asylum laws have been passed to divide the workers and play one section against the others.
<G-vec00296-002-s320><divide.spalten><de> Rassistische Einwanderungs- und Asylgesetze sollten die ArbeiterInnen spalten und gegeneinander ausspielen.
<G-vec00296-002-s321><divide.spalten><en> Promoting a social, economic, and cultural sense of community and helping to bridge gaps that continue to divide us
<G-vec00296-002-s321><divide.spalten><de> Und drittens, einen sozialen, ökonomischen und kulturellen Gemeinschaftssinn zu fördern, und zu helfen die Unterschiede welche uns bis heute spalten zu überbrücken.
<G-vec00296-002-s254><divide.teilen><en> Divide the dough into 8 equally sized pieces.
<G-vec00296-002-s254><divide.teilen><de> Den Teig in 8 gleich große Portionen teilen und zu Bällen rollen.
<G-vec00296-002-s255><divide.teilen><en> Divide the dough in two and roll out each portion on a floured surface to a roll of about 12 inches (30cm) length.
<G-vec00296-002-s255><divide.teilen><de> Den Teig in zwei Portionen teilen und dann auf einer bemehlten Fläche jeweils zu einer etwa 30m (12 inch) langen Rolle formen.
<G-vec00296-002-s256><divide.teilen><en> Divide the dough into 16 equal pieces.
<G-vec00296-002-s256><divide.teilen><de> Den Kloßteig in 16 gleich große Portionen teilen.
<G-vec00296-002-s257><divide.teilen><en> Divide the dough into 10 equal pieces and cover with a damp towel.
<G-vec00296-002-s257><divide.teilen><de> Den Teig in vier gleich große Portionen teilen.
<G-vec00296-002-s442><divide.trennen><en> Crop and divide audio files in a few clicks.
<G-vec00296-002-s442><divide.trennen><de> Zuschneiden und Trennen von Audio-Dateien mit wenigen Clicks.
<G-vec00296-002-s443><divide.trennen><en> Thus, every presenter has 5 minutes to divide the important from the unimportant.
<G-vec00296-002-s443><divide.trennen><de> Damit hat jeder Präsentierende 5 Minuten Zeit, wichtiges von unwichtigem zu trennen.
<G-vec00296-002-s444><divide.trennen><en> They cushion, insulate, filter, divide, connect and seal: molded parts made of rubber and thermoplastic elastomers.
<G-vec00296-002-s444><divide.trennen><de> Sie dämpfen, isolieren, filtern, trennen, verbinden und dichten: Formteile aus Gummi oder thermoplastischen Elastomeren.
<G-vec00296-002-s445><divide.trennen><en> Satan will always target such a core seeking to split it up and divide it.
<G-vec00296-002-s445><divide.trennen><de> Satan wird immer versuchen, auf einen solchen Kern zu zielen, um ihn zu spalten und zu trennen.
<G-vec00296-002-s446><divide.trennen><en> Ever since the great Situationist and expert on urban complexities Guy Debord, if not before, we have known that communication, especially telematics, not only connects, but can also divide.
<G-vec00296-002-s446><divide.trennen><de> Spätestens seit dem großen Situationisten Guy Debord, dem Experten für urbane Unübersichtlichkeiten, wissen wir, dass Kommunikation, zumal telematisch verfasste, nicht nur verbindet; sie kann auch trennen.
<G-vec00296-002-s447><divide.trennen><en> The work will not grow and expand and enlarge if Satan is allowed a place to divide the people of God.
<G-vec00296-002-s447><divide.trennen><de> Das Werk wird nicht wachsen und sich ausdehnen und größer werden, wenn man Satan Raum lässt, das Volk Gottes zu trennen.
<G-vec00296-002-s448><divide.trennen><en> What we must do is find ways of debating our choices respectfully and in a way that doesn’t just focus on the issues that divide us but seeks to find maximum areas of agreement as well.
<G-vec00296-002-s448><divide.trennen><de> Was wir tun müssen, ist, Wege zu finden, um unsere Entscheidungen respektvoll und auf eine Weise zu diskutieren, die sich nicht nur auf die Probleme konzentriert, die uns trennen, sondern auch versucht, maximale Einigungsbereiche zu finden.
<G-vec00296-002-s449><divide.trennen><en> As the older ones are telling us, when the beehive is filling up, then you have to divide the bees, as they cannot live together anymore."
<G-vec00296-002-s449><divide.trennen><de> Denn wenn der Bienenkorb sich ausfüllt, sagen die Älteren, wenn der Bienenkorb sich ausfüllt, dann muss man die Bienen trennen, weil sie nicht mehr zusammen bleiben können.
<G-vec00296-002-s450><divide.trennen><en> Divide the eggs and whip the egg whites with a dash of salt until stiff.
<G-vec00296-002-s450><divide.trennen><de> Die Eier trennen und das Eiweiß mit einer Prise Salz steifschlagen.
<G-vec00296-002-s451><divide.trennen><en> That is why the greatest danger of all is to allow new walls to divide us from one another.
<G-vec00296-002-s451><divide.trennen><de> Deshalb ist die größte Gefahr von allen, zuzulassen, dass uns neue Mauern von einander trennen...
<G-vec00296-002-s452><divide.trennen><en> PhenQ active ingredients are exactly what divide it from the remainder of the area, and as we shall see, each one supplies a particular set of benefits.
<G-vec00296-002-s452><divide.trennen><de> PhenQ Zutaten sind genau das, was sie von dem Rest des Feldes trennen, und wie wir sehen werden, bietet jeder eine bestimmte Sammlung von Vorteilen.
<G-vec00296-002-s453><divide.trennen><en> We must tear down the barriers of fear, holding grudges and injustice, which divide people and eliminate their dreams and hopes of peace.” The religious leaders were united in acknowledging that the current conflict in Iraq and Syria targets followers of every religion.
<G-vec00296-002-s453><divide.trennen><de> Wir müssen die Mauern der Angst, der Missgunst und der Ungerechtigkeit einreißen, denn diese trennen die Menschen und zerstören ihre Träume und ihre Hoffnung auf Frieden.“ Die religiösen Würdenträger stellten gemeinsam fest, dass der derzeitige Konflikt in Irak und Syrien die Anhänger aller Religionen betrifft.
<G-vec00296-002-s454><divide.trennen><en> With room Panel Curtains large living rooms can be separated into cosy lounges or dining areas and you can divide your workplace from your living space.
<G-vec00296-002-s454><divide.trennen><de> Zu Hause lassen sich große Wohnzimmer mit den textilen Paravents ideal in gemütliche Lounges oder Essecken separieren und der Arbeitsplatz vom Wohnbereich trennen.
<G-vec00296-002-s455><divide.trennen><en> In order to defeat us, the forces of Capital are still using the same tactics, trying to divide us across old nation-state borders, and the new internal borders caused by the latest wave of migration.
<G-vec00296-002-s455><divide.trennen><de> Die Kräfte des Kapitals nutzen noch immer dieselben Taktiken, um uns zu bezwingen: Sie versuchen uns auseinanderzubringen, uns nach den alten national-staatlichen Grenzen und nach den neuen inneren Grenzen, die durch die jüngste Migrationswellen entstanden sind, zu trennen.
<G-vec00296-002-s456><divide.trennen><en> PhenQ active ingredients are exactly what divide it from the remainder of the area, and as we will see, each one gives a certain set of advantages.
<G-vec00296-002-s456><divide.trennen><de> PhenQ Komponenten sind genau das, was sie von dem Rest des Feldes trennen, und wie wir sehen werden, gibt jeder eine bestimmte Sammlung von Vorteilen.
<G-vec00296-002-s457><divide.trennen><en> If you want to make a gate out of wedges, the distance between two wedges has to be bigger than the things you want to divide.
<G-vec00296-002-s457><divide.trennen><de> Wenn Sie ein Gatter aus Keilen machen, dann muss der Abstand zwischen zwei Keilen größer sein, als die Teile, die Sie trennen wollen.
<G-vec00296-002-s458><divide.trennen><en> Reaching into the sea in order to divide the waters of the Atlantic from those of the Bay of Biscay...
<G-vec00296-002-s458><divide.trennen><de> Greift tief ins Meer, um den offenen Atlantik vom Golf von Biskaya zu trennen...
<G-vec00296-002-s459><divide.trennen><en> The EU didn’t anticipate the extent to which the US would exploit it amidst the New Cold War, but as has been widely analyzed, the whole point of renewed US-Russian tensions has been for Washington to divide the EU from Russia and preempt the type of collusion between the two that would torpedo America’s Eurasian hegemony (as per Brzezinski’s forecast in “The Grand Chessboard”).
<G-vec00296-002-s459><divide.trennen><de> Die EU hat nicht vorhergesehen, in welchem Maße die USA sie inmitten des neuen Kalten Krieges ausnutzen würden, aber wie weitgehend analysiert, war der ganze Sinn der erneuerten amerikanisch-russischen Spannungen, dass Washington die EU von Russland trennen und der Verständigung, die Amerikas eurasische Hegemonie torpedieren würde (wie von Brzezinski in seinem “Grand Chessboard/Die Einzige Weltmacht” vorhergesagt), zwischen den beiden vorbeugen könnte.
<G-vec00296-002-s460><divide.trennen><en> 17 God set them in the firmament of the heavens to give light on the earth, 18 and to rule over the day and over the night, and to divide the light from the darkness.
<G-vec00296-002-s460><divide.trennen><de> 17Und Gott setzte sie an das Gewölbe des Himmels, um die Erde zu beleuchten, 18um über den Tag und über die Nacht zu herrschen und um das Licht von der Finsternis zu trennen.
<G-vec00296-002-s473><divide.unterteilen><en> Divide the page into five columns labeled Name, Address, E-mail Address, Phone Number, and Signature.
<G-vec00296-002-s473><divide.unterteilen><de> Unterteile die Seite in fünf Spalten, je eine für Name, Adresse, Email, Telefonnummer und die Unterschrift selbst.
<G-vec00296-002-s474><divide.unterteilen><en> [13] Divide up the hours in the day and decide what you will focus on when.
<G-vec00296-002-s474><divide.unterteilen><de> [13] Unterteile die Stunden des Tages und entscheide, worauf du dich wann konzentrieren willst.
<G-vec00296-002-s475><divide.unterteilen><en> They knew the different between day and night, black and white, and if you draw that you got a cross, overlap this with the southern cross- then divide every quarter in 3 up and down left and right, like puma, snake, condor or past future and present, connect all the points you get 12 angles or 12 months.
<G-vec00296-002-s475><divide.unterteilen><de> Sie kannten den Unterschied zwischen Tag und Nacht, Schwarz und Weiß, und wenn du das aufmalst siehst du ein Kreuz, man lege das Kreuz des Süden da drauf und unterteile jedes Viertel in 3 (oben unten links rechts), wie Puma, Schlange Condor oder Vergangenheit Gegenwart Zukunft, verbindet all die Punkte und man hat 12 ecken oder?= 12 Monate.
<G-vec00296-002-s476><divide.unterteilen><en> Create another ponytail (ponytail C) and divide into two.
<G-vec00296-002-s476><divide.unterteilen><de> Kreiere einen weiteren Zopf (C) und unterteile in zwei Parts.
<G-vec00296-002-s477><divide.unterteilen><en> If needed, divide your project further.
<G-vec00296-002-s477><divide.unterteilen><de> Falls nötig, unterteile dein Projekt weiter.
<G-vec00296-002-s478><divide.unterteilen><en> Divide different styles of songs into different sections.
<G-vec00296-002-s478><divide.unterteilen><de> Unterteile Songs in verschiedene Teile.
<G-vec00296-002-s479><divide.unterteilen><en> Divide your hair into 4-6 sections, depending on how thick your hair is.
<G-vec00296-002-s479><divide.unterteilen><de> Unterteile dein Haar in vier bis sechs Abschnitte, je nach Haardicke.
<G-vec00296-002-s480><divide.unterteilen><en> I divide the days into two types: first the "improve days" and then the "network days".
<G-vec00296-002-s480><divide.unterteilen><de> Ich unterteile die Tage in zwei Typen: zuerst die "improve days" und dann die "network days".
<G-vec00296-002-s535><divide.verteilen><en> In doing so, the cover becomes a second bottom allowing you to divide the contents into two separate halves after opening.
<G-vec00296-002-s535><divide.verteilen><de> So wird der Deckel zum zweiten Boden und der Inhalt kann nach dem Öffnen auf die beiden Hälften verteilt werden.
<G-vec00296-002-s536><divide.verteilen><en> 22but when the stronger than he coming upon [him] overcomes him, he takes away his panoply in which he trusted, and he will divide the spoil [he has taken] from him.
<G-vec00296-002-s536><divide.verteilen><de> 22 wenn aber ein Stärkerer als er über ihn kommt und ihn besiegt, so nimmt er seine ganze Waffenrüstung weg, auf die er vertraute, und seine Beute verteilt er.
<G-vec00296-002-s537><divide.verteilen><en> Generally four air bearing modules are used to move large and heavy loads, but to ensure maximum stability, at least three air bearing modules (preferably four) are required. They should be placed under the load, as far apart from each as possible, and in such way as to divide the weight of the load evenly between them.
<G-vec00296-002-s537><divide.verteilen><de> Um maximale Stabilität zu gewährleisten, sollten mindestens drei Luftkissen-Modulsysteme (besser vier) so weit wie möglich voneinander entfernt und auf solche Weise unter der Last platziert werden, dass das Gewicht der Last gleichmäßig auf sie verteilt ist.
<G-vec00296-002-s538><divide.verteilen><en> By inserting a pause during programming, you can divide the programme into two for recording on both sides of a tape.
<G-vec00296-002-s538><divide.verteilen><de> Sie können bei der Programmierung eine Pause einfügen, so daß Sie Ihr Programm auf die beiden Seiten einer Kassette verteilt aufnehmen können.
<G-vec00296-002-s551><divide.zerlegen><en> We went to the Lufthansa workshop and I was able to divide the split rim with outstanding tools and take the inner tube.
<G-vec00296-002-s551><divide.zerlegen><de> Wir begaben uns zur Lufthansa-Werkstatt, und ich konnte mit hervorragendem Werkzeug die zweigeteilte Felge zerlegen und den Schlauch entnehmen.
<G-vec00296-002-s552><divide.zerlegen><en> ➋ The black cells form dominoes which do not touch orthogonally (diagonally is allowed and necessary). ➌ The black cells divide the diagram into orthogonally contiguous areas of white cells.
<G-vec00296-002-s552><divide.zerlegen><de> ➋ Die schwarzen Felder dürfen nirgendwo eine Fläche der Größe 2x2 überdecken und zerlegen das Diagramm in rechteckige Bereiche orthogonal zusammenhängender weißer Felder.
<G-vec00296-002-s553><divide.zerlegen><en> “We divide up the projects based on what’s known as a scrum principle in software development,” explains Tönnis. “That means clearly defined development tasks with short iteration cycles of two to four weeks.
<G-vec00296-002-s553><divide.zerlegen><de> Andreas Tönnis: „Wir zerlegen die Projekte nach dem,Scrum‘-Prinzip, das in der Softwareentwicklung bekannt ist, in klar definierte Entwicklungsaufgaben mit kurzen Iterationszyklen von zwei bis vier Wochen.
<G-vec00296-002-s554><divide.zerlegen><en> If the railing does not divide into four pieces, you will likely need an assistant to transport it safely.
<G-vec00296-002-s554><divide.zerlegen><de> [1] Wenn sich die Bande nicht in vier Teile zerlegen lässt, wirst du wahrscheinlich einen Helfer brauchen, um sie sicher zu transportieren.
<G-vec00296-002-s555><divide.zerlegen><en> Now pick a few dozen words and divide them into syllables.
<G-vec00296-002-s555><divide.zerlegen><de> Suchen Sie sich aus einem Artikel mindestens ein Dutzend Wörter aus und zerlegen Sie sie in ihre Silben.
<G-vec00296-002-s556><divide.zerlegen><en> We discuss the order with you, advise you with regard to the options, setup the project, divide it into small, individual research jobs and offer these tasks to qualified Clickworkers for processing. After consulting with you, we implement appropriate quality assurance measures and make the payments to the Clickworkers for you.
<G-vec00296-002-s556><divide.zerlegen><de> Wir besprechen den Auftrag mit Ihnen, beraten Sie bezüglich der Möglichkeiten, setzen das Projekt für Sie auf, zerlegen es in Microtasks, bieten diese nur qualifizierten Autoren-Clickworkern zur Bearbeitung an und übernehmen sowohl die Qualitätssicherung als auch die Bezahlung der Clickworker für Sie.
<G-vec00296-002-s557><divide.zerlegen><en> Now it’s time to get together in a joint workshop with the project team and your chosen partner to analyse your timetable and divide the project into work packages.
<G-vec00296-002-s557><divide.zerlegen><de> Nun geht es darum in einem gemeinsamen Workshop mit dem Projektteam und dem Partner den Zeitplan zu analysieren und in Pakete zu zerlegen.
<G-vec00296-002-s559><divide.zerteilen><en> Many wire loops are used to divide up the crystal ingot within a sawing step.
<G-vec00296-002-s559><divide.zerteilen><de> Dabei zerteilen viele Drahtschlaufen den Kristallblock innerhalb eines Sägeschritts.
<G-vec00296-002-s560><divide.zerteilen><en> The goulash is done if the meat can be easily divide up with a spoon & the sauce has a creamy consistency.
<G-vec00296-002-s560><divide.zerteilen><de> Sobald sich das Fleisch leicht mit einem Löffel zerteilen lässt & die Sauce eine cremige Konsistenz hat, ist das Gulasch fertig & kann serviert werden.
<G-vec00296-002-s561><divide.zerteilen><en> All of them combine at a moment or another, consciously or not, to divide us, to set one against the other, to represent us by force, to rob us, to enlist us to go to the army, to analyze us, to threaten us, to buy and sell us, or, more basically, to club us.
<G-vec00296-002-s561><divide.zerteilen><de> All jene verbünden sich früher oder später, ob sie sich dessen bewusst sind oder nicht, um uns zu zerteilen, uns gegeneinander aufzubringen, unserem Dasein ihren Sinn aufzudrücken, uns auszunehmen, uns einzugliedern, uns zu analysieren, uns zu bedrohen, uns zu kaufen und zu verkaufen, oder uns ganz einfach nur niederzuknüppeln.
<G-vec00296-002-s562><divide.zerteilen><en> By setting marks between songs during a live recording, for instance, you can later easily divide that continuous live recording into single tracks. Variable Speed Audition
<G-vec00296-002-s562><divide.zerteilen><de> Wenn Sie beispielsweise während einer Live-Aufnahme Marken zwischen den einzelnen Songs setzen, können Sie die durchgehende Live-Aufnahme später leicht in einzelne Titel zerteilen.
<G-vec00296-002-s563><divide.zerteilen><en> Divide the lettuce heads into leaves, wash and drain as usual and distribute in a large salad bowl.
<G-vec00296-002-s563><divide.zerteilen><de> Die Salate wie üblich zerteilen, waschen, abtropfen lassen, in einer möglichst großen weiten Schüssel auflegen.
<G-vec00296-002-s564><divide.zerteilen><en> Cut the cauliflower in half and divide into florets.
<G-vec00296-002-s564><divide.zerteilen><de> Die Hälfte des Blumenkohls in schöne Röschen zerteilen.
<G-vec00694-002-s198><divide.(sich)_teilen><en> This causes the cell to lose its ability to divide.
<G-vec00694-002-s198><divide.(sich)_teilen><de> Es zwingt die Zelle, die Fähigkeit zu verlieren, geteilt zu werden.
<G-vec00694-002-s199><divide.(sich)_teilen><en> Without prejudice to Article 8(8) and the second subparagraph of Article 7(1), a prospectus composed of separate documents shall divide the required information into a registration document, a securities note and a summary.
<G-vec00694-002-s199><divide.(sich)_teilen><de> Unbeschadet des Artikels 8 Absatz 8 und des Artikels 7 Absatz 1 Unterabsatz 2, werden in einem aus mehreren Einzeldokumenten bestehenden Prospekt die geforderten Angaben in ein Registrierungsformular, eine Wertpapierbeschreibung und eine Zusammenfassung geteilt.
<G-vec00694-002-s200><divide.(sich)_teilen><en> A green belt now spans the continent where the Iron Curtain used to divide it: a unique ecosystem at the nexus of wilderness and cultivation.
<G-vec00694-002-s200><divide.(sich)_teilen><de> Wo Europa einst geteilt war, quert heute ein grünes Band den Kontinent: Ein einzigartiges Ökosystem zwischen Wildnis und Kulturlandschaft.
<G-vec00694-002-s201><divide.(sich)_teilen><en> The settings are in three to five parts, and the vocal parts sometimes divide.
<G-vec00694-002-s201><divide.(sich)_teilen><de> Die Sätze sind drei-bis fünfstimmig, die Chorstimmen dabei teilweise auch geteilt.
<G-vec00694-002-s202><divide.(sich)_teilen><en> In the unions the workers organised divide up into the groups of the trades to which they belong.
<G-vec00694-002-s202><divide.(sich)_teilen><de> In den Gewerkschaften vereinigen sich die Arbeiter geteilt nach den Gewerben, denen sie angehören.
<G-vec00694-002-s203><divide.(sich)_teilen><en> It soon became clear to Depardieu and to me that we needed a joint project, and we proceeded to divide the Festival month of August, which is reserved for me and my team.
<G-vec00694-002-s203><divide.(sich)_teilen><de> Bald war Depardieu und mir klar, dass wir ein gemeinsames Projekt brauchten, und haben uns dann den für mich und mein Küchenteam reservierten Festspielmonat August geteilt.
<G-vec00694-002-s204><divide.(sich)_teilen><en> To make the shoulder strap, cut from the leatherette fabric a rectangle of 10.5×50 cm and divide into 3 parts of 3.5 cm each.
<G-vec00694-002-s204><divide.(sich)_teilen><de> Für den Schulterriemen wird aus dem Kunstlederstoff ein Rechteck von 10,5×50 cm geschnitten und in 3 Teile von je 3,5 cm geteilt.
<G-vec00694-002-s205><divide.(sich)_teilen><en> You then divide for the front legs and the back and chest pieces are worked separately back and forth.
<G-vec00694-002-s205><divide.(sich)_teilen><de> Dann wird die Arbeit für die Vorderbeine geteilt und das Rücken- und Bauchteil werden einzeln in Hin- und Rück-Reihen weitergestrickt.
<G-vec00694-002-s206><divide.(sich)_teilen><en> The ballroom can divide into three equal sized rooms and has a large covered verandah running it's full length.
<G-vec00694-002-s206><divide.(sich)_teilen><de> Der Ballsaal kann in drei Räume gleicher Größe geteilt werden und verfügt über eine große überdachte Veranda, die sich über die gesamte Länge erstreckt.
<G-vec00694-002-s207><divide.(sich)_teilen><en> If the plant is too small to be treated as described above, you can use a knife to carefully divide the rhizome.
<G-vec00694-002-s207><divide.(sich)_teilen><de> Sollte die Pflanze nicht so groß sein, um wie oben beschrieben behandelt zu werden, kann das Rhizom auch vorsichtig mit Hilfe eines Messers geteilt werden.
<G-vec00694-002-s208><divide.(sich)_teilen><en> Use =1/n in a formula, where n is the number you want to divide 1 by.
<G-vec00694-002-s208><divide.(sich)_teilen><de> Sie verwenden =1/n in einer Formel, in der n die Zahl ist, durch die 1 geteilt werden soll.
<G-vec00694-002-s209><divide.(sich)_teilen><en> You can see that it is not necessary to divide members by intermediate nodes to apply concentrated loads.
<G-vec00694-002-s209><divide.(sich)_teilen><de> Es zeigt, dass die Stäbe nicht durch Zwischenknoten geteilt werden müssen, um Einzellasten anzusetzen.
<G-vec00694-002-s254><divide.(sich)_teilen><en> Divide the dough into 8 equally sized pieces.
<G-vec00694-002-s254><divide.(sich)_teilen><de> Den Teig in 8 gleich große Portionen teilen und zu Bällen rollen.
<G-vec00694-002-s255><divide.(sich)_teilen><en> Divide the dough in two and roll out each portion on a floured surface to a roll of about 12 inches (30cm) length.
<G-vec00694-002-s255><divide.(sich)_teilen><de> Den Teig in zwei Portionen teilen und dann auf einer bemehlten Fläche jeweils zu einer etwa 30m (12 inch) langen Rolle formen.
<G-vec00694-002-s256><divide.(sich)_teilen><en> Divide the dough into 16 equal pieces.
<G-vec00694-002-s256><divide.(sich)_teilen><de> Den Kloßteig in 16 gleich große Portionen teilen.
<G-vec00694-002-s257><divide.(sich)_teilen><en> Divide the dough into 10 equal pieces and cover with a damp towel.
<G-vec00694-002-s257><divide.(sich)_teilen><de> Den Teig in vier gleich große Portionen teilen.
<G-vec00694-002-s273><divide.(sich)_teilen><en> However, chemotherapy can also harm healthy cells that divide quickly, such as those that line the mouth and intestines.
<G-vec00694-002-s273><divide.(sich)_teilen><de> Jedoch kann die Chemotherapie auch gesunde Zellen, die sich schnell teilen, wie beispielsweise jene, die den Mund und die Därme säumen, beschädigen.
<G-vec00694-002-s274><divide.(sich)_teilen><en> We have made a place where people can gather, divide into groups based on interest, and move on to do something else.
<G-vec00694-002-s274><divide.(sich)_teilen><de> Wir haben einen Ort geschaffen, an den Menschen kommen, sich nach Interessen teilen und fahren weiter, um ihre Arbeit fortzusetzen.
<G-vec00694-002-s275><divide.(sich)_teilen><en> The research structures are like an organism which is in a state of constant change, can divide and grow, but is also vulnerable.
<G-vec00694-002-s275><divide.(sich)_teilen><de> Die Forschungsstrukturen sind wie ein Organismus, der sich ständig im Wandel befindet, sich teilen und wachsen kann, aber auch verletzlich ist.
<G-vec00694-002-s276><divide.(sich)_teilen><en> For example, such a rate occurs in a bacteria culture, when bacteria divide at a constant rate so that the total number of cells doubles with each division.
<G-vec00694-002-s276><divide.(sich)_teilen><de> Zum Beispiel tritt ein solches Wachstum in einer Bakterienkultur auf, wenn sich die Bakterien konstant teilen, so dass sich die Anzahl der Zellen bei jeder Teilung verdoppelt.
<G-vec00694-002-s277><divide.(sich)_teilen><en> Nuts can divide as right hand thread and left hand thread.
<G-vec00694-002-s277><divide.(sich)_teilen><de> Nüsse können sich als rechter Faden und linker Handfaden teilen.
<G-vec00694-002-s278><divide.(sich)_teilen><en> In both animals, digits form from cartilage cells which divide and mature into bone in regions called growth plates.
<G-vec00694-002-s278><divide.(sich)_teilen><de> In beiden Tieren bilden sich Finger aus Knorpelzellen, die sich teilen und in Abschnitten, die man Wachstumsplatten nennt, zu Knochen weiter wachsen.
<G-vec00694-002-s279><divide.(sich)_teilen><en> While they divide continuously and create new neurons in young animals, a large proportion of the cells in older animals persist in a state of dormancy.
<G-vec00694-002-s279><divide.(sich)_teilen><de> Während sie sich bei jungen Tieren fortlaufend teilen und so neue Nervenzellen entstehen, verharrt ein großer Teil bei älteren Tieren in einem Ruhezustand.
<G-vec00694-002-s280><divide.(sich)_teilen><en> He would soon divide, he said, and soon I would be assigned the place for which I had always secretly been longinag.
<G-vec00694-002-s280><divide.(sich)_teilen><de> Er würde sich teilen, und bald schon würde mir der Platz zugewiesen, nach dem ich mich schon immer insgeheim gesehnt hatte, sagte er.
<G-vec00694-002-s281><divide.(sich)_teilen><en> This tendency, very visible in Europe has pushed the biggest part of the anarchist movement to divide, and to take two apparently opposing roads, that in reality mirroring each other.
<G-vec00694-002-s281><divide.(sich)_teilen><de> Diese Tendenz, die in Europa gut sichtbar ist, hat den Großteil der anarchistischen Bewegung dazu getrieben, sich zu teilen, zwei scheinbar entgegengestellte, aber in Wirklichkeit spiegelverkehrte Wege einzuschlagen.
<G-vec00694-002-s282><divide.(sich)_teilen><en> Still, they all have one thing in common: their cause, the fact that abnormal cells divide uncontrollably and acquire the ability to invade other tissues.
<G-vec00694-002-s282><divide.(sich)_teilen><de> Dennoch haben alle eines gemeinsam: ihre Ursache, nämlich die Tatsache, dass sich veränderte Zellen unkontrolliert teilen und die Fähigkeit entwickeln, in andere Gewebe einzudringen.3 Die meisten Krebsarten werden nach dem Organ oder Zelltyp benannt, von dem sie ausgehen (z.
<G-vec00694-002-s283><divide.(sich)_teilen><en> When cells divide, their genetic information is passed on to both daughter cells in a highly complex process.
<G-vec00694-002-s283><divide.(sich)_teilen><de> Wenn Zellen sich teilen, wird das Erbgut in einem hoch komplexen Prozess an beide Tochterzellen weitergegeben.
<G-vec00694-002-s284><divide.(sich)_teilen><en> It protects against premature degradation of the telomeres, enabling cells to divide more often and for longer.
<G-vec00694-002-s284><divide.(sich)_teilen><de> Er schützt die Telomere vor vorzeitigem Abbau, so dass die Zellen sich öfter und länger teilen können.
<G-vec00694-002-s285><divide.(sich)_teilen><en> 27:17 what he lays up the righteous will wear, and the innocent will divide his silver.
<G-vec00694-002-s285><divide.(sich)_teilen><de> 27:17 so bringt er sie zwar zusammen, aber der Gerechte wird sie anziehen, und in das Geld werden sich die Unschuldigen teilen.
<G-vec00694-002-s286><divide.(sich)_teilen><en> The penis tissue cells will divide over and over again to fill in the gaps (tears) caused by the penile traction process.
<G-vec00694-002-s286><divide.(sich)_teilen><de> Die Peniszellen werden sich immer weiter teilen, um die Lücken (Risse), hervorgerufen durch den penilen Zugkraftprozess, zu schließen.
<G-vec00694-002-s287><divide.(sich)_teilen><en> Another interesting observation is that embryonic her5-expressing cells divide much more than their adult counterparts, hence that their cell cycle is faster that of adult progenitors.
<G-vec00694-002-s287><divide.(sich)_teilen><de> Eine weitere interessante Beobachtung ist, dass sich embryonale her5-exprimierende Zellen viel häufiger teilen können als ihre erwachsenen Gegenstücke, folglich ist ihr Zellzyklus schneller.
<G-vec00694-002-s288><divide.(sich)_teilen><en> When cells divide, they build a giant apparatus - the so called the "mitotic spindle".
<G-vec00694-002-s288><divide.(sich)_teilen><de> Wenn Zellen sich teilen, bauen sie einen gigantischen Apparat auf, die so genannte Zellteilungsspindel.
<G-vec00694-002-s336><divide.(sich)_teilen><en> Further divide each of these three portions into four equal pieces, forming a total of 12 evenly sized rolls.
<G-vec00694-002-s336><divide.(sich)_teilen><de> Teile dann jede dieser Portionen in vier gleich groβe Stücke, sodass du schlieβlich 12 gleich groβe Brötchen erhälst.
<G-vec00694-002-s337><divide.(sich)_teilen><en> To figure out how many US dollars you would need to save at the current exchange rate, divide 20,000 by 226.43.
<G-vec00694-002-s337><divide.(sich)_teilen><de> Um festzustellen, wie viele US Dollar du bei diesem Wechselkurs ansparen musst, teile 20.000 durch 226,43.
<G-vec00694-002-s338><divide.(sich)_teilen><en> Divide the sum of the numbers by the amount of numbers.
<G-vec00694-002-s338><divide.(sich)_teilen><de> Teile die Zahl 58 durch die Anzahl der Zahlen, die du addiert hast.
<G-vec00694-002-s339><divide.(sich)_teilen><en> Divide the product by the denominator (the bottom number) of the fraction.
<G-vec00694-002-s339><divide.(sich)_teilen><de> Teile das Produkt durch den Nenner (die untere Zahl) des Bruches.
<G-vec00694-002-s340><divide.(sich)_teilen><en> 12:13 Then 31 someone from the crowd said to him, “Teacher, tell 32 my brother to divide the inheritance with me.”
<G-vec00694-002-s340><divide.(sich)_teilen><de> 13Einer aus der Volksmenge aber sprach zu ihm: Lehrer, sage meinem Bruder, daß er das Erbe mit mir teile.
<G-vec00694-002-s341><divide.(sich)_teilen><en> 2 Divide the first number of the dividend by the divisor.
<G-vec00694-002-s341><divide.(sich)_teilen><de> Teile den ersten Term des Dividenden durch den ersten Term des Divisors.
<G-vec00694-002-s342><divide.(sich)_teilen><en> Step 2: Divide the number of your outs by the number of possible cards that might appear on the next street.
<G-vec00694-002-s342><divide.(sich)_teilen><de> Schritt 2: Teile die Anzahl deiner Outs durch die Anzahl der möglichen Karten, die an der nächsten Street kommen können.
<G-vec00694-002-s343><divide.(sich)_teilen><en> Divide the card up into three sections: morning, afternoon and night.
<G-vec00694-002-s343><divide.(sich)_teilen><de> Teile den Zettel in 3 Abschnitte ein: Morgen, Nachmittag und Abend.
<G-vec00694-002-s344><divide.(sich)_teilen><en> Divide your hair from ear to ear and from your forehead to the nape of your neck to create 4 sections.
<G-vec00694-002-s344><divide.(sich)_teilen><de> Teile dein Haar von Ohr zu Ohr und von der Stirn bis zum Nacken, um vier Abschnitte zu bilden.
<G-vec00694-002-s345><divide.(sich)_teilen><en> Enumerate the berries and divide them - strong and beautiful ones should be put on the blank, and a little trampled - on the spin.
<G-vec00694-002-s345><divide.(sich)_teilen><de> Zähle die Beeren auf und teile sie - kräftige und schöne sollten auf den Rohling gelegt und ein wenig mit Füßen getreten werden - auf den Spin.
<G-vec00694-002-s346><divide.(sich)_teilen><en> I press and divide.
<G-vec00694-002-s346><divide.(sich)_teilen><de> Ich drücke und teile.
<G-vec00694-002-s347><divide.(sich)_teilen><en> Divide your hair into smaller sections.
<G-vec00694-002-s347><divide.(sich)_teilen><de> Teile dein Haar in kleinere Sektionen.
<G-vec00694-002-s348><divide.(sich)_teilen><en> Divide three by five for a win percentage of 60%.
<G-vec00694-002-s348><divide.(sich)_teilen><de> Teile drei durch vier für einen Gewinnprozentsatz von 60%.
<G-vec00694-002-s349><divide.(sich)_teilen><en> Our part here was to host a track a this year's FSCONS called Divide and Reconquer, which focused on the problem of the trend towards centralised non-free Internet services, and possible solutions.
<G-vec00694-002-s349><divide.(sich)_teilen><de> Unser Beitrag dazu war die Veranstaltung einer Vortragsreihe auf der diesjährigen FSCONS mit dem Namen Divide and Reconquer (Teile und erobere zurück), die das Problem des Trends hin zu zentralisierten unfreien Internetdiensten und mögliche Lösungen dafür in den Fokus stellte.
<G-vec00694-002-s350><divide.(sich)_teilen><en> Divide your new rate by the number of days in the year, 365.
<G-vec00694-002-s350><divide.(sich)_teilen><de> Teile den neuen Zinssatz durch die Anzahl der Tage im Jahr (365).
<G-vec00694-002-s351><divide.(sich)_teilen><en> Divide the answer by 1.8.
<G-vec00694-002-s351><divide.(sich)_teilen><de> Teile das Ergebnis durch 1,8.
<G-vec00694-002-s352><divide.(sich)_teilen><en> Divide and rule strategies, they have.
<G-vec00694-002-s352><divide.(sich)_teilen><de> Ihre Strategie ist: "Teile und Herrsche".
<G-vec00694-002-s353><divide.(sich)_teilen><en> Then divide the dough in equal portions.
<G-vec00694-002-s353><divide.(sich)_teilen><de> Teile den Teig in 3 gleich große Stücke.
<G-vec00694-002-s354><divide.(sich)_teilen><en> Take your calorie requirement and divide it into these 3 categories.
<G-vec00694-002-s354><divide.(sich)_teilen><de> Nimm deinen Kalorienbedarf und teile ihn in diese 3 Kategorien auf.
<G-vec00694-002-s355><divide.(sich)_teilen><en> Remove the dough from the fridge and divide into four balls and roll out thinly
<G-vec00694-002-s355><divide.(sich)_teilen><de> Den Teig aus dem Kühlschrank nehmen und in vier gleich große Teile teilen.
<G-vec00694-002-s356><divide.(sich)_teilen><en> This is the reason why the authorities needed to divide the railway into two.
<G-vec00694-002-s356><divide.(sich)_teilen><de> Aus diesem Grund mussten die Behörden die Bahn in zwei Teile teilen.
<G-vec00694-002-s357><divide.(sich)_teilen><en> It is possible to divide the plot into 2 if you wish.
<G-vec00694-002-s357><divide.(sich)_teilen><de> Wenn Sie möchten, können Sie die Handlung in zwei Teile teilen.
<G-vec00694-002-s358><divide.(sich)_teilen><en> Indole-3-carbinol, for example, halts the cell cycle in breast cancer cells without actually killing the cells.3 The cell cycle is a rigidly controlled series of steps a cell must go through before it can divide in two, involving the duplication of the cell's contents and a final split.
<G-vec00694-002-s358><divide.(sich)_teilen><de> Indol-3-Carbinol beispielsweise stoppt den Zellzyklus in Brustkrebszellen, ohne die Zellen tatsächlich abzutöten: Der Zellzyklus ist eine streng kontrollierte Abfolge von Schritten, die eine Zelle durchlaufen muss, bevor sie sich in zwei Teile teilen kann, einschließlich der Verdoppelung des Zellinhalts und einer endgültigen Teilung.
<G-vec00694-002-s359><divide.(sich)_teilen><en> The relevance of menstrual dates is that most books use them to discuss the progress of your pregnancy and further divide it into three trimesters.
<G-vec00694-002-s359><divide.(sich)_teilen><de> Die Bedeutung der Menstruationsdaten ist, daß die meisten Bücher sie benutzen, um den Fortschritt Ihrer Schwangerschaft zu besprechen und ihn in drei Trimester weiter zu teilen.
<G-vec00694-002-s360><divide.(sich)_teilen><en> English Revised Version These are the names of the men which shall divide the land unto you for inheritance: Eleazar the priest, and Joshua the son of Nun.
<G-vec00694-002-s360><divide.(sich)_teilen><de> 16Und der HERR redete mit Mose und sprach: 17Das sind die Namen der Männer, die das Land unter euch teilen sollen: der Priester Eleasar und Josua, der Sohn Nuns.
<G-vec00694-002-s361><divide.(sich)_teilen><en> Such is the fact which emerges from the study of the whole history of these two peoples that we can not divide.
<G-vec00694-002-s361><divide.(sich)_teilen><de> Das ist die Tatsache, die aus dem Studium der ganzen Geschichte dieser beiden Völker hervorgeht, die wir nicht teilen können.
<G-vec00694-002-s362><divide.(sich)_teilen><en> If you have no idea how to better divide the space in the office, the house, at work or in the shop, we would advise you sliding glass doors.
<G-vec00694-002-s362><divide.(sich)_teilen><de> Wissen Sie nicht wie Sie Ihren Platz im Büro, zu Hause, in der Firma oder im Geschäft am besten teilen können, dann raten wir Ihnen zu den Schiebetüren aus Glas.
<G-vec00694-002-s363><divide.(sich)_teilen><en> All of these office typologies are shaped by vertical surfaces that create and partition spaces, that divide office floors into either closed or open areas.
<G-vec00694-002-s363><divide.(sich)_teilen><de> Alle diese Bürotypologien sind geprägt von vertikalen, Raum bildenden und Raum gliedernden Flächen, die das Geschoß entweder in geschlossene oder offene Bereiche teilen.
<G-vec00694-002-s364><divide.(sich)_teilen><en> In the emergency it is also easy to divide the treasures with co-travelers.
<G-vec00694-002-s364><divide.(sich)_teilen><de> In der Not fällt es auch leicht, die Schätze mit Mitreisenden zu teilen.
<G-vec00694-002-s365><divide.(sich)_teilen><en> In order to divide, cells in the intestinal wall have to leave their densely packed environment and migrate to the surface.
<G-vec00694-002-s365><divide.(sich)_teilen><de> Damit sich Zellen der Darmwand teilen können, müssen sie ihre dichtgepackte Umgebung verlassen und an die Oberfläche wandern.
<G-vec00694-002-s366><divide.(sich)_teilen><en> You can divide your hand into 3 steps and you can do with a total of 4 hands.
<G-vec00694-002-s366><divide.(sich)_teilen><de> Sie können Ihre Hand in 3 Schritte und vollständig mit 4 Händen teilen.
<G-vec00694-002-s367><divide.(sich)_teilen><en> For groups of more than 10 persons we divide the participants into two groups.
<G-vec00694-002-s367><divide.(sich)_teilen><de> Bei Gruppengrößen über 10 Personen teilen wir die Teilnehmer in zwei Gruppen auf.
<G-vec00694-002-s368><divide.(sich)_teilen><en> Breaking Points The renegades and Gatewatch divide their efforts to attack Tezzeret's operation on multiple fronts.
<G-vec00694-002-s368><divide.(sich)_teilen><de> Die Renegaten und die Wächter teilen ihre Bemühungen auf, um Tezzerets Operation an mehreren Fronten anzugreifen.
<G-vec00694-002-s369><divide.(sich)_teilen><en> Marxists do not divide the world into “good” and “bad” nations, we recognize the democratic right to self-determination of all nations while opposing all nationalist ideologies with the program of revolutionary internationalist class struggle.
<G-vec00694-002-s369><divide.(sich)_teilen><de> Marxisten teilen die Welt nicht in „gute“ und „schlechte“ Nationen, wir erkennen das demokratische Recht auf Selbstbestimmung aller Nationen an, und stellen allen nationalistischen Ideologien das Programm von revolutionärem internationalistischen Klassenkampf entgegen.
<G-vec00694-002-s370><divide.(sich)_teilen><en> A rule of thumb that Lynch used to combine growth and value is to take the long-term growth rate, add the dividend yield, and divide the total by the price-to-earnings ratio (P/E).
<G-vec00694-002-s370><divide.(sich)_teilen><de> Eine Faustregel zur Kombination von Wachstum und Wert, die Lynch verwendete, ist die langfristige Wachstumsrate eines Unternehmens zu nehmen, die Dividendenrendite hinzu zu addieren und das Ergebnis durch das Kurs-Gewinn-Verhältnis (KGV) zu teilen.
<G-vec00694-002-s371><divide.(sich)_teilen><en> The main fact in the creation of interior design is the lack of interior partitions, which obliges to divide space into functional zones.
<G-vec00694-002-s371><divide.(sich)_teilen><de> Die wichtigste Tatsache bei der Schaffung von Innenarchitektur ist das Fehlen von Innenwänden, die den Raum in funktionale Zonen teilen müssen.
<G-vec00694-002-s372><divide.(sich)_teilen><en> They divide the gently lit exhibition space diagonally.
<G-vec00694-002-s372><divide.(sich)_teilen><de> Sie teilen den sanft beleuchteten Ausstellungsraum diagonal.
<G-vec00694-002-s373><divide.(sich)_teilen><en> Category management We divide all expenditure into a standard set of categories.
<G-vec00694-002-s373><divide.(sich)_teilen><de> Kategorienmanagement Wir teilen alle Ausgabe in Standardkategorien ein.
<G-vec00694-002-s374><divide.(sich)_teilen><en> In other words, we should applaud the sacrifice of low wage, part-time workers, who divide up capitalist scarcity and poverty amongst themselves for the "greater good."
<G-vec00694-002-s374><divide.(sich)_teilen><de> Mit anderen Worten sollen wir den Opfern der NiedriglohnempfängerInnen und Teilzeitarbeitenden, die die kapitalistische Kargheit und Armut unter sich um des „höheren Guts willen“ teilen, applaudieren.
<G-vec00694-002-s375><divide.(sich)_teilen><en> Continue by taking out the dough. Divide into three equal parts.
<G-vec00694-002-s375><divide.(sich)_teilen><de> Den Teig aus dem Kühlschrank holen und in drei gleich große Teile teilen.
<G-vec00694-002-s376><divide.(sich)_teilen><en> Since the unionizing and communists movements of the 1920s to the COINTEL PRO FBI program of the 1970s to suppress the Black Liberation movement, government authorities have used tactics like wiretapping phones, intercepting mail, and infiltrating groups to “divide and conquer".
<G-vec00694-002-s376><divide.(sich)_teilen><de> Von den Gewerkschaftsbewegungen und den kommunistischen Bewegungen der 1920er bis zum COINTEL PRO FBI Programm der 1970er zur Unterdrückung der schwarzen Befreiungsbewegung haben Regierungsbehörden Taktiken wie das Abhören von Telefonen, das Abfangen von Postsendungen und die Infiltration von Gruppen angewandt, um „zu teilen und zu herrschen“.
<G-vec00694-002-s377><divide.(sich)_teilen><en> Symptoms of glaucoma in the eye make it possible to divide it into two forms: closed-angle and open-angle.
<G-vec00694-002-s377><divide.(sich)_teilen><de> Die Symptome des Glaukoms im Auge machen es möglich, es in zwei Formen zu teilen: geschlossener Winkel und offener Winkel.
<G-vec00694-002-s378><divide.(sich)_teilen><en> Each day, the cells of the human body divide billions of times; this also requires duplication of their genetic information.
<G-vec00694-002-s378><divide.(sich)_teilen><de> Die Zellen des menschlichen Körpers und die darin enthaltene Erbinformation teilen sich milliardenfach, jeden Tag.
<G-vec00694-002-s379><divide.(sich)_teilen><en> They extend along the coast for more than 250km and divide into numerous layers.
<G-vec00694-002-s379><divide.(sich)_teilen><de> Sie erstrecken sich entlang der Küste mehr als 250km und teilen sich in vielen Schichten.
<G-vec00694-002-s380><divide.(sich)_teilen><en> Amphibola bests break into shorter fibers or divide into thinner fibers along their longitudinal cleavage.
<G-vec00694-002-s380><divide.(sich)_teilen><de> Amphibolasbeste brechen zu kürzeren Fasern oder teilen sich entlang Ihrer Längsspaltbarkeit zu dünneren Fasern.
<G-vec00694-002-s381><divide.(sich)_teilen><en> Employers and employees divide social security contributions in half.
<G-vec00694-002-s381><divide.(sich)_teilen><de> Arbeitgeber/in und Arbeitnehmer/in teilen sich die Sozialbeiträge hälftig.
<G-vec00694-002-s382><divide.(sich)_teilen><en> At this point the production lines divide again: some of the salmon fillets are taken away to be packaged as finished products, while the rest are cut into portion-sized pieces and then packaged up.
<G-vec00694-002-s382><divide.(sich)_teilen><de> Hier teilen sich die Produktionslinien erneut: Ein Teil der Lachsfilets wird als fertiges Produkt der Verpackung zugeführt, der andere Teil wird in Portionsstücke geschnitten und anschließend verpackt.
<G-vec00694-002-s383><divide.(sich)_teilen><en> these 15 exclusive housing units divide each other in nine, or six, apartments in two building structures, through which the distance to the the next neighbor was extended and your privacy is being protected optimally.
<G-vec00694-002-s383><divide.(sich)_teilen><de> Die 15 exklusiven Wohneinheiten teilen sich zu neun beziehungsweise sechs Wohnungen auf zwei Baukörper auf, wodurch die Entfernung zum nächsten Nachbarn erweitert wurde und Ihre Privatsphäre optimal geschützt wird.
<G-vec00694-002-s384><divide.(sich)_teilen><en> The latter divide into three LFOs and a CV modulation sequence.
<G-vec00694-002-s384><divide.(sich)_teilen><de> Letztere teilen sich in drei LFOs und eine CV-Sequenz auf.
<G-vec00694-002-s385><divide.(sich)_teilen><en> Some cells divide repeatedly, while others appear to develop into more mature cell types that no longer divide.
<G-vec00694-002-s385><divide.(sich)_teilen><de> Einige dieser Zellen teilen sich wiederholt, während andere sich zu ausgereiften, spezialisierten Zelltypen entwickeln, die sich nicht mehr vermehren können.
<G-vec00694-002-s386><divide.(sich)_teilen><en> Typically, slot machines divide by 32, 64,128, 256 or 512.
<G-vec00694-002-s386><divide.(sich)_teilen><de> Gewöhnlich teilen sich Spielautomaten durch 32, 64.128, 256 oder 512.
<G-vec00694-002-s387><divide.(sich)_teilen><en> Further crushing of the blastomeres does not occur synchronously: some cells divide faster, some slower, resulting in the formation of a morula (the so-called stage of development of the human embryo, numbering about a hundred cells).
<G-vec00694-002-s387><divide.(sich)_teilen><de> Eine weitere Zerkleinerung der Blastomeren findet nicht synchron statt: einige Zellen teilen sich schneller, einige langsamer, was zur Bildung einer Morula führt (das sogenannte Entwicklungsstadium des menschlichen Embryos, das etwa 100 Zellen umfasst).
<G-vec00694-002-s388><divide.(sich)_teilen><en> Once inside the erythrocytes, they divide again and ultimately destroy them.
<G-vec00694-002-s388><divide.(sich)_teilen><de> Im Inneren der Erythrocyten teilen sie sich erneut und zerstören diese schließlich.
<G-vec00694-002-s389><divide.(sich)_teilen><en> Almost all long-distance trains travelling from Munich to the north of Germany run in combination to Nuremberg over the high-speed link and then divide up from here.
<G-vec00694-002-s389><divide.(sich)_teilen><de> Fast alle von München nach Norden führenden Fernverkehrsverbindungen laufen heute gebündelt über die Schnellfahrstrecke nach Nürnberg und teilen sich erst hier auf.
<G-vec00694-002-s390><divide.(sich)_teilen><en> This room is easy enough to organize and divide into zones.
<G-vec00694-002-s390><divide.(sich)_teilen><de> Das Zimmer ist einfach genug, um zu organisieren und teilen sich in Zonen.
<G-vec00694-002-s391><divide.(sich)_teilen><en> They are made homogeneous, or divide into several sectors, creating the effect of the gallery.
<G-vec00694-002-s391><divide.(sich)_teilen><de> Sie werden homogen gemacht oder teilen sich in mehrere Sektoren auf, wodurch die Wirkung der Galerie entsteht.
<G-vec00694-002-s392><divide.(sich)_teilen><en> Activated T cells divide every 4-5 hours, much faster than other cell types in the body.
<G-vec00694-002-s392><divide.(sich)_teilen><de> Aktivierte T-Zellen teilen sich alle 4-5 Stunden, viel schneller als andere Zelltypen des Körpers.
<G-vec00694-002-s393><divide.(sich)_teilen><en> While making the hair ready for straightening, divide the hair into layers, strands and sections.
<G-vec00694-002-s393><divide.(sich)_teilen><de> Teilen Sie das Haar in Schichten, Strähnen und Abschnitte, während Sie es für das Glätten vorbereiten.
<G-vec00694-002-s394><divide.(sich)_teilen><en> Divide the class into pairs.
<G-vec00694-002-s394><divide.(sich)_teilen><de> Teilen Sie die Klasse in Zweiergruppen ein.
<G-vec00694-002-s395><divide.(sich)_teilen><en> Divide the treatment on the hair.
<G-vec00694-002-s395><divide.(sich)_teilen><de> Teilen Sie das Shampoo auf das nasse Haar.
<G-vec00694-002-s396><divide.(sich)_teilen><en> Divide Kadus Satin On Anti-Frizz Serum on towel-dried hair.
<G-vec00694-002-s396><divide.(sich)_teilen><de> Teilen Sie Kadus auf das handtuchtrockene Haar.
<G-vec00694-002-s397><divide.(sich)_teilen><en> Pull an equal amount of extension hair and divide it by half.
<G-vec00694-002-s397><divide.(sich)_teilen><de> Ziehen Sie eine gleiche Menge Verlängerungshaar und teilen Sie es durch die Hälfte.
<G-vec00694-002-s398><divide.(sich)_teilen><en> Once more divide the ends into two equal bundles, then twist each bundle.
<G-vec00694-002-s398><divide.(sich)_teilen><de> Teilen Sie die Litze einmal mehr in zwei gleiche Bündel auf und verdrillen diese separat.
<G-vec00694-002-s399><divide.(sich)_teilen><en> STEP 2: Divide that number by your total number of followers and multiply by 100 to get your amplification rate percentage.
<G-vec00694-002-s399><divide.(sich)_teilen><de> SCHRITT 2: Teilen Sie diese Zahl durch die Gesamtzahl Ihrer Follower und multiplizieren Sie das Ergebnis mit 100, um Ihre prozentuale Amplifikations-Rate zu ermitteln.
<G-vec00694-002-s400><divide.(sich)_teilen><en> Divide the hair into four sections.
<G-vec00694-002-s400><divide.(sich)_teilen><de> Teilen Sie das Haar in vier Abschnitte.
<G-vec00694-002-s401><divide.(sich)_teilen><en> Divide the soft butter into smaller... Read more
<G-vec00694-002-s401><divide.(sich)_teilen><de> Teilen Sie die Butter in kleine Stücke und geben Sie sie...
<G-vec00694-002-s402><divide.(sich)_teilen><en> Divide the whole area into a number of rooms.
<G-vec00694-002-s402><divide.(sich)_teilen><de> Teilen Sie den ganzen Bereich in einige Räume unter.
<G-vec00694-002-s403><divide.(sich)_teilen><en> Divide your company in efficient departments.
<G-vec00694-002-s403><divide.(sich)_teilen><de> Teilen Sie Ihr Unternehmen in effiziente Abteilungen.
<G-vec00694-002-s404><divide.(sich)_teilen><en> Divide the spool and then it does not matter.
<G-vec00694-002-s404><divide.(sich)_teilen><de> Teilen Sie die Spule und dann spielt es keine Rolle.
<G-vec00694-002-s405><divide.(sich)_teilen><en> Divide one Laser beam into smaller Laser beam than hair.
<G-vec00694-002-s405><divide.(sich)_teilen><de> Teilen Sie einen Laserstrahl in einen kleineren Laserstrahl als das Haar.
<G-vec00694-002-s406><divide.(sich)_teilen><en> Divide the daily ration into several portions.
<G-vec00694-002-s406><divide.(sich)_teilen><de> Teilen Sie die Tagesration in mehrere Portionen auf.
<G-vec00694-002-s407><divide.(sich)_teilen><en> 4 Divide the vegetables over 4 plates, divide the mackerel over the vegetables.
<G-vec00694-002-s407><divide.(sich)_teilen><de> 4 Verteilen Sie das Gemüse auf 4 Teller, teilen Sie die Makrelen auf das Gemüse.
<G-vec00694-002-s408><divide.(sich)_teilen><en> So keep this in mind and do not increase everything, but divide this between the muscle groups.
<G-vec00694-002-s408><divide.(sich)_teilen><de> Denken Sie also daran und erhöhen Sie nicht alles, sondern teilen Sie dies auf die Muskelgruppen auf.
<G-vec00694-002-s409><divide.(sich)_teilen><en> Take the dish out of the oven, let it cool a little and then divide it into bars of equal size.
<G-vec00694-002-s409><divide.(sich)_teilen><de> Nehmen Sie das Gericht aus dem Ofen, lassen Sie es ein wenig abkühlen und teilen Sie es in gleich große Riegel.
<G-vec00694-002-s410><divide.(sich)_teilen><en> Alternatively, type MSINFO32 in Command Prompt, once in System Information, click Component, then Storage and finally Disk, to look for the number of partition Starting Offset; then divide it by 4096.
<G-vec00694-002-s410><divide.(sich)_teilen><de> Geben Sie alternativ MSINFO32 in die Eingabeaufforderung ein, und klicken Sie unter Systeminformationen auf Komponente, dann Speicher und abschließend Festplatte, um die Zahl des Startoffsets der Partition zu suchen; teilen Sie diese dann durch 4096.
<G-vec00694-002-s411><divide.(sich)_teilen><en> Divide the shampoo into wet hair.
<G-vec00694-002-s411><divide.(sich)_teilen><de> Teilen Sie das Shampoo in das nasse Haar.
<G-vec00694-002-s412><divide.(sich)_teilen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00694-002-s412><divide.(sich)_teilen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00694-002-s413><divide.(sich)_teilen><en> 17And he took a cup, and when he had given thanks he said, "Take this, and divide it among yourselves.
<G-vec00694-002-s413><divide.(sich)_teilen><de> 17Und er nahm einen Kelch, dankte und sprach: Nehmet diesen und teilet ihn unter euch.
<G-vec00694-002-s414><divide.(sich)_teilen><en> 13 "The kings of the armies, they flee, they flee!" The women at home divide the spoil,
<G-vec00694-002-s414><divide.(sich)_teilen><de> 13 Die Könige der Heerscharen sind untereinander Freunde, und die Hausehre teilet den Raub aus.
<G-vec00694-002-s415><divide.(sich)_teilen><en> 22:17 And having taken the chalice, he gave thanks, and said: Take, and divide it among you:
<G-vec00694-002-s415><divide.(sich)_teilen><de> 22:17 Und er nahm den Kelch, dankete und sprach: Nehmet denselbigen und teilet ihn unter euch.
<G-vec00694-002-s416><divide.(sich)_teilen><en> I have said, Thou and Ziba divide the land.
<G-vec00694-002-s416><divide.(sich)_teilen><de> Ich habe es gesagt:Du und Ziba teilet den Acker miteinander.
<G-vec00694-002-s030><divide.aufteilen><en> Decoction to divide into equal portions and drink during the day.
<G-vec00694-002-s030><divide.aufteilen><de> Brühe aufgeteilt in gleiche Portionen und trinken während des Tages.
<G-vec00694-002-s031><divide.aufteilen><en> In so doing, each individual document (deed) is to be submitted as one PDF document, i.e., don't divide one deed into several documents nor merge several deeds into one PDF.
<G-vec00694-002-s031><divide.aufteilen><de> Jede einzelne Urkunde ist dabei als eine PDF-Datei zu übergeben, d.h. die einzelne Urkunde darf nicht in mehrere Dokumente aufgeteilt werden, und mehrere Urkunden dürfen nicht in eine PDF-Datei zusammengefasst werden.
<G-vec00694-002-s032><divide.aufteilen><en> The walls can be used in office planning to create individual rooms or even divide a large area into smaller rooms to provide additional structure.
<G-vec00694-002-s032><divide.aufteilen><de> So können in der Büroplanung einzelne Räume entstehen oder auch ganze Bereiche in kleinere Räume aufgeteilt und damit strukturiert werden.
<G-vec00694-002-s033><divide.aufteilen><en> In light of these presentations, the Relator of the Synod formulates a series of points for discussion during the second phase, when all the Synodal members divide into small groups (circuli minores) according to the various languages spoken.
<G-vec00694-002-s033><divide.aufteilen><de> b. Unter Berücksichtigung dieser Schilderungen formuliert der Relator der Synode eine Reihe von Diskussionspunkten für die zweite Phase, bei der die Synodenmitglieder, aufgeteilt nach Sprachen in kleinen Gruppen zusammenkommen - den so genannten “Circuli minores”.
<G-vec00694-002-s034><divide.aufteilen><en> Eat these types of food daily in small portions and divide into small portions of food.
<G-vec00694-002-s034><divide.aufteilen><de> Eat diese Arten von Lebensmitteln täglich in kleinen Portionen und in kleine Mahlzeiten aufgeteilt.
<G-vec00694-002-s035><divide.aufteilen><en> When the community property arrangement comes to an end, the debts incurred in respect of the joint property must be deducted in order to divide the excess remaining into two equal shares for the two spouses (§ 1476 par.
<G-vec00694-002-s035><divide.aufteilen><de> Im Falle der Beendigung der Gütergemeinschaft sind die Gesamtgutverbindlichkeiten zunächst abzuziehen, bevor ein verbleibender Überschuss unter den Ehegatten hälftig aufgeteilt wird (§ 1476 Abs.
<G-vec00694-002-s036><divide.aufteilen><en> Using the "Type" field we can divide the companies to potential clients (Potential) and real clients (Clients).
<G-vec00694-002-s036><divide.aufteilen><de> Mittels des Feldes "Typ" können die Unternehmen in potentielle Kunden (Potentials) und reelle Kunden (Clients) aufgeteilt werden.
<G-vec00694-002-s037><divide.aufteilen><en> In Allplan Engineering 2016, the direct modification of placements has been improved so they are now easy to divide and change.
<G-vec00694-002-s037><divide.aufteilen><de> In Allplan Engineering 2016 wurde die Direktmodifikation von Verlegungen verbessert, so dass sie nun einfach aufgeteilt und verändert werden können.
<G-vec00694-002-s038><divide.aufteilen><en> A type of partitioning that lets you divide your large database into smaller databases, which can be managed faster more easily across servers.
<G-vec00694-002-s038><divide.aufteilen><de> Ein Partitionstyp, den Sie zum Aufteilen Ihrer großen Datenbank in kleinere Datenbanken verwenden können, um diese so schneller und einfacher auf Servern verwalten zu können.
<G-vec00694-002-s039><divide.aufteilen><en> Sliding elements can be used to divide the home into 6 areas (living room, master bedroom, kid’s bedroom, grandmother’s bedroom, guestroom, and service room).
<G-vec00694-002-s039><divide.aufteilen><de> Schiebeelemente können die Wohnung in 6 Bereiche (Wohnen, Eltern, Kind, Großmutter, Gäste und Service) aufteilen.
<G-vec00694-002-s040><divide.aufteilen><en> Divide the cookie dough into 12 equal portions and place with enough space between on the baking sheet.
<G-vec00694-002-s040><divide.aufteilen><de> Den Teig in 12 gleichgroße Portionen aufteilen und mit etwas Abstand auf das Blech legen.
<G-vec00694-002-s041><divide.aufteilen><en> There are many factors involved in the deployment of metallic paneling. To hide technology, divide or combine structures, as protection, or for practical or decorative reasons.
<G-vec00694-002-s041><divide.aufteilen><de> Technologie verbergen, Strukturen aufteilen oder zusammenfassen, als Schutz, aus Zweckmäßigkeit oder aus dekorativen Aspekten – für den Einsatz von Verkleidungen aus metallischen Werkstoffen sprechen viele Faktoren.
<G-vec00694-002-s042><divide.aufteilen><en> The service can extract pages from the source document or divide a source document based on bookmarks.
<G-vec00694-002-s042><divide.aufteilen><de> Der Dienst kann Seiten aus dem Quelldokument extrahieren oder ein Quelldokument basierend auf Lesezeichen aufteilen.
<G-vec00694-002-s043><divide.aufteilen><en> They will divide all nine symphonies among themselves, much as in the symphony cycle 4 September
<G-vec00694-002-s043><divide.aufteilen><de> Sie werden »alle Neune« – analog zum Symphonien-Zyklus im März – unter sich aufteilen.
<G-vec00694-002-s044><divide.aufteilen><en> Since you are all friends, you want to divide the pizza fairly.
<G-vec00694-002-s044><divide.aufteilen><de> Da ihr alle Freunde seit, wollt ihr die Pizza ganz gerecht aufteilen.
<G-vec00694-002-s045><divide.aufteilen><en> Divide the risen dough in three parts, roll out and place on an oiled round baking pan.
<G-vec00694-002-s045><divide.aufteilen><de> Den aufgegangenen Teig in drei Stücke aufteilen, ausrollen und in eine runde befettete Backform legen.
<G-vec00694-002-s046><divide.aufteilen><en> Since the transceivers have two parallel CS connectors, breakout applications can be realised: Network engineers can plug two CS patch cables into one transceiver and divide the 200G into 2 100G.
<G-vec00694-002-s046><divide.aufteilen><de> Da sich in den Transceivern zwei parallele CS-Anschlüsse befinden, lassen sich Breakout-Anwendungen realisieren: Netzwerktechniker können zwei CS-Patchkabel in einen Transceiver stecken und die 200G in 2 x 100G aufteilen.
<G-vec00694-002-s047><divide.aufteilen><en> But over time our strengths showed themselves and we could therefore divide the areas among ourselves.
<G-vec00694-002-s047><divide.aufteilen><de> Doch mit der Zeit haben sich unsere Stärken herauskristallisiert und so konnten wir uns die Bereiche untereinander aufteilen.
<G-vec00694-002-s048><divide.aufteilen><en> Let us now subdivide the different incentives into 3 options, namely metabolic, hypertrophy and neuro / power (we could still divide these between themselves, but for now I will leave that for what it is to make the story not too complicated).
<G-vec00694-002-s048><divide.aufteilen><de> Unterteilen wir nun die verschiedenen Anreize in drei Optionen, nämlich Stoffwechsel, Hypertrophie und Neuro / Power (wir könnten diese immer noch untereinander aufteilen, aber im Moment werde ich das so belassen, dass die Geschichte nicht zu kompliziert wird).
<G-vec00694-002-s049><divide.aufteilen><en> With the help of thread curtains, you can easily divide the room into zones, without the feeling of tightness.
<G-vec00694-002-s049><divide.aufteilen><de> Mit Hilfe von Fadenvorhängen können Sie den Raum problemlos in Zonen aufteilen, ohne dass Sie sich fest fühlen.
<G-vec00694-002-s050><divide.aufteilen><en> When it comes to organising your getaway, you can divide the island into three large areas: the south, where you will find the Tenerife-South International Airport; the north, which is home to the Tenerife-North International Airport; and the metropolitan area.
<G-vec00694-002-s050><divide.aufteilen><de> Um Ihren Aufenthalt besser zu organisieren, können Sie die Insel in drei Gebiete aufteilen: der Süden, in dem sich der internationale Flughafen Tenerife Sur befindet, der Norden mit dem Flughafen Tenerife Norte und das Gebiet um die Hauptstadt.
<G-vec00694-002-s051><divide.aufteilen><en> You could either create a segment for every time zone your recipients live in or divide your subscribers into manageable segments.
<G-vec00694-002-s051><divide.aufteilen><de> Sie können entweder ein Segment für jede Zeitzone erstellen, in der Ihre Empfänger leben, oder Ihre Abonnenten in einfacher verwaltbare Segmente aufteilen.
<G-vec00694-002-s052><divide.aufteilen><en> To use this command, choose Object > Path > Divide Objects Below.
<G-vec00694-002-s052><divide.aufteilen><de> Wenn Sie diesen Befehl verwenden möchten, wählen Sie „Objekt“ > „Pfad“ > „Darunter liegende Objekte aufteilen“.
<G-vec00694-002-s053><divide.aufteilen><en> The Text to Columns tool in Excel can quickly select the proper delimiter and divide the data into columns correctly.
<G-vec00694-002-s053><divide.aufteilen><de> Das Tool "Text zu Spalten" in Excel kann schnell das richtige Trennzeichen auswählen und die Daten richtig auf die Spalten aufteilen.
<G-vec00694-002-s054><divide.aufteilen><en> A session moderator on the web browser view of Collaborate can divide participants into groups for smaller projects and collaboration.
<G-vec00694-002-s054><divide.aufteilen><de> Eine Sitzungsmoderator-Browseransicht von Collaborate kann Teilnehmer für kleinere Projekte und Gruppenarbeiten in Gruppen aufteilen.
<G-vec00694-002-s055><divide.aufteilen><en> In between are countless regions which those who have journeyed from one end to the other often divide into three distinct planes in accordance with the balance of positive – spiritual and Negative – material forces in each plane .
<G-vec00694-002-s055><divide.aufteilen><de> Dazwischenliegen unzählige Regionen, welche diejenigen, die von einem Ende zum anderen gelangt sind, oftmals in drei unterschiedliche Ebenen aufteilen, entsprechend dem besonderen Ausgleich von positiv-spirituellen und negativ-materiellen Kräften.
<G-vec00694-002-s056><divide.aufteilen><en> Industry We can divide our production into several product ranges.
<G-vec00694-002-s056><divide.aufteilen><de> Industrie Wir können unsere Produktion in vielen Produktlinien aufteilen.
<G-vec00694-002-s070><divide.aufteilen><en> Many people choose to divide their Seagate external hard drives into different partitions and this could apply to your case.
<G-vec00694-002-s070><divide.aufteilen><de> Viele Menschen entscheiden sich dafür, ihre Seagate externen Festplatten in verschiedene Partitionen aufzuteilen und das könnte auch bei Ihnen der Fall sein.
<G-vec00694-002-s071><divide.aufteilen><en> Try to divide the exercise only in your head, and do the 100 repetitions one after the other.
<G-vec00694-002-s071><divide.aufteilen><de> Versuchen Sie, die Übung nur in Ihrem Kopf aufzuteilen und die 100 Wiederholungen nacheinander durchzuführen.
<G-vec00694-002-s072><divide.aufteilen><en> At the moment, the Foundation is trying to divide its SCPs equally upon the sky and the underground and to contain further anomalies.
<G-vec00694-002-s072><divide.aufteilen><de> Momentan versucht die Foundation ihre SCPs auf Himmel und Erde gleichmäßig aufzuteilen und weitere Anomalien einzudämmen.
<G-vec00694-002-s073><divide.aufteilen><en> Even a simple thread can become theatrical performance, if you do it in the air, waving a sharp knife, trying to divide soaring up fruits and vegetables.
<G-vec00694-002-s073><divide.aufteilen><de> Sogar ein einfaches Thread kann Theateraufführung werden, wenn man es in der Luft macht, ein scharfes Messer winkend, versucht, das Aufsteigen von Obst und Gemüse aufzuteilen.
<G-vec00694-002-s074><divide.aufteilen><en> It is necessary to divide food into small portions and eat 5-8 times a day.
<G-vec00694-002-s074><divide.aufteilen><de> Es ist notwendig, Essen in kleine Portionen aufzuteilen und 5-8 mal am Tag zu essen.
<G-vec00694-002-s075><divide.aufteilen><en> When Zeus decided to divide his kingdom, each god was given a field.
<G-vec00694-002-s075><divide.aufteilen><de> Als Zeus beschloss sein Reich aufzuteilen, bekam jeder Gott ein Gebiet.
<G-vec00694-002-s076><divide.aufteilen><en> Ask each group to divide the sections of the chapter among themselves.
<G-vec00694-002-s076><divide.aufteilen><de> Bitten Sie die Gruppen, die einzelnen Abschnitte des Kapitels innerhalb der Gruppe aufzuteilen.
<G-vec00694-002-s077><divide.aufteilen><en> Since eleven teams were registered for the tournament, the organizers had decided to divide the teams into two groups.
<G-vec00694-002-s077><divide.aufteilen><de> Da sich elf Teams für das Turnier angemeldet hatten, entschied der Veranstalter Berlin Sluggers, die Teams in zwei Gruppen aufzuteilen.
<G-vec00694-002-s078><divide.aufteilen><en> The idea of the procedure itself is an adjustable gastric band, which is a special belt designed to divide the stomach into two parts: an upper volume of about 25ml (the pouch), and a bottom part.
<G-vec00694-002-s078><divide.aufteilen><de> Die Idee des Verfahrens selbst ist ein Magenband, die eine besondere Band ausgebildet, um den Magen in zwei Teile aufzuteilen ist: ein oberes Volumen von etwa 25 ml (die Tasche), und einen unteren Teil.
<G-vec00694-002-s079><divide.aufteilen><en> The goal is to divide the grid into L-shaped regions.
<G-vec00694-002-s079><divide.aufteilen><de> Das Ziel ist, das Rastergitter in L-förmige Bereiche aufzuteilen.
<G-vec00694-002-s080><divide.aufteilen><en> It has the best file management in the market and has the ability to divide the audio books into two main categories; iPod library content and audible direct downloads.
<G-vec00694-002-s080><divide.aufteilen><de> Es hat die beste Dateiverwaltung auf dem Markt und hat die Fähigkeit, die Hörbücher in zwei Hauptkategorien aufzuteilen; iPod-Bibliothek-Inhalte und hörbare direkte Downloads.
<G-vec00694-002-s081><divide.aufteilen><en> The Zhou rites contained a number of legal institutions such as a patriarchal system (to maintain the rule of the hereditary nobility, including that the eldest son of the consort would inherit the throne and other sons from the consort, concubines, and mistresses would be given titles), a feudal system (to nominate and divide land among the royal family members), and ritual system (ceremonies and procedures used for the important national affairs).
<G-vec00694-002-s081><divide.aufteilen><de> Sie enthielten auch eine Anzahl von Rechtseinrichtungen, wie das patriarchische System (um die Herrschaft des Geburtsadelssystems zu bewahren, was heißt, der älteste Sohn des Gemahls würde den Thron erben und andere Söhne des Gemahls, Konkubinen und Gebieterinnen würden Titel erhalten), das Feudalsystem (um Land zu benennen und unter den königlichen Familienmitgliedern aufzuteilen) und das Ritualsystem (Zeremonien und Prozeduren, die bei den wichtigen nationalen Angelegenheiten angewendet wurden).
<G-vec00694-002-s082><divide.aufteilen><en> The camera uses a prism and a combination of bandpass filters to divide the incoming light into the 900 – 1400 nm and 1400 – 1700 nm wavelength bands and direct it to two separate indium gallium arsenide image sensors.
<G-vec00694-002-s082><divide.aufteilen><de> Die Kamera verwendet ein Prisma und eine Kombination aus Bandpass-Filtern, um das einfallende Licht in die beiden Wellenlängenbereiche, 900 – 1400 nm und 1400 – 1700 nm, aufzuteilen und auf zwei separate INGaAs-Zeilensensoren zu lenken.
<G-vec00694-002-s083><divide.aufteilen><en> It was also nice that the two of us made it possible to divide the shoot into two different locations.
<G-vec00694-002-s083><divide.aufteilen><de> Schön war auch, dass die beiden uns ermöglichten, das Shooting auf zwei verschiedene Locations aufzuteilen.
<G-vec00694-002-s084><divide.aufteilen><en> Due to the increasing number of entries per season, which often took a long time to load the site, we decided to divide each season in episodic sub-sites.
<G-vec00694-002-s084><divide.aufteilen><de> Wegen der steigenden Zahl von Einträgen pro Staffel, was oft zu langen Ladezeiten der Website geführt hat, haben wir uns entschieden, jede Saison in episodenbezogene Unterbereiche aufzuteilen.
<G-vec00694-002-s085><divide.aufteilen><en> A combination with the directly adjacent conference rooms "Vollschiff" and "Schoner" makes it possible to divide events into several locations or to run them in parallel.
<G-vec00694-002-s085><divide.aufteilen><de> Eine Kombination mit den unmittelbar angrenzenden Tagungsräumen „Vollschiff“ und „Schoner“ erlaubt es, Veranstaltungen auf mehrere Orte aufzuteilen oder parallel laufen zu lassen.
<G-vec00694-002-s086><divide.aufteilen><en> For the layout, it can be useful to divide the page in columns by mentioning the detailed plan, synthesized information and key figures, graphics, images to illustrate the remarks.
<G-vec00694-002-s086><divide.aufteilen><de> Für das Layout kann es nützlich sein, die Seite in Spalten aufzuteilen, indem der detaillierte Plan, die synthetisierten Informationen und Schlüsselfiguren, Grafiken und Bilder zur Veranschaulichung der Bemerkungen erwähnt werden.
<G-vec00694-002-s087><divide.aufteilen><en> If you're writing a longer article, it's useful to divide it into sections.
<G-vec00694-002-s087><divide.aufteilen><de> Wenn du einen längeren Artikel schreibst, ist es hilfreich, ihn in mehrere Absätze aufzuteilen.
<G-vec00694-002-s088><divide.aufteilen><en> If your business runs a large network, Role-Based Access Control can help you to divide security management responsibilities between multiple administrators.
<G-vec00694-002-s088><divide.aufteilen><de> Wenn Sie in Ihrem Unternehmen ein großes Netzwerk betreiben, unterstützt die rollenbasierte Zugriffssteuerung Sie dabei, die Sicherheitsverwaltungsaufgaben auf mehrere Administratoren aufzuteilen.
<G-vec00694-002-s152><divide.dividieren><en> This app is a free math calculator which allows you to calculate with polynomials. Yor are able to multiply, divide, add and subtract polynomials.
<G-vec00694-002-s152><divide.dividieren><de> Diese App ist ein kostenloser Mathe Rechner mit dem Sie Polynome multiplizieren, dividieren, addieren und subtrahieren können.
<G-vec00694-002-s153><divide.dividieren><en> We need to divide our input by 10 for every digit in the constant.
<G-vec00694-002-s153><divide.dividieren><de> Wir müssen die Eingabe für jede Dezimalstelle der Konstanten durch 10 dividieren.
<G-vec00694-002-s154><divide.dividieren><en> The main function of the software is therefore to count the individual pulses and divide them by the measuring time.
<G-vec00694-002-s154><divide.dividieren><de> Die Aufgabe der Software ist es daher, die einzelnen Impulse zu zählen und durch die Messzeit zu dividieren.
<G-vec00694-002-s155><divide.dividieren><en> www.The arithmetic tools perform addition (Plus), subtraction (Minus), multiplication (Times), and division (Divide) between two inputs.
<G-vec00694-002-s155><divide.dividieren><de> Die arithmetischen Werkzeuge führen die Addition (Plus), Subtraktion (Minus), Multiplikation (Multiplizieren) und Division (Dividieren) zwischen zwei Eingaben aus.
<G-vec00694-002-s156><divide.dividieren><en> Add up the total width in cm and divide by 45.
<G-vec00694-002-s156><divide.dividieren><de> Dann alle Breiten addieren und durch 45 dividieren.
<G-vec00694-002-s157><divide.dividieren><en> We strive to take this into account because the EU was originally created to unify the continent as a whole, not to divide it.
<G-vec00694-002-s157><divide.dividieren><de> Wir bemühen uns das zu berücksichtigen, denn die EU wurde ursprünglich gegründet, um den Kontinent insgesamt zu vereinen, und nicht um ihn zu dividieren.
<G-vec00694-002-s158><divide.dividieren><en> Please enter a duration and a factor to multiply (*) or divide (/).
<G-vec00694-002-s158><divide.dividieren><de> Bitte eine Dauer und einen Faktor zum multiplizieren (*) oder dividieren (/) eingeben.
<G-vec00694-002-s159><divide.dividieren><en> You can create a simple formula to add, subtract, multiply or divide values in your worksheet.
<G-vec00694-002-s159><divide.dividieren><de> Multiplizieren und Dividieren in Excel ist ein Kinderspiel, Sie müssen hierfür jedoch eine einfach Formel erstellen.
<G-vec00694-002-s160><divide.dividieren><en> When you multiply a number by 10, you increase its log by 1; when you divide a number by 10, you decrease its log by 1.
<G-vec00694-002-s160><divide.dividieren><de> Wenn Sie eine Zahl mit 10 multiplizieren, erhöhen Sie deren Logarithmus um 1; wenn Sie eine Zahl durch 10 dividieren, verringern Sie deren Logarithmus um 1.
<G-vec00694-002-s161><divide.dividieren><en> The height of the cylinder is easy to get, but to calculate the radius of the base as accurate as posible, students first have to measure the circumference and then divide by 2*pi.
<G-vec00694-002-s161><divide.dividieren><de> Die Höhe des Zylinders kann einfach bestimmt werden, aber für eine möglichst genaue Bestimmung des Radius‘ am Boden, müssen die Schüler zunächst den Umfang messen und durch 2 Pi dividieren.
<G-vec00694-002-s162><divide.dividieren><en> M and Sameer played with "Bluegrass express" in Northern and Western Germany and are also in the Group of 'GroundSpeed' not to divide.
<G-vec00694-002-s162><divide.dividieren><de> Malcher und Sieker spielten mit „Bluegrass-Express“ in Nord- und Westdeutschland und sind auch in der Gruppe „GroundSpeed“ nicht auseinander zu dividieren.
<G-vec00694-002-s163><divide.dividieren><en> • +0.0 results from attempting to divide a positive number by +infinity.
<G-vec00694-002-s163><divide.dividieren><de> Wird eine positive Zahl durch 0.0 dividiert, entsteht als Ergebnis Infinity .
<G-vec00694-002-s164><divide.dividieren><en> Each time you move one column to the right, you divide by 10.
<G-vec00694-002-s164><divide.dividieren><de> Jedesmal wenn Sie eine Spalte nach rechts gehen, wird durch 10 dividiert.
<G-vec00694-002-s165><divide.dividieren><en> Divide the number of characters given by 1500 to obtain the size of the source text.
<G-vec00694-002-s165><divide.dividieren><de> Die angegebene Zeichenzahl dividiert durch 1500 ergibt die Berechnungsseitenzahl des Ausgangstextes.
<G-vec00694-002-s166><divide.dividieren><en> In the following example, the parentheses that enclose the first part of the formula force Excel Online to calculate B4+25 first and then divide the result by the sum of the values in cells D5, E5, and F5.
<G-vec00694-002-s166><divide.dividieren><de> Im folgenden Beispiel führen die Klammern, die um den ersten Teil der Formel gesetzt sind, dazu, dass Excel Online zuerst B4+25 berechnet und das Ergebnis dann durch die Summe der Werte in den Zellen D5, E5 und F5 dividiert.
<G-vec00694-002-s167><divide.dividieren><en> Divide the values in the paste area by the values in the copy area.
<G-vec00694-002-s167><divide.dividieren><de> Dividiert die Werte im Einfügebereich durch die Werte im Kopierbereich.
<G-vec00694-002-s168><divide.dividieren><en> In photography, you need to divide by the f-stop number of the aperture to calculate that product.
<G-vec00694-002-s168><divide.dividieren><de> In der Fotografie muss durch den f-Wert der Blende dividiert werden, um dieses Produkt zu erhalten.
<G-vec00694-002-s169><divide.dividieren><en> Exponent law for quotient of powers to divide powers with the same base, subtract the exponents
<G-vec00694-002-s169><divide.dividieren><de> Potenzen mit gleicher Basis werden dividiert, indem man die Basis mit der Differenz der Exponenten potenziert.
<G-vec00694-002-s170><divide.einteilen><en> A healthy human cell can divide itself to replace cells that have been destroyed or damaged by normal wear and tear.
<G-vec00694-002-s170><divide.einteilen><de> Eine gesunde menschliche Zelle kann sich selbst einteilen zu ersetzen, die Zellen, die zerstört oder beschädigt wurden, durch normale Abnutzung und Verschleiß.
<G-vec00694-002-s171><divide.einteilen><en> The entrepreneur concerned must also divide the creditors into several classes, for example unsecured creditors and creditors with certain privileges (such as the tax authorities or pledgee and mortgage holders).
<G-vec00694-002-s171><divide.einteilen><de> Der betroffene Unternehmer muss auch die Gläubiger in mehrere Klassen einteilen, beispielsweise ungesicherte Gläubiger und Gläubiger mit bestimmten Privilegien (wie die Steuerbehörden oder Pfandgläubiger und Hypothekeninhaber).
<G-vec00694-002-s172><divide.einteilen><en> You can divide the cabinet into three tiers.
<G-vec00694-002-s172><divide.einteilen><de> Diesen Schrank kann man in drei Ebenen einteilen.
<G-vec00694-002-s173><divide.einteilen><en> Because every marketing channel has different margins or distribution channels, I would divide the market into six categories: Medical, wellness, lifestyle & computing, sports & fitness, industry & safety, and fashion.
<G-vec00694-002-s173><divide.einteilen><de> Weil jeder Vermarktungskanal unterschiedliche Margen oder Distributions-Kanäle hat, würde ich den Markt in sechs Kategorien einteilen: Medical, Wellness, Lifestyle & Computing, Sport & Fitness, Industry & Safety sowie Fashion.
<G-vec00694-002-s174><divide.einteilen><en> According to them, hard forks can divide a cryptocurrency into two rival groups.
<G-vec00694-002-s174><divide.einteilen><de> Hard Forks können eine Kryptowährung in zwei rivalisierende Gruppen einteilen.
<G-vec00694-002-s175><divide.einteilen><en> We can go one step further and divide the houses into four quadrants, which have been described by Howard Sasportas as the quadrants of self development, self expansion, self expression and self transcendence.
<G-vec00694-002-s175><divide.einteilen><de> Wir können noch einen Schritt weiter gehen und die Häuser in die vier Quadranten einteilen, die Howard Sasportas als die Quadranten der Selbstentwicklung, der Selbstexpansion, des Selbstausdrucks und der Transzendenz des Selbst genannt hat.
<G-vec00694-002-s176><divide.einteilen><en> We can divide shooters into two groups who are aiming and activating the trigger in very different ways.
<G-vec00694-002-s176><divide.einteilen><de> Man kann die Schützen in zwei Gruppen einteilen, die das Zielen und das Betätigen des Abzuges auf sehr verschiedene Weise ausführen.
<G-vec00694-002-s177><divide.einteilen><en> Both the private life and the professional career carries on and you have to divide your time after your own personal strength.
<G-vec00694-002-s177><divide.einteilen><de> Sowohl das private als auch das berufliche Karussell dreht sich bei uns weiter und man muss die eigene Zeit nach Kräften einteilen.
<G-vec00694-002-s178><divide.einteilen><en> You can divide the websites into public and intern part, which can be accessible after giving the password.
<G-vec00694-002-s178><divide.einteilen><de> Man kann die Seiten in öffentlichen und inneren Teil einteilen, welcher nach der Kennworteingabe zugänglich sein kann.
<G-vec00694-002-s179><divide.einteilen><en> As a teacher, you therefore have to divide the learners into small groups at the beginning of the game.
<G-vec00694-002-s179><divide.einteilen><de> Als Lehrender muss man daher zu Beginn des Spiels die Lernenden in kleinere Gruppen einteilen.
<G-vec00694-002-s180><divide.einteilen><en> I had to think of how many people strictly divide their time between leisure and work.
<G-vec00694-002-s180><divide.einteilen><de> Ich musste daran denken, wie viele Menschen ihr Leben streng in Freizeit und Arbeit einteilen.
<G-vec00694-002-s273><divide.sich_teilen><en> However, chemotherapy can also harm healthy cells that divide quickly, such as those that line the mouth and intestines.
<G-vec00694-002-s273><divide.sich_teilen><de> Jedoch kann die Chemotherapie auch gesunde Zellen, die sich schnell teilen, wie beispielsweise jene, die den Mund und die Därme säumen, beschädigen.
<G-vec00694-002-s274><divide.sich_teilen><en> We have made a place where people can gather, divide into groups based on interest, and move on to do something else.
<G-vec00694-002-s274><divide.sich_teilen><de> Wir haben einen Ort geschaffen, an den Menschen kommen, sich nach Interessen teilen und fahren weiter, um ihre Arbeit fortzusetzen.
<G-vec00694-002-s275><divide.sich_teilen><en> The research structures are like an organism which is in a state of constant change, can divide and grow, but is also vulnerable.
<G-vec00694-002-s275><divide.sich_teilen><de> Die Forschungsstrukturen sind wie ein Organismus, der sich ständig im Wandel befindet, sich teilen und wachsen kann, aber auch verletzlich ist.
<G-vec00694-002-s276><divide.sich_teilen><en> For example, such a rate occurs in a bacteria culture, when bacteria divide at a constant rate so that the total number of cells doubles with each division.
<G-vec00694-002-s276><divide.sich_teilen><de> Zum Beispiel tritt ein solches Wachstum in einer Bakterienkultur auf, wenn sich die Bakterien konstant teilen, so dass sich die Anzahl der Zellen bei jeder Teilung verdoppelt.
<G-vec00694-002-s277><divide.sich_teilen><en> Nuts can divide as right hand thread and left hand thread.
<G-vec00694-002-s277><divide.sich_teilen><de> Nüsse können sich als rechter Faden und linker Handfaden teilen.
<G-vec00694-002-s278><divide.sich_teilen><en> In both animals, digits form from cartilage cells which divide and mature into bone in regions called growth plates.
<G-vec00694-002-s278><divide.sich_teilen><de> In beiden Tieren bilden sich Finger aus Knorpelzellen, die sich teilen und in Abschnitten, die man Wachstumsplatten nennt, zu Knochen weiter wachsen.
<G-vec00694-002-s279><divide.sich_teilen><en> While they divide continuously and create new neurons in young animals, a large proportion of the cells in older animals persist in a state of dormancy.
<G-vec00694-002-s279><divide.sich_teilen><de> Während sie sich bei jungen Tieren fortlaufend teilen und so neue Nervenzellen entstehen, verharrt ein großer Teil bei älteren Tieren in einem Ruhezustand.
<G-vec00694-002-s280><divide.sich_teilen><en> He would soon divide, he said, and soon I would be assigned the place for which I had always secretly been longinag.
<G-vec00694-002-s280><divide.sich_teilen><de> Er würde sich teilen, und bald schon würde mir der Platz zugewiesen, nach dem ich mich schon immer insgeheim gesehnt hatte, sagte er.
<G-vec00694-002-s281><divide.sich_teilen><en> This tendency, very visible in Europe has pushed the biggest part of the anarchist movement to divide, and to take two apparently opposing roads, that in reality mirroring each other.
<G-vec00694-002-s281><divide.sich_teilen><de> Diese Tendenz, die in Europa gut sichtbar ist, hat den Großteil der anarchistischen Bewegung dazu getrieben, sich zu teilen, zwei scheinbar entgegengestellte, aber in Wirklichkeit spiegelverkehrte Wege einzuschlagen.
<G-vec00694-002-s282><divide.sich_teilen><en> Still, they all have one thing in common: their cause, the fact that abnormal cells divide uncontrollably and acquire the ability to invade other tissues.
<G-vec00694-002-s282><divide.sich_teilen><de> Dennoch haben alle eines gemeinsam: ihre Ursache, nämlich die Tatsache, dass sich veränderte Zellen unkontrolliert teilen und die Fähigkeit entwickeln, in andere Gewebe einzudringen.3 Die meisten Krebsarten werden nach dem Organ oder Zelltyp benannt, von dem sie ausgehen (z.
<G-vec00694-002-s283><divide.sich_teilen><en> When cells divide, their genetic information is passed on to both daughter cells in a highly complex process.
<G-vec00694-002-s283><divide.sich_teilen><de> Wenn Zellen sich teilen, wird das Erbgut in einem hoch komplexen Prozess an beide Tochterzellen weitergegeben.
<G-vec00694-002-s284><divide.sich_teilen><en> It protects against premature degradation of the telomeres, enabling cells to divide more often and for longer.
<G-vec00694-002-s284><divide.sich_teilen><de> Er schützt die Telomere vor vorzeitigem Abbau, so dass die Zellen sich öfter und länger teilen können.
<G-vec00694-002-s285><divide.sich_teilen><en> 27:17 what he lays up the righteous will wear, and the innocent will divide his silver.
<G-vec00694-002-s285><divide.sich_teilen><de> 27:17 so bringt er sie zwar zusammen, aber der Gerechte wird sie anziehen, und in das Geld werden sich die Unschuldigen teilen.
<G-vec00694-002-s286><divide.sich_teilen><en> The penis tissue cells will divide over and over again to fill in the gaps (tears) caused by the penile traction process.
<G-vec00694-002-s286><divide.sich_teilen><de> Die Peniszellen werden sich immer weiter teilen, um die Lücken (Risse), hervorgerufen durch den penilen Zugkraftprozess, zu schließen.
<G-vec00694-002-s287><divide.sich_teilen><en> Another interesting observation is that embryonic her5-expressing cells divide much more than their adult counterparts, hence that their cell cycle is faster that of adult progenitors.
<G-vec00694-002-s287><divide.sich_teilen><de> Eine weitere interessante Beobachtung ist, dass sich embryonale her5-exprimierende Zellen viel häufiger teilen können als ihre erwachsenen Gegenstücke, folglich ist ihr Zellzyklus schneller.
<G-vec00694-002-s288><divide.sich_teilen><en> When cells divide, they build a giant apparatus - the so called the "mitotic spindle".
<G-vec00694-002-s288><divide.sich_teilen><de> Wenn Zellen sich teilen, bauen sie einen gigantischen Apparat auf, die so genannte Zellteilungsspindel.
<G-vec00694-002-s198><divide.teilen><en> This causes the cell to lose its ability to divide.
<G-vec00694-002-s198><divide.teilen><de> Es zwingt die Zelle, die Fähigkeit zu verlieren, geteilt zu werden.
<G-vec00694-002-s199><divide.teilen><en> Without prejudice to Article 8(8) and the second subparagraph of Article 7(1), a prospectus composed of separate documents shall divide the required information into a registration document, a securities note and a summary.
<G-vec00694-002-s199><divide.teilen><de> Unbeschadet des Artikels 8 Absatz 8 und des Artikels 7 Absatz 1 Unterabsatz 2, werden in einem aus mehreren Einzeldokumenten bestehenden Prospekt die geforderten Angaben in ein Registrierungsformular, eine Wertpapierbeschreibung und eine Zusammenfassung geteilt.
<G-vec00694-002-s200><divide.teilen><en> A green belt now spans the continent where the Iron Curtain used to divide it: a unique ecosystem at the nexus of wilderness and cultivation.
<G-vec00694-002-s200><divide.teilen><de> Wo Europa einst geteilt war, quert heute ein grünes Band den Kontinent: Ein einzigartiges Ökosystem zwischen Wildnis und Kulturlandschaft.
<G-vec00694-002-s201><divide.teilen><en> The settings are in three to five parts, and the vocal parts sometimes divide.
<G-vec00694-002-s201><divide.teilen><de> Die Sätze sind drei-bis fünfstimmig, die Chorstimmen dabei teilweise auch geteilt.
<G-vec00694-002-s202><divide.teilen><en> In the unions the workers organised divide up into the groups of the trades to which they belong.
<G-vec00694-002-s202><divide.teilen><de> In den Gewerkschaften vereinigen sich die Arbeiter geteilt nach den Gewerben, denen sie angehören.
<G-vec00694-002-s203><divide.teilen><en> It soon became clear to Depardieu and to me that we needed a joint project, and we proceeded to divide the Festival month of August, which is reserved for me and my team.
<G-vec00694-002-s203><divide.teilen><de> Bald war Depardieu und mir klar, dass wir ein gemeinsames Projekt brauchten, und haben uns dann den für mich und mein Küchenteam reservierten Festspielmonat August geteilt.
<G-vec00694-002-s204><divide.teilen><en> To make the shoulder strap, cut from the leatherette fabric a rectangle of 10.5×50 cm and divide into 3 parts of 3.5 cm each.
<G-vec00694-002-s204><divide.teilen><de> Für den Schulterriemen wird aus dem Kunstlederstoff ein Rechteck von 10,5×50 cm geschnitten und in 3 Teile von je 3,5 cm geteilt.
<G-vec00694-002-s205><divide.teilen><en> You then divide for the front legs and the back and chest pieces are worked separately back and forth.
<G-vec00694-002-s205><divide.teilen><de> Dann wird die Arbeit für die Vorderbeine geteilt und das Rücken- und Bauchteil werden einzeln in Hin- und Rück-Reihen weitergestrickt.
<G-vec00694-002-s206><divide.teilen><en> The ballroom can divide into three equal sized rooms and has a large covered verandah running it's full length.
<G-vec00694-002-s206><divide.teilen><de> Der Ballsaal kann in drei Räume gleicher Größe geteilt werden und verfügt über eine große überdachte Veranda, die sich über die gesamte Länge erstreckt.
<G-vec00694-002-s207><divide.teilen><en> If the plant is too small to be treated as described above, you can use a knife to carefully divide the rhizome.
<G-vec00694-002-s207><divide.teilen><de> Sollte die Pflanze nicht so groß sein, um wie oben beschrieben behandelt zu werden, kann das Rhizom auch vorsichtig mit Hilfe eines Messers geteilt werden.
<G-vec00694-002-s208><divide.teilen><en> Use =1/n in a formula, where n is the number you want to divide 1 by.
<G-vec00694-002-s208><divide.teilen><de> Sie verwenden =1/n in einer Formel, in der n die Zahl ist, durch die 1 geteilt werden soll.
<G-vec00694-002-s209><divide.teilen><en> You can see that it is not necessary to divide members by intermediate nodes to apply concentrated loads.
<G-vec00694-002-s209><divide.teilen><de> Es zeigt, dass die Stäbe nicht durch Zwischenknoten geteilt werden müssen, um Einzellasten anzusetzen.
<G-vec00694-002-s273><divide.teilen><en> However, chemotherapy can also harm healthy cells that divide quickly, such as those that line the mouth and intestines.
<G-vec00694-002-s273><divide.teilen><de> Jedoch kann die Chemotherapie auch gesunde Zellen, die sich schnell teilen, wie beispielsweise jene, die den Mund und die Därme säumen, beschädigen.
<G-vec00694-002-s274><divide.teilen><en> We have made a place where people can gather, divide into groups based on interest, and move on to do something else.
<G-vec00694-002-s274><divide.teilen><de> Wir haben einen Ort geschaffen, an den Menschen kommen, sich nach Interessen teilen und fahren weiter, um ihre Arbeit fortzusetzen.
<G-vec00694-002-s275><divide.teilen><en> The research structures are like an organism which is in a state of constant change, can divide and grow, but is also vulnerable.
<G-vec00694-002-s275><divide.teilen><de> Die Forschungsstrukturen sind wie ein Organismus, der sich ständig im Wandel befindet, sich teilen und wachsen kann, aber auch verletzlich ist.
<G-vec00694-002-s276><divide.teilen><en> For example, such a rate occurs in a bacteria culture, when bacteria divide at a constant rate so that the total number of cells doubles with each division.
<G-vec00694-002-s276><divide.teilen><de> Zum Beispiel tritt ein solches Wachstum in einer Bakterienkultur auf, wenn sich die Bakterien konstant teilen, so dass sich die Anzahl der Zellen bei jeder Teilung verdoppelt.
<G-vec00694-002-s277><divide.teilen><en> Nuts can divide as right hand thread and left hand thread.
<G-vec00694-002-s277><divide.teilen><de> Nüsse können sich als rechter Faden und linker Handfaden teilen.
<G-vec00694-002-s278><divide.teilen><en> In both animals, digits form from cartilage cells which divide and mature into bone in regions called growth plates.
<G-vec00694-002-s278><divide.teilen><de> In beiden Tieren bilden sich Finger aus Knorpelzellen, die sich teilen und in Abschnitten, die man Wachstumsplatten nennt, zu Knochen weiter wachsen.
<G-vec00694-002-s279><divide.teilen><en> While they divide continuously and create new neurons in young animals, a large proportion of the cells in older animals persist in a state of dormancy.
<G-vec00694-002-s279><divide.teilen><de> Während sie sich bei jungen Tieren fortlaufend teilen und so neue Nervenzellen entstehen, verharrt ein großer Teil bei älteren Tieren in einem Ruhezustand.
<G-vec00694-002-s280><divide.teilen><en> He would soon divide, he said, and soon I would be assigned the place for which I had always secretly been longinag.
<G-vec00694-002-s280><divide.teilen><de> Er würde sich teilen, und bald schon würde mir der Platz zugewiesen, nach dem ich mich schon immer insgeheim gesehnt hatte, sagte er.
<G-vec00694-002-s281><divide.teilen><en> This tendency, very visible in Europe has pushed the biggest part of the anarchist movement to divide, and to take two apparently opposing roads, that in reality mirroring each other.
<G-vec00694-002-s281><divide.teilen><de> Diese Tendenz, die in Europa gut sichtbar ist, hat den Großteil der anarchistischen Bewegung dazu getrieben, sich zu teilen, zwei scheinbar entgegengestellte, aber in Wirklichkeit spiegelverkehrte Wege einzuschlagen.
<G-vec00694-002-s282><divide.teilen><en> Still, they all have one thing in common: their cause, the fact that abnormal cells divide uncontrollably and acquire the ability to invade other tissues.
<G-vec00694-002-s282><divide.teilen><de> Dennoch haben alle eines gemeinsam: ihre Ursache, nämlich die Tatsache, dass sich veränderte Zellen unkontrolliert teilen und die Fähigkeit entwickeln, in andere Gewebe einzudringen.3 Die meisten Krebsarten werden nach dem Organ oder Zelltyp benannt, von dem sie ausgehen (z.
<G-vec00694-002-s283><divide.teilen><en> When cells divide, their genetic information is passed on to both daughter cells in a highly complex process.
<G-vec00694-002-s283><divide.teilen><de> Wenn Zellen sich teilen, wird das Erbgut in einem hoch komplexen Prozess an beide Tochterzellen weitergegeben.
<G-vec00694-002-s284><divide.teilen><en> It protects against premature degradation of the telomeres, enabling cells to divide more often and for longer.
<G-vec00694-002-s284><divide.teilen><de> Er schützt die Telomere vor vorzeitigem Abbau, so dass die Zellen sich öfter und länger teilen können.
<G-vec00694-002-s285><divide.teilen><en> 27:17 what he lays up the righteous will wear, and the innocent will divide his silver.
<G-vec00694-002-s285><divide.teilen><de> 27:17 so bringt er sie zwar zusammen, aber der Gerechte wird sie anziehen, und in das Geld werden sich die Unschuldigen teilen.
<G-vec00694-002-s286><divide.teilen><en> The penis tissue cells will divide over and over again to fill in the gaps (tears) caused by the penile traction process.
<G-vec00694-002-s286><divide.teilen><de> Die Peniszellen werden sich immer weiter teilen, um die Lücken (Risse), hervorgerufen durch den penilen Zugkraftprozess, zu schließen.
<G-vec00694-002-s287><divide.teilen><en> Another interesting observation is that embryonic her5-expressing cells divide much more than their adult counterparts, hence that their cell cycle is faster that of adult progenitors.
<G-vec00694-002-s287><divide.teilen><de> Eine weitere interessante Beobachtung ist, dass sich embryonale her5-exprimierende Zellen viel häufiger teilen können als ihre erwachsenen Gegenstücke, folglich ist ihr Zellzyklus schneller.
<G-vec00694-002-s288><divide.teilen><en> When cells divide, they build a giant apparatus - the so called the "mitotic spindle".
<G-vec00694-002-s288><divide.teilen><de> Wenn Zellen sich teilen, bauen sie einen gigantischen Apparat auf, die so genannte Zellteilungsspindel.
<G-vec00694-002-s336><divide.teilen><en> Further divide each of these three portions into four equal pieces, forming a total of 12 evenly sized rolls.
<G-vec00694-002-s336><divide.teilen><de> Teile dann jede dieser Portionen in vier gleich groβe Stücke, sodass du schlieβlich 12 gleich groβe Brötchen erhälst.
<G-vec00694-002-s337><divide.teilen><en> To figure out how many US dollars you would need to save at the current exchange rate, divide 20,000 by 226.43.
<G-vec00694-002-s337><divide.teilen><de> Um festzustellen, wie viele US Dollar du bei diesem Wechselkurs ansparen musst, teile 20.000 durch 226,43.
<G-vec00694-002-s338><divide.teilen><en> Divide the sum of the numbers by the amount of numbers.
<G-vec00694-002-s338><divide.teilen><de> Teile die Zahl 58 durch die Anzahl der Zahlen, die du addiert hast.
<G-vec00694-002-s339><divide.teilen><en> Divide the product by the denominator (the bottom number) of the fraction.
<G-vec00694-002-s339><divide.teilen><de> Teile das Produkt durch den Nenner (die untere Zahl) des Bruches.
<G-vec00694-002-s340><divide.teilen><en> 12:13 Then 31 someone from the crowd said to him, “Teacher, tell 32 my brother to divide the inheritance with me.”
<G-vec00694-002-s340><divide.teilen><de> 13Einer aus der Volksmenge aber sprach zu ihm: Lehrer, sage meinem Bruder, daß er das Erbe mit mir teile.
<G-vec00694-002-s341><divide.teilen><en> 2 Divide the first number of the dividend by the divisor.
<G-vec00694-002-s341><divide.teilen><de> Teile den ersten Term des Dividenden durch den ersten Term des Divisors.
<G-vec00694-002-s342><divide.teilen><en> Step 2: Divide the number of your outs by the number of possible cards that might appear on the next street.
<G-vec00694-002-s342><divide.teilen><de> Schritt 2: Teile die Anzahl deiner Outs durch die Anzahl der möglichen Karten, die an der nächsten Street kommen können.
<G-vec00694-002-s343><divide.teilen><en> Divide the card up into three sections: morning, afternoon and night.
<G-vec00694-002-s343><divide.teilen><de> Teile den Zettel in 3 Abschnitte ein: Morgen, Nachmittag und Abend.
<G-vec00694-002-s344><divide.teilen><en> Divide your hair from ear to ear and from your forehead to the nape of your neck to create 4 sections.
<G-vec00694-002-s344><divide.teilen><de> Teile dein Haar von Ohr zu Ohr und von der Stirn bis zum Nacken, um vier Abschnitte zu bilden.
<G-vec00694-002-s345><divide.teilen><en> Enumerate the berries and divide them - strong and beautiful ones should be put on the blank, and a little trampled - on the spin.
<G-vec00694-002-s345><divide.teilen><de> Zähle die Beeren auf und teile sie - kräftige und schöne sollten auf den Rohling gelegt und ein wenig mit Füßen getreten werden - auf den Spin.
<G-vec00694-002-s346><divide.teilen><en> I press and divide.
<G-vec00694-002-s346><divide.teilen><de> Ich drücke und teile.
<G-vec00694-002-s347><divide.teilen><en> Divide your hair into smaller sections.
<G-vec00694-002-s347><divide.teilen><de> Teile dein Haar in kleinere Sektionen.
<G-vec00694-002-s348><divide.teilen><en> Divide three by five for a win percentage of 60%.
<G-vec00694-002-s348><divide.teilen><de> Teile drei durch vier für einen Gewinnprozentsatz von 60%.
<G-vec00694-002-s349><divide.teilen><en> Our part here was to host a track a this year's FSCONS called Divide and Reconquer, which focused on the problem of the trend towards centralised non-free Internet services, and possible solutions.
<G-vec00694-002-s349><divide.teilen><de> Unser Beitrag dazu war die Veranstaltung einer Vortragsreihe auf der diesjährigen FSCONS mit dem Namen Divide and Reconquer (Teile und erobere zurück), die das Problem des Trends hin zu zentralisierten unfreien Internetdiensten und mögliche Lösungen dafür in den Fokus stellte.
<G-vec00694-002-s350><divide.teilen><en> Divide your new rate by the number of days in the year, 365.
<G-vec00694-002-s350><divide.teilen><de> Teile den neuen Zinssatz durch die Anzahl der Tage im Jahr (365).
<G-vec00694-002-s351><divide.teilen><en> Divide the answer by 1.8.
<G-vec00694-002-s351><divide.teilen><de> Teile das Ergebnis durch 1,8.
<G-vec00694-002-s352><divide.teilen><en> Divide and rule strategies, they have.
<G-vec00694-002-s352><divide.teilen><de> Ihre Strategie ist: "Teile und Herrsche".
<G-vec00694-002-s353><divide.teilen><en> Then divide the dough in equal portions.
<G-vec00694-002-s353><divide.teilen><de> Teile den Teig in 3 gleich große Stücke.
<G-vec00694-002-s354><divide.teilen><en> Take your calorie requirement and divide it into these 3 categories.
<G-vec00694-002-s354><divide.teilen><de> Nimm deinen Kalorienbedarf und teile ihn in diese 3 Kategorien auf.
<G-vec00694-002-s355><divide.teilen><en> Remove the dough from the fridge and divide into four balls and roll out thinly
<G-vec00694-002-s355><divide.teilen><de> Den Teig aus dem Kühlschrank nehmen und in vier gleich große Teile teilen.
<G-vec00694-002-s356><divide.teilen><en> This is the reason why the authorities needed to divide the railway into two.
<G-vec00694-002-s356><divide.teilen><de> Aus diesem Grund mussten die Behörden die Bahn in zwei Teile teilen.
<G-vec00694-002-s357><divide.teilen><en> It is possible to divide the plot into 2 if you wish.
<G-vec00694-002-s357><divide.teilen><de> Wenn Sie möchten, können Sie die Handlung in zwei Teile teilen.
<G-vec00694-002-s358><divide.teilen><en> Indole-3-carbinol, for example, halts the cell cycle in breast cancer cells without actually killing the cells.3 The cell cycle is a rigidly controlled series of steps a cell must go through before it can divide in two, involving the duplication of the cell's contents and a final split.
<G-vec00694-002-s358><divide.teilen><de> Indol-3-Carbinol beispielsweise stoppt den Zellzyklus in Brustkrebszellen, ohne die Zellen tatsächlich abzutöten: Der Zellzyklus ist eine streng kontrollierte Abfolge von Schritten, die eine Zelle durchlaufen muss, bevor sie sich in zwei Teile teilen kann, einschließlich der Verdoppelung des Zellinhalts und einer endgültigen Teilung.
<G-vec00694-002-s359><divide.teilen><en> The relevance of menstrual dates is that most books use them to discuss the progress of your pregnancy and further divide it into three trimesters.
<G-vec00694-002-s359><divide.teilen><de> Die Bedeutung der Menstruationsdaten ist, daß die meisten Bücher sie benutzen, um den Fortschritt Ihrer Schwangerschaft zu besprechen und ihn in drei Trimester weiter zu teilen.
<G-vec00694-002-s360><divide.teilen><en> English Revised Version These are the names of the men which shall divide the land unto you for inheritance: Eleazar the priest, and Joshua the son of Nun.
<G-vec00694-002-s360><divide.teilen><de> 16Und der HERR redete mit Mose und sprach: 17Das sind die Namen der Männer, die das Land unter euch teilen sollen: der Priester Eleasar und Josua, der Sohn Nuns.
<G-vec00694-002-s361><divide.teilen><en> Such is the fact which emerges from the study of the whole history of these two peoples that we can not divide.
<G-vec00694-002-s361><divide.teilen><de> Das ist die Tatsache, die aus dem Studium der ganzen Geschichte dieser beiden Völker hervorgeht, die wir nicht teilen können.
<G-vec00694-002-s362><divide.teilen><en> If you have no idea how to better divide the space in the office, the house, at work or in the shop, we would advise you sliding glass doors.
<G-vec00694-002-s362><divide.teilen><de> Wissen Sie nicht wie Sie Ihren Platz im Büro, zu Hause, in der Firma oder im Geschäft am besten teilen können, dann raten wir Ihnen zu den Schiebetüren aus Glas.
<G-vec00694-002-s363><divide.teilen><en> All of these office typologies are shaped by vertical surfaces that create and partition spaces, that divide office floors into either closed or open areas.
<G-vec00694-002-s363><divide.teilen><de> Alle diese Bürotypologien sind geprägt von vertikalen, Raum bildenden und Raum gliedernden Flächen, die das Geschoß entweder in geschlossene oder offene Bereiche teilen.
<G-vec00694-002-s364><divide.teilen><en> In the emergency it is also easy to divide the treasures with co-travelers.
<G-vec00694-002-s364><divide.teilen><de> In der Not fällt es auch leicht, die Schätze mit Mitreisenden zu teilen.
<G-vec00694-002-s365><divide.teilen><en> In order to divide, cells in the intestinal wall have to leave their densely packed environment and migrate to the surface.
<G-vec00694-002-s365><divide.teilen><de> Damit sich Zellen der Darmwand teilen können, müssen sie ihre dichtgepackte Umgebung verlassen und an die Oberfläche wandern.
<G-vec00694-002-s366><divide.teilen><en> You can divide your hand into 3 steps and you can do with a total of 4 hands.
<G-vec00694-002-s366><divide.teilen><de> Sie können Ihre Hand in 3 Schritte und vollständig mit 4 Händen teilen.
<G-vec00694-002-s367><divide.teilen><en> For groups of more than 10 persons we divide the participants into two groups.
<G-vec00694-002-s367><divide.teilen><de> Bei Gruppengrößen über 10 Personen teilen wir die Teilnehmer in zwei Gruppen auf.
<G-vec00694-002-s368><divide.teilen><en> Breaking Points The renegades and Gatewatch divide their efforts to attack Tezzeret's operation on multiple fronts.
<G-vec00694-002-s368><divide.teilen><de> Die Renegaten und die Wächter teilen ihre Bemühungen auf, um Tezzerets Operation an mehreren Fronten anzugreifen.
<G-vec00694-002-s369><divide.teilen><en> Marxists do not divide the world into “good” and “bad” nations, we recognize the democratic right to self-determination of all nations while opposing all nationalist ideologies with the program of revolutionary internationalist class struggle.
<G-vec00694-002-s369><divide.teilen><de> Marxisten teilen die Welt nicht in „gute“ und „schlechte“ Nationen, wir erkennen das demokratische Recht auf Selbstbestimmung aller Nationen an, und stellen allen nationalistischen Ideologien das Programm von revolutionärem internationalistischen Klassenkampf entgegen.
<G-vec00694-002-s370><divide.teilen><en> A rule of thumb that Lynch used to combine growth and value is to take the long-term growth rate, add the dividend yield, and divide the total by the price-to-earnings ratio (P/E).
<G-vec00694-002-s370><divide.teilen><de> Eine Faustregel zur Kombination von Wachstum und Wert, die Lynch verwendete, ist die langfristige Wachstumsrate eines Unternehmens zu nehmen, die Dividendenrendite hinzu zu addieren und das Ergebnis durch das Kurs-Gewinn-Verhältnis (KGV) zu teilen.
<G-vec00694-002-s371><divide.teilen><en> The main fact in the creation of interior design is the lack of interior partitions, which obliges to divide space into functional zones.
<G-vec00694-002-s371><divide.teilen><de> Die wichtigste Tatsache bei der Schaffung von Innenarchitektur ist das Fehlen von Innenwänden, die den Raum in funktionale Zonen teilen müssen.
<G-vec00694-002-s372><divide.teilen><en> They divide the gently lit exhibition space diagonally.
<G-vec00694-002-s372><divide.teilen><de> Sie teilen den sanft beleuchteten Ausstellungsraum diagonal.
<G-vec00694-002-s373><divide.teilen><en> Category management We divide all expenditure into a standard set of categories.
<G-vec00694-002-s373><divide.teilen><de> Kategorienmanagement Wir teilen alle Ausgabe in Standardkategorien ein.
<G-vec00694-002-s374><divide.teilen><en> In other words, we should applaud the sacrifice of low wage, part-time workers, who divide up capitalist scarcity and poverty amongst themselves for the "greater good."
<G-vec00694-002-s374><divide.teilen><de> Mit anderen Worten sollen wir den Opfern der NiedriglohnempfängerInnen und Teilzeitarbeitenden, die die kapitalistische Kargheit und Armut unter sich um des „höheren Guts willen“ teilen, applaudieren.
<G-vec00694-002-s375><divide.teilen><en> Continue by taking out the dough. Divide into three equal parts.
<G-vec00694-002-s375><divide.teilen><de> Den Teig aus dem Kühlschrank holen und in drei gleich große Teile teilen.
<G-vec00694-002-s376><divide.teilen><en> Since the unionizing and communists movements of the 1920s to the COINTEL PRO FBI program of the 1970s to suppress the Black Liberation movement, government authorities have used tactics like wiretapping phones, intercepting mail, and infiltrating groups to “divide and conquer".
<G-vec00694-002-s376><divide.teilen><de> Von den Gewerkschaftsbewegungen und den kommunistischen Bewegungen der 1920er bis zum COINTEL PRO FBI Programm der 1970er zur Unterdrückung der schwarzen Befreiungsbewegung haben Regierungsbehörden Taktiken wie das Abhören von Telefonen, das Abfangen von Postsendungen und die Infiltration von Gruppen angewandt, um „zu teilen und zu herrschen“.
<G-vec00694-002-s377><divide.teilen><en> Symptoms of glaucoma in the eye make it possible to divide it into two forms: closed-angle and open-angle.
<G-vec00694-002-s377><divide.teilen><de> Die Symptome des Glaukoms im Auge machen es möglich, es in zwei Formen zu teilen: geschlossener Winkel und offener Winkel.
<G-vec00694-002-s378><divide.teilen><en> Each day, the cells of the human body divide billions of times; this also requires duplication of their genetic information.
<G-vec00694-002-s378><divide.teilen><de> Die Zellen des menschlichen Körpers und die darin enthaltene Erbinformation teilen sich milliardenfach, jeden Tag.
<G-vec00694-002-s379><divide.teilen><en> They extend along the coast for more than 250km and divide into numerous layers.
<G-vec00694-002-s379><divide.teilen><de> Sie erstrecken sich entlang der Küste mehr als 250km und teilen sich in vielen Schichten.
<G-vec00694-002-s380><divide.teilen><en> Amphibola bests break into shorter fibers or divide into thinner fibers along their longitudinal cleavage.
<G-vec00694-002-s380><divide.teilen><de> Amphibolasbeste brechen zu kürzeren Fasern oder teilen sich entlang Ihrer Längsspaltbarkeit zu dünneren Fasern.
<G-vec00694-002-s381><divide.teilen><en> Employers and employees divide social security contributions in half.
<G-vec00694-002-s381><divide.teilen><de> Arbeitgeber/in und Arbeitnehmer/in teilen sich die Sozialbeiträge hälftig.
<G-vec00694-002-s382><divide.teilen><en> At this point the production lines divide again: some of the salmon fillets are taken away to be packaged as finished products, while the rest are cut into portion-sized pieces and then packaged up.
<G-vec00694-002-s382><divide.teilen><de> Hier teilen sich die Produktionslinien erneut: Ein Teil der Lachsfilets wird als fertiges Produkt der Verpackung zugeführt, der andere Teil wird in Portionsstücke geschnitten und anschließend verpackt.
<G-vec00694-002-s383><divide.teilen><en> these 15 exclusive housing units divide each other in nine, or six, apartments in two building structures, through which the distance to the the next neighbor was extended and your privacy is being protected optimally.
<G-vec00694-002-s383><divide.teilen><de> Die 15 exklusiven Wohneinheiten teilen sich zu neun beziehungsweise sechs Wohnungen auf zwei Baukörper auf, wodurch die Entfernung zum nächsten Nachbarn erweitert wurde und Ihre Privatsphäre optimal geschützt wird.
<G-vec00694-002-s384><divide.teilen><en> The latter divide into three LFOs and a CV modulation sequence.
<G-vec00694-002-s384><divide.teilen><de> Letztere teilen sich in drei LFOs und eine CV-Sequenz auf.
<G-vec00694-002-s385><divide.teilen><en> Some cells divide repeatedly, while others appear to develop into more mature cell types that no longer divide.
<G-vec00694-002-s385><divide.teilen><de> Einige dieser Zellen teilen sich wiederholt, während andere sich zu ausgereiften, spezialisierten Zelltypen entwickeln, die sich nicht mehr vermehren können.
<G-vec00694-002-s386><divide.teilen><en> Typically, slot machines divide by 32, 64,128, 256 or 512.
<G-vec00694-002-s386><divide.teilen><de> Gewöhnlich teilen sich Spielautomaten durch 32, 64.128, 256 oder 512.
<G-vec00694-002-s387><divide.teilen><en> Further crushing of the blastomeres does not occur synchronously: some cells divide faster, some slower, resulting in the formation of a morula (the so-called stage of development of the human embryo, numbering about a hundred cells).
<G-vec00694-002-s387><divide.teilen><de> Eine weitere Zerkleinerung der Blastomeren findet nicht synchron statt: einige Zellen teilen sich schneller, einige langsamer, was zur Bildung einer Morula führt (das sogenannte Entwicklungsstadium des menschlichen Embryos, das etwa 100 Zellen umfasst).
<G-vec00694-002-s388><divide.teilen><en> Once inside the erythrocytes, they divide again and ultimately destroy them.
<G-vec00694-002-s388><divide.teilen><de> Im Inneren der Erythrocyten teilen sie sich erneut und zerstören diese schließlich.
<G-vec00694-002-s389><divide.teilen><en> Almost all long-distance trains travelling from Munich to the north of Germany run in combination to Nuremberg over the high-speed link and then divide up from here.
<G-vec00694-002-s389><divide.teilen><de> Fast alle von München nach Norden führenden Fernverkehrsverbindungen laufen heute gebündelt über die Schnellfahrstrecke nach Nürnberg und teilen sich erst hier auf.
<G-vec00694-002-s390><divide.teilen><en> This room is easy enough to organize and divide into zones.
<G-vec00694-002-s390><divide.teilen><de> Das Zimmer ist einfach genug, um zu organisieren und teilen sich in Zonen.
<G-vec00694-002-s391><divide.teilen><en> They are made homogeneous, or divide into several sectors, creating the effect of the gallery.
<G-vec00694-002-s391><divide.teilen><de> Sie werden homogen gemacht oder teilen sich in mehrere Sektoren auf, wodurch die Wirkung der Galerie entsteht.
<G-vec00694-002-s392><divide.teilen><en> Activated T cells divide every 4-5 hours, much faster than other cell types in the body.
<G-vec00694-002-s392><divide.teilen><de> Aktivierte T-Zellen teilen sich alle 4-5 Stunden, viel schneller als andere Zelltypen des Körpers.
<G-vec00694-002-s393><divide.teilen><en> While making the hair ready for straightening, divide the hair into layers, strands and sections.
<G-vec00694-002-s393><divide.teilen><de> Teilen Sie das Haar in Schichten, Strähnen und Abschnitte, während Sie es für das Glätten vorbereiten.
<G-vec00694-002-s394><divide.teilen><en> Divide the class into pairs.
<G-vec00694-002-s394><divide.teilen><de> Teilen Sie die Klasse in Zweiergruppen ein.
<G-vec00694-002-s395><divide.teilen><en> Divide the treatment on the hair.
<G-vec00694-002-s395><divide.teilen><de> Teilen Sie das Shampoo auf das nasse Haar.
<G-vec00694-002-s396><divide.teilen><en> Divide Kadus Satin On Anti-Frizz Serum on towel-dried hair.
<G-vec00694-002-s396><divide.teilen><de> Teilen Sie Kadus auf das handtuchtrockene Haar.
<G-vec00694-002-s397><divide.teilen><en> Pull an equal amount of extension hair and divide it by half.
<G-vec00694-002-s397><divide.teilen><de> Ziehen Sie eine gleiche Menge Verlängerungshaar und teilen Sie es durch die Hälfte.
<G-vec00694-002-s398><divide.teilen><en> Once more divide the ends into two equal bundles, then twist each bundle.
<G-vec00694-002-s398><divide.teilen><de> Teilen Sie die Litze einmal mehr in zwei gleiche Bündel auf und verdrillen diese separat.
<G-vec00694-002-s399><divide.teilen><en> STEP 2: Divide that number by your total number of followers and multiply by 100 to get your amplification rate percentage.
<G-vec00694-002-s399><divide.teilen><de> SCHRITT 2: Teilen Sie diese Zahl durch die Gesamtzahl Ihrer Follower und multiplizieren Sie das Ergebnis mit 100, um Ihre prozentuale Amplifikations-Rate zu ermitteln.
<G-vec00694-002-s400><divide.teilen><en> Divide the hair into four sections.
<G-vec00694-002-s400><divide.teilen><de> Teilen Sie das Haar in vier Abschnitte.
<G-vec00694-002-s401><divide.teilen><en> Divide the soft butter into smaller... Read more
<G-vec00694-002-s401><divide.teilen><de> Teilen Sie die Butter in kleine Stücke und geben Sie sie...
<G-vec00694-002-s402><divide.teilen><en> Divide the whole area into a number of rooms.
<G-vec00694-002-s402><divide.teilen><de> Teilen Sie den ganzen Bereich in einige Räume unter.
<G-vec00694-002-s403><divide.teilen><en> Divide your company in efficient departments.
<G-vec00694-002-s403><divide.teilen><de> Teilen Sie Ihr Unternehmen in effiziente Abteilungen.
<G-vec00694-002-s404><divide.teilen><en> Divide the spool and then it does not matter.
<G-vec00694-002-s404><divide.teilen><de> Teilen Sie die Spule und dann spielt es keine Rolle.
<G-vec00694-002-s405><divide.teilen><en> Divide one Laser beam into smaller Laser beam than hair.
<G-vec00694-002-s405><divide.teilen><de> Teilen Sie einen Laserstrahl in einen kleineren Laserstrahl als das Haar.
<G-vec00694-002-s406><divide.teilen><en> Divide the daily ration into several portions.
<G-vec00694-002-s406><divide.teilen><de> Teilen Sie die Tagesration in mehrere Portionen auf.
<G-vec00694-002-s407><divide.teilen><en> 4 Divide the vegetables over 4 plates, divide the mackerel over the vegetables.
<G-vec00694-002-s407><divide.teilen><de> 4 Verteilen Sie das Gemüse auf 4 Teller, teilen Sie die Makrelen auf das Gemüse.
<G-vec00694-002-s408><divide.teilen><en> So keep this in mind and do not increase everything, but divide this between the muscle groups.
<G-vec00694-002-s408><divide.teilen><de> Denken Sie also daran und erhöhen Sie nicht alles, sondern teilen Sie dies auf die Muskelgruppen auf.
<G-vec00694-002-s409><divide.teilen><en> Take the dish out of the oven, let it cool a little and then divide it into bars of equal size.
<G-vec00694-002-s409><divide.teilen><de> Nehmen Sie das Gericht aus dem Ofen, lassen Sie es ein wenig abkühlen und teilen Sie es in gleich große Riegel.
<G-vec00694-002-s410><divide.teilen><en> Alternatively, type MSINFO32 in Command Prompt, once in System Information, click Component, then Storage and finally Disk, to look for the number of partition Starting Offset; then divide it by 4096.
<G-vec00694-002-s410><divide.teilen><de> Geben Sie alternativ MSINFO32 in die Eingabeaufforderung ein, und klicken Sie unter Systeminformationen auf Komponente, dann Speicher und abschließend Festplatte, um die Zahl des Startoffsets der Partition zu suchen; teilen Sie diese dann durch 4096.
<G-vec00694-002-s411><divide.teilen><en> Divide the shampoo into wet hair.
<G-vec00694-002-s411><divide.teilen><de> Teilen Sie das Shampoo in das nasse Haar.
<G-vec00694-002-s412><divide.teilen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00694-002-s412><divide.teilen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00694-002-s413><divide.teilen><en> 17And he took a cup, and when he had given thanks he said, "Take this, and divide it among yourselves.
<G-vec00694-002-s413><divide.teilen><de> 17Und er nahm einen Kelch, dankte und sprach: Nehmet diesen und teilet ihn unter euch.
<G-vec00694-002-s414><divide.teilen><en> 13 "The kings of the armies, they flee, they flee!" The women at home divide the spoil,
<G-vec00694-002-s414><divide.teilen><de> 13 Die Könige der Heerscharen sind untereinander Freunde, und die Hausehre teilet den Raub aus.
<G-vec00694-002-s415><divide.teilen><en> 22:17 And having taken the chalice, he gave thanks, and said: Take, and divide it among you:
<G-vec00694-002-s415><divide.teilen><de> 22:17 Und er nahm den Kelch, dankete und sprach: Nehmet denselbigen und teilet ihn unter euch.
<G-vec00694-002-s416><divide.teilen><en> I have said, Thou and Ziba divide the land.
<G-vec00694-002-s416><divide.teilen><de> Ich habe es gesagt:Du und Ziba teilet den Acker miteinander.
<G-vec00694-002-s417><divide.teilen><en> If you divide the position “current expenses” by about 6 kitten in a year, you’ll already get 920,00 €.
<G-vec00694-002-s417><divide.teilen><de> Teilt man die Position “laufende Kosten” durch etwa 6 Katzenbabies im Jahr, kommt man bereits auf knapp 920,00 €.
<G-vec00694-002-s418><divide.teilen><en> The client then works in tandem with the Speed Server to intelligently divide your Internet traffic and deliver the combined speed of all available Internet connections.
<G-vec00694-002-s418><divide.teilen><de> Der Client arbeitet dann mit dem Speed-Server zusammen, teilt Ihren Internet Traffic intelligent auf und stellt die kombinierte Geschwindigkeit aller verfügbaren Internetverbindungen zur Verfügung.
<G-vec00694-002-s419><divide.teilen><en> If, therefore, you divide 1000 mm by the number of holes, you will know the mesh width.
<G-vec00694-002-s419><divide.teilen><de> Teilt man also 1000 mm durch die Anzahl der Maschen, ergibt sich die Maschenbreite.
<G-vec00694-002-s420><divide.teilen><en> You divide up the day how you want, and feel free to share ideas with people in the office who are not part of your own department.
<G-vec00694-002-s420><divide.teilen><de> Man teilt den Tag nach eigenen Vorstellungen ein und fühlt sich frei, auch mit Kollegen aus anderen Abteilungen Ideen auszutauschen.
<G-vec00694-002-s421><divide.teilen><en> They revolutionise the principles of baking and dough processing because they divide as well as shape (or "mould") the dough balls, all in one machine. They replace a divider and a moulder (please refer to "divider-shapers" in the machine range).
<G-vec00694-002-s421><divide.teilen><de> Dieses Gerät hat das Prinzip der Brotherstellung und der Teigverarbeitung revolutioniert, denn es teilt und formt (oder "wirkt") die Teiglinge mit nur einer Maschine.Es ersetzt einen Teiler und eine Wirkmaschine in der Maschinen-Produktpalette.
<G-vec00694-002-s422><divide.teilen><en> Divide ye like your enemies, in Houses, and lay your laws in set sequence from the center, again like the enemy Corners of the House of Troubles, and see yourself thence as timber, or mud-slats, or sheets of resin.
<G-vec00694-002-s422><divide.teilen><de> Teilt euch auf, wie eure Feinde, in Häuser, und legt eure Gesetze in einer Ordnung, vom Zentrum ausgehend, fest, wieder wie die feindlichen Ecken des Hauses der Sorgen, und seht euch selbst daher als Bauholz, oder Lehmziegel oder Schichten aus Harz.
<G-vec00694-002-s423><divide.teilen><en> Important for you: a&o will gladly divide the rooms up for you – profit from our experience.
<G-vec00694-002-s423><divide.teilen><de> Wichtig für Sie: a&o teilt gern Zimmer für Sie zu – Profitieren Sie von unserer Erfahrung.
<G-vec00694-002-s424><divide.teilen><en> Each car will divide after hit - unless it will be as small as possible.
<G-vec00694-002-s424><divide.teilen><de> Jedes Auto teilt nach Hit - es sei denn, es wird so klein wie möglich.
<G-vec00694-002-s425><divide.teilen><en> The Engagement Rate is calculated by taking the total PTAT (people talking about this) and divide by the total number of likes.
<G-vec00694-002-s425><divide.teilen><de> Engagementgrad: 0.07% Die Engagementrate wird berechnet, indem man den PTAT (people talking about this) durch die Anzahl an Likes teilt.
<G-vec00694-002-s426><divide.teilen><en> APLUS will detect crossing points and divide the line into separate dimension lines.
<G-vec00694-002-s426><divide.teilen><de> APLUS erkennt die Schnittpunkte und teilt die Linie in einzelne Bemaßungslinien.
<G-vec00694-002-s427><divide.teilen><en> The Immigration Service does not divide people into groups based on religion or ethnicity, which means that people from different sides of a conflict may end up living together.
<G-vec00694-002-s427><divide.teilen><de> Die Zuwanderungsbehörde teilt Menschen nicht auf Grund von Religion oder Ethnie in Gruppen ein, was bedeutet, dass es vorkommen kann, dass Menschen aus verschiedenen Seiten eines Konflikts zusammen leben müssen.
<G-vec00694-002-s428><divide.teilen><en> Please divide the minutes by 60, and format cells to display numbers with 2 decimals.
<G-vec00694-002-s428><divide.teilen><de> Bitt teilt dafür die Minuten durch 60 und formatiert die Zelle als Ziffer mit zwei Dezimalstellen.
<G-vec00694-002-s429><divide.teilen><en> But if you divide the tunnel into two halves and design each section completely differently, the tiled wall part can suddenly enhance the whole space to the extent that it becomes delightful.
<G-vec00694-002-s429><divide.teilen><de> Doch wenn man den Tunnel in zwei Hälften teilt und komplett anders gestaltet, erfährt der keramische Wandteil plötzlich eine Aufwertung, der wir uns sogar erfreuen können.
<G-vec00694-002-s430><divide.teilen><en> Benjamin shall ravin [as] a wolf: in the morning he shall devour the prey, and at night he shall divide the spoil.
<G-vec00694-002-s430><divide.teilen><de> 27 Benjamin ist ein reißender Wolf: / Am Morgen frisst er die Beute, / am Abend teilt er den Fang.
<G-vec00694-002-s431><divide.teilen><en> If you divide a country along linguistic lines, you have to take into account, that there are areas of mixed language that do not fit into your scheme.
<G-vec00694-002-s431><divide.teilen><de> Teilt man ein Land entlang sprachlicher Linien, so muss man berücksichtigen, daß es gemischtsprachige Gebiete gibt, die nicht in so ein Schema passen.
<G-vec00694-002-s432><divide.teilen><en> The analysis will divide the area to be lit into specific zones to determine where the luminaires and the sensors should be installed.
<G-vec00694-002-s432><divide.teilen><de> Diese Analyse teilt die Fläche in einzelne Zonen auf um zu bestimmen, wie viele Leuchten wo installiert werden sollten.
<G-vec00694-002-s433><divide.teilen><en> You simply divide it with the fork!
<G-vec00694-002-s433><divide.teilen><de> Man teilt ihn schlicht mit der Gabel.
<G-vec00694-002-s434><divide.teilen><en> Sometimes the larger kitchen will divide the kitchen into a cooking area and a preparation area, so that kitchen cooking can be performed better, and the operating people do not interfere with each other.
<G-vec00694-002-s434><divide.teilen><de> Manchmal teilt die größere Küche die Küche in einen Kochbereich und einen Vorbereitungsbereich auf, so dass das Kochen in der Küche besser durchgeführt werden kann und sich die Bedienungspersonen nicht gegenseitig behindern.
<G-vec00694-002-s435><divide.teilen><en> In the 7 questions version of the game, you just divide the questions between the players.
<G-vec00694-002-s435><divide.teilen><de> In der 7-Fragen-Variante des Spiels, teilt ihr die 21 Fragen einfach zwischen den Spielern auf.
<G-vec00694-002-s481><divide.unterteilen><en> The Protestant churches divide the law into three segments: The law before Moses, the law from Moses to the Cross and the New Testament law of love.
<G-vec00694-002-s481><divide.unterteilen><de> Die protestantischen Kirchen unterteilen das Gesetz in drei Abschnitte: das Gesetz vor Mose, das Gesetz von Mose bis zum Kreuz und das neutestamentliche Gesetz der Liebe.
<G-vec00694-002-s482><divide.unterteilen><en> Vertical and horizontal relations that meet flush divide the background.
<G-vec00694-002-s482><divide.unterteilen><de> Vertikale und horizontale Verhältnisse, die bündig aneinander stoßen, unterteilen den Hintergrund.
<G-vec00694-002-s483><divide.unterteilen><en> You can create a practice plan and divide your goal into mini steps.
<G-vec00694-002-s483><divide.unterteilen><de> Du kannst dir einen Übungsplan erstellen und dein Ziel in kleine Schritte unterteilen.
<G-vec00694-002-s484><divide.unterteilen><en> The aim is to divide the grid into rectangular and square regions such that each region contains exactly one number, and that number represents the difference of the width and height of the region.
<G-vec00694-002-s484><divide.unterteilen><de> Ziel ist es, das Rastergitter in rechteckige und quadratische Bereiche zu unterteilen, sodass jeder Bereich genau eine Zahl enthält und diese Zahl die Differenz zwischen Breite und Höhe des Bereichs darstellt.
<G-vec00694-002-s485><divide.unterteilen><en> Software will also allow you to divide your spending into different time periods and priorities.
<G-vec00694-002-s485><divide.unterteilen><de> Ein Softwareprogramm ermöglicht es dir auch deine Ausgaben in verschiedene Zeitperioden und nach unterschiedlichen Prioritäten zu unterteilen.
<G-vec00694-002-s486><divide.unterteilen><en> Wholesale Inquiry Decorate your home with waterproof lights, enhance the sense of space, subtly divide the space, let the space have a three-dimensional sense and the warmth and romance of the home
<G-vec00694-002-s486><divide.unterteilen><de> Dekorieren Sie Ihr Zuhause mit einer wasserdichten Lampe, um das Raumgefühl zu verbessern und den Raum auf subtile Weise zu unterteilen, so dass der Raum ein dreidimensionales Gefühl und die Wärme und Romantik Ihres Hauses hat.
<G-vec00694-002-s487><divide.unterteilen><en> The Slavic languages divide up into East Slavic, South Slavic and West Slavic tongues.
<G-vec00694-002-s487><divide.unterteilen><de> Die slavischen Sprachen unterteilen sich in ostslavische, südslavische und westslavische Sprachen.
<G-vec00694-002-s488><divide.unterteilen><en> Outlines help you identify the steps to follow in which order and divide the task into manageable information.
<G-vec00694-002-s488><divide.unterteilen><de> Mithilfe von Gliederungen können Sie die zu befolgenden Schritte in der Reihenfolge identifizieren und die Aufgabe in überschaubare Informationen unterteilen.
<G-vec00694-002-s489><divide.unterteilen><en> With reference to the figures 10 and 11 it is further proposed to divide the present invention in bays.
<G-vec00694-002-s489><divide.unterteilen><de> Mit Bezug auf die Figuren 10 und 11 wird weiter vorgeschlagen, die vorliegende Erfindung in Einschübe zu unterteilen.
<G-vec00694-002-s490><divide.unterteilen><en> Cleverly positioned curtains divide the rooms and make the homely feeling perfect.
<G-vec00694-002-s490><divide.unterteilen><de> Geschickt platzierte Vorhänge unterteilen den Raum und machen so das Zuhausegefühl perfekt.
<G-vec00694-002-s491><divide.unterteilen><en> In most cases, you can just mark the needed slice(s) with the Rectangular Marquee tool and then run "Delete", "Combine", "Divide", "Promote", or "Slice Options" script.
<G-vec00694-002-s491><divide.unterteilen><de> In den meisten Fällen können Sie nur die benötigten Slices mit dem Rechteck-Auswahl Werkzeug markieren und dann das Skript „Slices löschen“, „Slices kombinieren“, „Slice unterteilen“, „In Benutzer-Slices umwandeln“ oder „Slice-Optionen“ ausführen.
<G-vec00694-002-s492><divide.unterteilen><en> These new diets are similar in that, depending on the effect on blood sugar, they either divide carbohydrates into favourable (complex) or unfavourable (quickly digestible) carbohydrates.
<G-vec00694-002-s492><divide.unterteilen><de> Diese neuen Kostformen haben gemeinsam, dass sie die Kohlenhydrate je nach Wirkung auf den Blutzucker in günstige (komplexe) oder ungünstige (schnell verwertbare) Kohlenhydrate unterteilen.
<G-vec00694-002-s493><divide.unterteilen><en> In addition to dividing your Domain Name System (DNS) namespace into domains, you can also divide your DNS namespace into zones that store name information about one or more DNS domains.
<G-vec00694-002-s493><divide.unterteilen><de> In DNS (Domain Name System) können Sie Ihren DNS-Namespace nicht nur in Domänen, sondern auch in Zonen unterteilen, in denen Nameninformationen zu einer oder mehreren DNS-Domänen gespeichert werden.
<G-vec00694-002-s494><divide.unterteilen><en> It is possible to divide it into two units because it possesses two entrances or to be set up as one big apartment.
<G-vec00694-002-s494><divide.unterteilen><de> Es ist möglich es in zwei Einheiten unterteilen, weil sie zwei Eingänge besitzen, oder soll als eine große Wohnung eingerichtet werden.
<G-vec00694-002-s495><divide.unterteilen><en> The aim is to divide the grid into rectangular regions such that each region contains exactly one number.
<G-vec00694-002-s495><divide.unterteilen><de> Ziel ist es, das Rastergitter so in rechteckige Bereiche zu unterteilen, dass jeder Bereich genau eine Zahl enthält.
<G-vec00694-002-s496><divide.unterteilen><en> SQS uses its proven approach to divide the test process into test stages.
<G-vec00694-002-s496><divide.unterteilen><de> Die SQS wendet ihr bewährtes Vorgehen an, um den Testprozess in Teststufen zu unterteilen.
<G-vec00694-002-s497><divide.unterteilen><en> These divide the sleeping bag fi lling among many chambers and thus prevent any down migration.
<G-vec00694-002-s497><divide.unterteilen><de> Sie unterteilen die Schlafsackfüllung in mehrere Kammern und verhindern so ein mögliches Abwandern der Daunen.
<G-vec00694-002-s498><divide.unterteilen><en> The idea was to divide it into four separate parts, with three sub-frames and a plot about Berri.
<G-vec00694-002-s498><divide.unterteilen><de> Die Idee war, es in vier separate Teile zu unterteilen, mit drei Subframes und einer Handlung über Berri.
<G-vec00694-002-s499><divide.unterteilen><en> A number of pots can visually divide the area into zones.
<G-vec00694-002-s499><divide.unterteilen><de> Eine Reihe von Töpfen kann den Bereich visuell in Zonen unterteilen.
<G-vec00694-002-s500><divide.unterteilen><en> Divide your brochure to be able to showcase all your information!
<G-vec00694-002-s500><divide.unterteilen><de> Unterteilen Sie Ihre Broschüre, um alle Ihre Informationen präsentieren zu können.
<G-vec00694-002-s501><divide.unterteilen><en> Digital camera bag - Divide the upper and lower compartments, take the camera quickly on the left side, remove the middle compartment layer, and increase the capacity of backpack in seconds.
<G-vec00694-002-s501><divide.unterteilen><de> Digitalkameratasche - Unterteilen Sie das obere und untere Fach, nehmen Sie die Kamera schnell auf die linke Seite, entfernen Sie die mittlere Fachschicht und erhöhen Sie die Kapazität des Rucksacks in Sekunden.
<G-vec00694-002-s502><divide.unterteilen><en> Divide the ponytail into two parts.
<G-vec00694-002-s502><divide.unterteilen><de> Unterteilen Sie diesen in zwei Teile.
<G-vec00694-002-s503><divide.unterteilen><en> Divide the network into security zones separated by firewalls.
<G-vec00694-002-s503><divide.unterteilen><de> Unterteilen Sie das Netzwerk in Sicherheitszonen, die durch Firewalls voneinander getrennt sind.
<G-vec00694-002-s504><divide.unterteilen><en> Throw a first-class reception in our 204m2 conference hall or divide the room into 3 sectors for a more intimate ambiance.
<G-vec00694-002-s504><divide.unterteilen><de> Veranstalten Sie einen erstklassigen Empfang in unserem 204 m2 großen Konferenzsaal oder unterteilen Sie den Raum in 3 Abschnitte für ein intimeres Ambiente.
<G-vec00694-002-s509><divide.verteilen><en> In the event of administration of larger amounts it may be advisable to divide these into several individual doses over the day.
<G-vec00694-002-s509><divide.verteilen><de> So Im Falle der Applikation größerer Mengen kann es empfehlenswert sein, diese in mehreren Einzelgaben über den Tag zu verteilen.
<G-vec00694-002-s510><divide.verteilen><en> Adjust seasoning, divide between the lined rings and chill.
<G-vec00694-002-s510><divide.verteilen><de> Leicht nachwürzen und in die ausgekleideten Ringe verteilen und kühl stellen.
<G-vec00694-002-s511><divide.verteilen><en> Divide between 2 glasses and decorate with milk foam.
<G-vec00694-002-s511><divide.verteilen><de> Auf 2 Gläser verteilen und mit Milchschaum dekorieren.
<G-vec00694-002-s512><divide.verteilen><en> The half-life of Proviron 25 Mg is close to 12-24 hours, therefore it is necessary to divide the dosage into 2-3 times a day.
<G-vec00694-002-s512><divide.verteilen><de> Die Halbwertszeit von Proviron 25 Mg liegt bei 12-24 Stunden, daher ist es notwendig, die Dosierung auf 2-3 mal täglich zu verteilen.
<G-vec00694-002-s513><divide.verteilen><en> They decide to divide this gap among a senior employee and a freelancer.
<G-vec00694-002-s513><divide.verteilen><de> Sie beschließen, dies auf die erfahrenen Mitarbeiter und einen Freiberufler zu verteilen.
<G-vec00694-002-s514><divide.verteilen><en> 5 Divide rough sea salt over a plate and put the shells on the salt.
<G-vec00694-002-s514><divide.verteilen><de> 5 Grobes Meersalz auf einen Teller verteilen und die Muscheln auf das Salz legen.
<G-vec00694-002-s515><divide.verteilen><en> Mix until everything is combined (don’t over mix). Divide batter amongst 12 lined muffin cups, bake for 15-18 minutes until a toothpick inserted in center comes out clean.
<G-vec00694-002-s515><divide.verteilen><de> Teig auf die Papierförmchen verteilen und für 15-18 Minuten backen - mit einem Zahnstocher testen, ob noch Teig kleben bleibt und erst herausnehmen, wenn der Zahnstocher sauber herauskommt.
<G-vec00694-002-s516><divide.verteilen><en> Toss the salad leaves in a little extra virgin olive oil and divide between 4 dishes.
<G-vec00694-002-s516><divide.verteilen><de> Die Salatblätter mit etwas nativem Olivenöl beträufeln und auf vier Tellern verteilen.
<G-vec00694-002-s517><divide.verteilen><en> 7 God has promised in his sanctuary: "With exultation I will divide up Shechem, and portion out the Vale of Succoth.
<G-vec00694-002-s517><divide.verteilen><de> 8 Gott hat in seinem Heiligtum gesprochen: / "Ich will triumphieren, will Sichem verteilen und das Tal von Sukkot vermessen.
<G-vec00694-002-s518><divide.verteilen><en> If we divide them between the people, there won’t be less of knowledge and information.
<G-vec00694-002-s518><divide.verteilen><de> Verteilen wir sie an die Menschen, wird es nicht weniger Wissen und Informationen geben.
<G-vec00694-002-s519><divide.verteilen><en> In order not to burdening your body additionally you should do without fatty, heavy food and divide the meals into several small portions.
<G-vec00694-002-s519><divide.verteilen><de> Um den Körper nicht zusätzlich zu belasten, sollten Sie auf fettige, schwere Speisen verzichten und die Mahlzeiten auf mehrere, kleine Portionen verteilen.
<G-vec00694-002-s520><divide.verteilen><en> They rejoice before you according to the joy in harvest, as men rejoice when they divide the spoil.
<G-vec00694-002-s520><divide.verteilen><de> Sie freuen sich vor dir, wie man sich freut in der Ernte, wie man jauchzt beim Verteilen der Beute.
<G-vec00694-002-s521><divide.verteilen><en> Divide the dough into about 4 little balls.
<G-vec00694-002-s521><divide.verteilen><de> Den Teig auf 4 Schüsseln verteilen.
<G-vec00694-002-s522><divide.verteilen><en> 7 God hath spoken in his holiness; I will rejoice, I will divide Shechem, and mete out the valley of Succoth.
<G-vec00694-002-s522><divide.verteilen><de> 8 Gott hat geredet in seinem Heiligtum: Frohlocken will ich, will Sichem verteilen und das Tal Sukkoth ausmessen.
<G-vec00694-002-s523><divide.verteilen><en> The contract stipulates standard agreements that divide the costs and risks between the seller and the buyer.
<G-vec00694-002-s523><divide.verteilen><de> Kaufverträge beinhalten Standardvereinbarungen, die Kosten, Gefahren und Disposition zwischen Verkäufer und Käufer verteilen.
<G-vec00694-002-s524><divide.verteilen><en> It is up to you to divide it up according to the themes, according to the types of content (article, video, visual), depending on the media, or depending on the teams involved.
<G-vec00694-002-s524><divide.verteilen><de> Es steht Ihnen frei, sie nach den angesprochenen Themen, nach den Arten von Inhalten (Artikel, Video, Bild), nach den Medien oder nach den beteiligten Teams zu verteilen.
<G-vec00694-002-s525><divide.verteilen><en> Divide over the rice pudding and cook in a preheated oven for 30-45 minutes at 180 °C.
<G-vec00694-002-s525><divide.verteilen><de> Die Mangowürfel über den Milchreis verteilen und diesen bei 180 °C 30 bis 45 Minuten in einem vorgeheizten Backofen erhitzen.
<G-vec00694-002-s526><divide.verteilen><en> Divide the risotto among four plates and top with a sea bass fillet.
<G-vec00694-002-s526><divide.verteilen><de> Das Risotto auf die Teller verteilen und mit den Spargelköpfen dekorieren.
<G-vec00694-002-s527><divide.verteilen><en> One may divide the field of collectors in two parts, one on the western side, the other on the eastern.
<G-vec00694-002-s527><divide.verteilen><de> Man kann die Felder der Kollektoren zum Teil an die westliche Seite und zum Teil an die östliche Seite verteilen.
<G-vec00694-002-s528><divide.verteilen><en> Divide your songs on folders.
<G-vec00694-002-s528><divide.verteilen><de> Verteilen Sie Ihre Songs in Ordner.
<G-vec00694-002-s529><divide.verteilen><en> Divide the salad between two plates and serve with the fish and a sprinkle of capers.
<G-vec00694-002-s529><divide.verteilen><de> Verteilen Sie den Salat auf zwei Teller, geben Sie den Fisch dazu und garnieren Sie alles mit einigen Kapern.
<G-vec00694-002-s530><divide.verteilen><en> 4 Divide the vegetables over 4 plates, divide the mackerel over the vegetables.
<G-vec00694-002-s530><divide.verteilen><de> 4 Verteilen Sie das Gemüse auf 4 Teller, teilen Sie die Makrelen auf das Gemüse.
<G-vec00694-002-s531><divide.verteilen><en> Divide your daily intake of fat, carbohydrates, and protein evenly over your 3 main meals.
<G-vec00694-002-s531><divide.verteilen><de> Verteilen Sie Ihre tägliche Fettaufnahme, Kohlehydrate oder Proteine über drei Mahlzeiten am Tag.
<G-vec00694-002-s532><divide.verteilen><en> 7 Divide the onion, peppers and capers over the wraps.
<G-vec00694-002-s532><divide.verteilen><de> 7 Verteilen Sie die Zwiebel, Paprika und Kapern auf die Wraps.
<G-vec00694-002-s533><divide.verteilen><en> Divide the mango mixture among 4 glasses.
<G-vec00694-002-s533><divide.verteilen><de> Verteilen Sie den Mango-Mix auf vier Gläser.
<G-vec00694-002-s534><divide.verteilen><en> 3 Divide the orange segments, the fennel and the crab over the lettuce.
<G-vec00694-002-s534><divide.verteilen><de> 3 Verteilen Sie die Orangensegmente, den Fenchel und die Krabbe über dem Salat.
