<G-vec00291-001-s019><assign.abtreten><en> You may not transfer, lease, assign, rent or sublicense the rights granted to you under this Agreement, or make the Service available for the use of other persons through your User ID.
<G-vec00291-001-s019><assign.abtreten><de> Sie dürfen die Ihnen im Rahmen dieser Vereinbarung gewährten Rechte nicht übertragen, verleasen, abtreten, vermieten oder unterlizenzieren oder anderen Personen die Nutzung des Service über Ihre Nutzer-ID ermöglichen.
<G-vec00291-001-s020><assign.abtreten><en> (5) In case of defects in products provided by other producers/manufacturers the Seller is incapable of rectifying for licensing or factual reasons, the Seller may assert its warranty claims against the producers/manufacturers and contractors on account of the Principal or assign these rights to the Principal.
<G-vec00291-001-s020><assign.abtreten><de> (5) Bei Mängeln von Produkten anderer Produzenten/Hersteller, die der Verkäufer aus lizenzrechtlichen oder tatsächlichen Gründen nicht beseitigen kann, wird der Verkäufer nach seiner Wahl seine Gewährleistungsansprüche gegen die Produzenten/Hersteller und Lieferanten für Rechnung des Auftraggebers geltend machen oder an den Auftraggeber abtreten.
<G-vec00291-001-s021><assign.abtreten><en> Except as otherwise specifically provided herein, You may not transfer or assign any of the rights granted to You under this Agreement or any of Your obligations pursuant hereto.
<G-vec00291-001-s021><assign.abtreten><de> Sofern in der vorliegenden Vereinbarung keine anderweitigen Regelungen getroffen werden, dürfen Sie keines der Ihnen im Rahmen dieser Vereinbarung eingeräumten Rechte und keine der aus der Vereinbarung entstehenden Pflichten übertragen oder abtreten.
<G-vec00291-001-s022><assign.abtreten><en> The entitlement to the payment of the collected amounts is not affected; the customer may not assign its claims against subsequent purchasers to third parties, nor pledge them, nor agree to a prohibition of assignment with its subsequent purchasers.
<G-vec00291-001-s022><assign.abtreten><de> Der Anspruch auf Herausgabe der eingezogenen Beträge bleibt unberührt; der Kunde darf seine Forderung gegen Nacherwerber weder an Dritte abtreten, noch verpfänden, noch mit Nacherwerbern ein Abtretungsverbot vereinbaren.
<G-vec00291-001-s023><assign.abtreten><en> Without the Service Provider's prior written consent, the User may not assign or transfer the rights and obligations arising from this Contract to a third party.
<G-vec00291-001-s023><assign.abtreten><de> Ohne vorherige schriftliche Zustimmung des ANBIETERS darf der NUTZER die aus dem VERTRAG erwachsenden Rechte und Pflichten weder an Andere abtreten noch auf Andere übertragen.
<G-vec00291-001-s024><assign.abtreten><en> These terms are personal to you and, as a result, you may not, without the written consent of Ancestry, assign or transfer any of your rights and obligations under this Agreement.
<G-vec00291-001-s024><assign.abtreten><de> Diese Bedingungen gelten für Sie persönlich, und daher dürfen Sie ohne schriftliche Zustimmung von Ancestry Ihre Rechte und Pflichten aus dem vorliegenden Vertrag nicht abtreten oder übertragen.
<G-vec00291-001-s025><assign.abtreten><en> You may not assign your rights.
<G-vec00291-001-s025><assign.abtreten><de> Sie können Ihre Rechte nicht abtreten.
<G-vec00291-001-s026><assign.abtreten><en> You may not assign or transfer this Agreement or any part thereof without our prior written consent.
<G-vec00291-001-s026><assign.abtreten><de> Sie dürfen diese Übereinkunft oder irgendeinen Teil davon ohne unsere vorherige, schriftliche Einwilligung weder abtreten noch übereignen.
<G-vec00291-001-s027><assign.abtreten><en> The Company may assign or subcontract any or all of its rights and obligations under these Terms.
<G-vec00291-001-s027><assign.abtreten><de> Die Gesellschaft kann ihre gemäß diesen Geschäftsbedingungen bestehenden Rechte und Verpflichtungen ganz oder teilweise abtreten oder untervergeben.
<G-vec00291-001-s028><assign.abtreten><en> You may assign, pledge or otherwise transfer this EULA, or any rights or obligations hereunder to a third party only with our prior written approval.
<G-vec00291-001-s028><assign.abtreten><de> Sie dürfen diese EULA oder die darin enthaltenen Rechte oder Pflichten nur mit unserer vorherigen schriftlichen Zustimmung an einen Dritten abtreten, verpfänden oder in anderer Weise übertragen.
<G-vec00291-001-s029><assign.abtreten><en> 1.2 The Buyer shall not be entitled to assign claims against us.
<G-vec00291-001-s029><assign.abtreten><de> 1.2 Der Besteller kann Ansprüche gegen uns nicht abtreten.
<G-vec00291-001-s030><assign.abtreten><en> We may assign this Agreement to any affiliate or in the event of merger, reorganization, sale of all or substantially all of our assets, change of control or operation of law.
<G-vec00291-001-s030><assign.abtreten><de> Wir können diesen Vertrag an ein mit uns verbundenes Unternehmen abtreten oder im Falle einer Fusion, Sanierung, dem Verkauf aller oder im Wesentlichen aller unserer Vermögenswerte, Kontrollwechsel oder kraft Gesetzes.
<G-vec00291-001-s031><assign.abtreten><en> 11.1 The Affiliate may not assign this Agreement, by operation of law or otherwise, without obtaining the prior written consent of LSbet Affiliates.
<G-vec00291-001-s031><assign.abtreten><de> 11.1 Der Affiliate darf diese Vereinbarung nicht ohne vorherige schriftliche Zustimmung von LSbet Affiliates durch Gesetz oder anderweitig abtreten.
<G-vec00291-001-s032><assign.abtreten><en> LCI may assign these Terms, in whole or in part, at any time, with or without notice to you.
<G-vec00291-001-s032><assign.abtreten><de> LCI kann diese Bedingungen jederzeit mit oder ohne Mitteilung an Sie ganz oder teilweise abtreten.
<G-vec00291-001-s033><assign.abtreten><en> The Customer may not assign such claims, however, in order to have them collected by way of factoring, unless the Customer obliges the factor irrevocably to effect the counterperformance directly to DVS for as long as DVS still has receivables against the purchaser.
<G-vec00291-001-s033><assign.abtreten><de> Der Kunde darf diese Forderungen jedoch nicht abtreten, um sie im Wege des Factoring einziehen zu lassen, es sei denn, er verpflichtet den Factor unwiderruflich dazu, die Gegenleistung solange unmittelbar an DVS zu bewirken, als noch Forderungen von DVS gegen den Käufer bestehen.
<G-vec00291-001-s034><assign.abtreten><en> 6.7 The customer can only assign warranty rights with our prior written consent.
<G-vec00291-001-s034><assign.abtreten><de> 6.7 Der Kunde kann Gewährleistungsansprüche nur mit unserer vorherigen schriftlichen Zustimmung abtreten.
<G-vec00291-001-s035><assign.abtreten><en> TomTom may assign its rights and delegate its duties under the Terms of Use to any party at any time without notice to you.
<G-vec00291-001-s035><assign.abtreten><de> TomTom kann seine im Rahmen dieser Nutzungsbedingungen bestehenden Rechte und Pflichten jederzeit an eine andere Partei abtreten beziehungsweise delegieren, ohne Sie darüber zu benachrichtigen.
<G-vec00291-001-s036><assign.abtreten><en> AVG VPN Tech may assign this Agreement at any time in its sole discretion without any prior written consent by you.
<G-vec00291-001-s036><assign.abtreten><de> AVG VPN Tech kann diese Vereinbarung nach eigenem Ermessen jederzeit abtreten, auch ohne Ihre vorherige schriftliche Zustimmung.
<G-vec00291-001-s037><assign.abtreten><en> You may not assign or delegate any of your rights or obligations hereunder without Indeed's prior written consent and any such attempt is void.
<G-vec00291-001-s037><assign.abtreten><de> Sie dürfen keine der hierin gewährten Rechte oder Verpflichtungen abtreten oder übertragen, sofern nicht vorab eine schriftliche Zustimmung von Indeed vorliegt.
<G-vec00571-001-s025><assign.abtreten><en> You may not assign your rights.
<G-vec00571-001-s025><assign.abtreten><de> Sie können Ihre Rechte nicht abtreten.
<G-vec00571-001-s027><assign.abtreten><en> The Company may assign or subcontract any or all of its rights and obligations under these Terms.
<G-vec00571-001-s027><assign.abtreten><de> Die Gesellschaft kann ihre gemäß diesen Geschäftsbedingungen bestehenden Rechte und Verpflichtungen ganz oder teilweise abtreten oder untervergeben.
<G-vec00291-001-s048><assign.abtreten><en> Assignment We reserve the right to transfer, assign, sub-license or pledge, in whole or in part, any of the rights and obligations granted to or imposed upon us by these Rules, Terms and Conditions.
<G-vec00291-001-s048><assign.abtreten><de> Abtretung von RechtenWir behalten uns das Recht vor, Rechte und Pflichten, die uns durch diese Geschäftsbedingungen gewährt oder auferlegt wurden, vollständig oder teilweise zu übertragen, abzutreten, unterzulizenzieren oder zu verpfänden.
<G-vec00291-001-s049><assign.abtreten><en> The supplier is not entitled to claims which he has against us, assign or have them collected by third parties.
<G-vec00291-001-s049><assign.abtreten><de> Der Lieferant ist nicht berechtigt, Forderungen, die ihm gegen uns zustehen, abzutreten oder durch Dritte einziehen zu lassen.
<G-vec00291-001-s050><assign.abtreten><en> The buyer is not entitled to assign the receivables that have been assigned to us because of this extended retention of title elsewhere, including for security purposes.
<G-vec00291-001-s050><assign.abtreten><de> Der Käufer ist nicht berechtigt, die uns aufgrund dieses verlängerten Eigentumsvorbehalts abgetretenen For derungen anderweitig, auch nicht zu Sicherungszwecken, abzutreten.
<G-vec00291-001-s051><assign.abtreten><en> 13.1 The client is not entitled to assign their rights under the contract.
<G-vec00291-001-s051><assign.abtreten><de> 13.1 Der Kunde ist nicht berechtigt, seine Ansprüche aus dem Vertrag abzutreten.
<G-vec00291-001-s052><assign.abtreten><en> 10.1 The Supplier shall have the right to transfer or assign the Transaction and/or any right, including the claims or obligations under the Transaction or documents concluded or issued in relation to the Transaction, to any third party provided that it obtains a prior written consent of the Purchaser.
<G-vec00291-001-s052><assign.abtreten><de> 10.1 Der Lieferant hat das Recht das Rechtsgeschäft und/oder jedes andere Recht einschließlich Forderungen und Pflichten laut dem Rechtsgeschäft oder Urkunden, geschlossen oder ausgegeben in Verbindung mit ihm an einen Dritten zu übertragen oder abzutreten nur unter Bedingung, dass er im Voraus eine schriftliche Zustimmung des Auftraggebers bekommt.
<G-vec00291-001-s053><assign.abtreten><en> The Contracting Partner is not authorized to assign or transfer his rights and obligations from the contract without the consent of ACROSS.
<G-vec00291-001-s053><assign.abtreten><de> Der Vertragspartner ist nicht berechtigt, seine Rechte und Pflichten aus dem Vertrag ohne Einwilligung von ACROSS abzutreten oder zu übertragen.
<G-vec00291-001-s054><assign.abtreten><en> 8.6 Alibaba.com shall have the right to assign this Agreement (including all of its rights, titles, benefits, interests, and obligations and duties in this Agreement) to any person or entity (including any affiliates of Alibaba.com).
<G-vec00291-001-s054><assign.abtreten><de> 8.6 Alibaba.com hat das Recht, diesen Vertrag (einschließlich aller seiner Rechte, Titel, Vorteile, Beteiligungen und Verpflichtungen und Aufgaben aus diesem Vertrag) an eine Person oder Gesellschaft (einschließlich eine Konzerngesellschaft von Alibaba.com) abzutreten.
<G-vec00291-001-s055><assign.abtreten><en> § 5 Involvement of Subcontractors (1) In case the defective delivered item is a product that Duellberg Konzentra purchased in whole or in part from a third party, Duellberg Konzentra is entitled to assign its rights concerning material defects vis-à-vis the subcontractor to the purchaser and inform the purchaser of its option to assert claims against the subcontractor in and out of court.
<G-vec00291-001-s055><assign.abtreten><de> § 5 Einschaltung von Vorlieferanten (1) Soweit es sich bei dem mangelhaften Liefergegenstand um ein Erzeugnis handelt, das Düllberg Konzentra ganz oder zum Teil von einem Dritten bezogen hat, ist Düllberg Konzentra berechtigt, ihre Sachmängelrechte gegen den Vorlieferanten an den Käufer abzutreten und den Käufer auf die (gerichtliche) Inanspruchnahme des Vorlieferanten zu verweisen.
<G-vec00291-001-s056><assign.abtreten><en> 11.1 Without prior written consent from Traffective, the Publisher is not entitled to transfer and assign rights and obligations from this contractual relationship with Traffective to third parties.
<G-vec00291-001-s056><assign.abtreten><de> 11.1 Der Publisher ist ohne vorherige schriftliche Zustimmung von Traffective nicht berechtigt, Rechte oder Pflichten aus dem Vertragsverhältnis mit Traffective auf Dritte zu übertragen und abzutreten.
<G-vec00291-001-s057><assign.abtreten><en> The Provider shall be entitled to assign rights and duties arising from the contractual relations to third parties.
<G-vec00291-001-s057><assign.abtreten><de> Der Diensterbringer ist berechtigt, die Rechte und Verpflichtungen aus der Vertragsbeziehung an einen Dritten abzutreten.
<G-vec00291-001-s058><assign.abtreten><en> 3.6 The supplier is not entitled to fully or partially assign its claims against us or otherwise dispose of them without our express prior agreement in writing.
<G-vec00291-001-s058><assign.abtreten><de> 3.6 Ohne unsere vorherige schriftliche Zustimmung ist der Lieferant nicht berechtigt, seine Forderungen gegen uns ganz oder teilweise abzutreten oder in sonstiger Weise darüber zu verfügen.
<G-vec00291-001-s059><assign.abtreten><en> The Supplier is entitled to assign claims against the customer to third parties.
<G-vec00291-001-s059><assign.abtreten><de> Der Lieferant ist berechtigt, Forderungen gegen den Kunden an Dritte abzutreten.
<G-vec00291-001-s060><assign.abtreten><en> The supplier is not entitled to assign to any third parties any claims arising from the contractual relationship without our prior written consent.
<G-vec00291-001-s060><assign.abtreten><de> Der Lieferant ist nicht berechtigt, ohne unsere vorherige schriftliche Einwilligung Forderungen aus dem Vertragsverhältnis an Dritte abzutreten.
<G-vec00291-001-s061><assign.abtreten><en> The Customer shall neither be entitled to set off claims from STENFLEX® against counterclaims or to assert the right of retention, unless the counterclaims or the right of retention have been recognised in writing by STENFLEX® or have become res judicata nor to assign claims from this contract to third parties without the written consent of STENFLEX® .
<G-vec00291-001-s061><assign.abtreten><de> Der Kunde ist weder berechtigt, Forderungen von STENFLEX® um Gegenforderungen zu kürzen oder ein Zurückbehaltungsrecht geltend zu machen, es sei denn, dass die Gegenforderungen oder das Zurückhaltungsrecht von STENFLEX® schriftlich anerkannt oder rechtskräftig festgestellt sind, noch Forderungen aus diesem Vertrag ohne die schriftliche Zustimmung von STENFLEX® an Dritte abzutreten.
<G-vec00291-001-s062><assign.abtreten><en> The Bettor shall not be permitted to assign, pledge or otherwise dispose by legal transaction of any claims vis-à-vis the BOOKMAKER under a betting contract, or to set off such claims off against claims the BOOKMAKER may have against the Bettor.
<G-vec00291-001-s062><assign.abtreten><de> Dem Wettkunden ist es nicht gestattet, allfällige Forderungen gegen den BUCHMACHER aus Wettverträgen entgeltlich oder unentgeltlich abzutreten, zu verpfänden oder darüber in sonstiger Weise rechtsgeschäftlich zu verfügen oder mit derartigen Forderungen gegen Forderungen des BUCHMACHERS aufzurechnen.
<G-vec00291-001-s063><assign.abtreten><en> We reserve the right to transfer, assign, and sublicense or pledge the Terms, in whole or in part, to any person, provided that any such assignment will be on the same terms or terms that are no less advantageous to you.
<G-vec00291-001-s063><assign.abtreten><de> Wir behalten uns das Recht vor, die Nutzungsbedingungen ganz oder teilweise an jede Person zu übertragen, abzutreten, als Unterlizenz zu vergeben oder zu verpfänden, vorausgesetzt solch eine Abtretung erfolgt zu denselben Bedingungen, die für Sie nicht weniger vorteilhaft sind.
<G-vec00291-001-s064><assign.abtreten><en> The supplier is not authorised to assign claims from the contractual relationship to third parties without Schneider's written consent or to have said claims collected by third parties.
<G-vec00291-001-s064><assign.abtreten><de> Der Lieferant ist nicht berechtigt, ohne vorherige schriftliche Einwilligung von Schneider, Forderungen aus dem Vertragsverhältnis an Dritte abzutreten oder durch Dritte einziehen zu lassen.
<G-vec00291-001-s065><assign.abtreten><en> We are entitled to assign claims arising from our business relationships.
<G-vec00291-001-s065><assign.abtreten><de> Wir sind berechtigt, die Ansprüche aus unseren Geschäftsverbindungen abzutreten.
<G-vec00291-001-s066><assign.abtreten><en> We reserve the right to assign, transfer or delegate any of Our rights and obligations hereunder to any third party without notice to You.
<G-vec00291-001-s066><assign.abtreten><de> Wir behalten es uns vor, unsere Rechte und Pflichten ohne vorherige Mitteilung an dich an Dritte abzutreten, zu übertragen oder zu delegieren.
<G-vec00291-001-s109><assign.bestimmen><en> While the Tuscany regional committee, in the today's sitting, has approved of two deliberations proposed from the regional city council member to Infrastructures, Luca Ceccobao, in order to assign beyond two million euro for running expenses and investments of the four commercial ports of regional interest: Viareggio, Santo Stefano Port, Navy of Field and Isola del Giglio.
<G-vec00291-001-s109><assign.bestimmen><de> Zwischenzeitlich hat der toskanische Regionalausschuss, in der heutigen Sitzung von dem regional Referenten zu den Infrastrukturen, Luca Ceccobao vorschlagen zwei Delibere gebilligt jenseits zu bestimmen zwei million von dem Euro für der Staatshaushalte und Investitionen von vier den Häfen handels von dem Interesse regional: Viareggio, Hafen Santo Stefano, Marine von dem Feld Isola Del Giglio und.
<G-vec00291-001-s110><assign.bestimmen><en> Gallanti has found that the support of the BEAUTIFUL ones will have a positive effect on the budget of the harbour agency, that it will be able so to free important resources to assign to the realization of the plan of the Europe Platform, the whose ban of contest is published to January and for which disposed investor to participate have time until the 30 june in order to introduce the interest manifestations.
<G-vec00291-001-s110><assign.bestimmen><de> Gallanti hat erhoben, dass der Support von SCHÖNEN einen positiven Effekt auf der Bilanz von der hafen Körperschaft haben wird, dass es können wird, um zu der Durchführung von dem Projekt von der Plattform Europa zu bestimmen folglich wichtige Ressourcen befreien, Ausschreibung von dem Wettkampf welch zu, für veröffentlichen wird dem Januar und welch, die absichtlichen Anleger zu teilnehmen haben die Zeit bis 30 Juni, um die Demonstrationen von dem Interesse vorzuweisen.
<G-vec00291-001-s111><assign.bestimmen><en> That means, that you can assign which countries are available and if the dispatch and the payment are allowed to this place.
<G-vec00291-001-s111><assign.bestimmen><de> Das heißt, dass Sie bestimmen welche Länder verfügbar sind und ob dahin der Versand und die Zahlung gestattet sind.
<G-vec00291-001-s112><assign.bestimmen><en> Louis has specified that the cession price represents the value of the ship recorded in the accounting books of the group and therefore the transaction does not determine capital gains or losses.Systems Argon takes care of the acquisition of ships to assign to the demolition.
<G-vec00291-001-s112><assign.bestimmen><de> Louis hat präzisiert, dass der Preis von der Abtretung und folglich die Transaktion den Wert von dem in den Geschäftsbüchern von der Gruppe registriert Schiff nicht bestimmt Wertzuwächse oder Minusvalenze repräsentiert.passt sich Argon Systems den Erwerb von den Schiffen auf, um zu dem Abbruch zu bestimmen.
<G-vec00291-001-s113><assign.bestimmen><en> The crocieristico group American Carnival Corporation & plc has chosen the Japanese yards for the construction of others two ships from cruise of 125.000 tons of tonnage that will assign to own brand AIDA Cruises.
<G-vec00291-001-s113><assign.bestimmen><de> Die crocieristico amerikanische Gruppe Carnival hat Corporation & plc die japanischen Werften für den Bau von anderen gewählt zwei Schiffe von der Kreuzfahrt von 125.000 Tonnen von der Bruttotonnage, der zu eigener Marke AIDA Cruises bestimmen wird.
<G-vec00291-001-s114><assign.bestimmen><en> the Harbour Committee has expressed also to seem favorable to the proposal of the president of the harbour agency, Lorenzo Forcieri, to assign a part of the greater entrances of running part, estimated in approximately eight million euro, to the reduction of the harbour taxes, in particular to the reduction of the anchor duty.
<G-vec00291-001-s114><assign.bestimmen><de> hat das Hafen Komitee auch ausgedrückt einen Teil von meisten Entrate von dem fließenden Teil zu bestimmen, schätzen in ungefähr acht million von dem Euro, zu der Verringerung von den hafen Gebühren, insbesondere zu der Verringerung von der Gebühr von dem Ankerplatz, günstig zu dem Vorschlag von dem Präsidenten von der hafen Körperschaft, Lorenzo Forcieri zu scheinen.
<G-vec00291-001-s115><assign.bestimmen><en> "The ""Language"" menu allows you assign a language to the current text layer."
<G-vec00291-001-s115><assign.bestimmen><de> Mit dem Menü „Sprache“ (Language) können Sie die Sprache der aktiven Textebene bestimmen.
<G-vec00291-001-s116><assign.bestimmen><en> The objective is that to widen the availability of approaches to assign to the business activities and, consequently, the possibility of I use more wide large squares.
<G-vec00291-001-s116><assign.bestimmen><de> Das Ziel ist, infolgedessen, jen das ins bett bringt und, die Möglichkeit von der Nutzung mehr weite Plätze, um zu den Geschäftstätigkeiten zu bestimmen die Verfügbarkeit von zu erweitern.
<G-vec00291-001-s117><assign.bestimmen><en> "Our action, therefore, will continue to being meaningful on the front of public-private partenariato, fundamental instrument in order to exceed the current deficiency of public resources to assign to the infrastructure realization""."
<G-vec00291-001-s117><assign.bestimmen><de> "Unsere Handlung wird, folglich zu bedeutend auf der Stirn von der öffentlich-privaten Partnerschaft zu sein fortsetzen, das grundlegende Instrument den gegenwärtigen Mangel von den allgemeinen Ressourcen übertreffen"", um zu der Durchführung von den Infrastrukturen zu bestimmen."
<G-vec00291-001-s118><assign.bestimmen><en> You choose a greeting cards draft, assign a value and compose your own greetings card message.
<G-vec00291-001-s118><assign.bestimmen><de> Sie wählen eine Gutscheinvorlage aus, bestimmen den Wert und verfassen Ihren persönlichen Grußtext.
<G-vec00291-001-s119><assign.bestimmen><en> It is also possible to assign a drawing style to an object during its creation or later.
<G-vec00291-001-s119><assign.bestimmen><de> Es ist auch möglich, einen Zeichnungsstil für ein Objekt während seiner Erstellung oder später zu bestimmen.
<G-vec00291-001-s120><assign.bestimmen><en> To complete the services offered from the harbour port of call of Crotone, in the plan it is previewed, inside of the tensostruttura, the realization of two bodies to assign to the hygienic services.
<G-vec00291-001-s120><assign.bestimmen><de> Die von der hafen Zwischenlandung von Crotone anbieten Dienste zu ergänzen wird es innen im Projekt, von vorhergesehen, dem Tensostruttura, der Durchführung von zwei Körpern zu den Toiletten bestimmen.
<G-vec00291-001-s228><assign.zuweisen><en> In the Task dialog, compose your task and then click Assign Task on the Manage Task group under Task tab.
<G-vec00291-001-s228><assign.zuweisen><de> In dem Aufgabe Dialog, verfassen Sie Ihre Aufgabe und klicken Sie dann auf Aufgabe zuweisen auf die Aufgabe verwalten Gruppe unter Aufgabe Tab.
<G-vec00291-001-s229><assign.zuweisen><en> Expand Assign and click Assign .
<G-vec00291-001-s229><assign.zuweisen><de> Erweitern Sie Zuweisen und klicken Sie auf Zuweisen .
<G-vec00291-001-s230><assign.zuweisen><en> "After the import, assign the suitable DTD to the respective project (see ""Selecting the DTD"") ."
<G-vec00291-001-s230><assign.zuweisen><de> Nach dem Import müssen Sie dem gewünschten Projekt die passende DTD zuweisen (siehe DTD festlegen) .
<G-vec00291-001-s231><assign.zuweisen><en> With a double-click in the column Assigned usersyou can assign employees to the access.
<G-vec00291-001-s231><assign.zuweisen><de> Mit einem Doppklick in der Spalte Zugeordnete Mitarbeiter können Sie dem Zugang Mitarbeiter zuweisen.
<G-vec00291-001-s232><assign.zuweisen><en> Also, assign product names and define custom product and site groups to streamline tasks such as: product registration and license management, Service Request creation and management, and site administration.
<G-vec00291-001-s232><assign.zuweisen><de> Außerdem können Sie Produktnamen zuweisen und benutzerdefinierte Produkt- und Standortgruppen festlegen, um Aufgaben wie die Produktregistrierung und das Lizenzmanagement, die Erstellung und Verwaltung von Service-Requests und die Standortverwaltung zu optimieren.
<G-vec00291-001-s233><assign.zuweisen><en> You can now assign up to 15 locations to a student or staff member, and up to 15 instructors to a class, when using SFTP to create users and classes.
<G-vec00291-001-s233><assign.zuweisen><de> Wenn Sie Benutzer und Klassen über SFTP anlegen, können Sie einem Schüler/Studenten oder Mitarbeiter nun bis zu 15 Standorte und einer Klasse bis zu 15 Lehrkräfte zuweisen.
<G-vec00291-001-s234><assign.zuweisen><en> Decide what computer you'd like to assign your printer to.
<G-vec00291-001-s234><assign.zuweisen><de> Entscheiden Sie, welchem Computer Sie Ihren Drucker zuweisen möchten.
<G-vec00291-001-s235><assign.zuweisen><en> For information about how to assign a RaptorXML+XBRL Server license to the machine and for more information about licensing, see the Altova LicenseServer documentation .
<G-vec00291-001-s235><assign.zuweisen><de> Informationen darüber, wie Sie einem Rechner eine RaptorXML+XBRL Server Lizenz zuweisen und nähere Informationen zur Lizenzierung finden Sie in der Dokumentation zu Altova LicenseServer .
<G-vec00291-001-s236><assign.zuweisen><en> Alternatively, assign the button to a feature you'd like to keep close to hand – create a MOB key for emergencies, a dedicated key to record sonar logs for Insight Genesis, or a key to lock the touchscreen while you're using the keypad or an external controller.
<G-vec00291-001-s236><assign.zuweisen><de> Alternativ können Sie die Taste einer Funktion zuweisen, auf die Sie gerne schnell zugreifen können möchten – erstellen Sie eine MOB-Taste für Notfälle, eine dedizierte Taste zum aufzeichnen von Sonarlogs für Insight Genesis, oder eine Taste, um den Touchscreen zu sperren, während Sie das Tastenfeld oder eine externe Steuerung verwenden.
<G-vec00291-001-s237><assign.zuweisen><en> The processing priority to assign to this HRA server.
<G-vec00291-001-s237><assign.zuweisen><de> Die Verarbeitungspriorität, die Sie diesem Integritätsregistrierungsstellen-Server zuweisen möchten.
<G-vec00291-001-s238><assign.zuweisen><en> Ensure that the Assign Hostname to Loopback IP option is selected.
<G-vec00291-001-s238><assign.zuweisen><de> Stellen Sie sicher, dass die Option Hostname zur Loopback-ID zuweisen ausgewählt ist.
<G-vec00291-001-s239><assign.zuweisen><en> To assign a protecting scope to a JAX-RS method or class, add the @OAuthSecurity annotation to the method or class declaration, and set the scope element of the annotation to your preferred scope.
<G-vec00291-001-s239><assign.zuweisen><de> Wenn Sie einer JAX-RS-Methode oder -Klasse einen schützenden Bereich zuweisen möchten, fügen Sie die Annotation @OAuthSecurity zur Methoden- oder Klassendeklaration hinzu und setzen Sie das Element scope der Annotation auf Ihren bevorzugten Bereich.
<G-vec00291-001-s240><assign.zuweisen><en> (Optional) The processing priority to assign to this trusted server group.
<G-vec00291-001-s240><assign.zuweisen><de> Die Verarbeitungspriorität, die Sie dieser vertrauenswürdigen Servergruppe zuweisen möchten.
<G-vec00291-001-s241><assign.zuweisen><en> For information about how to assign a RaptorXML Server license to the machine and for more information about licensing, see the Altova LicenseServer documentation .
<G-vec00291-001-s241><assign.zuweisen><de> Informationen darüber, wie Sie einem Rechner eine RaptorXML Server Lizenz zuweisen und nähere Informationen zur Lizenzierung finden Sie in der Dokumentation zu Altova LicenseServer .
<G-vec00571-001-s234><assign.zuweisen><en> Decide what computer you'd like to assign your printer to.
<G-vec00571-001-s234><assign.zuweisen><de> Entscheiden Sie, welchem Computer Sie Ihren Drucker zuweisen möchten.
<G-vec00291-001-s248><assign.vergeben><en> "Furthermore, we have decided for the positions 2 and 3 to assign a little "" consolation prize "" ."
<G-vec00291-001-s248><assign.vergeben><de> "Ferner haben wir uns dazu entschlossen auch für die Plätze 2 und 3 einen kleinen ""Trostpreis"" zu vergeben."
<G-vec00291-001-s249><assign.vergeben><en> In the screen, you assign the serial numbers according to the quantity of the part to be posted.
<G-vec00291-001-s249><assign.vergeben><de> In dem Screen vergeben Sie die Seriennummern entsprechend der zu buchenden Menge des Teils.
<G-vec00291-001-s250><assign.vergeben><en> In this category you can customize the view of the client, control the behavior in certain events, assign hotkeys and shortcuts, add locations and use advanced service functions.
<G-vec00291-001-s250><assign.vergeben><de> In dieser Kategorie können Sie die Ansicht des Clients anpassen, das Verhalten bei bestimmten Ereignissen steuern, Hotkeys und Tastenkürzel (Shortcuts) vergeben und erweiterte Servicefunktionen nutzen.
<G-vec00291-001-s251><assign.vergeben><en> Sponsors with the middle class program 2007 (openPR) - andrea Ludwig pr, thorn city with Ulm and Lechner & colleagues garbage home/bathing assign together with the country wide promotion initiative for small and medium-size enterprises two promotion prices in the value of altogether euro 10.000.
<G-vec00291-001-s251><assign.vergeben><de> Sponsoren beim Mittelstandsprogramm 2007 (openPR) - andrea ludwig pr, Dornstadt bei Ulm und Lechner & Kollegen Müllheim/Baden vergeben gemeinsam bei der bundesweiten Förderinitiative für kleine und mittelständische Unternehmen zwei Förderpreise im Wert von insgesamt Euro 10.000.
<G-vec00291-001-s252><assign.vergeben><en> DQS is entitled to assign specific auditing and certification tasks to other DQS Companies holding the required accreditations or authorizations.
<G-vec00291-001-s252><assign.vergeben><de> DQS ist berechtigt, spezifische Auditierungs- und Zertifizierungsaufgaben an andere DQS-Geschäftsstellen zu vergeben, die die geforderten Akkreditierungen und Zulassungen halten.
<G-vec00291-001-s253><assign.vergeben><en> With the Accress Rights you can assign, manage and create individual user groups, user roles and permissions.
<G-vec00291-001-s253><assign.vergeben><de> Mit den Zugriffsrechten können Sie individuelle Nutzergruppen, Nutzerrollen und Berechtigungen vergeben, verwalten und auch neu erstellen.
<G-vec00291-001-s254><assign.vergeben><en> Only the procedure owner (displayed in RDB$OWNER_NAME) and the SYSDBA may assign rights to a procedure.
<G-vec00291-001-s254><assign.vergeben><de> Nur der Besitzer einer Prozedur (in RDB$OWNER_NAME gespeichert) und der SYSDBA dürfen die Rechte an einer Prozedur vergeben.
<G-vec00291-001-s255><assign.vergeben><en> His idea is to assign individual telephone numbers that aren't linked to SIM cards and instead stored in the cloud.
<G-vec00291-001-s255><assign.vergeben><de> Seine Idee ist, individuelle Telefonnummern zu vergeben, die nicht an SIM-Karten gebunden sind, sondern in der Cloud stecken.
<G-vec00291-001-s256><assign.vergeben><en> The Internet market place is scanable apart from the usual criteria also after references (tags), which can assign the entrepreneurs themselves.
<G-vec00291-001-s256><assign.vergeben><de> Der Internet-Marktplatz ist neben den gängigen Kriterien auch nach Stichworten (Tags) durchsuchbar, welche die Unternehmer selbst vergeben können.
<G-vec00291-001-s257><assign.vergeben><en> Note: If serialized parts are posted without serial numbers to storage areas, you can subsequently assign the serial numbers.
<G-vec00291-001-s257><assign.vergeben><de> Hinweis: Wenn seriennummernführende Teile den Lagerorten ohne Seriennummern zugebucht werden, dann können Sie die Seriennummern nachträglich vergeben.
<G-vec00291-001-s258><assign.vergeben><en> We confirm our forecast and continue to assign it the buy rating with a stock price target of €13.20 per share.
<G-vec00291-001-s258><assign.vergeben><de> Wir bestätigen unsere Prognose und vergeben weiterhin das Rating Kaufen mit einem Kursziel in Höhe von 13,20 € je Aktie.
<G-vec00291-001-s259><assign.vergeben><en> A maximum document number can be used to determine and assign these document numbers.
<G-vec00291-001-s259><assign.vergeben><de> Solche Belegnummern können mit Hilfe einer maximalen Belegnummer ermittelt und vergeben werden.
<G-vec00291-001-s260><assign.vergeben><en> Excitement in the capital: Shogun Tokugawa Ieyasu wants to assign the Han of Takamatsu in a challenge.
<G-vec00291-001-s260><assign.vergeben><de> "Aufregung in der Hauptstadt: Shogun Tokugawa Ieyasu will das Lehen (""Han"") Takamatsu in einem Wettstreit vergeben."
<G-vec00291-001-s261><assign.vergeben><en> Administrators can assign other users access privileges for the programs of this module.
<G-vec00291-001-s261><assign.vergeben><de> Administratoren können Zugriffsberechtigungen für die Programme dieses Moduls an andere Benutzer vergeben.
<G-vec00291-001-s262><assign.vergeben><en> That was when I got the idea: The award is neither to be assigned by an organization nor an institution, nor by professional jurors, the guests themselves are to assign it.
<G-vec00291-001-s262><assign.vergeben><de> Da kam mir die Idee: Nicht irgendeine Organisation oder Einrichtung, keine Fachjuroren, sondern die Gäste selbst sollten es sein, die diesen Award vergeben.
<G-vec00291-001-s263><assign.vergeben><en> The administrator can also adapt the Windows GUI configuration including data-field descriptions, manage document and email templates, assign access data for the hunter® JOBCENTER and maintain the keys used in hunter, e.g. for industries and positions.
<G-vec00291-001-s263><assign.vergeben><de> Zudem kann der Administrator die Konfiguration der Windows-Oberfläche bis hin zu Datenfeldbezeichnungen anpassen, Dokument- und E-Mail-Vorlagen verwalten, Zugangsdaten für das hunter®JOBCENTER vergeben und die in hunter verwendeten Schlüssel, beispielsweise für Branchen und Positionen, pflegen.
<G-vec00291-001-s264><assign.vergeben><en> If you are not sure what IP address you can assign, you should contact your network administrator.
<G-vec00291-001-s264><assign.vergeben><de> Sind Sie sich nicht sicher welche IP-Adresse Sie vergeben können, wenden Sie sich bitte an Ihren Netzwerkadministrator.
<G-vec00291-001-s265><assign.vergeben><en> Users shall not sub-license, assign, or transfer the any mentioned above to any entity without prior written consent from Vertis.
<G-vec00291-001-s265><assign.vergeben><de> Die Nutzer sollen das oben Aufgeführte nicht an eine weitere Person unterlizenzieren, vergeben oder transferieren, ohne davor eine schriftliche Erlaubnis von Vertis eingeholt zu haben.
<G-vec00291-001-s266><assign.vergeben><en> Exhibitors can also set up subaccounts and assign individual rights for employees and service providers.
<G-vec00291-001-s266><assign.vergeben><de> Für Mitarbeiter oder Dienstleister kann man Subaccounts anlegen und individuelle Rechte vergeben.
<G-vec00571-001-s253><assign.vergeben><en> With the Accress Rights you can assign, manage and create individual user groups, user roles and permissions.
<G-vec00571-001-s253><assign.vergeben><de> Mit den Zugriffsrechten können Sie individuelle Nutzergruppen, Nutzerrollen und Berechtigungen vergeben, verwalten und auch neu erstellen.
<G-vec00571-001-s255><assign.vergeben><en> His idea is to assign individual telephone numbers that aren't linked to SIM cards and instead stored in the cloud.
<G-vec00571-001-s255><assign.vergeben><de> Seine Idee ist, individuelle Telefonnummern zu vergeben, die nicht an SIM-Karten gebunden sind, sondern in der Cloud stecken.
<G-vec00571-001-s261><assign.vergeben><en> Administrators can assign other users access privileges for the programs of this module.
<G-vec00571-001-s261><assign.vergeben><de> Administratoren können Zugriffsberechtigungen für die Programme dieses Moduls an andere Benutzer vergeben.
<G-vec00291-001-s267><assign.vergeben><en> Shall not assign or sub-contract work under the contract without the prior approval of Munters;
<G-vec00291-001-s267><assign.vergeben><de> Er vergibt oder untervergibt keine vertraglich vereinbarten Leistungen ohne vorherige Zustimmung von Munters.
<G-vec00291-001-s268><assign.vergeben><en> Since the user doesn't need to assign addresses any more, there must be a possibility to check the assignment between the object at the host software and the BIDIB device: This is done by IDENTIFY: By pressing the IDENTIFY button at the BiDiB device, the corresponding object at the host software should flash.
<G-vec00291-001-s268><assign.vergeben><de> Da ja der Anwender keine Adressen mehr vergibt, muss es eine Möglichkeit geben, damit man die Zuordnung vom Objekt im Hostprogramm zur Baugruppe überprüfen kann: Das erfolgt mittels IDENTIFY: drückt man an der Baugruppe auf IDENTIFY, so soll das entsprechende Objekt in Hostprogramm blinken.
<G-vec00291-001-s269><assign.vergeben><en> As the operating system will then assign all resources (like the interrupts) the list is no longer shown.
<G-vec00291-001-s269><assign.vergeben><de> Da in diesem Fall das Betriebssystem alle Ressourcen vergibt (auch den Interrupt) wird die Liste nicht mehr angezeigt.
<G-vec00291-001-s270><assign.vergeben><en> In the first dialog you assign a name for the link if you want to.
<G-vec00291-001-s270><assign.vergeben><de> Im ersten Dialog vergibt man einen Namen für den Link, wenn man das möchte.
<G-vec00291-001-s271><assign.vergeben><en> The prerequisite for proALPHA to assign the usage category to a part is that the part is managed in a storage area.
<G-vec00291-001-s271><assign.vergeben><de> Voraussetzung, dass proALPHA einem Teil die Verwendungsart vergibt ist, dass das Teil auf einem Lager geführt wird.
<G-vec00291-001-s272><assign.vergeben><en> In the options, you can filter for the parts to which proALPHA is to assign the usage category.
<G-vec00291-001-s272><assign.vergeben><de> Im Vorlauf können Sie die Teile eingrenzen, denen proALPHA die Verwendungsart vergibt.
<G-vec00291-001-s341><assign.zuordnen><en> The tiny fish were only 1-2 cm long and we were neither able to assign them to an existing genus nor to an existing species.
<G-vec00291-001-s341><assign.zuordnen><de> Die winzigen Fische waren nur 1-2 cm lang und konnten von uns keiner existierenden Gattung oder Art zugeordnet werden.
<G-vec00291-001-s342><assign.zuordnen><en> In the second step you assign the classification system to the records.
<G-vec00291-001-s342><assign.zuordnen><de> Im zweiten Schritt wird die Merkmalsleiste den Datensätzen zugeordnet.
<G-vec00291-001-s343><assign.zuordnen><en> Here you have to assign the inputs to the channels.
<G-vec00291-001-s343><assign.zuordnen><de> Hier müssen die Eingänge den Kanälen zugeordnet werden.
<G-vec00291-001-s344><assign.zuordnen><en> "Using the menu function""File""or the first Toolbar Symbol you can assign INSEL Models (Assign Funktion)."
<G-vec00291-001-s344><assign.zuordnen><de> "Über die Menüleistenfunktion ""File""oder das ersteToolbar Symbol können fertige INSEL Modelle als Datei zugeordnet werden (Assign Funktion)."
<G-vec00291-001-s345><assign.zuordnen><en> You must then assign these connections another potential from the tree or create a new one.
<G-vec00291-001-s345><assign.zuordnen><de> Zu diesen Verbindungen muss dann ein anderes Potenzial aus dem Baum zugeordnet oder ein neues angelegt werden.
<G-vec00291-001-s346><assign.zuordnen><en> The assignment references are used to automatically assign sales lines to open items.
<G-vec00291-001-s346><assign.zuordnen><de> Anhand der Zuordnungsreferenzen werden Umsatzzeilen zu offenen Posten automatisch zugeordnet.
<G-vec00291-001-s347><assign.zuordnen><en> If you are thus logged in, Google may directly assign this information to your account.
<G-vec00291-001-s347><assign.zuordnen><de> Wenn Sie derart angemeldet sind, werden diese Daten möglicherweise von Google direkt Ihrem Konto zugeordnet.
<G-vec00291-001-s348><assign.zuordnen><en> It gives you everything you need to create unlimited amazing folder icons and assign them to any folder, in the easiest way possible.
<G-vec00291-001-s348><assign.zuordnen><de> Es bietet euch alles, was ihr zum Erstellen unbegrenzt vieler erstaunlicher Ordnersymbole, die auf einfachste Weise jedem Ordner zugeordnet werden könne, benötigt.
<G-vec00291-001-s349><assign.zuordnen><en> "A ""color_map {...}"" is a table of colors, which were assign to numbers between 0.00 an 1.00."
<G-vec00291-001-s349><assign.zuordnen><de> "Unter eine ""color_map {...}"" versteht man eine Tabelle von Farbenwerten, welche Zahlen von 0.00 bis 1.00 zugeordnet werden."
<G-vec00291-001-s350><assign.zuordnen><en> An A resource record is used to assign an IPv4 address to a DNS name.
<G-vec00291-001-s350><assign.zuordnen><de> Mit einem A Resource Record wird einem DNS-Namen eine IPv4-Adresse zugeordnet.
<G-vec00291-001-s351><assign.zuordnen><en> If we are unable to assign a payment to an application because some information is missing or it is not legible, the payment cannot be registered and therefore the application will neither be processed nor forwarded to the universities.
<G-vec00291-001-s351><assign.zuordnen><de> Solange Zahlungen nicht zugeordnet werden können, weil Angaben fehlen oder nicht lesbar sind, gelten diese Bewerbungen als nicht bezahlt und sie können dann weder bearbeitet noch an die Hochschulen weitergeleitet werden.
<G-vec00291-001-s352><assign.zuordnen><en> However, it is not possible to assign several wire harnesses to one sheet.
<G-vec00291-001-s352><assign.zuordnen><de> Jedoch können einem Blatt nicht mehrere Leitungsstränge zugeordnet werden.
<G-vec00291-001-s353><assign.zuordnen><en> It's hard to assign these from classical music inspired compositions to a special genre of rock music. Up to now Univers Zero is not only seen as a Rock in Opposition band but also with their own style: New Chamber Rock.
<G-vec00291-001-s353><assign.zuordnen><de> Die von klassischer Musik inspirierten Kompositionen sind schwerlich einem Zweig der Rockmusik zuzueignen, bis heute wird Univers Zero nicht nur der Rock In Opposition - Szene zugeordnet, sondern mit einem eigenen Stil versehen: New Chamber Rock.
<G-vec00291-001-s354><assign.zuordnen><en> "If you want to publish applications from the repository with DeltaMaster 6, you will need to assign the roles ""Define Report Distribution"" and/or ""Execute Report Distribution"" to these applications."
<G-vec00291-001-s354><assign.zuordnen><de> "Einzig die Benutzerberechtigungen sind zu beachten: Wer mit DeltaMaster 6 Anwendungen aus dem Repository publizieren möchte, muss für diese Anwendungen den Rollen ""Berichtsverteilung definieren"" und/oder ""Berichtsverteilung ausführen"" zugeordnet sein."
<G-vec00291-001-s355><assign.zuordnen><en> Assign a class to each pixel of an image.
<G-vec00291-001-s355><assign.zuordnen><de> Jedem Pixel eines Bildes wird eine Klasse zugeordnet.
<G-vec00291-001-s356><assign.zuordnen><en> Now the final strategy implementation phase will further strengthen the regions and assign roles and responsibilities in the markets more transparently.
<G-vec00291-001-s356><assign.zuordnen><de> In der finalen Phase der Strategieumsetzung werden jetzt die Regionen weiter gestärkt sowie die Rollen und Verantwortlichkeiten in den Märkten klarer zugeordnet.
<G-vec00291-001-s357><assign.zuordnen><en> A common problem is that your BIOS did not assign an interrupt to your card.
<G-vec00291-001-s357><assign.zuordnen><de> Ein oft vorkommendes Problem tritt ein, wenn Dein BIOS Deiner Karte keinen Interrupt zugeordnet hat.
<G-vec00291-001-s358><assign.zuordnen><en> You can assign header rows to the field information contained in the CSV files.
<G-vec00291-001-s358><assign.zuordnen><de> Die in den CSV-Dateien enthaltenen Feld-Informationen können Kopfzeilen zugeordnet bekommen.
<G-vec00291-001-s359><assign.zuordnen><en> An actuator is able to assign a function and various parameters to each transmitter.
<G-vec00291-001-s359><assign.zuordnen><de> Jedem Sender können am Aktor eine Funktion und verschiedenste Parameter zugeordnet werden.
<G-vec00571-001-s341><assign.zuordnen><en> The tiny fish were only 1-2 cm long and we were neither able to assign them to an existing genus nor to an existing species.
<G-vec00571-001-s341><assign.zuordnen><de> Die winzigen Fische waren nur 1-2 cm lang und konnten von uns keiner existierenden Gattung oder Art zugeordnet werden.
<G-vec00571-001-s342><assign.zuordnen><en> In the second step you assign the classification system to the records.
<G-vec00571-001-s342><assign.zuordnen><de> Im zweiten Schritt wird die Merkmalsleiste den Datensätzen zugeordnet.
<G-vec00571-001-s343><assign.zuordnen><en> Here you have to assign the inputs to the channels.
<G-vec00571-001-s343><assign.zuordnen><de> Hier müssen die Eingänge den Kanälen zugeordnet werden.
<G-vec00571-001-s355><assign.zuordnen><en> Assign a class to each pixel of an image.
<G-vec00571-001-s355><assign.zuordnen><de> Jedem Pixel eines Bildes wird eine Klasse zugeordnet.
<G-vec00291-001-s360><assign.zuteilen><en> There at the price of 200 Credits you can get trained hero, that you can assign to your castles.
<G-vec00291-001-s360><assign.zuteilen><de> Für den Preis von 200 Goldmünzen kann ein Held ausgebildet werden, der einer Burg zugeteilt wird, um sie zu regieren.
<G-vec00291-001-s361><assign.zuteilen><en> As the aircraft progresses through its flight, the Mode A code can be changed and it is normal for different ground service providers to assign different codes to the same flight.
<G-vec00291-001-s361><assign.zuteilen><de> Da das Flugzeug auf seinem Kurs verschiedene Zuständigkeitsbereiche durchfliegt ist es normal, dass ein und demselben Flug durch verschiedene regionale Controllzentren auch verschiedene Codes zugeteilt werden.
<G-vec00291-001-s362><assign.zuteilen><en> The method is to use an OLS regression not on the original data series, but on a series where each observation is assign a rank, say from 1 to N (for N observations).
<G-vec00291-001-s362><assign.zuteilen><de> Die Methode besteht darin, die OLS-Regression nicht auf die Originaldatenreihen anzuwenden, sondern auf eine Reihe, bei der jede Feststellung einem Rang zugeteilt wird, sagen wir 1 bis N (für N Feststellungen).
<G-vec00291-001-s363><assign.zuteilen><en> It is thus not necessary to assign them a password.
<G-vec00291-001-s363><assign.zuteilen><de> Es muss somit kein Passwort zugeteilt werden.
<G-vec00291-001-s364><assign.zuteilen><en> You can easily assign individually defined resources to new instances (virtual machines on your Reseller Cloud). They will be available within seconds.
<G-vec00291-001-s364><assign.zuteilen><de> Neuen Instanzen (virtuelle Maschinen auf Ihrer Reseller Cloud) können individuelle, frei definierbare Ressourcen zugeteilt werden und sind innerhalb von Sekunden einsatzbereit.
<G-vec00291-001-s365><assign.zuteilen><en> A smartphone and a few taps in an app is all that is needed to verify the user's identity and driver's license, assign the right rental car, and open it per smartphone.
<G-vec00291-001-s365><assign.zuteilen><de> Mit Hilfe des Smartphones und nur wenigen Klicks in einer App werden Identität und Fahrererlaubnis des Nutzers geprüft, der passende Mietwagen zugeteilt und dieser per Smartphone geöffnet.
<G-vec00291-001-s366><assign.zuweisen><en> Depending on the service of the user, the provider may assign a different address each time the user connects to the Internet.
<G-vec00291-001-s366><assign.zuweisen><de> Je nach Dienst des Nutzers kann diesem durch den Provider jedes Mal eine andere Adresse zugewiesen werden, wenn der Nutzer eine Verbindung mit dem Internet herstellt.
<G-vec00291-001-s367><assign.zuweisen><en> group ID ID of a group to assign clients to.
<G-vec00291-001-s367><assign.zuweisen><de> group ID ID einer Gruppe, zu der die Clients zugewiesen werden sollen.
<G-vec00291-001-s368><assign.zuweisen><en> The organisation, responsible for the sector of emergency camps, will assign the places of operation to THW.
<G-vec00291-001-s368><assign.zuweisen><de> Die Einsatzorte werden dem THW von der für den Bereich der Notlager verantwortlichen Organisation zugewiesen.
<G-vec00291-001-s369><assign.zuweisen><en> Describes how to use operators to assign values to variables.
<G-vec00291-001-s369><assign.zuweisen><de> Beschreibt, wie Variablen mithilfe von Operatoren Werte zugewiesen werden.
<G-vec00291-001-s370><assign.zuweisen><en> Veeam's Scale-out Backup Repository provides an abstraction layer over individual storage devices to create a single virtual pool of backup storage to which to assign backups.
<G-vec00291-001-s370><assign.zuweisen><de> Mit Scale-Out Backup Repository von Veeam erhalten Sie eine Abstraktionsebene über den einzelnen Storage-Geräten und damit einen einzigen virtuellen Backup-Storage-Pool, dem Backups zugewiesen werden können.
<G-vec00291-001-s371><assign.zuweisen><en> Dismissing the holy sacrament of marriage, she drew attention to the limited roles that patriarchal cultures assign to women.
<G-vec00291-001-s371><assign.zuweisen><de> Sie verwarf das heilige Sakrament der Ehe und wies auf die beschränkte Rolle hin, die Frauen in einer patriarchalen Kultur zugewiesen wird.
<G-vec00291-001-s372><assign.zuweisen><en> In the Publishing module, you can assign to a player a custom SWF to interact with web analytics services.
<G-vec00291-001-s372><assign.zuweisen><de> Im Veröffentlichungsmodul kann einem Player ein benutzerdefiniertes SWF zugewiesen werden, das mit Webanalysediensten interagiert.
<G-vec00291-001-s373><assign.zuweisen><en> Then a graphic horizontal line is added at the place you assign in the Step 1.
<G-vec00291-001-s373><assign.zuweisen><de> Dann wird eine grafische horizontale Linie an der Stelle hinzugefügt, die Sie im Schritt 1 zugewiesen haben.
<G-vec00291-001-s374><assign.zuweisen><en> Number of CPUs: Select the required number of CPUs to assign to the target VM.
<G-vec00291-001-s374><assign.zuweisen><de> Anzahl der CPUs: Wählen Sie die erforderliche Anzahl der CPUs aus, die der Ziel-VM zugewiesen werden soll.
<G-vec00291-001-s375><assign.zuweisen><en> The command uses the Name parameter of New-Module to assign a friendly name to the module.
<G-vec00291-001-s375><assign.zuweisen><de> Mit dem Name-Parameter von New-Module wird dem Modul im Befehl ein Anzeigename zugewiesen.
<G-vec00291-001-s376><assign.zuweisen><en> Expressions can be used to determine the value to assign to a variable, to compute the parameter of a function or procedure, or to test for a condition.
<G-vec00291-001-s376><assign.zuweisen><de> Ausdrücke können verwendet werden, um einen Wert zu ermitteln, der einer Variable zugewiesen werden soll, einen Parameter einer Funktion oder Prozedur zu berechnen oder um eine Bedingung zu prüfen.
<G-vec00291-001-s377><assign.zuweisen><en> SUBST [drive1: [drive2:]path] SUBST drive1: /D drive1: Specifies a virtual drive to which you want to assign a path.
<G-vec00291-001-s377><assign.zuweisen><de> SUBST [Laufwerk1: [Laufwerk2:]Pfad] SUBST Laufwerk1: /D Laufwerk1: Laufwerkbezeichnung, die dem Pfad zugewiesen werden soll.
<G-vec00291-001-s378><assign.zuweisen><en> You can then assign them to members, surfaces, and solids that share a surface (see Chapter 4.28).
<G-vec00291-001-s378><assign.zuweisen><de> Diese können dann Stäben, Flächen und Volumenkörpern zugewiesen werden, die eine Fläche gemeinsam verwenden (siehe Kapitel 4.28).
<G-vec00291-001-s379><assign.zuweisen><en> Depending on the responsibility, it may be necessary to release the MRP suggestion in order to assign it to the specialist responsible.
<G-vec00291-001-s379><assign.zuweisen><de> Je nach Zuständigkeit kann es erforderlich sein, den Dispositionsvorschlag freizugeben, wodurch dieser dem zuständigen Sachbearbeiter zugewiesen wird.
<G-vec00291-001-s380><assign.zuweisen><en> The command uses a dollar sign ($) to indicate a variable and the assignment operator (=) to assign the result of the Get-Service command to the newly created variable.
<G-vec00291-001-s380><assign.zuweisen><de> "Im Befehl wird mit dem Dollarzeichen ($) eine Variable angegeben, und mit dem Zuweisungsoperator (=) wird das Ergebnis des Befehls ""Get-Service"" der neu erstellten Variablen zugewiesen."
<G-vec00291-001-s381><assign.zuweisen><en> This is a unique, permanent and personalized symbol sequence which we assign to you when you first log in to your user account.
<G-vec00291-001-s381><assign.zuweisen><de> Es handelt sich hierbei um eine einzigartige, dauerhafte und nicht personalisierte Zeichenfolge, die Ihnen von uns zugewiesen wird, wenn Sie sich erstmals in Ihrem User-Account einloggen.
<G-vec00291-001-s382><assign.zuweisen><en> In the Select the desired vDisks list, highlight the vDisk(s) to assign, then click OK, then OK again to close the Target Device Properties dialog.
<G-vec00291-001-s382><assign.zuweisen><de> "Markieren Sie in der Liste Select the desired vDisks die vDisks, die zugewiesen werden sollen, klicken Sie auf OK und klicken Sie anschließend erneut auf OK, um das Dialogfeld ""Target Device Properties"" zu schließen."
<G-vec00291-001-s383><assign.zuweisen><en> The integrated software allows users to connect one or several shares within a network and to assign them to their own media pool – consisting of a hard disk and optical media.
<G-vec00291-001-s383><assign.zuweisen><de> Durch die integrierte Software werden somit ein oder mehrere Shares im Netz miteinander verbunden und einem eigenen Medienpool – bestehend aus Harddisk und optischen Medien – zugewiesen.
<G-vec00291-001-s384><assign.zuweisen><en> Note: Not all player templates permit you to assign playlists to them.
<G-vec00291-001-s384><assign.zuweisen><de> Hinweis: Nicht allen Playervorlagen können Wiedergabelisten zugewiesen werden.
<G-vec00291-001-s385><assign.zuordnen><en> If you are logged in to Twitter, Twitter can assign the visit to our websites to your Twitter account.
<G-vec00291-001-s385><assign.zuordnen><de> Sind Sie bei Twitter eingeloggt, kann Twitter den Besuch unserer Websites Ihrem dortigen Konto zuordnen.
<G-vec00291-001-s386><assign.zuordnen><en> You can assign the countries via Drag & Drop: In the All Countries list, select the countries you want to assign, and use the mouse to drag them to the Assigned Countries list.
<G-vec00291-001-s386><assign.zuordnen><de> Die Länder können Sie per Drag & Drop zuordnen: Wählen Sie aus der Liste Alle Länder die Länder aus, die Sie zuordnen möchten, und ziehen Sie diese mit derMaus in die Liste Zugeordnete Länder .
<G-vec00291-001-s388><assign.zuordnen><en> You can assign your campaigns to one location, multiple locations, or the entire organization.
<G-vec00291-001-s388><assign.zuordnen><de> Sie können Ihre Aktionen einer oder mehreren Filialen oder der gesamten Organisation zuordnen.
<G-vec00291-001-s389><assign.zuordnen><en> Double-click the image file you want to assign to the part.
<G-vec00291-001-s389><assign.zuordnen><de> Doppelklicken Sie auf die Bilddatei, die Sie dem Teil zuordnen wollen.
<G-vec00291-001-s390><assign.zuordnen><en> A window now opens in which you can assign the address fields of the ordering assistant precisely to the fields on the website.
<G-vec00291-001-s390><assign.zuordnen><de> Nun öffnet sich ein Fenster, in dem Sie die Adressfelder des Bestellhelfers genau den Feldern dieser Webseite zuordnen können.
<G-vec00291-001-s391><assign.zuordnen><en> Only if this date is in the validity period can you assign a fixed asset class or assign another depreciation method in the book.
<G-vec00291-001-s391><assign.zuordnen><de> Nur wenn das Inbetriebnahmedatum im Gültigkeitszeitraum liegt, können Sie eine Anlagenart zuordnen oder im Bewertungsbereich eine andere Abschreibungsart zuordnen.
<G-vec00291-001-s393><assign.zuordnen><en> With Role option you can automatically assign roles to users or create conditional field and depending on user’s selection assign appropriate role.
<G-vec00291-001-s393><assign.zuordnen><de> Mit Rollen Option können Rollen automatisch auf Benutzer zuordnen oder bedingte Feld und je nach Auswahl des Benutzers zuweisen angemessene Rolle.
<G-vec00291-001-s394><assign.zuordnen><en> regarding the significance we assign to our experiences.
<G-vec00291-001-s394><assign.zuordnen><de> hinsichtlich der Bedeutung, die wir Erlebnissen zuordnen.
<G-vec00291-001-s395><assign.zuordnen><en> You can enter or assign the customer number of the desired customer.
<G-vec00291-001-s395><assign.zuordnen><de> Die Kundennummer des gewünschten Kunden können Sie eingeben oder zuordnen.
<G-vec00291-001-s396><assign.zuordnen><en> If you are logged into Google, Google can assign your visit to your Google account.
<G-vec00291-001-s396><assign.zuordnen><de> Sind Sie bei Google eingeloggt, kann Google den Besuch Ihrem Google-Konto zuordnen.
<G-vec00291-001-s397><assign.zuordnen><en> Select the Tools | Assign Purchase Order menu item.
<G-vec00291-001-s397><assign.zuordnen><de> Wählen Sie den Menüpunkt Extras | Bestellung zuordnen .
<G-vec00291-001-s398><assign.zuordnen><en> You can assign an organization to a customer group, to which you can apply specific pricing anddiscount Commerce: A deduction applied to an online purchase, typically implemented as part of a marketing campaign.
<G-vec00291-001-s398><assign.zuordnen><de> Sie können eine Organisation einer Kundengruppe zuordnen, für die Sie spezielle Preise und Rabatte Commerce: Ein bei Online-Kauf gewährter Preisnachlass, typischerweise als Teil einer Marketing-Kampagne.
<G-vec00291-001-s399><assign.zuordnen><en> You can also assign a house bank manually for each suggested payment.
<G-vec00291-001-s399><assign.zuordnen><de> Auch können Sie eine Bankverbindung manuell zuordnen je Zahlungsvorschlag.
<G-vec00291-001-s400><assign.zuordnen><en> If you do not wish that Facebook can assign your visit to our site to your Facebook user account, please log out from your Facebook account.
<G-vec00291-001-s400><assign.zuordnen><de> Wenn Sie nicht wünschen, dass Facebook den Besuch unserer Seiten Ihrem Facebook-Nutzerkonto zuordnen kann, loggen Sie sich bitte aus Ihrem Facebook-Benutzerkonto aus.
<G-vec00291-001-s401><assign.zuordnen><en> If do not assign user groups or users to a discount, the discount is valid for all users.
<G-vec00291-001-s401><assign.zuordnen><de> Wenn Sie einem Rabatt keine Benutzergruppen oder Benutzer zuordnen, ist der Rabatt für alle Benutzer gültig.
<G-vec00291-001-s402><assign.zuordnen><en> In the window you can assign a task and forward it to one or several specialists.
<G-vec00291-001-s402><assign.zuordnen><de> In dem Fenster können Sie einen Vorgang zuordnen und an einen oder mehrere Sachbearbeiter weiterleiten.
<G-vec00291-001-s403><assign.zuordnen><en> This opens the Assign to Execution Task dialog.
<G-vec00291-001-s403><assign.zuordnen><de> Der Dialog Zu Änderungsmaßnahme zuordnen wird geöffnet.
<G-vec00291-001-s423><assign.zuteilen><en> If no oasis has been assigned to the Embassy, a quest will remind you to assign an oasis after a short while.
<G-vec00291-001-s423><assign.zuteilen><de> Hat man der Botschaft noch keine Oase zugeteilt, erscheint nach einiger Zeit eine Quest zum Zuteilen einer Oase zur Botschaft.
<G-vec00291-001-s424><assign.zuteilen><en> Whenever you get a Joker or one or more Deuces in your final hand, the computer will automatically assign a suit and value to it.
<G-vec00291-001-s424><assign.zuteilen><de> Wann auch immer Sie einen Spaßvogel oder eine oder mehr Zweien in Ihrer Endhand bekommen, wird der Computer eine Klage automatisch zuteilen und dazu schätzen.
<G-vec00291-001-s425><assign.zuteilen><en> Herbert Weidlich, active in the office detail, could now assign all of the musicians of the jazz orchestra Rhythm to the specially created work detail for 'Transport Protection'.
<G-vec00291-001-s425><assign.zuteilen><de> Der im Kommando Schreibstube tätige Herbert Weidlich konnte nun alle Musiker des Jazzorchesters „Rhythmus“ dem eigens geschaffenen Arbeitskommando „Transportschutz“ zuteilen: Es bot genügend Zeit zum Proben, die man auch heimlich während der eigentlich Arbeitszeit abhielt.
<G-vec00291-001-s426><assign.zuteilen><en> If you travel with other passengers we will assign the seats in accordance with availability and the conditions of the fare paid.
<G-vec00291-001-s426><assign.zuteilen><de> Wenn Sie mit anderen Passagieren reisen, werden wir die Sitzplätze je nach Verfügbarkeit und den Bedingungen des bezahlten Tarifs zuteilen.
<G-vec00291-001-s427><assign.zuteilen><en> If you do not make a seat reservation, we will assign you a seat on the day of departure.
<G-vec00291-001-s427><assign.zuteilen><de> Falls Sie kein Sitz im Voraus reserviert haben, werden wir Ihnen am Abflugstag einen zuteilen.
<G-vec00291-001-s428><assign.zuteilen><en> Whenever you get one or more deuces or joker in your final hand, the computer will automatically assign a suit and value to it to give you the highest possible payout, in light of the other cards that you are holding.
<G-vec00291-001-s428><assign.zuteilen><de> Wann auch immer Sie eine oder mehr Zweien oder Spaßvogel in Ihrer Endhand bekommen, wird der Computer eine Klage automatisch zuteilen und dazu schätzen, um Ihnen die höchstmögliche Ausschüttung im Licht der anderen Karten zu geben, die Sie halten.
<G-vec00291-001-s429><assign.zuteilen><en> Whenever you get the Joker, the computer will automatically assign a suit and value to it to give you the highest possible payout in light of the other cards that you are holding.
<G-vec00291-001-s429><assign.zuteilen><de> Wann auch immer Sie den Spaßvogel bekommen, wird der Computer eine Klage automatisch zuteilen und dazu schätzen, um Ihnen die höchstmögliche Ausschüttung im Licht der anderen Karten zu geben, die Sie halten.
<G-vec00291-001-s430><assign.zuteilen><en> During an hour of silence you will experience the Lord's grace, Who will inform you of His will and assign your future activity to you.
<G-vec00291-001-s430><assign.zuteilen><de> In einer stillen Stunde wirst du die Gnade des Herrn erleben, Der dir Seinen Willen kundtun und dir dein ferneres Wirken zuteilen wird.
<G-vec00571-001-s426><assign.zuteilen><en> If you travel with other passengers we will assign the seats in accordance with availability and the conditions of the fare paid.
<G-vec00571-001-s426><assign.zuteilen><de> Wenn Sie mit anderen Passagieren reisen, werden wir die Sitzplätze je nach Verfügbarkeit und den Bedingungen des bezahlten Tarifs zuteilen.
<G-vec00291-001-s431><assign.zuweisen><en> #BillboardGroup - The number of the billboard group you wish to assign a new material to.
<G-vec00291-001-s431><assign.zuweisen><de> #BillboardGroup - Die Nummer der Billboard-Gruppe, der Sie ein neues Material zuweisen möchten.
<G-vec00291-001-s432><assign.zuweisen><en> If you assign an alias to a table or a view, the alias must be used when specifying columns and also in any column references included in other clauses.
<G-vec00291-001-s432><assign.zuweisen><de> Wenn Sie einer Tabelle oder einer Ansicht einen Alias zuweisen, muss der Alias verwendet werden, wenn Spalten angegeben werden, und auch in Spaltenreferenzen, die in anderen Klauseln enthalten sind.
<G-vec00291-001-s433><assign.zuweisen><en> For this, you can assign the right bandwidth in the following way.
<G-vec00291-001-s433><assign.zuweisen><de> Dafür, Sie können die richtige Bandbreite in der folgenden Art und Weise zuweisen.
<G-vec00291-001-s434><assign.zuweisen><en> To a deepened examination more a crucial difference is anticipated obvious: that between the shareholders whom the Board of the nordeuropei ports name and the shareholders who will assign the charges in new the Board of the Italian ports.
<G-vec00291-001-s434><assign.zuweisen><de> Entscheidender Difformità weist sich mehr zu einer vertieft Prüfung vor offensichtlich: jen zwischen den Aktionären und den Aktionären, die die Behörden von den nordeuropäischen Häfen ernennen, die die Angriffe in den neuen Behörden von den italienischen Häfen zuweisen werden.
<G-vec00291-001-s435><assign.zuweisen><en> To assign your devices to a XenMobile Server, under Choose Action, choose Assign to Server .
<G-vec00291-001-s435><assign.zuweisen><de> Wählen Sie zum Zuweisen der Geräte zu XenMobile Server unter Choose Action die Option Assign to Server aus.
<G-vec00291-001-s436><assign.zuweisen><en> Click the keyboard icon and assign the macro to F3 (or whatever button you want to assign it to) using the “Press New Shortcut Key” clickable box.
<G-vec00291-001-s436><assign.zuweisen><de> "Klicke auf das Zeichen mit einer Tastatur, um dem Makro F3 zuzuordnen (oder eine andere Taste, die du ihm zuweisen möchtest), indem du die anklickbare Box ""Neues Tastaturkürzel eingeben"" drückst."
<G-vec00291-001-s437><assign.zuweisen><en> You can assign the address in the Azure portal.
<G-vec00291-001-s437><assign.zuweisen><de> Sie können die Adresse im Azure-Portal zuweisen.
<G-vec00291-001-s438><assign.zuweisen><en> How to assign a JavaScript function to an event handler is described in the section Assigning Function to Event Handlers .
<G-vec00291-001-s438><assign.zuweisen><de> Informationen zum Zuweisen einer JavaScript-Funktion zu einem Event Handler finden Sie im Abschnitt Zuweisen von Funktionen zu Event Handlern .
<G-vec00291-001-s439><assign.zuweisen><en> For more information, see Assign a Telephony User to a Line or a Phone.
<G-vec00291-001-s439><assign.zuweisen><de> Weitere Informationen finden Sie unter Zuweisen eines Telefoniebenutzers zu einem Anschluss oder einem Telefon.
<G-vec00291-001-s440><assign.zuweisen><en> Here you can assign any letter to USB drive by hitting it.
<G-vec00291-001-s440><assign.zuweisen><de> Hier können Sie einen beliebigen Buchstaben zu USB Laufwerk durch Schlagen zuweisen.
<G-vec00291-001-s441><assign.zuweisen><en> 1 Assign a File Name Select or assign the data file name for the downloaded results to be saved in.
<G-vec00291-001-s441><assign.zuweisen><de> 1 Dateinamen zuweisen Wählen Sie den Namen der Datendatei aus, in der die übertragenen Ergebnisse gespeichert werden sollen, oder weisen Sie den Namen zu.
<G-vec00291-001-s442><assign.zuweisen><en> People of the Freedom) in a interrogation to the minister of the Economy and Finances support the deputy Roberto Cassinelli (, charge covered from the same Prime Minister Mario Monti who but today has proposed the president of the Republic to leave the interim in order to assign the guide of the ministry to Vittorio Grilli.
<G-vec00291-001-s442><assign.zuweisen><de> Das stützt Volk von der Freiheit in einem Verhör zu dem Finanzminister den Abgeordneter Roberto Cassinelli (), belädt von dem Premierminister Mario Monti das gleiche überzieht, der aber heute zu dem Staatspräsidenten vorgeschlagen hat, den Führer von dem Ministerium zu Vittorio Grilli zuweisen, das Interim zu lassen.
<G-vec00291-001-s443><assign.zuweisen><en> For this, the manager can assign tests for each team and agent.
<G-vec00291-001-s443><assign.zuweisen><de> Dafür, der Manager kann für jedes Team und Agententests zuweisen.
<G-vec00291-001-s444><assign.zuweisen><en> Do the settings trying to assign goals to put the ball in play castle.
<G-vec00291-001-s444><assign.zuweisen><de> Sind die Einstellungen versucht, Ziele zuweisen, um den Ball im Spiel Schloss gebracht.
<G-vec00291-001-s445><assign.zuweisen><en> Set the new clip as default ringtone or assign to contacts, using this editor.
<G-vec00291-001-s445><assign.zuweisen><de> Stellen Sie den neuen Clip als Standard-Klingelton oder zu Kontakten zuweisen, mit diesem Editor.
<G-vec00291-001-s446><assign.zuweisen><en> The dispatcher can manually assign an available driver or the system can automatically assign.
<G-vec00291-001-s446><assign.zuweisen><de> Der Dispatcher kann manuell zuweisen ein Treiber verfügbar oder kann das System automatisch zuweisen.
<G-vec00291-001-s448><assign.zuweisen><en> Open the Altova LicenseServer administration page, and deactivate the license from the old MapForce Server machine and re-assign it to the new machine (see Assign Licenses to Registered Products).
<G-vec00291-001-s448><assign.zuweisen><de> Öffnen Sie die Altova LicenseServer-Verwaltungsseite und deaktivieren Sie die Lizenz für den alten MapForce Server-Rechner und weisen Sie diese dem neuen Rechner zu (siehe Zuweisen von Lizenzen zu registrierten Produkten).
<G-vec00291-001-s449><assign.zuweisen><en> With Role option you can automatically assign roles to users or create conditional field and depending on user’s selection assign appropriate role.
<G-vec00291-001-s449><assign.zuweisen><de> Mit Rollen Option können Rollen automatisch auf Benutzer zuordnen oder bedingte Feld und je nach Auswahl des Benutzers zuweisen angemessene Rolle.
<G-vec00291-001-s450><assign.zuweisen><en> How to assign some window action to those keys depends on your window management system.
<G-vec00291-001-s450><assign.zuweisen><de> Wie man den Tasten eine Funktion für Fenster zuweist hängt vom verwendeten Window-Management-System ab.
<G-vec00291-001-s451><assign.zuweisen><en> some-table some-key some-value) That way, you can be sure that Lilypond will not assign meaning to the returned value regardless of where it encounters it.
<G-vec00291-001-s451><assign.zuweisen><de> eine-Tabelle ein-Schlüssel ein-Wert) Auf diese Weise kann man sicher sein, dass LilyPond dem ausgegebenen Wert keine Bedeutung zuweist, unabhängig davon, wo er angetroffen wird.
<G-vec00291-001-s452><assign.zuweisen><en> Later in this section, you will learn how to assign styles to such blocks of grouped components.
<G-vec00291-001-s452><assign.zuweisen><de> Weiter hinten in diesem Abschnitt erfahren Sie, wie man solchen Blöcken gruppierter Komponenten Stile zuweist.
<G-vec00291-001-s453><assign.zuweisen><en> In previous versions, ships can do only one of the three functions. If you assign it more than one function, it will only do the one with the lowest numeric code.
<G-vec00291-001-s453><assign.zuweisen><de> In früheren Versionen können Schiffe immer nur eine Alchemiefunktion ausführen; wenn du ihm mehr als eine Funktion zuweist, führt es die mit dem niedrigsten numerischen Code aus.
<G-vec00291-001-s454><assign.zuweisen><en> DHCP can also be configured to assign addresses to each relevant client dynamically from an address pool set up for this purpose.
<G-vec00291-001-s454><assign.zuweisen><de> Zum anderen kann DHCP aber auch so konfiguriert werden, dass der Server jedem relevanten Client eine Adresse aus einem dafür vorgesehenen Adresspool dynamisch zuweist.
<G-vec00291-001-s455><assign.zuweisen><en> At the time, KitzbÃ1⁄4hel is still a little town and will soon be bursting at the seams, so the authorities – as the biggest landowners – assign land to the miners.
<G-vec00291-001-s455><assign.zuweisen><de> Das damals noch kleine Städtchen Kitzbühel platzt bald aus allen Nähten, sodass die Obrigkeit – als größter Landbesitzer – den Bergleuten Grundstücke zuweist.
<G-vec00291-001-s475><assign.zuordnen><en> Click the keyboard icon and assign the macro to F3 (or whatever button you want to assign it to) using the “Press New Shortcut Key” clickable box.
<G-vec00291-001-s475><assign.zuordnen><de> "Klicke auf das Zeichen mit einer Tastatur, um dem Makro F3 zuzuordnen (oder eine andere Taste, die du ihm zuweisen möchtest), indem du die anklickbare Box ""Neues Tastaturkürzel eingeben"" drückst."
<G-vec00291-001-s476><assign.zuordnen><en> With the Terminal Pins Wizard, it is now possible to assign terminal connections in graphical representations individually.
<G-vec00291-001-s476><assign.zuordnen><de> Mit dem Klemmenanschlussassistenten ist es jetzt möglich, Klemmenanschlüsse in grafischen Darstellungen individuell zuzuordnen.
<G-vec00291-001-s477><assign.zuordnen><en> With the help of a map it was easy to assign to each mountain its name.
<G-vec00291-001-s477><assign.zuordnen><de> Mit Hilfe einer Karte war es leicht, jedem Berg seinen Namen zuzuordnen.
<G-vec00291-001-s478><assign.zuordnen><en> 27 is difficult to assign.
<G-vec00291-001-s478><assign.zuordnen><de> Kapitel 27 ist schwer zuzuordnen.
<G-vec00291-001-s479><assign.zuordnen><en> The port VLAN ID (PVID) is set to '1' for all ports, to assign the ports to the internal network.
<G-vec00291-001-s479><assign.zuordnen><de> Die Port VLAN ID (PVID) wird für alle Ports auf '1' gestellt, um die Ports dem internen Netz zuzuordnen.
<G-vec00291-001-s480><assign.zuordnen><en> Ecologic is consigned as a national expert to assign the administrative measures provided by the German regulatory law to the relevant Community law and to analyse them.
<G-vec00291-001-s480><assign.zuordnen><de> Ecologic ist als Experte für das deutsche Umweltrecht mit der Aufgabe betraut, die im deutschen Ordnungsrecht vorgesehenen Maßnahmen der ausgewählten europäischen Gesetzgebung zuzuordnen und zu analysieren.
<G-vec00291-001-s481><assign.zuordnen><en> Now we try to assign to every player i his strength g_i.
<G-vec00291-001-s481><assign.zuordnen><de> Wir versuchen nun, jedem Spieler eine Spielstärke g_i zuzuordnen.
<G-vec00291-001-s482><assign.zuordnen><en> And it allows you to assign the most accurate therapy.
<G-vec00291-001-s482><assign.zuordnen><de> Und es ermöglicht Ihnen, die genaueste Therapie zuzuordnen.
<G-vec00291-001-s483><assign.zuordnen><en> The comprehensive reforms require, among other things, that all market participants assign their clients to legally specified client categories and that they take all necessary steps when executing and forwarding securities orders to achieve the best results (best execution) and to disclose the relevant information in an appropriate manner.
<G-vec00291-001-s483><assign.zuordnen><de> Die umfangreichen Neuerungen verpflichten alle Marktteilnehmer unter anderem, ihre Kunden gesetzlich vorgegebenen Kundenkategorien zuzuordnen sowie alle notwendigen Schritte zu unternehmen, um bei der Ausführung und Weiterleitung von Wertpapierorders die besten Resultate (Best Execution) zu erzielen sowie Informationen hierüber in geeigneter Weise zur Verfügung zu stellen.
<G-vec00291-001-s484><assign.zuordnen><en> Should you be logged into your Pinterest account at the same time, it is furthermore possible for Pinterest to assign your visit to your Pinterest account.
<G-vec00291-001-s484><assign.zuordnen><de> Sollten Sie währenddessen in Ihr Pinterest-Account eingeloggt sein, ist es Pinterest zudem möglich, Ihren Besuch Ihrem Pinterest-Account zuzuordnen.
<G-vec00291-001-s485><assign.zuordnen><en> "The pre-defined selections in the "" Special Instrument Name Prefix "" drop-down list (Dulci, Fiddle, Autoharp, Arab, Chroma, All-Key, Concertina...) allow you to assign the module a name which will cause a specific tablature display regardless of the selected tuning (see Special instruments)."
<G-vec00291-001-s485><assign.zuordnen><de> "• Die bereits vorgegebenen Einstellungen in dem "" Special Instrument Name Prefix "" Liste (Dulcimer, Fiddle, Autoharp, Arab, All-Key) erlauben Ihnen dem Modul einen speziellen Namen zuzuordnen und darauf hinfolgend wird TablEdit die entsprechende Tabulatur anzeigen, ohne die ausgewählte Stimmung zu berücksichtigen (siehe Spezielle Instrumente)."
<G-vec00291-001-s486><assign.zuordnen><en> In doing so, the YouTube server is informed about the websites you have accessed.If you logged in with your YouTube account, you enable YouTube to assign your browsing behavior directly to your personal profile.
<G-vec00291-001-s486><assign.zuordnen><de> Dabei wird dem Youtube-Server mitgeteilt, welche unserer Seiten Sie besucht haben.Wenn Sie in Ihrem YouTube-Account eingeloggt sind, ermöglichen Sie YouTube Ihr Surfverhalten direkt Ihrem persönlichen Profil zuzuordnen.
<G-vec00291-001-s487><assign.zuordnen><en> We have no possibility whatsoever to assign these anonymous measuring values to your person, for example, by allocation of your IP address or in another way.
<G-vec00291-001-s487><assign.zuordnen><de> Wir haben keinerlei Möglichkeit, diese anonymen Messwerte - etwa über die Zuordnung Ihrer IP-Adresse oder auf anderem Wege - Ihrer Person zuzuordnen.
<G-vec00291-001-s488><assign.zuordnen><en> A system of this kind can also be used to assign certain tasks to each person at least once within a defined period, in order for a sufficient level of practice with the task and thus also familiarity with the OSH information related to it to be retained.
<G-vec00291-001-s488><assign.zuordnen><de> Ein solches System kann außerdem dazu genutzt werden, bestimmte Aufgaben in einem festgelegten Zeitraum jeder Person mindestens einmal zuzuordnen, damit ein ausreichender Übungsgrad und damit auch die Kenntnis aufgabenbezogener arbeitsschutzspezifischer Informationen erhalten bleibt.
<G-vec00291-001-s489><assign.zuordnen><en> If you are logged into your YouTube account, you will enable YouTube to assign your surfing behaviour directly to your personal profile.
<G-vec00291-001-s489><assign.zuordnen><de> Wenn Sie in Ihrem YouTube-Account eingeloggt sind ermöglichen Sie YouTube, Ihr Surfverhalten direkt Ihrem persönlichen Profil zuzuordnen.
<G-vec00291-001-s490><assign.zuordnen><en> "On page Magnification, I try to ""sort"" the terms and assign them to values of the exit pupil and the resolution."
<G-vec00291-001-s490><assign.zuordnen><de> "Auf der Seite Vergrößerung versuche ich, die Begriffe zu ""sortieren"" und Werten der Austrittspupille sowie der Auflösung zuzuordnen."
<G-vec00291-001-s491><assign.zuordnen><en> We will can train our legions of orcs to make them more skilled in combat, train war beasts, assign generals and increase rank, and endless more actions that make this new delivery one of the most anticipated games of 2017.
<G-vec00291-001-s491><assign.zuordnen><de> Wir können unsere Legionen von Orks ausbilden, um sie im Kampf zu machen, Kriegstiere zu trainieren, Generäle zuzuordnen und den Rang zu erhöhen und endlos mehr Aktionen, die diese neue Lieferung zu einem der am meisten erwarteten Spiele von 2017 machen.
<G-vec00291-001-s492><assign.zuordnen><en> However, Youtube can assign your surfing behaviour directly to your personal profile if you are logged into your YouTube account.
<G-vec00291-001-s492><assign.zuordnen><de> Allerdings kann Youtube Ihr Surfverhalten direkt Ihrem persönlichen Profil zuzuordnen, sollten Sie in Ihrem YouTube Konto eingeloggt sein.
<G-vec00291-001-s493><assign.zuordnen><en> In addition to the default groups described in Access rights, Commerce adds a set of groups, which can be used to assign access rights to Commerce functions.
<G-vec00291-001-s493><assign.zuordnen><de> Zusätzlich zu den Standardgruppen beschrieben in den Zugriffsrechten, Commerce fügt eine Reihe von Gruppen ein, die verwendet werden, um Zugriffsrechte auf Commerce-Funktionen zuzuordnen.
<G-vec00291-001-s494><assign.zuweisen><en> And when I said to the Mensheviks in the course of the struggle against them: ‘You are in any case not inclined to assign a leading role to the peasantry, then this was not an agreement with the method of the Mensheviks as Radek tries to insinuate, but only the clear posing of an alternative: either the dictatorship of the liberal plutocracy or the dictatorship of the proletariat.
<G-vec00291-001-s494><assign.zuweisen><de> Und wenn ich im Kampfe gegen die Menschewiki diesen sagte: „Ihr seid ja am allerwenigsten bereit, der Bauernschaft eine führende Rolle zuzuweisen“, so war das keine Übereinstimmung mit der „Methode“ der Menschewiki, wie Radek mir zu insinuieren versucht, sondern eine klare Alternative, entweder die Diktatur der liberalen Plutokratie, oder die Diktatur des Proletariats.
<G-vec00291-001-s495><assign.zuweisen><en> If you select the generic Extensible Markup Language document type, you will be prompted for a schema (DTD or XML Schema) to assign to the document.
<G-vec00291-001-s495><assign.zuweisen><de> Wenn Sie die allgemeine Dokumentart Extensible Markup Language auswählen, werden Sie aufgefordert, dem Dokument ein Schema (DTD oder XML-Schema) zuzuweisen.
<G-vec00291-001-s496><assign.zuweisen><en> Kapost has clearly proven itself through vetted services in helping media outlets pitch, assign, edit and manage payment for content contributors.
<G-vec00291-001-s496><assign.zuweisen><de> Kapost hat sich eindeutig durch gründliche Dienstleistungen bewährt, indem es Medien Outlets die Bezahlungen für Inhalt Beitragende zu bearbeiten, zuzuweisen und zu verwalten.
<G-vec00291-001-s497><assign.zuweisen><en> The Harbour Authority has remembered that the participation to the Hennebique has the scope to complete the recovery process, redesigns and valorization of I put forward it to sea of the city and, in the specific one, the requalification of the building has like objective to assign to this portion of waterfront a meaningful role of public and private service in support of crocieristiche, harbour, tourist and city the activities, privileging also pedestrian accommodation of the context spaces.
<G-vec00291-001-s497><assign.zuweisen><de> Die Hafen Autorität hat erinnert neu zeichnen, dass der Eingriff zu dem Hennebique das Ziel hat, den Prozess von der Wiedergewinnung zu ergänzen, und zeige ich Bewertung von ihn zu dem Meer von der Stadt, und hat die Neuqualifizierung von dem Gebäude in spezifischem, auch wie Ziel waterfront dienstlich und, und privilegiert die fußgänger Regelung von den Räumen von dem Kontext, zu dieser Portion von einer bedeutenden beraubt Rolle die Öffentlichkeit zuzuweisen crocieristiche, hafen-, touristischen und städtischen von den Tätigkeiten zu Unterstützung.
<G-vec00291-001-s498><assign.zuweisen><en> The background color is an unusual color for people, furniture and clothing, and is used to assign an alpha channel to the captured image.
<G-vec00291-001-s498><assign.zuweisen><de> Hierbei wird eine generell bei Menschen, Möbeln und Bekleidung unübliche Farbe als Hintergrund verwendet, um dem aufgenommenen Bild einen Alphakanal zuzuweisen.
<G-vec00291-001-s499><assign.zuweisen><en> A change of mindset is needed by hoteliers who need to move now to assign budgets and adopt Metasearch as a key customer capture opportunity.
<G-vec00291-001-s499><assign.zuweisen><de> Es ist eine Veränderung der Denkweise der Hoteliers erforderlich, die jetzt daran arbeiten müssen, Budgets zu zuzuweisen und die Metasuche als eine wichtige Kundenerfassungsmöglichkeit zu verwenden.
<G-vec00291-001-s500><assign.zuweisen><en> With its two wizards, the macro Advanced CAD Import provides the ability to import drawings in the DXF or DWG format to Engineering Base projects and assign the objects of the imported drawings to Engineering Base objects and attributes.
<G-vec00291-001-s500><assign.zuweisen><de> Der Erweiterte CAD-Import bietet mit seinen zwei Assistenten die Möglichkeit, Zeichnungen mit DXF- oder DWG-Format in Engineering Base-Projekte zu importieren und die Objekte der importierten Zeichnungen Engineering Base-Objekten und -Attributen zuzuweisen.
<G-vec00291-001-s501><assign.zuweisen><en> The Member States would be obliged to conduct harmonized measures and to assign resources to them.
<G-vec00291-001-s501><assign.zuweisen><de> Die Mitgliedstaaten wären verpflichtet, einheitliche Maßnahmen durchzuführen und Ressourcen zuzuweisen.
<G-vec00291-001-s502><assign.zuweisen><en> Before deploying an app on a Shared iPad, Endpoint Management sends a request to the Apple VPP server to assign VPP licenses to devices.
<G-vec00291-001-s502><assign.zuweisen><de> Vor dem Bereitstellen einer App auf einem geteilten iPad sendet Endpoint Management eine Anforderung an den Apple VPP-Server, um VPP-Lizenzen Geräten zuzuweisen.
<G-vec00291-001-s503><assign.zuweisen><en> It’s time to assign responsibility.
<G-vec00291-001-s503><assign.zuweisen><de> Es ist Zeit, Verantwortung zuzuweisen.
<G-vec00291-001-s504><assign.zuweisen><en> Role Based Access Control (RBAC) which allows customers to assign different roles/permissions to users of their StoreOnce system.
<G-vec00291-001-s504><assign.zuweisen><de> Rollenbasierte Zugriffskontrolle (RBAC), die es Kunden ermöglicht, Benutzern ihres StoreOnce-Systems unterschiedliche Rollen/Berechtigungen zuzuweisen.
<G-vec00291-001-s505><assign.zuweisen><en> You can use the Edit Job Ticket dialog box (File > Job Jackets > Modify Job Ticket) to assign a Layout Specification to a layout in the active project.
<G-vec00291-001-s505><assign.zuweisen><de> Sie können die Dialogbox Job Ticket bearbeiten verwenden (Datei/Ablage > Job Jackets > Job Ticket bearbeiten), um einem Layout im aktiven Projekt eine Layoutspezifikation zuzuweisen.
<G-vec00291-001-s506><assign.zuweisen><en> “Confluence allows everyone on the team to access presentations used in meetings, read minutes from previous discussions and assign action points.
<G-vec00291-001-s506><assign.zuweisen><de> „Confluence ermöglicht es jedem im Team, auf Präsentationen zuzugreifen, die bei Meetings verwendet wurden, Protokolle vorheriger Besprechungen zu lesen und Aktionspunkte zuzuweisen.
<G-vec00291-001-s507><assign.zuweisen><en> It is nothing you have to assign to yourself.
<G-vec00291-001-s507><assign.zuweisen><de> Das ist nichts, was du dir zuzuweisen hast.
<G-vec00291-001-s508><assign.zuweisen><en> Thickness: Select this option to assign the thickness value from a neighboring text/block attribute.
<G-vec00291-001-s508><assign.zuweisen><de> Dichte: Diese Option auswählen, um die Dichte oder Stärke zuzuweisen, von enem nahestehenden Text/Blockattribut.
<G-vec00291-001-s509><assign.zuweisen><en> There is a tendency in China for companies to assign human resource management functions mainly to personnel administrative areas, such as legal compliance, records maintenance, and issuance of personnel policies.
<G-vec00291-001-s509><assign.zuweisen><de> Es gibt eine Tendenz in China für Unternehmen Funktionen Human Resource Management in erster Linie auf Personalverwaltungsbereiche, wie Einhaltung von Rechtsvorschriften, Aufzeichnungen Wartung und Ausgabe von Personalpolitik zuzuweisen.
<G-vec00291-001-s510><assign.zuweisen><en> The VLAN_ID is not sent to the RADIUS server. However, the Public Spot uses it to assign a VLAN ID provided by the gateway to a successfully authenticated user.
<G-vec00291-001-s510><assign.zuweisen><de> Die VLAN_ID wird nicht an den RADIUS-Server übermittelt, sondern vom Public Spot dazu genutzt, einem Benutzer nach erfolgreicher Authentifizierung eine vom Gateway vorgegebene VLAN-ID zuzuweisen.
<G-vec00291-001-s511><assign.zuweisen><en> It has weak authentication mechanisms and has the ability to assign a wide range of ports for the services it controls.
<G-vec00291-001-s511><assign.zuweisen><de> Es besitzt schwache Authentifizierungsmechanismen und hat die Fhigkeit, eine groe Bandbreite an Ports fr die von ihm kontrollierten Dienste zuzuweisen.
<G-vec00291-001-s512><assign.zuweisen><en> In a JavaScript action, you might need to select a Workflow Accelerator user based on external data, to assign a role.
<G-vec00291-001-s512><assign.zuweisen><de> Nutzerinformationen laden¶ In einer JavaScript-Aufgabe möchten Sie unter Umständen einen Nutzer auf Basis externer Daten auswählen, um so eine Rolle zuzuweisen.
<G-vec00291-001-s513><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to Free Scottish Sex Chat the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s513><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung Free Scottish Sex Chat die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s514><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to BG SEX the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s514><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung BG SEX die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s515><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to bongocams.info the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s515><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung bongocams.info die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s516><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to Adultter the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s516><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung BoinkCams die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s517><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to EroDolls the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s517><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung High heels Crush Models die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s518><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to BongaCams - Live Sex Chat the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s518><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung Free Live Sex Chat die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s519><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to CAMSEX.SU the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s519><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung CAMSEX.SU die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s520><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to Free Live Girls Sex Chat Roulette the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s520><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung Free Live Girls Sex Chat Roulette die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s521><assign.übereignen><en> I hereby expressly assign, and transfer, without further compensation, to BиpTcekc the results, content, and proceeds of my appearance(s) (including all such appearances made to date) videos, audio, chat, dialog, texts, acts, and instructional videos and advices, all of which are part of services provided - including all author rights to the above mentioned materials, renewals and extensions of such rights worldwide and throughout the whole validity period of such rights.
<G-vec00291-001-s521><assign.übereignen><de> Hiermit übereigne und transferiere ich ausdrücklich ohne weitere Vergütung BиpTcekc die Ergebnisse, Inhalte und Einnahmen meiner Auftritte (einschließlich all der bis heute gemachten Auftritte) in Videos, Audiodateien, Chats, Dialogen, Texten, Handlungen und Anleitungsvideos und Ratgebern, die alle Teil der bereitgestellten Dienste sind – einschließlich aller Autorenrechte an den zuvor genannten Materialien, Erneuerungen und Erweiterungen derartiger Rechte weltweit und über die gesamte Geltungsdauer derartiger Rechte.
<G-vec00291-001-s524><assign.übereignen><en> (6) In any case, the contracting party is to assign and transfer the reports, data carriers, raw data, samples and other documents embodying the work results to Pruftechnik upon termination of the contract.
<G-vec00291-001-s524><assign.übereignen><de> (6) Jedenfalls wird der Vertragspartner die Berichte, Datenträger, Rohdaten, Muster und sonstigen Unterlagen die Arbeitsergebnisse verkörpern bei Beendigung des Vertrages Prüftechnik übereignen und übergeben.
<G-vec00291-001-s525><assign.übereignen><en> The purchaser may neither pledge the delivery items nor assign them as security.
<G-vec00291-001-s525><assign.übereignen><de> Der Kunde darf den Liefergegenstand weder verpfänden noch zur Sicherung übereignen.
<G-vec00291-001-s526><assign.übereignen><en> 7.1 The company reserves title to the delivered goods until the purchase price as well as any other claims of the company against the customer, including future claims, have been paid in full.7.2 The customer is obliged to handle the goods carefully and assumes no-fault liability for any deterioration of the goods.7.3 The customer is not entitled to pledge the goods or to assign them as collateral.
<G-vec00291-001-s526><assign.übereignen><de> 7.1 Bis zur vollständigen Bezahlung der Kaufpreisforderung sowie aller anderen, auch künftig fällig werdenden, der Gesellschaft gegen den Kunden zustehenden Forderungen bleibt die gelieferte Ware Eigentum der Gesellschaft.7.2 Der Kunde ist verpflichtet die Ware pfleglich zu behandeln; für Wertminderung oder Verlust haftet der Kunde auch ohne Verschulden.7.3 Der Kunde darf die Ware weder verpfänden noch zur Sicherheit übereignen.
<G-vec00291-001-s527><assign.übereignen><en> If we acquire ownership or a co-ownership share in the new item, we assign our ownership or co-ownership share in the new item to Purchaser under the suspensive condition of full payment of the purchase price.
<G-vec00291-001-s527><assign.übereignen><de> Erwerben wir Eigentum oder einen Miteigentumsanteil an der neuen Sache, so übereignen wir dem Abnehmer unser Eigentum oder unseren Miteigentumsanteil an der neuen Sache unter der aufschiebenden Bedingung der vollen Kaufpreiszahlung.
<G-vec00291-001-s528><assign.übereignen><en> The buyer is not entitled to pledge the merchandise or to assign it by way of security.
<G-vec00291-001-s528><assign.übereignen><de> Der Käufer ist nicht berechtigt, die Ware zu verpfänden oder zur Sicherstellung zu übereignen.
<G-vec00291-001-s529><assign.übereignen><en> 9.2 The customer may reprocess and sell the goods within the orderly and usual business course, however may not pledge or assign them for security.
<G-vec00291-001-s529><assign.übereignen><de> 9.2 Der Kunde darf die Waren im ordnungsgemäßen und üblichen Geschäftsgang verarbeiten und veräußern, jedoch weder verpfänden noch zur Sicherung übereignen.
<G-vec00291-001-s530><assign.übereignen><en> Prior to the transfer of ownership, the customer is not entitled to pledge the goods without our consent, or to assign them for security or the like.
<G-vec00291-001-s530><assign.übereignen><de> Vor Eigentumsübergang ist der Kunde nicht berechtigt, die Ware ohne unsere Zustimmung zu verpfänden, zur Sicherheit zu übereignen und dgl.
<G-vec00291-001-s531><assign.übertragen><en> 4.2 TUI fly and the actual carrier shall be entitled to assign performance of carriage by air in full or in part to third parties/agents employed in performance of their obligations.
<G-vec00291-001-s531><assign.übertragen><de> 4.2 Das TUI fly Flugportal und der ausführende Luftfrachtführer sind berechtigt, die Durchführung der Flugbeförderung ganz oder teilweise auf Dritte/Erfüllungsgehilfen zu übertragen.
<G-vec00291-001-s532><assign.übertragen><en> You agree to assign any rights you may have to Fan Content to EOS.
<G-vec00291-001-s532><assign.übertragen><de> Sie erklären sich bereit, alle Rechte, die Sie möglicherweise am Fan-Content haben, an EOS zu übertragen.
<G-vec00291-001-s533><assign.übertragen><en> (3) The Law may assign further tasks to the Federal Parliament.
<G-vec00291-001-s533><assign.übertragen><de> (3) Das Gesetz kann der Bundesversammlung weitere Aufgaben und Befugnisse übertragen.
<G-vec00291-001-s534><assign.übertragen><en> If you imagine this case, author A would assign her rights to the FSF Europe and give a single, proprietary license to company B with the contract clause of not passing this license and software on to third parties.
<G-vec00291-001-s534><assign.übertragen><de> Stellt man sich diesen Fall vor, so würde Autor A seine Rechte an die FSF Europe übertragen und eine einfache, proprietäre Lizenz an Firma B erteilen, mit der Vertragsbedingung, diese nicht weiterzugeben.
<G-vec00291-001-s535><assign.übertragen><en> By submitting communications and/or materials to Syngenta through this Web site, you assign to Syngenta, free of charge, all worldwide rights, title and interest in all copyrights and other intellectual property rights in the information and/or materials you submit.
<G-vec00291-001-s535><assign.übertragen><de> Indem Sie über die Website Nachrichten und/oder Materialien an Syngenta übermitteln, übertragen Sie gleichzeitig kostenlos alle weltweiten Rechte an allen Urheberrechten und anderem geistigen Eigentum, das in den uns übermittelten Informationen und Materialien enthalten ist, an Syngenta.
<G-vec00291-001-s536><assign.übertragen><en> Stars Mobile reserves the right to assign this agreement, in whole or in part, at any time without notice.
<G-vec00291-001-s536><assign.übertragen><de> Stars Mobile behält sich das Recht vor, diese Vereinbarung vollständig oder teilweise zu jeder Zeit ohne Bekanntgabe zu übertragen.
<G-vec00291-001-s537><assign.übertragen><en> It normally conducts the surveys and prepares comprehensive compilations of data, provided the Federal Council does not assign this duty to another statistical office or federal office.
<G-vec00291-001-s537><assign.übertragen><de> Es führt in der Regel die Erhebungen durch und erarbeitet Gesamtdarstellungen, sofern diese nicht durch den Bundesrat einer anderen Statistik- oder Amtsstelle übertragen werden.
<G-vec00291-001-s538><assign.übertragen><en> You are not allowed to give sub-licenses for the material or rights granted to you under this agreement, or to forward, assign or sell such material or rights.
<G-vec00291-001-s538><assign.übertragen><de> Es ist Ihnen untersagt, für die Materialien oder die im Rahmen dieser Vereinbarung gewährten Rechte Unterlizenzen zu erteilen, weiterzugeben, zu übertragen oder zu verkaufen.
<G-vec00291-001-s539><assign.übertragen><en> Focused shall be free to assign these Terms of Use and/or transfer User’s rights and obligations under these Terms of Use fully or partly to any third parties at Focused’s sole and absolute discretion.
<G-vec00291-001-s539><assign.übertragen><de> Focused steht es frei, diese Nutzungsbedingungen zu übertragen und/oder die Rechte und Pflichten des Nutzers im Rahmen dieser Nutzungsbedingungen ganz oder teilweise auf Dritte zu übertragen, und zwar nach alleinigem Ermessen von Focused.
<G-vec00291-001-s540><assign.übertragen><en> Regardless of whether you choose to sell claims or assign the processing of receivables to us on a fiduciary basis, EOS Schweiz will help you safeguard your liquidity – with in-depth know-how and tailored solutions.
<G-vec00291-001-s540><assign.übertragen><de> Unabhängig davon, ob Sie sich für den Forderungsverkauf entscheiden oder uns die treuhänderische Forderungsbearbeitung übertragen, hilft Ihnen EOS Schweiz dabei, Ihre Liquidität zu sichern – mit fundiertem Know-how und individuellen Lösungen.
<G-vec00291-001-s541><assign.übertragen><en> If you now want to assign the template to another folder or record so choose in that templates -> load .
<G-vec00291-001-s541><assign.übertragen><de> Wollen Sie nun die Vorlage auf einen anderen Ordner oder Datensatz übertragen, so wählen Sie in diesem Vorlagen -> Laden .
<G-vec00291-001-s542><assign.übertragen><en> In the best of cases, you inform me precisely of your concerns and wishes in view of the project which you assign to me.
<G-vec00291-001-s542><assign.übertragen><de> Im Idealfall informieren Sie mich ausführlich über Ihre Sorgen und Wünsche rund um das Projekt, das Sie mir übertragen.
<G-vec00291-001-s543><assign.übertragen><en> The governments that have been recently elected in the region reflect an acknowledgment of the fact that it is necessary to assign a strategic role to the State in working out public policies.
<G-vec00291-001-s543><assign.übertragen><de> Die erst in jüngerer Zeit gewählten südamerikanischen Regierungen erkennen den Umstand an, dass man dem Staat bei der Definition der Öffentlichkeitspolitik eine strategische Rolle übertragen muss.
<G-vec00291-001-s544><assign.übertragen><en> "27 ""All the service of the sons of the Gershonites, in all their loads and in all their work, shall be performed at the command of Aaron and his sons; and you shall assign to them as a duty all their loads."
<G-vec00291-001-s544><assign.übertragen><de> 27 Nach dem Befehl Aarons und seiner Söhne soll alle Arbeit der Söhne der Gerschoniter geschehen hinsichtlich all ihrer Traglast und all ihrer Arbeit; und ihr sollt ihnen den Dienst für alles das übertragen, was sie zu tragen haben.
<G-vec00291-001-s545><assign.übertragen><en> If the customer’s item is to be regarded as the main item, the customer shall assign co-ownership to the seller on a pro rata basis.
<G-vec00291-001-s545><assign.übertragen><de> Ist die Sache des Kunden als Hauptsache anzusehen, so hat der Kunde dem Verkäufer anteilsmäßig Miteigentum zu übertragen.
<G-vec00291-001-s546><assign.übertragen><en> You grant Specialized a non-exclusive, royalty-free, perpetual right to use your content in any manner or media now or later developed, for any purpose, commercial, advertising, or otherwise, including the right to translate, display, reproduce, modify, create derivative works, sublicense, distribute, assign, publicly perform, and otherwise exploit such content on the App for the purposes of providing and promoting the App and our products as well as the features and services available on the App, and delivering services to you or promotional materials or opportunities to you.
<G-vec00291-001-s546><assign.übertragen><de> Sie gewähren Specialized ein nicht exklusives, gebührenfreies, unbefristetes Recht zur Nutzung Ihrer Inhalte in jeglicher Art und Weise, die jetzt oder später entwickelt wurden, für jeglichen Zweck, kommerziell, Werbung oder sonstiges, einschließlich des Rechts zur Übersetzung, Darstellung, Reproduktion, Änderung, Erstellen abgeleiteter Werke, unterlizenzieren, verteilen, übertragen, öffentlich vorführen und anderweitige Nutzung solcher Inhalte in der App zum Zwecke der Bereitstellung und Förderung der App und unserer Produkte sowie der Funktionen und Dienste in der App und Bereitstellung von Dienstleistungen für Sie oder Werbematerialien oder Möglichkeiten für Sie.
<G-vec00291-001-s547><assign.übertragen><en> In addition, your personal and other information may be disclosed to a potential or actual successor or assign in connection with a proposed or consummated merger, acquisition, reorganization, bankruptcy, or other similar event involving all or a portion of the Company, the Company's customer information may be transferred to our successor or assign.
<G-vec00291-001-s547><assign.übertragen><de> Außerdem können im Falle einer Fusion, einer Akquisition, einer Sanierung, eines Bankrotts oder bei ähnlichen Vorkommnissen, die das gesamte Unternehmen oder Teile desselben betreffen, die personenbezogenen Daten und sonstigen Informationen der Kunden des Unternehmens an unseren tatsächlichen oder potenziellen Nachfolger oder Abtretungsempfänger übertragen werden.
<G-vec00291-001-s548><assign.übertragen><en> Many German banks assign the Post with the legitimating task.
<G-vec00291-001-s548><assign.übertragen><de> Viele deutsche Banken übertragen der Post die Legitimationsaufgabe.
<G-vec00291-001-s549><assign.übertragen><en> Now we recolor the particle with a click on Color and then we assign the same color to the whole group via Group col=Smiley col.
<G-vec00291-001-s549><assign.übertragen><de> Nun wird das Teilchen durch Click auf Color umgefärbt und die Farbe mit Group col=Smiley col auf die ganze Gruppe übertragen.
<G-vec00291-001-s550><assign.übertragen><en> If the amalgamation is carried out in such a way that the supplier's objects are considered to be the main objects, it is understood that the supplier shall assign proportional joint ownership to us; the supplier shall hold sole or joint ownership for us.
<G-vec00291-001-s550><assign.übertragen><de> Erfolgt die Vermischung in der Weise, dass die Sache des Lieferanten als Hauptsache anzusehen ist, so gilt als vereinbart, dass der Lieferant uns anteilmäßig Miteigentum überträgt; der Lieferant verwahrt das Alleineigentum oder das Miteigentum für uns.
<G-vec00291-001-s551><assign.übertragen><en> The company is self-funded and has not accepted investment capital so far, but it does license, assign, and sell its technologies, trade secrets (intellectual property), and products to other companies.
<G-vec00291-001-s551><assign.übertragen><de> Das Unternehmen ist eigenfinanziert und hat bisher kein Investitionskapital akzeptiert, aber es lizenziert, überträgt und verkauft seine Technologien, Geschäftsgeheimnisse (geistiges Eigentum) und Produkte an andere Unternehmen.
<G-vec00291-001-s552><assign.übertragen><en> (2) Duellberg Konzentra shall not assign any intellectual property rights to the purchaser with the sale of the products.
<G-vec00291-001-s552><assign.übertragen><de> (2) Düllberg Konzentra überträgt mit dem Verkauf keinerlei geistige Schutzrechte an den Käufer.
<G-vec00291-001-s553><assign.übertragen><en> The purchaser shall assign to us co-title in the new goods in the proportion of the invoiced value of the goods under reservation to the other goods processed as at the time of processing.
<G-vec00291-001-s553><assign.übertragen><de> Der Käufer überträgt uns das Miteigentum an der neuen Sache im Verhältnis des Rechnungswertes der Vorbehaltsware zu den anderen verarbeiteten Waren im Zeitpunkt der Verarbeitung.
<G-vec00291-001-s554><assign.übertragen><en> This authorization does not assign rights to these documents and the copyright logo and the notation at the end of the page have to appear on all copies of the documents.
<G-vec00291-001-s554><assign.übertragen><de> Diese Ermächtigung überträgt keine Rechte an diesen Unterlagen und das urheberrechtliche Logo und der Vermerk am Ende der Seite müssen auf allen Kopien der Unterlagen erhalten bleiben.
<G-vec00291-001-s555><assign.übertragen><en> Dropbox may not assign this Agreement without providing notice to the Customer, except Dropbox may assign this Agreement or any rights or obligations under this Agreement to an Affiliate or in connection with a merger, acquisition, corporate reorganisation or sale of all or substantially all of its assets without providing notice.
<G-vec00291-001-s555><assign.übertragen><de> Dropbox darf diese Vereinbarung nur nach Benachrichtigung des Kunden übertragen, es sei denn, Dropbox überträgt diese Vereinbarung oder darin erläuterte Rechte oder Verpflichtungen auf eine Tochtergesellschaft oder in Verbindung mit einer Fusion, einer Übernahme, einer Neuorganisation des Unternehmens oder dem vollständigen oder teilweisen Verkauf aller Vermögenswerte.
<G-vec00291-002-s110><assign.abtreten><en> Cerner may assign its rights and duties under this agreement to any party at any time without notice to you.
<G-vec00291-002-s110><assign.abtreten><de> Cerner ist berechtigt, seine Rechte und Pflichten aus diesem Vertrag jederzeit abzutreten ohne Sie darüber in Kenntnis zu setzen.
<G-vec00291-002-s111><assign.abtreten><en> You may not assign the Terms or any rights or licenses granted hereunder, whether voluntarily, by operation of law, or otherwise, without our prior written consent, however, this agreement and the rights granted and obligations undertaken hereunder may be transferred, assigned, or delegated in any manner by Sampler.
<G-vec00291-002-s111><assign.abtreten><de> Sie sind nicht berechtigt, die Bedingungen oder Rechte oder Lizenzen, die hierunter gewährt werden, freiwillig, gesetzlich oder anderweitig ohne unsere vorherige schriftliche Zustimmung abzutreten, jedoch können diese Vereinbarung und die im Rahmen dieser Vereinbarung eingeräumten Rechte und Pflichten von Sampler auf jegliche Weise übertragen oder abgetreten werden.
<G-vec00291-002-s112><assign.abtreten><en> 14.5 The Contract is personal to the Customer, who shall not assign or in any way part with the benefit without the Company s prior written consent.
<G-vec00291-002-s112><assign.abtreten><de> 14.2 Der Käufer ist nicht berechtigt, den Vertrag oder einen Bestandteil davon ohne vorherige schriftliche Genehmigung seitens des Unternehmens abzutreten.
<G-vec00291-002-s113><assign.abtreten><en> You may not assign the Agreement or any part of it, nor transfer or sub-license your rights under the Agreement, to any third party
<G-vec00291-002-s113><assign.abtreten><de> Sie sind nicht berechtigt, den Vertrag oder einen Teil davon abzutreten oder Ihre Rechte aus dem Vertrag an Dritte zu übertragen oder Dritten eine Lizenz einzuräumen.
<G-vec00291-002-s114><assign.abtreten><en> We may assign these Terms at any time without notice or consent, to the fullest extent permitted under applicable law.
<G-vec00291-002-s114><assign.abtreten><de> Wir sind berechtigt, die vorliegenden Bedingungen, so weit, wie dies nach geltendem Recht zulässig ist, jederzeit ohne Vorankündigung und ohne Ihre Zustimmung abzutreten.
<G-vec00291-002-s115><assign.abtreten><en> Notwithstanding any other provision in this Agreement, you may not assign or transfer this Agreement or your Number or allow others to use your Number.
<G-vec00291-002-s115><assign.abtreten><de> Unbeschadet der sonstigen Bestimmungen dieser Vereinbarung sind Sie nicht berechtigt, diese Vereinbarung oder Ihre Nummer abzutreten, zu übertragen oder anderen zu erlauben, Ihre Nummer zu nutzen.
<G-vec00291-002-s116><assign.abtreten><en> 14.1 The Supplier may not assign the Supplier’s claims against the Customer without the Customer’s consent.
<G-vec00291-002-s116><assign.abtreten><de> 14.1 Der Auftragnehmer ist nicht berechtigt, seine Forderungen gegen den Auftraggeber ohne dessen Zustimmung abzutreten.
<G-vec00291-002-s118><assign.abtreten><en> Client may not assign its rights or obligations under this Agreement in whole or in part to any third party without the prior written consent of Tradedoubler, such consent not to be unreasonably withheld.
<G-vec00291-002-s118><assign.abtreten><de> Der Kunde ist nicht berechtigt, seine Rechte oder Verpflichtungen ganz oder teilweise an Dritte abzutreten, ohne zuvor die schriftliche Zustimmung von Tradedoubler einzuholen.
<G-vec00291-002-s119><assign.abtreten><en> The Customer shall not assign, transfer, pledge or otherwise dispose of any rights or obligations pertaining to the use of this Service to a third party.
<G-vec00291-002-s119><assign.abtreten><de> Der Kunde ist nicht berechtigt, Rechte oder Pflichten bezüglich der Nutzung dieses Dienstes an Dritte abzutreten, zu übertragen, zu verpfänden oder anderweitig zu veräußern.
<G-vec00291-002-s120><assign.abtreten><en> You may not assign this contract, or any part of it, to any other person or party without our prior written consent, which will not be unreasonably withheld.
<G-vec00291-002-s120><assign.abtreten><de> Sie sind nicht berechtigt, diesen Vertrag oder Teile davon ohne unsere vorherige schriftliche Zustimmung, die nicht ohne triftigen Grund verweigert wird, an andere Personen oder Parteien abzutreten.
<G-vec00291-002-s095><assign.beauftragen><en> The local administration offices should assign specific persons to monitor each of those who are on the list.
<G-vec00291-002-s095><assign.beauftragen><de> Die lokalen Leitungsbehörden sollten spezielle Personen beauftragen, um jeden, der auf der Liste steht, zu überwachen.
<G-vec00291-002-s096><assign.beauftragen><en> Fortunately, in Burger Bustle: Ellie’s Organics you can easily hire a worker and assign him to whatever task you’d like and you are also allowed to drag them to a new level if you’d like them there.
<G-vec00291-002-s096><assign.beauftragen><de> Zum Glück, in „Burger Bustle: Ellie’s Organics” kann man einfach einen Arbeiter einstellen und ihn mit einer beliebigen Aufgabe beauftragen und dabei kann man auch sie zum nächsten Level bringen, wenn man sie da möchte.
<G-vec00291-002-s097><assign.beauftragen><en> Furthermore you have the possibility to assign us with the tyre storage.
<G-vec00291-002-s097><assign.beauftragen><de> Darüber hinaus haben Sie hier die Möglichkeit, die Reifeneinlagerung zu beauftragen.
<G-vec00291-002-s098><assign.beauftragen><en> The bishop may assign one of his counselors to coordinate this effort by meeting regularly with a counselor from the elders quorum and Relief Society—a group like this constitutes a young single adult committee (see Handbook 2: 16.3.4).
<G-vec00291-002-s098><assign.beauftragen><de> Der Bischof kann einen seiner Ratgeber beauftragen, diese Bemühungen mit einem Ratgeber in der Ältestenkollegiumspräsidentschaft und einer Ratgeberin in der FHV-Leitung abzusprechen – diese drei bilden dann ein JAE-Komitee (siehe Handbuch 2, 16.3.4).
<G-vec00291-002-s099><assign.beauftragen><en> Long Beach Records Europe is authorised to assign third person to accomplish applications(subcontractor).
<G-vec00291-002-s099><assign.beauftragen><de> LBRE ist berechtigt, für die Erfüllung des Auftrags Dritte zu beauftragen (Subunternehmer).
<G-vec00291-002-s100><assign.beauftragen><en> The hotelkit GmbH is allowed, within the scope of HOTELKIT, to assign third parties with the processing of data; those shall not be considered contracting partners of the customer.
<G-vec00291-002-s100><assign.beauftragen><de> Die hotelkit GmbH ist berechtigt, im Rahmen von HOTELKIT auch Dritte mit der Verarbeitung von Daten zu beauftragen; diese werden nicht Vertragspartner des Kunden.
<G-vec00291-002-s101><assign.beauftragen><en> Concerned one in a proceeding for assessing fines one mediates therein how they can defend without an attorney to assign itself - within limited framework - even.
<G-vec00291-002-s101><assign.beauftragen><de> Betroffenen in einem Bußgeldverfahren wird darin vermittelt, wie sie sich ohne einen Rechtsanwalt zu beauftragen - in beschränktem Rahmen - selbst verteidigen können.
<G-vec00291-002-s102><assign.beauftragen><en> Once the details of your order are confirmed, we assign a top international logistics company to perform the service and you can follow online the transit of your parcel.
<G-vec00291-002-s102><assign.beauftragen><de> Sobald die Einzelheiten Ihrer Bestellung bestätigt sind, beauftragen wir eines der besten internationalen Logistikunternehmen mit der Durchführung des Service.
<G-vec00291-002-s103><assign.beauftragen><en> DBM We assign our craftsmen/ partners directly or create a convenient offer for you.
<G-vec00291-002-s103><assign.beauftragen><de> DBM Wir beauftragen unsere Handwerker/Partner direkt oder erstellen Ihnen ein passendes Angebot.
<G-vec00291-002-s104><assign.beauftragen><en> If you are unable to regularly check on your boat yourself, you should assign someone else to do it.
<G-vec00291-002-s104><assign.beauftragen><de> Wenn Sie nicht selbst regelmäßig nach dem Rechten sehen können, sollten Sie jemanden anderen damit beauftragen.
<G-vec00291-002-s105><assign.beauftragen><en> Our future vision is that, as China further ascends onto the world stage, it will be more and more important to service Chinese clients and brands in Europe and beyond.” Ms. Sassi-Bucsit also points out that one of today’s trends is that more clients prefer to assign a full-service agency rather than a travel agency to their outbound events, which leads to more impactful experiences for guests.
<G-vec00291-002-s105><assign.beauftragen><de> Unsere Vision für die Zukunft ist es, parallel zu Chinas Aufstieg auf der Weltbühne chinesischen Kunden und Marken in Europa und darüber hinaus überzeugende Lösungen anzubieten.“Katja Sassi-Bucsit weist auch darauf hin, dass immer mehr Kunden es vorziehen, eher eine Full-Service-Agentur als ein Reisebüro für ihre Outbound-Events zu beauftragen, um den Erlebnischarakter für die Gäste zu erhöhen.
<G-vec00291-002-s106><assign.beauftragen><en> We assign a dedicated project partner to manage the events work and build the team you need.
<G-vec00291-002-s106><assign.beauftragen><de> SINGLE PARTNER Wir beauftragen einen einzigen Partner, um das Management zu erleichtern und das Team aufzubauen, das Sie benötigen.
<G-vec00291-002-s107><assign.beauftragen><en> The MIT researchers wanted to perform a more controlled study in which they could randomly assign children to receive music lessons or not, and then measure the effects.
<G-vec00291-002-s107><assign.beauftragen><de> Die MIT-Forscher wollten eine kontrolliertere Studie durchführen, in der sie Kinder nach dem Zufallsprinzip mit Musikunterricht beauftragen oder nicht, und dann die Auswirkungen messen konnten.
<G-vec00291-002-s108><assign.beauftragen><en> Some clients assign us also their production in the South of France and Portugal.
<G-vec00291-002-s108><assign.beauftragen><de> Manche Kunden beauftragen uns auch mit Produktionen in Südfrankreich und Portugal.
<G-vec00291-002-s109><assign.beauftragen><en> You can assign the task of purchasing the insurance to us and we will insure each individual shipment for you.
<G-vec00291-002-s109><assign.beauftragen><de> Mit dem Eindecken der Transportversicherung können Sie uns beauftragen, wir versichern dann jede einzelne Sendung für Sie.
<G-vec00291-002-s140><assign.geben><en> Assign a passphrase and you're ready to go. Drag & Drop
<G-vec00291-002-s140><assign.geben><de> Geben Sie dem Tresor ein Passwort – und schon kann es losgehen.
<G-vec00291-002-s141><assign.geben><en> 35 9:24 They said to Joshua, “It was carefully reported to your subjects 36 how the Lord your God commanded Moses his servant to assign you the whole land and to destroy all who live in the land from before you. Because of you we were terrified 37 we would lose our lives, so we did this thing.
<G-vec00291-002-s141><assign.geben><de> 24Und sie antworteten Josua und sprachen: Weil deinen Knechten für gewiß berichtet wurde, daß Jehova, dein Gott, Mose, seinem Knechte, geboten hat, euch das ganze Land zu geben und alle Bewohner des Landes vor euch zu vertilgen, so fürchteten wir sehr für unser Leben euretwegen und taten diese Sache.
<G-vec00291-002-s142><assign.geben><en> The list's author noted, "We consider the claims from the Guardians of the Islamic Revolution as the most credible one received so far," but the analysis concluded, "We cannot assign responsibility for this tragedy to any terrorist group at this time.
<G-vec00291-002-s142><assign.geben><de> Am Ende dieser Liste vermerkte der Autor: „Wir erachten bislang das Bekennen der ‚Beschützer der islamischen Revolution‘ als das glaubwürdigste.“ Abschließend schreibt er: „Bis jetzt können wir die Verantwortung für diese Tragödie keiner Gruppe geben.
<G-vec00291-002-s143><assign.geben><en> In particular, the intelligent control over voice commands or touchpads will make it easier for people to assign the machine new tasks (70 percent).
<G-vec00291-002-s143><assign.geben><de> Insbesondere die intelligente Steuerung über Sprachbefehle oder Touchpads wird es Menschen leichter machen, der Maschine neue Aufgaben zu geben (70 Prozent).
<G-vec00291-002-s144><assign.geben><en> Finally, press the SAVE button and assign a suitable development class, or, if no transport to other R/3 systems is planned, declare it as a local object.
<G-vec00291-002-s144><assign.geben><de> Zum Schluß drücken Sie den Sichern Button und geben eine passende Entwicklungsklasse an, oder, wenn kein Transport in andere R/3 Systeme geplant sind, geben Sie es als lokales Objekt an.
<G-vec00291-002-s145><assign.geben><en> Ten per cent assign grades five and six (assessment according to the German school grading system) to their Jobcenter in this question.
<G-vec00291-002-s145><assign.geben><de> Zehn Prozent geben ihrem Jobcenter bei dieser Frage die Noten fünf und sechs (bewertet wird im Schulnotensystem).
<G-vec00291-002-s146><assign.geben><en> Film Finances, Inc. and Film Finances (1998) Canada will also assign their claims against the insolvent film producers Franchise Pictures and against subsidiaries of Franchise to the estate, hence withdrawing from the list of creditors.
<G-vec00291-002-s146><assign.geben><de> Zudem geben Film Finances, Inc. und Film Finances (1998) Canda ihre Ansprüchen gegen den insolventen Filmproduzenten Franchise Pictures und gegen Tochtergesellschaften von Franchise zugunsten der Insolvenzmasse ab und scheiden damit aus dem Gläubigerausschuss aus.
<G-vec00291-002-s147><assign.geben><en> 73 percent assume that AI makes it easier for people to assign the machine new tasks - for example, via voice command or touchpad.
<G-vec00291-002-s147><assign.geben><de> 73 Prozent gehen davon aus, dass KI es den Menschen erleichtert, der Maschine neue Aufgaben zu geben – beispielsweise via Sprachbefehl oder Touchpad.
<G-vec00291-002-s148><assign.geben><en> At our request, the Customer shall immediately inform his customers of such assignment and furnish us with the documents needed to collect the claims. In no case is the Customer authorized to assign the claims.
<G-vec00291-002-s148><assign.geben><de> Auf unser Verlangen ist er verpflichtet, seine Abnehmer sofort von der Abtretung an uns zu unterrichten - sofern wir das nicht selbst tun - und uns die zur Einziehung erforderlichen Auskünfte und Unterlagen zu geben.
<G-vec00291-002-s149><assign.geben><en> To use your own settings for a modern, clean film effect and to assign your own color tinting and mood, select the preset "Film (Manual Settings)".
<G-vec00291-002-s149><assign.geben><de> Um Ihre eigenen Einstellungen für einen neuen unbeschädigten Filmlook zu verwenden und dem Film einen individuellen Farbstich zu geben wählen Sie die Voreinstellung "Film (eigene Einstellung)".
<G-vec00291-002-s150><assign.geben><en> 2/ Your inventory allows you to find all the items you bought and to assign them to your dogs.
<G-vec00291-002-s150><assign.geben><de> 2/ Ihr Inventar erlaubt Ihnen alle Gegenstände die Sie gekauft haben zu finden und sie Ihren Hunden zu geben.
<G-vec00291-002-s151><assign.geben><en> The two artists did not start out from theories and it was not until much later that they consented to assign a meaning to the word "cubist".
<G-vec00291-002-s151><assign.geben><de> Die beiden Künstler sind nicht von Theorien ausgegangen und waren erst sehr viel später bereit, dem Wort "Kubismus" einen Sinn zu geben.
<G-vec00291-002-s152><assign.geben><en> And to ensure that the induction period runs smoothly after they start, we assign each new employee a mentor who looks after them and is on hand to answer their questions.
<G-vec00291-002-s152><assign.geben><de> Und damit die Einarbeitung nach dem Start leicht gelingt, geben wir jedem Neuen einen Paten, der ihn betreut und bei Fragen da ist.
<G-vec00291-002-s222><assign.ordnen><en> If you are logged onto Facebook during this process, Facebook will assign this information to your personal Facebook user account.
<G-vec00291-002-s222><assign.ordnen><de> Sind Sie dabei als Mitglied bei Facebook eingeloggt, ordnet Facebook diese Information Ihrem persönlichen Facebook-Benutzerkonto zu.
<G-vec00291-002-s224><assign.ordnen><en> If the Facebook ID contained in a Facebook cookie can be assigned to a Facebook user, then Facebook will assign this user to a target group ("Custom Audience") according to the rules we have defined, provided that the rules are relevant.
<G-vec00291-002-s224><assign.ordnen><de> Kann eine Zuordnung der im Facebook-Cookie enthaltenen Facebook-ID zu einem Facebook-Nutzer vorgenommen werden, ordnet Facebook diesem Nutzer anhand der von uns festgelegten Regeln einer Zielgruppe („Custom Audience“) zu, sofern die Regeln einschlägig sind.
<G-vec00291-002-s225><assign.ordnen><en> It uses automated character recognition to assign your basic data to the right form fields.
<G-vec00291-002-s225><assign.ordnen><de> Dabei ordnet unsere automatische Erkennung Ihre Stammdaten den richtigen Formularfeldern zu.
<G-vec00291-002-s226><assign.ordnen><en> If you are logged in to Facebook when you visit our site, Facebook will use the information collected by the component to identify the specific pages you are visiting and will assign this information to your personal Facebook account.
<G-vec00291-002-s226><assign.ordnen><de> Wenn Sie unsere Seite aufrufen und währenddessen bei Facebook eingeloggt sind, erkennt Facebook durch die von der Komponente gesammelte Information, welche konkrete Seite Sie besuchen und ordnet diese Informationen Ihrem persönlichen Account auf Facebook zu.
<G-vec00291-002-s227><assign.ordnen><en> If the data subject clicks on one of the Google+ buttons integrated on our website and thereby makes a Google+1 recommendation, Google will assign this information to the personal Google+ user account of the data subject and store this personal data.
<G-vec00291-002-s227><assign.ordnen><de> Betätigt die betroffene Person einen der auf unserer Internetseite integrierten Google+-Buttons und gibt damit eine Google+1 Empfehlung ab, ordnet Google diese Information dem persönlichen Google+-Benutzerkonto der betroffenen Person zu und speichert diese personenbezogenen Daten.
<G-vec00291-002-s228><assign.ordnen><en> If you are logged in as a member of Facebook, Facebook will assign this information to your personal user account.
<G-vec00291-002-s228><assign.ordnen><de> Sind Sie dabei als Mitglied bei Facebook eingeloggt, ordnet Facebook diese Information Ihrem persönlichen Benutzerkonto zu.
<G-vec00291-002-s230><assign.ordnen><en> This means that it no longer matters to the controller at the control centre what specific logger a communication was recorded on: via the web interface he is able to access all recordings from practically anywhere, play them back, analyse and search them, link them with other information, assign them to categories or give them attributes.
<G-vec00291-002-s230><assign.ordnen><de> Das bedeutet, dass es für den Disponenten auf der Leitstelle keine Rolle mehr spielt, auf welchem konkreten Logger eine Kommunikation aufgezeichnet wurde: Über das Web-Interface greift er von praktisch überall aus auf sämtliche Aufzeichnungen zu, spielt sie ab, analysiert und recherchiert sie, verknüpft sie mit weiteren Informationen, ordnet sie Kategorien zu oder attribuiert sie.
<G-vec00291-002-s238><assign.setzen><en> In case you are unable to assign a password to your user account using this form, contact your course administration or send an e-mail to ilias@studium.kit.edu.
<G-vec00291-002-s238><assign.setzen><de> Falls Sie mit dieser Funktion Ihr Passwort nicht setzen können, aber über einen lokalen ILIAS-Account verfügen, benachrichtigen Sie bitte Ihre Kursleitung oder senden Sie ein E-Mail an ilias@studium.kit.edu.
<G-vec00291-002-s239><assign.setzen><en> One could be forgiven, then, for assuming that a good CEO is little more than an omnipotent puppeteer, pulling the strings to assign the right people to the right projects.
<G-vec00291-002-s239><assign.setzen><de> Gute Führung braucht geschützte Räume Man könnte meinen, ein guter CEO sei nicht mehr als ein mächtiger Strippenzieher – lediglich damit beschäftigt, die geeigneten Leute auf die richtigen Projekte zu setzen.
<G-vec00291-002-s240><assign.setzen><en> (b) We may assign this Agreement at any time without your prior consent provided that such assignment does not affect the Services.
<G-vec00291-002-s240><assign.setzen><de> (b) Wir setzen diese Vereinbarung möglicherweise ohne Ihr Einverständnis in Kraft, falls eine solche Vereinbarung die Dienstleistungen nicht beeinträchtigt.
<G-vec00291-002-s241><assign.setzen><en> Regardless of which sector you work in, we assign translators who have the relevant experience and expert knowledge so that you can rest assured that your translated document will be interpreted correctly.
<G-vec00291-002-s241><assign.setzen><de> Übersetzen Egal, in welcher Branche Sie sich bewegen: wir setzen immer die Übersetzer mit der passenden einschlägigen Erfahrung und Spezialisierung ein.
<G-vec00291-002-s242><assign.setzen><en> In case you are unable to assign a password to your user account using this form, contact your course administration or send an e-mail to [email protected].
<G-vec00291-002-s242><assign.setzen><de> Falls Sie mit dieser Funktion Ihr Passwort nicht setzen können, benachrichtigen Sie bitte Ihre Kursleitung oder senden Sie ein E-Mail an [email protected].
<G-vec00291-002-s243><assign.setzen><en> For complex, demanding projects, we assign experienced project managers who apply professional, systematic methods.
<G-vec00291-002-s243><assign.setzen><de> Für anspruchsvolle Projekte greifen wir auf professionelle Projektmethodik zurück und setzen erfahrene Projektleiter ein.
<G-vec00291-002-s244><assign.setzen><en> In their hierarchy of these values, we are to assign practicality of law to common welfare at the lowest position.
<G-vec00291-002-s244><assign.setzen><de> In der Rangordnung dieser Werte haben wir die Zweckmäßigkeit des Rechts für das Gemeinwohl an die letzte Stelle zu setzen.
<G-vec00291-002-s276><assign.treten><en> You may resell the reserved goods in the ordinary course of business; you assign to us in advance all claims arising from this resale – irrespective of any combination or mixing of the reserved goods with a new item – in the amount of the invoice amount, and we accept this assignment.
<G-vec00291-002-s276><assign.treten><de> Sie dürfen die Vorbehaltsware im ordentlichen Geschäftsbetrieb weiterveräußern; sämtliche aus diesem Weiterverkauf entstehenden Forderungen treten Sie – unabhängig von einer Verbindung oder Vermischung der Vorbehaltsware mit einer neuen Sache – in Höhe des Rechnungsbetrages an uns im Voraus ab, und wir nehmen diese Abtretung an.
<G-vec00291-002-s277><assign.treten><en> You assign to us all right, title and interest in and to the Customer Input and agree to provide us with any assistance we may require to document, perfect and maintain our rights in the Customer Input.
<G-vec00291-002-s277><assign.treten><de> Sie treten an uns alle Rechte, Titel und Interessen an den Kundenanregungen ab und stimmen zu, uns jede Unterstützung zu gewähren, die wir für die Dokumentation, Vervollkommnung der Kundenanregungen und Sicherung unserer Rechte an diesen benötigen.
<G-vec00291-002-s278><assign.treten><en> After successful address and credit check and submission of the order, we assign our claim to PayPal.
<G-vec00291-002-s278><assign.treten><de> Nach erfolgreicher Adress- und Bonitätsprüfung und Abgabe der Bestellung treten wir unsere Forderung an PayPal ab.
<G-vec00291-002-s279><assign.treten><en> For this purpose, you assign to us fiduciary all claims that belong to you according to the Passenger Regulation, including any secondary financial claims.
<G-vec00291-002-s279><assign.treten><de> Hierzu treten Sie sämtliche Ihnen zustehende Ansprüche aus der Fluggast-Verordnung einschließlich Nebenforderungen treuhänderisch an uns ab.
<G-vec00291-002-s280><assign.treten><en> You are permitted to sell on reserved goods in the ordinary business operation; you shall assign all claims arising from this onward sale – regardless of connecting or mixing of the reserved goods with a new item – in the amount of the invoice amount to us in advance, and we accept this assignment.
<G-vec00291-002-s280><assign.treten><de> Sie dürfen die Vorbehaltsware im ordentlichen Geschäftsbetrieb weiterveräußern; sämtliche aus diesem Weiterverkauf entstehenden Forderungen treten Sie – unabhängig von einer Verbindung oder Vermischung der Vorbehaltsware mit einer neuen Sache - in Höhe des Rechnungsbetrages an uns im Voraus ab, und wir nehmen diese Abtretung an.
<G-vec00291-002-s282><assign.treten><en> In this case, you already now assign to us all claims in the amount of the invoice amount that accrue to you from the resale, we accept the assignment.
<G-vec00291-002-s282><assign.treten><de> Für diesen Fall treten Sie bereits jetzt alle Forderungen in Höhe des Rechnungsbetrages, die Ihnen aus dem Weiterverkauf erwachsen, an uns ab, wir nehmen die Abtretung an.
<G-vec00291-002-s283><assign.treten><en> In this case, you automatically assign your claims in this regard against the hotel to HRS.
<G-vec00291-002-s283><assign.treten><de> Für diesen Fall treten Sie automatisch Ihre diesbezüglichen Ansprüche gegen das Hotel an HRS ab.
<G-vec00291-002-s312><assign.vergeben><en> The user and IT are immediately informed of the incident and the user is requested to assign a new, secure password.
<G-vec00291-002-s312><assign.vergeben><de> Der Nutzer und die IT werden umgehend über den Vorfall informiert und der Nutzer zur Vergabe eines neuen, sicheren Passworts aufgefordert.
<G-vec00291-002-s313><assign.vergeben><en> It is also popular to assign special tasks spontaneously – past all the installed chain of command.
<G-vec00291-002-s313><assign.vergeben><de> Beliebt ist die spontane Vergabe von Sonderaufgaben – vorbei an den installierten Dienstwegen.
<G-vec00291-002-s314><assign.vergeben><en> Admin Password Displays the current status of your system setup program's password security feature and allows you to verify and assign a new admin password.
<G-vec00291-002-s314><assign.vergeben><de> Zeigt den derzeitigen Status der Systemkennwortfunktion des System-Setup-Programms an und ermöglicht die Bestätigung und Vergabe eines neuen Administrator-Kennworts.
<G-vec00291-002-s315><assign.vergeben><en> Ask your network administrator which settings are required to manually assign an IP address.
<G-vec00291-002-s315><assign.vergeben><de> Erkundigen Sie sich beim Errichter Ihres Netzwerkes, welche Einstellungen bei der manuellen Vergabe von IP-Adressen notwendig sind.
<G-vec00291-002-s316><assign.vergeben><en> Place a foldable element directly at the edge of the browser - for instance to assign a coupon code.
<G-vec00291-002-s316><assign.vergeben><de> Platzieren Sie ein aufklappbares Element direkt am Browserrand – beispielsweise zur Vergabe eines Gutscheincodes.
<G-vec00291-002-s317><assign.vergeben><en> Here, too, you can assign an ePIC Persistent Identifier and thus link to publications and internal processes and documentation.
<G-vec00291-002-s317><assign.vergeben><de> Auch hier ist die Vergabe eines ePIC Persistent Identifier und damit die Verknüpfung zu Publikationen und internen Prozessen und Dokumentationen möglich.
<G-vec00291-002-s318><assign.vergeben><en> For this reason, it is necessary to register and assign a password.
<G-vec00291-002-s318><assign.vergeben><de> Aus diesem Grund ist eine Anmeldung und Vergabe eines Passwortes nötig.
<G-vec00291-002-s319><assign.vergeben><en> To assign several serial numbers, the serial numbers can be suggested from the serial number master files.
<G-vec00291-002-s319><assign.vergeben><de> Zur Vergabe mehrerer Seriennummern können die Seriennummern aus dem Seriennummernstamm vorgeschlagen werden.
<G-vec00291-002-s371><assign.weisen><en> Based on these discussions, they assign visiting teachers to each sister in the ward.
<G-vec00291-002-s371><assign.weisen><de> Aufgrund dieser Besprechungen weisen die Führungsbeamten wenn möglich jedem Haushalt ein Heimlehrpaar zu.
<G-vec00291-002-s372><assign.weisen><en> Users assign colors to the alphabet according to their own feeling.
<G-vec00291-002-s372><assign.weisen><de> Benutzer weisen dem Alphabet nach eigener Empfindung Farben zu.
<G-vec00291-002-s373><assign.weisen><en> Using various rating methodologies, the analysts assess the credit profile of and the outlook for each issuer and subsequently assign them a credit rating.
<G-vec00291-002-s373><assign.weisen><de> Mithilfe standardisierter Ratingmethodik beurteilen die Analysten das Kreditprofil und den Ausblick für jeden Emittenten und weisen diesem anschließend ein Kreditrating zu.
<G-vec00291-002-s374><assign.weisen><en> Assign your customers and prospective customers to specific sales tours, automatically create appointments and visit reports and assess your tours.
<G-vec00291-002-s374><assign.weisen><de> Weisen Sie Kunden und Interessenten bestimmte Vertriebstouren zu, lassen Sie sich automatisch Termine und Besuchsberichte erzeugen und werten Sie Ihre Touren aus.
<G-vec00291-002-s375><assign.weisen><en> The switches assign the CV input of each section individually either to the duration parameter or the shape parameter.
<G-vec00291-002-s375><assign.weisen><de> Die Schalter weisen den CV-Eingang jeder Sektion separat entweder auf den Parameter Duration oder Parameter Shape zu.
<G-vec00291-002-s376><assign.weisen><en> We assign our expert orders to the most appropriate IT expert to obtain the best results.
<G-vec00291-002-s376><assign.weisen><de> Wir weisen unsere Gutachtenaufträge dem am besten geeigneten IT-Sachverständigen zu, um ein optimales Ergebnis zu erhalten.
<G-vec00291-002-s377><assign.weisen><en> You may choose any number of strategies that correspond exactly to your needs and assign them to individual products or entire product groups.
<G-vec00291-002-s377><assign.weisen><de> Legen Sie beliebig viele Strategien an, die genau Ihren Bedürfnissen entsprechen und weisen Sie diese einzelnen Produkten oder ganzen Produktgruppen zu.
<G-vec00291-002-s378><assign.weisen><en> After signing contracts, prison guards assign work to each and every cell to fulfill these large contracts.
<G-vec00291-002-s378><assign.weisen><de> Nach Abschluss der Verträge weisen Gefängniswärter allen in jeder Zelle die Arbeitsmenge zu.
<G-vec00291-002-s379><assign.weisen><en> Our staff will check you in, assign you a parking space and help you transfer your luggage to the shuttle bus.
<G-vec00291-002-s379><assign.weisen><de> Unsere Mitarbeiter checken dich ein, weisen dir einen Parkplatz zu, helfen dir mit dem Umladen deines Gepäcks in den Shuttlebus.
<G-vec00291-002-s380><assign.weisen><en> Assign a Responsible Team but do not assign a Confirmation Team and do not attach any QA Checklist
<G-vec00291-002-s380><assign.weisen><de> Weisen Sie ein verantwortliches Team zu, aber weisen Sie kein prüfendes Team zu und hängen Sie keine QA-Checkliste an.
<G-vec00291-002-s381><assign.weisen><en> To let them move one after the other, you assign different postponements for the fixtures and their position will shift as the illustration above shows.
<G-vec00291-002-s381><assign.weisen><de> Um Sie nun hintereinander zu setzen weisen Sie Ihnen verschiedene Phasenverschiebungen zu und die Position der Scanner verschiebt sich nach obigem Bild.
<G-vec00291-002-s382><assign.weisen><en> We assign a project manager who performs this otherwise time-consuming task for you.
<G-vec00291-002-s382><assign.weisen><de> Diese Aufgabe weisen wir einem Projektmanager zu, der diese ansonsten recht zeitraubende Arbeit übernimmt.
<G-vec00291-002-s383><assign.weisen><en> Using this input field you assign the user an individual VLAN ID.
<G-vec00291-002-s383><assign.weisen><de> Über dieses Eingabefeld weisen Sie dem Benutzer eine individuelle VLAN-ID zu.
<G-vec00291-002-s384><assign.weisen><en> Assign never-busy local or toll-free fax numbers directly to users
<G-vec00291-002-s384><assign.weisen><de> Weisen Sie persönliche lokale und gebührenfreie Faxnummern Benutzern direkt zu.
<G-vec00291-002-s385><assign.weisen><en> We stop the recording and give a name to it and assign a shortcut.
<G-vec00291-002-s385><assign.weisen><de> Wir stoppen die Aufnahme, geben ihr einen Namen und weisen ihr einer Taste zu.
<G-vec00291-002-s386><assign.weisen><en> Skills-Based Routing Automatically assign tickets to the right agents based on their skills, presence and workload.
<G-vec00291-002-s386><assign.weisen><de> Weisen Sie Tickets automatisch den richtigen Kundenserviceagenten zu – basierend auf Fertigkeiten, Anwesenheit und Arbeitspensum –, damit Ihre Kunden sofort Hilfe erhalten und Ihre Agenten nicht überlastet sind.
<G-vec00291-002-s387><assign.weisen><en> If you are selected for our program, we’ll work with you to understand your interests and assign you to a case that aligns with your personal and professional goals.
<G-vec00291-002-s387><assign.weisen><de> Wenn Sie für unser Praktikantenprogramm ausgewählt werden, setzen wir uns mit Ihnen zusammen und weisen Sie einem Fall zu, der zu Ihren Interessen und zu Ihren beruflichen Zielen passt.
<G-vec00291-002-s388><assign.weisen><en> Many Catholic investigators even at the present time assign the book to the reign of Solomon; the masterly poetic form points to this brilliant period of Hebrew poetry.
<G-vec00291-002-s388><assign.weisen><de> Viele katholische Ermittler auch in der heutigen Zeit weisen auf das Buch der Herrschaft von Salomo, der meisterhaft poetischen Form zeigt auf dieses brillanten Zeitraum von hebräischen Poesie.
<G-vec00291-002-s389><assign.weisen><en> Track your leads in a CRM tool and assign them the right source and generated revenue.
<G-vec00291-002-s389><assign.weisen><de> Verfolgen Sie Ihre Leads in einem CRM-Tool und weisen Sie ihnen die richtige Quelle und den erzielten Umsatz zu.
<G-vec00291-002-s524><assign.zuordnen><en> By using Fences you can create groups of icons just selecting them and assign them an area in the desktop.
<G-vec00291-002-s524><assign.zuordnen><de> Mit Fences lassen sich Icons gruppieren, indem man sie einfach auswählt und sie einem Bereich im Desktop zuordnet.
<G-vec00291-002-s525><assign.zuordnen><en> A “cookie” is a small piece of information that a website assign to your device while you are viewing a website.
<G-vec00291-002-s525><assign.zuordnen><de> „Cookies“ sind kleine Datensätze, die eine Website Ihrem Gerät zuordnet, wenn Sie die Website besuchen.
<G-vec00291-002-s526><assign.zuordnen><en> If you do not want Twitter to immediately assign the data collected via our website to your Twitter account, you must log out of Twitter before you visit our website.
<G-vec00291-002-s526><assign.zuordnen><de> Wenn Sie nicht möchten, dass Twitter die über unseren Webauftritt gesammelten Daten unmittelbar Ihrem Twitter-Account zuordnet, müssen Sie sich vor Ihrem Besucht unserer Webseite bei Twitter ausloggen.
<G-vec00291-002-s527><assign.zuordnen><en> If you do not want Twitter to collect data via our website and immediately assign it to your profile on Twitter, you must log off from your Twitter account before you visit our website.
<G-vec00291-002-s527><assign.zuordnen><de> Wenn Sie nicht möchten, dass Instagram die über unseren Webauftritt gesammelten Daten unmittelbar Ihrem Instagram-Account zuordnet, müssen Sie sich vor Ihrem Besuch unserer Website bei Instagram ausloggen.
<G-vec00291-002-s528><assign.zuordnen><en> If you do not wish Google to assign all the information regarding your visit to our web-site directly to your Google Plus profile, you must log out from Google Plus before visiting our web-site.
<G-vec00291-002-s528><assign.zuordnen><de> Wenn Sie nicht möchten, dass Google die über Ihren Besuch unserer Webseite gesammelten Informationen unmittelbar Ihrem Profil auf Google Plus zuordnet, müssen Sie sich vor Ihrem Besuch unserer Website bei Google Plus ausloggen.
<G-vec00291-002-s529><assign.zuordnen><en> If you do not want Twitter to collect data via our website directly and assign your Twitter account, you must log out of Twitter before you visit our website.
<G-vec00291-002-s529><assign.zuordnen><de> Wenn Sie nicht möchten, dass Twitter die über unseren Webauftritt gesammelten Daten unmittelbar Ihrem Twitter-Account zuordnet, müssen Sie sich vor Ihrem Besuch unserer Website bei Twitter ausloggen.
<G-vec00291-002-s530><assign.zuordnen><en> If you do not want the social networks to assign the data collected via our website directly to your profile in the respective service, you must log out of the corresponding service before you visit our website.
<G-vec00291-002-s530><assign.zuordnen><de> Wenn Sie nicht möchten, dass Facebook die über unseren Webauftritt gesammelten Daten unmittelbar Ihrem Facebook-Profil zuordnet, müssen Sie sich vor Ihrem Besuch unserer Website bei Facebook ausloggen.
<G-vec00291-002-s551><assign.zuteilen><en> The same Contracting Party may not assign the same number to another type of grouped, combined or reciprocally incorporated lamps covered by this Regulation.
<G-vec00291-002-s551><assign.zuteilen><de> Dieselbe Vertragspartei darf dieselbe Nummer einem anderen Typ von zusammengebauten, kombinierten oder ineinander gebauten Leuchten, für den diese Regelung gilt, nicht mehr zuteilen.
<G-vec00291-002-s552><assign.zuteilen><en> Now you can assign one or multiple roles.
<G-vec00291-002-s552><assign.zuteilen><de> Jetzt können Sie eine oder mehrere Rollen zuteilen.
<G-vec00291-002-s553><assign.zuteilen><en> If you would like to construct accessible pages or would simply like to bring more transparency to your layout structure, you can assign a Role to the element.
<G-vec00291-002-s553><assign.zuteilen><de> Wenn Sie barrierefreie Seiten aufbauen wollen oder einfach mehr Transparenz in Ihren Layoutaufbau bringen möchten, können Sie dem Element hier eine Rolle zuteilen.
<G-vec00291-002-s555><assign.zuteilen><en> We’ll organize a welcome meeting and you will take a test of written and oral French in the morning to assess your language level and assign you to a class.
<G-vec00291-002-s555><assign.zuteilen><de> Um 14.00 Uhr legen Sie einen schriftlichen und einen mündlichen Test ab, anhand dessen wir Ihr Sprachniveau ermitteln und Sie einer passenden Klasse zuteilen können.
<G-vec00291-002-s556><assign.zuteilen><en> For example, you can assign each sales representative 100 new identification values.
<G-vec00291-002-s556><assign.zuteilen><de> Sie können zum Beispiel jedem Verkäufer 100 neue Identifizierungswerte zuteilen.
<G-vec00291-002-s557><assign.zuteilen><en> If one were to assign a perfect location for its headquarters to the prestigious Italian fittings manufacturer Fantini – it would be right there.
<G-vec00291-002-s557><assign.zuteilen><de> Pella Würde man dem prestigeträchtigen italienischen Armaturenhersteller Fantini einen Ort zuteilen, an dem sich sein Hauptsitz befinden müsste – er wäre genau hier.
<G-vec00291-002-s558><assign.zuteilen><en> When you book, you can specify your specific wishes, and according to availability we will assign you the pitch that suits you most.
<G-vec00291-002-s558><assign.zuteilen><de> Bei Ihrer Reservierung können Sie Ihre Erwartungen und Wünsche angeben, je nach Verfügbarkeit, werden wir Ihnen den Stellplatz, der Ihren Bedürfnissen am besten entspricht zuteilen.
<G-vec00291-002-s559><assign.zuteilen><en> The Mary Glasgow Language Lab is a place where you can assign Learning units to your students and assess their progress.
<G-vec00291-002-s559><assign.zuteilen><de> Im Mary Glasgow-Language Lab können Sie Ihren Schülern Lerneinheiten zuteilen und ihre Fortschritte prüfen.
<G-vec00291-002-s579><assign.zuweisen><en> How to assign licenses is described in the next section, Assign Licenses to Registered Products.
<G-vec00291-002-s579><assign.zuweisen><de> Wie man eine Lizenz zuweist, ist im nächsten Abschnitt Zuweisen von Lizenzen zu registrierten Produkten beschrieben.
<G-vec00291-002-s580><assign.zuweisen><en> Make sure you still assign pods however, and that no one, except the current tank, stands in front of the bosses.
<G-vec00291-002-s580><assign.zuweisen><de> Stellt jedoch sicher, dass ihr immer noch die Pods zuweist und dass niemand, außer dem aktuellen Tank, vor den Bossen steht.
<G-vec00291-002-s581><assign.zuweisen><en> A "cookie" (also "tracking cookie," "browser cookie," and "HTTP cookie") is a small piece of text stored on a user's computer by a web browser that assign a unique identifier to your computer so that iSLCollective can "recognize" your computer each time you use it to return to the iSLCollective website.
<G-vec00291-002-s581><assign.zuweisen><de> Ein "Cookie" (auch "Tracking-Cookie", "Browser-Cookie" und "HTTP-Cookie") ist ein kurzer Textteil, der von einem Web-Browser auf dem Computer eines Benutzers gespeichert wird, der Ihrem Computer eine eindeutige Kennung zuweist, so dass iSLCollective Ihr Computer jedes Mal „erkennt“, wenn Sie es dazu benutzen, zur iSLCollective Webseite zurückzukehren.
<G-vec00291-002-s582><assign.zuweisen><en> Most editors will ask you what topics you are interested in writing about, or if you have a unique angle on a certain topic or issues before they assign story ideas.
<G-vec00291-002-s582><assign.zuweisen><de> Bevor dir jemand einen Artikel zuweist, wird dich dein Redakteur aber fragen, welche Themen dich besonders interessieren oder welche Meinung du zu bestimmten Themen hast.
<G-vec00291-002-s583><assign.zuweisen><en> And, when you are assigning rooms to a reservation in the room rack, you can expand the comments to make sure that you assign your guests the room that best fits their needs.
<G-vec00291-002-s583><assign.zuweisen><de> Und wenn du einer Reservierung im Zimmerplan einen Raum zuordnest, kannst du die Kommentare aufklappen und sicherstellen, dass du deinen Gästen den Raum zuweist, der ihren Bedürfnissen am besten entspricht.
<G-vec00291-002-s584><assign.zuweisen><en> If you opt for a fine dining restaurant, you should pay attention to proper attire and wait for the waiter to assign you a table.
<G-vec00291-002-s584><assign.zuweisen><de> Wenn Sie sich für ein Restaurant der gehobenen Gastronomie entscheiden, sollten Sie auf angemessene Kleidung achten und warten, bis der Kellner Ihnen einen Tisch zuweist.
<G-vec00291-002-s585><assign.zuweisen><en> Here, the DHCP server will be configured to always assign the same address to the gateway.
<G-vec00291-002-s585><assign.zuweisen><de> In diesem Fall konfigurieren Sie den DHCP-Server so, dass er dem Gateway stets die gleiche Adresse zuweist.
<G-vec00291-002-s643><assign.übertragen><en> 11.12 A client may not assign any rights pursuant to this article.
<G-vec00291-002-s643><assign.übertragen><de> 11.12 Der Abnehmer kann die Rechte kraft dieses Artikels nicht übertragen.
<G-vec00291-002-s644><assign.übertragen><en> For all Services commissioned by AMPLEXOR, the Supplier undertakes to assign to AMPLEXOR any copyright to which he may lay claim.
<G-vec00291-002-s644><assign.übertragen><de> Für alle von AMPLEXOR beauftragten Dienstleistungen verpflichtet sich der Lieferant, AMPLEXOR alle Urheberrechte zu übertragen, die er geltend machen könnte.
<G-vec00291-002-s646><assign.übertragen><en> You may not assign this Agreement or any rights, obligations, or privileges under this Agreement without YapStone’s prior written consent and such consent will not be unreasonably withheld.
<G-vec00291-002-s646><assign.übertragen><de> Sie dürfen diesen Vertrag oder jegliche Rechte, Verpflichtungen oder Vorrechte gemäß diesem Vertrag ohne die vorherige schriftliche Zustimmung von YapStone nicht übertragen, und jene Zustimmung wird nicht unangemessen zurückgehalten werden.
<G-vec00291-002-s647><assign.übertragen><en> You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; TGC may assign its rights under this Agreement without condition.
<G-vec00291-002-s647><assign.übertragen><de> Du kannst deine Rechte gemäß dieser Vereinbarung auf eine Partei übertragen, die sich mit ihren Geschäftsbedingungen einverstanden erklärt und bestätigt, dass sie sich an die Geschäftsbedingungen halten wird; Automattic kann seine Rechte gemäß der Vereinbarung bedingungslos übertragen.
<G-vec00291-002-s648><assign.übertragen><en> The Company may assign the contract or any part of it to any person, firm or Company.
<G-vec00291-002-s648><assign.übertragen><de> Die Gesellschaft kann den Vertrag oder einen Teil davon an eine Person, Firma oder Gesellschaft übertragen.
<G-vec00291-002-s649><assign.übertragen><en> It is equally possible to assign a mark for only part of the goods and services.
<G-vec00291-002-s649><assign.übertragen><de> Es ist auch möglich, eine Marke nur für einen Teil der Waren und Dienstleistungen zu übertragen.
<G-vec00291-002-s650><assign.übertragen><en> The Federal Council may also assign the vice president presidential powers.
<G-vec00291-002-s650><assign.übertragen><de> Der Bundesrat kann dem Vizepräsidenten präsidiale Befugnisse übertragen.
<G-vec00291-002-s651><assign.übertragen><en> You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; My Site may assign its rights under this Agreement without condition.
<G-vec00291-002-s651><assign.übertragen><de> Sie können Ihre Rechte aus dieser Vereinbarung an Dritte übertragen, die diesen Bedingungen und Konditionen zustimmen; JOBfoundation kann seine Rechte aufgrund dieser Vereinbarung ohne Bedingungen abtreten.
<G-vec00291-002-s652><assign.übertragen><en> In addition, either Party may, with notice but without needing the other Party’s consent assign its rights and delegate its obligations under this Agreement to an entity to which it transfers substantially all of its assets relating to this Agreement.
<G-vec00291-002-s652><assign.übertragen><de> Zusätzlich darf jede Partei bei Mitteilung an die andere Partei, jedoch auch ohne Zustimmung der anderen Partei, ihre Rechte und Verpflichtungen aus diesem Vertrag einem Rechtssubjekt übertragen, dem sie im Wesentlichen alle ihre Vermögenswerte, die sich auf diesen Vertrag beziehen, überträgt.
<G-vec00291-002-s653><assign.übertragen><en> We may transfer, assign, or delegate these Terms and our rights and obligations without consent.
<G-vec00291-002-s653><assign.übertragen><de> Classcraft kann diese Vereinbarung und die Rechte und Verpflichtungen von Classcraft ohne Ihre Zustimmung übereignen, übertragen oder delegieren.
<G-vec00291-002-s655><assign.übertragen><en> The CN is however entitled to assign the contract to a corporate affiliate without the consent of the CL.
<G-vec00291-002-s655><assign.übertragen><de> Der AN ist berechtigt, den Vertrag auch ohne Zustimmung des AG auf ein mit dem AN konzernrechtlich verbundenes Unternehmen zu übertragen.
<G-vec00291-002-s656><assign.übertragen><en> The Client cannot assign any rights under this article.
<G-vec00291-002-s656><assign.übertragen><de> Der Auftraggeber kann Rechte gemäß diesem Artikel nicht übertragen.
<G-vec00291-002-s657><assign.übertragen><en> In addition to directed training courses, we also assign them a high level of personal responsibility.
<G-vec00291-002-s657><assign.übertragen><de> Neben gezielten Schulungen wird ihnen auch viel Selbstverantwortung übertragen.
<G-vec00291-002-s658><assign.übertragen><en> (2) Nonetheless the Federal Minister entrusted with the administration of federal assets can assign the performance of such business to a Governor and the authorities subordinate to him.
<G-vec00291-002-s658><assign.übertragen><de> Die mit der Verwaltung des Bundesvermögens betrauten Bundesminister können jedoch die Besorgung solcher Geschäfte dem Landeshauptmann und den ihm unterstellten Behörden im Land übertragen.
<G-vec00291-002-s659><assign.übertragen><en> The WAVERLYFD is allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification.
<G-vec00291-002-s659><assign.übertragen><de> Eye Travel Excursions ist berechtigt, seine Rechte und / oder Pflichten unter diesen Bedingungen ohne Benachrichtigung zu übertragen, zu übertragen und zu vergeben.
<G-vec00291-002-s660><assign.übertragen><en> Tonybet reserves the right to assign this agreement, in whole or in part, at any time without notice.
<G-vec00291-002-s660><assign.übertragen><de> Tonybet behält sich das Recht vor, diese Vereinbarung vollständig oder teilweise zu jeder Zeit ohne Bekanntgabe zu übertragen.
<G-vec00291-002-s661><assign.übertragen><en> We could have chosen to assign an internal DPO, but because we wanted to be very transparent to the patients, practitioners and authorities, we chose to assign this role to an external impartial company that is specialized in data privacy and the evolution of the regulation.
<G-vec00291-002-s661><assign.übertragen><de> Wir hätten einen internen datenschutzbeauftragen wählen können, aber da wir für Patienten, Ärzte und Autoritäten sehr transparent sein wollten, haben wir uns entschieden, diese Rolle einem externen, unparteiischen Unternehmen zu übertragen, das auf Datenschutz und die Entwicklung der Verordnung spezialisiert ist.
<G-vec00074-002-s019><assign.abtreten><en> As a general rule, .de domains can be transferred. In other words, the existing domain holder can assign it to another prospective holder, who will then be entered as the new domain holder.
<G-vec00074-002-s019><assign.abtreten><de> Der Inhaberwechsel Grundsätzlich sind .de-Domains übertragbar, d. h. der Domaininhaber kann die Domain an einen anderen Interessenten abtreten, der dann als neuer Domaininhaber eingetragen wird.
<G-vec00074-002-s020><assign.abtreten><en> We may transfer, sell or assign any of the information described in this policy to third parties as a result of a sale, merger, consolidation, change of control, transfer of assets or reorganization of our business.
<G-vec00074-002-s020><assign.abtreten><de> Wir können die in dieser Richtlinie beschriebenen Informationen als Folge eines Verkaufs, einer Fusion, einer Zusammenlegung, einer Änderung der Kontrolle, einer Übertragung der Vermögenswerte oder einer Neuorganisation unseres Unternehmens an Dritte übertragen, verkaufen oder abtreten.
<G-vec00074-002-s021><assign.abtreten><en> k. EnergyCasino may assign this Agreement or any rights and/or obligations hereunder without the CLIENT’s consent.
<G-vec00074-002-s021><assign.abtreten><de> k. EnergyCasino kann diese Vereinbarung oder Rechte und/oder Verpflichtungen ohne Zustimmung des Kunden abtreten.
<G-vec00074-002-s022><assign.abtreten><en> Wizards may transfer or assign these Terms of Use, the Websites and the Services, in whole or in part, to third parties of our choosing.
<G-vec00074-002-s022><assign.abtreten><de> Wizards kann diese WPN-Nutzungsbedingungen ganz oder teilweise an Dritte seiner Wahl übertragen oder abtreten.
<G-vec00074-002-s023><assign.abtreten><en> The beneficiary of the letter of credit can assign (cede) the credit proceeds entirely or in part to a third party.
<G-vec00074-002-s023><assign.abtreten><de> Der Akkreditivbegünstigte kann den Akkreditiverlös ganz oder teilweise an eine Drittpartei abtreten (zedieren).
<G-vec00074-002-s024><assign.abtreten><en> In the case of infringements caused by products supplied by us or other manufacturers, we shall assert claims, at our own discretion, against manufacturers or primary suppliers for the account of the customer or assign them to the customer.
<G-vec00074-002-s024><assign.abtreten><de> (3) Bei Rechtsverletzungen durch von uns gelieferte Produkte anderer Hersteller werden wir nach unserer Wahl unsere Ansprüche gegen die Hersteller und Vorlieferanten für Rechnung des Auftraggebers geltend machen oder an den Auftraggeber abtreten.
<G-vec00074-002-s026><assign.abtreten><en> You may assign your rights under this Agreement to any party that consents to, and agrees to be bound by, its terms and conditions; My Site may assign its rights under this Agreement without condition.
<G-vec00074-002-s026><assign.abtreten><de> Sie können Ihre Rechte aus dieser Vereinbarung an Dritte übertragen, die diesen Bedingungen und Konditionen zustimmen; JOBfoundation kann seine Rechte aufgrund dieser Vereinbarung ohne Bedingungen abtreten.
<G-vec00074-002-s027><assign.abtreten><en> We may assign or transfer any rights, obligations or privileges that we have under this Agreement to an Affiliate.
<G-vec00074-002-s027><assign.abtreten><de> Wir dürfen Ansprüche, Rechte oder Pflichten, die wir gemäß der vorliegenden Vereinbarung haben, an ein verbundenes Unternehmen abtreten oder übertragen.
<G-vec00074-002-s028><assign.abtreten><en> 10.3 Unless UB Software LTD has given you specific written permission to do so, you may not assign (or grant a sub-license of) your rights to use the Software, grant a security interest in or over your rights to use the Software, or otherwise transfer any part of your rights to use the Software.
<G-vec00074-002-s028><assign.abtreten><de> 10.3 Sofern Sie nicht von kino-toni.de eine entsprechende schriftliche Erlaubnis erhalten haben, dürfen Sie Ihre Nutzungsrechte an der Software nicht abtreten (oder eine Unterlizenz erteilen), ein Sicherungsrecht an Ihren Nutzungsrechten der Software bestellen oder Ihre Nutzungsrechte an der Software anderweitig ganz oder teilweise übertragen.
<G-vec00074-002-s029><assign.abtreten><en> If a customer is given the option to pay for certain orders on account (following a successful credit check), the payment is processed in cooperation with Billpay GmbH, to whom we assign our payment claim.
<G-vec00074-002-s029><assign.abtreten><de> Wenn Ihnen für bestimmte Angebote nach Prüfung der Bonität der Kauf auf Rechnung gestattet wird, erfolgt die Abwicklung der Zahlung in Zusammenarbeit mit der Billpay GmbH, an die wir unsere Zahlungsforderung abtreten.
<G-vec00074-002-s030><assign.abtreten><en> You may not assign or transfer or purport to assign or transfer any of Your rights or obligations under this Agreement without first having obtained PGi’s prior written consent.
<G-vec00074-002-s030><assign.abtreten><de> Sie dürfen Ihre Rechte oder Pflichten aus diesem Vertrag nicht abtreten oder übertragen oder dies behaupten, ohne zuvor die schriftliche Zustimmung von PGi einzuholen.
<G-vec00074-002-s031><assign.abtreten><en> 9.1 TFC may transfer, assign, charge, sub-contract or otherwise dispose of this Licence, or any of our rights or obligations arising under it, at any time during the term of this Licence.
<G-vec00074-002-s031><assign.abtreten><de> 9.1 TFC kann diese Lizenz oder irgendwelche unserer Rechte oder Pflichten, die sich daraus ergeben, jederzeit während der Laufzeit dieser Lizenz übertragen, abtreten, subvertraglich oder anderweitig veräußern.
<G-vec00074-002-s032><assign.abtreten><en> BSC may assign its rights and duties under these Terms without such assignment being considered a change to the Terms and without notice to you.
<G-vec00074-002-s032><assign.abtreten><de> BSC kann seine Rechte und Pflichten im Rahmen dieser Nutzungsbedingungen abtreten, ohne dass diese Abtretung eine Änderung der Nutzungsbedingungen darstellt und ohne Sie davon in Kenntnis zu setzen.
<G-vec00074-002-s033><assign.abtreten><en> You may not assign your agreement with the company.
<G-vec00074-002-s033><assign.abtreten><de> Du darfst deine Vereinbarung mit dem Betreiber nicht abtreten.
<G-vec00074-002-s034><assign.abtreten><en> To the extent permitted by applicable law, Napster may assign this Agreement as it deems appropriate for any reason at any time.
<G-vec00074-002-s034><assign.abtreten><de> In gesetzlich zulässigem Ausmaß kann Napster diese Vereinbarung abtreten, wenn Napster dies zu jedweder Zeit aus irgendeinem Grund als angemessen erachtet.
<G-vec00074-002-s035><assign.abtreten><en> If a successful credit assessment has been carried out and the direct debit purchase is made available, the payment process will be handled in cooperation with Billpay GmbH, to which we will assign the payment claim.
<G-vec00074-002-s035><assign.abtreten><de> Wenn dem Kunden für bestimmte Angebote nach Prüfung der Bonität der Kauf per Lastschrift gestattet wird, erfolgt die Abwicklung der Zahlung in Zusammenarbeit mit der Billpay GmbH, an die wir unsere Zahlungsforderung abtreten.
<G-vec00074-002-s036><assign.abtreten><en> You may not assign or sub-contract any of your rights or obligations under these General Terms and Conditions of Sale to any third party unless we agree in writing.
<G-vec00074-002-s036><assign.abtreten><de> Wenn in Schriftform nicht anders festgelegt, dürfen Sie Ihre Rechte unter diesen allgemeinen Geschäftsbedingungen nicht an eine dritte Partei abtreten und nicht an einen Subunternehmer vergeben.
<G-vec00074-002-s037><assign.abtreten><en> The customer is not entitled to assign claims against us.
<G-vec00074-002-s037><assign.abtreten><de> Der Besteller kann Ansprüche gegen uns nicht abtreten.
<G-vec00074-002-s057><assign.abtreten><en> 3.10 We are entitled to assign receivables resulting from our business.
<G-vec00074-002-s057><assign.abtreten><de> Wir sind berechtigt, die Ansprüche aus unserer Geschäftsverbindung abzutreten.
<G-vec00074-002-s058><assign.abtreten><en> (3) We are entitled to assign to third parties the claims resulting from the business association, in particular our payment claims.
<G-vec00074-002-s058><assign.abtreten><de> (3) Wir sind berechtigt, die Ansprüche aus der Geschäftsbeziehung, insbesondere unsere Zahlungsansprüche, an Dritte abzutreten.
<G-vec00074-002-s059><assign.abtreten><en> Generally, the supplier shall be entitled to assign its claims.
<G-vec00074-002-s059><assign.abtreten><de> Der Lieferer ist prinzipiell berechtigt, seine Forderungen abzutreten.
<G-vec00074-002-s060><assign.abtreten><en> As a consequence, the purchaser expressly undertakes not to sell, assign, pledge and generally alienate the goods subject to the agreement prior to clearance of his/her/its account.
<G-vec00074-002-s060><assign.abtreten><de> Infolgedessen ist es dem Käufer ausdrücklich untersagt, die Güter, welche Gegenstand des Vertrags sind, zu verkaufen, abzutreten, zu verpfänden oder sonstwie zu veräußern, bevor das Konto ausgeglichen ist.
<G-vec00074-002-s061><assign.abtreten><en> RenderX grants you a personal, non-transferable and non-exclusive right and license to use the object code of its Software on a single computer; provided that you do not (and do not allow any third party to) copy, modify, create a derivative work of, reverse engineer, reverse assemble or otherwise attempt to discover any source code, sell, assign, sublicense, grant a security interest in or otherwise transfer any right in the Software.
<G-vec00074-002-s061><assign.abtreten><de> UPPAbaby gewährt Ihnen ein persönliches, nicht übertragbares und nicht ausschließliches Recht und eine Lizenz zur Nutzung des Service und der Software auf einem einzigen Computer; vorausgesetzt, dass Sie nicht (und nicht zulassen, dass Dritte) kopieren, modifizieren, eine abgeleitete Arbeit erstellen, Reverse Engineering, Reverse Assembly oder auf andere Weise versuchen, Quellcode zu entdecken, zu verkaufen, abzutreten, Unterlizenzen zu erteilen, eine Sicherheitsleistung zu gewähren oder übertragen Sie anderweitig ein Recht in der Software.
<G-vec00074-002-s062><assign.abtreten><en> Moreover, the operator is entitled to assign operational, development or support services to third parties in part or in full at any time with or without giving reasons.
<G-vec00074-002-s062><assign.abtreten><de> Der Betreiber ist zudem jederzeit berechtigt, Betriebs-, Entwicklungs- und Supportdienstleistungen mit oder ohne Angabe von Gründen ganz oder teilweise an Dritte abzutreten.
<G-vec00074-002-s063><assign.abtreten><en> In the event that all or part of our assets are sold or acquired by another party, or in the event of a merger, you grant us the right to assign the Personal and Non-Personal Information collected via the Site.
<G-vec00074-002-s063><assign.abtreten><de> Falls alle oder ein Teil unserer Vermögenswerte verkauft oder von einer anderen Partei erworben werden oder im Falle einer Fusion gewähren Sie uns das Recht, die im Rahmen der Dienste erhobenen personenbezogenen und nicht-personenbezogenen Daten abzutreten.
<G-vec00074-002-s064><assign.abtreten><en> The User is expressly prohibited to copy, modify, improve, edit, translate, de-compile, create a similar service, reverse engineer, disassemble or otherwise attempt to discover the target code (except as provided by law), sell, assign, sub-license or transfer in any way any part of the Site or of the Services without the prior written consent of ClicRDV.
<G-vec00074-002-s064><assign.abtreten><de> Dem Benutzer ist es ausdrücklich untersagt, den Zielcode zu kopieren, zu ändern, zu verbessern, zu bearbeiten, zu übersetzen, zu dekompilieren, einen ähnlichen Dienst einzurichten, zurück zu entwickeln, zu zerlegen oder anderweitig auszuspüren (es sei denn dies ist gesetzlich vorgesehen), zu verkaufen, abzutreten, zu unterlizenzieren oder einen Teil der Website oder des Service ohne vorherige schriftliche Zustimmung seitens ClicRDV irgendwie abzutreten.
<G-vec00074-002-s065><assign.abtreten><en> 19.2 You may not transfer, assign, charge or otherwise dispose of the Contract, or any of your rights or obligations arising under it, without our prior written consent.
<G-vec00074-002-s065><assign.abtreten><de> Sie sind nicht berechtigt, ohne unsere vorherige schriftliche Zustimmung einen Vertrag oder irgendwelche Ihrer Rechte oder Pflichten im Rahmen eines solchen Vertrages zu übertragen, abzutreten, zu belasten oder anderweitig darüber zu verfügen.
<G-vec00074-002-s066><assign.abtreten><en> You may not rent, lease, sublicense, assign, or transfer your rights in the Software, or authorize all or any portion of the Software to be copied onto another user's Device except as may be expressly permitted by this agreement.
<G-vec00074-002-s066><assign.abtreten><de> Mit Ausnahme der in diesem Vertrag ausdrücklich erlaubten Fälle sind Sie nicht berechtigt, die Rechte an der SOFTWARE zu vermieten, zu verleihen, zu verkaufen, unterzulizenzieren, abzutreten oder zu übertragen oder das Kopieren der SOFTWARE in Teilen oder als Ganzes auf den COMPUTER eines anderen Benutzers zu genehmigen.
<G-vec00074-002-s068><assign.abtreten><en> ICE IP may assign its rights and duties under this Terms of Use to any party at any time without notice to you. WATCHES ICE
<G-vec00074-002-s068><assign.abtreten><de> ICE IP hat das Recht, die aus den vorliegenden Nutzungsbedingungen erwachsenden Rechte und Pflichten jederzeit ohne Ankündigung an eine beliebige Drittpartei abzutreten.
<G-vec00074-002-s070><assign.abtreten><en> 8.3.1 Customer may not: (1) copy (save for making a back up copy), adapt, licence, sell, assign, sublicense, or otherwise transfer or encumber the Software; (2) use the Software in a managed services arrangement; or (3) use the Software in excess of the authorised number of licensed seats for concurrent users, sites, or other criteria specified in the applicable Service Documents.
<G-vec00074-002-s070><assign.abtreten><de> 8.3.1 Dem Kunden ist es untersagt: (1) die Software zu kopieren (ausgenommen sind Sicherungskopien), zu adaptieren, zu lizenzieren, zu verkaufen, abzutreten, zu unterlizenzieren oder sonst wie zu übertragen oder zu belasten; (2) die Software in einem Managed Services Arrangement zu benutzen, oder (3) die Software an mehr als der zugelassenen Anzahl lizenzierter Arbeitsplätze für Simultanbenutzer, Standorte oder sonstigen in den betreffenden Servicedokumenten vorgegebenen Kriterien zu benutzen.
<G-vec00074-002-s071><assign.abtreten><en> The sole duty of Infinigate shall be to assign its own warranty claims against the producer/supplier to the Contractual Partner.
<G-vec00074-002-s071><assign.abtreten><de> Die einzige Pflicht von Infinigate besteht darin, allfällige eigene Gewährleistungsansprüche gegen den Hersteller/Lieferanten an den Vertragspartnern abzutreten.
<G-vec00074-002-s072><assign.abtreten><en> The supplier is not authorized to assign claims from the contractual relation to third parties without our prior written consent.
<G-vec00074-002-s072><assign.abtreten><de> Der Lieferant ist nicht berechtigt, ohne vorherige schriftliche Einwilligung von uns, Forderungen aus dem Vertragsverhältnis an Dritte abzutreten.
<G-vec00074-002-s073><assign.abtreten><en> 5.7 We are entitled to assign receivables from our business transactions.
<G-vec00074-002-s073><assign.abtreten><de> 5.7 Wir sind berechtigt, die Ansprüche aus unseren Geschäftsverbindungen abzutreten.
<G-vec00074-002-s074><assign.abtreten><en> 2.1.6 You shall not access all or any part of the Services in order to: (i) build a product or service which competes with the Services; (ii) sell or use the Services and/or related documentation to provide services to third parties; or (iii) license, sell, rent, lease, transfer, assign, distribute, display, disclose, or otherwise commercially exploit, or otherwise make the Services available to any third party except, in the case of Requestors, the Authorised Users.
<G-vec00074-002-s074><assign.abtreten><de> 2.1.6 Sie verpflichten sich, auf die Dienstleistungen ganz oder auf Teile davon nicht zuzugreifen, um: (i) ein Produkt oder eine Dienstleistung herzustellen, die mit den Dienstleistungen konkurrieren; (ii) die Dienstleistungen und/oder dazugehörigen Dokumente zu verkaufen oder dafür zu nutzen, um Dienstleistungen an Dritte zu erbringen; oder (iii) die Dienstleistungen zu lizenzieren, zu verkaufen, zu vermieten, zu leasen, abzutreten, zu verteilen, auszustellen, weiterzugeben oder anderweitig die Dienstleistungen an Dritte zur Verfügung zu stellen, außer im Falle von Anforderern an autorisierte Nutzer.
<G-vec00074-002-s075><assign.abtreten><en> c) Silicon Software has the right to assign claims from its business relations.
<G-vec00074-002-s075><assign.abtreten><de> c) Silicon Software ist berechtigt die Ansprüche aus ihren Geschäftsverbindungen abzutreten.
<G-vec00074-002-s276><assign.abtreten><en> You may resell the reserved goods in the ordinary course of business; you assign to us in advance all claims arising from this resale – irrespective of any combination or mixing of the reserved goods with a new item – in the amount of the invoice amount, and we accept this assignment.
<G-vec00074-002-s276><assign.abtreten><de> Sie dürfen die Vorbehaltsware im ordentlichen Geschäftsbetrieb weiterveräußern; sämtliche aus diesem Weiterverkauf entstehenden Forderungen treten Sie – unabhängig von einer Verbindung oder Vermischung der Vorbehaltsware mit einer neuen Sache – in Höhe des Rechnungsbetrages an uns im Voraus ab, und wir nehmen diese Abtretung an.
<G-vec00074-002-s277><assign.abtreten><en> You assign to us all right, title and interest in and to the Customer Input and agree to provide us with any assistance we may require to document, perfect and maintain our rights in the Customer Input.
<G-vec00074-002-s277><assign.abtreten><de> Sie treten an uns alle Rechte, Titel und Interessen an den Kundenanregungen ab und stimmen zu, uns jede Unterstützung zu gewähren, die wir für die Dokumentation, Vervollkommnung der Kundenanregungen und Sicherung unserer Rechte an diesen benötigen.
<G-vec00074-002-s278><assign.abtreten><en> After successful address and credit check and submission of the order, we assign our claim to PayPal.
<G-vec00074-002-s278><assign.abtreten><de> Nach erfolgreicher Adress- und Bonitätsprüfung und Abgabe der Bestellung treten wir unsere Forderung an PayPal ab.
<G-vec00074-002-s279><assign.abtreten><en> For this purpose, you assign to us fiduciary all claims that belong to you according to the Passenger Regulation, including any secondary financial claims.
<G-vec00074-002-s279><assign.abtreten><de> Hierzu treten Sie sämtliche Ihnen zustehende Ansprüche aus der Fluggast-Verordnung einschließlich Nebenforderungen treuhänderisch an uns ab.
<G-vec00074-002-s280><assign.abtreten><en> You are permitted to sell on reserved goods in the ordinary business operation; you shall assign all claims arising from this onward sale – regardless of connecting or mixing of the reserved goods with a new item – in the amount of the invoice amount to us in advance, and we accept this assignment.
<G-vec00074-002-s280><assign.abtreten><de> Sie dürfen die Vorbehaltsware im ordentlichen Geschäftsbetrieb weiterveräußern; sämtliche aus diesem Weiterverkauf entstehenden Forderungen treten Sie – unabhängig von einer Verbindung oder Vermischung der Vorbehaltsware mit einer neuen Sache - in Höhe des Rechnungsbetrages an uns im Voraus ab, und wir nehmen diese Abtretung an.
<G-vec00074-002-s282><assign.abtreten><en> In this case, you already now assign to us all claims in the amount of the invoice amount that accrue to you from the resale, we accept the assignment.
<G-vec00074-002-s282><assign.abtreten><de> Für diesen Fall treten Sie bereits jetzt alle Forderungen in Höhe des Rechnungsbetrages, die Ihnen aus dem Weiterverkauf erwachsen, an uns ab, wir nehmen die Abtretung an.
<G-vec00074-002-s283><assign.abtreten><en> In this case, you automatically assign your claims in this regard against the hotel to HRS.
<G-vec00074-002-s283><assign.abtreten><de> Für diesen Fall treten Sie automatisch Ihre diesbezüglichen Ansprüche gegen das Hotel an HRS ab.
<G-vec00074-002-s284><assign.abtreten><en> 5.11 Should COMFOX AG be declared bankrupt, or file for bankruptcy protection, COMFOX AG shall assign to the customer the right to assert its claims directly against the third-party providers shown in the Offer/Individual Contract, to recover its data from the provider(s) or arrange to have it managed by another reseller.
<G-vec00074-002-s284><assign.abtreten><de> 5.11 Gerät COMFOX AG in Konkurs oder wird über COMFOX AG die Nachlassstundung beschlossen, so tritt hiermit COMFOX AG dem Kunden das Recht ab, bei den in der Offerte/Individualvertrag ausgewiesenen Drittanbietern direkt seine Ansprüche geltend zu machen, um seine Daten herauszuverlangen oder durch einen anderen Reseller betreuen zu lassen.
<G-vec00074-002-s285><assign.abtreten><en> (6) If the processing or treatment is carried out within the scope of a contract for work and services or a contract for work and materials, the customer/buyer shall also assign the pro-rata claim to work remuneration – corresponding to the value of the goods transferred by way of security – to us in advance.
<G-vec00074-002-s285><assign.abtreten><de> (6) Erfolgt die Be- oder Verarbeitung im Rahmen eines Werkvertrages oder Werklieferungsvertrages, tritt der Besteller an uns ebenfalls im voraus den anteiligen Werklohnanspruch, der dem Wert der sicherungsübereigneten Ware entspricht, ab.
<G-vec00074-002-s286><assign.abtreten><en> However, the customer will assign to Gira all claims for the amount of the relevant invoice value that the customer has incurred as a result of the resale of the goods to its own customer or to third parties.
<G-vec00074-002-s286><assign.abtreten><de> Er tritt jedoch an Gira alle Forderungen in Höhe des jeweiligen Fakturenwertes ab, die ihm aus der Weiterveräußerung gegen den Abnehmer oder gegen Dritte erwachsen.
<G-vec00074-002-s287><assign.abtreten><en> The customer shall assign his claims under the respective insurance policy and other claims on account of the loss or destruction of the goods subject to reservation of title to us here and now.
<G-vec00074-002-s287><assign.abtreten><de> Der Kunde tritt seine Ansprüche aus dem jeweiligen Versicherungsvertrag und andere Ansprüche wegen des Untergangs der Vorbehaltsware bereits jetzt an uns ab.
<G-vec00074-002-s288><assign.abtreten><en> (7) As security for our claims against the Customer, the Customer agrees to assign to us also any of its claims against third parties arising from the combination of any delivered items with any real estate property.
<G-vec00074-002-s288><assign.abtreten><de> (7) Der Besteller tritt uns auch die Forderungen zur Sicherung unserer Forderungen gegen ihn ab, die durch die Verbindung der Liefergegenstände mit einem Grundstück gegen einen Dritten erwachsen.
<G-vec00074-002-s289><assign.abtreten><en> (6) To secure the Seller's accounts against the Buyer, the latter shall also assign to the Seller such accounts accruing to the Buyer against third parties as a result of combining the goods subject to reservation of title with a property; the Seller hereby accepts this assignment here and now.
<G-vec00074-002-s289><assign.abtreten><de> (6) Zur Sicherung der Forderungen der Verkäuferin gegen den Käufer tritt dieser auch solche Forderungen an an die Verkäuferin ab, die ihm durch die Verbindung der Vorbehaltsware mit einem Grundstück gegen einen Dritten erwachsen; die Verkäuferin nimmt diese Abtretung schon jetzt an.
<G-vec00074-002-s290><assign.abtreten><en> If the retained goods are combined with land or moveable property, as a precaution the Purchaser shall assign the claims to which he is entitled as remuneration for the combining, along with all ancillary rights, to the Supplier without any special declarations being required later.
<G-vec00074-002-s290><assign.abtreten><de> Wird die Vorbehaltsware vom Besteller mit Grundstücken oder beweglichen Sachen verbunden, so tritt der Besteller seine Forderung die ihm als Vergütung für die Verbindung zusteht, mit allen Nebenrechten sicherungshalber an den Lieferer ab, ohne dass es weiterer besonderer Erklärungen bedarf.
<G-vec00074-002-s291><assign.abtreten><en> The purchaser shall assign any insurance claims to us.
<G-vec00074-002-s291><assign.abtreten><de> Der Besteller tritt alle eventuellen Versicherungsansprüche an uns ab.
<G-vec00074-002-s292><assign.abtreten><en> d) The purchaser shall hereby assign its claims arising from the resale of the reserved goods to the Vendor to the amount that corresponds to the value of the reserved goods.
<G-vec00074-002-s292><assign.abtreten><de> d) Der Käufer tritt seine Forderungen aus einem Weiterverkauf der Vorbehaltsware schon jetzt in dem Betrage an die Verkäuferin ab, der dem Wert der Vorbehaltsware entspricht.
<G-vec00074-002-s293><assign.abtreten><en> Where Retained Goods are resold together with other items, however, without contracting an individual price for such Retained Goods, the Purchaser will assign to the Supplier with preference to the remaining claims such a portion of the total price due which is equivalent to the price of the Retained Goods invoiced by the Supplier.
<G-vec00074-002-s293><assign.abtreten><de> Wird die Vorbehaltsware zusammen mit anderen Gegenständen weiter veräußert, ohne dass für die Vorbehaltsware ein Einzelpreis vereinbart wurde, so tritt der Besteller dem Lieferer mit Vorrang vor der übrigen Forderung denjenigen Teil der Gesamtpreisforderung ab, der dem vom Lieferer in Rechnung gestellten Preis der Vorbehaltsware entspricht.
<G-vec00074-002-s294><assign.abtreten><en> The Customer shall also assign to HERION the claims for securing HERION's claims which are due to the Customer against a third party by joining the delivery goods with a real property.
<G-vec00074-002-s294><assign.abtreten><de> Der Kunde tritt HERION auch die Forderungen zur Sicherung der Forderungen von HERION gegen ihn ab, die durch die Verbindung der Kaufsache mit einem Grundstück gegen einen Dritten erwachsen.
<G-vec00074-002-s295><assign.abtreten><en> In the event that Buyer has sold the claim as part of a genuine factoring transaction, Vendor’s claim shall become due immediately, and Buyer shall assign the claim against the factor to Vendor and promptly forward to Vendor the proceeds of the sale.
<G-vec00074-002-s295><assign.abtreten><de> Hat der Käufer die Forderung im Rahmen des echten Factorings verkauft, wird die Forderung des Verkäufers sofort fällig und der Käufer tritt die an ihre Stelle tretende Forderung gegen den Factor an den Verkäufer ab und leitet den Verkaufserlös unverzüglich an den Verkäufer weiter.
<G-vec00074-002-s296><assign.abtreten><en> If the customer sells the claim within the scope of a factoring transaction, he will herewith assign to us the substitute claim against the factor.
<G-vec00074-002-s296><assign.abtreten><de> Hat der Besteller diese Forderung im Rahmen des echten Factorings verkauft, so tritt er hiermit die an ihre Stelle tretende Forderung gegen den Factor an uns ab.
<G-vec00074-002-s297><assign.abtreten><en> 3.2 If goods subject to retention of title are processed and/or combined or mixed with other goods, the Buyer shall immediately assign any rights of property or co-property to the resulting goods to the Seller; this shall not result in any obligations on part of the Seller.
<G-vec00074-002-s297><assign.abtreten><de> 3.2 Wird die Vorbehaltsware vom Käufer be- oder verarbeitet oder mit anderen Waren verbunden oder vermischt, so tritt der Käufer schon jetzt seine Eigentums- oder Miteigentumsrechte an den neuen Gegenständen an den Verkäufer ab, ohne dass dem Verkäufer daraus Verpflichtungen entstehen.
<G-vec00074-002-s298><assign.abtreten><en> e) Where the Orderer combines the delivery item or the new item with parcels of land or movable property, he shall, in the interests of security, assign the claim to compensation, which he is entitled to for this combining, to the Contractor, including all ancillary rights, and without such requiring additional special declarations.
<G-vec00074-002-s298><assign.abtreten><de> e) Falls der Besteller den Liefergegenstand oder die neue Ware mit Grundstücken oder beweglichen Sachen verbindet, tritt er seine Vergütungsforderung, die für die Verbindung zusteht, einschließlich aller Nebenrechte an den Auftragnehmer sicherungshalber ab, und zwar ohne dass es weiterer besonderer Erklärungen bedürfte.
<G-vec00074-002-s299><assign.abtreten><en> The customer already agrees to assign to us any claims assigned to him from the resale and ancillary rights.
<G-vec00074-002-s299><assign.abtreten><de> Der Kunde tritt uns schon jetzt alle ihm aus der Weiterveräußerung zustehenden Forderungen mit Nebenrechten ab.
<G-vec00074-002-s300><assign.abtreten><en> They assign to us all claims against the buyer as a result of the resale to the full amount as collateral for their purchase price claim to us.
<G-vec00074-002-s300><assign.abtreten><de> Er tritt für den Fall des Weiterverkaufs hiermit alle daraus entstehenden Ansprüche gegen den Abnehmer in voller Höhe als Sicherheit für die Kaufpreisforderung an uns ab.
<G-vec00074-002-s301><assign.abtreten><en> 7) As surety for our claims against him, the customer shall also assign to us the claims arising to him against a third party from the joining of the purchased item with real estate.
<G-vec00074-002-s301><assign.abtreten><de> Der Besteller tritt uns im selben Umfang auch die Forderungen (einschließlich des Rechts auf Einräumung einer Sicherungshypothek) ab, die ihm durch die Verbindung der Kaufsache mit einem Grundstück gegen Dritte erwachsen.
<G-vec00074-002-s302><assign.abtreten><en> Purchaser shall be entitled to sell the object of supply on, as a due and proper business transaction; he shall, however, already assign to us, as of now, all claims in the amount of the gross sum of the invoice such as accrue to him from the further sale against his customer or against third parties, and, specifically, regardless of whether the object of supply has been sold without or after further processing.
<G-vec00074-002-s302><assign.abtreten><de> Der Käufer ist berechtigt, den Liefergegenstand im ordentlichen Geschäftsgang weiter zu verkaufen; er tritt uns jedoch bereits jetzt alle Forderungen in Höhe des Bruttorechnungsbetrages ab, die ihm aus der Weiterveräußerung gegen seine Abnehmer oder gegen Dritte erwachsen, und zwar unabhängig davon, ob der Liefergegenstand ohne oder nach Verarbeitung weiter verkauft worden ist.
<G-vec00074-002-s320><assign.vergeben><en> When performing manual (unscheduled) warehouse in postings, you can assign serial numbers to serialized parts if this has been defined in the settings in the serial number categories.
<G-vec00074-002-s320><assign.vergeben><de> Beim Durchführen von manuellen (ungeplanten) Lagerzugangsbuchungen können Sie für seriennummernführende Teile Seriennummern vergeben, sofern dies laut den Einstellungen in den Seriennummernarten vorgesehen ist.
<G-vec00074-002-s321><assign.vergeben><en> Once sent, you will receive an email with a link to assign a new password.
<G-vec00074-002-s321><assign.vergeben><de> Nach dem Absenden erhältst du eine E-Mail mit einem Link, um ein neues Passwort zu vergeben.
<G-vec00074-002-s322><assign.vergeben><en> The hotel has the right to assign rooms booked after 18:00 clock otherwise, without the guest to derive from this right or claim, unless other arrangements have been made or being a guest later arrival has not communicated in writing previously. 4.
<G-vec00074-002-s322><assign.vergeben><de> Das Hotel hat das Recht, gebuchte Zimmer nach 18.00 Uhr anderweitig zu vergeben, ohne dass der Gast hieraus Rechte oder Ansprüche herleiten kann, sofern keine abweichenden Vereinbarungen getroffen wurden oder der Gast sein späteres Eintreffen nicht schriftlich zuvor mitgeteilt hat.
<G-vec00074-002-s323><assign.vergeben><en> If the part of a part line is serialized, the serial number category defines whether you can assign the serial numbers during the document adoption.
<G-vec00074-002-s323><assign.vergeben><de> Wenn das Teil einer Teileposition seriennummernführend ist, dann bestimmt die Seriennummernart, ob Sie bei der Belegübernahme die Seriennummern vergeben können.
<G-vec00074-002-s324><assign.vergeben><en> On/Off Website analysis with Google Analytics: These cookies assign a randomly generated ID to your device, enabling us to recognize your device upon your next access.
<G-vec00074-002-s324><assign.vergeben><de> Diese Cookies ermöglichen es uns Ihre Nutzung dieser Website zu analysieren, indem wir Ihrem Gerät eine einzigartige, zufällig generierte ID vergeben, mit der wir Ihr Gerät bei Ihrem nächsten Besuch wiedererkennen.
<G-vec00074-002-s326><assign.vergeben><en> And if you want information about special evaluations, for example because you have variation evaluations during a manual annotation, but you are not sure which move evaluation symbol you want to assign, you can click on the button "complete analysis for one or two special engine evaluations" to see the result of the formula analysis.
<G-vec00074-002-s326><assign.vergeben><de> Und wenn man Informationen über spezielle Bewertungen wünschen sollte, weil man beispielsweise während einer Kommentierung per Hand über Variantenbewertungen verfügt, sich aber nicht sicher ist, welches Zugbewertungssymbol man vergeben möchte, kann man sich durch Klick auf den Schalter "komplette Analyse für ein oder zwei spezielle Engine-Bewertungen" das Resultat der Formelauswertungen zeigen lassen.
<G-vec00074-002-s327><assign.vergeben><en> For instance, it is now possible to create prospect campaigns that automatically assign tasks to sales reps, and that follow pre-defined contractual processes with partners and suppliers.
<G-vec00074-002-s327><assign.vergeben><de> So ist es jetzt möglich, Kampagnen für potenzielle Kunden auszurollen, die automatisch Aufgaben an den Vertrieb vergeben und die vordefinierte vertragliche Prozesse mit Partnern und Anbietern befolgen.
<G-vec00074-002-s328><assign.vergeben><en> Reason enough to assign key positions on this project to Wirtgen Group machines.
<G-vec00074-002-s328><assign.vergeben><de> Grund genug, die Schlüsselpositionen in diesem Projekt an Maschinen der Wirtgen Group zu vergeben.
<G-vec00074-002-s329><assign.vergeben><en> Only with this document can the respective registry office assign an appointment for the marriage.
<G-vec00074-002-s329><assign.vergeben><de> Erst mit diesem Dokument kann das jeweilige Standesamt einen Termin für die Heirat vergeben.
<G-vec00074-002-s330><assign.vergeben><en> If an assignment is refreshed, DHCP client requests the same parameters, but the DHCP server may assign a new IP address based on policies set by administrators.
<G-vec00074-002-s330><assign.vergeben><de> Bei der automatischen Zuordnung wird dem Client vom DHCP-Server auf Anfrage eine IP-Adresse vergeben, ohne dass die Mac-Adresse in der Konfiguration vermerkt sein muss.
<G-vec00074-002-s331><assign.vergeben><en> Change/Bug fix By entering a text field in the "Characteristics Properties" window, the user could assign the same stamp label to a characteristic if he was on a different drawing sheet.
<G-vec00074-002-s331><assign.vergeben><de> Änderung/Fehlerbehebung Per Textfeldeingabe im Fenster "Merkmaleigenschaften" konnte der Benutzer, wenn er sich auf einem anderen Zeichnungsblatt befand, die gleiche Stempelbeschriftung für ein Merkmal vergeben.
<G-vec00074-002-s332><assign.vergeben><en> We choose a mixed form for our example, assign letters for the individual subprojects and descending numbers for the levels.
<G-vec00074-002-s332><assign.vergeben><de> Wir wählen für unser Beispiel eine Mischform, vergeben Buchstaben für die einzelnen Teilprojekte und absteigende Nummern für die Ebenen.
<G-vec00074-002-s333><assign.vergeben><en> With the right classification attributes, you can assign the document type, the customer folder, the date, the responsibilities and much more information to the document, all of which can be edited at any time.
<G-vec00074-002-s333><assign.vergeben><de> Mit den richtigen Klassifizierungsattributen können Sie für jedes Dokument die Dokumentenart, den Kundenordner, das Datum, die Zuständigkeit und viele weitere Informationen vergeben, die bei Bedarf jederzeit bearbeitet werden können.
<G-vec00074-002-s334><assign.vergeben><en> If you do not manually assign the document number, the document number "0" is output when cash journal postings not yet posted are output.
<G-vec00074-002-s334><assign.vergeben><de> Wenn Sie die Belegnummer nicht manuell vergeben, dann wird beim Ausgeben der noch nicht gebuchten Kassenbuchungen die Belegnummer "0" ausgegeben.
<G-vec00074-002-s335><assign.vergeben><en> Website analysis with Google Analytics: These cookies assign a randomly generated ID to your device, enabling us to recognize your device upon your next access.
<G-vec00074-002-s335><assign.vergeben><de> Website-Analyse mit Google Analytics Diese Cookies vergeben Ihrem Gerät eine zufällig generierte ID, mit der wir Ihr Gerät bei Ihrem nächsten Besuch wiedererkennen.
<G-vec00074-002-s336><assign.vergeben><en> We do not assign or sell data from our customers or users.
<G-vec00074-002-s336><assign.vergeben><de> Wir vergeben oder verkaufen keine Daten unserer Kunden oder Nutzer.
<G-vec00074-002-s337><assign.vergeben><en> The owner can assign up to eight manager accounts for a single Deco network.
<G-vec00074-002-s337><assign.vergeben><de> Der Eigentümer kann bis zu acht Manager-Accounts für ein einzelnes Deco-Netzwerk vergeben.
<G-vec00074-002-s338><assign.vergeben><en> The grand majority of Internet connections offered per default by the ISPs, assign a dynamic IP to the users.
<G-vec00074-002-s338><assign.vergeben><de> Bei den meisten der Internetverbindungen vergeben die ISPs den Nutzern standardmäßig eine dynamische IP-Adresse.
<G-vec00074-002-s339><assign.vergeben><en> Assign an existing tag to the current item.
<G-vec00074-002-s339><assign.vergeben><de> Vergeben Sie ein existierendes Tag zum aktuellen Titel.
<G-vec00074-002-s340><assign.vergeben><en> Particularly convenient: assign permissions based on existing Active Directory user and security groups.
<G-vec00074-002-s340><assign.vergeben><de> Besonders komfortabel: Vergeben Sie Berechtigungen auf Basis der bestehenden Active Directory Benutzer- und Sicherheitsgruppen.
<G-vec00074-002-s341><assign.vergeben><en> Log tasks by employee and department, assign responsibilities and define the time allocated for completion.
<G-vec00074-002-s341><assign.vergeben><de> Erfassen Sie die Aufgaben nach Mitarbeitern und Abteilungen, vergeben Sie Verantwortlichkeiten und den Zeitaufwand.
<G-vec00074-002-s342><assign.vergeben><en> Optionally assign individual Keywords for this rule.
<G-vec00074-002-s342><assign.vergeben><de> Vergeben Sie optional individuelle Schlagwörter für diese Regel.
<G-vec00074-002-s343><assign.vergeben><en> Installing one of your customers is performed simply in only a single step: in WATO ➳ Customers select the New Customer button, and assign an explicit ID, as well as the name to be used when displaying it in Check_MK.
<G-vec00074-002-s343><assign.vergeben><de> Kunden anlegen Das Anlegen eines Ihrer Kunden erledigen Sie mit lediglich einem einzigen Schritt: Wählen Sie unter WATO ➳ Customers den Knopf New Customer aus und vergeben Sie dort eine eindeutige ID, sowie den Namen, wie er in Check_MK angezeigt werden soll.
<G-vec00074-002-s344><assign.vergeben><en> For this purpose, assign the "Archived" project status to the project.
<G-vec00074-002-s344><assign.vergeben><de> Dazu vergeben Sie dem Projekt den Projektstatus "archiviert".
<G-vec00074-002-s345><assign.vergeben><en> - Assign a ringtone directly to a contact;
<G-vec00074-002-s345><assign.vergeben><de> Vergeben Sie einen Klingelton direkt zu einem Kontakt.
<G-vec00074-002-s346><assign.vergeben><en> Create and assign different user access rights to your databases and models.
<G-vec00074-002-s346><assign.vergeben><de> Erstellen und vergeben Sie verschiedene Zugriffsrechte für Ihre Datenbanken und Modelle.
<G-vec00074-002-s347><assign.vergeben><en> Use the Browse symbol button to select the directory and assign a name to the wsAR file.
<G-vec00074-002-s347><assign.vergeben><de> Wählen Sie über die Durchsuchen-Symbolschaltfläche das Verzeichnis aus und vergeben Sie einen Namen für die wsAR-Datei.
<G-vec00074-002-s348><assign.vergeben><en> 1 Activate the action and assign a logical name.
<G-vec00074-002-s348><assign.vergeben><de> 1 Aktivieren Sie die Aktion und vergeben Sie einen sinnvollen Namen.
<G-vec00074-002-s349><assign.vergeben><en> Value When manually entering a CRO (including with the copy template), you manually assign a CRO number.
<G-vec00074-002-s349><assign.vergeben><de> Wert Bei der manuellen Erfassung (auch mit der Kopiervorlage) einer Kommission vergeben Sie eine entsprechende Kommissionsnummer manuell.
<G-vec00074-002-s350><assign.vergeben><en> Task Assignment: assign tasks to course participants or groups.
<G-vec00074-002-s350><assign.vergeben><de> Bereitstellung einer "Aufgabenstellung": Vergeben Sie Aufgaben an Ihre Kursteilnehmer oder Gruppen.
<G-vec00074-002-s351><assign.vergeben><en> To set this scene, drag the desired widgets into the designated area, assign a name, and save the scene.
<G-vec00074-002-s351><assign.vergeben><de> Um diese Szene einzurichten ziehen Sie die gewünschten Widgets in den dafür vorgesehenen Bereich, vergeben Sie einen Namen und speichern Sie die Szene ab.
<G-vec00074-002-s184><assign.zuordnen><en> Later, you use this abbreviation to assign the print mask to form templates and report views.
<G-vec00074-002-s184><assign.zuordnen><de> Anhand der Kurzbezeichnung ordnen Sie die Druckmaske später in Formularvorlagen und Listenansichten zu.
<G-vec00074-002-s185><assign.zuordnen><en> In the part master files, you assign commodity codes relevant to intra-EU trade statistics to the parts.
<G-vec00074-002-s185><assign.zuordnen><de> Im Teilestamm ordnen Sie den Teilen Warennummern zu, die für die Intrahandelsstatistik relevant sind.
<G-vec00074-002-s186><assign.zuordnen><en> In order for the field values to be converted according to the mappings during the replication, you have to assign the mappings to the corresponding fields in the replication structure.
<G-vec00074-002-s186><assign.zuordnen><de> Damit beim Replizieren die Feldwerte den Mappings entsprechend umgesetzt werden, ordnen Sie die Mappings in der Replikationsstruktur den betreffenden Feldern zu.
<G-vec00074-002-s187><assign.zuordnen><en> You assign a tax rate of "0%" to a tax code for tax-free business activities.
<G-vec00074-002-s187><assign.zuordnen><de> Einem Steuerschlüssel für steuerfreie Geschäftsvorgänge ordnen Sie einen Steuersatz von "0%" zu.
<G-vec00074-002-s188><assign.zuordnen><en> Value You assign a price list to a part by entering an unit price in the desired price list.
<G-vec00074-002-s188><assign.zuordnen><de> Wert Einem Teil ordnen Sie eine Preisliste zu, indem Sie in der gewünschten Preisliste einen Einzelpreis erfassen.
<G-vec00074-002-s189><assign.zuordnen><en> Under "Tools" you enter tools and machines and assign them an UnTouch Tool Tag.
<G-vec00074-002-s189><assign.zuordnen><de> Unter “Werkzeuge” erfassen Sie Werkzeuge und Maschinen und ordnen diesen einen UnTouch Werkzeugtag zu.
<G-vec00074-002-s190><assign.zuordnen><en> These great china bowls by Design Letters assign their owner and make seating arrangements unnecessary.
<G-vec00074-002-s190><assign.zuordnen><de> Diese tollen Porzellanschalen von Design Letters ordnen jede Schüssel seinem Eigentümer zu und machen Platzzuweisungen überflüssig.
<G-vec00074-002-s191><assign.zuordnen><en> Check the boxes “Use a custom block in model" and "Use a custom block in plan view”, and then assign them the 3D/2D blocks that you created
<G-vec00074-002-s191><assign.zuordnen><de> Aktivieren Sie die Kästchen „Benutzerdefinierten Block in Modellansicht verwenden“ und „Benutzerdefinierten Block in Draufsicht verwenden“ und ordnen Sie jedem die 3D-/2D-Blöcke zu, die Sie vorher erzeugt haben.
<G-vec00074-002-s192><assign.zuordnen><en> In this first example, we'll do just that, and then assign a list of our own User objects as the items source:
<G-vec00074-002-s192><assign.zuordnen><de> In diesem ersten Beispiel tun wir genau dies und ordnen dann eine Liste unseres eigenen User Objekts als Elementquelle zu.
<G-vec00074-002-s193><assign.zuordnen><en> For this purpose, you assign the desired categories to the drawing.
<G-vec00074-002-s193><assign.zuordnen><de> Dazu ordnen Sie der Zeichnung die gewünschten Kategorien zu.
<G-vec00074-002-s194><assign.zuordnen><en> In Configuration Management, you enter individual devices, furniture, equipment and software to form configurations and assign these to employees or customers.
<G-vec00074-002-s194><assign.zuordnen><de> Im Configuration Management fassen Sie einzelne Geräte, Möbel, Einrichtungs- und Ausrüstungsgegenstände sowie Software zu Konfigurationen zusammen und ordnen Sie Mitarbeitern oder Kunden zu.
<G-vec00074-002-s195><assign.zuordnen><en> The colourful corporate identity is present throughout the business concept of Park Inn Hotels: The Colourful Meetings assign each different kind of event to a colour – red for parties or product presentations, blue for business events, yellow for creativity and inspiration and green for health and wellness.
<G-vec00074-002-s195><assign.zuordnen><de> Die farbenfrohe Corporate Identity zieht sich auch durch das Businesskonzept der Park Inn Hotels: Die Colourful Meetings ordnen jeder Farbe eine Veranstaltungsart zu – rot für Partys oder Produkteinführungen, blau für geschäftliche Veranstaltungen, gelb für Kreativität und Insperation und grün für Gesundheit und Wellness.
<G-vec00074-002-s196><assign.zuordnen><en> App: When you download and install our App onto a mobile device, we assign a random number to your App installation.
<G-vec00074-002-s196><assign.zuordnen><de> App: Wenn Sie unsere App auf ein mobiles Gerät herunterladen und auf diesem installieren, ordnen wir Ihrer App-Installation eine Zufallszahl zu.
<G-vec00074-002-s197><assign.zuordnen><en> Assign this WLAN profile to the APs managed by the WLC.
<G-vec00074-002-s197><assign.zuordnen><de> Ordnen Sie das WLAN-Profil den vom WLC verwalteten APs zu.
<G-vec00074-002-s198><assign.zuordnen><en> You manually assign the status to the business partners whose bank has an indexed address.
<G-vec00074-002-s198><assign.zuordnen><de> Den Zustand ordnen Sie den Geschäftspartnern manuell zu, deren Bank eine indizierte Adresse hat.
<G-vec00074-002-s199><assign.zuordnen><en> Multinational companies continue to source most (57%) of their international assignees from the country in which they are headquartered and assign them to foreign subsidiaries.
<G-vec00074-002-s199><assign.zuordnen><de> Internationale Unternehmen entsenden nach wie vor die meisten ihrer Expatriates (57 Prozent) aus dem Stammland und ordnen sie einer ausländischen Niederlassung zu.
<G-vec00074-002-s200><assign.zuordnen><en> Initially configure your Dojo, set up the different ranks and assign criteria for belt tests.
<G-vec00074-002-s200><assign.zuordnen><de> Könfigurieren Sie zunächst Ihr Dojo, legen Sie dann verschiedene Ränge an und ordnen die Kritierien für Gürtelprüfungen zu.
<G-vec00074-002-s201><assign.zuordnen><en> For this purpose, you assign the project to the sales project.
<G-vec00074-002-s201><assign.zuordnen><de> Dazu ordnen Sie dem Vertriebsprojekt das Projekt zu.
<G-vec00074-002-s202><assign.zuordnen><en> To display the values determined, you assign the accounts to the corresponding analysis lines.
<G-vec00074-002-s202><assign.zuordnen><de> Zum Ausweis der ermittelten Werte ordnen Sie die Konten den entsprechenden Auswertungszeilen zu.
<G-vec00074-002-s203><assign.zuordnen><en> Select a track / submission type and assign the formats to the tracks.
<G-vec00074-002-s203><assign.zuordnen><de> Wählen Sie einen Beitragstyp / Track und ordnen Sie die Einreichungsformate dem Track zu.
<G-vec00074-002-s204><assign.zuordnen><en> Assign the child the main thing on today's hike in the store.
<G-vec00074-002-s204><assign.zuordnen><de> Ordnen Sie dem Kind die Hauptsache auf der heutigen Wanderung im Laden zu.
<G-vec00074-002-s205><assign.zuordnen><en> Assign a synestral for softening the cervix.
<G-vec00074-002-s205><assign.zuordnen><de> Ordnen Sie ein Synestral für die Erweichung des Gebärmutterhalses zu.
<G-vec00074-002-s206><assign.zuordnen><en> To automatically determine the expected inflows and outflows in the cash forecast, assign the corresponding plan transaction when defining an analysis line.
<G-vec00074-002-s206><assign.zuordnen><de> Zur automatischen Ermittlung der voraussichtlichen Zuflüsse und Abflüsse in der Liquiditätsprognose ordnen Sie beim Definieren einer Auswertungszeile den entsprechenden Planvorgang zu.
<G-vec00074-002-s207><assign.zuordnen><en> To manage the entitlements given to users, assign Product Profiles to the user group.
<G-vec00074-002-s207><assign.zuordnen><de> Um die Berechtigungen zu verwalten, die Benutzern erteilt wurden, ordnen Sie der Benutzergruppe Produktprofile zu.
<G-vec00074-002-s208><assign.zuordnen><en> Alternatively: Assign the project with <Ctrl + A>.
<G-vec00074-002-s208><assign.zuordnen><de> Alternativ: Ordnen Sie über <Strg + A> das Projekt zu.
<G-vec00074-002-s209><assign.zuordnen><en> Read More Workflow Assign mentions to users, set its status, its priority and close it once it has been checked.
<G-vec00074-002-s209><assign.zuordnen><de> Ordnen Sie Nutzern Erwähnungen zu, vergeben einen Status, eine Priorität und vermerken die Erwähnung als abgeschlossen, nachdem diese bearbeitet wurde.
<G-vec00074-002-s210><assign.zuordnen><en> Assign cards to people, not teams.
<G-vec00074-002-s210><assign.zuordnen><de> Ordnen Sie die Karten, um die Menschen, nicht die teams.
<G-vec00074-002-s211><assign.zuordnen><en> i. Assign the devices on which you want to use them to the extension.
<G-vec00074-002-s211><assign.zuordnen><de> i. Ordnen Sie der Nebenstelle die Endgeräte zu, auf denen Sie diese nutzen wollen.
<G-vec00074-002-s212><assign.zuordnen><en> Alternatively: In the Supplier Part No. field, enter the supplier part number of the desired part or use the supplier part number to assign the desired part with <Ctrl + A>.
<G-vec00074-002-s212><assign.zuordnen><de> Alternativ: Geben Sie im Feld Lief-TeileNr die Lieferantenteilenummer des gewünschten Teils ein oder ordnen Sie über <Strg + A> das gewünschte Teil anhand seiner Lieferantenteilenummer zu.
<G-vec00074-002-s213><assign.zuordnen><en> First assign the ticket to the category "Premium support", enter the subject of the support request and fill out the text field of the formular with your concerns.
<G-vec00074-002-s213><assign.zuordnen><de> Ordnen Sie das Ticket zunächst der Kategorie "Premium-Support" zu, geben Sie das Thema der Support-Anfrage an und füllen das Textfeld des Formulares mit Ihrem Anliegen aus.
<G-vec00074-002-s214><assign.zuordnen><en> Transfer photos of your food to the display and assign your own images to your dishes.
<G-vec00074-002-s214><assign.zuordnen><de> Übertragen Sie Fotos Ihrer Speisen auf das Display und ordnen Sie Ihren Gerichten Ihre eigenen Bilder zu.
<G-vec00074-002-s215><assign.zuordnen><en> Assign the desired serial number with <Ctrl + A>.
<G-vec00074-002-s215><assign.zuordnen><de> Ordnen Sie über <Strg + A> die gewünschte Seriennummer zu.
<G-vec00074-002-s216><assign.zuordnen><en> Bundle all important test data within the test case and assign the specific test data to the individual steps.
<G-vec00074-002-s216><assign.zuordnen><de> Bündeln Sie alle wichtigen Testdaten innerhalb des Test Cases und ordnen Sie die spezifischen Testdaten den einzelnen Schritten zu.
<G-vec00074-002-s217><assign.zuordnen><en> Use the master password or assign a separate password for twice the protection.
<G-vec00074-002-s217><assign.zuordnen><de> Verwenden Sie das Master-Passwort oder ordnen Sie ein separates Passwort für den doppelten Schutz zu.
<G-vec00074-002-s218><assign.zuordnen><en> Assign the respective cost items only once in the costing schedule.
<G-vec00074-002-s218><assign.zuordnen><de> Ordnen Sie die entsprechenden Kostenarten nur einmal im Kalkulationsschema zu.
<G-vec00074-002-s219><assign.zuordnen><en> Create a new product type and assign the necessary attributes (like Lieferzeit, Webstoff) to it.
<G-vec00074-002-s219><assign.zuordnen><de> Erstellen Sie einen neuen Produkttyp und ordnen Sie die erforderlichen Eigenschaften (wie Lieferzeit, Webstoff) zu.
<G-vec00074-002-s220><assign.zuordnen><en> Please register through the online application system and assign your application to the relevant sites.
<G-vec00074-002-s220><assign.zuordnen><de> Bitte registrieren Sie sich in unserem Online-Bewerbungssystem und ordnen Sie Ihre Initiativbewerbung den relevanten Standorten zu.
<G-vec00074-002-s221><assign.zuordnen><en> Assign the standard calendar weeks to the standard calendar.
<G-vec00074-002-s221><assign.zuordnen><de> Ordnen Sie dem Standardkalender die Standardkalenderwochen zu.
<G-vec00074-002-s222><assign.zuordnen><en> If you are logged onto Facebook during this process, Facebook will assign this information to your personal Facebook user account.
<G-vec00074-002-s222><assign.zuordnen><de> Sind Sie dabei als Mitglied bei Facebook eingeloggt, ordnet Facebook diese Information Ihrem persönlichen Facebook-Benutzerkonto zu.
<G-vec00074-002-s224><assign.zuordnen><en> If the Facebook ID contained in a Facebook cookie can be assigned to a Facebook user, then Facebook will assign this user to a target group ("Custom Audience") according to the rules we have defined, provided that the rules are relevant.
<G-vec00074-002-s224><assign.zuordnen><de> Kann eine Zuordnung der im Facebook-Cookie enthaltenen Facebook-ID zu einem Facebook-Nutzer vorgenommen werden, ordnet Facebook diesem Nutzer anhand der von uns festgelegten Regeln einer Zielgruppe („Custom Audience“) zu, sofern die Regeln einschlägig sind.
<G-vec00074-002-s225><assign.zuordnen><en> It uses automated character recognition to assign your basic data to the right form fields.
<G-vec00074-002-s225><assign.zuordnen><de> Dabei ordnet unsere automatische Erkennung Ihre Stammdaten den richtigen Formularfeldern zu.
<G-vec00074-002-s226><assign.zuordnen><en> If you are logged in to Facebook when you visit our site, Facebook will use the information collected by the component to identify the specific pages you are visiting and will assign this information to your personal Facebook account.
<G-vec00074-002-s226><assign.zuordnen><de> Wenn Sie unsere Seite aufrufen und währenddessen bei Facebook eingeloggt sind, erkennt Facebook durch die von der Komponente gesammelte Information, welche konkrete Seite Sie besuchen und ordnet diese Informationen Ihrem persönlichen Account auf Facebook zu.
<G-vec00074-002-s227><assign.zuordnen><en> If the data subject clicks on one of the Google+ buttons integrated on our website and thereby makes a Google+1 recommendation, Google will assign this information to the personal Google+ user account of the data subject and store this personal data.
<G-vec00074-002-s227><assign.zuordnen><de> Betätigt die betroffene Person einen der auf unserer Internetseite integrierten Google+-Buttons und gibt damit eine Google+1 Empfehlung ab, ordnet Google diese Information dem persönlichen Google+-Benutzerkonto der betroffenen Person zu und speichert diese personenbezogenen Daten.
<G-vec00074-002-s228><assign.zuordnen><en> If you are logged in as a member of Facebook, Facebook will assign this information to your personal user account.
<G-vec00074-002-s228><assign.zuordnen><de> Sind Sie dabei als Mitglied bei Facebook eingeloggt, ordnet Facebook diese Information Ihrem persönlichen Benutzerkonto zu.
<G-vec00074-002-s230><assign.zuordnen><en> This means that it no longer matters to the controller at the control centre what specific logger a communication was recorded on: via the web interface he is able to access all recordings from practically anywhere, play them back, analyse and search them, link them with other information, assign them to categories or give them attributes.
<G-vec00074-002-s230><assign.zuordnen><de> Das bedeutet, dass es für den Disponenten auf der Leitstelle keine Rolle mehr spielt, auf welchem konkreten Logger eine Kommunikation aufgezeichnet wurde: Über das Web-Interface greift er von praktisch überall aus auf sämtliche Aufzeichnungen zu, spielt sie ab, analysiert und recherchiert sie, verknüpft sie mit weiteren Informationen, ordnet sie Kategorien zu oder attribuiert sie.
<G-vec00074-002-s303><assign.zuordnen><en> Once you have logged into one of the services of the providers, these providers can assign your visit to our internet presence to your profile / account with the respective provider.
<G-vec00074-002-s303><assign.zuordnen><de> Sind Sie bei einem der Dienste der Anbieter eingeloggt, können die Anbieter den Besuch unserer Internetpräsenz Ihrem Profil/Konto des jeweiligen Anbieters unmittelbar zuordnen.
<G-vec00074-002-s304><assign.zuordnen><en> Should the customer be logged in on Facebook, Facebook is able to assign the customer's visit to the page to his or her Facebook account.
<G-vec00074-002-s304><assign.zuordnen><de> Sind Sie bei Facebook eingeloggt, kann Facebook den Besuch unserer Website Ihrem Facebook-Profil unmittelbar zuordnen.
<G-vec00074-002-s306><assign.zuordnen><en> If the user is logged in to Facebook, Facebook can assign the visit to his Facebook account.
<G-vec00074-002-s306><assign.zuordnen><de> Sind Sie bei Instagram eingeloggt, kann Instagram den Besuch unserer Website Ihrem Instagram-Account unmittelbar zuordnen.
<G-vec00074-002-s307><assign.zuordnen><en> If you are logged in with Pinterest, it will be able to assign your visit of our website to your Pinterest account.
<G-vec00074-002-s307><assign.zuordnen><de> Sind Sie bei Google+ eingeloggt, kann Google den Besuch unserer DaWanda-Seite Ihrem Google+ Profil unmittelbar zuordnen.
<G-vec00074-002-s308><assign.zuordnen><en> If you are connected to one of the social networks, providers can assign the visit of our website to your profile on Facebook.
<G-vec00074-002-s308><assign.zuordnen><de> Sind Sie bei Facebook eingeloggt, kann Facebook den Besuch unserer Website Ihrem Facebook- Profil unmittelbar zuordnen.
<G-vec00074-002-s309><assign.zuordnen><en> If you would not like Google or Facebook to assign the data collected via our website to your profile on the respective social network, you must log out of the respective network before visiting our website.
<G-vec00074-002-s309><assign.zuordnen><de> Wenn Sie nicht möchten, dass Google oder Facebook die über unseren Webauftritt gesammelten Daten unmittelbar Ihrem Profil in dem jeweiligen sozialen Netzwerk zuordnen, müssen Sie sich vor Ihrem Besuch unserer Website bei dem entsprechenden Netzwerk ausloggen.
<G-vec00074-002-s310><assign.zuordnen><en> If the user is logged in to Facebook, Facebook can assign the visit to the Facebook account of the user.
<G-vec00074-002-s310><assign.zuordnen><de> Sind Sie bei Facebook eingeloggt, kann Facebook den Besuch unserer Website Ihrem FacebookProfil unmittelbar zuordnen.
<G-vec00074-002-s311><assign.zuordnen><en> If you are logged into Twitter while using the site, Twitter can assign your access to your Twitter account.
<G-vec00074-002-s311><assign.zuordnen><de> Sind Sie bei Twitter eingeloggt, kann Twitter den Besuch unserer Webseite Ihrem Twitter- Account unmittelbar zuordnen.
<G-vec00074-002-s428><assign.zuordnen><en> When selecting which service technician to assign to a job, you must consider specific customer requests as well as the specialist skills required.
<G-vec00074-002-s428><assign.zuordnen><de> Bei der Auswahl der Servicetechniker, die einem Auftrag zugeordnet werden sollen, müssen Sie sowohl spezifische Kundenwünsche als auch die erforderlichen Fachkenntnisse berücksichtigen.
<G-vec00074-002-s429><assign.zuordnen><en> The next tab “macro” can be used to assign a single key press to self-chosen shortcuts.
<G-vec00074-002-s429><assign.zuordnen><de> Beim nächsten Reiter „Makro“ können selbst gewählte Tastenkombinationen einem einzigen Tastendruck zugeordnet werden.
<G-vec00074-002-s430><assign.zuordnen><en> Once computers are added to groups, you can assign policies, tasks or settings to these groups.
<G-vec00074-002-s430><assign.zuordnen><de> Werden Computer einer Gruppe zugeordnet, können Sie für diese Policies, Tasks oder Einstellungen festlegen.
<G-vec00074-002-s431><assign.zuordnen><en> If you do not enter any information for a repair warehouse and you assign the repair warehouse to a sales warehouse, then the settings for the sales warehouse will be used by default.
<G-vec00074-002-s431><assign.zuordnen><de> Wenn in einem Reparaturlager keine Einträge stehen und das Lager einem Vertriebslager zugeordnet ist, werden die Einstellungen des Vertriebslagers verwendet.
<G-vec00074-002-s432><assign.zuordnen><en> If you are logged in with Google+, Google can assign the visit to our website to your Google+ profile.
<G-vec00074-002-s432><assign.zuordnen><de> Wenn Sie bei dem Plug-in-Anbieter eingeloggt sind, werden Ihre bei uns erhobenen Daten direkt Ihrem beim Plug-in-Anbieter bestehenden Konto zugeordnet.
<G-vec00074-002-s434><assign.zuordnen><en> The next step is to assign the physical Network Cards to the configurations.
<G-vec00074-002-s434><assign.zuordnen><de> Nun werden die physischen Netzwerkkarten zu den Netzwerktypen zugeordnet.
<G-vec00074-002-s435><assign.zuordnen><en> If you are already logged in to one of the social networks of the providers, the providers can directly assign the visit to this website to your profile.
<G-vec00074-002-s435><assign.zuordnen><de> Wenn Sie bei Google eingeloggt sind, werden Ihre Daten direkt Ihrem Konto zugeordnet.
<G-vec00074-002-s436><assign.zuordnen><en> If you are also logged in to your YouTube account, you will allow YouTube to assign your surfing behaviour directly to your personal profile.
<G-vec00074-002-s436><assign.zuordnen><de> Sind Sie gleichzeitig bei YouTube eingeloggt, werden diese Informationen Ihrem Mitgliedskonto bei YouTube zugeordnet.
<G-vec00074-002-s437><assign.zuordnen><en> This information is stored in such a way that Abacus usually (if you do not log in to the website) cannot assign it to any particular person.
<G-vec00074-002-s437><assign.zuordnen><de> Diese Informationen werden so gespeichert, dass sie von Abacus in der Regel (wenn Sie sich auf der Website nicht einloggen) keiner bestimmten Personen zugeordnet werden können.
<G-vec00074-002-s438><assign.zuordnen><en> In any case, Holidog may assign or transfer all contracts, rights and obligations to which it is a party without obtaining the Member’s prior consent.
<G-vec00074-002-s438><assign.zuordnen><de> Verträge, Rechte und Pflichten von Holidog werden in jedem Fall zugeordnet oder übertragen ohne vorherige Zustimmung des Mitglieds.
<G-vec00074-002-s440><assign.zuordnen><en> Otherwise, Univention Management Console will automatically assign the next available group ID when adding the group.
<G-vec00074-002-s440><assign.zuordnen><de> Ansonsten wird der Gruppe automatisch die nächste freie Gruppen-ID zugeordnet.
<G-vec00074-002-s441><assign.zuordnen><en> For technical reasons, it is possible to assign this information to individual subscribers.
<G-vec00074-002-s441><assign.zuordnen><de> Diese Informationen können aus technischen Gründen zwar den einzelnen Newsletterempfängern zugeordnet werden.
<G-vec00074-002-s443><assign.zuordnen><en> The current practice is to assign the measured data to the relevant train cars and their axles by counting the total number of axles on the train.
<G-vec00074-002-s443><assign.zuordnen><de> Heute werden die Messdaten durch Zählen der Achsen des gesamten Zuges den betroffenen Wagen und deren Achsen zugeordnet.
<G-vec00074-002-s444><assign.zuordnen><en> It consists of a string of characters that can be used to assign websites and servers to the specific Internet browser in which the cookie was stored.
<G-vec00074-002-s444><assign.zuordnen><de> Sie besteht aus einer Zeichenfolge, durch welche Internetseiten und Server dem konkreten Internetbrowser zugeordnet werden können, in dem das Cookie gespeichert wurde.
<G-vec00074-002-s445><assign.zuordnen><en> Points which are used to assign the wagons to the relevant trains, can be reliably set with the help of inductive wheel sensors.
<G-vec00074-002-s445><assign.zuordnen><de> Weichen, über welche die Waggons den jeweiligen Zügen zugeordnet werden, können mit Hilfe induktiver Radsensoren zuverlässig gestellt werden.
<G-vec00074-002-s447><assign.zuordnen><en> You can assign a drawing object to an existing linked object.
<G-vec00074-002-s447><assign.zuordnen><de> Das Zeichnungsobjekt kann einem bestehenden, mit dem Projekt verknüpften Objekt zugeordnet werden.
<G-vec00074-002-s448><assign.zuordnen><en> If you are logged into Facebook, Facebook can assign your visit to your account.
<G-vec00074-002-s448><assign.zuordnen><de> Sind Sie bei Facebook eingeloggt so können die übermittelten Informationen direkt ihrem Konto zugeordnet werden.
<G-vec00074-002-s449><assign.zuordnen><en> It is possible to assign different colors to various objects of a structure in order to make the rendering display of the structure more clearly arranged.
<G-vec00074-002-s449><assign.zuordnen><de> Den verschiedenen Objekten der Struktur können unterschiedliche Farben zugeordnet werden, um die Rendering-Darstellung der Konstruktion noch übersichtlicher zu gestalten.
<G-vec00074-002-s451><assign.zuordnen><en> It is possible to assign the painting on the outer lid to an engraving after a painting of Antoine Watteau.
<G-vec00074-002-s451><assign.zuordnen><de> Das äußere Deckelgemälde kann einem Stich, angefertigt nach einem Gemälde von Antoine Watteau, zugeordnet werden.
<G-vec00074-002-s452><assign.zuordnen><en> If you are logged in to the social network, this can assign your visit to this website to your user account.
<G-vec00074-002-s452><assign.zuordnen><de> Wenn Sie im entsprechenden sozialen Netzwerk angemeldet sind, kann der Besuch der Webseite Ihrem Nutzerkonto zugeordnet werden.
<G-vec00074-002-s453><assign.zuordnen><en> A third reason WAC is a good choice for some manufacturers is in cases where inventory is highly commoditized and a cost per unit is not possible to assign to individual units or when the monetary fractions are so small that it is statistically irrelevant because all vendor costs are similar.
<G-vec00074-002-s453><assign.zuordnen><de> Ein dritter Grund, warum WAC für einige Hersteller eine gute Wahl ist, liegt in Fällen vor, in denen der Lagerbestand stark vermarktet ist und die Kosten pro Einheit nicht einzelnen Einheiten zugeordnet werden können oder wenn die monetären Anteile so gering sind, dass sie statistisch irrelevant sind, da alle Herstellerkosten anfallen ähnlich.
<G-vec00074-002-s454><assign.zuordnen><en> Roles tab allows you to define security roles and assign roles to user accounts.
<G-vec00074-002-s454><assign.zuordnen><de> Mit der Registerkarte Rollen können Sicherheitsrollen definiert und Rollen zu Benutzerkonten zugeordnet werden.
<G-vec00074-002-s489><assign.zuordnen><en> You can create roles, manage and assign roles to other users.
<G-vec00074-002-s489><assign.zuordnen><de> Sie können Rollen erstellen, verwalten und anderen Benutzern Rollen zuordnen.
<G-vec00074-002-s490><assign.zuordnen><en> If you are logged into Xing, Xing is able to assign your visit to your Xing account.
<G-vec00074-002-s490><assign.zuordnen><de> Sind Sie bei Xing eingeloggt kann Xing den Besuch Ihrem Xing-Konto zuordnen.
<G-vec00074-002-s491><assign.zuordnen><en> This is a lesson that some of you need to hear and that some of you will not look at, because Human Beings want to assign evil to entities.
<G-vec00074-002-s491><assign.zuordnen><de> Das ist eine Lektion die manche von euch hören müssen und die manche von euch nicht anschauen werden, denn Menschen wollen das Böse anderen Wesen zuordnen.
<G-vec00074-002-s492><assign.zuordnen><en> CADISON® can automatically identify ‘Free & Used contacts’ and assign them to devices.
<G-vec00074-002-s492><assign.zuordnen><de> CADISON® kann automatisch "Freie & Genutzte Kontakte" identifizieren und ihnen Geräte zuordnen.
<G-vec00074-002-s493><assign.zuordnen><en> You can use the variables "AbsoluteX" and "AbsoluteY" to read out free texts from the source drawing and assign them to Engineering Base attributes via their positions.
<G-vec00074-002-s493><assign.zuordnen><de> Mit den Variablen „AbsoluteX" und „AbsoluteY" lassen sich freie Texte in der Quellzeichnung auslesen und über ihre Position Engineering Base-Attributen zuordnen.
<G-vec00074-002-s494><assign.zuordnen><en> Assign your animal a subspecies, when necessary.
<G-vec00074-002-s494><assign.zuordnen><de> In ausgewählten Fällen kannst du dein Tier einer Unterspezies zuordnen.
<G-vec00074-002-s495><assign.zuordnen><en> The basics of hand reading that you've already learned: you know the five player types, you can assign them the average ranges and narrow those down post-flop using funnel principle.
<G-vec00074-002-s495><assign.zuordnen><de> Die Grundlagen des Handreading hast du bereits kennengelernt: Du kennst die fünf Spielertypen, kannst ihnen Durchschnittsranges zuordnen und diese mit dem Trichterprinzip postflop eingrenzen.
<G-vec00074-002-s496><assign.zuordnen><en> The Bitcoin Compass Trading Software will automatically assign a broker for you.
<G-vec00074-002-s496><assign.zuordnen><de> Die 1K Daily Profit Trading Software wird Ihnen automatisch einen Broker zuordnen.
<G-vec00074-002-s497><assign.zuordnen><en> You can assign a generated product file to a main product file by replacing the serial number in the corresponding product file line.
<G-vec00074-002-s497><assign.zuordnen><de> Eine generierte Produktakte können Sie einer Hauptproduktakte zuordnen, indem Sie in der betroffenen Produktaktenposition die Seriennummer austauschen.
<G-vec00074-002-s499><assign.zuordnen><en> Our employees in the shop will then briefly compare data with you in order to assign it clearly.
<G-vec00074-002-s499><assign.zuordnen><de> Unsere Mitarbeiter(innen) im Shop werden im Anschluss mit Ihnen gemeinsam kurz Ihre Daten abgleichen, um Sie eindeutig zuordnen zu können.
<G-vec00074-002-s500><assign.zuordnen><en> With this setting, the facets (categories), which you can assign to the application's data fields in the search configuration, and tags - will be shown next to the search results, if the search is configured for tags and a tag result is clicked on.
<G-vec00074-002-s500><assign.zuordnen><de> Mit dieser Einstellung werden neben den Suchergebnissen die Facetten (Kategorien), die Sie in der Suchenkonfiguration den Datenfeldern der Applikation zuordnen können, und Tags eingeblendet, wenn die Suche für Tags konfiguriert ist und auf einen Tag-Treffer geklickt wird.
<G-vec00074-002-s502><assign.zuordnen><en> If you are logged into Facebook, then Facebook can assign the visit to our website directly to your Facebook account.
<G-vec00074-002-s502><assign.zuordnen><de> Sind Sie bei Facebook eingeloggt, kann Facebook den Besuch unserer Website Ihrem Facebook-Konto direkt zuordnen.
<G-vec00074-002-s503><assign.zuordnen><en> This is an MRP suggestion that was linked with the demand of the firmed schedule in the pegging (Tools | Assign Demands menu item).
<G-vec00074-002-s503><assign.zuordnen><de> Dies ist ein Dispositionsvorschlag, der in der Bedarfsverwendung mit dem Bedarf der Abrufposition verbunden wurde (Menüpunkt Extras | Bedarfe zuordnen).
<G-vec00074-002-s504><assign.zuordnen><en> Facebook can then assign your Facebook account with the visit to our website.
<G-vec00074-002-s504><assign.zuordnen><de> Dadurch kann Facebook den Besuch unserer Seiten Ihrem Benutzerkonto zuordnen.
<G-vec00074-002-s505><assign.zuordnen><en> If you are logged into your Disqus account at the same time, it is also possible to associate the retrieval of the page with your Disqus account so that Disqus can assign your surfing behavior directly to your account.
<G-vec00074-002-s505><assign.zuordnen><de> Wenn Sie gleichzeitig in Ihren Disqus-Account eingeloggt sind, ist es auch möglich, den Abruf der Seite Ihrem Disqus-Account zuzuordnen, so dass Disqus Ihr Surfverhalten direkt Ihrem Account zuordnen kann.
<G-vec00074-002-s507><assign.zuordnen><en> They store a so-called session ID, which can be used to assign various requests from your browser to the respective session.
<G-vec00074-002-s507><assign.zuordnen><de> Diese speichern eine sogenannte Session-ID, mit welcher sich verschiedene Anfragen Ihres Browsers der gemeinsamen Sitzung zuordnen lassen.
<G-vec00074-002-s511><assign.zuordnen><en> If you do not wish Facebook to assign your visit to our website to your Facebook user account, please log out of your Facebook user account.
<G-vec00074-002-s511><assign.zuordnen><de> Wenn Sie nicht wünschen, dass Facebook den Besuch unserer Seiten Ihrem Facebook- Nutzerkonto zuordnen kann, loggen Sie sich bitte aus Ihrem Facebook-Benutzerkonto aus.
<G-vec00074-002-s512><assign.zuordnen><en> If you do not want Facebook to assign your visit to our website to your Facebook account, you must log out of your Facebook account before visiting our website or using our app.
<G-vec00074-002-s512><assign.zuordnen><de> Wenn Du nicht willst, dass Facebook den Besuch unserer Website Deinem dortigen Nutzerkonto zuordnen kann, musst Du Dich vor dem Aufruf unserer Website oder der Nutzung unserer App von Deinem Facebook-Benutzerkonto abmelden.
<G-vec00074-002-s513><assign.zuordnen><en> If you do not wish to allow Google to assign data that is collected on our website to your respective user account, you have to sign out from YouTube beforehand.
<G-vec00074-002-s513><assign.zuordnen><de> Wenn Sie nicht möchten, dass Google die auf unserem Internetangebot gesammelten Daten Ihrem jeweiligen Nutzerkonto bei YouTube zuordnen kann, so müssen Sie sich zuvor bei YouTube ausloggen.
<G-vec00074-002-s518><assign.zuordnen><en> If you do not want Twitter to assign your visit to our webpages to your Twitter user account, please log yourself out of your Twitter user’s account.
<G-vec00074-002-s518><assign.zuordnen><de> Wenn Sie nicht wünschen, dass Twitter den Besuch unserer Seiten Ihrem Twitter-Nutzerkonto zuordnen kann, loggen Sie sich bitte aus Ihrem Twitter-Benutzerkonto aus.
<G-vec00074-002-s520><assign.zuordnen><en> Moreover, if you click on the Xing button, you will link content from our website to your Xing profile or transmit data and information to Xing, allowing Xing to assign your visit to our website to you.
<G-vec00074-002-s520><assign.zuordnen><de> Mit einem Klick auf den Xing-Button verlinken Sie darüber hinaus Inhalte unserer Website mit Ihrem Xing-Profil oder übermitteln Daten und Informationen an Xing, womit Xing Ihnen den Besuch unserer Website zuordnen kann.
<G-vec00074-002-s605><assign.zuordnen><en> If you click on the Facebook “Like-Button” while you are logged into your Facebook account, you can link the contents of our pages to your Facebook profile. As a result, Facebook can assign the visit to our pages to your user account.
<G-vec00074-002-s605><assign.zuordnen><de> Wenn Sie den „Recommend-Button“ von LinkedIn anklicken und in Ihrem Account bei LinkedIn eingeloggt sind, ist es LinkedIn möglich, Ihren Besuch auf unserer Internetseite Ihnen und Ihrem Benutzerkonto zuzuordnen.
<G-vec00074-002-s606><assign.zuordnen><en> I publish these data only for statistical purposes in anonymized form so it is impossible to assign them to a particular person or company.
<G-vec00074-002-s606><assign.zuordnen><de> Ich veröffentliche diese Daten nur für statistische Zwecke in anonymisierter Form, so dass es unmöglich ist, sie einer bestimmten Person oder Firma zuzuordnen.
<G-vec00074-002-s607><assign.zuordnen><en> One can not assign a Boolean to an integer variable.
<G-vec00074-002-s607><assign.zuordnen><de> Es ist nicht möglich, einen Booleanwert direkt einer integer-Variable zuzuordnen.
<G-vec00074-002-s608><assign.zuordnen><en> Adding a new identity requires to define both the corresponding roles and a labeling prefix which is used to assign a type to personal files (/home/user/*).
<G-vec00074-002-s608><assign.zuordnen><de> Um eine neue Identität hinzuzufügen, ist es erforderlich, sowohl die entsprechenden Rollen als auch ein kennzeichnendes Präfix festzulegen, das dazu benutzt wird, einem Typ persönliche Dateien (/home/benutzer/*) zuzuordnen.
<G-vec00074-002-s609><assign.zuordnen><en> Assign External Issue Assign an issue from an external issue tracking system to the selected test definition.
<G-vec00074-002-s609><assign.zuordnen><de> Ermöglicht Ihnen, der ausgewählten Testspezifikation einen Fehler aus einem externen Fehlerverfolgungssystem zuzuordnen.
<G-vec00074-002-s610><assign.zuordnen><en> If you have logged in to your Vimeo account, this allows Vimeo to assign your browser behaviour directly to your personal profile.
<G-vec00074-002-s610><assign.zuordnen><de> Wenn Sie in Ihrem Vimeo-Account eingeloggt sind, ermöglichen Sie Vimeo, Ihr Surfverhalten direkt Ihrem persönlichen Profil zuzuordnen.
<G-vec00074-002-s611><assign.zuordnen><en> If you click the LinkedIn “Recommend button” and are logged into your LinkedIn account, it is possible for LinkedIn to assign your visit to our website to you and your user account.
<G-vec00074-002-s611><assign.zuordnen><de> Wenn Sie den “Recommend-Button” von LinkedIn anklicken und in Ihrem Account bei LinkedIn eingeloggt sind, ist es LinkedIn möglich, Ihren Besuch auf unserer Internetseite Ihnen und Ihrem Benutzerkonto zuzuordnen.
<G-vec00074-002-s612><assign.zuordnen><en> Facebook collects this information, so theoretically it is possible to assign this information to the Facebook account.
<G-vec00074-002-s612><assign.zuordnen><de> Facebook sammelt diese Informationen, sodass theoretisch die Möglichkeit besteht, diese Informationen dem Facebook-Account zuzuordnen.
<G-vec00074-002-s613><assign.zuordnen><en> If you are logged into your YouTube account, you enable YouTube to assign your surfing activity directly to your personal profile.
<G-vec00074-002-s613><assign.zuordnen><de> Wenn Sie in Ihrem YouTube-Account eingeloggt sind, ermöglichen Sie YouTube, Ihr Surfverhalten direkt Ihrem persönlichen Profil zuzuordnen.
<G-vec00074-002-s614><assign.zuordnen><en> To assign an asset to an asset shelf, you can alternatively cut the asset and insert it into the asset shelf.
<G-vec00074-002-s614><assign.zuordnen><de> Um ein Asset einer Asset-Ablage zuzuordnen, können Sie auch alternativ das Asset ausscheiden und in der Asset-Ablage einfügen.
<G-vec00074-002-s615><assign.zuordnen><en> Click the keyboard icon and assign the macro to F3 (or whatever button you want to assign it to) using the “Press New Shortcut Key” clickable box.
<G-vec00074-002-s615><assign.zuordnen><de> Klicke auf das Zeichen mit einer Tastatur, um dem Makro F3 zuzuordnen (oder eine andere Taste, die du ihm zuweisen möchtest), indem du die anklickbare Box "Neues Tastaturkürzel eingeben" drückst.
<G-vec00074-002-s616><assign.zuordnen><en> If you are logged into your vimeo account, you enable vimeo to assign your surfing behavior directly to your personal profile.
<G-vec00074-002-s616><assign.zuordnen><de> Wenn Sie in Ihrem vimeo-Account eingeloggt sind ermöglichen Sie vimeo, Ihr Surfverhalten direkt Ihrem persönlichen Profil zuzuordnen.
<G-vec00074-002-s617><assign.zuordnen><en> Click on Next to assign a mailbox.
<G-vec00074-002-s617><assign.zuordnen><de> Klicken Sie auf Weiter (Next), um ein Postfach zuzuordnen.
<G-vec00074-002-s618><assign.zuordnen><en> Comparative analyses allow us to assign highly specific targets to distinct tumor entities or particular stages of disease.
<G-vec00074-002-s618><assign.zuordnen><de> Vergleichende Analysen ermöglichen es uns, hochspezifische Targets bestimmten Tumorentitäten oder einem speziellen Erkrankungsstadium zuzuordnen.
<G-vec00074-002-s619><assign.zuordnen><en> This makes it possible for the first time to spatially assign complete spectral information to create a three-dimensional spectral tomography.
<G-vec00074-002-s619><assign.zuordnen><de> Dabei ist es erstmals möglich, eine vollständige spektrale Information räumlich zuzuordnen und so eine dreidimensional-spektrale Tomographie zu realisieren.
<G-vec00074-002-s620><assign.zuordnen><en> Moreover, please note that it is not possible to move or assign products from one store to another, only inside the same store.
<G-vec00074-002-s620><assign.zuordnen><de> Darüber hinaus ist zu beachten, dass es nicht möglich ist, Produkte von einem Laden zu einem anderen zu verschieben oder zuzuordnen, nur innerhalb derselben Filiale.
<G-vec00074-002-s621><assign.zuordnen><en> If you are logged-in your Vimeo account, Vimeo can assign your navigation activity to you personally.
<G-vec00074-002-s621><assign.zuordnen><de> Wenn Sie in Ihrem Vimeo-Account eingeloggt sind, kann Vimeo Ihr Surfverhalten Ihnen persönlich zuzuordnen.
<G-vec00074-002-s622><assign.zuordnen><en> Click + to assign a member to the group.
<G-vec00074-002-s622><assign.zuordnen><de> Klicken Sie auf +, um ein Mitglied der Gruppe zuzuordnen.
<G-vec00074-002-s264><assign.zuweisen><en> If you are using Office 365 operated by 21Vianet, see Assign or remove licenses in Office 365 operated by 21Vianet.
<G-vec00074-002-s264><assign.zuweisen><de> Wenn Sie Office 365 verwenden, betrieben von 21Vianet, lesen Sie Zuweisen oder Entfernen von Lizenzen in Office 365, betrieben von 21Vianet.
<G-vec00074-002-s265><assign.zuweisen><en> Assign a policy to a managed system on page 171 Assign a policy to a specific managed system.
<G-vec00074-002-s265><assign.zuweisen><de> Zuweisen einer Richtlinie zu einem verwalteten System auf Seite 188 Sie können einem bestimmten verwalteten System eine Richtlinie zuweisen.
<G-vec00074-002-s266><assign.zuweisen><en> This tutorial explains how to assign functions to the EPLAN project as a third step.
<G-vec00074-002-s266><assign.zuweisen><de> Dieses Tutorial erklärt, wie Sie dem EPLAN Projekt im dritten Schritt Funktionen zuweisen.
<G-vec00074-002-s267><assign.zuweisen><en> Assign training and automatic expiry notifications to manage required learning.
<G-vec00074-002-s267><assign.zuweisen><de> Verwalten Sie erforderliche Lerninitiativen, indem Sie Schulungen und automatische Ablaufbenachrichtigungen zuweisen.
<G-vec00074-002-s268><assign.zuweisen><en> Here you can purchase user licenses (subscription) on different SIGNL plans and assign those user licenses to your teams.
<G-vec00074-002-s268><assign.zuweisen><de> Im Anschluss erwerben sie beliebig viele Nutzerlizenzen für SIGNL Pläne ihrer Wahl, die sie anschließend ihren Teams zuweisen können.
<G-vec00074-002-s269><assign.zuweisen><en> Assign applications Once an application is assigned to a desktop, it's permanently bound to it.
<G-vec00074-002-s269><assign.zuweisen><de> Sobald Sie eine Anwendung einem Desktop zuweisen, ist sie permanent an ihn gebunden.
<G-vec00074-002-s270><assign.zuweisen><en> To learn how to assign a role to an already running instance, see IAM Roles for Amazon EC2.
<G-vec00074-002-s270><assign.zuweisen><de> Unter IAM-Rollen für Amazon EC2 erfahren Sie, wie Sie einer bereits ausgeführten Instance eine Rolle zuweisen können.
<G-vec00074-002-s273><assign.zuweisen><en> If you're the Office 365 admin responsible for assigning licenses, see Assign licenses to users.
<G-vec00074-002-s273><assign.zuweisen><de> Wenn Sie der Office 365-Administrator sind, der für die Zuweisung von Lizenzen verantwortlich ist, lesen Sie Zuweisen von Lizenzen zu Benutzern.
<G-vec00074-002-s274><assign.zuweisen><en> Learn how to assign a webinar license after purchase.
<G-vec00074-002-s274><assign.zuweisen><de> Erfahren Sie, wie Sie nach dem Kauf eine Webinar-Lizenz zuweisen.
<G-vec00074-002-s275><assign.zuweisen><en> Assignment Operators Use assignment operators (=, +=, -=, *=, /=, %=) to assign one or more values to variables, to change the values in a variable, and to append values to variables.
<G-vec00074-002-s275><assign.zuweisen><de> Zuweisungsoperatoren Verwenden Sie Zuweisungsoperatoren (=, +=, -=, *=, /=, %=), wenn Sie Variablen einen oder mehrere Werte zuweisen, die Werte in einer Variablen ändern oder Werte an Variablen anfügen möchten.
<G-vec00074-002-s352><assign.zuweisen><en> Assign Heart Rate to one of your watch face’s data points from the brand watch app options.
<G-vec00074-002-s352><assign.zuweisen><de> Weise die Herzfrequenz einem der Datenpunkte auf dem Zifferblatt zu.
<G-vec00074-002-s353><assign.zuweisen><en> Manage your projects, create todos, notes and assign employees to your projects.
<G-vec00074-002-s353><assign.zuweisen><de> Organisiere deine Projekte, erstelle dir To-Do-Listen und Notizen, weise deine MItarbeiter zu.
<G-vec00074-002-s354><assign.zuweisen><en> Alternatively you can add users to mysql database by using a control panel like phpMyAdmin to easily create or assign database permission to users.
<G-vec00074-002-s354><assign.zuweisen><de> Alternativ können Benutzer über Kontrollprogramme wie phpMyAdmin angelegt werden, um auf einfache Weise Zugriffsberechtigungen auf die Datenbank erstellen oder adaptieren zu können.
<G-vec00074-002-s355><assign.zuweisen><en> Invite the whole family to compete in a daily step challenge, assign tasks and chores, designate a reward virtual coin value and find out how many coins each child has.
<G-vec00074-002-s355><assign.zuweisen><de> Lade die gesamte Familie ein, an einer Schritt-Tageschallenge teilzunehmen, weise Aufgaben zu, lege einen Wert für eine virtuelle Belohnungsmünze fest und finde heraus, wie viele Münzen jedes Kind hat.
<G-vec00074-002-s356><assign.zuweisen><en> You can therefore assign a unique barcode to a series of instruments.
<G-vec00074-002-s356><assign.zuweisen><de> Auf diese Weise können Sie eine Instrumentenreihe mit einem eindeutigen Barcode versehen.
<G-vec00074-002-s357><assign.zuweisen><en> The Woman represents the most relevant female person: I personally don't assign the Woman strictly according to the method described above.
<G-vec00074-002-s357><assign.zuweisen><de> Die Dame repräsentiert die relevanteste weibliche Person: Ich persönlich weise die Dame nicht streng nach der oben beschriebenen Methode zu.
<G-vec00074-002-s358><assign.zuweisen><en> End your second recording and assign a shortcut & give it a name.
<G-vec00074-002-s358><assign.zuweisen><de> Beende deine zweite Aufnahme, weise ihr eine Verknüpfung zu und gib ihr einen Namen.
<G-vec00074-002-s359><assign.zuweisen><en> You may not incorporate any portion of the Pocketbook Software into your own programs or compile any portion of it in combination with your own programs, transfer it for use with another service, or sell, rent, lease, lend, loan, distribute or sub-license the Pocketbook Software or otherwise assign any rights to the Pocketbook Software in whole or in part.
<G-vec00074-002-s359><assign.zuweisen><de> Sie dürfen keine Teile der Pocketbook-Software in Ihre eigenen Programme einbinden, oder Teile daraus mit Ihren eigenen Programmen zusammen bündeln, es zur Benutzung für andere Services weiterreichen, sie dürfen die Pocketbook Software weder als Ganzes noch in Teilen verkaufen, vermieten, leasen, verleihen, beleihen, vertreiben oder sublizensieren oder in anderer Weise Rechte daran weitergeben.
<G-vec00074-002-s360><assign.zuweisen><en> Share files, collaborate with your team, manage access permissions, assign tasks and get work done without hassle.
<G-vec00074-002-s360><assign.zuweisen><de> Nutze Dateien gemeinsam, arbeite im Team zusammen, verwalte Zugriffsberechtigungen, weise Aufgaben zu und erledige Arbeit ohne Aufwand.
<G-vec00074-002-s361><assign.zuweisen><en> Assign a piece of furniture with each bullet point and object.
<G-vec00074-002-s361><assign.zuweisen><de> Weise jedem Gliederungspunkt und Objekt ein Möbelstück zu.
<G-vec00074-002-s362><assign.zuweisen><en> Automate inbound requests, and assign work to your team for faster client delivery.
<G-vec00074-002-s362><assign.zuweisen><de> Automatisiere eingehende Anforderungen und weise deinem Team Arbeit zu, um die Client-Zustellung zu beschleunigen.
<G-vec00074-002-s363><assign.zuweisen><en> Mic+ flips up to mute with a red mute light indicator.,Programmable G-Keys – Assign custom commands using G HUB on the three programmable G-keys for a seamless gaming and media experience.
<G-vec00074-002-s363><assign.zuweisen><de> Das Mikrofon lässt sich hochklappen und verfügt über eine rote Leuchtanzeige für die Stummschaltung.,Programmierbare G-Tasten – Weise mithilfe von G HUB den drei programmierbaren G-Tasten benutzerdefinierte Befehle zu für ein reibungsloses Gaming- und Multimedia-Erlebnis.
<G-vec00074-002-s364><assign.zuweisen><en> Don’t badmouth: Assign responsibility, not blame.
<G-vec00074-002-s364><assign.zuweisen><de> Keine üble Nachrede: Weise Verantwortung zu, nicht Schuld.
<G-vec00074-002-s365><assign.zuweisen><en> Assign ship to a venture dock before sending it into a parallel universe.
<G-vec00074-002-s365><assign.zuweisen><de> Weise ein Schiff einem Expeditions-Dock zu, bevor Du es in ein Paralleluniversum schickst.
<G-vec00074-002-s366><assign.zuweisen><en> I assign a task to a team member by dragging their portrait onto the task.
<G-vec00074-002-s366><assign.zuweisen><de> Ich weise einem Teammitglied eine Aufgabe zu, indem ich sein Foto darauf ziehe.
<G-vec00074-002-s367><assign.zuweisen><en> If the mixing is performed such that the customer's item is to be regarded as the principal item, it shall be deemed agreed upon that the customer shall assign proportionate co-ownership to us.
<G-vec00074-002-s367><assign.zuweisen><de> Erfolgt die Vermischung in der Weise, dass die Sache des Kunden als Hauptsache anzusehen ist, so gilt als vereinbart, dass der Kunde uns anteilmäßig Miteigentum überträgt.
<G-vec00074-002-s368><assign.zuweisen><en> Assign messages to the right teams and SocialHub users for more efficient processes.
<G-vec00074-002-s368><assign.zuweisen><de> Weise den zuständigen Teams und anderen SocialHub Nutzern Anfragen zu und sei dadurch effizienter.
<G-vec00074-002-s369><assign.zuweisen><en> In order to configure this setup, connect one output channel of your sound card to the line input of your speaker system and assign this channel to Output Master.
<G-vec00074-002-s369><assign.zuweisen><de> Um dieses Setup zu konfigurieren, verbinde einen Output-Kanal deines Audio-Interfaces mit dem Line-Eingang deines Lautsprechersystems und weise diesem Kanal Output Master zu.
<G-vec00074-002-s370><assign.zuweisen><en> Assign roles and decision-making status for each stakeholder.
<G-vec00074-002-s370><assign.zuweisen><de> Weise jedem Stakeholder Rollen und Entscheidungsstatus zu.
<G-vec00074-002-s371><assign.zuweisen><en> Based on these discussions, they assign visiting teachers to each sister in the ward.
<G-vec00074-002-s371><assign.zuweisen><de> Aufgrund dieser Besprechungen weisen die Führungsbeamten wenn möglich jedem Haushalt ein Heimlehrpaar zu.
<G-vec00074-002-s372><assign.zuweisen><en> Users assign colors to the alphabet according to their own feeling.
<G-vec00074-002-s372><assign.zuweisen><de> Benutzer weisen dem Alphabet nach eigener Empfindung Farben zu.
<G-vec00074-002-s373><assign.zuweisen><en> Using various rating methodologies, the analysts assess the credit profile of and the outlook for each issuer and subsequently assign them a credit rating.
<G-vec00074-002-s373><assign.zuweisen><de> Mithilfe standardisierter Ratingmethodik beurteilen die Analysten das Kreditprofil und den Ausblick für jeden Emittenten und weisen diesem anschließend ein Kreditrating zu.
<G-vec00074-002-s374><assign.zuweisen><en> Assign your customers and prospective customers to specific sales tours, automatically create appointments and visit reports and assess your tours.
<G-vec00074-002-s374><assign.zuweisen><de> Weisen Sie Kunden und Interessenten bestimmte Vertriebstouren zu, lassen Sie sich automatisch Termine und Besuchsberichte erzeugen und werten Sie Ihre Touren aus.
<G-vec00074-002-s375><assign.zuweisen><en> The switches assign the CV input of each section individually either to the duration parameter or the shape parameter.
<G-vec00074-002-s375><assign.zuweisen><de> Die Schalter weisen den CV-Eingang jeder Sektion separat entweder auf den Parameter Duration oder Parameter Shape zu.
<G-vec00074-002-s376><assign.zuweisen><en> We assign our expert orders to the most appropriate IT expert to obtain the best results.
<G-vec00074-002-s376><assign.zuweisen><de> Wir weisen unsere Gutachtenaufträge dem am besten geeigneten IT-Sachverständigen zu, um ein optimales Ergebnis zu erhalten.
<G-vec00074-002-s377><assign.zuweisen><en> You may choose any number of strategies that correspond exactly to your needs and assign them to individual products or entire product groups.
<G-vec00074-002-s377><assign.zuweisen><de> Legen Sie beliebig viele Strategien an, die genau Ihren Bedürfnissen entsprechen und weisen Sie diese einzelnen Produkten oder ganzen Produktgruppen zu.
<G-vec00074-002-s378><assign.zuweisen><en> After signing contracts, prison guards assign work to each and every cell to fulfill these large contracts.
<G-vec00074-002-s378><assign.zuweisen><de> Nach Abschluss der Verträge weisen Gefängniswärter allen in jeder Zelle die Arbeitsmenge zu.
<G-vec00074-002-s379><assign.zuweisen><en> Our staff will check you in, assign you a parking space and help you transfer your luggage to the shuttle bus.
<G-vec00074-002-s379><assign.zuweisen><de> Unsere Mitarbeiter checken dich ein, weisen dir einen Parkplatz zu, helfen dir mit dem Umladen deines Gepäcks in den Shuttlebus.
<G-vec00074-002-s380><assign.zuweisen><en> Assign a Responsible Team but do not assign a Confirmation Team and do not attach any QA Checklist
<G-vec00074-002-s380><assign.zuweisen><de> Weisen Sie ein verantwortliches Team zu, aber weisen Sie kein prüfendes Team zu und hängen Sie keine QA-Checkliste an.
<G-vec00074-002-s381><assign.zuweisen><en> To let them move one after the other, you assign different postponements for the fixtures and their position will shift as the illustration above shows.
<G-vec00074-002-s381><assign.zuweisen><de> Um Sie nun hintereinander zu setzen weisen Sie Ihnen verschiedene Phasenverschiebungen zu und die Position der Scanner verschiebt sich nach obigem Bild.
<G-vec00074-002-s382><assign.zuweisen><en> We assign a project manager who performs this otherwise time-consuming task for you.
<G-vec00074-002-s382><assign.zuweisen><de> Diese Aufgabe weisen wir einem Projektmanager zu, der diese ansonsten recht zeitraubende Arbeit übernimmt.
<G-vec00074-002-s383><assign.zuweisen><en> Using this input field you assign the user an individual VLAN ID.
<G-vec00074-002-s383><assign.zuweisen><de> Über dieses Eingabefeld weisen Sie dem Benutzer eine individuelle VLAN-ID zu.
<G-vec00074-002-s384><assign.zuweisen><en> Assign never-busy local or toll-free fax numbers directly to users
<G-vec00074-002-s384><assign.zuweisen><de> Weisen Sie persönliche lokale und gebührenfreie Faxnummern Benutzern direkt zu.
<G-vec00074-002-s385><assign.zuweisen><en> We stop the recording and give a name to it and assign a shortcut.
<G-vec00074-002-s385><assign.zuweisen><de> Wir stoppen die Aufnahme, geben ihr einen Namen und weisen ihr einer Taste zu.
<G-vec00074-002-s386><assign.zuweisen><en> Skills-Based Routing Automatically assign tickets to the right agents based on their skills, presence and workload.
<G-vec00074-002-s386><assign.zuweisen><de> Weisen Sie Tickets automatisch den richtigen Kundenserviceagenten zu – basierend auf Fertigkeiten, Anwesenheit und Arbeitspensum –, damit Ihre Kunden sofort Hilfe erhalten und Ihre Agenten nicht überlastet sind.
<G-vec00074-002-s387><assign.zuweisen><en> If you are selected for our program, we’ll work with you to understand your interests and assign you to a case that aligns with your personal and professional goals.
<G-vec00074-002-s387><assign.zuweisen><de> Wenn Sie für unser Praktikantenprogramm ausgewählt werden, setzen wir uns mit Ihnen zusammen und weisen Sie einem Fall zu, der zu Ihren Interessen und zu Ihren beruflichen Zielen passt.
<G-vec00074-002-s388><assign.zuweisen><en> Many Catholic investigators even at the present time assign the book to the reign of Solomon; the masterly poetic form points to this brilliant period of Hebrew poetry.
<G-vec00074-002-s388><assign.zuweisen><de> Viele katholische Ermittler auch in der heutigen Zeit weisen auf das Buch der Herrschaft von Salomo, der meisterhaft poetischen Form zeigt auf dieses brillanten Zeitraum von hebräischen Poesie.
<G-vec00074-002-s389><assign.zuweisen><en> Track your leads in a CRM tool and assign them the right source and generated revenue.
<G-vec00074-002-s389><assign.zuweisen><de> Verfolgen Sie Ihre Leads in einem CRM-Tool und weisen Sie ihnen die richtige Quelle und den erzielten Umsatz zu.
<G-vec00074-002-s390><assign.zuweisen><en> First assign a phone number to one of the number keys, 2 to 9.
<G-vec00074-002-s390><assign.zuweisen><de> Weisen Sie zuerst einer Telefonnummer eine Zifferntaste (2 bis 9) zu.
<G-vec00074-002-s391><assign.zuweisen><en> In After Effects, assign as much space as possible to the Disk Cache folder (on a separate fast drive) for best performance.
<G-vec00074-002-s391><assign.zuweisen><de> Um optimale Leistung zu erhalten, weisen Sie in After Effects dem Disk-Cache-Ordner so viel Platz wie möglich zu (auf einem separaten schnellen Laufwerk).
<G-vec00074-002-s392><assign.zuweisen><en> Then, to assign the virtual desktop or application to a user, you create a machine catalog and a delivery group containing the computer that hosts the graphical application.
<G-vec00074-002-s392><assign.zuweisen><de> Weisen Sie anschließend den virtuellen Desktop oder die virtuelle Anwendung einem Benutzer zu, indem Sie einen Maschinenkatalog und eine Bereitstellungsgruppe mit dem Computer erstellen, der die Grafikanwendung hostet.
<G-vec00074-002-s393><assign.zuweisen><en> Click Permissions, and then assign permissions that allow users to install the service pack from this folder.
<G-vec00074-002-s393><assign.zuweisen><de> Klicken Sie auf Berechtigungen, und weisen Sie dann Berechtigungen zu, die Benutzern das Installieren des Service Packs aus diesem Ordner erlauben.
<G-vec00074-002-s394><assign.zuweisen><en> Assign a unique number to it.
<G-vec00074-002-s394><assign.zuweisen><de> Weisen Sie ihm eine eindeutige Nummer zu.
<G-vec00074-002-s395><assign.zuweisen><en> Please assign a menu to the primary menu location under Menus.
<G-vec00074-002-s395><assign.zuweisen><de> Bitte weisen Sie ein Menü mit dem primären Speicherort unter Schöffel Vor.
<G-vec00074-002-s396><assign.zuweisen><en> Please assign a menu under Menus or Customize the design.
<G-vec00074-002-s396><assign.zuweisen><de> Bitte weisen Sie ein Menü mit dem primären Speicherort unter Menü Menüs.
<G-vec00074-002-s397><assign.zuweisen><en> Assign each goal to the appropriate person, so everyone knows who’s responsible, and who to go to with questions.
<G-vec00074-002-s397><assign.zuweisen><de> Weisen Sie jedes Ziel der richtigen Person zu, damit jeder weiß, wer verantwortlich ist und an wen man sich mit Fragen wenden kann.
<G-vec00074-002-s398><assign.zuweisen><en> Do not assign this account interactive logon permissions.
<G-vec00074-002-s398><assign.zuweisen><de> Weisen Sie diesem Konto keine Rechte zur interaktiven Anmeldungen zu.
<G-vec00074-002-s399><assign.zuweisen><en> Maintenance—Schedule preventive maintenance, and assign resources where they'll do the most good.
<G-vec00074-002-s399><assign.zuweisen><de> Instandhaltung - Planen Sie die vorbeugende Wartung und weisen Sie die Ressourcen bedarfsorientiert zu.
<G-vec00074-002-s400><assign.zuweisen><en> Assign desktops and policy to remote, disconnected users based on Active Directory credentials.
<G-vec00074-002-s400><assign.zuweisen><de> Weisen Sie Remote-Anwendern ohne Netzwerkverbindung Desktops und Richtlinien basierend auf Anmeldeinformationen von Active Directory zu.
<G-vec00074-002-s401><assign.zuweisen><en> Assign tasks and subtasks to others, and track progress to make sure nothing slips through the cracks.
<G-vec00074-002-s401><assign.zuweisen><de> Weisen Sie anderen Aufgaben und Unteraufgaben zu und verfolgen Sie den Fortschritt, um sicherzustellen, dass nichts vergessen wird.
<G-vec00074-002-s402><assign.zuweisen><en> Compose custom click patterns with up to four different accent levels in the new Click Pattern Editor, and assign several different patterns to the Signature Track.
<G-vec00074-002-s402><assign.zuweisen><de> Komponieren Sie eigene Click Patterns mit bis zu vier verschiedenen Betonungspegeln im neuen Click Pattern Editor und weisen Sie mehrere unterschiedliche Patterns der Taktart-Spur zu.
<G-vec00074-002-s403><assign.zuweisen><en> Assign the right staff at the right times and get valuable insights into your productivity and labor costs.
<G-vec00074-002-s403><assign.zuweisen><de> Weisen Sie die richtigen Mitarbeiter zur richtigen Zeit zu und erhalten Sie wertvolle Einblicke in Ihre Produktivität und Ihre Lohnkosten.
<G-vec00074-002-s404><assign.zuweisen><en> First, assign a number.
<G-vec00074-002-s404><assign.zuweisen><de> Erstens weisen Sie eine Zahl ein.
<G-vec00074-002-s405><assign.zuweisen><en> Note: Assign as many elements to the Design Attribute as you like; they will be active not before a condition was assigned to the element and this condition is true.
<G-vec00074-002-s405><assign.zuweisen><de> Hinweis: Weisen Sie beliebig viele Elemente einem Design Attribut zu; sie werden erst aktiv, wenn dem jeweiligen Element eine Bedingung hinzugefügt wurde und diese Bedingung zutrifft.
<G-vec00074-002-s407><assign.zuweisen><en> Assign new roles to recipients.
<G-vec00074-002-s407><assign.zuweisen><de> Weisen Sie Empfängern Rollen zu.
<G-vec00074-002-s408><assign.zuweisen><en> Assign User - assign user to a device.
<G-vec00074-002-s408><assign.zuweisen><de> Benutzer zuweisen... – Weisen Sie einen Benutzer zu einem Gerät zu.
<G-vec00074-002-s409><assign.zuweisen><en> 3. Where a computer algorithm within the investment firm is responsible for the investment decision in accordance with paragraph 1, the investment firm shall assign a designation for identifying the computer algorithm in a transaction report.
<G-vec00074-002-s409><assign.zuweisen><de> (3) Ist gemäß Absatz 1 ein Computeralgorithmus in der Wertpapierfirma für die Anlageentscheidung verantwortlich, weist die Wertpapierfirma dem Computeralgorithmus eine Bezeichnung für dessen Identifizierung in einer Geschäftsmeldung zu.
<G-vec00074-002-s410><assign.zuweisen><en> The idea of the Euro is as follows: first, assign the lead to Germany as chief partner / banker / accomplice of the plan, chief economic force of the Union, and chief exporter; then let all the other weaker players (PIGs, Spain, Italy), who produce virtually nothing, indebt themselves vis-à-vis Germany and Anglo-American banks, which, in turn, make good money from the yield on these Euro-bonds (the debt spiral).
<G-vec00074-002-s410><assign.zuweisen><de> Der Grundgedanke des Euro ist folgender: zunächst weist man Deutschland eine Führungsrolle als dem Primärpartner/Banker/Komplizen, ökonomisch stärkstem Staat der Union und Hauptexporteur zu; dann erlaubt man all den anderen, schwächeren Mitspielern (PIGs, Spanien, Italien), die praktisch nichts herstellen, sich vis-à-vis Deutschlands und anglo-amerikanischer Banken zu verschulden, welche wiederum hohe Gewinne durch die Zinsen auf diese Euro-Bonds einfahren (die Schuldenspirale).
<G-vec00074-002-s411><assign.zuweisen><en> Assign the selected skin to the mesh subset that consists of all currently selected model faces or groups (sse below).
<G-vec00074-002-s411><assign.zuweisen><de> Weist die selektierte Skin dem aus sämtlichen ausgewählten Modelloberflächen oder Gruppen bestehenden Mesh-Subset (Untergruppe) zu*.
<G-vec00074-002-s412><assign.zuweisen><en> Citrix Hypervisor does not automatically assign a role to the newly created user.
<G-vec00074-002-s412><assign.zuweisen><de> HASH (0x2e68218) weist dem neu erstellten Benutzer nicht automatisch eine Rolle zu.
<G-vec00074-002-s413><assign.zuweisen><en> In order to access some features of this Site‚ you may be required to register and We may assign to you, or you may be required to select, a password and user name or account identification.
<G-vec00074-002-s413><assign.zuweisen><de> Virago-forum.de weist Ihnen möglicherweise ein Kennwort und eine Kontoidentifikation zu, damit Sie auf bestimmte Teile dieser Website zugreifen und diese verwenden können.
<G-vec00074-002-s414><assign.zuweisen><en> · The Administrators group will assign people to the System Administrators role.
<G-vec00074-002-s414><assign.zuweisen><de> ・ Die Administratorengruppe weist Personen der Systemadministratorrolle zu.
<G-vec00074-002-s415><assign.zuweisen><en> If you are logged in to Facebook, Facebook can directly assign the search of our website to your Facebook account.
<G-vec00074-002-s415><assign.zuweisen><de> Die so gesammelten Informationen weist Facebook womöglich Ihrem dortigen persönlichen Nutzerkonto zu.
<G-vec00074-002-s416><assign.zuweisen><en> The Quantum Hybrid Trader Trading system will automatically assign a broker for you.
<G-vec00074-002-s416><assign.zuweisen><de> Das CryptoRobo Trading-System weist Ihnen automatisch einen Broker zu.
<G-vec00074-002-s417><assign.zuweisen><en> If you are logged into Instagram, Instagram may assign the visit to our site to your Instagram account and link the data by this means.
<G-vec00074-002-s417><assign.zuweisen><de> Sollten Sie gleichzeitig bei YouTube eingeloggt sein, weist YouTube die Verbindungsinformationen Ihrem YouTube-Konto zu.
<G-vec00074-002-s418><assign.zuweisen><en> The DHCP server will assign a new IP address for your computer.
<G-vec00074-002-s418><assign.zuweisen><de> Der DHCP-Server weist Ihrem Computer eine neue IP-Adresse zu.
<G-vec00074-002-s419><assign.zuweisen><en> 3. Where a computer algorithm within the investment firm is responsible for the execution of the transaction, the investment firm shall assign a designation for identifying the computer algorithm in accordance with Article 8(3).
<G-vec00074-002-s419><assign.zuweisen><de> (3) Ist ein Computeralgorithmus in der Wertpapierfirma für die Ausführung des Geschäfts verantwortlich, weist die Wertpapierfirma diesem Computeralgorithmus im Einklang mit Artikel 8 Absatz 3 eine Bezeichnung für dessen Identifizierung zu.
<G-vec00074-002-s420><assign.zuweisen><en> The Bitcoin Profit Trading system will automatically assign a broker for you.
<G-vec00074-002-s420><assign.zuweisen><de> Das Bitcoin Code 2018 Trading-System weist Ihnen automatisch einen Broker zu.
<G-vec00074-002-s421><assign.zuweisen><en> assign letter=L Assigns a drive letter, L, to the volume with focus.
<G-vec00074-002-s421><assign.zuweisen><de> Weist dem Volume mit Fokus einen Laufwerkbuchstaben oder einen Ordnerpfad mit Bereitstellungspunkt zu.focus.
<G-vec00074-002-s422><assign.zuweisen><en> The Welfare Office does not assign children to daycare centres, however; the decision on who to take up lies with the centres themselves.
<G-vec00074-002-s422><assign.zuweisen><de> Das Amt weist jedoch keine Plätze zu, die Entscheidung liegt bei den jeweiligen Einrichtungen selbst.
<G-vec00074-002-s423><assign.zuweisen><en> If, for technical/operational reasons, the seat assigned in the reservation is unavailable, the on board personnel will assign a replacement seat according to availability.
<G-vec00074-002-s423><assign.zuweisen><de> Sollte aus technischen/betrieblichen Gründen der in der Reservierung ausgewiesene Sitzplatz nicht zur Verfügung stehen, weist das Bordpersonal nach Verfügbarkeit einen Ersatzsitzplatz zu.
<G-vec00074-002-s425><assign.zuweisen><en> With that out of the way, if you unplug your modem for a few hours (yep, hours), your ISP will very likely assign you a new IP address when you reconnect to their system.
<G-vec00074-002-s425><assign.zuweisen><de> Wenn Sie Ihr Modem für einige Stunden vom Netz trennen (ja, Stunden), weist Ihnen Ihr Internetdienstanbieter höchstwahrscheinlich eine neue IP-Adresse zu, wenn Sie die Verbindung zu seinem System wiederherstellen.
<G-vec00074-002-s426><assign.zuweisen><en> Router 1’s DHCP server will automatically assign each device its own IP address in the same subnet.
<G-vec00074-002-s426><assign.zuweisen><de> Der DHCP-Server von Router 1 weist jedem Gerät automatisch seine eigene IP-Adresse im gleichen Subnet zu.
<G-vec00074-002-s427><assign.zuweisen><en> Like in the major system, you assign each number a letter, although the associations are arbitrary.
<G-vec00074-002-s427><assign.zuweisen><de> Wie im großen System weist du jeder Zahl einen Buchstaben zu, auch wenn die Verknüpfungen beliebig sind.
<G-vec00074-002-s455><assign.zuweisen><en> It is also important to assign the ‘Permanent’ criterion to all combinations.
<G-vec00074-002-s455><assign.zuweisen><de> Wichtig ist auch, dass allen Kombinationen das Kriterium "Ständig" zugewiesen wird.
<G-vec00074-002-s456><assign.zuweisen><en> Having incorporated MELAseal 200 or MELAseal Pro in MELAtrace, you require only a few steps to assign the sealing logs and integrate them in the tamper-proof decontamination report.
<G-vec00074-002-s456><assign.zuweisen><de> Haben Sie MELAseal 200 oder MELAseal Pro erfolgreich in MELAtrace eingebunden, können auch die Siegelprotokolle in wenigen Schritten zugewiesen und in das fälschungssichere Aufbereitungsprotokoll integriert werden.
<G-vec00074-002-s457><assign.zuweisen><en> Select a server from the Home Server list to assign a home server for the VM and click Next.
<G-vec00074-002-s457><assign.zuweisen><de> Wählen Sie in der Liste Heimserver einen Server aus, der als Home-Server für die VM zugewiesen werden soll, und klicken Sie auf Weiter .
<G-vec00074-002-s458><assign.zuweisen><en> The task is to find out rules and interrelations which assign tables to two different categories.
<G-vec00074-002-s458><assign.zuweisen><de> Die Aufgabe besteht darin, Regeln und Zusammenhänge zu entdecken, nach denen Tabellen zwei unterschiedlichen Kategorien zugewiesen werden.
<G-vec00074-002-s459><assign.zuweisen><en> Track, monitor and assign alarms to mission critical applications running in VMs, regardless of location, in order to meet SLAs and help support compliance initiatives
<G-vec00074-002-s459><assign.zuweisen><de> Kategorisierung nach GeschäftsbereichenNEU: Benachrichtigungen werden unabhängig vom Standort nachverfolgt, überwacht und geschäftskritischen Anwendungen auf VMs zugewiesen, um SLAs und Compliance-Vorgaben einzuhalten.
<G-vec00074-002-s460><assign.zuweisen><en> They will assign the vehicle to you after the auction concludes.
<G-vec00074-002-s460><assign.zuweisen><de> Das Fahrzeug wird Ihnen nach Auktionsende garantiert zugewiesen.
<G-vec00074-002-s461><assign.zuweisen><en> Once you assign several components and customize your game objects, you’ll often want to reuse them across the same scene or even multiple scenes or games.
<G-vec00074-002-s461><assign.zuweisen><de> Nachdem Sie mehrere Komponenten zugewiesen und Ihre Spielobjekte angepasst haben, wäre es von Vorteil, sie innerhalb einer Szene oder sogar szenen- oder spielübergreifend wiederzuverwenden.
<G-vec00074-002-s462><assign.zuweisen><en> If this is not the desired result (having the same output values for cells allocated to regions that may spatially be far apart), use the Region Group tool of the Generalize tools on the source data, which will assign new values for each connected region.
<G-vec00074-002-s462><assign.zuweisen><de> Wenn dies nicht das gewünschte Ergebnis ist (weil Zellen, die Regionen zugeordnet wurden, die möglicherweise räumlich weit auseinander liegen, die gleichen Ausgabewerte haben), verwenden Sie das Werkzeug Region Group der Generalisieren-Werkzeuge für Quelldaten, wodurch jeder verbundenen Region neue Werte zugewiesen werden.
<G-vec00074-002-s463><assign.zuweisen><en> If the IP address starts with 169 then either no network is detected or the router did not assign an IP address automatically (DHCP mode) and Windows assigned the default IP address internally to the computer.
<G-vec00074-002-s463><assign.zuweisen><de> Wenn die IP-Adresse mit 169 beginnt, wurde entweder das Netzwerk nicht erkannt oder dem Computer vom Router keine gültige IP-Adresse zugewiesen (DHCP-Modus), weshalb Windows die standardmäßige IP-Adresse verwendet.
<G-vec00074-002-s464><assign.zuweisen><en> The following currencies are available for deposit, withdrawal or play. By default, on account registration we assign the most logical currency according to where we believe you are registering from.
<G-vec00074-002-s464><assign.zuweisen><de> Folgende Währungen stehen für Einzahlung, Abhebung und Spielen zur Verfügung: In der Standardeinstellung wird eine logische Währung nach vermuteter Herkunft bereits bei der Registrierung eines neuen Accounts zugewiesen.
<G-vec00074-002-s465><assign.zuweisen><en> With the new multiscreen you can assign up to five locomotives to each throttle knob between which you can choose by a simple press of your thumb.
<G-vec00074-002-s465><assign.zuweisen><de> Mit dem Multibildschirm können jedem Regler nun bis zu 5 Loks zugewiesen werden, zwischen denen auf "Daumendruck" umgeschaltet werden kann.
<G-vec00074-002-s466><assign.zuweisen><en> In addition, and for the optimum distribution of the products and their proper control, an option is also available for dividing the warehouses into different physical locations. The user has the ability to assign a warehouse to each product according to their characteristics.
<G-vec00074-002-s466><assign.zuweisen><de> Außerdem gibt es für eine optimale Produktverteilung über mehrere Lager sowie deren Kontrolle die Option, die Warenlager in verschiedene physische Orte zu unterteilen, die anschließend je nach Eigenschaften den einzelnen Produkten zugewiesen werden.
<G-vec00074-002-s467><assign.zuweisen><en> This makes it possible also to assign appropriate administration access rights and policies.
<G-vec00074-002-s467><assign.zuweisen><de> Dadurch können entsprechende Zugangsrechte und -richtlinien für die Verwaltung zugewiesen werden.
<G-vec00074-002-s468><assign.zuweisen><en> With a Quick Click flag, you can also assign flags to items with a single click.
<G-vec00074-002-s468><assign.zuweisen><de> Mittels einer Schnellklick-Kennzeichnung werden Elementen Kennzeichnungen mit einem einzigen Klick zugewiesen.
<G-vec00074-002-s469><assign.zuweisen><en> Poznámka: Assigning a user group will also assign the associated product profiles to the user.
<G-vec00074-002-s469><assign.zuweisen><de> Durch Zuweisen einer Benutzergruppe werden dem Benutzer gleichzeitig die zugeordneten Produktprofile zugewiesen.
<G-vec00074-002-s470><assign.zuweisen><en> Then you can assign them to members, surfaces, and solids that jointly use one line (see Chapter 4.26).
<G-vec00074-002-s470><assign.zuweisen><de> Diese können dann Stäben, Flächen und Volumenkörpern zugewiesen werden, die eine Linie gemeinsam verwenden (siehe Kapitel 4.26).
<G-vec00074-002-s471><assign.zuweisen><en> In general, you should be sure not to assign permanent values to any variables that you might want to use for more than one purpose.
<G-vec00074-002-s471><assign.zuweisen><de> Im allgemeinen sollte man darauf achten, daß Variablen, die möglicherweise für mehr als einen Zweck benutzt werden könnten, keine permanenten Werte zugewiesen werden.
<G-vec00074-002-s472><assign.zuweisen><en> Assign the highest possible value (shown as 4 in this example) for time-critical PTP events
<G-vec00074-002-s472><assign.zuweisen><de> Zeitkritischen Point-to-Point(-Übertragung)-Ereignissen sollten möglichst hohe Werte (in diesem Beispiel 4) zugewiesen werden.
<G-vec00074-002-s473><assign.zuweisen><en> It is now possible to assign sizing methods to duct and pipe segments, enabling the use of different sizing criteria for the same duct or pipe segment depending on the location.
<G-vec00074-002-s473><assign.zuweisen><de> Ab sofort können Kanal- und Rohrsegmenten Dimensionierungsmethoden zugewiesen werden, sodass innerhalb eines Netzwerks unterschiedliche Dimensionierungskriterien verwendet werden können.
<G-vec00074-002-s474><assign.zuweisen><en> Note: It's possible to assign a role directly to a user without using a role group.
<G-vec00074-002-s474><assign.zuweisen><de> Hinweis: Eine Rolle kann einem Benutzer direkt und ohne Verwendung einer Rollengruppe zugewiesen werden.
<G-vec00074-002-s476><assign.zuweisen><en> Either disable the firewall entirely or assign the browsing interface to the internal firewall zone.
<G-vec00074-002-s476><assign.zuweisen><de> Hierzu muss die Firewall entweder vollständig deaktiviert werden oder der internen Firewall-Zone muss die Browsing-Schnittstelle zugewiesen werden.
<G-vec00074-002-s477><assign.zuweisen><en> In the Name Snapshot step, you can assign a name to an inventory scan.
<G-vec00074-002-s477><assign.zuweisen><de> Mit dem Einzelschritt Snapshot bezeichnen kann einem Inventarisierungsvorgang eine Bezeichnung zugewiesen werden.
<G-vec00074-002-s478><assign.zuweisen><en> It is now possible to assign operators to a specific department right from the department settings screen.
<G-vec00074-002-s478><assign.zuweisen><de> Jetzt können Operatoren direkt aus den Abteilungseinstellungen heraus einer bestimmten Abteilung zugewiesen werden.
<G-vec00074-002-s479><assign.zuweisen><en> We’ve seen in the previous examples, how to assign values to variables.
<G-vec00074-002-s479><assign.zuweisen><de> Die bisherigen Beispiele haben gezeigt, wie Variablen Werte zugewiesen werden.
<G-vec00074-002-s480><assign.zuweisen><en> You can assign multiple customer types to one characteristic.
<G-vec00074-002-s480><assign.zuweisen><de> Einer Eigenschaft können mehrere Kundentypen zugewiesen werden.
<G-vec00074-002-s481><assign.zuweisen><en> Assign an IP address If your All-In-One is listed as unconfigured in the Printer Selection dialog or the Network Printer Configuration dialog, you must assign it an IP address on your print server or network adapter.
<G-vec00074-002-s481><assign.zuweisen><de> Wenn der All-In-One im Dialogfenster für die Druckerauswahl oder im Dialogfenster "Netzwerkdruckerkonfiguration" als nicht konfiguriert aufgeführt ist, muss dem Gerät auf dem Druckserver oder dem Netzwerkadapter eine IP-Adresse zugewiesen werden.
<G-vec00074-002-s482><assign.zuweisen><en> Only the current FedEx Billing Online Administrator can assign a new administrator.
<G-vec00074-002-s482><assign.zuweisen><de> Ein neuer Administrator kann nur vom aktuellen FedEx Billing Online Administrator zugewiesen werden.
<G-vec00074-002-s483><assign.zuweisen><en> Choose session policies to assign to this Jump Item.
<G-vec00074-002-s483><assign.zuweisen><de> Wählen Sie Sitzungsrichtlinien, die diesem Jump-Element zugewiesen werden sollen.
<G-vec00074-002-s484><assign.zuweisen><en> If you wish to use our Customer Center, you must sign up by specifying your personal information and position, which allows us to assign you the appropriate access permissions for the individual modules, and accept the terms of use for the portal.
<G-vec00074-002-s484><assign.zuweisen><de> Sofern Sie unser Customer Center nutzen möchten, müssen Sie sich mittels Angabe Ihrer personenbezogenen Daten und unter Angabe Ihrer Position registrieren, damit Ihnen die passenden Zugangsrechte zu den Einzelmodulen zugewiesen werden können, und die Nutzungsbedingungen des Portals akzeptieren.
<G-vec00074-002-s485><assign.zuweisen><en> When a memory DIMM is added to a system, the operating system doesn't force you to invoke some commands to configure the memory and assign it to individual processes.
<G-vec00074-002-s485><assign.zuweisen><de> Wenn ein System um neue DIMM-Speicherchips erweitert wird, brauchen Sie auf Betriebssystemebene keine Befehle einzugeben, mit denen dieser neue Speicher konfiguriert und zu einzelnen Prozessen zugewiesen werden muss.
<G-vec00074-002-s486><assign.zuweisen><en> However, if your forest will have multiple sites, you must create subnets that assign IP addresses to Default-First-Site-Name as well as to all additional sites.
<G-vec00074-002-s486><assign.zuweisen><de> Wenn die Gesamtstruktur jedoch über mehrere Standorte verfügen soll, müssen Sie Subnetze erstellen, mit denen sowohl Standardname-des-ersten-Standorts als auch allen weiteren Standorten IP-Adressen zugewiesen werden.
<G-vec00074-002-s487><assign.zuweisen><en> To request a change to the item to be approved, click Request a change, specify to whom you want to assign the change request, provide information about the change requested, and then click Send.
<G-vec00074-002-s487><assign.zuweisen><de> Klicken Sie zum Anfordern einer Änderung am zu genehmigenden Element auf Änderung anfordern, geben Sie an, wem die Änderungsanforderung zugewiesen werden soll, geben Sie Informationen zur angeforderten Änderung an, und klicken Sie dann auf Senden.
<G-vec00074-002-s488><assign.zuweisen><en> Buttons on the control panel to which you can assign certain test functions from the software.
<G-vec00074-002-s488><assign.zuweisen><de> Tasten an der Steuerkonsole, denen von der Software bestimmte Prüffunktionen zugewiesen werden können.
<G-vec00074-002-s560><assign.zuweisen><en> Personal Firewall – You can now create firewall rules directly from the log or IDS notification window and assign profiles to network interfaces.
<G-vec00074-002-s560><assign.zuweisen><de> Personal Firewall - Sie können Firewall-Regeln jetzt direkt im Log oder im IDS-Benachrichtigungsfenster erstellen und Netzwerkschnittstellen Profile zuweisen.
<G-vec00074-002-s561><assign.zuweisen><en> Select the HTML radio button for default profile in the assign task step while using Workbench.
<G-vec00074-002-s561><assign.zuweisen><de> Wählen Sie bei der Verwendung von Workbench im Schritt zum Zuweisen der Aufgabe das HTML-Optionsfeld für das Standardprofil aus.
<G-vec00074-002-s562><assign.zuweisen><en> One can not tell the scanner send to folder "XY" or simply assign a network folder, you always have to choose a computer so that he scans.
<G-vec00074-002-s562><assign.zuweisen><de> Man kann den Scanner nicht an den Ordner "XY" schicken oder einfach einen Netzwerkordner zuweisen, man muss immer einen Computer auswählen, damit er scannt.
<G-vec00074-002-s563><assign.zuweisen><en> In the Printer description field, you can assign your printer a unique name for identification.
<G-vec00074-002-s563><assign.zuweisen><de> In dem Feld Druckerbeschreibung können Sie dem Drucker einen zur Identifikation eindeutigen Namen zuweisen.
<G-vec00074-002-s564><assign.zuweisen><en> ref readonly In a ref readonly method return, the readonly modifier indicates that method returns a reference and writes are not allowed to that reference. The final two contexts were added in C# 7.2. In this example, the value of the field year cannot be changed in the method ChangeYear, even though it is assigned a value in the You can assign a value to a readonly field only in the following contexts:
<G-vec00074-002-s564><assign.zuweisen><de> In diesem Beispiel kann der Wert des Felds year nicht zur Methode ChangeYear geändert werden, obwohl ihm im Klassenkonstruktor ein Wert zugewiesen ist:Sie können einem readonly-Feld nur in den folgenden Kontexten einen Wert zuweisen:Ein const-Feld kann nur bei der Deklaration des Felds initialisiert werden.A const Daher können readonly-Felder abhängig vom verwendeten Konstruktor über unterschiedliche Werte verfügen.Therefore, readonly fields can have different values depending on the constructor used.
<G-vec00074-002-s565><assign.zuweisen><en> Second example: if a server hosts 2 VOSEs (and no POSE), each used by the same 150 users, then you must assign 150 licenses to the server.
<G-vec00074-002-s565><assign.zuweisen><de> Zweites Beispiel: Wenn ein Server zwei VOSEs (und keine POSE) hostet, die jeweils von denselben 150 Usern verwendet werden, müssen Sie dem Server 150 Lizenzen zuweisen.
<G-vec00074-002-s566><assign.zuweisen><en> You may also assign the task to a role, set the default priority, provide a description, and specify a time when the task is due.
<G-vec00074-002-s566><assign.zuweisen><de> Sie können die Aufgabe auch einer Rolle zuweisen, die Standardpriorität festlegen, eine Beschreibung angeben und einen Fälligkeitszeitpunkt für die Aufgabe bestimmen.
<G-vec00074-002-s567><assign.zuweisen><en> The two most common ways to use expressions in tables are to assign a default value and to create a validation rule.
<G-vec00074-002-s567><assign.zuweisen><de> Die beiden am häufigsten genutzten Verwendungsmöglichkeiten für Ausdrücke in Tabellen sind das Zuweisen eines Standardwerts und das Erstellen einer Gültigkeitsregel.
<G-vec00074-002-s568><assign.zuweisen><en> 0-100 If you want to assign a color category to your task, on the Task tab, in the Options group, click Categorize, and then click one of the color categories on the menu.
<G-vec00074-002-s568><assign.zuweisen><de> Zurückgestellt 0-100 Wenn Sie Ihrer Aufgabe eine Farbkategorie zuweisen möchten, klicken Sie auf der Registerkarte Aufgabe in der Gruppe Optionen auf Kategorisieren, und klicken Sie dann auf eine der Farbkategorien im Menü.
<G-vec00074-002-s569><assign.zuweisen><en> Go there and assign a license to StyleVision Server.
<G-vec00074-002-s569><assign.zuweisen><de> Sie können nun zu LicenseServer wechseln und StyleVision Server eine Lizenz zuweisen.
<G-vec00074-002-s570><assign.zuweisen><en> On the first tab you can adjust the operation mode and assign a name to your bluetooth adapter.
<G-vec00074-002-s570><assign.zuweisen><de> Auf der ersten Registerkarte kannst Du den Operationsmodus einstellen und Deinem Bluetooth Adapter einen Namen zuweisen.
<G-vec00074-002-s571><assign.zuweisen><en> Why use a security group in Exchange Online? If you create a security group in Exchange Online, you can use this same group to assign permissions in both SharePoint Online and Exchange Online.
<G-vec00074-002-s571><assign.zuweisen><de> Gründe für die Erstellung einer Sicherheitsgruppe in Exchange Online: Wenn Sie in Exchange Online eine Sicherheitsgruppe erstellen, können Sie diese Gruppe zum Zuweisen von Berechtigungen in SharePoint Online und in Exchange Online verwenden.
<G-vec00074-002-s572><assign.zuweisen><en> This feature allows you to assign different rights to your single users.
<G-vec00074-002-s572><assign.zuweisen><de> Mit dieser Funktion können Sie den einzelnen Benutzern unterschiedliche Rechte zuweisen.
<G-vec00074-002-s573><assign.zuweisen><en> You can assign a special color to the non-displayable invocations.
<G-vec00074-002-s573><assign.zuweisen><de> Sie können nicht anzeigbaren Aufrufen eine spezielle Farbe zuweisen.
<G-vec00074-002-s574><assign.zuweisen><en> How you can assign roles to users, can be found out here
<G-vec00074-002-s574><assign.zuweisen><de> Wie Du den Nutzern Rollen zuweisen kannst, erfährst du hier.
<G-vec00074-002-s575><assign.zuweisen><en> In that case, you can assign costs that reflect the differences in the communications costs.
<G-vec00074-002-s575><assign.zuweisen><de> In diesem Fall können Sie Kosten zuweisen, die die Unterschiede bei den Kommunikationskosten widerspiegeln.
<G-vec00074-002-s576><assign.zuweisen><en> For example, you could assign your sister to the Family category (fuchsia), coworker contacts to the Team category (blue), and carpool contacts about your carpool to the Personal category (green).
<G-vec00074-002-s576><assign.zuweisen><de> Beispielsweise könnten Sie Ihre Schwester der Kategorie "Familie" (Pink), Mitarbeiterkontakte der Kategorie "Team" (Blau) und Fahrgemeinschaftskontakte der Kategorie "Persönlich" (Grün) zuweisen.
<G-vec00074-002-s577><assign.zuweisen><en> System Password You can assign a System Password for the configuration environment of your Gigaset SE551 WLAN dsl/cable, and specify the period after which a session is to end automatically if no further entry is made.
<G-vec00074-002-s577><assign.zuweisen><de> Systemkennwort Sie können ein Systemkennwort für die Bedienoberfläche des Gigaset SX762 WLAN dsl zuweisen und die Zeitdauer angeben, nach der eine Sitzung automatisch beendet wird, wenn keine Eingabe mehr vorgenommen wurde.
<G-vec00074-002-s578><assign.zuweisen><en> Admirals and captains can now assign multiple Gravitons at a time to a single clan member.
<G-vec00074-002-s578><assign.zuweisen><de> Admiräle und Kapitäne können Clanmitgliedern nun mehr als ein Graviton auf einmal zuweisen.
<G-vec00074-002-s624><assign.zuweisen><en> The specification of the country enables the provider to assign a suitable contact person to the user in case of questions or establishing contact.
<G-vec00074-002-s624><assign.zuweisen><de> Die Angabe des Landes ermöglicht es dem Nutzer geeignete Ansprechpartner zuzuweisen, falls es zu Rückfragen oder einer Kontaktaufnahme kommen sollte.
<G-vec00074-002-s625><assign.zuweisen><en> To assign the request to a team member, select it from the list, click Add assignee and select a member of your team.
<G-vec00074-002-s625><assign.zuweisen><de> Um die Anfrage einem Teammitglied zuzuweisen, wählen Sie sie aus der Liste aus, klicken Sie auf Verantwortlichen hinzufügen und wählen Sie ein passendes Mitglied Ihres Teams aus.
<G-vec00074-002-s626><assign.zuweisen><en> We reserve the right to assign or reassign seats at any time, even after boarding of the aircraft.
<G-vec00074-002-s626><assign.zuweisen><de> Wir behalten uns das Recht vor, Sitzplätze jederzeit zuzuweisen oder neu zuzuweisen, auch nach Betreten des Flugzeugs.
<G-vec00074-002-s627><assign.zuweisen><en> (3) Should this serve the prompter and more effective processing of such orders, the Land governments are authorised to assign summary proceedings for a payment order to a local court acting for the districts of several local courts, doing so by statutory instrument.
<G-vec00074-002-s627><assign.zuweisen><de> (3) Die Landesregierungen werden ermächtigt, durch Rechtsverordnung Mahnverfahren einem Amtsgericht für die Bezirke mehrerer Amtsgerichte zuzuweisen, wenn dies ihrer schnelleren und rationelleren Erledigung dient.
<G-vec00074-002-s628><assign.zuweisen><en> To assign a different style, right click on this component and select the "Set one Column Style" option from the list.
<G-vec00074-002-s628><assign.zuweisen><de> Um einen anderen Stil zuzuweisen, klicken Sie mit der rechten Maustaste auf die Komponente und wählen Sie im Kontextmenü die Option „Set one Column Style„.
<G-vec00074-002-s629><assign.zuweisen><en> It is also possible to assign several leaders to a team.
<G-vec00074-002-s629><assign.zuweisen><de> Ebenfalls ist es möglich, einem Dienst mehrere Dienstverantwortliche zuzuweisen.
<G-vec00074-002-s630><assign.zuweisen><en> Click Finish to create the bundle and assign it to the selected device.
<G-vec00074-002-s630><assign.zuweisen><de> Klicken Sie auf Fertig stellen, um das Bundle zu erstellen und dem ausgewählten Gerät zuzuweisen.
<G-vec00074-002-s631><assign.zuweisen><en> The integration of project and management makes it possible to create projects for specific user groups or organizations in a customized manner and to assign resources & users.
<G-vec00074-002-s631><assign.zuweisen><de> Die integrierte Projekt- und Nutzerverwaltung ermöglicht es gezielt Projekte für spezifische Nutzergruppen oder Gebiete anzulegen und Nutzern zuzuweisen.
<G-vec00074-002-s632><assign.zuweisen><en> To assign an icon, you may either select a predefined icon (Standard tab) or one of you own icons (Custom tab).
<G-vec00074-002-s632><assign.zuweisen><de> Um ein neues Symbol zuzuweisen, können Sie entweder aus vorgegebenen Symbolen wählen (Registerkarte Standard) oder eigene Symbole laden (Registerkarte Benutzerdefiniert).
<G-vec00074-002-s633><assign.zuweisen><en> When you design a database, you might want to assign a default value to a field or control.
<G-vec00074-002-s633><assign.zuweisen><de> Beim Entwerfen einer Datenbank haben Sie die Möglichkeit, einem Feld oder Steuerelement einen Standardwert zuzuweisen.
<G-vec00074-002-s634><assign.zuweisen><en> Click the Set button to assign the bone and morph data into the selected thumbnail.
<G-vec00074-002-s634><assign.zuweisen><de> Klicken Sie den Einstellung Button, um dem gewählten Vorschaubild Knochen und Morph Daten zuzuweisen.
<G-vec00074-002-s635><assign.zuweisen><en> The QSEC task manager starting from version 5.2 provide a fast, simple and dynamic tool to register, to assign and to edit tasks in addition to the measure management.
<G-vec00074-002-s635><assign.zuweisen><de> Der QSEC Task-Manager bietet ab Version 5.2 als Ergänzung zum Maßnahmenmanagement ein schnelles, einfaches und dynamisches Werkzeug, um Aufgaben zu erstellen, zuzuweisen und zu bearbeiten.
<G-vec00074-002-s636><assign.zuweisen><en> The option to assign your personal favourite settings to such a button forms a simply luxurious asset for an entry-level model like the Pentax W10.
<G-vec00074-002-s636><assign.zuweisen><de> Eine solche Möglichkeit, persönliche Favoriten zuzuweisen, ist für ein Einsteigermodell wie die Pentax W10 ein Luxus.
<G-vec00074-002-s637><assign.zuweisen><en> Currently it's only recommended not to assign PCI devices to untrusted guests.
<G-vec00074-002-s637><assign.zuweisen><de> Bis dieses Problem behoben werden kann, wird empfohlen, nicht vertrauenswürdigen Gastsystemen keine PCI Devices zuzuweisen.
<G-vec00074-002-s638><assign.zuweisen><en> Click OK to assign the selected categories and close the Assign Categories window.
<G-vec00074-002-s638><assign.zuweisen><de> Klicken Sie auf 'OK', um die ausgewählten Kategorien zuzuweisen und das Dialogfenster 'Kategorien zuweisen' zu schließen.
<G-vec00074-002-s639><assign.zuweisen><en> TAMPLO is a collaborative cloud-based project and meeting management software designed to help teams set-up projects, assign tasks, and track their completion with collaboration and prioritization tools.
<G-vec00074-002-s639><assign.zuweisen><de> TAMPLO ist eine cloudbasierte Task- und Meeting-Management-Software, die Teams aller Größenordnungen dabei hilft, Projekte zu erstellen, Aufgaben zuzuweisen und sie bis zur Fertigstellung zu verfolgen.
<G-vec00074-002-s640><assign.zuweisen><en> To assign a specific static IP address, enter something such as: ifconfig eth0 192.168.10.17 .
<G-vec00074-002-s640><assign.zuweisen><de> Um eine spezielle, statische IP-Adresse zuzuweisen: ifconfig eth0 192.168.10.17 .
<G-vec00074-002-s641><assign.zuweisen><en> In many congregations, each Elder or Ministerial Servant uses a different program, spreadsheet or method to produce schedules, maintain lists, and assign talks and parts.
<G-vec00074-002-s641><assign.zuweisen><de> In vielen Gemeinden verwendet jeder Älteste oder Ministerialbedienstete ein anderes Programm, eine andere Tabelle oder eine andere Methode, um Zeitpläne zu erstellen, Listen zu führen und Vorträge und Teile zuzuweisen.
<G-vec00074-002-s642><assign.zuweisen><en> Shortcut key To assign a shortcut key to a control, you have to set the focus into the text box and then press the desired key combination.
<G-vec00074-002-s642><assign.zuweisen><de> Um einem Bedienelement ein Tastaturkürzel zuzuweisen, ist der Fokus auf das Textfeld zu setzen und dann die gewünschte Tastenkombination zu betätigen.
