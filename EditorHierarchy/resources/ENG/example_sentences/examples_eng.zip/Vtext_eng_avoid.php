<G-vec00045-002-s114><avoid.entgehen><en> Obviously, if a device DeLonghi CTF2134C/S has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s114><avoid.entgehen><de> Es ist klar, dass wenn das Gerät DeLonghi Caffe Venezia ESAM2200 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s115><avoid.entgehen><en> Obviously, if a device Philips SDV8622/12 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s115><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Victory Refrigeration UR-48-12 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s116><avoid.entgehen><en> Obviously, if a device Philips 190C6 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s116><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Velleman DVM439 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s117><avoid.entgehen><en> Obviously, if a device Primo 1800 Office has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s117><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Samsung LH32MGPLBC/Z viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s118><avoid.entgehen><en> Obviously, if a device Philips 21PT9467 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s118><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Bushnell 1200 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s119><avoid.entgehen><en> The only way for Peer to avoid this fate is to prove that he was himself in his lifetime.
<G-vec00045-002-s119><avoid.entgehen><de> Entgehen kann Peer diesem Schicksal nur, wenn er beweisen kann, dass er in seinem Leben er selbst gewesen ist.
<G-vec00045-002-s120><avoid.entgehen><en> Assange took refuge in the Ecuadoran embassy in London in 2012 to avoid extradition to Sweden to face questioning in two alleged cases of sexual assault.
<G-vec00045-002-s120><avoid.entgehen><de> Der Australier hatte sich im Juni 2012 in die Londoner Botschaft des südamerikanischen Landes geflüchtet, um seiner Festnahme und Auslieferung nach Schweden wegen Vergewaltigungsvorwürfen zu entgehen.
<G-vec00045-002-s121><avoid.entgehen><en> Obviously, if a device Philips 32PFL7332 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s121><avoid.entgehen><de> Es ist klar, dass wenn das Gerät HoMedics VC-100-1 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s122><avoid.entgehen><en> She was later released, but was forced to leave her home for over 3 years in order to avoid further arrest.
<G-vec00045-002-s122><avoid.entgehen><de> Als sie später freigelassen wurde, sah sie sich jedoch gezwungen, ihr Zuhause für mehr als drei Jahre zu verlassen, um einer weiteren Verhaftung zu entgehen.
<G-vec00045-002-s123><avoid.entgehen><en> Obviously, if a device Amica EB 13249 E has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s123><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Amica EKGC 16166 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s124><avoid.entgehen><en> I decided to leave home to avoid additional persecution.
<G-vec00045-002-s124><avoid.entgehen><de> Um einer weiteren Verfolgung zu entgehen, beschloss ich, meine Wohnung zu verlassen.
<G-vec00045-002-s125><avoid.entgehen><en> Obviously, if a device LG Electronics DP771 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s125><avoid.entgehen><de> Es ist klar, dass wenn das Gerät CE Labs SW204HD viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s126><avoid.entgehen><en> Obviously, if a device Sony SR57E has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s126><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Sony BDV-E500W viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s127><avoid.entgehen><en> Obviously, if a device Healthrider HRE99940 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s127><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Healthrider HRE99940 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s128><avoid.entgehen><en> Obviously, if a device Philips FW-C80 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s128><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Videocon VU324LDF viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s129><avoid.entgehen><en> A mechanism of that kind leads to avoid the ethical and juridical dilemma of “perceived intent”.
<G-vec00045-002-s129><avoid.entgehen><de> Ein derartiger Prozess führt dazu, dem ethischen und rechtlichen Dilemma des „mutmaßlichen Willens“ zu entgehen.
<G-vec00045-002-s130><avoid.entgehen><en> Obviously, if a device Philips s10 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s130><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Vision Fitness E3200HRT viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s131><avoid.entgehen><en> Obviously, if a device Billy Goat CR550HC has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s131><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Billy Goat BLOWER QB882 viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s132><avoid.entgehen><en> Obviously, if a device Philips HDD1430 has multiple advanced functions, we will not avoid a high amount of information in this document.
<G-vec00045-002-s132><avoid.entgehen><de> Es ist klar, dass wenn das Gerät Hapro HB175 Summed Glow viele fortgeschrittene Funktionen hat, wir den vielen Informationen im Inhalt des Dokuments nicht entgehen können.
<G-vec00045-002-s741><avoid.entgehen><en> ...a bude hur | It the end of the seventies: In order to avoid military service, Olin manages to get himself sent to a psychiatric clinic.
<G-vec00045-002-s741><avoid.entgehen><de> Tschechoslowakei am Ende der 70er Jahre: Um dem Militärdienst zu entgehen, hat Olin einen Aufenthalt in der Psychiatrie provoziert.
<G-vec00045-002-s742><avoid.entgehen><en> According to a survey carried out by the Jordanian Institute for Solidarity Among Women, 62 percent of Jordanian women believe that rapists only marry their victims to avoid prosecution.
<G-vec00045-002-s742><avoid.entgehen><de> Laut einer Umfrage des jordanischen Instituts für die Solidarität unter Frauen gehen 62 Prozent der Jordanierinnen davon aus, dass die Täter die Opfer nur deshalb heiraten, um ihrer Strafe zu entgehen.
<G-vec00045-002-s743><avoid.entgehen><en> The police also frequently harassed me so that I was forced to leave home for a year to avoid being arrested.
<G-vec00045-002-s743><avoid.entgehen><de> Die Polizei belästigte mich regelmäßig, sodass ich gezwungen war, mein Zuhause für ein Jahr zu verlassen, um einer Verhaftung zu entgehen.
<G-vec00045-002-s744><avoid.entgehen><en> The Hebei Provincial Public Security Bureau arrested several Dafa practitioners, while several other practitioners were forced to leave their homes to avoid arrest.
<G-vec00045-002-s744><avoid.entgehen><de> Das öffentliche Sicherheitsbüro der Provinz Hebei verhaftete daraufhin mehrere Falun Gong Praktizierende; viele andere Praktizierende waren gezwungen, ihr Zuhause zu verlassen, um der Verhaftung zu entgehen.
<G-vec00045-002-s745><avoid.entgehen><en> She managed to escape, but had to become homeless to avoid further persecution.
<G-vec00045-002-s745><avoid.entgehen><de> Sie schaffte es zu entkommen und musste danach heimatlos leben, um einer weiteren Verfolgung zu entgehen.
<G-vec00045-002-s746><avoid.entgehen><en> He often lived away from home to avoid persecution.
<G-vec00045-002-s746><avoid.entgehen><de> Er lebte oftmals weit entfernt von zu Hause, um der Verfolgung zu entgehen.
<G-vec00045-002-s747><avoid.entgehen><en> She and her husband were in hiding since then to avoid further persecution.
<G-vec00045-002-s747><avoid.entgehen><de> Seitdem versteckt sie sich mit ihrem Ehemann, um der Verfolgung zu entgehen.
<G-vec00045-002-s748><avoid.entgehen><en> The party concerned argue against that the traffic laws and regulations made from the point of view of car riders and violation is the obvious possibility to avoid self-endangering.
<G-vec00045-002-s748><avoid.entgehen><de> Von den Betroffenen wird dagegengehalten, dass die den Straßenverkehr betreffenden Gesetze und Verordnungen aus dem Blickwinkel des Kraftfahrers heraus gemacht worden seien und ein Verstoß dagegen für Radfahrer oft die naheliegendste Möglichkeit sei, einer Selbstgefährdung zu entgehen.
<G-vec00045-002-s749><avoid.entgehen><en> When the sorcerer then perceives that the victim believes that it is cursed and tries to avoid the perceived consequence, the sorcerer will offer a cure.
<G-vec00045-002-s749><avoid.entgehen><de> Wenn der Zauberer dann merkt, daß das Opfer glaubt, es sei verflucht, und nun versucht, den angenommenen Auswirkungen zu entgehen, wird der Zauberer ihm eine Behandlung anbieten.
<G-vec00045-002-s750><avoid.entgehen><en> During the 1960s and 70s, tens of thousands of Americans fled to Canada looking to avoid the Vietnam draft.
<G-vec00045-002-s750><avoid.entgehen><de> In den 1960ern und 70ern flohen Zehntausende Amerikaner nach Kanada, um der Wehrpflicht für den Einsatz in Vietnam zu entgehen.
<G-vec00045-002-s751><avoid.entgehen><en> Holmes also mentioned that he had read on several occasions that a Corgi bites and then lies down to avoid being kicked, but that he had never observed any dog do that.
<G-vec00045-002-s751><avoid.entgehen><de> Holmes erwähnte auch, dass er mehrmals gelesen habe, dass ein Corgi zuschnappt und sich darauf hinlegt, um dem Tritt zu entgehen, dass er aber diese Methode nie beobachtet habe.
<G-vec00045-002-s752><avoid.entgehen><en> Mr. Wang returned to his hometown in Shanxi Province in July 2001 to avoid further persecution.
<G-vec00045-002-s752><avoid.entgehen><de> Im Juli 2001 kehrte Herr Wang in seine Heimatstadt in der Provinz Shanxi zurück, um weiterer Verfolgung zu entgehen.
<G-vec00045-002-s753><avoid.entgehen><en> (Please substitute @ for (AT); we are trying to avoid spam).
<G-vec00045-002-s753><avoid.entgehen><de> (Ersetzt (AT) durch @; wir versuchen so, Spam-Emails zu entgehen).
<G-vec00045-002-s754><avoid.entgehen><en> Assange, 44, sought sanctuary in the embassy in 2012 to avoid extradition to Sweden.
<G-vec00045-002-s754><avoid.entgehen><de> Zunächst hatte Assange in der Botschaft Schutz gesucht, um einer Auslieferung nach Schweden wegen Vergewaltigungsvorwürfen zu entgehen.
<G-vec00045-002-s755><avoid.entgehen><en> She was forced to leave home and live on the streets to avoid further persecution, leaving her two children unattended.
<G-vec00045-002-s755><avoid.entgehen><de> Sie war gezwungen ihre Wohnung zu verlassen und auf der Straße zu leben, um einer weiteren Verfolgung zu entgehen, sie musste ihre beiden Kinder unbeaufsichtigt zurücklassen.
<G-vec00045-002-s756><avoid.entgehen><en> The truth of the matter is that Şor is a typical oligarch without political views and ideological beliefs who is forced to be friends with Plahotniuc and be politically active to avoid the real legal prosecution.
<G-vec00045-002-s756><avoid.entgehen><de> In der Wirklichkeit ist Schor ein typischer Oligarch ohne politische Prinzipien und ideologische Neigungen, der die Freundschaft zu Plahotniuc und eigene politische Tätigkeit instrumentalisiert, um einer realen Strafverfolgung zu entgehen.
<G-vec00045-002-s757><avoid.entgehen><en> Yuan Jiang was forced to leave his home in January of 2001 to avoid persecution.
<G-vec00045-002-s757><avoid.entgehen><de> Yuan Jiang wurde im Januar 2001 gezwungen sein Haus zu verlassen, um der Verfolgung zu entgehen.
<G-vec00045-002-s758><avoid.entgehen><en> Oh, well, it looked like another month of slipping in and out through the window to avoid Mr Turcic's outstretched hand.
<G-vec00045-002-s758><avoid.entgehen><de> Es sah ganz nach einem weiteren Monat aus, in dem ich mein Büro kletternderweise durchs Fenster betreten würde, um Herrn Turcics fordernder Hand zu entgehen.
<G-vec00045-002-s759><avoid.entgehen><en> He found that his wife had been forced into homelessness to avoid persecution.
<G-vec00045-002-s759><avoid.entgehen><de> Er bemerkte, dass seine Frau heimatlos geworden war, um der Verfolgung zu entgehen.
<G-vec00045-002-s171><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product American Standard Silhouette 7185.011 than expected.
<G-vec00045-002-s171><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts American Standard 7185.011 entspringen.
<G-vec00045-002-s172><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Fellowes 480-2HS than expected.
<G-vec00045-002-s172><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Lanier 480-0209 entspringen.
<G-vec00045-002-s173><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product ZyXEL Communications VL470M than expected.
<G-vec00045-002-s173><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts ZyXEL Communications VT470M entspringen.
<G-vec00045-002-s174><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Lenovo GOBI 5000 than expected.
<G-vec00045-002-s174><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Lenovo 4262 entspringen.
<G-vec00045-002-s175><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Yamaha NS-P270 than expected.
<G-vec00045-002-s175><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Yamaha AVX-S80 entspringen.
<G-vec00045-002-s176><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product RCA RMW1108 than expected.
<G-vec00045-002-s176><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts RCA 56028090 entspringen.
<G-vec00045-002-s177><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product JVC GD-V4211PCE than expected.
<G-vec00045-002-s177><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts JVC 50050690 entspringen.
<G-vec00045-002-s178><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Rose electronics CATx than expected.
<G-vec00045-002-s178><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Rose electronics CrystalView entspringen.
<G-vec00045-002-s179><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product MTD 124-295A than expected.
<G-vec00045-002-s179><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts MTD 124-848M000 entspringen.
<G-vec00045-002-s180><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product York DM120 than expected.
<G-vec00045-002-s180><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts York F*FV entspringen.
<G-vec00045-002-s181><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Epson EMP 720 than expected.
<G-vec00045-002-s181><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Epson EMP MONITOR OPERATION V4.30 entspringen.
<G-vec00045-002-s182><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Louisville Tin and Stove VFM203 than expected.
<G-vec00045-002-s182><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Louisville Tin and Stove VFM64 entspringen.
<G-vec00045-002-s183><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Rangemaster 110 DUAL FUEL U109600-02 than expected.
<G-vec00045-002-s183><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Rangemaster RML3342 entspringen.
<G-vec00045-002-s184><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Sony SWR50 than expected.
<G-vec00045-002-s184><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Sony SWR50 entspringen.
<G-vec00045-002-s185><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Quatech T802.11b/g than expected.
<G-vec00045-002-s185><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Quatech 802.11B/G entspringen.
<G-vec00045-002-s186><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Black & Decker CWV9610 than expected.
<G-vec00045-002-s186><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Black & Decker CWV9610 entspringen.
<G-vec00045-002-s187><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Electrolux EAS(C,E)09C2ASK(W,S,M) than expected.
<G-vec00045-002-s187><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Electrolux RIMG150SW entspringen.
<G-vec00045-002-s188><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product York E3FB090 than expected.
<G-vec00045-002-s188><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts York LINC485 entspringen.
<G-vec00045-002-s189><avoid.machen><en> It is good to get acquainted with it to avoid disappointments resulting from a shorter exploitation time of the product Epson T7000 than expected.
<G-vec00045-002-s189><avoid.machen><de> Es lohnt sich, sich mit ihr bekannt zu machen, um Enttäuschungen vorzubeugen, die aus einem kürzeren als vorhergesehenen Zeitraum der Nutzung des Produkts Epson 850Z entspringen.
<G-vec00045-002-s190><avoid.meiden><en> Avoid hot plates, electric shocks and inky turrets to create your own path to the impenetrable I.N.K.T. Fortress.
<G-vec00045-002-s190><avoid.meiden><de> Meide heiße Platten, Elektroschocks und Tinten-Geschütze, um die scheinbar uneinnehmbare I.N.K.T.-Festung zu erreichen.
<G-vec00045-002-s191><avoid.meiden><en> Avoid them particularly on training and performing days.
<G-vec00045-002-s191><avoid.meiden><de> Meide sie besonders an Proben- oder Auftrittstagen.
<G-vec00045-002-s192><avoid.meiden><en> Avoid suede, as this material tends to be reserved for the colder months.
<G-vec00045-002-s192><avoid.meiden><de> Meide Wildleder, da dieses Material dazu neigt, für die kälteren Monate reserviert zu sein.
<G-vec00045-002-s193><avoid.meiden><en> Avoid chewing gum so you don’t swallow gas.
<G-vec00045-002-s193><avoid.meiden><de> Meide Kaugummi, damit du nicht aus Versehen Luft verschluckst.
<G-vec00045-002-s194><avoid.meiden><en> Avoid excess packaging.
<G-vec00045-002-s194><avoid.meiden><de> Meide überschüssige Verpackungen.
<G-vec00045-002-s195><avoid.meiden><en> Avoid milk and dairy products for at least an hour after taking iron because the calcium in dairy products may decrease iron absorption.
<G-vec00045-002-s195><avoid.meiden><de> Meide mindestens eine Stunde, nachdem du Eisen eingenommen hast, Milch und Milchprodukte, weil das Kalzium in Molkereiprodukten die Eisenaufnahme senken könnte.
<G-vec00045-002-s196><avoid.meiden><en> Avoid areas where wolves have been seen.
<G-vec00045-002-s196><avoid.meiden><de> Meide Gebiete, in denen Wölfe gesichtet wurden.
<G-vec00045-002-s197><avoid.meiden><en> Avoid the chicken dance, the granddad dance, and the head bang.
<G-vec00045-002-s197><avoid.meiden><de> Meide den Ententanz, den Opa-Tanz und das Headbangen.
<G-vec00045-002-s198><avoid.meiden><en> Join others, fight or avoid them.
<G-vec00045-002-s198><avoid.meiden><de> Verbünde dich mit anderen, bekämpfe oder meide sie.
<G-vec00045-002-s199><avoid.meiden><en> Avoid dairy if you're lactose intolerant.
<G-vec00045-002-s199><avoid.meiden><de> Meide Milchprodukte, falls du laktoseintolerant bist.
<G-vec00045-002-s200><avoid.meiden><en> Alternatively, avoid foods that are high in saturated and trans fats.
<G-vec00045-002-s200><avoid.meiden><de> Meide alternativ dazu Lebensmittel, die reich an gesättigten Fettsäuren und Transfetten sind.
<G-vec00045-002-s201><avoid.meiden><en> Avoid caffeine and sugary beverages.
<G-vec00045-002-s201><avoid.meiden><de> Meide Koffein und zuckerhaltige Getränke.
<G-vec00045-002-s202><avoid.meiden><en> Avoid activities that take you to the kitchen or near places you can buy food.
<G-vec00045-002-s202><avoid.meiden><de> Meide Aktivitäten, die dich in die Küche oder in die Nähe von Orten führen, an denen du essen kaufen kannst.
<G-vec00045-002-s203><avoid.meiden><en> Do not leave traces of your passage: avoid braking sharply and restarting (excessive soil erosion); avoid riding on the trails after pouring rains (excessive soil erosion); do not leave rubbish.
<G-vec00045-002-s203><avoid.meiden><de> Hinterlasse keine Spuren: meide Anfahrt und Bremsspuren (Bodenerosion); meide "Single Trails" nach Regenfällen (Bodenerosion); nimm deine Abfälle mit.
<G-vec00045-002-s205><avoid.meiden><en> Avoid the temptation to pick off the scab to get rid of it.
<G-vec00045-002-s205><avoid.meiden><de> Meide die Versuchung, die Kruste abzulösen, um sie loszuwerden.
<G-vec00045-002-s206><avoid.meiden><en> 4 Avoid additional triggers that can make the headache worse.
<G-vec00045-002-s206><avoid.meiden><de> 4 Meide zusätzliche Trigger, die deine Kopfschmerzen verschlimmern können.
<G-vec00045-002-s207><avoid.meiden><en> If you are not comfortable driving at high speeds, drive more slowly and avoid highways.
<G-vec00045-002-s207><avoid.meiden><de> Wenn dir hohe Geschwindigkeiten nicht geheuer sind, fahre langsamer und meide Autobahnen.
<G-vec00045-002-s208><avoid.meiden><en> Avoid companies that contact you if you’ve never contacted them.
<G-vec00045-002-s208><avoid.meiden><de> Meide Unternehmen, die an dich herantreten, ohne dass du sie vorher jemals kontaktiert hast.
<G-vec00045-002-s209><avoid.meiden><en> It is specified reasons for it gladly that the Schabrackentapire attack the cornfields at night and prepared big damage, which should be, however, very exaggerated surely, since tapirs avoid themselves mutually and therefore never appear in large groups.
<G-vec00045-002-s209><avoid.meiden><de> Als Grund dafür wird gerne angeführt, daß die Schabrackentapire nachts über die Maisfelder herfallen und großen Schaden anrichteten, was aber sicherlich sehr übertrieben sein dürfte, da sich Tapire gegenseitig meiden und deshalb niemals in großen Gruppen auftreten.
<G-vec00045-002-s210><avoid.meiden><en> You should also avoid pants that are too loose or made of a slippery material because your foot will be resting against the inside of your opposite thigh.
<G-vec00045-002-s210><avoid.meiden><de> Du solltest außerdem Hosen meiden, die zu locker oder aus rutschigem Material hergestellt sind, weil dein Fuß an der Innenseite deines gegenüberliegenden Oberschenkels anliegen sollte.
<G-vec00045-002-s211><avoid.meiden><en> If you want to avoid the crowds, Eleuthera is ideal -- there are less than 15,000 residents on the island.
<G-vec00045-002-s211><avoid.meiden><de> Wenn Sie die Menschenmassen meiden möchten, ist Eleuthera ideal - auf der Insel leben weniger als 15.000 Menschen.
<G-vec00045-002-s212><avoid.meiden><en> And you will avoid him and flee into my arms, because truth also shows you my nature, which is just love for all my creatures – never ever will I allow that the knowledge about your destiny is completely withheld from you men, never ever will I leave you to my opponent without a fight, and never ever will he be allowed to be able to usurp the throne by him being able to rule completely over you, my creatures, and to push you away from me by force.
<G-vec00045-002-s212><avoid.meiden><de> Und ihr werdet ihn meiden und in Meine Arme flüchten, denn die Wahrheit zeigt euch auch Mein Wesen, das nur Liebe ist für alle Meine Geschöpfe - nimmermehr werde Ich es zulassen, daß euch Menschen das Wissen um eure Bestimmung gänzlich vorenthalten wird, nimmermehr werde Ich euch Meinem Gegner kampflos überlassen, und nimmermehr wird er sich auf den Thron schwingen dürfen, indem er euch, Meine Geschöpfe, gänzlich beherrschen und euch von Mir mit Gewalt abdrängen kann.
<G-vec00045-002-s213><avoid.meiden><en> Way of life In its home, pink-cockatoos often turn into the plague since they are adaptable at many different habitats and even human settlements quite don't avoid.
<G-vec00045-002-s213><avoid.meiden><de> Lebensweise In ihrer Heimat werden Rosakakadus oft zur Landplage, da sie anpassungsfähig an viele unterschiedliche Lebensräume sind und selbst menschliche Ansiedlungen durchaus nicht meiden.
<G-vec00045-002-s214><avoid.meiden><en> One such example was during the Bangkok riots, where the Ministry sent an SMS warning those travelling to avoid the city centre.
<G-vec00045-002-s214><avoid.meiden><de> Wie im Beispiel Bangkok, wo das Ministerium per SMS eine Reisewarnung geschickt hat, mit dem Hinweis, die Innenstadt zu meiden.
<G-vec00045-002-s215><avoid.meiden><en> Others avoid solid relationships by deceiving themselves and their friends into thinking that they do not want a relationship at all, but rather want to enjoy their freedom.
<G-vec00045-002-s215><avoid.meiden><de> Andere meiden feste Beziehungen, indem sie sich selbst und ihren Mitmenschen vormachen, gar keine Partnerschaft anzustreben, sondern lieber ihre Freiheit genießen zu wollen.
<G-vec00045-002-s216><avoid.meiden><en> By collecting real data from other drivers, IQ Routes™ optimizes your journey so you can avoid closed roads and congestion.
<G-vec00045-002-s216><avoid.meiden><de> Durch das Erfassen von Echtzeitdaten anderer Fahrer optimiert IQ Routes™ Ihre Reise, sodass Sie gesperrte Straßen und Staus meiden können.
<G-vec00045-002-s217><avoid.meiden><en> Jack should also avoid ghosts, crocodiles and other exotics as carnivorous plants, teeth and soap bubbles.
<G-vec00045-002-s217><avoid.meiden><de> Auch Gespenster, Krokodile und andere Exoten wie fleischfressende Pflanzen, Gebisse und Seifenblasen sollte Jack meiden.
<G-vec00045-002-s218><avoid.meiden><en> In order to avoid confusion, you should know that the cortisone used in drugs is called hydrocortisone.
<G-vec00045-002-s218><avoid.meiden><de> Um künftig Verwirrungen zu meiden, sollten Sie wissen, dass Cortison in Medikamenten unter dem Namen Hydrocortison anzutreffen ist.
<G-vec00045-002-s219><avoid.meiden><en> If you are a person with a compromised immune system or are an elderly person, please avoid public spaces or travel.
<G-vec00045-002-s219><avoid.meiden><de> Wenn Sie eine Person mit einem geschwächten Immunsystem oder eine ältere Person sind, meiden Sie bitte öffentliche Räume oder Reisen.
<G-vec00045-002-s220><avoid.meiden><en> There is food with a very high glycemic index, which you should rather avoid (this is often food rich in starch or sugar).
<G-vec00045-002-s220><avoid.meiden><de> Es gibt Lebensmittel mit einem sehr hohen glykämischen Index, welche man besser meiden sollte (dies sind meist stärke- oder zuckerreiche Lebensmittel).
<G-vec00045-002-s221><avoid.meiden><en> You avoid the subject of drinking, even with your own parents.
<G-vec00045-002-s221><avoid.meiden><de> Sie meiden das Thema Alkohol sogar bei Ihren Eltern.
<G-vec00045-002-s222><avoid.meiden><en> Once you have identified your intolerances, however, there are ways to manage it, and if you successfully avoid the offending food item, your fatigue may disappear.
<G-vec00045-002-s222><avoid.meiden><de> Und wenn Sie die problembereitenden Lebensmittel komplett meiden, kann Ihre Müdigkeit im Nu verschwinden.
<G-vec00045-002-s223><avoid.meiden><en> To not have this experience makes it easier to diagnose, to enforce treatment, to prescribe medication, to reject them, to avoid them and ultimately to forget them.
<G-vec00045-002-s223><avoid.meiden><de> Diese Erfahrung nicht zu haben, macht es leichter zu diagnostizieren, zwangszubehandeln, Psychopharmaka zu verschreiben, Menschen abzuweisen, sie zu meiden und letztendlich zu vergessen.
<G-vec00045-002-s224><avoid.meiden><en> Wasps and mosquitos avoid the treated areas.
<G-vec00045-002-s224><avoid.meiden><de> Wespen und Stechm├╝cken meiden den Bereich behandelter Pflanzen.
<G-vec00045-002-s225><avoid.meiden><en> For vegetarians, vegans or the ones who avoid fish in their diet, having the daily supply in Omega 3 is a challenge.
<G-vec00045-002-s225><avoid.meiden><de> Für Vegetarier, Veganer oder diejenigen, die Fisch in ihrer Ernährung meiden, ist die tägliche Versorgung von Omega 3 eine Herausforderung.
<G-vec00045-002-s226><avoid.meiden><en> I was always trying to avoid the truth to walk my own path, always wanting to be God, and making people treat me like God.
<G-vec00045-002-s226><avoid.meiden><de> Ich versuchte immer, die Wahrheit zu meiden, meinen eigenen Weg zu beschreiten und die Menschen dazu zu veranlassen, mich wie Gott zu behandeln.
<G-vec00045-002-s227><avoid.meiden><en> Instead, pregnant women who are not immune should avoid anyone who has the illness and then be given the vaccine immediately after giving birth so that they will be immune during any future pregnancies.
<G-vec00045-002-s227><avoid.meiden><de> Stattdessen sollten nicht-immune Schwangere Personen mit der Erkrankung meiden und den Impfstoff direkt nach der Geburt erhalten, sodass sie während zukünftiger Schwangerschaften immun sind.
<G-vec00045-002-s399><avoid.umgehen><en> • We try to avoid peak times at the gondola, in the busses and also on the meeting areas which are focused between 9.30 am and 10.30 am.
<G-vec00045-002-s399><avoid.umgehen><de> • Wir umgehen die Stoßzeiten (große Menschenansammlungen) an der Gondel, in den Bussen und an den Sammelplätzen, die sich zwischen 09.30 und 10.30 Uhr konzentrieren.
<G-vec00045-002-s400><avoid.umgehen><en> This means they also avoid TV commercials, which are not broadcast in paid services.
<G-vec00045-002-s400><avoid.umgehen><de> Dabei umgehen sie auch die TV-Werbung, die bei den Bezahlangeboten nicht ausgespielt wird.
<G-vec00045-002-s401><avoid.umgehen><en> I will always know how to avoid that you do not feel to be deserted by me because in all needs and worries you are to turn to me, and you will always receive answers because I know it what makes you worry, but I am always ready to relieve you of these when only you hand them over to me trustingly.
<G-vec00045-002-s401><avoid.umgehen><de> Daß ihr euch nicht verlassen fühlet von Mir, werde Ich stets zu umgehen wissen, denn ihr sollet in allen Nöten und Sorgen euch an Mich wenden, und ihr werdet immer Antwort bekommen, weil Ich es weiß, was euch Sorgen macht, Ich aber stets bereit bin, euch diese abzunehmen, wenn ihr sie Mir nur vertrauensvoll übergebet.
<G-vec00045-002-s402><avoid.umgehen><en> This way you do not have too much humus and you can avoid the problem described above.
<G-vec00045-002-s402><avoid.umgehen><de> Auf diese Weise entsteht nicht allzuviel Humus und Sie können das oben beschriebene Problem umgehen.
<G-vec00045-002-s403><avoid.umgehen><en> This allows you to avoid blocks imposed by the Great Firewall and escape censorship while using a VPN in China.
<G-vec00045-002-s403><avoid.umgehen><de> Damit können Sie Blockierungen umgehen, die durch die Great Firewall verursacht werden und Sie überwinden Zensur, während Sie ein VPN in China verwenden.
<G-vec00045-002-s404><avoid.umgehen><en> In order to avoid this limitation you can use SSH and HTTP tunnels.
<G-vec00045-002-s404><avoid.umgehen><de> Um diese Einschränkungen zu umgehen, können Sie SSH und HTTP Tunnel verwenden.
<G-vec00045-002-s405><avoid.umgehen><en> You will not be able to avoid these transformations. We can say, however, that you must rejoice in them.
<G-vec00045-002-s405><avoid.umgehen><de> Ihr werdet diese Veränderungen nicht umgehen können, jedoch können wir euch sagen, dass ihr euch darüber freuen sollt.
<G-vec00045-002-s406><avoid.umgehen><en> Using this trick, scientists can avoid the key problem found in this area: the strong interaction of the electron beam with the sample has, up to now, made the electron diffraction much more difficult.
<G-vec00045-002-s406><avoid.umgehen><de> Mit diesem Trick umgehen die Wissenschaftler das zentrale Problem: die starke Wechselwirkung des Elektronenstrahls mit der Probe hatte bislang die Elektronenbeugung massiv erschwert.
<G-vec00045-002-s407><avoid.umgehen><en> In order to avoid the manufacturing of prototypes, particular attention was paid on the attempt of representing the behaviour of each component by simulations.
<G-vec00045-002-s407><avoid.umgehen><de> Um die Fertigung von Prototypen umgehen zu können, lag besonderes Augenmerk darauf, das Verhalten sämtlicher Komponenten anhand von Simulationen beschreiben zu können.
<G-vec00045-002-s408><avoid.umgehen><en> According to Patrick z’Brun, local porters pointed out that until ten years ago the base camp had regularly been pitched up further down the glacier and that even earlier, mountaineers had climbed via an eastern ridge directly to Camp 1 in order to avoid the danger zone.
<G-vec00045-002-s408><avoid.umgehen><de> Laut Patrick z’Brun wiesen einheimische Träger darauf hin, dass bis vor zehn Jahren das Basislager regelmäßig weiter unten auf dem Gletscher gestanden habe und dass noch früher die Bergsteiger auf einem östlich gelegenen Grat direkt nach Lager 1 aufgestiegen seien, um die Gefahrenzone zu umgehen.
<G-vec00045-002-s409><avoid.umgehen><en> However, the delay between detection by a monster and the start of an attack should be long enough for attentive harvesters to avoid most attacks.
<G-vec00045-002-s409><avoid.umgehen><de> Aufmerksame Charaktere sollten aber aufgrund des zeitlichen Abstands zwischen dem Erkanntwerden durch ein Monster und das Auslösen des Aggressens auch bei der Ernte die meisten Angriffe umgehen können.
<G-vec00045-002-s410><avoid.umgehen><en> Added new technology to avoid a defect of macOS where the operating system asks for permission to add a helper application when it actually removes a helper application.
<G-vec00045-002-s410><avoid.umgehen><de> Neue Technik hinzugefügt, um einen Konstruktionsfehler von macOS zu umgehen, bei dem das Betriebssystem um Erlaubnis fragt, ein Hilfsprogramm hinzufügen zu dürfen, wenn tatsächlich ein Hilfsprogramm entfernt wird.
<G-vec00045-002-s411><avoid.umgehen><en> Please give me wisdom to see the things that the evil one has designed for me and avoid them and resist them.
<G-vec00045-002-s411><avoid.umgehen><de> Schenke mir bitte die Weisheit, die Dinge des Bösen zu erkennen, zu umgehen und ihnen zu widerstehen.
<G-vec00045-002-s412><avoid.umgehen><en> Double space units avoid switching off the suctioning unit when emptying the filled containers and ensure continuous production.
<G-vec00045-002-s412><avoid.umgehen><de> Doppelplatzanlagen umgehen das Abschalten der Absaugung für den Entleervorgang der gefüllten Behälter und sichern eine fortlaufende Produktion.
<G-vec00045-002-s413><avoid.umgehen><en> Accordingly, it would be desirable to be able to map regions difficult to access the body, while maintaining a good acoustic access to the body and to avoid the need for complex imaging procedures.
<G-vec00045-002-s413><avoid.umgehen><de> Dementsprechend wäre es wünschenswert, in der Lage zu sein, schwer zugängliche Regionen des Körpers abzubilden, dabei einen guten akustischen Zugang zum Körper beizubehalten und die Notwendigkeit komplexer Bildgebungsprozeduren zu umgehen.
<G-vec00045-002-s414><avoid.umgehen><en> But it can also be that single error that you avoid on the construction site through precise design and consultation with the customer pays the bill.
<G-vec00045-002-s414><avoid.umgehen><de> Es kann aber auch der eine vermiedene Fehler auf der Baustelle sein, den man durch die genauere Planung und die Absprache mit dem Kunden umgehen konnte.
<G-vec00045-002-s415><avoid.umgehen><en> There are many who claims that project management is a generic discipline. But in our experience, specific knowledge in the area is needed in order to avoid making many of the known errors and, hence, get a faster implementation with a higher level of quality and success.
<G-vec00045-002-s415><avoid.umgehen><de> Viele behaupten, dass Projektleitung eine generische Disziplin ist, aber unsere Erfahrung sagt uns, dass die spezifische Erfahrung auf dem Gebiet macht, dass wir eine Reihe von Fehlern umgehen und eine schnellere Implementierung mit höherer Qualität erreichen können.
<G-vec00045-002-s416><avoid.umgehen><en> Please note that we cannot avoid passing on certain data to the registries.
<G-vec00045-002-s416><avoid.umgehen><de> Bitte beachten Sie, dass wir die Weitergabe bestimmter Daten an die Vergabestelle nicht umgehen können.
<G-vec00045-002-s417><avoid.umgehen><en> In order to avoid the danger of a ‘statistical’ performance, which always looms whenever one attempts to make music from a ‘technological’ epoch in love with its own philological instruments of cognition, one should be able to immerse oneself consciously in the psychological game which Feldman’s composition always suggests, once one allows it to operate at a level beyond that of the superficial first impression, the latticework of the score pages.
<G-vec00045-002-s417><avoid.umgehen><de> Um die Gefahr einer 'statistischen' Aufführung zu umgehen, die immer droht, wenn man Musik aus einer 'technologischen' und in ihre philologischen Erkenntnisinstrumente verliebten Epoche macht, sollte man bewusst in das psychologische Spiel eintauchen können, das von Feldmans Komponieren nahe gelegt wird, sobald man es über den oberflächlichen ersten Eindruck, die Gitterhaftigkeit der Partiturseiten, hinaus wirken lassen möchte.
<G-vec00045-002-s133><avoid.vermeiden><en> But a further question is how to avoid uncontrolled migration via the Mediterranean.
<G-vec00045-002-s133><avoid.vermeiden><de> Es geht aber auch darum, wie wir unkontrollierte Migration über das Mittelmeer vermeiden können.
<G-vec00045-002-s134><avoid.vermeiden><en> You can avoid the risk of falling into this trap by choosing to send your suitcase from Austria to Sweden instead.
<G-vec00045-002-s134><avoid.vermeiden><de> Aus diesem Grund ist es manchmal viel günstiger, den Koffer einfach von Deutschland nach Schweden zu verschicken und das Risiko vermeiden, in die Falle der Fluggesellschaften zu geraten.
<G-vec00045-002-s135><avoid.vermeiden><en> Children will avoid harming others when they understand how sensitive both they and others are.
<G-vec00045-002-s135><avoid.vermeiden><de> Kinder werden es vermeiden, einander zu verletzen, wenn sie verstehen, wie sensibel sie selbst und andere sind.
<G-vec00045-002-s136><avoid.vermeiden><en> Finally, a solution that helps you avoid the risks inherent in letting your hardware and software run rogue.
<G-vec00045-002-s136><avoid.vermeiden><de> Endlich gibt es eine Lösung, die Ihnen hilft, die Risiken in Verbindung mit dem Einsatz von nicht genehmigter Hardware und Software zu vermeiden.
<G-vec00045-002-s137><avoid.vermeiden><en> In providing suitable directives for consultation, the Bishop should also be aware of the danger of pressure groups - oftentimes a regrettable reality - and he should always avoid creating unjustified expectations with regard to the effective acceptance of their proposals.
<G-vec00045-002-s137><avoid.vermeiden><de> Der Bischof sollte sich bei der Erteilung entsprechender Anweisungen für die Befragung die - hier und da leider allzu reale - Gefahr des Entstehens von "pressure groups" vor Augen halten und es vermeiden in den Befragten ungerechtfertigte Erwartungen hinsichtlich einer tatsächlichen Annahme ihrer Vorschläge zu wecken.
<G-vec00045-002-s138><avoid.vermeiden><en> Each day fasting lasts between dawn and sunset, and Muslims should avoid eating food, drinking liquids, smoking and sex.
<G-vec00045-002-s138><avoid.vermeiden><de> Jeden Tag dauert das Fasten zwischen Morgengrauen und Sonnenuntergang, und Muslime sollten es vermeiden, Essen, Trinken von Flüssigkeiten, Rauchen und Sex zu essen.
<G-vec00045-002-s139><avoid.vermeiden><en> The target of this application is to avoid frequent replacement of bearings inside the conveyor belt wheels.
<G-vec00045-002-s139><avoid.vermeiden><de> Ziel der Anwendung ist es, den häufigen Austausch von Lagern in Förderbandrädern zu vermeiden.
<G-vec00045-002-s140><avoid.vermeiden><en> 1024 Étape 5 When handling the battery, avoid squeezing or touching the six exposed lithium polymer cells.
<G-vec00045-002-s140><avoid.vermeiden><de> Wenn du am Akku arbeitest, musst du es vermeiden die sechs offenliegenden Lithium-Polymer Zellen zu drücken oder anzufassen.
<G-vec00045-002-s141><avoid.vermeiden><en> Any two students sharing a house must be especially careful to make every effort to communicate together in English and avoid using their mother tongue to speak together.
<G-vec00045-002-s141><avoid.vermeiden><de> Wo zwei Schüler bei der gleichen Gastfamilie wohnen, müssen sie besonders aufpassen immer auf Englisch zu sprechen und es vermeiden ihre Muttersprache zu benutzen.
<G-vec00045-002-s142><avoid.vermeiden><en> Red insists that he needs Hydroxipam, despite Russell stating that Hydroxipam is too powerful and most drug users avoid using it.
<G-vec00045-002-s142><avoid.vermeiden><de> Red sagt ihm, dass er Hydroxipam brauche, doch er sagt ihm, das die meisten Drogenabhängigen es vermeiden, weil es zu stark ist.
<G-vec00045-002-s143><avoid.vermeiden><en> The goal of the 3R Principle is to avoid animal experiments altogether (Replacement), to limit the number of animals (Reduction) and their suffering (Refinement) in tests to an absolute minimum.
<G-vec00045-002-s143><avoid.vermeiden><de> Ziel des 3R Prinzips ist es, Tierversuche vollständig zu vermeiden (Replacement) und die Zahl der Tiere (Reduction) und ihr Leiden (Refinement) in Versuchen auf das unerlässliche Maß zu beschränken.
<G-vec00045-002-s144><avoid.vermeiden><en> The purpose of this Terms is to avoid potential misunderstandings or disputes if products, services or features developed or published by Ravenscourt might appear to be similar or identical to ideas that may have independently occurred to you.
<G-vec00045-002-s144><avoid.vermeiden><de> Ziel dieser Bedingungen ist es, potenzielle Missverständnisse oder Streitigkeiten zu vermeiden, falls Produkte, Services oder von Ravenscourt entwickelte oder veröffentliche Elemente Ideen ähneln oder identisch mit ihnen sind, die Ihnen unabhängig davon unterlaufen sind.
<G-vec00045-002-s145><avoid.vermeiden><en> We are at home in the particularities and the practices of the trade with soft commodities and know how to avoid pitfalls.
<G-vec00045-002-s145><avoid.vermeiden><de> Wir kennen die Besonderheiten und Usancen des Handels mit Agrarrohstoffen genau und wissen welche Fallstricke es zu vermeiden gilt.
<G-vec00045-002-s146><avoid.vermeiden><en> Administrators should avoid using their tools in situations where they may not be impartial.
<G-vec00045-002-s146><avoid.vermeiden><de> Administratoren sollten es vermeiden, ihre Werkzeuge in Situationen einzusetzen, in denen sie möglicherweise nicht unparteiisch sind.
<G-vec00045-002-s147><avoid.vermeiden><en> Early detection of sagging interest or excessive contact frequency helps to avoid customer inactivity and, ultimately, customer withdrawal.
<G-vec00045-002-s147><avoid.vermeiden><de> Es gilt, nachlassendes Interesse oder auch eine zu hohe Kontaktfrequenz frühzeitig zu erkennen, um Inaktivität und in letzter Instanz die Abmeldung zu vermeiden.
<G-vec00045-002-s148><avoid.vermeiden><en> This should avoid having to create different templates for every situation and allow improvements to be easier to implement.
<G-vec00045-002-s148><avoid.vermeiden><de> Dies sollte es vermeiden, verschiedene Vorlagen für jede Situation zu erstellen und es ermöglichen, Verbesserungen einfacher zu implementieren.
<G-vec00045-002-s149><avoid.vermeiden><en> If you yourself are prone to drug abuse, you may want to avoid becoming a stripper, as the temptation to use might be higher.
<G-vec00045-002-s149><avoid.vermeiden><de> Wenn du selbst zum Drogenmissbrauch neigst, solltest du es vielleicht vermeiden, eine Stripperin zu werden, da die Versuchung höher sein könnte.
<G-vec00045-002-s150><avoid.vermeiden><en> Moreover, Article 16(1) of the same Regulation provides that national courts must avoid giving decisions which would conflict with a decision contemplated by the Commission in proceedings that it has initiated.
<G-vec00045-002-s150><avoid.vermeiden><de> Artikel 16 Absatz 1 derselben Verordnung sieht zudem vor, dass Gerichte der Mitgliedstaaten es vermeiden müssen, Entscheidungen zu erlassen, die einer Entscheidung zuwiderlaufen würden, die die Kommission in einem von ihr eingeleiteten Verfahren zu erlassen beabsichtigt.
<G-vec00045-002-s151><avoid.vermeiden><en> Always be aware of what the nuts are on every street, and avoid drawing to hands that could still finish second best.
<G-vec00045-002-s151><avoid.vermeiden><de> Daher sollte man auf jeder Straße wissen, was die Nuts sind, und es vermeiden, in Draws zu investieren, die sich dann nur als die zweitbeste Hand erweisen.
<G-vec00045-002-s285><avoid.vermeiden><en> She actually found herself on the run, strategically trying to avoid her own death until Bujin could come and help.
<G-vec00045-002-s285><avoid.vermeiden><de> Sie sah sich sogar in die Ecke gedrängt, während sie durch strategisches Denken versuchte, ihren Tod zu vermeiden, bis Bujin kommen und ihr helfen könnte, indem er ihn lähmte und ihm seine Energie abzog.
<G-vec00045-002-s286><avoid.vermeiden><en> (37) One given to faithlessness has faith by which to avoid it.
<G-vec00045-002-s286><avoid.vermeiden><de> (37) Jemand, der der Vertrauenslosigkeit verfallen ist, kann sie mit Vertrauen vermeiden.
<G-vec00045-002-s287><avoid.vermeiden><en> Use an updated anti-virus to avoid virus infection.
<G-vec00045-002-s287><avoid.vermeiden><de> Verwenden Sie eine aktuelle Antivirus-Virus-Infektion zu vermeiden.
<G-vec00045-002-s288><avoid.vermeiden><en> In order to avoid projections of load curves and price developments, all calculations are performed for the year 2010.
<G-vec00045-002-s288><avoid.vermeiden><de> Sämtliche Berechnungen werden für das Jahr 2010 durchgeführt, um die Verwendung von Prognosen für Lastgänge und Preisentwicklungen, wie sie zum Beispiel für das Jahr 2025 erforderlich wären, zu vermeiden.
<G-vec00045-002-s289><avoid.vermeiden><en> Since the extender uses Cat 5e (or better) network cable, you have the option to use existing infrastructure wiring, which helps avoid the hassle and expense of running bulky video cables.
<G-vec00045-002-s289><avoid.vermeiden><de> Da der Extender Cat 5e-Netzwerkkabel (oder höher) verwendet, können Sie vorhandene Infrastrukturkabel verwenden, sodass Sie den Aufwand und die Kosten für das Verlegen von Videokabeln vermeiden.
<G-vec00045-002-s290><avoid.vermeiden><en> We have learned about some users having experienced issues with the drive support cap of the pump (see picture below) and we want to proactively inform our customers how to avoid experiencing similar challenges.
<G-vec00045-002-s290><avoid.vermeiden><de> Wir haben erfahren, dass Insulinpumpenträger vereinzelt von einer losen Motorgehäusekappe berichtet haben (siehe Abbildung unten) und möchten daher proaktiv unsere Kunden informieren, wie sie dies vermeiden können.
<G-vec00045-002-s291><avoid.vermeiden><en> After leaving office, the Justices avoid the impression of inappropriately exploiting internal knowledge.
<G-vec00045-002-s291><avoid.vermeiden><de> Sie vermeiden den Eindruck einer unangemessenen Verwertung internen Wissens.
<G-vec00045-002-s292><avoid.vermeiden><en> Otherwise the customer can avoid an obligation to provide replacement through damage arising through use of the goods, by not treating the goods as own property and avoiding actions which reduce the value of the goods.
<G-vec00045-002-s292><avoid.vermeiden><de> Im Übrigen können Sie die Pflicht zum Wertersatz für eine durch die bestimmungsgemäße Ingebrauchnahme der Sache entstandene Verschlechterung vermeiden, indem Sie die Sache nicht wie Ihr Eigentum in Gebrauch nehmen und alles unterlassen, was deren Wert beeinträchtigt.
<G-vec00045-002-s293><avoid.vermeiden><en> Well-thought tactics was the key to success and helped avoid being covered in colorful paint.
<G-vec00045-002-s293><avoid.vermeiden><de> Eine durchdachte Taktik war der Schlüssel zum Erfolg und sie ermöglichte, den Schuss von Farbe zu vermeiden.
<G-vec00045-002-s294><avoid.vermeiden><en> Jump to Seção 4.8.1, “How to avoid the problem before upgrading” and apply one of the two proposed procedures.
<G-vec00045-002-s294><avoid.vermeiden><de> Gehen Sie zu Abschnitt 4.8.1, „Das Problem vor dem Upgrade vermeiden“ und führen Sie eine der beiden möglichen Prozeduren durch.
<G-vec00045-002-s295><avoid.vermeiden><en> Titration errors – Learn to avoid and identify them
<G-vec00045-002-s295><avoid.vermeiden><de> Fehler bei der Titration – Lernen Sie, wie Sie sie erkennen und vermeiden können.
<G-vec00045-002-s296><avoid.vermeiden><en> … with insights and information people cannot avoid taking responsibility.”
<G-vec00045-002-s296><avoid.vermeiden><de> … mit Verständnis und Informationen können sie es nicht vermeiden.
<G-vec00045-002-s297><avoid.vermeiden><en> On busy roads, set it low and flash to allow visibility and avoid the wrong kind of attention.
<G-vec00045-002-s297><avoid.vermeiden><de> Bei stark befahrenen Straßen, stellen Sie es niedrig und blinken Sie, um die Sichtbarkeit zu ermöglichen und die falsche Aufmerksamkeit zu vermeiden.
<G-vec00045-002-s298><avoid.vermeiden><en> To avoid even sharper braking in the least favorable moment, essentially by the car pushing against your brake foot when it hits the obstacle, leading to the front wheels blocking in the most unfavorable instant, i.e. deeply in the pothole or ditch, and thereby producing an extremely high load of the front axle
<G-vec00045-002-s298><avoid.vermeiden><de> Sie vermeiden, dass Sie sich durch den Stoß auf das Bremspedal stützen müssen und dadurch die Vorderräder im ungünstigsten Augenblick, nämlich tief in der Rinne, blockieren und dadurch eine extrem hohe Belastung der Vorderachse erzeugen.
<G-vec00045-002-s299><avoid.vermeiden><en> Show consideration in nature, think of the fire hazard and avoid littering.
<G-vec00045-002-s299><avoid.vermeiden><de> Zeigen Sie Respekt vor der Natur, man denke an die Brandgefahr und Littering vermeiden.
<G-vec00045-002-s300><avoid.vermeiden><en> You do not only save setup time but also avoid a damaging by storage outside the folding machine and moreover you reduce the physical stress for the operator.
<G-vec00045-002-s300><avoid.vermeiden><de> So sparen Sie nicht nur Rüstzeit, Sie vermeiden auch Beschädigungen durch eine Lagerung außerhalb der Falzmaschine und reduzieren die körperliche Belastung für den Bediener.
<G-vec00045-002-s301><avoid.vermeiden><en> A Limit Order allows fast reaction when the particular rate you want to have - or avoid - arises.
<G-vec00045-002-s301><avoid.vermeiden><de> Mit einer Limit-Order können Sie schnell reagieren, wenn ein spezieller Kurs, den Sie anstreben oder vermeiden wollen, eintritt.
<G-vec00045-002-s302><avoid.vermeiden><en> To prevent listeriosis avoid these high risk foods and thoroughly cook raw food from animal sources, such as beef, lamb, pork, or poultry, keep and prepare raw meat separate from vegetables, cooked foods, and ready- to-eat food and wash raw vegetables and fruit thoroughly before eating.
<G-vec00045-002-s302><avoid.vermeiden><de> Zur Vorbeugung gegen Listeriose sollten Sie diese Nahrungsmittel mit hohem Infektionsrisiko vermeiden und folgende Vorsichtsmaßnahmen beachten: rohe Nahrungsmittel tierischen Ursprungs (wie zum Beispiel Rind-, Lamm-, Schweinefleisch oder Geflügel) ausreichend lange gar kochen, rohes Fleisch getrennt von Gemüse, gekochten und verzehrfertigen Nahrungsmitteln aufbewahren und zubereiten, sowie rohes Gemüse und Obst vor dem Verzehr gründlich waschen.
<G-vec00045-002-s303><avoid.vermeiden><en> Change the name of file to avoid any uncertainty and click ‘Save’.
<G-vec00045-002-s303><avoid.vermeiden><de> Ändern Sie den Namen der Datei, um jede Unsicherheit zu vermeiden, und klicken Sie auf "Speichern".
<G-vec00045-002-s361><avoid.vermeiden><en> The quality of raw materials is key so is a stringent check on any production process to avoid any risk of contamination throughout the various stages and to identify potential sources of hazard.
<G-vec00045-002-s361><avoid.vermeiden><de> Die Qualität der Rohstoffe ist entscheidend, da wichtig ist es eine sorgfältige Kontrolle aller Produktionsprozesse, um eine Kontamination während der verschiedenen Schritte zu vermeiden und die mögliche Risiken zu finden.
<G-vec00045-002-s362><avoid.vermeiden><en> Read all directions fully, and follow the program exactly to avoid compounding your digestive problems.
<G-vec00045-002-s362><avoid.vermeiden><de> Lies alle Anleitungen vollständig und befolge das Programm exakt, um zu vermeiden, dein Verdauungsproblem zu verschlimmern.
<G-vec00045-002-s363><avoid.vermeiden><en> Check the conditions to avoid confusion before you deposit.
<G-vec00045-002-s363><avoid.vermeiden><de> Überprüfen Sie die Bedingungen, um Verwechslungen zu vermeiden.
<G-vec00045-002-s364><avoid.vermeiden><en> Wipe the cleaner away in a circular motion to avoid streaks.
<G-vec00045-002-s364><avoid.vermeiden><de> Wisch den Reiniger mit kreisförmigen Bewegungen ab, um Schlieren zu vermeiden.
<G-vec00045-002-s365><avoid.vermeiden><en> Therefore, it is wise to determine entry and exit points near these lines to avoid disappointment.
<G-vec00045-002-s365><avoid.vermeiden><de> Daher ist es ratsam, Eintritts - und Austrittspunkte nahe diesen Linien zu bestimmen, um Enttäuschungen zu vermeiden.
<G-vec00045-002-s366><avoid.vermeiden><en> I understand the outrage felt by many football fans but as Foreign Minister I am looking for a way to avoid a boycott.
<G-vec00045-002-s366><avoid.vermeiden><de> Ich verstehe den Unmut vieler Fußballfreunde, aber als Außenminister suche ich Lösungen, um Boykotte zu vermeiden.
<G-vec00045-002-s367><avoid.vermeiden><en> It’s the first phone to use this type of feature, which helps to avoid overheating as a result of prolonged usage and keeps users happily gaming away.
<G-vec00045-002-s367><avoid.vermeiden><de> Es ist das erste Telefon, das diese Art Feature nutzt, um Überhitzung aufgrund längerer Nutzung zu vermeiden und die Benutzer durchgehend glücklich spielen lassen zu können.
<G-vec00045-002-s368><avoid.vermeiden><en> Use −nosound −ovc raw −o /dev/null to avoid wasting CPU power for this pass.
<G-vec00045-002-s368><avoid.vermeiden><de> Benutze −nosound −ovc raw −o /dev/null, um Verschwendung von CPU-Zeit für diesen Durchlauf zu vermeiden.
<G-vec00045-002-s369><avoid.vermeiden><en> To avoid any mistakes when clipping in, the attachment loops for the MIURARS have colour identification.
<G-vec00045-002-s369><avoid.vermeiden><de> Um Fehler beim Einhängen zu vermeiden hat der MIURARS farblich markierte Einhängeschlaufen.
<G-vec00045-002-s370><avoid.vermeiden><en> Canadians: Recommend you divert YOUR course 15 degrees to the South to avoid a collision.
<G-vec00045-002-s370><avoid.vermeiden><de> Kanadier: Ich empfehle, Sie ändern IHREN Kurs um 15 Grad nach Süden, um eine Kollision zu vermeiden.
<G-vec00045-002-s371><avoid.vermeiden><en> bluecow: Fixed Kad UDP socket usage to avoid loss of packets to send.
<G-vec00045-002-s371><avoid.vermeiden><de> bluecow: Korrektur der Kad UDP Socket Nutzung, um ein Verlieren von zu sendenden Paketen zu vermeiden.
<G-vec00045-002-s372><avoid.vermeiden><en> There is something absurd about the idea of Bronze-Age craftsmen doing their best to avoid representing constellations when they probably had no fixed representations of them in the first place: if anything, the disc should have been the opportunity to prove the opposite.
<G-vec00045-002-s372><avoid.vermeiden><de> Es ist absurd anzunehmen, dass Menschen in der Bronzezeit alles taten um Konstellationen zu vermeiden, wenn sie höchstwahrscheinlich keine festen Repräsentationen von ihnen an erster Stelle hatten: wenn überhaupt, wäre die Himmelsscheibe die Gelegenheit, das Gegenteil zu beweisen.
<G-vec00045-002-s373><avoid.vermeiden><en> Attach it today and start removing chemicals and impurities from your shower to avoid dry, damaged skin and a flaky scalp.
<G-vec00045-002-s373><avoid.vermeiden><de> Befestigen Sie ihn heute und fangen Sie an, Chemikalien und Verunreinigungen von Ihrer Dusche zu entfernen, um trockene, schädigende Haut und eine flockige Kopfhaut zu vermeiden.
<G-vec00045-002-s374><avoid.vermeiden><en> In cold weather it is advisable to wear thermoelastic t-shirts to avoid the entry of cold without obstructing the movement, and waterproof and windproof jackets to be prepared for any climate change or setback.
<G-vec00045-002-s374><avoid.vermeiden><de> Bei kaltem Wetter ist es ratsam, thermoelastische T-Shirts zu tragen, um das Eindringen von Kälte zu vermeiden, ohne die Bewegung zu behindern, und wasser- und winddichte Jacken, die für jeden Klimawandel oder Rückschlag vorbereitet sind.
<G-vec00045-002-s375><avoid.vermeiden><en> If you contract Salmonella, keep hydrated, take electrolyte supplements and wash your hands to avoid infecting others.
<G-vec00045-002-s375><avoid.vermeiden><de> Wenn Sie sich mit Salmonellen infizieren, müssen Sie viel trinken, Elektrolytzusätze einnehmen und gründlich Ihre Hände waschen und desinfizieren, um eine Infektion anderer zu vermeiden.
<G-vec00045-002-s376><avoid.vermeiden><en> The first step is to collect information on each area, and on individuals in the local public security departments, to establish a more complete database, and do it within a specific timeframe to avoid inadvertently forgetting important information.
<G-vec00045-002-s376><avoid.vermeiden><de> Im ersten Schritt haben wir Informationen zu jeder Gegend und über jede einzelne Person der örtlichen öffentlichen Sicherheitsabteilungen gesammelt, eine umfassende Datenbank aufgebaut und es innerhalb eines bestimmten Zeitfensters getan, um ungewolltes Vergessen wichtiger Informationen zu vermeiden.
<G-vec00045-002-s377><avoid.vermeiden><en> Check in here to avoid those confusions.
<G-vec00045-002-s377><avoid.vermeiden><de> Überprüfen Sie, um Verwechslungen zu vermeiden.
<G-vec00045-002-s378><avoid.vermeiden><en> To avoid punishment, Gifford agreed to act as a double agent.
<G-vec00045-002-s378><avoid.vermeiden><de> Um eine Strafe zu vermeiden war Gifford bereit, als Doppelagent zu arbeiten.
<G-vec00045-002-s379><avoid.vermeiden><en> Pressing OK here will cause the symbol cache library to be saved into a special „rescue“ library and all the symbols are renamed to avoid naming conflicts.
<G-vec00045-002-s379><avoid.vermeiden><de> OK zu wählen, wird hier das alte Symbol in eine spezielle „Rettungs“-Bibliothek sichern und alle Bauteile, die dieses Symbol verwenden, umbenennen, um Namens-Konflikte zu vermeiden.
<G-vec00045-002-s475><avoid.vermeiden><en> Avoid isolating yourself, so that you can have the social connections necessary for true peace of mind.
<G-vec00045-002-s475><avoid.vermeiden><de> Vermeide Isolation aktiv, um die für deinen Seelenfrieden notwendigen sozialen Verbindungen zu halten.
<G-vec00045-002-s476><avoid.vermeiden><en> Avoid gestures such as pointing; use an open palm instead.
<G-vec00045-002-s476><avoid.vermeiden><de> Vermeide Gesten wie Fingerzeigen; zeige stattdessen deine offenen Handflächen.
<G-vec00045-002-s477><avoid.vermeiden><en> Avoid loud and aggressive persons, they are vexations to the spirit.
<G-vec00045-002-s477><avoid.vermeiden><de> Vermeide laute und agressive Personen, sie wirken vergiftend auf den Geist.
<G-vec00045-002-s478><avoid.vermeiden><en> Avoid eating processed and packaged foods, and too much sugar or salt.
<G-vec00045-002-s478><avoid.vermeiden><de> Vermeide verarbeitete und abgepackte Lebensmittel, zu viel Zucker oder Salz.
<G-vec00045-002-s479><avoid.vermeiden><en> Avoid junk food like chips and crackers.
<G-vec00045-002-s479><avoid.vermeiden><de> Vermeide Junk-Food wie Chips und Kekse.
<G-vec00045-002-s480><avoid.vermeiden><en> If you’re trying to slim down quickly, avoid beverages that are high in calories and sugar, such as alcohol, sugary soda, juice, or sweetened coffees and teas.
<G-vec00045-002-s480><avoid.vermeiden><de> Wenn du schnell abnehmen willst, vermeide kalorienreiche und zuckerreiche Getränke wie Alkohol, Limos, Saft oder gesüßten Kaffee oder Tee.
<G-vec00045-002-s481><avoid.vermeiden><en> {Avoid sweets and greasy foods.
<G-vec00045-002-s481><avoid.vermeiden><de> Vermeide Süßigkeiten und fettiges Essen.
<G-vec00045-002-s482><avoid.vermeiden><en> Avoid high-calorie beverages like soda, juice cocktails, specialty coffees, and alcohol.
<G-vec00045-002-s482><avoid.vermeiden><de> Vermeide kalorienreiche Getränke, wie Limonade, Obstcocktails, Kaffeespezialitäten und Alkohol.
<G-vec00045-002-s483><avoid.vermeiden><en> Avoid loud and aggressive persons; they are vexatious to the spirit.
<G-vec00045-002-s483><avoid.vermeiden><de> Vermeide laute und streitsüchtige Menschen; sie sind dem Geiste ein Ärgernis.
<G-vec00045-002-s484><avoid.vermeiden><en> Avoid music with lyrics or any songs you know really well because this might be too distracting for you as try to fall asleep.
<G-vec00045-002-s484><avoid.vermeiden><de> Vermeide Musik mit Gedichten oder Liedern, die du gut kennst, weil sie dich ablenken können, wenn du versuchst einzuschlafen.
<G-vec00045-002-s485><avoid.vermeiden><en> Avoid excessive social drinking.
<G-vec00045-002-s485><avoid.vermeiden><de> Vermeide exzessives Trinken in der Öffentlichkeit.
<G-vec00045-002-s486><avoid.vermeiden><en> Avoid leaving them under stimulated.
<G-vec00045-002-s486><avoid.vermeiden><de> Vermeide, sie unterfordert zu lassen.
<G-vec00045-002-s487><avoid.vermeiden><en> Avoid caffeine and alcohol.
<G-vec00045-002-s487><avoid.vermeiden><de> Vermeide Kaffee und Alkohol.
<G-vec00045-002-s488><avoid.vermeiden><en> Make sure to choose simple heels and avoid details like ankle-straps, which will cut the line of your look.
<G-vec00045-002-s488><avoid.vermeiden><de> Trage schlichte Schuhe und vermeide Details wie Knöchelriemen, die den durchgehenden Look brechen würden.
<G-vec00045-002-s489><avoid.vermeiden><en> For example, if you're heavy avoid wearing horizontal stripes, they make you look bigger.
<G-vec00045-002-s489><avoid.vermeiden><de> Zum Beispiel, wenn du schwer bist, dann vermeide horizontale Streifen, sie lassen dich größer wirken.
<G-vec00045-002-s490><avoid.vermeiden><en> Large occupy too much space, so avoid them.
<G-vec00045-002-s490><avoid.vermeiden><de> Große belegen zu viel Platz, also vermeide sie.
<G-vec00045-002-s491><avoid.vermeiden><en> • Exploration: Follow branching routes through the unknown, using your wits to avoid hazards and solve puzzles.
<G-vec00045-002-s491><avoid.vermeiden><de> • Erkundung: Folge sich verzweigenden Pfaden durch das Unbekannte, vermeide Gefahren und löse Rätsel.
<G-vec00045-002-s492><avoid.vermeiden><en> Always avoid spamming type language, repetitive keyword abuse, poor spelling and bad grammar.
<G-vec00045-002-s492><avoid.vermeiden><de> Vermeide stets Spam-artige Ausdrucksweisen, wiederholte Verwendung von Keywords, schlechte Rechtschreibung und falsche Grammatik.
<G-vec00045-002-s493><avoid.vermeiden><en> If the battery is weak or dead, avoid filling the cells fully.
<G-vec00045-002-s493><avoid.vermeiden><de> Wenn die Batterie schwach oder entladen ist, vermeide ein komplettes Befüllen der Zellen.
<G-vec00045-002-s494><avoid.vermeiden><en> Avoid interrupting or giving your opinion until the person is done talking.
<G-vec00045-002-s494><avoid.vermeiden><de> Vermeide es, zu unterbrechen oder deine Meinung mitzuteilen, bis die Person mit dem Sprechen fertig ist.
<G-vec00045-002-s495><avoid.vermeiden><en> If the weather calls for rain, avoid building your tent in a steep valley that will collect water.
<G-vec00045-002-s495><avoid.vermeiden><de> Wenn es nach Regen aussieht, vermeide es, dein Zelt in einem Talgebiet zu bauen, indem sich das Wasser ansammeln könnte.
<G-vec00045-002-s496><avoid.vermeiden><en> Using the mouse, gather batteries for bonuses and avoid getting caught between the quickly moving walls.
<G-vec00045-002-s496><avoid.vermeiden><de> Kersplat Benutze die Maus um Batterien zu sammeln und vermeide es, zwischen den sich schnell bewegenden Wänden zerquetscht zu werden.
<G-vec00045-002-s497><avoid.vermeiden><en> Avoid sitting on a bed or soft sofa.
<G-vec00045-002-s497><avoid.vermeiden><de> Vermeide es, auf deinem Bett oder einem Sofa zu sitzen.
<G-vec00045-002-s498><avoid.vermeiden><en> Push your upper back towards the ceiling to avoid "drooping" your shoulder region.
<G-vec00045-002-s498><avoid.vermeiden><de> Drücke deinen Oberkörper zur Decke und vermeide es, die Schultergegend fallen zu lassen.
<G-vec00045-002-s499><avoid.vermeiden><en> Avoid looking up or tilting your head upwards, and try thinking of the note as farther away from you, rather than somewhere up in the air.
<G-vec00045-002-s499><avoid.vermeiden><de> Vermeide es, nach oben zu sehen oder deinen Kopf nach oben zu neigen, und versuche, dir vorzustellen, dass die Noten weiter weg von dir sind, statt irgendwo oben in der Luft.
<G-vec00045-002-s500><avoid.vermeiden><en> Avoid exposure to concentrated fumes from paints, especially when spraying them.
<G-vec00045-002-s500><avoid.vermeiden><de> Vermeide es, die konzentrierten Dämpfe der Farben einzuatmen, insbesondere wenn diese aufgesprüht werden.
<G-vec00045-002-s501><avoid.vermeiden><en> Avoid making too many comparisons with your old job, and work to create positive change where you can.
<G-vec00045-002-s501><avoid.vermeiden><de> Vermeide es, zu viele Vergleiche mit deinem alten Job zu ziehen, und versuche, wo immer es möglich ist, positive Veränderungen zu bewirken.
<G-vec00045-002-s502><avoid.vermeiden><en> Avoid posting a list of highly specific and inflexible demands.
<G-vec00045-002-s502><avoid.vermeiden><de> Vermeide es hochspezifische oder inflexible Forderungen an einen zukünftigen Partner zu stellen.
<G-vec00045-002-s503><avoid.vermeiden><en> Emulate or avoid.
<G-vec00045-002-s503><avoid.vermeiden><de> Ahme es nach, oder vermeide es.
<G-vec00045-002-s504><avoid.vermeiden><en> Be fun and playful and avoid being negative around your guy.
<G-vec00045-002-s504><avoid.vermeiden><de> Sei witzig und spielerisch und vermeide es, negativ zu wirken.
<G-vec00045-002-s505><avoid.vermeiden><en> Avoid using headache painkillers, even over-the-counter types, for more than 2 or 3 days per week.
<G-vec00045-002-s505><avoid.vermeiden><de> Vermeide es, Kopfschmerztabletten, sogar rezeptfreie, öfter als an zwei oder drei Tagen pro Woche zu nehmen.
<G-vec00045-002-s506><avoid.vermeiden><en> Avoid starting sentences with coordinating conjunctions such as "and" or "but"; use other types of transitions instead.
<G-vec00045-002-s506><avoid.vermeiden><de> Vermeide es auch, Sätze mit Konjunktionen wie "und" oder "aber" zu beginnen – verwende besser andere Überleitungen.
<G-vec00045-002-s507><avoid.vermeiden><en> Maybe your counterpart has a nickname that they can’t stand: then avoid calling the person that way, otherwise you will only make yourself unappealing.
<G-vec00045-002-s507><avoid.vermeiden><de> Vielleicht hat dein Gegenüber einen Spitznamen, den es gar nicht ausstehen kann: Vermeide es dann, die Person so anzusprechen, ansonsten machst du dich nur unsympathisch.
<G-vec00045-002-s508><avoid.vermeiden><en> Avoid eating to excess, but allow yourself to eat things that satisfy you and fulfill cravings.
<G-vec00045-002-s508><avoid.vermeiden><de> Vermeide es, exzessiv zu essen, aber gestatte dir selbst, Dinge zu essen, die du gern magst, und die Gelüste zu stillen.
<G-vec00045-002-s509><avoid.vermeiden><en> Avoid being arrogant or simplistic in deducing the motivations of others and give credit where it is due.
<G-vec00045-002-s509><avoid.vermeiden><de> Vermeide es, arrogant zu sein oder die Motivationen anderer zu einfach einzuschätzen und schenke Glauben, wenn es angebracht ist.
<G-vec00045-002-s510><avoid.vermeiden><en> Avoid composting any material that shows signs of disease.
<G-vec00045-002-s510><avoid.vermeiden><de> Vermeide es, Materialien zu kompostieren, die Anzeichen einer Krankheit zeigen.
<G-vec00045-002-s511><avoid.vermeiden><en> Avoid taking estrogen pills or estrogen supplements to increase breast size.
<G-vec00045-002-s511><avoid.vermeiden><de> Vermeide es, Östrogenpillen oder Nahrungsergänzungsmittel mit Östrogenen einzunehmen, um deine Brüste zu vergrößern.
<G-vec00045-002-s512><avoid.vermeiden><en> Avoid eating this plant, or you may have severe stomach upset.
<G-vec00045-002-s512><avoid.vermeiden><de> Vermeide es, diese Pflanze zu essen, da man sonst schwere Magenprobleme bekommen kann.
<G-vec00045-002-s513><avoid.vermeiden><en> In order to avoid misuse, staff at registration offices and private companies have to be able to check both quickly and reliably whether the documents presented are genuine or not.
<G-vec00045-002-s513><avoid.vermeiden><de> Auch Mitarbeiter in Meldestellen und vielen Unternehmen müssen – um Missbrauch zu vermeiden – vorgelegte Ausweisdokumente schnell und zuverlässig darauf überprüfen können, ob sie echt oder gefälscht sind.
<G-vec00045-002-s514><avoid.vermeiden><en> You can use the internet or stream music with your iPad Air over a Wi-Fi network to avoid going over your mobile data allowance.
<G-vec00045-002-s514><avoid.vermeiden><de> Sie können auch das Internet verwenden oder mit Ihrem Apple iPad Mini über ein Wi-Fi-Netzwerk Musik streamen, um zu vermeiden, dass Sie Ihr mobiles Datenvolumen überschreiten.
<G-vec00045-002-s515><avoid.vermeiden><en> We think and avoid incidents before they occur.
<G-vec00045-002-s515><avoid.vermeiden><de> Wir denken mit und vermeiden Fehler, bevor sie auftreten.
<G-vec00045-002-s516><avoid.vermeiden><en> Travelers should only consume bottled water and avoid swimming or bathing in bodies of standing water.
<G-vec00045-002-s516><avoid.vermeiden><de> Reisende sollten kein Leitungs- oder Regenwasser trinken und das Schwimmen oder Baden in stehenden Gewässern vermeiden.
<G-vec00045-002-s517><avoid.vermeiden><en> Do not allow the pot soil to dry out, but avoid standing water.
<G-vec00045-002-s517><avoid.vermeiden><de> Den Topfballen nicht austrocknen lassen, aber auch stehende Nässe vermeiden.
<G-vec00045-002-s518><avoid.vermeiden><en> Do it with pessimism not negativity: prepare for the worst, so you can avoid bad things.
<G-vec00045-002-s518><avoid.vermeiden><de> Machen Sie es mit Pessimismus und nicht mit Negativität: Bereiten Sie sich auf das Schlimmste vor, damit Sie schlechte Dinge vermeiden können.
<G-vec00045-002-s519><avoid.vermeiden><en> In order to keep negative environmental impacts as low as possible, all employees are required by AURELIUS travel policy to plan trips for maximum efficiency, and to avoid unnecessary travel.
<G-vec00045-002-s519><avoid.vermeiden><de> Um negative Umwelteinflüsse möglichst gering zu halten, werden alle Mitarbeiter durch die AURELIUS Reiserichtlinie dazu angehalten, ihre Reisen möglichst effizient zu planen und unnötige Reisen zu vermeiden.
<G-vec00045-002-s520><avoid.vermeiden><en> Choose the type of road (with or without highway), avoid toll roads, select the means of travel (car, public transit, cycling, walking), check the traffic situation on the road from Valley, NE to Alum Rock, CA.
<G-vec00045-002-s520><avoid.vermeiden><de> Wählen Sie den Typ der Straße (mit oder ohne Autobahn), Mautstraßen vermeiden, wählen Sie das Verkehrsmittel (Auto, öffentlichen Verkehrsmitteln, Fahrradfahren, Reise zu Fuß), überprüfen Sie die Verkehrssituation auf der Straße von Elk Creek, NE nach Guadalupe, CA.
<G-vec00045-002-s521><avoid.vermeiden><en> A fear for overfeeding is unnecessary, but it might be a good idea to restrict the amount in smaller tanks to avoid excessive waste production.
<G-vec00045-002-s521><avoid.vermeiden><de> Angst vor Überfütterung ist nicht angebracht, ist aber eine gute Idee um in kleineren Aquarien übermäßige Abfallproduktion zu vermeiden.
<G-vec00045-002-s522><avoid.vermeiden><en> Water-cooled engines for the servo-electrical drive axles avoid air turbulences.
<G-vec00045-002-s522><avoid.vermeiden><de> Wassergekühlte Motoren für die servoelektrischen Antriebsachsen vermeiden Luftverwirbelungen.
<G-vec00045-002-s523><avoid.vermeiden><en> There are several things to be aware of if you want to keep your playing regulated and avoid falling into addiction, as well as remaining safe on casino sites.
<G-vec00045-002-s523><avoid.vermeiden><de> Es gibt mehrere Dinge, die Sie beachten sollten, wenn Sie reguliert spielen und vermeiden möchten, süchtig zu werden, oder einfach sicher auf Casino-Webseiten unterwegs sein möchten.
<G-vec00045-002-s524><avoid.vermeiden><en> Or perhaps you’re planning a cross-country trip and looking to avoid as many motorways as possible.
<G-vec00045-002-s524><avoid.vermeiden><de> Vielleicht planen Sie auch eine Reise quer durchs Land und möchten Autobahnen dabei möglichst vermeiden.
<G-vec00045-002-s525><avoid.vermeiden><en> In order to avoid these major incidents, which can result in loss of life and assets, organizations need to proactively introduce operational business process improvements and manage risks that exist within their operations.
<G-vec00045-002-s525><avoid.vermeiden><de> Um solche größeren Zwischenfälle zu vermeiden, die Menschenleben und Vermögenswerte aufs Spiel setzen, benötigen Unternehmen proaktive Verbesserungen ihrer operativen Unternehmensprozesse und ein Risikomanagement für ihre Betriebsabläufe.
<G-vec00045-002-s526><avoid.vermeiden><en> Engine testing inspection, avoid oil-water-air-leak problem .
<G-vec00045-002-s526><avoid.vermeiden><de> Engine testing Inspektion, Öl-Wasser-Luft-Leck-Problem zu vermeiden.
<G-vec00045-002-s527><avoid.vermeiden><en> As a result, it will be necessary to treat the mother in order to avoid reinfecting the puppies.
<G-vec00045-002-s527><avoid.vermeiden><de> Dadurch wird es notwendig, die Mutter zu behandeln, um zu vermeiden, dass die Welpen wieder Flöhe bekommen.
<G-vec00045-002-s528><avoid.vermeiden><en> In order to avoid further misunderstandings and without further ado she changed her name to Bailly.
<G-vec00045-002-s528><avoid.vermeiden><de> Um weitere Missverständnisse zu vermeiden, änderte sie kurzerhand ihren Namen in Bailly.
<G-vec00045-002-s529><avoid.vermeiden><en> You can skip this bad frame by checking "Avoid incomplete conversion" option under the "Advanced" tab of the "Edit>Options" window.
<G-vec00045-002-s529><avoid.vermeiden><de> Sie können den fehlerhaften Framen überspringen, indem Sie die Option "Unvollständige Konvertierung vermeiden" unter der Registerkarte "Fortgeschritten" aktivieren.
<G-vec00045-002-s530><avoid.vermeiden><en> It is my duty to avoid any dangerous situations in the game.
<G-vec00045-002-s530><avoid.vermeiden><de> Es liegt in meiner eigenen Verantwortung gefährliche Situationen im Spiel zu vermeiden.
<G-vec00045-002-s531><avoid.vermeiden><en> Being properly prepared and knowing how to recognize problems before they get serious will help you to avoid injuries and having to take a break from training.
<G-vec00045-002-s531><avoid.vermeiden><de> Wenn du lernst, Warnsignale frühzeitig zu erkennen, bevor sie zu einer ernsthaften Beeinträchtigung werden, kannst du rechtzeitig eine Trainingspause einlegen und so Verletzungen vermeiden.
<G-vec00045-002-s532><avoid.vermeiden><en> THE IMPORTANCE OF PRICE A similar waste of resources would result if workers and unions were uncertain about future inflation and therefore demanded a rather high nominal wage increase in order to avoid high future inflation leading to significant declines in real wages.
<G-vec00045-002-s532><avoid.vermeiden><de> Eine ähnliche Verschwendung von Ressourcen ergäbe sich, wenn sich Arbeitnehmer und Gewerkschaften bezüglich der künftigen Inflation unsicher wären und deshalb eine deutlichere Erhöhung des Nominallohns forderten, um zu vermeiden, dass eine künftige hohe Inflationsrate zu gravierenden Einbußen bei den Reallöhnen führt.
<G-vec00045-002-s533><avoid.vermeiden><en> Try to avoid running too many programs that take up too much processing power at one time.
<G-vec00045-002-s533><avoid.vermeiden><de> Versuchen Sie zu vermeiden, dass zu viele Programme laufen, die auf einmal zu viel Rechenleistung in Anspruch nehmen.
<G-vec00045-002-s534><avoid.vermeiden><en> Wrap longer text over multiple lines to avoid text getting cut off in smaller breakpoints.
<G-vec00045-002-s534><avoid.vermeiden><de> Ordnen Sie längeren Text über mehrere Zeilen an, um zu vermeiden, dass Text an kleineren Umbruchpunkten abgeschnitten wird.
<G-vec00045-002-s535><avoid.vermeiden><en> It is quite common for people to download license keys from many peer-to-peer sites, in an attempt to avoid paying for tools that require the key for activation of full features.
<G-vec00045-002-s535><avoid.vermeiden><de> Es ist durchaus üblich, dass man Lizenzschlüssel von vielen Peer-to-Peer-Websites herunterlädt, um zu vermeiden, dass man für Tools bezahlt, die den Schlüssel für die Aktivierung der vollen Funktionen benötigen.
<G-vec00045-002-s536><avoid.vermeiden><en> To avoid getting overwhelmed, configure your chat software to automatically hide your chatbox once you hit a certain number of simultaneous conversations; our team caps at five per person.
<G-vec00045-002-s536><avoid.vermeiden><de> Um zu vermeiden, dass Sie aufgrund zu vieler gleichzeitiger Chats überfordert sind, konfigurieren Sie Ihre Chat-Software so, dass Ihre Chatbox automatisch verschwindet, wenn eine gewisse Anzahl von zeitgleichen Gesprächen erreicht ist.
<G-vec00045-002-s537><avoid.vermeiden><en> In order to avoid the escape of cold air and the external heat entering while opening the refrigerator, you must frequently use the compressor, which will leads to an increase of power consumption.
<G-vec00045-002-s537><avoid.vermeiden><de> Um zu vermeiden, dass beim Öffnen des Kühlschranks kalte Luft und Wärme von außen entweichen, müssen Sie häufig den Kompressor verwenden, was zu einer Erhöhung des Stromverbrauchs führt.
<G-vec00045-002-s538><avoid.vermeiden><en> It is advisable to eat some light food between meals to avoid eating too much during these.
<G-vec00045-002-s538><avoid.vermeiden><de> Es wird empfohlen, zwischen den Mahlzeiten etwas Leichtes zu essen, um zu vermeiden, dass man während der Mahlzeiten zu viel isst.
<G-vec00045-002-s539><avoid.vermeiden><en> Hence, when they circulate, they do so in very controlled conditions, both to avoid them being stolen and being damaged.
<G-vec00045-002-s539><avoid.vermeiden><de> Wenn sie in Umlauf gebracht werden, dann geschieht dies unter sehr kontrollierten Bedingungen, denn man möchte vermeiden, dass sie gestohlen oder beschädigt werden.
<G-vec00045-002-s540><avoid.vermeiden><en> DoubleClick uses cookies to display ads that are relevant to the user, to improve reports on the campaign's success, or to avoid repeatedly showing the same ad to a particular user.
<G-vec00045-002-s540><avoid.vermeiden><de> DoubleClick setzt Cookies ein, um für die Nutzer relevante Anzeigen zu schalten, die Berichte zur Kampagnenleistung zu verbessern oder um zu vermeiden, dass ein Nutzer die gleichen Anzeigen mehrmals sieht.
<G-vec00045-002-s541><avoid.vermeiden><en> In addition to knowing which numbers should be placed we also know where they should be since the 5’s must be diagonal to avoid a number appearing in the same row or column more than once.
<G-vec00045-002-s541><avoid.vermeiden><de> Abgesehen davon, dass wir die Zahlen kennen, wissen wir auch, wie sie platziert werden müssen, da die Fünfen nur diagonal zueinander stehen können, um zu vermeiden, dass sie in derselben Spalte oder Reihe zweimal vorkommen.
<G-vec00045-002-s542><avoid.vermeiden><en> Use products that contain at least SPF 15 to avoid damage caused by the sun.
<G-vec00045-002-s542><avoid.vermeiden><de> Verwende Produkte, die mindestens einen Sonnenschutzfaktor 15 enthalten, um zu vermeiden, dass deine Lippen durch die Sonne geschädigt werden.
<G-vec00045-002-s543><avoid.vermeiden><en> You can in many cases avoid employees quitting because of dissatisfaction with their work if you work smarter and start asking your former employees why they chose to leave.
<G-vec00045-002-s543><avoid.vermeiden><de> NETIGATE VOICE OF EMPLOYEE LÖSUNGEN In vielen Fällen können Sie vermeiden, dass Mitarbeiter aufgrund von Unzufriedenheit kündigen, indem Sie damit beginnen, ausgeschiedene Mitarbeiter danach zu fragen, warum sie sich entschieden haben zu gehen.
<G-vec00045-002-s544><avoid.vermeiden><en> Ensure servers are always up to date with all security updates and avoid servers running with vulnerabilities for months just to avoid downtime
<G-vec00045-002-s544><avoid.vermeiden><de> Stellen Sie sicher, dass Ihre Server stets mit allen wichtigen Sicherheitsupdates versorgt werden und vermeiden Sie, dass Server monatelang mit Sicherheitslücken betrieben werden.
<G-vec00045-002-s545><avoid.vermeiden><en> In this game you need to avoid It is very difficult.
<G-vec00045-002-s545><avoid.vermeiden><de> In diesem Spiel müssen Sie vermeiden, dass es sehr schwierig ist.
<G-vec00045-002-s546><avoid.vermeiden><en> Wherever you stay in the region, there is at most a 30-minute drive to the coast, so you can hardly avoid beaches, coastal areas, the countless small harbours, the sea and all the many activities having the sea as their focus during your holiday.
<G-vec00045-002-s546><avoid.vermeiden><de> Wo auch immer Sie sich in der Region aufhalten, ist die Küste höchstens eine halbe Stunde Fahrt entfernt, sodass man kaum vermeiden kann, dass Strände, Küstengebiete, die unzähligen kleinen Häfen, das Meer und all die zahlreichen Aktivitäten im Zusammenhang mit dem Meer einen wichtigen Teil Ihres Urlaubs ausmachen werden.
<G-vec00045-002-s547><avoid.vermeiden><en> To avoid the animals from becoming habituated, it generates a burst of roughly 1 second every 10 seconds.
<G-vec00045-002-s547><avoid.vermeiden><de> Um zu vermeiden, dass sich die Tiere an ihn gewöhnen, erzeugt er alle 10 s einen Burst von etwa 1 s. Da Menschen nicht hören können, ob die Schaltung aktiv ist, indiziert eine LED den Betrieb.
<G-vec00045-002-s548><avoid.vermeiden><en> Why turboSMTP There are very important reasons for using a professional SMTP server: in the past (before the spam era), sending emails was not problematical, whereas nowadays it is extremely important to follow the regulations of all email servers in order to avoid messages ending up in spam folders or even being deleted by email servers.
<G-vec00045-002-s548><avoid.vermeiden><de> Es gibt sehr wichtige Gründe für den Einsatz eines professionellen SMTP-Servers: in der Vergangenheit (vor der Spam-Ära), bereitete das Versenden von Emails keine Probleme, während es heute äußerst wichtig ist, den E-Mail Regelungen aller Server zu folgen, um zu vermeiden, dass Nachrichten im Spam-Ordner landen oder sogar von Email Servern gelöscht werden.
<G-vec00045-002-s549><avoid.vermeiden><en> Section B.2.2, "Using boot parameters to preseed questions" offers a way to avoid these questions being asked.
<G-vec00045-002-s549><avoid.vermeiden><de> Abschnitt B.2.2, "Boot-Parameter nutzen, um Fragen automatisiert zu beantworten" zeigt aber einen Weg, trotzdem zu vermeiden, dass diese Fragen gestellt werden.
<G-vec00045-002-s550><avoid.vermeiden><en> Avoid sweating directly on the wood.
<G-vec00045-002-s550><avoid.vermeiden><de> Vermeiden Sie, dass Schweiß auf das Holz tropft.
<G-vec00045-002-s551><avoid.vermeiden><en> Avoid the skin around the eyes.
<G-vec00045-002-s551><avoid.vermeiden><de> Vermeiden Sie die Haut um die Augen.
<G-vec00045-002-s552><avoid.vermeiden><en> Avoid unnecessary costs and optimize the long-term availability.
<G-vec00045-002-s552><avoid.vermeiden><de> Vermeiden Sie unnötige Kosten und optimieren Sie die langfristige Verfügbarkeit.
<G-vec00045-002-s553><avoid.vermeiden><en> Avoid lengthy lines and the hassle of ticket counters.
<G-vec00045-002-s553><avoid.vermeiden><de> Vermeiden Sie lange Warteschlangen und Stress an den Ticketschaltern.
<G-vec00045-002-s554><avoid.vermeiden><en> Note: Avoid installing or running Remo Recover or any application programs on the drive, which is re-formatted, as it may overwrite the previous data by saving / updating new data.
<G-vec00045-002-s554><avoid.vermeiden><de> Hinweis: Vermeiden Sie die Installation oder Ausführung von Remo Recover oder irgendwelchen Anwendungsprogrammen auf dem neu formatierten Laufwerk, da dadurch die vorherigen Daten durch Speichern / Aktualisieren neuer Daten überschrieben werden können.
<G-vec00045-002-s555><avoid.vermeiden><en> Avoid unwanted charges by cancelling unwanted apps two days before your billing date.
<G-vec00045-002-s555><avoid.vermeiden><de> Vermeiden Sie unerwünschte Kosten, indem Sie nicht mehr gewünschte Apps spätestens zwei Tage vor dem Abrechnungsdatum kündigen.
<G-vec00045-002-s556><avoid.vermeiden><en> Avoid the crowds on this private full-day tour and visit the affluent suburbs of Olivos and San Isidro, explore historic Tigre, and enjoy a catamaran cruise around the delta.
<G-vec00045-002-s556><avoid.vermeiden><de> Vermeiden Sie die Menschenmassen auf dieser privaten Tagestour und besuchen Sie die wohlhabenden Vororte Olivos und San Isidro, erkunden Sie das historische Tigre und unternehmen Sie eine Katamaran-Kreuzfahrt durch das Delta.
<G-vec00045-002-s557><avoid.vermeiden><en> Avoid crashing as you drive fast, brake and jump over all of the many obstacles in your way.
<G-vec00045-002-s557><avoid.vermeiden><de> Vermeiden Sie zu krachen, während Sie schnell fahren, bremsen und über die vielen Hindernisse in Ihrem Weg springen.
<G-vec00045-002-s558><avoid.vermeiden><en> In this case, be sure to reproof the color on every spread that has transparency, and avoid using the Difference and Exclusion blend modes—these modes can change the appearance dramatically.
<G-vec00045-002-s558><avoid.vermeiden><de> Prüfen Sie die Farbe erneut auf jedem Druckbogen, der Transparenz aufweist, und vermeiden Sie die Füllmethoden „Differenz“ und „Ausschluss“, da diese das Erscheinungsbild drastisch ändern können.
<G-vec00045-002-s559><avoid.vermeiden><en> But be careful, avoid betting or risky business, where you have to rely on the honesty of others.
<G-vec00045-002-s559><avoid.vermeiden><de> Aber seien Sie vorsichtig, vermeiden Sie Wetten oder riskantes Geschäft, wo Sie sich auf die Ehrlichkeit von anderen verlassen müssen.
<G-vec00045-002-s560><avoid.vermeiden><en> Avoid rubbing over all surfaces if possible.
<G-vec00045-002-s560><avoid.vermeiden><de> Vermeiden Sie möglichst das Reiben über alle Oberflächen.
<G-vec00045-002-s561><avoid.vermeiden><en> Avoid large food and fluid intake before bed: sleep and let restless.
<G-vec00045-002-s561><avoid.vermeiden><de> Vermeiden Sie größere Nahrungs- und Flüssigkeitsaufnahme vor dem Zubettgehen: und lassen Sie unruhig schlafen.
<G-vec00045-002-s562><avoid.vermeiden><en> By nomination Grau Rechtsanwälte LLP, as an external data protector officer, your company can easily avoid a liability risk, which is inevitable by creating an internal data protector officer.
<G-vec00045-002-s562><avoid.vermeiden><de> Mit der Bestellung von Grau Rechtsanwälte LLP als Ihren externen Datenschutzbeauftragten vermeiden Sie außerdem Haftungsrisiken, die bei der Beschäftigung eines internen Datenschutzbeauftragten unumgänglich bestehen.
<G-vec00045-002-s563><avoid.vermeiden><en> 7- AVOID STRESS: One of the biggest enemies of IVF treatment is stress.
<G-vec00045-002-s563><avoid.vermeiden><de> 7 - Vermeiden Sie Stress: Einer der größten Feinde der IVF-Behandlung ist Stress.
<G-vec00045-002-s564><avoid.vermeiden><en> Green environmental protection: avoid the environmental pollution caused by spraying; materials can be recycled 100%.
<G-vec00045-002-s564><avoid.vermeiden><de> Grüner Umweltschutz: Vermeiden Sie die Umweltverschmutzung durch Sprühen; Materialien können zu 100% recycelt werden.
<G-vec00045-002-s565><avoid.vermeiden><en> Avoid watching TV or using your computer/smartphone or tablet in the evening, at least an hour or so before going to bed.
<G-vec00045-002-s565><avoid.vermeiden><de> Vermeiden Sie das Fernsehen oder den Computer am Abend, mindestens eine Stunde vor dem Schlafengehen.
<G-vec00045-002-s566><avoid.vermeiden><en> Avoid misleading the width of your strip.
<G-vec00045-002-s566><avoid.vermeiden><de> Vermeiden Sie die Irreführung der Breite Ihres Streifens.
<G-vec00045-002-s567><avoid.vermeiden><en> Avoid flying obstacles such as bombs, hamburgers, bananas.
<G-vec00045-002-s567><avoid.vermeiden><de> Vermeiden Sie fliegende Hindernisse wie Bomben, Hamburger, Bananen.
<G-vec00045-002-s568><avoid.vermeiden><en> Do not inhale fuel vapors, and avoid any contact of fuel or oil with your skin.
<G-vec00045-002-s568><avoid.vermeiden><de> Atmen Sie die Kraftstoffdämpfe nicht ein und vermeiden Sie jeglichen Kontakt des Kraftstoffs oder Öls mit Ihrer Haut.
<G-vec00045-002-s569><avoid.vermeiden><en> Additionally, players will have to activate the built-in "set my status to DND during games"-mode to avoid external people Aufrufe
<G-vec00045-002-s569><avoid.vermeiden><de> Außerdem haben Spieler den integrierten "setze meinen Status während Spielen auf DND"-Modus zu aktivieren, um zu vermeiden, dass sie während der Spiele von externen Leuten kontaktiert / gestört werden.
<G-vec00045-002-s570><avoid.vermeiden><en> We all seem normal people and usually we avoid coming in situations where this problem is triggered and usually we succeed in doing so, but it makes us not free.
<G-vec00045-002-s570><avoid.vermeiden><de> Wir scheinen normale Menschen, und normalerweise vermeiden wir in Situationen zu kommen, in dem dieses Problem sich zeigen kann und meistens gelingt das, aber dadurch sind wir nicht frei.
<G-vec00045-002-s571><avoid.vermeiden><en> Gentle remove the dirt, please avoid contacting with eyes.
<G-vec00045-002-s571><avoid.vermeiden><de> Leicht entfernen Sie den Schmutz, vermeiden bitte, mit Augen in Verbindung zu treten.
<G-vec00045-002-s572><avoid.vermeiden><en> Avoid traffic jams with “jam alarm” Commuters help to avoid congestion and relaxed driving, which is the noble goal of the new function “traffic jam alarm” at the App ADAC Maps.
<G-vec00045-002-s572><avoid.vermeiden><de> Staus vermeiden mit “Stau-Alarm” Pendlern helfen Staus zu vermeiden und entspannt zu fahren, das ist das hehre Ziel der neuen Funktion “Stau-Alarm” bei der App ADAC Maps.
<G-vec00045-002-s573><avoid.vermeiden><en> In order to avoid any potential abuse, we may ask that you identify yourself adequately.
<G-vec00045-002-s573><avoid.vermeiden><de> Um Missbrauch zu vermeiden, können wir Sie auffordern, sich entsprechend zu identifizieren.
<G-vec00045-002-s574><avoid.vermeiden><en> The house has air conditioning system with ducts throughout the house with external machines on the roof to avoid noise or break the aesthetics of the house.. .
<G-vec00045-002-s574><avoid.vermeiden><de> Das Haus verfügt über eine Klimaanlage mit Klimakanälen im ganzen Hause mit externen Maschinen auf dem Deck Lärm zu vermeiden oder die Ästhetik des Gehäuses zu brechen.. .
<G-vec00045-002-s575><avoid.vermeiden><en> Consequently, one must avoid any attempt to oppose sacramental Baptism, the Baptism of desire and Baptism of blood as antithetical.
<G-vec00045-002-s575><avoid.vermeiden><de> Folglich ist jeder Versuch zu vermeiden, die sakramentale Taufe, die Begierdetaufe und die Bluttaufe in einen Gegensatz zueinander zu stellen.
<G-vec00045-002-s576><avoid.vermeiden><en> Download Snowl and avoid being overwhelmed by the Internet's information overload.
<G-vec00045-002-s576><avoid.vermeiden><de> Laden Sie Snowl herunter und vermeiden Sie so, von der Informationsüberlastung, die das Internet anbietet,überwältigt zu werden.
<G-vec00045-002-s577><avoid.vermeiden><en> Avoid choosing a domain name which is too long or too complicated for users to remember.
<G-vec00045-002-s577><avoid.vermeiden><de> Vermeiden Sie, ein Domain Name zu wählen, das zu lang oder zu schwierig ist, damit Benutzer sich erinnern.
<G-vec00045-002-s578><avoid.vermeiden><en> But because you get more shaky the longer you stay on the stand because of the fatigue from skiing, you try to avoid these reloads and choose the same risk as in individual events.
<G-vec00045-002-s578><avoid.vermeiden><de> Da es, je länger man am Stand steht, aufgrund der Erschöpfung durch das Laufen, immer zittriger wird, versucht man diese Nachlader zu vermeiden und das gleiche Risiko wie in den Individualstarts zu wählen.
<G-vec00045-002-s579><avoid.vermeiden><en> The best time to avoid the crowds and find cheap hotels in Southampton is to travel in spring or autumn.
<G-vec00045-002-s579><avoid.vermeiden><de> Es ist am besten, eine Reise nach Southampton im Frühling oder Herbst zu unternehmen, um Menschenmengen zu vermeiden und günstige Hotels in der Stadt zu finden.
<G-vec00045-002-s580><avoid.vermeiden><en> That’s why our fully automatic coffee speciality machines come with innovative technologies and energy saving modes to avoid unnecessary power consumption and actively save energy.
<G-vec00045-002-s580><avoid.vermeiden><de> Deshalb helfen Ihnen unsere Kaffeespezialitäten-Vollautomaten mit innovativen Technologien und Energie-Sparmodi dabei, unnötigen Stromverbrauch zu vermeiden und aktiv Energie zu sparen.
<G-vec00045-002-s581><avoid.vermeiden><en> Stalin had hoped that he could avoid war with Germany through his cowardly and treacherous non-aggression pact.
<G-vec00045-002-s581><avoid.vermeiden><de> Stalin hatte gehofft, durch seinen feigen und verräterischen Nichtangriffspakt den Krieg mit Deutschland vermeiden zu können.
<G-vec00045-002-s582><avoid.vermeiden><en> In other words, you’re brain often goes for the direct approach to growing your account as opposed to the non-direct route of taking many small losses to avoid the big loss while always keeping your eye out for the trade that works right away and therefore has less risk.
<G-vec00045-002-s582><avoid.vermeiden><de> In anderen Worten, Ihr Gehirn wählt oft den direkten Ansatz, um Ihr Konto zu erhöhen, anstatt den nicht direkten Weg mit wenigen, geringen Verluste, um den großen Verlust zu vermeiden, und dabei immer wieder einen Trade zu suchen, der gleich erfolgreich ist und somit weniger Risiko erfordert.
<G-vec00045-002-s583><avoid.vermeiden><en> This will help you avoid overeating at the table.
<G-vec00045-002-s583><avoid.vermeiden><de> Dadurch vermeiden Sie, zu viel am Tisch zu essen.
<G-vec00045-002-s584><avoid.vermeiden><en> Try to avoid standing in the same position for a long period of time.
<G-vec00045-002-s584><avoid.vermeiden><de> Versuche es zu vermeiden, über einen längeren Zeitraum in der gleichen Haltung zu stehen.
<G-vec00045-002-s585><avoid.vermeiden><en> To avoid omitting it we would like to know if you have it at your disposal where in the various holy places.
<G-vec00045-002-s585><avoid.vermeiden><de> Um zu vermeiden, darauf zu verzichten, kennten wir gern, ob Sie es zu Ihrer Verfügung haben, wo in unterschiedlichen Heiligen Orten.
<G-vec00045-002-s586><avoid.vermeiden><en> The practical application of HACCP is designed to avoid hazards that could lead to the sickening or injuring of humans and animals.
<G-vec00045-002-s586><avoid.vermeiden><de> Die praktische Anwendung des Konzepts soll Gefahren vermeiden, die zu einer Erkrankung oder Verletzung von Mensch und Tier führen könnten.
<G-vec00045-002-s587><avoid.vermeiden><en> To earn points you should throw green items out of the screen and avoid droping red ones.
<G-vec00045-002-s587><avoid.vermeiden><de> Um Punkte zu verdienen, sollten Sie grüne Sachen aus dem Schirm werfen und vermeiden, rote fallen zu lassen.
<G-vec00045-002-s588><avoid.vermeiden><en> It is interesting to see how therapy using holotropic states of consciousness can help us to avoid the dilemmas inherent in the situation described above.
<G-vec00045-002-s588><avoid.vermeiden><de> Therapien, die das heilende Potenzial holotroper Bewusstseinszustände nutzen, können uns helfen, die Probleme zu vermeiden, die die verbalen Techniken der Psychotherapie plagt: zu bestimmen, was in der Schilderung eines Klienten relevant ist, und die richtige Interpretation zu wählen.
<G-vec00045-002-s589><avoid.vermeiden><en> Here, we do not refer to physical movement (though that may aid your spiritual progress) but to the PACE AT WHICH YOU LEARN AND AT WHICH YOU SUBSEQUENTLY AVOID MAKING THE SAME MISTAKES.
<G-vec00045-002-s589><avoid.vermeiden><de> Hier beziehen wir uns nicht auf physische Bewegung (obwohl diese für euren spirituellen Fortschritt hilfreich sein mag), sondern auf die GESCHWINDIGKEIT MIT DER IHR LERNT UND MIT DER IHR IN DER FOLGE VERMEIDET, DIE SELBEN FEHLER ZU WIEDERHOLEN.
<G-vec00045-002-s590><avoid.vermeiden><en> If you avoid challenging work, you avoid doing what it takes to succeed.
<G-vec00045-002-s590><avoid.vermeiden><de> Wenn man anspruchsvolle Arbeit meidet, dann vermeidet man das, was einem Erfolg einbringt.
<G-vec00045-002-s591><avoid.vermeiden><en> On the other hand, Washington avoid declaring its open support to the YPG in the region in order to avoid further diplomatic escalation with Turkey.
<G-vec00045-002-s591><avoid.vermeiden><de> Andererseits vermeidet Washington seine Unterstützung der YPG in der Region offiziell zuzugeben, um eine weitere diplomatische Eskalation mit der Türkei zu verhindern.
<G-vec00045-002-s592><avoid.vermeiden><en> The left turn assist function can avoid a collision by warning the driver or by automatically applying the brakes.
<G-vec00045-002-s592><avoid.vermeiden><de> Der Linksabbiegeassistent vermeidet Kollisionen, indem er den Fahrer warnt oder das Fahrzeug selbsttätig abbremst.
<G-vec00045-002-s593><avoid.vermeiden><en> Your ski pass is a chip card, which helps you avoid long waiting times at the lifts.
<G-vec00045-002-s593><avoid.vermeiden><de> Ihr Skipass ist eine Chipkarte, die lange Wartezeiten an den Liftanlagen vermeidet.
<G-vec00045-002-s594><avoid.vermeiden><en> Use your Costume Brawl skills to hit other players in Costume Brawl mode to gain points and avoid being disabled by taking too many hits yourself.
<G-vec00045-002-s594><avoid.vermeiden><de> Verwendet eure eigenen Kostüm-Rauferei-Fertigkeiten, um andere Spieler im Kostüm-Rauferei-Modus zu treffen und Punkte zu sammeln und vermeidet dabei selber zu viele Treffer einzustecken und ausgeschaltet zu werden.
<G-vec00045-002-s595><avoid.vermeiden><en> It is desirable that the patient avoid close contact with others, it is also possible to use means that increase immunity to help the body cope with a fungal disease.
<G-vec00045-002-s595><avoid.vermeiden><de> Es ist wünschenswert, dass der Patient engen Kontakt mit anderen vermeidet, es ist auch möglich, Mittel zu verwenden, die die Immunität erhöhen, um dem Körper zu helfen, mit einer Pilzerkrankung fertig zu werden.
<G-vec00045-002-s596><avoid.vermeiden><en> This lets them avoid downtime.
<G-vec00045-002-s596><avoid.vermeiden><de> Das vermeidet Standzeiten.
<G-vec00045-002-s597><avoid.vermeiden><en> Thus insolvency under self-administration is the restructuring instrument when insolvency can no longer be avoided but the company has a business operation that is worth continuing and the entrepreneur has the objective of maintaining the company. ‘Custom’ regulations can be created in an insolvency plan that are optimum for the solution of the corporate crisis and that avoid the risk of facts that are relevant for the liability of the organs.
<G-vec00045-002-s597><avoid.vermeiden><de> Die Planinsolvenz unter Eigenverwaltung ist daher das Sanierungsinstrument, wenn eine Insolvenz nicht mehr zu vermeiden ist, das Unternehmen gleichwohl über einen fortführungswürdigen Geschäftsbetrieb verfügt und der Unternehmer das Ziel verfolgt das Unternehmen zu erhalten.In dem zu erstellenden Insolvenzplan, können für das Unternehmen „maßgeschneiderte“ Regelungen getroffen werden, die für die Lösung der Unternehmenskrise optimal sind und die Gefahr von haftungsrelevanten Tatsachen für die Organe vermeidet.
<G-vec00045-002-s598><avoid.vermeiden><en> The patients learn how to communicate effectively, how to avoid provocative situations and contacts with people who are still on drugs, how to overcome the drug memories and drug behavior from the past, how to restore moral, integrity and responsibility, how to rebuild social skills.
<G-vec00045-002-s598><avoid.vermeiden><de> Die Patienten lernen, wie man effektiv kommuniziert, wie man provokativen Situationen und Kontakte mit Menschen, die noch Drogen nehmen, vermeidet, wie man die Erinnerungen an die Droge und das Drogenverhalten überwindet, wie man seine Moral, Integrität und Verantwortung wiederherstellt und auch wie man soziale Fähigkeiten wieder aufbaut.
<G-vec00045-002-s599><avoid.vermeiden><en> In such cases to avoid potential damages, the DRP, after some automatic re-start attempts, makes the pump enter the stand-by mode.
<G-vec00045-002-s599><avoid.vermeiden><de> In solchen Fällen vermeidet der DRP nach einigen automatischen Wiederstartversuchen die Pumpe in den Stand-by-Modus.
<G-vec00045-002-s600><avoid.vermeiden><en> Avoid risky activities.
<G-vec00045-002-s600><avoid.vermeiden><de> Vermeidet risikoreiche Aktivitäten.
<G-vec00045-002-s601><avoid.vermeiden><en> The unique skin friendly precision trimmer system is built to avoid unnecessary skin contact.
<G-vec00045-002-s601><avoid.vermeiden><de> Hautfreundlicher Präzisionstrimmer Das einzigartige System des hautfreundlichen Präzisionstrimmers vermeidet unnötigen Hautkontakt.
<G-vec00045-002-s602><avoid.vermeiden><en> Instead of waiting for the machine unexpected interruption, Remote Care proactively analyzes machine performance, ensures production efficiency, helps to avoid unplanned production stops and saves time in correcting malfunctions.
<G-vec00045-002-s602><avoid.vermeiden><de> Statt zu warten, bis die Maschine unerwartet stehenbleibt, analysiert Remote Care vorausschauend das Betriebsverhalten der Maschine, gewährleistet die wirtschaftliche Produktion, vermeidet unplanmäßige Produktionsausfälle und spart beim Beseitigen von Betriebsstörungen Zeit ein.
<G-vec00045-002-s603><avoid.vermeiden><en> In this helpful overview, we’ll be exploring some of the most common grammar problems English learners face and how you can avoid them when you speak with others.
<G-vec00045-002-s603><avoid.vermeiden><de> In dieser hilfreichen Übersicht werden wir einige der häufigsten Grammatikprobleme ergründen, die Englischlerner machen, und wie man sie vermeidet, wenn man mit anderen Leuten spricht.
<G-vec00045-002-s604><avoid.vermeiden><en> Avoid taking public transportation or taxis.
<G-vec00045-002-s604><avoid.vermeiden><de> Vermeidet die öffentlichen Verkehrsmittel oder Taxis.
<G-vec00045-002-s605><avoid.vermeiden><en> A parent who can fluctuate between different parenting styles, when necessary, and avoid ever being neglectful, is on the right track to raising a high-functioning and happy child.
<G-vec00045-002-s605><avoid.vermeiden><de> Ein Elternteil, der zwischen verschiedenen Elternstilen schwanken kann, wenn es nötig ist, und vermeidet, vernachlässigend zu werden, ist auf dem richtigen Weg ein hochfunktionierenden und glückliches Kind zu begleiten.
<G-vec00045-002-s606><avoid.vermeiden><en> Foamed PE for insulating the inner conductor to avoid loss of signals.
<G-vec00045-002-s606><avoid.vermeiden><de> Geschäumtes PE zur Isolierung des Innenleiters vermeidet Signalverluste.
<G-vec00045-002-s607><avoid.vermeiden><en> This will not only increase efficiency, but also avoid complications.
<G-vec00045-002-s607><avoid.vermeiden><de> Das schafft nicht nur Effizienz, sondern vermeidet auch Komplikationen.
<G-vec00045-002-s627><avoid.vermeiden><en> He explained that Baden-Württemberg’s decision could save thousands of tonnes of fuel in the future and thus avoid CO2 emissions.
<G-vec00045-002-s627><avoid.vermeiden><de> Mit der Entscheidung Baden-Württembergs könnten künftig tausende Tonnen Kraftstoff eingespart und damit CO2-Emissionen vermieden werden.
<G-vec00045-002-s628><avoid.vermeiden><en> By researching, by developing, by promoting new technologies across the world, all nations, including the developing countries can advance economically, while slowing the growth in global greenhouse gases and avoid pollutants that undermines public health.
<G-vec00045-002-s628><avoid.vermeiden><de> Durch Forschung, Entwicklung und die Förderung neuer Technologien überall auf der Welt können alle Nationen, auch die Entwicklungsländer, wirtschaftliche Fortschritte verzeichnen, wobei der weltweite Anstieg an Treibhausgasen gebremst und der Ausstoß von Schadstoffen, die der öffentlichen Gesundheit schaden, vermieden wird.
<G-vec00045-002-s629><avoid.vermeiden><en> Therefore, in this embodiment of the present invention, the resynchronization of the clocks is by an offset time is determined at each computer, and the offset time for the processing of data is used to avoid the computers.
<G-vec00045-002-s629><avoid.vermeiden><de> Daher wird in dieser Ausführung der vorliegenden Erfindung die Neusynchronisation der Uhren an den Computern vermieden, indem eine Offset-Zeit an jedem Computer bestimmt wird und die Offset-Zeit für die Verarbeitung von Daten verwendet wird.
<G-vec00045-002-s630><avoid.vermeiden><en> As opposed to clutches, brakes avoid the use of rotary joints or engagement bearings to actuate the gearshift.
<G-vec00045-002-s630><avoid.vermeiden><de> Im Gegensatz zu Kupplungen wird bei Bremsen der Einsatz von Drehdurchführungen oder Einrücklagern zur Betätigung des Schaltelements vermieden.
<G-vec00045-002-s631><avoid.vermeiden><en> Using this very expensive but extremely efficient measure means it is possible to avoid the consequences of incorrect tempering temperatures such as cracks in the weld seam.
<G-vec00045-002-s631><avoid.vermeiden><de> Mit dieser sehr teuren, aber extrem effizienten Maßnahme werden die Folgen falscher Anlasstemperaturen, wie Risse an der Schweißstelle, vermieden.
<G-vec00045-002-s632><avoid.vermeiden><en> Thereby the state of the product development and process planing is contantly documented in order to constructively avoid failure costs.
<G-vec00045-002-s632><avoid.vermeiden><de> Dabei wird der Stand der Produktentwicklung und der Prozessplanung stets dokumentiert, damit Fehlerkosten konstruktiv vermieden werden können.
<G-vec00045-002-s633><avoid.vermeiden><en> Goods must be packaged in such a manner as to avoid any damage in transit.
<G-vec00045-002-s633><avoid.vermeiden><de> Die Waren sind so zu verpacken, dass Transportschäden vermieden werden.
<G-vec00045-002-s634><avoid.vermeiden><en> This will avoid divergent national measures or practices and obstacles to the internal market.
<G-vec00045-002-s634><avoid.vermeiden><de> Dadurch werden voneinander abweichende nationale Maßnahmen und Vorgehensweisen sowie Hindernisse für den Binnenmarkt vermieden.
<G-vec00045-002-s635><avoid.vermeiden><en> Jutta Gutwinski-Jeggle: Pathologische subjektive Phantasien Abstract Based on a case history that deals with a subjective misconception in the sense of a pathological conviction of the patient which severely limited his quality of life, it is hypothesized that the negative self-attribution, which is based on a real, conscious experience during schooling, can be understood as a defense against unconscious infantile emotional experiences which serves to avoid the reliving of traumatic states.
<G-vec00045-002-s635><avoid.vermeiden><de> Abstract Anhand einer Fallgeschichte, in der es um eine subjektive Mißkonzeption geht im Sinne einer pathologischen Überzeugung des Patienten, die seine Lebensqualität massiv einschränkte, wird die Hypothese aufgestellt, dass die negative Selbstzuschreibung, die auf einer realen, bewussten Erfahrung während der Schulzeit beruht, als Abwehr unbewusster frühkindlicher emotionaler Mangelerfahrungen und Zusammenbrüche zu verstehen ist, durch die das Wiedererleben damals erlittener traumatischer Zustände vermieden werden soll.
<G-vec00045-002-s636><avoid.vermeiden><en> The situations of scandal relating to some of our Bishops and clergy, and the necessary measures that have to be taken to avoid a repetition of these situations, must not make us lose sight of the fact that it is also necessary to favor the development of a full and fruitful ministry for priests.
<G-vec00045-002-s636><avoid.vermeiden><de> Die Skandale, die einige Bischöfe und Priester begangen haben, und die Maßnahmen, durch die eine Wiederholung solcher Fälle vermieden werden soll, dürfen uns nicht die Tatsache aus den Augen verlieren lassen, dass man auch die Entwicklung eines vollkommenen und fruchtbaren Dienstamtes für die Hirten fördern muss.
<G-vec00045-002-s637><avoid.vermeiden><en> The way we increasingly manage to avoid accidents and incidents is to apply the conclusions from detailed investigations of all incidents and to put them into practice without delay.
<G-vec00045-002-s637><avoid.vermeiden><de> Unfälle und Zwischenfälle werden zunehmend vermieden, indem wir die Erkenntnisse aus detaillierten Untersuchungen aller Vorfälle umgehend umsetzen.
<G-vec00045-002-s638><avoid.vermeiden><en> Multiple database worker threads can execute scripts simultaneously, so for best throughput you need to avoid database contention in your synchronization scripts.
<G-vec00045-002-s638><avoid.vermeiden><de> Da mehrere Datenbank-Worker-Threads Skripten gleichzeitig ausführen können, wird der beste Durchsatz erzielt, wenn in den Synchronisationsskripten Datenbankkonflikte vermieden werden.
<G-vec00045-002-s639><avoid.vermeiden><en> Unifrax is committed to developing an organisational culture which implements a policy of support for the internationally recognised human rights contained within the Universal Declaration of Human Rights and seeks to avoid complicity in human rights abuses.
<G-vec00045-002-s639><avoid.vermeiden><de> Unifrax verpflichtet sich zur Schaffung einer Unternehmenskultur, in der die international anerkannten Menschenrechte der UN-Menschenrechtscharta umgesetzt werden und in der eine Mittäterschaft bei einer Verletzung dieser Rechte vermieden wird.
<G-vec00045-002-s640><avoid.vermeiden><en> It will avoid constant start and stop of your compressor.
<G-vec00045-002-s640><avoid.vermeiden><de> Hierdurch wird der ständige Start und Stopp des Kompressors vermieden.
<G-vec00045-002-s641><avoid.vermeiden><en> The decisive upside of buying a company before the insolvency petition is filed is that it helps avoid the negative image of a failed company that is otherwise projected to the market.
<G-vec00045-002-s641><avoid.vermeiden><de> Der entscheidende Vorteil eines Unternehmenskaufs vor Insolvenzantragstellung ist, dass die mit der Insolvenz einhergehende negative Marktwahrnehmung vermieden wird.
<G-vec00045-002-s642><avoid.vermeiden><en> When freedom of association issues are discovered through auditing, union allegations, strikes or via our Fairness Channel compliance hotlines, we take decisive action to work together with the proper groups to resolve the issue, ensure the fair treatment of workers and implement the necessary safeguards to avoid being repeated in the future.
<G-vec00045-002-s642><avoid.vermeiden><de> Wenn Probleme hinsichtlich der Vereinigungsfreiheit durch Audits, Gewerkschaftsvorwürfe, Streiks oder über unsere Fairness Channel Compliance-Hotlines aufgedeckt werden, handeln wir entschlossen und arbeiten mit den entscheidenden Gruppen zusammen, um das Problem zu lösen, eine faire Behandlung der Arbeiter zu gewährleisten und die erforderlichen Vorkehrungen zu treffen, damit eine Wiederholung in der Zukunft vermieden wird.
<G-vec00045-002-s643><avoid.vermeiden><en> I used to avoid talking about death, but now I am at peace with it.
<G-vec00045-002-s643><avoid.vermeiden><de> Ich hatte es zuvor vermieden, über den Tod zu sprechen, aber jetzt bin ich damit völlig im Reinen.
<G-vec00045-002-s644><avoid.vermeiden><en> From individual speciality toxicology and IND enabling studies to tailored packages and total laboratory support, our highly experienced team can design and implement programmes that anticipate challenges and avoid road blocks for a smooth, efficient journey to market.
<G-vec00045-002-s644><avoid.vermeiden><de> Unser erfahrenes Team kann von der individuellen Toxikologie und IND-aktivierten Studien bis hin zu maßgeschneiderten Paketen und umfassender Laborunterstützung Programme entwickeln und ausführen, bei denen Herausforderungen antizipiert und Hürden vermieden werden und am Ende eine reibungslose und effiziente Markteinführung ermöglicht wird.
<G-vec00045-002-s645><avoid.vermeiden><en> A functioning data management system helps them avoid risks and generate value.
<G-vec00045-002-s645><avoid.vermeiden><de> Auf Basis eines funktionierenden Datenschutz Managements werden Risiken vermieden und Werte generiert.
<G-vec00045-002-s646><avoid.vermeiden><en> The sole purpose of this policy is to avoid potential misunderstandings or disputes when ProgressSoft products or marketing strategies might seem similar to ideas submitted to ProgressSoft.
<G-vec00045-002-s646><avoid.vermeiden><de> Anhand dieser Politik sollen mögliche Missverständnisse oder Streitigkeiten vermieden werden, wenn ProgressSoft Produkte oder Marketing-Strategien solchen Ideen ähneln, die an ProgressSoft geschickt wurden.
<G-vec00045-002-s647><avoid.vermeiden><en> The use of Liverxin® is also recommended to avoid cellular damage to the liver due to alcohol abuse.
<G-vec00045-002-s647><avoid.vermeiden><de> Darüber hinaus ist der Einsatz von Liverxin® aber auch sinnvoll, wenn aufgrund einer übermäßigen Alkoholzufuhr eine Leberzellschädigung durch Bildung von Acetaldehyd vermieden werden soll.
<G-vec00045-002-s648><avoid.vermeiden><en> Uncertain behavior is common to every person, but only in childhood can one avoid serious problems in the future.
<G-vec00045-002-s648><avoid.vermeiden><de> Unsicheres Verhalten ist jedem Menschen gemeinsam, aber nur in der Kindheit können ernsthafte Probleme in der Zukunft vermieden werden.
<G-vec00045-002-s649><avoid.vermeiden><en> One goal is to avoid what is known as glass corrosion.
<G-vec00045-002-s649><avoid.vermeiden><de> Dabei soll unter anderem die sogenannte Glaskorrosion vermieden werden.
<G-vec00045-002-s650><avoid.vermeiden><en> 23 organisations including the Free Software Foundation Europe (FSFE) joined up in proposing measures to EU institutions and EU member states to avoid negative implications on users' rights and Free Software imposed by the EU Radio Equipment Directive 2014/53/EU. Lue lisää...
<G-vec00045-002-s650><avoid.vermeiden><de> 23 Organisationen, darunter die Free Software Foundation Europe (FSFE), haben sich zusammengeschlossen, um den EU-Institutionen und den EU-Mitgliedstaaten Vorschläge zu unterbreiten, wie negative Auswirkungen auf Nutzerrechte und Freie Software vermieden werden können, die von der EU-Richtlinie für Funkanlagen (auch Funkrichtlinie genannt) verursacht werden.
<G-vec00045-002-s651><avoid.vermeiden><en> They must initially avoid food and liquids, because eating and drinking stimulate the pancreas.
<G-vec00045-002-s651><avoid.vermeiden><de> Anfänglich müssen Nahrung und Flüssigkeiten vermieden werden, da essen und trinken die Bauchspeicheldrüse anregt.
<G-vec00045-002-s652><avoid.vermeiden><en> To a certain extent, it can avoid overwriting the lost messages, which will further cause the missing messages never recoverable.
<G-vec00045-002-s652><avoid.vermeiden><de> Bis zu einem gewissen Grad kann vermieden werden, dass verlorene Nachrichten überschrieben werden, was dazu führt, dass die fehlenden Nachrichten niemals wiederhergestellt werden können.
<G-vec00045-002-s653><avoid.vermeiden><en> The direct or indirect offer, payment, soliciting or acceptance of bribes in any form is unacceptable and we must avoid conflicts of interest.
<G-vec00045-002-s653><avoid.vermeiden><de> Das direkte oder indirekte Angebot, die Zahlung, das Einholen oder die Annahme von Bestechungsgeldern in jeglicher Form ist inakzeptabel und Interessenkonflikte müssen vermieden werden.
<G-vec00045-002-s654><avoid.vermeiden><en> Advanced vSphere Discovery In order to efficiently discover unknown devices, RayVentory uses information from the vSphere infrastructure to avoid unnecessary network scanning (ping and port scanning).
<G-vec00045-002-s654><avoid.vermeiden><de> Um das Auffinden von unbekannten Geräten effizient durchzuführen, greift RayVentory die Informationen der vSphere Infrastruktur auf, so dass beispielsweise ein unnötiger Netzwerkscan (Ping- und Port-Scanning) vermieden werden kann.
<G-vec00045-002-s655><avoid.vermeiden><en> Third,it is necessary to avoid frequent power failure of the detector, which will cause the detection element to work unstable.
<G-vec00045-002-s655><avoid.vermeiden><de> Drittens muss ein häufiger Stromausfall des Detektors vermieden werden, der dazu führt, dass das Detektionselement instabil arbeitet.
<G-vec00045-002-s656><avoid.vermeiden><en> Humidity and temperature sensors auto-adjust drying time and energy consumption for every size of load, to preserve garment textures and avoid over-drying.
<G-vec00045-002-s656><avoid.vermeiden><de> Feuchtigkeits- und Temperatursensoren stellen die Trocknungsdauer und den Energiebedarf für jede Beladung automatisch ein, damit die Gewebestrukturen geschont und Übertrocknen vermieden werden.
<G-vec00045-002-s657><avoid.vermeiden><en> It is also often possible to avoid using unspecific insecticides and pesticides, as DNA barcoding can be used to quickly identify the eggs and larval stages of possible pests and thus be able to use targeted countermeasures.
<G-vec00045-002-s657><avoid.vermeiden><de> Auch der Verzicht auf unspezifische Insektizide und Pestizide kann oft vermieden werden, da man mithilfe des DNA Barcodings auch schon die Eier und Larvenstadien der möglichen Schädlinge schnell identifizieren kann und somit gezielte Gegenmaßnahmen einsetzen kann.
<G-vec00045-002-s659><avoid.vermeiden><en> I give “the free” only as a translation of “the liberals,” but with regard to the concept of freedom, as with generally so many other things whose anticipatory mention I can’t avoid, I must refer to what comes later.
<G-vec00045-002-s659><avoid.vermeiden><de> Ich gebe die „Freien“ nur als eine Übersetzung der Liberalen, muss aber rücksichtlich des Freiheitsbegriffes wie überhaupt so manches Anderen, dessen vorgreifliche Heranziehung nicht vermieden werden kann, auf Späteres verweisen.
<G-vec00045-002-s660><avoid.vermeiden><en> To ensure repaired endoscopes won’t adversely affect patients, we use only direct and indirect patient contact components, parts, glues, adhesives and lubricants that have been thoroughly tested for biocompatibility to avoid cytotoxicity, irritation and sensitization. Protection from cross-contamination risk
<G-vec00045-002-s660><avoid.vermeiden><de> Um sicherzustellen, dass die reparierten Endoskope dem Patienten nicht schaden, verwenden wir für den direkten oder indirekten Patientenkontakt nur solche Bau- und Ersatzteile, Klebe-, Haft- und Schmiermittel, die sorgfältig auf ihre Biokompatibilität getestet wurden, sodass Zytotoxizität, Reizung und Überempfindlichkeitsreaktionen vermieden werden.
<G-vec00045-002-s661><avoid.vermeiden><en> The purpose is to provide a milling center able to increase the production of the customers: waterjet technology allows to process various materials with high precision and rapidity and, minimizing the effect of the heat, it is possible to avoid the possible deformations due to thermal and mechanical stresses.
<G-vec00045-002-s661><avoid.vermeiden><de> Damit wird den Kunden ein Fräszentrum angeboten, mit dem sie ihre Produktion erhöhen können: dank der Waterjet-Technologie können unterschiedlichste Materialien mit höchster Präzision und Geschwindigkeit verarbeitet werden, da beim „Kaltschneideverfahren“ eventuelle Verformungen aufgrund thermischer und mechanischer Belastungen vermieden werden.
<G-vec00045-002-s662><avoid.vermeiden><en> The corrective part of the SGP, is meant to avoid gross errors in budgetary policies.
<G-vec00045-002-s662><avoid.vermeiden><de> Mit der korrektiven Komponente des SWP sollen schwerwiegende Fehler in der Haushaltspolitik vermieden werden.
<G-vec00045-002-s663><avoid.vermeiden><en> Furthermore, regular cleaning and maintenance can avoid unnecessary costs for repair work and service.
<G-vec00045-002-s663><avoid.vermeiden><de> Darüber hinaus können durch regelmäßige Reinigung und Instandhaltung unnötige Wartung- und Reparaturkosten vermieden werden.
<G-vec00045-002-s664><avoid.vermeiden><en> That way, they can avoid braking or accelerating unnecessarily.
<G-vec00045-002-s664><avoid.vermeiden><de> So kann unnötiges Bremsen und Beschleunigen vermieden werden.
<G-vec00045-002-s779><avoid.vermeiden><en> The screw points have blunted ends to avoid piercing sensitive flesh while still pressing in on their package.
<G-vec00045-002-s779><avoid.vermeiden><de> Die Schraubenpunkte haben abgestürzte Enden um ernsthafte Verletzungen zu vermeiden.
<G-vec00045-002-s780><avoid.vermeiden><en> Necessary encryption and security measures are strengthened to avoid any future instances of such kind.
<G-vec00045-002-s780><avoid.vermeiden><de> Notwendige Verschlüsselungs- und Sicherheitsmaßnahmen werden verstärkt, um zukünftige Fälle dieser Art zu vermeiden.
<G-vec00045-002-s781><avoid.vermeiden><en> This section is about your responsibilities while using SexCht services. We kindly ask you to read this section of Terms and Conditions carefully through, to avoid any unpleasant situations.
<G-vec00045-002-s781><avoid.vermeiden><de> Dieser Abschnitt handelt von Ihrer Verantwortung während der Nutzung der Dienste von Wir bitten Sie höflich, diesen Abschnitt der Allgemeinen Geschäftsbedingungen durchzulesen, um unangenehme Situationen zu vermeiden.
<G-vec00045-002-s782><avoid.vermeiden><en> The all-important rst step is to make employ- ees and managers aware of the risks related to data protection, so that they are able to detect and avoid them.
<G-vec00045-002-s782><avoid.vermeiden><de> Zentraler Ansatz- punkt ist die Sensibilisierung von Mitarbei- tern und Führungskräften, um Datenschutz- risiken zu erkennen und zu vermeiden.
<G-vec00045-002-s783><avoid.vermeiden><en> To avoid single points of failure, we recommend you include a distribution alias in addition to specific individuals.
<G-vec00045-002-s783><avoid.vermeiden><de> Um einzelne Fehlerstellen zu vermeiden, empfehlen wir, zusätzlich zu bestimmten Personen ein Verteiler-Alias als technischen Notfallkontakt anzugeben.
<G-vec00045-002-s784><avoid.vermeiden><en> Mostly an outcross is done to avoid too close inbreeding.
<G-vec00045-002-s784><avoid.vermeiden><de> Ein Outcross wird meist gemacht, um allzu enge Inzucht zu vermeiden.
<G-vec00045-002-s785><avoid.vermeiden><en> Raskonservatsiya begins with the cleaning of skimmers in order to avoid getting into them microorganisms.
<G-vec00045-002-s785><avoid.vermeiden><de> Raskonservatsiya beginnt mit der Reinigung von Skimmern, um Mikroorganismen zu vermeiden.
<G-vec00045-002-s786><avoid.vermeiden><en> To avoid a collision it is required for some steering wheels that their shifter paddles will be removed.
<G-vec00045-002-s786><avoid.vermeiden><de> Um eine Kollision zu vermeiden müssen bei manchen Lenkrädern deren eigene Schalthebel demontiert werden.
<G-vec00045-002-s787><avoid.vermeiden><en> Lists and infographics that highlight key points are also effective ways to avoid content overload.
<G-vec00045-002-s787><avoid.vermeiden><de> Listen und Infografiken, in denen Sie die wichtigsten Punkte herausstellen, sind weitere wirkungsvolle Möglichkeiten, zu lange Inhalte zu vermeiden.
<G-vec00045-002-s788><avoid.vermeiden><en> Take this medicine by mouth with a glass of water.Take after a meal or snack to avoid stomach upset.
<G-vec00045-002-s788><avoid.vermeiden><de> Schlucken Sie das Medikament zusammen mit etwas Wasser nach einer Mahlzeit oder einem Snack, um eine Magenverstimmung zu vermeiden.
<G-vec00045-002-s789><avoid.vermeiden><en> If a pathology is detected, the doctor prescribes treatment or a scoring correction to avoid further deterioration of vision.
<G-vec00045-002-s789><avoid.vermeiden><de> Wenn eine Pathologie festgestellt wird, verschreibt der Arzt eine Behandlung oder eine Korrektur des Scores, um eine weitere Verschlechterung des Sehvermögens zu vermeiden.
<G-vec00045-002-s790><avoid.vermeiden><en> The network of pipes is protected to avoid blows to the racks when the stored goods are handled. In the conventional racks, the tubes are placed behind the beams and in the cantilever racks, they hang from the ceiling into the interior of the columns.
<G-vec00045-002-s790><avoid.vermeiden><de> Das Rohrnetz ist geschützt, um Stöße bei der Handhabung der gelagerten Ware zu vermeiden Bei den Palettenregalanlagen sind die Rohre hinter den Längsträgern angebracht und bei den Kragarmregalen verlaufen sie vom Dach hinab bis ins Innere der Ständer.
<G-vec00045-002-s791><avoid.vermeiden><en> To avoid these effects, spasms must be treated early or prevented entirely.
<G-vec00045-002-s791><avoid.vermeiden><de> Um diese Effekte zu vermeiden, müssen Krämpfe frühzeitig behandelt oder ganz verhindert werden.
<G-vec00045-002-s792><avoid.vermeiden><en> We usually declare it as a sample and a low value to avoid high tax.
<G-vec00045-002-s792><avoid.vermeiden><de> Normalerweise deklarieren wir es als Stichprobe und als niedrigen Wert, um hohe Steuern zu vermeiden.
<G-vec00045-002-s793><avoid.vermeiden><en> <Class> "Latest Windows versions like 98, ME, XP, etc. already comes with patches that may help you avoid these attacks.
<G-vec00045-002-s793><avoid.vermeiden><de> <Class> Für aktuellere Windowsversionen wie 98, ME, XP und so weiter gibt es mittlerweile Patches, die euch helfen könnten solche Angriffe zu vermeiden.
<G-vec00045-002-s794><avoid.vermeiden><en> Card Detail: Material: PVC Card size: CR80 85.5*54mm, thickness 0.76mm(0.03in) Guilloche Pattern: an ornamental pattern or border, consisting of paired ribbons or lines base on a principle or standard to avoid copy or clone.
<G-vec00045-002-s794><avoid.vermeiden><de> Karte Details: Material: PVC-Karte Größe: CR80 85,5 * 54 mm, Dicke 0.76mm(0.03in) Guilloche-Muster: ein ornamentales Muster oder Grenze, bestehend aus gekoppelten Bänder oder Linien basieren auf einem Prinzip oder Standard, Kopie oder Klon zu vermeiden.
<G-vec00045-002-s795><avoid.vermeiden><en> PRE is useful for formatting computer code or poetry where whitespace is important, but since preformatted text is inherently visual, authors should avoid dependence on it wherever possible.
<G-vec00045-002-s795><avoid.vermeiden><de> PRE ist nützlich um Computer-Code oder Gedichte darzustellen, wo Leerräume wichtig sind, aber da vorformatierter Text vorwiegend visuell ist, sollten Autoren eine zu große Abhängigkeit davon vermeiden.
<G-vec00045-002-s796><avoid.vermeiden><en> In the current complicated international situation marked by a high level of turbulence and more pronounced manifestations of crisis, we must not forget the lessons of the past in order to avoid making irreparable mistakes in the future.
<G-vec00045-002-s796><avoid.vermeiden><de> In der aktuellen, nicht einfachen internationalen Situation, die sich durch große Turbulenzen und die Zunahme der Krisenerscheinungen gekennzeichnet ist, dürfen die Lehren der Vergangenheit nicht vergessen werden, um irreversible Fehler in der Zukunft zu vermeiden.
<G-vec00045-002-s797><avoid.vermeiden><en> Chromalox SLB Silicone Laminate Rubber Heaters provided the flexibility required to meet the tight tolerances and avoid wiring terminator issues.
<G-vec00045-002-s797><avoid.vermeiden><de> Chromalox SLB Silikon-beschichtete Gummiheizkörper besitzen die erforderliche Flexibilität, um die engen Toleranzen einzuhalten und Probleme bei der Endverkabelung zu vermeiden.
<G-vec00174-002-s342><avoid.verhindern><en> Equipped with a vacuum system on top of the filler, it is capable to suck in acid steam to avoid the development of corrosion on the blowing part.
<G-vec00174-002-s342><avoid.verhindern><de> Auf dem Füller ist ein Vakuumsystem installiert, das den saueren Dampf absaugt, um eine Korrosion des Streckblasabschnitts zu verhindern.
<G-vec00174-002-s343><avoid.verhindern><en> Spending inputs mixed using PrivateSend incurs the usual standard or InstantSend fees, but to avoid creating a potentially identifiable change address, the fee is always rounded up to the lowest possible denomination.
<G-vec00174-002-s343><avoid.verhindern><de> Das Versenden einer PrivateSend-Transaktion kostet die gleiche Gebühr, wie eine normale Transaktion, doch um das Identifizieren des Nutzers durch die Wechselgeldadresse zu verhindern, wird die Gebühr immer auf die nächst-höhere Denomination aufgerundet.
<G-vec00174-002-s344><avoid.verhindern><en> Furthermore, the edges 106 of the retainer 24 are distinctly rounded to avoid damaging the casing 104 when changing the position of the trocar sleeve 26.
<G-vec00174-002-s344><avoid.verhindern><de> Darüber hinaus sind die Kanten 106 des Halte mittels 24 hier deutlich abgerundet ausgeführt, um eine Beschä digung der Hülle 104 beim Verstellen der Position der Trokar hülse 26 zu verhindern.
<G-vec00174-002-s345><avoid.verhindern><en> 1. To avoid price collapses in the internal market and to remedy situations of overproduction based on the forecast supply balance, and taking into account the commitments of the Union resulting from international agreements concluded in accordance with the Treaty, the Commission may adopt implementing acts, containing decisions to withdraw from the market, for a given marketing year, those quantities of sugar or isoglucose produced under quotas which exceed the threshold calculated in accordance with paragraph 2 of this Article.
<G-vec00174-002-s345><avoid.verhindern><de> (1) Um einen Preisverfall auf dem Binnenmarkt zu verhindern und im Fall einer auf der Grundlage der Bedarfsvorausschätzung festgestellten Überproduktion Abhilfe zu schaffen, sowie unter Berücksichtigung der Verpflichtungen der Union, die sich aus gemäß dem AEUV geschlossenen internationalen Übereinkünften ergeben, kann die Kommission Durchführungsrechtsakte zur Rücknahme, für ein bestimmtes Wirtschaftsjahr, der Mengen an Quotenzucker oder Quotenisoglucose, die die gemäß Absatz 2 berechnete Schwelle überschreiten, vom Markt erlassen.
<G-vec00174-002-s346><avoid.verhindern><en> Even if it were assumed to the appellant's benefit that this contribution was known, then the skilled person would have concluded in view of (1) and (10) that the suspending effect of the asbestos fibres is not sufficient to avoid settling and stratifying to the desired extent since addition of a suspending agent or pre-treatment of the lime is necessary to obtain the desired settling resistance.
<G-vec00174-002-s346><avoid.verhindern><de> Selbst wenn man zugunsten der Beschwerdeführerin annimmt, daß dieser Beitrag bekannt war, hätte der Fachmann aus den Dokumenten 1 und 10 geschlossen, daß die Suspensionswirkung der Asbestfasern nicht ausreicht, um ein Absetzen und eine Schichtung im gewünschten Umfang zu verhindern, weil dort die Zugabe eines Suspensionsmittels oder eine Vorbehandlung des Kalks erforderlich war, um die gewünschte Antiabsetzwirkung zu erzielen.
<G-vec00174-002-s347><avoid.verhindern><en> It also allows you to cover your mouth to avoid breathing cold air that can inflame your lungs.
<G-vec00174-002-s347><avoid.verhindern><de> Sie können mit diesem auch Ihren Mund bedecken, um ein Einatmen von kalter Luft und so eine Lungenentzündung zu verhindern.
<G-vec00174-002-s348><avoid.verhindern><en> 4 illustrates a state machine, according to one embodiment, that may be used to avoid unwanted PFRQ entry lock conditions due to a missed fusible instruction in the IQ.
<G-vec00174-002-s348><avoid.verhindern><de> 4 zeigt eine Zustandsmaschine gemäß einer Ausführungsform, die verwendet werden kann, um unerwünschte PFRQ-Eintragssperrbedingungen aufgrund eines verfehlten fusionierbaren Befehls in der IQ zu verhindern.
<G-vec00174-002-s349><avoid.verhindern><en> Upon request by the Commission, the Member State shall demonstrate its precautionary measures taken to avoid an excessive consumption of days within the area due to a vessel terminating presences in the area that do not coincide with the end of a 24-hour period.
<G-vec00174-002-s349><avoid.verhindern><de> Der Mitgliedstaat weist der Kommission auf Verlangen nach, welche Vorsorgemaßnahmen er getroffen hat, um eine übermäßige AufwandInanspruchnahme im Gebiet aufgrund eines Schiffs zu verhindern, das seinen Aufenthalt im Gebiet vor Ablauf eines 24-Stunden-Zeitraums beendet.
<G-vec00174-002-s350><avoid.verhindern><en> To avoid this, edit the rule set and "Purge" it before splitting.
<G-vec00174-002-s350><avoid.verhindern><de> Um dies zu verhindern, bearbeiten Sie den Regel-Satz und klicken Sie vor dem Aufteilen auf "Ausräumen".
<G-vec00174-002-s351><avoid.verhindern><en> The touchpad can be disabled to avoid unintentional hitting during gaming.
<G-vec00174-002-s351><avoid.verhindern><de> Um Fehleingaben in Spielen zu verhindern, kann das Touchpad bei Bedarf deaktiviert werden.
<G-vec00174-002-s352><avoid.verhindern><en> This is to avoid damage to the tail servo and to the mechanics during the setup process.
<G-vec00174-002-s352><avoid.verhindern><de> Achtung Trennen Sie alle Servos von der VStabi und hängen Sie auch die Gestänge aus, um Beschädigungen an den Servos und der Mechanik während des Setups zu verhindern.
<G-vec00174-002-s353><avoid.verhindern><en> The applicator may be provided with an air-tight cap to avoid drying out between uses.
<G-vec00174-002-s353><avoid.verhindern><de> Das Auftragsteil kann mit einer luftdicht abschließenden Kappe versehen sein, um ein Austrocknen zwischen den Verwendungen zu verhindern.
<G-vec00174-002-s354><avoid.verhindern><en> When you arrive you will get a sympathy gadget, above all we try to give you the right mobilhome also for the needs of your dog: an example with shadow, with trees nearby and maybe a little separate to avoid the continuous passage of strangers disturbs him excessively.
<G-vec00174-002-s354><avoid.verhindern><de> Bei der Ankunft geben wir dir ein sympathisches Gadget und außerdem suchen wir das passende Moblheim, was auch angemessen für den Hund ist: zum Beispiel im Schatten, mit Bäumen in der Nähe und vielleicht auch ein etwas abgelegener, um zu verhindern daß ständig Fremde vorbeilaufen, die ihn extrem stören.
<G-vec00174-002-s355><avoid.verhindern><en> Consequently, the scientists can monitor these populations in order to ensure that declining populations can be restored and to avoid new declines as well as raising the alarm before it is too late.
<G-vec00174-002-s355><avoid.verhindern><de> Außerdem können die Wissenschaftler so die Bestände überwachen, rückläufige Populationen wieder aufstocken und, um weitere Rückgänge zu verhindern, rechtzeitig Alarm schlagen.
<G-vec00174-002-s356><avoid.verhindern><en> Traffic limitTo avoid denial-of-service (DoS) and brute-force attacks on the Public Spot you can restrict the permissible data transfer for non-authenticated Public Spot participants to a harmless volume.
<G-vec00174-002-s356><avoid.verhindern><de> Traffic-Limit Um Denial-of-Service- (DoS-) und Brute-Force-Angriffe auf den Public Spot zu verhindern, können Sie den zulässige Datentransfer noch nicht authentisierter Public Spot-Teilnehmer auf ein ungefährliches Volumen begrenzen.
<G-vec00174-002-s357><avoid.verhindern><en> Several options are available to avoid this from happening, the report continues.
<G-vec00174-002-s357><avoid.verhindern><de> Um dies zu verhindern, gibt es mehrere Optionen, so der Bericht weiter.
<G-vec00174-002-s358><avoid.verhindern><en> Include your brand name in your store code to avoid confusion between spreadsheets (for separate business or personal accounts).
<G-vec00174-002-s358><avoid.verhindern><de> Ihr Geschäftscode muss den Namen Ihres Unternehmens enthalten, um im Falle mehrerer Tabellen Verwechslungen zwischen einzelnen Geschäfts- oder persönlichen Konten zu verhindern.
<G-vec00174-002-s359><avoid.verhindern><en> In addition, any toys that sick children have been playing with should be thoroughly cleaned to avoid passing the illness onto other kids in the family.
<G-vec00174-002-s359><avoid.verhindern><de> Spielzeuge, mit denen kranke Kinder gespielt haben, sollten gründlich gereinigt werden, um zu verhindern, dass die Krankheit weiter verbreitet wird.
<G-vec00174-002-s360><avoid.verhindern><en> Regular exercising is important to avoid a repetition of these blockages.
<G-vec00174-002-s360><avoid.verhindern><de> Um ein Wiederauftauchen von Blockaden zu verhindern, ist regelmäßige sportliche Betätigung wichtig.
<G-vec00174-002-s418><avoid.verhindern><en> As an alternative to a browser add-on, especially for browsers on mobile devices, you can also avoid the information collection by Google Analytics by clicking on this link.
<G-vec00174-002-s418><avoid.verhindern><de> Alternativ zum Browser-Add-On, insbesondere bei Browsern auf mobilen Endgeräten, können Sie die Erfassung durch Google Analytics zudem verhindern, indem Sie auf diesen Link klicken.
<G-vec00174-002-s419><avoid.verhindern><en> Making regular backups of your files can help you avoid data loss if your PC gets infected again.
<G-vec00174-002-s419><avoid.verhindern><de> Wenn Sie regelmäßig Sicherungen Ihrer Dateien erstellen, können Sie Datenverluste verhindern, wenn der PC erneut infiziert wird.
<G-vec00174-002-s420><avoid.verhindern><en> In case of direct or indirect references to outside websites, lying outside the sphere of responsibility of the B. Strautmann & Söhne GmbH u. Co. KG, an obligation to liability would solely become effective in case that the author has knowledge of the contents and if it would technically be possible for him and can reasonably be expected from him, to avoid the use in case of illegal contents.
<G-vec00174-002-s420><avoid.verhindern><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die au√üerhalb des Verantwortungsbereiches des von B. Strautmann & Söhne GmbH u. Co. KG liegen, w√ľrde eine Haftungsverpflichtung ausschlie√ülich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00174-002-s421><avoid.verhindern><en> They are geared to help maintenance personnel learn how to avoid costly downtime while improving the efficiency of critical rotating equipment.
<G-vec00174-002-s421><avoid.verhindern><de> Diese lernen kostspielige Ausfallzeiten zu verhindern und die Effizienz kritischer rotierender Teile zu verbessern.
<G-vec00174-002-s422><avoid.verhindern><en> To avoid that Peggy makes a mistake because her jealousy, all the students arrive by "coincidence" to the beautiful house that Xavier's parents have in Chapala.
<G-vec00174-002-s422><avoid.verhindern><de> Um zu verhindern, dass Peggy aus Eifersucht einen Fehler begeht, kommen alle jungen Hauptakteure "zufällig" zu dem schönen Haus der Eltern von Xavier in Chapala.
<G-vec00174-002-s423><avoid.verhindern><en> We want to avoid re-creating the flawed dichotomy of a “city” and “a place for rest”.
<G-vec00174-002-s423><avoid.verhindern><de> We wollen verhindern den Strom zwischen Innenstadt und einem Ort der Ruhe wieder entstehen zu lassen.
<G-vec00174-002-s424><avoid.verhindern><en> Its contribution is decisive in making the «Conditions of Admission» to the International more severe, in order to avoid that it be joined by groups and parties which, propelled by a wave of still vigorous struggles, might claim to accept its revolutionary discipline and program, but then, in their everyday activity, sabotage them (especially if the international revolutionary wave should ebb).
<G-vec00174-002-s424><avoid.verhindern><de> Ihr Beitrag ist entscheidend dafür, die »Beitrittsbedingungen« zur Internationale selbst strenger zu gestalten, um zu verhindern, dass Gruppen und Parteien dem Wort nach und aufgrund der Welle der noch entschlossenen Kämpfe der Internationale beitreten, ihr revolutionäres Programm und die Disziplin so anerkennen, aber dann die Umsetzung und Anwendung verhindern (vor allem, wenn sich die revolutionäre Welle abkühlt).
<G-vec00174-002-s425><avoid.verhindern><en> We hope to avoid a new break of the wireline by running it a little bit slower.
<G-vec00174-002-s425><avoid.verhindern><de> Wir hoffen ein neues Brechen des Bohrkabels durch langsameres Bohren verhindern zu können.
<G-vec00174-002-s426><avoid.verhindern><en> I tried for years to avoid epidermal thickening, that protective callous which suffocates the soul and induces paranoia in the oversensitive artiste.
<G-vec00174-002-s426><avoid.verhindern><de> Ich habe jahrelang versucht, das dicker werden der Epidermis zu verhindern, die beschuetzende Hornhaut, die die Seele erstickt und im uebersensiblen Kuenstler Paranoia erzeugt.
<G-vec00174-002-s427><avoid.verhindern><en> [QUICK SET UP]- The shock-corded chair frames and chair legs design enable quick and easy set up, and the elastic ropes in the shock-corded chair frames and chair legs keep all parts connected and avoid losing parts.
<G-vec00174-002-s427><avoid.verhindern><de> [SCHNELLEINRICHTUNG] - Das Design der stoßgesicherten Stuhlrahmen und Stuhlbeine ermöglicht eine schnelle und einfache Einrichtung, und die elastischen Seile in den stoßgesicherten Stuhlrahmen und Stuhlbeinen halten alle Teile in Verbindung und verhindern den Verlust von Teilen.
<G-vec00174-002-s428><avoid.verhindern><en> Safety at sea In the ocean or on the waterway, a navigating system is a most important precaution to avoid accidents.
<G-vec00174-002-s428><avoid.verhindern><de> Navigation ist die wichtigste Voraussetzung, Unfälle und Havarien auf allen Wasserstraßen und Weltmeeren zu verhindern.
<G-vec00174-002-s429><avoid.verhindern><en> In particular, the achievement of this objective requires that there be substantial and progressive reduction in the support and protection of agriculture - covering internal regimes, market access and export subsidies - as well as of industry and other sectors, in order to avoid inflicting large losses on the more efficient producers, especially in developing countries.
<G-vec00174-002-s429><avoid.verhindern><de> Um dies erreichen zu können, bedarf es vor allem eines massiven und kontinuierlich fortschreitenden Abbaus der Subventionen und Hilfen für die Landwirtschaft - wozu binnenwirtschaftliche Maßnahmen des Marktzugangs und Exportsubventionen gehören -wie auch in der Industrie und in anderen Sektoren, um das Entstehen größerer Verluste bei den leistungsfähigeren Erzeugern, insbesondere in den Entwicklungsländern, zu verhindern.
<G-vec00174-002-s430><avoid.verhindern><en> The Provider has adopted all the technical and organizational measures and all the levels of protection necessary to guarantee the security in the treatment of the data and to avoid its alteration, loss, theft, treatment, or unauthorized access, according to the state of technology and nature of the stored data.
<G-vec00174-002-s430><avoid.verhindern><de> Der Anbieter hat alle technischen und organisatorischen Maßnahmen und alle erforderlichen Schutzmaßnahmen getroffen, um die Sicherheit bei der Behandlung der Daten zu gewährleisten und deren Veränderung, Verlust, Diebstahl, Behandlung oder unberechtigten Zugriff nach dem Stand der Technik und der Art der gespeicherten Daten zu verhindern.
<G-vec00174-002-s431><avoid.verhindern><en> And if one wants to choose one of them, in order to avoid the worse, one will get both.
<G-vec00174-002-s431><avoid.verhindern><de> Und wer sich für eines der beiden entscheidet, um das Schlimmere zu verhindern, der wird beides bekommen.
<G-vec00174-002-s432><avoid.verhindern><en> At speeds over 25kph, the engine completely ceases its support in order to avoid any friction that might impair power transfer.
<G-vec00174-002-s432><avoid.verhindern><de> Bei Geschwindigkeiten über 25 km/h unterstützt der Motor nicht mehr, um Reibung zu verhindern, welche die Kraftübertragung beeinträchtigen könnte.
<G-vec00174-002-s433><avoid.verhindern><en> For direct or indirect links to external web pages ("hyperlinks") that are not within the author’s sphere of responsibility, liability only becomes effective if the author is aware of the content and will technically and reasonably be able to avoid the use of possibly illegal content.
<G-vec00174-002-s433><avoid.verhindern><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten (“Links”), die außerhalb des Verantwortungsbereichs des Autors liegen, haftet dieser nur, wenn er von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar ist, die Nutzung im Fall rechtswidriger Inhalte zu verhindern.
<G-vec00174-002-s434><avoid.verhindern><en> If you click on the following deactivation link you can avoid that Google collects more visits to this website.
<G-vec00174-002-s434><avoid.verhindern><de> Wenn Sie auf folgenden Deaktivierungslink klicken, können Sie verhindern, dass Google weitere Besuche auf dieser Webseite erfasst.
<G-vec00174-002-s435><avoid.verhindern><en> The EU has also adopted common principles for business taxation to avoid that national tax regimes have harmful effects in other countries.
<G-vec00174-002-s435><avoid.verhindern><de> Die EU hat außerdem gemeinsame Grundsätze der Unternehmensbesteuerung verabschiedet, um zu verhindern, dass sich nationale Steuerregelungen negativ auf andere Länder auswirken.
<G-vec00174-002-s436><avoid.verhindern><en> What’s interesting is that currency decline was what Richard Nixon sought to avoid when he ended the gold standard in 1971 and announced that the country would no longer redeem its currency in gold.
<G-vec00174-002-s436><avoid.verhindern><de> Interessant ist in diesem Zusammenhang, dass ein Rückgang des Werts der Währung ja eigentlich genau das war, was der damalige US-Präsident Richard Nixon verhindern wollte, als er den Goldstandard 1971 für beendet erklärte und bekanntgab, dass die USA ihre Währung nicht mehr länger gegen Gold eintauschen würden.
<G-vec00174-002-s437><avoid.verhindern><en> Doubting will avoid an imagination become reality.
<G-vec00174-002-s437><avoid.verhindern><de> Zweifel verhindern, dass Ihre Imagination Realität wird.
<G-vec00174-002-s438><avoid.verhindern><en> Prevention The Fire Brigade is not only active in matters such as flood defences, it is also involved in other preventative measures to avoid dangers from arising.
<G-vec00174-002-s438><avoid.verhindern><de> Die Feuerwehr wird nicht nur aktiv bei abwehrenden Maßnahmen wie dem Hochwasserschutz, sie ist auch im vorbeugenden Bereich eingebunden und versucht im Vorfeld zu verhindern, dass Gefahren entstehen.
<G-vec00174-002-s439><avoid.verhindern><en> At the end of the war, France is preoccupied by concerns over its security and economic prosperity and wants to avoid any revival of German economic and military might.
<G-vec00174-002-s439><avoid.verhindern><de> Nach Kriegsende sorgt sich Frankreich um seine Sicherheit und seinen wirtschaftlichen Wohlstand und möchte auf jeden Fall verhindern, dass die wirtschaftliche und militärische Macht Deutschlands wiederaufblüht.
<G-vec00174-002-s440><avoid.verhindern><en> Rabbit Bettertainment also advises the player not to leave his computer unattended when logged in, so that he can avoid anyone using his account without his consent.
<G-vec00174-002-s440><avoid.verhindern><de> Rabbit Bettertainment rät dem Spieler weiter, seinen Computer während des Logins nicht unbeaufsichtigt zu lassen, um zu verhindern, dass Dritte das Spielerkonto ohne Zustimmung des Spielers nutzen.
<G-vec00174-002-s441><avoid.verhindern><en> When taking the camera out of the waterproof case, open the waterproof case with the lens facing downwards to avoid the camera falling out.
<G-vec00174-002-s441><avoid.verhindern><de> Wenn Sie die Kamera aus dem Unterwassergehäuse herausnehmen, öffnen Sie das Unterwassergehäuse so, dass das Objektiv nach unten zeigt, um zu verhindern, dass die Kamera herausfällt.
<G-vec00174-002-s442><avoid.verhindern><en> To avoid entities structuring their liabilities in a manner that impedes the effectiveness of the bail-in tool, it is appropriate to establish that the entities should meet at all times a minimum requirement for own funds and eligible liabilities which may be subject to the bail-in tool, expressed as a percentage of the total liabilities and own funds of the entity.
<G-vec00174-002-s442><avoid.verhindern><de> Um zu verhindern, dass Unternehmen ihre Verbindlichkeiten auf eine Art und Weise strukturieren, die die Wirksamkeit des Bail-in-Instruments einschränkt, ist es zweckmäßig festzulegen, dass die Unternehmen jederzeit eine als Prozentsatz der Gesamtverbindlichkeiten und der Eigenmittel des Unternehmens ausgedrückte Mindestanforderung an Eigenmittel und berücksichtigungsfähige Verbindlichkeiten, die dem Bail-in-Instrument unterliegen können, erfüllen müssen.
<G-vec00174-002-s443><avoid.verhindern><en> 3 HDMI source devices to be connected and manually selected to play, to avoid constantly plugging and unplugging.,PLUG AND PLAY | No extra power required.
<G-vec00174-002-s443><avoid.verhindern><de> 3 HDMI-Quellgeräte, die angeschlossen und manuell ausgewählt werden sollen, um zu spielen, um zu verhindern, dass das Gerät immer wieder verstopft und herausgezogen wird.,(PLUG UND PLAY)Keine zusätzliche Leistung erforderlich.
<G-vec00174-002-s444><avoid.verhindern><en> The assembly of the PVB and the glass takes place in a closed atmosphere to avoid dust particles between the layers.
<G-vec00174-002-s444><avoid.verhindern><de> Die Verbindung von PVB und Glas erfolgt unter Vakuum, um zu verhindern, dass Staub zwischen die einzelnen Teile gelangt.
<G-vec00174-002-s445><avoid.verhindern><en> KNITTING TIP: To avoid the knitting tension becoming tighter when you work pattern, it is important that the strands at the back of the piece are not tight.
<G-vec00174-002-s445><avoid.verhindern><de> STRICKTIPP: Um zu verhindern, dass das Gestrick zu fest wird, wenn im Muster gestrickt wird, ist es wichtig, dass die Fäden auf der Rückseite nicht zu fest mitgeführt werden.
<G-vec00174-002-s446><avoid.verhindern><en> This system has been conceived, according to Goldstein, to avoid the consumer from being vulnerable and defenseless and to avoid the prices of wine from not reflecting the reality of the market.
<G-vec00174-002-s446><avoid.verhindern><de> Um zu verhindern, dass der Verbraucher desorientiert ist und die Weinpreise nicht die Realität des Marktes widerspiegeln, sei diese Methode konzipiert worden, so Goldstein.
<G-vec00174-002-s447><avoid.verhindern><en> The auto foil detecting and foil bottle rejecting device will give an auto warning and remove the cap once it is detected without foil, to avoid non-sealed foil products outflow the production line.
<G-vec00174-002-s447><avoid.verhindern><de> Die automatische Folienerkennung und die Vorrichtung zum Zurückweisen von Folienflaschen geben eine automatische Warnung aus und entfernen die Kappe, sobald sie ohne Folie erkannt wird, um zu verhindern, dass nicht versiegelte Folienprodukte aus der Produktionslinie fließen.
<G-vec00174-002-s448><avoid.verhindern><en> Relations with the European community remained a dominant aspect particularly in economic questions, with Bern aiming to avoid «a situation in which the way the community’s legislation develops appears as an inevitable element of our policies» (Doc.
<G-vec00174-002-s448><avoid.verhindern><de> Die Beziehungen zur Europäischen Gemeinschaft blieben vor allem in Wirtschaftsfragen dominant, wo Bern verhindern wollte, «dass wir in Situationen geraten, wo die Entwicklung der Gesetzgebung der Gemeinschaft als zwingendes Element unserer Politik erscheint» (Dok.
<G-vec00174-002-s449><avoid.verhindern><en> The purpose of these cookies is to provide you with a more personal experience and to avoid you having to re-enter your preferences every time you visit our Site.
<G-vec00174-002-s449><avoid.verhindern><de> Diese Cookies haben den Zweck, Ihnen ein persönlicheres Erlebnis zu bieten und zu verhindern, dass Sie Ihre Präferenzen bei jedem Besuch unserer Seite neu eingeben müssen.
<G-vec00174-002-s450><avoid.verhindern><en> To avoid objects in VeroClear resin (translucent Polyjet resin) to become dirtied, you can often clean them with soapy water and a cloth, letting it dry thoroughly.
<G-vec00174-002-s450><avoid.verhindern><de> Um zu verhindern, dass Gegenstände aus VeroClear-Harz (transluzentes Polyjetharz) verschmutzt werden, können Sie diese öfters mit Seifenwasser und einem Tuch reinigen und sorgfältig trocknen lassen.
<G-vec00174-002-s451><avoid.verhindern><en> avoid re-enter the same information several times during the visit such as user name and password
<G-vec00174-002-s451><avoid.verhindern><de> - Sie verhindern, dass die gleichen Informationen während des Besuchs mehrmals eingegeben werden müssen, wie zum Beispiel Benutzername und Passwort.
<G-vec00174-002-s452><avoid.verhindern><en> Determined to avoid the worst-case scenario of locals being forced to sell their livestock or migrate from the Valley, the PPAF developed a “water balance model” to manage and conserve remaining resources and address the impacts of climate change, according to Sabri.
<G-vec00174-002-s452><avoid.verhindern><de> Um das Schlimmste zu verhindern – dass die lokale Bevölkerung ihr Vieh verliert oder aus dem Tal abwandert, entwickelte der Fonds ein Konzept zur nachhaltigen Nutzung der verbliebenen Wasserressourcen und zur Anpassung an die Folgen des Klimawandels.
<G-vec00174-002-s453><avoid.verhindern><en> Offer definitive advice on how people can avoid experiencing the same sad story.
<G-vec00174-002-s453><avoid.verhindern><de> Biete konkrete Hinweise, wie Andere verhindern können, dass ihnen dieselbe traurige Geschichte widerfährt.
<G-vec00174-002-s454><avoid.verhindern><en> It’s usual to find collections of vintage costume jewellery at auction, but as with a lot of our advice, we suggest that you do your homework to avoid getting stung.
<G-vec00174-002-s454><avoid.verhindern><de> Es ist durchaus üblich, Sammlungen von antikem Modeschmuck auf Auktionen zu finden, aber auch hier ist es unabdingbar, dass Sie Ihre Hausaufgaben vorher machen, um zu verhindern, dass Sie verlieren.
<G-vec00174-002-s455><avoid.verhindern><en> We want to intervene where it is important to support the communist tendencies within the struggles and to avoid the traps set by capitalist promises and illusions.
<G-vec00174-002-s455><avoid.verhindern><de> Wir wollen eingreifen, wo es gilt, die kommunistischen Tendenzen in den Kämpfen zu unterstützen, und verhindern, dass diese an den Fallstricken der kapitalistischen Versprechen und Illusionen hängen bleiben.
<G-vec00174-002-s456><avoid.verhindern><en> The vent system is thus placed that the part with high HCl concentration is kept under negative pressure in order to avoid leakages of HCl gases or oxide dust from the plant into the environment.
<G-vec00174-002-s456><avoid.verhindern><de> Der Ventilator ist so platziert, dass das System mit hoher HCl Konzentration im negativen Druckzustand gehalten wird und ein Austreten von HCl-Gas oder Oxidstaub in die Umwelt verhindert wird.
<G-vec00174-002-s457><avoid.verhindern><en> Aside from the well-established methods, the team uses the ‘single embryo transfer’ procedure to avoid risky multiple pregnancies.
<G-vec00174-002-s457><avoid.verhindern><de> Neben den fest etablierten Methoden nutzt das Team das ‚Single Embryo Transfer‘-Verfahren, das risikoreiche Mehrlingsschwangerschaften verhindert.
<G-vec00174-002-s458><avoid.verhindern><en> Herewith we avoid that the label stick on the product.
<G-vec00174-002-s458><avoid.verhindern><de> Somit wird verhindert, dass das Etikett nicht am Produkt haftet.
<G-vec00174-002-s459><avoid.verhindern><en> With the function default you can save time and avoid errors.
<G-vec00174-002-s459><avoid.verhindern><de> Die Funktion „Voreinstellung“ spart Zeit und verhindert Eingabefehler.
<G-vec00174-002-s460><avoid.verhindern><en> Helps protect the natural moisture of your skin, avoid uncomfortable tightness and promote youthful looking skin
<G-vec00174-002-s460><avoid.verhindern><de> Bewahrt die natürliche Feuchtigkeit deiner Haut, verhindert unangenehme Spannungsgefühle und fördert ein jugendlich wirkendes Hautbild.
<G-vec00174-002-s461><avoid.verhindern><en> In general we recommend not exceeding more than five percent of the speed marking the speedometer of your car; thus you´ll avoid being caught by radar.
<G-vec00174-002-s461><avoid.verhindern><de> Generell empfehlen wir Euch, nicht mehr als 5 % der Geschwindigkeit auf dem Tacho zu überschreiten; so verhindert Ihr von einem Radar registriert zu werden.
<G-vec00174-002-s462><avoid.verhindern><en> The method of claim 13 further comprising controlling an amount of water present in the reaction zone to maintain a desired reaction conversion and avoid deactivating the catalyst.
<G-vec00174-002-s462><avoid.verhindern><de> Verfahren nach Anspruch 13, das ferner das Regulieren einer Menge an Wasser umfasst, das in der Reaktionszone zugegen ist, so dass eine gewünschte Reaktionsumwandlung aufrechterhalten und eine Deaktivierung des Katalysators verhindert wird.
<G-vec00174-002-s463><avoid.verhindern><en> Underlay is installed in a way that the angle between the joints of flooring and the joints of boards would be 45˚, this helps to avoid the joints of the boards and flooring to overlap (Figure 2 and 3).
<G-vec00174-002-s463><avoid.verhindern><de> Die Unterlage wird so montiert, dass der Winkel zwischen den Verbindungen des Bodenbelags und der Platten 45˚ beträgt, dies verhindert die Überlappung der Verbindungen von Platten und Bodenbelag (Abbildung 2 und 3).
<G-vec00174-002-s464><avoid.verhindern><en> Guidelines include: „The input of Open Source software reduces one-sided dependence on suppliers, supply chains, customers and employees and therefore avoid bad investments.“ “Open Source promotes innovation, lowers...
<G-vec00174-002-s464><avoid.verhindern><de> Leitlinien sind unter anderem: „Der Einsatz von Open Source Software reduziert einseitige Abhängigkeiten von Lieferanten, Lieferketten, Kunden und Mitarbeitern und verhindert so Fehlinvestitionen.“ „Open Source fördert...
<G-vec00174-002-s465><avoid.verhindern><en> Sun protection – Awnings support to fend off UV rays and avoid the heating-up of the terrace or the balcony.
<G-vec00174-002-s465><avoid.verhindern><de> Sonnenschutz – Eine Markise hilft Sonnenstrahlen abzufangen und verhindert das Aufheizen der Terrasse oder des Balkons.
<G-vec00174-002-s466><avoid.verhindern><en> The general public is also interested in knowing whether the time provision project can actually delay or avoid moving into residential institutions.
<G-vec00174-002-s466><avoid.verhindern><de> Die Öffentlichkeit interessiert sich auch dafür, ob durch das Projekt Zeitvorsorge tatsächlich Übertritte in stationäre Einrichtungen verhindert oder verzögert werden können.
<G-vec00174-002-s467><avoid.verhindern><en> They’ve been developed with a waistband that smoothly holds the shorts in place, a cut that’s trim around the crotch to avoid saddle snag, a length that’s ideal with or without pads, and a versatile new fabric that flexes with each pedal stroke.
<G-vec00174-002-s467><avoid.verhindern><de> Sie bieten einen Taillenbund, der die Shorts auf angenehme Weise an der richtigen Stelle hält, einen raffinierten Schnitt, der verhindert, dass die Shorts am Sattel hängen bleiben, eine Länge, die mit oder ohne Polster perfekt passt und ein vielseitiges neues Gewebe, das sich jeder Bewegung anpasst.
<G-vec00174-002-s468><avoid.verhindern><en> Avoid excess perspiration and control excess humidity and avoid bad odours so you can follow your rhythm without worries.
<G-vec00174-002-s468><avoid.verhindern><de> Beugt übermäßiger Schweißbildung vor, kontrolliert Feuchtigkeitsansammlungen und verhindert Geruchsentwicklung, damit Sie unbekümmert Ihren Rhythmus beibehalten können.
<G-vec00174-002-s469><avoid.verhindern><en> The DIGITTRADE HIGH SECURITY HDD functions with a two-factor authentication process to avoid unauthorized access to the HDD and data stored on it.
<G-vec00174-002-s469><avoid.verhindern><de> D e u t Die DIGITTRADE HIGH SECURITY FESTPLATTE verfügt über einen s c h 2-stufigen Authentifizierungsvorgang, der unbefugten Zugriff auf die Festplatte und Daten verhindert.
<G-vec00174-002-s470><avoid.verhindern><en> Keylock system to avoid any accidental snagging of the carabiner.
<G-vec00174-002-s470><avoid.verhindern><de> Das Keylock-System verhindert ein Hängenbleiben des Karabiners.
<G-vec00174-002-s471><avoid.verhindern><en> In other words, don't expect Subversion to avoid committing changes you've made to a versioned file simply because that file's name matches an ignore pattern—Subversion always notices all of its versioned objects.
<G-vec00174-002-s471><avoid.verhindern><de> Mit anderen Worten: erwarten Sie nicht, dass Subversion die Übertragung von Änderungen verhindert, die Sie an einer versionierten Datei vorgenommen haben, nur weil der Name dieser Datei auf ein Ignorier-Muster passt – Subversion beachtet stets alle seine versionierten Objekte.
<G-vec00174-002-s472><avoid.verhindern><en> The rain wash coating helps reduce maintenance costs and helps avoid the effect of the drops and dust.
<G-vec00174-002-s472><avoid.verhindern><de> Die Rain-Wash-Beschichtung sorgt für klare Sicht bei jedem Wetter, reduziert Wartungskosten und verhindert Sichtbeeinträchtigung durch Tropfen und Staub.
<G-vec00174-002-s473><avoid.verhindern><en> Stores the number of times a user has seen a splash page, or if the user has chosen to no longer see the message to avoid showing the user the message more than the designated number of times 24 Month Geo
<G-vec00174-002-s473><avoid.verhindern><de> speichert die Zahl, wie oft einem Nutzer eine Intro-Seite (splash page) angezeigt worden ist, oder verhindert, dass dem Nutzer die Nachricht öfter als gewünscht angezeigt wird, sofern er bestimmt hat, dass ihm die Nachricht nicht mehr angezeigt werden soll.
<G-vec00174-002-s474><avoid.verhindern><en> Chopping the crop will avoid the build up of material and prevent blockages on the moving parts of diet feeders, forage boxes and straw choppers etc.
<G-vec00174-002-s474><avoid.verhindern><de> Geschnittenes Material verhindert das Aufstauen und Blockieren an den beweglichen Teilen von Fütterungsanlagen, Futterboxen und Strohhäckslern etc.
<G-vec00174-002-s760><avoid.verhindern><en> In these 120 days, FUNAI is also obligated to work to conclude the regularization of the area to avoid, in the definitive, the removal of the indigenous people from the land.
<G-vec00174-002-s760><avoid.verhindern><de> Innerhalb dieser Frist muss die FUNAI auch die Regulierung des Gebietes abschließen, um den endgültigen Abzug der Indios aus diesem Territorium zu verhindern.
<G-vec00174-002-s761><avoid.verhindern><en> On the other hand, Washington avoid declaring its open support to the YPG in the region in order to avoid further diplomatic escalation with Turkey.
<G-vec00174-002-s761><avoid.verhindern><de> Andererseits vermeidet Washington seine Unterstützung der YPG in der Region offiziell zuzugeben, um eine weitere diplomatische Eskalation mit der Türkei zu verhindern.
<G-vec00174-002-s762><avoid.verhindern><en> Stupidly, with the driver absent, the train started in motion and travelled at a good 120 km per hour through the countryside, until, in order to avoid worse, it was deliberately derailed about 120 km before reaching Port Hedland.
<G-vec00174-002-s762><avoid.verhindern><de> Dummerweise setze sich dabei der Zug dann jedoch ohne Zugführer wieder in Bewegung und fuhr mit gut 120 km/h durch die Landschaft, bis der Zug, um Schlimmeres zu verhindern, von einem Steuerzentrum 120 km vor Port Hedland zum planmäßigen Entgleisen gebracht wurde.
<G-vec00174-002-s763><avoid.verhindern><en> Please ensure that you correctly sign-out of PlayStation Network on your friend’s PlayStation 4 system to avoid any unauthorised access to your PlayStation Network account.
<G-vec00174-002-s763><avoid.verhindern><de> Bitte stelle sicher, dass du dich auf dem PlayStation 4-System deines Freundes vom PlayStation Network korrekt abmeldest, um nicht autorisierte Zugriffe auf dein Konto zu verhindern.
<G-vec00174-002-s764><avoid.verhindern><en> If the driver does not react, the system automatically brakes to avoid or reduce impact.
<G-vec00174-002-s764><avoid.verhindern><de> Reagiert der Fahrer nicht, bremst das System um den Aufprall zu verhindern oder dessen Folgen zu mildern.
<G-vec00174-002-s765><avoid.verhindern><en> A combination of good cybersecurity practices and the best antivirus software is the only way to stay safe online and avoid becoming a victim of hackers.
<G-vec00174-002-s765><avoid.verhindern><de> Nur eine Kombination aus guten Angewohnheiten im Cyberspace und der besten Antivirensoftware ist der einzige Weg, um online sicher zu bleiben und zu verhindern, dass Sie ein Opfer von Hackern werden.
<G-vec00174-002-s766><avoid.verhindern><en> To avoid this, make sure to round all co-ordinates used in calls to drawImage using Math.floor or as you’ll reader further in the article, bitwse operators.
<G-vec00174-002-s766><avoid.verhindern><de> Um dies zu verhindern, stellen Sie sicher, dass Sie alle Koordinaten in Aufrufen von drawImage() runden, zum Beispiel mit Hilfe von Math.floor().
<G-vec00174-002-s767><avoid.verhindern><en> To avoid that, uncheck "Enable encryption..." for each folder you don't want to share encrypted in the "Updates Options" dialog box available from the management panel.
<G-vec00174-002-s767><avoid.verhindern><de> Um diese zu verhindern, demarkieren Sie das Kontrollkästchen "Verschlüsselung aktivieren..." im Dialog "Aktualisierungs-Optionen" der über das Management-Dialogfeld aufgerufen werden kann, für jeden Ordner, den Sie nicht verschlüsselt freigeben möchten.
<G-vec00174-002-s768><avoid.verhindern><en> Please throw toilet paper in the waste basket to avoid blocking the toilet.
<G-vec00174-002-s768><avoid.verhindern><de> Das Toilettenpapier bitte in das entsprechende Körbchen werfen, um die Verstopfung der Toilette zu verhindern.
<G-vec00174-002-s769><avoid.verhindern><en> a client of CMC is likely to make financial gain or avoid a financial loss at the expense of another client.
<G-vec00174-002-s769><avoid.verhindern><de> Ein Kunde von CMC zu Lasten eines anderen Kunden einen finanziellen Gewinn erlangen oder einen finanziellen Schaden zu verhindern vermag.
<G-vec00174-002-s770><avoid.verhindern><en> 26 About the Printer 69 mm /2.7 inches 225 mm/ 8.9 inches 100 mm/3.9 inches 394 mm/15.5 inches 307 mm/12.1 inches 295.5 mm/ 11.6 inches 300 mm/11.8 inches 329.5 mm/13 inches To avoid irregular screen image or malfunctioning of your printer, avoid placing the printer in direct sunlight with the front cover opened.
<G-vec00174-002-s770><avoid.verhindern><de> 26 Informationen zum Drucker 69 mm /2.7 Zoll 225 mm/ 8.9 Zoll 100 mm/3.9 Zoll 394 mm/15.5 Zoll 307 mm/12.1 Zoll 295.5 mm/ 11.6 Zoll 300 mm/11.8 Zoll 329.5 mm/13 Zoll Um ein unregelmäßiges Bildschirmbild oder eine Fehlfunktion des Druckers zu verhindern, setzen Sie ihn bei geöffneter vorderer Abdeckung keiner direkten Sonneneinstrahlung aus.
<G-vec00174-002-s771><avoid.verhindern><en> You can also perform checksums of all the files, download massive image batches and even configure the parental control to avoid access to inappropriate contents.
<G-vec00174-002-s771><avoid.verhindern><de> Es erlaubt auch Prüfsummen aller Dateien auszuführen, massiven Bildserien herunterzuladen und sogar eine elterliche Kontrolle zu konfigurieren, um den Zugriff auf ungeeignete Inhalte zu verhindern.
<G-vec00174-002-s772><avoid.verhindern><en> warning: Disconnect the power cord before reaching inside the printer to avoid risk of injuries or electric shock.
<G-vec00174-002-s772><avoid.verhindern><de> Warnung: Sie müssen das Netzkabel trennen, bevor Sie in den Drucker fassen, um Verletzungen oder einen elektrischen Schlag zu verhindern.
<G-vec00174-002-s773><avoid.verhindern><en> Just before to buy Anavar steroids in Dortmund Germany, make certain you understand every little thing concerning its unfavorable effects, and means to avoid them.
<G-vec00174-002-s773><avoid.verhindern><de> Vor dem Anavar Steroiden in Dortmund Deutschland zu kaufen, stellen Sie sicher, du weißt alles über die negativen Auswirkungen und Möglichkeiten, sie zu verhindern.
<G-vec00174-002-s774><avoid.verhindern><en> Functions like data encryption or “Write-Once” features are easily implemented to avoid fraud and adhere with governmental requirements.
<G-vec00174-002-s774><avoid.verhindern><de> Funktionen wie Deatenverschlüsselung oder eimaliges Schreiben können einfach implementiert werden, um Betrug zu verhindern und gesetzliche Anforderungen einzuhalten.
<G-vec00174-002-s775><avoid.verhindern><en> As a result, an earlier intervention can be realized to suppress progression of the arrhythmia and avoid associated complications like stroke and heart failure.
<G-vec00174-002-s775><avoid.verhindern><de> Dadurch wird es möglich, früher zu intervenieren, die Arrhythmie zu unterbinden und darüber hinausgehende Komplikationen wie Schlaganfall und das Fortschreiten der Herzinsuffizienz zu verhindern.
<G-vec00174-002-s776><avoid.verhindern><en> To avoid an increase in the quantities used for these purposes, producers and importers should not be allowed to significantly increase the quantities placed on the market.
<G-vec00174-002-s776><avoid.verhindern><de> Um eine Zunahme der zu diesen Zwecken verwendeten Mengen zu verhindern, sollte es Herstellern und Einführern verboten sein, erheblich größere Mengen als bisher in Verkehr zu bringen.
<G-vec00174-002-s777><avoid.verhindern><en> Similarly, the essential objective of the State is to promote equality and avoid exclusion and discrimination.
<G-vec00174-002-s777><avoid.verhindern><de> Ziel des Staates ist es, die Gleichheit zu fördern und Ausschluss und Diskriminierung zu verhindern.
<G-vec00174-002-s778><avoid.verhindern><en> We reommend you chose a lower setting on your stove when heating the casserole in order to avoid overheating the casserole or burning of the food.
<G-vec00174-002-s778><avoid.verhindern><de> Wir empfehlen Ihnen daher, eine etwas niedrigere Stufe zum Anheizen des Topfes zu verwenden, um eine Überhitzung des Topfes und ein Anbrennen Ihrer Speisen zu verhindern.
