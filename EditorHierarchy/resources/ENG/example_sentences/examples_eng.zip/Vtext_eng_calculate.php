<G-vec00322-002-s038><calculate.ausrechnen><en> Our prices are a guide only and should be used to calculate your rough overall budget; for competitive rates, please contact us directly for a quote
<G-vec00322-002-s038><calculate.ausrechnen><de> Unsere Preise sind alle nur Richtlinien und sollten benutzt werden, um ein ungefähres Budget auszurechnen; für wettbewerbsfähige Raten kontaktieren Sie uns bitte, um ein Preisangebot zu erhalten.
<G-vec00322-002-s039><calculate.ausrechnen><en> A final strategy is to calculate the exact probability of each square taking the entire game into consideration.
<G-vec00322-002-s039><calculate.ausrechnen><de> Als letzte Option verbleibt noch, sich die genaue Wahrscheinlichkeit für jedes Feld auszurechnen, indem man das ganze Spiel miteinbezieht.
<G-vec00322-002-s040><calculate.ausrechnen><en> You can use the nearby bench to calculate the final coordinates.
<G-vec00322-002-s040><calculate.ausrechnen><de> Du kannst die naheliegende Bank nutzen um die Endkoordinaten auszurechnen.
<G-vec00322-002-s041><calculate.ausrechnen><en> Use the table to small drawings or sketches and use the calculator for calculate something.
<G-vec00322-002-s041><calculate.ausrechnen><de> Benutzen Sie die Tafel um kleine Zeichnungen oder Skizzen anzufertigen und den Taschenrechner um etwas auszurechnen.
<G-vec00322-002-s042><calculate.ausrechnen><en> Given the antivirus product X detects 50% of all viruses active in the Internet at a given moment of time, the product Y detects 90%, and the product Z detects 99.9%, it is a trivial problem to calculate the probability of your computer remaining intact after N attacks.
<G-vec00322-002-s042><calculate.ausrechnen><de> Wenn man annimmt, Produkt X entdeckt 50 Prozent aller aktiven Viren im Internet, Produkt Y immerhin schon 90 Prozent und Produkt Z ganze 99,9 Prozent, ist es ein Leichtes, die Wahrscheinlichkeit auszurechnen, wann ein Computer nach N Angriffen nicht mehr intakt sein wird.
<G-vec00322-002-s043><calculate.ausrechnen><en> In order to calculate the mentioned limit you have to take in account the global value of the assets, independently of the degree of participation of each tax payer.
<G-vec00322-002-s043><calculate.ausrechnen><de> Um die erwähnte Grenze auszurechnen muss die globale Bewertung der Güter in Betracht genommen werden, egal welcher der Beteiligungsgrad jeder Person ist.
<G-vec00322-002-s044><calculate.ausrechnen><en> No attempt is made to calculate the day and the hour of the Coming of Jesus Christ, as it is required in the Scripture, but the length of the final crisis is determined here.
<G-vec00322-002-s044><calculate.ausrechnen><de> In der Broschüre wird nicht versucht – wie auch die Schrift es verlangt – den Tag und die Stunde der Wiederkunft Christi auszurechnen, sondern es wird die Dauer der End-Krise festgestellt.
<G-vec00322-002-s045><calculate.ausrechnen><en> A mine is more likely in L than K and more likely in H than D. A final strategy is to calculate the exact probability of each square taking the entire game into consideration.
<G-vec00322-002-s045><calculate.ausrechnen><de> Eine Mine befindet sich eher in L als in K, und eher in H als in D. Als letzte Option verbleibt noch, sich die genaue Wahrscheinlichkeit für jedes Feld auszurechnen, indem man das ganze Spiel miteinbezieht.
<G-vec00322-002-s046><calculate.ausrechnen><en> If you are in need of a currency computer in order to calculate what your order costs in your currency we can recommend the Yahoo currency calculator.
<G-vec00322-002-s046><calculate.ausrechnen><de> Währungsrechner Sollten Sie einen Währungsrechner benötigen, um auszurechnen, was Ihre Bestellung in Ihrer Währung kostet, so können wir Ihnen den Yahoo Währungsrechner empfehlen.
<G-vec00322-002-s047><calculate.ausrechnen><en> It might be feasible to calculate how much resources to put into "growing chocolate", but how could any centralized system decide how much to produce of the thousands of different kinds of chocolate candies, chocolate pastries, chocolate puddings.
<G-vec00322-002-s047><calculate.ausrechnen><de> Es mag zwar möglich sein, auszurechnen, wie viele Rohstoffe wir in einer „werdenden Schokolade“ benötigen, aber wie soll ein zentralisiertes System entscheiden, wie viele von den tausenden verschiedenen Arten an Schokoladenriegeln, Schokoladenpasten, Schokoladenpuddings hergestellt werden sollen.
<G-vec00322-002-s168><calculate.berechnen><en> The Windows programmer, Thomas F. Carroll helped the Classics For X programmer to calculate the Taipan statistics.
<G-vec00322-002-s168><calculate.berechnen><de> Der Programmierer der Windows-Version, Thomas F. Carroll, half dem Programmierer der Mac-Version, die Taipan-Statistiken zu berechnen.
<G-vec00322-002-s169><calculate.berechnen><en> EtherNet/IP Capacity Tool — Calculate resources used by a proposed EtherNet/IP™ network.
<G-vec00322-002-s169><calculate.berechnen><de> EtherNet/IP-Kapazitätstool – Die von einem vorgeschlagenen EtherNet/IP™-Netzwerk verwendeten Ressourcen berechnen.
<G-vec00322-002-s170><calculate.berechnen><en> Science can calculate time zero, which was the Big Bang.
<G-vec00322-002-s170><calculate.berechnen><de> Die Wissenschaft kann die Zeit null berechnen, das war der Big Bang.
<G-vec00322-002-s171><calculate.berechnen><en> The signals are obtained by GPS receivers, such as navigation devices and are used to calculate the exact position, speed and time at the vehicles location.
<G-vec00322-002-s171><calculate.berechnen><de> Die Signale werden von GPS-Geräten, wie beispielsweise Satellitennavigationsgeräten, empfangen und dazu verwendet, die exakte Position, die Geschwindigkeit des Empfängers sowie die genaue Zeit am Standort des Empfängers zu berechnen.
<G-vec00322-002-s172><calculate.berechnen><en> It collects job logs and is able to automatically calculate costs for a specific job, or over a longer period of time.
<G-vec00322-002-s172><calculate.berechnen><de> Sie sammelt Job-Protokolle und ist in der Lage, automatisch die Kosten über einen konkreten Auftrag oder über einen längeren Zeitraum zu berechnen.
<G-vec00322-002-s173><calculate.berechnen><en> If you use Barcodesoft EAN13 fonts to print bar code, please use our Encoder to calculate checksum for you.
<G-vec00322-002-s173><calculate.berechnen><de> Wenn Sie Barcodesoft Code 11 zum Drucken von Barcodes verwenden, verwenden Sie unseren Encoder, um die Prüfsumme zu berechnen.
<G-vec00322-002-s174><calculate.berechnen><en> In the newsletter 167 one year ago was shown how to calculate externally and internally toothed gear wheel for an eccentric gear by means of ZAR1+.
<G-vec00322-002-s174><calculate.berechnen><de> Im Infobrief 167 vor einem Jahr wurde gezeigt, wie man mit ZAR1+ die Zahnradpaarung für Exzenter-Abwälzgetriebe aus außen- und innenverzahntem Zahnrad berechnen kann.
<G-vec00322-002-s175><calculate.berechnen><en> It will also give users the ability to see what benefits the addition of new technologies and approaches could bring, using their own data to assess the opportunity and calculate return on investment.
<G-vec00322-002-s175><calculate.berechnen><de> Mit dieser Plattform können Anwender zudem sehen, welche Vorteile eine Ergänzung neuer Technologien und Ansätze bringen könnte, indem sie ihre eigenen Daten nutzen, um die Möglichkeit zu bewerten und die Kapitalrendite zu berechnen.
<G-vec00322-002-s176><calculate.berechnen><en> On this webpage you can calculate reactances with two coils, two capacitors and a capacitor and a coil.
<G-vec00322-002-s176><calculate.berechnen><de> Auf der Webseite können Sie die Blindwiderstände zweier Spulen, zweier Kondensatoren oder eines Kondensators zusammen mit einer Spule berechnen.
<G-vec00322-002-s159><calculate.bestimmen><en> In 2018, car importers, therefore, turned to Empa to calculate the cornerstones of a recycling system for car batteries.
<G-vec00322-002-s159><calculate.bestimmen><de> 2018 wandten sich die Auto-Importeure daher an die Empa, um die Eckpunkte eines Recyclingsystems für Antriebsbatterien zu bestimmen.
<G-vec00322-002-s160><calculate.bestimmen><en> A first step is to calculate simple statistical quantities like the mean or the variance of the data. In the case of discrete data one often needs the probability distribution of the data.
<G-vec00322-002-s160><calculate.bestimmen><de> Ein erster Schritt besteht darin, für die Daten einfache statistische Größen wie den Mittelwert und die Standardabweichung zu bestimmen, bei diskreten Daten die Häufigkeitsverteilung.
<G-vec00322-002-s161><calculate.bestimmen><en> The flowmeter then makes use of the flow data, the differential temperature and the specific heat capacity of the flowing medium in order to calculate the energy consumption.
<G-vec00322-002-s161><calculate.bestimmen><de> Um den Energieverbrauch zu bestimmen, wertet das Gerät die Durchflussraten und die Temperaturdifferenz unter Berücksichtigung der spezifischen Wärmekapazität des entsprechenden Mediums aus.
<G-vec00322-002-s162><calculate.bestimmen><en> For controlling and post production analysis it is difficult to calculate the exact energy cost for a production step or an article.
<G-vec00322-002-s162><calculate.bestimmen><de> Für das Controlling und die Nachkalkulation ist es schwierig, die genauen Energiekosten für einen Produktionsschritt oder einen Artikel zu bestimmen.
<G-vec00322-002-s163><calculate.bestimmen><en> Once added to your chart, the FXCM Risk Calculator, as depicted above, has the ability to help a trader calculate risk based off of trade size and stop levels.
<G-vec00322-002-s163><calculate.bestimmen><de> Wenn der FXCM Risk Calculator wie oben dargestellt auf Ihrem Chart hinzugefügt wurde, kann er Tradern helfen, das Risiko aufgrund der Trade-Größe und der Stop-Levels zu bestimmen.
<G-vec00322-002-s164><calculate.bestimmen><en> So far it has helped them to accurately calculate the level of THC in brownies and crackers, among other products.
<G-vec00322-002-s164><calculate.bestimmen><de> Bis jetzt hat diese Methode geholfen, den THC-Wert unter anderem in 'Brownies' und Keksen zu bestimmen.
<G-vec00322-002-s165><calculate.bestimmen><en> Performance cookies: These are cookies that are either processed by us or by third parties and allow us to calculate user numbers and measure and statistically analyse how users utilise the service provided.
<G-vec00322-002-s165><calculate.bestimmen><de> Analyse-Cookies: Anhand dieser entweder von uns oder von Dritten verarbeiteten Cookies können wir die Anzahl der Nutzer bestimmen und somit eine Messung und statistische Analyse der Nutzung der angebotenen Dienste durch die Benutzer durchführen.
<G-vec00322-002-s166><calculate.bestimmen><en> It was already possible to accurately calculate the coordinates of the atoms in simple materials at different temperatures with quantum mechanical molecular dynamics (MD) simulations.
<G-vec00322-002-s166><calculate.bestimmen><de> Für einfache Materialien ist es möglich, die Position ihrer Atome bei verschiedenen Temperaturen mit quantenmechanischen Molekulardynamik-(MD)-Simulationen genau zu bestimmen.
<G-vec00322-002-s167><calculate.bestimmen><en> 2), is able to autonomously calculate the optimal process set-up and the user can also determine the process window for production after just one calculation run.
<G-vec00322-002-s167><calculate.bestimmen><de> 2) und ist in der Lage autonom die optimalen Prozesseinstellungen zu bestimmen, sodass der Benutzer nach nur einer Berechnung das Prozessfenster für die Produktion festlegen kann.
<G-vec00322-002-s177><calculate.ermitteln><en> In order to calculate the rim size of the glasses, simply add together the width of the nose bridge (B) and the lens width (C).
<G-vec00322-002-s177><calculate.ermitteln><de> Um die Fassungsgrösse der Brille zu ermitteln, addieren Sie ganz einfach die Breite des Stegs (B) mit der Glasbreite(C).
<G-vec00322-002-s178><calculate.ermitteln><en> Nevertheless, it is not possible to calculate the house position of several planets, as can be seen in the planet table next to the chart, which shows "0" as house position for quite a few planets.
<G-vec00322-002-s178><calculate.ermitteln><de> Gleichwohl lässt sich die Hausposition etlicher Planeten nicht ermitteln, wie die Planetentabelle in der Grafik offenbart, die für viele Himmelskörper die Hausposition 0 angibt.
<G-vec00322-002-s179><calculate.ermitteln><en> They also file our tax returns and calculate values such as the trade tax owed and the amount to be paid.
<G-vec00322-002-s179><calculate.ermitteln><de> Außerdem fassen sie unsere Steuererklärungen ab und ermitteln Werte wie Gewerbesteuerschuld und –zahlungshöhe.
<G-vec00322-002-s180><calculate.ermitteln><en> Contact Intralox fruit and vegetable specialists and let them calculate the potential savings hidden in your conveyors.
<G-vec00322-002-s180><calculate.ermitteln><de> Wenden Sie sich an die Obst- und Gemüsespezialisten von Intralox, und lassen Sie das ungenutzte Einsparungspotenzial Ihrer Förderer ermitteln.
<G-vec00322-002-s181><calculate.ermitteln><en> We calculate the loads lifted by your hoist and the elapsed share of its theoretical duration of service, which enables us to guarantee the remaining safe working period (SWP).
<G-vec00322-002-s181><calculate.ermitteln><de> Wir ermitteln die Höhe der Belastungen Ihres Hebezeugs und den Verbrauch der theoretischen Nutzungsdauer – und gewährleisten dadurch sichere Betriebsperioden (Safe Working Period, SWP).
<G-vec00322-002-s182><calculate.ermitteln><en> With the scenario analyser you can calculate potential outcomes of the next street(s), calculate river cards and calculate outcomes against multiple ranges.
<G-vec00322-002-s182><calculate.ermitteln><de> Mit der Szenario-Analyse kannst du potenzielle Ergebnisse von nachfolgenden Streets kalkulieren, Riverkarten berechnen und Ergebnisse gegen mehrere Ranges ermitteln.
<G-vec00322-002-s183><calculate.ermitteln><en> We constantly monitor footfall because this allows us to calculate average values over longer periods of time.
<G-vec00322-002-s183><calculate.ermitteln><de> Die Frequenzen messen wir laufend, denn so können wir Durchschnittswerte über größere Zeiträume ermitteln.
<G-vec00322-002-s184><calculate.ermitteln><en> We calculate the weighted average cost of capital (WACC) of debt and equity capital on an annual basis using market values.
<G-vec00322-002-s184><calculate.ermitteln><de> Hierfür ermitteln wir jährlich auf Basis von Marktwerten die Kapitalkosten (Weighted Average Cost of Capital; WACC) als gewichteten Durchschnittswert aus risikoadäquaten Marktrenditen für Eigen- und Fremdkapital.
<G-vec00322-002-s185><calculate.ermitteln><en> For the potency test mice are immunized with different doses of Ixiaro® (in vivo part) and subsequently seroconversion rates of the mouse sera are determined by PRNT (PRNT part) to finally calculate an effective dose 50 (ED50).
<G-vec00322-002-s185><calculate.ermitteln><de> Der Potency Test beruht auf der Immunisierung von Mäusen mit verschiedenen Dosen von Ixiaro® (in vivo Teil) und der anschließenden Bestimmung der Serokonversionsraten der Mausseren mittels PRNT (PRNT Teil), um die Effektive Dosis 50 (ED50) des Impfstoffes zu ermitteln.
<G-vec00322-002-s186><calculate.ermitteln><en> In order to calculate the capital gains the transfer value is deducted from the acquisition value.
<G-vec00322-002-s186><calculate.ermitteln><de> Um den Vermögenszuwachs zu ermitteln, wird der Übertragungswert vom Anschaffungswert abgezogen.
<G-vec00322-002-s187><calculate.ermitteln><en> We calculate the monthly wages and salaries for your employees, the payroll tax and social insurance contributions to be paid to the respective authorities.
<G-vec00322-002-s187><calculate.ermitteln><de> Wir ermitteln für Ihre Mitarbeiter die monatlichen Löhne und Gehälter, die abzuführende Lohnsteuer und Sozialversicherungsbeiträge.
<G-vec00322-002-s188><calculate.ermitteln><en> To calculate, just type or paste any text with numbers into the field and press Calculate digit sums.
<G-vec00322-002-s188><calculate.ermitteln><de> Zum Errechnen einfach eine Zahl oder einen beliebigen Text mit Zahlen in das Feld eingeben oder kopieren und auf Quersummen ermitteln klicken.
<G-vec00322-002-s189><calculate.ermitteln><en> In order to assess the impact of taxation on the competitiveness of agricultural enterprises in different countries, it would therefore be useful to calculate the tax burden for specific forms of enterprises that have the same factor endowment and the same type of production.
<G-vec00322-002-s189><calculate.ermitteln><de> Um den Einfluß der Besteuerung auf die Wettbewerbsfähigkeit der landwirtschaftlichen Unternehmen verschiedener Länder erfassen zu können, wäre es deshalb zweckmäßig, für definierte Unternehmen mit gleicher Faktorausstattung und gleicher Produktion, die Steuerbelastung zu ermitteln.
<G-vec00322-002-s190><calculate.ermitteln><en> At the end of every season, the results of these audits are added to the results of the satisfaction questionnaires completed by our customers so as to calculate scores per criterion for each village.
<G-vec00322-002-s190><calculate.ermitteln><de> Am Ende jeder Saison addieren wir die Ergebnisse dieser Prüfungen zu den Ergebnissen der durch die Kunden ausgefüllten Zufriedenheitsfragebögen und ermitteln so für jedes Dorf die jeweiligen Noten in den einzelnen Kriterien.
<G-vec00322-002-s191><calculate.ermitteln><en> To calculate the cost of furniture for an unfurnished apartment, the local cost for a representative selection of furniture available from IKEA worldwide was calculated separately for the two size classes.
<G-vec00322-002-s191><calculate.ermitteln><de> Um die notwendigen Ausgaben zur Möblierung einer Wohnung zu ermitteln, wurden die örtlichen Kosten für eine repräsentative Auswahl an Möbeln von IKEA für beide Wohnungsgrößen berechnet.
<G-vec00322-002-s192><calculate.ermitteln><en> I use various different data sources of the Institute for Employment Research (IAB) to calculate worker flows and job flows as well as inflows into and outflows from unemployment.
<G-vec00322-002-s192><calculate.ermitteln><de> Es werden verschiedene Datenquellen des IAB verwendet, um die Fluktuation von Arbeitskräften (Worker Flows) und Arbeitsplätzen (Job Flows) sowie Zugänge in und Abgänge aus Arbeitslosigkeit zu ermitteln.
<G-vec00322-002-s193><calculate.ermitteln><en> The odds are easy enough to calculate, and the wager on is rather structured as you shall see.
<G-vec00322-002-s193><calculate.ermitteln><de> Die Glücksspiele sind einfach genug, um zu ermitteln, und das Spiel ist ein wenig strukturiert.
<G-vec00322-002-s194><calculate.ermitteln><en> As long as you know the temperature of your sample, and the temperature standard of your hydrometer, you can calculate the salinity.
<G-vec00322-002-s194><calculate.ermitteln><de> Solange du die Temperatur deiner Probe und den Temperaturbereich deines Hydrometers kennst, kannst du den Salzgehalt ermitteln.
<G-vec00322-002-s195><calculate.ermitteln><en> “Calculate special lengths” asks for, or determines special lengths.
<G-vec00322-002-s195><calculate.ermitteln><de> „Fixlängen ermitteln“ erfragt oder ermittelt Fixlängen.
<G-vec00322-002-s232><calculate.errechnen><en> The monitoring unit has a calculation program in order to calculate an ACTUAL value of a melt flow rate of the spinning pump and/or an ACTUAL value of a total titre of the strand.
<G-vec00322-002-s232><calculate.errechnen><de> In der Überwachungseinheit könn- te hierzu ein weiteres Berechnungsprogramm hinterlegt sein, das den IST- Wert des Gesamttiters aus der Masse des Fadens errechnet.
<G-vec00322-002-s233><calculate.errechnen><en> The Filling & Packaging Performance app uses the values to calculate overall equipment effectiveness, allowing customers to monitor the equipment’s performance at any time.
<G-vec00322-002-s233><calculate.errechnen><de> Aus den Werten errechnet Filling & Packaging Performance dann eine Overall Equipment Effectiveness, mit der die Leistung der Anlage jederzeit abrufbar ist.
<G-vec00322-002-s234><calculate.errechnen><en> A&K uses simulation in selected scenarios to calculate and rate your supply chain and logistical processes, value stream alternatives, management philosophies, methods and parameters.
<G-vec00322-002-s234><calculate.errechnen><de> Mit Hilfe der Simulation errechnet und bewertet A&K Supply-Chain- und Logistikprozesse, Wertstromalternativen, Steuerungsphilosophien, Methoden und Parameter in ausgewählten Szenarien.
<G-vec00322-002-s235><calculate.errechnen><en> The shop will calculate your exact shipping charges when you check out.
<G-vec00322-002-s235><calculate.errechnen><de> Ihren exakten Tarif errechnet der Shop während des Bestellvorgangs online.
<G-vec00322-002-s236><calculate.errechnen><en> For instance, EHS participates in the World Risk Index, which is used to calculate the risk of disasters for 171 countries.
<G-vec00322-002-s236><calculate.errechnen><de> Das EHS ist beispielsweise beteiligt am Weltrisikoindex, der das Katastrophenrisiko für 171 Länder errechnet.
<G-vec00322-002-s237><calculate.errechnen><en> Once the actual sums have been submitted, the city can calculate the difference.
<G-vec00322-002-s237><calculate.errechnen><de> Liegen die tatsächlichen Zahlen schließlich vor, errechnet die Stadt den Differenzbetrag.
<G-vec00322-002-s238><calculate.errechnen><en> Optimised gear shifts, lower fuel consumption – the engine electronics calculate the most efficient gear for each driving situation and engine speed.
<G-vec00322-002-s238><calculate.errechnen><de> Optimal schalten, Verbrauch senken – die Motorelektronik errechnet je nach Fahrsituation und Motordrehzahl den aktuell effizientesten Gang, und ein aufleuchtendes Pfeilsymbol zeigt im Info Display an, wenn das Fahrzeug in einem höheren oder niedrigeren Gang sparsamer unterwegs sein könnte.
<G-vec00322-002-s239><calculate.errechnen><en> The third step is to calculate the mean deviation from the moving average.
<G-vec00322-002-s239><calculate.errechnen><de> Im dritten und letzten Schritt wird die mittlere Abweichung vom zuvor ermittelten gleitenden Durchschnitt errechnet.
<G-vec00322-002-s240><calculate.errechnen><en> You calculate your surcharge for free holiday cancellation based on the information given above and add it to the amount of deposit and pay it with the deposit.
<G-vec00322-002-s240><calculate.errechnen><de> Zahlung Ihr errechnet euch nach obigen Angaben euren Aufschlag für den kostenlosen Urlaubsrücktritt und addiert diese zum zu zahlenden Anzahlungsbetrag einfach dazu.
<G-vec00322-002-s241><calculate.errechnen><en> The app will now calculate your net salary in seconds.
<G-vec00322-002-s241><calculate.errechnen><de> Die App errechnet nun in Sekundenschnelle Ihr Nettogehalt.
<G-vec00322-002-s242><calculate.errechnen><en> They can also communicate with other devices, such as the on-board computer, which uses the data from the cells to calculate how much remaining energy the entire battery still has, the so called state of charge.
<G-vec00322-002-s242><calculate.errechnen><de> Oder sie kommunizieren mit anderen Geräten, etwa dem Bordcomputer, der aus den Daten der Zellen errechnet, wie viel Restenergie die gesamte Batterie noch aufweist.
<G-vec00322-002-s243><calculate.errechnen><en> Since, in the phase of flight, it is important to know whether the airports can be reached at all, and not how fast, pocket*StrePla will calculate the optimum Mac Cready setting.
<G-vec00322-002-s243><calculate.errechnen><de> Da es in dieser Flugphase darauf ankommt, ob diese Flugplätze überhaupt erreicht werden und nicht ob sie möglichst schnell wie im Wettbewerb erreicht werden, errechnet pocket*StrePla die optimale Mc Cready Einstellung.
<G-vec00322-002-s244><calculate.errechnen><en> The consulting firm Front Economics has carried out a study, on behalf of Agora Verkehrswende and Agora Energiewende, to calculate the efficiency of Power-to-Gas technology applications: While an electric car uses almost 70 percent of the electricity, a fuel cell car, which runs on synthetic hydrogen, only uses around a quarter.
<G-vec00322-002-s244><calculate.errechnen><de> Die Beratungsfirma Front Economics hat im Auftrag von Agora Verkehrswende und Agora Energiewende in einer Studie die Wirkungsgrade von Anwendungen der Power-to-Gas-Technologie errechnet: Während ein E-Auto knapp 70 Prozent des Stroms nutzt, ist es beim Brennstoffzellen-Auto, das mit synthetischem Wasserstoff fährt, nur rund ein Viertel.
<G-vec00322-002-s245><calculate.errechnen><en> (4) The Operator shall calculate and charge the tax on gaming winnings at the moment of paying out the winning to the Player’s I-account.
<G-vec00322-002-s245><calculate.errechnen><de> (4) Der Betreiber errechnet die Gewinnsteuer und zieht diese im Moment der Auszahlung des Gewinns auf das virtuelle Konto (i-Konto) des Spielers ein.
<G-vec00322-002-s246><calculate.errechnen><en> The modular cutting optimisation software uses the material list to calculate the most economic cutting process taking the cutting times and amount of waste into consideration.
<G-vec00322-002-s246><calculate.errechnen><de> Schnittoptimierungs-Software Die modular aufgebaute Schnittoptimierungs-Software errechnet aus den Stücklisten die wirtschaftlichsten Zuschnittpläne unter Berücksichtigung von Zuschnittzeit und Verschnittmenge.
<G-vec00322-002-s247><calculate.errechnen><en> China Airlines will calculate and confirm your mileage after departure.
<G-vec00322-002-s247><calculate.errechnen><de> China Airlines errechnet und bestätigt Ihre Meilen nach Abflug.
<G-vec00322-002-s248><calculate.errechnen><en> Online casinos calculate their rollover requirements so that they don’t make any losses.
<G-vec00322-002-s248><calculate.errechnen><de> Ein Online Casino errechnet die Umsatzbedingungen so, dass es im Durchschnitt keine Verluste macht.
<G-vec00322-002-s249><calculate.errechnen><en> The system uses data from sensors to detect unstable driving conditions and calculate the correct counter-measure in a split second.
<G-vec00322-002-s249><calculate.errechnen><de> Anhand von Sensorik-Daten kann das elektronische Stabilisierungsprogramm einen instabilen Fahrzustand erkennen und errechnet in Sekundenbruchteilen die richtige Gegenmaßnahme.
<G-vec00322-002-s250><calculate.errechnen><en> A mobile phone picks up the three signals and can calculate the location from the time.
<G-vec00322-002-s250><calculate.errechnen><de> Das Mobiltelefon empfängt die drei Signale und errechnet aus den Zeiten den Standort.
<G-vec00322-002-s270><calculate.kalkulieren><en> Calculate your desired quantity of Folding boxes.
<G-vec00322-002-s270><calculate.kalkulieren><de> Kalkulieren Sie Ihre gewünschte Menge Faltschachteln.
<G-vec00322-002-s271><calculate.kalkulieren><en> Calculate quadratic equations with this excellent, visual, tool.
<G-vec00322-002-s271><calculate.kalkulieren><de> Kalkulieren Sie quadratische Formeln mit diesem tollen, visuellen Werkzeug.
<G-vec00322-002-s272><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Note pads.
<G-vec00322-002-s272><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Schreibunterlagen.
<G-vec00322-002-s273><calculate.kalkulieren><en> Although it is easy to order a new domain and redirect the old domain, you have to calculate at least 1 year until all the scales have settled.
<G-vec00322-002-s273><calculate.kalkulieren><de> Es ist zwar ein Leichtes eine neue Domain zu bestellen und die alte Domain umzuleiten, doch kalkulieren Sie mit mindestens 1 Jahr bis sich alle Wogen geglättet haben.
<G-vec00322-002-s274><calculate.kalkulieren><en> Budget report, calculate your project costs.
<G-vec00322-002-s274><calculate.kalkulieren><de> Kalkulieren Sie die Projektkosten.
<G-vec00322-002-s275><calculate.kalkulieren><en> In addition to that, we calculate the costs, check the profitability of your plan, and apply for patents and test certificates for you.
<G-vec00322-002-s275><calculate.kalkulieren><de> Außerdem kalkulieren wir für Sie die Kosten, prüfen die Rentabilität Ihres Vorhabens und holen Patente sowie Prüf-Zertifikate für Sie ein.
<G-vec00322-002-s276><calculate.kalkulieren><en> Calculate your desired quantity of Floor stickers.
<G-vec00322-002-s276><calculate.kalkulieren><de> Kalkulieren Sie Ihre gewünschte Menge Bodenaufkleber.
<G-vec00322-002-s277><calculate.kalkulieren><en> Second, calculate the value of the bond assuming the owner is subject to the maximum personal income tax rate.
<G-vec00322-002-s277><calculate.kalkulieren><de> Zweitens kalkulieren sie den Wert dieser Anleihe unter der Berücksichtigung, dass der Investor die höchste Steuerrate zu zahlen hat.
<G-vec00322-002-s278><calculate.kalkulieren><en> Take a look at projects we have completed or calculate the price yourself.
<G-vec00322-002-s278><calculate.kalkulieren><de> Schauen Sie sich einige unserer Projekte an oder kalkulieren Sie den Preis selbst.
<G-vec00322-002-s279><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Floor stickers.
<G-vec00322-002-s279><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Klebefolien.
<G-vec00322-002-s280><calculate.kalkulieren><en> Calculate your desired quantity of Magnetic sheets.
<G-vec00322-002-s280><calculate.kalkulieren><de> Kalkulieren Sie Ihre gewünschte Menge Magnetfolien.
<G-vec00322-002-s281><calculate.kalkulieren><en> Calculate the volume of all common geometrical shapes, such as cubes, spheres, pyramids, cones etc.
<G-vec00322-002-s281><calculate.kalkulieren><de> Kalkulieren Sie das Volumen von allen gängigen Fromen, sowie Würfel, Kugeln, Pyramiden usw.
<G-vec00322-002-s282><calculate.kalkulieren><en> Calculate how much you’re spending, even without realizing “what” you are spending it on.
<G-vec00322-002-s282><calculate.kalkulieren><de> Kalkulieren Sie, wie viel Sie ausgeben, auch ohne zu realisieren „wofür“ Sie es ausgeben.
<G-vec00322-002-s283><calculate.kalkulieren><en> Calculate safely and easily with a smart rate and no hidden costs.
<G-vec00322-002-s283><calculate.kalkulieren><de> Kalkulieren Sie einfach und sicher mit einer smarten Rate ohne zusätzliche Nebenkosten.
<G-vec00322-002-s284><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Folding boxes.
<G-vec00322-002-s284><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Kissenschachteln.
<G-vec00322-002-s285><calculate.kalkulieren><en> So make your mind, calculate your budget and find a venue which best suits your needs, before someone else books it.
<G-vec00322-002-s285><calculate.kalkulieren><de> Also denken Sie darüber nach, kalkulieren Sie Ihr Budget und finden Sie einen Veranstaltungsort, der Ihren Bedürfnissen am besten entspricht, bevor jemand anderes ihn bucht.
<G-vec00322-002-s286><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Calendars.
<G-vec00322-002-s286><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Schreibblocks.
<G-vec00322-002-s287><calculate.kalkulieren><en> Of course, you only pay for what you use, and can precisely calculate in advance how much the applications will cost.
<G-vec00322-002-s287><calculate.kalkulieren><de> Selbstverständlich bezahlen Sie nur das, was sie nutzen, und Sie können im Voraus genau kalkulieren, wie viel Sie für die Anwendungen ausgeben.
<G-vec00322-002-s288><calculate.kalkulieren><en> Configure and calculate your running rigging quick and easy with a few mouse clicks.
<G-vec00322-002-s288><calculate.kalkulieren><de> Konfigurieren und kalkulieren Sie sich Ihr Tauwerk schnell und einfach mit ein paar Mausklicks.
<G-vec00322-002-s308><calculate.rechnen><en> ∙ Calculate 3 times 8 minus root of tangent of 3.
<G-vec00322-002-s308><calculate.rechnen><de> ∙ Rechne 3 mal 8 minus Wurzel von Tanges 3.
<G-vec00322-002-s309><calculate.rechnen><en> If your account is denominated in a currency other than US dollar, then simply calculate the equivalent amount of US dollars in your account using the current exchange rate and base your position size on that.
<G-vec00322-002-s309><calculate.rechnen><de> Falls dein Trading-Konto in einer anderen Währung als US-Dollar geführt wird, rechne den Betrag einfach mit dem aktuellen Wechselkurs in US-Dollar um und lege darauf beruhend deine Positionsgröße fest.
<G-vec00322-002-s310><calculate.rechnen><en> Repeat this process 10 times and calculate the average of all 10 results.
<G-vec00322-002-s310><calculate.rechnen><de> Wiederhole diesen Prozess zehn Mal und rechne den Durchschnitt aller zehn Ergebnisse aus.
<G-vec00322-002-s311><calculate.rechnen><en> The distance is about four kilometers, so you should calculate with about one hour to get there from the station.
<G-vec00322-002-s311><calculate.rechnen><de> Die Distanz beträgt knapp vier Kilometer, rechne also mit einer guten Stunde Gehzeit.
<G-vec00322-002-s312><calculate.rechnen><en> Calculate the investments needed to reach your goals.
<G-vec00322-002-s312><calculate.rechnen><de> Rechne die erforderlichen Investitionen zum Erreichen deiner Ziele aus.
<G-vec00322-002-s313><calculate.rechnen><en> Calculate how much sugar is in a particular bottle or can: to do so look on the nutrition label for how many grams of sugar there are per serving.
<G-vec00322-002-s313><calculate.rechnen><de> Rechne aus, wie viel Zucker in einer bestimmten Flasche oder Dose ist: um dies zu tun, schau auf die Nährwertkennzeichnung und suche, wie viel Gramm Zucker pro Portion enthalten ist.
<G-vec00322-002-s314><calculate.rechnen><en> Calculate the squares.
<G-vec00322-002-s314><calculate.rechnen><de> Rechne die Quadrate aus.
<G-vec00322-002-s315><calculate.rechnen><en> Now, calculate some other problems like 4 + 7 or 329 + 12.
<G-vec00322-002-s315><calculate.rechnen><de> Rechne dann auch andere Aufgaben wie 4 + 7 oder 329 + 12.
<G-vec00322-002-s316><calculate.rechnen><en> Calculate the square footage.
<G-vec00322-002-s316><calculate.rechnen><de> Rechne die Fläche aus.
<G-vec00166-002-s019><calculate.ausrechnen><en> When you stay in the world of matter, then one can calculate that.
<G-vec00166-002-s019><calculate.ausrechnen><de> Wenn Sie sich in der Welt der Materie aufhalten, dann kann man das ausrechnen.
<G-vec00166-002-s020><calculate.ausrechnen><en> Based on the capacity or power consumption of the device which is connected to the battery pack, you can calculate how often or how long your device can be charged / powered.
<G-vec00166-002-s020><calculate.ausrechnen><de> Auf Basis von der Kapazität oder de Leistung von dem Gerät was an die Powerbank angeschlossen wird, kannst Du ausrechnen wie oft oder wie lang das Gerät aufgeladen oder betrieben werden kann.
<G-vec00166-002-s021><calculate.ausrechnen><en> To calculate your most fertile days, you must first calculate the average duration of your cycle.
<G-vec00166-002-s021><calculate.ausrechnen><de> Sie müssen Ihren Zyklus nicht mehr eigenständig ausrechnen, um die besten Chancen für eine Schwangerschaft zu eruieren.
<G-vec00166-002-s022><calculate.ausrechnen><en> Choose your age, enter your gender and weight in kilogram an click Calculate.
<G-vec00166-002-s022><calculate.ausrechnen><de> Wählen Sie Ihr Alter aus und geben Sie Ihr Gewicht in Kilogramm ein und klicken Sie auf Ausrechnen.
<G-vec00166-002-s023><calculate.ausrechnen><en> You can also calculate which bra size you should be wearing using specific calculations, without the table above.
<G-vec00166-002-s023><calculate.ausrechnen><de> Mit bestimmten Berechnungen lässt sich auch ohne die obige Tabelle ausrechnen, welche BH-Größe du tragen solltest.
<G-vec00166-002-s024><calculate.ausrechnen><en> $0.99 This application allows you to calculate your Body Mass Index.
<G-vec00166-002-s024><calculate.ausrechnen><de> Mit dem BMI-Rechner können Sie ihren Body Maß Index ganz bequem ausrechnen.
<G-vec00166-002-s025><calculate.ausrechnen><en> Thus, you will be able to calculate the price yourself in advance.
<G-vec00166-002-s025><calculate.ausrechnen><de> Auf die Weise können Sie auch selbst den Preis im Voraus ausrechnen.
<G-vec00166-002-s026><calculate.ausrechnen><en> Calculate how much tax you can save with pillar 3a: With the Swiss Life tax calculator.
<G-vec00166-002-s026><calculate.ausrechnen><de> Ausrechnen, wie viel Steuern Sie mit der Säule 3a sparen können: Mit dem Steuerrechner von Swiss Life.
<G-vec00166-002-s027><calculate.ausrechnen><en> In the current succession debate, however, he is remembered not so much as the man who became known in 2003 by claiming that every citizen in Germany should be able to calculate his or her income tax on a beer coaster, but rather as the man with millions in his account and his mandate as Supervisory Board Chairman of Blackrock, the world’s biggest asset manager.
<G-vec00166-002-s027><calculate.ausrechnen><de> In der aktuellen Nachfolgedebatte ist er jedoch weniger der Mann, der 2003 mit dem Anspruch bekannt wurde, dass jeder Bürger seine Einkommensteuer auf einem Bierdeckel ausrechnen können sollte, sondern mehr der Mann mit den Millionen auf dem Konto und dem Mandat als Aufsichtsratschef von Blackrock, dem größten Vermögensverwalter der Welt.
<G-vec00166-002-s028><calculate.ausrechnen><en> For example, students use math skills when they calculate and chart the baby’s weight and measurements.
<G-vec00166-002-s028><calculate.ausrechnen><de> So setzen die Schüler/innen ihre mathematischen Fähigkeiten ein, wenn sie das Gewicht und die Größe des Babys ausrechnen.
<G-vec00166-002-s029><calculate.ausrechnen><en> If you select to custom the page size, you only need to calculate the correct size of Width and Height of your page.
<G-vec00166-002-s029><calculate.ausrechnen><de> Falls Sie sich dafür entscheiden die Seitengröße zu verändern, müssen Sie nur die korrekte Größe der Breite und Länge ausrechnen.
<G-vec00166-002-s030><calculate.ausrechnen><en> The food erm will calculate if this would be too much for storage, and if so, either suggest all members of the community to use more of it, or have it distributed to communities that have less.
<G-vec00166-002-s030><calculate.ausrechnen><de> Die Nahrungs-Verspon wird ausrechnen, ob dies zu viel zum Einlagern sein wird, und falls dem so ist, entweder allen Mitgliedern der Kommune dazu raten, mehr zu verbrauchen, oder es an Kommunen verteilen lassen, die weniger haben.
<G-vec00166-002-s031><calculate.ausrechnen><en> If the benefit of your cultural change lies in the future, you can calculate how great your personal commitment will be.
<G-vec00166-002-s031><calculate.ausrechnen><de> Wenn der Nutzen Ihres Kulturwandels in der Zukunft liegt, können Sie sich ausrechnen, wie groß das persönliche Engagement sein wird.
<G-vec00166-002-s032><calculate.ausrechnen><en> All you can do is calculate, how PROBABLE he can roll a given number.
<G-vec00166-002-s032><calculate.ausrechnen><de> Alles was du tun kannst ist ausrechnen, wie WAHRSCHEINLICH er eine bestimmte Zahl würfeln kann.
<G-vec00166-002-s033><calculate.ausrechnen><en> One can calculate how many water molecules that is – and how many “human” units of water are contained in all the water on Earth.
<G-vec00166-002-s033><calculate.ausrechnen><de> Man kann ausrechnen, wieviele Wassermoleküle das sind – und wieviel „Menschenmassen“ von Wasser in all dem Wasser auf Erden enthalten sind.
<G-vec00166-002-s034><calculate.ausrechnen><en> In no way do the universities determine the NC values in advance nor can applicants calculate their chances.
<G-vec00166-002-s034><calculate.ausrechnen><de> Es ist keineswegs so, dass die Unis die NC-Werte vorher festlegen und die Bewerberinnen und Bewerber sich ihre Chancen ausrechnen können.
<G-vec00166-002-s035><calculate.ausrechnen><en> All can calculate the lengths of the incubation periods for themselves.
<G-vec00166-002-s035><calculate.ausrechnen><de> Alle können die Länge der Brutzeit selber ausrechnen.
<G-vec00166-002-s036><calculate.ausrechnen><en> And if truckers use their vehicles practically as a living space despite reduced space offer, you can easily calculate the consumption, including air conditioning.
<G-vec00166-002-s036><calculate.ausrechnen><de> Und wenn Lkw-Fahrer/innen ihre Gefährte trotz vermindertem Raumangebot praktisch als Wohnraum nutzen, kann man sich den Verbrauch einschließlich Klimaanlage leicht ausrechnen.
<G-vec00166-002-s037><calculate.ausrechnen><en> With the upper calculator one can also calculate approximately the concentration of a magnesium sulfate bath.
<G-vec00166-002-s037><calculate.ausrechnen><de> Mit dem oberen Rechner kann man auch ungefähr die Konzentration von einem Magnesiumsulfat Bad ausrechnen.
<G-vec00166-002-s048><calculate.berechnen><en> Calculate your profits.
<G-vec00166-002-s048><calculate.berechnen><de> Berechne deinen Gewinn.
<G-vec00166-002-s049><calculate.berechnen><en> -3: Calculate w/h using the other dimension and the original aspect ratio.
<G-vec00166-002-s049><calculate.berechnen><de> -3: Berechne Breite/Höhe anhand der jeweils anderen Größe und dem originalen Breiten-/Höhenverhältnis.
<G-vec00166-002-s050><calculate.berechnen><en> Calculate the distances and travel times between these points.
<G-vec00166-002-s050><calculate.berechnen><de> Berechne die Fahrstrecke und -dauer zwischen den einzelnen Punkten.
<G-vec00166-002-s051><calculate.berechnen><en> While the hand itself has a golden color, I calculate the bloom strength separately for red, green and blue components, creating a more fiery orange color fringe.
<G-vec00166-002-s051><calculate.berechnen><de> Während die Hand selbst eine goldene Farbe besitzt, berechne ich die Stärke des Schimmers für rot, grün und blau separat, um einen eher feurig orangefarbenen Rand zu erzeugen.
<G-vec00166-002-s052><calculate.berechnen><en> Take one pile and calculate how many possibilities you have to form differently sounding rows of the 6 cards.
<G-vec00166-002-s052><calculate.berechnen><de> Nimm einen Stapel und berechne die Anzahl Möglichkeiten, um aus den 6 Karten unterschiedlich klingende Reihen zu bilden.
<G-vec00166-002-s053><calculate.berechnen><en> Then calculate % ionization for this solution.
<G-vec00166-002-s053><calculate.berechnen><de> Berechne den ph-wert dieser Lösung.
<G-vec00166-002-s054><calculate.berechnen><en> For orders with a low commodity value I calculate a fee for postage and packaging of 3 €.
<G-vec00166-002-s054><calculate.berechnen><de> Für Bestellungen mit niedrigerem Warenwert berechne ich eine Porto- und Verpackungspauschale von 3 Euro.
<G-vec00166-002-s055><calculate.berechnen><en> Then, calculate the exponent.
<G-vec00166-002-s055><calculate.berechnen><de> Berechne die Gesamtsumme der erhaltenen Zinsen.
<G-vec00166-002-s056><calculate.berechnen><en> Now, it’s not that I calculate my R for every tick every time the market moves, but I do it when a candlestick closes.
<G-vec00166-002-s056><calculate.berechnen><de> Nun, es ist nicht so, dass ich jedes Mal, wenn sich der Markt bewegt, mein R für jeden Tick berechne, aber ich mache es, wenn sich eine Kerzenformation schließt.
<G-vec00166-002-s057><calculate.berechnen><en> 5 Calculate the measurement of the third angle.
<G-vec00166-002-s057><calculate.berechnen><de> 5 Berechne den Wert des dritten Winkels.
<G-vec00166-002-s058><calculate.berechnen><en> Calculate the ratio of the cut frame and cut parts.
<G-vec00166-002-s058><calculate.berechnen><de> Berechne den Anteil der Einschnitte an der Rechtecksfläche.
<G-vec00166-002-s059><calculate.berechnen><en> Calculate probability for any Probability to draw at least one of the selected cards.
<G-vec00166-002-s059><calculate.berechnen><de> Berechne Wahrscheinlichkeiten für irgendeine Wahrscheinlichkeit, mindestens eine der gewählten Karten zu ziehen.
<G-vec00166-002-s060><calculate.berechnen><en> Calculate the impedance at resonance.
<G-vec00166-002-s060><calculate.berechnen><de> Berechne die Impedanz bei Resonanz.
<G-vec00166-002-s061><calculate.berechnen><en> Calculate the concentration of the acid.
<G-vec00166-002-s061><calculate.berechnen><de> Berechne die Konzentration und den ph-wert der Salzsäure.
<G-vec00166-002-s062><calculate.berechnen><en> Just calculate its weight, and think of it as galactic air - something to pass through.
<G-vec00166-002-s062><calculate.berechnen><de> Berechne einfach ihr Gewicht, und bedenke sie als galaktische Luft - etwas, wo man sich hindurchbewegt.
<G-vec00166-002-s063><calculate.berechnen><en> Calculate your LBM from your body fat percentage.
<G-vec00166-002-s063><calculate.berechnen><de> Berechne deine magere Körpermasse anhand deines Körperfettanteils.
<G-vec00166-002-s064><calculate.berechnen><en> In the Invoice Header tab, the new button “Calculate Tax Amount from Items” has been added (additional activation in Customizing is required).
<G-vec00166-002-s064><calculate.berechnen><de> Im Reiter Rechnungskopf wurde die neue Taste “Berechne Steuersumme aus Positionen” hinzugefügt (zusätzliche Aktivierung im Customizing erforderlich).
<G-vec00166-002-s065><calculate.berechnen><en> Enrico Medi, a great astrophysicist of our time, whose cause of beatification has been introduced, wrote: "O you mysterious galaxies... I see you, I calculate you, I understand you, I study you and I discover you, I penetrate you and I gather you.
<G-vec00166-002-s065><calculate.berechnen><de> Das hatte ein großer Astrophysiker unserer Zeit gut verstanden, dessen Seligsprechungsprozeß eingeleitet worden ist, Enrico Medi, der geschrieben hatte: »Oh, ihr geheimnisvollen Galaxien…, ich sehe euch, ich berechne euch, ich verstehe euch, ich studiere und entdecke euch, ich durchdringe euch und sammle euch.
<G-vec00166-002-s066><calculate.berechnen><en> Calculate your total Current (Amps).
<G-vec00166-002-s066><calculate.berechnen><de> Berechne den Gesamtstrom (Ampere).
<G-vec00166-002-s067><calculate.berechnen><en> Once your project is complete, you can easily calculate your actual incidence rate:
<G-vec00166-002-s067><calculate.berechnen><de> Sobald Ihr Projekt abgeschlossen ist, können Sie ganz einfach die tatsächliche Häufigkeitsrate berechnen.
<G-vec00166-002-s068><calculate.berechnen><en> In collaboration with the University of Tuscia, we have developed a calculation method that allows us to calculate the CO2 balance of each individual tree.
<G-vec00166-002-s068><calculate.berechnen><de> In Zusammenarbeit mit der Universität Tuscia haben wir eine Kalkulationsmethode entwickelt, die uns ermöglicht, den einzelnen CO2-Ausgleich jedes einzelnen Baumes zu berechnen.
<G-vec00166-002-s069><calculate.berechnen><en> If you know the number of Reynolds, you can calculate the pressure in a pipe line.
<G-vec00166-002-s069><calculate.berechnen><de> Der Druck in einer Rohrleitung läßt sich ebenfalls durch die Reynoldszahl berechnen.
<G-vec00166-002-s070><calculate.berechnen><en> Hedge funds, family offices, fund administrators and private equity firms rely on FundCount¿s standard reports and flexible templates to view asset allocation, prepare tax schedules, calculate fund performance, track nested entities and more.
<G-vec00166-002-s070><calculate.berechnen><de> Hedgefonds, Familienbüros, Fondsadministratoren und Private-Equity-Unternehmen verlassen sich auf die Standardberichte und flexiblen Vorlagen von FundCount, um die Asset-Allokation anzuzeigen, Steuerpläne zu erstellen, die Fondsperformance zu berechnen, verschachtelte Einheiten zu verfolgen und vieles mehr.
<G-vec00166-002-s071><calculate.berechnen><en> Live Snapshot Enter the working distance to calculate the field of view.
<G-vec00166-002-s071><calculate.berechnen><de> Livebild Einzelbild Geben Sie hier den Arbeitsabstand ein, um das Sichtfeld zu berechnen.
<G-vec00166-002-s072><calculate.berechnen><en> It’s easy to get started: enter your profile details and goal weight, and we’ll calculate the daily calorie budget best for you.
<G-vec00166-002-s072><calculate.berechnen><de> Geben Sie Ihre Profildetails und Ihr Zielgewicht ein, und wir berechnen für Sie die täglich beste Kalorienmenge.
<G-vec00166-002-s073><calculate.berechnen><en> If none of the exchanges on this page satisfy your demand for reserve, enter the amount of Wire Transfer THB, you want to buy, into the form above the exchanges list, and click "Calculate".
<G-vec00166-002-s073><calculate.berechnen><de> Falls keines der Wechselbüros auf dieser Seite Ihre Nachfrage nach Reserven befriedigt, geben Sie die Menge an Payeer USD, die Sie kaufen möchten, in das Formular über der Wechselbüro-Liste ein und klicken Sie auf „Berechnen”.
<G-vec00166-002-s074><calculate.berechnen><en> Calculate impedance Our online tool lets you immediately calculate impedance in three easy steps.
<G-vec00166-002-s074><calculate.berechnen><de> Mithilfe unseres Online-Tools können Sie den Widerstand in drei einfachen Schritten berechnen.
<G-vec00166-002-s075><calculate.berechnen><en> Glossy Embossing Calculate The selected quantity is the closest to what we have but also the cheapest.
<G-vec00166-002-s075><calculate.berechnen><de> Berechnen Die gewählte Anzahl ist der verfügbaren Anzahl am nächsten und gleichzeitig am günstigsten.
<G-vec00166-002-s076><calculate.berechnen><en> To calculate our situation, we use GHG (Green House Gas Protocol).
<G-vec00166-002-s076><calculate.berechnen><de> Um unsere Situation zu berechnen, verwenden wir GHG (Green House Gas Protocol).
<G-vec00166-002-s077><calculate.berechnen><en> To calculate the market size, the analyst considers the revenue generated from the shipment of electronic dictionaries or pocket electronic dictionaries.
<G-vec00166-002-s077><calculate.berechnen><de> Um die Marktgröße zu berechnen, berücksichtigt der Analyst die Einnahmen aus dem Versand elektronischer Wörterbücher oder elektronischer Wörterbücher.
<G-vec00166-002-s078><calculate.berechnen><en> It it used to calculate new and returning visitor statistics.
<G-vec00166-002-s078><calculate.berechnen><de> Es wird verwendet, um neue und wiederkehrende Besucherstatistiken zu berechnen.
<G-vec00166-002-s079><calculate.berechnen><en> And form such a diet based on the weight of a woman, a specialist, usually should calculate the necessary calorie intake of food.
<G-vec00166-002-s079><calculate.berechnen><de> Und eine solche Diät basierend auf dem Gewicht einer Frau, einem Spezialisten, sollte in der Regel die notwendige Kalorienaufnahme von Lebensmitteln berechnen.
<G-vec00166-002-s080><calculate.berechnen><en> If you then calculate the capacity utilization rate, you can easily see who is available – and when – for new project applications.
<G-vec00166-002-s080><calculate.berechnen><de> Wenn Sie dann den Auslastungsgrad berechnen, können Sie ganz einfach sehen, wer und wann für neue Projektanfragen zur Verfügung steht.
<G-vec00166-002-s081><calculate.berechnen><en> For a lingerie set, we calculate 10 - € Mapa
<G-vec00166-002-s081><calculate.berechnen><de> Für ein Wäsche Set berechnen wir 10.- € pro Person in Berlin vor Ort.
<G-vec00166-002-s082><calculate.berechnen><en> In this case, if you deposited $50 the betting site would calculate your bonus like this: $50 * 100% = $50.
<G-vec00166-002-s082><calculate.berechnen><de> In diesem Fall würde sich Dein Bonusbetrag wie folgt berechnen: 50€ x 100% = 50€.
<G-vec00166-002-s083><calculate.berechnen><en> We calculate the tractive force for each project to determine the appropriate aluminium rails.
<G-vec00166-002-s083><calculate.berechnen><de> Wir berechnen für jedes Projekt die Zugkraft und wählen ausgehend davon das passende Aluminiumprofil aus.
<G-vec00166-002-s084><calculate.berechnen><en> TRANSDATA successfully uses the PTV xServer in order to visualise the address, vehicle, order and journey data on maps and to calculate distances and toll charges.
<G-vec00166-002-s084><calculate.berechnen><de> TRANSDATA setzt erfolgreich die PTV xServer ein, um die Adress-, Fahrzeug-, Auftrags- und Tourdaten auf Karten zu visualisieren und Entfernungen sowie Mautdaten zu berechnen.
<G-vec00166-002-s085><calculate.berechnen><en> If none of the exchanges on this page satisfy your demand for reserve, enter the amount of Adv Cash EUR, you want to buy, into the form above the exchanges list, and click "Calculate".
<G-vec00166-002-s085><calculate.berechnen><de> Falls keines der Wechselbüros auf dieser Seite Ihre Nachfrage nach Reserven befriedigt, geben Sie die Menge an Wire Transfer EUR, die Sie kaufen möchten, in das Formular über der Wechselbüro-Liste ein und klicken Sie auf „Berechnen”.
<G-vec00166-002-s086><calculate.berechnen><en> In DIALux evo you can only calculate the part of the building whose view is currently selected in the "Fast" calculation mode (s. screenshot below).
<G-vec00166-002-s086><calculate.berechnen><de> In unserer DIALux evo-Software können Sie im Berechnungsmodus "Schnell" nur den Gebäudeteil berechnen lassen, dessen Ansicht gerade ausgewählt ist.
<G-vec00166-002-s087><calculate.berechnen><en> Highlights include the freeformOPT software that can be used to calculate individual free-form optics, as well as new laser processes for shaping, polishing, structuring and assembling fused silica optics.
<G-vec00166-002-s087><calculate.berechnen><de> Highlights sind beispielsweise die Software »freeformOPT«, mit der sich individuelle Freiformoptiken berechnen lassen, sowie neue Laserprozesse zur Formgebung, Politur, Strukturierung und Montage von Quarzglasoptiken.
<G-vec00166-002-s088><calculate.berechnen><en> It makes sense to have our experts calculate your options in order to optimize your repayments from a pension perspective as well.
<G-vec00166-002-s088><calculate.berechnen><de> Es lohnt sich, von Experten mögliche Varianten berechnen zu lassen, um die Amortisation auch vorsorgegerecht zu optimieren.
<G-vec00166-002-s089><calculate.berechnen><en> You can calculate the shipping costs in your shopping cart.
<G-vec00166-002-s089><calculate.berechnen><de> Die genauen Versandkosten können Sie in Ihrem Warenkorb berechnen lassen.
<G-vec00166-002-s090><calculate.berechnen><en> It is also possible to calculate and design a new lens according to your exact specifications.
<G-vec00166-002-s090><calculate.berechnen><de> Gerne sind wir auch bereit, von Grund auf neue Objektive nach Ihren Vorgaben berechnen und entwickeln zu lassen.
<G-vec00166-002-s091><calculate.berechnen><en> If you want to calculate the position and angle of the line based on the values in the chart, see Trendline.
<G-vec00166-002-s091><calculate.berechnen><de> Sie können die Position und den Winkel der Linie auch auf Basis der Werte im Diagramm berechnen lassen (siehe Trendlinie).
<G-vec00166-002-s092><calculate.berechnen><en> With this app you can even calculate the cooling or heating load of her house and get suitable equipment recommendations.
<G-vec00166-002-s092><calculate.berechnen><de> Mit dieser App können Sie selbst die Kühl- oder Heizlast ihres Hauses berechnen und sich passende Geräteempfehlungen anzeigen lassen.
<G-vec00166-002-s093><calculate.berechnen><en> On their homepage you can easily calculate your CO2 emissions, no matter if flight or cruise.
<G-vec00166-002-s093><calculate.berechnen><de> Auf der Homepage kannst Du Deinen CO2-Ausstoß ganz einfach berechnen lassen, egal ob Flug oder Kreuzfahrt.
<G-vec00166-002-s094><calculate.berechnen><en> Furthermore, thanks to Map24.de, you can use the following links to calculate the route from your home to us.
<G-vec00166-002-s094><calculate.berechnen><de> Weiterhin können Sie mit den nachfolgenden Links dank der Map24.de die Route von Ihrem Wohnort zu uns berechnen lassen.
<G-vec00166-002-s095><calculate.berechnen><en> You can enter the expected duration as part of a PERT analysis calculation, which takes a weighted average of expected, pessimistic, and optimistic dates and durations, or you can have Microsoft Office Project calculate it for you.
<G-vec00166-002-s095><calculate.berechnen><de> Sie können die pessimistische Dauer als Teil einer PERT-Analysenberechnung eingeben, die aus den realistischen, pessimistischen und optimistischen Terminen und Dauern einen gewichteten Mittelwert berechnet, oder Sie können diesen Wert von Microsoft Office Project berechnen lassen.
<G-vec00166-002-s096><calculate.berechnen><en> In the spreadsheet, you can choose from a wide selection of materials and finishes and calculate all multi-layer labels in completely free formats in real time for different printing processes.
<G-vec00166-002-s096><calculate.berechnen><de> In der Kalkulationsmaske können Sie aus einer großen Auswahl an Materialien und Veredelungen wählen und sich alle Multi-Layer-Etiketten in völlig freien Formaten in Echtzeit für verschiedene Druckverfahren berechnen lassen.
<G-vec00166-002-s097><calculate.berechnen><en> Use GPS tracking to calculate the covered area automatically.
<G-vec00166-002-s097><calculate.berechnen><de> GPS-Spuren aufzeichnen, um die bearbeitete Fläche automatisch berechnen zu lassen.
<G-vec00166-002-s098><calculate.berechnen><en> Now we have assigned Fokus Zukunft GmbH & Co. KG to calculate our remaining impact on the climate.
<G-vec00166-002-s098><calculate.berechnen><de> Nun haben wir unsere restlichen Klimabelastungen von der Fokus Zukunft GmbH & Co. KG berechnen lassen.
<G-vec00166-002-s099><calculate.berechnen><en> To calculate the optimal route for on Google Maps, the user merely has to press the button “Get Directions”, then enter departure and destination and then click on the little icon with the train.
<G-vec00166-002-s099><calculate.berechnen><de> Um die optimale Bahnverbindung für seine Reise von Google Maps berechnen zu lassen, braucht der Nutzer lediglich auf den Button „Get Directions“ zu drücken, anschließend Abfahrts- und Zielort einzugeben und dann auf das kleine Icon mit der Bahn zu klicken.
<G-vec00166-002-s100><calculate.berechnen><en> Using a running comparison between the position data and the time slot, manufacturing and trade companies can calculate the estimated time of arrival (ETA) exactly and check whether the truck will reach the loading dock on time, or whether another supplier can be squeezed in ahead.
<G-vec00166-002-s100><calculate.berechnen><de> Über den fortlaufenden Abgleich von Positionsdaten mit dem gebuchten Lieferzeitfenster können Unternehmen aus Industrie und Handel die „Estimated Time of Arrival“ (ETA) exakt berechnen und prüfen lassen, ob der LKW die Rampe pünktlich erreicht oder ein anderer Lieferant vorgezogen werden kann.
<G-vec00166-002-s101><calculate.berechnen><en> To get a larger map or to calculate your itinerary, please click below the map to "View Larger Map".
<G-vec00166-002-s101><calculate.berechnen><de> Um eine größere Kartenansicht zu erhalten oder Ihre Reiseroute berechnen zu lassen, klicken Sie bitte auf "Größere Karte ansehen".
<G-vec00166-002-s102><calculate.berechnen><en> Calculate the route by car, train, bus or by bike for to get to Steinhart Aquarium (California), with directions and the estimated travel time.
<G-vec00166-002-s102><calculate.berechnen><de> Wegbeschreibung nach Alterschwil Berechnen Sie die Route mit dem Auto, dem Zug, dem Bus oder dem Fahrrad, um nach Alterschwil zu gelangen, mit der Wegbeschreibung und der geschätzten Reisezeit.
<G-vec00166-002-s103><calculate.berechnen><en> Calculate the route for to Butler, OK starting from a different location.
<G-vec00166-002-s103><calculate.berechnen><de> Berechnen Sie die Route für Richland, OK ab einem anderen Ort.
<G-vec00166-002-s104><calculate.berechnen><en> Calculate the route for to Claysville, WV starting from a different location.
<G-vec00166-002-s104><calculate.berechnen><de> Berechnen Sie die Route für Binola, WV ab einem anderen Ort.
<G-vec00166-002-s105><calculate.berechnen><en> Calculate the surface area of different geometrical shapes
<G-vec00166-002-s105><calculate.berechnen><de> Berechnen Sie den Bereich von verschiedenen geometrischen Formen.
<G-vec00166-002-s106><calculate.berechnen><en> Calculate the route for to St. Patrick, OH starting from a different location.
<G-vec00166-002-s106><calculate.berechnen><de> Berechnen Sie die Route für St. Patrick, OH ab einem anderen Ort.
<G-vec00166-002-s107><calculate.berechnen><en> English Deutsch Français Español Italiano Português Nederlands Calculate the route by car, train, bus or by bike for to get to Acorn House B&B (Ireland), with directions and the estimated travel time.
<G-vec00166-002-s107><calculate.berechnen><de> Abfahrt von: Wegbeschreibung nach Alchenstorf Berechnen Sie die Route mit dem Auto, dem Zug, dem Bus oder dem Fahrrad, um nach Alchenstorf zu gelangen, mit der Wegbeschreibung und der geschätzten Reisezeit.
<G-vec00166-002-s108><calculate.berechnen><en> With an active-active shared-nothing cluster of 2 author instances, calculate the maximum throughput with a load profile where users perform a simple create page exercise on top of a base load of 300 existing pages, all of a similar nature.
<G-vec00166-002-s108><calculate.berechnen><de> Mit einem aktiv-aktiven Shared-Nothing-Cluster von 2 Autoreninstanzen berechnen Sie den maximalen Durchsatz mit einem Lastprofil, bei dem Benutzer eine einfache Seitenübung auf einer Grundlast von 300 vorhandenen Seiten durchführen, die alle von ähnlicher Art sind.
<G-vec00166-002-s109><calculate.berechnen><en> Find any address on the map of Kehl or calculate your itinerary from or to Kehl.
<G-vec00166-002-s109><calculate.berechnen><de> Routenplan Strassburg - Kehl Berechnen Sie Ihre Route von Strassburg nach Kehl schnell und einfach mit ViaMichelin.
<G-vec00166-002-s110><calculate.berechnen><en> Find any address on the map of Amersfoort or calculate your itinerary to and from Amersfoort, find all the tourist attractions and Michelin Guide restaurants in Amersfoort.
<G-vec00166-002-s110><calculate.berechnen><de> Finden Sie auf der Karte von Hilversum eine gesuchte Adresse, berechnen Sie die Route von oder nach Hilversum oder lassen Sie sich alle Sehenswürdigkeiten und Restaurants aus dem Guide Michelin in oder um Hilversum anzeigen.
<G-vec00166-002-s111><calculate.berechnen><en> Calculate the route for to Glen Aubrey, NY starting from a different location.
<G-vec00166-002-s111><calculate.berechnen><de> Berechnen Sie die Route für Fergus, CA ab einem anderen Ort.
<G-vec00166-002-s112><calculate.berechnen><en> Important: calculate the necessary amount of paper needed + additiona 10%
<G-vec00166-002-s112><calculate.berechnen><de> Wichtig: Berechnen Sie die benötigte Papiermenge + 10% zusätzlich.
<G-vec00166-002-s113><calculate.berechnen><en> Calculate the true costs of financing a long-distance supply chain and compare against sourcing locally.
<G-vec00166-002-s113><calculate.berechnen><de> Berechnen Sie die tatsächlichen Kosten der Finanzierung einer Langstrecken-Lieferkette und vergleichen Sie diese mit einem Einkauf vor Ort.
<G-vec00166-002-s114><calculate.berechnen><en> Calculate the route for to Higginsville, MO starting from a different location.
<G-vec00166-002-s114><calculate.berechnen><de> Berechnen Sie die Route für Lakeshire, MO ab einem anderen Ort.
<G-vec00166-002-s115><calculate.berechnen><en> Calculate the route by car, train, bus or by bike for to get to Overlook Castle (North Carolina), with directions and the estimated travel time.
<G-vec00166-002-s115><calculate.berechnen><de> Wegbeschreibung nach Altdorf Berechnen Sie die Route mit dem Auto, dem Zug, dem Bus oder dem Fahrrad, um nach Altdorf zu gelangen, mit der Wegbeschreibung und der geschätzten Reisezeit.
<G-vec00166-002-s116><calculate.berechnen><en> Calculate the route for to Figarden, CA starting from a different location.
<G-vec00166-002-s116><calculate.berechnen><de> Berechnen Sie die Route für Three Rocks, CA ab einem anderen Ort.
<G-vec00166-002-s117><calculate.berechnen><en> Calculate the route for to Cedar Creek (Bastrop County), TX starting from a different location.
<G-vec00166-002-s117><calculate.berechnen><de> Berechnen Sie die Route für Cedar Mill, CA ab einem anderen Ort.
<G-vec00166-002-s118><calculate.berechnen><en> Calculate the route for to Red Hill, WV starting from a different location.
<G-vec00166-002-s118><calculate.berechnen><de> Berechnen Sie die Route für Red Creek, WV ab einem anderen Ort.
<G-vec00166-002-s119><calculate.berechnen><en> Calculate the route for to Sleeth, IN starting from a different location.
<G-vec00166-002-s119><calculate.berechnen><de> Berechnen Sie die Route für Humboldt, IA ab einem anderen Ort.
<G-vec00166-002-s120><calculate.berechnen><en> Calculate the route for to Hawkinsville, GA starting from a different location.
<G-vec00166-002-s120><calculate.berechnen><de> Berechnen Sie die Route für Cohasset, MN ab einem anderen Ort.
<G-vec00166-002-s121><calculate.berechnen><en> And this is where the trouble starts for the medical scientist has been trained to solder, weld, work glass, calculate complex circuits, lay cables, or plan facilities.
<G-vec00166-002-s121><calculate.berechnen><de> Denn wie man lötet, schweißt und Glas bearbeitet, komplexe Schaltungen berechnet, Leitungen verlegt oder Anlagen plant, hat kaum ein Physiker, Chemiker, Biologe oder Mediziner in der Ausbildung gelernt.
<G-vec00166-002-s122><calculate.berechnen><en> Also there is an overall GPA, which is calculate from all your courses.
<G-vec00166-002-s122><calculate.berechnen><de> Außerdem gibt es einen Gesamtdurchschnitt, der von allen angegebenen Kursen berechnet wird.
<G-vec00166-002-s123><calculate.berechnen><en> Gimp doesn't calculate the correct size of Heap Buffers when processing PSD images.
<G-vec00166-002-s123><calculate.berechnen><de> Bei der Verarbeitung von PSD-Dateien berechnet Gimp die Größe des Heap-Puffers nicht immer korrekt.
<G-vec00166-002-s124><calculate.berechnen><en> In these results, Minitab uses the conditional equation and the marginal equation obtained from the stored model to calculate the two types of fits.
<G-vec00166-002-s124><calculate.berechnen><de> In diesen Ergebnissen berechnet Minitab die zwei Arten der Anpassung anhand der Gleichung für die bedingten Anpassungen und der Gleichung für die Randanpassungen, die aus dem gespeicherten Modell abgeleitet wurden.
<G-vec00166-002-s125><calculate.berechnen><en> The California Institute of Technology has used 3D simulations to calculate which .
<G-vec00166-002-s125><calculate.berechnen><de> Das California Institute of Technology hat anhand von 3D-Simulationen berechnet, welche möglich wären.
<G-vec00166-002-s126><calculate.berechnen><en> It was thus possible to calculate and analyze the savings potential for various different processes.
<G-vec00166-002-s126><calculate.berechnen><de> So konnte das Einsparpotential für verschiedene Prozesse berechnet und analysiert werden.
<G-vec00166-002-s127><calculate.berechnen><en> While it might take a raster image 1000 pixels to show the length of a line from point A to point B, a vector graphic of the same line would just plot the two end points and calculate the distance between them to draw the line.
<G-vec00166-002-s127><calculate.berechnen><de> Der Unterschied zwischen einer Vektorgrafik und einem Rasterbild ist einfach erklärt: Während ein Rasterbild 1.000 Pixel benötigt, um die Länge einer Linie von Punkt A zu Punkt B darzustellen, zeichnet eine Vektorgrafik lediglich die beiden Endpunkte und berechnet den Abstand zwischen beiden, um diesen als Linie abzubilden.
<G-vec00166-002-s128><calculate.berechnen><en> Let us now consider the method Meyer used to calculate the total number of Auschwitz victims.
<G-vec00166-002-s128><calculate.berechnen><de> Betrachten wir nun, wie Meyer die Gesamtopferzahl berechnet.
<G-vec00166-002-s129><calculate.berechnen><en> Please, also refer to this instruction for manual setup in our Help Portal to configure your Ecwid store to calculate tax rates for different regions, zones, and countries.
<G-vec00166-002-s129><calculate.berechnen><de> Bitte beachten Sie auch diese Anleitung zur manuellen Einrichtung in unserem Hilfeportal, um Ihren Ecwid-Store so zu konfigurieren, dass er Steuersätze für verschiedene Regionen, Zonen und Länder berechnet.
<G-vec00166-002-s130><calculate.berechnen><en> The pipeline uses image-to-image motion estimation to calculate the camera trajectory.
<G-vec00166-002-s130><calculate.berechnen><de> Das System berechnet die Bild-zu-Bild-Bewegung der Kamera und bildet daraus die Kameratrajektorie.
<G-vec00166-002-s131><calculate.berechnen><en> Give 20 cm as an extra for the knot and calculate in each case the necessary length of the cord.
<G-vec00166-002-s131><calculate.berechnen><de> Gebt noch 20 cm (insgesamt) für die Knoten hinzu und berechnet die jeweils benötigte Schnurlänge.
<G-vec00166-002-s132><calculate.berechnen><en> Collision detection based on spatial partitioning is used to calculate the forces that are acting on the deformable model.
<G-vec00166-002-s132><calculate.berechnen><de> Mithilfe einer Kollisionserkennung, basierend auf räumlicher Unterteilung, werden die Kräfte berechnet, die auf das verformbare Modell wirken.
<G-vec00166-002-s133><calculate.berechnen><en> If the customer states one colour only in the enquiry the seller will calculate the price as for using black.
<G-vec00166-002-s133><calculate.berechnen><de> Wenn der Kunde in der Anfrage nur eine Farbe angibt, berechnet der Verkäufer den Preis für einen Schwarz-Weiß-Druck.
<G-vec00166-002-s134><calculate.berechnen><en> The program will calculate for both objective and eyepiece the angles between the rays of light and the optical axis (marked with blue and green colour) and the magnification.
<G-vec00166-002-s134><calculate.berechnen><de> Das Programm berechnet jeweils die Größe der Sehwinkel an Objektiv und Okular (farbig gekennzeichnet) sowie den Vergrößerungsfaktor.
<G-vec00166-002-s135><calculate.berechnen><en> Leather stiffness tester machine is used to measure the stiffness in the longitudinal direction of steel shanks used for the reinforcement of the waist region of shoes,the shank is clamped at its heel end and bent as a cantilever beam by masses added to its forward,then calculate the flexural rigidity of the shank.
<G-vec00166-002-s135><calculate.berechnen><de> Lederne Steifheitsprüfvorrichtungsmaschine wird benutzt, um die Steifheit in der Längsrichtung von den Stahlschäften zu messen, die für die Verstärkung der Taillenregion der Schuhe benutzt werden, wird der Schaft an seinem Kanten festgeklemmt und Biegung als Kragträger durch Massen fügte seinem Vorwärts hinzu, dann berechnet die Biegesteifigkeit des Schaftes.
<G-vec00166-002-s136><calculate.berechnen><en> TechnoAlpin uses plans to calculate the volume of the reservoir in cubic meters. This is done both at the beginning of the season when still full, and again halfway through the season, after having covered part of the resort with snow.
<G-vec00166-002-s136><calculate.berechnen><de> TechnoAlpin berechnet die vorhandenen Kubikmeter in den Speicherteichen sowohl zu Beginn der Saison, wenn diese noch gefüllt sind, als auch zur Saisonmitte, wenn ein Teil des Gebiets bereits beschneit wurde.
<G-vec00166-002-s137><calculate.berechnen><en> At step S62, the control section 301 of the recording and reproducing device 300 causes the recording and reproducing device cryptography process section 302 of the recording and reproducing device 300 to calculate the integrity check value unique to the recording and reproducing device 300.
<G-vec00166-002-s137><calculate.berechnen><de> Im Schritt S62 veranlasst der Steuerabschnitt In step S62, the control portion causes 301 301 der Aufzeichnungs- und Wiedergabeeinrichtung the recording and playback device 300 300, dass der Aufzeichnungs- und Wiedergabeeinrichtungs-Kryptographieprozessabschnitt der Aufzeichnungs- und Wiedergabeeinrichtung the recording and playback device 300 300 den Integritätsprüfwert berechnet, der für die Aufzeichnungs- und Wiedergabeeinrichtung einzig ist.
<G-vec00166-002-s138><calculate.berechnen><en> It is used to calculate the principal payment for an investment based on a specified interest rate and a constant payment schedule.
<G-vec00166-002-s138><calculate.berechnen><de> Sie berechnet die aufgelaufene Tilgung eines Darlehens, die zwischen zwei Perioden zu zahlen ist, basierend auf einem festgelegten Zinssatz und einem konstanten Zahlungsplan.
<G-vec00166-002-s139><calculate.berechnen><en> Simply drag and drop a file to the window and it will calculate the Md5 sum in seconds.
<G-vec00166-002-s139><calculate.berechnen><de> Wenn Sie eine Datei per "drag and drop" über das winMd5Sum Portable Fenster ziehen, berechnet das Programm innert Sekunden die MD5 Summe.
<G-vec00166-002-s374><calculate.berechnen><en> Knowing these parameters, we may use Ohm's law to calculate the powering range.
<G-vec00166-002-s374><calculate.berechnen><de> Wenn Sie diese Werte kennen, können Sie die Spannungsreichweite berechnen.
<G-vec00166-002-s375><calculate.berechnen><en> According to the data presented above, you can easily find out how to calculate the number of cubes, boards and even square meters required for construction or repair, but some sellers still find tricks and profit from the ignorance of customers.
<G-vec00166-002-s375><calculate.berechnen><de> Anhand der oben genannten Daten können Sie leicht herausfinden, wie Sie die Anzahl der benötigten Würfel, Bretter und sogar Quadratmeter für den Bau oder die Reparatur berechnen, aber einige Verkäufer finden immer noch Tricks und profitieren von der Ignoranz der Kunden.
<G-vec00166-002-s376><calculate.berechnen><en> Calculate your net taxable earned income with the KBC Tax Planner.
<G-vec00166-002-s376><calculate.berechnen><de> Das netto zu besteuernde Arbeitseinkommen können Sie mit unserem Taxplanner (französische Fassung) berechnen.
<G-vec00166-002-s377><calculate.berechnen><en> Optimizing routes infoWith 'route optimization' Tyre can calculate the most efficient route between multiple waypoints.
<G-vec00166-002-s377><calculate.berechnen><de> Routen Optimieren infoTyre kann mit `Routen optimieren` die effizienteste Route für Sie zwischen mehreren Wegmarken berechnen.
<G-vec00166-002-s378><calculate.berechnen><en> How to calculate your BMI
<G-vec00166-002-s378><calculate.berechnen><de> Hier können Sie Ihren BMI berechnen.
<G-vec00166-002-s379><calculate.berechnen><en> To calculate the exact focal length you need for a specific camera location, use our online tool.
<G-vec00166-002-s379><calculate.berechnen><de> Verwenden Sie unser Online-Tool, um die genaue Brennweite zu berechnen, die Sie für einen bestimmten Kameraplatz benötigen.
<G-vec00166-002-s380><calculate.berechnen><en> • Weight: Keep your weight gain in the eye and let calculate your BMI.
<G-vec00166-002-s380><calculate.berechnen><de> • Gewicht: Behalten Sie Ihre Gewichtsentwicklung im Auge und lassen Sie Ihren BMI berechnen.
<G-vec00166-002-s381><calculate.berechnen><en> Quickly calculate your personal rate in KBC Touch.
<G-vec00166-002-s381><calculate.berechnen><de> In Touch können Sie schnell Ihren persönlichen Tarif berechnen.
<G-vec00166-002-s382><calculate.berechnen><en> This article tells how to calculate and buy the necessary material and tools and how to change old pipes to new ones.
<G-vec00166-002-s382><calculate.berechnen><de> In diesem Artikel erfahren Sie, wie Sie das erforderliche Material und die erforderlichen Werkzeuge berechnen und kaufen und wie Sie alte Rohre zu neuen ersetzen.
<G-vec00166-002-s383><calculate.berechnen><en> And this is not something to be idly discarded, since after all the text does urge us to calculate in this way.
<G-vec00166-002-s383><calculate.berechnen><de> Und dies ist auch durchaus nichts Verwerfliches, fordert uns ja der Text auf, sie zu berechnen.
<G-vec00166-002-s384><calculate.berechnen><en> Come and have a chat with us: our colleagues at our various centers will be happy to calculate the buy-back value of the vehicle of your Deutsch
<G-vec00166-002-s384><calculate.berechnen><de> Sprechen Sie uns an: Unsere Mitarbeiter an unseren Standorten werden Ihnen gerne den Rück-Kaufwert für das Fahrzeug Ihrer Wahl berechnen.
<G-vec00166-002-s385><calculate.berechnen><en> Throughout this article, we’ve illuminated a plethora of information on pot odds – what they are, the different types there are, how to calculate them, how to calculate your chances of improving, and how to relate these two figures together.
<G-vec00166-002-s385><calculate.berechnen><de> In diesem Artikel haben wir eine Fülle von Informationen zum Thema Pot Odds gegeben – was dies bedeutet, welche verschiedenen Arten es gibt, wie sie berechnet werden, wie Sie Ihre Verbesserungschancen berechnen, und wie Sie diese beiden Zahlen miteinander in Beziehung setzen.
<G-vec00166-002-s386><calculate.berechnen><en> Use formatting and formula editing so that you can calculate results and make your data look the way you'd like.
<G-vec00166-002-s386><calculate.berechnen><de> Formatieren Sie Zellen und verwenden Sie Formeln, um Ergebnisse zu berechnen und die Daten entsprechend Ihren Wünschen zu präsentieren.
<G-vec00166-002-s387><calculate.berechnen><en> Landmarks in the patient’s anatomy are used to calculate placement, enabling practically error-free patient positioning and dramatically reducing the need for retakes.
<G-vec00166-002-s387><calculate.berechnen><de> Sie verwendet anatomische Orientierungspunkte des Patienten, um die Platzierung zu berechnen, was eine praktisch fehlerfreie Patientenpositionierung ermöglicht und die Notwendigkeit für Wiederholungsaufnahmen deutlich reduziert.
<G-vec00166-002-s388><calculate.berechnen><en> You will be able to classify the different costs and anticipate bills or calculate EnPI's.
<G-vec00166-002-s388><calculate.berechnen><de> So können Sie die verschiedenen Kosten auseinandernehmen, der Rechnung zuvorkommen oder EnPIs berechnen.
<G-vec00166-002-s389><calculate.berechnen><en> The DaysDiff Heater makes it possible to calculate the difference between two date and/or time fields.
<G-vec00166-002-s389><calculate.berechnen><de> Mit dem DaysDiff Heater können Sie sich die Differenz von zwei Datums und/oder Zeitangaben berechnen lassen.
<G-vec00166-002-s390><calculate.berechnen><en> I have said to you that the number of spirits chosen for this delicate mission is infinite, that you cannot calculate, or imagine.
<G-vec00166-002-s390><calculate.berechnen><de> Ich habe euch gesagt, dass die Zahl der für diese schwierige Aufgabe gekennzeichneten Geister unendlich ist, ihr könnt sie nicht berechnen noch euch vorstellen.
<G-vec00166-002-s391><calculate.berechnen><en> Building information models, as known in the construction industry, are used to automatically calculate flight paths for unmanned aerial vehicles in order to facilitate efficient visual inspections of buildings.
<G-vec00166-002-s391><calculate.berechnen><de> Bauwerksinformationsmodelle, wie sie aus dem Bauwesen bekannt sind, werden verwendet, um automatisch Flugrouten für unbemannte Fluggeräte zu berechnen und so visuelle Inspektionen von Bauwerken effizienter und kostengünstiger zu gestalten.
<G-vec00166-002-s392><calculate.berechnen><en> Learn how to calculate home field advantage.
<G-vec00166-002-s392><calculate.berechnen><de> Erfahren Sie, wie Sie den Heimvorteil berechnen.
<G-vec00166-002-s393><calculate.berechnen><en> We have a fantastic tool to convert Djibouti time zone and calculate time difference between Djibouti and other cities.
<G-vec00166-002-s393><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Los Angeleser Zeitzone konvertiert und Zeitunterschiede zwischen Los Angeles und anderen Städten berechnet.
<G-vec00166-002-s394><calculate.berechnen><en> We have a fantastic tool to convert Tunisia time zone and calculate time difference between Tunisia and other cities.
<G-vec00166-002-s394><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Sowetoer Zeitzone konvertiert und Zeitunterschiede zwischen Soweto und anderen Städten berechnet.
<G-vec00166-002-s395><calculate.berechnen><en> We have a fantastic tool to convert Neuquen time zone and calculate time difference between Neuquen and other cities.
<G-vec00166-002-s395><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Aigaleoer Zeitzone konvertiert und Zeitunterschiede zwischen Aigaleo und anderen Städten berechnet.
<G-vec00166-002-s396><calculate.berechnen><en> We have a fantastic tool to convert Toowoomba time zone and calculate time difference between Toowoomba and other cities.
<G-vec00166-002-s396><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Chamonixer Zeitzone konvertiert und Zeitunterschiede zwischen Chamonix und anderen Städten berechnet.
<G-vec00166-002-s398><calculate.berechnen><en> We have a fantastic tool to convert Coromandel time zone and calculate time difference between Coromandel and other cities.
<G-vec00166-002-s398><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Zaragozaer Zeitzone konvertiert und Zeitunterschiede zwischen Zaragoza und anderen Städten berechnet.
<G-vec00166-002-s399><calculate.berechnen><en> We have a fantastic tool to convert Zambia time zone and calculate time difference between Zambia and other cities.
<G-vec00166-002-s399><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Oklahoma Cityer Zeitzone konvertiert und Zeitunterschiede zwischen Oklahoma City und anderen Städten berechnet.
<G-vec00166-002-s401><calculate.berechnen><en> We have a fantastic tool to convert Ecuador time zone and calculate time difference between Ecuador and other cities.
<G-vec00166-002-s401><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Österreicher Zeitzone konvertiert und Zeitunterschiede zwischen Österreich und anderen Städten berechnet.
<G-vec00166-002-s402><calculate.berechnen><en> We have a fantastic tool to convert Missouri time zone and calculate time difference between Missouri and other cities.
<G-vec00166-002-s402><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Vermonter Zeitzone konvertiert und Zeitunterschiede zwischen Vermont und anderen Städten berechnet.
<G-vec00166-002-s404><calculate.berechnen><en> We have a fantastic tool to convert Massachusetts time zone and calculate time difference between Massachusetts and other cities.
<G-vec00166-002-s404><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Massachusettser Zeitzone konvertiert und Zeitunterschiede zwischen Massachusetts und anderen Städten berechnet.
<G-vec00166-002-s405><calculate.berechnen><en> We have a fantastic tool to convert Comoros time zone and calculate time difference between Comoros and other cities.
<G-vec00166-002-s405><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Amalfier Zeitzone konvertiert und Zeitunterschiede zwischen Amalfi und anderen Städten berechnet.
<G-vec00166-002-s406><calculate.berechnen><en> We have a fantastic tool to convert Palmerston North time zone and calculate time difference between Palmerston North and other cities.
<G-vec00166-002-s406><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Mesaer Zeitzone konvertiert und Zeitunterschiede zwischen Mesa und anderen Städten berechnet.
<G-vec00166-002-s407><calculate.berechnen><en> We have a fantastic tool to convert Malawi time zone and calculate time difference between Malawi and other cities.
<G-vec00166-002-s407><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Japaner Zeitzone konvertiert und Zeitunterschiede zwischen Japan und anderen Städten berechnet.
<G-vec00166-002-s408><calculate.berechnen><en> We have a fantastic tool to convert Mississippi time zone and calculate time difference between Mississippi and other cities.
<G-vec00166-002-s408><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Neuseelander Zeitzone konvertiert und Zeitunterschiede zwischen Neuseeland und anderen Städten berechnet.
<G-vec00166-002-s410><calculate.berechnen><en> We have a fantastic tool to convert Wisconsin time zone and calculate time difference between Wisconsin and other cities.
<G-vec00166-002-s410><calculate.berechnen><de> Wir haben ein fantastisches Tool das die Niederlandeer Zeitzone konvertiert und Zeitunterschiede zwischen Niederlande und anderen Städten berechnet.
<G-vec00166-002-s213><calculate.errechnen><en> The vehicle will use sensors to identify its surroundings, calculate the best possible path of travel, and then independently perform complex maneuvers.
<G-vec00166-002-s213><calculate.errechnen><de> Das Fahrzeug wird mit Sensoren das Umfeld erkennen, den bestmöglichen Fahrweg errechnen und dann komplexe Manöver eigenständig ausführen können.
<G-vec00166-002-s214><calculate.errechnen><en> As a result, it is easier to make decisions directly related to the operation of a vehicle and its servicing and calculate operating costs.
<G-vec00166-002-s214><calculate.errechnen><de> Dank dieser Lösungen ist es einfacher Entscheidungen, die direkt mit der Nutzung des Fahrzeuges und dessen Service verbunden sind, zu treffen, als auch die Nutzungskosten zu errechnen.
<G-vec00166-002-s215><calculate.errechnen><en> ROI Calculator: With the ROI Calculator, you calculate the expected savings and the ROI that your company could achieve by using our solutions.
<G-vec00166-002-s215><calculate.errechnen><de> ROI Calculator: Mit dem ROI Calculator errechnen Sie die zu erwartenden Einsparungen und den ROI, die Ihr Unternehmen durch die Verwendung unserer Lösungen entstehen könnten.
<G-vec00166-002-s216><calculate.errechnen><en> This happens today, of course, with the help of computers, which can calculate hundreds of billions of keys per second – this method is called “brute force”.
<G-vec00166-002-s216><calculate.errechnen><de> Das passiert heute natürlich mit Hilfe von Computern, die hunderte Milliarden von Schlüsseln pro Sekunde errechnen können – diese „brutale“ Methode wird „Brute Force“ („nackte Gewalt“) genannt.
<G-vec00166-002-s217><calculate.errechnen><en> Fields marked with an asterisk are compulsory in order to calculate an effective sales price for your PV system.
<G-vec00166-002-s217><calculate.errechnen><de> Bei den mit einem blauen Sternchen gekennzeichneten Feldern handelt es sich um Pflichteingabefelder, die in jedem Fall nötig sind, um den Verkaufswert der Photovoltaikanlage zu errechnen.
<G-vec00166-002-s218><calculate.errechnen><en> If it is now assumed that this pattern will not change in the future, the current valuations of both indicators can be used to calculate what investors in the various markets can expect to earn in the long term with a high degree of probability (table below).
<G-vec00166-002-s218><calculate.errechnen><de> Wird nun angenommen, dass sich dieses Muster auch in Zukunft nicht ändert, lässt sich aus den aktuellen Bewertungen beider Indikatoren errechnen, was Anleger in den verschiedenen Märkten langfristig mit hoher Wahrscheinlichkeit an Rendite erwarten können (Tabelle unten).
<G-vec00166-002-s219><calculate.errechnen><en> As a basic data you should enter your year of birth and size, because the app needs these dates to calculate later values like the BMI.
<G-vec00166-002-s219><calculate.errechnen><de> Als Basisdaten sollte man dann schon einmal sein Geburtsjahr und die Größe eingeben, da die App diese benötigt um später Werte wie den BMI zu errechnen.
<G-vec00166-002-s220><calculate.errechnen><en> That brings the keyword advertiser in the position to calculate an optimal click price for every keyword based on the conversion, which is generated through this keyword and the money being paid for the sale or lead.
<G-vec00166-002-s220><calculate.errechnen><de> Das versetzt den Keyword Einbucher in die Lage, für jedes unterschiedliche Keyword einen optimalen Klickpreis errechnen zu können aufgrund der Conversion, die über dieses Keyword generiert wird und anhand der Verdiensthöhe, die für einen Sale oder Lead bezahlt wird.
<G-vec00166-002-s221><calculate.errechnen><en> It uses track durations or file names to calculate the level of similarity in percent.
<G-vec00166-002-s221><calculate.errechnen><de> Dazu werden die Längen oder die Dateinamen verglichen um den Grad an Übereinstimmung in Prozent zu errechnen.
<G-vec00166-002-s222><calculate.errechnen><en> While your SERP ranking is not really a metric that you can calculate, it is one of the clearest indicators of how well your content is performing.
<G-vec00166-002-s222><calculate.errechnen><de> Das SERP-Ranking ist zwar keine Kennzahl, die sich errechnen lässt, dennoch ist sie ein klarer Indikator für die Leistung Deiner Inhalte.
<G-vec00166-002-s223><calculate.errechnen><en> To calculate, just type or paste any text with numbers into the field and press Calculate digit sums.
<G-vec00166-002-s223><calculate.errechnen><de> Zum Errechnen einfach eine Zahl oder einen beliebigen Text mit Zahlen in das Feld eingeben oder kopieren und auf Quersummen ermitteln klicken.
<G-vec00166-002-s224><calculate.errechnen><en> Time rulers placed at subsequent missing teeth of the pick-up ring allow PicoScope to calculate the frequency of 1 full cycle (revolution) of the crankshaft.
<G-vec00166-002-s224><calculate.errechnen><de> Zeitlineale, die auf nachfolgend fehlenden Zähnen des Impulsgeberrads platziert werden, ermöglichen es dem PicoScope, die Frequenz eines vollständigen Takts (Umdrehung) der Kurbelwelle zu errechnen.
<G-vec00166-002-s225><calculate.errechnen><en> To calculate the winnings for a bet multiply the bet amount by the corresponding decimal odds
<G-vec00166-002-s225><calculate.errechnen><de> Um den Gewinn aus einer Wette zu errechnen, multiplizieren Sie den Wettbetrag mit der entsprechenden Dezimalquote.
<G-vec00166-002-s226><calculate.errechnen><en> In order to calculate the blood volume, the MVD was multiplied by the mean vessel diameter of the capillaries, according to the literature of 8 µm.
<G-vec00166-002-s226><calculate.errechnen><de> Um das Blutvolumen zu errechnen, wurde die MVD mit dem mittleren Gefäßdurchmesser der Kapillaren laut Literatur von 8 µm multipliziert.
<G-vec00166-002-s227><calculate.errechnen><en> In order to calculate the standard line price the number of keystrokes is divided by 55.
<G-vec00166-002-s227><calculate.errechnen><de> Um den Normzeilenpreis errechnen zu können, werden die gezählten Anschläge durch 55 geteilt.
<G-vec00166-002-s228><calculate.errechnen><en> While the angle of elevation methods, if used correctly, can calculate the correct height within 2-3 feet, there is abundant opportunity for human error, especially if the tree is angled or on a slope.
<G-vec00166-002-s228><calculate.errechnen><de> Während der Winkel der Methoden bei Bodenerhebungen, wenn sie korrekt angewendet werden, die korrekte Höhe des Baumes bis zu 60 – 90 cm errechnen können, gibt es doch viele Möglichkeiten für menschlichen Irrtum, besonders wenn der Baum im Winkel liegt oder auf einem Gefälle steht.
<G-vec00166-002-s229><calculate.errechnen><en> Whether you create your own storm in a glass or calculate the savings potential of your household: the “green corner” in the Aquademie offers a great deal for you to learn about, be astounded at and get hands-on with.
<G-vec00166-002-s229><calculate.errechnen><de> Ob Sie selbst einen Sturm im Wasserglas erzeugen oder Ihr persönliches Einsparpotenzial im Haushalt errechnen: In der „grünen Ecke“ der Aquademie gibt’s eine Menge zu lernen, zu staunen – und alle Hände voll zu tun.
<G-vec00166-002-s230><calculate.errechnen><en> You can calculate the whole size of your cover with Lulu.
<G-vec00166-002-s230><calculate.errechnen><de> Man kann die gesamte Größe des eigenen Covers bei Lulu errechnen.
<G-vec00166-002-s231><calculate.errechnen><en> In the first line you can also see the wattage each JBL LED light consumes and you can calculate the electricity savings compared to the wattage of your previous
<G-vec00166-002-s231><calculate.errechnen><de> In der ersten Zeile sehen Sie auch, wie viel Watt eine JBL LED-Lampe verbraucht und können im Vergleich zur Wattzahl der bisherigen Leuchtstofflampe die Stromeinsparung errechnen.
<G-vec00166-002-s251><calculate.kalkulieren><en> Create a financing plan to calculate the costs and revenues of your event.
<G-vec00166-002-s251><calculate.kalkulieren><de> Stellen Sie einen Finanzierungsplan auf, um die Kosten und Einnahmen für Ihre Veranstaltung zu kalkulieren.
<G-vec00166-002-s252><calculate.kalkulieren><en> After a discussion of what you budget is, we will calculate a budget distribution.
<G-vec00166-002-s252><calculate.kalkulieren><de> Budgetkalkulation und Verwaltung Nach der Vorgabe Ihres Budgets, kalkulieren wir eine erste Budgetverteilung.
<G-vec00166-002-s253><calculate.kalkulieren><en> Check your website/domain on webisworth.com (Open webisworth.com home page and write your website/domain name then click "Calculate").
<G-vec00166-002-s253><calculate.kalkulieren><de> Überprüfen Sie Ihre Webseite/Domain auf webisworth.com (öffnen Sie unsere webisworth.com Webseite,tragen Sie Ihren Webseiten-/Domainnamen ein und drücken auf "Kalkulieren").
<G-vec00166-002-s254><calculate.kalkulieren><en> We must not take anything with us – no backpack heavy with expectations, not too many buttons and cables encompassing our senses, and presumably neither should we calculate what we will experience and “take home with us” from distant places.
<G-vec00166-002-s254><calculate.kalkulieren><de> Wir dürfen nichts mit uns nehmen – keinen zu schweren Rucksack an Erwartungen, nicht zu viele Knöpfe und Kabel um unsere Sinne, und vermutlich sollten wir auch nicht kalkulieren, was wir an den fernen Orten erfahren und »mitnehmen« werden.
<G-vec00166-002-s255><calculate.kalkulieren><en> A drinking protocol can help to better calculate the amount of liquid consumed.
<G-vec00166-002-s255><calculate.kalkulieren><de> Ein Trinkprotokoll kann helfen, die Trinkmenge besser zu kalkulieren.
<G-vec00166-002-s256><calculate.kalkulieren><en> With the scenario analyser you can calculate potential outcomes of the next street(s), calculate river cards and calculate outcomes against multiple ranges.
<G-vec00166-002-s256><calculate.kalkulieren><de> Mit der Szenario-Analyse kannst du potenzielle Ergebnisse von nachfolgenden Streets kalkulieren, Riverkarten berechnen und Ergebnisse gegen mehrere Ranges ermitteln.
<G-vec00166-002-s257><calculate.kalkulieren><en> For an extensive zoo, a footpath is to calculate 15 minutes.
<G-vec00166-002-s257><calculate.kalkulieren><de> Für einen ausgedehnten Zoobesuch ist ein Fußweg von 15 Minuten zu kalkulieren.
<G-vec00166-002-s258><calculate.kalkulieren><en> The intuitive business processors in the cloud calculate and display the most pertinent information in a summary report on the dashboard homepage.
<G-vec00166-002-s258><calculate.kalkulieren><de> Die intuitiven Business-Prozessoren in der Cloud kalkulieren und zeigen die wichtigsten Informationen in einem zusammenfassenden Bericht auf der Dashboard-Startseite an.
<G-vec00166-002-s259><calculate.kalkulieren><en> If you have a task that requires more than your dedicated monthly time, we will calculate a separate offer for you.
<G-vec00166-002-s259><calculate.kalkulieren><de> Wenn Sie eine Aufgabe haben, die mehr als Ihre dedizierte monatliche Zeit erfordert, werden wir ein separates Angebot für Sie kalkulieren.
<G-vec00166-002-s260><calculate.kalkulieren><en> With the budget planer you can calculate the main costs of your trade fair participation within a few steps. Stand design advice
<G-vec00166-002-s260><calculate.kalkulieren><de> Mit unserem Budgetplaner kalkulieren Sie in nur fünf Schritten die wichtigsten flächenbezogenen Kosten Ihrer Messebeteiligung auf der BAU.
<G-vec00166-002-s261><calculate.kalkulieren><en> That is, there is an influence to our choices that we cannot calculate.
<G-vec00166-002-s261><calculate.kalkulieren><de> Das heißt, dass es einen Einfluss auf deine Entscheidungen gibt, die wir nicht kalkulieren können.
<G-vec00166-002-s262><calculate.kalkulieren><en> We calculate fixed prices that remain stable even with minor changes.
<G-vec00166-002-s262><calculate.kalkulieren><de> Wir kalkulieren Festpreise, die auch bei kleineren Änderungen stabil bleiben.
<G-vec00166-002-s263><calculate.kalkulieren><en> Tourism management personnel in Travel Planning plan, organise and calculate package holidays, personal trips, tours as well as group and special trips.
<G-vec00166-002-s263><calculate.kalkulieren><de> Tourismuskaufleute in der Reiseveranstaltung planen, gestalten und kalkulieren Pauschalreisen, individuelle Reisen, Rundreisen sowie Gruppen- und Sonderreisen.
<G-vec00166-002-s264><calculate.kalkulieren><en> The important thing is to calculate exactly how the individual investment can best be integrated into the ongoing production process.
<G-vec00166-002-s264><calculate.kalkulieren><de> Entscheidend ist, genau zu kalkulieren, wie das jeweilige Investitionsobjekt bestmöglich in den laufenden Produktionsprozess integriert werden kann.
<G-vec00166-002-s265><calculate.kalkulieren><en> Since we do not have a large marketing and sales machinery, we can calculate a really good price for the excellent quality of the products.
<G-vec00166-002-s265><calculate.kalkulieren><de> Da wir dabei auf eine große Marketing- und Vertriebsmaschinerie verzichten, können wir für die ausgezeichnete Qualität der Produkte einen richtig guten Preis kalkulieren.
<G-vec00166-002-s266><calculate.kalkulieren><en> With the help of our online configuration tool you can calculate in few steps your printing order, making it easy to create informative pamphlets for clubs, customers or employers.
<G-vec00166-002-s266><calculate.kalkulieren><de> Perforation Ohne unseres Online-Konfigurators können Sie ganz einfach in wenigen Schritten Ihren Druckauftrag bequem online kalkulieren und informative Vereinshefte sowie Hefte für Ihre Kunden oder Mitarbeiter erstellen.
<G-vec00166-002-s267><calculate.kalkulieren><en> In order for the site to calculate the price of transfer from Salzburg Airport to the hotel Seelos to Seefeld in Tirol and back, you need to select the arrival date, number of adults and children, as well as vehicle options.
<G-vec00166-002-s267><calculate.kalkulieren><de> Damit die Webseite den Transferpreis kalkulieren kann von Flughafen Salzburg nach Seefeld in Tirol - Alpenhotel Fall In Love und zurück, müssen Sie das Ankunftsdatum, die Zahl der Erwachsenen und Kinder, sowie die Varianten des Fahrzeugs auswählen.
<G-vec00166-002-s268><calculate.kalkulieren><en> We compare the technical specifications of the main competitive products with their solutions and calculate the difference in manufacturing costs – of course on the basis of your own cost structures.
<G-vec00166-002-s268><calculate.kalkulieren><de> Wir vergleichen die technischen Ausführungen von den Hauptwettbewerbsprodukten mit Ihren Lösungen und kalkulieren den Unterschied in den Herstellkosten – natürlich auf Basis Ihrer eigenen Kostenstrukturen.
<G-vec00166-002-s269><calculate.kalkulieren><en> Check your website/domain on worthkit.com (Open worthkit.com home page and write your website/domain name then click "Calculate").
<G-vec00166-002-s269><calculate.kalkulieren><de> Überprüfen Sie Ihre Webseite/Domain auf worthkit.com (öffnen Sie unsere worthkit.com Webseite,tragen Sie Ihren Webseiten-/Domainnamen ein und drücken auf "Kalkulieren").
<G-vec00166-002-s317><calculate.rechnen><en> Nowadays, human intelligence is taking a more systemic perspective and incorporates various dimensions, not only the ability to calculate or solve riddles.
<G-vec00166-002-s317><calculate.rechnen><de> Heute betrachtet man die menschliche Intelligenz eher aus einer systemischen Perspektive und bezieht verschiedene Dimensionen mit ein, die weit über die Fähigkeit zu rechnen oder Rätsel zu lösen hinausgehen.
<G-vec00166-002-s318><calculate.rechnen><en> Chemists of Jena University let fluorescent sugar sensors calculate In a chemistry lab at the Friedrich Schiller University Jena (Germany): Prof. Dr. Alexander Schiller works at a rectangular plastic board with 384 small wells.
<G-vec00166-002-s318><calculate.rechnen><de> Chemiker der Universität Jena lassen fluoreszierende Zuckersensoren rechnen In einem Chemie-Labor an der Friedrich-Schiller-Universität Jena: An einer rechteckigen Kunststoffplatte mit 384 kleinen Vertiefungen arbeitet Prof. Dr. Alexander Schiller.
<G-vec00166-002-s319><calculate.rechnen><en> You have to calculate an average of 4$ for a blade cartridge.
<G-vec00166-002-s319><calculate.rechnen><de> Du musst im Schnitt mit 4€ für eine Systemklinge rechnen.
<G-vec00166-002-s320><calculate.rechnen><en> After a click with the mouse on any free space of the window or on the "calculate" button you may already read the price per kilogram (1.308 €).
<G-vec00166-002-s320><calculate.rechnen><de> Nach einem Mausklick auf eine beliebige freie Stelle des Fensters oder den "rechnen"-Knopf können Sie bereits den Kilogrammpreis ablesen (1.308 €).
<G-vec00166-002-s321><calculate.rechnen><en> It is not even necessary to introduce a general speed limit, as opponents calculate that only 2 percent of the roads in Germany are not speed-limited.
<G-vec00166-002-s321><calculate.rechnen><de> Man braucht auch gar kein generelles Tempolimit einzuführen, denn die Gegner rechnen vor, dass nur 2 Prozent der Straßen in Deutschland nicht tempobegrenzt sind.
<G-vec00166-002-s322><calculate.rechnen><en> The E-350 can only calculate simultaneously executed multitasking operations on two cores, but that "out of order".
<G-vec00166-002-s322><calculate.rechnen><de> Der E-350 kann parallel ausgeführte Multitasking-Operationen nur auf zwei Kernen rechnen, dafür aber "Out of Order".
<G-vec00166-002-s323><calculate.rechnen><en> If QuickLOAD should by chance not contain the preferred cartridge length, we calculate using the CIP standard length or a length that we consider suitable.
<G-vec00166-002-s323><calculate.rechnen><de> Falls die bevorzugte Patronenlänge einmal fehlen sollte, so rechnen wir mit der CIP Standardlänge oder einer Länge welche wir für geeignet halten.
<G-vec00166-002-s324><calculate.rechnen><en> A scan without iSRD takes as much time as it is the case with the old model, as there is not much to calculate in a normal scan but the scanner itself requires time.
<G-vec00166-002-s324><calculate.rechnen><de> Ein Scan ohne iSRD dauert genauso lange wie beim alten Modell, da es bei einem normalen Scan nicht viel zu Rechnen gibt sondern der Scanner selbst die Zeit in Anspruch nimmt.
<G-vec00166-002-s325><calculate.rechnen><en> On average, we calculate that each tree stores 10 kg of CO2 each year.
<G-vec00166-002-s325><calculate.rechnen><de> Im Durchschnitt rechnen wir mit 10kg CO2 Bindung pro Baum pro Jahr.
<G-vec00166-002-s326><calculate.rechnen><en> Most of the uneducated girls learn how to read, write and calculate during their stay; additionally, they can attend job-specific training classes.
<G-vec00166-002-s326><calculate.rechnen><de> Die meist ungebildeten Mädchen lernen während ihres Aufenthalts Lesen, Schreiben und Rechnen; zusätzlich können sie an berufsbildenden Kursen teilnehmen.
<G-vec00166-002-s327><calculate.rechnen><en> For example here in Germany, when you calculate in USD, we are paying US$0.35 (35 cents) per kWh, and our goal is to cut the price at least in half.
<G-vec00166-002-s327><calculate.rechnen><de> Zum Beispiel hier in Deutschland, wenn Sie in USD rechnen, zahlen wir 0,35 US$ (35 Cent) pro kWh, und unser Ziel ist es, den Preis mindestens zu halbieren.
<G-vec00166-002-s328><calculate.rechnen><en> Next click on the "calculate" button and read the result in the desired unit.
<G-vec00166-002-s328><calculate.rechnen><de> Klicken Sie dann auf den "rechnen"-Button und lesen Sie das Resultat in den gewünschten Einheiten ab.
<G-vec00166-002-s329><calculate.rechnen><en> After typing your body weight into the field in front of the corresponding unit, a click on the "calculate" button or any free space of the window leads to the calculation of the weight in the other units and of the body-mass-index.
<G-vec00166-002-s329><calculate.rechnen><de> Wenn Sie dann das Körpergewicht eintippen, wird nach einem Mausklick auf den "rechnen"-Button oder eine beliebige freie Stelle des Fensters der Wert für den BMI sowie das Körpergewicht in den anderen Einheiten berechnet.
<G-vec00166-002-s330><calculate.rechnen><en> To be sure, I find it absurd to calculate this kind of damage in money.
<G-vec00166-002-s330><calculate.rechnen><de> Zwar finde ich es absurd, solche Schäden in Geld zu rechnen.
<G-vec00166-002-s331><calculate.rechnen><en> Some of our children would have starved on the streets, others would never have learned how to read, write or calculate.
<G-vec00166-002-s331><calculate.rechnen><de> Manche unserer Kinder wären auf der Straße verhungert, andere hätten nie lesen, schreiben und rechnen gelernt.
<G-vec00166-002-s332><calculate.rechnen><en> In a holistic analysis the experts additionally calculate into the equation the CO2 emissions from the manufacturing and recovery phase.
<G-vec00166-002-s332><calculate.rechnen><de> In einer ganzheitlichen Analyse rechnen die Experten zusätzlich die CO2-Emissionen aus der Herstellung und Verwertung ein.
<G-vec00166-002-s333><calculate.rechnen><en> More and more children and adolescents cannot even read properly, nor can they write or calculate.
<G-vec00166-002-s333><calculate.rechnen><de> Immer mehr Kinder und Jugendliche können sogar nicht mehr richtig lesen, schreiben und rechnen.
<G-vec00166-002-s334><calculate.rechnen><en> Since 2009 I'm a schoolgirl, studiously learning to write, calculate, and all the other things.
<G-vec00166-002-s334><calculate.rechnen><de> Seit 2009 gehe ich zur Schule, habe mittlerweile fleißig Schreiben, Rechnen und all die anderen Dinge gelernt.
<G-vec00166-002-s335><calculate.rechnen><en> Click on any empty space of the window or on the "calculate" button.
<G-vec00166-002-s335><calculate.rechnen><de> Klicken Sie auf ein beliebiges freies Feld des Fensters oder den "rechnen"-Button.
<G-vec00166-002-s336><calculate.rechnen><en> Roughly calculate the water volume of your tank in kg for the weight (you actually need to allow a further 10 % for the glass weight and decoration, such as gravel and stones).
<G-vec00166-002-s336><calculate.rechnen><de> Rechnen Sie grob das Wasservolumen Ihres Aquariums als Kilogramm für das Gewicht (eigentlich plus 10 % für Glasgewicht und Dekoration wie Kies und Steine).
<G-vec00166-002-s337><calculate.rechnen><en> Mandatory field Security question* Please calculate 1 plus 2.
<G-vec00166-002-s337><calculate.rechnen><de> Pflichtfeld Schutz* Bitte rechnen Sie 1 plus 1.
<G-vec00166-002-s338><calculate.rechnen><en> Pan Am Mandatory field Captcha* Please calculate 6 plus 1.
<G-vec00166-002-s338><calculate.rechnen><de> Pflichtfeld Spamschutz-Abfrage* Bitte rechnen Sie 6 plus 2.
<G-vec00166-002-s339><calculate.rechnen><en> Mandatory field Mandatory field Security query* Please calculate 2 plus 6.
<G-vec00166-002-s339><calculate.rechnen><de> Pflichtfeld Sicherheitsabfrage* Bitte rechnen Sie 9 plus 6.
<G-vec00166-002-s340><calculate.rechnen><en> Firstly, calculate the total power of the LED module.
<G-vec00166-002-s340><calculate.rechnen><de> Erstens, rechnen Sie die Gesamtleistung der LED-Module.
<G-vec00166-002-s341><calculate.rechnen><en> Mandatory field Secret question* Please calculate 3 plus 9.
<G-vec00166-002-s341><calculate.rechnen><de> Pflichtfeld Sicherheitsfrage* Bitte rechnen Sie 5 plus 7.
<G-vec00166-002-s342><calculate.rechnen><en> Calculate Qmiles and Qpoints to be earned as well as Qmiles required for redemption on Qatar Airways or other airlines.
<G-vec00166-002-s342><calculate.rechnen><de> Rechnen Sie aus, wie viele Qmiles und Qpoints Sie verdienen werden und wie viele Qmiles Sie zum Einlösen bei Qatar Airways oder anderen Fluggesellschaften benötigen.
<G-vec00166-002-s343><calculate.rechnen><en> Quick contact field Captcha* Please calculate 8 plus 5.
<G-vec00166-002-s343><calculate.rechnen><de> Pflichtfeld Spamschutz* Bitte rechnen Sie 6 plus 6.
<G-vec00166-002-s344><calculate.rechnen><en> your wishes Mandatory field Security-Question* Please calculate 1 plus 5.
<G-vec00166-002-s344><calculate.rechnen><de> Pflichtfeld Sicherheitsfrage* Bitte rechnen Sie 1 plus 1.
<G-vec00166-002-s345><calculate.rechnen><en> Calculate how much steel you need quickly and easily.
<G-vec00166-002-s345><calculate.rechnen><de> Rechnen Sie schnell und einfach aus, wie viel Stahl Sie benötigen.
<G-vec00166-002-s346><calculate.rechnen><en> Mandatory field Spam?* Please calculate 7 plus 6.
<G-vec00166-002-s346><calculate.rechnen><de> Pflichtfeld Zur Sicherheit* Bitte rechnen Sie 6 plus 4.
<G-vec00166-002-s347><calculate.rechnen><en> Mandatory field Security Question* Please calculate 4 plus 6.
<G-vec00166-002-s347><calculate.rechnen><de> Pflichtfeld Anti-SPAM* Bitte rechnen Sie 7 plus 6.
<G-vec00166-002-s348><calculate.rechnen><en> Calculate your project with the Florapower economic calculator.
<G-vec00166-002-s348><calculate.rechnen><de> Rechnen Sie Ihr Projekt mit den Florapower Wirtschaftlichkeitsrechner durch.
<G-vec00166-002-s349><calculate.rechnen><en> Security check Please calculate 4 plus 7.
<G-vec00166-002-s349><calculate.rechnen><de> Sicherheitsabfrage Bitte rechnen Sie 2 plus 7.
<G-vec00166-002-s350><calculate.rechnen><en> Mandatory field Please answer* Please calculate 4 plus 6.
<G-vec00166-002-s350><calculate.rechnen><de> Pflichtfeld Spamschutz* Bitte rechnen Sie 9 plus 1.
<G-vec00166-002-s351><calculate.rechnen><en> In general please calculate a longer delivery time for a laptop sleeve than for an iPhone case.
<G-vec00166-002-s351><calculate.rechnen><de> Bitte rechnen Sie in der Regel eine längere Lieferzeit für eine Clutch oder Laptop Tasche als für eine iPhone Tasche.
<G-vec00166-002-s352><calculate.rechnen><en> Hotel | Gasthof Security question* Please calculate 2 plus 9.
<G-vec00166-002-s352><calculate.rechnen><de> Pflichtfeld Sicherheitsfrage* Bitte rechnen Sie 2 plus 1.
<G-vec00166-002-s353><calculate.rechnen><en> Calculate how many square metres are on the menu for dinner tonight.
<G-vec00166-002-s353><calculate.rechnen><de> Rechnen Sie nach, wie viele Quadratmeter es heute zum Abendessen gibt.
<G-vec00166-002-s354><calculate.rechnen><en> Mandatory field Safety question* Please calculate 1 plus 1.
<G-vec00166-002-s354><calculate.rechnen><de> Pflichtfeld Spamschutz:* Bitte rechnen Sie 1 plus 1.
