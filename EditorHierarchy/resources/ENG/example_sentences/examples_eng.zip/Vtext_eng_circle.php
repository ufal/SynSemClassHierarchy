<G-vec00831-002-s128><circle.kreisen><en> Trillions such dirty snowballs circle around the sun at a very large distance.
<G-vec00831-002-s128><circle.kreisen><de> Billionen solcher schmutziger Schneebälle kreisen in sehr großer Entfernung um die Sonne.
<G-vec00831-002-s129><circle.kreisen><en> There are 4 types of circle - ordinary enemy, spikes, void, golden circle and first aid kit.
<G-vec00831-002-s129><circle.kreisen><de> Es gibt 4 Arten von Kreisen - gewöhnliche Feinde, Stacheln, Leere, goldene Kreise und Erste-Hilfe-Ausrüstung.
<G-vec00831-002-s130><circle.kreisen><en> Total weight: About 32000kg Application Model JXW500 Section Material Bender is used to make circle, curve, or spiral for work pieces.
<G-vec00831-002-s130><circle.kreisen><de> Gesamtgewicht: Ungefähr 32000kg \ n \ nAnwendung \ nModell JXW500 Schnittmaterial Bender wird zum Erstellen von Kreisen, Kurven oder Spiralen für Werkstücke verwendet.
<G-vec00831-002-s131><circle.kreisen><en> It remains to be underlined, that not only his own works, but also these examples circle around topics like delusion and its perception, or levels of reality and the questioning of free will, of fate and determination.
<G-vec00831-002-s131><circle.kreisen><de> Besonders hervorzuheben bleibt hier allerdings, daß auch die Vorbilder um die Themen des Wahns und seiner Wahrnehmung, um Ebenen von Wirklichkeit und um Fragen der Willensfreiheit, des Schicksals und der Determination kreisen.
<G-vec00831-002-s132><circle.kreisen><en> A superb show that made almost everyone circle their hair so hard that you think it won´t take long until their heads will fly off.
<G-vec00831-002-s132><circle.kreisen><de> Eine hammerstarke Show, die fast jeden seine Haare so fest kreisen lässt, dass man denkt, jetzt geht´s nicht mehr lange, dann stehen sie alle ohne Kopf da.
<G-vec00831-002-s133><circle.kreisen><en> Since eternity celestial bodies circle the universe on paths specified by the divine Creator and which will also be upheld in the plan of creation according to His will.
<G-vec00831-002-s133><circle.kreisen><de> Ewig schon kreisen die Gestirne in ihrer Bahn, die vom göttlichen Schöpfer ihnen vorgeschrieben wurde und die im Schöpfungsplan auch eingehalten wird nach Seinem Willen.
<G-vec00831-002-s134><circle.kreisen><en> Rules: Connect each four cells with a circle to a tetromino.
<G-vec00831-002-s134><circle.kreisen><de> Lösung: Regeln: Fassen Sie je vier Felder mit Kreisen zu einem Tetromino zusammen.
<G-vec00831-002-s135><circle.kreisen><en> The positioning of the individual groups on the stage, in the boxes and in the tiers allowed the attention to constantly circle and realign itself.
<G-vec00831-002-s135><circle.kreisen><de> Die Positionierung der einzelnen Gruppen auf der Bühne, in den Logen und Rängen ließ die Aufmerksamkeit beständig kreisen und sich neu ausrichten.
<G-vec00831-002-s136><circle.kreisen><en> Having planned for some time to travel to the continent for the purpose of evangelism, Robert Haldane travelled to Geneva in the autumn of 1816, and in the context of the Réveil, which was commencing there, he gained access to a student circle that had formed there over the preceding years, which was critical of rationalist theology.
<G-vec00831-002-s136><circle.kreisen><de> Im Herbst 1816 kam Robert, der schon länger eine Evangelisationsreise auf den Kontinent geplant hatte, nach Genf und fand im Kontext des dort beginnenden Réveil Zugang zu Kreisen einer der rationalistischen Theologie gegenüber kritisch eingestellten Studentenschaft, die sich dort in den letzten Jahren gesammelt hatten.
<G-vec00831-002-s137><circle.kreisen><en> Schools of barracuda often circle here, and dogtooth tuna and reef sharks are often prowling close by.
<G-vec00831-002-s137><circle.kreisen><de> Schulen von Barrakudas kreisen oft hier und Thunfische und Riffhaie sind häufig in der Nähe.
<G-vec00831-002-s138><circle.kreisen><en> The fresh trillions circle the world in the search for yield, but only a small part of the money flows into the real economy, where investments in new production plants produce lower returns.
<G-vec00831-002-s138><circle.kreisen><de> Die neuen Billionen kreisen auf der Suche nach Renditen um die Welt, aber nur ein kleiner Teil des Geldes fließt in die Realwirtschaft, wo Investitionen in neue Produktionsanlagen geringere Renditen anbieten.
<G-vec00831-002-s139><circle.kreisen><en> Their three films – THE HALFMOON FILES, DAY OF THE SPARROW and REVISION – circle the events of contemporary German-European history.
<G-vec00831-002-s139><circle.kreisen><de> Ihre drei Filme – THE HALFMOON FILES, DER TAG DES SPATZEN und REVISION – kreisen dabei um die deutsch-europäische Zeitgeschichte.
<G-vec00831-002-s140><circle.kreisen><en> Then I move her hands in a slow circle then move them upwards towards her breast.
<G-vec00831-002-s140><circle.kreisen><de> Dann bewege ich ihre Hände in sanften Kreisen nach oben, in Richtung ihrer Brüste.
<G-vec00831-002-s141><circle.kreisen><en> Therefore try to combat the harmful habit in the circle of your acquaintances.
<G-vec00831-002-s141><circle.kreisen><de> Versucht deshalb die schadenbringende Gewohnheit in den Euch vertrauten Kreisen zu bekämpfen.
<G-vec00831-002-s142><circle.kreisen><en> It was like his destiny that he started to circle the rim with the wood mallet.
<G-vec00831-002-s142><circle.kreisen><de> Es war wie eine Bestimmung für ihn, daß er mit dem Holzschlegel zu kreisen anfing.
<G-vec00831-002-s143><circle.kreisen><en> Find a place behind her after dinner, caress her neck softly and slowly, feel for her muscles and let your fingers circle around them.
<G-vec00831-002-s143><circle.kreisen><de> Pirsche dich nach dem Abendessen hinter sie und streichel ihr leicht und langsam über den Nacken, taste sanft ihre Muskulatur und lass deine Finger kreisen.
<G-vec00831-002-s144><circle.kreisen><en> The bird will circle back around and repeat the process.
<G-vec00831-002-s144><circle.kreisen><de> Der Vogel wird kreisen und den Vorgang wiederholen.
<G-vec00831-002-s145><circle.kreisen><en> In our case, it took 22.5 cm. If there is enough tissue on all sides, take a chalk or a pencil and circle the seat at the edges.
<G-vec00831-002-s145><circle.kreisen><de> In unserem Fall waren es 22,5 cm, wenn auf allen Seiten genügend Gewebe vorhanden ist, nehmen Sie Kreide oder Bleistift und kreisen Sie den Sitz an den Kanten ein.
<G-vec00831-002-s146><circle.kreisen><en> The oil between the individual ribs can circle the shape of the oil cooler kits (arrangement of cooling fins).
<G-vec00831-002-s146><circle.kreisen><de> Durch die Bauform des Ölkühler-Kits (Anordnung der Kühlrippen) kann das Motoröl zwischen den einzelnen Rippen kreisen.
<G-vec00831-002-s290><circle.umkreisen><en> The two, armed uniformed officers circle the vehicle and nod briefly.
<G-vec00831-002-s290><circle.umkreisen><de> Die zwei bewaffneten Uniformierten umkreisen das Fahrzeug und nicken kurz.
<G-vec00831-002-s291><circle.umkreisen><en> Here the musicians’ individual contributions circle and merge with one another, literally melting into a mutual song.
<G-vec00831-002-s291><circle.umkreisen><de> Bezaubernd, wie hier die individuellen Beiträge der Musiker einander umkreisen, sich verschränken, buchstäblich zu einem gemeinsamen Lied verschmelzen.
<G-vec00831-002-s292><circle.umkreisen><en> At the same time, an orbiter will circle Mars to ensure communication with Earth.
<G-vec00831-002-s292><circle.umkreisen><de> Gleichzeitig soll ein Orbiter den Mars umkreisen, um die Kommunikation zur Erde sicherzustellen.
<G-vec00831-002-s293><circle.umkreisen><en> Circle the main lines with a black pencil and erase the extra ones.
<G-vec00831-002-s293><circle.umkreisen><de> Umkreisen Sie die Hauptlinien mit einem schwarzen Bleistift und löschen Sie die zusätzlichen.
<G-vec00831-002-s294><circle.umkreisen><en> They circle around each other always on the lookout, between them a space takes form, in which they alone exist.
<G-vec00831-002-s294><circle.umkreisen><de> Lauernd umkreisen sie sich, zwischen ihnen baut sich ein Raum auf, in dem es nur noch sie gibt.
<G-vec00831-002-s295><circle.umkreisen><en> The rays of My light shining from you now circle the universe several times.
<G-vec00831-002-s295><circle.umkreisen><de> Die Strahlen Meines Lichts, die von dir scheinen, umkreisen das Universum mehrmals.
<G-vec00831-002-s296><circle.umkreisen><en> Circle the marker of scratches and damage, over which it is necessary to work.
<G-vec00831-002-s296><circle.umkreisen><de> Umkreisen Sie die Markierung der Kratzer und der Beschädigung, über die man arbeiten muss.
<G-vec00831-002-s297><circle.umkreisen><en> The game becomes a kind of combat qua baroque dance – players circle around each other, waiting for their opportunity to strike.
<G-vec00831-002-s297><circle.umkreisen><de> Das Spiel wird zu einer Art Kampfspiel, vermischt mit barockem Tanz – die Spieler umkreisen einander und warten auf eine Gelegenheit, zuzuschlagen.
<G-vec00831-002-s298><circle.umkreisen><en> It can circle the globe in just 16 hours.
<G-vec00831-002-s298><circle.umkreisen><de> DRAGORAN kann die Welt innerhalb von 16 Stunden umkreisen.
<G-vec00831-002-s299><circle.umkreisen><en> All these skis laid end to end would circle the equator several times over.
<G-vec00831-002-s299><circle.umkreisen><de> Würde man sämtliche Elan Ski hintereinanderlegen, würden sie den Äquator mehrmals umkreisen.
<G-vec00831-002-s300><circle.umkreisen><en> Together with the almost identical satellite TerraSAR-X, scheduled for launch in October 2006 from the Baikonur space centre, TanDEM-X will circle the Earth in close formation flight.
<G-vec00831-002-s300><circle.umkreisen><de> Zusammen mit dem nahezu baugleichen Satelliten TerraSAR-X, der im Oktober 2006 vom Weltraumbahnhof Baikonur starten soll, wird TanDEM-X im engen Formationsflug die Erde umkreisen.
<G-vec00831-002-s301><circle.umkreisen><en> You can put my toes in your mouth and circle around with your tongue, lick the sweat between your toes, drive the toenails with the tip of your tongue.
<G-vec00831-002-s301><circle.umkreisen><de> Du kannst meine Zehen in den Mund nehmen und mit deiner Zunge umkreisen, kannst den Schweiß zwischen den Zehen ablecken,...Zehennägel mit der Zungenspitze entlang fahren.
<G-vec00831-002-s302><circle.umkreisen><en> Circle the eyes twice, patting gently on the surface of the skin with your fingertips.
<G-vec00831-002-s302><circle.umkreisen><de> Umkreisen Sie die Augen zweimal und tupfen dabei leicht mit den Fingerspitzen auf die Hautoberfläche.
<G-vec00831-002-s303><circle.umrunden><en> For example, why not circle lake Zeller See wearing winter boots or snowshoes!
<G-vec00831-002-s303><circle.umrunden><de> Zum Beispiel umrunden Sie den Zeller See mit Winterstiefeln oder Schneeschuhen.
<G-vec00831-002-s304><circle.umrunden><en> So-called “cryovolcanoes” are active in Enceladus’ south polar region, spewing vapour fountains hundreds of kilometres up into space, where the refrozen ice particles are finally trapped by Saturn’s outer rings and from then on circle the planet.
<G-vec00831-002-s304><circle.umrunden><de> Am Südpol von Enceladus sind so genannte Kryovulkane aktiv, die Dampffontänen viele hundert Kilometer weit ins All schleudern, wo die wieder gefrorenen Eispartikel schließlich von den äußeren Ringen des Saturn eingefangen werden und dann den Planeten umrunden.
<G-vec00831-002-s305><circle.umrunden><en> In this position, the slitter shafts can be easily charged or a prepared pair of slitter shafts can be conveniently inserted – without the dangerous reaching into the machine on combination folding machines, without to circle around the machine a couple of times, without shifting the subsequent folding unit on buckle folding machines.
<G-vec00831-002-s305><circle.umrunden><de> In dieser Position können die Messerwellen mühelos bestückt oder ein vorher präpariertes Messerwellenpaar bequem eingesetzt werden – ohne gefährliches Hineingreifen bei Kombifalzmaschinen, ohne die Maschine mehrfach zu umrunden und ohne Verschieben des Nachfolgefalzwerkes bei Taschenfalzmaschinen.
<G-vec00831-002-s306><circle.umrunden><en> As she gets into the car, the perpetrators circle the car, knocking on the windows.
<G-vec00831-002-s306><circle.umrunden><de> Als sie ins Auto steigt, umrunden die Täter das Auto, klopfen an die Scheiben.
<G-vec00831-002-s307><circle.umrunden><en> Again and again we circle around dense scrubs.
<G-vec00831-002-s307><circle.umrunden><de> Immer wieder umrunden wir undurchsichtiges Gestrüpp.
<G-vec00831-002-s308><circle.umrunden><en> You can circle it in an hour.
<G-vec00831-002-s308><circle.umrunden><de> Sie können ihn in einer Stunde umrunden.
<G-vec00831-002-s309><circle.umrunden><en> 728 reviews In six days you can drive the whole Iceland circle and experience the magnificent nature of Iceland.
<G-vec00831-002-s309><circle.umrunden><de> 713 Bewertungen In 7-8 Tagen kann man bereits die Insel umrunden und einen Großteil der eindrucksvollen Naturwunder des Landes erleben.
<G-vec00831-002-s310><circle.umrunden><en> Several trails circle Alpine Haven, too, great for cross country skiing, snow shoeing and hiking.
<G-vec00831-002-s310><circle.umrunden><de> Mehrere Wanderwege umrunden Alpine Haven auch ideal für Langlaufen, Schneeschuhlaufen und Wandern.
<G-vec00831-002-s311><circle.umrunden><en> Believe it or not, enough plastic is discarded every year to circle the globe four times.
<G-vec00831-002-s311><circle.umrunden><de> Ob du es glaubst oder nicht, jeden Tag wird genug Plastik weggeworfen, um viermal den Globus zu umrunden.
<G-vec00831-002-s312><circle.umrunden><en> The viewer can easily circle this partial fence, but tends to step back from it, not for fear of being cut but for caution not to break the delicate glass.
<G-vec00831-002-s312><circle.umrunden><de> Der Betrachter kann diesen Teilzaun leicht umrunden, doch er tendiert dazu, zurückzutreten; nicht aus Angst davor, sich zu schneiden, sondern weil er nicht das zierliche Glas zerbrechen will.
<G-vec00831-002-s313><circle.umrunden><en> It took me five minutes to walk the full circle of the parking lot, and I’d repeat the rounds to make for an extended walk.
<G-vec00831-002-s313><circle.umrunden><de> Um den Platz einmal zu umrunden brauchte ich fünf Minuten und nach ein paar Runden wurde ein ausgedehnter Spaziergang daraus.
<G-vec00831-002-s314><circle.umrunden><en> The smaller Ma-13, which is not far away, will take you to medieval Alcúdia and the La Victòria peninsula, where you can climb or circle the Talaia; or take the Pollença route, enjoy markets, tasteful shops, galleries and restaurants and then stroll along Pollença's flagship promenade.
<G-vec00831-002-s314><circle.umrunden><de> Die kleinere, nicht weit entfernte Ma-13 bringt Sie in wenigen Minuten ins mittelalterliche Alcúdia und weiter auf die La-Victòria-Halbinsel – hier können Sie den Talaia erklimmen oder umrunden; oder nehmen Sie die Pollença-Route, genießen Markt, geschmackvolle Läden, Galerien und Restaurants und schlendern dann über die Vorzeigepromenade von Port de Pollença.
<G-vec00831-002-s315><circle.umrunden><en> Circle round the fountain and - still directly in front of the palace - go past it to the left, then immediately turning along the second path to the left.
<G-vec00831-002-s315><circle.umrunden><de> Sie umrunden den Brunnen und laufen - unmittelbar vor dem Schloss stehend - links daran vorbei, um gleich danach in den zweiten Weg links einzubiegen.
<G-vec00831-002-s316><circle.umrunden><en> Difficulty After Calvia we circle around a part of the Serra de Na Burguesa.
<G-vec00831-002-s316><circle.umrunden><de> Schwierigkeit Nach Calvia umrunden wir einen Teil der Serra de Na Burguesa.
<G-vec00831-002-s317><circle.umrunden><en> While the keen walker could almost circle the island in one day there exists also the possibility to rent a bike or even a water taxi in order to go to the more remote beaches on La Graciosa’s east coast like the beautiful Playa de las Conchas or Playa del Ambar.
<G-vec00831-002-s317><circle.umrunden><de> Wer gerne wandert könnte fast die ganze Insel in einem Tag umrunden aber es besteht auch die Möglichkeit sich ein Fahrrad oder sogar ein Wassertaxi zu chartern mit welchen man die an der Ostküste gelegenen Strände auf La Graciosa schnell erreichen kann.
<G-vec00831-002-s318><circle.umrunden><en> This 11 day driving holiday is perfect for those wanting to circle around Iceland at a comfortable pace and enjoy the unique and diverse scenery that make Iceland such an amazing destination.
<G-vec00831-002-s318><circle.umrunden><de> Dieser 11-tägige Fahrurlaub ist ideal für diejenigen, die Island in einem angenehmen Tempo umrunden und die einzigartige und abwechslungsreiche Landschaft genießen möchten, welche Island zu einem so erstaunlichen Reiseziel macht.
<G-vec00831-002-s319><circle.umrunden><en> Circle coral reefs with your motorbike.
<G-vec00831-002-s319><circle.umrunden><de> Mit dem Motorrad Korallenriffe umrunden.
