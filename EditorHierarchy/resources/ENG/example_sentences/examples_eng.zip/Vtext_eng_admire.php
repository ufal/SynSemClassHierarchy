<G-vec01048-002-s135><admire.bewundern><en> I admire the work you do, especially through Caritas and other Catholic charitable organizations in the different countries, in providing help to anyone who asks, without discrimination.
<G-vec01048-002-s135><admire.bewundern><de> Ich bewundere die Arbeit, die Ihr besonders durch die Caritas und mit Hilfe der katholischen karitativen Organisationen verschiedener Länder leistet, indem Ihr allen ohne jede Bevorzugung helft.
<G-vec01048-002-s136><admire.bewundern><en> I admire new technologies that solve problems for the environment.
<G-vec01048-002-s136><admire.bewundern><de> Ich bewundere neue Technologien, die Umweltprobleme lösen.
<G-vec01048-002-s137><admire.bewundern><en> I respect and admire people.
<G-vec01048-002-s137><admire.bewundern><de> Ich respektiere und bewundere Menschen.
<G-vec01048-002-s138><admire.bewundern><en> Susann: I admire different things in different people.
<G-vec01048-002-s138><admire.bewundern><de> Susann: Ich bin ein personality picker – ich bewundere unterschiedliche Dinge an unterschiedlichen Leuten.
<G-vec01048-002-s139><admire.bewundern><en> I admire what Mario Draghi has done to save the euro.
<G-vec01048-002-s139><admire.bewundern><de> Ich bewundere, was Mario Draghi geleistet hat, um den Euro zu retten.
<G-vec01048-002-s140><admire.bewundern><en> I rather admire a Bicinium on a one manual organ in meantone, than time and again the noisy ‘Cochereau-fireworks’ on a huge instrument in a big cathedral.
<G-vec01048-002-s140><admire.bewundern><de> Ich bewundere eher ein Bicinium auf einer einmanualigen, mitteltönigen Orgel, als die lauten Klangfeuerwerke auf einem riesigen Instrument in einer großen Kathedrale, etwa in der Art von Pierre Cochereau.
<G-vec01048-002-s141><admire.bewundern><en> "I especially admire her control over the sound, she never goes to her limits, it always sounds natural, even in the highest notes effortlessly.
<G-vec01048-002-s141><admire.bewundern><de> «Ich bewundere besonders, wie sie den Ton stets unter Kontrolle hat, sie geht nie an ihre Limiten, es klingt immer natürlich, auch in den höchsten Tönen mühelos.
<G-vec01048-002-s142><admire.bewundern><en> I admire the incredible creatures.
<G-vec01048-002-s142><admire.bewundern><de> Ich bewundere die unglaublichen Kreaturen.
<G-vec01048-002-s143><admire.bewundern><en> This is one reason I especially admire Jacques.
<G-vec01048-002-s143><admire.bewundern><de> Dies ist der Grund, weshalb ich Jacques Benveniste besonders bewundere.
<G-vec01048-002-s144><admire.bewundern><en> As I have said before I am not a vegan but I admire anyone who is.
<G-vec01048-002-s144><admire.bewundern><de> Wie ich schon öfter geschrieben habe, lebe ich nicht vegan, bewundere aber jeden der es tut.
<G-vec01048-002-s145><admire.bewundern><en> It is unlike anything I have ever experienced and I admire the Japanese in this tradition.
<G-vec01048-002-s145><admire.bewundern><de> Es ist anders als alles, was ich je erlebt habe und ich bewundere die Japaner in dieser Tradition.
<G-vec01048-002-s146><admire.bewundern><en> I greatly admire the artist Ellsworth Kelly, who remained faithful to his style for all his life with.
<G-vec01048-002-s146><admire.bewundern><de> Ein Künstler, den ich bewundere, ist Ellsworth Kelly, der wirklich sein ganzes Leben einem Stil treu geblieben ist.
<G-vec01048-002-s147><admire.bewundern><en> Admire from the viewing platform Dreiländerblick more than 30 three-thousanders of Switzerland, Italy and Austria. #soulfuldriving
<G-vec01048-002-s147><admire.bewundern><de> Bewundere von der Aussichtsplattform Dreiländerblick mehr als 30 Dreitausender der Schweiz, Italien und von Österreich.
<G-vec01048-002-s148><admire.bewundern><en> There are many African artists that I admire, whose practices I follow very carefully just like there are many Europeans.
<G-vec01048-002-s148><admire.bewundern><de> Es gibt viele afrikanische Künstler, die ich bewundere und deren Tätigkeiten ich sehr genau verfolge, aber es gibt genauso viele europäische Künstler, für die das Gleiche gilt.
<G-vec01048-002-s149><admire.bewundern><en> Mr Schroeder, you're a capable man and I admire you.
<G-vec01048-002-s149><admire.bewundern><de> Mr. Schröder, Sie sind ein fähiger Mann, den ich bewundere.
<G-vec01048-002-s150><admire.bewundern><en> I admire the work by Jürgen Teller and all the photographers from Self-service and Purple Fashion.
<G-vec01048-002-s150><admire.bewundern><de> Ich bewundere die Arbeiten von Jürgen Teller und den Photographen von Self- Service, Purple Fashion.
<G-vec01048-002-s151><admire.bewundern><en> I really admire their vision to become an ecovillage to spread permaculture and to combine local and ecological agricultural techniques, experience community life and give people a better future.
<G-vec01048-002-s151><admire.bewundern><de> Ich bewundere wirklich ihre Vision, ein Ökodorf zu werden, um Permakultur zu verbreiten und lokale und ökologische landwirtschaftliche Techniken zu kombinieren, das Gemeinschaftsleben zu erleben und Menschen eine bessere Zukunft zu geben.
<G-vec01048-002-s152><admire.bewundern><en> I admire all three oft hem, because they experienced a lot.
<G-vec01048-002-s152><admire.bewundern><de> Ich bewundere alle drei, denn sie haben alle eine Menge im Leben erlebt.
<G-vec01048-002-s153><admire.bewundern><en> I admire you for who you've become in Christ, and for being faithful to heed His call.
<G-vec01048-002-s153><admire.bewundern><de> Ich bewundere Sie, für die Sie in Christus geworden sind, und für das Sein treu, His Anruf zu beachten.
<G-vec01048-002-s154><admire.bewundern><en> It is located at the highest point of the lake and from there you can admire a wide view of the lake and the surrounding mountains.
<G-vec01048-002-s154><admire.bewundern><de> Es befindet sich auf dem höchsten Punkt des Sees und von dort können Sie einen weiten Blick auf den See und die umliegenden Berge bewundern.
<G-vec01048-002-s155><admire.bewundern><en> In Catania, you can admire two Roman amphitheatres.
<G-vec01048-002-s155><admire.bewundern><de> In Catania können Sie zwei römische Amphitheater bewundern.
<G-vec01048-002-s156><admire.bewundern><en> Visit the city to admire its architecture and meet friendly locals.
<G-vec01048-002-s156><admire.bewundern><de> Besuchen Sie die Stadt, um die Architektur zu bewundern und sich mit den freundlichen Einheimischen zu treffen.
<G-vec01048-002-s157><admire.bewundern><en> Speaking of being romantic, did you know that in December you can admire the beautiful nativity scenes and woodcarvings in the Christmas Valley?
<G-vec01048-002-s157><admire.bewundern><de> Apropos Romantik: Im Dezember dürfen Sie im Weihnachtstal die herrlichen Krippen und Holzschnitzereien bewundern, für die Gröden weltweit gefeiert wird.
<G-vec01048-002-s158><admire.bewundern><en> Do not miss the beautiful gardens of the Promenade where you can admire a magnificent panorama of the Gulf.
<G-vec01048-002-s158><admire.bewundern><de> Verpassen Sie nicht die schönen Gärten der Promenade, wo Sie ein herrliches Panorama auf den Golf bewundern können.
<G-vec01048-002-s159><admire.bewundern><en> You cannot help but admire the way all the Georgian features that have survived up to the present day are maintained as though they were articles in a museum.
<G-vec01048-002-s159><admire.bewundern><de> Man kann wie in einem Museum die verschiedenen georgianischen Zierelemente bewundern, die bis in die Gegenwart erhalten sind.
<G-vec01048-002-s160><admire.bewundern><en> You can find hydroelectric power stations on Łupawa as well and it is the second route, after Słupia River, where you can admire the hydrotechnological infrastructure.
<G-vec01048-002-s160><admire.bewundern><de> Auf Łupawa befinden sich auch Wasserkraftwerke – es ist die zweite Strecke nach Słupia wo man die hydrologisch-technische Infrastruktur bewundern kann.
<G-vec01048-002-s161><admire.bewundern><en> Conclusion: I don´t know if it´s possible to enter the school as a tourist but I think people should only admire the building from the outside and leave the students alone.
<G-vec01048-002-s161><admire.bewundern><de> Fazit: Ich weiß nicht, ob es überhaupt möglich ist in die Schule zu kommen, aber man sollte die Schüler dort in Ruhe lernen lassen und das Gebäude nur von außen bewundern.
<G-vec01048-002-s162><admire.bewundern><en> There you can retrace the city's history on the Owl's Trail (Parcours de la Chouette), explore the Palais des Ducs, visit the Museum of Burgundian Life and admire the panoramic views from Philippe le Bon Tower.
<G-vec01048-002-s162><admire.bewundern><de> Sie können die Geschichte von Dijon auf dem Eulen-Rundgang erforschen, den Herzogspalast und das Musée de la Vie Bourguignonne besuchen und vom Turm Philippe le Bon das Panorama bewundern.
<G-vec01048-002-s163><admire.bewundern><en> In many areas of South Tyrol Visitors admire a unique spectacle: the earth pyramids.
<G-vec01048-002-s163><admire.bewundern><de> In vielen Gegenden Südtirols bewundern Besucher ein einzigartiges Naturschauspiel: Die Erdpyramiden.
<G-vec01048-002-s164><admire.bewundern><en> You can admire breathtaking views for lovers of tranquility and silence.
<G-vec01048-002-s164><admire.bewundern><de> Sie können atemberaubende Aussichten für Liebhaber von Ruhe und Stille bewundern.
<G-vec01048-002-s165><admire.bewundern><en> He never called people to admire Him but only to follow Him.
<G-vec01048-002-s165><admire.bewundern><de> Er rief Menschen niemals dazu auf, ihn zu bewundern, sondern nur, ihm nachzufolgen.
<G-vec01048-002-s166><admire.bewundern><en> This is accepted inside Villa Fattorusso and from here it is possible to admire all the beauty of the Gulf of Naples, the island of Capri and the entire Sorrento peninsula.
<G-vec01048-002-s166><admire.bewundern><de> Dies wird akzeptiert in der Villa Fattorusso und von hier aus kann man die ganze Schönheit des Golfs von Neapel, der Insel Capri und der gesamten Halbinsel von Sorrent bewundern.
<G-vec01048-002-s167><admire.bewundern><en> This is a unique opportunity to admire the outstanding artistic talents of top independent watchmakers.
<G-vec01048-002-s167><admire.bewundern><de> Es war eine einmalige Gelegenheit, das Schaffen unabhängiger Uhrenkünstler zu bewundern.
<G-vec01048-002-s168><admire.bewundern><en> You can now admire it on your wrist with this beautiful timepiece.
<G-vec01048-002-s168><admire.bewundern><de> Sie können es jetzt auf Ihrem Handgelenk bewundern, mit diesem schönen Zeitmesser.
<G-vec01048-002-s169><admire.bewundern><en> Along the pathways that connect the different buildings, damaged during the First World War and rebuilt in 1933 along Austro-Hungarian lines, you can admire several tree varieties and shrubs.
<G-vec01048-002-s169><admire.bewundern><de> Entlang der Wege, die die einzelnen Gebäude miteinander verbinden, die im Ersten Weltkrieg Schaden erlitten und 1933 nach österreichisch-ungarischen Kriterien wieder aufgebaut wurden, sind zahlreiche Baum- und Strauchsorten zu bewundern.
<G-vec01048-002-s170><admire.bewundern><en> This is where fans will have the opportunity to admire two MAN TGXs designed in FC Bayern Munich’s colours and have their photographs taken with them.
<G-vec01048-002-s170><admire.bewundern><de> Dort haben die Fans die Gelegenheit, zwei in den FCB-Vereinsfarben gestaltete MAN TGX zu bewundern und sich mit ihnen fotografieren zu lassen.
<G-vec01048-002-s171><admire.bewundern><en> New ice will continue to be created on the ice sheet and there will still be enormous amounts of ice to admire in Greenland for the next many generations.
<G-vec01048-002-s171><admire.bewundern><de> Es wird noch immer neues Eis auf dem Inlandeis gebildet, und die nächsten Generationen können in Grönland noch immer jede Menge Eis bewundern.
<G-vec01048-002-s172><admire.bewundern><en> In this beautiful region we are able to admire the splendour of God's creation and to give thanks for his many gifts to us.
<G-vec01048-002-s172><admire.bewundern><de> In dieser schönen Region können wir die Schönheit von Gottes Schöpfung bewundern und Gott für die vielen Gaben danken, die er uns geschenkt hat.
<G-vec01048-002-s173><admire.bewundern><en> Located in an extraordinary natural oasis, just 12 km from the center of Florence and 6 km from Fiesole, this charming apartment is part of a beautiful villa, originally built in the XII- XIV centuries as Tower or Medieval Castle, and then altered to the typical structure of the Florentine Renaissance Villas, which you can still admire nowadays.
<G-vec01048-002-s173><admire.bewundern><de> Das Hotel liegt in einer außergewöhnlichen Naturoase, nur 12 km vom Zentrum von Florenz und 6 km von Fiesole, dieses charmante Wohnung ist Teil einer schönen Villa, gebaut ursprünglich in den XII- XIV Jahrhunderten als Turm oder mittelalterliche Burg, und dann auf die veränderte typische Struktur der Florentiner Renaissance-Villen, die man noch heute bewundern können.
<G-vec01048-002-s174><admire.bewundern><en> On this night the city government turns off all electric lights to allow visitors of Mojácar to admire the starry sky in all its splendour and beauty.
<G-vec01048-002-s174><admire.bewundern><de> Und damit die Besucher von Mojácar den Sternenhimmel in all seiner Pracht und Schönheit bewundern können, schaltet die Stadtverwaltungen in dieser Nacht alle elektrischen Lichter aus.
<G-vec01048-002-s175><admire.bewundern><en> For something even more special, try night snorkeling, and admire the nocturnal fish and the reef colors with an underwater lamp.
<G-vec01048-002-s175><admire.bewundern><de> Etwas ganz Besonderes ist das Nachtschnorcheln, bei dem Sie die nachtaktiven Fische und die Farben der Riffe im Schein Ihrer Unterwasserlampe bewundern können.
<G-vec01048-002-s176><admire.bewundern><en> Leaving from Barcelona, visit the Dalí Museum in Figueres, where you will admire a set of works that the artist created expressly for this Theatre-Museum.
<G-vec01048-002-s176><admire.bewundern><de> Besuchen Sie von Barcelona aus das Dalí-Museum in Figueres, wo Sie eine Reihe von Werken bewundern können, die der Künstler eigens für dieses Theater-Museum geschaffen hat.
<G-vec01048-002-s177><admire.bewundern><en> The commerce was prospering and as a consequence of this, the inhabitants started to build numerous churches and buildings that we can still admire during a visit.
<G-vec01048-002-s177><admire.bewundern><de> Der Handel blühte und somit wurde mit dem Bau zahlreicher Kirchen und Gebäude begonnen, die wir noch heute bewundern können.
<G-vec01048-002-s178><admire.bewundern><en> Obviously arriving early in the morning will have the advantage of being able to put you closer to the sea to be able to admire even better the beauty of these unique waters in Italy.
<G-vec01048-002-s178><admire.bewundern><de> Wenn Sie früh am Morgen anreisen, haben Sie natürlich den Vorteil, näher am Meer zu sein, um die Schönheit dieser einzigartigen Gewässer in Italien noch besser bewundern zu können.
<G-vec01048-002-s179><admire.bewundern><en> A tourist route goes along the lakes, which you can comfortably walk from Čunovo up to Rusovce and admire the beauty of this precious natural site. RUSOVCE LAKE
<G-vec01048-002-s179><admire.bewundern><de> An den Seen führt ein Wanderweg entlang, auf dem Sie bequem von Čunovo nach Rusovce gelangen und dabei die Schönheit der umliegenden Natur bewundern können.
<G-vec01048-002-s180><admire.bewundern><en> Divers in the waters of Tiran can be sure to admire not only countless coral formations, but also a rich reef and pelagic fauna.
<G-vec01048-002-s180><admire.bewundern><de> Taucher in den Gewässern von Tiran können also sicher sein, nicht nur unzählige Korallenformationen, sondern auch eine reiche Riff- und pelagische Fauna bewundern zu können.
<G-vec01048-002-s181><admire.bewundern><en> It is suggested the route through the historic center of Verona, which allows you to admire sumptuous churches and palaces, walls, fortresses and the Roman theater from the dinghy.
<G-vec01048-002-s181><admire.bewundern><de> Wir empfehlen eine Raftingtour durch die Altstadt von Verona, bei der Sie Kirchen und prunkvolle Paläste, Stadtmauern und Festungen sowie das römische Theater bewundern können.
<G-vec01048-002-s182><admire.bewundern><en> To admire the splendour of his place, you should visit it in summer.
<G-vec01048-002-s182><admire.bewundern><de> Um Shark Bay in seiner ganzen Pracht bewundern zu können, sollte man den Ort im Sommer besuchen.
<G-vec01048-002-s183><admire.bewundern><en> But all this is just the beginning. Just take a few steps towards the windows and terraces: this is where your eyes and your heart will be filled with amazement, as you admire the Cannaregio Canal right down below!
<G-vec01048-002-s183><admire.bewundern><de> Aber all das ist erst der Beginn, Nur wenige Schritte bis zum Fenster oder zur Terrasse: Es ist dort, wo die Augen und das Herz sich mit Staunen füllen werden, wenn Sie den Cannaregio Grande direkt unter Ihnen bewundern können.
<G-vec01048-002-s184><admire.bewundern><en> Tourist attractions Iisalmi One of the most important historical sites in the town is the Karelian Orthodox Cultural Centre, which allows visitors to admire the frescoes, stained glass, statues, icons, and tsasounas which remained after the war.
<G-vec01048-002-s184><admire.bewundern><de> Reiseführer Iisalmi - Tourismus Iisalmi Eine der bedeutendsten Attraktionen der Stadt ist das Orthodoxe Zentrum, wo Besucher alte Fresken, Glasmalereien, Skulpturen, Ikonen und Kapellen bewundern können.
<G-vec01048-002-s185><admire.bewundern><en> Some incredibly interesting excursions are available in this cave, during which you can watch its inhabitants and admire the fantastic stalactites and stalagmites.
<G-vec01048-002-s185><admire.bewundern><de> Einige unglaublich interessante Exkursionen sind in dieser Höhle möglich, in der Sie seine Bewohner beobachten und die fantastischen Stalaktiten und Stalagmiten bewundern können.
<G-vec01048-002-s186><admire.bewundern><en> On the way, you will make a stop to admire one of the most beautiful monasteries in Romania built in the16th century, the Monastery of Curtea de Arges, which amazes visitors with its elegant shape and its exquisite exterior decorations.
<G-vec01048-002-s186><admire.bewundern><de> Nach dem Frühstück werden sie in Richtung Sibiu fahren, auf dem malerischen Weg des Olttals Auf dem Weg werden sie anhalten um eine der schönsten Klöster Rumäniens bewundern zu können, das Kloster Curtea de Arges, im 16.
<G-vec01048-002-s187><admire.bewundern><en> From each seating on the island it is proposed to grant a view to the sky in order to admire the freedom and width of the stars.
<G-vec01048-002-s187><admire.bewundern><de> Von jeder Sitzgelegenheit auf der Insel soll ein Blick in den Himmel gewährt sein, um die Freiheit und Weite der Sterne bewundern zu können.
<G-vec01048-002-s188><admire.bewundern><en> During the spring and autumn, but mainly during the months of September and October, more lovers of free flying in Canazei who come here to admire the beautiful landscapes and enjoy the 360 ° view of the sceneries that fascinate with their thousand colors.
<G-vec01048-002-s188><admire.bewundern><de> Im Frühling und Herbst, vor allem aber in den Monaten September und Oktober, besuchen uns immer öfters die Liebhaber des freien Fluges hier in Canazei, um die zauberhaften Panoramen von oben bewundern und einen 360-Grad-Ausblick über die traumhaften Landschaften mit ihren 1000 Farben genießen zu können.
<G-vec01048-002-s189><admire.bewundern><en> There, you will admire many neoclassical houses.
<G-vec01048-002-s189><admire.bewundern><de> Dort wirst du viele neoklassizistische Häuser bewundern können.
<G-vec01048-002-s190><admire.bewundern><en> Fourteen orchid specialists in the Netherlands are opening their doors to allow clients and end-customers to admire their range.
<G-vec01048-002-s190><admire.bewundern><de> Vierzehn Orchideenspezialisten aus den Niederlanden öffnen ihre Türen, damit Kunden und Endkunden das Sortiment bewundern können.
<G-vec01048-002-s191><admire.bewundern><en> Located in Garfagnana (Lucca), the Cove of the Wind is full of comfortable paths that allow you to admire the wonders of the underground world in the light of the floodlights: from the stalactites and stalagmites alive and brilliant.
<G-vec01048-002-s191><admire.bewundern><de> Lucca Hohe Versilia Die Cove of the Wind in Garfagnana (Lucca) bietet viele bequeme Wege, auf denen Sie die Wunder der unterirdischen Welt im Schein der Flutlichter bewundern können: von den lebendigen und brillanten Stalaktiten und Stalagmiten.
<G-vec01048-002-s192><admire.bewundern><en> Admire the hard-to-forget cityscape of Split as we begin our speedboat tour.
<G-vec01048-002-s192><admire.bewundern><de> Beschreibung Bewundern Sie die Sicht auf Split aus unserem Schnellboot.
<G-vec01048-002-s193><admire.bewundern><en> Watch the confectioners model marzipan, admire the life-size Marzipan figures and let yourself be tempted by all the Niederegger Marzipan specialities on the cake buffet. Services included:
<G-vec01048-002-s193><admire.bewundern><de> Schauen Sie den Spezialisten beim Model-lieren über die Schulter, bewundern Sie die lebensgroßen Marzipan-Figuren und lassen Sie sich am großen Kuchenbuffet von süßen Niederegger Spezialitäten verführen.
<G-vec01048-002-s194><admire.bewundern><en> Admire the rustic knight's cellar deep under the houses of Chiusa/Klausen at the Hotel Walther von der Vogelweide.
<G-vec01048-002-s194><admire.bewundern><de> Bewundern Sie den rustikalen Ritterkeller tief unter den Häusern von Klausen im Hotel Walther von der Vogelweide.
<G-vec01048-002-s195><admire.bewundern><en> Admire the architecture that brings to mind pre-Columbian pyramids, enjoy its green spaces, its port, its beaches and its wide range of entertainment options.
<G-vec01048-002-s195><admire.bewundern><de> Bewundern Sie die Architektur, die an die präkolumbianischen Pyramiden erinnert, genießen Sie die grünen Parks, den Hafen, die Strände und die außergewöhnlich abwechslungsreiche Animation.
<G-vec01048-002-s196><admire.bewundern><en> Sit out on the terrace and admire views over the charming cove with its typical white houses, golden sands and the Mediterranean beyond.
<G-vec01048-002-s196><admire.bewundern><de> Entspannen Sie auf der Terrasse und bewundern Sie den Blick über die bezaubernde Bucht mit den typischen weißen Häusern, dem goldenen Sandstrand und dem Mittelmeer im Hintergrund.
<G-vec01048-002-s197><admire.bewundern><en> Admire the view of the river and facades of houses on the other side.
<G-vec01048-002-s197><admire.bewundern><de> Bewundern Sie den Blick auf den Fluss und auf die Fassaden der Häuser auf der anderen Seite.
<G-vec01048-002-s198><admire.bewundern><en> Book flights to the Netherlands and admire the thousands of flowers at the Keukenhof, purchase a Delftware vase in Delft or spot deer on the Veluwe.
<G-vec01048-002-s198><admire.bewundern><de> Buchen Sie einen Flug in die Niederlande und bewundern Sie Tausende von Blüten im Keukenhof; kaufen Sie eine Delftervase in Delft oder gehen Sie auf Wildbeobachtung auf dem Veluwe.
<G-vec01048-002-s199><admire.bewundern><en> Against a backdrop of high tide or low tide, admire the Tatihou Island.
<G-vec01048-002-s199><admire.bewundern><de> Im Hintergrund, bei Flut oder Ebbe, bewundern Sie die Insel Tatihou.
<G-vec01048-002-s200><admire.bewundern><en> Use your New York Explorer Pass to hop on the Ellis Island ferry, get up close to the world-famous green copper statue, and admire her torch and crown.
<G-vec01048-002-s200><admire.bewundern><de> Besteigen Sie die Ellis-Island-Fähre, gelangen Sie in die Nähe der weltberühmten grünen Kupferstatue und bewundern Sie ihre Fackel und ihre Krone.
<G-vec01048-002-s201><admire.bewundern><en> Be sure to make a short detour to visit the Schatzalp Alpinum to admire over 1,300 different species of plant grown there
<G-vec01048-002-s201><admire.bewundern><de> Machen Sie auch einen Abstecher ins Alpinum Schatzalp und bewundern Sie die über 1'300 Pflanzenarten.
<G-vec01048-002-s202><admire.bewundern><en> Paragliding Fly away on a two-seater with a professional pilot, and fly over Tenerife Island through stunning flying sites to admire absolutely breathtaking views of the oceans, volcanoes, mountains, cliffs and ravines.
<G-vec01048-002-s202><admire.bewundern><de> Ansehen Paragliding Fliegen Sie auf einem Zweisitzer mit einem professionellen Piloten über die Insel Teneriffa und bewundern Sie den atemberaubenden Anblick von Meer, Bergen, Klippen und Schluchten.
<G-vec01048-002-s203><admire.bewundern><en> Admire Leonardo da Vinci's iconic Last Supper with entry to the Church of Santa Maria delle Grazie.
<G-vec01048-002-s203><admire.bewundern><de> Bewundern Sie Leonardo da Vincis Meisterwerk „Das Letzte Abendmahl“ in der Kirche Santa Maria delle Grazie.
<G-vec01048-002-s204><admire.bewundern><en> Admire the historical house downtown, especially in Römerhofgasse, many of them boast ornaments, paintings and decorations.
<G-vec01048-002-s204><admire.bewundern><de> Bewundern Sie die historischen Häuser in der Innenstadt, insbesondere in der Römerhofgasse, oft reich verziert und kunstvoll bemalt.
<G-vec01048-002-s205><admire.bewundern><en> Relax in the cosy beer garden and admire the green surroundings.
<G-vec01048-002-s205><admire.bewundern><de> Entspannen Sie im gemütlichen Biergarten und bewundern Sie die grüne Umgebung.
<G-vec01048-002-s206><admire.bewundern><en> Navigate between the Gulf of Morbihan islands, admire the beautiful scenery and enjoy a relaxing stop at Belle island at sea, Houat and Hoëdic.
<G-vec01048-002-s206><admire.bewundern><de> Navigieren Sie zwischen den Inseln des Golfs von Morbihan, bewundern Sie die wunderschöne Landschaft und genießen Sie einen erholsamen Aufenthalt auf Belle Ille en Mer, Houat und Hoedic.
<G-vec01048-002-s207><admire.bewundern><en> Entertain friends in your private salon, peer out over panoramic balcony views, or just admire the elevated wood-beamed ceilings of this fabulously designed space.
<G-vec01048-002-s207><admire.bewundern><de> Laden Sie Freunde in Ihr privates Wohnzimmer ein, lassen Sie vom Panorama-Balkon aus Ihren Blick schweifen oder bewundern Sie einfach das unverwechselbare Design dieses Raumes mit seinen hohen, holzverkleideten Decken.
<G-vec01048-002-s208><admire.bewundern><en> Leave our house and walk through the flowered narrow streets of Saint-Suliac, admire the well conserved, very old stone-built houses with their colored window woodwork and their beautiful small gardens.
<G-vec01048-002-s208><admire.bewundern><de> Begehen Sie die beblumten Gässchen von Saint-Suliac, bewundern Sie die gut erhaltenen, jahrhundertealten Steinhäuser des Dorfes mit ihren bunten Fenstern und Türen und den hübschen Gärten.
<G-vec01048-002-s209><admire.bewundern><en> In the evening, admire illuminated landmarks like the Louvre and Eiffel Tower on a guided walk ending in the trendy St-Germain neighborhood. Learn More
<G-vec01048-002-s209><admire.bewundern><de> Bewundern Sie bei Nacht beleuchtete Sehenswürdigkeiten wie den Eiffelturm, die Kathedrale Notre Dame und das Louvre Museum auf einem Spaziergang entlang der Seine.
<G-vec01048-002-s210><admire.bewundern><en> Admire the fairytale winter landscape that slowly passes and changes before your eyes.
<G-vec01048-002-s210><admire.bewundern><de> Bewundern Sie die märchenhafte Winterlandschaft, die langsam an Ihnen vorbeizieht.
<G-vec01048-002-s211><admire.bewundern><en> Should an artist whose work you admire give you a compliment such as, "I love the colors in this," this means they are not only nice enough to compliment you on your work, but have taken the time to understand and appreciate the choices you made.
<G-vec01048-002-s211><admire.bewundern><de> Sollte ein Künstler, dessen Werk du bewunderst, dir ein Kompliment wie „ich liebe die Farben in diesem Bild“ machen, dann bedeutet dies, dass er nicht nur so nett ist, dir ein Kompliment bezüglich deiner Arbeit zu machen, sondern dass er sich auch die Zeit nimmt zu verstehen und die Entscheidungen, die du getroffen hast, zu schätzen weiß.
<G-vec01048-002-s212><admire.bewundern><en> – I show you how successful I am, thus you admire me and like me.
<G-vec01048-002-s212><admire.bewundern><de> – Ich zeige Dir, wie erfolgreich ich bin, dann bewunderst Du mich und magst mich.
<G-vec01048-002-s213><admire.bewundern><en> Ignore everyone who makes you feel bad about yourself, Try being like someone you admire but don't copy them .
<G-vec01048-002-s213><admire.bewundern><de> Ignoriere jeden, durch den du dich schlecht fühlst, versuche wie jemand zu sein, den du bewunderst, aber kopiere ihn nicht.
<G-vec01048-002-s214><admire.bewundern><en> Maybe someone you admire commented and told you a hot tip on how to boost the bass.
<G-vec01048-002-s214><admire.bewundern><de> Vielleicht hat jemand, den du bewunderst, einen Kommentar hinterlassen und dir einen heißen Tipp gegeben, wie du den Bass boosten kannst.
<G-vec01048-002-s215><admire.bewundern><en> Look for posh people you admire.
<G-vec01048-002-s215><admire.bewundern><de> Finde andere vornehme Menschen, die du bewunderst.
<G-vec01048-002-s216><admire.bewundern><en> Think about all of the hairstyles you admire, and gather photos of them.
<G-vec01048-002-s216><admire.bewundern><de> Überlege dir, welche Frisuren du bei anderen immer bewunderst und sammele Fotos davon.
<G-vec01048-002-s217><admire.bewundern><en> From every side you admire her sexy hands.
<G-vec01048-002-s217><admire.bewundern><de> Von jeder Seite bewunderst du ihr sexy Hände.
<G-vec01048-002-s218><admire.bewundern><en> There, you’ll admire the Temple of Apollo (where the oracle of Delphi, the Pythia, transmitted Appolo’s directives from the gods to humans), the theatre and the stadium.
<G-vec01048-002-s218><admire.bewundern><de> Dort bewunderst du den Tempel des Apollo (wo das Orakel von Delphi, die Pythia, die Direktiven von Appolo von den Göttern auf den Menschen übertragen hat), das Theater und das Stadion.
<G-vec01048-002-s219><admire.bewundern><en> For example, consider a few people whom you admire.
<G-vec01048-002-s219><admire.bewundern><de> Denke zum Beispiel über ein paar Menschen nach, die du bewunderst.
<G-vec01048-002-s220><admire.bewundern><en> You could also imagine yourself as someone else, and think about what qualities you admire in them.
<G-vec01048-002-s220><admire.bewundern><de> Du könntest dir dich selbst auch als jemand anderen vorstellen und über die Eigenschaften nachdenken, die du an ihm bewunderst.
<G-vec01048-002-s221><admire.bewundern><en> When you reach the bottom, you take a candle and tramp through drifts and tunnels where throngs of men are digging and blasting; you watch them send up tubs full of great lumps of stone--silver ore; you select choice specimens from the mass, as souvenirs; you admire the world of skeleton timbering; you reflect frequently that you are buried under a mountain, a thousand feet below daylight; being in the bottom of the mine you climb from “gallery” to “gallery”, up endless ladders that stand straight up and down; when your legs fail you at last, you lie down in a small box-car in a cramped “incline” like a half-up-ended sewer and are dragged up to daylight feeling as if you are crawling through a coffin that has no end to it.
<G-vec01048-002-s221><admire.bewundern><de> Kommst du unten an, nimmst du dir eine Kerze und strolchst durch Stollen und Strecken, wo Scharen von Männern häuen und sprengen; du siehst zu, wie sie Fässer voller großer Gesteinsbrocken – Silbererz – nach oben schicken; suchst dir als Andenken ein paar schöne Stücke aus; bewunderst das ungeheure Skelett der Verzimmerung; überlegst dir alle paar Augenblicke, dass du dreihundert Meter unter der Erdoberfläche in einem Berg begraben bist; da du dich an der tiefsten Stelle der Mine befindest, kletterst du von Sohle zu Sohle endlose und ganz steil stehende Leitern hinauf; können deine Beine dann schließlich nicht mehr, legst du dich in einem engen Schrägschacht, der wie ein halb hochgestellter Abzugskanal anmutet, in einen „Hund“ und lässt dich ans Tageslicht ziehen, wobei es dir vorkommt, als kröchest du durch einen Sarg, der kein Ende hat.
<G-vec01048-002-s222><admire.bewundern><en> They just influence you, especially if they are people you respect and admire.
<G-vec01048-002-s222><admire.bewundern><de> Sie beeinflussen dich einfach, insbesondere, wenn es Leute sind, die du respektierst und bewunderst.
<G-vec01048-002-s223><admire.bewundern><en> Identify two people you most admire.
<G-vec01048-002-s223><admire.bewundern><de> Identifiziere zwei Menschen, die du am meisten bewunderst.
<G-vec01048-002-s224><admire.bewundern><en> Admire the contemporary design throughout, with minimalist furniture and hardwood floors
<G-vec01048-002-s224><admire.bewundern><de> Bewundert das moderne Design mit minimalistischen Möbeln und Holzböden.
<G-vec01048-002-s225><admire.bewundern><en> Just know that everyone will appreciate your efforts and admire you for having written and given a eulogy.
<G-vec01048-002-s225><admire.bewundern><de> Sei dir bewusst, dass jeder deine Bemühungen zu schätzen weiß und dich bewundert, dass du die Traueransprache geschrieben und gehalten hast.
<G-vec01048-002-s226><admire.bewundern><en> The choice of the name is due to the fact that from a window of our house you can admire the river Adige, which passes through Verona.
<G-vec01048-002-s226><admire.bewundern><de> Die Wahl des Namens beruht auf die Tatsache, dass aus einem Fenster des Hauses der Fluss: die Etsch, welche durch Verona fließt, bewundert werden kann.
<G-vec01048-002-s227><admire.bewundern><en> And a first generation electric car from circa 1900 with be in action to admire.
<G-vec01048-002-s227><admire.bewundern><de> Außerdem kann ein Elektroauto der allerersten Generation aus der Zeit um 1900 in Aktion bewundert werden.
<G-vec01048-002-s228><admire.bewundern><en> After all, all images need a medium which we can use to expose and admire them.
<G-vec01048-002-s228><admire.bewundern><de> Ind er Tat benötigen alle Bilder ein Medium, um ausgestellt und bewundert zu werden.
<G-vec01048-002-s229><admire.bewundern><en> You can admire the original at the Musée d'Orsay in Paris.
<G-vec01048-002-s229><admire.bewundern><de> Das Original kann im Musée d'Orsay in Paris bewundert werden.
<G-vec01048-002-s230><admire.bewundern><en> Our ambition is not to rule the world – if you are making wine with your heart, you don’t have the time – we prefer to admire the sunset.
<G-vec01048-002-s230><admire.bewundern><de> Wir haben keine Ambitionen, die Weltherrschaft anzutreten – wenn man Wein mit dem Herzen erzeugt, hat man keine Zeit dafür – man bewundert lieber den Sonnenuntergang.
<G-vec01048-002-s231><admire.bewundern><en> Not only did they admire us, we were also fascinated by the things they brought with them.
<G-vec01048-002-s231><admire.bewundern><de> Nicht nur sie haben uns bewundert auch wir waren fasziniert über die Sachen, die sie mitgebracht haben.
<G-vec01048-002-s232><admire.bewundern><en> If your feet need some rest, take one of the Batobus boats on the banks of the Seine river and admire the city from the water.
<G-vec01048-002-s232><admire.bewundern><de> Wem die Füße müde werden, der nimmt am Ufer der Seine ein Boot der Batobus-Flotte und bewundert die Stadt vom Wasser aus.
<G-vec01048-002-s233><admire.bewundern><en> Respect their culture, their beliefs, they will be improved over time and stay discrete and admire these people who have suffered so much.
<G-vec01048-002-s233><admire.bewundern><de> Respektiert ihre Kultur, ihren Glauben, sie werden sich im Laufe der Zeit verbessern und bleibt diskret und bewundert diese Menschen, die so viel gelitten haben.
<G-vec01048-002-s234><admire.bewundern><en> It has been traditional to admire this mountain face from the fjord, but in recent years, it has become increasingly...
<G-vec01048-002-s234><admire.bewundern><de> Lange Zeit wurde diese Felswand nur vom Fjord aus bewundert, doch seit einigen Jahren erfreut sich der Wanderpfad hinauf...
<G-vec01048-002-s235><admire.bewundern><en> Enjoy walking through cobble-stoned tiny streets and admire the medieval architecture.
<G-vec01048-002-s235><admire.bewundern><de> Genießt einen Spaziergang durch die engen Kopfsteinpflasterstraßen und bewundert die mittelalterliche Architektur.
<G-vec01048-002-s236><admire.bewundern><en> As we hang around the streets, there are many details we can admire during the route.
<G-vec01048-002-s236><admire.bewundern><de> Wenn wir durch die Straßen wandern, gibt es viele Details, die hier auf unserer Route bewundert werden können.
<G-vec01048-002-s237><admire.bewundern><en> They thought any man alive, waking up in a coffin to find himself canonized like a saint, and made into a walking miracle for everyone to admire, would be swept along with his worshippers and accept the crown of glory that fell on him out the sky.
<G-vec01048-002-s237><admire.bewundern><de> Sie dachten sich, daß jeder lebende Mensch, der in einem Sarg aufwacht und wie ein Heiliger verehrt wird und in ein wandelndes Wunder verwandelt ist, das jedermann bewundert, von seinen Verehrern mitgerissen würde und die Krone des Ruhmes annähme, die da aus dem Himmel auf ihn gefallen ist.
<G-vec01048-002-s238><admire.bewundern><en> To this day, many characteristics of historical design have remained intact, so that you can still admire them in the park. For example, the ornate, affectionately inscribed benches invite every visitor to a moment of repose.
<G-vec01048-002-s238><admire.bewundern><de> Bis heute sind viele der historischen Gestaltungselemente erhalten geblieben und können nach wie vor im Park bewundert werden: So zum Beispiel die liebevoll mit Inschriften verzierten Bänke, die jeden Besucher zu einem Moment der Rast einladen.
<G-vec01048-002-s239><admire.bewundern><en> Nevertheless this stentorian accompagnato for bass is one of Bach’s most elaborate and subtle pieces of musical sermonising, so much so that one easily sidesteps the verbal crudity to admire the care Bach lavishes on the smallest detail of verbal inflection: his autograph score shows, for example, how he sharpened the rhythm of the word ‘Teufelsbrut’ (‘devil’s brood’) to make its impact more abrupt and brutal.
<G-vec01048-002-s239><admire.bewundern><de> Gleichwohl ist dieses stimmgewaltige Accompagnato für Bass eines der kunstreichsten und feinsinnigsten Stücke musikalischer Moralpredigten Bachs, in einem Maße, dass man leicht über den ungeschliffenen Text hinwegsehen kann und die Sorgfalt bewundert, die er der kleinsten Veränderung im Tonfall angedeihen lässt: Das Autograph der Partitur zeigt zum Beispiel, wie er den Rhythmus des Wortes „Teufelsbrut“ verschärfte, um es schroffer und roher wirken zu lassen.
<G-vec01048-002-s240><admire.bewundern><en> Look at the nature and admire all the beauty He has created with the love of His hands.
<G-vec01048-002-s240><admire.bewundern><de> Schaut auf die Natur und bewundert die ganze Schönheit, die er durch die Liebe seiner Hände geschaffen hat.
<G-vec01048-002-s241><admire.bewundern><en> Among the monuments stand out the Orthodox Russian Church, built in 1913, that recalls the Church of San Basilio in Moscow, the Borea d’Olmo Palace, built up during the fifteenth century, that houses the Civic Museum, the San Siro Cathedral, built during the XII century, in pure Romanic-gothic style and the St John Baptistery, near the Cathedral, that dates back to the Baroque period (1688), where you can admire the "Holy Communion of Magdalene" by Orazio de Ferrari.
<G-vec01048-002-s241><admire.bewundern><de> Folgende Denkmäler treten hervor: Die Russisch-Orthodoxe Kirche, die 1913 gebaut wurde und an die Basilius-Kathedrale von Moskau erinnert; den Borea D’Olmo Palast, der im fünfzehnten Jahrhundert errichtet wurde und das Stadtmuseum beherbergt; die San Siro Basilika, die im XII Jahrhundert in reinem romanisch-gotischen Stil errichtet wurde, und neben der Basilika die Taufkapelle Sankt Johannes', die auf die Barockzeit (1688) zurückgeht und wo die „Comunione della Maddalena“ (Kommunion der Magdalena) von Orazio de Ferrari bewundert werden kann.
<G-vec01048-002-s242><admire.bewundern><en> In Early Christian and early Medieval times, the main Roman buildings, in particular the baths were refurbished with construction, among other things, of a Early Christian baptistery where visitors can still today admire the baptismal font for complete immersion.
<G-vec01048-002-s242><admire.bewundern><de> In frühchristlicher und frühmittelalterlicher Zeit erlebten die wichtigsten römischen Bauten, insbesondere die Thermen, verschiedene Veränderungen, unter anderem mit dem Bau eines frühchristlichen Baptisteriums, dessen achteckige Taufwanne noch heute bewundert werden kann.
<G-vec01048-002-s258><admire.bewundern><en> Guests can get back to nature with a relaxing stroll through verdant parks and gardens, admire ornate churches or visit Bessarabian market for fresh produce.
<G-vec01048-002-s258><admire.bewundern><de> Gäste können außerdem einen entspannten Spaziergang durch die üppig begrünten Parks und Gärten machen, die wunderschön verzierten Kirchen bewundern oder in der Bessarabska-Markthalle frisches Obst und Gemüse kaufen.
<G-vec01048-002-s259><admire.bewundern><en> Visitors can admire gold ornamental art and ancient Greek weapons from the ancient Macedonia area as well as from neighbouring areas too.
<G-vec01048-002-s259><admire.bewundern><de> Besucher können die goldenen Wandmalereien, alte grieschiche Waffen aus Mazedonien und den Nachbargebieten bewundern.
<G-vec01048-002-s260><admire.bewundern><en> You can admire the landscape of cliffs torn by water and wind, including the famous Raz du Sein.
<G-vec01048-002-s260><admire.bewundern><de> Sie können die Felsenlandschaft bewundern, die vom Wasser und Wind zerfasert wurde, worunter der berühmte Raz de Sein.
<G-vec01048-002-s261><admire.bewundern><en> When in Krakow, take a walk in the historic centre and admire its rich Renaissance architecture with some intersting examples of Baroque and Gothic.
<G-vec01048-002-s261><admire.bewundern><de> Wenn Sie nach Krakau reisen, sollten Sie unbedingt einen Spaziergang durch das historische Stadtzentrum unternehmen und die ausgeprägte Architektur im Renaissance-Stil sowie die barocken und gotischen Einflüsse bewundern.
<G-vec01048-002-s262><admire.bewundern><en> Katafiki: Hike (approx. 80 minutes), admire and enjoy nature.
<G-vec01048-002-s262><admire.bewundern><de> Katafiki: Wandern (rund 80 Minuten), die Natur bewundern und genießen.
<G-vec01048-002-s263><admire.bewundern><en> Leave the rat race behind and visit Zaandam where you can not only admire traditional architecture but also enjoy beautiful nature.
<G-vec01048-002-s263><admire.bewundern><de> Lassen Sie den Alltag hinter sich und gönnen Sie sich einen erholsamen Kurzurlaub in Zaandam, in dem Sie nicht nur die traditionelle Architektur bewundern, sondern auch die wunderschöne Natur genießen können.
<G-vec01048-002-s264><admire.bewundern><en> For your relaxation, La Cortevecchia offers a large and welcoming courtyard with seasonal plants and flowers, where you can entertain yourself, admire the beautiful bell tower of Sant'Alessandro, or just read a book.
<G-vec01048-002-s264><admire.bewundern><de> Für Ihre Entspannung bietet La Cortevecchia einen großen und einladenden Innenhof mit Pflanzen und Blumen, in denen Sie die ganze Schönheit des wunderschönen Glockenturms von Sant'Alessandro bewundern oder einfach nur ein Buch lesen können.
<G-vec01048-002-s265><admire.bewundern><en> The last few days I was able to move a lot en plein air and to admire the rich green tones of nature.
<G-vec01048-002-s265><admire.bewundern><de> Die letzten Tage durfte ich mich viel in der Natur bewegen und die inzwischen satten Grüntöne der Natur bewundern.
<G-vec01048-002-s266><admire.bewundern><en> Each year, more than 3 million visitors come from all over the world to admire the abbey and bay of Mont Saint-Michel, both listed as a UNESCO World Heritage Site.
<G-vec01048-002-s266><admire.bewundern><de> Jedes Jahr strömen mehr als 3 Millionen Besucher aus der ganzen Welt hierher, um die Abtei und die Bucht des Mont-Saint-Michel zu bewundern, die beide als UNESCO-Weltkulturerbe klassifiziert sind.
<G-vec01048-002-s267><admire.bewundern><en> You can admire exhibitions dedicated to Archaic, Hellenistic and Roman season, which include statues, ceramic and mosaics.
<G-vec01048-002-s267><admire.bewundern><de> Man kann die Ausstellungen, die der archaischen, hellenistischen und römischen Epoche gewidmet sind und Statün, Keramik und Mosaik beinhalten, bewundern.
<G-vec01048-002-s268><admire.bewundern><en> The hotel's position makes it possible to visit artisan workshops exhibiting ancient traditional pottery techniques, to see unique works of art, to enjoy day trips to the splendid Tremiti Islands, and admire uncontaminated wilderness during long walks.
<G-vec01048-002-s268><admire.bewundern><de> Dank der Lage des Hotels können Sie Künstlerwerkstätten besuchen, die antike traditionelle Töpfereitechniken vorführen und einmalige Kunstwerke ausstellen, Tagesausflüge zu den wunderbaren Tremiti-Inseln machen und die Wildnis beim Wandern bewundern.
<G-vec01048-002-s269><admire.bewundern><en> In some planetariums, the function of playing nature sounds is built in, and the dynamic projection allows you to admire colorful Hawaiian sunsets, Northern lights or a fantastic rainbow.
<G-vec01048-002-s269><admire.bewundern><de> In einigen Planetarien ist die Funktion des Spielens von Naturgeräuschen eingebaut, und die dynamische Projektion ermöglicht es Ihnen, die bunten hawaiianischen Sonnenuntergänge, die Nordlichter oder den fantastischen Regenbogen zu bewundern.
<G-vec01048-002-s314><admire.bewundern><en> Of course, everyone goes to the Isola Bella as it is also beautiful and you can admire the unique Palazzo Borromeo.
<G-vec01048-002-s314><admire.bewundern><de> Natürlich fährt jeder zur Isola Bella, da sie auch wunderschön ist und ihr hier den einzigartigen Palazzo Borromeo bewundern könnt.
<G-vec01048-002-s315><admire.bewundern><en> Visitors can admire and buy cut crystal pieces - classic crystal chandeliers, modern light fixtures, enchanting light objects, unique glass sculptures, exclusive crystal costume jewellery, fashion accessories, figurines and gift items.
<G-vec01048-002-s315><admire.bewundern><de> Besucher können hier geschliffenes Kristallglas bewundern und kaufen – klassische Kristall-Kronleuchter, moderne Designer-Leuchtkörper, Geschenkartikel.
<G-vec01048-002-s316><admire.bewundern><en> On the one hand we can admire the enormous sliding feet that provide the necessary glide to the mouse.
<G-vec01048-002-s316><admire.bewundern><de> Zum einen können wir hier die enorm großen Gleitfüße bewundern, die für die nötigen Gleiteigenschaften der Maus sorgen.
<G-vec01048-002-s317><admire.bewundern><en> But it's not only the view that you can admire.
<G-vec01048-002-s317><admire.bewundern><de> Es ist nicht nur die Aussicht, die man hier bewundern kann.
<G-vec01048-002-s318><admire.bewundern><en> It is in 5 minutes on the Rhine and can admire the chic port of entry, or go to the chocolate museum or Sports and Olympic Museum.
<G-vec01048-002-s318><admire.bewundern><de> Man ist in 5 Minuten am Rhein und kann hier den schicken Zollhafen bewundern oder ins Schokoladenmuseum oder Sport- und Olympiamuseum gehen.
<G-vec01048-002-s319><admire.bewundern><en> In every season you can admire the most diverse flowers.
<G-vec01048-002-s319><admire.bewundern><de> Zu jeder Jahreszeit kann man hier die unterschiedlichste Blütenpracht bewundern.
<G-vec01048-002-s320><admire.bewundern><en> With luck, visitors can admire the last truly wild elephants, lions and rhinos.
<G-vec01048-002-s320><admire.bewundern><de> Mit viel Glück können Besucher hier die letzten wirklich wilden Elefanten, Löwen und Nashörner bewundern.
<G-vec01048-002-s329><admire.bewundern><en> Guests will admire views across the Adriatic Sea from the rooms.
<G-vec01048-002-s329><admire.bewundern><de> Gäste können Aussicht auf den Persische Golf von ihren Zimmern bewundern.
<G-vec01048-002-s330><admire.bewundern><en> Listen to Dreaming stories told by local Aboriginal guides and admire the work of resident artists before retiring to a luxury retreat surrounded by wilderness. Don't miss
<G-vec01048-002-s330><admire.bewundern><de> Sie können sich die Traumgeschichten von lokalen Aborigines-Guides anhören und die Werke ansässiger Künstler bewundern, bevor Sie sich in ein Luxus-Resort inmitten der Wildnis zurückziehen.
<G-vec01048-002-s331><admire.bewundern><en> Guests will admire views across Millennium Park and Lake Michigan from the rooms.
<G-vec01048-002-s331><admire.bewundern><de> Gäste können Aussicht auf den Grant Park und den Michigan See von ihren Zimmern bewundern.
<G-vec01048-002-s332><admire.bewundern><en> So a tour of the castle offers not just the opportunity to admire the Late Gothic and Renaissance interiors, but also to enjoy the museum’s collection.
<G-vec01048-002-s332><admire.bewundern><de> Bei Besichtigung der Burg können Sie also neben spätgotischen und Renaissance-Interieuren auch eine umfangreiche Museumsausstellung bewundern.
<G-vec01048-002-s333><admire.bewundern><en> Guests will admire views across Canal Grande and Grand Canal from the rooms.
<G-vec01048-002-s333><admire.bewundern><de> Gäste können Aussicht auf den Venetian Kanal von ihren Zimmern bewundern.
<G-vec01048-002-s334><admire.bewundern><en> Come and admire the five tidewater glaciers and high-altitude glaciers.
<G-vec01048-002-s334><admire.bewundern><de> Sie können fünf Gezeitengletscher und ebenso viele Hochgebirgsgletscher bewundern.
<G-vec01048-002-s335><admire.bewundern><en> Inside The Rainforest, you’ll also get a chance to admire the endangered Sumatran tigers prowling around.
<G-vec01048-002-s335><admire.bewundern><de> Im Regenwald können Sie die vom Aussterben bedrohten Sumatra-Tiger bewundern.
<G-vec01048-002-s336><admire.bewundern><en> This is a place not just to admire the established stars of the literary scene, but also to discover writers who have (not yet) had their big break.
<G-vec01048-002-s336><admire.bewundern><de> Im Haus für Poesie können Leser nicht nur die Stars der Literaturszene bewundern, sondern auch Dichter entdecken, die den großen Durchbruch (noch) nicht geschafft haben.
<G-vec01048-002-s337><admire.bewundern><en> At the third, at the Pertiller Mill, head off the main road, admire the local canyon, play and refresh in a great bath.
<G-vec01048-002-s337><admire.bewundern><de> Bei der dritten Mühle, Mühle „Pertiller”, können wir vom Wanderweg abschwenken und den lokalen Engpass bewundern, weiterhin ist es möglich, hier zu spielen und sich nach einem Bad zu erfrischen.
<G-vec01048-002-s338><admire.bewundern><en> In Theologos village you will find the famous ‘valley of the butterflies’ while in Lindos you will admire the simple beauty of the traditional island architecture by walking on its little cobblestone streets.
<G-vec01048-002-s338><admire.bewundern><de> Im Dorf Theologos finden Sie das berühmte „Tal der Schmetterlinge“ und in Lindos können Sie die einfache Schönheit der traditionellen Architektur der Insel bewundern, indem sie durch die schmalen Pflastersteingassen schlendern.
<G-vec01048-002-s339><admire.bewundern><en> Admire the local flora and fauna during your bike rides. Watch the video
<G-vec01048-002-s339><admire.bewundern><de> Bei der Radtour können Sie die Flora und Fauna von Brière bewundern.
<G-vec01048-002-s340><admire.bewundern><en> An enchanted place where you can walk in the forest following the many itineraries that cross the valley or admire the treasures preserved in the Museum of Sacred Art of the Abbey.
<G-vec01048-002-s340><admire.bewundern><de> Ein bezaubernder Ort, wo Sie im Wald spazieren gehen können und die vielen Wanderwegen folgen können oder die Schätze bewundern, die im Museum für sakrale Kunst der Abtei aufbewahrt werden.
<G-vec01048-002-s341><admire.bewundern><en> political heart of Florence, San Giovanni Square and Signoria Square, where you will admire the majestic Cathedral (exterior) and Palazzo Vecchio (exterior.)
<G-vec01048-002-s341><admire.bewundern><de> Daher können Sie die majestätische Kathedrale (von außen) und den Palazzo Vecchio bewundern (von außen).
<G-vec01048-002-s401><admire.bewundern><en> Admire the typical fabulous Highland landscape as well as the Merina population with their Asian features.
<G-vec01048-002-s401><admire.bewundern><de> Sie werden die typischen Sehenswürdigkeiten der Hochebene bewundern und feststellen, wie ihre Bevölkerung asiatische Züge aufweist.
<G-vec01048-002-s402><admire.bewundern><en> Discover the lacustrine region and admire the wonderful landscapes of the Coast.
<G-vec01048-002-s402><admire.bewundern><de> Entdecken Sie die Region aus einer lakustrischen Perspektive, während Sie die herrlichen Landschaften der Küste bewundern.
<G-vec01048-002-s403><admire.bewundern><en> Cruise on country roads through the flowering tulips and park your Twizy beside the road to admire the sea of flowers up close.
<G-vec01048-002-s403><admire.bewundern><de> Fahren Sie auf Landstraßen durch die blühenden Tulpen und parken Sie Ihren Twizy neben der Straße, um das Meer der Blumen aus nächster Nähe zu bewundern.
<G-vec01048-002-s404><admire.bewundern><en> Katia loves running in the mountains for competition but also for fun just to get that feeling of freedom she loves and to admire the beauty of the landscapes surrounding her.
<G-vec01048-002-s404><admire.bewundern><de> Katia läuft liebend gerne in den Bergen, im Wettlauf oder auch nur zum Spaß, um das Gefühl der Freiheit zu genießen und die Schönheit der sie umgebenden Landschaften zu bewundern.
<G-vec01048-002-s405><admire.bewundern><en> You pick up the check and put it on your credit card, because you want everyone at the table to admire you and like you more.
<G-vec01048-002-s405><admire.bewundern><de> Sie heben die Überprüfung auf und setzen sie auf Ihre Kreditkarte, weil Sie jeder am Tisch Sie bewundern und Sie mehr mögen wünschen.
<G-vec01048-002-s406><admire.bewundern><en> Live an exciting experience on the Lake Como to admire the nature and the several stately villas situated on the banks of the lake.
<G-vec01048-002-s406><admire.bewundern><de> Machen Sie eine unvergessliche Erfahrung bei der Entdeckung des Comer Sees oder halten Sie in der Mitte des Sees inne, um die unzähligen Villen am Ufer zu bewundern.
<G-vec01048-002-s407><admire.bewundern><en> In the country house we can admire the seventeenth frescoes and the 12000 mq Italian park.
<G-vec01048-002-s407><admire.bewundern><de> In dem herrschaftlichen Haus können Sie die siebzehnte Fresko und das 12000 mq Italian Park bewundern.
<G-vec01048-002-s408><admire.bewundern><en> From here it will be possible to admire the splendid panorama and the sapphire blue waters of the lake.
<G-vec01048-002-s408><admire.bewundern><de> Von hier aus können Sie das herrliche Panorama und das Saphirblau des Sees bewundern.
<G-vec01048-002-s409><admire.bewundern><en> Whatever direction you admire it from, the Ponte 25 de Abril – spanning the Tagus for 2.3 km between Lisbon’s trendy Docas (docks) area and the suburb of Alameda – is one of the most impressive landmarks in Lisbon.
<G-vec01048-002-s409><admire.bewundern><de> Auf aus welcher Blickrichtung Sie sie bewundern, die Ponte 25 de Abril, die sich zwischen den schicken Lissabonner Docas (Hafenanlagen) und dem Vorort Alameda auf 2,3 Kilometern über den Tejo erstreckt, ist eines der eindrucksvollsten Wahrzeichen Lissabons.
<G-vec01048-002-s410><admire.bewundern><en> Adventurous visitors will also have the opportunity to climb the Drachenfels and admire the Rhine valley and the Siebengebirge from the airy heights.
<G-vec01048-002-s410><admire.bewundern><de> Wenn sich die Besucher Zeit nehmen und den Fels emporklettern, so haben sie die Gelegenheit, das Rheintal und das Siebengebirge aus luftiger Höhe zu bewundern.
<G-vec01048-002-s411><admire.bewundern><en> You will admire the surpassing design and the high-quality manufacture.
<G-vec01048-002-s411><admire.bewundern><de> Hier können Sie das einmalige Design und die hochwertige Verarbeitung bewundern.
<G-vec01048-002-s412><admire.bewundern><en> Or, simply admire the wonderful Modernist features of the building's architecture, the style for which the city is famous.Make use of your apartment's own kitchen to prepare meals as you like.
<G-vec01048-002-s412><admire.bewundern><de> Oder Sie bewundern einfach die modernen Elemente in der Architektur des Hauses - für diesen Stil erlangte die Stadt große Berühmtheit.In der eigenen Küche Ihres Apartments bereiten Sie sich Mahlzeiten zu, ganz wie es Ihnen beliebt.
<G-vec01048-002-s413><admire.bewundern><en> As long as you feel like their business is similar to yours or you admire them, or fear them stealing your shine; you are free to include whoever you want as your competitor.
<G-vec01048-002-s413><admire.bewundern><de> Solange Sie das Gefühl haben, dass ihr Geschäft Ihrem ähnlich ist oder Sie sie bewundern, oder Angst haben, dass sie Ihnen den Glanz stehlen, können Sie jeden, den Sie wollen, als Konkurrenten aufnehmen.
<G-vec01048-002-s414><admire.bewundern><en> Sail the green waters of Frias Lake to Puerto Frias, admire the stunning Tronador Hill and the condors flying around.
<G-vec01048-002-s414><admire.bewundern><de> Sie überqueren die grünen Gewässer des Sees Frias nach Puerto Frias, wobei Sie den atemberaubenden Tronador und Kondore im Flug bewundern.
<G-vec01048-002-s415><admire.bewundern><en> We can observe two different olive-growing techniques: uphill we can admire the classic “vase-shaped” pruning typical of these hills, whereas further down – and we will see this towards the end of our itinerary – we can see the arrangement and pruning typical of intensive olive-growing.
<G-vec01048-002-s415><admire.bewundern><de> Sie können zwei verschiedene Techniken der gebräuchlichen Kultivierung sehen: weiter oben können sie die typisch klassische Olive “a vaso” unserer Hügel bewundern, weiter unten, am Ende dieser Wegstrecke, können Sie die Anordnung und das typische Verhalten der Intensiv- Olivenkultivierung beobachten.
<G-vec01048-002-s416><admire.bewundern><en> Besides the advantage to arrive from Cancun to Holbox in only 25 minutes you will be able to admire the island from the sky.
<G-vec01048-002-s416><admire.bewundern><de> Sie können Holbox von Cancun in nur 25 Minuten erreichen und zusätzlich können Sie die Insel aus der Luft bewundern, was zweifellos eine erstaunliche Erfahrung sein wird.
<G-vec01048-002-s417><admire.bewundern><en> In the evening, guests can also admire African sunsets from the deck, while enjoying sundowners before a night out.
<G-vec01048-002-s417><admire.bewundern><de> Am Abend können Sie von der Terrasse die afrikanischen Sonnenuntergänge bewundern und einen Sundowner genießen, bevor Sie ausgehen.
<G-vec01048-002-s418><admire.bewundern><en> Diving is also very popular, you can admire many corals, anemones and a multitude of colourful fishes.
<G-vec01048-002-s418><admire.bewundern><de> Das Tauchen ist auch sehr beliebt, so können Sie die vielen Korallen, Anemonen und eine Vielzahl an bunten Fischen bewundern.
<G-vec01048-002-s419><admire.bewundern><en> It is not possible to admire all the city’s attractions in just a few days.
<G-vec01048-002-s419><admire.bewundern><de> In wenigen Tagen können Sie die vielen Sehenswürdigkeiten gar nicht alle bewundern.
