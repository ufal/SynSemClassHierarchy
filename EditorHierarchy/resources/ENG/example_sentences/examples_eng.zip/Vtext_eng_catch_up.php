<G-vec01001-002-s055><catch_up.aufholen><en> The top 16-20% of our market are getting sustainability, for the laggards, you will have to play a catch up game when the tipping point for sustainability is reached.
<G-vec01001-002-s055><catch_up.aufholen><de> Die Top 16 – 20 % aus unserem Markt verstehen was Nachhaltigkeit ist, die Nachzügler müssen schnell aufholen, wenn der Wendepunkt für Nachhaltigkeit erreicht ist.
<G-vec01001-002-s056><catch_up.aufholen><en> Maybe you cannot catch up.
<G-vec01001-002-s056><catch_up.aufholen><de> Es mag sein, du kannst nicht aufholen.
<G-vec01001-002-s057><catch_up.aufholen><en> We are in our position because the regulations are very complicated and Renault has probably underestimated the new technology and it is difficult to catch up now.
<G-vec01001-002-s057><catch_up.aufholen><de> Wir sind in unserer Situation, weil unser Motorhersteller die neue Technologie wahrscheinlich unterschätzt hat – und auch kaum aufholen kann.
<G-vec01001-002-s058><catch_up.aufholen><en> This gives rise to 4+ new shoots, while lateral branches have time to catch up, which in turn produces larger main buds on the ends of these branches.
<G-vec01001-002-s058><catch_up.aufholen><de> Dies führt dann zu mehr als 4 neuen Trieben, während die Seitenäste aufholen können, was wiederum zu größeren Blüten an den Enden dieser Zweige führt.
<G-vec01001-002-s059><catch_up.aufholen><en> Either player can “catch up” or “fall back” to match the other player.
<G-vec01001-002-s059><catch_up.aufholen><de> Jeder der beiden Spieler kann “ aufholen” oder “ zuruckfallen” um dem jeweils anderen Spieler gleichzukommen.
<G-vec01001-002-s060><catch_up.aufholen><en> On the long term, of course, Europe will also need to catch up with regard to the volume of financing.
<G-vec01001-002-s060><catch_up.aufholen><de> Langfristig muss Europa natürlich auch im Bereich Finanzierungssummen aufholen.
<G-vec01001-002-s061><catch_up.aufholen><en> We need to catch up a bit.
<G-vec01001-002-s061><catch_up.aufholen><de> Wir müssen etwas aufholen.
<G-vec01001-002-s062><catch_up.aufholen><en> When I am already very wet without the slightest resistance, I will accept your friend... literally in every position, we start classically, then from the back, I will run for a dog, I will catch up when you lie down..., do not forget to meet me for a long time.
<G-vec01001-002-s062><catch_up.aufholen><de> Wenn ich schon sehr nass bin ohne den geringsten Widerstand, werde ich deinen Freund akzeptieren... buchstäblich in jeder Position, wir fangen klassisch an, dann renne ich nach einem Hund, ich werde aufholen, wenn du dich hinlegst..., vergiss nicht, mich lange zu treffen.
<G-vec01001-002-s063><catch_up.aufholen><en> And also where tariffs, customer care and offers are concerned, the third largest communications company of Austria has been able to markedly catch up.
<G-vec01001-002-s063><catch_up.aufholen><de> Und auch in punkto Tarife, Kundenbetreuung und Angebote konnte Österreichs drittgrößtes Kommunikationsunternehmen in der Kundengunst stark aufholen.
<G-vec01001-002-s064><catch_up.aufholen><en> Nevertheless there are aspects where German universities can catch up, for example in weighting of course content.
<G-vec01001-002-s064><catch_up.aufholen><de> Nichtsdestotrotz gibt es Elemente, wo deutsche Universitäten aufholen können, beispielsweise in der Gewichtung von Lehrinhalten.
<G-vec01001-002-s065><catch_up.aufholen><en> This can also delay the publication of the Draft or Internet standard by many months (sometimes even years) while the other documents catch up.
<G-vec01001-002-s065><catch_up.aufholen><de> Das kann die Veröffentlichung des Entwurfs oder Internetstandards um viele Monate (manchmal sogar Jahre) verzögern, während die anderen Dokumente aufholen.
<G-vec01001-002-s066><catch_up.aufholen><en> Still, I’m sure we can catch up in the second half of the season.
<G-vec01001-002-s066><catch_up.aufholen><de> Aber ich bin sicher, dass wir in der Rückrunde aufholen können.
<G-vec01001-002-s067><catch_up.aufholen><en> All rows above are my try to catch up with my loss of scheduled knitting that happened at the first two days while being on birthday parties with the family.
<G-vec01001-002-s067><catch_up.aufholen><de> Alles darüber hinaus ist ein Aufholen dessen, was ich in den ersten Tagen durch Familienfeiern nicht geschafft habe.
<G-vec01001-002-s068><catch_up.aufholen><en> Wifi and Samsung Smart TV with iPlayer catch up and DVD player.
<G-vec01001-002-s068><catch_up.aufholen><de> Wifi und Samsung Smart TV mit iPlayer Aufholen und DVD-Player.
<G-vec01001-002-s069><catch_up.aufholen><en> The main reason for this is that a fund manager first has to catch up around 1% of performance until he has only covered his own annual costs.
<G-vec01001-002-s069><catch_up.aufholen><de> Hauptgrund dafür ist, dass ein Fondsmanager zuerst rund 1% an Performance aufholen muss, bis er nur überhaupt seine eigenen jährlichen Kosten gedeckt hat.
<G-vec01001-002-s070><catch_up.aufholen><en> This is a common reaction of SMEs and corporations who have hesitated for years and then want to catch up all at once.
<G-vec01001-002-s070><catch_up.aufholen><de> So reagieren häufig Mittelständler und Konzerne, die erst jahrelang gezögert haben und dann knallhart aufholen wollen.
<G-vec01001-002-s071><catch_up.aufholen><en> For children having deficiencies in motor skills, it is very difficult to catch up. Differences in fitness substantiate with time.
<G-vec01001-002-s071><catch_up.aufholen><de> Kinder können Entwicklungsrückstände in der motorischen Leistungsfähigkeit nur schwer aufholen, die Unterschiede in der Fitness verfestigen sich über die Zeit.
<G-vec01001-002-s072><catch_up.aufholen><en> Even though I had to catch up with the other students in most of my subjects, it was easier than I had expected.
<G-vec01001-002-s072><catch_up.aufholen><de> Ich musste zwar in den meisten Fächern im Vergleich zu meinen Mitschülern aufholen, aber das war leichter als ich gedacht hatte.
<G-vec01001-002-s073><catch_up.aufholen><en> Since I am such an incredibly late bloomer, I have a fear that I won't be able to catch up to everyone else.
<G-vec01001-002-s073><catch_up.aufholen><de> Weil ich so ein extremer Spätzünder bin, mache ich mir Sorgen, dass ich nicht mehr aufholen kann.
<G-vec01001-002-s093><catch_up.aufholen><en> In this respect, I would like to thank you on behalf of the Krone team and promise all voters that we will continue to do everything in our power over the next twelve months to defend our leading position among curtainsiders and to catch up further in the other categories.
<G-vec01001-002-s093><catch_up.aufholen><de> Insofern bedanke ich mich im Namen des Krone Teams und verspreche allen Wählern, dass wir auch in den kommenden zwölf Monaten alles daran setzen werden, die Spitzenposition bei den Curtainsidern zu verteidigen und in den anderen Kategorien weiter aufzuholen.
<G-vec01001-002-s094><catch_up.aufholen><en> By the middle of our afternoon session on our first day, I realized that we had already traveled very far and it would be difficult for anyone arriving late to catch up.
<G-vec01001-002-s094><catch_up.aufholen><de> Während unserer Nachmittagsbesprechung am ersten Tag erkannte ich, dass wir bereits weit gereist waren und dass es für jeden, der später kam, schwierig sein würde dies aufzuholen.
<G-vec01001-002-s095><catch_up.aufholen><en> The tutorial is written from a beginner's perspective, and you should be able to catch up without much trouble.
<G-vec01001-002-s095><catch_up.aufholen><de> Das Tutorial ist aus der Perspektive eines Anfängers geschrieben, und Sie sollten in der Lage sein, ohne viel Mühe aufzuholen.
<G-vec01001-002-s096><catch_up.aufholen><en> For Ukraine, #13 will most likely be their end result, too slow to catch up and too fast to lose.
<G-vec01001-002-s096><catch_up.aufholen><de> Für die Ukraine wird #13 wohl auch das Endergebnis sein zu langsam um aufzuholen und zu schnell, um zu verlieren.
<G-vec01001-002-s097><catch_up.aufholen><en> I had eleven lost years of knowledge to catch up.
<G-vec01001-002-s097><catch_up.aufholen><de> Ich hatte elf Jahre verlorenes Wissen aufzuholen.
<G-vec01001-002-s098><catch_up.aufholen><en> If you have not written any letter or handwritten messages lately, this week is perfect to catch up as it is "Thinking of You Week" that should inspire people to create a wave of love, caring and happiness by sending greeting cards.
<G-vec01001-002-s098><catch_up.aufholen><de> Wenn du in letzter Zeit keine Briefe oder handgeschriebenen Nachrichten geschrieben hast, ist diese Woche perfekt, um es aufzuholen, denn es ist "An dich denken Woche", die Leute dazu bringen sollte, eine Welle von Liebe, Fürsorge und Glück durch das Senden von Grußkarten zu erzeugen.
<G-vec01001-002-s099><catch_up.aufholen><en> In summary: Renzi is at a disadvantage, but retains the opportunity to catch up.
<G-vec01001-002-s099><catch_up.aufholen><de> Zusammengefasst: Renzi ist im Nachteil, aber behält die Möglichkeit aufzuholen.
<G-vec01001-002-s100><catch_up.aufholen><en> The place to meet, catch up, eat dishes from all corners of the globe, drink drinks, relax, read a book, listen to (live) music, work, date or forget about time.
<G-vec01001-002-s100><catch_up.aufholen><de> Der Ort, um sich zu treffen, aufzuholen, Gerichte aus allen Ecken der Welt zu essen, Getränke zu trinken, sich zu entspannen, ein Buch zu lesen, Musik zu hören, zu arbeiten, zu verabreden oder die Zeit zu vergessen.
<G-vec01001-002-s101><catch_up.aufholen><en> We have set ourselves on helping to catch up on this research backlog of almost 100 years.
<G-vec01001-002-s101><catch_up.aufholen><de> Wir haben uns zum Ziel gesetzt, dabei zu helfen, diesen Forschungsrückstand von fast 100 Jahren aufzuholen.
<G-vec01001-002-s102><catch_up.aufholen><en> We had some good luck and a very good strategy early on to catch back the two laps.
<G-vec01001-002-s102><catch_up.aufholen><de> Wir haben am Anfang etwas Glück und eine sehr gute Strategie gehabt, um die zwei Runden aufzuholen.
<G-vec01001-002-s103><catch_up.aufholen><en> Avoid using items to catch up.
<G-vec01001-002-s103><catch_up.aufholen><de> Vermeide es, Gegenstände zu benutzen, um aufzuholen.
<G-vec01001-002-s104><catch_up.aufholen><en> Being a full time Mum I didn’t have time to eat properly myself, so I just ate their leftovers during the day and then once they’d gone to bed I’d cook a big meal for me and my husband – my portion sizes could probably have fed at least two people, but I figured seeing as I hadn’t eaten properly during the day it was ok to catch up by eating more in the evening.
<G-vec01001-002-s104><catch_up.aufholen><de> Als Vollzeit-Mama hatte ich keine Zeit selbst vernünftig zu essen, also aß ich einfach die Reste der Kinder über den Tag verteilt und dann, wenn sie im Bett lagen, kochte ich eine große Mahlzeit für mich und meinen Mann – meine Portionsgrößen hätten wahrscheinlich mindestens für zwei Personen ausgereicht, aber ich dachte mir, da ich am Tag nichts Richtiges gegessen hatte, war es okay am Abend etwas mehr zu essen und aufzuholen.
<G-vec01001-002-s105><catch_up.aufholen><en> Before trying to "catch up" the amount, you need to make sure that it is really necessary.
<G-vec01001-002-s105><catch_up.aufholen><de> Bevor Sie versuchen, den Betrag "aufzuholen", müssen Sie sicherstellen, dass es wirklich notwendig ist.
<G-vec01001-002-s106><catch_up.aufholen><en> Therefore they don't have a chance to catch up.
<G-vec01001-002-s106><catch_up.aufholen><de> Somit haben diese keine Chance, aufzuholen.
<G-vec01001-002-s107><catch_up.aufholen><en> They needed to continue development and eventually increase productivity to catch up with a backlog remaining after the previous vendor; after all, they still needed to develop both backend and frontend parts of the solution.
<G-vec01001-002-s107><catch_up.aufholen><de> Sie mussten die Entwicklung fortsetzen und schließlich die Produktivität steigern, um den Rückstand gegenüber dem vorherigen Anbieter aufzuholen; schließlich mussten sie sowohl Backend- als auch Frontend-Bereiche der Lösung entwickeln.
<G-vec01001-002-s108><catch_up.aufholen><en> It's a fact that young people excluded from the labour force for long periods are deprived of on-the-job learning leaving them with a skills deficit that they will never able to catch up.
<G-vec01001-002-s108><catch_up.aufholen><de> Es ist ein Fakt, dass junge Menschen, die für lange Zeit vom Arbeitsmarkt ausgeschlossen sind, benachteiligt im „Während-der-Arbeit-Lernen“ sind und somit Defizite haben, ohne Möglichkeit diese aufzuholen.
<G-vec01001-002-s109><catch_up.aufholen><en> While this is one way to skip all the time-consuming and painstaking effort you have to put into the game just to catch up, using this method could expose you to online scam sites.
<G-vec01001-002-s109><catch_up.aufholen><de> Während dies ein Weg ist, all die zeitraubenden und mühsamen Anstrengungen zu überspringen, die Sie ins Spiel stecken müssen, nur um aufzuholen, könnte Sie sich mit dieser Methode Online-Betrugsstellen aussetzen.
<G-vec01001-002-s110><catch_up.aufholen><en> I know days can be busy and there is no time to catch up.
<G-vec01001-002-s110><catch_up.aufholen><de> Ich weiß, dass Tage beschäftigt sein können und es keine Zeit gibt, aufzuholen.
<G-vec01001-002-s111><catch_up.aufholen><en> While the quality of financials in US and European companies deteriorated recently, the Japanese companies, which have been always lagging behind, started to catch up.
<G-vec01001-002-s111><catch_up.aufholen><de> Während sich die Qualität der Finanzwerte US-amerikanischer und europäischer Unternehmen in letzter Zeit verschlechtert hat, begannen die japanischen Unternehmen, die immer im Rückstand waren, aufzuholen.
<G-vec01001-002-s112><catch_up.bekommen><en> Alternatively, try to catch your parents’ attention by just walking by them or out of the room and head straight for your bed.
<G-vec01001-002-s112><catch_up.bekommen><de> Alternativ versuche die Aufmerksamkeit deiner Eltern zu bekommen, indem du an ihnen vorbeigehst oder aus dem Zimmer in Richtung deines Bettes.
<G-vec01001-002-s113><catch_up.bekommen><en> You can catch everything from a breathtaking classical concert at St Stephen’s Basilica to a rock gig at Club 202.
<G-vec01001-002-s113><catch_up.bekommen><de> Sie bekommen alles geboten – von einem atemberaubenden klassischen Konzert in der St.-Stephans-Basilika bis zu einem Rock-Gig im Club 202.
<G-vec01001-002-s114><catch_up.bekommen><en> For a frontal shot of the group with a 28mm lens on an APS chip camera you need to step back almost 9 meters to catch the 7 pairs.
<G-vec01001-002-s114><catch_up.bekommen><de> Für eine frontale Aufnahme mit einem 28mm Objektiv auf einer APS-Chip Kamera muss der Fotograf fast 9 Meter zurücktreten, um die 7 Paare in‘s Bild zu bekommen.
<G-vec01001-002-s115><catch_up.bekommen><en> Otherwise, the dressed child, expecting mother, will sweat and in cold air can catch a cold.
<G-vec01001-002-s115><catch_up.bekommen><de> Andernfalls wird das gekleidete Kind, das Mutter erwartet, schwitzen und in der kalten Luft eine Erkältung bekommen.
<G-vec01001-002-s116><catch_up.bekommen><en> Over the next two days on the Drake Passage, you catch a taste of life from the perspective of the polar explorers who first braved these regions: cool salt breezes, rolling waves, maybe even a fin whale blasting up a column of sea spray.
<G-vec01001-002-s116><catch_up.bekommen><de> Während der nächsten zwei Tage in der Drake-Passage, bekommen Sie einen Einblick in das Leben aus der Perspektive der Polarforscher, die diesen Regionen zuerst trotzten: kühle Salzbrisen, rauschende Meere, vielleicht sogar ein Finnwal, der zwischen den Wellen auftaucht.
<G-vec01001-002-s117><catch_up.bekommen><en> Anja`s strategie was the drop herself on the back and trie to catch Marine between her legs.
<G-vec01001-002-s117><catch_up.bekommen><de> Anjas Strategie war es, sich auf den Rücken fallen zu lassen und Marina zwischen die Schenkel zu bekommen.
<G-vec01001-002-s118><catch_up.bekommen><en> If you have managed to catch a cold or a fever, always consult a doctor.
<G-vec01001-002-s118><catch_up.bekommen><de> Erkältungen Wenn Sie eine Erkältung oder Fieber bekommen haben, konsultieren Sie immer einen Arzt.
<G-vec01001-002-s119><catch_up.bekommen><en> The playground is perfect, side offshore wind and waves…You definitely forget freestyle and try to catch as much waves as possible.
<G-vec01001-002-s119><catch_up.bekommen><de> Der Ort ist perfekt, schräg ablandiger Wind und Wellen…du wirst das Freestylen definitiv vergessen und versuchen so viele Wellen wie möglich zu bekommen.
<G-vec01001-002-s120><catch_up.bekommen><en> You will catch sight of them when Andreas Mühlbauer or Milena Fein takes you to the folio stacks.
<G-vec01001-002-s120><catch_up.bekommen><de> Und die bekommen die Besucher der Führung zu Gesicht, wenn Andreas Mühlbauer oder Milena Fein sie ins Folio-Magazin entführen.
<G-vec01001-002-s121><catch_up.bekommen><en> There are benefits to being observant. Observing people and using your findings could help you land your next job, catch someone in a lie, get people on your side in an argument or win the romantic partner of your dreams.
<G-vec01001-002-s121><catch_up.bekommen><de> Wenn du Menschen aufmerksam beobachten und deine Beobachtungen richtig einsetzen kannst, könnte dir das möglicherweise dabei helfen, einen tollen Job zu bekommen, jemanden beim Schwindeln zu ertappen, Menschen bei einer Auseinandersetzung auf deine Seite zu ziehen oder deinen Traumpartner für dich zu gewinnen.
<G-vec01001-002-s122><catch_up.bekommen><en> They use height to catch enough light.
<G-vec01001-002-s122><catch_up.bekommen><de> Sie nutzen die Höhe, um ausreichend Licht zu bekommen.
<G-vec01001-002-s123><catch_up.bekommen><en> Cormorants eat any fish they manage to catch.
<G-vec01001-002-s123><catch_up.bekommen><de> Kormorane fressen alle Fische, die sie bekommen können.
<G-vec01001-002-s124><catch_up.bekommen><en> After a while, I started feeling really sick, I could not catch my breath.
<G-vec01001-002-s124><catch_up.bekommen><de> Nach einer Weile begann ich mich wirklich krank zu spüren, ich konnte keinen Atem mehr bekommen.
<G-vec01001-002-s125><catch_up.bekommen><en> It is not allowed to bring used riding equipment to Iceland as our horses could catch a disease.
<G-vec01001-002-s125><catch_up.bekommen><de> Es ist nicht erlaubt, gebrauchte Reitsportausrüstung nach Island zu bringen, da unsere Pferde eine Krankheit bekommen könnten.
<G-vec01001-002-s240><catch_up.einholen><en> He was going to catch him in a few moments.
<G-vec01001-002-s240><catch_up.einholen><de> Er würde ihn in den nächsten Augenblicken einholen.
<G-vec01001-002-s241><catch_up.einholen><en> I could watch them mate twice - she let him catch her in a corner or under a bush. Unfortunately, I didn't get any good pics of the actual mating - his wide back covered it all.
<G-vec01001-002-s241><catch_up.einholen><de> Zweimal konnte ich beobachten wie sie sich einholen ließ und es in einer geschützten Ecke oder unter einem Strauch zur Paarung kam (leider habe ich keine guten Bilder der eigentlichen Paarung, da sein breiter Rücken alles verdeckt hat).
<G-vec01001-002-s242><catch_up.einholen><en> You can catch up the information under the contact data named below.
<G-vec01001-002-s242><catch_up.einholen><de> Die Auskunft können Sie unter den unten benannten Kontaktdaten einholen.
<G-vec01001-002-s243><catch_up.einholen><en> The two of them flew spontaneously for private reasons back to Germany for two weeks and Michael said that he would bewitch us so that we couldn't move forward and they could easily catch up with us again.
<G-vec01001-002-s243><catch_up.einholen><de> Die beiden flogen spontan aus privaten Gründen für zwei Wochen zurück nach Deutschland und Michael meinte noch, er verhexe uns, damit wir nicht voran kämen und sie uns leicht wieder einholen könnten.
<G-vec01001-002-s244><catch_up.einholen><en> Certainly yes! Because the sound wave propagates in air irrespective of the velocity of source at signal issuing time, the first airplane (which has sent a signal) will catch up the wave front propagating in the positive direction of axis, whereas the second airplane will "compete" with the wave front propagating in the negative direction of axis .
<G-vec01001-002-s244><catch_up.einholen><de> Da sich die Schallwelle in der Luft unabhängig von der Geschwindigkeit der Quelle im Zeitpunkt der Aussendung des Signals fortpflanzt, so wird das erste Flugzeug (das Signal gesendete) die Wellenfront einholen, die sich in der positiven Richtung der Achse erstreckt, und das zweite Flugzeug wird mit der Wellenfront "wetteifern", die sich in der negativen Richtung der Achse erstreckt.
<G-vec01001-002-s245><catch_up.einholen><en> I am testing the car myself right now, and it’s just the best thing to be able to leave town spontaneously to clear the head and enjoy some tranquility on the countryside – far away from Berlin, where reality and my duties always catch up with me.
<G-vec01001-002-s245><catch_up.einholen><de> Ich habe das Auto selbst seit ein paar Wochen und dadurch endlich die Möglichkeit mal spontan rauszufahren, den Kopf freizubekommen und einfach nur mal kurz die Ruhe zu genießen – weit weg von Berlin, wo mich die Realität und die Verpflichtungen einholen.
<G-vec01001-002-s246><catch_up.einholen><en> She needs to catch up with the thief, pull out all the feathers and return the stolen valuables.
<G-vec01001-002-s246><catch_up.einholen><de> Sie muss den Dieb einholen, alle Federn herausziehen und die gestohlenen Wertsachen zurückbringen.
<G-vec01001-002-s247><catch_up.einholen><en> Luna realized that she could not catch up to Mars until Christmas Eve.
<G-vec01001-002-s247><catch_up.einholen><de> Luna erkannte, dass sie Mars nicht mehr einholen konnte bis zum Weihnachtsabend.
<G-vec01001-002-s248><catch_up.einholen><en> Be patient, go a little slower and the baby will soon catch up with you.
<G-vec01001-002-s248><catch_up.einholen><de> Sei geduldig, geh ein bisschen langsamer und das Baby wird dich bald einholen.
<G-vec01001-002-s249><catch_up.einholen><en> He heard whereto we went, hired immediately a ship and will catch up with us here before 1 hour will have passed.
<G-vec01001-002-s249><catch_up.einholen><de> Denn er kam nahezu um eine Stunde später nach Kis, als wir abgefahren sind, und erfuhr, wohin wir gezogen sind, mietete sogleich ein Schiff und wird uns, ehe eine Stunde verrinnen wird, hier einholen.
<G-vec01001-002-s250><catch_up.einholen><en> He knew he’d never catch Pinot, but the desire to come 2nd, in a race he has twice won… Now that’s panache.
<G-vec01001-002-s250><catch_up.einholen><de> Er wusste, dass er Pinot nicht mehr einholen würde, doch das Verlangen, Zweiter zu werden bei einem Rennen, das er zweimal gewonnen hatte – das ist wirklich Panache.
<G-vec01001-002-s251><catch_up.einholen><en> The only reason I didn’t is because I knew he could catch me—he was bigger, faster, stronger, always had been—and he’d convince me to tell him all of it.
<G-vec01001-002-s251><catch_up.einholen><de> Ich tat es nur deshalb nicht, weil ich wusste, er konnte mich einholen – er war größer, schneller und stärker als ich, war es immer gewesen – und er würde mich dazu bringen, ihm alles zu sagen.
<G-vec01001-002-s252><catch_up.einholen><en> He is an excellent swimmer; on dry land he can run short distances fast enough to catch up with a horse.
<G-vec01001-002-s252><catch_up.einholen><de> Er kann gut schwimmen und auf kurzer Strecke ein Pferd einholen.
<G-vec01001-002-s253><catch_up.einholen><en> One more lap and I would perhaps have been able to catch Jesse.
<G-vec01001-002-s253><catch_up.einholen><de> Eine Runde mehr und ich hätte Jesse vielleicht einholen können.
<G-vec01001-002-s254><catch_up.einholen><en> Eventually, your feelings will catch up with your actions.
<G-vec01001-002-s254><catch_up.einholen><de> Deine Gefühle werden schließlich deine Handlungen einholen.
<G-vec01001-002-s255><catch_up.einholen><en> Whether you want to check out the ship in detail or catch up on the latest information before your cruise: get to know the EUROPA 2.
<G-vec01001-002-s255><catch_up.einholen><de> Ganz gleich, ob Sie sich im Detail über das Schiff informieren oder sich vor Ihrer Reise die letzten Informationen einholen möchten: Lernen Sie die EUROPA 2 kennen.
<G-vec01001-002-s256><catch_up.einholen><en> Labour and resources were redirected into industrial production so that China might “catch up to the West” in just a few years.
<G-vec01001-002-s256><catch_up.einholen><de> Arbeitskräfte und Ressourcen wurden in die industrielle Produktion umgeleitet, damit China in wenigen Jahren „den Westen einholen“ kann.
<G-vec01001-002-s257><catch_up.einholen><en> Then the Blessed One willed a feat of psychic power such that Aṅgulimāla, though running with all his might, could not catch up with the Blessed One walking at normal pace.
<G-vec01001-002-s257><catch_up.einholen><de> Da vollbrachte der Erhabene ein derartiges Kunststück übernatürlicher Kräfte, daß der Verbrecher Aṅgulimāla, obwohl er lief, so schnell er konnte, den Erhabenen nicht einholen konnte, der in normaler Geschwindigkeit ging.
<G-vec01001-002-s258><catch_up.einholen><en> Those of us who were born later can never have the experiences that others have had, can never catch up with them.
<G-vec01001-002-s258><catch_up.einholen><de> Wir, die Nachgeborenen, können die Erfahrungen, die andere gemacht haben, nie einholen.
<G-vec01001-002-s278><catch_up.einholen><en> I first tried to catch up with him, but soon found it reasonable to keep three steps behind him.
<G-vec01001-002-s278><catch_up.einholen><de> Ich versuchte zuerst ihn einzuholen, empfand es aber bald als normal drei Schritte hinter ihm zu bleiben.
<G-vec01001-002-s279><catch_up.einholen><en> DVDFab Blu-ray Creator for Mac has been in development for years to catch up with the latest technology trend.
<G-vec01001-002-s279><catch_up.einholen><de> Seit Jahre ist DVDFab Blu-ray Creator for Mac in der Entwicklung, um die Trends der neusten Technologie einzuholen.
<G-vec01001-002-s280><catch_up.einholen><en> Sally is trying to catch up with Mike.
<G-vec01001-002-s280><catch_up.einholen><de> Sally versucht Mike einzuholen.
<G-vec01001-002-s281><catch_up.einholen><en> He continues walking to catch up with his friends.
<G-vec01001-002-s281><catch_up.einholen><de> Er geht weiter, um seine Freunde einzuholen.
<G-vec01001-002-s282><catch_up.einholen><en> Jiang Jiao ordered his men to catch up to the monk and bring him back.
<G-vec01001-002-s282><catch_up.einholen><de> Darauf hin befahl Jiang Jiao seinen Männer, den Mönch einzuholen und ihn zurückzubringen.
<G-vec01001-002-s283><catch_up.einholen><en> Questions that seem to vanish into thin air during the course of this video, only to catch up with the audience again in the end.
<G-vec01001-002-s283><catch_up.einholen><de> Fragen, die sich im Laufe dieses Clips in Luft auflösen, um das Publikum dann schließlich doch wieder einzuholen.
<G-vec01001-002-s284><catch_up.einholen><en> There are also those, both in Russia and outside of it, who believe that Russia is doomed to drag behind, trying to catch up with the West and forced to bend to other players’ rules, and hence will be unable to claim its rightful place in international affairs.
<G-vec01001-002-s284><catch_up.einholen><de> Es gibt also solche, beide innerhalb und außerhalb Russlands, die glauben, daß Russland dazu verdammt ist hinterherzuhinken, zu versuchen den Westen einzuholen und gezwungen, sich nach den Regeln anderer Spieler zu beugen, weswegen es unfähig sein wird, seinen rechtmäßigen Platz in internationalen Zusammenhängen einzufordern.
<G-vec01001-002-s285><catch_up.einholen><en> And you run and you run to catch up with the sun, but it's sinking And racing around to come up behind you again
<G-vec01001-002-s285><catch_up.einholen><de> Und du läufst und läufst um die Sonne einzuholen doch sie sinkt und läuft im Kreis um hinter dir wieder aufzutauchen.
<G-vec01001-002-s286><catch_up.einholen><en> So on the one hand young entrepreneurs with lots of ideas are shaping the digital world at breakneck speed along the lines of “Move fast and break things,” and on the other a breathless politics tries to chase after something they can no longer catch up with: the frightening power of Silicon Valley.
<G-vec01001-002-s286><catch_up.einholen><de> So gestalten auf der einen Seite junge, ideengeladene Unternehmer die digitale Welt in einer atemberaubenden Geschwindigkeit ganz nach dem Motto »Move fast and break things« während auf der anderen Seite die außer Atem geratene Politik dem hinterherzujagen versucht, was nicht mehr einzuholen ist: der beängstigenden Machtstellung des Silicon Valley.
<G-vec01001-002-s287><catch_up.einholen><en> Woody and Buzz are racing to catch up with Andy’s moving van!
<G-vec01001-002-s287><catch_up.einholen><de> Woody und Buzz versuchen, Andy in seinem Van einzuholen.
<G-vec01001-002-s288><catch_up.einholen><en> In this case the above remarks about the passport are the same but you also need a tourist visa which has to be catch at the American foreign authorities before starting the trip.
<G-vec01001-002-s288><catch_up.einholen><de> Für diesen Fall gelten die obigen Ausführungen gleichermaßen und zusätzlich ist ein entsprechendes Touristen-Visum bei den amerikanischen Auslandsbehörden vor Antritt der Reise einzuholen.
<G-vec01001-002-s289><catch_up.einholen><en> Pictures provide an excellent opportunity to catch the readers’ attention and make the text come alive.
<G-vec01001-002-s289><catch_up.einholen><de> Die Integration von Pressebildern liefert hierbei eine hervorragende Möglichkeit, die Aufmerksamkeit der jeweiligen Leser einzuholen und den Text lebendig wirken zu lassen.
<G-vec01001-002-s290><catch_up.einholen><en> Kate, also carrying a torch, runs to catch up with him.]
<G-vec01001-002-s290><catch_up.einholen><de> Es ist Kate, die versucht, ihn einzuholen.
<G-vec01001-002-s291><catch_up.einholen><en> She slowed down, allowing him to catch up to her, to walk beside her.
<G-vec01001-002-s291><catch_up.einholen><de> Als ihr Bruder wortlos nickte, rannte sie los, um Eryn einzuholen.
<G-vec01001-002-s292><catch_up.einholen><en> How hard can it be to throw the hinges, to stare at the water and catch up with it again.
<G-vec01001-002-s292><catch_up.einholen><de> Wie schwer wird das auch sein die Angeln zu werfen, aufs Wasser zu starren und selbige wieder einzuholen.
<G-vec01001-002-s293><catch_up.einholen><en> To catch up with her sister, to be in everything like her, is the main goal of the little girl, and she tries very hard.
<G-vec01001-002-s293><catch_up.einholen><de> Es ist das Hauptziel des kleinen Mädchens, ihre Schwester einzuholen, in allem wie sie zu sein, und sie versucht es sehr.
<G-vec01001-002-s294><catch_up.einholen><en> But the problem is that far from not being able to catch up with the West – as the liberal critique claims – we are actually not able to catch up with our own past, as far as it concerns an experience that has been common to both sides of the West/East divide.
<G-vec01001-002-s294><catch_up.einholen><de> Aber das Problem ist weit entfernt von der Unfähigkeit, den Westen einzuholen – wie die liberale Kritik behauptet – wir sind gegenwärtig nicht fähig, unsere eigene Vergangenheit einzuholen, soweit sie eine Erfahrung betrifft, die beiden Seiten der West/Ost Trennung gemeinsam ist.
<G-vec01001-002-s296><catch_up.einholen><en> Tech-savvy to Output Astonishing Quality DVDFab Blu-ray Creator has been in development for years to catch up with the latest technology trends.
<G-vec01001-002-s296><catch_up.einholen><de> Seit Jahre sind alle DVDFab Produkte immer in der Entwicklung, um ihre High-End-Erfahrung zu behalten und die Trends der neusten Technologie einzuholen.
<G-vec01001-002-s333><catch_up.erreichen><en> Since many years, we are the reference for those looking for vacation rentals in Elba, and we have two agency in the area, one in Portoferraio and the other's one in Marina di Campo, with many opportunities to catch of holiday homes rentals on Elba.
<G-vec01001-002-s333><catch_up.erreichen><de> Seit vielen Jahren sind wir der Bezugspunkt für die Suche nach Ferienwohnungen in Elba, und wir haben zwei Büros, ein im Portoferraio und ein im Marina di Campo, mit vielen Vorschlägen zu vermieten Ferienhäuser und Ferienwohnungen auf Elba zu erreichen.
<G-vec01001-002-s334><catch_up.erreichen><en> Finish After the award ceremony, a new race begins for Frank Schleck: he has to catch the plane that will bring him to the Tour of Germany for tomorrow's first stage.
<G-vec01001-002-s334><catch_up.erreichen><de> Ziel Nach der Siegerehrung beginnt ein weiteres Rennen für Frank Schleck: er muss sein Flugzeug erreichen, das ihn zur Deutschland-rundfahrt bringen soll, die morgen beginnt.
<G-vec01001-002-s335><catch_up.erreichen><en> They would catch the ship.
<G-vec01001-002-s335><catch_up.erreichen><de> Sie würden das Schiff erreichen.
<G-vec01001-002-s336><catch_up.erreichen><en> Usually we are in a rush to catch a plane on our way out to somewhere and I never take the opportunity to browse the area.
<G-vec01001-002-s336><catch_up.erreichen><de> Normalerweise sind wir immer in Eile um ein Flugzeug irgendwohin zu erreichen und ich nutze nie die Gelegenheit einfach durch die Gegend zu schlendern.
<G-vec01001-002-s337><catch_up.erreichen><en> In Patanjali's yoga, for instance, one must transcend through six centres, one by one, before one can catch the Sound.
<G-vec01001-002-s337><catch_up.erreichen><de> In Patanjalis Yoga zum Beispiel muss man sechs Zentren durchqueren, bevor man den Ton erreichen kann.
<G-vec01001-002-s338><catch_up.erreichen><en> We will also easily pick you up from the indicated address and take you to the airport, leaving on time so that you can easily catch the plane.
<G-vec01001-002-s338><catch_up.erreichen><de> Wir holen Sie auch problemlos von der angegebenen Adresse ab und bringen Sie pünktlich zum Flughafen, damit Sie das Flugzeug problemlos erreichen können.
<G-vec01001-002-s339><catch_up.erreichen><en> Guests can catch a ride to nearby destinations on the area shuttle (surcharge).Dining Enjoy a satisfying meal at a restaurant serving guests of MAX Executive Apartments.
<G-vec01001-002-s339><catch_up.erreichen><de> Ziele in der Umgebung erreichen Sie mit dem Shuttle (gegen Gebühr).Speisen Freuen Sie sich auf schmackhafte Mahlzeiten im MAX Executive Apartments, denn das Haus besitzt ein Restaurant.
<G-vec01001-002-s340><catch_up.erreichen><en> If so, guests at Hotel Fira Congress staying in one of our Standard rooms can park their cars in our car park and we’ll take them to the airport for free so they can catch their flight on time.
<G-vec01001-002-s340><catch_up.erreichen><de> Dann übernachten Sie im Hotel Fira Congress und entspannen Sie sich in einem unserer Standardzimmer; im Gegenzug bieten wir Ihnen einen Pkw-Abstellplatz auf unserem Parkplatz und bringen Sie kostenlos zum Flughafen, damit Sie pünktlich Ihren Flug erreichen.
<G-vec01001-002-s341><catch_up.erreichen><en> Of course all the buses coming from north make a stop over here south bound toward various Manila destinations such as Cubao, Avenida,... ask the bus driver which final destination is best for your Manila trip or tell him to drop you at the best place to catch a taxi or other bus to continue your onward trip if needed.
<G-vec01001-002-s341><catch_up.erreichen><de> Natürlich kommen alle Busse von Norden wieder hier im Busbahnhof Dau vorbei auf ihrem Weg nach Manila zu den verschiedenen Stadtteilen Manila's wie Cubao, Avenida,... fragen sie den Bus Fahrer welches genaue Ziel in Manila für sie am nächsten liegt bevor sie sich für einen Bus entscheiden oder wo er sie aussteigen lassen kann, um ihr Endziel am einfachsten zu erreichen.
<G-vec01001-002-s342><catch_up.erreichen><en> Imagine the Solar System as an athletics racetrack. If you were watching a 400-metres race from the centre of the track and wanted to intercept one of the runners taking part, you could simply chase the runner you want to catch.
<G-vec01001-002-s342><catch_up.erreichen><de> Stellen Sie sich das Sonnensystem als die Laufbahnen eines Sportplatzes vor: Wenn Sie bei einem 400-Meterlauf von Ihrem Punkt auf der Laufbahn aus einen der Läufer erreichen möchten, so könnten Sie ihm einfach hinterherlaufen.
<G-vec01001-002-s343><catch_up.erreichen><en> In the night before I received a telephone call and was just barely able to catch a flight to Frankfurt and then the 747 to Beijing.
<G-vec01001-002-s343><catch_up.erreichen><de> In der Nacht vor dem geplanten Abflug nach Paris erhielt ich einen Anruf und konnte gerade noch rechtzeitig ein Flugzeug nach Frankfurt und damit den Jumbo nach Beijing erreichen.
<G-vec01001-002-s344><catch_up.erreichen><en> A stopover in Male can be booked here: Male City Hotels and Male Intl Airport Hotels • If your flight departs Male’ BEFORE 9.30am, you may have to check-out a day prior and stay overnight close to the airport to catch your onward flight.
<G-vec01001-002-s344><catch_up.erreichen><de> Einen Zwischenhalt in Malé können Sie hier buchen: Hotels in der Stadt Male und Hotels am internationalen Flughafen Male • Wenn Ihr Flug vor 9:30 Uhr abfliegt, dann sollten Sie am Tag davor auschecken und in Male übernachten, um den Flug sicher zu erreichen.
<G-vec01001-002-s345><catch_up.erreichen><en> Only when we have a pure heart, a heart of saving people, will they be able to catch the ship and not be left behind.
<G-vec01001-002-s345><catch_up.erreichen><de> Nur wenn wir ein reines Herz haben, ein Herz für das Erretten der Lebewesen, wird es den Menschen möglich sein, das Schiff zu erreichen und nicht zurückgelassen zu werden.
<G-vec01001-002-s346><catch_up.erreichen><en> A bus stop is just 10 metres below the house, and the main road to the airport is very easy to catch.
<G-vec01001-002-s346><catch_up.erreichen><de> Eine Bushaltestelle ist nur 10 Meter unterhalb des Hauses und die Hauptstraße zum Flughafen ist sehr leicht zu erreichen.
<G-vec01001-002-s347><catch_up.erreichen><en> We are also located near the Austin Bergstrom Airport and cater to frequent fliers, business travelers and those who need to catch a connecting flight.
<G-vec01001-002-s347><catch_up.erreichen><de> Die Nähe zum Flughafen Austin Bergstrom ist ideal für Vielflieger, Geschäftsleute und Reisende, die einen Anschlussflug erreichen möchten.
<G-vec01001-002-s348><catch_up.erreichen><en> Following the runaway Rio Grande in the Orinoco, Kira and Dax work on a way to catch it.
<G-vec01001-002-s348><catch_up.erreichen><de> Unterdessen sind Kira und Dax auf einem Abfangkurs, um die Rio Grande zu erreichen.
<G-vec01001-002-s349><catch_up.erreichen><en> (Jeremiah 8,8) It is important to meditate these inspired words of Jeremiah to catch the revealed divine Intention: to unmask the Jewish scribes who disfigure the Biblical message by their false interpretations.
<G-vec01001-002-s349><catch_up.erreichen><de> Die Worte Jeremia sollten näher betrachtet werden, um die darin ausgedrückte Absicht Gottes zu erreichen: die jüdische Schriftgelehrten zu demaskieren, die die biblische Botschaft durch ihre falsche Interpretationen entstellen.
<G-vec01001-002-s350><catch_up.erreichen><en> Considering her father has watched Point Break a dozen times or more, I am little more than embarrassing, struggling to paddle out from the shore and demonstrating all the dexterity of a giraffe on rollerblades when trying to catch a wave.
<G-vec01001-002-s350><catch_up.erreichen><de> Ihr Vater hat „Gefährliche Brandung“ zwar Dutzende Male gesehen, kann hier aber nur eine erbärmliche Nummer hinlegen - beim Versuch, die nächste Welle zu erreichen, demonstriert er die Gewandtheit einer Giraffe.
<G-vec01001-002-s351><catch_up.erreichen><en> You've got to preach short sermons to catch sinners; and deacons won't believe they need long ones themselves.
<G-vec01001-002-s351><catch_up.erreichen><de> Es bedarf kurzer Predigten, um Sünder zu erreichen; und Kirchenleute werden kaum meinen, dass sie selbst lange Predigten brauchen.
<G-vec01001-002-s352><catch_up.erwischen><en> In practice I catch myself using Live View often when shooting objects like buildings, still subjects or landscapes.
<G-vec01001-002-s352><catch_up.erwischen><de> In der Praxis erwische ich mich selbst dabei, dass ich den Live View häufig verwende, wenn ich Objekte, wie Gebäude, unbewegte Motive oder Landschaften, fotografiere.
<G-vec01001-002-s353><catch_up.erwischen><en> 14 Comments Photographers don't talk about filters much and I catch myself doing the same.
<G-vec01001-002-s353><catch_up.erwischen><de> Fotografen reden selten über Filter und auch ich erwische mich immer wieder dabei, wie mir dasselbe passiert.
<G-vec01001-002-s354><catch_up.erwischen><en> I often catch myself getting in bed at 11 pm but only falling asleep at 1 am.
<G-vec01001-002-s354><catch_up.erwischen><de> Oft erwische ich mich, dass ich um 23 Uhr zu Bett gehe, aber dann erst um 1 Uhr einschlafe.
<G-vec01001-002-s355><catch_up.erwischen><en> often catch myself being a bit ashamed about the long breaks that occur on this blog every now and then. And this shows me what this blog is to me: a sort of barometer to my creativity, my motivation, my moods and my living conditions.
<G-vec01001-002-s355><catch_up.erwischen><de> Ich erwische mich oft dabei, wie ich mich ein bißchen schäme, dass in diesem Blog manchmal so lange Pausen entstehen, was mir wiederum zeigt, was mein Blog für mich ist: eine Art Barometer meiner Kreativität, meiner Motivation, meiner Launen und meiner Lebensumstände.
<G-vec01001-002-s356><catch_up.erwischen><en> When I catch him in the kitchen, where he is sitting around lazily reading a magazine, instead of cleaning the kitchen as I had ordered, I have finally had enough.
<G-vec01001-002-s356><catch_up.erwischen><de> Als ich ihn lesend in der Küche erwische, wo er faul herumsitzt, anstatt die Küche zu putzen, wie ich es befohlen hatte, habe ich endgültig genug.
<G-vec01001-002-s357><catch_up.erwischen><en> I love this series and watch it whenever I happen to catch it on TV.
<G-vec01001-002-s357><catch_up.erwischen><de> Ich liebe diese Serie und schaue sie immer wenn ich sie im Fernsehen zufällig erwische.
<G-vec01001-002-s358><catch_up.erwischen><en> But in spite of tea and coffee I often catch myself drinking too less all in all.
<G-vec01001-002-s358><catch_up.erwischen><de> Aber trotz Tee und Kaffee erwische ich mich doch oft dabei, dass ich insgesamt zu wenig trinke.
<G-vec01001-002-s359><catch_up.erwischen><en> Some of these sexy girls love hot anal masturbation, too - catch amateur cam models satisfying their assholes with dildos, anal beads, and butt plugs right in front of their webcams.
<G-vec01001-002-s359><catch_up.erwischen><de> Einige dieser sexy Girls stehen auch auf Analmasturbation – erwische Amateur Cam Models, die ihre Arschlöcher mit Dildos, Analketten und Butt Plugs direkt vor ihren Webcams befriedigen.
<G-vec01001-002-s360><catch_up.erwischen><en> Peeps, unfortunately that’s all for today. I have to hurry up to catch a taxi that brings me to the airport timely as I have to take the first flight back to Zurich.
<G-vec01001-002-s360><catch_up.erwischen><de> So, leider muss ich für heute auch schon Schluss machen, denn gleich kommt ein Taxi, das mich zum Flughafen bringt, damit ich den ersten Flieger zurück nach Zürich erwische.
<G-vec01001-002-s361><catch_up.erwischen><en> There is always the chance that we will stumble upon some unknown corner of the hospital, see new faces, or catch a whiff of cooking as we pass.
<G-vec01001-002-s361><catch_up.erwischen><de> Es kann ja dazu führen, daß ich einen unbekannten Winkel entdecke, neue Gesichter erblicke, im Vorbeifahren einen Küchengeruch erwische.
<G-vec01001-002-s362><catch_up.erwischen><en> I knew the weather was changing but there was just the chance that I might still catch some nice weather.
<G-vec01001-002-s362><catch_up.erwischen><de> Ich wusste, dass das Wetter sich ändern würde, aber es bestand eine Chance, dass ich trotzdem noch etwas von dem schönen Wetter erwische.
<G-vec01001-002-s363><catch_up.erwischen><en> If you are fortunate enough to catch us on a day when we have any Belgian gold coins for sale, we recommend you take the opportunity and act fast.
<G-vec01001-002-s363><catch_up.erwischen><de> Wenn Sie das Glück haben, uns an einem Tag zu erwischen, an dem wir belgische Goldmünzen zum Verkauf anbieten, empfehlen wir Ihnen, die Gelegenheit zu nutzen und schnell zu handeln.
<G-vec01001-002-s364><catch_up.erwischen><en> Princess Nicole and Princess Scarlet come home and catch a burglar who smells their clothes.
<G-vec01001-002-s364><catch_up.erwischen><de> Princess Nicole and Princess Scarlet kommen nach Hause und erwischen einen Einbrecher der an ihrer Wäsche riecht.
<G-vec01001-002-s365><catch_up.erwischen><en> That’s why we are getting closer to Folkestone today to catch an early train tomorrow in hope of arriving back at home in Switzerland earlier in the evening than before.
<G-vec01001-002-s365><catch_up.erwischen><de> Deshalb fahren wir heute schon mal in seine Nähe, um morgen einen frühen Zug zu erwischen und nicht ganz so spät wie sonst in Bern einzutreffen.
<G-vec01001-002-s366><catch_up.erwischen><en> But if you're a little flexible, you should try to catch a day with a blue sky.
<G-vec01001-002-s366><catch_up.erwischen><de> Aber wenn Sie etwas flexibel sind, sollten Sie versuchen, einen Tag mit blauem Himmel zu erwischen.
<G-vec01001-002-s367><catch_up.erwischen><en> We were watching almost a different team than in recent games – lost, without an idea for the roster and the game, uselessly aggressive in inadequate moments and easy to catch without a cause.
<G-vec01001-002-s367><catch_up.erwischen><de> Es war fast so, als ob wir eine andere Mannschaft sahen als in den letzten Spielen – verloren, ohne eine Ahnung von der Aufstellung und dem Spiel, sinnlos aggressiv in unpassenden Momenten und ohne Grund leicht zu erwischen.
<G-vec01001-002-s368><catch_up.erwischen><en> Our job was to catch the remaining 14 dogs that we could not catch on the last two visits.
<G-vec01001-002-s368><catch_up.erwischen><de> Unsere Aufgabe war es, die restlichen 14 Hunde einzufangen, die wir die letzten beiden Male, die wir dort waren, nicht erwischen konnten.
<G-vec01001-002-s369><catch_up.erwischen><en> Whereas you can cruise mostly surfaced in the early stages of the war it's quite suicidal to do that later as many radar-equipped planes are on patrol and will very likely catch you off guard.
<G-vec01001-002-s369><catch_up.erwischen><de> Während man in den früheren Kriegsjahren meistens an der Oberfläche fahren kann, wird dies später fast selbstmörderisch da sehr viele mit Radar ausgestattete Flugzeuge den Seeraum patrouillieren und einen früher oder später kalt erwischen werden.
<G-vec01001-002-s370><catch_up.erwischen><en> People are rushing upstairs as you try to go down and catch your train.
<G-vec01001-002-s370><catch_up.erwischen><de> Die Menschen laufen die Treppe hoch, aber du musst runterlaufen und die Bahn erwischen.
<G-vec01001-002-s371><catch_up.erwischen><en> Now you have to catapult yourself to the other side at the right moment to catch the cube in flight.
<G-vec01001-002-s371><catch_up.erwischen><de> Nun musst du dich im richtigen Moment vom Katapult auf die andere Seite schießen lassen um den Cube im Flug zu erwischen.
<G-vec01001-002-s372><catch_up.erwischen><en> He made this trap to catch his wife with Ares.
<G-vec01001-002-s372><catch_up.erwischen><de> Er hat eine Falle gebaut, um seine Frau mit Ares zu erwischen.
<G-vec01001-002-s373><catch_up.erwischen><en> Prosecutions for pickpocketing are rare as legally the police have to catch the pickpocket in the middle of a crime.
<G-vec01001-002-s373><catch_up.erwischen><de> Die Diebe bekommen sehr selten eine Strafe, da die Polizei diese direkt beim Diebstahl erwischen muss.
<G-vec01001-002-s374><catch_up.erwischen><en> We know how difficult it is to catch a busy person like you;) Would you please introduce yourself for readers, who don’t know yet who you are and what you do.
<G-vec01001-002-s374><catch_up.erwischen><de> Wir sind uns bewusst, wie schwierig es ist, einen so beschäftigten Menschen wie Dich zu erwischen.
<G-vec01001-002-s375><catch_up.erwischen><en> On the one hand, we want to catch as many spammers as possible, but we must not be too quick to judge.
<G-vec01001-002-s375><catch_up.erwischen><de> Einerseits wollen wir möglichst viele Spammer erwischen, andererseits dürfen wir nicht vorschnell urteilen.
<G-vec01001-002-s376><catch_up.erwischen><en> No doors, moving quickly to try and catch decent light and angles from a fast moving platform.
<G-vec01001-002-s376><catch_up.erwischen><de> Keine Türen und ein sich bewegender Untergrund, und der ständige Versuch, vernünftiges Licht und gute Winkel zu erwischen.
<G-vec01001-002-s377><catch_up.erwischen><en> If you stand to triple your investment for the price of a minimum bet, statistics show that it is worth it to gamble on a losing hand on the off chance you catch someone bluffing or manage to improve your hand.
<G-vec01001-002-s377><catch_up.erwischen><de> Wenn Sie Ihre Investitionen für den Preis eines Mindesteinsatzes verdreifachen möchten, zeigen Statistiken, dass es sich lohnt auf eine verlorene Hand zu setzen, wenn Sie jemanden beim Bluffen erwischen, oder Ihre Hand verbessern möchten.
<G-vec01001-002-s378><catch_up.erwischen><en> But in order to catch the infection, it's enough to just ride a bus at rush hour or look into the family cafe, where there is always a couple of coughing babies.
<G-vec01001-002-s378><catch_up.erwischen><de> Aber um die Infektion zu erwischen, reicht es, wenn man zur Hauptverkehrszeit einen Bus fährt oder ins Familiencafe schaut, wo immer ein paar Hustenbabies sind.
<G-vec01001-002-s379><catch_up.erwischen><en> However, the rigorous objective criteria and review models sometimes turned objectives into a way to ‘catch out staff.’
<G-vec01001-002-s379><catch_up.erwischen><de> Die rigorosen objektiven Kriterien und Überprüfungsmodelle verwandelten die Ziele jedoch manchmal in eine Möglichkeit, die Mitarbeiter zu ‚erwischen‘.
<G-vec01001-002-s380><catch_up.erwischen><en> The two online game modes allow you to either collaborate with another player to escape, or to assume the role of the minotaur and try to catch the other player.
<G-vec01001-002-s380><catch_up.erwischen><de> Mit den beiden Online-Spielmodi kann man entweder mit anderen Spielern kollaborieren, um einen Ausweg zu finden, oder aber man schlüpft in die Rolle des Minotaur, um den anderen Spieler zu erwischen.
<G-vec01001-002-s381><catch_up.erwischen><en> If possible, talk to them during breaks when they seem too busy during working hours, or try to catch them just before or after work.
<G-vec01001-002-s381><catch_up.erwischen><de> Sprich sie nach Möglichkeit in den Pausen an, wenn sie während der Arbeitszeit zu beschäftigt wirken, oder versuch, sie kurz vor oder nach der Arbeit zu erwischen.
<G-vec01001-002-s382><catch_up.erwischen><en> A pickpocket (20, Moroccan) addresses passers-by to steal cell phones and steals a travel bag, which the police uses to catch him, thanks to a witness.
<G-vec01001-002-s382><catch_up.erwischen><de> Ein Taschendieb (20, Marokkaner) spricht Passanten an, um Handys zu stehlen und entwendet eine Reisetasche, mit der ihn die Polizei dank eines Zeugen erwischt.
<G-vec01001-002-s383><catch_up.erwischen><en> Then our Wickey Bluebeard's Ship climbing tower or our Wickey Wave Catcher climbing frame with swings come highly recommended so your little rascals can catch each wave.
<G-vec01001-002-s383><catch_up.erwischen><de> Dann empfiehlt sich beispielsweise unser Kletterturm Wickey Bluebeard’s Ship oder unser Kletterturm Wickey Wave Catcher, mit dem Ihr Racker garantiert jede Welle erwischt.
<G-vec01001-002-s384><catch_up.erwischen><en> While driving by a market I almost catch a bullet.
<G-vec01001-002-s384><catch_up.erwischen><de> Als ich am Markt vorbeifahre, erwischt mich beinah eine Kugel.
<G-vec01001-002-s385><catch_up.erwischen><en> Even with a healthy immune system, adults catch a cold two to four times a year – children even more often.
<G-vec01001-002-s385><catch_up.erwischen><de> Auch mit einem gesunden Immunsystem erwischt es Erwachsene zwei- bis viermal im Jahr, Kinder noch öfter.
<G-vec01001-002-s386><catch_up.erwischen><en> If you catch it within a couple minutes, you may be able to remove all the glue.
<G-vec01001-002-s386><catch_up.erwischen><de> Falls du ihn innerhalb von ein paar Minuten erwischt, könntest du in der Lage sein, allen Kleber zu entfernen.
<G-vec01001-002-s387><catch_up.erwischen><en> If you turn on a broker, then it is often a lottery game if you catch the broker who can also get the best deal for the sale.
<G-vec01001-002-s387><catch_up.erwischen><de> Schaltet man einen Makler ein, dann ist es häufig ein Lotteriespiel, ob man den Makler erwischt, der auch das beste Angebot für den Verkauf erzielen kann.
<G-vec01001-002-s388><catch_up.erwischen><en> He’s passionate, he’s loud and he knows how to inspire his troops, but you catch him on a bad day and he might shoot you dead if you look at him sideways… Always remember that.
<G-vec01001-002-s388><catch_up.erwischen><de> Er ist leidenschaftlich, laut und weiß, wie er seine Truppen bei Laune halten kann, aber wenn ihr ihn an einem schlechten Tag erwischt, erschießt er euch vielleicht, nur weil ihr ihn schräg anschaut…Behaltet das immer im Hinterkopf.
<G-vec01001-002-s389><catch_up.erwischen><en> What’s more, I didn’t catch a free lap.
<G-vec01001-002-s389><catch_up.erwischen><de> Zudem habe ich keine freie Runde erwischt.
<G-vec01001-002-s390><catch_up.erwischen><en> June June is a good time to visit, allowing you to catch the last of the dry weather and avoid the crowds seen during the European school holidays.
<G-vec01001-002-s390><catch_up.erwischen><de> Juni Juni ist ebenfalls eine gute Zeit, denn man erwischt das letzte trockenen Wetter und man vermeidet die Menschenmengen während der europäischen Schulferien.
<G-vec01001-002-s391><catch_up.erwischen><en> At the first day seemingly I didn´t catch the right position, i.e. the stent was positioned somewhat too high and it didn´t deliver sufficient functionality.
<G-vec01001-002-s391><catch_up.erwischen><de> Am ersten Tag hatte ich wohl nicht die richtige Position erwischt, d.h. ich war etwas zu hoch, so dass der Stent nicht gut funktionierte.
<G-vec01001-002-s392><catch_up.erwischen><en> We arrived in Helsinki quite late, managed to catch the right bus into town and the connection to our host’s address.
<G-vec01001-002-s392><catch_up.erwischen><de> Wir sind ziemlich spät in Helsinki angekommen, haben den richtigen Bus ins Stadtzentrum gefunden und die Anschlussverbindung zum Wohnort unserer Gastgeber erwischt.
<G-vec01001-002-s393><catch_up.erwischen><en> The music sounds more like a summer party and you can even catch one or two participants dancing spontaneously between the drills.
<G-vec01001-002-s393><catch_up.erwischen><de> Die Musik klingt eher nach einer Sommerparty und man erwischt sogar die ein oder andere Teilnehmerin bei einer spontanen Tanzeinlage zwischen den einzelnen Drills.
<G-vec01001-002-s807><catch_up.gleichziehen><en> Scheer hoped that the British would detect the battlecruisers, and respond with their own battlecruiser force, allowing the High Seas Fleet to catch and sink Beatty’s force.
<G-vec01001-002-s807><catch_up.gleichziehen><de> Als dann das deutsche Gros von den Briten gesichtet wurde, drehten diese ab, um die Hochseeflotte ihrerseits auf Jellicoes Hauptmacht zu ziehen.
<G-vec01001-002-s808><catch_up.gleichziehen><en> On the way back to Aasiaat, we will spend some time angling, trying to catch our dinner in the pure Arctic ocean.
<G-vec01001-002-s808><catch_up.gleichziehen><de> Auf dem Rückweg nach Aasiaat werden wir ein wenig angeln und versuchen, unser Abendessen aus dem sauberen Arktischen Ozean zu ziehen.
<G-vec01001-002-s809><catch_up.gleichziehen><en> Day in, day out, the designers of the Daimler Design unit create vehicles that will not catch people's eyes on the road until years later.
<G-vec01001-002-s809><catch_up.gleichziehen><de> Die Designer des Daimler Design Bereichs entwerfen tagtäglich Fahrzeuge, die erst Jahre später auf der Straße die Blicke auf sich ziehen werden.
<G-vec01001-002-s810><catch_up.gleichziehen><en> What might have been underestimated during an intense week of seminars, discussions and spectacular outdoor activities to catch media attention was the fact that women are participating in the diplomatic procedures and some even play a very prominent role in it, but in conflicting parties.
<G-vec01001-002-s810><catch_up.gleichziehen><de> Was während einer intensiven Woche mit Seminaren, Diskussionen und spektakulären Aktivitäten vor den Konferenzräumen unterschätzt wurde, um die Medien auf sich zu ziehen, war die Tatsache, dass Frauen an den diplomatischen Prozeduren teil genommen haben und einige sogar eine sehr prominente Rolle bei diesen spielte, wenn man von Konfliktparteien absieht.
<G-vec01001-002-s811><catch_up.gleichziehen><en> Whether you’re marvelling at fireworks flying through the sky or sharing a candlelit dinner for two, here are our tips for a look that’s sure to catch your other half’s eye.
<G-vec01001-002-s811><catch_up.gleichziehen><de> Ganz gleich, ob Sie das Silvester-Feuerwerk am Himmel bestaunen oder ein romantisches Abendessen bei Kerzenschein genießen – wir haben Tipps für den richtigen Look, um den Blick Ihres Gegenübers auf sich zu ziehen.
<G-vec01001-002-s812><catch_up.gleichziehen><en> Stainless steel etching is one of our signature techniques and our armour kits always catch the eye of others on the field.
<G-vec01001-002-s812><catch_up.gleichziehen><de> Ätzen auf Edelstahl ist eine unserer Signaturtechniken und unsere Rüstungssets ziehen immer die Blicke anderer auf das Feld.
<G-vec01001-002-s813><catch_up.gleichziehen><en> You will never want to leave once you catch a glimpse of the incredible views overlooking the city from our terrace.
<G-vec01001-002-s813><catch_up.gleichziehen><de> Lassen Sie sich von unserer Terrasse in den Bann der unglaublichen Aussicht auf die Stadt ziehen und entspannen Sie sich vom Stress im Fitness-Studio, das Sie während Ihres Aufenthalts genießen werden.
<G-vec01001-002-s814><catch_up.gleichziehen><en> More and more victims will eventually catch up with abusers. Related Stories
<G-vec01001-002-s814><catch_up.gleichziehen><de> Und immer mehr Opfern gelingt es, ihre Peiniger zur Rechenschaft zu ziehen.
<G-vec01001-002-s815><catch_up.gleichziehen><en> The slick graphics and high energy sound effects catch your attention, while the frequent wins keep the game engaging and exciting to play.
<G-vec01001-002-s815><catch_up.gleichziehen><de> Die beeindruckende Grafik und die energiegeladenen Soundeffekte ziehen die Aufmerksamkeit auf sich, während die häufigen Gewinne das Spiel aufregend und spannend machen.
<G-vec01001-002-s816><catch_up.gleichziehen><en> This completely crazy quiz should catch your attention.
<G-vec01001-002-s816><catch_up.gleichziehen><de> Dieses völlig verrückte Quiz sollte Ihre Aufmerksamkeit auf sich ziehen.
<G-vec01017-002-s561><catch_up.aufholen><en> To all appearances, the United States and its allies want to give radicals and extremists a chance to catch their breath and restore their ranks in order to prolong bloodshed on the Syrian territory and thus hinder political settlement.
<G-vec01017-002-s561><catch_up.aufholen><de> Überdies ergibt sich, dass die USA und deren Verbündeten den Radikalen und Extremisten die Möglichkeit gewähren wollen, um Atem zu holen, ihre Reihen wiederherzustellen, das Blutvergießen auf syrischem Boden zu verlängern und damit eine politische Regulierung zu erschweren.
<G-vec01017-002-s562><catch_up.aufholen><en> However, these regions may soon catch up: Four in 10 European executives (41 percent) and approximately half of Asia Pacific executives (49 percent) and Latin American executives (49 percent) report that their CEOs are more willing to talk with the news media today than they were several years ago.
<G-vec01017-002-s562><catch_up.aufholen><de> Doch die anderen Regionen holen auf: Vier von zehn europäischen Führungskräften (41 %) und etwa die Hälfte der Befragten aus der Asia-Pacific-Region sowie aus Lateinamerika (jeweils 49 %) geben an, ihre CEOs seien heute öfter bereit mit den Medien zu kommunizieren als noch vor einigen Jahren.
<G-vec01017-002-s563><catch_up.aufholen><en> Rowing at maximum intensity for short periods, using recovery phases to catch your breath and prepare for the next intense round.
<G-vec01017-002-s563><catch_up.aufholen><de> Das bedeutet Rudern bei maximaler Intensität in kurzen Phasen, gefolgt von Erholungsphasen, um Luft zu holen und sich auf die nächste intensive Runde vorzubereiten.
<G-vec01017-002-s564><catch_up.aufholen><en> Heavily panting he bent down, his hands on his knees to catch his breath.
<G-vec01017-002-s564><catch_up.aufholen><de> Keuchend beugte er sich vor, seine Hände auf seine Knien gestützt, um Luft zu holen.
<G-vec01017-002-s565><catch_up.aufholen><en> Competitors catch up and the market gets tighter.
<G-vec01017-002-s565><catch_up.aufholen><de> Die Mitbewerber holen ständig auf und der Kernmarkt wird enger.
<G-vec01017-002-s566><catch_up.aufholen><en> We do not have control of circumstances; no matter how hard we try to lead a good life and follow the right path: things still happen, the shadows catch up with us, and time leaves us behind, a shattered image of all we'd ever hoped to be.
<G-vec01017-002-s566><catch_up.aufholen><de> Wir können die Umstände nicht beherrschen; ganz gleich, wie sehr wir uns anstrengen, ein aufrechtes Leben zu führen und dem richtigen Pfad zu folgen: trotz allem geschehen diese Dinge, die Schatten holen uns ein, und die Zeit läßt uns hinter sich, ein zerbrochenes Abbild all dessen, was wir jemals zu sein hofften.
<G-vec01017-002-s567><catch_up.aufholen><en> Then it is possible that it will come flooding out and you will hardly have time to catch your breath.
<G-vec01017-002-s567><catch_up.aufholen><de> Dann werdet ihr möglicherweise von der Wahrheit geradezu „überflutet“ werden und kaum noch Zeit haben, „Atem zu holen“.
<G-vec01017-002-s568><catch_up.aufholen><en> Only with Habibiflo! So it can go when an image will be changed continuously and between makes a longer rest to catch his breath and to unfold …. Then I come along, take it as it is, make a fine photo and beautiful new images which now even may nestle cups.
<G-vec01017-002-s568><catch_up.aufholen><de> So kann es gehen, wenn ein Bild sich immer weiter verändern will und zwischendurch eine längere Rast macht um Atem zu holen und sich zu entfalten….dann komme ich daher, nehme es so, wie es ist, mache ein feines Foto und daraus wunderschöne neue Bilder, die sich jetzt sogar um Tassen schmiegen dürfen.
<G-vec01017-002-s569><catch_up.aufholen><en> That morning though, we just headed out a few meters to catch up with some sleep.
<G-vec01017-002-s569><catch_up.aufholen><de> Diesen Morgen haben wir jedoch beschlossen zunächst etwas Schlaf nach zu holen.
<G-vec01017-002-s570><catch_up.aufholen><en> The game grabs you so much you even forget to come up to the surface to catch your breath!
<G-vec01017-002-s570><catch_up.aufholen><de> Das Spiel packt Sie so, dass Sie sogar vergessen aufzutauchen um Luft zu holen.
<G-vec01017-002-s571><catch_up.aufholen><en> After an 11 day whirlwind tour of the country, our group needed a few days to catch our breath.
<G-vec01017-002-s571><catch_up.aufholen><de> Nach einer 11-tägigen Wirbelwindtour durch das Land brauchte unsere Gruppe ein paar Tage, um Luft zu holen.
<G-vec01017-002-s572><catch_up.aufholen><en> “Fantasy and reality do not catch up.”
<G-vec01017-002-s572><catch_up.aufholen><de> „Phantasie und Wirklichkeit holen sich nicht ein.“ (Manfred Hinrich, dt.
<G-vec01017-002-s573><catch_up.aufholen><en> While the rides can be exhilarating, if you’re looking to catch your breath and take a break from the excitement, take a peek inside the Model Shop, where new ideas for park LEGO displays are born.
<G-vec01017-002-s573><catch_up.aufholen><de> Die Fahrgeschäfte können zwar aufregend sein, aber wenn Sie Atem holen und eine Pause von der Aufregung einlegen möchten, werfen Sie einen Blick in den Model Shop, wo neue Ideen für LEGO-Displays im Park geboren werden.
<G-vec01017-002-s574><catch_up.aufholen><en> One time a monkey was sitting on the beach and tried to catch fish out of the water.
<G-vec01017-002-s574><catch_up.aufholen><de> Einmal saß ein Affe am Strand des Meeres und versuchte, die Fische aus dem Wasser zu holen.
<G-vec01017-002-s575><catch_up.aufholen><en> We catch them up the next day and drink some tea together, ride on and never see them again...
<G-vec01017-002-s575><catch_up.aufholen><de> Am nächsten Tag holen wir sie ein, trinken gemeinsam einen Tee, fahren weiter und sehen sie nie wieder...
<G-vec01017-002-s576><catch_up.aufholen><en> That means, humorous, grinding punk, chaotic hardcore and a proper dash of death metal from the early days, offering the perfect basis to devastate the neighborhood and to catch the cops.
<G-vec01017-002-s576><catch_up.aufholen><de> Das heißt, humorvoller grindiger Punk, chaotischer Hardcore und ne ordentliche Schippe Death Metal aus den guten Anfangstagen derselben, bieten eine gute Grundlage um die Nachbarschaft zu verwüsten und sich die Bullen an die Haustür zu holen.
<G-vec01017-002-s577><catch_up.aufholen><en> Now that Jerry haven’t been in Germany for five weeks, and I haven’t been able to do anything for the blog alone, there is a lot to catch up.
<G-vec01017-002-s577><catch_up.aufholen><de> Da ja Jerry jetzt fast fünf Wochen nicht in Deutschland war, und ich allein nichts zustande gebracht habe, gibt es natürlich viel nach zu holen.
