<G-vec00903-002-s019><cut_up.abschneiden><en> Wrap longer text over multiple lines to avoid text getting cut off in smaller breakpoints.
<G-vec00903-002-s019><cut_up.abschneiden><de> Ordnen Sie längeren Text über mehrere Zeilen an, um zu vermeiden, dass Text an kleineren Umbruchpunkten abgeschnitten wird.
<G-vec00903-002-s020><cut_up.abschneiden><en> A round chocolate cake (28 cm diameter) - the sides cut off and moved to the side as ears, one recipe of Cream Cheese Frosting.
<G-vec00903-002-s020><cut_up.abschneiden><de> Ein runder Schokoladenkuchen (28cm Durchmesser) - die Seiten abgeschnitten und als Ohren wieder seitlich angesetzt, 1 Rezept Schokoladenbuttercreme und ein paar Löffel baubles.
<G-vec00903-002-s021><cut_up.abschneiden><en> Note: Please keep your iPhone connecting with PC lest the process would be cut off.
<G-vec00903-002-s021><cut_up.abschneiden><de> Achtung: Bitte halten Sie die Verbindung zwischen Ihrem iPhone und Ihrem PC, so dass das Prozess nicht abgeschnitten werden wird.
<G-vec00903-002-s022><cut_up.abschneiden><en> In the autumn, before the onset of the first frost, last year's shoots, where the most powerful flowering took place, should be cut off almost to the ground (leave about 10 cm).
<G-vec00903-002-s022><cut_up.abschneiden><de> Im Herbst, vor dem Einsetzen des ersten Frosts, sollten die Triebe des letzten Jahres, in denen die stärkste Blüte stattfand, fast bis zum Boden abgeschnitten werden (etwa 10 cm Abstand lassen).
<G-vec00903-002-s023><cut_up.abschneiden><en> When the police eventually took her to a hospital, a doctor said the that circulation in her legs was cut off.
<G-vec00903-002-s023><cut_up.abschneiden><de> Als die Polizei sie schließlich ins Krankenhaus brachte, sagte der Arzt, dass die Blutzirkulation in ihren Beinen abgeschnitten sei.
<G-vec00903-002-s024><cut_up.abschneiden><en> If you have a large bathroom with a window, a French or a full balcony, then its decoration will be flowers: houseplants suitable for growing in a warm and humid climate or cut off, standing in vases.
<G-vec00903-002-s024><cut_up.abschneiden><de> Wenn Sie ein großes Badezimmer mit einem Fenster, einem französischen oder einem vollen Balkon haben, dann wird die Dekoration Blumen sein: Zimmerpflanzen, die für das Wachstum in einem warmen und feuchten Klima geeignet sind oder abgeschnitten werden und in Vasen stehen.
<G-vec00903-002-s025><cut_up.abschneiden><en> •“Cut it off and sold it,” said Della.
<G-vec00903-002-s025><cut_up.abschneiden><de> •"Abgeschnitten und verkauft," sagte Della.
<G-vec00903-002-s026><cut_up.abschneiden><en> Equipped with 22" in Length; 17" in Width; 18" in Depth product chamber with 40" Long x 7" OD grinding screw with 8" OD self sharpening cut off blades, 7½"ID threaded product discharge port with 8-5/8" diameter plate and has 42" floor clearance.
<G-vec00903-002-s026><cut_up.abschneiden><de> Ausgestattet mit 22" in der Länge, 17" in der Breite; 18" in Kammer Produkttiefe mit 40" Long x 7" OD Selbstschärf abgeschnitten Klingen, 7½ ‚ID Gewindeproduktabgabeöffnung mit 8-5 / 8‘ Durchmesser plate OD Schraube mit 8" Schleifen und hat 42" Bodenfreiheit.
<G-vec00903-002-s027><cut_up.abschneiden><en> There is a common network; however, its threads are cut off, and we have to reconnect them.
<G-vec00903-002-s027><cut_up.abschneiden><de> Es gibt ein gemeinsames Netz, doch dessen Fäden sind abgeschnitten, und wir müssen sie wieder verbinden.
<G-vec00903-002-s028><cut_up.abschneiden><en> Behind the bull a young boy sewn into a bear skin rode on a horse whose ears and tail were cut off.
<G-vec00903-002-s028><cut_up.abschneiden><de> Hinter dem Bullen ritt ein Junge genäht in ein Bärenfell auf einem Pferd, dessen Ohren und Schwanz abgeschnitten worden waren.
<G-vec00903-002-s029><cut_up.abschneiden><en> When the Wall went up in 1961, this triangular piece of land was cut off by the border installations; projecting into West Berlin, it was surrounded by a makeshift fence and left undeveloped.
<G-vec00903-002-s029><cut_up.abschneiden><de> Beim Bau der Mauer 1961 wurde der Zipfel durch die Sperranlagen abgeschnitten und blieb als nur provisorisch umzäunte, nach West-Berlin hinragende Brachfläche bestehen.
<G-vec00903-002-s030><cut_up.abschneiden><en> The war and the events of the war have cut completely across the line of development of the consciousness of the workers and given it a different direction to what might have been anticipated.
<G-vec00903-002-s030><cut_up.abschneiden><de> Der Krieg und die Ereignisse des Krieges haben die Entwicklungslinie des Bewusstseins der ArbeiterInnen völlig abgeschnitten und ihr eine andere Richtung gegeben, als man es vorhersehen konnte.
<G-vec00903-002-s031><cut_up.abschneiden><en> For the trunk of the Christmas tree, one of the slices has to be cut flat.
<G-vec00903-002-s031><cut_up.abschneiden><de> Für den Stamm des Tannenbaumes wird eine der Scheiben flach abgeschnitten.
<G-vec00903-002-s032><cut_up.abschneiden><en> Cronus, continued Sandro, was the son of the Earth Goddess and the God Uranus, and it was Cronus himself who cut off the gonads of his father and when he threw them into the sea from the foam appeared Aphrodite, goddess of love and sexuality. Venus, he continued saying, was the Roman heiress of the Greek Goddess Aphrodite.
<G-vec00903-002-s032><cut_up.abschneiden><de> Kronos, fuhr Sandro fort, war der Sohn des Gottes Uranus und der Göttin der Erde und als Kronos die Gonaden seines Vaters abgeschnitten hatte und ins Meer warf, erschien Venus, die Göttin der Liebe und der Sexualität, römische Erbin der griechischen Göttin Aphrodite, aus dem Meerschaum.
<G-vec00903-002-s033><cut_up.abschneiden><en> Also when I did not know your motives as yet – the connections being cut off – as at the time of the Brest-Litovsk peace, I defended you with your own motives.
<G-vec00903-002-s033><cut_up.abschneiden><de> Auch als ich Ihre Motive noch gar nicht kannte – die Verbindungen waren doch abgeschnitten –, wie beim Frieden von Brest-Litowsk, verteidigte ich Sie mit Ihren Motiven.
<G-vec00903-002-s034><cut_up.abschneiden><en> And it shall come to pass, as soon as the soles of the feet of the priests who bear the ark of the Lord, the Lord of all the earth, shall rest in the waters of the Jordan, that the waters of the Jordan shall be cut off, the waters that come down from upstream, and they shall stand as a heap.”
<G-vec00903-002-s034><cut_up.abschneiden><de> 13 Wenn dann die Fußsohlen der Priester, welche die Lade des HERRN, des Herrn der ganzen Erde, tragen, im Wasser des Jordan stillstehen, so wird das Wasser des Jordan, das Wasser, das von oben herabfließt, abgeschnitten werden, und es wird stehen bleiben wie ein Damm.
<G-vec00903-002-s035><cut_up.abschneiden><en> Many of them are just as cut off from any path toward integration into Canadian society as from the histories of their forebears, which was usually transmitted in the form of oral traditions and died out together with the banned dialects.
<G-vec00903-002-s035><cut_up.abschneiden><de> Von einer Integrationsmöglichkeit in die kanadische Gesellschaft sind sie oft genauso abgeschnitten wie von der meist mündlich überlieferten Geschichte ihrer Vorfahren, die zusammen mit den verbotenen Dialekten ausstarb.
<G-vec00903-002-s036><cut_up.abschneiden><en> It may need to bend or be cut off at certain points to look accurate.
<G-vec00903-002-s036><cut_up.abschneiden><de> An manchen Stellen kann das Muster gebogen oder abgeschnitten sein, damit es akkurater aussieht.
<G-vec00903-002-s037><cut_up.abschneiden><en> Intellectuals should no longer portray Internet users as secondary amateurs, cut off from a primary and primordial relationship with the world.
<G-vec00903-002-s037><cut_up.abschneiden><de> Intellektuelle sollten Netznutzer nicht länger als sekundäre Amateure zeichnen, die von einem primären und ursprünglichen Verhältnis zur Welt abgeschnitten sind.
<G-vec00903-002-s038><cut_up.abschneiden><en> Before scrapping it, make sure to cut off the mains cord so that the appliance cannot be re-used.
<G-vec00903-002-s038><cut_up.abschneiden><de> Machen Sie das Gerät vor der Verschrottung unbrauchbar, indem Sie das Netzkabel abschneiden.
<G-vec00903-002-s039><cut_up.abschneiden><en> - Standing upright, these you can simply cut with the Sword (usually leaves behind a Deku Stick).
<G-vec00903-002-s039><cut_up.abschneiden><de> - Aufrecht stehend (verwelkt), die kann man einfach mit dem Schwert abschneiden (hinterlässt meistens einen Deku-Stab).
<G-vec00903-002-s040><cut_up.abschneiden><en> He seems to be cold and brutal at first because he is quite serious, does many things on his own, chose brutal methods (e.g. he wanted to cut off his feet to free himself from wax) and talks in an insensitive way.
<G-vec00903-002-s040><cut_up.abschneiden><de> Auf den ersten Blick wirkt er etwas kalt und brutal, da er eine ziemlich ernste Person ist, vieles im Alleingang macht, brutale Methoden wählt (zB wollte er sich die Beine abschneiden, als er im Wachs drinsteckte) und unsentimentale Sprüche abgibt.
<G-vec00903-002-s041><cut_up.abschneiden><en> Only the harmonious song of the birds will cut off this silence.
<G-vec00903-002-s041><cut_up.abschneiden><de> Nur das harmonische Lied der Vögel wird dieses Schweigen abschneiden.
<G-vec00903-002-s042><cut_up.abschneiden><en> Cut away all protruding parts on the Trix C Track connection points and the fasteners on the first tie.
<G-vec00903-002-s042><cut_up.abschneiden><de> Abschneiden aller überstehenden Teile an der Trix C-Gleis-Anschlussstelle und der Kleineisen an der ersten Schwelle.
<G-vec00903-002-s043><cut_up.abschneiden><en> Wrap the leather around your wrist to determine how long to cut your pieces.
<G-vec00903-002-s043><cut_up.abschneiden><de> Wickle es dafür um dein Handgelenk, um zu bestimmen, wie lange du die Stücke abschneiden musst.
<G-vec00903-002-s044><cut_up.abschneiden><en> Cut and sew the threads.
<G-vec00903-002-s044><cut_up.abschneiden><de> Faden abschneiden und Faden vernähen.
<G-vec00903-002-s045><cut_up.abschneiden><en> Diamond Blades for Cut-Off Saws - Simply a cut above: The diamond blades for cut-off saws Wacker Neuson's diamond blade range is tailor-made for the BTS range of Wacker Neuson cut-off saws.
<G-vec00903-002-s045><cut_up.abschneiden><de> Einfach perfekt abschneiden: Mit Diamantscheiben für Trennschneider Das Diamantscheiben-Sortiment von Wacker Neuson ist speziell auf die Trennschneider-Modelle der BTS-Reihe von Wacker Neuson zugeschnitten.
<G-vec00903-002-s046><cut_up.abschneiden><en> Because as long as the EU doesn’t decide to lay barbed wire across Mediterranean beaches, or to turn back refugee boats with armed force, the sea border of the EU to the south cannot be ‘defended’: the EU cannot cut itself off from the Mediterranean – which, it is worth remembering, is in cultural historical terms, as the Mare Nostrum, the quintessential European sea – and from whose trade routes the EU most certainly does not want to cut itself off.
<G-vec00903-002-s046><cut_up.abschneiden><de> Aber Griechenland oder Italien oder die Länder auf der Balkanroute – ob EU oder nicht – haben keine Wahl: sie werden von Flüchtlingen überrannt, ganz egal, was sie tun, um das zu verhindern – denn solange die EU sich nicht entschließt, Stacheldraht auf Mittelmeerstränden zu verlegen oder Flüchtlingsboote mit Waffengewalt abzuwehren, kann die Wassergrenze der EU nach Süden gar nicht ‚geschützt’ werden: die EU kann sich nicht vom Mittelmeer abschneiden, das übrigens als Mare Nostrum kulturgeschichtlich das europäische Meer schlechthin ist – und von dessen Handelsrouten sich die EU keinesfalls abschneiden will.
<G-vec00903-002-s047><cut_up.abschneiden><en> This would in effect cut off the northern West Bank from the southern part, apart from a narrow bottleneck near Jericho.
<G-vec00903-002-s047><cut_up.abschneiden><de> Dies würde dann tatsächlich den nördlichen Teil der Westbank vom südlichen Teil abschneiden, abgesehen von einem engen Flaschenhals bei Jericho.
<G-vec00903-002-s048><cut_up.abschneiden><en> When diagram A.1 has been completed, cut and fasten the strand.
<G-vec00903-002-s048><cut_up.abschneiden><de> Wenn A.1 zu Ende gehäkelt wurde, den Faden abschneiden und vernähen.
<G-vec00903-002-s049><cut_up.abschneiden><en> To propagate roses using this method, you need to select a healthy rose plant and cut off a stem.
<G-vec00903-002-s049><cut_up.abschneiden><de> Um Rosen mit dieser Methode zu vermehren, musst du eine gesunde Rosenpflanze aussuchen und einen Stängel abschneiden.
<G-vec00903-002-s050><cut_up.abschneiden><en> For how to select the auto feed & cut mode, see "Setting of the DIP switches" (on page 11).
<G-vec00903-002-s050><cut_up.abschneiden><de> Lesen Sie den Abschnitt “Einstellung der DIP-Schalter” (auf Seite 10) hinsichtlich der Auswahl des Modus zum automatischen Einzug und Abschneiden.
<G-vec00903-002-s051><cut_up.abschneiden><en> Peel the lower third of the asparagus and cut the ends.
<G-vec00903-002-s051><cut_up.abschneiden><de> Das untere Drittel des Spargels schälen und die Enden abschneiden.
<G-vec00903-002-s052><cut_up.abschneiden><en> The prickly leaves can be cut slightly.
<G-vec00903-002-s052><cut_up.abschneiden><de> Die stachligen Blätter kann man etwas abschneiden.
<G-vec00903-002-s053><cut_up.abschneiden><en> First make a cut in the underside before you cut off a length from above.
<G-vec00903-002-s053><cut_up.abschneiden><de> Machen Sie zuerst einen Schnitt an der Unterseite, bevor Sie eine Länge von oben abschneiden.
<G-vec00903-002-s054><cut_up.abschneiden><en> In this case, you do not need to cut the stems.
<G-vec00903-002-s054><cut_up.abschneiden><de> In diesem Fall müssen Sie die Stiele nicht abschneiden.
<G-vec00903-002-s055><cut_up.abschneiden><en> Make a tassel for each end of the string as follows: Cut 12 threads of Cotton Viscose and 8 threads Vivaldi measuring 20 cm each.
<G-vec00903-002-s055><cut_up.abschneiden><de> An den Enden je 1 Quaste einziehen: 12 Fäden Cotton Viscose und 8 Fäden Vivaldi à 20 cm abschneiden.
<G-vec00903-002-s056><cut_up.abschneiden><en> He gives us directly the step by which we can cut off all unnecessary actions.
<G-vec00903-002-s056><cut_up.abschneiden><de> Er gibt uns direkt den Schritt, durch den wir alle unnötigen Handlungen abschneiden können.
<G-vec00903-002-s057><cut_up.abschneiden><en> After lots of futile attempts to save the mango trees, the only remaining option is to cut and burn them.
<G-vec00903-002-s057><cut_up.abschneiden><de> Nach vielen vergeblichen Versuchen bleibt nur die Möglichkeit, die kranken Bäume abzuschneiden und zu verbrennen.
<G-vec00903-002-s058><cut_up.abschneiden><en> Product Description This Selectable Portable 3G Cell Phone WiFi Jammer & GPS Signal Jammer that you are viewing here is the new designed signal jammer that is designed with the ability to cut off the signals of GSM, DCS, PCS, 3G,4G, 4G LTE,4G WiMax and WiFi GPS, i at the same time.
<G-vec00903-002-s058><cut_up.abschneiden><de> Produkt-Beschreibung Dieser auswählbare Handy-WiFi-Störsender des Portable-3G u. GPS-Signal-Störsender, dass Sie hier ansehen, ist der neue entworfene Signalstörsender, der mit der Fähigkeit, die Signale von G/M, von DCS, von PCS, von 3G, von 4G, von 4G LTE, von 4G WiMax und von GPS Lojack abzuschneiden entworfen ist, i gleichzeitig.
<G-vec00903-002-s059><cut_up.abschneiden><en> This allows the player running at him enough time to put pressure on him and cut off other options.
<G-vec00903-002-s059><cut_up.abschneiden><de> Dies gibt dem jeweils anlaufenden Spieler Zeit, ihn unter Druck zu setzen und weitere Optionen abzuschneiden.
<G-vec00903-002-s060><cut_up.abschneiden><en> A stove cut off may be used to cut off gas or power after a specified time.
<G-vec00903-002-s060><cut_up.abschneiden><de> Ein abgeschnittener Ofen wird verwendet möglicherweise, um Gas oder Leistung nach einer festgelegten Zeit abzuschneiden.
<G-vec00903-002-s061><cut_up.abschneiden><en> The heat can damage your curl pattern and the only way to remedy the damage is to cut the torched hair off.
<G-vec00903-002-s061><cut_up.abschneiden><de> Die Hitze kann die Struktur deiner Locken schädigen und die einzige Möglichkeit, diese Schäden zu heilen, ist es die verbrannten Haare abzuschneiden.
<G-vec00903-002-s062><cut_up.abschneiden><en> The girl was very impressed when her father told her that their country doctor easily could cut off a man's arm or leg, or even rip the belly and pull out the sick inside.
<G-vec00903-002-s062><cut_up.abschneiden><de> Das Mädchen war sehr beeindruckt, als der Vater ihm erzählte, dass es ihrem Landarzt nichts ausmacht, einen Arm oder ein Bein einem Menschen abzuschneiden oder sogar den Bauch zu reiβen und das Innere des Patienten herauszuziehen.
<G-vec00903-002-s063><cut_up.abschneiden><en> "I have run all the way in order to cut you off, Dr. Watson," said she.
<G-vec00903-002-s063><cut_up.abschneiden><de> It seems, „Ich bin den ganzen Weg gerannt, um Ihnen den Weg abzuschneiden, Dr. Watson“, sagte sie.
<G-vec00903-002-s064><cut_up.abschneiden><en> It could be set, using a decibel meter to provide a visual warning when the sound level at the neighbours property exceeded 45dB and to cut off mains power from the performers equipment if they continually ignored the warning lights.
<G-vec00903-002-s064><cut_up.abschneiden><de> Es konnte mit einem Dezibel-Meter gesetzt werden, um eine Sehwarnung zur Verfügung zu stellen, als der Geräuschpegel am Nachbareigentum 45 DB überschritten hat und Hauptmacht von der Darstellerausrüstung abzuschneiden, wenn sie ständig die Warnlichter ignoriert haben.
<G-vec00903-002-s065><cut_up.abschneiden><en> Crop (in the standalone version) lets you cut off unwanted areas in the image.
<G-vec00903-002-s065><cut_up.abschneiden><de> Das Freistellen-Werkzeug (nur in der Standalone-Version verfügbar) erlaubt es, unnötige Teile des Bildes abzuschneiden.
<G-vec00903-002-s066><cut_up.abschneiden><en> conventional vehicle door includes a complete outer skin with a window and lock hardware to cut off a vehicle cabin completely from the environment.
<G-vec00903-002-s066><cut_up.abschneiden><de> Eine herkömmliche Fahrzeugtür beinhaltet eine vollständige Außenhaut mit einem Fenster und Riegelhardware, um eine Fahrzeugkabine vollständig von der Umwelt abzuschneiden.
<G-vec00903-002-s067><cut_up.abschneiden><en> Beforehand, follow the roll of wallpaper to measure and cut off several strips, the size of the height of the pasted wall.
<G-vec00903-002-s067><cut_up.abschneiden><de> Zuvor folgen Sie der Rolle der Tapete, um mehrere Streifen zu messen und abzuschneiden, die Größe der Höhe der eingefügten Wand.
<G-vec00903-002-s068><cut_up.abschneiden><en> When the operation pressure of the mud pump is greater than the setting pressure, the discharge pressure of the mud pump push piston rod and the piston of the safety valve so as to open the shear pin board, and cut off the shear pin to immediately discharge the pressure of the mud pump from the outlet of the safety valve, thus to protect the mud pump effectively.
<G-vec00903-002-s068><cut_up.abschneiden><de> Wenn der Betriebsdruck der Schlammpumpe größer als der Einstelldruck ist, drückt der Abgabedruck der Schlammpumpe die Kolbenstange und den Kolben des Sicherheitsventils, um die Scherbolzenplatte zu öffnen und den Scherbolzen abzuschneiden, um sich sofort zu entladen der Druck der Schlammpumpe vom Auslass des Sicherheitsventils, um so die Schlammpumpe effektiv zu schützen.
<G-vec00903-002-s070><cut_up.abschneiden><en> He behaved in a noble-minded way towards them, but before setting them free, he ordered to cut off the nose of Rozhoň by a sickle as an exemplary act.
<G-vec00903-002-s070><cut_up.abschneiden><de> Er verhielt sich zu den Besiegten großzügig, jedoch bevor er ihnen die Freiheit schenkte, hatte er befohlen, Rozhoň zur Warnung die Nase mit Sichel abzuschneiden.
<G-vec00903-002-s071><cut_up.abschneiden><en> That is the reason why in some countries one is required to report capital wrong doings so to cut off ways to develop usuals from wrongs and gain benefit from the wrong deeds done by others in tolerating them, better taking part.
<G-vec00903-002-s071><cut_up.abschneiden><de> Das ist der Grund, warum es in manchen Ländern von einem gefordert wird, kapitales Fehlverhalten auf/anzuzeigen, um so die Gefahr des Üblichwerdens von Fehlhandlungen, und sich an Fehlhandlungen (auch mit Mitteln des Duldens) zu bereichern, abzuschneiden.
<G-vec00903-002-s072><cut_up.abschneiden><en> Many prefer to cut the spike entirely off and count on the plant building up its energy for a renewed larger new spike next growing season.
<G-vec00903-002-s072><cut_up.abschneiden><de> Viele ziehen es vor, die Spitze völlig abzuschneiden und auf dem Betrieb zu zählen, der seine Energie für eine erneuerte größere neue Spitze folgende wachsende Jahreszeit aufbaut.
<G-vec00903-002-s073><cut_up.abschneiden><en> While rolling the wrapper skin, to prevent the double folding of dough skin that causes uneven taste, a roller cutter is equipped to cut off the extra dough skin.
<G-vec00903-002-s073><cut_up.abschneiden><de> Während die Umhüllungshaut gerollt wird, um das doppelte Falten der Teighaut zu verhindern, das einen ungleichmäßigen Geschmack verursacht, ist ein Rollenschneider ausgerüstet, um die zusätzliche Teighaut abzuschneiden.
<G-vec00903-002-s074><cut_up.abschneiden><en> Your neighbor was correct to cut off the bad roots.
<G-vec00903-002-s074><cut_up.abschneiden><de> Dein Nachbar war korrekt, die schlechten Wurzeln abzuschneiden.
<G-vec00903-002-s075><cut_up.abschneiden><en> To cut supply lines to England Germany starts unrestricted submarine warfare in 1917.
<G-vec00903-002-s075><cut_up.abschneiden><de> Um die Nachschublinien der Briten abzuschneiden, startet Deutschland 1917 einen uneingeschränkten U-Boot-Krieg.
<G-vec00903-002-s095><cut_up.ausschneiden><en> Great advancements have been achieved in the Dynamic Photo function, which enables users to cut out images of a moving subject and paste them on a different still image that acts as a background.
<G-vec00903-002-s095><cut_up.ausschneiden><de> Die Dynamic Photo-Funktion, mit der ein sich bewegendes Motiv ausgeschnitten und auf ein anderes unbewegtes Hintergrundbild gesetzt werden kann, wurde erheblich verbessert.
<G-vec00903-002-s096><cut_up.ausschneiden><en> On the latter I stamped the first part of the sentiment and then fussy cut it out before stamping the second part as well.
<G-vec00903-002-s096><cut_up.ausschneiden><de> Auf das weiße Papier habe ich den Spruch gestempelt und es dann per Hand "ausgeschnitten" bevor ich dann noch den zweiten Teil hinzugestempelt habe.
<G-vec00903-002-s097><cut_up.ausschneiden><en> I stamped it once with black ink, once heat embossed it using golden embossing powder, then cut those out and put them on brown cardstock.
<G-vec00903-002-s097><cut_up.ausschneiden><de> Der ist einmal mit schwarzer Tinte und einmal golden embossed gestempelt, ausgeschnitten und auf braunen Cardstock geklebt.
<G-vec00903-002-s098><cut_up.ausschneiden><en> With large honeycombs, the curves are cut out of the sheet and tapered at each end.
<G-vec00903-002-s098><cut_up.ausschneiden><de> Bei den großen Waben werden die Kurven an jedem Ende verjüngt und aus der Platte ausgeschnitten.
<G-vec00903-002-s099><cut_up.ausschneiden><en> stamped the boy and girl images, colored them and then cut them out trimming closely.
<G-vec00903-002-s099><cut_up.ausschneiden><de> Ich habe den Jungen und das Mädchen abgestempelt, coloriert und dann anschließend konturengenau ausgeschnitten.
<G-vec00903-002-s100><cut_up.ausschneiden><en> I stamped the flowers again, wiped them with Distress Inks in colour, cut them out and glued them on.
<G-vec00903-002-s100><cut_up.ausschneiden><de> Die Blüten habe ich nochmal extra gestempelt, mit Distress Inks farbig gewischt, ausgeschnitten und aufgeklebt.
<G-vec00903-002-s101><cut_up.ausschneiden><en> Some children cut out their footprints and draw something on it that deserves protection for them.
<G-vec00903-002-s101><cut_up.ausschneiden><de> Einige Kinder haben ihren Fußabdruck ausgeschnitten und etwas aus der Natur darauf gemalt, was für sie besonders schützenswert ist.
<G-vec00903-002-s102><cut_up.ausschneiden><en> Where it previously had to be tediously cut and adjusted, the pipe can now easily be inserted through the prepared inflow opening and the rainwater hopper mounted directly on the wall.
<G-vec00903-002-s102><cut_up.ausschneiden><de> Wo bisher langwierig ausgeschnitten und angepasst werden musste, kann das Rohr jetzt spielend leicht in die vorbereitete Zulauföffnung eingesteckt und der Regenfangkasten direkt an der Wand montiert werden.
<G-vec00903-002-s103><cut_up.ausschneiden><en> The image is colored with Copics and cut out by hand.
<G-vec00903-002-s103><cut_up.ausschneiden><de> Das Motiv ist mit Copics coloriert und ausgeschnitten.
<G-vec00903-002-s104><cut_up.ausschneiden><en> As a sheet material, for example textile materials such as woven or knitted fabrics, but also films are also conceivable, of which the markings are, for example punched or cut out.
<G-vec00903-002-s104><cut_up.ausschneiden><de> Als flächiges Material sind zB textile Materialien wie Gewebe oder Gewirke, aber auch Folien denkbar, aus denen die Markierungen zB ausgestanzt oder ausgeschnitten sind.
<G-vec00903-002-s105><cut_up.ausschneiden><en> Der Carstock mit den Motiven (eine Maus aus dem Mice Time to Celebrate Set, The paper with the stamped on images (a mouse from the Mice Time to Celebrate stamp set, one of the bears from the Joyful Heart Bears set and a piglet from the Piggy Pebbles set) ist glued behind the frame and the images were cut out so the pieces that would've been covered by the frame are on top of it.
<G-vec00903-002-s105><cut_up.ausschneiden><de> Den weißen Cardstock im Hintergrund, den ich schwarz gemattet und auf eine weiße Grundkarte geklebt habe, ist mit Distress Ink Tumbled Glass und verschiedenen "Flecken" aus dem Distressed ein Bär aus dem Joyful Heart Bears Set und noch ein Schweinchen aus dem Piggy Pebbles Set) ist hinter den Rahmen geklebt und die Motive so ausgeschnitten, dass die eigentlich vom Rahmen abgedeckten Teile der Tiere vorne über den Rahmen überstehen.
<G-vec00903-002-s106><cut_up.ausschneiden><en> I wiped the elephants with grey paint, cut them out and glued them on.
<G-vec00903-002-s106><cut_up.ausschneiden><de> Die Elefanten habe ich mit grauer Farbe gewischt, ausgeschnitten und aufgeklebt.
<G-vec00903-002-s107><cut_up.ausschneiden><en> Comprehensive editing functions (e.g., block functions such as cut, copy, paste, move, even directly moving into other windows without using the clipboard).
<G-vec00903-002-s107><cut_up.ausschneiden><de> Umfangreiche Editierfunktionen (Blöcke können ausgeschnitten, eingefügt, verschoben oder in andere Programmfenster kopiert werden, auch direkt in andere Fenster ohne den Umweg über das Clipboard).
<G-vec00903-002-s108><cut_up.ausschneiden><en> From the dense cardboard, two identical figures are cut out.
<G-vec00903-002-s108><cut_up.ausschneiden><de> Aus dem dichten Karton werden zwei identische Figuren ausgeschnitten.
<G-vec00903-002-s109><cut_up.ausschneiden><en> And some of them, being cut out, can come to be an object on the wall.
<G-vec00903-002-s109><cut_up.ausschneiden><de> Einige werden dann ausgeschnitten und so kann man sie als eine Art Objekt an die Wand hängen.
<G-vec00903-002-s110><cut_up.ausschneiden><en> The span is 2 meters and own parts were cut out by hand for the feathers of the wings.
<G-vec00903-002-s110><cut_up.ausschneiden><de> Die Spannweite liegt bei 2 Metern und es wurden für die Federn der Flügel eigene Teile per Hand ausgeschnitten.
<G-vec00903-002-s111><cut_up.ausschneiden><en> In order to ensure the desired quality standard, these small openings must be cut out precisely.
<G-vec00903-002-s111><cut_up.ausschneiden><de> Um den gewünschten Qualitätsstandard gewährleisten zu können, müssen diese kleinen Öffnungen sehr passgenau ausgeschnitten werden.
<G-vec00903-002-s112><cut_up.ausschneiden><en> Each photo can be cut out and send as a postcard.
<G-vec00903-002-s112><cut_up.ausschneiden><de> Jedes Foto kann danach als Postkarte ausgeschnitten und weitergeschickt werden.
<G-vec00903-002-s113><cut_up.ausschneiden><en> Make a collage of images you cut out from magazines by overlapping them on your cardstock.
<G-vec00903-002-s113><cut_up.ausschneiden><de> Erstelle eine Collage aus Bildern, die du aus Zeitschriften ausgeschnitten hast, indem du sie überlappend auf dem Karton anbringst.
<G-vec00903-002-s114><cut_up.ausschneiden><en> You need to do some video editing: cut unnecessary parts out (otherwise the whole thing can easily become boring; the professional movie makers cut pretty much out, some episodes are later included as specials on the DVD, but they don't appear in the actual movie; there is also a difference between theatrical and DVD (extended) editions), add transitions between episodes to make the movie smooth, add titles or subtitles where needed, emphasize some moments by zooming in while showing the whole picture in a smaller box (picture in picture), and so on.
<G-vec00903-002-s114><cut_up.ausschneiden><de> Sie brauchen eine Videobearbeitung durchzuführen: nicht nötige Teilen ausschneiden (sonst kann das Ganze langweilig werden; bei professionellen Filmen scheidet man ziemlich viel aus, manche Episoden werden später als Extras zur DVD hinzugefügt, sie erscheinen aber nicht im Film; es gibt auch einen Unterschied zwischen Kino- und DVD-Versionen), Übergänge zwischen Episoden hinzufügen, Untertitel und andere Beschriftungen hinzufügen, einige Momenten mit Zoom betonen und das ganze Bild in kleinerer Box zeigen (Bild im Bild) usw.
<G-vec00903-002-s115><cut_up.ausschneiden><en> + Trim, cut and crop your photos and video clips.
<G-vec00903-002-s115><cut_up.ausschneiden><de> + Trimmen, Ausschneiden und Beschneiden Ihrer Fotos.
<G-vec00903-002-s116><cut_up.ausschneiden><en> Magic Wand Edit Commands: You can now use the cut, copy, paste, and duplicate edit commands on magic wand selections, allowing you to break models up into multiple pieces.
<G-vec00903-002-s116><cut_up.ausschneiden><de> Bearbeitungsbefehle für den Zauberstab: Sie können jetzt die Bearbeitungsbefehle „Ausschneiden“, „Kopieren“, „Einfügen“ und „Duplizieren“ auf Zauberstab-Auswahlen anwenden, um Modelle in mehrere Teile zu unterteilen.
<G-vec00903-002-s117><cut_up.ausschneiden><en> Then hold the orange over the bowl and cut the orange fillets out of the fruit.
<G-vec00903-002-s117><cut_up.ausschneiden><de> Danach die Orange über der Schüssel halten und Orangenfilets aus der Frucht ausschneiden.
<G-vec00903-002-s118><cut_up.ausschneiden><en> Select the content frame, and choose Edit > Cut.
<G-vec00903-002-s118><cut_up.ausschneiden><de> Markieren Sie den Inhaltsrahmen und wählen Sie „Bearbeiten“ > „Ausschneiden“.
<G-vec00903-002-s119><cut_up.ausschneiden><en> With a knife cut out a hole through the circle and the pie.
<G-vec00903-002-s119><cut_up.ausschneiden><de> Mit dem Messer aus diesm Kreis ein Loch ausschneiden.
<G-vec00903-002-s120><cut_up.ausschneiden><en> When you're working with your files in FX File Explorer, you'll find the classic options you'd expect from a the desktop computer: copy, paste, cut, create, delete, rename.
<G-vec00903-002-s120><cut_up.ausschneiden><de> In FX File Explorer findet man alle Funktionen die man auch vom Desktop-PC kennt: Kopieren, Einfügen, Ausschneiden, Erstellen, Löschen, Umbenennen.
<G-vec00903-002-s121><cut_up.ausschneiden><en> Cut out flowers - cubic...
<G-vec00903-002-s121><cut_up.ausschneiden><de> Blumen ausschneiden -...
<G-vec00903-002-s122><cut_up.ausschneiden><en> Cut 2 small squares out of the blue Gaffer tape and glue them to the head to make the eyes.
<G-vec00903-002-s122><cut_up.ausschneiden><de> Aus dem blauen Gaffer Tape 2 kleine Quadrate ausschneiden und als Augen auf den Kopf kleben.
<G-vec00903-002-s123><cut_up.ausschneiden><en> You can cut/copy/paste/move/delete/rename files using Tabbles.
<G-vec00903-002-s123><cut_up.ausschneiden><de> Du kannst Dateien ausschneiden/kopieren/einfügen/bewegen /löschen/umbenennen.
<G-vec00903-002-s124><cut_up.ausschneiden><en> If you have lousy handwriting, and no to/from cards or stickers, you can cut a square of coordinating wrapping paper, fold it into a "card", and tape it in place.
<G-vec00903-002-s124><cut_up.ausschneiden><de> Wenn du eine lausige Handschrift hast und keine von/an Karten oder Sticker, kannst du ein Quadrat aus abgestimmtem Geschenkpapier ausschneiden, es zu einer "Karte" falten und es festkleben.
<G-vec00903-002-s125><cut_up.ausschneiden><en> You can cut out pictures and set the area as a background image, the one you like best.
<G-vec00903-002-s125><cut_up.ausschneiden><de> Du kannst Fotos ausschneiden und den Bereich als Hintergrundbild einstellen, der dir am besten gefällt.
<G-vec00903-002-s126><cut_up.ausschneiden><en> Click the Cut button on the toolbar to move the folder and its contents to the clipboard.
<G-vec00903-002-s126><cut_up.ausschneiden><de> Klicken Sie in der Symbolleiste auf die Schaltfläche Ausschneiden, um den Ordner und seinen Inhalt in die Zwischenablage zu verschieben.
<G-vec00903-002-s127><cut_up.ausschneiden><en> When you scroll down, you will see that Google Cloud has built a web-based interface that lets you cut and paste any text into the page.
<G-vec00903-002-s127><cut_up.ausschneiden><de> Wenn Sie nach unten scrollen, werden Sie sehen, dass Google Cloud eine webbasierte Benutzeroberfläche entwickelt hat, mit der Sie jeden beliebigen Text in die Seite ausschneiden und einfügen können.
<G-vec00903-002-s128><cut_up.ausschneiden><en> If you selected an entire row or column and you select Edit > Cut, the entire row or column is removed from the table (not just the contents of the cells).
<G-vec00903-002-s128><cut_up.ausschneiden><de> Wenn Sie eine ganze Zeile oder Spalte und „Bearbeiten“ > „Ausschneiden“ ausgewählt haben, wird die ganze Zeile oder Spalte (und nicht nur der Inhalt der Zellen) aus der Tabelle entfernt.
<G-vec00903-002-s129><cut_up.ausschneiden><en> To make the beak for the penguin, have the child cut a small triangle out of the orange construction paper.
<G-vec00903-002-s129><cut_up.ausschneiden><de> Lasse das Kind, um den Schnabel für den Pinguin zu machen, ein kleines Dreieck aus dem orangen Bastelpapier ausschneiden.
<G-vec00903-002-s130><cut_up.ausschneiden><en> The default shortcuts Ctrl+C (copy), Ctrl+X (cut) and Ctrl+V (paste) can be used for editing.
<G-vec00903-002-s130><cut_up.ausschneiden><de> Die Standard-Tastenkürzel Strg+C (Kopieren), Strg+X (Ausschneiden) und Strg+V (Einfügen) können für das Bearbeiten verwendet werden.
<G-vec00903-002-s131><cut_up.ausschneiden><en> C. Cut: You can use the cut option to move a component from one place to another in the adaptive form.
<G-vec00903-002-s131><cut_up.ausschneiden><de> D. Ausschneiden: Sie können die Option zum Ausschneiden verwenden, um eine Komponente von einer Position in der interaktiven Kommunikation an eine andere Position zu verschieben.
<G-vec00903-002-s380><cut_up.reduzieren><en> He told the forum it made sense to cut the number in the French-speaking region.
<G-vec00903-002-s380><cut_up.reduzieren><de> Im RTS-Forum schrieb er, in der französischsprachigen Westschweiz würde es durchaus Sinn machen, die Anzahl der Geräte zu reduzieren.
<G-vec00903-002-s381><cut_up.reduzieren><en> With a corrugated box cutting machine, you will not only be able to cut the costs of packaging supplies that your company uses, but you will also be able to cut the shipping costs that your company is constantly incurring as well.
<G-vec00903-002-s381><cut_up.reduzieren><de> Mithilfe von Wellpappe-Schneidemaschinen werden Sie nicht nur die Kosten der Verpackungsmaterialien Ihres Unternehmens, sondern auch die Versandkosten reduzieren können, die Ihrem Unternehmen laufend entstehen.
<G-vec00903-002-s382><cut_up.reduzieren><en> Cut energy costs across your distributed office by 35 percent and gain 100 percent visibility into the energy usage of every device in your data center.
<G-vec00903-002-s382><cut_up.reduzieren><de> Reduzieren Sie die Stromkosten an verteilten Standorten um 35 Prozent und sorgen Sie für vollständige Transparenz hinsichtlich des Energieverbrauchs jedes einzelnen Geräts in Ihrem Rechenzentrum.
<G-vec00903-002-s383><cut_up.reduzieren><en> In October 2012, a cogeneration plant was taken into service at the company's largest production site in Wiesloch-Walldorf, Germany. In the future, this plant will cut the site's energy costs by 10 percent and save 3,700 metric tons of CO2 each year.
<G-vec00903-002-s383><cut_up.reduzieren><de> Im Oktober 2012 ging am Standort Wiesloch-Walldorf - dem größten Produktionsstandort des Unternehmens - ein Blockheizkraftwerk in Betrieb, das künftig die Energiekosten des Standortes um zehn Prozent reduzieren wird, und das jährlich 3.700 Tonnen CO2 einspart.
<G-vec00903-002-s384><cut_up.reduzieren><en> And best of all, a line with of OneStep technology can cut your total cost of ownership drastically.
<G-vec00903-002-s384><cut_up.reduzieren><de> Und das Beste: Eine Prozesslinie mit OneStep-Technologie kann Ihre Gesamtbetriebskosten drastisch reduzieren.
<G-vec00903-002-s385><cut_up.reduzieren><en> One of the features of the polarizing filter is that it can cut out reflections that appear in a water surface or glass window.
<G-vec00903-002-s385><cut_up.reduzieren><de> Ein Merkmal von Polfiltern besteht darin, dass er Spiegelungen auf Wasseroberflächen oder Fensterscheiben erheblich reduzieren kann.
<G-vec00903-002-s386><cut_up.reduzieren><en> Sorry,you have to pay it first,but we'll cut the costs in your next order(20GP).
<G-vec00903-002-s386><cut_up.reduzieren><de> Tut mir leid müssen Sie es zuerst zahlen, aber wir reduzieren die Kosten in Ihrem folgenden Auftrag (20GP).
<G-vec00903-002-s387><cut_up.reduzieren><en> Cut engineering time and costs to meet your customers' expectations.
<G-vec00903-002-s387><cut_up.reduzieren><de> Reduzieren Sie Entwicklungszeit und -kosten und erfüllen Sie die Anforderungen Ihrer Kunden.
<G-vec00903-002-s388><cut_up.reduzieren><en> They’re not supposed to cut costs; they’re supposed to improve processes.
<G-vec00903-002-s388><cut_up.reduzieren><de> Sie sollen nicht Kosten reduzieren, sondern Prozesse verbessern.
<G-vec00903-002-s389><cut_up.reduzieren><en> The electricity costs for one and two-family homes can be cut by 25 to 40 percent.
<G-vec00903-002-s389><cut_up.reduzieren><de> Die Stromkosten im Ein- und Zweifamilienhaus lassen sich um 25 bis 40 Prozent reduzieren.
<G-vec00903-002-s390><cut_up.reduzieren><en> If your insulin is high, you're likely consuming too much sugar and need to cut back.
<G-vec00903-002-s390><cut_up.reduzieren><de> Wenn der Insulinspiegel hoch ist, konsumieren Sie wahrscheinlich zu viel Zucker und müssen Ihre Zuckerzufuhr reduzieren.
<G-vec00903-002-s391><cut_up.reduzieren><en> Writing about what you are doing can help you explore and express what you are feeling as you cut back or quit using marijuana.
<G-vec00903-002-s391><cut_up.reduzieren><de> Darüber zu schreiben, was du machst, kann dir helfen, herauszufinden und auszudrücken, was du empfindest, während du versuchst, deinen Marihuanakonsum zu reduzieren.
<G-vec00903-002-s392><cut_up.reduzieren><en> Take advantage of innovative products that optimize your manufacturing process, cut your water consumption and improve pulp quality.
<G-vec00903-002-s392><cut_up.reduzieren><de> Profitieren Sie von innovativen Produkten, die Ihren Herstellungsprozess optimieren, den Wasser- und Energieverbrauch reduzieren und die Zellstoffqualität verbessern.
<G-vec00903-002-s393><cut_up.reduzieren><en> Around the world, businesses of all shapes and sizes trust us to deliver technology systems that cut complexity, quickly.
<G-vec00903-002-s393><cut_up.reduzieren><de> Überall auf der Welt vertrauen Unternehmen aller Formen und Größen uns, Technologiesysteme zu liefern, die die Komplexität schnell reduzieren.
<G-vec00903-002-s394><cut_up.reduzieren><en> This is a bottle for life which you can use to cut down your personal plastic consumption in a heartbeat.
<G-vec00903-002-s394><cut_up.reduzieren><de> Diese Flasche kann euer neuer, lebenslanger Begleiter werden, mit dem ihr auch euren persönlichen Plastikverbrauch einfach reduzieren könnt.
<G-vec00903-002-s395><cut_up.reduzieren><en> Most likely I will cut back in the next few years, continuing to see my regular clients, but not taking on any new people.
<G-vec00903-002-s395><cut_up.reduzieren><de> Höchstwahrscheinlich werde ich in den nächsten paar Jahren reduzieren, das heißt meine regelmäßigen Kunden weiterhin treffen, aber keine neuen mehr annehmen.
<G-vec00903-002-s396><cut_up.reduzieren><en> If you want to cut your company’s trade show costs drastically, there is no way around meticulous planning.
<G-vec00903-002-s396><cut_up.reduzieren><de> Wer die Messekosten seines Unternehmens drastisch reduzieren möchte, kommt nicht um eine detaillierte Planung herum.
<G-vec00903-002-s397><cut_up.reduzieren><en> As a result, the charging time for a lithium-ion battery could be cut from an hour to just 12 minutes.
<G-vec00903-002-s397><cut_up.reduzieren><de> Demzufolge ließe sich die Ladezeit eines Lithium-Ionen-Akkus von einer Stunde auf gerade einmal zwölf Minuten reduzieren.
<G-vec00903-002-s398><cut_up.reduzieren><en> According to the developers, this device can significantly cut costs related to lab tests for diseases such as HIV, syphilis, and Lyme disease.
<G-vec00903-002-s398><cut_up.reduzieren><de> Entsprechend den Entwicklern kann diese Einheit die Kosten beträchtlich reduzieren, die auf Laborversuchen für Krankheiten wie HIV, Syphilis und Lyme-Borreliose in Verbindung gestanden werden.
<G-vec00903-002-s247><cut_up.schneiden><en> The pink 80's net shirt is very wide cut and therefore fits to any size.
<G-vec00903-002-s247><cut_up.schneiden><de> Das pinke 80er Jahre Netz Shirt ist sehr weit geschnitten und passt deswegen zu jeder Größe.
<G-vec00903-002-s248><cut_up.schneiden><en> Every day an episode is filmed, cut, plotted and a dialogue book form is written out...
<G-vec00903-002-s248><cut_up.schneiden><de> Jeden Tag wird eine Folge gedreht, eine geschnitten, eine geplottet, eine in Dialogbuchform ausformuliert...
<G-vec00903-002-s249><cut_up.schneiden><en> One of its characteristics is that it is not cut, but pared – using a device such as the Girolle or Pirouette – to make delicate rosettes.
<G-vec00903-002-s249><cut_up.schneiden><de> Eine seiner Besonderheiten: Er wird nicht geschnitten, sondern mit einem Schabgerät wie der Girolle oder der Pirouette zu feinen Rosetten gedreht.
<G-vec00903-002-s250><cut_up.schneiden><en> Details Straight cut jacket in super-stretch bull cotton with shirt collar, long sleeves with buttoned cuffs, patch pockets with flap on the chest and inset pockets on the sides.
<G-vec00903-002-s250><cut_up.schneiden><de> Details Leichter Popeline-Mantel aus Stretch-Baumwolle, gerade geschnitten, mit langen Ärmeln mit Reißverschluss, aufgesetzten Taschen mit Druckknopf und abnehmbarer Unterseite mit Reißverschluss.
<G-vec00903-002-s251><cut_up.schneiden><en> Designed, printed, cut, glued.
<G-vec00903-002-s251><cut_up.schneiden><de> Entworfen, gedruckt, geschnitten, geklebt.
<G-vec00903-002-s252><cut_up.schneiden><en> Various shapes, logos or lettering can be cut very quickly.
<G-vec00903-002-s252><cut_up.schneiden><de> Es können sehr schnell verschieden Formen, Logos oder Schriftzüge geschnitten werden.
<G-vec00903-002-s253><cut_up.schneiden><en> Wedges must always be cut and used in such a way that nails can be driven into the side along which the grain runs.
<G-vec00903-002-s253><cut_up.schneiden><de> Keile müssen grundsätzlich so geschnitten und eingesetzt werden, dass in die Faser des Holzes genagelt werden kann.
<G-vec00903-002-s254><cut_up.schneiden><en> For printing postage stamps the paper (substrate) as the basic material is either cut into individual sheets (typographical designation "sheet fed printing") or comes from a roll (typographical designation "cylinder").
<G-vec00903-002-s254><cut_up.schneiden><de> Das Druckpapier (der Bedruckstoff) als Ausgangsmaterial ist beim Briefmarkendruck entweder in einzelne Bogen geschnitten (drucktechnische Bezeichnung "Bogendruck") oder es stammt von einer Rolle (drucktechnische Bezeichnung "Rollendruck").
<G-vec00903-002-s255><cut_up.schneiden><en> SAINT-NAZAIRE, FRANCE – Nov. 21, 2016 – The next generation of cruise ships moves from concept to construction today, as the first piece of steel is cut at the STX France shipyard for Celebrity Cruises’ newest — and boldest — ship.
<G-vec00903-002-s255><cut_up.schneiden><de> Stahlschnitt für die Celebrity Edge Foto von links nach rechts: Jean-Yves Jaouen, Auf der STX Werft in Saint-Nazaire wurde nun das erste Stück Stahl für das neueste und kühnste Schiff von Celebrity Cruises geschnitten.
<G-vec00903-002-s256><cut_up.schneiden><en> During the Halvas is still warm, it is cut, weighed and packed by hand.
<G-vec00903-002-s256><cut_up.schneiden><de> Während der Halvas noch warm ist, wird er von Hand geschnitten, abgewogen und verpackt.
<G-vec00903-002-s257><cut_up.schneiden><en> Wood with a small diameter (preferably Oak) is selected, which is usually cut down in winter.
<G-vec00903-002-s257><cut_up.schneiden><de> Es wird Holz mit einem kleinen Durchmesser (vorzugsweise Eiche) ausgewählt, das im Winter geschnitten wird.
<G-vec00903-002-s258><cut_up.schneiden><en> Hedges and bushes should be cut again, which would give the final.
<G-vec00903-002-s258><cut_up.schneiden><de> Hecken und Sträucher sollten mal wieder geschnitten werden, das würde das Gesamtbild verschönern.
<G-vec00903-002-s259><cut_up.schneiden><en> Fortunately, they are cheap and can still be cut into four pieces.
<G-vec00903-002-s259><cut_up.schneiden><de> Zum Glück sind sie billig und können immer noch in vier Stücke geschnitten werden.
<G-vec00903-002-s260><cut_up.schneiden><en> The tool box has been cut using my Cameo.
<G-vec00903-002-s260><cut_up.schneiden><de> Der Werkzeugkasten ist mit meiner Cameo geschnitten.
<G-vec00903-002-s261><cut_up.schneiden><en> When you cut from a close-up to a long shot, the viewer no longer sees the details, and it is thus easier to make a chronological jump.
<G-vec00903-002-s261><cut_up.schneiden><de> Wenn von der Naheinstellung in die Totale geschnitten wird, sieht der Zuschauer die Details nicht mehr und ein Zeitsprung kann so leichter integriert werden.
<G-vec00903-002-s262><cut_up.schneiden><en> The cube as well as the bird are cut with the Silhouette Cameo.
<G-vec00903-002-s262><cut_up.schneiden><de> Der Würfel und auch der Vogel sind mit der Silhouette Cameo geschnitten.
<G-vec00903-002-s263><cut_up.schneiden><en> One bitter pepper is cleaned from the seeds, then cut into thin strips.
<G-vec00903-002-s263><cut_up.schneiden><de> Ein bitterer Pfeffer wird von den Samen befreit und dann in dünne Streifen geschnitten.
<G-vec00903-002-s264><cut_up.schneiden><en> The spring onions I cut into small pieces, also some brown mushrooms.
<G-vec00903-002-s264><cut_up.schneiden><de> Die Frühlingszwiebeln habe ich klein geschnitten, genauso ein paar braune Champignons.
<G-vec00903-002-s265><cut_up.schneiden><en> You can whip them on very quickly, they are cut wide to wear pullovers or cardigans underneath, and we don?t see any problem in playing games in the garden: the ponchos are made of cotton and can be washed in hot water.
<G-vec00903-002-s265><cut_up.schneiden><de> Sie sind blitzschnell übergezogen, weit geschnitten, um Pullover oder Strickjacken unterzuziehen und zudem steht dem ausgelassenen Spielen im Garten nichts im Wege: sie sind aus Baumwolle gewebt und können heiß gewaschen werden.
<G-vec00903-002-s418><cut_up.schneiden><en> Cut the cards out and put one in your wallet for the upcoming week.
<G-vec00903-002-s418><cut_up.schneiden><de> Schneide die Tabellen aus und verstaue eine dieser Karten in deiner Brieftasche.
<G-vec00903-002-s419><cut_up.schneiden><en> As you go along, cut each string 2 inches longer.
<G-vec00903-002-s419><cut_up.schneiden><de> Schneide, wenn du weitermachst, jede Schnur 5 cm länger ab.
<G-vec00903-002-s420><cut_up.schneiden><en> Place the foam on the linen and cut a fitting rectangle.
<G-vec00903-002-s420><cut_up.schneiden><de> Platziere den Schaumstoff auf dem Leinen und schneide ein passendes Rechteck zum Einschlagen zu.
<G-vec00903-002-s421><cut_up.schneiden><en> Meanwhile, wash and cut your chosen fruits.
<G-vec00903-002-s421><cut_up.schneiden><de> Wasche und schneide inzwischen dein gewähltes Obst.
<G-vec00903-002-s422><cut_up.schneiden><en> Cut the puff pastry into squares.
<G-vec00903-002-s422><cut_up.schneiden><de> Schneide den Blätterteig in Quadrate.
<G-vec00903-002-s423><cut_up.schneiden><en> Then, cut a leaf shape.
<G-vec00903-002-s423><cut_up.schneiden><de> Schneide einen langen 1cm Klebebandstreifen.
<G-vec00903-002-s424><cut_up.schneiden><en> Cut a log of pre-made cookie dough into even rounds.
<G-vec00903-002-s424><cut_up.schneiden><de> Schneide den vorgefertigten Plätzchenteig in gleichmäßige, runde Stücke.
<G-vec00903-002-s425><cut_up.schneiden><en> 9 Then He said: Take for me a three-year-old cow, a three-year-old goat, a three-year-old male sheep, a dove, and a young pigeon. 10 And he took all these animals, cut them up in halves for sacrifice, laying each half opposite the other half, but he did not cut the birds in half.
<G-vec00903-002-s425><cut_up.schneiden><de> 1Mo 15,9 [9/10] Da sagte der Herr: »Bring mir eine dreijährige Kuh, eine dreijährige Ziege, einen dreijährigen Schafbock, eine Turteltaube und eine junge Taube; schneide sie mittendurch, und lege die Hälften einander gegenüber.
<G-vec00903-002-s426><cut_up.schneiden><en> Let cool completely, then cut in half and fill with pastry cream and fruit preserve or jam.
<G-vec00903-002-s426><cut_up.schneiden><de> Lass sie komplett auskühlen, schneide sie dann halb durch und fülle sie mit Hilfe eines Spritzbeutels mit der Crème und Marmelade.
<G-vec00903-002-s427><cut_up.schneiden><en> Cut your pieces out.
<G-vec00903-002-s427><cut_up.schneiden><de> Schneide deinen Stoff.
<G-vec00903-002-s428><cut_up.schneiden><en> 2 Poke the knife through the belly of the fish and cut towards the tail.
<G-vec00903-002-s428><cut_up.schneiden><de> Schneide den Schwanz ab, wenn du es nicht bereits getan hast und schneide den Kopf mit dem großen Messer ab.
<G-vec00903-002-s429><cut_up.schneiden><en> Cut the exposed hair, with your scissors perpendicular to the comb or your fingers.
<G-vec00903-002-s429><cut_up.schneiden><de> Schneide die freiliegenden Haare mit deiner Schere senkrecht zu deinem Kamm oder einen Fingern ab.
<G-vec00903-002-s430><cut_up.schneiden><en> Do not cut off the thread or yarn; you will continue weaving with it.
<G-vec00903-002-s430><cut_up.schneiden><de> Schneide den Faden nicht ab; du fährst damit fort, ihn zu weben.
<G-vec00903-002-s431><cut_up.schneiden><en> If you bought a long fillet of salmon, carefully use a sharp knife to cut the salmon into individual fillets.
<G-vec00903-002-s431><cut_up.schneiden><de> Falls du ein langes Lachsfilet gekauft hast, schneide es mit einem scharfen Messer vorsichtig in einzelne Filets.
<G-vec00903-002-s432><cut_up.schneiden><en> Cut an end in the proper place with a scissors before laying it down.
<G-vec00903-002-s432><cut_up.schneiden><de> Schneide eine Ecke an der richtigen Stelle mit einer Schere ein, bevor du es anbringst.
<G-vec00903-002-s433><cut_up.schneiden><en> Cut off (a part of) the stem.
<G-vec00903-002-s433><cut_up.schneiden><de> Schneide auch ein Stück vom Stiel ab.
<G-vec00903-002-s434><cut_up.schneiden><en> To take a spore print, take a mushroom, cut the cap away from the stem using a sharp knife, and place it gills down on a piece of paper.
<G-vec00903-002-s434><cut_up.schneiden><de> Um einen Sporenabdruck zu nehmen, nimm einen Pilz, schneide die Kappe mit einem scharfen Messer vom Stiel und leg sie mit den Lamellen nach unten auf ein Stück Papier.
<G-vec00903-002-s435><cut_up.schneiden><en> 1 Cut cotton cloth into small squares.
<G-vec00903-002-s435><cut_up.schneiden><de> 1 Schneide Baumwollstoff in kleine Quadrate.
<G-vec00903-002-s436><cut_up.schneiden><en> Cut along the edge of the fold with sharp scissors.
<G-vec00903-002-s436><cut_up.schneiden><de> Schneide mit einer scharfen Schere an der Kante der Faltung entlang.
<G-vec00903-002-s437><cut_up.schneiden><en> Also wash the scallions and cut them in rings.
<G-vec00903-002-s437><cut_up.schneiden><de> Frühlingszwiebeln waschen und in Ringe schneiden.
<G-vec00903-002-s438><cut_up.schneiden><en> For stuffing cut the pretzels and pour hot milk over them.
<G-vec00903-002-s438><cut_up.schneiden><de> Für die Füllung die Brezen schneiden und mit heißer Milch übergießen.
<G-vec00903-002-s439><cut_up.schneiden><en> Cut off mains cable and dispose of together with plug.
<G-vec00903-002-s439><cut_up.schneiden><de> Schneiden Sie das Netzkabel ab und entsorgen Sie es zusammen mit dem Stecker.
<G-vec00903-002-s440><cut_up.schneiden><en> To cut an audio track, simply click on a particular spot and then click on the scissors symbol for editing.
<G-vec00903-002-s440><cut_up.schneiden><de> Einfachste Bedienung: Zum Schneiden markieren Sie einfach die entsprechende Stelle in der Audiospur und drücken dann das Schere-Symbol.
<G-vec00903-002-s441><cut_up.schneiden><en> 125ml water Preparation Peel peach, remove stone, and cut into pieces.
<G-vec00903-002-s441><cut_up.schneiden><de> Spinat waschen und in kleine Stücke schneiden oder - wenn möglich - häkseln.
<G-vec00903-002-s442><cut_up.schneiden><en> Cut onions into thin rings.
<G-vec00903-002-s442><cut_up.schneiden><de> Zwiebeln in feine Ringe schneiden.
<G-vec00903-002-s443><cut_up.schneiden><en> Cut the black drawing out with a stanley knife.
<G-vec00903-002-s443><cut_up.schneiden><de> Schneiden Sie die schwarzen Markierungen mit einem Stanleymesser aus.
<G-vec00903-002-s444><cut_up.schneiden><en> Particularly my mom is looking forward to the release of Season 1.1 - as I still have a bet running to NOT cut my hear (or beard for that matter) until we ship the first product.
<G-vec00903-002-s444><cut_up.schneiden><de> Insbesondere meine Mutter freut sich auf den Verkauf der Season 1.1 - auf Grund eines Versprechens darf ich nämlich meine Haare (inklusive Bart) nicht schneiden, bis wir das Erste Päckchen rausschicken.
<G-vec00903-002-s445><cut_up.schneiden><en> General purpose diamond blade is perfect for those contractors who need to cut a wide variety of different materials.
<G-vec00903-002-s445><cut_up.schneiden><de> Universelles Diamantblatt ist für jene Auftragnehmer perfekt, die eine große Vielfalt von verschiedenen Materialien schneiden müssen.
<G-vec00903-002-s446><cut_up.schneiden><en> You will also end up using less dye if you cut your hair first, because you will have less hair to work with.
<G-vec00903-002-s446><cut_up.schneiden><de> Außerdem sparst du an der Färbung, weil es nach dem Schneiden weniger zu färben gibt.
<G-vec00903-002-s447><cut_up.schneiden><en> By using this circle as templates, cut the cloth the right amount of disks.
<G-vec00903-002-s447><cut_up.schneiden><de> Durch die Nutzung dieser Kreis als Vorlagen, schneiden Sie das Tuch die richtige Menge an Platten.
<G-vec00903-002-s448><cut_up.schneiden><en> For the finishing touch, peel the remaining squash and cut it into cubes.
<G-vec00903-002-s448><cut_up.schneiden><de> Schälen Sie den verbliebenen Kürbis und schneiden Sie ihn in Würfel.
<G-vec00903-002-s449><cut_up.schneiden><en> Wash the peppers and cut into strips.
<G-vec00903-002-s449><cut_up.schneiden><de> Paprika waschen und in Streifen schneiden.
<G-vec00903-002-s450><cut_up.schneiden><en> Do not use tools for purposes not intended; for example, do not use circular saws to cut tree limbs or logs. Similar Manual de Instruções
<G-vec00903-002-s450><cut_up.schneiden><de> Benützen Sie Werkzeuge nicht für Zwecke und Arbeiten, Wofür sie nicht bestimmt sind; zum Beispiel benützen Sie keine Handkreissäge, um Bäume zu flällen oder Äste zu schneiden.
<G-vec00903-002-s451><cut_up.schneiden><en> Preparation Cut the mild Manchego cheese into triangles and dry with a kitchen cloth.
<G-vec00903-002-s451><cut_up.schneiden><de> Zubereitung Den jungen Manchego-Käse in Dreiecke schneiden und mit einem Küchentuch abtrocknen.
<G-vec00903-002-s452><cut_up.schneiden><en> All you have to do is cut up the peel and put it in the disposal.
<G-vec00903-002-s452><cut_up.schneiden><de> Du musst die Schale nur schneiden und in den Mülleimer geben.
<G-vec00903-002-s453><cut_up.schneiden><en> NOCH Laser-Cut Texture Sheets can be easily cut with a knife or scissors, they are easy to shape and to process. The advantages of the NOCH Laser-Cut Texture Sheets:
<G-vec00903-002-s453><cut_up.schneiden><de> Dank der Herstellung aus hochwertigen Kartonagen können Sie die NOCH Laser-Cut Bodenplatten mit einer Schere oder einem Messer schnell und einfach in Form schneiden.
<G-vec00903-002-s454><cut_up.schneiden><en> Cut the bowl out two different types of wood and mix the parts during assembly.
<G-vec00903-002-s454><cut_up.schneiden><de> Schneiden Sie die Schale aus zwei verschiedenen Holzarten und mischen Sie die Einzelteile beim Zusammenbau zusammen.
<G-vec00903-002-s455><cut_up.schneiden><en> They are rust-free and generate little resistance when they cut through the material.
<G-vec00903-002-s455><cut_up.schneiden><de> Sie sind rostfrei und erzeugen wenig Widerstand, wenn sie durch das Material schneiden.
<G-vec00903-002-s456><cut_up.schneiden><en> The machine uses a sawing unit to cut diagonally through the rectangular unprocessed part. It moves the two halves apart so that the four- or five-piece spindles can trim and profile the steps from all sides.
<G-vec00903-002-s456><cut_up.schneiden><de> Mit einem Sägeaggregat schneidet die Maschine diagonal durch den rechteckigen Rohling und fährt beide Hälften soweit auseinander, dass die Vier- oder Fünfachsspindel die Stufen ringsherum fräsen und profilieren kann.
<G-vec00903-002-s457><cut_up.schneiden><en> Peter Breuer, on the other hand, now prepares the schedule for the next several days, and works with his “music guy” to cut the songs down to a suitable length.
<G-vec00903-002-s457><cut_up.schneiden><de> Peter Breuer hingegen bereitet noch den Plan für die nächsten Tage vor und schneidet mit seinem Ton-Verantwortlichen die Songs auf die richtige Länge zu.
<G-vec00903-002-s458><cut_up.schneiden><en> Zum Vergrößern bitte anklicken / click to enlarge Take your scissors and your first piece of cardstock and cut your score lines exactly like the purple lines in the sketch show from the upper line to the middle mark you just made.
<G-vec00903-002-s458><cut_up.schneiden><de> Wiederholt das mit dem anderen Stück noch einmal genau Jetzt nehmt ihr euch eine Schere und schneidet beim ersten Stück Cardstock von oben bis zum markierten Mittelpunkt die Falzlinie ein, genau wie die lilafarbenen Linien in der Skizze es zeigen.
<G-vec00903-002-s459><cut_up.schneiden><en> Then cut a window in one of the large sections.
<G-vec00903-002-s459><cut_up.schneiden><de> Schneidet dann in einen der Deckel ein Fenster.
<G-vec00903-002-s460><cut_up.schneiden><en> If you cut the upper portion of your body, as soon as you see inside, it is all obnoxious horrible things.
<G-vec00903-002-s460><cut_up.schneiden><de> Wenn ihr in den oberen Teil des Körpers schneidet, sobald ihr hineinseht, ist alles darin abstoßend und grässlich.
<G-vec00903-002-s461><cut_up.schneiden><en> The dual blade system of this electric shaver lifts hairs to cut comfortably below skin level. Spring-released pop-up trimmer
<G-vec00903-002-s461><cut_up.schneiden><de> Das 2-Klingen-System dieses Elektrorasierers hebt die Haare an und schneidet sie direkt für eine sanfte Rasur an der Hautoberfläche ab.
<G-vec00903-002-s462><cut_up.schneiden><en> When laser head cut metals, there will produce some hot energy in laser head and laser device.
<G-vec00903-002-s462><cut_up.schneiden><de> Wenn der Laserkopf Metalle schneidet, wird im Laserkopf und im Lasergerät etwas heiße Energie erzeugt.
<G-vec00903-002-s463><cut_up.schneiden><en> The doctor under local anesthesia will cut a bridle or special scissors, or a laser.
<G-vec00903-002-s463><cut_up.schneiden><de> Der Arzt unter örtlicher Betäubung schneidet einen Zaum oder eine spezielle Schere oder einen Laser.
<G-vec00903-002-s464><cut_up.schneiden><en> File folder cards can be found many made with the punchboard....but not everyone has it...so I made one without First you cut your cardstock to the given size and lay it along the short side to the ScorPal and score at 10,5 cm...
<G-vec00903-002-s464><cut_up.schneiden><de> Immer wieder findet man File Folder Karten, die mit dem Punchboard gefertigt werden...allerdings hat ja nicht jeder so ein tolles Board zur Hand...und so habe ich eine File Folder Card ohne Punchboard für euch Als erstes schneidet ihr euren Cardstock auf die passende Größe zu...anschließend legt ihr euch den Cardstock mit der langen Seite oben am ScorPal an und falzt ihn bei 10,5cm...
<G-vec00903-002-s465><cut_up.schneiden><en> Cut a slit in the lime wedge and rub it around the rim of a tall beer glass.
<G-vec00903-002-s465><cut_up.schneiden><de> Schneidet den Limettenkeil ein und streicht damit den Glasrand eines Bierglases ein.
<G-vec00903-002-s466><cut_up.schneiden><en> And so you cut yourself off.
<G-vec00903-002-s466><cut_up.schneiden><de> Und auf diese Weise schneidet ihr euch selbst ab.
<G-vec00903-002-s467><cut_up.schneiden><en> When nearly dry cut the bread into small squares and season it well with powdered sage, salt and pepper.
<G-vec00903-002-s467><cut_up.schneiden><de> Man schneidet die Stücke 2 cm dick, salzt und pfeffert sie und wendet sie leicht in Mehl um.
<G-vec00903-002-s468><cut_up.schneiden><en> Take a cardboard disk with the diameter of the telescope's optic, cut two (or three) holes in it and place it in front of the telescope.
<G-vec00903-002-s468><cut_up.schneiden><de> Man nimmt im einfachsten Fall eine Pappscheibe, die die Teleskopöffnung abdeckt, schneidet zwei runde Löcher hinein und plaziert die Scheibe vor der Teleskopöffnung.
<G-vec00903-002-s469><cut_up.schneiden><en> Roughly cut out 2 pieces from an old jeans, which are about the same size and a little larger than the stamped image.
<G-vec00903-002-s469><cut_up.schneiden><de> Grob schneidet man nun 2 ungefähr gleich große Stücke aus einer alten Jeanshose, die ein bisschen größer sind als das gestempelte Motiv.
<G-vec00903-002-s470><cut_up.schneiden><en> Cut away the things of the world, accept the leadership of Jesus Christ, or you’ll perish as sure as the world.
<G-vec00903-002-s470><cut_up.schneiden><de> Schneidet die Dinge der Welt ab und nehmt die Führerschaft Jesu Christi an, sonst werdet ihr so sicher wie die Welt umkommen.
<G-vec00903-002-s471><cut_up.schneiden><en> He uses it to cut samples from every possible source, and later these serve as the main themes for pieces.
<G-vec00903-002-s471><cut_up.schneiden><de> Damit schneidet er aus allen möglichen Quellen Samples raus, die dann als Grundmotive für Stücke dienen.
<G-vec00903-002-s472><cut_up.schneiden><en> Interreg DiveSMART Baltic Method The Cutting Extinguisher technique consists of a mixture of water and cutting agent (abrasive) being ejected through a special nozzle at high pressure (>250 bar) to cut through all known building and construction materials.
<G-vec00903-002-s472><cut_up.schneiden><de> Bei der Schneidlöschtechnik wird dem Löschwasser über eine spezielle Düse unter hohem Druck (>250 bar) ein Schneidmittel (Abrasivmittel) zugesetzt, mit dessen Hilfe der Wasserstrahl durch alle bekannten Baumaterialien schneidet.
<G-vec00903-002-s473><cut_up.schneiden><en> You can use a good pair of kitchen scissors to cut through practically anything: paper, cardboard, corrugated cardboard, string, fabric, aluminium foil or cling film and other packaging used in the kitchen, as well as of course herbs, rosemary sprigs, rhubarb, flowers etc.
<G-vec00903-002-s473><cut_up.schneiden><de> Mit einer guten Küchenschere schneidet Ihr so gut wie alles: Papier, Pappe, Wellpappe, Bindfäden, Stoff, Alu- oder Plastikfolie und andere Verpackungen rund ums Kochen, aber natürlich auch Kräuter, Rosmarinzweige, Rhabarber, Blumen usw..
<G-vec00903-002-s474><cut_up.schneiden><en> Now cut the inside of the brim.
<G-vec00903-002-s474><cut_up.schneiden><de> Jetzt schneidet ihr den inneren Kreis der Krempe aus.
<G-vec00903-002-s475><cut_up.schneiden><en> The sportive cut and the long back guarantee a comfortable fit.
<G-vec00903-002-s475><cut_up.schneiden><de> Der angenehm lockere Schnitt und die verlängerte Rückenpartie garantieren einen komfortablen Tragekomfort.
<G-vec00903-002-s476><cut_up.schneiden><en> In addition to the traditional cut for children and men, a waisted ladies cut is also available.
<G-vec00903-002-s476><cut_up.schneiden><de> Neben dem traditionellen Schnitt für Kinder und Herren ist auch ein taillierter Damenschnitt erhältlich.
<G-vec00903-002-s477><cut_up.schneiden><en> Better cut and pleasant material on the skin.
<G-vec00903-002-s477><cut_up.schneiden><de> Vorteilhafter Schnitt und angenehmes Material auf der Haut.
<G-vec00903-002-s478><cut_up.schneiden><en> • No cut on the skin and no damage of muscles around the lachrymal sac are the other advantages.
<G-vec00903-002-s478><cut_up.schneiden><de> • Kein Schnitt auf der Haut und kein Schaden von Muskeln um den tränenreichen Beutel sind die anderen Vorteile.
<G-vec00903-002-s479><cut_up.schneiden><en> The top features a sleeveless cut, a striped, elastic bottom band, and a cropped length.
<G-vec00903-002-s479><cut_up.schneiden><de> Das Oberteil hat einen ärmellosen Schnitt, ein gestreiftes, elastisches Unterteil und eine kurze Länge.
<G-vec00903-002-s480><cut_up.schneiden><en> Cut/fit: This jacket offers the special Semi Fit form with a sportive and comfortable cut.
<G-vec00903-002-s480><cut_up.schneiden><de> Schnitt/Passform: Die Zap Bike Jacke bietet eine sportliche und zugleich komfortable Schnittführung in Sugois speziellem Semi Fit Design.
<G-vec00903-002-s481><cut_up.schneiden><en> Comfortably cut in a flattering look with permanent crease, waistband extension, belt loops (belt not included), 2 slanting pockets and refined hem vents.
<G-vec00903-002-s481><cut_up.schneiden><de> Komfortabler Schnitt in figurfreundlicher Optik mit Bügelfalten, Bundverlängerung, Gürtelschlaufen (ohne Gürtel), zwei schrägen Taschen und dezenten Saumschlitzen.
<G-vec00903-002-s482><cut_up.schneiden><en> “WE BELIEVE IN WORKING CUT AND COLOUR IN SYNERGY TO CREATE CUSTOMISED LOOKS FOR...
<G-vec00903-002-s482><cut_up.schneiden><de> „Wir glauben an die Synergie von Schnitt und Farbe, um für Ihre Salonkunden persönliche Looks zu kreieren.
<G-vec00903-002-s483><cut_up.schneiden><en> On his return, he cut them up into the pot of soup; they did not know what they were.
<G-vec00903-002-s483><cut_up.schneiden><de> Wieder zurück schnitt er sie in Stücke und warf sie in den Topf, obwohl keiner von ihnen die Früchte kannte.
<G-vec00903-002-s484><cut_up.schneiden><en> Based on the scripts, our films begin to breathe because of aesthetic pictures, the tactful use of music and the sensitive cut.
<G-vec00903-002-s484><cut_up.schneiden><de> Basierend auf den Drehbüchern, beginnen unsere Filme durch ihre ästhetischen Bilder, den taktvollen Einsatz von Musik und den feinfühligen Schnitt zu atmen.
<G-vec00903-002-s485><cut_up.schneiden><en> Despite the neutral position, the edge geometry enables a soft cut to be achieved.
<G-vec00903-002-s485><cut_up.schneiden><de> Trotz der neutralen Lage ermöglicht die Schneidengeometrie einen weichen Schnitt.
<G-vec00903-002-s486><cut_up.schneiden><en> Model 620 is a regular fit, a bit slimmer cut but still suitable for the man with some strong legs and a base width of 21.5 cm.
<G-vec00903-002-s486><cut_up.schneiden><de> Modell 620 ist eine normale Passform, ein bisschen schlanker Schnitt aber immer noch geeignet für den Mann, mit einigen starken Beinen und einer Basisbreite von 21,5 cm.
<G-vec00903-002-s487><cut_up.schneiden><en> The cut has been designed to adjust to all body shapes, slightly longer in the back and not too snug over the stomach.
<G-vec00903-002-s487><cut_up.schneiden><de> Der Schnitt passt sich allen Morphologien an, hinten etwas länger und am Bauch weiter.
<G-vec00903-002-s488><cut_up.schneiden><en> Slim fit - cut closely to the body.
<G-vec00903-002-s488><cut_up.schneiden><de> Slim fit - Schnitt dicht an den Körper.
<G-vec00903-002-s489><cut_up.schneiden><en> The CutMaster offers shortest processing times, achieving uniform grain size with clean cut and minimal temperature increase.
<G-vec00903-002-s489><cut_up.schneiden><de> Der CutMaster bietet kürzeste Verarbeitungszeiten und erreicht eine gleichmäßige Korngröße mit sauberem Schnitt und minimaler Temperaturerhöhung.
<G-vec00903-002-s490><cut_up.schneiden><en> The comfortable cut drops along the leg to then draw in at the ankle cuffs.
<G-vec00903-002-s490><cut_up.schneiden><de> Der Schnitt fällt am Bein bequem und schließt mit einem Bündchen am Knöchel ab.
<G-vec00903-002-s491><cut_up.schneiden><en> More than 80 years of experience and the family philosophy passed to the next generations ensure both the charm of old school elegance as well as modern style and contemporary cut of our products.
<G-vec00903-002-s491><cut_up.schneiden><de> Mehr als 80 Jahren Erfahrung und von Generation zu Generation weitergegebene Familienphilosophie bewirkt, dass unsere Produkte sowohl einen Zauber der Eleganz „von vor vielen Jahren” als auch einen modernen Stil und aktuellen Schnitt haben.
<G-vec00903-002-s492><cut_up.schneiden><en> This well-shaped Chanty Vino dress with fashionable A-symmetric hemline dress with special cut and tailoring give your figure an elegant and feminine silhouette.
<G-vec00903-002-s492><cut_up.schneiden><de> Dieses gut geformte Chanty Vino Kleid mit speziellem Schnitt und Schneiderei verleiht Ihrer Figur eine elegante und feminine Silhouette.
<G-vec00903-002-s493><cut_up.schneiden><en> A shirt doesn’t just mean work in terms of cut and fabric, but also in print.
<G-vec00903-002-s493><cut_up.schneiden><de> Ein Hemd bedeutet nicht nur Arbeit in Sachen Schnitt und Stoff, sondern auch beim Print.
<G-vec00903-002-s513><cut_up.zerschneiden><en> By contrast, the unique Skrunda radar station, alas, was blown up, and Soviet submarines were cut up into scrap.
<G-vec00903-002-s513><cut_up.zerschneiden><de> Leider wurde ein unikales Objekt – das Radioteleskop von Skrunda gesprengt, die sowjetischen U-Boote wurden zerschnitten...
<G-vec00903-002-s514><cut_up.zerschneiden><en> For scanning APS films with the Super Coolscan 9000 ED anyway the film has to be removed out of its cartridge, cut up and placed in a special strip film holder with glass.
<G-vec00903-002-s514><cut_up.zerschneiden><de> Um dennoch APS-Filme mit dem Super Coolscan 9000 ED zu scannen, müssen diese aus der Filmspule herausgenommen, zerschnitten und in einen speziellen Filmstreifenhalter mit Glaseinsatz eingelegt werden.
<G-vec00903-002-s515><cut_up.zerschneiden><en> A further plus point: The integrated spring steel strips also have an anti-theft function in the vertical direction: If the curtain is wilfully cut, only the cut to the next spring steel strip is possible.
<G-vec00903-002-s515><cut_up.zerschneiden><de> Weiterer Pluspunkt: Die integrierten Federstahlstreifen übernehmen in vertikaler Richtung auch eine Diebstahlschutzfunktion: Wird die Plane mutwillig zerschnitten, ist nur der Schnitt bis zum nächsten Federstahlstreifen möglich.
<G-vec00903-002-s516><cut_up.zerschneiden><en> The bottom of the gown and the sleeves are cut in wedges.
<G-vec00903-002-s516><cut_up.zerschneiden><de> Der untere Teil des Gewandes sowie die Ärmel sind zu Spitzen zerschnitten.
<G-vec00903-002-s517><cut_up.zerschneiden><en> If the mats are cut remove them carefully with a dog detangling comb with rotating teeth.
<G-vec00903-002-s517><cut_up.zerschneiden><de> Wenn die Matten zerschnitten sind versuchen Sie diese vorsichtig mit einem Hundekamm mit rotierenden Zähnen zu entfernen.
<G-vec00903-002-s518><cut_up.zerschneiden><en> The pain became serious as if my internal organs were cut into pieces.
<G-vec00903-002-s518><cut_up.zerschneiden><de> Die Schmerzen wurden so stark, als würden meine inneren Organe zerschnitten.
<G-vec00903-002-s519><cut_up.zerschneiden><en> The protective sleeves are vital to ensure that the sharp edges of the concrete do not cut the belts during this movement.
<G-vec00903-002-s519><cut_up.zerschneiden><de> Dass bei dieser Bewegung nicht die scharfen Kanten des Betons zerschnitten werden, dafür sind die Kantenschutzschläuche von erheblicher Bedeutung.
<G-vec00903-002-s520><cut_up.zerschneiden><en> If we had had stabbing weapons, then we had cut our intestines.
<G-vec00903-002-s520><cut_up.zerschneiden><de> Hätten wir Stichwaffen gehabt, wir hätten uns die Eingeweide zerschnitten.
<G-vec00903-002-s521><cut_up.zerschneiden><en> Found material is copied, cut, mirrored and glued.
<G-vec00903-002-s521><cut_up.zerschneiden><de> Vorgefundenes Material wird kopiert, zerschnitten, gespiegelt und geklebt.
<G-vec00903-002-s522><cut_up.zerschneiden><en> The picture on the right illustrates the procedure: A sharp knife is used to cut a wiper into three pieces (holder, arm and blade).
<G-vec00903-002-s522><cut_up.zerschneiden><de> Das Bild rechts zeigt das Prozedere: Mit einem scharfen Messer wird der Wischer in drei Teile (Halterung, Arm und Blatt) zerschnitten.
<G-vec00903-002-s523><cut_up.zerschneiden><en> In order to achieve a complete removal, the 300 t tripod has to be cut in parts.
<G-vec00903-002-s523><cut_up.zerschneiden><de> Dafür muss das 300 Tonnen schwere Fundament in mehrere Teile zerschnitten werden.
<G-vec00903-002-s524><cut_up.zerschneiden><en> Under threat is Cameroon’s coherent and unique ecosystem which like in Tanzania, will be cut into two parts.
<G-vec00903-002-s524><cut_up.zerschneiden><de> Genau wie in Tansania würde auch in Kamerun ein zusammenhängendes einzigartiges Ökosystem in zwei Teile zerschnitten.
<G-vec00903-002-s525><cut_up.zerschneiden><en> But when the royal envoy came to him, Joseph said,42 "Go back to your lord and ask him to inquire about the matter of the women who cut their hands.
<G-vec00903-002-s525><cut_up.zerschneiden><de> Als der Bote zu ihm kam, sagte er: "Kehr zu deinem Herrn zurück und frag ihn, wie es mit den Frauen steht, die sich ihre Hände zerschnitten.
<G-vec00903-002-s526><cut_up.zerschneiden><en> It proved difficult though, as the volume really overran the audience and the high frequencies of the squeezebox and electric guitar in particular cut through the eardrum.
<G-vec00903-002-s526><cut_up.zerschneiden><de> Das erwies sich jedoch meist als schwierig, da die Lautstärke das Publikum regelrecht überrollte und vor allem die hohen Frequenzen von Quetsche und E-Gitarre schier das Trommelfell zerschnitten.
<G-vec00903-002-s527><cut_up.zerschneiden><en> This is cut into small pieces and then ground it into a powder along with various types of recycled plastics.
<G-vec00903-002-s527><cut_up.zerschneiden><de> Dieses wird in kleine Teile zerschnitten und im Anschluss mit verschiedenen Arten von Recyclingkunststoffen zu einem Pulver gemahlen.
<G-vec00903-002-s528><cut_up.zerschneiden><en> We cut those animal hide thongs, threw away the two bottles of potions, and prayed to God for his protection.
<G-vec00903-002-s528><cut_up.zerschneiden><de> Wir zerschnitten diese Tierhautschnüre, warfen die zwei Medizinflaschen fort und baten Gott um seinen Schutz.
<G-vec00903-002-s529><cut_up.zerschneiden><en> In the video, the interview language is cut apart into individual word fragments.
<G-vec00903-002-s529><cut_up.zerschneiden><de> Die Interviewsprache wird hier in isolierte Worte zerschnitten und mit einer monologisierenden Off-Stimme kommentiert.
<G-vec00903-002-s530><cut_up.zerschneiden><en> Beef, buffalo, venison, rabbit or rattlesnake meat was cut into small chunks, seasoned with spicy dried chili peppers and slowly simmered in a pot over a campfire.
<G-vec00903-002-s530><cut_up.zerschneiden><de> Rindfleisch, Buffalo, Reh, Kaninchen oder Schlangenfleisch wurde in kleine Stückchen zerschnitten, mit heissen getrockneten Chili Pfeffern gewürzt und dann langsam in einem Topf über einem Kampingfeuer gekocht.
<G-vec00903-002-s531><cut_up.zerschneiden><en> A geometric shape which is cut up in one place is always the same.
<G-vec00903-002-s531><cut_up.zerschneiden><de> Gleich ist immer eine geometrische Form, die an einer Stelle zerschnitten ist.
