<G-vec00893-002-s028><brim.bersten><en> And for the first time in a long time the churches everywhere here were filled to the brim with people who normally do not go to church.
<G-vec00893-002-s028><brim.bersten><de> Und zum ersten Mal seit langer Zeit waren unsere Kirchen hier bis zum Bersten mit Menschen gefüllt, die normalerweise sonst nicht in die Kirche gehen.
<G-vec00893-002-s049><brim.füllen><en> Wonderfully spicy, fresh and filled to the brim with mussels, noodles, and spinach.
<G-vec00893-002-s049><brim.füllen><de> Angenehm scharf, frisch und gut gefüllt mit Muscheln, Nudeln und Spinat.
<G-vec00893-002-s050><brim.füllen><en> The research pipeline is filled to the brim and in 2009 was awarded the title of “Best Cardiovascular Pipeline” by the renowned US magazine “R&D Directions”.
<G-vec00893-002-s050><brim.füllen><de> Die Forschungs-Pipeline ist prall gefüllt und wurde 2009 vom angesehenen US-Magazin „R&D Directions“ mit dem Titel „Beste kardiovaskuläre Pipeline“ ausgezeichnet.
