<G-vec00196-002-s038><cause.anrichten><en> Electrical surges can cause severe damages, which cannot be averted by taking traditional preventive measures.
<G-vec00196-002-s038><cause.anrichten><de> Überspannungen können hier immense Schäden anrichten, die durch althergebrachte Vorsorgemaßnahmen nicht verhindert werden können.
<G-vec00196-002-s039><cause.anrichten><en> Capture this creepy pair before they cause any more chaos!
<G-vec00196-002-s039><cause.anrichten><de> Nimm dieses gruselige Pärchen in Gewahrsam, bevor die beiden noch mehr Chaos anrichten.
<G-vec00196-002-s040><cause.anrichten><en> 2011 Because our whole house has been destroyed in the flames, we know that fire can cause a huge disaster.
<G-vec00196-002-s040><cause.anrichten><de> 2011 In der Geschichte unserer Familie und unseres Hauses ist die Zerstörung die ein Brand anrichten kann noch immer allgegenwärtig.
<G-vec00196-002-s041><cause.anrichten><en> The broad range of opportunities is of some concern, however, since few concrete guidelines exist for any of these activities, and improper behaviour by visitors could cause great harm to the sensitive ecosystem in the Antarctic.
<G-vec00196-002-s041><cause.anrichten><de> Die breite Palette an Möglichkeiten ist jedoch auch mit Bedenken verbunden, da es für die wenigsten der angebotenen Aktivitäten konkrete Richtlinien gibt und Besucherinnen und Besucher durch falsches Verhalten großen Schaden im empfindlichen Ökosystem der Antarktis anrichten können.
<G-vec00196-002-s042><cause.anrichten><en> Although the TILO has not been officially designed as an attachment, since it meets the military standard IP68 and can withstand shocks up to 800G, the recoil of a standard hunting weapon will not cause any damage.
<G-vec00196-002-s042><cause.anrichten><de> Zwar ist die TILO nicht offiziell als Vorsatzgerät entworfen worden, da sie jedoch die Militärnorm IP68 erfüllt und Stöße bis 800G aushalten kann, wird der Rückstoß einer Standardjagdwaffe keinerlei Schaden anrichten.
<G-vec00196-002-s043><cause.anrichten><en> They are not software programs that could penetrate into the operating system of the user and cause damage here.
<G-vec00196-002-s043><cause.anrichten><de> Es handelt sich dabei nicht um Programme, die in das System des Benutzers eindringen und dort Schaden anrichten können.
<G-vec00196-002-s044><cause.anrichten><en> Cookies cannot cause any damage to the devices used.
<G-vec00196-002-s044><cause.anrichten><de> Cookies können keine Schäden auf den verwendeten Geräten anrichten.
<G-vec00196-002-s045><cause.anrichten><en> Even short blackouts may cause serious financial losses.
<G-vec00196-002-s045><cause.anrichten><de> Auch kurze Blackouts können gravierende wirtschaftliche Schäden anrichten.
<G-vec00196-002-s046><cause.anrichten><en> "Imagine... the chaos we'll cause, once we're in behind their lines!"
<G-vec00196-002-s046><cause.anrichten><de> Der General ist sich sicher, dass sie ein unglaubliches Chaos hinter ihren Linien anrichten wird.
<G-vec00196-002-s047><cause.anrichten><en> They could stand for the damage hurtful remarks cause, for something which is broken (possibly beyond repair), or for injury.
<G-vec00196-002-s047><cause.anrichten><de> Sie können für den Schaden stehen, den Kränkungen anrichten, oder für etwas, das kaputt ist, für Verletzungen.
<G-vec00196-002-s048><cause.anrichten><en> Some substances, after being ingested, can cause a lot of damage if vomited back up.
<G-vec00196-002-s048><cause.anrichten><de> Manche Substanzen können nach ihrer Einnahme sehr viel Schaden anrichten, wenn sie erbrochen werden.
<G-vec00196-002-s049><cause.anrichten><en> That one man could cause so much damage is astounding, but tragically true.
<G-vec00196-002-s049><cause.anrichten><de> Dass ein Mann so viel Schaden anrichten kann ist erstaunlich, aber leider wahr.
<G-vec00196-002-s050><cause.anrichten><en> But I have also known about My first externalized spirit’s antagonism for an eternity, I’ve known about his opposition and the confusion he would cause amongst My earliest spirits....
<G-vec00196-002-s050><cause.anrichten><de> Doch Ich wußte auch seit Ewigkeiten um die Gegnerschaft Meines ersten aus Mir herausgestellten Geistes, Ich wußte um seinen Widerstand und um die Verwirrung, die er anrichten würde unter Meinen Urgeistern....
<G-vec00196-002-s051><cause.anrichten><en> All areas where the cockroach slipper would cause more damage than results.
<G-vec00196-002-s051><cause.anrichten><de> Alles Bereiche, wo der Kakerlakenschlappen eher Schaden anrichten würde.
<G-vec00196-002-s052><cause.anrichten><en> Before the water can cause any damage, a warning is sounded.
<G-vec00196-002-s052><cause.anrichten><de> Bevor das Wasser Schaden anrichten kann, ertönt ein Warnton.
<G-vec00196-002-s053><cause.anrichten><en> 17 I urge you, brothers and sisters, to watch out for those who cause divisions and put obstacles in your way that are contrary to the teaching you have learned.
<G-vec00196-002-s053><cause.anrichten><de> 17 Ich ermahne euch aber, liebe Brüder, daß ihr achtet auf die, die da Zertrennung und Ärgernis anrichten neben der Lehre, die ihr gelernt habt, und weichet von ihnen.
<G-vec00196-002-s054><cause.anrichten><en> That way, minor flaws and any wear to the screw can be repaired before they can cause damage.
<G-vec00196-002-s054><cause.anrichten><de> So lassen sich auch kleinere Fehler und Verschleiß an der Spannschraube rechtzeitig erkennen, bevor sie Schaden anrichten können.
<G-vec00196-002-s055><cause.anrichten><en> The starters' ingenious design with extensive air passages ensures that foreign bodies are hardly able to cause any damage.
<G-vec00196-002-s055><cause.anrichten><de> Die durchdachte Bauweise der Anlasser mit ausgeprägten Luftdurchgängen gewährleistet, dass Fremdkörper kaum Schäden anrichten können.
<G-vec00196-002-s056><cause.anrichten><en> His policy follows a logic of escalation, it is impulsive and defies evidence and facts, and it is ignorant of the lasting damage it may cause.
<G-vec00196-002-s056><cause.anrichten><de> Seine Politik folgt einer Logik der Eskalation, sie ist impulsiv und setzt sich über Belege und Fakten hinweg, und sie ist sich des bleibenden Schadens, den sie anrichten könnte, nicht bewusst.
<G-vec00196-002-s057><cause.auslösen><en> Due to their small sizes, the particles penetrate deeply into the bloodstream and can cause serious diseases.
<G-vec00196-002-s057><cause.auslösen><de> Aufgrund der kleinen Größe dringen die Partikel bis in die Blutbahnen vor und können schwerheilbare Krankheiten auslösen.
<G-vec00196-002-s058><cause.auslösen><en> In the run-up to this debate, we should recall that France is a country where women are not blamed for the desire they cause; a country where individuals live and not “communities”; a country where, out of reference to dissenters and for the purpose of preserving inner peace, one does not carry one’s faith as a banner in front of oneself.
<G-vec00196-002-s058><cause.auslösen><de> Im Vorfeld dieser Auseinandersetzung sollten wir daran erinnern, dass Frankreich ein Land ist, wo die Frauen nicht schuldig gesprochen werden für das Begehren, das sie auslösen; ein Land, in dem Individuen leben und nicht «Gemeinschaften»; ein Land, wo man, aus Respekt vor Andersdenkenden und um den inneren Frieden aufrechtzuerhalten, seinen Glauben nicht wie ein Banner vor sich her trägt.
<G-vec00196-002-s059><cause.auslösen><en> Storm winds over 75km/h: Can cause damage to objects standing outdoors.
<G-vec00196-002-s059><cause.auslösen><de> Sturmwind über 75km/h: Kann Schäden an stehenden Objekten im Freien auslösen.
<G-vec00196-002-s060><cause.auslösen><en> Psychological stress: Scientists suspect that stress can cause cancer.
<G-vec00196-002-s060><cause.auslösen><de> Psychischer Stress: Wissenschaftler vermuten, das Stress Krebs auslösen kann.
<G-vec00196-002-s061><cause.auslösen><en> The following table describes when data validation failures cause a record or a field to be skipped.
<G-vec00196-002-s061><cause.auslösen><de> Die folgende Tabelle beschreibt, wann Datenüberprüfungsfehler das Überspringen eines Datensatzes oder eines Felds auslösen.
<G-vec00196-002-s062><cause.auslösen><en> By immobilizing the wrist, movements of the hand will be avoided, which cause the numb feeling (mainly at night).
<G-vec00196-002-s062><cause.auslösen><de> Durch Fixierung des Handgelenks werden Stellungen vermieden, welche das Taubheitsgefühl (hauptsächlich nachts) auslösen.
<G-vec00196-002-s063><cause.auslösen><en> We could also cause real excitement by video and movie producers, especially those who offer their videos in several languages.
<G-vec00196-002-s063><cause.auslösen><de> Wahre Freude konnten wir wie immer auch bei Video- und Filmproduzenten auslösen, vor allem bei denjenigen, die ihre Videos in mehreren Sprachen anbieten.
<G-vec00196-002-s064><cause.auslösen><en> Opioids are often used to relieve pain but can cause side effects, such as constipation, that also require treatment.
<G-vec00196-002-s064><cause.auslösen><de> Zur Schmerzlinderung werden oft Opioide eingesetzt, die jedoch Nebenwirkungen wie Verstopfung auslösen können, die ebenfalls einer Behandlung bedürfen.
<G-vec00196-002-s065><cause.auslösen><en> And this happens, despite the fact that it can even cause life-threatening reactions in those cases where there is a particular sensitivity towards other foreign substances.
<G-vec00196-002-s065><cause.auslösen><de> Und das, obwohl es im Falle besonderer Sensibilität anderen Fremdstoffen gegenüber sogar lebensbedrohliche Reaktionen auslösen kann.
<G-vec00196-002-s066><cause.auslösen><en> Nickel can cause allergies and skin irritation.
<G-vec00196-002-s066><cause.auslösen><de> Nickel kann Allergien und Hautirritationen auslösen.
<G-vec00196-002-s067><cause.auslösen><en> We can help to identify process weaknesses and prioritize them so you focus on the parameters most likely to cause problems.
<G-vec00196-002-s067><cause.auslösen><de> Wir können dabei helfen, Prozessschwächen zu identifizieren und zu priorisieren, damit Sie sich denjenigen Faktoren widmen können, welche die Problematiken auslösen.
<G-vec00196-002-s068><cause.auslösen><en> Some pathogenic species are zoonosis pathogens, ie bacteria which are transmitted from animals to humans and can cause serious diseases.
<G-vec00196-002-s068><cause.auslösen><de> Es gibt eine Vielzahl krankmachende wie auch nicht krankmachende Bakterien, die vom Tier auf den Menschen übertragen werden und schwere Krankheiten auslösen können.
<G-vec00196-002-s069><cause.auslösen><en> Getting short curly hairstyles doesn’t have to cause hassle, just make sure you’ve got the right tools to hand.
<G-vec00196-002-s069><cause.auslösen><de> Kurze, gelockte Frisuren zu kreieren muss keinen Druck auslösen, stelle einfach sicher, dass Du die richtigen Tools zur Hand hast.
<G-vec00196-002-s070><cause.auslösen><en> Epidemiological studies show that campylobacter and salmonella bacteria can cause diseases following consumption of contaminated animal-based foods.
<G-vec00196-002-s070><cause.auslösen><de> Epidemiologische Untersuchungen zeigen, dass Campylobacter- und Salmonella-Bakterien durch den Verzehr kontaminierter tierischer Nahrungsmittel Erkrankungen auslösen können.
<G-vec00196-002-s071><cause.auslösen><en> Steroids that are very Androgenic such as Dianabol or Testosterone cause more adverse effects.
<G-vec00196-002-s071><cause.auslösen><de> Steroide, die sehr Androgene wie Dianabol oder Testosteron sind auslösen mehr unerwünschte Wirkungen.
<G-vec00196-002-s072><cause.auslösen><en> To determine whether it might cause an epidemic or even a pandemic, the researchers try to find out if it can be passed from one person to another.
<G-vec00196-002-s072><cause.auslösen><de> Um abzuschätzen, ob sie eine Epidemie oder sogar Pandemie auslösen könnten, versuchen die Wissenschaftler herauszufinden, ob sie von einer Person zu einer anderen übertragen werden können.
<G-vec00196-002-s073><cause.auslösen><en> The possibility is real for economic collapse, unprecedented military conflict, internal political chaos, or martial law—any one of which could cause global disruption if positioned appropriately.
<G-vec00196-002-s073><cause.auslösen><de> Die Möglichkeiten für einen wirklichen Zusammenbruch der Ökonomie, für einen unvorhergesehenen militärischen Konflikt, innenpolitisches Chaos oder Kriegsrecht sind real; jedes von dem könnte einen globalen Zusammenbruch auslösen, wenn es in geeigneter Weise positioniert würde.
<G-vec00196-002-s074><cause.auslösen><en> Although mites themselves are not dangerous or transmit diseases, their excretions can cause allergic reactions.
<G-vec00196-002-s074><cause.auslösen><de> Milben selbst sind zwar weder gefährlich noch übertragen sie Krankheiten, wohl aber können ihre Ausscheidungen allergische Reaktionen auslösen.
<G-vec00196-002-s075><cause.auslösen><en> As an engineer, May was most noted for having identified the cause of the "alpha particle problem", which was affecting the reliability of integrated circuits as device features reached a critical size where a single alpha particle could change the state of a stored value and cause a single event upset.
<G-vec00196-002-s075><cause.auslösen><de> Als Ingenieur wurde May vor allem dafür bekannt, dass er die Ursache des „Alpha-Partikel-Problems“ identifiziert hatte, das die Zuverlässigkeit integrierter Schaltungen beeinträchtigte, da die Gerätemerkmale eine kritische Größe erreichten, bei der ein einzelnes Alphateilchen den Zustand eines gespeicherten Wertes ändern und ein Single Event Upset auslösen konnte.
<G-vec00196-002-s095><cause.bewirken><en> This ritual has filled the symbol with powerful energies and it will therefore cause special changes in your life.
<G-vec00196-002-s095><cause.bewirken><de> Dieser Zauber hat das Zeichen mit machtvoller Energie gefüllt und es wird daher gewisse Veränderungen in Deinem Leben bewirken.
<G-vec00196-002-s096><cause.bewirken><en> In addition, reactions of flavours with the air that can cause change the flavour.
<G-vec00196-002-s096><cause.bewirken><de> Hinzu kommen Reaktionen der Geschmacksstoffe mit der Luft, die Veränderungen des Aromas bewirken können.
<G-vec00196-002-s097><cause.bewirken><en> The globalisation and consequently the internationalisation of risk management and accounting, severe demographic changes, the developments in the international financial markets, new financial instruments and technological innovations – these are only a few aspects that cause far-reaching changes to actuarial science.
<G-vec00196-002-s097><cause.bewirken><de> Die Globalisierung und die damit einhergehende Internationalisierung von Risikomanagement und Rechnungslegung, gravierende demographische Veränderungen, die Entwicklungen an den internationalen Finanzmärkten, neuartige Finanzinstrumente und technologische Innovationen sind nur einige Aspekte, die sehr weitreichende Veränderungen in der Versicherungswirtschaft bewirken.
<G-vec00196-002-s098><cause.bewirken><en> Although they seem bulky and large, these boxes are an effective solution to "room droning" as they cause, in my perception, more throughout the room through their "counter vibration" than thick foam/mineral wool absorbers in which the deep Frequencies simply "swallowed" on the walls.
<G-vec00196-002-s098><cause.bewirken><de> Auch wenn sie klobig und gross erscheinen, sind diese Kisten bei "Raum-Dröhnen" eine wirkungsvolle Lösung, da sie, meiner Wahrnehmung nach, durch ihre "Gegenschwingung" mehr im gesamten Raum bewirken, als dicke Schaumstoff/Mineralwolle Absorber, in denen die tiefen Frequenzen einfach an den Wänden "verschluckt" werden.
<G-vec00196-002-s099><cause.bewirken><en> We have been sealed by the Holy Spirit and all we have in this life is actually merely the promise, the earnest money so to speak, of the promise God will fulfill the rest of the deal - that the first born from the dead will indeed cause the rest of us to also be born from the dead - the spiritual rebirth the token of that promise.
<G-vec00196-002-s099><cause.bewirken><de> Wir sind mit dem Heiligen Geist versiegelt worden und alles was wir in diesem Leben haben, ist tatsächlich bloß das Versprechen, sozusagen das „Anzahlungsgeld“ der Verheißung, dass Gott den Rest des Abkommens erfüllen wird – dass der Erstgeborene aus den Toten tatsächlich bewirken wird, dass der Rest von uns auch aus den Toten geboren wird.
<G-vec00196-002-s100><cause.bewirken><en> Beside the diffusion movement of these intrinsic defects at elevated temperatures, at low temperatures an electric field may cause their redistribution.
<G-vec00196-002-s100><cause.bewirken><de> Neben der Diffusionsbewegung dieser Eigendefekte bei hohen Temperaturen kann bei niedrigen Temperaturen ein elektrisches Feld deren Umverteilung bewirken.
<G-vec00196-002-s101><cause.bewirken><en> By blocking the effect of angiotensin II, ACE inhibitors cause your blood vessels to relax which lowers your blood pressure.
<G-vec00196-002-s101><cause.bewirken><de> Durch die Blockade der Wirkung von Angiotensin II bewirken ACE-Hemmer eine Entspannung Ihrer Blutgefäße, was wiederum den Blutdruck senkt.
<G-vec00196-002-s102><cause.bewirken><en> Harsh living environments and aging can cause the decrease of HA content in skin, and as a result, the water maintaining ability of the skin is weakened causing the skin to look dry and rough.
<G-vec00196-002-s102><cause.bewirken><de> Ein raues Klima und Alterung können die Abnahme des HA-Gehalts in der Haut bewirken und durch die verminderte Fähigkeit zur Wasserspeicherung, sieht die Haut trocken und rau aus.
<G-vec00196-002-s103><cause.bewirken><en> They cannot prevent the burning of plastics, but they reduce the flammability or cause self-extinguishing.
<G-vec00196-002-s103><cause.bewirken><de> Flammhemmer können das Brennen von Kunststoffen nicht verhindern, setzen aber die Entflammbarkeit herab, erschweren die Verbrennung oder bewirken ein Selbstverlöschen.
<G-vec00196-002-s104><cause.bewirken><en> You should not take Sildenafil Teva if you are taking medicines called nitrates, as the combination of these products may cause a potentially dangerous decrease in your blood pressure.
<G-vec00196-002-s104><cause.bewirken><de> Sie dürfen Sildenafil 1A Pharma nicht einnehmen, wenn Sie Arzneimittel einnehmen, die Nitrate genannt werden, da die Kombination dieser Arzneimittel eine möglicherweise gefährliche Senkung Ihres Blutdrucks bewirken kann.
<G-vec00196-002-s105><cause.bewirken><en> The chestnut and ginger extracts cause a firming support of regenerative processes and also has a vitalising effect and antiseptic.
<G-vec00196-002-s105><cause.bewirken><de> Die Kastanien- und Ingwerextrakte bewirken eine hautstraffende Unterstützung der regenerativen Prozesse und wirken zudem vitalisierend und antiseptisch.
<G-vec00196-002-s106><cause.bewirken><en> The deflection of the actuating means to continuously and thus take place without jumps, so that no pressure surges are applied to the coating material, which can cause outgassing of the coating material.
<G-vec00196-002-s106><cause.bewirken><de> Die Auslenkung des Betätigungsmittels soll kontinuierlich und somit ohne Sprünge erfolgen, damit keine Druckstöße auf das Beschichtungsmaterial ausgeübt werden, die ein Ausgasen des Beschichtungsmaterials bewirken können.
<G-vec00196-002-s107><cause.bewirken><en> This can also cause the top coat layer to dry faster, trapping solvents underneath.
<G-vec00196-002-s107><cause.bewirken><de> Dies kann auch ein schnelleres Trocknen der top coat Lage bewirken, bei dem die darunter befindlichen Lösungsmittel eingeschlossen werden.
<G-vec00196-002-s108><cause.bewirken><en> I don't know, whether this sounds dangerous for you, but such a being with use of wrong feelings and illusions in a court-case could cause that an innocent is locked up for life.
<G-vec00196-002-s108><cause.bewirken><de> Ich weiß nicht, ob das für Euch gefährlich klingt, aber ein solches Wesen könnte in einem Gerichtsfall mit Einsatz von falschen Gefühlen und Illusionen bewirken, daß ein Unschuldiger lebenslänglich eingesperrt wird.
<G-vec00196-002-s109><cause.bewirken><en> The centering exercises cause a noticeable difference in everyday life.
<G-vec00196-002-s109><cause.bewirken><de> Die Zentrierungsübungen im ETB bewirken einen spürbaren Unterschied im Alltag.
<G-vec00196-002-s110><cause.bewirken><en> It is indisputable that the entry of the Y generation into management positions cannot be stopped and will cause a rethinking of management methods, e.g. management styles.
<G-vec00196-002-s110><cause.bewirken><de> Unumstritten ist, dass der Einzug der Generation Y in diese Führungspositionen nicht aufzuhalten ist und ein Umdenken bei Management Methoden, wie zum Beispiel Führungsstilen, bewirken wird.
<G-vec00196-002-s111><cause.bewirken><en> In near vision, prismatic effects in the near reference point of the lens cause a deviation of the centrally imaging principal ray, with the result that the principal ray is not perpendicular to the back surface of the lens.
<G-vec00196-002-s111><cause.bewirken><de> Prismatische Nebenwirkungen im Nahbezugspunkt des Brillenglases bewirken beim Blick in die Nähe eine Ablenkung der zentral abbildenden Hauptstrahlen, so dass der Hauptstrahl nicht senkrecht auf der augenseitigen Glasfläche steht.
<G-vec00196-002-s112><cause.bewirken><en> FORWARD LOOKING STATEMENTS: This press release contains forward-looking statements, including statements regarding the anticipated benefits of the merger, that involve known and unknown risks, uncertainties and other factors that may cause actual results, levels of activity, performance or achievements to differ materially from results expressed or implied by these statements.
<G-vec00196-002-s112><cause.bewirken><de> Diese Pressemitteilung enthält einige auf die Zukunft gerichtete Aussagen sowie Aussagen zu geplanten Aktivitäten und Ergebnissen, die bekannte und unbekannte Risiken, Unwägbarkeiten und andere Faktoren enthalten können, die wesentliche Abweichungen unserer gegenwärtigen Geschäftsergebnisse, Aktivitäten, Wertentwicklung oder Leistungen von den Ergebnissen, die in dieser Pressemitteilung beschrieben oder impliziert sind, bewirken können.
<G-vec00196-002-s113><cause.bewirken><en> Disappointment comes and it might even cause depressions.
<G-vec00196-002-s113><cause.bewirken><de> Enttäuschung entsteht und sie mag gar Depressionen bewirken.
<G-vec00196-002-s114><cause.bringen><en> They also cause the viewer to pause and provide him grounding points for his reflection about the space in which he finds himself.
<G-vec00196-002-s114><cause.bringen><de> Sie bringen den Zuschauer für einen Moment ins Wanken und bieten ihm Ankerpunkte für dessen Reflexion über den Raum, in dem er sich befindet.
<G-vec00196-002-s115><cause.bringen><en> Two denial of service bugs were found in the way Squid handles malformed requests which can cause the server to crash.
<G-vec00196-002-s115><cause.bringen><de> Zwei Denial-of-Service Fehler wurden in der Bearbeitung von bösartigen Request-URLs gefunden, was die Software zum Absturz bringen kann.
<G-vec00196-002-s116><cause.bringen><en> But they can also be dangerous or cause a lot of trouble.
<G-vec00196-002-s116><cause.bringen><de> Aber sie können auch Gefahren mit sich bringen oder eine Menge Ärger verursachen.
<G-vec00196-002-s117><cause.bringen><en> 13`Now, be it known to the king, that if this city be builded, and the walls finished, toll, tribute, and custom they do not give; and at length [to] the kings it doth cause loss.
<G-vec00196-002-s117><cause.bringen><de> 13 So sei nun dem König kundgetan: Wenn diese Stadt wieder aufgebaut wird und die Mauern vollendet werden, so werden sie Steuern, Abgaben und Zoll nicht mehr geben, und zuletzt wird es den Königen Schaden bringen.
<G-vec00196-002-s118><cause.bringen><en> As, for better or worse, logistics always depends on effective communication, persistent disruption thereof was enough to cause the downfall of the insurgent high-rise project.
<G-vec00196-002-s118><cause.bringen><de> Weil jede Logistik auf Gedeih und Verderb von funktionierender Kommunikation abhängt, reichte eine nachhaltige Störung derselben, um das aufständische Wolkenkratzerprojekt zu Fall zu bringen.
<G-vec00196-002-s119><cause.bringen><en> 31:7 Moses called to Joshua, and said to him in the sight of all Israel, "Be strong and courageous: for you shall go with this people into the land which Yahweh has sworn to their fathers to give them; and you shall cause them to inherit it.
<G-vec00196-002-s119><cause.bringen><de> 31:7 Und Mose rief Josua und sprach zu ihm vor den Augen des ganzen Israel: Sei getrost und unverzagt; denn du wirst dies Volk ins Land bringen, das der HERR ihren Vätern geschworen hat, ihnen zu geben, und du wirst es unter sie austeilen.
<G-vec00196-002-s120><cause.bringen><en> But, two years later, it was discovered that some of the IPCC report’s key claims – for example, that global warming would cause the immense Himalayan glaciers to disappear by 2035, or halve African crop yields by 2020 – were based on statements made in appeals by environmentalist organizations, and were backed by little or no evidence.
<G-vec00196-002-s120><cause.bringen><de> Doch zwei Jahre später kam heraus, dass einige der zentralen Behauptungen des IPCC – etwa, dass die globale Erwärmung die riesigen Gletscher des Himalaya bis 2035 zum Verschwinden bringen oder die afrikanischen Ernteerträge bis 2020 halbieren würde – auf Äußerungen in Spendenappellen von Umweltorganisationen beruhten und dass es dafür kaum oder gar keine Belege gab.
<G-vec00196-002-s121><cause.bringen><en> We hope that in the end the actual legal reform doesn’t in fact cause the serious knock that is planned at present.
<G-vec00196-002-s121><cause.bringen><de> Wir hoffen, dass die tatsächliche Neuregelung des Gesetzes letztendlich doch nicht die drastischen Einschnitte mit sich bringen wird, die derzeit geplant sind.
<G-vec00196-002-s122><cause.bringen><en> That change is beautiful and yet, it will cause challenges for humans.
<G-vec00196-002-s122><cause.bringen><de> Diese Veränderung ist wunderschön, doch wird sie für die Menschen Herausforderungen bringen.
<G-vec00196-002-s123><cause.bringen><en> In the end, a clash of religious interests will cause more death and destruction on earth than all the other conflicts put together.
<G-vec00196-002-s123><cause.bringen><de> Am Ende wird die religiöse Konfrontation mehr Tote und Zerstörung auf Erden bringen als jede andere Konfrontation.
<G-vec00196-002-s124><cause.bringen><en> A selenium deficiency can cause various health risks.
<G-vec00196-002-s124><cause.bringen><de> Wenn Sie nämlich einen Mangel haben, kann das verschiedene Gesundheitsrisiken mit sich bringen.
<G-vec00196-002-s125><cause.bringen><en> That's why it's important for you to learn the symptoms and complications that this illness can cause.
<G-vec00196-002-s125><cause.bringen><de> Es ist für Sie wichtig, die Symptome und Folgen die diese Krankheit mit sich bringen kann, zu kennen.
<G-vec00196-002-s126><cause.bringen><en> In most cases, however, this regulation should not cause any considerable issues.
<G-vec00196-002-s126><cause.bringen><de> In den meisten Fällen sollte diese Regelung aber keine großen Probleme mit sich bringen.
<G-vec00196-002-s127><cause.bringen><en> Because a shamanic journey shall also cause a result in normal reality, it is important to attend to a specific question or topic during the journey.
<G-vec00196-002-s127><cause.bringen><de> Da eine schamanische Reise auch in der alltäglichen Wirklichkeit ein Resultat bringen soll, ist es wesentlich, auch eine Fragestellung oder ein Thema auf der Reise zu bearbeiten.
<G-vec00196-002-s128><cause.bringen><en> Thus says the Lord God to these bones, Behold, I will cause breath to enter you, and you shall live.
<G-vec00196-002-s128><cause.bringen><de> So spricht der HERR HERR von diesen Gebeinen: Siehe, ich will einen Odem in euch bringen, daß ihr sollt lebendig werden.
<G-vec00196-002-s129><cause.bringen><en> Apart from the material problems that nominating a second cardinal voter would cause in a diocese, there is always this concern in the Church to ensure that it is clear that the cardinals belong to the whole Church and are not just representatives of the local church from which they come.
<G-vec00196-002-s129><cause.bringen><de> Abgesehen von den Problemen, die die Ernennung eines zweiten wahlberechtigten Kardinals in einer Diözese mit sich bringen würde, hat die Kirche stets Sorge dafür zu tragen, dass die Kardinäle als Repräsentanten der Gesamtkirche und nicht nur als Vertreter ihrer jeweiligen Teilkirchen in Erscheinung treten.
<G-vec00196-002-s130><cause.bringen><en> The way of death is this:... they show no compassion for the poor, they do not suffer with the suffering, they do not acknowledge their Creator, they kill their children and by abortion cause God's creatures to perish; they drive away the needy, oppress the suffering, they are advocates of the rich and unjust judges of the poor; they are filled with every sin.
<G-vec00196-002-s130><cause.bringen><de> Der Weg des Todes ist folgender:... sie haben kein Mitleid mit dem Armen, sie leiden nicht mit dem Leidenden, sie anerkennen nicht ihren Schöpfer, sie töten ihre Kinder und bringen durch Abtreibung Geschöpfe Gottes um; sie schicken den Bedürftigen fort, unterdrücken den Geplagten, sind Anwälte der Reichen und ungerechte Richter der Armen; sie sind voller Sünde.
<G-vec00196-002-s131><cause.bringen><en> 35 They built the high places of Baal in the Valley of the Son of Hinnom, to offer up their sons and daughters to Molech, though I did not command them, nor did it enter into my mind, that they should do this abomination, to cause Judah to sin.
<G-vec00196-002-s131><cause.bringen><de> 35 und haben die Höhen des Baal gebaut im Tal Ben-Hinnom, um ihre Söhne und Töchter für den Moloch durchs Feuer gehen zu lassen, was ich ihnen nie geboten habe und mir nie in den Sinn gekommen ist, dass sie solchen Gräuel tun sollten, um Juda in Sünde zu bringen.
<G-vec00196-002-s132><cause.bringen><en> Additionally, calibration extends the life of your product, helping you avoid downtime by repairing or replacing components that might cause the tester to fail.
<G-vec00196-002-s132><cause.bringen><de> Darüber hinaus verlängert die Kalibrierung die Lebensdauer Ihres Produkts und hilft Ihnen, Ausfallzeiten zu vermeiden, indem Sie Komponenten reparieren oder ersetzen, die den Tester zum Versagen bringen könnten.
<G-vec00196-002-s152><cause.führen><en> Forward-looking statements are subject to a number of risks and uncertainties that may cause the actual results of the Company to differ materially from those discussed in the forward-looking statements, and even if such actual results are realized or substantially realized, there can be no assurance that they will have the expected consequences to, or effects on the Company.
<G-vec00196-002-s152><cause.führen><de> Obwohl zukunftsgerichtete Aussagen auf Daten, Annahmen und Analysen beruhen, die das Unternehmen unter den gegebenen Umständen für angemessen hält, hängt es von einer Reihe von Risiken und Unsicherheiten ab, ob die tatsächlichen Ergebnisse, Leistungen oder Entwicklungen den Erwartungen und Prognosen des Unternehmens entsprechen werden, die dazu führen können, dass die tatsächlichen Ergebnisse, Leistungen und finanziellen Bedingungen des Unternehmens wesentlich von seinen Erwartungen abweichen.
<G-vec00196-002-s153><cause.führen><en> Novelties: Fixed an issue that could cause player characters to hold the Marriner's Horn incorrectly.
<G-vec00196-002-s153><cause.führen><de> Extras: Ein Fehler wurde behoben, der dazu führen konnte, dass Spielercharaktere das Horn Marriners falsch hielten.
<G-vec00196-002-s154><cause.führen><en> Although First Star Resources has attempted to identify important factors that could cause actual actions, events or results to differ materially from those described in forward-looking statements, there may be other factors that cause actions, events or results not to be as anticipated, estimated or intended.
<G-vec00196-002-s154><cause.führen><de> Obwohl First Star Resources versuchte, die wichtigen Faktoren zu identifizieren, die dazu führen könnten, dass sich die tatsächlichen Ereignisse oder Ergebnisse erheblich von jenen in vorausblickenden Aussagen zum Ausdruck gebrachten unterscheiden, kann es noch immer Faktoren geben, die dazu führen könnten, dass die Ereignisse oder Ergebnisse nicht wie angenommen, geschätzt oder beabsichtigt eintreten.
<G-vec00196-002-s155><cause.führen><en> Forward-looking statements are subject to a number of risks and uncertainties that may cause the actual results of the Company to differ materially from those discussed in the forward-looking statements, and even if such actual results are realized or substantially realized, there can be no assurance that they will have the expected consequences to, or effects on the Company.
<G-vec00196-002-s155><cause.führen><de> Zukunftsgerichtete Aussagen unterliegen einer Vielzahl von Risiken und Unsicherheiten, die größtenteils nicht von der Gesellschaft kontrolliert oder vorhergesehen werden können und die dazu führen könnten, dass sich die tatsächlichen Ergebnisse der Gesellschaft erheblich von denen unterscheiden, die in diesen zukunftsgerichteten Aussagen enthalten sind.
<G-vec00196-002-s156><cause.führen><en> Duplicates, thus texts, that occur on other websites, in identical wording, can cause that the efforts backfire: the website is punished and is no more discoverable in searching machines.
<G-vec00196-002-s156><cause.führen><de> Duplikate, also Texte, die auf anderen Websites in identischem Wortlaut vorkommen, können dazu führen, dass die Anstrengungen nach hinten losgehen: die Website wird abgestraft und ist in Suchmaschinen nicht mehr auffindbar.
<G-vec00196-002-s157><cause.führen><en> Should prevent the installation of cookies or restrict this can cause however, that not all the features of our website are fully usable.
<G-vec00196-002-s157><cause.führen><de> Sollten Sie die Installation der Cookies verhindern oder einschränken, kann dies allerdings dazu führen, dass nicht sämtliche Funktionen unseres Internetauftritts vollumfänglich nutzbar sind.
<G-vec00196-002-s158><cause.führen><en> While OMA's management believes that the expectations reflected in such forward-looking statements are reasonable, investors are cautioned that forward-looking information and statements are subject to various risks and uncertainties, many of which are difficult to predict and are generally beyond the control of OMA, that could cause actual results and developments to differ materially from those expressed in, or implied or projected by, the forward-looking information and statements.
<G-vec00196-002-s158><cause.führen><de> Obwohl die Geschäftsleitung von Sanofi glaubt, dass die Erwartungen, die sich in solchen zukunftsgerichteten Aussagen widerspiegeln, vernünftig sind, sollten Investoren gewarnt sein, dass zukunftsgerichtete Informationen und Aussagen einer Vielzahl von Risiken und Unsicherheiten unterworfen sind, von denen viele schwierig vorauszusagen sind und grundsätzlich außerhalb des Einflussbereiches von Sanofi liegen und dazu führen können, dass die tatsächlich erzielten Ergebnisse und Entwicklungen erheblich von denen abweichen, die in den zukunftsgerichteten Information und Aussagen ausdrücklich oder indirekt enthalten sind oder in diesen prognostiziert werden.
<G-vec00196-002-s159><cause.führen><en> Although management of the Company has attempted to identify important factors that could cause actual results to differ materially from those contained in forward-looking statements or forward-looking information, there may be other factors that cause results not to be as anticipated, estimated or intended.
<G-vec00196-002-s159><cause.führen><de> Obwohl das Management des Unternehmens versuchte, die wichtigsten Faktoren zu identifizieren, die dazu führen könnten, dass sich die tatsächlichen Ergebnisse erheblich von jenen in vorausblickenden Aussagen zum Ausdruck gebrachten unterscheiden, kann es noch immer Faktoren geben, die dazu führen könnten, dass die Ergebnisse nicht wie angenommen, geschätzt oder beabsichtigt eintreten.
<G-vec00196-002-s160><cause.führen><en> Forward-looking statements involve the use of certain assumptions that may not materialize or that may not be accurate and are subject to known and unknown risks and uncertainties and other factors, which may cause actual results or events to differ materially from those expressed or implied by such information.
<G-vec00196-002-s160><cause.führen><de> Solche zukunftsgerichteten Aussagen unterliegen bekannten und unbekannten Risiken, Unsicherheiten und sonstigen Faktoren, die dazu führen können, dass unsere tatsächlichen Ereignisse, Ergebnisse, Leistungen oder Erfolge erheblich von den zukünftigen Ereignissen, Ergebnissen, Leistungen oder Erfolgen abweichen, die in solchen zukunftsgerichteten Aussagen direkt oder indirekt genannt wurden.
<G-vec00196-002-s161><cause.führen><en> It can also help you with files that actually contains some photos that cause you to experience a slow process of uploading, downloading, or sending out your PDF files.
<G-vec00196-002-s161><cause.führen><de> Es kann auch bei Dateien helfen, die tatsächlich einige Fotos enthalten, die dazu führen, dass Ihre PDF-Dateien nur langsam hochgeladen, heruntergeladen oder versendet werden.
<G-vec00196-002-s162><cause.führen><en> Although Mineworx has attempted to identify important factors that could cause actual results to differ materially from those contained in forward-looking statements, there may be other factors that cause results not to be as anticipated, estimated or intended.
<G-vec00196-002-s162><cause.führen><de> Zukunftsgerichtete Aussagen beinhalten Risiken, Unsicherheiten und andere Faktoren, die dazu führen können, dass die tatsächlichen Ergebnisse, Leistungen und Chancen wesentlich von denen abweichen, die in solchen zukunftsgerichteten Aussagen impliziert sind.
<G-vec00196-002-s163><cause.führen><en> Although the Company has attempted to identify important factors that could cause actual actions, events or results to differ materially from those described in forward-looking statements, there may be other factors that cause actions, events or results to differ from those anticipated, estimated or intended.
<G-vec00196-002-s163><cause.führen><de> Obwohl das Unternehmen versuchte, die wichtigen Faktoren zu identifizieren, die dazu führen könnten, dass sich die tatsächlichen Ereignisse oder Ergebnisse erheblich von jenen unterscheiden, die in zukunftsgerichteten Aussagen zum Ausdruck gebrachten wurden, kann es noch immer Faktoren geben, die dazu führen könnten, dass die Ereignisse oder Ergebnisse nicht wie angenommen, geschätzt oder beabsichtigt eintreten.
<G-vec00196-002-s164><cause.führen><en> Forward-looking information and statements are subject to a variety of known and unknown risks, uncertainties and other factors that could cause actual events or results to differ from those reflected in the forward-looking information or statements.
<G-vec00196-002-s164><cause.führen><de> Zukunftsgerichtete Informationen unterliegen einer Reihe von Risiken und Ungewissheiten sowie anderen Faktoren, die dazu führen könnten, dass sich die Pläne, Schätzungen und tatsächlichen Ergebnisse erheblich von jenen in den zukunftsgerichteten Informationen unterscheiden.
<G-vec00196-002-s165><cause.führen><en> Forward-looking statements are subject to known and unknown risks, uncertainties and other factors that could cause TLG IMMOBILIEN AG's revenues, profitability or the degree to which it performs or achieves its targets, to materially deviate from what is explicitly or implicitly stated or described in this publication.
<G-vec00196-002-s165><cause.führen><de> Zu-kunftsgerichtete Aussagen unterliegen bekannten und unbekannten Risiken, Unsicherheiten und anderen Faktoren, die dazu führen können, dass Umsatz, Profitabilität, Zielerreichung und Ergebnisse der WCM AG wesentlich von den ausdrücklich oder implizit in dieser Veröffentlichung genannten oder beschriebenen abweichen werden.
<G-vec00196-002-s166><cause.führen><en> Factors that could cause actual results to differ materially from those in forward-looking statements include such matters as market prices, exploitation and exploration results, continued availability of capital and financing, and general economic, market or business conditions.
<G-vec00196-002-s166><cause.führen><de> Viele bekannte und unbekannte Faktoren könnten dazu führen, dass die tatsächlichen Ergebnisse, Leistungen oder Erfolge wesentlich von den Ergebnissen, Leistungen oder Erfolgen abweichen, die in solchen zukunftsgerichteten Aussagen direkt oder indirekt genannt werden.
<G-vec00196-002-s167><cause.führen><en> By their nature, forward-looking statements require Bombardier’s management to make assumptions and are subject to important known and unknown risks and uncertainties, which may cause Bombardier’s and CSALP’s actual results in future periods to differ materially from forecast results set forth in forward-looking statements.
<G-vec00196-002-s167><cause.führen><de> Es liegt in der Natur von zukunftsgerichteten Aussagen, dass die Unternehmensleitung bestimmte Annahmen trifft und dass diese Aussagen beträchtlichen bekannten und unbekannten Risiken und Unwägbarkeiten unterliegen, die dazu führen können, dass unsere tatsächlichen Ergebnisse in künftigen Zeiträumen erheblich von den in zukunftsgerichteten Aussagen formulierten Voraussagen abweichen können.
<G-vec00196-002-s168><cause.führen><en> These forward-looking statements involve risks and uncertainties that could cause Agilent's results to differ materially from management's current expectations.
<G-vec00196-002-s168><cause.führen><de> Diese zukunftsgerichteten Aussagen umfassen Risiken und Ungewissheiten, die dazu führen könnten, dass die Ergebnisse von Agilent maßgeblich von den gegenwärtigen Erwartungen der Geschäftsführung abweichen.
<G-vec00196-002-s169><cause.führen><en> Such forward-looking statements are subject to a number of risks, assumptions and uncertainties that could cause Diligent’s actual results to differ materially from those projected in such forward-looking statements.
<G-vec00196-002-s169><cause.führen><de> Solche in die Zukunft gerichteten Aussagen unterliegen einer Reihe von Risiken, Annahmen und Ungewissheiten, die dazu führen können, dass sich die tatsächlichen Ergebnisse von Diligent Board Member Services, Inc. von denen, die in solchen in die Zukunft gerichteten Aussagen getroffen wurden, wesentlich unterscheiden.
<G-vec00196-002-s170><cause.führen><en> 20 defect report: A document reporting on any flaw in a component or system that can cause the component or system to fail to perform its required function.
<G-vec00196-002-s170><cause.führen><de> Ein Dokument, das über einen Fehlerzustand einer Komponente oder eines Systems berichtet, der dazu führen kann, dass System oder Komponente die geforderte Funktion nicht erbringt [nach IEEE 829].
<G-vec00196-002-s266><cause.führen><en> SHIPMENTS THAT MAY CAUSE DAMAGE TO, OR DELAY OF, EQUIPMENT, PERSONNEL OR OTHER SHIPMENTS.
<G-vec00196-002-s266><cause.führen><de> Sendungen, die zu Schäden an oder Verspätungen von Ausrüstung, Mitarbeitern oder anderen Sendungen führen können.
<G-vec00196-002-s267><cause.führen><en> The parasites are transmitted by sand flies and cause Leishmaniasis, a disease which above all occurs in tropical regions, the Mediterranean and Asia.
<G-vec00196-002-s267><cause.führen><de> Die Parasiten werden durch Sandmücken übertragen und führen zur Leishmaniose, einer Erkrankung, die vor allem in den Tropen, im Mittelmeerraum und Asien vorkommt.
<G-vec00196-002-s268><cause.führen><en> Its mode of action means that it is especially valuable where intensive use of glyphosate has caused, or threatens to cause, the development of glyphosate resistant weeds.
<G-vec00196-002-s268><cause.führen><de> Durch seine Wirkungsweise ist es vor allem dort wertvoll, wo der intensive Einsatz von Glyphosat zur Entwicklung Glyphosat-resistenter Unkräuter geführt hat oder führen kann.
<G-vec00196-002-s269><cause.führen><en> The radionuclides implant themselves in the cells of the joint mucosa, where they cause sclerosing of the synovia, reducing the size of the proliferating joint mucosa and reducing the inflammation.
<G-vec00196-002-s269><cause.führen><de> Die Radionuklide setzen sich in den Zellen der Gelenkschleimhaut fest und führen dort zu einer Verödung der Synovia, wodurch die wuchernde Gelenkschleimhaut verkleinert und die Entzündung verringert wird.
<G-vec00196-002-s270><cause.führen><en> Some products include harmful components that can cause significant negative effects or ailments.
<G-vec00196-002-s270><cause.führen><de> Einige Lösungen enthalten gefährliche Formel, die in erheblichen negativen Auswirkungen oder Krankheiten führen könnten.
<G-vec00196-002-s271><cause.führen><en> Salt can cause irritation to the dog’s skin, and sand can get in their eyes as they’re trying to get rid of it from their faces, which can cause eye infections and lots of discomfort.
<G-vec00196-002-s271><cause.führen><de> Salz kann die Haut des Hundes reizen und Sand kann in die Augen gelangen, wenn sie versuchen, es vom Gesicht zu entfernen, was zu Augenentzündungen und vielen Beschwerden führen kann.
<G-vec00196-002-s272><cause.führen><en> Plaque that is not removed from around the gum line can cause inflammation and irritation to the gums around your teeth. Tartar is a mineral buildup that's fairly easy to see, if above the gum line.
<G-vec00196-002-s272><cause.führen><de> Wird Zahnbelag um den Zahnfleischrand nicht entfernt, können Entzündungen und eine Reizung des Zahnfleisches um Ihre Zähne entstehen, die zu Gingivitis (rotes, geschwollenes, blutendes Zahnfleisch) führen können.
<G-vec00196-002-s273><cause.führen><en> However, UV rays or a foreign body in the eye can also cause it to occur.
<G-vec00196-002-s273><cause.führen><de> Aber auch UV-Strahlung oder Fremdkörper im Auge können zu einer Bindehautentzündung führen.
<G-vec00196-002-s274><cause.führen><en> 14 RTM-ATCA-F120-OPT Installation and Use (6806800G29C) Safety Notes Damage to RTM/Backplane or System Components Bent pins or loose components can cause damage to the RTM, the backplane, or other system components.
<G-vec00196-002-s274><cause.führen><de> Beschädigung des RTMs, der Backplane oder von System Komponenten Verbogene Pins oder lose Komponenten können zu einer Beschädigung des RTMs, der Backplane oder von Systemkomponenten führen.
<G-vec00196-002-s275><cause.führen><en> Various major events take place in London, these may cause hop-on hop-off route changes and/or disruptions.
<G-vec00196-002-s275><cause.führen><de> In London finden verschiedene Großveranstaltungen statt, die zu Routenänderungen und / oder Störungen führen können.
<G-vec00196-002-s276><cause.führen><en> And cause them to enter the garden which He has made known to them.
<G-vec00196-002-s276><cause.führen><de> Und sie ins Paradies führen, das Er ihnen zu wissen getan hat.
<G-vec00196-002-s277><cause.führen><en> for article '%1' may cause data inconsistency as the source table is already subscribed to '%2' Search by Google Top Google Results
<G-vec00196-002-s277><cause.führen><de> Warnung: Das Hinzufügen eines aktualisierbaren Abonnements für den '%1'-Artikel kann zu einer Dateninkonsistenz führen, da die Quelltabelle bereits '%2' abonniert.
<G-vec00196-002-s278><cause.führen><en> NSAIDs should not be used during the last 3 months of pregnancy unless specified by a doctor, because they may cause problems in the fetus or complications during delivery.
<G-vec00196-002-s278><cause.führen><de> Letztere sollten nur auf ausdrückliche Anweisung eines Arztes eingenommen werden, da sie vor allem in den letzten 3 Monaten der Schwangerschaft dem Fötus schaden und zu Geburtskomplikationen führen können.
<G-vec00196-002-s279><cause.führen><en> Clamping or tensioning the pane at a single point can cause it to fracture.
<G-vec00196-002-s279><cause.führen><de> Klemmung oder Verspannung der Scheibe an einer Stelle kann zum Bruch führen.
<G-vec00196-002-s280><cause.führen><en> Characteristics Too high screw-tightening torque, corrosion or wear - these and other factors cause thread destruction.
<G-vec00196-002-s280><cause.führen><de> Ein zu großes Schraubenanzugsmoment, Korrosion, aber auch Verschleiß - diese und weitere Gründe können zur Zerstörung von Gewinden führen.
<G-vec00196-002-s281><cause.führen><en> Basically, your vocal cords are rubbing against each other. This can cause harmful nodes.
<G-vec00196-002-s281><cause.führen><de> Die Stimmbänder reiben aneinander, was zu gefährlichen Knoten führen kann.
<G-vec00196-002-s282><cause.führen><en> Q: Some expect AI to cause large scale unemployment.
<G-vec00196-002-s282><cause.führen><de> Manche rechnen damit, dass künstliche Intelligenz zu Massenarbeitslosigkeit führen wird.
<G-vec00196-002-s283><cause.führen><en> Interruptions to your network connection may cause your experience to be impacted, and may cause a loss of connection to Destiny.
<G-vec00196-002-s283><cause.führen><de> Verbindungsstörungen bei deinem Netzwerk können dein Spielerlebnis beeinträchtigen und können zur Verbindungsunterbrechung mit Destiny führen.
<G-vec00196-002-s284><cause.führen><en> Note: Be aware that setting the speaker volume + button to maximum level may cause the speakers' internal protection feature to engage, reducing system output.
<G-vec00196-002-s284><cause.führen><de> Hinweis: Beachten Sie, dass das Einstellen des Plus-Lautstärkereglers (+) auf das maximale Niveau die interne Schutzfunktion der Lautsprecher aktivieren kann, was zur Reduktion der Systemausgabe führen kann.
<G-vec00196-002-s285><cause.führen><en> Extreme temperatures like cold or especially heat (as in a sauna or while taking a hot bath) cause physiological flushing and may trigger rosacea.
<G-vec00196-002-s285><cause.führen><de> Extreme Temperaturen wie Kälte oder insbesondere Hitze (beispielsweise in einer Sauna oder bei einem heißen Bad) führen zu physiologischer Gesichtsröte und können Rosazea anstoßen.
<G-vec00196-002-s286><cause.führen><en> For examplesplinters that are deep in the body move slowly to the surface and cause inflammation.
<G-vec00196-002-s286><cause.führen><de> Zum Beispiel dringen Splitter, die tief im Körper sitzen, langsam an die Oberfläche und führen zu Entzündungen.
<G-vec00196-002-s287><cause.führen><en> This can in theory cause reduced cravings and less food cravings.
<G-vec00196-002-s287><cause.führen><de> Dies kann in der Theorie führen zu reduzierten Heißhunger und weniger Heißhunger.
<G-vec00196-002-s288><cause.führen><en> Fixed asset acquisitions cause movements on accounts of financial accounting.
<G-vec00196-002-s288><cause.führen><de> Anlagenzugänge führen zu Bewegungen auf Konten der Finanzbuchhaltung.
<G-vec00196-002-s289><cause.führen><en> On the contrary, they severely damage nerve cells and cause them to die.
<G-vec00196-002-s289><cause.führen><de> Im Gegenteil: Sie schädigen Nervenzellen massiv und führen zu deren Absterben.
<G-vec00196-002-s290><cause.führen><en> Monster trucks will cause a shift in transport from the environmentally friendly railways to the cheaper roads.
<G-vec00196-002-s290><cause.führen><de> Monstertrucks führen zu einer Verkehrsverlagerung von der umweltfreundlichen Schiene auf die preiswertere Straße.
<G-vec00196-002-s291><cause.führen><en> Failure to comply with these requirements can cause vibrations that affect driving comfort and safety.
<G-vec00196-002-s291><cause.führen><de> Nichteinhaltung dieser Ansprüche führen zu Vibrationen, die den Fahrkomfort und die Sicherheit beeinträchtigen.
<G-vec00196-002-s292><cause.führen><en> The dry ice pellets hitting the component cause a sudden punctual supercooling of the coating or soiling that has to be removed.
<G-vec00196-002-s292><cause.führen><de> Die auf das Bauteil auftreffenden Trockeneispellets führen zu einer schlagartigen punktuellen Unterkühlung der zu entfernenden Beschichtung oder Verunreinigung.
<G-vec00196-002-s293><cause.führen><en> Resource consumption of shopping online The parcels used for internet clothes shopping, which have a weight of approx. half a kilo on average, cause approx.
<G-vec00196-002-s293><cause.führen><de> Die Kartons, die für einen Modeversandhandel im Mittel ein Gewicht von rund einem halben Kilo haben dürften, führen zu Treibhausgasemissionen in Höhe von rund 350 Gramm.
<G-vec00196-002-s294><cause.führen><en> Disturbances in these boilers caused by deposits, scaling, corrosion, localized overheating or over cracks in the steam, impair the safety and cause immense economic damage.
<G-vec00196-002-s294><cause.führen><de> Störungen in diesen Kesselanlagen durch Ablagerungen, Kesselsteinbildung, Korrosion, lokale Überhitzungen oder Überrisse in den Dampf beeinträchtigen die Betriebssicherheit und führen zu immensen wirtschaftlichen Schäden.
<G-vec00196-002-s295><cause.führen><en> Hostile code is not the only threat—many non-malicious software applications also cause problems.
<G-vec00196-002-s295><cause.führen><de> Schädlicher Programmcode ist nicht die einzige Bedrohung - auch viele an sich nicht schädliche Anwendungen führen zu Problemen.
<G-vec00196-002-s296><cause.führen><en> Environmental policies cause an adjustment of economic structures, for example by adapting the property-rights regimes for natural resources to take account of their increased scarcity and new scientific insights.
<G-vec00196-002-s296><cause.führen><de> Umweltpolitische Maßnahmen führen zu einer Anpassung der Wirtschaftsstrukturen, beispielsweise durch Regelungen zum Schutz immer knapperer natürlicher Ressourcen und durch Berücksichtigung neuester wissenschaftlicher Erkenntnisse.
<G-vec00196-002-s297><cause.führen><en> In many cases, these fragments degrade the computer’s performance and cause problems with the application’s operation.
<G-vec00196-002-s297><cause.führen><de> In vielen Fällen verschlechtern diese Fragmente die Leistung des Computers und führen zu Problemen bei der Arbeit mit den Anwendungen.
<G-vec00196-002-s298><cause.führen><en> Failures cause faults in the operating sequence and thus lead to excessive costs.
<G-vec00196-002-s298><cause.führen><de> Ausfälle führen zu Störungen des Betriebsablaufes und damit zu hohen Kosten.
<G-vec00196-002-s299><cause.führen><en> The existing national differences cause distortions of competition within Europe.
<G-vec00196-002-s299><cause.führen><de> Die bisherigen nationalen Unterschiede führen zu Wettbewerbsverzerrungen innerhalb Europas.
<G-vec00196-002-s300><cause.führen><en> Stigma and discrimination, ignorance and fear cause social isolation and prevent people with epilepsy from seeking treatment.
<G-vec00196-002-s300><cause.führen><de> Stigma und Diskriminierung, Unwissenheit und Angst führen zu sozialer Isolation und verhindern, dass sich Menschen mit Epilepsie in Behandlung begeben.
<G-vec00196-002-s301><cause.führen><en> Tension caused by attending competitions cause blockages in the muscles.
<G-vec00196-002-s301><cause.führen><de> Verspannung aufgrund von Turnierteilnahmen führen letztendlich zu Blockaden in der Muskulatur.
<G-vec00196-002-s302><cause.führen><en> Infusions of glucose or fructose in high dose cause an increase in blood lactate levels.
<G-vec00196-002-s302><cause.führen><de> Hochdosierte Infusionen von Glukose oder von Fruktose führen zu einem maßigen Anstieg der Laktatkonzentration im Blut.
<G-vec00196-002-s303><cause.führen><en> Fertilizers that contain a lot of salt cause spots on the leaves.
<G-vec00196-002-s303><cause.führen><de> Stark salzhaltige Dünger führen meist zu Flecken auf den Blättern.
<G-vec00196-002-s589><cause.führen><en> Cortisol, a hormone your body produces in response to stress, can also cause weight gain, specifically around the belly area.
<G-vec00196-002-s589><cause.führen><de> Auch Cortisol, ein Hormon, welches von deinem Körper bei Stress produziert wird, kann zu Gewichtszunahme und Schwimmringen führen.
<G-vec00196-002-s590><cause.führen><en> WARNING: Air travel can cause an excess of ink on the tip and cap.
<G-vec00196-002-s590><cause.führen><de> ACHTUNG: Der Transport auf Flugreisen kann zu einem Übermaß an Tinte in der Markerspitze und Kappe führen.
<G-vec00196-002-s591><cause.führen><en> Fixed problem that would cause record duplication when synchronizing between Mac and iPhone versions.
<G-vec00196-002-s591><cause.führen><de> Problem behoben, das beim Synchronisieren zwischen Mac- und iPhon-Versionen zu doppelten Datensätzen führen konnte.
<G-vec00196-002-s592><cause.führen><en> This will affect future marriage and fertility patterns. Eventually, it could cause unrest among young adult males who will be unable to find partners.
<G-vec00196-002-s592><cause.führen><de> Dies wird sich in Zukunft auf Heirats- und Geburtszahlen auswirken und könnte zu Unruhen unter jungen Männern führen, die keine Partnerinnen finden.
<G-vec00196-002-s593><cause.führen><en> Yet, the reduce can also cause health and wellness problems since the physical body loses a protection layer against any sort of sort of illness.
<G-vec00196-002-s593><cause.führen><de> Dennoch kann die Abnahme auch zu gesundheitlichen Problemen führen, weil der Körper eine Schutzschicht gegen alle Arten von Krankheiten verliert.
<G-vec00196-002-s594><cause.führen><en> When the software is outdated, it can cause problems when trying to get your device recognized by the computer.
<G-vec00196-002-s594><cause.führen><de> Wenn die Software veraltet ist, kann es zu Problemen führen, wenn sie versuchen, das Gerät vom Computer erkannt zu werden.
<G-vec00196-002-s595><cause.führen><en> These deposits can cause irreversible damage to the liner.
<G-vec00196-002-s595><cause.führen><de> Diese Ablagerungen können zu irreversiblen Schäden für die Auskleidung führen.
<G-vec00196-002-s596><cause.führen><en> This could cause irreparable damage to them.
<G-vec00196-002-s596><cause.führen><de> Dies kann zu irreparablen Schäden am Gerät führen.
<G-vec00196-002-s597><cause.führen><en> This load can cause database contention and other factors that can adversely affect performance.
<G-vec00196-002-s597><cause.führen><de> Diese Last kann zu Datenbankkonflikten und anderen Faktoren führen, die sich negativ auf die Leistung auswirken können.
<G-vec00196-002-s598><cause.führen><en> Some insulation can cause stiffness, affecting the overall suppleness of the cable.
<G-vec00196-002-s598><cause.führen><de> Isolierung kann zu Steifigkeit führen und die Elastizität des Kabels beeinflussen.
<G-vec00196-002-s599><cause.führen><en> The temperature of the bottom of the unit may rise during normal operation and could cause discomfort or burns with prolonged contact.
<G-vec00196-002-s599><cause.führen><de> Die Unterseite des Computers kann sich beim normalen Betrieb erwärmen und könnte bei einem Kontakt über längere Zeit zu Beschwerden oder Verbrennungen führen.
<G-vec00196-002-s600><cause.führen><en> For instance, this could cause [8]annoying circumstances for users and third-party bug tracking systems.
<G-vec00196-002-s600><cause.führen><de> Es kann zum Beispiel zu [8]unangenehmen Situationen für Anwender und fremden Fehlerdatenbanken führen.
<G-vec00196-002-s601><cause.führen><en> White A faulty or damaged washing machine door handle can cause a huge problems, especially if you have items stuck in your machine.
<G-vec00196-002-s601><cause.führen><de> Farbe: weiß Ein defekter oder beschädigter Türgriff kann zu großen Problemen führen, vor allem, wenn Sie Wäschestücke...
<G-vec00196-002-s602><cause.führen><en> Users with a Cusy account are required to manage their password securely: unauthorized physical or logical access to objects that can potentially store passwords should not cause compromised passwords.
<G-vec00196-002-s602><cause.führen><de> Benutzer mit einem Cusy-Account sind verpflichtet, ihr Passwort sicher zu verwalten: Unerlaubter physischer oder logischer Zugriff auf Objekte, die potenziell Passwörter speichern können, dürfen nicht zu kompromittierten Passwörtern führen.
<G-vec00196-002-s603><cause.führen><en> These can heat up under a dryer and cause discomfort and burns.
<G-vec00196-002-s603><cause.führen><de> Sie können sich unter einem Föhn erhitzen und zu Unannehmlichkeiten und Verbrennungen führen.
<G-vec00196-002-s604><cause.führen><en> Due to the diversity of such systems, statically choosing processing units for compute kernel execution can cause low performance and high energy consumption or even inhibit the execution in case the required unit is not present.
<G-vec00196-002-s604><cause.führen><de> Aufgrund der Vielseitigkeit solcher Systeme kann eine rein statische Auswahl von Recheneinheiten für die Ausführung sogenannter "compute kernel" zu längeren Laufzeiten und höherem Energieverbrauch führen oder sogar die Anwendungsausführung verhindern, wenn eine benötigte Einheit nicht vorhanden ist.
<G-vec00196-002-s605><cause.führen><en> Modification of the machine or use of parts not tested and approved by the equipment manufacturer can cause unforeseeable damage.
<G-vec00196-002-s605><cause.führen><de> Umbauten an diesem Gerät oder der Gebrauch von Teilen, die nicht vom Hersteller geprüft und freigegeben sind, können beim Betrieb zu unvorhersehbaren Schäden führen.
<G-vec00196-002-s606><cause.führen><en> It's not hard, but if your knees aren't great, it can cause a bit of strain.
<G-vec00196-002-s606><cause.führen><de> Es ist nicht schwer, aber wenn Ihre Knie nicht großartig sind, kann dies zu einer gewissen Belastung führen.
<G-vec00196-002-s607><cause.führen><en> Over time, high heels can damage your joints and cause chronic back pain.
<G-vec00196-002-s607><cause.führen><de> Das Tragen von hochhackigen Schuhen kann deine Gelenke mit der Zeit schädigen und zu chronischen Rückenschmerzen führen.
<G-vec00196-002-s342><cause.hervorrufen><en> We guarantee that the Site is free from information viruses and other properties that may cause loss or damage.
<G-vec00196-002-s342><cause.hervorrufen><de> Wir garantieren nicht, dass die Website frei von Computerviren ist oder von anderen Eigenschaften, die Verluste oder Schäden hervorrufen könnten.
<G-vec00196-002-s343><cause.hervorrufen><en> Worn-out or broken thermostat valve may cause a restricted coolant flow thus preventing the heater to operate properly.
<G-vec00196-002-s343><cause.hervorrufen><de> Ein abgenutztes oder defektes Thermostatventil kann einen verringerten Kühlmitteldurchfluss hervorrufen, wodurch der korrekte Betrieb der Heizung nicht möglich ist.
<G-vec00196-002-s344><cause.hervorrufen><en> No data from that cookie is sent back to AddThis and removing it when disabling cookies would cause unexpected behaviour for users.
<G-vec00196-002-s344><cause.hervorrufen><de> Es werden keinerlei Daten dieses Cookies an AddThis übertragen und die Blockierung dieses Cookies kann Fehlfunktionen für den Benutzer hervorrufen.
<G-vec00196-002-s345><cause.hervorrufen><en> Important: Sometimes, in the course of your work, you will be introduced to words and techniques that may or may not cause subconscious fears and doubts in some people.
<G-vec00196-002-s345><cause.hervorrufen><de> Wichtig: Auf unseren Webseiten werden Sie bisweilen mit Begriffen und Techniken vertraut gemacht, die bei manchen Menschen oft unbewußte Ängste und vielleicht sogar Abneigung hervorrufen können.
<G-vec00196-002-s346><cause.hervorrufen><en> The filter also protects the solar panel from HF stray and leakage currents that can cause premature aging in the PV modules.
<G-vec00196-002-s346><cause.hervorrufen><de> Der Filter schützt die Solarplatte auch gegen HF-Streuverluste und Verlustströme, die ein frühzeitiges Altern der PV-Module hervorrufen können.
<G-vec00196-002-s347><cause.hervorrufen><en> Chronic malabsorption may cause nutritional deficiencies, particularly of vitamins D and B12.
<G-vec00196-002-s347><cause.hervorrufen><de> Chronische Malabsorption kann Nährstoffmängel, insbesondere von Vitamin D und B12, hervorrufen.
<G-vec00196-002-s348><cause.hervorrufen><en> Even if deceased persons do not wish to cause any disagreement between the heirs with the will and decide that they shall inherit as provided by law (intestate succession), disputes that have a negative impact on family relations still occur in practice.
<G-vec00196-002-s348><cause.hervorrufen><de> Auch wenn verstorbene Personen keine Entzweiung zwischen den Erben mit dem Testament hervorrufen möchten und sich entscheiden, dass sie wie gesetzlich vorgesehen erben sollen (gesetzliche Erbfolge), kommt es in der Praxis immer noch zu Streitigkeiten, die sich negativ auf die Familienbeziehungen auswirken.
<G-vec00196-002-s349><cause.hervorrufen><en> Again and again, new questions and challenges arise that cause the need for decision and change.
<G-vec00196-002-s349><cause.hervorrufen><de> Immer wieder entstehen neue Fragestellungen und Herausforderungen, die Entscheidungs- und Veränderungsbedarf hervorrufen.
<G-vec00196-002-s350><cause.hervorrufen><en> It is the spine that can cause pain in heart, kidney, head, etc.
<G-vec00196-002-s350><cause.hervorrufen><de> Das ist eben die Wirbelsäule, die Herz-, Nieren- oder Kopfschmerzen hervorrufen kann.
<G-vec00196-002-s351><cause.hervorrufen><en> Electret is a dielectric material that, a long time preserving the polarized state after the external influence, which led to the polarization (or charge) of the insulator, and created in the surrounding quasi-constant electric field. Filter effectively delays the small particles of dust, dust mites, tobacco smoke, animal hair particles and other microscopic particles that cause allergic reactions in humans.
<G-vec00196-002-s351><cause.hervorrufen><de> Elektret ist ein dielektrisches Material, das für eine lange Zeit den polarisierten Status nach einem externen Einfluss erhält, was zu einer Polarisierung (oder Ladung) des Isolators führt und in der Hausstaubmilben, Tabakrauch, Partikel von Tierhaaren und andere mikroskopische Partikel, die bei Menschen allergische Reaktionen hervorrufen.
<G-vec00196-002-s352><cause.hervorrufen><en> Memories can be good or bad, can cause pain or pleasure.
<G-vec00196-002-s352><cause.hervorrufen><de> Erinnerungen können gut oder schlecht sein, können Schmerz oder Freude hervorrufen.
<G-vec00196-002-s353><cause.hervorrufen><en> In case one nursed babies one year before the surgery she may very well produce milk for a few days following the operation. This may cause discomfort but it can be treated with the medication we will prescribe for you.
<G-vec00196-002-s353><cause.hervorrufen><de> Wenn Sie in dem letzten Jahr vor der Opertion gestillt haben, könnte es sein, dass sie ein paar Tage nach der Operation Milch produzieren.Dies könnte ein Unwohlsein hervorrufen, was aber mit einer von uns verabreichten Medikation behandelt werden kann.
<G-vec00196-002-s354><cause.hervorrufen><en> Clots can occur on such calcifications and can either suddenly or slowly and progressively cause a complete vascular occlusion.
<G-vec00196-002-s354><cause.hervorrufen><de> An solchen Verkalkungen können Blutgerinnsel entstehen und plötzlich oder langsam fortschreitend einen vollständigen Gefäßverschluss hervorrufen.
<G-vec00196-002-s355><cause.hervorrufen><en> Therapists can cause multiple personality disorder (MPD) by mind manipulation, but early in life trauma makes victims especially vulnerable.
<G-vec00196-002-s355><cause.hervorrufen><de> Multiple Persönlichkeitsstörungen können von Therapeuten hervorrufen werden, doch Trauma in jungen Jahren machen die Opfer besonders anfällig.
<G-vec00196-002-s356><cause.hervorrufen><en> However, you should know that very rarely lanolin or cetrimide, which is part of the ointment, can cause allergic reactions.
<G-vec00196-002-s356><cause.hervorrufen><de> Sie sollten jedoch wissen, dass Lanolin oder Cetrimid, das Teil der Salbe ist, sehr selten allergische Reaktionen hervorrufen können.
<G-vec00196-002-s357><cause.hervorrufen><en> The bully might be so surprised that you can cause laughter or, at a minimum, get away.
<G-vec00196-002-s357><cause.hervorrufen><de> Der Tyrann könnte so überrascht sein, dass du Gelächter hervorrufen oder zumindest weglaufen kannst.
<G-vec00196-002-s358><cause.hervorrufen><en> After that, and due to the internal conflict that premonitions cause for me, I began having these experiences voluntarily, with the goal of experimentation.
<G-vec00196-002-s358><cause.hervorrufen><de> Danach konnte ich aufgrund des inneren Konfliktes durch diese Ahnungen diese Erfahrungen willentlich hervorrufen, um damit zu experimentieren.
<G-vec00196-002-s359><cause.hervorrufen><en> Early signs of allergic reactions include difficulty breathing, shortness of breath, swelling, hives, itching, generalised urticaria, tightness of the chest, wheezing, low blood pressure, blurred vision and anaphylaxis (severe allergic reaction that can cause difficulty in swallowing and/or breathing, red or swollen face and/or hands).
<G-vec00196-002-s359><cause.hervorrufen><de> Frühe Anzeichen von allergischen Reaktionen können sein: Atembeschwerden, Kurzatmigkeit, Schwellung, Nesselsucht, Juckreiz, generalisierte Urtikaria, Engegefühl im Brustbereich, pfeifende Atmung, niedriger Blutdruck, verschwommenes Sehen und Anaphylaxie (schwere allergische Reaktion, die Schluck- und/ oder Atembeschwerden, Rötungen oder Schwellungen im Gesicht und/ oder an den Händen hervorrufen kann).
<G-vec00196-002-s360><cause.hervorrufen><en> In some cases, oral supplements may cause negative side effects or aggravate symptoms of other health conditions.
<G-vec00196-002-s360><cause.hervorrufen><de> In manchen Fällen können orale Zusatzmittel negative Nebeneffekte hervorrufen oder Symptome anderer Gesundheitsprobleme verschlimmern.
<G-vec00196-002-s475><cause.veranlassen><en> It works by blocking the action of certain blood cells (eg, T lymphocytes) that can cause the body to reject the transplanted organ.
<G-vec00196-002-s475><cause.veranlassen><de> Es funktioniert, indem es die Aktion von bestimmten Blutzellen blockiert (z.B., t-Lymphozyten) die den Körper veranlassen können, das verpflanzte Organ zurückzuweisen.
<G-vec00196-002-s476><cause.veranlassen><en> This is because your adrenal gland releases stress hormones which tend to cause your cardiovascular system to overwork.
<G-vec00196-002-s476><cause.veranlassen><de> Deine Nebennierendrüse setzt Hormone frei, die das Herz-Kreislauf-System dazu veranlassen, mehr zu arbeiten.
<G-vec00196-002-s477><cause.veranlassen><en> If you will do this, I will do my part and cause him to begin to stand tall.
<G-vec00196-002-s477><cause.veranlassen><de> Wenn ihr dies tut, werde Ich Meinen Teil ausführen und ihn veranlassen, gross zu stehen.
<G-vec00196-002-s478><cause.veranlassen><en> (5) The FanClub management may cause amendments, if at least 51% of the management participants agree to this change.
<G-vec00196-002-s478><cause.veranlassen><de> (5) Die FanClubleitung kann Satzungsänderungen veranlassen, wenn mindestens 51% der Leitungsteilnehmer dieser Änderung zustimmen.
<G-vec00196-002-s479><cause.veranlassen><en> The exception is commands like GET, that cause a value to be returned in the extended return code.
<G-vec00196-002-s479><cause.veranlassen><de> Die Ausnahme sind Befehle wie GET, die veranlassen, einen Wert in dem erweiterten Rückgabewert zurückzugeben.
<G-vec00196-002-s480><cause.veranlassen><en> Source mail databases are corrupted Corrupted items in source mail databases can cause the Exchange Migration Wizard to report problems during the extraction process.
<G-vec00196-002-s480><cause.veranlassen><de> Quellpostfächer sind beschädigt Beschädigte Elemente in Quellpostfächern können den Assistenten für die Migration zu Exchange veranlassen, während des Extraktionsvorgangs Probleme aufzuzeichnen.
<G-vec00196-002-s481><cause.veranlassen><en> But the very fact that the energy is not materialistic focus, can not be presented to the senses, I see a guarantee that it will cause a profound transformation in the spirits.
<G-vec00196-002-s481><cause.veranlassen><de> Aber gerade darin, dass die Energie nicht materialistisch gefasst, nicht sinnlich vorgestellt werden kann, sehe ich eine Bürgschaft dafür, dass sie eine tiefgehende Umwälzung in den Geistern veranlassen wird.
<G-vec00196-002-s482><cause.veranlassen><en> A power failure might cause the lift to stop between two floors.
<G-vec00196-002-s482><cause.veranlassen><de> Ein Stromausfall konnte das Höhenruder veranlassen, zwischen zwei Fußböden zu stoppen.
<G-vec00196-002-s483><cause.veranlassen><en> What you do now for MY glory and what you have done for MY glory alone will cause MY Son to spare you of the horror of MY wrath and judgment to come.
<G-vec00196-002-s483><cause.veranlassen><de> Einzig und allein, was du jetzt zu MEINER Ehre tust und was du zu MEINER Ehre getan hast, wird MEINEN Sohn veranlassen, dich von dem Schrecken MEINES zukünftigen Zorns und Gerichts zu verschonen.
<G-vec00196-002-s484><cause.veranlassen><en> The employee of Socialis for The Gambia e.V. will cause the restriction of the processing.
<G-vec00196-002-s484><cause.veranlassen><de> Der Mitarbeiter der ATELIER STÖCKL wird die Einschränkung der Verarbeitung veranlassen.
<G-vec00196-002-s485><cause.veranlassen><en> “I am going to cause an explosion of faith around the world.
<G-vec00196-002-s485><cause.veranlassen><de> “Ich werde rund um die Welt eine Glaubens-Explosion veranlassen.
<G-vec00196-002-s486><cause.veranlassen><en> By opening the “YouTube” page, you cause the recommendation components to make the browser you are using download the corresponding portrayal of the components from the supplier in question.
<G-vec00196-002-s486><cause.veranlassen><de> Mit dem Aufruf der „YouTube“-Seite veranlassen die Empfehlungs-Komponenten, dass der von Ihnen verwendete Browser eine entsprechende Darstellung der Komponente von dem jeweiligen Anbieter herunterlädt.
<G-vec00196-002-s487><cause.veranlassen><en> For I do not forget you; I just keep myself often hidden to cause you to call for me.
<G-vec00196-002-s487><cause.veranlassen><de> Denn Ich vergesse euch nicht, nur halte Ich Mich oft verborgen, um euch zu veranlassen, nach Mir zu rufen.
<G-vec00196-002-s488><cause.veranlassen><en> It is also considered as a misleading omission, if a company is hiding essential information or if it provides it only in an unclear, unintelligible, ambiguous or untimely manner which in result causes the average consumer to take a transactional decision, or is likely to cause it, in cases where he would not have taken that decision otherwise.
<G-vec00196-002-s488><cause.veranlassen><de> Als irreführende Unterlassung gilt es auch, wenn ein Unternehmer wesentliche Informationen verheimlicht oder auf unklare, unverständliche, zweideutige Weise oder nicht rechtzeitig bereitstellt und dies jeweils einen Durchschnittsverbraucher zu einer geschäftlichen Entscheidung veranlasst oder ihn zu veranlassen geeignet ist, die er ansonsten nicht getroffen hätte.
<G-vec00196-002-s489><cause.veranlassen><en> For every increase or decrease of body temperature can cause chemical reaction in the body and electrochemical activity in the heart.
<G-vec00196-002-s489><cause.veranlassen><de> Jede Erhöhung oder Senkung der Körpertemperatur kann chemische Reaktionen im Körper veranlassen und die elektrochemische Aktivität des Herzens beeinflussen.
<G-vec00196-002-s490><cause.veranlassen><en> This medication can cause you to have unusual results with certain medical tests.
<G-vec00196-002-s490><cause.veranlassen><de> Dieses Medikament kann Sie veranlassen, ungewöhnliche Ergebnisse mit bestimmten medizinischen Tests zu haben.
<G-vec00196-002-s491><cause.veranlassen><en> The employee of the IAI industrial robot GmbH will cause the necessary in individual cases.
<G-vec00196-002-s491><cause.veranlassen><de> Der Mitarbeiter der Classic-Line Warenhandelsgesellschaft mbH wird im Einzelfall das Notwendige veranlassen.
<G-vec00196-002-s492><cause.veranlassen><en> Admittedly, this type of wine for winemaking wine lovers who love the sound of a bottle of wine bottle, cause the nose to turn up.
<G-vec00196-002-s492><cause.veranlassen><de> Zugegeben, diese Verpackungsart für Wein mag Weinkenner die das Geräusch des Entkorkens einer Weinflasche lieben, veranlassen, die Nase zu rümpfen.
<G-vec00196-002-s493><cause.veranlassen><en> “This should give you great cause for joy and hope that nothing in your life is wasted and the greater the sacrifice, the greater impact you are having on My Kingdom coming to this Earth, and the number of souls added to Me is increasing.
<G-vec00196-002-s493><cause.veranlassen><de> “Dies sollte euch zu großer Freude veranlassen und euch die Hoffnung schenken, dass nichts in eurem Leben vergeudet ist und je größer das Opfer, um so größeren Einfluss habt ihr auf Mein Königreich, das auf diese Erde kommt und die Zahl der Seelen, die Mir hinzugefügt werden, steigen an.
<G-vec00196-002-s513><cause.verursachen><en> Affected enemy units, monsters and heroes cause 90% less damage for 30 seconds.
<G-vec00196-002-s513><cause.verursachen><de> Getroffene feindliche Einheiten, Helden und Monster verursachen für 30 Sekunden 90% weniger Schaden.
<G-vec00196-002-s514><cause.verursachen><en> Jam can not be poured into wet jars, as moisture can cause mold and damage to the product.
<G-vec00196-002-s514><cause.verursachen><de> Marmelade kann nicht in nasse Gläser gegossen werden, da Feuchtigkeit Schimmel und Schäden am Produkt verursachen kann.
<G-vec00196-002-s515><cause.verursachen><en> NO2 affects lung function and, among children, lung development. It can cause cell damage and inflammation in the alveoli and, like particulate matter, also causes an increase in heart/circulatory disease.
<G-vec00196-002-s515><cause.verursachen><de> NO2 beeinträchtigt die Lungenfunktion sowie Lungenfunktionsentwicklung bei Kindern, kann Zellschädigungen und Entzündungsprozesse im Alveolengewebe verursachen und bewirkt ebenfalls eine Zunahme der Herz-Kreislauferkrankungen.
<G-vec00196-002-s516><cause.verursachen><en> Doxorubicin is a widely used, potent chemotherapeutic agent, which may cause severe damage to the heart.
<G-vec00196-002-s516><cause.verursachen><de> Doxorubicin ist ein häufig verwendetes, potentes Chemotherapeutikum, das schwere Herzschädigungen verursachen kann.
<G-vec00196-002-s517><cause.verursachen><en> Anti blue light: filters over 90% of the harmful blue light that can cause Rubber
<G-vec00196-002-s517><cause.verursachen><de> 90 % des schädlichen Blaulichts, das Ermüdung und Sehverlust verursachen kann.
<G-vec00196-002-s518><cause.verursachen><en> [MFSA-2006-03] CVE-2006-0292 The Javascript interpreter does not properly dereference objects, which allows remote attackers to cause a denial of service or execute arbitrary code.
<G-vec00196-002-s518><cause.verursachen><de> [MFSA-2006-03] CVE-2006-0292 Der JavaScript-Interpreter dereferenziert einige Objekte nicht angemessen, wodurch es entfernten Angreifern erlaubt wird, eine Diensteverweigerung (denial of service) zu verursachen oder beliebigen Code auszuführen.
<G-vec00196-002-s519><cause.verursachen><en> Speed of this natural degradation depends on the circumstances, but resulting radioactive emitting fragments and liquids ever cause follow-up environmental harm.
<G-vec00196-002-s519><cause.verursachen><de> Die Geschwindigkeit des natürlichen chemischen Abbaus hängt von den Umständen ab, die sich daraus ergebenden radioaktiv strahlenden Fragmente und Flüssigkeiten verursachen in jedem Fall erhebliche Umweltschutzprobleme.
<G-vec00196-002-s520><cause.verursachen><en> One thing works perfectly – always when we try too hard at the same time we push away our desired things and cause more damage than success.
<G-vec00196-002-s520><cause.verursachen><de> Eine Sache funktioniert aber immer ausgezeichnet: wenn wir uns zu viel bemühen, treiben wir es zugleich weg von uns und oft verursachen wir so mehr Schaden als Nutzen.
<G-vec00196-002-s521><cause.verursachen><en> These medications are available by prescription only, and can weaken your immune system and cause other serious side effects.
<G-vec00196-002-s521><cause.verursachen><de> Diese Medikamente sind nur gegen die Vorlage eines Rezepts erhältlich und können dein Immunsystem schwächen oder andere ernsthafte Nebenwirkungen verursachen.
<G-vec00196-002-s522><cause.verursachen><en> Depending on the grindability of your orebody, abrasion will cause a certain amount of deterioration to the steel media and liners in your circuit.
<G-vec00196-002-s522><cause.verursachen><de> Je nach Mahlbarkeit Ihres Erzkörpers wird der Abrieb eine gewisse Verschlechterung des Stahls und der Auskleidungen in Ihrem Schaltkreis verursachen.
<G-vec00196-002-s523><cause.verursachen><en> –Improper connection can cause electric shock.
<G-vec00196-002-s523><cause.verursachen><de> –Falsches Anschließen kann Stromschläge verursachen.
<G-vec00196-002-s524><cause.verursachen><en> This region of the world is a source of the severe yellow dust storms that cause serious problems in northeast Asia.
<G-vec00196-002-s524><cause.verursachen><de> In dieser Region entstehen größtenteils die starken gelben Sandstürme, die ernsthafte Probleme in Nordostasien verursachen.
<G-vec00196-002-s525><cause.verursachen><en> Put a lot of salt, may produce nitrite, if the body's nitrite exceeds the standard, it may lead to acute poisoning, and if you eat salted food for a long time, it may cause cancer.
<G-vec00196-002-s525><cause.verursachen><de> Setzen Sie viel Salz, können Nitrit produzieren, wenn das Nitrit im Körper den Standard übersteigt, kann es zu akuter Vergiftung kommen, und wenn Sie lange Zeit gesalzenes Essen zu sich nehmen, kann dies Krebs verursachen.
<G-vec00196-002-s526><cause.verursachen><en> Improper adjustment of controls not described in the instructions can cause damage, which often requires extensive adjustment work by a qualified technician.
<G-vec00196-002-s526><cause.verursachen><de> Unsachgemäße, nicht dokumentierte Einstellungen können Schäden verursachen und machen häufig umfangreiche Einstellarbeiten durch einen qualifizierten Service-Technikererforderlich.
<G-vec00196-002-s527><cause.verursachen><en> The two grade material may cause scratches and chromatic aberration in the production process, but it is not very serious.
<G-vec00196-002-s527><cause.verursachen><de> Das zweiwertige Material kann Kratzer und chromatische Aberration im Produktionsprozess verursachen, ist jedoch nicht sehr ernst.
<G-vec00196-002-s528><cause.verursachen><en> Your Devastate and Revenge also cause 5 Bleed damage over 15 sec. Buff
<G-vec00196-002-s528><cause.verursachen><de> Eure Fähigkeiten 'Verwüsten' und 'Rache' verursachen zusätzlich im Verlauf von 15 sec 5 Blutungsschaden.
<G-vec00196-002-s529><cause.verursachen><en> In a rat model of neuropathic pain molecules, which bind to the CB1 receptor but do not cross the blood-brain barrier and thus do not cause psychological side effects, alleviated pain.
<G-vec00196-002-s529><cause.verursachen><de> In einem Rattenmodell für neuropathische Schmerzen linderten Moleküle, die an den CB1-Rezeptor binden, aber nicht die Blut-Hirn-Schranke überwinden und daher keine psychologischen Nebenwirkungen verursachen, Schmerzen.
<G-vec00196-002-s530><cause.verursachen><en> Dr. Bach described 38 negative mental (emotional) states which cause illness.
<G-vec00196-002-s530><cause.verursachen><de> Dr. Bach hat 38 negative psychische (seelische) Zustände beschrieben, die Krankheiten verursachen.
<G-vec00196-002-s531><cause.verursachen><en> Another consequence is moisture in the shaft head area, which can cause building damage and the formation of mould.
<G-vec00196-002-s531><cause.verursachen><de> Eine weitere Folge ist Feuchtigkeit im Schachtkopfbereich, die Bauschäden und Schimmelpilzbildung verursachen kann.
<G-vec00196-002-s532><cause.verursachen><en> In addition, due to the absence of metal particles, it will not cause a short-circuit or serious damage to the computer when in contact with electrical contacts.
<G-vec00196-002-s532><cause.verursachen><de> Aufgrund der Abwesenheit von Metallpartikeln verursacht es außerdem keinen Kurzschluss oder ernsthafte Beschädigung des Computers, wenn es mit elektrischen Kontakten in Kontakt kommt.
<G-vec00196-002-s533><cause.verursachen><en> Malfunctioning of this gland will cause hormonal imbalance in the body.
<G-vec00196-002-s533><cause.verursachen><de> Fehlfunktion dieser Drüse verursacht hormonelles Ungleichgewicht im Körper.
<G-vec00196-002-s534><cause.verursachen><en> Cooee Classics logos, trademarks and trade dress may not be used in connection with any product or service that is not Cooee Classics, in any manner that is likely to cause confusion among customers, or in any manner that disparages or discredits Cooee Classics and CooeeClassics.com.
<G-vec00196-002-s534><cause.verursachen><de> Blinks Marken- und Kennzeichen dürfen nicht in Verbindung mit einem Produkt oder Dienst, der nicht zu Blink gehört, in einer Weise verwendet werden, dass die Möglichkeit besteht, dass Zuordnungsverwechslungen bei Kunden verursacht werden oder in einer Weise, die Blink herabsetzt oder diskreditiert.
<G-vec00196-002-s535><cause.verursachen><en> Only reliable measurements and data allow it to prove with certainty that the train’s power electronics do not cause critical frequencies.
<G-vec00196-002-s535><cause.verursachen><de> Denn nur dann können wir sicher beurteilen, ob die Leistungselektronik keine kritischen Frequenzen verursacht“, sagt Kappel.
<G-vec00196-002-s536><cause.verursachen><en> But the most common cause of tinnitus is exposure to noise.
<G-vec00196-002-s536><cause.verursachen><de> Am häufigsten wird Tinnitus durch Lärm verursacht.
<G-vec00196-002-s537><cause.verursachen><en> allianz.com: Quite apart from natural catastrophes the increasing use of technology also means that there's an additional risk that hackers might cause power cuts.
<G-vec00196-002-s537><cause.verursachen><de> allianz.com: Nebst Gefahren aus der Natur steigt mit der zunehmenden Technisierung ja auch noch die Gefahr, dass ein Computerhacker einen Stromausfall verursacht.
<G-vec00196-002-s538><cause.verursachen><en> It will cause unnecessary modifications to your browser preferences, none of which will serve to your benefit.
<G-vec00196-002-s538><cause.verursachen><de> Es verursacht unnötige Änderungen an den Einstellungen Ihres Browsers, keiner von denen zu Ihrem Vorteil dienen wird.
<G-vec00196-002-s539><cause.verursachen><en> At this time, the phenomenon of passing and breaking will occur, which will inevitably cause quality problems of the product.
<G-vec00196-002-s539><cause.verursachen><de> Zu diesem Zeitpunkt tritt das Phänomen des Passierens und Brechens auf, was unweigerlich Qualitätsprobleme des Produkts verursacht.
<G-vec00196-002-s540><cause.verursachen><en> If the correct value would cause overflow, plus or minus INFINITY is returned (according to the sign of the value), and ERANGE is stored in errno.
<G-vec00196-002-s540><cause.verursachen><de> Falls der korrekte Wert einen Überlauf verursacht, wird plus oder minus HUGE_VAL (HUGE_VALF, HUGE_VALL) zurückgegeben (abhängig vom Vorzeichen des Wertes) und ERANGE wird in errno gespeichert.
<G-vec00196-002-s541><cause.verursachen><en> The infected discharge remaining in the nose will seep into the side cavities and can cause the inflammation of the accessory cavities, or can get into the middle ear through the pharyngo-tympanic tube causing the inflammation of the middle ear.
<G-vec00196-002-s541><cause.verursachen><de> Das in der Nase angestaute infizierte Sekret wandert in die Nasennebenhöhlen und verursacht eine Nasennebenhöhlenentzündung, über die Ohrtrompete kann es in das Mittelohr gelangen und eine Mittelohrentzündung herbeiführen.
<G-vec00196-002-s542><cause.verursachen><en> Unpurified mercury “possesses many blemishes and they can cause many disorders in the body.
<G-vec00196-002-s542><cause.verursachen><de> Ungereinigtes Quecksilber „besitzt viele Makel und verursacht zahlreiche Störungen im Körper.
<G-vec00196-002-s543><cause.verursachen><en> GTN may cause some headaches and dizziness.
<G-vec00196-002-s543><cause.verursachen><de> GTN verursacht möglicherweise etwas Kopfschmerzen und Übelkeit.
<G-vec00196-002-s544><cause.verursachen><en> Note: Since Windows 10 version 1803, Microsoft has added native SSH support, which is known to cause conflict with Git connections.
<G-vec00196-002-s544><cause.verursachen><de> Hinweis: Seit Windows 10, Version 1803, bietet Microsoft native SSH-Unterstützung, die bekanntermaßen Konflikte mit Git-Verbindungen verursacht.
<G-vec00196-002-s545><cause.verursachen><en> But God does not cause evil, nor does He prevent man’s choice to do evil.
<G-vec00196-002-s545><cause.verursachen><de> Jedoch verursacht Gott nichts böses, noch verhindert er die Entscheidung der Menschen böses zu tun.
<G-vec00196-002-s546><cause.verursachen><en> I apologize for any inconvenience this may cause.
<G-vec00196-002-s546><cause.verursachen><de> Ich entschuldige mich schon vorab für etwaige Unannehmlichkeiten, die diese Änderung verursacht.
<G-vec00196-002-s547><cause.verursachen><en> Mixing will cause no heat, or burn out.
<G-vec00196-002-s547><cause.verursachen><de> Das Mischen verursacht keine Hitze oder Ausbrennen.
<G-vec00196-002-s548><cause.verursachen><en> Connecting the external drive and its cables to another Mac can help make sure the drive does not cause kernel panics.
<G-vec00196-002-s548><cause.verursachen><de> Indem Sie das externe Laufwerk und die Kabel zunächst an einem anderen Mac testen, können Sie sicherstellen, dass die Kernel Panics nicht durch das Laufwerk verursacht werden.
<G-vec00196-002-s549><cause.verursachen><en> It doesn’t cause false response of the security system, there is a possibility to interrupt sending, the number of already sent messages and messages to be sent is shown in the Mail Merge Toolkit information window.
<G-vec00196-002-s549><cause.verursachen><de> Es verursacht keine falsche Reaktion seitens Sicherheitssystems, es gibt eine Möglichkeit den Versand zu unterbrechen, die Anzahl der gesendeten und der noch zusendenden Nachrichten wird in einem Informationsfenster angezeigt.
<G-vec00196-002-s550><cause.verursachen><en> Remember that in your situation the most important thing is to avoid constipation, so try to eat food that does not cause annoying difficulties.
<G-vec00196-002-s550><cause.verursachen><de> Denken Sie daran, dass in Ihrer Situation das Wichtigste ist, Verstopfung zu vermeiden, also versuchen Sie, Essen zu essen, das keine lästigen Schwierigkeiten verursacht.
