<G-vec00095-002-s038><adapt.adaptieren><en> Fields of expertise Our professional translators translate and adapt specialized texts for the marketplace as well as the research institute.
<G-vec00095-002-s038><adapt.adaptieren><de> Fachgebiete Unsere professionellen Übersetzer adaptieren Fachtexte aus den Bereichen Marketing und Wissenschaft.
<G-vec00095-002-s039><adapt.adaptieren><en> Therefore you may not copy, modify, adapt, translate, distribute, reverse engineer, reverse assemble or decompile the contents thereof.
<G-vec00095-002-s039><adapt.adaptieren><de> Sie dürfen daher diese Inhalte nicht kopieren, modifizieren, adaptieren, übersetzen, verteilen, rückentwickeln, rückassemblieren oder dekompilieren.
<G-vec00095-002-s040><adapt.adaptieren><en> On the one hand, they are mixed with pop culture (e.g. advanced electronic music), on the other hand they adapt approaches that orientate themselves on aesthetic or abstract principles of painting.
<G-vec00095-002-s040><adapt.adaptieren><de> Sie vermischen sich auf der einen Seite mit der Popkultur (etwa im Feld der avancierten Elektronik), auf der anderen Seite adaptieren sie Herangehensweisen, die sich an abbildungsästhetischen oder abstrakten Prinzipien der Malerei orientieren.
<G-vec00095-002-s041><adapt.adaptieren><en> In terms of technical means, the aim is to adapt the effect of existing instruments rather than invent new ones.
<G-vec00095-002-s041><adapt.adaptieren><de> Bei den technischen Mitteln geht es mehr darum, die Wirkung vorhandener Instrumente zu adaptieren, als neue Instrumente zu schaffen.
<G-vec00095-002-s042><adapt.adaptieren><en> Until now I have always managed to adapt the music for the stage.
<G-vec00095-002-s042><adapt.adaptieren><de> Bisher habe ich es immer geschafft die Musik für die Bühne zu adaptieren.
<G-vec00095-002-s043><adapt.adaptieren><en> There is a staircase out of the kitchen up to the sitting area but there is no stair gate for the smaller members of your party so you may have to improvise, adapt and overcome this.
<G-vec00095-002-s043><adapt.adaptieren><de> Es gibt eine Treppe aus der Küche in den Wohnbereich, aber es gibt keine Treppengitter für die kleineren Mitglieder Ihrer Partei, so dass Sie improvisieren müssen können, adaptieren und diese überwinden.
<G-vec00095-002-s044><adapt.adaptieren><en> Our staff is able to adapt the manufacturing documentation received from customers and make suggestions to improve the effectiveness of the production process.
<G-vec00095-002-s044><adapt.adaptieren><de> Unsere Kollegen sind fähig die von unseren Besteller erhaltenen Herstellerdokumentation zu adaptieren und sie können einen Vorschlag für die Steigerung der Effizienz der Produktionstechnologie geben.
<G-vec00095-002-s045><adapt.adaptieren><en> If you do post content or submit material, and unless we indicate otherwise, you grant DOMINUS CERVIX INTERNATIONAL and its associates a nonexclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such content throughout the world in any media.
<G-vec00095-002-s045><adapt.adaptieren><de> Falls Sie Inhalte posten oder Material einreichen und Pearson VUE keine anderweitige schriftlich unterzeichnete Zustimmung erteilt, gewähren Sie Pearson VUE ein nicht-exklusives, Lizenzgebühr-freies, unbefristetes, unwiderrufbares und vollständig unterlizenzierbares Recht, diese Inhalte weltweit und in allen Medien zu benutzen, zu reproduzieren, zu modifizieren, zu adaptieren, zu veröffentlichen, zu übersetzen, zu verteilen, darzustellen und derivate Werke daraus zu erstellen.
<G-vec00095-002-s046><adapt.adaptieren><en> The live-action movie adaptation of JoJo’s Bizarre Adventure will adapt only Part 4, which is set in Japan.
<G-vec00095-002-s046><adapt.adaptieren><de> Die Live-Action Film Adaption von JoJo’s Bizarre Adventure wird nur den vierten Teil adaptieren, welcher in Japan spielt.
<G-vec00095-002-s047><adapt.adaptieren><en> An OEM now asked us to adapt that to their environment and to evaluate possibilities for implementation.
<G-vec00095-002-s047><adapt.adaptieren><de> Ein Automobilhersteller beauftragte uns nun, dieses an sein Umfeld zu adaptieren und Umsetzungsmöglichkeiten zu prüfen.
<G-vec00095-002-s048><adapt.adaptieren><en> Most page layouts that are included with FrontFace for Public Displays can adapt themselves dynamically to the actual screen resolution and screen orientation.
<G-vec00095-002-s048><adapt.adaptieren><de> Die meisten Layouts, die bei FrontFace for Public Displays mitgeliefert werden, können sich automatisch an beliebige Bildschirmauflösungen und Orientierungen adaptieren.
<G-vec00095-002-s049><adapt.adaptieren><en> The Particle Display allows you to adapt the decay characteristics in different frequency bands.
<G-vec00095-002-s049><adapt.adaptieren><de> Im Particle Display kannst du die Decay Charakteristika in unterschiedlichen Frequenzbereichen adaptieren.
<G-vec00095-002-s050><adapt.adaptieren><en> On account of the diversity and dynamic development of technologies, companies need to adapt them to their needs.
<G-vec00095-002-s050><adapt.adaptieren><de> Aufgrund der Vielfalt und dynamischen Entwicklung der Technologien müssen Unternehmen diese für ihren Bedarf adaptieren.
<G-vec00095-002-s051><adapt.adaptieren><en> The aim is to develop new business models and concepts and to adapt established models for new markets.
<G-vec00095-002-s051><adapt.adaptieren><de> Ziel ist, neue Geschäftsmodelle und Konzepte zu entwickeln und etablierte Modelle für neue Märkte zu adaptieren.
<G-vec00095-002-s052><adapt.adaptieren><en> We develop independent communication solutions or adapt international campaigns for the German market in order to give global active clients in Germany a competitive edge.
<G-vec00095-002-s052><adapt.adaptieren><de> Wir entwickeln eigenständige Kommunikationslösungen oder adaptieren internationale Kampagnen für den deutschen Markt, um global aktiven Kunden in Deutschland einen Wettbewerbsvorsprung herauszuarbeiten.
<G-vec00095-002-s053><adapt.adaptieren><en> We adapt modelling, integration and optimization independently and in combination.
<G-vec00095-002-s053><adapt.adaptieren><de> Hierfür adaptieren wir die Modellierung, die Integration und die Optimierung sowohl einzeln als auch in Kombination.
<G-vec00095-002-s054><adapt.adaptieren><en> They adapt, design and program plug-ins.
<G-vec00095-002-s054><adapt.adaptieren><de> Sie adaptieren, entwerfen, programmieren Plugins.
<G-vec00095-002-s055><adapt.adaptieren><en> We adapt content management systems (CMS) and integrate this software into existing or newly created design templates.
<G-vec00095-002-s055><adapt.adaptieren><de> Wir adaptieren für Sie Content-Management Systeme (CMS) und integrieren in vorhandene oder neu erstellte Designvorlagen.
<G-vec00095-002-s056><adapt.adaptieren><en> 8.3.1 Customer may not: (1) copy (save for making a back up copy), adapt, licence, sell, assign, sublicense, or otherwise transfer or encumber the Software; (2) use the Software in a managed services arrangement; or (3) use the Software in excess of the authorised number of licensed seats for concurrent users, sites, or other criteria specified in the applicable Service Documents.
<G-vec00095-002-s056><adapt.adaptieren><de> 8.3.1 Dem Kunden ist es untersagt: (1) die Software zu kopieren (ausgenommen sind Sicherungskopien), zu adaptieren, zu lizenzieren, zu verkaufen, abzutreten, zu unterlizenzieren oder sonst wie zu übertragen oder zu belasten; (2) die Software in einem Managed Services Arrangement zu benutzen, oder (3) die Software an mehr als der zugelassenen Anzahl lizenzierter Arbeitsplätze für Simultanbenutzer, Standorte oder sonstigen in den betreffenden Servicedokumenten vorgegebenen Kriterien zu benutzen.
<G-vec00095-002-s086><adapt.anpassen><en> A general overhaul can modernise such vehicles with the networked expertise of the manufacturer from top to bottom and can adapt them completely to today's requirements.
<G-vec00095-002-s086><adapt.anpassen><de> Mit einer Generalüberholung können solche Fahrzeuge mit dem vernetzten Know-how des Herstellers von Grund auf modernisiert und an heutige Anforderungen vollständig angepasst werden.
<G-vec00095-002-s087><adapt.anpassen><en> The appearance and positioning of individual operating elements can be changed to a great extent to quickly adapt the environment to your own requirements.
<G-vec00095-002-s087><adapt.anpassen><de> Aussehen und Positionierung einzelner Bedienelemente sind dabei in hohem Maße veränderbar, sodass Sie die Umgebung schnell an die eigenen Vorstellungen angepasst haben.
<G-vec00095-002-s088><adapt.anpassen><en> Being the face of the THESEUS program, the Core Technology Cluster provides adaptable knowledge visualization approaches for several use cases of the THESEUS program. These approaches provide the ability to adapt the visualization to specific contexts or users.
<G-vec00095-002-s088><adapt.anpassen><de> Als „Gesicht“ des THESEUS Programms bietet das Kerntechnologien-Cluster für die unterschiedlichen Use Cases oder Teilprojekte des THESEUS Programms adaptierbare Ansätze für die Wissensvisualisierung, die an dem jeweiligen Zusammenhang aber auch an die Benutzer angepasst werden können.
<G-vec00095-002-s089><adapt.anpassen><en> If your survey can truly ‘listen’ to its respondents, it should then adapt the conversation on the fly.
<G-vec00095-002-s089><adapt.anpassen><de> Wenn Ihre Umfrage nicht wirklich ihre Befragten “erhört”, sollte sie an das laufende Gespräch angepasst werden.
<G-vec00095-002-s090><adapt.anpassen><en> Types are adapt to the dressing unit.
<G-vec00095-002-s090><adapt.anpassen><de> Die Ausführungen sind an die maschinelle Abrichteinheit angepasst.
<G-vec00095-002-s091><adapt.anpassen><en> Our hotel's own restaurant space in the very heart of León's commercial hub offers a regularly-updated menu which seeks to adapt to current trends, based on local traditional cuisine.
<G-vec00095-002-s091><adapt.anpassen><de> Der eigene gastronomische Bereich unseres Hotels im Geschäftsviertel von León bietet eine laufend aktualisierte Auswahl an Gerichten aus der traditionellen lokalen Küche, die den aktuellen Trends angepasst wurde.
<G-vec00095-002-s092><adapt.anpassen><en> Engineers need flexible hardware, software, and instrumentation to adapt these systems to new signal types and threats. Flexible Solutions Across the RF Spectrum
<G-vec00095-002-s092><adapt.anpassen><de> Daher benötigen Ingenieure flexible Software und Messtechnik zur Entwicklung neuartiger C4ISR-Kommunikationssysteme, die Bedrohungen rechtzeitig erkennen und an komplexe Signaltypen angepasst werden können.
<G-vec00095-002-s093><adapt.anpassen><en> In today’s global marketplace, business leaders need to ensure they have scalable support which can easily adapt to inevitable change, especially as they grow.” concluded Gill at Epicor Software.
<G-vec00095-002-s093><adapt.anpassen><de> Auf dem heutigen Weltmarkt müssen Führungskräfte sicherstellen, dass sie eine skalierbare Umgebung haben, die einfach an den unvermeidbaren Wandel angepasst werden kann – insbesondere, wenn sie wachsen“, so das Fazit von Müller-Wolf von Epicor Software.
<G-vec00095-002-s094><adapt.anpassen><en> Comprehensive, flexible solutions that meet your needs and adapt to your life situation, so you can live peacefully in your home, travel, protect your health, prepare for retirement, save and protect your family and build up an estate.
<G-vec00095-002-s094><adapt.anpassen><de> Wir bieten umfassende und flexible Lösungen an, die Ihren Bedürfnissen gerecht werden und an Ihren Lebenszyklus angepasst sind, damit Sie unbeschwert wohnen und leben, reisen, auf Ihre Gesundheit achten, Ihren Ruhestand vorbereiten, sparen, Ihre Familie schützen und ein Vermögen aufbauen können.
<G-vec00095-002-s095><adapt.anpassen><en> This solution enables companies to streamline their processes, make them more flexible, and adapt them to current challenges.
<G-vec00095-002-s095><adapt.anpassen><de> Mithilfe dieser Lösung können die Prozesse im Unternehmen verschlankt, flexibilisiert und an aktuelle Herausforderungen angepasst werden.
<G-vec00095-002-s096><adapt.anpassen><en> But the distinctive feature of the Vietnamese has always been the ability to perceive foreign culture and adapt it to their own conditions.
<G-vec00095-002-s096><adapt.anpassen><de> Die Vietnamesen waren schon immer den anderen Kulturen gegenüber sehr offen und haben sie an ihre eigenen Lebensbedingungen zum Teil angepasst.
<G-vec00095-002-s097><adapt.anpassen><en> Instead, the aim was “to adapt the historically grown structure of the financial assistance programmes to current economic priorities.”
<G-vec00095-002-s097><adapt.anpassen><de> Stattdessen sollte „die über viele Jahre gewachsene Struktur der Förderprogramme an die aktuelle Schwerpunktsetzung der wirtschaftlichen Themen“ angepasst werden.
<G-vec00095-002-s098><adapt.anpassen><en> They're fixed-layout documents — they can't adjust or adapt to different screen sizes.
<G-vec00095-002-s098><adapt.anpassen><de> Es sind Dokumente mit festem Layout — sie können sich weder selbst anpassen, noch an unterschiedliche Bildschirmgrößen angepasst werden.
<G-vec00095-002-s099><adapt.anpassen><en> Due to its modular structure, it was possible to individually adapt the CAQ system to the brand manufacturer’s requirements.
<G-vec00095-002-s099><adapt.anpassen><de> Aufgrund des modularen Aufbaus konnte das CAQ-System individuell an die Anforderungen des Markenherstellers angepasst werden.
<G-vec00095-002-s100><adapt.anpassen><en> The cichlids have evolved to adapt to the lake’s diverse habitats and developed endemic (only existent there) species.
<G-vec00095-002-s100><adapt.anpassen><de> Die Buntbarsche (Cichliden) haben sich im Laufe der Evolution an die verschiedenen Lebensräume des Sees angepasst und endemische (nur dort lebende) Arten ausgebildet.
<G-vec00095-002-s101><adapt.anpassen><en> Easy to understand and user-friendly decision algorithms that can quickly adapt to a new modus operandi of fraudsters.
<G-vec00095-002-s101><adapt.anpassen><de> Leicht verständlicher und anwenderfreundlicher Entscheidungsalgorithmus, der rasch an neue Vorgehensweisen von Betrügern angepasst werden kann.
<G-vec00095-002-s102><adapt.anpassen><en> Since the Software are flexible it is easy to adapt the tools to various needs.
<G-vec00095-002-s102><adapt.anpassen><de> Da die Software flexible ist, kann sie leicht an die speziellen Bedürfnisse angepasst werden.
<G-vec00095-002-s103><adapt.anpassen><en> Accelerator offers the flexibility to adapt Planon innovations and new business processes easily and quickly.
<G-vec00095-002-s103><adapt.anpassen><de> Ist flexibel, um an Innovationen und neue Geschäftsprozesse schnell und einfach angepasst zu werden.
<G-vec00095-002-s104><adapt.anpassen><en> With the development of company, we need more and more talent to join in, and every month will hold a party for fresh, a new welcoming ceremony, which is a fast familiar with and adapt to the company.
<G-vec00095-002-s104><adapt.anpassen><de> Mit der Entwicklung des Unternehmens brauchen wir mehr und mehr Talente, um mitzumachen, und jeden Monat wird eine Party stattfinden, eine neue Begrüßungszeremonie, die schnell vertraut und an das Unternehmen angepasst ist.
<G-vec00095-002-s105><adapt.anpassen><en> With silk screen printing on plastic or metal we can create motives that after the printing on a flat surface of a sheet subsequently “adapt” to the shape of a product.
<G-vec00095-002-s105><adapt.anpassen><de> Mit Siebdruck können wir auch solche Motive schaffen, die sie nach dem Druck auf ebene Bogenfläche an die Artikelform anpassen.
<G-vec00095-002-s106><adapt.anpassen><en> When you access your photo albums or blog with your mobile phone, the text and images will now adapt to the screen size.
<G-vec00095-002-s106><adapt.anpassen><de> Wenn Sie Ihr Fotoalbum oder Blog mit Ihrem Mobiltelefon abrufen, wird sich der Text und die Bilder nun an die Bildschirmgröße anpassen.
<G-vec00095-002-s107><adapt.anpassen><en> HMI developers can simply open these templates in the new visual editor and quickly adapt them to their needs.
<G-vec00095-002-s107><adapt.anpassen><de> Der Visualisierungs-Ersteller kann die Designs einfach im neuen grafischen Editor an die eigenen Bedürfnisse und Vorgaben anpassen.
<G-vec00095-002-s108><adapt.anpassen><en> You can adapt the flash of the EXILIM EX-Z800 to different situations.
<G-vec00095-002-s108><adapt.anpassen><de> Den Blitz der EXILIM EX-Z800 können Sie an unterschiedliche Situationen anpassen.
<G-vec00095-002-s109><adapt.anpassen><en> If a modest portion of these revenues were devoted to helping poor countries adapt to climate change, it would protect the livelihoods of millions of very poor people.
<G-vec00095-002-s109><adapt.anpassen><de> Wenn nur ein geringer Teil dieser Einnahmen an arme Länder geht, damit diese sich dem Klimawandel anpassen können, könnten die Lebengrundlagen Millionen armer Menschen geschützt werden.
<G-vec00095-002-s110><adapt.anpassen><en> Röhlig will also establish its future as an independent family business, able to adapt to changing markets faster than others and expanding its business strongly on a healthy financial basis even in times of weaker economic growth.
<G-vec00095-002-s110><adapt.anpassen><de> Röhlig wird auch seine Zukunft als unabhängiges Familienunternehmen in die Hand nehmen, sich schneller als andere Unternehmen an die Veränderungen auf dem Markt anpassen und nachhaltig auf einer gesunden, finanziellen Grundlage expandieren, auch in schlechten Zeiten.
<G-vec00095-002-s111><adapt.anpassen><en> This innovative, exclusive technology helps Bitdefender Internet Security 2019 adapt to the hardware and software configuration of your system to save computing resources and improve speed and performance.
<G-vec00095-002-s111><adapt.anpassen><de> Bitdefender Photon™ Dank dieser innovativen und einzigartigen Technologie kann sich Bitdefender Total Security Multi-Device 2019 an die Hardware- und Software-Konfiguration Ihres Systems anpassen.
<G-vec00095-002-s112><adapt.anpassen><en> It lets you quickly adapt to changing light conditions and makes cleaning a breeze.
<G-vec00095-002-s112><adapt.anpassen><de> So kannst du dich blitzschnell an wechselnde Lichtbedingungen anpassen und deine Sichtscheiben im Handumdrehen reinigen.
<G-vec00095-002-s113><adapt.anpassen><en> But thanks to our great community of players, we were able to quickly adapt our cheat Boom Beach to the updated game.
<G-vec00095-002-s113><adapt.anpassen><de> Aber dank unserer tollen Spielergemeinschaft konnten wir unseren Cheat Boom Beach schnell an das aktualisierte Spiel anpassen.
<G-vec00095-002-s114><adapt.anpassen><en> Coffee farmers can only maintain or improve the quality and quantity of their yields if they adapt their farming practices to the consequences of global warming.
<G-vec00095-002-s114><adapt.anpassen><de> Kaffeefarmer können die Qualität und Quantität ihrer Erträge nur halten oder verbessern, wenn sie ihre Anbaupraktiken an die Folgen der globalen Erwärmung anpassen.
<G-vec00095-002-s115><adapt.anpassen><en> The variuos geometric modularity both horizontally and vertically made us afraid that it could not adapt to ceramic formats without the introduction of compensating elements, that would have interrupted the modular continuity of the coverage.
<G-vec00095-002-s115><adapt.anpassen><de> Man befürchtete, dass sich die vielfältige geometrische Modularität auf horizontaler als auch auf vertikaler Ebene schlecht an die Keramikformate anpassen könnte, falls keine kompensierenden Elemente eingefügt würden, die jedoch wiederum die modulare Kontinuität der Verkleidung unterbrochen hätten.
<G-vec00095-002-s116><adapt.anpassen><en> Comments If our various types of subscriptions do not adapt to your company needs and you are looking for more, install the encuestafacil.com license, the online survey software number 1 in Europe and Latin America!
<G-vec00095-002-s116><adapt.anpassen><de> Kommentare Wenn sich unsere verschiedene Abonnements nicht an die Bedürfnisse Ihres Unternehmens anpassen und Sie sind auf der Suche nach etwas mehr, installieren Sie eine Lizenz von Einfacheumfrage.de, die Onlineumfragen-Software Nummer 1 in Europa und Lateinamerika.
<G-vec00095-002-s117><adapt.anpassen><en> This innovative, exclusive technology helps Bitdefender Internet Security 2019 adapt to the hardware and software configuration of your system to save computing resources and improve speed and performance.
<G-vec00095-002-s117><adapt.anpassen><de> Bitdefender Photon™ Dank dieser innovativen und einzigartigen Technologie kann sich Bitdefender Internet Security 2019 an die Hardware- und Software-Konfiguration Ihres Systems anpassen.
<G-vec00095-002-s118><adapt.anpassen><en> The newest version of the Cruz kayak has been thought out so that every kayak fisherman can easily adapt their kayak to any fishing style without ever drilling into the hull of this kayak. Recipient:
<G-vec00095-002-s118><adapt.anpassen><de> Die neueste Version des Cruz Kajaks wurde durchdacht, so dass jeder Kajakfischer seine Kajaks problemlos an jeden Fischfang anpassen kann, ohne jemals in den Rumpf dieses Kajaks bohren zu müssen.
<G-vec00095-002-s119><adapt.anpassen><en> Through standardization and attention to software evolution, Woodward’s partners can adapt 1990’s software into today’s advanced control platforms with minimal changes or when none are required.
<G-vec00095-002-s119><adapt.anpassen><de> Durch Standardisierung und Berücksichtigung der Weiterentwicklung der Software können die Partner von Woodward Software aus den 1990er Jahren mit nur geringen oder gar keinen Änderungen an die heutigen fortschrittlichen Steuerplattformen anpassen.
<G-vec00095-002-s120><adapt.anpassen><en> But laboratory head Lass dismisses her objections: “It is not a question of achieving a perfect simulation of reality. Our goal is to be able to adapt our test set-up so that we can explore all the possible issues that interest us in the area of Industry 4.0.”
<G-vec00095-002-s120><adapt.anpassen><de> Unser Ziel ist es, den Versuchsaufbau an alle möglichen Fragestellungen anpassen zu können, die uns im Bereich Industrie 4.0 interessieren.“ Man merkt deutlich: Nicht nur für Arora Chaudha- ry war diese Mischung aus Anwendungsbezogenheit und Grundlagenforschung spannend und neu.
<G-vec00095-002-s121><adapt.anpassen><en> Understanding the geographical differences in coloration may be important to predict how animals adapt to climate change.
<G-vec00095-002-s121><adapt.anpassen><de> Die geografischen Unterschiede in der Färbung sind eine wichtige Grundlage für das Verständnis dafür, wie sich Tiere an klimatische Änderungen anpassen können.
<G-vec00095-002-s122><adapt.anpassen><en> We will adapt all the products to conform to the new CI.
<G-vec00095-002-s122><adapt.anpassen><de> Wir werden nach und nach alle Produkte an das neue CI anpassen.
<G-vec00095-002-s123><adapt.anpassen><en> You should not adapt yourself to the universe.
<G-vec00095-002-s123><adapt.anpassen><de> Du sollst dich nicht an das Universum anpassen.
<G-vec00095-002-s124><adapt.anpassen><en> According to Perrot, these concepts provider users with an easier opportunity to ideally adapt illumination to their utilisation conditions and achieve stable brightness over a longer period of time so that production machines are made more efficient.
<G-vec00095-002-s124><adapt.anpassen><de> Anwendern bieten solche Konzepte laut Perrot eine vereinfachte Möglichkeit, Beleuchtungen optimal an die Einsatzbedingungen anzupassen und über einen langen Zeitraum eine stabile Helligkeit zu erzielen, um Produktionsanlagen somit effizienter zu machen.
<G-vec00095-002-s125><adapt.anpassen><en> All employees are endeavored to apply the rules in their area of responsibility, to monitor their effectiveness continuously and to adapt to the latest knowledge and requirements.
<G-vec00095-002-s125><adapt.anpassen><de> Alle Mitarbeiter/-innen sind bestrebt, die in ihrem Verantwortungsbereich geltenden Regelungen anzuwenden, ihre Wirksamkeit ständig zu überwachen und an die neuesten Kenntnisse und Erfordernisse anzupassen.
<G-vec00095-002-s126><adapt.anpassen><en> We also use your information to adapt the content of our advertising campaigns and our website to your preferences and personal characteristics in the future.
<G-vec00095-002-s126><adapt.anpassen><de> Wir verwenden Ihre Informationen außerdem, um den Inhalt unserer Werbekampagnen und unserer Website zukünftig an Ihre Präferenzen und persönlichen Charakteristika anzupassen.
<G-vec00095-002-s127><adapt.anpassen><en> Ready and progressive answers, easy and intuitive controls, different settings and customizable operating parameters make it possible to adapt the performances to the work to be carried out, enabling thus the maximum operating economy.
<G-vec00095-002-s127><adapt.anpassen><de> Fertige, progressive Antworten, leichte, intuitive Bedienelemente, verschiedene Einstellungen und Betriebsparameter, die individuell eingerichtet werden können, erlauben die Umschlagmaschine an die für die auszuführende Arbeit notwendigen Leistungen anzupassen und damit die bestmögliche Wirtschaftlichkeit im Betrieb zu erzielen.
<G-vec00095-002-s128><adapt.anpassen><en> Therefore, it is high time to adapt our website to the new temicon, so that you can experience what we can achieve for you.
<G-vec00095-002-s128><adapt.anpassen><de> Deshalb ist es an der Zeit unsere Webseite an die neue temicon anzupassen, damit Sie erleben, was wir für Sie verwirklichen können.
<G-vec00095-002-s129><adapt.anpassen><en> The new definition of the need for long-term care must be taken as an opportunity to review staffing levels and adapt them to meet changing needs.
<G-vec00095-002-s129><adapt.anpassen><de> Der neue Pflegebedürftigkeitsbegriff muss somit zum Anlass genommen werden, die Personalausstattung zu überprüfen und an den sich verändernden Bedarf anzupassen.
<G-vec00095-002-s130><adapt.anpassen><en> The best way to create or adapt your website to mobile devices without programming skills.
<G-vec00095-002-s130><adapt.anpassen><de> Die beste Art, Ihre Website ohne Programmierungskenntnisse zu erstellen oder an mobile Geräte anzupassen.
<G-vec00095-002-s131><adapt.anpassen><en> Cookies enable us to gather information on the use of our services and to improve and adapt these services to our visitors’ wishes.
<G-vec00095-002-s131><adapt.anpassen><de> Der Einsatz von Cookies ermöglicht es uns, Informationen über die Nutzung unserer Dienstleistungen zu sammeln und diese zu verbessern und an den Wünschen unserer Besucher anzupassen.
<G-vec00095-002-s132><adapt.anpassen><en> The players take control of a faction that can be shaped by choosing troops, characters and cards that best adapt to their game style. show more show less
<G-vec00095-002-s132><adapt.anpassen><de> Die Spieler übernehmen die Kontrolle über eine Fraktion, die durch die Wahl der Truppen, der Charaktere und der Spielkarten geformt werden kann, um sie an den Spielstil des jeweiligen Spielers anzupassen.
<G-vec00095-002-s133><adapt.anpassen><en> Sport brings the body to convert the motion and energy expenditure muscles and adapt to the demands of the sport.
<G-vec00095-002-s133><adapt.anpassen><de> Sport bringt den Körper dazu, durch die Bewegungsabläufe und den Energieumsatz die Muskulatur umzuformen und an die Anforderungen des Sports anzupassen.
<G-vec00095-002-s134><adapt.anpassen><en> Cardiac syncope occurs either due to a reduction in cardiac output because of arrhythmia or due to the inability of the heart to adapt the heart's function to higher work loads because of heart disease.
<G-vec00095-002-s134><adapt.anpassen><de> Kardiale Synkopen entstehen entweder infolge einer Verminderung der Herzleistung bei Arrhythmie oder infolge einer mangelnden Kapazität des Herzens bei Herzkrankheit, die Herzleistung an einen erhöhten Bedarf anzupassen.
<G-vec00095-002-s135><adapt.anpassen><en> Please help to optimally adapt our shop to your requirements and send us an e-mail with your suggestions.
<G-vec00095-002-s135><adapt.anpassen><de> Bitte helfen Sie mit, unseren Shop optimal an Ihre Bedürfnisse anzupassen und senden Sie uns eine E-Mail mit Ihren Vorschlägen.
<G-vec00095-002-s136><adapt.anpassen><en> As developers and distributors of our own driving simulation solution OpenDS we are able to quickly and inexpensively adapt the software and hardware to meet your specific needs.
<G-vec00095-002-s136><adapt.anpassen><de> Als Entwickler und Vertreiber unserer eigenen Fahrsimulationslösung OpenDS sind wir in der Lage, Software und Hardware schnell und kostengünstig an Ihre spezifischen Bedürfnisse anzupassen.
<G-vec00095-002-s137><adapt.anpassen><en> With of our strong market position in the DACH region and our high qualified specialists, we support our customers by redesigning business models and by helping them to adapt to the sector-specific and regulatory requirements.
<G-vec00095-002-s137><adapt.anpassen><de> Durch unsere starke Marktposition in der DACH Region und mit Hilfe unserer hochqualifizierten Spezialisten, unterstützen wir unsere Kunden dabei ihre Geschäftsmodelle zu überdenken undsich an branchenspezifische und regulatorische Anforderungen anzupassen.
<G-vec00095-002-s138><adapt.anpassen><en> Sow with the Pepperl+Fuchs box thin client portfolio, users can adapt monitoring in the control room to their individual needs.
<G-vec00095-002-s138><adapt.anpassen><de> So haben Anwender mit dem Pepperl+Fuchs Box-Thin-Client-Portfolio die volle Flexibilität, um die Überwachung in der Leitwarte ganz an ihren individuellen Bedarf anzupassen.
<G-vec00095-002-s139><adapt.anpassen><en> Various parameters allow the user to set, among other things, lighting and backgrounds and to adapt them to his model.
<G-vec00095-002-s139><adapt.anpassen><de> Diverse Parameter erlauben es dem Benutzer unter anderem Beleuchtung und Hintergründe einzustellen und an sein Bauteil anzupassen.
<G-vec00095-002-s140><adapt.anpassen><en> The go-to market speed of new products and styles has also created pressure to quickly adapt marketing to digital consumers’ needs.
<G-vec00095-002-s140><adapt.anpassen><de> Neue Akteure, die auf den Markt drängen, und die hohe Geschwindigkeit bei Markteinführungen neuer Produkte und Moden haben den Druck erhöht, das Marketing schnell an die Bedürfnisse der digitalen Verbraucher anzupassen.
<G-vec00095-002-s141><adapt.anpassen><en> Another significant freedom that Free Software guarantees is the freedom to modify the program so as to adapt it to the user's needs and to redistribute copies of the modified version.
<G-vec00095-002-s141><adapt.anpassen><de> Ein weitere wichtige Freiheit, die Freie Software garantiert, ist die Freiheit, das Programm zu modifizieren und an die Bedürfnisse des Nutzers anzupassen und Kopien der modifizierten Version verbreiten zu dürfen.
<G-vec00095-002-s142><adapt.anpassen><en> You can adapt Photoshop to the way you work by selecting from several preset workspaces or by creating one of your own. Home screen
<G-vec00095-002-s142><adapt.anpassen><de> Sie haben auch die Möglichkeit, Illustrator an Ihre spezifische Arbeitsweise anzupassen, indem Sie einen von mehreren vordefinierten Arbeitsbereichen wählen oder Ihren eigenen Arbeitsbereich erstellen.
<G-vec00095-002-s143><adapt.anpassen><en> For correct operation of the motorcycle, it is necessary to adapt the motorcycle electronics to an Aprilia dealer.
<G-vec00095-002-s143><adapt.anpassen><de> Damit das Motorrad einwandfrei funktioniert, muss die Motorradelektronik an einen Aprilia-Händler angepasst werden.
<G-vec00095-002-s144><adapt.anpassen><en> - Text Length: when your text is long, animations adapt so there is more time to read it.
<G-vec00095-002-s144><adapt.anpassen><de> - Textlänge: Wenn dein Text lang ist, werden Animationen angepasst, damit mehr Zeit zum Lesen bleibt.
<G-vec00095-002-s145><adapt.anpassen><en> They now need to work with Member States to keep moving towards flexicurity models which adapt labour markets to a globalised world while giving workers meaningful protection and new opportunities.
<G-vec00095-002-s145><adapt.anpassen><de> Jetzt müssen sie mit den Mitgliedstaaten zusammenarbeiten, um weiterhin Fortschritte bei Modellen der Flexicurity zu erreichen, mit denen die Arbeitsmärkte an eine globalisierte Welt angepasst werden, während gleichzeitig die Arbeitnehmer wirksam geschützt und ihnen neue Möglichkeiten eröffnet werden.
<G-vec00095-002-s146><adapt.anpassen><en> Put your pet’s toys and accessories in the bed, so that the pet can adapt to the new bed ASAP.
<G-vec00095-002-s146><adapt.anpassen><de> Setzen Sie Ihr Haustier Spielzeug und Zubehör im Bett, so dass das Tier an das neue Bett ASAP angepasst werden kann.
<G-vec00095-002-s147><adapt.anpassen><en> Regardless of whether a new building is being planned, an existing building is to undergo a change of purpose, a building's users are exposed to a higher level of danger as a result of changes of some kind, or the general risk situation is becoming more severe – it must be possible to adapt security measures to suit the risks involved, and not the other way round.
<G-vec00095-002-s147><adapt.anpassen><de> Unabhängig davon, ob ein Objekt neu gebaut wird, es eine Nutzungsänderung erfährt, die Nutzer des Gebäudes durch Änderungen jedweder Art einer höheren Gefährdung ausgesetzt sind oder die Gefährdungslage insgesamt höher wird - Sicherheitsmaßnahmen müssen den Risiken angepasst werden können, nicht umgekehrt.
<G-vec00095-002-s148><adapt.anpassen><en> This will adapt the speed to your graphic.
<G-vec00095-002-s148><adapt.anpassen><de> Dadurch wird die Geschwindigkeit an Ihre Grafik angepasst.
<G-vec00095-002-s149><adapt.anpassen><en> Energy consumption of houses: we adapt the heating system to consume less.
<G-vec00095-002-s149><adapt.anpassen><de> Der Energieverbrauch des Gebäudes: Die Heizungssysteme werden angepasst um am wenigsten zu verbrauchen.
<G-vec00095-002-s150><adapt.anpassen><en> For example, a ceiling connector for the overhead shower can be extended in order to adapt it to the architectural features in an old building.
<G-vec00095-002-s150><adapt.anpassen><de> So wird beispielsweise ein Deckenanschluss für die Kopfbrause verlängert und dadurch an die architektonischen Gegebenheiten in einem Altbau angepasst.
<G-vec00095-002-s151><adapt.anpassen><en> For successful embroidery onto active wear, it is essential to adapt the digitising to the fabric, select the correct embroidery thread and choose the right stabiliser to achieve top-quality results.
<G-vec00095-002-s151><adapt.anpassen><de> Um Active Wear erfolgreich zu besticken, muss die Programmierung an den Stoff angepasst, das richtige Stickgarn und einen geeigneten Stabilisator ausgewählt werden - nur so können perfekte Ergebnisse erzielt werden.
<G-vec00095-002-s152><adapt.anpassen><en> "Arctic Marine Governance: Opportunities for Transatlantic Cooperation" looks at the current governance environment in the marine Arctic, considers how policy frameworks can adapt to address new challenges in the region, and examines opportunities for cooperation between the European Union and the United States.
<G-vec00095-002-s152><adapt.anpassen><de> Es befasst sich mit der aktuellen Umwelt-Governance in der marinen Arktis, untersucht, wie politische Rahmenbedingungen an neue Herausforderungen angepasst werden können und prüft Möglichkeiten für die Zusammenarbeit von EU und USA.
<G-vec00095-002-s153><adapt.anpassen><en> A large majority of stakeholders agreed that the general principles remain valid but that there is a need to adapt the current framework in order to better respond to challenges posed by the rapid development of new technologies (particularly online) and increasing globalisation, while maintaining the technological neutrality of the Directive.
<G-vec00095-002-s153><adapt.anpassen><de> Im Zuge der Konsultationen zum Datenschutz-Gesamtkonzept stellte eine breite Mehrheit der Teilnehmer fest, dass die allgemeinen Grundsätze zwar nach wie vor gültig sind, die derzeitige Regelung aber angepasst werden muss, um besser auf die rasante Entwicklung neuer Technologien (vor allem von Online-Technologien) und die zunehmende Globalisierung reagieren zu können.
<G-vec00095-002-s154><adapt.anpassen><en> To increase performance, this Nilfisk can adapt to a wide range of optional accessories.
<G-vec00095-002-s154><adapt.anpassen><de> Um die Leistung zu erhöhen, kann dieser Nilfisk auf eine breite Palette von optionalem Zubehör angepasst werden.
<G-vec00095-002-s155><adapt.anpassen><en> This allows you to adapt studying and learning times flexibly to your individual working hours and personal circumstances.
<G-vec00095-002-s155><adapt.anpassen><de> Somit können die Studien- und Lernzeiten flexibel den individuellen Arbeitszeiten und persönlichen Bedingungen angepasst werden.
<G-vec00095-002-s156><adapt.anpassen><en> This allows us to adapt our teaching to the needs of the students and to design it according to the target group; for example, by offering courses that take different previous knowledge levels or different learning outcomes into account.
<G-vec00095-002-s156><adapt.anpassen><de> Die Lehre kann auf dieser Basis auf die Bedürfnisse der Studierenden angepasst und zielgruppengerechter gestaltet werden, zum Beispiel durch das Angebot von Veranstaltungen, die das unterschiedliche Vorwissen oder unterschiedlichen Lernerfolg berücksichtigen.
<G-vec00095-002-s157><adapt.anpassen><en> Against this background, the opening lecture of the conference examines whether we must rather adapt our ideas of freedom and security to changing technical developments and circumstances.
<G-vec00095-002-s157><adapt.anpassen><de> Der Einführungsvortrag der Konferenz fragt vor diesem Hintergrund, ob stattdessen unsere Vorstellungen von Freiheit und Sicherheit den technischen Entwicklungen und Gegebenheiten angepasst werden müssen.
<G-vec00095-002-s158><adapt.anpassen><en> Our Caregiver Center provides insight on what to expect and how to adapt care during the early, middle and late stages of Alzheimer's disease.
<G-vec00095-002-s158><adapt.anpassen><de> Unser Zentrum für Betreuer vermittelt Ihnen, was Sie erwartet und wie die Pflege im Früh-, Mittel- und Endstadium von Alzheimer angepasst werden muss.
<G-vec00095-002-s159><adapt.anpassen><en> Gisela Waldthaler Moser: "We worked hard, things got better and we were able to expand the hotel and adapt it to meet the new needs.
<G-vec00095-002-s159><adapt.anpassen><de> Wir haben fleißig gearbeitet, die Zeiten wurden immer besser, so konnte das Hotel mehrmals erweitert und den neuen Bedürfnissen angepasst werden.
<G-vec00095-002-s160><adapt.anpassen><en> So the energy management will always automatically adapt to the current situations in the rooms - exact and automatic.
<G-vec00095-002-s160><adapt.anpassen><de> So wird das Energiemanagement immer wieder auf die aktuelle Situationen selbständig angepasst und präzise umgesetzt.
<G-vec00095-002-s161><adapt.anpassen><en> The new software version ensures that SPIDERweb can also in future adapt to new technologies and be further developed.
<G-vec00095-002-s161><adapt.anpassen><de> Die neue Softwareversion stellt sicher, dass SPIDERweb auch in Zukunft den neuen Technologien angepasst und weiterentwickelt werden kann.
<G-vec00095-002-s162><adapt.anpassen><en> With modern consumers going off-piste from carefully crafted buying journeys, it’s the marketer who is able to adapt quickly who will reap the rewards.
<G-vec00095-002-s162><adapt.anpassen><de> Da die modernen Kunden sich von einer sorgfältig gestalteten Einkaufsreise wegbewegen, ist es der Marketer, der sich schnell anpassen kann, der die Früchte seiner Arbeit ernten wird.
<G-vec00095-002-s163><adapt.anpassen><en> So you can continue to deploy complex contact center technologies, transform your enterprise contact centers, and adapt your processes to meet the expectations of your customers.
<G-vec00095-002-s163><adapt.anpassen><de> So können Sie komplexe Kontakt-Center-Technologien bereitstellen, Ihre Enterprise-Kontakt-Center transformieren und Ihre Prozesse an die Erwartungen Ihrer Kunden anpassen.
<G-vec00095-002-s164><adapt.anpassen><en> Reviews Hotel in Puerto de Soller, Mallorca The reviews and opinions about the Soller Bay Hotel by Ona Hotels allow us to get to know our guests and to adapt our services to their needs.
<G-vec00095-002-s164><adapt.anpassen><de> Dank der Kommentare und Meinungen über das Soller Bay Hotel by Ona Hotels, die uns unsere Gäste geschrieben haben, können wir die Wünsche der einzelnen Reisenden besser verstehen und unsere Serviceleistungen ihrem Bedarf anpassen.
<G-vec00095-002-s165><adapt.anpassen><en> In the same way you can of course also adapt something like the Ella dress.
<G-vec00095-002-s165><adapt.anpassen><de> Auf die gleiche Weise könnt ihr natürlich auch das Kleid "Ella CLASSIC" anpassen.
<G-vec00095-002-s166><adapt.anpassen><en> Parallel Sysplex enables an expanding infrastructure to be an effective, resilient foundation that can adapt to new technologies and support opportunities for growth.
<G-vec00095-002-s166><adapt.anpassen><de> “Parallel Sysplex” formt eine wachsende Infrastruktur zu einer effektiven, belastbaren Basis, die sich neuen Technologien anpassen kann und Wachstumschancen fördert.
<G-vec00095-002-s167><adapt.anpassen><en> To secure your data, we maintain technical and organizational security measures, which we continually adapt to the state of the art.
<G-vec00095-002-s167><adapt.anpassen><de> Zur Sicherung Ihrer Daten unterhalten wir technische- und organisatorische Sicherungsmaßnahmen, die wir immer wieder dem Stand der Technik anpassen.
<G-vec00095-002-s168><adapt.anpassen><en> The Schilli Implantology Circle around Prof. Dr. Wilfried Schilli has always been able to adapt its scientific experience in ordinary clinical practice to the demands of modern implant therapy.
<G-vec00095-002-s168><adapt.anpassen><de> Der Schilli Implantology Circle um Prof. Dr. Wilfried Schilli hat seine wissenschaftliche Erfahrung permanent im klinischen Alltag den Erfordernissen der modernen Implantattherapie anpassen können.
<G-vec00095-002-s169><adapt.anpassen><en> The increase in volatility is sight for sore eyes for most Forex traders, but this also means we need to adapt our trading technique to match these changes.
<G-vec00095-002-s169><adapt.anpassen><de> Die Volatilitätszunahme dürfte viele Forex Trader erleichtert aufatmen lassen, aber dies bedeutet auch, dass wir unsere Tradingtechnik diesen Veränderungen anpassen müssen.
<G-vec00095-002-s170><adapt.anpassen><en> A minority must only be sufficiently persistent, then the majorities would already adapt: see gender talk, vegetarian or kosher food offers, narrow ties and short confirmation jackets (which were actually enforced by ONE Tagesschau-anchorman, Jens Riewa) or the wearing of beards.
<G-vec00095-002-s170><adapt.anpassen><de> Es müsse eine Minderheit nur genügend hartnäckig sein, dann würden sich die Mehrheiten schon anpassen: siehe Gendertalk, vegetarische oder koschere Speiseangebote, schmale Kravatten und kurze Konfirmandensakkos (die tatsächlich von EINEM Tagesschausprecher, Jens Riewa, durchgesetzt worden sind) oder das Tragen von Bärten.
<G-vec00095-002-s171><adapt.anpassen><en> We have to be realistic, Spain is different but is no longer what it was, our role is changing and we must know how to adapt to our new position and accept that they are ahead of other countries that have not suffered so much the crisis I that have been most effective and Chameleon to follow later, our congratulations to countries such as Turkey and China which have taken advantage of new technologies in our country to deal with the fees of market that we are leaving free.
<G-vec00095-002-s171><adapt.anpassen><de> Wir müssen realistisch sein, Spanien ist anders, aber ist nicht mehr das, was es war, unsere Rolle verändert sich und wir müssen wissen, wie unsere neue Position anpassen und akzeptieren, dass sie vor anderen Staaten, die nicht so sehr die Krise erlitten haben, I, die effektivste und Chamäleon später unsere Glückwünsche an Länder wie die Türkei und China zu folgen, die in unserem Land zur Bewältigung der neuen Technologien ausgenutzt haben die Gebühren des Marktes, die wir frei verlassen.
<G-vec00095-002-s172><adapt.anpassen><en> You can therefore adapt your plan to suit your needs without permanently hiking up your bill.
<G-vec00095-002-s172><adapt.anpassen><de> So können Sie Ihr Paket ohne dauerhafte Bindung an Ihren Bedarf anpassen.
<G-vec00095-002-s173><adapt.anpassen><en> A unique world is generated each time a new level starts, so you will need to dynamically adapt your strategies and tactics during each session.
<G-vec00095-002-s173><adapt.anpassen><de> Bei jedem Start eines neuen Levels wird eine einzigartige Welt generiert, weswegen Sie Ihre Strategien und Taktiken während jeder Sitzung dynamisch anpassen müssen.
<G-vec00095-002-s174><adapt.anpassen><en> This allows the driver to adapt the working result to different soil types or varying conditions in the field.
<G-vec00095-002-s174><adapt.anpassen><de> Der Fahrer kann dadurch das Arbeitsergebnis an verschiedene Bodenarten oder variierende Bedingungen im Feld anpassen.
<G-vec00095-002-s175><adapt.anpassen><en> Here, you can learn how we adapt our solutions to your needs.
<G-vec00095-002-s175><adapt.anpassen><de> Hier erfahren Sie, wie wir unsere Dienstleistung an Ihre Anforderungen anpassen.
<G-vec00095-002-s176><adapt.anpassen><en> Furthermore, you've also got the possibility to customize how the notifications counter will be shown next to the icons of your application tray, being able to modify and adapt the size and color of the badge.
<G-vec00095-002-s176><adapt.anpassen><de> Außerdem haben Sie auch die Möglichkeit, individuell einzurichten, wie der Benachrichtigungszähler neben den Icons Ihres Anwendungsbereichs gezeigt wird, wobei Sie die Größe und die Farbe des Kennzeichens ändern und anpassen können.
<G-vec00095-002-s177><adapt.anpassen><en> You’ll obviously have to adapt based on your partner’s responses, but that may help keep you on track if you’re nervous about talking on the phone.
<G-vec00095-002-s177><adapt.anpassen><de> Offensichtlich musst du dich an die Antworten des Gesprächspartners anpassen, aber eine Reihung kann hilfreich sein, um dich auf dem richtigen Weg zu halten, wenn du während des Telefonats nervös wirst.
<G-vec00095-002-s178><adapt.anpassen><en> Assess, Adapt, and Attack – Crysis’s highly-acclaimed sandbox gameplay is back with more open levels to let players choose their path and approach.
<G-vec00095-002-s178><adapt.anpassen><de> Abschätzen, anpassen und angreifen – Das gefeierte Sandbox-Gameplay von Crysis ist wieder da, mit noch mehr offenen Leveln, in denen Spieler ihren Weg und ihre Spielweise selbst bestimmen können.
<G-vec00095-002-s179><adapt.anpassen><en> Access your data at any time using the variety of standard reports which you can adapt easily to suit your needs. Fiscal year statistics
<G-vec00095-002-s179><adapt.anpassen><de> Greifen Sie jederzeit auf Ihre Daten zu und nutzen Sie die Vielzahl der Standardauswertungen, welche Sie ohne großen Aufwand an Ihre Bedürfnisse anpassen können.
<G-vec00095-002-s180><adapt.anpassen><en> We may adapt this data privacy policy at any time without prior notice.
<G-vec00095-002-s180><adapt.anpassen><de> Wir können diese Datenschutzerklärung jederzeit ohne Vorankündigung anpassen.
<G-vec00095-002-s181><adapt.anpassen><en> Here you will find a selection of modern accessories that allow you to adapt the vehicle interior to your style.
<G-vec00095-002-s181><adapt.anpassen><de> Hier finden Sie eine Auswahl moderner Accessoires, mit denen Sie den Fahrzeuginnenraum an Ihren Stil anpassen können.
<G-vec00095-002-s182><adapt.anpassen><en> Interactions with our websites are tracked using cookies and the technologies specified below in order to adapt them for you.
<G-vec00095-002-s182><adapt.anpassen><de> Interaktionen mit unseren Internetseiten werden mithilfe von Cookies und den nachfolgend genannten Technologien nachverfolgt, um diese für Sie anpassen zu können.
<G-vec00095-002-s183><adapt.anpassen><en> Technical Cookies: to offer you a cutting edge and easy to use website, we use technical cookies to adapt it to your needs.
<G-vec00095-002-s183><adapt.anpassen><de> Technische Cookies: um Ihnen eine bedienungsfreundliche und effektive Website anzubieten, verwenden wir technische Cookies, damit wir sie Ihren Bedürfnissen anpassen können.
<G-vec00095-002-s184><adapt.anpassen><en> This website uses anonymous cookies in order to adapt the website in the best possible way to the needs of our visitors.
<G-vec00095-002-s184><adapt.anpassen><de> Diese Website setzt anonymisierte Cookies ein, um die Webseite bestmöglich an die Bedürfnisse unserer Besucher anpassen zu können.
<G-vec00095-002-s185><adapt.anpassen><en> In order to adapt the size of the block site of the expansion of the fabric 7, it is advantageous when the balloon 5 is not rigid-as indicated in figure 1 - but slidably disposed on the treatment catheter.
<G-vec00095-002-s185><adapt.anpassen><de> Um die Größe der Blockadestelle der Ausdehnung des Gewebes 7 anpassen zu können, ist es von Vorteil, wenn der Ballon 5 nicht starr- wie in Figur 1 angedeutet - sondern auf dem Behandlungskatheter 1 verschiebbar angeordnet ist.
<G-vec00095-002-s186><adapt.anpassen><en> The apple growers will receive up to date and timely information that will allow them to adapt their plant protection accordingly.
<G-vec00095-002-s186><adapt.anpassen><de> Die Apfelproduzenten erhalten die Ergebnisse zeitnah, sodass sie ihren Pflanzenschutz entsprechend anpassen können.
<G-vec00095-002-s187><adapt.anpassen><en> Finally, the application can synchronize with a large variety of devices, letting you adapt your multimedia contents for the device you want.
<G-vec00095-002-s187><adapt.anpassen><de> Schließlich kann die Anwendung mit einer Vielzahl von Geräten synchronisiert werden, sodass Sie Ihre Multimedia-Inhalte auf das gewünschte Gerät anpassen können.
<G-vec00095-002-s188><adapt.anpassen><en> The aim of ATOSS Workforce Management is to deploy the existing personnel capacity more intelligently and give companies the ability at all times to adapt quickly and flexibly to changing framework conditions without losing sight of employees' interests.
<G-vec00095-002-s188><adapt.anpassen><de> Das Ziel von ATOSS Workforce Management ist es, die vorhandenen Personalkapazitäten intelligenter einsetzen und jederzeit schnell und agil an sich ändernde Rahmenbedingungen anpassen zu können, ohne dabei die Interessen der Mitarbeiter aus den Augen zu verlieren.
<G-vec00095-002-s189><adapt.anpassen><en> This website uses anonymous cookies in order to adapt the website in the best possible way to the needs of our visitors.
<G-vec00095-002-s189><adapt.anpassen><de> DATENSCHUTZ SITEMAP Diese Website setzt anonymisierte Cookies ein, um die Webseite bestmöglich an die Bedürfnisse unserer Besucher anpassen zu können.
<G-vec00095-002-s190><adapt.anpassen><en> It should be completed and send to us a month before the start of the course. The tutors will adapt the contents to the interests of the participants.
<G-vec00095-002-s190><adapt.anpassen><de> Dieser Fragebogen muss ein Monat im Voraus ausgefüllt und zurück gesendet werden, damit die Kursleiter die Unterrichtsinhalte den Interessen der Teilnehmer anpassen können.
<G-vec00095-002-s191><adapt.anpassen><en> In particular, the text calls for the establishment of a specific European policy framework to deal with the problems that these areas face in order to enable them to better overcome the permanent disadvantages and to adapt their development model by making the most of all their assets.
<G-vec00095-002-s191><adapt.anpassen><de> Der Text verlangt insbesondere die Errichtung eines spezifischen europäischen Handlungsrahmens für den Umgang mit den Problemen dieser Regionen, damit diese ihre dauerhafte Benachteiligung besser bewältigen und ihr Entwicklungsmodell anpassen können, um das Beste aus ihren Vorteilen zu machen.
<G-vec00095-002-s192><adapt.anpassen><en> The integrated tilt function of the solid Wall Mount PDW T XL which provides the flexibility that is needed to adapt the screen installation to the individual requirements existing for each MDT room.
<G-vec00095-002-s192><adapt.anpassen><de> Die integrierte Neigefunktion der festen Wandhalterung PDW T XL sorgt für die nötige Flexibilität, um die Bildschirminstallation an die jeweiligen Anforderungen jedes radiologischen Besprechungsraums anpassen zu können.
<G-vec00095-002-s193><adapt.anpassen><en> We use cookies in order to adapt our websites to your needs.
<G-vec00095-002-s193><adapt.anpassen><de> Wir verwenden Cookies, um unsere Webseiten an Ihre Bedürfnisse anpassen zu können.
<G-vec00095-002-s194><adapt.anpassen><en> Equally important, though, is that we organise to make our governments and businesses take the bold action needed to prevent the truly catastrophic effects of climate change, the effects that are impossible to adapt to.
<G-vec00095-002-s194><adapt.anpassen><de> Genauso wichtig ist es jedoch, dass wir uns zusammenschließen, um unsere Regierungen und Firmen dazu bringen, die mutigen Taten zu setzen, die nötig sind, um die wirklich katastrophalen Auswirkungen des Klimawandels zu vermeiden, die Folgen, an die wir uns unmöglich anpassen können.
<G-vec00095-002-s195><adapt.anpassen><en> For this purpose, the software tools developed within the project will be made available in open source, enabling other research institutions with media archives to benefit from the person lexicon, concept lexicon and visualisation techniques, and to adapt them to their own needs with little effort.
<G-vec00095-002-s195><adapt.anpassen><de> Zu diesem Zweck werden die entwickelten Softwarewerkzeuge in Form von Open Source zur Verfügung gestellt, sodass auch andere Forschungseinrichtungen mit Medienarchiven von den Algorithmen zur Personen- und Konzepterkennung sowie den Visualisierungstechniken profitieren und diese mit geringem Aufwand für eigene Zwecke anpassen können.
<G-vec00095-002-s196><adapt.anpassen><en> This collection of data points out the browsers used in order to adapt the website accordingly.
<G-vec00095-002-s196><adapt.anpassen><de> Diese Datenerhebung zeigt uns, welche Browser eingesetzt werden, damit wir unsere Website entsprechend anpassen können.
<G-vec00095-002-s197><adapt.anpassen><en> The session cookie records what parts of the website are looked at during a visit, and that allows us to adapt our website accordingly.
<G-vec00095-002-s197><adapt.anpassen><de> Das Sitzungs-Cookie erfasst, welche Bereiche der Website bei einem Besuch betrachtet werden, sodass wir die Website daran anpassen können.
<G-vec00095-002-s198><adapt.anpassen><en> The first section of each tool explains what problems (see Step 1) the instruments are appropriate for, and the following sections explain how to adapt them to context. 2.2.3.2
<G-vec00095-002-s198><adapt.anpassen><de> Im ersten Abschnitt jedes Werkzeugs wird erklärt, für welche Probleme (siehe Schritt 1) die Instrumente geeignet sind, die folgenden Abschnitte erklären Ihnen, wie Sie die Instrumente an Ihren Kontext anpassen können.
<G-vec00095-002-s250><adapt.anpassen><en> Cookies also enable us to adapt our website to your specific requirements.
<G-vec00095-002-s250><adapt.anpassen><de> Darüber hinaus erlauben uns Cookies, unsere Websites an Ihre speziellen Anforderungen anzupassen.
<G-vec00095-002-s251><adapt.anpassen><en> Companies of all sizes must adapt their cyber security strategies. Read more
<G-vec00095-002-s251><adapt.anpassen><de> Diese Entwicklung des Cybercrime zwingt Unternehmen aller Größen dazu, ihre Cybersecurity-Strategien anzupassen.
<G-vec00095-002-s252><adapt.anpassen><en> Selection of impulse pipes and sampling lines for water and steam sectors in thermal This VGB-Standard was created to adapt the design of measurement and analytical/ discharge lines to the increased steam parameters and the updated long-term parameters.
<G-vec00095-002-s252><adapt.anpassen><de> Steuern: 166,60 € Kurzbeschreibung Dieser VGB-Standard wurde aufgestellt, um die Auslegung von Mess- und Analyse-/ Entnahmeleitungen an die erhöhten Dampfparameter und die aktualisierten Zeitstandkennwerte anzupassen.
<G-vec00095-002-s253><adapt.anpassen><en> And, Gen10 servers can improve your customers’ business agility by making it easy to adapt their IT quickly to changing requirements with Intelligent System Tuning, HPE Persistent Memory, and server networking and storage advances.
<G-vec00095-002-s253><adapt.anpassen><de> Gen10 Server verhelfen Ihnen zu mehr Agilität und ebnen Ihnen den Weg, um Ihre IT mit Intelligent System Tuning, HPE Persistent Memory, Server Networking und innovativem Storage schnell an sich ändernde Anforderungen anzupassen.
<G-vec00095-002-s254><adapt.anpassen><en> Continuity also requires being available and the ability to modify and adapt our help in time according to the changing situation of the elderly.
<G-vec00095-002-s254><adapt.anpassen><de> Kontinuität erfordert Verfügbarkeit und die Fähigkeit, unsere Hilfe zu modifizieren und der Zeit anzupassen, in Beziehung zur veränderten Situation des alten Menschen.
<G-vec00095-002-s255><adapt.anpassen><en> Over the years the company has shown its ability to adapt itself not only to the varying market conditions but most of all to the increasing customers’ demands on quality, accuracy and reliability of supplied machines.
<G-vec00095-002-s255><adapt.anpassen><de> Im Verlauf der Jahre hat die Gesellschaft ihre Fähigkeit gezeigt, sich nicht nur an die wechselnden Marktbedingungen aber vor allem an die immer steigenden Kundenansprüche an Qualität, Genauigkeit und Zuverlässigkeit der gelieferten Maschinen anzupassen.
<G-vec00095-002-s256><adapt.anpassen><en> We use special test methods to adapt the profile form within the degrees of freedom (provided by the individual polymers) perfectly to each customer requirement with absolute repeat accuracy.
<G-vec00095-002-s256><adapt.anpassen><de> Dabei stehen uns spezielle Prüfmethoden zur Verfügung, um die Profilform innerhalb der Freiheitsgrade (welche die einzelnen Polymere uns bieten) für jeden Kundenbedarf wiederholgenau anzupassen.
<G-vec00095-002-s257><adapt.anpassen><en> The customer is obliged to produce the necessary technical requirements both in terms of hardware and software and, if necessary, to constantly adapt them during the contract period.
<G-vec00095-002-s257><adapt.anpassen><de> Der Kunde ist verpflichtet die erforderlichen technischen Voraussetzungen sowohl hinsichtlich Hard- als auch Software herzustellen und sofern erforderlich auch während der Vertragslaufzeit ständig anzupassen.
<G-vec00095-002-s258><adapt.anpassen><en> 4. The Commission shall be empowered to adopt delegated acts in accordance with Article 103 to adapt the methodology set out in the second subparagraph of paragraph 1 of this Article to any change in the methodology provided in the GPA for the revision of the thresholds referred to in points (a) and (b) of Article 15 and for the determination of the corresponding values in the national currencies of the Member States, whose currency is not the euro, as referred to in paragraph 2 of this Article.
<G-vec00095-002-s258><adapt.anpassen><de> (4) Der Kommission wird die Befugnis übertragen, delegierte Rechtsakte gemäß Artikel 48 zu erlassen, um die in Absatz 1 Unterabsatz 2 des vorliegenden Artikels genannte Methode an jede Änderung der im GPA vorgesehenen Methode anzupassen und so den in Artikel 8 Absatz 1 genannten Schwellenwert neu festzusetzen und den Gegenwert gemäß Absatz 2 in den nationalen Währungen der Mitgliedstaaten, deren Währung nicht der Euro ist, festzulegen.
<G-vec00095-002-s259><adapt.anpassen><en> Today, with the electric vehicle, the opportunity arises to adapt the car to the actual needs.
<G-vec00095-002-s259><adapt.anpassen><de> Heute entsteht mit dem elektrobetriebenen Fahrzeug die Chance, das Auto dem tatsächlichem Bedarf anzupassen.
<G-vec00095-002-s260><adapt.anpassen><en> As we did long ago, we renew the recommendation to adapt your website for mobile devices in the near future.
<G-vec00095-002-s260><adapt.anpassen><de> Wie wir schon vor längerer Zeit gemacht haben, erneuern wir die Empfehlung in nächster Zukunft Ihre Webseite für Mobilgeräte anzupassen.
<G-vec00095-002-s261><adapt.anpassen><en> The purpose of the Redmine implementation service is to adapt the software to the clients' projects and processes and deliver maximum value from Easy Redmine.
<G-vec00095-002-s261><adapt.anpassen><de> Der Zweck des Redmine-Implementierungsservice ist es, die Software an die Projekte und Prozesse der Kunden anzupassen und den maximalen Wert durch Easy Redmine zu liefern.
<G-vec00095-002-s262><adapt.anpassen><en> So it is sensible to pull the lessons of it to adapt them through precise actions to improve the quality and the harmony of the environment.
<G-vec00095-002-s262><adapt.anpassen><de> Deshalb ist es vernünftig, die Lehren davon zu ziehen, um sie durch präzise Handlungen anzupassen, um die Qualität und die Harmonie der Umgebung zu verbessern.
<G-vec00095-002-s263><adapt.anpassen><en> Cookies allow us to adapt a website to your interests, for example, or to save your password so that you do not have to enter it every time you visit the site.
<G-vec00095-002-s263><adapt.anpassen><de> Cookies erlauben es beispielsweise, eine Website Ihren Interessen anzupassen oder Ihr Kennwort zu speichern, damit Sie es nicht jedes Mal neu eingeben müssen.
<G-vec00095-002-s264><adapt.anpassen><en> The legitimate interest that we pursue when processing data is to optimise the website settings for the device you are using and to adapt the user interface accordingly.
<G-vec00095-002-s264><adapt.anpassen><de> Unser berechtigtes Interesse an der Datenverarbeitung liegt dabei darin, die Website-Einstellungen für das von Ihnen verwendete Endgerät zu optimieren und die Benutzeroberflächen anzupassen.
<G-vec00095-002-s265><adapt.anpassen><en> As riding is a life-style, Harcour designs each year 2 collections in limited edition and dedicated to the equestrian world to adapt riders' everyday life and to offer them products with eye-appeal that are both fashion & up-to-date.
<G-vec00095-002-s265><adapt.anpassen><de> Da Reiten ein Lebensstil ist, entwirft Harcour jedes Jahr 2 Kollektionen in limitierter Auflage und widmet sich der Pferdesportwelt, um diese dem Alltag der Reiter anzupassen und ihnen Produkte anzubieten, die sowohl modisch als auch zeitgemäß sind.
<G-vec00095-002-s266><adapt.anpassen><en> gedacht. Selection of impulse pipes and sampling lines for water and steam sectors was created to adapt the design of measurement and analytical/ discharge lines to the increased steam parameters and the updated long-term parameters.
<G-vec00095-002-s266><adapt.anpassen><de> Auswahl von Mess- und Probenahmeleitungen für die Wasser- und Dampfbereiche im Wärmekraftwerk - Dieser VGB-Standard wurde aufgestellt, um die Auslegung von Mess- und Analyse-/ Entnahmeleitungen an die erhöhten Dampfparameter und die aktualisierten Zeitstandkennwerte anzupassen.
<G-vec00095-002-s267><adapt.anpassen><en> Its existence relies upon the right for an author to release their software along with the source code, and to grant everyone the right to use, copy, adapt and redistribute it, in its original or in a modified form.
<G-vec00095-002-s267><adapt.anpassen><de> Die Existenz Freier Software verlässt sich auf das Recht eines Autors seine Software zusammen mit dem Quellcode zu veröffentlichen, und jedem das Recht zu gewähren, sie zu nutzen, zu kopieren, anzupassen und weiter in ihrer originalen oder veränderten Form zu verbreiten.
<G-vec00095-002-s268><adapt.anpassen><en> Smoobu shall be entitled to modify and adapt the content of its services, including the software provided, in the context of user-related, technological or substantive further developments, provided that the agreed functionalities of the software are not substantially restricted thereby.
<G-vec00095-002-s268><adapt.anpassen><de> Smoobu ist berechtigt, den Inhalt seiner Leistungen einschließlich der bereitgestellten Software im Rahmen von nutzeroberflächenbezogenen, technologischen oder inhaltlichen Weiterentwicklungen zu verändern und anzupassen, sofern die vereinbarten Funktionalitäten der Software hierdurch nicht wesentlich eingeschränkt werden.
<G-vec00095-002-s269><adapt.anpassen><en> In order to adapt the market, R&D department continuously makes efforts on the technology innovation,and pattern of new products.
<G-vec00095-002-s269><adapt.anpassen><de> Um den Markt anzupassen, bemüht sich die Forschungs- und Entwicklungsabteilung kontinuierlich um technologische Innovationen und Muster neuer Produkte.
<G-vec00095-002-s270><adapt.anpassen><en> A key challenge in the years to come will be to adapt employment and social policies to better meet the rapidly evolving labour-market needs generated by the digital economy.
<G-vec00095-002-s270><adapt.anpassen><de> Eine wesentliche Herausforderung in den kommenden Jahren wird darin bestehen, die Beschäftigungs- und Sozialpolitik anzupassen, um sich den von der Digitalwirtschaft geschaffenen Bedürfnissen des sich schnell entwickelnden Arbeitsmarktes gerecht zu werden.
<G-vec00095-002-s271><adapt.anpassen><en> Therefore, the objective of this Regulation is to adapt the harmonised legal framework on copyright and related rights and to provide a common approach to the provision of online content services to subscribers temporarily present in a Member State other than their Member State of residence by removing barriers to cross-border portability of online content services which are lawfully provided.
<G-vec00095-002-s271><adapt.anpassen><de> Das Ziel dieser Verordnung ist daher, den harmonisierten Rechtsrahmen zum Schutz des Urheberrechts und der verwandten Schutzrechte anzupassen und ein gemeinsames Konzept für die Bereitstellung von Online-Inhaltediensten für Abonnenten, die sich vorübergehend in einem anderen Mitgliedstaat als ihrem Wohnsitzmitgliedstaat aufhalten, zu schaffen, indem die Hindernisse für die grenzüberschreitende Portabilität von Online-Inhaltediensten, die rechtmäßig erbracht werden, beseitigt werden.
<G-vec00095-002-s272><adapt.anpassen><en> For existing hotels their owners and particularly their operators are forced to respond even faster and adapt the structures, as competition in the hotel sector has intensified within the last few years and the market environment is permanently developing further. Under the heading of ‘MICE’ and wellness
<G-vec00095-002-s272><adapt.anpassen><de> Bei bereits bestehenden Hotels sind die Eigentümer und vor allem die Hotelbetreiber gezwungen, immer schneller zu reagieren und die Strukturen anzupassen, da sich in den letzten Jahren nicht nur der Wettbewerb in der Hotelbranche zunehmend verschärft hat sondern sich auch das Marktumfeld ständig weiterentwickelt.
<G-vec00095-002-s273><adapt.anpassen><en> Confronted with poetry of such an individual nature, and in order to adapt it to their own culturel horizon, the interpreters tried to translate the sentences into the terms of a collective truth.
<G-vec00095-002-s273><adapt.anpassen><de> Angesichts einer so stark individuell bestimmten Lyrik, und um sie dem eigenen Erwartungshorizont anzupassen, bemühten sich die Interpreten um eine Übersetzung in die Kategorien einer kollektiven Wahrheit.
<G-vec00095-002-s274><adapt.anpassen><en> In order to adapt the market, R & D department continuously makes efforts on the technologyinnovation,and pattern of new products.
<G-vec00095-002-s274><adapt.anpassen><de> Um den Markt anzupassen, bemüht sich die Forschungs- und Entwicklungsabteilung kontinuierlich um die technologische Innovation und das Muster neuer Produkte.
<G-vec00095-002-s275><adapt.anpassen><en> In so doing, policy fails to concentrate its efforts on qualitative changes in industry and society – changes that take account of local conditions and aim to adapt global trade and industry so that they remain within planetary boundaries.
<G-vec00095-002-s275><adapt.anpassen><de> Damit stellt die internationale Klimapolitik nicht qualitative Veränderungen von Wirtschaft und Gesellschaft in den Mittelpunkt ihrer Bemühungen - Veränderungen, die lokale Besonderheiten berücksichtigen und darauf abzielen, globales Wirtschaften so anzupassen, dass es sich in die natürlichen Grenzen des Planeten einfügt.
<G-vec00095-002-s276><adapt.anpassen><en> In addition, it is possible to adapt the jet types to your personal needs, so that they can be adjusted to the respective mood.
<G-vec00095-002-s276><adapt.anpassen><de> Zusätzlich besteht die Möglichkeit, die Strahlarten dem persönlichen Bedürfnis anzupassen, so dass diese sich auf die jeweilige Stimmung einstellen lässt.
<G-vec00095-002-s277><adapt.anpassen><en> The Ark Foundation, through its Accelerator service, will enable the researchers from Martigny to adapt their algorithms for integration into a bracelet, where they can be used to identify the veins of the wrist.
<G-vec00095-002-s277><adapt.anpassen><de> Die Stiftung The Ark wird es den Forschern von Martinach über ihre Dienstleistung Accelerator ermöglichen, ihre Algorithmen anzupassen, damit sie sich in ein Armband integrieren lassen und mit einer Identifizierung der Venen des Handgelenks kompatibel sind.
<G-vec00095-002-s278><adapt.anpassen><en> These developments not only testify to the outstanding work of the Office and our staff, but they are also indicative of persistent trends that have led the EPO to adapt services, procedures and, last year, our internal structure to respond to a rapidly evolving international patent system with a growing number of important actors among which the EPO needs to secure its position.
<G-vec00095-002-s278><adapt.anpassen><de> Diese Entwicklungen zeugen nicht nur von der herausragenden Arbeit des Amts und seiner Bediensteten, sondern auch von dauerhaften Trends, die das EPA veranlasst haben, Dienstleistungen, Verfahren und unlängst auch seine interne Struktur an das rasch veränderliche internationale Patentsystem anzupassen, in dem es sich gegen immer mehr wichtige Akteure behaupten muss.
<G-vec00095-002-s296><adapt.anpassen><en> Adapt your game accordingly.
<G-vec00095-002-s296><adapt.anpassen><de> Passe dein Spiel an.
<G-vec00095-002-s297><adapt.anpassen><en> I easily adapt myself to changes.
<G-vec00095-002-s297><adapt.anpassen><de> Ich passe mich leicht Veränderungen an.
<G-vec00095-002-s298><adapt.anpassen><en> I adapt the energy in the form of carbohydrates to the intensity and the training intention.
<G-vec00095-002-s298><adapt.anpassen><de> Die Energie in der Form von Kohlenhydraten passe ich der Intensität und der Trainingsabsicht an.
<G-vec00095-002-s299><adapt.anpassen><en> I adapt my looks and clothes to the corporate identity of your company: I can be the stewardess who gives safety instructions.
<G-vec00095-002-s299><adapt.anpassen><de> Ich passe mein Aussehen und meine Kleidung der Corporate Identity deines Unternehmens an: Ich kann die Stewardess sein, die Sicherheitsanweisungen gibt.
<G-vec00095-002-s300><adapt.anpassen><en> You can even adjust it: Adapt it to the length of your rain barrel, in order to lead the water without loss and kinking over the barrel edge.
<G-vec00095-002-s300><adapt.anpassen><de> Dieses ist sogar verstellbar: Passe es auf die geeignete Länge zu Deinem Regenfass an, um das Wasser verlustarm und knickfrei über den Fassrand zu führen.
<G-vec00095-002-s301><adapt.anpassen><en> TA: Generally, I tend to adapt my style to the story.
<G-vec00095-002-s301><adapt.anpassen><de> Ich passe meine Zeichnungen generell dem Szenario an.
<G-vec00095-002-s302><adapt.anpassen><en> Adapt your deck, evolve your strategy and prepare to die as you try to defeat your enemies.
<G-vec00095-002-s302><adapt.anpassen><de> Passe deinen Kartensatz an, entwickle deine Strategie und blicke dem Tod ins Auge, während du deine Gegner besiegst.
<G-vec00095-002-s303><adapt.anpassen><en> Carry Diana with different straps and adapt them to your personal style.
<G-vec00095-002-s303><adapt.anpassen><de> Kombiniere Diana mit verschiedenen Riemen und passe sie deinem persönlichen Style an.
<G-vec00095-002-s304><adapt.anpassen><en> Adapt your Tutanota account to all your professional needs.
<G-vec00095-002-s304><adapt.anpassen><de> Passe Tutanota auf alle Bedürfnisse deines Unternehmens an.
<G-vec00095-002-s305><adapt.anpassen><en> Select the level you want to be challenged at and adapt the game to your style with two levels of difficulty: Keen detective and Master sleuth.
<G-vec00095-002-s305><adapt.anpassen><de> Schwierigkeitsstufen Wähle die Schwierigkeit, die du möchtest, und passe mithilfe dieser zwei Schwierigkeitsstufen das Spiel an deinen Stil an: Aufstrebender Detektiv und Meisterdetektiv.
<G-vec00095-002-s306><adapt.anpassen><en> + With my element system (basic and extension) I adapt exactly to your room – even around corners.
<G-vec00095-002-s306><adapt.anpassen><de> + Mit meinem Element-System (Grund- und Anbau) passe ich mich genau deinem Raum an – sogar über Eck.
<G-vec00095-002-s307><adapt.anpassen><en> Combine our different frames and table tops and adapt them to your ideas.
<G-vec00095-002-s307><adapt.anpassen><de> Gestalte unsere unterschiedlichen Gestelle und Tischplatten und passe sie an Deine Vorstellungen an.
<G-vec00095-002-s308><adapt.anpassen><en> Adapt our high performance SSD cloud storage to the requirements of your application.
<G-vec00095-002-s308><adapt.anpassen><de> Passe unseren leistungsstarken SSD-Cloud Storage an die Anforderungen deiner Anwendung an.
<G-vec00095-002-s309><adapt.anpassen><en> Adapt the building's floor if necessary.
<G-vec00095-002-s309><adapt.anpassen><de> Passe, wenn nötig, den Boden des Gebäudes an.
<G-vec00095-002-s310><adapt.anpassen><en> We always come to the customer’s request and we adapt the racks to the overproduct.
<G-vec00095-002-s310><adapt.anpassen><de> Dabei gehen wir stets von den Wünschen des Kunden aus und passen die Regale dem Transportgut an.
<G-vec00095-002-s311><adapt.anpassen><en> Find the necessary product and related product information faster and adapt it to current trends and market requirements.
<G-vec00095-002-s311><adapt.anpassen><de> Finden Sie das notwendige Produkt und die zugehörigen Produktinformationen schneller und passen Sie diese an die aktuellen Trends und Marktanforderungen an.
<G-vec00095-002-s312><adapt.anpassen><en> Brera B is customized and made up of profiles that are conceived to take up a minimal amount of space and to discreetly adapt in pre-existing spaces.
<G-vec00095-002-s312><adapt.anpassen><de> Maßgefertigt hergestellt, besteht Brera B aus Profilen, die so konzipiert sind, dass sie Mindestabmessungen haben und diskret in bereits vorhandenen Räumen passen.
<G-vec00095-002-s313><adapt.anpassen><en> Unique employee file: Adapt the administrative data in your HR database to your company’s organisational, technical, and regulatory context.
<G-vec00095-002-s313><adapt.anpassen><de> Zentrales Mitarbeiterprofil: Passen Sie administrative Personaldaten aus Ihren HR-Datenbank an den organisatorischen, technischen und rechtlichen Kontext Ihres Unternehmens an.
<G-vec00095-002-s314><adapt.anpassen><en> With our integrated and scalable solutions (ERP), you adapt to planning and management methods and achieve your goals.
<G-vec00095-002-s314><adapt.anpassen><de> Mit unseren integrierten und skalierbaren ERP-Lösungen passen Sie Ihre Planungs- und Steuerungsprozesse stets den Anforderungen Ihres Unternehmens an und erreichen so Ihre Ziele.
<G-vec00095-002-s315><adapt.anpassen><en> Please adapt the cut-out for the amplifier module in the building plan.
<G-vec00095-002-s315><adapt.anpassen><de> Bitte passen Sie im Bauplan der Zeitschrift die Größe der Aussparung für das neue Verstärkermodul an.
<G-vec00095-002-s316><adapt.anpassen><en> We review our security measures regularly and adapt them to technological advances.e review our security measures regularly and adapt them to technological advances.
<G-vec00095-002-s316><adapt.anpassen><de> Wir überprüfen unsere Sicherheitsmaßnahmen regelmäßig und passen sie dem technologischen Fortschritt an.
<G-vec00095-002-s317><adapt.anpassen><en> We continually develop our manufacturing technology and adapt it to meet customer requirements.
<G-vec00095-002-s317><adapt.anpassen><de> Wir entwickeln unsere Fertigungstechnologien kontinuierlich weiter und passen sie auf Kundenbedürfnisse an.
<G-vec00095-002-s318><adapt.anpassen><en> This camera has been designed to meet virtually any creative challenge – it’s faster, more responsive and features the tools to adapt to everything from studio photography to creative videography, while producing results of the highest quality.”
<G-vec00095-002-s318><adapt.anpassen><de> Die Kamera wird nahezu jeder kreativen Herausforderung gerecht: Sie ist schnell, hat ein hervorragendes Ansprechverhalten und Funktionen, die zu allen Anforderungen, von der Studio-Fotografie bis zur kreativen Videogestaltung, passen und Ergebnisse auf h?chstem Niveau liefern.
<G-vec00095-002-s319><adapt.anpassen><en> In addition, we adapt the handling individually to the specifications of the customer or the molded part.
<G-vec00095-002-s319><adapt.anpassen><de> Zusätzlich passen wir das Handling individuell auf die Vorgaben der Kunden oder des Formteils an.
<G-vec00095-002-s320><adapt.anpassen><en> To keep our range up-to-date for you, we continuously adapt it to the changing demands of the market as well as making fashionable changes to colour and design.
<G-vec00095-002-s320><adapt.anpassen><de> Um unser Sortiment für Sie aktuell zu halten, passen wir es laufend an die sich wandelnden Markterfordernisse sowie modische Änderungen in Design und Farbe an.
<G-vec00095-002-s321><adapt.anpassen><en> We adapt our cutting to the wishes of each customer with a level of finishing of their choice: raw meat, semi-pared meat, ready to cut/slice meat.
<G-vec00095-002-s321><adapt.anpassen><de> Wir passen uns beim Zerlegen an die Wünsche jedes einzelnen Kunden an, der uns den Bearbeitungsgrad vorgibt: rohes Schlachtfleisch, halb-pariertes Fleisch, grob- und feinzerlegtes Fleisch.
<G-vec00095-002-s322><adapt.anpassen><en> Subject to the case of application, our experts adapt the headbox ideally to the range of grades to be produced.
<G-vec00095-002-s322><adapt.anpassen><de> Je nach Anwendungsfall passen unsere Experten den Stoffauflauf optimal an die Produktionsanforderungen und Papiersorten an.
<G-vec00095-002-s323><adapt.anpassen><en> Therefore we create the needed infrastructural preconditions as well as adapt the regulatory framework to LNG-usage in cooperation with members and partners of the LNG-Initiative.
<G-vec00095-002-s323><adapt.anpassen><de> Hierfür schaffen wir im Zusammenwirken mit weiteren Akteuren der LNG-Plattform die infrastrukturellen Voraussetzungen und passen die regulatorischen Rahmenbedingungen laufend den Erfordernissen an.
<G-vec00095-002-s324><adapt.anpassen><en> On the way to tailor-made biocatalysts, we discover and produce enzymes and adapt them to your requirements.
<G-vec00095-002-s324><adapt.anpassen><de> Auf dem Weg zu maßgeschneiderten Biokatalysatoren suchen und produzieren wir Enzyme und passen diese Ihren Aufgabenstellungen an.
<G-vec00095-002-s325><adapt.anpassen><en> We adapt our program to the respective vehicle design of roof-mounted, sub- and fully integrated air conditioning equipment.
<G-vec00095-002-s325><adapt.anpassen><de> Wir passen unser Programm an Dach-, teil- und vollintegrierten Klimaanlagen dem jeweiligen Fahrzeugdesign an.
<G-vec00095-002-s326><adapt.anpassen><en> Our technical know-how in the marine sector allows us to adapt to the individual requirements aboard each vessel.
<G-vec00095-002-s326><adapt.anpassen><de> Mit unserem technischen Marine-Knowhow passen wir uns den individuellen Anforderungen an Bord an.
<G-vec00095-002-s327><adapt.anpassen><en> Multi-Adapter The multi adapter in different types of wood adapt perfectly to NOHrD wallbars
<G-vec00095-002-s327><adapt.anpassen><de> Die Multi-Adapter in verschiedenen Holztypen passen optisch perfekt zu den NOHrD Sprossenwänden.
<G-vec00095-002-s328><adapt.anpassen><en> Whatever your project – rail automation, railway electrification, locomotives, trams, metro systems, regional and high-speed trains or depots – we adapt vehicles and systems to your individual requirements, and perfectly coordinate all components.
<G-vec00095-002-s328><adapt.anpassen><de> Enlarge Bahnautomatisierung, Bahnelektrifizierung, Lokomotiven, Straßenbahnen, Metrosysteme, Regional- und Hochgeschwindigkeitszüge, Depots – wir passen Fahrzeuge und Systeme auf Ihr individuelles Projekt an und stimmen alle Komponenten aufeinander ab.
<G-vec00095-002-s329><adapt.anpassen><en> Through our cooperation with numerous professional partners from the fields of warehousing and distribution, we can optimally adapt our services to your personal needs.
<G-vec00095-002-s329><adapt.anpassen><de> Durch unsere Kooperation mit zahlreichen professionellen Partnern aus den Bereichen Warehousing and Distribution passen wir unsere Leistungen optimal an Ihre Bedürfnisse an.
<G-vec00095-002-s330><adapt.anpassen><en> The adjustable arm and hand rests adapt front to back as well as up and down.
<G-vec00095-002-s330><adapt.anpassen><de> Die Schwenkarm- und Handreste passen Front zur Rückseite sowie auf und ab an.
<G-vec00095-002-s331><adapt.anpassen><en> We create travel packages and services based on your wishes and adapt the offer directly to your needs.
<G-vec00095-002-s331><adapt.anpassen><de> Reisepakete und Dienstleistungen erstellen wir anhand Ihrer Wünsche und passen das Angebot unmittelbar an Ihre Bedürfnisse an.
<G-vec00095-002-s332><adapt.anpassen><en> Open the planning templates with a single click and then quickly and easily adapt the bathroom to suit your individual wishes and needs in our free 3D Bathroom Planner.
<G-vec00095-002-s332><adapt.anpassen><de> Starten Sie die Planungsvorlagen mit einem Klick und passen Sie das Bad dann einfach und schnell in unserem kostenfreien 3D-Badplaner an Ihre individuellen Wünsche und Bedürfnisse an.
<G-vec00095-002-s333><adapt.anpassen><en> Instead of these products, we prefer to use regional products and adapt our menu to the harvest calendar.
<G-vec00095-002-s333><adapt.anpassen><de> Anstelle dieser Produkte verwenden wir dann lieber Regionales und passen unsere Karte dem Erntekalender an.
<G-vec00095-002-s334><adapt.anpassen><en> Plants adapt the iron acquisition in their roots to their current requirements.
<G-vec00095-002-s334><adapt.anpassen><de> Pflanzen passen die Wurzeleisengewinnung an den aktuellen Bedarf an.
<G-vec00095-002-s335><adapt.anpassen><en> Because as a specialist team with a clear technology focus, we know this field like no other, and - as a small company - we take each job equally serious and adapt our work to your processes without fuss.
<G-vec00095-002-s335><adapt.anpassen><de> Denn als Spezialisten-Team mit klarem Technik-Fokus kennen wir diesen Bereich wie kaum ein zweiter, nehmen als kleines Unternehmen jeden Auftrag gleichermaßen ernst und passen unsere Arbeit unkompliziert an Ihre Prozesse an.
<G-vec00095-002-s336><adapt.anpassen><en> We manufacture both the roll forming gearboxes and the frames and dies according to your wishes and where necessary we adapt standard components to meet your requirements.
<G-vec00095-002-s336><adapt.anpassen><de> Sowohl die Profiliergetriebe als auch die Gerüste oder Werkzeuge fertigen wir nach Ihren Wünschen, gegebenenfalls passen wir dabei Standardkomponenten an Ihre Anforderungen an.
<G-vec00095-002-s337><adapt.anpassen><en> We adapt the transport to suit our customer´s requirements.
<G-vec00095-002-s337><adapt.anpassen><de> Wir passen den Transport an die Bedürfnisse des Kunden an.
<G-vec00095-002-s338><adapt.anpassen><en> Examples of Prohibition signs - Choose one of our example signs and adapt it to your requirements.
<G-vec00095-002-s338><adapt.anpassen><de> Beispiele von Verbotsschildern - Wählen Sie eines unserer Musterschilder und passen Sie es nach eigenen Wünschen an.
<G-vec00095-002-s339><adapt.anpassen><en> Examples of Hotel parking signs - Choose one of our example signs and adapt it to your requirements.
<G-vec00095-002-s339><adapt.anpassen><de> Beispiele von Hotelschildern - Wählen Sie eines unserer Musterschilder und passen Sie es nach eigenen Wünschen an.
<G-vec00095-002-s340><adapt.anpassen><en> In addition, we adapt the height, volume and layout of the silo compartments individually to your production plant.
<G-vec00095-002-s340><adapt.anpassen><de> Außerdem passen wir Höhe, Volumen und Anordnung der Silozellen individuell an Ihre Produktionsstätte an.
<G-vec00095-002-s341><adapt.anpassen><en> «Reasonable men adapt themselves to the world; unreasonable men persist in trying to adapt the world to themselves.
<G-vec00095-002-s341><adapt.anpassen><de> "Vernünftige Menschen passen sich der Welt an; die unvernünftigen versuchen, sie zu verändern.
<G-vec00095-002-s342><adapt.anpassen><en> Maintain full transparency over costs at all times and flexibly adapt the services to your needs.
<G-vec00095-002-s342><adapt.anpassen><de> Behalten Sie jederzeit die vollen Kosten im Blick und passen Sie die Leistungen flexibel an Ihren Bedarf an.
<G-vec00095-002-s343><adapt.anpassen><en> As far as possible, we adapt to the lifestyle and immerse ourselves in the countryside and the life, work and culture of the people.
<G-vec00095-002-s343><adapt.anpassen><de> Im Grossen und Ganzen passen wir uns – soweit uns das möglich ist - den Lebensgewohnheiten an und tauchen dabei in die Landschaft, die Lebens- und Arbeitsweisen und die Kultur ein.
<G-vec00095-002-s344><adapt.anpassen><en> Whatever challenges you may face, with our professional consulting services at our office and your site we specifically adapt to your needs.
<G-vec00095-002-s344><adapt.anpassen><de> Welche Herausforderung auch vor Ihnen liegt, durch unser kompetentes Beratungsangebot im Innendienst und bei Ihnen vor Ort passen wir uns gezielt Ihrem Bedarf an.
<G-vec00095-002-s345><adapt.anpassen><en> We adapt the length of the program to your wishes.
<G-vec00095-002-s345><adapt.anpassen><de> Die Länge des Programmes passen wir an Ihre Wünsche an.
<G-vec00095-002-s346><adapt.anpassen><en> We adapt ourselves to the requirements of our national and international customers. Therefore, we are certified according to AEO-C now.
<G-vec00095-002-s346><adapt.anpassen><de> Wir passen uns den Anforderungen unserer nationalen und internationalen Kunden an und sind daher jetzt auch nach AEO-C zertifiziert.
<G-vec00095-002-s347><adapt.anpassen><en> We have the idea, develop the concept from it and adapt it to your wishes.
<G-vec00095-002-s347><adapt.anpassen><de> Wir haben die Idee, entwickeln daraus das Konzept und passen es Ihren wünschen an.
<G-vec00095-002-s348><adapt.anpassen><en> WC and Wash Basins adapt to the most different of needs at the touch of a button.
<G-vec00095-002-s348><adapt.anpassen><de> WC und Waschtische passen sich auf Knopfdruck den unterschiedlichsten Bedürfnissen an.
<G-vec00095-002-s349><adapt.anpassen><en> The soft rubber sides adapt to the contours of your teeth and gums to absorb excessive pressure.
<G-vec00095-002-s349><adapt.anpassen><de> Die weichen Seiten aus Gummi passen sich den Konturen deiner Zähne und des Zahnfleischs an, um so übermässigen Druck zu absorbieren.
<G-vec00095-002-s350><adapt.anpassen><en> There is a light blue and pink version of it and both shades adapt perfectly to the skin’s tone.
<G-vec00095-002-s350><adapt.anpassen><de> Es gibt ihn in hellblau oder rosa und beide Farben passen sich der Haut sehr gut an.
<G-vec00095-002-s351><adapt.anpassen><en> This you can rely on with the wiper blades distributed by Mopar® for Fiat, Alfa Romeo, Lancia, Fiat Professional, Jeep® and Abarth vehicles, because they are designed to measure and adapt perfectly to the shape and inclination of the windscreen of all FCA vehicles.
<G-vec00095-002-s351><adapt.anpassen><de> Die von Mopar® vertriebenen Scheibenwischerblätter von Fiat, Alfa Romeo, Lancia, Fiat Professional, Jeep® und Abarth ermöglichen auf all das zu vertrauen und passen sich perfekt an die Form und Schräge der Windschutzscheibe der Fahrzeuge der FIAT Gruppe an, da sie auf Maß designt wurden.
<G-vec00095-002-s352><adapt.anpassen><en> Our services adapt efficiently to your business needs and drive the right business outcomes for your company.
<G-vec00095-002-s352><adapt.anpassen><de> Unsere Services passen sich effizient an Ihre Geschäftsanforderungen an und fördern die richtigen Ergebnisse für Ihr Unternehmen.
<G-vec00095-002-s353><adapt.anpassen><en> The different sipes flexibly adapt to all weather variations, offering relentless grip and enjoyably controlled and quiet driving.
<G-vec00095-002-s353><adapt.anpassen><de> Die unterschiedlichen Lamellen passen sich flexibel an alle Wetterumschwünge an und stellen so kompromisslosen Grip, kontrollierten Fahrspaß und eine ruhige Fahrt sicher.
<G-vec00095-002-s354><adapt.anpassen><en> With power outputs of 250 or 500 Watt, the UMC generators are able to optimally adapt to individual cleaning requirements.
<G-vec00095-002-s354><adapt.anpassen><de> Die UMC Generatoren passen sich dabei mit 250 oder 500 Watt Leistung optimal an individuelle Reinigungsanforderungen an.
<G-vec00095-002-s355><adapt.anpassen><en> The high speed ICE stations Limburg and Montabaur adapt impressively into trans-European networks.
<G-vec00095-002-s355><adapt.anpassen><de> Die ICE-Bahnhöfe Limburg und Montabaur passen sich „eindrucksvoll“ in transeuropäische Netze ein.
<G-vec00095-002-s356><adapt.anpassen><en> The manufactured products adapt perfectly to the needs of your production, amplifying the performances in each phase.
<G-vec00095-002-s356><adapt.anpassen><de> Die realisierten Produkte passen sich den Anforderungen Ihrer Produktion perfekt an und verbessern zudem in jedem Stadium ihre Leistung.
<G-vec00095-002-s357><adapt.anpassen><en> They adapt excellently to their respective environment, and they existed long before humans.
<G-vec00095-002-s357><adapt.anpassen><de> Sie passen sich ihrer jeweiligen Umgebung hervorragend an, und es gab sie schon lange vor dem Menschen.
<G-vec00095-002-s358><adapt.anpassen><en> Due to its elegant and light design and the streamlined orientation the outdoor furniture collection Alize easily adapt to a variety of furnishings.
<G-vec00095-002-s358><adapt.anpassen><de> Aufgrund ihres elegant schlichten Designs und der stromlinienförmigen Ausrichtung passen sich die Möbel der Outdoor Kollektion Alize problemlos einer Vielzahl von Umgebungen an.
<G-vec00095-002-s359><adapt.anpassen><en> As a result jackets that use hydrophilic membranes adapt to your activity level and retain heat well.
<G-vec00095-002-s359><adapt.anpassen><de> Aus diesem Grund passen sich Jacken mit hydrophilen Membranen deinem Aktivitätsniveau an und speichern hervorragend Wärme.
<G-vec00095-002-s360><adapt.anpassen><en> Nearly a billion shorter fibers adapt to your movements to create our pillow’s signature springy support.
<G-vec00095-002-s360><adapt.anpassen><de> Fast eine Milliarde winzig kleiner Fasern im inneren Kissen passen sich deinen Bewegungen an und sorgen für angenehm federnde Unterstützung.
<G-vec00095-002-s361><adapt.anpassen><en> Personalizable front panels and individual appearance adapt flexible to the CI and the application site.
<G-vec00095-002-s361><adapt.anpassen><de> Personalisierbare Fronten und individuelle Erscheinung passen sich der CI und dem Einsatzort flexibel an.
<G-vec00095-002-s362><adapt.anpassen><en> The MEX gooseneck microphones with their numerous mounting accessories adapt perfectly to any environment.
<G-vec00095-002-s362><adapt.anpassen><de> Die MEX-Schwanenhalsmikrofone mit ihrem zahlreichen Montagezubehör passen sich jeder Umgebung bestens an.
<G-vec00095-002-s363><adapt.anpassen><en> Made from high-quality, soft materials, they adapt perfectly to the changes in your figure, ensuring that you feel comfortable.
<G-vec00095-002-s363><adapt.anpassen><de> Aus hochwertigen, weichen Materialien passen sie sich den Veränderungen der Figur perfekt an und sorgen so für Ihr Wohlgefühl.
<G-vec00095-002-s364><adapt.anpassen><en> Most adapt as fast as any other employee, some need more time and adapt gradually.
<G-vec00095-002-s364><adapt.anpassen><de> Die meisten passen sich so schnell wie jeder andere Mitarbeiter an, einige brauchen mehr Zeit und passen sich gradweise an.
<G-vec00095-002-s366><adapt.anpassen><en> Minimize delays and adapt to unforeseen circumstances with real-time monitoring of operations.
<G-vec00095-002-s366><adapt.anpassen><de> Durch Echtzeitüberwachung der Betriebe minimieren Sie Verspätungen und passen sich unvorhergesehenen Umständen an.
<G-vec00095-002-s367><adapt.anpassen><en> 1. Each institution shall adapt its rules of procedure to the provisions of this Regulation.
<G-vec00095-002-s367><adapt.anpassen><de> (1) Jedes Organ passt seine Geschäftsordnung an die Bestimmungen dieser Verordnung an.
<G-vec00095-002-s368><adapt.anpassen><en> Based on the information, an actuator on the mixing shunt will constantly adapt the supply temperature to the actual heat demand.
<G-vec00095-002-s368><adapt.anpassen><de> Aufgrund der gesammelten Informationen passt ein Stellantrieb an der Mischergruppe die Vorlauftemperatur fortlaufend an den tatsächlichen Heizbedarf an.
<G-vec00095-002-s369><adapt.anpassen><en> Together with the technical departments, they develop new software solutions and adapt these with the flow of work in the respective departments.
<G-vec00095-002-s369><adapt.anpassen><de> Gemeinsam mit den Fachbereichen entwickelt die Abteilung IT & Organisation neue Software-Lösungen und passt sie an die Arbeitsabläufe in den jeweiligen Arbeitsbereichen an.
<G-vec00095-002-s370><adapt.anpassen><en> Our team will be happy to adapt to specific diets when previously informed.
<G-vec00095-002-s370><adapt.anpassen><de> Unser Team passt die Gerichte in Bezug auf spezielle Essgewohnheiten gerne an, wenn wir im Vorfeld informiert werden.
<G-vec00095-002-s371><adapt.anpassen><en> On the occasion you adapt the hood, which is now made of sheet metal and no longer of plastic.
<G-vec00095-002-s371><adapt.anpassen><de> Bei der Gelegenheit passt man die Haube an, die nun aus Blech und nicht mehr aus Kunststoff geformt ist.
<G-vec00095-002-s372><adapt.anpassen><en> The Varioflex technology allows the visor to adapt its tint to the prevailing lighting conditions.
<G-vec00095-002-s372><adapt.anpassen><de> Durch die Varioflex Technologie passt das Visier seine Tönung automatisch den Lichtverhältnissen an.
<G-vec00095-002-s373><adapt.anpassen><en> 3 The Federal Council shall periodically adapt the content of the universal service in accordance with the state of the art and social and economic requirements.
<G-vec00095-002-s373><adapt.anpassen><de> 3 Der Bundesrat passt den Inhalt der Grundversorgung periodisch den gesellschaftlichen und wirtschaftlichen Bedürfnissen und dem Stand der Technik an.
<G-vec00095-002-s374><adapt.anpassen><en> SB is fully responsive and will adapt itself to any mobile or tablet device.
<G-vec00095-002-s374><adapt.anpassen><de> SB ist völlig responsive und passt sich jedem Gerät an.
<G-vec00095-002-s375><adapt.anpassen><en> Even the AMG DYNAMIC SELECT can adapt the vehicle’s characteristics to your wishes and needs: From efficient to comfortable to sporty to extremely sporty.
<G-vec00095-002-s375><adapt.anpassen><de> Auch das AMG DYNAMIC SELECT passt die Charakteristik des Fahrzeugs auf Ihre Wünsche und Bedürfnisse an: von effizient, komfortabel über sportlich bis hin zu besonders sportlich.
<G-vec00095-002-s376><adapt.anpassen><en> Whether wristbands, docking station or mounts: People with an assured sense of style adapt their Apple Watch accessories to the watch, the trend and daily changing style.
<G-vec00095-002-s376><adapt.anpassen><de> Ob Armbänder, Dockingstation mit Ladefunktion, Halterungen oder Ständer: Wer stilsicher unterwegs ist, der passt sein Apple Watch Zubehör von xMount der Uhr, dem Trend und dem täglich wechselnden Stil an.
<G-vec00095-002-s377><adapt.anpassen><en> Only a few calibration steps are necessary to adapt a coating thickness gauges perfectly to the measuring task thus assuring highest precision in coating thickness measurement.
<G-vec00095-002-s377><adapt.anpassen><de> Die Kalibrierung eines Schichtdicken- messgerätes ist in wenigen Schritten durchgeführt und passt den MiniTest optimal an die Messaufgabe an, um höchste Präzision in der Schichtdicken- messung zu gewährleisten.
<G-vec00095-002-s378><adapt.anpassen><en> By Velcro and elastic band you adapt this leg dress to your body measurements.
<G-vec00095-002-s378><adapt.anpassen><de> Per Klettverschluss und Gummizug passt du dieses Beinkleid an deine Körpermaße an.
<G-vec00095-002-s379><adapt.anpassen><en> The gears adapt the motor's high rotational speed to the low rotational speed of the wheel.
<G-vec00095-002-s379><adapt.anpassen><de> Das Getriebe passt die hohe Drehzahl des Motors an die niedrigere Drehzahl des Rades an.
<G-vec00095-002-s380><adapt.anpassen><en> Moreover, the Executive Board wants to further develop our management culture and to adapt it to new challenges.
<G-vec00095-002-s380><adapt.anpassen><de> Zudem entwickelt der Vorstand die Führungskultur weiter und passt sie an die neuen Herausforderungen an.
<G-vec00095-002-s381><adapt.anpassen><en> The new DAB e.sybox mini offers a complete solution and will adapt itself to the ever changing demands of the system.
<G-vec00095-002-s381><adapt.anpassen><de> Die neue DAB e.sybox mini bietet eine komplette Lösung und passt sich den ständig wechselnden Anforderungen des Systems an.
<G-vec00095-002-s382><adapt.anpassen><en> Control over Dual Pixel CMOS AF sensitivity and speed for movies allows you to adapt the focus to the shooting situation and create a slow, natural or fast-paced look for your movie.
<G-vec00095-002-s382><adapt.anpassen><de> Kreative Steuerung des Fokus Die Steuerung der AF-Reaktion und AF-Geschwindigkeit des Dual Pixel CMOS AF passt den Autofokus an die Aufnahmesituation an und verleiht Ihren Videos damit ein einzigartiges Aussehen.
<G-vec00095-002-s383><adapt.anpassen><en> The glare-free matrix headlights automatically and continuously adapt to the prevailing traffic situation and surroundings.
<G-vec00095-002-s383><adapt.anpassen><de> Es passt seine Lichtleistung automatisch und kontinuierlich der jeweiligen Verkehrssituation und Umgebung an.
<G-vec00095-002-s384><adapt.anpassen><en> We develop projects for people in a particular area - here the Rollberg district - and adapt our offers flexibly to the needs of the target group.
<G-vec00095-002-s384><adapt.anpassen><de> Er entwickelt Projekte für die Menschen in einem bestimmten Kiez – hier das Rollbergviertel – und passt seine Angebote flexibel den Bedürfnissen der Zielgruppe an.
<G-vec00095-002-s385><adapt.anpassen><en> Adapt to the day/night cycle and changing weather conditions as you craft weapons to take down your foes in tense tactical combat.
<G-vec00095-002-s385><adapt.anpassen><de> Passt euch an den Tag/Nacht-Zyklus und die sich ändernden Wetterbedingungen an, während ihr Waffen herstellt, um eure Feinde in spannenden und taktischen Kämpfen zu besiegen.
<G-vec00095-002-s386><adapt.anpassen><en> Made from soft and exceptionally stretchy material, this comfortable babydoll will adapt to your feminine curves.
<G-vec00095-002-s386><adapt.anpassen><de> Gefertigt aus einem weichen und besonders dehnbaren Material ist dieses Babydoll angenehm zu tragen und passt sich leicht den weiblichen Kurven an.
<G-vec00095-002-s387><adapt.anpassen><en> The driving dynamics adapt to your mood at the touch of a button with four driving options "Comfort", "Sport", "Eco" and "Individual".
<G-vec00095-002-s387><adapt.anpassen><de> Die Fahrdynamik passt sich auf Knopfdruck mit vier Fahroptionen "Komfort", "Sport", "Eco" und "Individual" Ihrer Stimmung an.
<G-vec00095-002-s388><adapt.anpassen><en> Obsessively engineered and made to adapt, this pumped up runner conforms to your foot in a way no other shoe can touch.
<G-vec00095-002-s388><adapt.anpassen><de> Dieser Laufschuh zum Aufpumpen passt sich wie kein anderer deiner Fußform an und überzeugt durch sein perfekt durchdachtes Design.
<G-vec00095-002-s389><adapt.anpassen><en> Depending on its location, the plant has the ability to adapt ideally to its surroundings, whether as low-lying or wide shrubs, or as columnar trees.
<G-vec00095-002-s389><adapt.anpassen><de> Die Pflanze passt sich je nach Standort optimal an, sei es als niedriger oder breit ausladender Strauch, sei es als säulenförmiger Baum.
<G-vec00095-002-s390><adapt.anpassen><en> As our most dynamic women's cross-training shoe, the low-profile Pulse IGNITE XT is designed to adapt to the boldness and flexibility of any workout.
<G-vec00095-002-s390><adapt.anpassen><de> Der flach profilierte Pulse IGNITE XT Swan ist unser dynamischster Crosstraining-Schuh für Frauen, passt sich jederzeit an deine Trainingsintensität an und bietet genau die Flexibilität, die dein Workout gerade verlangt.
<G-vec00095-002-s391><adapt.anpassen><en> Extensible infrastructure keeps pace with business dynamics, using incremental data integration and semantic analysis to dynamically adapt to changing systems, process, and information needs.
<G-vec00095-002-s391><adapt.anpassen><de> Die frei erweiterbare Infrastruktur für inkrementelle Datenintegration und semantische Datenanalyse passt sich dynamisch Ihrem System-, Prozess- und Informationsbedarf an.
<G-vec00095-002-s392><adapt.anpassen><en> The “Tunable White” solution simulates natural daylight and can adapt to personal requirements.
<G-vec00095-002-s392><adapt.anpassen><de> Die Lichtlösung „Tunable White“ bildet deshalb das Tageslicht nach und passt sich individuellen Bedürfnissen an.
<G-vec00095-002-s393><adapt.anpassen><en> Thanks to the sliding rear seat bench, it is spacious and also flexible enough to adapt to any requirements.
<G-vec00095-002-s393><adapt.anpassen><de> Dank der umklappbaren Beifahrersitzlehne und der verschiebbaren Rücksitzbank ist er geräumig und passt sich flexibel an Ihre Wünsche an.
<G-vec00095-002-s394><adapt.anpassen><en> At Focke Meler, we adapt to the specific needs of each application, offering a very competitive price, an excellent pre and after sales service, with technical assistance all over the world and minimal delivery times (between 24 and 48 hours for standard material).
<G-vec00095-002-s394><adapt.anpassen><de> Focke Meler passt sich den besonderen Anforderungen jeder Anwendung zu einem wettbewerbsfähigen Preis mit einem ausgezeichneten Beratungsservice vor und nach dem Verkauf und einem technischen Kundendienst in der ganzen Welt sowie extrem kurzen Lieferzeiten (zwischen 24 und 48 Stunden bei Standardmaterialien) an.
<G-vec00095-002-s395><adapt.anpassen><en> MyFairs is available in German and English. App functions automatically adapt to the language selection.
<G-vec00095-002-s395><adapt.anpassen><de> MyFairs ist in den Sprachen deutsch und englisch erhältlich; die Anwendung passt sich der jeweiligen Landeseinstellung an.
<G-vec00095-002-s453><adapt.anpassen><en> The integrated Flip Chip lets you further adapt the bike’s geometry to suit your technique and terrain.
<G-vec00095-002-s453><adapt.anpassen><de> Die SRAM Guide R mit einem bewährten 4-Kolben-Bremssattel lässt sich dank des integrierten Flip Chips präzise auf unterschiedliche Terrains und deinen Fahrstil anpassen.
<G-vec00095-002-s454><adapt.anpassen><en> Integrated Motion system that gives incredible flexibility to the pad, allowing it to adapt even to more extreme movements.
<G-vec00095-002-s454><adapt.anpassen><de> Das integrierte Motion System verleiht der Binde eine unglaubliche Flexibilität, wodurch sie sich sogar heftigen Bewegungen anpassen kann.
<G-vec00095-002-s455><adapt.anpassen><en> A number of long-term trends are reshaping the global landscape, awakening new high profile brands - while others may fail to adapt.
<G-vec00095-002-s455><adapt.anpassen><de> Einige langfristige Trends verändern das globale Umfeld und treiben den Aufstieg neuer hochkarätiger Marken voran – während andere sich nicht anpassen können.
<G-vec00095-002-s456><adapt.anpassen><en> One must adapt little by prospects how great the float should be.
<G-vec00095-002-s456><adapt.anpassen><de> Man muss sich anpassen wenig von Perspektiven, wie groß der Schwimmer sein sollte.
<G-vec00095-002-s457><adapt.anpassen><en> Most of our G-1000 materials come pre-waxed, but it’s still a good idea to know how to re-apply and remove the wax to adapt your jacket to the conditions.
<G-vec00095-002-s457><adapt.anpassen><de> G-1000 Heavy Duty ist zwar vorgewachst, doch es lohnt sich, das Auftragen und Entfernen des Wachses zu lernen, damit du deine Jacke den Bedingungen entsprechend anpassen kannst.
<G-vec00095-002-s458><adapt.anpassen><en> Other species must adapt or die.
<G-vec00095-002-s458><adapt.anpassen><de> Andere Arten müssen sich anpassen oder sterben.
<G-vec00095-002-s459><adapt.anpassen><en> This feature means that they easily adapt to the environment during their growth.
<G-vec00095-002-s459><adapt.anpassen><de> Diese Eigenschaft bedeutet, dass sie sich leicht an die Umwelt während ihres Wachstums anpassen.
<G-vec00095-002-s460><adapt.anpassen><en> For modernizations, we have to adapt to the existing situation.
<G-vec00095-002-s460><adapt.anpassen><de> Bei einer Modernisierung hingegen muss man sich den Gegebenheiten anpassen.
<G-vec00095-002-s461><adapt.anpassen><en> This unique girl's bikini is completely bordered with elasticated straps which adapt individually to the
<G-vec00095-002-s461><adapt.anpassen><de> Der einzigartige Mädchen Bikini ist vollständig mit elastischen Bändern eingefasst, die sich dem Körper individuell anpassen.
<G-vec00095-002-s462><adapt.anpassen><en> HÜPPE Studio Paris elegance allows you to adapt the shower space to the structural elements in your bathroom without having to compromise on design.
<G-vec00095-002-s462><adapt.anpassen><de> Mit HÜPPE Studio Paris elegance können Sie sich fexibel an die baulichen Gegebenheiten Ihres Bades anpassen, ohne Kompromisse im Design eingehen zu müssen.
<G-vec00095-002-s463><adapt.anpassen><en> But as soon as there is danger of an avalanche the animals vanish as if by magic: ‘‘Chamois can adapt themselves very well to their alpine environment“, says game warden Bruno Tscherrig.
<G-vec00095-002-s463><adapt.anpassen><de> Doch sobald Lawinengefahr herrscht, verschwinden die Tiere, wie von Zauberhand weggebracht: „Gämsen können sich ihrer alpinen Umgebung sehr gut anpassen“, sagt Wildhüter Bruno Tscherrig.
<G-vec00095-002-s464><adapt.anpassen><en> Fourthly, It can adapt to difficult working conditions; it is highly protected from dust and moisture with IP67 sealing.
<G-vec00095-002-s464><adapt.anpassen><de> Viertens kann sich es schwierigen Arbeitsbedingungen anpassen; es wird in hohem Grade vor Staub und Feuchtigkeit mit Dichtung IP67 geschützt.
<G-vec00095-002-s465><adapt.anpassen><en> It has a number of advantages: the production processes are best adapted to the corresponding products; it is flexible in that it can adapt quickly to relatively minor changes in the underlying phenomena that the data describe; it is under the control of the domain manager and it results in a low-risk business architecture, as a problem in one of the production processes should normally not affect the rest of the production.
<G-vec00095-002-s465><adapt.anpassen><de> Es besitzt eine Reihe von Vorteilen: Die Produktionsverfahren sind für die entsprechenden Produkte am besten geeignet; es ist insofern flexibel, als es sich rasch an kleinere Veränderungen der den Daten zugrundeliegenden Phänomene anpassen lässt; es unterliegt der Kontrolle des Bereichsleiters und weist eine risikoarme Geschäftsarchitektur auf, da ein Problem in einem Produktionsprozess in der Regel keine Auswirkungen auf die übrige Produktion haben dürfte.
<G-vec00095-002-s466><adapt.anpassen><en> One bed can adapt to your child’s development and age the entire childhood.
<G-vec00095-002-s466><adapt.anpassen><de> Das Bett kann sich der Entwicklung Ihres Kindes anpassen und Ihr Kind die gesamte Kindheit begleiten.
<G-vec00095-002-s467><adapt.anpassen><en> In the name of solidarity you should adapt to the circumstances and support the group.
<G-vec00095-002-s467><adapt.anpassen><de> Im Namen der Solidarität sollten Sie sich den Umständen anpassen und die Gruppe unterstützen.
<G-vec00095-002-s468><adapt.anpassen><en> Parting from our transversal knowledge, accumulated experience and user empathy, we design and develop custom tools that adapt to any particular needs and facilitate, optimise and integrate with the productive processes of our clients.
<G-vec00095-002-s468><adapt.anpassen><de> Basierend auf unserem transversalen Wissen, gesammelte Erfahrung und Empathie mit den Nutzern, gestalten und entwickeln wir personalisierte Werkzeuge, die sich an die jeweiligen Bedürfnisse anpassen, die produktive Prozesse unserer Kunde vereinfachen, optimieren und sich damit integrieren.
<G-vec00095-002-s469><adapt.anpassen><en> And since the obstacles and opportunities in the competitive world market change over time and in place, to succeed the economic cat, no matter what its color, must adapt to these changes or fail to catch any mice at all.
<G-vec00095-002-s469><adapt.anpassen><de> Und da die Hindernisse und Gelegenheiten in der Konkurrenz des Weltmarktes sich in Raum und Zeit immer wieder ändern, muss die wirtschaftliche Katze, gleich welcher Farbe, um Erfolg zu haben, sich diesen Veränderungen anpassen oder sie schafft es nicht, irgendwelche Mäuse zu fangen.
<G-vec00095-002-s470><adapt.anpassen><en> Man can live in any economic relationship, can adapt himself to any form of political life, without affecting in the slightest the laws to which his physical being is subject.
<G-vec00095-002-s470><adapt.anpassen><de> Der Mensch kann unter jedem Wirtschaftsverhältnis leben, er kann sich jeder Form des politischen Lebens anpassen, ohne daß dadurch die Gesetze, denen sein physisches Sein unterworfen ist, berührt würden.
<G-vec00095-002-s471><adapt.anpassen><en> In these extreme conditions, rescue operations have always been a priority for the population and coastal ports have had to adapt and endow themselves with ever more efficient equipment.
<G-vec00095-002-s471><adapt.anpassen><de> Unter diesen extremen Bedingungen waren Rettungseinsätze schon immer eine Priorität für die Bevölkerung und die Küstenhäfen mussten sich anpassen und mit immer leistungsfähigeren Geräten ausstatten.
<G-vec00095-002-s472><adapt.anpassen><en> Or you can provide an HTML snippet, which can adapt to the current screen size via css media queries and utilize the full size of the area.
<G-vec00095-002-s472><adapt.anpassen><de> Oder Sie liefern die Anzeige als HTML-Snippet, welches sich dank CSS Media Queries an die jeweilige Bildschirmgröße anpasst.
<G-vec00095-002-s473><adapt.anpassen><en> This method allows the shoe's leather to be more flexible and adapt to each person's foot, achieving maximum comfort.
<G-vec00095-002-s473><adapt.anpassen><de> Diese Methode ermöglicht es, dass das Leder des Schuhs flexibler ist und sich dem Fuß jeder Person anpasst, wodurch maximaler Komfort erreicht wird.
<G-vec00095-002-s474><adapt.anpassen><en> And even if a concept is well accepted, it is imperative for a startup to constantly adapt in order to keep up with the market and continue to build on its lead.
<G-vec00095-002-s474><adapt.anpassen><de> Und auch wenn gute Konzepte greifen, ist es unabdingbar, dass das Startup sich stetig anpasst, um am Markt dran zu sein und seinen Vorsprung weiter auszubauen.
<G-vec00095-002-s475><adapt.anpassen><en> With its innovative design, AirFit N20 has been finished and shaped to adapt to the unique facial contours of each of your patients, offering a robust seal regardless of face shape or size.
<G-vec00095-002-s475><adapt.anpassen><de> Durch das innovative Design der AirFit N20 mit seiner speziellen Form und Oberfläche wird sichergestellt, dass die Maske sich den individuellen Gesichtskonturen jedes Ihrer Patienten anpasst und, unabhängig von Gesichtsform und -größe, eine zuverlässige Abdichtung bietet.
<G-vec00095-002-s476><adapt.anpassen><en> Rubber and the covering spring take the rubber, which are resistant to ozone and UV and adapt to different climatic conditions.
<G-vec00095-002-s476><adapt.anpassen><de> Gummi und die Abdeckfeder nehmen den Gummi auf, der gegen Ozon und UV beständig ist und sich an verschiedene klimatische Bedingungen anpasst.
<G-vec00095-002-s477><adapt.anpassen><en> See now Basic bras have been reinvented to better adapt to different silhouettes, materials and trends.
<G-vec00095-002-s477><adapt.anpassen><de> Die Basic-BHs werden neu erfunden, um ein Sortiment anbieten zu können, das sich besser an die verschiedensten Silhouetten, Materialien und Trends anpasst.
<G-vec00095-002-s478><adapt.anpassen><en> In a rapidly changing world, it is key that the Fund remains flexible in its response and adapt rapidly to the changing circumstances.
<G-vec00095-002-s478><adapt.anpassen><de> In einer sich schnell verändernden Welt ist es von größter Wichtigkeit, dass der IWF weiterhin flexibel reagiert und sich den neuen Umständen schnell anpasst.
<G-vec00095-002-s479><adapt.anpassen><en> Its cross-section with single-arm suspension system for the Number of elements is designed so as to adapt constantly and accurately to the road surface.
<G-vec00095-002-s479><adapt.anpassen><de> Sein Querprofil mit der Einzelarmabstützung der Abfederungselemente ist so konstruiert, dass es sich immer sehr genau der Fahrbahn anpasst.
<G-vec00095-002-s480><adapt.anpassen><en> For this very reason there is only one dance floor with its groove changing organically just like the circle of sun and moon - the music will adapt to the atmosphere of the day or the night.
<G-vec00095-002-s480><adapt.anpassen><de> Daher auch nur eine Tanzfläche, deren Groove sich so organisch wie das Spiel von Sonne und Mond verändert, wobei sich die Musik der jeweiligen Tages- oder Nachtzeit anpasst.
<G-vec00095-002-s481><adapt.anpassen><en> Not only: the multifunctional character of this product is also reflected in the installation procedures which adapt to baths of different types: between two walls or corner fitting, there is always a solution suited to your planning and space needs.
<G-vec00095-002-s481><adapt.anpassen><de> Und dem noch mehr: Die Multifunktionalität dieses Produkts spiegelt sich auch in der Einbauweise wider, die sich verschiedenartigen Wannen anpasst: Zwischen zwei Wänden oder in der Ecke, es gibt immer eine Lösung, die für Ihre Entwurfs- und Platzbedürfnisse geeignet ist.
<G-vec00095-002-s482><adapt.anpassen><en> Padel World Press .- If you are a padel player who has experience on the court and loves power, do not hesitate and discover the new HEAD Alpha Touch 2021, a shovel that will adapt like a glove to your needs.
<G-vec00095-002-s482><adapt.anpassen><de> Padel Weltpresse .- Wenn Sie ein Padel-Spieler sind, der Erfahrung auf dem Platz hat und Macht liebt, zögern Sie nicht und entdecken Sie das Neue KOPF Alpha Touch 2021, eine Schaufel, die sich wie angegossen an Ihre Bedürfnisse anpasst.
<G-vec00095-002-s483><adapt.anpassen><en> flexCloud Freely scalable cloud solution which can adapt to your company requirements at any time.
<G-vec00095-002-s483><adapt.anpassen><de> flexCloud Frei skalierbare Cloud-Lösung, die sich jederzeit an die Anforderungen Ihres Unternehmen anpasst.
<G-vec00095-002-s484><adapt.anpassen><en> The Counter Ring ring is made of elastic material to easily adapt to any penis size.
<G-vec00095-002-s484><adapt.anpassen><de> Der Penisring Counter Ring ist aus elastischem Material, das sich mühelos an jede Penisgrösse anpasst.
<G-vec00095-002-s485><adapt.anpassen><en> In the 2nd trimester, when the body is just beginning to adapt to the new weight and the load on the legs increases, this is especially true.
<G-vec00095-002-s485><adapt.anpassen><de> Im zweiten Trimester, wenn sich der Körper gerade erst an das neue Gewicht anpasst und die Belastung der Beine zunimmt, trifft dies besonders zu.
<G-vec00095-002-s486><adapt.anpassen><en> A notable feature is that the game seems to adapt to the spatial conditions of the player.
<G-vec00095-002-s486><adapt.anpassen><de> Eine erwähnenswerte Eigenschaft ist, dass dieses Spiel sich scheinbar an die räumlichen Gegebenheiten des Spielers anpasst.
<G-vec00095-002-s487><adapt.anpassen><en> AUVESY is a solid, owner-managed, traditional German SME with an expertise base spanning multiple industries and the capacity to quickly and flexibly adapt to customer requirements.
<G-vec00095-002-s487><adapt.anpassen><de> AUVESY ist ein solides, inhabergeführtes Unternehmen des deutschen Mittelstandes, das über das komplette branchenübergreifende Know-how verfügt und sich flexibel und schnell an die Bedürfnisse seiner Kunden anpasst.
<G-vec00095-002-s488><adapt.anpassen><en> Also, the website was created using responsive design, which enables the page to adapt automatically to the screen size of the device (iPad, tablet, mobile phone) it is accessed from for an optimal display.
<G-vec00095-002-s488><adapt.anpassen><de> Außerdem wurde der Webauftritt im Responsive Design gestaltet, sodass sich die Darstellung der Seiten auch beim Zugriff über mobile Endgeräte automatisch dem jeweiligen Ausgabemedium optimal anpasst.
<G-vec00095-002-s489><adapt.anpassen><en> FORMOTION® is a freely moving heel system that is de-coupled allowing to adapt to your individual running style.
<G-vec00095-002-s489><adapt.anpassen><de> FORMOTION® ist ein freibewegliches und entkoppeltes Fersenelement, das sich deinem individuellen Laufstil anpasst.
<G-vec00095-002-s490><adapt.anpassen><en> Standout projects to date include Bounce Family (2012), a collection of containers composed of Lycra-covered steel that stretch and hold much more than expected; and Dry (2012), a sculptural, stackable drying rack made of four movable, colorful, thermo-lacquered steel components designed to adapt to today’s multipurpose living spaces.
<G-vec00095-002-s490><adapt.anpassen><de> Herausragende Projekte sind bis dato die Bounce Family (2012), eine Kollektion von Stahlcontainern, die mit Lycra bezogen sind, sich dehnen und ungewöhnlich viel Gewicht tragen können; und Dry (2012), ein skulpturales und stapelbares Trockengestell, das aus vier beweglichen, bunten und thermolackierten Stahlelementen besteht und sich so den heutigen Mehrzweck-Wohnräumen anpasst.
<G-vec00095-002-s491><adapt.anpassen><en> A lean organisational structure and ultra-modern manufacturing are the basis for the fast development of products to adapt to the ever changing requirements of the industry.
<G-vec00095-002-s491><adapt.anpassen><de> Schlanke Organisationsstrukturen und hochmoderne Konstruktionsarbeitsplätze bilden die Grundlage zur schnellen Entwicklung von Produkten, um sich den ständig ändernden Anforderungen der Industrie anzupassen.
<G-vec00095-002-s492><adapt.anpassen><en> As a result, businesses that try to adapt to this new reality find that all types of contact initiated by customers—voice, social, text, chat—can be great revenue-producing opportunities.
<G-vec00095-002-s492><adapt.anpassen><de> Unternehmen, die versuchen, sich an diese neue Wirklichkeit anzupassen, stellen daher fest, dass jede Art von Kontaktaufnahme durch den Kunden, sei es sprachbasiert, über soziale Netzwerke, Text oder Chat, eine wichtige Absatzchance darstellen kann.
<G-vec00095-002-s493><adapt.anpassen><en> And it’s probably going to be easier for small labels to adapt.
<G-vec00095-002-s493><adapt.anpassen><de> Da wird es wahrscheinlich sogar für die kleinen Labels einfacher sein, sich anzupassen.
<G-vec00095-002-s494><adapt.anpassen><en> Water has its own rules, and we as humans have to learn how to adapt to these rules.
<G-vec00095-002-s494><adapt.anpassen><de> Wasser hat seine eigenen Gesetzmäßigkeiten, und der Mensch muss lernen, sich diesen anzupassen.
<G-vec00095-002-s495><adapt.anpassen><en> I believe in secure, flexible and fast solutions, that make it easy to adapt to new challenges as fast as needed.
<G-vec00095-002-s495><adapt.anpassen><de> Ich glaube an sichere, flexible und schnelle Lösungen, die es leicht machen, sich so schnell wie möglich an neue Herausforderungen anzupassen.
<G-vec00095-002-s496><adapt.anpassen><en> Kathrin Wehrli, Remo Lütolf and Yogesh Maheshwari will discuss how diversity can play an integral role on business success and why it is critical to an organization’s ability to adapt to a fast-changing environment.
<G-vec00095-002-s496><adapt.anpassen><de> Kathrin Wehrli, Remo Lütolf und Yogesh Maheshwari diskutieren, wie Vielfalt eine entscheidende Rolle für den Geschäftserfolg spielen kann und warum sie für die Fähigkeit eines Unternehmens, sich an ein sich schnell veränderndes Umfeld anzupassen, entscheidend ist.
<G-vec00095-002-s497><adapt.anpassen><en> A Member State to which paragraph 2 applies may have up to two more years, if necessary to enable the economic operators in that Member State to adapt gradually to the resale right system while maintaining their economic viability, before it is required to apply the resale right for the benefit of those entitled under the artist after his/her death.
<G-vec00095-002-s497><adapt.anpassen><de> (3) Ein Mitgliedstaat, auf den Absatz 2 Anwendung findet, verfügt erforderlichenfalls über einen zusätzlichen Zeitraum von höchstens zwei Jahren, um die Wirtschaftsteilnehmer in diesem Mitgliedstaat in die Lage zu versetzen, sich unter Wahrung ihrer wirtschaftlichen Lebensfähigkeit allmählich an das Folgerechtssystem anzupassen, bevor dieses Recht zugunsten der nach dem Tod des Künstlers anspruchsberechtigten Rechtsnachfolger angewandt werden muss.
<G-vec00095-002-s498><adapt.anpassen><en> General power banks have a relatively large range of charging in order to adapt to most mobile phones.
<G-vec00095-002-s498><adapt.anpassen><de> Allgemeine Powerbanks verfügen über einen relativ großen Ladebereich, um sich an die meisten Mobiltelefone anzupassen.
<G-vec00095-002-s499><adapt.anpassen><en> Collaborative robots are designed to learn and adapt as if they were a human coworker, which requires controlled, safe motion.
<G-vec00095-002-s499><adapt.anpassen><de> Kollaborierende Roboter sind darauf ausgelegt, wie ein menschlicher Mitarbeiter zu lernen und sich anzupassen, was eine kontrollierte, sichere Bewegung erfordert.
<G-vec00095-002-s500><adapt.anpassen><en> If a human incarnates he takes certain abilities into his life, principally to adapt to earthly conditions, that means he automatically accepts the conditions and adjusts to them.
<G-vec00095-002-s500><adapt.anpassen><de> Wenn der Mensch neu inkarniert, nimmt er bestimmte Anlagen mit, im Prinzip solche, um sich total dem Irdischen anzupassen, d.h. er sieht von hier aus eine Konstellation und paßt sich an.
<G-vec00095-002-s501><adapt.anpassen><en> The ski resort and the TechnoAlpin staff in charge of the project met over several months in order to plan the design and to adapt an advanced snowmaking system to the conditions of the location.
<G-vec00095-002-s501><adapt.anpassen><de> Das Skigebiet und die Zuständigen von TechnoAlpin haben sich über mehrere Monate getroffen um das Projekt zu planen und eine fortschrittliche Beschneiungsanlage an die Gegebenheiten des Ortes anzupassen.
<G-vec00095-002-s502><adapt.anpassen><en> Both were forced to adapt to the other’s rhythm of words.
<G-vec00095-002-s502><adapt.anpassen><de> Beide waren gezwungen, sich dem Rhythmus der Worte des anderen anzupassen.
<G-vec00095-002-s503><adapt.anpassen><en> The tibia roller pad can be adjusted to adapt to different user heights.
<G-vec00095-002-s503><adapt.anpassen><de> Das Schienbeinpolster ist verstellbar, um sich Nutzern unterschiedlicher Körpergrößen anzupassen.
<G-vec00095-002-s504><adapt.anpassen><en> Once the body begins to adapt, it consumes body fat in order to keep pace with energy demands that come with the curriculum.
<G-vec00095-002-s504><adapt.anpassen><de> Wenn der Körper beginnt, sich anzupassen, benötigt er Körperfett, um Schritt zu halten mit der Energie-Anforderungen, die mit einem Trainingsprogramm kommen.
<G-vec00095-002-s505><adapt.anpassen><en> With a global move towards linerless labels – pressure-sensitive labels without backing paper – the industry as a whole is demonstrating a willingness to adapt to the cultural and political drive towards environmentalism, regardless of the country of production.
<G-vec00095-002-s505><adapt.anpassen><de> Angesichts des globalen Trends zu trägerbandlosen Etiketten – drucksensitive Etiketten ohne Trägerpapier – beweist die Branche insgesamt ihre Bereitschaft, sich unabhängig vom Fertigungsland an das kulturelle und politische Streben nach Ressourcenschonung anzupassen.
<G-vec00095-002-s506><adapt.anpassen><en> In practice the alternative is even clearer: either Social Democracy must say pater peccavi to the patriotic bourgeoisie (as former young daredevils and present day old devotees in our ranks are already proclaiming contritely) and thus have to revise fundamentally all its tactics and principles, in peace-time as well as in war-time, in order to adapt to its present social-imperialist position; or the party will have to say pater peccavi to the international proletariat and adapt its behaviour during the war to its principles in peace-time.
<G-vec00095-002-s506><adapt.anpassen><de> Praktisch sieht die Alternative noch deutlicher aus: Entweder wird die Sozialdemokratie, wie ehemalige junge Draufgänger und heutige alte Betschwestern in unseren Reihen bereits reumütig ankündigen, vor der vaterländischen Bourgeoisie pater, peccavi sagen und auch im Frieden ihre ganze Taktik und ihre Grundsätze gründlich revidieren müssen, um sich ihrer heutigen sozialimperialistischen Position anzupassen, oder sie wird vor dem internationalen Proletariat pater, peccavi sagen und ihr Verhalten im Kriege ihren Prinzipien im Frieden anpassen müssen.
<G-vec00095-002-s507><adapt.anpassen><en> The connectors of the udoq cables can be adjusted in height to adapt to most protective cases.
<G-vec00095-002-s507><adapt.anpassen><de> Die Ladestecker der udoq Kabel können in der Höhe verstellt werden, um sich an die meisten Schutzhüllen anzupassen.
<G-vec00095-002-s508><adapt.anpassen><en> In order to maintain or raise the opening rates, it is essential for e-Mail marketers to adapt to the mobile trend.
<G-vec00095-002-s508><adapt.anpassen><de> Um die Öffnungsraten also weiterhin zu halten oder zu steigern, ist es für E-Mail-Marketer unumgänglich, sich an den mobilen Trend anzupassen.
<G-vec00095-002-s509><adapt.anpassen><en> Peru is home to thousands of species that continue to amaze the scientific world, especially the endemic species, whose beauty, peculiar features and ability to adapt to challenging climates make them a special attraction.
<G-vec00095-002-s509><adapt.anpassen><de> Peru beheimatet Tausende von Arten, die noch immer Überraschungen für die Wissenschaft bereithalten, vor allem die örtlich begrenzt auftretenden Spezies, deren Schönheit, charakteristische Merkmale und Fähigkeit, sich schwierigen klimatischen Bedingungen anzupassen, sie zu einer echten Attraktion machen.
<G-vec00095-002-s548><adapt.anpassen><en> It allows companies to adapt their presence to constantly increasing competition.
<G-vec00095-002-s548><adapt.anpassen><de> Unternehmen können so ihre Prozesse dem permanent steigenden Wettbewerbsdruck anpassen.
<G-vec00095-002-s549><adapt.anpassen><en> We are able to adapt our services to special requirements within a short time frame.
<G-vec00095-002-s549><adapt.anpassen><de> So können wir unsere Leistungen innerhalb kürzester Zeit den jeweiligen Anforderungen anpassen.
<G-vec00095-002-s550><adapt.anpassen><en> As farmers, we can be part of the solution and adapt and develop our farming systems to be more resilient to these changing environmental conditions.
<G-vec00095-002-s550><adapt.anpassen><de> Als Landwirte können wir Teil der Lösung sein und unsere Zucht- und Anbaumethoden so anpassen und weiterentwickeln, dass sie widerstandsfähiger gegenüber diesen sich verändernden Umgebungsbedingungen sind.
<G-vec00095-002-s551><adapt.anpassen><en> Unfortunately, I was never as flexible as you, which is why I could never adapt as you could.
<G-vec00095-002-s551><adapt.anpassen><de> Leider war ich nie so flexibel wie Du, weshalb ich mich auch nie so anpassen konnte wie Du das konntest.
<G-vec00095-002-s552><adapt.anpassen><en> Physicians can adapt therapies early and prevent the worsening of underlying conditions, stroke or hospitalizations. For the
<G-vec00095-002-s552><adapt.anpassen><de> So können Ärzte die Therapie frühzeitig anpassen und eine Verschlechterung von Grunderkrankungen sowie Schlaganfälle oder Hospitalisierungen verhindern.
<G-vec00095-002-s553><adapt.anpassen><en> By reacting quickly to notifications, we were able to follow up with patients exactly when they needed medical attention, and adapt their therapy accordingly,” said Dr. Peter Sogaard, Aalborg University Hospital, Denmark.
<G-vec00095-002-s553><adapt.anpassen><de> Indem wir rasch auf Meldungen reagiert haben, konnten wir uns genau zu dem Zeitpunkt um unsere Patienten kümmern, an dem eine Behandlung medizinisch erforderlich war, und so ihre Therapie entsprechend anpassen“, erläuterte Professor Dr. Peter Sogaard, Universitätsklink Aalborg, Dänemark.
<G-vec00095-002-s554><adapt.anpassen><en> Allows the operator permanent access to all settings, possibility to adapt settings according to the applications without having to go back to the machine.
<G-vec00095-002-s554><adapt.anpassen><de> Der Bediener hat so dauerhaften Zugang zu allen Einstellungen und kann diese je nach Anwendung anpassen ohne wieder zurück zur Maschine gehen zu müssen.
<G-vec00095-002-s555><adapt.anpassen><en> If you produce small quantities at regular intervals, you can adapt the template to these quantities.
<G-vec00095-002-s555><adapt.anpassen><de> Fertigen Sie in regelmäßigen Abständen eher geringe Stückzahlen, so können Sie die Schablone an diese Stückzahlen anpassen.
<G-vec00095-002-s556><adapt.anpassen><en> Considering that terrorists adapt their behaviour to avoid detection, detection methods currently used by security services are likely to be much less accurate.
<G-vec00095-002-s556><adapt.anpassen><de> In Anbetracht der Tatsache, dass Terroristen ihr Verhalten so anpassen, dass sie nicht entdeckt werden können, dürften die derzeit von Sicherheitsdiensten verwendeten Erkennungsmethoden weitaus weniger genau sein.
<G-vec00095-002-s557><adapt.anpassen><en> By means of the backup time schedules you can individually adapt the backup of the databases to your requirements.
<G-vec00095-002-s557><adapt.anpassen><de> Mit Hilfe der Backup-Zeitpläne können Sie so individuell das Backup der Datenbanken an Ihre Bedürfnisse anpassen.
<G-vec00095-002-s572><adapt.anpassen><en> We have and will always live in this environment and act and adapt accordingly.
<G-vec00095-002-s572><adapt.anpassen><de> Wir haben und werden immer in diesem Umfeld leben, entsprechend handeln und uns anpassen.
<G-vec00095-002-s573><adapt.anpassen><en> Nature is not something that we can control and therefore we need to adapt to the weather.
<G-vec00095-002-s573><adapt.anpassen><de> Die Natur ist nichts, was wir kontrollieren können, also müssen wir uns der Natur anpassen.
<G-vec00095-002-s574><adapt.anpassen><en> Because our business is constantly changing, we must adapt to the changing circumstances and set new goals and implement smarter solutions.
<G-vec00095-002-s574><adapt.anpassen><de> Da sich unser Geschäft ständig ändert, müssen wir uns an die neuen Umstände anpassen, neue Ziele setzen und intelligentere Lösungen implementieren.
<G-vec00095-002-s575><adapt.anpassen><en> But we had to adapt to the dogs as well.
<G-vec00095-002-s575><adapt.anpassen><de> Aber wir mussten uns genauso an die Hunde anpassen.
<G-vec00095-002-s576><adapt.anpassen><en> Unfortunately, we can not always choose, so we must adapt, so here are some tips for working effectively in open space.
<G-vec00095-002-s576><adapt.anpassen><de> Leider können wir nicht immer wählen, also müssen wir uns anpassen, deshalb hier ein paar Tipps für effektives Arbeiten im Freiraum.
<G-vec00095-002-s577><adapt.anpassen><en> Our extensive experience allows as to adapt precisely to your needs.
<G-vec00095-002-s577><adapt.anpassen><de> Mit unserer umfassenden Erfahrung können wir uns genau Ihren Anforderungen anpassen.
<G-vec00095-002-s578><adapt.anpassen><en> We are expected to adapt to the trends and try to stay one step ahead of our customer, their needs and perceptions.
<G-vec00095-002-s578><adapt.anpassen><de> Man erwartet von uns, dass wir uns allen Trends anpassen und den Ansprüchen und Bedürfnissen der Konsumenten immer einen Schritt voraus sind.
<G-vec00095-002-s579><adapt.anpassen><en> As we learn, adapt, and grow as a group, we want to hear from you.
<G-vec00095-002-s579><adapt.anpassen><de> Während wir als Gruppe lernen, uns anpassen und wachsen, möchten wir euer Feedback hören.
<G-vec00095-002-s580><adapt.anpassen><en> „NYSA” can adapt to and fully accept each customer's unique way of doing business.
<G-vec00095-002-s580><adapt.anpassen><de> Wir sind flexibel und können uns dem Kunde und seinem spezifischen Arbeitssystem anpassen.
<G-vec00095-002-s581><adapt.anpassen><en> So we’re not only able to lower costs and save time, but as well to adapt to the variable needs of our purchasers.
<G-vec00095-002-s581><adapt.anpassen><de> Wir sind somit nicht nur in der Lage Ihre Zeit und Ihre Kosten zu sparen, sondern können uns auch auf die veränderlichen Bedürfnisse unserer Kunden anpassen.
<G-vec00095-002-s582><adapt.anpassen><en> The economy has its own cycles and we need to adapt and respond to their stimuli.
<G-vec00095-002-s582><adapt.anpassen><de> Die Wirtschaft hat ihre eigenen Zyklen und wir müssen uns anpassen und auf ihre Reize reagieren.
<G-vec00095-002-s583><adapt.anpassen><en> As full-fledged technology enthusiasts, we work precisely and dutifully, following the principles of agile software development and can adapt spontaneously to your needs.
<G-vec00095-002-s583><adapt.anpassen><de> Als absolute Technikenthusiasten arbeiten wir exakt und pflichtbewusst, folgen den Prinzipien der agilen Softwareentwicklung und können uns spontan an Ihre Bedürfnisse anpassen.
<G-vec00095-002-s584><adapt.anpassen><en> We need to adapt.
<G-vec00095-002-s584><adapt.anpassen><de> Wir müssen uns anpassen.
<G-vec00095-002-s585><adapt.anpassen><en> Even if we have grown up, I do not think it means we can be motivated with compulsive orders or prohibitions (even if we might have learned to adapt to those).
<G-vec00095-002-s585><adapt.anpassen><de> Auch wenn wir längst volljährig, „erwachsen“, sind, heißt das doch nicht, dass uns zwanghafte Gebote und Verbote besser motivieren (auch wenn wir vielleicht inzwischen gelernt haben, uns dem vermeintlichen Zwang anzupassen).
<G-vec00095-002-s586><adapt.anpassen><en> What we all have in-common across all generations is the gift to learn,change, adapt and develop ourselves.
<G-vec00095-002-s586><adapt.anpassen><de> Was wir alle über alle Generationen hinweg gemeinsam haben, ist das Geschenk, uns selbst zu lernen, zu verändern, uns anzupassen und zu entwickeln.
<G-vec00095-002-s587><adapt.anpassen><en> Cookies enable a website, for instance, to adapt to your specific interests or to save your password so that it is not necessary to enter it again every time.
<G-vec00095-002-s587><adapt.anpassen><de> Cookies erlauben es uns beispielsweise, eine Webseite Ihren Interessen anzupassen oder Ihr Kennwort zu speichern, damit Sie es nicht jedes Mal neu eingeben müssen.
<G-vec00095-002-s588><adapt.anpassen><en> We know that this is a special situation, in which we are forced to adapt rapidly to new circumstances.
<G-vec00095-002-s588><adapt.anpassen><de> Wir wissen, dass es sich um eine besondere Situation handelt, in der wir gezwungen sind, uns schnell an neue Umstände anzupassen.
<G-vec00095-002-s589><adapt.anpassen><en> It gives us a better understanding of the people and the history of the countries we trade with. Experience gives us the ability to adapt to continuously changing political, economic and social situations.
<G-vec00095-002-s589><adapt.anpassen><de> Unsere Erfahrung im Umgang mit den Menschen und die Kenntnis der Geschichte der Länder, mit denen wir Handel betreiben, verleiht uns die nötige Expertise und die Flexibilität, uns dem stetigen politischen, ökonomischen und sozialen Wandel anzupassen.
<G-vec00095-002-s590><adapt.anpassen><en> Our intention is to build long term relationships with clients, understand closely their issues and adapt us to their needs.
<G-vec00095-002-s590><adapt.anpassen><de> Wir setzen auf eine langfristige Zusammenarbeit mit unseren Mandanten, um uns mit ihren Anliegen bestens vertraut zu machen und uns ihren Bedürfnissen anzupassen.
<G-vec00095-002-s591><adapt.anpassen><en> Since our earliest days we have always been eager to respond to your needs and adapt to your expectations.
<G-vec00095-002-s591><adapt.anpassen><de> Schon seit unseren frühen Anfängen war es immer unser Ziel, uns nach Ihren Wünschen zu richten und uns Ihren Erwartungen anzupassen.
<G-vec00095-002-s592><adapt.anpassen><en> In order to adapt to your needs, it was unfortunately necessary to send the telephone answering machine into quarantine.
<G-vec00095-002-s592><adapt.anpassen><de> Um uns Ihren Bedürfnissen anzupassen, war es leider notwendig den Anrufbeantworter in Quarantäne zu schicken.
<G-vec00095-002-s593><adapt.anpassen><en> The evaluations serve to recognise the reading habits of our users and to adapt the contents of our newsletters to them or to send different content according to the interests of our users.
<G-vec00095-002-s593><adapt.anpassen><de> Die Auswertungen dienen uns viel mehr dazu, die Lesegewohnheiten unserer Nutzer zu erkennen und unsere Inhalte auf sie anzupassen oder unterschiedliche Inhalte entsprechend den Interessen unserer Nutzer zu versenden.
<G-vec00095-002-s594><adapt.anpassen><en> Wherever possible, we will try to better adapt to your demands.
<G-vec00095-002-s594><adapt.anpassen><de> Wann immer möglich, werden wir versuchen unser Bestes, um uns Ihre Wünsche anzupassen.
<G-vec00095-002-s595><adapt.anpassen><en> "We have not seen money from rich countries to help us adapt.
<G-vec00095-002-s595><adapt.anpassen><de> „Wir haben von den reichen Ländern kein Geld gesehen, um uns zu helfen, uns anzupassen.
<G-vec00095-002-s596><adapt.anpassen><en> We have to learn to adapt, and move to get to that cheese.
<G-vec00095-002-s596><adapt.anpassen><de> Wir müssen lernen, uns anzupassen und in Bewegung zu setzen, um an diesen Käse zu gelangen.
<G-vec00095-002-s597><adapt.anpassen><en> As a small but thoroughly flexible company, we are in a position to adapt to the wishes of our customers and to develop individual special solutions.
<G-vec00095-002-s597><adapt.anpassen><de> Als kleines, aber überaus flexibles Unternehmen sind wir in der Lage, uns den Wünschen unserer Kunden anzupassen und individuelle Sonderlösungen zu entwickeln.
<G-vec00095-002-s598><adapt.anpassen><en> It will be easier to accept cultural differences, adapt (to) them, and benefit from a much broader perspective.
<G-vec00095-002-s598><adapt.anpassen><de> Mit solchem erhoehten Verstaendnis, wird es auch leichter mit den kulturellen Unterschieden umzugehen, uns anzupassen und so erfolgreich die sich daraus ergebende vergrößerte Sichtweise zu nutzen.
<G-vec00095-002-s599><adapt.anpassen><en> Such personal data collected in the tracking pixels contained in the newsletters are stored and analyzed by the controller in order to optimize the shipping of the newsletter, as well as to adapt the content of future newsletters even better to the interests of the data subject.
<G-vec00095-002-s599><adapt.anpassen><de> Solche über die in den Newslettern enthaltenen Zählpixel erhobenen personenbezogenen Daten, werden von uns gespeichert und ausgewertet, um den Newsletterversand zu optimieren und den Inhalt zukünftiger Newsletter noch besser Ihren Interessen anzupassen.
<G-vec00095-002-s600><adapt.anpassen><en> We love to adapt to the command of the enemy. Because it’s easier to understand how they play and which counter-attack will work.
<G-vec00095-002-s600><adapt.anpassen><de> Wir lieben es, uns dem Gegner anzupassen, da es so es einfacher ist zu verstehen, wie sie spielen und welcher Gegenangriff funktioniert.
<G-vec00095-002-s601><adapt.ändern><en> Its main feature is to actively and continuously control the response of the shock absorbers, which adapt depending on the movement of the car and the road conditions, as well as the driving style.
<G-vec00095-002-s601><adapt.ändern><de> Die wesentliche Aufgabe des Systems besteht darin, aktiv und ununterbrochen die Reaktion der Stoßdämpfer zu steuern, welche das eigene Verhalten auf Grundlage der Bewegungen des Fahrzeugaufbaus und der Straßenbedingungen ändern, wobei selbstverständlich die Anforderungen des Fahrers und sein Fahrstil berücksichtigt werden.
<G-vec00095-002-s602><adapt.ändern><en> HÔTEL DE CHARME NEIGE ET ROC reserves the right to adapt the data protection policy.
<G-vec00095-002-s602><adapt.ändern><de> HÔTEL DE CHARME NEIGE ET ROC behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s603><adapt.ändern><en> In this context it is pointed out that the examining division may not adapt the description of its own motion.
<G-vec00095-002-s603><adapt.ändern><de> In diesem Zusammenhang wird darauf hingewiesen, dass der Prüfer die Beschreibung nicht von Amts wegen ändern kann.
<G-vec00095-002-s604><adapt.ändern><en> SAS HOSTELLERIE DE LEVERNOIS reserves the right to adapt the data protection policy.
<G-vec00095-002-s604><adapt.ändern><de> SAS HOSTELLERIE DE LEVERNOIS behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s605><adapt.ändern><en> We reserve the right to adapt our data protection declaration to ensure that it always complies with the applicable legal requirements, especially in the event of changes to our services.
<G-vec00095-002-s605><adapt.ändern><de> Durch die Weiterentwicklung unserer Website und Angebote darüber oder aufgrund geänderter gesetzlicher beziehungsweise behördlicher Vorgaben kann es notwendig werden, diese Datenschutzerklärung zu ändern.
<G-vec00095-002-s606><adapt.ändern><en> SARL CARON reserves the right to adapt the data protection policy.
<G-vec00095-002-s606><adapt.ändern><de> SARL CARON behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s607><adapt.ändern><en> HÔTEL D reserves the right to adapt the data protection policy.
<G-vec00095-002-s607><adapt.ändern><de> La Villa Florentine behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s608><adapt.ändern><en> Hôtel Lyon Métropole reserves the right to adapt the data protection policy.
<G-vec00095-002-s608><adapt.ändern><de> Hôtel Lyon Métropole behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s609><adapt.ändern><en> Just go to Settings> Deals, and click the pencil next to the template you want to adapt under 'Templates for quotation content'.
<G-vec00095-002-s609><adapt.ändern><de> Gehen Sie ganz einfach zu Einstellungen > Deals, und klicken Sie unter ‚Templates für Angebotinhalt‘ auf den Stift neben der Vorlage, die Sie ändern wollen.
<G-vec00095-002-s610><adapt.ändern><en> As the company regularly organises customer events, it is particularly useful to adapt the access times in such a flexible way.
<G-vec00095-002-s610><adapt.ändern><de> Da das Unternehmen regelmäßig Events und Kundenveranstaltungen durchführt, ist die Möglichkeit, Zutrittszeiten flexibel zu ändern, besonders hilfreich.
<G-vec00095-002-s611><adapt.ändern><en> We are entitled to adapt moulds and tools which have been submitted to us to the extent that this seems necessary for technical reasons or in order to minimize risks, without prejudice to Buyer’s liability to submit only tools which are properly designed and manufactured for their intended use.
<G-vec00095-002-s611><adapt.ändern><de> Wir sind berechtigt, eingesandte Formeinrichtungen und Werkzeuge zu ändern, soweit dies aus technischen Gründen oder zwecks Verminderung des Risikos notwendig erscheint, unbeschadet der Haftung des Käufers für die richtige Konstruktion und die den Verwendungszweck sichernde Ausführung.
<G-vec00095-002-s612><adapt.ändern><en> In such a case please adapt your internet options or write your registration as a normal email to us.
<G-vec00095-002-s612><adapt.ändern><de> In einem solchen Fall ändern Sie bitte Ihre Internetoptionen oder schreiben Sie kurz Ihren Aufnahmewunsch als E-Mail.
<G-vec00696-002-s279><adapt.einstellen><en> We can adapt the keys’ path to the artist’s preferences.
<G-vec00696-002-s279><adapt.einstellen><de> Wir können den Tastenweg nach den Vorlieben des Künstlers einstellen.
<G-vec00696-002-s280><adapt.einstellen><en> The saying "When in Rome, do as the Romans do" clearly expresses how the business must adapt its actions, its strategies and its thinking, to the prevailing general conditions, in order to be successful.
<G-vec00696-002-s280><adapt.einstellen><de> Der Ausspruch "Andere Länder, andere Sitten" bringt hier sehr deutlich zum Ausdruck, dass die Wirtschaft ihr Handeln, ihre Strategien, ihr Denken auf die jeweils vorherrschenden Rahmenbedingungen einstellen muss, um erfolgreich zu sein.
<G-vec00696-002-s281><adapt.einstellen><en> “Although racing is often the best way of helping out, I’ve been out there a few times just to be on hand to help the drivers on how to address set-up problems, and to adapt the car to the very special circuits that the China championship races at.
<G-vec00696-002-s281><adapt.einstellen><de> „Obwohl man in den Rennen am meisten lernt, war ich ein paar Mal dort um den Fahrern bei ihren Abstimmungs-Problemen zu helfen und habe ihnen gezeigt, wie sie die Autos für die sehr speziellen Strecken der chinesischen Meisterschaft einstellen müssen.“ „Für mich ist China ein ganz besonderer Ort.
<G-vec00696-002-s282><adapt.einstellen><en> It will also help us better adapt and plan for change.
<G-vec00696-002-s282><adapt.einstellen><de> So können wir uns auch besser auf Veränderungen einstellen und entsprechend planen.
<G-vec00696-002-s283><adapt.einstellen><en> Together with the regions Abtenau, Bad Reichenhall and Tegernsee and the Ludwig-Maximilians-University Munich as well as the University of Applied Sciences Munich and the Innovation and Technology Transfer Salzburg (ITG), the EU project Trail for Health Nord is investigating how health-oriented tourism providers can adapt to the needs of an aging society with increasing urbanisation.
<G-vec00696-002-s283><adapt.einstellen><de> Zusammen mit den Regionen Abtenau, Bad Reichenhall und Tegernsee und mit der Ludwig-Maximilians-Universität München sowie der Hochschule München und dem Innovations- und Technologietransfer Salzburg (ITG) wird im Rahmen des EU-Projektes Trail for Health Nord untersucht, wie sich gesundheitsorientierte Tourismusanbieter auf die Bedürfnisse einer älter werdenden Gesellschaft mit zunehmender Urbanisierung einstellen können.
<G-vec00696-002-s284><adapt.einstellen><en> Requirements that we are prepared to respond and adapt to over and over again.
<G-vec00696-002-s284><adapt.einstellen><de> Anforderungen, auf die wir uns sehr genau eingestellt haben und auch immer wieder neu einstellen werden.
<G-vec00696-002-s285><adapt.einstellen><en> Our customer, a Middle East retail conglomerate, was about to launch an IPO, and needed to adapt itself to the stricter requirements for a capital market-oriented company.
<G-vec00696-002-s285><adapt.einstellen><de> Unser Kunde, ein Handelskonglomerat im Mittleren Osten, stand vor einem IPO und musste sich daher auf die erhöhten Anforderungen eines kapitalmarktorientierten Unternehmens einstellen.
<G-vec00696-002-s286><adapt.einstellen><en> Please remember that you must separately adapt the settings for each browser and computer you use.
<G-vec00696-002-s286><adapt.einstellen><de> Denken Sie daran, dass Sie die Konfiguration jedes Browsers und Geräts, die Sie nutzen, einzeln einstellen müssen.
<G-vec00696-002-s287><adapt.einstellen><en> An accelerated digital transformation has become necessary for us to be able to adapt more thoroughly to the complex requirements of our customers in the B2B environment.
<G-vec00696-002-s287><adapt.einstellen><de> Um uns zukünftig noch intensiver auf die komplexen Anforderungen unserer Kunden im B2B Umfeld einstellen zu können, ist eine beschleunigte digitale Transformation notwendig geworden.
<G-vec00696-002-s288><adapt.einstellen><en> The ritualists of the past could adapt themselves to the larger rhythms of the solar system, the zodiac, and even the groups of solar systems such as the Great Bear, the Pleiades, and Sirius, without using astronomical instruments.
<G-vec00696-002-s288><adapt.einstellen><de> Die Ritualisten der Vergangenheit konnten sich auf die größeren Rhythmen des Sonnensystems, des Tierkreises und gar der Gruppen von Sonnensystemen wie dem Grossen Bären, den Plejaden und Sirius einstellen, ohne astronomische Instrumente zu verwenden.
<G-vec00696-002-s289><adapt.einstellen><en> Increasingly customized products go hand in hand with increasingly complex processes – and, in turn, the way we handle goods also needs to adapt.
<G-vec00696-002-s289><adapt.einstellen><de> Immer individuellere Produkte gehen einher mit immer komplexeren Prozessen – und darauf muss sich auch die Handhabung der Güter einstellen.
<G-vec00696-002-s290><adapt.einstellen><en> Ladies and Gentlemen, networking via the Internet is a global trend, which we not only have to adapt to, but which we are actively shaping.
<G-vec00696-002-s290><adapt.einstellen><de> Meine Damen und Herren, die Vernetzung über das Internet ist ein globaler Trend, auf den wir uns nicht nur einstellen müssen, sondern den wir auch aktiv gestalten.
<G-vec00696-002-s291><adapt.einstellen><en> Especially in the upcoming BRIC countries (Brazil, Russia, India and China) the manufacturers will have to adapt to the increased quality requirements of the customers.
<G-vec00696-002-s291><adapt.einstellen><de> Vor allem in den aufstrebenden BRIC-Staaten (Brasilien, Russland, Indien und China) würden sich Hersteller auf gestiegene Qualitätsansprüche der Kunden einstellen müssen.
<G-vec00696-002-s292><adapt.einstellen><en> What seems to be incomprehensible to man he would, seen in the light of the spiritual, well be able to grasp, and also only on the way of the spiritual it is possible to give him clarity because his train of thought can only then be steered so, that one after the other becomes intelligible, that he now can adapt himself positively to that what he formerly thought of as unacceptable.
<G-vec00696-002-s292><adapt.einstellen><de> Was dem Menschen unbegreiflich erscheint, würde er, im Licht des Geistigen besehen, wohl zu fassen vermögen, und es ist auch nur auf dem Wege des Geistigen möglich, ihm Klarheit zu geben, denn sein Gedankengang kann erst dann so gelenkt werden, daß ihm eines nach dem anderen verständlich wird, daß er sich nun bejahend zu dem einstellen kann, was er vordem für unannehmbar hielt.
<G-vec00696-002-s294><adapt.einstellen><en> We are specialists who are able to quickly adapt to the different requirements of the customers.
<G-vec00696-002-s294><adapt.einstellen><de> Wir sind Spezialisten, die sich schnell auf die unterschiedlichen Anforderungen der Kunden einstellen.
<G-vec00696-002-s295><adapt.einstellen><en> As you continually work on your own personal development and become better able to adapt to unpredictable wilderness conditions, this directly impacts your growth as a guide and your future guests’ overall experience.
<G-vec00696-002-s295><adapt.einstellen><de> Weil Sie die ganze Zeit an Ihrer persönlichen Entwicklung arbeiten und sich daher immer besser auf unerwartete Gegebenheiten in der Wildnis einstellen können, hat dies einen direkten Einfluss auf Ihre persönliche Entwicklung als Guide und auf das Erlebnis Ihrer Gäste.
<G-vec00696-002-s510><adapt.einstellen><en> Digital is everywhere – and businesses must either adapt to this new market reality or risk falling behind.
<G-vec00696-002-s510><adapt.einstellen><de> Wenn Unternehmen nicht Gefahr laufen wollen, ins Hintertreffen zu geraten, müssen sie sich auf diese neue Realität einstellen.
<G-vec00696-002-s511><adapt.einstellen><en> Driving instructors who can adapt to the needs of each individual student are particularly popular.
<G-vec00696-002-s511><adapt.einstellen><de> FahrlehrerInnen, die sich auf die Bedürfnisse jedes einzelnen Fahrschülers einstellen können, sind besonders beliebt.
<G-vec00696-002-s512><adapt.einstellen><en> Yet even if traders and markets adapt quickly to the new situation, the low level of volatility seen in 2017 remains unusual.
<G-vec00696-002-s512><adapt.einstellen><de> Auch wenn sich der Handel und die Märkte schnell auf die neue Lage einstellen – ein Phänomen bleibt das niedrige Volatilitätsniveau von 2017 dennoch.
<G-vec00696-002-s513><adapt.einstellen><en> Our long-standing and trusted customer relationships based on our performance and target-oriented approach, which we constantly and timely adapt to the ever-changing need for advice.
<G-vec00696-002-s513><adapt.einstellen><de> Unsere langjährigen und vertrauensvollen Kundenbeziehungen basieren auf unserer leistungs- und zielorientierten Arbeitsweise, die wir permanent und zeitgemäß auf den sich ständig wandelnden Beratungsbedarf einstellen.
<G-vec00696-002-s514><adapt.einstellen><en> Power grid operators must adapt to a changing system with a high proportion of fluctuating renewable energy.
<G-vec00696-002-s514><adapt.einstellen><de> Stromnetzbetreiber müssen sich auf ein verändertes System mit hohem Anteil fluktuierender erneuerbarer Energie einstellen.
<G-vec00696-002-s515><adapt.einstellen><en> As a result, you can adapt to the weather in S. Maddalena / St. Magdalena and surroundings every day and plan accordingly for your day.
<G-vec00696-002-s515><adapt.einstellen><de> So können Sie sich täglich auf das Wetter in St. Magdalena und Umgebung einstellen und Ihren Urlaubstag dementsprechend planen.
<G-vec00696-002-s516><adapt.einstellen><en> In many companies staff development has to adapt to the needs of multicultural workforces and international locations.
<G-vec00696-002-s516><adapt.einstellen><de> In vielen Unternehmen muss sich die Personalentwicklung auf die Bedürfnisse multikultureller Belegschaften und internationaler Standorte einstellen.
<G-vec00696-002-s517><adapt.einstellen><en> Today, companies need to adapt even faster to changing market situations.
<G-vec00696-002-s517><adapt.einstellen><de> Immer schneller müssen sich Unternehmen auf geänderte Marktsituationen einstellen.
<G-vec00696-002-s518><adapt.einstellen><en> In any case, FC Bayern now quickly needs to adapt to a BVB that does not run into traps as often as the team under Bosz did.
<G-vec00696-002-s518><adapt.einstellen><de> Der FC Bayern darf sich kurzfristig jedenfalls auf einen BVB einstellen, der nicht so sehr ins offene Messer läuft wie es die Mannschaft unter Bosz noch häufig tat.
<G-vec00696-002-s519><adapt.einstellen><en> <When you take for a certain time a digestion enzyme with the meals, then organism can adapt more easily to the concentrated proteins.
<G-vec00696-002-s519><adapt.einstellen><de> "Wenn Sie eine Zeit lang ein Verdauungsenzym zu den Malzeiten einnehmen, kann sich der Organismus leichter auf die konzentrierten Proteine einstellen.
<G-vec00696-002-s520><adapt.einstellen><en> Science and industry have to adapt to one another in this respect.
<G-vec00696-002-s520><adapt.einstellen><de> Hier müssen sich Wissenschaft und Wirtschaft aufeinander einstellen.
<G-vec00696-002-s521><adapt.einstellen><en> There are many tools on the market that cannot adapt individually enough to the goals of your company.
<G-vec00696-002-s521><adapt.einstellen><de> Es gibt viele Tools auf dem Markt die sich nicht individuell genug auf die Ziele Ihres Unternehmens einstellen können.
<G-vec00696-002-s522><adapt.einstellen><en> For the first time, the long-range radar now operates independently of the set driving level and is able to adapt continuously to changing inclination of the vehicle as a result of suspension or load statuses.
<G-vec00696-002-s522><adapt.einstellen><de> Der Fernbereichsradar arbeitet nun erstmals unabhängig vom eingestellten Fahrniveau und kann sich permanent auf veränderte Fahrzeugneigung aufgrund von Fahrwerks- oder Beladungszuständen einstellen.
<G-vec00696-002-s523><adapt.einstellen><en> She was able to adapt to the horse and rider quickly and analyze their problems precisely.
<G-vec00696-002-s523><adapt.einstellen><de> Sie konnte sich schnell auf die Schüler und Pferde einstellen und deren präzise Probleme analysieren.
<G-vec00696-002-s524><adapt.einstellen><en> Success often depends on being able to quickly adapt to new situations.
<G-vec00696-002-s524><adapt.einstellen><de> Oftmals hängt der Erfolg von der Fähigkeit ab, sich schnell auf neue Situationen einstellen zu können.
<G-vec00696-002-s525><adapt.einstellen><en> Share your treatment requirements with us as soon as possible and the Larimar team will adapt to your personal needs.
<G-vec00696-002-s525><adapt.einstellen><de> Teilen Sie uns Ihre Behandlungswünsche möglichst frühzeitig mit, damit sich das Larimar-Team optimal auf Sie einstellen kann.
<G-vec00696-002-s526><adapt.einstellen><en> In order to achieve this performance, you'll need to find the shoes that best adapt to your needs in function of the modalities that you practise.
<G-vec00696-002-s526><adapt.einstellen><de> Um diese Leistungsfähigkeit zu erreichen solltest du dich für die Schuhe entscheiden, die sich am besten auf deine Bedürfnisse und auch auf deine spezielle Kategorie einstellen.
<G-vec00696-002-s527><adapt.einstellen><en> For CMOs it turned out that in future they will need to adapt to the needs of their inhomogeneous customers groups (big pharma vs. small biotech) in order to react flexibly in terms of serialization.
<G-vec00696-002-s527><adapt.einstellen><de> Für Lohnverpacker zeigte sich, dass sich diese in Zukunft unterschiedlichen Bedürfnisse ihrer inhomogenen Kundengruppen (Big Pharma vs. Kleine Biotechunternehmen) einstellen und hier sehr flexibel reagieren können müssen.
<G-vec00696-002-s528><adapt.einstellen><en> In her view, effective movements – including the climate movement – require key figures that can mediate, adapt to the cultural codes of different societal groups and are able to convincingly present and explain the goals of the movement.
<G-vec00696-002-s528><adapt.einstellen><de> Aus ihrer Sicht sind für das Wirksamwerden etwa der Klimabewegung Schlüsselfiguren wichtig, die vermitteln, sich auf die unterschiedlichen kulturellen Codes gesellschaftlicher Gruppen einstellen können und die Anliegen der Bewegung überzeugend darstellen und erzählen können.
<G-vec00696-002-s529><adapt.einstellen><en> Rather, it is vital that we adapt to the culture, expectations, and possibilities of our individual partners.
<G-vec00696-002-s529><adapt.einstellen><de> Wichtig ist es, sich auf Kultur, Erwartungshaltung und Möglichkeiten des jeweiligen Partners einzustellen.
<G-vec00696-002-s530><adapt.einstellen><en> It is therefore absolutely essential for companies to adapt to new opportunities for dialog and to develop appropriate strategies.
<G-vec00696-002-s530><adapt.einstellen><de> Für Unternehmen ist es daher zwingend erforderlich, sich auch auf neue Dialogmöglichkeiten einzustellen und entsprechende Strategien zu entwickeln.
<G-vec00696-002-s531><adapt.einstellen><en> It is very easy for them to learn the ropes of complex issues and to adapt to new corporate cultures with ever new assignment.
<G-vec00696-002-s531><adapt.einstellen><de> Es fällt ihnen sehr leicht, sich in komplexe Sachverhalte einzuarbeiten und sich bei jedem Einsatz auf eine andere Unternehmenskultur einzustellen.
<G-vec00696-002-s532><adapt.einstellen><en> You are the first point of contact and even in stressful day-to-day business you are constantly challenged to adapt to the different callers and their needs.
<G-vec00696-002-s532><adapt.einstellen><de> Sie sind die erste Kontaktperson und auch im stressigen Tagesgeschäft immer wieder gefordert, sich auf die unterschiedlichen Anrufer mit ihren Bedürfnissen einzustellen.
<G-vec00696-002-s533><adapt.einstellen><en> Apart from innovative solutions and the high level of expertise, business partners appreciate ECG s ability to adapt flexibly to new conditions and to support the development of business processes.
<G-vec00696-002-s533><adapt.einstellen><de> Geschäftspartner schätzen neben den innovativen Softwarelösungen und der Fachexpertise der ECG insbesondere die Fähigkeit, sich auf neue Rahmenbedingungen flexibel einzustellen und bei der Entwicklung von Geschäftsprozessen beratend zur Seite zu stehen.
<G-vec00696-002-s534><adapt.einstellen><en> I think Evonik has the flexibility to adapt to the needs and wishes of their employees and to offer opportunity to develop and grow.
<G-vec00696-002-s534><adapt.einstellen><de> Ich denke, Evonik hat die Flexibilität, sich auf die Wünsche und Bedürfnisse seiner Mitarbeitenden einzustellen und ihnen Entwicklungs- und Wachstumsmöglichkeiten anzubieten.
<G-vec00696-002-s535><adapt.einstellen><en> This was combined with the self-transformation of our systematic rank-and-file work in order to adapt them to the tasks in class struggle that lie ahead.
<G-vec00696-002-s535><adapt.einstellen><de> Das durchdrang sich mit der Selbstveränderung unserer Kleinarbeit, um sie auf die bevorstehenden Aufgaben im Klassenkampf einzustellen.
<G-vec00696-002-s536><adapt.einstellen><en> Service quality: you assist your customers to develop an efficient energy management system and are able to adapt to your customers’ requirements from an early stage.
<G-vec00696-002-s536><adapt.einstellen><de> Servicequalität: Sie unterstützen Ihre Kunden beim Aufbau eines effizienten Energiemanagements und lernen frühzeitig, sich auf Kundenanforderungen einzustellen.
<G-vec00696-002-s537><adapt.einstellen><en> – being able to adapt to the needs of people with mental disabilities, in order to offer them the right support
<G-vec00696-002-s537><adapt.einstellen><de> – in der Lage zu sein, sich auf die Bedürfnisse von Menschen mit kognitiven Einschränkungen einzustellen um ihnen angemessene Unterstützung zu bieten.
<G-vec00696-002-s538><adapt.einstellen><en> These statistics indicate how critical it is for marketers to adapt to the rapidly changing range of consumer behaviors, preferences and expectations.
<G-vec00696-002-s538><adapt.einstellen><de> Diese Statistik zeigt, wie wichtig es für Marketingverantwortliche ist, sich auf die stark variierenden Verhaltensweisen, Vorlieben und Erwartungen des Verbrauchers einzustellen.
<G-vec00696-002-s539><adapt.einstellen><en> The Luxxamed has the ability to learn by the application on the patient and thus adapt to the different states."
<G-vec00696-002-s539><adapt.einstellen><de> Der Luxxamed hat die Fähigkeit, durch die Anwendung am Patienten zu lernen und sich somit auf die unterschiedlichen Zustände einzustellen.
<G-vec00696-002-s540><adapt.einstellen><en> With task forces on start-ups, industry internationalization, and business opportunities in the energy transition the network, managed by DWR eco CEO David Wortmann, helps clean tech companies adapt to rapidly changing market conditions.
<G-vec00696-002-s540><adapt.einstellen><de> Mit Task Forces für Start-Ups, zur Internationalisierung der Branche und zu den Geschäftschancen der Energiewende hilft das von DWR eco Geschäftsführer David Wortmann gemanagte Netzwerk Unternehmen der Cleantech-Branche sich auf die rasant ändernden Marktbedingungen einzustellen.
<G-vec00696-002-s541><adapt.einstellen><en> We know that redevelopment is a dynamic process in which it is necessary to adapt to constantly occurring changes.
<G-vec00696-002-s541><adapt.einstellen><de> Wir wissen, dass Sanierung ein dynamischer Prozess ist, in dem es erforderlich ist, sich auf stetig eintretende Veränderungen einzustellen.
<G-vec00696-002-s542><adapt.einstellen><en> Our ‘Convenience in Europe’ study series offers suppliers of convenience products the opportunity to adapt better to the desires and needs of their customers.
<G-vec00696-002-s542><adapt.einstellen><de> Unsere Studienreihe ’Convenience in Europa’ gibt Anbietern von Convenience-Produkten die Möglichkeit, sich noch besser auf die Wünsche und Bedürfnisse ihrer Kunden einzustellen.
<G-vec00696-002-s543><adapt.einstellen><en> As a service contractor, you need the ability to adapt quickly to whatever your customers are asking for.
<G-vec00696-002-s543><adapt.einstellen><de> Als Dienstleister müssen Sie in der Lage sein, sich schnell auf die Anforderungen Ihrer Kunden einzustellen.
<G-vec00696-002-s544><adapt.einstellen><en> By combining a world-class storage R&D team with a commitment to customer satisfaction, Thecus is able to adapt to the market with its innovative NAS and NVR and fulfill the storage and surveillance needs of
<G-vec00696-002-s544><adapt.einstellen><de> Durch die Kombination eines Weltklasse-R&D-Teams für Speicherlösungen mit der Selbstverpflichtung, Kunden zufriedenzustellen, ist Thecus in der Lage, sich mit seinen innovativen NAS und NVR auf die Bedürfnisse des Marktes einzustellen und so die Speicher- und Kontroll-Anforderungen von heute zu erfüllen.
<G-vec00696-002-s545><adapt.einstellen><en> The most successful companies are able to adapt to rapidly changing market conditions.
<G-vec00696-002-s545><adapt.einstellen><de> Die erfolgreichsten Unternehmen sind in der Lage sich auf schnell verändernde Marktbedingungen einzustellen.
<G-vec00696-002-s546><adapt.einstellen><en> They are challenged to adapt to complex and “colourful” CVs.
<G-vec00696-002-s546><adapt.einstellen><de> Sie sind gefordert sich auf vielschichtige und „bunte“ Lebensläufe einzustellen.
<G-vec00696-002-s547><adapt.einstellen><en> In a club the DJ is the boss, the VJ tries to follow the beat of the music and adapt to the style of the pieces.
<G-vec00696-002-s547><adapt.einstellen><de> Im Club ist der DJ der Chef, der VJ versucht, dem Beat der Musik zu folgen und sich auf den Stil der Stücke einzustellen.
<G-vec00696-002-s348><adapt.passen><en> WC and Wash Basins adapt to the most different of needs at the touch of a button.
<G-vec00696-002-s348><adapt.passen><de> WC und Waschtische passen sich auf Knopfdruck den unterschiedlichsten Bedürfnissen an.
<G-vec00696-002-s349><adapt.passen><en> The soft rubber sides adapt to the contours of your teeth and gums to absorb excessive pressure.
<G-vec00696-002-s349><adapt.passen><de> Die weichen Seiten aus Gummi passen sich den Konturen deiner Zähne und des Zahnfleischs an, um so übermässigen Druck zu absorbieren.
<G-vec00696-002-s350><adapt.passen><en> There is a light blue and pink version of it and both shades adapt perfectly to the skin’s tone.
<G-vec00696-002-s350><adapt.passen><de> Es gibt ihn in hellblau oder rosa und beide Farben passen sich der Haut sehr gut an.
<G-vec00696-002-s352><adapt.passen><en> Our services adapt efficiently to your business needs and drive the right business outcomes for your company.
<G-vec00696-002-s352><adapt.passen><de> Unsere Services passen sich effizient an Ihre Geschäftsanforderungen an und fördern die richtigen Ergebnisse für Ihr Unternehmen.
<G-vec00696-002-s353><adapt.passen><en> The different sipes flexibly adapt to all weather variations, offering relentless grip and enjoyably controlled and quiet driving.
<G-vec00696-002-s353><adapt.passen><de> Die unterschiedlichen Lamellen passen sich flexibel an alle Wetterumschwünge an und stellen so kompromisslosen Grip, kontrollierten Fahrspaß und eine ruhige Fahrt sicher.
<G-vec00696-002-s354><adapt.passen><en> With power outputs of 250 or 500 Watt, the UMC generators are able to optimally adapt to individual cleaning requirements.
<G-vec00696-002-s354><adapt.passen><de> Die UMC Generatoren passen sich dabei mit 250 oder 500 Watt Leistung optimal an individuelle Reinigungsanforderungen an.
<G-vec00696-002-s355><adapt.passen><en> The high speed ICE stations Limburg and Montabaur adapt impressively into trans-European networks.
<G-vec00696-002-s355><adapt.passen><de> Die ICE-Bahnhöfe Limburg und Montabaur passen sich „eindrucksvoll“ in transeuropäische Netze ein.
<G-vec00696-002-s356><adapt.passen><en> The manufactured products adapt perfectly to the needs of your production, amplifying the performances in each phase.
<G-vec00696-002-s356><adapt.passen><de> Die realisierten Produkte passen sich den Anforderungen Ihrer Produktion perfekt an und verbessern zudem in jedem Stadium ihre Leistung.
<G-vec00696-002-s357><adapt.passen><en> They adapt excellently to their respective environment, and they existed long before humans.
<G-vec00696-002-s357><adapt.passen><de> Sie passen sich ihrer jeweiligen Umgebung hervorragend an, und es gab sie schon lange vor dem Menschen.
<G-vec00696-002-s358><adapt.passen><en> Due to its elegant and light design and the streamlined orientation the outdoor furniture collection Alize easily adapt to a variety of furnishings.
<G-vec00696-002-s358><adapt.passen><de> Aufgrund ihres elegant schlichten Designs und der stromlinienförmigen Ausrichtung passen sich die Möbel der Outdoor Kollektion Alize problemlos einer Vielzahl von Umgebungen an.
<G-vec00696-002-s359><adapt.passen><en> As a result jackets that use hydrophilic membranes adapt to your activity level and retain heat well.
<G-vec00696-002-s359><adapt.passen><de> Aus diesem Grund passen sich Jacken mit hydrophilen Membranen deinem Aktivitätsniveau an und speichern hervorragend Wärme.
<G-vec00696-002-s360><adapt.passen><en> Nearly a billion shorter fibers adapt to your movements to create our pillow’s signature springy support.
<G-vec00696-002-s360><adapt.passen><de> Fast eine Milliarde winzig kleiner Fasern im inneren Kissen passen sich deinen Bewegungen an und sorgen für angenehm federnde Unterstützung.
<G-vec00696-002-s361><adapt.passen><en> Personalizable front panels and individual appearance adapt flexible to the CI and the application site.
<G-vec00696-002-s361><adapt.passen><de> Personalisierbare Fronten und individuelle Erscheinung passen sich der CI und dem Einsatzort flexibel an.
<G-vec00696-002-s362><adapt.passen><en> The MEX gooseneck microphones with their numerous mounting accessories adapt perfectly to any environment.
<G-vec00696-002-s362><adapt.passen><de> Die MEX-Schwanenhalsmikrofone mit ihrem zahlreichen Montagezubehör passen sich jeder Umgebung bestens an.
<G-vec00696-002-s363><adapt.passen><en> Made from high-quality, soft materials, they adapt perfectly to the changes in your figure, ensuring that you feel comfortable.
<G-vec00696-002-s363><adapt.passen><de> Aus hochwertigen, weichen Materialien passen sie sich den Veränderungen der Figur perfekt an und sorgen so für Ihr Wohlgefühl.
<G-vec00696-002-s364><adapt.passen><en> Most adapt as fast as any other employee, some need more time and adapt gradually.
<G-vec00696-002-s364><adapt.passen><de> Die meisten passen sich so schnell wie jeder andere Mitarbeiter an, einige brauchen mehr Zeit und passen sich gradweise an.
<G-vec00696-002-s366><adapt.passen><en> Minimize delays and adapt to unforeseen circumstances with real-time monitoring of operations.
<G-vec00696-002-s366><adapt.passen><de> Durch Echtzeitüberwachung der Betriebe minimieren Sie Verspätungen und passen sich unvorhergesehenen Umständen an.
<G-vec00696-002-s396><adapt.reagieren><en> In all these areas, ever-increasing competitive and price pressures necessitate streamlined processes, increased productivity, and reduced costs, not to mention a high level of flexibility to adapt to future requirements.
<G-vec00696-002-s396><adapt.reagieren><de> Der stetig wachsende Wettbewerbs- und Kostendruck in diesen Bereichen erfordert es Prozesse zu optimieren, die Produktivität zu steigern, Kosten zu senken und zugleich sehr flexibel auf künftige Anforderungen reagieren zu können.
<G-vec00696-002-s397><adapt.reagieren><en> Thanks to our cancellation period of only 14 days, you are able to adapt your rental period to suit your ever-changing needs.
<G-vec00696-002-s397><adapt.reagieren><de> Dank unserer Kündigungsfrist von lediglich 14 Tagen können Sie stets uneingeschränkt auf neue Lebensereignisse reagieren.
<G-vec00696-002-s398><adapt.reagieren><en> Adapt quickly to changing demands (sensor types, regulatory and compliance changes) with support for open source hooks for hardware and software.
<G-vec00696-002-s398><adapt.reagieren><de> Reagieren Sie schnell auf sich ändernde Anforderungen (Sensortypen, behördliche Auflagen und Complianceänderungen) mit Unterstützung für Open-Source-Hooks für Hardware und Software.
<G-vec00696-002-s399><adapt.reagieren><en> Thanks to the sensors on the soles of the feet, for example, H-1 is able to adapt to uneven ground and even balance on one leg.
<G-vec00696-002-s399><adapt.reagieren><de> So kann H-1 beispielsweise dank der Sensoren an den Fußsohlen auf Unebenheiten im Boden reagieren und sogar auf einem Bein balancieren.
<G-vec00696-002-s400><adapt.reagieren><en> Resilience is the body's ability to adapt to certain stimuli.
<G-vec00696-002-s400><adapt.reagieren><de> Belastbarkeit ist die Anpassungsfähigkeit des Körpers, um auf bestimmte Reize zu reagieren.
<G-vec00696-002-s401><adapt.reagieren><en> Even the infamous Annie Bot won't adapt to your strategies the same way a real, human opponent would.
<G-vec00696-002-s401><adapt.reagieren><de> Selbst der berüchtigte Annie-Bot wird nicht auf die gleiche Weise auf eure Strategien reagieren, wie es ein realer, menschlicher Gegenspieler täte.
<G-vec00696-002-s402><adapt.reagieren><en> As a result, the company can adapt itself flexibly to future customers with still unknown products.
<G-vec00696-002-s402><adapt.reagieren><de> Somit ist DHL flexibel, um auf künftige Kunden mit noch unbekannten Produkten reagieren zu können.
<G-vec00696-002-s403><adapt.reagieren><en> This means that we can adapt to changes of any nature quickly and flexibly.
<G-vec00696-002-s403><adapt.reagieren><de> Dank kurzer Kommunikationswege in ungezwungener Betriebsatmosphäre können wir schnell und flexibel auf Veränderungen jeglicher Art reagieren.
<G-vec00696-002-s404><adapt.reagieren><en> We also have to commit to a culture of lifelong learning so that people can adapt more quickly and more successfully to an ever changing environment.
<G-vec00696-002-s404><adapt.reagieren><de> Wir müssen zudem eine Kultur des lebenslangen Lernens verankern, damit Menschen schneller und besser auf ein sich wandelndes Umfeld reagieren können.
<G-vec00696-002-s405><adapt.reagieren><en> Quickly adapt to industry challenges such as market volatility, complex supply chains, and shrinking budgets – with SAP software for aerospace companies and defense contractors.
<G-vec00696-002-s405><adapt.reagieren><de> Reagieren Sie schnell auf die Herausforderungen Ihrer Branche, zum Beispiel auf Marktschwankungen, komplexe Logistikketten und schrumpfende Budgets – mit SAP-Software für Unternehmen der Luft- und Raumfahrtindustrie.
<G-vec00696-002-s406><adapt.reagieren><en> Now, the fashion company has full control over the shop system and can easily and quickly adapt to shifting market conditions.
<G-vec00696-002-s406><adapt.reagieren><de> So besitzt das Modeunternehmen die 100%-ige Hoheit über das Shopsystem und kann schnell und agil auf veränderte Marktgegebenheiten reagieren.
<G-vec00696-002-s407><adapt.reagieren><en> CROs and senior risk executives are being challenged to adapt to the rapidly changing business environment.
<G-vec00696-002-s407><adapt.reagieren><de> Geschäftsleitung und Führungskräfte des Risikomanagements sind ständig gefordert, schnell auf den dynamischen Wandel zahlloser regulatorischer Kontextfaktoren zu reagieren.
<G-vec00696-002-s408><adapt.reagieren><en> In today’s world, everything is constantly changing. We must be ready to constantly adapt to change.
<G-vec00696-002-s408><adapt.reagieren><de> In der heutigen Welt ist alles im Fluss, und wir müssen ständig auf Veränderungen reagieren.
<G-vec00696-002-s409><adapt.reagieren><en> However, house prices adapt in the short-run dynamically to economic, financial, institutional and demographic factors.
<G-vec00696-002-s409><adapt.reagieren><de> Allerdings reagieren Immobilienpreise auch auf ökonomische, finanzielle, institutionelle und demographische Veränderungen.
<G-vec00696-002-s410><adapt.reagieren><en> Subcontractor Through cooperation with a variety of trucking subcontractors, Ewals Cargo care has an extensive network that can adapt to changes within the market.
<G-vec00696-002-s410><adapt.reagieren><de> Subunternehmer Durch Kooperationen mit einer Vielzahl an Frachtfuhrunternehmen besitzt Ewals Cargo Care ein umfangreiches Netzwerk, das auf Änderungen innerhalb des Marktes reagieren kann.
<G-vec00696-002-s411><adapt.reagieren><en> To survive, the bacterium must have the ability to adapt to the changing conditions.
<G-vec00696-002-s411><adapt.reagieren><de> Um zu überleben, muss das Bakterium auf die wechselnden Bedingungen reagieren können.
<G-vec00696-002-s412><adapt.reagieren><en> Without being able to learn informally, employees will hardly be successful in companies which have to adapt quickly to innovations, new technologies, new customer requirements and new product cycles.
<G-vec00696-002-s412><adapt.reagieren><de> Ohne diese Fähigkeit zum informellen Lernen werden Mitarbeiter in Unternehmen, die rasch auf neue Innovationen und Technologien, Kundenwünsche und Produktzyklen reagieren müssen, schwerlich Erfolg haben.
<G-vec00696-002-s413><adapt.reagieren><en> Having a pool of gig workers available also makes it much easier to adapt to sudden or unexpected increases in service demands.
<G-vec00696-002-s413><adapt.reagieren><de> Mit einem Pool von „Gig“-Arbeitskräften wird es auch sehr viel einfacher, bei einem plötzlichen oder unerwarteten Anstieg von Service-Anfragen zu reagieren.
<G-vec00696-002-s414><adapt.reagieren><en> The best employer brands recognise the changing needs of their workforce and shifts in perceptions and adapt accordingly.
<G-vec00696-002-s414><adapt.reagieren><de> Die besten Arbeitgebermarken erkennen nicht nur, wenn sich die Bedürfnisse und die Wahrnehmung des Unternehmens durch die Belegschaft verändern, sondern sie reagieren auch darauf.
<G-vec00696-002-s453><adapt.sich_anpassen><en> The integrated Flip Chip lets you further adapt the bike’s geometry to suit your technique and terrain.
<G-vec00696-002-s453><adapt.sich_anpassen><de> Die SRAM Guide R mit einem bewährten 4-Kolben-Bremssattel lässt sich dank des integrierten Flip Chips präzise auf unterschiedliche Terrains und deinen Fahrstil anpassen.
<G-vec00696-002-s454><adapt.sich_anpassen><en> Integrated Motion system that gives incredible flexibility to the pad, allowing it to adapt even to more extreme movements.
<G-vec00696-002-s454><adapt.sich_anpassen><de> Das integrierte Motion System verleiht der Binde eine unglaubliche Flexibilität, wodurch sie sich sogar heftigen Bewegungen anpassen kann.
<G-vec00696-002-s455><adapt.sich_anpassen><en> A number of long-term trends are reshaping the global landscape, awakening new high profile brands - while others may fail to adapt.
<G-vec00696-002-s455><adapt.sich_anpassen><de> Einige langfristige Trends verändern das globale Umfeld und treiben den Aufstieg neuer hochkarätiger Marken voran – während andere sich nicht anpassen können.
<G-vec00696-002-s456><adapt.sich_anpassen><en> One must adapt little by prospects how great the float should be.
<G-vec00696-002-s456><adapt.sich_anpassen><de> Man muss sich anpassen wenig von Perspektiven, wie groß der Schwimmer sein sollte.
<G-vec00696-002-s457><adapt.sich_anpassen><en> Most of our G-1000 materials come pre-waxed, but it’s still a good idea to know how to re-apply and remove the wax to adapt your jacket to the conditions.
<G-vec00696-002-s457><adapt.sich_anpassen><de> G-1000 Heavy Duty ist zwar vorgewachst, doch es lohnt sich, das Auftragen und Entfernen des Wachses zu lernen, damit du deine Jacke den Bedingungen entsprechend anpassen kannst.
<G-vec00696-002-s458><adapt.sich_anpassen><en> Other species must adapt or die.
<G-vec00696-002-s458><adapt.sich_anpassen><de> Andere Arten müssen sich anpassen oder sterben.
<G-vec00696-002-s459><adapt.sich_anpassen><en> This feature means that they easily adapt to the environment during their growth.
<G-vec00696-002-s459><adapt.sich_anpassen><de> Diese Eigenschaft bedeutet, dass sie sich leicht an die Umwelt während ihres Wachstums anpassen.
<G-vec00696-002-s460><adapt.sich_anpassen><en> For modernizations, we have to adapt to the existing situation.
<G-vec00696-002-s460><adapt.sich_anpassen><de> Bei einer Modernisierung hingegen muss man sich den Gegebenheiten anpassen.
<G-vec00696-002-s461><adapt.sich_anpassen><en> This unique girl's bikini is completely bordered with elasticated straps which adapt individually to the
<G-vec00696-002-s461><adapt.sich_anpassen><de> Der einzigartige Mädchen Bikini ist vollständig mit elastischen Bändern eingefasst, die sich dem Körper individuell anpassen.
<G-vec00696-002-s462><adapt.sich_anpassen><en> HÜPPE Studio Paris elegance allows you to adapt the shower space to the structural elements in your bathroom without having to compromise on design.
<G-vec00696-002-s462><adapt.sich_anpassen><de> Mit HÜPPE Studio Paris elegance können Sie sich fexibel an die baulichen Gegebenheiten Ihres Bades anpassen, ohne Kompromisse im Design eingehen zu müssen.
<G-vec00696-002-s463><adapt.sich_anpassen><en> But as soon as there is danger of an avalanche the animals vanish as if by magic: ‘‘Chamois can adapt themselves very well to their alpine environment“, says game warden Bruno Tscherrig.
<G-vec00696-002-s463><adapt.sich_anpassen><de> Doch sobald Lawinengefahr herrscht, verschwinden die Tiere, wie von Zauberhand weggebracht: „Gämsen können sich ihrer alpinen Umgebung sehr gut anpassen“, sagt Wildhüter Bruno Tscherrig.
<G-vec00696-002-s464><adapt.sich_anpassen><en> Fourthly, It can adapt to difficult working conditions; it is highly protected from dust and moisture with IP67 sealing.
<G-vec00696-002-s464><adapt.sich_anpassen><de> Viertens kann sich es schwierigen Arbeitsbedingungen anpassen; es wird in hohem Grade vor Staub und Feuchtigkeit mit Dichtung IP67 geschützt.
<G-vec00696-002-s465><adapt.sich_anpassen><en> It has a number of advantages: the production processes are best adapted to the corresponding products; it is flexible in that it can adapt quickly to relatively minor changes in the underlying phenomena that the data describe; it is under the control of the domain manager and it results in a low-risk business architecture, as a problem in one of the production processes should normally not affect the rest of the production.
<G-vec00696-002-s465><adapt.sich_anpassen><de> Es besitzt eine Reihe von Vorteilen: Die Produktionsverfahren sind für die entsprechenden Produkte am besten geeignet; es ist insofern flexibel, als es sich rasch an kleinere Veränderungen der den Daten zugrundeliegenden Phänomene anpassen lässt; es unterliegt der Kontrolle des Bereichsleiters und weist eine risikoarme Geschäftsarchitektur auf, da ein Problem in einem Produktionsprozess in der Regel keine Auswirkungen auf die übrige Produktion haben dürfte.
<G-vec00696-002-s466><adapt.sich_anpassen><en> One bed can adapt to your child’s development and age the entire childhood.
<G-vec00696-002-s466><adapt.sich_anpassen><de> Das Bett kann sich der Entwicklung Ihres Kindes anpassen und Ihr Kind die gesamte Kindheit begleiten.
<G-vec00696-002-s467><adapt.sich_anpassen><en> In the name of solidarity you should adapt to the circumstances and support the group.
<G-vec00696-002-s467><adapt.sich_anpassen><de> Im Namen der Solidarität sollten Sie sich den Umständen anpassen und die Gruppe unterstützen.
<G-vec00696-002-s468><adapt.sich_anpassen><en> Parting from our transversal knowledge, accumulated experience and user empathy, we design and develop custom tools that adapt to any particular needs and facilitate, optimise and integrate with the productive processes of our clients.
<G-vec00696-002-s468><adapt.sich_anpassen><de> Basierend auf unserem transversalen Wissen, gesammelte Erfahrung und Empathie mit den Nutzern, gestalten und entwickeln wir personalisierte Werkzeuge, die sich an die jeweiligen Bedürfnisse anpassen, die produktive Prozesse unserer Kunde vereinfachen, optimieren und sich damit integrieren.
<G-vec00696-002-s469><adapt.sich_anpassen><en> And since the obstacles and opportunities in the competitive world market change over time and in place, to succeed the economic cat, no matter what its color, must adapt to these changes or fail to catch any mice at all.
<G-vec00696-002-s469><adapt.sich_anpassen><de> Und da die Hindernisse und Gelegenheiten in der Konkurrenz des Weltmarktes sich in Raum und Zeit immer wieder ändern, muss die wirtschaftliche Katze, gleich welcher Farbe, um Erfolg zu haben, sich diesen Veränderungen anpassen oder sie schafft es nicht, irgendwelche Mäuse zu fangen.
<G-vec00696-002-s470><adapt.sich_anpassen><en> Man can live in any economic relationship, can adapt himself to any form of political life, without affecting in the slightest the laws to which his physical being is subject.
<G-vec00696-002-s470><adapt.sich_anpassen><de> Der Mensch kann unter jedem Wirtschaftsverhältnis leben, er kann sich jeder Form des politischen Lebens anpassen, ohne daß dadurch die Gesetze, denen sein physisches Sein unterworfen ist, berührt würden.
<G-vec00696-002-s471><adapt.sich_anpassen><en> In these extreme conditions, rescue operations have always been a priority for the population and coastal ports have had to adapt and endow themselves with ever more efficient equipment.
<G-vec00696-002-s471><adapt.sich_anpassen><de> Unter diesen extremen Bedingungen waren Rettungseinsätze schon immer eine Priorität für die Bevölkerung und die Küstenhäfen mussten sich anpassen und mit immer leistungsfähigeren Geräten ausstatten.
<G-vec00696-002-s472><adapt.sich_anpassen><en> Or you can provide an HTML snippet, which can adapt to the current screen size via css media queries and utilize the full size of the area.
<G-vec00696-002-s472><adapt.sich_anpassen><de> Oder Sie liefern die Anzeige als HTML-Snippet, welches sich dank CSS Media Queries an die jeweilige Bildschirmgröße anpasst.
<G-vec00696-002-s473><adapt.sich_anpassen><en> This method allows the shoe's leather to be more flexible and adapt to each person's foot, achieving maximum comfort.
<G-vec00696-002-s473><adapt.sich_anpassen><de> Diese Methode ermöglicht es, dass das Leder des Schuhs flexibler ist und sich dem Fuß jeder Person anpasst, wodurch maximaler Komfort erreicht wird.
<G-vec00696-002-s474><adapt.sich_anpassen><en> And even if a concept is well accepted, it is imperative for a startup to constantly adapt in order to keep up with the market and continue to build on its lead.
<G-vec00696-002-s474><adapt.sich_anpassen><de> Und auch wenn gute Konzepte greifen, ist es unabdingbar, dass das Startup sich stetig anpasst, um am Markt dran zu sein und seinen Vorsprung weiter auszubauen.
<G-vec00696-002-s475><adapt.sich_anpassen><en> With its innovative design, AirFit N20 has been finished and shaped to adapt to the unique facial contours of each of your patients, offering a robust seal regardless of face shape or size.
<G-vec00696-002-s475><adapt.sich_anpassen><de> Durch das innovative Design der AirFit N20 mit seiner speziellen Form und Oberfläche wird sichergestellt, dass die Maske sich den individuellen Gesichtskonturen jedes Ihrer Patienten anpasst und, unabhängig von Gesichtsform und -größe, eine zuverlässige Abdichtung bietet.
<G-vec00696-002-s476><adapt.sich_anpassen><en> Rubber and the covering spring take the rubber, which are resistant to ozone and UV and adapt to different climatic conditions.
<G-vec00696-002-s476><adapt.sich_anpassen><de> Gummi und die Abdeckfeder nehmen den Gummi auf, der gegen Ozon und UV beständig ist und sich an verschiedene klimatische Bedingungen anpasst.
<G-vec00696-002-s477><adapt.sich_anpassen><en> See now Basic bras have been reinvented to better adapt to different silhouettes, materials and trends.
<G-vec00696-002-s477><adapt.sich_anpassen><de> Die Basic-BHs werden neu erfunden, um ein Sortiment anbieten zu können, das sich besser an die verschiedensten Silhouetten, Materialien und Trends anpasst.
<G-vec00696-002-s478><adapt.sich_anpassen><en> In a rapidly changing world, it is key that the Fund remains flexible in its response and adapt rapidly to the changing circumstances.
<G-vec00696-002-s478><adapt.sich_anpassen><de> In einer sich schnell verändernden Welt ist es von größter Wichtigkeit, dass der IWF weiterhin flexibel reagiert und sich den neuen Umständen schnell anpasst.
<G-vec00696-002-s479><adapt.sich_anpassen><en> Its cross-section with single-arm suspension system for the Number of elements is designed so as to adapt constantly and accurately to the road surface.
<G-vec00696-002-s479><adapt.sich_anpassen><de> Sein Querprofil mit der Einzelarmabstützung der Abfederungselemente ist so konstruiert, dass es sich immer sehr genau der Fahrbahn anpasst.
<G-vec00696-002-s480><adapt.sich_anpassen><en> For this very reason there is only one dance floor with its groove changing organically just like the circle of sun and moon - the music will adapt to the atmosphere of the day or the night.
<G-vec00696-002-s480><adapt.sich_anpassen><de> Daher auch nur eine Tanzfläche, deren Groove sich so organisch wie das Spiel von Sonne und Mond verändert, wobei sich die Musik der jeweiligen Tages- oder Nachtzeit anpasst.
<G-vec00696-002-s481><adapt.sich_anpassen><en> Not only: the multifunctional character of this product is also reflected in the installation procedures which adapt to baths of different types: between two walls or corner fitting, there is always a solution suited to your planning and space needs.
<G-vec00696-002-s481><adapt.sich_anpassen><de> Und dem noch mehr: Die Multifunktionalität dieses Produkts spiegelt sich auch in der Einbauweise wider, die sich verschiedenartigen Wannen anpasst: Zwischen zwei Wänden oder in der Ecke, es gibt immer eine Lösung, die für Ihre Entwurfs- und Platzbedürfnisse geeignet ist.
<G-vec00696-002-s482><adapt.sich_anpassen><en> Padel World Press .- If you are a padel player who has experience on the court and loves power, do not hesitate and discover the new HEAD Alpha Touch 2021, a shovel that will adapt like a glove to your needs.
<G-vec00696-002-s482><adapt.sich_anpassen><de> Padel Weltpresse .- Wenn Sie ein Padel-Spieler sind, der Erfahrung auf dem Platz hat und Macht liebt, zögern Sie nicht und entdecken Sie das Neue KOPF Alpha Touch 2021, eine Schaufel, die sich wie angegossen an Ihre Bedürfnisse anpasst.
<G-vec00696-002-s483><adapt.sich_anpassen><en> flexCloud Freely scalable cloud solution which can adapt to your company requirements at any time.
<G-vec00696-002-s483><adapt.sich_anpassen><de> flexCloud Frei skalierbare Cloud-Lösung, die sich jederzeit an die Anforderungen Ihres Unternehmen anpasst.
<G-vec00696-002-s484><adapt.sich_anpassen><en> The Counter Ring ring is made of elastic material to easily adapt to any penis size.
<G-vec00696-002-s484><adapt.sich_anpassen><de> Der Penisring Counter Ring ist aus elastischem Material, das sich mühelos an jede Penisgrösse anpasst.
<G-vec00696-002-s485><adapt.sich_anpassen><en> In the 2nd trimester, when the body is just beginning to adapt to the new weight and the load on the legs increases, this is especially true.
<G-vec00696-002-s485><adapt.sich_anpassen><de> Im zweiten Trimester, wenn sich der Körper gerade erst an das neue Gewicht anpasst und die Belastung der Beine zunimmt, trifft dies besonders zu.
<G-vec00696-002-s486><adapt.sich_anpassen><en> A notable feature is that the game seems to adapt to the spatial conditions of the player.
<G-vec00696-002-s486><adapt.sich_anpassen><de> Eine erwähnenswerte Eigenschaft ist, dass dieses Spiel sich scheinbar an die räumlichen Gegebenheiten des Spielers anpasst.
<G-vec00696-002-s487><adapt.sich_anpassen><en> AUVESY is a solid, owner-managed, traditional German SME with an expertise base spanning multiple industries and the capacity to quickly and flexibly adapt to customer requirements.
<G-vec00696-002-s487><adapt.sich_anpassen><de> AUVESY ist ein solides, inhabergeführtes Unternehmen des deutschen Mittelstandes, das über das komplette branchenübergreifende Know-how verfügt und sich flexibel und schnell an die Bedürfnisse seiner Kunden anpasst.
<G-vec00696-002-s488><adapt.sich_anpassen><en> Also, the website was created using responsive design, which enables the page to adapt automatically to the screen size of the device (iPad, tablet, mobile phone) it is accessed from for an optimal display.
<G-vec00696-002-s488><adapt.sich_anpassen><de> Außerdem wurde der Webauftritt im Responsive Design gestaltet, sodass sich die Darstellung der Seiten auch beim Zugriff über mobile Endgeräte automatisch dem jeweiligen Ausgabemedium optimal anpasst.
<G-vec00696-002-s490><adapt.sich_anpassen><en> Standout projects to date include Bounce Family (2012), a collection of containers composed of Lycra-covered steel that stretch and hold much more than expected; and Dry (2012), a sculptural, stackable drying rack made of four movable, colorful, thermo-lacquered steel components designed to adapt to today’s multipurpose living spaces.
<G-vec00696-002-s490><adapt.sich_anpassen><de> Herausragende Projekte sind bis dato die Bounce Family (2012), eine Kollektion von Stahlcontainern, die mit Lycra bezogen sind, sich dehnen und ungewöhnlich viel Gewicht tragen können; und Dry (2012), ein skulpturales und stapelbares Trockengestell, das aus vier beweglichen, bunten und thermolackierten Stahlelementen besteht und sich so den heutigen Mehrzweck-Wohnräumen anpasst.
<G-vec00696-002-s491><adapt.sich_anpassen><en> A lean organisational structure and ultra-modern manufacturing are the basis for the fast development of products to adapt to the ever changing requirements of the industry.
<G-vec00696-002-s491><adapt.sich_anpassen><de> Schlanke Organisationsstrukturen und hochmoderne Konstruktionsarbeitsplätze bilden die Grundlage zur schnellen Entwicklung von Produkten, um sich den ständig ändernden Anforderungen der Industrie anzupassen.
<G-vec00696-002-s492><adapt.sich_anpassen><en> As a result, businesses that try to adapt to this new reality find that all types of contact initiated by customers—voice, social, text, chat—can be great revenue-producing opportunities.
<G-vec00696-002-s492><adapt.sich_anpassen><de> Unternehmen, die versuchen, sich an diese neue Wirklichkeit anzupassen, stellen daher fest, dass jede Art von Kontaktaufnahme durch den Kunden, sei es sprachbasiert, über soziale Netzwerke, Text oder Chat, eine wichtige Absatzchance darstellen kann.
<G-vec00696-002-s493><adapt.sich_anpassen><en> And it’s probably going to be easier for small labels to adapt.
<G-vec00696-002-s493><adapt.sich_anpassen><de> Da wird es wahrscheinlich sogar für die kleinen Labels einfacher sein, sich anzupassen.
<G-vec00696-002-s494><adapt.sich_anpassen><en> Water has its own rules, and we as humans have to learn how to adapt to these rules.
<G-vec00696-002-s494><adapt.sich_anpassen><de> Wasser hat seine eigenen Gesetzmäßigkeiten, und der Mensch muss lernen, sich diesen anzupassen.
<G-vec00696-002-s495><adapt.sich_anpassen><en> I believe in secure, flexible and fast solutions, that make it easy to adapt to new challenges as fast as needed.
<G-vec00696-002-s495><adapt.sich_anpassen><de> Ich glaube an sichere, flexible und schnelle Lösungen, die es leicht machen, sich so schnell wie möglich an neue Herausforderungen anzupassen.
<G-vec00696-002-s496><adapt.sich_anpassen><en> Kathrin Wehrli, Remo Lütolf and Yogesh Maheshwari will discuss how diversity can play an integral role on business success and why it is critical to an organization’s ability to adapt to a fast-changing environment.
<G-vec00696-002-s496><adapt.sich_anpassen><de> Kathrin Wehrli, Remo Lütolf und Yogesh Maheshwari diskutieren, wie Vielfalt eine entscheidende Rolle für den Geschäftserfolg spielen kann und warum sie für die Fähigkeit eines Unternehmens, sich an ein sich schnell veränderndes Umfeld anzupassen, entscheidend ist.
<G-vec00696-002-s497><adapt.sich_anpassen><en> A Member State to which paragraph 2 applies may have up to two more years, if necessary to enable the economic operators in that Member State to adapt gradually to the resale right system while maintaining their economic viability, before it is required to apply the resale right for the benefit of those entitled under the artist after his/her death.
<G-vec00696-002-s497><adapt.sich_anpassen><de> (3) Ein Mitgliedstaat, auf den Absatz 2 Anwendung findet, verfügt erforderlichenfalls über einen zusätzlichen Zeitraum von höchstens zwei Jahren, um die Wirtschaftsteilnehmer in diesem Mitgliedstaat in die Lage zu versetzen, sich unter Wahrung ihrer wirtschaftlichen Lebensfähigkeit allmählich an das Folgerechtssystem anzupassen, bevor dieses Recht zugunsten der nach dem Tod des Künstlers anspruchsberechtigten Rechtsnachfolger angewandt werden muss.
<G-vec00696-002-s498><adapt.sich_anpassen><en> General power banks have a relatively large range of charging in order to adapt to most mobile phones.
<G-vec00696-002-s498><adapt.sich_anpassen><de> Allgemeine Powerbanks verfügen über einen relativ großen Ladebereich, um sich an die meisten Mobiltelefone anzupassen.
<G-vec00696-002-s499><adapt.sich_anpassen><en> Collaborative robots are designed to learn and adapt as if they were a human coworker, which requires controlled, safe motion.
<G-vec00696-002-s499><adapt.sich_anpassen><de> Kollaborierende Roboter sind darauf ausgelegt, wie ein menschlicher Mitarbeiter zu lernen und sich anzupassen, was eine kontrollierte, sichere Bewegung erfordert.
<G-vec00696-002-s500><adapt.sich_anpassen><en> If a human incarnates he takes certain abilities into his life, principally to adapt to earthly conditions, that means he automatically accepts the conditions and adjusts to them.
<G-vec00696-002-s500><adapt.sich_anpassen><de> Wenn der Mensch neu inkarniert, nimmt er bestimmte Anlagen mit, im Prinzip solche, um sich total dem Irdischen anzupassen, d.h. er sieht von hier aus eine Konstellation und paßt sich an.
<G-vec00696-002-s501><adapt.sich_anpassen><en> The ski resort and the TechnoAlpin staff in charge of the project met over several months in order to plan the design and to adapt an advanced snowmaking system to the conditions of the location.
<G-vec00696-002-s501><adapt.sich_anpassen><de> Das Skigebiet und die Zuständigen von TechnoAlpin haben sich über mehrere Monate getroffen um das Projekt zu planen und eine fortschrittliche Beschneiungsanlage an die Gegebenheiten des Ortes anzupassen.
<G-vec00696-002-s502><adapt.sich_anpassen><en> Both were forced to adapt to the other’s rhythm of words.
<G-vec00696-002-s502><adapt.sich_anpassen><de> Beide waren gezwungen, sich dem Rhythmus der Worte des anderen anzupassen.
<G-vec00696-002-s503><adapt.sich_anpassen><en> The tibia roller pad can be adjusted to adapt to different user heights.
<G-vec00696-002-s503><adapt.sich_anpassen><de> Das Schienbeinpolster ist verstellbar, um sich Nutzern unterschiedlicher Körpergrößen anzupassen.
<G-vec00696-002-s504><adapt.sich_anpassen><en> Once the body begins to adapt, it consumes body fat in order to keep pace with energy demands that come with the curriculum.
<G-vec00696-002-s504><adapt.sich_anpassen><de> Wenn der Körper beginnt, sich anzupassen, benötigt er Körperfett, um Schritt zu halten mit der Energie-Anforderungen, die mit einem Trainingsprogramm kommen.
<G-vec00696-002-s505><adapt.sich_anpassen><en> With a global move towards linerless labels – pressure-sensitive labels without backing paper – the industry as a whole is demonstrating a willingness to adapt to the cultural and political drive towards environmentalism, regardless of the country of production.
<G-vec00696-002-s505><adapt.sich_anpassen><de> Angesichts des globalen Trends zu trägerbandlosen Etiketten – drucksensitive Etiketten ohne Trägerpapier – beweist die Branche insgesamt ihre Bereitschaft, sich unabhängig vom Fertigungsland an das kulturelle und politische Streben nach Ressourcenschonung anzupassen.
<G-vec00696-002-s506><adapt.sich_anpassen><en> In practice the alternative is even clearer: either Social Democracy must say pater peccavi to the patriotic bourgeoisie (as former young daredevils and present day old devotees in our ranks are already proclaiming contritely) and thus have to revise fundamentally all its tactics and principles, in peace-time as well as in war-time, in order to adapt to its present social-imperialist position; or the party will have to say pater peccavi to the international proletariat and adapt its behaviour during the war to its principles in peace-time.
<G-vec00696-002-s506><adapt.sich_anpassen><de> Praktisch sieht die Alternative noch deutlicher aus: Entweder wird die Sozialdemokratie, wie ehemalige junge Draufgänger und heutige alte Betschwestern in unseren Reihen bereits reumütig ankündigen, vor der vaterländischen Bourgeoisie pater, peccavi sagen und auch im Frieden ihre ganze Taktik und ihre Grundsätze gründlich revidieren müssen, um sich ihrer heutigen sozialimperialistischen Position anzupassen, oder sie wird vor dem internationalen Proletariat pater, peccavi sagen und ihr Verhalten im Kriege ihren Prinzipien im Frieden anpassen müssen.
<G-vec00696-002-s507><adapt.sich_anpassen><en> The connectors of the udoq cables can be adjusted in height to adapt to most protective cases.
<G-vec00696-002-s507><adapt.sich_anpassen><de> Die Ladestecker der udoq Kabel können in der Höhe verstellt werden, um sich an die meisten Schutzhüllen anzupassen.
<G-vec00696-002-s508><adapt.sich_anpassen><en> In order to maintain or raise the opening rates, it is essential for e-Mail marketers to adapt to the mobile trend.
<G-vec00696-002-s508><adapt.sich_anpassen><de> Um die Öffnungsraten also weiterhin zu halten oder zu steigern, ist es für E-Mail-Marketer unumgänglich, sich an den mobilen Trend anzupassen.
<G-vec00696-002-s509><adapt.sich_anpassen><en> Peru is home to thousands of species that continue to amaze the scientific world, especially the endemic species, whose beauty, peculiar features and ability to adapt to challenging climates make them a special attraction.
<G-vec00696-002-s509><adapt.sich_anpassen><de> Peru beheimatet Tausende von Arten, die noch immer Überraschungen für die Wissenschaft bereithalten, vor allem die örtlich begrenzt auftretenden Spezies, deren Schönheit, charakteristische Merkmale und Fähigkeit, sich schwierigen klimatischen Bedingungen anzupassen, sie zu einer echten Attraktion machen.
<G-vec00696-002-s510><adapt.sich_einstellen><en> Digital is everywhere – and businesses must either adapt to this new market reality or risk falling behind.
<G-vec00696-002-s510><adapt.sich_einstellen><de> Wenn Unternehmen nicht Gefahr laufen wollen, ins Hintertreffen zu geraten, müssen sie sich auf diese neue Realität einstellen.
<G-vec00696-002-s511><adapt.sich_einstellen><en> Driving instructors who can adapt to the needs of each individual student are particularly popular.
<G-vec00696-002-s511><adapt.sich_einstellen><de> FahrlehrerInnen, die sich auf die Bedürfnisse jedes einzelnen Fahrschülers einstellen können, sind besonders beliebt.
<G-vec00696-002-s512><adapt.sich_einstellen><en> Yet even if traders and markets adapt quickly to the new situation, the low level of volatility seen in 2017 remains unusual.
<G-vec00696-002-s512><adapt.sich_einstellen><de> Auch wenn sich der Handel und die Märkte schnell auf die neue Lage einstellen – ein Phänomen bleibt das niedrige Volatilitätsniveau von 2017 dennoch.
<G-vec00696-002-s513><adapt.sich_einstellen><en> Our long-standing and trusted customer relationships based on our performance and target-oriented approach, which we constantly and timely adapt to the ever-changing need for advice.
<G-vec00696-002-s513><adapt.sich_einstellen><de> Unsere langjährigen und vertrauensvollen Kundenbeziehungen basieren auf unserer leistungs- und zielorientierten Arbeitsweise, die wir permanent und zeitgemäß auf den sich ständig wandelnden Beratungsbedarf einstellen.
<G-vec00696-002-s514><adapt.sich_einstellen><en> Power grid operators must adapt to a changing system with a high proportion of fluctuating renewable energy.
<G-vec00696-002-s514><adapt.sich_einstellen><de> Stromnetzbetreiber müssen sich auf ein verändertes System mit hohem Anteil fluktuierender erneuerbarer Energie einstellen.
<G-vec00696-002-s515><adapt.sich_einstellen><en> As a result, you can adapt to the weather in S. Maddalena / St. Magdalena and surroundings every day and plan accordingly for your day.
<G-vec00696-002-s515><adapt.sich_einstellen><de> So können Sie sich täglich auf das Wetter in St. Magdalena und Umgebung einstellen und Ihren Urlaubstag dementsprechend planen.
<G-vec00696-002-s516><adapt.sich_einstellen><en> In many companies staff development has to adapt to the needs of multicultural workforces and international locations.
<G-vec00696-002-s516><adapt.sich_einstellen><de> In vielen Unternehmen muss sich die Personalentwicklung auf die Bedürfnisse multikultureller Belegschaften und internationaler Standorte einstellen.
<G-vec00696-002-s517><adapt.sich_einstellen><en> Today, companies need to adapt even faster to changing market situations.
<G-vec00696-002-s517><adapt.sich_einstellen><de> Immer schneller müssen sich Unternehmen auf geänderte Marktsituationen einstellen.
<G-vec00696-002-s518><adapt.sich_einstellen><en> In any case, FC Bayern now quickly needs to adapt to a BVB that does not run into traps as often as the team under Bosz did.
<G-vec00696-002-s518><adapt.sich_einstellen><de> Der FC Bayern darf sich kurzfristig jedenfalls auf einen BVB einstellen, der nicht so sehr ins offene Messer läuft wie es die Mannschaft unter Bosz noch häufig tat.
<G-vec00696-002-s519><adapt.sich_einstellen><en> <When you take for a certain time a digestion enzyme with the meals, then organism can adapt more easily to the concentrated proteins.
<G-vec00696-002-s519><adapt.sich_einstellen><de> "Wenn Sie eine Zeit lang ein Verdauungsenzym zu den Malzeiten einnehmen, kann sich der Organismus leichter auf die konzentrierten Proteine einstellen.
<G-vec00696-002-s520><adapt.sich_einstellen><en> Science and industry have to adapt to one another in this respect.
<G-vec00696-002-s520><adapt.sich_einstellen><de> Hier müssen sich Wissenschaft und Wirtschaft aufeinander einstellen.
<G-vec00696-002-s521><adapt.sich_einstellen><en> There are many tools on the market that cannot adapt individually enough to the goals of your company.
<G-vec00696-002-s521><adapt.sich_einstellen><de> Es gibt viele Tools auf dem Markt die sich nicht individuell genug auf die Ziele Ihres Unternehmens einstellen können.
<G-vec00696-002-s522><adapt.sich_einstellen><en> For the first time, the long-range radar now operates independently of the set driving level and is able to adapt continuously to changing inclination of the vehicle as a result of suspension or load statuses.
<G-vec00696-002-s522><adapt.sich_einstellen><de> Der Fernbereichsradar arbeitet nun erstmals unabhängig vom eingestellten Fahrniveau und kann sich permanent auf veränderte Fahrzeugneigung aufgrund von Fahrwerks- oder Beladungszuständen einstellen.
<G-vec00696-002-s523><adapt.sich_einstellen><en> She was able to adapt to the horse and rider quickly and analyze their problems precisely.
<G-vec00696-002-s523><adapt.sich_einstellen><de> Sie konnte sich schnell auf die Schüler und Pferde einstellen und deren präzise Probleme analysieren.
<G-vec00696-002-s524><adapt.sich_einstellen><en> Success often depends on being able to quickly adapt to new situations.
<G-vec00696-002-s524><adapt.sich_einstellen><de> Oftmals hängt der Erfolg von der Fähigkeit ab, sich schnell auf neue Situationen einstellen zu können.
<G-vec00696-002-s525><adapt.sich_einstellen><en> Share your treatment requirements with us as soon as possible and the Larimar team will adapt to your personal needs.
<G-vec00696-002-s525><adapt.sich_einstellen><de> Teilen Sie uns Ihre Behandlungswünsche möglichst frühzeitig mit, damit sich das Larimar-Team optimal auf Sie einstellen kann.
<G-vec00696-002-s526><adapt.sich_einstellen><en> In order to achieve this performance, you'll need to find the shoes that best adapt to your needs in function of the modalities that you practise.
<G-vec00696-002-s526><adapt.sich_einstellen><de> Um diese Leistungsfähigkeit zu erreichen solltest du dich für die Schuhe entscheiden, die sich am besten auf deine Bedürfnisse und auch auf deine spezielle Kategorie einstellen.
<G-vec00696-002-s527><adapt.sich_einstellen><en> For CMOs it turned out that in future they will need to adapt to the needs of their inhomogeneous customers groups (big pharma vs. small biotech) in order to react flexibly in terms of serialization.
<G-vec00696-002-s527><adapt.sich_einstellen><de> Für Lohnverpacker zeigte sich, dass sich diese in Zukunft unterschiedlichen Bedürfnisse ihrer inhomogenen Kundengruppen (Big Pharma vs. Kleine Biotechunternehmen) einstellen und hier sehr flexibel reagieren können müssen.
<G-vec00696-002-s528><adapt.sich_einstellen><en> In her view, effective movements – including the climate movement – require key figures that can mediate, adapt to the cultural codes of different societal groups and are able to convincingly present and explain the goals of the movement.
<G-vec00696-002-s528><adapt.sich_einstellen><de> Aus ihrer Sicht sind für das Wirksamwerden etwa der Klimabewegung Schlüsselfiguren wichtig, die vermitteln, sich auf die unterschiedlichen kulturellen Codes gesellschaftlicher Gruppen einstellen können und die Anliegen der Bewegung überzeugend darstellen und erzählen können.
<G-vec00696-002-s529><adapt.sich_einstellen><en> Rather, it is vital that we adapt to the culture, expectations, and possibilities of our individual partners.
<G-vec00696-002-s529><adapt.sich_einstellen><de> Wichtig ist es, sich auf Kultur, Erwartungshaltung und Möglichkeiten des jeweiligen Partners einzustellen.
<G-vec00696-002-s530><adapt.sich_einstellen><en> It is therefore absolutely essential for companies to adapt to new opportunities for dialog and to develop appropriate strategies.
<G-vec00696-002-s530><adapt.sich_einstellen><de> Für Unternehmen ist es daher zwingend erforderlich, sich auch auf neue Dialogmöglichkeiten einzustellen und entsprechende Strategien zu entwickeln.
<G-vec00696-002-s531><adapt.sich_einstellen><en> It is very easy for them to learn the ropes of complex issues and to adapt to new corporate cultures with ever new assignment.
<G-vec00696-002-s531><adapt.sich_einstellen><de> Es fällt ihnen sehr leicht, sich in komplexe Sachverhalte einzuarbeiten und sich bei jedem Einsatz auf eine andere Unternehmenskultur einzustellen.
<G-vec00696-002-s532><adapt.sich_einstellen><en> You are the first point of contact and even in stressful day-to-day business you are constantly challenged to adapt to the different callers and their needs.
<G-vec00696-002-s532><adapt.sich_einstellen><de> Sie sind die erste Kontaktperson und auch im stressigen Tagesgeschäft immer wieder gefordert, sich auf die unterschiedlichen Anrufer mit ihren Bedürfnissen einzustellen.
<G-vec00696-002-s533><adapt.sich_einstellen><en> Apart from innovative solutions and the high level of expertise, business partners appreciate ECG s ability to adapt flexibly to new conditions and to support the development of business processes.
<G-vec00696-002-s533><adapt.sich_einstellen><de> Geschäftspartner schätzen neben den innovativen Softwarelösungen und der Fachexpertise der ECG insbesondere die Fähigkeit, sich auf neue Rahmenbedingungen flexibel einzustellen und bei der Entwicklung von Geschäftsprozessen beratend zur Seite zu stehen.
<G-vec00696-002-s534><adapt.sich_einstellen><en> I think Evonik has the flexibility to adapt to the needs and wishes of their employees and to offer opportunity to develop and grow.
<G-vec00696-002-s534><adapt.sich_einstellen><de> Ich denke, Evonik hat die Flexibilität, sich auf die Wünsche und Bedürfnisse seiner Mitarbeitenden einzustellen und ihnen Entwicklungs- und Wachstumsmöglichkeiten anzubieten.
<G-vec00696-002-s535><adapt.sich_einstellen><en> This was combined with the self-transformation of our systematic rank-and-file work in order to adapt them to the tasks in class struggle that lie ahead.
<G-vec00696-002-s535><adapt.sich_einstellen><de> Das durchdrang sich mit der Selbstveränderung unserer Kleinarbeit, um sie auf die bevorstehenden Aufgaben im Klassenkampf einzustellen.
<G-vec00696-002-s536><adapt.sich_einstellen><en> Service quality: you assist your customers to develop an efficient energy management system and are able to adapt to your customers’ requirements from an early stage.
<G-vec00696-002-s536><adapt.sich_einstellen><de> Servicequalität: Sie unterstützen Ihre Kunden beim Aufbau eines effizienten Energiemanagements und lernen frühzeitig, sich auf Kundenanforderungen einzustellen.
<G-vec00696-002-s537><adapt.sich_einstellen><en> – being able to adapt to the needs of people with mental disabilities, in order to offer them the right support
<G-vec00696-002-s537><adapt.sich_einstellen><de> – in der Lage zu sein, sich auf die Bedürfnisse von Menschen mit kognitiven Einschränkungen einzustellen um ihnen angemessene Unterstützung zu bieten.
<G-vec00696-002-s538><adapt.sich_einstellen><en> These statistics indicate how critical it is for marketers to adapt to the rapidly changing range of consumer behaviors, preferences and expectations.
<G-vec00696-002-s538><adapt.sich_einstellen><de> Diese Statistik zeigt, wie wichtig es für Marketingverantwortliche ist, sich auf die stark variierenden Verhaltensweisen, Vorlieben und Erwartungen des Verbrauchers einzustellen.
<G-vec00696-002-s539><adapt.sich_einstellen><en> The Luxxamed has the ability to learn by the application on the patient and thus adapt to the different states."
<G-vec00696-002-s539><adapt.sich_einstellen><de> Der Luxxamed hat die Fähigkeit, durch die Anwendung am Patienten zu lernen und sich somit auf die unterschiedlichen Zustände einzustellen.
<G-vec00696-002-s540><adapt.sich_einstellen><en> With task forces on start-ups, industry internationalization, and business opportunities in the energy transition the network, managed by DWR eco CEO David Wortmann, helps clean tech companies adapt to rapidly changing market conditions.
<G-vec00696-002-s540><adapt.sich_einstellen><de> Mit Task Forces für Start-Ups, zur Internationalisierung der Branche und zu den Geschäftschancen der Energiewende hilft das von DWR eco Geschäftsführer David Wortmann gemanagte Netzwerk Unternehmen der Cleantech-Branche sich auf die rasant ändernden Marktbedingungen einzustellen.
<G-vec00696-002-s541><adapt.sich_einstellen><en> We know that redevelopment is a dynamic process in which it is necessary to adapt to constantly occurring changes.
<G-vec00696-002-s541><adapt.sich_einstellen><de> Wir wissen, dass Sanierung ein dynamischer Prozess ist, in dem es erforderlich ist, sich auf stetig eintretende Veränderungen einzustellen.
<G-vec00696-002-s542><adapt.sich_einstellen><en> Our ‘Convenience in Europe’ study series offers suppliers of convenience products the opportunity to adapt better to the desires and needs of their customers.
<G-vec00696-002-s542><adapt.sich_einstellen><de> Unsere Studienreihe ’Convenience in Europa’ gibt Anbietern von Convenience-Produkten die Möglichkeit, sich noch besser auf die Wünsche und Bedürfnisse ihrer Kunden einzustellen.
<G-vec00696-002-s543><adapt.sich_einstellen><en> As a service contractor, you need the ability to adapt quickly to whatever your customers are asking for.
<G-vec00696-002-s543><adapt.sich_einstellen><de> Als Dienstleister müssen Sie in der Lage sein, sich schnell auf die Anforderungen Ihrer Kunden einzustellen.
<G-vec00696-002-s544><adapt.sich_einstellen><en> By combining a world-class storage R&D team with a commitment to customer satisfaction, Thecus is able to adapt to the market with its innovative NAS and NVR and fulfill the storage and surveillance needs of
<G-vec00696-002-s544><adapt.sich_einstellen><de> Durch die Kombination eines Weltklasse-R&D-Teams für Speicherlösungen mit der Selbstverpflichtung, Kunden zufriedenzustellen, ist Thecus in der Lage, sich mit seinen innovativen NAS und NVR auf die Bedürfnisse des Marktes einzustellen und so die Speicher- und Kontroll-Anforderungen von heute zu erfüllen.
<G-vec00696-002-s545><adapt.sich_einstellen><en> The most successful companies are able to adapt to rapidly changing market conditions.
<G-vec00696-002-s545><adapt.sich_einstellen><de> Die erfolgreichsten Unternehmen sind in der Lage sich auf schnell verändernde Marktbedingungen einzustellen.
<G-vec00696-002-s546><adapt.sich_einstellen><en> They are challenged to adapt to complex and “colourful” CVs.
<G-vec00696-002-s546><adapt.sich_einstellen><de> Sie sind gefordert sich auf vielschichtige und „bunte“ Lebensläufe einzustellen.
<G-vec00696-002-s547><adapt.sich_einstellen><en> In a club the DJ is the boss, the VJ tries to follow the beat of the music and adapt to the style of the pieces.
<G-vec00696-002-s547><adapt.sich_einstellen><de> Im Club ist der DJ der Chef, der VJ versucht, dem Beat der Musik zu folgen und sich auf den Stil der Stücke einzustellen.
<G-vec00696-002-s348><adapt.sich_passen><en> WC and Wash Basins adapt to the most different of needs at the touch of a button.
<G-vec00696-002-s348><adapt.sich_passen><de> WC und Waschtische passen sich auf Knopfdruck den unterschiedlichsten Bedürfnissen an.
<G-vec00696-002-s349><adapt.sich_passen><en> The soft rubber sides adapt to the contours of your teeth and gums to absorb excessive pressure.
<G-vec00696-002-s349><adapt.sich_passen><de> Die weichen Seiten aus Gummi passen sich den Konturen deiner Zähne und des Zahnfleischs an, um so übermässigen Druck zu absorbieren.
<G-vec00696-002-s350><adapt.sich_passen><en> There is a light blue and pink version of it and both shades adapt perfectly to the skin’s tone.
<G-vec00696-002-s350><adapt.sich_passen><de> Es gibt ihn in hellblau oder rosa und beide Farben passen sich der Haut sehr gut an.
<G-vec00696-002-s352><adapt.sich_passen><en> Our services adapt efficiently to your business needs and drive the right business outcomes for your company.
<G-vec00696-002-s352><adapt.sich_passen><de> Unsere Services passen sich effizient an Ihre Geschäftsanforderungen an und fördern die richtigen Ergebnisse für Ihr Unternehmen.
<G-vec00696-002-s353><adapt.sich_passen><en> The different sipes flexibly adapt to all weather variations, offering relentless grip and enjoyably controlled and quiet driving.
<G-vec00696-002-s353><adapt.sich_passen><de> Die unterschiedlichen Lamellen passen sich flexibel an alle Wetterumschwünge an und stellen so kompromisslosen Grip, kontrollierten Fahrspaß und eine ruhige Fahrt sicher.
<G-vec00696-002-s354><adapt.sich_passen><en> With power outputs of 250 or 500 Watt, the UMC generators are able to optimally adapt to individual cleaning requirements.
<G-vec00696-002-s354><adapt.sich_passen><de> Die UMC Generatoren passen sich dabei mit 250 oder 500 Watt Leistung optimal an individuelle Reinigungsanforderungen an.
<G-vec00696-002-s355><adapt.sich_passen><en> The high speed ICE stations Limburg and Montabaur adapt impressively into trans-European networks.
<G-vec00696-002-s355><adapt.sich_passen><de> Die ICE-Bahnhöfe Limburg und Montabaur passen sich „eindrucksvoll“ in transeuropäische Netze ein.
<G-vec00696-002-s356><adapt.sich_passen><en> The manufactured products adapt perfectly to the needs of your production, amplifying the performances in each phase.
<G-vec00696-002-s356><adapt.sich_passen><de> Die realisierten Produkte passen sich den Anforderungen Ihrer Produktion perfekt an und verbessern zudem in jedem Stadium ihre Leistung.
<G-vec00696-002-s357><adapt.sich_passen><en> They adapt excellently to their respective environment, and they existed long before humans.
<G-vec00696-002-s357><adapt.sich_passen><de> Sie passen sich ihrer jeweiligen Umgebung hervorragend an, und es gab sie schon lange vor dem Menschen.
<G-vec00696-002-s358><adapt.sich_passen><en> Due to its elegant and light design and the streamlined orientation the outdoor furniture collection Alize easily adapt to a variety of furnishings.
<G-vec00696-002-s358><adapt.sich_passen><de> Aufgrund ihres elegant schlichten Designs und der stromlinienförmigen Ausrichtung passen sich die Möbel der Outdoor Kollektion Alize problemlos einer Vielzahl von Umgebungen an.
<G-vec00696-002-s359><adapt.sich_passen><en> As a result jackets that use hydrophilic membranes adapt to your activity level and retain heat well.
<G-vec00696-002-s359><adapt.sich_passen><de> Aus diesem Grund passen sich Jacken mit hydrophilen Membranen deinem Aktivitätsniveau an und speichern hervorragend Wärme.
<G-vec00696-002-s360><adapt.sich_passen><en> Nearly a billion shorter fibers adapt to your movements to create our pillow’s signature springy support.
<G-vec00696-002-s360><adapt.sich_passen><de> Fast eine Milliarde winzig kleiner Fasern im inneren Kissen passen sich deinen Bewegungen an und sorgen für angenehm federnde Unterstützung.
<G-vec00696-002-s361><adapt.sich_passen><en> Personalizable front panels and individual appearance adapt flexible to the CI and the application site.
<G-vec00696-002-s361><adapt.sich_passen><de> Personalisierbare Fronten und individuelle Erscheinung passen sich der CI und dem Einsatzort flexibel an.
<G-vec00696-002-s362><adapt.sich_passen><en> The MEX gooseneck microphones with their numerous mounting accessories adapt perfectly to any environment.
<G-vec00696-002-s362><adapt.sich_passen><de> Die MEX-Schwanenhalsmikrofone mit ihrem zahlreichen Montagezubehör passen sich jeder Umgebung bestens an.
<G-vec00696-002-s363><adapt.sich_passen><en> Made from high-quality, soft materials, they adapt perfectly to the changes in your figure, ensuring that you feel comfortable.
<G-vec00696-002-s363><adapt.sich_passen><de> Aus hochwertigen, weichen Materialien passen sie sich den Veränderungen der Figur perfekt an und sorgen so für Ihr Wohlgefühl.
<G-vec00696-002-s364><adapt.sich_passen><en> Most adapt as fast as any other employee, some need more time and adapt gradually.
<G-vec00696-002-s364><adapt.sich_passen><de> Die meisten passen sich so schnell wie jeder andere Mitarbeiter an, einige brauchen mehr Zeit und passen sich gradweise an.
<G-vec00696-002-s366><adapt.sich_passen><en> Minimize delays and adapt to unforeseen circumstances with real-time monitoring of operations.
<G-vec00696-002-s366><adapt.sich_passen><de> Durch Echtzeitüberwachung der Betriebe minimieren Sie Verspätungen und passen sich unvorhergesehenen Umständen an.
