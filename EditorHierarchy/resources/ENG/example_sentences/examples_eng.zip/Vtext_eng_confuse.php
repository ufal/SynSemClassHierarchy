<G-vec00589-002-s022><confuse.durcheinanderbringen><en> Other contemporary definitions of mindfulness may avoid the mistake of confusing mindfulness with awakening, but they still confuse it with qualities that sometimes are and sometimes aren’t useful on the path.
<G-vec00589-002-s022><confuse.durcheinanderbringen><de> Andere zeitgenössische Beschreibungen von Achtsamkeit mögen den Fehler des Durcheinanderbringens von Achtsamkeit mit Erwachen meiden, doch sie bringen sie mit Qualitäten durcheinander, die manchmal nützlich für den Pfad sind, und manches Mal nicht.
<G-vec00589-002-s057><confuse.irritieren><en> Although you are free to reassign existing keyboard shortcuts to the controls on your form template, doing so can confuse users who are accustomed to these Office shortcuts.
<G-vec00589-002-s057><confuse.irritieren><de> Obwohl Sie den Steuerelementen auf Ihrer Formularvorlage vorhandene Tastenkombinationen neu zuordnen können, ist es möglich, dass die mit diesen Office-Tastenkombinationen vertrauten Benutzer dadurch irritiert werden.
<G-vec00589-002-s165><confuse.sorgen><en> But they can also distract the driver from traffic or confuse them with wrong information.
<G-vec00589-002-s165><confuse.sorgen><de> Andererseits können sie vom Verkehr ablenken oder mit falschen Informationen für Verwirrung sorgen.
<G-vec00589-002-s166><confuse.stiften><en> The purpose of this is to gain time, to confuse and disorient the movement and to trick the opposition into making a deal with the oligarchy and preserve the system.
<G-vec00589-002-s166><confuse.stiften><de> Zweck dieses Manövers ist es, Zeit zu gewinnen, Verwirrung zu stiften und die Opposition dazu zu bringen in eine Koalition mit der Oligarchie einzutreten – mit dem einzigen Ziel das System zu stabilisieren und zu retten.
<G-vec00589-002-s060><confuse.verwirren><en> Though a page's title can be changed, you should take care not to confuse the reader by giving it a title that is completely different from the page's name.
<G-vec00589-002-s060><confuse.verwirren><de> Obwohl ein Titel einer Seite änderbar ist, sollten Sie Ihre Leserinnen und Leser nicht mit einem Titel verwirren, der komplett unterschiedlich zum Namen der Seite ist.
<G-vec01170-002-s021><confuse.durcheinanderbringen><en> His first series–huge comics–can be considered soap operas about our image–saturated and cynical era. The artist works with prima facie ordinary objects, but he tends to confuse viewers by hiding the context, producing a powerful psychological tension in his series.
<G-vec01170-002-s021><confuse.durcheinanderbringen><de> Der Künstler richtet sich, auf den ersten Blick, an alltägliche Sachen, aber mit seiner Neigung den Zuschauer aus dem Konzept zu bringen, “vernebelt” er gewöhnlich den Kontext und schafft in seinen Serien den Zustand einer starken psychischen Spannung.
<G-vec01170-002-s037><confuse.durcheinanderbringen><en> But no one should confuse this outcome with a solution to the problem of Iran’s nuclear ambitions or its contributions to the ongoing turmoil in the Middle East.
<G-vec01170-002-s037><confuse.durcheinanderbringen><de> Doch sollte niemand dieses Ergebnis mit der Lösung des Problems der iranischen Nuklearambitionen oder dem Beitrag des Landes zu den anhaltenden Turbulenzen im Nahen Osten durcheinanderbringen.
<G-vec01170-002-s038><confuse.durcheinanderbringen><en> Do not try to force friendly meetings prematurely, as this can confuse you and your ex.
<G-vec01170-002-s038><confuse.durcheinanderbringen><de> Versuche nicht, voreilig freundschaftliche Treffen zu arrangieren, da dich das und deinen/deine Ex durcheinanderbringen könnte.
<G-vec01170-002-s039><confuse.durcheinanderbringen><en> That is why it is absurd, as the Mensheviks tried to do, and as some people still do, to confuse the party with the class.
<G-vec01170-002-s039><confuse.durcheinanderbringen><de> Deshalb ist es absurd, wenn die Menschewiki (und einige Leute heute immer noch) versuchten, Partei und Klasse durcheinanderzuwerfen.
<G-vec01170-002-s059><confuse.durcheinanderbringen><en> The foursome get hyped from their fans and I can't help the feeling, that all the girls confuse our Matthew-Superstar a bit up there.
<G-vec01170-002-s059><confuse.durcheinanderbringen><de> Das Quartet wird fgehyped ohne Ende von seinen Fans, und ab und zu kann ich mich nicht des Eindrucks erwehren, als ob die Mädels unseren Matthew – Superstar ganz schön aus dem Konzept bringen.
<G-vec01170-002-s070><confuse.vermischen><en> With the sense of spirituality of renewal and not of the restoration of old times, we should try to distinguish and not confuse Medjugorje with other cases of apparitions.
<G-vec01170-002-s070><confuse.vermischen><de> Im Sinne einer Spiritualität der Erneuerung unserer Zeit, nicht der Restaurierung alter Zeiten, sollten wir bemüht sein, das Phänomen Medjugorje von anderen Erscheinungsphänomenen zu unterscheiden und nicht zu vermischen.
<G-vec01170-002-s071><confuse.vermischen><en> But there is nothing surprising about this, seeing that they confuse the scriptural prophecies of the Millennium with those that refer to the New Creation.
<G-vec01170-002-s071><confuse.vermischen><de> Doch dies ist nicht weiter verwunderlich, vermischen sie doch die Prophezeiungen der Schrift auf das Millennium mit jenen auf die Neue Schöpfung.
<G-vec01170-002-s072><confuse.vermischen><en> A.T.: The first challenge is to not confuse religion and terrorism, and to remember that extremism is a phenomenon that affects all religions.
<G-vec01170-002-s072><confuse.vermischen><de> A.T.: Die erste Herausforderung ist, Religion und Terrorismus nicht zu vermischen, und nicht zu vergessen, dass das Phänomen des Extremismus alle Religionen betrifft.
<G-vec01170-002-s020><confuse.verwechseln><en> People often confuse borders and gridlines in Excel.
<G-vec01170-002-s020><confuse.verwechseln><de> Die Benutzer verwechseln in Excel häufig Rahmen und Gitternetzlinien.
<G-vec01170-002-s024><confuse.verwechseln><en> Don’t confuse lactose intolerance with cow milk protein allergy (CMP)
<G-vec01170-002-s024><confuse.verwechseln><de> Die Laktoseintoleranz darf nicht mit der Milcheiweissallergie (echte Allergie gegen Kuhmilch-Eiweiss) verwechselt werden.
<G-vec01170-002-s025><confuse.verwechseln><en> Contrary to her critics' charge, Arendt's critique of cognitive claims in the political realm was not, never make a cognitive judgment when you judge politically; it was, do not confuse a cognitive judgment for judging politically.
<G-vec01170-002-s025><confuse.verwechseln><de> Ganz im Gegensatz zu den Vorwürfen ihrer KritikerInnen bestand Arendts Kritik kognitiver Ansprüche im Bereich des Politischen nicht darin, zu sagen: "Urteile niemals kognitiv, wenn du politisch urteilst"; sondern: "Verwechsle nie ein kognitives Urteil mit politischem Urteilen".
<G-vec01170-002-s029><confuse.verwechseln><en> If you are mildly dehydrated, your brain may be confuse a need for water with hunger.
<G-vec01170-002-s029><confuse.verwechseln><de> [7] Wenn du leicht dehydriert bist, kann es sein, dass dein Gehirn Durst mit Hunger verwechselt.
<G-vec01170-002-s063><confuse.verwechseln><en> Even dried grasshoppers are offered and you have to be careful not to confuse them with the chilies.
<G-vec01170-002-s063><confuse.verwechseln><de> Sogar getrocknete Heuschrecken werden angeboten und man muss aufpassen, dass man diese nicht mit den Chilis verwechselt.
<G-vec01170-002-s074><confuse.verwechseln><en> Don't confuse expertise for wisdom.
<G-vec01170-002-s074><confuse.verwechseln><de> Verwechsel Kompetenz nicht mit Weisheit.
<G-vec01170-002-s075><confuse.verwechseln><en> ANSWER: Don’t confuse the „Hall of Records“ with the Cave of Creation, where the Akashic records are kept.
<G-vec01170-002-s075><confuse.verwechseln><de> ANTWORT: Verwechsele die „Halle der Aufzeichnungen“ nicht mit der Höhle der Schöpfung, wo die Akasha-Chronik aufbewahrt wird.
<G-vec01170-002-s076><confuse.verwechseln><en> We mustn’t confuse this right with forms of « prestige » remuneration, which cajoles more the prestige of politics, making that right his whim.
<G-vec01170-002-s076><confuse.verwechseln><de> Verwechseln wir nicht dieses Recht mit den Formen der Entschädigung durch das „Prestige“, wie es die Politiker tun, die sich aus diesem Recht ein Vergnügen machen.
<G-vec01170-002-s077><confuse.verwechseln><en> Do not confuse with the Nymphaea caerulea also called blue lotus which is a water lily.
<G-vec01170-002-s077><confuse.verwechseln><de> Verwechseln Sie nicht mit der Nymphaea caerulea, auch Blaue Lotus genannt, der eine Seerose ist.
<G-vec01170-002-s078><confuse.verwechseln><en> Be careful not to confuse the zone of accompaniment (several hundred of metres before and after each refreshment post, limits of which are clearly marked) with the zone of assistance (the area of the refreshment post reserved for this use).
<G-vec01170-002-s078><confuse.verwechseln><de> Verwechseln Sie also nicht die Zone, wo Begleitung erlaubt ist (einige Hundert Meter vor und nach jeder Labestelle, die durch Schilder gekennzeichnet sind) und die Zone, wo Hilfe erlaubt ist (ein Teil der Labestelle, die für Hilfeleistung vorgesehen ist).
<G-vec01170-002-s079><confuse.verwechseln><en> From the moment a hunter can confuse a mare with a boar, we can be horrified by the idea that tomorrow he could confuse an animal with a child.
<G-vec01170-002-s079><confuse.verwechseln><de> Ab dem Moment, in dem ein Jäger eine Stute mit einem Wildschwein verwechselt, haben wir Angst vor der Idee, dass er morgen ein Tier mit einem Kind verwechseln könnte.
<G-vec01170-002-s080><confuse.verwechseln><en> That the invalids do not make the healthy sick — and that would be such a softening — that should surely be ruling point of view on earth. But that would require above everything that the healthy remain separated from the sick, protected even from the gaze of sick people, so that they don’t confuse themselves with the ill.
<G-vec01170-002-s080><confuse.verwechseln><de> Dass die Kranken nicht die Gesunden krank machen — und dies wäre eine solche Verweichlichung — das sollte doch der oberste Gesichtspunkt auf Erden sein: — dazu aber gehört vor allen Dingen, dass die Gesunden von den Kranken abgetrennt bleiben, behütet selbst vor dem Anblick der Kranken, dass sie sich nicht mit den Kranken verwechseln.
<G-vec01170-002-s081><confuse.verwechseln><en> It likewise exposes another problem of our times: that certain persons confuse the appearance of modernity with artistic quality.
<G-vec01170-002-s081><confuse.verwechseln><de> Und zugleich bringt es ein anderes aktuelles Problem an den Tag: bestimmte Personen verwechseln den Anschein von Modernität mit künstlerischer Qualität.
<G-vec01170-002-s082><confuse.verwechseln><en> For many people in fact, it is much easier and better to have drowsy and dull kids who confuse happiness with a sofa. For many people, that is more convenient than having young people who are alert and searching, trying to respond to God’s dream and to all the restlessness present in the human heart.
<G-vec01170-002-s082><confuse.verwechseln><de> Gewiss, für viele ist es einfacher und vorteilhafter, duselige und benommene Jugendliche zu haben, die das Glück mit einem Sofa verwechseln; vielen scheint das günstiger, als aufgeweckte junge Menschen zu haben, die reagieren möchten, die danach verlangen, dem Traum Gottes zu entsprechen und allen Bestrebungen des Herzens.
<G-vec01170-002-s083><confuse.verwechseln><en> I was taught that you are a mystery, but you have taught me that I should not confuse your nature with your identity.
<G-vec01170-002-s083><confuse.verwechseln><de> Ich wurde belehrt, dass Du ein Geheimnis seist, aber Du hast mich gelehrt, dass ich Deine Natur nicht mit deiner Identität verwechseln soll.
<G-vec01170-002-s084><confuse.verwechseln><en> Do not confuse these for good sources of protein.
<G-vec01170-002-s084><confuse.verwechseln><de> Verwechseln Sie diese für eine gute Quelle für Protein.
<G-vec01170-002-s085><confuse.verwechseln><en> Be careful not to confuse the noac option with "no data caching."
<G-vec01170-002-s085><confuse.verwechseln><de> Achtung: Verwechseln Sie die Option noac nicht mit »keine Daten-Zwischenspeicherung«.
<G-vec01170-002-s086><confuse.verwechseln><en> Often we confuse love with desire and sexual satisfaction.
<G-vec01170-002-s086><confuse.verwechseln><de> Oft verwechseln wir Liebe mit Verlangen und mit sexueller Befriedigung.
<G-vec01170-002-s087><confuse.verwechseln><en> There's a whole lot of shaking going on when two pornstars confuse twitchy compadres Beavis and Butt-head for drug dealers.
<G-vec01170-002-s087><confuse.verwechseln><de> Im zweiten Teil geht es drunter und drüber, als zwei Pornostars Beavis und Butt-Head mit Drogendealern verwechseln.
<G-vec01170-002-s088><confuse.verwechseln><en> Furthermore, many investigators, scientists, and other interested parties confuse “biogeographical ancestry”, “bio-ethnicity” and “ethnicity.”
<G-vec01170-002-s088><confuse.verwechseln><de> Zudem verwechseln viele Ermittler, Wissenschaftler und andere Interessierte ‚biogeografische Abstammung’ mit ‚Ethnizität’.
<G-vec01170-002-s089><confuse.verwechseln><en> Sometimes we confuse our baby’s second year with his third.
<G-vec01170-002-s089><confuse.verwechseln><de> Manchmal verwechseln wir das zweite mit dem dritten Jahr unseres Babys.
<G-vec01170-002-s090><confuse.verwechseln><en> Note: Take care not to confuse extract of Garcinia cambogia rind with resin of Garcinia hanburyi, a powerful laxative with potentially serious side-effects. The very latest scientific advances
<G-vec01170-002-s090><confuse.verwechseln><de> Achtung: Achten Sie darauf, den Schalenextrakt der Früchte von Garcinia cambogia mit dem Harz von Garcinia hanburyi, einem starken Abführmittel mit potenziell schweren Nebenwirkungen, nicht zu verwechseln.
<G-vec01170-002-s091><confuse.verwechseln><en> It stops me fooling myself and it allows me to not confuse my present concepts of the then events with the actual experience.
<G-vec01170-002-s091><confuse.verwechseln><de> Es verwehrt mir, mir etwas vorzumachen, und macht mir möglich, meine heutigen Begriffe von dem damaligen Geschehen nicht mit dem damaligen gleichzeitigen Erlebnis zu verwechseln.
<G-vec01170-002-s092><confuse.verwechseln><en> No, not serious - do not confuse these two concepts.
<G-vec01170-002-s092><confuse.verwechseln><de> Nein, nicht ernst - verwechseln Sie diese beiden Begriffe nicht.
<G-vec01170-002-s093><confuse.verwechseln><en> Be careful not to confuse bond ETFs with a short time to maturity, with short ETFs.
<G-vec01170-002-s093><confuse.verwechseln><de> Verwechseln Sie Anleihen-ETFs mit einer kurzen Laufzeit (häufig bezeichnet als „Short”) auf keinen Fall mit sogenannten Short-ETFs.
<G-vec01170-002-s094><confuse.verwechseln><en> Do not confuse the syntax of the CASE statement with that of the CASE expression.
<G-vec01170-002-s094><confuse.verwechseln><de> Verwechseln Sie die Syntax des CASE-Ausdrucks nicht mit der Syntax der CASE-Anweisung.
<G-vec01170-002-s095><confuse.verwechseln><en> Numerous critics have pointed out that we should not confuse the social reality of the Third Reich with the increasingly perfected images developed by the scriptwriters and directors in Joseph Goebbels’s Ministry of Propaganda.
<G-vec01170-002-s095><confuse.verwechseln><de> Es ist wiederholt darauf hingewiesen worden, dass man die gesellschaftliche Wirklichkeit des »Dritten Reiches« nicht mit dem propagandistischen Bild verwechseln darf, das die Regisseure und Texter aus Goebbels’ Ministerium mit wachsender Perfektion von ihm entwarfen.
<G-vec01170-002-s096><confuse.verwechseln><en> Do not confuse these shoes with the light up shoes you had as a child.
<G-vec01170-002-s096><confuse.verwechseln><de> Verwechseln Sie diese Schuhe nicht mit den lustigen Turnschuhen, die Sie als Kind mal hatten.
<G-vec01170-002-s097><confuse.verwechseln><en> Stop Finning DE: There is the thesis that sharks confuse surfer with seals.
<G-vec01170-002-s097><confuse.verwechseln><de> Stop Finning DE: Es gibt ja die Theorie, dass Haie Surfbretter mit Robben verwechseln würden.
<G-vec01170-002-s098><confuse.verwechseln><en> The practitioner added that, because the regime intentionally supplanted correct principles with wrong ones, most Chinese people in the mainland confuse wrong for right and right for wrong.
<G-vec01170-002-s098><confuse.verwechseln><de> Er fügte hinzu, dass das Regime gezielt korrekte Prinzipien durch falsche ersetze, sodass die meisten Chinesen auf dem Festland falsch mit richtig und richtig mit falsch verwechseln würden.
<G-vec01170-002-s099><confuse.verwechseln><en> 3) Another way of stating 2) is: Never confuse right with wrongmindedness.
<G-vec01170-002-s099><confuse.verwechseln><de> 3) Eine andere Ausdrucksweise für 2) ist: Verwechselt nie Klar- mit UnVerständlichkeit.
<G-vec01170-002-s100><confuse.verwechseln><en> “Da” could term this “in-between” tensioned by the fundamental interplay of “Being” – “Beings” – “nothingness-Nihilation” and potentiated by transcendence; do not confuse it with nihilism.
<G-vec01170-002-s100><confuse.verwechseln><de> „Da” könnte dieses „Zwischen“ bezeichnen, das gespannt ist durch das grundlegende Zusammenspiel von „Sein“ – „Seiende“ – „Nichts-Nihilisierung“, potentialisiert durch Transzendenz, was nicht mit Nihilismus verwechselt werden darf.
<G-vec01170-002-s101><confuse.verwechseln><en> It was the object of ecstatic comments in Germany and throughout the world, among all the Pavlovian cretins who confuse the refusal of the politically correct with the right to let loose and, in so doing, liberate the stench of the most pestilential of thoughts.
<G-vec01170-002-s101><confuse.verwechseln><de> Grass’ Gedicht war der Gegenstand entzückter Kommentare, in Deutschland und im Rest der Welt, bei allen Kretins, die in ihren pawlowschen Reflexen die Ablehnung des politisch Korrekten verwechselt haben mit dem Recht, sich gehen zu lassen und dabei den aufs Übelste verpesteten Mief ihrer Gedanken freizusetzen.
<G-vec01170-002-s103><confuse.verwechseln><en> In other words: those who inquire about the attractiveness of what communists have to “offer” confuse the critique of capitalism with election slogans of an alternative elite who promise to run things better for their valued citizens than those currently holding power.
<G-vec01170-002-s103><confuse.verwechseln><de> Anders gesagt: Wer nach der Attraktivität des kommunistischen „Angebots“ fragt, der verwechselt Kapitalismuskritik mit der Wahlwerbung einer alternativen Elite, die verspricht, es dem werten Bürger besser zu richten als diejenigen, die die Macht innehaben.
<G-vec01170-002-s104><confuse.verwechseln><en> These buttons are correctly positioned and come out enough from the device so as not to confuse them.
<G-vec01170-002-s104><confuse.verwechseln><de> Diese Knöpfe sind richtig positioniert und kommen so weit aus dem Gerät heraus, dass sie nicht verwechselt werden können.
<G-vec01170-002-s105><confuse.verwechseln><en> It’s important not to confuse this with arbitrage which is similar but that is a different discussion.
<G-vec01170-002-s105><confuse.verwechseln><de> Es ist des Weiteren wichtig, dass dies nicht mit Arbitrage-Wetten verwechselt wird, das ist eine ähnliche aber andere Sachlage.
<G-vec01170-002-s106><confuse.verwechseln><en> Many people confuse the transfer process as an escrow service but they are actually different. The three parties involved in the transfer process are: Sedo, the seller, and the buyer.
<G-vec01170-002-s106><confuse.verwechseln><de> Häufig wird der Transfer-Prozess im Zuge eines Domainkaufs mit einem Treuhandservice verwechselt, doch es gibt Unterschiede: Die drei Parteien, die in einen Transfer-Prozess involviert sind, sind: Sedo, der Verkäufer und der Käufer.
<G-vec01170-002-s107><confuse.verwechseln><en> The reason is that WPF may otherwise confuse the syntax with the one used for Markup Window>
<G-vec01170-002-s107><confuse.verwechseln><de> Der Grund dafür ist, dass WPF ansonsten die Syntax mit der für Markup Extensions verwendeten verwechselt.
<G-vec01170-002-s108><confuse.verwechseln><en> A sleep hangover is common with long naps, which is why experts recommend brief 20-minute naps (no longer) on the couch or in a comfortable chair rather then in your bed so as not to confuse naps with bedtime.
<G-vec01170-002-s108><confuse.verwechseln><de> Ein Schlaf-Kater tritt häufig nach langen Mittagsschläfchen auf, weshalb Experten nur kurze Nickerchen von 20 Minuten (nicht länger) auf der Couch oder in einem bequemen Stuhl statt im Bett empfehlen, damit die Mittagsschläfchen nicht mit dem nächtlichen Schlaf verwechselt werden.
<G-vec01170-002-s109><confuse.verwechseln><en> However, where the application of the other provisions of this Directive, in particular those set out in Article 3, would not enable consumers in the Member State of marketing to know the true nature of the foodstuff and to distinguish it from foodstuffs with which they could confuse it, the sales name shall be accompanied by other descriptive information which shall appear in proximity to the sales name.
<G-vec01170-002-s109><confuse.verwechseln><de> Wenn jedoch die Anwendung der anderen Bestimmungen dieser Verordnung, insbesondere denjenigen des Artikels 9, es den Verbrauchern im Vermarktungsmitgliedstaat nicht ermöglicht, die tatsächliche Art des Lebensmittels zu erkennen und es von Lebensmitteln zu unterscheiden, mit denen es verwechselt werden könnte, ist die Bezeichnung des Lebensmittels durch weitere beschreibende Informationen zu ergänzen, die in der Nähe der Bezeichnung des Lebensmittels anzubringen sind.
<G-vec01170-002-s110><confuse.verwechseln><en> It's understandable to confuse them as both will glean the same outcome: a new home.
<G-vec01170-002-s110><confuse.verwechseln><de> Diese beiden Berufe werden oft verwechselt, weil sie zu dem gleichen Ergebnis beitragen: ein neues Zuhause.
<G-vec01170-002-s111><confuse.verwechseln><en> Many minor remedy abbreviations have been changed in order not to confuse them with other remedy abbreviations that represent completely different remedies.
<G-vec01170-002-s111><confuse.verwechseln><de> Viele Abkürzungen kleinerer Mittel wurden verändert, damit sie nicht mit anderen Arzneimittelabkürzungen verwechselt werden, die für völlig andere Arzneimittel stehen.
<G-vec01170-002-s112><confuse.verwechseln><en> This dogs often have large white areas on their body, especially on their head, because of a pigment disorder. Some lays confuse them with "White Collies".
<G-vec01170-002-s112><confuse.verwechseln><de> Da die Hunde auf Grund einer Pigmentstörung oft große Weißanteile am Körper, insbesondere am Kopf haben werden sie von Laien hin und wieder mit den "Weißen Collies" verwechselt.
<G-vec01170-002-s113><confuse.verwechseln><en> Do not confuse this with Human awareness.
<G-vec01170-002-s113><confuse.verwechseln><de> Verwechselt das nicht mit menschlicher Aufmerksamkeit.
<G-vec01170-002-s114><confuse.verwechseln><en> And when thinking of the Sethite priesthood, do not confuse those high-minded and noble teachers of health and religion, those true educators, with the debased and commercial priesthoods of the later tribes and surrounding nations.
<G-vec01170-002-s114><confuse.verwechseln><de> Und wenn ihr an die sethitische Priesterschaft denkt, dann verwechselt diese hochgesinnten und edlen Lehrer der Gesundheit und Religion, diese wahren Erzieher, nicht mit den verderbten und geschäftstüchtigen Priesterschaften der späteren Stämme und umliegenden Nationen.
<G-vec01170-002-s115><confuse.verwechseln><en> If you’ve been diagnosed with osteoarthritis, you may confuse it with other common forms of arthritis, such as rheumatoid arthritis, but the two conditions are quite different in origin.
<G-vec01170-002-s115><confuse.verwechseln><de> Wenn Ihnen Arthrose diagnostiziert wurde, haben Sie dies vielleicht auch mit einer anderen Form der Arthritis verwechselt, wie dem Gelenkrheumatismus, aber die zwei Krankheiten haben einen grundverschiedenen Ursprung.
<G-vec01170-002-s116><confuse.verwechseln><en> He may confuse the expectations of the outer world with his intrinsic value as an individual.
<G-vec01170-002-s116><confuse.verwechseln><de> Möglicherweise verwechselt er die Erwartungen der äußeren Welt mit seinem inneren Wert als Individuum.
<G-vec01170-002-s117><confuse.verwechseln><en> The one person may always confuse left and right, another may not be able to bang a nail into a wall straight, a third doesn’t know what “phenomenology” means – quite apart from the ability to dance, cut cloth, plane wood, or iron shirts.
<G-vec01170-002-s117><confuse.verwechseln><de> Einer verwechselt andauernd rechts und links, ein zweiter kann keinen Nagel in die Wand schlagen, eine dritte weiß nicht, was „Phänomenologie“ bedeutet – ganz abgesehen von Fertigkeiten wie Tanzen, Schneidern, Hobeln oder Hemdenbügeln.
<G-vec01170-002-s118><confuse.verwechseln><en> Don’t confuse them with regular sign up, match deposit or welcome bonuses that require a deposit to unlock the offer.
<G-vec01170-002-s118><confuse.verwechseln><de> Bitte verwechselt diese nicht mit einer regulären Anmeldung, einer Match-Einzahlung oder Willkommensboni, die eine Einzahlung erfordern, um das Angebot freizuschalten.
<G-vec01170-002-s119><confuse.verwechseln><en> Never confuse wisdom with luck.
<G-vec01170-002-s119><confuse.verwechseln><de> Verwechsle niemals Weisheit mit Glück.
<G-vec01170-002-s120><confuse.verwechseln><en> Don’t confuse the wolf spider with a brown recluse spider.
<G-vec01170-002-s120><confuse.verwechseln><de> Verwechsle die Wolfsspinne nicht mit der braunen Einsiedlerspinne.
<G-vec01170-002-s121><confuse.verwechseln><en> Strangely enough I always confuse it with „Chanel Mademoiselle“, which is pretty similar I guess.
<G-vec01170-002-s121><confuse.verwechseln><de> Komischerweise verwechsle ich es oft mit „Chanel Mademoiselle“, was für mich echt total ähnlich riecht.
<G-vec01170-002-s122><confuse.verwechseln><en> Don't confuse fame with success.
<G-vec01170-002-s122><confuse.verwechseln><de> Verwechsle niemals Ruhm mit Erfolg.
<G-vec01170-002-s123><confuse.verwechseln><en> Do not confuse notoriety and fame with greatness.
<G-vec01170-002-s123><confuse.verwechseln><de> Verwechsle Bekanntheit und Berühmtheit nicht mit wahrer Größe.
<G-vec01170-002-s124><confuse.verwechseln><en> Do not confuse the higher knowledge and the mental knowledge.
<G-vec01170-002-s124><confuse.verwechseln><de> Verwechsle nicht höheres Wissen mit mentalem Wissen.
<G-vec01170-002-s169><confuse.verwechseln><en> However, this also means that many men confuse friendliness with flirting.
<G-vec01170-002-s169><confuse.verwechseln><de> Das hat allerdings auch zur Folge, dass viele Männer Freundlichkeit mit Flirten verwechseln.
