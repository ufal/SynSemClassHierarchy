<G-vec00376-003-s475><close_down.schließen><en> To contact your fairy hold the pendant in your hand, close your eyes and meditate for a few minutes about the guidance or help you need.
<G-vec00376-003-s475><close_down.schließen><de> Um die Elfe zu kontaktieren, halte ihr Abbild in Deinen Händen, schließe die Augen und meditiere einige Minuten über die Führung oder Hilfestellung, die Du benötigst.
<G-vec00376-003-s476><close_down.schließen><en> ⇒ Once the glass jar is full, fill with distilled water until all the shredded cabbage is covered and top with the two cabbage leaves, close the lid.
<G-vec00376-003-s476><close_down.schließen><de> ⇒ Wenn der Glaskrug gefüllt und zusammen gepresst ist, fülle ihn mit dem destillierten Wasser auf, füge die noch ganzen Blätter hinzu und schließe das Ganze mit dem Deckel.
<G-vec00376-003-s477><close_down.schließen><en> Rooms How can I close the bottom of the bath.
<G-vec00376-003-s477><close_down.schließen><de> Zimmer Wie schließe ich den Boden des Bades.
<G-vec00376-003-s478><close_down.schließen><en> Close your eyes and flip a coin.
<G-vec00376-003-s478><close_down.schließen><de> Schließe deine Augen und wirf eine Münze.
<G-vec00376-003-s479><close_down.schließen><en> Aham Brahma Asmi and Tat Tvam Asi. your Ishta Devata for a few minutes and close your eyes.
<G-vec00376-003-s479><close_down.schließen><de> Betrachte das Bild deiner persönlichen Gottheit (IshtaDevata) ein paar Minuten lang und schließe die Augen.
<G-vec00376-003-s480><close_down.schließen><en> Train your fighter, master blows and receptions, engage with faceless enemies and close a gate of shadows in Shadow fight 2.
<G-vec00376-003-s480><close_down.schließen><de> Trainiere deinen Kämpfer, erlerne Schläge und Techniken, bekämpfe die gesichtslosen Feinde und schließe das Schattentor im Spiel Shadow fight 2.
<G-vec00376-003-s481><close_down.schließen><en> If possible, close your eyes for a moment and ask what it is.
<G-vec00376-003-s481><close_down.schließen><de> 5Wenn möglich, schließe deine Augen einen Augenblick und frage, was es ist.
<G-vec00376-003-s482><close_down.schließen><en> Must last until I close December.
<G-vec00376-003-s482><close_down.schließen><de> Muss reichen, bis ich Dezember schließe.
<G-vec00376-003-s483><close_down.schließen><en> Close your eyes, shut out the rest of the world, and think about your affirmations.
<G-vec00376-003-s483><close_down.schließen><de> Schließe Deine Augen, ziehe Dich vom Rest der Welt zurück und denke über Deine Affirmationen nach.
<G-vec00376-003-s484><close_down.schließen><en> To resolve this issue, please close and restart Destiny to initiate your update.
<G-vec00376-003-s484><close_down.schließen><de> Um diesen Fehler zu beheben, schließe Destiny und starte es erneut, um das Update zu beginnen.
<G-vec00376-003-s485><close_down.schließen><en> 6 Add the right kind of washing fluid and close the door.
<G-vec00376-003-s485><close_down.schließen><de> Gib die richtige Art von Waschmittel in die Trommel und schließe die Tür.
<G-vec00376-003-s486><close_down.schließen><en> 6 Close the Settings tab.
<G-vec00376-003-s486><close_down.schließen><de> Schließe den Tab "Einstellungen".
<G-vec00376-003-s487><close_down.schließen><en> I will close with another example of institutionalized "intersectional" feminism in action: Alicia's Iraqi parents took her to Sweden when she was four.
<G-vec00376-003-s487><close_down.schließen><de> Ich schließe mit einem weiteren Beispiel für institutionalisierten "intersektionellen" Feminismus in Aktion: Alicias irakische Eltern brachten sie mit vier Jahren nach Schweden.
<G-vec00376-003-s488><close_down.schließen><en> I sit in the open jeep and close my eyes for a moment.
<G-vec00376-003-s488><close_down.schließen><de> Ich sitze im offenen Jeep und schließe für einen Moment die Augen.
<G-vec00376-003-s489><close_down.schließen><en> When you wake up and remember your dream, write it down in your dream journal, then close your eyes and focus on the dream.
<G-vec00376-003-s489><close_down.schließen><de> Wenn du aufwachst und dich an deinen Traum erinnerst, dann schreibe es in deinem Traumtagebuch auf, schließe dann die Augen erneut und konzentriere dich auf den Traum.
<G-vec00376-003-s490><close_down.schließen><en> Click on the Facebook share icon and remember to close the window that now opens.
<G-vec00376-003-s490><close_down.schließen><de> Klick auf die Teilen-Funktion für Facebook, schließe das sich öffnende Fenster aber wieder.
<G-vec00376-003-s491><close_down.schließen><en> Before I close I will give you a loose guideline for a happily abundant life.
<G-vec00376-003-s491><close_down.schließen><de> Bevor ich schließe, werde euch eine lose Leitlinie für ein glückliches Leben der Fülle geben.
<G-vec00376-003-s492><close_down.schließen><en> Close the door as much as possible and look for uneven lines.
<G-vec00376-003-s492><close_down.schließen><de> Schließe die Tür so weit es eben geht und schau nach Unebenheiten.
<G-vec00376-003-s493><close_down.schließen><en> Now, close your eyes (after you're done reading this) and imagine Hollywood movie sets, beautiful historic districts, or foreign and exotic locales teeming with vibrant and interesting people who hang on your every word.
<G-vec00376-003-s493><close_down.schließen><de> Schließe nun die Augen (nachdem du den Artikel zu Ende gelesen hast) und stell dir die Kulissen in Hollywood vor, schöne historische Stadtteile, oder fremde und exotische Lokalitäten, voll lebendiger und interessanter Leute, die an deinen Lippen hängen.
<G-vec00376-003-s589><close_down.verschließen><en> Later on, after Sora, Donald, and Goofy defeat Ansem and attempt to close the door to Kingdom Hearts, King Mickey finally reappears with the Kingdom Key D, the Keyblade of the Realm of Darkness that he had gone to search for.
<G-vec00376-003-s589><close_down.verschließen><de> Nachdem Ansem, jener der die Dunkelheit sucht, besiegt ist, hilft er Sora Kingdom Hearts zu verschließen, in dem er erst die Herzlosen im Reich der Dunkelheit aufhält und danach mit Sora gemeinsam die Tür zur Dunkelheit von beiden Seiten verschließt.
<G-vec00376-003-s590><close_down.verschließen><en> They were used to close the garments in front of the neck.
<G-vec00376-003-s590><close_down.verschließen><de> Sie wurden verwendet, um die Halsöffnungen der Gewänder zu verschließen.
<G-vec00376-003-s591><close_down.verschließen><en> The energy Jennifer has invested in Space Between speaks to her conviction that growing numbers of people share her refusal to close their eyes to the realities of consumer industries.
<G-vec00376-003-s591><close_down.verschließen><de> Die Energie, die Jennifer in das Projekt Space Between investiert, rührt aus ihrer Überzeugung, dass es immer mehr Menschen gibt, die wie sie nicht die Augen vor den Zuständen in der Konsumgüterindustrie verschließen wollen.
<G-vec00376-003-s592><close_down.verschließen><en> To close this little slot is almost impossible, and I think that most KS fans do not know that there is such a milling in the bearing shield.
<G-vec00376-003-s592><close_down.verschließen><de> Diese kleine Schlitzfräsung zu verschließen ist so gut wie unmöglich und ich glaube das die meisten KS-Fans überhaupt nicht wissen dass es solch eine Fräsung im Lagerschild gibt.
<G-vec00376-003-s593><close_down.verschließen><en> It is also important that ospreys in diving into water when necessary can close their nostrils that are visible on the beak.
<G-vec00376-003-s593><close_down.verschließen><de> Es ist auch wichtig, dass Fischadler beim Eintauchen ins Wasser wenn nötig ihre Nasenlöcher, die auf dem Schnabel zu sehen sind, verschließen können.
<G-vec00376-003-s594><close_down.verschließen><en> To close a 16 mm PE pipe.
<G-vec00376-003-s594><close_down.verschließen><de> Zum verschließen eines 16 mm PE-Rohres.
<G-vec00376-003-s595><close_down.verschließen><en> So it does not help to close your eyes, to sweep something under the carpet or to avoid the problem.
<G-vec00376-003-s595><close_down.verschließen><de> Es hilft also nichts, die Augen zu verschließen, etwas unter den Teppich zu kehren oder dem Problem auszuweichen.
<G-vec00376-003-s596><close_down.verschließen><en> Hot melt and cold adhesive solutions are available to meet the needs of bag and sack construction as well as application of adhesives to be reactived to seal / close a bag after filling.
<G-vec00376-003-s596><close_down.verschließen><de> Wir bieten Schmelzklebstoff‑ und Kaltleimlösungen, die sowohl zur Herstellung von Beuteln und Taschen als auch zum Klebstoffauftrag zum Abdichten/Verschließen eines Beutels nach der Befüllung dienen.
<G-vec00376-003-s597><close_down.verschließen><en> Put the compound back into its re-sealable packaging and close it carefully to ensure the compound remains fresh.
<G-vec00376-003-s597><close_down.verschließen><de> Legen Sie die Masse zurück in die Packung, und verschließen Sie diese sorgfältig, damit die Masse nicht austrocknet.
<G-vec00376-003-s598><close_down.verschließen><en> To close the filling hole we use sealing plugs suitable to Epson cartridges.
<G-vec00376-003-s598><close_down.verschließen><de> Sie können die bei Octopus erhältlichen Verschlussstopfen für Epson Patronen zum Verschließen der Epson 24 oder Epson 26 Patronen verwenden.
<G-vec00376-003-s599><close_down.verschließen><en> Universality does away with the limits that close the world in and create differences and conflicts.
<G-vec00376-003-s599><close_down.verschließen><de> Die Universalität öffnet die Grenzen, die die Welt verschließen und Gegensätze und Konflikte schaffen.
<G-vec00376-003-s600><close_down.verschließen><en> You can close your tea maker with a stopper made of natural bamboo.
<G-vec00376-003-s600><close_down.verschließen><de> Mit einem Stopfen aus Naturbambus kannst du deinen Teebereiter verschließen.
<G-vec00376-003-s601><close_down.verschließen><en> Draco gave me a penetrating look, which told me what he thought about it; that they were blind ignorant morons to close their eyes against the facts that the Dark Lord was back.
<G-vec00376-003-s601><close_down.verschließen><de> Draco warf mir einen durchdringenden Blick zu, der besagte was die anderen doch für blinde Ignoranten waren, die Augen davor zu verschließen, dass der Dark Lord zurück war.
<G-vec00376-003-s602><close_down.verschließen><en> Depending on your material, you may have to close the ring past the final position you want, then bring it back.
<G-vec00376-003-s602><close_down.verschließen><de> Je nach Material musst du den Ring möglicherweise hinter der gewünschten Position verschließen und danach den Verschluss etwas zurückbiegen.
<G-vec00376-003-s603><close_down.verschließen><en> CONCEPT All those curious about Paul Celan´s life and work will find it intricate and dark: “historically dark” because Paul Celan (1920 – 1970) experienced the atrocities of the Third Reich and its aftermath; “personally dark” because the poet constantly tried to close himself off to he outside world.
<G-vec00376-003-s603><close_down.verschließen><de> Schwer fassbar und dunkel liegen das Leben und Werk des Dichters Paul Celan (1920 – 1970) vor demjenigen, der sich ihm zu nähern versucht: „Historisches Dunkel“ der entsetzlichen Verbrechen des „Dritten Reiches“ und deren Folgen, „persönliches Dunkel“ im Leben des Dichters, das er stets vor der Außenwelt zu verschließen suchte und schließlich das außergewöhnliche, tiefe und komplexe Dunkel seiner Dichtung, zu derer Entschlüsselung bis heute immer wieder neue Zugänge gesucht werden.
<G-vec00376-003-s604><close_down.verschließen><en> Close the bottle with measuring cap and shake to homogenize the solution.
<G-vec00376-003-s604><close_down.verschließen><de> Verschließen Sie die Flasche mit Messkappe und schütteln, um die Lösung zu homogenisieren.
<G-vec00376-003-s605><close_down.verschließen><en> The doors close the compartment in which the stereo and home cinema devices are hidden. Such doors are equipped with special cylinder hinges thanks to which they can be opened 180°.
<G-vec00376-003-s605><close_down.verschließen><de> Die Flügel verschließen den Schrank, in welchem die Stereoanlage und das Home Cinema versteckt sind: diese sind mit speziellen Zylinderscharnieren ausgestattet, welche ein Öffnen zu 180° ermöglichen.
<G-vec00376-003-s606><close_down.verschließen><en> The distance from the end becomes smaller and smaller; the signs will increase, and the recognizing and the believing is made easy for everyone with that; and so the will of man is good, he will also not resist and close his mind to these references.
<G-vec00376-003-s606><close_down.verschließen><de> Der Abstand vom Ende wird immer kleiner, die Zeichen werden sich mehren, und einem jeden wird dadurch das Erkennen und das Glauben leichtgemacht; und so der Wille des Menschen gut ist, wird er sich auch nicht sträuben und sich diesen Hinweisen verschließen.
<G-vec00376-003-s607><close_down.verschließen><en> A serious examination would convince them, that your knowledge cannot simple be rejected, because it holds deep truths, because they could not close their minds to the logical conclusions, which show a giver, who knows about everything and for that reason can also give complete enlightenment.
<G-vec00376-003-s607><close_down.verschließen><de> Eine ernsthafte Prüfung würde sie überzeugen, daß euer Wissen nicht einfach abgelehnt werden kann, weil es tiefe Wahrheiten birgt, weil sie sich den logischen Folgerungen nicht verschließen könnten, die einen Geber verraten, Der um alles weiß und darum auch lückenlos Aufklärung geben kann.
