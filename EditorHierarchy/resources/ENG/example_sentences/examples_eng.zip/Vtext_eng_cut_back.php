<G-vec00118-002-s228><cut_back.kürzen><en> On the back of 2012 when banks added more than 534.6 tons to gold reserves, the most since 1964, the move suggests a possible shift in dynamics as several banks have now cut their gold forecasts for 2013.
<G-vec00118-002-s228><cut_back.kürzen><de> Nach 2012, als die Banken mehr als 534,6 Tonnen an Goldreserven aufstockten, die größte Reserve seit 1964, zeigt diese Bewegung, dass die Dynamik vor einer Wende steht, da zahlreiche Banken nun ihre Gold-Prognosen für 2013 gekürzt haben.
<G-vec00118-002-s229><cut_back.kürzen><en> Though UK development funds have been made available to support health systems, with some positive results, the UK recently cut its aid to both countries as it promotes greater private healthcare across Africa.
<G-vec00118-002-s229><cut_back.kürzen><de> Obwohl öffentliche Gesundheitssysteme mit britischen Entwicklungshilfegeldern gefördert wurden, mit einigen positiven Ergebnissen, hat Großbritannien kürzlich seine Entwicklungshilfe an beide Länder gekürzt, da es überall in Afrika eine private Gesundheitsversorgung fördert.
<G-vec00118-002-s230><cut_back.kürzen><en> The World Bank predicts that, even under the most optimistic growth and reform scenarios, total public spending would have to be cut by an unprecedented 6.5 percent of GDP.
<G-vec00118-002-s230><cut_back.kürzen><de> Die Weltbank geht davon aus, dass sogar unter Voraussetzung der optimistischsten Wachstums- und Reformszenarien die öffentlichen Ausgaben um nie da gewesene 6,5 Prozent des BIP gekürzt werden müssten.
<G-vec00118-002-s231><cut_back.kürzen><en> Wages would have to be cut by means of inflation, the profit rate supported by lowering the interest rate, and the remaining unemployment absorbed by public works, until these measures produced the beginning of a new prosperity, at which point the economy could be left once again to the automatic mechanism of the market.
<G-vec00118-002-s231><cut_back.kürzen><de> Die Löhne müßten auf dem Wege der Inflation gekürzt, die Profitrate durch die Senkung der Zinsrate gestützt, und der verbleibende Rest der Arbeitslosigkeit durch öffentliche Ausgaben aufgesaugt werden, bis sich durch all diese Maßnahmen eine neue Konjunktur herausbildet, womit man die Wirtschaft für eine weitere Etappe dem Automatismus des Marktes überlassen könnte.
<G-vec00118-002-s232><cut_back.kürzen><en> (Brussels, 09.05.2018) According to a proposal tabled by the EU Commissioner for Budget and Human Resources Günther Oettinger, the agriculture budget is to be cut by five percent.
<G-vec00118-002-s232><cut_back.kürzen><de> (Brüssel, 09.05.2018) Nach Vorschlag von EU-Haushaltskommissar Günther Oettinger soll der Agrarhaushalt um fünf Prozent gekürzt werden.
<G-vec00118-002-s233><cut_back.kürzen><en> A second version, now cut to two acts, was staged at the Theater an der Wien in 1806 — with greater success, but with no demand for further performances.
<G-vec00118-002-s233><cut_back.kürzen><de> Eine zweite Fassung, nunmehr gekürzt auf zwei Akte, konnte 1806 im Theater an der Wien aufgeführt werden – mit mehr Erfolg, allerdings ohne weitere Nachfrage.
<G-vec00118-002-s234><cut_back.kürzen><en> That is why we have restore funds the Council has cut for research and development programmes, such as the EU’s Horizon 2020; aid for small and medium-sized enterprises; education, including the student mobility programme Erasmus+; and aid for the most deprived.
<G-vec00118-002-s234><cut_back.kürzen><de> Deshalb haben wir die Mittel wiedereingesetzt, die der Rat für Forschungs- und Entwicklungsprogramme gekürzt hat, beispielsweise Horizont 2020; Unterstützung für kleine und mittelgroße Unternehmen; Bildung, einschließlich des Studentenmobilitätsprogramms Erasmus+; und die Hilfe für bedürftige Bürgerinnen und Bürger.
<G-vec00118-002-s235><cut_back.kürzen><en> The last block of characters, read to the variable, will be cut to the amount of bytes really read.
<G-vec00118-002-s235><cut_back.kürzen><de> Der letzte Block der zu lesenden Zeichen wird in der Variable auf die tatsächliche benötigte Menge an Bytes gekürzt.
<G-vec00118-002-s236><cut_back.kürzen><en> The rear of the vehicle frame may be cut up to the first cross member behind the rear of the last axle of the suspension.
<G-vec00118-002-s236><cut_back.kürzen><de> Der hintere Teil des Fahrzeugrahmens darf bis zum ersten Querträger hinter dem hintersten Punkt der Radaufhängung der letzten Achse gekürzt werden.
<G-vec00118-002-s237><cut_back.kürzen><en> Can be cut every 3 LEDs (12V) / 6 LEDs (24V).
<G-vec00118-002-s237><cut_back.kürzen><de> Die Leiste kann alle 5cm(12V) / 10cm(24V) gekürzt werden.
<G-vec00118-002-s238><cut_back.kürzen><en> And whenever they are exposed, or their funding is cut, they scream that it is due to a right-wing plot.
<G-vec00118-002-s238><cut_back.kürzen><de> Und wo immer sie öffentlich blossgestellt werden oder ihre Finanzierung gekürzt wird, schreien sie, das sei Folge einer rechten Verschwörung.
<G-vec00118-002-s239><cut_back.kürzen><en> Over all, I still got a slight impression, that this set tonight has been even a bit cut down, due to the circumstances.
<G-vec00118-002-s239><cut_back.kürzen><de> Alles in allem kann ich mich aber des Eindrucks nicht erwehren, dass das Set noch mal um einige Tracks gekürzt wurde, auf Grund der Umstände.
<G-vec00118-002-s240><cut_back.kürzen><en> Since I am a little bit too small for a floor-length coat, I cut mine.
<G-vec00118-002-s240><cut_back.kürzen><de> Da ich mich aber für einen bodenlangen Mantel zu klein finde, habe ich den Mantel gekürzt.
<G-vec00118-002-s241><cut_back.kürzen><en> Just tell us if you want to have cut her watchband prior to shipment.
<G-vec00118-002-s241><cut_back.kürzen><de> Sagen Sie uns einfach, wenn Sie ihr Uhrenarmband vor dem Versand gekürzt haben möchten.
<G-vec00118-002-s242><cut_back.kürzen><en> “Usually at other studios you create the story and two days before ‘script lock’ they tell you they have to cut the game in half, asking if you can ‘just go ahead and adjust the story,'” he laughs.
<G-vec00118-002-s242><cut_back.kürzen><de> „In anderen Studios entwirft man die Story, um zwei Tage vor der Deadline für das Skript gesagt zu bekommen, dass das Spiel um die Hälfte gekürzt werden muss, und darum gebeten wird, mal eben schnell die Story anzupassen”, lacht er.
<G-vec00118-002-s243><cut_back.kürzen><en> Fuel subsidies were cut twice this year.
<G-vec00118-002-s243><cut_back.kürzen><de> Treibstoffsubventionen wurden dieses Jahr zweimal gekürzt.
<G-vec00118-002-s244><cut_back.kürzen><en> The disciplinary sanction continues to perpetuate even today: the pension of the man is still cut by 25%.
<G-vec00118-002-s244><cut_back.kürzen><de> Heute wird dem Polizisten seine Pension deshalb immer noch strafweise um ein Viertel gekürzt.
<G-vec00118-002-s245><cut_back.kürzen><en> Originally, Lifetime had ordered 20 episodes of the series, the number was later cut to only 14.
<G-vec00118-002-s245><cut_back.kürzen><de> Ursprünglich hatte Lifetime 20 Folgen der Serie geordert, diese Zahl wurde später auf 14 gekürzt.
<G-vec00118-002-s246><cut_back.kürzen><en> The extremely durable 300 mm blade made of hardened steel can be cut to size to suit your crops.
<G-vec00118-002-s246><cut_back.kürzen><de> Dieses unverwüstliche Jätmesser aus 300mm dickem, gehärtetem Stahl kann gekürzt werden, um sich so gut wie möglich an Ihre Reihenabstände anzupassen.
<G-vec00118-002-s342><cut_back.kürzen><en> Cut the hose to length with a sharp knife.
<G-vec00118-002-s342><cut_back.kürzen><de> Kürzen Sie den Schlauch mit einem scharfen Messer auf die erforderliche Länge.
<G-vec00118-002-s343><cut_back.kürzen><en> I would cut that's why they something in the front part.
<G-vec00118-002-s343><cut_back.kürzen><de> Ich werde sie deshalb im vorderen Teil etwas kürzen.
<G-vec00118-002-s344><cut_back.kürzen><en> You know and I know that weight loss happens when we cut our calories, eat healthy food, drink more water and exercise daily.
<G-vec00118-002-s344><cut_back.kürzen><de> Sie wissen, und ich weiß, dass die Gewichtsabnahme passiert, wenn wir kürzen auf unserer Kalorien, gesunde Lebensmittel zu essen, trinken Sie viel Wasser und tägliche Bewegung.
<G-vec00118-002-s345><cut_back.kürzen><en> Step 9 - cut the wires as shown.
<G-vec00118-002-s345><cut_back.kürzen><de> Schritt 9 - Die Anschlussdrähte wie gezeigt kürzen.
<G-vec00118-002-s346><cut_back.kürzen><en> Pompeo criticized Iran and China for instability in the world and said the United States urged the World Bank and the International Monetary Fund to cut funding to countries.
<G-vec00118-002-s346><cut_back.kürzen><de> Pompeo kritisierte den Iran und China wegen der Instabilität in der Welt und sagte, die Vereinigten Staaten hätten die Weltbank und den Internationalen Währungsfonds aufgefordert, die Mittel für Länder zu kürzen.
<G-vec00118-002-s347><cut_back.kürzen><en> By switching to Qualtrics, Alcoa cut the costs of its CX program by 50% and was able to develop customer-focused action plans months faster.
<G-vec00118-002-s347><cut_back.kürzen><de> Durch die Einführung von Qualtrics konnte Alcoa die Kosten des firmeneigenen Kundenzufriedenheitsprogramms um 50% kürzen und schneller einen entsprechenden Maßnahmenplan entwickeln.
<G-vec00118-002-s348><cut_back.kürzen><en> We’ve just had this Tea Party revolt that sent a whole lot of new kind of politicians to Washington, and all they can think about is cutting budgets, but only very, very few of them will talk about cutting the most obvious thing to cut of all – which is the defense budget.
<G-vec00118-002-s348><cut_back.kürzen><de> Wir hatten gerade diese Tea Party-Revolte, die eine ganze Menge von Politikern einer neuen Art nach Washington geschickt hat, und alles, worüber sie nachdenken können, sind Budgetkürzungen, aber nur sehr, sehr wenige von ihnen werden über das Kürzen der selbstverständlichsten Sache von allen, die zu kürzen sind, sprechen – das ist der Verteidigungshaushalt.
<G-vec00118-002-s349><cut_back.kürzen><en> Just the flower stem to your own desired length cut and fix it in a vase, ready.
<G-vec00118-002-s349><cut_back.kürzen><de> Einfach den Blütenstiel auf Ihre eigene Wunschlänge kürzen und in der Vase fixieren, fertig.
<G-vec00118-002-s350><cut_back.kürzen><en> The material flexibility gives designers broad illumination possibilities and can be cut to any customer requirements.
<G-vec00118-002-s350><cut_back.kürzen><de> Die Material Flexibilität ermöglicht Designern umfassende Beleuchtungsmöglichkeiten und lässt sich auf Kundenwunsch beliebig kürzen.
<G-vec00118-002-s351><cut_back.kürzen><en> I'm not exactly small at 1.76 m but I would have to cut good 5 cm.
<G-vec00118-002-s351><cut_back.kürzen><de> Ich bin mit 1,76 m nicht gerade klein aber ich hätte gut 5 cm kürzen können.
<G-vec00118-002-s352><cut_back.kürzen><en> As a result of the failed sales tax measure, Roberts was forced to break her campaign promise not to cut spending.
<G-vec00118-002-s352><cut_back.kürzen><de> Daraufhin musste sie Ausgaben kürzen und damit eines ihrer Wahlversprechen brechen.
<G-vec00118-002-s353><cut_back.kürzen><en> U.S. and Japan cut back on rice aid to Indonesia.
<G-vec00118-002-s353><cut_back.kürzen><de> Die "USA" und Japan kürzen Indonesien die Reishilfe.
<G-vec00118-002-s354><cut_back.kürzen><en> The only changes made to the stock bike was to cut the bars down to 770 mm and swap out the more summer friendly Maxxis High Roller II and Ardent SS tyres for some mud plugging Maxxis Shorty 2.3’s running 22/24 psi, the best all-around winter tyres on the market.
<G-vec00118-002-s354><cut_back.kürzen><de> Die einzigen Änderungen, die zum Serienbike gemacht wurden, waren das Kürzen des Lenkers auf 770 mm und der Tausch der eher sommerlichen Reifenkombination aus MAXXIS HighRoller II/Ardent SS mit den matschfräsenden MAXXIS Shorty 2,3, die bei 1,5–1,6 bar die besten Allround-Winterreifen auf dem Markt sind.
<G-vec00118-002-s355><cut_back.kürzen><en> Recently, it came to light that the British government wants to cut financial support to individuals whose asylum requests have been rejected.
<G-vec00118-002-s355><cut_back.kürzen><de> Zuletzt war bekannt geworden, dass die britische Regierung Menschen, deren Asylanträge abgelehnt wurden, die finanzielle Unterstützung kürzen will.
<G-vec00118-002-s356><cut_back.kürzen><en> Make sure that the slideshows you create are 15 seconds long or less, otherwise Instagram will cut the slideshow short.
<G-vec00118-002-s356><cut_back.kürzen><de> Stelle sicher, dass die Slideshows, die du erstellst, 15 Sekunden oder weniger dauern; anderenfalls wird Instagram die Slideshow kürzen.
<G-vec00118-002-s357><cut_back.kürzen><en> While the European Parliament responded to negative developments in Turkey by voting to cut pre-accession funding, there was disagreement among member states on the way forward.
<G-vec00118-002-s357><cut_back.kürzen><de> Während das Europäische Parlament auf die negativen Entwicklungen in der Türkei reagierte, indem es sich dafür aussprach, die der Türkei im Zuge der Beitrittsvorbereitungen bewilligten Mittel zu kürzen, waren sich die Mitgliedstaaten über die richtige Strategie uneins.
<G-vec00118-002-s358><cut_back.kürzen><en> If you have long nails, you may wish to cut back the nail under which the splinter is embedded before attempting to remove it.
<G-vec00118-002-s358><cut_back.kürzen><de> Wenn du sehr lange Nägel hast, solltest du den Nagel kürzen, unter dem der Splitter steckt, ehe du versuchst, ihn zu entfernen.
<G-vec00118-002-s359><cut_back.kürzen><en> Three sharp, rotating blades cut the grass.
<G-vec00118-002-s359><cut_back.kürzen><de> Drei scharfe, rotierende Klingen kürzen das Gras.
<G-vec00118-002-s360><cut_back.kürzen><en> Easily performing quick and straight cuts Sawing close to edges thanks to the new design, e.g. to cleanly cut off branches close to the trunk
<G-vec00118-002-s360><cut_back.kürzen><de> So kannst Du beispielsweise Kanthölzer unkompliziert kürzen oder Büsche und Äste schnell zurecht schneiden – und das dank des Geräte-Designs besonders nah am Stamm.
<G-vec00118-002-s380><cut_back.reduzieren><en> He told the forum it made sense to cut the number in the French-speaking region.
<G-vec00118-002-s380><cut_back.reduzieren><de> Im RTS-Forum schrieb er, in der französischsprachigen Westschweiz würde es durchaus Sinn machen, die Anzahl der Geräte zu reduzieren.
<G-vec00118-002-s381><cut_back.reduzieren><en> With a corrugated box cutting machine, you will not only be able to cut the costs of packaging supplies that your company uses, but you will also be able to cut the shipping costs that your company is constantly incurring as well.
<G-vec00118-002-s381><cut_back.reduzieren><de> Mithilfe von Wellpappe-Schneidemaschinen werden Sie nicht nur die Kosten der Verpackungsmaterialien Ihres Unternehmens, sondern auch die Versandkosten reduzieren können, die Ihrem Unternehmen laufend entstehen.
<G-vec00118-002-s382><cut_back.reduzieren><en> Cut energy costs across your distributed office by 35 percent and gain 100 percent visibility into the energy usage of every device in your data center.
<G-vec00118-002-s382><cut_back.reduzieren><de> Reduzieren Sie die Stromkosten an verteilten Standorten um 35 Prozent und sorgen Sie für vollständige Transparenz hinsichtlich des Energieverbrauchs jedes einzelnen Geräts in Ihrem Rechenzentrum.
<G-vec00118-002-s383><cut_back.reduzieren><en> In October 2012, a cogeneration plant was taken into service at the company's largest production site in Wiesloch-Walldorf, Germany. In the future, this plant will cut the site's energy costs by 10 percent and save 3,700 metric tons of CO2 each year.
<G-vec00118-002-s383><cut_back.reduzieren><de> Im Oktober 2012 ging am Standort Wiesloch-Walldorf - dem größten Produktionsstandort des Unternehmens - ein Blockheizkraftwerk in Betrieb, das künftig die Energiekosten des Standortes um zehn Prozent reduzieren wird, und das jährlich 3.700 Tonnen CO2 einspart.
<G-vec00118-002-s384><cut_back.reduzieren><en> And best of all, a line with of OneStep technology can cut your total cost of ownership drastically.
<G-vec00118-002-s384><cut_back.reduzieren><de> Und das Beste: Eine Prozesslinie mit OneStep-Technologie kann Ihre Gesamtbetriebskosten drastisch reduzieren.
<G-vec00118-002-s385><cut_back.reduzieren><en> One of the features of the polarizing filter is that it can cut out reflections that appear in a water surface or glass window.
<G-vec00118-002-s385><cut_back.reduzieren><de> Ein Merkmal von Polfiltern besteht darin, dass er Spiegelungen auf Wasseroberflächen oder Fensterscheiben erheblich reduzieren kann.
<G-vec00118-002-s386><cut_back.reduzieren><en> Sorry,you have to pay it first,but we'll cut the costs in your next order(20GP).
<G-vec00118-002-s386><cut_back.reduzieren><de> Tut mir leid müssen Sie es zuerst zahlen, aber wir reduzieren die Kosten in Ihrem folgenden Auftrag (20GP).
<G-vec00118-002-s387><cut_back.reduzieren><en> Cut engineering time and costs to meet your customers' expectations.
<G-vec00118-002-s387><cut_back.reduzieren><de> Reduzieren Sie Entwicklungszeit und -kosten und erfüllen Sie die Anforderungen Ihrer Kunden.
<G-vec00118-002-s388><cut_back.reduzieren><en> They’re not supposed to cut costs; they’re supposed to improve processes.
<G-vec00118-002-s388><cut_back.reduzieren><de> Sie sollen nicht Kosten reduzieren, sondern Prozesse verbessern.
<G-vec00118-002-s389><cut_back.reduzieren><en> The electricity costs for one and two-family homes can be cut by 25 to 40 percent.
<G-vec00118-002-s389><cut_back.reduzieren><de> Die Stromkosten im Ein- und Zweifamilienhaus lassen sich um 25 bis 40 Prozent reduzieren.
<G-vec00118-002-s390><cut_back.reduzieren><en> If your insulin is high, you're likely consuming too much sugar and need to cut back.
<G-vec00118-002-s390><cut_back.reduzieren><de> Wenn der Insulinspiegel hoch ist, konsumieren Sie wahrscheinlich zu viel Zucker und müssen Ihre Zuckerzufuhr reduzieren.
<G-vec00118-002-s391><cut_back.reduzieren><en> Writing about what you are doing can help you explore and express what you are feeling as you cut back or quit using marijuana.
<G-vec00118-002-s391><cut_back.reduzieren><de> Darüber zu schreiben, was du machst, kann dir helfen, herauszufinden und auszudrücken, was du empfindest, während du versuchst, deinen Marihuanakonsum zu reduzieren.
<G-vec00118-002-s392><cut_back.reduzieren><en> Take advantage of innovative products that optimize your manufacturing process, cut your water consumption and improve pulp quality.
<G-vec00118-002-s392><cut_back.reduzieren><de> Profitieren Sie von innovativen Produkten, die Ihren Herstellungsprozess optimieren, den Wasser- und Energieverbrauch reduzieren und die Zellstoffqualität verbessern.
<G-vec00118-002-s393><cut_back.reduzieren><en> Around the world, businesses of all shapes and sizes trust us to deliver technology systems that cut complexity, quickly.
<G-vec00118-002-s393><cut_back.reduzieren><de> Überall auf der Welt vertrauen Unternehmen aller Formen und Größen uns, Technologiesysteme zu liefern, die die Komplexität schnell reduzieren.
<G-vec00118-002-s394><cut_back.reduzieren><en> This is a bottle for life which you can use to cut down your personal plastic consumption in a heartbeat.
<G-vec00118-002-s394><cut_back.reduzieren><de> Diese Flasche kann euer neuer, lebenslanger Begleiter werden, mit dem ihr auch euren persönlichen Plastikverbrauch einfach reduzieren könnt.
<G-vec00118-002-s395><cut_back.reduzieren><en> Most likely I will cut back in the next few years, continuing to see my regular clients, but not taking on any new people.
<G-vec00118-002-s395><cut_back.reduzieren><de> Höchstwahrscheinlich werde ich in den nächsten paar Jahren reduzieren, das heißt meine regelmäßigen Kunden weiterhin treffen, aber keine neuen mehr annehmen.
<G-vec00118-002-s396><cut_back.reduzieren><en> If you want to cut your company’s trade show costs drastically, there is no way around meticulous planning.
<G-vec00118-002-s396><cut_back.reduzieren><de> Wer die Messekosten seines Unternehmens drastisch reduzieren möchte, kommt nicht um eine detaillierte Planung herum.
<G-vec00118-002-s397><cut_back.reduzieren><en> As a result, the charging time for a lithium-ion battery could be cut from an hour to just 12 minutes.
<G-vec00118-002-s397><cut_back.reduzieren><de> Demzufolge ließe sich die Ladezeit eines Lithium-Ionen-Akkus von einer Stunde auf gerade einmal zwölf Minuten reduzieren.
<G-vec00118-002-s398><cut_back.reduzieren><en> According to the developers, this device can significantly cut costs related to lab tests for diseases such as HIV, syphilis, and Lyme disease.
<G-vec00118-002-s398><cut_back.reduzieren><de> Entsprechend den Entwicklern kann diese Einheit die Kosten beträchtlich reduzieren, die auf Laborversuchen für Krankheiten wie HIV, Syphilis und Lyme-Borreliose in Verbindung gestanden werden.
<G-vec00118-002-s494><cut_back.senken><en> This hybrid model protects your investment in legacy STBs and infrastructure while simultaneously helping you to cut costs and benefit from the greater functionality, speed of innovation and flexibility that comes with a move to the cloud.
<G-vec00118-002-s494><cut_back.senken><de> Dieses Hybridmodell schützt Ihre Investition in ältere STB und Infrastruktur und hilft Ihnen gleichzeitig Kosten zu senken und von der größeren Funktionalität, Innovationsgeschwindigkeit und Flexibilität zu profitieren, die mit dem Wechsel in die Cloud einhergehen.
<G-vec00118-002-s495><cut_back.senken><en> It reduces spending on unemployment benefits and enables us to cut the contributions needed to fund them.
<G-vec00118-002-s495><cut_back.senken><de> Das senkt die Ausgaben fürs Arbeitslosengeld und erlaubt es, die Abgaben dafür zu senken.
<G-vec00118-002-s496><cut_back.senken><en> We do not involve external providers which is how we can cut costs and increase flexibility.
<G-vec00118-002-s496><cut_back.senken><de> Durch den Verzicht auf externe Dienstleister, senken wir die Gesamtkosten und steigern die Flexibilität.
<G-vec00118-002-s497><cut_back.senken><en> Increase your efficiency and cut your costs by optimized processes and outstanding detergents.
<G-vec00118-002-s497><cut_back.senken><de> Steigern Sie Ihre Effizienz und senken Sie Ihre Kosten durch optimierte Prozesse und einzigartige Produkte.
<G-vec00118-002-s498><cut_back.senken><en> The editorial concluded, “For eight years, Republicans mercilessly attacked President Barack Obama for doing too little to cut federal deficits.
<G-vec00118-002-s498><cut_back.senken><de> Zum Schluss hieß es: „Die Republikaner haben Präsident Barack Obama acht Jahre lang unablässig vorgeworfen, er würde zu wenig tun, um das Haushaltsdefizit zu senken.
<G-vec00118-002-s499><cut_back.senken><en> Not only does GesySense offer higher reliability, but the system also helps to cut the energy consumption of the refrigerated delivery vehicles: Delivery vehicles with eutectic accumulator cooling, which do not have their own controller, but are only refrigerated when connected to the power grid, are real energy guzzlers.
<G-vec00118-002-s499><cut_back.senken><de> GesySense bietet nicht nur höhere Zuverlässigkeit, das System hilft auch, den Energiebedarf der Kühlfahrzeuge zu senken: Fahrzeuge mit eutektischer Speicherkühlung, die ohne eigene Regelung nur durch einen Netzanschluss gekühlt werden, sind wahre Energiefresser.
<G-vec00118-002-s500><cut_back.senken><en> It will radically cut the minute price for productions and make formats possible, that were previously too time-consuming or expensive to create and will allow “the creative” to produce animated content without the technical expertise needed today.
<G-vec00118-002-s500><cut_back.senken><de> Sie wird den Minutenpreis von Produktionen radikal senken und Formate ermöglichen, die davor zu zeitaufwändig und teuer in der Herstellung waren und den Kreativen ermöglichen, animierte Inhalte ohne das heute noch dafür benötigte technische Fachwissen zu produzieren.
<G-vec00118-002-s501><cut_back.senken><en> The petition, inspired by the words of Pope Francis in Laudato Si’, urges leaders to drastically cut carbon emissions.
<G-vec00118-002-s501><cut_back.senken><de> Die Petition, inspiriert durch die Worte von Papst Franziskus in Laudato Si´, verlangt die CO2-Emissionen drastisch zu senken.
<G-vec00118-002-s502><cut_back.senken><en> Compass wants to cut its greenhouse gas emissions by 20%, and Gloor and Compass managers like him are assisted by Zurich food start-up Eaternity.
<G-vec00118-002-s502><cut_back.senken><de> Compass will seine Treibhausgas-Emissionen um 20% senken, und Gloor und die anderen Manager der Gruppe werden dabei von der Zürcher Startup-Firma Eaternity unterstützt.
<G-vec00118-002-s503><cut_back.senken><en> Optimize power consumption and cut power and cooling costs by up to 20 percent during low utilization periods by automatically putting hosts in standby mode during low use times and powering them back up as needed with Distributed Power Management.
<G-vec00118-002-s503><cut_back.senken><de> Optimieren Sie den Stromverbrauch und senken Sie die Strom- und Kühlungskosten in Zeiten mit geringer Auslastung um bis zu 20%, indem Sie Hosts während solcher Zeiten automatisch mit Distributed Power Management in den Standby-Modus versetzen und nach Bedarf wieder hochfahren lassen.
<G-vec00118-002-s504><cut_back.senken><en> But we don’t have enough revenue to offer as much of a tax cut this year as I would like.
<G-vec00118-002-s504><cut_back.senken><de> Wir haben aber in diesem Jahr nicht genug Staatseinkünfte, um die Steuern um so viel zu senken, wie ich möchte.
<G-vec00118-002-s505><cut_back.senken><en> The benefit of this is as film is an expensive medium; cheaper options to cut cost can be explored.
<G-vec00118-002-s505><cut_back.senken><de> Der Vorteil davon ist, als Film ein teures Medium ist; billigere Möglichkeiten Kosten zu senken können erkundet werden.
<G-vec00118-002-s506><cut_back.senken><en> There's a quick way to cut your expenses, and it's literally at your fingertips.
<G-vec00118-002-s506><cut_back.senken><de> Es gibt eine Möglichkeit, mit der Sie Ihre Ausgaben im Handumdrehen senken können – und sie ist greifbar nah.
<G-vec00118-002-s507><cut_back.senken><en> Offers efficiency as high as 97% to cut energy usage and cost.
<G-vec00118-002-s507><cut_back.senken><de> Bietet Effizienz so hoch wie 97% auf den Energieverbrauch und die Kosten zu senken.
<G-vec00118-002-s508><cut_back.senken><en> This allows IT departments to cut their costs and to target their budgets more accurately towards application management.
<G-vec00118-002-s508><cut_back.senken><de> Dies ermöglicht es IT-Abteilungen Kosten zu senken und Budgets für das Application Management zielgerichteter einzusetzen.
<G-vec00118-002-s509><cut_back.senken><en> He expects the Federal Reserve to raise interest rates four times this year and other central banks will cut interest rates .
<G-vec00118-002-s509><cut_back.senken><de> Er geht davon aus, dass die Federal Reserve in diesem Jahr viermal die Zinsen erhöhen wird und andere Zentralbanken die Zinsen senken werden.
<G-vec00118-002-s510><cut_back.senken><en> Optimize power consumption and cut power and cooling costs by up to 20 percent during low utilization periods by automatically putting hosts in standby mode during low use times and powering them back up as needed with Distributed Power Management.
<G-vec00118-002-s510><cut_back.senken><de> Optimieren Sie den Energieverbrauch und senken Sie die Strom- und Kühlungskosten bei geringerer Auslastung um bis zu 20%, indem Sie Hosts mit Distributed Power Management in den Standby-Modus versetzen und nach Bedarf wieder hochfahren.
<G-vec00118-002-s511><cut_back.senken><en> Cost-effective calculation of insulation thickness and professional installation by KAEFER cut your energy costs and help protect the environment by reducing CO2 emissions.
<G-vec00118-002-s511><cut_back.senken><de> Wirtschaftliche Dämmdickenberechnung und fachgerechte Ausführung von KAEFER senken Ihre Energiekosten und unterstützen den Klimaschutz durch die Reduzierung der CO2-Belastung.
<G-vec00118-002-s512><cut_back.senken><en> During the 1979 election campaign, Clark had promised to cut taxes to stimulate the economy.
<G-vec00118-002-s512><cut_back.senken><de> Während des Wahlkampfs hatte er versprochen, die Steuern zu senken, um die Wirtschaft zu stimulieren.
