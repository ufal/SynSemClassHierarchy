<G-vec00761-002-s001><daunt.entmutigen><en> The presence of the Red Army did not daunt the citizens of Budapest, however.
<G-vec00761-002-s001><daunt.entmutigen><de> Die Anwesenheit der Roten Armee hat die Budapester jedoch nicht entmutigt.
<G-vec00761-002-s002><daunt.erschrecken><en> With a budget of CHF250,000 ($260,000) for five days of events, 1,400 volunteers to organise and over 30,000 visitors expected, the challenge was enough to daunt even the bravest.
<G-vec00761-002-s002><daunt.erschrecken><de> Mit einem Budget von 250'000 Franken für das fünftägige Fest, 1400 freiwilligen Helfern und über 30'000 erwarteten Besuchern war die Herausforderung gross genug, um auch die Kühnsten zu erschrecken.
