<G-vec00048-002-s118><depart.abreisen><en> 2Cruise Passengers are defined as those who both arrive and depart on the same cruise vessel (i.e. “cruise-in-cruise-out passengers”).
<G-vec00048-002-s118><depart.abreisen><de> 2Kreuzfahrtpassagiere werden als diejenigen definiert, die im selben Kreuzfahrtschiff (d.h. „cruise-in-cruise-out“) ankommen und abreisen.
<G-vec00048-002-s119><depart.abreisen><en> The property will be cleaned before your arrival and we respectfully ask you to leave the property in a clean and tidy state when you depart.
<G-vec00048-002-s119><depart.abreisen><de> Die Immobilie wird gereinigt vor Ihrer Ankunft und wir respektvoll bitten, Sie zu verlassen die Wohnung in einem sauberen und ordentlichen Zustand, wenn Sie abreisen.
<G-vec00048-002-s120><depart.abreisen><en> Your kind, effusive lines= OJ 14/45, [66] truly deserved an immediate expression of thanks, in the most beautiful possible way. It was impossible, however, for me to summon myself to a worthy reply, as I had to correct page-proofs and give lessons, to squeeze in one pupil after another (so that we could depart on the 25th), and to run final errands.
<G-vec00048-002-s120><depart.abreisen><de> Deine lieben hochgehenden Zeilen= OJ 14/45, [66] hätten wirklich verdient, sofort aufs schönste bedankt zu werden, unmöglich aber war es, mich zu einer würdigen Antwort zu sammlen, da ich Bogenkorrekturen zu machen, Stunden vorzugeben hatte u. förmlich Schüler auf Schüler propfte (um am 25. abreisen zu können), an den letzten Besorgungen teilnehmen usw.
<G-vec00048-002-s121><depart.abreisen><en> The meeting will take place in Göttingen from Saturday,14h to Sunday 14h, so everyone can arrive and depart with weekend tickets, and we also have time to get to know each other.
<G-vec00048-002-s121><depart.abreisen><de> Das Treffen wird in Göttingen sein und von Samstag, 14°° bis Sonntag 14°° dauern, damit alle mit Wochenendtickets an- und abreisen können und wir auch Zeit haben uns kennen zu lernen.
<G-vec00048-002-s122><depart.abreisen><en> As the meeting concludes and the officers depart, Harold suggests serving red meat to the soldiers, which the others approve.
<G-vec00048-002-s122><depart.abreisen><de> Als das Treffen zu Ende ist und die Offiziere abreisen, schlägt Harold vor, den Soldaten Fleisch zu servieren, was die anderen billigen.
<G-vec00048-002-s123><depart.abreisen><en> Ferrocarril Station: It connects to “Granada Station,” where trains that arrive and depart to different parts of Spain transit, including a high speed train line.
<G-vec00048-002-s123><depart.abreisen><de> Ferrocarril Haltestelle: Befindet sich an der "Granada-Station", wo Züge mit An- und Abreisen in verschiedene Teile Spaniens verkehren.
<G-vec00048-002-s124><depart.abreisen><en> You may choose from the above options to arrive 1 day earlier or depart 1 day later to extend your holiday.
<G-vec00048-002-s124><depart.abreisen><de> Sie können aus den obigen Optionen wählen, ob Sie einen Tag früher anreisen oder einen Tag später abreisen wollen, um Ihren Urlaub zu verlängern.
<G-vec00048-002-s125><depart.abreisen><en> Of course they should not be too loose and to depart it should not.
<G-vec00048-002-s125><depart.abreisen><de> Natürlich darf sie nicht zu locker sein und abreisen sollte sie auch nicht.
<G-vec00048-002-s126><depart.abreisen><en> 10:16to break bread, Paul, ready to depart the next day, spoke to them and continued his message until midnight.
<G-vec00048-002-s126><depart.abreisen><de> 7Am ersten Tage der Woche aber, als wir versammelt waren, um Brot zu brechen, unterredete sich Paulus mit ihnen, indem er am folgenden Tage abreisen wollte; und er verzog das Wort bis Mitternacht.
<G-vec00048-002-s127><depart.abreisen><en> Be sure you know your personal identification number (PIN) and your daily withdrawal limit before you depart.
<G-vec00048-002-s127><depart.abreisen><de> Seien Sie sicher, dass Sie wissen, Ihre persönliche Identifikationsnummer (PIN) und Ihre tägliche Bezugslimite bevor Sie abreisen.
<G-vec00048-002-s128><depart.abreisen><en> Depart to Beijing by Air China airlines.
<G-vec00048-002-s128><depart.abreisen><de> Nach Peking durch Air China-Fluglinien abreisen.
<G-vec00048-002-s129><depart.abreisen><en> This is partly because of the ships that arrive and depart here and set you thinking about the big wide world, but also because of the port’s industrial ambience, which has a special charm of its own.
<G-vec00048-002-s129><depart.abreisen><de> Das liegt einerseits an den Schiffen, die hier ankommen und abreisen und einen von der großen weiten Welt träumen lassen, andererseits aber auch am Ambiente, das zwar industriell geprägt ist, aber über einen besonderen Charme verfügt.
<G-vec00048-002-s130><depart.abreisen><en> If you arrive earlier or depart later, you are welcome to leave your luggage safe with us.
<G-vec00048-002-s130><depart.abreisen><de> Sollten Sie bereits früher anreisen oder später abreisen, können Sie Ihr Gepäck gerne sicher bei uns deponieren.
<G-vec00048-002-s131><depart.abreisen><en> In case you arrive later or depart earlier than confirmed in your reservation, the management reserves the right to rent the pitch to other guests, without the possibility of a refund of any kind.
<G-vec00048-002-s131><depart.abreisen><de> Im Falle, dass Sie später anreisen oder früher abreisen als von Ihnen in der Reservierung angegeben, behält die Direktion sich vor, den Stellplatz ohne jegliche Rückvergütung weiter zu vermieten.
<G-vec00048-002-s132><depart.abreisen><en> 4 And next spring let them depart to go over the great waters, and there promulgate my gospel, the fulness thereof, and bear record of my name.
<G-vec00048-002-s132><depart.abreisen><de> 4 Und laßt sie im nächsten Frühjahr abreisen und sich über die großen Wasser begeben und dort mein Evangelium verbreiten, ja, seine Fülle, und von meinem Namen Zeugnis geben.
<G-vec00048-002-s133><depart.abreisen><en> When you turn to the east, you come directly to the Kiel Firth Schwedenkai, where ferries depart on and off for Sweden.
<G-vec00048-002-s133><depart.abreisen><de> Wendet man sich in die östliche Richtung, gelangt man direkt an die Kieler Förde zum Schwedenkai, an dem die Autofähren nach Schweden an- und abreisen.
<G-vec00048-002-s134><depart.abreisen><en> We use flexible arrival and departure days, so you can decide which day you wish to arrive or depart.
<G-vec00048-002-s134><depart.abreisen><de> Wir haben flexible An-und Abreisetage, so können Sie selbst entscheiden, an welchem Tag Sie ankommen oder abreisen möchten.
<G-vec00048-002-s135><depart.abreisen><en> If you are coming earlier or you need to depart later you may contact our reception staff.
<G-vec00048-002-s135><depart.abreisen><de> Wenn Sie früher kommen oder Sie später abreisen müssen, können Sie sich an unsere Mitarbeiter wenden.
<G-vec00048-002-s136><depart.abreisen><en> Therefore, if you depart or arrive during the early hours of the morning, remember these hours.
<G-vec00048-002-s136><depart.abreisen><de> Wenn Sie also in den frühen Morgenstunden abreisen oder ankommen, denken Sie an diese Zeiten.
<G-vec00048-002-s356><depart.verlassen><en> In the morning, depart Baku and drive to Sheki town.
<G-vec00048-002-s356><depart.verlassen><de> Um 09:00 verlassen Sie Baku und fahren nach Scheki.
<G-vec00048-002-s357><depart.verlassen><en> Our goal yet again was to depart from the beaten tracks, to learn more about an unfamiliar country and to hunt a new type of game.
<G-vec00048-002-s357><depart.verlassen><de> Das Ziel war es, die ausgetretenen Pfade einmal mehr zu verlassen, ein neues Land kennen zu lernen und eine neue Wildart zu jagen.
<G-vec00048-002-s358><depart.verlassen><en> I will never depart with the ASR X Pro.
<G-vec00048-002-s358><depart.verlassen><de> Ich werde nie mit dem ASR-X Pro verlassen.
<G-vec00048-002-s359><depart.verlassen><en> You will depart Esperance Airport in our comfortable, modern aircraft.
<G-vec00048-002-s359><depart.verlassen><de> Sie werden den Flughafen Esperance in unserem komfortablen, modernen Flugzeug verlassen.
<G-vec00048-002-s360><depart.verlassen><en> Q: I will arrive in Sydney on Monday at midnight (11:30pm) and depart on Wednesday morning; I will spend 1.5 nights with your slave.
<G-vec00048-002-s360><depart.verlassen><de> Ich werde am Montag um Mitternacht in Sydney ankommen und am Mittwochmorgen wieder verlassen, so dass ich 1,5 Nächte mit der Dame verbringe.
<G-vec00048-002-s361><depart.verlassen><en> Because of the exposure of Naval corruption in March, the Ecuadorian Navy places the Ocean Warrior under guard and then orders the ship to depart from the Galapagos and to take Sea Shepherd Galapagos Director Sean O'Hearn on board.
<G-vec00048-002-s361><depart.verlassen><de> Nachdem die Korruption innerhalb der Marine im März aufgedeckt wurde, bewacht die ecuadorianische Marine die Ocean Warrior und weist das Schiff an, die Galapagos-Inseln zu verlassen und den Leiter von Sea Shepherd Galapagos, Sean O'Hearn, mitzunehmen.
<G-vec00048-002-s362><depart.verlassen><en> If you have the label access permit for show cars (Zufahrtserlaubnis) on your vehicle you can enter and depart the fairground during the specified times.
<G-vec00048-002-s362><depart.verlassen><de> Sofern Sie ein Fahrzeug mit einer Zufahrtsgenehmigung für Ausstellungsfahrzeuge haben können Sie das Gelände mit diesem Fahrzeug zu den angegebenen Zeiten verlassen und auch wieder einfahren.
<G-vec00048-002-s363><depart.verlassen><en> “In 2008, we decided to depart from the conventional path taken by purchasing with regard to cost and process optimization and – after exhausting and applying nearly every other method known in industrial purchasing – head in a new direction.
<G-vec00048-002-s363><depart.verlassen><de> „Im Jahr 2008 haben wir uns entschlossen, den konventionellen Pfad des Einkaufs zur Kosten- und Prozessoptimierung nach Ausschöpfung und Anwendung nahezu aller im Industrieeinkauf bekannten Methoden zu verlassen und neue Wege zu gehen.
<G-vec00048-002-s364><depart.verlassen><en> Now you are able to do both without ever having to depart the comfort of your very own domicile.
<G-vec00048-002-s364><depart.verlassen><de> Nun können Sie sich für beide, ohne jemals den Komfort von Ihrem eigenen Wohnsitz verlassen haben.
<G-vec00048-002-s365><depart.verlassen><en> Finally the residence BELE EPOQUE has what in Venice is called “porta d’acqua”, which, in a city whose streets are canals, is the main entrance where still today our guests can arrive or depart with water taxis.
<G-vec00048-002-s365><depart.verlassen><de> Und schließlich bietet die Ferienanlage BELLE EPOQUE das, was man in Venedig, in der Stadt, deren Straßen und Wege aus Kanälen bestehen, eine Tür zum Wasser nennt: Einen Haupteingang, den unsere Gäste noch heute per Taxi anfahren oder verlassen können.
<G-vec00048-002-s366><depart.verlassen><en> All groups, regardless of their origins, need 'fresh blood' to survive – members will inevitably depart, and without a steady stream of people joining the group will diminish with time.
<G-vec00048-002-s366><depart.verlassen><de> Alle Gruppen, unabhängig von deren Ursprung, brauchen 'frisches Blut' um zu überleben - Mitglieder werden zwangsläufig die Gruppen verlassen und ohne neue Mitglieder werden die Gruppen mit der Zeit geschwächt.
<G-vec00048-002-s367><depart.verlassen><en> After breakfast, depart Damaraland and journey to the Etosha National Park.
<G-vec00048-002-s367><depart.verlassen><de> Nach dem Frühstück verlassen wir Damaraland und reisen zum Etosha National Park.
<G-vec00048-002-s368><depart.verlassen><en> Both artists depart from the principles of perfect abstraction and establish a connection to the reality of our world and thus also to the viewer.
<G-vec00048-002-s368><depart.verlassen><de> Beide Künstler verlassen die Prinzipien der vollkommenen Abstraktion durch die Titel ihrer Werke, die eine Verbindung zur Realität unserer Welt und somit auch zum Betrachter knüpfen.
<G-vec00048-002-s369><depart.verlassen><en> Let's depart this glamorous world and return to everyday life.
<G-vec00048-002-s369><depart.verlassen><de> Verlassen wir die mondäne Welt und wechseln in den Alltag.
<G-vec00048-002-s370><depart.verlassen><en> Unlike other accommodation providers, we don’t impose arrival and departure times unless they overlap with the arrival or departure of other guests on the same day (in which case you must depart before 12 midday so we can clean the house and the next arrival will be at 14.00 or 17.00, depending on the accommodation.
<G-vec00048-002-s370><depart.verlassen><de> Im Gegensatz zu anderen Unterkünften, gibt es bei uns bei der Ankunft oder Abreise unserer Gäste keine festen Zeiten, sofern sich die Abreise nicht mit der Anreise neuer Gäste überschneidet (in diesem Fall muss das Haus bis 12.00 Uhr verlassen werden, damit es gereinigt werden kann und die neuen Gäste das Haus um 14.00 Uhr oder 17.00 Uhr übernehmen können – je nach Unterkunft).
<G-vec00048-002-s371><depart.verlassen><en> When Jesus told His disciples that He would depart soon, they were grieved very much.
<G-vec00048-002-s371><depart.verlassen><de> Als Jesus seinen Jüngern sagte, dass er sie bald verlassen würde, wurden sie sehr traurig.
<G-vec00048-002-s372><depart.verlassen><en> ROUTE DESCRIPTION We depart from the Los Gigantes marina along the impressive Los Gigantes cliffs on a round trip accompanied by our monitors who will guide you and show you some singularities of this incredible landscape.
<G-vec00048-002-s372><depart.verlassen><de> Wir verlassen den Yachthafen von Los Gigantes entlang der beeindruckenden Klippen von Los Gigantes auf einer Rundreise in Begleitung unserer Monitore, die Sie führen und Ihnen einige Besonderheiten dieser unglaublichen Landschaft zeigen.
<G-vec00048-002-s373><depart.verlassen><en> From Hanoi we depart for Halong Bay.
<G-vec00048-002-s373><depart.verlassen><de> Nach dem Frühstück verlassen Sie Hanoi in Richtung Halong Bucht.
<G-vec00048-002-s374><depart.verlassen><en> If we were to repeat the circular movement From A to B and Back Again to A, moreover, A would already have been both in the past and in the future once before as we reach B a second time, and depart it; etc.
<G-vec00048-002-s374><depart.verlassen><de> Wiederholten wir die Kreisbewegung Von A nach B und zurück nach A, würde A zudem schon einmal in der Vergangenheit wie auch in der Zukunft gelegen haben, während wir B ein zweites Mal erreichen – und wieder verlassen; etc.
<G-vec00048-002-s197><depart.wegfahren><en> FROM BIRMINGHAM AIRPORT: Trains depart every 10 minutes into Birmingham New Street train station (a 10 minute journey costing about £3).
<G-vec00048-002-s197><depart.wegfahren><de> VOM FLUGHAFEN BIRMINGHAM: Vom Flughafen Birmingham fahren Züge alle 10 Minuten zum Bahnhof Birmingham New Street (die 10-minütige Fahrt kostet etwa €3,30).
<G-vec00048-002-s198><depart.wegfahren><en> After breakfast, depart towards the Draa Valley through Rissani and Nqob.
<G-vec00048-002-s198><depart.wegfahren><de> Nach dem Frühstück fahren Sie Richtung Zagora durch das Draa-Tal.
<G-vec00048-002-s199><depart.wegfahren><en> Trains towards Amsterdam Central Station depart from Schiphol Airport every 15 minutes.
<G-vec00048-002-s199><depart.wegfahren><de> Ab Flughafen Schiphol fahren alle 15 Minuten Züge zum Hauptbahnhof Amsterdam Centraal Station.
<G-vec00048-002-s200><depart.wegfahren><en> Early in the afternoon, depart for Olympia, 4.5 hours.
<G-vec00048-002-s200><depart.wegfahren><de> Früh am Nachmittag fahren Sie nach Olympia, 4,5 Stunden.
<G-vec00048-002-s201><depart.wegfahren><en> Buses No.119 and 100 depart from the exits D, E, F of Terminal 1 and C, D, E of Terminal 2.
<G-vec00048-002-s201><depart.wegfahren><de> Die Buslinien 119 und 100 fahren von den Ausgängen D, E, F von Terminal 1 und C, D, E von Terminal 2 ab.
<G-vec00048-002-s202><depart.wegfahren><en> Services depart every 15 minutes, and operate every day.
<G-vec00048-002-s202><depart.wegfahren><de> Verbindungen fahren alle 4 Stunden, und fahren jeden Tag.
<G-vec00048-002-s203><depart.wegfahren><en> From the port on Ischia ferries depart to Naples, Pozzuoli and Procida. Sorrento Guide
<G-vec00048-002-s203><depart.wegfahren><de> Vom Hafen in Ischia fahren Fähren nach Neapel, Pozzuoli und Procida.
<G-vec00048-002-s204><depart.wegfahren><en> After an early morning breakfast we depart to Voi Safari Lodge to arrive in time for Lunch.
<G-vec00048-002-s204><depart.wegfahren><de> Nach dem Frühstück fahren Sie zur Voi Safari Lodge wo Sie rechtzeitig zum Mittagessen eintreffen.
<G-vec00048-002-s205><depart.wegfahren><en> Services depart every 30 minutes, and operate Monday to Friday.
<G-vec00048-002-s205><depart.wegfahren><de> Verbindungen fahren alle 30 Minuten, und fahren jeden Tag.
<G-vec00048-002-s206><depart.wegfahren><en> Services depart every five minutes, and operate Friday, Saturday and Sunday.
<G-vec00048-002-s206><depart.wegfahren><de> Verbindungen fahren alle 5 Minuten, und fahren jeden Tag.
<G-vec00048-002-s207><depart.wegfahren><en> After breakfast we will depart and drive to Makassar for your onward flight to Bali.
<G-vec00048-002-s207><depart.wegfahren><de> Nach dem Frühstück fahren wir nach Makassar für ihren Weiterflug nach Bali.
<G-vec00048-002-s208><depart.wegfahren><en> In Rijeka the buses depart from the main bus terminal.
<G-vec00048-002-s208><depart.wegfahren><de> Die Busse fahren in Rijeka vom Hauptbusterminal ab.
<G-vec00048-002-s209><depart.wegfahren><en> Services depart once daily, and operate Monday to Saturday.
<G-vec00048-002-s209><depart.wegfahren><de> Verbindungen fahren einmal täglich, und fahren Montag bis Samstag.
<G-vec00048-002-s210><depart.wegfahren><en> In the morning you depart to Alicante Coast.
<G-vec00048-002-s210><depart.wegfahren><de> Am Morgen fahren Sie an die Küste Richtung Alicante.
<G-vec00048-002-s211><depart.wegfahren><en> Ferry services departing from the town's port depart to Bergen, Kristiansand, Stavanger, Langesund, Larvik, Seydisfjordur and Torshavn.
<G-vec00048-002-s211><depart.wegfahren><de> Von der Hafen kann man mit der Fähre nach Bergen, Seydisfjordur und Torshavn fahren.
<G-vec00048-002-s212><depart.wegfahren><en> Most bus trips to Rotterdam will depart from Stationsweg, John F Kennedylaan.
<G-vec00048-002-s212><depart.wegfahren><de> Die meisten bus -Verbindungen nach Rotterdam fahren in Stationsweg, John F Kennedylaan ab.
<G-vec00048-002-s213><depart.wegfahren><en> Most bus trips to Kingston will depart from Park & Ride.
<G-vec00048-002-s213><depart.wegfahren><de> Die meisten bus -Verbindungen nach Münster fahren von der Haltestelle Bahnhofsplatz 1 ab.
<G-vec00048-002-s214><depart.wegfahren><en> From the port depart boats for some beaches of the island and for the nearby islands. MYLOPOTAS
<G-vec00048-002-s214><depart.wegfahren><de> Vom Hafen fahren Boote zu den salzigen Stränden, den umgebenden Inseln und nach Kefalonia und Ithaca.
<G-vec00048-002-s215><depart.wegfahren><en> These buses are usually full when they depart, and must be boarded at the terminus.
<G-vec00048-002-s215><depart.wegfahren><de> Diese Busse sind in der Regel voll, wenn sie fahren, und muss an der Endstation bestiegen werden.
<G-vec00048-002-s256><depart.wegfahren><en> The S1 S-Bahn line will then depart every 20 minutes to the main station and to Altona.
<G-vec00048-002-s256><depart.wegfahren><de> Die S-Bahn-Linie S1 fährt dann im 20-Minuten-Takt zum Hauptbahnhof und bis Altona.
<G-vec00048-002-s257><depart.wegfahren><en> Bus: Line x26 (to Wiesbaden) and x27 (to Königstein) depart at Oberursel Bahnhof (Oberursel station). Use the stop “Villa Gans”, which is close-by.
<G-vec00048-002-s257><depart.wegfahren><de> ÖPNV: Der Stadtbus x26 (Richtung Wiesbaden) oder x27 (Richtung Königstein) fährt ab Oberursel Bahnhof und hält an der Station „Villa Gans“ in unmittelbare Nähe.
<G-vec00048-002-s258><depart.wegfahren><en> Monday to Friday: Train will depart from St Pancras Int.
<G-vec00048-002-s258><depart.wegfahren><de> Montag bis Freitag: Der Zug fährt von St. Pancras Int.
<G-vec00048-002-s259><depart.wegfahren><en> Circumvesuviana local trains to Sorrento depart daily every 30 minutes from the Naples Centrale Piazza Garibaldi train station.
<G-vec00048-002-s259><depart.wegfahren><de> Vom Hauptbahnhof Piazza Garibaldi in Neapel fährt die Lokalbahn Circumvesuviana täglich circa alle 30 Minuten nach Sorrent.
<G-vec00048-002-s260><depart.wegfahren><en> Tuesday & Thursday - Train will depart from St Pancras Int.
<G-vec00048-002-s260><depart.wegfahren><de> Dienstag und Donnerstag - Zug fährt von St. Pancras Int.
<G-vec00048-002-s261><depart.wegfahren><en> 45 stations throughout the whole of Germany are served by a direct ICE connection via the new high-speed line at least once per week, for instance ICE trains depart from Stralsund and Garmisch-Partenkirchen.
<G-vec00048-002-s261><depart.wegfahren><de> Von 45 Bahnhöfen in ganz Deutschland fährt ein direkter ICE mindestens einmal pro Woche über die neue Hochgeschwindig-keitsstrecke, beispielsweise ab Stralsund oder Garmisch-Partenkirchen.
<G-vec00048-002-s262><depart.wegfahren><en> Schedule of shuttle buses: First bus will depart from Bled (main parking lot at Bled Sports Hall) three hours prior to start of daily competitions.
<G-vec00048-002-s262><depart.wegfahren><de> Zeitplan der Shuttlebuse: Der erste Bus fährt von Bled (Hauptparkplatz bei der Sporthalle Bled) drei Stunden vor dem Anfang der Rennen.
<G-vec00048-002-s263><depart.weggehen><en> 15 And when euen was come, his disciples came to him, saying, This is a desart place, and the time is alreadie past: let the multitude depart, that they may goe into the townes, and bye them vitailes.
<G-vec00048-002-s263><depart.weggehen><de> 15 Am Abend aber traten seine Jünger zu ihm und sprachen: Dies ist eine Wüste, und die Nacht fällt herein; Laß das Volk von dir, daß sie hin in die Märkte gehen und sich Speise kaufen.
<G-vec00048-002-s264><depart.weggehen><en> We’ll depart from the station of El Chorro, so we’ll be able to get there in our own vehicle or by train.
<G-vec00048-002-s264><depart.weggehen><de> Wir gehen vom Bahnhof von El Chorro los, so dass wir mit unserem eigenen Fahrzeug oder mit dem Zug dorthin gelangen können.
<G-vec00048-002-s265><depart.weggehen><en> Or put in your language, you have to depart and to come back again.
<G-vec00048-002-s265><depart.weggehen><de> Oder, in eurer Sprache gesagt, du musst gehen und ein zweites Mal kommen.
<G-vec00048-002-s266><depart.weggehen><en> Ask yourselves whether you could stand before God's judgment seat, whether your earthly life is right with God, whether you have shown love, and whether you are ready to depart from earth at any hour without fear of having to give account to God....
<G-vec00048-002-s266><depart.weggehen><de> Prüfet euch, ob ihr werdet bestehen können vor dem Richterstuhl Gottes, ob euer Erdenlebenswandel gerecht ist vor Gott, ob ihr die Liebe geübt und ob ihr jede Stunde bereit seid, von der Erde zu gehen, ohne die Verantwortung vor Gott fürchten zu müssen....
<G-vec00048-002-s267><depart.weggehen><en> After a written and oral placement test you depart on a city tour of Quito / Cusco / Sucre together with all new students.
<G-vec00048-002-s267><depart.weggehen><de> Nach einem schriftlichen und mündlichen Einstufungstest gehen Sie zusammen mit allen neuen Studenten auf eine Stadttour in Quito / Cusco / Sucre.
<G-vec00048-002-s268><depart.weggehen><en> With whatever clothing he arrived, with the like let him depart. If he has a wife, his wife also shall depart, at the same time.
<G-vec00048-002-s268><depart.weggehen><de> 3 Ist er ohne Frau gekommen, so soll er auch ohne Frau gehen; ist er aber mit seiner Frau gekommen, so soll sie mit ihm gehen.
<G-vec00048-002-s269><depart.weggehen><en> Without saying a word to my son, I will depart elsewhere.” So not telling a creature he left the park and passing beyond the borders of the realm of Magadha he built him a hut of leaves in the Mahimsaka kingdom, near Mount Candaka, in a bend of the river Kannapenna, where it issues out of the lake Samkhapala.
<G-vec00048-002-s269><depart.weggehen><de> Ohne meinem Sohne etwas davon zu sagen, werde ich anderswohin gehen.“ Ohne jemand etwas davon wissen zu lassen, verließ er den Park, durchschritt das Königreich Magadha und erbaute sich im Königreich Mahimsaka an einer Krümmung des aus dem Samkhapala-See kommenden Kannapenna-Flusses bei dem Candaka-Berge eine Laubhütte.
<G-vec00048-002-s270><depart.weggehen><en> Pisa Centrale is the main train station, where all important, mostly regular connections to the most prominent cities like Rome, Genoa, Turin, Naples, Livorno, Grosseto and Florence depart.
<G-vec00048-002-s270><depart.weggehen><de> Dabei fungiert Pisa Centrale als Hauptbahnhof, über den alle wichtigen, teilweise regulären Verbindungen zu allen bedeutenden italienischen Städten wie Rom, Genua, Turin, Neapel, Livorno, Grosseto und Florenz gehen.
<G-vec00048-002-s271><depart.weggehen><en> Now before the feast of the passover, Jesus, knowing that his hour had come that he should depart out of this world to the Father, having loved his own who were in the world, loved them to the end.
<G-vec00048-002-s271><depart.weggehen><de> 1 Vor dem Passahfest aber, da Jesus wusste, dass seine Stunde gekommen war, aus dieser Welt zum Vater zu gehen: Wie er die Seinen geliebt hatte, die in der Welt waren, so liebte er sie bis ans Ende.
<G-vec00048-002-s272><depart.weggehen><en> Depart from Tower Pier, next to the historic Tower of London fortress and fairytale Tower Bridge. Sail past sights, such as the Houses of Parliament, London Eye, and the towering Shard pyramid at London Bridge.
<G-vec00048-002-s272><depart.weggehen><de> Gehen Sie am Tower Pier in der Nähe des Tower of London an Bord und fahren Sie flussabwärts, vorbei an Sehenswürdigkeiten wie dem Globe Theatre, dem brandneuen Shard-Wolkenkratzer (derzeit das höchste Gebäude Europas) sowie dem London Eye und den Houses of Parliament.
<G-vec00048-002-s273><depart.weggehen><en> Then answered all the wicked men and men of Belial, of those that went with David, and said, Because they went not with us, we will not give them any of the spoil that we have recovered, except to every man his wife and his children, that they may lead them away, and depart.
<G-vec00048-002-s273><depart.weggehen><de> 22 Und allerlei Böse und Nichtswürdige von den Männern, die mit David gezogen waren, sagten: Weil sie nicht mit uns gezogen sind, wollen wir ihnen von der Beute, die wir [den Feinden] entrissen haben, nichts geben, sondern jeder [nehme] seine Frau und seine Kinder; die können sie mitnehmen und gehen.
<G-vec00048-002-s274><depart.weggehen><en> 12 And David said to Uriah, Tarry here to day also, and to morrow I will let thee depart.
<G-vec00048-002-s274><depart.weggehen><de> 12 David sprach zu Uria:So bleib heute auch hie, morgen will ich dich lassen gehen.
<G-vec00048-002-s275><depart.weggehen><en> And coming, they besought them: and bringing them out, they desired them to depart out of the city.
<G-vec00048-002-s275><depart.weggehen><de> Und sie kamen und redeten ihnen zu; und sie führten sie hinaus und baten sie, daß sie aus der Stadt gehen möchten.
<G-vec00048-002-s276><depart.weggehen><en> 30:22 Then answered all the wicked men and base fellows, of those that went with David, and said: 'Because they went not with us, we will not give them aught of the spoil that we have recovered, save to every man his wife and his children, that they may lead them away, and depart.'
<G-vec00048-002-s276><depart.weggehen><de> 30:22 Und allerlei Böse und Nichtswürdige von den Männern, die mit David gezogen waren, sagten: Weil sie nicht mit uns gezogen sind, wollen wir ihnen von der Beute, die wir [den Feinden] entrissen haben, nichts geben, sondern jeder [nehme] seine Frau und seine Kinder; die können sie mitnehmen und gehen.
<G-vec00048-002-s277><depart.weggehen><en> Inspired by its message, Mo Lishi has written a few personal lines about those who depart and the new ones who come and can look forward to a life full of promise.
<G-vec00048-002-s277><depart.weggehen><de> Davon inspiriert, hat Mo Lishi ein paar persönliche Zeilen geschrieben: Über die einen, die gehen, und die anderen, die kommen und ein verheißungsvolles Leben erwarten.
<G-vec00048-002-s278><depart.weggehen><en> 8:37 All the people of the surrounding country of the Gadarenes asked him to depart from them, for they were very much afraid.
<G-vec00048-002-s278><depart.weggehen><de> (37) Und die ganze Menge der Umgebung von Gerasa bat ihn, von ihnen zu gehen, weil sie eine große Furcht erfasst hatte.
<G-vec00048-002-s279><depart.weggehen><en> On the third day you will depart after an early breakfast to take the boat back to Rurrenabaque where you will arrive around 8.30 hrs.
<G-vec00048-002-s279><depart.weggehen><de> Heute gehen Sie ins Boot zurück nach Rurrenabaque, wo Sie um ungefähr 08.30 Uhr ankommen.
<G-vec00048-002-s280><depart.weggehen><en> 39 (UKJV) And they came and besought them, and brought them out, and desired them to depart out of the city.
<G-vec00048-002-s280><depart.weggehen><de> 39 (ELB) Und sie kamen und redeten ihnen zu; und sie führten sie hinaus und baten sie, daß sie aus der Stadt gehen möchten.
<G-vec00048-002-s281><depart.weggehen><en> After breakfast, depart for Johannesburg for your flight to George.
<G-vec00048-002-s281><depart.weggehen><de> Nach dem Frühstück geht die Fahrt an der Küste entlang nach Hermanus.
<G-vec00048-002-s282><depart.weggehen><en> In the early evening depart to the Papyrus institute where the procedure of manufacturing the oldest paper in the world will be demonstrated for you.
<G-vec00048-002-s282><depart.weggehen><de> Vom Museum geht es weiter zum Papyrus-Institut, wo Ihnen die Kunst der Papierherstellung aus Schilfrohr, die von den alten Ägyptern entdeckt wurde, vorgeführt wird.
<G-vec00048-002-s283><depart.weggehen><en> The meeting point is at 5.00pm or 5.30pm at Adolf ski hire shop and from there you will depart on a 4-hour tour.
<G-vec00048-002-s283><depart.weggehen><de> Treffpunkt ist jeweils um 17 oder 17.30 Uhr beim Skiverleih Adolf und von dort aus geht es gemeinsam los zur 4 stündigen Tour.
<G-vec00048-002-s284><depart.weggehen><en> Early in the morning we depart towards the little island Šćedro where we will have enough time to relax and refresh in the clean, crystal blue sea.
<G-vec00048-002-s284><depart.weggehen><de> Früh am morgen geht es zur kleinen Insel Šćedro, wo wir zu Mittag essen und auch Zeit zum Schwimmen haben.
<G-vec00048-002-s285><depart.weggehen><en> As usual, flights to Lanzarote will depart once a week and twice weekly to Gran Canaria and Fuerteventura.
<G-vec00048-002-s285><depart.weggehen><de> Flüge nach Lanzarote finden wie gewohnt einmal pro Woche statt, nach Gran Canaria und Fuerteventura geht es zweimal wöchentlich.
<G-vec00048-002-s286><depart.weggehen><en> Even if the EU prioritizes a Multilateral Investment Court instead of the old ISDS mechanism, the Commission does not depart in the new system from granting multinational corporations privileged rights of action and to prize rulings of this court of justice above democratically legitimised laws under certain circumstances.
<G-vec00048-002-s286><depart.weggehen><de> Auch wenn von Seiten der EU ein multilateraler Schiedsgerichtshof anstelle des alten ISDS-Mechanismus priorisiert wird, geht die Kommission im neuen System nicht davon ab, multinationalen Konzernen privilegierte Klagsrechte einzuräumen und Entscheidungen dieses Gerichtshofs unter Umständen über demokratisch legitimierte Gesetze zu stellen.
<G-vec00048-002-s287><depart.weggehen><en> 4)And into whatsoever house ye enter, there abide until ye depart thence.
<G-vec00048-002-s287><depart.weggehen><de> 4 Und in welches Haus ihr eintretet, dort bleibt, und von da geht weiter.
<G-vec00048-002-s288><depart.weggehen><en> After a final breakfast at the hotel, you will depart for the airport for your flight back to Lima and journey home.
<G-vec00048-002-s288><depart.weggehen><de> Nach einem letzten Frühstück im Hotel geht es dann schließlich nach Lima.
<G-vec00048-002-s289><depart.weggehen><en> Next we'll depart for the landing beaches at Normandy, where we stop at both the Pointe du Hoc and the American cemetery Saint-Laurent at Omaha Beach for about an hour.
<G-vec00048-002-s289><depart.weggehen><de> Weiter geht es an die Landungsstrände der Normandie, wo wir an Pointe du Hoc und dem amerikanischen Friedhof Saint-Laurent am Omaha Beach für eine gute Stunde Halt machen.
<G-vec00048-002-s290><depart.weggehen><en> And Lot went out and spoke to his sons-in-law, who married his daughters, and said, Arise, depart from this place; for the LORD will destroy this city: but he seemed to his sons-in-law as one that mocked.
<G-vec00048-002-s290><depart.weggehen><de> 14Da ging Lot hinaus und redete mit den Männern, die seine Töchter heiraten sollten: Macht euch auf und geht aus diesem Ort, denn der HERR wird diese Stadt verderben.
<G-vec00048-002-s291><depart.weggehen><en> Now before the Feast of the Passover, when Jesus knew that His hour had come that He should depart from this world to the Father, having loved His own who were in the world, He loved them to the end.
<G-vec00048-002-s291><depart.weggehen><de> PR VI (Evangelium): Joh 13,1-15.34-35 1 Vor dem Passafest aber erkannte Jesus, dass seine Stunde gekommen war, dass er aus dieser Welt ginge zum Vater.
<G-vec00048-002-s292><depart.weggehen><en> 1 Now before the feast of the Passover, Jesus, having seen that his hour has come that he would depart out of this world to his Father, having loved his own in the world, he loved them to the end.
<G-vec00048-002-s292><depart.weggehen><de> 1 Vor dem Fest aber der Ostern, da Jesus erkennete, daß seine Zeit kommen war, daß er aus dieser Welt ginge zum Vater: wie er hatte geliebet die Seinen, die in der Welt waren, so liebte er sie bis ans Ende.
<G-vec00048-002-s293><depart.weggehen><en> 4:42 And when it was day, he departed, and went into a desert place; and the people sought him, and came to him, and stayed him, that he should not depart from them.
<G-vec00048-002-s293><depart.weggehen><de> 4:42 Als es aber Tag geworden war, ging er aus und begab sich an einen öden Ort; und die Volksmengen suchten ihn auf und kamen bis zu ihm, und sie hielten ihn auf, daß er nicht von ihnen ginge.
<G-vec00048-002-s294><depart.weggehen><en> ¶ As soon as it was day, he departed and went away into a desert place, and the people sought him and came to him, and kept him that he should not depart from them.
<G-vec00048-002-s294><depart.weggehen><de> 42Da es aber Tag ward, ging er hinaus an eine wüste Stätte; und das Volk suchte ihn, und sie kamen zu ihm und hielten ihn auf, daß er nicht von ihnen ginge.
<G-vec00048-002-s295><depart.weggehen><en> 1 Now before the festival of the Passover, Jesus knew that his hour had come to depart from this world and go to the Father. Having loved his own who were in the world, he loved them to the end.
<G-vec00048-002-s295><depart.weggehen><de> Vor dem Passafest aber erkannte Jesus, daß seine Stunde gekommen war, daß er aus dieser Welt ginge zum Vater; und wie er die Seinen geliebt hatte, die in der Welt waren, so liebte er sie bis ans Ende.
<G-vec00048-002-s296><depart.weggehen><en> 42 And when it was day, he departed, and went into a desert place; and the people sought him, and came to him, and stayed him, that he should not depart from them.
<G-vec00048-002-s296><depart.weggehen><de> 42Als es aber Tag wurde, ging er hinaus an eine einsame Stätte; und das Volk suchte ihn, und sie kamen zu ihm und wollten ihn festhalten, damit er nicht von ihnen ginge.
<G-vec00048-002-s297><depart.weggehen><en> 42And when it was day, he departed and went into a desert place: and the people sought him, and came unto him, and stayed him, that he should not depart from them.
<G-vec00048-002-s297><depart.weggehen><de> 42 Als es aber Tag wurde, ging er hinaus an eine einsame Stätte; und die Menge suchte ihn, und sie kamen zu ihm und wollten ihn festhalten, damit er nicht von ihnen ginge.
<G-vec00048-002-s298><depart.weggehen><en> And when it was day, going out he went into a desert place, and the multitudes sought him, and came unto him: and they stayed him that he should not depart from them.
<G-vec00048-002-s298><depart.weggehen><de> Da es aber Tag ward, ging er hinaus an eine wüste Stätte; und das Volk suchte ihn, und sie kamen zu ihm und hielten ihn auf, daß er nicht von ihnen ginge.
