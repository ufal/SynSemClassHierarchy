<G-vec00497-002-s047><cede.(sich)_nehmen><en> By then they cede their place to the daylilies and the autumn garden.
<G-vec00497-002-s047><cede.(sich)_nehmen><de> Danach nehmen die Taglilien und der Herbstgarten ihren Platz ein.
<G-vec00497-002-s049><cede.abgeben><en> As much as businesses enjoy having power, they will happily cede power and let us have things our way if it helps them get even more of our money.
<G-vec00497-002-s049><cede.abgeben><de> So sehr Unternehmen ihre Macht genießen, so freudig werden sie Macht abgeben und überlassen uns Dinge auf unsere Art zu tun, wenn ihnen das hilft mehr von unserem Geld zu bekommen.
<G-vec00497-002-s046><cede.abtreten><en> The architect was therefore forced to attend the project only as a consultant and to cede all his intellectual property rights to the city of Dubai.
<G-vec00497-002-s046><cede.abtreten><de> Demnach wurde der Architekt genötigt, lediglich als Berater dem Projekt beizuwohnen und die Rechte an seinem geistigen Eigentum komplett an die Stadt Dubai abzutreten.
<G-vec00497-002-s035><cede.befinden><en> No idea... perhaps Cede could help you out on that?
<G-vec00497-002-s035><cede.befinden><de> Du befindest dich hier: Ich hätte da eine Idee...
<G-vec00497-002-s039><cede.erheben><en> The blessed old man did not reclaim the fruit, but he did not cede possession of the land for the reason we have given above.
<G-vec00497-002-s039><cede.erheben><de> Der selige Greis erhob keinen Anspruch auf den Ertrag, aber die Herrschaft über das Land gab er aus dem angegebenen Grunde nicht auf.
<G-vec00497-002-s047><cede.nehmen><en> By then they cede their place to the daylilies and the autumn garden.
<G-vec00497-002-s047><cede.nehmen><de> Danach nehmen die Taglilien und der Herbstgarten ihren Platz ein.
<G-vec00497-002-s052><cede.treten><en> If the customer has sold the account receivable in the framework of genuine factoring, he shall hereby cede the substitute receivable against the factor to us already now.
<G-vec00497-002-s052><cede.treten><de> Hat der Auftraggeber die Forderung im Rahmen eines echten Factorings verkauft, so tritt er die an die Stelle tretende Forderung gegen den Factor hiermit schon jetzt an uns ab.
<G-vec00497-002-s041><cede.vereinnahmen><en> Never cede, therefore, to the temptation to distance yourself from intimacy with your Heavenly Spouse by allowing yourselves to be overly attracted by the interests and problems of daily life.
<G-vec00497-002-s041><cede.vereinnahmen><de> Gebt daher niemals der Versuchung nach, euch von der inneren Vertrautheit mit eurem himmlischen Bräutigam zu entfernen und euch zu sehr von den Belangen und den Problemen des täglichen Lebens vereinnahmen zu lassen.
<G-vec00497-002-s054><cede.verlassen><en> Cede the long sessions to the gamblers who go to Vegas just for the gaming.
<G-vec00497-002-s054><cede.verlassen><de> Verlassen Sie die langen Runden um die Personen, die nach Las Vegas gehen einfach für die Wetten.
<G-vec00497-002-s056><cede.verlieren><en> And as the German Empire had been obliged to cede almost one seventh of its territory, the country was also gripped by a wave of migrants.
<G-vec00497-002-s056><cede.verlieren><de> Nachdem das Deutsche Kaiserreich knapp ein Siebtel seines Territoriums verlor, wurde das Land von einer Flüchtlingswelle erfasst.
<G-vec00497-002-s028><cede.weichen><en> While St Nicholas has had to cede his place to the ‘christ child’, especially in protestant areas of Europe, his creepy helper has clung on in imaginations with a stubborn survival instinct.
<G-vec00497-002-s028><cede.weichen><de> Während der Heilige Nikolaus besonders in den protestantischen Gegenden Europas allmählich dem Christkind weichen musste, hat sich sein ominöser Knecht als hartnäckiger Überlebenskünstler erwiesen.
<G-vec00497-002-s059><cede.zedieren><en> The beneficiary of the letter of credit can assign (cede) the credit proceeds entirely or in part to a third party.
<G-vec00497-002-s059><cede.zedieren><de> Der Akkreditivbegünstigte kann den Akkreditiverlös ganz oder teilweise an eine Drittpartei abtreten (zedieren).
<G-vec00497-002-s062><cede.zurücktreten><en> If the artist’s freedom of creative expression is measured against an interference with the right of phonogram producers that only slightly limits the possibilities of exploitation, the exploitation interests of the phonogram producer may have to cede in favour of artistic dialogue.
<G-vec00497-002-s062><cede.zurücktreten><de> Steht der künstlerischen Entfaltungsfreiheit ein Eingriff in das Tonträgerherstellerrecht gegenüber, der die Verwertungsmöglichkeiten nur geringfügig beschränkt, können die Verwertungsinteressen des Tonträgerherstellers zugunsten der Freiheit der künstlerischen Auseinandersetzung zurückzutreten haben.
<G-vec00497-002-s063><cede.überlassen><en> It may cede its operations wholly or partially to such companies.
<G-vec00497-002-s063><cede.überlassen><de> Sie kann ihren Betrieb ganz oder teilweise solchen Unternehmungen überlassen.
<G-vec00497-002-s045><cede.übertragen><en> Should mixture take place in a manner whereby the concerns of the Customer are considered the primary concerns, it is considered agreed that the Customer shall cede partial and proportional ownership to Band Pro.
<G-vec00497-002-s045><cede.übertragen><de> Erfolgt die Vermischung in der Weise, dass die Sache des Kunden als Hauptsache anzusehen ist, so gilt als vereinbart, dass der Kunde Band Pro anteilmäßig Miteigentum überträgt.
