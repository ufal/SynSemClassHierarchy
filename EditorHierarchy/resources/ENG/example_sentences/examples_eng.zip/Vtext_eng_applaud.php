<G-vec00135-001-s013><applaud.loben><en> Some commentators applaud the move, saying it will finally launch a dialogue between the conflicting parties.
<G-vec00135-001-s013><applaud.loben><de> Damit wird endlich ein Dialog der Konfliktparteien angestoßen, loben einige Kommentatoren.
<G-vec00120-001-s015><applaud.applaudieren><en> I applaud them for this simple statement for I, too, have found appreciation to be the express elevator to the upper floors of my own consciousness.
<G-vec00120-001-s015><applaud.applaudieren><de> Ich applaudiere ihnen zu dieser einfachen Aussage, denn auch ich habe gefunden, dass Dankbarkeit der beschleunigte Fahrstuhl zu den oberen Stockwerken meines eigenen Bewusstseins ist.
<G-vec00120-001-s016><applaud.applaudieren><en> I applaud him for acting courageously to express the spirit of liberty and truth.
<G-vec00120-001-s016><applaud.applaudieren><de> Ich applaudiere ihn für mutig fungieren, zum des Geists der Freiheit und der Wahrheit auszudrücken.
<G-vec00120-001-s017><applaud.applaudieren><en> And today I applaud the Unbounce customers who have agreed to let me analyze their landing page designs in public view.
<G-vec00120-001-s017><applaud.applaudieren><de> Und heute applaudiere ich den Unbounce-Kunden, die mir erlaubt haben, ihre Landing Page Designs öffentlich zu analysieren.
<G-vec00120-001-s018><applaud.applaudieren><en> In this instance, I also applaud Samuels for his fresh thinking on race relations.
<G-vec00120-001-s018><applaud.applaudieren><de> In diesem Fall applaudiere ich auch Samuels für sein frisches Denken auf Rennenrelationen.
<G-vec00135-001-s019><applaud.applaudieren><en> Applaud yourself for making errors.
<G-vec00135-001-s019><applaud.applaudieren><de> Applaudiere dir dafür, dass du Fehler gemacht hast.
<G-vec00120-001-s020><applaud.applaudieren><en> "Video ""A man holds a speech to the audience in an auditorium on a convention of economics and finance their business and to applaud his speech"" can be used for personal and commercial purposes according to the conditions of the purchased Royalty-free license."
<G-vec00120-001-s020><applaud.applaudieren><de> "Das Video ""Ein Mann hält eine Rede an das Publikum im Auditorium eine Konvention der Ökonomie und ihre Geschäfte zu finanzieren und zu seiner Rede applaudieren"" kann für persönliche und kommerzielle Zwecke gemäß den Bedingungen der erworbenen abgabefreien (royalty-free) Lizenz verwendet werden."
<G-vec00120-001-s021><applaud.applaudieren><en> "Today instead should be all the rage ""street priest"", and ""suburban priests', but the old story is always the same: He comes from a part don Luigi Ciotti for the show one of its Messe sociopolitical, and rushes at once jubilant and sculettante Niki Vendola with her in tow to applaud the 'base priest ""."
<G-vec00120-001-s021><applaud.applaudieren><de> "Heute stattdessen sollte der letzte Schrei ""Straße Priester"" sein, und ""Vorstadtpriester, aber die alte Geschichte ist immer die gleiche: Er kommt aus einem Teil Don Luigi Ciotti für die Show eines ihrer Messe gesellschaftspolitische, und stürzt auf einmal jubelnd und sculettante Niki Vendola mit ihr im Schlepptau des 'Basis Priester"" applaudieren."
<G-vec00120-001-s022><applaud.applaudieren><en> From George to Lenore to their son Mitt, the Romney family has chosen to give back to America through public service, and that is a legacy that we honor and applaud tonight.
<G-vec00120-001-s022><applaud.applaudieren><de> Von George über Lenore zu ihrem Sohn Mitt hat die Romney-Familie Amerika im Dienst an der Allgemeinheit etwas zurückgezahlt, und das ist ein Vermächtnis, das wir ehren und dem wir heute Nacht applaudieren.
<G-vec00120-001-s023><applaud.applaudieren><en> Although the impacts of Garcinia Extra still a couple of in scientific evidence, several physicians have verified the formula as secure to be consumed by human and even applaud it.
<G-vec00120-001-s023><applaud.applaudieren><de> Obwohl die Auswirkungen der Garcinia Extra noch ein paar in wissenschaftlichen Beweise haben mehrere Ärzte die Formel als sicher verifiziert werden durch menschliche verbraucht und sogar applaudieren sie.
<G-vec00120-001-s025><applaud.applaudieren><en> Although the results of Garcinia Extra still a few in scientific proof, many physicians have actually validated the formula as risk-free to be eaten by human and even applaud it.
<G-vec00120-001-s025><applaud.applaudieren><de> Obwohl die Ergebnisse der Garcinia Extra noch ein paar in wissenschaftlichen Beweise, viele Ärzte validiert haben die Formel als sicher werden durch menschliche aufgenommen und sogar applaudieren sie.
<G-vec00120-001-s026><applaud.applaudieren><en> Although the effects of Garcinia Extra still a few in clinical evidence, lots of medical professionals have verified the formula as safe to be eaten by human and even applaud it.
<G-vec00120-001-s026><applaud.applaudieren><de> Obwohl die Auswirkungen der Garcinia Extra noch ein paar in der klinischen Beweisen, viele medizinisch Fachleute haben die Formel als sicher verzehrt werden vom Menschen überprüft und sogar applaudieren sie.
<G-vec00120-001-s027><applaud.applaudieren><en> Applause Applause Students applaud during a visit to a school in the vicinity of Kunduz.
<G-vec00120-001-s027><applaud.applaudieren><de> Applaus Applaus Schüler applaudieren während einer Besichtung einer Schule in der Nähe von Kunduz.
<G-vec00120-001-s028><applaud.applaudieren><en> I’d applaud Dr Jensen for not muddying the waters in that respect.
<G-vec00120-001-s028><applaud.applaudieren><de> Ich würde Dr. Jensen für nicht trüben das Wasser in dieser Hinsicht applaudieren.
<G-vec00120-001-s029><applaud.applaudieren><en> Articulo 19's latest report Simulated Democracy, Nothing to Applaud states that of the aggressions against reporters committed during the current six-year term of office, only 8% were allegedly committed by members of organized crime while 48% were committed by public officials.
<G-vec00120-001-s029><applaud.applaudieren><de> Der Bericht #Simulierte Demokratie, nichts zu applaudieren, den Artikel 19 2018 veröffentlichte, weist darauf hin, dass von den Aggressionen gegen Journalisten während der aktuellen Amtszeit nicht mehr als 8% vom organisierten Verbrechen begangen wurden; derweil wurden 48% von Beamten im öffentlichen Dienst begangen.
<G-vec00120-001-s030><applaud.applaudieren><en> You have accomplished something that has never before been done and we applaud you and urge you to step up to your new paths and to walk them with confidance knowing that we walk beside you.
<G-vec00120-001-s030><applaud.applaudieren><de> Ihr habt etwas vollbracht, das noch niemals zuvor gemacht worden ist und wir applaudieren euch und drängen euch, auf eure neuen Wege zuzugehen und sie mit Vertrauen zu beschreiten, wissend, dass wir an eurer Seite gehen.
<G-vec00120-001-s031><applaud.applaudieren><en> Others seek only to be stroked like a cat, desiring others to applaud and confirm their present list of beliefs.
<G-vec00120-001-s031><applaud.applaudieren><de> Andere suchen nur wie eine Katze gestreichelt zu werden, dem Wunsch anderen zu applaudieren, und bestätigen Sie ihre gegenwärtige Liste von Überzeugungen.
<G-vec00120-001-s032><applaud.applaudieren><en> On a scene of a film festival of Kozhevnikov shared history of the grandfather then in a hall began to applaud with the audience.
<G-vec00120-001-s032><applaud.applaudieren><de> Auf der Szene des Filmfestivals Koschewnikows hat den Zuschauer von der Geschichte des Großvaters mitgeteilt, wonach im Saal anfingen zu applaudieren.
<G-vec00120-001-s033><applaud.applaudieren><en> Â Solve the case quickly, and everyone will applaud your leadership.
<G-vec00120-001-s033><applaud.applaudieren><de> Löse den Fall schnell, und jeder wird Ihre Führungs applaudieren.
<G-vec00120-001-s034><applaud.applaudieren><en> In the back of the crowd a man wearing with a yarmulke - a Jew - stands next to a black man as they both applaud the homespun hero. Was that an accident?
<G-vec00120-001-s034><applaud.applaudieren><de> In der Rückseite der Masse ein Mann, der mit einem yarmulke trägt - ein Jude - Standplätze nahe bei einem schwarzen Mann, wie sie beide den homespun Held applaudieren.
<G-vec00120-001-s035><applaud.applaudieren><en> At times we know it has not been easy and we applaud you for never giving up and for believing that it could be done.
<G-vec00120-001-s035><applaud.applaudieren><de> Wir wissen, dass es oft nicht einfach gewesen ist und wir applaudieren euch, da ihr nie aufgegeben hat und dass ihr daran geglaubt hat, dass es machbar ist.
<G-vec00120-001-s036><applaud.applaudieren><en> So back to the letter-writing campaign: While I applaud the effort I really don't see how they are going to exact a change.
<G-vec00120-001-s036><applaud.applaudieren><de> So der Brief-Kampagne zurück: Während ich die Anstrengung, die ich wirklich nicht sehen, wie sie mit einer genauen Wandels applaudieren.
<G-vec00120-001-s037><applaud.applaudieren><en> The journalists who aren't bad are thrilled by the short flight however and applaud when the aeroplane lands.
<G-vec00120-001-s037><applaud.applaudieren><de> Diejenigen Journalisten, denen nicht schlecht wird, sind jedoch vom Rundflug begeistert und applaudieren bei der Landung.
<G-vec00120-001-s038><applaud.applaudieren><en> Although the impacts of Garcinia Extra still a few in scientific evidence, many physicians have confirmed the formula as safe to be taken in by human and even applaud it.
<G-vec00120-001-s038><applaud.applaudieren><de> Obwohl die Auswirkungen der Garcinia Extra noch ein paar in wissenschaftlichen Beweis, haben viele Mediziner die Formel als risikofrei validiert durch menschliche genommen in sein und sogar applaudieren sie.
<G-vec00135-001-s039><applaud.applaudieren><en> Our encounter with India could not be more cheerful, thanks to the enthusiasm and skills of a multiethnic army of young musicians educated to beauty, that Veronica and I were able to applaud as soon as we landed in Mumbai.
<G-vec00135-001-s039><applaud.applaudieren><de> Der Eindruck von Indien konnte nicht strahlender sein, dank des Enthusiasmus und der Bravour einer solch multikulturellen Armee junger Musikanten, die zum Schönen erzogen sind, denen Veronica und ich applaudieren durften, kaum dass wir in Mumbai gelandet waren.
<G-vec00135-001-s040><applaud.applaudieren><en> At that very moment the group of people present will applaud you and shower you with rose petals.
<G-vec00135-001-s040><applaud.applaudieren><de> In diesem Moment wird die Gruppe der Leute, die anwesend sind, Sie applaudieren und mit Rose-Blumenblättern duschen.
<G-vec00135-001-s041><applaud.applaudieren><en> You applaud, but not for the model.
<G-vec00135-001-s041><applaud.applaudieren><de> Sie applaudieren, aber nicht fÃ1⁄4r das Modell.
<G-vec00120-001-s042><applaud.applaudieren><en> All of your vaunted “politics of memory” and “learning from the past” is simply a pile of dog shit, as again before your eyes unarmed civilians are butchered, and you applaud this and promise these Ukrainian murderers fresh financing.
<G-vec00120-001-s042><applaud.applaudieren><de> Eure gesamte „Erinnerungskultur“ und das „Lernen aus der Vergangenheit“ sind nicht mehr als ein schlechter Witz, wenn vor euren Augen unbewaffnete Menschen ermordet werden, während ihr applaudiert und den ukrainischen Mördern neue Kredite versprecht.
<G-vec00120-001-s043><applaud.applaudieren><en> Up on the mountain we wait and applaud.
<G-vec00120-001-s043><applaud.applaudieren><de> Oben am Berg wird gewartet und applaudiert.
<G-vec00120-001-s044><applaud.applaudieren><en> You may laugh or cry, and then you applaud, and then you leave the theatre.
<G-vec00120-001-s044><applaud.applaudieren><de> Ihr mögt lachen oder weinen, danach applaudiert ihr, und danach geht ihr aus dem Theater heraus.
<G-vec00120-001-s045><applaud.applaudieren><en> The day will soon come when mankind will applaud him and acknowledge the great sacrifice he has made on its behalf.
<G-vec00120-001-s045><applaud.applaudieren><de> Der Tag wird bald kommen, an dem ihm die Menschheit applaudiert und sein großes Opfer würdigt, das er ihr gebracht hat.
<G-vec00120-001-s046><applaud.applaudieren><en> Applaud those who have the courage to speak out regarding the atrocities experienced by children.
<G-vec00120-001-s046><applaud.applaudieren><de> Applaudiert denen, die den Mut haben, die Grausamkeiten auszusprechen, die Kinder erlebt haben.
<G-vec00120-001-s047><applaud.applaudieren><en> As far as the doubts of the resumption and the weakness of the dollar, there I applaud to two hands, because it is indeed the inconvenient functioning of the press US which hides behind this growth of paper and which builds the deficits US next to which Godzilla and King Kong are dwarfs.
<G-vec00120-001-s047><applaud.applaudieren><de> Für das, das an zwei Händen applaudierte Zweifel der Wiederaufnahme und die Schwäche des Dollars dort ich ist, denn, es ist wirklich das unangebrachte Funktionieren des US-Scheinbretts, das sich hinten dieses Papierwachstum versteckt, und das die US-Defizite baut an, seitens von denen Godzilla und King Kongs Zwerge sind.
<G-vec00120-001-s049><applaud.beglückwünschen><en> I am aware that Falun Gong practitioners have long endured brutal persecution by the Chinese authorities and I applaud your continuing peaceful efforts to protest and reform the regime’s actions.
<G-vec00120-001-s049><applaud.beglückwünschen><de> Ich bin mir bewusst, dass Falun Gong Praktizierende lange Zeit eine brutale Verfolgung durch der chinesischen Behörden geduldet haben und ich beglückwünsche Sie für Ihre fortgesetzten friedlichen Bemühungen, gegen die Taten des Regimes zu protestieren und diese zu verbessern.
<G-vec00120-001-s068><applaud.spenden><en> Even though, unfortunately, there is no new Nikon scanner, this is a development that we, LaserSoft Imaging, can only applaud.
<G-vec00120-001-s068><applaud.spenden><de> Auch wenn es leider kein neuer Nikon-Scanner geworden ist, ist das eine Entwicklung, der wir von LaserSoft Imaging nur Beifall spenden können.
<G-vec00120-001-s069><applaud.spenden><en> We should not just applaud our athletes when they come home with gold medals. We should welcome them with brotherly affection; we should welcome them all as if they had won.
<G-vec00120-001-s069><applaud.spenden><de> Unseren Sportlern muss man nicht nur Beifall spenden, wenn sie mit Goldmedaillen zurückkommen, sondern man muss alle mit brüderlicher Zuneigung so empfangen, als ob sie gewonnen hätten.
<G-vec00120-001-s070><applaud.zollen><en> """We can only applaud all these people [Shen Yun's artists],"" she said."
<G-vec00120-001-s070><applaud.zollen><de> """Wir können diesen Leuten [den Künstlern von Shen Yun] nur Beifall zollen"", sagte sie."
<G-vec00120-001-s071><applaud.zollen><en> They'd rather us die too, a decision that our enemies applaud.
<G-vec00120-001-s071><applaud.zollen><de> Sie würden eher auch uns sterben lassen – eine Entscheidung, der unsere Feinde Beifall zollen.
<G-vec00120-001-s074><applaud.beklatschen><en> If some want to be known solely for their talents, I applaud it.
<G-vec00120-001-s074><applaud.beklatschen><de> Wenn einige ausschließlich für ihre Talente bekannt sein wollen, beklatsche ich es.
<G-vec00120-001-s075><applaud.beklatschen><en> We sit in the Linq Theater and applaud Mat Franco for his almost too-perfect card tricks.
<G-vec00120-001-s075><applaud.beklatschen><de> Wir sitzen im Theater des Linq Hotel & Casino und beklatschen Mat Franco für seine fast schon überperfekten Kartentricks.
<G-vec00135-001-s079><applaud.applaudieren><en> The Cabinet is there merely to advise him; the parliament (Reichstag) is there merely to hear his decisions and applaud.
<G-vec00135-001-s079><applaud.applaudieren><de> Das Kabinett berät ihn lediglich; das Parlament (der Reichstag) nimmt lediglich seine Entscheidungen entgegen und applaudiert.
<G-vec00135-001-s080><applaud.beklatschen><en> But does that mean we have to applaud everything our partner does?...
<G-vec00135-001-s080><applaud.beklatschen><de> Bedeutet aber dieser Fakt, dass man alles beklatschen muss, was der Partner tut?...
<G-vec00135-001-s086><applaud.applaudieren><en> After the performance, people near the castle leaned out of windows to applaud.
<G-vec00135-001-s086><applaud.applaudieren><de> Nach der Vorführung lehnten sich die Leute in der Nähe des Schlosses aus ihren Fenstern und applaudierten.
<G-vec00120-001-s088><applaud.klatschen><en> Strange way hears one the Spanish spectators nearly only with punishing corners of its team, if they applaud rhythmic.
<G-vec00120-001-s088><applaud.klatschen><de> Kurioser Weise hört man die spanischen Zuschauer fast nur bei Strafecken ihres Teams, wenn sie rhythmisch klatschen.
<G-vec00120-001-s089><applaud.klatschen><en> Faked Broder: But people applaud when I say such things.
<G-vec00120-001-s089><applaud.klatschen><de> Faked Broder: Aber die Leute klatschen, wenn ich solche Sachen sage.
<G-vec00120-001-s090><applaud.klatschen><en> Along the march route, many people stopped to watch and applaud.
<G-vec00120-001-s090><applaud.klatschen><de> Viele Menschen entlang der Marschroute hielten an und klatschten Beifall.
<G-vec00120-001-s092><applaud.loben><en> I still applaud the churches for spreading the Good News.
<G-vec00120-001-s092><applaud.loben><de> Ich lobe die Kirchen dennoch weil sie die Gute Nachricht verbreiten.
<G-vec00120-001-s093><applaud.loben><en> Although experts applaud Angola for introducing stringent anti-corruption legislation and for taking action publicly to combat corruption, it is safe to assume that some of the oil revenue is being misappropriated at the top echelons of government.
<G-vec00120-001-s093><applaud.loben><de> Obgleich Fachleute Angola dafür loben, dass es strenge Anti-Korruptionsgesetze eingeführt hat und die Korruption auch öffentlich bekämpft, ist dennoch davon auszugehen, dass Teile der Ölgewinne auf hoher administrativer Ebene unter schla gen werden.
<G-vec00120-001-s094><applaud.loben><en> We applaud President Bush's record of upholding justice and human rights all over the world, and we sincerely hope that he will continue to do so when Jiang Zemin comes to visit.
<G-vec00120-001-s094><applaud.loben><de> Wir loben Präsident Bushs Aussage, Gerechtigkeit und Menschenrechte auf der ganzen Welt schützen zu wollen und wir hoffen aufrichtig, dass er damit fortfahren wird, wenn Jiang Zemin zu Besuch sein wird.
<G-vec00120-001-s095><applaud.loben><en> I applaud StatTools' powerful statistical analysis.
<G-vec00120-001-s095><applaud.loben><de> I kann die leistungsstarke statistische StatTools-Analyse nur loben.
<G-vec00120-001-s096><applaud.loben><en> Although the results of Garcinia Extra still a few in clinical evidence, numerous physicians have verified the formula as secure to be consumed by human and even applaud it.
<G-vec00120-001-s096><applaud.loben><de> Obwohl die Auswirkungen der Garcinia Extra noch ein paar in wissenschaftlichen Beweise haben mehrere Ärzte bestätigt tatsächlich die Formel als risikofrei durch menschliche genommen in werden, und es sogar loben.
<G-vec00120-001-s097><applaud.loben><en> "Nonetheless, the upper authorities applaud this a place as a ""model unit for Shandong Province."""
<G-vec00120-001-s097><applaud.loben><de> "Nichtsdestotrotz loben die höheren Beamten diesen Ort als ""vorbildliche Einheit der Provinz Shandong""."
<G-vec00120-001-s098><applaud.loben><en> Survivors are even forced to publicly applaud and thank their torturers.
<G-vec00120-001-s098><applaud.loben><de> Die Überlebenden werden sogar dazu gezwungen, ihre Folterer öffentlich zu loben und ihnen zu danken.
<G-vec00120-001-s101><applaud.spenden><en> "Now this same man says: ""I applaud the courage and dignity of the Tunisian people."""
<G-vec00120-001-s101><applaud.spenden><de> "Jetzt sagt derselbe Mann: ""Ich spende dem Mut und der Würde des tunesischen Volkes Beifall""."
<G-vec00120-001-s103><applaud.applaudieren><en> It will be a wonderful occasion to watch and applaud the performances of persons that have not wanted to give up on their passion for dance.
<G-vec00120-001-s103><applaud.applaudieren><de> Dies ist eine wunderbare Gelegenheit, um an der Aufführung von Menschen, die auf Ihre Leidenschaft für den Tanz nicht verzichten wollen, teilzuhaben und zu applaudieren.
<G-vec00120-001-s105><applaud.applaudieren><en> During the performance of Minstrel Hall, a lady in the audience began to applaud prematurely during a pause in the song.
<G-vec00120-001-s105><applaud.applaudieren><de> "Ritchie war fest entschlossen seine Sache diesen Abend rüberzubringen und jeder fand das gut.Während der Aufführung von ""Minstrel Hall"" begann eine Frau im Publikum, während einer Pause im Lied, zu zeitig an zu applaudieren."
<G-vec00120-001-s106><applaud.zollen><en> "The entire working class of the U.S.S.R., the entire advanced section of the proletarians in all countries, enthusiastically welcome the Manifesto, unanimously applaud the idea of introducing a seven hour working day -- but the opposition votes against the Manifesto and adds its voice to the general chorus of bourgeois and Menshevik ""critics,"" it adds its voice to those of the slanderers on the staff of Vorwärts ."
<G-vec00120-001-s106><applaud.zollen><de> "Die ganze Arbeiterklasse der UdSSR, der ganze fortgeschrittene Teil der Proletarier aller Länder begrüßen das Manifest voller Begeisterung, zollen der Idee des Übergangs zum Siebenstundentag einmütigen Beifall - die Opposition aber stimmt gegen das Manifest, stimmt in den allgemeinen Chor der bürgerlichen und menschewistischen ""Kritiker"" ein und schließt sich den Verleumdern aus dem ""Vorwärts"" an."
<G-vec00120-001-s107><applaud.zollen><en> We applaud the work of popes, church leaders, and scholars who passionately contributed to these developments, including the strong-willed proponents of Catholic-Jewish dialogue at the end of World War II, whose collective work was a leading drive for Nostra Aetate .
<G-vec00120-001-s107><applaud.zollen><de> Wir zollen der Arbeit der Päpste, Kirchenleiter und Gelehrten Beifall, die leidenschaftlich zu diesen Entwicklungen beigetragen haben, darunter den entschlossenen Befürwortern des katholisch-jüdischen Dialogs am Ende des Zweiten Weltkrieges, deren gemeinsame Arbeit ein maßgeblicher Antrieb zu Nostra Aetate war.
<G-vec00135-002-s013><applaud.applaudieren><en> Politik ZURÜCKEROBERT. I applaud and congratulate the U.S. Senate for confirming our GREAT NOMINEE, Judge Brett Kavanaugh, to the United States Supreme Court.
<G-vec00135-002-s013><applaud.applaudieren><de> HEUTE HAT DIE REPUBLIK DIE KONTROLLE applaudiere und gratuliere dem US-Senat dafür, dass er unseren GROßARTIGEN NOMINEE, Richter Brett Kavanaugh, vor dem Obersten Gerichtshof der Vereinigten Staaten bestätigt hat.
<G-vec00135-002-s014><applaud.applaudieren><en> For the words that the mouth utters come from the overflowing of the heart.” (Matthew 12: 33-34) Therefore: If his fruits are good, I applaud the man and his religion.
<G-vec00135-002-s014><applaud.applaudieren><de> Denn die Worte, die der Mund aus dem Überströmen des Herzens hervorbringt, "(Matthäus 12: 33-34) Deshalb: Wenn seine Früchte gut sind, applaudiere ich dem Mann und seiner Religion.
<G-vec00135-002-s015><applaud.applaudieren><en> Thus also the piece by Yoshie Baba, of Japan, which shows an artist asking the viewers to applaud her every movement and action.
<G-vec00135-002-s015><applaud.applaudieren><de> So auch die Performance von Yoshie Baba aus Japan, bei der sie die Zuschauer darum bat, bei jeder ihrer Bewegungen zu applaudieren.
<G-vec00135-002-s016><applaud.applaudieren><en> IT wants to applaud.
<G-vec00135-002-s016><applaud.applaudieren><de> ES möchte applaudieren.
<G-vec00135-002-s017><applaud.applaudieren><en> They applaud and ask me to whip my pony.
<G-vec00135-002-s017><applaud.applaudieren><de> Sie applaudieren und fordern mich auf, mein Pony zu peitschen.
<G-vec00135-002-s018><applaud.applaudieren><en> Even at the break after a half hours, many applaud him standing.
<G-vec00135-002-s018><applaud.applaudieren><de> Schon zur Pause nach anderthalb Stunden applaudieren viele ihm stehend.
<G-vec00135-002-s019><applaud.applaudieren><en> Your eggs will applaud every time.
<G-vec00135-002-s019><applaud.applaudieren><de> Deine Eier werden jedes Mal applaudieren.
<G-vec00135-002-s020><applaud.applaudieren><en> Everybody has some dreams and ideas about perfection and therefore you will applaud to unbelievably hot Zdenek.
<G-vec00135-002-s020><applaud.applaudieren><de> Jeder hat ein paar Träume und Vorstellungen von Perfektion und deshalb werden Sie dem unglaublich heißen Zdenek applaudieren.
<G-vec00135-002-s021><applaud.applaudieren><en> Often the same reactions follow: opponents are shocked, supporters applaud, and the media discusses.
<G-vec00135-002-s021><applaud.applaudieren><de> Es sind fast immer die gleichen Reaktionen, die darauf folgen: Die Gegner sind entsetzt, seine Unterstützer applaudieren, die Medien diskutieren.
<G-vec00135-002-s022><applaud.applaudieren><en> People have paid to see this and they applaud when the man has ejaculated.
<G-vec00135-002-s022><applaud.applaudieren><de> Die Leute haben dafür bezahlt, dies zu sehen, und applaudieren, wenn der Mann gekommen ist.
<G-vec00135-002-s023><applaud.applaudieren><en> On the contrary, the two emissaries do nothing but applaud this new conquest since “Biopower — a horizon of the hybridization of the natural and the artificial, needs and machines, desire and collective organization of the economic and the social — must continually regenerate itself in order to exist” (p. 389).
<G-vec00135-002-s023><applaud.applaudieren><de> Im Gegensatz dazu tun die beiden Abgesandten nichts als zu dieser neuen Eroberung zu applaudieren, denn „Biomacht - ein Horizont der Hybridisierung des Natürlichen und des Künstlichen, von Bedürfnissen und Maschinen, von Begehren und der kollektiven Organisation des Ökonomischen und des Gesellschaftlichen - muss sich, um bestehen zu können, fortwährend re-generieren“.
<G-vec00135-002-s024><applaud.applaudieren><en> He said Moscow believes there is no use in appealing to the common sense of American politicians, since many of them are currently “blinded by Russophobia and eagerly applaud the Ukrainian nationalist punitive battalions.”
<G-vec00135-002-s024><applaud.applaudieren><de> Er fügte hinzu, dass es keinen Sinn macht, sich an den gesunden Menschenverstand US-amerikanischer Politiker zu wenden, da viele von ihnen derzeit „von Russophobie geblendet sind und den ukrainischen nationalistischen Strafbataillonen eifrig applaudieren“.
<G-vec00135-002-s025><applaud.applaudieren><en> A crowning guitar solo completes an excellent introduction and makes me applaud for the first time.
<G-vec00135-002-s025><applaud.applaudieren><de> Ein krönendes Gitarrensolo rundet einen hervorragenden Einstieg ab und lässt mich das erste Mal applaudieren.
<G-vec00135-002-s026><applaud.applaudieren><en> I have to applaud Leslie’s skepticism.
<G-vec00135-002-s026><applaud.applaudieren><de> Ich habe zu applaudieren Leslie ‘ s Skepsis.
<G-vec00135-002-s031><applaud.applaudieren><en> When Sousa returned to the United States, he found people would often applaud his sacrifice, although he personally believed it was because people felt guilty and wanted to make themselves feel better.[2]
<G-vec00135-002-s031><applaud.applaudieren><de> Als Sousa in die Vereinigten Staaten zurückkehrte, fand er, dass die Leute oft sein Opfer applaudierten, obwohl er persönlich glaubte, dass es so war, weil die Leute sich schuldig fühlten und sich besser fühlen wollten.
<G-vec00135-002-s066><applaud.applaudieren><en> You can take long walks to leave your cares behind or stop and applaud the street entertainers.
<G-vec00135-002-s066><applaud.applaudieren><de> Hier kann man bei einem langen Spaziergang die Seele baumeln lassen und den Strassenkünstlern applaudieren.
<G-vec00135-002-s035><applaud.begrüßen><en> "I applaud the FDA's decision to approve the diaphragm pacer so all ALS patients can have access to it.
<G-vec00135-002-s035><applaud.begrüßen><de> "Ich begrüße die Entscheidung der FDA, den Zwerchfellschrittmacher zuzulassen, damit alle ALS-Patienten darauf Zugriff haben.
<G-vec00135-002-s036><applaud.begrüßen><en> I applaud his methods as he is one of the few Tutors I know who can get teenagers to say they truly enjoyed his lessons! Well Done."
<G-vec00135-002-s036><applaud.begrüßen><de> Ich begrüße seine Methode, da er einer der wenigen Lehrer ist, die Jugendliche dazu bringt zu sagen, dass sie die Unterrichtstunden richtig genossen haben“.
<G-vec00135-002-s037><applaud.begrüßen><en> I therefore applaud the efforts of the Federal Government to enhance the meaning of electric drive systems in motor vehicles.
<G-vec00135-002-s037><applaud.begrüßen><de> Ich begrüße daher die Bestrebungen der Bundesregierung zur Steigerung der Bedeutung von elektrischen Antrieben in Kraftfahrzeugen.
<G-vec00135-002-s038><applaud.begrüßen><en> I do, however, applaud Frank for their cavalier approach here, albeit inappropriate.
<G-vec00135-002-s038><applaud.begrüßen><de> Ich begrüße Frank jedoch für ihren unbekümmerten Ansatz, obwohl auch unangebracht.
<G-vec00135-002-s039><applaud.begrüßen><en> I applaud your business model.
<G-vec00135-002-s039><applaud.begrüßen><de> Ich begrüße Ihr Geschäftsmodell.
<G-vec00135-002-s040><applaud.begrüßen><en> Finally, I applaud Mrs Figueiredo's initiative, because it aims to ensure that minimum standards applicable to all are universally applied, without prejudice to the existence of standards in individual Member States that are more favourable to workers.
<G-vec00135-002-s040><applaud.begrüßen><de> Abschließend begrüße ich die Initiative von Frau Figueiredo, weil sie sicherstellen will, dass weltweit Mindestnormen für alle Betroffenen angewandt werden, unbeschadet der bereits in einzelnen Mitgliedstaaten bestehenden günstigeren Normen für Arbeitnehmer.
<G-vec00135-002-s041><applaud.begrüßen><en> Finally, I applaud the joint action promoted by the Council, namely to extend the right of sea and air pursuit of these pirates to the territorial waters of the coastal states, provided that the countries concerned agree, as well as to develop a mechanism for coordinated assistance against cases of maritime piracy.
<G-vec00135-002-s041><applaud.begrüßen><de> Zum Schluss begrüße ich die vom Rat geförderte gemeinsame Maßnahme, nämlich die Ausweitung des Rechts zur Verfolgung dieser Piraten per See und Luft in den territorialen Gewässern der Küstenstaaten, vorausgesetzt, dass die betroffenen Länder ihre Zustimmung dazu erteilen, sowie die Entwicklung eines Mechanismus für koordinierte Unterstützung gegen Fälle der Hochseepiraterie.
<G-vec00135-002-s042><applaud.begrüßen><en> Well ok, the mayors don‘t want to grow weed themselves, although we would certainly applaud such a move.
<G-vec00135-002-s042><applaud.begrüßen><de> Na OK, die Bürgermeister selbst wollen natürlich kein Gras anbauen, obwohl wir einen solchen Schritt sicherlich begrüßen würden.
<G-vec00135-002-s043><applaud.begrüßen><en> Whilst we have to applaud the fact that some of the European institutions are coming under heavy criticism, I should like to make an observation.
<G-vec00135-002-s043><applaud.begrüßen><de> Es ist zwar zu begrüßen, dass einige europäische Institutionen stark kritisiert werden, ich möchte aber doch eine Bemerkung machen.
<G-vec00135-002-s044><applaud.begrüßen><en> It wishes to applaud his work, his personal commitment, and his continuous efforts to accomplish his mission since his appointment in August 2017.
<G-vec00135-002-s044><applaud.begrüßen><de> Wir begrüßen seine Arbeit, sein persönliches Engagement und seine ständigen Bemühungen um eine erfolgreiche Erfüllung seiner Aufgaben seit seiner Ernennung im August 2017.
<G-vec00135-002-s045><applaud.begrüßen><en> Every Thursday, people all over the country stand in front of their homes and applaud the NHS employees who are on the front line in the battle against the terrible disease.
<G-vec00135-002-s045><applaud.begrüßen><de> Jeden Donnerstag stehen Menschen im ganzen Land vor ihren Häusern und begrüßen die NHS-Mitarbeiter, die im Kampf gegen die schreckliche Krankheit an vorderster Front stehen.
<G-vec00135-002-s046><applaud.begrüßen><en> "We applaud recent statements made by Undersecretary of Defense for Acquisition and Sustainment, Ellen Lord, expressing significant concern regarding U.S. sole-source dependence on China for rare earth products.
<G-vec00135-002-s046><applaud.begrüßen><de> "Wir begrüßen die Aussagen von Ellen Lord, Undersecretary of Defense for Acquisition and Sustainment, die sich ernsthaft besorgt darüber zeigt, dass China die einzige Quelle der USA für Seltenerdmetallprodukte ist.
<G-vec00135-002-s047><applaud.begrüßen><en> Usually all the designers applaud the uniqueness and exclusivity of their silk and satin dresses.
<G-vec00135-002-s047><applaud.begrüßen><de> Normalerweise werden alle Designer begrüßen die Einzigartigkeit und Exklusivität ihrer Seide und Satin Kleider.
<G-vec00135-002-s048><applaud.begrüßen><en> Football Supporters Europe (FSE) applaud the progressive approach adopted by both the DFB and UEFA.
<G-vec00135-002-s048><applaud.begrüßen><de> Football Supporters Europe (FSE) begrüßt den progressiven Ansatz von DFB und UEFA.
<G-vec00135-002-s064><applaud.begrüßen><en> His proposal to require all university students to spend time in other eurozone countries to learn at least two languages is another example of his long-term collaborative thinking, something which I applaud.
<G-vec00135-002-s064><applaud.begrüßen><de> Sein Vorschlag, von allen Universitätsstudenten zu fordern, Zeit in anderen Ländern der Eurozone zu verbringen, um mindestens zwei Sprachen zu lernen, ist ein weiteres Beispiel für seine langfristige kooperative Denkweise, die ich sehr begrüße.
<G-vec00135-002-s051><applaud.beklatschen><en> He allows Donald Trump to applaud him and jokes around with the left-wing environmental editor of the 'Guardian'....
<G-vec00135-002-s051><applaud.beklatschen><de> Er lässt sich von Donald Trump beklatschen und schäkert mit dem linken Umweltredakteur des 'Guardian'....
<G-vec00135-002-s050><applaud.spenden><en> Too bad for the conter-demonstrators - even not 100 of them showed up - who are running quickly away at the sight of the masses arriving to applaud Jean-Marie Le Pen.
<G-vec00135-002-s050><applaud.spenden><de> Um so schlimmer für die Gegendemonstranten: knapp 100 von ihnen tauchten auf, liefen aber beim Anblick der Menschenmassen, die herbeiströmten, um Jean-Marie Le Pen Beifall zu spenden, wieder weg.
<G-vec00135-002-s065><applaud.spenden><en> We applaud you, dear ones.
<G-vec00135-002-s065><applaud.spenden><de> Wir spenden euch Beifall, ihr Lieben.
