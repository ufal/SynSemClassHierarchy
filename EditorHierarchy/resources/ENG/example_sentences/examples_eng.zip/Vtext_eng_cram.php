<G-vec00735-002-s018><cram.einfügen><en> In the dictionary, we have tried to cram in as much scales and chords as possible.
<G-vec00735-002-s018><cram.einfügen><de> Im Wörterbuch haben wir versucht, so viele Tonleitern und Akkorde wie möglich einzufügen.
<G-vec00735-002-s022><cram.packen><en> I love that they cram me and fill my mouth with milk.
<G-vec00735-002-s022><cram.packen><de> Ich liebe, dass sie mich packen und meinen Mund mit Milch füllen.
<G-vec00735-002-s023><cram.packen><en> It can seem next to impossible to cram even just the essence of your message into these precious few words.
<G-vec00735-002-s023><cram.packen><de> Es kann fast unmöglich erscheinen, auch nur die Essenz ihrer Nachricht in diesen kostbaren paar Worte zu packen.
<G-vec00735-002-s025><cram.quetschen><en> Don’t try to cram as much as possible onto each sheet.
<G-vec00735-002-s025><cram.quetschen><de> Versuche nicht, so viel wie möglich auf ein Blatt zu quetschen.
<G-vec00735-002-s026><cram.quetschen><en> Up to three players can cram around the keyboard.
<G-vec00735-002-s026><cram.quetschen><de> Bis zu drei Spieler können sich an die Tastatur quetschen.
<G-vec00735-002-s027><cram.stopfen><en> Crumple some newspapers, cram them into the pot and fix everything with glue.
<G-vec00735-002-s027><cram.stopfen><de> Zeitungspapier zerknüllen, in den Topf stopfen und alles mit Kleber festigen.
<G-vec00735-002-s028><cram.stopfen><en> Quickly we cram our bags into the small trunk and get into the car.
<G-vec00735-002-s028><cram.stopfen><de> Rasch stopfen wir unsere Taschen in den kleinen Kofferraum und steigen ein.
<G-vec00735-002-s029><cram.unterbringen><en> Through our engineering expertise, we have been able to cram the latest, highly performant technology into this amazingly thin (15.9 mm) and light (1.05 kg) chassis.
<G-vec00735-002-s029><cram.unterbringen><de> Mit unserem Technologie-Know-How konnten wir die neueste und leistungsfähigste Technologie in diesem unglaublich dünnen (15,9 mm) und leichten (1,05 kg) Gehäuse unterbringen.
<G-vec00735-002-s030><cram.verstopfen><en> Laws and regulations cram its statute books.
<G-vec00735-002-s030><cram.verstopfen><de> Seine Statuten sind mit Gesetzen und Bestimmungen verstopft.
<G-vec00735-002-s032><cram.vollstopfen><en> Of course these aren’t the conventional TV ads that try to cram down the consumer’s throat the latest pitch in 30 seconds or less, as companies must work diligently to attract and maintain the loyalty of these subscribers.
<G-vec00735-002-s032><cram.vollstopfen><de> Natürlich sind diese nicht die herkömmlichen Werbespots die versuchen dem Verbraucher die Kehle mit dem Neuesten in weniger als 30 Sekunden vollzustopfen, ein Unternehmen muss fleißig Arbeiten um die Loyalität dieser Abonnenten zu gewinnen und zu behalten.
<G-vec00735-002-s033><cram.zusammendrängen><en> It’s better to print a few more pages than to cram text and pictures too close together.
<G-vec00735-002-s033><cram.zusammendrängen><de> Also, lieber ein paar Seiten mehr bedrucken, als Texte und Bilder zu sehr zusammenzudrängen.
<G-vec00841-002-s021><cram.lernen><en> Older ones huddle in pods, some chitchat, others cram for a test in their civics and ethics class.
<G-vec00841-002-s021><cram.lernen><de> Ältere drängen sich in Grüppchen zusammen, einige plaudern, andere lernen für einen Test in Staatsbürgerkunde- und Ethikunterricht.
