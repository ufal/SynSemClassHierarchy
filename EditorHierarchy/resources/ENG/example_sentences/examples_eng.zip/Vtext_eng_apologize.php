<G-vec00658-002-s038><apologize.bitten><en> We apologize for any inconvenience and hope that the new system provides you a better overview of our range in the future.
<G-vec00658-002-s038><apologize.bitten><de> Wir bitten Sie um Verständnis und hoffen, dass Ihnen diese neue Systematik künftig den Überblick über unser Angebot erleichtert.
<G-vec00658-002-s039><apologize.bitten><en> We apologize for the inconvenience, but please submit your receipt, your purchased tickets and your credit card at the ticket counter.
<G-vec00658-002-s039><apologize.bitten><de> Wir bitten Sie, hierzu den Kaufbeleg (Quittung), die komplette Anzahl gekaufter Tickets und Ihre Kreditkarte an dem Ticket Counter vorzuzeigen.
<G-vec00658-002-s040><apologize.bitten><en> We apologize for any invconvenience.
<G-vec00658-002-s040><apologize.bitten><de> Wir bitten um Entschuldigung, es ist ein unbekannter Fehler aufgetreten.
<G-vec00658-002-s041><apologize.bitten><en> We apologize for the inconvenience, but we're performing some maintenance.
<G-vec00658-002-s041><apologize.bitten><de> Für die Unannehmlichkeiten bitten wir um Ihr Verständnis.
<G-vec00658-002-s042><apologize.bitten><en> We apologize for the inconvenience and thank you for your cooperation.
<G-vec00658-002-s042><apologize.bitten><de> Wir bitten um Ihr Verständnis und bedanken uns für Ihre Geduld.
<G-vec00658-002-s137><apologize.bitten><en> However, we are disappointed that you have used your speech not just to apologize, but also for an opportunistic and transparent political ploy to gain the sympathy of pro-Israeli groups and the Israeli government.
<G-vec00658-002-s137><apologize.bitten><de> Wir sind allerdings enttäuscht, dass Sie Ihre Rede nicht nur für eine Entschuldigung benutzt haben, sondern auch für ein opportunistisches und durchsichtiges Manöver, die Sympathie von pro-israelischen Gruppen und der israelischen Regierung zu gewinnen.
<G-vec00658-002-s138><apologize.bitten><en> We apologize, but an error occurred and your request could not be completed.
<G-vec00658-002-s138><apologize.bitten><de> Entschuldigung, es ist ein Fehler aufgetreten und die Nachricht wurde nicht gesendet.
<G-vec00658-002-s139><apologize.bitten><en> One of these is when the Spanish government apologized to Jewish people for their expulsion from the Kingdom of Spain in 1492, but they still refuse to apologize to the indigenous peoples of Latin America and the Caribbean.
<G-vec00658-002-s139><apologize.bitten><de> Eines davon ist die Entschuldigung der spanischen Regierung an das jüdische Volk für seinen Ausschluss aus dem spanischen Königreich 1492, aber sie verweigert die Entschuldigung an die indigenen Völker Lateinamerikas und der Karibik.
<G-vec00658-002-s140><apologize.bitten><en> We apologize, this page is not translated into your language.
<G-vec00658-002-s140><apologize.bitten><de> Entschuldigung, diese Seite ist nicht in Ihre Sprache übersetzt.
<G-vec00658-002-s141><apologize.bitten><en> He has to be willing to apologize and provide adequate compensation.
<G-vec00658-002-s141><apologize.bitten><de> Er muss sich zu einer Entschuldigung und angemessenen Entschädigung bereit erklären.
<G-vec00658-002-s142><apologize.bitten><en> He clearly regretted his rash remarks about the mental faculties of his mother and sister but could not bring himself to apologize.
<G-vec00658-002-s142><apologize.bitten><de> Offensichtlich bedauerte er seinen Ausfall über die intellektuellen Fähigkeiten seiner Mutter und seiner Schwester, brachte aber keine Entschuldigung über die Lippen.
<G-vec00658-002-s143><apologize.bitten><en> This is only natural, but you can't go into this thinking that so long as you do everything right when you apologize, that things will work out well.
<G-vec00658-002-s143><apologize.bitten><de> Das ist nur natürlich, aber du darfst nicht in die Vorstellung verfallen, dass solange du mit der Entschuldigung alles richtig machst, die Dinge schon wieder in Ordnung kommen.
<G-vec00658-002-s201><apologize.bitten><en> We apologize for any inconvenience caused.
<G-vec00658-002-s201><apologize.bitten><de> Für etwaige Unannehmlichkeiten bitten wir um Entschuldigung.
<G-vec00658-002-s202><apologize.bitten><en> We sincerely apologize for the inconvenience this may have caused.
<G-vec00658-002-s202><apologize.bitten><de> Für die entstandenen Unannehmlichkeiten bitten wir Sie vielmals um Entschuldigung.
<G-vec00658-002-s025><apologize.entschuldigen><en> Obama as dictator of his world empire is of course not able to afford to apologize to his slaves, and so his accomplices have to do it, and that it is exactly what Ms Merkel feels and wants to prevent, because she insists on a direct apology from the one who insulted her.
<G-vec00658-002-s025><apologize.entschuldigen><de> Obama als der Diktator seines Weltreiches kann es sich natürlich nicht leisten, sich bei seinen Sklaven zu entschuldigen, und so müssen nun seine Helfershelfer es tun, und das ist es genau was Frau Merkel spürt und verhindern will, weil sie auf eine Entschuldigung direkt vom Beleidiger besteht.
<G-vec00658-002-s026><apologize.entschuldigen><en> I often have the feeling that parents apologize to each other when they have clearly said “no” to the...
<G-vec00658-002-s026><apologize.entschuldigen><de> Ich hab oft das Gefühl, dass sich Eltern gegenseitig beieinander entschuldigen, wenn sie dem...
<G-vec00658-002-s027><apologize.entschuldigen><en> We apologize for not having done so before, but we wanted to do so with the permission of the mother superior.
<G-vec00658-002-s027><apologize.entschuldigen><de> Bitte entschuldigen Sie, dass wir das nicht schon früher getan haben, aber wir wollten es mit Erlaubnis unserer Mutter Oberin tun.
<G-vec00658-002-s028><apologize.entschuldigen><en> Unfortunately, I only had my smartphone, I apologize for the bad sound quality. Facebook
<G-vec00658-002-s028><apologize.entschuldigen><de> Leider hatte ich nur mein Smartphone dabei, ich bitte die schlechte Tonqualität zu entschuldigen.
<G-vec00658-002-s029><apologize.entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s029><apologize.entschuldigen><de> Bitte entschuldigen uns für die Unannehmlichkeiten.
<G-vec00658-002-s031><apologize.entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s031><apologize.entschuldigen><de> Eventuelle Unannehmlichkeiten bitten wir zu entschuldigen.
<G-vec00658-002-s032><apologize.entschuldigen><en> We apologize for any inconvenience it might cause you.
<G-vec00658-002-s032><apologize.entschuldigen><de> Wir bitten Sie eventuelle daraus entstandene Unannehmlichkeiten zu entschuldigen.
<G-vec00658-002-s033><apologize.entschuldigen><en> We apologize for this disruption.
<G-vec00658-002-s033><apologize.entschuldigen><de> Wir bitten diese Störung zu entschuldigen.
<G-vec00658-002-s034><apologize.entschuldigen><en> Of course we are dependent on the supplier companies, we apologize for any delays.
<G-vec00658-002-s034><apologize.entschuldigen><de> Natürlich sind wir von den Lieferantenfirmen abhängig, eventuelle Verzögerungen bitten wir zu entschuldigen.
<G-vec00658-002-s035><apologize.entschuldigen><en> We sincerely apologize for the inconvenience.
<G-vec00658-002-s035><apologize.entschuldigen><de> Wir bitten die damit verbundenen Unannehmlichkeiten zu entschuldigen.
<G-vec00658-002-s036><apologize.entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s036><apologize.entschuldigen><de> Etwaige Unannehmlichkeiten bitten wir zu entschuldigen.
<G-vec00658-002-s037><apologize.entschuldigen><en> We apologize for the inconveniences.
<G-vec00658-002-s037><apologize.entschuldigen><de> Wir bitten dieses Ärgernis zu entschuldigen.
<G-vec00658-002-s043><apologize.entschuldigen><en> A mother, a participant of CinA, wrote to her daughter during the training time to apologize for being too controlling of her.
<G-vec00658-002-s043><apologize.entschuldigen><de> Eine Mutter, Teilnehmerin von CinAm, schrieb ihrer Tochter während der Zeit des Trainings, um sich dafür zu entschuldigen, dass sie sie zu sehr kontrolliere.
<G-vec00658-002-s044><apologize.entschuldigen><en> Instead he proposed that the authorities of the church of Velankanni at Mumbai should publicly apologize for distributing the dirty drainage water that was dripping from the cross to hundreds of gullible people.
<G-vec00658-002-s044><apologize.entschuldigen><de> Stattdessen schlug er vor, daß sich die Führung der Kirche von Velankanni in Mumbai öffentlich dafür entschuldigen sollte, daß sie schmutziges Abflußwasser, das vom Kreuz tropfte, an Hunderte von Gläubigen ausgeteilt hat.
<G-vec00658-002-s046><apologize.entschuldigen><en> You have to yield, you have to sacrifice, you have to apologize if you were too greedy.
<G-vec00658-002-s046><apologize.entschuldigen><de> Du musst zurückweichen, opfern und dich entschuldigen, wenn du zu gierig warst.
<G-vec00658-002-s047><apologize.entschuldigen><en> Think through what happened and decide what you need to apologize for.
<G-vec00658-002-s047><apologize.entschuldigen><de> Durchdenke, was passiert ist, und entscheide, wofür du dich entschuldigen musst.
<G-vec00658-002-s048><apologize.entschuldigen><en> Plus, you have no reason to apologize.
<G-vec00658-002-s048><apologize.entschuldigen><de> Außerdem hast du keinen Grund dafür, dich zu entschuldigen.
<G-vec00658-002-s049><apologize.entschuldigen><en> And do not apologize for his "wild" behavior before strangers: you do not have to apologize.
<G-vec00658-002-s049><apologize.entschuldigen><de> Und entschuldige dich nicht für sein "wildes" Verhalten vor Fremden: Du musst dich nicht entschuldigen.
<G-vec00658-002-s050><apologize.entschuldigen><en> If you have many things that you need to say to the person, you may want to write out your apology before you apologize.
<G-vec00658-002-s050><apologize.entschuldigen><de> Wenn du dich für viele Dinge entschuldigen willst, solltest du deine Entschuldigung vielleicht vorher aufschreiben.
<G-vec00658-002-s051><apologize.entschuldigen><en> Prepare to apologize.
<G-vec00658-002-s051><apologize.entschuldigen><de> Sei bereit, dich zu entschuldigen.
<G-vec00658-002-s052><apologize.entschuldigen><en> Look her in the eyes when you apologize.
<G-vec00658-002-s052><apologize.entschuldigen><de> Sieh ihr in die Augen, wenn du dich entschuldigst.
<G-vec00658-002-s053><apologize.entschuldigen><en> Accept responsibility for your actions when you apologize.
<G-vec00658-002-s053><apologize.entschuldigen><de> Übernimm die Verantwortung für deine Handlungen, wenn du dich entschuldigst.
<G-vec00658-002-s055><apologize.entschuldigen><en> So, it´s better to apologize less often, otherwise the German would think that the Japanese counterpart has a guilt complex.
<G-vec00658-002-s055><apologize.entschuldigen><de> Also lieber einmal weniger entschuldigen, sonst denkt der Deutsche noch, sein japanisches Gegenüber hätte einen Schuldkomplex.
<G-vec00658-002-s056><apologize.entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s056><apologize.entschuldigen><de> Entschuldige die Unannehmlichkeiten.
<G-vec00658-002-s057><apologize.entschuldigen><en> 2 Apologize if you hurt him.
<G-vec00658-002-s057><apologize.entschuldigen><de> 2 Entschuldige dich, wenn du ihn verletzt hast.
<G-vec00658-002-s058><apologize.entschuldigen><en> If your co-worker says no, accept what is and apologize for any misunderstandings.
<G-vec00658-002-s058><apologize.entschuldigen><de> Wenn dein Kollege nein sagt, dann akzeptiere diese Tatsache und entschuldige dich für jegliche Missverständnisse.
<G-vec00658-002-s059><apologize.entschuldigen><en> Apologize to all that you had to fail them, thank everyone for your attention.
<G-vec00658-002-s059><apologize.entschuldigen><de> Entschuldige dich für alles, was du zu scheitern hast, danke allen für deine Aufmerksamkeit.
<G-vec00658-002-s060><apologize.entschuldigen><en> "Apologize to the man, Tung dear," Miles sang through his teeth, "and let's get on.
<G-vec00658-002-s060><apologize.entschuldigen><de> »Entschuldige dich bei dem Mann, liebster Tung«, säuselte Miles zwischen zusammengebissenen Zähnen, »und dann laßt uns weitermachen.
<G-vec00658-002-s062><apologize.entschuldigen><en> If you and a friend stopped talking over a meaningless dispute, call or text that friend and apologize.
<G-vec00658-002-s062><apologize.entschuldigen><de> Wenn du und ein Freund wegen eines unbedeutenden Streits nicht mehr miteinander sprecht, rufe diesen Freund an oder schicke ihm eine Textnachricht und entschuldige dich.
<G-vec00658-002-s063><apologize.entschuldigen><en> Mention how grateful you are to your employer and apologize for any inconveniences you caused.
<G-vec00658-002-s063><apologize.entschuldigen><de> Erwähne, wie dankbar du bist, und entschuldige dich für die zusätzlichen Umstände, die du bereitet hast.
<G-vec00658-002-s064><apologize.entschuldigen><en> If you do accidentally hurt her, apologize and move on.
<G-vec00658-002-s064><apologize.entschuldigen><de> Wenn du sie versehentlich verletzt, entschuldige dich und macht weiter.
<G-vec00658-002-s065><apologize.entschuldigen><en> If you mess it up, just give a little laugh and apologize.
<G-vec00658-002-s065><apologize.entschuldigen><de> Wenn du es versaust, dann lache kurz und entschuldige dich.
<G-vec00658-002-s066><apologize.entschuldigen><en> If he responds with a--potentially justified--angry text, apologize again.
<G-vec00658-002-s066><apologize.entschuldigen><de> Wenn er mit einem – potentiell gerechtfertigten – wütenden Text antwortet, entschuldige dich noch einmal.
<G-vec00658-002-s067><apologize.entschuldigen><en> Instead, apologize for each and every thing you did, but don’t even mention the things they did.
<G-vec00658-002-s067><apologize.entschuldigen><de> Entschuldige dich stattdessen für alles und jedes, was du getan hast, ohne auch nur die Dinge zu erwähnen, die er getan hat.
<G-vec00658-002-s068><apologize.entschuldigen><en> 6 Apologize. After contemplating your actions and role in the argument, apologize for any wrongdoing.
<G-vec00658-002-s068><apologize.entschuldigen><de> Wenn ihr über eure Handlungen und eure Rollen im Streit nachgedacht habt, entschuldige dich für falsches Verhalten.
<G-vec00658-002-s069><apologize.entschuldigen><en> If you see no way that you are able to help her fix the problem, then apologize and tell her that you cannot help her fix the problem.
<G-vec00658-002-s069><apologize.entschuldigen><de> Wenn du keine Möglichkeit siehst, wie du ihr bei ihrem Problem helfen kannst, dann entschuldige dich und sage ihr, dass du ihr nicht helfen kannst.
<G-vec00658-002-s070><apologize.entschuldigen><en> Apologize if you make her upset.
<G-vec00658-002-s070><apologize.entschuldigen><de> Entschuldige dich, wenn du sie verärgert hast.
<G-vec00658-002-s071><apologize.entschuldigen><en> Be honest, and apologize for your thoughtlessness.
<G-vec00658-002-s071><apologize.entschuldigen><de> Sei ehrlich und entschuldige dich für deine Gedankenlosigkeit.
<G-vec00658-002-s072><apologize.entschuldigen><en> Apologize when you hurt someone.
<G-vec00658-002-s072><apologize.entschuldigen><de> Entschuldige dich, wenn du jemanden verletzt hast.
<G-vec00658-002-s073><apologize.entschuldigen><en> If my description is not very clear, I apologize in advance.
<G-vec00658-002-s073><apologize.entschuldigen><de> Wenn meine Beschreibung ist nicht ganz klar, ich entschuldige mich im Voraus.
<G-vec00658-002-s074><apologize.entschuldigen><en> I apologize for the delayed response, but we were disrupted by the earthquake.
<G-vec00658-002-s074><apologize.entschuldigen><de> Ich entschuldige mich für die verzögerte Antwort, aber wir waren durch das Erdbeben zerstört.
<G-vec00658-002-s075><apologize.entschuldigen><en> I apologize to the English readers, many links lead to German news or blog sites.
<G-vec00658-002-s075><apologize.entschuldigen><de> Ich entschuldige mich bei den englischen Lesern, viele Links führen zu deutschen Nachrichten oder Blog-Seiten .
<G-vec00658-002-s076><apologize.entschuldigen><en> We apologize for any inconvenience and should be back up with a newly updated website soon.
<G-vec00658-002-s076><apologize.entschuldigen><de> Ich entschuldige mich für jegliche Unannehmlichkeiten und hoffe auf Euer Verständnis...
<G-vec00658-002-s077><apologize.entschuldigen><en> “Gentlemen, I sincerely apologize.
<G-vec00658-002-s077><apologize.entschuldigen><de> „Gentlemen, ich entschuldige mich aufrichtig.
<G-vec00658-002-s078><apologize.entschuldigen><en> I apologize for my inability to retrieve the proper vocabulary in the moment.
<G-vec00658-002-s078><apologize.entschuldigen><de> Ich entschuldige mich für meine Unfähigkeit, im Augenblick das richtige Vokabular herauszuholen.
<G-vec00658-002-s079><apologize.entschuldigen><en> Everything went fine, I apologize for my nervousness.
<G-vec00658-002-s079><apologize.entschuldigen><de> Ich entschuldige mich, dass ich mit nichts helfen kann.
<G-vec00658-002-s080><apologize.entschuldigen><en> Once again I apologize at you, I send bow to your poor orphans".
<G-vec00658-002-s080><apologize.entschuldigen><de> Wieder entschuldige ich mich an Ihnen, ich sende Bogen Ihren armen Waisen".
<G-vec00658-002-s081><apologize.entschuldigen><en> Hi there, I agree with you that we lack a bit in official communication, there are plenty justifications but I'll spare you the long read and just apologize, we will try to improve on that.
<G-vec00658-002-s081><apologize.entschuldigen><de> "Hallo, ich stimme Ihnen zu, dass es uns an offizieller Kommunikation mangelt, es gibt viele Gründe, aber ich erspare Ihnen das lange Lesen und entschuldige mich, wir werden versuchen, dies zu verbessern.
<G-vec00658-002-s082><apologize.entschuldigen><en> For this, I apologize.
<G-vec00658-002-s082><apologize.entschuldigen><de> Für dieses entschuldige mich ich.
<G-vec00658-002-s083><apologize.entschuldigen><en> I apologize and ask for forgiveness for these mistakes (pratikraman).
<G-vec00658-002-s083><apologize.entschuldigen><de> Ich entschuldige mich und bitte um die Vergebung für diese Fehler (Pratikraman).
<G-vec00658-002-s084><apologize.entschuldigen><en> I apologize, but, in my opinion, you are not right.
<G-vec00658-002-s084><apologize.entschuldigen><de> Ich entschuldige mich, aber meiner Meinung nach sind Sie nicht recht.
<G-vec00658-002-s085><apologize.entschuldigen><en> I apologize to all male-men, you are not stupid because of your gender or your hair color or the presence of hair, the cited study is absolute NONSENSE in every respect.
<G-vec00658-002-s085><apologize.entschuldigen><de> Ich entschuldige mich bei allen Männern, ihr seid nicht blöd aufgrund eures Geschlechts oder eurer Haarfarbe oder des Vorhandenseins von Haaren, die zitierte Studie ist absoluter QUATSCH in jeder Beziehung.
<G-vec00658-002-s086><apologize.entschuldigen><en> I apologize for my horrifying acts of violence, a reflection of my own congealed rage, my own inability to distinguish real enemies from friends.
<G-vec00658-002-s086><apologize.entschuldigen><de> Ich entschuldige mich für meine verschreckenden Akte der Gewalt, eine Reflexion meiner eigenen erstarrten Wut, meiner eigenen Unfähigkeit wirkliche Freunde von Feinden zu unterscheiden.
<G-vec00658-002-s087><apologize.entschuldigen><en> For the latter omission I apologize.
<G-vec00658-002-s087><apologize.entschuldigen><de> Für letzteres entschuldige ich mich.
<G-vec00658-002-s088><apologize.entschuldigen><en> I apologize for the mistake.
<G-vec00658-002-s088><apologize.entschuldigen><de> Ich entschuldige mich für den Fehler.
<G-vec00658-002-s089><apologize.entschuldigen><en> I apologize for any inconvenience.
<G-vec00658-002-s089><apologize.entschuldigen><de> Ich entschuldige mich für jede entstandene Unannehmlichkeit.
<G-vec00658-002-s090><apologize.entschuldigen><en> I apologize for the current silence on here but I've been so busy with planning my future.
<G-vec00658-002-s090><apologize.entschuldigen><de> Ich entschuldige mich für die dezente Stille zurzeit, aber meine Zukunftsplanung ist in vollem Gange.
<G-vec00658-002-s091><apologize.entschuldigen><en> I apologize for the possible translation errors.
<G-vec00658-002-s091><apologize.entschuldigen><de> Ich entschuldige mich für Übersetzungsfehler.
<G-vec00658-002-s092><apologize.entschuldigen><en> Before I’ll write here about craft beers I’d like to apologize to all of you. Apologize?
<G-vec00658-002-s092><apologize.entschuldigen><de> Bevor ich hier über Handwerksbiere schreibe, möchte ich mich bei euch allen entschuldigen.
<G-vec00658-002-s093><apologize.entschuldigen><en> Unsatisfied and undaunted, Rajkumari stood by her demand that the boy himself apologize to her and be punished for his behavior.
<G-vec00658-002-s093><apologize.entschuldigen><de> Eisern und unerschrocken hielt sie an ihrer Forderung fest, dass der Junge sich persönlich bei ihr zu entschuldigen hat und er für sein Verhalten bestraft werden müsse.
<G-vec00658-002-s094><apologize.entschuldigen><en> Theophilus, toward the end of the year 402, was summoned by the emperor to Constantinople to apologize before a synod, over which Chrysostom should preside, for several charges, which were brought against him by certain Egyptian monks, especially by the so-called four "tall brothers". VIII, 12) . However, Theophilus was not easily frightened.
<G-vec00658-002-s094><apologize.entschuldigen><de> Theophilus, Theophilus, gegen Ende des Jahres 402, wurde durch den Kaiser berief nach Konstantinopel, um vor einer Synode zu entschuldigen, über die Chrysostomos sollte präsidieren, für mehrere Ladungen, die gegen ihn von bestimmten ägyptischen Mönche gebracht wurden, vor allem durch die sogenannten vier plötzlich gegen sie gewendet und hatte immer Agenten und Freunden in Konstantinopel, und wusste, den Stand der Dinge und die Gefühle bei dem Gericht.
<G-vec00658-002-s095><apologize.entschuldigen><en> We sincerely apologize for the inconvenience.
<G-vec00658-002-s095><apologize.entschuldigen><de> Wir entschuldigen die Unannehmlichkeit.
<G-vec00658-002-s096><apologize.entschuldigen><en> I must apologize for my terrible German on this website.
<G-vec00658-002-s096><apologize.entschuldigen><de> Ich muss für mein schreckliches Deutsch auf dieser Website entschuldigen.
<G-vec00658-002-s097><apologize.entschuldigen><en> We sincerely apologize for the inconvenience.
<G-vec00658-002-s097><apologize.entschuldigen><de> WIR entschuldigen für die Unannehmlichkeiten.
<G-vec00658-002-s098><apologize.entschuldigen><en> We apologize for any inconvenience this may have caused players.
<G-vec00658-002-s098><apologize.entschuldigen><de> Wir entschuldigen für jegliche Unannehmlichkeiten, die dadurch entstanden sind.
<G-vec00658-002-s099><apologize.entschuldigen><en> Before we make our way out, Katherine says, “Christian, I really do, sincerely apologize,” she says in a soft humble tone which is contrite and heartfelt.
<G-vec00658-002-s099><apologize.entschuldigen><de> Bevor wir den Raum verlassen, sagt Katherine sanft, „Christian, ich muss mich wirklich abermals bei dir entschuldigen.“ Ihre Stimme klingt reuevoll und aufrichtig.
<G-vec00658-002-s100><apologize.entschuldigen><en> We do however apologize for this to our old fans that have been waiting since 2006 now (and are used to fast releases from us!) but we will make sure that it will be worth the wait!
<G-vec00658-002-s100><apologize.entschuldigen><de> Natürlich entschuldigen wir uns gerade bei den die-hard Fans dafür, schließlich warten die seit 2006 auf neues Material (und normalerweise veröffentlichen wir eigentlich relativ rasch neues Material), aber wir werden dafür Sorge tragen, dass sich die lange Wartezeit definitiv lohnt.
<G-vec00658-002-s101><apologize.entschuldigen><en> Giovanni manages to hustle her out and to apologize to the others for her behaviour.
<G-vec00658-002-s101><apologize.entschuldigen><de> Giovanni will ihr Verhalten vor den anderen entschuldigen und drängt Elvira hinaus.
<G-vec00658-002-s102><apologize.entschuldigen><en> We are apologize for the inconvenience but you need to download
<G-vec00658-002-s102><apologize.entschuldigen><de> Entschuldigen Sie die Unannehmlichkeiten aber wir führen gerade Wartungsarbeiten durch.
<G-vec00658-002-s103><apologize.entschuldigen><en> Then they offer me cigarettes, cheroots, and tobacco and apologize that they are only German and Algerian goods...
<G-vec00658-002-s103><apologize.entschuldigen><de> Darauf bieten sie mir Zigaretten, Stumpen und Tabak an und entschuldigen sich, dass es nur deutsche und algerische Ware sei...
<G-vec00658-002-s104><apologize.entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s104><apologize.entschuldigen><de> Entschuldigen Sie die Unannehmlichkeit.
<G-vec00658-002-s105><apologize.entschuldigen><en> Thank you for patience and apologize for the inconvenience.
<G-vec00658-002-s105><apologize.entschuldigen><de> Bitte haben Sie Verständnis und entschuldigen Sie die Unannehmlichkeiten.
<G-vec00658-002-s106><apologize.entschuldigen><en> I apologize for the inconvenience, gentlemen, but we are about to get a change of venue.
<G-vec00658-002-s106><apologize.entschuldigen><de> Entschuldigen Sie die Unannehmlichkeit, Gentlemen, aber wir müssen den Treffpunkt verlagern.
<G-vec00658-002-s107><apologize.entschuldigen><en> We apologize for any inconvenience that this procedure may cause.
<G-vec00658-002-s107><apologize.entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten.
<G-vec00658-002-s108><apologize.entschuldigen><en> We apologize now to all members reading this text too late and whose VPN connections were dropped.
<G-vec00658-002-s108><apologize.entschuldigen><de> Wir entschuldigen uns jetzt schon bei den Mitgliedern die diesen Text zu spät lesen und vom Server geflogen sind.
<G-vec00658-002-s109><apologize.entschuldigen><en> We apologize for any inconvenience and we invite you to check back shortly.
<G-vec00658-002-s109><apologize.entschuldigen><de> Wir entschuldigen uns für jegliche Unannehmlichkeiten und bitten Sie, die Seite in Kürze neu zu laden.
<G-vec00658-002-s110><apologize.entschuldigen><en> The page you requested cannot be found We apologize for the inconvenience.
<G-vec00658-002-s110><apologize.entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten und bitten Sie, es später noch einmal zu versuchen.
<G-vec00658-002-s112><apologize.entschuldigen><en> We apologize for the inconvenience, but we're performing some maintenance.
<G-vec00658-002-s112><apologize.entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten und bitten Sie, es später nochmals zu versuchen.
<G-vec00658-002-s113><apologize.entschuldigen><en> We apologize for the inconvenience that these causes may cause, they are totally foreign to Casa Rural Acebuchal 23.
<G-vec00658-002-s113><apologize.entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten, die diese Ursachen haben können, sie sind Casa Rural Acebuchal 23 völlig fremd.
<G-vec00658-002-s115><apologize.entschuldigen><en> "We apologize for any inconvenience this causes those who have tickets to shows but wish to reassure fans to hold onto these existing tickets, as they will be valid for the rescheduled dates, which will be announced shortly.
<G-vec00658-002-s115><apologize.entschuldigen><de> Wir entschuldigen uns für etwaige Unannehmlichkeiten, die dazu führen, dass diejenigen, die Tickets für Shows haben, die Fans jedoch die bestehenden Tickets behalten möchten, da sie gültig sind für die neu geplanten Termine, die in Kürze bekannt gegeben werden.
<G-vec00658-002-s116><apologize.entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s116><apologize.entschuldigen><de> Wir entschuldigen uns fr diese Unannehmlichkeit.
<G-vec00658-002-s117><apologize.entschuldigen><en> We apologize for any inconvenience this has caused.
<G-vec00658-002-s117><apologize.entschuldigen><de> Wir entschuldigen uns für diese Unannehmlichkeiten.
<G-vec00658-002-s118><apologize.entschuldigen><en> We apologize for the the inconvience and appreciate your patience.
<G-vec00658-002-s118><apologize.entschuldigen><de> Wir entschuldigen uns für etwaige Umstände und danken Ihnen für Ihre Geduld.
<G-vec00658-002-s120><apologize.entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s120><apologize.entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten zu entschuldigen.
<G-vec00658-002-s121><apologize.entschuldigen><en> For reasons of adaptation, some services such as restaurants may be adjusted, we apologize in advance.
<G-vec00658-002-s121><apologize.entschuldigen><de> Aus Gründen der Anpassung können einige Dienstleistungen wie Restaurants angepasst werden, wir entschuldigen uns im Voraus.
<G-vec00658-002-s123><apologize.entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s123><apologize.entschuldigen><de> Für etwaige Unannehmlichkeiten entschuldigen wir uns.
<G-vec00658-002-s124><apologize.entschuldigen><en> This site is currently under construction We apologize for the inconvenience.
<G-vec00658-002-s124><apologize.entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten und bitte kommen Sie bald wieder.
<G-vec00658-002-s126><apologize.entschuldigen><en> We apologize for the inconvenience, please try again within 15 minutes.
<G-vec00658-002-s126><apologize.entschuldigen><de> Wir entschuldigen die Unannehmlichkeiten, das Angebot steht schnellst möglich wieder verfügbar.
<G-vec00658-002-s127><apologize.entschuldigen><en> You apologize for your body.
<G-vec00658-002-s127><apologize.entschuldigen><de> Du entschuldigst dich für deinen Körper.
<G-vec00658-002-s128><apologize.entschuldigen><en> And please apologize, I am sharing too many pictures of this look…I am totally fascinated by the movement of this forte_forte silk skirt.
<G-vec00658-002-s128><apologize.entschuldigen><de> Und bitte entschuldigt die unzähligen Bilder dieses Looks..ich bin so fasziniert von der Bewegung des forte_forte Seidenjupes.
<G-vec00658-002-s129><apologize.entschuldigen><en> I also translated some articles from a Kopenhagen living magazine (yes, from Danish so apologize for weird words;)) and uploaded "Let it snow" article-zine.
<G-vec00658-002-s129><apologize.entschuldigen><de> Außerdem hab ich einen wunderschönen Artikel über Trips im Schnee in einer Kopenhagener Wohnzeitschrift gefunden und einige Rezepte übersetzt (ja, aus dem Dänischen, also entschuldigt komische Worte) und den Artikel hochgeladen.
<G-vec00658-002-s130><apologize.entschuldigen><en> We apologize for the delay but now you can vote for your favorite monsters again.
<G-vec00658-002-s130><apologize.entschuldigen><de> Entschuldigt die Verzögerung, aber ab jetzt könnt ihr wieder eure Lieblingsmonster wählen.
<G-vec00658-002-s131><apologize.entschuldigen><en> He doesn’t apologize, he knows he’s wrong.
<G-vec00658-002-s131><apologize.entschuldigen><de> Er entschuldigt sich nicht; er weiß, dass er falsch lag.
<G-vec00658-002-s132><apologize.entschuldigen><en> Later on, he did apologize to the casino's representative but that didn't change the fact that he was denied of the winnings.
<G-vec00658-002-s132><apologize.entschuldigen><de> Später entschuldigte er sich beim Vertreter des Casinos, das änderte jedoch nichts an der Tatsache, dass ihm der Gewinn verweigert wurde.
<G-vec00658-002-s133><apologize.entschuldigen><en> He knew it was wrong and would apologize as he was reaching out to hug a waitress or a stranger.
<G-vec00658-002-s133><apologize.entschuldigen><de> Er wusste, dass das falsch war, und entschuldigte sich, wenn er die Arme ausstreckte, um eine Kellnerin oder einen Fremden zu umarmen.
<G-vec00658-002-s134><apologize.entschuldigen><en> Alaric tried to apologize for not being around, but Jenna told him not to.
<G-vec00658-002-s134><apologize.entschuldigen><de> Er entschuldigte sich bei Jenna, dass er nicht bei ihr sei, aber sie sagte ihm, es würde ihr nicht viel ausmachen.
<G-vec00658-002-s135><apologize.entschuldigen><en> In fact, O’Reilly did apologize and allowed an exception to the organizer.
<G-vec00658-002-s135><apologize.entschuldigen><de> Zwar entschuldigte sich O’Reilly und erlaubte dem Organisator eine Ausnahme.
<G-vec00658-002-s136><apologize.entschuldigen><en> Some participants went to find others to apologize to them and shared their thoughts with others members of the gathering.
<G-vec00658-002-s136><apologize.entschuldigen><de> Einige Teilnehmer gingen auf andere zu, entschuldigten sich und sprachen mit anderen Anwesenden über ihre Gedanken.
<G-vec00658-002-s148><apologize.entschuldigen><en> He's the one that should apologize to me.
<G-vec00658-002-s148><apologize.entschuldigen><de> Und wenn du mich jetzt entschuldigst.
<G-vec00658-002-s152><apologize.entschuldigen><en> I clearly say that I apologize for my past to God and True Parents and love them and am proud of them.
<G-vec00658-002-s152><apologize.entschuldigen><de> Ich sage klar, dass ich mich für meine Vergangenheit vor Gott und den Wahren Eltern entschuldige und dass ich sie liebe und sehr stolz auf sie bin.
<G-vec00658-002-s153><apologize.entschuldigen><en> “I want to apologize for all the times I ran away from you.
<G-vec00658-002-s153><apologize.entschuldigen><de> “Ich möchte mich entschuldigen für alle Zeiten von Ihnen entgangen.
<G-vec00658-002-s154><apologize.entschuldigen><en> I met with David Packard and Bob Noyce and tried to apologize for screwing up so badly.
<G-vec00658-002-s154><apologize.entschuldigen><de> Ich traf David Packard und Bob Noyce und versuchte, mich für mein Versagen zu entschuldigen.
<G-vec00658-002-s155><apologize.entschuldigen><en> “First off, I would like to once again apologize for my actions last year,” Hunt said.
<G-vec00658-002-s155><apologize.entschuldigen><de> "Zuerst möchte ich mich noch einmal für meine Handlungen im vergangenen Jahr entschuldigen.
<G-vec00658-002-s156><apologize.entschuldigen><en> I would like to apologize for the non-appearance last month, unfortunately there was trouble between the German Linux-Magazin and the Brave GNU World after they had cut out a part of issue #48 [5] ("Free Software Laptops").
<G-vec00658-002-s156><apologize.entschuldigen><de> Für den Ausfall letzten Monat möchte ich mich entschuldigen, leider gab es Ärger zwischen dem deutschen Linux-Magazin und der Brave GNU World, nachdem in Ausgabe 48 [5] ein Teil der Kolumne ("Freie Software Laptops") herausgeschnitten worden war.
<G-vec00658-002-s157><apologize.entschuldigen><en> I (the artist) would like to take the time and apologize for the varying drawing style the readers have been experiencing for more than 500 strips.
<G-vec00658-002-s157><apologize.entschuldigen><de> Ich (der Zeichner) möchte mich hier kurz für den inkonsistenten Zeichenstil entschuldigen, den die Leser über mehr als 500 Strips aushalten mussten.
<G-vec00658-002-s158><apologize.entschuldigen><en> Well, I must apologize - I thought surely you were scamming me.
<G-vec00658-002-s158><apologize.entschuldigen><de> Nun, ich muss mich entschuldigen - ich dachte wirklich, dass sie mich betrügen.
<G-vec00658-002-s159><apologize.entschuldigen><en> For those readers who may have already discovered the pleasure, demands and inspirations of the FMP catalogue, I apologize for what might seem like wide-eyed naiveté.
<G-vec00658-002-s159><apologize.entschuldigen><de> Bei den Lesern, die vielleicht schon die Freuden, Anforderungen und Inspirationen des FMP-Katalogs kennen gelernt haben, möchte ich mich für meine vielleicht blauäugige Naivität entschuldigen.
<G-vec00658-002-s160><apologize.entschuldigen><en> I haven't been able to apologize, or correct, or justify, or defend, or squirm out of it, because I haven't been informed.
<G-vec00658-002-s160><apologize.entschuldigen><de> Ich war nicht in der Lage, mich zu entschuldigen oder zu korrigieren oder zu rechtfertigen oder zu verteidigen oder mich herauszuwinden, weil ich nicht informiert worden bin.
<G-vec00658-002-s161><apologize.entschuldigen><en> Therefore, I whish to apologize for the suffering inflicted upon the victims of these crimes in the name of science – to those who perished and have since passed away and to the ones who have survived.
<G-vec00658-002-s161><apologize.entschuldigen><de> Daher möchte ich mich für das Leid entschuldigen, das den Opfern dieser Verbrechen – den toten wie den überlebenden – im Namen der Wissenschaft angetan wurde.
<G-vec00658-002-s162><apologize.entschuldigen><en> I want to apologize." Tears flowed from my eyes.
<G-vec00658-002-s162><apologize.entschuldigen><de> Ich möchte mich entschuldigen.“ Tränen stiegen mir in die Augen, als ich dies hörte.
<G-vec00658-002-s163><apologize.entschuldigen><en> I herewith want to apologize myself to his family and his students for the wrong quotation of his name in the printed publication.
<G-vec00658-002-s163><apologize.entschuldigen><de> Ich möchte mich für die fehlerhafte Nennung seines Namens in der Druckpublikation bei seiner Familie und seinen Schülern entschuldigen.
<G-vec00658-002-s164><apologize.entschuldigen><en> Maybe I should apologize now that I really haven't post lately.
<G-vec00658-002-s164><apologize.entschuldigen><de> Vielleicht sollte ich mich jetzt entschuldigen, dass ich nicht gepostet hab.
<G-vec00658-002-s165><apologize.entschuldigen><en> I am very sorry about your check-in troubles and I would like to apologize again for your inconveniences.
<G-vec00658-002-s165><apologize.entschuldigen><de> Für Ihre Unannehmlichkeiten mit der Zimmerreinigung möchte ich mich in aller Form entschuldigen und ich werde die Reinigugsprozedur umgehend mit meiner Hausdame anschauen.
<G-vec00658-002-s166><apologize.entschuldigen><en> I would like to recognize and apologize for the mistreatment of German Prisoners of War held by the United States, in Germany and France, from 1945 to 1946.
<G-vec00658-002-s166><apologize.entschuldigen><de> Ich moechte die Misshandlung deutscher Kriegsgefangener im Gewarsam der Vereinigten Staaten in Deutschland und Frankreich von 1945 bis 1946 eingestehen und mich dafuer entschuldigen.
<G-vec00658-002-s167><apologize.entschuldigen><en> Since the batch of corrected proofs that I sent on November 29 should by now have reached you, I take this opportunity to apologize for the recent incorporation of new material, and the so-to-speak last-minute, somewhat reduced speed of completion of the half-volume that has resulted from this.
<G-vec00658-002-s167><apologize.entschuldigen><de> 1 Die Absendung der Korrektur, die am 29/11 bei Ihnen eingetroffen sein dürfte, nehme ich zur Veranlassung, mich wegen der neuerlichen Einschaltung, u. des gleichsam in letzter Stunde dadurch etwas verzögerten Tempo in der Fertigstellung des Halbbands zu entschuldigen.
<G-vec00658-002-s171><apologize.entschuldigen><en> We apologize for the inconveniences.
<G-vec00658-002-s171><apologize.entschuldigen><de> Wir möchten die Unannehmlichkeiten entschuldigen.
<G-vec00658-002-s176><apologize.entschuldigen><en> From Munich he wrote Fritz to apologize for not answering the boy's letter sooner for lack of anything important to say.
<G-vec00658-002-s176><apologize.entschuldigen><de> Von München schrieb er an Fritz, er möge entschuldigen, dass er den Brief des Knaben nicht früher beantwortet habe, da es nichts Wichtiges mitzuteilen gebe.
<G-vec00658-002-s177><apologize.entschuldigen><en> Cassie is made to address a white child as if she were superior to her and to apologize for something that wasn't her fault.
<G-vec00658-002-s177><apologize.entschuldigen><de> Cassie wird gemacht, um ein weißes Kind anzusprechen, als ob sie überlegen sei und sich für etwas entschuldige, das nicht ihre Schuld war.
<G-vec00658-002-s178><apologize.entschuldigen><en> He tried to apologize, but Annabeth and I were too busy cracking up.
<G-vec00658-002-s178><apologize.entschuldigen><de> Er wollte sich entschuldigen, aber Annabeth und ich schüttelten uns vor Lachen.
<G-vec00658-002-s179><apologize.entschuldigen><en> And much more: Colonization, colonialism, and coloniality are facts; therefore, the King of Spain must apologize.
<G-vec00658-002-s179><apologize.entschuldigen><de> Zudem: Kolonisation, Kolonialismus und Kolonialität sind Fakten, daher müsse sich der spanische König entschuldigen.
<G-vec00658-002-s180><apologize.entschuldigen><en> Strache urged the president to apologize and criticized him for his further trivialization of National Socialism.
<G-vec00658-002-s180><apologize.entschuldigen><de> Weiters forderte Strache den Präsidenten dazu auf sich zu entschuldigen und kritisierte ihn für seine Verharmlosung des Nationalsozialismus.
<G-vec00658-002-s181><apologize.entschuldigen><en> 'I'll Be Your Man' is about a broken relationship; the man wants to apologize for the past and is so desperate that he prays to god to get his loved one back.
<G-vec00658-002-s181><apologize.entschuldigen><de> In I'll Be Your Man geht es um eine zerbrochene Beziehung; der Mann möchte sich für die Vergangenheit entschuldigen und ist so verzweifelt, dass er zu Gott betet um seine Geliebte zurückerobern zu können.
<G-vec00658-002-s182><apologize.entschuldigen><en> Too many financial types, arrogant people who bump into you because they’re staring at their cell phones and then don’t bother to apologize.
<G-vec00658-002-s182><apologize.entschuldigen><de> Zu viele Finanztypen, unverschämte Leute, die dichanrempeln, weil sie nur auf ihre Handys glotzen, und sich nicht entschuldigen.
<G-vec00658-002-s183><apologize.entschuldigen><en> Therefore he advises it to apologize to the grandfather and to make with it the peace.
<G-vec00658-002-s183><apologize.entschuldigen><de> Deshalb berät er ihm, sich vor dem Großvater zu entschuldigen und, mit ihm der Frieden zu schließen.
<G-vec00658-002-s184><apologize.entschuldigen><en> They must guarantee the basic human rights of the arrested protestors during retention; ii) The government and police must stop suppressing the peaceful assembly and apologize to the people; iii) National People’s Congress must withdraw the ‘fake universal suffrage’.
<G-vec00658-002-s184><apologize.entschuldigen><de> Sämtliche Menschenrechte müssen für die verhafteten AktivistInnen für die gesamte Dauer der Festnahme gewährleistet werden; ii) Die Regierung und die Polizei sollen umgehend die Unterdrückung der friedlichen, öffentlichen Versammlungen einstellen und sich beim Volk für ihr Vorgehen entschuldigen; iii) Der Nationale Volkskongress muss das „pseudo-allgemeine Wahlrecht“ zurücknehmen.
<G-vec00658-002-s185><apologize.entschuldigen><en> Of course he wouldn't apologize for criticizing Israel, he said, noting that he is, after all, a journalist.
<G-vec00658-002-s185><apologize.entschuldigen><de> Natürlich wird er sich nicht für Kritik am Staat Israel entschuldigen, er ist Journalist.
<G-vec00658-002-s186><apologize.entschuldigen><en> Just like ginseng, baikal has a list of health effects, the length of which would have a tendency to apologize, especially those from pharmaceutical companies whose drugs are the opposite of adaptogens.
<G-vec00658-002-s186><apologize.entschuldigen><de> Genau wie Ginseng hat Baikal eine Liste von gesundheitlichen Auswirkungen, deren Länge sich tendenziell entschuldigen würde, besonders jene von Pharmaunternehmen, deren Medikamente das Gegenteil von Adaptogenen sind.
<G-vec00658-002-s187><apologize.entschuldigen><en> Mohinder finds Molly still in a coma, and Bob comes to apologize to Mohinder.
<G-vec00658-002-s187><apologize.entschuldigen><de> Mohinder entdeckt, dass Molly immer noch im Koma liegt und Bob kommt, um sich zu entschuldigen.
<G-vec00658-002-s188><apologize.entschuldigen><en> Should Iraq descend into all-out civil war, there will be far more to apologize for in the decades to come. Nancy th CONGRESS 1st Session
<G-vec00658-002-s188><apologize.entschuldigen><de> Sollte der Irak in einen allgemeinen Bürgerkrieg abgleiten, dann wird es in den kommenden Jahrzehnten viel mehr geben, wofür sich die USA entschuldigen werden müssen.
<G-vec00658-002-s189><apologize.entschuldigen><en> Eventually James Wesley arrived for the meeting instead of Fisk, citing Fisk was too busy to come in person, and for that he wanted to apologize to everybody and especially Gao personally.
<G-vec00658-002-s189><apologize.entschuldigen><de> Schließlich kam James Wesley für das Treffen statt Fisk an und zitierte, dass Fisk zu beschäftigt war, um persönlich zu kommen, und dafür wollte er sich bei allen und vor allem Gao persönlich entschuldigen.
<G-vec00658-002-s190><apologize.entschuldigen><en> This is now of course not a carte blanche to be inattentive during a conversation, but it can happen and then you can mention it and apologize.
<G-vec00658-002-s190><apologize.entschuldigen><de> Das ist jetzt natürlich kein Freischein unaufmerksam im gemeinsamen Gespräch zu sein, aber es kann eben passieren und dann kann man es ja erwähnen und sich entschuldigen.
<G-vec00658-002-s191><apologize.entschuldigen><en> This way Tom can apologize to someone for you, or profess his unending love...or even sing a song.
<G-vec00658-002-s191><apologize.entschuldigen><de> So kann man sich mit Hilfe von Tom bei jemandem entschuldigen, oder seine unendliche Liebe gestehen.
<G-vec00658-002-s192><apologize.entschuldigen><en> Female smokers know how to savour the moment and will not apologize for their pleasure.
<G-vec00658-002-s192><apologize.entschuldigen><de> Weibliche Raucher wissen den Moment zu genießen und werden sich für ihr Vergnügen nicht entschuldigen.
<G-vec00658-002-s193><apologize.entschuldigen><en> Sample sentences: Ken claimed the story was untrue and refused to apologize.
<G-vec00658-002-s193><apologize.entschuldigen><de> Die Firma konnte sich das Verschwinden der Waren nicht erklären und rief an, um sich zu entschuldigen.
<G-vec00658-002-s194><apologize.entschuldigen><en> He could do this for several years until the district court sentenced him to apologize to the affected Gypsies affected by newspaper notice.
<G-vec00658-002-s194><apologize.entschuldigen><de> Er konnte dies mehrere Jahre tun, bis das Amtsgericht Sabac ihn dazu verurteilte, sich bei den betroffenen Roma per Zeitungsanzeige zu entschuldigen.
<G-vec00658-002-s195><apologize.entschuldigen><en> A good friend will apologize without being asked, once they realize you are truly upset.
<G-vec00658-002-s195><apologize.entschuldigen><de> Ein guter Freund wird sich entschuldigen, ohne darum gebeten zu werden, wenn er merkt, dass du wirklich gekränkt bist.
<G-vec00658-002-s196><apologize.entschuldigen><en> He called on the paper to apologize and not to make the same national and media mistake again.
<G-vec00658-002-s196><apologize.entschuldigen><de> Er forderte die Zeitung auf, sich zu entschuldigen und den nationalen und medialen Fehler nicht zu wiederholen.
<G-vec00658-002-s197><apologize.entschuldigen><en> According to the paper, the Israeli government had conveyed the message that the only way to defrost relations between Sweden and Israel was for Sweden to apologize for recognizing Palestine -- or if a new government came to power.
<G-vec00658-002-s197><apologize.entschuldigen><de> Nach Angaben der Zeitung hatte die israelische Regierung die Botschaft übermittelt, dass die einzige Möglichkeit die Beziehungen zwischen Schweden und Israel zu entfrosten, darin besteht, dass Schweden sich für die Anerkennung Palästinas entschuldigt - oder wenn eine neue Regierung an die Macht käme.
<G-vec00658-002-s199><apologize.entschuldigen><en> Home Page We sincerely apologize for the inconvenience.
<G-vec00658-002-s199><apologize.entschuldigen><de> Klicken Sie hier, um auf die Startseite zu gelangen und entschuldigen Sie die Unannehmlichkeiten.
<G-vec00658-002-s205><apologize.entschuldigen><en> There you have it, we’re not going to apologize for our immune systems.
<G-vec00658-002-s205><apologize.entschuldigen><de> Da habt Ihr’s, wir werden uns sicherlich nicht für unser Immunsystem entschuldigen.
<G-vec00658-002-s206><apologize.entschuldigen><en> However we would like to apologize for any resulted inconveniences due to the elevators.
<G-vec00658-002-s206><apologize.entschuldigen><de> Jedoch möchten wir uns für die Unannehmlichkeiten entschuldigen, die Ihnen durch die leeren Batterien entstanden sind.
<G-vec00658-002-s207><apologize.entschuldigen><en> If we hurt our child, it is important to take responsibility and apologize.
<G-vec00658-002-s207><apologize.entschuldigen><de> Wenn wir unser Kind kränken, ist es wichtig Verantwortung zu übernehmen und uns entschuldigen.
<G-vec00658-002-s208><apologize.entschuldigen><en> First of all, we would like to apologize for the inconveniences described.
<G-vec00658-002-s208><apologize.entschuldigen><de> Für die von Ihnen beschriebenen Unannehmlichkeiten möchten wir uns entschuldigen.
<G-vec00658-002-s209><apologize.entschuldigen><en> Why should we apologize in advance for something that has nothing to do with us?« This statement is laughable; if any band is associated with a far-right aesthetic, then it’s »Rammstein«, not »The Krupps«.
<G-vec00658-002-s209><apologize.entschuldigen><de> Warum sollten wir uns im Vorfeld für etwas entschuldigen, was mit uns gar nichts zu tun hat?« Diese Äußerung ist lachhaft: Wenn eine Band mit rechter Ästhetik assoziiert wird, dann nicht »Die Krupps«, sondern »Rammstein«.
<G-vec00658-002-s210><apologize.entschuldigen><en> We apologize for any inconvenience these issues have caused.
<G-vec00658-002-s210><apologize.entschuldigen><de> Für etwaige Unannehmlichkeiten möchten wir uns entschuldigen.
<G-vec00658-002-s211><apologize.entschuldigen><en> We know how to say thank you and we know how to apologize.
<G-vec00658-002-s211><apologize.entschuldigen><de> Wir können Danke sagen und uns entschuldigen.
<G-vec00658-002-s212><apologize.entschuldigen><en> Nevertheless, there may be inadvertent or accidental errors for which we apologize.
<G-vec00658-002-s212><apologize.entschuldigen><de> Dennoch kann es zu unbeabsichtigten und zufälligen Fehlern gekommen sein, für die wir uns entschuldigen.
<G-vec00658-002-s213><apologize.entschuldigen><en> We’d like to apologize for the unexpected goblin rampage.
<G-vec00658-002-s213><apologize.entschuldigen><de> Wir möchten uns für den unerwarteten Goblinsturm entschuldigen.
<G-vec00658-002-s218><apologize.entschuldigen><en> Resist the impulse to defend yourself or apologize.
<G-vec00658-002-s218><apologize.entschuldigen><de> Widerstehen Sie dem Impuls, sich zu verteidigen oder zu entschuldigen.
<G-vec00658-002-s025><apologize.sich_entschuldigen><en> Obama as dictator of his world empire is of course not able to afford to apologize to his slaves, and so his accomplices have to do it, and that it is exactly what Ms Merkel feels and wants to prevent, because she insists on a direct apology from the one who insulted her.
<G-vec00658-002-s025><apologize.sich_entschuldigen><de> Obama als der Diktator seines Weltreiches kann es sich natürlich nicht leisten, sich bei seinen Sklaven zu entschuldigen, und so müssen nun seine Helfershelfer es tun, und das ist es genau was Frau Merkel spürt und verhindern will, weil sie auf eine Entschuldigung direkt vom Beleidiger besteht.
<G-vec00658-002-s026><apologize.sich_entschuldigen><en> I often have the feeling that parents apologize to each other when they have clearly said “no” to the...
<G-vec00658-002-s026><apologize.sich_entschuldigen><de> Ich hab oft das Gefühl, dass sich Eltern gegenseitig beieinander entschuldigen, wenn sie dem...
<G-vec00658-002-s027><apologize.sich_entschuldigen><en> We apologize for not having done so before, but we wanted to do so with the permission of the mother superior.
<G-vec00658-002-s027><apologize.sich_entschuldigen><de> Bitte entschuldigen Sie, dass wir das nicht schon früher getan haben, aber wir wollten es mit Erlaubnis unserer Mutter Oberin tun.
<G-vec00658-002-s028><apologize.sich_entschuldigen><en> Unfortunately, I only had my smartphone, I apologize for the bad sound quality. Facebook
<G-vec00658-002-s028><apologize.sich_entschuldigen><de> Leider hatte ich nur mein Smartphone dabei, ich bitte die schlechte Tonqualität zu entschuldigen.
<G-vec00658-002-s029><apologize.sich_entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s029><apologize.sich_entschuldigen><de> Bitte entschuldigen uns für die Unannehmlichkeiten.
<G-vec00658-002-s031><apologize.sich_entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s031><apologize.sich_entschuldigen><de> Eventuelle Unannehmlichkeiten bitten wir zu entschuldigen.
<G-vec00658-002-s032><apologize.sich_entschuldigen><en> We apologize for any inconvenience it might cause you.
<G-vec00658-002-s032><apologize.sich_entschuldigen><de> Wir bitten Sie eventuelle daraus entstandene Unannehmlichkeiten zu entschuldigen.
<G-vec00658-002-s033><apologize.sich_entschuldigen><en> We apologize for this disruption.
<G-vec00658-002-s033><apologize.sich_entschuldigen><de> Wir bitten diese Störung zu entschuldigen.
<G-vec00658-002-s034><apologize.sich_entschuldigen><en> Of course we are dependent on the supplier companies, we apologize for any delays.
<G-vec00658-002-s034><apologize.sich_entschuldigen><de> Natürlich sind wir von den Lieferantenfirmen abhängig, eventuelle Verzögerungen bitten wir zu entschuldigen.
<G-vec00658-002-s035><apologize.sich_entschuldigen><en> We sincerely apologize for the inconvenience.
<G-vec00658-002-s035><apologize.sich_entschuldigen><de> Wir bitten die damit verbundenen Unannehmlichkeiten zu entschuldigen.
<G-vec00658-002-s036><apologize.sich_entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s036><apologize.sich_entschuldigen><de> Etwaige Unannehmlichkeiten bitten wir zu entschuldigen.
<G-vec00658-002-s037><apologize.sich_entschuldigen><en> We apologize for the inconveniences.
<G-vec00658-002-s037><apologize.sich_entschuldigen><de> Wir bitten dieses Ärgernis zu entschuldigen.
<G-vec00658-002-s043><apologize.sich_entschuldigen><en> A mother, a participant of CinA, wrote to her daughter during the training time to apologize for being too controlling of her.
<G-vec00658-002-s043><apologize.sich_entschuldigen><de> Eine Mutter, Teilnehmerin von CinAm, schrieb ihrer Tochter während der Zeit des Trainings, um sich dafür zu entschuldigen, dass sie sie zu sehr kontrolliere.
<G-vec00658-002-s044><apologize.sich_entschuldigen><en> Instead he proposed that the authorities of the church of Velankanni at Mumbai should publicly apologize for distributing the dirty drainage water that was dripping from the cross to hundreds of gullible people.
<G-vec00658-002-s044><apologize.sich_entschuldigen><de> Stattdessen schlug er vor, daß sich die Führung der Kirche von Velankanni in Mumbai öffentlich dafür entschuldigen sollte, daß sie schmutziges Abflußwasser, das vom Kreuz tropfte, an Hunderte von Gläubigen ausgeteilt hat.
<G-vec00658-002-s046><apologize.sich_entschuldigen><en> You have to yield, you have to sacrifice, you have to apologize if you were too greedy.
<G-vec00658-002-s046><apologize.sich_entschuldigen><de> Du musst zurückweichen, opfern und dich entschuldigen, wenn du zu gierig warst.
<G-vec00658-002-s047><apologize.sich_entschuldigen><en> Think through what happened and decide what you need to apologize for.
<G-vec00658-002-s047><apologize.sich_entschuldigen><de> Durchdenke, was passiert ist, und entscheide, wofür du dich entschuldigen musst.
<G-vec00658-002-s048><apologize.sich_entschuldigen><en> Plus, you have no reason to apologize.
<G-vec00658-002-s048><apologize.sich_entschuldigen><de> Außerdem hast du keinen Grund dafür, dich zu entschuldigen.
<G-vec00658-002-s049><apologize.sich_entschuldigen><en> And do not apologize for his "wild" behavior before strangers: you do not have to apologize.
<G-vec00658-002-s049><apologize.sich_entschuldigen><de> Und entschuldige dich nicht für sein "wildes" Verhalten vor Fremden: Du musst dich nicht entschuldigen.
<G-vec00658-002-s050><apologize.sich_entschuldigen><en> If you have many things that you need to say to the person, you may want to write out your apology before you apologize.
<G-vec00658-002-s050><apologize.sich_entschuldigen><de> Wenn du dich für viele Dinge entschuldigen willst, solltest du deine Entschuldigung vielleicht vorher aufschreiben.
<G-vec00658-002-s051><apologize.sich_entschuldigen><en> Prepare to apologize.
<G-vec00658-002-s051><apologize.sich_entschuldigen><de> Sei bereit, dich zu entschuldigen.
<G-vec00658-002-s052><apologize.sich_entschuldigen><en> Look her in the eyes when you apologize.
<G-vec00658-002-s052><apologize.sich_entschuldigen><de> Sieh ihr in die Augen, wenn du dich entschuldigst.
<G-vec00658-002-s053><apologize.sich_entschuldigen><en> Accept responsibility for your actions when you apologize.
<G-vec00658-002-s053><apologize.sich_entschuldigen><de> Übernimm die Verantwortung für deine Handlungen, wenn du dich entschuldigst.
<G-vec00658-002-s055><apologize.sich_entschuldigen><en> So, it´s better to apologize less often, otherwise the German would think that the Japanese counterpart has a guilt complex.
<G-vec00658-002-s055><apologize.sich_entschuldigen><de> Also lieber einmal weniger entschuldigen, sonst denkt der Deutsche noch, sein japanisches Gegenüber hätte einen Schuldkomplex.
<G-vec00658-002-s056><apologize.sich_entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s056><apologize.sich_entschuldigen><de> Entschuldige die Unannehmlichkeiten.
<G-vec00658-002-s057><apologize.sich_entschuldigen><en> 2 Apologize if you hurt him.
<G-vec00658-002-s057><apologize.sich_entschuldigen><de> 2 Entschuldige dich, wenn du ihn verletzt hast.
<G-vec00658-002-s058><apologize.sich_entschuldigen><en> If your co-worker says no, accept what is and apologize for any misunderstandings.
<G-vec00658-002-s058><apologize.sich_entschuldigen><de> Wenn dein Kollege nein sagt, dann akzeptiere diese Tatsache und entschuldige dich für jegliche Missverständnisse.
<G-vec00658-002-s059><apologize.sich_entschuldigen><en> Apologize to all that you had to fail them, thank everyone for your attention.
<G-vec00658-002-s059><apologize.sich_entschuldigen><de> Entschuldige dich für alles, was du zu scheitern hast, danke allen für deine Aufmerksamkeit.
<G-vec00658-002-s060><apologize.sich_entschuldigen><en> "Apologize to the man, Tung dear," Miles sang through his teeth, "and let's get on.
<G-vec00658-002-s060><apologize.sich_entschuldigen><de> »Entschuldige dich bei dem Mann, liebster Tung«, säuselte Miles zwischen zusammengebissenen Zähnen, »und dann laßt uns weitermachen.
<G-vec00658-002-s062><apologize.sich_entschuldigen><en> If you and a friend stopped talking over a meaningless dispute, call or text that friend and apologize.
<G-vec00658-002-s062><apologize.sich_entschuldigen><de> Wenn du und ein Freund wegen eines unbedeutenden Streits nicht mehr miteinander sprecht, rufe diesen Freund an oder schicke ihm eine Textnachricht und entschuldige dich.
<G-vec00658-002-s063><apologize.sich_entschuldigen><en> Mention how grateful you are to your employer and apologize for any inconveniences you caused.
<G-vec00658-002-s063><apologize.sich_entschuldigen><de> Erwähne, wie dankbar du bist, und entschuldige dich für die zusätzlichen Umstände, die du bereitet hast.
<G-vec00658-002-s064><apologize.sich_entschuldigen><en> If you do accidentally hurt her, apologize and move on.
<G-vec00658-002-s064><apologize.sich_entschuldigen><de> Wenn du sie versehentlich verletzt, entschuldige dich und macht weiter.
<G-vec00658-002-s065><apologize.sich_entschuldigen><en> If you mess it up, just give a little laugh and apologize.
<G-vec00658-002-s065><apologize.sich_entschuldigen><de> Wenn du es versaust, dann lache kurz und entschuldige dich.
<G-vec00658-002-s066><apologize.sich_entschuldigen><en> If he responds with a--potentially justified--angry text, apologize again.
<G-vec00658-002-s066><apologize.sich_entschuldigen><de> Wenn er mit einem – potentiell gerechtfertigten – wütenden Text antwortet, entschuldige dich noch einmal.
<G-vec00658-002-s067><apologize.sich_entschuldigen><en> Instead, apologize for each and every thing you did, but don’t even mention the things they did.
<G-vec00658-002-s067><apologize.sich_entschuldigen><de> Entschuldige dich stattdessen für alles und jedes, was du getan hast, ohne auch nur die Dinge zu erwähnen, die er getan hat.
<G-vec00658-002-s068><apologize.sich_entschuldigen><en> 6 Apologize. After contemplating your actions and role in the argument, apologize for any wrongdoing.
<G-vec00658-002-s068><apologize.sich_entschuldigen><de> Wenn ihr über eure Handlungen und eure Rollen im Streit nachgedacht habt, entschuldige dich für falsches Verhalten.
<G-vec00658-002-s069><apologize.sich_entschuldigen><en> If you see no way that you are able to help her fix the problem, then apologize and tell her that you cannot help her fix the problem.
<G-vec00658-002-s069><apologize.sich_entschuldigen><de> Wenn du keine Möglichkeit siehst, wie du ihr bei ihrem Problem helfen kannst, dann entschuldige dich und sage ihr, dass du ihr nicht helfen kannst.
<G-vec00658-002-s070><apologize.sich_entschuldigen><en> Apologize if you make her upset.
<G-vec00658-002-s070><apologize.sich_entschuldigen><de> Entschuldige dich, wenn du sie verärgert hast.
<G-vec00658-002-s071><apologize.sich_entschuldigen><en> Be honest, and apologize for your thoughtlessness.
<G-vec00658-002-s071><apologize.sich_entschuldigen><de> Sei ehrlich und entschuldige dich für deine Gedankenlosigkeit.
<G-vec00658-002-s072><apologize.sich_entschuldigen><en> Apologize when you hurt someone.
<G-vec00658-002-s072><apologize.sich_entschuldigen><de> Entschuldige dich, wenn du jemanden verletzt hast.
<G-vec00658-002-s073><apologize.sich_entschuldigen><en> If my description is not very clear, I apologize in advance.
<G-vec00658-002-s073><apologize.sich_entschuldigen><de> Wenn meine Beschreibung ist nicht ganz klar, ich entschuldige mich im Voraus.
<G-vec00658-002-s074><apologize.sich_entschuldigen><en> I apologize for the delayed response, but we were disrupted by the earthquake.
<G-vec00658-002-s074><apologize.sich_entschuldigen><de> Ich entschuldige mich für die verzögerte Antwort, aber wir waren durch das Erdbeben zerstört.
<G-vec00658-002-s075><apologize.sich_entschuldigen><en> I apologize to the English readers, many links lead to German news or blog sites.
<G-vec00658-002-s075><apologize.sich_entschuldigen><de> Ich entschuldige mich bei den englischen Lesern, viele Links führen zu deutschen Nachrichten oder Blog-Seiten .
<G-vec00658-002-s076><apologize.sich_entschuldigen><en> We apologize for any inconvenience and should be back up with a newly updated website soon.
<G-vec00658-002-s076><apologize.sich_entschuldigen><de> Ich entschuldige mich für jegliche Unannehmlichkeiten und hoffe auf Euer Verständnis...
<G-vec00658-002-s077><apologize.sich_entschuldigen><en> “Gentlemen, I sincerely apologize.
<G-vec00658-002-s077><apologize.sich_entschuldigen><de> „Gentlemen, ich entschuldige mich aufrichtig.
<G-vec00658-002-s078><apologize.sich_entschuldigen><en> I apologize for my inability to retrieve the proper vocabulary in the moment.
<G-vec00658-002-s078><apologize.sich_entschuldigen><de> Ich entschuldige mich für meine Unfähigkeit, im Augenblick das richtige Vokabular herauszuholen.
<G-vec00658-002-s079><apologize.sich_entschuldigen><en> Everything went fine, I apologize for my nervousness.
<G-vec00658-002-s079><apologize.sich_entschuldigen><de> Ich entschuldige mich, dass ich mit nichts helfen kann.
<G-vec00658-002-s080><apologize.sich_entschuldigen><en> Once again I apologize at you, I send bow to your poor orphans".
<G-vec00658-002-s080><apologize.sich_entschuldigen><de> Wieder entschuldige ich mich an Ihnen, ich sende Bogen Ihren armen Waisen".
<G-vec00658-002-s081><apologize.sich_entschuldigen><en> Hi there, I agree with you that we lack a bit in official communication, there are plenty justifications but I'll spare you the long read and just apologize, we will try to improve on that.
<G-vec00658-002-s081><apologize.sich_entschuldigen><de> "Hallo, ich stimme Ihnen zu, dass es uns an offizieller Kommunikation mangelt, es gibt viele Gründe, aber ich erspare Ihnen das lange Lesen und entschuldige mich, wir werden versuchen, dies zu verbessern.
<G-vec00658-002-s082><apologize.sich_entschuldigen><en> For this, I apologize.
<G-vec00658-002-s082><apologize.sich_entschuldigen><de> Für dieses entschuldige mich ich.
<G-vec00658-002-s083><apologize.sich_entschuldigen><en> I apologize and ask for forgiveness for these mistakes (pratikraman).
<G-vec00658-002-s083><apologize.sich_entschuldigen><de> Ich entschuldige mich und bitte um die Vergebung für diese Fehler (Pratikraman).
<G-vec00658-002-s084><apologize.sich_entschuldigen><en> I apologize, but, in my opinion, you are not right.
<G-vec00658-002-s084><apologize.sich_entschuldigen><de> Ich entschuldige mich, aber meiner Meinung nach sind Sie nicht recht.
<G-vec00658-002-s085><apologize.sich_entschuldigen><en> I apologize to all male-men, you are not stupid because of your gender or your hair color or the presence of hair, the cited study is absolute NONSENSE in every respect.
<G-vec00658-002-s085><apologize.sich_entschuldigen><de> Ich entschuldige mich bei allen Männern, ihr seid nicht blöd aufgrund eures Geschlechts oder eurer Haarfarbe oder des Vorhandenseins von Haaren, die zitierte Studie ist absoluter QUATSCH in jeder Beziehung.
<G-vec00658-002-s086><apologize.sich_entschuldigen><en> I apologize for my horrifying acts of violence, a reflection of my own congealed rage, my own inability to distinguish real enemies from friends.
<G-vec00658-002-s086><apologize.sich_entschuldigen><de> Ich entschuldige mich für meine verschreckenden Akte der Gewalt, eine Reflexion meiner eigenen erstarrten Wut, meiner eigenen Unfähigkeit wirkliche Freunde von Feinden zu unterscheiden.
<G-vec00658-002-s087><apologize.sich_entschuldigen><en> For the latter omission I apologize.
<G-vec00658-002-s087><apologize.sich_entschuldigen><de> Für letzteres entschuldige ich mich.
<G-vec00658-002-s088><apologize.sich_entschuldigen><en> I apologize for the mistake.
<G-vec00658-002-s088><apologize.sich_entschuldigen><de> Ich entschuldige mich für den Fehler.
<G-vec00658-002-s089><apologize.sich_entschuldigen><en> I apologize for any inconvenience.
<G-vec00658-002-s089><apologize.sich_entschuldigen><de> Ich entschuldige mich für jede entstandene Unannehmlichkeit.
<G-vec00658-002-s090><apologize.sich_entschuldigen><en> I apologize for the current silence on here but I've been so busy with planning my future.
<G-vec00658-002-s090><apologize.sich_entschuldigen><de> Ich entschuldige mich für die dezente Stille zurzeit, aber meine Zukunftsplanung ist in vollem Gange.
<G-vec00658-002-s091><apologize.sich_entschuldigen><en> I apologize for the possible translation errors.
<G-vec00658-002-s091><apologize.sich_entschuldigen><de> Ich entschuldige mich für Übersetzungsfehler.
<G-vec00658-002-s092><apologize.sich_entschuldigen><en> Before I’ll write here about craft beers I’d like to apologize to all of you. Apologize?
<G-vec00658-002-s092><apologize.sich_entschuldigen><de> Bevor ich hier über Handwerksbiere schreibe, möchte ich mich bei euch allen entschuldigen.
<G-vec00658-002-s093><apologize.sich_entschuldigen><en> Unsatisfied and undaunted, Rajkumari stood by her demand that the boy himself apologize to her and be punished for his behavior.
<G-vec00658-002-s093><apologize.sich_entschuldigen><de> Eisern und unerschrocken hielt sie an ihrer Forderung fest, dass der Junge sich persönlich bei ihr zu entschuldigen hat und er für sein Verhalten bestraft werden müsse.
<G-vec00658-002-s094><apologize.sich_entschuldigen><en> Theophilus, toward the end of the year 402, was summoned by the emperor to Constantinople to apologize before a synod, over which Chrysostom should preside, for several charges, which were brought against him by certain Egyptian monks, especially by the so-called four "tall brothers". VIII, 12) . However, Theophilus was not easily frightened.
<G-vec00658-002-s094><apologize.sich_entschuldigen><de> Theophilus, Theophilus, gegen Ende des Jahres 402, wurde durch den Kaiser berief nach Konstantinopel, um vor einer Synode zu entschuldigen, über die Chrysostomos sollte präsidieren, für mehrere Ladungen, die gegen ihn von bestimmten ägyptischen Mönche gebracht wurden, vor allem durch die sogenannten vier plötzlich gegen sie gewendet und hatte immer Agenten und Freunden in Konstantinopel, und wusste, den Stand der Dinge und die Gefühle bei dem Gericht.
<G-vec00658-002-s095><apologize.sich_entschuldigen><en> We sincerely apologize for the inconvenience.
<G-vec00658-002-s095><apologize.sich_entschuldigen><de> Wir entschuldigen die Unannehmlichkeit.
<G-vec00658-002-s096><apologize.sich_entschuldigen><en> I must apologize for my terrible German on this website.
<G-vec00658-002-s096><apologize.sich_entschuldigen><de> Ich muss für mein schreckliches Deutsch auf dieser Website entschuldigen.
<G-vec00658-002-s097><apologize.sich_entschuldigen><en> We sincerely apologize for the inconvenience.
<G-vec00658-002-s097><apologize.sich_entschuldigen><de> WIR entschuldigen für die Unannehmlichkeiten.
<G-vec00658-002-s098><apologize.sich_entschuldigen><en> We apologize for any inconvenience this may have caused players.
<G-vec00658-002-s098><apologize.sich_entschuldigen><de> Wir entschuldigen für jegliche Unannehmlichkeiten, die dadurch entstanden sind.
<G-vec00658-002-s099><apologize.sich_entschuldigen><en> Before we make our way out, Katherine says, “Christian, I really do, sincerely apologize,” she says in a soft humble tone which is contrite and heartfelt.
<G-vec00658-002-s099><apologize.sich_entschuldigen><de> Bevor wir den Raum verlassen, sagt Katherine sanft, „Christian, ich muss mich wirklich abermals bei dir entschuldigen.“ Ihre Stimme klingt reuevoll und aufrichtig.
<G-vec00658-002-s100><apologize.sich_entschuldigen><en> We do however apologize for this to our old fans that have been waiting since 2006 now (and are used to fast releases from us!) but we will make sure that it will be worth the wait!
<G-vec00658-002-s100><apologize.sich_entschuldigen><de> Natürlich entschuldigen wir uns gerade bei den die-hard Fans dafür, schließlich warten die seit 2006 auf neues Material (und normalerweise veröffentlichen wir eigentlich relativ rasch neues Material), aber wir werden dafür Sorge tragen, dass sich die lange Wartezeit definitiv lohnt.
<G-vec00658-002-s101><apologize.sich_entschuldigen><en> Giovanni manages to hustle her out and to apologize to the others for her behaviour.
<G-vec00658-002-s101><apologize.sich_entschuldigen><de> Giovanni will ihr Verhalten vor den anderen entschuldigen und drängt Elvira hinaus.
<G-vec00658-002-s102><apologize.sich_entschuldigen><en> We are apologize for the inconvenience but you need to download
<G-vec00658-002-s102><apologize.sich_entschuldigen><de> Entschuldigen Sie die Unannehmlichkeiten aber wir führen gerade Wartungsarbeiten durch.
<G-vec00658-002-s103><apologize.sich_entschuldigen><en> Then they offer me cigarettes, cheroots, and tobacco and apologize that they are only German and Algerian goods...
<G-vec00658-002-s103><apologize.sich_entschuldigen><de> Darauf bieten sie mir Zigaretten, Stumpen und Tabak an und entschuldigen sich, dass es nur deutsche und algerische Ware sei...
<G-vec00658-002-s104><apologize.sich_entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s104><apologize.sich_entschuldigen><de> Entschuldigen Sie die Unannehmlichkeit.
<G-vec00658-002-s105><apologize.sich_entschuldigen><en> Thank you for patience and apologize for the inconvenience.
<G-vec00658-002-s105><apologize.sich_entschuldigen><de> Bitte haben Sie Verständnis und entschuldigen Sie die Unannehmlichkeiten.
<G-vec00658-002-s106><apologize.sich_entschuldigen><en> I apologize for the inconvenience, gentlemen, but we are about to get a change of venue.
<G-vec00658-002-s106><apologize.sich_entschuldigen><de> Entschuldigen Sie die Unannehmlichkeit, Gentlemen, aber wir müssen den Treffpunkt verlagern.
<G-vec00658-002-s107><apologize.sich_entschuldigen><en> We apologize for any inconvenience that this procedure may cause.
<G-vec00658-002-s107><apologize.sich_entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten.
<G-vec00658-002-s108><apologize.sich_entschuldigen><en> We apologize now to all members reading this text too late and whose VPN connections were dropped.
<G-vec00658-002-s108><apologize.sich_entschuldigen><de> Wir entschuldigen uns jetzt schon bei den Mitgliedern die diesen Text zu spät lesen und vom Server geflogen sind.
<G-vec00658-002-s109><apologize.sich_entschuldigen><en> We apologize for any inconvenience and we invite you to check back shortly.
<G-vec00658-002-s109><apologize.sich_entschuldigen><de> Wir entschuldigen uns für jegliche Unannehmlichkeiten und bitten Sie, die Seite in Kürze neu zu laden.
<G-vec00658-002-s110><apologize.sich_entschuldigen><en> The page you requested cannot be found We apologize for the inconvenience.
<G-vec00658-002-s110><apologize.sich_entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten und bitten Sie, es später noch einmal zu versuchen.
<G-vec00658-002-s112><apologize.sich_entschuldigen><en> We apologize for the inconvenience, but we're performing some maintenance.
<G-vec00658-002-s112><apologize.sich_entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten und bitten Sie, es später nochmals zu versuchen.
<G-vec00658-002-s113><apologize.sich_entschuldigen><en> We apologize for the inconvenience that these causes may cause, they are totally foreign to Casa Rural Acebuchal 23.
<G-vec00658-002-s113><apologize.sich_entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten, die diese Ursachen haben können, sie sind Casa Rural Acebuchal 23 völlig fremd.
<G-vec00658-002-s115><apologize.sich_entschuldigen><en> "We apologize for any inconvenience this causes those who have tickets to shows but wish to reassure fans to hold onto these existing tickets, as they will be valid for the rescheduled dates, which will be announced shortly.
<G-vec00658-002-s115><apologize.sich_entschuldigen><de> Wir entschuldigen uns für etwaige Unannehmlichkeiten, die dazu führen, dass diejenigen, die Tickets für Shows haben, die Fans jedoch die bestehenden Tickets behalten möchten, da sie gültig sind für die neu geplanten Termine, die in Kürze bekannt gegeben werden.
<G-vec00658-002-s116><apologize.sich_entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s116><apologize.sich_entschuldigen><de> Wir entschuldigen uns fr diese Unannehmlichkeit.
<G-vec00658-002-s117><apologize.sich_entschuldigen><en> We apologize for any inconvenience this has caused.
<G-vec00658-002-s117><apologize.sich_entschuldigen><de> Wir entschuldigen uns für diese Unannehmlichkeiten.
<G-vec00658-002-s118><apologize.sich_entschuldigen><en> We apologize for the the inconvience and appreciate your patience.
<G-vec00658-002-s118><apologize.sich_entschuldigen><de> Wir entschuldigen uns für etwaige Umstände und danken Ihnen für Ihre Geduld.
<G-vec00658-002-s120><apologize.sich_entschuldigen><en> We apologize for the inconvenience.
<G-vec00658-002-s120><apologize.sich_entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten zu entschuldigen.
<G-vec00658-002-s121><apologize.sich_entschuldigen><en> For reasons of adaptation, some services such as restaurants may be adjusted, we apologize in advance.
<G-vec00658-002-s121><apologize.sich_entschuldigen><de> Aus Gründen der Anpassung können einige Dienstleistungen wie Restaurants angepasst werden, wir entschuldigen uns im Voraus.
<G-vec00658-002-s123><apologize.sich_entschuldigen><en> We apologize for any inconvenience.
<G-vec00658-002-s123><apologize.sich_entschuldigen><de> Für etwaige Unannehmlichkeiten entschuldigen wir uns.
<G-vec00658-002-s124><apologize.sich_entschuldigen><en> This site is currently under construction We apologize for the inconvenience.
<G-vec00658-002-s124><apologize.sich_entschuldigen><de> Wir entschuldigen uns für die Unannehmlichkeiten und bitte kommen Sie bald wieder.
<G-vec00658-002-s126><apologize.sich_entschuldigen><en> We apologize for the inconvenience, please try again within 15 minutes.
<G-vec00658-002-s126><apologize.sich_entschuldigen><de> Wir entschuldigen die Unannehmlichkeiten, das Angebot steht schnellst möglich wieder verfügbar.
<G-vec00658-002-s127><apologize.sich_entschuldigen><en> You apologize for your body.
<G-vec00658-002-s127><apologize.sich_entschuldigen><de> Du entschuldigst dich für deinen Körper.
<G-vec00658-002-s128><apologize.sich_entschuldigen><en> And please apologize, I am sharing too many pictures of this look…I am totally fascinated by the movement of this forte_forte silk skirt.
<G-vec00658-002-s128><apologize.sich_entschuldigen><de> Und bitte entschuldigt die unzähligen Bilder dieses Looks..ich bin so fasziniert von der Bewegung des forte_forte Seidenjupes.
<G-vec00658-002-s129><apologize.sich_entschuldigen><en> I also translated some articles from a Kopenhagen living magazine (yes, from Danish so apologize for weird words;)) and uploaded "Let it snow" article-zine.
<G-vec00658-002-s129><apologize.sich_entschuldigen><de> Außerdem hab ich einen wunderschönen Artikel über Trips im Schnee in einer Kopenhagener Wohnzeitschrift gefunden und einige Rezepte übersetzt (ja, aus dem Dänischen, also entschuldigt komische Worte) und den Artikel hochgeladen.
<G-vec00658-002-s130><apologize.sich_entschuldigen><en> We apologize for the delay but now you can vote for your favorite monsters again.
<G-vec00658-002-s130><apologize.sich_entschuldigen><de> Entschuldigt die Verzögerung, aber ab jetzt könnt ihr wieder eure Lieblingsmonster wählen.
<G-vec00658-002-s131><apologize.sich_entschuldigen><en> He doesn’t apologize, he knows he’s wrong.
<G-vec00658-002-s131><apologize.sich_entschuldigen><de> Er entschuldigt sich nicht; er weiß, dass er falsch lag.
<G-vec00658-002-s132><apologize.sich_entschuldigen><en> Later on, he did apologize to the casino's representative but that didn't change the fact that he was denied of the winnings.
<G-vec00658-002-s132><apologize.sich_entschuldigen><de> Später entschuldigte er sich beim Vertreter des Casinos, das änderte jedoch nichts an der Tatsache, dass ihm der Gewinn verweigert wurde.
<G-vec00658-002-s133><apologize.sich_entschuldigen><en> He knew it was wrong and would apologize as he was reaching out to hug a waitress or a stranger.
<G-vec00658-002-s133><apologize.sich_entschuldigen><de> Er wusste, dass das falsch war, und entschuldigte sich, wenn er die Arme ausstreckte, um eine Kellnerin oder einen Fremden zu umarmen.
<G-vec00658-002-s134><apologize.sich_entschuldigen><en> Alaric tried to apologize for not being around, but Jenna told him not to.
<G-vec00658-002-s134><apologize.sich_entschuldigen><de> Er entschuldigte sich bei Jenna, dass er nicht bei ihr sei, aber sie sagte ihm, es würde ihr nicht viel ausmachen.
<G-vec00658-002-s135><apologize.sich_entschuldigen><en> In fact, O’Reilly did apologize and allowed an exception to the organizer.
<G-vec00658-002-s135><apologize.sich_entschuldigen><de> Zwar entschuldigte sich O’Reilly und erlaubte dem Organisator eine Ausnahme.
<G-vec00658-002-s136><apologize.sich_entschuldigen><en> Some participants went to find others to apologize to them and shared their thoughts with others members of the gathering.
<G-vec00658-002-s136><apologize.sich_entschuldigen><de> Einige Teilnehmer gingen auf andere zu, entschuldigten sich und sprachen mit anderen Anwesenden über ihre Gedanken.
<G-vec00658-002-s148><apologize.sich_entschuldigen><en> He's the one that should apologize to me.
<G-vec00658-002-s148><apologize.sich_entschuldigen><de> Und wenn du mich jetzt entschuldigst.
<G-vec00658-002-s152><apologize.sich_entschuldigen><en> I clearly say that I apologize for my past to God and True Parents and love them and am proud of them.
<G-vec00658-002-s152><apologize.sich_entschuldigen><de> Ich sage klar, dass ich mich für meine Vergangenheit vor Gott und den Wahren Eltern entschuldige und dass ich sie liebe und sehr stolz auf sie bin.
<G-vec00658-002-s153><apologize.sich_entschuldigen><en> “I want to apologize for all the times I ran away from you.
<G-vec00658-002-s153><apologize.sich_entschuldigen><de> “Ich möchte mich entschuldigen für alle Zeiten von Ihnen entgangen.
<G-vec00658-002-s154><apologize.sich_entschuldigen><en> I met with David Packard and Bob Noyce and tried to apologize for screwing up so badly.
<G-vec00658-002-s154><apologize.sich_entschuldigen><de> Ich traf David Packard und Bob Noyce und versuchte, mich für mein Versagen zu entschuldigen.
<G-vec00658-002-s155><apologize.sich_entschuldigen><en> “First off, I would like to once again apologize for my actions last year,” Hunt said.
<G-vec00658-002-s155><apologize.sich_entschuldigen><de> "Zuerst möchte ich mich noch einmal für meine Handlungen im vergangenen Jahr entschuldigen.
<G-vec00658-002-s156><apologize.sich_entschuldigen><en> I would like to apologize for the non-appearance last month, unfortunately there was trouble between the German Linux-Magazin and the Brave GNU World after they had cut out a part of issue #48 [5] ("Free Software Laptops").
<G-vec00658-002-s156><apologize.sich_entschuldigen><de> Für den Ausfall letzten Monat möchte ich mich entschuldigen, leider gab es Ärger zwischen dem deutschen Linux-Magazin und der Brave GNU World, nachdem in Ausgabe 48 [5] ein Teil der Kolumne ("Freie Software Laptops") herausgeschnitten worden war.
<G-vec00658-002-s157><apologize.sich_entschuldigen><en> I (the artist) would like to take the time and apologize for the varying drawing style the readers have been experiencing for more than 500 strips.
<G-vec00658-002-s157><apologize.sich_entschuldigen><de> Ich (der Zeichner) möchte mich hier kurz für den inkonsistenten Zeichenstil entschuldigen, den die Leser über mehr als 500 Strips aushalten mussten.
<G-vec00658-002-s158><apologize.sich_entschuldigen><en> Well, I must apologize - I thought surely you were scamming me.
<G-vec00658-002-s158><apologize.sich_entschuldigen><de> Nun, ich muss mich entschuldigen - ich dachte wirklich, dass sie mich betrügen.
<G-vec00658-002-s159><apologize.sich_entschuldigen><en> For those readers who may have already discovered the pleasure, demands and inspirations of the FMP catalogue, I apologize for what might seem like wide-eyed naiveté.
<G-vec00658-002-s159><apologize.sich_entschuldigen><de> Bei den Lesern, die vielleicht schon die Freuden, Anforderungen und Inspirationen des FMP-Katalogs kennen gelernt haben, möchte ich mich für meine vielleicht blauäugige Naivität entschuldigen.
<G-vec00658-002-s160><apologize.sich_entschuldigen><en> I haven't been able to apologize, or correct, or justify, or defend, or squirm out of it, because I haven't been informed.
<G-vec00658-002-s160><apologize.sich_entschuldigen><de> Ich war nicht in der Lage, mich zu entschuldigen oder zu korrigieren oder zu rechtfertigen oder zu verteidigen oder mich herauszuwinden, weil ich nicht informiert worden bin.
<G-vec00658-002-s161><apologize.sich_entschuldigen><en> Therefore, I whish to apologize for the suffering inflicted upon the victims of these crimes in the name of science – to those who perished and have since passed away and to the ones who have survived.
<G-vec00658-002-s161><apologize.sich_entschuldigen><de> Daher möchte ich mich für das Leid entschuldigen, das den Opfern dieser Verbrechen – den toten wie den überlebenden – im Namen der Wissenschaft angetan wurde.
<G-vec00658-002-s162><apologize.sich_entschuldigen><en> I want to apologize." Tears flowed from my eyes.
<G-vec00658-002-s162><apologize.sich_entschuldigen><de> Ich möchte mich entschuldigen.“ Tränen stiegen mir in die Augen, als ich dies hörte.
<G-vec00658-002-s163><apologize.sich_entschuldigen><en> I herewith want to apologize myself to his family and his students for the wrong quotation of his name in the printed publication.
<G-vec00658-002-s163><apologize.sich_entschuldigen><de> Ich möchte mich für die fehlerhafte Nennung seines Namens in der Druckpublikation bei seiner Familie und seinen Schülern entschuldigen.
<G-vec00658-002-s164><apologize.sich_entschuldigen><en> Maybe I should apologize now that I really haven't post lately.
<G-vec00658-002-s164><apologize.sich_entschuldigen><de> Vielleicht sollte ich mich jetzt entschuldigen, dass ich nicht gepostet hab.
<G-vec00658-002-s165><apologize.sich_entschuldigen><en> I am very sorry about your check-in troubles and I would like to apologize again for your inconveniences.
<G-vec00658-002-s165><apologize.sich_entschuldigen><de> Für Ihre Unannehmlichkeiten mit der Zimmerreinigung möchte ich mich in aller Form entschuldigen und ich werde die Reinigugsprozedur umgehend mit meiner Hausdame anschauen.
<G-vec00658-002-s166><apologize.sich_entschuldigen><en> I would like to recognize and apologize for the mistreatment of German Prisoners of War held by the United States, in Germany and France, from 1945 to 1946.
<G-vec00658-002-s166><apologize.sich_entschuldigen><de> Ich moechte die Misshandlung deutscher Kriegsgefangener im Gewarsam der Vereinigten Staaten in Deutschland und Frankreich von 1945 bis 1946 eingestehen und mich dafuer entschuldigen.
<G-vec00658-002-s167><apologize.sich_entschuldigen><en> Since the batch of corrected proofs that I sent on November 29 should by now have reached you, I take this opportunity to apologize for the recent incorporation of new material, and the so-to-speak last-minute, somewhat reduced speed of completion of the half-volume that has resulted from this.
<G-vec00658-002-s167><apologize.sich_entschuldigen><de> 1 Die Absendung der Korrektur, die am 29/11 bei Ihnen eingetroffen sein dürfte, nehme ich zur Veranlassung, mich wegen der neuerlichen Einschaltung, u. des gleichsam in letzter Stunde dadurch etwas verzögerten Tempo in der Fertigstellung des Halbbands zu entschuldigen.
<G-vec00658-002-s171><apologize.sich_entschuldigen><en> We apologize for the inconveniences.
<G-vec00658-002-s171><apologize.sich_entschuldigen><de> Wir möchten die Unannehmlichkeiten entschuldigen.
<G-vec00658-002-s176><apologize.sich_entschuldigen><en> From Munich he wrote Fritz to apologize for not answering the boy's letter sooner for lack of anything important to say.
<G-vec00658-002-s176><apologize.sich_entschuldigen><de> Von München schrieb er an Fritz, er möge entschuldigen, dass er den Brief des Knaben nicht früher beantwortet habe, da es nichts Wichtiges mitzuteilen gebe.
<G-vec00658-002-s177><apologize.sich_entschuldigen><en> Cassie is made to address a white child as if she were superior to her and to apologize for something that wasn't her fault.
<G-vec00658-002-s177><apologize.sich_entschuldigen><de> Cassie wird gemacht, um ein weißes Kind anzusprechen, als ob sie überlegen sei und sich für etwas entschuldige, das nicht ihre Schuld war.
<G-vec00658-002-s178><apologize.sich_entschuldigen><en> He tried to apologize, but Annabeth and I were too busy cracking up.
<G-vec00658-002-s178><apologize.sich_entschuldigen><de> Er wollte sich entschuldigen, aber Annabeth und ich schüttelten uns vor Lachen.
<G-vec00658-002-s179><apologize.sich_entschuldigen><en> And much more: Colonization, colonialism, and coloniality are facts; therefore, the King of Spain must apologize.
<G-vec00658-002-s179><apologize.sich_entschuldigen><de> Zudem: Kolonisation, Kolonialismus und Kolonialität sind Fakten, daher müsse sich der spanische König entschuldigen.
<G-vec00658-002-s180><apologize.sich_entschuldigen><en> Strache urged the president to apologize and criticized him for his further trivialization of National Socialism.
<G-vec00658-002-s180><apologize.sich_entschuldigen><de> Weiters forderte Strache den Präsidenten dazu auf sich zu entschuldigen und kritisierte ihn für seine Verharmlosung des Nationalsozialismus.
<G-vec00658-002-s181><apologize.sich_entschuldigen><en> 'I'll Be Your Man' is about a broken relationship; the man wants to apologize for the past and is so desperate that he prays to god to get his loved one back.
<G-vec00658-002-s181><apologize.sich_entschuldigen><de> In I'll Be Your Man geht es um eine zerbrochene Beziehung; der Mann möchte sich für die Vergangenheit entschuldigen und ist so verzweifelt, dass er zu Gott betet um seine Geliebte zurückerobern zu können.
<G-vec00658-002-s182><apologize.sich_entschuldigen><en> Too many financial types, arrogant people who bump into you because they’re staring at their cell phones and then don’t bother to apologize.
<G-vec00658-002-s182><apologize.sich_entschuldigen><de> Zu viele Finanztypen, unverschämte Leute, die dichanrempeln, weil sie nur auf ihre Handys glotzen, und sich nicht entschuldigen.
<G-vec00658-002-s183><apologize.sich_entschuldigen><en> Therefore he advises it to apologize to the grandfather and to make with it the peace.
<G-vec00658-002-s183><apologize.sich_entschuldigen><de> Deshalb berät er ihm, sich vor dem Großvater zu entschuldigen und, mit ihm der Frieden zu schließen.
<G-vec00658-002-s184><apologize.sich_entschuldigen><en> They must guarantee the basic human rights of the arrested protestors during retention; ii) The government and police must stop suppressing the peaceful assembly and apologize to the people; iii) National People’s Congress must withdraw the ‘fake universal suffrage’.
<G-vec00658-002-s184><apologize.sich_entschuldigen><de> Sämtliche Menschenrechte müssen für die verhafteten AktivistInnen für die gesamte Dauer der Festnahme gewährleistet werden; ii) Die Regierung und die Polizei sollen umgehend die Unterdrückung der friedlichen, öffentlichen Versammlungen einstellen und sich beim Volk für ihr Vorgehen entschuldigen; iii) Der Nationale Volkskongress muss das „pseudo-allgemeine Wahlrecht“ zurücknehmen.
<G-vec00658-002-s185><apologize.sich_entschuldigen><en> Of course he wouldn't apologize for criticizing Israel, he said, noting that he is, after all, a journalist.
<G-vec00658-002-s185><apologize.sich_entschuldigen><de> Natürlich wird er sich nicht für Kritik am Staat Israel entschuldigen, er ist Journalist.
<G-vec00658-002-s186><apologize.sich_entschuldigen><en> Just like ginseng, baikal has a list of health effects, the length of which would have a tendency to apologize, especially those from pharmaceutical companies whose drugs are the opposite of adaptogens.
<G-vec00658-002-s186><apologize.sich_entschuldigen><de> Genau wie Ginseng hat Baikal eine Liste von gesundheitlichen Auswirkungen, deren Länge sich tendenziell entschuldigen würde, besonders jene von Pharmaunternehmen, deren Medikamente das Gegenteil von Adaptogenen sind.
<G-vec00658-002-s187><apologize.sich_entschuldigen><en> Mohinder finds Molly still in a coma, and Bob comes to apologize to Mohinder.
<G-vec00658-002-s187><apologize.sich_entschuldigen><de> Mohinder entdeckt, dass Molly immer noch im Koma liegt und Bob kommt, um sich zu entschuldigen.
<G-vec00658-002-s188><apologize.sich_entschuldigen><en> Should Iraq descend into all-out civil war, there will be far more to apologize for in the decades to come. Nancy th CONGRESS 1st Session
<G-vec00658-002-s188><apologize.sich_entschuldigen><de> Sollte der Irak in einen allgemeinen Bürgerkrieg abgleiten, dann wird es in den kommenden Jahrzehnten viel mehr geben, wofür sich die USA entschuldigen werden müssen.
<G-vec00658-002-s189><apologize.sich_entschuldigen><en> Eventually James Wesley arrived for the meeting instead of Fisk, citing Fisk was too busy to come in person, and for that he wanted to apologize to everybody and especially Gao personally.
<G-vec00658-002-s189><apologize.sich_entschuldigen><de> Schließlich kam James Wesley für das Treffen statt Fisk an und zitierte, dass Fisk zu beschäftigt war, um persönlich zu kommen, und dafür wollte er sich bei allen und vor allem Gao persönlich entschuldigen.
<G-vec00658-002-s190><apologize.sich_entschuldigen><en> This is now of course not a carte blanche to be inattentive during a conversation, but it can happen and then you can mention it and apologize.
<G-vec00658-002-s190><apologize.sich_entschuldigen><de> Das ist jetzt natürlich kein Freischein unaufmerksam im gemeinsamen Gespräch zu sein, aber es kann eben passieren und dann kann man es ja erwähnen und sich entschuldigen.
<G-vec00658-002-s191><apologize.sich_entschuldigen><en> This way Tom can apologize to someone for you, or profess his unending love...or even sing a song.
<G-vec00658-002-s191><apologize.sich_entschuldigen><de> So kann man sich mit Hilfe von Tom bei jemandem entschuldigen, oder seine unendliche Liebe gestehen.
<G-vec00658-002-s192><apologize.sich_entschuldigen><en> Female smokers know how to savour the moment and will not apologize for their pleasure.
<G-vec00658-002-s192><apologize.sich_entschuldigen><de> Weibliche Raucher wissen den Moment zu genießen und werden sich für ihr Vergnügen nicht entschuldigen.
<G-vec00658-002-s193><apologize.sich_entschuldigen><en> Sample sentences: Ken claimed the story was untrue and refused to apologize.
<G-vec00658-002-s193><apologize.sich_entschuldigen><de> Die Firma konnte sich das Verschwinden der Waren nicht erklären und rief an, um sich zu entschuldigen.
<G-vec00658-002-s194><apologize.sich_entschuldigen><en> He could do this for several years until the district court sentenced him to apologize to the affected Gypsies affected by newspaper notice.
<G-vec00658-002-s194><apologize.sich_entschuldigen><de> Er konnte dies mehrere Jahre tun, bis das Amtsgericht Sabac ihn dazu verurteilte, sich bei den betroffenen Roma per Zeitungsanzeige zu entschuldigen.
<G-vec00658-002-s195><apologize.sich_entschuldigen><en> A good friend will apologize without being asked, once they realize you are truly upset.
<G-vec00658-002-s195><apologize.sich_entschuldigen><de> Ein guter Freund wird sich entschuldigen, ohne darum gebeten zu werden, wenn er merkt, dass du wirklich gekränkt bist.
<G-vec00658-002-s196><apologize.sich_entschuldigen><en> He called on the paper to apologize and not to make the same national and media mistake again.
<G-vec00658-002-s196><apologize.sich_entschuldigen><de> Er forderte die Zeitung auf, sich zu entschuldigen und den nationalen und medialen Fehler nicht zu wiederholen.
<G-vec00658-002-s197><apologize.sich_entschuldigen><en> According to the paper, the Israeli government had conveyed the message that the only way to defrost relations between Sweden and Israel was for Sweden to apologize for recognizing Palestine -- or if a new government came to power.
<G-vec00658-002-s197><apologize.sich_entschuldigen><de> Nach Angaben der Zeitung hatte die israelische Regierung die Botschaft übermittelt, dass die einzige Möglichkeit die Beziehungen zwischen Schweden und Israel zu entfrosten, darin besteht, dass Schweden sich für die Anerkennung Palästinas entschuldigt - oder wenn eine neue Regierung an die Macht käme.
<G-vec00658-002-s199><apologize.sich_entschuldigen><en> Home Page We sincerely apologize for the inconvenience.
<G-vec00658-002-s199><apologize.sich_entschuldigen><de> Klicken Sie hier, um auf die Startseite zu gelangen und entschuldigen Sie die Unannehmlichkeiten.
<G-vec00658-002-s205><apologize.sich_entschuldigen><en> There you have it, we’re not going to apologize for our immune systems.
<G-vec00658-002-s205><apologize.sich_entschuldigen><de> Da habt Ihr’s, wir werden uns sicherlich nicht für unser Immunsystem entschuldigen.
<G-vec00658-002-s206><apologize.sich_entschuldigen><en> However we would like to apologize for any resulted inconveniences due to the elevators.
<G-vec00658-002-s206><apologize.sich_entschuldigen><de> Jedoch möchten wir uns für die Unannehmlichkeiten entschuldigen, die Ihnen durch die leeren Batterien entstanden sind.
<G-vec00658-002-s207><apologize.sich_entschuldigen><en> If we hurt our child, it is important to take responsibility and apologize.
<G-vec00658-002-s207><apologize.sich_entschuldigen><de> Wenn wir unser Kind kränken, ist es wichtig Verantwortung zu übernehmen und uns entschuldigen.
<G-vec00658-002-s208><apologize.sich_entschuldigen><en> First of all, we would like to apologize for the inconveniences described.
<G-vec00658-002-s208><apologize.sich_entschuldigen><de> Für die von Ihnen beschriebenen Unannehmlichkeiten möchten wir uns entschuldigen.
<G-vec00658-002-s209><apologize.sich_entschuldigen><en> Why should we apologize in advance for something that has nothing to do with us?« This statement is laughable; if any band is associated with a far-right aesthetic, then it’s »Rammstein«, not »The Krupps«.
<G-vec00658-002-s209><apologize.sich_entschuldigen><de> Warum sollten wir uns im Vorfeld für etwas entschuldigen, was mit uns gar nichts zu tun hat?« Diese Äußerung ist lachhaft: Wenn eine Band mit rechter Ästhetik assoziiert wird, dann nicht »Die Krupps«, sondern »Rammstein«.
<G-vec00658-002-s210><apologize.sich_entschuldigen><en> We apologize for any inconvenience these issues have caused.
<G-vec00658-002-s210><apologize.sich_entschuldigen><de> Für etwaige Unannehmlichkeiten möchten wir uns entschuldigen.
<G-vec00658-002-s211><apologize.sich_entschuldigen><en> We know how to say thank you and we know how to apologize.
<G-vec00658-002-s211><apologize.sich_entschuldigen><de> Wir können Danke sagen und uns entschuldigen.
<G-vec00658-002-s212><apologize.sich_entschuldigen><en> Nevertheless, there may be inadvertent or accidental errors for which we apologize.
<G-vec00658-002-s212><apologize.sich_entschuldigen><de> Dennoch kann es zu unbeabsichtigten und zufälligen Fehlern gekommen sein, für die wir uns entschuldigen.
<G-vec00658-002-s213><apologize.sich_entschuldigen><en> We’d like to apologize for the unexpected goblin rampage.
<G-vec00658-002-s213><apologize.sich_entschuldigen><de> Wir möchten uns für den unerwarteten Goblinsturm entschuldigen.
<G-vec00658-002-s218><apologize.sich_entschuldigen><en> Resist the impulse to defend yourself or apologize.
<G-vec00658-002-s218><apologize.sich_entschuldigen><de> Widerstehen Sie dem Impuls, sich zu verteidigen oder zu entschuldigen.
