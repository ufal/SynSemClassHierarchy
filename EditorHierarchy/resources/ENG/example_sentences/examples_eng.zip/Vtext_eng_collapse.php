<G-vec00597-002-s030><collapse.(sich)_brechen><en> So the inversion of an image in which an ideology consists is given its philosophical and media-technological concept – or its media-technological monument, as in the end medium and monument coincide in the Berlin Wall (and its fall): after all, it isn’t just any old monument that here serves as a camera to create inverted images; the wall is the ideological monument, upon which world images collapse.
<G-vec00597-002-s030><collapse.(sich)_brechen><de> Die Verkehrung eines Bildes, in der eine Ideologie besteht, wird also auf seinen philosophischen und medientechnischen Begriff gebracht – oder auf sein medientechnisches Monument, denn schließlich fallen Medium und Monument im Fall der Mauer (und seit dem Mauerfall) zusammen: Schließlich ist die Mauer nicht irgendein Monument, das hier als Camera dient, um umgedrehte Bilder zu erzeugen; die Mauer ist von sich aus bereits das ideologische Monument, an dem sich die Weltbilder brechen.
<G-vec00597-002-s031><collapse.(sich)_brechen><en> The freezing cold, dark mineshafts regularly collapse and bury the workers, many of them still children, alive.
<G-vec00597-002-s031><collapse.(sich)_brechen><de> Regelmäßig brechen die eiskalten, dunklen Minenschächte ein und begraben die Arbeiter, viele davon noch Kinder, bei lebendigem Leibe.
<G-vec00597-002-s032><collapse.(sich)_brechen><en> This is where so-called gravity waves frequently collapse, releasing momentum and energy which influence atmospheric circulation.
<G-vec00597-002-s032><collapse.(sich)_brechen><de> Hier brechen häufig die sogenannten Schwerewellen, deren Impuls und Energie die Zirkulation der Atmosphäre beeinflussen.
<G-vec00597-002-s033><collapse.(sich)_brechen><en> But if the financial system’s dykes collapse, we may be headed for a decade of severe deflation, rendering expansionary stimulus useless.
<G-vec00597-002-s033><collapse.(sich)_brechen><de> Doch wenn die Dämme des Finanzsystems brechen, kann uns ein Jahrzehnt der schweren Deflation bevorstehen, was Expansionsimpulse sinnlos macht.
<G-vec00597-002-s034><collapse.(sich)_brechen><en> And these loads lead to the fact that dogs begin to collapse joints.
<G-vec00597-002-s034><collapse.(sich)_brechen><de> Diese Belastungen führen dazu, dass die Hunde Gelenke beginnen zu brechen.
<G-vec00597-002-s025><collapse.ausblenden><en> Tip: On desktop, you can collapse any image by clicking the down arrow next to the image title, or type the /collapse slash command to collapse all media in a channel. Awesome!
<G-vec00597-002-s025><collapse.ausblenden><de> Tipp: Auf dem Desktop kannst du jedes Bild ausblenden, indem du auf den Abwärtspfeil neben dem Bildtitel klickst oder den Slash-Befehl /collapse eingibst, damit alle Medien in einem Channel ausgeblendet werden.
<G-vec00597-002-s026><collapse.ausblenden><en> You can now collapse code by hovering your mouse over the line number and clicking the triangle that appears.
<G-vec00597-002-s026><collapse.ausblenden><de> Sie können jetzt Code ausblenden, indem Sie mit der Maus auf die Zeilennummer zeigen und auf das angezeigte Dreieck klicken.
<G-vec00597-002-s027><collapse.ausblenden><en> Users can also expand and collapse categories which contain many subcategories.
<G-vec00597-002-s027><collapse.ausblenden><de> Benutzer können Kategorien mit vielen Unterkategorien nach Bedarf ein- und ausblenden.
<G-vec00597-002-s028><collapse.ausblenden><en> To collapse all the profile groups in Profile Browser, right-click (Win) / Control-click (Mac) any profile group and choose Collapse All from the menu.
<G-vec00597-002-s028><collapse.ausblenden><de> Zum Ausblenden aller Profilgruppen im Profil-Browser klicken Sie mit der rechten Maustaste (Windows) oder bei gedrückter Ctrl-Taste (Mac) auf eine beliebige Profilgruppe und wählen Sie Alle minimieren im Menü aus.
<G-vec00597-002-s029><collapse.ausblenden><en> If you collapse the timer, you won't see the color changes.
<G-vec00597-002-s029><collapse.ausblenden><de> Wenn Sie den Timer ausblenden, sehen Sie die Farbänderung nicht.
<G-vec00597-002-s030><collapse.brechen><en> So the inversion of an image in which an ideology consists is given its philosophical and media-technological concept – or its media-technological monument, as in the end medium and monument coincide in the Berlin Wall (and its fall): after all, it isn’t just any old monument that here serves as a camera to create inverted images; the wall is the ideological monument, upon which world images collapse.
<G-vec00597-002-s030><collapse.brechen><de> Die Verkehrung eines Bildes, in der eine Ideologie besteht, wird also auf seinen philosophischen und medientechnischen Begriff gebracht – oder auf sein medientechnisches Monument, denn schließlich fallen Medium und Monument im Fall der Mauer (und seit dem Mauerfall) zusammen: Schließlich ist die Mauer nicht irgendein Monument, das hier als Camera dient, um umgedrehte Bilder zu erzeugen; die Mauer ist von sich aus bereits das ideologische Monument, an dem sich die Weltbilder brechen.
<G-vec00597-002-s031><collapse.brechen><en> The freezing cold, dark mineshafts regularly collapse and bury the workers, many of them still children, alive.
<G-vec00597-002-s031><collapse.brechen><de> Regelmäßig brechen die eiskalten, dunklen Minenschächte ein und begraben die Arbeiter, viele davon noch Kinder, bei lebendigem Leibe.
<G-vec00597-002-s032><collapse.brechen><en> This is where so-called gravity waves frequently collapse, releasing momentum and energy which influence atmospheric circulation.
<G-vec00597-002-s032><collapse.brechen><de> Hier brechen häufig die sogenannten Schwerewellen, deren Impuls und Energie die Zirkulation der Atmosphäre beeinflussen.
<G-vec00597-002-s033><collapse.brechen><en> But if the financial system’s dykes collapse, we may be headed for a decade of severe deflation, rendering expansionary stimulus useless.
<G-vec00597-002-s033><collapse.brechen><de> Doch wenn die Dämme des Finanzsystems brechen, kann uns ein Jahrzehnt der schweren Deflation bevorstehen, was Expansionsimpulse sinnlos macht.
<G-vec00597-002-s034><collapse.brechen><en> And these loads lead to the fact that dogs begin to collapse joints.
<G-vec00597-002-s034><collapse.brechen><de> Diese Belastungen führen dazu, dass die Hunde Gelenke beginnen zu brechen.
<G-vec00597-002-s066><collapse.einbrechen><en> Although there is no limestone on Mars, other solution processes could lead to the formation of similar cavities; here, as with lava tubes, parts of the tunnel ceiling ultimately collapse, generating a row of sinkholes.
<G-vec00597-002-s066><collapse.einbrechen><de> Auch wenn es auf dem Mars keine Kalkgebirge gibt, könnten Lösungsprozesse zu ähnlicher Hohlraumbildung führen und anschließend, wie bei den Lavaröhren, Teile der Tunneldecke einbrechen und eine Reihe von Absenkungstrichtern bilden.
<G-vec00597-002-s067><collapse.einbrechen><en> Scientists are taking it for granted that should the flow of the Gulf Stream collapse seriously, this would lead to a worldwide climate change and massive cooling of the world´s climate".
<G-vec00597-002-s067><collapse.einbrechen><de> Wissenschaftler gehen davon aus, das, würde die Strömung des Golfstroms stark einbrechen, dies zu einer weltweiten Klimaverschiebung und massiven Abkühlung des Weltklimas führen würde".
<G-vec00597-002-s068><collapse.einbrechen><en> On Wednesday, Airbus CEO Thomas Enders warned that, were that to happen, Germany's aircraft industry would "collapse".
<G-vec00597-002-s068><collapse.einbrechen><de> Airbus Direktor Thomas Enders hat soeben gewarnt, dass wenn das passieren sollte, würde Deutschlands Flugzeug-Industrie einbrechen.
<G-vec00597-002-s069><collapse.einbrechen><en> In contrast, domestic institutional investors today are far more prevalent in many domestic markets, and often act as a stabilizing force when asset prices collapse by stepping in to buy assets when foreign investors may be fleeing them.
<G-vec00597-002-s069><collapse.einbrechen><de> Dagegen sind inländische institutionelle Anleger an vielen inländischen Märkten mittlerweile viel präsenter und wirken häufig als stabilisierende Kraft, wenn die Kurse von Vermögenswerten einbrechen, indem sie einspringen und Vermögenswerte kaufen, wenn ausländische Anleger daraus fliehen.
<G-vec00597-002-s070><collapse.einbrechen><en> As public debt grew, the government's only hope of paying it back was a deflationary clampdown on available money and credit--with a collapse in output, soaring unemployment, and civil disorder almost inevitable.
<G-vec00597-002-s070><collapse.einbrechen><de> Die einzige Hoffnung der Regierung, die wachsenden Staatsschulden zurückzahlen zu können war es, Barauszahlungen und Krediten einen deflationistischen Riegel vorzuschieben - ein Einbrechen der Produktionsleistung, der sprunghafte Anstieg der Arbeitslosigkeit und zivile Unruhen waren so fast unvermeidbar.
<G-vec00597-002-s071><collapse.einbrechen><en> However, if the oil price were to collapse (back to the U.S. $30 range), the recovery could falter.
<G-vec00597-002-s071><collapse.einbrechen><de> Sollten jedoch die Ölnotierungen einbrechen (wieder auf das Niveau von rund 30 US-Dollar), könnte der Aufschwung ins Stocken geraten.
<G-vec00597-002-s072><collapse.einbrechen><en> I assume the number of passengers will collapse after the new road is opened.
<G-vec00597-002-s072><collapse.einbrechen><de> I vermute, dass nach der Eröffnung der Straße die Zahl der Passagiere einbrechen wird.
<G-vec00597-002-s141><collapse.einstürzen><en> As early as 2014 cultural historians sounded the alarm that the Acropolis was on the verge of collapse....
<G-vec00597-002-s141><collapse.einstürzen><de> Schon 2014 schlugen Kunsthistoriker Alarm, die Akropolis drohe einzustürzen....
<G-vec00597-002-s142><collapse.einstürzen><en> It is especially necessary to watch out for balconies which tend to collapse first.
<G-vec00597-002-s142><collapse.einstürzen><de> Man muss besonders bei Balkons aufpassen, da sie dazu neigen, zuerst einzustürzen.
<G-vec00597-002-s143><collapse.einstürzen><en> As law enforcers Jordan slowly come to terms, his entire house of cards threatens to collapse. Watch film now
<G-vec00597-002-s143><collapse.einstürzen><de> Als die Gesetzeshüter ihm langsam auf die Schliche kommen, droht sein gesamtes Kartenhaus einzustürzen...
<G-vec00597-002-s144><collapse.einstürzen><en> In Medjugorje, the communist East has begun to collapse.
<G-vec00597-002-s144><collapse.einstürzen><de> In Medjugorje begann der kommunistische Osten einzustürzen.
<G-vec00597-002-s145><collapse.einstürzen><en> Some attempts at mining amber were tried, but the shafts and tunnels in the areas near the amber beaches were prone to collapse and this initial attempt at amber mining was not successful.
<G-vec00597-002-s145><collapse.einstürzen><de> Einige Versuche am Bergbaubernstein wurden versucht, aber die Wellen und die Tunnels in den Bereichen nahe den bernsteinfarbigen Stränden waren vornübergeneigt einzustürzen und dieser Anfangsversuch am bernsteinfarbigen Bergbau war nicht erfolgreich.
<G-vec00597-002-s146><collapse.einstürzen><en> Large boulders block the way on a regular basis and threaten to collapse at every earthquake.
<G-vec00597-002-s146><collapse.einstürzen><de> Große Felsblöcke versperren regelmäßig den Weg und drohen bei jedem Erdbeben einzustürzen.
<G-vec00597-002-s147><collapse.einstürzen><en> By this, too, he gains endlessly, he gains, in that the foundation of his legislation is true, so that a future reformer need not collapse the basic edifice of the constitution if he undertakes improvements of conceptions, which are the inevitable consequence in all false religions, as soon as the torch of Reason sheds its light upon them.
<G-vec00597-002-s147><collapse.einstürzen><de> Und dadurch gewinnt er schon unendlich, er gewinnt – daß der Grund seiner Gesetzgebung wahr ist, daß also ein künftiger Reformator die Grundverfassung nicht einzustürzen braucht, wenn er die Begriffe verbessert, welches bei allen falschen Religionen die unausbleibliche Folge ist, sobald die Fackel der Vernunft sie beleuchtet.
<G-vec00597-002-s198><collapse.kollabieren><en> The collapse of the probability distribution in this case takes place at the very end when the probability distribution reaches the screen because that's when a measurement is taken and the rendering produces a pattern on the screen according to the interference pattern of the probability distribution.
<G-vec00597-002-s198><collapse.kollabieren><de> Die Wahrscheinlichkeitsverteilung kollabiert in diesem Fall erst in dem Moment, wo sie auf den Schirm trifft, denn dann findet eine Messung statt und die auf den Schirm treffende Verteilung zeigt dann ein Interferenzmuster auf, was zu einem Muster aus hellen und dunklen Streifen auf dem Schirm führt.
<G-vec00597-002-s199><collapse.kollabieren><en> The cover floats on the surface of the water and will not collapse under the water if fallen on.
<G-vec00597-002-s199><collapse.kollabieren><de> Die Abdeckung schwimmt auf der Oberfläche des Wassers und kollabiert nicht unter dem Wasser, wenn sie darauf fällt.
<G-vec00597-002-s200><collapse.kollabieren><en> The fusion of the appropriate vesicles with the correct target membrane is of outmost importance, otherwise the cell will lose its compartmentalisation and collapse.
<G-vec00597-002-s200><collapse.kollabieren><de> Die korrekte Fusion der einzelnen Vesikel mit der entsprechenden Organelle ist von höchster Wichtigkeit, ansonsten verliert die Zelle ihre Kompartimentierung und kollabiert.
<G-vec00597-002-s201><collapse.kollabieren><en> The tent comes with very sturdy 9mm DAC poles, which will provide the necessary stability so that the tent wont collapse as a result of strong winds.
<G-vec00597-002-s201><collapse.kollabieren><de> Damit das Zelt auch bei starkem Wind nicht kollabiert, sorgt ein stabiles und robustes 9mm DAC Gestänge für die nötige Stabilität.
<G-vec00597-002-s227><collapse.minimieren><en> To collapse all the profile groups in Profile Browser, right-click (Win) / Control-click (Mac) any profile group and choose Collapse All from the menu.
<G-vec00597-002-s227><collapse.minimieren><de> Zum Ausblenden aller Profilgruppen im Profil-Browser klicken Sie mit der rechten Maustaste (Windows) oder bei gedrückter Ctrl-Taste (Mac) auf eine beliebige Profilgruppe und wählen Sie Alle minimieren im Menü aus.
<G-vec00597-002-s228><collapse.minimieren><en> Once you're done with your selections, click the hamburger icon once more to collapse the menu.
<G-vec00597-002-s228><collapse.minimieren><de> Wenn du die Auswahl abgeschlossen hast, klicke noch einmal auf das Hamburger-Symbol, um das Menü zu minimieren.
<G-vec00597-002-s229><collapse.minimieren><en> Click the arrow next to a folder to expand or collapse it.
<G-vec00597-002-s229><collapse.minimieren><de> Klicken Sie auf den Pfeil neben einem Ordner, um diesen zu erweitern oder zu minimieren.
<G-vec00597-002-s230><collapse.minimieren><en> All expanding creatives types should include a way to collapse the creative.
<G-vec00597-002-s230><collapse.minimieren><de> Alle Expandable-Creatives müssen einen Möglichkeit zum Minimieren des Creative aufweisen.
<G-vec00597-002-s242><collapse.platzen><en> That misunderstanding encouraged people to buy homes for their investment value – and thus was a major cause of the real estate bubbles around the world whose collapse fueled the current economic crisis.
<G-vec00597-002-s242><collapse.platzen><de> Dieses Missverständnis ermunterte die Leute, Häuser und Wohnungen als Kapitalanlage zu kaufen, und war daher ein wichtiger Grund für die Immobilienblasen überall auf der Welt, deren Platzen die gegenwärtige Wirtschaftskrise anheizte.
<G-vec00597-002-s243><collapse.platzen><en> This is the reason why the FDP withdrew from the Jamaica coalition talks, causing them to collapse.
<G-vec00597-002-s243><collapse.platzen><de> Das ist der Grund, weshalb die FDP die Jamaika-Verhandlungen hat platzen lassen.
<G-vec00597-002-s244><collapse.platzen><en> The collapse of the equity bubble calls that effort into serious question.
<G-vec00597-002-s244><collapse.platzen><de> Durch das Platzen der Aktienblase werden diese Bemühungen nun ernsthaft in Frage gestellt.
<G-vec00597-002-s245><collapse.platzen><en> After pushing the federal funds rate to a 45-year low of 1% following the collapse of the equity bubble of the early 2000s, the Fed delayed policy normalization for an inordinately long period.
<G-vec00597-002-s245><collapse.platzen><de> Nachdem sie nach dem Platzen der Anlageblase der frühen 2000er Jahre die Federal Funds Rate auf ein 45-Jahres-Tief von 1% gesetzt hatte, verzögerte die Fed die Normalisierung ihrer Politik übermäßig lang.
<G-vec00597-002-s246><collapse.platzen><en> Other economic shocks, such as high energy prices, the US subprime mortgage crisis in 2007 or the collapse of the dot-com bubble in 2000 often play a role.
<G-vec00597-002-s246><collapse.platzen><de> Andere Wirtschaftsschocks, wie etwa hohe Energiepreise, die US-Subprime-Krise von 2007 oder das Platzen der Dotcom-Blase im Jahr 2000, spielen dabei oft eine Rolle.
<G-vec00597-002-s247><collapse.reduzieren><en> You can click the collapse/expand icon to view other columns in the table.
<G-vec00597-002-s247><collapse.reduzieren><de> Klicken Sie zum Anzeigen der anderen Spalten in der Tabelle auf das Symbol „Reduzieren/Erweitern“.
<G-vec00597-002-s248><collapse.reduzieren><en> Click here to collapse or expend the section
<G-vec00597-002-s248><collapse.reduzieren><de> Klicken Sie hier, um den Abschnitt zu reduzieren oder zu erweitern.
<G-vec00597-002-s249><collapse.reduzieren><en> Press Enter again to collapse all sections.
<G-vec00597-002-s249><collapse.reduzieren><de> Durch erneutes Drücken der EINGABETASTE reduzieren Sie alle Abschnitte.
<G-vec00597-002-s250><collapse.reduzieren><en> Expand/Collapse: The Content column in the rule list displays the rule content.
<G-vec00597-002-s250><collapse.reduzieren><de> Anzeigen/Reduzieren:Die Inhaltsspalte in der Regelliste zeigt den Regelinhalt an.
<G-vec00597-002-s251><collapse.reduzieren><en> Collapse or expand a note: Double-click the title bar.
<G-vec00597-002-s251><collapse.reduzieren><de> Notiz reduzieren oder erweitern: Doppelklicke auf die Titelleiste.
<G-vec00597-002-s252><collapse.reduzieren><en> To collapse the key, click the minus sign.
<G-vec00597-002-s252><collapse.reduzieren><de> Klicken Sie auf das Minuszeichen, um den Schlüssel zu reduzieren.
<G-vec00597-002-s253><collapse.reduzieren><en> Administrators can scroll through the list of servers and expand or collapse the view to display DirectAccess and VPN server components.
<G-vec00597-002-s253><collapse.reduzieren><de> Administratoren können in der Serverliste einen Bildlauf durchführen und die Ansicht erweitern und reduzieren, um DirectAccess- und VPN-Serverkomponenten aufzurufen.
<G-vec00597-002-s254><collapse.reduzieren><en> Render a dashboard, select a grid, and expand and collapse it five times with a 15 second pause between interactions.
<G-vec00597-002-s254><collapse.reduzieren><de> Rendern eines Dashboards, Auswählen eines Rasters und fünfmaliges Erweitern und Reduzieren mit einer Pause von 15 Sekunden zwischen Interaktionen.
<G-vec00597-002-s255><collapse.reduzieren><en> Comfort petals The new Avent Natural nipple has unique comfort petals, reducing leakage and nipple collapse.
<G-vec00597-002-s255><collapse.reduzieren><de> Der neue, natürlich geformte Sauger von Avent verfügt über einzigartige Komfortkissen, die ein Auslaufen und das Zusammenziehen des Saugers reduzieren.
<G-vec00597-002-s256><collapse.reduzieren><en> Tip: You can also click Collapse Dialog to temporarily hide the Resize Table dialog box, select the range on the worksheet, and then click Expand dialog .
<G-vec00597-002-s256><collapse.reduzieren><de> Tipp: Sie können auch auf Dialogfeld reduzieren klicken, um das Dialogfeld Tabellengröße ändern vorübergehend auszublenden, den Bereich im Arbeitsblatt auswählen und anschließend auf Dialogfeld erweitern klicken.
<G-vec00597-002-s257><collapse.reduzieren><en> For features coded with CRD_TYPE = 2, consider running the Merge Divided Roads tool first, then running the Collapse Road Detail tool again.
<G-vec00597-002-s257><collapse.reduzieren><de> Für Features, die mit CRD_TYPE = 2 codiert sind, ist es sinnvoll, zuerst das Werkzeug Getrennte Fahrbahnen zusammenführen auszuführen und dann das Werkzeug Straßendetails reduzieren erneut auszuführen.
<G-vec00597-002-s258><collapse.reduzieren><en> Expand and Collapse buttons are shown so you can display or hide details.
<G-vec00597-002-s258><collapse.reduzieren><de> Die Schaltflächen Erweitern und Reduzieren werden angezeigt, sodass Sie Details anzeigen oder ausblenden können.
<G-vec00597-002-s259><collapse.reduzieren><en> To show less detail, click Collapse.
<G-vec00597-002-s259><collapse.reduzieren><de> Zum Anzeigen von weniger Details klicken Sie auf Reduzieren.
<G-vec00597-002-s260><collapse.reduzieren><en> Tip You can also click the Collapse Dialog button at the right end of the Where box, and then select the range that you want to use on the worksheet.
<G-vec00597-002-s260><collapse.reduzieren><de> Tipp Sie können auch auf die Schaltfläche Dialog reduzieren rechts im Feld Wo klicken und dann den gewünschten Bereich auf dem Arbeitsblatt auswählen.
<G-vec00597-002-s261><collapse.reduzieren><en> Use horizontal snap to grid allowing you to place components in the grid, resize as required, and define when they should collapse/reflow to be side-by-side or above/below.
<G-vec00597-002-s261><collapse.reduzieren><de> Mit der horizontalen Ausrichtung am Raster können Sie Komponenten im Raster platzieren, die Größe anpassen und definieren, wann ein Reduzieren/Umfließen daneben oder drüber/darunter erfolgen soll.
<G-vec00597-002-s262><collapse.reduzieren><en> Tip You can also click the Collapse Dialog Box button, and then select the range that you want to use on the worksheet.
<G-vec00597-002-s262><collapse.reduzieren><de> Tipp Sie können auch auf die Schaltfläche Dialog reduzieren klicken und dann den Bereich auswählen, den Sie auf dem Arbeitsblatt verwenden möchten.
<G-vec00597-002-s263><collapse.reduzieren><en> You can use a PivotTable to expand and collapse levels of data to focus your results and to drill down to details from the summary data for areas that are of interest to you.
<G-vec00597-002-s263><collapse.reduzieren><de> Sie können mithilfe einer PivotTable Datenebenen erweitern und reduzieren, um sich auf bestimmte Ergebnisse zu konzentrieren, und Drilldowns durchführen, um Details der zusammengefassten Daten für Sie interessierende Bereiche anzuzeigen.
<G-vec00597-002-s264><collapse.reduzieren><en> Select the menu option Data Comparison | Collapse tables or select this command from the context menu that opens when you right-click the header of either component in the Data Comparison window.
<G-vec00597-002-s264><collapse.reduzieren><de> Wählen Sie die Menüoption Datenvergleich | Tabellen reduzieren oder wählen Sie diesen Befehl aus dem Kontextmenü, das sich öffnet, wenn Sie im Datenvergleichsfenster mit der rechten Maustaste die Kopfzeile einer beliebigen Komponente anklicken.
<G-vec00597-002-s265><collapse.reduzieren><en> The expand/collapse arrow just below the main navigation menu lets you collapse the menu to a set of icons, or expand (fly-out) to show an icon and description for each major administrative feature.
<G-vec00597-002-s265><collapse.reduzieren><de> Mit den Pfeilen zum Erweitern/Reduzieren direkt unterhalb des Hauptnavigationsmenüs können Sie das Menü auf eine Reihe von Symbolen reduzieren oder das Menü erweitern, um ein Symbol und eine Beschreibung für die einzelnen Hauptverwaltungsfunktionen anzuzeigen.
<G-vec00597-002-s266><collapse.scheitern><en> This is even more remarkable when one considers the deplorable collapse of the first German democracy.
<G-vec00597-002-s266><collapse.scheitern><de> Und diese Tatsache ist umso erstaunlicher, als sie einen auffallenden Kontrast zum kläglichen politischen Scheitern der ersten deutschen Demokratie darstellt.
<G-vec00597-002-s267><collapse.scheitern><en> Critics hailed Bricks and Mortar an epochal portrait of urban society after the collapse of the great utopias.
<G-vec00597-002-s267><collapse.scheitern><de> Von der Kritik wurde Im Stein als epochales Porträt einer urbanen Gesellschaft nach dem Scheitern der großen Utopien gefeiert.
<G-vec00597-002-s268><collapse.scheitern><en> It is faith and nothing else that brings light and sense when natural scientific explanations collapse.
<G-vec00597-002-s268><collapse.scheitern><de> Denn dort, wo naturwissenschaftliche Erklärungen scheitern, da ist es der Glauben, der diesen Raum ausfüllt, der einen Sinn und ein Licht gibt.
<G-vec00597-002-s269><collapse.scheitern><en> Also in the pages of the London daily, former shadow Home secretary David Davis believes a policy of tough targets to cut carbon emissions, which Mr Cameron supports, is "destined to collapse".
<G-vec00597-002-s269><collapse.scheitern><de> Der ehemaliger Innenminister des Schattenkabinetts David Davis äußertebenfalls in den Spalten der Londoner Tageszeitung, dass eine solch kompromisslose Politik wie die von Cameron, die das Ziel des CO2-Emissionsstops derart hartnäckig verfolgt, "zum Scheitern verurteilt ist".
<G-vec00597-002-s270><collapse.scheitern><en> (Own report) - Just before the "Nord Stream" natural gas pipeline (or "Baltic Pipeline") goes into operation, a rival "Nabucco" project to German-Russian hegemony over European gas supply is on the verge of collapse.
<G-vec00597-002-s270><collapse.scheitern><de> (Eigener Bericht) - Kurz vor der Inbetriebnahme der Erdgaspipeline "Nord Stream" ("Ostsee-Pipeline") steht ein Konkurrenzprojekt zur deutsch-russischen Hegemonie über die europäische Gasversorgung vor dem Scheitern.
<G-vec00597-002-s271><collapse.scheitern><en> This could have heralded the end of the salvation history of God, the collapse of a movement of several millennia, of the strongest spiritual power of humanity.
<G-vec00597-002-s271><collapse.scheitern><de> Dieses hätte das Ende der Heilsgeschichte Gottes einläuten können, das Scheitern der mehrtausendjährigen Bewegung der stärksten geistigen Macht der Menschheit.
<G-vec00597-002-s272><collapse.scheitern><en> For example - the step-by-step unification of the European justice systems has fallen victim to the red pencil after the collapse of the "European Constitution".
<G-vec00597-002-s272><collapse.scheitern><de> So ist die schrittweise Vereinheitlichung der Justizapparate nach dem Scheitern der "Europäischen Verfassung" dem Rotstift zum Opfer gefallen.
<G-vec00597-002-s273><collapse.scheitern><en> Following negotiations which I followed for more than ten years and which were on the brink of collapse on more than one occasion, I know how valuable cooperation with Russia was in ending that conflict.
<G-vec00597-002-s273><collapse.scheitern><de> Nach Verhandlungen, die ich über 10 Jahre lang begleitet habe und die mehr als nur einmal kurz vor dem Scheitern standen, weiß ich, wie wertvoll die Kooperation mit Russland zur Beendigung dieses Konflikts war.
<G-vec00597-002-s274><collapse.scheitern><en> KABUL/BERLIN (Own report) - In light of the Afghan rebels' spring offensive, warnings of a collapse of the western occupation policy in Afghanistan are getting louder in German military circles.
<G-vec00597-002-s274><collapse.scheitern><de> KABUL/BERLIN (Eigener Bericht) - Angesichts der Frühjahrsoffensive afghanischer Aufständischer werden in Kreisen deutscher Militärs Warnungen vor einem Scheitern der westlichen Besatzungspolitik in Afghanistan laut.
<G-vec00597-002-s275><collapse.scheitern><en> She trains her gaze on social utopias and their collapse, on the economic but also racist marginalization and discrimination of people.
<G-vec00597-002-s275><collapse.scheitern><de> Sie richtet ihren Blick auf soziale Utopien und deren Scheitern, auf die ökonomische, aber auch rassistische Ausgrenzung und Diskriminierung von Menschen.
<G-vec00597-002-s323><collapse.zerfallen><en> This system could collapse like a house of cards from one day to the next.
<G-vec00597-002-s323><collapse.zerfallen><de> Ein System, das von heute auf morgen wie ein Kartenhaus zerfallen koennte.
<G-vec00597-002-s324><collapse.zerfallen><en> By the end of the 1990s it was threatening to collapse after years of neglect.
<G-vec00597-002-s324><collapse.zerfallen><de> Es drohte Ende der 1990er Jahre nach Jahren der Verwahrlosung zu zerfallen.
<G-vec00597-002-s325><collapse.zerfallen><en> Only now, after the general decline on all fronts and only after the collapse of all hopes connected with his bourgeois existence did Jahnn form his unbending and comprehensive concept of creation as a process of destruction.
<G-vec00597-002-s325><collapse.zerfallen><de> Erst jetzt, erst nach der Verdüsterung des allgemeinen Horizonts und erst mit dem Zerfallen aller Hoffnungen seiner bürgerlichen Existenz, hat sich Jahnn eine eherne und umfassende Vorstellung von der Schöpfung als Vernichtungsprozeß gebildet.
<G-vec00597-002-s326><collapse.zerfallen><en> "Wherever states collapse, the people are always the first to suffer," declared Federal Foreign Minister Guido Westerwelle, at the presentation of the new strategy.
<G-vec00597-002-s326><collapse.zerfallen><de> "Überall, wo Staaten zerfallen, leiden zuallererst die Menschen", sagte Bundesaußenminister Guido Westerwelle bei der Vorstellung des Konzepts.
<G-vec00597-002-s039><collapse.zusammenbrechen><en> “If the world slides into recession - and that's what experts at the Forum expect in a few years at the latest - the house of cards will simply collapse.
<G-vec00597-002-s039><collapse.zusammenbrechen><de> „Rutscht die Wirtschaft in die Rezession - und das erwarten die WEF-Experten spätestens in ein paar Jahren -, dann bricht das Kartenhaus zusammen.
<G-vec00597-002-s040><collapse.zusammenbrechen><en> A collapse of the energy supply system would threaten both the economy and society as a whole.
<G-vec00597-002-s040><collapse.zusammenbrechen><de> Bricht die Energieversorgung zusammen, drohen Schäden für Wirtschaft und Gesellschaft.
<G-vec00597-002-s041><collapse.zusammenbrechen><en> He remains in that position for a minute, till he finishes, than he collapse on her.
<G-vec00597-002-s041><collapse.zusammenbrechen><de> Er verharrt in der Position eine Minute, bis er fertig ist, dann bricht er auf ihr zusammen.
<G-vec00597-002-s042><collapse.zusammenbrechen><en> All things must now finally proceed in the calculated form; otherwise, everything will collapse in less than a year.
<G-vec00597-002-s042><collapse.zusammenbrechen><de> Dinge müssen nun endlich in errechneter Form vorangehen, sonst bricht alles zusammen in weniger als einem Jahr.
<G-vec00597-002-s170><collapse.zusammenfallen><en> Both demands finally collapse into the one: modifying as little as at all possible in the old keyboard.
<G-vec00597-002-s170><collapse.zusammenfallen><de> Beide Forderungen fallen schließlich in die eine zusammen: an der alten Klaviatur so wenig wie nur irgend möglich zu ändern.
<G-vec00597-002-s171><collapse.zusammenfallen><en> In one direction they collapse in itself, to be retracted into the housing.
<G-vec00597-002-s171><collapse.zusammenfallen><de> Sie fallen in der einen Richtung zusammen, um ins Gehäuse einzufahren.
<G-vec00597-002-s172><collapse.zusammenfallen><en> The downs collapse as the water dissolves the tiny compounds that hold the down together.
<G-vec00597-002-s172><collapse.zusammenfallen><de> Die Daunen fallen in sich zusammen, da das Wasser die winzigen Verbindungen auflöst, die die Daunen zusammenhalten.
<G-vec00597-002-s173><collapse.zusammenfallen><en> Confronted with the reality of God as revealed to us through the lives of the canonized saints, the atheist arguments for the non-existence of God collapse like a house of cards.
<G-vec00597-002-s173><collapse.zusammenfallen><de> Die Argumente der Atheisten fallen wie ein Kartenhaus in sich zusammen, wenn sie mit der Wirklichkeit Gottes konfrontiert werden, die uns im Leben der Heiligen vor Augen tritt.
