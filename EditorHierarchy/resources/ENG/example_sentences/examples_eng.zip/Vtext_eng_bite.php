<G-vec00441-002-s236><bite.beißen><en> Remember that for your own safety any bite, scratch or even lick from an unknown animal should be cleaned immediately and thoroughly.
<G-vec00441-002-s236><bite.beißen><de> Erinnern Sie sich, dass Sie für eigene Sicherheit die Stelle, wohin das Tier Sie gebissen, gekratzt oder sogar einfach angeleckt hat, unverzüglich und sorgfältig ausspülen sollen.
<G-vec00441-002-s237><bite.beißen><en> Together tasty cocktails are slurping, at the bar we barke and meowe, the tails are wagged everywhere, on the giant bed the animals are rubbing and cuddling each other, but sometimes they also bite.
<G-vec00441-002-s237><bite.beißen><de> Gemeinsam werden lecker Cocktails geschlabbert, an der Bar wird gebellt und miaut, mit den Schwänzen und Schweifen gewedelt, auf dem riesen Hundebett gerieben und gekuschelt, aber manchmal wohl auch gebissen.
<G-vec00441-002-s238><bite.beißen><en> He took advantage of the huge space to annoy the free range hens, but did not bite or hurt any of them (contrary to what his former owner said!).
<G-vec00441-002-s238><bite.beißen><de> Er hat das riesige Gelände dort genutzt um die freilaufenden Hühner zu ärgern – gebissen oder zerrissen hat er aber keins (entgegen der Aussage seines früheren Besitzers).
<G-vec00441-002-s239><bite.beißen><en> In the last two days it came on heavy again but I could bite myself through it.
<G-vec00441-002-s239><bite.beißen><de> In den letzten 2 Tagen kam es noch mal dicke und ich habe mich durch gebissen.
<G-vec00441-002-s344><bite.stechen><en> You can check the capture rate any time by glancing into the trap bag and counting the mosquitoes that will no longer bite you.
<G-vec00441-002-s344><bite.stechen><de> Mit einem Blick in den Fangbeutel können Sie die Fangleistung anhand der gefangenen Mücken jederzeit überprüfen und die Mücken zählen, die Sie nicht mehr stechen werden.
<G-vec00441-002-s345><bite.stechen><en> If you place the trap in shady places or bushes near the terrace, you will catch the mosquitoes near their resting areas, before they reach the terrace and bite you. Resting locations
<G-vec00441-002-s345><bite.stechen><de> Wenn Sie die Falle an schattigen Plätzen oder Büschen neben der Terrasse aufstellen, fangen Sie die Stechmücken nahe ihrer Ruheplätze, bevor sie die Terrasse erreichen und Sie stechen können.
<G-vec00441-002-s346><bite.stechen><en> 17 For, behold, I will send serpents, adders, among you, which will not be charmed; and they shall bite you, says Yahweh.
<G-vec00441-002-s346><bite.stechen><de> 17 Denn siehe, ich will Schlangen und Basilisken unter euch senden, die nicht zu beschwören sind; die sollen euch stechen, spricht der HERR.
<G-vec00441-002-s347><bite.stechen><en> These mosquitoes typically bite during the day, particularly in the early morning and in the evening. Dengue carrier
<G-vec00441-002-s347><bite.stechen><de> Im Gegensatz zur Malaria-Mücke stechen die Tiger- und Gelbfiebermücke überwiegend tagsüber und am frühen Abend.
<G-vec00441-002-s348><bite.stechen><en> Nevertheless, annoying insects bite your favorite child much earlier than this age.
<G-vec00441-002-s348><bite.stechen><de> Trotzdem stechen lästige Insekten Ihr Lieblingskind viel früher als in diesem Alter.
<G-vec00441-002-s349><bite.stechen><en> Only they bite — they need blood for their eggs to grow.
<G-vec00441-002-s349><bite.stechen><de> Denn nur sie stechen – sie brauchen Blut für die Entwicklung ihrer Eier.
<G-vec00441-002-s350><bite.stechen><en> In late summer, people often say that now flies have started to bite.
<G-vec00441-002-s350><bite.stechen><de> Im Spätsommer hört man oft, dass nun die Fliegen zu stechen begonnen haben.
<G-vec00441-002-s351><bite.stechen><en> 10:8 He that digs a pit shall fall into it; and whoso breaks an hedge, a serpent shall bite him.
<G-vec00441-002-s351><bite.stechen><de> 10:8 ○ Aber wer eine Grube macht, der wird selbst hineinfallen; und wer den Zaun zerreißt, den wird eine Schlange stechen.
<G-vec01038-002-s033><bite.beißen><en> If in doubt, ask. I swear I don't bite.
<G-vec01038-002-s033><bite.beißen><de> Wenn Unklarheiten bestehen, frag mich einfach, ich beiße nicht.
<G-vec01038-002-s034><bite.beißen><en> Bite humans and satisfy your hunger.
<G-vec01038-002-s034><bite.beißen><de> Beiße die Leute und stille deinen Hunger.
<G-vec01038-002-s035><bite.beißen><en> Bon Apetit! En Kiss my neck, bite me, pull my hair, trace my spine, hold me down, use your tongue.
<G-vec01038-002-s035><bite.beißen><de> Ik hou van: Küss meinen Nacken, beiße mich, ziehe an meinen Haaren, zeichne meine Wirbelsäule nach, halte mich fest, benutze deine Zunge.
<G-vec01038-002-s036><bite.beißen><en> I do not bite, I`m super nice, friendly and always in a good mood.
<G-vec01038-002-s036><bite.beißen><de> Ich beiße nicht, bin mega nett, freundlich und immer gut gelaunt.
<G-vec01038-002-s037><bite.beißen><en> I bite the bullet and order two new front tires at the dealer.
<G-vec01038-002-s037><bite.beißen><de> Ich beiße in den sauren Apfel und bestelle beim Reifenhändler zwei neue Reifen für die Vorderräder.
<G-vec01038-002-s038><bite.beißen><en> I bite the inside of my lip.
<G-vec01038-002-s038><bite.beißen><de> Ich beiße mir auf die Unterlippe.
<G-vec01038-002-s039><bite.beißen><en> Sometimes I almost bite my teeth on difficult issues.
<G-vec01038-002-s039><bite.beißen><de> Manchmal beiße ich mir an schwierigen Sachverhalten fast die Zähne aus.
<G-vec01038-002-s040><bite.beißen><en> Maybe in a year I'll bite my elbows, that I did not stand with rods.
<G-vec01038-002-s040><bite.beißen><de> Vielleicht in einem Jahr beiße ich mir die Ellbogen, dass ich nicht mit Stäben stehen würde.
<G-vec01038-002-s041><bite.beißen><en> I bite my lips out of pain and summon up all my strength.
<G-vec01038-002-s041><bite.beißen><de> Aus Schmerz beiße ich mich die Lippen auf und versuche noch Kraft zu finden.
<G-vec01038-002-s042><bite.beißen><en> Igor: Nö, Nope, I don't bite ducks... this only stuffs your mouth with feathers...
<G-vec01038-002-s042><bite.beißen><de> Flutterby (moaning): ich beiße keine Enten... da hat man nur lauter Federn im Maul...
<G-vec01038-002-s043><bite.beißen><en> I bite into my sandwich topped with three kinds of meat and sausage, baked with cheese and a fried egg.
<G-vec01038-002-s043><bite.beißen><de> Ich beiße in mein mit drei Fleisch- und Wurstsorten belegtes Sandwich, überbacken mit Käse und einem Spiegelei.
<G-vec01038-002-s044><bite.beißen><en> Between a breath of the cigarette smoke and the stale odor of beer in the dimly lit place, I bite off the end of my fry.
<G-vec01038-002-s044><bite.beißen><de> Zwischen Zigarettenqualm und dem Geruch von abgestandenem Bier in dieser Spelunke, beiße ich das Ende des Kartoffelsticks ab.
<G-vec01038-002-s045><bite.beißen><en> Let yourself be captured by Me, bite yourself firmly and be saved.
<G-vec01038-002-s045><bite.beißen><de> Lass dich von mir fangen, beiße dich fest und werde gerettet.
<G-vec01038-002-s046><bite.beißen><en> If you want to and the rapist is not armed and they forces oral sex on you, bite HARD.
<G-vec01038-002-s046><bite.beißen><de> Wenn der Vergewaltiger nicht bewaffnet ist und dich zu Oralsex zwingt, beiße ihn FEST.
<G-vec01038-002-s047><bite.beißen><en> I bite and I bite not.
<G-vec01038-002-s047><bite.beißen><de> Pass auf, ich beiße.
<G-vec01038-002-s048><bite.beißen><en> If they attack and bite you, you can die.
<G-vec01038-002-s048><bite.beißen><de> Wenn sie dich attackieren und beißen, kannst du sterben.
<G-vec01038-002-s049><bite.beißen><en> They are busy communicating, to you or another lizard, and they may bite.
<G-vec01038-002-s049><bite.beißen><de> Sie kommunizieren mit dir oder einer andere Echse und können beißen.
<G-vec01038-002-s050><bite.beißen><en> Vodicka, water, Wash my little face, So that the glitters gleamed, To make the cheeks blush, So that the rook could laugh, To bite the tooth.
<G-vec01038-002-s050><bite.beißen><de> Vodicka, Wasser, Wasch mein kleines Gesicht, damit die Glitzer schimmerten, die Wangen erröten, damit der Turm lachen konnte, um den Zahn zu beißen.
<G-vec01038-002-s051><bite.beißen><en> Construction materials reflect the relationship between the earth and the landscape: the earth provides the project with ‘roots’ in the slope at the north of the site, the house seems to bite into the mountain, and landscape provides ‘freedom’ to the south, with an overhang that projects the house into the valley.
<G-vec01038-002-s051><bite.beißen><de> Die Konstruktionsmaterialien spiegeln die Beziehung zwischen der Erde und der Landschaft wider: die Erde versorgt das Projekt mit "Wurzeln" im Hang auf der Nordseite des Grundstücks, das Haus scheint in den Berg zu "beißen", und die Landschaft sorgt im Süden mit einem Überhang, der das Haus ins Tal hervorragen läßt, für "Freiheit".
<G-vec01038-002-s052><bite.beißen><en> Patients may search fastidiously for a particular kind of scab to pull; they may try to ensure that the scab is pulled off in a particular way (using either fingers or an implement) and may bite or swallow the scab once it has been pulled off.
<G-vec01038-002-s052><bite.beißen><de> Die Patienten können penibel nach einer bestimmten Art von Schorf suchen, um diesen abzuziehen; sie können versuchen, sicherzustellen, dass die Kruste in einer bestimmten Art und Weise abgezogen wird (entweder mit den Fingern oder einem Werkzeug) und beißen oder schlucken diesen eventuell, sobald er abgezogen wurde.
<G-vec01038-002-s053><bite.beißen><en> I wanted to bite the fingers I felt in my mouth but had no strength.
<G-vec01038-002-s053><bite.beißen><de> Ich wollte in die Finger beißen die ich in meinem Mund spürte, aber ich hatte keine Kraft.
<G-vec01038-002-s054><bite.beißen><en> `Very true,' said the Duchess: `flamingoes and mustard both bite.
<G-vec01038-002-s054><bite.beißen><de> »Sehr wahr,« sagte die Herzogin, »Flamingos und Senf beißen beide.
<G-vec01038-002-s055><bite.beißen><en> For those who like it a bit more extreme, it can also be a way to bite your cheek firmly or your finger.
<G-vec01038-002-s055><bite.beißen><de> Für diejenigen, die es etwas extremer mögen kann es auch eine Möglichkeit sein, sich feste auf die Backe oder auf den Finger zu beißen.
<G-vec01038-002-s056><bite.beißen><en> Unlike most other bulbous ones, mice do not bite them, moreover, they bypass it.
<G-vec01038-002-s056><bite.beißen><de> Im Gegensatz zu den meisten anderen Knollenmäusen beißen Mäuse sie nicht, außerdem umgehen sie sie.
<G-vec01038-002-s057><bite.beißen><en> The cold would bite into the window frames.
<G-vec01038-002-s057><bite.beißen><de> Die Kälte würde sich in die Fensterrahmen beißen.
<G-vec01038-002-s058><bite.beißen><en> Typical conditions are the “overbite”, whereby the upper incisors protrude over the lower ones or a lower jaw that is too large and pronounced so that the lower incisors bite before the upper ones do.
<G-vec01038-002-s058><bite.beißen><de> Typische Formen sind etwa der „Deckbiss“, bei welchem die oberen Schneidezähne die unteren überdecken oder ein zu großer, ausgeprägter Unterkiefer, bei dem die unteren Schneidezähne vor die oberen beißen.
<G-vec01038-002-s059><bite.beißen><en> However, be careful, as not all of them enjoy it and may try to bite.
<G-vec01038-002-s059><bite.beißen><de> Allerdings solltest du damit vorsichtig sein, da nicht alle Artgenossen es mögen und sie daher versuchen könnte, dich zu beißen.
<G-vec01038-002-s060><bite.beißen><en> This is due to the fact that freely moving around the room, rabbits can bite the wires, spoil furniture and other items.
<G-vec01038-002-s060><bite.beißen><de> Dies liegt an der Tatsache, dass sich Kaninchen frei im Raum bewegen können, die Drähte beißen, Möbel und andere Gegenstände verderben können.
<G-vec01038-002-s061><bite.beißen><en> The outer fabric (600D high tenacity polyester) with a diamond quilted pattern makes it a lot harder for the horse to bite in the fabric and tear it up.
<G-vec01038-002-s061><bite.beißen><de> Da der äußere Stoff (600D hochfester Polyester) mit einem Diamant-gesteppten Muster versehen ist, wird es auch sehr schwierig für das Pferd, in den Stoff zu beißen und die Decke zu zerreißen.
<G-vec01038-002-s062><bite.beißen><en> The bearded dragon will probably try to bite you, so keep its head between your fingers so it can’t turn to bite you.
<G-vec01038-002-s062><bite.beißen><de> Der Bartagame wird wahrscheinlich versuchen dich zu beißen, also halte seinen Kopf zwischen deinen Fingern, damit er sich nicht drehen kann, um dich zu beißen.
<G-vec01038-002-s064><bite.beißen><en> Bite into the orange.
<G-vec01038-002-s064><bite.beißen><de> In die Orange beißen.
<G-vec01038-002-s065><bite.beißen><en> Immigration Minister Phil Woolas pointed to this slight slowdown as evidence the Government's points-based system was starting to bite.
<G-vec01038-002-s065><bite.beißen><de> Immigrationsminister Phil Woolas wies auf eine leichte Abschwächung als Beweismittel hin, dass das Punkte-System der Regierung zu beißen beginne.
<G-vec01038-002-s066><bite.beißen><en> In the autumn the perch is most easily caught on a jig, fishing from the boat, as well as in the winter when the large perch likes to bite on a shiny jig with worms or perch eyes as bait on the hook.
<G-vec01038-002-s066><bite.beißen><de> Im Herbst wird der Barsch am einfachsten mit der Eisangel vom Boot gefangen, wie auch im Winter, wenn die großen Barsche gern auf einen mit Wurm oder Barschauge geköderten Eisangelblinker beißen.
<G-vec01038-002-s067><bite.beißen><en> Often bite at the heads of rapids.
<G-vec01038-002-s067><bite.beißen><de> Beißt gerne am Oberlauf von Stromschnellen.
<G-vec01038-002-s068><bite.beißen><en> Her most recent work, »La mano che non mordi« (2007; t: The hand that you don't bite), is set in the former Yugoslavia, which resembles her native country in uncanny ways.
<G-vec01038-002-s068><bite.beißen><de> Ihr jüngstes Werk, »La mano che non mordi« (2007; Ü: Die Hand, die man nicht beißt), spielt im ehemaligen Jugoslawien, das auf unheimliche Weise ihrem Heimatland gleicht.
<G-vec01038-002-s069><bite.beißen><en> But today you are a warrior of love, and you bite into the day, and you make it good.
<G-vec01038-002-s069><bite.beißen><de> Heute aber bist du ein Krieger der Liebe, und du beißt in den Tag, und du machst das gut.
<G-vec01038-002-s070><bite.beißen><en> 10:11 Surely the serpent will bite without enchantment; and a babbler is no better.
<G-vec01038-002-s070><bite.beißen><de> 10:11 Wenn die Schlange beißt, ehe die Beschwörung da ist, so hat der Beschwörer keinen Nutzen.
<G-vec01038-002-s071><bite.beißen><en> Professor Mark Post, PhD, taking a bite of his burger made of lab-grown meat.
<G-vec01038-002-s071><bite.beißen><de> Professor Mark Post, PhD, beißt in seinen Burger aus Fleisch, das im Labor gezüchtet wurde.
<G-vec01038-002-s072><bite.beißen><en> Summons a demon to repeatedly bite a single target, dealing 18% Magic Attack every 3 sec.
<G-vec01038-002-s072><bite.beißen><de> Beschwört einen Dämon, der wiederholt ein einzelnes Ziel beißt und so 18% Eures Magischen Schadens alle 3 Sekunden zufügt.
<G-vec01038-002-s073><bite.beißen><en> If the serpent bite before enchantment, then the charmer hath no advantage.
<G-vec01038-002-s073><bite.beißen><de> Wenn die Schlange beißt, ehe man sie beschworen hat, so hat der Beschwörer keinen Nutzen von seiner Kunst.
<G-vec01038-002-s074><bite.beißen><en> As a joke, the Slovenian president showed a video in which he took a bite out of a board made of biodegradable material, which we also produced.
<G-vec01038-002-s074><bite.beißen><de> Als Scherz zeigte der Präsident Sloweniens auf einem Video, wie er in ein Brett aus biologisch abbaubarem Material beißt, das wir ebenfalls produziert haben.
<G-vec01038-002-s075><bite.beißen><en> Whilst neighbours at the table bite enthusiastically into their schnitzel, others must eat puréed food.
<G-vec01038-002-s075><bite.beißen><de> Während der Tischnachbar herzhaft in sein Schnitzel beißt, müssen andere Bewohner pürierte Kost zu sich nehmen.
<G-vec01038-002-s076><bite.beißen><en> Once in a restaurant at a nearby table we see a scene: a girl takes a bite out of something, and if it seems hot to her, opens her mouth and Mom blows her there.
<G-vec01038-002-s076><bite.beißen><de> Einmal in einem Restaurant an einem Tisch in der Nähe sehen wir eine Szene: ein Mädchen beißt etwas heraus, und wenn es ihr heiß erscheint, öffnet sie den Mund und Mama bläst sie dort.
<G-vec01038-002-s077><bite.beißen><en> The sun is a short-term band-aid which will often bite back with more acne in the weeks following exposure.
<G-vec01038-002-s077><bite.beißen><de> Die Sonne ist ein kurzfristiges Bandhilfsmittel, das häufig zurück mit mehr Akne in den Wochen Belichtung folgend beißt.
<G-vec01038-002-s078><bite.beißen><en> 15 But if you bite and devour one another, be careful that you don't consume one another.
<G-vec01038-002-s078><bite.beißen><de> 15Wenn ihr euch aber untereinander beißt und fresst, so seht zu, dass ihr nicht einer vom andern aufgefressen werdet.
<G-vec01038-002-s079><bite.beißen><en> 15But if you bite and devour one another, beware lest you be consumed by one another!
<G-vec01038-002-s079><bite.beißen><de> 15 Wenn ihr einander beißt und verschlingt, dann gebt Acht, dass ihr euch nicht gegenseitig umbringt.
<G-vec01038-002-s080><bite.beißen><en> Quotation Goethe: "God gives the nuts, but he does not bite them auf".
<G-vec01038-002-s080><bite.beißen><de> Zitat Goethe: "Gott gibt die Nüsse, aber er beißt sie nicht auf".
<G-vec01038-002-s081><bite.beißen><en> If you have time and are curious, see if you can find the small monkey that is figuratively taking a bite of the “sour apple,” a German expression equivalent to “swallowing a bitter pill.”
<G-vec01038-002-s081><bite.beißen><de> Wenn Sie Lust und Zeit haben, gehen Sie auf die Suche nach einem kleinen Äffchen, das im übertragenen Sinne in den „sauren Apfel“ beißt.
<G-vec01038-002-s082><bite.beißen><en> With the US in quiet support of the invasion and Britain not keen on engaging in military action in the issue, the UN resolution was all bark with bite.
<G-vec01038-002-s082><bite.beißen><de> Da die USA die Invasion stillschweigend unterstützten und die Briten nicht scharf darauf waren sich an militärischen Aktionen in dieser Angelegenheit zu beteiligen, war die UN Resolution wie ein bellender Hund, der nicht beißt.
<G-vec01038-002-s083><bite.beißen><en> When venomous snakes bite, in addition to tissue damage and infection, the concern is the effects of the snake venom.
<G-vec01038-002-s083><bite.beißen><de> Wenn dich eine Giftschlange beißt, sind neben den Gewebeschäden und der Infektion die Auswirkungen des Schlangengifts ein weiteres Problem.
<G-vec01038-002-s084><bite.beißen><en> Then you bite a hole in the dough and lick out the whole filling with joy: circular, sucking, fast and slow.
<G-vec01038-002-s084><bite.beißen><de> Dann beißt du ein Loch in den Teig und leckst die ganze Füllung genüsslich aus: kreisend, saugend, schnell und langsam.
<G-vec01038-002-s085><bite.beißen><en> In order to fasten the overalls, lightning does not "bite" the baby's chin, in "right" models, she has protection against pinching - sewn into the collar fabric corner, which closes the lock.
<G-vec01038-002-s085><bite.beißen><de> Um den Overall zu befestigen, "beißt" das Blitzlicht das Kinn des Babys nicht, bei "richtigen" Modellen hat es Schutz gegen Einklemmen - in die Kragen-Stoffecke eingenäht, die das Schloss schließt.
<G-vec01038-002-s086><bite.beißen><en> Yesterday evening we had a bite and landed a fish.
<G-vec01038-002-s086><bite.beißen><de> Gestern Abend hatten wir einen Biss.
<G-vec01038-002-s087><bite.beißen><en> If you are interested you can study – in flowers or on a straw of grass – how the spiders, who don’t weave a net, sit motionlessly waiting for their prey, and how they then paralyze the victim with a poisonous bite.
<G-vec01038-002-s087><bite.beißen><de> Bei Interesse kann man beobachten - in Blumen oder an Grashalmen - wie die Spinnen, die kein Netz weben, bewegungslos dasitzen und auf Beute warten und sie dann das Opfer mit einem giftigen Biss bewegungsunfähig machen.
<G-vec01038-002-s088><bite.beißen><en> Andrew’s talk was followed by a short movie about South Georgia, which showed the beauty impressive nature, but also the danger and how your hand might look after a bite of a fur seal, which can be aggressive.
<G-vec01038-002-s088><bite.beißen><de> Das Expeditionsteam zeigte uns hinterher einen kurzen Dokumentarfilm über Süd-Georgien, welcher uns die schöne Landschaft zeigte, aber auch was passieren kann mit deiner Hand nach einem Biss von einer Pelzrobbe.
<G-vec01038-002-s089><bite.beißen><en> It is very important that the doctor carefully examines the wound, as there are many cases when fragments of animal teeth, wool, dirt or other foreign objects could remain in the wound from the bite.
<G-vec01038-002-s089><bite.beißen><de> Es ist sehr wichtig, dass der Arzt die Wunde sorgfältig untersucht, da es viele Fälle gibt, in denen Fragmente von Tierzähnen, Wolle, Schmutz oder anderen Fremdkörpern in der Wunde vom Biss verbleiben können.
<G-vec01038-002-s090><bite.beißen><en> The bacteria that gets into a wound from a bite is what causes the abscess.
<G-vec01038-002-s090><bite.beißen><de> Verursacht wird er durch die Bakterien, die durch den Biss in die Wunde gelangen.
<G-vec01038-002-s091><bite.beißen><en> If a praline starts to melt in your hand before you bite into it, this is a sign that it contains a lot of cocoa butter, a very good sign.
<G-vec01038-002-s091><bite.beißen><de> Wenn eine Praline noch vor dem ersten Biss in Ihrer Hand zu schmelzen beginnt, dann ist dies ein gutes Zeichen, denn es bedeutet, dass sie mit viel Kakaobutter hergestellt wurde.
<G-vec01038-002-s092><bite.beißen><en> Tommy shook some Tabasco on his taco, took a bite, and added a few more shakes.
<G-vec01038-002-s092><bite.beißen><de> Das habe ich ihm empfohlen.« Tommy goss ein wenig Tabasco auf sein Taco, biss davon ab und würzte nach.
<G-vec01038-002-s093><bite.beißen><en> He was small, highly flexible, unpredictable with the will and bite to succeed.
<G-vec01038-002-s093><bite.beißen><de> Er war klein, hoch flexibel, unberechenbar mit dem Willen und Biss zum Erfolg.
<G-vec01038-002-s094><bite.beißen><en> A venomous snake - viper - may be seen in the area of South Moravia; its bite may be dangerous especially for children.
<G-vec01038-002-s094><bite.beißen><de> In Südmähren können Sie einer Giftschlange begegnen - Kreuzotter, deren Biss für Kinder gefährlich sein kann.
<G-vec01038-002-s095><bite.beißen><en> Bored of generic sounds and tracks that lack bite, his productions increasingly sidestep cliche and tread riskier paths -- often perverting house and techno frames with a myriad of sounds deftly lifted from other facets of electronic music and beyond.
<G-vec01038-002-s095><bite.beißen><de> Gelangweilt durch typische Sounds und Tracks, denen Biss fehlt, weichen seine Produktionen zunehmend Klischee aus und betreten riskantere Wege—oftmals werden verdrehte House- und Techno-Frames mit unzähligen Sounds und anderen Facetten elektronischer Musik erweitert und so in andere Sphären gehoben.
<G-vec01038-002-s096><bite.beißen><en> There is a hard bite.
<G-vec01038-002-s096><bite.beißen><de> Es erfolgt ein harter Biss.
<G-vec01038-002-s097><bite.beißen><en> Crisp dark chocolate chunks with extra bite and lots of cocoa – our chocolate chunks give your cake that special something.
<G-vec01038-002-s097><bite.beißen><de> Knackige Zartbitter Schokostücken mit extra viel Biss und viel Kakao – unsere Chocolate Chunks verleihen deinen Kuchen, das besondere Etwas.
<G-vec01038-002-s098><bite.beißen><en> Oh thus a small bite will not certainly harm - and generally - to me HE does not have it also directly said.
<G-vec01038-002-s098><bite.beißen><de> Ach, so ein kleiner Biss wird sicher nicht schaden - und überhaupt - mir hat ER es ja auch nicht direkt gesagt.
<G-vec01038-002-s099><bite.beißen><en> Bite through yourself and control more snakes for more points.
<G-vec01038-002-s099><bite.beißen><de> Biss durch sich selbst und kontrollieren mehr Schlangen für mehr Punkte.
<G-vec01038-002-s100><bite.beißen><en> To a serious illness and even death can result in a bite of spiders - Brown hermit or Black widow.
<G-vec01038-002-s100><bite.beißen><de> Zu einer schweren Krankheit und sogar zum Tod kann ein Biss von Spinnen führen - Brauner Einsiedler oder Schwarze Witwe.
<G-vec01038-002-s101><bite.beißen><en> Ferocious Bite now has double the normal chance to critically strike against bleeding targets (instead of having an additional 25% chance to critically strike).
<G-vec01038-002-s101><bite.beißen><de> 'Wilder Biss' hat bei blutenden Zielen jetzt eine verdoppelte kritische Trefferchance (anstatt einer allgemein um 25 % erhöhten kritischen Trefferchance).
<G-vec01038-002-s102><bite.beißen><en> This O-Zone delivers bite with a touch of anger.
<G-vec01038-002-s102><bite.beißen><de> Diese O-Zone liefert Biss mit einem Hauch von Wut.
<G-vec01038-002-s103><bite.beißen><en> The brown recluse spider, also known as the violin spider, is a venomous creature whose bite can cause children and adults to become ill.
<G-vec01038-002-s103><bite.beißen><de> Die Braune Einsiedlerspinne, auch als Violinenspinne bekannt, ist eine der giftigsten Spinnenarten Nordamerikas und kann durch einen Biss bei Kindern und Erwachsenen schwere Symptome hervorrufen.
<G-vec01038-002-s104><bite.beißen><en> This puppy was so frightened, but when we tried to stroke her, she wanted to bite, but not to attack, just because she was so frightened and in so much pain.
<G-vec01038-002-s104><bite.beißen><de> Dieses Welpen war sehr ängstlich und beim versuch sie zu streicheln biss sie vor Angst - außerdem hatte sie starke Schmerzen, weshalb sie auch zusätzlich Angst vor unseren Berühungen hatte, weil hierdurch ihre Schmerzen offensichtlich verstärkt wurden.
<G-vec01038-002-s112><bite.beißen><en> Each bite of our cream cake is lush and filled with a multi-texture little wonders.
<G-vec01038-002-s112><bite.beißen><de> Jeder Bissen von diesem zarten Creme-Kuchen ist üppig und Ihr Empfänger wird ihn mit einer Tasse Kaffee bestimmt genießen.
<G-vec01038-002-s113><bite.beißen><en> Savor the flavor and take a bite out of the annual Burgerliscious - a beefy gathering of more than 20 of Coral Gables' premier...
<G-vec01038-002-s113><bite.beißen><de> Genießen Sie den Geschmack und nehmen Sie einen Bissen aus dem jährlichen Burgerliscious - eine fleischige Versammlung von mehr als 20...
<G-vec01038-002-s114><bite.beißen><en> In order to complete the challenging metres of altitude without break-ins, it is best to go to any refreshment stand and treat yourself to a bouillon, a salty gel or a bite of the famous Salty&Nuts bar, depending on your individual taste for salt.
<G-vec01038-002-s114><bite.beißen><de> Um die anspruchsvollen Höhenmeter genussvoll und ohne Einbrüche zu absolvieren, langt man nun am besten an jedem Verpflegungsstand zu und gönnt sich je nach individuellem Salzgelust auch mal eine Bouillon, einen salzigen Gel oder einen Bissen vom herzhaften Salty&Nuts-Riegel.
<G-vec01038-002-s115><bite.beißen><en> Oral care cleans your dog's teeth and thanks to Hill's unique, specially composed biscuits plaque is removed with every bite.
<G-vec01038-002-s115><bite.beißen><de> Dank Hill's einzigartiger, speziell zusammengesetzter Futterbrocken, reinigt Oral Care die Zähne Ihres Hundes und entfernt Plaque und Zahnbelag mit jedem Bissen.
<G-vec01038-002-s116><bite.beißen><en> Fisherman's is known as one of the best seafood restaurants in Berlin and I have to say we had really good food and enjoyed every bite.
<G-vec01038-002-s116><bite.beißen><de> Fisherman's ist bekannt als eines der besten Fischrestaurants in Berlin und ich muss sagen wir haben das Essen wirklich bis zum letzten Bissen genossen.
<G-vec01038-002-s117><bite.beißen><en> With every bite you will revel in memories of the landscape of Provence.
<G-vec01038-002-s117><bite.beißen><de> So schwelgen Sie mit jedem Bissen in Meersalz und Kräutern.
<G-vec01038-002-s118><bite.beißen><en> When you eat, appreciate every last bite.
<G-vec01038-002-s118><bite.beißen><de> •Wenn du isst, schätze jeden letzten Bissen.
<G-vec01038-002-s119><bite.beißen><en> One type of injury that can be compensated is a dog or any animal deadly bite.
<G-vec01038-002-s119><bite.beißen><de> Eine Art Verletzung, die ausgeglichen werden kann, ist ein Hund oder jeder tierische tödliche Bissen.
<G-vec01038-002-s120><bite.beißen><en> With Wonka’s permission, Charlie reaches into the television, grabs the chocolate, and eats a bite.
<G-vec01038-002-s120><bite.beißen><de> Mit Wonkas Erlaubnis greift Charlie in den Fernseher, schnappt sich die Schokolade und isst einen Bissen.
<G-vec01038-002-s121><bite.beißen><en> I can say from personal experience that there are many, many more bite incidents with the household dog or cat, and that either of these species tend to do a lot more damage.
<G-vec01038-002-s121><bite.beißen><de> Ich kann aus persönlicher Erfahrung sagen, dass es viel, viel mehr Zwischfälle mit Bissen mit dem Hund oder der Katze eines Haushaltes gibt, und das jeder dieser Arten dazu neigt, einen viel größeren Schaden zu verursachen.
<G-vec01038-002-s122><bite.beißen><en> Be aware of your environment, eat slowly, enjoy each bite.
<G-vec01038-002-s122><bite.beißen><de> Achten Sie auf Ihre Umgebung, Essen Sie langsam, genießen Sie jeden Bissen.
<G-vec01038-002-s123><bite.beißen><en> Take a bite from Canada’s multi cultural arts capital, Montreal, where the city’s diversity translates seamlessly into its tasty eateries.
<G-vec01038-002-s123><bite.beißen><de> Genehmigen Sie sich einen Bissen von Kanadas multikultureller Kunsthauptstadt, Montreal, wo sich die Vielseitigkeit der Stadt nahtlos auf ihre leckeren Restaurants überträgt.
<G-vec01038-002-s124><bite.beißen><en> One scrumptious bite and you'll understand how the bar got its name!
<G-vec01038-002-s124><bite.beißen><de> Ein Bissen und Sie werden merken woher dieser Riegel dessen Namen bekam.
<G-vec01038-002-s125><bite.beißen><en> The first bite tells us the lamb shank on kumara mash was the right choice.
<G-vec01038-002-s125><bite.beißen><de> Wir entscheiden uns für die Lamb Shank on kumara mash und schwelgen vom ersten Bissen an.
<G-vec01038-002-s126><bite.beißen><en> With every bite, you can taste the fact that the calves were reared without stress and healthily in the meadows of the Bavarian Alpine foothills.
<G-vec01038-002-s126><bite.beißen><de> Mit jedem Bissen schmecken Sie, wie die Kälber stressfrei und gesund auf den Weiden des bayerischen Voralpenlandes aufgewachsen sind.
<G-vec01038-002-s127><bite.beißen><en> When I found them there was a bunch of them, not only two, and I had not presented my sandwiches yet when they had vanished from my hands and a fight started over each bite of it.
<G-vec01038-002-s127><bite.beißen><de> Da waren dann nicht zwei, sondern ein ganzer Trupp, und kaum dass ich Brote hervorgeholt hatte, waren sie mir aus den Händen gerissen und es gab einen regelrechten Kampf um jeden Bissen davon.
<G-vec01038-002-s128><bite.beißen><en> If you feel uncertain about whether or not cooked chicken is still good, but do not want to waste it if it still is, you can cautiously take a bite.
<G-vec01038-002-s128><bite.beißen><de> Falls du dir unsicher bist, ob gegartes Hühnerfleisch noch gut ist, du es aber nicht verschwenden möchtest, kannst du vorsichtig einen Bissen nehmen.
<G-vec01038-002-s129><bite.beißen><en> Every potential customer is at a different point in the sales funnel and having a multi-pronged attraction phase will help you to generate more targeted, high quality “hot” leads than just casting out your digital net and hoping for a bite from any traffic source.
<G-vec01038-002-s129><bite.beißen><de> Jeder potenzielle Kunde befindet sich an einem anderen Punkt im Funnel und eine mehrgleisige Attraktionsphase zu haben, hilft Dir, forciertere, qualitativ hochwertige „heiße“ Leads zu generieren anstatt nur Dein digitales Netz auszuwerfen und auf einen Bissen zu hoffen.
<G-vec01038-002-s130><bite.beißen><en> Her work colleagues, former test eaters, were enthusiastic from the first bite and passengers loved the delicious pastry.
<G-vec01038-002-s130><bite.beißen><de> Ihre Arbeitskollegen, die damaligen Testesser, waren vom ersten Bissen weg begeistert und schwärmten bei den Fahrgästen von der schmackhaften Wähe.
