<G-vec00316-003-s298><abide_by.(sich)_nehmen><en> Islanders and visitors abide by strict rules to keep it that way Getting to heaven can be a trial.
<G-vec00316-003-s298><abide_by.(sich)_nehmen><de> Um sie dauerhaft zu schützen, gelten strikte Regeln für Bewohner und Besucher Wer ins Paradies will, muss auch den Weg dorthin auf sich nehmen.
<G-vec00316-003-s299><abide_by.(sich)_nehmen><en> We ask that you abide by the terms and conditions below.
<G-vec00316-003-s299><abide_by.(sich)_nehmen><de> Wir bitten Sie die Allgemeinen Geschäftsbedingungen zur Kenntnis zu nehmen.
<G-vec00316-003-s019><abide_by.akzeptieren><en> By using the site, You acknowledge that you have read and agree to abide by the TOU.
<G-vec00316-003-s019><abide_by.akzeptieren><de> Mit der Navigation auf der Website erklären Sie, die ANB zur Kenntnis genommen zu haben und in vollem Umfang und vorbehaltlos zu akzeptieren.
<G-vec00316-003-s020><abide_by.akzeptieren><en> We do insist that you abide by the rules and policies of the forum.
<G-vec00316-003-s020><abide_by.akzeptieren><de> Klicke auf »Akzeptieren«, wenn Du die hier genannten Regeln und Erklärungen anerkennst.
<G-vec00316-003-s021><abide_by.akzeptieren><en> “Then they must abide by the decision.
<G-vec00316-003-s021><abide_by.akzeptieren><de> Dann müssen sie die Entscheidung akzeptieren.
<G-vec00316-003-s037><abide_by.anerkennen><en> Agreement to Official Rules: Entry and participation in this Sweepstakes constitutes entrant's full and unconditional agreement (and permission of an entrant under the age of majority in his/her state or country of residence (a 'Minor') to enter and participate in this Sweepstakes constitutes such Minor's parent/legal guardian's full and unconditional agreement on behalf of themselves and the Minor participant) to abide by these Official Rules (exact compliance is essential) and accept the decisions of Sponsor and its agents as final and binding in all matters related to this Sweepstakes.
<G-vec00316-003-s037><abide_by.anerkennen><de> "Anerkennung der offiziellen Bedingungen: Die Teilnahme an diesem Gewinnspiel stellt die volle und bedingungslose Zustimmung des Teilnehmers dar (und die Erlaubnis einer in ihrem Wohnsitzland minderjährigen Person (""Minderjährige"") zur Teilnahme an diesem Gewinnspiel stellt die volle und bedingungslose Zustimmung des Elternteils oder Sorgeberechtigten im eigenen Namen und dem des minderjährigen Teilnehmers dar), diese offiziellen Bedingungen anzuerkennen (genaue Beachtung ist unerlässlich) und die Entscheidungen des Veranstalters und seiner Vertreter bezüglich dieses Gewinnspiels als endgültig und verbindlich zu akzeptieren.
<G-vec00316-003-s038><abide_by.anerkennen><en> However, the judge refused to abide by the law.
<G-vec00316-003-s038><abide_by.anerkennen><de> Der Richter jedoch weigerte sich, diese rechtlich anzuerkennen.
<G-vec00316-003-s039><abide_by.aushalten><en> I couldn’t abide daylight.
<G-vec00316-003-s039><abide_by.aushalten><de> Ich konnte das Tageslicht nicht aushalten.
<G-vec00316-003-s040><abide_by.aushalten><en> I do not seem to be capable of removing my anger, and I don't know how to abide with it.
<G-vec00316-003-s040><abide_by.aushalten><de> Ich scheine nicht fähig zu sein, meinen Ärger fortzuschaffen, und ich weiß nicht, wie ich es mit ihm aushalten kann.
<G-vec00316-003-s041><abide_by.beachten><en> For any claim where the total amount of the award sought is $10,000 or less, the AAA, you and Covoco must abide by the following rules: (a) the arbitration shall be conducted solely based on written submissions; and (b) the arbitration shall not involve any personal appearance by the parties or witnesses unless otherwise mutually agreed by the parties.
<G-vec00316-003-s041><abide_by.beachten><de> Für Streitigkeiten mit einem Gesamtstreitwert von bis zu $10.000 müssen die AAA, Sie und 99designs folgende Regeln beachten: (a) das Schiedsverfahren darf nur auf der Grundlage schriftlicher Eingaben durchgeführt werden; und (b) das Schiedsverfahren beinhaltet kein persönliches Erscheinen der Parteien oder von Zeugen, es sei denn, dies wird von den Parteien einvernehmlich vereinbart.
<G-vec00316-003-s042><abide_by.beachten><en> The client shall comprehensively abide by these regulations, save their direct or indirect applicability and shall never supply products purchased from the vendor to the Iranian oil and gas industry nor directly or indirectly get round these Regulations in any manner whatsoever.
<G-vec00316-003-s042><abide_by.beachten><de> Der Kunde hat diese Vorschriften vollumfänglich zu beachten und zu keinem Zeitpunkt beim Verkäufer gekaufte Produkte an die iranische Gas- und Ölindustrie weder direkt noch indirekt zu liefern, noch diese Vorschriften auf irgendeine Weise zu umgehen.
<G-vec00316-003-s043><abide_by.beachten><en> The Client undertakes to abide by any special conditions of access to the accommodation concerning pets.
<G-vec00316-003-s043><abide_by.beachten><de> Der Kunde verpflichtet sich, die eventuellen besonderen Zugangsbedingungen in Bezug auf Haustiere zu beachten.
<G-vec00316-003-s044><abide_by.beachten><en> Both members and guests are expected to abide by all relevant VIP lounge regulations.
<G-vec00316-003-s044><abide_by.beachten><de> Die in der VIP Lounge geltenden Bestimmungen sind von Mitgliedern und Gästen gleichermaßen zu beachten.
<G-vec00316-003-s045><abide_by.beachten><en> Naturally, we abide by the legal provisions of the German Federal Data Protection Act (BDSG), the German Telemedia Act (TMG) and any other applicable data protection regulations.
<G-vec00316-003-s045><abide_by.beachten><de> Selbstverständlich beachten wir die gesetzlichen Bestimmungen des Datenschutzgesetzes (BDSG) des Telemediengesetzes (TMG) und anderer datenschutzrechtlicher Bestimmungen.
<G-vec00316-003-s046><abide_by.beachten><en> I have familiarised myself with the general conditions and agree to abide by them. See conditions Miscellaneous
<G-vec00316-003-s046><abide_by.beachten><de> Ich erkläre hiermit, von den allgemeinen Geschäftsbedingungen Kenntnis genommen zu haben und sie zu beachten.
<G-vec00316-003-s047><abide_by.beachten><en> You agree to abide by any and all additional copyright notices, information, or restrictions contained in any part of TechTarget’s German Network of Sites.
<G-vec00316-003-s047><abide_by.beachten><de> Sie verpflichten sich, alle zusätzlichen urheberrechtlichen Vermerke, Informationen oder Beschränkungen zu beachten, die in irgendeinem Teil von TechTarget’s Netzwerk von deutschen Webseiten enthalten sind.
<G-vec00316-003-s048><abide_by.beachten><en> You may transfer files containing the Work or permitted derivative works to employees or subcontractors, provided that such employees and subcontractors agree to abide by the restrictions of this Agreement and only use the Work on your behalf.
<G-vec00316-003-s048><abide_by.beachten><de> Sie dürfen die Dateien, die das Werk oder zulässige abgeleitete Werke enthalten, an Mitarbeiter oder Vertragsnehmer unter der Voraussetzung übermitteln, dass die betreffenden Mitarbeiter und Vertragsnehmer die Einschränkungen dieses Vertrags beachten und das Werk nur in Ihrem Auftrag verwenden.
<G-vec00316-003-s049><abide_by.beachten><en> Always abide by the terms and conditions of use of Facebook, Twitter, Instagram and YouTube.
<G-vec00316-003-s049><abide_by.beachten><de> Bitte beachten Sie die Allgemeinen Geschäftsbedingungen von Facebook, Twitter, Instagram und Youtube.
<G-vec00316-003-s050><abide_by.beachten><en> During Ramadan everyone who visits Dubai, regardless of their religion, should abide by the fast in public throughout their visit.
<G-vec00316-003-s050><abide_by.beachten><de> Während des Ramadans müssen alle Besucher Dubais unabhängig von ihrer Region das Fastengebot in der Öffentlichkeit beachten.
<G-vec00316-003-s051><abide_by.beachten><en> You agree to abide by this License in Your installation and use of the App.
<G-vec00316-003-s051><abide_by.beachten><de> Sie stimmen zu, diese Lizenz bei Ihrer Installation und Nutzung der App zu beachten.
<G-vec00316-003-s073><abide_by.befolgen><en> Man only knew that it was Jehovah who had created mankind, but he had no inkling of how to abide by the words or the laws of Jehovah.
<G-vec00316-003-s073><abide_by.befolgen><de> Der Mensch wusste lediglich, dass es Jehova war, der die Menschheit erschaffen hatte, doch der Mensch hatte nicht die leiseste Ahnung davon, wie man die Worte und Gebote Jehovas befolgt.
<G-vec00316-003-s074><abide_by.befolgen><en> 3.7 A member can be excluded from the Association by resolution of the Management Board if the member grossly violates the purpose, interests or reputation of the Association, in particular, does not abide by these Articles of Association or, in spite of repeated demands, fails to pay the resolved contributions, fees or costs allocations.
<G-vec00316-003-s074><abide_by.befolgen><de> 3.7 Ein Mitglied kann durch Beschluss des Vorstands aus dem Verein ausgeschlossen werden, wenn es Zweck, Belange oder Ansehen des Vereins gröblich schädigt, insbesondere diese Satzung nicht befolgt oder trotz mehrmaliger Aufforderung die beschlossenen Beiträge, Gebühren oder Umlagen nicht zahlt.
<G-vec00316-003-s222><abide_by.bleiben><en> Had these been gods, they would not have come to it and all shall abide therein.
<G-vec00316-003-s222><abide_by.bleiben><de> Wären diese Götter gewesen, wären sie nicht dahin gekommen; doch sie müssen alle auf ewig darin bleiben.
<G-vec00316-003-s223><abide_by.bleiben><en> Surely the guilty shall abide in the chastisement of hell.
<G-vec00316-003-s223><abide_by.bleiben><de> Die Ungläubigen aber werden ewig in der qualvollen Strafe der Hölle bleiben.
<G-vec00316-003-s159><abide_by.einhalten><en> The Humboldt Foundation assumes that candidates will abide by the Rules of Good Scientific Practice during the application and sponsorship periods.
<G-vec00316-003-s159><abide_by.einhalten><de> Die Humboldt-Stiftung setzt voraus, dass bei Bewerbung und Förderung die Regeln guter wissenschaftlicher Praxis und die rechtsverbindlichen Grundsätze der Wissenschaftsethik eingehalten werden.
<G-vec00316-003-s160><abide_by.einhalten><en> Charter times are to be promptly abide by, there are captains and crews that are there to service you.
<G-vec00316-003-s160><abide_by.einhalten><de> Die Charterzeiten müssen schnell eingehalten werden, es gibt Kapitäne und Mannschaften, die für Sie da sind.
<G-vec00316-003-s227><abide_by.festhalten><en> We are only to abide what he says.
<G-vec00316-003-s227><abide_by.festhalten><de> Wir müssen nur an dem festhalten, was er sagt.
<G-vec00316-003-s228><abide_by.festhalten><en> TCT built the following Code of Ethic with the aim to promote safe and fair working conditions, and to be responsible for environmental and social issues, and govern activities with our stakeholders, which include the suppliers, who must abide with our business ethic.
<G-vec00316-003-s228><abide_by.festhalten><de> TCT hat den folgenden etischen Kodex entwickelt, mit dem Ziel sichere und faire Arbeitsbedingungen zu fördern, für umweltschonende und soziale Themen Verantwortung zu übernehmen und Tätigkeiten mit unseren Interessensvertretern, einschließlich der Lieferanten, zu regeln, die an unserer Unternehmensethik festhalten müssen.
<G-vec00316-003-s229><abide_by.festhalten><en> As a basic principle, complaints regarding partial performance do not constitute grounds for refusal of the remaining delivery unless the ordering party can no longer reasonably be expected to abide by the contract.
<G-vec00316-003-s229><abide_by.festhalten><de> Beanstandungen von Teilleistungen berechtigen grundsätzlich nicht zur Ablehnung der Restlieferung, es sei denn, ein Festhalten an dem Vertrag ist dem Besteller nicht mehr zumutbar.
<G-vec00316-003-s233><abide_by.folgen><en> To be spiritually fruitful, love must not simply abide by earthly laws but must let itself be illumined by the truth which is God and must be expressed in that superior measure of justice which is mercy.
<G-vec00316-003-s233><abide_by.folgen><de> Um geistlich fruchtbar zu sein, darf die Liebe nicht bloß den irdischen Gesetzen folgen, sondern muss sich von der Wahrheit, die Gott ist, erleuchten lassen und sich in jenem höheren Maß der Gerechtigkeit zeigen, das die Barmherzigkeit ist.
<G-vec00316-003-s234><abide_by.folgen><en> The industry is in dire need of a shake-up, a revolution of its own with new hotel and restaurant brands that do not abide by these traditional belief systems and shatter the status quo with new fully plant-based concepts that rejuvenate the industry.
<G-vec00316-003-s234><abide_by.folgen><de> Die Gastronomie-Branche muss aufwachen, sie braucht eine Revolution mit neuen Hotels und Restaurants, die nicht diesem traditionellen Glaubenssystem folgen, sondern den Status quo mit komplett pflanzenbasierten Konzepten aufbrechen.
<G-vec00316-003-s235><abide_by.folgen><en> Your continued use of this site after such modifications will constitute your acknowledgment of the modified Terms of Use and agreement to abide and be bound by the modified Terms of Use.
<G-vec00316-003-s235><abide_by.folgen><de> Ihr fortgesetzter Gebrauch dieser Webseite nach solch einer Änderungen wird als eine Anerkennung der modifizierten Benutzungsbedingungen gesehen, und das Sie an die modifizierten Benutzungsbedingungen gebunden sind und ihnen folgen.
<G-vec00316-003-s236><abide_by.folgen><en> “They manage the infrastructure, so we have to abide by their rules,” explains Natale.
<G-vec00316-003-s236><abide_by.folgen><de> "Sie sind es, welche die Infrastruktur bewirtschaften, deshalb müssen wir ihren Regeln folgen", sagt Sonia Natale.
<G-vec00316-003-s237><abide_by.folgen><en> They abide by a simple grid, three spaces wide by three spaces high, with a white, enveloping edge around the outside, resulting in both small and large formats.
<G-vec00316-003-s237><abide_by.folgen><de> Dabei folgen sie einem einfachen Raster, drei Flächen in der Breite, drei Flächen in der Höhe, außen herum ein weißer, zusammenfassender Rand, daraus ergeben sich die kleinen und die größeren Formate.
<G-vec00316-003-s238><abide_by.forenregeln><en> I have read, and agree to abide by the bullterrierforum rules.
<G-vec00316-003-s238><abide_by.forenregeln><de> Ich habe die Forenregeln von Sturmkrähen gelesen und bin damit einverstanden.
<G-vec00316-003-s239><abide_by.forenregeln><en> I have read, and agree to abide by the Hyde Fans rules.
<G-vec00316-003-s239><abide_by.forenregeln><de> Ich habe die Forenregeln von Stilvoll Fischen gelesen und bin damit einverstanden.
<G-vec00316-003-s240><abide_by.forenregeln><en> I have read, and agree to abide by the Vauxhall Viva Forum rules.
<G-vec00316-003-s240><abide_by.forenregeln><de> Ich habe die Forenregeln von Prüfungsfragen Forum - Deine Community zur Prüfungsvorbereitung gelesen und bin damit einverstanden.
<G-vec00316-003-s241><abide_by.forenregeln><en> I have read, and agree to abide by the Fragnet Forums rules.
<G-vec00316-003-s241><abide_by.forenregeln><de> Ich habe die Forenregeln von tutorials.de gelesen und bin damit einverstanden.
<G-vec00316-003-s242><abide_by.forenregeln><en> I have read, and agree to abide by the ETF Talk Forum rules.
<G-vec00316-003-s242><abide_by.forenregeln><de> Ich habe die Forenregeln und die Datenschutzerklärung von Honda-Board gelesen und bin damit einverstanden.
<G-vec00316-003-s243><abide_by.forenregeln><en> I have read, and agree to abide by the Mirth Community rules.
<G-vec00316-003-s243><abide_by.forenregeln><de> Ich habe die Forenregeln von Thelyn Ennor - Forum gelesen und bin damit einverstanden.
<G-vec00316-003-s244><abide_by.forenregeln><en> I have read, and agree to abide by the Free Incest Forum rules.
<G-vec00316-003-s244><abide_by.forenregeln><de> Ich habe die Forenregeln von GIMP-Forum 3.0 gelesen und bin damit einverstanden.
<G-vec00316-003-s245><abide_by.forenregeln><en> I have read, and agree to abide by the Wc3C.net rules.
<G-vec00316-003-s245><abide_by.forenregeln><de> Ich habe die Forenregeln von Deutsches Baseball und Softball Forum gelesen und bin damit einverstanden.
<G-vec00316-003-s246><abide_by.forenregeln><en> I have read, and agree to abide by the Crimeseekers rules. Contact Us
<G-vec00316-003-s246><abide_by.forenregeln><de> Ich habe die Forenregeln von Das Forum für den Google Chrome Browser gelesen und bin damit einverstanden.
<G-vec00316-003-s247><abide_by.forenregeln><en> I have read, and agree to abide by the Gardener's Forums rules.
<G-vec00316-003-s247><abide_by.forenregeln><de> Ich habe die Forenregeln von Freelancer-Foren gelesen und bin damit einverstanden.
<G-vec00316-003-s248><abide_by.forenregeln><en> I have read, and agree to abide by the PC Tweakers Forums rules.
<G-vec00316-003-s248><abide_by.forenregeln><de> Ich habe die Forenregeln von China-RNS.com gelesen und bin damit einverstanden.
<G-vec00316-003-s249><abide_by.forenregeln><en> I have read, and agree to abide by the The PoolForum rules.
<G-vec00316-003-s249><abide_by.forenregeln><de> Ich habe die Forenregeln von Zigarrenforum - Das Forum des guten Geschmacks gelesen und bin damit einverstanden.
<G-vec00316-003-s250><abide_by.forenregeln><en> I have read, and agree to abide by the Ceroc Scotland Forum rules.
<G-vec00316-003-s250><abide_by.forenregeln><de> Ich habe die Forenregeln von ST-Board gelesen und bin damit einverstanden.
<G-vec00316-003-s251><abide_by.forenregeln><en> I have read, and agree to abide by the Forums rules.
<G-vec00316-003-s251><abide_by.forenregeln><de> Ich habe die Forenregeln von Reptilien Forum für Terraristik gelesen und bin damit einverstanden.
<G-vec00316-003-s252><abide_by.forenregeln><en> I have read, and agree to abide by the North Stand Chat rules.
<G-vec00316-003-s252><abide_by.forenregeln><de> Ich habe die Forenregeln von Baumarkt-Forum gelesen und bin damit einverstanden.
<G-vec00316-003-s253><abide_by.forenregeln><en> I have read, and agree to abide by the DragonByte Technologies Ltd.
<G-vec00316-003-s253><abide_by.forenregeln><de> Ich habe die Forenregeln von Das TISCHLERFORUM gelesen und bin damit einverstanden.
<G-vec00316-003-s254><abide_by.forenregeln><en> I have read, and agree to abide by the Galeria Foto rules.
<G-vec00316-003-s254><abide_by.forenregeln><de> Ich habe die Forenregeln von Tierforum Tierstube gelesen und bin damit einverstanden.
<G-vec00316-003-s255><abide_by.forenregeln><en> I have read, and agree to abide by the SimpleLib rules. Contact Us Home
<G-vec00316-003-s255><abide_by.forenregeln><de> Ich habe die Forenregeln von ProgForum.com - Das Elektronik Diskussionsforum gelesen und bin damit einverstanden.
<G-vec00316-003-s256><abide_by.forenregeln><en> I have read, and agree to abide by the Forum:: Travian.cl rules.
<G-vec00316-003-s256><abide_by.forenregeln><de> Ich habe die Forenregeln von E-Zigaretten.info - Das Forum für elektrische Zigaretten gelesen und bin damit einverstanden.
<G-vec00316-003-s035><abide_by.halten><en> Unfortunately, our hands are tied because we too must abide by the laws in force.
<G-vec00316-003-s035><abide_by.halten><de> Leider sind uns die Hände gebunden, denn auch wir müssen uns an Gesetze halten.
<G-vec00316-003-s036><abide_by.halten><en> The 2014 has brought new styles and created for you a base to be modern abide by the rules of the Qur'an and not act as a Muslim without express style.
<G-vec00316-003-s036><abide_by.halten><de> Das Jahr 2014 hat ganz neue Styles hervorgebracht und für Sie eine Basis geschaffen, sich modern an die Regeln des Quran zu halten und als Muslim nicht ohne modische Akzente aufzutreten.
<G-vec00316-003-s295><abide_by.nachkommen><en> We will abide by your request unless we have compelling legitimate grounds for the processing which override your interests and rights, or if we need to continue to process the data for the establishment, exercise or defense of legal claims.
<G-vec00316-003-s295><abide_by.nachkommen><de> Wir werden Ihrer Aufforderung nachkommen, es sei denn, wir haben zwingende Gründe für die Verarbeitung, die Ihre Interessen und Rechte außer Kraft setzen, oder wenn wir die Daten zur Begründung, Ausübung oder Abwehr von Rechtsansprüchen weiterverarbeiten müssen.
<G-vec00316-003-s296><abide_by.nachkommen><en> This should be a choice your partner makes, and you should abide by your partner's wishes.
<G-vec00316-003-s296><abide_by.nachkommen><de> Es liegt in der Hand deines Partners und du solltest seinen Wünschen nachkommen.
<G-vec00316-003-s297><abide_by.nachkommen><en> If the Buyer does not abide by above obligations, the delivery shall be understood as accepted without reservations.
<G-vec00316-003-s297><abide_by.nachkommen><de> Sollte der Abnehmer der obigen Verpflichtungen nicht nachkommen, wird die Lieferung als angenommen ohne Vorbehalte anerkannt.
<G-vec00316-003-s298><abide_by.nehmen><en> Islanders and visitors abide by strict rules to keep it that way Getting to heaven can be a trial.
<G-vec00316-003-s298><abide_by.nehmen><de> Um sie dauerhaft zu schützen, gelten strikte Regeln für Bewohner und Besucher Wer ins Paradies will, muss auch den Weg dorthin auf sich nehmen.
<G-vec00316-003-s299><abide_by.nehmen><en> We ask that you abide by the terms and conditions below.
<G-vec00316-003-s299><abide_by.nehmen><de> Wir bitten Sie die Allgemeinen Geschäftsbedingungen zur Kenntnis zu nehmen.
<G-vec00316-003-s282><abide_by.sich_halten><en> Our Team Leaders and Teachers abide by these basics, which gives our GJJ students the Blue belt program correctly.
<G-vec00316-003-s282><abide_by.sich_halten><de> Unsere Teamleiter und Lehrer halten sich an diese Grundlagen, sodass unsere GJJ-Schüler das Blaugurt-Programm korrekt erhalten.
<G-vec00316-003-s283><abide_by.sich_halten><en> Strictly abide by the Confidential Agreements and never disclose your sales area, ideas of design and all your private information.
<G-vec00316-003-s283><abide_by.sich_halten><de> Halten Sie sich strikt an die Vertraulichkeitsvereinbarungen und geben Sie niemals Ihren Verkaufsbereich, Ihre Designvorstellungen und alle Ihre privaten Informationen preis.
<G-vec00316-003-s284><abide_by.sich_halten><en> They abide by the Anti-Money Laundering (AML) and Know-Your-Customer (KYC) policies put in place to help curb vices in the financial markets and to help boost transparency.
<G-vec00316-003-s284><abide_by.sich_halten><de> Sie halten sich an die Richtlinien zur Bekämpfung von Geldwäsche (AML) und Know-Your-Customer (KYC), die zur Eindämmung der Laster auf den Finanzmärkten und zur Erhöhung der Transparenz eingeführt wurden.
<G-vec00316-003-s333><abide_by.stehen><en> All are His servants and all abide by His bidding!
<G-vec00316-003-s333><abide_by.stehen><de> Alle sind Seine Diener und alle stehen unter Seinem Befehl.
<G-vec00316-003-s334><abide_by.stehen><en> We abide by our jointly developed corporate values.
<G-vec00316-003-s334><abide_by.stehen><de> Wir stehen zu unseren gemeinsam erarbeiteten Unternehmenswerten.
<G-vec00316-003-s335><abide_by.unterliegen><en> You must be a member of the partner's program in which you are transferring Amtrak Guest Rewards points to and abide by that program's rules and regulations in order to exchange points to their currency.
<G-vec00316-003-s335><abide_by.unterliegen><de> Sie müssen ein bestehendes Mitglied des Partnerprogramms sein und unterliegen den Bestimmungen und Vorschriften des Programms, in dessen Währung Sie Ihre Amtrak-Guest-Rewards-Punkte umtauschen möchten.
<G-vec00316-003-s336><abide_by.unterliegen><en> Xbox Game Preview games are available in the Xbox One Marketplace and abide by the same rules around Xbox Live Gold as other available games.
<G-vec00316-003-s336><abide_by.unterliegen><de> Spiele mit Xbox Spielvorschau sind im Xbox One Marketplace verfügbar und unterliegen denselben Bedingungen für Xbox Live Gold wie andere verfügbare Spiele.
<G-vec00316-003-s337><abide_by.unterliegen><en> As a German company we must abide to the very strict and clear regulations of the Federal Data Protection Act.
<G-vec00316-003-s337><abide_by.unterliegen><de> Als deutsches Unternehmen unterliegen wir den sehr eindeutigen und strengen Bestimmungen des Bundesdatenschutzgesetzes.
<G-vec00316-003-s338><abide_by.unterliegen><en> All people of this Earth have to abide by this inexorable Law of Sin and Atonement.
<G-vec00316-003-s338><abide_by.unterliegen><de> Alle Menschen dieser Erde unterliegen diesem unerbittlichen Gesetz von Schuld und Sühne.
<G-vec00316-003-s346><abide_by.verbinden><en> It is very important to note that by accepting a bonus, you are accepting to abide by the wagering requirements it sets out.
<G-vec00316-003-s346><abide_by.verbinden><de> Denken Sie immer daran, dass Sie mit der Annahme eines Bonus automatisch auch die damit verbundenen Umsatzbedingungen akzeptieren.
<G-vec00316-003-s347><abide_by.verbinden><en> You agree to abide by the terms and conditions of purchase imposed by any supplier with whom you elect to deal, including, but not limited to, payment of all amounts when due and compliance with the supplier's rules and restrictions regarding availability and use of fares, products, or services.
<G-vec00316-003-s347><abide_by.verbinden><de> Sie erkennen die mit dem Kauf bei einem von Ihnen gewählten Anbieter verbundenen Bedingungen und Bestimmungen an, einschließlich jedoch nicht beschränkt auf die rechtzeitige Zahlung aller fälligen Beträge und die Konformität mit allen Bestimmungen und Einschränkungen des Anbieters in Bezug auf die Verfügbarkeit und Bereitstellung von Preisen, Produkten oder Services.
<G-vec00316-003-s341><abide_by.verbleiben><en> I bear witness that from eternity Thou wert exalted in Thy transcendent majesty and might, and wilt to eternity abide in Thy surpassing power and glory.
<G-vec00316-003-s341><abide_by.verbleiben><de> Ich bezeuge, daß Du seit Ewigkeit in Deiner überirdischen Majestät und Macht erhaben warst und bis in Ewigkeit in Deiner überragenden Kraft und Herrlichkeit verbleiben wirst.
<G-vec00316-003-s342><abide_by.verbleiben><en> “And may the grace of God the Father, whose throne is high in the heavens, and our Lord Jesus Christ, who sitteth on the right hand of his power, until all things shall become subject unto him, be, and abide with you forever.
<G-vec00316-003-s342><abide_by.verbleiben><de> Und möge die Gnade Gottes, des Vaters, dessen Thron hoch in den Himmeln ist, und unseres Herrn Jesus Christus, der zur rechten Hand seiner Macht sitzt, bis ihm alles unterworfen ist, immerdar mit dir sein und verbleiben.
<G-vec00316-003-s343><abide_by.verbleiben><en> I pray that the blessings of heaven may be and abide with us and all men.
<G-vec00316-003-s343><abide_by.verbleiben><de> Ich bete darum, dass die Segnungen des Himmels bei uns und bei allen übrigen Menschen sein und verbleiben mögen.
<G-vec00316-003-s344><abide_by.verbleiben><en> The words died upon Keawe's tongue; he who bought it could never sell it again, the bottle and the bottle imp must abide with him until he died, and when he died must carry him to the red end of "For God's sake buy it!" he cried.
<G-vec00316-003-s344><abide_by.verbleiben><de> Und wer sie kauft –« Die Worte erstarben auf Keawes Zunge: Wer sie kaufte, der konnte sie niemals wieder verkaufen; die Flasche und der Flaschenteufel mussten bei ihm verbleiben, bis er starb; und wenn er starb, musste er in die rote Höllentiefe fahren.
<G-vec00316-003-s345><abide_by.verbleiben><en> From eternity Thou hast inhabited the loftiest heights of Thy dominion and of Thine unfettered sovereignty, and wilt unto eternity continue to abide in the inaccessible retreats of Thy majesty and glory.
<G-vec00316-003-s345><abide_by.verbleiben><de> Seit Ewigkeit wohnst Du in den erhabensten Höhen Deiner Herrschaft und Deiner unbegrenzten Souveränität, und bis in Ewigkeit wirst Du in der unzugänglichen Zurückgezogenheit Deiner Majestät und Herrlichkeit verbleiben.
<G-vec00316-003-s348><abide_by.verfolgen><en> At Sport-Thieme GmbH, we also abide by the principle of ceasing to use your data for advertising purposes no later than five years after your last contact.
<G-vec00316-003-s348><abide_by.verfolgen><de> Bei der Sport-Thieme GmbH verfolgen wir daneben den Grundsatz, Daten spätestens fünf Jahre nach Ihrem letzten Kontakt zu uns nicht mehr werblich zu nutzen.
<G-vec00316-003-s349><abide_by.verfolgen><en> We abide by a value-oriented growth strategy with long-term objectives.
<G-vec00316-003-s349><abide_by.verfolgen><de> Wir verfolgen eine wertorientierte Wachstumsstrategie mit langfristigen Zielen.
<G-vec00316-003-s350><abide_by.verfolgen><en> And there is little doubt those under 35 do not abide by the same routine as their elders.
<G-vec00316-003-s350><abide_by.verfolgen><de> Demnach gibt es wenig Zweifel daran, dass die unter 35-jährigen nicht dieselben Gewohnheiten verfolgen wie die ältere Generation.
<G-vec00316-003-s199><abide_by.verpflichten><en> By using the website, you indicate that you accept these terms of use and that you agree to abide by them.
<G-vec00316-003-s199><abide_by.verpflichten><de> Anhand der Nutzung unserer Website erklären Sie, dass Sie diese Nutzungsbedingungen akzeptieren und sich zu ihrer Einhaltung verpflichten.
<G-vec00316-003-s200><abide_by.verpflichten><en> By using our site, you indicate that you accept these terms of use and that you agree to abide by them.
<G-vec00316-003-s200><abide_by.verpflichten><de> Durch die Nutzung und den Zugriff auf diese Website zeigen Sie an, dass Sie diese AGB akzeptieren und sich zu ihrer Einhaltung verpflichten.
<G-vec00316-003-s351><abide_by.verweilen><en> I want to be still and abide with You in all my troubles and joys so that I can give myself to You.
<G-vec00316-003-s351><abide_by.verweilen><de> In aller Not, in aller Freude möchte ich bei Dir verweilen und still werden, damit ich mich Dir schenken kann.
<G-vec00316-003-s352><abide_by.verweilen><en> Neither live in the past, My people, for evil and resentful things abide there.
<G-vec00316-003-s352><abide_by.verweilen><de> Lebt auch nicht in der Vergangenheit, Mein Volk, denn böse und nachtragende Dinge verweilen dort.
<G-vec00316-003-s353><abide_by.verweilen><en> If the mind and heart are restless, changeful, unquiet, Ananda of a kind may come, but it is mixed with vital excitement and cannot abide.
<G-vec00316-003-s353><abide_by.verweilen><de> Wenn Mental und Herz rastlos sind, wechselhaft, unruhig, kann ebenfalls eine Art ānanda kommen, doch ist er mit vitaler Erregung vermischt und kann nicht verweilen.
<G-vec00316-003-s359><abide_by.wohnen><en> In saying we are sorry and asking for his help, God forgives us and sends his Spirit to abide in us.
<G-vec00316-003-s359><abide_by.wohnen><de> Wenn wir umkehren und Gott um Hilfe bitten, wird Er uns vergeben und uns Seinen Geist schicken, auf dass er in uns wohne.
<G-vec00316-003-s360><abide_by.wohnen><en> Therefore most delightfully I will glory the more in my infirmities, in order that the power of Christ may abide on me.
<G-vec00316-003-s360><abide_by.wohnen><de> Darum will ich mich am allerliebsten rühmen meiner Schwachheit, auf daß die Kraft Christi bei mir wohne.
