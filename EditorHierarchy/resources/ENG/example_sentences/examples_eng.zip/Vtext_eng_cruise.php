<G-vec00063-002-s128><cruise.cruisen><en> The wheels are perfect for the smooth concrete floor of your skate park and also work great if you want to cruise on rough asphalt through the city.
<G-vec00063-002-s128><cruise.cruisen><de> Die Rollen sind perfekt für den glatten Betonboden deines Skateparks und funktionieren auch super falls du mal auf rauen Asphalt durch die Stadt cruisen möchtest.
<G-vec00063-002-s129><cruise.cruisen><en> That’s why most people learn how to cruise within the first 2-4 hours.
<G-vec00063-002-s129><cruise.cruisen><de> Aus diesem Grund lernen es die meisten innerhalb der ersten 2-4 Stunden einfach hin und her mit dem Foil zu “Cruisen”.
<G-vec00063-002-s130><cruise.cruisen><en> You’ll have an unimaginable amount of space to cruise around and try out new jumps.
<G-vec00063-002-s130><cruise.cruisen><de> Ihr habt unglaublich viel Platz zum cruisen oder zum trainieren von neuen Moves.
<G-vec00063-002-s131><cruise.cruisen><en> sweeps and leisurely trips along the waterside - away from the hustle and bustle of everyday life, you cruise through the charming landscape of Carinthia between...
<G-vec00063-002-s131><cruise.cruisen><de> Anspruchsvolle Pässe, herausfordernde Kehren und gemütliche Touren am Wasser- abseits von Hektik und Lärm cruisen Sie durch die reizvolle Landschaft in Kärnten zwischen Bergen und Seen.
<G-vec00063-002-s132><cruise.cruisen><en> The perfect place to cruise around in your super car.
<G-vec00063-002-s132><cruise.cruisen><de> Es ist der perfekte Ort, um in deinem Supercar durch die Gegend zu cruisen.
<G-vec00063-002-s133><cruise.cruisen><en> A trip to the Tree Island at sunset or a cruise through the reed canals of Weiden are amazing experiences.
<G-vec00063-002-s133><cruise.cruisen><de> Eine Ausfahrt zur Bauminsel bei Sonnenuntergang oder einfach nur das Cruisen in den Weidener Schilfkanälen sind besondere Erlebnisse.
<G-vec00063-002-s134><cruise.cruisen><en> Those who want to can also make do with a rechargeable battery and cruise up to 80 km in the local area – you have the choice.
<G-vec00063-002-s134><cruise.cruisen><de> Wer will, kann sich auch mit einem Akku begnügen und so bis zu 80 km elektrisch durch die Gegend cruisen – du hast die Wahl.
<G-vec00063-002-s135><cruise.cruisen><en> You cruise literally and, although the tyres are allowed up to 210 km/h, one has rarely seen someone at 180 km/h.
<G-vec00063-002-s135><cruise.cruisen><de> Sie cruisen im wahrsten Sinne des Wortes und, obwohl ihre Reifen bis 210 km/h zugelassen sind, hat man selten einen mit 180 km/h erlebt.
<G-vec00063-002-s137><cruise.cruisen><en> And it’s also fun to rent a motorcycle there and cruise up to the chocolate hills.
<G-vec00063-002-s137><cruise.cruisen><de> Und es macht auch einen riesigen Spaß, sich dort ein Motorbike zu mieten und hoch zu den Chocolate Hills zu cruisen.
<G-vec00063-002-s138><cruise.cruisen><en> Of course, care is taken to ensure that the time spent on the boat is fairly distributed and that every co-owner can cruise the Mediterranean during the peak and off-peak season.
<G-vec00063-002-s138><cruise.cruisen><de> Dabei wird selbstverständlich darauf geachtet, dass die Zeit auf dem Boot fair verteilt wird und jeder Co-Owner in der Haupt- und Nebensaison übers Mittelmeer cruisen kann.
<G-vec00063-002-s139><cruise.cruisen><en> On the Pacific Coast Highway we will cruise through the beautiful Coromandel area to Whitianga.
<G-vec00063-002-s139><cruise.cruisen><de> Auf dem Pacific Coast Highway cruisen wir heute durch die wunderschöne Coromandel-Gegend nach Whitianga.
<G-vec00063-002-s140><cruise.cruisen><en> With large and soft wheels help ensure a good feeling when you cruise through the city.
<G-vec00063-002-s140><cruise.cruisen><de> Mit großen weichen Räder helfen, ein gutes Gefühl zu gewährleisten, wenn Sie durch die Stadt cruisen.
<G-vec00063-002-s141><cruise.cruisen><en> Only e-bikes offer the flexibility to get in a workout, ride with a faster friend, haul a heavy load or simply cruise.
<G-vec00063-002-s141><cruise.cruisen><de> Nur E-Bikes bieten die Flexibilität, Sport zu treiben, mit einem schnelleren Freund mitzuhalten, schwere Lasten zu transportieren oder einfach nur zu cruisen.
<G-vec00063-002-s142><cruise.cruisen><en> Demanding passes, challenging sweeps and leisurely trips along the waterside - away from the hustle and bustle of everyday life, you cruise through the charming landscape of sweeps and leisurely trips along the waterside - away from the hustle and bustle of everyday life, you cruise through the charming landscape of Carinthia between mountains and lakes.
<G-vec00063-002-s142><cruise.cruisen><de> Grenzenlose Freiheit im Dreiländereck 07.05.2017 bis 17.07.2017 Anspruchsvolle Pässe, herausfordernde Kehren und gemütliche Touren am Wasser- abseits von Hektik und Lärm cruisen Sie durch die reizvolle Landschaft in Kärnten zwischen Bergen und Seen.
<G-vec00063-002-s143><cruise.cruisen><en> Whether on a sporty ride, on the way to work, on the way for shopping or on a relaxing cruise in the nature: Experience the fascination of the eBike firsthand always when you are on the way.
<G-vec00063-002-s143><cruise.cruisen><de> Ob auf sportlichen Touren, auf dem Weg zur Arbeit, unterwegs zum Shopping oder beim entspannten Cruisen in der Natur: Erleben Sie die Faszination eBike hautnah, wo immer Sie unterwegs sind.
<G-vec00063-002-s144><cruise.cruisen><en> Today we will pick up our motorcycles at the rental station and cruise first to the north along the Costa del Sol.
<G-vec00063-002-s144><cruise.cruisen><de> Heute übernehmen wir unsere Motorräder an der Vermietstation und cruisen zunächst entlang der Costa del Sol nach Norden.
<G-vec00063-002-s145><cruise.cruisen><en> Surprises and twists are overrated anyway, so viewers have to switch to autopilot and cruise through the problems and battles until the pre-programmed end.
<G-vec00063-002-s145><cruise.cruisen><de> Überraschungen und Wendungen werden ohnehin überbewertet, deswegen müssen Zuschauer auf Autopilot schalten und durch die Probleme und Schlachten bis zum vorprogrammierte Ende cruisen.
<G-vec00063-002-s146><cruise.cruisen><en> Let the little ones, with the child’s wooden balance bicycle with name engraving, cruise safely through the countryside.
<G-vec00063-002-s146><cruise.cruisen><de> Lassen Sie die Kleinen mit dem Kinderlaufrad aus Holz mit Gravur sicher durch die Landschaft cruisen.
<G-vec00063-002-s181><cruise.fahren><en> With its infrastructure support, the Initiative Musik will build an expressway on which many artists will be able to cruise at high speed.
<G-vec00063-002-s181><cruise.fahren><de> Die Initiative Musik gGmbH wird mit der Infrastrukturförderung eine Autobahn bauen, auf der viele Künstler schnell fahren können.
<G-vec00063-002-s182><cruise.fahren><en> Over the course of 3 hours, you’ll cruise from Darling Harbour past landmarks like the Opera House and Harbour Bridge.
<G-vec00063-002-s182><cruise.fahren><de> Im Laufe von 3 Stunden fahren Sie vom Darling Harbour aus vorbei an Sehenswürdigkeiten wie dem Opernhaus und der Harbour Bridge.
<G-vec00063-002-s183><cruise.fahren><en> On this private tour you’ll cruise through the parks and streets of Berlin on an easy-to-ride Segway.
<G-vec00063-002-s183><cruise.fahren><de> Auf dieser privaten Tour fahren Sie mit einem einfach zu fahrenden Segway durch die Parks und Straßen Berlins.
<G-vec00063-002-s184><cruise.fahren><en> Afterwards, see pearls being cultured on a tour of the pearl museum or cruise Roebuck Bay on an old pearl lugger.
<G-vec00063-002-s184><cruise.fahren><de> Sehen Sie anschließend bei einer Tour durch das Perlenmuseum wie Perlen gezüchtet werden oder fahren Sie mit einem alten Perlenlogger durch die Roebuck Bay.
<G-vec00063-002-s185><cruise.fahren><en> Overview Experience the magic of Menorca at sunset as you sail around the island on this 2-hour, 45-minute catamaran cruise.
<G-vec00063-002-s185><cruise.fahren><de> Übersicht Erleben Sie den Zauber von Menorca bei Sonnenuntergang, während Sie auf dieser Bootstour von 2 Stunden und 45 Minuten mit dem Katamaran um die Insel fahren.
<G-vec00063-002-s186><cruise.fahren><en> Whereas you can cruise mostly surfaced in the early stages of the war it's quite suicidal to do that later as many radar-equipped planes are on patrol and will very likely catch you off guard.
<G-vec00063-002-s186><cruise.fahren><de> Während man in den früheren Kriegsjahren meistens an der Oberfläche fahren kann, wird dies später fast selbstmörderisch da sehr viele mit Radar ausgestattete Flugzeuge den Seeraum patrouillieren und einen früher oder später kalt erwischen werden.
<G-vec00063-002-s187><cruise.fahren><en> You’ll cruise comfortably aboard one of the biggest boats operating from Exmouth on the Ningaloo Reef and the friendly and experienced skipper and crew are always on hand to assist and enhance your Whale Shark swim.
<G-vec00063-002-s187><cruise.fahren><de> Sie fahren an Bord eines der größten zwischen Exmouth und dem Ningaloo-Riff operierenden Boote und der freundliche, erfahrene Skipper und seine Crew stehen Ihnen zur Seite und bereichern Ihre Walhaie-Begegnung.
<G-vec00063-002-s188><cruise.fahren><en> A wedding in Italy is not a drive in a Ferrari, it is something to be taken slowly and savoured; sometimes we cruise and relish the view; later we might step on the gas and enjoy the thrill of the ride.
<G-vec00063-002-s188><cruise.fahren><de> In Italien ist eine Hochzeit keine rasante Fahrt mit einem Ferrari, wir haben es gerne langsam und genussvoll – manchmal fahren wir spazieren und genießen die Aussicht, dann wieder treten wir aufs Gas und freuen uns am Tempo.
<G-vec00063-002-s189><cruise.fahren><en> In a luxurious cruise boat, you are taken along beautiful imposing canal-side houses with clock, spout and neck gables, the Zevenbogenbruggengracht, the Magere Bridge over the Amstel, the VOC-ship and the docks.
<G-vec00063-002-s189><cruise.fahren><de> Sie fahren in einem luxuriös ausgestatteten Tagestourenboot an den schönen beeindruckenden Grachtenhäuse mit Uhr-, Schnabel- und Halsfassaden, der Zevenbogenbruggengracht, der Magere Brücke über der Amstel, dem Schiff der Vereinigten Ostindischen Kompagnie (VOC) und dem Hafen vorbei.
<G-vec00063-002-s190><cruise.fahren><en> You should therefore only cruise on the river if you are certain of having access to the Zennegat lock (Louvain- Dijle Canal: operations only 4 hours before to 4 hours after high water, VHF channel 20) or the Lower Lock at Mechelen (Keerdok: operated from 3.5 hours before to 3.5 hours after high water, tel. 015 20 22 56.)
<G-vec00063-002-s190><cruise.fahren><de> Fahren Sie den Fluss also nur hinauf, wenn Sie sicher durch die Schleuse Zennegat (Kanal Leuven-Dijle: Bedienung nur 4 Stunden vor bis 4 Stunden nach der Flut, UKW 20) oder die untere Schleuse Mechelen kommen (Keerdok: Bedienung 3,5 Stunden vor bis 3,5 Stunden nach Hochwasser, VHF 20 oder T 015 20 22 56).
<G-vec00063-002-s191><cruise.fahren><en> Then we'll cruise to Kas, a small harbour town with a bohemian atmosphere here you will be able to see interesting the murals along the harbour wall.
<G-vec00063-002-s191><cruise.fahren><de> Dann fahren wir nach Kas, einer kleinen Hafenstadt mit Boheme Atmosphäre - werfe einen Blick auf die Wandgemälde entlang der Hafenwand.
<G-vec00063-002-s192><cruise.fahren><en> Early this morning we will cruise along the coast, past the spectacular Seven Capes and the long Patara Beach, to Firnaz Bay, near Kalkan, where breakfast will be served and guests can have a swim.
<G-vec00063-002-s192><cruise.fahren><de> Früh am Morgen fahren wir entlang der Küste, vorbei an den spektakulären sieben Kappen und dem langen Patara Strand, zur Firnaz Bucht nahe Kalkan, wo Frühstück serviert wird und die Gäste schwimmen können.
<G-vec00063-002-s193><cruise.fahren><en> A 0600hrs morning river cruise up the Kinabatangan River to Kelenanap oxbow lake to view more birds and wildlife.
<G-vec00063-002-s193><cruise.fahren><de> Um 6 Uhr morgens fahren Sie in einem Boot den Fluss hinauf zum Kelenanap Oxbow See um noch mehr Vögel und andere heimische Tiere zu beobachten.
<G-vec00063-002-s194><cruise.fahren><en> At the beginning of dusk more than 100 boats of any kind and size – all decorated with electrical Christmas lights – cruise through the canals.
<G-vec00063-002-s194><cruise.fahren><de> Über 100 Boote jeder Art und Größe – mit kostümierten Passagieren und geschmückt mit elektrischen Weihnachtslichtern - fahren bei Anbruch der Dunkelheit durch die Kanäle.
<G-vec00063-002-s195><cruise.fahren><en> Without this licence you won’t be able to cruise on these waterways.
<G-vec00063-002-s195><cruise.fahren><de> Ohne diese Lizenz können Sie nicht auf diesen Wasserwegen fahren.
<G-vec00063-002-s196><cruise.fahren><en> You will also cruise through the vast inland lake, the Etang de Thau, which is also good for swimming and is warmer than the Med.
<G-vec00063-002-s196><cruise.fahren><de> Außerdem fahren Sie durch den großen Binnensee, dem Etang de Thau, der sich ebenfalls gut zum Schwimmen eignet und sogar wärmer als das Mittelmeer ist.
<G-vec00063-002-s197><cruise.fahren><en> As you calmly cruise through the thriving streets of the city, high above the hustle and the bustle of the pavement, you will be able to learn all about the history that lies behind every landmark you pass thanks to our earphone service in a choice of 12 different languages.
<G-vec00063-002-s197><cruise.fahren><de> Während Sie in aller Ruhe durch die belebten Straßen der Stadt fahren, hoch über dem Trubel und der Hektik auf den Bürgersteigen, haben Sie die Möglichkeit, alles über die Geschichte, die hinter jedem Wahrzeichen steckt zu erfahren, dank unserem Audioguide mit einer Auswahl von 12 verschiedene Sprachen.
<G-vec00063-002-s198><cruise.fahren><en> Follow in the footsteps of Beatrix Potter as you visit her home at Hill Top, see William Wordsworth’s former school in Hawkshead and cruise across Windermere, England’s largest lake.
<G-vec00063-002-s198><cruise.fahren><de> Folgen Sie den Spuren von Beatrix Potter, während Sie ihr Haus in Hill Top besuchen, William Wordsworths ehemalige Schule in Hawkshead besuchen und über Windermere, Englands größten See, fahren.
<G-vec00063-002-s199><cruise.fahren><en> You’ll cruise through sites showcased in some of the city’s most iconic films, walk in the steps the stars have and even hear exclusive, behind the scenes stories about some of your favorite actors.
<G-vec00063-002-s199><cruise.fahren><de> Sie fahren durch Drehorte, die in einigen der legendärsten Filme der Stadt zu sehen waren, verfolgen die Schritte der Stars und hören sogar exklusiven Geschichten von hinter den Kulissen über einige Ihre Lieblingsstars.
<G-vec00063-002-s200><cruise.fahren><en> Cruise in comfort during your scenic tour of Newport and Jamestown while enjoying a complimentary quahog "stuffie" and champagne toast.
<G-vec00063-002-s200><cruise.fahren><de> Fahren Sie bequem während Ihrer malerischen Tour durch Newport und Jamestown, während Sie ein kostenloses Quahog "Stuffie" und Champagner Toast genießen.
<G-vec00063-002-s201><cruise.fahren><en> Cruise to Anguilla on a power catamaran on this 7-hour tour from St. Maarten.
<G-vec00063-002-s201><cruise.fahren><de> Fahren Sie auf dieser 7-stündigen Tour ab St. Maarten mit einem Katamaran nach Anguilla.
<G-vec00063-002-s202><cruise.fahren><en> Cruise along Lake Las Vegas with a cable line to propel you along and pick up speed as you zip across the water.
<G-vec00063-002-s202><cruise.fahren><de> Fahren Sie entlang des Lake Las Vegas mit einer Seilschnur, um Sie mitzunehmen und beschleunigen Sie sich beim Überqueren des Wassers.
<G-vec00063-002-s203><cruise.fahren><en> Get lost in medieval castles, cruise through rolling uplands and shallow valleys and learn about World War II history in this storied Western European region.
<G-vec00063-002-s203><cruise.fahren><de> Verirren Sie sich in mittelalterlichen Burgen, fahren Sie durch hügelige Hochebenen und flache Täler und erfahren Sie mehr über die Geschichte des Zweiten Weltkriegs in dieser sagenumwobenen westeuropäischen Region.
<G-vec00063-002-s204><cruise.fahren><en> Cruise along the Manavgat River on the western slopes of the Taurus Mountains on a 7-hour tour from Alanya.
<G-vec00063-002-s204><cruise.fahren><de> Kundenbewertung ☆☆☆☆☆ Fahren Sie auf dem Manavgat entlang des Taurusgebirges bei einer siebenstündigen Tour ab Alanya.
<G-vec00063-002-s205><cruise.fahren><en> Cruise to the island of Delos to stroll around the UNESCO-listed ruins.
<G-vec00063-002-s205><cruise.fahren><de> Fahren Sie zur Insel Delos, um die UNESCO-geschützten Ruinen zu erkunden.
<G-vec00063-002-s206><cruise.fahren><en> Cruise along the city’s edge on the St. Lawrence River taking pictures of where modern and old architecture collide.
<G-vec00063-002-s206><cruise.fahren><de> Fahren Sie entlang der Stadt am Sankt-Lorenz-Strom und fotografieren Sie, wo moderne und alte Architektur aufeinanderprallen.
<G-vec00063-002-s207><cruise.fahren><en> Cruise back to Forcalquier and take in views of gardens and villages during the journey.
<G-vec00063-002-s207><cruise.fahren><de> Fahren Sie zurück nach Forcalquier und genießen Sie die Aussicht auf Gärten und Dörfer während der Reise.
<G-vec00063-002-s208><cruise.fahren><en> Cruise on country roads through the flowering tulips and park your Twizy beside the road to admire the sea of flowers up close.
<G-vec00063-002-s208><cruise.fahren><de> Fahren Sie auf Landstraßen durch die blühenden Tulpen und parken Sie Ihren Twizy neben der Straße, um das Meer der Blumen aus nächster Nähe zu bewundern.
<G-vec00063-002-s209><cruise.fahren><en> Cruise past the erupting Kīlauea Volcano by night & alongside the stunning cliffs of the Nā Pali Coast by day.
<G-vec00063-002-s209><cruise.fahren><de> Fahren Sie nachts am aktiven Vulkan Kīlauea vorbei und tagsüber an den beeindruckenden Kliffs der Nā Pali Küste.
<G-vec00063-002-s210><cruise.fahren><en> Get acquainted with the area’s complex history and cruise past legendary monuments like the Abbey of St-Etienne, a structure considered one of Normandy’s most impressive Romanesque structures.
<G-vec00063-002-s210><cruise.fahren><de> Machen Sie sich mit der komplexen Geschichte der Region vertraut und fahren Sie vorbei an legendären Monumenten wie der Abtei von Saint-Étienne, einem Gebäude, das als eines der beeindruckendsten romanischen Bauwerke der Normandie gilt.
<G-vec00063-002-s211><cruise.fahren><en> Cruise along the River Garonne on a 1.5-hour wine tasting tour of Bordeaux.
<G-vec00063-002-s211><cruise.fahren><de> Fahren Sie auf der Garonne in Bordeaux bei einer 1,5-stündigen Bootsfahrt mit Weinprobe.
<G-vec00063-002-s212><cruise.fahren><en> Cruise around the beautiful island of Capri by boat and get amazing views of its natural attractions, including the stunning sea caves of the Blue Grotto and the magnificent Faraglioni rocks.
<G-vec00063-002-s212><cruise.fahren><de> Kundenbewertung ☆☆☆☆☆ Fahren Sie um die wundervolle Insel Capri mit einem Boot und genießen Sie die atemberaubende Aussicht auf die Natur-Attraktionen.
<G-vec00063-002-s213><cruise.fahren><en> Cruise the waves by luxury speed boat, paddle hidden inlets by sea-canoe, and enjoy sunset views—with national park fees and snorkelling equipment included. Learn More Free Cancellation
<G-vec00063-002-s213><cruise.fahren><de> Fahren Sie mit dem Luxus-Schnellboot durch die Wellen, paddeln Sie mit einem Kanu durch versteckte Buchten und genießen Sie die Aussicht auf den Sonnenuntergang - inklusive Nationalparkgebühren und Schnorchelausrüstung.
<G-vec00063-002-s214><cruise.fahren><en> Cruise down the Corinth Canal.
<G-vec00063-002-s214><cruise.fahren><de> Fahren Sie auf dem Kanal von Korinth.
<G-vec00063-002-s215><cruise.fahren><en> Then, cruise by boat back to Sydney Harbour on the Parramatta River.
<G-vec00063-002-s215><cruise.fahren><de> Anschließend fahren Sie mit dem Boot zurück zum Hafen von Sydney am Parramatta River.
<G-vec00063-002-s216><cruise.fahren><en> On this full-day tour from Nha Trang, cruise out across the bay and visit up to five different islands.
<G-vec00063-002-s216><cruise.fahren><de> Fahren Sie auf dieser ganztägigen Tour von Nha Trang aus über die Bucht und besuchen Sie bis zu fünf verschiedene Inseln.
<G-vec00063-002-s217><cruise.fahren><en> Cruise on Jamaica's bioluminescent Luminous Lagoon during this nighttime excursion.
<G-vec00063-002-s217><cruise.fahren><de> Fahren Sie während dieser nächtlichen Exkursion durch Jamaikas biolumineszierende Leuchtende Lagune.
<G-vec00063-002-s218><cruise.fahren><en> If you just want to cruise halfday you can go over and have a lunch in Melchsee-Frutt and then cruise back and take the lift from Engstlen up to Jochpass and back to Engelberg.
<G-vec00063-002-s218><cruise.fahren><de> Wenn Sie nur einen halben Tag am Rad verbringen möchten, essen Sie in Melchsee-Frutt zu Mittag, fahren Sie zurück und nehmen Sie den Lift von Engstlen auf den Jochpass und zurück nach Engelberg.
<G-vec00063-002-s219><cruise.fahren><en> INCLUDES SKIP-THE-LINE TICKETS FOR LOUVRE MUSEUM, SKIP-THE-LINE TICKETS FOR MONTPARNASSE, A CRUISE THROUGH THE SEINE, A 1-WAY TRANSFER FROM THE AIRPORT TO the city center, A 3-DAY VALID METRO CARD and 20% discount on Paris' top attractions.
<G-vec00063-002-s219><cruise.fahren><de> Ok Buchen EINSCHLIESSLICH TICKETS OHNE WARTESCHLANGEN FÜR DAS LOUVRE MUSEUM, TICKETS OHNE WARTESCHLANGEN FÜR MONTPARNASSE, EINE FAHRT ÜBER DIE SEINE, EINE FAHRT VOM FLUGHAFEN ZUM STADTZENTRUM, EINE U-BAHN-KARTE MIT 3-TÄGIGER GÜLTIGKEIT UND 20% RABATT FÜR DIE BESTEN ATTRAKTIONEN IN PARIS.
<G-vec00063-002-s220><cruise.fahren><en> October–March: one cruise per hour.
<G-vec00063-002-s220><cruise.fahren><de> Oktober-März: eine Fahrt pro Stunde.
<G-vec00063-002-s221><cruise.fahren><en> You’ll continue your evening with a charming cruise along the Seine.
<G-vec00063-002-s221><cruise.fahren><de> Sie setzen Ihren Abend mit einer reizvollen Fahrt auf der Seine fort.
<G-vec00063-002-s222><cruise.fahren><en> Bratislava – Vienna Regular Cruises by Hydrofoil 1 hour and 45 minutes long cruise by a hydrofoil express boat from the Bratislava’s downtown to Vienna including crossing of the lock chambers in Freudenau.
<G-vec00063-002-s222><cruise.fahren><de> Die Fahrt mit dem Tragflügelboot aus dem Zentrum Bratislava in Richtung Wien einschließlich der Übersegelung der Schleusenkammer (Schleuse Freudenau) in Freudenau dauert 1 Stunde und 45 Minuten.
<G-vec00063-002-s223><cruise.fahren><en> All in all, for our first cruise, we neede 4500 liters of gas, 13.75 kilowatt respectively.
<G-vec00063-002-s223><cruise.fahren><de> Insgesamt haben wir für die erste Fahrt 4500 Liter Gas, also rund 13,75 Kilowatt verbraucht.
<G-vec00063-002-s224><cruise.fahren><en> Sadly not such a good cruise as previously experienced.
<G-vec00063-002-s224><cruise.fahren><de> Leider nicht so eine gute Fahrt wie zuvor erlebt.
<G-vec00063-002-s225><cruise.fahren><en> Apart from the scientific program, the M120 cruise includes a capacity building program for scientists and technicians from our Angolan, Namibian and Senegalese project partner institutes which is promoted by both projects.
<G-vec00063-002-s225><cruise.fahren><de> Zusätzlich zu den wissenschaftlichen Arbeiten wird auf der Fahrt ein Ausbildungsprogramm für Wissenschaftler und Techniker der afrikanischen Projektpartner aus Angola, Namibia und Senegal durchgeführt, welches von beiden Projekten unter stützt wird.
<G-vec00063-002-s226><cruise.fahren><en> One cruise takes about 45 minutes.
<G-vec00063-002-s226><cruise.fahren><de> Eine Fahrt dauert ungefähr 45 Minuten.
<G-vec00063-002-s227><cruise.fahren><en> A cruise on Göta Canal is refreshing for both body and soul, and takes you on a ride through an amazing landscape.
<G-vec00063-002-s227><cruise.fahren><de> Eine Fahrt auf dem Göta-Kanal ist beruhigend für Körper und Geist und nimmt Sie mit auf eine Reise durch eine fantastische Natur.
<G-vec00063-002-s228><cruise.fahren><en> After a few hours the cruise will continue along the Sognefjord, the world's longest and deepest fjord, to the fjord village of Balestrand.
<G-vec00063-002-s228><cruise.fahren><de> Nach ein paar Stunden geht die Fahrt weiter in den Sognefjord, den weltweit längsten und tiefsten Fjord, zu der Fjordstadt Balestrand.
<G-vec00063-002-s229><cruise.fahren><en> In the morning we pick you up at your hotel in Saigon and take you to Can Tho. You board your wooden river cruise vessel around noon.
<G-vec00063-002-s229><cruise.fahren><de> Morgens holen wir Sie in Saigon am Hotel ab und bringen Sie zur Ablegestelle in Cai Be (etwa 2 Stunden Fahrt).
<G-vec00063-002-s230><cruise.fahren><en> We are so sorry that we do not see him on our cruise.
<G-vec00063-002-s230><cruise.fahren><de> Schade, dass wir uns daher auf unserer Fahrt nicht wiedersehen.
<G-vec00063-002-s231><cruise.fahren><en> Other ways to take in Norway's breathtaking scenery are by taking a fjord cruise or the Ulriksbanen aerial tramway (which has a top height of over 600 metres).
<G-vec00063-002-s231><cruise.fahren><de> Auch mit einem Ausflug durch die Fjorde oder einer Fahrt mit der Ulriksbanen-Luftseilbahn (mit einer Spitzenhöhe von über 600 Metern) kann man in den Genuss der atemberaubenden Landschaft Norwegens kommen.
<G-vec00063-002-s232><cruise.fahren><en> The bespoke vessel employs classic stainless steel portlights, teak sole decks, high bulwarks, and a massive garage that can store multiple water toys as you cruise.
<G-vec00063-002-s232><cruise.fahren><de> Das maßgeschneiderte Schiff verfügt über klassische Edelstahlfenster, Teakholzsohlendecks, hohe Bollwerke und eine massive Garage, in der Sie während der Fahrt mehrere Wasserspielzeuge unterbringen können.
<G-vec00063-002-s233><cruise.fahren><en> If the cruise by speedboat or catamaran is not enough for you, in this case the Divoká Voda areal in Čunovo is for you.
<G-vec00063-002-s233><cruise.fahren><de> Wenn Ihnen die Fahrt mit dem Schnellboot oder dem Katamaran noch immer nicht genug ist, dann gibt es hier noch das Wildwasserareal in Čuňovo.
<G-vec00063-002-s234><cruise.fahren><en> During this cruise we pass 2 locks.
<G-vec00063-002-s234><cruise.fahren><de> Diese Fahrt führt durch 2 Schleusen.
<G-vec00063-002-s235><cruise.fahren><en> No matter where you cruise Germany, maybe the wine region Rhine-Moselle-Valley, the Neckar Valley to step by in Heidelberg or eventually the river Elbe on your way through Germany from Berlin to Prague - cruise Germany for an unforgettable journey through Germany.
<G-vec00063-002-s235><cruise.fahren><de> Egal wohin Ihre Fahrt geht, möglicherweise in die Weinregion Rhein-Mosel-Tal, durch das Neckar-Tal vorbei an Heidelberg oder vielleicht von Berlin nach Prag - Ihre Kreuzfahrt wird sicher eine unvergessliche Reise durch Deutschland.
<G-vec00063-002-s236><cruise.fahren><en> If you decide to take the cruise on the river after your dinner at Les Ombres, you may get the chance to watch the sun setting over Paris.
<G-vec00063-002-s236><cruise.fahren><de> Wenn Sie sich nach dem Abendessen im Les Ombres für eine Fahrt auf dem Wasser entscheiden, haben Sie vielleicht die Möglichkeit, den Sonnenuntergang über Paris zu sehen.
<G-vec00063-002-s237><cruise.fahren><en> Just returned from my 3rd cruise on the IOS in as many years.
<G-vec00063-002-s237><cruise.fahren><de> Gerade aus meiner dritten Fahrt auf dem IOS in ebenso vielen Jahren zurückgekehrt.
<G-vec00063-002-s505><cruise.reisen><en> Born and raised on the Lycian cost and with more than 20 years of seafaring experience, Ilyas has the perfect foundation to realize your wishes and meet your needs during a Blue Cruise.
<G-vec00063-002-s505><cruise.reisen><de> Mehr als 20 Jahre Erfahrung in der Schifffahrt, geboren und aufgewachsen an der lykischen Küste sind das Fundament, um Ihre Wünsche und Bedürfnisse während einer "Blauen Reise" optimal umzusetzen.
<G-vec00063-002-s506><cruise.reisen><en> Your cruise starts in Bergen, a city surrounded by seven mountains.
<G-vec00063-002-s506><cruise.reisen><de> Ihre Reise beginnt in Bergen, das von sieben Bergen eingerahmt ist.
<G-vec00063-002-s507><cruise.reisen><en> You can easily charter Gulet Fatma Kristina by Guletyacht.co.uk and then sail on an unforgettable cruise.
<G-vec00063-002-s507><cruise.reisen><de> Sie können Yacht Faustina einfach bei Guletyacht.de chartern und dann eine unvergessliche reise machen.
<G-vec00063-002-s508><cruise.reisen><en> Calculate the amount you would like to donate to non-profit-making climate projects to offset your cruise – and we will cover 25 %.
<G-vec00063-002-s508><cruise.reisen><de> Errechnen Sie sich den freiwilligen Kompensationsbeitrag für Ihre Reise – 25 % davon übernehmen wir – als Spende für gemeinnützige Klimaprojekte.
<G-vec00063-002-s509><cruise.reisen><en> On the 18th of May my boyfriend Karsten will visit me on AIDAbella and if everything works out fine my brother & my mum will come one cruise later.
<G-vec00063-002-s509><cruise.reisen><de> Am 18.05. kommt Karsten mich auf der AIDAbella besuchen und wenn’s gut geht kommt auch mein Bruder und meine Mama eine Reise später.
<G-vec00063-002-s510><cruise.reisen><en> The volcanic Deception Island is an unforgettable sight to bring your cruise to a close.
<G-vec00063-002-s510><cruise.reisen><de> Den unvergesslichen Abschluss Ihrer Reise bildet die Vulkaninsel Deception Island.
<G-vec00063-002-s511><cruise.reisen><en> You can also hire Bonaparte yacht for your blue cruise especially for and other close regions.
<G-vec00063-002-s511><cruise.reisen><de> Sie können die Alessandro Yacht insbesondere für Ihre blaue Reise in Santorini, aber auch andere Regionen mieten.
<G-vec00063-002-s512><cruise.reisen><en> At the end of a cruise, you go home.
<G-vec00063-002-s512><cruise.reisen><de> Nach Beendigung Ihrer Reise kommen Sie nach Hause.
<G-vec00063-002-s513><cruise.reisen><en> After the end of the cruise, the bonus miles will be credited to your bonus mile account.
<G-vec00063-002-s513><cruise.reisen><de> Nach Ende der Reise werden die Bonusmeilen auf Ihrem Bonusmeilenkonto gutgeschrieben.
<G-vec00063-002-s514><cruise.reisen><en> You can easily charter Gulet Sailing Nour by Guletyacht.net and then sail on an unforgettable cruise.
<G-vec00063-002-s514><cruise.reisen><de> Sie können Yacht Gulmaria einfach bei Guletyacht.de chartern und dann eine unvergessliche reise machen.
<G-vec00063-002-s515><cruise.reisen><en> Your cruise ends on Bali – which is perhaps the start of your post-cruise programme*.
<G-vec00063-002-s515><cruise.reisen><de> Auf Bali endet Ihre Reise – vielleicht der Start für Ihr Nachprogramm*.
<G-vec00063-002-s516><cruise.reisen><en> The best starting point for the "Blue Cruise" is Bodrum
<G-vec00063-002-s516><cruise.reisen><de> Auch ist Bodrum der ideale Ausgangspunkt für eine Blaue Reise.
<G-vec00063-002-s517><cruise.reisen><en> Of course, we do not know the route and destination of your cruise yet.
<G-vec00063-002-s517><cruise.reisen><de> Wir wissen natürlich noch nicht, wohin Ihre Reise gehen soll.
<G-vec00063-002-s518><cruise.reisen><en> While planning our cruise still in Germany, we were attracted by the magic of the name: Great Dismal Swamp.
<G-vec00063-002-s518><cruise.reisen><de> Schon bei der Planung unserer Reise in Deutschland, waren wir fasziniert von der Idee, diese historische Wasserstrasse auf eigenem Kiel zu erleben.
<G-vec00063-002-s519><cruise.reisen><en> The first leg of cruise M 60 aims at physical, biogeochemical and biological sampling in the framework of the EU project OASIS (OceAnic Seamounts: an Integrated Study).
<G-vec00063-002-s519><cruise.reisen><de> Der erste Fahrtabschnitt der Reise M 60 dient der physikalischen, biogeochemischen und biologischen Probengewinnung im Rahmen des EU- Projektes OASIS (OceAnic Seamounts: an Integrated Study).
<G-vec00063-002-s520><cruise.reisen><en> The Cruise Terminal located at Pointe de Floride has all the necessary facilities for a high-quality welcome of passengers in transit or embarking on a cruise, and crew members: Tourist Information Point with distribution of multilingual maps and brochures, registration counters, luggage scanning, control and storage area, customs office and border police, lounge, boutique, car & bike hire, free Wifi, toilets, defibrillator.
<G-vec00063-002-s520><cruise.reisen><de> Das Kreuzfahrtterminal an der Pointe de Floride verfügt über die passende Ausstattung um einen hochwertigen Empfang der Passagiere, in Transit oder zu Beginn/Ende ihrer Reise sowie für die Besatzung zu gewährleisten: Informationspunkt mit mehrsprachigen Plänen und Broschüren, Check-in-Schalter, Gepäck-Kontrolle (Scanner) und –Aufbewahrung, Zoll- und Grenzpolizei, Ruhebereich, Boutique, Fahrzeug- und Fahrradvermietung, kostenloses WLAN, Toiletten, Defibrillator.
<G-vec00063-002-s521><cruise.reisen><en> The cruise lasts about 40 minutes.
<G-vec00063-002-s521><cruise.reisen><de> Die Reise dauert etwa 40 Minuten.
<G-vec00063-002-s522><cruise.reisen><en> This is the last report before the end of the cruise.
<G-vec00063-002-s522><cruise.reisen><de> Dies ist der letzte Beitrag vor Beendigung der Reise.
<G-vec00063-002-s523><cruise.reisen><en> This is a popular area for tourists to Turkey because it is characterised by small coves and beautiful bays and is therefore a favoured stop over for visitors taking the Blue Cruise along Turkey's south west coast.
<G-vec00063-002-s523><cruise.reisen><de> Dies ist ein beliebtes Gebiet für Touristen in der Türkei, weil sie von kleinen, wunderschönen Buchten besteht und ist daher ein beliebter Zwischenstopp für Besucher unter die Blaue Reise entlang der Türkei Südwestküste.
