<G-vec00681-002-s211><blow_out.jagen><en> You get into an automobile, you turn an ignition switch, and you set off a series of somewhere between four and eight explosions, and you have no fear that you’re going to blow up even though you have an internal combustion engine right at your knees.
<G-vec00681-002-s211><blow_out.jagen><de> Ihr steigt in ein Auto, schaltet die Zündung ein und löst eine Serie von vier bis acht Explosionen aus und habt keine Angst, euch selbst in die Luft zu jagen, obwohl direkt an euren Knien ein Verbrennungsmotor ist.
<G-vec00681-002-s212><blow_out.jagen><en> Personally, I'm hoping for the latter, because I'd rather not blow myself up.
<G-vec00681-002-s212><blow_out.jagen><de> Ich persönlich hoffe, es ist letzteres, denn eigentlich möchte ich mich nicht in die Luft jagen.
<G-vec00681-002-s213><blow_out.jagen><en> This scene also stands for the steady „survival of the Roma“, who are still there even if others blow up or destroy their homes.
<G-vec00681-002-s213><blow_out.jagen><de> Diese Szene steht auch für das stetige „Überleben der Roma“, die selbst dann noch da sind wenn andere ihre Häuser in die Luft jagen oder zerstören.
<G-vec00681-002-s214><blow_out.jagen><en> Said Mike Janov, VFX supervisor, SPY, “One of the things we did extensively in our shots for ‘Priest’ was blow stuff up.
<G-vec00681-002-s214><blow_out.jagen><de> Mike Janov, VFX Supervisor bei SPY, erklärt: „Für „Priest“ haben wir uns besonders ausführlich damit befasst, Sachen in die Luft zu jagen.
<G-vec00681-002-s215><blow_out.jagen><en> Convincing healthy individuals to blow themselves up is obviously not easy, but requires ideas and institutions.
<G-vec00681-002-s215><blow_out.jagen><de> Gesunde Individuen davon zu überzeugen sich selbst in die Luft zu jagen, ist offenbar nicht leicht, sondern bedarf Ideen und Institutionen.
<G-vec00681-002-s216><blow_out.jagen><en> Those bastards have sent a bunch of idiots that are going to blow up the whole area.
<G-vec00681-002-s216><blow_out.jagen><de> Jene Bastarde haben eine Gruppe von Idioten geschickt, die das ganze Gebiet in die Luft jagen werden.
<G-vec00681-002-s217><blow_out.jagen><en> You were sent to blow up the base.
<G-vec00681-002-s217><blow_out.jagen><de> Du wurdest geschickt, um die Basis in die Luft zu jagen.
<G-vec00681-002-s218><blow_out.sprengen><en> My mom was worried to see me always return home very late and more than once threatened to blow up the Fine Arts department (seen in today’s situation in the world, her words may sound threatening, but then it was just a joke).
<G-vec00681-002-s218><blow_out.sprengen><de> Meine Mutter drohte, da sie mein spätes Heimkommen beunruhigte, damit, die Kunstabteilung im Gymnasium in die Luft zu sprengen (bei der heutigen Weltlage klingt das sehr bedrohlich, damals aber war das eher wie ein Scherz).
<G-vec00681-002-s219><blow_out.sprengen><en> Heidi then follows Angela, and tells her about Nathan's "conspiracy" to blow up New York with Peter.
<G-vec00681-002-s219><blow_out.sprengen><de> Heidi folgt daraufhin Angela und erzählt ihr von Nathans "Verschwörung", mit Peter New York City in die Luft zu sprengen.
<G-vec00681-002-s220><blow_out.sprengen><en> Khaled and Said, good friends since their childhood, have been chosen as suicide bombers and are expected to blow themselves up in Tel Aviv.
<G-vec00681-002-s220><blow_out.sprengen><de> Khaled und Said, seit ihrer Kindheit gute Freunde, sind dazu bestimmt worden, sich als Selbstmordattentäter in Tel Aviv in die Luft zu sprengen.
<G-vec00681-002-s221><blow_out.sprengen><en> . BELGIUM – Captured fugitive Salah Abdeslam initially planned to blow himself up outside the Stade de France during the Paris attacks but changed his mind, a prosecutor said Saturday, after Europe’s most wanted man was charged with “terrorist murder” for his role in the November assaults.
<G-vec00681-002-s221><blow_out.sprengen><de> Salah Abdeslam wollte sich laut der französischen Staatsanwaltschaft bei den Angriffen in Paris in die Luft sprengen Das habe er nach seiner Festnahme am Freitag in Brüssel den belgischen Ermittlern gesagt, teilte der Pariser Staatsanwalt François Molins mit.
<G-vec00681-002-s222><blow_out.sprengen><en> The station even proposed to headquarters through back channels that a squad be on hand at the moment of the coup to storm the [Communist] Chinese embassy, kill everyone inside, steal their secret records, and blow up the building to cover the facts.
<G-vec00681-002-s222><blow_out.sprengen><de> Er schlug dem Hauptquartier sogar vor, dass man eine geheime Spezialeinheit aufstellen solle, um während des Putsches die [kommunistische] chinesische Botschaft zu stürmen, alle Insassen zu killen, alle geheimen Dokumente zu stehlen und das Gebäude in die Luft zu sprengen, um alles zu vertuschen.
<G-vec00681-002-s223><blow_out.sprengen><en> Hedges can be shot out of a cannon to blow up if they interfere with the movement.
<G-vec00681-002-s223><blow_out.sprengen><de> Hedges kann aus einer Kanone geschossen werden, um die Luft zu sprengen, wenn sie mit der Bewegung stören.
<G-vec00681-002-s224><blow_out.sprengen><en> In 1955 there was a permission given to blow up the „Goering’s dacha” (as the people the building had been called amongst the citizens).
<G-vec00681-002-s224><blow_out.sprengen><de> Im Jahre 1955 kam die Erlaubnis, die „Datsche von Göring” – so wurde dieses Objekt von der Bevölkerung genannt – in die Luft zu sprengen.
<G-vec00681-002-s225><blow_out.sprengen><en> For years now – and on an almost daily basis – Muslims have been unscrupulously described in newspapers and talk shows as people who blow themselves up, style themselves as "Sharia police", oppress women, are intolerant of anyone with opposing views and who quite simply spread terror.
<G-vec00681-002-s225><blow_out.sprengen><de> In Zeitungen und Talkshows werden Muslime seit Jahren beinahe täglich auf hemmungslose Weise als Menschen beschrieben, die sich in die Luft sprengen, sich als "Scharia-Polizisten" aufspielen, Frauen unterdrücken, intolerant gegenüber Andersdenkenden sind und schlicht Terror verbreiten.
<G-vec00681-002-s306><blow_out.sprengen><en> Like all the puzzle bobble style games, you have to form clusters of at least 3 same colored balls to blow them up.
<G-vec00681-002-s306><blow_out.sprengen><de> Wie alle Puzzle Bobble-Stil-Spiele, haben Sie Cluster aus mindestens 3 gleichfarbigen Kugeln zu bilden, um sie zu sprengen.
<G-vec00681-002-s307><blow_out.sprengen><en> Use explosives to blow up walls.
<G-vec00681-002-s307><blow_out.sprengen><de> Benutze Sprengstoff um die Wände zu sprengen.
<G-vec00681-002-s308><blow_out.sprengen><en> Allegedly he rejected the stability pact only because he thought he could get more concessions for the City of London, concessions that – as I was told – the City did not even ask for and held not important enough to blow up a European Council for it.
<G-vec00681-002-s308><blow_out.sprengen><de> Es heißt, Cameron hätte sich der Einigung über den Stabilitätspakt nur widersetzt, weil er angeblich noch weitere Konzessionen für die City of London herausholen wollte, Konzessionen, die die City – wie mir gesagt wurde – keineswegs für wichtig genug hielt um dafür einen Europäischen Rat zu sprengen.
<G-vec00681-002-s309><blow_out.sprengen><en> Use explosives to blow up those buildings. Controls
<G-vec00681-002-s309><blow_out.sprengen><de> Wende die Bomben an um die Gebäude zu sprengen.
<G-vec00681-002-s310><blow_out.sprengen><en> To list all possible activities here would probably blow up the content of our small website.
<G-vec00681-002-s310><blow_out.sprengen><de> Alle möglichen Aktivitäten hier anzugeben würde wohl den Inhalt unserer kleinen Website sprengen.
<G-vec00681-002-s311><blow_out.sprengen><en> I get around a rock that stands in my way, until I have enough powder to blow it up; I get around the laws of a people, until I’ve gathered the strength to overthrow them.
<G-vec00681-002-s311><blow_out.sprengen><de> Einen Felsen, der Mir im Wege steht, umgehe Ich so lange, bis Ich Pulver genug habe, ihn zu sprengen; die Gesetze eines Volkes umgehe Ich, bis Ich Kraft gesammelt habe, sie zu stürzen.
<G-vec00681-002-s312><blow_out.sprengen><en> Set your dynamite in the right places and blow the bridge when the convoy is trying to cross.
<G-vec00681-002-s312><blow_out.sprengen><de> Stellen Sie Ihren Dynamit an den richtigen Stellen und sprengen die Brücke, wenn der Konvoi versucht zu überqueren.
<G-vec00681-002-s313><blow_out.sprengen><en> Our Karina will blow your idea of sensuality and eroticism.
<G-vec00681-002-s313><blow_out.sprengen><de> Unsere Karina wird Ihre Vorstellung von Sinnlichkeit und Erotik sprengen.
<G-vec00681-002-s314><blow_out.sprengen><en> Too powerful Takata airbags, which can blow up parts of the metal paneling and throw them through the vehicle interior, have been causing problems for the automobile industry for years.
<G-vec00681-002-s314><blow_out.sprengen><de> Zu kräftig auslösende Takata-Airbags, die Teile der Metallverkleidung sprengen und durch den Fahrzeuginnenraum schleudern können, machen der Autoindustrie seit Jahren zu schaffen.
<G-vec00681-002-s315><blow_out.sprengen><en> My heart is beating so hard that it seems to blow my chest.
<G-vec00681-002-s315><blow_out.sprengen><de> Mein Herz schlägt so hart, dass es mir die Brust zu sprengen scheint.
<G-vec00681-002-s316><blow_out.sprengen><en> ** When you Forming a swastika Elimination you will get Butterfly which can help you blow the obstacles. Features:
<G-vec00681-002-s316><blow_out.sprengen><de> ** Wenn Sie eine Hakenkreuz Beseitigung bilden, erhalten Sie Schmetterling, der Ihnen helfen kann, die Hindernisse zu sprengen.
<G-vec00681-002-s317><blow_out.sprengen><en> MDB is especially used when a system is comprised of several complex subsystems or creating a necessary prototype would blow the project budget both financially and timewise.
<G-vec00681-002-s317><blow_out.sprengen><de> Diese kommt speziell dann zur Anwendung, wenn eine Anlage aus mehreren komplexen Teilsystemen besteht oder die Erstellung eines notwendigen Prototyps das zeitliche und finanzielle Projektbudget sprengen würde.
<G-vec00681-002-s318><blow_out.sprengen><en> Blow up numbered blocks, catch bonus specials and power ups.
<G-vec00681-002-s318><blow_out.sprengen><de> Nummerierte Blöcke sprengen Sie, fangen Sie Bonus Spezialitäten und Power-UPS.
<G-vec00681-002-s319><blow_out.sprengen><en> If we were to apply the same standard to Hamas that Goldstone applies here to Israel, we would have grounds to doubt that ‘the crimes allegedly committed by Hamas were intentional’, given the extreme rarity of ‘deaths and injuries to civilians’ in a context in which Hamas might just as reasonably be found to have been trying harmlessly to blow holes in the ground, to aid in planting, perhaps.
<G-vec00681-002-s319><blow_out.sprengen><de> Wenn man die Hamas nach dem gleichen Maß messen würde, nach Goldstone Israel hier mißt, gäbe es Grund zu zweifeln, daß „die von der Hamas angeblich begangenen Verbrechen vorsätzlich waren“, da es zu „zivilen Todesfällen und Verletzten“ äußerst selten gekommen war in einem Zusammenhang, in dem man zu dem ebenso angemessenen Schluß kommen könnte, die Hamas hätte (womöglich zur Förderung der Landwirtschaft) harmlose Löcher in den Boden sprengen wollen.
<G-vec00681-002-s320><blow_out.sprengen><en> At Demolition Game you need to blow up all the buildings and towers using your dynamite.
<G-vec00681-002-s320><blow_out.sprengen><de> In diesem Spiel musst du alle Gebäude und Türme mit dem Dynamit sprengen.
<G-vec00681-002-s321><blow_out.sprengen><en> In fewer words still I will blow it to pieces, so that not a trace of it remains.
<G-vec00681-002-s321><blow_out.sprengen><de> Mit noch weniger Worten werde ich ihn in Stücke sprengen, so, daß auch nicht eine Spur von ihm bleibt.
<G-vec00681-002-s322><blow_out.sprengen><en> Already in the first months of your baby learns to blow bubbles, say aga, hoot and something to sing in only his understandable language.
<G-vec00681-002-s322><blow_out.sprengen><de> Bereits in den ersten Monaten lernt Ihr Baby, Blasen zu sprengen, Aga zu sagen, zu jubeln und etwas zu singen, nur in seiner verständlichen Sprache.
<G-vec00681-002-s323><blow_out.sprengen><en> When there is too much pressure in the cooker, the steam that is supposed to blow off through the safety valve is liable to blow the lid off instead.
<G-vec00681-002-s323><blow_out.sprengen><de> Und wenn der Druck im Kessel zu groß geworden ist, droht der Dampf, wenn er nicht mehr durch das Ventil entweichen kann, den Deckel zu sprengen.
<G-vec00681-002-s324><blow_out.sprengen><en> Blow up your friend: In the Skirmish Mode, set up custom fleets and battle human or computer-controlled enemies. Systemkrav
<G-vec00681-002-s324><blow_out.sprengen><de> Sprengen Sie Ihren Freund in die Luft: Im Skirmish Modus können Sie mit Ihren eigenen Flotten gegen andere Spieler oder computergesteuerte Feinde kämpfen.
<G-vec00681-002-s349><blow_out.wegblasen><en> This Grungy Bubble Texture pack is simply bubbling and bursting with 10 super high res textures that will blow you away.
<G-vec00681-002-s349><blow_out.wegblasen><de> Diese Grungy Bubble Texture Pack ist einfach sprudeln und platzen mit 10 super High Res Texturen, die Sie wegblasen wird.
<G-vec00681-002-s350><blow_out.wegblasen><en> The dust blower in BOSCH jigsaws deflects some of the cooling air to blow the sawdust off the cut line. Top
<G-vec00681-002-s350><blow_out.wegblasen><de> Mit der Späneblasvorrichtung bei BOSCH-Stichsägen wird ein Teil der Kühlluft abgezweigt und zum Wegblasen der Späne benützt.
<G-vec00681-002-s351><blow_out.wegblasen><en> This revolutionary smoking device will blow you away.
<G-vec00681-002-s351><blow_out.wegblasen><de> Dieses revolutionäre Rauchgerät wird Dich wegblasen.
<G-vec00681-002-s352><blow_out.wegblasen><en> I know that they are built very solid, a big storm can't blow them away, however, they don't look real anymore.
<G-vec00681-002-s352><blow_out.wegblasen><de> Ich weiß, dass sie sehr solide gebaut sind, ein großer Sturm kann sie nicht wegblasen, wie auch immer, sie schauen nicht echt aus.
<G-vec00681-002-s353><blow_out.wegblasen><en> I can dispense foul odours and adjust my scalp temperature and sometimes (I swear) I can blow the beam of the reading light an inch or two away from my nose.
<G-vec00681-002-s353><blow_out.wegblasen><de> Ich kann auf übelriechende Gerüche verzichten und die Temperatur meiner Kopfhaut abstimmen und manchmal (ich schwöre es) kann ich den Strahl meines Leselichts einen Inch (2,5 cm) oder zwei von meiner Nase wegblasen.
