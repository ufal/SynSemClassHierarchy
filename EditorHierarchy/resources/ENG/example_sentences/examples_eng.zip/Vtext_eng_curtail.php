<G-vec00118-002-s004><curtail.beschneiden><en> Furthermore, a constitutional amendment would be required to curtail the president’s unfettered access to the security forces.
<G-vec00118-002-s004><curtail.beschneiden><de> Zudem bedürfte es einer Verfassungsänderung, um den uneingeschränkten Zugriff des Präsidenten auf die Sicherheitskräfte zu beschneiden.
<G-vec00118-002-s006><curtail.beschneiden><en> Now it's time to curtail their nationalism.
<G-vec00118-002-s006><curtail.beschneiden><de> Jetzt ist es an der Zeit, ihren Nationalismus zu beschneiden.
<G-vec00118-002-s007><curtail.beschneiden><en> Western democracies too are preparing to curtail some of the basic Internet freedoms currently available.
<G-vec00118-002-s007><curtail.beschneiden><de> Westliche Demokratien schicken sich ebenfalls an, einige der aktuell vorhandenen Grundfreiheiten im Internet zu beschneiden.
<G-vec00118-002-s008><curtail.beschneiden><en> When the Norwegian King tried to curtail the privileges of the Hanseatic merchants in 1284, they simply cancelled commercial trade and no longer supplied any grain.
<G-vec00118-002-s008><curtail.beschneiden><de> Als 1284 der norwegische König die Privilegien der Hansekaufleute zu beschneiden versuchte, brachen diese die Handelsbeziehungen einfach ab und lieferten kein Getreide mehr.
<G-vec00118-002-s009><curtail.beschneiden><en> There’s a reason why authoritarian regimes try to shut themselves off from the free flow of information and cultural influences, why they try to curtail the freedom of the Internet.
<G-vec00118-002-s009><curtail.beschneiden><de> Es hat einen Grund, dass autoritäre Regime versuchen, sich abzuschotten von freier Information und kulturellem Einfluss, dass sie versuchen, die Freiheit des Internet zu beschneiden.
<G-vec00118-002-s010><curtail.beschneiden><en> Like the ruling class in the US, European governments have used the guise of the “war on terror” to curtail democratic rights and establish veritable police states.
<G-vec00118-002-s010><curtail.beschneiden><de> Ähnlich wie die herrschende Klasse in den USA nutzen die europäischen Regierungen den Deckmantel des „Kriegs gegen den Terror“, um demokratische Rechte zu beschneiden und einen regelrechten Polizeistaat zu errichten.
<G-vec00118-002-s011><curtail.beschneiden><en> Primitive marriage did not much curtail man’s sex liberties, but it did render further sex license taboo to the wife.
<G-vec00118-002-s011><curtail.beschneiden><de> Die primitive Ehe beschnitt die sexuellen Freiheiten des Mannes nicht besonders, hingegen war für die Frau außerehelicher Geschlechtsverkehr tabu.
<G-vec00118-002-s036><curtail.beschneiden><en> The President of the Federation, the German Professor and Doctor in Law, Lutz Simon justifies the request by virtue of the adoption by the Ponta Government of emergency decrees which drastically curtail the rights of Romania’s Constitutional Court and the «Peoples’ Lawyer».
<G-vec00118-002-s036><curtail.beschneiden><de> Der Präsident des Verbandes, Prof. Dr. Dr. Dr. Lutz Simon, begründet die Forderung mit den Notverordnungen der Regierung Ponta, in denen die Rechte des Verfassungsgerichts und des Volksanwalts beschnitten werden.
<G-vec00118-002-s012><curtail.beschränken><en> German Labour Minister Andrea Nahles wants to severely curtail EU migrants' access to social benefits.
<G-vec00118-002-s012><curtail.beschränken><de> Bundesarbeitsministerin Andrea Nahles will die Sozialleistungen für EU-Ausländer deutlich beschränken.
<G-vec00118-002-s013><curtail.beschränken><en> Such biases, the authors conclude, might curtail the success of such morphs and perhaps even contribute to the low frequencies in which they occur.
<G-vec00118-002-s013><curtail.beschränken><de> Diese einseitige Erfahrung, so schließen die Autoren, könnte den Erfolg solcher Morphen beschränken und vielleicht sogar dazu beitragen, dass sie so selten sind.
<G-vec00118-002-s014><curtail.beschränken><en> The Islamic reaction has exploited the publication of a few cartoons of the Prophet Mohammad to intimidate the western press and media and curtail their freedom.
<G-vec00118-002-s014><curtail.beschränken><de> Die islamischen Reaktionäre haben die Veröffentlichung einiger Cartoons des Propheten Mohammad ausgenutzt, um die westliche Presse und die Medien einzuschüchtern und ihre Freiheit zu beschränken.
<G-vec00118-002-s015><curtail.eindämmen><en> Nor did the deal curtail Iran’s violent and destabilizing activity in Afghanistan, Iraq, Lebanon, Syria, Yemen, and Gaza.
<G-vec00118-002-s015><curtail.eindämmen><de> Auch hat das Abkommen die gewalttätigen und destabilisierenden Aktivitäten Irans in Afghanistan, Syrien, dem Irak, Libanon, Jemen und dem Gazastreifen nicht eingedämmt.
<G-vec00118-002-s020><curtail.eindämmen><en> Burroughs was a libertarian with a paranoid view of government that was out to curtail freedoms on different levels.
<G-vec00118-002-s020><curtail.eindämmen><de> Burroughs war ein Libertärer mit einer paranoiden Sicht auf die Regierung, die darauf aus war, Freiheiten auf verschiedenen Ebenen einzudämmen.
<G-vec00118-002-s021><curtail.eindämmen><en> Armed with this data, users can intricately fine-tune their B2B sales and operations to better curtail these costs, or to better utilize the segments that are the most profitable for the business.
<G-vec00118-002-s021><curtail.eindämmen><de> Anhand dieser Daten können Nutzer dann ihre B2B Aktivitäten exakt anpassen, um diese Kosten einzudämmen oder die Segmente besser zu nutzen, die für das Unternehmen am profitabelsten sind.
<G-vec00118-002-s003><curtail.einschränken><en> You also have the right to request that it be corrected or deleted or to curtail its use.
<G-vec00118-002-s003><curtail.einschränken><de> Sie haben das Recht, die Berichtigung, Löschung dieser Daten zu verlangen, oder deren Bearbeitung einzuschränken.
<G-vec00118-002-s017><curtail.einschränken><en> In the last years of his life he died in 1153 Bernard was obliged to curtail his journeys but did not entirely stop travelling.
<G-vec00118-002-s017><curtail.einschränken><de> In den letzten Jahren seines Lebens – der Tod ereilte ihn im Jahr 1153 – musste Bernhard die Reisen einschränken, ohne sie allerdings völlig zu unterbrechen.
<G-vec00118-002-s018><curtail.einschränken><en> The ongoing European sovereign debt crisis could strongly curtail Lufthansa Group's financing options and increase its financing costs.
<G-vec00118-002-s018><curtail.einschränken><de> Die anhaltende europäische Staatsschuldenkrise könnte die Finanzierungsmöglichkeiten der Lufthansa Gruppe stark einschränken und ihre Finanzierungskosten erhöhen.
<G-vec00118-002-s022><curtail.einschränken><en> The main reason behind the monitoring of workforce is to prevent unacceptable behavior is at first place and to curtail such behavior that can destroy the business.
<G-vec00118-002-s022><curtail.einschränken><de> Der Hauptgrund für die Überwachung der Arbeitskräfte ist es, inakzeptables Verhalten zunächst zu verhindern und ein solches Verhalten einzuschränken, das das Geschäft zerstören kann.
<G-vec00118-002-s023><curtail.einschränken><en> In addition, most Stora Enso sawmills plan to take extended Christmas breaks to curtail production and adjust inventory levels.
<G-vec00118-002-s023><curtail.einschränken><de> Zusätzlich plant Stora Enso die Produktion von Sägewerken im Hinblick auf die Einführung der russischen Exportabgaben in voller Höhe einzuschränken.
<G-vec00118-002-s024><curtail.einschränken><en> It allowed them to strengthen the military and the apparatus of state repression and to curtail democratic rights.
<G-vec00118-002-s024><curtail.einschränken><de> Er erlaubte ihnen das Militär und den staatlichen Repressionsapparat zu stärken und demokratische Rechte einzuschränken.
<G-vec00118-002-s027><curtail.mindern><en> However, the Socialists & Democrats underline that the aim is not to stabilize this unemployment but that it is crucial to curtail it.
<G-vec00118-002-s027><curtail.mindern><de> Die Sozialdemokratische Fraktion unterstreicht jedoch, dass es nicht das Ziel ist, die Arbeitslosigkeit auf diesem Niveau zu stabilisieren, sondern dass sie unbedingt gemindert werden muss.
<G-vec00118-002-s030><curtail.reduzieren><en> 1917: Mr Jones of Des Moines has patented his anti-masturbation overalls – they “curtail self-abuse in both sexes”.
<G-vec00118-002-s030><curtail.reduzieren><de> 1917: Herr Jones von Des Moines hat seine Anti-Masturbations-Overalls patentiert - sie „reduzieren den Selbstmissbrauch bei beiden Geschlechtern“.
<G-vec00118-002-s033><curtail.verkürzen><en> Pheoby promises to curtail any nasty talk about Janie among the women.
<G-vec00118-002-s033><curtail.verkürzen><de> Pheoby verspricht, das böse Gerede über Janie in der Stadt zu verkürzen.
<G-vec00118-002-s035><curtail.verringern><en> He can reduce your movement speed by 50% or curtail your healing by 50% whilst you receive percentage damage.
<G-vec00118-002-s035><curtail.verringern><de> Er reduziert eure Bewegungsgeschwindigkeit um 50% oder verringert eure erhaltene Heilung um 50%, während ihr prozentual Schaden erleidet.
