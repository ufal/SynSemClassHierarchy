<G-vec00620-002-s003><berate.auszanken><en> Look at the all the people who fall in love, and then fall out of love and berate themselves that once they loved where now they no longer do.
<G-vec00620-002-s003><berate.auszanken><de> Schau mal alle Menschen an, die sich verlieben und dann nicht mehr verliebt sind und sich dann selbst auszanken, weil sie einst geliebt haben und jetzt nicht mehr lieben.
<G-vec00620-002-s004><berate.beschimpfen><en> Both berate him, laugh at him and verbally insult him again and again with humiliating gestures.
<G-vec00620-002-s004><berate.beschimpfen><de> Beide beschimpfen ihn, lachen ihn aus und beleidigen ihn immer wieder verbal und mit erniedrigenden Gesten.
<G-vec00620-002-s006><berate.schimpfen><en> Don't berate yourself––all beginners experience the inner chatter.
<G-vec00620-002-s006><berate.schimpfen><de> Schimpfe nicht mit dir – alle Anfänger erleben das innerliche Geschwätz.
<G-vec00620-002-s007><berate.tadeln><en> Whatever you do, don't congratulate yourself too much or berate yourself either.
<G-vec00620-002-s007><berate.tadeln><de> Was Sie auch tun loben Sie sich nicht soviel und tadeln Sie sich nicht.
