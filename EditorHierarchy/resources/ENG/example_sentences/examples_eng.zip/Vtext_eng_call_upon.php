<G-vec00485-002-s038><call_upon.abrufen><en> Get phone call logs history with Location Read more...
<G-vec00485-002-s038><call_upon.abrufen><de> Abrufen des Anrufprotokollverlaufs mit Standort Mehr erfahren...
<G-vec00485-002-s039><call_upon.abrufen><en> In future the air conditioning will link up to my smartphone via an interface provided by the manufacturer and an app and call up my settings – temperature, ventilator, off.
<G-vec00485-002-s039><call_upon.abrufen><de> In Zukunft wird sich die Klimaanlage über ein Interface des Herstellers und eine App mit meinem Smartphone verbinden und meine Einstellungen abrufen – Temperatur, Ventilator, Off-Einstellung.
<G-vec00485-002-s040><call_upon.abrufen><en> Topped off by the intelligent design, athletes can call up their optimum performance - both during workout and in competition.
<G-vec00485-002-s040><call_upon.abrufen><de> Abgerundet durch das intelligente Design können Sportler Ihre optimale Leistung abrufen – sowohl beim Workout als auch im Wettkampf.
<G-vec00485-002-s041><call_upon.abrufen><en> No profound mission stimulating thought - design, like Clayman with his "Zero," no deliberation is announced here, just follow the orders and do your thing, and call on your abilities, to exist in this mission, which is called "go, go, go..." from beginning to end.
<G-vec00485-002-s041><call_upon.abrufen><de> Kein tiefgründiges, zum Denken anregendes Mission – Design, wie Clayman mit seinem „Zero“, kein Überlegen ist hier angesagt, nein den Orders folgen und Deinen Dienst tun und Dein Können abrufen, um in dieser Mission zu bestehen, die von Anfang bis Ende „go,go,go...“ heißt.
<G-vec00485-002-s042><call_upon.abrufen><en> Drivers can call up camera images and receive alarm alerts during their trip.
<G-vec00485-002-s042><call_upon.abrufen><de> Während der Fahrt kann der Fahrer Kamerabilder abrufen und Alarmmeldungen empfangen.
<G-vec00485-002-s043><call_upon.abrufen><en> VitaDock® Online from Medisana makes it possible to save, call up, evaluate and export your personal vital data such as blood pressure, blood sugar, blood oxygen, body temperature, weight and activity.
<G-vec00485-002-s043><call_upon.abrufen><de> VitaDock® Online von Medisana ermöglicht das Speichern, Abrufen, Auswerten und Exportieren Ihrer persönlichen Vitaldaten wie Blutdruck, Blutzucker, Blutsauerstoff, Körpertemperatur, Gewicht und Aktivität.
<G-vec00485-002-s044><call_upon.abrufen><en> Therefore, you should have a high –tech tool that empowers you to get the Voip call history logs.
<G-vec00485-002-s044><call_upon.abrufen><de> Daher sollten Sie über ein Hightech-Tool verfügen, mit dem Sie die Voip-Anrufprotokolle abrufen können.
<G-vec00485-002-s045><call_upon.abrufen><en> In NoRA, you can call up the abstract of any of the standards, and for the majority of standards also the table of contents.
<G-vec00485-002-s045><call_upon.abrufen><de> Sie können über NoRA zu jeder Norm das Kurzreferat und in den meisten Fällen auch das Inhaltsverzeichnis abrufen.
<G-vec00485-002-s046><call_upon.abrufen><en> With the monitoring tools, users can call up and view the system’s performance online at any time.
<G-vec00485-002-s046><call_upon.abrufen><de> Mit Monitoring-Tools kann der Nutzer die Leistung der Anlage jederzeit online abrufen.
<G-vec00485-002-s047><call_upon.abrufen><en> Intelligent service starts in your BMW X6 from where you can call up your service status at any time.
<G-vec00485-002-s047><call_upon.abrufen><de> Im BMW M3 Coupé können Sie jederzeit den Service-Status abrufen.
<G-vec00485-002-s048><call_upon.abrufen><en> In addition, you can easily go with a few clicks the Our company call in order to find us easily.
<G-vec00485-002-s048><call_upon.abrufen><de> Darüber hinaus können Sie bequem unterwegs mit ein paar Klicks den Standort unserer Firma abrufen damit Sie uns leicht finden.
<G-vec00485-002-s049><call_upon.abrufen><en> If you call up this website from inside the Provincial Government Buildings, there is no limit on the 'Addressee' field, but your own Province e-mail address has to be in the 'Sender' field.
<G-vec00485-002-s049><call_upon.abrufen><de> Wenn Sie diese Website innerhalb des Gouvernements abrufen, gilt keine Einschränkung für das Feld 'Adressat', doch im Feld 'Absender' sollte Ihre Provinz-E-Mail-Adresse stehen.
<G-vec00485-002-s050><call_upon.abrufen><en> Our partners can call up special additional services directly at the POS with a personal password.
<G-vec00485-002-s050><call_upon.abrufen><de> Mit einem persönlichen Passwort können unsere Partner am Point of Sale die besonderen Zusatzleistungen abrufen.
<G-vec00485-002-s051><call_upon.abrufen><en> Should you call up pages and files within our site and thus be asked to enter data about yourself, we hereby give notice that such data transmission via the internet is not secure, and that these data can thus be seen by unauthorised persons, or can be forged.
<G-vec00485-002-s051><call_upon.abrufen><de> Wenn Sie innerhalb unseres Angebotes Seiten und Dateien abrufen und dabei aufgefordert werden, Daten über sich einzugeben, so weisen wir darauf hin, dass diese Datenübertragung über das Internet ungesichert erfolgt, die Daten somit von Unbefugten zur Kenntnis genommen oder auch verfälscht werden können.
<G-vec00485-002-s052><call_upon.abrufen><en> In the future, marketing will increasingly become a service, as users are able to call up additional information via tags and communicate directly with the retailer.
<G-vec00485-002-s052><call_upon.abrufen><de> Künftig wird Marketing immer mehr zum Service, indem User über Tags Zusatzinformationen abrufen und mit dem Händler direkt kommunizieren können.
<G-vec00485-002-s053><call_upon.abrufen><en> I do not leave you without a fight to my opponent but I can only oppose him with love and therefore also call you away out of love when the only thing that you can still expect on earth is death, spiritual death, which is so terrible that I take pity and want to protect you from it.
<G-vec00485-002-s053><call_upon.abrufen><de> Ich überlasse euch nicht kampflos Meinem Gegner, doch nur mit Liebe kann Ich ihm gegenübertreten und also auch aus Liebe euch abrufen, wenn ihr auf Erden nur noch den Tod zu erwarten habt, den geistigen Tod, der so entsetzlich ist, daß es Mich erbarmet und Ich euch davor bewahren will.
<G-vec00485-002-s054><call_upon.abrufen><en> This saves time, for example, when the operator can call data required from CAD/CAM applications directly from the TNC control.
<G-vec00485-002-s054><call_upon.abrufen><de> Das spart Zeit, wenn Sie direkt von der TNC-Steuerung fehlende Daten aus CAD/CAM-Anwendungen abrufen können.
<G-vec00485-002-s055><call_upon.abrufen><en> The user can for example call up video sequences that show the changing of the film roll and the film knife.
<G-vec00485-002-s055><call_upon.abrufen><de> Der Bediener kann zum Beispiel Videosequenzen abrufen, die den Folienrollen- und Folienmesserwechsel zeigen.
<G-vec00485-002-s056><call_upon.abrufen><en> In addition, the website operator can also recognize which subpages you call up on the page, as each page call ends up in a so-called log file.
<G-vec00485-002-s056><call_upon.abrufen><de> Zudem kann der Webseitenbetreiber erkennen, welche Unterseiten Sie auf der Seite abrufen, da jeder Seitenabruf in einer sogenannten Log-Datei landet.
<G-vec00485-002-s133><call_upon.anrufen><en> Automatically saves your device's call history to a calendar.
<G-vec00485-002-s133><call_upon.anrufen><de> Speichert Anrufe automatisch im Kalender Ihres Geräts.
<G-vec00485-002-s134><call_upon.anrufen><en> It displays the list of recent call that you have made or received.
<G-vec00485-002-s134><call_upon.anrufen><de> Es wird die Liste der zuletzt durchgeführten oder angenommenen Anrufe angezeigt.
<G-vec00485-002-s135><call_upon.anrufen><en> But when I call you never seem to be home
<G-vec00485-002-s135><call_upon.anrufen><de> Aber wenn ich anrufe scheinst du nie Zuhause zu sein.
<G-vec00485-002-s136><call_upon.anrufen><en> Login Mobile Spy Package, Monitor GPS locations, Call, SMS, Videos, Photos and Social Media and much more.
<G-vec00485-002-s136><call_upon.anrufen><de> Login Mobiles Spionagepaket, Überwachung von GPS-Standorten, Anrufe, SMS, Videos, Fotos und Social Media und vieles mehr.
<G-vec00485-002-s137><call_upon.anrufen><en> Call blending – using an auto dialing strategy such as predictive dialing combined with inbound call handling - drives significant efficiencies through the ability to allocate agents across contact channels through true and through automated multichannel blending defined by business rules.
<G-vec00485-002-s137><call_upon.anrufen><de> Call Blending – mit einer Autodialer-Strategie wie Predictive Dialing, kombiniert mit der Behandlung eingehender Anrufe – eröffnet die Möglichkeit, die Mitarbeiter über die Kontaktkanäle hinweg über echtes oder automatisiertes Mehrkanal-Blending gemäß der Definition in den Geschäftsregeln zuzuweisen, und sorgt so für erhebliche Effizienz.
<G-vec00485-002-s138><call_upon.anrufen><en> * Any kind of alcoholic drinks, hot shower, cold drinks, snacks, laundry, phone call, internet.
<G-vec00485-002-s138><call_upon.anrufen><de> * Jede Art von alkoholischen Getränken, kalten Getränken, Wäscherei, Anrufe, Internet.
<G-vec00485-002-s139><call_upon.anrufen><en> The module makes a GSM call or send an SMS (text) to each configured user number.
<G-vec00485-002-s139><call_upon.anrufen><de> Das Modul macht GSM Anrufe und schickt SMS Nachrichten an jede eingestellte Benutzer-Telefonnummer.
<G-vec00485-002-s140><call_upon.anrufen><en> Moreover, the call and demands of the Spirit resound in the very events of history, and so the Church can also be guided to a more profound understanding of the inexhaustible mystery of marriage and the family by the circumstances, the questions and the anxieties and hopes of the young people, married couples and parents of today.[9]
<G-vec00485-002-s140><call_upon.anrufen><de> Und nicht nur das: Die Forderungen und Anrufe des göttlichen Geistes sprechen auch aus den Ereignissen der Geschichte, weshalb die Kirche auch durch die Situationen, Fragen, Ängste und Hoffnungen der Jugendlichen, der Eheleute und der Eltern von heute zu einer tieferen Kenntnis des unerschöpflichen Mysteriums der Ehe und Familie geführt werden kann (Vgl.
<G-vec00485-002-s141><call_upon.anrufen><en> Operators accept the call in your name, take down caller information, then pass it to your dealership the next working day for processing.
<G-vec00485-002-s141><call_upon.anrufen><de> Die Anrufe werden in Ihrem Namen angenommen, die Daten des Anrufers notiert und am nächsten Arbeitstag zur Bearbeitung in Ihr Autohaus weitergeleitet.
<G-vec00485-002-s142><call_upon.anrufen><en> Select Menu > Settings > Call and from the following options: ● Call divert — to divert your incoming calls (network service).
<G-vec00485-002-s142><call_upon.anrufen><de> Anrufen Wählen Sie Menü > Einstellungen > Anrufe und eine der folgenden Optionen: ● Rufumleitung — Zum Umleiten von Anrufen (Netzdienst).
<G-vec00485-002-s143><call_upon.anrufen><en> There are many variants of settings: you can answer the incoming call shaking your smartphone or taking it to your ear, you can finish the conversation turning your device and others. Game features:
<G-vec00485-002-s143><call_upon.anrufen><de> Es gibt viele Anpassungsmöglichkeiten, du kannst zum Beispiel Anrufe annehmen, indem du dein Smartphone schüttelst oder es zum Ohr bewegst, Auflegen kannst du, indem du dein Telefon mit dem Bildschirm auf den Tisch legst.
<G-vec00485-002-s144><call_upon.anrufen><en> Settings for incoming phone call, email, and other notifications and for smartphone remaining battery notifications can be configured.
<G-vec00485-002-s144><call_upon.anrufen><de> Einstellungen für eingehende Anrufe, E-Mails und andere Benachrichtigungen sowie für Hinweise über den Smartphone-Akkustand können konfiguriert werden.
<G-vec00485-002-s145><call_upon.anrufen><en> Unwanted call blocking is a feature that helps block your Skype Number from receiving unwanted spam calls.
<G-vec00485-002-s145><call_upon.anrufen><de> Das Blockieren unerwünschter Anrufe ist eine Funktion, mit dem Sie verhindern, dass Ihre Skype-Rufnummer unerwünschte Spam-Anrufe empfängt.
<G-vec00485-002-s146><call_upon.anrufen><en> *Using Bixby may be limited under certain situations including without limitation during media (Video/Game/Voice) recording, during call (including outgoing call), Maximum power saving mode, Emergency mode, Kids Mode, and MirrorLink™.
<G-vec00485-002-s146><call_upon.anrufen><de> ** Bixby kann unter bestimmten Bedingungen nur eingeschränkt nutzbar sein, zum Beispiel bei Medienaufnahmen (Video/Spiele/Sprache), Telefonaten (inklusive Anrufe), im maximalen Stromsparmodus, Notfallmodus, Kids Mode und bei MirrorLink™.
<G-vec00485-002-s147><call_upon.anrufen><en> You also agree to not offer or use the Services as a service bureau by which the Services can be accessed by third parties or by which information produced pursuant to the Service is sold or given to third parties via pay per call or any other such arrangements whatsoever.
<G-vec00485-002-s147><call_upon.anrufen><de> Ferner verpflichten Benutzer sich, die Dienstleistungen nicht als ein Serviceunternehmen anzubieten oder zu benutzen, über welches Dritte auf die Dienstleistungen zugreifen können oder die durch die Dienstleistungen erzeugten Informationen durch gebührenpflichtige Anrufe oder vergleichbare Service an Dritte verkauft oder weiter geleitet werden.
<G-vec00485-002-s148><call_upon.anrufen><en> Cordless phone with answer machine With a digital answering machine, you'll never miss a call or message.
<G-vec00485-002-s148><call_upon.anrufen><de> Schnurlostelefon mit Anrufbeantworter Der digitale Anrufbeantworter speichert zuverlässig alle Anrufe und Nachrichten.
<G-vec00485-002-s149><call_upon.anrufen><en> “Placing a call is one of the most intuitive actions a consumer can take on their mobile phone, and calls are proving to be a very effective way to monetize mobile advertising, especially in service-based verticals.”
<G-vec00485-002-s149><call_upon.anrufen><de> Anrufe haben sich außerdem als einer der effektivsten Wege erwiesen, mobile Werbung zu monetarisieren – insbesondere im Dienstleistersektor.“ Es hat sich gezeigt, dass besonders Unternehmen in der Service-Branche erfolgreich mit mobilem Click-to-Call arbeiten.
<G-vec00485-002-s150><call_upon.anrufen><en> Tap the channel or direct message name to open the channel or conversation info, and choose Start a call.
<G-vec00485-002-s150><call_upon.anrufen><de> Anrufe starten Tippe auf den Namen des Channels oder der Direktnachricht, um die Informationen für den Channel oder die Unterhaltung zu öffnen.
<G-vec00485-002-s151><call_upon.anrufen><en> The call is coming to you company no matter if the caller originates in your geographical location or abroad.
<G-vec00485-002-s151><call_upon.anrufen><de> Die Anrufe werden direkt zu Ihnen geleitet, egal ob der Anrufer im Inland oder im Ausland (mit Ländervorwahl) sitzt.
<G-vec00485-002-s266><call_upon.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00485-002-s266><call_upon.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00485-002-s267><call_upon.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00485-002-s267><call_upon.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00485-002-s268><call_upon.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00485-002-s268><call_upon.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00485-002-s269><call_upon.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00485-002-s269><call_upon.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00485-002-s270><call_upon.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00485-002-s270><call_upon.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00485-002-s271><call_upon.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00485-002-s271><call_upon.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00485-002-s272><call_upon.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00485-002-s272><call_upon.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00485-002-s273><call_upon.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00485-002-s273><call_upon.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00485-002-s274><call_upon.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00485-002-s274><call_upon.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00485-002-s275><call_upon.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00485-002-s275><call_upon.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00485-002-s276><call_upon.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00485-002-s276><call_upon.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00485-002-s277><call_upon.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00485-002-s277><call_upon.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00485-002-s278><call_upon.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00485-002-s278><call_upon.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00485-002-s279><call_upon.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00485-002-s279><call_upon.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00485-002-s280><call_upon.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00485-002-s280><call_upon.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00485-002-s281><call_upon.aufrufen><en> Tried to call a removed routine.
<G-vec00485-002-s281><call_upon.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00485-002-s282><call_upon.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00485-002-s282><call_upon.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00485-002-s283><call_upon.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00485-002-s283><call_upon.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00485-002-s284><call_upon.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00485-002-s284><call_upon.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00485-002-s323><call_upon.bezeichnen><en> Bahlsen: You could call him that.
<G-vec00485-002-s323><call_upon.bezeichnen><de> Bahlsen: So könnte man ihn bezeichnen.
<G-vec00485-002-s324><call_upon.bezeichnen><en> It is therefore incomprehensible that the guests call me the house as not clean.
<G-vec00485-002-s324><call_upon.bezeichnen><de> Es ist mir daher unverständlich das die Gäste das Haus als nicht sauber bezeichnen.
<G-vec00485-002-s325><call_upon.bezeichnen><en> Because there are already four of those restaurants, so I guess you can call it a chain.
<G-vec00485-002-s325><call_upon.bezeichnen><de> Weil es mittlerweile bereits vier Ishins gibt, von daher kann man es wohl getrost als Ladenkette bezeichnen.
<G-vec00485-002-s326><call_upon.bezeichnen><en> External creation as well as quotation from the Bible urged to call this bell "Christ's bell".
<G-vec00485-002-s326><call_upon.bezeichnen><de> Sowohl äußere Gestaltung als auch Bibelwort legten nahe, diese Glocke als "Christusglocke" zu bezeichnen.
<G-vec00485-002-s327><call_upon.bezeichnen><en> This positive confirmation of aesthetic interventions was the motivation to examine current trends more closely and to carry out an analysis based on historical developments, which, in our opinion, must necessarily lead to a changed philosophy of aesthetic medicine, which we would like to call Compositional Aesthetics.
<G-vec00485-002-s327><call_upon.bezeichnen><de> Diese positive Bestätigung ästhetischer Interventionen war Motivation, die aktuellen Trends genauer zu untersuchen und eine Analyse auf Basis der historischen Entwicklung durchzuführen, die notwendigerweise unserer Auffassung nach zu einer veränderten Philosophie der ästhetischen Medizin führen muss, die wir mit dem Begriff Kompositorische Ästhetik bezeichnen wollen.
<G-vec00485-002-s328><call_upon.bezeichnen><en> Thus the Jews call God the Father, and in Christianity God has even put forth a human Son.
<G-vec00485-002-s328><call_upon.bezeichnen><de> Entsprechend bezeichnen die Juden Gott als Vater, im Christentum hat Gott sogar einen menschlichen Sohn gezeugt.
<G-vec00485-002-s329><call_upon.bezeichnen><en> Many scientist have described what we call the information field as a "field of mental and physical interchange".
<G-vec00485-002-s329><call_upon.bezeichnen><de> Viele Wissenschaftler beschrieben bereits den Bereich, den wir als Informationsfeld bezeichnen, als ein Feld der mentalen und physischen Wechselwirkungen.
<G-vec00485-002-s330><call_upon.bezeichnen><en> As boxer engine you can not call it well, because opposite cylinders run on a connecting rod pin and thus always run the same movement.
<G-vec00485-002-s330><call_upon.bezeichnen><de> Als Boxermotor kann man ihn wohl nicht bezeichnen, weil gegenüberliegende Zylinder auf einem Pleuelzapfen laufen und damit immer die gleiche Bewegung ausführen.
<G-vec00485-002-s331><call_upon.bezeichnen><en> Share On pinterest Pin Wrestling might be fake, but at least it has the chops to call it a squared circle.
<G-vec00485-002-s331><call_upon.bezeichnen><de> Beim Wrestling mag zwar vieles Fake sein, aber immerhin haben die genügend Eier, ihren Ring als quadratischen Kreis zu bezeichnen.
<G-vec00485-002-s332><call_upon.bezeichnen><en> I would call our group “blue helmets” as an analogy to UN peacekeepers.
<G-vec00485-002-s332><call_upon.bezeichnen><de> Ich würde unsere ganze Gruppe als „Blauhelme“ bezeichnen, in Analogie zu den Friedensstiftern der UNO.
<G-vec00485-002-s333><call_upon.bezeichnen><en> I am now able to call myself bilingual, as I use both English and German in my daily life.
<G-vec00485-002-s333><call_upon.bezeichnen><de> Nun kann ich mich selbst als bilingual bezeichnen, denn in meinem Alltag gebrauche ich sowohl Englisch als auch Deutsch.
<G-vec00485-002-s334><call_upon.bezeichnen><en> We always call them LR44 on Lovehoney.com
<G-vec00485-002-s334><call_upon.bezeichnen><de> Wir bezeichnen sie stets als LR44-Batterien.
<G-vec00485-002-s335><call_upon.bezeichnen><en> You can call Him a hippie, all right!
<G-vec00485-002-s335><call_upon.bezeichnen><de> Man könnte Ihn als Hippie bezeichnen.
<G-vec00485-002-s336><call_upon.bezeichnen><en> It also extends to those who call themselves "healers" in this room, for they have the same task as the channeller or the teacher, and that is translating a perceptual, metaphörical message into something that is 3D and practical.
<G-vec00485-002-s336><call_upon.bezeichnen><de> Es schließt auch diejenigen im Raum ein, die sich als Heiler bezeichnen, denn sie haben die gleiche Aufgabe wie die Channeler oder Lehrer, nämlich, eine wahrgenommene metaphorische Botschaft in etwas zu übersetzen, was 3D und praktisch ist.
<G-vec00485-002-s337><call_upon.bezeichnen><en> With our nearly 30 years of experience and extensive series of delivered projects, we can rightly call ourselves solid surface experts.
<G-vec00485-002-s337><call_upon.bezeichnen><de> Mit unseren fast 30 Jahren Erfahrung und bereits realisierte, erfolgreiche Projekte können wir uns mit Recht als Solid Surface-Experten bezeichnen.
<G-vec00485-002-s338><call_upon.bezeichnen><en> If the score of any method is above a certain limit, then we call that moment “abnormal” according to that method.
<G-vec00485-002-s338><call_upon.bezeichnen><de> Wenn der Wert einer dieser Methoden einen bestimmten Grenzwert überschreitet, bezeichnen wir diesen Moment als „abnormal“ entsprechend der jeweiligen Methode.
<G-vec00485-002-s339><call_upon.bezeichnen><en> The shape of the main island of Taiwan is similar to a sweet potato seen in a south-to-north direction, and therefore, Taiwanese (especially Min Nan speakers) often call themselves "children of the Sweet Potato.
<G-vec00485-002-s339><call_upon.bezeichnen><de> Charakteristisch für Taiwan ist die auf der Landkarte eine Süßkartoffel ähnelnde Form, aufgrund deren sich die Min Nan Ureinwohner auch als „Kinder der Süßkartoffel“ bezeichnen.
<G-vec00485-002-s340><call_upon.bezeichnen><en> What we call "evil spirits" are Satan and all the evil spirit men on his side.
<G-vec00485-002-s340><call_upon.bezeichnen><de> Mit dem Ausdruck "böse Geister" bezeichnen wir Satan und all seine bösen Geister.
<G-vec00485-002-s341><call_upon.bezeichnen><en> As a top place I would not call this place.
<G-vec00485-002-s341><call_upon.bezeichnen><de> Als Top-Platz würde ich diesen Platz nicht bezeichnen.
<G-vec00485-002-s380><call_upon.erfordern><en> The challenges of international competition and the EC internal market call for an increased effort to structure the world of work more humanely.
<G-vec00485-002-s380><call_upon.erfordern><de> Die Herausforderungen des internationalen Wettbewerbs und des EG-Binnenmarktes erfordern vermehrte Anstrengungen für eine menschengerechtere Strukturierung der Arbeitswelt.
<G-vec00485-002-s381><call_upon.erfordern><en> Modern printers and smart devices call for a multi-layered approach to security that spans intrusion prevention, device detection, document and data detection and external partnerships with security specialists.
<G-vec00485-002-s381><call_upon.erfordern><de> Moderne Drucker und intelligente Geräte erfordern einen mehrschichtigen Sicherheitsansatz, der die Bereiche Angriffsverhinderung, Geräteerkennung sowie Dokumenten- und Datenschutz abdeckt und Partnerschaften mit externen Anbietern für Datensicherheit beinhaltet.
<G-vec00485-002-s382><call_upon.erfordern><en> Variable inlet guide vanes (IGV) ensure optimal flow rates, especially when changing on-site conditions call for immediate adjustments.
<G-vec00485-002-s382><call_upon.erfordern><de> Verstellbare Eintrittsleitschaufeln (IGVs, Inlet Guide Vanes) gewährleisten optimale Flussraten, insbesondere, wenn sich wandelnde Bedingungen vor Ort eine sofortige Anpassung erfordern.
<G-vec00485-002-s383><call_upon.erfordern><en> Special working environments call for special solutions.
<G-vec00485-002-s383><call_upon.erfordern><de> Besondere Arbeitsumgebungen erfordern besondere Lösungen.
<G-vec00485-002-s384><call_upon.erfordern><en> Trial and error, early corrections, and brand-new approaches call for a creative way of working toward solutions.
<G-vec00485-002-s384><call_upon.erfordern><de> Versuch und Irrtum, frühe Korrekturen und völlig neue Ansätze erfordern eine kreative Annäherung an die Lösungen.
<G-vec00485-002-s385><call_upon.erfordern><en> Rough, sloping terrain and cramped working conditions call for robust and reliable forestry machines.
<G-vec00485-002-s385><call_upon.erfordern><de> Raues, abschüssiges Gelände und beengte Arbeitsbedingungen erfordern robuste und zuverlässige Forstmaschinen.
<G-vec00485-002-s386><call_upon.erfordern><en> Such deep dives are, however, quite strenuous and usually call for some resting time at the surface which was observed in some of the pilot whales this morning.
<G-vec00485-002-s386><call_upon.erfordern><de> Solche tiefen Tauchgänge sind jedoch ziemlich anstrengend und erfordern normalerweise eine gewisse Ruhezeit an der Wasseroberfläche, die bei einigen Pilotwale während der heutigen Nachmittagstour beobachtet werden konnte.
<G-vec00485-002-s387><call_upon.erfordern><en> From ultrasonic welding, gluing or riveting, whether force, current or position measurement: custom drives call for customized solutions.
<G-vec00485-002-s387><call_upon.erfordern><de> Ob Ultraschall-Schweißen, Kleben oder Vernieten, ob Kraft-, Strom- oder Positionsmessung: Individuelle Antriebe erfordern individuelle Lösungen.
<G-vec00485-002-s388><call_upon.erfordern><en> Each situation and each woman may call for something different.
<G-vec00485-002-s388><call_upon.erfordern><de> Jede Situation und jede Frau kann etwas anderes erfordern.
<G-vec00485-002-s389><call_upon.erfordern><en> Specifically, they call for a lifestyle marked by sobriety and solidarity, with new rules and forms of engagement, one which focuses confidently and courageously on strategies that actually work, while decisively rejecting those that have failed.
<G-vec00485-002-s389><call_upon.erfordern><de> Sie erfordern insbesondere eine durch Maßhalten und Solidarität gekennzeichnete Lebensweise mit neuen Regeln und Formen des Einsatzes, die zuversichtlich und mutig die positiven Erfahrungen aufgreifen und die negativen entschieden zurückweisen.
<G-vec00485-002-s390><call_upon.erfordern><en> Highly complex food products like fruit juices may – depending on the performance requirements – call for the use of the entire spectrum of analytical methods.
<G-vec00485-002-s390><call_upon.erfordern><de> Fruchtsäfte als hochkomplexe Lebensmittel erfordern je nach Aufgabenstellung das gesamte Spektrum der analytischen Methoden.
<G-vec00485-002-s391><call_upon.erfordern><en> On the mountain, extreme conditions call for the right balance between weight and functionality.
<G-vec00485-002-s391><call_upon.erfordern><de> Die extremen Bedingungen am Berg erfordern eine ausgewogene Balance zwischen Gewicht und Funktionalität.
<G-vec00485-002-s392><call_upon.erfordern><en> Ever-increasing demands regarding the cleanliness of component surfaces call for increasingly effective cleaning methods.
<G-vec00485-002-s392><call_upon.erfordern><de> Immer höhere Anforderungen an die Sauberkeit von Bauteiloberflächen erfordern immer effektivere Reinigungsverfahren.
<G-vec00485-002-s393><call_upon.erfordern><en> Industrial revolutions always call for investments to implement structural change – and Industry 4.0 is no exception.
<G-vec00485-002-s393><call_upon.erfordern><de> Industrielle Revolutionen erfordern Investitionen, ohne die nun mal kein Strukturwandel möglich ist – da macht auch die Industrie 4.0 keine Ausnahme.
<G-vec00485-002-s394><call_upon.erfordern><en> Constantly rising competition and cost pressure as well as decreasing margins call for flexibility and constant adaptability.
<G-vec00485-002-s394><call_upon.erfordern><de> Ständig steigender Wettbewerbs- und Kostendruck und sinkende Margen erfordern Flexibilität und stetige Anpassungen.
<G-vec00485-002-s395><call_upon.erfordern><en> Pressing conflicts, risks and crisis may call for rapid, decisive actions.
<G-vec00485-002-s395><call_upon.erfordern><de> Konflikte, dringende Risiken und Krisen erfordern entschlossenes und rasches Handeln.
<G-vec00485-002-s396><call_upon.erfordern><en> Granting rights of use not only needs to be taken into consideration for traditional licensing agreements, but also in a variety of other types of agreement: creating websites, drafting ASP agreements or transferring databases all call for copyright provisions which may be critical to the quality of the overall contractual framework.
<G-vec00485-002-s396><call_upon.erfordern><de> Die Einräumung von Nutzungsrechten ist nicht nur bei klassischen Lizenzverträgen zu berücksichtigen, sondern auch bei einer Reihe anderer Vereinbarungen: Die Erstellung von Webseiten, ASP-Verträge oder die Übernahme von Datenbanken erfordern urheberrechtliche Regelungen, die über die Qualität des gesamten Vertragswerkes entscheiden können.
<G-vec00485-002-s397><call_upon.erfordern><en> The great challenges of our time call upon us all to stand together and to commit to continual improvement.
<G-vec00485-002-s397><call_upon.erfordern><de> Klimawandel, knappe Ressourcen und globale Märkte – die großen Herausforderungen unserer Zeit erfordern Zusammenhalt und den Willen zur stetigen Verbesserung.
<G-vec00485-002-s398><call_upon.erfordern><en> Individual needs call for individual solutions.
<G-vec00485-002-s398><call_upon.erfordern><de> Individuelle Bedürfnisse erfordern individuelle Lösungen.
<G-vec00485-002-s399><call_upon.fordern><en> To call for the use of arms under the guise of democracy is in itself impermissible, but to speak of Germany as a democracy state, which in this way could somehow repair its damaged image, that is defamatory, and the question must be asked of why Germany could be so bent on playing at war again, instead of eschewing it for all time.
<G-vec00485-002-s399><call_upon.fordern><de> Waffeneinsätze unter dem Deckmantel der Demokratie zu fordern ist schon unzulässig, aber Deutschland als demokratischen Staat anzupreisen, der dadurch eine Art Imageschaden wieder gut machen könnte, das ist ehrenrührig und es muss die Frage gestellt werden, warum Deutschland so versessen darauf sein könnte, wieder Krieg zu spielen, anstatt dies für alle Zeiten bleiben zu lassen.
<G-vec00485-002-s400><call_upon.fordern><en> In an article in Spiegel Online, Andre Wilkens and Jakob von Weizsäcker call for a publicly financed media channel that is produced in and for Europe.1 It is their hope that the project will make an important contribution to European democracy.
<G-vec00485-002-s400><call_upon.fordern><de> In ihrem Gastbeitrag für „Spiegel Online“ fordern die Autoren Andre Wilkens und Jakob von Weizsäcker einen öffentlich-rechtlichen Medienkanal aus und für Europa.1 Von diesem erhoffen sie sich einen wichtigen Beitrag zur Rettung der europäischen Demokratie.
<G-vec00485-002-s401><call_upon.fordern><en> Meanwhile, we call on the Council of the EU to take a final decision on further sanctions against the Russian Federation only after thoroughly evaluating the progress towards the political solution.
<G-vec00485-002-s401><call_upon.fordern><de> In der Zwischenzeit fordern wir den Rat der Europäischen Union auf, einen endgültigen Beschluss über weitere Sanktionen gegen Russland erst nach einer gründlichen Bewertung des Fortschritts auf dem Weg zur politischen Lösung zu fassen.
<G-vec00485-002-s402><call_upon.fordern><en> About 60 protesters marched to the local police headquarters to support the arrested reclaimers and call for their release.
<G-vec00485-002-s402><call_upon.fordern><de> Etwa 60 DemonstrantInnen marschierten zur Polizeistation, um die Verhafteten zu unterstützen und ihre Freilassung zu fordern.
<G-vec00485-002-s403><call_upon.fordern><en> Younger Central Committee members call on the "old comrades" to leave the CC voluntarily in the face of the demands of the rank and file.
<G-vec00485-002-s403><call_upon.fordern><de> Jüngere ZK-Mitglieder fordern die „alten Genossen" auf, freiwillig aus dem ZK zurückzutreten, weil dies die Parteibasis verlange.
<G-vec00485-002-s404><call_upon.fordern><en> Their feeling that they are under threat is fuelled above all by the fact that hard-liners in Tehran time and again openly call for the destruction of Israel while Hezbollah’s rockets are, at the same time, stationed on Israel’s northern border.
<G-vec00485-002-s404><call_upon.fordern><de> Das Gefühl der Bedrohung wird vor allem dadurch genährt, dass immer wieder Hardliner in Teheran offen die Vernichtung Israels fordern, während gleichzeitig an Israels Nordgrenze die Raketen der Hisbollah stehen.
<G-vec00485-002-s405><call_upon.fordern><en> In accordance with the FBE previous and constant position we call upon an end to arbitrary arrest, detention, and prosecution of judges, lawyers and journalists.
<G-vec00485-002-s405><call_upon.fordern><de> Entsprechend dem bisherigen und festen Standpunkt des FBE fordern wir ein Ende der willkürlichen Festnahme, Inhaftierung und Verfolgung von Richtern, Anwälten und Journalisten.
<G-vec00485-002-s406><call_upon.fordern><en> We call for EU citizens to have the choice to continue to buy healthy bulbs in the future.
<G-vec00485-002-s406><call_upon.fordern><de> Wir fordern für alle europäischen Bürger die Freiheit, auch in Zukunft gesunde Leuchtmittel kaufen zu können.
<G-vec00485-002-s407><call_upon.fordern><en> We also call on all armed groups to put an immediate end to violence.
<G-vec00485-002-s407><call_upon.fordern><de> Wir fordern außerdem alle bewaffneten Gruppierungen auf, die Gewalt unverzüglich zu beenden.
<G-vec00485-002-s408><call_upon.fordern><en> Organic Farming News European experts call to convert organic agriculture in the model for European agriculture.
<G-vec00485-002-s408><call_upon.fordern><de> Landwirtschaft News Europäische Experten fordern die Umstellung auf den ökologischen Landbau in dem Modell für die europäische Landwirtschaft.
<G-vec00485-002-s409><call_upon.fordern><en> We call for an independent review of all existing surveillance powers as to their effectiveness, proportionality, costs, harmful side-effects and alternative solutions.
<G-vec00485-002-s409><call_upon.fordern><de> Wir fordern eine unabhängige Überprüfung aller bestehenden Überwachungsbefugnisse in Hinblick auf ihre Wirksamkeit, Verhältnismäßigkeit, Kosten, schädliche Nebenwirkungen und Alternativen.
<G-vec00485-002-s410><call_upon.fordern><en> We call on Europe to push for the conversion of the INF Treaty into a multilateral Treaty in order to include other nuclear states, like China.
<G-vec00485-002-s410><call_upon.fordern><de> Wir fordern die EU auf, die Umwandlung des INF-Vertrags in einen multilateralen Vertrag voranzutreiben, um andere Nuklearstaaten wie China einzubeziehen.
<G-vec00485-002-s411><call_upon.fordern><en> The stream that meanders through the grounds, the trickily undulating greens well protected by bunkers, and the ancient tree population including some majestic solitary giants, call for accurate play on this special 9-hole course.
<G-vec00485-002-s411><call_upon.fordern><de> Der sich durch das Gelände ziehende Bach, die durch Bunker gut verteidigten und anspruchsvoll ondulierten Grüns sowie der alte Baumbestand mit großen Solitären fordern ein akkurates Spiel auf diesem besonderen 9-Loch-Platz.
<G-vec00485-002-s412><call_upon.fordern><en> She told the audience that the reason she came to South Africa was to call for a stop to the persecution of Falun Dafa.
<G-vec00485-002-s412><call_upon.fordern><de> Sie erzählte den Zuschauern warum sie nach Südafrika gekommen war, nämlich um ein Ende der Verfolgung von Falun Gong zu fordern.
<G-vec00485-002-s413><call_upon.fordern><en> When “masters” control servants, or when capitalists control workers, this is considered to be in the nature of things; the private life of the working and exploited people is not considered inviolable. The bourgeoisie are entitled to call to account any "wage slave" and at any time to make public his income and expenditure.
<G-vec00485-002-s413><call_upon.fordern><de> Wenn die „Herrschaften“ die Dienstboten kontrollieren, wenn die Kapitalisten die Arbeiter kontrollieren, dann hält man das für ganz in Ordnung, das Privatleben des Werktätigen und Ausgebeuteten gilt nicht für unantastbar, die Bourgeoisie ist berechtigt, von jedem „Lohnsklaven“ Rechenschaft zu fordern, seine Einnahmen und Ausgaben jederzeit an die Öffentlichkeit zu zerren.
<G-vec00485-002-s414><call_upon.fordern><en> We need a more creative and coordinated response from the EU and its Member States, and we call for a European strategy on demographic change and for more familyand child-friendly environments.
<G-vec00485-002-s414><call_upon.fordern><de> Wir benötigen eine kreativere und koordiniertere Antwort der EU und ihrer Mitgliedstaaten, und wir fordern eine europäische Strategie zum demografischen Wandel sowie zu familien- und kinderfreundlichen Umgebungen.
<G-vec00485-002-s415><call_upon.fordern><en> The artists call for the resignation of the Senator of Culture, because a competent Senator for Cultural Affairs would do something intelligent for the city of Berlin with the keys of the house in his/her hands.
<G-vec00485-002-s415><call_upon.fordern><de> Die Künstler fordern den Rücktritt des Kultursenators, da ein kompetenter Senator für kulturelle Angelegenheiten mit dem ihm übergebenen Tacheles Schlüssel etwas Intelligentes für die Stadt Berlin bewirken könnte.
<G-vec00485-002-s416><call_upon.fordern><en> We call on the Russian Federation to immediately cease its attacks on the Syrian opposition and civilians and to focus its efforts on fighting ISIL.
<G-vec00485-002-s416><call_upon.fordern><de> Wir fordern die Russische Föderation auf, ihre Angriffe auf die syrische Opposition und die Zivilbevölkerung unverzüglich zu stoppen und sich auf die Bekämpfung von ISIS zu konzentrieren.
<G-vec00485-002-s417><call_upon.fordern><en> However, the finite nature of fossil fuels, climate change and smog call for alternative solutions from the automotive industry, such as the electric drive.
<G-vec00485-002-s417><call_upon.fordern><de> Die Endlichkeit fossiler Kraftstoffe, der Klimawand und Smog fordern von der Automobilindustrie jedoch alternative Lösungen wie den Elektroantrieb.
<G-vec00485-002-s494><call_upon.nennen><en> 13 “You call me ‘Teacher’ and ‘Lord,’ and rightly so, for that is what I am.
<G-vec00485-002-s494><call_upon.nennen><de> Ihr nennt mich Meister und Herr und sagt es mit Recht, denn ich bin’s auch.
<G-vec00485-002-s495><call_upon.nennen><en> Cheap flights from Seville to Rio De Janeiro from 502 € on Iberia From the moment you enter Rio de Janeiro, you will understand why they call it the ‘Marvellous City’.
<G-vec00485-002-s495><call_upon.nennen><de> Billige Tickets für Iberia Flüge von Berlin nach Rio de Janeiro ab 638 € bei Iberia Vom Zeitpunkt an, in dem Sie Rio de Janeiro betreten, werden Sie verstehen, warum man sie „die wundervolle Stadt“ nennt.
<G-vec00485-002-s496><call_upon.nennen><en> Once he says his sounding name at the end of the phone call, they put his Hungarian language to a test.
<G-vec00485-002-s496><call_upon.nennen><de> Als er gegen Ende des Telefonats seinen klingenden Namen nennt, stellt man gleich sein Ungarisch auf eine Belastungsprobe.
<G-vec00485-002-s497><call_upon.nennen><en> Let us take it from another aspect of what you call insects and bees.
<G-vec00485-002-s497><call_upon.nennen><de> Lasst uns das unter einem anderen Aspekt sehen, von den Kreaturen, die ihr Insekten und Bienen nennt.
<G-vec00485-002-s498><call_upon.nennen><en> You do not put your feet on the table, you do not burp while eating, and you do not call the twelve worst years in German history "bird shit."
<G-vec00485-002-s498><call_upon.nennen><de> Man legt die Füße nicht auf den Tisch, man rülpst nicht beim Essen, und man nennt die 12 schlimmsten Jahre der deutschen Geschichte nicht einen „Vogelschiss“.
<G-vec00485-002-s499><call_upon.nennen><en> The two of them then make up after he assures her that he will not leave her (although she continues to call him a liar).
<G-vec00485-002-s499><call_upon.nennen><de> Die beiden von ihnen machen dann auf, nachdem er ihr versichert hat, dass er sie nicht verlassen wird (obwohl sie ihn weiterhin einen Lügner nennt).
<G-vec00485-002-s500><call_upon.nennen><en> That would be exactly what we call diplomacy: the art of (secret) negotiation....
<G-vec00485-002-s500><call_upon.nennen><de> Das wäre genau das, was man Diplomatie nennt: die Kunst des (geheimen) Verhandelns....
<G-vec00485-002-s501><call_upon.nennen><en> Perhaps you already have a remedy that has helped you to heal the wounds quickly, and you know exactly what to call the pharmacist in the pharmacy.
<G-vec00485-002-s501><call_upon.nennen><de> Vielleicht haben Sie bereits ein Mittel, das Ihnen geholfen hat, die Wunden schnell zu heilen, und Sie wissen genau, wie man den Apotheker in der Apotheke nennt.
<G-vec00485-002-s502><call_upon.nennen><en> It is possible to go back into what you call your history and change or alter it.
<G-vec00485-002-s502><call_upon.nennen><de> Es ist möglich, in das, was ihr eure Geschichte nennt, zurückzugehen und sie zu ändern oder umzugestalten.
<G-vec00485-002-s503><call_upon.nennen><en> We wish you much Joy and Love as you "unfold" into the New Cycle which you call a New Year.
<G-vec00485-002-s503><call_upon.nennen><de> Wir wünschen euch viel Freude und Liebe, wenn ihr euch in den Neuen Zyklus hinein „entfaltet“, den ihr das Neue Jahr nennt.
<G-vec00485-002-s504><call_upon.nennen><en> When we talk about the first collective dimension, this is what you actually call God.
<G-vec00485-002-s504><call_upon.nennen><de> Wenn wir über die erste kollektive Dimension sprechen, so ist dies das, was ihr Gott nennt.
<G-vec00485-002-s505><call_upon.nennen><en> You call them Gods but... Kana yakulani atta'ama.
<G-vec00485-002-s505><call_upon.nennen><de> Ihr nennt sie Götter, aber "Kana Yakulani Atta'ama".
<G-vec00485-002-s506><call_upon.nennen><en> I also know that many persons, including nuns from various monasteries of contemplative life, "mystical antennae", as you call them, accompany you and support you with their prayers, while the sick, hospital patients and prisoners offer up their sufferings for your apostolate.
<G-vec00485-002-s506><call_upon.nennen><de> Ich weiß, daß euch viele Personen, darunter Nonnen in verschiedenen Klöstern des kontemplativen Lebens, die ihr »mystische Antennen« nennt, durch ihr Gebet unterstützen, während Kranke, bettlägerige Patienten in Krankenhäusern sowie Gefangene ihr Leiden eurem Apostolat widmen.
<G-vec00485-002-s507><call_upon.nennen><en> In the Basque country, they call it a transition stage, but 6 climbs were on the program on the 164 kilomters between Ataun and Villatuerta.
<G-vec00485-002-s507><call_upon.nennen><de> Ausreissersieg durch Baskenland nennt man das eine Übergangsetappe, doch nicht weniger als 6 Bergwertungen standen auch heute auf den 164 Kilometern zwischen Ataun und Villatuerta auf dem Programm.
<G-vec00485-002-s508><call_upon.nennen><en> In order to have a clear concept of this planetary body which you call Saturn, it is important to know what its actual name denotes: Earth Calmness, World Nothingdom. It is also absolutely necessary to learn about its natural sphere, its distance from the sun, its size, structure, its inhabitants as well as the inhabitants on the rings and moons, as well as its diverse vegetation in accordance with the conditions that prevail because of distinctly varying climates.
<G-vec00485-002-s508><call_upon.nennen><de> Der Saturn Um sich von diesem Weltkörper, den ihr Saturn nennt – während sein eigentlicher Name soviel besagt wie: Erdruhe, Weltnichtstum – einen deutlichen Begriff zu machen, ist vor allem nötig, seine natürliche Sphäre, Entfernung von der Sonne, seine Größe wie auch die seiner Monde so genau wie nur immer eurer Fassungskraft möglich zu erkennen.
<G-vec00485-002-s509><call_upon.nennen><en> Furthermore, you become aware of your own limits, in English, you call that ‘Humility’.
<G-vec00485-002-s509><call_upon.nennen><de> Des Weiteres wirst du dir auch deiner eigenen Grenzen bewusst, im Englischen nennt man das ‚Humility‘.
<G-vec00485-002-s510><call_upon.nennen><en> Indeed these occur through connectivity in the neural networks (plasmic filaments) of the Living Cosmos or gestalt energy you call God.
<G-vec00485-002-s510><call_upon.nennen><de> In der Tat geschieht dies durch die Verbindungsfähigkeit in den neuronalen Netzwerken (plasmaartige Leuchtfäden) des lebendigen Kosmos oder der gestaltenden Energie, die ihr Gott nennt.
<G-vec00485-002-s511><call_upon.nennen><en> As long as no one is in the way … or a wing is broken – or what would you call it?
<G-vec00485-002-s511><call_upon.nennen><de> Das ist ein großer Spaß, wenn keiner im Wege steht … oder ein Flügel hinkt, oder wie man das nennt.
<G-vec00485-002-s512><call_upon.nennen><en> In any case, Marlen was not a year old when Lore become pregnant again; so Cristina was what in show business you call the encore, the familiar song, saved for last and laid in a gently polished version at the feet of the breathless audience.
<G-vec00485-002-s512><call_upon.nennen><de> Jedenfalls war Marlen noch kein Jahr alt, als Lore wieder schwanger war; Cristina wurde also das, was man im Showbusiness die Zugabe nennt, der vertraute Song, aufgespart, um ihn dem atemlosen Publikum in einer sanft polierten Variante zu Füßen zu legen.
<G-vec00485-002-s608><call_upon.rufen><en> Call Swiss America trading right now: 1-800-289-2646.
<G-vec00485-002-s608><call_upon.rufen><de> Ruft Swiss America Trading gleich jetzt an: 1-800-289-2646.
<G-vec00485-002-s609><call_upon.rufen><en> Please leave your name and telephone number and UF Gabelstapler GmbH will call you back.
<G-vec00485-002-s609><call_upon.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und UF Gabelstapler GmbH ruft Sie zurück.
<G-vec00485-002-s610><call_upon.rufen><en> The Checkmk alert helpers call up their functions synchronously.
<G-vec00485-002-s610><call_upon.rufen><de> Der Alerthelper von Checkmk ruft Ihre Funktionen synchron auf.
<G-vec00485-002-s611><call_upon.rufen><en> call on him while he is near.
<G-vec00485-002-s611><call_upon.rufen><de> Ruft ihn an, während er nahe ist.
<G-vec00485-002-s612><call_upon.rufen><en> Please leave your name and telephone number and Delgado Freizeit GmbH will call you back.
<G-vec00485-002-s612><call_upon.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und UnikTruck A/S ruft Sie zurück.
<G-vec00485-002-s613><call_upon.rufen><en> It will call res_init(), if it has not already been called.
<G-vec00485-002-s613><call_upon.rufen><de> Sie ruft res_init() auf, wenn es noch nicht aufgerufen wurde.
<G-vec00485-002-s614><call_upon.rufen><en> opening, you must call, Ya Fattah, Ya Fattah, Ya Fattah.
<G-vec00485-002-s614><call_upon.rufen><de> Für die Öffnung ruft ihr Ya Fattah, Ya Fattah, Ya Fattah.
<G-vec00485-002-s615><call_upon.rufen><en> There are daily steamers from Piraeus to Corfu, Cephallonia and Zakynthos, though the same ship does not necessarily call at all three.
<G-vec00485-002-s615><call_upon.rufen><de> Es gibt tägliche Dampfer von Piraeus zu Corfu, Cephallonia und Zakynthos, obwohl das gleiche Schiff nicht unbedingt überhaupt drei ruft.
<G-vec00485-002-s616><call_upon.rufen><en> Please leave your name and telephone number and AGRAVIS Technik Center GmbH will call you back.
<G-vec00485-002-s616><call_upon.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und AGRAVIS Technik Center GmbH ruft Sie zurück.
<G-vec00485-002-s617><call_upon.rufen><en> Call to Allah.
<G-vec00485-002-s617><call_upon.rufen><de> Ruft Allah an.
<G-vec00485-002-s618><call_upon.rufen><en> Call xxx() to get the result for the aggregate when the group changes or after the last row has been processed.
<G-vec00485-002-s618><call_upon.rufen><de> Es ruft xxx() auf, um das Aggregatergebnis zu erhalten, wenn die Gruppe wechselt oder nachdem die letzte Zeile verarbeitet wurde.
<G-vec00485-002-s619><call_upon.rufen><en> Be aware of this and be clear about the assistance you call to yourself.
<G-vec00485-002-s619><call_upon.rufen><de> Seid euch dessen bewußt, und seid klar in bezug auf die Unterstützung, die ihr zu euch ruft.
<G-vec00485-002-s620><call_upon.rufen><en> Enlighten your peasant brothers, banish ignorance from the villages, call on the peasant poor to support the workers of town and country in their glorious struggle.
<G-vec00485-002-s620><call_upon.rufen><de> Klärt eure Brüder, die Bauern, auf: vertreibt die Finsternis aus dem Dorf, ruft die Dorfarmut auf, die Arbeiter in Stadt und Land in ihrem ruhmvollen Kampf zu unterstützen.
<G-vec00485-002-s621><call_upon.rufen><en> In my country Malaysia, the muezzin would call out to Muslims for prayer five times a day through loudspeakers from the minarets of mosques.
<G-vec00485-002-s621><call_upon.rufen><de> In meinem Heimatland Malaysien ruft der Muezzin durch die Lautsprecher auf den Minaretten der Moscheen fünfmal am Tag die Muslime zum Gebet.
<G-vec00485-002-s622><call_upon.rufen><en> If you call them to Guidance they would not hear; you see them looking at you and they see not.
<G-vec00485-002-s622><call_upon.rufen><de> Und wenn ihr sie zur Rechtleitung ruft, hören sie nicht.
<G-vec00485-002-s623><call_upon.rufen><en> 110 Say: "Call upon Allah, or call upon Rahman: by whatever name ye call upon Him, (it is well): for to Him belong the Most Beautiful Names.
<G-vec00485-002-s623><call_upon.rufen><de> 110 Sag: Ruft Allah oder ruft den Allerbarmer an; welchen ihr auch ruft, Sein sind die schönsten Namen.
<G-vec00485-002-s626><call_upon.rufen><en> Elijah said to the prophets of Baal, Choose you one bull for yourselves, and dress it first; for you are many; and call on the name of your god, but put no fire under.
<G-vec00485-002-s626><call_upon.rufen><de> 25Und Elia sprach zu den Propheten Baals: Wählt ihr einen Stier und richtet zuerst zu, denn ihr seid viele, und ruft den Namen eures Gottes an, aber legt kein Feuer daran.
<G-vec00485-002-s665><call_upon.telefonieren><en> Whether you need to make a call while driving, require current traffic information, want to reach your destination using the navigation system or simply want to listen to your own music – your Golf SV provides various options for using modern technology in a convenient and uncomplicated way.
<G-vec00485-002-s665><call_upon.telefonieren><de> Infotainment Ob Sie beim Fahren telefonieren müssen, aktuelle Verkehrsinformationen benötigen, per Navigation Ihr Ziel erreichen wollen oder einfach nur Ihre eigene Musik hören möchten – Ihr Golf Sportsvan bietet Ihnen diverse Möglichkeiten, moderne Technik bequem und unkompliziert zu nutzen.
<G-vec00485-002-s666><call_upon.telefonieren><en> No, the man in the picture does not want to call, but checks with the help of the 'Internet of Things', if he has loaded all his tools and not has forgotten any at his former working place.
<G-vec00485-002-s666><call_upon.telefonieren><de> Nein, der Mitarbeiter auf dem Bild will nicht telefonieren, sondern überprüft mit Hilfe des 'Internets der Dinge', ob er alle Werkzeuge eingeladen, also keins auf der Baustelle vergessen hat.
<G-vec00485-002-s667><call_upon.telefonieren><en> 3 Keeping in touch 3 Keeping in touch Call in style Launching the Phone app Your ASUS Tablet’s Phone app offers you many ways to make a call.
<G-vec00485-002-s667><call_upon.telefonieren><de> 3 In Kontakt bleiben In Verbindung bleiben 3 Stilvoll telefonieren Starten der Phone-App Die Telefon-App Ihres ASUS Tablets bietet Ihnen viele Möglichkeiten, einen Anruf abzusetzen.
<G-vec00485-002-s668><call_upon.telefonieren><en> Employees can make a call or send an email or fax directly from SAP, Microsoft Dynamics & Co.
<G-vec00485-002-s668><call_upon.telefonieren><de> Mitarbeiter können direkt aus SAP, Microsoft Dynamics & Co. telefonieren, eine Mail oder ein Fax versenden.
<G-vec00485-002-s669><call_upon.telefonieren><en> If you have to make a phone call while travelling, be careful not to sit in the quiet section when booking your business trip.
<G-vec00485-002-s669><call_upon.telefonieren><de> Wenn du während der Fahrt telefonieren musst, achte bei der Buchung der Geschäftsreise darauf, nicht im Ruheabteil zu sitzen.
<G-vec00485-002-s670><call_upon.telefonieren><en> Until now, it simply wasn’t possible to listen to music, watch TV, or make a phone call with the vacuum cleaner on in the background.
<G-vec00485-002-s670><call_upon.telefonieren><de> Bis jetzt war es schlicht und einfach nicht möglich, Musik zu hören, fernzusehen oder zu telefonieren, wenn ein Staubsauger im Hintergrund lief.
<G-vec00485-002-s671><call_upon.telefonieren><en> Regardless of whether you use your cell phone to make a call in the morning, drive your electric car to work or boot your laptop, metal weld connections in the lithium-ion cells made by Schunk Sonosystem devices accompany you reliably throughout the whole day.
<G-vec00485-002-s671><call_upon.telefonieren><de> Egal ob Sie morgens mit Ihrem Handy telefonieren, mit Ihrem E-Auto zur Arbeit fahren oder Ihren Laptop hochfahren: Metallschweißungen an den Li-Ionen Zellen von Schunk Sonosystems begleiten Sie zuverlässig den ganzen Tag.
<G-vec00485-002-s672><call_upon.telefonieren><en> In the event that it is a false alarm, you can then lie back and relax and call your friends, as Scope doubles up as a cordless landline telephone.
<G-vec00485-002-s672><call_upon.telefonieren><de> Sollte es bloß falscher Alarm sein, können Sie sich beruhigt zurücklehnen und ganz in Ruhe mit Ihren Freunden telefonieren, denn Scope ist zugleich ein schnurloses Festnetztelefon.
<G-vec00485-002-s673><call_upon.telefonieren><en> No matter where you are from and no matter where exactly you want to call cheap to Russia: from the source of the Volga to the Caspian Sea.
<G-vec00485-002-s673><call_upon.telefonieren><de> Egal woher Sie stammen und egal wohin genau Sie günstig nach Russland telefonieren möchten: von der Quelle der Wolga bis ans kaspische Meer.
<G-vec00485-002-s674><call_upon.telefonieren><en> Surf, Call, Text security that keeps your communications safe by blocking unwanted content and contact
<G-vec00485-002-s674><call_upon.telefonieren><de> Sicherheit beim Surfen, Telefonieren und Simsen schützt Ihre gesamte Kommunikation, indem unerwünschte Inhalte und Kontakte gesperrt werden.
<G-vec00485-002-s675><call_upon.telefonieren><en> Up to 8 hours battery life while being used on a call, and up to 200 hours on standby.
<G-vec00485-002-s675><call_upon.telefonieren><de> Bis zu 8 Stunden Akkulaufzeit beim Telefonieren und bis zu 200 Stunden im Standby-Betrieb.
<G-vec00485-002-s676><call_upon.telefonieren><en> Why to call if all the important information about the office services and working schedules obviously placed on the homepage.
<G-vec00485-002-s676><call_upon.telefonieren><de> Warum telefonieren, wenn alle wichtigen Informationen über die Leistungen und Arbeitszeiten offensichtlich auf der Homepage platziert sind.
<G-vec00485-002-s677><call_upon.telefonieren><en> Intern: By dialing the room number, you can call another room in the hotel free of charge.
<G-vec00485-002-s677><call_upon.telefonieren><de> Intern: Durch wählen der Zimmernummer können Sie im Haus kostenfrei zu einem anderen Zimmer telefonieren.
<G-vec00485-002-s678><call_upon.telefonieren><en> They are third party modules integrated into apps to track the user and „call home“ with their findings.
<G-vec00485-002-s678><call_upon.telefonieren><de> Dabei handelt es sich um in Apps eingebundene Module von Drittanbietern, die das Verhalten der Anwender beobachten und „nach Hause telefonieren“.
<G-vec00485-002-s679><call_upon.telefonieren><en> We couldn’t call each other or text, but in the end we found each other.
<G-vec00485-002-s679><call_upon.telefonieren><de> Telefonieren und SMSen war nicht möglich, aber schlussendlich fanden wir uns doch.
<G-vec00485-002-s680><call_upon.telefonieren><en> They want to make a call.
<G-vec00485-002-s680><call_upon.telefonieren><de> Sie möchten telefonieren.
<G-vec00485-002-s681><call_upon.telefonieren><en> Except you call a local KBC employee from the comfort of your home, outside office hours.
<G-vec00485-002-s681><call_upon.telefonieren><de> Sie telefonieren mit einem KBC-Mitarbeiter aus Ihrer Nähe, ruhig von zu Hause aus, auch außerhalb der Geschäftszeiten.
<G-vec00485-002-s682><call_upon.telefonieren><en> Being a full-blown alternative to a fixed line, it can meet the needs of customers who want to call while remaining connected to the data network. Fixed-line replacement
<G-vec00485-002-s682><call_upon.telefonieren><de> Als vollwertige Alternative zum Festnetz geht man auf die Bedürfnisse der Kunden ein, welche telefonieren sowie gleichzeitig über einen Datennetzanschluss verfügen möchten, aber aus unterschiedlichen Gründen kein Festnetz haben.
<G-vec00485-002-s683><call_upon.telefonieren><en> How to call from Skype for free, we have already figured out.
<G-vec00485-002-s683><call_upon.telefonieren><de> Wie telefonieren mit "Skype" kostenlos, haben wir bereits verstanden.
<G-vec00485-002-s722><call_upon.verlangen><en> The SDGs call for a division of labour and a concentration on low income countries that are especially dependent on external support.
<G-vec00485-002-s722><call_upon.verlangen><de> Die SDGs verlangen einen arbeitsteiligen Ansatz und eine Konzentration auf Ländern, die besonders stark von externer Unterstützung abhängig sind.
<G-vec00485-002-s723><call_upon.verlangen><en> The Registrar has broad powers over trade union accounts, including the right to call for accounts at any time and to investigate any accounts that the Registrar considers unsatisfactory (ss 39 and 40, Trade Unions Act).
<G-vec00485-002-s723><call_upon.verlangen><de> Der zuständige Beamte hat weitreichende Befugnisse bezüglich Gewerkschaftskonten wie zum Beispiel das Recht, jederzeit Kontoauszüge zu verlangen oder Konten zu prüfen, die er für unbefriedigend hält (Artikel 39 und 40 des Gewerkschaftsgesetzes).
<G-vec00485-002-s724><call_upon.verlangen><en> They shall also be entitled to call for the data to be updated, rectified, supplemented or deleted, ask for them to be blocked or object to their processing, and require further information on the processing of personal data by contacting Assicurazioni Generali, Piazza Duca degli Abruzzi 2, 34132 Trieste.
<G-vec00485-002-s724><call_upon.verlangen><de> Sie sind auch berechtigt zu verlangen, dass die Daten aktualisiert, korrigiert, ergänzt oder gelöscht werden; sie können die Daten blockieren lassen oder ihre Verarbeitung ablehnen sowie weitere Informationen über die Verarbeitung der personenbezogenen Daten verlangen, indem sie sich mit Assicurazioni Generali, Piazza Duca degli Abruzzi 2, 34132 Triest, in Verbindung setzen.
<G-vec00485-002-s725><call_upon.verlangen><en> They also call for the clubs to respect the legislation dealing with immigration, especially when they employ young players from other countries, and the possibility of their returning to their country of origin if their career doesn’t take off.
<G-vec00485-002-s725><call_upon.verlangen><de> Die Abgeordneten verlangen von den Sportvereinen, dass sie insbesondere bei der Verpflichtung jugendlicher Sportler aus Drittländern bestehende Einwanderungsvorschriften einhalten und ihnen die Möglichkeit der Rückkehr in ihr Heimatland offen lassen, falls ihre Karriere nicht wie geplant verläuft.
<G-vec00485-002-s726><call_upon.verlangen><en> New technical capabilites and new moral challenges in clinical medicine call for new parameters and principles in post-Hippocratic health care ethics.
<G-vec00485-002-s726><call_upon.verlangen><de> Neue technische Möglichkeiten und neue ethische Herausforderungen der klinischen Medizin verlangen nach dem Ausmessen neuer Parameter der klinischen Ethik jenseits von Hippokrates.
<G-vec00485-002-s727><call_upon.verlangen><en> These requirements call for structure and for a perfect balance of text and visual elements.
<G-vec00485-002-s727><call_upon.verlangen><de> Forderungen, die eine übersichtliche Struktur und ein perfektes Zusammenspiel zwischen den verbalen und visuellen Elementen verlangen.
<G-vec00485-002-s728><call_upon.verlangen><en> Since this look can take on a costume makeup appearance, save it for special occasions that call for getting dressed up in style.
<G-vec00485-002-s728><call_upon.verlangen><de> Da dieser Look ein Kostüm-Make-up-Erscheinungsbild annehmen kann, solltest du ihn für besondere Ereignisse aufheben, die danach verlangen, dass du dich mit Stil zurecht machst.
<G-vec00485-002-s729><call_upon.verlangen><en> Anarcho-primitivists like the Fifth Estate paper in Detroit call for nothing less than the eradication of industrial-technological society and a return to primitive communism.
<G-vec00485-002-s729><call_upon.verlangen><de> Anarcho-Primitivlinge wie die Zeitung FIFTH ESTATE in Detroit verlangen nichts geringeres als die Ausmerzung der industriell-technologischen Gesellschaft und die Rückkehr zum primitiven Kommunismus.
<G-vec00485-002-s730><call_upon.verlangen><en> Different employers and situations will call for different styles and tones in a cover letter.
<G-vec00485-002-s730><call_upon.verlangen><de> Verschiedene Arbeitgeber und Situationen verlangen nach einem sehr unterschiedlichen Stil und Ton im Bewerbungsschreiben.
<G-vec00485-002-s731><call_upon.verlangen><en> One is thus led to think that perhaps David Irving, by taking the great risk of launching his libel suit, secretly intended to call the cards of his opponents and that we now see their hand, in the form of van Pelt's book.
<G-vec00485-002-s731><call_upon.verlangen><de> Da er sein Plädoyer nun dennoch so vorträgt, kann man vielleicht darauf schließen, dass David Irving, als er das große Risiko seiner Verleumdungsklage auf sich nahm, insgeheim darauf abzielte, von seinen Gegnern zu verlangen, ihre Karten auf den Tisch zu legen und wir nun diese Karten in Gestalt von van Pelts Buch vor uns haben.
<G-vec00485-002-s732><call_upon.verlangen><en> Heavier trucks require tires to match, and new tire product lines call for matching tire retreading materials.
<G-vec00485-002-s732><call_upon.verlangen><de> Schwere Lkws fordern passende Reifen und neue Reifenproduktlinien verlangen nach passenden Materialien für die Runderneuerung.
<G-vec00485-002-s733><call_upon.verlangen><en> Most recommendations call for repeating each exercise 10 times, at least twice a week, for noticeable results.
<G-vec00485-002-s733><call_upon.verlangen><de> Die meisten Empfehlungen verlangen, dass jede Übung zehn Mal wiederholt wird, mindestens zweimal pro Woche, um spürbare Ergebnisse zu erzielen.
<G-vec00485-002-s734><call_upon.verlangen><en> New energy efficiency targets, such as the 80PLUS® Gold requirement promoted by Climate Savers Computing Initiative, call for approximately a 10 percent improvement in the energy efficiency of computers compared to the current requirements of the U.S. Energy Star program.
<G-vec00485-002-s734><call_upon.verlangen><de> Neue Vorgaben zur Energieeinsparung wie die 80PLUS® Gold-Anforderung der Climate Savers Computing Initiative verlangen bei Computern eine weitere Verbesserung der Energieeffizienz im Vergleich zum derzeitigen U.S. Energy Star Programm.
<G-vec00485-002-s735><call_upon.verlangen><en> Accelerated social and technological changes call for new attitudes and behaviours on the part of individuals, groups and institutions.
<G-vec00485-002-s735><call_upon.verlangen><de> Beschleunigte gesellschaftliche und technologische Wandlungsprozesse verlangen neue Einstellungen und Verhaltensweisen von Individuen, Gruppen und Institutionen.
<G-vec00485-002-s736><call_upon.verlangen><en> It is in this spirit that we call for a European peace initiative with a set timeframe leading to tangible results in the context of the two-state solution, which should include an international monitoring and implementation mechanism.
<G-vec00485-002-s736><call_upon.verlangen><de> In diesem Geiste verlangen wir eine europäische Friedensinitiative mit einem festgelegten Zeitrahmen, die zu konkreten Ergebnissen im Rahmen der Zwei-Staaten-Lösung führt und einen internationalen Überwachungs- und Umsetzungsmechanismus beinhalten sollte.
<G-vec00485-002-s737><call_upon.verlangen><en> Call for an ambulance as soon as possible because the casualty needs hospital care.
<G-vec00485-002-s737><call_upon.verlangen><de> Einen Krankenwagen so bald wie möglich verlangen, weil der Unfall Krankenhausobacht benötigt.
<G-vec00485-002-s738><call_upon.verlangen><en> In order to completely exit Container Shipping, TUI will obtain the right to call for an IPO with priority placement of the shares held by TUI any time as of end of June 2012.
<G-vec00485-002-s738><call_upon.verlangen><de> Um den vollständigen Ausstieg aus der Containerschiffahrt zu vollziehen, erhält TUI das Recht, jederzeit ab Ende Juni 2012 einen Börsengang mit vorrangiger Platzierung der von TUI gehaltenen Aktien zu verlangen.
<G-vec00485-002-s739><call_upon.verlangen><en> This shows that the call for a united “Fatherland” had a very material background.
<G-vec00485-002-s739><call_upon.verlangen><de> Man sieht hieraus, wie das Verlangen nach einem einheitlichen "Vaterland" einen sehr materiellen Hintergrund besaß.
<G-vec00485-002-s740><call_upon.verlangen><en> The Trump administration and the Republican Party will get nearly everything they want, while the Democrats wage a phony war and call on the victims of Trump’s attacks to wait until the 2018 elections.
<G-vec00485-002-s740><call_upon.verlangen><de> Die Trump-Regierung und die Republikaner werden fast alles durchsetzen, während die Demokraten nur symbolisch kämpfen und von den Opfern verlangen, dass sie sich bis zur Kongresswahl 2018 gedulden.
