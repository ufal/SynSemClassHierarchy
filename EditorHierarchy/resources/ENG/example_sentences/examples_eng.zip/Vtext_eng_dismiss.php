<G-vec00555-002-s108><dismiss.abberufen><en> 12. After prior approval by the regulatory authority, the Supervisory Body may dismiss the compliance officer.
<G-vec00555-002-s108><dismiss.abberufen><de> (11) Nach vorheriger Zustimmung der Regulierungsbehörde kann das Aufsichtsorgan den Gleichbehandlungsbeauftragten abberufen.
<G-vec00555-002-s028><dismiss.ablegen><en> You must dismiss the fear of the concentration.
<G-vec00555-002-s028><dismiss.ablegen><de> Du musst die Furcht vor der Konzentration ablegen.
<G-vec00555-002-s118><dismiss.ablehnen><en> Human beings are not yet able to imagine such intervention by God and thus dismiss what they find difficult to believe in.
<G-vec00555-002-s118><dismiss.ablehnen><de> Noch können sich die Menschen einen solchen Eingriff von seiten Gottes nicht vorstellen, und sie lehnen daher ab, was ihnen schwerfällt zu glauben.
<G-vec00555-002-s147><dismiss.abtun><en> Scenes from the world's future I know things before they happen but I usually dismiss it as a logical outcome of previous events.
<G-vec00555-002-s147><dismiss.abtun><de> Szenen aus der Zukunft der Welt Ich weiß Dinge, bevor sie passieren, aber für gewöhnlich tue ich es als logische Folge früherer Ereignisse ab.
<G-vec00555-002-s051><dismiss.abweisen><en> 37 The Commission contends that the Court should: – dismiss the action; – order the applicants to pay the costs.
<G-vec00555-002-s051><dismiss.abweisen><de> 45 Die Kommission beantragt, – die Klage abzuweisen; – der Klägerin die Kosten aufzuerlegen.
<G-vec00555-002-s052><dismiss.abweisen><en> With the appeal approved by the Court of Appeal, the defendant continues to pursue its claim to dismiss the action.
<G-vec00555-002-s052><dismiss.abweisen><de> Mit der vom Berufungsgericht zugelassenen Revision verfolgt der Beklagte seinen Antrag, die Klage abzuweisen, weiter.
<G-vec00555-002-s053><dismiss.abweisen><en> Nonsensical input, for example, the input of text in a date field, it is appropriate to dismiss this entry.
<G-vec00555-002-s053><dismiss.abweisen><de> Bei unsinnigen Eingaben, beispielsweise die Eingabe eines Textes in ein Datumsfeld, ist es angemessen, diese Eingabe abzuweisen.
<G-vec00555-002-s054><dismiss.abweisen><en> This trait is never given to recruited units, so it may be unwise to dismiss such units or to send them to a foolish death.
<G-vec00555-002-s054><dismiss.abweisen><de> Diese Charakteristik wird nicht an ausgebildete Einheiten vergeben, weshalb es unklug sein mag, Freiwillige abzuweisen oder unsinnigerweise in den sicheren Tod zu schicken.
<G-vec00555-002-s027><dismiss.abwerten><en> Whereas at one time it was fashionable to dismiss it as a "language of peasants", today it is “in”.
<G-vec00555-002-s027><dismiss.abwerten><de> Während sie früher als "Bauernsprache" abgewertet wurde, gilt sie heute als hip.
<G-vec00555-002-s175><dismiss.abwinken><en> Step 1 – Speak Italian and Spanish and then laugh and dismiss with a wave the Romanian language.
<G-vec00555-002-s175><dismiss.abwinken><de> Schritt 1 – Sprich Italienisch und Spanisch und lach und wink ab.
<G-vec00555-002-s056><dismiss.anweisen><en> If you don't want to see reminders for events in the past, you can tell Outlook to automatically dismiss reminders for past events.
<G-vec00555-002-s056><dismiss.anweisen><de> Wenn Sie keine Erinnerung für Ereignisse in der Vergangenheit sehen möchten, können Sie Outlook anweisen, die Erinnerung für vergangene Ereignisse automatisch zu schließen.
<G-vec00555-002-s060><dismiss.ausblenden><en> Notifications appear briefly in the top-right corner of the screen or stay there until you dismiss them.
<G-vec00555-002-s060><dismiss.ausblenden><de> Die Mitteilungen werden für einen kurzen Moment oben rechts auf dem Bildschirm eingeblendet oder sie bleiben dort, bis du sie ausblendest.
<G-vec00555-002-s064><dismiss.ausreden><en> They both listened and seemed sympathetic, but also tried to dismiss the event or tell me why it wasn't real.
<G-vec00555-002-s064><dismiss.ausreden><de> Beide hörten zu und schienen mitfühlend, aber versuchten auch mir das Ereignis auszureden oder mir zu sagen, warum es nicht real war.
<G-vec00555-002-s102><dismiss.ausschalten><en> Scientifically one seeks to explain and justify everything in creation, but to dismiss a creating power - so to completely deny it.
<G-vec00555-002-s102><dismiss.ausschalten><de> Man sucht wissenschaftlich alles in der Schöpfung zu erklären und begründen, eine erschaffende Macht aber auszuschalten - also sie gänzlich zu leugnen.
<G-vec00555-002-s061><dismiss.ausstellen><en> Our alarm clock offers the following dismiss options: screen button, volume buttons, power button, or shaking your phone.
<G-vec00555-002-s061><dismiss.ausstellen><de> Unser Wecker bietet folgende Optionen zum Ausstellen: Bildschirmtaste, Lautstärketasten, Ein-/Aus-Taste oder Schütteln des Telefons.
<G-vec00555-002-s065><dismiss.bekräftigen><en> Speaking to a reporter, the president said he was thinking about the investigation into Russian involvement when he decided to dismiss the FBI director.
<G-vec00555-002-s065><dismiss.bekräftigen><de> WashingtonDer kürzlich entlassene FBI-Direktor James Comey will einem Medienbericht zufolge in der Russland-Affäre erhobene Vorwürfe gegen US-Präsident Donald Trump bekräftigen.
<G-vec00555-002-s069><dismiss.diffamieren><en> It is wrong and cynical to dismiss this international consensus as mere lip service.
<G-vec00555-002-s069><dismiss.diffamieren><de> Diesen internationalen Konsens als Lippenbekenntnis zu diffamieren, ist falsch und zynisch.
<G-vec00555-002-s073><dismiss.entbinden><en> Yes. Even if you have no earnings, it does not always dismiss you from filing taxes in the US; it will most likely result in you not paying any tax.
<G-vec00555-002-s073><dismiss.entbinden><de> Ich verdiene kein (wenig) Geld – auch wenn Sie über kein (wenig) Einkommen verfügen, entbindet Sie dies nicht von der Pflicht, in den USA eine Steuererklärung einzureichen.
<G-vec00555-002-s074><dismiss.entheben><en> (9) The General Meeting may dismiss the entire Board or any of its Members.
<G-vec00555-002-s074><dismiss.entheben><de> (9) Die Generalversammlung kann den gesamten Vorstand oder einzelne seiner Mitglieder entheben.
<G-vec00555-002-s095><dismiss.entlassen><en> 3 and if I should dismiss them to their home fasting, they will faint on the way; for some of them are come from far.
<G-vec00555-002-s095><dismiss.entlassen><de> 3 und wenn ich sie nach Hause entlassen, ohne daß sie gegessen haben, so werden sie auf dem Wege verschmachten; denn etliche von ihnen sind von ferne gekommen.
<G-vec00555-002-s174><dismiss.freigeben><en> Use: Summon and dismiss your yellow balloon.
<G-vec00555-002-s174><dismiss.freigeben><de> Benutzen: Euren grünen Ballon beschwören oder wieder freigeben.
<G-vec00555-002-s107><dismiss.genießen><en> Yes he is in fact a brilliant musician, a songwriter of fine tunes, which need a certain mood, otherwise the dismiss the wanted effect.
<G-vec00555-002-s107><dismiss.genießen><de> Ja, er ist tatsächlich ein guter Musiker, ein Songwriter der filigranen Töne, die vor allem in der richtigen Stimmung genossen werden müssen.
<G-vec00555-002-s111><dismiss.hinweisen><en> If someone points out a potential future problem, you can simply dismiss them by saying "we'll cross that bridge when we come to it"; literally meaning "I don't want to think about this now. Let's hope it won't happen, but if it does, we'll handle the problem then."
<G-vec00555-002-s111><dismiss.hinweisen><de> Falls jemand dich auf ein potentielles Problem in der Zukunft hinweist, kannst du einfach sagen: "We'll cross that bridge when we come to it" = da möchte ich jetzt nicht drüber nachdenken, wir hoffen einfach mal, dass es nicht passiert, aber darüber machen wir uns erst Gedanken, wenn wir wirklich müssen.
<G-vec00555-002-s112><dismiss.ignorieren><en> You can choose to dismiss this alert.
<G-vec00555-002-s112><dismiss.ignorieren><de> Sie können diesen Fehler ignorieren.
<G-vec00555-002-s123><dismiss.kündigen><en> During this 26-week period, the employer may neither dismiss the employee with notice nor call him to a preliminary interview in view of dismissal with notice nor dismiss him for serious misconduct which took place prior to the sick leave.
<G-vec00555-002-s123><dismiss.kündigen><de> Während der Dauer der Arbeitsunfähigkeit (und innerhalb der Grenze der ersten 26 Wochen der Arbeitsunfähigkeit) darf der Arbeitgeber ihm demnach nicht ordentlich kündigen, ihn nicht zu einem Vorgespräch im Hinblick auf eine ordentliche Kündigung einbestellen und ihn auch nicht wegen einer vor der Arbeitsunfähigkeit liegenden schwerwiegenden Verfehlung entlassen.
<G-vec00555-002-s120><dismiss.löschen><en> You can also tap to dismiss all notifications and close the Notifications panel.
<G-vec00555-002-s120><dismiss.löschen><de> Sie können auch auf tippen, um alle Benachrichtigungen zu löschen und das Benachrichtigungsfeld zu löschen.
<G-vec00555-002-s055><dismiss.missverstehen><en> There is plenty of utopianism and idealism in all these films which a pragmatic view of the world could easily dismiss.
<G-vec00555-002-s055><dismiss.missverstehen><de> Es lässt sich hier jede Menge Utopie und Idealismus finden, die eine pragmatische Sicht auf die Lage der Welt nur allzu leicht missversteht.
<G-vec00555-002-s116><dismiss.schließen><en> Or dismiss the notification to install Mojave later.
<G-vec00555-002-s116><dismiss.schließen><de> Alternativ können Sie die Mitteilung schließen, um Mojave später zu installieren.
<G-vec00555-002-s142><dismiss.sehen><en> Others dismiss his criticism as a cheap way of gaining votes.
<G-vec00555-002-s142><dismiss.sehen><de> Andere sehen die Kritik an Deutschland als billiges Mittel zum Stimmenfang.
<G-vec00555-002-s150><dismiss.unterschätzen><en> This feature might be down on our list of must-have things that property buyers are looking for, but don´t dismiss it´s importance.
<G-vec00555-002-s150><dismiss.unterschätzen><de> Diese Eigenschaft mag vielleicht unten auf unserer Liste der Dinge stehen, nach denen Immobilienkäufer suchen, aber unterschätzen Sie nicht ihre Bedeutung.
<G-vec00555-002-s104><dismiss.verachten><en> This is why one should never be too quick to dismiss a copy.
<G-vec00555-002-s104><dismiss.verachten><de> Nie sollte man deswegen eine Kopie zu früh verachten.
<G-vec00555-002-s152><dismiss.verlassen><en> Dismiss the lock screen by swiping up from the bottom edge of the screen or by pressing a key if you have a Surface Typing Cover attached.
<G-vec00555-002-s152><dismiss.verlassen><de> Verlassen Sie den Sperrbildschirm, indem Sie vom unteren Bildschirmrand nach oben wischen oder, falls ein Surface-Tastatur-Cover angeschlossen ist, indem Sie eine Taste drücken.
<G-vec00555-002-s153><dismiss.verlassen><en> Well, the owner of the station listened but had to quickly dismiss her with the promise to pray.
<G-vec00555-002-s153><dismiss.verlassen><de> Nun, die Besitzerin des Senders hörte zu, aber musste sie rasch verlassen, jedoch versprach sie, dafür zu beten.
<G-vec00555-002-s154><dismiss.vertreiben><en> The wish to eradicate the bad thoughts would dismiss the good ones too.
<G-vec00555-002-s154><dismiss.vertreiben><de> Der Wunsch, die schlechten Gedanken auszumerzen würde auch die guten vertreiben.
<G-vec00555-002-s155><dismiss.verweisen><en> DISMISSALS The Management reserves the right to dismiss any person who fails to comply with the regulations set forth herein, without any kind of refund.
<G-vec00555-002-s155><dismiss.verweisen><de> Die Direktion hat das Recht ohne jegliche Kostenerstattung all diejenigen von der Ferienanlage zu verweisen, die nicht die Bestimmungen der vorliegenden Platzordnung beachten.
<G-vec00555-002-s156><dismiss.verweisen><en> I am well aware that in the areas of politics and philosophy there are those who firmly reject the idea of a Creator, or consider it irrelevant, and consequently dismiss as irrational the rich contribution which religions can make towards an integral ecology and the full development of humanity.
<G-vec00555-002-s156><dismiss.verweisen><de> Ich weiß sehr wohl, dass auf dem Gebiet der Politik und des Denkens einige mit Nachdruck die Idee eines Schöpfers ablehnen oder sie als irrelevant betrachten, bis zu dem Punkt, den Reichtum, den die Religionen für eine ganzheitliche Ökologie und eine volle Entwicklung der Menschheit bieten können, in den Bereich des Irrationalen zu verweisen.
<G-vec00555-002-s157><dismiss.verwerfen><en> I dismiss all my debilitating emotions now.
<G-vec00555-002-s157><dismiss.verwerfen><de> Ich verwerfe jetzt alle meine schwächenden Emotionen.
<G-vec00555-002-s166><dismiss.weglassen><en> However, we cannot exclude or dismiss the evidence presented, and have to acknowledge, "There could be more!”
<G-vec00555-002-s166><dismiss.weglassen><de> Wie auch immer, wir können die vorgelegten Beweise nicht ausschließen oder weglassen und müssen zustimmen, dass "es mehr geben könnte".
<G-vec00555-002-s167><dismiss.wegschicken><en> But we can't dismiss people who are already there as long as we don't have the person or persons capable of actively assuming that position.
<G-vec00555-002-s167><dismiss.wegschicken><de> Diejenigen, die da sind, können wir nicht wegschicken, solange wir nicht eine oder mehrere Personen haben, die aktiv diese Position einnehmen können.
<G-vec00555-002-s168><dismiss.wegwischen><en> But to dismiss the Right’s appeal to moral values is to forget what it offers.
<G-vec00555-002-s168><dismiss.wegwischen><de> Aber den Anspruch der Rechten auf moralische Werte wegzuwischen heißt, dass man vergisst, was er bietet.
<G-vec00555-002-s169><dismiss.weisen><en> The authors of the document dismiss the concept of “exploitation” as a “complaint” by the left.
<G-vec00555-002-s169><dismiss.weisen><de> Die Autoren des Dokuments weisen den Begriff „Ausbeutung“ als „Anklage" der Linken zurück.
<G-vec00555-002-s178><dismiss.zurückweisen><en> The tribunal will dismiss so-called frivolous claims – cases which clearly have no justification – and force the investor to pay the legal costs, including those of the state they have challenged.
<G-vec00555-002-s178><dismiss.zurückweisen><de> Das Gericht wird ungerechtfertigte Klagen, also eindeutig unbegründete Fälle, zurückweisen und dem Investor die Prozesskosten auferlegen, darunter auch die des beklagten Staates.
<G-vec00555-002-s194><dismiss.zustellen><en> Notification of dismissal procedure Notification deadlines If the business employs less than 150 staff members, the employer may dismiss with notice immediately.
<G-vec00555-002-s194><dismiss.zustellen><de> Beschäftigt ein Unternehmen weniger als 150 Arbeitnehmer, kann der Arbeitgeber die ordentliche Kündigung ohne Einhaltung einer bestimmten Frist zustellen.
<G-vec00555-002-s125><dismiss.zwingen><en> The European Parliament can also dismiss the Commission, if it is not satisfied with its work.
<G-vec00555-002-s125><dismiss.zwingen><de> Zudem kann das Europäische Parlament die Kommission zum Rücktritt zwingen, wenn es mit ihrer Arbeit unzufrieden ist.
<G-vec00555-002-s148><dismiss.übergehen><en> So, you must learn how to quickly dismiss these distractions and refocus your attention to the task at hand.
<G-vec00555-002-s148><dismiss.übergehen><de> So muessen Sie lernen, wie man diese Ablenkungen schnell uebergeht und die Aufmerksamkeit wieder auf die eigentliche Arbeit konzentriert.
<G-vec00050-002-s029><dismiss.ablehnen><en> When you dismiss a call to send a quick response, the caller is sent to voicemail.
<G-vec00050-002-s029><dismiss.ablehnen><de> Wenn Sie einen Anruf ablehnen und eine Kurzantwort senden, wird der Anrufer zur Mailbox weitergeleitet.
<G-vec00050-002-s030><dismiss.ablehnen><en> If a complaint does not have a reasonable chance of success or cannot be expected to result in the clarification of a constitutional issue, the Constitutional Court may decide to dismiss the case (especially by way of a simplified decision, usually with standard wording).
<G-vec00050-002-s030><dismiss.ablehnen><de> Wenn eine Beschwerde keine hinreichende Aussicht auf Erfolg hat oder die Klärung einer verfassungsrechtlichen Frage nicht erwarten lässt, kann der Verfassungsgerichtshof auch deren Behandlung mit Beschluss ablehnen (besonders vereinfachte Entscheidung, meist mit formelhafter Begründung).
<G-vec00050-002-s031><dismiss.ablehnen><en> To keep Pisces interested, though, Gemini cannot ignore or dismiss the gentle Fishes’ inner longings.
<G-vec00050-002-s031><dismiss.ablehnen><de> Zwillinge können jedoch die inneren Sehnsüchte der sanften Fische nicht ignorieren oder ablehnen, um Fischinteresse zu wecken.
<G-vec00050-002-s032><dismiss.ablehnen><en> You can easily recognize it and therefore quickly dismiss it.
<G-vec00050-002-s032><dismiss.ablehnen><de> Sie können es leicht erkennen und daher schnell ablehnen.
<G-vec00050-002-s033><dismiss.ablehnen><en> For this reason, you can not dismiss the design of windows, as from a minor detail, because it can become the center of the entire interior composition.
<G-vec00050-002-s033><dismiss.ablehnen><de> Aus diesem Grund können Sie das Design von Fenstern nicht von einem kleinen Detail ablehnen, weil es zum Zentrum der gesamten Innenkomposition werden kann.
<G-vec00050-002-s042><dismiss.ablehnen><en> The theory of evolution is a typical example of how a highly speculative and scientifically unsound theory captured the imagination of the masses and has allowed them to dismiss the Biblical account despite the fact that the theory has not been substantiated scientifically and is devoid of any real scientific basis.
<G-vec00050-002-s042><dismiss.ablehnen><de> Die Theorie der Evolution ist ein typisches Beispiel dafür, wie eine sehr spekulative und wissenschaftlich unzulängliche Theorie die Vorstellungskraft der Massen gefesselt und sie dazu verleitet hat, die biblische Darstellung abzulehnen, obwohl die Theorie nicht wissenschaftlich belegt werden konnte und ihr die wissenschaftliche Basis fehlt.
<G-vec00050-002-s043><dismiss.ablehnen><en> Competition leads children to envy winners, to dismiss losers.
<G-vec00050-002-s043><dismiss.ablehnen><de> Wettbewerb bringt Kinder dazu, Gewinner zu beneiden und Verlierer abzulehnen.
<G-vec00050-002-s179><dismiss.zurückweisen><en> Terms such as we cannot dismiss, we cannot rule out, or we cannot discount reflect an unlikely, improbable, or remote event whose consequences are such that it warrants mentioning.
<G-vec00050-002-s179><dismiss.zurückweisen><de> Begriffe wie wir können nicht zurückweisen, wir können nicht ausschließen oder wir können nicht ablehnen spiegeln ein nicht wahrscheinliches, unwahrscheinliches oder ein Ereignis von entfernter Wahrscheinlichkeit wider, dessen Konsequenzen derart sind, daß es eine Erwähnung wert ist.
<G-vec00050-002-s181><dismiss.zurückweisen><en> Terry Jenkins was the latest player to dismiss the notion that it is an advantage to know exactly when you are playing in an interview with "Dave" recently.
<G-vec00050-002-s181><dismiss.zurückweisen><de> Terry Jenkins war der bisher letzte Spieler, der es in einem Interview mit "Dave" zurückwies, dass es von Vorteil ist, wenn man genau weiß wann man spielen wird.
<G-vec00050-002-s182><dismiss.zurückweisen><en> If we have reason to suspect that the ordered seeds are destined for growing cannabis on a larger-than-private scale, we reserve the right to dismiss that specific order. Blog How To Make Your Own Hash At Home
<G-vec00050-002-s182><dismiss.zurückweisen><de> Wenn wir Grund dazu haben zu vermuten, dass die bestellten Samen für einen Cannabisanbau bestimmt sind, der einen größeren Umfang als für den privaten Rahmen aufweist, dann behalten wir uns das Recht vor diese spezielle Bestellung zurückzuweisen.
<G-vec00050-002-s185><dismiss.zurückweisen><en> If the rejection is deemed incomprehensible or to have insufficient grounds, Independent Publishing reserves the right to dismiss the rejection.
<G-vec00050-002-s185><dismiss.zurückweisen><de> Ist die Ablehnung unzureichend begründet oder nicht nachvollziehbar, behält sich Independent Publishing das Recht vor, die Ablehnung zurückzuweisen.
<G-vec00050-002-s188><dismiss.zurückweisen><en> Balancing all points at issue, Rose J decided to dismiss Janssen's application for a stay.
<G-vec00050-002-s188><dismiss.zurückweisen><de> Unter Abwägung aller angesprochenen Punkte entschied Rose J, den Antrag von Janssen auf Verfahrensaussetzung zurückzuweisen.
<G-vec00050-002-s190><dismiss.zurückweisen><en> Mutations in most other significant genes occurred in frequencies too low to draw firm conclusions, but Ellis says it's premature to dismiss their importance.
<G-vec00050-002-s190><dismiss.zurückweisen><de> Veränderungen in den meisten anderen beträchtlichen Genen traten in den Frequenzen zu niedrig auf, um feste Schlussfolgerungen zu zeichnen, aber Ellis sagt, dass es vorzeitig ist, ihre Bedeutung zurückzuweisen.
<G-vec00050-002-s193><dismiss.zurückweisen><en> At the end of the oral proceedings the decision of the Board to dismiss the appeal as well as the appellant's petitions 2, 3 and 4 and the respondent's request for an award of costs under Article 104 EPC was announced.
<G-vec00050-002-s193><dismiss.zurückweisen><de> Am Ende der mündlichen Verhandlung verkündete die Kammer ihre Entscheidung, die Beschwerde, die Anträge 2, 3 und 4 des Beschwerdeführers und den vom Beschwerdegegner nach Artikel 104 EPÜ gestellten Kostenverteilungsantrag zurückzuweisen.
