<G-vec01009-002-s022><cite.anführen><en> And if, nevertheless, we insist strongly that the reader be fully clear on this generally known fact, if we cite, for explicitness, as it were, the facts of the first edition of Rabocheye Dyelo and of the polemic between the “old” and the “young” at the beginning of 1897, we do this because the people who vaunt their “democracy” speculate on the ignorance of these facts on the part of the broad public (or of the very young generation).
<G-vec01009-002-s022><cite.anführen><de> Und wenn wir trotzdem besonders darauf bestehen, daß der Leser sich über diese allgemein bekannte Tatsache völlig klar wird, wenn wir sozusagen der Anschaulichkeit halber Material über das Rabotscheje Delo erster Fassung und über die Meinungsverschiedenheiten zwischen den „Alten“ und den „Jungen“ zu Beginn des Jahres 1897 anführen, so tun wir es, weil die Leute, die mit ihrem „Demokratismus“ protzen, darauf spekulieren, daß das breite Publikum (oder die blutjunge Generation) diese Tatsache nicht kennt.
<G-vec01009-002-s023><cite.anführen><en> One can cite the following identification marks: I can sin or commit a sin against the latter, but I can only lose, push away, or deprive myself of the other, i.e., act imprudently.
<G-vec01009-002-s023><cite.anführen><de> Man könnte folgendes Erkennungszeichen dafür anführen: gegen jene kann Ich Mich versündigen oder eine Sünde begehen, die andere nur verscherzen, von Mir stoßen, Mich darum bringen, d.h. eine Unklugheit begehen.
<G-vec01009-002-s024><cite.anführen><en> Common criteria can hardly cite.
<G-vec01009-002-s024><cite.anführen><de> Gängige Kriterien kann man kaum anführen.
<G-vec01009-002-s025><cite.anführen><en> We could cite many more instances; in every one of them we would find this fundamental difference between West and East.
<G-vec01009-002-s025><cite.anführen><de> Und so könnte man vieles, vieles anführen, man würde in allem finden diesen fundamentalen Gegensatz zwischen dem Westen und dem Osten.
<G-vec01009-002-s026><cite.anführen><en> PROJECTS There would be many projects that we could cite as our reference projects.
<G-vec01009-002-s026><cite.anführen><de> REFERENZPROJEKTE Es gäbe viele Projekte, die wir als unsere Referenzprojekte anführen könnten.
<G-vec01009-002-s027><cite.anführen><en> Now we need to cite a small classification of emotionally colored expressions.
<G-vec01009-002-s027><cite.anführen><de> Jetzt müssen wir eine kleine Klassifizierung emotional gefärbter Ausdrücke anführen.
<G-vec01009-002-s028><cite.anführen><en> Despite the unresolved questions about benefits and risks, it is obviously misleading to cite this study as evidence that forskolin has been proven to melt belly fat or improve weight loss.
<G-vec01009-002-s028><cite.anführen><de> Trotz der ungelösten Fragen über Nutzen und Risiken, ist es offensichtlich irreführend, diese Studie als Beweis zu anführen, dass Forskolin ist nachgewiesen worden, um Bauchfett zu schmelzen oder Gewichtsverlust zu verbessern.
<G-vec01009-002-s029><cite.anführen><en> At this point I would like to cite another quote that particularly appeals to me as a liberal: Art is the daughter of freedom, said Friedrich Schiller.
<G-vec01009-002-s029><cite.anführen><de> Hier möchte ich ein weiteres Zitat anführen, das mir als Liberalem besonders gut gefällt: Die Kunst ist eine Tochter der Freiheit so Friedrich Schiller.
<G-vec01009-002-s030><cite.anführen><en> However, anyone who is already on his territory will be able to cite ever more ‘evidence’ which is all but deception and illusion.
<G-vec01009-002-s030><cite.anführen><de> Wer aber sich schon auf seinem Boden befindet, der wird stets mehr „Beweise“ anführen können, die jedoch nicht anders zu bewerten sind als Trug und Schein.
<G-vec01009-002-s035><cite.anführen><en> Today, when they ask me why Russia is spreading fake news I ask them to cite at least one example.
<G-vec01009-002-s035><cite.anführen><de> Wenn ich jetzt gefragt werde, warum Russland „Fake News“ verbreitet, bitte ich immer, wenigstens ein Beispiel anzuführen.
<G-vec01009-002-s036><cite.anführen><en> How to cite this document (one suggested style): "Avannaraha Sutta: Dispraise" (AN 4.83), Published by Zugang zur Einsicht on:
<G-vec01009-002-s036><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Avannaraha Sutta: Tadel" (AN 4.83), übersetzt aus dem Pail vom Ehrw.
<G-vec01009-002-s037><cite.anführen><en> How to cite this document (one suggested style): "Anagata-bhayani Sutta: The Discourse on Future Dangers (3)" (AN 5.79), translated from the Pali by Thanissaro Bhikkhu.
<G-vec01009-002-s037><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Anagata-bhayani Sutta: Die Lehrrede über Zukünftige Gefahren (3)" (AN 5.79), übersetzt aus dem Pali von Thanissaro Bhikkhu.
<G-vec01009-002-s038><cite.anführen><en> How to cite this document (one suggested style): 'J 125 - Katahaka-Jataka', translated by Robert Chalmers.
<G-vec01009-002-s038><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): 'J 125 Die Erzählung von Katahaka - Katahaka-Jataka', übersetzt von Dr. Julius Dutoit.
<G-vec01009-002-s039><cite.anführen><en> How to cite this document (one suggested style): "Old News Archive: October-December 2001", edited by Access to Insight.
<G-vec01009-002-s039><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Alte Neuigkeiten Archiv: Oktober-Dezember 2001", zusammengestellt von Access to Insight.
<G-vec01009-002-s040><cite.anführen><en> How to cite this document (one suggested style): "Lekha Sutta: Inscriptions" (AN 3.130), translated from the Pali by Thanissaro Bhikkhu.
<G-vec01009-002-s040><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Lekha Sutta: Inschriften" (AN 3.130), übersetzt aus dem Pali von Thanissaro Bhikkhu.
<G-vec01009-002-s041><cite.anführen><en> How to cite this document (one suggested lib/authors/thanissaro/bmc2/bmc2.ch04.html . Retrieved on 10 September 2012 (Offline Edition 2012.09.10.14), republished Alternate formats: Printed copies of this book are available upon request.
<G-vec01009-002-s041><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Kodex für buddhistische Einsiedler II: Literaturverzeichnis", von Übernommen am 12 März 2013 (Offline Edition 2012.09.10.14), wiederveröffentlicht von Zugang zur Einsicht auf Alternative Formate: Gedruckte Ausgaben des Buches können auf Anfrage zur Verfügung gestellt werden.
<G-vec01009-002-s042><cite.anführen><en> How to cite this document (one suggested style): "Better Than a Hundred Years", by Bhikkhu Bodhi.
<G-vec01009-002-s042><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Besser als hundert Jahre", vom Ehrw.
<G-vec01009-002-s043><cite.anführen><en> How to cite this document (one suggested style): “Sammaditthi Sutta: Right View” (MN 9), translated from the Pali by Thanissaro Bhikkhu.
<G-vec01009-002-s043><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): „Bhutamidam Sutta: Dieses ist ins Entstehen gekommen“ (SN 12.31), übersetzt aus dem Pali von Thanissaro Bhikkhu.
<G-vec01009-002-s044><cite.anführen><en> How to cite this document (one suggested style): 'J 380 - Asamka-Jataka', translated by H.T.
<G-vec01009-002-s044><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): 'J 380 Die Erzählung von Asamka - Asamka-Jataka', übersetzt von Dr. Julius Dutoit.
<G-vec01009-002-s045><cite.anführen><en> How to cite this document (one suggested style): "A Glossary of Pali and Buddhist Terms", edited by Access to Insight.
<G-vec01009-002-s045><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Glossar: Ein Worteverzeichnis zu Pali und buddhistischen Ausdrücken", zusammengestellt von Access to Insight.
<G-vec01009-002-s046><cite.anführen><en> How to cite this document (one suggested style): "The Parayana Vagga: The Chapter on the Way to the Far Shore", by Thanissaro Bhikkhu.
<G-vec01009-002-s046><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Der Parayana Vagga: Das Kapitel über den Weg zum fernen Ufer", von thanissaro/parayanavagga.html .
<G-vec01009-002-s047><cite.anführen><en> How to cite this document (one suggested style): 'J 519 - Sambula-Jataka', translated by H.T. Francis.
<G-vec01009-002-s047><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): 'J 519 Die Erzählung von Sambula - Sambula-Jataka', übersetzt von Dr. Julius Dutoit.
<G-vec01009-002-s048><cite.anführen><en> How to cite this document (one suggested style): "Vasala Sutta: Discourse on Outcasts" (Sn 1.7), translated from the Pali by Piyadassi Thera.
<G-vec01009-002-s048><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Vasala Sutta: Lehrrede über Ausgestoßene" (Sn 1.7), übersetzt aus dem Pali von Piyadassi Thera.
<G-vec01009-002-s049><cite.anführen><en> How to cite this document (one suggested style): 'J 248 - Kimsukopama-Jataka', translated by W.H.D. Rouse.
<G-vec01009-002-s049><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): 'J 248 Die Erzählung von dem Vergleich mit dem Kimsuka-Baum - Kimsukopama-Jataka', übersetzt von Dr. Julius Dutoit.
<G-vec01009-002-s050><cite.anführen><en> How to cite this document (one suggested style): "Starting Out Small: A Collection of Talks for Beginning Meditators", by Ajaan Lee Dhammadharo, translated from the Thai by Thanissaro Bhikkhu.
<G-vec01009-002-s050><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Das Dhamma zu deinem Eigen machen: Lehren von Phra Ajaan Khamdee Pabhaso", übersetzt aus dem Thailändischen von Thanissaro Bhikkhu.
<G-vec01009-002-s051><cite.anführen><en> How to cite this document (one suggested style): "Old News Archive: November 2013", edited by Zugang zur Einsicht.
<G-vec01009-002-s051><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): "Alte Neuigkeiten Archiv: November 2013", zusammengestellt von Zugang zur Einsicht.
<G-vec01009-002-s052><cite.anführen><en> How to cite this document (one suggested style): 'J 196 - Valahassa-Jataka', translated by W.H.D. Rouse.
<G-vec01009-002-s052><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): 'J 196 Die Erzählung von dem Flügelross - Valahassa-Jataka', übersetzt von Dr. Julius Dutoit.
<G-vec01009-002-s053><cite.anführen><en> How to cite this document (one suggested style): “Discourses of the Ancient Nuns: (Bhikkhuni-samyutta)”, translated from the Pali by Bhikkhu Bodhi.
<G-vec01009-002-s053><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): „Der Geschmack der Freiheit“, vom Ehrw.
<G-vec01009-002-s054><cite.anführen><en> How to cite this document (one suggested style): "Brahmanavagga: The Holy Man" (Dhp XXVI), translated from the Pali by Acharya Buddharakkhita.
<G-vec01009-002-s054><cite.anführen><de> Wie das Dokument anzuführen ist (ein Vorschlag): übersetzt aus dem Pali von Acharya Buddharakkhita.
<G-vec01009-002-s110><cite.anführen><en> We may cite Proudhon's Philosophie de la Misere as an example of this form.
<G-vec01009-002-s110><cite.anführen><de> Als Beispiel führen wir Proudhons »Philosophie de la misère« an.
<G-vec01009-002-s111><cite.anführen><en> In doing so, the authors cite European values, symbols and day to day realities as evidence.
<G-vec01009-002-s111><cite.anführen><de> Die Autoren führen dabei europäische Werte, Symbole und Alltagsrealitäten als Belege an.
<G-vec01009-002-s112><cite.anführen><en> As an example, they cite drag performances of Queers of Color such as that by Vaginal Davis, which resist subjugating and normalizing discourses, and escape normative categorizations.
<G-vec01009-002-s112><cite.anführen><de> Als Beispiel führen sie Drag Performances von Queers of Color wie die von Vaginal Davis an, die unterdrückenden und normalisierenden Diskursen widerstehen und normativen Kategorisierungen entgehen.
<G-vec01009-002-s113><cite.anführen><en> In business, South African companies are very active in Nigeria but this is a one-way street: Nigerian (and other African) firms frequently cite South Africa’s protectionist policies and BEE regulations as barriers to entering its market and a hard brake on intra-continental trade.
<G-vec01009-002-s113><cite.anführen><de> In der Geschäftswelt sind südafrikanische Unternehmen in Nigeria sehr aktiv, jedoch gleicht dies einer Einbahnstraße: Nigerianische (und andere afrikanische) Unternehmen führen häufig die protektionistischen Maßnahmen und BEE-Regulierungen an, wenn es um Hindernisse für den Markzugang im intrakontinentalen Handel geht.
<G-vec01009-002-s114><cite.anführen><en> We cite as an example the circumcision and the fasting.
<G-vec01009-002-s114><cite.anführen><de> Wir führen als Beispiel die Beschneidung und das Fasten an.
<G-vec01009-002-s115><cite.anführen><en> According to the report Strength amidst uncertainty in 2017 by Moore Stephens, a global accountancy and advisory network, the U.K. construction and real estate firms it surveyed cite export activity as one strategy for growth.
<G-vec01009-002-s115><cite.anführen><de> Nach dem Bericht Strength amidst uncertainty in 2017 von Moore Stephens, einem weltweiten Wirtschaftsprüfungs- und Beraternetzwerk, führen die von ihm befragten Bau- und Immobilienunternehmen in Großbritannien die Exporttätigkeit als eine Wachstumsstrategie an.
<G-vec01009-002-s116><cite.anführen><en> We cite the findings of the Canadian government as an example; Canadian officials state that ‘the (annual) dialogue was created as a cornerstone of Ottawa's policy of engagement with China on human rights, but today there is "pervasive cynicism" and "dialogue fatigue" among most officials.’ The overriding view of many participants in annual bilateral talks with China is that, although talks have been intended to provide genuine dialogue, they have always descended into a rehearsed propaganda exercise.
<G-vec01009-002-s116><cite.anführen><de> Wir führen die Befunde der kanadischen Regierung als Beispiel an: Kanadische Beamte geben an, dass „der (jährliche) Dialog als Eckstein von Ottawas Vorgehensweise der Verpflichtung mit China bezüglich der Menschenrechte geschaffen wurde, aber heute herrscht dort unter den meisten Beamten ‚durchgehender Zynismus’ und ‚Dialogerschöpfung’.“ Die vorrangige Auffassung von vielen Teilnehmern der jährlichen bilateralen Gespräche mit China ist, dass, obwohl ein authentischer Dialog beabsichtigt worden ist, sie immer in eine geprobte Propagandaübung abgestiegen sind.
<G-vec01009-002-s118><cite.anführen><en> They cite, among others, the humanitarian disasters that could be resulted worldwide and the potential for state abuse of human rights.
<G-vec01009-002-s118><cite.anführen><de> Sie führen hierfür unter anderem weltweit resultierende humanitäre Katastrophen sowie das Potential zu staatlichem Missbrauch der Menschenrechte an.
<G-vec01009-002-s129><cite.anführen><en> As an example, one can cite a well-known US American retail chain, which has failed more than miserably in Germany.
<G-vec01009-002-s129><cite.anführen><de> Als Beispiel kann man hier eine namhafte US-amerikanische Handelskette anführen, die in Deutschland mehr als kläglich gescheitert ist.
<G-vec01009-002-s143><cite.anführen><en> I cite two illustrations from the New Testament.
<G-vec01009-002-s143><cite.anführen><de> Ich möchte zwei Beispiele aus dem Neuen Testament anführen.
<G-vec01009-002-s033><cite.angeben><en> Users (redistributors) of EJOP are required to cite the original source, including the author's names, EJOP as the initial source of publication, year of publication, volume number and DOI (if available).
<G-vec01009-002-s033><cite.angeben><de> Benutzer des JBDGM müssen die ursprüngliche Quelle angeben, einschließlich der Namen des Autors, JBDGM als erste Quelle der Veröffentlichung, Jahr der Veröffentlichung, Bandnummer und DOI (falls verfügbar).
<G-vec01009-002-s034><cite.angeben><en> It does not even matter if we cite a source for this one since a short trip to the grocery store is enough for you to see all the processed foods filled with sugar and canned goods filled with salt.
<G-vec01009-002-s034><cite.angeben><de> Es spielt keine Rolle, ob wir dafür eine Quelle angeben, denn ein kurzer Besuch im Lebensmittelgeschäft reicht aus, um alle verarbeiteten Lebensmittel mit Zucker und die mit Salz gefüllten Konserven zu sehen.
<G-vec01009-002-s120><cite.angeben><en> The stenotopic, hygrophilous and graminicolous species lives on simplestem bur-reed (Sparganium erectum) and on common bulrush (Typha latifolia), some authors also cite sedges (Carex) as host plant.
<G-vec01009-002-s120><cite.angeben><de> Die stenotope, hygrophile und gramineicole Art lebt am Ästigen Igelkolben (Sparganium erectum) und am Breitblättrigen Rohrkolben (Typha latifolia), einige Autoren geben auch Seggen (Carex) an.
<G-vec01009-002-s121><cite.angeben><en> Please always cite your customer number, invoice number and reason for returning the product.
<G-vec01009-002-s121><cite.angeben><de> Bitte geben Sie immer Kundennummer, Rechnungsnummer und Grund der Rücksendung an.
<G-vec01009-002-s122><cite.angeben><en> Please cite the following source every time you use our images: “Photo: Messe München.” Thank you. Save the date
<G-vec01009-002-s122><cite.angeben><de> Bitte geben Sie jeder Verwendung unseres Bildmaterials folgende Quellenangabe an: „Foto: Messe München“, danke sehr.
<G-vec01009-002-s124><cite.nennen><en> Interestingly, the things that motivate many bloggers to start blogging — “personal satisfaction” — seem increasingly tied to the reasons they cite when explaining why they stopped blogging.
<G-vec01009-002-s124><cite.nennen><de> Interessant ist, dass die “persönliche Befriedigung”, die viele Blogger zum Bloggen motiviert hat, zunehmend an die Gründe gebunden scheint, die genannt werden, um zu erklären, warum das Bloggen beendet wurde.
<G-vec01009-002-s125><cite.nennen><en> The “deviators” cite examples, which indicate that in many cases the issue is not a more efficient and leaner administration but more deregulation.
<G-vec01009-002-s125><cite.nennen><de> Von den „Abweichlern“ werden Beispiele genannt, die darauf hindeuten, dass es oft weniger um effiziente und schlanke Verwaltung sondern mehr um Deregulierung geht.
<G-vec01009-002-s144><cite.nennen><en> Introduce the author in the sentence but cite the source in parentheses.
<G-vec01009-002-s144><cite.nennen><de> Führe den Autor im Satz an, aber nenne die Quelle in Parenthesen.
<G-vec01009-002-s145><cite.nennen><en> That’s probably why 86% of employees and executives cite lack of collaboration or ineffective communication as the reason for workplace failures.
<G-vec01009-002-s145><cite.nennen><de> Das ist wahrscheinlich auch der Grund, warum 86% der Mitarbeiter und Führungskräfte Mangel an Zusammenarbeit oder ineffektive Kommunikation als Grund für Scheitern am Arbeitsplatz nennen.
<G-vec01009-002-s146><cite.nennen><en> On this part of the coast you will find many typical villages where old traditions live together with modern touristic equipments and organizations: as an example for all we cite the cableway in Malcesine which in only a few minutes allows to reach the summit of Monte Baldo, even taking along your bicycle.
<G-vec01009-002-s146><cite.nennen><de> Hier hat es viele typische kleine Ortschaften, in denen neben alten Traditionen moderne touristische Einrichtungen co-existieren: als Beispiel für alle nennen wir die Seilbahn von Malcesine, mit der man in wenigen Minuten den Gipfel des Monte Baldo, auch zusammen mit dem Fahrrad, erreicht.
<G-vec01009-002-s147><cite.nennen><en> Nonetheless, Germans polled on this subject cite residual pesticides as one of the greatest current health risks.
<G-vec01009-002-s147><cite.nennen><de> Dennoch nennen die Deutschen in Umfragen Pestizidrückstände als eines der aktuell größten Gesundheitsrisiken.
<G-vec01009-002-s148><cite.nennen><en> If the talk is available in audio-video.gnu.org, please cite that site.
<G-vec01009-002-s148><cite.nennen><de> Bitte wählen und nennen Sie audio-video.gnu.org als die Internetpräsenz für Filmaufnahmen meiner Vorträge ‑ nicht YouTube.
<G-vec01009-002-s149><cite.nennen><en> Alongside the radical purification brought about by Baptism or martyrdom they cite as means of obtaining forgiveness of sins: effort at reconciliation with one's neighbor, tears of repentance, concern for the salvation of one's neighbor, the intercession of the saints, and the practice of charity "which covers a multitude of sins."32
<G-vec01009-002-s149><cite.nennen><de> Neben der durchgreifenden Läuterung, die durch die Taufe oder das Martyrium bewirkt wird, nennen sie als Mittel, um Vergebung der Sünden zu erlangen, die Bemühungen, sich mit seinem Nächsten zu versöhnen, die Tränen der Buße, die Sorge um das Heil des Nächsten‘, die Fürbitte der Heiligen und die tätige Nächstenliebe - „denn die Liebe deckt viele Sünden zu" (1 Petr 4, 8).
<G-vec01009-002-s150><cite.nennen><en> The members of parliament cite the financial industry as an example.
<G-vec01009-002-s150><cite.nennen><de> Als Vorbild nennen die Parlamentarier die Finanzbranche.
<G-vec01009-002-s151><cite.nennen><en> Over 81% cite this as their main pastime – directly followed by cooking or barbecuing on the campsite (76%).
<G-vec01009-002-s151><cite.nennen><de> Mehr als 81 % nennen dies als Haupt-Zeitvertreib – direkt gefolgt vom Kochen oder Grillen am Stellplatz (76 %).
<G-vec01009-002-s152><cite.nennen><en> In their study, the goetzpartners experts cite the success factors for successful cross-channel management.
<G-vec01009-002-s152><cite.nennen><de> Die goetzpartners-Experten nennen in ihrer Studie die Erfolgsfaktoren für ein gelungenes Cross-Channel-Management.
<G-vec01009-002-s153><cite.nennen><en> He added that, however, 82% of Brazilians fail to cite a research institution of the country.
<G-vec01009-002-s153><cite.nennen><de> Er fügte hinzu, dass jedoch 82% der Brasilianer nicht eine Forschungseinrichtung des Landes nennen können.
<G-vec01009-002-s154><cite.nennen><en> Other sources cite circus performers as models for the cape-and-spandex look.
<G-vec01009-002-s154><cite.nennen><de> Andere Quellen nennen Zirkus-Performer als Vorlage für den Cape-und-Spandex-Look.
<G-vec01009-002-s155><cite.nennen><en> Location The literary sources that mention the Columnae rostratae of Augustus only cite the Forum as their location.
<G-vec01009-002-s155><cite.nennen><de> Die literarischen Quellen, die uns von den Columnae rostratae des Augustus berichten, nennen als Standort lediglich das Forum.
<G-vec01009-002-s156><cite.nennen><en> 41 percent cite the sending of messages as the most important activity and 35 percent the checking of e-mails and their answering.
<G-vec01009-002-s156><cite.nennen><de> 41 Prozent nennen das Versenden von Botschaften als wichtigste Aktivität und 35 Prozent das Checken von E-Mails und deren Beantwortung.
<G-vec01009-002-s157><cite.nennen><en> And we also pushed forward the digital transformation of ALTANA, to cite just a few examples.
<G-vec01009-002-s157><cite.nennen><de> Und wir haben die digitale Transformation von ALTANA deutlich vorangetrieben, um nur einige Beispiele zu nennen.
<G-vec01009-002-s158><cite.nennen><en> In medicine and archeology, to cite two examples, a high degree of trust is given to these technologies, above all, I believe, because the processes of image acquisition, interpretation and distribution are closer together and apparently subject to better social control.
<G-vec01009-002-s158><cite.nennen><de> In der Medizin oder der Archäologie, um zwei Beispiele zu nennen, vertraut man diesen Techniken in einem hohen Ausmaß, vor allem aber auch, denke ich, da die Prozesse der Bildgewinnung, Interpretation und Distribution näher beieinander liegen und offensichtlich einer besseren gesellschaftlichenKontrolle unterliegen.
<G-vec01009-002-s159><cite.nennen><en> Those behind it cite costs of maintaining the tomb and the mummified body, the Orthodox traditions, and necessity to “bury the Communist past" of the county.
<G-vec01009-002-s159><cite.nennen><de> Diejenigen, die hinter dieser Idee stehen, nennen zumeist die Kosten für die Erhaltung des Mausoleums und des mumifizierten Körpers, christlich-orthodoxe Traditionen und die Notwendigkeit, "die kommunistische Vergangenheit des Landes zu begraben", als Argumente und Rechtfertigungsgründe.
<G-vec01009-002-s160><cite.nennen><en> In addition, 50 percent of respondents cite human error as contributing significantly to the cause of unplanned downtime in the data center.
<G-vec01009-002-s160><cite.nennen><de> 50 Prozent der Teilnehmer nennen beispielsweise menschliche Fehler als wesentliche Ursache für ungeplante Ausfallzeiten im Rechenzentrum.
<G-vec01009-002-s161><cite.nennen><en> Aberle is already testing another digital tool with its Service-App that uses augmented reality to provide an inside view of a system, illuminate potential defects or cite part numbers for repair work, among other things.
<G-vec01009-002-s161><cite.nennen><de> Ein weiteres digitales Tool erprobt Aberle bereits mit seiner Service-App: Durch den Einsatz von Augmented Reality erlaubt die App unter anderem den Blick ins Innere einer Anlage, erläutert potenzielle Fehlerbilder oder nennt Teilenummern für Reparaturarbeiten.
<G-vec01009-002-s162><cite.nennen><en> While network pros cite many of the same concerns as their employers, the way they spend their time shows greater focus on reactive issues, rather than proactive efforts.
<G-vec01009-002-s162><cite.nennen><de> Während Netzwerk-Profis viele der gleichen Bedenken wie ihre Arbeitgeber nennen, zeigt die Art und Weise, wie sie ihre Zeit verbringen, eine größere Konzentration auf reaktive Probleme, statt auf proaktive Bemühungen.
<G-vec01009-002-s137><cite.verweisen><en> The boards frequently cite R. 42(1)(c) EPC as the basis for the problem and solution approach.
<G-vec01009-002-s137><cite.verweisen><de> Als Grundlage für den Aufgabe-Lösungs-Ansatz wird von den Beschwerdekammern häufig auf R. 27 (1) c) EPÜ 1973 (jetzt R. 42 (1) c) EPÜ) verwiesen.
<G-vec01009-002-s174><cite.verweisen><en> Some believe that it is too late, others cite lack of time and energy.
<G-vec01009-002-s174><cite.verweisen><de> Einige glauben, dass es zu spät ist, andere verweisen auf das fehlen von Zeit und Mühe.
<G-vec01009-002-s175><cite.verweisen><en> The authors cite the provisions of WIPO Standards on protection against unfair competition; foreign litigation and dispute resolution practice of the Antimonopoly Committee of Ukraine; practical comments to the Laws of Ukraine On Protection from Unfair Competition and On Advertising.
<G-vec01009-002-s175><cite.verweisen><de> Die Autoren verweisen auf WIPO Standardbestimmungen zum Schutz gegen unlauteren Wettbewerb, ausländische Gerichtspraxis und Praxis der Streitbeilegung des Antimonopolkomitees der Ukraine, geben praktische Kommentare zum Wettbewerbs- und Werbungsgesetz der Ukraine.
<G-vec01009-002-s176><cite.verweisen><en> It’s important to remember that you must cite every type of source in exactly the same way.
<G-vec01009-002-s176><cite.verweisen><de> Es ist gut zu wissen, dass auf jede Art von Quelle gleich verwiesen werden muss.
<G-vec01009-002-s106><cite.zitieren><en> It offers the possibility to cite (parts of) source code specifically and permanently.
<G-vec01009-002-s106><cite.zitieren><de> Somit besteht die Möglichkeit einzelne Teile des Quellcodes gezielt und dauerhaft zu zitieren.
<G-vec01009-002-s131><cite.zitieren><en> Scientifically/technically speaking, if you have published text before, you also need to cite your own work properly in a new publication.
<G-vec01009-002-s131><cite.zitieren><de> Wissenschaftlich / technisch gesprochen, muss ein veröffentlichter Text, inklusive eigene Texte richtig zitiert werden.
<G-vec01009-002-s173><cite.zitieren><en> If the client wishes to cite said results in whole or in part then they must make all such citations recognisable as such and name GO as the author.
<G-vec01009-002-s173><cite.zitieren><de> Will der Auftraggeber ganz oder teilweise aus dem Untersuchungsbericht zitieren, so muss er die Zitate als solche kenntlich machen und dabei GO als Verfasser des Untersuchungsberichts benennen.
<G-vec01009-002-s178><cite.zitieren><en> In all of the examples mentioned above, there's no possibility to export the information you will need to cite later on.
<G-vec01009-002-s178><cite.zitieren><de> In den oben genannten Fällen gibt es auf der Webseite keine Möglichkeit, die für das spätere Zitieren nötigen Daten zu exportieren.
<G-vec01009-002-s190><cite.zitieren><en> Cite your own experience.
<G-vec01009-002-s190><cite.zitieren><de> Zitiere deine eigene Erfahrung.
<G-vec01009-002-s191><cite.zitieren><en> You’ll notice that in my infographics, I cite SEO blogs and articles written by marketing writers quite often:
<G-vec01009-002-s191><cite.zitieren><de> Du wirst merken, dass ich recht oft SEO Blogs und Artikel, die von Marketing Autoren verfasst wurden, in meinen Infografiken zitiere.
<G-vec01009-002-s192><cite.zitieren><en> Cite the source for the figure in the Reference List.
<G-vec01009-002-s192><cite.zitieren><de> Zitiere die Quelle für die Darstellung im Literaturverzeichnis.
<G-vec01009-002-s193><cite.zitieren><en> Cite data included in the case study, such as increased marketing spending, purchasing of new property, changed revenue streams, etc.
<G-vec01009-002-s193><cite.zitieren><de> Zitiere die Daten, die in der Fallstudie inbegriffen sind, wie etwa höhere Marketingausgaben, der Kauf neuer Sachanlagen, neue Einkommensquellen, etc.
<G-vec01009-002-s194><cite.zitieren><en> Even this conference call, I cite is a circuit of energy formed in this hour by you each one.
<G-vec01009-002-s194><cite.zitieren><de> Auch diese Telefonkonferenz, ich zitiere, ist ein Kreislauf von Energie, in dieser Stunde durch jeden Einzelnen von euch hervorgebracht.
<G-vec01009-002-s195><cite.zitieren><en> One of the major complaints that organic food consumers cite when choosing organic over non-organic is the presence of pesticides.
<G-vec01009-002-s195><cite.zitieren><de> Eine der Hauptbeschwerden, die organische Nahrungsmittelverbraucher zitieren, wenn sie Bio oder Nicht-Bio wählen, ist die Präsenz von Pestiziden.
<G-vec01009-002-s196><cite.zitieren><en> Many who cite his apologetic approach have a comically wooden understanding of how he approached people to win them to faith.
<G-vec01009-002-s196><cite.zitieren><de> Viele, die seine Apologetik zitieren, haben eine witzige hölzerne Verstellung, wie er Menschen begegnete, um sie zum Glauben zu führen.
<G-vec01009-002-s197><cite.zitieren><en> We should encourage authors of articles and courses to seek peer review, both through existing formal scholarly mechanisms, and through the informal mechanism of asking respected names in the field for permission to cite their endorsement in the article or course.
<G-vec01009-002-s197><cite.zitieren><de> Wir sollten die Autoren von Artikeln und Kursen zu gegenseitigen Begutachtungen ermutigen, sowohl durch existierende wissenschaftliche Mechanismen als auch auf dem informellen Weg, anerkannte Köpfe im entsprechenden Bereich nach der Erlaubnis zu fragen, ihre Bemerkungen im Artikel oder Kurs zu zitieren.
<G-vec01009-002-s198><cite.zitieren><en> Please cite your answers with Laws that are in full force and effect.
<G-vec01009-002-s198><cite.zitieren><de> Bitte zitieren Sie die Gesetze die in vollen Kraft sind.
<G-vec01009-002-s199><cite.zitieren><en> With LaTeX's BibTeX program, you can cite directly from literature databases.
<G-vec01009-002-s199><cite.zitieren><de> Mit LaTeX' BibTeX-Format können Sie direkt aus Literaturverzeichnis-Datenbanken zitieren.
<G-vec01009-002-s200><cite.zitieren><en> Those of us who use our superior education to cite Klee’s dictum that “art does not reproduce the visible, but makes visible” should beware of smugness.
<G-vec01009-002-s200><cite.zitieren><de> Diejenigen von uns, die unsere überlegene Bildung dazu heranziehen, Klees Ausspruch „Kunst gibt nicht das Sichtbare wieder, sondern macht sichtbar“ zu zitieren, sollten sich vor ihrer Selbstgefälligkeit in acht nehmen.
<G-vec01009-002-s201><cite.zitieren><en> We will cite several folk recipes aimed at alleviating inflammation and improving immunity.
<G-vec01009-002-s201><cite.zitieren><de> Wir werden einige Volksrezepte zitieren, die darauf abzielen, Entzündungen zu lindern und die Immunität zu verbessern.
<G-vec01009-002-s202><cite.zitieren><en> Some people may cite Bible verse using abbreviations and Roman numerals.
<G-vec01009-002-s202><cite.zitieren><de> Manche Leute zitieren Bibelverse, indem sie Abkürzungen und römische Ziffern verwenden.
<G-vec01009-002-s203><cite.zitieren><en> You cite a thesis of the bureau.
<G-vec01009-002-s203><cite.zitieren><de> Sie zitieren eine These des Büros.
<G-vec01009-002-s204><cite.zitieren><en> They cite today's popular culture as well as historical pictures and Christian iconography.
<G-vec01009-002-s204><cite.zitieren><de> Sie zitieren gleichermaßen die gegenwärtige Populärkultur, wie historische Bilder und christliche Ikonographie.
<G-vec01009-002-s205><cite.zitieren><en> After repeatedly emphasizing in my second reply that his assertions were almost wholly undocumented, I figured he would feel obligated to cite scholarly sources to justify his assertions.
<G-vec01009-002-s205><cite.zitieren><de> Nachdem ich wiederholt betont hatte in meiner zweiten Erwiderung, dass seine Erklärungen fast gänzlich undokumentiert waren, meinte ich, er würde sich verpflichtet fühlen, wissenschaftliche Quellen zu zitieren, um seine Erklärungen zu rechtfertigen.
<G-vec01009-002-s206><cite.zitieren><en> To cite a reference in a TeX document, you insert the BibTeX key for the reference in the correct place in the document.
<G-vec01009-002-s206><cite.zitieren><de> Wenn Sie ein TeX-Dokument erstellen und eine Quelle zitieren, fügen Sie in der TeX-Datei an der betreffenden Stelle den zugehörigen BibTeX-Key ein.
<G-vec01009-002-s207><cite.zitieren><en> Officials will urge calm and cite statistics to prove that these natural calamities are rare but normal.
<G-vec01009-002-s207><cite.zitieren><de> Regierungssprecher werden zur Ruhe aufrufen und Statistiken zitieren, um zu beweisen, dass solche Naturkatastrophen selten und normal sind.
<G-vec01009-002-s208><cite.zitieren><en> For this case I would like to cite the brandeins-author Peter Lau, who laid down 8 rules for a revolt in 2001.
<G-vec01009-002-s208><cite.zitieren><de> Fuer diesen Fall moechte ich abschließend den brandeins-Autoren Peter Lau zitieren, der 2001 acht Regeln für eine Revolte aufstellte.
<G-vec01009-002-s209><cite.zitieren><en> It is evident that the presence of URKUND within the teaching environment makes the vast majority of students, who would never deliberately take any prohibited shortcut, more carefully check their references and cite and paraphrase correctly.
<G-vec01009-002-s209><cite.zitieren><de> Es ist offensichtlich, dass die Anwesenheit von URKUND in der Lehrumgebung die überwiegende Mehrheit der Schüler, die niemals absichtlich eine verbotene Abkürzung nehmen würden, ihre Referenzen sorgfältiger überprüfen und korrekt zitieren und paraphrasieren lässt.
<G-vec01009-002-s210><cite.zitieren><en> You should write a piece of text strictly in your own words and then cite your sources.
<G-vec01009-002-s210><cite.zitieren><de> Du solltest unbedingt ein Stück Text selbst in eigenen Worten schreiben und deine Quellen zitieren.
<G-vec01009-002-s211><cite.zitieren><en> This is a little different as there isn’t one solid value proposition, but I will cite David’s piece throughout this article when it comes to the Submariner.
<G-vec01009-002-s211><cite.zitieren><de> Dies ist ein wenig anders, da es kein solides Wertversprechen gibt, aber ich werde Davids Artikel in diesem Artikel zitieren, wenn es um den Submariner geht.
<G-vec01009-002-s212><cite.zitieren><en> The monotonous clicking of slide projectors and the viewer´s perception of being "caught," in per-son, in the empty grid of the steel skeleton perhaps can tempt them to cite Rilke's "Panther": "and behind the bars, no world."
<G-vec01009-002-s212><cite.zitieren><de> Das monotone Klicken der Dia-Projektoren und das persönliche "Gefangensein" des Betrachters im leeren Raster des Stahlskeletts können unter Umständen dazu verführen, Rilkes "Panther" zu zitieren: "und hinter tausend Stäben keine Welt".
<G-vec01009-002-s213><cite.zitieren><en> We cite the retreat of the tropical forest (more than 100 hectares per year in Zambia), the advance of the desert (000 km in thirty years for the Sahel countries), rampant urbanization and demography whose growth rates are thrilling.
<G-vec01009-002-s213><cite.zitieren><de> Wir zitieren den Rückzug des Tropenwaldes (mehr als 100 Hektar pro Jahr in Sambia), den Vormarsch der Wüste (000 km in dreißig Jahren für die Sahel-Länder), die galoppierende Urbanisierung und Demografie, deren Wachstumsraten sind aufregend.
<G-vec01009-002-s214><cite.zitieren><en> Your teacher should tell you how should cite your sources or what guidelines you should be using.
<G-vec01009-002-s214><cite.zitieren><de> Dein Lehrer sollte dir sagen, wie du zitieren oder welchen Richtlinien du folgen sollst.
<G-vec01009-002-s216><cite.zitieren><en> "You do not need to ask my permission to cite something that I have said or written.
<G-vec01009-002-s216><cite.zitieren><de> "Du brauchst mich nicht um Erlaubnis zu bitten, wenn du etwas zitieren möchtest, was ich geschrieben oder gesagt habe.
<G-vec01009-002-s217><cite.zitieren><en> Proposed citation Please cite the MoLeaP database as follows: Judith Seipold, The London Mobile Learning Group LMLG (Year): MoLeaP - The mobile learning project database.
<G-vec01009-002-s217><cite.zitieren><de> Bitte zitieren Sie die MoLeaP-Datenbank wie folgt: Judith Seipold, The London Mobile Learning Group (LMLG) (Jahr): MoLeaP – Die mobile learning Projektdatenbank.
<G-vec01009-002-s218><cite.zitieren><en> Cite island and bridge Neuf view.
<G-vec01009-002-s218><cite.zitieren><de> Zitieren Sie Insel und Brücke Neuf-Ansicht.
<G-vec01009-002-s219><cite.zitieren><en> Respect copyright laws, and reference or cite sources appropriately.
<G-vec01009-002-s219><cite.zitieren><de> Achten Sie auf Copyright-Gesetze und referenzieren oder zitieren Sie Quellen angemessen.
<G-vec01009-002-s220><cite.zitieren><en> Cite your source.
<G-vec01009-002-s220><cite.zitieren><de> Zitieren Sie Ihre Quelle.
<G-vec01009-002-s221><cite.zitieren><en> For every page, in more menu, there is a link to "Cite this page".
<G-vec01009-002-s221><cite.zitieren><de> Für jede Seite, in mehr Menü, gibt es einen Link zu "Zitieren Sie diese Seite".
<G-vec01009-002-s222><cite.zitieren><en> Persistent, unique identifiers make it easy to cite data in scientific literature.
<G-vec01009-002-s222><cite.zitieren><de> Durch persistente, eindeutige Identifikatoren können Daten in wissenschaftlicher Literatur leicht zitiert werden.
<G-vec01009-002-s227><cite.zitieren><en> In this regard, we follow the lead of the Apartheid Archive Project, which we shall cite several times below, in its determination to reverse the effects of the dominant power relations in the old archive so as to create a viable basis for the achievement of a just society.
<G-vec01009-002-s227><cite.zitieren><de> Mit Blick auf diesen Kontext folgen wir den Direktiven des Apartheid Archive Project, das wir im Folgenden des öfteren zitieren werden und das sich zum Ziel gesetzt hat, die Auswirkungen der dominanten Machtverhältnisse des alten Archivs umzukehren, um so eine belastbare Basis für eine gerechte Gesellschaft zu schaffen.
<G-vec01029-002-s117><cite.anführen><en> Engineers who were involved with the program cite the detailed understanding they had of each spacecraft component–down to the wire and solder point–as contributing heavily to their success in managing the crisis.
<G-vec01029-002-s117><cite.anführen><de> Ingenieure, die an dem Programm beteiligt waren, führen ihr detailliertes Verständnis sämtlicher Bestandteile der Raumfähre – bis hin zum letzten Draht und Lötpunkt – als einen der Hauptgründe dafür an, dass sie die Krise erfolgreich bewältigen konnten.
<G-vec01029-002-s225><cite.aufzählen><en> 56 percent of marketers cite delivery and transportation companies and supply chain/shipping departments (47 percent) among the top three stakeholders to deliver the best customer experience.
<G-vec01029-002-s225><cite.aufzählen><de> 56 Prozent der Marketingverantwortlichen zählen Liefer- und Transportunternehmen sowie Lieferketten-/Versandabteilungen (47 Prozent) zu den drei wichtigsten Gruppen, die für optimale Kundenerfahrungen sorgen können.
<G-vec01029-002-s226><cite.aufzählen><en> To defend this claim they will cite a list of criteria that define a ‘good scientific theory’.
<G-vec01029-002-s226><cite.aufzählen><de> Um diese Behauptung zu verteidigen, zählen sie typischerweise eine Liste von Kriterien auf, die eine „gute wissenschaftliche Theorie“ ausmachen.
<G-vec01029-002-s215><cite.zitieren><en> In fact, some of Obama’s biographies cite his pot use.
<G-vec01029-002-s215><cite.zitieren><de> Tatsächlich zitieren einige von Obamas Biographien seinen Marihuanakonsum.
