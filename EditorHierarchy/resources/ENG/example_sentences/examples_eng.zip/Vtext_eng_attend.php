<G-vec00042-001-s057><attend.teilnehmen><en> Anyone should attend to the club life as actively and regularly as possible, and engage in agreed labor.
<G-vec00042-001-s057><attend.teilnehmen><de> Jeder soll möglichst aktiv und regelmäßig am Clubleben teilnehmen und sich an der Vereinsarbeit beteiligen.
<G-vec00042-001-s058><attend.teilnehmen><en> I first attended it on Friday and after that I was compelled to attend the rest of it as it was so good.
<G-vec00042-001-s058><attend.teilnehmen><de> Ich habe zuerst am Freitag teilgenommen und danach musste ich am Rest auch teilnehmen, denn es war so gut.
<G-vec00042-001-s059><attend.teilnehmen><en> A Taizé each week there will be days of preparation for those who wish to attend this meeting in Kigali.
<G-vec00042-001-s059><attend.teilnehmen><de> In Taizé wird es in jeder Woche Vorbereitungstage für alle geben, die am Treffen in Kigali teilnehmen möchten.
<G-vec00042-001-s060><attend.teilnehmen><en> "Please use the text box below (""Your Message""), fill in the workshop you would like to attend and give a short description of the enterprise development work you are currently involved with and the main reasons you would like to attend the course. Also please fill in your contact details in the table under the text box."
<G-vec00042-001-s060><attend.teilnehmen><de> "Bitte geben Sie in der Textbox (""Ihre Nachricht"") an, für welchen Workshop Sie sich interessieren, tragen Sie Ihre Kontaktdaten ein und hinterlassen Sie uns eine Kurzbeschreibung der Unternehmensentwicklungsarbeit, mit der Sie aktuell beschäftigt sind sowie die Hauptgründe, warum Sie am Training Workshop teilnehmen möchten."
<G-vec00042-001-s061><attend.teilnehmen><en> Students of other religious denominations or students without any religious denomination may also attend Religious Instruction classes without receiving grades.
<G-vec00042-001-s061><attend.teilnehmen><de> Schüler anderer Konfessionen oder Schüler ohne Konfession können ohne Benotung am Religionsunterricht ihrer Wahl teilnehmen.
<G-vec00042-001-s062><attend.teilnehmen><en> OSCARTIELLE and INCOLD will attend CIBUS 2014 Read more...
<G-vec00042-001-s062><attend.teilnehmen><de> OSCARTIELLE und INCOLD werden am CIBUS 2014 teilnehmen Lesen Sie alles...
<G-vec00042-001-s063><attend.teilnehmen><en> "Webinar You want to attend the webinar ""secure digital Banking""."
<G-vec00042-001-s063><attend.teilnehmen><de> "Webinar Sie möchten am Webinar ""sicheres digitales Banking"" teilnehmen."
<G-vec00042-001-s064><attend.teilnehmen><en> As on each occasion, the Hohenberg brothers are obliged to ask for a special permission to enter Czechoslovakia, so as to be able to attend his funeral.
<G-vec00042-001-s064><attend.teilnehmen><de> Wie Jedes mal, wenn die Brüder Hohenberg sich in die Tschechoslowakei begeben wollen, müssen sie eine spezielle Genehmigung beantragen -so auch dieses Mal, um am Begräbnis ihres Onkels und ehemaligen Vormundes teilnehmen zu können.
<G-vec00042-001-s065><attend.teilnehmen><en> This type of course is recommended for people who can only attend classes for 2-4 weeks.
<G-vec00042-001-s065><attend.teilnehmen><de> Dieser Kurstyp wird für Personen empfohlen, die nur 2-4 Wochen am Unterricht teilnehmen können.
<G-vec00042-001-s066><attend.teilnehmen><en> Parents can decide if their child should attend religious instruction at school.
<G-vec00042-001-s066><attend.teilnehmen><de> Eltern können entscheiden, ob ihr Kind am Religionsunterricht in der Schule teilnehmen soll.
<G-vec00042-001-s067><attend.teilnehmen><en> They can attend the competition through e-mail/SMS/internet.
<G-vec00042-001-s067><attend.teilnehmen><de> Sie können am Wettbewerb per E-Mail / SMS / Internet teilnehmen.
<G-vec00042-001-s068><attend.teilnehmen><en> Working while studying is coordinated for the employed people and active sportsmen who can't attend classes due to their obligations.
<G-vec00042-001-s068><attend.teilnehmen><de> Das Arbeiten während des Studiums wird für die Beschäftigten und aktiven Sportler koordiniert, die aufgrund ihrer Verpflichtungen nicht am Unterricht teilnehmen können.
<G-vec00042-001-s069><attend.teilnehmen><en> The President of the European Commission, Jean-Claude Juncker, will attend the Three Seas Initiative Summit for the first time.
<G-vec00042-001-s069><attend.teilnehmen><de> Der Präsident der Europäischen Kommission Jean-Claude Juncker wird zum ersten Mal am der Drei-Meere-Initiative teilnehmen.
<G-vec00042-001-s070><attend.teilnehmen><en> He said he would attend the European Union Summit on Thursday, where he would seek legal and political assurances to overcome the concerns raised by the members of the opposition to the content of the Convention regarding the Brexit conditionality agreement.
<G-vec00042-001-s070><attend.teilnehmen><de> Er sagte, er werde am Gipfeltreffen der Europäischen Union am Donnerstag teilnehmen, wo er rechtliche und politische Zusicherungen einholen würde, um die Bedenken der Mitglieder der Opposition gegen den Inhalt des Konvents hinsichtlich des Brexit-Konditionalitätsabkommens zu überwinden.
<G-vec00042-001-s071><attend.teilnehmen><en> Some sent e-mails expressing appreciation and a former SA diplomat in Washington DC decided to attend the final day of training in Cape Town.
<G-vec00042-001-s071><attend.teilnehmen><de> Einige schickten E-Mails, in denen sie ihre Wertschätzung ausdrückten und eine ehemaliger südafrikanischer Diplomat in Washington D.C. beschloss, am letzten Tag der Fortbildung in Kapstadt teilzunehmen.
<G-vec00042-001-s072><attend.teilnehmen><en> A different perspective The Asian guests travelled a long way to attend the meeting with their European colleagues in Luxembourg.
<G-vec00042-001-s072><attend.teilnehmen><de> Die Gäste aus Asien sind weit gereist, um am Treffen mit ihren europäischen Kolleginnen und Kollegen in Luxemburg teilzunehmen.
<G-vec00042-001-s073><attend.teilnehmen><en> The main goal is to attend the Alumni and Stadium Series Game.
<G-vec00042-001-s073><attend.teilnehmen><de> Das Hauptziel ist es, am Alumni Spiel und am Stadium Series Spiel teilzunehmen.
<G-vec00042-001-s074><attend.teilnehmen><en> As chairperson, I particularly work to ensure frank discourse and transparency in all decision making processes and warmly invite all members of TU Graz to attend the public part of our senate meetings.
<G-vec00042-001-s074><attend.teilnehmen><de> Als Vorsitzender bemühe ich mich besonders um einen freimütigen Diskurs und Transparenz in allen Entscheidungsprozessen und lade alle Angehörigen der TU Graz herzlich dazu ein, am öffentlichen Teil unserer Senatssitzungen teilzunehmen.
<G-vec00042-001-s075><attend.teilnehmen><en> AS THE camp at Pella was being established, Jesus, taking with him Nathaniel and Thomas, secretly went up to Jerusalem to attend the feast of the dedication.
<G-vec00042-001-s075><attend.teilnehmen><de> WÄHREND das Lager in Pella eingerichtet wurde, nahm Jesus Nathanael und Thomas mit sich und begab sich heimlich nach Jerusalem, um am Fest der Tempelweihe teilzunehmen.
<G-vec00042-001-s076><attend.teilnehmen><en> Additionally, the winner will receive an invitation to attend RELEX Supply Chain seminar 2014 in Helsinki to present the victorious work there.
<G-vec00042-001-s076><attend.teilnehmen><de> Zusätzlich erhält der Gewinner eine Einladung, um am RELEX Supply Chain Seminar 2014 in Helsinki teilzunehmen, und dort die siegreiche Arbeit zu präsentieren.
<G-vec00042-001-s077><attend.teilnehmen><en> Here I want to share my experience of stepping out to attend the group Fa study.
<G-vec00042-001-s077><attend.teilnehmen><de> Heute möchte ich über meine Erfahrungen beim Heraustreten berichten, um am Fa-Lernen in der Gruppe teilzunehmen.
<G-vec00042-001-s078><attend.teilnehmen><en> In April 1942 he traveled to Ubon Ratchathani to attend the funeral of his teacher, Ācariya Sao.
<G-vec00042-001-s078><attend.teilnehmen><de> Im April 1942 wanderte er nach Ubon Ratchathani, um am Begräbnis seines Lehrers Ācariya Sao teilzunehmen.
<G-vec00042-001-s079><attend.teilnehmen><en> Such was the reach for DFW materials by athletes for their foundations and humanitarian activities, that an invitation was received to attend the NBA (National Basketball Association) All-Star Game at the Staples Center in Los Angeles, California.
<G-vec00042-001-s079><attend.teilnehmen><de> Die Nachfrage der Sportler für ihre Stiftungen und humanitären Aktivitäten nach DFW-Materialien war so groß, dass eine Einladung erhalten wurde, am NBA (National Basketball Association) All-Star Spiel im Staples Center in Los Angeles, Kalifornien, teilzunehmen.
<G-vec00042-001-s080><attend.teilnehmen><en> Children in schools had been forced to attend Islamic religious education classes.
<G-vec00042-001-s080><attend.teilnehmen><de> Die Kinder in den Schulen wurden genötigt, am islamischen Religionsunterricht teilzunehmen.
<G-vec00042-001-s100><attend.besuchen><en> "If required, Credit Suisse will be happy to offer a personal consultation, and you can also attend the following course: ""Founding a company"" (dates and registration via Startups.ch)."
<G-vec00042-001-s100><attend.besuchen><de> Bei Bedarf bietet Ihnen die Credit Suisse gerne ein Beratungsgespräch an, zusätzlich können Sie den folgenden Kurs besuchen: «Clever eine Firma gründen» (Terminvereinbarung über Startups.ch).
<G-vec00042-001-s101><attend.besuchen><en> Visiting Students are former students of our school who would like to visit the German International School Washington D.C. for up to 10 days and attend classes during that time.
<G-vec00042-001-s101><attend.besuchen><de> Aufnahme von Schülerinnen und Schülern als Besucher Besucherinnen und Besucher sind ehemalige Schülerinnen und Schüler unserer Schule, die bis zu 10 Tagen an der GISW den Unterricht besuchen.
<G-vec00042-001-s102><attend.besuchen><en> Therefore Fox collected the strength and began to attend rehabilitation courses.
<G-vec00042-001-s102><attend.besuchen><de> Deshalb hat Foks die Kräfte zusammengenommen und fing an, die Kurse der Rehabilitierung zu besuchen.
<G-vec00042-001-s103><attend.besuchen><en> "People come from all the world over to attend private and public masked balls and masked people invade all the numerous ""campi"" where music and dancing continues until the day after."
<G-vec00042-001-s103><attend.besuchen><de> "Die Leute kommen aus der ganzen Welt an private und öffentliche Maskenbälle besuchen und maskierte Personen überfallen all die vielen ""Campi"", wo Musik und Tanz geht weiter, bis zum nächsten Tag."
<G-vec00042-001-s104><attend.besuchen><en> The speaker himself can then manage which days he will be on site and which workshops he would like to attend.
<G-vec00042-001-s104><attend.besuchen><de> Der Referent kann dann selbst verwalten, an welchen Tagen er vor Ort sein wird und welche Workshops er besuchen möchte.
<G-vec00042-001-s105><attend.besuchen><en> After the tour you have the option to attend anArtist Talkwith Miet Warlop at 18.15 as well as the show Mystery Magnetat 19.30 at TQW Halle G.
<G-vec00042-001-s105><attend.besuchen><de> Im Anschluss an die Führung besteht um 18.15 Uhr die Möglichkeit, einenArtist Talk von Miet Warlop sowie um 19.30 Uhr die Aufführung von Mystery Magnet in der TQW Halle G zu besuchen.
<G-vec00042-001-s106><attend.besuchen><en> "Famous Russian ballerina Anastasia declined an invitation to attend the festival, ""The big difference"" in Odessa .."
<G-vec00042-001-s106><attend.besuchen><de> "Berühmte russische Ballerina Anastasia ging eine Einladung an das Festival, ""Der große Unterschied"" in Odessa besuchen .."
<G-vec00042-001-s107><attend.besuchen><en> In 2013, about 60 percent of Tunisians polled said that they no longer attend mosques but instead pray at home.
<G-vec00042-001-s107><attend.besuchen><de> 2013 gaben etwa 60 Prozent der befragten Tunesier an, keine Moschee mehr zu besuchen, sondern lieber zu Hause zu beten.
<G-vec00042-001-s108><attend.besuchen><en> Thanks to its proximity to all faculties, the Kleeburger Weg residence is good for students that attend lectures at different locations every day.
<G-vec00042-001-s108><attend.besuchen><de> Durch die Nähe zu allen Fachbereichen eignet sich die Wohnanlage Kleeburger Weg gut für Studierende, die täglich an unterschiedlichen Standorten Vorlesungen besuchen.
<G-vec00042-001-s109><attend.besuchen><en> Please indicate on the online form whether you would like to attend the press or preview days in Athens, Kassel, or both cities.
<G-vec00042-001-s109><attend.besuchen><de> Bitte geben Sie auf dem Onlineformular an, ob Sie die Pressekonferenz und die Preview Days in Athen, in Kassel, oder in beiden Städten besuchen wollen.
<G-vec00042-001-s129><attend.teilnehmen><en> In the end, the young journalists will attend the international media conference M100 Sanssouci Colloquium in Potsdam, uniting Europe's top editors, commentators and media owners alongside key public figures to assess the role and impact of the media in international affairs and to promote democracy and freedom of speech.
<G-vec00042-001-s129><attend.teilnehmen><de> Am Ende werden die jungen Journalisten an der internationalen Medienkonferenz M100 Sanssouci Colloquium in Potsdam teilnehmen, die Europas tonangebende Redakteure, Kommentatoren und Medienbesitzer sowie öffentliche Schlüsselfiguren zusammenbringt, um die Rolle und den Einfluss der Medien in internationalen Angelegenheiten zu untersuchen und sich für Demokratie, Meinungs- und Pressefreiheit einzusetzen.
<G-vec00042-001-s130><attend.teilnehmen><en> Several members of the WFC Disarmament Working Group will attend the five-yearly Non-Proliferation Treaty Review Conference in New York.
<G-vec00042-001-s130><attend.teilnehmen><de> Mehrere Mitglieder der WFC-Arbeitsgruppe für Demilitarisierung werden an der Konferenz zur Revision des Atomwaffensperrvertrages in New York teilnehmen.
<G-vec00042-001-s131><attend.teilnehmen><en> But perhaps one of my IF Blog readers can attend the unique agile.ruhr Camp.
<G-vec00042-001-s131><attend.teilnehmen><de> Aber vielleicht kann ja der eine oder andere IF-Blog-Leser an meiner Stelle an diesem einzigartigen agile.ruhr Camp teilnehmen.
<G-vec00042-001-s132><attend.teilnehmen><en> The Secretary General of NATO and a senior UN peacekeeping official will attend.
<G-vec00042-001-s132><attend.teilnehmen><de> Ebenso an dem Treffen teilnehmen werden der Generalsekretär der NATO und ein Vertreter der UNO-Friedenstruppe.
<G-vec00042-001-s133><attend.teilnehmen><en> "You can attend their public rehearsals at various venues, or see them at the ""Petit Art Petit"" festival and various street events and free initiatives in and around the city."
<G-vec00042-001-s133><attend.teilnehmen><de> Hier können Sie vor Ort an öffentlichen Proben, am Festival Petit Art Petit sowie an zahlreichen anderen Vorführungen in den Straßen des Zentrums, an kostenlosen künstlerischen Angeboten in der Stadt und darüber hinaus teilnehmen...
<G-vec00042-001-s134><attend.teilnehmen><en> Persons required to attend training courses: All your bodies (members of partnerships or of limited liability companies, members of boards of directors or of foundation boards or of association committees and all other management members with general powers) and for all your subordinated employees and auxiliaries taking part in matters governed by the MLA, including your MLA Officer.
<G-vec00042-001-s134><attend.teilnehmen><de> Personen, die an den Ausbildungs-kursen teilnehmen müssen: Alle Ihre Organe (Gesellschafter von Personengesellschaften oder von Gesellschaften mit beschränkter Haftung, Mitglieder von Verwaltungs- oder Stiftungsräten oder von Vereinsvorständen sowie alle weiteren Mitglieder der Direktion mit allgemeinen Befugnissen) sowie für alle Ihre untergebenen Angestellten und Hilfspersonen, die an GwG unterstellte Aufgaben wahrnehmen, unter Einschluss Ihres GwG-Beauftragten.
<G-vec00042-001-s135><attend.teilnehmen><en> On Wednesday, October 26, ICCJ President Dr. Deborah Weissman and the ICCJ General Secretary will attend a board meeting of our Israeli member organization, the Interreligious Coordinating Council Israel.
<G-vec00042-001-s135><attend.teilnehmen><de> Am Mittwoch, den 26.Oktober, werden die ICCJ Präsidentin Dr. Deborah Weissman und der ICCJ Generalsekretär an einer Vorstandssitzung unserer israelischen Mitgliedsorganisation The Interreligious Coordinating Council Israel teilnehmen.
<G-vec00042-001-s136><attend.teilnehmen><en> Shareholders who are unable to attend the Meeting in person will be able to listen to the conference call and concurrently view a live webcast presentation of the Meeting.
<G-vec00042-001-s136><attend.teilnehmen><de> Aktionäre, die nicht persönlich an der Jahreshauptversammlung teilnehmen können, können die Telefonkonferenz mithören und gleichzeitig einen Live-Webcast der Jahreshauptversammlung ansehen.
<G-vec00042-001-s137><attend.teilnehmen><en> The Debian project announced that its members and affiliates will attend four exhibitions and conferences that cover Free Software and GNU/Linux in Europe.
<G-vec00042-001-s137><attend.teilnehmen><de> Das Debian-Projekt kündigte an, dass seine Mitglieder und Beteiligten an vier Ausstellungen und Konferenzen in Europa teilnehmen werden, die Freie Software und GNU/Linux behandeln.
<G-vec00042-001-s138><attend.teilnehmen><en> When is justice?» There above, the so-called radicalism promises to itself that it will drive the new R-E-V-O-L-U-T-I-O-N (which in reality is quite old), programming activities that it will not attend (the assault on the Winter Palace can’t conflict with the holidays); and the families all alone, stiff with cold and rage.
<G-vec00042-001-s138><attend.teilnehmen><de> Und dort oben die angebliche Radikalitaet, wo sie sich die Fuehrung der neuen R-E-V-O-L-U-T-I-Ó-N versprechen (die in Wirklichkeit bereits sehr alt ist), das Programmieren von Aktivitaeten, an denen sie dann nicht teilnehmen (den Angriff auf den Winterpalast macht man nicht in der Urlaubszeit) und die Familienangehoerigen allein, zitternd vor Kaelte und Wut.
<G-vec00042-001-s139><attend.teilnehmen><en> Trainers may become inactive if they are not giving a training, not pay membership fees, do not wish to attend and vote at council meetings.
<G-vec00042-001-s139><attend.teilnehmen><de> Trainern ist es erlaubt, inaktiv zu werden, wenn sie keine Ausbildung geben, keine Mitgliedsbeiträge zahlen, an der Mitgliederversammlung und an Abstimmungen nicht teilnehmen wollen.
<G-vec00042-001-s140><attend.teilnehmen><en> If your employer is happy with your progress, you could ask if you could attend an auto mechanic training course at the expense of the company.
<G-vec00042-001-s140><attend.teilnehmen><de> Wenn dein Arbeitgeber mit deinen Fortschritten zufrieden ist, dann könntest du fragen, ob du auf Kosten der Firma an einem Automechanik-Kurs teilnehmen kannst.
<G-vec00042-001-s141><attend.teilnehmen><en> Generally anyone may attend a trade fair, an exhibition or a market.
<G-vec00042-001-s141><attend.teilnehmen><de> Grundsätzlich darf jeder an einer Messe, Ausstellung oder einem Markt teilnehmen.
<G-vec00042-001-s142><attend.teilnehmen><en> Mainly the reasons they provide to the bosses and employers include, my kid was sick, I was not well with a fake doctor’s note, my vehicle went out of order, and I had to attend the funeral ceremony of a relative who suddenly died and few more too.
<G-vec00042-001-s142><attend.teilnehmen><de> Vor allem die Gründe, die sie den Chefs und Arbeitgebern zur Verfügung stellen, sind, mein Kind war krank, mir ging es nicht gut mit einem falschen Arztschreiben, mein Fahrzeug ging außer Betrieb und ich musste an der Beerdigungszeremonie eines Verwandten teilnehmen, der plötzlich starb und wenige mehr.
<G-vec00042-001-s143><attend.teilnehmen><en> The Talum's Management Board, the directors of subsidiary companies and business units, heads of the services, members of the Works Council, members of the Employees Council and members of the Syndicate Conference Kidrievo, will attend this event.
<G-vec00042-001-s143><attend.teilnehmen><de> Der Vorstand von Talum, die Geschäftsführer der Tochtergesellschaften und Geschäftseinheiten, die Leiter der Dienststellen, die Mitglieder des Betriebsrats, die Mitglieder des Mitarbeiterrates und der Gewerkschaftskonferenz Kidričevo werden an dieser Veranstaltung teilnehmen.
<G-vec00042-001-s144><attend.teilnehmen><en> Alternatively, people interested in social nudity can attend clothes-free beaches and other types of ad-hoc nudist events.
<G-vec00042-001-s144><attend.teilnehmen><de> Menschen, die an geselliger Nacktheit interessiert sind, können wahlweise an textilfreien oder Gelegenheits-FKK-Veranstaltungen teilnehmen.
<G-vec00042-001-s145><attend.teilnehmen><en> In this situation, the person may only attend meetings, leaving the person clueless to or unaware of what the team is doing.
<G-vec00042-001-s145><attend.teilnehmen><de> In dieser Situation darf er nur an Meetings teilnehmen, so dass er ahnungslos ist und nicht weiß, was das Team tut.
<G-vec00042-001-s146><attend.teilnehmen><en> A few years ago in 2003,the Boqueria Food School was set up where you can attend a class or workshop about food preparation, produce and cooking techniques.
<G-vec00042-001-s146><attend.teilnehmen><de> Vor ein paar Jahren, im Jahr 2003, wurde die Boqueria Essens Schule gegründet, wo Sie an einer Klasse oder Workshop über Essenszubereitung, Erzeugnis- und Kochtechniken teilnehmen können.
<G-vec00042-001-s147><attend.teilnehmen><en> 10.01.16 Coldline will attend Sigep 2016 from the 23rd till the 27th of January in Rimini.
<G-vec00042-001-s147><attend.teilnehmen><de> 10.01.16 Coldline wird an Sigep 2016 vom 23 bis 27 von Januar in Rimini teilnehmen.
<G-vec00042-001-s148><attend.teilnehmen><en> But the most ambitious mikro project is the Wizards of OS conference in July 1999 which brings together computer scientists and media theorists, hackers, programmers and end users alike who will gather in the Haus der Kulturen der Welt to discuss the technological and social implications of operating systems and the rise of the Open Source movement -- and perhaps attend a Linux installation party as well.
<G-vec00042-001-s148><attend.teilnehmen><de> "Doch das ambitionierteste Projekt von mikro ist die „Wizards of OS"" Konferenz im Juli 1999, die Informatiker und Medientheoretiker, Hacker, Programmierer und Endnutzer im Haus der Kulturen der Welt zusammenbringen wird, um über die technologischen und gesellschaftlichen Implikationen von Betriebssystemen und den Aufstieg der Open Source Bewegung zu diskutieren – und vielleicht auch an einer Linux-Installations Party teilzunehmen."
<G-vec00042-001-s149><attend.teilnehmen><en> The Grand Master of the Order of Malta Fra' Andrew Bertie left for Madrid this morning to attend tomorrow's wedding between the Prince of Asturie, heir to the Spanish throne, and Letizia Ortiz.
<G-vec00042-001-s149><attend.teilnehmen><de> Der Großmeister des Malteserordens, Frà Andrew Bertie, ist am heutigen Vormittag nach Madrid abgereist, um morgen an den Hochzeitsfeierlichkeiten des spanischen Thronfolgers, des Prinzen von Asturien, mit Letizia Ortiz teilzunehmen.
<G-vec00042-001-s150><attend.teilnehmen><en> · Fall 1994: The Institute for Historical Review - a world-renowned historical research institute and an intellectual think tank for Revisionists - invited Zündel to attend their annual conference as one of their main speakers.
<G-vec00042-001-s150><attend.teilnehmen><de> · Herbst '94: Das Institute for Historical Review, das weltberühmte revisionistische Geschichtsforschungsinstitut, sozusagen eine Denkschmiede für Revisionisten, ladet Zündel ein, an ihrer Jahresversammlung in 1994 als einer der Hauptredner teilzunehmen.
<G-vec00042-001-s151><attend.teilnehmen><en> Crowds gather from all over the country to attend the liturgies and to worship
<G-vec00042-001-s151><attend.teilnehmen><de> Menschen kommen aus dem ganzen Land, um an den Liturgien teilzunehmen und zu beten.
<G-vec00042-001-s152><attend.teilnehmen><en> The members of the whole board shall have the right to attend all meetings of the Association’s roundtables, in particular but not limited to those of the divisions / working groups.
<G-vec00042-001-s152><attend.teilnehmen><de> Die Mitglieder des Gesamtvorstands haben das Recht, an allen Sitzungen der Gremien des Vereins, insbesondere an denen der Fachbereiche / Arbeitskreise teilzunehmen.
<G-vec00042-001-s153><attend.teilnehmen><en> The workshops are always greatly anticipated events, drawing students of the Order from different European countries. If you want to experience for yourself how intensive and transforming this intensive temple work is, and why people travel hundreds of kilometres to attend these events, make use of this opportunity now:
<G-vec00042-001-s153><attend.teilnehmen><de> Wenn Sie erfahren möchten, wie intensiv und transformierend die Tempelarbeit ist und warum Leute Hunderte von Kilometern fahren um an diesen Ereignissen teilzunehmen, nutzen Sie jetzt die Möglichkeit: Wir reservieren immer ein paar Plätze für Leute, die diese intensive magische Arbeit kennen lernen und erfahren wollen.
<G-vec00042-001-s154><attend.teilnehmen><en> Research this, and then plan to attend a meeting or two to mix and mingle.
<G-vec00042-001-s154><attend.teilnehmen><de> Forschung, und dann planen, an einer Sitzung teilzunehmen oder zwei zu mischen und zu mischen.
<G-vec00042-001-s155><attend.teilnehmen><en> Ozieri boasts a deep rooted religious tradition as well, and an historic presence of friars and monks helped by the diocese, the Seminary and the numerous and beautiful churches, so it is very easy to attend religious services in different hours of the day.
<G-vec00042-001-s155><attend.teilnehmen><de> Ozieri rühmt auch einer religiöser verwurzelte Tradition und eine geschichtliche religiöser Anwesendheit, begünstigt durch einen bischhöflichen Sitz, vom Seminar und von den zahlreichen und wunderschönen Kirchen, daher ist es sehr leicht, an verschiedenen Stunden am Tag, an religiösen Funktionen teilzunehmen.
<G-vec00042-001-s156><attend.teilnehmen><en> Professor Moscati was however the victim of his own success among the students, for many of them preferred to follow his lectures rather than to attend the official courses.
<G-vec00042-001-s156><attend.teilnehmen><de> Professor Moscati wurde in gewisser Weise ein Opfer seines Erfolgs bei den Studenten, denn viele von ihnen wollten, statt an den vorgesehenen Kursen teilzunehmen, lieber seine Vorlesungen hören.
<G-vec00042-001-s157><attend.teilnehmen><en> SAP held its annual SAPPHIRE NOW conference in Orlando, Florida recently, and I was fortunate to attend the event, which was said to be the biggest SAPPHIRE ever.
<G-vec00042-001-s157><attend.teilnehmen><de> SAP veranstaltete kürzlich seine jährliche SAPPHIRE NOW-Konferenz in Orlando, Florida und ich hatte das große Glück, an der Veranstaltung – die bisher größte SAPPHIRE – teilzunehmen.
<G-vec00042-001-s158><attend.teilnehmen><en> The day I decided to hop on a plane to attend a corporate event in Copenhagen; that day, I didn't know it yet, but it was the moment I took the most important decision in my life, which would lead to the success I would later achieve with Nu Skin.
<G-vec00042-001-s158><attend.teilnehmen><de> Der Tag, an dem ich beschloss, in ein Flugzeug nach Kopenhagen zu steigen, um an einer Veranstaltung des Unternehmens teilzunehmen... Dieser Tag, das wusste ich damals noch nicht, war der Moment, in dem ich die wichtigste Entscheidung meines Lebens getroffen habe, die mich letztendlich mit Nu Skin zum Erfolg führen sollte.
<G-vec00042-001-s159><attend.teilnehmen><en> Media representatives are required to obtain prior accreditation for this conference in order to gain access to the Austria Centre Vienna and to attend press briefings and side events.
<G-vec00042-001-s159><attend.teilnehmen><de> Hinweis für Journalisten Medienvertreter müssen sich für diese Konferenz akkreditieren, um Zugang zum Austria Centre Vienna zu erhalten und um an den Pressekonferenzen und Rahmenveranstaltungen teilzunehmen.
<G-vec00042-001-s160><attend.teilnehmen><en> The President may attend the meetings. Top
<G-vec00042-001-s160><attend.teilnehmen><de> Der Präsident ist berechtigt, an den Sitzungen teilzunehmen.
<G-vec00042-001-s161><attend.teilnehmen><en> We also invite you to attend our FAccT Center Research Seminar. Please contact us.
<G-vec00042-001-s161><attend.teilnehmen><de> Darüber hinaus laden wir Sie ein, als Zuhörer an unserem FAccT Center Research Seminar teilzunehmen.
<G-vec00042-001-s162><attend.teilnehmen><en> I spoke to people about the persecution of Falun Gong, and managed to routinely do morning exercises and attend our weekly Fa study group.
<G-vec00042-001-s162><attend.teilnehmen><de> Ich sprach mit Menschen über die Verfolgung von Falun Gong und schaffte es regelmäßig, die Übungen morgens zu machen und an unserer wöchentlichen Fa-Lerngruppe teilzunehmen.
<G-vec00042-001-s163><attend.teilnehmen><en> The event offers attendees the chance to attend workshops which will cover a wide variety of topics and to network with other trust and estate practitioners from all over the world.
<G-vec00042-001-s163><attend.teilnehmen><de> Die Veranstaltung bietet den Teilnehmern die Möglichkeit, an Workshops teilzunehmen, die eine Vielzahl von Themen abdecken und sich mit anderen Trust- und Estate-Practitionern aus der ganzen Welt vernetzen.
<G-vec00042-001-s164><attend.teilnehmen><en> Frame Rate versus Shutter Speed Axis Communications’ Academy gives you the opportunity to attend online courses anywhere in the world at any time.
<G-vec00042-001-s164><attend.teilnehmen><de> Axis Communications Academy bietet Ihnen die Möglichkeit, jederzeit und an jedem Ort der Welt an Online-Kursen teilzunehmen.
<G-vec00042-001-s165><attend.teilnehmen><en> If limited teaching has taken place this year because of the civil war, we recommend that you attend a preparatory college.
<G-vec00042-001-s165><attend.teilnehmen><de> Sollte in diesem einen Jahr aufgrund des Bürgerkrieges wenig Unterricht stattgefunden haben, wird empfohlen an einem Studienkolleg teilzunehmen.
<G-vec00042-001-s166><attend.teilnehmen><en> During the past 10 years the two partners have been working together and they could not miss the opportunity to attend the most important specialty coffee expo in Latin America and the Caribbean.
<G-vec00042-001-s166><attend.teilnehmen><de> Seit 10 Jahren arbeiten die beiden Partner zusammen und so konnten sie es sich natürlich nicht entgehen lassen an der wichtigsten specialty coffee expo in Lateinamerika und der Karibik teilzunehmen.
<G-vec00042-001-s167><attend.sein><en> You only need to attend FH JOANNEUM for a maximum of two Fridays and two Saturdays per month.
<G-vec00042-001-s167><attend.sein><de> Sie sind also nur maximal zwei Freitage und zwei Samstage im Monat an der Fachhochschule anwesend.
<G-vec00042-001-s168><attend.sein><en> Although this comprehensive degree is offered at international universities around the world, the cost of tuition will vary depending on which school the student chooses to attend.
<G-vec00042-001-s168><attend.sein><de> Obwohl dieser umfassende Abschluss an internationalen Universitäten auf der ganzen Welt angeboten wird, variieren die Unterrichtsstunden je nachdem, welche Schule der Studierende anwesend ist.
<G-vec00042-001-s169><attend.sein><en> Here you can get to know your fellow students, receive a lot of information about organizing your studies, and you will get program documents in printed form (anyone who cannot attend will be sent the documents by post).
<G-vec00042-001-s169><attend.sein><de> Hier können Sie Ihre Kommilitonen kennenlernen, sie bekommen viele Informationen rund um die Organisation des Studiums und erhalten die Studienunterlagen in ausgedruckter Form (alle, die nicht anwesend sein können, bekommen diese per Post zugeschickt).
<G-vec00042-001-s170><attend.sein><en> It is important for you and the other passengers that you attend this.
<G-vec00042-001-s170><attend.sein><de> Es ist für Sie selbst und für die Anderen wichtig, dass Sie hierbei anwesend sind.
<G-vec00042-001-s171><attend.sein><en> When a document is transmitted for service within the territory of another Contracting State the addressee shall be allowed, in the event that such service implies a time-limit affecting him, reasonable time, such time to be determined by the requesting State, from the moment he has received the document, to attend the proceedings or be represented or to make representations, as the case may be.
<G-vec00042-001-s171><attend.sein><de> Wird ein Schriftstück zur Zustellung im Hoheitsgebiet eines anderen Vertragsstaats übermittelt, so muss dem Empfänger, wenn diese Zustellung für ihn eine Frist in Gang setzt, eine von dem ersuchenden Staat festzulegende angemessene Zeit von der Übergabe des Schriftstücks an eingeräumt werden, um je nach Lage des Falles beim Verfahren anwesend zu sein, sich vertreten zu lassen oder die erforderlichen Schritte zu unternehmen.
<G-vec00042-001-s172><attend.sein><en> The director plans to attend and give an introduction of the film and be available for a subsequent discussion.
<G-vec00042-001-s172><attend.sein><de> Die Regisseurin wird zur Einführung des Films und zum anschließenden Gespräch anwesend sein.
<G-vec00042-001-s173><attend.sein><en> Although Titan Poker’s “vinex7″ of Russia was unable to attend and was blinded out of the action, he still brought home a $2,700 prize.
<G-vec00042-001-s173><attend.sein><de> "Obwohl Titan Poker ""vinex7"" von Russland war nicht anwesend und wurde von der Aktion geblendet, er noch nach Hause brachte ein $ 2.700 Preisgeld."
<G-vec00042-001-s174><attend.sein><en> The President and foreign dignitaries attend the event as well.
<G-vec00042-001-s174><attend.sein><de> Der Präsident und ausländische Würdenträger sind ebenso anwesend.
<G-vec00042-001-s175><attend.sein><en> The kiosks' flawless results have made them particularly popular in the galaxy's wealthiest circles, leading to a trend among these upper-class clients to sport entirely unique and exotic appearances at every social function they attend.
<G-vec00042-001-s175><attend.sein><de> Die fehlerlosen Resultate der Kiosks erfreuen sich insbesondere in den reichen Kreisen der Galaxis größter Beliebtheit, was bei diesen wohlhabenden Kunden zum Trend geführt hat, einzigartige und exotische Erscheinungsbilder für jede soziale Gelegenheit zu erschaffen, bei denen sie anwesend sind.
<G-vec00042-001-s176><attend.sein><en> However, Nakagoro who was pointed out as abandoning smuggling of North Korea did not attend.
<G-vec00042-001-s176><attend.sein><de> Nakagoro, der darauf hingewiesen wurde, dass er den Schmuggel Nordkoreas aufgegeben hatte, war jedoch nicht anwesend.
<G-vec00042-001-s177><attend.sein><en> However, all other Land Associations of German Sinti and Roma must be involved as well since they also call upon their re-spective Land Government to recognize the quorum of provisions under Part III of the Charter; these Land Governments mostly attend the Implementation Conference pri-marily on account of the protection of Romany.
<G-vec00042-001-s177><attend.sein><de> Erforderlich ist aber auch die Beteiligung der anderen Landesverbände Deutscher Sinti und Roma, denn diese fordern ebenso die An- erkennung des Charta-Quorums nach Teil III von ihren jeweiligen Landesregierungen, die auf den Implementierungskonferenzen meist nur wegen des Schutzes von Romanes anwesend sind.
<G-vec00042-001-s178><attend.sein><en> During your visit at SEA LIFE Jesolo you will attend feeding times and see how and when our sea friends get their lunch.
<G-vec00042-001-s178><attend.sein><de> Bei deinem Besuch in SEA LIFE Jesolo bist du bei einer der zahlreichen taglichen Schaufütterungen anwesend und du kannst erleben wie Seesterne und Krebse sich anfühlen.
<G-vec00042-001-s179><attend.sein><en> The two contestants, Constantinescu and Chişinevschi, didn't attend.
<G-vec00042-001-s179><attend.sein><de> Die beiden Widersacher des Parteichefs, Constantinescu und Chişinevschi, waren nicht anwesend.
<G-vec00042-001-s180><attend.sein><en> The management of GF Machining Solutions will also attend.
<G-vec00042-001-s180><attend.sein><de> Anwesend ist auch das Management von GF Machining Solutions.
<G-vec00042-001-s181><attend.sein><en> The President of Argentina Cristina Fernández de Kirchner, German Foreign Minister Guido Westerwelle and the Argentine Ministers of Foreign Affairs, Science and Education will attend the opening.
<G-vec00042-001-s181><attend.sein><de> Anwesend waren: die argentinische Staatspräsidentin Cristina Fernández de Kirchner, der deutsche Außenminister Guido Westerwelle sowie die argentinischen Außen-, Wissenschafts- und Erziehungsminister.
<G-vec00042-001-s182><attend.sein><en> """Unfortunately, not all of our brothers were able to attend,"" noted Chief Apostle Jean-Luc Schneider at the beginning of the session."
<G-vec00042-001-s182><attend.sein><de> """Leider können nicht alle Brüder anwesend sein"", musste Stammapostel Jean-Luc Schneider zu Beginn der Sitzung feststellen."
<G-vec00042-001-s183><attend.sein><en> The Chinese communist regime put extraordinary emphasis on this event, and dispatched three diplomats to attend the press conference.
<G-vec00042-001-s183><attend.sein><de> Das chinesische kommunistische Regime maß diesem Ereignis eine außerordentliche Gewichtung bei und entsandte drei Diplomaten, um bei dieser Pressekonferenz anwesend zu sein.
<G-vec00042-001-s184><attend.sein><en> The court allowed us to attend.
<G-vec00042-001-s184><attend.sein><de> Das Gericht erlaubte uns, anwesend zu sein.
<G-vec00042-001-s185><attend.sein><en> Serenata Mexican style, select your songs, go to any part More... of the city at any time without obligation just call and we will attend.
<G-vec00042-001-s185><attend.sein><de> Serenata mexikanischen Stil, wählen Sie Ihre Songs, gehen Sie zu Mehr... irgendeinem Teil der Stadt jederzeit und ohne Verpflichtung einfach anrufen und wir werden anwesend sein.
<G-vec00042-001-s186><attend.sein><en> By evaluating our preparation for receiving Kalachakra empowerment and our ability to keep the vows and commitments, we can make a realistic decision whether to attend as an active participant or an interested observer.
<G-vec00042-001-s186><attend.sein><de> Indem wir unsere Vorbereitung für den Erhalt der Kalachakra-Ermächtigung und unsere Fähigkeit, Gelübde und Verpflichtungen einzuhalten, einschätzen, können wir eine realistische Entscheidung treffen, ob wir als aktiver Teilnehmer oder als interessierter Beobachter anwesend sein wollen.
<G-vec00042-001-s187><attend.sein><en> You will attend the parade on the Champs-Elysées, his incredible Fireworks and her Republican guard.
<G-vec00042-001-s187><attend.sein><de> Sie werden im Umzug auf den Feldern Elysee, in seinem unglaublichen Feuerwerk und seiner republikanischen Bewachung anwesend sein.
<G-vec00042-001-s188><attend.sein><en> Moreover, keep in mind that it is not always necessary for all participants to attend the entire workshop.
<G-vec00042-001-s188><attend.sein><de> Beachten Sie auch: Es brauchen nicht immer alle Teilnehmer während des gesamten Workshops anwesend zu sein.
<G-vec00042-001-s189><attend.sein><en> It is to be desired that next time more collectors and dealers will attend to present their own research.
<G-vec00042-001-s189><attend.sein><de> Es ist zu wünschen, daß beim nächsten Mal wieder mehr Sammler und Händler anwesend sein werden, um ihre eigenen Forschungen vorzustellen.
<G-vec00042-001-s190><attend.sein><en> The concert was broadcasted live via Internet by Radio Volcán, the in-house radio station, to give people who weren't able to attend, the possibility to enjoy the whole concert online.
<G-vec00042-001-s190><attend.sein><de> Das Konzert wurde durch Radio Volcán, dem hausinternen Radiosender, via Internet live übertragen, um den Leuten, die nicht anwesend sein konnten, die Möglichkeit zu geben, das Ganze online zu genießen.
<G-vec00042-001-s191><attend.sein><en> All students are expected to attend and participate actively in class discussions of all readings and daily news.
<G-vec00042-001-s191><attend.sein><de> Von den Studierenden wird erwartet, im Unterricht stets anwesend zu sein und aktiv an Unterrichtsdiskussionen zur jeweiligen Kurslektüre oder den täglichen Nachrichten teilzunehmen.
<G-vec00042-001-s192><attend.sein><en> The Chinese Prime Minister Li Keqiang, the American Secretary of State Kerry, the German Chancellor Merkel and the French President Hollande are among those who will attend the meeting in Davos this year.
<G-vec00042-001-s192><attend.sein><de> In Davos werden dieses Jahr unter anderem der chinesische Premierminister Li Keqiang, der amerikanische Außenminister Kerry, die deutsche Kanzlerin Merkel und der französische Präsident Hollande anwesend sein.
<G-vec00042-001-s193><attend.sein><en> The ejaculate collection is the only step in the whole process you should attend.
<G-vec00042-001-s193><attend.sein><de> Die Entnahme des Ejakulats ist der einzige Schritt im ganzen Prozess, beim welchen Sie anwesend sein müssen.
<G-vec00042-001-s194><attend.sein><en> "He particularly thanked its founder, who was unable to attend in person due to illness, and paid tribute to him as an ""important business personality""."
<G-vec00042-001-s194><attend.sein><de> "Er dankte insbesondere bei dem Stiftungsgründer, der krankheitsbedingt nicht mehr selbst anwesend sein konnte, und würdigte ihn als ""bedeutende Unternehmerpersönlichkeit""."
<G-vec00042-001-s195><attend.sein><en> Neither attorneys, nor family members were allowed to attend the hearing.
<G-vec00042-001-s195><attend.sein><de> Weder die Anwälte noch die Familienangehörigen durften bei der Gerichtsverhandlung anwesend sein.
<G-vec00042-001-s196><attend.sein><en> In the event the client is unable to personally attend my site, this very intense and clearing method of energy work can be used as remote transmission.
<G-vec00042-001-s196><attend.sein><de> Diese äußerst intensive und klärende Art der Energiearbeit kann auch durch Fernübertragung angewendet werden, falls der Klient nicht vor Ort anwesend sein kann.
<G-vec00042-001-s197><attend.sein><en> Claudia Bandion-Ortner, Minister of Justice of the Republic of Austria, who unfortunately could not personally attend the presentation by reason of a business trip, but in her letter she promised to attend the next meeting, which is going to take place in spring 2010 in Kyiv.
<G-vec00042-001-s197><attend.sein><de> Claudia Bandion-Ortner, Justizministerin der Republik Österreich vor, welche wegen einer Dienstreise bei der Präsentation persönlich nicht anwesend sein konnte, in ihrem Schreiben versprach sie allerdings, das nächste für Frühling 2010 geplante Treffen der Gesellschaft in Kiew zu besuchen.
<G-vec00042-001-s198><attend.sein><en> The Meeting was streamed, so that people unable to attend in person could participate via IRC.
<G-vec00042-001-s198><attend.sein><de> Das Treffen wurde ins Internet gesendet, so dass Personen, die nicht in Persona anwesend sein konnten, via IRC teilnehmen konnten.
<G-vec00042-001-s199><attend.sein><en> The independent lectures will enable children to follow a topic even if they are only able to attend on one afternoon.
<G-vec00042-001-s199><attend.sein><de> Die unabhängigen Vorlesungen ermöglichen es den Kindern, einem Thema zu folgen, auch wenn sie nur einen Nachmittag anwesend sein können.
<G-vec00042-001-s200><attend.sein><en> I extend my greetings to your colleagues and friends who have been unable to attend.
<G-vec00042-001-s200><attend.sein><de> Ich weite meinen Gruß aus auf eure Kollegen und Freunde, die heute nicht anwesend sein konnten.
<G-vec00301-001-s217><attend.beachten><en> In our hotel we have all the knowledge and amenities needed to attend to either business or leisure travellers.
<G-vec00301-001-s217><attend.beachten><de> In unserem Hotel lassen wir alles Wissen und Annehmlichkeiten benötigen, um Geschäft oder Freizeitreisende zu beachten entweder.
<G-vec00301-001-s218><attend.beachten><en> The reason may have been that the water supply in Fatehpur Sikri was insufficient or of poor quality, or, as some historians believe, that Akbar had to attend to the northwest areas of his empire and therefore moved his capital northwest.
<G-vec00301-001-s218><attend.beachten><de> Der Grund kann gewesen sein, dass die Wasserversorgung in Fatehpur Sikri oder von der geringen Qualität unzulänglich war, oder, wie einige Historiker glauben, dass Akbar die Nordwestbereiche seines Reiches beachten musste und folglich, seinen Hauptnordwesten verschob.
<G-vec00301-001-s219><attend.beachten><en> Monday is Soccer Practice, Tuesday is Piano lesson, Wednesday is Church Activities, Thursday is a Soccer Game, Friday a birthday party to attend.
<G-vec00301-001-s219><attend.beachten><de> Montag ist Fußball-üblich, Dienstag ist Klavierlektion, Mittwoch ist Kirche-Tätigkeiten, Donnerstag ist ein Fußball-Spiel, Freitag eine GeburtstagPartei zu beachten.
<G-vec00301-001-s220><attend.beachten><en> Please attend to our FAQs entry in this case and install the following driver afterwards.
<G-vec00301-001-s220><attend.beachten><de> Beachten Sie in diesem Fall bitte unseren Eintrag in den FAQs dazu und installieren Sie anschließend folgenden Treiber.
<G-vec00301-001-s221><attend.beachten><en> In-between we attempt to attend to our own spiritual lessons and stay grounded.
<G-vec00301-001-s221><attend.beachten><de> In der Zwischenzeit versuchen wir, unsere spirituellen Lektionen zu beachten und bleiben geerdet.
<G-vec00301-001-s222><attend.beachten><en> But we are more likely to find such a new way if we first have a bodily felt sense of what is needed, and if we attend to it.
<G-vec00301-001-s222><attend.beachten><de> Aber die Wahrscheinlichkeit einen solchen Weg zu finden ist größer, wenn wir zumindest den körperlichen Felt Sense von dem haben, was gebraucht wird und wir diesen beachten.
<G-vec00301-001-s223><attend.beachten><en> But I was too curious not to attend.
<G-vec00301-001-s223><attend.beachten><de> Aber ich war zu neugierig nicht zu beachten.
<G-vec00301-001-s224><attend.beachten><en> Omitting prayer is calculated to lead the mind away from those duties which are incumbent upon us; then let us attend to our prayers and all our duties, and you will know that brother Brigham and his brethren have told you of these things...
<G-vec00301-001-s224><attend.beachten><de> Das Versäumnis des Gebets führt dazu, dass der Geist von den Pflichten abgelenkt wird, die uns obliegen; lasst uns dann also unsere Gebete beachten und alle unsere Pflichten, und ihr werdet wissen, dass Bruder Brigham und seine Brüder zu euch von diesen Dingen sprach....
<G-vec00301-001-s225><attend.beachten><en> My hunch had been correct that the session on Russian Pedagogy was the one I needed to attend.
<G-vec00301-001-s225><attend.beachten><de> Meine Ahnung war korrekt gewesen, die der Lernabschnitt auf russischer Pädagogik das ein I war, das benötigt wurde, um zu beachten.
<G-vec00301-001-s226><attend.beachten><en> An announcement of the Roadrunners would be made at that time if I was unable to attend in person.
<G-vec00301-001-s226><attend.beachten><de> Eine Ansage der Roadrunners würde zu dieser Zeit gebildet, wenn ich nicht imstande war, persönlich zu beachten.
<G-vec00301-001-s227><attend.beachten><en> Despite the difficulties of wartime transportation, 'Munny' insisted upon making her annual summer excursion to Milford, Pennsylvania, to attend to property inherited from her parents.
<G-vec00301-001-s227><attend.beachten><de> Trotz der Schwierigkeiten des Kriegtransportes, beharrte ` Munny ' nach dem Lassen ihrer jährlichen Sommerexkursion zu Milford, Pennsylvania, die Eigenschaft beachten, die von ihren Eltern übernommen wurde.
<G-vec00301-001-s228><attend.beachten><en> My family would love to attend, and maybe take a walk over to Anissa's house while we are in the area.
<G-vec00301-001-s228><attend.beachten><de> Meine Familie würde lieben zu beachten und möglicherweise einen Spaziergang vorbei zu Anissa' macht; s-Haus, während wir im Bereich sind.
<G-vec00301-001-s229><attend.beachten><en> Â My family would love to attend, and maybe take a walk over to Anissa's house while we are in the area.
<G-vec00301-001-s229><attend.beachten><de> Meine Familie würde lieben zu beachten und möglicherweise einen Spaziergang vorbei zu Anissa' macht; s-Haus, während wir im Bereich sind.
<G-vec00301-001-s230><attend.beachten><en> If such an orientation is available, it is a good idea to attend as a way to learn about all of the options at your fingertips and decide what activities to choose that will enhance your luxury experience.
<G-vec00301-001-s230><attend.beachten><de> Wenn solch eine Lagebestimmung vorhanden ist, ist es eine gute Idee, als Weise zu beachten, über alle Wahlen an deinen Fingerspitzen zu erlernen und zu entscheiden, welche Tätigkeiten zum zu wählen, die deine Luxuxerfahrung erhöhen.
<G-vec00301-001-s231><attend.beachten><en> The College Board estimates the average four-year public college costs almost $5,000 per year to attend and a two-year public college is almost $2000.
<G-vec00301-001-s231><attend.beachten><de> Das Hochschulgremium schätzt die durchschnittlichen vierjährlichen allgemeine Hochschulkosten fast $5.000 pro Jahr, um zu beachten und eine zweijährige allgemeine Hochschule ist fast $2000.
<G-vec00301-001-s232><attend.begleiten><en> The Chamber recommends that always two midwives attend a birth.
<G-vec00301-001-s232><attend.begleiten><de> Die Empfehlung des Verbandes ist, dass immer zwei Hebammen eine Geburt begleiten.
<G-vec00301-001-s233><attend.begleiten><en> - helps to attend projekts and plans ongoing...
<G-vec00301-001-s233><attend.begleiten><de> - hilft Projekte und Vorhaben laufend zu begleiten...
<G-vec00301-001-s234><attend.begleiten><en> Never do the secondary supernaphimˆ fail to pilot their subjects successfully on the second attempt, and the same superaphicˆ ministers and other guides always attend these candidates during this second adventure.
<G-vec00301-001-s234><attend.begleiten><de> Beim zweiten Versuch führen die sekundären Supernaphim die ihnen Anvertrauten unfehlbar zum Erfolg, und es sind immer dieselben superaphischen Betreuer und anderen Führer, welche die Kandidaten während des zweiten Abenteuers begleiten.
<G-vec00301-001-s235><attend.begleiten><en> On behalf of our clients we conduct and attend to cases before federal, cantonal and local authorities and administrative institutions, self-regulatory organizations and all administrative law courts.
<G-vec00301-001-s235><attend.begleiten><de> Für unsere Klienten führen und begleiten wir Verfahren vor Behörden und Verwaltungsinstitutionen des Bundes, der Kantone und Gemeinden, vor Selbstregulierungsorganisationen sowie vor allen verwaltungsrechtlichen Instanzen.
<G-vec00301-001-s236><attend.begleiten><en> In contrast to many other start-up consultancies, with our start-up consultancy you profit from the cooperation with an integrated team from strategy, marketing and finance experts who attend founders of new businesses and many medium-sized businesses economically and thus offer you not only the start-up consulting but also a high potential of active support in the continuous start-up stabilization.
<G-vec00301-001-s236><attend.begleiten><de> Im Gegensatz zu vielen anderen Existenzgründerberatungen profitieren Sie bei unserer Existenzgründerberatung durch die Zusammenarbeit mit einem integrierten Team aus Strategie-, Marketing- und Finanzexperten, die neben Existenzgründern auch viele mittelständische Unternehmen wirtschaftlich begleiten, und Ihnen so über die Existenzgründungsberatung hinaus ein hohes Potential an aktiver Unterstützung in der kontinuierlichen Existenzgründungsstabilisierung bieten.
<G-vec00301-001-s237><attend.begleiten><en> At our day clinic, we will attend you throughout the entire treatment.
<G-vec00301-001-s237><attend.begleiten><de> In unserer Praxis begleiten wir Sie während der gesamten Kur.
<G-vec00301-001-s238><attend.begleiten><en> In this way a business is created under the management of Ernst Eckert, a scion of the founding family Ott, and its products and services were to attend and shape the culture of tobacco and smoking in Europe and overseas for a long time - for 150 years now.
<G-vec00301-001-s238><attend.begleiten><de> Unter der Federführung von Ernst Eckert, einem Sproß der Gründerfamilie Ott, entsteht so ein Unternehmen, dessen Produkte und Leistungen die Tabak- und Rauchkultur in Europa und Übersee begleiten und nachhaltig prägen sollten - seit nunmehr über 150 Jahren.
<G-vec00301-001-s239><attend.begleiten><en> We attend you in the phases of growth, start-up or in the crisis with purposeful controlling.
<G-vec00301-001-s239><attend.begleiten><de> Wir begleiten Sie in Phasen des Wachstums, Start-Ups oder in der Krise mit zielführendem Controlling.
<G-vec00301-001-s240><attend.begleiten><en> We are going to continue to attend to the issue of LGBTI in Mexico and are curious how the individual initiatives will work out”, von Schönfeld finally explains.
<G-vec00301-001-s240><attend.begleiten><de> Wir werden das Thema LSBTI in Mexiko weiter begleiten und sind gespannt, wie die einzelnen Initiativen laufen“, erklärt von Schönfeld abschließend.
<G-vec00301-001-s241><attend.begleiten><en> The idea of this program is to attend and promote the process of change of violent women.
<G-vec00301-001-s241><attend.begleiten><de> Die Zielsetzung des Trainingsprogramms ist, einen Prozess der Veränderung der gewalttätigen Frauen zu befördern und zu begleiten.
<G-vec00301-001-s242><attend.begleiten><en> Where necessary, interpreters attend these check-ups and medical care.
<G-vec00301-001-s242><attend.begleiten><de> Wenn nötig, begleiten Dolmetscher diese medizinischen Untersuchungen und Betreuung.
<G-vec00301-001-s243><attend.begleiten><en> Before we start or attend IT outsourcing projects, we make a cost-benefit analysis regarding the IT outsourcing project for our customers so that the IT outsourcing will be economically successful in the long term.
<G-vec00301-001-s243><attend.begleiten><de> Bevor wir IT Outsourcing Projekte starten oder begleiten, erstellen wir eine Kosten- und Nutzenanalyse zum IT Outsourcing Vorhaben für unsere Kunden, damit IT Outsourcing auch langfristig wirtschaftlich erfolgreich wird.
<G-vec00301-001-s244><attend.begleiten><en> It does not seem that anything would be more suitable to practice than harmonizing, because one must always attend to the principal singers and follow their movement.
<G-vec00301-001-s244><attend.begleiten><de> Nun gibt es nichts, was so geeignet wäre, das Tonerkennen zu üben, als das Begleiten, weil man immer auf die Prinzipalstimmen Acht geben und ihre Bewegung verfolgen muss.
<G-vec00301-001-s245><attend.begleiten><en> This is merely the first of the successive administrative adjustments which attend the unfolding of the successive ages of increasingly brilliant attainment on the inhabited worlds as they pass from the first to the seventh stage of settled existence.
<G-vec00301-001-s245><attend.begleiten><de> Das ist nur die erste der sukzessiven administrativen Anpassungen, die die Entfaltung der aufeinander folgenden Zeitalter immer strahlenderen Vollbringens begleiten, während die bewohnten Welten vom ersten zum siebenten Stadium gefestigter Exi stenz vorrücken.
<G-vec00301-001-s246><attend.begleiten><en> We attend and communicate the sustainable value orientation of the entire company.
<G-vec00301-001-s246><attend.begleiten><de> Wir begleiten und kommunizieren die nachhaltige Wertorientierung des gesamten Unternehmens.
<G-vec00301-001-s247><attend.begleiten><en> Not only form outside you can discovery an impressive piece of design, at inside attend a mix of nubs, grooves and curves you to a unique massage pleasure.
<G-vec00301-001-s247><attend.begleiten><de> Nicht nur außen lässt sich hier ein gelungenes Designstück entdecken, im Inneren begleiten eine Mischung aus weichen Noppen, Rillen, Kurven und Erhebungen dein bestes Stück zu einem einzigartigen Massageerlebnis.
<G-vec00301-001-s248><attend.begleiten><en> Love, trust and deep affection attend them with every gesture through this day.
<G-vec00301-001-s248><attend.begleiten><de> Liebe, Vertrauen und tiefe Zuneigung begleiten sie mit jeder ihrer Gesten durch den Tag.
<G-vec00301-001-s249><attend.begleiten><en> "Aside from the training events, which provide us with direct feedback on our work, I find it extremely interesting to plan and attend to larger change projects in interdisciplinary teams, where one can see the execution and results of one's work ""live."""
<G-vec00301-001-s249><attend.begleiten><de> "Dabei finde ich es neben den Trainingsveranstaltungen, die uns ein direktes Feedback zur Arbeit geben, besonders spannend, größere Veränderungsvorhaben in interdisziplinären Teams zu planen und zu begleiten, bei denen man die Umsetzung und die Ergebnisse seiner Arbeit hinterher ""live"" sehen kann."
<G-vec00301-001-s250><attend.begleiten><en> We attend demonstrations for a cause .
<G-vec00301-001-s250><attend.begleiten><de> Wir begleiten Demonstrationen für eine Sache.
<G-vec00042-001-s270><attend.beiwohnen><en> In the morning, early, we went on foot along the arcades, to the solemn tolling of the shrine’s enormous bell, as far as the large open space: we found a good position, on the edge of the square, to attend the sung pontifical mass, celebrated by Cardinal La Fontaine, the Patriarch of Venice; but it wasn’t possible to get into the beautiful shrine because of the crowds of people.
<G-vec00042-001-s270><attend.beiwohnen><de> Am Morgen gingen wir dann, vom feierlichen Geläut der großen Glocke begleitet, durch die Säulengänge zu dem großen Platz: dort hatten wir am Wegesrand einen guten Platz erhascht, von dem aus wir dem Pontifikalamt beiwohnen konnten, das von Kardinal La Fontaine gefeiert wurde, dem Patriarchen von Venedig; leider war es aufgrund der großen Menschenmassen nicht möglich, das wunderschöne Marienheiligtum zu betreten.
<G-vec00042-001-s271><attend.beiwohnen><en> You do not need to be present during the expert's appraisal, but you may attend if you so wish.
<G-vec00042-001-s271><attend.beiwohnen><de> Sie brauchen bei der Erstellung des Gutachtens nicht anwesend zu sein, Sie können ihr aber beiwohnen, wenn Sie das möchten.
<G-vec00042-001-s272><attend.beiwohnen><en> The Commission or other National Contact Points can also attend the meetings.
<G-vec00042-001-s272><attend.beiwohnen><de> Die Kommission oder andere Nationale Kontaktstellen können den Treffen ebenfalls beiwohnen.
<G-vec00042-001-s273><attend.beiwohnen><en> Right at the start of the semester an excursion to the Graf-Adolf Platz square is taking place, during which the students of the Artistic Text in Music, Sound Art, Film and Radio Plays seminar will attend a public performance of ROTH ELECTRIC - Sprechperformance - Sounds [ROTH ELECTRIC – spoken performance – sounds] by the Düsseldorf artist Jörg Steinmann.
<G-vec00042-001-s273><attend.beiwohnen><de> Direkt zum Semesterstart findet eine erste Exkursion zum Graf-Adolf Platz statt, wo die Studierenden des Seminars Künstlerischer Text in Musik, Klangkunst, Film und Hörspiel eine öffentliche Sprech-Performance ROTH ELECTRIC - Sprechperformance - Sounds des Düsseldorfer Künstlers Jörg Steinmann beiwohnen.
<G-vec00042-001-s274><attend.beiwohnen><en> Serbian President Tomislav Nikolic has gone to London, where he will attend tonight the opening ceremony of the Olympic Games, along with more than 100 world leaders.
<G-vec00042-001-s274><attend.beiwohnen><de> Der Präsident Serbiens Tomislav Nikolic ist in London angereist, wo er heute Abend der Eröffnung der Olympischen Spiele beiwohnen wird, und die ersten zwei Tage wird er mit den serbischen Sportlern mitfiebern.
<G-vec00042-001-s275><attend.beiwohnen><en> There you can meet the region's many producers, taste and choose the best strawberry, or attend concerts and shows.
<G-vec00042-001-s275><attend.beiwohnen><de> Dort kann man die vielen Produzenten aus der Region treffen, die beste Erdbeere probieren und küren und Konzerten und Vorführungen beiwohnen.
<G-vec00042-001-s276><attend.beiwohnen><en> "In the Recreo de las Cadenas, work of the French architect Garnier and headquarters of the Royal Andalusian School of the Equestrian Art, we can attend a demonstration of ""How the Andalusian Horses Dance""."
<G-vec00042-001-s276><attend.beiwohnen><de> "Im Recreo de las Cadenas, einem Werk des französischen Architekten Garnier und Sitz der Real Escuela Andaluza del Arte Ecuestre (Königlichen Andalusischen Reitschule), kann man der Dressurschau ""Cómo Bailan los Caballos Andaluces"" (Wie tanzen die andalusischen Pferde) beiwohnen."
<G-vec00042-001-s277><attend.beiwohnen><en> This camera is available for live interviews to members of the media who attend the event and may not have a full camera crew with them, or who may not have access to satellite time.
<G-vec00042-001-s277><attend.beiwohnen><de> Diese Kamera ist für Live-Interviews für Medienvertreter verfügbar, die dem Ereignis beiwohnen und kein Kamerateam dabei haben, oder denen keine Satellitenzeit zur Verfügung steht.
<G-vec00042-001-s278><attend.beiwohnen><en> Some NGOs are more involved in discussing the committee's plans and legal initiatives, and committee members sometimes attend different NGO events.
<G-vec00042-001-s278><attend.beiwohnen><de> Manche NGO's beteiligen sich mehr an den Besprechung der Pläne und Rechtsinitiativen des Komitees, dessen Mitglieder ab und zu auch verschiedenen NGO-Veranstaltungen beiwohnen.
<G-vec00042-001-s279><attend.beiwohnen><en> "So the bishop could enter directly from the floor of the palace the West bars and attend the service in the ""royal box"" with his guests."
<G-vec00042-001-s279><attend.beiwohnen><de> So konnte der Bischof direkt vom Obergeschoss des Palastes den Westriegel betreten und in der „Kaiserloge“ mit seinen Gästen dem Gottesdienst beiwohnen.
<G-vec00042-001-s280><attend.beiwohnen><en> Today, the museum is a meeting place of the Wittenberger inhabitants and their guests, we were lucky enough to be able to attend a musical event - music that did not fit the Renaissance and yet or just because of that found its audience.
<G-vec00042-001-s280><attend.beiwohnen><de> Heute Museum und Treffpunkt der Wittenberger und ihrer Gäste hätten wir das Glück einem musikalischen Event beiwohnen zu können - Musik die so gar nicht zur Renaissance passte und trotzdem oder gerade deshalb ihre Zuhörer gefunden hat.
<G-vec00042-001-s281><attend.beiwohnen><en> All media representatives who may wish to attend the event are welcome to do so.
<G-vec00042-001-s281><attend.beiwohnen><de> Alle Mediavertreter, die dem Event beiwohnen wollen, können dies tun.
<G-vec00042-001-s282><attend.beiwohnen><en> "And holy angels as ministers and witnesses, in number ""ten thousand times ten thousand, and thousands of thousands,"" attend this great tribunal."
<G-vec00042-001-s282><attend.beiwohnen><de> Und als Diener und Zeugen werden heilige Engel an Zahl „tausendmal tausend und zehntausendmal zehntausend,“ diesem großen Gericht beiwohnen.
<G-vec00042-001-s283><attend.beiwohnen><en> Thus outside parties and Ms. Li's family members did not get to attend the trial.
<G-vec00042-001-s283><attend.beiwohnen><de> Aus diesem Grunde konnten außenstehende Parteien und die Familienangehörigen von Frau Li dem Verfahren nicht beiwohnen.
<G-vec00042-001-s284><attend.beiwohnen><en> If you are keen to attend a musical event at the Palau see our article on 'A Guide to Classical Concert Venues in Barcelona ' for more information.
<G-vec00042-001-s284><attend.beiwohnen><de> Wenn Sie unbedingt einem Konzert im Palau de la Música beiwohnen möchten, lesen Sie unseren Artikel, Reiseführer zu Veranstaltungsorten für klassische Konzerte in Barcelona '.
<G-vec00042-001-s285><attend.beiwohnen><en> However, researchers and public figures were allowed to attend this rehearsal.
<G-vec00042-001-s285><attend.beiwohnen><de> Rechercheure und öffentliche Personen durften der Probe beiwohnen.
<G-vec00042-001-s286><attend.beiwohnen><en> (3) The parties shall be informed of all dates for the taking of evidence, and may attend the taking of evidence.
<G-vec00042-001-s286><attend.beiwohnen><de> (3) Die Beteiligten werden von allen Beweisterminen benachrichtigt und können der Beweisaufnahme beiwohnen.
<G-vec00042-001-s287><attend.beiwohnen><en> "The Chairman of SIX Exchange Regulation is a permanent guest at the meetings of the Management Committee (""MC"") of the Group unit which operates the exchange (currently the Cash Markets Division of SIX Swiss Exchange Ltd), and may also attend the meetings of the executive bodies of the other regulated exchanges within SIX Group as a guest without voting rights."
<G-vec00042-001-s287><attend.beiwohnen><de> Der Vorsitzende von SIX Exchange Regulation ist ständiger Gast in der GL (heute Management Committee [MC]) der Konzerneinheit, welche die Börse betreibt (heute Division Cash Market der SIX Swiss Exchange AG) und darf den Sitzungen der geschäftsleitenden Organe der übrigen regulierten Börsen der SIX Group als Gast ohne Stimmrecht ebenfalls beiwohnen.
<G-vec00042-001-s288><attend.beiwohnen><en> I had the enormous fortune to attend Teacher's Falun Dafa (or Falun Gong) lectures in 1993 and 1994.
<G-vec00042-001-s288><attend.beiwohnen><de> Ich hatte das enorme Glück, dass ich den Falun Gong- Vorlesungen des Meisters in den Jahren 1993 /94 beiwohnen konnte.
<G-vec00042-001-s289><attend.beiwohnen><en> The personal monitors are most strict and watchful on occasions when practitioners are forced to attend meetings, do slave labour, study brainwashing materials, and assemble together, and when they eat, engage in activities such as training, walking, medical check-ups and going to the toilet.
<G-vec00042-001-s289><attend.beiwohnen><de> Die persönlichen Beobachter sind äußerst strikt und wachsam bei Anlässen, wenn Praktizierende gezwungen werden, Treffen beizuwohnen, Sklavenarbeit zu verrichten, Gehirnwäschematerialien zu studieren und sich zu treffen und wenn sie essen, sich in Aktivitäten engagieren, wie Training, Gehen, medizinische Untersuchungen oder die Toiletten aufsuchen.
<G-vec00042-001-s290><attend.beiwohnen><en> Some of these men made a four-hour round trip to attend those prayer meetings.
<G-vec00042-001-s290><attend.beiwohnen><de> Einige dieser Männer reisten vier Stunden hin und zurück, um diesen Gebetsversammlungen beizuwohnen.
<G-vec00042-001-s291><attend.beiwohnen><en> Dafa practitioners from Toronto and Ottawa, overcoming many difficulties, arrived to work with local practitioners to comprehensively explain the facts to local people and attend the three days of court hearings.
<G-vec00042-001-s291><attend.beiwohnen><de> Unter vielen Schwierigkeiten kamen Falun Gong Praktizierende aus Toronto und Ottawa, um mit den örtlichen Praktizierenden zusammenzuarbeiten, den Einwohnern die wahren Hintergründe zu erklären und den dreitägigen Gerichtsanhörungen beizuwohnen.
<G-vec00042-001-s292><attend.beiwohnen><en> Tell them you have to attend classes.
<G-vec00042-001-s292><attend.beiwohnen><de> Sag ihnen ihr habt den Klassen beizuwohnen.
<G-vec00042-001-s293><attend.beiwohnen><en> In T 998/04 the board emphasised as an obiter dictum that the burden of proof for alleged lack of patentability lay with the opponent and could not be dispensed with by requesting the board to carry out its own investigations, in particular, by summoning four named witnesses, by commissioning an independent expert to carry out experimental tests and by allowing individuals from the appellant company to attend any tests and to question witnesses or experts.
<G-vec00042-001-s293><attend.beiwohnen><de> "In der Sache T 998/04 betonte die Kammer in einem ""obiter dictum"", dass die Beweislast für die behauptete mangelnde Patentfähigkeit beim Einsprechenden liegt und nicht abgewälzt werden kann, indem man die Kammer ersucht, eigene Ermittlungen durchzuführen, vor allem indem vier namentlich genannte Zeugen geladen werden, ein unabhängiger Sachverständiger mit der Durchführung experimenteller Tests beauftragt wird und Mitarbeitern des Beschwerdeführers gestattet wird, den Tests beizuwohnen sowie Zeugen und Experten zu befragen."
<G-vec00042-001-s294><attend.beiwohnen><en> It is far wiser to attend in this manner than to make a premature commitment we later regret.
<G-vec00042-001-s294><attend.beiwohnen><de> Es ist bei weitem weiser, auf diese Art beizuwohnen, als vorschnell Verpflichtungen aufzunehmen, die wir später bereuen.
<G-vec00042-001-s295><attend.beiwohnen><en> He is invited to conduct three workshops and rehearsals on the piece during the Academy in August, and to attend the dress rehearsal and concert in October.
<G-vec00042-001-s295><attend.beiwohnen><de> Er ist eingeladen, während der Academy im August drei Workshops und Proben zu dem Stück zu leiten und der Generalprobe und dem Konzert im Oktober beizuwohnen.
<G-vec00042-001-s296><attend.beiwohnen><en> Members of the European Parliament. Today as Taoiseach I’m honoured to attend the European Parliament and present the priorities of the Irish Presidency.
<G-vec00042-001-s296><attend.beiwohnen><de> Sehr geehrte Abgeordnete Heute habe ich als Taoiseach die Ehre, dem Europäischen Parlament beizuwohnen und die Prioritäten des irischen Ratsvorsitzes zu präsentieren.
<G-vec00042-001-s297><attend.beiwohnen><en> The court only allowed two family members to attend the hearing.
<G-vec00042-001-s297><attend.beiwohnen><de> Das Gericht erlaubte nur zwei ihrer Familienangehörigen, der Anhörung beizuwohnen.
<G-vec00042-001-s298><attend.beiwohnen><en> Urantia Foundation encourages readers of The Urantia Book to attend or organize study groups in their communities.
<G-vec00042-001-s298><attend.beiwohnen><de> Die Urantia Stiftung ermuntert Leser des Urantia Buches, Lesegruppen in ihrer Umgebung zu organisieren oder beizuwohnen.
<G-vec00042-001-s299><attend.beiwohnen><en> Photo 2: Some sisters who took part in the CJ Formation Conference had the opportunity to attend the canonization.
<G-vec00042-001-s299><attend.beiwohnen><de> Foto 2: Einige Schwestern, die an der CJ-Formationskonferenz teilnahmen, hatten die Möglichkeit, der Heiligsprechung beizuwohnen.
<G-vec00042-001-s300><attend.beiwohnen><en> "As companions, they invite members of the audience to follow them and attend a version of 4' 33"" performed at a venue they have chosen."
<G-vec00042-001-s300><attend.beiwohnen><de> "Als Begleiterinnen und Begleiter laden sie dazu ein, ihnen zu folgen und einer Version von 4' 33"" an einem von ihnen gewählten Ort beizuwohnen."
<G-vec00042-001-s301><attend.beiwohnen><en> "Along with the many topics covering sport and exercise facilities, the many club representatives were also provided with comprehensive information on club topics, the work of the association and given the possibility to attend a ""sport discussion"" by the regional association."
<G-vec00042-001-s301><attend.beiwohnen><de> "Für die vielen Vereinsvertreter gab es neben den vielen Foren zu Sport- und Bewegungsanlagen auch umfassende Informationen des Landessportbundes zu Vereinsthemen und der Arbeit des Verbandes und die Möglichkeit dem ""Sportgespräch"" beizuwohnen."
<G-vec00042-001-s302><attend.beiwohnen><en> Since I know that this is not possible and if you allow Texas to carry out the execution I will invite you to attend his execution together with me because in this case I need your support and guidance.
<G-vec00042-001-s302><attend.beiwohnen><de> Da ich weiß, daß das nicht möglich ist und falls Sie Texas erlauben, die Hinrichtung auszuführen, möchte ich Sie einladen, der Hinrichtung gemeinsam mit mir beizuwohnen, denn in diesem Fall benötige ich Ihre Unterstützung.
<G-vec00042-001-s303><attend.beiwohnen><en> Although her friends tried to attend to her, none of them knew why she fainted.
<G-vec00042-001-s303><attend.beiwohnen><de> Obwohl ihre Freunde versuchten, Ihr beizuwohnen, wusste keiner von ihnen, warum sie ohnmächtig geworden.
<G-vec00042-001-s304><attend.beiwohnen><en> Armed Forces Day: This was first held in 2009 and takes place on a Saturday in late June 'so that school children and most working adults would be available to attend events'.
<G-vec00042-001-s304><attend.beiwohnen><de> "Der Tag der Streitkräfte: Dieser wurde erstmals 2009 abgehalten und findet an einem Samstag Ende Juni statt, ""so dass Schulkinder und die meisten Erwachsenen in Arbeit erreichbar sind, um den Veranstaltungen beizuwohnen""."
<G-vec00042-001-s305><attend.beiwohnen><en> "At Schloss Spitz, many festival guests meet again, as well as writers and filmmakers, to attend today's prize-giving ceremony for the ""Austrian Book Trade Honorary Award for Tolerance in Thought and Action""."
<G-vec00042-001-s305><attend.beiwohnen><de> "Auf Schloß zu Spitz finden sich wieder viele BesucherInnen des Festivals ein, sowie Literatur- und Filmschaffende, um heute der Verleihung des ""Ehrenpreises des österreichischen Buchhandels für Toleranz in Denken und Handeln"" beizuwohnen."
<G-vec00042-001-s306><attend.beiwohnen><en> The court also didn't allow Falun Gong practitioners to attend the trial.
<G-vec00042-001-s306><attend.beiwohnen><de> Das Gericht erlaubte Falun Gong-Praktizierenden nicht, dem Verfahren beizuwohnen.
<G-vec00042-001-s307><attend.beiwohnen><en> In July, 2017, US President Donald Trump even stopped in Warsaw to attend the second meeting of the Three Seas Initiative .
<G-vec00042-001-s307><attend.beiwohnen><de> Im Juli 2017 war sogar US-Präsident Donald Trump zu Gast in Warschau, um dem zweiten Treffen der Drei-Meere-Initiative beizuwohnen.
<G-vec00042-001-s308><attend.belegen><en> The largest official foreign display is of course being prepared by the partner country India; it will occupy almost the entire Hall A1 and 150 Indian companies are expected to attend.
<G-vec00042-001-s308><attend.belegen><de> Den überhaupt größten offiziellen ausländischen Stand bereitet natürlich das MSV-Partnerland Indien vor: er wird fast die ganze Halle A1 belegen, erwartet werden rund 150 indische Firmen.
<G-vec00042-001-s309><attend.belegen><en> Depending on the Marshall Center resident program chosen for the study concentration, students then attend either the module “Transnational Governance” or the module “Security and Development,” which focus on dealing with transnational threats and
<G-vec00042-001-s309><attend.belegen><de> Je nach gewähltem Marshall Center-Lehrgang während der „Study Concentration“ belegen die Studenten danach entweder das Modul „Transnational Governance” oder das Modul „Security and Development”, das als Schwerpunkt transnationale Bedrohungen und Herausforderungen sowie den Nexus Sicherheit und Entwicklung hat und hier insbesondere die Entwicklung in einem Post-Konflikt-Umfeld.
<G-vec00042-001-s310><attend.belegen><en> "Despite the possibility to attend all four courses in parallel, it is recommended to attend the courses ""Advanced IT Basics"" and ""Advanced Web Basics"" one after the other and then to attend the courses ""Tools & Methods in Digital Humanities"" and ""Digital Object Processing""."
<G-vec00042-001-s310><attend.belegen><de> "Trotz der Möglichkeit, alle vier Lehrveranstaltungen parallel zu belegen, empfiehlt es sich, die Veranstaltungen ""Advanced IT Basics"" und ""Advanced Web Basics"" nacheinander zu besuchen und anschließend die Veranstaltungen ""Tools & Methods in Digital Humanities"" und ""Digital Object Processing"" zu belegen."
<G-vec00042-001-s311><attend.belegen><en> And the prospect of wasting her precious time with learning stuff she is not interested in, only to be able to attend to the few interesting courses, produced an incredible amount of frustration for my client.
<G-vec00042-001-s311><attend.belegen><de> Und die Aussicht darauf, ihre kostbare Zeit mit Zeug zu vergeuden, das sie nicht interessiert, nur um die wenigen interessanten Fächer belegen zu können, erzeugte in meiner Klientin eine unglaubliche Frustration.
<G-vec00042-001-s312><attend.belegen><en> The events are aimed at pupils from high-school senior classes and are particularly suitable for groups of pupils who attend physics classes with a higher level of requirements.
<G-vec00042-001-s312><attend.belegen><de> Die Veranstaltungen richten sich an Schüler*innen der gymnasialen Oberstufe und ist für Schüler*innengruppen, die den Physikunterricht mit erhöhtem Anforderungsniveau belegen, besonders geeignet.
<G-vec00042-001-s313><attend.belegen><en> In the first semester, you attend introductory courses on Political Science, methods and statistics, and the political system in the Federal Republic of Germany .
<G-vec00042-001-s313><attend.belegen><de> Im Studium belegen Sie zunächst Einführungs­veranstaltungen zu Politik­wissenschaft, Methoden und Statistik und zum System der Bundes­republik Deutschland .
<G-vec00042-001-s314><attend.belegen><en> Students attend 4-5 classes per semester most of which will be (research-based) seminars.
<G-vec00042-001-s314><attend.belegen><de> Studierende belegen 4-5 Kurse pro Semester, wovon der Großteil (Forschungs-)Seminare sind.
<G-vec00042-001-s315><attend.belegen><en> With a 'Studium Generale at a partner university ' of SRH Hochschule Berlin, you attend interdisciplinary classes at a foreign university.
<G-vec00042-001-s315><attend.belegen><de> Beim Studium Generale an einer Partnerhochschule der SRH Hochschule Berlin belegen Sie interdisziplinäre Studienfächer an einer ausländischen Universität.
<G-vec00042-001-s316><attend.belegen><en> In exceptional cases it is also possible for BA students to attend courses from the MA programme.
<G-vec00042-001-s316><attend.belegen><de> In Ausnahmefällen ist es auch möglich, dass Bachelorstudierende Kurse aus dem Masterprogramm belegen.
<G-vec00042-001-s317><attend.belegen><en> The aim behind the academy is to give schoolchildren of different age groups the chance to attend seminars on robotics, microcontrollers and automation so they can learn how to develop their ideas and get to grips with the technical terminology.
<G-vec00042-001-s317><attend.belegen><de> Hier sollen Schüler verschiedener Altersklassen die Möglichkeit erhalten, Seminare zu den Themen Robotik, Microcontroller oder Automation zu belegen, um beispielsweise zu lernen, wie sie eigene Ideen entwickeln und entsprechende Fachsprachen einsetzen können.
<G-vec00042-001-s318><attend.belegen><en> It goes without saying that you are free to choose and attend those lectures that suit you personally in every phase of your study, when the learning content and objectives are particularly relevant or interesting for you.
<G-vec00042-001-s318><attend.belegen><de> Natürlich können Sie in jeder Phase Ihres Studiums das für Sie persönlich passende Veranstaltungsangebot wählen und belegen, wenn die Lerninhalte und -ziele für Sie besonders relevant oder interessant sind.
<G-vec00301-001-s319><attend.besuchen><en> This enables him to attend the Technical School in Dresden and thus receive an education that is usually only bestowed upon engineers and technicians at the time.
<G-vec00301-001-s319><attend.besuchen><de> "Diese ermöglicht ihm den Besuch der ""Technischen Bildungsanstalt"" in Dresden und damit eine Ausbildung, wie sie damals gewöhnlich nur einem Ingenieur oder Techniker zuteil wird."
<G-vec00301-001-s320><attend.besuchen><en> Students who are entirely unable to attend any lectures over a prolonged period on important grounds (illness, accident, maternity, work placement, military or civil service) can be granted a leave of absence by the responsible Dean's office upon written request.
<G-vec00301-001-s320><attend.besuchen><de> Studierende, die aus wichtigen Gründen (Krankheit, Unfall, Mutterschaft, Praktika, Militärdienst oder Zivildienst) während längerer Zeit am Besuch der Lehrveranstaltungen vollständig verhindert sind, können auf ein schriftliches Gesuch hin vom zuständigen Dekanat beurlaubt werden.
<G-vec00301-001-s321><attend.besuchen><en> I pray specially for priests now, especially when I attend the Mass daily.
<G-vec00301-001-s321><attend.besuchen><de> Ich bete jetzt besonders für Priester, speziell beim Besuch der täglichen Heiligen Messe.
<G-vec00301-001-s322><attend.besuchen><en> In order to allow children to attend school, even though some of their parents are not able to cover the school fee, the initiative keeps on searching for donations and educational sponsorships.
<G-vec00301-001-s322><attend.besuchen><de> Um auch Kindern, deren Eltern die Schulgelder nicht bezahlen können, den Besuch der Schule Cruz del Sur ermöglichen zu können, werden Patenschaften gesucht.
<G-vec00301-001-s323><attend.besuchen><en> During his studies, an Erasmus/Socrates Scholarship allowed him to attend the École Nationale Supérieure des Beaux-Arts in Paris for twelve months.
<G-vec00301-001-s323><attend.besuchen><de> Während seiner Studienzeit ermöglichte ihm das Erasmus/Sokrates-Stipendium einen zwölfmonatigen Besuch der École Nationale Supérieure des Beaux-Arts in Paris.
<G-vec00301-001-s324><attend.besuchen><en> Data processing when re-personalizing personalized tickets When you purchased a personalized ticket and transferred the right to attend the event to a third party (assignment), the name of the third party must be noted on the ticket (re-personalization) so that he or she will be granted entrance to the booked event.
<G-vec00301-001-s324><attend.besuchen><de> "Datenverarbeitung bei der Umpersonalisierung personalisierter Tickets Wenn Sie ein personalisiertes Ticket gekauft haben und das Recht zum Besuch der Veranstaltung auf einen Dritten übertragen haben (Abtretung), muss der Name des Dritten auf dem Ticket vermerkt werden (""Umpersonalisierung""), damit dieser Einlass in die gebuchte Veranstaltung erhält."
<G-vec00301-001-s325><attend.besuchen><en> After Mr. Bai was forced to attend brainwashing sessions and detained in the Macheng No. 1 Detention Centre for a year, he was sentenced to four years in prison.
<G-vec00301-001-s325><attend.besuchen><de> Nachdem Herr Bai zum Besuch der Gehirnwäschekurse gezwungen worden und für ein Jahr im Macheng Gefängnis Nr.1 eingesperrt war, wurde er zu vier Jahren Gefängnis verurteilt.
<G-vec00301-001-s326><attend.besuchen><en> This collaboration between Roche and the Salzburg Festival will primarily allow European university and college students to attend contemporary music events in Salzburg, and will attempt to uncover the link between innovation in music and art on the one hand and science on the other.
<G-vec00301-001-s326><attend.besuchen><de> Die Zusammenarbeit von Roche und den Salzburger Festspielen ermöglicht vor allem Jugendlichen aus europäischen Hochschulen den Besuch von Veranstaltungen zeitgenössischer Musik in Salzburg und versucht eine Verbindung zwischen Innovationen in Kunst und Musik einer- und Naturwissenschaften anderseits aufzuzeigen.
<G-vec00301-001-s327><attend.besuchen><en> Attend all cases of psychopathological diseases incurred and porhaber, we are a team working for their welfare in the city of tacna.
<G-vec00301-001-s327><attend.besuchen><de> Besuch aller fälle von psychopathologischen erkrankungen entstehen und porhaber, wir sind ein team für ihr wohlergehen in der stadt tacna.
<G-vec00301-001-s328><attend.besuchen><en> Jewish youths were forbidden attend to higher schools, the systematic plundering of the propertied class began.
<G-vec00301-001-s328><attend.besuchen><de> Jüdischen Jugendlichen wurde der Besuch von höheren Schulen verboten, die systematische Ausplünderung der Besitzenden begann.
<G-vec00301-001-s329><attend.besuchen><en> Once issued, a media accreditation is non-transferable and entitles the holder (i) to occupy and use a working space on the post match press stand, (ii) to access the mixed zone after the match, and (iii) to attend the press conference, subject to space restrictions.
<G-vec00301-001-s329><attend.besuchen><de> Eine Akkreditierung im Bereich MEDIEN hat nur für die antragstellende Person Gültigkeit, d.h. ist personengebunden und damit nicht übertragbar, und berechtigt ausschließlich zur Nutzung eines von dem Club zugeteilten Arbeitsplatzes auf der Pressetribüne sowie nach Spielende - je nach Kapazität - auch zum Zutritt zur Mixed-Zone und zum Besuch der Pressekonferenz.
<G-vec00301-001-s330><attend.besuchen><en> It enables children from the poorest families to attend nursery and primary school free of cost.
<G-vec00301-001-s330><attend.besuchen><de> Sie ermöglicht Kindern aus den ärmsten Familien den kostenlosen Besuch des Kindergartens und der Primarschule.
<G-vec00301-001-s331><attend.besuchen><en> Visitors are also encouraged to attend the knight camp and medieval market.
<G-vec00301-001-s331><attend.besuchen><de> Sehr zu empfehlen ist auch ein Besuch des Ritterlagers und des mittelalterlichen Markts.
<G-vec00301-001-s332><attend.besuchen><en> In order to truly live this ideal and to allow children everywhere in this world to attend school, it is important to remind us of this essential impulse by reaching out to one another beyond national borders – from one continent to another, from one human being to another.
<G-vec00301-001-s332><attend.besuchen><de> Um dieses Ideal wirklich zu leben und Kindern überall auf der Welt den Besuch einer Schule zu ermöglichen, ist es wichtig, dass wir uns an diesen wesentlichen Impuls erinnern und uns über Landesgrenzen hinaus einander helfend die Hände reichen – von Kontinent zu Kontinent, von Kultur zu Kultur, von Mensch zu Mensch.
<G-vec00301-001-s333><attend.besuchen><en> This common language is the prerequisite for going on to attend secondary schools, which is funded in Togo by the state and by charitable means.
<G-vec00301-001-s333><attend.besuchen><de> Die gemeinsame Sprache ist die Voraussetzung für den Besuch weiterführender Schulen, die durch staatliche und karitative Träger in Togo angeboten werden.
<G-vec00301-001-s334><attend.besuchen><en> It is hereby made clear for the above case that this is not a transfer of the contract with the event organizer (Clause 11.1.), and that solely the right to attend the event is transferred as provided for in Clause 10.1.
<G-vec00301-001-s334><attend.besuchen><de> Wir werden die von Ihnen hochgeladenen Daten unverzüglich wieder löschen, wenn die Umpersonalisierung abgeschlossen ist.Für diesen Fall wird klargestellt, dass es sich hierbei nicht um eine Übertragung des Vertrags mit dem Veranstalter (Ziffer 11.1) handelt, sondern es wird lediglich das Recht zum Besuch der Veranstaltung übertragen, wie in Ziffer 10.1 geregelt.
<G-vec00301-001-s335><attend.besuchen><en> A few individuals called for Jews to be compelled to attend Protestant preaching services.
<G-vec00301-001-s335><attend.besuchen><de> Vereinzelt wurde gefordert, Juden sollten zum Besuch evangelischer Predigtgottesdienste gezwungen werden.
<G-vec00301-001-s336><attend.besuchen><en> "Called ""law on parental responsibility"", the law, promoted by the government, declares it illegal to make children attend assemblies and places of worship or religious schools which are not recognized by the state."
<G-vec00301-001-s336><attend.besuchen><de> "Das neue Gesetz, das auch als ""Gesetz über die Verantwortlichkeit der Eltern"" genannt wird, verbietet Kindern und Jugendlichen den Besuch von Orten oder Versammlungen sowie von Religionsschulen, die nicht vom Staat anerkannt werden."
<G-vec00301-001-s337><attend.besuchen><en> A fun thing to do in Paris at night is attend a comedy show.
<G-vec00301-001-s337><attend.besuchen><de> Der Besuch einer Comedy-Show in Paris verspricht Spaß pur.
<G-vec00042-001-s338><attend.besuchen><en> Attend the wedding on the SUMMER level.
<G-vec00042-001-s338><attend.besuchen><de> Besuche die Hochzeit im Level „Sommer“.
<G-vec00042-001-s339><attend.besuchen><en> If you would like to know more, simply attend one of our career information days held in spring at several locations across Switzerland for a range of apprenticeship trades.
<G-vec00042-001-s339><attend.besuchen><de> Wenn du es genauer wissen willst, besuche einen unserer Schnupperinfotage, die wir im Frühjahr an verschiedenen Standorten in der Schweiz und für unterschiedliche Lehrberufe anbieten.
<G-vec00042-001-s340><attend.besuchen><en> I attend a special class in physics.
<G-vec00042-001-s340><attend.besuchen><de> Ich besuche in einer Spezialklasse ür Physik.
<G-vec00042-001-s341><attend.besuchen><en> Now I believe in God but I don't attend church on a regular basis, but pray every night and I'm thankful for my kids and wife and my career.
<G-vec00042-001-s341><attend.besuchen><de> Jetzt glaube ich an Gott aber ich besuche die Kirche nicht regelmäßig, bete aber jeden Abend und bin dankbar für meine Kinder meine Frau und meine Karriere.
<G-vec00042-001-s342><attend.besuchen><en> Comments: Learn Italian in a pleasant and relaxing environment and attend a wide variety of cultural activities.
<G-vec00042-001-s342><attend.besuchen><de> Kommentar: Lerne Italienisch in einer angenehmen und entspannenden Umgebung und besuche eine Vielzahl von kulturellen Aktivitäten.
<G-vec00042-001-s343><attend.besuchen><en> A Research Training Group (RTG) is expected to maintain close contacts with researchers in other countries, invite visiting researchers from abroad, recruit doctoral researchers internationally and allow them to spend time working abroad and attend international conferences.
<G-vec00042-001-s343><attend.besuchen><de> Von einem Graduiertenkolleg (GRK) wird erwartet, dass es enge Kontakte ins Ausland pflegt, Gastwissenschaftlerinnen und Gastwissenschaftler aus dem Ausland einlädt, Promovierende international rekrutiert und ihnen Auslandsaufenthalte und Besuche von internationalen Konferenzen ermöglicht.
<G-vec00042-001-s344><attend.besuchen><en> "Good evening, I don't ""I attend"" These sites you don Ariel and I did not mention the time and brainpower in order to form an opinion."
<G-vec00042-001-s344><attend.besuchen><de> "guten Abend, Ich glaube nicht, ""ich besuche"" diese Websites, die Sie don erwähnt Ariel und ich habe die Zeit und intellektuelle Fähigkeiten beurteilen zu können,."
<G-vec00042-001-s345><attend.besuchen><en> I attend at least two major training courses to enhance my skills each year; in 2017, I even took part in five.
<G-vec00042-001-s345><attend.besuchen><de> Ich besuche mindestens zwei große Lehrgänge zur Kompetenzsteigerung pro Jahr, 2017 Jahr waren es sogar fünf.
<G-vec00042-001-s346><attend.besuchen><en> I attend the Free Waldorf School in Dresden.
<G-vec00042-001-s346><attend.besuchen><de> Ich besuche die Freie Waldorfschule Dresden.
<G-vec00042-001-s347><attend.besuchen><en> I attend the vocational school in Plön and am currently doing my professional education with a training as a commercial assistant.
<G-vec00042-001-s347><attend.besuchen><de> Ich besuche die Berufsschule in Plön und mache momentan mein Fachabitur mit einer Ausbildung zur kaufmännischen Assistentin.
<G-vec00042-001-s348><attend.besuchen><en> "During the semester, I go to school just like the ""regular"" students and attend lectures."
<G-vec00042-001-s348><attend.besuchen><de> "Während des Semesters bin ich genauso wie ""normale"" Studenten an der Hochschule und besuche die Vorlesungen."
<G-vec00042-001-s349><attend.besuchen><en> The plan was to attend a language school for two weeks, and after that volunteer in an orphanage for four and a half months.
<G-vec00042-001-s349><attend.besuchen><de> Geplant war, dass ich zwei Wochen eine Sprachschule besuche und danach viereinhalb Monate eine Freiwilligenarbeit in einem Waisenheim mache.
<G-vec00042-001-s350><attend.besuchen><en> God’s love for His children is not based on the number of times they attend formal services.
<G-vec00042-001-s350><attend.besuchen><de> Gottes Liebe für seine Kinder basiert nicht auf der Anzahl der Besuche des Gottesdienstes.
<G-vec00042-001-s351><attend.besuchen><en> In the rehearsal I attend, they work on a scene where the Baron's lame daughter, Edith von Kekesfalva, tries to walk.
<G-vec00042-001-s351><attend.besuchen><de> In der Probe, die ich besuche, arbeitet die Gruppe gerade an einer Szene, in der Edith von Kekesfalva, die lahme Tochter des Barons, zu laufen versucht.
<G-vec00042-001-s352><attend.besuchen><en> I attend the parish, not only Sunday Mass, but also various meetings, catechesis, etc..
<G-vec00042-001-s352><attend.besuchen><de> Ich besuche die Pfarrei, nicht nur die Sonntagsmesse, sondern auch verschiedene Sitzungen, Katechese, usw..
<G-vec00042-001-s353><attend.besuchen><en> Attend one of the many freestyle camps – you'll be amazed how quickly you make progress.
<G-vec00042-001-s353><attend.besuchen><de> Besuche eines der vielen Freestylecamps - du wirst sehen, wie schnell du Fortschritte machst.
<G-vec00042-001-s354><attend.besuchen><en> I usually attend many meetups in Berlin, and the city is very active in this way.
<G-vec00042-001-s354><attend.besuchen><de> Ich besuche regelmäßig Meetups in Berlin – die Stadt ist sehr aktiv in diesem Bereich.
<G-vec00042-001-s355><attend.besuchen><en> Attend public concerts, parties, celebratory events, and feasts for Diwali.
<G-vec00042-001-s355><attend.besuchen><de> Besuche öffentliche Konzerte, Feste, Feierlichkeiten und Festessen für Diwali.
<G-vec00042-001-s356><attend.besuchen><en> I am 17 years old from Salzburg in Austria. I attend a trade school for sports and this is now my third year in the Red Bull Rookies Cup.
<G-vec00042-001-s356><attend.besuchen><de> Lukas Trautmann: Ich bin 17 Jahre, aus Salzburg in Österreich, besuche eine Handelsschule für Sport und fahre jetzt im dritten Jahr den Red Bull Rookies Cup.
<G-vec00042-001-s357><attend.besuchen><en> In addition to that, international degree-seeking students are welcome to also attend the regular Orientation Weeks, organised by the respective faculty student representative committees.
<G-vec00042-001-s357><attend.besuchen><de> Alle internationalen Vollzeitstudierenden sind außerdem herzlich eingeladen, zusätzlich die regulären Orientierungswochen zu besuchen, die von den jeweiligen Fachschaften organisiert werden.
<G-vec00042-001-s358><attend.besuchen><en> 37% of pupils in Austria at the upper secondary level attend a vocational school (OECD: 31%), 33% are involved in apprenticeship training (OECD: 13%). The remaining 30% (OECD: 56%) are getting a general education in the upper grades of an academic secondary school.
<G-vec00042-001-s358><attend.besuchen><de> 37 Prozent der Schülerinnen und Schüler besuchen in Österreich in der Sekundarstufe II demnach eine berufsbildende Schule (OECD: 31 Prozent), 33 Prozent machen eine Lehre (OECD: 13 Prozent).
<G-vec00042-001-s359><attend.besuchen><en> You are strongly advised to check the dates of the event you plan to attend before you book a hotel or rent a car in Cherbourg.
<G-vec00042-001-s359><attend.besuchen><de> Wier empfehlen nachdrücklich die Termindaten der Veranstaltung die Sie besuchen möchten zu überprüfen, bevor Sie ein Hotel oder ein Auto in Cherbourg mieten.
<G-vec00042-001-s360><attend.besuchen><en> "HFF students can attend courses offered by the TUM Language Center in 17 languages, either to prepare for planned stays abroad or to deepen their knowledge of German through ""German as a foreign language"" courses."
<G-vec00042-001-s360><attend.besuchen><de> "So können die Studierenden der HFF Lehrveranstaltungen aus dem Angebot des TUM Sprachenzentrums besuchen, um sich entweder gezielt auf geplante Auslandsaufenthalte vorzubereiten oder mittels Lehrveranstaltungen ""Deutsch als Fremdsprache"" ihre Deutschkenntnisse zu vertiefen."
<G-vec00042-001-s361><attend.besuchen><en> Also, in the case of teachers who attend the course, tools will be provided them so that they can teach their students these techniques from personal experience.
<G-vec00042-001-s361><attend.besuchen><de> Auch werden bei Lehrern, die den Kurs besuchen, Werkzeuge ihnen vorgesehen sein, dass sie ihren Schülern diese Techniken aus eigener Erfahrung beibringen können.
<G-vec00042-001-s362><attend.besuchen><en> So instead of spending the evening fly-hunting in our hotel, it had seemed to be a much better decision to attend Valkyrien Allstars concert in Sandane.
<G-vec00042-001-s362><attend.besuchen><de> Anstatt also den Abend mit Fliegenjagd in unserem Hotel zu verbringen, erschien es viel sinnvoller, das Konzert von Valkyrien Allstars in Sandane zu besuchen.
<G-vec00042-001-s363><attend.besuchen><en> Grab a free show at Central Park, attend a gospel celebration in Harlem or head to Long Island City for a rooftop party at MoMa PS1.
<G-vec00042-001-s363><attend.besuchen><de> Besuchen Sie per Fahrrad eine kostenlose Show im Central Park, eine Gospelfeier in Harlem oder eine Dachparty im MoMa PS1 in Long Island City.
<G-vec00042-001-s364><attend.besuchen><en> The first big event for Airwheel self-balancing electric scooter in 2016 is to attend the Consumer Electronics Show, held in Las Vegas, from 6th to 9th, Jan, 2016.
<G-vec00042-001-s364><attend.besuchen><de> Die erste große Veranstaltung für Airwheel Balance Elektroroller im Jahr 2016 soll der Consumer Electronics Show in Las Vegas, vom 6. bis 9., Jan, 2016 ausgetragen zu besuchen.
<G-vec00042-001-s365><attend.besuchen><en> On the basis of the various different study structures, each departmentwill use the existing concept to define the study elements students can attend in order to gain portfolio points for the certificate.
<G-vec00042-001-s365><attend.besuchen><de> Aufgrund der unterschiedlichen Studienstrukturen wird jedes Departement anhand des vorliegenden Konzepts die Elemente definieren, die Studierenden besuchen können, um Portfoliopunkte für das Zertifikat zu sammeln.
<G-vec00042-001-s366><attend.besuchen><en> Evening on the balcony of the Town Hall are free Christmas concerts, and a day with their children can attend the lessons of baking delicious Bavarian cookies.
<G-vec00042-001-s366><attend.besuchen><de> Abend auf dem Balkon des Rathauses sind frei Weihnachtskonzerte, und einen Tag mit ihren Kindern können die Lektionen der Backen köstliche bayerische Cookies besuchen.
<G-vec00042-001-s367><attend.besuchen><en> In Ontario alone, there are about more than 650 To attend courses.
<G-vec00042-001-s367><attend.besuchen><de> Alleine in Ontario etwa gibt es mehr als 650 Golfplätze zu besuchen .
<G-vec00042-001-s368><attend.besuchen><en> Thanks to its proximity, this is a great opportunity for MachinePoint to focus on the Spanish customers and present them the latest news on used machinery for this market. “The meetings with the OEMs were productive as we could meet new ones and attend their requests and offers”, said the responsible for the injection moulding department in Spain, at EQUIPLAST.
<G-vec00042-001-s368><attend.besuchen><de> """Die Treffen mit den OEMs produktiv waren, wie wir neue treffen könnten und besuchen ihre Anfragen und Angebote"", sagte der verantwortlich für die Spritzgussabteilung in Spanien, bei EQUIPLAST."
<G-vec00042-001-s369><attend.besuchen><en> """People who have anxiety, they can't attend places like that."
<G-vec00042-001-s369><attend.besuchen><de> “Menschen, die unter Ängsten leiden, können solche Orte oft nicht besuchen.
<G-vec00042-001-s370><attend.besuchen><en> If you are going to attend a wedding ceremony as the guest or the mother of the brides, you have to take good use of this dress's mermaid silhouette and the floor-length full of elegance.
<G-vec00042-001-s370><attend.besuchen><de> Wenn Sie vorhaben, eine Hochzeitsfeier als Gast oder die Mutter der Braut zu besuchen sind, haben Sie für einen guten Zweck dieses Kleid ist Meerjungfrau Silhouette und die bodenlange voller Eleganz zu nehmen.
<G-vec00042-001-s371><attend.besuchen><en> Lastly, experience the 'Art Gallery' packed with sculptures, paintings and photographs that change with the seasons, and attend exhibitions to discover or rediscover all the secrets of current artists.
<G-vec00042-001-s371><attend.besuchen><de> Zudem können Sie sich die Galerie mit zahlreichen Skulpturen, Gemälden und Fotos anschauen, die je nach Jahreszeit wechseln, sowie Ausstellungen besuchen, um die Geheimnisse heutiger Künstler zu entdecken.
<G-vec00042-001-s372><attend.besuchen><en> In Istria and on Kvarner islands, the Croats and Slovenians (the majority peoples) were allowed to attend secondary school in their mother tongues.
<G-vec00042-001-s372><attend.besuchen><de> In Istrien und auf den Kvarner Inseln war es den Kroaten und Slowenen (mehrheitliche Bevölkerung), die Mittelschule auf der Muttersprache zu besuchen.
<G-vec00042-001-s373><attend.besuchen><en> Designers are trained in the in-house training facility and attend vocational school for a maximum of two days a week.
<G-vec00042-001-s373><attend.besuchen><de> Konstrukteure/ -innen werden im Ausbildungsbetrieb ausgebildet und besuchen während maximal zwei Tagen pro Woche die Berufsschule.
<G-vec00042-001-s374><attend.besuchen><en> Learning blackjack dealing from a casino school is not compulsory, as casinos do not actually require you to attend a private dealer school.
<G-vec00042-001-s374><attend.besuchen><de> Apprentissage Blackjack sich von einem Glücksspiel Schule nicht unbedingt erforderlich ist, Casinos da zu keinem Zeitpunkt im Wesentlichen verlangen, dass Sie zu einem privaten Händler Schule zu besuchen.
<G-vec00042-001-s375><attend.besuchen><en> MindZoom mingles in your own time. This means no extra time to listen to CDs on a relaxed state, or attend Therapies or Hypnosis sessions.
<G-vec00042-001-s375><attend.besuchen><de> Das bedeutet, dass keine zusätzliche Zeit benötigt wird, um CDs in einem entspannten Zustand zu hören oder Therapien oder Hypnose-Sessions zu besuchen.
<G-vec00042-001-s376><attend.besuchen><en> Attend our monthly events and activities for Beijing expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s376><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Beijing, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s377><attend.besuchen><en> "Enjoy Hamburg by night on the famous ""Reeperbahn"" street or attend to one of the musicals, festivals or events taking place throughout the year."
<G-vec00042-001-s377><attend.besuchen><de> Genießen Sie Hamburg bei Nacht auf der berühmten Reeperbahn oder besuchen Sie eines der Musicals, Festivals oder Events, welche über das ganze Jahr hinweg stattfinden.
<G-vec00042-001-s378><attend.besuchen><en> Attend our monthly events and activities for Birmingham expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s378><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Birmingham, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s379><attend.besuchen><en> Attend our monthly events and activities for Perth expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s379><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Perth, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s380><attend.besuchen><en> Attend a brief update training course and save valuable working time.
<G-vec00042-001-s380><attend.besuchen><de> Besuchen Sie ein kompaktes Update Training und sparen dadurch wertvolle Arbeitszeit.
<G-vec00042-001-s381><attend.besuchen><en> Come admire a sunset with oyster tasting on the island of Fort Brescou, attend a fireworks display or discover our territory during a guided walk...
<G-vec00042-001-s381><attend.besuchen><de> Bewundern Sie einen Sonnenuntergang mit einer Austernverkostung auf der Insel Fort Brescou, besuchen Sie ein Feuerwerk oder entdecken Sie unser Gebiet während einer geführten Wanderung...
<G-vec00042-001-s382><attend.besuchen><en> Attend our monthly events and activities for Jerusalem expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s382><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Jerusalem, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s383><attend.besuchen><en> Attend a winter soiree in our Judy Mosaic Pieced Mink Bomber Jacket in Whiskey Ombre for women from Fur Hat World.
<G-vec00042-001-s383><attend.besuchen><de> Besuchen Sie eine Winter-Soiree in unserer Judy Mosaik zusammengesetzt Nerz Bomberjacke in Whiskey Ombre für Frauen aus Pelz Hut Welt.
<G-vec00042-001-s384><attend.besuchen><en> Attend productronica 2019 and profit from its unique atmosphere.
<G-vec00042-001-s384><attend.besuchen><de> Besuchen Sie die productronica 2019 und profitieren von einem einmaligen Umfeld.
<G-vec00042-001-s385><attend.besuchen><en> Attend our monthly events and activities for Raleigh expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s385><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Raleigh, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s386><attend.besuchen><en> Attend the center image, souks 211, corner arauco, ovalle.
<G-vec00042-001-s386><attend.besuchen><de> Besuchen sie das zentrum bild, souks 211, ecke arauco, ovalle.
<G-vec00042-001-s387><attend.besuchen><en> Attend our monthly events and activities for Kuala Lumpur expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s387><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Kuala Lumpur, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s388><attend.besuchen><en> Then attend the extravagant midday ceremony to witness how the Cao Dai followers conduct daily mass.
<G-vec00042-001-s388><attend.besuchen><de> Besuchen Sie dann die extravagante Mittagszeremonie, um zu sehen, wie die Anhänger von Cao Dai ihre tägliche Messe abhalten.
<G-vec00042-001-s389><attend.besuchen><en> Attend one of them and discover Maribor and its surroundings from a completely different angle.
<G-vec00042-001-s389><attend.besuchen><de> Besuchen Sie einen von ihnen und entdecken Sie Maribor und seine Umgebung aus einem ganz anderen Gesichtspunkt.
<G-vec00042-001-s390><attend.besuchen><en> Attend our monthly events and activities for Genoa expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s390><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Genoa, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s391><attend.besuchen><en> Attend our monthly events and activities for Groningen expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s391><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Groningen, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s392><attend.besuchen><en> Attend our monthly events and activities for Blantyre expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s392><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Blantyre, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s393><attend.besuchen><en> "Enjoy the "" route of the white villages "" (Ronda, 120 kms) or attend Malaga (230 kms) or Alhambra in Granada (320 kms)."
<G-vec00042-001-s393><attend.besuchen><de> "Genießen Sie die ""Route der weißen Dörfer"" (Ronda, 120 Km) oder besuchen Sie Malaga (230 Km) oder die Alhambra in Granada (320 Km)."
<G-vec00042-001-s394><attend.besuchen><en> Attend our monthly events and activities for Liverpool expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s394><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Liverpool, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s395><attend.besuchen><en> In response, Van Doesburg organizes a course on De Stijl in his own studio in Weimar, which many Bauhaus students attend. … to Paris After this, Van Doesburg leaves for Paris.
<G-vec00042-001-s395><attend.besuchen><de> "Van Doesburg reagiert darauf, indem er in seinem eigenen Atelier in Weimar einen Kurs über ""De Stijl"" organisiert, der von vielen Bauhaus/Studenten besucht wird.... nach Paris Danach verlässt Van Doesburg Weimar und zieht Richtung Paris."
<G-vec00042-001-s396><attend.besuchen><en> Art lovers, each year, Space Rohan offers colorful cultural season, during which you will be given to attend various theatrical performances.
<G-vec00042-001-s396><attend.besuchen><de> Kunstliebhaber, jedes Jahr Space Rohan bietet farbenfrohe kulturelle Saison, während die euch gegeben, verschiedene Theateraufführungen besucht werden.
<G-vec00042-001-s397><attend.besuchen><en> In Turkey, Malteser International is also supporting a school in the border district of Kilis, at the Syrian border, where 1,350 Syrian children currently attend classes.
<G-vec00042-001-s397><attend.besuchen><de> In der Türkei finanziert Malteser International eine Schule im Distrikt Killis, an der Grenze zu Syrien, die von 1.350 syrischen Kindern besucht wird.
<G-vec00042-001-s398><attend.besuchen><en> There are far less private schools than public schools in Bulgaria and only a small percentage of students attend them.
<G-vec00042-001-s398><attend.besuchen><de> Es gibt weit weniger Privatschulen als öffentliche Schulen in Bulgarien und nur ein kleiner Prozentsatz der Schüler besucht sie.
<G-vec00042-001-s399><attend.besuchen><en> The special ten minute programme was free to attend and took place over three nights in May 2016.
<G-vec00042-001-s399><attend.besuchen><de> Das zehnminütige Programm konnte an drei Abenden im Mai 2016 kostenlos besucht werden.
<G-vec00042-001-s400><attend.besuchen><en> André Rieu polo shirt If you regularly attend André's concerts, you will certainly have noticed the staff members who make sure that everything is in order behind the scenes.
<G-vec00042-001-s400><attend.besuchen><de> André Rieu polo shirt Wer regelmäßig ein André Rieu-Konzert besucht, dem sind sie bestimmt schon aufgefallen - die vielen hilfreichen Mitarbeiter, die hinter den Kulissen nichts dem Zufall überlassen.
<G-vec00042-001-s401><attend.besuchen><en> He added, however, that those entering the country would be thoroughly examined whether they had not violated the Ukrainian legislation at the time of their previous stay if they did not attend the territory temporarily occupied by Russia.
<G-vec00042-001-s401><attend.besuchen><de> Er fügte jedoch hinzu, dass die Einreise in das Land gründlich geprüft würde, ob sie bei ihrem vorherigen Aufenthalt nicht gegen die ukrainischen Rechtsvorschriften verstoßen hätten, wenn sie nicht das von Russland besetzte Gebiet besucht hätten.
<G-vec00042-001-s402><attend.besuchen><en> The multiplicity of the subjects taught at the Athenaeums and Study Centres that you attend intends to respond to this vast and urgent cultural and spiritual challenge.
<G-vec00042-001-s402><attend.besuchen><de> Die Vielfalt der Lehrinhalte, die euch in den Universitäten und Studienzentren, die ihr besucht, angeboten werden, will dazu beitragen, auf diese große und dringliche kulturelle und geistliche Herausforderung zu antworten.
<G-vec00042-001-s403><attend.besuchen><en> Of course there are requirements as to which courses you have to attend during a degree programme.
<G-vec00042-001-s403><attend.besuchen><de> Natürlich gibt es Vorgaben, welche Kurse im Verlauf eines Studiums besucht werden müssen.
<G-vec00042-001-s404><attend.besuchen><en> Generally, it seems that these children spend most of the Sunday in bed to recover from the week's exertion; only a few attend church and school, and teachers complain about drowsiness and dullness despite all the curiosity to learn. The same thing happens with older girls and women.
<G-vec00042-001-s404><attend.besuchen><de> Allgemein scheint es zu sein, daß diese Kinder den größten Teil des Sonntags im Bette zubringen, um sich einigermaßen von der Anstrengung der Woche zu erholen; Kirche und Schule werden nur von wenigen besucht, und bei diesen klagen die Lehrer über große Schläfrigkeit und Abstumpfung bei aller Lernbegierde.
<G-vec00042-001-s405><attend.besuchen><en> In all other Polish elementary schools, which the German school children necessarily also had to attend, Protestant religious education classes were the only opportunity to give the German children any instruction in their mother tongue.
<G-vec00042-001-s405><attend.besuchen><de> An allen anderen polnischen Volksschulen, die auch von den deutschen Schulkindern besucht werden mussten, war die Erteilung des evangelischen Religionsunterrichts die einzige Möglichkeit, die deutschen Kinder in ihrer Muttersprache notdürftig zu unterweisen.
<G-vec00042-001-s406><attend.besuchen><en> Some 25% of children in rural areas of the less developed world did not attend school in 2005/2006.
<G-vec00042-001-s406><attend.besuchen><de> Rund 25% der Kinder in ländlichen Gebieten weniger entwickelter Länder haben die Schule 2005/06 nicht besucht.
<G-vec00042-001-s407><attend.besuchen><en> If there's only one event to attend this year, it is this one so you don't want to miss IDEA.
<G-vec00042-001-s407><attend.besuchen><de> Wer dieses Jahr nur eine Veranstaltung besucht, der wird die IDEA auf keinen Fall verpassen wollen.
<G-vec00042-001-s408><attend.besuchen><en> On New Year's Eve, people host guests at home, meet up in restaurants, attend special gala dances and enjoy lively concerts.
<G-vec00042-001-s408><attend.besuchen><de> Am Silvesterabend lädt man Gäste zu sich nach Hause ein, trifft sich in Restaurants, besucht Tanzveranstaltungen und genießt beschwingende Konzerte.
<G-vec00042-001-s409><attend.besuchen><en> Throughout the training you attend classes at the Technischen Berufsschule [technical vocational college] 1 in Bochum.
<G-vec00042-001-s409><attend.besuchen><de> In der gesamten Zeit der Ausbildung besucht man den Unterricht an der Technischen Berufsschule 1 in Bochum.
<G-vec00042-001-s410><attend.besuchen><en> „I did not attend a higher scholl but the Great Spirit gave to me what I would not have learned in any class room (…).
<G-vec00042-001-s410><attend.besuchen><de> „Ich habe keine höhere Schule besucht, aber der Große Geist gab mir, was ich in keinem Klassenzimmer hätte lernen können (…).
<G-vec00042-001-s411><attend.besuchen><en> Suffice it to say, attend the camp and find out.
<G-vec00042-001-s411><attend.besuchen><de> Es sei hier lediglich gesagt, besucht das Camp und findet es heraus.
<G-vec00042-001-s412><attend.besuchen><en> As an Au Pair you live with a Japanese family, tend to their children and attend language courses.
<G-vec00042-001-s412><attend.besuchen><de> Als Au Pair lebt man in einer japanischen Familie, betreut deren Kinder und besucht Sprachkurse.
<G-vec00042-001-s413><attend.besuchen><en> Those who did attend the WSIS Summits in Geneva and Tunis indicated that the major and lasting benefit that they saw arising from their attendance was the networking opportunities that it afforded.
<G-vec00042-001-s413><attend.besuchen><de> Diejenigen, die die WSIS-Gipfel in Genf und Tunis besucht haben, erzählen, dass sie als wichtigsten und nachhaltigsten Vorteil die Möglichkeiten zum Vernetzen ansahen, die hier geboten wurden.
<G-vec00301-001-s414><attend.betreuen><en> TIGGES Rechtsanwälte attend to their clients personally and individually.
<G-vec00301-001-s414><attend.betreuen><de> TIGGES Rechtsanwälte betreuen Mandanten persönlich und individuell.
<G-vec00301-001-s415><attend.betreuen><en> Through the 2011 established overseas branch near Shanghai CSZ is optimally positioned on the ground as well as in Germany to attend western clients when realizing their ambitious building project in growth country China.
<G-vec00301-001-s415><attend.betreuen><de> Durch die 2011 gegründete Auslandsniederlassung bei Shanghai ist CSZ vor Ort und in Deutschland bestens aufgestellt, um westliche Kunden bei der Umsetzung Ihrer anspruchsvollen Bauvorhaben im Wachstumsland China zu betreuen.
<G-vec00301-001-s416><attend.betreuen><en> Interested retailers are gladly intermediated by us to our engaged customers, who are able to attend them locally and individually.
<G-vec00301-001-s416><attend.betreuen><de> Interessierte Einzelhändler vermitteln wir gerne an engagierte Kunden von uns weiter, die sie ortsnah und individuell betreuen können.
<G-vec00301-001-s417><attend.betreuen><en> We attend to customers in northern Germany from our offices at Hamburg and Kiel.
<G-vec00301-001-s417><attend.betreuen><de> Unsere norddeutschen Kunden betreuen wir aus Hamburg und Kiel.
<G-vec00301-001-s418><attend.betreuen><en> Our assistants are specially trained for this and attend you and your family carers discreetly and reliably within the region of Bad Godesberg and Bonn.
<G-vec00301-001-s418><attend.betreuen><de> Unsere speziell dafür ausgebildeten Mitarbeiter-/innen betreuen Sie und pflegende Angehörige im Raum Bad Godesberg und Bonn diskret und zuverlässig.
<G-vec00301-001-s419><attend.betreuen><en> Art experts from different countries and continents get the invitation to entrust artists, scientists and art scholars with contributions on the project’s topic and to attend to them as curators.
<G-vec00301-001-s419><attend.betreuen><de> KunstexpertInnen aus verschiedenen Ländern und Kontinenten erhalten die Einladung, auf der Basis einer vordefinierten Honorarstruktur KünstlerInnen, NaturwissenschaftlerInnen und GeisteswissenschaftlerInnen mit Beiträgen zum Projektthema zu betrauen und kuratorisch zu betreuen.
<G-vec00301-001-s420><attend.betreuen><en> Many speak different languages, and between us we are able to attend homeowners and buyers from many countries, always offering a personalised service focused on achieving the results you – as a vendor or a buyer – are looking for.
<G-vec00301-001-s420><attend.betreuen><de> Viele sprechen verschiedene Fremdsprachen, und insgesamt sind wir in der Lage, Eigenheimbesitzer und Käufer aus vielen Ländern zu betreuen, immer mit einem persönlichen Service und dem Fokus, die Ergebnisse zu erzielen, die Sie als Verkäufer oder Käufer – erwarten.
<G-vec00301-001-s421><attend.betreuen><en> The owners, Family Theile, attend personally to the guests and provide interesting information about life at the edge of the Namib Desert.
<G-vec00301-001-s421><attend.betreuen><de> Die Eigentümer, Familie Theile, betreuen die Gäste und vermitteln interressante Informationen über das Leben am Rande der Namibwüste.
<G-vec00301-001-s422><attend.betreuen><en> Employees can take up to ten days of leave at short notice in order to attend to family members at home.
<G-vec00301-001-s422><attend.betreuen><de> Kurzfristig können sich die Mitarbeiter bis zu zehn Tage freistellen lassen, um Familienmitglieder zuhause zu betreuen.
<G-vec00301-001-s423><attend.betreuen><en> Our sales representatives attend you on site and support our sales department in developing the optimal solution for you.
<G-vec00301-001-s423><attend.betreuen><de> Unsere Handelsvertreter betreuen Sie vor Ort und unterstützen unsere Vertriebsabteilung dabei, die optimale Lösung für Sie zu entwickeln.
<G-vec00301-001-s424><attend.betreuen><en> Simplify your supply chain by letting us take care of your hardware while you focus on your application and attend to your customers.
<G-vec00301-001-s424><attend.betreuen><de> Vereinfachen Sie Ihre Lieferkette, indem Sie uns die Sorge um Ihre Hardware überlassen, während Sie sich auf Ihre Anwendung fokussieren und Ihre Kunden betreuen.
<G-vec00301-001-s425><attend.betreuen><en> We personally attend to our customers.
<G-vec00301-001-s425><attend.betreuen><de> Wir betreuen unsere Kunden persönlich.
<G-vec00042-001-s426><attend.sein><en> Please recommend to people who just want to attend the concert have the utmost consideration to people attending the Pentads and do not occupy the temple until the Cults are completed.
<G-vec00042-001-s426><attend.sein><de> Bitte empfehlen für Leute, die nur das Konzert größtmögliche Berücksichtigung Leute, die die Pentaden haben dabei sein wollen und nicht besetzen den Tempel, bis die Cults abgeschlossen sind.
<G-vec00042-001-s427><attend.sein><en> Since that time he tries to attend the healing fires as often as possible.
<G-vec00042-001-s427><attend.sein><de> Jetzt versucht er aus eigenem Antrieb, so oft wie möglich, bei diesem heilenden Feuer dabei zu sein.
<G-vec00042-001-s428><attend.sein><en> Moving the tour to the middle of the event will allow many more people to attend and interact with one another.
<G-vec00042-001-s428><attend.sein><de> Durch die Verschiebung der Exkursion in die Mitte der Veranstaltung werden mehr Teilnehmer dabei sein und miteinander interagieren können.
<G-vec00042-001-s429><attend.sein><en> The children take part on their own, but parents are welcome to attend the final session.
<G-vec00042-001-s429><attend.sein><de> Die Kinder nehmen daran alleine teil, die Eltern können aber bei der Abschlussrunde dabei sein.
<G-vec00042-001-s430><attend.sein><en> I was 100% sure I wanted to attend the KTM ADVENTURE RALLY because I wanted to see the tracks in Sardinia.
<G-vec00042-001-s430><attend.sein><de> Ich wollte unbedingt bei der KTM ADVENTURE RALLY dabei sein, weil mich die Pfade Sardiniens reizten.
<G-vec00042-001-s431><attend.sein><en> Everyone can attend.
<G-vec00042-001-s431><attend.sein><de> Alle Menschen können dabei sein.
<G-vec00042-001-s432><attend.sein><en> Edith did not attend because both Margot and Grandmother Holländer were ill.
<G-vec00042-001-s432><attend.sein><de> Edith kann nicht dabei sein, weil Margot und Großmutter Holländer krank sind.
<G-vec00042-001-s433><attend.sein><en> BAHMUELLER looks very positive into the future and will attend the show again next year.
<G-vec00042-001-s433><attend.sein><de> BAHMÜLLER blickt sehr positiv in die Zukunft und wird auch im nächsten Jahr wieder dabei sein.
<G-vec00042-001-s434><attend.sein><en> I try to attend as many Falun Dafa activities as possible and tell people about Falun Dafa.
<G-vec00042-001-s434><attend.sein><de> Ich versuche bei so vielen Falun Dafa Aktivitäten, wie möglich dabei zu sein und den Leuten von Falun Dafa zu erzählen.
<G-vec00042-001-s435><attend.sein><en> UNIS Director Maher Nasser, Christoph Pinter from UNHCR Office Vienna and representatives of the Austrian permanent mission to the UN will attend the event.
<G-vec00042-001-s435><attend.sein><de> UNIS-Direktor Maher Nasser, Christoph Pinter vom UNHCR-Büro Wien und Vertreter der Ständigen Vertretung Österreichs bei den Vereinten Nationen werden mit dabei sein.
<G-vec00042-001-s436><attend.sein><en> Summary: Once again it was THE party of the year where every rocker just had to attend.
<G-vec00042-001-s436><attend.sein><de> Fazit: Auch dieses Jahr war es wieder DIE Party des Jahres, bei der jeder Rocker der Szene dabei sein musste.
<G-vec00042-001-s437><attend.sein><en> Another Yale alumnus, Minnesota Governor Mark Dayton, was supposed to attend but had a conflict.
<G-vec00042-001-s437><attend.sein><de> Eine weitere Yale Absolvent, Minnesota Gouverneur Mark Dayton, sollte dabei sein, hatte aber einen Konflikt.
<G-vec00042-001-s438><attend.sein><en> Ellen Page interrupted the current filming of the »Flatliners« remake in Toronto and headed back to the United States to attend the New York premiere of »Tallulah« on Tuesday.
<G-vec00042-001-s438><attend.sein><de> Ellen Page unterbrach am Dienstag die laufenden Dreharbeiten für das »Flatliners« Remake in Toronto und flog zurück in die Vereinigten Staaten um am Abend bei der New York Premiere von »Tallulah« dabei zu sein.
<G-vec00042-001-s439><attend.sein><en> I have crossed the border just once since the war started, to attend the funeral of my nephew, who was killed fighting for the Free Syrian Army in 2012.
<G-vec00042-001-s439><attend.sein><de> Seit der Krieg begann, habe ich die Grenze nur einmal überschritten, um beim Begräbnis meines Neffen dabei zu sein, der 2012 als Kämpfer für die Freie Syrische Armee getötet wurde.
<G-vec00042-001-s440><attend.sein><en> 100 % plan to attend the next event again.
<G-vec00042-001-s440><attend.sein><de> 100 % möchten beim nächsten Mal wieder dabei sein.
<G-vec00042-001-s441><attend.sein><en> I am happy to greet all the English-speaking pilgrims who have come to attend the Consistory, especially those from Iraq, Ireland, India, Kenya and the United States of America.
<G-vec00042-001-s441><attend.sein><de> … auf englisch: Es freut mich, alle englischsprachigen Pilger zu grüßen, die gekommen sind, um beim Konsistorium dabei zu sein, insbesondere jene aus dem Irak, Irland, Indien, Kenia und den Vereinigten Staaten von Amerika.
<G-vec00042-001-s442><attend.sein><en> Should you organize a flying day and need willing assistance, I would gladly attend with my Moth and other models.
<G-vec00042-001-s442><attend.sein><de> Sollten Sie mal in ein Flugtag organisieren und Sie suchen noch tatkräftige Unterstützung, würde ich sehr gerne mit meiner Motte und anderen Modellen dabei sein.
<G-vec00042-001-s443><attend.teilnehmen><en> The resort launched a new reef watch and regeneration initiative Project ’Coral Freedom’. All guests are invited to attend a seminar on the dangers of coral bleaching and divers get the chance to bring their ’coral karma’ back into balance by volunteering to help reef replanting and regeneration while diving some of Asia’s most spectacular spots.
<G-vec00042-001-s443><attend.teilnehmen><de> Alle Gäste können daran teilnehmen und sich Vorträge zu den Gefahren von Korallenbleichen anhören und Taucher haben die Möglichkeit ihr ‚Korallen Karma’ wiederherzustellen, indem sie bei der Neubepflanzung und Regeneration von Korallen mithelfen während sie die eindrucksvollsten Tauchgründe Asiens erkunden.
<G-vec00042-001-s444><attend.teilnehmen><en> Norbert Steiner, chairman of the Board of Executive Directors, as well as Joachim Felker and Jan Peter Nonnenkamp, both members of the Board of Executive Directors, will attend.
<G-vec00042-001-s444><attend.teilnehmen><de> Norbert Steiner, Vorsitzender des Vorstands sowie Joachim Felker und Jan Peter Nonnenkamp, Mitglieder des Vorstands, werden daran teilnehmen.
<G-vec00042-001-s445><attend.teilnehmen><en> Together with our official guests and those still planning to attend, the overall number of participants will be approx. 150.
<G-vec00042-001-s445><attend.teilnehmen><de> Zusammen mit unseren offiziellen Gästen und allen, die noch daran teilnehmen möchten, kommen wir auf eine Gesamtzahl von ungefähr 150 Teilnehmern.
<G-vec00042-001-s446><attend.teilnehmen><en> Not only fans from all over Europe but also officials of various host cities in Poland and Ukraine wanted to attend.
<G-vec00042-001-s446><attend.teilnehmen><de> Nicht nur Fans aus ganz Europa, sondern auch Offizielle der diversen Host Cities in Polen und der Ukraine wollten daran teilnehmen.
<G-vec00042-001-s447><attend.teilnehmen><en> Reservation is needed indicating date, time and number of guests who will attend.
<G-vec00042-001-s447><attend.teilnehmen><de> Reservation ist erforderlich Angabe von Datum, Uhrzeit und Anzahl der Gäste, die daran teilnehmen werden.
<G-vec00042-001-s448><attend.teilnehmen><en> The conference is usually held every summer, but this year, as there were many projects going on, it was moved to the end of September so that more practitioners could attend.
<G-vec00042-001-s448><attend.teilnehmen><de> Die Konferenz wird normalerweise jeden Sommer abgehalten, aber da dieses Jahr viele Projekte am Laufen waren, wurde sie auf Ende September verschoben, damit mehr Praktizierende daran teilnehmen konnten.
<G-vec00042-001-s449><attend.teilnehmen><en> When the children from our Minghui School learned that a cultivation experience sharing conference would be held in Taiwan, they were very excited and wanted to attend.
<G-vec00042-001-s449><attend.teilnehmen><de> Als die Kinder von unserer Minghui Schule erfuhren, dass eine Fa-Erfahrungsaustausch Konferenz in Taiwan abgehalten wird, waren sie sehr aufgeregt und wollten daran teilnehmen.
<G-vec00042-001-s450><attend.teilnehmen><en> The Cancer support group is meeting in the parish hall and is a great benefit to all who attend.
<G-vec00042-001-s450><attend.teilnehmen><de> Das Krebsunterstützungskonsortium trifft sich in der Gemeindehalle und ist von großem Nutzen aller, die daran teilnehmen.
<G-vec00042-001-s451><attend.teilnehmen><en> For example you may request information via a form, ask for support via “Contact Sales” forms or similar features, register or attend events or webinars, access or download certain content or participate in other interactions with us.
<G-vec00042-001-s451><attend.teilnehmen><de> So können Sie beispielsweise über ein Formular Informationen anfordern, über „Vertrieb kontaktieren“-Formulare oder ähnliche Funktionen den Support kontaktieren, sich für Veranstaltungen oder Webinare registrieren oder daran teilnehmen, auf bestimmte Inhalte zugreifen oder diese herunterladen oder anderweitig mit uns interagieren.
<G-vec00042-001-s452><attend.teilnehmen><en> As we didn't know who was going to attend, we were quite surprised to have an entire class of ten-year-old children, and not so many teachers.
<G-vec00042-001-s452><attend.teilnehmen><de> Da wir nicht wussten, wer daran teilnehmen würde, waren wir ganz überrascht, eine ganze Klasse zehnjähriger Kinder da zu haben und nicht viele Lehrer.
<G-vec00042-001-s453><attend.teilnehmen><en> He decided to attend and others could go if they wanted.
<G-vec00042-001-s453><attend.teilnehmen><de> Er möchte gerne daran teilzunehmen und schlug den anderen vor mitzukommen, wenn sie mögen.
<G-vec00042-001-s454><attend.teilnehmen><en> List management software company AWeber has some simple but effective ways to urge people who have registered for a free webinar to actually attend.
<G-vec00042-001-s454><attend.teilnehmen><de> AWeber, ein Software-Unternehmen für List Management, benutzt einfache aber sehr effektive Möglichkeiten, um Menschen, die sich für ein kostenloses Webinar angemeldet haben, dazu zu bringen, auch tatsächlich daran teilzunehmen.
<G-vec00042-001-s455><attend.teilnehmen><en> Secretary-General Ban Ki-moon plans to attend.
<G-vec00042-001-s455><attend.teilnehmen><de> Generalsekretär Ban Ki-moon plant, daran teilzunehmen.
<G-vec00042-001-s456><attend.teilnehmen><en> You are cordially invited to attend.
<G-vec00042-001-s456><attend.teilnehmen><de> Sie sind hiermit herzlich eingeladen, daran teilzunehmen.
<G-vec00042-001-s457><attend.teilnehmen><en> """I'm delighted with the seminar results: almost everybody who expressed an interest in coming to the event found the time and opportunity to attend."
<G-vec00042-001-s457><attend.teilnehmen><de> """Ich bin von den Ergebnissen des Seminars begeistert: Nahezu jeder, der zu dem Ereignis kommen wollte, fand die Zeit und die Möglichkeit, daran teilzunehmen."
<G-vec00042-001-s458><attend.teilnehmen><en> Systems 99 is going to have an area for linux people and they have invited Debian to attend.
<G-vec00042-001-s458><attend.teilnehmen><de> Die Systems 99 wird einen Bereich für Linux-Leute haben und sie haben Debian eingeladen daran teilzunehmen.
<G-vec00042-001-s459><attend.teilnehmen><en> All owners are welcome to attend.
<G-vec00042-001-s459><attend.teilnehmen><de> Alle Eigentümer sind eingeladen, daran teilzunehmen.
<G-vec00042-001-s460><attend.teilnehmen><en> After thinking more about this situation, I realized that since group study and group exercise were forms established by Master, I should really make an effort attend them.
<G-vec00042-001-s460><attend.teilnehmen><de> Als ich mehr über diese Situation nachdachte, erkannte ich, dass das gemeinsame Lernen und das gemeinsame Üben, Formen waren, die der Meister eingerichtet hat und ich sollte mir wirklich Mühe geben, daran teilzunehmen.
<G-vec00042-001-s461><attend.teilnehmen><en> You are not required to attend.
<G-vec00042-001-s461><attend.teilnehmen><de> Sie sind nicht verpflichtet, daran teilzunehmen.
<G-vec00042-001-s462><attend.teilnehmen><en> Mr. Shi's wife did not consent to the autopsy under these terms and refused to attend.
<G-vec00042-001-s462><attend.teilnehmen><de> Shis Ehefrau wollte unter diesen Bedingungen ihre Zustimmung für die Autopsie nicht geben und weigerte sich, daran teilzunehmen.
<G-vec00042-001-s501><attend.gehen><en> This year, additionally to our big trip, I want to at least attend two festivals, visit at least one more country and spend a few days of winter somewhere you can see the northern lights and where Caro can indulge in her Christmas addiction.
<G-vec00042-001-s501><attend.gehen><de> Ich möchte dieses Jahr, zusätzlich zu unserem Trip, noch auf mindestens zwei Festivals gehen, noch mindestens ein weiteres Land besuchen und im Winter ein paar Tage an einem Ort verbringen, wo dick Schnee liegt, die Nordlichter zu sehen sind und Caro ihrer Weihnachts-Addiction ausgiebig frönen kann.
<G-vec00042-001-s502><attend.gehen><en> To hear her talk of angels, punishment, forgiveness and his need to attend church most appear well founded allegations that Saul has moved in premiere, implying that is denying the past where we met her ’.
<G-vec00042-001-s502><attend.gehen><de> Zu der Engel sprechen hören, Strafe, Vergebung und sein Bedürfnis zur Kirche zu gehen, die meisten erscheinen begründet Behauptungen, die Saul in Uraufführung verschoben hat, Was bedeutet, die Vergangenheit zu leugnen ist wo wir haben sie getroffen ’.
<G-vec00042-001-s503><attend.gehen><en> My brother got a certificate for my mother, and I got one, because I was supposed to attend the Jerusalem Academy of Applied Arts, the Bezalel School.
<G-vec00042-001-s503><attend.gehen><de> Durch meinen Bruder hat meine Mutter ein Zertifikat bekommen und ich dadurch, dass ich in die Bezalel-Schule, das ist die Akademie für Kunst und Kunsthandwerk in Jerusalem, gehen sollte.
<G-vec00042-001-s504><attend.gehen><en> He did not start school in Hamburg, which likely had to do in part with his delayed development due to his disorder but also due, of course, to the fact that Jewish children were no longer allowed to attend school in the 1940s.
<G-vec00042-001-s504><attend.gehen><de> Eingeschult wurde er in Hamburg nicht, was vermutlich sowohl an seinem krankheitsbedingten Entwicklungsrückstand lag, aber natürlich auch daran, dass jüdische Kinder in den 1940er Jahren nicht mehr zur Schule gehen durften.
<G-vec00042-001-s505><attend.gehen><en> Around the world there are roughly 250,000 children whom armed groups have forced into service as soldiers; about 152 million children have to work and about 60 million children of primary school age are unable to attend school.
<G-vec00042-001-s505><attend.gehen><de> Weltweit werden etwa 250.000 Kinder von bewaffneten Gruppen als Kämpfer missbraucht, etwa 152 Millionen Kinder müssen arbeiten, mehr als 60 Millionen Kinder im Grundschulalter können nicht zur Schule gehen.
<G-vec00042-001-s506><attend.gehen><en> Since begin¬ning Miles had basically shelved these songs to attend school, focus on fatherhood, and commit to the demanding schedule of the F&O's.
<G-vec00042-001-s506><attend.gehen><de> Von Anfang an hatte MILES die Songs auf Halde gelegt, um weiter zur Uni zu gehen, sich auf seine Vaterschaft zu konzentrieren oder um all das zu erfüllen, was THE FRESH&ONLYS zu leisten hatten.
<G-vec00042-001-s507><attend.gehen><en> Many people attend a Christmas service.
<G-vec00042-001-s507><attend.gehen><de> Viele gehen zum Weihnachtsgottesdienst.
<G-vec00042-001-s508><attend.gehen><en> People start to talk only about this curse and attend church everyday to pray.
<G-vec00042-001-s508><attend.gehen><de> Die Menschen sprechen nur noch über diesen Fluch, gehen täglich in die Kirche und beten.
<G-vec00042-001-s509><attend.gehen><en> Peter-Michael Synek: Browsing the Hannover Messe today you will notice companies that didn't attend previously, especially IT companies.
<G-vec00042-001-s509><attend.gehen><de> Peter-Michael Synek: Wenn Sie heute beispielsweise über die Hannover Messe gehen, bemerken Sie Unternehmen, die früher nicht da waren, besonders IT-Unternehmen.
<G-vec00042-001-s510><attend.gehen><en> It may be possible If you choose not to learn and attend the meetings and learn who and what you are voting for that you do not get to vote.
<G-vec00042-001-s510><attend.gehen><de> Es ist durchaus möglich, dass ihr euch dazu entscheidet, nicht zu Meetings zu gehen, um zu lernen und zu prüfen, für wen, was und wofür ihr eure Stimme abgebt und somit nicht wählen geht.
<G-vec00042-001-s511><attend.gehen><en> "For that reason he begins he treatment of discernment with a strong warning against the ""troublesome temptation"" to want to know God's will in every minor detail of daily life such as whether to dine with this friend or not, to wear gray or black, to fast on Friday or Saturday, to visit the sick or to attend vespers, and so forth."
<G-vec00042-001-s511><attend.gehen><de> "Aus diesem Grund beginnt er seine Gedanken zur Entscheidungsfindung mit einer starken Warnung gegen die ""lästige Versuchung"", Gottes Willen in jedem winzigen Detail des täglichen Lebens erkennen zu wollen wie etwa, ob man mit einem Freund essen gehen soll oder nicht, ob man grau oder schwarz tragen soll, ob man am Freitag oder Samstag fasten soll, ob man Kranke besuchen oder in die Kirche gehen soll und so fort."
<G-vec00042-001-s512><attend.gehen><en> Nevertheless, meanwhile 20 children between two and six years attend kindergarten and an additional four to six students attend each school grade.
<G-vec00042-001-s512><attend.gehen><de> Dennoch gehen inzwischen 20 Kinder zwischen zwei und sechs Jahren in den Kindergarten und in die vier Schulklassen jeweils vier bis sechs Schüler.
<G-vec00042-001-s513><attend.gehen><en> Those with a mature devotional approach attend and perform rituals to gain inspiration to work on themselves. Balancing the Three
<G-vec00042-001-s513><attend.gehen><de> Diejenigen mit einer reifen hingebungsvollen Herangehensweise gehen zu Ritualen und führen diese durch, um inspiriert zu werden, an sich zu arbeiten.
<G-vec00042-001-s514><attend.gehen><en> They did not attend to the usual work necessary to sustain daily life.
<G-vec00042-001-s514><attend.gehen><de> Sie gehen nicht den üblichen Arbeiten nach, die für den Unterhalt des täglichen Lebens nötig sind.
<G-vec00042-001-s515><attend.gehen><en> "Many children who work to help support their family"", adds Krämer ""cannot attend school."
<G-vec00042-001-s515><attend.gehen><de> """Viele Kinder, die arbeiten und damit zum Lebensunterhalt ihrer Familie beitragen müssen, können nicht zur Schule gehen."
<G-vec00042-001-s516><attend.gehen><en> I heard one Western Buddhist teacher say that we use up a lot of positive karma to attend and hear teachings.
<G-vec00042-001-s516><attend.gehen><de> Ich habe gehört, wie ein westlicher Buddhismus-Lehrer gesagt hat, dass wir viel positives Karma verbrauchen, wenn wir zu Unterweisungen gehen und sie anhören.
<G-vec00042-001-s517><attend.gehen><en> I have never been to a re:publica, and I'm sure it's very different from the standard IT fairs I generally have to attend.
<G-vec00042-001-s517><attend.gehen><de> Ich muss gestehen, ich war noch nie auf einer re:publica und das ist sicher was ganz anderes als die üblichen IT-Messen, auf die ich sonst immer gehen muss.
<G-vec00042-001-s518><attend.gehen><en> Zahra makes it possible for specially gifted children to attend school in Kerman.
<G-vec00042-001-s518><attend.gehen><de> Besonders begabten Kindern ermöglicht Zahra, in Kerman zur Schule zu gehen.
<G-vec00042-001-s519><attend.gehen><en> And tiniest little figures attend to their living now here, now there, as obvious among them also quarry workers.
<G-vec00042-001-s519><attend.gehen><de> Und kleinste Figürchen gehen bald hier, bald da ihrem Broterwerb nach, als naheliegend unter ihnen auch Steinbrucharbeiter.
<G-vec00042-001-s539><attend.kommen><en> Invited guests include spiritual luminaries and leaders of all the great world religions and diverse smaller religious groups; invited guests who are unable to attend can participate in the conference via satellite.
<G-vec00042-001-s539><attend.kommen><de> Geladen sind spirituelle Größen und Führer/innen aller weltreligiösen Großrichtungen und diverser kleinerer Gemeinschaften; geladene Gäste, die nicht kommen können, haben die Möglichkeit über Satellitenschaltung an der Konferenz teilzunehmen.
<G-vec00042-001-s540><attend.kommen><en> You'll need to know how many people are going to attend for the purposes of venues, catering and invitations.
<G-vec00042-001-s540><attend.kommen><de> Du wirst wissen müssen, wie viele Leute kommen werden, um die Örtlichkeiten, das Catering und die Einladungen zu planen.
<G-vec00042-001-s541><attend.kommen><en> Aufderheide: I certainly can't learn the index cards of all those who attend off by heart.
<G-vec00042-001-s541><attend.kommen><de> Aufderheide: Jedenfalls kann ich nicht alle Karteikarten derer, die kommen, auswendig lernen.
<G-vec00042-001-s542><attend.kommen><en> Exactly the right age to attend the nursery.
<G-vec00042-001-s542><attend.kommen><de> Genau das richtige Alter um in den Kindergarten zu kommen.
<G-vec00042-001-s543><attend.kommen><en> Not knowing who would attend, we were quite surprised to have a whole class of 10-year-old kids.
<G-vec00042-001-s543><attend.kommen><de> Da wir nicht wussten, wer kommen würde, waren wir ziemlich überrascht, als wir eine ganze Klasse mit 10-jährigen Kindern vor uns hatten.
<G-vec00042-001-s544><attend.kommen><en> These galleries present up to four exhibitions per year and attend around two trade shows, such as Design Miami, the Biennale Interieur in Kortrijk or the Milan Furniture Fair .
<G-vec00042-001-s544><attend.kommen><de> Die hier genannten Designgalerien veranstalten bis zu vier Ausstellungen im Jahr, hinzu kommen circa zwei Messeauftritte, beispielsweise auf der Design Miami, der Biennale Interieur in Kortrijk oder dem Salone del Mobile in Mailand.
<G-vec00042-001-s545><attend.kommen><en> Barack Obama and George W. Bush will attend the funeral, but the current president is not invited.
<G-vec00042-001-s545><attend.kommen><de> Barack Obama und George W. Bush kommen zum Begräbnis, aber der derzeitige Präsident ist nicht eingeladen.
<G-vec00042-001-s546><attend.kommen><en> As GIZ Project Manager Björn Zimprich explains, 'Over 90 per cent of Jordanians and Syrians are followers of Islam, and all worshippers attend mosques regardless of their ethnic origin.'
<G-vec00042-001-s546><attend.kommen><de> """Über 90 Prozent der Jordanier und Syrer bekennen sich zum Islam und in den Moscheen kommen alle Gläubigen zusammen – egal welcher Herkunft"", erklärt GIZ-Projektleiter Björn Zimprich."
<G-vec00042-001-s547><attend.kommen><en> In 1937 this association was frequented only by well heeled elderly gentlemen like Friedrich Bonhoff or Bruno Dorfmann who demanded two guarantors before allowing the new member to attend their meetings.
<G-vec00042-001-s547><attend.kommen><de> Im Jahre 1937 bestand dieser Verein aus vorwiegend sehr gut betuchten alten Herren – darunter zum Beispiel Friedrich Bonhoff oder Bruno Dorfmann, die schon zwei Bürgen sehen wollten, ehe sie einem neuen Mitglied erlaubten, zu ihren Sitzungen zu kommen.
<G-vec00042-001-s548><attend.kommen><en> Remember: for every registered student in a course who does not attend regularly, there are other more motivated students who did not receive the spot and are deprived of the opportunity to attend that course.
<G-vec00042-001-s548><attend.kommen><de> Bedenken Sie: Für jeden eingeschriebenen Teilnehmer, der nicht zum Kurs erscheint, gibt es mehrere leistungs- und lernwilligere Studenten, die es nicht geschafft haben, in den Kurs ihrer Wahl zu kommen.
<G-vec00042-001-s549><attend.kommen><en> Keen riders could attend Newcastle on the Sydney if the dates do not coincide.
<G-vec00042-001-s549><attend.kommen><de> Begeisterte Fahrer könnten nach Newcastle am Sydney kommen, wenn die Daten nicht übereinstimmen.
<G-vec00042-001-s550><attend.kommen><en> The children use the equipment, in part, intensively and explore every avenue of use, for teenagers and adults trying and testing the equipment out is more at the forefront. Only very few people use the equipment for training, and few attend regularly.
<G-vec00042-001-s550><attend.kommen><de> Die Kinder nutzten die Geräte zum Teil intensiv und erforschen jede Möglichkeit der Nutzung, bei Jugendliche und Erwachsenen steht vor allem das Ausprobieren und Testen im Vordergrund, nur wenige Menschen nutzen das Angebot zum Trainieren, ganz wenige kommen regelmäßig.
<G-vec00042-001-s551><attend.kommen><en> Garmisch is my home, my family lives here and I know, they all will attend the races and will cheer for me.
<G-vec00042-001-s551><attend.kommen><de> Garmisch ist meine Heimat, hier leben meine Familie, meine Freunde und ich weiß, sie alle kommen zu den Rennen um mich anzufeuern.
<G-vec00042-001-s552><attend.kommen><en> One of the Mageians attending found FOSDEM very difficult: “Because of the huge amount of people I missed important speaks I wanted to attend as you had to crash and disturb the previous talk to have any chance what so ever to attend until the room was “closed”.
<G-vec00042-001-s552><attend.kommen><de> Einer der Mageia-Besucher fand die FOSDEM sehr anstrengend: „Wegen der großen Masse an Besuchern habe ich wichtige Vorträge, die ich anhören wollte verpasst, weil man den vorherigen Vortrag hätte stören müssen, um überhaupt eine Chance zu haben, in den entsprechenden Raum zu kommen, bevor er geschlossen wurde.
<G-vec00042-001-s553><attend.kommen><en> Against this background, the event provides possibilities for getting in touch with senior decision makers from all over the globe, as about 200 leading experts are expected to attend the event.
<G-vec00042-001-s553><attend.kommen><de> Vor diesem Hintergrund bietet das WDF den rund 200 erwarteten darunter Signaltechnikexperten und Entscheidungsträgern aus aller Welt die Chance, in einem informellen Rahmen ins Gespräch zu kommen und sich auszutauschen.
<G-vec00042-001-s554><attend.kommen><en> Most of them still attend that church over forty years later.
<G-vec00042-001-s554><attend.kommen><de> Die Mehrheit von ihnen kommen immer noch zu jener Kirche, über vierzig Jahre später.
<G-vec00042-001-s555><attend.kommen><en> If you wish to assist abuse survivors to attend who are financially unable, we are setting aside a special silentlambs travel fund.
<G-vec00042-001-s555><attend.kommen><de> Wenn ihr Missbrauchsopfern, die dazu finanziell nicht in der Lage sind, helfen wollt, zu kommen, dann gibt es dafür eine besondere Silentlambs-Reisekasse.
<G-vec00042-001-s556><attend.kommen><en> When they use our drugs, they will be weak both spiritually and physically to attend church services, read their Bible, or pray, until they become dead spiritually.
<G-vec00042-001-s556><attend.kommen><de> Wenn sie sie benutzen, werden sie geistig und körperlich schwach sein, sie werden nicht zur Anbetung kommen und Schwierigkeiten haben, ihre Bibel zu lesen oder zu beten, bis sie geistig sterben.
<G-vec00042-001-s557><attend.kommen><en> Some bore the names of those unable to attend in person.
<G-vec00042-001-s557><attend.kommen><de> Einige tragen auch die Namen von denen, die nicht persönlich kommen konnten.
<G-vec00301-001-s558><attend.kümmern><en> We’ll personally attend to them and reply as soon as possible.
<G-vec00301-001-s558><attend.kümmern><de> Wir kümmern uns persönlich darum und antworten so schnell wie möglich.
<G-vec00301-001-s559><attend.kümmern><en> Customer queries do not relent to allow agents to be trained properly, before they are expected to resolve attend to tickets.
<G-vec00301-001-s559><attend.kümmern><de> Kundenanfragen nehmen nicht ab und erlaubern den Mitarbeitern geschult zu werden, bevor sie sich um Tickets kümmern.
<G-vec00301-001-s560><attend.kümmern><en> """Sorin, you and I have another matter to attend to,"" said Olivia, floating around them."
<G-vec00301-001-s560><attend.kümmern><de> """Sorin, wir beide haben uns um eine andere Angelegenheit zu kümmern"", sagte Olivia und schwebte um sie herum."
<G-vec00301-001-s561><attend.kümmern><en> When you find a Cow hungry and thirsty, do not neglect to attend to it.
<G-vec00301-001-s561><attend.kümmern><de> Wenn ihr eine Kuh hungrig und durstig vorfindet, versäumt nicht, euch um sie zu kümmern.
<G-vec00301-001-s562><attend.kümmern><en> Customer support at Coral Poker is efficient and excellent staff is knowledgeable to attend to your queries.
<G-vec00301-001-s562><attend.kümmern><de> Die Kundenbetreuung bei Coral Poker ist effizient und die hervorragenden Mitarbeiter kümmern sich kompetent um Ihre Fragen.
<G-vec00301-001-s563><attend.kümmern><en> When these think about salvation, they cherish those lusts in their hearts and embrace their faith with both hands, thinking that they may be saved by uttering certain words with a tone of confidence, and that they need not attend to anything of their life for the sake of God, but only for the sake of the world.
<G-vec00301-001-s563><attend.kümmern><de> Wenn diese über Errettung nachdenken, hegen sie solche sinnlichen Begierden in ihren Herzen und umarmen ihren Glauben mit beiden Händen, und meinen, daß sie gerettet seien, indem sie gewisse Worte von sich geben, mit einem Ton der Gewissheit, und daß sie sich um nichts in ihrem Leben wegen Gott kümmern brauchen, sondern nur wegen der Welt.
<G-vec00301-001-s564><attend.kümmern><en> Three weeks after my return I finally managed at home to attend to the allegedly - according to information supplied by the F5 - used up battery sets.
<G-vec00301-001-s564><attend.kümmern><de> Drei Wochen nach meiner Rückkehr kam ich zuhause endlich dazu, mich um die drei angeblich - nach Aussage der F5 - verbrauchten Batteriesätze zu kümmern.
<G-vec00301-001-s565><attend.kümmern><en> Here, in Italy, I have discovered many associations, men and women, who give part of their own time to attend to, to accompany, to be caregivers to the sick.
<G-vec00301-001-s565><attend.kümmern><de> Hier in Italien habe ich viele Verbände entdeckt, Männer und Frauen, die einen Teil ihrer Zeit aufopfern, um sich um kranke Menschen zu kümmern, ihnen beizustehen, sie zu pflegen.
<G-vec00301-001-s566><attend.kümmern><en> There are lots of aspects to attend to: finding a venue, arranging your wedding dress, the invitations, choosing the suppliers, checking all the orders, personally managing everything to achieve the desired result - all this can only be done by someone who organizes weddings professionally.
<G-vec00301-001-s566><attend.kümmern><de> Es gibt so viele Aspekte zu kümmern: Suche nach Lage, Ihr Hochzeitskleid, Investitionen, Lieferantenauswahl, alle Verträge überprüfen und persönlich alles gelingt, mit dem gewünschten Ergebnis zu erhalten, zu dem nur diejenigen, die Hochzeiten organisieren Beruf kann denken.
<G-vec00301-001-s567><attend.kümmern><en> They were to attend him day and night, to minister to his physical and sundry needs, and to accompany him on those night vigils of prayer and mysterious communion with the Father in heaven.
<G-vec00301-001-s567><attend.kümmern><de> Sie hatten ihm Tag und Nacht zu Diensten zu sein, sich um seine materiellen und übrigen Bedürfnisse zu kümmern und ihn zu begleiten während der durchwachten Nächte, die er im Gebet und in geheimnisvoller Verbindung mit dem himmlischen Vater verbrachte.
<G-vec00301-001-s568><attend.kümmern><en> In that case your employer has to attend to registration of this document.
<G-vec00301-001-s568><attend.kümmern><de> In diesem Fall soll sich von der Erledigung dieses Dokumentes Ihr Arbeitgeber kümmern.
<G-vec00301-001-s569><attend.kümmern><en> And neither its author nor anyone else seems interested or able to attend to whatever the problem (s) might be.
<G-vec00301-001-s569><attend.kümmern><de> Weder der Autor noch jemand anderes scheint interessiert oder in der Lage zu sein, sich um die Probleme zu kümmern.
<G-vec00301-001-s570><attend.kümmern><en> Rich or poor, high or low, all receive equal attention in the same manner as a doctor should attend to the sick.
<G-vec00301-001-s570><attend.kümmern><de> Alle erhalten die gleiche Aufmerksamkeit, ob arm oder reich, hoch oder niedrig, so wie sich ein Arzt um die Kranken kümmern sollte.
<G-vec00301-001-s571><attend.kümmern><en> New year everything is closer so if you were not defined yet where and as will meet it — it is a high time to attend to this question.
<G-vec00301-001-s571><attend.kümmern><de> Das neue Jahr ist sich immer näher, so dass wenn Sie sich noch nicht geklärt haben, wo Sie auch als es die Zeit begegnen werden von dieser Frage zu kümmern.
<G-vec00042-001-s610><attend.teilnehmen><en> They also regularly attend conferences held by international professional organizations or international representations of interest at home or abroad.
<G-vec00042-001-s610><attend.teilnehmen><de> Sie nehmen auch regelmäßig an Konferenzen im In- und Ausland teil, welche von internationalen beruflichen Organisationen oder internationalen Interessenvereinigungen ausgerichtet werden.
<G-vec00042-001-s611><attend.teilnehmen><en> The CEO, the ICS Officer, the Head of Internal Audit and the CFO as well as a representative of the auditors also attend the meetings of the Audit Committee in a consultative capacity.
<G-vec00042-001-s611><attend.teilnehmen><de> An den Sitzungen des Prüfungsausschusses nehmen auch der CEO, der IKS-Officer, der CFO, der Leiter Interne Revision sowie ein Vertreter der Revisionsgesellschaft beratend teil.
<G-vec00042-001-s612><attend.teilnehmen><en> Many decision makers attend the expo on regular basis.
<G-vec00042-001-s612><attend.teilnehmen><de> Viele Entscheidungstreffer nehmen regelmäßig an der Messe teil.
<G-vec00042-001-s613><attend.teilnehmen><en> Women are more likely to see a doctor and attend check-ups.
<G-vec00042-001-s613><attend.teilnehmen><de> Frauen nehmen häufiger an Vorsorgeuntersuchungen teil und haben insgesamt mehr medizinische Konsultationen.
<G-vec00042-001-s614><attend.teilnehmen><en> The CEO, the CFO, the Head of Internal Audit/Risk Officer as well as a representative of the auditors also attend the meetings of the Audit Committee in a consultative capacity.
<G-vec00042-001-s614><attend.teilnehmen><de> An den Sitzungen des Prüfungsausschusses nehmen auch der CEO, der CFO, der Leiter Interne Revision/Risk Officer sowie ein Vertreter der Revisionsgesellschaft beratend teil.
<G-vec00042-001-s615><attend.teilnehmen><en> Project manager as well as engineering manager attend the development rounds.
<G-vec00042-001-s615><attend.teilnehmen><de> In den Entwicklungsrunden nehmen sowohl die Projektmanager als auch die Fertigungsleitung teil.
<G-vec00042-001-s616><attend.teilnehmen><en> Attend a Fronius event at least once every three years to retain your Partner status.
<G-vec00042-001-s616><attend.teilnehmen><de> Nehmen Sie mindestens alle drei Jahre an einer Fronius Veranstaltung teil und halten somit Ihre Partnerschaft aufrecht.
<G-vec00042-001-s617><attend.teilnehmen><en> The Rothschild family often pops up in connection with Bilderberg, and many of its minions frequently attend, although sometimes their Rothschild connection is not highlighted on the guest list.
<G-vec00042-001-s617><attend.teilnehmen><de> Die Rothschild-Familie taucht oft im Zusammenhang mit Bilderberg auf und viele ihrer Diener nehmen häufig teil, obwohl manchmal ihre Rothschild-Verbindung nicht auf der Gästeliste hervorgehoben wird.
<G-vec00042-001-s618><attend.teilnehmen><en> This year, participants from 18 countries and regions including Japan, mainland China, Germany, Taiwan and the U.K. will attend.
<G-vec00042-001-s618><attend.teilnehmen><de> In diesem Jahr nehmen Aussteller aus 18 Ländern und Regionen teil, darunter Japan, Festland-China, Deutschland, Taiwan und U.K.
<G-vec00042-001-s619><attend.teilnehmen><en> In addition, representatives from all major Russian media outlets (both publicly and at least on paper, privately owned) attend the meetings. – either executives, deputy directors or chief editors.
<G-vec00042-001-s619><attend.teilnehmen><de> An den Treffen nehmen zusätzlich zu Gromov die Vertreter – sowohl die stellvertretenden Chefs als auch Chefredakteure – aller größeren russischen Medienausgaben teil (sowohl die von den staatlichen als auch der privaten).
<G-vec00042-001-s620><attend.teilnehmen><en> Furthermore, representatives of the European Commission and the European Medicines Agency also attend.
<G-vec00042-001-s620><attend.teilnehmen><de> Außerdem nehmen Vertreter der Europäischen Kommission und der Europäischen Arzneimittelbehörde teil.
<G-vec00301-001-s697><attend.sorgen><en> Traditional methods of finding a date would be to rely on friends to play matchmaker or to attend bars, various different social events and parties.
<G-vec00301-001-s697><attend.sorgen><de> Traditionelle Methoden des Findens eines Datums würden auf Freunde bauen sollen, um Ehestifter zu spielen oder sich Stäbe, verschiedene unterschiedliche Sozialfälle und Parteien zu sorgen.
<G-vec00301-001-s698><attend.sorgen><en> You know what I'm talking about -- it's the marketing face, the selling voice, that you often put on in order to attend a networking event or make a sales call.
<G-vec00301-001-s698><attend.sorgen><de> Sie wissen, über was ich spreche -- es ist das Marketing-Gesicht, die verkaufenstimme, die Sie häufig sich an setzen, um sich ein Netzwerkanschlussereignis zu sorgen oder zu bilden ein Kundenbesuch.
<G-vec00301-001-s699><attend.sorgen><en> In a production area of about 3,900 square metres they attend to the tasks of production, warehousing, logistics, administration, purchasing and data processing for smooth processing.
<G-vec00301-001-s699><attend.sorgen><de> Auf einer Produktionsfläche von etwa 3.900 qm sorgen sie in den Bereichen Produktion, Lager, Logistik, Verwaltung, Einkauf und EDV für reibungslose Abläufe.
<G-vec00301-001-s700><attend.sorgen><en> The salient fact was that both the mayor and an African American council member, Don Samuels, did not think it worthwhile or advisable to attend an event sponsored by the Minneapolis NAACP.
<G-vec00301-001-s700><attend.sorgen><de> Die auffallende Tatsache war, dass der Bürgermeister und ein AfroamerikanerRatsmitglied, Don Samuels, sie nicht lohnend oder ratsam, sich ein Ereignis zu sorgen dachten, das durch das Minneapolis NAACP gefördert wurde.
<G-vec00301-001-s701><attend.sorgen><en> We market and sell bucket elevators globally and attend to delivery, installation, and start-up.
<G-vec00301-001-s701><attend.sorgen><de> Wir vermarkten und verkaufen Pendelbecherwerke global und sorgen für Lieferung, Montage und Betriebsaufnahme der Pendelbecherwerke.
<G-vec00301-001-s702><attend.sorgen><en> 3 The benefit provided in accordance with this article shall be afforded with a view to maintaining, restoring or improving the health of the person protected and his ability to work and to attend to his personal needs.
<G-vec00301-001-s702><attend.sorgen><de> 3 Die Leistungen nach diesem Artikel sind darauf zu richten, die Gesundheit der geschützten Personen, ihre Arbeitsfähigkeit und ihre Fähigkeit, für ihre persönlichen Bedürfnisse zu sorgen, zu erhalten, wiederherzustellen oder zu bessern.
<G-vec00301-001-s703><attend.sorgen><en> In late October 2000, Brazilian company Tonini invited us to San Paolo to attend a number of seminars and presentations organized by their specialists and devoted to the main topic of our magazine: new information technology for outdoor usage.
<G-vec00301-001-s703><attend.sorgen><de> Im späten Oktober 2000 lud brasilianische Firma Tonini uns zu San Paolo ein, uns einige Seminare und Präsentationen zu sorgen, die von ihren Fachleuten organisiert wurden und dem Hauptthema unserer Zeitschrift gewidmet waren: neue Information Technologie für Außenwerbung Nutzung.
<G-vec00301-001-s704><attend.sorgen><en> "This is a process by which employees are ""refreshed"", ""cleansed"" and ""re-invigorated"" by ensuring they attend set training courses or, perhaps, are placed on the ubiquitous ""refresher"" course."
<G-vec00301-001-s704><attend.sorgen><de> "Dieses ist ein Prozess, durch den Angestellte ""erneuert"" sind, ""gereinigte"" und ""neu gestärkte"" durch Gewährleistung sie sorgen gesetzte Ausbildungskurse oder möglicherweise gesetzt auf den überall vorhandenen ""Erfrischung"" Kurs."
<G-vec00301-001-s705><attend.sorgen><en> More that 1,500 persons from all parts of the country were expected to attend.
<G-vec00301-001-s705><attend.sorgen><de> Mehr, die 1.500 Personen von allen Teilen des Landes erwartet wurden, sich zu sorgen.
<G-vec00301-001-s706><attend.sorgen><en> Some choose to attend California which are located near the sea or close to nature.
<G-vec00301-001-s706><attend.sorgen><de> Einige beschließen, sich Kalifornien zu sorgen, die nahe dem Meer oder nah an Natur sich befinden.
<G-vec00301-001-s707><attend.sorgen><en> 3 The medical care specified in paragraph 2 of this article shall be afforded with a view to maintaining, restoring or improving the health of the woman protected and her ability to work and to attend to her personal needs.
<G-vec00301-001-s707><attend.sorgen><de> 3 Die ärztliche Betreuung nach Absatz 2 ist darauf zu richten, die Gesundheit der geschützten Frau, ihre Arbeitsfähigkeit und ihre Fähigkeit, für ihre persönlichen Bedürfnisse zu sorgen, zu erhalten, wiederherzustellen oder zu bessern.
<G-vec00301-001-s708><attend.sorgen><en> We, the Service-to-Others Zetas, attend them with all our means.
<G-vec00301-001-s708><attend.sorgen><de> Wir, die Dienst-für-andere-Zetas, sorgen für sie mit all unseren Mitteln.
<G-vec00301-001-s709><attend.sorgen><en> For one thing, prolonged educations persuade young people, especially women, to postpone childbearing and childrearing for the sake of becoming established in a career. Assuming that college selects the more intelligent persons within the population, intelligent women and men who prolong their educations are systematically failing to reproduce in comparison with those who do not attend school or have dropped out of school.
<G-vec00301-001-s709><attend.sorgen><de> Für eine Sache überzeugen verlängerte educations junge Leute, besonders Frauen, Gebären und das Childrearing um des Werdens willen hinauszuschieben hergestellt in einer Karriere., daß Hochschule die vorwählt, intelligenteren Personen innerhalb der Bevölkerung annehmend, können intelligente Frauen und Männer, die ihre educations ausdehnen, systematisch im Vergleich mit denen reproduzieren, die nicht haben sich nicht Schule sorgen oder außerschulisches fallengelassen.
<G-vec00042-001-s748><attend.teilnehmen><en> We are dedicated to the preparation and sale of bedding More... wholesale and retail orders to attend provinces, hotels and tenders.
<G-vec00042-001-s748><attend.teilnehmen><de> Wir sind mit der Vorbereitung und dem Verkauf von Betten Mehr... Groß-und Einzelhandel Aufträge Provinzen, Hotels und Ausschreibungen teilnehmen gewidmet.
<G-vec00042-001-s749><attend.teilnehmen><en> My vision for the TMLA is as an organization free of prejudice and division, where any student can participate, regardless of their nation of origin, gender, or the university they attend.
<G-vec00042-001-s749><attend.teilnehmen><de> Mein Ziel ist, dass die TMLA eine Organisation frei von Vorurteilen und Abgrenzungen ist, an der jeder Student ungeachtet von Herkunftsland, Geschlecht oder Universität teilnehmen kann.
<G-vec00042-001-s750><attend.teilnehmen><en> Conference funding Conference costs are covered by voluntary contributions: you can pay an amount of your choice either for your own attendance or, if you are unable to attend, to allow someone else to participate.
<G-vec00042-001-s750><attend.teilnehmen><de> Tagungsunterstützung Die Tagungskosten werden durch freie Beiträge gedeckt: durch Einzahlung eines frei wählbaren Unterstützungsbeitrags für Ihre eigene Teilnahme oder, wenn Sie nicht teilnehmen können, um anderen die Teilnahme zu ermöglichen.
<G-vec00042-001-s751><attend.teilnehmen><en> For women who are unable to attend one of our events or don't live in a city where there is a National Woman's Heart Day® screening event, talk to your physician or health care provider about getting a heart-health screening. Ask them to:
<G-vec00042-001-s751><attend.teilnehmen><de> Für Frauen, die nicht in der Lage sind, einer unserer Veranstaltungen teilnehmen oder leben nicht in einer Stadt, wo es ein National Woman's Heart Day ® Screening-Veranstaltung, sprechen Sie mit Ihrem Arzt oder Arzt darum, eine Herz-Gesundheit-Screening.
<G-vec00042-001-s752><attend.teilnehmen><en> If you are not able to attend, the information from these events will also be available online.
<G-vec00042-001-s752><attend.teilnehmen><de> Wenn Sie nicht teilnehmen können, sind die Informationen dieser Veranstaltungen auch online verfügbar.
<G-vec00042-001-s753><attend.teilnehmen><en> (According to the Commentary, this means that all bhikkhunīs in the Community territory (sima) must attend.
<G-vec00042-001-s753><attend.teilnehmen><de> (Entsprechend dem Kommentar bedeutet dieses, daß all Bhikkhunīs im Gemeinschaftgebiet (sima) teilnehmen müssen.
<G-vec00042-001-s754><attend.teilnehmen><en> Of course, living in boarding schools meant that Edward could attend lessons and he got a pretty good education in modern languages and classical studies.
<G-vec00042-001-s754><attend.teilnehmen><de> Natürlich, das Leben in Internate bedeutete, dass Edward Unterricht teilnehmen könnten, und er bekam eine ziemlich gute Ausbildung in modernen Sprachen und klassischen Studien.
<G-vec00042-001-s755><attend.teilnehmen><en> The weigh-in, which non-anglers can attend for $50, will feature barbecue, drinks and live country music.
<G-vec00042-001-s755><attend.teilnehmen><de> Das Wiegen, die nicht-Angler können teilnehmen $50, wird Grill verfügen, Getränke und Live-Country-Musik.
<G-vec00042-001-s756><attend.teilnehmen><en> "October 12, 2010 The articles ""James Lloyd To Attend Debate"" and ""UPDATE: Democrats Not Attending Debate Tonight"" both had the last name of Dan Petrosky corrected."
<G-vec00042-001-s756><attend.teilnehmen><de> "Oktober 12, 2010 Die Artikel ""James Lloyd, die Debatte teilnehmen"" and ""UPDATE: Demokraten werde nicht kommen Debatte heute Abend"" hatten beide den Nachnamen des Dan Petrosky korrigiert."
<G-vec00042-001-s757><attend.teilnehmen><en> Later you'll visit the Island of Barbana where it is possible, for anyone who wishes, to attend Holy Mass, have lunch or booking directly at the Shrine.
<G-vec00042-001-s757><attend.teilnehmen><de> Später besuchen wir die Isola di Barbana, auf der diejenigen, die es wünschen, an der Heiligen Messe teilnehmen können; danach kann ein Imbiss-Mittagessen genossen oder direkt beim Wallfahrtsort reserviert werden.
<G-vec00042-001-s758><attend.teilnehmen><en> In order to ensure the timely receipt of these admission cards, we ask that shareholders intending to attend the Annual General Meeting request an admission card from their depositary bank at the earliest possible time.
<G-vec00042-001-s758><attend.teilnehmen><de> Um den rechtzeitigen Erhalt der Eintrittskarten sicherzustellen, bitten wir die Aktionäre, die an der Hauptversammlung teilnehmen wollen, möglichst frühzeitig eine Eintrittskarte bei ihrem depotführenden Institut anzufordern.
<G-vec00042-001-s759><attend.teilnehmen><en> "The event was open to the public; ""Falcon Crest"" fans were welcome to attend."
<G-vec00042-001-s759><attend.teilnehmen><de> Die Veranstaltung war öffentlich; Fans der Serie konnten teilnehmen.
<G-vec00042-001-s760><attend.teilnehmen><en> Our institut will attend at the PSE 2010 in Garmisch Partenkirchen (stand number 14).
<G-vec00042-001-s760><attend.teilnehmen><de> Unsere Einrichtung wird als Aussteller an der PSE 2010 in Garmisch Partenkirchen teilnehmen.
<G-vec00042-001-s761><attend.teilnehmen><en> "In the words of its director, Alejandro Roda, ""practically the 100% of the purchasing power of the Iberian peninsula it attend the appointment."
<G-vec00042-001-s761><attend.teilnehmen><de> "In den Worten seines Direktors, Alejandro Roda, ""praktisch die 100% der Kaufkraft der Iberischen Halbinsel, die daran teilnehmen der Ernennung."
<G-vec00042-001-s762><attend.teilnehmen><en> Even though my attend distant learning classes online, several universities hold commencement at several locations.
<G-vec00042-001-s762><attend.teilnehmen><de> Auch wenn mein Fernstudium Klassen online teilnehmen, halten mehrere Universitäten Beginn an mehreren Standorten.
<G-vec00042-001-s763><attend.teilnehmen><en> Further speakers can attend at early-bird partner price.*
<G-vec00042-001-s763><attend.teilnehmen><de> Weitere Vortragende können zum Early-Bird Partnerpreis teilnehmen.
<G-vec00042-001-s764><attend.teilnehmen><en> Hanwha Azdel Award Winners to Attend Ceremony Hanwha Azdel is proud to announce that two members are set to receive the Hanwha Advanced Materials Global Award in October.
<G-vec00042-001-s764><attend.teilnehmen><de> "Hanwha Azdel Award-Gewinner werden bei der ""Global Award Ceremony"" teilnehmen Hanwha Azdel freut sich bekannt zu geben, dass zwei Mitarbeiter von Hanwha Azdel im Oktober den Hanwha Advanced Materials Global Award erhalten werden."
<G-vec00042-001-s765><attend.teilnehmen><en> In his capacity as representative of the country holding the Presidency, the State Secretary will then attend the Wilton Park conference on the future of the European Union in Sussex, where he will give a speech on the future course of procedure relating to the Constitutional Treaty.
<G-vec00042-001-s765><attend.teilnehmen><de> "Abschließend wird der Staatssekretär als Vertreter des EU-Vorsitzlandes an einer in Sussex stattfindenden ""Wilton Park""-Konferenz zur Zukunft der Europäischen Union teilnehmen und in seinem Vortrag auf die weitere Vorgehensweise im Bereich des Verfassungsvertrages eingehen."
<G-vec00042-001-s766><attend.teilnehmen><en> During your time at Neapolis University in Cyprus, whether on a Bachelor's, Master's or Doctoral (Ph.D.), you will be expected to attend lectures and other programme-related activities and to work independently, either individually or in groups, on assignments.
<G-vec00042-001-s766><attend.teilnehmen><de> Während Ihrer Zeit bei Neapolis Universität in Zypern, ob auf einem Bachelor-, Master- oder Doktor (PhD), wird von Ihnen erwartet, zu Vorträgen und anderen programmbezogenen Aktivitäten teilnehmen und eigenständig zu arbeiten, entweder einzeln oder in Gruppen, auf Zuweisungen.
<G-vec00042-001-s767><attend.teilnehmen><en> For those who are unable to physically attend the event, directions will be given through this website on how to take part in the work that we will undertake in Seattle. If you are signed up to receive the Hathor messages, you will automatically receive this information when it is available.
<G-vec00042-001-s767><attend.teilnehmen><de> Jene die nicht in der Lage sind, physisch bei uns zu sein, werden weitere Informationen über diese Website erhalten, wie sie an dieser Arbeit teilnehmen können, die wir in Seattle unternehmen.
<G-vec00042-001-s768><attend.teilnehmen><en> Free Shipping Description In case that you are ready to attend wedding party, now just spend a few minuets taking this away.
<G-vec00042-001-s768><attend.teilnehmen><de> beschreibung Für den Fall, dass Sie bereit sind, Hochzeitsfeier teilnehmen können, jetzt verbringen Sie einfach ein paar Menuette der Einnahme dieses weg .
<G-vec00042-001-s769><attend.teilnehmen><en> "The regular intercultural seminars that all employees are welcome to attend have now become a tradition, and are always well received,"" says Vera Vogel, Manager Human Resources ."
<G-vec00042-001-s769><attend.teilnehmen><de> "Die regelmäßigen interkulturellen Seminare, an denen alle Mitarbeiter teilnehmen können, haben inzwischen Tradition und werden gern angenommen"", sagt Vera Vogel, Manager Human Resources."
<G-vec00042-001-s770><attend.teilnehmen><en> For a lucky few, free tickets are distributed via lottery to attend this London-based fest.
<G-vec00042-001-s770><attend.teilnehmen><de> Einige wenige Menschen werden sich glücklich schätzen können, da einige Tickets durch eine Lotterie verlost werden, um an diesem Londoner Fest teilnehmen zu können.
<G-vec00042-001-s771><attend.teilnehmen><en> Note: Online Registration for the 2012 iDateStartup in Beverly Hills ends on June 20, 2012 We must receive your application prior to June 20, 2012 in order to be approved to attend the event at no charge .
<G-vec00042-001-s771><attend.teilnehmen><de> Hinweis: Online Registration fÃ1⁄4r die 2012 iDateStartup in Beverly Hills endet am June 20, 2012 Damit Sie kostenlos an der Veranstaltung teilnehmen zu können, mÃ1⁄4ssen wir Ihre Anfrage vor dem June 20, 2012 erhalten.
<G-vec00042-001-s772><attend.teilnehmen><en> Description Now that you are willing to attend the charming beauty competition, you should choose such a perfect and stylish dress to be your best companion.
<G-vec00042-001-s772><attend.teilnehmen><de> beschreibung Nun, da Sie bereit sind, die bezaubernde Schönheit Wettbewerb teilnehmen können, sollten Sie eine so perfekte und stilvolle Kleidung zu Ihrem besten Begleiter.
<G-vec00042-001-s773><attend.teilnehmen><en> Some media reporters were delighted to attend such an interesting symposium, and many of them said that they would come for interviews on the next day.
<G-vec00042-001-s773><attend.teilnehmen><de> Einige Medien-Reporter waren erfreut, an so einem interessanten Symposium teilnehmen zu können, und viele von ihnen sagten, dass sie am nächsten Tag kämen, um Interviews zu machen.
<G-vec00042-001-s774><attend.teilnehmen><en> So I was so happy to attend the showcase.
<G-vec00042-001-s774><attend.teilnehmen><de> Umso glücklicher war ich also am Showcase teilnehmen zu können.
<G-vec00042-001-s775><attend.teilnehmen><en> There were seventy elders from the last meeting of The Eagle and The Condor in South America hoping to attend.
<G-vec00042-001-s775><attend.teilnehmen><de> "Siebzig Älteste vom vorhergehenden Treffen ""Der Adler und der Kondor"" (The Eagle and The Condor) in Südamerika hofften teilnehmen zu können."
<G-vec00042-001-s776><attend.teilnehmen><en> Given that you are ready to attend party, take this one away soon.
<G-vec00042-001-s776><attend.teilnehmen><de> Vorausgesetzt, dass Sie bereit für die Party teilnehmen können, nehmen Sie diesen bald weg .
<G-vec00042-001-s777><attend.teilnehmen><en> In order to attend the Annual General Meeting, each shareholder must provide the offices designated by the Board of Directors with evidence of his or her shareholding no less than five days prior to the date of the meeting.
<G-vec00042-001-s777><attend.teilnehmen><de> Um an der Generalversammlung teilnehmen zu können, hat sich jeder Aktionär spätestens fünf Tage vor dem Zeitpunkt der Versammlung bei den vom Verwaltungsrat hierfür bezeichneten Stellen über seinen Aktienbesitz auszuweisen.
<G-vec00042-001-s778><attend.teilnehmen><en> This date has specifically been chosen to enable all top drivers to attend.
<G-vec00042-001-s778><attend.teilnehmen><de> Dieser Termin wurde bewusst so angesetzt, damit alle Topfahrer teilnehmen können.
<G-vec00042-001-s779><attend.teilnehmen><en> Being invited to attend wedding party, it is an either exciting or upset thing.
<G-vec00042-001-s779><attend.teilnehmen><de> Die Einladung zur Hochzeitsfeier teilzunehmen, ist es ein entweder spannend oder verärgert Sache.
<G-vec00042-001-s780><attend.teilnehmen><en> There is far more abundance on the table, which you have invited to attend.
<G-vec00042-001-s780><attend.teilnehmen><de> Es gibt weit mehr Fülle auf dem Tisch derer, die euch eingeladen haben teilzunehmen.
<G-vec00042-001-s781><attend.teilnehmen><en> Manuel Georget, a worker at the Philips factory in Dreux and also a member of the Revolutionary Tendency of the NPA, was unable to attend the seminar due to the preparations for the NPA congress in February.
<G-vec00042-001-s781><attend.teilnehmen><de> Manuel Georget, ein Arbeiter der Philips Fabrik in Dreux, und ebenfalls Mitglied der Revolutionären Tendenz der NPA, war es wegen der Vorbereitungen für den NPA-Kongress im Februar leider nicht möglich, am Seminar teilzunehmen.
<G-vec00042-001-s782><attend.teilnehmen><en> Since those who extended the invitation have known for months that we do not agree with the conclusions that are being proposed, I felt it more appropriate to not attend the meeting.
<G-vec00042-001-s782><attend.teilnehmen><de> Da diejenigen, die diese Sitzung einberufen haben, seit Monaten wissen, dass wir mit den angedachten Ergebnissen nicht einverstanden sind, hielt ich es für richtiger, an dieser Sitzung nicht teilzunehmen.
<G-vec00042-001-s783><attend.teilnehmen><en> North Ossetia police ordered to attend all the weddings held in the republic.
<G-vec00042-001-s783><attend.teilnehmen><de> Nordossetien Polizei ordnete alle Hochzeiten in der Republik statt teilzunehmen.
<G-vec00042-001-s784><attend.teilnehmen><en> The girl will attend the Spring Fashion Show in Paris.
<G-vec00042-001-s784><attend.teilnehmen><de> Das Mädchen wird die Spring Fashion Show in Paris teilzunehmen.
<G-vec00042-001-s785><attend.teilnehmen><en> The Management Board may allow shareholders to cast their votes in writing or by electronic means even if they do not attend and are not represented at the General Meeting of Shareholders (absentee vote).
<G-vec00042-001-s785><attend.teilnehmen><de> Der Vorstand kann vorsehen, dass Aktionäre ihre Stimmen, auch ohne an der Versammlung selbst oder durch Vertreter teilzunehmen, schriftlich oder im Wege elektronischer Kommunikation abgeben dürfen (Briefwahl).
<G-vec00042-001-s786><attend.teilnehmen><en> Mr. Meng Hualong was among the inmates in the audience who were forced to attend.
<G-vec00042-001-s786><attend.teilnehmen><de> Meng Hualong war ein Inhaftierter, der gezwungen wurde, als Zuschauer daran teilzunehmen.
<G-vec00042-001-s787><attend.teilnehmen><en> Nearly 800 people from 60 different countries and 15 Christian denominations came to the pilgrimage in Rome. Included within the 800, The Holy Spirit inspired 95 clergy, many of whom were Archbishops and Bishops, to attend, so as to assemble and experience a unity in diversity.
<G-vec00042-001-s787><attend.teilnehmen><de> Zur Pilgerreise nach Rom kamen beinahe 800 Leute aus 60 Ländern und 15 christlichen Denominationen; inklusive 95 Klerikern, welche der Heilige Geist inspiriert hatte, an der Pilgerreise teilzunehmen und zusammenzukommen um die Einheit in der Vielheit zu erleben, viele darunter waren Erzbischöfe und Bischöfe.
<G-vec00042-001-s788><attend.teilnehmen><en> In addition to the general meeting where a new board will be elected there will also be lectures that all are welcome to attend.
<G-vec00042-001-s788><attend.teilnehmen><de> Außerdem werden zusätzlich zu der Hauptversammlung, auf der ein neuer Vorstand gewählt werden wird, Vorlesungen gehalten werden, bei denen jeder willkommen ist teilzunehmen.
<G-vec00042-001-s789><attend.teilnehmen><en> Earlier in the year I was approached by the symposium organisers, asking if the OeWF would be interested to attend.
<G-vec00042-001-s789><attend.teilnehmen><de> Zu Beginn des Jahres wurde ich von den Organisatoren des Symposiums gefragt, ob das ÖWF interessiert ist, teilzunehmen.
<G-vec00042-001-s790><attend.teilnehmen><en> For modern young ladies, they are in favor of wearing special short length dress to attend party.
<G-vec00042-001-s790><attend.teilnehmen><de> beschreibung Für die moderne junge Damen, sie sind für das Tragen besonderer Kleidung zu kurze Länge Partei teilzunehmen.
<G-vec00042-001-s791><attend.teilnehmen><en> The event is set to appear for the first time in the Olympics, to be held in Russia in 2014 and the 24 year old VanLaanen is excited to be healthy enough to attend.
<G-vec00042-001-s791><attend.teilnehmen><de> Die Veranstaltung wird sich zum ersten Mal bei den Olympischen Spielen erscheinen, in Russland statt in 2014 und die 24 jährige VanLaanen angeregt wird, um gesund genug, um teilzunehmen.
<G-vec00042-001-s792><attend.teilnehmen><en> Graduates do not need a ticket to attend the event.
<G-vec00042-001-s792><attend.teilnehmen><de> Absolventen und Absolventinnen benötigen kein Ticket, um teilzunehmen.
<G-vec00042-001-s793><attend.teilnehmen><en> It would have probably felt better if the Hopi had joined, but as far as the Mayan prophecy is concerned, the Hopi Traditional leaders were asked to attend, but their absence does not fail the Mayan Prophecy.
<G-vec00042-001-s793><attend.teilnehmen><de> Es hätte sich wahrscheinlich besser angefühlt, wenn die Hopi sich angeschossen hätten, aber soweit es die Prophezeiung der Maya betrifft, wurden die traditionellen Führer der Hopi gebeten teilzunehmen, aber ihre Abwesenheit brachte die Prophezeiung der Maya nicht zum scheitern.
<G-vec00042-001-s794><attend.teilnehmen><en> I will keep everyone updated as to my progress in raising the necessary funds in order to attend here on my blog.
<G-vec00042-001-s794><attend.teilnehmen><de> Ich werde alle über meine Fortschritte bei der Beschaffung der notwendigen Mittel auf dem Laufenden halten, um hier auf meinem Blog teilzunehmen.
<G-vec00042-001-s795><attend.teilnehmen><en> Any player interested in gaining experience with this repertoire and discovering the secrets of interpretation of the music that originated and was played here in the city where the masteclass takes place are invited to participate in the masterclass and to attend the concert Melante – the unknown Telemann .
<G-vec00042-001-s795><attend.teilnehmen><de> Musiker/innen, die Erfahrung mit diesem Repertoire gewinnen und die Geheimnisse der Interpretation entdecken möchten – eine Musik, die sogar aus der Stadt des Meisterkurses stammte und hier gespielt wurde, – sind herzlich eingeladen, am Meisterkurs teilzunehmen und das Konzert Melante – der unbekannte Telemann anzuhören.
<G-vec00042-001-s796><attend.teilnehmen><en> The Society has been stressing that the Watchtower Study is the real reason for JWs to attend the Sunday meeting.
<G-vec00042-001-s796><attend.teilnehmen><de> Durch de-Betonung der öffentlichen Diskussion wird die Gesellschaft macht den Punkt, dass die Wachtturm-Studium der wahre Grund für Zeugen Jehovas, den Sonntag Sitzung teilzunehmen.
<G-vec00042-001-s797><attend.teilnehmen><en> All interested people are welcome to attend.
<G-vec00042-001-s797><attend.teilnehmen><de> Alle interessierten Leute seien eingeladen teilzunehmen.
<G-vec00301-001-s798><attend.warten><en> Like remembered in our public assembly, the challenges are numerous that attend our associates and therefore an ulterior organizational and progettuale effort for being able will be necessary to accompany them along the distance that will lead them towards the future.
<G-vec00301-001-s798><attend.warten><de> Wie erinnert in unserer allgemeinen Versammlung, sind die Herausforderungen zahlreich, die und folglich eine zusätzliche organisations- und projekt- Mühe für sie zu können der die zukunft unsere Mitglieder wird notwendig sein wird in richtung zu sie führen warten, entlang dem Kurs begleiten.
<G-vec00301-001-s799><attend.warten><en> With the displacement of the passage of income in the retroportuale area - it has explained the agency - the trucks will be able to be stopped to the traffic centre of the plateau, where they will attend the ticket that will allow they to come down in city and to enter directly in the terminals of the port of Trieste for the boarding.
<G-vec00301-001-s799><attend.warten><de> Die Lastkraftwagen werden sich können, mit der Verschiebung von dem Durchgang von dem Eintritt in die retroportuale Fläche zu dem Autoporto von der Hochebene anhalten,- hat die Körperschaft erklärt -, wo das das Ticket warten wird und sie zulassen sie werden, direkt in den Terminals von dem Hafen von Trieste für das an Bord gehen hineinzugehen, in Stadt hinunterzugehen.
<G-vec00301-001-s800><attend.warten><en> "With respect to the perspectives for the next months, the forecasts of Peter Ulber, than from last month is the new managing director of Panalpina, is to the standard of the precaution: ""we do not attend - it has explained - meaningful changes in economical the world-wide one, but however still we consider that the increase of our activity Air Freight will continue."
<G-vec00301-001-s800><attend.warten><de> "Hinsichtlich der Perspektiven für die folgenden Monate, die Vorsorgen von Peter Ulber, ist als von dem fließt Monat das neue Verwaltungsratsmitglied von Panalpina, sind zu dem Schild von der Vorsicht: ""warten uns wir nicht die bedeutenden Veränderungen in der sparsamen Weltmeisterschaft,- hat es erklärt -, aber halten wir gleichwohl nach wie vor, dass das Wachstum von unserer Tätigkeit Air Freight fortsetzen wird."
<G-vec00301-001-s801><attend.warten><en> From part its Trasportounito does not hide to nourish little hopes on a positive outcome of the reunion: “we attend - the president of the trade-union association has explained, Franco Pensiero - the fixed encounter with the Improta undersecretary, at the end of the month of October, but the hopes to obtain turned out tangible are, to light of the recent experiences, indeed insufficient”.
<G-vec00301-001-s801><attend.warten><de> Trasportounito verbirgt ihrerseits nicht, wenige Hoffnungen auf einem positiven Ergebnis von der Versammlung zu hegen: warten“ wir „die mit dem Staatssekretär Improta „festlegt Begegnung, für das Ende von dem Monat von dem Oktober,“,„- hat der Präsident von dem gewerkschaftlichen Verein erklärt, Franco Pensiero -“,„aber sind die Hoffnungen erhalten „herausstellt konkret, zu dem Licht von den neuen Erfahrungen, in der tat knapp.
<G-vec00301-001-s802><attend.warten><en> It is therefore extremely important that we discuss with the parts interested of the challenges that they attend to us in order to fully take advantage of the potential one of the European logistics and the field of the transport of the goods”.
<G-vec00301-001-s802><attend.warten><de> Es ist folglich extrem wichtig, dass wir uns besprechen, mit den interessierten Teilen von den Herausforderungen, die uns warten“, um völlig das Potenzial von der europäischen Logistik von dem Sektor von dem Transport von den Waren und zu nutzen.
<G-vec00301-001-s803><attend.warten><en> Now we attend trusting the argument to the Chamber that can contribute to improve the text substantially”.
<G-vec00301-001-s803><attend.warten><de> Wir warten jetzt die Diskussion zu der Kamera vertrauensvoll, der kann“, grundsätzlich den Text zu verbessern beitragen.
<G-vec00301-001-s804><attend.warten><en> We have supplied to riposizionare wide part of our fleet in the Atlantic, so as to draw the maximum advantage from the bounce of the market that we attend in that area.
<G-vec00301-001-s804><attend.warten><de> Ich provveduto den sehr maximalen Vorteil von dem Abprall von dem Markt zu entnehmen breiten Teil von unserer Flotte in Atlantik zu neu positionieren, der uns in jen Fläche wir warten.
<G-vec00301-001-s805><attend.warten><en> "Same the Olbia, for which we attend still important confirmations, will accommodate new companies: between all a Carnival, that it will arrive with the Breeze new; the Coast Cruises, that it will use the White Island like home port for the Serene Coast, with possibility of boarding and disembarkation directly from our docks, so as has been in 2008 and 2009 with the MSC and 2010 with the same Marine Coast""."
<G-vec00301-001-s805><attend.warten><de> "Olbia wird gleich neue Gesellschaften beherbergen, für welch wir noch wichtige Bestätigungen warten: der Carnival zwischen all, dass es mit dem neuen Breeze kommen wird; costa Kreuzfahrten, dass die Weiße Insel wie Home für Gelassenes Costa, port, mit Möglichkeit von dem an Bord gehen und der Landung von unseren Kais direkt anwenden wird, als 2009 mit dem MSC, 2010 mit der gleichen See Küste folglich in 2008, in und in gewesen ist es""."
<G-vec00301-001-s806><attend.warten><en> The omnipotence of Your Mercy defends us from the assaults of the enemies of our salvation, so that we can attend with trust, as you give birth Yours, Your last arrival in the known day only to You.
<G-vec00301-001-s806><attend.warten><de> Die Allmacht von Deiner Barmherzigkeit verteidigt uns vor den Überfällen von den Feinden von unserer Rettung, so daß wir können mit Vertrauen warten, wie Kinder Dein, Dein letztes Kommen in der bekannte Tag nur zu Dir.
<G-vec00301-001-s807><attend.warten><en> "As the port of Naples cannot more attend, after four years of commissariamento, it needs to return to competitive being""."
<G-vec00301-001-s807><attend.warten><de> "Als nicht kann der Hafen von Neapel, mehr warten, nach vier Jahren von dem Commissariamento benötigt es"" zu dem konkurrenzfähigen Wesen zurückzukehren."
<G-vec00301-001-s808><attend.warten><en> If, as seems, the stall situation is due to the strong perplexities on one of the three indicated members of the college from the government - they have emphasized Truzzi and Finzi - are necessary that the political forces find a fast agreement on another personality of find in a position to carrying out such role: the citizens and the workers of the field cannot attend beyond.
<G-vec00301-001-s808><attend.warten><de> Wenn, als scheint es, die Situation von dem toten Punkt die angibt Komponenten von dem Internat von der Regierung Schuld zu den starken Ratlosigkeiten auf ein von drei ist notwendig ist,- haben betont Truzzi und Finzi -, dass die politischen Kräfte ein schnelles Abkommen auf einer anderen Persönlichkeit von erheben, in der lage solche Rolle auszuführen finden: die Bürger und die Arbeiter von dem Sektor können nicht jenseits warten.
<G-vec00301-001-s809><attend.warten><en> When we were about to go out, The the archbishop was very busy, but you/he/she made us say day to return back and to attend a moment.
<G-vec00301-001-s809><attend.warten><de> Wenn wir, um auszugehen waren im Begriff, DIE der Erzbischof war sehr besetzt, aber es ließ uns Tag rückwärts zurückzukehren sagen und auf einen Augenblick zu warten.
<G-vec00301-001-s810><attend.warten><en> """We attend with confidence - it has said Coast - that the Commission of Appraisal of Environmental impact recognizes the facts: Contorted Sant'Angelo saves the Venetian crocieristica excellence and starts the morphologic and naturalistic reconstruction of the central lagoon""."
<G-vec00301-001-s810><attend.warten><de> "warten wir ""mit Vertrauen,- hat Küste gesagt - als die Kommission von der Bewertung von dem Umwelteinfluss wiedererkennt Fatti: verdreht Sant'Angelo speichert die crocieristica venezianische Exzellenz und beginnt den Wiederaufbau von der zentralen Lagune morphologischen und naturalistica""."
<G-vec00301-001-s811><attend.warten><en> In addition to working on project designs, I deal with a host of different subjects, such as assigning new, urgent tasks to teams, budget topics, committee meetings, but I also take time to attend to strategies or presentations.
<G-vec00301-001-s811><attend.warten><de> Neben der Arbeit am Design der Projekte warten unterschiedlichste Themen auf mich, wie die Beauftragung von Teams mit neuen, akuten Aufgaben, Budget-Themen, Gremien-Termine, aber auch Zeit für Strategie oder Vorträge.
<G-vec00301-001-s812><attend.warten><en> "Ischia Lines has emphasized that ""it does not intend to attend ulteriorly, continuing to battle with the local governments in order to assert own rights, dispersing own resources waiting for yearned for authorizations for the development of an entrepreneurial activity that, moreover, would have to be of free market""."
<G-vec00301-001-s812><attend.warten><de> "Ischia Lines hat betont ""und setzt ""fort, zerstreut Berechtigungen für die Entfaltung von einer unternehmer Tätigkeit begehrt eigene Ressourcen warten auf mit der Gemeindeverwaltung"" um zu ""machen"" zu ""kämpfen"",""eigene Rechte"" zu ""wert_sein"",""der, außerdem müssen"" würde,""von dem freien Markt sein"", dass es ""nicht beabsichtigt"",""des weiteren"" zu ""warten""."
<G-vec00301-001-s813><attend.widmen><en> Nevertheless, the body also has to be in harmony with the soul, it has to provide the soul with inner calm which it can always achieve once it has calmed itself down, i.e., once its needs are met and it can attend to the soul's requirements.
<G-vec00301-001-s813><attend.widmen><de> Dennoch muss der Körper auch in einer gewissen Harmonie mit der Seele stehen, er muss der Seele die innere Ruhe verschaffen, was er stets dann kann, so er selbst ebenfalls zur Ruhe gekommen ist, d.h. seine Bedürfnisse gedeckt sind und er sich nun dem Verlangen der Seele widmen kann.
<G-vec00301-001-s814><attend.widmen><en> Consequently the globalized society tries in public to leave the thought on transcendence to one's own conscience and the free decision of the individual person; it wants to neutralize the questions about the last things in the public debate, in order to be able thus to attend to penultimate matters, with which one thinks to reach a little easier an agreement between the people and the cultures.
<G-vec00301-001-s814><attend.widmen><de> Somit versucht die globalisierte Gesellschaft, in aller Öffentlichkeit die Überlegungen zur Transzendenz dem eigenen Gewissen und der freien Entscheidung des Einzelnen zu überlassen; sie will die Fragen nach den letzten Dingen in der öffentlichen Debatte neutralisieren, um sich so den vorletzten Dingen widmen zu können, bei denen man glaubt, etwas müheloser zu einer Übereinkunft zwischen den Personen und den Kulturen gelangen zu können.
<G-vec00301-001-s815><attend.widmen><en> We shall attend to this responsibility also in future with priority.
<G-vec00301-001-s815><attend.widmen><de> Dieser Aufgabe widmen wir uns auch zukünftig mit Vorrang.
<G-vec00301-001-s816><attend.widmen><en> Forms, sounds, odors, tastes... leave them to the others to attend to.
<G-vec00301-001-s816><attend.widmen><de> Formen, Geräusche, Gerüche, Geschmack... überlass es den anderen, sich ihnen zu widmen.
<G-vec00301-001-s817><attend.widmen><en> Behle explained: „After six years as CEO of MTU Aero Engines, I do not want to extend my contract again, but like to attend to other tasks with regards to my personal life planning.
<G-vec00301-001-s817><attend.widmen><de> Behle erklärte: „Nach sechs Jahren als CEO der MTU Aero Engines möchte ich meinen Vertrag nicht erneut verlängern, sondern mich im Rahmen meiner persönlichen Lebensplanung ab 2014 anderen Aufgaben widmen.
<G-vec00301-001-s818><attend.widmen><en> Next time I'll probably attend more to my geographical centre - I'm only going to play live in the German-speaking area, where the people understand me.
<G-vec00301-001-s818><attend.widmen><de> Wahrscheinlich werde ich mich beim nächsten Mal mehr meinem geografischen Zentrum widmen - live spiele ich ab jetzt nur mehr im deutschsprachigen Raum, wo mich die Leute auch verstehen.
<G-vec00301-001-s819><attend.widmen><en> When “Gilmore Girls” ended, Lauren didn’t take a long break but decided to attend to new film projects.
<G-vec00301-001-s819><attend.widmen><de> "Nach dem Ende von ""Gilmore Girls"" beschloß sie, sich keine längere Auszeit zu gönnen, sondern sich gleich neuen Filmprojekten zu widmen."
<G-vec00301-001-s820><attend.widmen><en> If you have to attend to other things as soon as school is over, block out a specific time each evening for homework completion.
<G-vec00301-001-s820><attend.widmen><de> Wenn du dich anderen Dingen widmen musst, sobald die Schule vorbei ist, dann blocke jeden Abend eine feste Zeit, um deine Hausaufgaben fertigzustellen.
<G-vec00301-001-s821><attend.widmen><en> Attend to that which is yours to attend to.
<G-vec00301-001-s821><attend.widmen><de> Widme dich dem, was an dir ist, dich ihm zu widmen.
<G-vec00301-001-s822><attend.widmen><en> The potential problems connected with the cooling system are numerous and varied and almost undetectable for a private user. Therefore, it is all the more important for the repair shop, as the main contact to the customer, to attend to the matter of the cooling system and coolant, identify problems at an early stage and provide help and advice to its customers.
<G-vec00301-001-s822><attend.widmen><de> Umso wichtiger ist es für die Werkstatt als Hauptkontakt zum Kunden, sich der Thematik Kühlsystem/Kühlmittel zu widmen, Probleme frühzeitig zu erkennen und ihren Kunden mit Rat und Tat zu Seite zu stehen.
<G-vec00042-001-s842><attend.gehen><en> The Bible implies that those who attend church, whether it is God's church or not, without receiving the Holy Spirit are fools.
<G-vec00042-001-s842><attend.gehen><de> Die Bibel impliziert, dass diejenigen, die zur Kirche gehen, egal, ob es Gottes Kirche ist oder nicht, ohne den Heiligen Geist zu empfangen, Narren sind.
<G-vec00042-001-s843><attend.gehen><en> Shopping facilities are not only available in Sydney but also in Orangedale (10 minutes away) und in Whycocomagh (25 minutes away), where the children of the local inhabitants attend school. This is important, as many Canadians live here all year round.
<G-vec00042-001-s843><attend.gehen><de> Einkaufsmöglichkeiten gibt es nicht nur in Sydney, sondern auch in Orangedale in 10 Minuten Entfernung und Whycocomagh in 25 Minuten Entfernung, wo die Kinder der Einheimischen zur Schule gehen, dies ist wichtig, da in dieser Gegend auch sehr viele Kanadier ganzjährig wohnen.
<G-vec00042-001-s844><attend.gehen><en> Atheists may not like the fact that our children attend church and respect God.
<G-vec00042-001-s844><attend.gehen><de> Möglicherweise mißfällt den Gottlo sen, daß unsere Kinder zur Kirche gehen und Gott ehren.
<G-vec00042-001-s845><attend.gehen><en> It is fashion that people are not married in the Church, that children are not baptized, that people do not attend Sunday mass, that people are involved in esotericism.
<G-vec00042-001-s845><attend.gehen><de> Es ist Mode, dass die Menschen nicht kirchlich getraut sind, dass die Kinder nicht getauft sind, dass die Menschen am Sonntag nicht zur Messe gehen, dass die Menschen mit Esoterik zu tun haben.
<G-vec00042-001-s846><attend.gehen><en> """Already the MDGs have helped lift millions of people out of poverty, save countless children's lives and ensure that they attend school,"" Mr. Ban said."
<G-vec00042-001-s846><attend.gehen><de> """Die MDGs haben bereits geholfen, Millionen von Menschen aus der Armut zu bringen, unzählige Kinderleben zu retten und sicherzustellen, dass sie zur Schule gehen,"" sagte Ban."
<G-vec00042-001-s847><attend.gehen><en> Children who do not attend school are often those who work all day, have to cope with disabilities or live in crisis countries or rural regions of sub-Saharan Africa.
<G-vec00042-001-s847><attend.gehen><de> Kinder, die nicht zur Schule gehen, sind oft jene, die ganztägig arbeiten, die mit einer Behinderungen leben oder in Krisenländern beziehungsweise ländlichen Regionen Sub-Sahara Afrikas leben.
<G-vec00042-001-s848><attend.gehen><en> A lot of children can't attend school because they lack the necessary documents and don't exist officially.
<G-vec00042-001-s848><attend.gehen><de> Viele Kinder können nicht zur Schule gehen, weil sie die notwendigen Dokumente nicht besitzen, wie zum Beispiel eine Geburtsurkunde.
<G-vec00042-001-s849><attend.gehen><en> Even with the country at peace, the children and youngsters continued to work from an early age and could often not attend school.
<G-vec00042-001-s849><attend.gehen><de> Selbst als wieder Frieden herrschte, mussten Kinder und Jugendliche weiterhin sehr früh arbeiten und konnten noch immer nicht zur Schule gehen.
<G-vec00042-001-s850><attend.gehen><en> Teacher Jurevičienė intimidated children, telling them that a list has been drawn up of those students who attend church.
<G-vec00042-001-s850><attend.gehen><de> Die Lehrerin Jurevičienė hat die Schüler mit der Behauptung eingeschüchtert, daß die Namen der Schüler, die zur Kirche gehen, aufgeschrieben seien.
<G-vec00042-001-s851><attend.gehen><en> Sanitation plays a big role in gender equity: The amount of girls who attend school has increased substantially due to clean and separated sanitation facilities in schools.
<G-vec00042-001-s851><attend.gehen><de> Sanitäre Grundversorgung spielt eine große Rolle in der Gleichberechtigung der Geschlechter: Die Anzahl der Mädchen, die zur Schule gehen, ist deutlich angestiegen aufgrund sauberer und nach Geschlechtern getrennten sanitären Anlagen in den Schulen.
<G-vec00301-002-s415><attend.annehmen><en> Outsiders no longer attend our holy Masses, the doorbells ring for UPS and other deliveries, but they simply put their boxes at the entrance.
<G-vec00301-002-s415><attend.annehmen><de> Außenstehende nehmen nicht mehr an unseren heiligen Messen teil, die Türklingeln für UPS und andere Lieferungen läuten, aber sie stellen ihre Pakete einfach am Eingang ab.
<G-vec00301-002-s416><attend.annehmen><en> The heads of the VITA, VEWA & ALTO and TUTO divisions report to the Foundation Board and attend meetings of the Foundation Board. Stiftung Marienheim Kontakt
<G-vec00301-002-s416><attend.annehmen><de> Die Leiter/innen der Bereiche VITA, VEWA & ALTO sowie TUTO sind dem Stiftungsvorstand unterstellt und nehmen an Sitzungen des Stiftungsvorstandes teil.
<G-vec00301-002-s417><attend.annehmen><en> 9.2.2005: Fr. Gérard and Clare Kalkwarf attend a lecture of the South African HIV Clinicians' Society at Entabeni Hospital in Durban about managing Tuberculosis and HIV.
<G-vec00301-002-s417><attend.annehmen><de> 9.2.2005: Pater Gerhard und Clare Kalkwarf nehmen an einem Vortrag der Südafrikanischen HIV Kliniker Vereinigung über die Behandlung von Tuberkulose und HIV im Entabeni Hospital in Durban teil.
<G-vec00301-002-s418><attend.annehmen><en> The world’s most renowned brands display their collections exclusively at Baselworld and choose not to attend any other exhibitions, adding extra value to visitors’ experience and potential business outcomes.
<G-vec00301-002-s418><attend.annehmen><de> Die renommiertesten Marken der Welt zeigen ihre Kollektionen exklusiv auf der Baselworld und nehmen an keinen anderen Ausstellungen teil, wodurch das Erlebnis der Besucher und die potenziellen Geschäftsergebnisse zusätzliches Wert bekommt.
<G-vec00301-002-s419><attend.annehmen><en> Students from all over the world attend our courses; therefore, you need to make your own way to Mexico.
<G-vec00301-002-s419><attend.annehmen><de> Schüler aus aller Welt nehmen an unseren Kursen teil; daher musst du selbst deine Reise nach Mexiko organisieren.
<G-vec00301-002-s420><attend.annehmen><en> Several uniformed police officers and armed civilians regularly attend the church services of Rev. Grace Masegman and Rev. Fr. Jonash Joyohoy, both of whom work on human rights related programs of the IFI.
<G-vec00301-002-s420><attend.annehmen><de> Uniformierte Polizisten und bewaffnete Zivilisten nehmen demnach regelmäßig an Gottesdiensten von Pfarrerin Grace Masegman und Pfarrer Jonash Joyohoy teil, die beide an Menschenrechtsprojekten der IFI mitarbeiten.
<G-vec00301-002-s421><attend.annehmen><en> They also periodically attend training and refresher courses held not only at the Treviglio and Lauingen Academies, but also at local training centres.
<G-vec00301-002-s421><attend.annehmen><de> Regelmäßig nehmen sie an Fort- und Weiterbildungsmaßnahmen teil – nicht nur in der Academy von Treviglio und Lauingen, sondern auch in regionalen Schulungszentren.
<G-vec00301-002-s422><attend.annehmen><en> The INSCA members attend each year meetings that are taking part in different countries worldwide.
<G-vec00301-002-s422><attend.annehmen><de> Die INSCA-Mitglieder nehmen jährlich an Treffen teil die in verschiedenen Ländern der ganzen Welt stattfinden.
<G-vec00301-002-s423><attend.annehmen><en> As we change hemispheres, you will attend a ceremony organised in a fun and festive atmosphere: with white togas, Neptune’s trident and fancy dress on the agenda.
<G-vec00301-002-s423><attend.annehmen><de> Während Sie die Halbkugel wechseln, nehmen Sie an einer Zeremonie in fröhlich-festlicher Stimmung teil: weiße Togen, Dreizack des Neptun und Fantasieverkleidungen stehen auf dem Programm.
<G-vec00301-002-s424><attend.annehmen><en> If you become a member of the Amis de l’OPL, you will receive information about the Orchestra every month and you will be given the opportunity to take part in trips organised by the Amis to OPL concerts outside Luxembourg, to attend rehearsals open exclusively to members of the Amis and benefit from reduced ticket prices for the «Concerts-apéritif».
<G-vec00301-002-s424><attend.annehmen><de> Als Mitglied der Amis de l’OPL erhalten Sie monatlich Informationen über das Orchester, reisen zu OPL-Konzerten außerhalb Luxemburgs, nehmen an exklusiven öffentlichen Proben teil und profitieren von Ermäßigungen auf die «Concerts-apéritif».
<G-vec00301-002-s425><attend.annehmen><en> These cooperation partners also attend meetings of the OSCE bodies.
<G-vec00301-002-s425><attend.annehmen><de> Diese Kooperationspartner nehmen auch an Treffen der OSZE-Gremien teil.
<G-vec00301-002-s426><attend.annehmen><en> Training centres often organise excursions for their clients or attend sports or cultural events.
<G-vec00301-002-s426><attend.annehmen><de> Die Ausbildungszentren organisieren oft Ausflüge für ihre Kunden oder nehmen mit ihnen an Sport- oder Kulturveranstaltungen teil.
<G-vec00301-002-s427><attend.annehmen><en> Almost all three- and four-year-olds attend some kind of preschool program.
<G-vec00301-002-s427><attend.annehmen><de> Nahezu alle drei- und vierjährigen Kinder nehmen an einer Form von Vorschulerziehung teil.
<G-vec00301-002-s428><attend.annehmen><en> Local Lions attend and contribute to the national and regional trachoma planning meetings that review progress and develop strategy.
<G-vec00301-002-s428><attend.annehmen><de> Lokale Lions nehmen an nationalen und regionalen Trachom-Planungstreffen teil, in denen Fortschritte überblickt und Strategien entwickelt werden.
<G-vec00301-002-s138><attend.begleiten><en> We appreciate to advise you with your product strategy and offer you to attend in time on the shortest possible way to a serial production.
<G-vec00301-002-s138><attend.begleiten><de> Gerne beraten wir Sie unverbindlich bei Ihrer Produktstrategie und bieten Ihnen an, Sie frühzeitig auf dem kürzest möglichen Weg bis zur Serienlieferung zu begleiten.
<G-vec00301-002-s139><attend.begleiten><en> Waste, death, and destruction attend a fight for a better life.
<G-vec00301-002-s139><attend.begleiten><de> Verfall, Tod und Zerstörung begleiten den Kampf für ein besseres Leben.
<G-vec00301-002-s140><attend.begleiten><en> We attend you with all fiscal matters and keep our promises.
<G-vec00301-002-s140><attend.begleiten><de> Wir begleiten Sie bei finanzbehördlichen Agenden und halten unser Versprechen.
<G-vec00301-002-s141><attend.begleiten><en> You will attend the mounting and the installation of our plasma monitors and projection devices in warehouses and shopping centres.
<G-vec00301-002-s141><attend.begleiten><de> Sie werden die Aufbauarbeiten und die Montage unserer Plasma-Monitore und Projektionsanlagen in den Warenhäusern und Einkaufszentren begleiten.
<G-vec00301-002-s142><attend.begleiten><en> Furthermore, the employees attend to local and regional agenda initiatives and promote the German-Czech cooperation.
<G-vec00301-002-s142><attend.begleiten><de> Daneben begleiten die Mitarbeiter lokale und regionale Agenda-Initiativen und fördern die deutsch-tschechische Zusammenarbeit.
<G-vec00301-002-s144><attend.begleiten><en> We attend acceptance procedures at suppliers, coordinate the contractors and accompany the project through to completed installation.
<G-vec00301-002-s144><attend.begleiten><de> Wir begleiten Werksabnahmen bei den Zulieferern, koordinieren die Fremdfirmen und begleiten das Projekt bis zur abnahmefähigen Installation.
<G-vec00301-002-s145><attend.begleiten><en> Unfortunately Kinsky had another fever attack and could not attend the Nizam’s gala dinner that was set for 8 o’clock.
<G-vec00301-002-s145><attend.begleiten><de> Leider hatte Kinsky wieder einen Fieberanfall, so dass er mich nun zu dem folgenden Gala-Diner beim Nisam, welches für 8 Uhr angesagt war, nicht begleiten konnte.
<G-vec00301-002-s146><attend.begleiten><en> We will attend you kindly and you will be surprised by our professionalism.
<G-vec00301-002-s146><attend.begleiten><de> Wir werden Sie freundlich begleiten und Sie werden von unserer Professionalität überrascht sein.
<G-vec00301-002-s147><attend.begleiten><en> In the summer of 2013 I had the opportunity to attend the work of the organization “Aktive Direkt Hilfe” in the Congo directly on-site for three weeks.
<G-vec00301-002-s147><attend.begleiten><de> Im Sommer 2013 durfte ich die Arbeit des Vereins "Aktive Direkt Hilfe" im Kongo direkt vor Ort für drei Wochen begleiten.
<G-vec00301-002-s148><attend.begleiten><en> Hence we attend our clients in more than 60% of all project internationally.
<G-vec00301-002-s148><attend.begleiten><de> Entsprechend begleiten wir unsere Kunden in über 60% aller Projekte international.
<G-vec00301-002-s149><attend.begleiten><en> As a well experienced partner we attend and support you and your family during your integration and settle in Switzerland.
<G-vec00301-002-s149><attend.begleiten><de> Als zuverlässiger Ansprechpartner begleiten und unterstützen wir Sie und Ihre Familie beim Fuß fassen und Einleben in der Schweiz.
<G-vec00301-002-s150><attend.begleiten><en> We are also happy to attend your celebration for several days – just according to your wishes.
<G-vec00301-002-s150><attend.begleiten><de> Gerne begleiten wir Euch auch mehrere Tage – ganz nach Euren Wünschen.
<G-vec00301-002-s151><attend.begleiten><en> Teachers of English as an Additional Language (EAL) and Deutsch als Fremdsprache (DaF) (German as a Foreign Language) attend classes with students who require additional support or whose needs have been identified through assessment monitoring from our EAL core teacher.
<G-vec00301-002-s151><attend.begleiten><de> Lehrer für Englisch als Fremdsprache (EAL) und Deutsch als Fremdsprache (DaF) begleiten Schüler im Unterricht, um ihnen diese zusätzliche Förderung entsprechend des von dem EAL/DAF Team erstellten Entwicklungsplans zu ermöglichen.
<G-vec00301-002-s184><attend.beiwohnen><en> We learned that on the floor above us were two family members of Cliff's victims to attend the execution as witnesses.
<G-vec00301-002-s184><attend.beiwohnen><de> Im Stockwerk über uns, erfuhren wir, befanden sich zwei Angehörige von Cliff's Opfern, um der Hinrichtung als Zeugen beizuwohnen.
<G-vec00301-002-s185><attend.beiwohnen><en> The objective of these seminars is twofold. On the one hand, they offer interested parties the chance to attend a presentation given by an internationally renowned scholar.
<G-vec00301-002-s185><attend.beiwohnen><de> Diese Seminare verfolgen zwei Ziele: Einerseits bieten Sie Interessenten die Möglichkeit, einem Vortrag eines international hoch angesehenen Forschers beizuwohnen.
<G-vec00301-002-s186><attend.beiwohnen><en> In recognition of the importance of the agricultural sector, the EU Commission expressed its desire for close cooperation with its representatives at an early stage and invited national agricultural organisations to attend the 1958 Stresa Conference as observers.
<G-vec00301-002-s186><attend.beiwohnen><de> In Anerkennung der Bedeutung des Agrarsektors brachte die EU-Kommission schon frühzeitig ihren Wunsch nach enger Zusammenarbeit mit seinen Vertretern zum Ausdruck und ersuchte die nationalen landwirtschaftlichen Organisationen, der Stresa-Konferenz von 1958 als Beobachter beizuwohnen.
<G-vec00301-002-s187><attend.beiwohnen><en> Yan Shu even took a group of government officials with him to attend Liu Shu's lectures.
<G-vec00301-002-s187><attend.beiwohnen><de> Yan Shu brachte sogar eine Gruppe Regierungsbeamte mit, um Liu Shus Vorlesungen beizuwohnen.
<G-vec00301-002-s189><attend.beiwohnen><en> The brilliant scientist personally invites you to attend its biggest experiment: the creation of a homunculus.
<G-vec00301-002-s189><attend.beiwohnen><de> Der geniale Wissenschaftler persönlich lädt Sie ein, seinem größten Experiment beizuwohnen: Der Erschaffung eines Homunculus.
<G-vec00301-002-s190><attend.beiwohnen><en> The architect was therefore forced to attend the project only as a consultant and to cede all his intellectual property rights to the city of Dubai.
<G-vec00301-002-s190><attend.beiwohnen><de> Demnach wurde der Architekt genötigt, lediglich als Berater dem Projekt beizuwohnen und die Rechte an seinem geistigen Eigentum komplett an die Stadt Dubai abzutreten.
<G-vec00301-002-s191><attend.beiwohnen><en> He had suggested to his secretary that she also attend the execution, but she turned down the invitation.
<G-vec00301-002-s191><attend.beiwohnen><de> Zuvor hatte er noch seiner Sekretärin vorgeschlagen, der Hinrichtung ebenfalls beizuwohnen, was diese ablehnte.
<G-vec00301-002-s193><attend.beiwohnen><en> All students are warmly invited to attend the public part of the meetings.
<G-vec00301-002-s193><attend.beiwohnen><de> Alle Studierenden sind herzlich eingeladen dem öffentlichen Teil der Sitzung beizuwohnen.
<G-vec00301-002-s194><attend.beiwohnen><en> Each year, around 2,500 participants from the Department of General Internal Medicine meet at the largest Swiss medical congress to attend the wide range of training courses available to hospital physicians and general practitioners.
<G-vec00301-002-s194><attend.beiwohnen><de> Am größten medizinischen Fachkongress der Schweiz vereinen sich alljährlich rund 2’500 Teilnehmende des Fachbereichs Allgemeine Innere Medizin, um der breiten Palette an Fortbildungsangeboten für Spitalmediziner und Hausärzte beizuwohnen.
<G-vec00301-002-s195><attend.beiwohnen><en> The appointed representative may appoint a maximum of 2 witnesses and 2 substitute witnesses to attend the voting operations.
<G-vec00301-002-s195><attend.beiwohnen><de> Der Bevollmächtigte kann eventuell höchstens 2 Wahlbeobachter und 2 Stellvertreter benennen, um den Vorgängen beizuwohnen.
<G-vec00301-002-s196><attend.belegen><en> If you have already attended or currently attend "Human Factors 1", the credit points can be recognised.
<G-vec00301-002-s196><attend.belegen><de> Sollten Sie "Human Factors 1" schon belegen oder belegt haben, kann die Prüfungsleistung anerkannt werden.
<G-vec00301-002-s197><attend.belegen><en> In addition to the innovations of ISH exhibitors on show, visitors will have the chance to attend over 30 interesting workshops and lectures on holistic bathroom planning during the fair.
<G-vec00301-002-s197><attend.belegen><de> Neben den gezeigten Innovationen der Aussteller kann der Besucher während der ISH über 30 interessante Workshops und Vorträge rund um die ganzheitliche Badplanung belegen.
<G-vec00301-002-s198><attend.belegen><en> We strongly recommend that you attend courses in the host university’s teaching language or national language at the Language Center of the University of Zurich and ETH Zurich as early as possible.
<G-vec00301-002-s198><attend.belegen><de> Es ist sehr empfehlenswert, frühzeitig beim Sprachenzentrum Sprachkurse in der Unterrichtssprache und/oder Landessprache der Gasthochschule zu belegen.
<G-vec00301-002-s199><attend.belegen><en> Therefore, you should only attend the colloquium after you have started working on your thesis.
<G-vec00301-002-s199><attend.belegen><de> Deshalb sollten Sie das Master-Kolloquium erst belegen, wenn Sie ein Masterarbeitsthema haben und mit der Bearbeitung dieses Themas begonnen haben.
<G-vec00301-002-s200><attend.belegen><en> When you have decided which course you would like to attend, the best way to register is to fill out our registration form and we will get in touch with you immediately!
<G-vec00301-002-s200><attend.belegen><de> Wenn Sie sich entschieden haben welchen Kurs Sie belegen möchten ist die einfachste Form sich an unserer Schule anzumelden indem Sie unser online Anmeldeformular ausfüllen.
<G-vec00301-002-s201><attend.belegen><en> There are university modules you can attend, exams that need to be passed – it's all an ongoing process.
<G-vec00301-002-s201><attend.belegen><de> Es gibt Hochschulmodule, die man belegen kann, Prüfungen müssen gemeistert werden – alles findet kontinuierlich statt .
<G-vec00301-002-s202><attend.belegen><en> 5th Semester Why the decision has been made on this degree course: Already on the Commercial High School it was clear that I will attend a economic degree program.
<G-vec00301-002-s202><attend.belegen><de> Warum die Entscheidung auf diesen Studiengang gefallen ist: Schon auf dem Wirtschaftsgymnasium war mir klar, dass ich ein stark wirtschaftsgeprägten Studiengang belegen werde.
<G-vec00301-002-s204><attend.belegen><en> The strength of the company rests in the speed of intervention, within 24 hours of the call, day and night, 7 days a week, and in the professionalism of its experts: the MAC SERVICE technicians attend continuous training and updating courses to be able to offer impeccable service.
<G-vec00301-002-s204><attend.belegen><de> Die Stärke des Unternehmens liegt im raschen Handeln, innerhalb von 24 Stunden nach dem Anruf, Tag und Nacht, 7 Tage in der Woche und in der Professionalität seiner Experten: Die Techniker von MAC SERVICE belegen ständig Fort- und Weiterbildungskurse, um einen perfekten Service zu bieten.
<G-vec00301-002-s205><attend.belegen><en> You have the opportunity to attend three different courses at our painting school in Kathmandu in which you can learn the basics of thangka painting in theory and practice.
<G-vec00301-002-s205><attend.belegen><de> Sie haben die Möglichkeit an unserer Malschule in Kathmandu drei verschiedene Kurse zu belegen, in denen Sie die Grundlagen der Thangka Malerei in Theorie und Praxis lernen können.
<G-vec00301-002-s206><attend.belegen><en> You can attend up to as many as 8 lessons per day, according to your own preferences.
<G-vec00301-002-s206><attend.belegen><de> Man kann bis zu 8 Lektionen oder Unterrichtseinheiten (UE) pro Tag belegen, je nach eigenen Bedürfnissen und Wünschen.
<G-vec00301-002-s207><attend.belegen><en> Until that I had always refused me even to enter a dance school, although my wife would occasionally attend a dance class with me.
<G-vec00301-002-s207><attend.belegen><de> Bis dahin nämlich hatte ich mich stets geweigert, eine Tanzschule auch nur zu betreten, obwohl meine Frau hin und wieder einen Tanzkurs mit mir belegen wollte.
<G-vec00301-002-s208><attend.belegen><en> Instruction is organized on a block schedule: from Monday to Saturday, for a whole trimester, students attend the same three courses.
<G-vec00301-002-s208><attend.belegen><de> Der Unterricht ist blockweise organisiert, von Montag bis Samstag belegen die Jugendlichen jeweils ein Trimester lang dieselben drei Kurse.
<G-vec00301-002-s209><attend.belegen><en> You need to attend 7 Masterclass seminars in total.
<G-vec00301-002-s209><attend.belegen><de> Sie müssen insgesamt 7 Masterclassseminare belegen.
<G-vec00301-002-s210><attend.belegen><en> It is particularly important to her that employees are free to decide which training courses to attend, when to attend them and how often.
<G-vec00301-002-s210><attend.belegen><de> Ihr liegt besonders am Herzen, dass es den Mitarbeitenden freisteht, selbst zu entscheiden, welche Weiterbildungskurse sie wann und wie oft belegen.
<G-vec00301-002-s286><attend.besuchen><en> In the morning you will attend the Standard Italian course, from Monday to Friday, from 9:15 to 13:00, with a 25-minute break, for a total of 20 hours per week.
<G-vec00301-002-s286><attend.besuchen><de> Am Vormittag besuchst du den Standard-Kurs in Italienisch, von Montag bis Freitag, von 09.15 bis 13.
<G-vec00301-002-s287><attend.besuchen><en> So, you can take their variety of Arabica coffees back home, or you can even buy them online, or attend one of their coffee courses and learn how to do latte art.
<G-vec00301-002-s287><attend.besuchen><de> Du kannst also ihre Vielfalt an Arabica-Kaffees sogar mit nach Hause nehmen, oder du bestellst einfach online oder du besuchst einen ihrer Kaffeekurse und lernst, wie man Latte Art kreiiert.
<G-vec00301-002-s288><attend.besuchen><en> Vocational school: In addition to your on-the-job training you will attend three-week lesson blocks at the Vocational School of Technology in Schwerin.
<G-vec00301-002-s288><attend.besuchen><de> Berufsschule: Neben deiner betrieblichen Ausbildung besuchst du im wöchentlichen Turnus die Berufliche Schule für Technik in Schwerin.
<G-vec00301-002-s289><attend.besuchen><en> Depending on the level of schooling you have attained, you will attend vocational college on one or two days of the week.
<G-vec00301-002-s289><attend.besuchen><de> Je nach Schulniveau besuchst Du während einem oder zwei Tagen pro Woche die Berufsschule.
<G-vec00301-002-s290><attend.besuchen><en> There are no fees for studying in Germany – unless you attend a private university.
<G-vec00301-002-s290><attend.besuchen><de> Das Studium ist in Deutschland kostenlos – außer du besuchst eine private Hochschule.
<G-vec00301-002-s291><attend.besuchen><en> Of course, you will also attend the vocational school.
<G-vec00301-002-s291><attend.besuchen><de> Die Berufsschule besuchst du natürlich noch dazu.
<G-vec00301-002-s292><attend.besuchen><en> If you attend an auditorium church you've heard for years about the 'revival' that is coming to the world.
<G-vec00301-002-s292><attend.besuchen><de> Wenn du eine Auditoriumsgemeinde besuchst, dann hast du seit Jahren über die „Erweckung“ gehört, die auf die Welt kommen wird.
<G-vec00301-002-s293><attend.besuchen><en> Talk to the staff and faculty at the school you attend or a theatre you've worked with.
<G-vec00301-002-s293><attend.besuchen><de> Triff dich mit dem Personal und den Lehrern an der Schule, die du besuchst, oder am Theater, mit dem du gearbeitet hast.
<G-vec00301-002-s294><attend.besuchen><en> Make sure to bring along your card and collect your stamp whenever you attend the show.
<G-vec00301-002-s294><attend.besuchen><de> Achte darauf, deine Karte mitzubringen und deinen Stempel zu kassieren, wenn du die Show besuchst.
<G-vec00301-002-s314><attend.betreuen><en> Our consulting services attend to our customers in all projects and operating phases, and our services are specifically managed services that assist our customers primarily in an efficient operational management of the SAP system landscape.
<G-vec00301-002-s314><attend.betreuen><de> Unsere Consulting Dienstleistungen betreuen unsere Kunden in allen Projekt und Betriebsphasen, unsere Services sind spezifische Managed Services die unsere Kunden primär in einer effizienten Betriebsführung der SAP Systemlandschaft unterstützen.
<G-vec00301-002-s315><attend.betreuen><en> As general planners, we attend to all the needs of your construction project - whether a simple utility building or a complex one with special design requirements, and from the initial planning concept to completion on schedule and within budget.
<G-vec00301-002-s315><attend.betreuen><de> Wir betreuen als Generalplaner Ihre Bauaufgabe - von einfachen Zweckbauten bis hin zu Gebäuden mit besonderen gestalterischen Ansprüchen und vom ersten Planungskonzept bis zur termin- und kostengerechten Fertigstellung.
<G-vec00301-002-s316><attend.betreuen><en> Hence, we assist German clients with international projects and attend to a multiplicity of foreign clients who are commercially active in Germany.
<G-vec00301-002-s316><attend.betreuen><de> So begleiten wir deutsche Mandanten bei ihren internationalen Projekten und betreuen eine Vielzahl ausländischer Mandanten bei ihren Unternehmungen in Deutschland.
<G-vec00301-002-s317><attend.betreuen><en> Hospitalization On the ward the specialists attend to hospitalized patients of the Unit, and other hospitalized patients in the clinic, with complex or multiple pathologies, who need the additional intervention by an internist.
<G-vec00301-002-s317><attend.betreuen><de> Auf der Station betreuen die Fachärzte die stationären Patienten der Inneren Medizin, sowie andere stationäre Patienten der Klinik, die aufgrund ihrer komplexen und verschiedenen Pathologien die ergänzende Intervention eines Internisten erfordern.
<G-vec00301-002-s318><attend.betreuen><en> We will attend to you right away.
<G-vec00301-002-s318><attend.betreuen><de> Wir werden Sie sofort betreuen.
<G-vec00301-002-s319><attend.betreuen><en> Therefore, according to our beliefs, a specialization in certain fields of law and branches of trade are necessary to advise and attend to a client quickly and with a level of high professional quality.
<G-vec00301-002-s319><attend.betreuen><de> Demzufolge ist nach unserer Überzeugung eine Spezialisierung auf bestimmte Rechtsgebiete und Branchen notwendig, um Mandanten schnell und mit hoher fachlicher Qualität zu beraten und betreuen.
<G-vec00301-002-s320><attend.betreuen><en> Plexus agencies attend to more than 200 clients from the B2B and B2C areas.
<G-vec00301-002-s320><attend.betreuen><de> Plexus-Agenturen betreuen über 200 Kunden aus dem B2B und B2C-Bereich.
<G-vec00301-002-s321><attend.betreuen><en> The curators from the history museum attend the tourists.
<G-vec00301-002-s321><attend.betreuen><de> Die Leiter des Historischen Museums betreuen die Touristen.
<G-vec00301-002-s322><attend.betreuen><en> Villa Ticino Guest House was established in 1992 and is now managed and run by the new team who personally welcome and attend to travellers from all around the globe.
<G-vec00301-002-s322><attend.betreuen><de> Das 1992 gegründete Gästehaus Villa Ticino wird nach wie vor dem neuen Team mit Stolz geführt, die Reisende aus aller Welt persönlich empfangen und betreuen.
<G-vec00301-002-s323><attend.betreuen><en> We attend to customers in trades, industry and
<G-vec00301-002-s323><attend.betreuen><de> Wir betreuen Kunden im Handwerk, in der Industrie und in den Verwaltungen.
<G-vec00301-002-s325><attend.betreuen><en> The boar and the other sows attend occasionally, but always exquisite, the new piglet litters and can be "nervous" of the piglets, while the mother-sow in the meantime be able to meet their feeding needs at rest.
<G-vec00301-002-s325><attend.betreuen><de> Die Eber und die anderen Sauen betreuen gelegentlich, aber grundsätzlich vorzüglich, die neuen Ferkelwürfe und lassen sich von den Ferkeln „nerven“, während die Mutter-Sau in der Zwischenzeit in Ruhe ihrem Fressbedürfnis nachkommen kann.
<G-vec00301-002-s326><attend.betreuen><en> We will attend you kindly in any of our offices.
<G-vec00301-002-s326><attend.betreuen><de> Wir werden Sie in jedem unserer Büros freundlich betreuen.
<G-vec00301-002-s327><attend.betreuen><en> Contact our Call Center, available 24/7, and one of our agents will attend you in your language so that you can explain your case in detail and we can contact one of our doctors collaborating in the Port of Pollensa.
<G-vec00301-002-s327><attend.betreuen><de> Wenden Sie sich an unser Call Center, das rund um die Uhr erreichbar ist, und einer unserer Mitarbeiter wird Sie in Ihrer Sprache betreuen, damit Sie Ihren Fall ausführlich erläutern können, und wir können einen unserer Ärzte kontaktieren, der im Hafen von Pollensa arbeitet.
<G-vec00301-002-s353><attend.gehen><en> In 1828 and 1829 Hans Christian Andersen took his exams so he could eventually attend university.
<G-vec00301-002-s353><attend.gehen><de> 1828 und 1829 wurde Andersen geprüft und konnte schließlich auf die Universität gehen.
<G-vec00301-002-s354><attend.gehen><en> People regularly attend worship and donate money, many of them not looking for salvation but magical overnight prosperity.
<G-vec00301-002-s354><attend.gehen><de> Die Menschen gehen regelmäßig zur Messe und spenden Geld, wobei viele nicht ihr Seelenheil suchen, sondern eher einen wundersamen Reichtum über Nacht.
<G-vec00301-002-s355><attend.gehen><en> After moving to the U.S. to attend college, Blitz continued to hone his musical skills, releasing several mixtapes as an undergrad at Kent State University.
<G-vec00301-002-s355><attend.gehen><de> Nachdem er in die U.S.A. gezogen war um dort zum College zu gehen, veröffentlichte er mehrere Mixtapes als Student an der Kent State University, um weiter an an seinen musikalischen Fähigkeiten zu arbeiten und sich zu verbessern.
<G-vec00301-002-s356><attend.gehen><en> In the evenings they can attend the mini disco or take part in a performance in the open air theatre.
<G-vec00301-002-s356><attend.gehen><de> Abends gehen sie in die Minidisco oder treten im Freilichttheater auf.
<G-vec00301-002-s357><attend.gehen><en> A complex set of personal, work-related and societal factors, which influence the decision to attend at work despite of illness, could be identified.
<G-vec00301-002-s357><attend.gehen><de> Es konnte ein komplexes Geflecht an persönlichen, arbeitsbedingten und gesellschaftlichen Faktoren herausgearbeitet werden, die die Entscheidung, trotz einer Erkrankung arbeiten zu gehen, beeinflussen.
<G-vec00301-002-s359><attend.gehen><en> Many Jews who define themselves as secular, attend synagogue and fast on this special day.
<G-vec00301-002-s359><attend.gehen><de> Viele Juden, die sich ansonsten als säkular bezeichnen würden, gehen an diesem besonderen Tag in die Synagoge.
<G-vec00301-002-s360><attend.gehen><en> You can also attend talks and presentations, or take part in activities for children and adults alike.
<G-vec00301-002-s360><attend.gehen><de> Man kann auch zu Vorträgen gehen und sich an Aktivitäten für Kinder und Erwachsene beteiligen.
<G-vec00301-002-s361><attend.gehen><en> One could attend, participate in, and leave Mass without experiencing a sense of community or family as the Body of Christ.
<G-vec00301-002-s361><attend.gehen><de> Man kann zu einer Messe gehen, daran teilnehmen und sie verlassen, ohne ein Gefühl für Gemeinschaft oder Familie als Leib Christi empfunden zu haben.
<G-vec00301-002-s362><attend.gehen><en> They will decide which school and class your child can attend.
<G-vec00301-002-s362><attend.gehen><de> Die Schulbehörde wird entscheiden, in welche Schule und welche Klasse Ihr Kind gehen kann.
<G-vec00301-002-s363><attend.gehen><en> And we were forced to attend the mosque regularly.
<G-vec00301-002-s363><attend.gehen><de> Und man wurde gezwungen, regelmäßig in die Moschee zu gehen.
<G-vec00301-002-s364><attend.gehen><en> In the dormitory, girls from the surrounding area of Amravati will live who would otherwise live too remotely to be able to attend school regularly.
<G-vec00301-002-s364><attend.gehen><de> Im Wohnheim werden Mädchen aus dem weiteren Umland von Amravati wohnen, die sonst zu abgelegen leben würden, um regelmäßig zur Schule gehen zu können.
<G-vec00301-002-s365><attend.gehen><en> Aware of her great desire to attend Church, (Miss) Šukytė used to take her to church every day.
<G-vec00301-002-s365><attend.gehen><de> Da Šukytė deren großen Wunsch kannte, in die Kirche zu gehen, brachte sie das Mädchen jeden Tag in die Kirche.
<G-vec00301-002-s366><attend.gehen><en> Minors can attend the counselling sessions on their own or accompanied by a close person of their choice.
<G-vec00301-002-s366><attend.gehen><de> Zur Beratung kann eine Minderjährige allein oder in Begleitung einer Vertrauensperson gehen.
<G-vec00301-002-s367><attend.gehen><en> For those who are not neighbors to multiculturalism, whose kids do not attend the worst schools and only read the mainstream media, the old Sweden still exists.
<G-vec00301-002-s367><attend.gehen><de> Jene, die keine direkten Nachbarn des Multikulturalismus sind, deren Kinder nicht auf die schlimmsten Schulen gehen müssen und die nur die Mainstream-Medien konsumieren, jene alten Schweden gibt es noch.
<G-vec00301-002-s368><attend.gehen><en> When children are healthy, they can attend school, fight minor illnesses and grow up to reach their potential.
<G-vec00301-002-s368><attend.gehen><de> Gesunde Kinder können zur Schule gehen, kleinere Krankheiten gut überstehen und zu Erwachsenen mit großem Potenzial heranwachsen.
<G-vec00301-002-s369><attend.gehen><en> Although there are many Christians today, we see that many of them in fact only attend church on Sundays, and no clear standard and Word of salvation is found in their hearts.
<G-vec00301-002-s369><attend.gehen><de> Obwohl es heutzutage viele Christen gibt, sehen wir, dass viele von ihnen eigentlich nur am Sonntag in die Kirche gehen und in ihren Herzen kann man weder klare Standards noch das Wort der Rettung finden.
<G-vec00301-002-s370><attend.gehen><en> I then decided to attend the workshop.
<G-vec00301-002-s370><attend.gehen><de> Ich habe mich dann entschieden, zum Workshop zu gehen.
<G-vec00301-002-s371><attend.gehen><en> Lesson 39 discussed the need to attend the temple and perform priesthood ordinances in behalf of those who have died without receiving them.
<G-vec00301-002-s371><attend.gehen><de> In Lektion 39 wurde besprochen, wie wichtig es ist, dass wir in den Tempel gehen und die heiligen Handlungen des Priestertums für diejenigen vollziehen, die gestorben sind, ohne sie empfangen zu haben.
<G-vec00301-002-s372><attend.kommen><en> The visit was successful and the teacher was very pleased that the practitioners were able to attend.
<G-vec00301-002-s372><attend.kommen><de> Der Besuch war erfolgreich und der Lehrer freute sich sehr, daß die Praktizierenden kommen konnten.
<G-vec00301-002-s373><attend.kommen><en> Then the Israelis built the separation Wall between the school and the Palestinian city. At the beginning, an open door in the wall allowed the children from Bethany to continue to attend school.
<G-vec00301-002-s373><attend.kommen><de> Doch nach dem Bau der israelischen Mauer zwischen der Schule und der palästinensischen Stadt gab es zunächst ein Tor, durch das die Kinder aus Betania kommen konnten.
<G-vec00301-002-s374><attend.kommen><en> I was invited to hear him play and decided to attend.
<G-vec00301-002-s374><attend.kommen><de> Ich war eingeladen ihn spielen zu hören und beschloss zu kommen.
<G-vec00301-002-s375><attend.kommen><en> In the meantime, 70 percent of the population above 15 are able to read and write and most children attend school.
<G-vec00301-002-s375><attend.kommen><de> Mittlerweile können dort etwas über 70 Prozent der Menschen über 15 Jahren lesen und schreiben und die meisten Kinder kommen in eine Schule.
<G-vec00301-002-s376><attend.kommen><en> Master: Over eighty percent who attend a Shen Yun Performing Arts performance are first-time patrons.
<G-vec00301-002-s376><attend.kommen><de> Meister: Über 80% der Zuschauer, die zu den Aufführungen von Shen Yun Performing Arts kommen, sind neue Zuschauer.
<G-vec00301-002-s377><attend.kommen><en> And that’s why I was really pleased to get an invitation to attend a high-level briefing with HP brass in Geneva.
<G-vec00301-002-s377><attend.kommen><de> Deshalb hat es mich auch so gefreut, als ich eine Einladung erhielt, nach Genf zu kommen und ein hochklassiges Briefing von den Bossen von HP zu bekommen.
<G-vec00301-002-s378><attend.kommen><en> The delegates who were to be present but could not attend for various reasons had authorized their representatives to deliver their reports: 1.
<G-vec00301-002-s378><attend.kommen><de> Die Vortragenden, die infolge verschiedener Ursachen nicht kommen konnten, haben ihre Vertreter in Moskau bevollmächtigt, ihre Vorträge oder ihre Thesen zu verlesen.
<G-vec00301-002-s379><attend.kommen><en> Silentlambs sent out an open invitation several days in advance to encourage all that could attend to be there.
<G-vec00301-002-s379><attend.kommen><de> Silentlambs schickte mehrere Tage im Voraus eine öffentliche Einladung heraus, um alle, die dort sein könnten, zu ermuntern, zu kommen.
<G-vec00301-002-s380><attend.kommen><en> Unfortunately the owner and founder of the company, Rudolf Grenzebach was unable to attend himself, but in his speech, which was read by his daughter, the many guests learned how the small American firm developed from humble beginnings into a successful company with a staff of more than 100.
<G-vec00301-002-s380><attend.kommen><de> In einem durch seine Tochter überbrachten Grußwort des Firmengründers Rudolf Grenzebach, der selbst leider nicht kommen konnte, erfuhren die Gäste, wie sich die Firma in Amerika aus kleinen Anfängen zu einer Produktionsstätte mit über 100 Mitarbeitern entwickelte.
<G-vec00301-002-s382><attend.kommen><en> Those who missed the final application date or who were unable to attend can schedule an individual interview appointment at any time.
<G-vec00301-002-s382><attend.kommen><de> Wer den letzten Bewerbungstermin verpasst hat oder nicht kommen konnte, kann jederzeit einen individuellen Vorstellungstermin vereinbaren.
<G-vec00301-002-s383><attend.kommen><en> Conversations between educators and day care attendants concerning the personal development of the children that are going to attend the facility are very important, furthermore conversations about the topic “Exercising” help to combine similarities and overcome demarcations.
<G-vec00301-002-s383><attend.kommen><de> Wichtig sind Gespräche zwischen Erzieherinnen und Tagespflegepersonen über die persönliche Entwicklung der Kinder, die in die Einrichtung kommen werden und natürlich über das Thema Bewegung – Gemeinsamkeiten verbinden und helfen, Abgrenzungen zu überwinden.
<G-vec00301-002-s384><attend.kommen><en> Tickets for the original date will still be valid, but if you have bought tickets and cannot attend on the Saturday, please contact your point of sale for a refund.
<G-vec00301-002-s384><attend.kommen><de> Karten für das ursprüngliche Datum sind weiterhin gültig, aber wer Karten gekauft hat und nicht am Samstag kommen kann, sollte seine Vorverkaufsstelle um Preiserstattung bitten.
<G-vec00301-002-s385><attend.kommen><en> With immediate effect, refugees can attend a consultation interview in the International Office every Thursday from 15.00 to 16.00 without prior appointment.
<G-vec00301-002-s385><attend.kommen><de> Ab sofort können Flüchtlinge jeden Donnerstag von 15.00 – 16.00 Uhr ohne vorherige Anmeldung zu einer Sprechstunde ins International Office kommen.
<G-vec00301-002-s386><attend.kommen><en> In case of an emergency and if you have acute symptoms, you can of course always attend without an appointment.
<G-vec00301-002-s386><attend.kommen><de> Im Notfall und bei akuten Beschwerden können Sie selbstverständlich auch ohne Voranmeldung kommen.
<G-vec00301-002-s387><attend.kommen><en> I am asking you to attend this trial.
<G-vec00301-002-s387><attend.kommen><de> Ich bitte euch hiermit, zu diesem Prozess zu kommen.
<G-vec00301-002-s388><attend.kommen><en> It should also be noted that ascertain number of visitors from neighbouring countries attend German trade fairs for personal reasons, while nearly all overseas visitors attend for professional reasons.
<G-vec00301-002-s388><attend.kommen><de> Dabei ist zu berücksichtigen, dass Besucher aus den Nachbarländern in nennenswertem Umfang auch aus privaten Gründen auf deutsche Messen kommen, während die Interessenten aus Übersee fast ausschließlich Fachbesucher sind.
<G-vec00301-002-s389><attend.kommen><en> All students are warmly invited to attend the public part of the meetings.
<G-vec00301-002-s389><attend.kommen><de> Die AStA-Sitzungen finden jeden Montag statt, alle Studierenden sind herzlich eingeladen zu kommen.
<G-vec00301-002-s390><attend.kommen><en> In order to learn all the details of these steps and making them your own it is important to attend all classes of the workshop.
<G-vec00301-002-s390><attend.kommen><de> Es ist wichtig zu allen Klassen zu kommen, um sämtliche Details dieser Schritte zu erlernen.
<G-vec00301-002-s391><attend.kümmern><en> „Dr. Mortimer "But Dr. Mortimer has his practice to attend to, and his house is miles away from yours.
<G-vec00301-002-s391><attend.kümmern><de> -„Doch Dr. Mortimer muss sich um seine Praxis kümmern und sein Haus ist von Ihrem meilenweit entfernt.
<G-vec00301-002-s392><attend.kümmern><en> Baby Care Centres: You can attend to all your baby's needs in the Baby Care Centres located in both Disney Parks.
<G-vec00301-002-s392><attend.kümmern><de> Baby Care Center: Kümmern Sie sich in den Baby Care Centern in den beiden Disney® Parks um die Bedürfnisse Ihres Babys.
<G-vec00301-002-s393><attend.kümmern><en> We will then attend to your enquiry, directly and personally.
<G-vec00301-002-s393><attend.kümmern><de> Wir kümmern uns dann umgehend und persönlich um Ihre Anfrage.
<G-vec00301-002-s394><attend.kümmern><en> We offer solutions for manufacturers, companies of spare parts, competition and we attend to urgent needs repairing or manufacturing customized components.
<G-vec00301-002-s394><attend.kümmern><de> Wir bieten Lösungen für Hersteller, Ersatzteilfirmen und kümmern uns um dringende Reparaturen oder um die Herstellung von kundenspezifischen Komponenten.
<G-vec00301-002-s395><attend.kümmern><en> Apart from the initial coating, we also attend to the cleaning and renovation of metallic façades together with our carefully selected application partners.
<G-vec00301-002-s395><attend.kümmern><de> Neben der Erstbeschichtung kümmern wir uns auch um die Reinigung und Renovierung von Metallfassaden, zusammen mit sorgfältig ausgewählten Applikationspartnern.
<G-vec00301-002-s396><attend.kümmern><en> The combination will force the owners to attend to the "double" lighting, as the functional zones are now also two.
<G-vec00301-002-s396><attend.kümmern><de> Die Kombination wird die Eigentümer zwingen, sich um die "doppelte" Beleuchtung zu kümmern, da die funktionalen Zonen jetzt auch zwei sind.
<G-vec00301-002-s397><attend.kümmern><en> I have some personal business to attend,” I say and the change of plans causes Taylor’s eyebrows to shoot up.
<G-vec00301-002-s397><attend.kümmern><de> Ich muss mich um eine private Angelegenheit kümmern“, sage ich und diese Planänderung lässt Taylors Augenbrauen nach oben schnellen.
<G-vec00301-002-s398><attend.kümmern><en> Integrity “I deal with many different customers every day who call us for various reasons and whose affairs we attend to.
<G-vec00301-002-s398><attend.kümmern><de> "Ich habe tagtäglich mit vielen verschiedenen Kunden zu tun, die aus ganz unterschiedlichen Gründen bei uns anrufen und um deren Anliegen wir uns kümmern.
<G-vec00301-002-s399><attend.kümmern><en> At Funidelia we use the information you provide in order to manage the contractual relationships established with you. (Send the order to the correct person and address, attend to any requests or questions you may have, send you all the necessary information about your purchases and provide you with information about Funidelia's products).
<G-vec00301-002-s399><attend.kümmern><de> In Funidelia verwenden wir die Informationen, die Sie uns zur Verfügung stellen, um die mit Ihnen eingegangenen Vertragsbeziehungen zu verwalten (das Senden der Bestellung an die richtige Person und Adresse, das Kümmern um Ihre Anfragen oder Zweifel, das Senden aller notwendigen Informationen über Ihre Einkäufe und die Versorgung mit Informationen über die Produkte von Funidelia).
<G-vec00301-002-s400><attend.kümmern><en> So now if you’d excuse me, ladies and gentlemen, I have some listening to attend to.
<G-vec00301-002-s400><attend.kümmern><de> Und nun entschuldigt mich, werte Damen und Herren, ich muss mich um einige Hörproben kümmern.
<G-vec00301-002-s401><attend.kümmern><en> We know that planning all details is crucial and, therefore, we will plan the journey flawless, so that you can attend other organizational elements.
<G-vec00301-002-s401><attend.kümmern><de> Wir wissen, dass die Planung aller Details wesentlich ist und deswegen werden wir die Reise perfekt organisieren, sodass Sie sich um andere organisatorische Einzelheiten kümmern können.
<G-vec00301-002-s403><attend.kümmern><en> Providing its guests with unparalleled service, the hotel offers round-the-clock, dedicated butlers to attend to every need.
<G-vec00301-002-s403><attend.kümmern><de> Das Hotel bietet seinen Gästen rund um die Uhr einen unvergleichlichen Service mit engagierten Butlern, die sich um jedes Bedürfnis kümmern.
<G-vec00301-002-s405><attend.kümmern><en> To practice the religion means to attend to your own heart and mind.
<G-vec00301-002-s405><attend.kümmern><de> Die Lehre zu praktizieren bedeutet, sich um das eigene Herz zu kümmern.
<G-vec00301-002-s124><attend.sein><en> Venturesome participants are provided the opportunity to attend their examinations.
<G-vec00301-002-s124><attend.sein><de> Risikofreudigen Teilnehmern wird die Möglichkeit geboten, bei ihren Prüfungen anwesend zu sein.
<G-vec00301-002-s125><attend.sein><en> French President Emmanuel Macron and Commission boss Jean-Claude Juncker were also slated to attend.
<G-vec00301-002-s125><attend.sein><de> Auch der französische Präsident Emmanuel Macron und Kommissionschef Jean-Claude Juncker sollten dabei anwesend sein.
<G-vec00301-002-s128><attend.sein><en> He was unable to attend the 2011 prize-giving ceremony in Berlin in person owing to a travel ban that had been imposed on him.
<G-vec00301-002-s128><attend.sein><de> Bei der Preisverleihung 2011 in Berlin konnte er nicht persönlich anwesend sein, da ihm zuvor ein Reiseverbot erteilt worden war.
<G-vec00301-002-s129><attend.sein><en> In the course of this activity, they will also attend various events.
<G-vec00301-002-s129><attend.sein><de> Im Zuge dessen werden Sie auch zu verschiedenen Veranstaltungen anwesend sein.
<G-vec00301-002-s130><attend.sein><en> The most important purpose of the Summer Service radio is to transmit the sermons to those who are not able to attend the services.
<G-vec00301-002-s130><attend.sein><de> Die wichtigste Aufgabe des Versammlungsradios ist es, die Predigten für diejenigen Menschen zu übertragen, die nicht anwesend sein können.
<G-vec00301-002-s131><attend.sein><en> Ridam will attend the PLMA’s annual “World of Private Label” International Trade Show.
<G-vec00301-002-s131><attend.sein><de> Ridam wird anwesend sein auf der PLMA jährlichen „Welt der Handelsmarken“ Internationale Fachmesse.
<G-vec00301-002-s133><attend.sein><en> Your efforts to attend will make a difference.
<G-vec00301-002-s133><attend.sein><de> Eure Bemühungen, anwesend zu sein, machen viel aus.
<G-vec00301-002-s134><attend.sein><en> Ms. Hu had to be carried to the courtroom to attend the hearing.
<G-vec00301-002-s134><attend.sein><de> Sie musste zum Gerichtssaal getragen werden, um bei der Anhörung anwesend zu sein.
<G-vec00301-002-s135><attend.sein><en> The directors Kurt Reinhard and Christoph Schreiber and ELA Co-director Dan Kaufman will attend the screening. Please find more details on our events page.
<G-vec00301-002-s135><attend.sein><de> Die Regisseure Kurt Reinhard und Christoph Schreiber sowie der Gründer der ELA, Dan Kaufman, werden bei der Filmvorführung anwesend sein.
<G-vec00301-002-s136><attend.sein><en> I hadn’t even been able to attend one of their conferences before.
<G-vec00301-002-s136><attend.sein><de> Ich hatte noch nicht einmal die Gelegenheit bei einer ihrer Kongresse anwesend zu sein.
<G-vec00301-002-s137><attend.sein><en> The person who invited them may not attend the meeting, and they may not be on the Diamond Club member’s team, but Diamond Club members are responsible for ensuring that enrollees are placed on the correct team and under the WA who referred them.
<G-vec00301-002-s137><attend.sein><de> Die Person, von der der neue IPC eingeladen wurde, muss selbst nicht anwesend sein und muss auch nicht zu dem Team des Diamond Club Teilnehmers gehören, aber der Diamond Club Teilnehmer muss dafür sorgen, dass der neue IPC in das korrekte Team kommt und unter der Person platziert wird, von der sie eingeladen wurde.
<G-vec00301-002-s406><attend.sich_kümmern><en> We are located in the city of Santiago de Cali and attend to various companies of municipalities and surrounding Calidad Integral SAS
<G-vec00301-002-s406><attend.sich_kümmern><de> Wir sind in der Stadt Santiago de Cali und kümmern sich um verschiedene Unternehmen der Gemeinden und die umliegenden Bezirke.
<G-vec00301-002-s409><attend.sich_kümmern><en> Nearly 40 employees from the fields of marine electronics, blacksmithing and motor services attend to the requirements of our customers in a customer-oriented and efficient manner.
<G-vec00301-002-s409><attend.sich_kümmern><de> Fast 40 Mitarbeiter aus den Bereichen Schiffselektrik, Schlosserei und Motorenservice kümmern sich kundenorientiert und effizient um die Anforderungen unserer Kunden.
<G-vec00301-002-s411><attend.sich_kümmern><en> Competent and obliging staff attend to the bookers and guests, true to the cooperation's philosophy, "We are your partner here in the region".
<G-vec00301-002-s411><attend.sich_kümmern><de> Kompetente und zuvorkommende Mitarbeiter kümmern sich um Bucher und Gäste, getreu der Kooperationsphilosophie "wir sind Ihr Partner in Sachen Tagungsgeschäft".
<G-vec00301-002-s412><attend.sich_kümmern><en> Nikki & Gez live next door and will be on hand to explain all that you need to know and to serve you breakfast and attend to all cleaning, & housekeeping.
<G-vec00301-002-s412><attend.sich_kümmern><de> Nikki & Gez wohnen nebenan und werden vor Ort sein, alles zu erklären, die Sie wissen müssen, und Sie das Frühstück zu servieren und kümmern sich um alle Reinigung und Hauswirtschaft.
<G-vec00301-002-s413><attend.sich_kümmern><en> We are located in the city of Santiago de Cali and attend to various companies of municipalities and surrounding Publichilito
<G-vec00301-002-s413><attend.sich_kümmern><de> Wir sind in der Stadt Santiago de Cali und kümmern sich um verschiedene Unternehmen der Gemeinden und Rechnungswesen....
<G-vec00301-002-s414><attend.sich_kümmern><en> Already on-site in the countries of origin, our experts personally attend to efficient quality assurance.
<G-vec00301-002-s414><attend.sich_kümmern><de> Bereits vor Ort in den Herkunftsländern kümmern sich unsere Experten persönlich um eine effiziente Qualitätssicherung.
<G-vec00301-002-s343><attend.teilnehmen><en> I invite all of you to attend it because it is an experience you can not miss!.
<G-vec00301-002-s343><attend.teilnehmen><de> Ich lade euch ein, daran teilzunehmen, denn es ist eine Erfahrung, die Sie nicht verpassen sollten.
<G-vec00301-002-s345><attend.teilnehmen><en> All are welcome to attend and learn about Vipassana Meditation and the Centre.
<G-vec00301-002-s345><attend.teilnehmen><de> Alle Alten Schüler/innen sind willkommen, daran teilzunehmen.
<G-vec00301-002-s346><attend.teilnehmen><en> You and your friends are cordially invited to attend.
<G-vec00301-002-s346><attend.teilnehmen><de> Ihr und Eure Freunde seid herzlich eingeladen, daran teilzunehmen.
<G-vec00301-002-s347><attend.teilnehmen><en> Just a few weeks ago they had the grand opening and invited hubby and myself to attend.
<G-vec00301-002-s347><attend.teilnehmen><de> Vor wenigen Wochen war erst die Eroeffnung des Restaurants und sie hatten uns eingeladen, daran teilzunehmen.
<G-vec00301-002-s348><attend.teilnehmen><en> Take advantage of your stay at the Campanile hotel in Glasgow to attend.
<G-vec00301-002-s348><attend.teilnehmen><de> Nutzen Sie die Chance, während Ihres Aufenthalts im Campanile-Hotel in Glasgow daran teilzunehmen.
<G-vec00301-002-s349><attend.teilnehmen><en> It is an intriguing question, considering that the Americans refused to attend these talks before.
<G-vec00301-002-s349><attend.teilnehmen><de> Das ist immer eine sehr heikle Frage, wenn man bedenkt, dass sie sich bisher weigerten, daran teilzunehmen.
<G-vec00301-002-s350><attend.teilnehmen><en> Although not strictly required under Nevisian law, your IBC may conduct periodic meetings even if you elect not to attend. Our Service
<G-vec00301-002-s350><attend.teilnehmen><de> Obwohl es nicht grundsätzlich nach nevisischem Recht erforderlich ist, kann Ihre IBC periodische Sitzungen abhalten, selbst wenn Sie wählen nicht daran teilzunehmen.
<G-vec00301-002-s352><attend.teilnehmen><en> Unfortunately, I will not be able to attend, since I’ll be writing my final exams at that time.
<G-vec00301-002-s352><attend.teilnehmen><de> Leider werde ich selbst nicht in der Lage daran teilzunehmen, da ich mich zu diesem Zeitpunkt im Prüfungsstress befinden werde – wollte aber trotzdem etwas dazu beitragen.
<G-vec00042-002-s171><attend.beiwohnen><en> Throughout the year, you can attend conferences, workshops, screenings, performances, training, and can also see temporary exhibitions.
<G-vec00042-002-s171><attend.beiwohnen><de> Das ganze Jahr über können Sie hier Konferenzen, Workshops, Filmvorführungen, Shows, Weiterbildungen und Sonderausstellungen beiwohnen.
<G-vec00042-002-s172><attend.beiwohnen><en> A member of the opposition division may, at the request of the opposition division, attend such court hearings (see E‑IV, 1.3).
<G-vec00042-002-s172><attend.beiwohnen><de> Der Vernehmung vor dem zuständigen Gericht kann auf Antrag der Einspruchsabteilung ein Mitglied der Einspruchsabteilung beiwohnen (siehe E‑IV, 1.3).
<G-vec00042-002-s173><attend.beiwohnen><en> As long as we do not realize this, however much we read books or attend talks or talk about removing attachment, we will not be able to get rid of attachment.
<G-vec00042-002-s173><attend.beiwohnen><de> So lange wir diese jedoch nicht erkennen, so viele Bücher wir auch lesen, Lehrreden beiwohnen, über das Entfernen von Anhaftung reden, werden wir nicht fähig sein, Anhaftung los zu werden.
<G-vec00042-002-s174><attend.beiwohnen><en> On Sundays, you can attend a two and a half hour Russian mass at 10.30 am, which is a wonderful ceremony.
<G-vec00042-002-s174><attend.beiwohnen><de> Sonntags kann man hier um 10.30 Uhr der zweieinhalbstündigen russischen Messe beiwohnen, einer großartigen Zeremonie.
<G-vec00042-002-s175><attend.beiwohnen><en> This gentle flower fairy will attend a party with other flower fairies.
<G-vec00042-002-s175><attend.beiwohnen><de> Diese sanfte Blumenfee wird einer Partei mit anderen Blumenfeen beiwohnen.
<G-vec00042-002-s176><attend.beiwohnen><en> The resulting sculpture remaining in the exhibition makes it possible for visitors who did not attend the performance to imagine both the performative act and the acoustic / tonal elements of the composition.
<G-vec00042-002-s176><attend.beiwohnen><de> Die daraus entstandene und in der Ausstellung verbleibende Skulptur macht es dann wiederum auch für BesucherInnen die nicht der Performance beiwohnen konnten möglich, sich sowohl den performativen Akt als auch die akustisch/klanglichen Elemente der Komposition vorzustellen.
<G-vec00042-002-s178><attend.beiwohnen><en> Media representatives wishing to attend the event are invited to complete and submit this form.
<G-vec00042-002-s178><attend.beiwohnen><de> Medienvertreter, die der Pressekonferenz beiwohnen möchten, sind eingeladen dieses Formular auszufüllen und einzusenden.
<G-vec00042-002-s181><attend.beiwohnen><en> After one hour of playtime, we were able to attend a "roundtable" where we could ask the developers questions specifically about Summerset.
<G-vec00042-002-s181><attend.beiwohnen><de> Nach der einen Stunde Spielzeit konnten wir noch einem „Roundtable“ beiwohnen, bei dem wir den Entwicklern Fragen stellen konnten speziell zu Summerset.
<G-vec00042-002-s182><attend.beiwohnen><en> Visitors to the church are welcome to attend these prayers and enjoy a moment of contemplation and inner peace during the recitation of the psalms.
<G-vec00042-002-s182><attend.beiwohnen><de> Die Benediktinerinnen von Müstair können diesem Gebet gerne beiwohnen und durch das Rezitieren der Psalmen Versenkung und innere Ruhe finden.
<G-vec00042-002-s183><attend.beiwohnen><en> Visitors can sample Mallorcan products and attend a traditional dance performance.
<G-vec00042-002-s183><attend.beiwohnen><de> Besucher können mallorquinische Produkte verkosten und einer traditionellen Tanzvorführung beiwohnen.
<G-vec00042-002-s057><attend.besuchen><en> For example, students may attend Technical College at Fortis Akademie for two years to obtain their University of Applied Sciences entrance qualification.
<G-vec00042-002-s057><attend.besuchen><de> An der Fortis Akademie können Schülerinnen und Schüler unter anderem die Fachoberschule Technik besuchen, um nach zwei Jahren die Fachhochschulreife zu erlangen.
<G-vec00042-002-s058><attend.besuchen><en> For example, in some countries students without an immigrant background perform better in the collaboration-specific aspects of the test when they attend schools with a larger proportion of immigrant students.
<G-vec00042-002-s058><attend.besuchen><de> So erzielen in einigen Ländern Schülerinnen und Schüler ohne Migrationshintergrund bessere Leistungen, wenn sie Schulen mit einem größeren Anteil an Schülern mit Migrationshintergrund besuchen.
<G-vec00042-002-s059><attend.besuchen><en> Compared to a full-time degree, the choice of modules is restricted if you can only attend lessons on the two given days .
<G-vec00042-002-s059><attend.besuchen><de> Die Modulwahl ist gegenüber dem Vollzeitstudium eingeschränkt, wenn Sie den Unterricht nur an den zwei festen Wochentagen besuchen können.
<G-vec00042-002-s060><attend.besuchen><en> Assuming that all children aged 7 to 11 attend school, less than half that number were lucky enough to stay for more than four years.
<G-vec00042-002-s060><attend.besuchen><de> Nimmt man an, daß alle Kinder im Alter von 7-11 Jahren die Schule besuchen, hat nur weniger als die Hälfte das Glück, länger als 4 Jahre in der Schule zu bleiben.
<G-vec00042-002-s061><attend.besuchen><en> Following the tour, you and your class will attend the first half of a dress rehearsal.
<G-vec00042-002-s061><attend.besuchen><de> Im Anschluss an die Führung besuchen Sie mit Ihrer Klasse die erste Hälfte einer Generalprobe.
<G-vec00042-002-s062><attend.besuchen><en> Depending on the problem you come to us with, it may make more sense to attend the open office hours or arrange a specific appointment.
<G-vec00042-002-s062><attend.besuchen><de> E-Mail schreiben Je nach dem, mit welchem Anliegen Sie zu uns kommen, bietet es sich an, die offene Sprechstunde zu besuchen oder einen Beratungstermin zu vereinbaren.
<G-vec00042-002-s063><attend.besuchen><en> Likewise, its varied portfolio of nightlife venues where you can attend flamenco shows, live music for all ages or disco music to dance until dawn is popular recognition.
<G-vec00042-002-s063><attend.besuchen><de> Ebenso ist sein abwechslungsreiches Angebot an Veranstaltungsorten des Nachtlebens, wo Sie Flamenco-Shows, Live-Musik für alle Altersgruppen oder Disco-Musik zum Tanzen bis zum Morgengrauen besuchen können, eine beliebte Anerkennung.
<G-vec00042-002-s064><attend.besuchen><en> Students of 18 years or older (in exceptions 16 or older) can attend our language courses.
<G-vec00042-002-s064><attend.besuchen><de> An der Piccola Università Italiana können Studenten ab 18 (in Ausnahmefällen auch ab 16) unsere Italienischkurse besuchen.
<G-vec00042-002-s065><attend.besuchen><en> Following this morning’s plenary session, delegates will have the opportunity to attend five parallel sessions after lunch.
<G-vec00042-002-s065><attend.besuchen><de> Im Anschluss an die morgendliche Plenarsitzung haben die Teilnehmer am Nachmittag die Möglichkeit, fünf parallele Sektionen zu besuchen.
<G-vec00042-002-s066><attend.besuchen><en> Depending on their level of deafness, pupils are either partially integrated into regular classes or can attend a bilingual secondary level in both sign language and the spoken.
<G-vec00042-002-s066><attend.besuchen><de> Je nach Stufe der Gehörlosigkeit werden die Schülerinnen und Schüler an dieser Schule zum Teil in die regulären Klassen integriert oder können eine zweisprachige Sekundarstufe mit Gebärdensprache und gesprochener Sprache besuchen.
<G-vec00042-002-s211><attend.besuchen><en> DVD If you don’t have neither the time nor the money to attend time consuming dance classes over weeks, you should not miss this dance class on DVD.
<G-vec00042-002-s211><attend.besuchen><de> DVD Wer keine Zeit oder kein Geld für den Besuch wochenlanger Tanzkurse hat, der sollte sich diesen Tanzkurs auf DVD nicht entgehen lassen.
<G-vec00042-002-s212><attend.besuchen><en> Use Promundi to donate blockchain-supported child benefit to enable children in developing countries to attend schools and relieve the burden on their families.
<G-vec00042-002-s212><attend.besuchen><de> Spenden Sie mit Promundi durch Blockchainerträge gestützes Kindergeld, um Kindern in Entwicklungsländern den Besuch von Schulen zu ermöglichen und die Familien zu entlasten.
<G-vec00042-002-s213><attend.besuchen><en> Tickets are required to attend the events.
<G-vec00042-002-s213><attend.besuchen><de> Für den Besuch der Veranstaltungen sind Tickets erforderlich.
<G-vec00042-002-s214><attend.besuchen><en> We promote continual advancement in our staff by giving opportunities to attend tech conferences, meetups, workshops and further training.
<G-vec00042-002-s214><attend.besuchen><de> Wir ermutigen und fördern unsere Mitarbeiter bei kontinuierlicher Weiterentwicklung, indem wir den Besuch von Tech-Konferenzen, Meetups, Workshops und Weiterbildung unterstützen.
<G-vec00042-002-s215><attend.besuchen><en> Every valid ticket entitles one person to attend the performance named on it under the adherence to the respective house rules.
<G-vec00042-002-s215><attend.besuchen><de> Jede gültige Eintrittskarte berechtigt eine Person zum Besuch der darauf angegebenen Vorstellung unter Einhaltung der jeweiligen Hausordnung.
<G-vec00042-002-s216><attend.besuchen><en> intermediate secondary school leaving certificate or an educational qualification recognised as equivalent or entitlement to attend upper secondary school in accordance with the regulations of the respective federal state.
<G-vec00042-002-s216><attend.besuchen><de> Mittlerer Schulabschluss oder ein als gleichwertig anerkannter Bildungsabschluss oder die Berechtigung zum Besuch der gymnasialen Oberstufe nach den Regelungen des jeweiligen Landes.
<G-vec00042-002-s217><attend.besuchen><en> In Germany it is not compulsory for children to attend kindergarten.
<G-vec00042-002-s217><attend.besuchen><de> In Deutschland ist der Besuch des Kindergartens freiwillig.
<G-vec00042-002-s218><attend.besuchen><en> If you are only staying in Munich, Garching or Freising for a few days to attend a conference, or if you need somewhere to stay while searching for accommodation, a wide choice of hotels and youth hostels is available.
<G-vec00042-002-s218><attend.besuchen><de> Für einen kurzen Besuch in München, Garching oder Freising empfehlen sich Hotels und Jugendherbergen - etwa während einer Tagung oder der Wohnungssuche.
<G-vec00042-002-s219><attend.besuchen><en> Tuition is required to attend government or private schools.
<G-vec00042-002-s219><attend.besuchen><de> Besuch staatlicher und privater Schulen erfordert Schulgeld.
<G-vec00042-002-s220><attend.besuchen><en> Many students ask us for support to attend language classes, because this enables them to acquire internationally recognized certificates, that are needed to pursue further studies or a PHD abroad.
<G-vec00042-002-s220><attend.besuchen><de> Viele Studierende bitten uns um Unterstützung beim Besuch von Sprachkursen, weil sie dadurch international anerkannte Zertifikate erwerben können, die sie für ein weiterführendes Studium oder eine Promotion im Ausland benötigen.
<G-vec00042-002-s221><attend.besuchen><en> Please note that photos will be made during the event, and that you consent to the recordings and publications if you attend the event.
<G-vec00042-002-s221><attend.besuchen><de> Bitte beachte, dass während der Veranstaltung Fotoaufzeichnungen angefertigt werden und du mit Besuch der Veranstaltung deine Zustimmung zu den Aufnahmen und etwaigen Veröffentlichungen gibst.
<G-vec00042-002-s222><attend.besuchen><en> However, we recommend you attend a course offered by an accredited training provider.
<G-vec00042-002-s222><attend.besuchen><de> Wir empfehlen aber den Besuch eines Kurses eines akkreditierten Unternehmens.
<G-vec00042-002-s223><attend.besuchen><en> Reserve already today a date in your calendar to attend this interesting event.
<G-vec00042-002-s223><attend.besuchen><de> Reservieren Sie sich heute schon einen Termin in Ihrem Kalender für den Besuch dieser interessanten Messe.
<G-vec00042-002-s224><attend.besuchen><en> In many congregations, the afternoon and evening prayers are recited back-to-back on a working day, to save people having to attend synagogue twice.
<G-vec00042-002-s224><attend.besuchen><de> In vielen Gemeinden betet man werktags die Mittags- und Abendgebete hintereinander, um den Gläubigen einen zusätzlichen Besuch der Synagoge zu ersparen.
<G-vec00042-002-s225><attend.besuchen><en> Mattia Zappa, Cellist, *1973, Switzerland, Scholarship holder 1994-1995, organises the Soweto Project with the pianist Massimiliano Mainolfi. The Zappa/Mainolfi Duo performs a charity concert in November 2009 in New York’s famous Carnegie Hall which enables poor children to attend the Melody Music School of Soweto.
<G-vec00042-002-s225><attend.besuchen><de> Mattia Zappa, Cellist, *1973, Schweiz, Stipendiat 1994-1995, organisiert zusammen mit dem Pianisten Wohltätigkeitskonzert in der berühmten Carnegie Hall New York, welches armen Kindern den Besuch der Melody Music School von Soweto ermöglicht.
<G-vec00042-002-s226><attend.besuchen><en> Doctors who fell short were made to attend workshops "to school them into how to better meet their numbers," German says.
<G-vec00042-002-s226><attend.besuchen><de> Tierärzte, die diesbezüglich ihre Vorgaben nicht erreichten, wurden zum Besuch von Workshops genötigt, "um sie darin zu schulen, bessere Zahlen zu erzielen", sagt German.
<G-vec00042-002-s227><attend.besuchen><en> If you want to attend this year’s European juggling convention and the Pinzgau convention (which would an excellent idea since there is only an interval of 3 days between these conventions), the train ride from Munich will take less than three and a half hours.
<G-vec00042-002-s227><attend.besuchen><de> Falls du den Besuch der diesjährigen Europäischen Jonglierconvention mit dem der Pinzgauer Convention verbinden willst (was übrigens eine ausgezeichnete Idee ist, da nur drei Tage dazwischen liegen): Von München bist du mit der Bahn in weniger als 3,5 Stunden in Bruck.
<G-vec00042-002-s228><attend.besuchen><en> Registration to attend the ADTF 2017 is open.
<G-vec00042-002-s228><attend.besuchen><de> Die Registrierung für den Besuch der ADTF 2017 hat begonnen.
<G-vec00042-002-s230><attend.besuchen><en> I do attend school and I enjoy going to the community.
<G-vec00042-002-s230><attend.besuchen><de> Ich besuche Schule und ich genieße, zur Gemeinschaft zu gehen.
<G-vec00042-002-s231><attend.besuchen><en> I am still so fascinated by it that I continue to attend workshops.
<G-vec00042-002-s231><attend.besuchen><de> Und bin davon so begeistert, dass ich nach wie vor Kurse besuche.
<G-vec00042-002-s232><attend.besuchen><en> Playing as Harry Potter, Ron Weasley™ and Hermione Granger™, as well as other favorite characters, gamers will have the opportunity to attend lessons, cast spells, mix potions, fly on broomsticks and complete tasks to earn house points.
<G-vec00042-002-s232><attend.besuchen><de> Schlüpfe in die Rollen von Harry Potter, Ron Weasley™ und Hermine Granger™ oder anderer beliebter Figuren und besuche als Spieler den Unterricht, verwende Zaubersprüche, mische Zaubertränke, fliege auf einem Besen, meistere Herausforderungen und sammle Punkte für dein Haus.
<G-vec00042-002-s233><attend.besuchen><en> As a member of the Church, I have the blessings of prayer, the scriptures, the ward I attend, and the words of the prophets to give me a deeper understanding of Heavenly Father and the Savior.
<G-vec00042-002-s233><attend.besuchen><de> Als Mitglied der Kirche genieße ich viele Segnungen: Ich kann beten, ich habe die heiligen Schriften, die Gemeinde, die ich besuche, und die Worte der Propheten, die mir ein tieferes Verständnis vom himmlischen Vater und Jesus Christus vermitteln.
<G-vec00042-002-s234><attend.besuchen><en> However, now I believe once more and attend church every other Sunday.
<G-vec00042-002-s234><attend.besuchen><de> Irgendwie glaube ich jetzt etwas mehr und besuche die Kirche jeden zweiten Sonntag.
<G-vec00042-002-s237><attend.besuchen><en> I must say here that I attend a few seminars, since few of them speak to me directly.
<G-vec00042-002-s237><attend.besuchen><de> Ich muss hier sagen, dass ich wenige Seminare besuche, da mich wenige von diesen direkt ansprechen.
<G-vec00042-002-s238><attend.besuchen><en> Then there are all those very tempting bookshelves in the libraries I attend which are created to make me read a book.
<G-vec00042-002-s238><attend.besuchen><de> Und dann sind da natuerlich all die verlockenden Buecherregale in den Buechereien, die ich besuche, die nur dazu da sind, um mich zum Lesen eines Buches zu bringen.
<G-vec00042-002-s239><attend.besuchen><en> The different events that I attend on a regular basis are always highly informative and organised just perfectly.
<G-vec00042-002-s239><attend.besuchen><de> Die unterschiedlichen Veranstaltungen, die ich regelmäßig besuche, sind immer sehr informativ und top organisiert.
<G-vec00042-002-s241><attend.besuchen><en> I attend the TGIT in Schwäbisch Hall.
<G-vec00042-002-s241><attend.besuchen><de> Ich besuche das TGIT in Schwäbisch Hall.
<G-vec00042-002-s242><attend.besuchen><en> You attend rally's down there. I attend the correcting time for Urantia.
<G-vec00042-002-s242><attend.besuchen><de> Ihr macht da unten Rally's, ich besuche die Korrekturzeit von Urantia.
<G-vec00042-002-s243><attend.besuchen><en> I move 24 hours or attend my apartment.
<G-vec00042-002-s243><attend.besuchen><de> Ich ziehe 24 Stunden oder besuche meine Wohnung.
<G-vec00042-002-s244><attend.besuchen><en> Participation in the general membership meetings of the local organizations also goes without saying. Under conditions of legality it is not wise to choose to substitute meetings of local delegates for these periodic membership meetings; on the contrary, all members must be required to attend these meetings regularly.
<G-vec00042-002-s244><attend.besuchen><de> Ganz selbstverständlich ist auch die Teilnahme an den allgemeinen Mitgliederversammlungen der örtlichen Organisationen; es ist nicht gut, diese periodischen Versammlungen unter legalen Verhältnissen durch örtliche Repräsentationen ersetzen zu wollen, vielmehr sollten alle Mitglieder zum regelmäßigen Besuche dieser Versammlungen verpflichtet werden.
<G-vec00042-002-s245><attend.besuchen><en> Attend modeling industry events in your area.
<G-vec00042-002-s245><attend.besuchen><de> Besuche Veranstaltungen der Mode-Branche in deiner Nähe.
<G-vec00042-002-s246><attend.besuchen><en> Yes I practice my faith more and attend worship services regularly.
<G-vec00042-002-s246><attend.besuchen><de> Ja, ich praktiziere meinen Glauben mehr und besuche die Gottendienste regulär.
<G-vec00042-002-s247><attend.besuchen><en> I still continue to attend his lectures and courses. Since 1995, MRC “Valeo”, SWH Medical center, private practice, “Bobath center Attīstība”, Institute of Homeopathy.
<G-vec00042-002-s247><attend.besuchen><de> Ich besuche immer noch seine Kurse und Vorlesungen und seit 1995 MRC "Valeo", SWH Medical Center, private Praxis, "Bobath Zentrum attīstība", Institut für Homöopathie.
<G-vec00042-002-s248><attend.besuchen><en> Traditionals" attend a sweat much as Christians go to church.
<G-vec00042-002-s248><attend.besuchen><de> Traditionelle Indianer besuchen eine "Sweat" genau so wie Christen in die Kirche gehen.
<G-vec00042-002-s249><attend.besuchen><en> I chose to study law at a university in Aleppo that had an elevator, which would enable me to attend lectures and classes.
<G-vec00042-002-s249><attend.besuchen><de> Ich habe mich an der Universität von Aleppo eingeschrieben, um Jura zu studieren, weil sie einen Aufzug hatte, sodass ich auch in der Lage sein würde, die Vorlesungen zu besuchen.
<G-vec00042-002-s250><attend.besuchen><en> During your stay in Villeneuve-Saint-Georges, you will have the chance to attend a play, a one-man-show, a concert and many more shows at the Sud-Est Théâtre.
<G-vec00042-002-s250><attend.besuchen><de> Während Ihres Aufenthalts in Villeneuve-Saint-Georges werden Sie die Gelegenheit haben, ein Theaterstück, eine Ein-Mann-Show, ein Konzert oder viele andere Aufführungen im Sud-Est Théâtre zu besuchen.
<G-vec00042-002-s251><attend.besuchen><en> Children who have reached the age of three can attend the Kindergarten.
<G-vec00042-002-s251><attend.besuchen><de> Den Deutschen Kindergarten können Kinder ab Vollendung des dritten Lebensjahres besuchen.
<G-vec00042-002-s252><attend.besuchen><en> To cover the theoretical programme, apprentices attend the vocational school in Zurich twice a week for subject courses to gain in-depth knowledge of the industry.
<G-vec00042-002-s252><attend.besuchen><de> Um auch die theoretische Ausbildung zu absolvieren, besuchen die Lernenden zwei Mal pro Woche die Berufsschule in Zürich und lernen in den überbetrieblichen Kursen die Branche vertieft kennen.
<G-vec00042-002-s253><attend.besuchen><en> The board consists of parents whose children attend the primary school.
<G-vec00042-002-s253><attend.besuchen><de> Der Vorstand besteht aus Eltern, deren Kinder die Grundschule besuchen.
<G-vec00042-002-s254><attend.besuchen><en> «After the divorce I can attend classes or go to college, instead of accepting a job.
<G-vec00042-002-s254><attend.besuchen><de> «Nach der Scheidung kann ich Kurse besuchen oder auf die Uni gehen, statt einen Job anzunehmen.
<G-vec00042-002-s255><attend.besuchen><en> Each semester approximately 900 students who have been admitted by one of the six universities attend courses at the VWU.
<G-vec00042-002-s255><attend.besuchen><de> Jedes Semester besuchen rund 900 Studierende mit einer Studienzulassung einer Wiener wissenschaftlichen Universität die Kurse am VWU.
<G-vec00042-002-s256><attend.besuchen><en> In Québec, it is compulsory to attend school between the ages of 6 and 16.
<G-vec00042-002-s256><attend.besuchen><de> In Quèbec ist es Pflicht, die Schule vom sechsten bis zum sechzehnten Lebensjahr zu besuchen.
<G-vec00042-002-s257><attend.besuchen><en> Young people from middle-class families are still three times as likely to attend a university-track secondary school as those from families with lower socio-economic background, even with comparable ability and performance.
<G-vec00042-002-s257><attend.besuchen><de> Noch immer haben Jugendliche aus Mittelschichtfamilien etwa dreimal so hohe Chancen ein Gymnasium zu besuchen wie Jugendliche aus Arbeiterfamilien – und dies bei vergleichbarer Begabung und Fachleistung.
<G-vec00042-002-s258><attend.besuchen><en> You attend the theory modules at central locations in Lausanne and Zurich that are easily reachable by public transport.
<G-vec00042-002-s258><attend.besuchen><de> Die Theoriemodule besuchen Sie an zentral gelegenen, mit den öffentlichen Verkehrsmitteln gut erreichbaren Standorten in Lausanne und Zürich.
<G-vec00042-002-s259><attend.besuchen><en> “Of course we will get younger men and women involved very soon, but at the outset we are long-term educators on the highest level, who want to give credibility to a global education initiative for those who will never attend established schools which provide formal theological education,” said newly elected vice-chair, Thomas Schirrmacher, Associate Secretary General for Theological Concerns of the World Evangelical Alliance.
<G-vec00042-002-s259><attend.besuchen><de> „Natürlich werden wir sehr bald auch jüngere Männer und Frauen einbeziehen, aber zu Beginn sind wir altgediente Lehrkräfte auf höchstem Niveau, die einer globalen Bildungsinitiative Vertrauenswürdigkeit verleihen wollen, zum Segen für diejenigen, die nie etablierte Schulen besuchen werden“, sagte der neu gewählte stellvertretende Vorsitzende von Re-Forma und Stellvertretende Generalsekretär für Theologische Fragen der Weltweiten Evangelischen Allianz, Thomas Schirrmacher.
<G-vec00042-002-s260><attend.besuchen><en> Around 1,000 participants attend the conference every year, which has established itself over the past 50 years as a meeting place for experts from the water industry.
<G-vec00042-002-s260><attend.besuchen><de> Rund 1.000 Teilnehmer besuchen die Tagung jährlich, die sich in den vergangenen 50 Jahren als Treffpunkt der Fachwelt aus der Wasserwirtschaft etabliert hat.
<G-vec00042-002-s261><attend.besuchen><en> My attempts to attend an art college were prevented, not because of my ability and talent, but because of my status; I had no father or relatives who were commanders. And I did not know anyone in a high position in the Baath Party, who called me an artist with his finger snap, so I was accepted into a fine arts college.
<G-vec00042-002-s261><attend.besuchen><de> Meine Versuche, eine Kunsthochschule zu besuchen, wurden nicht wegen meines Könnens und meines Talents, sondern wegen meines Status verhindert, ich hatte keinen Vater oder keine Verwandten, die Kommandeure waren und hatte auch keinen, der in einer hohen Position in der Baath Partei war und mit einem Fingerschnipsen mich sofort als Künstler bezeichnet hat, und ich an einer Hochschule für die Schönen Künste angenommen wurde.
<G-vec00042-002-s262><attend.besuchen><en> Therefore they attend language learning classes, pre-courses, and welcome classes to integrate in Germany.
<G-vec00042-002-s262><attend.besuchen><de> Daher besuchen sie Sprachlernklassen, Vorkurse und Willkommensklassen um für ein Leben in Deutschland ausgestattet zu sein.
<G-vec00042-002-s263><attend.besuchen><en> Doctoral students at CES are free to decide on a research area of their interest, and are encouraged to attend international conferences, publish in refereed journals and in a variety of ifo publication outlets.
<G-vec00042-002-s263><attend.besuchen><de> Die Doktoranden des CES erschließen sich selbständig ein Forschungsgebiet ihres Interesses, besuchen internationale Konferenzen und publizieren in referierten Fachzeitschriften sowie den zahlreichen ifo-Produkten.
<G-vec00042-002-s264><attend.besuchen><en> If a student intends to attend individual teaching units and take exams not only at the university to which he/she was admitted, but also at another university, he/she shall enrol at this university as a co-registered student.
<G-vec00042-002-s264><attend.besuchen><de> Beabsichtigt ein/e Studierende/r nicht nur an der Universität, an welcher er/sie zugelassen wurde, sondern auch an einer anderen Universität einzelne Lehrveranstaltungen zu besuchen und Prüfungen abzulegen, so hat er/sie sich an dieser Universität als Mitbeleger/in zu melden.
<G-vec00042-002-s265><attend.besuchen><en> With respect tot their technical field of studies, the students of Business Engineering otherwise attend the same courses as the students enrolled in the corresponding purely technical Master’s programmes.
<G-vec00042-002-s265><attend.besuchen><de> Die Studierenden des Wirtschaftsingenieurwesens besuchen hinsichtlich ihrer technischen Fachrichtung ansonsten aber die gleichen Veranstaltungen wie die Studierenden der entsprechenden rein technischen Master-Studiengänge.
<G-vec00042-002-s266><attend.besuchen><en> The idea is to inform the public of the event and to persuade them to attend.
<G-vec00042-002-s266><attend.besuchen><de> Die Idee ist es, die Öffentlichkeit über die Veranstaltung zu informieren und sie zu überzeugen, zu besuchen.
<G-vec00042-002-s267><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Russians in Ottawa.
<G-vec00042-002-s267><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Ottawa, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s268><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Brazilians in Victoria.
<G-vec00042-002-s268><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Victoria, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s269><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Americans in Jamaica.
<G-vec00042-002-s269><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Jamaika, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s270><attend.besuchen><en> Attend Church meetings regularly (see D&C 59:9–10).
<G-vec00042-002-s270><attend.besuchen><de> Besuchen Sie regelmäßig die Versammlungen der Kirche (siehe LuB 59:9,10).
<G-vec00042-002-s271><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Brazilians in Durban.
<G-vec00042-002-s271><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Durban, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s272><attend.besuchen><en> Attend yoga classes with other girls, and keep your bodies in shape.
<G-vec00042-002-s272><attend.besuchen><de> Besuchen Sie Yoga-Kurse mit anderen Mädchen und halten Sie Ihren Körper in Form.
<G-vec00042-002-s273><attend.besuchen><en> Attend a performance at the Sleep Train Amphitheater, which has chair and lawn seating and hosts top entertainers.
<G-vec00042-002-s273><attend.besuchen><de> Besuchen Sie eine Vorstellung im Sleep Train Amphitheater, das Stühle oder Rasensitzplätze und erstklassige Veranstaltungen anbietet.
<G-vec00042-002-s274><attend.besuchen><en> Attend an open-air concert or simply pack a picnic and lie back on the grass in Hyde Park.
<G-vec00042-002-s274><attend.besuchen><de> Besuchen Sie ein Open-Air-Konzert im Hyde Park oder machen Sie einfach ein Picknick und legen Sie sich ins Gras.
<G-vec00042-002-s275><attend.besuchen><en> Attend our monthly events and activities for Balearic Islands expatriates to get to know like-minded expatriates in real life.
<G-vec00042-002-s275><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Balearen, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s276><attend.besuchen><en> Attend one of our events, workshops or meet us at a job fair.
<G-vec00042-002-s276><attend.besuchen><de> Besuchen Sie eine unserer Veranstaltungen, Workshops oder treffen Sie uns auf einer Karrieremesse.
<G-vec00042-002-s277><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Austrians in Johannesburg.
<G-vec00042-002-s277><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Johannesburg, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s278><attend.besuchen><en> Attend our monthly events and activities for Bergen expatriates to get to know like-minded expatriates in real life.
<G-vec00042-002-s278><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Bali, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s280><attend.besuchen><en> Sustain your Church leaders, pay a full tithing, and attend your Church meetings.
<G-vec00042-002-s280><attend.besuchen><de> Unterstützen Sie die Führer der Kirche, zahlen Sie den vollen Zehnten und besuchen Sie die Versammlungen der Kirche.
<G-vec00042-002-s281><attend.besuchen><en> Attend an enchanting Tahitian dance show called ‘ori Tahiti, or visit a contemporary art exhibition, an unusual play, a traditional or modern concert.
<G-vec00042-002-s281><attend.besuchen><de> Besuchen Sie die tahitianische Tanz-Show ‘ori Tahiti oder besuchen Sie eine Ausstellung moderner Kunst, ein ungewöhnliches Theaterstück sowie ein traditionelles oder modernes Konzert.
<G-vec00042-002-s282><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Swedes in Genoa.
<G-vec00042-002-s282><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Florenz, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s283><attend.besuchen><en> No personal data will be transferred to third parties unless the user has given consent for such purposes, or attend any of the circumstances that would permit such disclosure.
<G-vec00042-002-s283><attend.besuchen><de> Werden keine personenbezogenen Daten an Dritte weitergegeben, es sei denn der Nutzer hat eine erteilte Einwilligung für solche Zwecke, oder besuchen Sie einen der Fälle, dass eine solche Offenlegung erlauben würde.
<G-vec00042-002-s284><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Italians in Tallinn.
<G-vec00042-002-s284><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Tallinn, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s285><attend.besuchen><en> Attend our monthly events and activities and join various interest-based groups to get to know like-minded expatriates and fellow Portuguese in Salzburg.
<G-vec00042-002-s285><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Turin, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-002-s295><attend.besuchen><en> If a visa is granted, you will have to attend classes regularly.
<G-vec00042-002-s295><attend.besuchen><de> Wird Ihnen ein Visum zum Kursbesuch erteilt, muss der Kurs natürlich auch besucht werden.
<G-vec00042-002-s296><attend.besuchen><en> With the qualified secondary school completion, it is possible to attend higher level secondary school.
<G-vec00042-002-s296><attend.besuchen><de> Mit dem qualifizierten Realschulabschluss kann die gymnasiale Oberstufe besucht werden.
<G-vec00042-002-s297><attend.besuchen><en> Most people attend Salzburg Festival performances in pairs, but stay in Salzburg during the Festival in groups of three.
<G-vec00042-002-s297><attend.besuchen><de> Er besucht zu zweit Aufführungen der Salzburger Festspiele, kommt aber überwiegend zu dritt zum Festspielaufenthalt nach Salzburg.
<G-vec00042-002-s298><attend.besuchen><en> Yet statistics show that about half of Americans attend church services weekly. Doesn't this religiosity have a moral impact?
<G-vec00042-002-s298><attend.besuchen><de> Auf der anderen Seite jedoch zeigen die Statistiken, daß ungefähr die Hälfte aller Amerikaner wöchentlich einen Gottesdienst besucht.
<G-vec00042-002-s299><attend.besuchen><en> Due to this my father had psychological difficulties and I was more of a moral help than a real help (even though I had started to attend a technical university).
<G-vec00042-002-s299><attend.besuchen><de> Aus diesem Grund hatte mein Vater psychische Schwierigkeiten und ich war eher eine moralische Hilfe als eine wirkliche Hilfe (obwohl ich eine technische Universität besucht hatte).
<G-vec00042-002-s300><attend.besuchen><en> A very good reason for taking the train to Schaffhausen when you attend an auction in Zurich the next time.
<G-vec00042-002-s300><attend.besuchen><de> Ein guter Grund, den Zug nach Schaffhausen zu nehmen, wenn man das nächste Mal eine Auktion in Zürich besucht.
<G-vec00042-002-s301><attend.besuchen><en> In South Africa, for instance, a child is 30 percent more likely to attend school if his or her family receives remittances.
<G-vec00042-002-s301><attend.besuchen><de> In Südafrika beispielsweise steigt die Wahrscheinlichkeit, dass ein Kind die Schule besucht, um 30 Prozent, wenn die Familie Remittances erhält.
<G-vec00042-002-s302><attend.besuchen><en> The goal of this study was to explore whether students participating in various interrelated communication courses teaching communication skills have higher positive and lower negative attitudes towards learning communication skills compared to students who did not attend such courses.
<G-vec00042-002-s302><attend.besuchen><de> Das Ziel dieser Untersuchung war es, herauszufinden, ob Studierende, die an verschiedenen aufeinander aufbauenden Kommunikationskursen teilgenommen hatten, höhere positive und niedrigere negative Einstellungen gegenüber dem Erlenen von kommunikativen Fähigkeiten hatten als Studierenden, die solche Kurse nicht besucht hatten.
<G-vec00042-002-s303><attend.besuchen><en> If you have applied for grades from particular courses to be recognised, you no longer have to attend those courses.
<G-vec00042-002-s303><attend.besuchen><de> Kurse, für die eine Anrechnung beantragt wurde, müssen nicht mehr besucht werden.
<G-vec00042-002-s304><attend.besuchen><en> So they embark on their journey, read books, attend training courses, obtain certifications, employ hordes of coaches and consultants, visit Spotify, travel to Silicon Valley and so on.
<G-vec00042-002-s304><attend.besuchen><de> Man macht sich also auf den Weg, liest Bücher, besucht Trainings, erwirbt Zertifizierungen, beschäftigt Heerscharen von Coaches und Beratern, besichtigt Spotify, bereist das Silicon Valley und so weiter.
<G-vec00042-002-s305><attend.besuchen><en> Why it's so popular: Again, this is a major press stop for big international comic productions (including blockbuster comic book movies and TV shows) and so big names are likely to attend, drawing a massive crowd. Up-and-coming Conventions
<G-vec00042-002-s305><attend.besuchen><de> Was die Con so beliebt macht: Auch diese Con ist eine wichtige Marketing-Anlaufstelle großer, internationaler Comicproduktionen (einschließlich Blockbuster-Comicfilme und Fernsehshows) und wird daher garantiert von Giganten der Industrie besucht – was wiederum viele Besucher anzieht.
<G-vec00042-002-s306><attend.besuchen><en> Club Sanfrecce Hiroshima Urawa Red Diamonds Gamba Osaka has not been attend by any other user
<G-vec00042-002-s306><attend.besuchen><de> Verein Sanfrecce Hiroshima Urawa Diese Begegnung wurde von keinem anderen User besucht.
<G-vec00042-002-s307><attend.besuchen><en> While the things that are put together will vary according to the college that you have chosen to attend, you can be certain there is a calendar filled with activities that can entertain all.
<G-vec00042-002-s307><attend.besuchen><de> Zwar variieren die Veranstaltungen natürlich je nachdem, welche Universität man besucht, man kann sich jedoch sicher sein, dass der Kalender stets voller Aktivitäten sein wird die viel Unterhaltung versprechen.
<G-vec00042-002-s308><attend.besuchen><en> So, you only come close to the water near the jetties (alternativly, you can attend one of the public bathing places)
<G-vec00042-002-s308><attend.besuchen><de> Man kommt also nur bei den Landungsstegen bis ans Wasser heran, oder man besucht eines der Bäder.
<G-vec00042-002-s309><attend.besuchen><en> He was regarded as one of the most brilliant students ever to attend Hogwarts, a fact admitted by Albus Dumbledore himself. After Hogwarts (1945-1949)
<G-vec00042-002-s309><attend.besuchen><de> In seinem letzten Jahr in Hogwarts war Tom Riddle der Inbegriff eines Musterschülers: Vertrauensschüler, Schulsprecher und einer der brilliantesten Schüler, die Hogwarts jemals besucht hatten.
<G-vec00042-002-s310><attend.besuchen><en> Today, viewers all over the world can “attend” large social sector conferences on their screens – from the NTEN Fundraising Conference to the SOCAP.
<G-vec00042-002-s310><attend.besuchen><de> Viele große Konferenzen im sozialen Sektor, von der NTEN Fundraising Konferenz bis zur SOCAP, können heute von Zuschauern weltweit am heimischen Bildschirm „besucht“ werden.
<G-vec00042-002-s312><attend.besuchen><en> Although that testimony can continue to be fed spiritually and to grow as you study, as you pray for guidance, and as you attend your Church meetings each week, it is up to you to keep that testimony alive.
<G-vec00042-002-s312><attend.besuchen><de> Dieses Zeugnis kann zwar weiterhin geistig genährt werden und wachsen, wenn ihr in den Schriften lest, um Führung betet und jede Woche die Versammlungen der Kirche besucht, aber es ist an euch, dieses Zeugnis lebendig zu halten.
<G-vec00042-002-s313><attend.besuchen><en> To achieve the qualification for trainings on this level, you can attend courses from the Entry or Basics level in advance.
<G-vec00042-002-s313><attend.besuchen><de> Um die Qualifikation für Schulungen auf diesem Level zu erlangen, können vorab Kurse aus dem Einstiegs- oder Grundlagen-Niveau besucht werden.
<G-vec00042-002-s086><attend.teilnehmen><en> Dolkun Isa, Secretary General, World Uyghur Congress, who flew into Washington DC, from Germany was unable to attend the conference.
<G-vec00042-002-s086><attend.teilnehmen><de> Dolkun Isa, der Generalsekretär des Uighurischen Weltkongresses, der von Deutschland aus nach Washington DC geflogen war, konnte leider nicht an der Konferenz teilnehmen.
<G-vec00042-002-s087><attend.teilnehmen><en> All Ambassadors must be able to attend both seminars.
<G-vec00042-002-s087><attend.teilnehmen><de> Alle Teilnehmer des Netzwerks müssen an beiden Seminaren teilnehmen können.
<G-vec00042-002-s088><attend.teilnehmen><en> In this prestigious environment you can attend our exclusive event.
<G-vec00042-002-s088><attend.teilnehmen><de> In diesem repräsentativen Umfeld können Sie an unserer exklusiven Veranstaltung teilnehmen.
<G-vec00042-002-s089><attend.teilnehmen><en> This is convenient for us because we attend a blogger conference for some days.
<G-vec00042-002-s089><attend.teilnehmen><de> Es ist für uns sehr praktisch, da wir einige Tage an einer Blogger Konferenz teilnehmen.
<G-vec00042-002-s090><attend.teilnehmen><en> In May, you will be able to attend one of the most sacred festivals in Nepal in relation to the Buddhist religion: Buddha Jayanti or the birth of Buddha.
<G-vec00042-002-s090><attend.teilnehmen><de> Im Mai können Sie an einem der heiligsten Feste Nepals im Zusammenhang mit der buddhistischen Religion teilnehmen: Buddha Jayanti oder die Geburt von Buddha.
<G-vec00042-002-s091><attend.teilnehmen><en> Representatives of the Federal Ministry of Finance, the Federal Ministry of Justice and the Federal Ministry of Economics and Technology as well as representatives of the Deutsche Bundesbank are also entitled to attend the meetings of the Securities Council.
<G-vec00042-002-s091><attend.teilnehmen><de> An den Sitzungen des Gremiums können auch Vertreter der Bundesministerien der Finanzen und der Justiz und des Bundesministeriums für Wirtschaft und Technologie sowie Vertreter der Deutschen Bundesbank teilnehmen.
<G-vec00042-002-s092><attend.teilnehmen><en> Any competitor has not provided such documents at the latest during the withdrawal of bibs will not be able to attend the event.
<G-vec00042-002-s092><attend.teilnehmen><de> Jeder Konkurrent hat nicht vorgesehen, dass solche Dokumente spätestens bei der Entnahme der Lätzchen nicht an der Veranstaltung teilnehmen können.
<G-vec00042-002-s093><attend.teilnehmen><en> In September, amongst the events in Laos that you can attend, is Boun Khao Salak.
<G-vec00042-002-s093><attend.teilnehmen><de> Im September, im Rahmen der Veranstaltungen in Laos, an denen Sie teilnehmen können, ist der Boun Khao Salak.
<G-vec00042-002-s094><attend.teilnehmen><en> Niche will attend EICMA 2018 in Milan, Italy.
<G-vec00042-002-s094><attend.teilnehmen><de> Niche wird an der EICMA 2018 in Mailand teilnehmen.
<G-vec00042-002-s095><attend.teilnehmen><en> During the fair, you can also attend film screenings and educational workshops which take place as part of the programme.
<G-vec00042-002-s095><attend.teilnehmen><de> Während der Messe können sie an Filmvorführungen und Lehrveranstaltungen teilnehmen.
<G-vec00042-002-s096><attend.teilnehmen><en> For only 250,- Euro per course it is now possible to attend CMII courses as CMII certified individual once again.
<G-vec00042-002-s096><attend.teilnehmen><de> Zum Unkostenbeitrag von nur 250,- Euro pro Kurs können Sie als CMII-zertifizierter Kunde erneut an CMII-Kursen teilnehmen.
<G-vec00042-002-s097><attend.teilnehmen><en> For media accreditation to the events at the Vienna International Centre (VIC) and the Habibi & Hawara restaurant: all Media representatives need to register to be able to attend these events, including those with yearly accreditation to the VIC.
<G-vec00042-002-s097><attend.teilnehmen><de> Für Medienakkreditierung zu den Veranstaltungen im Vienna International Centre (VIC) und im Habibi & Hawara Restaurant: Um an diesen Veranstaltungen teilnehmen zu können, müssen sich alle Medienvertreter registrieren lassen, auch Journalisten mit Jahresakkreditierung im VIC.
<G-vec00042-002-s098><attend.teilnehmen><en> FAQ Registration I would like to attend the Bonn Conference.
<G-vec00042-002-s098><attend.teilnehmen><de> FAQ Anmeldung Ich möchte an der Bonn Conference teilnehmen.
<G-vec00042-002-s099><attend.teilnehmen><en> If you would like to see the Schloss as it once was, you can visit the museum and take a guided tour of the historic rooms, or alternatively, you can attend the annual Schlossfest, a festival which takes place in September.
<G-vec00042-002-s099><attend.teilnehmen><de> Wer die einmalige Atmosphäre des Schlosses erleben möchte, kann an geführten Touren teilnehmen, die historischen Räume im Schlossmuseum besuchen oder jedes Jahr im September beim Schlossfest mitfeiern.
<G-vec00042-002-s100><attend.teilnehmen><en> Unfortunately, according to Hong Kong media that quoted Hong Kong Falun Gong spokesperson Kan Hung-cheung, over the past one week, more than 20 practitioners from other countries or areas who planned to attend the parade were barred from entering Hong Kong by the authorities.
<G-vec00042-002-s100><attend.teilnehmen><de> Hongkong Medien zitierten den Falun Gong-Sprecher von Hongkong Kan Hung-cheung, der berichtete, dass in der vergangenen Woche mehr als 20 Praktizierenden aus anderen Ländern oder Gebieten, die an der Parade teilnehmen wollten, von den Hongkonger Behörden die Einreise nach Hongkong verwehrt wurde.
<G-vec00042-002-s101><attend.teilnehmen><en> I draw inspiration through many different channels; having the honour of being able to attend a variety of events just as movie premiers, art exhibitions and fashion shows I am always surrounded by the latest trends, which I then adapt to my preferences and needs.
<G-vec00042-002-s101><attend.teilnehmen><de> Da ich das Vergnügen habe, an einer Vielzahl von Veranstaltungen wie Filmvorführungen, Kunstausstellungen und Modenschauen teilnehmen zu können, bin ich immer von den neuesten Trends umgeben, die ich dann an meine Vorlieben und Bedürfnisse anpasse.
<G-vec00042-002-s102><attend.teilnehmen><en> Visitors will also be able to attend talks and seminars led by industry experts.
<G-vec00042-002-s102><attend.teilnehmen><de> Zuschauer können zudem an Vorträgen und Seminaren von Branchenexperten teilnehmen.
<G-vec00042-002-s103><attend.teilnehmen><en> (3) In addition, Supervisory Board members shall receive an attendance fee of EUR 2,000 for each Supervisory Board meeting and committee meeting they attend.
<G-vec00042-002-s103><attend.teilnehmen><de> (3) Darüber hinaus erhalten die Mitglieder des Aufsichtsrats für jede Sitzung des Aufsichtsrats und seiner Ausschüsse, an der sie teilnehmen, ein Sitzungsgeld von EUR 2.000.
<G-vec00042-002-s104><attend.teilnehmen><en> We will attend the IFA show and will cover the consumer electronics show live from the show floor.
<G-vec00042-002-s104><attend.teilnehmen><de> Wir werden an der Internationalen Funkausstellung teilnehmen, um live und vor Ort über die Verbraucherelektronikschau zu berichten.
<G-vec00042-002-s105><attend.teilnehmen><en> He came out in 2013 after publicly declining an offer to attend a Russian film festival due to the country's anti-gay laws.
<G-vec00042-002-s105><attend.teilnehmen><de> Er machte seine sexuelle Orientierung im Jahr 2013 öffentlich, nachdem er das Angebot an einem russischen Filmfestival teilzunehmen abgelehnt hatte.
<G-vec00042-002-s106><attend.teilnehmen><en> 30.09.2015 Convening notice The shareholders of NATIXIS AM Funds, are kindly invited to attend the Annual General Meeting of the shareholders of the SICAV which will take place on October 9, 2015 at 10.00 a.m.
<G-vec00042-002-s106><attend.teilnehmen><de> 30.09.2015 Einberufung Die Anteilinhaber von NATIXIS AM Funds sind herzlich eingeladen, an der Jahreshauptversammlung der Anteilinhaber der SICAV teilzunehmen, die in den Geschäftsräumen von CACEIS Bank steht, aber insbesondere für Unicredit vorgesehen ist.
<G-vec00042-002-s107><attend.teilnehmen><en> Suitable candidates are invited to attend an interview with the Academic Director which will cover the way that the PhD relates to and will help your professional development; and your knowledge and appreciation of current thinking in one or more areas of management.
<G-vec00042-002-s107><attend.teilnehmen><de> Geeignete Kandidaten werden aufgefordert, an einem Interview mit dem Lehrgangsleiter teilzunehmen, das die Art und Weise deckt, die das PhD Studium betrifft und Ihrer beruflichen Entwicklung hilft; und Ihr Wissen und Wertschätzung des gegenwärtigen Denkens in einem oder mehreren Bereichen der Verwaltung.
<G-vec00042-002-s108><attend.teilnehmen><en> 12.3 The President shall be entitled to attend all other meetings convened by BWI.
<G-vec00042-002-s108><attend.teilnehmen><de> 12.3 Der Präsident ist berechtigt, an allen von der BHI einberufenen Tagungen teilzunehmen.
<G-vec00042-002-s109><attend.teilnehmen><en> When they understood this, they invited Falun Gong practitioners to attend their seminar and tell other Turkish people about Falun Gong in Germany.
<G-vec00042-002-s109><attend.teilnehmen><de> Als sie diese Zusammenhänge erkannten, luden sie die Falun Gong-Praktizierenden ein, an ihrem Seminar teilzunehmen und den anderen türkischen Seminarteilnehmern über Falun Gong in Deutschland zu erzählen.
<G-vec00042-002-s110><attend.teilnehmen><en> I was lucky enough to attend the session in person and the slides don't give it justice.
<G-vec00042-002-s110><attend.teilnehmen><de> Ich hatte das Glück, persönlich an der Sitzung teilzunehmen, und die Folien werden ihr nicht gerecht.
<G-vec00042-002-s111><attend.teilnehmen><en> More than 30 operators from all German Nordzucker plants came to Uelzen to attend this in-house course on extraction.
<G-vec00042-002-s111><attend.teilnehmen><de> Mehr als 30 Bediener aus allen deutschen Nordzucker-Werken reisten nach Uelzen, um an der Inhouse-Schulung Extraktion teilzunehmen.
<G-vec00042-002-s112><attend.teilnehmen><en> Something similar will be experienced by participants of the 2008 Volkmanntreffen when they walk up the steps to the Museum of Islamic Art in Berlin on the evening of 10 October 2008 to attend the opening of an exhibition in which Anatolian kilims from the Prammer Collection will be displayed, integrated into the museum’s own collection.
<G-vec00042-002-s112><attend.teilnehmen><de> "I Ähnlich wird es dem Teilnehmer des Volkmanntreffens 2008 ergehen, wenn er am Abend des 10.Oktober 2008 die Treppen nach oben zu dem Museum für Islamische Kunst in Berlin beschreiten wird, um an der Eröffnung einer Ausstellung teilzunehmen, in der integriert in die reguläre Sammlung des Museums anatolische Kelim aus der Sammlung Prammer gezeigt werden.
<G-vec00042-002-s113><attend.teilnehmen><en> He returns to attend their wedding reception, and nearly gets into a fight with Edward.
<G-vec00042-002-s113><attend.teilnehmen><de> Er kehrt zurück, um an ihrem Hochzeitsempfang teilzunehmen, und gerät beinahe in einen Streit mit Edward und Bella.
<G-vec00042-002-s114><attend.teilnehmen><en> During the years Mr Hubbard resided at Saint Hill, Scientologists from around the world poured into East Grinstead to attend the famous Saint Hill Special Briefing Course where he delivered more than 400 lectures to students, imparting his latest research and development breakthroughs.
<G-vec00042-002-s114><attend.teilnehmen><de> Während der Jahre, als L. Ron Hubbard in Saint Hill lebte, kamen Scientologen aus der ganzen Welt nach East Grinstead, um an dem berühmten Saint Hill Special Briefing Kurs teilzunehmen, für dessen Studenten er mehr als 400 Vorträge hielt, um sie über seine neuesten Forschungen und Entwicklungen zu unterrichten.
<G-vec00042-002-s115><attend.teilnehmen><en> However, the program also enables undergraduate students at Cankaya to attend only the summer school programs offered at Rutgers.
<G-vec00042-002-s115><attend.teilnehmen><de> Das Programm ermöglicht jedoch auch Studenten in Cankaya, nur an den Summer School-Programmen teilzunehmen, die bei Rutgers angeboten werden.
<G-vec00042-002-s116><attend.teilnehmen><en> I was pleased to attend the Germans from Russia Heritage Society Convention at Aberdeen, SD, in July.
<G-vec00042-002-s116><attend.teilnehmen><de> Es war eine Freude für mich, im Juli an der Tagung der Germans from Russia Heritage Society in Aberdeen, SD, teilzunehmen.
<G-vec00042-002-s117><attend.teilnehmen><en> It is better not to attend the funeral at all, than to behave in a coarse manner. Molėtai
<G-vec00042-002-s117><attend.teilnehmen><de> Es ist besser an einem Begräbnis erst gar nicht teilzunehmen, als sich ein so kulturloses Benehmen zu leisten.
<G-vec00042-002-s118><attend.teilnehmen><en> In order to attend the Advanced Open Water Diver course, you shall be in possession of an Open Water Diver License.
<G-vec00042-002-s118><attend.teilnehmen><de> Um an dem Kurs Advanced Open Water Diver teilzunehmen, müsst ihr den Tauchschein Open Water Diver besitzen.
<G-vec00042-002-s119><attend.teilnehmen><en> You do not have to be a member of Trident Ploughshares to attend the camp.
<G-vec00042-002-s119><attend.teilnehmen><de> Man muss kein Mitglied von Trident Ploughshares sein, um an dem Camp teilzunehmen.
<G-vec00042-002-s120><attend.teilnehmen><en> The Chairwoman of Puertos del Estado is in Palma today and tomorrow to attend a series of internal conferences of the Spanish port system on the future of the strategic framework of general interest State port.
<G-vec00042-002-s120><attend.teilnehmen><de> Die Vorsitzende der Öffentlichen Stelle für Hafenbetrieb befindet sich noch heute und morgen in Palma, um an internen Tagungen des spanischen Hafensystems teilzunehmen, in denen es um die Zukunft des strategischen Rahmenwerks der staatlichen Häfen von allgemeinem Interesse geht.
<G-vec00042-002-s121><attend.teilnehmen><en> (4) By registration the participant agrees that he is of the appropriate age and in a suitable health condition to attend the course.
<G-vec00042-002-s121><attend.teilnehmen><de> (4) Mit der Anmeldung erklärt der Teilnehmer, dass er volljährig und gesundheitlich in der Lage ist, an den Kursen teilzunehmen.
<G-vec00042-002-s122><attend.teilnehmen><en> If you are on the island in August, do not miss the opportunity to attend one of the many “Ikarian festivals”.
<G-vec00042-002-s122><attend.teilnehmen><de> Wenn Sie im August auf der Insel sind, verpassen Sie nicht die Gelegenheit, an einem der vielen „Ikarian Festivals“ teilzunehmen.
<G-vec00042-002-s123><attend.teilnehmen><en> Once, we went to another city to attend a Fa conference.
<G-vec00042-002-s123><attend.teilnehmen><de> Einmal trafen wir uns in einer anderen Stadt, um an einer Fa-Konferenz teilzunehmen.
<G-vec00042-002-s511><attend.teilnehmen><en> A: Although no experience is necessary, and only one member of your organization must participate in order for the organization to be recognized as GST certified, we recommend that at least two people attend the 5-day Instructor Certification Course.
<G-vec00042-002-s511><attend.teilnehmen><de> Antwort: Obwohl keine Erfahrung vorausgesetzt wird und nur ein Mitglied Ihrer Organisation teilnehmen muss, damit die Organisation zertifiziert werden kann, empfehlen wir, dass von jeder Organisation mindestens zwei Personen teilnehmen.
<G-vec00042-002-s512><attend.teilnehmen><en> If you attend the Extreme Trail course, you will learn the handling of the donkeys and spend a great day with the donkey entrusted to you.
<G-vec00042-002-s512><attend.teilnehmen><de> Wenn Sie auf einem Extreme Trail Kurs teilnehmen, dann lernen Sie das Umgehen mit den Eseln und Sie verbringen einen tollen Tag mit dem Ihnen anvertrauten Esel.
<G-vec00042-002-s513><attend.teilnehmen><en> Because of this, Customer Service will be closed between 12pm - 2pm MST so that our representatives can attend the party with the rest of the corporate staff. Please plan accordingly to accommodate for this closure.
<G-vec00042-002-s513><attend.teilnehmen><de> Deswegen ist der Kundenservice von 20.00 bis 22.00 Uhr geschlossen, damit unsere Servicemitarbeiter zusammen mit den anderen Angestellten des Unternehmens an der Party teilnehmen können.
<G-vec00042-002-s514><attend.teilnehmen><en> In short, it is often that we are called for a meeting, but before deciding whether to attend that meeting or not, we should ask ourselves if it will be really productive for us and it won’t mean a waste of time.
<G-vec00042-002-s514><attend.teilnehmen><de> Resümee: Häufig werden wir zu Besprechungen gebeten, aber bevor wir entscheiden, ob wir teilnehmen oder nicht, sollten wir uns fragen, ob die Besprechung wirklich produktiv für uns ist oder wir nur Zeit verlieren.
<G-vec00042-002-s515><attend.teilnehmen><en> Five zis scholars are allowed to attend the Federal President’s youth reception.
<G-vec00042-002-s515><attend.teilnehmen><de> Fünf zis-Stipendiaten dürfen am Jugendempfang des Bundespräsidenten teilnehmen.
<G-vec00042-002-s516><attend.teilnehmen><en> 2 accompanying persons can attend for free.
<G-vec00042-002-s516><attend.teilnehmen><de> 2 Begleitpersonen können kostenlos teilnehmen.
<G-vec00042-002-s517><attend.teilnehmen><en> Whether you’ve accepted and you find out you can’t attend, or you declined and you are suddenly able to go, you’ll have to contact the person who invited you to let them know.
<G-vec00042-002-s517><attend.teilnehmen><de> Wenn du angenommen hast und herausfindest, dass du doch nicht teilnehmen kannst oder abgesagt hast und plötzlich doch hingehen kannst, musst du die Person kontaktieren, die dich eingeladen hat, und es sie wissen lassen.
<G-vec00042-002-s518><attend.teilnehmen><en> Please accept this email as an official notice that I was unable to attend 19 November 2018 due to a cold.
<G-vec00042-002-s518><attend.teilnehmen><de> Bitte akzeptieren Sie diese E-Mail als offizielle Mitteilung, dass ich aufgrund einer Erkältung nicht an 19 November 2018 teilnehmen konnte.
<G-vec00042-002-s519><attend.teilnehmen><en> And I hope you all will come and attend the puja and get the blessings of Shri Laxmi.
<G-vec00042-002-s519><attend.teilnehmen><de> Und ich hoffe ihr werdet alle kommen und teilnehmen am Puja und die Segnungen von Shri Laxmi erhalten.
<G-vec00042-002-s520><attend.teilnehmen><en> Experimenter Most cinema lovers observe what is happening at the Cannes, Venice and Sundance Film Festivals, even if they cannot attend.
<G-vec00042-002-s520><attend.teilnehmen><de> Experimenter Die meisten Cineasten verfolgen die Geschehnisse bei den Filmfestivals in Cannes, Venedig und Sundance obwohl sie selbst nicht teilnehmen können.
<G-vec00042-002-s521><attend.teilnehmen><en> Students under the age of 18 years cannot attend the welcome drinks at the pub.
<G-vec00042-002-s521><attend.teilnehmen><de> Schüler unter 18 dürfen nicht am Willkommensumtrunk im Pub teilnehmen.
<G-vec00042-002-s522><attend.teilnehmen><en> As the oral trial was public, and the case has already attracted enough national and international attention, also national, provincial and local deputies wanted to attend the public trail, also by solidarity.
<G-vec00042-002-s522><attend.teilnehmen><de> Da die mündliche Verhandlung öffentlich war und der Fall bereits genügend nationale und internationale Aufmerksamkeit auf sich gezogen, wollten auch nationale, provinzielle und lokale Abgeordnete am öffentlichen Prozess teilnehmen, auch um Solidarität mit Milagro Sala zu bekunden.
<G-vec00042-002-s523><attend.teilnehmen><en> A bone of contention is when Angela and Kieren were last working together, as carefree 20-somethings, they could attend events at the drop of a hat.
<G-vec00042-002-s523><attend.teilnehmen><de> Etwas hat sich aber doch geändert; als Angela und Kieren zuletzt zusammen gearbeitet hatte, als sorgenfreie 20-jährige, konnten sie spontant an Veranstaltungen teilnehmen.
<G-vec00042-002-s524><attend.teilnehmen><en> Prof. Manfred Fischedick and Thomas Fink of the Wuppertal Institute will attend the workshop which is supported by the German Academic Exchange Service (DAAD).
<G-vec00042-002-s524><attend.teilnehmen><de> Von Seiten des Wuppertal Instituts werden Prof. Dr. Manfred Fischedick und Thomas Fink teilnehmen und Input liefern.
<G-vec00042-002-s525><attend.teilnehmen><en> ‘There is no one holy text we all must read, there is no organized church service which is mandatory to attend, there is no concept of original sin or any pressure to be perfect people.
<G-vec00042-002-s525><attend.teilnehmen><de> “Es gibt keinen heiligen Text, den wir alle lesen müssen, es gibt keinen organisierten Gottesdienst, an dem man unbedingt teilnehmen muss, es gibt kein Konzept der Erbsünde und keinen Druck, vollkommene Menschen zu sein.
<G-vec00042-002-s526><attend.teilnehmen><en> Of course in the following we will inform all those who are unable to attend this event about any relevant developments.
<G-vec00042-002-s526><attend.teilnehmen><de> Selbstverständlich werden wir alle, die nicht teilnehmen können, im Anschluss über relevante Ereignisse informieren.
<G-vec00042-002-s527><attend.teilnehmen><en> EDEN Center is looking for 1 volunteerfrom Germany to attend for a long-term EVS in Tirana, Albania to be involved in environmental education and best environmental management practises activities in Tirana.
<G-vec00042-002-s527><attend.teilnehmen><de> Das EDEN-Zentrum sucht einen Freiwilligen aus Deutschland, der an einem Langzeit-EFD in Tirana, Albanien, teilnehmen wird, um sich in Tirana an Umwelterziehung und den besten Umweltmanagementpraktiken zu beteiligen.
<G-vec00042-002-s528><attend.teilnehmen><en> If you are unable to attend due to Coronavirus, the ski school will refund the entire amount of the lessons booked.
<G-vec00042-002-s528><attend.teilnehmen><de> Wenn Sie aufgrund von Coronavirus nicht teilnehmen können, erstattet die Skischule den Betrag der gebuchten Lektionen zurück.
<G-vec00042-002-s529><attend.teilnehmen><en> Three artists whose works were considered the finest will be offered a free excursion... if they attend the congress!
<G-vec00042-002-s529><attend.teilnehmen><de> Drei Künstler, deren Werke als die besten erkoren werden, gewinnen einen freien Ausflug, falls sie am Kongress teilnehmen.
<G-vec00042-002-s531><attend.teilnehmen><en> Only the twelve apostles had known that Jesus intended to attend the feast of tabernacles when they had departed from Magadan.
<G-vec00042-002-s531><attend.teilnehmen><de> Als sie aus Magadan weggingen, wussten nur die zwölf Apostel, dass Jesus am Laubhüttenfest teilzunehmen beabsichtigte.
<G-vec00042-002-s532><attend.teilnehmen><en> For the period 2015 – 2019, the Management Board and the Budget Committee of EUIPO have granted the User Associations APRAM, AIPPI, CNIPA, EURATEX, FICPI, GRUR, ICC, ITMA, LESI and UNION the possibility to attend their meetings on a rotational basis.
<G-vec00042-002-s532><attend.teilnehmen><de> Für den Zeitraum 2015-2019 geben der Verwaltungsrat und der Haushaltsausschuss des EUIPO den Nutzerverbänden APRAM, AIPPI, CNIPA, EURATEX, FICPI, GRUR, ICC, ITMA, LESI und UNION die Möglichkeit, abwechselnd an ihren Sitzungen teilzunehmen.
<G-vec00042-002-s533><attend.teilnehmen><en> We came over to Penneshaw to attend a wedding and had a lovely stay at Sea Spray Holiday House.
<G-vec00042-002-s533><attend.teilnehmen><de> Wir kamen zu Penneshaw über zu einer Hochzeit teilzunehmen und hatten einen schönen Aufenthalt im Sea Spray Ferienhaus.
<G-vec00042-002-s534><attend.teilnehmen><en> Children from Romani camps in and around Milano were able to attend soccer trainings once a week.
<G-vec00042-002-s534><attend.teilnehmen><de> Die Kinder von Roma-Siedlungen in und rund um Mailand hatten wöchentlich die Möglichkeit, an einem Fußballtraining teilzunehmen.
<G-vec00042-002-s535><attend.teilnehmen><en> “The conference costs $2-$3k to attend.
<G-vec00042-002-s535><attend.teilnehmen><de> „Die Konferenz kostet $ 2- $ 3k um teilzunehmen.
<G-vec00042-002-s536><attend.teilnehmen><en> The live classes are an opportunity for students to attend an English class in real time, no matter where you are.
<G-vec00042-002-s536><attend.teilnehmen><de> Die live abgehaltenen Unterrichtsstunden von Teacher Robin sind eine einzigartige Gelegenheit, in Echtzeit an einer Englischstunde teilzunehmen, ganz gleich, wo du dich gerade befindest.
<G-vec00042-002-s537><attend.teilnehmen><en> I truly think the most important reason to attend these small wedding fairs is to network.
<G-vec00042-002-s537><attend.teilnehmen><de> Der wichtigste Grund an kleinen Hochzeitsmessen teilzunehmen ist das Netztwerk.
<G-vec00042-002-s538><attend.teilnehmen><en> Prospective students are welcome to attend any of these events.
<G-vec00042-002-s538><attend.teilnehmen><de> Studieninteressierte sind herzlich eingeladen, teilzunehmen.
<G-vec00042-002-s539><attend.teilnehmen><en> We put on a wide variety of different orientation events, which all new students are welcome to attend.
<G-vec00042-002-s539><attend.teilnehmen><de> Alle Studenten sind herzlich eingeladen, an den zahlreichen Einführungsveranstaltungen teilzunehmen.
<G-vec00042-002-s540><attend.teilnehmen><en> We focus on the cooperation with museums and educational institutions, but we are willing to attend events with a different focus, as long as the transfer of knowledge can be our priority.
<G-vec00042-002-s540><attend.teilnehmen><de> Unser Fokus liegt dabei stark auf der Zusammenarbeit mit Museen und Bildungseinrichtungen, allerdings sind wir auch bereit bei anderen Veranstaltungen teilzunehmen, solange die Wissensvermittlung im Vordergrund steht.
<G-vec00042-002-s541><attend.teilnehmen><en> Several organisations invited practitioners to introduce Falun Dafa to their employees, or to attend other activities.
<G-vec00042-002-s541><attend.teilnehmen><de> Mehrere Organisationen luden die Praktizierenden ein, ihren Angestellten Falun Gong vorzustellen oder an ihren Aktivitäten teilzunehmen.
<G-vec00042-002-s542><attend.teilnehmen><en> The Peace Corps Volunteers involved with the three winning projects in the Peace Corps ICT contest have been given a scholarship to attend the Global Forum on Youth and ICT for Development in Geneva, Switzerland.
<G-vec00042-002-s542><attend.teilnehmen><de> Die Freiwilligen des Friedenskorps, die mit den drei Siegerprojekten im ICT Wettberb des Friedenskorps zu tun hatten, erhielten ein Stipendium um am Weltforum für Jugend, ICT und Entwicklung in Genf teilzunehmen.
<G-vec00042-002-s544><attend.teilnehmen><en> Even though she has attended a real UN conference, she still described the Model UN as interesting and exciting: "I think it is really important for young people to attend conferences like this, even though they are just simulations.
<G-vec00042-002-s544><attend.teilnehmen><de> Obwohl sie bereits an einer "echten" UNO-Konferenz teilgenommen hat, beschrieb sie die Model UN als interessant und spannend: "Ich denke, es ist wirklich wichtig für junge Menschen, an solchen Konferenzen teilzunehmen, obgleich sie nur Simulationen sind.
<G-vec00042-002-s545><attend.teilnehmen><en> This provided me with an opportunity to connect with international professors and PhD students from all over the world, to attend inspiring lectures and to engage in lively discussions about innovative marketing.
<G-vec00042-002-s545><attend.teilnehmen><de> Das gab mir Gelegenheit, internationale Professoren und Doktoranden aus aller Welt kennenzulernen, inspirierenden Vorträgen zu lauschen und an engagierten Diskussionen zu innovativem Marketing teilzunehmen.
<G-vec00042-002-s547><attend.teilnehmen><en> India Dreamin had over 1300 registered to attend.
<G-vec00042-002-s547><attend.teilnehmen><de> India Dreamin hatte über 1300 registriert, um teilzunehmen.
<G-vec00042-002-s548><attend.teilnehmen><en> For this year’s Kagyu Monlam, I personally requested Chamgon Situ Rinpoche to definitely come, but in the end, Rinpoche was not able to attend.
<G-vec00042-002-s548><attend.teilnehmen><de> Für das diesjährige Gebetsfest bat ich Chamgon Situ Rinpoche persönlich, definitiv zu kommen, aber Rinpoche war es nicht möglich, am Mönlam teilzunehmen.
