<G-vec00877-002-s023><crave.begehren><en> He who is actually greater than the world can crave nothing, can desire nothing, from this world.
<G-vec00877-002-s023><crave.begehren><de> Wer eigentlich größer ist als die Welt kann nichts begehren, nichts wünschen, was von dieser Welt ist.
<G-vec00877-002-s024><crave.begehren><en> A public pat on the back goes far when giving your team the recognition they crave.
<G-vec00877-002-s024><crave.begehren><de> Ein öffentliches Schulterklopfen ist viel wert um Ihren Teammitgliedern die Anerkennung zu geben, die sie begehren.
<G-vec00877-002-s025><crave.begehren><en> This has become the newest crave in online poker as professional online poker players are starting to read what their counterparts are doing.
<G-vec00877-002-s025><crave.begehren><de> Dies begehren seit neuestem im Online Poker die professionellen Pokerspieler das zu tun, was ihre Kollegen auch machen.
<G-vec00877-002-s044><crave.ersehnen><en> I crave spiritual gold.
<G-vec00877-002-s044><crave.ersehnen><de> Ich ersehne spirituelles Gold.
<G-vec00877-002-s045><crave.ersehnen><en> I crave a lot of alone time.
<G-vec00877-002-s045><crave.ersehnen><de> Ich ersehne mir viel Zeit allein.
<G-vec00877-002-s046><crave.ersehnen><en> Clare: Saturn normally describes what we crave and what we feel we have been denied, so this is a good example.
<G-vec00877-002-s046><crave.ersehnen><de> Clare: Saturn beschreibt normalerweise das, was wir ersehnen und von dem wir glauben, dass es uns vorenthalten wurde, insofern ist das ein gutes Beispiel.
<G-vec00877-002-s053><crave.lechzen><en> Everything that the soul of man could crave or ask for seems to be available.
<G-vec00877-002-s053><crave.lechzen><de> Alles, wonach die Seele des Menschen lechzen oder verlangen könnte, scheint erhältlich zu sein.
<G-vec00877-002-s059><crave.lechzen><en> Protein Muesli does not contain and preservative or added sugar*, and it’s also a great alternative when you crave sweets during your diet.
<G-vec00877-002-s059><crave.lechzen><de> Protein Muesli enthält weder Konservierugsstoffe noch zusätzlichen Zucker*, zudem ist es eine tolle Alternative, wenn du während deiner Diät nach Süßigkeiten lechzt.
<G-vec00877-002-s039><crave.sehnen><en> He warns: "Yes, you will get what you crave.
<G-vec00877-002-s039><crave.sehnen><de> Er warnt uns: "Ja, du wirst bekommen, wonach du dich sehnst.
<G-vec00877-002-s061><crave.sehnen><en> Join me and fight against <CHARNAME> and I will return the power you lost, the power you crave so much.
<G-vec00877-002-s061><crave.sehnen><de> Unterstützt mich und kämpft gegen <CHARNAME> und ich werde Euch die Macht zurückgeben, die Ihr einst verlort, die Macht, nach der Ihr Euch so sehr sehnt.
<G-vec00877-002-s062><crave.sehnen><en> Sooooo gals, if you really crave that boyfriend look, go through your bf's closet, or even better at times: your dad's.
<G-vec00877-002-s062><crave.sehnen><de> Aaaalso Mädels, wenn ihr euch wirklich nach diesem Boyfriend- Look sehnt, geht wirklich mal durch den Kleiderschrank eures Freundes, oder manchmal sogar besser: die eurer Väter.
<G-vec00877-002-s070><crave.sehnen><en> Good Surrounding Area: Cabarete, with his sandy beach, is just the right location for those who crave sun and wind.
<G-vec00877-002-s070><crave.sehnen><de> Umgebung: Cabarete, welche an einem kilometerlangen Sandstrand liegt, ist genau der richtige Ort für diejenigen, die Wind und Sonne sehnen.
<G-vec00877-002-s071><crave.sehnen><en> Now is the winter cold and we all crave delicious and tasty sweets and chocolates.
<G-vec00877-002-s071><crave.sehnen><de> Jetzt ist der Winter kalt und wir alle sehnen lecker und schmackhaft Bonbons und Pralinen.
<G-vec00877-002-s072><crave.sehnen><en> Crave it and enjoy it, but eat sushi responsibly.
<G-vec00877-002-s072><crave.sehnen><de> Sehnen Sie es und genießen Sie es, aber essen Sie Sushi verantwortungsvoll.
<G-vec00877-002-s073><crave.sehnen><en> As soon as people lock themselves in their homes, they start to crave for social interactions.
<G-vec00877-002-s073><crave.sehnen><de> Sobald sich die Menschen in ihren Häusern aufhalten, beginnen sie sich nach sozialer Interaktion zu sehnen.
<G-vec00877-002-s074><crave.sehnen><en> While women are reluctant to admit that they crave more in bed from their partner, the simple fact of the matter is that everyone has room for improvement.
<G-vec00877-002-s074><crave.sehnen><de> Während Frauen zögern zuzugeben, dass sie mehr im Bett von ihrem Partner sehnen, ist die einfache Tatsache der Sache, dass jeder Raum für Verbesserungenhat.
<G-vec00877-002-s075><crave.sehnen><en> In this area you can accommodate any later sofa and blanket that sometimes crave, or spend time with friends deciding what will be the plan for the day.
<G-vec00877-002-s075><crave.sehnen><de> In diesem Bereich können Sie einen beliebigen späteren Sofa und Decke aufzunehmen, die manchmal sehnen, oder verbringen Sie Zeit mit Freunden zu entscheiden, was der Plan für den Tag sein wird.
<G-vec00877-002-s076><crave.sehnen><en> Those who crave entertainment until dawn can immerse themselves in the nightlife.
<G-vec00877-002-s076><crave.sehnen><de> Diejenigen, die Unterhaltung bis zum Morgengrauen sehnen, können in das Nachtleben eintauchen.
<G-vec00877-002-s077><crave.sehnen><en> One of the easiest ways to cut back without feeling denied is to switch to lower-calorie versions of the foods you crave.
<G-vec00877-002-s077><crave.sehnen><de> Eine der einfachsten Möglichkeiten, zurück zu schneiden, ohne das Gefühl verweigert, ist die Umstellung auf kalorienarme Versionen von Lebensmittel, die Sie sehnen.
<G-vec00877-002-s078><crave.sehnen><en> And for those who crave something grand, offers all sorts of tournaments.
<G-vec00877-002-s078><crave.sehnen><de> Und für diejenigen, die etwas Großes sehnen, bietet alle Arten von Turnieren.
<G-vec00877-002-s079><crave.sehnen><en> This necessary mineral could assist your cells soak up as much sugar as possible, so you crave fewer carbohydrates and sugars.
<G-vec00877-002-s079><crave.sehnen><de> Diese notwendige Mineral könnte Ihre Zellen unterstützen so viel Zucker wie möglich genießen, so dass Sie sehnen sich weniger Kohlenhydrate und Zucker.
<G-vec00877-002-s086><crave.sehnen><en> “Dear children! Today I wish to tell you to open your hearts to God like the spring flowers which crave for the sun.
<G-vec00877-002-s086><crave.sehnen><de> Heute will ich euch sagen, daß ihr Gott eure Herzen öffnen sollt wie die Blüten im Frühling, die sich so nach der Sonne sehnen.
<G-vec00877-002-s039><crave.sich_sehnen><en> He warns: "Yes, you will get what you crave.
<G-vec00877-002-s039><crave.sich_sehnen><de> Er warnt uns: "Ja, du wirst bekommen, wonach du dich sehnst.
<G-vec00877-002-s061><crave.sich_sehnen><en> Join me and fight against <CHARNAME> and I will return the power you lost, the power you crave so much.
<G-vec00877-002-s061><crave.sich_sehnen><de> Unterstützt mich und kämpft gegen <CHARNAME> und ich werde Euch die Macht zurückgeben, die Ihr einst verlort, die Macht, nach der Ihr Euch so sehr sehnt.
<G-vec00877-002-s062><crave.sich_sehnen><en> Sooooo gals, if you really crave that boyfriend look, go through your bf's closet, or even better at times: your dad's.
<G-vec00877-002-s062><crave.sich_sehnen><de> Aaaalso Mädels, wenn ihr euch wirklich nach diesem Boyfriend- Look sehnt, geht wirklich mal durch den Kleiderschrank eures Freundes, oder manchmal sogar besser: die eurer Väter.
<G-vec00877-002-s070><crave.sich_sehnen><en> Good Surrounding Area: Cabarete, with his sandy beach, is just the right location for those who crave sun and wind.
<G-vec00877-002-s070><crave.sich_sehnen><de> Umgebung: Cabarete, welche an einem kilometerlangen Sandstrand liegt, ist genau der richtige Ort für diejenigen, die Wind und Sonne sehnen.
<G-vec00877-002-s071><crave.sich_sehnen><en> Now is the winter cold and we all crave delicious and tasty sweets and chocolates.
<G-vec00877-002-s071><crave.sich_sehnen><de> Jetzt ist der Winter kalt und wir alle sehnen lecker und schmackhaft Bonbons und Pralinen.
<G-vec00877-002-s072><crave.sich_sehnen><en> Crave it and enjoy it, but eat sushi responsibly.
<G-vec00877-002-s072><crave.sich_sehnen><de> Sehnen Sie es und genießen Sie es, aber essen Sie Sushi verantwortungsvoll.
<G-vec00877-002-s073><crave.sich_sehnen><en> As soon as people lock themselves in their homes, they start to crave for social interactions.
<G-vec00877-002-s073><crave.sich_sehnen><de> Sobald sich die Menschen in ihren Häusern aufhalten, beginnen sie sich nach sozialer Interaktion zu sehnen.
<G-vec00877-002-s074><crave.sich_sehnen><en> While women are reluctant to admit that they crave more in bed from their partner, the simple fact of the matter is that everyone has room for improvement.
<G-vec00877-002-s074><crave.sich_sehnen><de> Während Frauen zögern zuzugeben, dass sie mehr im Bett von ihrem Partner sehnen, ist die einfache Tatsache der Sache, dass jeder Raum für Verbesserungenhat.
<G-vec00877-002-s075><crave.sich_sehnen><en> In this area you can accommodate any later sofa and blanket that sometimes crave, or spend time with friends deciding what will be the plan for the day.
<G-vec00877-002-s075><crave.sich_sehnen><de> In diesem Bereich können Sie einen beliebigen späteren Sofa und Decke aufzunehmen, die manchmal sehnen, oder verbringen Sie Zeit mit Freunden zu entscheiden, was der Plan für den Tag sein wird.
<G-vec00877-002-s076><crave.sich_sehnen><en> Those who crave entertainment until dawn can immerse themselves in the nightlife.
<G-vec00877-002-s076><crave.sich_sehnen><de> Diejenigen, die Unterhaltung bis zum Morgengrauen sehnen, können in das Nachtleben eintauchen.
<G-vec00877-002-s077><crave.sich_sehnen><en> One of the easiest ways to cut back without feeling denied is to switch to lower-calorie versions of the foods you crave.
<G-vec00877-002-s077><crave.sich_sehnen><de> Eine der einfachsten Möglichkeiten, zurück zu schneiden, ohne das Gefühl verweigert, ist die Umstellung auf kalorienarme Versionen von Lebensmittel, die Sie sehnen.
<G-vec00877-002-s078><crave.sich_sehnen><en> And for those who crave something grand, offers all sorts of tournaments.
<G-vec00877-002-s078><crave.sich_sehnen><de> Und für diejenigen, die etwas Großes sehnen, bietet alle Arten von Turnieren.
<G-vec00877-002-s079><crave.sich_sehnen><en> This necessary mineral could assist your cells soak up as much sugar as possible, so you crave fewer carbohydrates and sugars.
<G-vec00877-002-s079><crave.sich_sehnen><de> Diese notwendige Mineral könnte Ihre Zellen unterstützen so viel Zucker wie möglich genießen, so dass Sie sehnen sich weniger Kohlenhydrate und Zucker.
<G-vec00877-002-s086><crave.sich_sehnen><en> “Dear children! Today I wish to tell you to open your hearts to God like the spring flowers which crave for the sun.
<G-vec00877-002-s086><crave.sich_sehnen><de> Heute will ich euch sagen, daß ihr Gott eure Herzen öffnen sollt wie die Blüten im Frühling, die sich so nach der Sonne sehnen.
<G-vec00877-002-s087><crave.sich_wünschen><en> Totally Untethered Whether you're streaming tunes in the kitchen with a Wi-Fi speaker, relaxing on the couch with headphones on and your phone in-hand, or walking the dog with some of your favorite tracks—Polk wireless audio delivers the sound you crave without the need to run cables to hear it.
<G-vec00877-002-s087><crave.sich_wünschen><de> Ganz egal, ob Sie in der Küche Musik mit einem WLAN-Lautsprecher hören, auf der Couch mit Kopfhörern und Ihrem Handy in der Hand entspannen oder mit dem Hund spazieren gehen, während Sie Ihre Lieblingsmusik hören – kabellose Audiosysteme von Polk liefern Ihnen den Sound, den Sie sich wünschen, ohne dass Sie Kabel dafür benötigen.
<G-vec00877-002-s088><crave.sich_wünschen><en> As the world’s best-selling electric vehicle, Nissan LEAF is redefining the power you crave behind the wheel.
<G-vec00877-002-s088><crave.sich_wünschen><de> Der NISSAN LEAF ist das meistverkaufte Elektrofahrzeug weltweit und definiert die Leistung neu, die Sie sich am Steuer wünschen.
<G-vec00877-002-s089><crave.sich_wünschen><en> Boldly envisioned, intricately designed – each XPS offers the performance that you crave, with an impressive battery life packed into a small, thin and stunning package.
<G-vec00877-002-s089><crave.sich_wünschen><de> Außergewöhnliches Design für höchste Ansprüche: Jedes XPS bietet die Leistung, die Sie sich wünschen, und eine beeindruckende Akkulaufzeit in einem kleinen, flachen und beeindruckenden Gerät.
<G-vec00877-002-s090><crave.sich_wünschen><en> HIGH-PERFORMANCE GAMING ACCESSORIES Transform your gaming laptop into a desktop-class gaming rig with the superior graphics and audio performance you crave.
<G-vec00877-002-s090><crave.sich_wünschen><de> Verwandeln Sie Ihr Gaming-Notebook in ein Gaming-Rigg der Desktop-PC-Klasse mit der überlegenen Grafik- und Audioleistung, die Sie sich wünschen.
<G-vec00877-002-s091><crave.sich_wünschen><en> Made with 10 plastic bones and a satin lace-up back, it creates the shapely contours you crave, inspiring a confident sizzle in the bedroom.
<G-vec00877-002-s091><crave.sich_wünschen><de> Das Korsett enthält 10 Kunststoffstäbchen und eine Stoffschnürung auf der Rückseite und schafft damit die formschönen Konturen, die Sie sich wünschen, und verleiht Ihnen im Schlafzimmer ein selbstbewusstes Knistern.
<G-vec00877-002-s092><crave.sich_wünschen><en> New Hybrid Hard Drives: It's a win-win situation for every gamer: the SSD performance you crave, with the HDD capacity you need.
<G-vec00877-002-s092><crave.sich_wünschen><de> Neue Hybrid-Festplatten: für jeden Spieler eine Win-win-Situation: die SSD-Leistung, die Sie sich wünschen, mit der Festplattenkapazität, die Sie brauchen.
<G-vec00877-002-s101><crave.sich_wünschen><en> So selflove is one of our very first abilities – but at the same time one of the most fragile as it needs constand love from outside to build enough stability to overcame even times in life, when we get less love, than we crave for. Philosophie.
<G-vec00877-002-s101><crave.sich_wünschen><de> Uns selbst lieben zu können ist somit eine unserer allerersten Fähigkeiten – und gleichzeitig eine, die so zerbrechlich ist, dass sie konstanter Liebe von außen bedarf, um so stabil zu werden, dass sie es auch übersteht, wenn mal eine Lebensphase eintreten sollte, in der wir weniger Liebe bekommen, als wir uns wünschen.
<G-vec00877-002-s093><crave.streben><en> Others, however, continue to crave the simplicity that a slot such as Xtra Hot offers with as few distractions as possible between them and the ultimate goal of winning huge prizes.
<G-vec00877-002-s093><crave.streben><de> Weitere Menschen streben noch doch nach der Einfachkeit, die ein Spielautomat wie Xtra Hot bietet, mit weniger Ablenkungen wie möglich dazwischen und mit dem Endziel, riesige Gewinne zu erwerben.
<G-vec00877-002-s049><crave.verlangen><en> Seraphim equally crave assignment to the missions of the incarnated Sons and attachment as destiny guardians to the mortals of the realms; the latter is the surest seraphic passport to Paradise, while the bestowal attendants have achieved the highest local universe service of the completion seraphim of Paradise attainment. 428 2.
<G-vec00877-002-s049><crave.verlangen><de> Die Seraphim haben ein ebenso heißes Verlangen, den Sendungen der inkarnierten Söhne zugeteilt zu werden, wie den Sterblichen der Welten als Schicksalshüter beigegeben zu werden; letzteres ist der sicherste seraphische Pass zum Paradies, während die Begleiter der Selbsthingaben es zum höchsten sind die seraphischen Ratgeber und Helfer, die allen Ordnungen der Rechtsprechung zugeteilt sind, von den Schlichtern bis hinauf zu den höchsten Gerichten des Reichs.
<G-vec00877-002-s064><crave.verlangen><en> If we take a moment to wonder why we crave certain foods, we might change our minds.
<G-vec00877-002-s064><crave.verlangen><de> Wenn wir uns einen Moment Zeit nehmen, um uns zu fragen, warum wir nach bestimmten Lebensmitteln verlangen, können wir unsere Meinung ändern.
<G-vec00877-002-s065><crave.verlangen><en> But it also binds us, as long as we crave for knowledge and comfort.
<G-vec00877-002-s065><crave.verlangen><de> Aber auch er bindet uns, solange wir nach Wissen und Komfort verlangen.
<G-vec00877-002-s095><crave.verlangen><en> Dr. Mario Garcia: "Heraldo Abierto offers the very section that readers/users of news media today crave for.
<G-vec00877-002-s095><crave.verlangen><de> Dr. Mario Garcia: „Heraldo Abierto bietet genau das, wonach die Leser/Nutzer von Nachrichtenmedien heute verlangen.
<G-vec00877-002-s096><crave.verlangen><en> Drier zones, however, crave water and nutritious ingredients to prevent dehydration and irritation.
<G-vec00877-002-s096><crave.verlangen><de> Ganz im Gegenteil, denn die typischen trockenen Zonen verlangen Feuchtigkeit und müssen genährt werden, um das Dehydrieren zu verhindern und Reizungen zu vermeiden.
<G-vec00877-002-s097><crave.verlangen><en> As I felt sated with Jingmai teas for some time, and didn't crave for very young sheng at that time, those samples were left horribly neglected by me.
<G-vec00877-002-s097><crave.verlangen><de> Da ich mich einige Zeit von Jingmaitees übersättigt fühlte und kein Verlangen nach blutjungen Sheng hatte, wurden jene drei Proben sträflich vernachlässigt.
<G-vec00877-002-s098><crave.verlangen><en> During the wintertime when it's colder, your body is automatically going to crave hearty and filling foods that keep you warm and are relatively high-caloric.
<G-vec00877-002-s098><crave.verlangen><de> Während der Winterzeit, wenn es kälter wird, verlangt es Deinen Körper automatisch nach herzhaften und sättigenden Lebensmitteln, die Dich warm halten und relativ kalorienreich sind.
<G-vec00877-002-s099><crave.verspüren><en> Continue to drink the cream of tartar and orange juice mixture until you no longer crave nicotine.
<G-vec00877-002-s099><crave.verspüren><de> Trinke diese Mischung so lange, bis du keine Nikotinsucht mehr verspürst.
<G-vec00877-002-s087><crave.wünschen><en> Totally Untethered Whether you're streaming tunes in the kitchen with a Wi-Fi speaker, relaxing on the couch with headphones on and your phone in-hand, or walking the dog with some of your favorite tracks—Polk wireless audio delivers the sound you crave without the need to run cables to hear it.
<G-vec00877-002-s087><crave.wünschen><de> Ganz egal, ob Sie in der Küche Musik mit einem WLAN-Lautsprecher hören, auf der Couch mit Kopfhörern und Ihrem Handy in der Hand entspannen oder mit dem Hund spazieren gehen, während Sie Ihre Lieblingsmusik hören – kabellose Audiosysteme von Polk liefern Ihnen den Sound, den Sie sich wünschen, ohne dass Sie Kabel dafür benötigen.
<G-vec00877-002-s088><crave.wünschen><en> As the world’s best-selling electric vehicle, Nissan LEAF is redefining the power you crave behind the wheel.
<G-vec00877-002-s088><crave.wünschen><de> Der NISSAN LEAF ist das meistverkaufte Elektrofahrzeug weltweit und definiert die Leistung neu, die Sie sich am Steuer wünschen.
<G-vec00877-002-s089><crave.wünschen><en> Boldly envisioned, intricately designed – each XPS offers the performance that you crave, with an impressive battery life packed into a small, thin and stunning package.
<G-vec00877-002-s089><crave.wünschen><de> Außergewöhnliches Design für höchste Ansprüche: Jedes XPS bietet die Leistung, die Sie sich wünschen, und eine beeindruckende Akkulaufzeit in einem kleinen, flachen und beeindruckenden Gerät.
<G-vec00877-002-s090><crave.wünschen><en> HIGH-PERFORMANCE GAMING ACCESSORIES Transform your gaming laptop into a desktop-class gaming rig with the superior graphics and audio performance you crave.
<G-vec00877-002-s090><crave.wünschen><de> Verwandeln Sie Ihr Gaming-Notebook in ein Gaming-Rigg der Desktop-PC-Klasse mit der überlegenen Grafik- und Audioleistung, die Sie sich wünschen.
<G-vec00877-002-s091><crave.wünschen><en> Made with 10 plastic bones and a satin lace-up back, it creates the shapely contours you crave, inspiring a confident sizzle in the bedroom.
<G-vec00877-002-s091><crave.wünschen><de> Das Korsett enthält 10 Kunststoffstäbchen und eine Stoffschnürung auf der Rückseite und schafft damit die formschönen Konturen, die Sie sich wünschen, und verleiht Ihnen im Schlafzimmer ein selbstbewusstes Knistern.
<G-vec00877-002-s092><crave.wünschen><en> New Hybrid Hard Drives: It's a win-win situation for every gamer: the SSD performance you crave, with the HDD capacity you need.
<G-vec00877-002-s092><crave.wünschen><de> Neue Hybrid-Festplatten: für jeden Spieler eine Win-win-Situation: die SSD-Leistung, die Sie sich wünschen, mit der Festplattenkapazität, die Sie brauchen.
<G-vec00877-002-s101><crave.wünschen><en> So selflove is one of our very first abilities – but at the same time one of the most fragile as it needs constand love from outside to build enough stability to overcame even times in life, when we get less love, than we crave for. Philosophie.
<G-vec00877-002-s101><crave.wünschen><de> Uns selbst lieben zu können ist somit eine unserer allerersten Fähigkeiten – und gleichzeitig eine, die so zerbrechlich ist, dass sie konstanter Liebe von außen bedarf, um so stabil zu werden, dass sie es auch übersteht, wenn mal eine Lebensphase eintreten sollte, in der wir weniger Liebe bekommen, als wir uns wünschen.
