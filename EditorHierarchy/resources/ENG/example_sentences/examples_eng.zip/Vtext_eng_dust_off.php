<G-vec00552-002-s598><dust_off.stäuben><en> After successfully passing the relevant laboratory tests the Gericke feeder control unit has been approved for use in explosive atmospheres containing combustible dust.
<G-vec00552-002-s598><dust_off.stäuben><de> Mit dem erfolgreichen Bestehen der notwendigen Labortests hat die Gericke Waagensteuerung die Zulassung zur Verwendung in explosionsgefährdeten Umgebungen mit brennbaren Stäuben erhalten und entspricht der Kategorie 3.
<G-vec00552-002-s599><dust_off.stäuben><en> To set the smooth complexion in place, dust over a fine loose powder.
<G-vec00552-002-s599><dust_off.stäuben><de> Um das glatte Hautbild in Form zu halten, stäuben Sie etwas feinen, losen Puder darüber.
<G-vec00552-002-s600><dust_off.stäuben><en> However, in these data no significant difference between dust from the cutting of unreinforced concrete and carbon concrete can be identified.
<G-vec00552-002-s600><dust_off.stäuben><de> Allerdings kann in diesen Daten kein signifikanter Unterschied zwischen Stäuben aus dem Trennen von Reinbeton und Carbonbeton ausgemacht werden.
<G-vec00552-002-s601><dust_off.stäuben><en> Use processes, operating procedures and products which will limit workers exposure to fibrous dust.
<G-vec00552-002-s601><dust_off.stäuben><de> Verwenden Sie Methoden, Arbeitsverfahren und Produkte, durch welche die Anwender so wenig wie möglich faserförmigen Stäuben ausgesetzt werden.
<G-vec00552-002-s602><dust_off.stäuben><en> To highlight, dust Kind Heart baked cheek powder along the tops of the cheekbones.
<G-vec00552-002-s602><dust_off.stäuben><de> Für ein aufregendes Highlight stäuben Sie Kind Heart Baked Cheek Powder auf die höchste Stelle der Wangenknochen.
<G-vec00552-002-s603><dust_off.stäuben><en> The occurrence of discharges that can ignite the explosive mixtures of gas, vapour, mist and dust.
<G-vec00552-002-s603><dust_off.stäuben><de> Auftreten zündfähiger Entladungen, die explosionsfähige Gemische von Gasen, Dämpfen, Nebeln oder Stäuben entzünden können.
<G-vec00552-002-s604><dust_off.stäuben><en> b) Do not operate power tools in explosive. atmospheres, such as in the presence of flammable liquids, gases or dustPower tools create sparks which may ignite the dust or fumes.
<G-vec00552-002-s604><dust_off.stäuben><de> b)Verwenden Sie Elektrowerkzeuge niemals an Orten, an denen Explosionsgefahr besteht – zum Beispiel in der Nähe von leicht entflammbaren Flüssigkeiten, Gasen oder Stäuben.
<G-vec00552-002-s605><dust_off.stäuben><en> In environments in which explosive dust is present, we recommend the use of ExCharge® filter media.
<G-vec00552-002-s605><dust_off.stäuben><de> Bei explosiven Stäuben empfehlen wir den Einsatz von ExCharge®-Filtermedien.
<G-vec00552-002-s606><dust_off.stäuben><en> Besides dust and pollen this type of filter remove from the air also the odors and gaseous air pollutants such as nitrogen oxides, sulfur dioxide, hydrogen sulfide, ammonia, solvent components or ozone.
<G-vec00552-002-s606><dust_off.stäuben><de> Neben Stäuben und Pollen werden so Gerüche und gasförmige Luftverunreinigungen wie Stickoxide, Schwefeldioxid, Schwefelwasserstoff, Ammoniak, Lösemittelbestandteile oder Ozon aus der Zuluft entfernt.
<G-vec00552-002-s607><dust_off.stäuben><en> Air quality measurements taken by the Basel municipal authorities and Novartis showed that odor emissions and the dispersal of lindane-contaminated dust during operations were not reduced as anticipated.
<G-vec00552-002-s607><dust_off.stäuben><de> Luftmessungen der Baselstädtischen Behörden und von Novartis haben ergeben, dass die Geruchsemmissionen und die Verfrachtung von mit Lindan-Abfällen belasteten Stäuben bei laufendem Betrieb nicht wie erhofft reduziert werden konnten.
<G-vec00552-002-s608><dust_off.stäuben><en> The IEC 61241-2-2 contains the test method for determining the specific electrical resistance of dust.
<G-vec00552-002-s608><dust_off.stäuben><de> Die IEC 61241-2-2 beinhaltet das Prüfverfahren zur Bestimmung des spezifischen elektrischen Widerstandes von Stäuben.
<G-vec00552-002-s609><dust_off.stäuben><en> When the concentration of steam and dust cannot normally or has to be reduced to a safe level, the atmosphere in the unit is set by adding an inert gas such as nitrogen or carbon dioxide in such a quantity that a non-critical and maximum permissible concentration is reached.
<G-vec00552-002-s609><dust_off.stäuben><de> Wenn die Konzentration an Dämpfen oder Stäuben nicht in einen ungefährlichen Bereich gesenkt werden kann oder soll, kann der vorhandenen Atmosphäre in den Anlagen ein Inertgas wie Stickstoff oder Kohlendioxid in einer Größenordnung beigemengt werden, dass sich eine unkritische, höchstzulässige Sauerstoffkonzentration einstellt.
<G-vec00552-002-s610><dust_off.stäuben><en> Rotary valves are used to discharge dust, chipboard shavings and fibrous conveyed goods, and as shut-off devices.
<G-vec00552-002-s610><dust_off.stäuben><de> Zellenradschleusen werden zum Austragen von Stäuben, Spänen und faserigen Fördergütern sowie als Absperrorgan eingesetzt.
<G-vec00552-002-s611><dust_off.stäuben><en> Don’t forget road traffic and the resulting dust, salts and tire wear particles.
<G-vec00552-002-s611><dust_off.stäuben><de> Hinzu kommt der Straßenverkehr und seine Auswirkungen in Form von Stäuben, Salzen und Reifenabrieb.
<G-vec00552-002-s612><dust_off.stäuben><en> Our wide range of materials and coatings, even at high levels of corrosion such as acids and bases as well as dust and moist vapours, guarantees years of operation – around the clock of course.
<G-vec00552-002-s612><dust_off.stäuben><de> Dabei sorgt unser hohes Sortiment an Werkstoffen und Beschichtungen selbst bei korrosiven Belastungen mit Säuren und Laugen sowie bei Stäuben und feuchten Dämpfen für jahrelange Betriebszeiten – natürlich rund um die Uhr.
<G-vec00552-002-s613><dust_off.stäuben><en> GeoFlex Exhaust HT-650 is a high temperature hose for extraction or blowing hot air, vapor or dust within the industry.
<G-vec00552-002-s613><dust_off.stäuben><de> GeoFlex Exhaust HT-650 ist ein Hochtemperaturschlauch für das Absaugen oder Einblasen von Warmluft, Dämpfen, Rauch oder Stäuben innerhalb der Industrie.
<G-vec00552-002-s614><dust_off.stäuben><en> New legislation (EN 60335-2-69) has placed some very tight restrictions on handling hazardous dust.
<G-vec00552-002-s614><dust_off.stäuben><de> Neue Rechtsvorschriften (EN 60335-2-69) legen einige sehr strenge Beschränkungen über den Umgang mit gefährlichen Stäuben auf.
<G-vec00552-002-s615><dust_off.stäuben><en> ASM FFP 3-5: Comfortable fit via 4-point headband; safe fit due to circumferential comfort sealing lip; nosepiece is flexible, ensuring that the mask fits securely, even across the nose; protects against dust up to 30 times the MAK and TRK limit values.
<G-vec00552-002-s615><dust_off.stäuben><de> ASM FFP 3-5: Komfortabler Halt über 4-Punkt-Kopfband, sicherer Sitz durch umlaufende Komfortdichtlippe, flexibel anpassbarer Nasenbügel für einen dichten Sitz der Maske, auch an der Nase; schützt vor Stäuben bis zum 30-fachen Grenzwert der MAK und TRK.
<G-vec00552-002-s616><dust_off.stäuben><en> Dust Mary Kay® Translucent Loose Powder evenly over the face to reduce shine and create a matte finish Quick View
<G-vec00552-002-s616><dust_off.stäuben><de> Stäuben Sie Mary Kay® Translucent Powder gleichmäßig auf das Gesicht – das verhindert einen glänzenden Teint und sorgt für ein seidig-mattes Finish.
