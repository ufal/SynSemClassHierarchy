<G-vec00701-002-s006><annoy.beleidigen><en> Give your fans the thumbs-up for points, or annoy protesters with rude gestures.
<G-vec00701-002-s006><annoy.beleidigen><de> Geben Sie Ihren Fans Ihr Bestes zur Schau und beleidigen Sie protestierende Demonstranten mit eindeutigen Gesten.
<G-vec00701-002-s007><annoy.belästigen><en> (c) acting in an unsportsmanlike or disruptive manner, or with the intent to annoy, abuse, embarrass, threaten or harass any person(s).
<G-vec00701-002-s007><annoy.belästigen><de> (c) unsportliches oder störendes Verhalten an den Tag legt oder beabsichtigt, (eine) andere Person(en) zu belästigen, zu missbrauchen, zu blamieren, zu bedrohen oder zu schikanieren.
<G-vec00701-002-s008><annoy.belästigen><en> We may prohibit you from participating in or utilizing the Site if in our sole and absolute discretion you show a disregard for this Agreement or act in an unsportsmanlike manner, with the intent to annoy, abuse, threaten, or harass any other person, or in any other disruptive manner.
<G-vec00701-002-s008><annoy.belästigen><de> Wenn wir nach unserem alleinigen Ermessen entscheiden, dass Sie gegen diese Vereinbarung verstoßen, unkooperativ sind oder sich störend verhalten und die Absicht haben, andere Personen zu belästigen, zu missbrauchen, zu bedrohen oder zu schikanieren, untersagen wir Ihnen gegebenenfalls die Mitarbeit an oder Nutzung der Website.
<G-vec00701-002-s009><annoy.belästigen><en> Limited alone to the earth, he will not have the privilege of ranging to other planets, to tempt and annoy those who have not fallen.
<G-vec00701-002-s009><annoy.belästigen><de> Auf die Erde beschränkt, wird er keinen Zugang zu anderen Welten haben, um die zu versuchen und zu belästigen, die nie gefallen sind.
<G-vec00701-002-s021><annoy.nerven><en> To every little thing taken care of and you never had the feeling to annoy him so, but he really wants to spoil us.
<G-vec00701-002-s021><annoy.nerven><de> Um jede Kleinigkeit wurde sich gekümmert und man hatte nie das Gefühl ihn damit zu nerven, sondern das er uns wirklich verwöhnen möchte.
<G-vec00701-002-s022><annoy.nerven><en> Nobody else has the right to annoy us, to pressurise us, let alone to coerce or blackmail us.
<G-vec00701-002-s022><annoy.nerven><de> Kein anderer sonst hat das Recht, uns zu nerven, uns unter Druck zu setzen, geschweige denn, uns zu nötigen und zu erpressen.
<G-vec00701-002-s023><annoy.nerven><en> You don't even have to annoy your parents or your neighbors if you've got some headphones.
<G-vec00701-002-s023><annoy.nerven><de> Du musst dabei nicht mal deine Eltern oder Nachbarn nerven, wenn du Kopfhörer hast.
<G-vec00701-002-s024><annoy.nerven><en> “Russia is able ‘to annoy’ the US by stopping or severely restricting cooperation in outer space, or by cutting supplies of components for Boeing aircraft, [and] close the supply of titanium," said Petr Pushkarev, chief analyst of TeleTrade.
<G-vec00701-002-s024><annoy.nerven><de> "Russland könnte die USA 'nerven', indem es die Zusammenarbeit im Weltraum erheblich einschränkt oder aussetzt oder indem es die Lieferungen von Bestandteilen an Boeing reduziert und die Titan-Lieferungen komplett stoppt", erklärte Petr Puschkarew, der Chefanalyst des Finanzdienstleisters TeleTrade.
<G-vec00701-002-s025><annoy.nerven><en> Anyone who knows me knows that the regular near-accidents with walking sticks on my mountain tours annoy me, as I believe that walking sticks limit the balance of most participants.
<G-vec00701-002-s025><annoy.nerven><de> Wer mich kennt, weiß ja, dass mich die regelmäßigen Beinahe-Unfälle mit Wanderstöcken auf meinen Bergtouren nerven, glaube ich doch, dass Wanderstöcke bei den meisten Teilnehmern das Gleichgewicht einschränken.
<G-vec00701-002-s026><annoy.nerven><en> The song starts to annoy her and she shouts at her eldest child to switch the television off.
<G-vec00701-002-s026><annoy.nerven><de> Das Lied geht ihr auf die Nerven, und sie schreit ihr ältestes Kind an, den Fernseher abzuschalten.
<G-vec00701-002-s027><annoy.nerven><en> Although calls for market and opinion research can annoy us sometimes, they do not constitute as unauthorized telephone advertising, according to the Federal Network Agency.
<G-vec00701-002-s027><annoy.nerven><de> Obwohl Anrufe zur Markt- und Meinungsforschung uns nerven können, stellen sie laut der Bundesnetzagentur grundsätzlich keine unerlaubte Telefonwerbung dar.
<G-vec00701-002-s028><annoy.nerven><en> Tap him, the bell, the gong, the sword or other objects to annoy Tanuki Sensei.
<G-vec00701-002-s028><annoy.nerven><de> Berühre ihn, die Glocke, den Gong, das Schwert oder andere Objekte, um Tanuki Sensei zu nerven.
<G-vec00701-002-s029><annoy.nerven><en> I just read all what comes in my view, even the fine print on the milk carton (one thing my fellow human beings really annoy, especially at breakfast)
<G-vec00701-002-s029><annoy.nerven><de> Ich lese alles, auch das Kleingedruckte auf den Milchtüten (was meine Mitmenschen gerade beim Frühstück ganz schön nerven kann).
<G-vec00701-002-s030><annoy.nerven><en> This is the single easiest way to annoy your teacher.
<G-vec00701-002-s030><annoy.nerven><de> Dies ist die wahrscheinlich einfachste Art seinen Lehrer zu nerven.
<G-vec00701-002-s031><annoy.nerven><en> West asks Mr. Zern questions to annoy Claire.
<G-vec00701-002-s031><annoy.nerven><de> West stellt Mr. Zern Fragen, um Claire zu nerven.
<G-vec00701-002-s033><annoy.nerven><en> Besides excellent measuring values and a brilliant space it is "...fast and precise in every pitch, without having any breeze of "airy" clouding which often leads to an early "AHA-effect" when listening a classical tube preamplifier, but after 15 minutes at the latest this effect will extremely annoy.
<G-vec00701-002-s033><annoy.nerven><de> Neben exzellenten Meßwerten und einer hervorragenden Räumlichkeit ist sie "...schnell und präzise in jeder Tonlage, ohne jeden Hauch von "luftiger" Wolkigkeit", die bei manch klassischer Röhrenvorstufe zunächst zu einem Aha-Effekt führt, nach spätestens einer Viertelstunde extrem nervt.
<G-vec00701-002-s015><annoy.stören><en> They're cool plants, with the added bonus that they'll eat things that annoy you.
<G-vec00701-002-s015><annoy.stören><de> Sie sind kühle Betriebe, mit der addierten Prämie, daß sie Sachen essen, die dich stören.
<G-vec00701-002-s041><annoy.stören><en> Be gentle, do not annoy other prisoners as they can also complain on your behavior and the system will prolong your sentence.
<G-vec00701-002-s041><annoy.stören><de> Sei nett, störe nicht andere im Gefängnis, weil sie sich auch über Ihr Verhalten beschweren können und das System kontrolliert deine Nachrichten.
<G-vec00701-002-s042><annoy.stören><en> We want to clarify in brief, whether these stripes annoy during daily work and in what way they do affect everyday life's use.
<G-vec00701-002-s042><annoy.stören><de> Wir möchten klären, ob diese Streifen bei der täglichen Arbeit stören und wie sich diese im Alltagseinsatz auswirken.
<G-vec00701-002-s043><annoy.stören><en> However, the intense reflections in outdoor use will annoy the user.
<G-vec00701-002-s043><annoy.stören><de> Allerdings stören im Außengebrauch die starken Reflexionen den Nutzer.
<G-vec00701-002-s044><annoy.stören><en> We also make no dirt or take away much space or we don’t annoy anyone.
<G-vec00701-002-s044><annoy.stören><de> Wir machen auch keinen Dreck oder nehmen zu viel Platz ein oder stören andere.
<G-vec00701-002-s045><annoy.stören><en> Napette is attracted by Napo’s charm but her attempts to help him sometimes irritate or annoy Napo.
<G-vec00701-002-s045><annoy.stören><de> Napette findet Napo sehr sympathisch, aber ihre Versuche, ihm zu helfen, stören oder ärgern Napo manchmal.
<G-vec00701-002-s046><annoy.stören><en> If the ads annoy you or you just want to support this app's development, you can easily upgrade to the PRO edition.
<G-vec00701-002-s046><annoy.stören><de> Wenn sie die Werbung stört oder sie einfach die Entwicklung dieser App unterstützen möchten, können sie leicht auf die PRO Edition upgraden.
<G-vec00701-002-s047><annoy.stören><en> In the latter two cases it is mandatory to see to it that the rites not annoy other citizens; i.e., that those rites be carried out in separate facilities.
<G-vec00701-002-s047><annoy.stören><de> In den letzten beiden Fällen muss man sich vergewissern, daß die Zeremonie die anderen Bürger nicht stört, d. h. sie muss in einem gesonderten Raum durchgeführt werden.
<G-vec00701-002-s051><annoy.verärgern><en> Sponsor reserves the right at its sole discretion to disqualify any individual (and void his/her entry) it finds to be tampering with the entry process or the operation of this Challenge or website, intending to annoy, abuse, threaten, or harass any other participant, Sponsor, or any of its representatives or to otherwise be acting in violation of these Official Rules.
<G-vec00701-002-s051><annoy.verärgern><de> Der Organisator behält sich das Recht vor, jedwede Person zu disqualifizieren (und seinen/ihren Wettbewerbsbeitrag ungültig zu machen), die er als Manipulation des Auswahlprozesses der Beiträge oder der Durchführung dieses Wettbewerbs oder Website versteht, mit der Absicht, andere Teilnehmer, den Organisator oder jedweden seiner Repräsentanten zu verärgern, zu missbrauchen, zu bedrohen oder zu belästigen oder anderweitig gegen diese offiziellen Teilnahmeregeln zu verstoßen.
<G-vec00701-002-s052><annoy.verärgern><en> Sharon does not want to annoy Bush.
<G-vec00701-002-s052><annoy.verärgern><de> Sharon möchte Bush nicht verärgern.
<G-vec00701-002-s053><annoy.verärgern><en> This will probably annoy your friend and cause him to be even more self-conscious.
<G-vec00701-002-s053><annoy.verärgern><de> Dies wird deinen Freund wahrscheinlich verärgern und dazu führen, dass er noch befangener ist.
<G-vec00701-002-s054><annoy.verärgern><en> FileMaker Server administrators should make sure the idle time is long enough not to annoy users with frequent disconnections.
<G-vec00701-002-s054><annoy.verärgern><de> FileMaker Server-Administratoren sollten sicherstellen, dass die Leerlaufzeit lang genug ist, um nicht Benutzer durch häufiges Trennen der Verbindung zu verärgern.
<G-vec00701-002-s055><annoy.verärgern><en> Hazards are everywhere on the web, some of them may really annoy and endanger you.
<G-vec00701-002-s055><annoy.verärgern><de> Die Gefahren lauern überall und einige davon könnten Sie wirklich verärgern und gefährden.
<G-vec00701-002-s056><annoy.verärgern><en> These major dissimilarities annoy consumers because they have to have a separate charger for each phone and have to buy new accessories for each new device.
<G-vec00701-002-s056><annoy.verärgern><de> Diese großen Unterschiede verärgern die Verbraucher, weil sie für jedes Telefon ein anderes Ladegerät haben und für jedes neue Gerät auch wieder neues Zubehör anschaffen müssen.
<G-vec00701-002-s057><annoy.verärgern><en> Whether or not a bargain had actually been struck between the British and German Socialists, it was made clear to me in my conversations with Ruhr labor leaders that they were anxious above all not to embarrass or annoy the British Labour Government.
<G-vec00701-002-s057><annoy.verärgern><de> Ob nun tatsächlich zwischen den britischen und deutschen Sozialisten ein Abkommen erzielt worden war oder nicht, meine Gespräche mit den Gewerkschaftsführern an der Ruhr zeigten mir, daß diese vor nichts so sehr Angst hatten als davor, die britische Labour-Regierung zu verärgern.
<G-vec00701-002-s058><annoy.verärgern><en> (3) be threatening, defamatory, abusive or invade another’s privacy, or cause annoyance, inconvenience or needless anxiety or be likely to harass, upset, embarrass, alarm or annoy any other person;
<G-vec00701-002-s058><annoy.verärgern><de> (3) andere Personen bedrohen, verleumden, beleidigen, deren Privatsphäre verletzen, verärgern, stören oder unnötig in Angst versetzen oder andere Personen voraussichtlich belästigen, aufregen, in Verlegenheit bringen, alarmieren oder verärgern.
<G-vec00701-002-s059><annoy.verärgern><en> A number of failed attempts led him to annoy with Pokemon Go game on iPhone.
<G-vec00701-002-s059><annoy.verärgern><de> Mehrere fehlgeschlagene Versuche führten dazu, dass er das Pokemon Go-Spiel auf dem iPhone verärgert hat.
<G-vec00701-002-s060><annoy.verärgern><en> It would annoy Weston if she corrected him, and so for a moment, she considered doing so.
<G-vec00701-002-s060><annoy.verärgern><de> Würde sie Weston darüber aufklären, wäre er verärgert, weshalb sie einen Augenblick erwog, es zu tun.
<G-vec00701-002-s061><annoy.verärgern><en> It’s not uncommon for a new user to annoy others with inappropriate behaviour.
<G-vec00701-002-s061><annoy.verärgern><de> Es ist nicht ungewöhnlich, dass ein neuer Nutzer die anderen mit unangemessenem Verhalten verärgert.
<G-vec00701-002-s005><annoy.ärgern><en> On the other hand, if you’re the more sociable gambler, public tables will provide you with the opportunity to chat, interact with, and possibly annoy other payers.
<G-vec00701-002-s005><annoy.ärgern><de> Andererseits, wenn Sie der geselligere Spieler sind, werden öffentliche Tische Sie mit der Gelegenheit versorgen, zu plaudern, mit anderen Spielern zu interagieren und vielleicht andere Zahler zu ärgern.
<G-vec00701-002-s013><annoy.ärgern><en> You can thwart their efforts, and annoy them in the process, with tangents and/or harmless pranks.
<G-vec00701-002-s013><annoy.ärgern><de> Mit Ablenkungen und/oder harmlosen Streichen kannst du diese Pläne aber durchkreuzen und deinen Lehrer gleichzeitig ärgern.
<G-vec00701-002-s019><annoy.ärgern><en> Hovercraft A persistent pest with a highspeed power unit that likes to sneak up from the dead angle to annoy one with his short stump from behind.
<G-vec00701-002-s019><annoy.ärgern><de> Hovercraft Ein hartnäckiger Plagegeist mit einem Hochgeschwindigkeitsantrieb, der sich am liebsten aus einem toten Winkel heranpirscht um einen mit seinem kurzen Stummel von hinten zu ärgern.
<G-vec00701-002-s038><annoy.ärgern><en> Nasty mutated flame spewing moles have infested the place and dig tunnels just to annoy him.
<G-vec00701-002-s038><annoy.ärgern><de> Scheußliche, mutierte flammenspeiende Maulwürfe haben den ganzen Garten befallen und graben überall Tunnel, nur um Rex zu ärgern.
<G-vec00701-002-s063><annoy.ärgern><en> Epic may disqualify any Contestant from participating in the Contest or winning a prize if, in its sole discretion, it determines such Entrant is attempting to undermine the legitimate operation of the Contest by cheating, hacking, deception, or any other unfair playing practices intending to annoy, abuse, threaten, undermine, or harass any other players or Epic’s representatives.
<G-vec00701-002-s063><annoy.ärgern><de> Epic kann einen Teilnehmer von der Teilnahme am Wettbewerb oder das Gewinnen von Preisen disqualifizieren, sollte Epic nach eigenem Ermessen bestimmen, dass dieser Teilnehmer den rechtmäßigen Ablauf des Wettbewerbs beeinträchtigt sei es durch Cheaten, Hacking, Täuschung oder jedwede andere Spielpraktiken, die andere Spieler oder die Stellvertreter des Wettbewerbs ärgern, missbrauchen, bedrohen oder belästigen.
<G-vec00701-002-s064><annoy.ärgern><en> Be likely to harass, upset, embarrass, alarm or annoy any other person.
<G-vec00701-002-s064><annoy.ärgern><de> • Eine andere Person schikanieren, beunruhigen, in Verlegenheit bringen, erschrecken oder ärgern.
<G-vec00701-002-s065><annoy.ärgern><en> "I have always been careful not to annoy or bother anyone".
<G-vec00701-002-s065><annoy.ärgern><de> "Ich habe immer darauf geachtet, damit niemanden zu ärgern oder zu langweilen".
<G-vec00701-002-s066><annoy.ärgern><en> To annoy a man, Scarlett marries an unloved one.
<G-vec00701-002-s066><annoy.ärgern><de> Um einen Mann zu ärgern, heiratet Scarlett einen Ungeliebten.
<G-vec00701-002-s067><annoy.ärgern><en> You can have friends without problem as far as they don't make damages and you don't annoy. Availability
<G-vec00701-002-s067><annoy.ärgern><de> Sie können so viel Freunde ohne Problem haben, da sie keine Schäden machen und Sie nicht ärgern.
<G-vec00701-002-s068><annoy.ärgern><en> I think that this acts as if the charge of stevedoring boatman or a Smutt Rochus to the captain and wanted to annoy him, because elsewhere is still a lot of space. 3.
<G-vec00701-002-s068><annoy.ärgern><de> Auf mich wirkt das so, als hätten der für das Stauen zuständige Bootsmann oder der Smutt einen Rochus auf den Kapitän und wollten ihn ärgern, denn anderswo ist noch viel Platz.
<G-vec00701-002-s069><annoy.ärgern><en> He says things that annoy me.
<G-vec00701-002-s069><annoy.ärgern><de> Er sagt Dinge, die mich ärgern.
<G-vec00701-002-s070><annoy.ärgern><en> Past these annoyances that can annoy an inhabitant of unsuspecting cities, we had a great time.
<G-vec00701-002-s070><annoy.ärgern><de> Nach diesen Unannehmlichkeiten, die ein Bewohner von ahnungslosen Städten ärgern kann, wir hatten eine tolle Zeit.
<G-vec00701-002-s071><annoy.ärgern><en> When we want to annoy them, we sing 'How Much Is that Dorgi in the Window'.
<G-vec00701-002-s071><annoy.ärgern><de> Wenn wir sie ärgern wollen, singen wir "Was kostet der Dorgi dort im Fenster".
<G-vec00701-002-s072><annoy.ärgern><en> Joseph Beuys didn´t want to annoy anybody - on the contrary – using his art he wanted to communicate with as many people as possible.
<G-vec00701-002-s072><annoy.ärgern><de> Joseph Beuys wollte niemanden ärgern, im Gegenteil: Er wollte über seine Kunst mit möglichst vielen Menschen ins Gespräch kommen.
<G-vec00701-002-s073><annoy.ärgern><en> I always feel like the bogeyman, who imagines himself in his little room louder things to annoy the group.
<G-vec00701-002-s073><annoy.ärgern><de> Ich fühle mich immer wie der Buhmann, der sich in seinem Zimmerchen lauter Sachen ausdenkt, um die Gruppe zu ärgern.
<G-vec00701-002-s074><annoy.ärgern><en> (Video) Aileen would like to eat a banana, as Donna comes into the room to annoy Aileen.
<G-vec00701-002-s074><annoy.ärgern><de> (Video) Aileen möchte in Ruhe ihre Banane essen, da kommt Donna ins Zimmer und fängt an Aileen zu ärgern.
<G-vec00701-002-s075><annoy.ärgern><en> So the time when I could still annoy my mother-in-law using the IKEA Place App is gone.
<G-vec00701-002-s075><annoy.ärgern><de> Vorbei ist also die Zeit, in der ich mit Hilfe der IKEA Place App noch meine Schwiegermutter ärgern konnte.
<G-vec00701-002-s076><annoy.ärgern><en> In reality, this adware soon starts to annoy the users with a constant flow of advertisements and pop-ups.
<G-vec00701-002-s076><annoy.ärgern><de> In Wirklichkeit beginnt diese Adware bald um die Benutzer mit einen konstanten Strom von Werbung und Popups zu ärgern.
<G-vec00701-002-s077><annoy.ärgern><en> Only the sound of the wind in the trees or the birds singing you will "annoy".
<G-vec00701-002-s077><annoy.ärgern><de> Nur das Rauschen des Windes in den Bäumen oder dem Gesang der Vögel werden Sie "ärgern".
<G-vec00701-002-s078><annoy.ärgern><en> The fact that insurances that do nothing but annoy the customers in the end are often sold is irrelevant.
<G-vec00701-002-s078><annoy.ärgern><de> Dass Versicherungen verkauft werden, bei denen sich die Kunden beim Ablauf nur ärgern, spielt keine Rolle.
<G-vec00701-002-s079><annoy.ärgern><en> Stop it, you annoy on your business trip over the badly-equipped gym at the hotel.
<G-vec00701-002-s079><annoy.ärgern><de> Hör auf, dich auf deiner Geschäftsreise über den schlecht ausgestatteten Fitnessraum im Hotel zu ärgern.
<G-vec00701-002-s080><annoy.ärgern><en> One explanation for this is: When people have other people assign them tasks that they don’t really like to do, they think that their supervisors don’t like them, that they’re idiots and only do this to annoy them.
<G-vec00701-002-s080><annoy.ärgern><de> Das lässt sich unter anderem so erklären: Wenn Menschen von Menschen Aufgaben zugeteilt bekommen, die sie nicht so gerne ausführen, denken sie sich, dass ihre Vorgesetzten sie nicht mögen, idiotisch seien und das nur machen, um sie zu ärgern.
<G-vec00701-002-s081><annoy.ärgern><en> “I thought he’d annoy Ron most,” said Hermione dispassionately.
<G-vec00701-002-s081><annoy.ärgern><de> »Ich dachte, der würde Ron am meisten ärgern«, erwiderte Hermine sachlich.
<G-vec00701-002-s082><annoy.ärgern><en> All people visiting me here in Dortmund are always entering Borussia's office, take a picture of the world cup to annoy the Cruzeiro fans at home.
<G-vec00701-002-s082><annoy.ärgern><de> Alle Leute, die mich hier besuchen, gehen immer zur Geschäftsstelle, machen ein Bild mit dem Weltpokal, und ärgern die Fans von Cruzeiro damit zu Hause.
<G-vec00701-002-s083><annoy.ärgern><en> Recognize that not all things in life are there to annoy us or to make life difficult, but also wonderful little presents.
<G-vec00701-002-s083><annoy.ärgern><de> Erkennen, dass all die Dinge nicht nur da sind, um uns zu ärgern, oder uns das Leben schwer zu machen, sondern eben auch wunderbare kleine Geschenke.
<G-vec00701-002-s084><annoy.ärgern><en> Even if this time there will not be such a great number of postcards and the authorities will try to suppress them, this is exactly what we want to propose to you, for this will annoy the suppressors nevertheless.
<G-vec00701-002-s084><annoy.ärgern><de> Auch wenn es diesmal nicht so viele Postkarten sein werden und die Bürokratie versuchen wird, diese zu unterschlagen, wollen wir Euch genau diesen Vorschlag unterbreiten, denn es ärgert die Unterschläger doch.
<G-vec00701-002-s085><annoy.ärgern><en> Among other things, he told me that he likes to “annoy others”.
<G-vec00701-002-s085><annoy.ärgern><de> Er hat mir unter anderem erzählt, dass er gerne „andere Menschen ärgert“.
