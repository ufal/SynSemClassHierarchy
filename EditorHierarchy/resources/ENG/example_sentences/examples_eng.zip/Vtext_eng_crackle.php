<G-vec00681-002-s025><crackle.knacken><en> After the pleasures of the steam room you can get comfortable (up to 25 people) in the sitting room with fireplace to enjoy the crackle of fire.
<G-vec00681-002-s025><crackle.knacken><de> Nach dem Vergnügen des Dampfraumes können sie es sich im Aufenthaltsraum mit Feuerstelle (für bis zu 25 Personen) beim Knacken des Feuers gemütlich machen und entspannen.
<G-vec00681-002-s026><crackle.knacken><en> Crunch, chewiness, creaminess, airiness, crisp, bite, crackle,… all matter.
<G-vec00681-002-s026><crackle.knacken><de> Das Krachen, die Cremigkeit, die Luftigkeit, der Biss, das Knacken von Essen… das alles hat eine Bedeutung.
<G-vec00681-002-s027><crackle.knacken><en> The case may possibly give away a bit under point pressure and creak if not even crackle (in the area of the optical drive).
<G-vec00681-002-s027><crackle.knacken><de> Hier kann das Gehäuse unter punktueller Druckbelastung etwas nachgeben und knarren und mitunter sogar knacken (im Bereich des optischen Laufwerkes).
<G-vec00681-002-s028><crackle.knacken><en> Please check if the crackle comes from the rear wheel.
<G-vec00681-002-s028><crackle.knacken><de> Prüfen Sie zuerst ob das Knacken wirklich vom Hinterrad kommt.
<G-vec00681-002-s030><crackle.knistern><en> Keep stirring until the seeds start to crackle, then add the ginger. 4.
<G-vec00681-002-s030><crackle.knistern><de> Solange umrühren, bis die Samen zu knistern beginnen und dann den Ingwer hinzugeben.
<G-vec00681-002-s031><crackle.knistern><en> Adoro: As a domina I enjoy myself in all areas. I get my fulfillment from you when during our game the whole room is under tension, the air starts to crackle and time and space disappear in a fog of ecstasy.
<G-vec00681-002-s031><crackle.knistern><de> Ik hou van: Als Domina vergnüge ich mich in allen Bereichen.Ich bekomme meine Erfüllung von dir, wenn während unserem Spiel der gesamte Raum unter Spannung steht, die Luft zu knistern beginnt und Zeit und Raum in einem Nebel der Ekstase verschwinden.
<G-vec00681-002-s032><crackle.knistern><en> Consisting of DeNoiser, DeClicker and DeBuzzer, RestoreRig was designed to detect and remove noise, such as clicks, crackle, buzz or hum, accurately restoring your impaired recordings while preserving the audio quality.
<G-vec00681-002-s032><crackle.knistern><de> RestoreRig besteht aus DeNoiser, DeClicker und DeBuzzer, mit denen Sie störende Signale wie Klicks, Knistern und Brummen aus Ihren Aufnahmen entfernen können – ohne dass die Audioqualität darunter leidet.
<G-vec00681-002-s033><crackle.knistern><en> A uniform whoosh and a slight crackle are heard.
<G-vec00681-002-s033><crackle.knistern><de> Gleichmäßiges Rauschen und ein leises Knistern sind zu hören.
<G-vec00681-002-s034><crackle.knistern><en> Burn these candles and enjoy the crackle of the wood wicks.
<G-vec00681-002-s034><crackle.knistern><de> Brennen Sie diese Kerzen und genießen Sie das Knistern des Holz Dochte.
<G-vec00681-002-s036><crackle.knistern><en> Nature exudes an invigorating calm, the loudest sound is the crackle underfoot.
<G-vec00681-002-s036><crackle.knistern><de> Die Natur strahlt eine belebende Ruhe aus, das lauteste Geräusch ist das Knistern unter den Füßen.
<G-vec00681-002-s037><crackle.knistern><en> Relax while stimulating fun and let yourself taste a glass of sparkling Ahrbrugunder when crackle by the fireplace.
<G-vec00681-002-s037><crackle.knistern><de> Entspannen Sie beim anregenden Plausch und lassen Sie sich ein Gläschen funkelnden Ahrbrugunder schmecken, wenn im Kamin die Flammen knistern.
<G-vec00681-002-s039><crackle.knistern><en> It was lovely to wake up and hear the crackle of the fireplace in the living area.
<G-vec00681-002-s039><crackle.knistern><de> Es war schön, aufzuwachen und zu hören, das Knistern des Kamins im Wohnbereich.
<G-vec00681-002-s040><crackle.knistern><en> Synthetic Crackle Quartz Chips Beads Strands, Dyed & Heated, Mixed Color, 5~8x5~8mm, Hole: 1mm;...
<G-vec00681-002-s040><crackle.knistern><de> Vorbereitungszeit: 3 Tage Wunschzettel Synthetischen Knistern Quarz-Chips Perlen Stränge, gefärbt und erhitzt, Gemischte Farbe, 5~8x5~8 mm...
<G-vec00681-002-s041><crackle.knistern><en> You’ll also pick up more subtle sounds and discover noises you didn’t know existed: a baby's soft burble, the hum of a refrigerator, the crackle of an open fire, or the whispered words of a loved one.
<G-vec00681-002-s041><crackle.knistern><de> Sie werden ebenfalls leisere Töne wahrnehmen und Geräusche entdecken, die Sie bisher gar nicht kannten: das leise Plappern eines Babys, das Summen eines Kühlschranks, das Knistern eines offenen Feuers oder geflüsterte Zärtlichkeiten.
<G-vec00681-002-s042><crackle.knistern><en> There are few things more comforting in life than the soft crackle of a charcoal barbecue pitched against the background hum of conversation and laughter.
<G-vec00681-002-s042><crackle.knistern><de> Es gibt nur wenige Dinge im Leben, die schöner sind, als das Knistern eines Holzkohlegrills, in das sich Gespräche und fröhliches Lachen mischen.
<G-vec00681-002-s043><crackle.knistern><en> From the brief dialogue that precedes the pummeling beats of opener "Looking Glass" to the closing hiss and crackle of the title track, Initiation represents a coming of age for the band.
<G-vec00681-002-s043><crackle.knistern><de> Vom kurzen Dialog vor den treibenden Beats des Openers,Looking Glass" bis zum Zischen und Knistern zum Ende des Titeltracks ist,Initiation" das Erwachsenwerden der Band.
<G-vec00681-002-s044><crackle.knistern><en> The Sun began to crackle with the same strange electrical discharge that I had witnessed on my last visit days earlier.
<G-vec00681-002-s044><crackle.knistern><de> Die Sonne begann mit der gleichen seltsamen elektrischen Entladung zu knistern, die ich bei meinem letzten Besuch Tage zuvor erlebt hatte.
<G-vec00681-002-s045><crackle.knistern><en> The sounds like occasional rumbling in the castle or crackle of the fire, splashing of water or dog barking fits the overall view.
<G-vec00681-002-s045><crackle.knistern><de> Der Sound wie gelegentliches Rumoren im Schloß oder Knistern des Feuers, Wasserplätschern oder Hundegegkläff paßt zum Gesamtbild.
<G-vec00681-002-s046><crackle.knistern><en> Something snaps here, a faint crackle there, over there again someone seems to be knocking on the roof like a woodpecker.
<G-vec00681-002-s046><crackle.knistern><de> Irgendwas rastet hier ein, ein leises Knistern dort, darüber scheint wieder jemand wie ein Specht ans Dach zu klopfen.
<G-vec00681-002-s047><crackle.knistern><en> As a domina I enjoy myself in all areas. I get my fulfillment from you when during our game the whole room is under tension, the air starts to crackle and time and space disappear in a fog of Datebelgie
<G-vec00681-002-s047><crackle.knistern><de> Als Domina vergnüge ich mich in allen Bereichen.Ich bekomme meine Erfüllung von dir, wenn während unserem Spiel der gesamte Raum unter Spannung steht, die Luft zu knistern beginnt und Zeit und Raum in einem Nebel der Ekstase verschwinden.
<G-vec00681-002-s048><crackle.knistern><en> Our bonfire was sited down by the river, and in the darkness we could hear the murmur of the water as a counterpoint to the crackle of the fire.
<G-vec00681-002-s048><crackle.knistern><de> Unser Lagerfeuer stand in der Nähe des Flusses und in der Dunkelheit konnten wir das Rauschen des Wassers als Kontrapunkt zum Knistern des Feuers hören.
<G-vec00681-002-s049><crackle.knistern><en> Beside the crickets one can hear a crackle, quite dainty, it comes from the ear.
<G-vec00681-002-s049><crackle.knistern><de> Neben den Grillen hört man ein Knistern, ganz fein, es kommt wohl von den Ähren.
<G-vec00681-002-s051><crackle.knistern><en> The special: They don't crackle and rustle.
<G-vec00681-002-s051><crackle.knistern><de> Das Besondere ist: Es knistert und raschelt nichts.
<G-vec00681-002-s059><crackle.knistern><en> The erotic begins to crackle between us.
<G-vec00681-002-s059><crackle.knistern><de> Die Erotik beginnt unüberhörbar zwischen uns zu knistern.
