<G-vec01023-002-s022><congratulate.beglückwünschen><en> I congratulate all parties on the swift adoption of this Directive and call upon Member States to ensure equally swift implementation at national level."
<G-vec01023-002-s022><congratulate.beglückwünschen><de> Ich beglückwünsche alle Beteiligten zu der raschen Annahme dieser Richtlinie und appelliere an die Mitgliedstaaten, für eine ebenso rasche Umsetzung in ihren Ländern zu sorgen,“ so Binnenmarkt-Kommissar Charlie McCreevy.
<G-vec01023-002-s023><congratulate.beglückwünschen><en> I congratulate Bero on correctly identifying an Imperial Battlemage, but there are many written examples of Welloc's skill in the School of Destruction.
<G-vec01023-002-s023><congratulate.beglückwünschen><de> Ich beglückwünsche Bero zur richtigen Identifizierung eines kaiserlichen Kampfmagiers, aber es gibt viele niedergeschriebene Beispiele von Wellocs Fertigkeiten in der Schule der Zerstörung.
<G-vec01023-002-s024><congratulate.beglückwünschen><en> I congratulate the winners of the 2018 EU Prize for Cultural Heritage / Europa Nostra Awards and their teams for their exceptional and innovative work.
<G-vec01023-002-s024><congratulate.beglückwünschen><de> Ich beglückwünsche die Gewinner des Preises der Europäischen Union für das Kulturerbe / Europa Nostra Awards 2018 und ihre Teams zu ihrer herausragenden und innovativen Arbeit.
<G-vec01023-002-s025><congratulate.beglückwünschen><en> I wholeheartedly congratulate Guntram Vesper on being selected for this award,” Jung added.
<G-vec01023-002-s025><congratulate.beglückwünschen><de> Aus ganzem Herzen beglückwünsche ich Guntram Vesper zu dieser Preisvergabe”, so Jung.
<G-vec01023-002-s026><congratulate.beglückwünschen><en> Katharina Fegebank, Hamburg Minister of Science: “I congratulate the KLU on receiving perpetual state recognition.
<G-vec01023-002-s026><congratulate.beglückwünschen><de> Hamburgs Wissenschaftssenatorin Katharina Fegebank: „Ich beglückwünsche die KLU zur unbefristeten Anerkennung.
<G-vec01023-002-s027><congratulate.beglückwünschen><en> Commissioner Potočnik said “I congratulate Copenhagen on winning the title of European Green Capital 2014.
<G-vec01023-002-s027><congratulate.beglückwünschen><de> Kommissar Potočnik erklärte: „Ich beglückwünsche Kopenhagen zum Titel Grüne Hauptstadt Europas 2014.
<G-vec01023-002-s028><congratulate.beglückwünschen><en> As German Foreign Minister and as her colleague, I congratulate Hillary Clinton on her decision to run for America, and I wish her every success.
<G-vec01023-002-s028><congratulate.beglückwünschen><de> Als deutscher Außenminister und Kollege beglückwünsche ich sie zu ihrer Entscheidung, für Amerika ins Rennen zu gehen und wünsche ihr dabei viel Erfolg.
<G-vec01023-002-s029><congratulate.beglückwünschen><en> I bought the PC Reviver program and congratulate you because it is a very good program.
<G-vec01023-002-s029><congratulate.beglückwünschen><de> Ich kaufte das PC Reviver Programm und beglückwünsche Sie, denn es ist ein sehr gutes Programm.
<G-vec01023-002-s030><congratulate.beglückwünschen><en> I congratulate comrade Raul for his brilliant performance and particularly for his strength of character and dignity when in a kind but firm gesture greeted the United States Head of Government and told him in English: “Mr. President, I’m Castro”.
<G-vec01023-002-s030><congratulate.beglückwünschen><de> Ich beglückwünsche Genossen Raúl zu seinem brillanten Auftreten und vor allem zu der Festigkeit und Würde, als er mit freundlicher, aber fester Geste den Regierungschef der Vereinigten Staaten begrüßte und zu ihm auf Englisch sagte: "Herr Präsident, ich bin Castro".
<G-vec01023-002-s031><congratulate.beglückwünschen><en> Whatever you do, don't congratulate yourself too much or berate yourself either.
<G-vec01023-002-s031><congratulate.beglückwünschen><de> Was immer du tust: Beglückwünsche dich nicht zu sehr, oder: Blas’ dich nicht so auf.
<G-vec01023-002-s032><congratulate.beglückwünschen><en> If you have not suffered any of these irritations, congratulate yourself on your excellent choice of auditors up to now.
<G-vec01023-002-s032><congratulate.beglückwünschen><de> Sollten Sie bisher keine dieser Irritationen erlitten haben, beglückwünsche ich Sie zur guten Auswahl Ihrer bisherigen Wirtschaftsprüfer.
<G-vec01023-002-s033><congratulate.beglückwünschen><en> First of all, congratulate yourself on having a profitable trade.
<G-vec01023-002-s033><congratulate.beglückwünschen><de> Zuallererst beglückwünschen Sie sich zu Ihrem profitablen Trade.
<G-vec01023-002-s034><congratulate.beglückwünschen><en> 9When Tou king of Hamath heard that David had defeated the entire army of Hadadezer king of Zobah, 10he sent his son Hadoram to King David to greet him and congratulate him on his victory in battle over Hadadezer, who had been at war with Tou. Hadoram brought all kinds of articles of gold, of silver and of bronze.
<G-vec01023-002-s034><congratulate.beglückwünschen><de> 9Und als Tou, der König von Hamath, hörte, daß David die ganze Heeresmacht Hadaresers, des Königs von Zoba, geschlagen hatte, 10da sandte er Hadoram, seinen Sohn, zu dem König David, um ihn nach seinem Wohlergehen zu fragen und ihn zu beglückwünschen, darum daß er wider Hadareser gestritten und ihn geschlagen hatte; denn Hadareser war stets im Kriege mit Tou; und er sandte allerlei Geräte von Gold und von Silber und von Erz.
<G-vec01023-002-s035><congratulate.beglückwünschen><en> When the ‘Leopard sign’ is seen…run…to congratulate your patient and ask them about the things that have helped them to such a successful healthy life.
<G-vec01023-002-s035><congratulate.beglückwünschen><de> Wenn Sie das “Leopardenzeichen” sehen... beeilen Sie sich... ihren Patienten zu beglückwünschen und ihn zu fragen, wie er es geschafft hat, ein so gesundes Leben zu leben.
<G-vec01023-002-s036><congratulate.beglückwünschen><en> At number 2 follows Edit, even with you, we want to thank and congratulate you, of course.
<G-vec01023-002-s036><congratulate.beglückwünschen><de> Gleich auf Platz 2 folgt Edit, auch bei Dir wollen wir uns herzlich bedanken und Dich natürlich beglückwünschen.
<G-vec01023-002-s037><congratulate.beglückwünschen><en> 2015 is a jubilee year for your community and we wish to congratulate you on this occasion.
<G-vec01023-002-s037><congratulate.beglückwünschen><de> 2015 ist für Ihre Communauté ein Jubeljahr und wir möchten Sie bei dieser Gelegenheit beglückwünschen.
<G-vec01023-002-s038><congratulate.beglückwünschen><en> 47 Moreover the king's servants came to congratulate our lord King David, saying, `Your God make the name of Solomon more famous than yours, and make his throne greater than your throne.'
<G-vec01023-002-s038><congratulate.beglückwünschen><de> 47 Auch sind die Diener des Königs gekommen, um unseren Herrn, den König David, zu beglückwünschen und zu rufen: Gott lasse Salomos Ruhm noch größer werden als deinen und er mache seinen Thron noch erhabener als deinen Thron.
<G-vec01023-002-s039><congratulate.beglückwünschen><en> One can only congratulate the management of theater Ingolstadt to the purchase of this touring production.
<G-vec01023-002-s039><congratulate.beglückwünschen><de> Man kann die Leitung des Ingolstädter Theaters zu dem Einkauf dieser Tourneeproduktion nur beglückwünschen.
<G-vec01023-002-s040><congratulate.beglückwünschen><en> We congratulate Eden Fine Art with this beautiful new art gallery.
<G-vec01023-002-s040><congratulate.beglückwünschen><de> Wir beglückwünschen Eden Fine Art zu ihrer wunderschönen neuen Kunstgalerie.
<G-vec01023-002-s041><congratulate.beglückwünschen><en> And on this occasion, we wish to hug you and congratulate you.
<G-vec01023-002-s041><congratulate.beglückwünschen><de> Und zu diesem Anlass wollen wir euch umarmen und beglückwünschen.
<G-vec01023-002-s042><congratulate.beglückwünschen><en> It is known that from constellation Your head has come to congratulate you.
<G-vec01023-002-s042><congratulate.beglückwünschen><de> Es ist bekannt, dass aus dem Sternbild Dich ist gekommen, Ihr Leiter zu beglückwünschen.
<G-vec01023-002-s043><congratulate.beglückwünschen><en> Breaking ground in the medical cannabis market, we also congratulate the voters in the states of Florida, Arkansas and North Dakota, which have passed
<G-vec01023-002-s043><congratulate.beglückwünschen><de> Im Hinblick auf die bahnbrechenden Erfolge im Markt für medizinisches Cannabis beglückwünschen wir auch die Wähler in den Bundesstaaten Florida, Arkansas und North Dakota, die sich für eine entsprechende Legalisierung ausgesprochen haben.
<G-vec01023-002-s044><congratulate.beglückwünschen><en> "We congratulate Dr. Dorrit Jacob on her appointment to one of the renowned DFG Heisenberg Professorships," says JGU President Professor Dr. Georg Krausch.
<G-vec01023-002-s044><congratulate.beglückwünschen><de> "Wir beglückwünschen Dr. Dorrit Jacob zu der Bewilligung der angesehenen Heisenberg-Professur durch die DFG", so JGU-Präsident Prof. Dr. Georg Krausch.
<G-vec01023-002-s045><congratulate.beglückwünschen><en> At the same time, the organisations congratulate the Truth and Reconciliation Commission to its work and the finalisation of the comprehensive report.
<G-vec01023-002-s045><congratulate.beglückwünschen><de> Gleichzeitig beglückwünschen die Organisationen die nationale Wahrheits- und Versöhnungskommission Osttimors zu ihrer Arbeit und zur Fertigstellung des umfassenden Abschlussberichts.
<G-vec01023-002-s046><congratulate.beglückwünschen><en> Congratulate Arab Health 2017 On a Successful Ending We met a lot of long-term cooperative partners and got more new friends in Arab Health 2017.
<G-vec01023-002-s046><congratulate.beglückwünschen><de> Beglückwünschen Sie arabische Gesundheit 2017 auf einem erfolgreichen Ende Wir trafen viele langfristigen kooperativen Partner und erhielten neuere Freunde in arabischer Gesundheit 2017.
<G-vec01023-002-s047><congratulate.beglückwünschen><en> Congratulate your friends on a variety of occasions.
<G-vec01023-002-s047><congratulate.beglückwünschen><de> Beglückwünschen Sie Ihre Freunde auf eine Vielzahl von Gelegenheiten.
<G-vec01023-002-s048><congratulate.beglückwünschen><en> “I would like to congratulate Rudi Rutten because he was second all the way and that helped me to keep going,” he said.
<G-vec01023-002-s048><congratulate.beglückwünschen><de> „Ich möchte Rudi Rutten beglückwünschen, weil er im ganzen Verlauf an zweiter Stelle stand, und das half mir durchzuhalten“, so Stéphane.
<G-vec01023-002-s049><congratulate.beglückwünschen><en> "I want to congratulate all of this year's winners on their awards and to thank them for their work," Energy Secretary Steven Chu said.
<G-vec01023-002-s049><congratulate.beglückwünschen><de> „Ich möchte alle diesjährige Sieger auf ihren Preisen beglückwünschen und ihnen für ihre Arbeit danken,“ sagte Energieminister Steven Chu.
<G-vec01023-002-s050><congratulate.beglückwünschen><en> But you can congratulate the authors for the ease of handling, for the simple and convenient user interface, the powerfulness of linking/fitting and hatch functions, to the choice of the DXF format and not a proprietary format.
<G-vec01023-002-s050><congratulate.beglückwünschen><de> Aber man kann sich zur Einfachheit der Handhabung beglückwünschen, zur einfachen und angenehmen Benutzeroberfläche, zur Mächtigkeit der Einbindungs- und Schraffurfunktionen, zur Wahl des DXF Formats und keinem proprietären Format... .
<G-vec01023-002-s051><congratulate.beglückwünschen><en> Now congratulate yourself, send it out to your respondents, and watch their answers roll in!
<G-vec01023-002-s051><congratulate.beglückwünschen><de> Beglückwünschen Sie sich selbst, versenden Sie die Umfrage an Ihre Befragten und beobachten Sie, wie die Beantwortungen eintreffen.
<G-vec01023-002-s052><congratulate.beglückwünschen><en> The Council of the Ukrainian Association of Retired Persons congratulate the members of the organization, seniors both in Ukraine and in the world, and also veterans of our country on this magnificent day.
<G-vec01023-002-s052><congratulate.beglückwünschen><de> Der Rat der Ukrainischen Senioren Union beglückwünscht den Mitgliedern der Organisation, Senioren sowohl in der Ukraine als auch in der ganzen Welt, und dazu auch Veteranen unseres Landes zu diesem wunderbaren Tag.
<G-vec01023-002-s057><congratulate.beglückwünschen><en> I also want to congratulate Russia and President Putin for having done such an excellent job in hosting the World Cup.
<G-vec01023-002-s057><congratulate.beglückwünschen><de> Ich möchte auch Russland und Präsident Putin dazu beglückwünschen, dass sie bei der Austragung der Weltmeisterschaft so hervorragende Arbeit geleistet haben.
<G-vec01023-002-s071><congratulate.beglückwünschen><en> Six city council members of Ottawa went to the show to congratulate it.
<G-vec01023-002-s071><congratulate.beglückwünschen><de> Auch sechs Stadtratsmitglieder von Ottawa besuchten die Gala, um sie zu beglückwünschen.
<G-vec01023-002-s160><congratulate.beglückwünschen><en> Mr President, I should first like to congratulate Mr Markov on his report on the activities of the European Bank for Reconstruction and Development (EBRD).
<G-vec01023-002-s160><congratulate.beglückwünschen><de> Herr Präsident, zunächst möchte ich Herrn Markov zu seinem Bericht über die Aktivitäten der Europäischen Bank für Wiederaufbau und Entwicklung (EBWE) beglückwünschen.
<G-vec01023-002-s019><congratulate.gratulieren><en> To thank, show appreciation, congratulate, reward.
<G-vec01023-002-s019><congratulate.gratulieren><de> Würdigen, anerkennen, gratulieren, belohnen, auszeichnen.
<G-vec01023-002-s021><congratulate.gratulieren><en> DEAR GUESTS, To begin with let me congratulate our German hosts on the occasion of the International Green Week, which brings us together in yet another year in Berlin as we celebrate both tradition and the future of the farming and food industries.
<G-vec01023-002-s021><congratulate.gratulieren><de> Lassen Sie mich zunächst unseren deutschen Gastgebern zur Internationalen Ausstellung der Grünen Woche gratulieren, die uns für weiteres Jahr in Berlin zu einem Treffen zwischen Tradition und Zukunft im Bereich der Landwirtschaft und der Lebensmittelindustrie versammeln.
<G-vec01023-002-s055><congratulate.gratulieren><en> I know how hard it is and I congratulate you, you did well.
<G-vec01023-002-s055><congratulate.gratulieren><de> Ich weiß, wie schwer das ist und daher gratuliere ich Ihnen, das haben Sie gut gemacht.
<G-vec01023-002-s058><congratulate.gratulieren><en> I understand this is purely a business deal, and I'd like to congratulate both Facebook and the Oculus owners.
<G-vec01023-002-s058><congratulate.gratulieren><de> Ich weiß, dass es ein rein geschäftlicher Deal ist und ich möchte den Besitzern von Facebook und Oculus dazu gratulieren.
<G-vec01023-002-s059><congratulate.gratulieren><en> I can only congratulate them for being up there.
<G-vec01023-002-s059><congratulate.gratulieren><de> Ich kann ihnen nur dazu gratulieren, dort oben zu stehen.
<G-vec01023-002-s060><congratulate.gratulieren><en> Before we start, I’d like to congratulate you on writing such a versatile and selfconscious album despite all the (possibly even pressuring) expectations from fans and people with other interests in your music.
<G-vec01023-002-s060><congratulate.gratulieren><de> Bevor wir loslegen, möchte ich dir dazu gratulieren, ein so vielseitiges und selbstbewusstes Album trotz der (möglicherweise bedrückenden) Erwartungen durch Fans und andersartig interessierte Menschen geschrieben zu haben.
<G-vec01023-002-s064><congratulate.gratulieren><en> It is my honor to congratulate relayr for their innovative work and superior contribution to the rapidly evolving IoT industry,” said Ken Briodagh, Editorial Director for IoT Evolution.
<G-vec01023-002-s064><congratulate.gratulieren><de> Es ist mir eine Ehre, dem Team von relayr zu seiner innovativen Arbeit und dem außerordentlichen Beitrag zur sich rasant entwickelnden IoT-Branche zu gratulieren“, sagte Ken Briodagh, Chefredakteur bei IoT Evolution.
<G-vec01023-002-s066><congratulate.gratulieren><en> In the last working week before Christmas, the managing directors Michael Reuter and Pierre Simmler were happy to congratulate over 30 colleagues for their long years of employment.
<G-vec01023-002-s066><congratulate.gratulieren><de> Im Rahmen eines kleinen Jahresausklangs in der letzten Woche vor Weihnachten durfte die Geschäftsführung um Michael Reuter und Pierre Simler an den Standorten Dinkelsbühl (Logistik & Verwaltung) und Wieseth (Produktion) über 30 Kollegen zu ihrem jahrelangen Engagement in der Firma gratulieren.
<G-vec01023-002-s068><congratulate.gratulieren><en> 40 Arch Archer Have the Ranging Guild judge congratulate you for acquiring over 1,000 archery tickets.
<G-vec01023-002-s068><congratulate.gratulieren><de> Lass dir vom Wettkampfrichter in der Gilde der Fernkämpfer zu 1 000 Schützen-Tickets gratulieren.
<G-vec01023-002-s069><congratulate.gratulieren><en> With the New Year well under way, we would like to congratulate all our 2018 PADI Elite Instructor Award recipients.
<G-vec01023-002-s069><congratulate.gratulieren><de> Mit dem fortschreitenden neuen Jahr möchten wir allen Empfängern des PADI Elite Insructor Award 2018 gratulieren.
<G-vec01023-002-s070><congratulate.gratulieren><en> FIFA.com: Salvador, first of all we’d like to congratulate you on your comeback.
<G-vec01023-002-s070><congratulate.gratulieren><de> Salvador, zunächst einmal möchten wir Ihnen zu Ihrer Rückkehr in den Fußball gratulieren.
<G-vec01023-002-s079><congratulate.gratulieren><en> If you do, I heartily congratulate you, because you are the owner of the most precious wealth in life. Chinese version available
<G-vec01023-002-s079><congratulate.gratulieren><de> Wenn das der Fall ist, gratuliere ich Ihnen von Herzen, weil Sie Besitzer des wertvollsten Schatzes im Leben sind.
<G-vec01023-002-s080><congratulate.gratulieren><en> I congratulate both member associations.
<G-vec01023-002-s080><congratulate.gratulieren><de> Ich gratuliere beiden Verbänden.
<G-vec01023-002-s081><congratulate.gratulieren><en> I salute and congratulate you for successfully realizing this cultural festival as an event of solidarity.
<G-vec01023-002-s081><congratulate.gratulieren><de> Ich grüße und gratuliere euch für die erfolgreiche Organisierung des Kulturfestes als eine Veranstaltung der Solidarität.
<G-vec01023-002-s082><congratulate.gratulieren><en> Vincent Berrutto, Director of the EU-Commission for Energy Efficiency in Buildings, Equipment and Transport employed charming words in the Award-Ceremony: «I congratulate Onlog on this achievement .
<G-vec01023-002-s082><congratulate.gratulieren><de> Vincent Berrutto, Direktor der EU-Kommission für Energieeffizienz in Gebäuden, Industrie, Ausrüstung und Transport fand bei der Preisverleihung lobende Worte: «Ich gratuliere der Onlog zu dieser Leistung.
<G-vec01023-002-s083><congratulate.gratulieren><en> "I congratulate you for your courage," one of them said to Stolz.
<G-vec01023-002-s083><congratulate.gratulieren><de> «Ich gratuliere ihnen zu ihrer Tapferkeit», sagte einer von ihnen zu Stolz.
<G-vec01023-002-s084><congratulate.gratulieren><en> I congratulate all the winners here again a warm welcome and for the non-winners, I express my regret... it can not always win each.
<G-vec01023-002-s084><congratulate.gratulieren><de> Ich gratuliere allen Gewinnern hier nochmal aufs herzlichste und bei den Nicht-Gewinnern spreche ich mein Bedauern aus...es kann leider nicht immer jeder gewinnen.
<G-vec01023-002-s085><congratulate.gratulieren><en> On behalf of the nation, I congratulate each one of you for the commission you've earned and for the credit you bring to the United States of America.
<G-vec01023-002-s085><congratulate.gratulieren><de> Im Namen unseres Landes gratuliere ich jedem von Ihnen zu dem erworbenen Patent und zu dem Verdienst, den sie den Vereinigten Staaten von Amerika bringen.
<G-vec01023-002-s086><congratulate.gratulieren><en> I’d like to congratulate all of them on their fantastic ideas for a liveable city and a positive neighbourhood.
<G-vec01023-002-s086><congratulate.gratulieren><de> Ich gratuliere allen zu ihren tollen Ideen für eine lebenswerte Stadt und für eine gute Nachbarschaft.
<G-vec01023-002-s087><congratulate.gratulieren><en> Congratulate and compliment the other players for a job well-done and stay positive about the experience.
<G-vec01023-002-s087><congratulate.gratulieren><de> Gratuliere den anderen Spielern, lobe sie für einen gut erledigten Job und bleibe der Erfahrung gegenüber positiv.
<G-vec01023-002-s088><congratulate.gratulieren><en> "I congratulate Professor Koudelka and his team at TU Graz on this incredible discovery.
<G-vec01023-002-s088><congratulate.gratulieren><de> "Ich gratuliere dem Team um Prof. Koudelka von der TU Graz zu dieser großartigen Entdeckung.
<G-vec01023-002-s089><congratulate.gratulieren><en> I congratulate and thank Dr. Royo for his work and I encourage the people who suffer from Syringomyelia that they please get in contact with the Institute Neurologic of Barcelona.
<G-vec01023-002-s089><congratulate.gratulieren><de> Ich gratuliere und Danke dem Doktor Royo für seine Arbeit und rege alle die, die unter Syringomyelie leiden dazu an, sich mit dem Institut Neurològic (neurologisches Institut) von Barcelona in Verbindung zu setzten.
<G-vec01023-002-s090><congratulate.gratulieren><en> “I would like to warmly congratulate Sabrina on her appointment as FEI Secretary General,” FEI President Ingmar De Vos commented.
<G-vec01023-002-s090><congratulate.gratulieren><de> Präsident Ingmar de Vos sagte: „Ich gratuliere Sabrina Zeender von ganzen Herzen zu ihrer Ernennung.
<G-vec01023-002-s091><congratulate.gratulieren><en> Print I warmly congratulate Denis Mukwege and Nadia Murad Basee Taha who were awarded the Nobel Peace Prize today for their efforts to put an end to sexual violence as a strategy of war.
<G-vec01023-002-s091><congratulate.gratulieren><de> Drucken Ich gratuliere Denis Mukwege und Nadia Murad Basee Taha, denen heute für ihre Bemühungen zur Beendigung von sexueller Gewalt als Mittel der Kriegsführung der Friedensnobelpreis zuerkannt wurde.
<G-vec01023-002-s092><congratulate.gratulieren><en> Androulla Vassiliou, the European Commissioner responsible for culture, stated: "I congratulate Matera on its successful bid.
<G-vec01023-002-s092><congratulate.gratulieren><de> Androulla Vassiliou, die für Bildung, Kultur, Mehrsprachigkeit und Jugend zuständige EU-Kommissarin, sagte dazu: „Ich gratuliere der Stadt Matera zu diesem Erfolg.
<G-vec01023-002-s093><congratulate.gratulieren><en> I congratulate you once again. I wish you good health and new achievements.
<G-vec01023-002-s093><congratulate.gratulieren><de> Ich gratuliere Ihnen allen und wünsche Ihnen Gesundheit und neue Erfolge.
<G-vec01023-002-s094><congratulate.gratulieren><en> I congratulate Ukraine on this special occasion and hope that all Ukrainians will remember this day as an historic milestone on the path to ever-closer cooperation with the EU and its Member States.
<G-vec01023-002-s094><congratulate.gratulieren><de> Ich gratuliere der Ukraine zu diesem besonderen Ereignis und wünsche allen Ukrainern, dass dieser Tag für sie in Erinnerung bleiben möge als ein historischer Meilenstein auf dem Weg zur immer engeren Zusammenarbeit mit der EU und ihren Mitgliedsstaaten.
<G-vec01023-002-s095><congratulate.gratulieren><en> I would like to congratulate the team for this well-deserved award and thank all our customers that took the time to vote for us” stated Dennie Kawahara, Managing Director, OKI Europe Ltd.
<G-vec01023-002-s095><congratulate.gratulieren><de> Ich gratuliere dem Team für diese wohlverdiente Auszeichnung und danke all unseren Kunden, die sich die Zeit genommen haben, für uns zu stimmen", sagte Dennie Kawahara, Managing Director, OKI Europe Ltd.
<G-vec01023-002-s096><congratulate.gratulieren><en> Today I warmly congratulate my niece and her husband to their wedding.
<G-vec01023-002-s096><congratulate.gratulieren><de> Heute gratuliere ich ganz herzlich meiner Nichte und Ihrem Mann zur Hochzeit.
<G-vec01023-002-s097><congratulate.gratulieren><en> I congratulate him; I congratulate Governor Palin for all that they've achieved.
<G-vec01023-002-s097><congratulate.gratulieren><de> Ich gratuliere ihm und ich gratuliere Governeurin Sarah Palin zu allem, was sie erreicht haben.
<G-vec01023-002-s098><congratulate.gratulieren><en> First of all, I cordially congratulate the State Oil Company of Azerbaijan, "Shahdeniz" consortium and companies taking part at this consortium on the occasion of this great achievement.
<G-vec01023-002-s098><congratulate.gratulieren><de> Zuerst gratuliere ich der Staatlichen Erdölgesellschaft Aserbaidschans, dem Konsortium \"Schachdenis\" und den Gesellschaften, die die Mitglieder dieses Konsortiums sind, zu dieser großen Errungenschaft.
<G-vec01023-002-s099><congratulate.gratulieren><en> “I am very pleased with this successful campaign, and I congratulate everyone involved.
<G-vec01023-002-s099><congratulate.gratulieren><de> „Ich freue mich sehr über diesen großen Erfolg und gratuliere allen Beteiligten sehr herzlich.
<G-vec01023-002-s100><congratulate.gratulieren><en> The certificate is one of the best that I have received and I congratulate you on its design.
<G-vec01023-002-s100><congratulate.gratulieren><de> Das Zertificat ist eines der besten, das ich bekommen habe, und ich gratuliere Ihnen zur Skizze.
<G-vec01023-002-s101><congratulate.gratulieren><en> Let's congratulate the European community of Allods Online- guild Ascendancy began conquest of the Tep's Pyramid.
<G-vec01023-002-s101><congratulate.gratulieren><de> Ich will der Europäischen Gemeinschaft von Allods Online gratulieren - Gilde Ascendancy hat Eroberung der Tep's Pyramide begonnen.
<G-vec01023-002-s102><congratulate.gratulieren><en> Or certain members of the UN Human Rights Council: during a session in March, some states had the gall to congratulate Equatorial Guinea for its “unequivocal commitment” to human rights.
<G-vec01023-002-s102><congratulate.gratulieren><de> Oder bestimmte Mitglieder des UN-Menschenrechtsrates: Während einer Sitzung im März besaßen einige Staaten die Frechheit, Äquatorialguinea zu seinem „eindeutigen Bekenntnis“ zu den Menschenrechten zu gratulieren.
<G-vec01023-002-s103><congratulate.gratulieren><en> I saw your I- can- go- anywhere vehicle in the Kiel news and I simply have to congratulate you on it.
<G-vec01023-002-s103><congratulate.gratulieren><de> Ich habe ihren Ich- kann- überall- hin Rollstuhl in den Kieler Nachrichten gesehen und ich muss Ihnen einfach gratulieren.
<G-vec01023-002-s104><congratulate.gratulieren><en> We congratulate Janja Garnbret on this extraordinary performance and wish her much continued success.
<G-vec01023-002-s104><congratulate.gratulieren><de> Wir gratulieren Janja Garnbret ganz herzlich zu dieser außergewöhnlichen Leistung und wünschen ihr weiterhin viel Erfolg.
<G-vec01023-002-s105><congratulate.gratulieren><en> We congratulate and thank our Partners for the official opening ceremony at the international Airport of Doha in Qatar and wish the entire team at Qatar all the best for the new location.
<G-vec01023-002-s105><congratulate.gratulieren><de> Wir gratulieren und danken unseren Partnern für die offizielle Eröffnungszeremonie am internationalen Flughafen von Doha in Katar und wünschen dem gesamten Team in Katar alles Gute für den neuen Standort.
<G-vec01023-002-s106><congratulate.gratulieren><en> “We congratulate Argos Ltd. for this well-deserved award,” said Achim Rudolph-Rolfes, Managing Director at Aspera GmbH.
<G-vec01023-002-s106><congratulate.gratulieren><de> „Wir gratulieren zu dieser verdienten Anerkennung und dem gelungenen Projekt“, so Olaf Diehl, Geschäftsführer der Aspera GmbH.
<G-vec01023-002-s107><congratulate.gratulieren><en> During the rally, the Divine Land Marching Band and waist drum troupe gave performances several times to congratulate the 13 million Chinese people on breaking away from the control of the CCP’s evil specter.
<G-vec01023-002-s107><congratulate.gratulieren><de> Während der Kundgebung gaben das „Himmlische Orchester“ und die Hüfttrommler mehrere Vorführungen, um den 13 Millionen Chinesen zu gratulieren, dass sie sich aus der Kontrolle des bösartigen Geistes der KPC losreißen konnten.
<G-vec01023-002-s108><congratulate.gratulieren><en> We can only congratulate the Steeler shipyard for having these two people on board.
<G-vec01023-002-s108><congratulate.gratulieren><de> Zu diesen beiden Mitarbeitern können wir der Steeler Werft nur gratulieren.
<G-vec01023-002-s109><congratulate.gratulieren><en> We congratulate our Alumni from winter semester 2016/2017 and summer semester 2017.
<G-vec01023-002-s109><congratulate.gratulieren><de> Wir gratulieren den Absolventinnen und Absolventen des Wintersemesters 2016/2017 und des Sommersemesters 2017.
<G-vec01023-002-s110><congratulate.gratulieren><en> At the end of the stroll, we propose you a small moment to meet and congratulate our dogs.
<G-vec01023-002-s110><congratulate.gratulieren><de> Am Ende des Spaziergangs schlagen wir Ihnen einen kleinen Moment vor, um zu treffen und unseren Hunden zu gratulieren.
<G-vec01023-002-s111><congratulate.gratulieren><en> King Azaz and the Mathemagician welcome and congratulate Milo, Tock, and Humbug on rescuing Rhyme and Reason.
<G-vec01023-002-s111><congratulate.gratulieren><de> König Azaz und der Mathematiker begrüssen und gratulieren Milo, Tock und Humbug zur Rettung von Rhyme und Reason.
<G-vec01023-002-s112><congratulate.gratulieren><en> Question: Mr. President, first of all let me congratulate you on behalf of all Azerbaijani journalists on the occasion of the brilliant diplomatic victory at the Lisbon Summit. Because we all have seen how Armenia remained in complete diplomatic isolation and all alone.
<G-vec01023-002-s112><congratulate.gratulieren><de> Frage: Herr Präsident, vor allem möchte ich Ihnen im Namen aller aserbaidschanischen Journalisten zu dem erfolgreichen diplomatischen Sieg, den Sie auf dem Lissabonner Gipfel errungen haben, gratulieren, weil wir alle die Zeugen davon waren, daß Armenien in voller diplomatischen Einsamkeit und in der Isolation geblieben war.
<G-vec01023-002-s113><congratulate.gratulieren><en> When one is invited as a guest to a birthday, wedding or wedding anniversary, one has to congratulate the opportunity to present orally either in person or through a greeting card.
<G-vec01023-002-s113><congratulate.gratulieren><de> Wenn man als Gast zu einem Geburtstag, Hochzeit oder Ehejubiläum eingeladen wird, hat man die Möglichkeit entweder persönlich mündlich oder durch überreichen einer Glückwunschkarte zu gratulieren.
<G-vec01023-002-s114><congratulate.gratulieren><en> We would like to congratulate the winner and to thank all users who took part in the online voting for this year’s “UX Design Award | Public Choice”.
<G-vec01023-002-s114><congratulate.gratulieren><de> Wir gratulieren dem Gewinner und bedanken uns bei allen Nutzern, die an der Online-Abstimmung zum diesjährigen „UX Design Award | Public Choice“ teilgenommen haben.
<G-vec01023-002-s115><congratulate.gratulieren><en> We congratulate Mrs. S. Barile and Mr. S. Zimmermann and their team to this great success.
<G-vec01023-002-s115><congratulate.gratulieren><de> Wir gratulieren ganz herlich Frau S. Barile und Herrn S. Zimmermann sowie dem ganzen Outbound Team zu diesem schönen Resultat.
<G-vec01023-002-s116><congratulate.gratulieren><en> We all hope that you will continue to show discretion and attempt to build bridges, and we congratulate you sincerely on your prize. All the best!
<G-vec01023-002-s116><congratulate.gratulieren><de> Wir alle wünschen dir, dass du ihn mit Besonnenheit fortsetzen kannst, dass du stets auch versuchen wirst, Brücken zu bauen, und wir gratulieren dir ganz herzlich zu diesem Preis.
<G-vec01023-002-s117><congratulate.gratulieren><en> At this point, I would especially like to recognise the pivotal role played by Ross Brawn in this success and congratulate him, too, on his part in this championship victory.
<G-vec01023-002-s117><congratulate.gratulieren><de> An dieser Stelle möchte ich die zentrale Rolle von Ross Brawn für diesen Erfolg betonen und auch ihm zu seinem Anteil an diesem WM-Gewinn gratulieren.
<G-vec01023-002-s118><congratulate.gratulieren><en> They laugh with each other, congratulate the winners from the day before and each demonstrate a true form of sportsmanship that is common on the World Cup circuit.
<G-vec01023-002-s118><congratulate.gratulieren><de> Sie lachen zusammen, gratulieren den Gewinnern des vorherigen Tages und zeigen so ein wirklich sportliches Verhalten, das unter Weltmeisterschaftskreisen üblich ist.
<G-vec01023-002-s119><congratulate.gratulieren><en> In this day of celebration, I wish to congratulate the Falun Gong that reminded us wonderful principles that ennobles each of us. Sincerely yours,
<G-vec01023-002-s119><congratulate.gratulieren><de> An diesem Tag der Feier möchte ich Falun Gong gratulieren, das uns an die wunderbaren Prinzipien erinnert, die jeden von uns veredeln.
<G-vec01023-002-s120><congratulate.gratulieren><en> We know that, and congratulate you. And yes, you're right: you can do it without JULIA too.
<G-vec01023-002-s120><congratulate.gratulieren><de> Das wissen wir und gratulieren Ihnen dazu und ja, Sie haben Recht: ohne JULIA geht es auch.
<G-vec01023-002-s121><congratulate.gratulieren><en> We congratulate Mr. Letta to his new role and are looking forward to the cooperation.
<G-vec01023-002-s121><congratulate.gratulieren><de> Wir gratulieren dem neuen Präsidenten zu seinem Amt und freuen uns auf die Zusammenarbeit.
<G-vec01023-002-s122><congratulate.gratulieren><en> We congratulate you with our Great Holiday, with the Holiday that made us a united people.
<G-vec01023-002-s122><congratulate.gratulieren><de> Wir gratulieren euch mit dieser Großen Feier, welche uns in ein vereintes Volk verbindet.
<G-vec01023-002-s123><congratulate.gratulieren><en> I'd like to congratulate all the players who've beat my high score -- you've earned my legendary respect.
<G-vec01023-002-s123><congratulate.gratulieren><de> Ich möchte gerne allen Spielern gratulieren, die meinen Rekord gebrochen haben – ihr habt meinen legendären Respekt verdient.
<G-vec01023-002-s124><congratulate.gratulieren><en> We congratulate on their success.
<G-vec01023-002-s124><congratulate.gratulieren><de> Wir gratulieren herzlich zu ihrem Erfolg.
<G-vec01023-002-s125><congratulate.gratulieren><en> Among all participants who submitted a correct answer to our prize questions in May, June and Juli, we give away 10 free tickets each month.We congratulate the winners and are happy to welcome them soon on...
<G-vec01023-002-s125><congratulate.gratulieren><de> Unter allen Teilnehmern, welche unsere Gewinnspielfragen im Mai, Juni und Juli richtig beantwortet haben, verlosten wir jedenMonat 10 kostenlose Tickets.Wir gratulieren herzlich und freuen uns bald an Bordbegrüßen zu dürfen:Selimi Adnan...
<G-vec01023-002-s126><congratulate.gratulieren><en> We would like to congratulate the new scholarship recipients and we wish them all the best for the upcoming school year.
<G-vec01023-002-s126><congratulate.gratulieren><de> Wir gratulieren den Empfängern herzlich und wünschen ihnen alles Gute für das kommende Schuljahr.
<G-vec01023-002-s127><congratulate.gratulieren><en> We congratulate them on their numerous awards at the World Beer Awards 2018.
<G-vec01023-002-s127><congratulate.gratulieren><de> Wir gratulieren herzlich zu den zahlreichen Auszeichnungen an den World Beer Awards 2018.
<G-vec01023-002-s128><congratulate.gratulieren><en> We congratulate athletes, coaches, the IBSF and all involved persons.
<G-vec01023-002-s128><congratulate.gratulieren><de> Wir gratulieren Athleten, Betreuern, der IBSF und allen beteiligten Personen herzlich.
<G-vec01023-002-s129><congratulate.gratulieren><en> We sincerely congratulate Dr. MatzE for this achievement and welcome the decision of the doctoral committee consisting of Prof. […]
<G-vec01023-002-s129><congratulate.gratulieren><de> Wir gratulieren Dr. MatzE dazu ganz recht herzlich und begrüßen die Entscheidung des Promotionsausschusses bestehend aus Prof. Dr.-Ing.
<G-vec01023-002-s130><congratulate.gratulieren><en> We are very pleased to continue on this path together with her and congratulate her on her new position," says Dr Martin Huenges, a partner at Maiwald.
<G-vec01023-002-s130><congratulate.gratulieren><de> Wir freuen uns sehr, diesen Weg auch weiter mit ihr gemeinsam zu gehen und gratulieren herzlich zur neuen Position“, so Dr. Martin Huenges, Partner bei Maiwald.
<G-vec01023-002-s131><congratulate.gratulieren><en> His supervisors Prof. Dr. Dr. Lars Schmidt-Thieme, Prof. Dr. Alexandros Nanopoulos and the ISMLL team congratulate and wish all the best for his new position as fellow researcher at the Department of Computer Science and Technical Informatics at the Technical University of Budapest.
<G-vec01023-002-s131><congratulate.gratulieren><de> Seine Betreuer Prof. Dr. Dr. Lars Schmidt-Thieme, Prof. Dr. Alexandros Nanopoulos und das Team vom ISMLL gratulieren recht herzlich und wünschen ihm privat wie auch beruflich als Post-Doc am Lehrstuhl "Technische Informatik" der Technischen Universität Budapest das Allerbeste.
<G-vec01023-002-s132><congratulate.gratulieren><en> We congratulate our trainees and are pleased to employ both of them.
<G-vec01023-002-s132><congratulate.gratulieren><de> Wir gratulieren unseren Auszubildenden und freuen uns, beide Leistungsträger übernehmen zu dürfen.
<G-vec01023-002-s133><congratulate.gratulieren><en> We are pleased to congratulate all top five parks, and are looking forward to the European Star Award 2013, taking place at the EAS event in Paris.
<G-vec01023-002-s133><congratulate.gratulieren><de> Wir gratulieren den Top-5-Parks und freuen uns auf die Verleihung des European Star Award 2013 auf der EAS in Paris.
<G-vec01023-002-s134><congratulate.gratulieren><en> viastore is pleased to congratulate customer Viracopos on being named the best cargo airport in the world by the trade journal Air Cargo World.
<G-vec01023-002-s134><congratulate.gratulieren><de> Wir gratulieren unserem Kunden Viracopos zur Auszeichnung des Fachjournals Air Cargo World als bester Frachtflughafen der Welt.
<G-vec01023-002-s135><congratulate.gratulieren><en> We congratulate Corinna on receiving this honorable Award and her graduation, and welcome her as a new PhD student in our group.
<G-vec01023-002-s135><congratulate.gratulieren><de> Die gesamte Arbeitsgruppe gratuliert Corinna zum Erhalt des Preises und ihrem Studienabschluss.
<G-vec01023-002-s136><congratulate.gratulieren><en> As well the management team congratulate for the successful completion of the training at the headquarters in Wildberg.
<G-vec01023-002-s136><congratulate.gratulieren><de> Auch das Management gratuliert zum erfolgreichen Abschluss der Schulung in der Zentrale in Wildberg.
<G-vec01023-002-s137><congratulate.gratulieren><en> He would like to congratulate the many cellists for their wonderful music-making and for presenting the very high level of cello playing!
<G-vec01023-002-s137><congratulate.gratulieren><de> Er gratuliert den Teilnehmern des Wettbewerbs für ihre wunderbare Präsentation und das hohe Niveau des Cellospiels.
<G-vec01023-002-s138><congratulate.gratulieren><en> The European Falun Dafa Association congratulate the establishment of the Bulgarian Dafa Association.
<G-vec01023-002-s138><congratulate.gratulieren><de> Der Europäische Falun Dafa Verein gratuliert zur Gründung des Bulgarischen Dafa Vereins.
<G-vec01023-002-s139><congratulate.gratulieren><en> We congratulate Anna Westhoff on her prize. to the top
<G-vec01023-002-s139><congratulate.gratulieren><de> Das JSC gratuliert Anna Westhoff herzlich zu diesem Erfolg.
<G-vec01023-002-s140><congratulate.gratulieren><en> “After the race in China I wanted to congratulate him, and he called me straight back and said thanks,” says Alex Fach.
<G-vec01023-002-s140><congratulate.gratulieren><de> „Nach seinem Rennen in China habe ich ihm gratuliert und er direkt zurückgerufen und sich bedankt“, sagt Alex Fach.
<G-vec01023-002-s141><congratulate.gratulieren><en> ForeverGreen would like to congratulate Alexi Pervukhin as he is the fist ForeverGreen Member to receive the Community Stands Leadership Award for taking a Stand in his community.
<G-vec01023-002-s141><congratulate.gratulieren><de> ForeverGreen gratuliert Alexi Pervukhin dazu, dass er das erste ForeverGreen Mitglied ist die Community Stands Führerschaft Auszeichnung zu bekommen, weil er in seine Gemeinschaft eine Stellung bezogen hat.
<G-vec01023-002-s142><congratulate.gratulieren><en> The AVR would like to congratulate the representatives on their election, and also take this opportunity to thank those who were involved with the elections, both actively and passively.
<G-vec01023-002-s142><congratulate.gratulieren><de> Der AVR gratuliert den Gewählten und dankt all denjenigen, die sich aktiv und passiv an den Wahlen beteiligt haben.
<G-vec01023-002-s143><congratulate.gratulieren><en> I was fortunate to meet the manager whilst I was there and must congratulate him on a wonderful island.
<G-vec01023-002-s143><congratulate.gratulieren><de> Ich hatte das Glück den Manager zu treffen, während ich dort war und habe ihm zu der wunderschönen Insel gratuliert.
<G-vec01023-002-s144><congratulate.gratulieren><en> IRIS Adlershof would like to congratulate Sven Ramelow and wishes him much success in his future work.
<G-vec01023-002-s144><congratulate.gratulieren><de> IRIS Adlershof gratuliert herzlich und wünscht Herrn Ramelow viel Erfolg in seiner weiteren Arbeit.
<G-vec01023-002-s145><congratulate.gratulieren><en> Then however, one journalist among this group stood up in order to congratulate all three winners on their awesome sportive performances and wished them all the best for Athens.
<G-vec01023-002-s145><congratulate.gratulieren><de> Bis dem ein Journalist aus den eigenen Reihen ein Ende machte, indem er aufstand, den drei Siegerinnen gratulierte zu ihren großartigen sportlichen Leistungen und ihnen alles Gute für Athen wünschte.
<G-vec01023-002-s146><congratulate.gratulieren><en> I felt like she and the others took a personal interest in my progress, and it was so nice to get a call from Linda to congratulate me when I got offered the job.
<G-vec01023-002-s146><congratulate.gratulieren><de> Es fühlte sich so an, als wäre sie und die anderen persönlich an meinen Fortschritt interessiert und es war so toll, einen Anruf von Linda zu erhalten, in dem sie mir für das Jobangebot gratulierte.
<G-vec01023-002-s147><congratulate.gratulieren><en> Check your Xbox messages for one from NW Community, which will congratulate you on your success.
<G-vec01023-002-s147><congratulate.gratulieren><de> Überprüft euren Xbox Posteingang, ob ihr eine Nachricht von NW Community erhalten habt die euch zu eurem Erfolg gratuliert.
<G-vec01023-002-s148><congratulate.gratulieren><en> We also want to congratulate all the other nominees.
<G-vec01023-002-s148><congratulate.gratulieren><de> Aber natürlich möchten wir auch allen anderen Nominierten herzlich gratulieren.
<G-vec01023-002-s149><congratulate.gratulieren><en> STATEMENTS Statements I wouldn‘t like to miss the opportunity to congratulate the Kammersymphonie to their 20th anniversary.
<G-vec01023-002-s149><congratulate.gratulieren><de> STATEMENTS Statements Ich möchte nicht versäumen, der Kammersymphonie zu ihrem 20-jährigen Jubiläum herzlich zu gratulieren.
<G-vec01023-002-s150><congratulate.gratulieren><en> We would like to congratulate both jubilees and wish them all the best.
<G-vec01023-002-s150><congratulate.gratulieren><de> Zu beiden Anlässen möchten wir beiden Jubilaren herzlich gratulieren.
<G-vec01023-002-s152><congratulate.gratulieren><en> We congratulate the winners Dirk and Daniel.
<G-vec01023-002-s152><congratulate.gratulieren><de> Hiermit gratulieren wir den Siegern Dirk und Daniel.
<G-vec01023-002-s154><congratulate.gratulieren><en> I would especially like to thank and congratulate our award winners for their fine contributions to journalism and the art of reporting.
<G-vec01023-002-s154><congratulate.gratulieren><de> Ich möchte besonders unseren Preisträgern danken und ihnen gratulieren – zu ihren exzellenten Beiträgen zum Journalismus und zur Kunst der Berichterstattung.
<G-vec01023-002-s158><congratulate.gratulieren><en> First, I’d like to congratulate everyone at Metals from the bottom of my heart.
<G-vec01023-002-s158><congratulate.gratulieren><de> Erst mal möchte ich den Metals-Kollegen von ganzem Herzen gratulieren.
<G-vec01023-002-s161><congratulate.gratulieren><en> To conclude, I congratulate the Swiss people on making such a decision.
<G-vec01023-002-s161><congratulate.gratulieren><de> Zum Schluss möchte ich dem Schweizervolk zu seiner Entscheidung gratulieren.
<G-vec01023-002-s162><congratulate.gratulieren><en> They also took the opportunity to congratulate Chinese people in New York and around the world, and to wish them a Happy "Year of Dog."
<G-vec01023-002-s162><congratulate.gratulieren><de> Die Politiker ergriffen auch die Gelegenheit, den Chinesen in New York und auf der ganzen Welt zu gratulieren und ihnen ein glückliches „Jahr des Hundes“ zu wünschen.
<G-vec01023-002-s164><congratulate.gratulieren><en> We proudly congratulate our Chef Fine Dining Heiko Nieder, who has been named “Chef of the Year 2019” by GaultMillau.
<G-vec01023-002-s164><congratulate.gratulieren><de> Mit viel Stolz gratulieren wir unserem Chef Fine Dining, Heiko Nieder, welcher von Gault Millau zum «Koch des Jahres 2019» gekürt wurde.
