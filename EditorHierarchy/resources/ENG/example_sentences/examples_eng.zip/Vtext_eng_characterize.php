<G-vec00417-002-s033><characterize.auszeichnen><en> Instead of taking a superficial advertising tack, Blocher Blocher Partners highlights the unique perspective and exciting themes that characterize the firm's work.
<G-vec00417-002-s033><characterize.auszeichnen><de> Statt vordergründiger Werbung, setzt Blocher Blocher Partners auf die besonderen Blickwinkel und spannenden Themen, die die Unternehmensgruppe auszeichnen.
<G-vec00417-002-s034><characterize.auszeichnen><en> Tranquility, peace, nature and the vastness of the sea – all these are attributes that characterize the North Sea health resort island of Helgoland.
<G-vec00417-002-s034><characterize.auszeichnen><de> Beschaulichkeit, Ruhe, Natur und die Weite des Meeres – dies alles sind Attribute, die das Nordseeheilbad Helgoland auszeichnen.
<G-vec00417-002-s035><characterize.auszeichnen><en> Bookcases with old books, paintings, shotguns, deer antlers and solid wood are some of the peculiarities that characterize the furnishings of this villa.
<G-vec00417-002-s035><characterize.auszeichnen><de> Bücherregale mit alten Büchern, Gemälden, Schrotflinten, Hirschgeweih und Massivholz sind einige der Besonderheiten, die die Einrichtung dieser Villa auszeichnen.
<G-vec00417-002-s036><characterize.auszeichnen><en> Convince yourself. Not only of the flexibility and efficiency that characterize the system, but also of its user-friendliness and patented double stroke technology.
<G-vec00417-002-s036><characterize.auszeichnen><de> Überzeugen Sie sich neben der Flexibilität und Effizienz, welche das System auszeichnen, auch von der Bedienerfreundlichkeit und der patentierten Doppelhubtechnik.
<G-vec00417-002-s037><characterize.auszeichnen><en> On top the shelf-life and freshness should characterize the new pack.
<G-vec00417-002-s037><characterize.auszeichnen><de> Dabei sollen Haltbarkeit und Frische die neue Verpackung auszeichnen.
<G-vec00417-002-s038><characterize.auszeichnen><en> The style and theme of these illustrations are a world away from the cheerful serenity and colorfulness that characterize his other paintings.
<G-vec00417-002-s038><characterize.auszeichnen><de> Der Stil und die Thematik dieser Abbildungen sind meilenweit entfernt von der heiteren Gelassenheit und Farbigkeit, die seine anderen Bilder auszeichnen.
<G-vec00417-002-s039><characterize.auszeichnen><en> Boredom and an unpleasant work atmosphere – Greenfort lacks such features that characterize many other law firms and instead distinguishes itself by its uncompromising good-mood-vibe, amicable atmosphere and authentic humanity.
<G-vec00417-002-s039><characterize.auszeichnen><de> Langeweile, Büro-Muff und schlechte Atmosphäre – Greenfort lässt all das vermissen, wodurch sich viele andere Kanzleien auszeichnen und verschafft sich mit kompromissloser Gute-Laune-Stimmung, freundschaftlicher Atmosphäre und authentischer Menschlichkeit ein außergewöhnliches Gesicht.
<G-vec00417-002-s040><characterize.auszeichnen><en> This Jamón is made by ham experts who know very the way to bring out all the flavour nuances that characterize this particular ham.
<G-vec00417-002-s040><characterize.auszeichnen><de> Dieser Jamón wird von Schinken-Experten hergestellt, die sehr gut wissen, wie man alle Geschmacksnuancen hervorhebt, die diesen besonderen Schinken auszeichnen.
<G-vec00417-002-s041><characterize.auszeichnen><en> Good quality and, above all, resilience are factors which characterize these substances.
<G-vec00417-002-s041><characterize.auszeichnen><de> Starke Qualität und vor allem Belastbarkeit sind Faktoren, die diese Stoffe auszeichnen.
<G-vec00417-002-s042><characterize.auszeichnen><en> High chemical resistance, against oil and fats, are only a few of the attributes that characterize this castor.
<G-vec00417-002-s042><characterize.auszeichnen><de> Hohe chemische Beständigkeit, gegen Öl und Fette, sind nur einige Atribute, die diese Rolle auszeichnen.
<G-vec00417-002-s047><characterize.beschreiben><en> To characterize how pleasant the weather is in Chinchinim throughout the year, we compute two travel scores.
<G-vec00417-002-s047><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Araguanã im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s048><characterize.beschreiben><en> To characterize how pleasant the weather is in Brooks throughout the year, we compute two travel scores.
<G-vec00417-002-s048><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Brooks im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s049><characterize.beschreiben><en> To characterize how pleasant the weather is in El Monte throughout the year, we compute two travel scores.
<G-vec00417-002-s049><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in El Arador im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s050><characterize.beschreiben><en> To characterize how pleasant the weather is in Rūdiškės throughout the year, we compute two travel scores.
<G-vec00417-002-s050><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Yarkovo im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s051><characterize.beschreiben><en> To characterize how pleasant the weather is at Davenport Municipal Airport throughout the year, we compute two travel scores.
<G-vec00417-002-s051><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter am Ağrı Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s052><characterize.beschreiben><en> To characterize how pleasant the weather is in Manhiça throughout the year, we compute two travel scores.
<G-vec00417-002-s052><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Osasco im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s053><characterize.beschreiben><en> To characterize how pleasant the weather is in Cienfuegos throughout the year, we compute two travel scores.
<G-vec00417-002-s053><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Pablo L. Sidar im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s054><characterize.beschreiben><en> To characterize how pleasant the weather is at Edwards County Airport throughout the year, we compute two travel scores.
<G-vec00417-002-s054><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter am Barstow Daggett County Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s055><characterize.beschreiben><en> To characterize how pleasant the weather is in Kayan throughout the year, we compute two travel scores.
<G-vec00417-002-s055><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Ayapa im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s056><characterize.beschreiben><en> To characterize how pleasant the weather is at Redding Municipal Airport throughout the year, we compute two travel scores.
<G-vec00417-002-s056><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter am Gobernador Edgardo Castello Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s057><characterize.beschreiben><en> To characterize how pleasant the weather is at Gioia Del Colle throughout the year, we compute two travel scores.
<G-vec00417-002-s057><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter am Gioia Del Colle im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s058><characterize.beschreiben><en> To characterize how pleasant the weather is in Tarxien throughout the year, we compute two travel scores.
<G-vec00417-002-s058><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Huaranchal im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s059><characterize.beschreiben><en> To characterize how pleasant the weather is in Kirchhundem throughout the year, we compute two travel scores.
<G-vec00417-002-s059><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Calatañazor im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s060><characterize.beschreiben><en> To characterize how pleasant the weather is in Tapalpa throughout the year, we compute two travel scores.
<G-vec00417-002-s060><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Tepango im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s061><characterize.beschreiben><en> To characterize how pleasant the weather is in Bhairab Bāzār throughout the year, we compute two travel scores.
<G-vec00417-002-s061><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Wushi im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s062><characterize.beschreiben><en> To characterize how pleasant the weather is at Samos Aristarchos International Airport throughout the year, we compute two travel scores.
<G-vec00417-002-s062><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter am Honolulu International Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s063><characterize.beschreiben><en> To characterize how pleasant the weather is in Heanor throughout the year, we compute two travel scores.
<G-vec00417-002-s063><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Malie im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s064><characterize.beschreiben><en> To characterize how pleasant the weather is in Seydişehir throughout the year, we compute two travel scores.
<G-vec00417-002-s064><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Peabody im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s065><characterize.beschreiben><en> To characterize how pleasant the weather is in Yenipazar throughout the year, we compute two travel scores.
<G-vec00417-002-s065><characterize.beschreiben><de> Um zu beschreiben, wie angenehm das Wetter in Eleşkirt im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00417-002-s075><characterize.bezeichnen><en> What should have been a conclusive critique of the Donation came in 1433, not from an anti-papal source, but from somebody we might characterize as a liberal reformer within the Church.
<G-vec00417-002-s075><characterize.bezeichnen><de> Es dauerte bis zum Jahre 1433, ehe eine solid fundierte Kritik der Schenkung erschien, und zwar nicht von einem Papstgegner, sondern von jemandem, den man als liberalen Reformer innerhalb der Kirche bezeichnen könnte.
<G-vec00417-002-s076><characterize.bezeichnen><en> If such were the case, I would characterize our good earth as completely degenerate.
<G-vec00417-002-s076><characterize.bezeichnen><de> Wenn das der Fall wäre, dann würde ich unsere gute Erde als völlig entartet bezeichnen.
<G-vec00417-002-s077><characterize.bezeichnen><en> It is of particular significance that the right to characterize the will as free is attained through the experience: In my will an ideal intuition comes to realization.
<G-vec00417-002-s077><characterize.bezeichnen><de> Von besonderer Bedeutung ist, daß die Berechtigung, ein Wollen als frei zu bezeichnen, durch das Erlebnis erreicht wird: in dem Wollen ver- wirklicht sich eine ideelle Intuition.
<G-vec00417-002-s078><characterize.bezeichnen><en> But it is absolutely senseless to characterize the social democracy as the “moderate wing of Fascism.”
<G-vec00417-002-s078><characterize.bezeichnen><de> Absolut unsinnig ist es aber, die Sozialdemokratie als den „gemäßigten Flügel des Faschismus“ zu bezeichnen.
<G-vec00417-002-s079><characterize.bezeichnen><en> Given his irregular manner of ascending to the office, one might characterize him as a symbolic President.
<G-vec00417-002-s079><characterize.bezeichnen><de> Mit seinem außerplanmäßigen Amtsantritt könnte man ihn als einen symbolischen Präsidenten bezeichnen.
<G-vec00417-002-s080><characterize.bezeichnen><en> “ … One might well characterize the back of a painting as its archive, for it is frequently plastered with labels and other slips of paper which disclose something about its history … Only by the look at the back one becomes aware of the physical presence of the work of art as a three-dimensional object.
<G-vec00417-002-s080><characterize.bezeichnen><de> „ … Man könnte die Rückseite eines Gemäldes gut als sein Archiv bezeichnen, da sie oft mit Etiketten und anderen Zetteln beklebt ist, die etwas über seine Geschichte verraten … Erst durch den Blick auf die Rückseite wird man sich der physischen Anwesenheit des Kunstwerks als eines dreidimensionalen Objekts bewusst.
<G-vec00417-002-s100><characterize.charakterisieren><en> The final step of the project is to produce and characterize these natural active ingredients.
<G-vec00417-002-s100><characterize.charakterisieren><de> Als letzten Schritt des Projekts sollen diese natürlichen Wirkstoffe produziert und charakterisiert werden.
<G-vec00417-002-s101><characterize.charakterisieren><en> Blown up by the Germans in 1944, it was reconstructed after accurate studies to rediscover the original curvatures of the arches that still characterize its elegance today.
<G-vec00417-002-s101><characterize.charakterisieren><de> Es wurde von den Deutschen im 1944 zerstört, und dann, nach sorgfältigen Lernen, mit der gebürtige Krümmung der Bögen, die seine Eleganz noch heute charakterisiert, wieder aufgebaut.
<G-vec00417-002-s102><characterize.charakterisieren><en> All the churches are built with the traditional and simple aesthetics that characterize the architecture of Mykonos.
<G-vec00417-002-s102><characterize.charakterisieren><de> Alle Kirchen sind mit der traditionellen und einfachen Ästhetik erbaut, die die Architektur von Mykonos charakterisiert.
<G-vec00417-002-s103><characterize.charakterisieren><en> And if you want a good outline on how to characterize a false teacher, here it is in six statements.
<G-vec00417-002-s103><characterize.charakterisieren><de> Wenn ihr nach einer guten Beschreibung sucht, wie man falsche Lehrer charakterisiert, findet ihr sie hier in sechs Aussagen.
<G-vec00417-002-s104><characterize.charakterisieren><en> Magnetoencephalography was used in conjunction with functional magnetic resonance imaging (fMRI) to localize and characterize cortical sources evoked by temporally asymmetric sounds.
<G-vec00417-002-s104><characterize.charakterisieren><de> Mit Hilfe der Magnetoenzephalographie und funktioneller Magnetresonanztomographie (fMRI) wurden die durch auditorische Stimulation evozierten kortikalen Quellen lokalisiert und charakterisiert.
<G-vec00417-002-s105><characterize.charakterisieren><en> This issue is now circumvented by a new method presented last year by the theorists led by Peter Zoller, which can be used to characterize any entangled state.
<G-vec00417-002-s105><characterize.charakterisieren><de> Dieses Problem umgeht nun eine neue Methode, die Theoretiker um Peter Zoller im Vorjahr vorgestellt haben und mit der beliebige Verschränkungszustände charakterisiert werden können.
<G-vec00417-002-s106><characterize.charakterisieren><en> This happens, but it does not characterize all liberal leaders.
<G-vec00417-002-s106><characterize.charakterisieren><de> Es passiert, aber es charakterisiert nicht alle Führer-Liberalen.
<G-vec00417-002-s107><characterize.charakterisieren><en> Instead, we focus on model systems with specially prepared internal interfaces. We structurally characterize these interfaces on the atomic level and investigate their optical and electronic properties systematically.
<G-vec00417-002-s107><characterize.charakterisieren><de> Vielmehr werden eigens entwickelte Modellsysteme mit einzelnen, speziell präparierten inneren Grenzflächen auf der atomaren Skala strukturell charakterisiert und ihre optischen und elektronischen Eigenschaften systematisch studiert.
<G-vec00417-002-s108><characterize.charakterisieren><en> Further studies will have to characterize this knock-out.
<G-vec00417-002-s108><characterize.charakterisieren><de> Dieser Knock-out muss in weiteren Experimenten charakterisiert werden.
<G-vec00417-002-s141><characterize.kennzeichnen><en> The innovative technique of the BOY E-Series – designed to the increase machine efficiency – as well as interesting and versatile applications characterize the BOY fair appearance at FIP 2014.
<G-vec00417-002-s141><characterize.kennzeichnen><de> Die innovative Technik der BOY E-Baureihe - ausgerichtet auf die Steigerung der Maschineneffizienz - sowie interessante und vielseitige Anwendungen kennzeichnen den Messeauftritt von BOY auf der FIP 2014.
<G-vec00417-002-s142><characterize.kennzeichnen><en> A collection to decorates with modern parallelepiped, mounted on feet of the same material, which characterize the entire collection. Amber
<G-vec00417-002-s142><characterize.kennzeichnen><de> Das Sideboard der Designer Bernhardt & Vella besteht aus einem soliden Holzquader mit Füßen aus dem gleichen Material, welche die gesamte Kollektion kennzeichnen.
<G-vec00417-002-s143><characterize.kennzeichnen><en> Simultaneity and succession also characterize the stages of a speech act: (a) in the formulation process the subject chooses the signs to be uttered from simultaneously given paradigms of virtual signs; (b) in sign utterance the selected signs are produced successively; (c) in the resulting text the signs are given simultaneously and connected by syntagmic structures.
<G-vec00417-002-s143><characterize.kennzeichnen><de> Simultaneität und Sukzession kennzeichnen auch die Stadien des Sprechaktes: (a) im Formulierungsprozeß wählt das Subjekt die zu äußernden Zeichen aus simultan gegebenen Paradigmen von virtuellen Zeichen aus; (b) bei der Zeichenäußerung werden die gewählten Zeichen sukzessive produziert; (c) in dem dabei entstandenen Text sind die Zeichen simultan gegeben und durch syntagmatische Beziehungen miteinander verknüpft.
<G-vec00417-002-s144><characterize.kennzeichnen><en> Gentle hills and green forests characterize the Austrian Mühlviertel, where we design all of our products.
<G-vec00417-002-s144><characterize.kennzeichnen><de> Sanfte Hügel und grüne Wälder kennzeichnen das österreichische Mühlviertel.
<G-vec00417-002-s145><characterize.kennzeichnen><en> Only a few years ago Tony Blair used the term “Meritocracy” to characterize his vision of a new Great Britain and Europe.
<G-vec00417-002-s145><characterize.kennzeichnen><de> Noch vor wenigen Jahren benutzte Tony Blair das Wort “Meritokratie”, um seine Vision eines neuen Großbritannien – und Europa – zu kennzeichnen.
<G-vec00417-002-s146><characterize.kennzeichnen><en> Similar symptoms also characterize inflammatory processes in the prostate gland.
<G-vec00417-002-s146><characterize.kennzeichnen><de> Ähnliche Symptome kennzeichnen auch entzündliche Prozesse in der Prostata.
<G-vec00417-002-s147><characterize.kennzeichnen><en> Countless application areas and a maximum of variability and efficiency characterize the modular construction of our rolling mills as you can readily convince yourself of.
<G-vec00417-002-s147><characterize.kennzeichnen><de> Unzählige Einsatzmöglichkeiten sowie ein Maximum an Variabilität und Effizienz kennzeichnen den modularen Aufbau unserer Walzanlagen – überzeugen Sie sich am besten selbst davon.
<G-vec00417-002-s148><characterize.kennzeichnen><en> A distinctive and hearty freshness characterize the wines of this grape variety.
<G-vec00417-002-s148><characterize.kennzeichnen><de> Eine ausgeprägte und herzhafte Frische kennzeichnen die Weine dieser Rebsorte.
<G-vec00417-002-s149><characterize.kennzeichnen><en> In the second part of our field article series, we explain which properties, possible uses and future prospects characterize fieldbuses.
<G-vec00417-002-s149><characterize.kennzeichnen><de> Im zweiten Teil unserer Fachartikelserie zum Feld erklären wir, welche Eigenschaften, Verwendungsmöglichkeiten und Zukunftsaussichten Feldbusse kennzeichnen.
<G-vec00417-002-s151><characterize.kennzeichnen><en> Quick manual assembly for sheet thicknesses from 18 to 30 mm characterize the new DryLin® LinClip linear liners.
<G-vec00417-002-s151><characterize.kennzeichnen><de> Schnelle Montage per Hand für Blechstärken von 16 - 30 mm kennzeichnen die neuen drylin® LinClip- Lineargleitfolien.
<G-vec00417-002-s152><characterize.kennzeichnen><en> High quality and continuous innovation characterize our product and service portfolio .
<G-vec00417-002-s152><characterize.kennzeichnen><de> Hohe Qualität und ständige Innovation kennzeichnen unser Produkt- und Leistungsportfolio.
<G-vec00417-002-s153><characterize.kennzeichnen><en> Know-how, creativity and business acumen characterize our working style.
<G-vec00417-002-s153><characterize.kennzeichnen><de> Know-how, Kreativität und Geschäftsverständnis kennzeichnen unseren Arbeitsstil.
<G-vec00417-002-s154><characterize.kennzeichnen><en> Sound technical know-how and practice-oriented economic understanding characterize the way we work.
<G-vec00417-002-s154><characterize.kennzeichnen><de> Fundiertes fachliches Know-how und ein praxisorientiertes wirtschaftliches Verständnis kennzeichnen unsere Arbeitsweise.
<G-vec00417-002-s155><characterize.kennzeichnen><en> Participation, interactivity, social networks, fusion of communication services and contents: These and other keywords used in context with 'Web 2.0' characterize technological advancements, which might have a deep impact on the lingual-communicative aspects related to information processing, self-portrayal and forming of communities.
<G-vec00417-002-s155><characterize.kennzeichnen><de> Wörterbücher Interviews Netzwerke, Verschmelzung von Kommunikationsdiensten und Inhalten: Diese und andere gängige Schlagworte für Web 2.0 kennzeichnen technologische Entwicklungstendenzen, die tief greifende Konsequenzen für sprachlich-kommunikative Prozesse der Informationsaufbereitung, Selbstdarstellung und Vergemeinschaftung haben können.
<G-vec00417-002-s156><characterize.kennzeichnen><en> Cooperation and mutual support characterize our work and management style.
<G-vec00417-002-s156><characterize.kennzeichnen><de> Zusammenarbeit und gegenseitige Unterstützung kennzeichnen unseren Arbeits- und Führungsstil.
<G-vec00417-002-s157><characterize.kennzeichnen><en> Works such as Hermann Finsterlin’s »Stilspiel« (Style Game) are an expression of the fantasy and creativity that characterize the game.
<G-vec00417-002-s157><characterize.kennzeichnen><de> Arbeiten wie »Das Stilspiel« von Hermann Finsterlin sind Ausdruck der Phantasie und Kreativität, die das Spiel kennzeichnen.
<G-vec00417-002-s158><characterize.kennzeichnen><en> Progressive design and a sustainable mindset also characterize the footwear styles.
<G-vec00417-002-s158><characterize.kennzeichnen><de> Progressives Design und nachhaltiges Denken kennzeichnen auch die Footwear-Styles.
<G-vec00417-002-s159><characterize.kennzeichnen><en> Flexibility and professionalism characterize our customer relationships.
<G-vec00417-002-s159><characterize.kennzeichnen><de> Flexibilität und Professionalität kennzeichnen unsere Kundenbeziehungen.
