<G-vec00318-002-s044><associate.assoziieren><en> Mentally associate positive health and feeling good with the foods that are beneficial, and remember the consequences of the foods that are off-limits.
<G-vec00318-002-s044><associate.assoziieren><de> Assoziiere mental ein gutes Gefühl und Gesundheit mit diesen Nahrungsmitteln, die günstig für dich sind.
<G-vec00318-002-s045><associate.assoziieren><en> Do not associate Me only with thunder and lightning.
<G-vec00318-002-s045><associate.assoziieren><de> Assoziiere Mich nicht bloß mit dem Donner und Blitz.
<G-vec00318-002-s046><associate.assoziieren><en> Visualize and associate.
<G-vec00318-002-s046><associate.assoziieren><de> Visualisiere und assoziiere.
<G-vec00318-002-s047><associate.assoziieren><en> He has the presence of mind and way of expressing things—avoiding certain issues and emphasising others—that I associate with experienced politicians and diplomats.
<G-vec00318-002-s047><associate.assoziieren><de> Er besitzt eine Geistesgegenwart und eine Art sich auszudrücken, bestimmte Themen auszulassen und andere hervorzuheben, die ich mit erfahrenen Politiker/ innen und Diplomat/ innen assoziiere.
<G-vec00318-002-s048><associate.assoziieren><en> I associate something Romantic with quite a few of your pieces.
<G-vec00318-002-s048><associate.assoziieren><de> Zu mehreren deiner Stücke assoziiere ich Romantisches.
<G-vec00318-002-s049><associate.assoziieren><en> For instance, I have a very clear image of an associate operator from linear algebra.
<G-vec00318-002-s049><associate.assoziieren><de> Ich assoziiere mit einem Operator der linearen Algebra zum Beispiel ein sehr klares Bild.
<G-vec00318-002-s050><associate.assoziieren><en> Autumn is the season, which I associate with celebrations, not only because my birthday falls in this season, but also several birthdays of my friends.
<G-vec00318-002-s050><associate.assoziieren><de> Diese Jahreszeit assoziiere ich mit Feiern, da nicht nur mein Geburtstag in diese Jahreszeit fällt, sondern auch mehrere Geburtstage meiner Freunde.
<G-vec00318-002-s402><associate.bringen><en> The elegant simplicity of Fascinating about Erdems dresses and gowns is, how, even though they seem so extraordinary and striking, one could never associate them with terms as pompous or overloaded.
<G-vec00318-002-s402><associate.bringen><de> Erdem Faszinierend an Erdems Kleidern und Roben ist, wie sie, so außergewöhnlich und auffällig sie auch erscheinen mögen, doch nie mit Anspielungen wie 'prunkvoll' oder gar 'kitschig' in Verbindung gebracht werden könnten.
<G-vec00318-002-s403><associate.bringen><en> Google will in no event associate your IP address with other data.
<G-vec00318-002-s403><associate.bringen><de> Es wird in keinem Fall die IP-Adresse mit anderen den Nutzer betreffenden Daten in Verbindung gebracht.
<G-vec00318-002-s404><associate.bringen><en> A child should not be able to associate the character on the screen with real life characters, they should be distinctly fantasy.
<G-vec00318-002-s404><associate.bringen><de> Der Charakter auf dem Bildschirm sollte von einem Kind nicht mit real existierenden Wesen in Verbindung gebracht werden können, sondern in allen Aspekten ein Fantasiewesen sein.
<G-vec00318-002-s405><associate.bringen><en> We associate the white Flower of Life with goodness, sincerity, beginning and perfection.
<G-vec00318-002-s405><associate.bringen><de> Es wird mit dem Guten, mit Ehrlichkeit, dem Anfang, Unschuld und Perfektion in Verbindung gebracht.
<G-vec00318-002-s406><associate.bringen><en> If there is anything people tend to associate with sunny weather and Bavaria it is surely enjoying a beer in the sun. And along with the one by the aforementioned Chinese Tower, there is any number of other beer gardens in Munich.
<G-vec00318-002-s406><associate.bringen><de> Hiermit wären wir auch schon bei dem Aspekt, der wie kein anderer mit der bayerischen Sommerkultur in Verbindung gebracht wird: Neben jenem am Chinesischen Turm gibt es eine ganze Menge weiterer Biergärten in München.
<G-vec00318-002-s407><associate.bringen><en> Google will never associate your IP address with other data held by Google.
<G-vec00318-002-s407><associate.bringen><de> Keinesfalls wird aber Ihre IP-Adresse durch Google mit anderen Daten von Google in Verbindung gebracht.
<G-vec00318-002-s291><associate.ordnen><en> Associate members' IDs to simplify the facility's access control, including lockers in changing rooms.
<G-vec00318-002-s291><associate.ordnen><de> Ordnen Sie die ID Ihrer Mitglieder zu, um die Zutrittskontrolle und die Nutzung der Schließfächer in den Umkleideräumen zu erleichtern.
<G-vec00318-002-s292><associate.ordnen><en> APG|SGA poster research shows that within five years the recall value for the ÖKK poster campaign has doubled, and seven times as many people associate it with the correct brand.
<G-vec00318-002-s292><associate.ordnen><de> Die APG|SGA-Plakatforschung beweist: innert fünf Jahren hat sich der Erinnerungswert an die ÖKK Plakatkampagne verdoppelt, und sieben Mal so viele Personen ordnen heute die richtige Marke zu.
<G-vec00318-002-s293><associate.ordnen><en> Most viewers associate display noise with the continuously changing noise in an image, which is actually the dynamic noise.
<G-vec00318-002-s293><associate.ordnen><de> Die meisten Betrachter ordnen Displayrauschen dem sich kontinuierlich ändernden Rauschen in einem Bild zu, das tatsächlich dynamisches Rauschen ist.
<G-vec00318-002-s294><associate.ordnen><en> For most images (Windows Vista with SP1, Windows Server 2008, Windows 7, and Windows Server 2008 R2) author an Unattend.xml by using Windows SIM, save it to a known location, and then associate the file with an image using the following procedures.
<G-vec00318-002-s294><associate.ordnen><de> Für die meisten Abbilder (Windows Vista mit SP1, Windows Server 2008, Windows 7 und Windows Server 2008 R2) kann die folgende Vorgehensweise verwendet werden: Erstellen Sie mithilfe von Windows SIM eine Datei vom Typ Unattend.xml, speichern Sie sie an einem bekannten Ort, und ordnen Sie die Datei anschließend mithilfe der weiter unten angegebenen Verfahren einem Abbild zu.
<G-vec00318-002-s295><associate.ordnen><en> Access the full power of your intelligent field devices. Using with your DeltaV system, you can configure field devices from the maintenance shop, store device configurations in your plant database, perform device loop tests and calibrations, associate electronic drawings and notes with a particular device, import or export system data, and establish multi-level password security quickly and easily.
<G-vec00318-002-s295><associate.ordnen><de> Erfahren Sie die volle Leistung Ihrer intelligenten Geräte im Feld Unter Einsatz des AMS Device Managers und dem DeltaV System konfigurieren Sie schnell und einfach Feldgeräte der Wartungsabteilung, speichern Gerätekonfigurationen in Ihrer Anlagen-Datenbank, führen Schleifentests und Kalibrierungen durch, ordnen elektronische Zeichnungen und Notizen bestimmten Geräten zu, importieren oder exportieren Systemdaten und richten einen mehrstufigen Passwortschutz ein.
<G-vec00318-002-s296><associate.ordnen><en> If necessary, create a stand-alone Mediation Server and associate it with a PSTN gateway.
<G-vec00318-002-s296><associate.ordnen><de> Erstellen Sie bei Bedarf einen eigenständigen Vermittlungsserver und ordnen Sie ihm ein PSTN-Gateway zu.
<G-vec00318-002-s297><associate.ordnen><en> Click on the templates tab and associate SNMP device monitoring model (Template SNMP Device).
<G-vec00318-002-s297><associate.ordnen><de> Klicken Sie auf die Registerkarte Vorlagen, und ordnen Sie die Vorlage zur Überwachung eines VMware Server (Template Virt Vmware).
<G-vec00318-002-s298><associate.ordnen><en> In Microsoft Advertising, you create a Location Extension and associate it to a campaign or an ad group.
<G-vec00318-002-s298><associate.ordnen><de> In Microsoft Advertising erstellen Sie eine Standorterweiterung und ordnen diese einer Kampagne oder Anzeigengruppe zu.
<G-vec00318-002-s299><associate.ordnen><en> Referral Tracking: We use Cookies to associate user activity with the third party website that referred the user to our Website, or to associate user activity that Indeed referred to a third party website.
<G-vec00318-002-s299><associate.ordnen><de> Weiterleitungs-Nachverfolgung: Mithilfe von Cookies ordnen wir die Nutzeraktivität der Drittanbieter-Website zu, über die der Nutzer zu unserer Website weitergeleitet wurde.
<G-vec00318-002-s300><associate.ordnen><en> In Microsoft Advertising, you create a Review Extension and associate it to a campaign or an ad group.
<G-vec00318-002-s300><associate.ordnen><de> In Microsoft Advertising erstellen Sie eine Rezensionserweiterung und ordnen diese einer Kampagne oder Anzeigengruppe zu.
<G-vec00318-002-s357><associate.verbinden><en> During the painful sessions they talk about what they associate with Jerusalem and paint a picture among the 20th century’s most important satirists.
<G-vec00318-002-s357><associate.verbinden><de> Während der schmerzhaften Sessions erzählen sie, was sie mit Jerusalem verbindet und zeichnen so das Bild einer Stadt voller Widersprüche.
<G-vec00318-002-s358><associate.verbinden><en> Ask someone from outside Bavaria what they associate with the state and the answers are almost always the same: dirndl and... more
<G-vec00318-002-s358><associate.verbinden><de> Wenn man einen Nicht-Bayern fragt, was er mit dem Bundesland verbindet, dann werden die Antworten fast immer gleich sein: Dirndl...
<G-vec00318-002-s359><associate.verbinden><en> People who are between 50 and 65 years today have grown up with horror movies and associate those not just with the undead and blood baths, but with wonderful teenage memories of movie theater and TV nights together.
<G-vec00318-002-s359><associate.verbinden><de> Wer heute zwischen 50 und 65 Jahre alt ist, der ist mit Horrorfilmen aufgewachsen und verbindet mit ihnen nicht nur Untote und Blutbäder, sondern wunderschöne Jugenderinnerungen an gemeinsame Kinobesuche und Fernsehabende.
<G-vec00318-002-s360><associate.verbinden><en> One cannot help but associate “drones” with Pakistan and Yemen, where the US military use them to execute people without a charge, trial or conviction.
<G-vec00318-002-s360><associate.verbinden><de> Mit „Drohnen“ verbindet man unweigerlich Pakistan und Jemen, wo amerikanische Militärs mit Kampfdrohnen Menschen ohne Anklage, Verhandlung oder Urteil hinrichten.
<G-vec00318-002-s361><associate.verbinden><en> This mix & match regimen associate one universal antioxidant crème and five targeted serums to meet the specific needs of each skin type.
<G-vec00318-002-s361><associate.verbinden><de> Die kombinierbare Pflegeroutine verbindet eine universelle antioxidative Creme und fünf gezielte Seren für die spezifischen Bedürfnisse jedes Hauttyps.
<G-vec00318-002-s362><associate.verbinden><en> Although we primarily associate the food fairs with final products, ever larger areas are being occupied by suppliers of technologies, including the most illustrious brands.
<G-vec00318-002-s362><associate.verbinden><de> Obwohl man Nahrungsmittelmessen allgemein vor allem mit Finalprodukten verbindet, belegen Anbieter von Technologien, weltweit namhafte Marken inbegriffen, immer größere Flächen.
<G-vec00318-002-s363><associate.verbinden><en> Of course, during the first few months the child does not react to his name, does not associate himself with him.
<G-vec00318-002-s363><associate.verbinden><de> Natürlich reagiert das Kind in den ersten Monaten nicht auf seinen Namen, verbindet sich nicht mit ihm.
<G-vec00318-002-s364><associate.verbinden><en> We associate Spain with beautiful beaches, interesting buildings, good wine and great football.
<G-vec00318-002-s364><associate.verbinden><de> Mit Spanien verbindet man schöne Strände, sehenswerte Bauwerke, guten Wein und großartigen Fußball.
<G-vec00318-002-s365><associate.verbinden><en> But the project that Europeans associate his name with first of all is the Istanbul Oriental Ensemble.
<G-vec00318-002-s365><associate.verbinden><de> Doch das Projekt, welches man in Europa zuallererst mit seinem Namen verbindet, ist das Istanbul Oriental Ensemble.
<G-vec00318-002-s366><associate.verbinden><en> In general, you associate with the Vikings - only battles and carnage.
<G-vec00318-002-s366><associate.verbinden><de> Im Allgemeinen verbindet man mit den Wikingern - nur Schlachten und grausames Gemetzel.
<G-vec00318-002-s367><associate.verbinden><en> - System Associate an identifier to a user with the ASP.Net application for all the variables stored during session
<G-vec00318-002-s367><associate.verbinden><de> - System Verbindet eine Kennung mit einem Benutzer über die ASP.Net-Anwendung für alle Variablen, die während der Sitzung gespeichert werden.
<G-vec00318-002-s368><associate.verbinden><en> Red is also the color that we associate with Italian sports cars.
<G-vec00318-002-s368><associate.verbinden><de> Rot ist auch die Farbe, die man mit italienischen Sportwagen verbindet.
<G-vec00318-002-s369><associate.verbinden><en> This new creation will preserve the essence of the Lido’s variety shows (style, glamour, rhinestones, feathers and sequins, and its stunning Bluebell Girls) and associate the bold contributions of the new artistic designers.
<G-vec00318-002-s369><associate.verbinden><de> Diese neue Produktion behält die wesentlichen Merkmale des Lido (Schick, Glamour, Strass, Federn und Pailletten und die strahlenden Bluebell Girls...) bei und verbindet diese mit neuen mutigen künstlerischen Gestaltungsformen.
<G-vec00318-002-s437><associate.verknüpfen><en> once you have given your consent, google will associate your web and app browsing history with your google account for this purpose.
<G-vec00318-002-s437><associate.verknüpfen><de> Haben Sie eine entsprechende Einwilligung erteilt, verknüpft Google zu diesem Zweck Ihren Web– und App-Browserverlauf mit Ihrem Google-Konto.
<G-vec00318-002-s438><associate.verknüpfen><en> If you have an account with a social network integrated in this way and are logged in to said social network when you visit our website, this pixel will associate the page visit with your account.
<G-vec00318-002-s438><associate.verknüpfen><de> Sofern Sie einen Account bei einem hierüber einbezogenen sozialen Netzwerk besitzen und zum Zeitpunkt des Seitenbesuchs dort angemeldet sind, verknüpft dieser Pixel den Seitenbesuch mit Ihrem Account.
<G-vec00318-002-s439><associate.verknüpfen><en> Google will not associate your IP address with any other data held by Google.
<G-vec00318-002-s439><associate.verknüpfen><de> Google verknüpft Ihre IP-Adresse nicht mit anderen Daten im Besitz von Google.
<G-vec00318-002-s440><associate.verknüpfen><en> Google may associate your child’s device identifier or phone number with their Google Account;
<G-vec00318-002-s440><associate.verknüpfen><de> Google verknüpft die Gerätekennung oder Telefonnummer deines Kindes gegebenenfalls mit seinem Google-Konto.
<G-vec00318-002-s441><associate.verknüpfen><en> Google does not associate the IP address with any other data held by Google or attempts to link an IP address to a user's identity.
<G-vec00318-002-s441><associate.verknüpfen><de> Google verknüpft die IP-Adresse nicht mit anderen Daten von Google und versucht nicht, eine IP-Adresse mit der Identität eines Nutzers zu verknüpfen.
<G-vec00318-002-s442><associate.verknüpfen><en> Google will not associate the IP address transferred in the context of Google Analytics with any other data held by Google.
<G-vec00318-002-s442><associate.verknüpfen><de> Google verknüpft die im Kontext von Google Analytics übertragene IP-Adresse nicht mit anderen von Google gespeicherten Daten.
<G-vec00318-002-s443><associate.verknüpfen><en> once you have given your consent, google will associate your web and app browsing history with your google account for this purpose.
<G-vec00318-002-s443><associate.verknüpfen><de> Haben Sie eine entsprechende Einwilligung erteilt, verknüpft Google zu diesem Zweck Ihren Web- und App-Browserverlauf mit Ihrem Google-Konto.
<G-vec00318-002-s445><associate.verknüpfen><en> So if you click on “Like” or leave a comment via such a plug-in, the plug-in will transfer this information to the social media provider and associate it with your existing account on their network.
<G-vec00318-002-s445><associate.verknüpfen><de> Sollten Sie über das Plug-In ein „Like“ vornehmen oder einen Kommentar verfassen, so übermittelt das Plug-In diese Information an den Social Media Anbieter und verknüpft es mit Ihrem bestehenden Account bei diesem Anbieter.
<G-vec00318-002-s446><associate.verknüpfen><en> It is also used to preserve a user’s choice to opt out of behaviorally targeted ads from Microsoft, if the user has chosen to associate the opt-out with his or her Windows Live ID.
<G-vec00318-002-s446><associate.verknüpfen><de> Wird außerdem verwendet, um die Auswahl eines Besuchers beizubehalten, dass er keine gezielte, nutzungsbasierte Werbung mehr von Microsoft erhalten möchte, wenn er die Ablehnung mit der Windows Live ID verknüpft hat.
<G-vec00318-002-s447><associate.verknüpfen><en> If SNI is not supported and you (as the administrator) assign an SSL certificate to a site hosted on a shared IP address, Plesk will associate that certificate with all other sites hosted on this IP address.
<G-vec00318-002-s447><associate.verknüpfen><de> Wenn die Servernamensanzeige nicht unterstützt wird und Sie (als Administrator) einer auf einer gemeinsamen IP-Adresse gehosteten Website ein SSL/TLS-Zertifikat zuweisen, verknüpft Plesk dieses Zertifikat auch mit allen anderen Websites, die auf derselben IP-Adresse gehostet werden.
<G-vec00318-002-s448><associate.verknüpfen><en> If you are a member of a social network and do not want it to associate any information about your visit to our site to you membership data stored with the network, log out of the social network before you activate the social share buttons.
<G-vec00318-002-s448><associate.verknüpfen><de> Wenn Sie Mitglied bei einem sozialen Netzwerk sind und nicht möchten, dass dieses die bei Ihrem Besuch unserer Website gesammelten Daten mit Ihren gespeicherten Mitgliedsdaten verknüpft, müssen Sie sich vor der Aktivierung der Schaltflächen aus dem jeweiligen sozialen Netzwerk ausloggen.
<G-vec00318-002-s449><associate.verknüpfen><en> Tap the Add a contact, company, or deal fields to select records to associate with this task.
<G-vec00318-002-s449><associate.verknüpfen><de> Klicken Sie auf das Feld Hinzufügen von Kontakt, Unternehmen oder Deal, um Datensätze auszuwählen, die mit dieser Aufgabe verknüpft werden sollen.
<G-vec00318-002-s450><associate.verknüpfen><en> To this end, Google will temporarily associate your personal information with Google Analytics data to create target audiences.
<G-vec00318-002-s450><associate.verknüpfen><de> Dazu werden Ihre personenbezogenen Daten von Google vorübergehend mit Google Analytics-Daten verknüpft, um Zielgruppen zu bilden.
<G-vec00318-002-s451><associate.verknüpfen><en> If a user also uses Instagram's services and does not want Instagram to collect data about him through this online offering and associate it with his user data stored on Instagram, they must log out of Instagram and delete their cookies before using our online offering.
<G-vec00318-002-s451><associate.verknüpfen><de> Wenn ein Nutzer zugleich Nutzer der Dienste von Instagram ist und nicht möchte, dass Instagram über dieses Onlineangebot Daten über ihn sammelt und mit seinen bei Instagram gespeicherten Nutzerdaten verknüpft, muss er sich vor der Nutzung unseres Onlineangebotes bei Instagram ausloggen und seine Cookies löschen.
<G-vec00318-002-s452><associate.verknüpfen><en> People associate the 1920s with one image in particular: women with feather boas, ultra long cigarette holders and long gloves.
<G-vec00318-002-s452><associate.verknüpfen><de> Die zwanziger Jahre des letzten Jahrhunderts sind vor allem mit einem Bild verknüpft: Frauen mit Federboas, endlosen Zigarettenspitzen und langen Handschuhen.
<G-vec00318-002-s453><associate.verknüpfen><en> If you have a Vimeo user account and do not want Vimeo to collect data through this web site and associate it with the membership data stored at Vimeo, you must log off of your Vimeo account prior to visiting this web site.
<G-vec00318-002-s453><associate.verknüpfen><de> Wenn Sie ein Vimeo-Benutzerkonto haben und nicht möchten, dass Vimeo über diese Website Daten über Sie sammelt und mit Ihren bei Vimeo gespeicherten Mitgliedsdaten verknüpft, müssen Sie sich vor Ihrem Besuch dieser Website bei Vimeo ausloggen.
<G-vec00318-002-s454><associate.verknüpfen><en> Win7codecs doesn't have any media player and therefore it doesn't associate it to any format.
<G-vec00318-002-s454><associate.verknüpfen><de> Win7codecs hat keinen Media Player und verknüpft ihn daher nicht mit irgendeinem Format.
<G-vec00318-002-s455><associate.verknüpfen><en> Maybe there are a few who can really do that, but most people would end up injuring themselves, and thereafter would begin to associate working out with frustration and disappointment instead of fun and enjoyment.
<G-vec00318-002-s455><associate.verknüpfen><de> Es gibt Menschen, die das können, aber bei den meisten verursacht es Schäden - und sei es, dass Training nicht mehr mit Spaß und Freude, sondern mit Frust und Enttäuschung verknüpft ist.
<G-vec00318-002-s214><associate.zuordnen><en> This allows Facebook to associate visits to my site with your user account.
<G-vec00318-002-s214><associate.zuordnen><de> Dadurch kann Facebook den Besuch unserer Seiten Ihrem Benutzerkonto zuordnen.
<G-vec00318-002-s216><associate.zuordnen><en> This allows Facebook to associate my page visit with your user account.
<G-vec00318-002-s216><associate.zuordnen><de> Dadurch kann Facebook den Besuch meiner Seite Ihrem Benutzerkonto zuordnen.
<G-vec00318-002-s217><associate.zuordnen><en> This means that Instagram can associate visits to our pages with your user
<G-vec00318-002-s217><associate.zuordnen><de> Dadurch kann Instagram den Besuch unserer Seiten Ihrem Benutzerkonto zuordnen.
<G-vec00318-002-s221><associate.zuordnen><en> This means that Twitter can associate visits to our pages with your user account.
<G-vec00318-002-s221><associate.zuordnen><de> Dadurch kann Twitter den Besuch unserer Seiten Ihrem Benutzerkonto zuordnen.
