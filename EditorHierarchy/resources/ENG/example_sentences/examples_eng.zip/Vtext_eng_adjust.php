<G-vec00095-002-s072><adjust.anpassen><en> It is easy to adjust an object to the size of the label.
<G-vec00095-002-s072><adjust.anpassen><de> Sie können ihr Objekt ganz einfach an die gesamte Größe des Etiketts anpassen.
<G-vec00095-002-s073><adjust.anpassen><en> You can choose between different paper types here, and thus optimally adjust your postcards to suit your intended purpose.
<G-vec00095-002-s073><adjust.anpassen><de> Hierbei können Sie zwischen unterschiedlichen Papierarten wählen und so Ihre Postkarten optimal an den gewünschten Verwendungszweck anpassen.
<G-vec00095-002-s074><adjust.anpassen><en> Please visit our product advisor to find out more about how to ergonomically adjust the height of the children’s desk.
<G-vec00095-002-s074><adjust.anpassen><de> Wie Sie die Höhe des Kinderschreibtische optimal an die Körpergröße Ihres Kindes anpassen, erfahren Sie in unserem Produktberater.
<G-vec00095-002-s075><adjust.anpassen><en> The outlook for the future is also outstanding – always assuming companies can adjust themselves to changing conditions affecting the industry.
<G-vec00095-002-s075><adjust.anpassen><de> Die Aussichten für die Zukunft sind damit ebenfalls hervorragend – wenn sich die Unternehmen an die sich wandelnden Rahmenbedingungen anpassen.
<G-vec00095-002-s076><adjust.anpassen><en> Rheinmetall Aktiengesellschaft does not assume any liability or guarantee for such forward-looking statements and will not adjust them to any future results and developments.
<G-vec00095-002-s076><adjust.anpassen><de> Die Rheinmetall Aktiengesellschaft übernimmt keine Haftung oder Gewähr für solche zukunftsgerichteten Aussagen und wird sie nicht an künftige Ergebnisse und Entwicklungen anpassen.
<G-vec00095-002-s077><adjust.anpassen><en> A guaranteed way not to worry about skin irritation is the refusal to shave, but in most cases, women just can't adjust to the experiments with wax or sugar-based.
<G-vec00095-002-s077><adjust.anpassen><de> Ein garantierter Weg, sich keine Sorgen über Hautreizungen zu machen, ist die Weigerung, sich zu rasieren, aber in den meisten Fällen können sich Frauen einfach nicht an die Experimente mit Wachs oder Zucker anpassen.
<G-vec00095-002-s078><adjust.anpassen><en> You can choose between different paper types here, and thus optimally adjust your postcards to suit your intended purpose.
<G-vec00095-002-s078><adjust.anpassen><de> Sie können zwischen unterschiedlichen Papierarten wählen und so Ihre Postkarten optimal an den gewünschten Verwendungszweck anpassen.
<G-vec00095-002-s079><adjust.anpassen><en> This allows the shaver to automatically adjust to every curve of one’s scalp, face or leg for a comfortable and smooth shave.
<G-vec00095-002-s079><adjust.anpassen><de> Dadurch kann sich der Rasierer automatisch an jede Kopf-, Gesichts- oder Beinlinie anpassen, um eine komfortable und sanfte Rasur zu erzielen.
<G-vec00095-002-s080><adjust.anpassen><en> In addition, 61% say they will adjust their supply chain or do so in the near future due to stronger trade conflicts and punitive tariffs.
<G-vec00095-002-s080><adjust.anpassen><de> Darüber hinaus geben 61 % an, dass sie wegen stärkerer Handelskonflikte und Strafzölle ihre Supply-Chain anpassen oder das in naher Zukunft tun werden.
<G-vec00095-002-s081><adjust.anpassen><en> You can adjust the Facet to suit your exact needs.
<G-vec00095-002-s081><adjust.anpassen><de> Sie können den Facet ganz an Ihre Bedürfnisse anpassen.
<G-vec00095-002-s082><adjust.anpassen><en> With adjustable torso length (Bergans QuickAdjust II) and top tensioners, you can quickly adjust the backpack to the day’s requirements.
<G-vec00095-002-s082><adjust.anpassen><de> Mittels verstellbarer Rückenlänge (Bergans QuickAdjust II) und Stabilisierungsriemen lässt sich der Rucksack im Handumdrehen an die jeweiligen Bedürfnisse anpassen.
<G-vec00095-002-s083><adjust.anpassen><en> You can also refuse the use of cookies and adjust your browser configuration. forward bookmark list []
<G-vec00095-002-s083><adjust.anpassen><de> An dieser Stelle können Sie auch der Verwendung von Cookies widersprechen und die Browsereinstellungen entsprechend anpassen.
<G-vec00095-002-s084><adjust.anpassen><en> Now, however, you can check trends with a few clicks and adjust the operation of your business accordingly, thereby optimizing all resources.
<G-vec00095-002-s084><adjust.anpassen><de> Jetzt können Sie die Tendenzen mit paar Mausklicken prüfen, den Betrieb Ihres Unternehmens an diese anpassen und jede Ressource optimieren.
<G-vec00095-002-s085><adjust.anpassen><en> With the colour variety of WAREMA you can individually adjust your external venetian blinds to your facade.
<G-vec00095-002-s085><adjust.anpassen><de> Mit der Farbvielfalt von WAREMA können Sie Ihre Außenjalousien individuell an Ihre Fassade anpassen.
<G-vec00095-002-s086><adjust.anpassen><en> "The technically demanding routes meant that riders had to work hard and adjust their pace were a constant companion.
<G-vec00095-002-s086><adjust.anpassen><de> Durch die technisch anspruchsvollen Strecken mussten die Teilnehmer hart arbeiten und ihr Tempo an die schwierigen Bedingungen anpassen.
<G-vec00095-002-s087><adjust.anpassen><en> Top-slewing cranes from Liebherr can adjust to any specific requirement.
<G-vec00095-002-s087><adjust.anpassen><de> High-sich Obendreher von Liebherr an jede spezifische Anforderung anpassen.
<G-vec00095-002-s088><adjust.anpassen><en> The Gillette Sensor Excel razor for men features self-adjusting twin blades that automatically adjust to every curve of your face.
<G-vec00095-002-s088><adjust.anpassen><de> Der Gillette Sensor Excel Rasierer für Männer verfügt über selbst justierende Doppelklingen, die sich automatisch an jede Kurve Ihres Gesichts anpassen.
<G-vec00095-002-s089><adjust.anpassen><en> When the car is equipped with the optional virtual cockpit, the driver can adjust how the instruments are displayed to suit their preferences.
<G-vec00095-002-s089><adjust.anpassen><de> Mit dem optional erhältlichen Virtual Cockpit kann der Fahrer die Anzeigen ganz an seine persönlichen Vorlieben anpassen.
<G-vec00095-002-s090><adjust.anpassen><en> Not just a question of looks: BMW M Performance Parts let you adjust the chassis of your BMW to suit your needs and your driving style perfectly.
<G-vec00095-002-s090><adjust.anpassen><de> Nicht nur eine Frage der Optik: Mit BMW M Performance Parts können Sie das Fahrwerk Ihres BMW optimal an Ihre Wünsche und Ihr Fahrverhalten anpassen.
<G-vec00095-002-s091><adjust.anpassen><en> To fully utilize the screen area with different aspect contents, it required the user to use an additional anamorphic lens or manually adjust the zoom/focus every time.
<G-vec00095-002-s091><adjust.anpassen><de> Für eine volle Bildfüllung ist es erforderlich, jedes mal den Zoom und Fokus an das Format anzupassen oder mit teuren Anamorphoten Objektiven zu arbeiten.
<G-vec00095-002-s092><adjust.anpassen><en> Tchibo therefore decided to gradually adjust the sizes when procuring its shipping packages, from mid-2015, to reflect the results of the study.
<G-vec00095-002-s092><adjust.anpassen><de> Tchibo hat daraufhin beschlossen, bei der Beschaffung der Versandverpackungen die Größen ab Mitte 2015 schrittweise an die Ergebnisse der Studie anzupassen.
<G-vec00095-002-s093><adjust.anpassen><en> Smart With minimal instructions of an employee, our robots can easily adjust themselves to a new assignment, changes in the environment or product variations.
<G-vec00095-002-s093><adjust.anpassen><de> Smart Unsere Roboter sind mit minimalen Anweisungen eines Mitarbeiters in der Lage, sich schnell an eine neue Bestellung, eine Veränderung der Umgebung oder Produktvariationen anzupassen.
<G-vec00095-002-s094><adjust.anpassen><en> Originally, the mound did not exist, was created as a result of uranium mining and has now been redeveloped to sustainably adjust impacts on the population and the environment to the natural environment.
<G-vec00095-002-s094><adjust.anpassen><de> Ursprünglich existierte der Haldenberg nicht, entstand infolge des Uranabbaus und wurde nun saniert, um die Auswirkungen auf Bevölkerung und Umwelt nachhaltig an den Naturraum anzupassen.
<G-vec00095-002-s095><adjust.anpassen><en> This is the reason why so called leap seconds are inserted into the UTC time scale, they adjust process of the UTC time to the real earth rotation.
<G-vec00095-002-s095><adjust.anpassen><de> Um den Verlauf der UTC-Zeit an die tatsächliche Erddrehung anzupassen, werden von Zeit zu Zeit sogenannte Schaltsekunden in die UTC-Zeitskala eingefügt.
<G-vec00095-002-s096><adjust.anpassen><en> Kanban gives us the flexibility to individually adjust development processes to capacities and procedures in our company.
<G-vec00095-002-s096><adjust.anpassen><de> Kanban gibt uns die Flexibilität, Entwicklungsprozesse individuell an Kapazitäten und Abläufe in unserem Unternehmen anzupassen.
<G-vec00095-002-s097><adjust.anpassen><en> The modification of the H2 sub-ceiling in current prices needs to be translated into 2011 prices in order to technically adjust the MFF table in 2011 prices.
<G-vec00095-002-s097><adjust.anpassen><de> Die Änderung der Teilobergrenze der Rubrik 2 zu jeweiligen Preisen erfordert die Umwandlung in Preise von 2011, um die MFR-Tabelle technisch an die Preise von 2011 anzupassen.
<G-vec00095-002-s098><adjust.anpassen><en> contact solutions ROVEMA Retrofit GmbH offers its customers specific and individual solutions for converting, renewing and complementing second-hand packaging machines in order to effectively and successfully adjust them to new packaging requirements and technical developments.
<G-vec00095-002-s098><adjust.anpassen><de> Kontakt Lösungen Die ROVEMA Retrofit GmbH bietet ihren Kunden spezifische und individuelle Lösungen für Umbau, Erneuerung oder Ergänzung von gebrauchten Verpackungsmaschinen, um diese effektiv und erfolgreich an neue Verpackungsanforderungen und technische Entwicklungen anzupassen.
<G-vec00095-002-s099><adjust.anpassen><en> We reserve the right to update our privacy policy in due course to improve privacy and / or to adjust it according to changes in regulatory practice or jurisdiction.
<G-vec00095-002-s099><adjust.anpassen><de> Wir behalten uns vor, die Datenschutzerklärung zu gegebener Zeit zu aktualisieren, um den Datenschutz zu verbessern und/oder an geänderte Behördenpraxis oder Rechtsprechung anzupassen.
<G-vec00095-002-s100><adjust.anpassen><en> SKW Stahl-Metallurgie Holding AG does not intend and assumes no liability to update such forward-looking statements and to adjust them to future events and developments.
<G-vec00095-002-s100><adjust.anpassen><de> Die SKW Stahl-Metallurgie Holding AG beabsichtigt nicht und übernimmt keinerlei Verpflichtung, derartige zukunftsgerichtete Aussagen zu aktualisieren und an zukünftige Ereignisse oder Entwicklungen anzupassen.
<G-vec00095-002-s101><adjust.anpassen><en> Should this be the case, the supplier shall be required to reasonably adjust the contractual regulations in line with the changing conditions.
<G-vec00095-002-s101><adjust.anpassen><de> Der Lieferant ist in diesem Fall verpflichtet, die vertraglichen Regelungen im Rahmen des Zumutbaren an die veränderten Verhältnisse anzupassen.
<G-vec00095-002-s102><adjust.anpassen><en> The Wii U project kicked off when we thought that we should adjust to the new HD standard for home televisions.
<G-vec00095-002-s102><adjust.anpassen><de> Das Wii U-Projekt nahm seinen Ursprung, als wir begannen, darüber nachzudenken, unsere Technologie an den neuen HD-Standard der heimischen Fernsehgeräte anzupassen.
<G-vec00095-002-s103><adjust.anpassen><en> IXOLIT shall be entitled to adjust the remuneration once a year according to the price in-crease of the current consumer price index (CPI) or an index replacing it.
<G-vec00095-002-s103><adjust.anpassen><de> IXOLIT ist berechtigt, die Vergütung entsprechend der Preissteigerung des jeweiligen Verbraucherpreisindex (VPI) oder eines an seine Stelle tretenden Index einmal jährlich anzupassen.
<G-vec00095-002-s104><adjust.anpassen><en> Analysing user behaviour through tracking helps us to review the effectiveness of our Services, to optimise them and adjust them to meet the needs of the user, as well as to resolve errors.
<G-vec00095-002-s104><adjust.anpassen><de> Die Analyse des Nutzerverhaltens mittels Tracking hilft uns, die Effektivität unserer Services zu überprüfen, sie zu optimieren und an die Bedürfnisse der Nutzer anzupassen sowie Fehler zu beheben.
<G-vec00095-002-s105><adjust.anpassen><en> To continue improving our services and adjust them to the necessities of PhD students, the Methodenwoche is regularly evaluated.
<G-vec00095-002-s105><adjust.anpassen><de> Um das Angebot der GGG und die Ausrichtung der Methodenwoche noch besser an die Wünsche und Bedürfnisse der Promovierenden anzupassen, wird die Methodenwoche regelmäßig evaluiert.
<G-vec00095-002-s106><adjust.anpassen><en> Ideally, air conditioning systems should include variable volume flow control and speed-controlled fans such that they can adjust efficiently to changes of usage.
<G-vec00095-002-s106><adjust.anpassen><de> RLT-Anlagen sollten mit einer variablen Volumenstromregelung und drehzahlgeregelten Ventilatoren arbeiten, um sich effizient an ein geändertes Nutzungsverhalten anzupassen.
<G-vec00095-002-s107><adjust.anpassen><en> Fully automatically, Finishing® will adjust to the requirements of the relevant food, but the quality remains at the highest level at all times.
<G-vec00095-002-s107><adjust.anpassen><de> Vollautomatisch wird das Finishing® an die Bedürfnisse der jeweiligen Speisen angepasst, die Qualität bleibt aber jederzeit auf höchstem Niveau.
<G-vec00095-002-s108><adjust.anpassen><en> In such a case your doctor may need to adjust your other antiparkinson medicines, especially levodopa, to give sufficient control of your symptoms.
<G-vec00095-002-s108><adjust.anpassen><de> In diesem Fall muss die Dosierung Ihrer anderen Antiparkinson-Arzneimittel, insbesondere von Levodopa, angepasst werden, um eine ausreichende Kontrolle Ihrer Parkinson-Beschwerden zu erzielen.
<G-vec00095-002-s109><adjust.anpassen><en> The "Change metadata" function allows you to adjust single information statements simultaneously for multiple items, without entering the detailed view. Changes cannot be canceled.
<G-vec00095-002-s109><adjust.anpassen><de> Mit der Funktion „Metadaten ändern“ können einzelne Informationen bei mehreren Items gleichzeitig angepasst werden, ohne die Detailansicht der Fragen zu öffnen.
<G-vec00095-002-s110><adjust.anpassen><en> The lower handles adjust the softness (edge transparency) of the luma channel’s contribution to the key.
<G-vec00095-002-s110><adjust.anpassen><de> Mit den unteren Aktivpunkten wird die Weichheit (Randtransparenz) angepasst, die der Luma-Kanal zur Stanzmaske beiträgt.
<G-vec00095-002-s111><adjust.anpassen><en> According to your and our interest in data security we continuously check and adjust our security measures in order to achieve a higher protection standard.
<G-vec00095-002-s111><adjust.anpassen><de> Unserem und Ihrem Interesse an Datensicherheit entsprechend werden diese Sicherungsmaßnahmen laufend überprüft und angepasst, um einen höheren Schutzstandard zu erreichen.
<G-vec00095-002-s112><adjust.anpassen><en> Perfect length, not too wide, not too tight, and you can adjust it in the waist.
<G-vec00095-002-s112><adjust.anpassen><de> Perfekte Länge, nicht zu weit, nicht zu eng, und in der Taille kann die Weite sogar angepasst werden.
<G-vec00095-002-s113><adjust.anpassen><en> Due to the big range of available thicknesses (50 up to 400 you are able to adjust the performance of the screen perfectly to your environment.
<G-vec00095-002-s113><adjust.anpassen><de> Durch die große Bandbreite an erhältlichen Schichtdicken (50 bis zu 400 können die Eigenschaften perfekt an die Umgebungsbedingungen angepasst werden.
<G-vec00095-002-s114><adjust.anpassen><en> If the appointment compose form already has an existing end time, setting the end time subsequently will adjust both the duration and end time.
<G-vec00095-002-s114><adjust.anpassen><de> Wenn das Formular zum Verfassen des Termins bereits eine Endzeit aufweist, werden durch das spätere Festlegen der Endzeit die Dauer und die Endzeit angepasst.
<G-vec00095-002-s115><adjust.anpassen><en> Subsequently, the so-called “structure generator” places spheres according to the given size distribution in a virtual box and adjust the size to satisfy an arbirtraily defined porosity.
<G-vec00095-002-s115><adjust.anpassen><de> Anschließend werden von einem sogenannten Strukturgenerator Kugeln gemäß einer vorgegebenen Größenverteilung in einer virtuellen Box platziert und deren Größe angepasst, um eine beliebige vordefinierte Porosität einzuhalten.
<G-vec00095-002-s116><adjust.anpassen><en> As the numerous references show, the Biturox® Process grants a maximum flexibility in crude selection – as it can – different to just physical distillation - adjust the structural balance and the molecular distribution of the bitumen by chemical conversion.
<G-vec00095-002-s116><adjust.anpassen><de> Wie zahlreiche Referenzen zeigen, gewährt der Biturox®-Prozess maximale Flexibilität bei der Auswahl der Rohöle, da in diesem Prozess – im Gegensatz zu einfacher physikalischer Destillation – das strukturelle Gleichgewicht und die molekulare Verteilung des Bitumens durch chemische Umwandlung angepasst werden kann.
<G-vec00095-002-s117><adjust.anpassen><en> The horizontal and/or vertical spaces between several elements of a dialog can be distributed evenly by selecting them via multiple selection and then using the or icon in the toolbar of the Target Editor or the corresponding commands in the text menu to adjust them.
<G-vec00095-002-s117><adjust.anpassen><de> Die horizontalen und/oder vertikalen Abstände zwischen mehreren Elemente eines Dialogs lassen sich vereinheitlichen, indem diese zunächst per Mehrfachauswahl markiert werden und anschließend über die Icons oder in der Symbolleiste des Target Editor oder über die entsprechenden Befehle im Kontextmenü angepasst werden.
<G-vec00095-002-s118><adjust.anpassen><en> You can now use Logic Remote to adjust Format controls in Alchemy.
<G-vec00095-002-s118><adjust.anpassen><de> Ab sofort können die Formatsteuerungen in Alchemy mit Logic Remote angepasst werden.
<G-vec00095-002-s119><adjust.anpassen><en> If you selected the Discovery Service of another location as the DDS, you would have to adjust the proxy settings for this DDS installation.
<G-vec00095-002-s119><adjust.anpassen><de> Würde als DDS ein Discovery Service eines anderen Standorts gewählt werden, müssen die Proxy-Einstellungen dieser DDS Installation zuvor angepasst werden.
<G-vec00095-002-s120><adjust.anpassen><en> Thanks to social distancing and restrictions on movement, we have had to adjust our working practice and adapt to new technologies.
<G-vec00095-002-s120><adjust.anpassen><de> Aufgrund sozialer Distanzierung und Bewegungseinschränkungen haben wir unsere Arbeitspraxis angepasst und neue Technologien eingeführt.
<G-vec00095-002-s121><adjust.anpassen><en> The pull tabs are designed to ease putting the product on the body and removing easily after use and can be used to adjust during play.
<G-vec00095-002-s121><adjust.anpassen><de> Die Zuglaschen erleichtern das Aufsetzen des Produkts auf den Körper und das Entfernen nach Gebrauch und können während des Spielens angepasst werden.
<G-vec00095-002-s122><adjust.anpassen><en> If you change the size/shape of the selected item, the aspect ratio will automatically adjust.
<G-vec00095-002-s122><adjust.anpassen><de> Wenn Sie die Größe/Form des markierten Objekts ändern, wird das Seitenverhältnis automatisch angepasst.
<G-vec00095-002-s123><adjust.anpassen><en> In the "Display" navigator, you can adjust the display so that the member deformations are also shown as rendered cross-sections.
<G-vec00095-002-s123><adjust.anpassen><de> Im "Zeigen"-Navigator kann die Darstellung so angepasst werden, dass die Stabverformungen auch als gerenderte Querschnitte angezeigt werden (Bild 1).
<G-vec00095-002-s124><adjust.anpassen><en> This will adjust the overall brightness of the image.
<G-vec00095-002-s124><adjust.anpassen><de> So wird die allgemeine Helligkeit des Bildes angepasst.
<G-vec00095-002-s125><adjust.anpassen><en> Drinking active water can quickly adjust electrolyte balance of human body, quench thirst, and eliminate alcohol and fatness.
<G-vec00095-002-s125><adjust.anpassen><de> Durch das Trinken von aktivem Wasser kann das Elektrolythaushalt des menschlichen Körpers schnell angepasst, der Durst gelöscht und Alkohol und Fett beseitigt werden.
<G-vec00095-002-s126><adjust.anpassen><en> *Prices may adjust based on the US dollar to Euro conversion rate.
<G-vec00095-002-s126><adjust.anpassen><de> *Die Preise können aufgrund des Umrechnungskurses von US-Dollar zum Euro angepasst werden.
<G-vec00095-002-s127><adjust.anpassen><en> Every jeweller or watch maker can adjust your LAiMER watch to the desired size.
<G-vec00095-002-s127><adjust.anpassen><de> Deine LAiMER Holzuhr kann von jedem Juwelier und Uhrmacher auf die gewünschte Größe angepasst werden.
<G-vec00095-002-s128><adjust.anpassen><en> Twenty adjustable height positions allow you to adjust the rack according to your individual needs and selected exercises.
<G-vec00095-002-s128><adjust.anpassen><de> Zwanzig Höhenpositionen sind einstellbar, sodass das Rack je nach individuellem Bedarf und gewählter Übung angepasst werden kann.
<G-vec00095-002-s129><adjust.anpassen><en> We just have to adjust the activities to their requirements.
<G-vec00095-002-s129><adjust.anpassen><de> Die Aktivitäten müssen nur an ihre Bedürfnisse angepasst werden.
<G-vec00095-002-s130><adjust.anpassen><en> The app serves as a digital ticket and lets you individually adjust the pick-up moment to avoid waiting time.
<G-vec00095-002-s130><adjust.anpassen><de> Die Serva App dient als digitales Ticket mit der jederzeit die Abholzeit individuell angepasst werden kann, um Wartezeiten zu vermeiden.
<G-vec00095-002-s131><adjust.anpassen><en> With every supported output format, you can adjust its settings to get better quality or smaller file size.
<G-vec00095-002-s131><adjust.anpassen><de> Einstellungen jedes unterstützten Ausgabeformats können angepasst werden, um bessere Qualität oder kleinere Dateigröße zu erzielen.
<G-vec00095-002-s132><adjust.anpassen><en> Since we have been manufacturing our products for many years, it is necessary for us to adjust our manufacturing processes to new materials and shapes.
<G-vec00095-002-s132><adjust.anpassen><de> Da unsere Produkte über Jahre hergestellt werden, müssen unsere Prozesse ständig neuen Materialien und Formen angepasst werden.
<G-vec00095-002-s133><adjust.anpassen><en> Fixed: Fixed inability to adjust the transition length for Reach/Spring Key.
<G-vec00095-002-s133><adjust.anpassen><de> Behoben: Übergangslänge von Ausrichten/Feder Keys konnte nicht angepasst werden.
<G-vec00095-002-s134><adjust.anpassen><en> You can therefore adjust the seat size of the saddle to suit each individual rider.
<G-vec00095-002-s134><adjust.anpassen><de> Somit kann die Sitzgröße des Sattels an den jeweiligen Reiter angepasst werden.
<G-vec00095-002-s135><adjust.anpassen><en> You can’t adjust this setting on the mobile web just yet.
<G-vec00095-002-s135><adjust.anpassen><de> Diese Einstellung kann über das mobile Web derzeit noch nicht angepasst werden.
<G-vec00095-002-s136><adjust.anpassen><en> Using the control-unit, it is possible to view and adjust all settings.
<G-vec00095-002-s136><adjust.anpassen><de> Mithilfe der Control-Unit können sämtliche Einstellungen angezeigt sowie angepasst werden.
<G-vec00095-002-s137><adjust.anpassen><en> Moreover we can adjust the static pressure to the ambient temperature via the special valve.
<G-vec00095-002-s137><adjust.anpassen><de> Zusätzlich kann über das Spezialventil der statische Vordruck feinjustiert an die Umgebungstemperatur angepasst werden.
<G-vec00095-002-s138><adjust.anpassen><en> The ability to adjust the lighting individually is also important, as employees do ultimately have different needs.
<G-vec00095-002-s138><adjust.anpassen><de> Wichtig ist auch, dass die Beleuchtung individuell angepasst werden kann – schließlich unterscheiden sich die Bedürfnisse der einzelnen Mitarbeiter.
<G-vec00095-002-s139><adjust.anpassen><en> a manual trailing stop loss order follows the same principle as an automated trailing stop loss but you manually adjust its position as the price moves.
<G-vec00095-002-s139><adjust.anpassen><de> ...ein manueller Trailing Stop-Loss denselben Prinzipien wie ein automatischer Trailing Stop-Loss unterliegt, wobei die Position jedoch vom Trader manuell angepasst werden muss.
<G-vec00095-002-s140><adjust.anpassen><en> With three different zone focusing areas, it’s super-fast and easy to adjust to every focusing distance desired.
<G-vec00095-002-s140><adjust.anpassen><de> Mit drei verschiedenen Fokusbereichen kann jede Fokusdistanz superschnell und einfach angepasst werden.
<G-vec00095-002-s141><adjust.anpassen><en> Adjust the depth of the 3D image by simply sliding your stylus on the Touch Screen.
<G-vec00095-002-s141><adjust.anpassen><de> Die Tiefe deines 3D-Bildes kann durch Verschieben des Touchpens auf dem Touchscreen angepasst werden.
<G-vec00095-002-s142><adjust.anpassen><en> The focusing mechanism was fundamentally reworked in the 2017 edition to make it possible to more quickly and accurately adjust the focal distance.
<G-vec00095-002-s142><adjust.anpassen><de> Bei der Edition 2017 wurde der Fokussiermechanismus grundlegend überarbeitet, sodass der Fokusabstand schneller und genauer angepasst werden kann.
<G-vec00095-002-s143><adjust.anpassen><en> A corn united harvest machine as long as the change and adjust a few parts, can be used to harvest rice, wheat and barley, beans, corn, sorghum, and sunflower and other crops.
<G-vec00095-002-s143><adjust.anpassen><de> Eine Mais-Einheits-Erntemaschine kann verwendet werden, um Reis, Weizen und Gerste, Bohnen, Mais, Sorghum, Sonnenblumen und andere Pflanzen zu ernten, solange die Teile gewechselt und angepasst werden.
<G-vec00095-002-s144><adjust.anpassen><en> In addition to viewing the song title and speaker position, you can search for other songs, change the order or adjust the volume.
<G-vec00095-002-s144><adjust.anpassen><de> Neben Songtitel und Lautsprecherstandort, kann nach weiteren Songs gesucht, die Reihenfolge verändert oder die Lautstärke angepasst werden.
<G-vec00095-002-s145><adjust.anpassen><en> You can also make money with videos on Dailymotion, adjust the player, and oversee revenue with the analysis tool.
<G-vec00095-002-s145><adjust.anpassen><de> Auch bei Dailymotion können Sie die Monetisierung von Videos freischalten, den Player anpassen und per Analyse-Tool die Einnahmen kontrollieren.
<G-vec00095-002-s146><adjust.anpassen><en> It should also be possible to adjust dates, times and addresses to suit the customary styles in specific countries.
<G-vec00095-002-s146><adjust.anpassen><de> Landesspezifische Standards für die Darstellung von Datum, Uhrzeit und Adressen sollten sich ebenfalls anpassen lassen.
<G-vec00095-002-s147><adjust.anpassen><en> We can adjust product size to make product install conveniently, improve the customer's production efficiency.
<G-vec00095-002-s147><adjust.anpassen><de> Wir können die Produktgröße anpassen, um das Produkt bequem zu installieren und die Produktionseffizienz des Kunden zu verbessern.
<G-vec00095-002-s148><adjust.anpassen><en> If VAT is applicable and the rate changes between your order date and the date we supply the product, we will adjust the rate of VAT that you pay, unless you have already paid for the product in full before the change in the rate of VAT takes effect.
<G-vec00095-002-s148><adjust.anpassen><de> Wenn der Mehrwertsteuersatz sich jedoch zwischen dem Datum Ihrer Bestellung und dem Lieferdatum ändert, werden wir die von Ihnen zu zahlende Mehrwertsteuer anpassen, es sei denn, Sie haben die Produkte bereits vollständig bezahlt, bevor die Änderung des Mehrwertsteuersatzes in Kraft tritt.
<G-vec00095-002-s149><adjust.anpassen><en> The CL-E321 is simple and intuitive to use, so that Users do not waste Time when they change Labels or adjust Settings.
<G-vec00095-002-s149><adjust.anpassen><de> Der CL-E321 ist einfach und intuitiv zu bedienen, so dass Benutzer keine Zeit verschwenden, wenn Sie Etiketten ändern oder Einstellungen anpassen.
<G-vec00095-002-s150><adjust.anpassen><en> Here you can choose format as MP3, AAC, FLAC or WAV and adjust the output quality as required.
<G-vec00095-002-s150><adjust.anpassen><de> Hier können Sie das Ausgabeformat als MP3, AAC, FLAC oder WAV wählen und Ausgabequalität bis zu 320 Kbps anpassen.
<G-vec00095-002-s151><adjust.anpassen><en> The Lely Vector enables cattle farmers to define and adjust their feeding strategy for different groups of animals.
<G-vec00095-002-s151><adjust.anpassen><de> Mithilfe des Lely Vector können Viehhalter ihre Fütterungsstrategie für unterschiedliche Gruppen von Kühen definieren und exakt anpassen.
<G-vec00095-002-s152><adjust.anpassen><en> You can also adjust the settings so that your browser rejects all cookies (or only third party cookies).
<G-vec00095-002-s152><adjust.anpassen><de> Sie können die Einstellungen auch so anpassen, dass Ihr Browser alle Cookies (oder nur Cookies von Dritten) ablehnt.
<G-vec00095-002-s153><adjust.anpassen><en> You can adjust the tint of an individual object, or create tints by using the Tint slider in the Swatches panel or Color panel.
<G-vec00095-002-s153><adjust.anpassen><de> Sie können den Farbton eines einzelnen Objekts anpassen oder Farbtöne mithilfe des Farbton-Schiebereglers im Farbfeld- oder Farbbedienfeld erstellen.
<G-vec00095-002-s154><adjust.anpassen><en> Administrators can now adjust Lightweight Directory Access Protocol (LDAP) queries to obtain public keys from servers that use a different schema.
<G-vec00095-002-s154><adjust.anpassen><de> Administratoren können nun Lightweight Directory Access Protocol (LDAP) Anfragen anpassen, um öffentliche Schlüssel von Servern zu erhalten, die ein anderes Schema verwenden.
<G-vec00095-002-s155><adjust.anpassen><en> With the built-in firewall, you can adjust the device completely to your requirements.
<G-vec00095-002-s155><adjust.anpassen><de> Mit der integrierten Firewall können Sie das Gerät komplett Ihren Anforderungen anpassen.
<G-vec00095-002-s156><adjust.anpassen><en> This allows him to tactically adjust the line-up to the opposing team.
<G-vec00095-002-s156><adjust.anpassen><de> Er kann die Aufstellung dadurch taktisch dem Gegner anpassen.
<G-vec00095-002-s157><adjust.anpassen><en> (Multi-Speed + LCD screen): With speeds ranging from 1 - 6 km / h, the treadmill allows you to adjust the speed by remote control according to your physical condition and your exercise needs.
<G-vec00095-002-s157><adjust.anpassen><de> Description (Multi-Speed + LCD-Bildschirm): Mit Geschwindigkeiten von 1 bis 6 km / h können Sie mit dem Laufband die Geschwindigkeit per Fernbedienung an Ihre körperliche Verfassung und Ihre Trainingsbedürfnisse anpassen.
<G-vec00095-002-s158><adjust.anpassen><en> One only has to adjust his speed.
<G-vec00095-002-s158><adjust.anpassen><de> Man muss nur seine Geschwindigkeit anpassen.
<G-vec00095-002-s159><adjust.anpassen><en> For example, if you want to adjust the f-stop, the following notification appears: `Lens opening - adjust the amount of incoming light and background blur by increasing or decreasing this value`.
<G-vec00095-002-s159><adjust.anpassen><de> Wenn man beispielsweise die Blende anpassen möchte, erscheint die Meldung „Objektivöffnung: Passen Sie die einströmende Lichtmenge und die Hintergrundunschärfe an, indem Sie diesen Wert erhöhen oder verringern”.
<G-vec00095-002-s160><adjust.anpassen><en> Custom options allow you to set up your city the way you see fit, and it allows you to change your gaming experience as you adjust to new challenges.
<G-vec00095-002-s160><adjust.anpassen><de> Mit individuellen Optionen gestaltest du deine Stadt nach deinen Vorstellungen und du kannst deine Spielerfahrung an neue Herausforderungen anpassen.
<G-vec00095-002-s161><adjust.anpassen><en> You can also adjust the collage's lightness and saturation in the graphics editor.
<G-vec00095-002-s161><adjust.anpassen><de> Außerdem können Sie die Helligkeit und Sättigung anpassen.
<G-vec00095-002-s162><adjust.anpassen><en> Click Adjust to open the Adjust panel.
<G-vec00095-002-s162><adjust.anpassen><de> Klicken Sie auf „Anpassen“, um das Bedienfeld „Anpassen“ zu öffnen.
<G-vec00095-002-s164><adjust.anpassen><en> We have tried and tested products that allow you to adjust the processing properties of the concrete, targeted to your own needs.
<G-vec00095-002-s164><adjust.anpassen><de> Wir haben praxiserprobte Produkte, mit denen Sie die Verarbeitungseigenschaften des Betons gezielt Ihren eigenen Bedürfnissen anpassen können.
<G-vec00095-002-s165><adjust.anpassen><en> It would be desirable if the set contains another weaker spring to adjust the joystick to other aircraft types.
<G-vec00095-002-s165><adjust.anpassen><de> Wünschenswert wäre hier im Lieferumfang noch eine etwas schwächere Feder gewesen, um den Joystick an andere Flugzeugtypen anpassen zu können.
<G-vec00095-002-s166><adjust.anpassen><en> You can choose from a list of EQ presets that you can use on your audio and adjust the amount using the slider.
<G-vec00095-002-s166><adjust.anpassen><de> Sie können aus einer Liste mit EQ-Vorgaben auswählen, die Sie mit Ihrem Audio testen und anhand des Schiebereglers anpassen können.
<G-vec00095-002-s167><adjust.anpassen><en> A thickness of Vivaldi, the possibility of the Browser, so adjust as you need it as a user.
<G-vec00095-002-s167><adjust.anpassen><de> Eine Stärke von Vivaldi ist die Möglichkeit, den Browser ganz so anpassen zu können wie man es als Nutzer braucht.
<G-vec00095-002-s168><adjust.anpassen><en> Speed limit respect: With the HUD, your speed is displayed next to the speed limit right in front of you to let you adjust your driving at any moment.
<G-vec00095-002-s168><adjust.anpassen><de> Auf dem HUD wird Ihre Geschwindigkeit neben der Geschwindigkeitsbegrenzung direkt vor Ihnen angezeigt, damit Sie Ihre Fahrweise jederzeit anpassen können.
<G-vec00095-002-s169><adjust.anpassen><en> They are very convenient because they allow you to adjust your parking time. For example, if you return to your vehicle faster than expected, you can use one of the applications to only pay for the time you actually spent on the parking spot.
<G-vec00095-002-s169><adjust.anpassen><de> Sie sind besonders praktisch, da Sie Ihre Parkdauer anpassen können: wenn Sie früher zum Fahrzeug zurückkehren, können Sie über die App die Parkzeit verkürzen und zahlen dann weniger.
<G-vec00095-002-s170><adjust.anpassen><en> Depending on the system and your therapy needs, you may have a controller that allows you to turn the system on and off, adjust the stimulation, and check the battery.
<G-vec00095-002-s170><adjust.anpassen><de> In Abhängigkeit vom System und Ihrem Therapiebedarf, erhalten Sie ein Handgerät (unten abgebildet), mit dem Sie das System ein- und ausschalten, die Stimulation anpassen und den Batteriestatus prüfen können.
<G-vec00095-002-s171><adjust.anpassen><en> Depending on which style you choose, more tweaks will appear to add labels and adjust the button options.
<G-vec00095-002-s171><adjust.anpassen><de> Je nachdem welchen Style Sie wählen, werden weitere Anpassungen angezeigt, mit denen Sie Etiketten hinzufügen können und die Button Optionen anpassen können.
<G-vec00095-002-s172><adjust.anpassen><en> It is a wipe effect that allows you to adjust the angle of the transition.
<G-vec00095-002-s172><adjust.anpassen><de> Es handelt sich um einen Verwischeffekt, mit dem Sie den Winkel des Übergangs anpassen können.
<G-vec00095-002-s173><adjust.anpassen><en> Discover PhotoDirector's comprehensive tools and easy-to-use features that make it easier than ever to professionally edit and adjust photos.
<G-vec00095-002-s173><adjust.anpassen><de> Entdecken Sie die umfassenden Tools und benutzerfreundlichen Funktionen von PhotoDirector, mit denen Sie Fotos professionell bearbeiten und anpassen können.
<G-vec00095-002-s174><adjust.anpassen><en> When there are at least two or more fields in the dialog and if you select a field the “Move” buttons will become enabled and let you adjust the order of the fields.
<G-vec00095-002-s174><adjust.anpassen><de> Wenn mindestens zwei Felder im Dialogfeld enthalten sind und Sie ein Feld auswählen, werden die Schaltflächen zum Verschieben aktiviert, sodass Sie die Reihenfolge der Felder anpassen können.
<G-vec00095-002-s175><adjust.anpassen><en> Similar to the introduction of Ultra High Definition TV (UHDTV) and 4K, the new audio format MPEG-H audio was created to deliver impressive sound to TV audiences, further adding to their audio experience. As a core contributor, Fraunhofer IIS played a major role in the co-development of the new MPEG-H audio standard which will give TV viewers the ability to tailor the sound mix to their personal preferences, e.g. to switch between different languages and audio tracks or to adjust the audio balance of television presenters and dialogues.
<G-vec00095-002-s175><adjust.anpassen><de> Außerdem ist parallel zur Einführung von Ultra High Definition TV (UHDTV) und 4K ein neues Tonformat entstanden, das neben beeindruckenden Klangerlebnissen weiteren Mehrwert für das TV-Publikum bereithält: Basierend auf dem maßgeblich vom Fraunhofer IIS mitentwickelten MPEG-H Audio Standard sollen Zuschauer künftig zwischen verschiedenen Sprachen oder Tonspuren wechseln und Moderatoren oder Dialoge in der Lautstärke anpassen können.
<G-vec00095-002-s176><adjust.anpassen><en> There is also a default Windows fan settings mode, and a Manual mode for users to individually adjust the speed of the dedicated GPU and CPU fans.
<G-vec00095-002-s176><adjust.anpassen><de> Es gibt auch einen Standard-Windows-Lüftereinstellungsmodus und einen manuellen Modus, mit dem Benutzer die Geschwindigkeit der dedizierten GPU- und CPU-Lüfter individuell anpassen können.
<G-vec00095-002-s177><adjust.anpassen><en> They save your personal settings in order to adjust the website to your needs.
<G-vec00095-002-s177><adjust.anpassen><de> In diesen Cookies werden Informationen zu Ihren persönlichen Einstellungen hinterlegt, sodass wir unsere Webseite an Ihre Bedürfnisse anpassen können.
<G-vec00095-002-s178><adjust.anpassen><en> Last but not least, metal telescopic tube, which allows you to easily adjust the height.
<G-vec00095-002-s178><adjust.anpassen><de> Last but not least, Metall-Teleskoprohr, mit dem Sie die Höhe leicht anpassen können.
<G-vec00095-002-s179><adjust.anpassen><en> The road is simulated using different positions that you adjust yourself.
<G-vec00095-002-s179><adjust.anpassen><de> Die Simulation der Straße erfolgt mit verschiedenen Positionen, die Sie selbst anpassen können.
<G-vec00095-002-s180><adjust.anpassen><en> This compartment is equipped with sturdy internal dividers that allow you to adjust the layout to your liking.
<G-vec00095-002-s180><adjust.anpassen><de> Dieses Fach ist mit robusten internen Trennwänden ausgestattet, mit denen Sie das Layout nach Ihren Wünschen anpassen können.
<G-vec00095-002-s181><adjust.anpassen><en> The game is totally customizable, in such a way that you will have the possibility to adjust the difficulty.
<G-vec00095-002-s181><adjust.anpassen><de> Das Spiel ist völlig konfigurierbar, sodass Sie den Schwierigkeitsgrad anpassen können.
<G-vec00095-002-s182><adjust.anpassen><en> - Full and convenient adjustment of settings to the different body shape of the user, allowing you to adjust the training for everyone.
<G-vec00095-002-s182><adjust.anpassen><de> - Vollständige und bequeme Anpassung der Einstellungen an die unterschiedliche Körperform des Benutzers, sodass Sie das Training für alle anpassen können.
<G-vec00095-002-s183><adjust.anpassen><en> In addition, you can optimize Windows 8.1 with Avast Cleanup, which will adjust settings, clear junk data, and clean out your registry to get your Windows 8.1 PC running as good as new.
<G-vec00095-002-s183><adjust.anpassen><de> Zudem können Sie Windows 8.1 mit Avast Cleanup optimieren, dass Ihre Einstellungen anpasst, Datenmüll leert und die Registry aufräumt, damit Ihr Windows 8.1-PC wieder wie neu läuft.
<G-vec00095-002-s184><adjust.anpassen><en> The POS is forced to take action, and it only has chance in the future, if they do adjust their services to the needs of the customers, just as online retailers do.
<G-vec00095-002-s184><adjust.anpassen><de> Der POS steht unter Zugzwang – wer sich nicht den Bedürfnissen der Kunden anpasst, wie es jeder Online-Händler tut, hat in Zukunft keine Chance.
<G-vec00095-002-s185><adjust.anpassen><en> If you adjust the design, you will see immediately if content no longer fits into the area and can change this.
<G-vec00095-002-s185><adjust.anpassen><de> Wenn du das Design anpasst, dann siehst du sofort, falls Inhalte nicht mehr in den Bereich passen und kannst das ändern.
<G-vec00095-002-s186><adjust.anpassen><en> Enhanced power management features automatically and instantaneously adjust performance states and features based on processor performance requirements, helping users get more efficient performance by dynamically activating or turning off parts of the processor.
<G-vec00095-002-s186><adjust.anpassen><de> Erweitertes Energiemanagement, das auf Grundlage der an den Prozessor gestellten Leistungsanforderungen automatisch und unmittelbar Leistung und Funktionen anpasst.
<G-vec00095-002-s187><adjust.anpassen><en> If you prefer not to constantly have to switch back and forth between glasses and sunglasses as light conditions change, you might want to consider an indoor/outdoor solution with lenses that automatically adjust to changing light conditions: PhotoFusion.
<G-vec00095-002-s187><adjust.anpassen><de> Wer nicht ständig zwischen der normalen Alltagsbrille und der Sonnenbrille bei Lichtwechsel tauschen möchte, dem kann die Drinnen-/Draußen-Brille, die sich mit automatisch verfärbenden Brillengläsern den Lichtverhältnissen anpasst, weiterhelfen: PhotoFusion heißt das Zauberwort.
<G-vec00095-002-s188><adjust.anpassen><en> Solicite un presupuesto Email a and automatically adjust the stride length to replicate walking, jogging and running for greater comfort, variety and challenge.
<G-vec00095-002-s188><adjust.anpassen><de> Ahmt Gehen, Joggen oder Laufen nach und fügt mit Octanes charakteristischem SmartStride, der die Schrittlänge, basierend auf dem Tempo des Nutzers, automatisch zwischen 51 und 71 cm anpasst, neue Herausforderungen hinzu.
<G-vec00095-002-s189><adjust.anpassen><en> Far more useful would be flexible controls that take into account specific traffic and weather conditions and adjust the maximum speed depending on the situation.
<G-vec00095-002-s189><adjust.anpassen><de> Viel sinnvoller ist eine flexible Steuerung, die auf Verkehrslage und Wetter Rücksicht nimmt und die Höchstgeschwindigkeit situationsabhängig anpasst.
<G-vec00095-002-s190><adjust.anpassen><en> Shared use is likely to be successful provided that enough space is available, that implied priority for any means of transport is removed, and that the overall impression is clearly transmitted to cyclists that they are 'guests' on pedestrian spaces and thus have to adjust their cycling speed.
<G-vec00095-002-s190><adjust.anpassen><de> Das Miteinander funktioniert dann gut, wenn genügend Platz vorhanden ist, bei gemischten Flächen kein Verkehrsmittel einen Vorrang suggeriert bekommt, der Gesamteindruck eindeutig ist in dem Sinne, dass der Radverkehr bei den Fußgängern "zu Gast" ist und sich entsprechend in der Fahrgeschwindigkeit anpasst.
<G-vec00095-002-s191><adjust.anpassen><en> iQ flow control, the third assistance system presented at the Plastimagen, will connect the injection moulding machine, which is equipped with an e-flomo electronic temperature control water distributor, to the temperature control unit, enabling the pump speed to automatically adjust to the actual requirement.
<G-vec00095-002-s191><adjust.anpassen><de> iQ flow control, das dritte auf der Plastimagen präsentierte Assistenzsystem, vernetzt die mit einem elektronischen Temperierwasserverteiler vom Typ e flomo ausgestattete Spritzgießmaschine mit dem Temperiergerät, so dass sich die Drehzahl der Pumpe automatisch an den tatsächlichen Bedarf anpasst.
<G-vec00095-002-s192><adjust.anpassen><en> Voicing and final tuning When the technical assembly is completed and everything is working properly the voicer comes in once again to adjust the sound of each pipe to the rest of the pipes and ranks and to the acoustics of the place of destination.
<G-vec00095-002-s192><adjust.anpassen><de> Wenn der technische Aufbau abgeschlossen ist und alles richtig funktioniert, ist wieder der Intonateur gefordert, der – wie schon bei der Vorintonation in der Werkstatt – den Klang jeder Pfeife im Zusammenhang mit den anderen Pfeifen und Registern sowie der Raumakustik anpasst.
<G-vec00095-002-s193><adjust.anpassen><en> However, the AI drivers are able to adjust very rapidly to the player's skill level: Even on the lower difficulty settings, you are only able to win two up to three consecutive races. By then, your competitors have adapted insofar as your next podium finish will require hard work.
<G-vec00095-002-s193><adjust.anpassen><de> Erschwert wird der Rennfahreralltag allerdings dadurch, dass sich die KI sehr schnell an das Können des Spielers anpasst: Selbst auf niedrigeren Schwierigkeitsstufen kann man nur zwei bis drei Rennen in Folge problemlos gewinnen, bis sich die Konkurrenz insoweit angepasst hat, dass die nächste Podiumsplatzierung ein hartes Stück Arbeit wird.
<G-vec00095-002-s194><adjust.anpassen><en> It is therefore important for the laser to automatically adjust itself ‘on the fly’ to balance out any variation in film thickness.
<G-vec00095-002-s194><adjust.anpassen><de> Es ist deshalb sehr wichtig, dass sich der Laser automatisch “on the fly” anpasst und ein Gleichgewicht bei jeder Lagenstärke findet.
<G-vec00095-002-s195><adjust.anpassen><en> We want it to change with us and adjust to our taste, which of course doesn't stay the same: it changes depending on our age, surroundings, the situation of our life.
<G-vec00095-002-s195><adjust.anpassen><de> Wir möchten, dass er sich gemeinsam mit uns verändert und sich an unseren Stil anpasst, der schließlich nicht statisch ist: unser Stil variiert je nach Alter, Umgebung und den Situationen, mit denen uns das Leben konfrontiert.
<G-vec00095-002-s196><adjust.anpassen><en> The advantage of taking a German company is that they know the rules and regulations of the German system very well and adjust the benefits to these conditions. You also normally receive the document to show at university or when passing the boarder right away.
<G-vec00095-002-s196><adjust.anpassen><de> Der Vorteil eines deutschen Anbieters liegt darin, dass er die Begebenheiten und Regelungen vor Ort kennt und die Leistungen darauf anpasst, außerdem erhält man meist gleich die Bestätigung, die bei der Universität oder bei der Einreise vorgelegt werden muss.
<G-vec00095-002-s197><adjust.anpassen><en> The strap-on harness itself, which usually has a padded front section and a series of adjustable straps that you step into and then adjust at the waist and/or the legs.
<G-vec00095-002-s197><adjust.anpassen><de> Dem Umschnallgurt selbst, der normalerweise aus einem gepolsterten Vorderteil und einer Reihe von gepolsterten Gurten besteht, in die man hineinsteigt und anschließend an der Taille und/oder den Beinen anpasst.
<G-vec00095-002-s198><adjust.anpassen><en> Headset or head microphones: The microphone includes a headband to adjust onto the guide’s head.
<G-vec00095-002-s198><adjust.anpassen><de> Headset-Mikrofon: Das Mikrofon enthält einen Kopfbügel, der dem Kopf anpasst wird.
<G-vec00095-002-s199><adjust.anpassen><en> Retouch the picture to make it brighter or adjust the colors, decide the format and size, and click on the Print button.
<G-vec00095-002-s199><adjust.anpassen><de> Retuschiere Bilder, indem du sie aufhellst oder die Farben anpasst, entscheide dich für ein Format und eine Größe und drücke auf Drucken.
<G-vec00095-002-s200><adjust.anpassen><en> In case you do not position the bubble on the same spot every time, the most convenient option is to set the flash to auto-exposure (TTL) and use flash exposure compensation to adjust its brightness as needed.
<G-vec00095-002-s200><adjust.anpassen><de> Sofern Ihr die Seifenblase nicht immer im selben Abstand zum Blitz positioniert, macht Ihr es Euch am einfachsten, wenn Ihr den Blitz auf Automatik (TTL) stellt und die Helligkeit nötigenfalls mit der Blitzbelichtungskorrektur anpasst.
<G-vec00095-002-s201><adjust.anpassen><en> In this tutorial you will be shown how to create and adjust these reports.
<G-vec00095-002-s201><adjust.anpassen><de> In diesem Tutorial wird Dir gezeigt wie Du Reporte erstellst und anpasst.
<G-vec00095-002-s221><adjust.anpassen><en> They ordered Tebis consultants to adjust internal procedures and to better utilize existing potential.
<G-vec00095-002-s221><adjust.anpassen><de> Sie beauftragte Tebis Berater, um Interne Abläufe anzupassen und vorhandene Potenziale besser zu nutzen.
<G-vec00095-002-s222><adjust.anpassen><en> With this update, our main focus was to change cards with the Create ability, as well as to adjust the Swap mechanic. See more
<G-vec00095-002-s222><adjust.anpassen><de> Bei diesem Update lag unser Hauptaugenmerk darauf, die Karten mit der Fähigkeit "Erschaffen" zu ändern, sowie die Austausch-Mechanik anzupassen.
<G-vec00095-002-s223><adjust.anpassen><en> Flex-Connect allows you to transform your camera set from compact to full-featured in just seconds, providing a quick way to adjust to any dive environment.
<G-vec00095-002-s223><adjust.anpassen><de> Flex-Connect können Sie Ihr Sealife Kamera-Set von der kompakten Version transformieren, um mit vollem Funktionsumfang in nur wenigen Sekunden, eine schnelle Möglichkeit zu haben, um die Sealife Unterwasserkamera bei jedem Tauchgang dem Umfeld anzupassen.
<G-vec00095-002-s224><adjust.anpassen><en> As an experienced and very well networked real estate investor, it is therefore very important for us to be close to the market in order to actively seize opportunities for our investors and, where necessary, adjust portfolio strategies in close coordination with fund management.
<G-vec00095-002-s224><adjust.anpassen><de> Als erfahrener und sehr gut vernetzter Immobilieninvestor ist es uns deshalb sehr wichtig eng am Markt zu sein, um Chancen für unsere Anleger aktiv wahrzunehmen und dort, wo es notwendig ist, in enger Abstimmung mit dem Fondsmanagement Portfoliostrategien anzupassen.
<G-vec00095-002-s225><adjust.anpassen><en> There are many ways to adjust the light settings to your own taste.
<G-vec00095-002-s225><adjust.anpassen><de> Dabei gibt es viele Möglichkeiten die Licht-Einstellungen auf den eigenen Geschmack anzupassen.
<G-vec00095-002-s226><adjust.anpassen><en> Smartphone cameras restrict the ability to adjust aperture, shutter speed and other settings, as you might do on a conventional camera.
<G-vec00095-002-s226><adjust.anpassen><de> Im Vergleich zu herkömmlichen Kameras haben wir bei den Kameras unserer Smartphones nur begrenzt die Möglichkeit, Blende, Belichtungszeit und anderen Einstellungen anzupassen.
<G-vec00095-002-s227><adjust.anpassen><en> To see quick results it is necessary to adjust and change some forms of behavior.
<G-vec00095-002-s227><adjust.anpassen><de> Um schnell gut zu werden ist es notwendig, manche Verhaltensformen anzupassen oder zu verändern.
<G-vec00095-002-s228><adjust.anpassen><en> To adjust the intensity, simply tap the selected filter again.
<G-vec00095-002-s228><adjust.anpassen><de> Um die Intensität anzupassen, genügt ein erneuter Fingertipp auf den ausgewählten Filter.
<G-vec00095-002-s229><adjust.anpassen><en> Influenced with this new knowledge she organized different programs that would encourage women to do weaving, by processing of wool and knitting, in a way to adjust this products to the necessities of a market.
<G-vec00095-002-s229><adjust.anpassen><de> Von diesem neuen Wissen getrieben, organisierte sie verschiedene Programme über Weben, Wollverarbeitung und Stricken, mit dem Ziel, handwerkliche Produkte dem Markt anzupassen.
<G-vec00095-002-s230><adjust.anpassen><en> Click Content settings in the "Privacy" section to adjust your permissions for cookies, images, JavaScript, plug-ins, pop-ups and location sharing.
<G-vec00095-002-s230><adjust.anpassen><de> Klicken Sie im Bereich "Datenschutz" auf Inhaltseinstellungen, um Ihre Berechtigungen für Cookies, Bilder, JavaScript, Plug-ins, Pop-ups sowie für die Standortfreigabe anzupassen.
<G-vec00095-002-s231><adjust.anpassen><en> The term "an instruction to adaptation" means a statement that a computing instruction, an algorithm, a factor or in the broadest sense information which can be used by the signal processing device of the hearing aid to adjust the amplification characteristics of the hearing aid to the needs of the wearer.
<G-vec00095-002-s231><adjust.anpassen><de> Der Begriff „eine Anweisung zur Anpassung” bedeutet eine Anweisung, eine Rechenanweisung, einen Algorithmus, einen Faktor oder im weitesten Sinne eine Information, welche von der Signalverarbeitungseinrichtung des Hörgeräts genutzt werden kann, um die Verstärkungseigenschaften des Hörgeräts an die Bedürfnisse des Trägers anzupassen.
<G-vec00095-002-s232><adjust.anpassen><en> Grip width adjustment If you can control your ride with just one finger, it’s extremely important to adjust the brake grips exactly to the unique shape of your hands.
<G-vec00095-002-s232><adjust.anpassen><de> Griffweiteneinstellung: Wenn du mit nur einem Finger deine Fahrt kontrollieren kannst, ist es äußerst wichtig, die Bremsgriffe exakt an die einzigartige Form deiner Hände anzupassen.
<G-vec00095-002-s233><adjust.anpassen><en> The person is unable to adjust his sleep/wake cycle to the length of the day, and his sleep time progresses around the clock.
<G-vec00095-002-s233><adjust.anpassen><de> Die Person ist nicht in der Lage ihren Schlaf-Wach-Rhythmus an die Länge eines Tages anzupassen und ihre Schlafzeiten wandern stetig um die Uhr.
<G-vec00095-002-s234><adjust.anpassen><en> Once inside the room, guests can use the in-room tablet or the Hospitality TV with LYNC HMS solution to easily adjust the lighting and draw the blinds, all without having to move.
<G-vec00095-002-s234><adjust.anpassen><de> Sobald sie sich im Zimmer befinden, können Ihre Gäste das dort verfügbare Tablet oder das Hotel TV mit LYNC HMS-Lösung nutzen, um die Beleuchtung und die Jalousien bequem anzupassen, ohne dass sie sich dazu bewegen müssen.
<G-vec00095-002-s235><adjust.anpassen><en> Application statuses To adjust in-product statuses in the first pane of ESET Endpoint Antivirus navigate to User interface > User interface elements > Application statuses of the ESET Endpoint Antivirus Advanced setup tree.
<G-vec00095-002-s235><adjust.anpassen><de> Um den produktinternen Status im ersten Bereich von ESET Endpoint Security anzupassen, navigieren Sie zu Benutzeroberfläche > Elemente der Benutzeroberfläche > Anzuzeigende Hinweise in den erweiterten Einstellungen von ESET Endpoint Security.
<G-vec00095-002-s236><adjust.anpassen><en> For those who want to lose weight, or a littleYou can also use this kind of massage to adjust the figure.
<G-vec00095-002-s236><adjust.anpassen><de> Für diejenigen, die abnehmen wollen, oder ein wenigSie können diese Art der Massage auch verwenden, um die Figur anzupassen.
<G-vec00095-002-s237><adjust.anpassen><en> h) Should cost reductions or cost increases arise after the contract has been concluded, WRW is entitled to adjust the agreed upon price.
<G-vec00095-002-s237><adjust.anpassen><de> h) Sollten sich nach Vertragsschluss Kostensenkungen oder Kostenerhöhungen ergeben, ist WRW berechtigt, die vereinbarten Preise anzupassen.
<G-vec00095-002-s238><adjust.anpassen><en> But it’s important to wear the hearing aids as much as possible, to give the brain time to adjust.
<G-vec00095-002-s238><adjust.anpassen><de> Es ist’ jedoch wichtig, die Hörgeräte so häufig und lange wie möglich zu tragen, um dem Gehirn Zeit zu geben, sich anzupassen.
<G-vec00095-002-s239><adjust.anpassen><en> PROTIQ is entitled to adjust the agreed monthly dealer fee on each extension of the term of the dealer account.
<G-vec00095-002-s239><adjust.anpassen><de> PROTIQ ist berechtigt, die vereinbarte monatliche Anbietergebühr bei jeder Laufzeitverlängerung des Anbieterkontos anzupassen.
<G-vec00095-002-s259><adjust.anpassen><en> Airlines can adjust prices for tickets from San Francisco to Hong Kong based on the day and time that you decide to book your flight.
<G-vec00095-002-s259><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von San Francisco nach Hong Kong basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s260><adjust.anpassen><en> Such higher coverage level should be limited in time and in scope and the Member States concerned should adjust the target level and contributions paid to their DGSs proportionately.
<G-vec00095-002-s260><adjust.anpassen><de> Eine solche höhere Deckungssumme sollte in Geltungsdauer und -umfang begrenzt sein, und die betreffenden Mitgliedstaaten sollten die Zielausstattung und die in ihre Einlagensicherungssysteme eingezahlten Beiträge proportional anpassen.
<G-vec00095-002-s261><adjust.anpassen><en> Airlines can adjust prices for tickets from Seoul to Hong Kong based on the day and time that you decide to book your flight.
<G-vec00095-002-s261><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Seoul nach Hong Kong basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s262><adjust.anpassen><en> Using this feature you can adjust the posture differences between G2, G3 and G5 characters, and prevent issues such as body leans forward or backward or limb penetration into the body when you apply motions to a character with unique body proportions.
<G-vec00095-002-s262><adjust.anpassen><de> Wenn Sie diese Funktion verwenden, können Sie die Unterschiede der Körperhaltung zwischen G2, G3 und G5 Charakteren anpassen und Fehler beim Einsetzen von Bewegungen für einen Charakter, wie das Vor- oder Zurücklehnen des Körpers oder Körpergliedmaßen, die den Körper durchdringen, zu vermeiden.
<G-vec00095-002-s263><adjust.anpassen><en> You may adjust the amount of interest-based advertising you may receive from us by changing your cookie settings and/or opting out of advertising networks.
<G-vec00095-002-s263><adjust.anpassen><de> Sie können die Menge an interessenbezogener Werbung, die Sie von uns erhalten, anpassen, indem Sie Ihre Cookie-Einstellungen ändern und / oder aus Werbenetzwerken aussteigen.
<G-vec00095-002-s264><adjust.anpassen><en> Airlines can adjust prices for tickets from Delhi to Hong Kong based on the day and time that you decide to book your flight.
<G-vec00095-002-s264><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Delhi nach Hong Kong basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s265><adjust.anpassen><en> While guests can adjust temperature settings in their rooms, anticipating opportunities to more intelligently control energy distribution helps hotels reduce energy costs, promote energy system performance and drive operational efficiency.
<G-vec00095-002-s265><adjust.anpassen><de> Die Gäste können die Temperatureinstellungen in ihren Zimmern nach wie vor anpassen, doch sorgt die intelligente Steuerung der Energieversorgung dafür, dass Hotels Energiekosten senken, die Leistung des Energiesystems steigern und die betriebliche Effizienz fördern können.
<G-vec00095-002-s266><adjust.anpassen><en> Airlines can adjust prices for tickets from Atlanta to Washington, District of Columbia based on the day and time that you decide to book your flight.
<G-vec00095-002-s266><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Atlanta nach Washington, District of Columbia basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s267><adjust.anpassen><en> Airlines can adjust prices for tickets from Delhi to Dallas based on the day and time that you decide to book your flight.
<G-vec00095-002-s267><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Delhi nach Dallas basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s268><adjust.anpassen><en> Airlines can adjust prices for tickets from Toronto to Bangkok based on the day and time that you decide to book your flight.
<G-vec00095-002-s268><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Toronto nach Bangkok basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s269><adjust.anpassen><en> Airlines can adjust prices for tickets from Detroit to New York City based on the day and time that you decide to book your flight.
<G-vec00095-002-s269><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Detroit nach New York City basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s270><adjust.anpassen><en> Airlines can adjust prices for tickets from Miami, Florida to Toronto based on the day and time that you decide to book your flight.
<G-vec00095-002-s270><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Miami, Florida nach Toronto basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s271><adjust.anpassen><en> Airlines can adjust prices for tickets from Paris, France to Miami, Florida based on the day and time that you decide to book your flight.
<G-vec00095-002-s271><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Paris, France nach Miami, Florida basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s272><adjust.anpassen><en> Airlines can adjust prices for tickets from New York City to Guayaquil based on the day and time that you decide to book your flight.
<G-vec00095-002-s272><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von New York City nach Guayaquil basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s273><adjust.anpassen><en> Airlines can adjust prices for tickets from New York City to Montreal based on the day and time that you decide to book your flight.
<G-vec00095-002-s273><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von New York City nach Montreal basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s274><adjust.anpassen><en> Airlines can adjust prices for tickets from Los Angeles, California to Seoul based on the day and time that you decide to book your flight.
<G-vec00095-002-s274><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Los Angeles, California nach Seoul basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s275><adjust.anpassen><en> This period allows the balance to adjust to ambient temperature and stabilise to its environment.
<G-vec00095-002-s275><adjust.anpassen><de> Während dieser Zeit kann sich die Waage an die Umgebungstemperatur und -bedingungen anpassen.
<G-vec00095-002-s276><adjust.anpassen><en> Airlines can adjust prices for tickets from Rome, Italy to Chicago based on the day and time that you decide to book your flight.
<G-vec00095-002-s276><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Rome, Italy nach Chicago basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s277><adjust.anpassen><en> You could adjust music volume or change songs or charging earbuds by touching easily.
<G-vec00095-002-s277><adjust.anpassen><de> Sie können die Musiklautstärke anpassen oder Lieder ändern oder Kopfhörer laden, indem Sie sie leicht berühren.
<G-vec00095-002-s297><adjust.anpassen><en> Dignita reserves the right to adjust prices at any time.
<G-vec00095-002-s297><adjust.anpassen><de> Dignita behält sich das Recht vor, die Preise jederzeit anzupassen.
<G-vec00095-002-s298><adjust.anpassen><en> Possibility to adjust the dimensions and strength parameters of the pallet to the specificity of the load.
<G-vec00095-002-s298><adjust.anpassen><de> Die Möglichkeit, die Größe und Widerstandsfähigkeit der Palette an die Spezifität der Ladung anzupassen.
<G-vec00095-002-s299><adjust.anpassen><en> Your iMac uses the ambient light sensor to adjust the display's brightness based on your environment.
<G-vec00095-002-s299><adjust.anpassen><de> Der iMac nutzt den Umgebungslichtsensor, um die Bildschirmhelligkeit des Displays an Ihre Umgebung anzupassen.
<G-vec00095-002-s300><adjust.anpassen><en> Swipe up or down the screen to adjust brightness or change the speed of the different modes.
<G-vec00095-002-s300><adjust.anpassen><de> Ziehen Sie Ihren Finger über den Bildschirm, um die Helligkeit oder die Geschwindigkeit von den verschiedenen Modi anzupassen.
<G-vec00095-002-s301><adjust.anpassen><en> In 2005, Toon Thellier was asked to alter and revise the sound and light show attended by thousands of visitors every evening and to adjust technology to the demanding requirements of a modern show control system.
<G-vec00095-002-s301><adjust.anpassen><de> 2005 bekam Toon Thellier den Auftrag die all abendliche für tausende von Besuchern inszenierte Sound und Lichtshow neu zu überarbeiten und die Technik den modernen Anforderungen eines Show Control Systems anzupassen.
<G-vec00095-002-s302><adjust.anpassen><en> Drag the Density slider to adjust mask opacity, or the Feathering slider to feather mask edges.
<G-vec00095-002-s302><adjust.anpassen><de> Ziehen Sie den Regler „Dichte“, um die Deckkraft der Maske anzupassen, oder den Regler „Weiche Kante“, um Maskenkanten weichzuzeichnen.
<G-vec00095-002-s303><adjust.anpassen><en> To adjust the indicator light brightness, or to dismiss a notification, press the multifunction key.
<G-vec00095-002-s303><adjust.anpassen><de> Um die Helligkeit der Statusanzeige anzupassen oder eine Benachrichtigung zu verwerfen, drücken Sie die Multifunktionstaste.
<G-vec00095-002-s304><adjust.anpassen><en> SEMIKRON expressly reserves the right to adjust prices for 2019 deliveries.
<G-vec00095-002-s304><adjust.anpassen><de> SEMIKRON behält sich ausdrücklich das Recht vor, die Preise für 2019 Lieferungen anzupassen.
<G-vec00095-002-s305><adjust.anpassen><en> For contract terms longer than one year, info-key reserves the right to adjust the annual license fee after one year of fixed pricing.
<G-vec00095-002-s305><adjust.anpassen><de> Bei Vertragslaufzeiten von länger als einem Jahr behält info-key sich das Recht vor, die Höhe der jährlichen Gebühr nach einer Preisbindung von einem Jahr anzupassen.
<G-vec00095-002-s306><adjust.anpassen><en> Consel Group AG reserves the right to adjust prices at any time without prior notice.
<G-vec00095-002-s306><adjust.anpassen><de> Consel Group AG behält sich das Recht vor, die Preise jederzeit ohne Vorankündigung anzupassen.
<G-vec00095-002-s307><adjust.anpassen><en> Just tap on the screen to adjust exposure.
<G-vec00095-002-s307><adjust.anpassen><de> Tippen Sie einfach auf das Display, um die Belichtung anzupassen.
<G-vec00095-002-s308><adjust.anpassen><en> Navigate the timeline of your audio files easily using the project cursor, and add fade points at precise locations to adjust volume or to pan the audio.
<G-vec00095-002-s308><adjust.anpassen><de> Navigiere in der Zeitachse von Audiodateien einfach mittels dem Projektcursor und füge Ein- / Ausblendpunkte an genauen Stellen hinzu, um die Lautstärke oder den Schwenk dem Audio anzupassen.
<G-vec00095-002-s309><adjust.anpassen><en> We reserve the right to adjust pricing for our Paid Services or any components thereof in any manner and at any time.
<G-vec00095-002-s309><adjust.anpassen><de> Wir behalten uns das Recht vor, die Preise für unsere Kostenpflichtigen Services oder Bestandteile derselben jederzeit und in jeder Hinsicht anzupassen.
<G-vec00095-002-s310><adjust.anpassen><en> Of course, the CRC Performance HC MK3 PRO Haldex controller has got a racetrack mode enabling it to take an influence on vehicle dynamics and to adjust power distribution to the relevant speedway optimally.
<G-vec00095-002-s310><adjust.anpassen><de> Selbstverständlich verfügt die HC MK3 PRO Haldexsteuerung über ein Rundstreckenprogramm, das es ermöglicht, die Fahrdynamik des Fahrzeugs zu beeinflussen und um die Leistungsverteilung optimal auf die jeweilige Rennstrecke anzupassen.
<G-vec00095-002-s311><adjust.anpassen><en> It was difficult to adjust the new boards available on the market to those already installed and to the existing structure.
<G-vec00095-002-s311><adjust.anpassen><de> Es war schwierig, die auf dem Markt verfügbaren neuen Platinen an die bereits installierten und an die bestehende Struktur anzupassen.
<G-vec00095-002-s312><adjust.anpassen><en> Vade’s SOC uses the feedback to mitigate the threat, adjust heuristic rules, and train our machine learning and computer vision algorithms.
<G-vec00095-002-s312><adjust.anpassen><de> Das Vade-SOC nutzt das Feedback, um die Bedrohung zu beseitigen, die heuristischen Regeln anzupassen und unsere Algorithmen für Machine Learning und Computer Vision zu trainieren.
<G-vec00095-002-s313><adjust.anpassen><en> Double-click a field to adjust field properties.
<G-vec00095-002-s313><adjust.anpassen><de> Doppelklicken Sie auf ein Feld, um die Feldeigenschaften anzupassen.
<G-vec00095-002-s314><adjust.anpassen><en> Individual finishes and a modern design allows you to adjust the prefabrication to your personal needs and requirements.
<G-vec00095-002-s314><adjust.anpassen><de> Die individuelle Ausführung und das moderne Design erlauben, die Garage an Ihre Bedürfnisse und Anforderungen anzupassen.
<G-vec00095-002-s315><adjust.anpassen><en> This makes it possible to localize tumors and healthy tissue very precisely over the whole treatment period in order to adjust radiation therapy individually if the tumor has shifted since the last treatment or if its size has changed.
<G-vec00095-002-s315><adjust.anpassen><de> Dadurch können Tumoren und gesunde Gewebe über den Behandlungszeitraum hinweg sehr genau lokalisiert werden, um die Strahlentherapie individuell anzupassen, falls sich der Tumor im Vergleich zur letzten Behandlung verschoben oder in seiner Größe verändert hat.
<G-vec00095-002-s439><adjust.anpassen><en> Thanks to the tool-free focus option, the user can manually adjust the correct working distance.
<G-vec00095-002-s439><adjust.anpassen><de> Dank der werkzeugfreien Fokusoption kann der Benutzer den richtigen Arbeitsabstand entsprechend der Anwendung leicht manuell anpassen.
<G-vec00095-002-s440><adjust.anpassen><en> The Booking System for Amusement Parks and Zoos can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s440><adjust.anpassen><de> Analysen Das Buchungssystem für Werksführungen kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s441><adjust.anpassen><en> The speed of the fan is controlled in 3 stages so you can easily adjust the capacity of the cooker hood to the intensity of cooking fumes.
<G-vec00095-002-s441><adjust.anpassen><de> Dadurch kann er die Luftleistung an die Intensität der Kochdünste entsprechend anpassen.
<G-vec00095-002-s442><adjust.anpassen><en> The Booking System for Bus Tours can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s442><adjust.anpassen><de> Das Buchungssystem für Virtual Reality Arenen kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s443><adjust.anpassen><en> Colour:Graphite White Choosing this will cause the need to adjust other options.
<G-vec00095-002-s443><adjust.anpassen><de> Wenn diese Position ausgewählt wird, wird man andere Optionen entsprechend anpassen müssen.
<G-vec00095-002-s445><adjust.anpassen><en> Where your local rules require more from us than that, we will adjust our practice to make sure your data is safe with us no matter where in the world you are!
<G-vec00095-002-s445><adjust.anpassen><de> Wenn bei Ihnen strengere Vorschriften gelten, werden wir unsere Praxis entsprechend anpassen, um sicherzustellen, dass Ihre Daten bei uns sicher sind, egal wo auf der Welt Sie sich befinden.
<G-vec00095-002-s447><adjust.anpassen><en> The Booking System for Bubble Soccer can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s447><adjust.anpassen><de> Das Buchungssystem für Bubble Soccer kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s448><adjust.anpassen><en> If you do not want to receive e-mail or other mail from us, please use our User Administration pages to adjust your preferences.
<G-vec00095-002-s448><adjust.anpassen><de> Sie können Ihre E-Mail-Einstellungen entsprechend anpassen, wenn Sie keine E-Mails oder andere Post von uns erhalten wollen.
<G-vec00095-002-s450><adjust.anpassen><en> The Booking System for Events can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s450><adjust.anpassen><de> Das Buchungssystem für geführte Touren kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s451><adjust.anpassen><en> The Booking System for Trampoline Halls can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s451><adjust.anpassen><de> Das Buchungssystem für Wassersport kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s452><adjust.anpassen><en> MTU is observing the potential impact of the coronavirus issue and will, if necessary, adjust its forecast in the course of the year.
<G-vec00095-002-s452><adjust.anpassen><de> Die MTU beobachtet mögliche Auswirkungen der Coronavirus-Problematik und wird ihre Prognose im Jahresverlauf gegebenenfalls entsprechend anpassen.
<G-vec00095-002-s453><adjust.anpassen><en> In addition, SMARTCRM 19.1 scores with new functionalities: users can personalize their own start screen, the SMART Board, using the variable number of columns and adjust it to their proper needs.
<G-vec00095-002-s453><adjust.anpassen><de> Darüber hinaus überzeugt SMARTCRM 19.1 mit neuer Funktionalität: So können User Ihren persönlichen Startbildschirm, das SMART Board, dank der variablen Spaltenanzahl noch individueller gestalten und den eigenen Bedürfnissen entsprechend anpassen.
<G-vec00095-002-s454><adjust.anpassen><en> If you do not want to receive e-mail or other mail from us, please adjust your Customer Communication Preferences.
<G-vec00095-002-s454><adjust.anpassen><de> • Sie können Ihr Benutzerkonto entsprechend anpassen, wenn Sie keine E-Mails oder andere Post von uns erhalten wollen.
<G-vec00095-002-s456><adjust.anpassen><en> Lampa Choosing this will cause the need to adjust other options.
<G-vec00095-002-s456><adjust.anpassen><de> Lampa Wenn diese Position ausgewählt wird, wird man andere Optionen entsprechend anpassen müssen.
<G-vec00095-002-s457><adjust.anpassen><en> In these cases Ciuvo will also adjust the details of the terms and privacy policy.
<G-vec00095-002-s457><adjust.anpassen><de> In diesen Fällen wird Ciuvo auch die Hinweise zum Datenschutz entsprechend anpassen.
<G-vec00095-002-s533><adjust.anpassen><en> Adjust the magic-wand settings.
<G-vec00095-002-s533><adjust.anpassen><de> Passe die Zauberstab-Einstellungen an.
<G-vec00095-002-s534><adjust.anpassen><en> For the taste test, I choose to adjust my equipment to obtain a lukewarm vape and a correct vapor.
<G-vec00095-002-s534><adjust.anpassen><de> Für den Geschmackstest passe ich meine Ausrüstung an, um einen lauwarmen Dampf und einen korrekten Dampf zu erhalten.
<G-vec00095-002-s535><adjust.anpassen><en> Adjust your difficulty settings or give yourself more lives to battle through each game in its entirety.
<G-vec00095-002-s535><adjust.anpassen><de> Passe den Schwierigkeitsgrad an oder verleihe dir selbst mehr Leben, um jedes Spiel komplett durchspielen zu können.
<G-vec00095-002-s536><adjust.anpassen><en> Adjust the frequency to find the resonance peak.
<G-vec00095-002-s536><adjust.anpassen><de> Passe die Frequenz an, um die Resonanzspitze herauszufinden.
<G-vec00095-002-s537><adjust.anpassen><en> Give a title and description to your vlog, adjust to your preferred quality, and select category and privacy then hit on "Export" button.
<G-vec00095-002-s537><adjust.anpassen><de> Gib deinem Vlog einen Titel und eine Beschreibung, passe ihn an deine bevorzugte Qualität an, wähle Kategorie und Datenschutz und klicke dann auf die Schaltfläche „Export“.
<G-vec00095-002-s538><adjust.anpassen><en> Remember what your mobile looked like before you started experimenting with it and adjust the width and length in the tiles to resize it.
<G-vec00095-002-s538><adjust.anpassen><de> Erinnere dich daran, wie dein Mobile aussah, bevor du angefangen hast, damit zu experimentieren und passe die Breite und Länge in den Kacheln an, um die Größe anzupassen.
<G-vec00095-002-s539><adjust.anpassen><en> Please adjust the daily feed amount accordingly and please always provide fresh drinking water.
<G-vec00095-002-s539><adjust.anpassen><de> Bitte passe die tägliche Futtermenge dementsprechend an und stelle bitte immer frisches Trinkwasser zur Verfügung.
<G-vec00095-002-s540><adjust.anpassen><en> Try on the necklace and adjust it as needed.
<G-vec00095-002-s540><adjust.anpassen><de> Probiere die Kette und passe sie nach Bedarf an.
<G-vec00095-002-s541><adjust.anpassen><en> Your curls will start where the headband sits, so adjust it based on how you want your curls to look.
<G-vec00095-002-s541><adjust.anpassen><de> Deine Locken beginnen dort, wo das Stirnband sitzt, also passe es an, je nachdem, wie deine Locken aussehen sollen.
<G-vec00095-002-s542><adjust.anpassen><en> Adjust your hair color to bring out your complexion.
<G-vec00095-002-s542><adjust.anpassen><de> Passe deine Haarfarbe an, um deinen Teint hervorzubringen.
<G-vec00095-002-s543><adjust.anpassen><en> Quick fix: adjust your bra straps and loosen them.
<G-vec00095-002-s543><adjust.anpassen><de> Schnelle Lösung: passe Deine BH-Träger an und lockere sie.
<G-vec00095-002-s544><adjust.anpassen><en> Choose your tablet model and case type, upload a photo and adjust it, then check-out.
<G-vec00095-002-s544><adjust.anpassen><de> Wähle dein Tablet-Modell und den Handyhüllentyp, lade anschließend ein Bild hoch und passe es an.
<G-vec00095-002-s545><adjust.anpassen><en> If you don’t want us to recognize your computer, please adjust your browser settings to delete or block all cookies or to warn you before saving a cookie.
<G-vec00095-002-s545><adjust.anpassen><de> Wenn Du nicht möchtest, dass wir deinen Computer wiedererkennen, dann passe bitte deine Browsereinstellung an um automatisch alle Cookies zu blockieren oder löschen oder Dich zu warnen bevor dein Browser einen Cookie speichert.
<G-vec00095-002-s546><adjust.anpassen><en> Adjust the display to display up to 8 data fields on each page.
<G-vec00095-002-s546><adjust.anpassen><de> Passe das Display an, um auf jeder Seite bis zu 8 Datenfelder anzuzeigen.
<G-vec00095-002-s547><adjust.anpassen><en> If some branches seem dimmer or brighter than others, adjust the lights as necessary, bringing them out to pop or nestling them in to be a bit dimmer.
<G-vec00095-002-s547><adjust.anpassen><de> Wenn einige Zweige dunkler oder heller als andere erscheinen, passe die Lichter an, hole sie mehr heraus oder verstecke sie etwas im Grün, um zu dimmen.
<G-vec00095-002-s548><adjust.anpassen><en> Use the "Corners" slider to adjust how rounded your corners will be.
<G-vec00095-002-s548><adjust.anpassen><de> {Passe mit dem Schieberegler "Ecken" an, wie abgerundet die Ecken sein werden.
<G-vec00095-002-s549><adjust.anpassen><en> Adjust each design element’s opacity by clicking on the down arrow and adjusting the transparency slider.
<G-vec00095-002-s549><adjust.anpassen><de> Passe die Deckstärke der einzelnen Elemente an, indem du auf den Pfeil nach unten klickst und den Schieberegler für die Transparenz einstellst.
<G-vec00095-002-s550><adjust.anpassen><en> If you do not want to be awakened at night, deactivate the automatic daylight saving time changeover on the mobile phone in the evening before the time changeover and adjust the times manually the next morning.
<G-vec00095-002-s550><adjust.anpassen><de> Wenn du in der Nacht nicht geweckt werden willst, deaktiviere die automatische Zeitanpassung auf dem Smartphone am Abend bevor die Zeitumstellung erfolgt und passe die Zeit am nächsten Morgen manuell an.
<G-vec00095-002-s551><adjust.anpassen><en> Upon request, I adjust my service portfolio graphically for my agency clients so that it is tailored to your CI (colour and logo).
<G-vec00095-002-s551><adjust.anpassen><de> Mein Dienstleistungsportfolio passe ich auf Wunsch für meine Agenturkunden grafisch so an, dass es auf Ihr CI abgestimmt ist (farblich und mit Logo).
<G-vec00095-002-s552><adjust.anpassen><en> Adjust your motorbike's spring constants, tire pressure, and acceleration.
<G-vec00095-002-s552><adjust.anpassen><de> Passe die Federkonstanten deines Motorrads, den Reifendruck und die Beschleunigung an.
<G-vec00095-002-s553><adjust.anpassen><en> Manually adjust your brightness for certain conditions.
<G-vec00095-002-s553><adjust.anpassen><de> Passe manuell die Helligkeit unter bestimmten Umgebungsbedingungen an.
<G-vec00095-002-s554><adjust.anpassen><en> Adjust the photo and place it on the case until it looks exactly as you have been envisioning it.
<G-vec00095-002-s554><adjust.anpassen><de> Passe das Foto an und lege es nach Belieben auf die Hülle.
<G-vec00095-002-s555><adjust.anpassen><en> Adjust the overall quality of shaders.
<G-vec00095-002-s555><adjust.anpassen><de> Passe die allgemeine Qualität der Shader an.
<G-vec00095-002-s556><adjust.anpassen><en> As you see what really does transpire, adjust your actions or responses as best as you can.
<G-vec00095-002-s556><adjust.anpassen><de> Wenn du siehst, was wirklich passiert, passe deine Handlungen oder Reaktionen so gut wie möglich an.
<G-vec00095-002-s557><adjust.anpassen><en> Keep the butter and water ratio the same and simply adjust the amount of bud you grind in.
<G-vec00095-002-s557><adjust.anpassen><de> Halte das Verhältnis von Butter und Wasser gleich und passe einfach die Menge des Marihuanas an, das du hinein mahlst.
<G-vec00095-002-s558><adjust.anpassen><en> If soil in your area is alkaline, adjust it to between 6.1 and 6.5 pH using a garden store pH kit.
<G-vec00095-002-s558><adjust.anpassen><de> Wenn die Erde bei dir alkalisch ist, besorge dir aus dem Gartencenter oder einer Gärtnerei ein pH-Kit und passe den pH-Wert auf 6,1 bis 6,5 an.
<G-vec00095-002-s559><adjust.anpassen><en> Then, adjust either the time frame or your goals themselves.
<G-vec00095-002-s559><adjust.anpassen><de> Passe dann entweder den Zeitrahmen oder die Ziele selbst an.
<G-vec00095-002-s560><adjust.anpassen><en> Adjust a little bit, check, and adjust
<G-vec00095-002-s560><adjust.anpassen><de> Passe ein bisschen an, prüfe und passe weiter an.
<G-vec00095-002-s561><adjust.anpassen><en> • Easily change the style of your title, adjust text and punctuation, or add inline emoji
<G-vec00095-002-s561><adjust.anpassen><de> • Passe den Stil deines Titels, Text oder Satzzeichen ganz einfach an oder füge Emoji hinzu.
<G-vec00095-002-s562><adjust.anpassen><en> Adjust the image.
<G-vec00095-002-s562><adjust.anpassen><de> Passe das Bild an.
<G-vec00095-002-s563><adjust.anpassen><en> Add your logo, decide sizes and position and adjust it to the items you have chosen.
<G-vec00095-002-s563><adjust.anpassen><de> Inseriere dein Logo, ändere die Maße und passe sie an die von dir gewählten Linien an.
<G-vec00095-002-s564><adjust.anpassen><en> Adjust your bid per site before blocking specific sites altogether if your CPA is high.
<G-vec00095-002-s564><adjust.anpassen><de> Wenn dein CPA zu hoch ist, passe dein Gebot pro Seite an, bevor du mehrere Seiten auf einmal pausierst.
<G-vec00095-002-s565><adjust.anpassen><en> Adjust the room temperature.
<G-vec00095-002-s565><adjust.anpassen><de> Passe die Raumtemperatur an.
<G-vec00095-002-s566><adjust.anpassen><en> Adjust your room temperature.
<G-vec00095-002-s566><adjust.anpassen><de> Passe deine Zimmertemperatur an.
<G-vec00095-002-s567><adjust.anpassen><en> Beginner or advanced? we adjust the training to your individual fitness level.
<G-vec00095-002-s567><adjust.anpassen><de> Ob Anfänger oder Fortgeschrittener - wir passen die Trainingsbelastung an Ihren individuellen Trainingsstand an.
<G-vec00095-002-s568><adjust.anpassen><en> Depending on the application speed, the material flow, the diameter required of swirl bead, we adjust the parameters of the gun and the complete system behind. typical Layout
<G-vec00095-002-s568><adjust.anpassen><de> Abhängig von der Applikationsgeschwindigkeit, dem Materialfluss und dem benötigten Durchmesser der Swirlapplikation passen wir die Parameter der Spritzpistole und des gesamten Systems an.
<G-vec00095-002-s569><adjust.anpassen><en> If circumstances change, we adjust our efforts to meet your new requirements.
<G-vec00095-002-s569><adjust.anpassen><de> Wenn sich die Rahmenbedingungen ändern, passen wir die Suche pragmatisch an.
<G-vec00095-002-s570><adjust.anpassen><en> We add this graph to our report (we can now simply click on the report name in the report-selection), adjust the time axis accordingly and give the box a title.
<G-vec00095-002-s570><adjust.anpassen><de> Auch diesen Graphen übernehmen wir in unseren Report (hierzu können wir jetzt den Reportnamen in der Auswahl anklicken), passen die Zeitachse entsprechend an und geben der Box einen Titel.
<G-vec00095-002-s571><adjust.anpassen><en> We always adjust the security in accordance with the legal requirements.
<G-vec00095-002-s571><adjust.anpassen><de> Wir passen die Sicherheit immer an die gesetzlichen Anforderungen an.
<G-vec00095-002-s572><adjust.anpassen><en> To change the amount of overlap between events, adjust the Amount setting in the Cut-to-overlap conversion section of the dialog.
<G-vec00095-002-s572><adjust.anpassen><de> Um das Verhältnis der Überlappung zwischen Events zu ändern, passen Sie im Dialogfeld-Abschnitt Konvertierung für Cutüberschneidung die Einstellung Verhältnis an.
<G-vec00095-002-s573><adjust.anpassen><en> We adjust each UV converter tube to its associated BEAMAGE camera.
<G-vec00095-002-s573><adjust.anpassen><de> Wir passen jedes UV-Konverterrohr an die zugehörige BEAMAGE-Kamera an.
<G-vec00095-002-s574><adjust.anpassen><en> 2. Should an ACP State fail to ratify this Agreement or denounce it, the Parties shall adjust the amounts of the resources provided for in the Financial Protocol set out in Annex I. Adjustment of the financial resources shall also apply upon:
<G-vec00095-002-s574><adjust.anpassen><de> (2) Ratifiziert ein AKP-Staat dieses Abkommen nicht oder kündigt er es, so passen die Vertragsparteien die im Finanzprotokoll in Anhang I vorgesehenen Beträge an.
<G-vec00095-002-s575><adjust.anpassen><en> If this is the case, we will do the word count and adjust for the fee.
<G-vec00095-002-s575><adjust.anpassen><de> In diesem Fall zählen wir die Wörter und passen die Kosten an.
<G-vec00095-002-s576><adjust.anpassen><en> With our self-developed "StyleEdit" you can adjust your shop according to your wishes and needs without any programming skills.
<G-vec00095-002-s576><adjust.anpassen><de> Mit dem von uns entwickelten „StyleEdit“ passen Sie Ihren Shop ohne Programmierkenntnisse nach Ihren Vorstellungen an.
<G-vec00095-002-s577><adjust.anpassen><en> Our buildings adjust to changed user requirements.
<G-vec00095-002-s577><adjust.anpassen><de> Unsere Gebäude passen sich veränderten Nutzeranforderungen an.
<G-vec00095-002-s578><adjust.anpassen><en> Beyond being experts in business analysis, our coaches are aware of learning style differences and adjust the skills transfer process to fit the needs of each person.
<G-vec00095-002-s578><adjust.anpassen><de> Unsere Trainer sind nicht nur Experten der Buiness Analyse, sie erkennen auch die Unterschiede im Lernstil und passen den Prozess des Kompetenztransfers an die Bedürfnisse jedes einzelnen Kunden an.
<G-vec00095-002-s579><adjust.anpassen><en> Adjust the present Rumstag I can present you my result.
<G-vec00095-002-s579><adjust.anpassen><de> Passen zum heutigen Rumstag kann ich Euch mein Ergebnis präsentieren.
<G-vec00095-002-s580><adjust.anpassen><en> Change the gears with the space key, adjust your angle of the jump with the spacebar.
<G-vec00095-002-s580><adjust.anpassen><de> Ändern Sie die Zahnräder mit der Space-Taste, passen Sie die Winkel der Sprung mit der Leertaste.
<G-vec00095-002-s581><adjust.anpassen><en> If you wish, we can adjust your waterbed to fit into your existing bed frame.
<G-vec00095-002-s581><adjust.anpassen><de> Wenn gewünscht, passen wir Ihr Wasserbett auch so an, dass es in Ihr Bettgestell passt.
<G-vec00095-002-s582><adjust.anpassen><en> We will adjust the privacy policy as soon as there are changes in the data processing required.
<G-vec00095-002-s582><adjust.anpassen><de> Wir passen die Datenschutzerklärung an, sobald die Änderungen der von uns durchgeführten Datenverarbeitungen dies erforderlich machen.
<G-vec00095-002-s583><adjust.anpassen><en> These can be easily controlled via the hob operating panel and automatically adjust their output to the amount of heat generated by the hob.
<G-vec00095-002-s583><adjust.anpassen><de> Diese lassen sich ganz einfach über das Bedienfeld des Kochfeldes steuern und passen ihre Leistung automatisch der Wärmebildung des Kochfeldes an.
<G-vec00095-002-s584><adjust.anpassen><en> Then you need to be flexible and adjust their plans.
<G-vec00095-002-s584><adjust.anpassen><de> Dann müssen Sie flexibel sein und passen ihre Pläne.
<G-vec00095-002-s585><adjust.anpassen><en> The upper handles (which appear only in Manual mode) adjust the tolerance (core transparency) of the luma channel’s contribution to the key.
<G-vec00095-002-s585><adjust.anpassen><de> Die oberen Aktivpunkte (nur im Modus „Manuell“ verfügbar) passen die Toleranz (Kerntransparenz) an, die der Luma-Kanal zur Stanzmaske beiträgt.
<G-vec00095-002-s586><adjust.anpassen><en> Indulgence without compromise: you choose your coffee strength and the temperature. Added to that, one single rotation is all it takes to adjust the amount of coffee to the preferred cup size.
<G-vec00095-002-s586><adjust.anpassen><de> Genuss ohne Kompromisse: Wählen Sie Ihre Kaffeestärke und Temperatur: Mit einer einzigen Drehung passen Sie außerdem die Kaffeemenge an die bevorzugte Tassengröße (30 - 220 ml) an.
<G-vec00095-002-s587><adjust.anpassen><en> In the future you will be able to adjust the adapter and the tool heads to your required working position, as they are now rotatable by 360°.
<G-vec00095-002-s587><adjust.anpassen><de> Passen Sie in Zukunft den Adapter und die Werkzeugköpfe doch einfach Ihrer gewünschten Arbeitsposition an, denn diese sind ab sofort um 360° drehbar.
<G-vec00095-002-s588><adjust.anpassen><en> Depending on the goals and objectives, you simply select a pre-defined template, adjust the template according to your needs and upload your addresses – done.
<G-vec00095-002-s588><adjust.anpassen><de> Je nach Anwendungszweck wählen Sie eine vorgestaltete Kampagne aus, passen die Vorlagen nach Ihren Wünschen an und laden Ihre Adressdaten hoch – fertig.
<G-vec00095-002-s589><adjust.anpassen><en> Use one of the following examples and adjust them to your needs.
<G-vec00095-002-s589><adjust.anpassen><de> Nutzen Sie dafür eines der folgenden Beispiele und passen diese auf Ihre Bedürfnisse an.
<G-vec00095-002-s590><adjust.anpassen><en> First of we adjust our project settings.
<G-vec00095-002-s590><adjust.anpassen><de> Als erstes passen wir die Voreinstellungen an.
<G-vec00095-002-s591><adjust.anpassen><en> The masks for the feeding in process (information fields) adjust themselves to any of these specific investment instruments.
<G-vec00095-002-s591><adjust.anpassen><de> Die Eingabemasken (Informationsfelder) passen sich jedem dieser spezifischen Anlageinstrumenten an.
<G-vec00095-002-s592><adjust.anpassen><en> The Audi Matrix LED headlights can adjust the light distribution from your Audi RS 6 Avant to perfection, depending on the situation.
<G-vec00095-002-s592><adjust.anpassen><de> Je nach Situation passen die Audi Matrix LED-Scheinwerfer die Lichtverteilung Ihres Audi TT Roadster optimal an.
<G-vec00095-002-s593><adjust.anpassen><en> To guarantee you the best possible insurance protection, we adjust our insurance packages individually to your life situation, needs and preferences.
<G-vec00095-002-s593><adjust.anpassen><de> Um dir den optimalen Versicherungsschutz zu garantieren, passen wir unsere Versicherungspakete individuell an deine Lebenssituation, Wünsche und Vorstellungen an.
<G-vec00095-002-s594><adjust.anpassen><en> We always aim for perfection and will therefore adjust the specifications for each project, to suit the requirements for the work to be performed on the vessel.
<G-vec00095-002-s594><adjust.anpassen><de> Wir streben ständig nach Perfektion und passen deshalb für jedes Projekt die Spezifikationen an, um die Anforderungen, die sich aus der spezifischen Benutzung Ihres Bootes oder Schiffes ergeben, zu erfüllen.
<G-vec00095-002-s595><adjust.anpassen><en> We discuss the design with you and adjust it accordingly.
<G-vec00095-002-s595><adjust.anpassen><de> Wir stimmen das Design mit Ihnen ab und passen dieses entsprechend an.
<G-vec00095-002-s597><adjust.anpassen><en> Developing. We adjust your documentation tools according to your needs and develop publishing solutions for web portals or apps.
<G-vec00095-002-s597><adjust.anpassen><de> Wir passen Ihre Dokumentationswerkzeuge an Ihre Anforderungen an und entwickeln Lösungen für die Publikation Ihrer Inhalte auf Web-Portalen oder als App.
<G-vec00095-002-s598><adjust.anpassen><en> Opacity envelopes adjust the transparency of an event, allowing it to fade in over a background.
<G-vec00095-002-s598><adjust.anpassen><de> Deckungsgrad-Hüllkurven passen die Transparenz eines Events an und ermöglichen es, das Event vor einem Hintergrund einzublenden.
<G-vec00095-002-s599><adjust.anpassen><en> We are happy to adjust our opening times at negotiable your wishes.
<G-vec00095-002-s599><adjust.anpassen><de> Gern passen wir unsere Öffnungszeiten nach Absprache Ihren Wünschen an.
<G-vec00095-002-s600><adjust.anpassen><en> During the game training, your employees plan the activities of their business or units, analyze the markets and activities of competitors, adjust and optimize processes, compete, cooperate, trade not only with the computer, but with each other.
<G-vec00095-002-s600><adjust.anpassen><de> Während des Spieltrainings planen Ihre Mitarbeiter die Aktivitäten ihres Unternehmens oder ihrer Einheiten, analysieren Märkte und Aktivitäten von Wettbewerbern, passen Prozesse an und optimieren sie, konkurrieren, kooperieren und handeln nicht nur mit dem Computer, sondern untereinander.
<G-vec00095-002-s601><adjust.anpassen><en> Through regular surveys of our suppliers, we continuously adjust the WE Programme to meet the needs of workers.
<G-vec00095-002-s601><adjust.anpassen><de> Wir befragen unsere Lieferanten regelmäßig nach Verbesserungsvorschlägen und passen WE kontinuierlich an die Bedürfnisse der Beschäftigten an.
<G-vec00095-002-s602><adjust.anpassen><en> If you do not want us to use personal information that we gather to allow third parties to personalize advertisements we display to you, please adjust your Advertising Preferences .
<G-vec00095-002-s602><adjust.anpassen><de> Wenn Sie nicht möchten, dass wir personenbezogene Daten verwenden, die wir Dritten zur Verfügung stellen, um Anzeigen, die wir Ihnen zeigen, zu personalisieren, passen Sie bitte Ihre Werbepräferenzen an.
<G-vec00095-002-s603><adjust.anpassen><en> They approach history with a preconceived notion and then adjust the evidence accordingly.
<G-vec00095-002-s603><adjust.anpassen><de> Sie gehen an die Geschichte mit einer vorgefassten Meinung heran und passen die Beweise entsprechend an.
<G-vec00095-002-s604><adjust.anpassen><en> We are not strictly limited by a modular system, we can adjust the design of a conveyor exactly as you need.
<G-vec00095-002-s604><adjust.anpassen><de> Wir unterliegen keiner strikten Einschränkung durch das modulare System, sondern passen die Förderanlage konstruktionell Ihren Bedürfnissen genau an.
<G-vec00095-002-s605><adjust.anpassen><en> Adjust the settings for your new password, then copy it to the clipboard or fill it on the page.
<G-vec00095-002-s605><adjust.anpassen><de> Passen Sie die Einstellungen für Ihr neues Passwort an und kopieren Sie es dann in die Zwischenablage oder füllen Sie es auf der Seite aus.
<G-vec00095-002-s606><adjust.anpassen><en> To add picture watermark, please click "Add Picture Watermark" button, and choose a picture in the dialog that opens, and adjust the settings below.
<G-vec00095-002-s606><adjust.anpassen><de> Um Bildwasserzeichen hinzuzufügen, klicken Sie bitte auf „Bildwasserzeichen hinzufügen“, wählen Sie ein Bild aus dem geöffneten Dialog aus und passen Sie die Einstellungen an.
<G-vec00095-002-s607><adjust.anpassen><en> Adjust the speed of the slide.
<G-vec00095-002-s607><adjust.anpassen><de> Passen Sie die Geschwindigkeit des Schlittens.
<G-vec00095-002-s608><adjust.anpassen><en> As long as you are not contented with the synchronous run, adjust the correction course by well-considered defining of additional Spline markers.
<G-vec00095-002-s608><adjust.anpassen><de> Solange Sie mit dem Synchronlauf nicht zufrieden sind, passen Sie den Korrekturverlauf durch wohlüberlegtes Setzen weiterer Splinemarker an.
<G-vec00095-002-s609><adjust.anpassen><en> Add impact to your video tracks and adjust the opacity of a video clip, so you can see multiple clips at the same time, create superimposed effects or custom fade-in / fade-out transitions.
<G-vec00095-002-s609><adjust.anpassen><de> Erhöhen Sie die Wirkung Ihrer Videospuren und passen Sie die Deckkraft eines Videoclips an, damit mehrere Clips gleichzeitig zu sehen sind; erzeugen Sie Überlagerungs- und eigene Ein- und Ausblendeffekte.
<G-vec00095-002-s610><adjust.anpassen><en> Hue versus Saturation - Adjust the saturation of pixels in a selected hue range.
<G-vec00095-002-s610><adjust.anpassen><de> Farbton vs. Sättigung –Passen Sie die Sättigung der Pixel in einem ausgewählten Farbtonbereich an.
<G-vec00095-002-s611><adjust.anpassen><en> You can add the Comic filter, then adjust it in the inspector or the heads-up display (HUD).
<G-vec00095-002-s611><adjust.anpassen><de> Fügen Sie den Comic-Filter hinzu, und passen Sie ihn im Informationsfenster oder in der Schwebepalette an.
<G-vec00095-002-s612><adjust.anpassen><en> Adjust the dates in the Start Date and Due Date columns to reflect the relationships between the tasks.
<G-vec00095-002-s612><adjust.anpassen><de> Passen Sie die Datumsangaben in den Spalten Startdatum und Fälligkeitsdatum gemäß den Beziehungen zwischen den Aufgaben an.
<G-vec00095-002-s613><adjust.anpassen><en> Adjust your bids based on the day of check in at the hotel.
<G-vec00095-002-s613><adjust.anpassen><de> Passen Sie Ihre Gebote auf der Grundlage des Ankunftstags im Hotel an.
<G-vec00095-002-s614><adjust.anpassen><en> Adjust the number of colors in the tracing result when Mode is set to Color. Grays
<G-vec00095-002-s614><adjust.anpassen><de> Passen Sie die Anzahl der Farben im Nachzeichnerergebnis an, wenn als Modus „Farbe“ festgelegt wurde.
<G-vec00095-002-s615><adjust.anpassen><en> Adjust Brightness first, then adjust Contrast only if further adjustment is necessary.
<G-vec00095-002-s615><adjust.anpassen><de> Passen Sie zunächst Helligkeit an und anschließend, falls erforderlich, den Kontrast.
<G-vec00095-002-s616><adjust.anpassen><en> Adjust the CompressionThreshold setting.
<G-vec00095-002-s616><adjust.anpassen><de> Passen Sie die Einstellung des Verbindungsparameters CompressionThreshold an.
<G-vec00095-002-s617><adjust.anpassen><en> Optimize images with a click or adjust brightness, contrast, saturation, photo temperature, hue control etc.
<G-vec00095-002-s617><adjust.anpassen><de> Optimieren Sie Bilder mit nur einem Klick oder passen Sie Dinge wie Helligkeit, Kontrast, Sättigung, Foto-Temperatur, Farbtonregelung u.v.m.
<G-vec00095-002-s618><adjust.anpassen><en> Optional: In the Body tab, change and adjust the sending time by changing the number of days. —Image—
<G-vec00095-002-s618><adjust.anpassen><de> Optional: Wechseln Sie in den Reiter Template und passen Sie die Versanddauer an, indem Sie die Anzahl der Tage ändern (standardmäßig 10).
<G-vec00095-002-s619><adjust.anpassen><en> Place your borrowed ring on the screen and adjust the circle until it aligns with the inner outline of the ring.
<G-vec00095-002-s619><adjust.anpassen><de> Legen Sie den Ring auf den Bildschirm und passen Sie den Kreis an, bis er mit dem inneren Umriss des Ringes übereinstimmt.
<G-vec00095-002-s620><adjust.anpassen><en> If your computer is connected to the Internet via the proxy server, adjust proxy server settings in the product.
<G-vec00095-002-s620><adjust.anpassen><de> Passen Sie die Einstellungen für den Proxyserver im Programm, wenn Sie einen Proxyserver für den Internetzugriff verwenden.
<G-vec00095-002-s621><adjust.anpassen><en> If doing so produces a choppy sound, adjust the percentage to strike a balance between choppiness and chorusing.
<G-vec00095-002-s621><adjust.anpassen><de> Wenn dies zu einem abgehackten Sound führt, passen Sie den Prozentsatz an, um ein Gleichgewicht zwischen den beiden Effekten herzustellen.
<G-vec00095-002-s622><adjust.anpassen><en> To view previous invoices, adjust the date range using the drop-down menu.
<G-vec00095-002-s622><adjust.anpassen><de> Passen Sie über das Drop-down-Menü den Zeitraum an, um ältere Daten einzubeziehen.
<G-vec00095-002-s623><adjust.anpassen><en> Adjust the iGO navigation software for campers to your RV and adjust your vehicle parameters.
<G-vec00095-002-s623><adjust.anpassen><de> Passen Sie die iGO Camper & Truck Navisoftware Ihrem Wohnmobil an und hinterlegen Sie Ihre Fahrzeugparameter.
<G-vec00095-002-s624><adjust.anpassen><en> Knob adjust air volume, digital display air volume gear, realize precise control.
<G-vec00095-002-s624><adjust.anpassen><de> ● Doppelter Knopf passt Luftvolumen, Temperatur und digitale visuelle Anzeige für präzise Steuerung.
<G-vec00095-002-s625><adjust.anpassen><en> If at the moment of an installation or modification of the adjustments of SME Server it detects an inexact translation or that one does not adjust to the context, please, takes note precise from the same one and in where it found it, soon to correct it.
<G-vec00095-002-s625><adjust.anpassen><de> Wenn Sie bei der Installation oder beim Ändern von Einstellungen eine ungenaue Übersetzung bemerken oder wenn die Übersetzung nicht zum Kontext passt, machen Sie sich Notizen zu der Übersetzung und wo Sie sie gefunden haben, um sie möglichst bald zu korrigieren.
<G-vec00095-002-s626><adjust.anpassen><en> You enter certain input into them and adjust the connections among the neurons in such a way that the desired output will “most probably” appear in the end.
<G-vec00095-002-s626><adjust.anpassen><de> Man füttert sie mit einem bestimmten Input und passt die Verbindungen zwischen den Neuronen so an, dass am Ende „hochwahrscheinlich“ der gewünschte Output erscheint.
<G-vec00095-002-s627><adjust.anpassen><en> SFX Pro’s sleeve fan will automatically adjust its fan speed according to the PSU’s temperature.
<G-vec00095-002-s627><adjust.anpassen><de> Der Gehäuselüfter des SFX Pro passt die Lüftergeschwindigkeit automatisch an die Temperatur des Netzteils an.
<G-vec00095-002-s628><adjust.anpassen><en> Photoshop will now automatically adjust itself based on your Windows settings, making it simple to set up.
<G-vec00095-002-s628><adjust.anpassen><de> Photoshop passt sich auf der Grundlage euer Windows-Einstellungen automatisch an, wodurch das Setup ein Kinderspiel wird.
<G-vec00095-002-s629><adjust.anpassen><en> Intelligent lighting learns how you use the premises and adjust the lighting according to it.
<G-vec00095-002-s629><adjust.anpassen><de> Die intelligente Beleuchtung lernt die Nutzung der Räume und passt die Beleuchtung entsprechend an.
<G-vec00095-002-s630><adjust.anpassen><en> 1. The competent authority of the Member State addressed shall, where and to the extent necessary, adjust the factual elements of the protection measure in order to give effect to the protection measure in that Member State.
<G-vec00095-002-s630><adjust.anpassen><de> (1) Die zuständige Behörde des ersuchten Mitgliedstaats passt, sofern und soweit erforderlich, die faktischen Elemente der Schutzmaßnahme an, um der Schutzmaßnahme in diesem Mitgliedstaat Wirkung zu verleihen.
<G-vec00095-002-s631><adjust.anpassen><en> The decision was made for the Karlsruhe, Germany, based business software not only because the system's scalability was ideal for their growing operation, but also because the function range included in the standard release was a good fit for a sheet metal processing operation while still providing extensive options to adjust the system to their own requirements.
<G-vec00095-002-s631><adjust.anpassen><de> Die Entscheidung fällt auf die Karlsruher Unternehmenssoftware, nicht nur, weil sie von der Leistungsfähigkeit ideal zur Betriebsgröße passt, sondern vor allem aufgrund des Funktionsumfangs, der schon im Standard weitestgehend zum Blechbearbeitungsbetrieb passt und darüber hinaus umfangreiche Möglichkeiten bietet, eigene Anforderungen umzusetzen.
<G-vec00095-002-s632><adjust.anpassen><en> The option Free Transform ("Free Transformation")menu Edit ("Edit") adjust the dimensions of the inserted image to the size of the figure in the photo.
<G-vec00095-002-s632><adjust.anpassen><de> Die Option Freie Transformation ("Freie Transformation")Menü Bearbeiten ("Bearbeiten") passt die Abmessungen des eingefügten Bildes an die Größe der Figur im Foto an.
<G-vec00095-002-s633><adjust.anpassen><en> If your package sizes differ from my – don’t worry. Just add a little more / less milk and adjust the creaminess later on.
<G-vec00095-002-s633><adjust.anpassen><de> Sollte euer Seidentofu in anderen Packungsgrößen kommen, dann benutzt zunächst etwas mehr / weniger Mandelmilch und passt die Menge bei Bedarf später noch an.
<G-vec00095-002-s634><adjust.anpassen><en> This control lets you adjust the number of beats per minute (BPM) and is essential for adjusting both tracks to play at the same speed before making a transition.
<G-vec00095-002-s634><adjust.anpassen><de> Dieser Regler passt die Anzahl der Beats pro Minute (BPM) an und ist entscheidend, um beide Tracks vor dem Einfügen eines Übergangs auf dasselbe Tempo anzupassen.
<G-vec00095-002-s635><adjust.anpassen><en> We cover the designing of the brake – the construction of the brake disk as well as the selection of the friction layers and the caliper – and adjust the brake into the concept of the vehicle.
<G-vec00095-002-s635><adjust.anpassen><de> Wir übernehmen die Auslegung der Radbremse – die Konstruktion der Bremsscheibe sowie die Auswahl der Bremsbeläge und des Bremssattels – und passt die Radbremse in das Fahrzeugkonzept ein.
<G-vec00095-002-s636><adjust.anpassen><en> Specify a skin color in an image and adjust the exposure and white balance. 1.
<G-vec00095-002-s636><adjust.anpassen><de> Man bestimmt in dem Bild die Hautfarbe und passt den Belichtigungsausgleich und den Weißabgleich an.
<G-vec00095-002-s637><adjust.anpassen><en> Set your speed and safe following distance, and let Intelligent Cruise Control not only maintain but automatically adjust your speed to adapt to the traffic flow.
<G-vec00095-002-s637><adjust.anpassen><de> Intelligente Geschwindigkeitsregelung Sie stellen die Geschwindigkeit und den Sicherheitsabstand ein und die intelligente Geschwindigkeitsregelung passt Ihre Geschwindigkeit automatisch dem Verkehrsfluss an.
<G-vec00095-002-s638><adjust.anpassen><en> No child is pleased with a boring-looking chair with a seat height that doesn’t adjust to them and where they have to slip restlessly back and forth to find a comfortable seating position.
<G-vec00095-002-s638><adjust.anpassen><de> Kein Kind freut sich über einen langweilig aussehenden Stuhl, dessen Sitzhöhe nicht zu ihm passt und auf dem es unruhig hin- und herrutschen muss, um eine angenehme Sitzposition zu finden.
<G-vec00095-002-s639><adjust.anpassen><en> Elasticated bust with Velcro tab to adjust to any size.
<G-vec00095-002-s639><adjust.anpassen><de> Der mit Klettverschluss verstellbare Gummibund passt für jede Größe.
<G-vec00095-002-s640><adjust.anpassen><en> In the particular configuration opted for, the HMI (Human Machine Interface) display and the tablet display react to changes in the data situation and dynamically and automatically adjust the necessary documentation.
<G-vec00095-002-s640><adjust.anpassen><de> Bei der jeweils eingesetzten Konfiguration reagiert die Anzeige des HMIs (Human Machine Interface) sowie des Tablets auf die geänderte Datenlage und passt dynamisch die notwendigen Dokumentationen automatisch an.
<G-vec00095-002-s641><adjust.anpassen><en> Stuttgart, Mar 27, 2018 - As of financial year 2018, Daimler AG will adjust its financial reporting to comply with the new standards IFRS 9 and 15.
<G-vec00095-002-s641><adjust.anpassen><de> Stuttgart, 27.03.2018 - Die Daimler AG passt mit dem Geschäftsjahr 2018 die Bilanzierung an die neuen Standards IFRS 9 und 15 an.
<G-vec00095-002-s642><adjust.anpassen><en> Buttons let you quickly play, pause and change songs or adjust the volume.
<G-vec00095-002-s642><adjust.anpassen><de> Mit den Tasten spielst du schnell Songs ab, stoppst, wechselst das Lied und passt die Lautstärke an.
<G-vec00095-002-s643><adjust.anpassen><en> Adjust the brightness of the video signal (default: 0).
<G-vec00095-002-s643><adjust.anpassen><de> Passt die Helligkeit der Videoausgabe an (Standard: 0).
<G-vec00095-002-s644><adjust.anpassen><en> Gamma Correction - To adjust the white point.
<G-vec00095-002-s644><adjust.anpassen><de> Gammakorrektur – passt den Weißpunkt an.
<G-vec00095-002-s645><adjust.anpassen><en> The newly presented Uvex Variotronic is based on a completely new concept whereby the lenses adjust to light conditions within tenths of a second.
<G-vec00095-002-s645><adjust.anpassen><de> Die nun von Uvex präsentierte Variotronic setzt auf ein komplett neues Konzept und passt die Gläser innerhalb einer zehntel Sekunde an die vorherrschende Lichtsituation an.
<G-vec00095-002-s646><adjust.anpassen><en> The intelligent management system will automatically adjust the settings for the freezing tunnel.
<G-vec00095-002-s646><adjust.anpassen><de> Das intelligente Betriebssystem passt die Einstellungen des Gefriertunnels automatisch an.
<G-vec00095-002-s647><adjust.anpassen><en> Function CONT (Contrast) Function Adjust the contrast of printing image.
<G-vec00095-002-s647><adjust.anpassen><de> CONT (Contrast) Passt den Kontrast des Druckbildes an.
<G-vec00095-002-s648><adjust.anpassen><en> By using the integrated Built-In-Pressure system and the handy BPS card, the patient can easily adjust the compression range to maintain the therapeutic compression level.
<G-vec00095-002-s648><adjust.anpassen><de> Mit dem integrierten Built-In-Pressure System justiert der Patient den Kompressionsbereich einfach mit einer handlichen Messkarte nach und passt ihn an den verringerten Umfang an.
<G-vec00095-002-s649><adjust.anpassen><en> The laser will automatically adjust to the correct height based on the thickness of the material you are cutting or engraving.
<G-vec00095-002-s649><adjust.anpassen><de> Der Laser passt die Höhe automatisch an die Dicke des Materials an, das Sie schneiden oder gravieren.
<G-vec00095-002-s650><adjust.anpassen><en> If your selected time zone observes DST, Hootsuite will comply with that observance and adjust the dashboard time at 2am.
<G-vec00095-002-s650><adjust.anpassen><de> Falls eine Zeitumstellung auf Ihre gewählte Zeitzone zutrifft, passt Hootsuite die Dashboard-Zeit um 2 Uhr an.
<G-vec00095-002-s651><adjust.anpassen><en> Prepared positions are saved (for takeoff and landing, eating, lounge) or you can adjust it after your needs.
<G-vec00095-002-s651><adjust.anpassen><de> Es sind fertige Positionen (Start- und Landung, Essen, Lounge) gespeichert, oder aber der Gast passt es nach Bedarf an.
<G-vec00095-002-s652><adjust.anpassen><en> ReSound uniquely applies proven technologies that can accurately identify voices in noisy backgrounds and automatically adjust settings so that you can hear speech more clearly, but without losing touch with other sounds.
<G-vec00095-002-s652><adjust.anpassen><de> ReSound verwendet bewährte Technologien, mit denen sich Stimmen in lärmiger Umgebung präzise identifizieren lassen und passt die Einstellungen automatisch an, sodass Sie Sprache klarer hören können, ohne dabei den Kontakt zu anderen Geräuschen zu verlieren.
<G-vec00095-002-s653><adjust.anpassen><en> Adjust the volume from the left and right speaker.
<G-vec00095-002-s653><adjust.anpassen><de> Passt die Lautstärke zwischen dem linken und dem rechten Lautsprecher an.
<G-vec00095-002-s654><adjust.anpassen><en> The Intelligent Charge technology allows this portable charger to automatically recognize the maximum absorbable charging level of your device and adjust it accordingly.
<G-vec00095-002-s654><adjust.anpassen><de> Dank diesem innovativen System erkennt das tragbare Ladegerät automatisch die vom Gerät aufgenommene Höchstleistung und passt sie dementsprechend an.
<G-vec00095-002-s655><adjust.anpassen><en> And to ensure that you have the best view in any situation, you can adjust the luminosity intensity as you wish to suit the individual lighting conditions.
<G-vec00095-002-s655><adjust.anpassen><de> Und damit Sie in jeder Situation den besten Durchblick haben, passt sich die Leuchtstärke auf Wunsch an die jeweiligen Lichtbedingungen an.
<G-vec00095-002-s656><adjust.anpassen><en> Our intelligent equipment adjust your welding procedure according to the welded material and the pipe diameter, liquid influx/flow and pressure.
<G-vec00095-002-s656><adjust.anpassen><de> Entsprechend dem geschweißten Material und dem Rohrdurchmesser sowie abhängig von Durchfluss und Druck des Mediums passt unsere intelligente Ausrüstung Ihr Schweißverfahren an.
<G-vec00095-002-s657><adjust.anpassen><en> As you meet your milestones, it will adjust your goal for the next day, gradually nudging you toward a healthier lifestyle.
<G-vec00095-002-s657><adjust.anpassen><de> Abhängig von deinen täglichen Erfolgen passt das Gerät dein Ziel für den nächsten Tag an und bringt dich damit einem gesunden Lebensstil näher.
<G-vec00095-002-s658><adjust.anpassen><en> You will also be required to adjust credit limits where needed and provide monthly reports for the relevant departments.
<G-vec00095-002-s658><adjust.anpassen><de> Weiterhin passt du, wenn nötig, Kreditlimits an und schickst jeden Monat Berichte an die entsprechenden Abteilungen.
<G-vec00095-002-s659><adjust.anpassen><en> The Editor will then automatically adjust the proportions of the other photos.
<G-vec00095-002-s659><adjust.anpassen><de> Der Editor passt dabei automatisch die Maße der anderen Fotos an.
<G-vec00095-002-s660><adjust.anpassen><en> If you upload a frame rate that is higher than 60 FPS or lower than 15 FPS, Vimeo will automatically adjust the frame rate for you — but we can't guarantee the results will always look as expected.
<G-vec00095-002-s660><adjust.anpassen><de> Wenn du eine Bildrate von mehr als 60 FPS oder weniger als 15 FPS hochlädst, passt Vimeo die Bildrate automatisch für dich an - aber wir können nicht garantieren, dass die Ergebnisse immer wie erwartet aussehen.
<G-vec00095-002-s714><adjust.anpassen><en> You can adjust the Anchorage type and the Bond type by using the lists.
<G-vec00095-002-s714><adjust.anpassen><de> Über die Listen lassen sich die Verankerungsart und der Verbund anpassen.
<G-vec00095-002-s715><adjust.anpassen><en> The efficient trimmer head ensures good results and you can easily adjust it by changing the type of blade, depending on the task – from fine trimming to heavy work in rough terrain.
<G-vec00095-002-s715><adjust.anpassen><de> Der leistungsstarke Trimmerkopf gewährleistet gute Ergebnisse und lässt sich ganz einfach durch die Wahl eines anderen Schneideblatts an die entsprechende Aufgabe anpassen: von Feinbearbeitung bis hin zu harter Arbeit in anspruchsvollem Gelände.
<G-vec00095-002-s716><adjust.anpassen><en> In OS X, you can adjust keyboard shortcuts for each program under »System Preferences > Keyboard > Shortcuts«.
<G-vec00095-002-s716><adjust.anpassen><de> Tastaturkurzbefehle lassen sich in OS X für jedes Programm unter »Systemeinstellungen > Tastatur > Kurzbefehle« anpassen.
<G-vec00095-002-s717><adjust.anpassen><en> You can adjust the using quantity and using area according to your need.
<G-vec00095-002-s717><adjust.anpassen><de> Sie können sich die Gebrauchsmenge und den Gebrauchbereich entsprechend Ihrem Bedarf anpassen.
<G-vec00095-002-s718><adjust.anpassen><en> 2 piece light reactive lenses that adjust to a wide range of changing light conditions.
<G-vec00095-002-s718><adjust.anpassen><de> 2 Stück leichte reaktive Linsen, die sich eine Vielzahl von wechselnden Licht Bedingungen anpassen.
<G-vec00095-002-s719><adjust.anpassen><en> SDS can adjust automatically based on your capacity needs.
<G-vec00095-002-s719><adjust.anpassen><de> SDS lässt sich je nach Ihren Kapazitätsbedürfnissen automatisch anpassen.
<G-vec00095-002-s720><adjust.anpassen><en> Its rounded head, five blades that adjust to every curve, and Ribbon of MoistureTM ensure smooth results.
<G-vec00095-002-s720><adjust.anpassen><de> Sein abgerundeter Klingenkopf, fünf Klingen, die sich jeder Kurve anpassen, und das Feuchtigkeitsband garantieren glatte Ergebnisse.
<G-vec00095-002-s721><adjust.anpassen><en> It must adjust with the times and new circumstances.
<G-vec00095-002-s721><adjust.anpassen><de> Sie muss sich der Zeit und den neuen Gegebenheiten anpassen.
<G-vec00095-002-s722><adjust.anpassen><en> Equipped with four Slide Bloc buckles, you can adjust the Ophir Kids to any child size within seconds.
<G-vec00095-002-s722><adjust.anpassen><de> Mit vier Slide Bloc-Schnallen ausgestattet lässt sich der Ophir Kids in Sekundenschnelle an jede Kindergröße anpassen.
<G-vec00095-002-s723><adjust.anpassen><en> The new development supports the efficiency and cost effectiveness of climbing systems insomuch that they adjust flexibly to the structure geometry and permit larger formwork units.
<G-vec00095-002-s723><adjust.anpassen><de> Die Neuentwicklung unterstützt die Effizienz und Wirtschaftlichkeit von Klettersystemen, indem sie sich flexibel an die Bauwerksgeometrie anpassen lässt und größere Schalungseinheiten erlaubt.
<G-vec00095-002-s724><adjust.anpassen><en> Your body will adjust to make that happen and you will begin to see changes in many ways, including some of the shifts in consciousness.
<G-vec00095-002-s724><adjust.anpassen><de> Euer Körper wird sich anpassen, um das zu ermöglichen, und ihr werdet bald unterschiedliche Veränderungen sehen, darunter auch Bewusstseinsverschiebungen.
<G-vec00095-002-s725><adjust.anpassen><en> But they were able to adjust quickly.
<G-vec00095-002-s725><adjust.anpassen><de> Aber sie konnten sich schnell anpassen.
<G-vec00095-002-s726><adjust.anpassen><en> The safety cushion is therefore able to easily adjust to the child’s body.
<G-vec00095-002-s726><adjust.anpassen><de> Das Sicherheitskissen lässt sich dadurch leicht dem Körper des Kindes anpassen.
<G-vec00095-002-s727><adjust.anpassen><en> This means that no matter what monitor resolution you set, all elements adjust the size automatically.
<G-vec00095-002-s727><adjust.anpassen><de> Das bedeutet das egal welche Monitorauflösung man einstellt, sich alle Elemente automatisch in der Größe anpassen.
<G-vec00095-002-s728><adjust.anpassen><en> The Rear Delt/Pec Fly machine is equipped with swivelling, mobile arms, which adjust automatically to the arm length of the user.
<G-vec00095-002-s728><adjust.anpassen><de> Die Taurus Pec Fly/Rear Delt IT95 verfügt über schwenkbare, bewegliche Arme, die sich automatisch der Armlänge des Trainierenden anpassen.
<G-vec00095-002-s729><adjust.anpassen><en> You can adjust the white balance, tonal range, contrast, color saturation, and sharpness of a raw image without any loss of image quality.
<G-vec00095-002-s729><adjust.anpassen><de> Ohne Verlust der Bildqualität lassen sich Weißabgleich, Tonwertbereich, Kontrast, Farbsättigung und Schärfe von Kamera-Rohdateien, wie jeweils gewünscht, anpassen.
<G-vec00095-002-s730><adjust.anpassen><en> And I know that I’m fast: my skiing just needs to adjust to the material’s performance, then everything will be fine”, as the World Cup winner quickly put the race behind her again in the Atomic Facebook Livestream.
<G-vec00095-002-s730><adjust.anpassen><de> Und ich weiß, dass ich schnell bin: Mein Skifahren muss sich nur an die Performance des Materials anpassen, dann ist alles gut“, war für die Gesamtweltcupsiegerin im Atomic Facebook Livestream schnell wieder ein Haken unter dem Rennen.
<G-vec00095-002-s731><adjust.anpassen><en> This allows the belt to adjust optimally to any height und will not soon be too small.
<G-vec00095-002-s731><adjust.anpassen><de> Damit lässt sich der Gurt optimal an jede Körpergröße anpassen und wird nicht so schnell zu klein.
<G-vec00095-002-s732><adjust.anpassen><en> For this, you can adjust the colors and values assigned in the panel.
<G-vec00095-002-s732><adjust.anpassen><de> Dabei lassen sich die Farb- und Wertezuweisungen des Panels anpassen.
<G-vec00095-002-s733><adjust.anpassen><en> Researchers from the Institute of Neuroscience in Brussels are studying how long it takes our brains to adjust to this dynamic.
<G-vec00095-002-s733><adjust.anpassen><de> Wissenschaftler am Institut für Neurobiologie in Brüssel erforschen, wie lang unser Gehirn braucht, um sich an diese neue Dynamik anzupassen.
<G-vec00095-002-s734><adjust.anpassen><en> As new services and means of distribution arise, old staples will still have time to adjust.
<G-vec00095-002-s734><adjust.anpassen><de> Trotz immer neuer Dienste und Distributionswege bleibt alten Strukturen noch genug Zeit, sich anzupassen.
<G-vec00095-002-s735><adjust.anpassen><en> a legal and regulatory environment that is stable but also flexible enough to adjust swiftly to a constantly changing environment,
<G-vec00095-002-s735><adjust.anpassen><de> Ein stabiler rechtlicher und aufsichtsrechtlicher Rahmen, der gleichzeitig flexibel genug ist, um sich schnell an veränderte Rahmenbedingungen anzupassen.
<G-vec00095-002-s736><adjust.anpassen><en> Because we are developing using an agile process the team is able to adjust on the fly.
<G-vec00095-002-s736><adjust.anpassen><de> Weil wir mit einem agilen Prozess entwickeln, ist das Team in der Lage, sich spontan anzupassen.
<G-vec00095-002-s737><adjust.anpassen><en> If you choose to stay with a family, you should recognize that a certain degree of flexibility will be required to adjust to Peruvian customs and way of life.
<G-vec00095-002-s737><adjust.anpassen><de> Wenn Sie vorhaben, mit einer Familie zu leben, sollten Sie daran denken, dass Sie ein gewisses Maß an Flexibilität mitbringen sollten, um sich an die peruanischen Gewohnheiten und den Lebensstil anzupassen.
<G-vec00095-002-s738><adjust.anpassen><en> Since the skin still needs a while to adjust to the new underlay as smooth as possible, wearing the corsetry is useful for a period of about four to eight weeks.
<G-vec00095-002-s738><adjust.anpassen><de> Da die Haut noch eine längere Zeit braucht, um sich der neuen Unterlage möglichst glatt anzupassen, ist das Tragen der Miederware für einen Zeitraum von etwa vier bis acht Wochen sinnvoll.
<G-vec00095-002-s739><adjust.anpassen><en> Our eyes have the natural ability to adjust to these different types of lighting, but a camera doesn’t.
<G-vec00095-002-s739><adjust.anpassen><de> Unsere Augen haben die natürliche Fähigkeit, sich an diese verschiedenen Arten der Beleuchtung anzupassen, aber eine Kamera nicht.
<G-vec00095-002-s740><adjust.anpassen><en> Description As part of our diving accessories, MP-400 scuba mouthpiece, a conventional scuba mouthpieces use an extremely flexible material in order to adjust to all the various configurations of teeth and jaws required by the our special design, soft silicone.
<G-vec00095-002-s740><adjust.anpassen><de> Beschreibung Als Teil unseres Tauchzubehörs, dem Mundstück MP-400, verwenden herkömmliche Mundstücke ein extrem flexibles Material, um sich an die verschiedenen Konfigurationen von Zähnen und Backen anzupassen, die von unserem speziellen Design, dem weichen Silikon, verlangt werden.
<G-vec00095-002-s741><adjust.anpassen><en> Individual MDF product orders In order to adjust to individual needs of every client, we offer the possibility to order finishing materials of different kinds or non-standard products based on samples or technical drawings.
<G-vec00095-002-s741><adjust.anpassen><de> Um sich an die individuellen Bedürfnisse jedes Kunden anzupassen, bieten wir die Möglichkeit, unterschiedliche Arten von Fertigungselementen sowie untypischen Produkten – aufgrund von Mustern oder technischen Zeichnungen herzustellen.
<G-vec00095-002-s742><adjust.anpassen><en> Even so, many struggle to adjust to the rapidly changing media culture.
<G-vec00095-002-s742><adjust.anpassen><de> Dennoch fällt es vielen Medien schwer, sich an die sich rasch wandelnde Medienkultur anzupassen.
<G-vec00095-002-s743><adjust.anpassen><en> Elaphusa Hotel offers a wide selection of different experiences and services and tries to adjust fully to the needs and wishes of its guests.
<G-vec00095-002-s743><adjust.anpassen><de> Das Hotel Elaphusa bietet eine breite Palette verschiedenartiger Erlebnisse und Dienstleistungen und ist bemüht, sich den Bedürfnissen und Wünschen seiner Gäste anzupassen.
<G-vec00095-002-s744><adjust.anpassen><en> This design is stationary - it can not be moved or deployed anywhere if the hallway is converted, however, due to the variety of materials, it is always possible to change the exterior facade, to adjust absolutely to any style of the interior - be it classic or modern minimalism.
<G-vec00095-002-s744><adjust.anpassen><de> Dieses Design ist stationär - es kann nicht überall bewegt oder aufgestellt werden, wenn der Flur umgebaut wird, jedoch ist es aufgrund der Vielfalt der Materialien immer möglich, die Außenfassade zu ändern, um sich absolut jedem Stil des Interieurs anzupassen - sei es klassischer oder moderner Minimalismus.
<G-vec00095-002-s745><adjust.anpassen><en> Give the new siblings time to adjust.
<G-vec00095-002-s745><adjust.anpassen><de> Gib den neuen Geschwisterkindern Zeit sich anzupassen.
<G-vec00095-002-s746><adjust.anpassen><en> Handle with lug has possibility to adjust (2 levels), allows to individual personalisation to growth.
<G-vec00095-002-s746><adjust.anpassen><de> Griff mit Stollen hat die Möglichkeit, sich anzupassen (2 Stufen), ermöglicht individuelle Anpassung an das Wachstum.
<G-vec00095-002-s747><adjust.anpassen><en> Personality helps you to adjust Your personality helps you to "survive" and deal with the daily challenges surrounding you.
<G-vec00095-002-s747><adjust.anpassen><de> Die Persönlichkeit hilft Ihnen, sich anzupassen Ihre Persönlichkeit hilft Ihnen, zu überleben und die täglichen Herausforderungen zu meistern.
<G-vec00095-002-s748><adjust.anpassen><en> It is best to adjust while the feeler gauge is between.
<G-vec00095-002-s748><adjust.anpassen><de> Am besten ist es, sich anzupassen, während die Fühlerlehre zwischen beiden ist.
<G-vec00095-002-s749><adjust.anpassen><en> The European Union will adopt an integrated method of management to adjust to the characteristics of fisheries in the Mediterranean.
<G-vec00095-002-s749><adjust.anpassen><de> Die Europäische Union wird ein integriertes Bewirtschaftungskonzept verabschieden, um sich an die Merkmale der Mittelmeerfischerei anzupassen.
<G-vec00095-002-s750><adjust.anpassen><en> As with all new situations, it takes time to adjust.
<G-vec00095-002-s750><adjust.anpassen><de> Wie in allen neuen Situationen braucht man Zeit, sich anzupassen.
<G-vec00095-002-s787><adjust.anpassen><en> If you find that the temperature uniformity has to be changed from top to bottom, you simply adjust the ratio.
<G-vec00095-002-s787><adjust.anpassen><de> Wenn Sie feststellen, dass die Temperaturgleichmäßigkeit von oben nach unten verändert werden muss, dann können Sie dieses Verhältnis einfach anpassen.
<G-vec00095-002-s788><adjust.anpassen><en> It is possible to adjust these templates according to your specific needs. If required create custom forms, labels and reports by yourself.
<G-vec00095-002-s788><adjust.anpassen><de> GS1 Logistiklabels Natürlich können Sie diese Formulare an Ihre Anforderungen anpassen oder komplett neue Formulare, Labels und Etiketten selbst erstellen.
<G-vec00095-002-s789><adjust.anpassen><en> You will learn how to adjust your Prezi to different topics and what visual concept to choose in those cases.
<G-vec00095-002-s789><adjust.anpassen><de> Sie lernen, wie Sie Ihre Prezi an verschiedene Themen anpassen, und welche visuellen Konzepte man hierzu am Besten wählt.
<G-vec00095-002-s790><adjust.anpassen><en> Your advisory package and financial plan will have to adjust accordingly.
<G-vec00095-002-s790><adjust.anpassen><de> Entsprechend müssen Sie Ihr Beratungspaket und Ihre Vorsorge anpassen.
<G-vec00095-002-s791><adjust.anpassen><en> Proper nutrition Do not forget about how to adjust your diet for the time of illness.
<G-vec00095-002-s791><adjust.anpassen><de> Richtige Ernährung Vergessen Sie nicht, wie Sie Ihre Diät für die Zeit der Krankheit anpassen.
<G-vec00095-002-s792><adjust.anpassen><en> As the saying goes, the next opponent is always the hardest; you’ll need to maintain a constant overview of your competition and adjust your squad accordingly.
<G-vec00095-002-s792><adjust.anpassen><de> Da der nächste Gegner bekanntlich immer der schwerste ist, musst du deine Kontrahenten ständig im Blick behalten und deine Aufstellung auf sie anpassen.
<G-vec00095-002-s793><adjust.anpassen><en> The video shows how to adjust and save the size for a cappuccino.
<G-vec00095-002-s793><adjust.anpassen><de> In diesem Video wird gezeigt, wie Sie die Trinkmenge für einen Cappuccino anpassen und speichern.
<G-vec00095-002-s794><adjust.anpassen><en> If you use Auto Invest on Mintos and want to invest in new ID Finance loans issued in Spain, be sure to adjust your Auto Invest settings accordingly.
<G-vec00095-002-s794><adjust.anpassen><de> Wenn Sie Auto Invest auf Mintos verwenden und in die neuen ID Finance-Darlehen investieren möchten, die in Spanien ausgegeben werden, stellen Sie sicher, dass Sie Ihre Auto Invest-Einstellungen entsprechend anpassen.
<G-vec00095-002-s795><adjust.anpassen><en> Under Export options optionally adjust the Export accuracy.
<G-vec00095-002-s795><adjust.anpassen><de> Optional können Sie auf der Registerseite Exportoptionen die Exportgenauigkeit anpassen.
<G-vec00095-002-s796><adjust.anpassen><en> The player can adjust the width and the arc of their offensive line.
<G-vec00095-002-s796><adjust.anpassen><de> Sie können die Breite und den Bogen der Angriffslinie anpassen.
<G-vec00095-002-s797><adjust.anpassen><en> You may need to adjust the size of some callouts to fit the translated text.
<G-vec00095-002-s797><adjust.anpassen><de> Möglicherweise müssen Sie die Größe einiger Callouts an den übersetzten Text anpassen.
<G-vec00095-002-s798><adjust.anpassen><en> The cockring Marc Dorcel Adjust Ring is a cock ring that can easily be adapted to any size of penis.
<G-vec00095-002-s798><adjust.anpassen><de> Somit vermeiden Sie Pilze oder andere Infektionen.</p> Marc-Dorcel add-to-Ring ist ein Penisring, der sich leicht an alle Penisgrößen anpassen kann.
<G-vec00095-002-s799><adjust.anpassen><en> Have a base CV that you can adjust to each job you are applying for.
<G-vec00095-002-s799><adjust.anpassen><de> Haben Sie einen Basis-Lebenslauf, den Sie für jeden Job, für den Sie sich bewerben, anpassen können.
<G-vec00095-002-s800><adjust.anpassen><en> Use padding to adjust the spacing around the text inside the text box.
<G-vec00095-002-s800><adjust.anpassen><de> Verwenden Sie den Abstand, um den Abstand zwischen dem Text in das Textfeld anpassen.
<G-vec00095-002-s801><adjust.anpassen><en> ● Unique widely adaption technology: not only can realize detecting book clip, but also can make it detect super large cutter & prohibited item via adjust the sensitivity of the security gate in its panel setting menu.
<G-vec00095-002-s801><adjust.anpassen><de> ● Einzigartige weit verbreitete Technologie: Erkennt nicht nur die Erkennung von Buchclips, sondern kann auch super große Cutter und verbotene Objekte erkennen, indem Sie die Empfindlichkeit des Sicherheitsgates im Menü der Menüeinstellungen anpassen.
<G-vec00095-002-s802><adjust.anpassen><en> If you are using other modules, you must adjust points 8 and 10 in the Python script.
<G-vec00095-002-s802><adjust.anpassen><de> Wenn Sie andere Baugruppen verwenden, dann müssen Sie Punkte 8 und 10 im Python Skript anpassen.
<G-vec00095-002-s803><adjust.anpassen><en> You can easily adjust the roofing to the facade of the building and its surroundings.
<G-vec00095-002-s803><adjust.anpassen><de> Mit Leichtigkeit werden Sie die Bedachung der Gebäudefassade und seiner Umgebung anpassen.
<G-vec00095-002-s804><adjust.anpassen><en> If you're unsure of how to adjust these controls, check the manual for your monitor or the manufacturer's website.
<G-vec00095-002-s804><adjust.anpassen><de> Wenn Sie nicht sicher sind, wie Sie diese Steuerungen anpassen, finden Sie weitere Informationen in der Dokumentation des Monitors oder auf der Website des Herstellers.
<G-vec00095-002-s805><adjust.anpassen><en> To adjust the settings, go to Notification Emails settings.
<G-vec00095-002-s805><adjust.anpassen><de> Unter Einstellungen für E-Mail-Benachrichtigungen können Sie die Einstellungen anpassen.
<G-vec00095-002-s458><adjust.justieren><en> The benches dispose of a camera/monitoring-system to adjust the luminaires that they stand in the optical axis.
<G-vec00095-002-s458><adjust.justieren><de> Die Bänke verfügen über ein Kamera/Monitorsystem um die Leuchtmittel so zu justieren, dass sie in der optischen Achse stehen.
<G-vec00095-002-s459><adjust.justieren><en> This structure represents still another difficulty of the system, explains Christian Bichlmeier, scientist at the chair: „The Trackingsystem is very expensive and complex to adjust.“ How to integrate it in the operating room is another unresolved problem.
<G-vec00095-002-s459><adjust.justieren><de> Dieser Aufbau stellt noch eine Schwierigkeit des Systems dar, erklärt Christoph Bichlmeier, Mitarbeiter des Lehrstuhls: „Das Trackingsystem ist sehr teuer und aufwendig zu installieren und zu justieren.“ Wie es in den Operationssaal integriert werden soll, ist bislang noch ein ungelöstes Problem.
<G-vec00095-002-s460><adjust.justieren><en> “Corrective” is a good word – how much do start-ups, for example, help you adjust some of the courses REWE is on?
<G-vec00095-002-s460><adjust.justieren><de> Korrektiv ist ein gutes Stichwort – inwieweit helfen Ihnen Start-ups zum Beispiel, die eine oder andere Spur, auf der REWE unterwegs ist, zu justieren.
<G-vec00095-002-s461><adjust.justieren><en> A multi-turn 20Ký trim pot can also be used to adjust the output voltage up or down.
<G-vec00095-002-s461><adjust.justieren><de> Ein Multidrehung 20Ký Ordnungstopf kann auch benutzt werden, um die Ausgangsspannung auf oder ab zu justieren.
<G-vec00095-002-s462><adjust.justieren><en> When bottle size is changed, there is no need to adjust the transferring chain’s height.
<G-vec00095-002-s462><adjust.justieren><de> Wenn Flaschengröße geändert wird, gibt es keinen Bedarf, die Übertragungshöhe der Kette zu justieren.
<G-vec00095-002-s463><adjust.justieren><en> Curved triple connecting rod structure, easy to adjust.
<G-vec00095-002-s463><adjust.justieren><de> Gebogene dreifache Pleuelstangestruktur, einfach zu justieren.
<G-vec00095-002-s464><adjust.justieren><en> It can also adjust due to its plastic ball joint.
<G-vec00095-002-s464><adjust.justieren><de> Er kann wegen seines Plastikkugelgelenkes auch justieren.
<G-vec00095-002-s465><adjust.justieren><en> You can easily adjust the bag size and loop handle size.
<G-vec00095-002-s465><adjust.justieren><de> Sie können die Taschengröße und Schleifengriffgröße leicht justieren.
<G-vec00095-002-s466><adjust.justieren><en> Once the motor is being mounted, a technician must use a variety of tools to adjust it for proper belt tension and aligning.
<G-vec00095-002-s466><adjust.justieren><de> Nach der Motormontage muss ihn ein Techniker mit Hilfe verschiedener Werkzeuge für eine korrekte Riemenspannung und -ausrichtung justieren.
<G-vec00095-002-s467><adjust.justieren><en> We can adjust the shaping embossing device to make the sheet shaping well.
<G-vec00095-002-s467><adjust.justieren><de> Wir können das Formungsprägungsgerät justieren, um das Blatt zu machen, das gut formt.
<G-vec00095-002-s468><adjust.justieren><en> Do not hide, in order to surface treatment plane has passed safely, you need to accurately adjust the knife and properly move the tool on the work surface.
<G-vec00095-002-s468><adjust.justieren><de> Verstecke dich nicht, um die Oberflächenbehandlung sicher passieren zu können, musst du das Messer genau justieren und das Werkzeug richtig auf der Arbeitsfläche bewegen.
<G-vec00095-002-s469><adjust.justieren><en> The trick is to adjust the balance, within one's own company, between those two worlds.
<G-vec00095-002-s469><adjust.justieren><de> Die Kunst des Managers besteht letztlich darin, die Balance zwischen beiden Welten im Unternehmen zu justieren.
<G-vec00095-002-s470><adjust.justieren><en> Moreover, the light-weight structure enables the event tent to adjust to almost every kind of ground so that you can save a lot in dealing with the ground.
<G-vec00095-002-s470><adjust.justieren><de> Außerdem ermöglicht die leichte Struktur dem Ereigniszelt, auf fast jede Art Boden zu justieren, damit Sie im Umgang mit dem Boden viel speichern können.
<G-vec00095-002-s471><adjust.justieren><en> With a photo-editing app, you can enhance, rotate, and crop an image, tweak its perspective, and adjust its brightness and colors.
<G-vec00095-002-s471><adjust.justieren><de> Mit einer Foto-redigierenden APP können Sie ein Bild erhöhen, drehen und ernten, seine Perspektive zwicken und sein Brightness und Farben justieren.
<G-vec00095-002-s472><adjust.justieren><en> The users can adjust the slider on the side of the adapter to get different output voltage 12/15/16/18/19/20/22/24VDC.
<G-vec00095-002-s472><adjust.justieren><de> Die Benutzer können den Schieber auf der Seite des Adapters justieren, um unterschiedliche Ausgangsspannung 12/15/16/18/19/20/22/24VDC zu erhalten.
<G-vec00095-002-s473><adjust.justieren><en> Louver curtain ventilated air permeability is good, can adjust indoor illumination intensity, especially applicable to concise and lively indoor space.
<G-vec00095-002-s473><adjust.justieren><de> Luftdurchlässigkeit des Jalousienvorhangs ist gut, kann Innenbeleuchtungsintensität justieren, besonders anwendbar auf prägnanten und lebhaften Innenraum.
<G-vec00095-002-s474><adjust.justieren><en> We research, develop and adjust.
<G-vec00095-002-s474><adjust.justieren><de> Wir forschen, entwickeln und justieren.
<G-vec00095-002-s475><adjust.justieren><en> You can adjust each color to be dim or bright.
<G-vec00095-002-s475><adjust.justieren><de> Sie können die Farbe justieren.
<G-vec00095-002-s476><adjust.justieren><en> Benchmarking helps you to better classify your product ideas and to precisely adjust the yardstick for future developments.
<G-vec00095-002-s476><adjust.justieren><de> Benchmarking hilft Ihnen, Ihre Produktideen besser einzuordnen und die Messlatte für zukünftige Entwicklungen exakt zu justieren.
<G-vec00095-002-s496><adjust.korrigieren><en> I had to look within and adjust myself.
<G-vec00095-002-s496><adjust.korrigieren><de> Ich musste nach innen schauen und mich korrigieren.
<G-vec00095-002-s497><adjust.korrigieren><en> You should also check the volume level in the sound mixer and adjust it if necessary.
<G-vec00095-002-s497><adjust.korrigieren><de> Überprüfen Sie auch den eingestellten Lautstärkepegel im Sound-Mixer und korrigieren Sie gegebenenfalls.
<G-vec00095-002-s498><adjust.korrigieren><en> We will adjust the exposure, crop the photos and all in all improve the quality of your images.
<G-vec00095-002-s498><adjust.korrigieren><de> Wir korrigieren, setzen Ausschnitte, verbessern die Qualität in vielen Punkten und geben euren Bildern die coolsten Effekte auf dem Planeten.
<G-vec00095-002-s499><adjust.korrigieren><en> EGNOS, a joint project of the ESA, the European Commission and Eurocontrol, consists of a network of around 40 ground stations scattered throughout Europe designed to record, adjust and improve data from the American system GPS.
<G-vec00095-002-s499><adjust.korrigieren><de> EGNOS, ist ein gemeinsames Projekt der ESA, der Europäischen Kommission und Eurocontrol und besteht aus einem Netzwerk von rund 40 in Europa verteilten Bodenstationen, die die Daten des US-amerikanischen GPS-Systems aufzeichnen, korrigieren und verbessern.
<G-vec00095-002-s500><adjust.korrigieren><en> Small object fields of view are often observed by means of long focal length lenses equipped with an additional spacer, used to adjust the working distance.
<G-vec00095-002-s500><adjust.korrigieren><de> Kleine Objektfelder erfordern häufig Objektive mit langen Brennweiten, die mit einem zusätzlichen Abstandshalter ausgestattet sind, um den jeweiligen Arbeitsabstand zu korrigieren.
<G-vec00095-002-s501><adjust.korrigieren><en> We reserve the right to adjust margin requirements for each of our products.
<G-vec00095-002-s501><adjust.korrigieren><de> Wir behalten uns das Recht vor, die Marginanforderung für jedes unserer Produkte zu korrigieren.
<G-vec00095-002-s502><adjust.korrigieren><en> Moreover, you can monitor the progress of your employee and adjust the knowledge base if necessary.
<G-vec00095-002-s502><adjust.korrigieren><de> Darüber hinaus können Sie den Fortschritt Ihrer Mitarbeiter überwachen und eventuell korrigieren.
<G-vec00095-002-s503><adjust.korrigieren><en> In order to achieve the perfect result, you need to manually adjust the exposure.
<G-vec00095-002-s503><adjust.korrigieren><de> Um das perfekte Resultat zu erzielen müssen Sie die Belichtung manuell korrigieren.
<G-vec00095-002-s504><adjust.korrigieren><en> At some stations it might be better to change trains and adjust your destination, in order to take your own, personal route.
<G-vec00095-002-s504><adjust.korrigieren><de> An manchen Stationen ist es vielleicht besser, umzusteigen und sein Reiseziel zu korrigieren, um einen anderen, eigenen Weg einschlagen zu können.
<G-vec00095-002-s505><adjust.korrigieren><en> Every time I go out to conduct an interview, I try to study the Fa, adjust my mind, and send forth righteous thoughts to clear the field.
<G-vec00095-002-s505><adjust.korrigieren><de> Jedes Mal, wenn ich ein Interview führe, versuche ich zuvor, das Fa zu lernen, meinen Geist zu korrigieren und aufrichtige Gedanken auszusenden, um das Feld zu reinigen.
<G-vec00095-002-s506><adjust.korrigieren><en> (4) Any typing errors in placing the order can identify the customer in the final confirmation before checkout and adjust using the delete and change function as well by pressing the "Back" function of the Internet browser before sending the order at any time.
<G-vec00095-002-s506><adjust.korrigieren><de> (4) Etwaige Eingabefehler bei Abgabe der Bestellung kann der Kunde bei der abschließenden Bestätigung vor der Kasse erkennen und mit Hilfe der Lösch- und Änderungsfunktion sowie durch Betätigen der „Zurück-Funktion“ des Internet-Browsers vor Absendung der Bestellung jederzeit korrigieren.
<G-vec00095-002-s507><adjust.korrigieren><en> An innovative system based on a patented mechanism enables the user, when changing timezone, to adjust all the indications in one smooth and easy move by simply turning the crown.
<G-vec00095-002-s507><adjust.korrigieren><de> Ein innovatives System mit einem patentierten Mechanismus ermöglicht es Reisenden, bei einem Zeitzonenwechsel durch Drehen der Krone sämtliche Anzeigen einfach und im Handumdrehen zu korrigieren.
<G-vec00095-002-s508><adjust.korrigieren><en> The mirror is used until the patients are capable to adjust their lateral body orientation without its help.
<G-vec00095-002-s508><adjust.korrigieren><de> Er wird so lange eingesetzt, bis die Patienten und Patientinnen in der Lage sind, auch ohne Spiegel ihre Körperlängsachse zu korrigieren.
<G-vec00095-002-s509><adjust.korrigieren><en> After playing the script you can adjust the shadow position by nudging or deforming the "Text's shadow" layer.
<G-vec00095-002-s509><adjust.korrigieren><de> Nach Anwendung des Skriptes kann man die Lage des Schattens korrigieren, indem man die vom Skript erstellte Ebene „Text's shadow“ verschiebt.
<G-vec00095-002-s510><adjust.korrigieren><en> 2 Press the joystick up, down, left or right to adjust the display position.
<G-vec00095-002-s510><adjust.korrigieren><de> 2 Drücken Sie den Joystick nach oben, unten, links oder rechts um die Anzeigeposition zu korrigieren.
<G-vec00095-002-s511><adjust.korrigieren><en> You understand that you, depending on weather, traffic or any other circumstance, uncertainty or other factors, must adjust, adapt and calculate Your speed, riding behavior and braking distance.
<G-vec00095-002-s511><adjust.korrigieren><de> Sie verstehen, dass Sie Ihre Geschwindigkeit, Ihr Fahrverhalten und Ihren Bremsweg in Abhängigkeit von Wetter, Verkehr oder anderen Umständen, Unsicherheiten oder anderen Faktoren korrigieren, anpassen und berechnen müssen.
<G-vec00095-002-s512><adjust.korrigieren><en> Then we could just adjust the shading and everything else as we wanted to.
<G-vec00095-002-s512><adjust.korrigieren><de> Danach konnten wir einfach die Schattierungen korrigieren und natürlich alles, was wir sonst noch wollten.
<G-vec00095-002-s513><adjust.korrigieren><en> You can remove them later or adjust the quantities if you change your mind.
<G-vec00095-002-s513><adjust.korrigieren><de> Sie können jederzeit Ihre Waren entfernen oder die Anzahl korrigieren.
<G-vec00095-002-s514><adjust.korrigieren><en> Notes [1] Adaptive optics systems rapidly adjust a deformable mirror to counteract the distorting effect of atmospheric turbulence — the same effect that makes stars twinkle — in real time.
<G-vec00095-002-s514><adjust.korrigieren><de> [1] Adaptive Optik nutzt einen schnell verformbaren Spiegel, um die durch atmosphärische Turbulenzen verursachten Bildstörungen – derselbee Effekt verursacht auch das Funkeln der Sterne – in Echtzeit zu korrigieren.
<G-vec00095-002-s900><adjust.verändern><en> As we need a rather big function here, we need to adjust some settings of the Power Fractal.
<G-vec00095-002-s900><adjust.verändern><de> Da wir hier eine recht große Funktion benötigen, müssen wir noch einige Einstellungen des Power Fractals verändern.
<G-vec00095-002-s901><adjust.verändern><en> The intuitive GUI offers direct access to all important parameters, required to adjust the reverb to your taste.
<G-vec00095-002-s901><adjust.verändern><de> Die intuitive GUI gibt Ihnen direkten Zugriff auf die wichtigsten Parameter, die Sie brauchen, um die Presets nach Ihren Wünschen zu verändern.
<G-vec00095-002-s902><adjust.verändern><en> In your admin panel, you can adjust the widget individually, check the statistics, and call up credit notes.
<G-vec00095-002-s902><adjust.verändern><de> In Ihrem Administrator-Bereich verändern Sie Ihr Widget individuell, sehen die Statistik ein und rufen Gutschriften auf.
<G-vec00095-002-s903><adjust.verändern><en> You will usually adjust their values using the knobs located below.
<G-vec00095-002-s903><adjust.verändern><de> Meist werden Sie deren Werte mit den darunter liegenden Reglern verändern.
<G-vec00095-002-s904><adjust.verändern><en> You can also drag the existing tab-stops around to adjust the tab positions, or drag them out to remove them.
<G-vec00095-002-s904><adjust.verändern><de> Sie können ebenso die schon existierenden Tab-Stops im Lineal verschieben, um die Tabulator-Positionen zu verändern, oder ziehen Sie Tabulatoren aus dem Lineal heraus, um sie zu entfernen.
<G-vec00095-002-s905><adjust.verändern><en> Hinge X 8 40x40, heavy-duty with Clamp Lever allows you to adjust the angle of connection in a matter of seconds.
<G-vec00095-002-s905><adjust.verändern><de> Mit dem Gelenk X 8 40x40 mit Klemmhebel verändern Sie den Winkel innerhalb weniger Sekunden.
<G-vec00095-002-s906><adjust.verändern><en> You can adjust your personal privacy settings in the settings of your Google account.
<G-vec00095-002-s906><adjust.verändern><de> Dort können Sie im Datenschutzcenter auch Ihre persönlichen Datenschutz-Einstellungen verändern.
<G-vec00095-002-s907><adjust.verändern><en> You can adjust the settings in such a way that the cookies are blocked or you are informed when cookies are sent to your device.
<G-vec00095-002-s907><adjust.verändern><de> Sie können die Einstellungen so verändern, dass Cookies blockiert werden oder Sie informiert werden, wenn Cookies an Ihr Gerät gesendet werden.
<G-vec00095-002-s908><adjust.verändern><en> This way I can go to extremes, adjust the angles until it holds and in doing so, explore the vocabulary of form.
<G-vec00095-002-s908><adjust.verändern><de> So kann ich ins Extreme gehen, die Winkel verändern, bis das Ganze gerade noch steht, und das Formenvokabular ausreizen.
<G-vec00095-002-s909><adjust.verändern><en> You'll be able to control the anti-squat and anti-dive of the front and rear arms using the standard pivot blocks, and the option parts allow you to adjust the sweep and toe angles.
<G-vec00095-002-s909><adjust.verändern><de> Sie können den Anti-Squat und den Anti-Dive an der Vorder- und Hinterachse kontrollieren, indem Sie die Standard Spurblöcke verwenden oder mittels den erhältlichen Tuning Spurblöcken auch den Spurwinkel der Achsschwingen verändern.
<G-vec00095-002-s910><adjust.verändern><en> You cannot adjust the sensor threshold values in a small monitoring panel.
<G-vec00095-002-s910><adjust.verändern><de> In einem kleinen Überwachungspanel können Sie die Sensorgrenzwerte nicht verändern.
<G-vec00095-002-s911><adjust.verändern><en> Victims of sexual harassment will feel less safe and often have to adjust their travel routes and schedules in order to avoid certain times of the day (especially late at night) or certain places (near bars, colleges, and restaurants) where sexual harassment is a frequent occurrence.
<G-vec00095-002-s911><adjust.verändern><de> Opfer sexueller Belästigung fühlen sich weniger sicher und müssen oft ihre Wege und Zeitpläne verändern, um bestimmte Orte (wie Bars, Unis und Restaurants) zu gewissen Zeiten (besonders spätnachts) zu vermeiden, da sexuelle Belästigung vermehrt dort auftritt.
<G-vec00095-002-s912><adjust.verändern><en> Use the a>z in the menu to adjust the sort order of the item list.
<G-vec00095-002-s912><adjust.verändern><de> Benutzen Sie a>z im Menü, um die Sortierungsreihenfolge der Artikelliste zu verändern.
<G-vec00095-002-s913><adjust.verändern><en> This allows videographers to adjust settings silently during filming.
<G-vec00095-002-s913><adjust.verändern><de> Hier können Filmer während der Aufnahme Einstellungen geräuschlos verändern.
<G-vec00095-002-s914><adjust.verändern><en> As every Club offers a different range of membership types it could be necessary to adjust these options.
<G-vec00095-002-s914><adjust.verändern><de> Da jeder Club über einen anderen Status verfügt, kann es gegebenenfalls nötig sein, die vordefinierten Möglichkeiten zu verändern.
<G-vec00095-002-s915><adjust.verändern><en> Settings Adjust datasource, datasink, open policy, read policy, main screen settings and bi-directional communication options.
<G-vec00095-002-s915><adjust.verändern><de> Verändern der Datenquelle, Datensenke, Verbindungsherstellung, Datenempfang, Hauptbildschirm-Optionen und bidirektionale Kommunikationsoptionen.
<G-vec00095-002-s916><adjust.verändern><en> One can now try to adjust the momentum equation so that plausible human behavior is approximated.
<G-vec00095-002-s916><adjust.verändern><de> Man kann nun versuchen die Impulsgleichung so zu verändern dass damit plausibles menschliches Verhalten angenähert wird.
<G-vec00095-002-s917><adjust.verändern><en> In order to measure, adjust and improve how your organisation works, it’s important to be as scientific as possible.
<G-vec00095-002-s917><adjust.verändern><de> Eine wissenschaftliche Herangehensweise ist essenziell, um Ihre Organisation zu verstehen, zu verändern und zu verbessern.
<G-vec00095-002-s918><adjust.verändern><en> You can adjust the speed of video playback.
<G-vec00095-002-s918><adjust.verändern><de> Sie können die Geschwindigkeit der Videowiedergabe verändern.
<G-vec00095-002-s936><adjust.ändern><en> Username Email You may adjust your notification preferences at any time
<G-vec00095-002-s936><adjust.ändern><de> Sie können Ihre Cookie-Einstellung jederzeit hier ändern: Datenschutz.
<G-vec00095-002-s937><adjust.ändern><en> This will allow you to adjust things like volume without affecting the video.
<G-vec00095-002-s937><adjust.ändern><de> So kannst du beispielsweise die Lautstärke nachjustieren, ohne gleich das ganze Video ändern zu müssen.
<G-vec00095-002-s938><adjust.ändern><en> Intuitive operation: the large, easy-to-read LCD screen and conveniently placed controls make it easy to adjust settings.
<G-vec00095-002-s938><adjust.ändern><de> Intuitive Bedienung: Durch den großen, gut ablesbaren LCD-Monitor und die praktisch angeordneten Bedienelemente können Sie die Einstellungen ganz leicht ändern.
<G-vec00095-002-s939><adjust.ändern><en> You can adjust the editing permissions granted to members of the shared folder of the file you're working on using the Dropbox badge.
<G-vec00095-002-s939><adjust.ändern><de> Auf einigen Rechnern können Sie den Eigentümer eines freigegebenen Ordners über die Desktop-App von Dropbox ändern.
<G-vec00095-002-s940><adjust.ändern><en> • Protection designed for work at height and on the ground: - DUAL chinstrap allows the worker to adjust chinstrap strength in order to adapt the helmet to different environments: work at height (EN 12492) or on the ground (EN 397).
<G-vec00095-002-s940><adjust.ändern><de> Kopfschutz geeignet zum Arbeiten in der Höhe und am Boden bei Tag und Nacht: - Das DUAL-Kinnband bietet dem Benutzer die Möglichkeit, die Haltekraft des Kinnbands zu ändern, um den Helm unterschiedlichen Arbeitssituationen anzupassen: Arbeiten in der Höhe (EN 12492) und Arbeiten am Boden (EN 397).
<G-vec00095-002-s941><adjust.ändern><en> Key Points: Only team admins can adjust default sharing rules.
<G-vec00095-002-s941><adjust.ändern><de> Wichtig: Nur Team-Administratoren können Standard-Freigabeberechtigungen ändern.
<G-vec00095-002-s942><adjust.ändern><en> Each quarter, the banks check the LIBOR rate and may adjust the customer rate accordingly (customer margin + LIBOR rate = customer rate).
<G-vec00095-002-s942><adjust.ändern><de> Jedes Quartal wird geschaut wo der LIBOR-Satz steht, demzufolge kann sich der Kundenzins jedes Quartal ändern (Kundenmarge + LIBOR-Satz = Kundenzins).
<G-vec00095-002-s943><adjust.ändern><en> You can adjust your targets for all future days/weeks or only for the current period.
<G-vec00095-002-s943><adjust.ändern><de> Du kannst deine Ziel-Vorgabe entweder für alle zukünftigen Tage/Wochen ändern oder nur für den gerade aktuellen Zeitraum.
<G-vec00095-002-s944><adjust.ändern><en> You can adjust all the settings: make the hatching denser or finer, change the pitch angle of strokes, choose the pencil color, etc.
<G-vec00095-002-s944><adjust.ändern><de> Sie können die Intensität der Schraffierung ändern, die Linien feiner machen, der Winkel der Striche festlegen, Ausgangsfarben hinzufügen/entfernen.
<G-vec00095-002-s945><adjust.ändern><en> The seller reserves the right to adjust its prices periodically.
<G-vec00095-002-s945><adjust.ändern><de> 2.2 Der Verkäufer behält sich das Recht vor, die Preise periodisch zu ändern.
<G-vec00095-002-s946><adjust.ändern><en> If it happens that a meeting takes longer than expected, I can easily adjust the auto-generated booking in time cockpit’s calendar using drag and drop.
<G-vec00095-002-s946><adjust.ändern><de> Wenn ein Meeting länger dauert als erwartet, kann ich die Zeitbuchung im Kalender einfach mit Drag & Drop ändern.
<G-vec00095-002-s947><adjust.ändern><en> We reserve the right to adjust prices, offers, goods and specifications of goods on the Website at our discretion at any time before (but not after) we accept your order.
<G-vec00095-002-s947><adjust.ändern><de> Wir behalten uns das Recht vor, Preise, Angebote, Produkte und Produktbeschreibungen auf unserer Website nach unserem Ermessen zu jeder Zeit zu ändern.
<G-vec00095-002-s948><adjust.ändern><en> However, some of these quests were tied behind other quests, so we would like to adjust these when we have the opportunity.
<G-vec00095-002-s948><adjust.ändern><de> Aber an manche dieser Aufträge kommt man erst, wenn man vorher andere Aufträge abgeschlossen hat, und wir würden das gerne ändern, sobald wir die Möglichkeit dazu haben.
<G-vec00095-002-s949><adjust.ändern><en> Please note that once you have submitted your credit card details to bid for an upgrade, you will not be required to re-enter those credit card details if you wish to adjust the bid amount at a later stage.
<G-vec00095-002-s949><adjust.ändern><de> Bitte beachten Sie, dass Sie nach der Angabe Ihrer Kreditkartendaten beim Upgrade-Angebot diese Informationen nicht erneut angeben müssen, wenn Sie die Angebotssumme zu einem späteren Zeitpunkt ändern wollen.
<G-vec00095-002-s950><adjust.ändern><en> If you want to adjust your privacy preferences on your mobile device, please see How to Access, Update and Manage Your Information.
<G-vec00095-002-s950><adjust.ändern><de> Wenn du die Privatsphäreeinstellungen deines Mobilgeräts ändern möchtest, lies bitte unter Abruf, Aktualisierung und Verwaltung deiner Daten nach.
<G-vec00095-002-s951><adjust.ändern><en> They could make a reservation, but were not able to adjust it online.
<G-vec00095-002-s951><adjust.ändern><de> Damit konnten sie Reservierungen vornehmen, aber online nichts ändern.
<G-vec00095-002-s952><adjust.ändern><en> You may feel that you are speaking artificially slowly, but you should be able to adjust the speed later by using your audio recording software.
<G-vec00095-002-s952><adjust.ändern><de> Sie haben vielleicht das Gefühl, dass Sie unnatürlich langsam sprechen, Sie können die Geschwindigkeit mit Ihrer Audio-Aufzeichnungssoftware später jedoch noch ändern.
<G-vec00095-002-s953><adjust.ändern><en> The employer can unilaterally adjust this retirement age during the course of the agreement based on the general rules governing the statutory retirement age.
<G-vec00095-002-s953><adjust.ändern><de> Der Versicherer kann dieses Pensionsalter im Laufe eines Vertrags aufgrund der allgemeinen Regeln über das gesetzliche Pensionsalter einseitig ändern.
<G-vec00095-002-s954><adjust.ändern><en> Of course you can adjust this composition according to your preferences.
<G-vec00095-002-s954><adjust.ändern><de> Sie können diese Zusammensetzung natürlich nach Ihren Vorstellungen ändern.
<G-vec00696-002-s019><adjust.abstimmen><en> For retailers, for example, we have eye-catching secondary placements and other solutions available, which we will gladly adjust to meet your individual needs.
<G-vec00696-002-s019><adjust.abstimmen><de> Für den Einzelhandel stehen Ihnen zum Beispiel aufmerksamkeitsstarke Zweitplatzierungen und weitere Maßnahmen zur Verfügung, die wir gerne kundenindividuell mit Ihnen abstimmen.
<G-vec00696-002-s020><adjust.abstimmen><en> We can therefore adjust the content of our websites tailored to your requirements, and thus improve our site for you.
<G-vec00696-002-s020><adjust.abstimmen><de> So können wir die Inhalte unserer Internetseiten gezielter auf Ihre Bedürfnisse abstimmen und somit unser Angebot für Sie verbessern.
<G-vec00696-002-s021><adjust.abstimmen><en> We promise this because we know your needs and expectations and adjust every step of the selection process accordingly.
<G-vec00696-002-s021><adjust.abstimmen><de> Wir machen Ihnen dieses Versprechen, weil wir Ihre Bedürfnisse und Erwartungen kennen und jeden Schritt im Auswahlprozess darauf abstimmen.
<G-vec00696-002-s023><adjust.abstimmen><en> They can also adjust the speed between various boom parts or change it by using the extension boom manually during operation.
<G-vec00696-002-s023><adjust.abstimmen><de> Er kann außerdem die Geschwindigkeiten der einzelnen Krankomponenten abstimmen oder ändern, indem er den Teleskopausschub während des Arbeitsgangs von Hand steuert.
<G-vec00696-002-s024><adjust.abstimmen><en> You can adjust the amount of coverage to your needs.
<G-vec00696-002-s024><adjust.abstimmen><de> Sie können die Abdeckung auf Ihre Bedürfnisse abstimmen.
<G-vec00696-002-s025><adjust.abstimmen><en> You can adjust the ambience to any occasion: a big party, an intimate dinner or a moment of relaxation on a late summer night.
<G-vec00696-002-s025><adjust.abstimmen><de> Du kannst das Ambiente auf jeden Anlass abstimmen: ein großes Fest, ein romantisches Abendessen oder ein lauschiger Sommerabend.
<G-vec00696-002-s026><adjust.abstimmen><en> Full Flexibility With private lessons you are not bound to specific time tables and you can also adjust your schedule to your work and free time.
<G-vec00696-002-s026><adjust.abstimmen><de> Im Einzelunterricht bist Du außerdem nicht an Kurszeiten gebunden, damit Du den Unterricht flexibel auf Deine Arbeit und Freizeit abstimmen kannst.
<G-vec00696-002-s027><adjust.abstimmen><en> These flash together, achieving greater overall visibility, and they use tricks that allow them to continuously adjust to each other.
<G-vec00696-002-s027><adjust.abstimmen><de> Diese blinken gemeinsam, um in Summe sichtbarer zu sein und verwenden Tricks, die es ermöglichen, dass sie sich immer wieder aufeinander abstimmen.
<G-vec00696-002-s028><adjust.abstimmen><en> They have to take on global responsibility and adjust politics to ensure the well-being of all people.
<G-vec00696-002-s028><adjust.abstimmen><de> Sie sollte global Verantwortung übernehmen und eine Politik zum Wohle aller Menschen abstimmen.
<G-vec00696-002-s029><adjust.abstimmen><en> We take the theory and immediately put it into practice, so we can adjust the training to your needs and your negotiation experience and language skills.
<G-vec00696-002-s029><adjust.abstimmen><de> Theoretische Kompetenzen werden somit direkt in die Praxis umgesetzt, so dass wir das Training ganz auf Ihre Anforderungen, Ihre Verhandlungserfahrung sowie Ihre Sprachkenntnisse abstimmen können.
<G-vec00696-002-s030><adjust.abstimmen><en> As a result, we can adjust the content of our website to the requirements of our users in a targeted manner and optimise what we have on offer.
<G-vec00696-002-s030><adjust.abstimmen><de> In der Folge können wir die Inhalte unserer Webseite gezielter auf die Bedürfnisse unserer Nutzer abstimmen und unser Angebot optimieren.
<G-vec00696-002-s031><adjust.abstimmen><en> With this information, Quality Stores Online B.V. is able to adjust the site and services to the requirements of the users.
<G-vec00696-002-s031><adjust.abstimmen><de> Mit diesen Informationen kann Quality Stores Online B.V. die Seite und Dienste auf die Wünsche der Benutzer abstimmen.
<G-vec00696-002-s032><adjust.abstimmen><en> With the extensively adjustable damper setup, you can precisely adjust the driving behavior of your car, no matter if sporty tight or on request with increased residual driving comfort.
<G-vec00696-002-s032><adjust.abstimmen><de> Mit dem umfangreich einstellbaren Dämpfersetup kannst Du das Fahrverhalten Deines Fahrzeugs präzise abstimmen, egal ob sortlich straff oder auf Wunsch mit gesteigertem Restfahrkomfort.
<G-vec00696-002-s033><adjust.abstimmen><en> With this plugin you can customize the appearance of your blog and adjust it to your shop design.
<G-vec00696-002-s033><adjust.abstimmen><de> Mit diesem Plugin können Sie die Darstellung Ihres Blogs anpassen und auf Ihren Shop abstimmen.
<G-vec00696-002-s316><adjust.einstellen><en> More information: With the absence of ribs, either the inner or outer ring will move freely so as to adjust to axial movement hence can be used as free side bearings.
<G-vec00696-002-s316><adjust.einstellen><de> Bei Abwesenheit von Rippen wird sich entweder der innere oder äußere Ring frei bewegen, um sich auf die axiale Bewegung einzustellen, kann daher als freie Seitenlager verwendet werden.
<G-vec00696-002-s317><adjust.einstellen><en> Move lever forward or back to adjust height.
<G-vec00696-002-s317><adjust.einstellen><de> Bewegen Sie den Hebel vor und zurück, um die Höhe einzustellen.
<G-vec00696-002-s318><adjust.einstellen><en> Select Mode to adjust touch screen display according to time of day.
<G-vec00696-002-s318><adjust.einstellen><de> Wählen Sie Modus, um die Anzeige der Tageszeit gemäß einzustellen.
<G-vec00696-002-s319><adjust.einstellen><en> Before diving into the red paddling pool, you'll use the mouse to adjust flight direction and the tank pressure.
<G-vec00696-002-s319><adjust.einstellen><de> Bevor Sie in das rote Planschbecken eintauchen, verwenden Sie die Maus, um die Flugrichtung und den Druck des Tankes einzustellen.
<G-vec00696-002-s320><adjust.einstellen><en> The young musicians will be prepared for upcoming auditions through the study of the required literature for particular orchestral positions and by learning to adjust mentally for the extreme conditions of the audition setting.
<G-vec00696-002-s320><adjust.einstellen><de> Auf bevorstehende Probespiele werden die jungen Musikerinnen und Musiker vorbereitet, indem sie die geforderte Literatur, speziell die Orchesterstellen, einstudieren und sich mental auf die extremen Bedingungen der Probespiel-Situation einzustellen lernen.
<G-vec00696-002-s321><adjust.einstellen><en> Use provided click gear washers to adjust spool height on the reel.
<G-vec00696-002-s321><adjust.einstellen><de> Verwenden Sie die mitgelieferten Klickradscheiben, um die Spulenhöhe auf der Spule einzustellen.
<G-vec00696-002-s322><adjust.einstellen><en> Beautifully small and lightweight, one of the defining characteristics that set this vaporizer apart is the ability to adjust the LED’s and vape temperature via an app.
<G-vec00696-002-s322><adjust.einstellen><de> Wunderschön klein und leichtgewichtig, ist eine der entscheidenden Eigenschaften, die diesen Vaporizer auszeichnen, die Möglichkeit, die LEDs und die Vape-Temperatur über eine App einzustellen.
<G-vec00696-002-s323><adjust.einstellen><en> The user is able to adjust the height directly at the stand via the display of the control unit or by the remote control via the Desk Control smartphone app.
<G-vec00696-002-s323><adjust.einstellen><de> Der Anwender hat die Möglichkeit, die Höhe direkt am Tisch über das Display der Steuereinheit oder per Fernbedienung über die Smartphone-App „Desk Control“ einzustellen.
<G-vec00696-002-s324><adjust.einstellen><en> Minute flashing, press UP and DOWN to adjust minute (press and hold UP and DOWN will quickly adjust), press MODE to confirm.
<G-vec00696-002-s324><adjust.einstellen><de> Minute blinkt, drücken Sie UP und DOWN, um die Minuten einzustellen (drücken und halten Sie UP und DOWN, um schnell zu justieren), drücken Sie zur Bestätigung MODE.
<G-vec00696-002-s325><adjust.einstellen><en> Easily switch on/off your flashlight, wifi, rotation lock or adjust your screen’s brightness.
<G-vec00696-002-s325><adjust.einstellen><de> Es wird sehr einfach deine Taschenlampe, Wifi und Drehsperre ein- oder auszuschalten oder die Helligkeit des Bildschirms einzustellen.
<G-vec00696-002-s326><adjust.einstellen><en> Move your mouse to adjust the angle and power.
<G-vec00696-002-s326><adjust.einstellen><de> Bewegen Sie die Maus, um den Winkel und die Kraft einzustellen.
<G-vec00696-002-s327><adjust.einstellen><en> And with Signia’s useful touchControl App, you can discreetly adjust volume and the balance between the sound from your left and right with just a few taps on your smartphone.
<G-vec00696-002-s327><adjust.einstellen><de> Es ermöglicht dem Träger, die CROS-Lautstärke und die binaurale Balance mit nur wenigen Klicks am Smartphone einzustellen.
<G-vec00696-002-s328><adjust.einstellen><en> It is only necessary to press a few buttons to move the RL 200 SF to the transport or operating position or adjust the height of the pickup table, the feed or the speed of all drums and belts with the operating menu.
<G-vec00696-002-s328><adjust.einstellen><de> Wenige Tastendrucke genügen, um den RL 200 SF zum Beispiel von der Transport- in die Arbeitsstellung zu bringen oder im Arbeitsmenü die Höhe des Aufnahmetisches, den Vorschub oder die Drehzahlen aller Walzen und Bänder einzustellen.
<G-vec00696-002-s329><adjust.einstellen><en> 1) Click the Video Source tab to adjust Image Size for TV, AV, S-Video, Component, DVI(HDCP), HDMI, DTV.
<G-vec00696-002-s329><adjust.einstellen><de> 1) Klicken Sie auf die Registerkarte Video Source (Videoquelle), um die Bildgröße für TV, AV, S-Video, Component, HDMI und DTV einzustellen.
<G-vec00696-002-s330><adjust.einstellen><en> Oil lubrication systems let you adjust lubricant dispensing accurately and impeccably for each point, even lowering the temperature of the bearing or lubricated air.
<G-vec00696-002-s330><adjust.einstellen><de> Die Ölschmiersysteme ermöglichen es, die Schmierstoffabgabe für jede Stelle präzise und einwandfrei einzustellen, wodurch auch die Temperatur des Lagers oder der geschmierten Luft gesenkt wird.
<G-vec00696-002-s331><adjust.einstellen><en> Click Adjust Spacing to adjust the Cells per line and Lines per Box values based on your changes to the Line Space and Character Space fields.
<G-vec00696-002-s331><adjust.einstellen><de> Klicken Sie auf Abstände einstellen, um die Werte für Zellen je Zeile und Zeilen je Seite auf der Basis Ihrer Änderungen in den Feldern Zeilenabstand und Zeichenabstand einzustellen.
<G-vec00696-002-s332><adjust.einstellen><en> Here are the steps you need to follow in order to adjust the “Monthly Volume Allowed” per sub-account:
<G-vec00696-002-s332><adjust.einstellen><de> Hier sind die Schritte die Sie kennen müssen um das „Monatliche erlaubte Volumen“ per Unterkonto einzustellen.
<G-vec00696-002-s333><adjust.einstellen><en> Hours flashing, Press UP and DOWN to adjust hour (press and hold UP and DOWN will quickly adjust), press MODE to confirm.
<G-vec00696-002-s333><adjust.einstellen><de> Stunden blinken, drücken Sie UP und DOWN, um die Stunde einzustellen (drücken und halten Sie UP und DOWN, um sich schnell einzustellen), drücken Sie zur Bestätigung MODE.
<G-vec00696-002-s334><adjust.einstellen><en> There are settings for daylight, fluorescent lighting and light bulb, but you can also adjust the white balance manually.
<G-vec00696-002-s334><adjust.einstellen><de> Neben den Einstellungen Tageslicht, TL und Kunstlicht, gibt es zugleich die Möglichkeit den Weißabgleich manuell einzustellen.
<G-vec00696-002-s335><adjust.einstellen><en> And with Autoselect®, the steam-mop will automatically adjust the amount of steam based on the surface you’re cleaning. Learn More
<G-vec00696-002-s335><adjust.einstellen><de> Mit der AutoSelect Technologie kann je nach Bodenbelag oder Oberfläche die richtige Menge Dampf via Einstellrad am Handgerät eingestellt werden.
<G-vec00696-002-s336><adjust.einstellen><en> You have to be prepared to adjust to large fluctuations due to the ongoing licensing procedures in many countries.
<G-vec00696-002-s336><adjust.einstellen><de> Durch die laufenden Lizenzverfahren in vielen Ländern muss man auf große Schwankungen eingestellt sein.
<G-vec00696-002-s337><adjust.einstellen><en> A valve can be used to adjust the flow rate in the pipe section.
<G-vec00696-002-s337><adjust.einstellen><de> Über ein Ventil kann der Durchfluss in der Rohrstrecke eingestellt werden.
<G-vec00696-002-s338><adjust.einstellen><en> A selected viewport shows reference points at the corners which can be used to adjust the the size of the viewport.
<G-vec00696-002-s338><adjust.einstellen><de> Ein ausgewähltes Ansichtsfenster zeigt an den Ecken Referenzpunkte an, mit denen die Grösse des Ansichtsfensters eingestellt werden kann.
<G-vec00696-002-s339><adjust.einstellen><en> A dedicated knob on the back of the subwoofer lets you adjust the bass level.
<G-vec00696-002-s339><adjust.einstellen><de> Mit einem speziellen Regler an der Rückseite des Subwoofers kann der Basspegel eingestellt werden.
<G-vec00696-002-s340><adjust.einstellen><en> It is possible to adjust the water pressure, type and position of spray, and the water temperature. Photos: TOTO.
<G-vec00696-002-s340><adjust.einstellen><de> Dabei können Strahlstärke, Strahlart, Wassertemperatur und Position des Wasserstrahlsindividuell eingestellt werden.Fotos: TOTO.
<G-vec00696-002-s341><adjust.einstellen><en> People with an unusual short- or far-sightedness can also benefit from the Conflex annual lens, since an optician can choose diopter, diameter or radius of the eye exactly and adjust them to a patient’s individual needs better than other contact lenses.
<G-vec00696-002-s341><adjust.einstellen><de> Menschen mit ungewöhnlich hohen oder niedrigen Dioptrienwerten profitieren am meisten von der Conflex Air 100 UV Jahreslinse, da diese vom Hersteller genauer auf Dioptrien, Durchmesser oder Radius der Augen eingestellt und auf die individuellen Bedürfnisse angepasst werden kann.
<G-vec00696-002-s342><adjust.einstellen><en> Plus, with the help of spray granulation, it is possible to dry liquid food additives and precisely adjust their particle size.
<G-vec00696-002-s342><adjust.einstellen><de> Mittels Sprühgranulation werden flüssige Lebensmittelzusatzstoffe getrocknet und ihre Partikelgröße exakt eingestellt.
<G-vec00696-002-s343><adjust.einstellen><en> Telescopic adjustable poles are assembled in 2 or 3 segments so that the athlete can adjust them to the correct size depending on their height. For running on normal terrain and gentle slopes the arms should be at a right angle of 90 degrees.
<G-vec00696-002-s343><adjust.einstellen><de> Besonders praktisch sind Stöcke mit Teleskopsystem, die aus zwei oder drei Teilen montiert werden und auf die jeweils benötigte Höhe eingestellt werden können: Die Arme sollten bei normalem Gelände und sanften Hängen etwa einen rechten Winkel bilden.
<G-vec00696-002-s344><adjust.einstellen><en> It can take some time to adjust to the culture shock – but the joy of discovering this unique and beautiful country is so worth the effort.
<G-vec00696-002-s344><adjust.einstellen><de> Es kann ein bisschen dauern, bis man sich auf den Kulturschock eingestellt hat – aber die Freude die es mit sich bringt dieses einzigartige und schöne Land zu entdecken, ist die Mühe allemal wert.
<G-vec00696-002-s345><adjust.einstellen><en> This makes it possible to precisely adjust physical properties as required.
<G-vec00696-002-s345><adjust.einstellen><de> Dadurch können die physikalischen Eigenschaften je nach Bedarf genau eingestellt werden.
<G-vec00696-002-s346><adjust.einstellen><en> It can be used to disassemble, assemble and adjust both first generation dry double clutches (up to May 2011) and second generation dry double clutches (from June 2011) in vehicles manufactured by Audi, Seat, Škoda and Volkswagen with a 0AM transmission.
<G-vec00696-002-s346><adjust.einstellen><de> Damit können sowohl trockene Doppelkupplungen der ersten Generation (bis Produktionsdatum 05.2011), als auch der zweiten Generation (ab Produktionsdatum 06.2011) bei Fahrzeugen der Marken Audi, Seat, Skoda und Volkswagen mit Getriebetyp 0AM demontiert, montiert und eingestellt werden.
<G-vec00696-002-s347><adjust.einstellen><en> The elastic waistband of these ski pants closes with Velcro, allowing you to adjust it to your own fit and comfort.
<G-vec00696-002-s347><adjust.einstellen><de> Das elastische Taillenband dieser Skihose ist mit einem Klettverschluss verschließbar und kann somit auf jede individuelle Größe eingestellt werden.
<G-vec00696-002-s348><adjust.einstellen><en> The color tones are adjusted automatically, but you can adjust color tones manually using the White Balance function.
<G-vec00696-002-s348><adjust.einstellen><de> Die Farbtöne werden automatisch eingestellt, können mit der Weißabgleichfunktion aber auch manuell eingestellt werden.
<G-vec00696-002-s349><adjust.einstellen><en> During a six day course our certified trainers show you how to cycle healthy, how to adjust your bike to your needs, give tips on training techniques and how to select the right equipment - all fundamental information to promote healthy exercises.
<G-vec00696-002-s349><adjust.einstellen><de> Im 6-tägigen Präventionskurs zeigen Ihnen zertifizierte Trainer, wie Radfahren die Gesundheit fördert und das Fahrrad richtig eingestellt wird, geben Tipps zu Technik und Ausrüstung und vermitteln Grundlagen des gesundheitsfördernden Trainings.
<G-vec00696-002-s350><adjust.einstellen><en> Set the maximum heart rate and it will adjust the rhythm, speed and running gradient based on the heart rate detected in real time during training.
<G-vec00696-002-s350><adjust.einstellen><de> Stellen Sie die maximale Herzfrequenz ein, und Rhythmus, Geschwindigkeit und Steigung werden basierend auf der in Echtzeit während des Trainings erfassten Herzfrequenz eingestellt.
<G-vec00696-002-s351><adjust.einstellen><en> Crampons adjust by default to smaller to medium size boots (without bar sticking out at the back).
<G-vec00696-002-s351><adjust.einstellen><de> Die Steigeisen sind werksseitig auf kleine bis mittelgroße Füße eingestellt (ohne dass der Steg nach hinten hinausragt).
<G-vec00696-002-s352><adjust.einstellen><en> Another scale is used to adjust the angle of inclination of the water tank.
<G-vec00696-002-s352><adjust.einstellen><de> Über eine weitere Skala wird der Neigungswinkel des Wasserbehälters eingestellt.
<G-vec00696-002-s353><adjust.einstellen><en> With the potentiometer P1 you can adjust the output voltage from 2.4 to 16 volts.
<G-vec00696-002-s353><adjust.einstellen><de> Mit P1 wird die Spannung von 2,4 bis 16 Volt eingestellt.
<G-vec00696-002-s354><adjust.einstellen><en> Unable to adjust BUZZER volume of my Philips device
<G-vec00696-002-s354><adjust.einstellen><de> Die Summtonlautstärke meines Philips Geräts kann nicht eingestellt werden.
<G-vec00696-002-s355><adjust.einstellen><en> The system can operate in conjunction with any trailer without need to calibrate or adjust to recognise any new trailer.
<G-vec00696-002-s355><adjust.einstellen><de> Das System funktioniert mit jedem Anhänger, und es muss weder kalibriert noch auf die Erfassung eines neuen Anhängers eingestellt werden.
<G-vec00696-002-s356><adjust.einstellen><en> Drawstring with plastic stops at both 2 side seams, can adjust by yourself.
<G-vec00696-002-s356><adjust.einstellen><de> Kordelzug mit Kunststoffanschlägen an beiden 2 Seitennähten, kann von Ihnen selbst eingestellt werden.
<G-vec00696-002-s357><adjust.einstellen><en> The image can also be shifted, so installers do not have to reinstall or adjust the projector physically in case the image is not precisely aligned on the desired frame and space.
<G-vec00696-002-s357><adjust.einstellen><de> Das Bild kann auch verschoben werden, sodass der Projektor nicht neu installiert oder eingestellt werden muss, falls das Bild nicht passgenau auf den gewünschten Rahmen oder Raum ausgerichtet ist.
<G-vec00696-002-s358><adjust.einstellen><en> It enables you to adjust the height of the two-way cargo board to the position you need.
<G-vec00696-002-s358><adjust.einstellen><de> Er kann auf die Höhe eingestellt werden, die Sie wünschen, um alles Nötige zu verstauen.
<G-vec00696-002-s359><adjust.einstellen><en> Able to setup and adjust the Soy Milk and coagulant injecting quantity, mixing time, Tofu stirring time to increase Tofu production efficiency.
<G-vec00696-002-s359><adjust.einstellen><de> Tofu-Die Einspritzmenge für Sojamilch und Koagulans, Mischzeit, Tofu-Rührzeit können eingestellt und eingestellt werden, um die Tofu-Produktionseffizienz zu erhöhen.
<G-vec00696-002-s360><adjust.einstellen><en> This allows you to adjust the size of the projected image to the surface, without sacrificing any quality.
<G-vec00696-002-s360><adjust.einstellen><de> Hiermit kann die Größe des Bildes ohne Qualitätsverlust eingestellt werden.
<G-vec00696-002-s361><adjust.einstellen><en> The belt can be tensioned separately, and easy to adjust the level.
<G-vec00696-002-s361><adjust.einstellen><de> Der Riemen kann separat gespannt werden und das Niveau kann leicht eingestellt werden.
<G-vec00696-002-s362><adjust.einstellen><en> These parameters allow to adjust the reaction conditions exactly to the process medium and the targeted output.
<G-vec00696-002-s362><adjust.einstellen><de> Mit diesen Parametern können die Reaktionsbedingungen exakt auf das Prozessmedium und die angestrebte Leistung eingestellt werden.
<G-vec00696-002-s363><adjust.einstellen><en> Equipped with the variable spray nozzle FlexJet it is possible to adjust the application amount and the width of the spray jet individually.
<G-vec00696-002-s363><adjust.einstellen><de> Pre-fill Premium ist mit dem variablen Sprühkopf FlexJet ausgestattet, womit Ausbringmenge und Sprühstrahlbreite je nach Bedarf individuell eingestellt werden können.
<G-vec00696-002-s364><adjust.einstellen><en> If for any reason the Customer does not know how to use or adjust the products correctly, the Customer must send a written request to COUTH for more information and/or explanatory leaflets for this purpose.
<G-vec00696-002-s364><adjust.einstellen><de> Wenn der Kunde aus irgendeinem Grund nicht weiß, wie die Produkte korrekt verwendet oder eingestellt werden, muss der Kunde eine schriftliche Anfrage an COUTH senden, um weitere Informationen und/oder erklärende Broschüren zu diesem Zweck zu erhalten.
<G-vec00696-002-s365><adjust.einstellen><en> Through the loading and unloading gate can adjust the material flow.
<G-vec00696-002-s365><adjust.einstellen><de> Durch das Lade- und Entlade-Tor kann der Materialfluss eingestellt werden.
<G-vec00696-002-s366><adjust.einstellen><en> You can also adjust the cold tire color.
<G-vec00696-002-s366><adjust.einstellen><de> Die Farbe der kalten Reifen kann ebenfalls eingestellt werden.
<G-vec00696-002-s367><adjust.einstellen><en> A mechanical spring allows the user to adjust the pressure of the backrest to his or her own individual needs.
<G-vec00696-002-s367><adjust.einstellen><de> Über eine mechanische Feder kann der Andruck der Rückenlehne individuell an das jeweilige Bedürfnis des Benutzers eingestellt werden.
<G-vec00696-002-s368><adjust.einstellen><en> If you do not want cookies to be used on this website, you can adjust your browser to ensure that storage of the cookie is not accepted.
<G-vec00696-002-s368><adjust.einstellen><de> Sollten Sie die Verwendung von Cookies auf dieser Website nicht wünschen, können Sie Ihren Browser so einstellen, dass eine Speicherung nicht akzeptiert wird.
<G-vec00696-002-s369><adjust.einstellen><en> Currently a transitional period of two years applies in which all parties must adjust to the new rules.
<G-vec00696-002-s369><adjust.einstellen><de> Aktuell gilt eine Übergangszeit von 2 Jahren, in der sich alle betroffenen Parteien auf die neuen Regelungen einstellen müssen.
<G-vec00696-002-s370><adjust.einstellen><en> 1 Select the speaker whose level you want to adjust.
<G-vec00696-002-s370><adjust.einstellen><de> 1 Wählen Sie den Lautsprecher an, dessen Pegel Sie einstellen möchten.
<G-vec00696-002-s371><adjust.einstellen><en> 17 CFD-222/DW222.E._3-858-169-1X.U/CA/AU/E92 Setting Up Setting Up Adjusting the sound emphasis (TONE/MEGA BASS) You can adjust the tone and reinforce the bass sound.
<G-vec00696-002-s371><adjust.einstellen><de> 17 D Vorbereitungen CFD-222L/DW222.E.G._3-858-169-3X.CED.CEK.EE1.E23.EA1.JEC Vorbereitungen Einstellen der Klangbetonung (TONE/MEGA BASS) Sie können den Klang einstellen und die Bässe verstärken.
<G-vec00696-002-s372><adjust.einstellen><en> In particular, the client requested complete control over the lighting system so as to be able to adjust the switching on/off of the luminaires and the variation of the light intensity in every room of the house, both inside and outside, from a practical display.
<G-vec00696-002-s372><adjust.einstellen><de> Insbesondere wünschte der Kunde eine vollständige Steuerung der Beleuchtungsanlage, um das Ein- und Ausschalten der Leuchten und die Variation der Lichtintensität in jedem Raum des Hauses, sowohl innen als auch außen, über ein praktisches Display einstellen zu können.
<G-vec00696-002-s373><adjust.einstellen><en> Depending on your display setup, you can set the screen resolution, toggle mirroring, and adjust the refresh rates.
<G-vec00696-002-s373><adjust.einstellen><de> Je nach Display können Sie Auflösung, Mirroring und Bildwiederholrate einstellen.
<G-vec00696-002-s374><adjust.einstellen><en> You can adjust the angle and rotate your device horizontally or vertically thanks to the ball joint.
<G-vec00696-002-s374><adjust.einstellen><de> Sie können den Winkel einstellen und Ihr Gerät dank des Kugelgelenks vertikal oder horizontal drehen.
<G-vec00696-002-s375><adjust.einstellen><en> The heating curve allows you to adjust the desired temperature of the feed line as a function of the outside temperature.
<G-vec00696-002-s375><adjust.einstellen><de> Mit der Heizkurve kannst Du die gewünschte Solltemperatur des Vorlaufs in Abhängigkeit von der Außentemperatur einstellen.
<G-vec00696-002-s376><adjust.einstellen><en> I also found it hard work having to pull the straps in the shoulder area upwards to adjust them.
<G-vec00696-002-s376><adjust.einstellen><de> Ich selbst fand es außerdem anstrengend, das Gurtband im Schulterbereich zum Einstellen gen Himmel ziehen zu müssen.
<G-vec00696-002-s377><adjust.einstellen><en> You must adjust your shots based on the gravitational pull of each planet.
<G-vec00696-002-s377><adjust.einstellen><de> Du musst deine Schüsse basierend auf die Anziehungskraft jedes Planeten einstellen.
<G-vec00696-002-s378><adjust.einstellen><en> The adjustable length mass, you can adjust the straps on your optimal suitcase luggage and highly secure.
<G-vec00696-002-s378><adjust.einstellen><de> Durch die verstellbaren Längenmasse können Sie die Spanngurte optimal auf Ihr Koffergepäck einstellen und bestens Sichern.
<G-vec00696-002-s379><adjust.einstellen><en> During playback, you can adjust the interval or pause to capture and share a still image.
<G-vec00696-002-s379><adjust.einstellen><de> Während der Wiedergabe können Sie das Intervall einstellen oder anhalten und mit anderen ein Foto teilen.
<G-vec00696-002-s380><adjust.einstellen><en> For example, to adjust speech rate, rotate two fingers until the VoiceOver speech rate rotor control is selected.
<G-vec00696-002-s380><adjust.einstellen><de> Beispiel: Zum Einstellen des Sprechtempos drehen Sie zwei Finger, bis die Rotoreinstellung für das Sprechtempo von VoiceOver ausgewählt ist.
<G-vec00696-002-s381><adjust.einstellen><en> Using this mode you can adjust the Brightness, Contrast, Temperature and Blur / Sharpen parameters, apply effects or textures in different combinations.
<G-vec00696-002-s381><adjust.einstellen><de> Sie können auch die Parameter Helligkeit, Kontrast, Temperatur und Unschärfe / Schärfe getrennt einstellen.
<G-vec00696-002-s382><adjust.einstellen><en> Organic / inorganic phosphorus compounds for reef aquariums: Helps adjust the TRITON nutrient ratio.
<G-vec00696-002-s382><adjust.einstellen><de> Organische/Anorganische Phosphorverbindungen für Riffaquarien: Hilft beim Einstellen des TRITON Nährstoff-Verhältnisses.
<G-vec00696-002-s383><adjust.einstellen><en> To adjust the sensitivity of each zone according to the indicator light, so as to adjust each sensor zone to the best state.
<G-vec00696-002-s383><adjust.einstellen><de> Einstellen der Empfindlichkeit jeder Zone entsprechend der Anzeigelampe, um jede Sensorzone auf den besten Zustand einzustellen.
<G-vec00696-002-s384><adjust.einstellen><en> Setting Up 27 Setting Up Adjusting the audio emphasis (MEGA BASS/ROTARY EQUALIZER/SURROUND) You can adjust the audio emphasis of the sound you are listening to.
<G-vec00696-002-s384><adjust.einstellen><de> Page 72 Vorbereitungen 32 D Auswählen der Klangbetonung (Klangmodus/MEGA BASS) Sie können die Klangbetonung der Musik, die Sie wiedergeben lassen, einstellen.
<G-vec00696-002-s385><adjust.einstellen><en> The maximum gain You can adjust channel isolated in steps 0 dB, 10 dB and 20 dB.
<G-vec00696-002-s385><adjust.einstellen><de> Die maximale Verstärkung können Sie in den Schritten 0 dB, 10 dB und 20 dB kanalgetrennt einstellen.
<G-vec00696-002-s386><adjust.einstellen><en> Also, you can adjust the VR Porn player to any video format you have downloaded, and even the option “Fisheye” is now possible.
<G-vec00696-002-s386><adjust.einstellen><de> Außerdem können Sie den VR Porn Playerauf jedes heruntergeladene Videoformat einstellen, und sogar die Option "Fisheye" ist jetzt möglich.
<G-vec00696-002-s387><adjust.einstellen><en> The oak shelf rests on pins that let you adjust its position up and down.
<G-vec00696-002-s387><adjust.einstellen><de> Das Eichenregal ruht auf Stiften, mit denen Sie die Position nach oben und unten einstellen können.
<G-vec00696-002-s388><adjust.einstellen><en> The ZENIT HIGH adapts to the movements and the body shape of the user. It is equipped with a synchronous mechanism, which allows you to adjust the seat inclination and backrest independently.
<G-vec00696-002-s388><adjust.einstellen><de> Der ZENIT HIGH BIG passt sich den Bewegungen und der Körperform des Nutzers an, da er mit einer neuartigen Synchronmechanik ausgestattet ist, bei der Sie die Neigung von Sitzfläche und Rückenlehne unabhängig voneinander einstellen können.
<G-vec00696-002-s389><adjust.einstellen><en> Additionally or alternatively, the injector may be operated in a clocked, in particular, the opening time period and the clock frequency are adjustable in the manner of a pulse-width modulation to adjust the respective amount of fuel.
<G-vec00696-002-s389><adjust.einstellen><de> Zusätzlich oder alternativ kann die Einspritzdüse getaktet betrieben werden, wobei insbesondere die Öffnungszeitdauer und die Taktfrequenz einstellbar sind, um nach Art einer Puls-Weiten Modulation die jeweilige Kraftstoffmenge einstellen zu können.
<G-vec00696-002-s390><adjust.einstellen><en> The fan head can be tilted 25 degrees so you can even adjust the direction of the air flow.
<G-vec00696-002-s390><adjust.einstellen><de> Der Ventilatorkopf kann 25 Grad geneigt werden, sodass Sie sogar die Richtung des Luftstroms einstellen können.
<G-vec00696-002-s391><adjust.einstellen><en> They are usually provided with replaceable blades and controls that allow you to adjust the tensioning force exerted on the cable ties.
<G-vec00696-002-s391><adjust.einstellen><de> Sie sind in der Regel mit austauschbaren Messern und Bedienelementen ausgestattet, mit denen Sie die auf die Kabelbinder ausgeübte Spannkraft einstellen können.
<G-vec00696-002-s392><adjust.einstellen><en> The round Ray ceiling spots are tiltable, allowing you to adjust the direction of the light beam.
<G-vec00696-002-s392><adjust.einstellen><de> Die runden Ray Deckenstrahler sind schwenkbar, so dass Sie die Richtung des Lichtstrahls einstellen können.
<G-vec00696-002-s393><adjust.einstellen><en> The industrial robots involved in the process of robotic welding are articulated devices, equipped with arms, which are usually mounted on some form of axis allowing them to move and adjust themselves as required.
<G-vec00696-002-s393><adjust.einstellen><de> Bei den Industrierobotern, die für Roboterschweißen eingesetzt werden, handelt es sich um gelenkige Vorrichtungen mit Armen, die in der Regel auf einer Art Achse montiert sind und sich, wie erforderlich, selbst bewegen und einstellen können.
<G-vec00696-002-s394><adjust.einstellen><en> In order to precisely adjust the mainsail and “square head”, the mainsail has a traveller which can be fastened in any position.
<G-vec00696-002-s394><adjust.einstellen><de> Um das Großsegel und den „Square Head“ genau einstellen zu können, hat das Großsegel einen Traveller, der in jeder Position fixiert werden kann.
<G-vec00696-002-s395><adjust.einstellen><en> All devices in the Vario Line own our patented Vario grinder, which allows you to adjust the size of the dry ice particles in three stages (0.4 / 0.8 / 2.0 mm).
<G-vec00696-002-s395><adjust.einstellen><de> Alle Geräte der Vario Line besitzen unser patentiertes Vario-Mahlwerk, mit dem Sie die Größe der Trockeneispartikel in drei Stufen einstellen können (0,4 / 0,8 / 2,0 mm).
<G-vec00696-002-s396><adjust.einstellen><en> The SKYTOPPOWER STP3005 Regulated DC Power Supply 30V 5A (110/220V AC Switchable) 3 1/2 LED display is a regulated DC power supply that allows you to adjust the current and the voltage continuously.
<G-vec00696-002-s396><adjust.einstellen><de> Das SKYTOPPOWER STP3005 Geregelte DC-Netzteil 30V 5A (110 / 220V AC umschaltbar) 3 1/2 LED-Anzeige ist eine geregelte DC-Stromversorgung, mit der Sie den Strom und die Spannung kontinuierlich einstellen können.
<G-vec00696-002-s397><adjust.einstellen><en> The slim profile 11 mm and the easy to reach brightness adjustment button allow you to easily adjust it for relaxed drawing to your desired brightness.
<G-vec00696-002-s397><adjust.einstellen><de> Ein schmales 11-mm-Profil und eine leicht zugängliche Helligkeits-Einstelltaste, mit der Sie die gewünschte Helligkeit zum bequemen Zeichnen problemlos einstellen können.
<G-vec00696-002-s398><adjust.einstellen><en> The temperature is very important because it allows you to adjust the filtration time of your pool.
<G-vec00696-002-s398><adjust.einstellen><de> Die Temperatur ist wichtig, weil Sie damit die Filtrationszeit Ihres Pools einstellen können.
<G-vec00696-002-s400><adjust.einstellen><en> adjustment may be provided in order to adjust the effective length of projecting into the pharynx tongue depressor to a patient.
<G-vec00696-002-s400><adjust.einstellen><de> Eine Verstellmöglichkeit kann vorgesehen sein, um die effektive Länge des in den Pharynx ragenden Zungenspatels auf einen Patienten einstellen zu können.
<G-vec00696-002-s420><adjust.einstellen><en> An encoder according to claim 1, wherein said special code comprises a dummy data to be abandoned in a decoding process so as to adjust the length of the partitioned data string.
<G-vec00696-002-s420><adjust.einstellen><de> Codierer nach Anspruch 1, bei dem der spezielle Code Scheindaten aufweist, die in einem Decodiervorgang wegzulassen sind, um die Länge der geteilten Datenreihe einzustellen.
<G-vec00696-002-s421><adjust.einstellen><en> If necessary, medical staff will be able to easily operate the manual crank to adjust the patient bed.
<G-vec00696-002-s421><adjust.einstellen><de> Im Bedarfsfall kann das ärztliche Personal die Handkurbel verwenden, um das Patientenbett ganz einfach einzustellen.
<G-vec00696-002-s422><adjust.einstellen><en> Black and overexposure limits, and also other intermediate safety levels can be used to adjust the camera and lens.
<G-vec00696-002-s422><adjust.einstellen><de> Schwarz- und Überbelichtungsgrenzen, sowie andere Sicherheitspegel können verwendet werden, um die Kamera- und Objektiv-Werte einzustellen.
<G-vec00696-002-s423><adjust.einstellen><en> It is now easier than ever to adjust the upper heating platen to accommodate thick items.
<G-vec00696-002-s423><adjust.einstellen><de> Jetzt ist es einfacher denn je, die obere Heizplatte für dicke Gegenstände einzustellen.
<G-vec00696-002-s424><adjust.einstellen><en> 4) Easy installation: come with steel stand for installation, the sensor is rotatable to adjust detective angle.
<G-vec00696-002-s424><adjust.einstellen><de> 4) Einfache Installation: kommen mit Stahlständer für Installation, der Sensor ist drehbar, um Detektivwinkel einzustellen.
<G-vec00696-002-s426><adjust.einstellen><en> possible to adjust the driving energy by changing the size of the initial combustion chamber for the propellant charge.
<G-vec00696-002-s426><adjust.einstellen><de> Ebenfalls möglich ist es, die Eintreibenergie durch eine Veränderung der Größe des Anfangsbrennraums für die Treibladung einzustellen.
<G-vec00696-002-s427><adjust.einstellen><en> Plush trousers, with drawstring on the waist to adjust the width, with two pockets.
<G-vec00696-002-s427><adjust.einstellen><de> 106,00 € 53,00 € mit Kordel auf der Taille, um die Breite einzustellen und zwei Taschen.
<G-vec00696-002-s428><adjust.einstellen><en> There are additional options available to adjust other aspects of the kernel's behaviour.
<G-vec00696-002-s428><adjust.einstellen><de> Es gibt außerdem zusaetzliche Optionen und Befehle um andere Aspekte des Kernelverhaltens einzustellen.
<G-vec00696-002-s429><adjust.einstellen><en> Press the upper or lower part of the Volume key during a call to adjust the volume.
<G-vec00696-002-s429><adjust.einstellen><de> Drücken Sie während eines Anrufes die Lautstärke-Taste oben oder unten, um die Lautstärke einzustellen.
<G-vec00696-002-s430><adjust.einstellen><en> Acer eNet Management automatically detects the best settings for a new location, while offering you the freedom to manually adjust the settings to match your needs, simply by right-clicking on the icon in the taskbar.
<G-vec00696-002-s430><adjust.einstellen><de> Acer eNet Management erkennt automatisch die besten Einstellungen fur einen neuen Ort und erlaubt Ihnen, die Einstellungen ganz nach Ihren Bedurfnissen frei einzustellen, indem Sie einfach mit der rechten Maustaste auf das Symbol in der Taskleiste klicken.
<G-vec00696-002-s431><adjust.einstellen><en> POWERFUL SOFTWARE CORSAIR LINK software allows you to adjust RGB lighting, individual fan speeds, and pump speed while monitoring CPU and coolant temperatures, and more.
<G-vec00696-002-s431><adjust.einstellen><de> Die Corsair Software macht es möglich, das RGB Licht einzustellen, sowie individuelle Lüfter- und Pumpengeschwindigkeiten während man die CPU und die Kühlertemperatur überwacht.
<G-vec00696-002-s432><adjust.einstellen><en> A well-thought-out design of the profile and accessories allows you to adjust the window yourself, without much effort and time.
<G-vec00696-002-s432><adjust.einstellen><de> Ein durchdachtes Design des Profils und des Zubehörs ermöglicht es Ihnen, das Fenster selbst ohne viel Aufwand und Zeit einzustellen.
<G-vec00696-002-s433><adjust.einstellen><en> You also have the option to adjust your walking speed to calculate the traveling time itself.
<G-vec00696-002-s433><adjust.einstellen><de> Sie haben zudem die Möglichkeit, Ihr Wandertempo zur Berechnung der Wanderzeit selbst einzustellen.
<G-vec00696-002-s434><adjust.einstellen><en> Lightweight, easy to adjust and now also compatible with GripWalk and GripWalk PRO SET
<G-vec00696-002-s434><adjust.einstellen><de> Leicht, einfach einzustellen und jetzt auch kompatibel mit GripWalk und GripWalk Junior Skischuhen.
<G-vec00696-002-s435><adjust.einstellen><en> For this reason, it may be necessary to adjust the time base on the chosen recipe.
<G-vec00696-002-s435><adjust.einstellen><de> Aus diesem Grund kann es notwendig sein, die Zeitbasis auf das gewählte Rezept einzustellen.
<G-vec00696-002-s436><adjust.einstellen><en> Raik Nach This weekend i've got time to adjust the spindle bearings.
<G-vec00696-002-s436><adjust.einstellen><de> Am Wochenende bin ich dazu gekommen die Spindellager genauer einzustellen.
<G-vec00696-002-s437><adjust.einstellen><en> On this panel it is possible to adjust, which columns are searched, if upper and lower case words are differed or if the search is concentrated on the whole term or single words.
<G-vec00696-002-s437><adjust.einstellen><de> Hier ist es möglich einzustellen, welche Spalten nach den entsprechenden Worten durchsucht werden, ob die Groß- und Kleinschreibung beachtet werden soll oder ob der Begriff als ganzer Term oder als mehrere Einzelwörter behandelt werden soll.
<G-vec00696-002-s438><adjust.einstellen><en> The system precisely scans the condition of the road ahead with the help of a stereo camera to adjust the damping of each individual wheel optimally to the upcoming bumps already ahead of time.
<G-vec00696-002-s438><adjust.einstellen><de> Mithilfe einer Stereokamera wird die Beschaffenheit der vorausliegenden Fahrbahn präzise erfasst, um die Dämpfung jedes einzelnen Rades schon im Vorfeld auf die kommenden Unebenheiten bestmöglich einzustellen.
<G-vec00696-002-s751><adjust.einstellen><en> The ENGEL programming department had to adjust to the new dual spindle machine in the process.
<G-vec00696-002-s751><adjust.einstellen><de> Dabei musste sich die ENGEL-Programmierabteilung erst auf die neue Doppelspindelmaschine einstellen.
<G-vec00696-002-s752><adjust.einstellen><en> The future belongs to companies, which adjust strategically to the opportunities and challenges of tomorrow and then pursue this path consistently.
<G-vec00696-002-s752><adjust.einstellen><de> Die Zukunft gehört Unternehmen, die sich strategisch auf die Chancen und Herausforderungen von Morgen einstellen und diesen Weg dann konsequent verfolgen.
<G-vec00696-002-s753><adjust.einstellen><en> For a perfect wearing comfort, you can adjust your sunglasses individually from your optician.
<G-vec00696-002-s753><adjust.einstellen><de> Weiterführende Links zu Für einen perfekten Tragekomfort lassen Sie sich Ihre Sonnenbrille von Ihrem Optiker individuell einstellen.
<G-vec00696-002-s754><adjust.einstellen><en> Our vision must adjust to new intensity.
<G-vec00696-002-s754><adjust.einstellen><de> Unser Blick muss sich einstellen auf neue Intensität.
<G-vec00696-002-s755><adjust.einstellen><en> Competition in the Stuttgart region has become tougher and organic traders like Naturgut must suitably adjust to this situation.
<G-vec00696-002-s755><adjust.einstellen><de> Der Wettbewerb im Raum Stuttgart ist härter geworden und Biohändler wie Naturgut müssen sich entsprechend darauf einstellen .
<G-vec00696-002-s756><adjust.einstellen><en> You will be one step ahead of your competition at all times and can adjust to changes before they become apparent.
<G-vec00696-002-s756><adjust.einstellen><de> So sind Sie Ihrem Wettbewerb stets einen Schritt voraus und können sich auf Veränderungen einstellen, noch bevor diese offensichtlich werden.
<G-vec00696-002-s757><adjust.einstellen><en> Once you have selected an EQ band, you can adjust its parameters via the knobs below the display.
<G-vec00696-002-s757><adjust.einstellen><de> Nach Anwahl eines EQ-Bandes lassen sich dessen Parameter mit den Reglern unter dem Display einstellen.
<G-vec00696-002-s758><adjust.einstellen><en> · you can adjust the coin value accordingly with the "+/-" keys.
<G-vec00696-002-s758><adjust.einstellen><de> · Mit den „+/–“-Tasten lässt sich der Münzwert entsprechend einstellen.
<G-vec00696-002-s759><adjust.einstellen><en> Its successful operating concept allows users to adjust the swivel chair to their individual needs.
<G-vec00696-002-s759><adjust.einstellen><de> Mit dem gelungenen Bedienkonzept lässt sich der Drehstuhl auf die individuellen Bedürfnisse einstellen.
<G-vec00696-002-s760><adjust.einstellen><en> By the size of the recess 6 can adjust the elasticity of the arm relative to the arm 3b on the 3rd.
<G-vec00696-002-s760><adjust.einstellen><de> Über die Größe der Ausnehmung 6 lässt sich die Elastizität des Schenkels 3a gegenüber dem Schenkel 3b einstellen.
<G-vec00696-002-s761><adjust.einstellen><en> Sensor-enhanced gloves allow the immersive virtual reality program to adjust the size of an object or its distance from a user, making a task easier or more difficult depending on the patient’s performance.
<G-vec00696-002-s761><adjust.einstellen><de> Dank mit Sensoren ausgestatteter Handschuhe lässt sich im realistischen VR-Programm die Größe eines Gegenstands oder seine Entfernung zum Nutzer einstellen, um die Aufgabe abhängig von der Leistung des Patienten leichter oder schwerer zu machen.
<G-vec00696-002-s762><adjust.einstellen><en> You can adjust the size of the stroke with a slider.
<G-vec00696-002-s762><adjust.einstellen><de> Die Konturgröße lässt sich mit einen Slider zwischen 1 und 288 Pixeln einstellen.
<G-vec00696-002-s763><adjust.einstellen><en> Var: Here, you can adjust the characteristic via the scale potentiometer.
<G-vec00696-002-s763><adjust.einstellen><de> Vary: Hier lässt sich, mittels Scale-Potentiometer, eine Charakteristik von 0V bis +0,5 V pro Oktave einstellen.
<G-vec00696-002-s764><adjust.einstellen><en> It will be exciting to see how quickly app developers adjust to switching from a small to a large display.
<G-vec00696-002-s764><adjust.einstellen><de> Spannend wird sein, wie schnell sich die App-Entwickler auf das Umschalten von kleinem auf großes Display einstellen.
<G-vec00696-002-s765><adjust.einstellen><en> This allows to adjust the speed ratios of pick-up and transfer rollers, the three distributor rollers and the four collector rollers independently.
<G-vec00696-002-s765><adjust.einstellen><de> So lassen sich die Drehzahlverhältnisse der Aufnahme- und Übergabewalzen, der drei Verteilwalzen und der vier als Zwickwalzen ausgeführten Sammelwalzen unabhängig voneinander einstellen.
<G-vec00696-002-s766><adjust.einstellen><en> If you leave the marked swimming area, you have to adjust to some strong currents.
<G-vec00696-002-s766><adjust.einstellen><de> Wer die markierte Schwimmfläche verlässt, muss sich auf teilweise starke Strömungen einstellen.
<G-vec00696-002-s767><adjust.einstellen><en> It’s surprising how little you can adjust on this top model in the compact camera line.
<G-vec00696-002-s767><adjust.einstellen><de> Für ein Topmodell der Kompaktkameraserie lässt sich überraschend wenig einstellen.
<G-vec00696-002-s824><adjust.einstellen><en> You can adjust your browser in order to notify you about the setting of new cookies and decide whether to accept cookies for certain cases or to generally decline them.
<G-vec00696-002-s824><adjust.einstellen><de> Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und einzeln über deren Annahme entscheiden oder die Annahme von Cookies für bestimmte Fälle oder generell ausschließen.
<G-vec00696-002-s825><adjust.einstellen><en> You may adjust your browser to reject cookies but this will make the site less user-friendly.
<G-vec00696-002-s825><adjust.einstellen><de> Sie können Ihren Browser so einstellen, dass er Cookies blockiert, aber das macht die Website weniger benutzerfreundlich.
<G-vec00696-002-s826><adjust.einstellen><en> You can adjust the settings in your browser to inform you any time a cookie is being saved and request your permission to save cookies on a case-by-case basis, to only allow cookies to be saved in certain cases, to prevent the saving of cookies altogether, and/or to automatically delete cookies when you close your browser.
<G-vec00696-002-s826><adjust.einstellen><de> Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und Cookies nur im Einzelfall erlauben, die Annahme von Cookies für bestimmte Fälle oder generell ausschließen sowie das automatische Löschen der Cookies beim Schließen des Browser aktivieren.
<G-vec00696-002-s827><adjust.einstellen><en> You can adjust your browser settings to inform you in advance whenever cookies are set.
<G-vec00696-002-s827><adjust.einstellen><de> Sie können Ihren Browser so einstellen, dass er Sie über das Setzen von Cookies vorher informiert.
<G-vec00696-002-s829><adjust.einstellen><en> Most web browsers automatically accept cookies, but you can usually adjust your browser setting to decline cookies if you like.
<G-vec00696-002-s829><adjust.einstellen><de> Die meisten Web-Browser akzeptieren Cookies automatisch, aber sie können Ihren Browser so einstellen, dass er nur die Cookies der von Ihnen bevorzugten Web-Sites speichert.
<G-vec00696-002-s830><adjust.einstellen><en> You can adjust your browser to inform you when cookies are set, to allow cookies for individual cases, to deny cookies for specific groups, or to automatically deleting all cookies by ending your browser.
<G-vec00696-002-s830><adjust.einstellen><de> Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und Cookies nur im Einzelfall erlauben, die Annahme von Cookies für bestimmte Fälle oder generell ausschließen sowie das automatische Löschen der Cookies beim Schließen des Browsers aktivieren.
<G-vec00696-002-s831><adjust.einstellen><en> In addition, you can deactivate the storing of cookies or adjust your browser to inform you before the Cookie is stored on your computer.
<G-vec00696-002-s831><adjust.einstellen><de> Außerdem können Sie das Speichern von Cookies deaktivieren oder Ihren Browser so einstellen, dass Sie informiert werden, bevor ein Cookie auf Ihrem Computer gespeichert wird.
<G-vec00696-002-s832><adjust.einstellen><en> Hold the steering wheel and press the lever down. Adjust to the ideal position by moving the steering wheel horizontally and vertica...
<G-vec00696-002-s832><adjust.einstellen><de> Das Lenkrad so einstellen, dass der Abstand zwischen Lenkrad und Brustbein mindestens 25 cm beträg...
<G-vec00696-002-s833><adjust.einstellen><en> If you are not happy with this, you should adjust your browser to reject cookies.
<G-vec00696-002-s833><adjust.einstellen><de> Wenn Sie das nicht wünschen, sollten Sie Ihren Internetbrowser so einstellen, dass er die Annahme von Cookies verweigert.
<G-vec00696-002-s834><adjust.einstellen><en> The User can adjust his browser to reject Cookies or remove certain Cookies according to his criterion.
<G-vec00696-002-s834><adjust.einstellen><de> Der Nutzer kann seinen Browser so einstellen, dass er Cookies ablehnt oder bestimmte Cookies nach seinem Kriterium entfernt.
<G-vec00696-002-s836><adjust.einstellen><en> You can, however, disable the setting of cookies or adjust your browser to notify you as soon as a cookie is transmitted.
<G-vec00696-002-s836><adjust.einstellen><de> Sie können das Speichern von Cookies jedoch deaktivieren oder Ihren Browser so einstellen, dass er Sie benachrichtigt, sobald Cookies gesendet werden.
<G-vec00696-002-s839><adjust.einstellen><en> However, you can deactivate the storage of cookies or adjust your browser to inform you when cookies will be sent.
<G-vec00696-002-s839><adjust.einstellen><de> Sie können das Speichern von Cookies jedoch deaktivieren oder ihren Browser so einstellen, dass er Sie auf die Sendung von Cookies hinweist.
<G-vec00696-002-s840><adjust.einstellen><en> We can even adjust all the way to zero visibility conditions too – the only limit will be the need to balance things for fun and usability.
<G-vec00696-002-s840><adjust.einstellen><de> Wir können es sogar so einstellen, dass die Sicht gleich null ist – die Grenze hierbei sollte einfach nur sein, das richtige Gleichgewicht zu finden, dass alles noch Spaß macht und bedienbar bleibt.
<G-vec00696-002-s841><adjust.einstellen><en> If you would prefer not to receive any Cookies, you can adjust the settings on your internet browser to alert you each time a Cookie is presented to your computer, or you can delete any Cookies that have been stored on your hard drive.
<G-vec00696-002-s841><adjust.einstellen><de> Wenn Sie es vorziehen, keine Cookies zu erhalten, können Sie Ihren Internetbrowser so einstellen, dass Sie jedes Mal darauf aufmerksam gemacht werden, wenn ein Cookie auf Ihrem Computer angelegt werden soll, oder Sie können alle Cookies löschen, die auf Ihrer Festplatte gespeichert worden sind.
<G-vec00696-002-s714><adjust.sich_anpassen><en> You can adjust the Anchorage type and the Bond type by using the lists.
<G-vec00696-002-s714><adjust.sich_anpassen><de> Über die Listen lassen sich die Verankerungsart und der Verbund anpassen.
<G-vec00696-002-s715><adjust.sich_anpassen><en> The efficient trimmer head ensures good results and you can easily adjust it by changing the type of blade, depending on the task – from fine trimming to heavy work in rough terrain.
<G-vec00696-002-s715><adjust.sich_anpassen><de> Der leistungsstarke Trimmerkopf gewährleistet gute Ergebnisse und lässt sich ganz einfach durch die Wahl eines anderen Schneideblatts an die entsprechende Aufgabe anpassen: von Feinbearbeitung bis hin zu harter Arbeit in anspruchsvollem Gelände.
<G-vec00696-002-s716><adjust.sich_anpassen><en> In OS X, you can adjust keyboard shortcuts for each program under »System Preferences > Keyboard > Shortcuts«.
<G-vec00696-002-s716><adjust.sich_anpassen><de> Tastaturkurzbefehle lassen sich in OS X für jedes Programm unter »Systemeinstellungen > Tastatur > Kurzbefehle« anpassen.
<G-vec00696-002-s717><adjust.sich_anpassen><en> You can adjust the using quantity and using area according to your need.
<G-vec00696-002-s717><adjust.sich_anpassen><de> Sie können sich die Gebrauchsmenge und den Gebrauchbereich entsprechend Ihrem Bedarf anpassen.
<G-vec00696-002-s718><adjust.sich_anpassen><en> 2 piece light reactive lenses that adjust to a wide range of changing light conditions.
<G-vec00696-002-s718><adjust.sich_anpassen><de> 2 Stück leichte reaktive Linsen, die sich eine Vielzahl von wechselnden Licht Bedingungen anpassen.
<G-vec00696-002-s719><adjust.sich_anpassen><en> SDS can adjust automatically based on your capacity needs.
<G-vec00696-002-s719><adjust.sich_anpassen><de> SDS lässt sich je nach Ihren Kapazitätsbedürfnissen automatisch anpassen.
<G-vec00696-002-s720><adjust.sich_anpassen><en> Its rounded head, five blades that adjust to every curve, and Ribbon of MoistureTM ensure smooth results.
<G-vec00696-002-s720><adjust.sich_anpassen><de> Sein abgerundeter Klingenkopf, fünf Klingen, die sich jeder Kurve anpassen, und das Feuchtigkeitsband garantieren glatte Ergebnisse.
<G-vec00696-002-s721><adjust.sich_anpassen><en> It must adjust with the times and new circumstances.
<G-vec00696-002-s721><adjust.sich_anpassen><de> Sie muss sich der Zeit und den neuen Gegebenheiten anpassen.
<G-vec00696-002-s722><adjust.sich_anpassen><en> Equipped with four Slide Bloc buckles, you can adjust the Ophir Kids to any child size within seconds.
<G-vec00696-002-s722><adjust.sich_anpassen><de> Mit vier Slide Bloc-Schnallen ausgestattet lässt sich der Ophir Kids in Sekundenschnelle an jede Kindergröße anpassen.
<G-vec00696-002-s723><adjust.sich_anpassen><en> The new development supports the efficiency and cost effectiveness of climbing systems insomuch that they adjust flexibly to the structure geometry and permit larger formwork units.
<G-vec00696-002-s723><adjust.sich_anpassen><de> Die Neuentwicklung unterstützt die Effizienz und Wirtschaftlichkeit von Klettersystemen, indem sie sich flexibel an die Bauwerksgeometrie anpassen lässt und größere Schalungseinheiten erlaubt.
<G-vec00696-002-s724><adjust.sich_anpassen><en> Your body will adjust to make that happen and you will begin to see changes in many ways, including some of the shifts in consciousness.
<G-vec00696-002-s724><adjust.sich_anpassen><de> Euer Körper wird sich anpassen, um das zu ermöglichen, und ihr werdet bald unterschiedliche Veränderungen sehen, darunter auch Bewusstseinsverschiebungen.
<G-vec00696-002-s725><adjust.sich_anpassen><en> But they were able to adjust quickly.
<G-vec00696-002-s725><adjust.sich_anpassen><de> Aber sie konnten sich schnell anpassen.
<G-vec00696-002-s726><adjust.sich_anpassen><en> The safety cushion is therefore able to easily adjust to the child’s body.
<G-vec00696-002-s726><adjust.sich_anpassen><de> Das Sicherheitskissen lässt sich dadurch leicht dem Körper des Kindes anpassen.
<G-vec00696-002-s727><adjust.sich_anpassen><en> This means that no matter what monitor resolution you set, all elements adjust the size automatically.
<G-vec00696-002-s727><adjust.sich_anpassen><de> Das bedeutet das egal welche Monitorauflösung man einstellt, sich alle Elemente automatisch in der Größe anpassen.
<G-vec00696-002-s728><adjust.sich_anpassen><en> The Rear Delt/Pec Fly machine is equipped with swivelling, mobile arms, which adjust automatically to the arm length of the user.
<G-vec00696-002-s728><adjust.sich_anpassen><de> Die Taurus Pec Fly/Rear Delt IT95 verfügt über schwenkbare, bewegliche Arme, die sich automatisch der Armlänge des Trainierenden anpassen.
<G-vec00696-002-s729><adjust.sich_anpassen><en> You can adjust the white balance, tonal range, contrast, color saturation, and sharpness of a raw image without any loss of image quality.
<G-vec00696-002-s729><adjust.sich_anpassen><de> Ohne Verlust der Bildqualität lassen sich Weißabgleich, Tonwertbereich, Kontrast, Farbsättigung und Schärfe von Kamera-Rohdateien, wie jeweils gewünscht, anpassen.
<G-vec00696-002-s730><adjust.sich_anpassen><en> And I know that I’m fast: my skiing just needs to adjust to the material’s performance, then everything will be fine”, as the World Cup winner quickly put the race behind her again in the Atomic Facebook Livestream.
<G-vec00696-002-s730><adjust.sich_anpassen><de> Und ich weiß, dass ich schnell bin: Mein Skifahren muss sich nur an die Performance des Materials anpassen, dann ist alles gut“, war für die Gesamtweltcupsiegerin im Atomic Facebook Livestream schnell wieder ein Haken unter dem Rennen.
<G-vec00696-002-s731><adjust.sich_anpassen><en> This allows the belt to adjust optimally to any height und will not soon be too small.
<G-vec00696-002-s731><adjust.sich_anpassen><de> Damit lässt sich der Gurt optimal an jede Körpergröße anpassen und wird nicht so schnell zu klein.
<G-vec00696-002-s732><adjust.sich_anpassen><en> For this, you can adjust the colors and values assigned in the panel.
<G-vec00696-002-s732><adjust.sich_anpassen><de> Dabei lassen sich die Farb- und Wertezuweisungen des Panels anpassen.
<G-vec00902-002-s354><adjust.werden><en> Unable to adjust BUZZER volume of my Philips device
<G-vec00902-002-s354><adjust.werden><de> Die Summtonlautstärke meines Philips Geräts kann nicht eingestellt werden.
<G-vec00902-002-s355><adjust.werden><en> The system can operate in conjunction with any trailer without need to calibrate or adjust to recognise any new trailer.
<G-vec00902-002-s355><adjust.werden><de> Das System funktioniert mit jedem Anhänger, und es muss weder kalibriert noch auf die Erfassung eines neuen Anhängers eingestellt werden.
<G-vec00902-002-s356><adjust.werden><en> Drawstring with plastic stops at both 2 side seams, can adjust by yourself.
<G-vec00902-002-s356><adjust.werden><de> Kordelzug mit Kunststoffanschlägen an beiden 2 Seitennähten, kann von Ihnen selbst eingestellt werden.
<G-vec00902-002-s357><adjust.werden><en> The image can also be shifted, so installers do not have to reinstall or adjust the projector physically in case the image is not precisely aligned on the desired frame and space.
<G-vec00902-002-s357><adjust.werden><de> Das Bild kann auch verschoben werden, sodass der Projektor nicht neu installiert oder eingestellt werden muss, falls das Bild nicht passgenau auf den gewünschten Rahmen oder Raum ausgerichtet ist.
<G-vec00902-002-s358><adjust.werden><en> It enables you to adjust the height of the two-way cargo board to the position you need.
<G-vec00902-002-s358><adjust.werden><de> Er kann auf die Höhe eingestellt werden, die Sie wünschen, um alles Nötige zu verstauen.
<G-vec00902-002-s359><adjust.werden><en> Able to setup and adjust the Soy Milk and coagulant injecting quantity, mixing time, Tofu stirring time to increase Tofu production efficiency.
<G-vec00902-002-s359><adjust.werden><de> Tofu-Die Einspritzmenge für Sojamilch und Koagulans, Mischzeit, Tofu-Rührzeit können eingestellt und eingestellt werden, um die Tofu-Produktionseffizienz zu erhöhen.
<G-vec00902-002-s360><adjust.werden><en> This allows you to adjust the size of the projected image to the surface, without sacrificing any quality.
<G-vec00902-002-s360><adjust.werden><de> Hiermit kann die Größe des Bildes ohne Qualitätsverlust eingestellt werden.
<G-vec00902-002-s361><adjust.werden><en> The belt can be tensioned separately, and easy to adjust the level.
<G-vec00902-002-s361><adjust.werden><de> Der Riemen kann separat gespannt werden und das Niveau kann leicht eingestellt werden.
<G-vec00902-002-s362><adjust.werden><en> These parameters allow to adjust the reaction conditions exactly to the process medium and the targeted output.
<G-vec00902-002-s362><adjust.werden><de> Mit diesen Parametern können die Reaktionsbedingungen exakt auf das Prozessmedium und die angestrebte Leistung eingestellt werden.
<G-vec00902-002-s363><adjust.werden><en> Equipped with the variable spray nozzle FlexJet it is possible to adjust the application amount and the width of the spray jet individually.
<G-vec00902-002-s363><adjust.werden><de> Pre-fill Premium ist mit dem variablen Sprühkopf FlexJet ausgestattet, womit Ausbringmenge und Sprühstrahlbreite je nach Bedarf individuell eingestellt werden können.
<G-vec00902-002-s364><adjust.werden><en> If for any reason the Customer does not know how to use or adjust the products correctly, the Customer must send a written request to COUTH for more information and/or explanatory leaflets for this purpose.
<G-vec00902-002-s364><adjust.werden><de> Wenn der Kunde aus irgendeinem Grund nicht weiß, wie die Produkte korrekt verwendet oder eingestellt werden, muss der Kunde eine schriftliche Anfrage an COUTH senden, um weitere Informationen und/oder erklärende Broschüren zu diesem Zweck zu erhalten.
<G-vec00902-002-s365><adjust.werden><en> Through the loading and unloading gate can adjust the material flow.
<G-vec00902-002-s365><adjust.werden><de> Durch das Lade- und Entlade-Tor kann der Materialfluss eingestellt werden.
<G-vec00902-002-s366><adjust.werden><en> You can also adjust the cold tire color.
<G-vec00902-002-s366><adjust.werden><de> Die Farbe der kalten Reifen kann ebenfalls eingestellt werden.
<G-vec00902-002-s367><adjust.werden><en> A mechanical spring allows the user to adjust the pressure of the backrest to his or her own individual needs.
<G-vec00902-002-s367><adjust.werden><de> Über eine mechanische Feder kann der Andruck der Rückenlehne individuell an das jeweilige Bedürfnis des Benutzers eingestellt werden.
