<G-vec00380-003-s475><close_out.schließen><en> To contact your fairy hold the pendant in your hand, close your eyes and meditate for a few minutes about the guidance or help you need.
<G-vec00380-003-s475><close_out.schließen><de> Um die Elfe zu kontaktieren, halte ihr Abbild in Deinen Händen, schließe die Augen und meditiere einige Minuten über die Führung oder Hilfestellung, die Du benötigst.
<G-vec00380-003-s476><close_out.schließen><en> ⇒ Once the glass jar is full, fill with distilled water until all the shredded cabbage is covered and top with the two cabbage leaves, close the lid.
<G-vec00380-003-s476><close_out.schließen><de> ⇒ Wenn der Glaskrug gefüllt und zusammen gepresst ist, fülle ihn mit dem destillierten Wasser auf, füge die noch ganzen Blätter hinzu und schließe das Ganze mit dem Deckel.
<G-vec00380-003-s477><close_out.schließen><en> Rooms How can I close the bottom of the bath.
<G-vec00380-003-s477><close_out.schließen><de> Zimmer Wie schließe ich den Boden des Bades.
<G-vec00380-003-s478><close_out.schließen><en> Close your eyes and flip a coin.
<G-vec00380-003-s478><close_out.schließen><de> Schließe deine Augen und wirf eine Münze.
<G-vec00380-003-s479><close_out.schließen><en> Aham Brahma Asmi and Tat Tvam Asi. your Ishta Devata for a few minutes and close your eyes.
<G-vec00380-003-s479><close_out.schließen><de> Betrachte das Bild deiner persönlichen Gottheit (IshtaDevata) ein paar Minuten lang und schließe die Augen.
<G-vec00380-003-s480><close_out.schließen><en> Train your fighter, master blows and receptions, engage with faceless enemies and close a gate of shadows in Shadow fight 2.
<G-vec00380-003-s480><close_out.schließen><de> Trainiere deinen Kämpfer, erlerne Schläge und Techniken, bekämpfe die gesichtslosen Feinde und schließe das Schattentor im Spiel Shadow fight 2.
<G-vec00380-003-s481><close_out.schließen><en> If possible, close your eyes for a moment and ask what it is.
<G-vec00380-003-s481><close_out.schließen><de> 5Wenn möglich, schließe deine Augen einen Augenblick und frage, was es ist.
<G-vec00380-003-s482><close_out.schließen><en> Must last until I close December.
<G-vec00380-003-s482><close_out.schließen><de> Muss reichen, bis ich Dezember schließe.
<G-vec00380-003-s483><close_out.schließen><en> Close your eyes, shut out the rest of the world, and think about your affirmations.
<G-vec00380-003-s483><close_out.schließen><de> Schließe Deine Augen, ziehe Dich vom Rest der Welt zurück und denke über Deine Affirmationen nach.
<G-vec00380-003-s484><close_out.schließen><en> To resolve this issue, please close and restart Destiny to initiate your update.
<G-vec00380-003-s484><close_out.schließen><de> Um diesen Fehler zu beheben, schließe Destiny und starte es erneut, um das Update zu beginnen.
<G-vec00380-003-s485><close_out.schließen><en> 6 Add the right kind of washing fluid and close the door.
<G-vec00380-003-s485><close_out.schließen><de> Gib die richtige Art von Waschmittel in die Trommel und schließe die Tür.
<G-vec00380-003-s486><close_out.schließen><en> 6 Close the Settings tab.
<G-vec00380-003-s486><close_out.schließen><de> Schließe den Tab "Einstellungen".
<G-vec00380-003-s487><close_out.schließen><en> I will close with another example of institutionalized "intersectional" feminism in action: Alicia's Iraqi parents took her to Sweden when she was four.
<G-vec00380-003-s487><close_out.schließen><de> Ich schließe mit einem weiteren Beispiel für institutionalisierten "intersektionellen" Feminismus in Aktion: Alicias irakische Eltern brachten sie mit vier Jahren nach Schweden.
<G-vec00380-003-s488><close_out.schließen><en> I sit in the open jeep and close my eyes for a moment.
<G-vec00380-003-s488><close_out.schließen><de> Ich sitze im offenen Jeep und schließe für einen Moment die Augen.
<G-vec00380-003-s489><close_out.schließen><en> When you wake up and remember your dream, write it down in your dream journal, then close your eyes and focus on the dream.
<G-vec00380-003-s489><close_out.schließen><de> Wenn du aufwachst und dich an deinen Traum erinnerst, dann schreibe es in deinem Traumtagebuch auf, schließe dann die Augen erneut und konzentriere dich auf den Traum.
<G-vec00380-003-s490><close_out.schließen><en> Click on the Facebook share icon and remember to close the window that now opens.
<G-vec00380-003-s490><close_out.schließen><de> Klick auf die Teilen-Funktion für Facebook, schließe das sich öffnende Fenster aber wieder.
<G-vec00380-003-s491><close_out.schließen><en> Before I close I will give you a loose guideline for a happily abundant life.
<G-vec00380-003-s491><close_out.schließen><de> Bevor ich schließe, werde euch eine lose Leitlinie für ein glückliches Leben der Fülle geben.
<G-vec00380-003-s492><close_out.schließen><en> Close the door as much as possible and look for uneven lines.
<G-vec00380-003-s492><close_out.schließen><de> Schließe die Tür so weit es eben geht und schau nach Unebenheiten.
<G-vec00380-003-s493><close_out.schließen><en> Now, close your eyes (after you're done reading this) and imagine Hollywood movie sets, beautiful historic districts, or foreign and exotic locales teeming with vibrant and interesting people who hang on your every word.
<G-vec00380-003-s493><close_out.schließen><de> Schließe nun die Augen (nachdem du den Artikel zu Ende gelesen hast) und stell dir die Kulissen in Hollywood vor, schöne historische Stadtteile, oder fremde und exotische Lokalitäten, voll lebendiger und interessanter Leute, die an deinen Lippen hängen.
<G-vec00380-003-s589><close_out.verschließen><en> Later on, after Sora, Donald, and Goofy defeat Ansem and attempt to close the door to Kingdom Hearts, King Mickey finally reappears with the Kingdom Key D, the Keyblade of the Realm of Darkness that he had gone to search for.
<G-vec00380-003-s589><close_out.verschließen><de> Nachdem Ansem, jener der die Dunkelheit sucht, besiegt ist, hilft er Sora Kingdom Hearts zu verschließen, in dem er erst die Herzlosen im Reich der Dunkelheit aufhält und danach mit Sora gemeinsam die Tür zur Dunkelheit von beiden Seiten verschließt.
<G-vec00380-003-s590><close_out.verschließen><en> They were used to close the garments in front of the neck.
<G-vec00380-003-s590><close_out.verschließen><de> Sie wurden verwendet, um die Halsöffnungen der Gewänder zu verschließen.
<G-vec00380-003-s591><close_out.verschließen><en> The energy Jennifer has invested in Space Between speaks to her conviction that growing numbers of people share her refusal to close their eyes to the realities of consumer industries.
<G-vec00380-003-s591><close_out.verschließen><de> Die Energie, die Jennifer in das Projekt Space Between investiert, rührt aus ihrer Überzeugung, dass es immer mehr Menschen gibt, die wie sie nicht die Augen vor den Zuständen in der Konsumgüterindustrie verschließen wollen.
<G-vec00380-003-s592><close_out.verschließen><en> To close this little slot is almost impossible, and I think that most KS fans do not know that there is such a milling in the bearing shield.
<G-vec00380-003-s592><close_out.verschließen><de> Diese kleine Schlitzfräsung zu verschließen ist so gut wie unmöglich und ich glaube das die meisten KS-Fans überhaupt nicht wissen dass es solch eine Fräsung im Lagerschild gibt.
<G-vec00380-003-s593><close_out.verschließen><en> It is also important that ospreys in diving into water when necessary can close their nostrils that are visible on the beak.
<G-vec00380-003-s593><close_out.verschließen><de> Es ist auch wichtig, dass Fischadler beim Eintauchen ins Wasser wenn nötig ihre Nasenlöcher, die auf dem Schnabel zu sehen sind, verschließen können.
<G-vec00380-003-s594><close_out.verschließen><en> To close a 16 mm PE pipe.
<G-vec00380-003-s594><close_out.verschließen><de> Zum verschließen eines 16 mm PE-Rohres.
<G-vec00380-003-s595><close_out.verschließen><en> So it does not help to close your eyes, to sweep something under the carpet or to avoid the problem.
<G-vec00380-003-s595><close_out.verschließen><de> Es hilft also nichts, die Augen zu verschließen, etwas unter den Teppich zu kehren oder dem Problem auszuweichen.
<G-vec00380-003-s596><close_out.verschließen><en> Hot melt and cold adhesive solutions are available to meet the needs of bag and sack construction as well as application of adhesives to be reactived to seal / close a bag after filling.
<G-vec00380-003-s596><close_out.verschließen><de> Wir bieten Schmelzklebstoff‑ und Kaltleimlösungen, die sowohl zur Herstellung von Beuteln und Taschen als auch zum Klebstoffauftrag zum Abdichten/Verschließen eines Beutels nach der Befüllung dienen.
<G-vec00380-003-s597><close_out.verschließen><en> Put the compound back into its re-sealable packaging and close it carefully to ensure the compound remains fresh.
<G-vec00380-003-s597><close_out.verschließen><de> Legen Sie die Masse zurück in die Packung, und verschließen Sie diese sorgfältig, damit die Masse nicht austrocknet.
<G-vec00380-003-s598><close_out.verschließen><en> To close the filling hole we use sealing plugs suitable to Epson cartridges.
<G-vec00380-003-s598><close_out.verschließen><de> Sie können die bei Octopus erhältlichen Verschlussstopfen für Epson Patronen zum Verschließen der Epson 24 oder Epson 26 Patronen verwenden.
<G-vec00380-003-s599><close_out.verschließen><en> Universality does away with the limits that close the world in and create differences and conflicts.
<G-vec00380-003-s599><close_out.verschließen><de> Die Universalität öffnet die Grenzen, die die Welt verschließen und Gegensätze und Konflikte schaffen.
<G-vec00380-003-s600><close_out.verschließen><en> You can close your tea maker with a stopper made of natural bamboo.
<G-vec00380-003-s600><close_out.verschließen><de> Mit einem Stopfen aus Naturbambus kannst du deinen Teebereiter verschließen.
<G-vec00380-003-s601><close_out.verschließen><en> Draco gave me a penetrating look, which told me what he thought about it; that they were blind ignorant morons to close their eyes against the facts that the Dark Lord was back.
<G-vec00380-003-s601><close_out.verschließen><de> Draco warf mir einen durchdringenden Blick zu, der besagte was die anderen doch für blinde Ignoranten waren, die Augen davor zu verschließen, dass der Dark Lord zurück war.
<G-vec00380-003-s602><close_out.verschließen><en> Depending on your material, you may have to close the ring past the final position you want, then bring it back.
<G-vec00380-003-s602><close_out.verschließen><de> Je nach Material musst du den Ring möglicherweise hinter der gewünschten Position verschließen und danach den Verschluss etwas zurückbiegen.
<G-vec00380-003-s603><close_out.verschließen><en> CONCEPT All those curious about Paul Celan´s life and work will find it intricate and dark: “historically dark” because Paul Celan (1920 – 1970) experienced the atrocities of the Third Reich and its aftermath; “personally dark” because the poet constantly tried to close himself off to he outside world.
<G-vec00380-003-s603><close_out.verschließen><de> Schwer fassbar und dunkel liegen das Leben und Werk des Dichters Paul Celan (1920 – 1970) vor demjenigen, der sich ihm zu nähern versucht: „Historisches Dunkel“ der entsetzlichen Verbrechen des „Dritten Reiches“ und deren Folgen, „persönliches Dunkel“ im Leben des Dichters, das er stets vor der Außenwelt zu verschließen suchte und schließlich das außergewöhnliche, tiefe und komplexe Dunkel seiner Dichtung, zu derer Entschlüsselung bis heute immer wieder neue Zugänge gesucht werden.
<G-vec00380-003-s604><close_out.verschließen><en> Close the bottle with measuring cap and shake to homogenize the solution.
<G-vec00380-003-s604><close_out.verschließen><de> Verschließen Sie die Flasche mit Messkappe und schütteln, um die Lösung zu homogenisieren.
<G-vec00380-003-s605><close_out.verschließen><en> The doors close the compartment in which the stereo and home cinema devices are hidden. Such doors are equipped with special cylinder hinges thanks to which they can be opened 180°.
<G-vec00380-003-s605><close_out.verschließen><de> Die Flügel verschließen den Schrank, in welchem die Stereoanlage und das Home Cinema versteckt sind: diese sind mit speziellen Zylinderscharnieren ausgestattet, welche ein Öffnen zu 180° ermöglichen.
<G-vec00380-003-s606><close_out.verschließen><en> The distance from the end becomes smaller and smaller; the signs will increase, and the recognizing and the believing is made easy for everyone with that; and so the will of man is good, he will also not resist and close his mind to these references.
<G-vec00380-003-s606><close_out.verschließen><de> Der Abstand vom Ende wird immer kleiner, die Zeichen werden sich mehren, und einem jeden wird dadurch das Erkennen und das Glauben leichtgemacht; und so der Wille des Menschen gut ist, wird er sich auch nicht sträuben und sich diesen Hinweisen verschließen.
<G-vec00380-003-s607><close_out.verschließen><en> A serious examination would convince them, that your knowledge cannot simple be rejected, because it holds deep truths, because they could not close their minds to the logical conclusions, which show a giver, who knows about everything and for that reason can also give complete enlightenment.
<G-vec00380-003-s607><close_out.verschließen><de> Eine ernsthafte Prüfung würde sie überzeugen, daß euer Wissen nicht einfach abgelehnt werden kann, weil es tiefe Wahrheiten birgt, weil sie sich den logischen Folgerungen nicht verschließen könnten, die einen Geber verraten, Der um alles weiß und darum auch lückenlos Aufklärung geben kann.
<G-vec00198-002-s266><close_out.schließen><en> 12 of 35 Skiing in Cloudy or Windy Conditions (1) there is nowhere to ski when it is windy or visibility is bad and lifts often shut, (3) there are some trees for poor visibility but main lifts sometimes close, (5) Seefin (Monavullagh) is mostly in forest where you can ski in flat-light and windy days, lifts rarely close.
<G-vec00198-002-s266><close_out.schließen><de> 12 of 35 Skifahren bei Regen und Wind (1) es gibt nirgendwo eine Piste zum Skifahren, wenn es windig ist oder die Sicht schlecht ist sind die Lifts sind oft geschlossen, (3) einige Bäume, die für eine schlechte Sicht sorgen aber Lifts sind manchmal geschlossen, (5) Maverick Mountain ist meist im Wald, wo man an einfachen und windigen Tagen, Skifahren kann Aufzüge sind selten in der nahe.
<G-vec00198-002-s267><close_out.schließen><en> April and May are probably the least optimal months to go since many camps close during the long rains. However, there are still enough places open for us to put together a magnificent itinerary for you if those months are your only option.
<G-vec00198-002-s267><close_out.schließen><de> Zwar haben viele Camps während der Regenzeit im April und Mai geschlossen, aber es sind oft genügend Plätze offen, die es uns ermöglichen, einen großartigen Reiseplan für Sie auszuarbeiten, wenn diese Monate Ihre einzige Option darstellen.
<G-vec00198-002-s268><close_out.schließen><en> But to depart entirely without faith from earth is a hopeless state and will end with renewed banishment, because the gates of the beyond will close the moment the old earth is dissolved.
<G-vec00198-002-s268><close_out.schließen><de> Doch ganz ohne Glauben abzuscheiden von der Erde ist hoffnungslos und endet mit der Neubannung, weil das Jenseits die Tore geschlossen hat mit dem Moment des Auflösens der alten Erde.
<G-vec00198-002-s269><close_out.schließen><en> You’re good to fully close the windows now.
<G-vec00198-002-s269><close_out.schließen><de> Nun können die Fenster geschlossen werden.
<G-vec00198-002-s270><close_out.schließen><en> While windows tend to remain closed, doors are obliged to open and close several times each day for a building to function.
<G-vec00198-002-s270><close_out.schließen><de> Fenster können geschlossen bleiben, doch Türen müssen täglich viele Male geöffnet und geschlossen werden, damit ein Gebäude seine Funktion erfüllen kann.
<G-vec00198-002-s271><close_out.schließen><en> "12sync.exe has encountered a problem and needs to close.
<G-vec00198-002-s271><close_out.schließen><de> "4DIRSIZE.EXE hat ein Problem und muss geschlossen werden.
<G-vec00198-002-s272><close_out.schließen><en> 12 of 35 Skiing in Cloudy or Windy Conditions (1) there is nowhere to ski when it is windy or visibility is bad and lifts often shut, (3) there are some trees for poor visibility but main lifts sometimes close, (5) Strynefjellet is mostly in forest where you can ski in flat-light and windy days, lifts rarely close.
<G-vec00198-002-s272><close_out.schließen><de> 12 of 35 Skifahren bei Regen und Wind (1) es gibt nirgendwo eine Piste zum Skifahren, wenn es windig ist oder die Sicht schlecht ist sind die Lifts sind oft geschlossen, (3) einige Bäume, die für eine schlechte Sicht sorgen aber Lifts sind manchmal geschlossen, (5) Les Genevez ist meist im Wald, wo man an einfachen und windigen Tagen, Skifahren kann Aufzüge sind selten in der nahe.
<G-vec00198-002-s273><close_out.schließen><en> In the early afternoon, the West Berlin police close the permit offices at the order of all three Western city commanders.
<G-vec00198-002-s273><close_out.schließen><de> Am frühen Nachmittag werden die Passierscheinstellen auf Weisung aller drei westlichen Stadtkommandanten durch die West-Berliner Polizei geschlossen.
<G-vec00198-002-s274><close_out.schließen><en> CLOSE the shut-off valves at the end of each wash day.
<G-vec00198-002-s274><close_out.schließen><de> Am Ende jedes Waschtages müssen die Absperrventile GESCHLOSSEN werden.
<G-vec00198-002-s275><close_out.schließen><en> Many of us – gay, lesbian, feminist – had to give up already and close shop.
<G-vec00198-002-s275><close_out.schließen><de> Viele von uns – schwul, lesbisch, feministisch – haben bereits aufgegeben und wieder geschlossen.
<G-vec00198-002-s276><close_out.schließen><en> In the late seventies, the Glasgow MTC had to close down due to its limited accommodation.
<G-vec00198-002-s276><close_out.schließen><de> In den späten siebziger Jahren musste der Glasgow MTC wegen seiner begrenzten Unterkunft geschlossen werden.
<G-vec00198-002-s277><close_out.schließen><en> Shelter: 5.0 (1) there is nowhere to ski when it is windy or visibility is bad and lifts often shut, (3) there are some trees for poor visibility but main lifts sometimes close, (5) Correncon en Vercors is mostly in forest where you can ski in flat-light and windy days, lifts rarely close.
<G-vec00198-002-s277><close_out.schließen><de> Schutz: 5.0 (1) es gibt nirgendwo eine Piste zum Skifahren, wenn es windig ist oder die Sicht schlecht ist sind die Lifts sind oft geschlossen, (3) einige Bäume, die für eine schlechte Sicht sorgen aber Lifts sind manchmal geschlossen, (5) Bromley Mountain ist meist im Wald, wo man an einfachen und windigen Tagen, Skifahren kann Aufzüge sind selten in der nahe.
<G-vec00198-002-s278><close_out.schließen><en> The exhibition and or tour may close occasionally for rehearsals, performances, and events which may not be listed on this website.
<G-vec00198-002-s278><close_out.schließen><de> Die Ausstellung und / oder Tour kann gelegentlich für Proben, Aufführungen und Veranstaltungen geschlossen werden, die auf dieser Website nicht aufgeführt sind.
<G-vec00198-002-s279><close_out.schließen><en> The print paper setting is initialized two minutes after you close the door.
<G-vec00198-002-s279><close_out.schließen><de> VORBEREITUNGEN Zwei Sekunden, nachdem Sie die Tür geschlossen haben, wird die DruckpapierEinstellung initialisiert.
<G-vec00198-002-s280><close_out.schließen><en> 12 of 35 Skiing in Cloudy or Windy Conditions (1) there is nowhere to ski when it is windy or visibility is bad and lifts often shut, (3) there are some trees for poor visibility but main lifts sometimes close, (5) Dave Henry Lodge is mostly in forest where you can ski in flat-light and windy days, lifts rarely close.
<G-vec00198-002-s280><close_out.schließen><de> 12 of 35 Skifahren bei Regen und Wind (1) es gibt nirgendwo eine Piste zum Skifahren, wenn es windig ist oder die Sicht schlecht ist sind die Lifts sind oft geschlossen, (3) einige Bäume, die für eine schlechte Sicht sorgen aber Lifts sind manchmal geschlossen, (5) Dave Henry Lodge ist meist im Wald, wo man an einfachen und windigen Tagen, Skifahren kann Aufzüge sind selten in der nahe.
<G-vec00198-002-s281><close_out.schließen><en> Also, of the around 600 legal waste dumps in the country, at least 300 will have to close in the coming years, either because they do not conform to EU standards or because they have reached their capacity limits.
<G-vec00198-002-s281><close_out.schließen><de> Von den rund 600 legalen Müllhalden des Landes müssen in den kommenden Jahren mindestens 300 geschlossen werden, da sie entweder die EU-Normen nicht erfüllen oder keine weiteren Abfälle mehr aufnehmen können.
<G-vec00198-002-s282><close_out.schließen><en> 12 of 35 Skiing in Cloudy or Windy Conditions (1) there is nowhere to ski when it is windy or visibility is bad and lifts often shut, (3) there are some trees for poor visibility but main lifts sometimes close, (5) Val Thorens is mostly in forest where you can ski in flat-light and windy days, lifts rarely close.
<G-vec00198-002-s282><close_out.schließen><de> 12 of 35 Skifahren bei Regen und Wind (1) es gibt nirgendwo eine Piste zum Skifahren, wenn es windig ist oder die Sicht schlecht ist sind die Lifts sind oft geschlossen, (3) einige Bäume, die für eine schlechte Sicht sorgen aber Lifts sind manchmal geschlossen, (5) Goderdzi ist meist im Wald, wo man an einfachen und windigen Tagen, Skifahren kann Aufzüge sind selten in der nahe.
<G-vec00198-002-s283><close_out.schließen><en> With the first stage completed, the south wing will then close for renovation and construction on the new fourth wing will commence.
<G-vec00198-002-s283><close_out.schließen><de> Danach wird der Südflügel für seine Sanierung und die Errichtung des vierten Flügels geschlossen.
<G-vec00198-002-s284><close_out.schließen><en> Imagine how many museums it would be necessary to close, how many musical groups it would be necessary to silence; Galileo and Darwin would have had to abandon their research, and Monty Python would not have been able to film The Life of Brian.
<G-vec00198-002-s284><close_out.schließen><de> Stellen Sie sich einmal vor, wie viele Museen geschlossen werden müssten, wie viele Musikgruppen zum Schweigen gebracht; Galileo oder Darwin hätten ihre Forschungen aufgeben müssen und Monty Python hätte nicht Das Leben des Brian drehen können.
<G-vec00198-002-s494><close_out.schließen><en> The upcoming twelfth Tolkien Seminar of the German Tolkien Society is set to close this gap with a variety of papers.
<G-vec00198-002-s494><close_out.schließen><de> Dem wird das kommende zwölfte Tolkien-Seminar der Deutschen Tolkien Gesellschaft mit einer Reihe von Vorträgen nachkommen, die diese Lücke schließen helfen.
<G-vec00198-002-s495><close_out.schließen><en> Open the lid of the ground coffee chute for at least 5 seconds and then close it again.
<G-vec00198-002-s495><close_out.schließen><de> Öffnen Sie den Deckel des Pulverschachts für mindestens 5 Sekunden und schließen Sie ihn danach wieder.
<G-vec00198-002-s496><close_out.schließen><en> Close the doors of the car and after a few minutes all the contents inside the car have been emptied.
<G-vec00198-002-s496><close_out.schließen><de> Türen des Wagens schließen und nach wenigen Minuten hat sich der gesamte Inhalt im Wageninneren entleert.
<G-vec00198-002-s497><close_out.schließen><en> Setup is complete now and you can go to the Garmin portal to get familiar with the program and to enter your personal settings, or you can close the window.
<G-vec00198-002-s497><close_out.schließen><de> Die Konfiguration ist abgeschlossen und Sie können jetzt zum Garmin Portal gehen und sich mit dem Programm vertraut machen sowie Ihre individuellen Einstellungen vornehmen oder das Fenster schließen.
<G-vec00198-002-s498><close_out.schließen><en> The owners of Mantic Forums reserve the right to remove, edit, move or close any content item for any reason. Contact Us Mantic Games
<G-vec00198-002-s498><close_out.schließen><de> Die Eigentümer von STAR TREK Online Info - Das Deutsche STO Community Forum haben das Recht, Themen und Beiträge zu löschen, zu bearbeiten, zu verschieben oder zu schließen.
<G-vec00198-002-s499><close_out.schließen><en> The titanic three—Google, Facebook and Apple—have access to most of that data, and their army of engineers still haven’t managed to completely close that gap.
<G-vec00198-002-s499><close_out.schließen><de> Obwohl die drei Giganten Google, Facebook und Apple Zugriff auf einen Großteil dieser Daten haben, hat es ihr Heer an Ingenieuren immer noch nicht fertig gebracht, diese Lücke vollständig zu schließen.
<G-vec00198-002-s500><close_out.schließen><en> Close straps prior to washing.
<G-vec00198-002-s500><close_out.schließen><de> Verschlüsse zum Waschen schließen.
<G-vec00198-002-s501><close_out.schließen><en> When the plants grow to a height of 10 cm, they need to mow and close up in the soil.
<G-vec00198-002-s501><close_out.schließen><de> Wenn die Pflanzen eine Höhe von 10 cm erreichen, müssen sie im Boden mähen und sich schließen.
<G-vec00198-002-s502><close_out.schließen><en> (2) The users oblige to close contracts only through BAGEMA.
<G-vec00198-002-s502><close_out.schließen><de> (2) Die Nutzer verpflichten sich Verträge nur über BAGEMA zu schließen.
<G-vec00198-002-s503><close_out.schließen><en> The owners of RC Forumz - Dedicated to RC Discussions reserve the right to remove, edit, move or close any content item for any reason.
<G-vec00198-002-s503><close_out.schließen><de> Die Eigentümer von Bym.de-Community haben das Recht, Themen und Beiträge zu löschen, zu bearbeiten, zu verschieben oder zu schließen.
<G-vec00198-002-s504><close_out.schließen><en> The owners of this forum reserve the right to remove, edit, move or close any thread for any reason.
<G-vec00198-002-s504><close_out.schließen><de> Die Eigentümer von GIMP-Forum 3.0 haben das Recht, Themen und Beiträge zu löschen, zu bearbeiten, zu verschieben oder zu schließen.
<G-vec00198-002-s505><close_out.schließen><en> After the digital revolution, these companies were not able to compete against digital TV and online videos and had to close one after the other.
<G-vec00198-002-s505><close_out.schließen><de> Nach der digitalen Revolution (digitales Fernsehen und Online-Videos) waren diese Betriebe nicht mehr konkurrenzfähig und mussten nach und nach schließen.
<G-vec00198-002-s506><close_out.schließen><en> To contact emergency services providers from your device, close Lync for iPad, and use your device’s dial pad.
<G-vec00198-002-s506><close_out.schließen><de> Schließen Sie zum Kontaktieren eines Anbieters für Notfalldienste Lync für iPhone, und verwenden Sie die Wähltastatur Ihres Geräts.
<G-vec00198-002-s507><close_out.schließen><en> Allthough we never had to overcome a step when we had to get to the toilets it has been really narrow every single time. I really did need help because there were no handholds and I could not get into the toilet with my wheelchair because then I could not close the door anymore.
<G-vec00198-002-s507><close_out.schließen><de> Man musste zwar nie eine Stufe überwinden - zum Glück - aber es war eng und ich war immer auf Hilfe angewiesen denn es gab auch keine Haltegriffe und ich konnte nicht direkt zum WC reinfahren denn dann hätte man die Türe nicht mehr schließen können.
<G-vec00198-002-s508><close_out.schließen><en> As an emissions-free, purely electric-driven car sharing solution, SVEN should close the gap between personal and public transportation.
<G-vec00198-002-s508><close_out.schließen><de> Es soll als emissionsfreie, rein elektrische betriebene Carsharing-Lösung die Lücke zwischen Individual- und öffentlichem Personennahverkehr schließen.
<G-vec00198-002-s509><close_out.schließen><en> To do this, open OneNote 2016 for Windows, click the arrow next to your notebook name, find the notebook you deleted, right-click it, and choose Close This Notebook.
<G-vec00198-002-s509><close_out.schließen><de> Dazu öffnen Sie OneNote 2016 für Windows, klicken Sie auf den Pfeil neben dem Notizbuchnamen, suchen Sie das Notizbuch, das Sie gelöscht haben, klicken Sie mit der rechten Maustaste darauf, und wählen Sie Dieses Notizbuch schließen aus.
<G-vec00198-002-s510><close_out.schließen><en> You will have to close all the necessary facilities: Commercial Centre La Valentine, Restaurants, Cinema, Pub and small businesses (bakery, et accueil parfait .
<G-vec00198-002-s510><close_out.schließen><de> Sie haben alle notwendigen Einrichtungen zu schließen: Einkaufszentrum La Valentine, Restaurants, Kino, Pub und kleine Unternehmen (Bäckerei, Kiosk,...) und in der Nähe von Scharen von kleinen Dörfern der Provence: Aubagne (Stadt von Marcel Pagnol) Allauch....
<G-vec00198-002-s511><close_out.schließen><en> Use the ◄/► buttons for adjustment. To close the dialog and complete this operation, press KEYSTONE button again.
<G-vec00198-002-s511><close_out.schließen><de> Verwenden Sie die Cursortasten ▲/▼zur Korrektur der Verzerrung.Drücken Sie die KEYSTONE-Taste erneut zum Schließen des Dialogs und Beenden dieses Vorgangs.
<G-vec00198-002-s512><close_out.schließen><en> FileMaker Pro Advanced allows you to prompt networked clients to close the shared file when you close the file, change the sharing conditions for the file, exit FileMaker Pro Advanced, or perform a task that requires all clients to close the file.
<G-vec00198-002-s512><close_out.schließen><de> FileMaker Pro gibt Ihnen die Möglichkeit, Clients im Netzwerk aufzufordern, die gemeinsam genutzte Datei zu schließen, wenn Sie die Datei schließen, die Sharing-Voraussetzungen für die Datei ändern, FileMaker Pro beenden oder eine Aufgabe ausführen, für die alle Clients die Datei schließen müssen.
<G-vec00198-002-s513><close_out.schließen><en> Close the roulade.
<G-vec00198-002-s513><close_out.schließen><de> Schließen Sie die Roulade.
<G-vec00198-002-s514><close_out.schließen><en> Close the flag design without saving any changes.
<G-vec00198-002-s514><close_out.schließen><de> Schließen Sie den „Flag“-Entwurf, ohne Änderungen zu speichern.
<G-vec00198-002-s515><close_out.schließen><en> C Close the scanner unit .
<G-vec00198-002-s515><close_out.schließen><de> D Schließen Sie langsam die Scannereinheit.
<G-vec00198-002-s516><close_out.schließen><en> Close the window "Prioritize Application".
<G-vec00198-002-s516><close_out.schließen><de> Schließen Sie das Fenster "Belegwünsche priorisieren".
<G-vec00198-002-s517><close_out.schließen><en> Open and close the front cover to resume printing.
<G-vec00198-002-s517><close_out.schließen><de> Öffnen und schließen Sie die obere Abdeckung, und öffnen Sie dann schnell das Ausgabefach.
<G-vec00198-002-s518><close_out.schließen><en> Close the box and tape it securely.
<G-vec00198-002-s518><close_out.schließen><de> Schließen Sie den Karton und kleben Sie ihn mit Klebeband sicher zu.
<G-vec00198-002-s519><close_out.schließen><en> Send a document from Paris, sign it in Tokyo, and close business in minutes.
<G-vec00198-002-s519><close_out.schließen><de> Versenden Sie ein Dokument aus Paris, unterschreiben Sie es in Tokio oder San Francisco und schließen Sie Geschäfte in Minuten ab.
<G-vec00198-002-s520><close_out.schließen><en> Close the Programs window, and the Control Panel window.
<G-vec00198-002-s520><close_out.schließen><de> Schließen Sie das Fenster Software und die Systemsteuerung.
<G-vec00198-002-s521><close_out.schließen><en> Close User Manager.
<G-vec00198-002-s521><close_out.schließen><de> Schließen Sie den Benutzer-Manager.
<G-vec00198-002-s522><close_out.schließen><en> Close the window Local Security Policy (Windows Vista) / Local Security Settings (Windows XP).
<G-vec00198-002-s522><close_out.schließen><de> Schließen Sie das Fenster Lokale Sicherheitsrichtlinie (Windows Vista) / Lokale Sicherheitseinstellungen (Windows XP).
<G-vec00198-002-s523><close_out.schließen><en> Place the grow kit without the lid inside the plastic bag and close the bag by folding the top, you can fasten this with the 2 paperclips.
<G-vec00198-002-s523><close_out.schließen><de> Legen Sie den Cubenisanbaukasten ohne den Deckel innerhalb der Plastiktasche und schließen Sie die Tasche, indem Sie die Spitze falten; Sie können das mit 2 Hefklammern befestigen.
<G-vec00198-002-s524><close_out.schließen><en> Close the window when you are done.
<G-vec00198-002-s524><close_out.schließen><de> Schließen Sie das Fenster, wenn Sie fertig sind.
<G-vec00198-002-s525><close_out.schließen><en> Close the shutter by pulling at the key.
<G-vec00198-002-s525><close_out.schließen><de> Schließen Sie die Klappe, indem Sie am Schlüssel ziehen.
<G-vec00198-002-s526><close_out.schließen><en> Click "Ok" and close the Services app window.
<G-vec00198-002-s526><close_out.schließen><de> Klicken Sie auf "OK" und schließen Sie das Service-App-Fenster.
<G-vec00198-002-s527><close_out.schließen><en> Use our wire racks to keep your wine in order and close at hand.
<G-vec00198-002-s527><close_out.schließen><de> Benutzen Sie unsere Drahtgitter, um Ihren Wein im Auftrag zu halten und schließen Sie zur Hand.
<G-vec00198-002-s528><close_out.schließen><en> Close the dialog box.
<G-vec00198-002-s528><close_out.schließen><de> Schließen Sie das Dialogfeld.
<G-vec00198-002-s529><close_out.schließen><en> Close the Preferences window.
<G-vec00198-002-s529><close_out.schließen><de> Schließen Sie das Fenster Einstellungen.
<G-vec00198-002-s530><close_out.schließen><en> Now close the dialog box.
<G-vec00198-002-s530><close_out.schließen><de> Schließen Sie nun das Dialogfeld.
<G-vec00198-002-s531><close_out.schließen><en> Close the error message pop-up window and Qlik NPrinting Designer.
<G-vec00198-002-s531><close_out.schließen><de> Schließen Sie das Popup-Fenster mit der Fehlermeldung und Qlik NPrinting Designer.
<G-vec00198-002-s532><close_out.schließen><en> Close your earthly eyes and stop to search outside.
<G-vec00198-002-s532><close_out.schließen><de> Schließt eure irdischen Augen und sucht nicht mehr im Außen.
<G-vec00198-002-s533><close_out.schließen><en> The integration of entrustable professional activities (EPAs) in training and formative assessment may close the gap between the theory of competency-based training and the patient-centred practice in the clinical context [21], [30].
<G-vec00198-002-s533><close_out.schließen><de> Die Integration von anvertraubaren professionellen Tätigkeiten (APTs) als Basis für formative Prüfungen in der Weiterbildung schließt die Lücke zwischen der Theorie eines kompetenzbasierten Trainings und einer patientenzentrierten Umsetzung im klinischen Kontext [20], [30].
<G-vec00198-002-s534><close_out.schließen><en> In rare cases, if the zipper does not close after this treatment, it may be necessary to press the zipper helix (with the zipper open) carefully behind the zip using a pliers to close the beginning of the helix.
<G-vec00198-002-s534><close_out.schließen><de> In seltenen Fällen, falls der Reißverschluß nach dieser Behandlung nicht schließt, kann es notwendig sein, dass man die Spirale des Reißverschlusses (Reißverschluß in geöffnetem Zustand) hinter dem Schieber mit einer Zange vorsichtig zusammendrückt, damit ein geschlosssener Anfang der Spirale gegeben ist.
<G-vec00198-002-s535><close_out.schließen><en> The following quote taken from a theoretical text on haikus, can be applied directly to the work of both artists: ‘Explicit art that tries to tell us all that it means will close itself off within its own boundaries.
<G-vec00198-002-s535><close_out.schließen><de> Das folgende Zitat, das aus einem theoretischen Text über Haikus stammt, lässt sich eins zu eins auf die Arbeit der beiden Künstlerinnen übertragen: „Explizite Kunst, die alles zu sagen versucht, was sie bedeuten will, schließt sich selbst in ihre Grenzen ein.
<G-vec00198-002-s536><close_out.schließen><en> F10 – Open/close console/chat log.
<G-vec00198-002-s536><close_out.schließen><de> F10 – öffnet/schließt das Chat-Protokoll.
<G-vec00198-002-s537><close_out.schließen><en> After a complete body massage which relaxes your whole body, you close your eyes and warm oil will be poured on top of your forehead, releasing tension.
<G-vec00198-002-s537><close_out.schließen><de> Nach einer Ganzkörpermassage, die den kompletten Körper entspannt, schließt du deine Augen und genießt es, wie warmes Öl auf deine Stirn gegossen wird und dabei Anspannungen aller Art löst.
<G-vec00198-002-s538><close_out.schließen><en> The Egyptian Lotus symbol was used as a symbol of the Sun and the afterlife since it's flower buds rise to the surface of the water over a period of 2-3 days and when ready open in the morning and then close in the afternoon.
<G-vec00198-002-s538><close_out.schließen><de> Produktbeschreibung "Gegrüßt seiest du, Juwel im Lotus" Die Lotus Blume ist ein Symbol der Sonne, der Schöpfung und der Wiedergeburt, denn nachts schließt sich die Blume und sinkt unter Wasser und zur Dämmerung kommt sie wieder an die Oberfläche und öffnet sich erneut.
<G-vec00198-002-s539><close_out.schließen><en> Close the Product List form. OpenForm
<G-vec00198-002-s539><close_out.schließen><de> Schließt das Formular "Artikelliste".
<G-vec00198-002-s540><close_out.schließen><en> The fair will close at 5:00 p.m. on the last day of the show.
<G-vec00198-002-s540><close_out.schließen><de> Die Veranstaltung schließt am letzten Messetag bereits um 17:00 Uhr.
<G-vec00198-002-s541><close_out.schließen><en> Click OK to close the Create Rule dialog box.
<G-vec00198-002-s541><close_out.schließen><de> Schließt das Dialogfeld, ohne die Änderungen zu speichern.
<G-vec00198-002-s542><close_out.schließen><en> This cookie does not contain any personal data and is removed when you close the browser.
<G-vec00198-002-s542><close_out.schließen><de> Dieses Cookie enthält keine personenbezogenen Daten und wird verworfen, wenn du deinen Browser schließt.
<G-vec00198-002-s543><close_out.schließen><en> Thanks to the bituminous compound, SILENT FLOOR tends to close around the fastening system, ensuring watertightness in the event of leaks from systems, and it is extremely stable over time.
<G-vec00198-002-s543><close_out.schließen><de> Dank der bituminösen Verbindung schließt sich SILENT FLOOR um die Befestigungssysteme und garantiert Dichtigkeit im Fall von Systemverlusten, außerdem ist es dauerhaft stabil.
<G-vec00198-002-s544><close_out.schließen><en> Cancel will close the dialog without applying changes.
<G-vec00198-002-s544><close_out.schließen><de> Abbrechen Schließt die Dialogbox, verwirft aber die Änderungen.
<G-vec00198-002-s545><close_out.schließen><en> The gate will close behind you.
<G-vec00198-002-s545><close_out.schließen><de> Das Tor schließt sich hinter euch.
<G-vec00198-002-s547><close_out.schließen><en> Leave a little space before you close it and fill the drop with cotton wool.
<G-vec00198-002-s547><close_out.schließen><de> Bevor du sie schließt, lass eine kleine Lücke und füll den Tropfen mit Watte.
<G-vec00198-002-s548><close_out.schließen><en> If the water flows in the other direction, the valve would close and prevents that dirt is floating into the rainwater tank.
<G-vec00198-002-s548><close_out.schließen><de> Würde das Wasser entgegengesetzt fließen, schließt sich die Klappe und verhindert, dass Schmutz in den Regenspeicher fließt.
<G-vec00198-002-s549><close_out.schließen><en> Close your eyes, connect your heart to the Heart of the Planet and the Heart of the Universe.
<G-vec00198-002-s549><close_out.schließen><de> Schließt eure Augen, verbindet euer Herz mit dem Herzen des Planeten und dem Herzen des Universums.
<G-vec00198-002-s550><close_out.schließen><en> Check-in desks open 3 hours before departure and close 60 minutes before your flight departs.
<G-vec00198-002-s550><close_out.schließen><de> Der Check-in schließt 60 Minuten vor dem Abflug von Langstreckenflügen und 45 Minuten vor dem Abflug von Kurzstreckenflügen.
