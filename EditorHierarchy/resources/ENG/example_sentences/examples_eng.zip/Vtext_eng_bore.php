<G-vec00609-002-s266><bore.langweilen><en> Good stories must ‘ignite’, touch, amaze and never bore.
<G-vec00609-002-s266><bore.langweilen><de> Gute Geschichten müssen „zünden“, berühren, erstaunen, und sie dürfen auf keinen Fall langweilen.
<G-vec00609-002-s267><bore.langweilen><en> I’m afraid I might bore you to much.
<G-vec00609-002-s267><bore.langweilen><de> Ich fürchte, ich könnte Euch zu sehr langweilen.
<G-vec00609-002-s268><bore.langweilen><en> If you do your stuff and you start to bore you then synonymous of face to face "jump" and always nice to keep sharp dynamic.
<G-vec00609-002-s268><bore.langweilen><de> Wenn du das drauf hast und dich zu langweilen beginnst kannst du dann auch von Gesicht zu Gesicht "springen" und immer schön dynamisch scharf halten.
<G-vec00609-002-s269><bore.langweilen><en> Don’t worry, we'll make it short and won’t bore you with unimportant scientific details.
<G-vec00609-002-s269><bore.langweilen><de> Keine Angst, wir werden es kurz machen und Dich nicht mit unwichtigen wissenschaftlichen Details langweilen.
<G-vec00609-002-s270><bore.langweilen><en> "Alice caught actually to bore; it did not sit for a long time with its sister at the bank and had anything to do.
<G-vec00609-002-s270><bore.langweilen><de> "Alice fing an sich zu langweilen; sie saß schon lange bei ihrer Schwester am Ufer und hatte nichts zu tun.
<G-vec00609-002-s271><bore.langweilen><en> Firstly, and most crucially, we bore when we lose faith that it really could be our feelings that would stand the best chance of interesting others.
<G-vec00609-002-s271><bore.langweilen><de> Erstens, und das ist das Wichtigste, langweilen wir andere, wenn wir nicht mehr daran glauben, dass es unsere echten Gefühle sind, die andere Menschen am meisten interessieren.
<G-vec00609-002-s272><bore.langweilen><en> I don't want to bore you with details.
<G-vec00609-002-s272><bore.langweilen><de> Ich will euch nicht mit Einzelheiten langweilen.
<G-vec00609-002-s273><bore.langweilen><en> All the perfumes that are new on the market year after year, bore me.
<G-vec00609-002-s273><bore.langweilen><de> Alle Düfte, die Jahr für Jahr neu erscheinen, langweilen mich.
<G-vec00609-002-s274><bore.langweilen><en> We don’t want to bore you with classifications of wood types.
<G-vec00609-002-s274><bore.langweilen><de> Wir möchten Sie nicht mit Klassifizierungen von Holzsorten langweilen.
<G-vec00609-002-s275><bore.langweilen><en> Instead, they must bore their audience with "authenticity".
<G-vec00609-002-s275><bore.langweilen><de> Statt dessen sollen sie mit „Wahrheit” langweilen.
<G-vec00609-002-s276><bore.langweilen><en> I do not want to bore you with details.
<G-vec00609-002-s276><bore.langweilen><de> Ich will Dich nicht mit Details langweilen.
<G-vec00609-002-s277><bore.langweilen><en> The comedy of the game is also realized through the visual component: the animations of the characters offer the kind of exaggerated and silly combat that we want to see and never bore, for the duration of the title.
<G-vec00609-002-s277><bore.langweilen><de> Die Komödie des Spiels wird auch durch die visuelle Komponente realisiert: Die Animationen der Charaktere bieten die Art von übertriebenen und albernen Kämpfen, die wir sehen und niemals langweilen wollen, für die Dauer des Titels.
<G-vec00609-002-s278><bore.langweilen><en> Also, do not stay too long on one word, otherwise it can bore the child.
<G-vec00609-002-s278><bore.langweilen><de> Bleiben Sie auch nicht zu lange bei einem Wort, sonst kann es das Kind langweilen.
<G-vec00609-002-s279><bore.langweilen><en> It is not our intention to bore you with the local legislation, but to give short and simple answers on issues that might be of interest to you.
<G-vec00609-002-s279><bore.langweilen><de> Es ist nicht unsere Absicht, langweilen Sie mit der lokalen Gesetzgebung, sondern auch kurze und einfache Antworten auf Fragen, die für Sie von Interesse sein könnten zu geben.
<G-vec00609-002-s280><bore.langweilen><en> In this blog I don´t want to bore anyone with tourist details, but concentrate on the things that have to do with my artistic projects Today I talked with a few employees of TAV on various details of my projects.
<G-vec00609-002-s280><bore.langweilen><de> In diesem Blog will ich aber niemanden mit touristischen Details langweilen, sondern mich auf die Sachen konzentrieren, die mit meinen künstlerischen Projekten zu tun haben Heute mit ein paar Mitarbeiterinnen des TAV über verschiedene Details meiner Vorhaben gesprochen.
<G-vec00609-002-s281><bore.langweilen><en> Of course we brought home quite the pile of material, I don’t want to bore you with that.
<G-vec00609-002-s281><bore.langweilen><de> Wir haben natürlich wahnsinnig viel Material mit nach Hause genommen, damit möchte ich Euch aber nicht langweilen.
<G-vec00609-002-s282><bore.langweilen><en> I don’t want to bore readers who are less interested in technology with further details, so there is a more detailed technical part at the end of the blog entry.
<G-vec00609-002-s282><bore.langweilen><de> Ich möchte die weniger an Technik interessierten LeserInnen hier nicht mit weiteren Details langweilen, daher gibts am Ende des Blogeintrags einen ausführlicheren technischen Teil.
<G-vec00609-002-s283><bore.langweilen><en> • A whole bunch of little bug fixes that we won't bore you with.
<G-vec00609-002-s283><bore.langweilen><de> • Eine Reihe kleinerer Fehler, mit denen wir dich nicht langweilen wollen.
<G-vec00609-002-s284><bore.langweilen><en> We don’t want to bore you with a plain book or lecture.
<G-vec00609-002-s284><bore.langweilen><de> Wir wollen dich hier aber nicht mit einem nüchternen Buch oder Vortrag langweilen.
