<G-vec00427-002-s046><buzz_off.brummen><en> So the time capsules seem to be alive by those who can sense them, and they "buzz" with activity to the esoteric "see-er."
<G-vec00427-002-s046><buzz_off.brummen><de> Also, die Zeitkapseln scheinen für die zu leben, die sie wahrnehmen können, und sie "brummen" vor Aktivität für den esoterischen "Seh-her".
<G-vec00427-002-s047><buzz_off.brummen><en> The electrons will thus flow through the wire, making the buzzer buzz, until the piece of magnesium dissolves completely.
<G-vec00427-002-s047><buzz_off.brummen><de> Die Elektronen fließen also durch den Draht und lassen den Summer brummen, bis sich das Magnesiumstück vollständig auflöst.
<G-vec00427-002-s048><buzz_off.brummen><en> A weird room mode or modes making things uneven, over or under-trapping, noisy neighbors, electrical issues, equipment troubles, a weird rattle, a buzz – all these things impede the engineer’s and artists ability to let the outside world vanish and work on their art.
<G-vec00427-002-s048><buzz_off.brummen><de> Eine komische Raummode oder mehrere Moden die die Wiedergabe ungleichmäßig machen, zu starke oder zu schwache Dämpfung, laute Nachbarn, elektronische Probleme, Equipment Defekte, ein komisches Rasseln, ein Brummen, all diese Dinge erschweren es dem Engineer und dem Künstler die Außenwelt auszublenden und an ihrer Kunst zu arbeiten.
<G-vec00427-002-s049><buzz_off.brummen><en> Also reported neurological improvements, such as a decrease in dizziness or 'buzz' in his head and quicker speech.
<G-vec00427-002-s049><buzz_off.brummen><de> Er berichtete auch von neurologischen Verbesserungen, wie ein Rückgang seiner Schwindelanfälle oder des „Brummen“ im Kopf und er kann schneller sprechen.
<G-vec00427-002-s098><buzz_off.rauschen><en> Mostly Sativa in nature, she unloads a mind-bending buzz - sure to please Sativa lovers to no end.
<G-vec00427-002-s098><buzz_off.rauschen><de> Zum größten Teil Sativa in der Natur, entfesselt sie einen bewußtseinsverändernden Rausch der Sativaliebhaber ohne Ende erfreut.
<G-vec00427-002-s099><buzz_off.rauschen><en> Upon inhaling her smoke, you will at first enjoy a happy, cerebral buzz that slowly transitions into an awesome stone that relaxes your whole body.
<G-vec00427-002-s099><buzz_off.rauschen><de> Nach dem Einatmen ihres Rauchs wirst Du zuerst einen glücklichen, zerebralen Rausch genießen, der langsam in ein geiles Stoned-Sein übergeht, das Deinen ganzen Körper entspannt.
<G-vec00427-002-s100><buzz_off.rauschen><en> The long time toker will be impressed by the heavy mental buzz and length of effect.
<G-vec00427-002-s100><buzz_off.rauschen><de> Der Langzeit-Cannabinieri wird von dem heftigen mentalen Rausch und der Länge der Wirkung beeindruckt sein.
<G-vec00427-002-s101><buzz_off.rauschen><en> As previously mentioned Royale Haze is most Sativa in nature (85% to precise), and there hits with a strong Sativa-favored buzz.
<G-vec00427-002-s101><buzz_off.rauschen><de> Um nochmal auf die bereits erwähnte Sativadominanz zurückzukommen, Royale Haze trägt 85% Sativagene in sich und schlägt mit einem dementsprechenden Rausch zu.
<G-vec00427-002-s102><buzz_off.rauschen><en> With that in mind (no pun intended), she is an ideal strain for those wanting to get work done on a clear and comfortable buzz.
<G-vec00427-002-s102><buzz_off.rauschen><de> Daher ist sie eine ideale Sorte für alle, die ihre Arbeit mit einem klaren und komfortablen Rausch erledigen möchten.
<G-vec00427-002-s103><buzz_off.rauschen><en> Locked and loaded with both Indica and Sativa traits (at a 40%/60% split), Y Griega CBD induces a clinical buzz that patients will find adequately soothing but not overpowering.
<G-vec00427-002-s103><buzz_off.rauschen><de> Mit Indica und Sativa Zügen (bei einer 40%/60% Aufteilung) geladen, löst Y Griega CBD einen klinischen Rausch aus, den Patienten als angemessen beruhigend, aber nicht übermächtig finden werden.
<G-vec00427-002-s104><buzz_off.rauschen><en> If you are looking to help fight the symptoms of insomnia then you may want to look else where, the cerebral buzz will not help you drift off to sleep.
<G-vec00427-002-s104><buzz_off.rauschen><de> Wenn Du Hilfe im Kampf gegen die Symptome der Schlaflosigkeit suchst, solltest Du Dich anderweitig umsehen, denn der zerebrale Rausch wird Dir nicht helfen in den Schlaf abzudriften.
<G-vec00427-002-s122><buzz_off.summen><en> An audible hum or buzz may be heard by either the remote party or by both the remote party and the Cisco Unified IP Phone user.
<G-vec00427-002-s122><buzz_off.summen><de> Dieses Summen ist entweder nur beim Gesprächspartner oder beim Gesprächspartner und dem Benutzer des Cisco Unified IP-Telefons zu hören.
<G-vec00427-002-s123><buzz_off.summen><en> Create a buzz on the street or wear them to stay warm.
<G-vec00427-002-s123><buzz_off.summen><de> Erstellen Sie eine Summen auf der Straße oder tragen sie um warm zu bleiben.
<G-vec00427-002-s124><buzz_off.summen><en> Gynectrol is a newbie to the market however has actually currently created a great deal of positive buzz.
<G-vec00427-002-s124><buzz_off.summen><de> Gynectrol ist ein Neuling auf dem Markt, hat aber noch eine Reihe von günstigen Summen erzeugt.
<G-vec00427-002-s125><buzz_off.summen><en> Social networking sites are the big buzz around the internet and not only are they great for socializing with friends, but there are hundreds of Internet Marketers that use these sites to promote their businesses.
<G-vec00427-002-s125><buzz_off.summen><de> Social Networking-Websites sind die großen Summen um das Internet und sie sind nicht nur für Geselligkeit mit Freunden groß, aber es gibt Hunderte von Internet-Marketingspezialisten, dass diese Seiten nutzen, um ihre Wirtschaft zu fördern.
<G-vec00427-002-s126><buzz_off.summen><en> The online casino industry is really exciting at the moment and a lot of this is down to the buzz generated by the games.
<G-vec00427-002-s126><buzz_off.summen><de> Die Online-Casino-Industrie ist wirklich aufregend im Moment und eine Menge von dieser ist bis auf das Summen der Spiele erzeugt.
<G-vec00427-002-s127><buzz_off.summen><en> A buzz is heard and the door opens.
<G-vec00427-002-s127><buzz_off.summen><de> Ein Summen ertönt und die Sicherheitstür wird geöffnet.
<G-vec00427-002-s128><buzz_off.summen><en> Just across the Bay Bridge, Berkeley and its neighbor Oakland get little of the buzz that SF does on the other side of the water.
<G-vec00427-002-s128><buzz_off.summen><de> Nur über die Bay Bridge, Berkeley und sein Nachbar Oakland bekommen wenig von der Summen, die SF tut auf der anderen Seite des Wassers.
<G-vec00427-002-s129><buzz_off.summen><en> Amidst the chink of glasses, the murmur of Italian voices and the buzz of music and laughter, you discover an unforgettable side to Venice that many visitors miss.
<G-vec00427-002-s129><buzz_off.summen><de> Inmitten des Klirrens von Gläsern, dem Gemurmel von italienischen Stimmen und dem Summen von Musik und Gelächter entdecken Sie eine unvergessliche Seite von Venedig, die vielen Besuchern entgeht.
<G-vec00427-002-s130><buzz_off.summen><en> With decorative items from your techneb shop, the buzz is assured: you will impress your friends with these Gifts Design.
<G-vec00427-002-s130><buzz_off.summen><de> Mit dekorativen Artikeln aus Ihrem Techneb-Shop ist das Summen sicher: Sie werden Ihre Freunde mit diesen Geschenke entwerfen.
<G-vec00427-002-s131><buzz_off.summen><en> Beautiful place and great buzz.
<G-vec00427-002-s131><buzz_off.summen><de> Ein schöner Ort und große Summen.
<G-vec00427-002-s132><buzz_off.summen><en> Gynectrol is a beginner to the marketplace yet has actually currently generated a bunch of favorable buzz.
<G-vec00427-002-s132><buzz_off.summen><de> Gynectrol ist ein Neuling auf dem Markt, sondern hat bereits viele positive Summen erzeugt.
<G-vec00427-002-s133><buzz_off.summen><en> Certainly, there is a legitimate factor for all the buzz and also enjoyment concerning this product.
<G-vec00427-002-s133><buzz_off.summen><de> Sicher, es ist ein berechtigter Grund für all die Summen sowie Heiterkeit zu diesem Produkt.
<G-vec00427-002-s134><buzz_off.summen><en> In the summer the bees buzz around the blossoming flowers looking for nectar.
<G-vec00427-002-s134><buzz_off.summen><de> Im Sommer summen die Bienen um die blühenden Blüten und im Herbst erfreuen sich die Vögel an den Samen.
<G-vec00427-002-s135><buzz_off.summen><en> True to their genetics, these sativa strains generate such a head buzz that it will leave you reeling.
<G-vec00427-002-s135><buzz_off.summen><de> Getreu ihrer Genetik erzeugen diese Sativas-Stämme ein Summen im Kopf, das Sie überwältigen wird.
<G-vec00427-002-s136><buzz_off.summen><en> For a few days the declaration of a vapereur makes the "buzz" on the social network Facebook.
<G-vec00427-002-s136><buzz_off.summen><de> Für ein paar Tage macht die Deklaration eines Vapeurers das "Summen" im sozialen Netzwerk Facebook.
<G-vec00427-002-s137><buzz_off.summen><en> Hvar is a fantastic place to be part of, especially at the height of the summer months with an electrifying buzz and pace of life.
<G-vec00427-002-s137><buzz_off.summen><de> Hvar ist ein fantastischer Ort, an dem man teilnehmen kann, vor allem in den Hochsommermonaten mit einem elektrisierenden Summen und Lebenstempo.
<G-vec00427-002-s138><buzz_off.summen><en> The birds sing, the bees buzz, the air has the seasoned fragrance of grass, forest, fields and the delicacies created by the chef Manuel Ebner in his kitchen.
<G-vec00427-002-s138><buzz_off.summen><de> Vögel zwitschern, Bienen summen, die Luft duftet würzig nach Kräutern, Wald, Wiesen – und nach den Köstlichkeiten, die Juniorchef Manuel Ebner in seiner Küche zaubert.
<G-vec00427-002-s139><buzz_off.summen><en> If you've been scouring the news, devouring as much information as possible regarding weight loss, you've likely heard all the buzz about the relationship between weight loss and drinking water.
<G-vec00427-002-s139><buzz_off.summen><de> Wenn Sie die Nachrichten gereinigt haben, so viele Informationen verschlingend, wie möglich betreffend Gewichtverlust, haben Sie wahrscheinlich das ganzes Summen über das Verhältnis zwischen Gewichtverlust und Trinkwasser gehört.
<G-vec00427-002-s140><buzz_off.summen><en> What began as a low buzz swelled into a rumble that shook the surrounding structure.
<G-vec00427-002-s140><buzz_off.summen><de> Was als leichtes Summen begann, schwoll zu einem Grollen an, das die umgebenden Mauern zum Beben brachte.
