<G-vec00761-002-s061><bully.drangsalieren><en> One of the women was so triggered and had a slight case of the "insanity" and, in my fourth year of this so called enlightened healing school, she began to bully me.
<G-vec00761-002-s061><bully.drangsalieren><de> Eine der Frauen war so angetriggert und hatte einen leichten Fall von "Irrsinn" und es war in meinem vierten Jahr an dieser sogenannten erleuchteten Heilungsschule, als sie begann mich zu drangsalieren.
<G-vec00761-002-s062><bully.drangsalieren><en> Christ’s perfect love overcomes temptations to harm, coerce, bully, or oppress.
<G-vec00761-002-s062><bully.drangsalieren><de> Die vollkommene Liebe Christi überwindet jede Versuchung, anderen Schaden zuzufügen, sie einzuschüchtern, zu drangsalieren oder zu unterdrücken.
<G-vec00761-002-s022><bully.mobben><en> You should strive to make friends with people who don't bully.
<G-vec00761-002-s022><bully.mobben><de> Du solltest danach streben, dich mit Personen anzufreunden, die nicht mobben.
<G-vec00761-002-s066><bully.mobben><en> Fact #5 My husband used to bully me in School.
<G-vec00761-002-s066><bully.mobben><de> Fakt #5 Mein Eheman hat mich früher in der Schule gemobbt.
<G-vec00761-002-s070><bully.mobben><en> 1 Understand the intent of the bully.
<G-vec00761-002-s070><bully.mobben><de> 1 Verstehe die Intention hinter dem Mobben.
<G-vec00761-002-s074><bully.mobben><en> But to effectively stop a bully from doing things that harm others, you need to try finding out where and how the need to bully others starts in a kid, what possibly triggers it.
<G-vec00761-002-s074><bully.mobben><de> Aber um einen Mobber wirklich effektiv von dem abzubringen, Dinge zu tun, die andere verletzen, muss man versuchen herauszufinden, wann und womit das Bedürfnis zu mobben beginnt - was Mobbing auslöst.
<G-vec00761-002-s075><bully.mobben><en> Reflect on how it feels to bully others.
<G-vec00761-002-s075><bully.mobben><de> Überlege, wie es sich für dich anfühlt andere zu mobben.
<G-vec00761-002-s076><bully.mobben><en> Forbidden Conduct: It is forbidden to harass or bully other players via verbal or written communications.
<G-vec00761-002-s076><bully.mobben><de> Es ist verboten, andere Spieler in verbaler oder schriftlicher Form zu belästigen zu schikanieren oder zu mobben.
<G-vec00761-002-s094><bully.schikanieren><en> Do not allow your children to bully or make fun of the disadvantaged in their community and schools.
<G-vec00761-002-s094><bully.schikanieren><de> Erlaubt euren Kindern nicht, die Benachteiligten in ihrer Gemeinde und Schule zu schikanieren oder sich über sie lustig zu machen.
<G-vec00761-002-s095><bully.schikanieren><en> The proposed investor rights are a sure-fire way to bully decision-makers.
<G-vec00761-002-s095><bully.schikanieren><de> Die vorgeschlagenen Anlegerrechte sind ein sicherer Weg, um die Entscheidungsträger zu schikanieren.
<G-vec00761-002-s096><bully.schikanieren><en> What a buzz for the closet totalitarian then, to bully other people “for their own good” - in this case, to “save the planet”.
<G-vec00761-002-s096><bully.schikanieren><de> Was für ein Glückstaumel für den Westentaschen-Diktator dann, die anderen Menschen "zu ihrem eigenen Besten" zu schikanieren - in diesem Fall um "den Planeten zu retten".
<G-vec00761-002-s097><bully.schikanieren><en> Use our built-in tools to avoid the negativity and report those who bully, harass and abuse.
<G-vec00761-002-s097><bully.schikanieren><de> Verwenden Sie unsere integrierten Tools, um Negativität zu vermeiden und melden Sie diejenigen, die schikanieren, belästigen und beschimpfen.
<G-vec00761-002-s098><bully.schikanieren><en> Lauren, as usual, came out aggressive and tried to bully Brooke into making a mistake.
<G-vec00761-002-s098><bully.schikanieren><de> Lauren kam wie immer aggressiv heraus und versuchte Brooke zu schikanieren, um einen Fehler zu machen.
<G-vec00761-002-s099><bully.schikanieren><en> Stefan, a long rickety blond boy, had taken on the task to bully me.
<G-vec00761-002-s099><bully.schikanieren><de> Stefan, ein langer wackeligen blonder Junge, hatte die Aufgabe übernommen, mich zu schikanieren.
<G-vec00761-002-s100><bully.schikanieren><en> President Trump can’t bully him with tweets.
<G-vec00761-002-s100><bully.schikanieren><de> Präsident Trump kann ihn nicht mit Tweets schikanieren.
<G-vec00761-002-s101><bully.schikanieren><en> He once tried to bully me in the courtroom before the judge made his entrance.
<G-vec00761-002-s101><bully.schikanieren><de> Er versuchte einmal, mich im Gerichtssaal zu schikanieren, bevor der Richter seinen Eingang machte.
<G-vec00761-002-s111><bully.tyrannisieren><en> For nine days I chase them around, bully them, and see as little of them as possible.
<G-vec00761-002-s111><bully.tyrannisieren><de> Neun Tage lang jage ich sie herum, tyrannisiere sie und sehe von ihnen so wenig wie möglich.
<G-vec00761-002-s112><bully.tyrannisieren><en> He is predictably applying his particular art of negotiation: threaten, bully and bluster – then strike a deal.
<G-vec00761-002-s112><bully.tyrannisieren><de> Voraussichtlich wendet er seine besondere Verhandlungskunst an: drohen, tyrannisieren und toben - dann einen Deal machen.
<G-vec00761-002-s113><bully.tyrannisieren><en> In the person of our nation we are able, vicariously, to bully and cheat.
<G-vec00761-002-s113><bully.tyrannisieren><de> In der Person unserer Nation sind wir imstande, durch einen Stellvertreter zu tyrannisieren und zu betrügen.
<G-vec00761-002-s114><bully.tyrannisieren><en> For money, the officials would take advantage of their positions and become corrupt; the people would take great risk, and collude with officials or gangsters to bully others.
<G-vec00761-002-s114><bully.tyrannisieren><de> Die Beamten nutzten ihre Position und wurden korrupt; die Leute nahmen große Gefahren auf sich und kooperierten mit den Beamten, um andere zu tyrannisieren.
<G-vec00761-002-s115><bully.tyrannisieren><en> We bully people around. “I am a FATHER and I must be respected!” Of course, our child has difficulty with that, and there is a big conflict.
<G-vec00761-002-s115><bully.tyrannisieren><de> Wir tyrannisieren die Menschen um uns herum: „Ich bin ein VATER und muss respektiert werden!“ Natürlich hat unser Kind damit dann Schwierigkeiten und es gibt einen großen Konflikt.
<G-vec00761-002-s116><bully.tyrannisieren><en> They would ask their four daughters to come over just to yell at me and bully me.
<G-vec00761-002-s116><bully.tyrannisieren><de> Sie kamen sogar mit ihren vier Töchtern zu mir, die mich anbrüllten und tyrannisierten.
