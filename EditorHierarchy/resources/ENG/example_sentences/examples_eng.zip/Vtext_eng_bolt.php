<G-vec00899-002-s067><bolt.bolzen><en> To ensure the 808 Reef SB outboard motor lock can provide optimal protection for your engine, the lock body, the bolt and the security-relevant parts of the locking mechanism are made of specially hardened steel.
<G-vec00899-002-s067><bolt.bolzen><de> Damit das Außenbordmotor-Schloss 808 Reef SB Ihren Motor optimal schützt, wurden der Schlosskörper, der Bolzen und die sicherheitsrelevanten Teile des Schließmechanismus aus speziell gehärtetem Stahl gefertigt.
<G-vec00899-002-s068><bolt.bolzen><en> You can also open the stick 90° and put some Vaseline on the surfaces close to the bolt.
<G-vec00899-002-s068><bolt.bolzen><de> Knirschende Geräusche: Sollte der Stock knirschen, öffnen Sie den Stock 90° und tun Sie Vaseline auf den Flächen um den Bolzen.
<G-vec00899-002-s069><bolt.bolzen><en> Our popular products include:carbon steel hex nut, bolt and screws.
<G-vec00899-002-s069><bolt.bolzen><de> Unsere populären Produkte schließen ein: KohlenstoffstahlSechskantmutter, Bolzen und Schrauben.
<G-vec00899-002-s070><bolt.bolzen><en> 4pcs black plastic stop rings, Attached by bolt and nut. Washers
<G-vec00899-002-s070><bolt.bolzen><de> Plastikanschlagringe des Schwarzen 4pcs, befestigt durch Bolzen und Nuss.
<G-vec00899-002-s071><bolt.bolzen><en> The latch bolt is the piece of the latch that goes into the door frame to close the door.
<G-vec00899-002-s071><bolt.bolzen><de> Der Teil des Schlosses, welcher ausfährt und die Tür zusperrt, ist der Bolzen.
<G-vec00899-002-s072><bolt.bolzen><en> The handle lock can also be bypassed, if needed, with a small bolt through the handle in the release position.
<G-vec00899-002-s072><bolt.bolzen><de> Der Griffverschluß kann auch überbrückt werden, wenn er, mit einem kleinen Bolzen durch den Griff in der Freigabeposition benötigt wird.
<G-vec00899-002-s073><bolt.bolzen><en> High strength bolt is made of high strength material.
<G-vec00899-002-s073><bolt.bolzen><de> Hochfester Bolzen wird vom hochfesten Material hergestellt.
<G-vec00899-002-s074><bolt.bolzen><en> Hex flange bolt is a one-piece forged bolt with a hex washer head.
<G-vec00899-002-s074><bolt.bolzen><de> Hexenflanschbolzen ist ein einteiliger geschmiedeter Bolzen mit einem Hexenwaschmaschinenkopf.
<G-vec00899-002-s075><bolt.bolzen><en> of Athens decisions were taken not by the court president but by the court members (somehow like the jurors in the american jurisdiction) voting in favour (disks with a bolt) or versus (disks with a hole) the defendant.
<G-vec00899-002-s075><bolt.bolzen><de> In den Athener Gerichten wurden die Entscheidungen nicht vom Gerichtsvorsitzenden gefällt sondern von den Gerichtsmitgliedern, die mit so einem Metallring dafür (Ring mit Bolzen) oder dagegen (Ring mit Loch) plädierten.
<G-vec00899-002-s077><bolt.bolzen><en> Never use damaged or incorrect blade washers or bolt.
<G-vec00899-002-s077><bolt.bolzen><de> Verwenden Sie niemals defekte oder vom Original abweichende Unterlegscheiben oder Bolzen.
<G-vec00899-002-s078><bolt.bolzen><en> A bolt from the gravity-feed magazine is pressed into the hole in the workpiece.
<G-vec00899-002-s078><bolt.bolzen><de> Aus dem Fallmagazin wird ein Bolzen in die Bohrungen des Werkstücks eingepresst.
<G-vec00899-002-s079><bolt.bolzen><en> All of this also meant that the bolt binding the civic anti-government union is very fragile and will not last too long.
<G-vec00899-002-s079><bolt.bolzen><de> All dies bedeutete aber auch, dass der Bolzen, der die bürgerliche Anti-Regierungs-Einheit zusammenhält, sehr brüchig ist und diese nicht allzu lange halten wird.
<G-vec00899-002-s080><bolt.bolzen><en> The clamp is clamped around the wire and then mounted to the fencing component via a bolt / nut connection.
<G-vec00899-002-s080><bolt.bolzen><de> Die Klemme wird um den Draht geklemmt und dann über eine Bolzen / Mutter-Verbindung an der Zaunkomponente befestigt.
<G-vec00899-002-s081><bolt.bolzen><en> 1 NOS bolt for squareback cargo door hinges.
<G-vec00899-002-s081><bolt.bolzen><de> 1 NOS Bolzen für Variant Hecklappen-Scharnier.
<G-vec00899-002-s082><bolt.bolzen><en> Then you mount the bolt bottom-up in the top of the fork with a long allen key.
<G-vec00899-002-s082><bolt.bolzen><de> Danach wird der Bolzen von unten in den oberen Teil der Gabel mit einem langen Inbusschlüssel eingeschraubt.
<G-vec00899-002-s083><bolt.bolzen><en> Fixed in position with a bolt from the backside of the bracket.
<G-vec00899-002-s083><bolt.bolzen><de> In Position gehalten durch einen Bolzen auf der Rückseite der Klammer.
<G-vec00899-002-s084><bolt.bolzen><en> Our draw safeguard is pushed over the trailer lug and locked through pressure on the bolt.
<G-vec00899-002-s084><bolt.bolzen><de> Die Sicherung von Grönheit & Weigel für die Deichsel wird über die Anhängeröse geschoben und durch Druck auf den Bolzen verriegelt.
<G-vec00899-002-s085><bolt.bolzen><en> I have a vintage gold spoon hanging from the top on a large black iron toogle bolt.
<G-vec00899-002-s085><bolt.bolzen><de> Ich habe einen Vintage gold Löffel hängen von der Spitze auf einem großen schwarzen Eisen Toogle Bolzen.
<G-vec00899-002-s200><bolt.schrauben><en> Ⅱ: connect the flange connection to the flange on the pipe and bolt it.
<G-vec00899-002-s200><bolt.schrauben><de> Ⅱ: Verbinden Sie die Flanschverbindung mit dem Flansch am Rohr und schrauben Sie ihn fest.
<G-vec00899-002-s201><bolt.schrauben><en> When using LOGO.3 formwork on large-area construction components, the low number of tie points fulfils the high demands that are made of the concrete surface, whereas the LOGO.S with steel facing achieves ideal concrete surfaces, since no bolt or rivet head impressions are visible in the concrete.
<G-vec00899-002-s201><bolt.schrauben><de> Beim Einsatz der LOGO.3-Schalung in großflächigen Bauteilen werden durch den geringen Spannstellenanteil hohe Anforderungen an die Betonoberfläche erfüllt und die LOGO.S mit Stahlschalhaut erzielt optimale Betonoberflächen, da keine Abdrücke von Schrauben oder Nietköpfen im Beton sichtbar sind.
<G-vec00899-002-s202><bolt.schrauben><en> Never use another bolt or self-extractor nut to install INpower cranks.
<G-vec00899-002-s202><bolt.schrauben><de> Verwenden Sie zum Einbau von INpower-Tretkurbeln niemals andere Schrauben oder selbstanziehende Muttern.
<G-vec00899-002-s203><bolt.schrauben><en> ► Bolt the mast support-yoke to the side tubes.
<G-vec00899-002-s203><bolt.schrauben><de> ► Schrauben Sie das Querrohr auf die Seitenrohre.
<G-vec00899-002-s204><bolt.schrauben><en> Beside the standard fasteners used in the assembly of steel constructions, and as a part of full-service deliveries, we also offer special bolt connections protecting the elements of constructions from theft (anti-theft connections).
<G-vec00899-002-s204><bolt.schrauben><de> Zusätzlich zu den Standardverbindungselementen, die bei Montage von Stahlkonstruktionen verwendet werden, bieten wir im Rahmen von komplexen Lieferungen ebenfalls Sonderausführungen von Schrauben, welche den Diebstahl von Bauteilen verhindern (s.g. Diebstahlschutz).
<G-vec00899-002-s205><bolt.schrauben><en> For example, if you have modeled embeds as studs, steel parts, or reinforcing bars, respectively either bolt settings, part settings, or reinforcement settings are relevant.
<G-vec00899-002-s205><bolt.schrauben><de> Wenn Sie beispielsweise Einbauteile wie Bolzen, Stahlteile oder Bewehrungsstäbe modelliert haben, sind dementsprechend die Einstellungen für Schrauben, Teile oder Bewehrung relevant.
<G-vec00899-002-s206><bolt.schrauben><en> The correct bolt must be chosen depending on the working pressure.
<G-vec00899-002-s206><bolt.schrauben><de> Abhängig vom Betriebsdruck müssen die richtigen Schrauben gewählt werden.
<G-vec00899-002-s207><bolt.schrauben><en> “We don’t insist that Nord-Lock be used where the expense is not justified but we do insist that this product be used in radiation contaminated areas because they allow a bolt to be tightened very quickly.
<G-vec00899-002-s207><bolt.schrauben><de> Aber wir bestehen darauf, dass dieses Produkt in strahlungskontaminierten Bereichen eingesetzt wird, da es die Scheiben ermöglichen, die Schrauben mit minimalem Zeitaufwand anzuziehen.
