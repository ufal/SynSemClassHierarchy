<G-vec01000-002-s049><bless.segnen><en> 16 If you obey the commandments of the Lord your God that I command you today, by loving the Lord your God, by walking in his ways, and by keeping his commandments and his statutes and his rules, then you shall live and multiply, and the Lord your God will bless you in the land that you are entering to take possession of it.
<G-vec01000-002-s049><bless.segnen><de> 16 da ich dir heute gebiete, Jahwe, deinen Gott, zu lieben, auf seinen Wegen zu wandeln und seine Gebote und seine Satzungen und seine Rechte zu beobachten, damit du lebest und dich mehrest, und Jahwe, dein Gott, dich segne in dem Lande, wohin du kommst, um es in Besitz zu nehmen.
<G-vec01000-002-s050><bless.segnen><en> 7‘Bring me game and prepare for me delicious food, that I may eat it and bless you before the Lord before I die.’
<G-vec01000-002-s050><bless.segnen><de> 7Bringe mir ein Wildbret und mach mir ein Essen, dass ich esse und dich segne vor dem HERRN, ehe ich sterbe.
<G-vec01000-002-s051><bless.segnen><en> 9“Please go to the flock and bring me two choice young goats, and I make a tasty dish from them for your father, such as he loves. 10“And you shall take it to your father, and he shall eat it, so that he might bless you before his death.”
<G-vec01000-002-s051><bless.segnen><de> 9Gehe doch zur Herde und hole mir von dannen zwei gute Ziegenböcklein, und ich will sie zu einem schmackhaften Gericht bereiten für deinen Vater, wie er es gern hat; 10und du sollst es deinem Vater bringen, daß er esse, damit er dich segne vor seinem Tode.
<G-vec01000-002-s052><bless.segnen><en> 19 Dt 24, 19 When you cut down your harvest in your field, and have forgot a sheaf in the field, you shall not go again to fetch it: it shall be for the stranger, for the fatherless, and for the widow: that the LORD your God may bless you in all the work of your hands.
<G-vec01000-002-s052><bless.segnen><de> 19 Dt 24, 19 Wenn du deine Ernte auf deinem Felde hältst und eine Garbe auf dem Felde vergissest, so sollst du nicht umkehren, um sie zu holen: Für den Fremdling, für die Waise und für die Witwe soll sie sein, auf daß Jehova, dein Gott, dich segne in allem Werke deiner Hände.
<G-vec01000-002-s053><bless.segnen><en> ‘Bring me game and make savory food for me, that I may eat it and bless you in the presence of the Lord before my death.’
<G-vec01000-002-s053><bless.segnen><de> Bringe mir ein Wildbret und mache mir ein Essen, daß ich esse und dich segne vor dem HERRN, ehe ich sterbe.
<G-vec01000-002-s054><bless.segnen><en> 25 He said, "Bring it near to me, and I will eat of my son`s venison, that my soul may bless you."
<G-vec01000-002-s054><bless.segnen><de> 25 Da sprach er: Reiche es mir her, daß ich esse von dem Wildbret meines Sohnes, damit meine Seele dich segne.
<G-vec01000-002-s055><bless.segnen><en> 30:16 in that I command you this day to love Yahweh your God, to walk in his ways, and to keep his commandments and his statutes and his ordinances, that you may live and multiply, and that Yahweh your God may bless you in the land where you go in to possess it.
<G-vec01000-002-s055><bless.segnen><de> 30:16 da ich dir heute gebiete, Jehova, deinen Gott, zu lieben, auf seinen Wegen zu wandeln und seine Gebote und seine Satzungen und seine Rechte zu beobachten, damit du lebest und dich mehrest, und Jehova, dein Gott, dich segne in dem Lande, wohin du kommst, um es in Besitz zu nehmen.
<G-vec01000-002-s056><bless.segnen><en> Go to the flock and bring me two good young goats, so that I may prepare from them delicious food for your father, such as he loves. And you shall bring it to your father to eat, so that he may bless you before he dies.”
<G-vec01000-002-s056><bless.segnen><de> Gehe doch zur Herde und hole mir von dannen zwei gute Ziegenböcklein, und ich will sie zu einem schmackhaften Gericht bereiten für deinen Vater, wie er es gern hat; und du sollst es deinem Vater bringen, dass er es esse, damit er dich segne vor seinem Tode.
<G-vec01000-002-s057><bless.segnen><en> 12And if the man be poor, thou shalt not sleep with his pledge: 13in any case thou shalt deliver him the pledge again when the sun goeth down, that he may sleep in his own raiment, and bless thee: and it shall be righteousness unto thee before the Lord thy God.
<G-vec01000-002-s057><bless.segnen><de> 12Und wenn er ein dürftiger Mann ist, so sollst du dich nicht mit seinem Pfande schlafen legen; 13du sollst ihm das Pfand jedenfalls beim Untergang der Sonne zurückgeben, daß er sich in seinem Mantel schlafen lege und dich segne; und es wird dir Gerechtigkeit sein vor Jehova, deinem Gott.
<G-vec01000-002-s058><bless.segnen><en> If you obey the commandments of the LORD your God that I command you today, by loving the LORD your God, by walking in his ways, and by keeping his commandments and his statutes and his rules, then you shall live and multiply, and the LORD your God will bless you in the land that you are entering to take possession of it.
<G-vec01000-002-s058><bless.segnen><de> NeÜ | Sünde Gnade Freiheit Dies ist's, was ich dir heute gebiete: dass du den HERRN, deinen Gott, liebst und wandelst in seinen Wegen und seine Gebote, Gesetze und Rechte hältst, so wirst du leben und dich mehren, und der HERR, dein Gott, wird dich segnen in dem Lande, in das du ziehst, es einzunehmen.
<G-vec01000-002-s059><bless.segnen><en> If you obey the commandments of the LORD your God that I command you today, by loving the LORD your God, by walking in his ways, and by keeping his commandments and his statutes and his rules, then you shall live and multiply, and the LORD your God will bless you in the land that you are entering to take possession of it.
<G-vec01000-002-s059><bless.segnen><de> LUT | ist's, was ich dir heute gebiete: dass du den HERRN, deinen Gott, liebst und wandelst in seinen Wegen und seine Gebote, Gesetze und Rechte hältst, so wirst du leben und dich mehren, und der HERR, dein Gott, wird dich segnen in dem Lande, in das du ziehst, es einzunehmen.
<G-vec01000-002-s060><bless.segnen><en> 3Stay in this land for a while, and I will be with you and will bless you. For to you and your descendants I will give all these lands and will confirm the oath I swore to your father Abraham.
<G-vec01000-002-s060><bless.segnen><de> 3Halte dich auf in diesem Lande, und ich werde mit dir sein und dich segnen; denn dir und deinem Samen werde ich alle diese Länder geben, und ich werde den Eid aufrecht erhalten, den ich deinem Vater Abraham geschworen habe.
<G-vec01000-002-s061><bless.segnen><en> 15:10 You shall surely give him, and yours heart shall not be grieved when you give unto him: because that for this thing the LORD your God shall bless you in all your works, and in all that you put yours hand unto.
<G-vec01000-002-s061><bless.segnen><de> 15:10 Sondern du sollst ihm geben und dein Herz nicht verdrießen lassen, daß du ihm gibst; denn um solches willen wird dich der HERR, dein Gott, segnen in allen deinen Werken und in allem, was du vornimmst.
<G-vec01000-002-s062><bless.segnen><en> 8 The LORD shall command the blessing upon you in your storehouses, and in all that you set your hand unto; and he shall bless you in the land which the LORD your God gives you.
<G-vec01000-002-s062><bless.segnen><de> 8 Der HERR wird gebieten dem Segen, daß er mit dir sei in deinem Keller und in allem, was du vornimmst, und wird dich segnen in dem Lande, das dir der HERR, dein Gott, gegeben hat.
<G-vec01000-002-s063><bless.segnen><en> X For the Lord your God will bless you as he has promised, and you will lend to many nations but will borrow from none.
<G-vec01000-002-s063><bless.segnen><de> Denn er hat gesagt: »Ich will dich nicht verlassen und nicht von dir weichen.« Denn der HERR, dein Gott, wird dich segnen, wie er dir zugesagt hat.
<G-vec01000-002-s064><bless.segnen><en> For the Lord your God will bless you in all your harvest and in all the work of your hands, and your joy will be complete.
<G-vec01000-002-s064><bless.segnen><de> Denn der HERR, dein Gott, wird dich segnen in deiner ganzen Ernte und in allen Werken deiner Hände; darum sollst du fröhlich sein.
<G-vec01000-002-s065><bless.segnen><en> 24 An altar of earth you shall make unto me, and shall sacrifice thereon eth-your burnt offerings, and eth-your oxen: in all places where I record eth-my name I will come unto you, and I will bless you.
<G-vec01000-002-s065><bless.segnen><de> Einen Altar von Erde sollst du mir machen und darauf opfern deine Brandopfer und deine Friedensopfer, dein Kleinvieh und deine Rinder; an jedem Orte, wo ich meines Namens werde gedenken lassen, werde ich zu dir kommen und dich segnen.
<G-vec01000-002-s066><bless.segnen><en> And verse 8 and 9 The LORD will command the blessing on you in your barns, and in all that you put your hand to; and he will bless you in the land which the LORD your God gives you.
<G-vec01000-002-s066><bless.segnen><de> Und Vers 8 und 9 Der HERR wird dir den Segen entbieten in deine Speicher und zu allem Geschäft deiner Hand, und er wird dich segnen in dem Land, das der HERR, dein Gott, dir gibt.
<G-vec01000-002-s067><bless.segnen><en> 3 And I will bless those who bless you and he who curses you I will curse. And all the families of the earth will be blessed in you.
<G-vec01000-002-s067><bless.segnen><de> 12:3 Ich will segnen, die dich segnen, und verfluchen, die dich verfluchen; und in dir sollen gesegnet werden alle Geschlechter auf Erden.
<G-vec01000-002-s068><bless.segnen><en> Dies ist's, was ich dir For I command you today to love the Lord your God, to walk in obedience to him, and to keep his commands, decrees and laws; then you will live and increase, and the Lord your God will bless you in the land you are entering to possess.
<G-vec01000-002-s068><bless.segnen><de> Das sei ist's, was ich dir heute gebiete: dass du den HERRN, deinen Gott, liebst und wandelst in seinen Wegen und seine Gebote, Gesetze und Rechte hältst, so wirst du leben und dich mehren, und der HERR, dein Gott, wird dich segnen in dem Lande, in das du ziehst, es einzunehmen.
<G-vec01000-002-s069><bless.segnen><en> 2 I will make you a great nation; I will bless you and make your name great; and you shall be a blessing.
<G-vec01000-002-s069><bless.segnen><de> Und ich will dich zu einem großen Volk machen und dich segnen und deinen Namen groß machen, und du sollst ein Segen sein.
<G-vec01000-002-s070><bless.segnen><en> Don’t be afraid, because I am with you; I will bless you and increase your descendants for the sake of my servant Avraham.”
<G-vec01000-002-s070><bless.segnen><de> Fürchte dich nicht; denn ich bin mit dir und will dich segnen und deinen Samen mehren um meines Knechtes Abraham willen.
<G-vec01000-002-s071><bless.segnen><en> When you do that and put God first, He will bless you.
<G-vec01000-002-s071><bless.segnen><de> Wenn du Gott auch in dieser Angelegenheit an erste Stelle setzt, wird er dich segnen.
<G-vec01000-002-s072><bless.segnen><en> 24Yahweh appeared to him the same night, and said, “I am the God of Abraham your father. Don’t be afraid, for I am with you, and will bless you, and multiply your offspring#or, seed for my servant Abraham’s sake.”
<G-vec01000-002-s072><bless.segnen><de> 24Und Jehova erschien ihm in selbiger Nacht und sprach: Ich bin der Gott Abrahams, deines Vaters; fürchte dich nicht, denn ich bin mit dir, und ich werde dich segnen und deinen Samen mehren um Abrahams, meines Knechtes, willen.
<G-vec01000-002-s073><bless.segnen><en> May God bless and keep you always.
<G-vec01000-002-s073><bless.segnen><de> Möge Gott dich segnen und für immer behalten.
<G-vec01000-002-s074><bless.segnen><en> Fear not, for I am with you and will bless you and multiply your offspring for my servant Abraham’s sake.”
<G-vec01000-002-s074><bless.segnen><de> Denn ich bin mit dir, und ich werde dich segnen und deine Nachkommen vermehren um meines Knechtes Abraham willen.
<G-vec01000-002-s075><bless.segnen><en> 8 The LORD shall command the blessing upon thee in thy storehouses, and in all that thou settest thine hand unto; and he shall bless thee in the land which the LORD thy God giveth thee.
<G-vec01000-002-s075><bless.segnen><de> 8 Der HERR wird gebieten dem Segen, daß er mit dir sei in dem, was du besitzt, und in allem, was du unternimmst, und wird dich segnen in dem Land, das dir der HERR, dein Gott, gegeben hat.
<G-vec01000-002-s076><bless.segnen><en> The next time you think, “That’s just too good to be true,” remember, God wants to bless you beyond your wildest dreams.
<G-vec01000-002-s076><bless.segnen><de> Wenn Du das nächste Mal meinst: „Das ist zu schön um wahr zu sein“, denke daran, dass Dich Gott weit über Deine kühnsten Träume hinaus segnen will.
<G-vec01000-002-s077><bless.segnen><en> 27:10 You shall bring it to your father, that he may eat, so that he may bless you before his death."
<G-vec01000-002-s077><bless.segnen><de> 10 Dann sollst du es deinem Vater bringen, daß er ißt, damit er dich vor seinem Tod segnet.
<G-vec01000-002-s078><bless.segnen><en> And the Levite, and the stranger, and the fatherless, and the widow, which are within your gates, shall come, and shall eat and be satisfied, that the Lord your God may bless thee, in all the works of your hands which you do.’ Deut.14:22, to the end.
<G-vec01000-002-s078><bless.segnen><de> 14,29 Und der Levit - denn er hat keinen Anteil noch Erbe mit dir - und der Fremde und die Waise und die Witwe, die in deinen Toren [wohnen], sollen kommen und essen und sich sättigen, damit der HERR, dein Gott, dich in allem Werk deiner Hand, das du tust, segnet.
<G-vec01000-002-s079><bless.segnen><en> 1 veroveren. For I command you today to love the Lord your God, to walk in obedience to him, and to keep his commands, decrees and laws; then you will live and increase, and the Lord your God will bless you in the land you are entering to possess.
<G-vec01000-002-s079><bless.segnen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec01000-002-s080><bless.segnen><en> 29 so that the Levites (who have no allotment or inheritance of their own) and the foreigners, the fatherless and the widows who live in your towns may come and eat and be satisfied, and so that the Lord your God may bless you in all the work of your hands.
<G-vec01000-002-s080><bless.segnen><de> 29 Dann soll der Levit kommen, der keinen Anteil und Erbbesitz neben dir hat, der Fremde, die Waise und die Witwe, die an deinem Ort wohnen, und sie sollen sich satt essen, damit der HERR, dein Gott, dich segnet bei aller Arbeit deiner Hände, die du tust.
<G-vec01000-002-s081><bless.segnen><en> 10 And you shall bring it to your father to eat, so that he may bless you before he dies.”
<G-vec01000-002-s081><bless.segnen><de> 10 Du bringst es dann deinem Vater zum Essen, damit er dich vor seinem Tod segnet.
<G-vec01000-002-s090><bless.segnen><en> Young men of the Aaronic Priesthood, I testify to you that the Lord is bound by solemn covenant to bless your lives according to your faithfulness.
<G-vec01000-002-s090><bless.segnen><de> Ihr Jungen Männer vom Aaronischen Priestertum, ich bezeuge euch, dass der Herr durch einen feierlichen Bund verpflichtet ist, euch gemäß eurer Glaubenstreue zu segnen.
<G-vec01000-002-s091><bless.segnen><en> Buddha will bless you.
<G-vec01000-002-s091><bless.segnen><de> Buddha wird euch segnen.
<G-vec01000-002-s092><bless.segnen><en> This fragment preserves a blessing to be recited by the leader of the surviving community upon their victory in the final battle, at the end of time: “God Most High will bless you and shine his face upon you, and he will open for you his rich storehouse in the heavens.” God and his holy angels will bestow abundance and fertility upon the holy congregation, and protect them from plagues and wild animals.
<G-vec01000-002-s092><bless.segnen><de> Dieses Fragment erhält einen Segen des Anführers der überlebenden Gemeinschaft nach ihrem Sieg im letzten Kampf am Ende der Zeiten: „Gott, der Allerhöchste, wird euch segnen und sein Angesicht leuchten lassen über euch, und er wird für euch seine reiche Schatzkammer im Himmel öffnen.“ Gott und seine heiligen Engel werden Wohlstand und Fruchtbarkeit über die heilige Versammlung bringen und sie vor Plagen und wilden Tieren schützen.
<G-vec01000-002-s093><bless.segnen><en> I want to bless you for your will to serve me, and I want to help you to carry out your will, by me giving you power for a blessed vineyard work.
<G-vec01000-002-s093><bless.segnen><de> Ich will euch segnen für euren Willen, Mir zu dienen, und Ich will euch helfen, euren Willen auszuführen, indem Ich euch bedenke mit Kraft für eine gesegnete Weinbergsarbeit.
<G-vec01000-002-s094><bless.segnen><en> He will bless you with His blessing of peace.
<G-vec01000-002-s094><bless.segnen><de> Er wird euch segnen mit seinem Segen des Friedens.
<G-vec01000-002-s095><bless.segnen><en> You must be active yourselves, and I will bless you.
<G-vec01000-002-s095><bless.segnen><de> Ihr müsset selbst tätig sein, und Ich werde euch segnen.
<G-vec01000-002-s096><bless.segnen><en> Thus, hold out your hand to your enemies of yore and share with them the land and its fruits and I shall bless you so that a true and lasting peace will eventually entail welfare and blossoming deserts.
<G-vec01000-002-s096><bless.segnen><de> So reichet die Hand euren einstigen Feinden und teilet mit ihnen Land und Frucht, und ICH werde euch segnen, auf daß bald ein wahrer, dauerhafter Frieden möglich wird und Wohlergehen in grünenden Wüsten entsteht.
<G-vec01000-002-s097><bless.segnen><en> If you make an effort to conduct yourselves along the path of noble aspirations, so that your mind can be occupied with virtues and your lips be the faithful instrument of truth and inspiration which will germinate in your spirit, I will bless you and allow you to behold the light of that kingdom of peace which together you will build.
<G-vec01000-002-s097><bless.segnen><de> Ich werde euch segnen und euch einen Lichtschimmer jenes Friedensreiches erblicken lassen, das ihr gemeinsam errichten werdet, wenn ihr bemüht seid, einen guten Lebenswandel zu führen, sodass euer Denken sich mit den Tugenden befasst und eure Lippen ein zuverlässiges Werkzeug der Wahrheit und der Eingebung sind, die in eurem Geiste keimen.
<G-vec01000-002-s098><bless.segnen><en> Ye are the children of the prophets, and of the covenant which God made with our fathers, saying unto Abraham, And in thy seed shall all the kindreds of the earth be blessed. Unto you first God, having raised up his Son Jesus, sent him to bless you, in turning away every one of you from his iniquities.
<G-vec01000-002-s098><bless.segnen><de> „Ihr seid die Sohne der Propheten und des Bundes, den Gott geschlossen hat mit euren Vatern, als er zu Abraham sprach: „Durch dein Geschlecht sollen gesegnet werden alle Volker auf Erden.“ Fur euch zuerst hat Gott seinen Knecht Jesus erweckt und hat ihn zu euch gesandt, euch zu segnen, dass ein jeder sich bekehre von seiner Bosheit.
<G-vec01000-002-s099><bless.segnen><en> May The Five bless and keep you for what you've done.
<G-vec01000-002-s099><bless.segnen><de> Mögen die Fünf Euch segnen und schützen für das, was Ihr getan habt.
<G-vec01000-002-s100><bless.segnen><en> May Bhagavan bless you on this holy festival of Guru Purnima.
<G-vec01000-002-s100><bless.segnen><de> Möge Bhagawan euch segnen an diesem heiligen Fest Guru Purnima.
<G-vec01000-002-s101><bless.segnen><en> And I want to bless you and every work, which you do, for me and my kingdom.
<G-vec01000-002-s101><bless.segnen><de> Und Ich will euch segnen und jede Arbeit, die ihr leistet, für Mich und Mein Reich.
<G-vec01000-002-s102><bless.segnen><en> May God bless you to make the right decision right now.
<G-vec01000-002-s102><bless.segnen><de> Möge Gott euch segnen, damit ihr die richtige Entscheidung trefft, gerade jetzt.
<G-vec01000-002-s105><bless.segnen><en> I took you to curse my enemies, and behold, you have done nothing but bless them."
<G-vec01000-002-s105><bless.segnen><de> Ich habe dich geholt, damit du meine Feinde verwünschst, und nun hast du sie stattdessen gesegnet.
<G-vec01000-002-s106><bless.segnen><en> 20And as for Ishmael, I have heard you: I will surely bless him; I will make him fruitful and will greatly increase his numbers. He will be the father of twelve rulers, and I will make him into a great nation.
<G-vec01000-002-s106><bless.segnen><de> 20Und um Ismael habe ich dich erhört: Siehe, ich habe ihn gesegnet und werde ihn fruchtbar machen und ihn sehr, sehr mehren; zwölf Fürsten wird er zeugen, und ich werde ihn zu einer großen Nation machen.
<G-vec01000-002-s107><bless.segnen><en> We might conclude that since we pay tithing with money, the Lord will always bless us with money.
<G-vec01000-002-s107><bless.segnen><de> Wir könnten daraus schließen, dass man, wenn man den Zehnten mit Geld zahlt, vom Herrn stets mit Geld gesegnet wird.
<G-vec01000-002-s108><bless.segnen><en> 13 When Samuel finally found him, Saul greeted him cheerfully. “May the Lord bless you,” he said.
<G-vec01000-002-s108><bless.segnen><de> 13Als Samuel nun zu Saul kam, sagte Saul zu ihm: Gesegnet seist du vom Herrn.
<G-vec01000-002-s109><bless.segnen><en> 20 And as for Ishmael, I have heard thee: Behold, I shall bless him and will make him fruitful and will multiply him exceedingly; he shall beget twelve princes, and I will make him a great nation.
<G-vec01000-002-s109><bless.segnen><de> 20 Und um Ismael habe ich dich erhört: Siehe, ich habe ihn gesegnet und werde ihn fruchtbar machen und ihn sehr, sehr mehren; zwölf Fürsten wird er zeugen, und ich werde ihn zu einer großen Nation machen.
<G-vec01000-002-s110><bless.segnen><en> I am Abraham’s servant. The LORD has bless my master greatly, and he has become great. He has given him flocks and herds, silver and gold, menservants and maidservants,
<G-vec01000-002-s110><bless.segnen><de> 35Und der HERR hat meinen Herrn reich gesegnet, dass er groß geworden ist, und hat ihm Schafe und Rinder, Silber und Gold, Knechte und Mägde, Kamele und Esel gegeben.
<G-vec01000-002-s111><bless.segnen><en> 10 Then Balak became very angry at Balaam, and he struck his hands together. Balak said to Balaam, "I called you to curse my enemies, and look, you have done nothing but bless them these three times!
<G-vec01000-002-s111><bless.segnen><de> Da ergrimmte Balak im Zorn wider Bileam und schlug die Hände zusammen und sprach zu ihm: Ich habe dich gefordert, daß du meinen Feinden fluchen solltest; und siehe, du hast sie nun dreimal gesegnet.
<G-vec01000-002-s112><bless.segnen><en> Of course, we are aware that some real life Bill & Ted’s are on the loose, bless their little hearts.
<G-vec01000-002-s112><bless.segnen><de> Natürlich ist uns bewusst, dass es einige Bill & Teds im richtigen Leben gibt, gesegnet sind ihre kleinen Herzen.
<G-vec01000-002-s113><bless.segnen><en> 10 Boaz said, "May Yahweh bless you, my daughter!
<G-vec01000-002-s113><bless.segnen><de> 10 Da sagte er: Gesegnet bist du vom Herrn, meine Tochter.
<G-vec01000-002-s114><bless.segnen><en> And the Lord did bless us.
<G-vec01000-002-s114><bless.segnen><de> Und der Herr hat uns gesegnet.
<G-vec01000-002-s136><bless.segnen><en> God Bless Your Countries.
<G-vec01000-002-s136><bless.segnen><de> Möge Gott Ihre Länder segnen.
<G-vec01000-002-s137><bless.segnen><en> God bless you and all your families with an abundance of all His graces.
<G-vec01000-002-s137><bless.segnen><de> Möge Gott Sie und Ihre Familien mit all Seinen Gnaden reichlich segnen.
<G-vec01000-002-s138><bless.segnen><en> Thank you, God bless you, and may God bless these United States.
<G-vec01000-002-s138><bless.segnen><de> Möge Gott Sie segnen, und möge Gott diese Vereinigten Staaten von Amerika segnen.
<G-vec01000-002-s139><bless.segnen><en> And may God bless the United States of America.
<G-vec01000-002-s139><bless.segnen><de> Und Gott möge die Vereinigten Staaten von Amerika segnen.
<G-vec01000-002-s140><bless.segnen><en> May God bless you and give you peace and hope.
<G-vec01000-002-s140><bless.segnen><de> Gott möge Sie segnen und Ihnen Frieden und Hoffnung schenken.
<G-vec01000-002-s157><bless.segnen><en> We pray, Father, that You'll bless this Grantway Assembly, its pastor, his wife, his children, the deacons, trustees, and all the board.
<G-vec01000-002-s157><bless.segnen><de> Wir bitten um den Segen für diese Grantway-Versammlung, für ihren Pastor, für seine Frau und die Kinder, für die Diakone, für die Verwalter und für die ganze Gemeinde.
<G-vec01000-002-s158><bless.segnen><en> We pray the Lord may bless you while listening to our radio and browsing through the additional content which you can share with others through email, Facebook & Twitter.
<G-vec01000-002-s158><bless.segnen><de> Wir wünschen Ihnen Gottes Segen beim Hören des Radios und Durchstöbern der weiteren Inhalte, die Sie via Email, Facebook & Twitter mit anderen teilen können.
<G-vec01000-002-s159><bless.segnen><en> It is then that He will bless you so that you can lead a life full of the Holy Spirit.
<G-vec01000-002-s159><bless.segnen><de> Dann wird Er Sie segen, damit Sie ein Leben erfüllt vom Heiligen Geist leben können.
<G-vec01000-002-s160><bless.segnen><en> He currently practices in Utah and enjoys using the oils in his home and integrating them into his practice to bless the lives of his patients.
<G-vec01000-002-s160><bless.segnen><de> Er praktiziert derzeit in Utah, er setzt gerne die Öle in seinem Haus ein und integriert sie in seine Praxis, sehr zum Segen seiner Patienten.
<G-vec01000-002-s161><bless.segnen><en> As for me, I accompany you with affection and prayer, as I cordially bless you, your families and the young people of the entire city of Rome.
<G-vec01000-002-s161><bless.segnen><de> Meinerseits begleite ich euch mit meiner Zuneigung und meinem Gebet und erteile euch, euren Familien und allen Jugendlichen der Stadt Rom von Herzen meinen Segen.
<G-vec01000-002-s162><bless.segnen><en> The author has made it easy for the non-speakers to feel the beauty of it, so I want to congratulate the author and may god bless him, and congratulations for all those who want to learn the language of The Holy Quran.
<G-vec01000-002-s162><bless.segnen><de> Der Autor hat es den Nicht-Sprechern leicht gemacht, die Schönheit der Sprache zu spüren, deshalb möchte ich dem Autor gratulieren und Gottes segen aussprechen und Glückwünsche für all diejenigen, die die Sprache des Heiligen Korans lernen wollen.
<G-vec01000-002-s163><bless.segnen><en> We are given gifts to use in God's Kingdom for two reasons: 1) to bring glory to God, and, 2) to bless others.
<G-vec01000-002-s163><bless.segnen><de> Aus zwei Gründen werden wir in Gottes Reich mit Gaben ausgestattet: 1) um Gott zu verherrlichen, und 2) um ein Segen für andere Menschen zu sein.
<G-vec01000-002-s164><bless.segnen><en> Trust in the Lord to guide you right, turn to Him in prayer time and time again, and constantly appeal to Him to bless your work on earth.
<G-vec01000-002-s164><bless.segnen><de> Vertraue dem Herrn, daß Er dich recht führet, wende dich Ihm immer und immer wieder zu im Gebet, und bitte unaufhörlich um Seinen Segen zu deinem Wirken auf Erden.
<G-vec01000-002-s165><bless.segnen><en> These can bless members of the congregation.
<G-vec01000-002-s165><bless.segnen><de> Dieser kann Mitgliedern der Kirche einen Segen spenden.
<G-vec01000-002-s166><bless.segnen><en> He might have remained in favor with God, beloved and honored by all the angelic throng, presiding in his exalted position with generous, unselfish care, exercising his noble powers to bless others and to glorify his Maker.
<G-vec01000-002-s166><bless.segnen><de> Luzifer hätte, geliebt und geehrt von allen Engelscharen, in der Gunst Gottes bleiben und alle seine hohen Begabungen zum Segen anderer und zur Verherrlichung seines Schöpfers anwenden können.
<G-vec01000-002-s167><bless.segnen><en> As you love His children, Heavenly Father will guide you, and angels will assist you.6 You will be given power to bless lives and rescue souls.
<G-vec01000-002-s167><bless.segnen><de> Wenn ihr den Kindern des himmlischen Vaters Liebe erweist, führt er euch und Engel stehen euch zur Seite.6 Euch wird dann die Macht gegeben, ein Segen zu sein und Seelen zu retten.
<G-vec01000-002-s168><bless.segnen><en> The spiritual power of his teachings and his example of faithful discipleship blessed and continue to bless in marvelous ways the members of the Savior’s restored Church and the people of the world.
<G-vec01000-002-s168><bless.segnen><de> Die geistige Kraft seiner Worte und sein Beispiel treuer Nachfolge sind den Mitgliedern der wiederhergestellten Kirche des Erlösers und den Menschen in der Welt bis heute ein großer Segen.
<G-vec01000-002-s169><bless.segnen><en> In 1848 Hermann Cohen, a Jew converted to Christianity started the initiative in Paris with the following intention “night exposition and adoration of the Most Holy Sacrament in reparation for the many offences committed against the Lord and to ask God to bless France and preserve it from the evils with which it is threatened” as it was written in the minutes of the First Session.
<G-vec01000-002-s169><bless.segnen><de> 1848 führte der konvertierte Jude Hermann Cohen die nächtlichen Anbetungsgruppen in Paris ein, wo er „die Ausstellung des Allerheiligsten und dessen nächtliche Anbetung zur Wiedergutmachung der Beleidigungen gegenüber Gott“ fördern wollte, „um Gottes Segen für Frankreich zu erwirken und die Übel abzuwenden, die es bedrohen“, wie man in den Akten zur ersten Sitzung liest.
<G-vec01000-002-s170><bless.segnen><en> I assure you of my daily remembrance in prayer, while I warmly bless you together with your families and all your loved ones.
<G-vec01000-002-s170><bless.segnen><de> Auch ich stehe euch bei im Gebet und erteile jedem von euch, euren Familien und den Armen, die ihr liebevoll unterstützt, meinen besonderen Apostolischen Segen.
<G-vec01000-002-s171><bless.segnen><en> 19 Is the seed yet in the barn? yea, the vine, and the fig-tree, and the pomegranate, and the olive-tree have not brought forth: from this day will I bless you.
<G-vec01000-002-s171><bless.segnen><de> 19 Denn der Same liegt noch in der Scheuer und trägt noch nichts, weder Weinstöcke, Feigenbäume, Granatbäume noch Ölbäume; aber von diesem Tage an will ich Segen geben.
<G-vec01000-002-s172><bless.segnen><en> 'From this day on I will bless you.' "
<G-vec01000-002-s172><bless.segnen><de> Von diesem Tage an will ich Segen geben.
<G-vec01000-002-s173><bless.segnen><en> 2 if you swear, "As Yahweh lives!" truthfully, justly, uprightly, then the nations will bless themselves by him and glory in him.
<G-vec01000-002-s173><bless.segnen><de> 2 und wenn du ohne Heuchelei recht und heilig schwörst: »So wahr der HERR lebt«, dann werden Völker sich Segen wünschen durch ihn und sich seiner rühmen.
<G-vec01000-002-s174><bless.segnen><en> 10 then Toi sent Joram his son to king David, to Greet him, and to bless him, because he had fought against Hadadezer and struck him: for Hadadezer had wars with Toi.
<G-vec01000-002-s174><bless.segnen><de> 10 sandte er seinen Sohn Joram zum König David, ihm Frieden und Segen zu wünschen, weil er gegen Hadad-Eser gekämpft und ihn geschlagen hatte – denn Toï führte Krieg mit Hadad-Eser -, und Joram brachte mit sich silberne, goldene und kupferne Kleinode.
<G-vec01000-002-s175><bless.segnen><en> 10 he sent Hadoram his son to king David, to salute him, and to bless him, because he had fought against Hadarezer and smitten him; (for Hadarezer had wars with Tou;) and [he had with him] all manner of vessels of gold and silver and brass.
<G-vec01000-002-s175><bless.segnen><de> 10sandte er seinen Sohn Hadoram zum König David und ließ ihn grüßen und ihm Segen wünschen, dass er mit Hadad-Eser gekämpft und ihn geschlagen hatte, denn Toï führte Krieg mit Hadad-Eser; und Hadoram brachte mit allerlei goldene, silberne und kupferne Gefäße.
<G-vec01000-002-s176><bless.segnen><en> I bless, whose trouble goes to their heart, that they help them and that they give love to those, who receive no love, because they reject the giver of love.
<G-vec01000-002-s176><bless.segnen><de> Ich segne, denen deren Not zu Herzen geht, daß sie ihnen beistehen und daß sie Liebe geben denen, die keine Liebe empfangen, weil sie den Liebespender ablehnen.
<G-vec01000-002-s177><bless.segnen><en> God bless all those affiliated with your ministry as you search the Scriptures daily for truth.
<G-vec01000-002-s177><bless.segnen><de> Gott segne all jene, die mit Ihrem Dienst verbunden sind, indem Sie die Schrift täglich nach Wahrheit durchsuchen.
<G-vec01000-002-s178><bless.segnen><en> May God bless the State of Israel and may God bless the United States of America.
<G-vec01000-002-s178><bless.segnen><de> Gott segne den Staat Israel und Gott segne die Vereinigten Staaten von Amerika.
<G-vec01000-002-s180><bless.segnen><en> Look up and believe in God, And bless the grave and death.
<G-vec01000-002-s180><bless.segnen><de> Schau auf und glaub an Gott, Und segne Grab und Tod.
<G-vec01000-002-s181><bless.segnen><en> With these sentiments, as I assure you of my remembrance in prayer, I willingly bless all consecrated persons and the Christian communities in which they are called to carry out their mission.
<G-vec01000-002-s181><bless.segnen><de> Mit diesen Gefühlen, während ich ein Gedenken im Gebet zusichere, segne ich alle geweihten Personen und die christlichen Gemeinschaften, in denen sie berufen sind, ihre Sendung zu erfüllen.
<G-vec01000-002-s182><bless.segnen><en> I bless you with health and strength needed to fulfill the divine destiny that God has in store for each of you, that His will may be done by you and through you.
<G-vec01000-002-s182><bless.segnen><de> Ich segne Sie mit Gesundheit und Kraft, die Sie brauchen, um Ihre göttliche Bestimmung zu erfüllen, damit sein Wille durch Sie geschehen möge.
<G-vec01000-002-s183><bless.segnen><en> I most cordially bless you all.
<G-vec01000-002-s183><bless.segnen><de> Ich segne euch alle von ganzem Herzen.
<G-vec01000-002-s184><bless.segnen><en> Loving Shepherd and Holy God, please bless me as I seek to passionately live a life that pleases you and brings you joy.
<G-vec01000-002-s184><bless.segnen><de> Liebender Hirte und heiliger Gott, bitte segne mich in meinem Bemühen, ein leidenschaftliches Leben zu führen, an dem du Wohlgefallen und Freude haben kannst.
<G-vec01000-002-s185><bless.segnen><en> With affection I bless you. English-speaking
<G-vec01000-002-s185><bless.segnen><de> Ich segne euch alle von Herzen.
<G-vec01000-002-s186><bless.segnen><en> As I express to you my grateful appreciation for the service you render to the Church, I assure you of my constant remembrance in prayer and I warmly bless you all.
<G-vec01000-002-s186><bless.segnen><de> Mit meiner dankbaren Wertschätzung für den Dienst, den ihr der Kirche leistet, versichere ich euch meines ständigen Gedenkens im Gebet und segne euch alle von Herzen.
<G-vec01000-002-s187><bless.segnen><en> May Jesus bless you and may the Holy Virgin protect you.
<G-vec01000-002-s187><bless.segnen><de> Jesus segne euch und die Jungfrau Maria beschütze euch.
<G-vec01000-002-s188><bless.segnen><en> For I myself bless the work, which you transact for me and my kingdom.
<G-vec01000-002-s188><bless.segnen><de> Denn Ich Selbst segne die Arbeit, die ihr für Mich und Mein Reich tätigt.
<G-vec01000-002-s189><bless.segnen><en> Hence you cannot say that these people will now have to do penance for the sins of their ancestors but it has always been up to each person to prove himself during the temptations and he will also receive the strength from Me to do so, for I bless this determination and will never abandon such a person to My adversary.
<G-vec01000-002-s189><bless.segnen><de> Ihr könnet also nicht sagen, daß diese Menschen nun büßen müssen für die Sünde ihrer Vorväter, sondern immer stand es einem jeden Menschen frei, sich zu bewähren in den Versuchungen, und er wird auch von Mir aus dazu die Kraft empfangen, denn diesen Willen segne Ich und werde nie einen solchen Menschen Meinem Gegner überlassen.
<G-vec01000-002-s190><bless.segnen><en> God bless you for standing up for the truth of God’s Holy and Inerrant Word.
<G-vec01000-002-s190><bless.segnen><de> Gott segne sie, dass sie für die Wahrheit von Gottes Heiligem und Unfehlbarem Wort eintreten.
<G-vec01000-002-s191><bless.segnen><en> I bless our Father, our Master and our Lord Jesus Christ who, in His great love for us, chooses to revive us at this end of time.
<G-vec01000-002-s191><bless.segnen><de> Ich segne unseren Vater, unseren Meister und unseren Herrn Jesus Christus, der in Seiner großen Liebe sich dafür entschieden hat, uns in diesen Endzeiten zu erwecken.
<G-vec01000-002-s192><bless.segnen><en> Help us Lord in our fear and uncertainty, and bless us with the knowledge that we are secure in your love.
<G-vec01000-002-s192><bless.segnen><de> Hilf uns Herr in unserer Furcht und Ungewissheit und segne uns mit der Erkenntnis, dass wir in Deiner Liebe sicher sind.
<G-vec01000-002-s193><bless.segnen><en> I bless you all with my motherly blessing and I bring you all before my Son Jesus.
<G-vec01000-002-s193><bless.segnen><de> Ich bin mit euch und ich liebe euch alle und segne euch mit meinem mütterlichen Segen.
<G-vec01000-002-s194><bless.segnen><en> I bless every initiative to commemorate his person.
<G-vec01000-002-s194><bless.segnen><de> Ich segne jede Initiative, die seiner Person gedenkt.
<G-vec01000-002-s195><bless.segnen><en> I bless the Lord because He has at last opened our eyes.
<G-vec01000-002-s195><bless.segnen><de> Ich segne den Herrn dafür, dass Er uns schließlich die Augen geöffnet hat.
<G-vec01000-002-s196><bless.segnen><en> God bless these men for saving us countless hours with browsing through the website for the highest quality content.
<G-vec01000-002-s196><bless.segnen><de> Gott segne diese Männer dafür, dass sie uns unzählige Stunden damit erspart haben, die Webseite nach Inhalten von höchster Qualität zu durchsuchen.
<G-vec01000-002-s197><bless.segnen><en> Now, notice that I did not include such things as “love your enemy, bless those that persecute you,” because, in the larger sense, the soul that chooses to serve others, that chooses to see unity in difference will naturally love the enemy and bless persecutors.
<G-vec01000-002-s197><bless.segnen><de> Beachtet, dass ich Sätze wie, “liebe deine Feinde” oder “segne diejenigen, die dich verfolgen” hier nicht mit eingeschlossen haben, denn die Seele, die wählt anderen zu dienen, wählt in einem größeren Sinn auch die Einheit in den Unterschieden zu sehen und sie wird den “Feind” ganz natürlich lieben und ihre “Verfolger” segnen.
<G-vec01000-002-s198><bless.segnen><en> BABAJI: I bless you, who follow these words.
<G-vec01000-002-s198><bless.segnen><de> BABAJI: Ich segne dich, der du diesen Worten folgst.
<G-vec01000-002-s199><bless.segnen><en> Father loved the Cain side completely; through doing that, he could restore history, bless us, and forgive the original sin.
<G-vec01000-002-s199><bless.segnen><de> Vater liebte die Kain-Seite bedingungslos und dadurch konnte er die Geschichte wiederherstellen, uns segnen und die ursprüngliche Sünde vergeben.
<G-vec01000-002-s200><bless.segnen><en> As this couple knelt at the sacred altar, they received promises beyond mortal comprehension that will bless, strengthen, and assist them on their mortal journey.
<G-vec01000-002-s200><bless.segnen><de> Als dieses Paar am heiligen Altar kniete, wurden ihm Verheißungen gemacht, die jenseits der menschlichen Vorstellungskraft liegen und die es auf dem gemeinsamen Lebensweg segnen, stärken und ihm helfen werden.
<G-vec01000-002-s201><bless.segnen><en> Ours the Minds Which join together as We bless the world.
<G-vec01000-002-s201><bless.segnen><de> Unser Denken ist das Denken Welches Sich miteinander vereint während Wir die Welt segnen.
<G-vec01000-002-s202><bless.segnen><en> You owe more than you can ever pay and if you forgive you’ll bless the saints, because you’ll pursue unity.
<G-vec01000-002-s202><bless.segnen><de> Ihr schuldet mehr, als ihr je zurückzahlen könnt, und wenn ihr vergebt, werdet ihr die Heiligen segnen, weil ihr nach Einheit strebt.
<G-vec01000-002-s203><bless.segnen><en> The LORD shall command the blessing upon thee in thy storehouses, and in all that thou settest thine hand unto; and he shall bless thee in the land which the LORD thy God giveth thee.
<G-vec01000-002-s203><bless.segnen><de> Der HERR wird dir den Segen entbieten in deine Speicher und zu allem Geschäft deiner Hand, und er wird dich segnen in dem Land, das der HERR, dein Gott, dir gibt.
<G-vec01000-002-s204><bless.segnen><en> At the porter's lodge, a brother receives people looking for information, those who want a mass celebration or make bless some religious items.
<G-vec01000-002-s204><bless.segnen><de> An der Pforte nimmt ein Bruder die Personen in Empfang, die eine Auskunft suchen, diejenigen, die eine Messe lesen lassen möchten oder einen religiösen Gegenstand segnen lassen wollen.
<G-vec01000-002-s205><bless.segnen><en> We pray to demonstrate our faith in God, that He will do as He has promised in His Word and bless our lives abundantly more than we could ask or hope for (Ephesians 3:20).
<G-vec01000-002-s205><bless.segnen><de> Wir beten um unseren Glauben in Gott zu demonstrieren, das Er tun wird was Er in Seinem Wort versprochen hat, und das Er uns mehr segnen wird als wir darum bitten oder hoffen koennten (Epheser 3:20).
<G-vec01000-002-s206><bless.segnen><en> Our universal loving heart and divine knowledge of enlightenment have infinite power to guide, bless and protect everyone if we react faster and work all together to achieve unity and protection for all in this moment.
<G-vec01000-002-s206><bless.segnen><de> Unser universell liebendes Herz und göttliche Wissen der Erleuchtung haben unendliche Macht, jeden zu führen, zu segnen und zu beschützen, wenn wir schneller reagieren und Alle zusammenarbeiten, um in diesem Moment Einheit und Schutz für alle zu erreichen.
<G-vec01000-002-s207><bless.segnen><en> 24 An altar of earth thou shalt make unto me, and shalt sacrifice thereon thy burnt offerings, and thy peace offerings, thy sheep, and thine oxen: in all places where I record my name I will come unto thee, and I will bless thee.
<G-vec01000-002-s207><bless.segnen><de> 24Einen Altar von Erde sollst du mir machen, darauf du deine Brandopfer und deine Dankopfer, deine Schafe und deine Rinder opferst; an jedem Ort, wo ich meines Namens Gedächtnis stifte, daselbst will ich zu dir kommen und dich segnen.
<G-vec01000-002-s208><bless.segnen><en> 47 And again, verily I say, whomsoever you bless I will bless, and whomsoever you curse I will acurse, saith the Lord; for I, the Lord, am thy God.
<G-vec01000-002-s208><bless.segnen><de> 47 Und weiter, wahrlich, ich sage: Wen auch immer du segnest, den werde ich segnen, und wen auch immer du verfluchst, den awerde ich verfluchen, spricht der Herr; denn ich, der Herr, bin dein Gott.
<G-vec01000-002-s209><bless.segnen><en> They answered all the questions and even individual questions, and they had time to better examine their lives, to bless the Lord for this wonderful study and for all His grace and revelations.
<G-vec01000-002-s209><bless.segnen><de> Sie beantworteten alle Fragen und sogar die individuellen Fragen, und sie hatten Zeit, ihr Leben zu untersuchen, den Herrn für dieses wunderbare Studium und für all Seine Gnaden und Offenbarungen zu segnen.
<G-vec01000-002-s210><bless.segnen><en> With these sentiments, dear friends, I ask the Thrice-Holy to bless you and your families with every spiritual gift and to guide your steps in the way of peace. Shalom aleikhem!
<G-vec01000-002-s210><bless.segnen><de> Mit diesen Gedanken, liebe Freunde, bitte ich den dreimal heiligen Gott, Sie und Ihre Familien mit reichen geistlichen Gaben zu segnen und Ihre Schritte auf dem Weg des Friedens zu leiten.
<G-vec01000-002-s211><bless.segnen><en> I don’t care how you feel, it is your obedience that I will bless.
<G-vec01000-002-s211><bless.segnen><de> Es ist Mir egal, wie du dich fühlst, es ist dein Gehorsam, den Ich segnen werde.
<G-vec01000-002-s212><bless.segnen><en> 13 For °God, having promised to Abraham, since he had no greater to swear by, swore by himself, 14 saying, Surely blessing I will bless thee, and multiplying I will multiply thee; 15 and thus, having had long patience, he got the promise.
<G-vec01000-002-s212><bless.segnen><de> 13 Denn als Gott Abraham verhieß, da er bei keinem Größeren zu schwören hatte, schwur er bei sich selbst 14 und sprach: “Wahrlich, ich will dich segnen und vermehren.” 15 Und also trug er Geduld und erlangte die Verheißung.
<G-vec01000-002-s213><bless.segnen><en> 13 he will bless those who fear the Lord, both the small and the great.
<G-vec01000-002-s213><bless.segnen><de> 13 er wird segnen, die den HERRN fürchten,die Kleinen samt den Großen1.
<G-vec01000-002-s214><bless.segnen><en> The country's top rabbi, Berel Lasar, swooned a few months ago that Russians had "every reason to ask God to bless you.
<G-vec01000-002-s214><bless.segnen><de> So schwärmte Russlands Oberrabbiner vor ein paar Monaten Putin an, das Volk habe "allen Grund, Gott zu bitten, Sie zu segnen.
<G-vec01000-002-s215><bless.segnen><en> Radio that will bless your life.
<G-vec01000-002-s215><bless.segnen><de> Radio, die Ihr Leben segnen wird.
<G-vec01000-002-s216><bless.segnen><en> 20 And he blessed them that day, saying, In thee will Israel bless, saying, God make thee as Ephraim and Manasseh!
<G-vec01000-002-s216><bless.segnen><de> So segnete er sie an jenem Tag und sprach: Mit dir wird man sich in Israel segnen und sagen: Gott mache dich wie Ephraim und Manasse.
<G-vec01000-002-s217><bless.segnen><en> 43 All of the people left. Everyone went home. And David returned home to bless his family.
<G-vec01000-002-s217><bless.segnen><de> 43 Und alles Volk zog hin, ein jeder in sein Haus, und David kehrte auch heim, sein Haus zu segnen.
<G-vec01000-002-s218><bless.segnen><en> Commending to the merciful God all the victims of force and hatred, we bless you from our hearts, praying that "the God of peace may be always with you" (Phil 4:9).
<G-vec01000-002-s218><bless.segnen><de> Indem wir dem barmherzigen Gott alle Opfer von Gewalt und Haß empfehlen, segnen wir euch und bitten von Herzen, daß „der Gott des Friedens immer mit euch sei“ (Phil 4,9).
<G-vec01000-002-s219><bless.segnen><en> And if you humans would only ever consider the suffering you have to endure as a means for purification, as the condition for a cleansing of your soul from all weaknesses and flaws still adhering to it, you would truly bless the suffering and be glad of it, because it will result in your spiritual progress and one day you will also realise why it was necessary during your earthly existence.
<G-vec01000-002-s219><bless.segnen><de> Und würdet ihr Menschen alles Leid, das ihr erdulden müsset, immer nur ansehen als Läuterungsmittel, als die Bedingung für eine Entschlackung eurer Seele von allen ihr noch anhaftenden Schwächen und Fehlern, ihr würdet wahrlich das Leid segnen und euch dessen erfreuen, weil es euch geistigen Fortschritt bringt und einmal ihr es auch erkennen werdet, weshalb es nötig war während eures Erdendaseins.
<G-vec01000-002-s220><bless.segnen><en> Let us make fervent vows to God that He may bless the holy diligence of Bishops, pastors and all those who are responsible for children, so that these may soon unite themselves with Jesus Christ, and continue to remain united with him in the Holy Eucharist.
<G-vec01000-002-s220><bless.segnen><de> Handeln wir also inbrünstig in unseren Berufungen zu Gott, der die heiligen Geschicke der Bischöfe segnen möge, die der Gemeindepriester und all jener, die sich der Kinder annehmen, damit diese sich so frühzeitig wie möglich mit Jesus Christus vereinigen können und fortgesetzt mit Ihm in Seiner Heiligen Eucharistie vereint bleiben.
<G-vec01000-002-s221><bless.segnen><en> I extend a special greeting to the pilgrims from Malaysia and Singapore, and I pray that Almighty God will continue to bless you and your families with vigorous faith and generosity in works of charity.
<G-vec01000-002-s221><bless.segnen><de> Einen besonderen Gruß richte ich an die Pilger aus Malaysia und Singapur, und ich bete dafür, daß der allmächtige Gott euch und eure Familien weiterhin mit einem starken Glauben und mit Großherzigkeit in den Werken der Barmherzigkeit segnen möge.
<G-vec01000-002-s222><bless.segnen><en> We pray that God will bless you as you seek to make the best decisions for your child’s future.
<G-vec01000-002-s222><bless.segnen><de> Wir beten, dass Gott Sie in Ihrem Bestreben segnen möge, die beste Entscheidung für die Zukunft Ihres Kindes zu treffen.
<G-vec01000-002-s223><bless.segnen><en> It's my turn, he says, if you'll forgive him you'll bless me, you'll benefit me in the Lord.
<G-vec01000-002-s223><bless.segnen><de> Jetzt bin ich dran, sagt er, wenn du ihm vergibst, wirst du mich segnen, du wirst mir im Herrn nützlich sein.
<G-vec01000-002-s224><bless.segnen><en> The Prophet's seal, may God bless him and grant him peace, on the cover of the books is symbolic and is linked to the their contents. It represents the Qur'an (the final scripture) and the Prophet Mohammed, may God bless him and grant him peace, the last of the prophets.
<G-vec01000-002-s224><bless.segnen><de> Das Siegel des Propheten, das auf dem Umschlag aller Bücher des Autors abgebildet ist, symbolisiert, dass der Quran das letzte Buch und das letzte Wort Allahs ist und dass der Prophet Muhammad (Möge Allah ihn segnen und Frieden auf ihm sein lassen) der letzte der Propheten ist.
<G-vec01000-002-s225><bless.segnen><en> 10 You drench its furrows and level its ridges; you soften it with showers and bless its crops.
<G-vec01000-002-s225><bless.segnen><de> 10 Du tränkest seine Furchen und feuchtest sein Gepflügtes; mit Regen machst du es weich und segnest sein Gewächs.
<G-vec01000-002-s226><bless.segnen><en> 65:10 You water the ridges thereof abundantly: you settle the furrows thereof: you make it soft with showers: you bless the springing thereof.
<G-vec01000-002-s226><bless.segnen><de> 65:10 Du tränkest ihre Furchen, ebnest ihre Schollen, du erweichst sie mit Regengüssen, segnest ihr Gewächs.
<G-vec01000-002-s227><bless.segnen><en> But Jacob said, "I will not let you go, unless you bless me."
<G-vec01000-002-s227><bless.segnen><de> Er entgegnete: Ich lasse dich nicht los, wenn du mich nicht segnest.
<G-vec01000-002-s228><bless.segnen><en> God, I commit this group of people, Brother Leo and Brother Gene, and all the followers here, into Your hands, that You'll bless them and love them, forgiving all their iniquities, healing all of their diseases, keeping them ever in love and fellowship, and encouraging those who would--would be--get weary.
<G-vec01000-002-s228><bless.segnen><de> Gott, ich übergebe Dir diese Gruppe von Menschen, Bruder Leo und Bruder Gene und all die Nachfolger hier, in Deine Hände, damit Du sie segnest und liebst, all ihre Ungerechtigkeiten vergibst, all ihre Krankheiten heilst, sie immer in Liebe und Gemeinschaft hältst und jene ermutigst, die würden... müde würden.
<G-vec01000-002-s229><bless.segnen><en> They have settled next to me. Now please come and curse this people for me because they are stronger than I am. Perhaps I’ll be able to destroy them and drive them from the land, for I know that whomever you bless is blessed and whomever you curse is cursed.”
<G-vec01000-002-s229><bless.segnen><de> 6 Numeri 22 Balak sendet Boten zu Bileam mit dem Auftrag: 6 So komm nun und verfluche mir das Volk, denn es ist mir zu mächtig; vielleicht kann ich's dann schlagen und aus dem Lande vertreiben; denn ich weiß: Wen du segnest, der ist gesegnet, und wen du verfluchst, der ist verflucht.
<G-vec01000-002-s230><bless.segnen><en> Yahweh will bless his people with peace.
<G-vec01000-002-s230><bless.segnen><de> Der Herr segnet sein Volk mit Frieden.
<G-vec01000-002-s231><bless.segnen><en> 12 The LORD hath been mindful of us: he will bless us; he will bless the house of Israel; he will bless the house of Aaron. 13 He will bless them that fear the LORD, both small and great.
<G-vec01000-002-s231><bless.segnen><de> Er segnet das Haus Israel; er segnet das Haus Aaron; 13 er segnet, die den HERRN fürchten, beide Kleine und Große.
<G-vec01000-002-s234><bless.segnen><en> it shall be for the stranger, for the fatherless, and for the widow; that Jehovah thy God may bless thee in all the work of thy hands.
<G-vec01000-002-s234><bless.segnen><de> Für den Fremden, für die Waise und für die Witwe soll sie sein, damit der HERR, dein Gott, dich segnet in allem Tun deiner Hände.
<G-vec01000-002-s235><bless.segnen><en> Father Gabriel – God bless you, brother Petar.
<G-vec01000-002-s235><bless.segnen><de> Vater Gavrilo: Gott segnet Dich, Bruder P.
<G-vec01000-002-s236><bless.segnen><en> Father Gabriel: God bless you.
<G-vec01000-002-s236><bless.segnen><de> Vater Gavrilo: Gott segnet Dich.
<G-vec01000-002-s237><bless.segnen><en> 140:3.15 "I say to you: Love your enemies, do good to those who hate you, bless those who curse you, and pray for those who despitefully use you.
<G-vec01000-002-s237><bless.segnen><de> 140:3.15 (1571.2) „Ich sage euch: Liebet eure Feinde, tut denen Gutes, die euch hassen, segnet jene, die euch verfluchen und betet für jene, die sich euch verächtlich zunutze machen.
<G-vec01000-002-s238><bless.segnen><en> “I say to you: Love your enemies, do good to those who hate you, bless those who curse you, and pray for those who despitefully use you.
<G-vec01000-002-s238><bless.segnen><de> Ich sage euch: Liebet eure Feinde, tut denen Gutes, die euch hassen, segnet jene, die euch verfluchen und betet für jene, die sich euch verächtlich zunutze machen.
<G-vec01000-002-s239><bless.segnen><en> Toss the weeds aside as you may, and bless them too.
<G-vec01000-002-s239><bless.segnen><de> Reißt die Wildkräuter heraus, wenn ihr mögt, und segnet sie gleichfalls.
<G-vec01000-002-s240><bless.segnen><en> Bless it every now and then as it was done in olden days.
<G-vec01000-002-s240><bless.segnen><de> Segnet sie immer wieder, wie man das in früheren Tagen gemacht hat.
<G-vec01000-002-s241><bless.segnen><en> The air you breathe, just breathing it in, the air it bless you 15%.
<G-vec01000-002-s241><bless.segnen><de> Die Luft, die ihr atmet, nur durch das Einatmen, segnet einen die Luft zu 15 %.
<G-vec01000-002-s242><bless.segnen><en> Bless those who persecute you; bless and do not curse them.
<G-vec01000-002-s242><bless.segnen><de> Segnet, die euch verfolgen; segnet und fluchet nicht.
<G-vec01000-002-s244><bless.segnen><en> But I say unto you, Love your enemies, bless them that curse you, do good to them that hate you, and pray for them which despitefully use you and persecute you; that ye may be the children of your Father which is in heaven; for he maketh his sun to rise on the evil and on the good, and sendeth rain on the just and the unjust.
<G-vec01000-002-s244><bless.segnen><de> Mt 5,16: „So soll euer Licht leuchten vor den Leuten, dass sie eure guten Werke sehen und euren Vater im Himmel preisen.“ Mt 5,44-45: „Ich aber sage euch: Liebt eure Feinde, segnet, die euch fluchen, tut wohl denen, die euch hassen, und bittet für die, welche euch beleidigen und verfolgen, damit ihr Söhne eures Vaters im Himmel seid.
<G-vec01000-002-s245><bless.segnen><en> ....if you wish someone to pray for, bless and anoint you. Pastor Joh.
<G-vec01000-002-s245><bless.segnen><de> ....wenn Sie möchten, dass man für Sie betet, Sie segnet, Sie salbt usw.
<G-vec01000-002-s246><bless.segnen><en> 13 He that holds her fast will inherit glory; And where * he enters, the Lord will bless.
<G-vec01000-002-s246><bless.segnen><de> 14 Wer fest an ihr hält, der wird große Ehre erlangen; und wo er einkehrt, da segnet der Herr.
<G-vec01000-002-s247><bless.segnen><en> Rise in the power of Elijah and bless your children, let them know you love them.
<G-vec01000-002-s247><bless.segnen><de> Erhebt euch in der Macht des Elia und segnet eure Kinder, lasst sie wissen, dass ihr sie liebt.
<G-vec01000-002-s248><bless.segnen><en> In contrast, the Lord assures us that when we have virtuous thoughts, He will bless us with confidence, even the confidence to know who we really are.
<G-vec01000-002-s248><bless.segnen><de> Im Gegensatz dazu versichert uns der Herr, dass er uns mit Selbstvertrauen segnet, wenn wir tugendhafte Gedanken haben – sogar in solchem Maße, dass wir erkennen, wer wir wirklich sind.
<G-vec01000-002-s249><bless.segnen><en> 20 And Eli used to bless Elkanah and his wife, and to sayYahweh give thee seed of this woman, instead of the loan that hath been lent unto Yahweh.
<G-vec01000-002-s249><bless.segnen><de> 20 Und Eli segnete Elkana und sein Weib und sprach: Der HERR gebe dir Samen von diesem Weibe um der Bitte willen, die sie vom HERRN gebeten hat.
<G-vec01000-002-s250><bless.segnen><en> 20Then Eli would bless Elkanah and his wife, and say to Elkanah, “May the Lord give you other children by this woman to take the place of the one you dedicated to him.”
<G-vec01000-002-s250><bless.segnen><de> 20Und Eli segnete Elkana und sein Weib und sprach: Jehova gebe dir Samen von diesem Weibe an Stelle des Geliehenen, das man Jehova geliehen hat.
<G-vec01000-002-s251><bless.segnen><en> It became true, in the same month God bless us with a child.
<G-vec01000-002-s251><bless.segnen><de> Es wurde wahr, im selben Monat segnete Gott uns mit einem Kind.
<G-vec01000-002-s252><bless.segnen><en> I had made a promise to God to always do my best if he would bless me with children and would never think for a moment to leave this world by my own hand (suicide).
<G-vec01000-002-s252><bless.segnen><de> Ich hatte Gott versprochen, immer mein Bestes zu geben, wenn er mich mit Kindern segnete und ich würde nie daran denken, diese Welt durch meine eigene Hand (Selbstmord) zu verlassen.
<G-vec01000-002-s253><bless.segnen><en> In St Peter’s Square hundreds of children and adults held up a "Baby Jesus" for the Holy Father to bless at the end of the Marian prayer.
<G-vec01000-002-s253><bless.segnen><de> Auf dem Petersplatz hielten Hunderte von Kindern und Erwachsenen ein Jesuskind in der Hand; der Heilige Vater segnete sie am Schluss des Gebetes.
<G-vec01000-002-s254><bless.segnen><en> Unbelieving fanatics of the law had long wanted to kill Paul. He, however, chose to evangelize and bless them.
<G-vec01000-002-s254><bless.segnen><de> Ungläubige Gesetzesfanatiker wollten Paulus schon lange töten, er aber evangelisierte und segnete sie.
<G-vec01000-002-s255><bless.segnen><en> She proceeded to bless the rosaries in the Name of the Father and of the Son and of the Holy Spirit.
<G-vec01000-002-s255><bless.segnen><de> Dann segnete sie die Rosenkränze im Namen des Vaters und des Sohnes und des Heiligen Geistes und nahm uns alle unter ihren schützenden Mantel.
<G-vec01000-002-s256><bless.segnen><en> Not only did his mouth bless the name of God, but in his heart he also blessed the name of God; his mouth and heart were as one.
<G-vec01000-002-s256><bless.segnen><de> Nicht nur segnete sein Mund den Namen Gottes, sondern er segnete auch in seinem Herzen den Namen Gottes; sein Mund und sein Herz waren eins.
<G-vec01000-002-s257><bless.segnen><en> Fortunately, Father came out to meet and bless us; as a result, Paul found the strength to enter the church sanctuary.
<G-vec01000-002-s257><bless.segnen><de> Zum Glück kam uns der Pater entgegen und segnete uns, was Paul die Kraft gab, um ins Heiligtum eintreten zu können.
<G-vec01000-002-s115><bless.sein><en> Bless the body, indeed, for it is what you have created to be able to experience the wonders called physicality.
<G-vec01000-002-s115><bless.sein><de> Gesegnet sei der Körper, wirklich, denn ihr habt ihn euch geschaffen um die Wunder der so genannten Materie zu erfahren.
<G-vec01000-002-s116><bless.sein><en> Bless Be the name YHVH forever, Amen and Amen.
<G-vec01000-002-s116><bless.sein><de> Gesegnet Sei der Name YHVH für immer, Amen und Amen.
