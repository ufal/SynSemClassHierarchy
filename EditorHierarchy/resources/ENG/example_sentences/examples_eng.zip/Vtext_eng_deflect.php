<G-vec00049-002-s031><deflect.abwehren><en> The Company ensures to take all reasonable measures to deflect such attacks and provide you with a secure and smooth trading experience.
<G-vec00049-002-s031><deflect.abwehren><de> Das Unternehmen garantiert, alle vertretbaren Maßnahmen zu ergreifen, um solche Angriffe abzuwehren und Ihnen ein sicheres und reibungsloses Handelserlebnis zu bieten.
<G-vec00049-002-s032><deflect.abwehren><en> Therefore a feeling of shame can be spread amongst people as each shamed person tries to deflect shame from themselves by making other people feel ashamed.
<G-vec00049-002-s032><deflect.abwehren><de> Dadurch kann sich ein Gefühl von Scham unter Menschen ausbreiten, indem jede beschämte Person versucht, Scham von sich selber abzuwehren, indem sie andere beschämt.
<G-vec00049-002-s033><deflect.abwehren><en> Activate Finn's sword to grapple and deflect lasers when solving puzzles and fighting enemies.
<G-vec00049-002-s033><deflect.abwehren><de> Aktiviere Finns Schwert, um zu greifen und Laser abzuwehren, wenn du Rätsel löst und Gegner bekämpfst.
<G-vec00049-002-s068><deflect.abwenden><en> Deflect volatile questions.
<G-vec00049-002-s068><deflect.abwenden><de> Wende brisante Fragen ab.
