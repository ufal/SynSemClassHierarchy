<G-vec00206-001-s019><count.abzählen><en> They can count on the fingers.
<G-vec00206-001-s019><count.abzählen><de> Sie können an den Fingern abzählen.
<G-vec00206-001-s020><count.abzählen><en> In line 16, there is a ruler, which is supposed to make it easier for you to count the columns.
<G-vec00206-001-s020><count.abzählen><de> In Zeile 16 ist ein Lineal zu sehen, das das Abzählen von Spalten erleichtern soll.
<G-vec00206-001-s021><count.abzählen><en> "The Westinghouse Company presented ""Elektro"", a ""moto-man"", 7 feet (2,13 meter) large and 130 kilo heavy, which was able to count by his fingers [not really]."
<G-vec00206-001-s021><count.abzählen><de> "Die Firma Westinghouse präsentierte ""Elektro"" einen ""Moto-man"", 7 Fuß (2,13 Meter) gross und 130 Kilo schwer, der an den Fingern abzählen konnte [nicht wirklich]."
<G-vec00206-001-s022><count.abzählen><en> "9 ""You shall count seven weeks for yourself; you shall begin to count seven weeks from the time you begin to put the sickle to the standing grain."
<G-vec00206-001-s022><count.abzählen><de> 9 Sieben Wochen sollst du dir abzählen; wenn man anfängt, die Sichel an die Saat zu legen, sollst du anfangen, sieben Wochen zu zählen.
<G-vec00206-001-s023><count.abzählen><en> Until 2012, e-bike experts could still easily count the number of drive systems currently on the market on one hand.
<G-vec00206-001-s023><count.abzählen><de> Bis 2012 konnten E-Bike-Experten die Anzahl der marktrelevanten Antriebssysteme noch relativ leicht mit einer Hand abzählen.
<G-vec00206-001-s024><count.abzählen><en> Once again, the middle lines are drawn and the distance from it to the front, back, left and right are plotted (simply count the studs based on the front and side view).
<G-vec00206-001-s024><count.abzählen><de> Dazu werden ebenfalls wieder erst die vorhandenen Mittelachsen eingezeichnet und anschließend die Abstände der Mittelachsen nach rechts, links, vorne und hinten (einfach aus Seiten- und Frontansicht abzählen).
<G-vec00206-001-s025><count.abzählen><en> And you will be able to count the chosen ones of even a prominent place, very easily on your fingers.
<G-vec00206-001-s025><count.abzählen><de> - Und ihr werdet die Auserwählten eines bedeutenden Ortes sehr leicht an den Fingern abzählen können.
<G-vec00206-001-s026><count.abzählen><en> On two occasions I was placed over a chair and received 25 strokes with a rubber hose, which they obliged me to count myself.
<G-vec00206-001-s026><count.abzählen><de> Ich erhielt auf einem Stuhl liegend zweimal 25 Hiebe mit einem Gummischlauch, die ich selbst abzählen musste.
<G-vec00206-001-s027><count.abzählen><en> I can probably count on one hand the companies that I know who make an aisle runner worth anything.
<G-vec00206-001-s027><count.abzählen><de> Ich kann wahrscheinlich an einer Hand abzählen die Unternehmen, die ich kenne, der eine Schneise Läufer machen etwas wert.
<G-vec00206-001-s028><count.abzählen><en> We hurried onward and after the length of time it takes to count to a thousand, we came to the first cataract on the Nile.
<G-vec00206-001-s028><count.abzählen><de> Wir beschleunigten unsere Schritte und waren in der Zeit, in der man tausend Steine abzählen würde, an der ersten Abfallstelle des Nils.
<G-vec00206-001-s029><count.abzählen><en> You shall count seven weeks to yourselves;
<G-vec00206-001-s029><count.abzählen><de> Sieben Wochen sollst du dir abzählen.
<G-vec00206-001-s030><count.abzählen><en> The Jews, practical people that they are, were able to count on their fingers that “German fists” which have been unable to overthrow their own Prussian reaction, can hardly be expected to smash Russian absolutism. The Poles, exposed to the triple-headed war, were not in a position to answer their “liberators” in audible language.
<G-vec00206-001-s030><count.abzählen><de> Die Juden, ein praktisches Volk wie sie sind, mochten sich das einfache Rechenexempel an den Fingern abzählen, daß die „deutschen Fäuste“, die es nicht einmal fertiggebracht haben, ihre eigene preußische Reaktion, zum Beispiel das Dreiklassenwahlrecht, zu „zerschmettern“, wohl wenig tauglich sind, den russischen Absolutismus zu zerschmettern.
<G-vec00206-001-s031><count.abzählen><en> You have closely observed and seen that she can intuitively capture small quantities, but not yet count them safely.
<G-vec00206-001-s031><count.abzählen><de> Du hast genau beobachtet und gesehen, dass sie kleine Mengen zwar intuitiv erfassen, aber noch nicht sicher abzählen kann.
<G-vec00206-001-s033><count.abzählen><en> Anyway, in these parts it does not matter at all, since you can possibly count the buyers on one hand;) Bottom line: nice compilation, but far too much customized on the Spanish market.
<G-vec00206-001-s033><count.abzählen><de> Aber das dürfte hierzulande wohl sowieso egal sein, denn die Käufer kann man wohl an einer Hand abzählen;) Fazit: nette Compilation, die jedoch stark auf den spanischen Markt zugeschnitten ist.
<G-vec00206-001-s034><count.abzählen><en> If you rule out the “visits” when they were just bringing my Mom to see me, or pick her up, I can count on the toes of one hand how many times my family has visited me in those 21 years.
<G-vec00206-001-s034><count.abzählen><de> "Wenn Sie ausschließen, die ""Besuche"", wenn sie nur darauf, meine Mom, mich zu sehen, oder sie abholen, Ich kann auf die Zehen einer Hand abzählen, wie oft meine Familie hat mich in jene besucht 21 Jahre."
<G-vec00206-001-s035><count.abzählen><en> Our personal experience has shown that while it is mostly cloudy in July, but real rainy days you could count in the past 3 years on one hand, usually there was a heavy shower sometimes, but after half an hour it was all over.
<G-vec00206-001-s035><count.abzählen><de> Unsere persönliche Erfahrung hat gezeigt, dass es im Juli zwar mehrheitlich bewölkt ist, richtige Regentage konnte man aber in den letzten 3 Jahren an einer Hand abzählen, meist gab es ab und zu einen kräftigen Guss, nach einer halben Stunde war aber alles wieder vorbei.
<G-vec00206-001-s036><count.abzählen><en> You can count the number of polo clubs on one hand, and there are fewer than a hundred active polo players.
<G-vec00206-001-s036><count.abzählen><de> Die Polo Clubs lassen sich an einer Hand abzählen und die Zahl der aktiven Polo Player bewegt sich im zweistelligen Bereich.
<G-vec00206-001-s037><count.abzählen><en> I can count the jewelry that I wear every day on one hand: a few precious rings, my watch, a couple of necklaces, all quite simple, nothing too loud.
<G-vec00206-001-s037><count.abzählen><de> Die Schmuckstücke, die ich jeden Tag trage, kann ich an einer Hand abzählen: Einige mir wertvolle Ringe, meine Uhr, ein paar Ketten, alles eher zurückhaltend als prunkvoll.
<G-vec00206-001-s132><count.gelten><en> All scheduled MTTs with cash buy-ins will count towards this promotion.
<G-vec00206-001-s132><count.gelten><de> Alle geplanten MTTs mit Cash Buy-Ins gelten für diese Aktion.
<G-vec00206-001-s133><count.gelten><en> The British count as the pioneers of Swiss Tourism.
<G-vec00206-001-s133><count.gelten><de> Die Briten gelten als die Pioniere des Schweizer Tourismus.
<G-vec00206-001-s134><count.gelten><en> The Hohe Tauern National Park and its surrounding mountains count as the largest winter hiking territory in the Eastern Alps.
<G-vec00206-001-s134><count.gelten><de> Der Nationalpark Hohe Tauern und seine umliegenden Berge gelten als das größte Winterwanderrevier der Ostalpen.
<G-vec00206-001-s135><count.gelten><en> "It had already been agreed upon earlier which game was to count: ""Three under a hundred"" or ""Three-five-seven."""
<G-vec00206-001-s135><count.gelten><de> "Bevor dies geschah, wurde bereits vereinbart, welches Spiel gelten sollte: ""Drei unter Hundert"" oder ""Drei - fünf - sieben""."
<G-vec00206-001-s136><count.gelten><en> If I told you there would be more you would wait and be prepared, and then it wouldn’t count as one.
<G-vec00206-001-s136><count.gelten><de> Wenn ich dir sagen würde, dass es noch Chancen gibt, und du darauf warten und dich darauf vorbereiten würdest, würde es dann auch nicht mehr gelten.
<G-vec00206-001-s137><count.gelten><en> Treated and processed goods shall count as reserved merchandise as defined by these conditions.
<G-vec00206-001-s137><count.gelten><de> Be- und verarbeitete Ware gelten als Vorbehaltsware im Sinne dieser Bedingungen.
<G-vec00206-001-s138><count.gelten><en> "When she asked for it back, the police officer who was in charge of household registry said, ""Our words do not count for anything."
<G-vec00206-001-s138><count.gelten><de> "Als sie um die Rückgabe bat, sagte der für die Registrierung der Haushalte verantwortliche Polizist: ""Unsere Worte gelten nicht für alles."
<G-vec00206-001-s139><count.gelten><en> For the young people participating in our discussion, unlike for former generations, it is not only the important acts of great men that count as historical events but also the past of every-day people.
<G-vec00206-001-s139><count.gelten><de> Anders als dies wohl für frühere Generationen der Fall gewesen ist, gelten den hier zu Wort kommenden Jugendlichen eben nicht allein die bedeutenden Taten großer Männer als geschichtliche Ereignisse, sondern ebenso die Vergangenheit alltäglicher Menschen.
<G-vec00206-001-s140><count.gelten><en> How many children does each parent have for whom he or she has to make so many sacrifices of so many sorts before the children can grow to the point where they really count as human beings and the parents can relax some of their concern.
<G-vec00206-001-s140><count.gelten><de> Wieviele Kinder haben Eltern, für die sie so viele Opfer, so verschiedener Art bringen müssen, bevor die Kinder zu einem Punkt heranwachsen, an dem sie wirklich als menschliche Wesen gelten, und sich deren Eltern zu einem gewissen Punkt entspannen können.
<G-vec00206-001-s141><count.gelten><en> If you lose your job after working in your new country for more than 1 year, you have the right to continue to live there, provided you are registered as a jobseeker and continue to meet the conditions to count as a jobseeker.
<G-vec00206-001-s141><count.gelten><de> Wenn Sie Ihren Job verloren haben, nachdem Sie mehr als ein Jahr lang in Ihrem neuen Land gearbeitet haben, dürfen Sie weiterhin dort wohnen, sofern Sie als arbeitssuchend gemeldet sind und die Voraussetzungen erfüllen, um als Arbeitssuchende/-r zu gelten.
<G-vec00206-001-s142><count.gelten><en> Clothes regulations of the Taliban count to this piece of way.
<G-vec00206-001-s142><count.gelten><de> Für dieses Stück Weg gelten die Kleidungsvorschriften der Taliban.
<G-vec00206-001-s143><count.gelten><en> If they're dramatic, they count as feelings, they exist; if they're not dramatic, they don't count and they don't really exist.
<G-vec00206-001-s143><count.gelten><de> Wenn sie dramatisch sind, zählen sie als Gefühl, sie sind vorhanden; wenn sie nicht dramatisch sind, gelten sie nicht und sind eigentlich nicht vorhanden.
<G-vec00206-001-s144><count.gelten><en> The same conditions count for the eastern board of the Praya River. There the reserve was in March 2013 - as one can see on the photo, not more than 30 to 50cm, and every year it is 6 cm less...
<G-vec00206-001-s144><count.gelten><de> Dieselben Verhältnisse gelten für das Ostufer: Die Reserve betrug im März 2013 - so wie man auf dem Foto sieht, kaum mehr als 30 bis 50cm, und jedes Jahr werden es 6cm weniger...
<G-vec00206-001-s145><count.gelten><en> "Thinking: ""A friend is one, before which I am allowed to think loudly"" This quotation of the American philosopher Ralph Waldo Emerson will count also for our partnership."
<G-vec00206-001-s145><count.gelten><de> "Denken: ""Ein Freund ist einer, vor dem ich laut denken darf"" Dieses Zitat des amerikanischen Philosophen Ralph Waldo Emerson wird auch für unsere Partnerschaft gelten."
<G-vec00206-001-s146><count.gelten><en> Several ballot papers in one ballot paper envelope shall be regarded as one ballot paper if the markings are identical or if only one of them has been marked; otherwise they shall count as one ballot paper with two invalid votes.
<G-vec00206-001-s146><count.gelten><de> Mehrere in einem Stimmzettelumschlag enthaltene Stimmzettel gelten als ein Stimmzettel, wenn sie gleich lauten oder nur einer von ihnen gekennzeichnet ist; sonst gelten sie als ein Stimmzettel mit zwei ungültigen Stimmen.
<G-vec00206-001-s147><count.gelten><en> Because the glaciers found on Mars hold the greatest amount of water ice outside its poles – and therefore count as a possible candidate to find life on Mars. The Kaunertaler glacier is in many ways comparable to the glaciers on the red planet.
<G-vec00206-001-s147><count.gelten><de> Denn die bisher entdeckten Gletscher auf dem Mars halten die größten Mengen an Wassereis außerhalb der Pole – und gelten deshalb als ein möglicher Kandidat für Leben auf dem Mars.
<G-vec00206-001-s148><count.gelten><en> All part shipments of a contract count as special business operations.
<G-vec00206-001-s148><count.gelten><de> Alle Teillieferungen eines Abschlusses gelten als besondere Geschäfte.
<G-vec00206-001-s149><count.gelten><en> The following qualifications count as suitable evidence of these skills: certificates from higher technical institutes, universities and third-level colleges and relevant training courses.
<G-vec00206-001-s149><count.gelten><de> Als Nachweis gelten Zeugnisse von Höheren technischen Lehranstalten, Zeugnisse von Universitäten und Fachhochschulen sowie Bestätigungen über einschlägige Fort- und Weiterbildungen.
<G-vec00206-001-s150><count.gelten><en> The most popular functional areas of transportation, turnover, consignment sales, packaging as well as control of production processes count as the most popular applications within logistics.
<G-vec00206-001-s150><count.gelten><de> Als populärste Anwendungen innerhalb der Logistik gelten die Funktionsbereiche Transport, Umschlag, Kommissionierung, Verpackung sowie die Steuerung von Produktionsabläufen.
<G-vec00206-001-s151><count.zählen><en> Red threes count for the players if they are laid down on the table with their melds and against if not.
<G-vec00206-001-s151><count.zählen><de> Die roten Dreien werden für den Spieler gezählt, wenn diese auf dem Tisch neben dessen Meldung liegen, und gegen den Spieler, wenn dies nicht der Fall ist.
<G-vec00206-001-s152><count.zählen><en> With five reels and five paylines come Dragons treasure and all winnings will count from left to right.
<G-vec00206-001-s152><count.zählen><de> Mit fünf Walzen und fünf Gewinnlinien ist Dragons Treasure ausgestattet und die Gewinne werden von links nach rechts gezählt.
<G-vec00206-001-s153><count.zählen><en> Any hands and/or games played prior to opting in will not count towards the progress.
<G-vec00206-001-s153><count.zählen><de> Alle Hände und/oder Spiele, die Sie vor der Anmeldung gespielt haben, werden nicht gezählt.
<G-vec00206-001-s154><count.zählen><en> In this article, I will talk about how to count the unique values in pivot table.
<G-vec00206-001-s154><count.zählen><de> In diesem Artikel werde ich darüber sprechen, wie die eindeutigen Werte in der Pivot-Tabelle gezählt werden.
<G-vec00206-001-s155><count.zählen><en> The owner was furious, but the owner was an Indian, so his opinion did not count for much.
<G-vec00206-001-s155><count.zählen><de> Der Besitzer war wütend, aber der Besitzer war ein Indianer, also hat seine Meinung nicht viel gezählt.
<G-vec00206-001-s156><count.zählen><en> Here I will provide a specific example to explain how to count cells particle equal to given value.
<G-vec00206-001-s156><count.zählen><de> Hier werde ich ein konkretes Beispiel geben, um zu erklären, wie Zellenpartikel mit dem angegebenen Wert gezählt werden.
<G-vec00206-001-s157><count.zählen><en> Note that the bishops on a1 and h1 are exchangeable with pawns at the same positions. I count this as one solution only.
<G-vec00206-001-s157><count.zählen><de> Bei der ersten Stellung sind die Läufer auf a1 und h1 mit den Bauern auf den gleichen Positionen austauschbar und deshalb wird diese nur als eine Lösung gezählt.
<G-vec00206-001-s158><count.zählen><en> The only field defined in mt_erreg is the recovered error count in the low 16 bits (as defined by MT_ST_SOFTERR_SHIFT and MT_ST_SOFTERR_MASK).
<G-vec00206-001-s158><count.zählen><de> "Das einzige definierte Feld in mt_erreg ist der "" Fehlerzähler"" (Es werden nur behobene Fehler gezählt) in den unteren 16 Bits (wie durch MT_ST_SOFTERR_SHIFT und MT_ST_SOFTERR_MASK definiert)."
<G-vec00206-001-s159><count.zählen><en> Early marriage and desire for sons is believed to be the biggest problems, but also developing country problems such as illiteracy and ignorance about contraception count as major concerns.
<G-vec00206-001-s159><count.zählen><de> Frühe Heirat und der Wunsch nach Söhnen wird angenommen, dass die größten Probleme, sondern auch die Entwicklungsländer Probleme wie Analphabetismus und Unwissenheit über Empfängnisverhütung als wichtige Anliegen gezählt.
<G-vec00206-001-s160><count.zählen><en> Although the pin count is loaded to one side, there is no lack of rivalry in this extraordinary encounter that sees both contrasting combatants perform with breathtaking determination.
<G-vec00206-001-s160><count.zählen><de> Obwohl die Pins nur auf einer Seite gezählt werden fehlt es nicht an Rivalität in diesem aussergewöhnlichem Kampf, in welchem beide gegensätzlichen Kämpferinnen mit atemberaubender Zielstrebigkeit performen.
<G-vec00206-001-s161><count.zählen><en> In the formula, A2 contains the text string which you want to count occurrences of specific character from.
<G-vec00206-001-s161><count.zählen><de> In der Formel A2 enthält die Textzeichenfolge, aus der Vorkommen von bestimmten Zeichen gezählt werden sollen.
<G-vec00206-001-s162><count.zählen><en> I can tell you that my Law Bodies are innumerable, they're impossible to count.
<G-vec00206-001-s162><count.zählen><de> Ich sage euch, ich habe unzählige Fashen, die nicht gezählt werden können.
<G-vec00206-001-s163><count.zählen><en> Biggest number of servers is in the US, I think I didn't count.
<G-vec00206-001-s163><count.zählen><de> Größte Anzahl von Servern in den USA, Ich glaube, ich habe sie nicht gezählt.
<G-vec00206-001-s164><count.zählen><en> The COUNTIF function is a statistical function in Excel which is used to count the number of cells that meet a criterion.
<G-vec00206-001-s164><count.zählen><de> Die COUNTIF function ist eine statistische Funktion in Excel, mit der die Anzahl der Zellen gezählt wird, die ein Kriterium erfüllen.
<G-vec00206-001-s165><count.zählen><en> Select the range that you will count cells by specific formatting, and open the Find and Replace dialog by pressing the Ctrl + F keys simultaneously.
<G-vec00206-001-s165><count.zählen><de> Wählen Sie den Bereich aus, in dem die Zellen nach einer bestimmten Formatierung gezählt werden, und öffnen Sie das Dialogfeld Suchen und Ersetzen, indem Sie die Taste drücken Ctrl + F Schlüssel gleichzeitig.
<G-vec00206-001-s166><count.zählen><en> We didn't count the stairs to the top of the 64 meter (210 feet) tall pyramid but some of them are so high that cables have been put in to help visitors climb up hand over hand.
<G-vec00206-001-s166><count.zählen><de> Wir haben die Stufen bis zur Spitze der 64m hohen Pyramide nicht gezählt, aber einige von ihnen sind so hoch, dass zur Unterstützung der Kletterer Seile angebracht wurden, an denen man sich in die Höhe hangeln kann.
<G-vec00206-001-s167><count.zählen><en> 1) In the formula, B1 and B2 contain the start date and end date you will count days between.
<G-vec00206-001-s167><count.zählen><de> 1) In der Formel enthalten B1 und B2 das Startdatum und das Enddatum, zwischen denen die Tage gezählt werden.
<G-vec00206-001-s168><count.zählen><en> Note that 802.11 Management Frames and Control Frames don't count as data. Roam performance
<G-vec00206-001-s168><count.zählen><de> Beachten Sie, dass 802.11-Verwaltungs- und Steuerungs-Frames nicht als Daten gezählt werden.
<G-vec00206-001-s169><count.zählen><en> Major molecular response (MMR) —PCR (a blood test that allows to detect and count very small amounts of specific parts of a gene) can still detect BCR-ABL, but at a low level (BCR-ABL levels below 0.1%).
<G-vec00206-001-s169><count.zählen><de> Gutes molekulares Ansprechen (MMR) —Mit PCR (einem Bluttest, mit dem sehr kleine Mengen eines bestimmten Teils eines Gens entdeckt und gezählt werden können) ist immer noch BCR-ABL nachweisbar, allerdings in sehr geringer Menge (Menge an BCR-ABL unter 0,1 %).
<G-vec00206-001-s246><count.rechnen><en> All people in need may count on the company’s support, although children from the poorest families, the disabled and sick have the priority.
<G-vec00206-001-s246><count.rechnen><de> Mit der Unterstützung durch die Firma können alle Bedürftigen rechnen, bevorzugt sind jedoch Kinder aus ärmsten Familien, Behinderte und Kranke.
<G-vec00206-001-s247><count.rechnen><en> Lessons schedule is only published on Thursdays on our Facebook page to make sure that we can count with adequate sea and weather conditions.
<G-vec00206-001-s247><count.rechnen><de> Der Unterrichtsplan wird nur Donnerstags auf unserer Facebook-Seite veröffentlicht, um gewährleisten zu können, dass wir mit angemessenen Meeres- und Wetterbedingungen rechnen können.
<G-vec00206-001-s248><count.rechnen><en> To increase the granulocyte count in patients with aplastic anemia.
<G-vec00206-001-s248><count.rechnen><de> Um rpaHyлoциT zu vergrößern rechnen bei den Patientinnen mit aплacTичeckoй von der Anämie.
<G-vec00206-001-s249><count.rechnen><en> And they can also count on the love of the Father.
<G-vec00206-001-s249><count.rechnen><de> Sie können auch mit dieser Liebe des Vaters rechnen.
<G-vec00206-001-s250><count.rechnen><en> "Germans carry a particular responsibility, as the historian Constantin Goschler argues: ""The German comeback after World War II had much to do with the generosity of their former adversaries, who could in turn count on profiting from West Germany's economic strength."
<G-vec00206-001-s250><count.rechnen><de> "Den Deutschen obliegt also eine besondere Verantwortung, wie der Historiker Constantin Goschler ausführt: ""Der deutsche Wiederaufstieg nach dem Zweiten Weltkrieg hatte viel mit der Großzügigkeit der ehemaligen Gegner zu tun, die im Gegenzug damit rechnen konnten, von der ökonomischen Stärke der Bundesrepublik zu profitieren."
<G-vec00206-001-s251><count.rechnen><en> Because the big parliament negotiates about it at present, at first we count in 2006 on the final law.
<G-vec00206-001-s251><count.rechnen><de> Da das große Parlament darüber zurzeit verhandelt, rechnen wir anfangs 2006 mit dem endgültigen Gesetz.
<G-vec00206-001-s252><count.rechnen><en> We can count on the politically conscious workers alone; the remaining mass, the bourgeoisie and the petty proprietors, are against us; they do not believe in the new order and take advantage of every opportunity to worsen the plight of the people.
<G-vec00206-001-s252><count.rechnen><de> Wir können nur auf die klassenbewußten Arbeiter rechnen; die übrige Masse, die Bourgeoisie und die Kleineigentümer, sind gegen uns, sie glauben nicht an die neue Ordnung, sie greifen jede Gelegenheit auf, um die Not des Volkes zu verschärfen.
<G-vec00206-001-s253><count.rechnen><en> I was never disappointed, in problematic situations I can always count on quick and effective response.
<G-vec00206-001-s253><count.rechnen><de> Ich war nie enttäuscht, in den Problemsituationen konnte ich auf schnelle und erfolgreiche Reaktion rechnen.
<G-vec00206-001-s254><count.rechnen><en> Please count on our prayers as we count on yours,
<G-vec00206-001-s254><count.rechnen><de> Sie können mit unserem Gebet rechnen, ebenso wie wir mit Ihnen rechnen.
<G-vec00206-001-s256><count.rechnen><en> It is necessary to consider that children often play on a floor, hence, proceeding from it, and it is necessary to count light exposure of a room.
<G-vec00206-001-s256><count.rechnen><de> Man muss berücksichtigen, dass die Kinder auf dem Fußboden, also ausgehend davon häufig spielen, und man muss die Beleuchtungsstärke des Zimmers rechnen.
<G-vec00206-001-s257><count.rechnen><en> Besides, unlike poor countries, they can already count on the introduction of automatic information exchange.
<G-vec00206-001-s257><count.rechnen><de> Im Gegensatz zu den ärmeren Ländern dürfen sie außerdem bereits mit dem automatischen Informationsaustausch rechnen.
<G-vec00206-001-s258><count.rechnen><en> You can count on the best materials, combined with the accuracy one would expect of a clock.
<G-vec00206-001-s258><count.rechnen><de> Sie können mit den besten Materialien rechnen, die mit der Genauigkeit kombiniert wird, die Sie von einer Wanduhr erwarten dürfen.
<G-vec00206-001-s259><count.rechnen><en> Something similar applies to montage, in other words the sudden moments of aleatoric but evident connection, which are always past as soon as they are seen … – Because we not only start from a non-continuum between viewers and “reality, but also from a non-continuum between our respective elements of temporality as authors/speakers/filmmakers and try to count on something like a “media agency, which allows that which exists to happen between things, persons and signs.
<G-vec00206-001-s259><count.rechnen><de> Ähnliches gilt für die Montage, also die plötzlichen Momente von aleatorischer, aber evidenter Verbindung, die immer schon vorbei sein werden, wenn sie gesehen sind … – Denn wir gehen nicht nur von einem Nicht-Kontinuum zwischen Zuschauer_innen und Wirklichkeit“ aus, sondern ebenso von einem Nicht-Kontinuum zwischen unseren jeweiligen Elementen der Zeitlichkeit als Autor_innen/Sprecher_innen/Filmemacher_innen und versuchen, mit so etwas wie einer medialen Agency“ zu rechnen, die das, was ist, zwischen Dingen, Personen und Zeichen passieren ließe.
<G-vec00206-001-s260><count.rechnen><en> In order to place the proletariat in the best position during the ensuing battles, the leadership took the stance that although the greatest efforts should be made to use the traditional apparatus of the Red organisations, it was also necessary to warn the proletariat not to count on anything from the maximalists and reformists, who would even go so far as accepting a peace treaty with fascism.
<G-vec00206-001-s260><count.rechnen><de> Um für die weiteren Kämpfe der Arbeiterklasse die bestmöglichen Voraussetzungen zu schaffen, gab die Zentrale die Weisung, unbedingt den traditionellen Gewerkschaftsapparat zu nutzen, zugleich aber auch dem Proletariat vor Augen zu führen, nicht mit Maximalisten und Reformisten rechnen zu können, unter deren Führung die Gewerkschaften standen und die so weit gingen, einen Friedenspakt mit den Faschisten zu unterzeichnen.
<G-vec00206-001-s261><count.rechnen><en> It seems so unreal to them that they would much rather portray you as fantasists than to take your words to heart and to count on their likelihood.
<G-vec00206-001-s261><count.rechnen><de> Es erscheint ihnen so unwirklich, daß sie weit eher euch als Phantasten bezeichnen, als eure Worte sich zu Herzen zu nehmen und mit der Wahrscheinlichkeit zu rechnen.
<G-vec00206-001-s262><count.rechnen><en> According to the law, every citizen, except lifelong payments of pension funds, can count on lump sum payments to pensioners.
<G-vec00206-001-s262><count.rechnen><de> Nach dem Gesetz kann jeder Bürger mit Ausnahme der lebenslangen Zahlungen der Pensionskassen mit Pauschalzahlungen an die Rentner rechnen.
<G-vec00206-001-s263><count.rechnen><en> Fortunately, the Good News is not dependent on things like a trailer and we can continue to count on God's intervention.
<G-vec00206-001-s263><count.rechnen><de> Gott sei Dank ist die Gute Nachricht nicht abhängig von einem Anhänger und wir können weiterhin mit Gottes Wirken rechnen.
<G-vec00206-001-s264><count.rechnen><en> If you are knitting a sweater, you can count two ways.
<G-vec00206-001-s264><count.rechnen><de> Wenn du einen Pullover strickst, kannst du auf zwei Wegen rechnen.
<G-vec00206-001-s398><count.zählen><en> "In an old house in the ""Chaldäergasser"" the ghost of a miser, chained to his treasure-chests, is cursed to count coins every night."
<G-vec00206-001-s398><count.zählen><de> "In einem alten Haus in der ""Chaldäergasser"" ist der Geist eines Geizhalses, an seine Schatzkiste gekettet, dazu verflucht, jede Nacht Münzen zu zählen."
<G-vec00206-001-s399><count.zählen><en> I do not advise you to count the signs of darkness, they lead only to obscurity.
<G-vec00206-001-s399><count.zählen><de> Ich rate Euch nicht, die Zeichen der Dunkelheit zu zählen, sie führen nur zu Verfinsterung.
<G-vec00206-001-s400><count.zählen><en> However, they count double for any of the princesses or animals – and generate winnings of 300 for three symbols, 1,000 for four and 10,000 for five.
<G-vec00206-001-s400><count.zählen><de> Allerdings zählen sie doppelt für die Prinzessinnen oder die Tiere und sorgen für Gewinne von 300 bei drei, 1000 bei vier und 10.000 bei fünf Symbolen.
<G-vec00206-001-s401><count.zählen><en> For those individuals who read this and are already greatly indebted to the material proclivities, this may be a difficult choice and one that is almost impossible; therefore, during those hours that a parent is available with the child, parents are urged to make every moment count by maintaining a conscious presence with the child.
<G-vec00206-001-s401><count.zählen><de> Für jene Menschen, die sich bereits tief in dieser materiellen Vorliebe verschuldet haben und die dies hier lesen, mag das eine schwierige Entscheidung sein, eine, die beinahe unmöglich erscheint; deshalb sind Eltern während dieser Stunden in denen sie dem Kind zur Verfügung stehen angehalten jeden Moment zählen zu lassen, indem sie eine bewußte Präsenz mit dem Kind beibehalten.
<G-vec00206-001-s402><count.zählen><en> And Health Mate can count anybody's steps for free, as long as they have the app on their smartphone.
<G-vec00206-001-s402><count.zählen><de> Und Health Mate kann die Schritte von allen Teilnehmern kostenlos zählen, solange die App auf deren Smartphone installiert ist.
<G-vec00206-001-s403><count.zählen><en> It is thanks to them that we can count, make calculations and solve certain problems.
<G-vec00206-001-s403><count.zählen><de> Ihnen ist es zu verdanken, dass wir zählen, rechnen und bestimmte Probleme lösen können.
<G-vec00206-001-s404><count.zählen><en> And so on, until you count to one hundred, without losing concentration.
<G-vec00206-001-s404><count.zählen><de> Und so weiter, bis Sie hundert zählen, ohne die Konzentration zu verlieren.
<G-vec00206-001-s405><count.zählen><en> In times in which communication and global thinking are increasingly important, and in times in which innovation and change count to the usual daily business of successful, competitive organisations, we are glad to be in the position to make our offer available not only in german and english, but from now on as well in spanish language.
<G-vec00206-001-s405><count.zählen><de> In Zeiten in denen Kommunikation und globales Denken zunehmend an Wichtigkeit gewinnen, und Innovation und Wandel zum täglichen Geschäft erfolgreicher Unternehmen zählen, freuen wir uns Ihnen unser Angebot ab sofort auch in spanischer Sprache zur Verfügung stellen zu können.
<G-vec00206-001-s406><count.zählen><en> The points collected in all the races count towards the 2017 Louis Vuitton Challenger Series — where all six teams, including defender Oracle Team USA, will each race each other to select who challenges for the Louis Vuitton America’s Cup.
<G-vec00206-001-s406><count.zählen><de> Die gesammelten Punkte zählen für die Louis Vuitton Challenger Series 2017, wenn alle sechs Teams inklusive dem Titelverteidiger des America’s Cup, Team Oracle USA, zwei Mal gegeneinander fahren, um den Herausforderer für den Louis Vuitton America’s Cup zu ermitteln.
<G-vec00206-001-s407><count.zählen><en> as char(24) character set utf8)) from rdb$database -- returns 208: all 24 CHAR positions count, and two of them are 16-bit
<G-vec00206-001-s407><count.zählen><de> as char(24) character set utf8)) from rdb$database -- ergibt 208: alle 24 CHAR -Positionen zählen ud zwei von ihnen haben 16 Bit.
<G-vec00206-001-s408><count.zählen><en> We forcefully reject, however, the logic under which only patriotic Kurds count.
<G-vec00206-001-s408><count.zählen><de> Aber wir lehnen die zugrunde gelegte Logik, wonach nur patriotische Kurden zählen, entschieden ab.
<G-vec00206-001-s409><count.zählen><en> During their vacation in Livorno, tourists can count on many demonstrations and musical performances at Livorno .
<G-vec00206-001-s409><count.zählen><de> In ihrem Urlaub in Livorno, Touristen können auf vielen zählen Demonstrationen und Musikaufführungen bei Livorno .
<G-vec00206-001-s410><count.zählen><en> Count on us to help you install, configure, and use PosterJet – even before you buy.
<G-vec00206-001-s410><count.zählen><de> Egal, ob Installation, Konfiguration oder Benutzung von PosterJet, zählen Sie auf unsere Unterstützung – und das auch schon vor dem Kauf.
<G-vec00206-001-s411><count.zählen><en> The arrival and departure days count as one day.
<G-vec00206-001-s411><count.zählen><de> An- und Abreisetag zählen als ein Tag.
<G-vec00206-001-s412><count.zählen><en> In any case, Sauces of the brand “Tabasco” are not said to count as one of the specialities of the restaurant.
<G-vec00206-001-s412><count.zählen><de> Das Angebot von Soßen der Marke „Tabasco“ soll jedenfalls nicht zu den speziellen Vorzügen des Restaurants zählen.
<G-vec00206-001-s413><count.zählen><en> Whether your event is small (the Bar 21 can be set up to receive between 15 and 40 delegates) or large (in total, all the spaces available can accommodate up to 380 delegates), you can count on a beautiful setting and personal and professional service to ensure everything goes smoothly.
<G-vec00206-001-s413><count.zählen><de> Unabhängig davon, ob Sie einen kleinen (in der Bar 21 finden zwischen 15 und 40 Teilnehmer Platz) oder großen Anlass (insgesamt finden bis zu 380 Teilnehmer Platz) planen, Sie können auf die herrliche Lage und das Personal mit dem professionellen Service zählen, das dafür sorgt, dass Ihr Anlass reibungslos abläuft.
<G-vec00206-001-s414><count.zählen><en> Create Conditional Formula is a wizard in Optipe Data Tools Suite that lets you create in the currently selected cell a formula to find, count or add data conditionally, for one or multiple criteria, similar to Merge Tables application.
<G-vec00206-001-s414><count.zählen><de> Erstellen Bedingte Formel wird ein Assistent in Optipe Data Tools Suite, die, schafft in der aktuell ausgewählten Zelle, eine Formel bedingte: zu finden, zählen oder Summendaten; für ein oder mehrere Kriterien, ähnlich wie die Verknüpfen von Tabellen Anwendung.
<G-vec00206-001-s415><count.zählen><en> Go through the lists and cross out any attributes and values that you share with your competitors, because they don't count.
<G-vec00206-001-s415><count.zählen><de> Die Listen und das Kreuz heraus laufen alle mögliche Attribute und Werte durch, die Sie mit Ihren Konkurrenten teilen, weil sie nicht zählen.
<G-vec00206-001-s416><count.zählen><en> At some point, we could not count the number of times we had mutually assured each other during the six days in the House Lentischio that we could not find any better accommodation.
<G-vec00206-001-s416><count.zählen><de> Irgendwann konnten wir nicht mehr zählen, wie oft wir uns in den sechs Tagen im Haus Lentischio gegenseitig versichert haben, dass wir keine bessere Unterkunft hätten finden können.
<G-vec00206-001-s433><count.zählen><en> First impressions count – and that's what swayed MOST Mobile in favor of pladur® Relief Wood.
<G-vec00206-001-s433><count.zählen><de> Der erste Eindruck zählt – und daher entschied sich das Unternehmen MOST Mobile für die Coil-Coating-Oberfläche pladur® Relief Wood.
<G-vec00206-001-s434><count.zählen><en> The remaining Talon triple will later count to the opponent’s tricks.
<G-vec00206-001-s434><count.zählen><de> Das zweites Talon Triple zählt am Ende zum Team der Gegner.
<G-vec00206-001-s435><count.zählen><en> Take a walk, count to ten or fifteen, or divert your mind to something pleasant.
<G-vec00206-001-s435><count.zählen><de> Macht einen kleinen Spaziergang, zählt bis zehn oder fünfzehn und lenkt euch durch irgendetwas Schönes ab.
<G-vec00206-001-s436><count.zählen><en> Step 10: Rooting will begin with a progress percentage count like in screenshot below.
<G-vec00206-001-s436><count.zählen><de> Schritt 10: Rooting wird mit einem Fortschrittsprozent beginnen zählt wie in Abbildung unten.
<G-vec00206-001-s437><count.zählen><en> What she asks, doesn’t count.
<G-vec00206-001-s437><count.zählen><de> Was sie sagt, zählt nicht.
<G-vec00206-001-s438><count.zählen><en> Make every shot count and see your controller brought to life in-game as a virtual weapon, bringing deadly precision to compatible PS VR shooter games.
<G-vec00206-001-s438><count.zählen><de> Jeder Schuss zählt: Dieser Controller erwacht in deinen Spielen als virtuelle Waffe zum Leben und ermöglicht dir bei kompatiblen PS VR-Shootern tödliche Präzision.
<G-vec00206-001-s439><count.zählen><en> Under the phase contrast, the live cells will appear bright and golden and should be counted; do not count any of the dull, dead, blue cells.
<G-vec00206-001-s439><count.zählen><de> Unter Phasenkontrast erscheinen lebende Zellen hell und golden und sollten gezählt werden; Zellen die trüb, tot und blau sind zählt man nicht.
<G-vec00206-001-s440><count.zählen><en> Count the dishes out too.
<G-vec00206-001-s440><count.zählen><de> Zählt auch nicht auf die Teller.
<G-vec00206-001-s441><count.zählen><en> He takes pinhole images, alienates them, repeats them, builds collages, emphasizes text fragments, also repeats these, SICK OF GOODBYS, turns Skylines upside down, interlaces everything with gatefolds, starts giving the count with 1 and 2, lands on the 9, then REVOLUTION, then 9, then ciphers, then 9...
<G-vec00206-001-s441><count.zählen><de> Er nimmt Lochkamerabilder, verfremdet sie, wiederholt sie, baut Collagen, hebt Textfragmente hervor, wiederholt auch diese, SICK OF GOODBYS, stellt Skylines auf den Kopf, verschachtelt alles mit Gatefolds, zählt an mit 1 und 2, landet auf der 9, dann REVOLUTION, dann 9, dann Chiffren, dann 9...
<G-vec00206-001-s442><count.zählen><en> First impressions count: The new Welcome Center in the entrance hall of the nora Weinheim, Germanytraining and information center displays an attractive and modern look.
<G-vec00206-001-s442><count.zählen><de> Der erste Eindruck zählt: Im attraktiven Look präsentiert sich das neue Welcome Center im Eingangsbereich des Schulungs- und Informationszentrums.
<G-vec00206-001-s443><count.zählen><en> WHO has recently published new tools that show the way forward for health care facilities and countries: The WHO application of ICD-10 to deaths during the perinatal period: ICD-PM; and Making every baby count: audit and review of stillbirths and neonatal deaths.
<G-vec00206-001-s443><count.zählen><de> Die WHO hat vor kurzem neue Instrumente veröffentlicht, die als Wegweiser für die Länder und ihre Gesundheitseinrichtungen gedacht sind: Die WHO-Anwendung des ICD-10 auf Todesfälle während der Perinatalperiode: ICD-PM und Jedes Baby zählt: Überprüfung der Zahl der Totgeburten und der Todesfälle bei Neugeborenen.
<G-vec00206-001-s444><count.zählen><en> "A rental with one or more Free Rental Days (""Free Rental Days"") will count as a Qualified Rental as long as there is a minimum of one paid rental day."
<G-vec00206-001-s444><count.zählen><de> "Eine Anmietung mit einem oder mehreren kostenfreien Miettagen (""kostenfreie Miettage"") zählt als qualifizierende Anmietung, solange sie zumindest einen bezahlten Miettag umfasst."
<G-vec00206-001-s445><count.zählen><en> First impressions count, and I loved what I was seeing in front of me as I slipped off the red sleeve and opened the box.
<G-vec00206-001-s445><count.zählen><de> Der erste Eindruck zählt, und ich liebte das, was ich vor mir sah, als ich den roten Ärmel abriss und die Schachtel öffnete.
<G-vec00206-001-s446><count.zählen><en> The Campagnolo Vintage Wall Clock will count down the minutes until your next ride or race.
<G-vec00206-001-s446><count.zählen><de> Die Campagnolo-Vintage-Wanduhr zählt die Minuten, die Sie von Ihrer nächsten Fahrradfahrt oder vom nächsten Radrennen trennen.
<G-vec00206-001-s447><count.zählen><en> Perhaps he gives up too fast; or perhaps he doesn't try to enforce his wishes, because anything you have to force someone to do doesn't count as love or understanding.
<G-vec00206-001-s447><count.zählen><de> Vielleicht gibt er zu früh auf oder vielleicht versucht er erst gar nicht, seine Wünsche durchzusetzen, weil alles, wozu er jemanden zwingen muss, für ihn nicht als Liebe oder Verständnis zählt.
<G-vec00206-001-s448><count.zählen><en> When winter starts turning to spring, Uimonen goes round the potential breeding den sites to count how many of them have been occupied – and how many new pups have been raised safely thanks to the volunteers' work.
<G-vec00206-001-s448><count.zählen><de> Wenn der Frühling den Winter verdrängt, sucht Uimonen die möglichen Bruthöhlen auf, und zählt, wie viele belegt sind und wie viele Jungtiere dank der Freiwilligen sicher aufgezogen wurden.
<G-vec00206-001-s449><count.zählen><en> Khuzestan is a center of the Iranian oil industry, vast new oilfields are being developed, and obviously, they count on technology made in Germany.
<G-vec00206-001-s449><count.zählen><de> In Khuzestan befinden sich die größten Ölförderanlangen des Iran, weitere Ölfelder warten auf Erschließung, und ganz offen zählt man dabei auf Technologie Made in Germany.
<G-vec00206-001-s450><count.zählen><en> """Neutral"" doesn't count as connection but is a interruption in the web."
<G-vec00206-001-s450><count.zählen><de> """Neutral"" zählt nicht als Verbindung, sondern ist eine Unterbrechung des Netzes."
<G-vec00206-001-s451><count.zählen><en> But that still doesn't count in the science system.
<G-vec00206-001-s451><count.zählen><de> Aber noch zählt das nicht im Wissenschaftssystem.
<G-vec00206-002-s069><count.bauen><en> Starting at £499 Count on powerful productivity packed in a sleek, versatile 14" design with best-in-class security and manageability.
<G-vec00206-002-s069><count.bauen><de> Bauen Sie auf Performance und Produktivität in einem schlanken, vielseitigen 35,6 cm (14'')-Design mit erstklassigen Sicherheits- und Verwaltungsfunktionen.
<G-vec00206-002-s070><count.bauen><en> Our promise of excellence means that we can count on the trust of the main players in the sector.
<G-vec00206-002-s070><count.bauen><de> Unser Versprechen für höchste Qualität bedeutet, dass wir auf das Vertrauen der wichtigsten Player in der Branche bauen.
<G-vec00206-002-s071><count.bauen><en> You can count on safety, reliability and quality when you buy from us.
<G-vec00206-002-s071><count.bauen><de> Bauen Sie auf Sicherheit, Zuverlässigkeit und Qualität.
<G-vec00206-002-s072><count.bauen><en> They count on you.
<G-vec00206-002-s072><count.bauen><de> Sie bauen auf dich.
<G-vec00206-002-s073><count.bauen><en> If it comes to reliable and correct estimation of value and potential of your investment asset - you should count on the competence of our experts!
<G-vec00206-002-s073><count.bauen><de> Wenn es um eine fundierte Marktpreiseinschätzung und das Wertpotenzial Ihrer Anlageimmobilie geht, sollten Sie auf die Kompetenz eines Experten bauen.
<G-vec00206-002-s074><count.bauen><en> The customers of the DOMUS Software AG no matter their size, can count on the expertise as specialist.
<G-vec00206-002-s074><count.bauen><de> Die Kunden der DOMUS Software AG, egal welcher Größenordnung, können auf die Kompetenz als Fachkraft bauen.
<G-vec00206-002-s075><count.bauen><en> As mayor, I'm especially proud of the fact that our city can count on a huge voluntary commitment.
<G-vec00206-002-s075><count.bauen><de> Ganz besonders stolz bin ich als Oberbürgermeister darauf, dass unsere Stadt auf ein großes ehrenamtliches Engagement bauen kann.
<G-vec00206-002-s076><count.bauen><en> And much of the time, we could not count on the support of others and had to go through it alone, using our own severely stretched resources and somewhat battered inner strength.
<G-vec00206-002-s076><count.bauen><de> Und oft genug konnten wir nicht auf die Unterstuetzung anderer bauen und mussten alleine da durch, mit unseren empfindlich eingeschraenkten Ressourcen und irgendwie arg mitgenommener innerer Staerke.
<G-vec00206-002-s077><count.bauen><en> Whatever their choice, they can count on easy integration and handling, thanks to the typical USB plug & play functionality.
<G-vec00206-002-s077><count.bauen><de> In jedem Fall kann er - dank des USB-typischen Plug & Plays - auf eine einfache Integration und Handhabung bauen.
<G-vec00206-002-s078><count.bauen><en> This approach has been proven successful for our own product range during the last 20 years and we can count on a continually growing and satisfied customer base.
<G-vec00206-002-s078><count.bauen><de> Diese Ausrichtung hat sich für unsere hauseigenen Produktenketten bewährt und so können wir auf einen stetig wachsenden und zufriedenen Kundenkreis bauen.
<G-vec00206-002-s079><count.bauen><en> Count on high performance from your private network with a fast standard port speed of 100 Mbit/s and the option to upgrade to as much as 1 Gigabit/s per port.
<G-vec00206-002-s079><count.bauen><de> Bauen Sie auf die hohe Leistung Ihres privaten Netzwerks und nutzen Sie eine Standard-Port-Hochgeschwindigkeit von 100 Mbit/s und die Option, auf 1 Gigabit/s pro Port upzugraden.
<G-vec00206-002-s080><count.bauen><en> This is a promise our clients can count on, just as they can always count on our adhering to deadlines.
<G-vec00206-002-s080><count.bauen><de> Auf dieses Versprechen können sich unsere Auftraggeber verlassen und dabei stets auf unsere Termintreue bauen.
<G-vec00206-002-s081><count.bauen><en> SMART is a bending machine you can count on to make your production.
<G-vec00206-002-s081><count.bauen><de> Die SMART ist eine Biegemaschine, auf die Sie Ihre Produktion bauen können.
<G-vec00206-002-s082><count.bauen><en> from Kendrion We count on competence in magnetism and offer customized system solutions coupled with innovation force and the latest manufacturing technologies, creating products with an excellent market position.
<G-vec00206-002-s082><count.bauen><de> Kundenspezifische Lösungen von Kendrion Wir bauen auf Kompetenz im Magnetismus und bieten maßgeschneiderte Systemlösungen gepaart mit Innovationskraft und neuesten Fertigungstechnologien.
<G-vec00206-002-s083><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Maniwaki QC and the mean stroke count for all stations
<G-vec00206-002-s083><count.blitzen><de> Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Prescott (Red) sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s084><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Palm Beach Gardens and the mean stroke count for all stations
<G-vec00206-002-s084><count.blitzen><de> Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Palm Beach Gardens sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s086><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Milford and the mean stroke count for all stations
<G-vec00206-002-s086><count.blitzen><de> Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station De Pere sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s087><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station and the mean stroke count for all stations
<G-vec00206-002-s087><count.blitzen><de> Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Harvest sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s089><count.blitzen><en> Stroke count Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Sendai and the mean stroke count for all stations
<G-vec00206-002-s089><count.blitzen><de> Umgebung der Station Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s090><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Tucson / Rita Ranch and the mean stroke count for all stations
<G-vec00206-002-s090><count.blitzen><de> Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Jarvenpaa Blue sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s091><count.blitzen><en> Surrounding area Stroke count Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Hinesburg and the mean stroke count for all stations
<G-vec00206-002-s091><count.blitzen><de> Umgebung der Station Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Gladwyne sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s092><count.blitzen><en> Stroke count Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Palmerston North.
<G-vec00206-002-s092><count.blitzen><de> Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Milford sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s093><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Milford and the mean stroke count for all stations
<G-vec00206-002-s093><count.blitzen><de> Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Milford sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s094><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Mundelein and the mean stroke count for all stations
<G-vec00206-002-s094><count.blitzen><de> Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Mundelein sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s096><count.blitzen><en> Last detected Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Kyotanabe and the mean stroke count for all stations
<G-vec00206-002-s096><count.blitzen><de> Umgebung der Station Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Kyotanabe sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s097><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Lerum and the mean stroke count for all stations
<G-vec00206-002-s097><count.blitzen><de> Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Lerum sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s099><count.blitzen><en> Stroke count Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Komoka, Ontario and the mean stroke count for all stations
<G-vec00206-002-s099><count.blitzen><de> Umgebung der Station Blitzanzahl Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Houston sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s101><count.blitzen><en> Here you can see the whole stroke count per hours detected by the lightning network, the count of detected strokes/h of the station Val-d'or QC and the mean stroke count for all stations
<G-vec00206-002-s101><count.blitzen><de> Zu sehen ist die Gesamtanzahl an Blitzen pro Stunde aus dem Ortungsnetzwerk, die Anzahl der detektierten Blitze der Station Val-d'or QC sowie zum Vergleich der Durchschnitt aller Stationen.
<G-vec00206-002-s159><count.gehören><en> The decision in favour of the Charité underlines their ambition to count among the most important health research centres.
<G-vec00206-002-s159><count.gehören><de> Die Entscheidung für die Charité unterstreiche deren Anspruch, zu den wichtigsten deutschen Zentren der Gesundheitsforschung zu gehören.
<G-vec00206-002-s160><count.gehören><en> For a whole host of large industrial enterprises, which count among the largest polluters in Germany, emissions trading serves as a lucrative source of income instead of obliging them to protect our climate.
<G-vec00206-002-s160><count.gehören><de> Einer ganzen Reihe von Industriekonzernen, die zu den größten Umweltverschmutzern Deutschlands gehören, dient der Emissionshandel als lukrative Einnahmequelle, anstatt die Unternehmen zu mehr Klimaschutz zu verpflichten.
<G-vec00206-002-s161><count.gehören><en> Amongst the facilities count a foyer with 24-hour reception, 4 lifts, a...
<G-vec00206-002-s161><count.gehören><de> Zur Ausstattung gehören eine Empfangshalle mit 24 h Rezeption, 4 Aufzüge sowie eine...
<G-vec00206-002-s162><count.gehören><en> The Slovak beers count among Europe’s best beers.
<G-vec00206-002-s162><count.gehören><de> Die slowakischen Biere gehören zu den Besten auf dem Kontinent.
<G-vec00206-002-s163><count.gehören><en> The annual JUVE Awards count among the most coveted prizes for legal services in Germany.
<G-vec00206-002-s163><count.gehören><de> Die alljährlich verliehenen JUVE-Awards gehören zu den renommiertesten Preisen im nationalen Rechtsmarkt.
<G-vec00206-002-s164><count.gehören><en> Drawings and prints, therefore, count amongst the most important media of artistic and transcultural exchange.
<G-vec00206-002-s164><count.gehören><de> Zeichnungen und Druckgraphiken gehören daher zu den wichtigsten Medien des künstlerischen und transkulturellen Austauschs.
<G-vec00206-002-s165><count.gehören><en> Besides alpine roses I count sunflowers among my favourite flowers.
<G-vec00206-002-s165><count.gehören><de> Sonnenblumen gehören neben den Alpenrosen sowieso zu meinen Lieblingsblumen.
<G-vec00206-002-s166><count.gehören><en> Amongst the facilities count an entrance hall with 24-hour reception, a hotel safe and a bar.
<G-vec00206-002-s166><count.gehören><de> Zur Ausstattung gehören eine Empfangshalle mit 24 h Rezeption, Hotelsafe, Wechselstube, Aufzug und Restaurant.
<G-vec00206-002-s167><count.gehören><en> Amongst the hotel's modern facilities count a foyer with 24-hour reception and safe, a TV room, lifts and a car park.
<G-vec00206-002-s167><count.gehören><de> Zur Hotelausstattung gehören eine Empfangshalle mit Rezeption (24 Stunden besetzt), Hotelsafe, TV-Raum, sowie Aufzüge und Parkplätze.
<G-vec00206-002-s168><count.gehören><en> And we count major brand names BMW, Mazda, Mercedes-Benz, Audi, Nissan, Honda and Volkswagen among our satisfied customers.
<G-vec00206-002-s168><count.gehören><de> Zu unseren zufriedenen Kunden gehören wichtige Markennamen wie BMW, Mazda, Mercedes-Benz, Audi, Nissan, Honda und Volkswagen.
<G-vec00206-002-s169><count.gehören><en> Amongst the facilities count a foyer with a 24-hour reception desk, a safe, a lift, a TV room, a video games room, conference facilities and Internet access.
<G-vec00206-002-s169><count.gehören><de> Zur Einrichtung gehören Empfangshalle, 24 h Rezeption, Hotelsafe, Aufzug, TV-Raum, Videospielzimmer, Konferenzmöglichkeiten und Internetanschluss.
<G-vec00206-002-s170><count.gehören><en> Yet Schwerin, Neubrandenburg, Greifswald and Stralsund also count among the established addresses in MV's schedule of trade fairs.
<G-vec00206-002-s170><count.gehören><de> Aber auch Schwerin, Neubrandenburg, Greifswald und Stralsund gehören zu den festen Adressen im Messeplan des Landes.
<G-vec00206-002-s171><count.gehören><en> Birth certificates count among the most frequently required civil-status documents.
<G-vec00206-002-s171><count.gehören><de> Geburtsurkunden gehören zu den am häufigsten gebrauchten Personenstandsurkunden.
<G-vec00206-002-s172><count.gehören><en> Amongst the hotel's facilities count a foyer with 24-hour reception, a safe, a lift and a currency exchange counter.
<G-vec00206-002-s172><count.gehören><de> Zur Ausstattung gehören eine Empfangshalle mit 24 h Rezeption, Hotelsafe, Wechselstube und Aufzug.
<G-vec00206-002-s173><count.gehören><en> Lovely prepared plain fare and social gathering count to the way of living as well as being in accord with the nature.
<G-vec00206-002-s173><count.gehören><de> Liebevoll zubereitete Kärnter Gaumenfreuden und geselliges Beisammensein gehören hier ebenso zur Lebensart wie das Leben im Einklang mit der Natur.
<G-vec00206-002-s174><count.gehören><en> Amongst the hotel's modern facilities count a foyer with 24-hour reception, lifts and...
<G-vec00206-002-s174><count.gehören><de> Zur modernen Hotelausstattung gehören eine Empfangshalle mit 24 h Rezeption, Hotel-Safe,...
<G-vec00206-002-s175><count.gehören><en> Trade associations and institutions as well as owners and brand managers of many well-known companies count among the exclusive network of the foundation’s members.
<G-vec00206-002-s175><count.gehören><de> Zum exklusiven Netzwerk der Stiftungsmitglieder gehören neben Wirtschaftsverbänden und Institutionen die Inhaber und Markenlenker vieler namhafter Unternehmen.
<G-vec00206-002-s176><count.gehören><en> They make advertising for Adidas or design coffee cups, which count amongst the most wanted accessories of stars like Kanye West, Jay-Z, or Lady Gaga.
<G-vec00206-002-s176><count.gehören><de> Sie machen Werbung für Adidas oder designen Kaffeetassen und gehören zu den most wanted accessories von Stars wie Kanye West, Jay-Z oder Lady Gaga.
<G-vec00206-002-s177><count.gehören><en> Francesco Clemente's (*1952) works count among the most visually powerful and erotically charged works of the Transavanguardia.
<G-vec00206-002-s177><count.gehören><de> Francesco Clementes (*1952) Arbeiten gehören zu den visuell stärksten und erotisch aufgeladensten Werken der Transavanguardia.
<G-vec00206-002-s178><count.gelten><en> Today they justifiably count as treasured rarities.
<G-vec00206-002-s178><count.gelten><de> Heute gelten sie zu recht als kostbare Rarität.
<G-vec00206-002-s179><count.gelten><en> The 5 days count as of the date when the order was placed.
<G-vec00206-002-s179><count.gelten><de> Die 5 Tagen gelten ab dem Eingang der Bestellung.
<G-vec00206-002-s180><count.gelten><en> But we won’t count that because Wilson had connections at Playboy.
<G-vec00206-002-s180><count.gelten><de> Aber das wollen wir nicht gelten lassen, weil ja Wilson zum Playboy Beziehungen hatte.
<G-vec00206-002-s181><count.gelten><en> They count from camp and do not contain the transportation costs and packing charges.
<G-vec00206-002-s181><count.gelten><de> Sie gelten ab Lager und beinhalten nicht die Transport- und Verpackungskosten.
<G-vec00206-002-s182><count.gelten><en> As their stay was involuntarily and their social position was less respected at that time, they did not count as the first settlers of Iceland.
<G-vec00206-002-s182><count.gelten><de> Aufgrund der Unfreiwilligkeit des Aufenthalts und ihrer zur jener Zeit gesellschaftlich weniger geachteten Position gelten diese jedoch nicht als die ersten Siedler Islands.
<G-vec00206-002-s183><count.gelten><en> Various types of testing count as use of the goods and in these cases the goods can therefore neither be returned nor cancelled.
<G-vec00206-002-s183><count.gelten><de> Diverse Arten von Tests gelten als Benutzung der Ware und solche Ware kann somit weder zurückgegeben noch widerrufen werden.
<G-vec00206-002-s184><count.gelten><en> In that way, written exams in Germany don’t count as that much dramatically important, at least not that important as one could obviously find out, when the final exams will take part.
<G-vec00206-002-s184><count.gelten><de> So gesehen gelten schriftliche Prüfungen in Deutschland nicht als so dermaßen besonders wichtig, zumindest kann man in Deutschland nicht so offensichtlich erkennen, wann die Semesterabschlussprüfungen stattfinden.
<G-vec00206-002-s185><count.gelten><en> However, if your stay covers several price bands, the cheapest nightly price will count as the free nights.
<G-vec00206-002-s185><count.gelten><de> Sofern Sie mehrere unterschiedliche Preis- Zeiträume abdecken, gelten die preiswertesten Nächte als kostenlose Nächte.
<G-vec00206-002-s186><count.gelten><en> The works that we do because we owe them are necessary in life, but they’re not the works that count before God.
<G-vec00206-002-s186><count.gelten><de> Die Werke, die wir aus Schuld tun – die sind zwar im Leben notwendig, aber sie sind nicht die Werke, die vor Gott gelten.
<G-vec00206-002-s187><count.gelten><en> (1) The following General Terms and Conditions count for every delivery between us and a consumer from the time of the order valid version.
<G-vec00206-002-s187><count.gelten><de> (1) Die nachfolgenden Allgemeinen Geschäftsbedingungen gelten für alle Lieferungen zwischen uns und einem Verbraucher in ihrer zum Zeitpunkt der Bestellung gültigen Fassung.
<G-vec00206-002-s188><count.gelten><en> As far as the country of destination admits other protection rights instead of the retention of title, these count as explicit agreed.
<G-vec00206-002-s188><count.gelten><de> Soweit das Bestimmungsland anstelle des Eigentumsvorbehaltes andere Sicherungsrechte zuläßt, gelten diese als ausdrücklich vereinbart.
<G-vec00206-002-s189><count.gelten><en> Residence means the place in which a person resides with the intention of staying there permanently (there may also be several such places, so all these courts may count as the general court).
<G-vec00206-002-s189><count.gelten><de> Wohnsitz ist der Ort, an dem sich eine Person mit der Absicht aufhält, dauerhaft dort zu bleiben (es kann auch mehrere solcher Orte geben, so dass alle diese Gerichte als allgemeines Gericht gelten können).
<G-vec00206-002-s190><count.gelten><en> Not only do we serve our guests exquisite global cuisine, we also count in-the-know locals amongst our regulars, especially at the award winning Beach Restaurant and The Restaurant, simple names that belie sophisticated dining experiences.
<G-vec00206-002-s190><count.gelten><de> Wir servieren unseren Gästen nicht nur exquisite internationale Küche, wir gelten auch als Geheimtipp unter unseren einheimischen Stammgästen, besonders im preisgekrönten Strandrestaurant und im Restaurant, unspektakuläre Namen, die jedoch mit anspruchsvollen kulinarischen Erlebnissen überraschen.
<G-vec00206-002-s191><count.gelten><en> In case of an illness during your holidays, those days count as sick leave and are not holidays.
<G-vec00206-002-s191><count.gelten><de> Sollten Sie während Ihres Urlaubes erkranken, dann gelten Tage an denen Sie krank sind als Krankenstandstage und nicht als Urlaubstage.
<G-vec00206-002-s192><count.gelten><en> In the event of forfeited points, these will count for final settlement. If the nominated point is awarded as a penalty point, all bets on that point will be void.
<G-vec00206-002-s192><count.gelten><de> Bei Abbrüchen, Verspätungen oder Unterbrechungen gelten folgende Bestimmungen: Falls zumindest eines der involvierten Spiele mit mehr als einer Stunde Verspätung beginnt, sind alle Wetten ungültig.
<G-vec00206-002-s193><count.gelten><en> The ghosts released count as magic projectiles and can be blocked\reflected\absorbed by skills like Reflect Kick, Phoenix Talon, and Statue of Glory.
<G-vec00206-002-s193><count.gelten><de> Die Geister gelten als ein magisches Projektil, das blockiert/reflektiert/absorbiert werden kann, von Skills wie Reflektierender Kick, Phönixklaue und Heldenhafter Wächter.
<G-vec00206-002-s194><count.gelten><en> The volumetric data, which count as the limitation factors for the survival time concerning the patients, were in the fore.
<G-vec00206-002-s194><count.gelten><de> Im Vordergrund standen die volumetrischen Daten der Lebermetastasen, die als limitierende Faktoren der Überlebenszeit der betroffenen Patienten gelten.
<G-vec00206-002-s195><count.gelten><en> The conditions determined by the Schengen agreement, the walls on the US and Mexican border or racist and foreigner-hostile campaigns such as the foreigner and asylum law in Switzerland are the rules that count for immigrants.
<G-vec00206-002-s195><count.gelten><de> Für MigrantInnen gelten die Regeln von Schengener Sicherheitsabkommen, US-amerikanischen Grenzmauern zu Mexico oder die Logik von rassistischen und ausländerfeindlichen Kampagnen wie zum Beispiel zum Ausländer- und Asylgesetz in der Schweiz.
<G-vec00206-002-s196><count.gelten><en> The München Card is available for adults or children and for groups of up to 5 persons, whereby any two children between 6 and 14 years count as one adult.
<G-vec00206-002-s196><count.gelten><de> Erhältlich ist die München Card als Single- oder Kinderkarte und als Gruppenkarte für eine Gruppe von 2 Personen bis zu 5 Personen – wobei zwei Kinder zwischen 6 und 14 Jahren als eine Person gelten.
<G-vec00206-002-s235><count.grafen><en> The opera is set in the palace and gardens of Count Almaviva in Seville, Spain.
<G-vec00206-002-s235><count.grafen><de> Die Oper spielt in der Entstehungszeit um 1780 am Schloss des Grafen Almaviva in Aguasfrescas in der Nähe von Sevilla.
<G-vec00206-002-s236><count.grafen><en> Margot Balbeck has waited for this moment 35 years - she wants to even the score with the Count.
<G-vec00206-002-s236><count.grafen><de> Margot Balbeck hat auf diesen Augenblick seit 35 Jahren gewartet, denn sie hat mit dem Grafen eine alte Rechnung zu begleichen.
<G-vec00206-002-s237><count.grafen><en> In 1132, Montepeloso adhered to the conspiracy of the barons against King Ruggiero II, and was occupied by the rebel Count Tancredi of Conversano.
<G-vec00206-002-s237><count.grafen><de> 1132 stimmte der Ort der Verschwörung der Baronen gegen Roger II zu und wurde von dem rebellischen Grafen Tancredi von Conversano besetzt.
<G-vec00206-002-s238><count.grafen><en> Like those of Duke, Marquis or Count, the titles of Viscount or Vidame originate in a land jurisdiction.
<G-vec00206-002-s238><count.grafen><de> Wie die eines Herzogs, eines Marquis oder eines Grafen, haben die Titel eines Vicomte oder eines Domverwesers ursprünglich eine Grundgerichtsbarkeit.
<G-vec00206-002-s239><count.grafen><en> Despite all kinds of tricks, however, the Count did not manage to dampen the people's devotion one iota.
<G-vec00206-002-s239><count.grafen><de> Aber trotz seiner List gelang es dem Grafen nicht, die Devotion des Volkes auszumerzen.
<G-vec00206-002-s240><count.grafen><en> Crafting: the Count’s influence.
<G-vec00206-002-s240><count.grafen><de> Neuigkeiten » Crafting: der Einfluss des Grafen.
<G-vec00206-002-s241><count.grafen><en> Known as the Toledo of Quercy, this mediaeval fortified town, founded in 1241 by the Count of Toulouse, contains a superb rectangular square surrounded by old stone and timber-framed houses.
<G-vec00206-002-s241><count.grafen><de> Diese mittelalterliche Bastide mit dem Spitznamen "Tolede von Quercy" wurde 1241 durch den Grafen von Toulouse gegründet und birgt in ihrem Kern einen wunderschönen Winkelplatz mit Laubengängen, umgeben von alten Häusern aus Stein und Fachwerk.
<G-vec00206-002-s242><count.grafen><en> In 1707, an order by Count Ernst of Stolberg forbade Brocken guides to take strangers or local folk to the Brocken without special permission, and the lighting of fires was forbidden.
<G-vec00206-002-s242><count.grafen><de> 1707 verbot eine Verordnung des Grafen Ernst zu Stolberg den Brockenführern, Fremde oder Einheimische ohne besondere Erlaubnis auf den Brocken zu führen; das Feuermachen wurde untersagt.
<G-vec00206-002-s243><count.grafen><en> But Annette and her lover Lubin succeed, through a combination of spirited defence and a plea for mercy, in gaining the protection of the local lord or count (Le Seigneur).
<G-vec00206-002-s243><count.grafen><de> Annette und ihrem Geliebten Lubin gelingt es aber mit einer Kombination aus Sich-zur-Wehr-Setzen und Um-Mitleid-Bitten, die Gunst des örtlichen Gutsherrn oder Grafen (Le Seigneur) zu gewinnen.
<G-vec00206-002-s244><count.grafen><en> As US ambassador to Paris, he met Count de Mirabeau - Weishaupt ´s French Contact, who made French Masonic lodges revolutionary hotbeds and became Grand Master of a Parisian Masonic lodge - a is believed to have been initiated as a member of the Illuminati in Paris.
<G-vec00206-002-s244><count.grafen><de> Als US-Botschafter in Paris traf er den Grafen de Mirabeau - Weishaupt ’s französischen Kontakt, der die französischen Freimaurerlogen zu revolutionären Brutstätten gemacht hatte, und Franklin wurde Großmeister einer Pariser Freimaurerloge - es wird angenommen, dass er als Mitglied der Illuminaten in Paris eingeweiht wurde.
<G-vec00206-002-s245><count.grafen><en> "Your love is worth more than any dignity and honour... and I really don't see myself as a count.
<G-vec00206-002-s245><count.grafen><de> "Deine Liebe gilt für mich mehr als jegliches hohes Amt, jegliche Ehrenstellung... ich kann mich nicht als Grafen sehen.
<G-vec00206-002-s246><count.grafen><en> At this time, Buchard von Printsac was given in fief a watermill at "coppern" by Count Gerhard von Eppstein.
<G-vec00206-002-s246><count.grafen><de> Zu dieser Zeit wurde dem Burchard von Printsac eine Mühle zu coppern vom Grafen Gerhard von Eppstein zum Lehen gegeben.
<G-vec00206-002-s247><count.grafen><en> Soon afterwards, bandits looted the count’s home while he was in the city and set it alight.
<G-vec00206-002-s247><count.grafen><de> Bald darauf plünderten Banditen das Haus des Grafen, während er in der Stadt war, und zündeten es an.
<G-vec00206-002-s248><count.grafen><en> Johann David Welcker: Allegory on the acquisition of Surinam by Count Friedrich Casimir of Hanau in 1669.
<G-vec00206-002-s248><count.grafen><de> Johann David Welcker: Allegorie auf die Erwerbung von Surinam durch den Grafen Friedrich Kasimir von Hanau 1669.
<G-vec00206-002-s249><count.grafen><en> Follow in the footsteps of Count Berthold Aichelburg up to the forest lodge.
<G-vec00206-002-s249><count.grafen><de> Folgen Sie den Spuren des Grafen Berthold Aichelburg bis zur Waldhütte.
<G-vec00206-002-s250><count.grafen><en> Early creations[edit] The title was first created for Robert de Beaumont, but he nearly always used his French title of Count of Meulan.
<G-vec00206-002-s250><count.grafen><de> Geschichte[Bearbeiten | Quelltext bearbeiten] Der erste Titelträger war um 1107 Robert de Beaumont, der gleichzeitig noch den Titel eines französischen Grafen von Meulan trug.
<G-vec00206-002-s251><count.grafen><en> Portrait of Count Antonio Porcia, ca 1535-1540.
<G-vec00206-002-s251><count.grafen><de> Porträt des Grafen Antonio Porcia, ca 1535-1540.
<G-vec00206-002-s252><count.grafen><en> Under the count of Wertheim and later the Count of Erbach several modifications were made.
<G-vec00206-002-s252><count.grafen><de> Unter den Grafen von Wertheim und später den Grafen von Erbach wurden mehrere Umbauten vorgenommen.
<G-vec00206-002-s310><count.rechnen><en> However you can also count on a great result if you only receive liposculpture of the neck.
<G-vec00206-002-s310><count.rechnen><de> Aber auch wenn Sie nur eine Liposkulptur des Halses machen lassen, können Sie schon mit einem schönen Ergebnis rechnen.
<G-vec00206-002-s311><count.rechnen><en> Last but not least, the captain can also count on a creative marketing service that translates the identity of our company to visual and spoken language and who observes and manages the overall appearance of the Duma Sale-ship both short and long term.
<G-vec00206-002-s311><count.rechnen><de> Zum Schluss kann der Kapitän auf einen kreativen Marketingdienst rechnen, der die Identität unseres Unternehmens in Bilder und Texte umsetzt und der die Ausstrahlung des Duma Sale-Schiffes ständig überwacht und versorgt.
<G-vec00206-002-s312><count.rechnen><en> But we must not take this into account twice. We must not count it first as money required for the circulation of the variable capital, and a second time as money required for the circulation of the revenue of the laborers.
<G-vec00206-002-s312><count.rechnen><de> Aber wir dürfen dies nicht zweimal rechnen: einmal als Geld, nöthig zur Cirkulation des variablen Kapitals, und noch einmal als Geld, nöthig zur Cirkulation der Revenue der Arbeiter.
<G-vec00206-002-s313><count.rechnen><en> For each and every issue, you can count on us to find a creative and effective solution.
<G-vec00206-002-s313><count.rechnen><de> Für jedes Problem können Sie mit einer kreativen und sachdienlichen Lösung rechnen.
<G-vec00206-002-s314><count.rechnen><en> Mail ## english version Dear $Assembly, you took part with an assembly at the 33C3 and we hope to count on you again at the 34C3.
<G-vec00206-002-s314><count.rechnen><de> == [[34C3/Assembly:BSD]] als Teil der ''Cyber Competenz Assemblie, ihr habt auf dem 33C3 mit einem Assemblie teilgenommen und wir hoffen auch auf dem 34C3 mit Euch rechnen zu können.
<G-vec00206-002-s315><count.rechnen><en> Fendt has always guaranteed an unbeatable resale value – an investment that you can always count on, even in the future.
<G-vec00206-002-s315><count.rechnen><de> Fendt garantiert seit jeher einen unschlagbaren Wiederverkaufswert - eine Investition, mit der Sie auch in Zukunft rechnen können.
<G-vec00206-002-s316><count.rechnen><en> Patient with triglyceride over 130 mg/dl (1.47 mmol/l) indicates high apoB particles (LDL) count.
<G-vec00206-002-s316><count.rechnen><de> Ab einer Triglyzerid-Konzentration von etwa 1.000 mg/ dl (11,3 mmol/ l) ist mit einem Chylomikronämie-Syndrom zu rechnen.
<G-vec00206-002-s317><count.rechnen><en> 18% count on a clear rise of climatic refugees from particularly areas heavily concerned of the earth.
<G-vec00206-002-s317><count.rechnen><de> 18% rechnen mit einem deutlichen Anstieg von Klimaflüchtlingen aus besonders schwer betroffenen Gebieten der Erde.
<G-vec00206-002-s318><count.rechnen><en> Here, too, the institution must count on seeing a high workload.
<G-vec00206-002-s318><count.rechnen><de> Auch hier hat das Institut mit einem erhöhten Aufwand zu rechnen.
<G-vec00206-002-s319><count.rechnen><en> You can count on us for constructive input, helpful improvements and valuable ideas.
<G-vec00206-002-s319><count.rechnen><de> Mit konstruktivem Input, hilfreichen Verbesserungen und wertvollen Ideen dürfen Sie rechnen.
<G-vec00206-002-s320><count.rechnen><en> We must and can count on God.
<G-vec00206-002-s320><count.rechnen><de> Wir sollen und dürfen mit Gott rechnen.
<G-vec00206-002-s321><count.rechnen><en> It is the simplest manner to gamble with nothing to count, for sure no 10’s or 5’s or anything else to refer to.
<G-vec00206-002-s321><count.rechnen><de> Es ist die einfachste Art und Weise, mit nichts zu rechnen spielen, das ist sicher keine 10 oder 5 oder irgend etwas anderes zu verweisen.
<G-vec00206-002-s322><count.rechnen><en> Nor can we count on a tailwind from the markets.
<G-vec00206-002-s322><count.rechnen><de> Wir rechnen auch nicht mit Rückenwind aus den Märkten.
<G-vec00206-002-s323><count.rechnen><en> If when playing pontoon you card count correctly (even if the casino game uses multiple of cards), you’ll be able to tilt the possibilities to your favor.
<G-vec00206-002-s323><count.rechnen><de> Wenn Sie beim Abspielen von Ponton-Karte richtig rechnen (auch wenn das Casino-Spiel mehrere Karten verwendet), werden Sie in der Lage sein, die Möglichkeiten zu Ihren Gunsten zu kippen.
<G-vec00206-002-s324><count.rechnen><en> Including competent support through service and maintenance, which you can count on at all times.
<G-vec00206-002-s324><count.rechnen><de> Inklusive kompetenter Unterstützung durch Service und Wartung, mit der Sie jederzeit rechnen können.
<G-vec00206-002-s325><count.rechnen><en> The incredible emotional songs, that this metalcore machine accurately serves, can count on backing vocals of the whole crowd.
<G-vec00206-002-s325><count.rechnen><de> Die sehr emotionalen Songs die diese Metalcore Maschine so genau serviert können bei jeder Show rechnen auf Vokalische Unterstützung des Publikums.
<G-vec00206-002-s326><count.rechnen><en> In the following will be closer to the means 14 for loading count of the fingerprint according to a set Fin gerabdruckmodus received.
<G-vec00206-002-s326><count.rechnen><de> Im nachfolgenden wird näher auf die Einrichtung 14 zum Be rechnen des Fingerabdrucks gemäß einem eingestellten Fin gerabdruckmodus eingegangen.
<G-vec00206-002-s327><count.rechnen><en> Whether biogas, natural gas or special gas, regardless of container construction or individual project development: you can count on the maximum level of availability and efficiency of your system because we look very closely at your needs and provide individual consultation.
<G-vec00206-002-s327><count.rechnen><de> Gleich ob Biogas, Erdgas oder Sondergas, gleich ob Container-Bauweise oder individuelle Projektierung: Sie können mit der maximalen Verfügbarkeit und Effizienz Ihrer Anlage rechnen, denn wir schauen genau auf Ihre Bedürfnisse und beraten Sie individuell.
<G-vec00206-002-s328><count.rechnen><en> This means you can always count on clean and agreeable working conditions.
<G-vec00206-002-s328><count.rechnen><de> So können Sie immer auf saubere und angenehme Arbeitsbedingungen rechnen.
<G-vec00206-002-s329><count.setzen><en> For selection of raw material we exclusively count on material from Western European production.
<G-vec00206-002-s329><count.setzen><de> Bei der Auswahl des Rohmaterials setzen wir ausschließlich auf Material aus westeuropäischer Fertigung.
<G-vec00206-002-s330><count.setzen><en> Although this PeaceLab blog is now closed, we of course count on continued exchange with you on thoughts and ideas regarding this important topic.
<G-vec00206-002-s330><count.setzen><de> Auch wenn dieser PeaceLab-Blog nun geschlossen wird, setzen wir selbstverständlich auch weiterhin auf den Austausch mit Ihnen zu diesem wichtigen Thema.
<G-vec00206-002-s331><count.setzen><en> Numerous market research institutes and industrial market researchers count on the mobile offline survey app mQuest®.
<G-vec00206-002-s331><count.setzen><de> Zahlreiche Marktforschungsinstitute und betriebliche Marktforscher setzen bei Car Clinics seit vielen Jahren auf die mobile Offline-Befragungs- und Erhebungsapp mQuest®.
<G-vec00206-002-s332><count.setzen><en> At best, hosts can count on a single solution that unites as many kinds as possible.
<G-vec00206-002-s332><count.setzen><de> Im besten Fall können Gastgeber auf eine Gesamtlösung setzen, die so viele Arten wie möglich miteinander vereint und mehr als nur ein Problem löst.
<G-vec00206-002-s333><count.setzen><en> We have fantastic visitors here, the decision-makers from the sector and for that reason we will also continue to count on our stand here.
<G-vec00206-002-s333><count.setzen><de> Wir haben ein tolles Publikum hier, die Entscheidungsträger der Branche und deswegen werden wir auch weiterhin hier auf unseren Stand setzen.
<G-vec00206-002-s334><count.setzen><en> When it comes to securities services for the German financial market, three out of four institutes count on us.
<G-vec00206-002-s334><count.setzen><de> Wenn es um Wertpapierservices für den deutschen Finanzmarkt geht, setzen drei von vier Instituten auf unsere Dienstleistungen.
<G-vec00206-002-s335><count.setzen><en> In the meantime, 6 centers in Germany count on this method: university hospitals at Rostock, Homburg/Saar, Tuebingen, Goettingen, Dresden and Magdeburg.
<G-vec00206-002-s335><count.setzen><de> Auf die Methode setzen mittlerweile sechs Zentren inDeutschland: die Universitätskliniken Rostock, Homburg/Saar, Tübingen,Göttingen, Dresden und Magdeburg.
<G-vec00206-002-s336><count.setzen><en> All leading capitalistic powers count petroleum as the most important energy raw material, simply because it is incomparably cheap and boosts their economy's growth enormously.
<G-vec00206-002-s336><count.setzen><de> Alle führenden kapitalistischen Mächte setzen auf das Erdöl als wichtigsten Energie-Rohstoff, einfach weil es konkurrenzlos billig ist und ihrem Wirtschaftswachstum enormen Auftrieb gibt.
<G-vec00206-002-s337><count.setzen><en> Well-known companies from an extremely wide range of industries count on our know-how.
<G-vec00206-002-s337><count.setzen><de> Bekannte Unternehmen aus den unterschiedlichsten Branchen setzen auf unser Know-How.
<G-vec00206-002-s338><count.setzen><en> You can count on high-quality multi-pin and tightly-fitting connectors and couplings – whether for a control unit or wiring harness.
<G-vec00206-002-s338><count.setzen><de> Setzen Sie auf mehrpolige und passgenaue Stecker und Kupplungen in Top-Qualität − ob für Steuergerät oder Kabelbaum.
<G-vec00206-002-s339><count.setzen><en> In uncertain times, customers are turning to the retailer they know and believe they can count on...for a quality product, dependable service and an experience they will want to repeat.
<G-vec00206-002-s339><count.setzen><de> In unsicheren Zeiten setzen die Kunden auf den vertrauten, verlässlichen Einzelhändler – im Hinblick auf Produktqualität, zuverlässigen Service und einer Erfahrung, die sie gerne wieder machen würden.
<G-vec00206-002-s340><count.setzen><en> Throughout the whole process from formulation, choice of packaging, certifications to evaluations and product tests, our partners can count on our expert support.
<G-vec00206-002-s340><count.setzen><de> Auf dem Weg von der Formulierung, bis hin zur Verpackungsauswahl, den Zertifizierungen, Bewertungen und den gewünschten Tests der Produkte, können unsere Kunden auf unsere Kompetenzen setzen.
<G-vec00206-002-s341><count.setzen><en> One of the world¹s most renowned and prestigious destinations, the Coast can count on the wealth of tourism products with which the area is endowed: from a wide range of itineraries, such as food and wine, religious and arts and crafts trails, to sporting activities and excursions.
<G-vec00206-002-s341><count.setzen><de> Letztere beispielsweise, die Côte d’Azur, ist eins der bekanntesten und namhaftesten Ziele der Welt und kann auf die Vielfalt seiner Touristenprodukte setzen, die das Gebiet im Überfluss besitzt: weingastronomische und religiöse Routen, Sport- und Ausflugsmöglichkeiten sowie ein interessantes Angebot an typischen Handwerksprodukten.
<G-vec00206-002-s342><count.setzen><en> We count on our staff’s cooperation in achieving this goal together.
<G-vec00206-002-s342><count.setzen><de> Wir setzen auf die Zusammenarbeit unserer Mitarbeiter, um dieses Ziel gemeinsam zu erreichen.
<G-vec00206-002-s343><count.setzen><en> With our reuse-concept we count on sustainable, environment-friendly en route indulgence.
<G-vec00206-002-s343><count.setzen><de> Wir setzen mit unserem Mehrweg-Konzept deshalb auf nachhaltigen, umweltfreundlichen Unterwegs-Genuss.
<G-vec00206-002-s344><count.setzen><en> In this, we count on agile development methodologies, excellent code quality and cutting-edge technologies – together with a dedicated team and over 15 years of experience.
<G-vec00206-002-s344><count.setzen><de> Dabei setzen wir auf agile Entwicklungsmethoden, exzellente Code-Qualität und aktuelle Technologien – zusammen mit einem engagierten Team und über 15 Jahren Erfahrung.
<G-vec00206-002-s345><count.setzen><en> Peter Dippel, owner and CEO of REMA TEC GmbH, states: "As a system integrator of material handling solutions, we count on efficiency and reliability.
<G-vec00206-002-s345><count.setzen><de> Peter Dippel, Inhaber und Geschäftsführer der REMA TEC GmbH, sagt: „Als Systemintegrator für Materialflusslösungen setzen wir auf Effizienz und Zuverlässigkeit.
<G-vec00206-002-s346><count.setzen><en> However, if you want to reach an even larger amount of people with a printed out-of-home product, you can also count on means of transport advertising.
<G-vec00206-002-s346><count.setzen><de> Wer jedoch mit einem gedruckten Out-of-Home-Produkt eine noch größere Menge an Leuten erreichen möchte, kann auch auf Verkehrsmittelwerbung setzen.
<G-vec00206-002-s347><count.setzen><en> Immediately after the merger, the law firm can count on a working unit in Baden-Württemberg and swiftly expand locally existing contacts and clients of the Heuking partners.
<G-vec00206-002-s347><count.setzen><de> Die Kanzlei kann umgehend nach dem Zusammenschluss auf eine funktionierende Einheit in Baden-Württemberg setzen und die bereits existierenden lokal vorhandenen Kontakte und Mandate der Heuking-Partner zügig ausbauen.
<G-vec00206-002-s404><count.verlassen><en> Those trusted service manufacturers like Ocean Freight Service factory will deliver solutions you can count on, so you can spend more time on what matters most - growing your business.
<G-vec00206-002-s404><count.verlassen><de> Jene vertrauenswürdigen Dienstleister werden Lösungen abliefern, auf die Sie sich verlassen können, sodass Sie mehr Zeit mit dem Wesentlichsten verbringen können - dem Wachstum Ihres Unternehmens.
<G-vec00206-002-s405><count.verlassen><en> When it comes to distribution in your terminal, you need equipment you can count on.
<G-vec00206-002-s405><count.verlassen><de> Wenn es um Distribution an Ihrem Terminal geht, dann benötigen Sie Geräte, auf die Sie sich verlassen können.
<G-vec00206-002-s406><count.verlassen><en> Casino of Dreams provides players with a user friendly design and customer support they can count on any time they require assistance.
<G-vec00206-002-s406><count.verlassen><de> Casino of Dreams bietet Spielern ein benutzerfreundliches Design und Kundenunterstützung, auf die sie sich verlassen können, wenn sie Hilfe benötigen.
<G-vec00206-002-s407><count.verlassen><en> You can count on the kitchen Ligno the last decades.
<G-vec00206-002-s407><count.verlassen><de> Verlassen Sie sich auf die Küche Ligno der letzten Jahrzehnte.
<G-vec00206-002-s408><count.verlassen><en> The significant level of cooperation in ARM TrustZone accelerates our ability to provide full security solutions that you can count on.
<G-vec00206-002-s408><count.verlassen><de> Die umfangreiche Zusammenarbeit in ARM TrustZone beschleunigt unsere Fähigkeiten, vollständige Sicherheitslösungen bereitzustellen, auf die Sie sich verlassen können.
<G-vec00206-002-s411><count.verlassen><en> It is known that the influence of economic capital and global policies is something one cannot count on.
<G-vec00206-002-s411><count.verlassen><de> Es ist bekannt, dass der Einfluss des ökonomischen Kapitals und der globalen Politik etwas darstellt, auf das wir uns nicht verlassen können.
<G-vec00206-002-s412><count.verlassen><en> And those who like to go on an adventure will be able to count on our external batteries to be able to use GPS and camera of your iPhone without fear of the dry failure.
<G-vec00206-002-s412><count.verlassen><de> Und diejenigen, die ein Abenteuer erleben möchten, können sich auf unsere externen Batterien verlassen, um GPS und die Kamera Ihres iPhones ohne Angst vor dem Trockenausfall nutzen zu können.
<G-vec00206-002-s413><count.verlassen><en> You can count on Avanade to be the best partner your business has ever had.
<G-vec00206-002-s413><count.verlassen><de> Avanade ist der ideale Partner für Ihr Unternehmen, auf den Sie sich jederzeit verlassen können.
<G-vec00206-002-s414><count.verlassen><en> So, should there be something with your hygrometer, you can count on an excellent service.
<G-vec00206-002-s414><count.verlassen><de> Falls Sie Probleme mit Ihrem Feuchtemessgerät haben, können Sie sich auf einen ausgezeichneten Service verlassen.
<G-vec00206-002-s416><count.verlassen><en> Since then, Israel has considered Germany to be the only other country it can count on besides the US.
<G-vec00206-002-s416><count.verlassen><de> Die Israelis halten Deutschland seitdem neben den USA für das einzige Land, auf das sie sich verlassen können.
<G-vec00206-002-s418><count.verlassen><en> Overall, we can say that all three authentication algorithms – HOTP, TOTP and OCRA are something you can count on when it comes to data security issues prevention.
<G-vec00206-002-s418><count.verlassen><de> Im Grossen und Ganzen können wir sagen, dass man sich auf alle drei Algorithmen der Identifizierung HOTP, TOTP und OCRA in der Frage des Schutzes der Daten vom unbefugten Zugriff verlassen kann.
<G-vec00206-002-s419><count.verlassen><en> When you buy from Dancover, you get durable and hardy tools, you can count on and that you will be able to use over time.
<G-vec00206-002-s419><count.verlassen><de> Wenn Sie bei Dancover einkaufen, erhalten Sie robuste und widerstandsfähige Werkzeuge, auf die Sie sich verlassen können und die für eine lange Zeit genutzt werden können.
<G-vec00206-002-s420><count.verlassen><en> During the journey from Katowice-Pyrzowice Airport you can count on our driver – you will definitely get to hear some interesting facts about our city; the driver will also provide you with information on topics that are of interest to you.
<G-vec00206-002-s420><count.verlassen><de> Während der Fahrt vom Flughafen können Sie sich auf unsere Fahrer verlassen – auf jeden Fall kriegen Sie einige interessante Fakten über unsere Stadt zu hören; der Fahrer wird auch versuchen, Informationen zu Themen die Sie interessieren zur Verfügung zu stellen.
<G-vec00206-002-s421><count.verlassen><en> HAVEP guarantees that all external processors are selected with due care so that we can count on the security and integrity of your personal data.
<G-vec00206-002-s421><count.verlassen><de> HAVEP garantiert, dass alle externen Auftragsverarbeiter sorgfältig ausgewählt werden, damit wir uns auf die Sicherheit und Integrität Ihrer personenbezogenen Daten verlassen können.
<G-vec00206-002-s422><count.verlassen><en> Magical Vegas Casino provides players with a user friendly design and customer support they can count on any time they require assistance.
<G-vec00206-002-s422><count.verlassen><de> Das Magical Vegas Casino bietet Spielern ein benutzerfreundliches Design und Kundenunterstützung, auf die sie sich verlassen können, wenn sie Hilfe benötigen.
<G-vec00206-002-s423><count.vertrauen><en> As with new binding machines, you can also count on our quality service for the purchase of used binding machines.
<G-vec00206-002-s423><count.vertrauen><de> Genau wie bei den neuen Bindegeräten können Sie bei den gebrauchten Geräten auf unseren Qualitätsservice vertrauen.
<G-vec00206-002-s424><count.vertrauen><en> Aware of our limits and our miseries, let us not count on our poor strength.
<G-vec00206-002-s424><count.vertrauen><de> Unserer Beschränkungen und Grenzen und unserer Armut bewußt, vertrauen wir nicht auf unsere wenigen Kräfte.
<G-vec00206-002-s425><count.vertrauen><en> Count on the unprecedented performance and innovative capabilities of NVIDIA Quadro® and Tesla® GPU to tackle even the most demanding visual computing tasks with ease.
<G-vec00206-002-s425><count.vertrauen><de> Vertrauen Sie auf die unübertroffene Leistung und innovativen Merkmale der NVIDIA® Quadro® und Tesla® Grafikkarten für die mühelose Verarbeitung grafisch anspruchsvoller Aufgaben.
<G-vec00206-002-s426><count.vertrauen><en> Many famous teams in the worldwide motorsport business count on the know how of the H&R suspension specialists and engineers from Germany’s Sauerland.
<G-vec00206-002-s426><count.vertrauen><de> Viele Spitzenteams des Motorsportes vertrauen auf das Know How des Fahrwerksspezialisten aus dem Sauerland und seiner Ingenieure.
<G-vec00206-002-s427><count.vertrauen><en> SPILLGUARD If things boil over at work, count on SpillGuard.
<G-vec00206-002-s427><count.vertrauen><de> Wenn es am Arbeitsplatz mal überkocht, vertrauen Sie auf den Spritzwasserschutz.
<G-vec00206-002-s428><count.vertrauen><en> Leading plant engineering companies and owner operators worldwide count on our software to deliver accurate, reliable results.
<G-vec00206-002-s428><count.vertrauen><de> Führende Unternehmen des Anlagenbaus sowie Anlagenbetreiber vertrauen auf unsere Software für die Lieferung genauer und zuverlässiger Ergebnisse.
<G-vec00206-002-s429><count.vertrauen><en> A name you can count on.
<G-vec00206-002-s429><count.vertrauen><de> Eine Marke, der man vertrauen kann.
<G-vec00206-002-s430><count.vertrauen><en> As a SKIDATA customer, you can count on a motivated team of employees who are progressive and passionate about their work.
<G-vec00206-002-s430><count.vertrauen><de> Als Kunde von SKIDATA können Sie auf ein motiviertes Team von Mitarbeitern vertrauen, die fortschrittlich sind und Leidenschaft für ihre Arbeit mitbringen.
<G-vec00206-002-s431><count.vertrauen><en> „Our customers can count on the fact that they can get the most economical total package from us.
<G-vec00206-002-s431><count.vertrauen><de> „Die Kunden können darauf vertrauen, dass sie bei uns das günstigste Gesamtpaket bekommen.
<G-vec00206-002-s432><count.vertrauen><en> No problem: you can count on your answering machine.
<G-vec00206-002-s432><count.vertrauen><de> Vertrauen Sie einfach auf Ihren Anrufbeantworter.
<G-vec00206-002-s433><count.vertrauen><en> 36 US military Pacific Command personnel helped out in the mission, along with experts from countries around the world but you can always count on Hollywood to find the American angle.
<G-vec00206-002-s433><count.vertrauen><de> 36 Soldaten des US Pacific Command halfen bei dieser Mission gemeinsam mit Experten aus der ganzen Welt, aber man kann auf Hollywood vertrauen, dass sie den amerikanischen Ansatz finden werden.
<G-vec00206-002-s434><count.vertrauen><en> Well-known, leading automotive manufacturers count on SFC KOENIG solutions for optimized safety and reliability.
<G-vec00206-002-s434><count.vertrauen><de> Renommierte, führende Automobilhersteller vertrauen Lösungen von SFC KOENIG für optimierte Sicherheit und Zuverlässigkeit.
<G-vec00206-002-s435><count.vertrauen><en> Count on it: A LeadingCamping is always the best campground in its region – leading in regard to service, facilities and innovation; extraordinary in regard to gastronomy, wellness, sports, entertainment and in the way you stay.
<G-vec00206-002-s435><count.vertrauen><de> Vertrauen Sie darauf: Ein LeadingCamping ist immer der beste Campingplatz seiner Region – führend in Service, Ausstattung und Innovation, außergewöhnlich in Gastronomie, Wellness, Sport, Unterhaltung und in der Art, wie Sie wohnen.
<G-vec00206-002-s436><count.vertrauen><en> We have played a successful role in the market for nearly half a century – you can count on our great experience.
<G-vec00206-002-s436><count.vertrauen><de> Seit einem halben Jahrhundert sind wir erfolgreich im Markt – Vertrauen Sie auf unsere große Erfahrung.
<G-vec00206-002-s437><count.vertrauen><en> No matter what you have in mind – you can count on our extensive know-how.
<G-vec00206-002-s437><count.vertrauen><de> Egal, was Sie auch vor haben – Sie können auf unser langjähriges Know-how vertrauen.
<G-vec00206-002-s438><count.vertrauen><en> Your donation towards rescue dog training makes sure that those affected in real emergencies can count on the world's best rescue dog teams. Donate Train the Trainers
<G-vec00206-002-s438><count.vertrauen><de> Mit Ihrer Spende für die Rettungshundeausbildung sorgen Sie dafür, dass Betroffene im Ernstfall auf die weltbesten Rettungshundeteams vertrauen dürfen.
<G-vec00206-002-s439><count.vertrauen><en> Renowned brand manufacturers from the international household appliance industry count on our product quality and reliability.
<G-vec00206-002-s439><count.vertrauen><de> Bekannte Markenhersteller der internationalen Weiße-Ware-Industrie vertrauen auf die Qualität und Zuverlässigkeit unserer Produkte.
<G-vec00206-002-s440><count.vertrauen><en> In their negotiations with works councils or trade unions, clients can count on our extensive experience and expertise in this area.
<G-vec00206-002-s440><count.vertrauen><de> In Verhandlungen mit Betriebsräten oder Gewerkschaften können Mandanten auf unsere umfangreiche Erfahrung und Expertise vertrauen, z.
<G-vec00206-002-s441><count.vertrauen><en> Major engine manufacturers throughout the world have learned to count on our heat exchangers.
<G-vec00206-002-s441><count.vertrauen><de> Richtungsweisende Motorenhersteller weltweit vertrauen auf Wärmetauscher von uns.
<G-vec00206-002-s518><count.zählen><en> Count on our modern and efficient technical solutions in the field of power electronics and profit from our know-how and over 20 years of experience.
<G-vec00206-002-s518><count.zählen><de> Zählen Sie auf moderne und effiziente Techniklösungen im Bereich der Leistungselektronik und nutzen Sie unser Know-how und unsere über 20-jährige Erfahrung.
<G-vec00206-002-s519><count.zählen><en> Count on Star Wars®: The New Essential Guide to Alien Species – and don't leave your homeworld without it. Generation:
<G-vec00206-002-s519><count.zählen><de> Zählen Sie auf den Star Wars®: The New Essential Guide to Alien Species – und verlassen Sie Ihren Heimatplanet niemals ohne ihn.
<G-vec00206-002-s520><count.zählen><en> Count inwardly to ten and go a few steps on your rebellious pirates or your bitchy princess.
<G-vec00206-002-s520><count.zählen><de> Zählen Sie innerlich bis zehn und gehen Sie ein paar Schritte auf Ihren aufmüpfigen Piraten oder Ihrer zickige Prinzessin zu.
<G-vec00206-002-s521><count.zählen><en> Count to ten.
<G-vec00206-002-s521><count.zählen><de> Zählen Sie bis zehn.
<G-vec00206-002-s522><count.zählen><en> Count how many steps you have walked, how far you have run and how much calorie you have consumed.
<G-vec00206-002-s522><count.zählen><de> Zählen Sie, wie viele Schritte Sie gelaufen, wie weit Sie laufen und wie viel Kalorien Sie verbraucht haben.
<G-vec00206-002-s523><count.zählen><en> Keep it stretched out and count to five.
<G-vec00206-002-s523><count.zählen><de> Lassen Sie es ausgestreckt und zählen Sie bis fünf.
<G-vec00206-002-s524><count.zählen><en> Count on the perfect fit, skin friendly materials and comfortable wearing feel.
<G-vec00206-002-s524><count.zählen><de> Zählen Sie auf perfekte Passform, hautfreundliche Materialien und bequemes Tragegefühl.
<G-vec00206-002-s525><count.zählen><en> And then the Professor had ordered: "Count.
<G-vec00206-002-s525><count.zählen><de> Und dann hatte der Professor befohlen: »Zählen Sie.
<G-vec00206-002-s526><count.zählen><en> One man wrote: “Count me curious, but not yet committed.
<G-vec00206-002-s526><count.zählen><de> Ein Mann schrieb: „Zählen Sie mich neugierig, aber nicht schon festgelegt.
<G-vec00206-002-s527><count.zählen><en> Then count on us and let us count for you.
<G-vec00206-002-s527><count.zählen><de> Dann zählen Sie auf uns und lassen uns für Sie zählen.
<G-vec00206-002-s528><count.zählen><en> Now count the number of alphabets in which a given letter is present.
<G-vec00206-002-s528><count.zählen><de> Zählen Sie nun die Anzahl der Alphabethe, in denen ein bestimmter Buchstabe vorkommt.
<G-vec00206-002-s529><count.zählen><en> Now count five to seven buds up, and cut the shoot tip off just above the fifth to seventh bud.
<G-vec00206-002-s529><count.zählen><de> Zählen Sie nun fünf bis sieben Knospen nach oben und schneiden Sie kurz oberhalb der fünften bis siebten Knospe die Triebspitze ab.
<G-vec00206-002-s530><count.zählen><en> Count on us when it comes to measuring: We have the necessary know-how to measure and validate all parts that we have made.
<G-vec00206-002-s530><count.zählen><de> Zählen Sie auf uns, wenn es ums Messen geht: Wir verfügen über das nötige Know-how, um alle von uns gefertigten Teile selber zu vermessen und zu validieren.
<G-vec00206-002-s531><count.zählen><en> Measuring cups and count things, like crackers, to see how much you should really be there.
<G-vec00206-002-s531><count.zählen><de> Verwenden Sie Messbecher und zählen Sie Dinge wie Cracker zu sehen, wie viel Sie wirklich essen.
<G-vec00206-002-s532><count.zählen><en> Entrust us with your unanswered questions, and count on expert quality from INNOTECH®.
<G-vec00206-002-s532><count.zählen><de> Überlassen Sie uns Ihre offenen Fragen und zählen Sie auf Qualität vom Experten, von INNOTECH.
<G-vec00206-002-s533><count.zählen><en> If this is affecting you, KEEP CALM, count to ten before replying to even the slightest provocation, and carry a Dragon Holding Fireball Anti-Conflict amulet.
<G-vec00206-002-s533><count.zählen><de> Falls Sie davon betroffen sind, BLEIBEN SIE RUHIG und zählen Sie auf zehn, bevor Sie auch nur auf die leichteste Provokation antworten, und tragen Sie ein Anti-Konflikt Amulett mit dem roten Drachen.
<G-vec00206-002-s534><count.zählen><en> Count on CRYPTALLOY RFID blocking.
<G-vec00206-002-s534><count.zählen><de> Zählen Sie auf CRYPTALLOY RFID Blocking.
<G-vec00206-002-s535><count.zählen><en> Count all blocks and type a number in the text box at the top.
<G-vec00206-002-s535><count.zählen><de> Zählen Sie alles zusammen und geben Sie anschließend eine Zahl oben in das Textfeld ein.
<G-vec00402-002-s033><count.anrechnen><en> If they do, they will not be enrolled in the workflow and will not count towards the workflow's goal conversion rate.
<G-vec00402-002-s033><count.anrechnen><de> Wenn dies der Fall ist, werden sie nicht in den Workflow aufgenommen und nicht auf die Zielkonversionsrate des Workflows angerechnet.
<G-vec00402-002-s034><count.anrechnen><en> A bet will count towards the Challenge according to the time it was placed (regardless of when it is settled).
<G-vec00402-002-s034><count.anrechnen><de> Ein Einsatz wird in Abhängigkeit von der Zeit, in der sie platziert wurde, auf die Aufgabe angerechnet (unabhängig davon, wann sie gewertet wurde).
<G-vec00402-002-s035><count.anrechnen><en> Videos WhatsApp Backups Note: Movies, apps, books, and music bought in iTunes will not count towards your iCloud storage.
<G-vec00402-002-s035><count.anrechnen><de> Die in iTunes gekauften Filme, Apps, Bücher und Musik werden auf Ihren iCloud-Speicher nicht angerechnet, da iTunes es erlaubt diese erneut herunterzuladen.
<G-vec00402-002-s036><count.anrechnen><en> Note: Gadgets don’t count toward your storage limits.
<G-vec00402-002-s036><count.anrechnen><de> Hinweis: Gadgets werden nicht auf Ihr Speicherplatzkontingent angerechnet.
<G-vec00402-002-s037><count.anrechnen><en> Purchased music, apps, books and Photo Stream do not count against the storage limit.
<G-vec00402-002-s037><count.anrechnen><de> Gekaufte Musik, Apps, Bücher und Photo Stream werden nicht auf diese Speichergrenze angerechnet.
<G-vec00402-002-s038><count.anrechnen><en> All offers are free of charge for teaching staff at Kiel University, and count as supplementary workshops for university didactic qualifications by the Continuing Professional Development Centre.
<G-vec00402-002-s038><count.anrechnen><de> Alle Angebote sind für Lehrende der CAU kostenfrei und werden innerhalb der hochschuldidaktischen Zertifikate der Wissenschaftlichen Weiterbildung als Aufbauworkshops angerechnet.
<G-vec00402-002-s039><count.anrechnen><en> Flagged reviews will be removed and not count toward a business’s star rating.
<G-vec00402-002-s039><count.anrechnen><de> Markierte Bewertungen werden entfernt und nicht auf die Sternebewertung eines Unternehmens angerechnet.
<G-vec00402-002-s040><count.anrechnen><en> Manual entries, trainer rides or rides marked private will not count towards your Challenge effort.
<G-vec00402-002-s040><count.anrechnen><de> Manuelle Einträge oder Trainingsfahrten werden nicht auf deine Herausforderungsleistungen angerechnet.
<G-vec00402-002-s041><count.anrechnen><en> Manual entries or treadmill runs will not count towards your Challenge effort.
<G-vec00402-002-s041><count.anrechnen><de> Manuelle Einträge oder Läufe auf dem Laufband werden nicht auf deine Herausforderungsleistung angerechnet.
<G-vec00402-002-s042><count.anrechnen><en> Both Real and Bonus funds spins will count towards the Tournament.
<G-vec00402-002-s042><count.anrechnen><de> Sowohl das Echtgeld als auch das Bonusgeld werden für das Turnier angerechnet.
<G-vec00402-002-s043><count.anrechnen><en> During a research visit, scholarship holders continue to receive their payments, which count as part of the agreed period of financial support.
<G-vec00402-002-s043><count.anrechnen><de> Für Stipendiatinnen und Stipendiaten wird die Zahlung des Stipendiums während eines Forschungsaufenthaltes fortgesetzt und auf die vereinbarte Förderdauer angerechnet.
<G-vec00402-002-s044><count.anrechnen><en> Any tests carried out under this paragraph shall count towards the minimum number of tests required under paragraph 2.
<G-vec00402-002-s044><count.anrechnen><de> Jede nach dem vorliegenden Absatz durchgeführte Prüfung wird auf die nach Absatz 2 vorgeschriebene Mindestanzahl von Prüfungen angerechnet.
<G-vec00402-002-s045><count.anrechnen><en> The notification shall be made by each Member State towards whose overall national target the proportion or amount of electricity is to count.
<G-vec00402-002-s045><count.anrechnen><de> Die Mitteilung erfolgt durch jeden Mitgliedstaat, auf dessen nationales Gesamtziel der Prozentsatz oder die Menge der Elektrizität angerechnet werden soll.
<G-vec00402-002-s046><count.anrechnen><en> Manual entries or trainer rides will not count towards your Challenge effort.
<G-vec00402-002-s046><count.anrechnen><de> Manuelle Einträge oder Trainingsfahrten werden nicht auf deine Herausforderung angerechnet.
<G-vec00402-002-s047><count.anrechnen><en> Please note that that date of entry and exit count towards the 30 days Total limit.
<G-vec00402-002-s047><count.anrechnen><de> Bitte beachten Sie, dass das Datum der Ein- und Ausreise auf das 30-tägige Limit angerechnet wird.
<G-vec00402-002-s048><count.anrechnen><en> The reservation fee will count in full to the pitch hire fee.
<G-vec00402-002-s048><count.anrechnen><de> Die Reservierungsgebühr wird auf die Platzmiete voll angerechnet.
<G-vec00402-002-s049><count.anrechnen><en> However, the hotel reward night is not point qualifying and does not count toward tier qualification.
<G-vec00402-002-s049><count.anrechnen><de> Eine Hotel-Bonusnacht ist jedoch nicht bonusberechtigend und wird nicht zur Erlangung der Qualifikation für einen Mitgliedslevel angerechnet.
<G-vec00402-002-s254><count.haben><en> We count with greens for both professional and amateur golfers.
<G-vec00402-002-s254><count.haben><de> Wir haben Greens für beide Profis und Amateure.
<G-vec00402-002-s255><count.haben><en> We count also on your prayer.
<G-vec00402-002-s255><count.haben><de> Wir haben auch euer Gebet.
<G-vec00402-002-s256><count.haben><en> Currently, we count about 300 active correspondents.
<G-vec00402-002-s256><count.haben><de> Zurzeit haben wir über 300 aktive Teilnehmer.
<G-vec00402-002-s257><count.haben><en> The partly simple, low-parts number count circuits sound quite charming, similar and similarly unique like tube circuits.
<G-vec00402-002-s257><count.haben><de> Die teils extrem simplen, bauteilarmen Schaltungen haben einen klanglichen Charme, den allenfalls noch gute Röhrenschaltungen bieten können.
<G-vec00402-002-s258><count.haben><en> Today, we count with over 50 cars in our 4x4 rental fleet.
<G-vec00402-002-s258><count.haben><de> Heue haben wir über 50 PKW in unserer Allradflotte.
<G-vec00402-002-s259><count.haben><en> We count on highly qualified technical personnel.
<G-vec00402-002-s259><count.haben><de> Wir haben hoch qualifizierte technische Personal.
<G-vec00402-002-s260><count.haben><en> Weekly digests—Every week, we send an email that shows you how many reviews you collected the prior week and provides recommendations for increasing your review count.
<G-vec00402-002-s260><count.haben><de> Wöchentliche Zusammenfassungen – Wir senden Ihnen jede Woche eine E-Mail, die zeigt, wie viele Bewertungen Sie in der vergangenen Woche erfasst haben.
<G-vec00402-002-s261><count.haben><en> We count to the date More... with a select customer, made up of the companies and more important institutions of piura, with which solid and lasting relations have dreamed up.
<G-vec00402-002-s261><count.haben><de> Wir haben eine Verabredung mit einer ausgewählten Klientel, der Mehr... wichtigsten Unternehmen und Institutionen von Piura, die starke und dauerhafte Beziehungen geschmiedet haben, zusammensetzt.
<G-vec00402-002-s262><count.haben><en> Because everyone can count on knowing that we would never leave anyone in the lurch.
<G-vec00402-002-s262><count.haben><de> Weil jeder die Gewissheit haben kann, dass wir niemanden im Stich lassen.
<G-vec00402-002-s263><count.haben><en> Even this graph from return.co places the average word count of the travel sector pretty high.
<G-vec00402-002-s263><count.haben><de> Sogar dieses Diagramm von New Age Media zeigt, dass Artikel aus der Reisebranche eher mehr Wörter haben.
<G-vec00402-002-s264><count.haben><en> It is of utmost importance that the inhabitants of these villages have at least a basic medical assistance to count upon, because their state of health is often already weak due to the climate, diet and contaminated water.
<G-vec00402-002-s264><count.haben><de> Es ist von äußerster Wichtigkeit, dass die Bewohner dieser Dörfer wenigstens eine Grundlage medizinischer Hilfe haben, weil ihr Gesundheitsstatus oft schon wegen des Klimas, Nahrung und verunreinigten Wassers schwach ist .
<G-vec00402-002-s265><count.haben><en> Count down the 10 biggest debuts to take place at Survivor Series.
<G-vec00402-002-s265><count.haben><de> Seht euch die 10 größten Debüts an, die bei Survivor Series stattgefunden haben.
<G-vec00402-002-s266><count.haben><en> When it comes to finding the best KLM price online, you can count on klm.com.
<G-vec00402-002-s266><count.haben><de> Der Preis muss mindestens 15 CHF unter dem klm.com-Preis liegen und an dem Tag gefunden worden sein, an dem Sie Ihr klm.com-Ticket gebucht haben.
<G-vec00402-002-s267><count.haben><en> Circles in the reservation count from 15 to 33 m in diameter. In each circle is from 16 to 29 stones protruding from the ground for 20 to 70 cm.
<G-vec00402-002-s267><count.haben><de> Die Steinkreise haben einen Durchmesser von 15 bis 33 m. In jedem Steinkreis sind 16 bis 29 Steine, die zu 20 bis 70 cm aus der Erde hervorragen.
<G-vec00402-002-s268><count.haben><en> Aces count as either 1 or 11, face cards count as 10 and number cards count at their face values.
<G-vec00402-002-s268><count.haben><de> Asse zählen entweder als 1 oder 11, Bildkarten als 10 und Nummernkarten haben den angezeigten Wert.
<G-vec00402-002-s269><count.haben><en> We would be thrilled to count you in.
<G-vec00402-002-s269><count.haben><de> Wir würden uns freuen, Sie hier zu haben.
<G-vec00402-002-s270><count.haben><en> During expansion of our company we could count on many years of experience in market of packaging materials.
<G-vec00402-002-s270><count.haben><de> Für die Entwicklung unseres Unternehmens haben wir die langjährigen Erfahrungen im Bereich der Verpackungsmaterialen ausgenutzt.
<G-vec00402-002-s271><count.haben><en> We count on an ample range in fabrics and national and imported designs.
<G-vec00402-002-s271><count.haben><de> Wir haben eine breite Palette von Stoffen und inländischer und importierter Designs.
<G-vec00402-002-s272><count.haben><en> We count on a team of professionals who follow the whole process of product traceability from the farm to the consumer.
<G-vec00402-002-s272><count.haben><de> Wir haben ein erfahrenes Team von Fachleuten, die unsere Produkte vom Anbau bis hin zum Verbraucher begleiten.
<G-vec00402-002-s367><count.sich_verlassen><en> You can count on us for the complete technical design for your self-storage infrastructure.
<G-vec00402-002-s367><count.sich_verlassen><de> Auch für den vollständigen Entwurf Ihrer Selfstorage-Infrastruktur können Sie sich auf uns verlassen.
<G-vec00402-002-s368><count.sich_verlassen><en> Those who are better at studying international / Russian accounting and corporate governance issues can count on the career of a financial analyst in large industrial companies.
<G-vec00402-002-s368><count.sich_verlassen><de> Diejenigen, die besser in der Lage sind, internationale / russische Fragen der Rechnungslegung und Corporate Governance zu studieren, können sich auf die Karriere eines Finanzanalysten in großen Industrieunternehmen verlassen.
<G-vec00402-002-s369><count.sich_verlassen><en> 2684 One thing that I always didn't like on most tube sites was the fact that you can always count on the lousy quality of the videos.
<G-vec00402-002-s369><count.sich_verlassen><de> 2684 Eine Sache, die mir auf den meisten Tube-Seiten nicht gefiel, war die Tatsache, dass man sich immer auf die lausige Qualität der Videos verlassen kann.
<G-vec00402-002-s370><count.sich_verlassen><en> Night ride For good riders in twos, with moonlight by the night ride, count on the horses and her steps.
<G-vec00402-002-s370><count.sich_verlassen><de> Nachtritte sind am Knallerhof stets ein Erlebnis Für gute Reiter zu zweit, bei Mondschein durch die Nacht reiten, sich auf die Pferde und ihre Schritte verlassen.
<G-vec00402-002-s371><count.sich_verlassen><en> Our clients can hence always count on one thing: 100 % performance.
<G-vec00402-002-s371><count.sich_verlassen><de> Damit können sich unsere Kunden stets auf eines verlassen: 100% Leistung.
<G-vec00402-002-s372><count.sich_verlassen><en> Drivers can count on an ABB charger.
<G-vec00402-002-s372><count.sich_verlassen><de> Die Autofahrer können sich auf die Ladestationen von ABB verlassen.
<G-vec00402-002-s373><count.sich_verlassen><en> Whichever you choose, you can always count on comfortable beds, free access to the hotel’s hot tubs, saunas and wi-fi throughout the hotel.
<G-vec00402-002-s373><count.sich_verlassen><de> Egal wofür man sich entscheidet, man kann sich immer auf bequeme Betten verlassen, kostenlosen Zutritt zu den Whirlpools des Hotels und der Sauna, und auf Internet im ganzen Hotel.
<G-vec00402-002-s374><count.sich_verlassen><en> Neither Mr. Oberländer nor third who are involved in the production, production or transmission of this website are responsible for damages or injuries which originate to themselves from the access or the impossibility of the access, the use or impossibility of the use of this website or from the fact that you count on information which is included on this website.
<G-vec00402-002-s374><count.sich_verlassen><de> Weder Herr Oberländer noch Dritte, die in die Erstellung, Produktion oder Übermittlung dieser Website involviert sind, sind haftbar für Schäden oder Verletzungen, die sich aus dem Zugang oder der Unmöglichkeit des Zugangs, der Nutzung oder Unmöglichkeit der Nutzung dieser Website oder aus dem Umstand, dass Sie sich auf eine Information, die auf dieser Website enthalten ist, verlassen, entstehen.
<G-vec00402-002-s375><count.sich_verlassen><en> You can count on a smooth and efficient translation service at an affordable price.
<G-vec00402-002-s375><count.sich_verlassen><de> Sie können sich auf einen schnellen und effizienten Übersetzungsservice verlassen und das zu einem guten Preis.
<G-vec00402-002-s376><count.sich_verlassen><en> You can count on real-time accuracy.
<G-vec00402-002-s376><count.sich_verlassen><de> Sie können sich auf präzise Echtzeitdaten verlassen.
<G-vec00402-002-s377><count.sich_verlassen><en> Quality is capitalized with us - you can count on it.
<G-vec00402-002-s377><count.sich_verlassen><de> Qualität wird bei uns groß geschrieben – darauf können Sie sich verlassen.
<G-vec00402-002-s378><count.sich_verlassen><en> Thanks to the Memosens technology, the cable connection is insensitive to moisture, corrosion or dirt: you can count on the sensor's highest availability and your trial is safe.
<G-vec00402-002-s378><count.sich_verlassen><de> Dank der Memosens-Technologie unterliegt die Kabelverbindung keinen Problemen durch Feuchtigkeit, Korrosion oder Verunreinigungen: Sie können sich auf die maximale Verfügbarkeit des Sensors und die Sicherheit Ihrer Tests verlassen.
<G-vec00402-002-s379><count.sich_verlassen><en> You can count on our competent, friendly and professional personnel fully...
<G-vec00402-002-s379><count.sich_verlassen><de> Sie können sich voll auf unsere kompetenten, Freundlichen und professionellen Mitarbeiter verlassen...
<G-vec00402-002-s380><count.sich_verlassen><en> Woo Casino is part of the Direx N.V Group and as with their other 38 popular casinos, players can count on a very easy and fast registration.
<G-vec00402-002-s380><count.sich_verlassen><de> Das Woo Casino ist Teil der Direx N.V. Gruppe und wie bei ihren anderen 38 beliebten Casinos können sich die Spieler auf eine sehr einfache und schnelle Registrierung verlassen.
<G-vec00402-002-s381><count.sich_verlassen><en> You can count on us.
<G-vec00402-002-s381><count.sich_verlassen><de> Auf uns kann man sich verlassen.
<G-vec00402-002-s382><count.sich_verlassen><en> As customers are king, you can count on our high service.
<G-vec00402-002-s382><count.sich_verlassen><de> Da der Kunde König ist, können Sie sich auf unseren hohen Service verlassen.
<G-vec00402-002-s383><count.sich_verlassen><en> You can count on our experience.
<G-vec00402-002-s383><count.sich_verlassen><de> Sie können sich auf unsere Erfahrung verlassen.
<G-vec00402-002-s384><count.sich_verlassen><en> From planning to implementation... you can count on us.
<G-vec00402-002-s384><count.sich_verlassen><de> Von der Planung bis zur Umsetzung... Sie können sich auf uns verlassen.
<G-vec00402-002-s385><count.sich_verlassen><en> We will do as promised, you can count on that.
<G-vec00402-002-s385><count.sich_verlassen><de> Was wir Ihnen versprechen, das halten wir auch, darauf können Sie sich verlassen.
<G-vec00402-002-s367><count.verlassen><en> You can count on us for the complete technical design for your self-storage infrastructure.
<G-vec00402-002-s367><count.verlassen><de> Auch für den vollständigen Entwurf Ihrer Selfstorage-Infrastruktur können Sie sich auf uns verlassen.
<G-vec00402-002-s368><count.verlassen><en> Those who are better at studying international / Russian accounting and corporate governance issues can count on the career of a financial analyst in large industrial companies.
<G-vec00402-002-s368><count.verlassen><de> Diejenigen, die besser in der Lage sind, internationale / russische Fragen der Rechnungslegung und Corporate Governance zu studieren, können sich auf die Karriere eines Finanzanalysten in großen Industrieunternehmen verlassen.
<G-vec00402-002-s369><count.verlassen><en> 2684 One thing that I always didn't like on most tube sites was the fact that you can always count on the lousy quality of the videos.
<G-vec00402-002-s369><count.verlassen><de> 2684 Eine Sache, die mir auf den meisten Tube-Seiten nicht gefiel, war die Tatsache, dass man sich immer auf die lausige Qualität der Videos verlassen kann.
<G-vec00402-002-s370><count.verlassen><en> Night ride For good riders in twos, with moonlight by the night ride, count on the horses and her steps.
<G-vec00402-002-s370><count.verlassen><de> Nachtritte sind am Knallerhof stets ein Erlebnis Für gute Reiter zu zweit, bei Mondschein durch die Nacht reiten, sich auf die Pferde und ihre Schritte verlassen.
<G-vec00402-002-s371><count.verlassen><en> Our clients can hence always count on one thing: 100 % performance.
<G-vec00402-002-s371><count.verlassen><de> Damit können sich unsere Kunden stets auf eines verlassen: 100% Leistung.
<G-vec00402-002-s372><count.verlassen><en> Drivers can count on an ABB charger.
<G-vec00402-002-s372><count.verlassen><de> Die Autofahrer können sich auf die Ladestationen von ABB verlassen.
<G-vec00402-002-s373><count.verlassen><en> Whichever you choose, you can always count on comfortable beds, free access to the hotel’s hot tubs, saunas and wi-fi throughout the hotel.
<G-vec00402-002-s373><count.verlassen><de> Egal wofür man sich entscheidet, man kann sich immer auf bequeme Betten verlassen, kostenlosen Zutritt zu den Whirlpools des Hotels und der Sauna, und auf Internet im ganzen Hotel.
<G-vec00402-002-s374><count.verlassen><en> Neither Mr. Oberländer nor third who are involved in the production, production or transmission of this website are responsible for damages or injuries which originate to themselves from the access or the impossibility of the access, the use or impossibility of the use of this website or from the fact that you count on information which is included on this website.
<G-vec00402-002-s374><count.verlassen><de> Weder Herr Oberländer noch Dritte, die in die Erstellung, Produktion oder Übermittlung dieser Website involviert sind, sind haftbar für Schäden oder Verletzungen, die sich aus dem Zugang oder der Unmöglichkeit des Zugangs, der Nutzung oder Unmöglichkeit der Nutzung dieser Website oder aus dem Umstand, dass Sie sich auf eine Information, die auf dieser Website enthalten ist, verlassen, entstehen.
<G-vec00402-002-s375><count.verlassen><en> You can count on a smooth and efficient translation service at an affordable price.
<G-vec00402-002-s375><count.verlassen><de> Sie können sich auf einen schnellen und effizienten Übersetzungsservice verlassen und das zu einem guten Preis.
<G-vec00402-002-s376><count.verlassen><en> You can count on real-time accuracy.
<G-vec00402-002-s376><count.verlassen><de> Sie können sich auf präzise Echtzeitdaten verlassen.
<G-vec00402-002-s377><count.verlassen><en> Quality is capitalized with us - you can count on it.
<G-vec00402-002-s377><count.verlassen><de> Qualität wird bei uns groß geschrieben – darauf können Sie sich verlassen.
<G-vec00402-002-s378><count.verlassen><en> Thanks to the Memosens technology, the cable connection is insensitive to moisture, corrosion or dirt: you can count on the sensor's highest availability and your trial is safe.
<G-vec00402-002-s378><count.verlassen><de> Dank der Memosens-Technologie unterliegt die Kabelverbindung keinen Problemen durch Feuchtigkeit, Korrosion oder Verunreinigungen: Sie können sich auf die maximale Verfügbarkeit des Sensors und die Sicherheit Ihrer Tests verlassen.
<G-vec00402-002-s379><count.verlassen><en> You can count on our competent, friendly and professional personnel fully...
<G-vec00402-002-s379><count.verlassen><de> Sie können sich voll auf unsere kompetenten, Freundlichen und professionellen Mitarbeiter verlassen...
<G-vec00402-002-s380><count.verlassen><en> Woo Casino is part of the Direx N.V Group and as with their other 38 popular casinos, players can count on a very easy and fast registration.
<G-vec00402-002-s380><count.verlassen><de> Das Woo Casino ist Teil der Direx N.V. Gruppe und wie bei ihren anderen 38 beliebten Casinos können sich die Spieler auf eine sehr einfache und schnelle Registrierung verlassen.
<G-vec00402-002-s381><count.verlassen><en> You can count on us.
<G-vec00402-002-s381><count.verlassen><de> Auf uns kann man sich verlassen.
<G-vec00402-002-s382><count.verlassen><en> As customers are king, you can count on our high service.
<G-vec00402-002-s382><count.verlassen><de> Da der Kunde König ist, können Sie sich auf unseren hohen Service verlassen.
<G-vec00402-002-s383><count.verlassen><en> You can count on our experience.
<G-vec00402-002-s383><count.verlassen><de> Sie können sich auf unsere Erfahrung verlassen.
<G-vec00402-002-s384><count.verlassen><en> From planning to implementation... you can count on us.
<G-vec00402-002-s384><count.verlassen><de> Von der Planung bis zur Umsetzung... Sie können sich auf uns verlassen.
<G-vec00402-002-s385><count.verlassen><en> We will do as promised, you can count on that.
<G-vec00402-002-s385><count.verlassen><de> Was wir Ihnen versprechen, das halten wir auch, darauf können Sie sich verlassen.
<G-vec00402-002-s442><count.werden><en> Amongst the hotel's facilities count a foyer with a 24-hour reception desk, a safe, a currency exchange desk, a conference room and a secure car park (for an additional fee).
<G-vec00402-002-s442><count.werden><de> Den Gästen werden eine Empfangshalle, Rezeption (24 Stunden besetzt), Hotel-Safe, Wechselstube, ein Konferenzraum und ein bewachter Parkplatz (gegen Gebühr) geboten.
<G-vec00402-002-s443><count.werden><en> All services provided by the company or its personnel count as own contributions. 18.
<G-vec00402-002-s443><count.werden><de> Sämtliche Leistungen, die das Unternehmen beziehungsweise dessen MitarbeiterInnen selbst erbringen, werden als Eigenleistungen anerkannt.
<G-vec00402-002-s444><count.werden><en> Three Specialty Dining options for two guests: Cagney's - Chicago Style Steak House voucher traditional group or FS group and count towards tour conductor credits.
<G-vec00402-002-s444><count.werden><de> Berechtigte Individual Fit Reservierungen können auf eine existierende, traditionelle Gruppe oder eine FS-Gruppe übertragen werden und werden für das Tour Conductor-Guthaben angerechnet.
<G-vec00402-002-s445><count.werden><en> Even after implementation, if something went wrong (for example, with individual user account setup), Janneke could always count on Resourcing Pros for help.
<G-vec00402-002-s445><count.werden><de> Auch nach der Implementierung, zum Beispiel bei der Einrichtung eines individuellen Benutzerkontos bekam Shell von Resourcing Pros noch Hilfestellung und es konnten verschiedene Fragen geklärt werden.
<G-vec00402-002-s446><count.werden><en> Your faculty’s study and examination advisors: Study and examination advisors can explain and make recommendations about the different ways your degree programme can be organised and which modules can count towards the area of professionalisation.
<G-vec00402-002-s446><count.werden><de> Studien- und Prüfungsberater/innen Ihrer Fakultät: Hier erfahren Sie, welche Gestaltungsmöglichkeiten und Empfehlungen es für Ihren Studiengang gibt und welche Module im Professionalisierungsbereich angerechnet werden können.
<G-vec00402-002-s447><count.werden><en> Kilometre count is noted, damage is photographed and documented.
<G-vec00402-002-s447><count.werden><de> Kilometerstände werden notiert, vorhandene Schäden fotografiert und dokumentiert.
<G-vec00402-002-s448><count.werden><en> The staff can count on modern security means of transportation like water scooters and Rescue Surfs (boards that can transport 2 people: rescuer and injured.
<G-vec00402-002-s448><count.werden><de> Darüber hinaus stehen moderne Rettungsgeräte für den Einsatz im Meer bereit, wie etwa Wasser-Scooter und sogenannte Rescue Surfs (Bretter, auf denen zwei Personen transportiert werden können: der Verletzte und der Retter).
<G-vec00402-002-s449><count.werden><en> Among the facilities offered by this air-conditioned hotel count a foyer with 24-hour reception and a bar. On Request
<G-vec00402-002-s449><count.werden><de> Das Strandhotel ist zudem klimatisiert und die Gäste werden im Empfangsbereich mit 24h-Rezeption mit Check-out-Service willkommen geheißen.
<G-vec00402-002-s450><count.werden><en> These points count toward both Total and Status point totals.
<G-vec00402-002-s450><count.werden><de> Diese Punkte werden sowohl auf die Gesamtpunkte als auch auf die Statuspunktesumme angerechnet.
<G-vec00402-002-s451><count.werden><en> We count on your genuine help for people as generous and politically aware as Rachel, Brian and Tom, to join the International Solidarity Movement (ISM).
<G-vec00402-002-s451><count.werden><de> Aufopfernde und politisch bewusste Menschen, wie Brian, Rachel, und Tom, werden durch Eure großzügige Mitgliedschaft unterstützt, damit sie sich weiterhin nach Palästina begeben können, um dort den Kampf fortzusetzen.
<G-vec00402-002-s452><count.werden><en> Of cource, "Believers" count only as believers when they are Muslims.
<G-vec00402-002-s452><count.werden><de> Unter den "Gläubigen" werden wie selbstverständlich die Muslime verstanden.
<G-vec00402-002-s453><count.werden><en> Medical equipment and up to two assistive devices that are approved for transportation in the cabin do not count towards the number of carry-on bags a passenger is allowed free of charge.
<G-vec00402-002-s453><count.werden><de> Medizinische Geräte und bis zu zwei Hilfsgeräte, die für den Transport in der Kabine zugelassen sind, werden bei der Anzahl der Handgepäck-Stücke nicht mitgezählt, die ein Passagier kostenlos mitnehmen darf.
<G-vec00402-002-s454><count.werden><en> Job rotation, exchange programmes, learning circles, quality circles and self-directed learning count as more modern 'other' forms of continuing vocational training.
<G-vec00402-002-s454><count.werden><de> Zu den moderneren "anderen" Formen der betrieblichen Weiterbildung werden Job-Rotation, Austauschprogramme, Lern- und Qualitätszirkel und das selbstgesteuerte Lernen gerechnet.
<G-vec00402-002-s455><count.werden><en> At the moment Swiss Health can Count 31 member hospitals and clinics.
<G-vec00402-002-s455><count.werden><de> Die Spitäler und Kliniken die von Swiss Health empfohlen werden, decken die vollständige Bandbreite aller Krankheitsbilder ab.
<G-vec00402-002-s456><count.werden><en> Flushes, straights and pairs count against your hand
<G-vec00402-002-s456><count.werden><de> Flushes, Straights und Paare werden als solche gewertet.
<G-vec00402-002-s457><count.werden><en> If you have an ad with multiple creatives of the same size and you select the As many as possible or One or more setting for displaying creatives, you must enter the number of creatives of each size. Click the Provide some creative details link under the 'Inventory Sizes' field, then enter a number in the 'Count' field.
<G-vec00402-002-s457><count.werden><de> Wenn Sie über eine Anzeige mit mehreren Creatives derselben Größe verfügen und Sie die Einstellung So viele wie möglich oder Eines oder mehrere zur Anzeige der Creatives auswählen, kann das verfügbare Inventar in der Prognose unterschätzt werden, da derzeit davon ausgegangen wird, dass jede Anzeige nur über ein Creative einer bestimmten Größe verfügen kann.
<G-vec00402-002-s458><count.werden><en> Qualifying new individual FIT reservations can be moved into an existing speculative group and count towards tour conductor credits.
<G-vec00402-002-s458><count.werden><de> Berechtigte New Individual FIT Reservierungen können auf eine bestehende traditionelle FS-Gruppe übertragen werden und werden für das Tour Conductor-Guthaben angerechnet.
<G-vec00402-002-s459><count.werden><en> The employees can count on increased comfort thanks to six of these cranes, each with a load-bearing capacity of up to five tonnes.
<G-vec00402-002-s459><count.werden><de> Mit sechs dieser Profilkrane mit einer Traglast von jeweils fünf Tonnen kann wesentlich besser gearbeitet werden.
<G-vec00402-002-s460><count.werden><en> Only new devices count towards the 2,000 device threshold.
<G-vec00402-002-s460><count.werden><de> Nur neue Geräte werden für den Grenzwert von 2.000 Geräten einbezogen.
<G-vec00166-002-s197><count.zählen><en> The algorithm constantly monitors and tracks all the available trading strategies (over 1,000,000,000 at last count) to find the best fit for your profile as a trader.
<G-vec00166-002-s197><count.zählen><de> Der Algorithmus überwacht und verfolgt ständig alle verfügbaren Handelsstrategien (über 1.000.000.000.000 zuletzt gezählt), um die beste Lösung für Ihr Profil als Händler zu finden.
<G-vec00166-002-s198><count.zählen><en> I didn’t count all the islands.
<G-vec00166-002-s198><count.zählen><de> Die Inseln habe ich nicht gezählt.
<G-vec00166-002-s199><count.zählen><en> How ever, it should be known by a serious practitioner how to set, count and where it is coming from.
<G-vec00166-002-s199><count.zählen><de> Wie auch immer sollte es von einem seriösen Praktizierenden gekannt und verstanden werden, wie es festgesetzt, gezählt wird und wo es her kommt.
<G-vec00166-002-s200><count.zählen><en> The semester in which a student was enrolled in one and the same degree program; leave of absence semesters are not study semesters, but do count as semesters at university; when a student changes degree programs, it can happen that study semesters and university semesters no longer correspond.
<G-vec00166-002-s200><count.zählen><de> Fachsemester Die Semester, in denen ein Studierender in ein und demselben Studiengang immatrikuliert war; Urlaubssemester sind keine Fachsemester, werden aber als Hochschulsemester gezählt; bei einem Studienfachwechsel kann es vorkommen, dass Fachsemester und Hochschulsemester nicht mehr übereinstimmen.
<G-vec00166-002-s202><count.zählen><en> Like usual I will only count things I have shown here in 2017.
<G-vec00166-002-s202><count.zählen><de> Wie immer werden die Sachen gezählt, die ich 2017 hier im Blog gezeigt habe.
<G-vec00166-002-s203><count.zählen><en> A large golf umbrella may count as one baggage. British Airways
<G-vec00166-002-s203><count.zählen><de> Ein großer Golfregenschirm könnte als ein Gepäckstück gezählt werden.
<G-vec00166-002-s204><count.zählen><en> Attention: Orders on prepayment will only get count when they actually got paid.
<G-vec00166-002-s204><count.zählen><de> ACHTUNG: Bestellungen mit Vorkasse werden erst dann gezählt, wenn Sie auch wirklich bezahlt werden.
<G-vec00166-002-s205><count.zählen><en> For each conversion action, you can choose to count every or one conversion after each click.
<G-vec00166-002-s205><count.zählen><de> Sie können für jede Conversion-Aktion auswählen, ob alle Conversions oder nur einzelne Conversions nach jedem Klick gezählt werden sollen.
<G-vec00166-002-s206><count.zählen><en> The algorithms of your ONcoach 100 have been developed to count steps only during walking activities.
<G-vec00166-002-s206><count.zählen><de> Die Algorithmen Ihres ONcoach 100 sind so ausgelegt, dass keine Schritte gezählt werden, wenn Sie im Auto, Bus oder einem anderen Verkehrsmittel unterwegs sind.
<G-vec00166-002-s207><count.zählen><en> For any conversion action, you can choose to count every conversion that happens after a click, or only one conversion that happens after a click.
<G-vec00166-002-s207><count.zählen><de> Für jede Conversion-Aktion lässt sich festlegen, ob nach einem Klick jede oder nur eine Conversion gezählt wird.
<G-vec00166-002-s208><count.zählen><en> For the FIS Points List the average of the competitor´s 5 best results over the last 12 months will count,” adds Petr Mach, WSC Chief of Cross-country Competition.
<G-vec00166-002-s208><count.zählen><de> Für die FIS- Punkteliste werden die fünf besten Ergebnisse des Wettläufers, die er in den letzten zwölf Monaten erreicht hat, gezählt.“ fügte Petr Mach, der Manager der WM- Langläufe, hinzu.
<G-vec00166-002-s209><count.zählen><en> You'll count the ABSOLUTE VALUE, the staking power of the cards.
<G-vec00166-002-s209><count.zählen><de> Es werden die Absolutwerte der Karte gezählt, unabhängig von ihrem Zeichen.
<G-vec00166-002-s210><count.zählen><en> For example, if an actually detected intrinsic event counted with "1", a value of count may be "0.3" depending on the length of the blanking and the value assumed natural rate for each blanking time in the intended period.
<G-vec00166-002-s210><count.zählen><de> Wird beispielsweise ein tatsächlich erfasstes intrinsisches Ereignis mit "1" gezählt, kann je nach Länge der Ausblendzeiten und Wert der angenommen natürlichen Rate für jede Ausblendzeit in dem vorgesehenen Zeitraum ein Wert von "0,3" gezählt werden.
<G-vec00166-002-s211><count.zählen><en> Conversion goals allow you to specify which actions (as recorded by UET) to count as conversions.
<G-vec00166-002-s211><count.zählen><de> Mit Abschlusszielen können Sie angeben, welche (von UET erfassten) Aktionen als Abschlüsse gezählt werden.
<G-vec00166-002-s212><count.zählen><en> Both rules count the number of times that a straight line drawn from a point crosses the path on its way out of the area surrounded by a path.
<G-vec00166-002-s212><count.zählen><de> Bei beiden Regeln wird gezählt, wie oft eine von einem Punkt aus gerade gezeichnete Linie den Pfad auf ihrem Weg aus dem vom Pfad umgebenen Bereich schneidet.
<G-vec00166-002-s213><count.zählen><en> These cookies are used to count visitors to our website and to measure how the website is used
<G-vec00166-002-s213><count.zählen><de> Zweck(e): Mithilfe dieser Cookies werden die Besucher unserer Website gezählt und die Verwendungsweise gemessen.
<G-vec00166-002-s214><count.zählen><en> (The display will count down through defrosting time)
<G-vec00166-002-s214><count.zählen><de> (In der Anzeige wird die Auftauzeit herunter gezählt).
<G-vec00166-002-s215><count.zählen><en> Parameters: reference = The range of cells to count the number of cells that have a fill color.
<G-vec00166-002-s215><count.zählen><de> Parameter: reference = Der Zellbereich, in dem die Zellen mit einer Füllfarbe gezählt werden sollen.
<G-vec00166-002-s480><count.zählen><en> Once that’s done, smile into a mirror and count how many teeth you can see.
<G-vec00166-002-s480><count.zählen><de> Wenn du damit fertig bist, schau in den Spiegel, während du lächelst und zähle, wie viele Zähne sichtbar sind.
<G-vec00166-002-s481><count.zählen><en> Vladimir Putin responded to Angela Merkel's attacks at the G20 summit saying that personal friendships do not count when Russia's interests are at stake.
<G-vec00166-002-s481><count.zählen><de> Wladimir Putin hat die offene Attacke Angela Merkels beim G20-Gipfel mit den Worten kommentiert, die persönliche Freundschaft zähle nicht, sondern es gehe ihm um die Interessen Russlands.
<G-vec00166-002-s482><count.zählen><en> Count "Forty-Nine Days to the Omer" Tonight Tomorrow is the forty-ninth -- and last -- day of the Omer Count.
<G-vec00166-002-s482><count.zählen><de> Zähle “49 Tage des Omer” - heute Nacht Morgen ist der neunundvierzigste Tag des Omer-Zählens, entsprechend dem jüdischen Kalender.
<G-vec00166-002-s483><count.zählen><en> If death has power, then count on me in death to be the real Marcus Garvey that I would like to be.
<G-vec00166-002-s483><count.zählen><de> Wenn der Tod Macht hat, dann zähle darauf, dass ich im Tod der wahre Marcus Garvey bin, der ich gerne sein würde.
<G-vec00166-002-s484><count.zählen><en> Count the bacteria.
<G-vec00166-002-s484><count.zählen><de> Zähle die Bakterien.
<G-vec00166-002-s485><count.zählen><en> If you want to feel rich, just count all the things you have that money can't buy.
<G-vec00166-002-s485><count.zählen><de> Wenn Du Dich reich fühlen möchtest, zähle all die Dinge, die man für Geld nicht kaufen kann.
<G-vec00166-002-s486><count.zählen><en> I count this week-end sometimes to the top 3.
<G-vec00166-002-s486><count.zählen><de> Dieses Wochenende zähle ich mal zu den Top 3.
<G-vec00166-002-s487><count.zählen><en> Count forwards or backwards as long as you can to keep your mind focus on something other than your fear until you feel yourself dose off.
<G-vec00166-002-s487><count.zählen><de> Zähle so lange du kannst vorwärts oder rückwarts, um dich auf etwas anderes als deine Angst zu konzentrieren.
<G-vec00166-002-s488><count.zählen><en> Sit down and count the screws holding the backrest.
<G-vec00166-002-s488><count.zählen><de> Setz dich auf die Bank und zähle die Schrauben, die die Rückenlehne des Bänkleins festhalten.
<G-vec00166-002-s489><count.zählen><en> So, count it with me.
<G-vec00166-002-s489><count.zählen><de> Also zähle es mit mir.
<G-vec00166-002-s490><count.zählen><en> To find the possible number of positive roots, look at the signs on the coefficients and count the number of times the signs on the coefficients change from positive to negative or negative to positive.
<G-vec00166-002-s490><count.zählen><de> Um die Anzahl möglicher positiver Nullstellen zu bestimmen, betrachte die Vorzeichen der Koeffizienten und zähle, wie oft die Vorzeichen der Koeffizienten von positiv nach negativ oder von negativ nach positiv wechseln.
<G-vec00166-002-s491><count.zählen><en> For each letter which arises as first letter of a word of the saying, count how many words start with this letter.
<G-vec00166-002-s491><count.zählen><de> Für jeden Buchstaben, der als Anfangsbuchstabe eines Wortes des Spruches auftritt, zähle wieviele Wörter mit diesem Buchstaben beginnen.
<G-vec00166-002-s492><count.zählen><en> I count on the commitment of all authors of texts concerned in assuring the application of the norms established in this way.
<G-vec00166-002-s492><count.zählen><de> Ich zähle auf die engagierte Mitarbeit aller Beteiligten bei der konsequenten Anwendung dieser Regeln.
<G-vec00166-002-s493><count.zählen><en> Don’t count the calories, but this classic American food will leave a satisfying feeling in your stomach.
<G-vec00166-002-s493><count.zählen><de> Zähle nicht die Kalorien, aber sei dir sicher, dass du die amerikanische Küche mit einem befriedigenden Gefühl im Magen verlassen wirst.
<G-vec00166-002-s494><count.zählen><en> The steps I do not count any longer, too many are there and I am busy to keep my balance in order not to slip.
<G-vec00166-002-s494><count.zählen><de> Die Stufen zähle ich nicht mehr, zu viele sind es und ich bin damit beschäftigt mein Gleichgewicht zu halten um nicht abzurutschen.
<G-vec00166-002-s495><count.zählen><en> count 25 fat balls in a plastic bucket, and 50 pieces in a poly bag (both for the market in England).
<G-vec00166-002-s495><count.zählen><de> Zähle 25 Meisenknödel in einen Kunststoff-Eimer sowie 50 Stück in einen Polybeutel (beides für den Markt in England).
<G-vec00166-002-s496><count.zählen><en> I count myself among these latters.
<G-vec00166-002-s496><count.zählen><de> Ich zähle mich zu diesen Letzteren.
<G-vec00166-002-s497><count.zählen><en> I count a total of 21 sledges and probably as many scooters.
<G-vec00166-002-s497><count.zählen><de> Ich zähle insgesamt 21 Schlitten und etwa noch einmal so viele Skooter.
<G-vec00166-002-s498><count.zählen><en> Hold your breath, count to two, relax.
<G-vec00166-002-s498><count.zählen><de> Halte den Atem an, zähle bis zwei, entspann dich.
<G-vec00166-002-s499><count.zählen><en> Outreach services for young people remaining with their families were organised quite quickly and the thereafter families could count on specific help.
<G-vec00166-002-s499><count.zählen><de> Ambulante Pflege für die Jugendlichen, die in ihren Familien blieben, wurde schnell in die Wege geleitet, wodurch die Familien von nun an auf eine besondere Hilfe zählen konnten.
<G-vec00166-002-s500><count.zählen><en> You can count on positive reactions from visitors, because everyone looks radiant in this mirror.
<G-vec00166-002-s500><count.zählen><de> Sie können auf positive Reaktionen von Besuchern zählen, denn in diesem Spiegel sieht jeder strahlend aus.
<G-vec00166-002-s501><count.zählen><en> The main point with this task is to count only the tablets that have already been thrown into the filling tube.
<G-vec00166-002-s501><count.zählen><de> Das Prinzip ist dabei, nur die Tabletten zu zählen, die tatsächlich schon in das Füllrohr abgeworfen wurden.
<G-vec00166-002-s502><count.zählen><en> Analytical cookies: They allow us to recognise and count the number of visitors and to see how visitors move around our website when they are using it.
<G-vec00166-002-s502><count.zählen><de> Analytische Cookies: Diese Cookies ermöglichen es uns, Besucher wiederzuerkennen und zu zählen; ebenso können wir mit ihnen feststellen, welche Seiten unserer Website von den Besuchern aufgerufen werden.
<G-vec00166-002-s503><count.zählen><en> Games like progressives don’t count toward meeting the wagering requirements.
<G-vec00166-002-s503><count.zählen><de> Progressive Spiele zählen nicht für die Wettanforderungen.
<G-vec00166-002-s504><count.zählen><en> Start sightseeing the minute your bus leaves the station. If you're on the night bus from Cologne to Gotha, get comfy and count the stars.
<G-vec00166-002-s504><count.zählen><de> Wenn Sie mit dem Nachtbus von Gotha nach Frankfurt am Main unterwegs sind, sollten Sie es sich bequem machen und die Sterne am Nachthimmel zählen.
<G-vec00166-002-s505><count.zählen><en> If you're on the night bus from Elazığ to Istanbul, get comfy and count the stars. Buses are energy-efficient.
<G-vec00166-002-s505><count.zählen><de> Wenn Sie mit dem Nachtbus von Elazığ nach Istanbul unterwegs sind, sollten Sie es sich bequem machen und die Sterne am Nachthimmel zählen.
<G-vec00166-002-s506><count.zählen><en> Youll need to be able to count to play this.
<G-vec00166-002-s506><count.zählen><de> Sie müssen in der Lage sein zu zählen, um dieses Spiel.
<G-vec00166-002-s507><count.zählen><en> Cowgirl Kate is trying to count the cows but Cocoa keeps distracting her. She decides to count them herself, but is too small to see the cows on the ground, and she's also too short to see from on top of the fence.
<G-vec00166-002-s507><count.zählen><de> Cowgirl Kate versucht, die Kühe zu zählen, aber Kakao hält sie ablenkend Sie beschließt, sie selbst zu zählen, ist aber zu klein, um die Kühe auf dem Boden zu sehen, und sie ist auch zu kurz, um von oben auf den Zaun zu sehen.
<G-vec00166-002-s509><count.zählen><en> In this way we are able to recognise visitors and count them as such.
<G-vec00166-002-s509><count.zählen><de> Auf diese Weise sind wir in der Lage, Besucher voneinander zu unterscheiden und als solche zu zählen.
<G-vec00166-002-s510><count.zählen><en> The competition is enormous, especially for Swiss films, which often can’t count on well-known actors or big budgets.
<G-vec00166-002-s510><count.zählen><de> Dies macht sich insbesondere für die Schweizer Filme bemerkbar, die häufig nicht auf bekannte Schauspieler oder ein großes Budget zählen können.
<G-vec00166-002-s511><count.zählen><en> You counted on one thing, and now you can count on it no longer.
<G-vec00166-002-s511><count.zählen><de> Du zähltest auf eine Sache, und nun kannst du auf sie nicht mehr länger zählen.
<G-vec00166-002-s512><count.zählen><en> “It will be the first proof that EU leaders do not really count on the president”, concludes the Polish daily. Share Related
<G-vec00166-002-s512><count.zählen><de> "Das wird der erste Beweis dafür, dass die europäischen Staatsoberhäupter nicht wirklich auf den Präsidenten zählen", folgert die polnische Tageszeitung.
<G-vec00166-002-s513><count.zählen><en> Alongside the awarding of both IGZ founders, district administrator Wolfgang Lippert presented both IGZ founders with a gift in the form of a watercolour of the "IGZ software barns" from regional artist Rudolf Jäger from Tirschenreuth on behalf of the county and the region and was please "to be able to count a flagship company such as IGZ part of his county".
<G-vec00166-002-s513><count.zählen><de> Landrat Wolfgang Lippert überreichte im Anschluss an die Auszeichnung den beiden IGZ-Gründern stellvertretend für den Landkreis und die Region, ein Geschenk in Form eine Aquarells der „IGZ-Softwarescheunen“, des regionalen Künstlers Rudolf Jäger aus Tirschenreuth und freute sich „ein Vorzeige-Unternehmen wie die IGZ zu seinem Landkreis zählen zu dürfen“.
<G-vec00166-002-s514><count.zählen><en> The lights created by God enabled man to regularly, precisely, and clearly differentiate between night and day, and count the days, and clearly keep track of the lunar terms and years.
<G-vec00166-002-s514><count.zählen><de> Die von Gott erschaffenen Lichter, ermöglichten es den Menschen regelmäßig, präzise und eindeutig zwischen Nacht und Tag zu unterscheiden, die Tage zu zählen und die Mondphasen und Jahre klar nachzuverfolgen.
<G-vec00166-002-s515><count.zählen><en> If you're on the night bus from Lübeck to Saint-Brieuc, get comfy and count the stars.
<G-vec00166-002-s515><count.zählen><de> Wenn Sie mit dem Nachtbus von Heidelberg nach Saint-Brieuc unterwegs sind, sollten Sie es sich bequem machen und die Sterne am Nachthimmel zählen.
<G-vec00166-002-s516><count.zählen><en> If you're on the night bus from Toulouse to Venice, get comfy and count the stars.
<G-vec00166-002-s516><count.zählen><de> Wenn Sie mit dem Nachtbus von Hannover nach Venedig unterwegs sind, sollten Sie es sich bequem machen und die Sterne am Nachthimmel zählen.
<G-vec00166-002-s517><count.zählen><en> Risha - You can count on it.
<G-vec00166-002-s517><count.zählen><de> Risha - Darauf könnt Ihr zählen.
<G-vec00166-002-s536><count.zählen><en> It is a promotional race. It doesn’t count towards a championship.
<G-vec00166-002-s536><count.zählen><de> Es ist ein reines Promo-Rennen und zählt für keine Meisterschaft.
<G-vec00166-002-s537><count.zählen><en> If, without actually intending to disrobe, he makes any of the statements usually used for disrobing, it does not count as an act of disrobing.
<G-vec00166-002-s537><count.zählen><de> Wenn er, ohne wirkliche Absicht sich zu entweihen, irgend eine der Aussagen trifft, die gewöhnlich für das Entweihen verwendet werden, zählt dies nicht als eine Handlung der Entweihung.
<G-vec00166-002-s538><count.zählen><en> Moreover it is not only the careful elaboration of our tours to realise your trip with no problems, but also your special personal wishes that count for us.
<G-vec00166-002-s538><count.zählen><de> Hierzu zählt für uns nicht nur die sorgsame Ausarbeitung und reibungslose Durchführung Ihrer Reise, sondern auch Ihre besonderen persönlichen Wünsche.
<G-vec00166-002-s539><count.zählen><en> An ace counts as one or 11: If scoring an 11 would cause your hand value to exceed 21 (‘bust’), an ace will count as one.
<G-vec00166-002-s539><count.zählen><de> Ein Ass zählt einen oder 11 Punkte: Wenn 11 Punkte dazu führen würden, dass das Blatt 21 überschreitet (überkauft ist), zählt das Ass einen Punkt.
<G-vec00166-002-s540><count.zählen><en> Under Jiang regime's extermination policy that "no one will be held responsible if Falun Gong practitioners are beaten to death, just count them as suicide," the personal safety and life of Falun Gong practitioners cannot be guaranteed.
<G-vec00166-002-s540><count.zählen><de> Durch die Ausrottungspolitik von Jiangs Regime „Niemand wird zur Verantwortung gezogen, wenn Falun Gong Praktizierende tot geschlagen werden – zählt sie dann als Selbstmord“ ist die persönliche Sicherheit und das Leben eines Falun Gong Übenden nicht mehr garantiert.
<G-vec00166-002-s541><count.zählen><en> A fresh glass of orange juice or a tomato-based sauce on pasta can count as one serving each.
<G-vec00166-002-s541><count.zählen><de> Ein Glas Orangensaft oder einige Tomatensauce zählt als eine Portion jeweils zu bekommen.
<G-vec00166-002-s542><count.zählen><en> Only the room occupied by the member will count toward tier status, current Hyatt Gold Passport promotions and receive program benefits and services.
<G-vec00166-002-s542><count.zählen><de> Nur das vom Mitglied belegte Zimmer zählt in Hinblick auf Mitgliedsstatus, aktuelle Hyatt Gold Passport-Promotions sowie Programmvorteile und -leistungen.
<G-vec00166-002-s543><count.zählen><en> If e-mails, landlines and mobiles number are stored under the same name, the device will count 3 contacts.
<G-vec00166-002-s543><count.zählen><de> Wenn E-Mails, Festnetz- und Handynummern unter dem gleichen Namen gespeichert sind, zählt das Gerät 3 Kontakte.
<G-vec00166-002-s544><count.zählen><en> Your crew only has to count the quantities; we will take care of the price evaluation and look after the data.
<G-vec00166-002-s544><count.zählen><de> Ihre Crew zählt lediglich die Menge, wir kümmern uns um die Preisbewertung und Pflege der Daten.
<G-vec00166-002-s545><count.zählen><en> Having spent many years as partners in internationally focussed firms, we know that our clients count on personal relations, speed and practical skills, beyond top professional and legal competence.
<G-vec00166-002-s545><count.zählen><de> Viele Jahre als Partner in international orientierten Kanzleien haben uns gezeigt, dass für unsere Mandanten neben der fachlichen Qualifikation der persönliche Kontakt, Schnelligkeit und praktische Handlungskompetenz zählt.
<G-vec00166-002-s546><count.zählen><en> MeisterSinger manufactures unusual watches – especially made for people who don’t count the seconds.
<G-vec00166-002-s546><count.zählen><de> MeisterSinger baut besondere Uhren; für Menschen, deren Zeit nicht nach Sekunden zählt.
<G-vec00166-002-s547><count.zählen><en> Matches can be won by pinning the opponent to the mat for the count of three, making him submit, knocking him out of the ring for a predetermined count (generally twenty) or by disqualification.
<G-vec00166-002-s547><count.zählen><de> Matches kann man gewinnen, wenn man seinen Konkurrent auf der Matte hält, während der Ringrichter bis 3 zählt (Pin), ihn zur Aufgabe zwingt, der Gegner außerhalb des Ringes ausgezählt wird (Ringrichter zählt bis 10) oder durch Disqualifikation.
<G-vec00166-002-s549><count.zählen><en> The test event Driving at the Alltech FEI World Equestrian Games in Normandy 2014 started today with the dressage and an obstacle driving competition, which did not count towards the final results.
<G-vec00166-002-s549><count.zählen><de> Heute hat das Testturnier für die Vierspänner-WM bei den Weltreisterspielen in der Normandie 2014 begonnen mit der Dressur und einer Hindernisfahrprüfung, die nicht für die Kombi zählt.
<G-vec00166-002-s550><count.zählen><en> Simply a little bit farther lay also does not count.
<G-vec00166-002-s550><count.zählen><de> Einfach etwas weiter weg legen zählt auch nicht.
<G-vec00166-002-s551><count.zählen><en> Count every time someone completes a specific action, such as signing up for a newsletter or downloading a document, as a conversion.
<G-vec00166-002-s551><count.zählen><de> Zählt jeden Abschluss einer bestimmten Aktion wie das Registrieren für einen Newsletter oder das Herunterladen eines Dokuments als Abschluss.
<G-vec00166-002-s552><count.zählen><en> If a device is not managed, Lights-Out does not control it nor does it count to the number of managed and licensed devices.
<G-vec00166-002-s552><count.zählen><de> Wird ein Gerät nicht verwaltet, dann wird es von Lights-Out nicht gesteuert und zählt auch nicht zur Anzahl lizenzierter Geräte dazu.
<G-vec00166-002-s554><count.zählen><en> Foundation Round: 1ch (does not count as a st), 12dc into ring, ss to join, fasten off (12sts)
<G-vec00166-002-s554><count.zählen><de> Grundreihe: 1Lm (zählt nicht als Masche), 12fM in den Ring, schließe die Runde mit einer Km in die erste Masche.
