<G-vec00372-002-s114><color.farben><en> I also drew a boundary where one color should be separated from another (fig. 5).
<G-vec00372-002-s114><color.farben><de> Er zog die Markierungslinien auch in den Bereichen, wo die Farben voneinander abgetrennt werden mussten (Bild 5).
<G-vec00372-002-s115><color.farben><en> It has a powerful cloning brush, a tool to illuminate and darken image light sources, a color brush that allows to extract color or transparencies, and a lot more.
<G-vec00372-002-s115><color.farben><de> Es verfügt auch über ein Pinsel zum Klonen, ein Tool zum Beleuchten oder Dämmern, ein Farbpinsel, um Farben zu extrahieren und viel mehr.
<G-vec00372-002-s116><color.farben><en> Type of clothing and its own color you can choose.
<G-vec00372-002-s116><color.farben><de> Art der Kleidung und Farben können Sie wählen selbst.
<G-vec00372-002-s117><color.farben><en> The “Choose Color” window lets you pick up and set any color you want to use for the various functions, like font color, lonk color, colorize an image, etc.
<G-vec00372-002-s117><color.farben><de> Im Fenster „Farbe wählen“ können Sie beliebige Farben für die unterschiedlichen Funktionen auswählen, wie Textfarbe, Linkfarbe, Bild einfärben oder ähnliches.
<G-vec00372-002-s118><color.farben><en> At more fertile times of the year, dizzying sprays of wildflowers bloom in the plateau, igniting the panorama with a fierce color stretching as far as the eye can see.
<G-vec00372-002-s118><color.farben><de> In den fruchtbaren Zeiten des Jahres, sind die weiten Felder der Ebene ein Meer blühender Wildblumen, die das Panorama, soweit das Auge reicht, mit ihren leuchtenden Farben entflammt.
<G-vec00372-002-s119><color.farben><en> In this section, you’ll learn the role that color plays in conversion rate optimization.
<G-vec00372-002-s119><color.farben><de> In diesem Abschnitt wirst Du mehr über die Rolle von Farben bei der Optimierung der Conversion Rate erfahren.
<G-vec00372-002-s120><color.farben><en> We offer many models that vary in size and color you want.
<G-vec00372-002-s120><color.farben><de> Wir bieten viele Modelle in verschiedenen Größen und Farben an.
<G-vec00372-002-s121><color.farben><en> We welcome custom color, feel free to contact us for custom order.
<G-vec00372-002-s121><color.farben><de> Wir begrüßen kundenspezifische Farben, kontaktieren Sie uns für kundenspezifische Bestellung.
<G-vec00372-002-s122><color.farben><en> It is in green color, other colors like black, white, blue, red, and yellow and custom color available too.
<G-vec00372-002-s122><color.farben><de> Es ist in grüner Farbe, andere Farben wie schwarz, weiß, blau, rot und gelb sowie benutzerdefinierte Farben verfügbar.
<G-vec00372-002-s123><color.farben><en> Entering the main lobby will transport you back to the 60s and 70s thanks to the explosion of color and graphics on the wall.
<G-vec00372-002-s123><color.farben><de> Beim Betreten der Lobby werden Sie zurück in die 60er und 70er Jahre transportiert, dank der Explosion an Farben und Grafiken an der Wand.
<G-vec00372-002-s124><color.farben><en> Logo In general, 350's style relies more on fonts, color and content than on the logo.
<G-vec00372-002-s124><color.farben><de> Ganz allgemein setzt der Stil von 350 eher auf Schriftarten, Farben und Inhalte als auf das Logo.
<G-vec00372-002-s125><color.farben><en> Easter 3D Screensaver is an animated screensaver that will flood your PC with color and Easter tradition.
<G-vec00372-002-s125><color.farben><de> Easter 3D Screensaver ist ein animierter Bildschirmschoner, der Ihren PC mit Farben und österlichen Traditionen überfluten wird.
<G-vec00372-002-s126><color.farben><en> Add to favorites More Color Options » A-Line/Princess Knee-length Flower Girl Dress - Organza/Satin...
<G-vec00372-002-s126><color.farben><de> Zu Lieblingsartikel hinzufügen Mehr Farben zur Auswahl » A-Linie/Princess-Linie Knielang Blumenmädchenkleid -...
<G-vec00372-002-s127><color.farben><en> favor More Color Options » A-Line/Princess Sweetheart Knee-Length Tulle Homecoming Dress With...
<G-vec00372-002-s127><color.farben><de> favor Mehr Farben zur Auswahl » Duchesse-Linie Trägerlos Bodenlang Tüll Quinceañera Kleid (Kleid für...
<G-vec00372-002-s128><color.farben><en> 111) The colors in the photo do not An incorrect white balance can create unrealistic color.
<G-vec00372-002-s128><color.farben><de> Die Farben auf dem Foto passen nicht zur tatsächlichen Szene Ein falscher Weißabgleich kann zu unrealistisch wirkenden Farben führen.
<G-vec00372-002-s129><color.farben><en> It creates brilliant color, razer-sharp images, and produces an impressive, abrasion-resistant, water-proof result.
<G-vec00372-002-s129><color.farben><de> Der Drucker produziert brillante Farben, messerscharfe Bilder und ein beeindruckendes, abrieb- und wasserfestes Ergebnis.
<G-vec00372-002-s130><color.farben><en> Click on "More Colors..." to open a window where you can change the color by using the slide at the far right side of the window, or by dragging the cross on the rainbow-like color field.
<G-vec00372-002-s130><color.farben><de> Klicke auf "mehr Farben..." und Du bekommst ein Fenster, in dem Du durch den Regler ganz rechts oder durch Verschieben des Fadenkreuzes im Regenbogenfeld Farben wählen kannst.
<G-vec00372-002-s131><color.farben><en> Atomizer capacity: 3.5ml Color: Silver, Black, Red, Blue, Orange, White
<G-vec00372-002-s131><color.farben><de> Das Set ist in den Farben Schwarz, Blau, Weiß, Silber, Rot und Orange erhältlich.
<G-vec00372-002-s132><color.farben><en> Joining Tiffany in 1980, her love of strong shapes and exuberant color, both in her work and in her life, have made her an acclaimed designer and fashion icon.
<G-vec00372-002-s132><color.farben><de> Paloma Picasso kam 1980 zu Tiffany und ihre Leidenschaft für starke Formen und kräftige Farben, sowohl in ihrer Arbeit als auch in ihrem Leben, haben sie zu einer renommierten Designerin und Modeikone gemacht.
