<G-vec00430-002-s209><change.sich_verändern><en> That has an effect on their work, they change.
<G-vec00430-002-s209><change.sich_verändern><de> Das wirkt sich auf ihre Arbeit aus, sie verändern sich.
<G-vec00430-002-s210><change.sich_verändern><en> The dynamic menu options depend on the context and change according to the given possibilities within one of the modules.
<G-vec00430-002-s210><change.sich_verändern><de> Die dynamischen Menüoptionen sind abhängig vom Kontext und verändern sich entsprechend den gegebenen Möglichkeiten innerhalb eines der Module.
<G-vec00430-002-s211><change.sich_verändern><en> Even the environments like prehistoric times, Inca, Vikings, feudal Japan and industrial revolution change this time and affect the game!
<G-vec00430-002-s211><change.sich_verändern><de> Selbst die Umgebungen wie Urzeit, Inka, Wikinger, feudales Japan und die industrielle Revolution verändern sich diesmal und beeinflussen den Spielverlauf.
<G-vec00430-002-s212><change.sich_verändern><en> And sometimes, when our boundaries are respected, they soften or change.
<G-vec00430-002-s212><change.sich_verändern><de> Und manchmal, wenn unsere Grenzen respektiert werden, werden sie milder oder verändern sich.
<G-vec00430-002-s213><change.sich_verändern><en> Situations change over the years and require adaptation.
<G-vec00430-002-s213><change.sich_verändern><de> Im Laufe der Zeit verändern sich die Situationen und erfordern eine Anpassung.
<G-vec00430-002-s214><change.sich_verändern><en> In the same way, people and animals are born, grow and change during their life-times until they eventually die.
<G-vec00430-002-s214><change.sich_verändern><de> In gleicher Weise werden Menschen und Tiere geboren, sie wachsen und verändern sich während ihrer Lebenszeit, um dann schließlich zu sterben.
<G-vec00430-002-s215><change.sich_verändern><en> But people change
<G-vec00430-002-s215><change.sich_verändern><de> Aber die Menschen verändern sich.
<G-vec00430-002-s216><change.sich_verändern><en> Current laws and our practice change over time.
<G-vec00430-002-s216><change.sich_verändern><de> Geltendes Recht und unsere Verfahren verändern sich mit der Zeit.
<G-vec00430-002-s217><change.sich_verändern><en> Furthermore, proteins change: they thicken from 42°C & anyone who has ever had a fever knows what it feels like.
<G-vec00430-002-s217><change.sich_verändern><de> Weiters verändern sich Eiweiße, diese stocken ab 42°C & jeder der schon einmal Fieber hatte weiß wie sich das anfühlt.
<G-vec00430-002-s218><change.sich_verändern><en> Because IT is becoming such an integral part of products and merchandise, manufacturing industry's traditional supply chains are experiencing a fundamental change.
<G-vec00430-002-s218><change.sich_verändern><de> Weil IT zu einem festen Bestandteil von Waren und Gütern wird, verändern sich die klassischen Lieferketten in der Fertigungsindustrie fundamental.
<G-vec00430-002-s219><change.sich_verändern><en> For other set-ups and line lengths the control times will change.
<G-vec00430-002-s219><change.sich_verändern><de> Bei anderem Aufbau und anderen Leitungslängen verändern sich die Regelzeiten.
<G-vec00430-002-s220><change.sich_verändern><en> Sometimes the rooms are missing, sometimes walls fall, sometimes borders change, often people come, sometimes there is mistrust and possibly even treason.
<G-vec00430-002-s220><change.sich_verändern><de> Manchmal fehlen die Räume, manchmal fallen Mauern, manchmal verändern sich Grenzen, oft kommen Menschen dazu, manchmal gibt es Misstrauen und womöglich sogar Verrat.
<G-vec00430-002-s221><change.sich_verändern><en> As described above, capacitive and inductive reactances always change in opposite directions.
<G-vec00430-002-s221><change.sich_verändern><de> Wie oben beschrieben verändern sich kapazitiver und induktiver Blindwiderstand immer in entgegengesetzter Richtung.
<G-vec00430-002-s222><change.sich_verändern><en> Markets change continuously and enterprises must adapt permanently to stay on the wave of success.
<G-vec00430-002-s222><change.sich_verändern><de> Märkte verändern sich laufend und Unternehmen müssen sich ständig anpassen, wollen Sie auf der Erfolgswelle bleiben.
<G-vec00430-002-s223><change.sich_verändern><en> Because the etheric field is the blueprint for physical form, our own physical bodies and Gaia's physical body change when our etheric bodies change.
<G-vec00430-002-s223><change.sich_verändern><de> Weil das ätherische Feld die Blaupause für die physische Form ist, verändern sich unsere physischen Körper und auch Gaias physischer Körper wenn sich das ätherische Feld verändert.
<G-vec00430-002-s224><change.sich_verändern><en> Over time the plants and animals change, accommodating the climatic change.
<G-vec00430-002-s224><change.sich_verändern><de> Über die Zeit verändern sich die Pflanzen und Tiere und passen sich den Klimaveränderungen an.
<G-vec00430-002-s225><change.sich_verändern><en> This happens against the background of a profound social transformation of the Ruhr district, which expresses itself for example in the economic structural change as well as in the demographic and social change.
<G-vec00430-002-s225><change.sich_verändern><de> Dies geschieht vor dem Hintergrund tiefgreifender gesellschaftlicher Veränderungen in der Region: Wirtschaft, Altersaufbau und Sozialgefüge verändern sich spürbar.
<G-vec00430-002-s226><change.sich_verändern><en> Places and people change, but the tales remain the same.
<G-vec00430-002-s226><change.sich_verändern><de> Orte und Menschen verändern sich - aber die Sagen bleiben gleich.
<G-vec00430-002-s227><change.sich_verändern><en> All jobs change over time.
<G-vec00430-002-s227><change.sich_verändern><de> Alle Jobs verändern sich mit der Zeit.
<G-vec00430-002-s532><change.sich_ändern><en> The purpose for which your data shall be used will only change upon provision of your consent.
<G-vec00430-002-s532><change.sich_ändern><de> Nur mit Zustimmung ändert sich so der Nutzungszweck dieser Daten.
<G-vec00430-002-s533><change.sich_ändern><en> As with any average, the components of the Dow Jones averages change to meet economic realities – which is why they currently list Microsoft and Intel as “industrial” instead of The American Cotton Oil Company and National Lead (from 1896).
<G-vec00430-002-s533><change.sich_ändern><de> Wie bei jedem Index ändert sich auch die Zusammensetzung des Dow Jones ständig, um die Wirtschaftsrealität abzubilden – deswegen sind heute Microsoft und Intel als „Industrie“ gelistet, nicht mehr The American Cotton Oil Company und National Lead (aus dem Jahr 1896).
<G-vec00430-002-s534><change.sich_ändern><en> The price of the Futures Contracts continuously change during market trading hours and are considered to be attractive trading instruments.
<G-vec00430-002-s534><change.sich_ändern><de> Der Preis der Futures-Kontrakte ändert sich während der Handelszeiten ständig und sie gelten als höchst attraktive Trading-Instrumente.
<G-vec00430-002-s535><change.sich_ändern><en> Focusing is purely by extension, i. e. the entire lens element package is moved forward. The spacing of the individual elements does not change.
<G-vec00430-002-s535><change.sich_ändern><de> Die Scharfstellung erfolgt dabei ausschließlich über eine Verlängerung des Auszugs, d. h. das gesamte Paket der Einzellinsen wird von der Filmebene wegbewegt, und der Abstand der Linsen zueinander ändert sich nicht.
<G-vec00430-002-s536><change.sich_ändern><en> The account structure within the Eurosystem will change: liquidity will be controlled via a central account in the future.
<G-vec00430-002-s536><change.sich_ändern><de> Dabei ändert sich die Kontostruktur innerhalb des Eurosystems: Liquidität wird zukünftig über ein zentrales Konto gesteuert.
<G-vec00430-002-s537><change.sich_ändern><en> On every page the H1, H2 and H3 title color will change to the color you define here.
<G-vec00430-002-s537><change.sich_ändern><de> Auf jeder Seite ändert sich die Titelfarbe H1, H2 und H3 zu der Farbe, die Sie hier definieren.
<G-vec00430-002-s538><change.sich_ändern><en> For example, when your customer opens the document you’ve emailed them, the status under the invoice total will change from Sent to Opened.
<G-vec00430-002-s538><change.sich_ändern><de> Wenn Ihr Kunde beispielsweise das Dokument öffnet, das Sie ihm per E-Mail geschickt haben, ändert sich der Status unter dem Rechnungsbetrag von Verschickt zu Geöffnet.
<G-vec00430-002-s539><change.sich_ändern><en> The sculpture’s color and shape will change accordingly.
<G-vec00430-002-s539><change.sich_ändern><de> Die Skulptur& rsquo; s Farbe und Form ändert sich entsprechend.
<G-vec00430-002-s540><change.sich_ändern><en> In outdoor surveillance, the color temperature will change throughout the day, requiring automatic white balancing to keep color fidelity.
<G-vec00430-002-s540><change.sich_ändern><de> Bei der Außenüberwachung ändert sich die Farbtemperatur im Laufe des Tages, sodass zum Aufrechterhalten der Farbtreue ein automatischer Weißabgleich erforderlich ist.
<G-vec00430-002-s541><change.sich_ändern><en> During their lifetime, the state of technical and scientific knowledge and the nature of requirements will change.
<G-vec00430-002-s541><change.sich_ändern><de> Im Laufe ihres Lebens ändert sich der Stand der Wissenschaft und Technik, sowie diverser Anforderungen.
<G-vec00430-002-s542><change.sich_ändern><en> The battery life does not change greatly under full load, but the new processor generation allows using the laptop about 1:40 hours longer while idle.
<G-vec00430-002-s542><change.sich_ändern><de> Unter voller Last ändert sich die Laufzeit nicht großartig, im Idle-Betrieb ermöglicht die neue Prozessorengeneration circa 1:40 Stunden längere Laufzeiten.
<G-vec00430-002-s543><change.sich_ändern><en> This does not change if, for example, coconut milk is used in the sweet and sour sauce.
<G-vec00430-002-s543><change.sich_ändern><de> Das ändert sich auch nicht, wenn zum Beispiel Kokosmilch in der Süß-Sauer Sauce verwendet wird.
<G-vec00430-002-s544><change.sich_ändern><en> The ordering process itself does not change and no system modifications are required.
<G-vec00430-002-s544><change.sich_ändern><de> Der Bestellprozess selbst ändert sich für Sie nicht.
<G-vec00430-002-s545><change.sich_ändern><en> When your name is changed, an email will be sent to your registered email address, and your login name will change to the new name.
<G-vec00430-002-s545><change.sich_ändern><de> Wenn du deinen Accountnamen änderst, wird eine email an die email-Adresse, welche du beim Registrieren angegeben hast, geschickt, und es ändert sich dein Anmelde-Name.
<G-vec00430-002-s546><change.sich_ändern><en> In recent years, it has become important as a center for summer and second homes, but little by little there is a change in this behavior and the number of people who decide to stay and live motivated by the tranquility lives in the municipality, its proximity to the sea and its natural environment.
<G-vec00430-002-s546><change.sich_ändern><de> In den letzten Jahren ist es als Zentrum für Sommer- und Zweitwohnungen wichtig geworden, aber nach und nach ändert sich dieses Verhalten und die Anzahl der Menschen, die sich entscheiden, zu bleiben und von der Ruhe motiviert zu leben lebt in der Gemeinde, seine Nähe zum Meer und seiner natürlichen Umgebung.
<G-vec00430-002-s547><change.sich_ändern><en> If this happens, the status will change from Pending to Expired.
<G-vec00430-002-s547><change.sich_ändern><de> Wenn dies geschieht, ändert sich der Status von Ausstehend zu Abgelaufen.
<G-vec00430-002-s548><change.sich_ändern><en> However, when they change office, they also change their rhetoric.
<G-vec00430-002-s548><change.sich_ändern><de> Haben sie indes ein neues Amt, ändert sich ihre Rhetorik.
<G-vec00430-002-s549><change.sich_ändern><en> the symbol will change to an open padlock.
<G-vec00430-002-s549><change.sich_ändern><de> Das Symbol ändert sich in ein geöffnetes Vorhängeschloss.
<G-vec00430-002-s550><change.sich_ändern><en> The school book lists change slightly from one year to another (and even if the titles remain the same, the edition can change).
<G-vec00430-002-s550><change.sich_ändern><de> Jedes Schuljahr ändert sich die Bücherliste der Schule (und auch wenn die Titel gleich bleiben kann die Ausgabe sich ändern).
<G-vec00430-002-s228><change.verändern><en> As a trainer, coach and process facilitator, I empower young adults in times of personal and global change to unfold their gifts and potentials, reconnect with their purpose, and to do work which brings positive change to both themselves and society.
<G-vec00430-002-s228><change.verändern><de> Ich unterstütze junge Menschen in Zeiten des persönlichen und globalen Wandels als Trainerin, Coach und Prozessfaziilatorin darin, ihre Gaben und Potentiale zu entfalten, sich mit ihrem “Purpose” zu verbinden und einer Arbeit nachzugehen, die sowohl sie selbst als auch die Gesellschaft positiv verändert.
<G-vec00430-002-s229><change.verändern><en> We also reran a couple of benchmarks while running on battery power to see if the results could change.
<G-vec00430-002-s229><change.verändern><de> Wir haben auch ein paar Benchmarks im Akkubetrieb durchgeführt, um zu sehen, ob das die Ergebnisse verändert.
<G-vec00430-002-s230><change.verändern><en> Cannabis Doesn't Change The Brain.
<G-vec00430-002-s230><change.verändern><de> Cannabis verändert nicht das Gehirn.
<G-vec00430-002-s231><change.verändern><en> Mr. Sam: Well, my sound did change a lot but it has been growing up, that’s true.
<G-vec00430-002-s231><change.verändern><de> Mr. Sam: Nun ja, mein Sound hat sich schon ziemlich verändert, das ist richtig.
<G-vec00430-002-s232><change.verändern><en> There are many different reasons for the change in recent years in Polish society's overwhelmingly positive attitude towards the social transformation after 1989.
<G-vec00430-002-s232><change.verändern><de> Dass sich die überwiegend positive Einstellung der polnischen Gesellschaft gegenüber dem Gesellschaftswandel nach 1989 in den letzten Jahren verändert hat, hat vielfältige Gründe.
<G-vec00430-002-s233><change.verändern><en> An error was corrected that led to an incorrect calculation of the size of the edit box in AND/OR elements. It was not possible to select or change text anymore in this case.
<G-vec00430-002-s233><change.verändern><de> Es wurde ein Fehler im Edit-Modus behoben, der bei UND/ODER-Elementen dazu geführt hat, dass die Größe der Edit-Box nicht korrekt berechnet wurde und deswegen kein Text selektiert oder verändert werden konnte.
<G-vec00430-002-s234><change.verändern><en> In the Position group, you can change the position of your headers and / or footers.
<G-vec00430-002-s234><change.verändern><de> In der Gruppe Position kann die Position der Kopf- und der Fußzeile verändert werden.
<G-vec00430-002-s235><change.verändern><en> When it does change colour, the chances are a new long-term trend is starting
<G-vec00430-002-s235><change.verändern><de> Wenn sich die Farbe verändert, dann besteht die Chance auf einen neuen Langzeittrend.
<G-vec00430-002-s236><change.verändern><en> Trend researcher Matthias Horx is convinced that the Internet will change our future everyday life far less dramatically than has been the case in the last few years.
<G-vec00430-002-s236><change.verändern><de> Trendforscher Matthias Horx ist überzeugt, dass das Internet unseren künftigen Alltag weit weniger drastisch verändert, als es in den vergangenen Jahren der Fall war.
<G-vec00430-002-s237><change.verändern><en> Rice growing in Thailand: how a tractor can change your life.
<G-vec00430-002-s237><change.verändern><de> Thailand Reisanbau in Thailand: Wenn ein Traktor das Leben verändert.
<G-vec00430-002-s238><change.verändern><en> Our authors point out how digitalization influences us, both as individuals and as a society. They discuss the rules of a digital society and ponder how the position of humans in the workplace may change due to the profound effects of digitalization.
<G-vec00430-002-s238><change.verändern><de> Die Autoren zeigen auf, wie uns die Digitalisierung als Individuum und als Gesellschaft verändert, diskutieren die Spielregeln der digitalen Gesellschaft und fragen, wo bei den tief greifenden Einwirkungen der Digitalisierung auf die Arbeitswelt der Mensch bleibt.
<G-vec00430-002-s239><change.verändern><en> The author offers people a secret code which will dramatically change their lives from indigence and mediocrity to prosperity, royalty and abundance.
<G-vec00430-002-s239><change.verändern><de> Der Autor bietet den Menschen einen geheimen Code an, der ihr Leben dramatisch verändert, so dass ihre Bedürftigkeit und Mittelmäßigkeit sich in Wohlstand, königlichen Status und Überfluss wandelt.
<G-vec00430-002-s240><change.verändern><en> By filling in and sending off the data mask you are forwarding personal data to StrikoWestofen GmbH and giving your consent for StrikoWestofen GmbH to collect, process, store, change and use your data for the purposes of expediting your request for information.
<G-vec00430-002-s240><change.verändern><de> Mit dem Ausfüllen und Absenden der Datenmaske leiten Sie personenbezogene Daten von sich an StrikoWestofen GmbH und willigen ein, dass StrikoWestofen GmbH Ihre Daten zum Zwecke der Durchführung Ihrer Informationswünsche erhebt, verarbeitet, speichert, verändert und nutzt.
<G-vec00430-002-s241><change.verändern><en> The Social Sculpture by Joseph Beuys represents the hope that art can serve as an interdisciplinary language between nature and man and can mediate considering the existing environmental problems. Thus, art should be realisable in all spheres of life of a society and ultimately change life on earth for the better.
<G-vec00430-002-s241><change.verändern><de> Hinter der Forderung der Sozialen Plastik von Joseph Beuys steht die Hoffnung, dass die Kunst als interdisziplinäre Sprache zwischen Natur und Mensch in Bezug auf die bestehende Umweltproblematik vermitteln kann und somit die Verwirklichung in allen Lebensbereichen der Gesellschaft das Leben auf der Erde zum Positiven verändert.
<G-vec00430-002-s242><change.verändern><en> We’ll have to keep an eye out for how this progressed and continues to change the conversation around this issue.
<G-vec00430-002-s242><change.verändern><de> Wir werden beobachten, wie das weitergeht und weiterhin die Diskussion über dieses Thema verändert.
<G-vec00430-002-s243><change.verändern><en> - The Bank of Japan made a change to their stimulus strategy last night, and we will discuss that in our Market Talk article on Friday.
<G-vec00430-002-s243><change.verändern><de> - Die Bank of Japan hat ihre Stimulus-Strategie letzte Nacht verändert, und wir werden darüber ausführlich in unserem Market Talk Artikel vom Freitag sprechen.
<G-vec00430-002-s244><change.verändern><en> But since the gross end price will not change there is no change in consumer behavior to be expected in the long run.
<G-vec00430-002-s244><change.verändern><de> Da sich aber der Bruttopreis nicht verändert, ist eine Veränderung des Konsumverhaltens der Bevölkerung mittelfristig nicht zu erwarten.
<G-vec00430-002-s245><change.verändern><en> You change your past continually.
<G-vec00430-002-s245><change.verändern><de> Ihr verändert dauernd eure Vergangenheit.
<G-vec00430-002-s246><change.verändern><en> Around 140,000 people live in this collection of old buildings over eleven square kilometers, and no other area has undergone as much change as this East Berlin district since the fall of the wall. In the middle of all this, a green mobile telescopic crane is in operation.
<G-vec00430-002-s246><change.verändern><de> Rund 140.000 Menschen leben in diesem elf Quadratkilometer großen Altbauensemble und kein Stadtteil hat sich seit dem Mauerfall wohl so schnell verändert wie das Ost-Berliner Viertel - mitten drin arbeitet ein grüner Mobilteleskopkran.
<G-vec00430-002-s342><change.wechseln><en> And, with KeyDepot, it’s also no longer a problem to regularly change your passwords.
<G-vec00430-002-s342><change.wechseln><de> Mit KeyDepot ist es auch kein Problem, die Passwörter regelmäßig zu wechseln.
<G-vec00430-002-s343><change.wechseln><en> "Combined training", when during the aerobic session you change to different cardio equipment.
<G-vec00430-002-s343><change.wechseln><de> "Kombiniertes Training", wenn Sie während der Aerobic-Sitzung zu verschiedenen Cardio-Geräten wechseln.
<G-vec00430-002-s344><change.wechseln><en> Most of the brands will change from ego promotion to consumer orientation; tell a story, convey an idea instead of selling a product via price promotions.
<G-vec00430-002-s344><change.wechseln><de> Die meisten Marken werden von „Ego“ Promotion zu kundenorientieren Marketing wechseln; eine Geschichte erzählen, Ideen übermitteln statt das Produkt über Preispromotions zu vertreiben.
<G-vec00430-002-s345><change.wechseln><en> It is simply wrong to believe it is possible to just wait three months and then in return change more than half of the water.
<G-vec00430-002-s345><change.wechseln><de> Es ist einfach falsch zu glauben, man könne ruhig drei Monate warten und dafür dann eben mehr als die Hälfte des Wassers wechseln.
<G-vec00430-002-s346><change.wechseln><en> They can go months without food by slowing down their metabolism, consecutive nesting seasons, and even change nesting beaches in response to stress.
<G-vec00430-002-s346><change.wechseln><de> Sie können Monate ohne Nahrung auskommen, ihren Stoffwechsel verlangsamen, aufeinanderfolgende Brutzeiten und sogar als Reaktion auf Stress die Brutstrände wechseln.
<G-vec00430-002-s347><change.wechseln><en> The exhibition's features as well as the accompanying workshops on subjects such as language, home or travel raise the children's awareness for the subject of diversity—they change their perspective and become visionaries.
<G-vec00430-002-s347><change.wechseln><de> Die Ausstellungsangebote und begleitenden Workshops zu Themen wie Sprache, Heimat oder Reisen sensibilisieren Kinder für das Thema Vielfalt – sie wechseln die Perspektive, werden zu Visionären.
<G-vec00430-002-s348><change.wechseln><en> Of course, they may call upon your expertise, but you shouldn’t assume that you’re going to tell them how to do every last thing, from how to change a diaper to how to help their child grow into a responsible adult.
<G-vec00430-002-s348><change.wechseln><de> Selbstverständlich machen sie sich vielleicht dein Expertenwissen zunutze, aber du solltest nicht davon ausgehen, dass du ihnen vom Wechseln einer Windel bis zum Erziehen ihres Kindes in einen verantwortungsbewussten Erwachsenen alles erzählen wirst.
<G-vec00430-002-s349><change.wechseln><en> Use filters to change location or to narrow results for Lexus cars in UAE.
<G-vec00430-002-s349><change.wechseln><de> Verwenden Sie Filter, um Standort zu wechseln oder um die Ergebnisse für Lexus cars einzugrenzen.
<G-vec00430-002-s350><change.wechseln><en> And one young man had to change his clothes several times, because he played two or three different parts, but the same person.
<G-vec00430-002-s350><change.wechseln><de> Ein junger Mann musste seine Kleidung einige Male wechseln, weil er zwei oder drei verschiedene Rollen zu spielen hatte - doch es war immer die gleiche Person.
<G-vec00430-002-s351><change.wechseln><en> Use filters to change location or to narrow results for agricultural vehicle in Riyadh Saudi Arabia.
<G-vec00430-002-s351><change.wechseln><de> Verwenden Sie Filter, um Standort zu wechseln oder um die Ergebnisse für Chrysler cars in Riyadh Saudi Arabien einzugrenzen.
<G-vec00430-002-s352><change.wechseln><en> To determine whether this is the cause of the error message, update or change the printer driver.
<G-vec00430-002-s352><change.wechseln><de> Ob das der Fall ist, können Sie feststellen, indem Sie den Druckertreiber aktualisieren oder wechseln.
<G-vec00430-002-s353><change.wechseln><en> We are not printed circuit boards change, but find the defective component and change it, with low costs as a result.
<G-vec00430-002-s353><change.wechseln><de> Wir wechseln nicht nur Leiterplatten aus, sondern ermitteln die defekten Komponenten und ersetzen sie, um die Kosten auf ein Minimum zu begrenzen.
<G-vec00430-002-s354><change.wechseln><en> Use filters to change location or to narrow results for Ferrari cars in Netherlands.
<G-vec00430-002-s354><change.wechseln><de> Verwenden Sie Filter, um Standort zu wechseln oder um die Ergebnisse für Ferrari cars in Niederlande einzugrenzen.
<G-vec00430-002-s355><change.wechseln><en> “The situation is strange because the ribs are not too bad but the collarbone is the big problem, I don’t have power in the arm and I can’t change direction on the bike.
<G-vec00430-002-s355><change.wechseln><de> "Die Situation ist seltsam, denn die Rippen sind nicht allzu schlecht, aber das Schlüsselbein ist ein großes Problem Ich habe keine Kraft im Arm und ich kann auf dem Bike die Richtung nicht wechseln.
<G-vec00430-002-s356><change.wechseln><en> Speed is of the essence when the machine’s operator needs to set up a tool, inspect a punch, or change the metal sheet for a special order. To make this possible, all the critical positions at the TruMatic 6000 fiber are easily accessible.
<G-vec00430-002-s356><change.wechseln><de> Damit der Maschinenbediener schnell ein Werkzeug rüsten, einen Stempel prüfen oder für einen Sonderauftrag ein Blech wechseln kann, sind alle entscheidenden Stellen an der TruMatic 6000 fiber leicht zugänglich – so als wäre keine Schutz-Umhausung vorhanden.
<G-vec00430-002-s357><change.wechseln><en> The SCHIRN exhibitions change, but the MINISCHIRN remains.
<G-vec00430-002-s357><change.wechseln><de> Die Ausstellungen in der Schirn wechseln, die MINISCHIRN bleibt.
<G-vec00430-002-s358><change.wechseln><en> To apply it, change into the Drupal base directory and issue patch -p0<drupalwotemptables.patch on the commandline.
<G-vec00430-002-s358><change.wechseln><de> Um ihn anzuwenden ins Basisverzeichnis wechseln und patch -p0<drupalwotemptables.patch ausführen.
<G-vec00430-002-s359><change.wechseln><en> As you move to change lane, the system issues a visual warning signal in the... Les mer
<G-vec00430-002-s359><change.wechseln><de> Wechseln Sie die Fahrspur, informiert Sie das System durch ein optisches Signal in den...
<G-vec00430-002-s360><change.wechseln><en> Trade like a mercenary guerrilla. We must fight on the winning side and be willing to change sides readily when one side has gained the upper hand.
<G-vec00430-002-s360><change.wechseln><de> Man muss sich auf die Gewinner-Seite schlagen und bereit sein, jederzeit von „Kaufen“ zu „Verkaufen“ zu wechseln oder umgekehrt, wenn die andere Seite die Oberhand gewonnen hat.
<G-vec00430-002-s513><change.ändern><en> If you would like Paylobby to change your personal data or no longer use your data, you can contact Paylobby at info@paylobby.com.
<G-vec00430-002-s513><change.ändern><de> Wenn Sie möchten, dass Paylobby Ihre personenbezogenen Daten ändert oder Ihre Daten nicht mehr nutzt, können Sie Paylobby unter info@paylobby.com kontaktieren.
<G-vec00430-002-s514><change.ändern><en> This price will be used only for customers on Windows 10 (including Xbox) in the selected market. If you enter a free-form price, that price will not be adjusted (even if conversion rates change) unless you submit an update with a new price.
<G-vec00430-002-s514><change.ändern><de> Durch einen formfreien Preis wird der Preis nur angepasst (auch wenn sich der Umrechnungskurs ändert), wenn Sie ein Update mit einem neuen Preis übermitteln.Grundpreise für mehrere Märkte zu überschreiben, erstellen Sie eine Marktgruppe.To override the base price for multiple markets, you’ll create a market group.
<G-vec00430-002-s515><change.ändern><en> They can be easily added later if needs change.
<G-vec00430-002-s515><change.ändern><de> Sie können leicht später addiert werden, wenn Bedarf ändert.
<G-vec00430-002-s516><change.ändern><en> Ordered on request within 4 days Screen protector - 100% protection against scratches, lifetime warranty, extreme durability and full transparency, does not change the colours of the display, makes your...
<G-vec00430-002-s516><change.ändern><de> Auf Bestellung innerhalb von 4 Arbeitstagen Schutzfolie - 100% Garantie gegen Kratzer, lebenslange Garantie, extreme Widerstandsfähigkeit und volle Transparenz, die Folie ändert nicht die Farben des Displays, das Display...
<G-vec00430-002-s517><change.ändern><en> It is safe because Start Menu 7 does not change your system!
<G-vec00430-002-s517><change.ändern><de> Dies ist ein absolut sicherer Vorgang, denn Start Menu 7 ändert keine Systemeinstellungen.
<G-vec00430-002-s518><change.ändern><en> If checked, changes in ACL are detected even when the file body does not change.
<G-vec00430-002-s518><change.ändern><de> Wenn diese Option aktiviert ist, werden Änderungen in ACL auch dann erkannt, wenn sich der Dateikörper nicht ändert.
<G-vec00430-002-s519><change.ändern><en> FIXED: When this setting is selected, the television audio through the AUDIO OUT jacks does not change How do I watch subscribed services using a smart card module?Table of contents: 1.
<G-vec00430-002-s519><change.ändern><de> FIXED (FEST): Wenn diese Einstellung gewählt wird, ändert sich der Ton des Fernsehers über die AUDIO OUT-Buchsen nicht, wenn die Lautstärkentasten der Fernbedienung des Fernsehers gedrückt werden.
<G-vec00430-002-s520><change.ändern><en> Not even Tomboy could change anything about that.
<G-vec00430-002-s520><change.ändern><de> An all dem ändert auch Tomboy nichts.
<G-vec00430-002-s521><change.ändern><en> Sometimes a package will change its section.
<G-vec00430-002-s521><change.ändern><de> Manchmal ändert ein Paket seinen Bereich.
<G-vec00430-002-s522><change.ändern><en> Check to see if someone's voice changes, or if they suddenly change their body language.
<G-vec00430-002-s522><change.ändern><de> Überprüfe, ob jemand seine Stimme ändert, oder ob sich plötzlich die Körpersprache ändert.
<G-vec00430-002-s523><change.ändern><en> For a public page, the Browse page permission doesn't change anything to the access security of that page because it is already accessible by anybody who has access to the domain.
<G-vec00430-002-s523><change.ändern><de> Bei einer öffentlichen Seite ändert die Berechtigung Seite durchsuchen nichts an der Zugriffssicherheit dieser Seite, da sie bereits für jeden zugänglich ist, der Zugriff auf die Domain hat.
<G-vec00430-002-s524><change.ändern><en> Whatever obstruction he manifests, he does not change the nature of life.
<G-vec00430-002-s524><change.ändern><de> Was immer an Versperrung er manifestiert, er ändert die Natur des Lebens nicht.
<G-vec00430-002-s525><change.ändern><en> It doesn’t change your IP and doesn’t encrypt your connection like VPN but offers better speed when watching video content.
<G-vec00430-002-s525><change.ändern><de> Es ändert Ihre IP-Adresse nicht und verschlüsselt Ihre Verbindung nicht wie VPN, bietet jedoch eine höhere Internetgeschwindigkeit beim Anschauen von Videoinhalten.
<G-vec00430-002-s526><change.ändern><en> Description Action controls trigger actions when the states of Rocrail objects change.
<G-vec00430-002-s526><change.ändern><de> Beschreibung Aktionssteuerungen lösen Aktionen aus, wenn sich der Status von Rocrail-Objekten ändert.
<G-vec00430-002-s527><change.ändern><en> If after a predetermined number of CK4 clock cycles a framing signal is not detected. then counter 850 will cause mux control logic 848 to change the phase of CK4 using mux 828 (FIG.
<G-vec00430-002-s527><change.ändern><de> Falls nach einer vorbestimmten Anzahl von CK4-Taktzyklen ein Rahmensignal nicht detektiert wird, dann bewirkt der Zähler 850, dass die MUX-Steuerlogik 848 die Phase des CK4 unter Verwendung des MUX 828 ändert (8).
<G-vec00430-002-s528><change.ändern><en> The possible effects of an electromagnetic field change with increasing frequency.
<G-vec00430-002-s528><change.ändern><de> Das elektromagnetische Feld ändert seine möglichen Wirkungen mit höher werdender Frequenz.
<G-vec00430-002-s529><change.ändern><en> The online gambling industry has been waiting for the technology to change the payment procedure at online casinos.
<G-vec00430-002-s529><change.ändern><de> Die Online-Glücksspielindustrie hat darauf gewartet, dass die Technologie das Zahlungsverfahren in den Online-Casinos ändert.
<G-vec00430-002-s530><change.ändern><en> You can also change music by adding effects for listening or recording to a new file.
<G-vec00430-002-s530><change.ändern><de> Er ändert ebenfalls die Stimme der Musik, fügt neuen Dateien Effekte für Hören oder Aufnehmen zu.
<G-vec00430-002-s531><change.ändern><en> Battle Bears Royale, a team based third-person shooter action game for Android, will change the way you think about teddy bears.
<G-vec00430-002-s531><change.ändern><de> Battle Bears Royale, ein teambasierter Third-Person-Shooter Actionspiel für Android, ändert wie Sie über Teddybären denken.
<G-vec00590-002-s323><change.wechseln><en> At the same time, because the material of the product has these properties, the quality is still the same as new with the change of years, so it is not necessary to worry about the traces left on the surface of the floor by years.
<G-vec00590-002-s323><change.wechseln><de> Da das Material des Produkts diese Eigenschaften aufweist, ist die Qualität mit dem Wechsel der Jahre immer noch dieselbe wie neu, sodass Sie sich nicht um die Spuren kümmern müssen, die jahrelang auf der Oberfläche des Bodens hinterlassen wurden.
<G-vec00590-002-s324><change.wechseln><en> We consult our clients at annual shareholders' meetings and in the case of a change of management as well as in liability suits of shareholders, directors and managing directors.
<G-vec00590-002-s324><change.wechseln><de> Wir beraten bei Gesellschafter- und Hauptversammlungen, beim Wechsel der Unternehmensleitung, bei der Haftung von Gesellschaftern, Vorständen und Geschäftsführern.
<G-vec00590-002-s325><change.wechseln><en> There is no daily cleaning but a weekly change of bed linen and towels.
<G-vec00590-002-s325><change.wechseln><de> Es gibt keine tägliche Reinigung, sondern ein wöchentlicher Wechsel der Bettwäsche und Handtücher.
<G-vec00590-002-s326><change.wechseln><en> The change of legal owner of a .irish to Infomaniak is immediate.
<G-vec00590-002-s326><change.wechseln><de> Der Wechsel des gesetzlichen Inhabers einer .film-Domain zu Infomaniak ist umgehend wirksam.
<G-vec00590-002-s327><change.wechseln><en> A cleaning service, bathroom linen change every 4 days and bed linen change every 8 days are offered.
<G-vec00590-002-s327><change.wechseln><de> Ein Reinigungsservice, Handtuchwechsel alle 4 Tage und Wechsel der Bettwäsche alle 8 Tage werden angeboten.
<G-vec00590-002-s328><change.wechseln><en> Full pH changes pH changes according USP method A (half change) and method B (full change), with measurement in each vessel.
<G-vec00590-002-s328><change.wechseln><de> pH-Wechsel in Übereinstimmung mit USP Methode A (halber Wechsel) und USP Methode B (ganzer Wechsel), inklusive Messung in jedem Prüfbehälter.
<G-vec00590-002-s330><change.wechseln><en> The change of legal owner of a .net.co to Infomaniak is immediate.
<G-vec00590-002-s330><change.wechseln><de> Der Wechsel des gesetzlichen Inhabers einer .net.co-Domain zu Infomaniak ist umgehend wirksam.
<G-vec00590-002-s331><change.wechseln><en> I currently reside in the country which I truthfully and accurately indicated in the form provided to register into imeetzu webcam chat and undertake the duty to immediately inform, within 24 hours, of any change of residence by sending an email to .
<G-vec00590-002-s331><change.wechseln><de> Ich wohne gegenwärtig in dem Land, welches ich wahrheitsgemäß und korrekt in dem Formular zur Registrierung bei imeetzu webcam chat angegeben habe und ich verpflichte mich, jeden Wechsel des Wohnorts unmittelbar, innerhalb von 24 Stunden, mittels Senden einer E-Mail an zu melden.
<G-vec00590-002-s332><change.wechseln><en> The unit change is confirmed a few seconds after you stop pressing the button. Related articles
<G-vec00590-002-s332><change.wechseln><de> Der Wechsel der Einheit wird ein paar Sekunden nachdem Sie aufgehört haben, den Knopf zu drücken, bestätigt.
<G-vec00590-002-s333><change.wechseln><en> After a change to the Register “Sensors” get the current measured values appear in addition to temperature, the clock frequency of the GPU and the memory, the speed of the fan in percent, the utilization of graphics memory and Chip, as well as the applied voltage.
<G-vec00590-002-s333><change.wechseln><de> Nach einem Wechsel zum Register „Sensors“ bekommen Sie die aktuellen Messwerte angezeigt, neben der Temperatur sind das die Taktfrequenz von GPU und Speicher, die Geschwindigkeit des Ventilators in Prozent, die Auslastung von Grafikspeicher und Chip sowie die anliegende Spannung.
<G-vec00590-002-s334><change.wechseln><en> They were all amazed and somewhat terror-stricken by the sudden change in the Master’s teaching tactics.
<G-vec00590-002-s334><change.wechseln><de> Sie waren alle verwundert und ziemlich in Schrecken versetzt über den plötzlichen Wechsel in der Unterweisungstaktik des Meisters.
<G-vec00590-002-s335><change.wechseln><en> It is easy to change from a piano accordion to a piano or a keyboard.
<G-vec00590-002-s335><change.wechseln><de> Der Wechsel vom Piano-Akkordeon zum Klavier oder Keyboard ist leicht zu bewerkstelligen.
<G-vec00590-002-s336><change.wechseln><en> A coach service also exists between Biarritz airport and the Hendaye train station, via Saint-Jean-De-Luz (change buses there).
<G-vec00590-002-s336><change.wechseln><de> Ein Bus Service existiert auch zwischen Biarritz Flughafen und der Hendaye Zug Station, via Saint Jean De Luz (wechsel Busse dort).
<G-vec00590-002-s337><change.wechseln><en> Easy and fast change between Universal and SMART-columns by fitting an adapter.
<G-vec00590-002-s337><change.wechseln><de> Einfacher und schneller Wechsel zwischen Universal- und SMART-Säulen durch Einklicken eines Adapters.
<G-vec00590-002-s338><change.wechseln><en> bed linen and towles with weekly change, final cleaning, water, gas, use of the barbecue and the washing machine.
<G-vec00590-002-s338><change.wechseln><de> Bettwäsche und Handtücher mit wöchentlichem Wechsel, Endreinigung, Wasser, Gas, Benutzung des Barbecues und der Waschmaschine, WLan.
<G-vec00590-002-s339><change.wechseln><en> AQUACEL® Burn dressings offer wear times of up to 21 days (or until change is clinically indicated) and gently detach from the burn wound as it dries and heals.
<G-vec00590-002-s339><change.wechseln><de> AQUACEL® Ag Burn Verbände bieten eine Tragedauer von bis zu 21 Tagen (oder bis ein Wechsel klinisch indiziert ist) und eine sanfte Ablösung von der Brandwunde, sobald diese trocknet und verheilt.
<G-vec00590-002-s340><change.wechseln><en> The cooling and power consumption as well as the speed benefit from the change from the Kepler to the Maxwell architecture (does not apply to all new GPUs).
<G-vec00590-002-s340><change.wechseln><de> Der Wechsel von der Kepler- auf die Maxwell-Architektur (betrifft nicht alle neuen GPUs) kommt sowohl der Kühlung und dem Strombedarf als auch der Geschwindigkeit zugute.
<G-vec00590-002-s341><change.wechseln><en> Weekly cleaning and change of bed linen and towels are included for stays longer than 10 nights.
<G-vec00590-002-s341><change.wechseln><de> Bei einem Aufenthalt von mehr als 10 Nächten sind der wöchentliche Reinigungsservice sowie der Wechsel von Bettwäsche und Handtüchern inbegriffen.
<G-vec00590-002-s532><change.ändern><en> The purpose for which your data shall be used will only change upon provision of your consent.
<G-vec00590-002-s532><change.ändern><de> Nur mit Zustimmung ändert sich so der Nutzungszweck dieser Daten.
<G-vec00590-002-s533><change.ändern><en> As with any average, the components of the Dow Jones averages change to meet economic realities – which is why they currently list Microsoft and Intel as “industrial” instead of The American Cotton Oil Company and National Lead (from 1896).
<G-vec00590-002-s533><change.ändern><de> Wie bei jedem Index ändert sich auch die Zusammensetzung des Dow Jones ständig, um die Wirtschaftsrealität abzubilden – deswegen sind heute Microsoft und Intel als „Industrie“ gelistet, nicht mehr The American Cotton Oil Company und National Lead (aus dem Jahr 1896).
<G-vec00590-002-s534><change.ändern><en> The price of the Futures Contracts continuously change during market trading hours and are considered to be attractive trading instruments.
<G-vec00590-002-s534><change.ändern><de> Der Preis der Futures-Kontrakte ändert sich während der Handelszeiten ständig und sie gelten als höchst attraktive Trading-Instrumente.
<G-vec00590-002-s535><change.ändern><en> Focusing is purely by extension, i. e. the entire lens element package is moved forward. The spacing of the individual elements does not change.
<G-vec00590-002-s535><change.ändern><de> Die Scharfstellung erfolgt dabei ausschließlich über eine Verlängerung des Auszugs, d. h. das gesamte Paket der Einzellinsen wird von der Filmebene wegbewegt, und der Abstand der Linsen zueinander ändert sich nicht.
<G-vec00590-002-s536><change.ändern><en> The account structure within the Eurosystem will change: liquidity will be controlled via a central account in the future.
<G-vec00590-002-s536><change.ändern><de> Dabei ändert sich die Kontostruktur innerhalb des Eurosystems: Liquidität wird zukünftig über ein zentrales Konto gesteuert.
<G-vec00590-002-s537><change.ändern><en> On every page the H1, H2 and H3 title color will change to the color you define here.
<G-vec00590-002-s537><change.ändern><de> Auf jeder Seite ändert sich die Titelfarbe H1, H2 und H3 zu der Farbe, die Sie hier definieren.
<G-vec00590-002-s538><change.ändern><en> For example, when your customer opens the document you’ve emailed them, the status under the invoice total will change from Sent to Opened.
<G-vec00590-002-s538><change.ändern><de> Wenn Ihr Kunde beispielsweise das Dokument öffnet, das Sie ihm per E-Mail geschickt haben, ändert sich der Status unter dem Rechnungsbetrag von Verschickt zu Geöffnet.
<G-vec00590-002-s539><change.ändern><en> The sculpture’s color and shape will change accordingly.
<G-vec00590-002-s539><change.ändern><de> Die Skulptur& rsquo; s Farbe und Form ändert sich entsprechend.
<G-vec00590-002-s540><change.ändern><en> In outdoor surveillance, the color temperature will change throughout the day, requiring automatic white balancing to keep color fidelity.
<G-vec00590-002-s540><change.ändern><de> Bei der Außenüberwachung ändert sich die Farbtemperatur im Laufe des Tages, sodass zum Aufrechterhalten der Farbtreue ein automatischer Weißabgleich erforderlich ist.
<G-vec00590-002-s541><change.ändern><en> During their lifetime, the state of technical and scientific knowledge and the nature of requirements will change.
<G-vec00590-002-s541><change.ändern><de> Im Laufe ihres Lebens ändert sich der Stand der Wissenschaft und Technik, sowie diverser Anforderungen.
<G-vec00590-002-s542><change.ändern><en> The battery life does not change greatly under full load, but the new processor generation allows using the laptop about 1:40 hours longer while idle.
<G-vec00590-002-s542><change.ändern><de> Unter voller Last ändert sich die Laufzeit nicht großartig, im Idle-Betrieb ermöglicht die neue Prozessorengeneration circa 1:40 Stunden längere Laufzeiten.
<G-vec00590-002-s543><change.ändern><en> This does not change if, for example, coconut milk is used in the sweet and sour sauce.
<G-vec00590-002-s543><change.ändern><de> Das ändert sich auch nicht, wenn zum Beispiel Kokosmilch in der Süß-Sauer Sauce verwendet wird.
<G-vec00590-002-s544><change.ändern><en> The ordering process itself does not change and no system modifications are required.
<G-vec00590-002-s544><change.ändern><de> Der Bestellprozess selbst ändert sich für Sie nicht.
<G-vec00590-002-s545><change.ändern><en> When your name is changed, an email will be sent to your registered email address, and your login name will change to the new name.
<G-vec00590-002-s545><change.ändern><de> Wenn du deinen Accountnamen änderst, wird eine email an die email-Adresse, welche du beim Registrieren angegeben hast, geschickt, und es ändert sich dein Anmelde-Name.
<G-vec00590-002-s546><change.ändern><en> In recent years, it has become important as a center for summer and second homes, but little by little there is a change in this behavior and the number of people who decide to stay and live motivated by the tranquility lives in the municipality, its proximity to the sea and its natural environment.
<G-vec00590-002-s546><change.ändern><de> In den letzten Jahren ist es als Zentrum für Sommer- und Zweitwohnungen wichtig geworden, aber nach und nach ändert sich dieses Verhalten und die Anzahl der Menschen, die sich entscheiden, zu bleiben und von der Ruhe motiviert zu leben lebt in der Gemeinde, seine Nähe zum Meer und seiner natürlichen Umgebung.
<G-vec00590-002-s547><change.ändern><en> If this happens, the status will change from Pending to Expired.
<G-vec00590-002-s547><change.ändern><de> Wenn dies geschieht, ändert sich der Status von Ausstehend zu Abgelaufen.
<G-vec00590-002-s548><change.ändern><en> However, when they change office, they also change their rhetoric.
<G-vec00590-002-s548><change.ändern><de> Haben sie indes ein neues Amt, ändert sich ihre Rhetorik.
<G-vec00590-002-s549><change.ändern><en> the symbol will change to an open padlock.
<G-vec00590-002-s549><change.ändern><de> Das Symbol ändert sich in ein geöffnetes Vorhängeschloss.
<G-vec00590-002-s550><change.ändern><en> The school book lists change slightly from one year to another (and even if the titles remain the same, the edition can change).
<G-vec00590-002-s550><change.ändern><de> Jedes Schuljahr ändert sich die Bücherliste der Schule (und auch wenn die Titel gleich bleiben kann die Ausgabe sich ändern).
