<G-vec01130-002-s028><bury.beerdigen><en> An ancient chant recounts how Wakea (the god of the sky) had to bury his first son because the child was born as a shapeless mass.
<G-vec01130-002-s028><bury.beerdigen><de> Ein sehr alter Gesang berichtet uns, wie Wakea (der Gott des Himmels) seinen ersten Sohn beerdigen musste, weil das Kind als formlose Masse geboren wurde.
<G-vec01130-002-s029><bury.beerdigen><en> When the film by Hajo Seppelt was broadcast on ARD, they sent all dirty, extremely dirty biological passport of skiers and biathletes to RUSADA with only one purpose: to bury them.”
<G-vec01130-002-s029><bury.beerdigen><de> Als der Film von Hajo Seppelt in der ARD ausgestrahlt wurde, haben sie die dreckigen, extrem dreckigen Pässe an die russische Anti-Dopingagentur geschickt – mit nur einem Ziel: diese Fälle zu beerdigen.“ Sollten allein diese Vorwürfe sich bewahrheiten, wäre dies ein dramatischer Fall der Vertuschung.
<G-vec01130-002-s030><bury.beerdigen><en> If you can help us bring in the corpses, at least we can bury them.
<G-vec01130-002-s030><bury.beerdigen><de> Wenn Ihr uns helfen könnt, die Leichen zurückzuholen, können wir sie wenigstens beerdigen.
<G-vec01130-002-s031><bury.beerdigen><en> Either taking you out of your coffin or through your coffin they should bury you.
<G-vec01130-002-s031><bury.beerdigen><de> Entweder nehmen sie dich aus dem Sarg heraus, oder sie beerdigen dich in deinem Sarg.
<G-vec01130-002-s032><bury.beerdigen><en> She carried everywhere with her a tiny dead child and lived in a world of dreams until it started to decompose, and the young mother did not understand that it was necessary to bury him.
<G-vec01130-002-s032><bury.beerdigen><de> Sie trug mit sich das kleine tote Kind und lebte in einer Welt von Träumereien, bis es zu zerlegen begann und die junge Mutter verstand, dass sie es beerdigen muss.
<G-vec01130-002-s033><bury.beerdigen><en> Despite all the unfortunately justified criticism that is being made, no one, not even the Venice Commission of the Council of Europe, is saying that Turkey’s referendum will effectively bury its democracy.
<G-vec01130-002-s033><bury.beerdigen><de> Dass die Türkei mit dem Referendum ihre Demokratie beerdigt, sagt bei aller leider allzu berechtigten Kritik nicht mal die Venedig-Kommission des Europarats.
<G-vec01130-002-s034><bury.beerdigen><en> In both areas there are natural caves where primitive tribes used to lived and bury their dead.
<G-vec01130-002-s034><bury.beerdigen><de> Beide Orte besitzen natürliche Höhlen, wo früher primitive Stämme wohnten und ihre Toten beerdigten.
<G-vec01130-002-s210><bury.beerdigen><en> For example, police should be aware that a Muslim family would expect to bury their kin as soon as possible after death, preferably within 24 hours.
<G-vec01130-002-s210><bury.beerdigen><de> Beispielsweise sollten Polizisten wissen, dass eine muslimische Familie erwartet, verstorbene Angehörige so rasch wie möglich nach dem Todeszeitpunkt beerdigen zu können, vorzugsweise innerhalb von 24 Stunden.
<G-vec01130-002-s037><bury.begraben><en> 5 My father made me swear, saying, Lo, I die: in my grave which I have digged for me in the land of Canaan, there shalt thou bury me.
<G-vec01130-002-s037><bury.begraben><de> 5 Mein Vater hat einen Eid von mir genommen und gesagt: Siehe, ich sterbe; begrabe mich in meinem Grabe, das ich mir im Lande KanaanKanaan gegraben habe.
<G-vec01130-002-s038><bury.begraben><en> Now therefore let me go up, I pray thee, and bury my father, and I will come again.
<G-vec01130-002-s038><bury.begraben><de> Und nun laß mich doch hinaufziehen, daß ich meinen Vater begrabe und ich will zurückkommen.
<G-vec01130-002-s039><bury.begraben><en> 8 And he said unto the queen: He is not dead, but he sleepeth in God, and on the morrow he shall rise again; therefore bury him not.
<G-vec01130-002-s039><bury.begraben><de> 8 Und er sprach zur Königin: Er ist nicht tot, sondern er schläft in Gott, und morgen wird er sich wieder erheben; darum begrabe ihn nicht.
<G-vec01130-002-s040><bury.begraben><en> For my father made me swear to him, saying: Behold I die: thou shalt bury me in my sepulchre which I have digged for myself in the land of Chanaan.
<G-vec01130-002-s040><bury.begraben><de> 5Mein Vater hat einen Eid von mir genommen und gesagt: Siehe, ich sterbe; begrabe mich in meinem Grabe, das ich mir im Lande Kanaan gegraben habe.
<G-vec01130-002-s041><bury.begraben><en> 21 Another of his disciples said to him, 'Lord, allow me first to go and bury my father.'
<G-vec01130-002-s041><bury.begraben><de> 21Und ein anderer unter den Jüngern sprach zu ihm: Herr, erlaube mir, dass ich zuvor hingehe und meinen Vater begrabe.
<G-vec01130-002-s042><bury.begraben><en> Do not bury me in Egypt, NIV 30 but when I rest with my fathers, carry me out of Egypt and bury me where they are buried.”
<G-vec01130-002-s042><bury.begraben><de> 30 Wenn ich mit meinen Vätern liegen werde, so führe mich aus Ägypten und begrabe mich in ihrem Begräbnis.
<G-vec01130-002-s043><bury.begraben><en> 4 Do not bury me in Egypt, 47:30 but when I rest 5 with my fathers, carry me out of Egypt and bury me in their burial place.”
<G-vec01130-002-s043><bury.begraben><de> 30Wenn ich mit meinen Vätern liegen werde, so führe mich aus Ägypten und begrabe mich in ihrem Begräbnis.
<G-vec01130-002-s044><bury.begraben><en> Bury in a pelvis with sand a few small items - "secretaries".
<G-vec01130-002-s044><bury.begraben><de> Begrabe in einem Becken mit Sand ein paar kleine Gegenstände - "Sekretärinnen".
<G-vec01130-002-s045><bury.begraben><en> I am born for burning, bury me again.
<G-vec01130-002-s045><bury.begraben><de> Ich bin geboren um zu brennen, begrabe mich wieder.
<G-vec01130-002-s046><bury.begraben><en> 31The king said to him, “Do as he has said, and fall on him, and bury him; that you may take away the blood, which Joab shed without cause, from me and from my father’s house.
<G-vec01130-002-s046><bury.begraben><de> 31Und der König sprach zu ihm: Tue, wie er geredet hat, und stoße ihn nieder, und begrabe ihn; und so tue das Blut, das Joab ohne Ursache vergossen hat, von mir und von dem Hause meines Vaters hinweg.
<G-vec01130-002-s047><bury.begraben><en> Bury a few small toys in the sand so that the kid can see how you hide them.
<G-vec01130-002-s047><bury.begraben><de> Begrabe ein paar kleine Spielsachen im Sand, damit das Kind sehen kann, wie du es versteckst.
<G-vec01130-002-s048><bury.begraben><en> 6 And Pharao said to Joseph, Go up, bury your father, as he constrained you to swear.
<G-vec01130-002-s048><bury.begraben><de> 6 Pharao sprach: Zieh hinauf und begrabe deinen Vater, wie du ihm geschworen hast.
<G-vec01130-002-s049><bury.begraben><en> But he said, “Lord, let me first go and bury my father.”
<G-vec01130-002-s049><bury.begraben><de> Der sprach aber: HERR, erlaube mir, daß ich zuvor hingehe und meinen Vater begrabe.
<G-vec01130-002-s050><bury.begraben><en> And Abraham rose up from before his dead and said to the Hittites, “I am a sojourner and foreigner among you; give me property among you for a burying place, that I may bury my dead out of my sight.”
<G-vec01130-002-s050><bury.begraben><de> Darnach stand er auf von seiner Leiche und redete mit den Kindern Heth und sprach: 4 Ich bin ein Fremder und Einwohner bei euch; gebt mir ein Erbbegräbnis bei euch, daß ich meinen Toten begrabe, der vor mir liegt.
<G-vec01130-002-s051><bury.begraben><en> Now therefore let me go up, I pray you, and bury my father; then I will return."
<G-vec01130-002-s051><bury.begraben><de> Und nun lass mich doch hinaufziehen, dass ich meinen Vater begrabe und zurückkomme.
<G-vec01130-002-s052><bury.begraben><en> So bury your dead.
<G-vec01130-002-s052><bury.begraben><de> So begrabe deine Tote.
<G-vec01130-002-s053><bury.begraben><en> 6And Pharaoh answered, “Go up, and bury your father, as he made you swear.”
<G-vec01130-002-s053><bury.begraben><de> 6Der Pharao sprach: Zieh hinauf und begrabe deinen Vater, wie du ihm geschworen hast.
<G-vec01130-002-s055><bury.begraben><en> 3And Abraham rose up from before his dead and said to the Hittites, 4"I am a sojourner and foreigner among you; give me property among you for a burying place, that I may bury my dead out of my sight."
<G-vec01130-002-s055><bury.begraben><de> 3Und Abraham erhob sich weg von seiner Toten und redete zu den Kindern Heth und sprach: 4Ich bin ein Fremdling und Beisasse bei euch; gebet mir ein Erbbegräbnis bei euch, daß ich meine Tote begrabe vor meinem Angesicht hinweg.
<G-vec01130-002-s056><bury.begraben><en> But he said, “Permit me first to go and bury my father.”
<G-vec01130-002-s056><bury.begraben><de> Der aber sagte: Erlaube mir, erst hinzugehen und meinen Vater zu begraben.
<G-vec01130-002-s057><bury.begraben><en> 13And he spake unto Ephron in the audience of the people of the land, saying, But if thou wilt give it, I pray thee, hear me: I will give thee money for the field; take it of me, and I will bury my dead there.
<G-vec01130-002-s057><bury.begraben><de> 13und redete mit Efron, sodass das Volk des Landes es hörte, und sprach: Willst du ihn mir lassen, so bitte ich, nimm von mir das Geld für den Acker, das ich dir gebe, so will ich meine Tote dort begraben.
<G-vec01130-002-s058><bury.begraben><en> GRAND ALCHEMIST want too much and bury a bigger part of their musical finesse under a tight wall of bombastic keyboards and pianos.
<G-vec01130-002-s058><bury.begraben><de> GRAND ALCHEMIST wollen ziemlich viel, aber begraben ein Großteil ihrer musikalischen Finesse unter einer schier undurchdringlichen Wand aus bombastischen Keyboards und Pianos.
<G-vec01130-002-s059><bury.begraben><en> How I got here, who I am - I do not know, but I must have seen something horrible or done otherwise would not bury me alive and left to believe that I was dead.
<G-vec01130-002-s059><bury.begraben><de> Wie ich hierherkam, wer ich bin - ich weiß es nicht, aber ich muss etwas Schreckliches gesehen oder getan haben, sonst hätte man mich nicht lebendig begraben und in dem Glauben zurückgelassen, dass ich tot sei.
<G-vec01130-002-s060><bury.begraben><en> After death you can choose to bury or cremate your pet at a special pet cemetery.
<G-vec01130-002-s060><bury.begraben><de> Nach seinem Tod kann Dein Haustier auf einem speziellen Haustierfriedhof begraben oder eingeäschert werden.
<G-vec01130-002-s061><bury.begraben><en> If, however, a compromise is not reached, it will be time to formally bury the Doha Round at long last.
<G-vec01130-002-s061><bury.begraben><de> Sollte jedoch kein Kompromiss zustande kommen, wäre es an der Zeit, die Doha-Runde endlich auch formell zu begraben.
<G-vec01130-002-s062><bury.begraben><en> Nomadic herders from the region returned here in late winter and spring to rest their herds and bury their dead.
<G-vec01130-002-s062><bury.begraben><de> Nomadische Hirten aus der Region kehrten im späten Winter und Frühjahr hierher zurück, um mit ihren Herden zu rasten und ihre Toten zu begraben.
<G-vec01130-002-s063><bury.begraben><en> There were not enough living left to bury them, for, at one stroke, the flower of their offspring had perished.
<G-vec01130-002-s063><bury.begraben><de> Es waren nicht genügend Lebende da, um sie zu begraben; denn mit einem Schlag waren die besten Nachkommen vernichtet worden.
<G-vec01130-002-s064><bury.begraben><en> In both Kirchhoefe, men became with their armament (iron blade, measurer, bar of heads and dolche) and women with their jewelry bury (Fibulae and pins, halsketten, rings, hair ornaments).
<G-vec01130-002-s064><bury.begraben><de> In beide Kirchhöfe, Männer wurden mit ihrer Rüstung (Eisenklingen, Messer, Stange Köpfe und Dolche) und Frauen mit ihren Schmucksachen begraben (Fibulae und Stifte, Halsketten, Ringe, Haarverzierungen).
<G-vec01130-002-s065><bury.begraben><en> So they will bury Gog there with all his horde, and they will call it the valley of Hamon-gog.
<G-vec01130-002-s065><bury.begraben><de> Und daselbst werden sie Gog und seine ganze Menge begraben, und sie werden es nennen: Tal der Menge Gogs.
<G-vec01130-002-s066><bury.begraben><en> 10And the dogs shall eat Jezebel in the territory of Jezreel, and none shall bury her.”
<G-vec01130-002-s066><bury.begraben><de> 10Isebel aber sollen die Hunde fressen auf dem Ackerstück zu Jisreel, und niemand wird sie begraben.
<G-vec01130-002-s067><bury.begraben><en> Mr. Steiger, the old grave-digger, told me that he had to bury 12 corpses in the first few days after the end of the war.
<G-vec01130-002-s067><bury.begraben><de> Ich ging auf den Ortsfriedhof, wo ich den alten Totengräber Steiger antraf, er erzählte mir, daß er gleich nach den ersten Tagen 12 Leichen begraben musste.
<G-vec01130-002-s068><bury.begraben><en> In 2018 ANDRA wants to get the final authorization to start to bury 99% of France’s most radioactive nuclear waste 500 meters deep in the region of Bure.
<G-vec01130-002-s068><bury.begraben><de> Im Jahr 2018 will ANDRA die endgültige Genehmigung erhalten, 99% der hoch radioaktiven Atomabfälle Frankreichs 500 Meter tief in der Region Bure zu begraben.
<G-vec01130-002-s069><bury.begraben><en> End of darkness; no more fears, or: to bury one's needs, to suppress one's fears or one's intuition.
<G-vec01130-002-s069><bury.begraben><de> Ende der Dunkelheit; keine Ängste mehr, oder: Bedürfnisse begraben, Ängste oder Intuition unterdrücken.
<G-vec01130-002-s070><bury.begraben><en> It seemed as if common sense and logic had won over the hundreds of mayors and dogcatchers (who during 8 years managed to "bury" aprox. 35 million euros in a mountain of stray corps).Also, during the same time, in December 2007, the Senate modified the law concerning the strays and replaced euthanasia with spay/neuter and returning to territory, according to the WHO's guidelines.
<G-vec01130-002-s070><bury.begraben><de> Es schien, als ob der gesunde Menschenverstand und die Logik sich gegen hunderte von Bürgermeistern und Hundefängern durchgesetzt hätten (die es in 8 Jahren geschafft hatten 35 Millionen Euro in einem Berg von toten Streunerkötpern zu „begraben“) Während der gleichen Zeit im Dezember 2007, modifizierte der Senat das Streunergesetz gemäß den Richtlinien der WHO und ersetzte die Tötungen durch Kastrationen und die Verbringung an die angestammten Plätze.
<G-vec01130-002-s071><bury.begraben><en> The paper then imposed a near-blackout on its news and editorial pages to bury the story and kill it through silence - never mind its importance in documenting clear evidence of Israeli war crimes against a civilian population.
<G-vec01130-002-s071><bury.begraben><de> Danach hat das Blatt eine fast vollständige Nachrichtenblockade auf seinen Leitartikel-und Nachrichtenseiten verhängt, um die Geschichte zu begraben und sie totzuschweigen – abgesehen von ihrer Bedeutung, eindeutige Beweise über israelische Kriegsverbrechen gegen die Zivilbevölkerung dokumentiert zu haben.
<G-vec01130-002-s072><bury.begraben><en> Nay, my lord, hear me: the field give I thee, and the cave that is therein, I give it thee; in the presence of the sons of my people give I it thee: bury thy dead.
<G-vec01130-002-s072><bury.begraben><de> Ich schenke dir den Acker, und die Höhle drinnen dazu, und übergebe dir's vor den Augen der Kinder meines Volks, zu begraben deinen Toten.
<G-vec01130-002-s073><bury.begraben><en> 21 Then another of His disciples said to Him, “Lord, let me first go and bury my father.”
<G-vec01130-002-s073><bury.begraben><de> Ein anderer aber von seinen Jüngern sprach zu ihm: Herr, erlaube mir, zuvor hinzugehen und meinen Vater zu begraben.
<G-vec01130-002-s074><bury.begraben><en> 10 Then shalt thou break the bottle in the sight of the men that go with thee, 11 and shalt say unto them, Thus saith Jehovah of hosts: Even so will I break this people and this city, as one breaketh a potter’s vessel, that cannot be made whole again; and they shall bury in Topheth, till there be no place to bury.
<G-vec01130-002-s074><bury.begraben><de> 10 Und du sollst den Krug zerbrechen vor den Männern, die mit dir gegangen sind, 11 und sprich zu ihnen: So spricht der HERR Zebaoth: Eben wie man eines Töpfers Gefäß zerbricht, das nicht kann wieder ganz werden, so will ich dies Volk und diese Stadt auch zerbrechen; und sie sollen im Thopheth begraben werden, weil sonst kein Raum sein wird, zu begraben.
<G-vec01130-002-s075><bury.begraben><en> Let the dead bury the dead and perhaps they'll "get it" on the next pass but they are NOT your concern.
<G-vec01130-002-s075><bury.begraben><de> Lass die Toten die Toten begraben, und vielleicht werden sie es beim nächsten Durchgang „kapieren“, aber das soll nicht deine Sorge sein.
<G-vec01130-002-s076><bury.begraben><en> For our one Father, God, lives, and our mother, the Church; and neither are we dead who live to God, nor do we bury our dead, inasmuch as they too are living in Christ.
<G-vec01130-002-s076><bury.begraben><de> Denn es lebt Gott, unser einziger Vater, und unsere Mutter, die Kirche, und auch wir sind nicht tot, da wir Gott leben, und wir begraben keine Toten, da auch sie in Christo leben.
<G-vec01130-002-s077><bury.begraben><en> 40 Then they took the body of Jesus, and bound it in strips of linen with the spices, as the custom of the Jews is to bury.
<G-vec01130-002-s077><bury.begraben><de> 40 Sie nahmen nun den Leib Jesu und banden ihn samt den wohlriechenden Gewürzen in leinene Tücher, wie die Juden zu begraben pflegen.
<G-vec01130-002-s078><bury.begraben><en> 40Then took they the body of Jesus, and wound it in linen clothes with the spices, as the manner of the Jews is to bury.
<G-vec01130-002-s078><bury.begraben><de> 40Da nahmen sie den Leichnam Jesu und banden ihn in Leinentücher mit wohlriechenden Ölen, wie die Juden zu begraben pflegen.
<G-vec01130-002-s079><bury.begraben><en> 40 They took therefore the body of Jesus, and bound it in linen cloths, with the spices, as the manner of the Jews is to bury.
<G-vec01130-002-s079><bury.begraben><de> 40 Da nahmen sie den Leichnam Jesu und banden ihn in Leinentücher mit wohlriechenden Spezereien, wie die Juden zu begraben pflegen.
<G-vec01130-002-s080><bury.begraben><en> Now therefore let me go up, I pray thee, and bury my father, and I will come again.
<G-vec01130-002-s080><bury.begraben><de> Und nun möge ich doch hinaufziehen, meinen Vater begraben und wiederkehren.
<G-vec01130-002-s081><bury.begraben><en> 29 Then he gave them these instructions: "I am about to be gathered to my people. Bury me with my fathers in the cave in the field of Ephron the Hittite, 30 the cave in the field of Machpelah, near Mamre in Canaan, which Abraham bought as a burial place from Ephron the Hittite, along with the field.
<G-vec01130-002-s081><bury.begraben><de> 29Und er gebot ihnen und sprach: Ich werde zu meinem Volk versammelt werden; begrabet mich bei meinen Vätern in der Höhle auf dem Acker Ephrons, des Hetiters, (1.Mose 23,16-20; 1.Mose 47,30) 30in der Höhle Machpelah, Mamre gegenüber im Lande Kanaan, wo Abraham den Acker gekauft hat von Ephron, dem Hetiter, zum Erbbegräbnis.
<G-vec01130-002-s082><bury.begraben><en> 34 And, when he had entered and eaten and drunk, he said—Look, I pray you, after this accursed woman, and bury her, for the daughter of a king, she is.
<G-vec01130-002-s082><bury.begraben><de> 34 Und er ging hinein und aß und trank; und er sprach: Sehet doch nach dieser Verfluchten und begrabet sie, denn sie ist eine Königstochter.
<G-vec01130-002-s083><bury.begraben><en> Genesis 49:29 And he [Jacob] charged them, and said unto them, I am to be gathered unto my people: bury me with my fathers in the cave that is in the field of Ephron the Hittite 30 In the cave that is in the field of Machpelah, which is before Mamre, in the land of Canaan, which Abraham bought with the field of Ephron the Hittite for a possession of a buryingplace.
<G-vec01130-002-s083><bury.begraben><de> Jakobs Tod und Begräbnis: „29 Und Jakob gebot ihnen und sprach zu ihnen: Ich werde versammelt zu meinem Volk; begrabt mich bei meinen Vätern in der Höhle auf dem Acker Efrons, des Hetiters, 30 in der Höhle auf dem Felde von Machpela, die östlich von Mamre liegt im Lande Kanaan, die Abraham kaufte samt dem Acker von Efron, dem Hetiter, zum Erbbegräbnis.
<G-vec01130-002-s084><bury.begraben><en> < 13:31 After burying him, he said to his sons, "When I die, bury me in the grave where the man of God is buried; lay my bones beside his bones.
<G-vec01130-002-s084><bury.begraben><de> 13:31 Und als sie ihn begraben hatten, sprach er zu seinen Söhnen: Wenn ich sterbe, so begrabt mich in dem Grabe, in dem der Mann Gottes begraben ist, und legt mein Gebein neben sein Gebein.
<G-vec01130-002-s085><bury.begraben><en> The Death of Jacob Then he gave them these instructions: “I am about to be gathered to my people. Bury me with my fathers in the cave in the field of Ephron the Hittite, the cave in the field of Machpelah, near Mamre in Canaan, which Abraham bought along with the field as a burial place from Ephron the Hittite.
<G-vec01130-002-s085><bury.begraben><de> 29 Und er gebot ihnen und sprach zu ihnen: Bin ich versammelt zu meinem Volk, so begrabt mich zu meinen Vätern in der Höhle, die in dem Feld Ephrons, des Hethiters, ist, 30 in der Höhle, die in dem Feld Machpela vor Mamre ist, im Land Kanaan, die Abraham samt dem Feld von Ephron, dem Hethiter, zum Erbbegräbnis gekauft hat.
<G-vec01130-002-s086><bury.begraben><en> Bury me in the cave in the field at Machpelah, near Mamre, in the land of Canaan
<G-vec01130-002-s086><bury.begraben><de> Begrabt mich in der Höhle auf dem Feld von Machpela gegenüber von Mamre im Land Kanaan.
<G-vec01130-002-s087><bury.begraben><en> 31 And it came to pass, after he had buried him, that he spake to his sons, saying, When I am dead, then bury me in the sepulchre wherein the man of God is buried; lay my bones beside his bones.
<G-vec01130-002-s087><bury.begraben><de> 31 Und da sie ihn begraben hatten, sprachsprach er zu seinen Söhnen: Wenn ich sterbe, so begrabt mich in dem Grabe, darin der Mann GottesGottes begraben ist, und legt mein GebeinGebein neben sein GebeinGebein.
<G-vec01130-002-s088><bury.begraben><en> However, the Ari stopped them, crying out: "Don't bury him here.
<G-vec01130-002-s088><bury.begraben><de> Der Ari hielt sie zurück und rief: „Begrabt ihn nicht hier.
<G-vec01130-002-s089><bury.begraben><en> 31 After burying him, he said to his sons, “When I die, bury me in the grave where the man of God is buried; lay my bones beside his bones.
<G-vec01130-002-s089><bury.begraben><de> Und als er ihn begraben hatte, sprach er zu seinen Söhnen: Wenn ich sterbe, so begrabt mich in dem Grab, in dem der Mann Gottes begraben worden ist, und legt meine Gebeine neben seine Gebeine.
<G-vec01130-002-s091><bury.begraben><en> 17 I would give my bread to the hungry and my clothing to the naked. If I saw one of my people who had died and been thrown outside the walls of Nineveh, I would bury him.
<G-vec01130-002-s091><bury.begraben><de> 17 Ich gab den Hungernden mein Brot und den Nackten meine Kleider; wenn ich sah, dass einer aus meinem Volk gestorben war und dass man seinen Leichnam hinter die Stadtmauer von Ninive geworfen hatte, begrub ich ihn.
<G-vec01130-002-s092><bury.begraben><en> 7`And I -- in my coming in from Padan-[Aram] Rachel hath died by me in the land of Canaan, in the way, while yet a kibrath of land to enter Ephrata, and I bury her there in the way of Ephrata, which [is] Bethlehem.'
<G-vec01130-002-s092><bury.begraben><de> 7 Und als ich aus Mesopotamien kam, starb mir Rahel im Land Kanaan auf der Reise, als es nur noch eine kleine Strecke Weges war bis Efrata, und ich begrub sie dort an dem Wege nach Efrata, das nun Bethlehem heißt.
<G-vec01130-002-s093><bury.begraben><en> Only once Our Lady showed the young people a horrible scene: a river of blood, people killing each other, abandoned corpses, no one to bury them…This terrifying vision was later related to the genocide which disrupted Rwanda in 1994/1995, of which Kibeho was one of the worst affected areas.
<G-vec01130-002-s093><bury.begraben><de> Nur einmal zeigte sie erschreckende Bilder: einen Fluss aus Blut, Menschen, die sich gegenseitig umbrachten, Leichen, die keiner begrub …Diese schreckliche Vision wurde später mit dem Völkermord in Verbindung gebracht, zu dem es in Ruanda in den Jahren 1994/1995 gekommen war und zu dessen blutigsten Schauplätzen gerade Kibeho gehörte.
<G-vec01130-002-s094><bury.begraben><en> 23 and Uzziah lieth with his fathers, and they bury him with his fathers, in the field of the burying-place that the kings have, for they said, 'He [is] a leper;' and reign doth Jotham his son in his stead.
<G-vec01130-002-s094><bury.begraben><de> 23Und Usija legte sich zu seinen Vätern und sie begruben ihn bei seinen Vätern auf dem Felde neben der Grabstätte der Könige; denn sie sprachen: Er ist aussätzig.
<G-vec01130-002-s095><bury.begraben><en> 14 and bury the bones of Saul and of Jonathan his son in the land of Benjamin, in Zelah, in the burying-place of Kish his father, and do all that the king commanded, and God is entreated for the land afterwards.
<G-vec01130-002-s095><bury.begraben><de> 14 und begruben die Gebeine Sauls und seines Sohnes Jonathan im Lande Benjamin zu Zela im Grabe seines Vaters Kis und taten alles, wie der König geboten hatte.
<G-vec01130-002-s096><bury.begraben><en> Before the Prophethood of Muhammad (Peace and Blessings be upon him) the Arabs were heavy drinkers of alcohol, engage in tribal battles and even bury their female babies alive.
<G-vec01130-002-s096><bury.begraben><de> Vor dem Prophetentum Muhammads (Frieden und Segen auf ihm) waren die Araber schwere Trinker, ständig in Stammeskriegen verstrickt und begruben sogar ihre kleinen Töchter bei lebendigem Leibe.
<G-vec01130-002-s097><bury.begraben><en> "No, they did not bury me, though there is a period of time which I remember mistily, with a shuddering wonder, like a passage through some inconceivable world that had no hope in it and no desire.
<G-vec01130-002-s097><bury.begraben><de> Nein, sie begruben mich nicht, obwohl es eine Zeitspanne gibt, an die ich mich nur nebelhaft erinnere, mit einer fröstelnden Verwunderung, wie an die Durchquerung einer unbegreiflichen Welt, in der es keine Hoffnung und keine Sehnsucht gab.
<G-vec01130-002-s098><bury.begraben><en> 28 On his own chariot his servants laid him down, and so bore him back to Jerusalem, to bury him where his fathers were buried, in David’s Keep.
<G-vec01130-002-s098><bury.begraben><de> 28 Und seine Knechte ließen ihn führen gen Jerusalem und begruben ihn in seinem Grabe mit seinen Vätern in der Stadt Davids.
<G-vec01130-002-s100><bury.begraben><en> And everyone knows that when your pet frog dies that everybody is solemn and you go out and bury the frog with due ceremony and ritual.
<G-vec01130-002-s100><bury.begraben><de> Jedermann weis, wenn Dein Frosch Haustier stirbt, verhalten sich alle ganz feierlich, und Du gehst raus und begräbst den Frosch mit der gebührenden Zeremonie und dem angemessenen Ritual.
<G-vec01130-002-s101><bury.begraben><en> eviction / expulsion, but enact our collective death and bury us all here.
<G-vec01130-002-s101><bury.begraben><de> Stattdessen verlangen wir, dass die Regierung unseren kollektiven Tod dekretiert und uns alle hier begräbt.
<G-vec01130-002-s102><bury.begraben><en> Whoever truly recognizes this “hidden predestination” of all our so-called “good works” will quickly bury even the smallest tinge of pride, for all that flows from our lives which is acceptable and good does not arise with us.
<G-vec01130-002-s102><bury.begraben><de> Wer diese verborgene Prädestination unserer so genannten „Guten Werke“ erkennt, begräbt schnell jeden Anflug von Stolz, denn alles was akzeptabel und gut aus unserem Leben herauskommt, stammt nicht von uns, sondern bleibt ein Gedanke und eine Tat unseres Gottes.
<G-vec01130-002-s103><bury.begraben><en> A so-called "full service" broker will bury you with all kinds of reports, analysis sheets and other pretty pieces of paper, but will probably try to sell you something that makes him the most commission.Let's see.
<G-vec01130-002-s103><bury.begraben><de> Ein sogenannter Vermittler "des vollen Services" begräbt Sie mit allen Arten Reports, Analyse Blättern und anderen hübschen Papierstreifen, aber versucht vermutlich, Sie zu verkaufen etwas, das ihn die meiste Kom...
<G-vec01130-002-s104><bury.begraben><en> Be brave enough to be the first one to bury the hatchet again.
<G-vec01130-002-s104><bury.begraben><de> Sei tapfer genug der erste zu sein der wieder das Kriegsbeil begräbt.
<G-vec01130-002-s130><bury.begraben><en> The ravine was reportedly then destroyed with explosives in order to bury all the bodies.
<G-vec01130-002-s130><bury.begraben><de> Anschließend sei die Schlucht gesprengt worden, um alle Leichen darunter zu begraben.
<G-vec01130-002-s142><bury.begraben><en> Bury this McCann crap along with Madeleine
<G-vec01130-002-s142><bury.begraben><de> Gehen Sie diese McCann Mist begraben zusammen mit...
<G-vec01130-002-s152><bury.begraben><en> When darkness had fallen – it may perhaps have lasted half an hour – I feared that a working party would now come to bury us.
<G-vec01130-002-s152><bury.begraben><de> Als es dunkel geworden war – es mag etwa eine halbe Stunde gedauert haben –, fürchtete ich, daß nunmehr eine Kolonne kommen werde, um uns zu begraben.
<G-vec01130-002-s158><bury.begraben><en> 10 And the dogs shall eat Jezebel in the plot of Jizreel, and none shall bury her.
<G-vec01130-002-s158><bury.begraben><de> Isebel aber sollen die Hunde fressen auf dem Feld von Jesreel, und da wird niemand sein, der begräbt.
<G-vec01130-002-s164><bury.begraben><en> 31 And the king said unto him, Do as he hath said, and fall upon him, and bury him; that thou mayest take away the innocent blood, which Joab shed, from me, and from the house of my father. 32 And the LORD shall return his blood upon his own head, who fell upon two men more righteous and better than he, and slew them with the sword, my father David not knowing thereof, to wit, Abner the son of Ner, captain of the host of Israel, and Amasa the son of Jether, captain of the host of Judah.
<G-vec01130-002-s164><bury.begraben><de> 2:31 Der König sprach zu ihm: Tue, wie er geredet hat, und schlage ihn und begrabe ihn, daß du das Blut, das Joab umsonst vergossen hat, von mir tust und von meines Vaters Hause, 2:32 und der HERR ihm bezahle sein Blut auf seinen Kopf, daß er zween Männer geschlagen hat, die gerechter und besser waren denn er, und hat sie erwürget mit dem Schwert, daß mein Vater David nichts drum wußte, nämlich Abner, den Sohn Ners, den Feldhauptmann über Israel, und Amasa, den Sohn Jethers, den Feldhauptmann über Juda; 2:33 daß ihr Blut bezahlet werde auf den Kopf Joabs und seines Samens ewiglich, aber David und sein Same, sein Haus und sein Stuhl Frieden habe ewiglich vor dem HERRN.
<G-vec01130-002-s168><bury.begraben><en> 30 And he laid his body in his own grave; and they mourned over him, saying, Alas, my brother! 31 And it came to pass, after he had buried him, that he spake to his sons, saying, When I am dead, then bury me in the sepulchre wherein the man of God is buried; lay my bones beside his bones.
<G-vec01130-002-s168><bury.begraben><de> 30 Demgemäß legte er seinen Leichnam in seine eigene Grabstätte; und sie fuhren fort, um ihn zu klagen:+ „Wie schade, mein Bruder!“ 31 Und es geschah, nachdem er ihn begraben hatte, daß er weiter zu seinen Söhnen sagte: „Wenn ich sterbe, sollt ihr mich in der Grabstätte begraben, in welcher der Mann des [wahren] Gottes begraben ist.
<G-vec01130-002-s172><bury.begraben><en> They were also to receive the sacraments there and bury their dead in their own cemetery.
<G-vec01130-002-s172><bury.begraben><de> Auch sollten sie an Ort und Stelle die Sakramente empfangen und ihre Toten in einem eigenen Friedhof begraben können.
<G-vec01130-002-s176><bury.begraben><en> I had bottled things up to bury my worry.
<G-vec01130-002-s176><bury.begraben><de> Ich habe alles unterdrückt und meine Sorgen begraben.
<G-vec01130-002-s146><bury.tragen><en> Together, we will read names and symbolically bury the Universal Declaration of Human Rights.
<G-vec01130-002-s146><bury.tragen><de> Wir werden gemeinsam Namen verlesen und die Allgemeine Erklärung der Menschenrechte symbolisch zu Grabe tragen.
<G-vec01130-002-s147><bury.tragen><en> And people were getting ready to go and bury me.
<G-vec01130-002-s147><bury.tragen><de> Und die Leute bereiteten sich vor, um mich zu Grabe zu tragen.
