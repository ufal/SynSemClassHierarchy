<G-vec00484-002-s012><chastise.bestrafen><en> He said: As to him who is injust, we will chastise him, then shall he be returned to his Lord, and He will chastise him with an exemplary chastisement: And as for him who believes and does good, he shall have goodly reward, and We will speak to him an easy word of Our command.
<G-vec00484-002-s012><chastise.bestrafen><de> Er sprach: Â«Wer da frevelt, den werden wir sicherlich bestrafen; dann soll er zu seinem Herrn zurückgebracht werden, und Er wird ihn mit furchtbarer Strafe strafen.
<G-vec00484-002-s010><chastise.kasteien><en> I now have imposed not at all restrictions on men, as I also never make demands on man to chastise themselves, to reach the kingdom of God.
<G-vec00484-002-s010><chastise.kasteien><de> Ich habe nun keineswegs den Menschen Beschränkungen auferlegt, wie Ich auch niemals Forderungen an die Menschen stelle, sich zu kasteien, um das Reich Gottes zu erreichen.
<G-vec00484-002-s011><chastise.schelten><en> She narrows her eyes in an attempt to chastise me for my outrageous behavior.
<G-vec00484-002-s011><chastise.schelten><de> Sie kneift die Augen zusammen und versucht mich damit für mein unerhörtes Verhalten zu schelten.
<G-vec00484-002-s009><chastise.wehren><en> 13 For I have foretold to him that I will judge his house unto eternity, because of iniquity. For he had known that his sons acted shamefully, and he did not chastise them.
<G-vec00484-002-s009><chastise.wehren><de> 13Denn ich habe ihm kundgetan, daß ich sein Haus richten will ewiglich, um der Ungerechtigkeit willen, die er gewußt hat, daß seine Söhne sich den Fluch zuzogen, und er ihnen nicht gewehrt hat.
<G-vec00484-002-s015><chastise.zurechtweisen><en> Because she's so advanced devotee that she has got the right to chastise the Supreme Personality of Godhead.
<G-vec00484-002-s015><chastise.zurechtweisen><de> Weil sie so eine fortgeschrittene Geweihte ist, dass sie das Recht hat die höchste Persönlichkeit Gottes zurecht zu weisen.
<G-vec00484-002-s016><chastise.züchtigen><en> 19 Whomsoever I love, I rebuke and chastise.
<G-vec00484-002-s016><chastise.züchtigen><de> 19 Ich überführe und züchtige, so viele ich liebe.
<G-vec00620-002-s017><chastise.züchtigen><en> Since I have seen the essence of man clearly, I am qualified to chastise man and judge him, because all of man came from Me but has been corrupted by Satan.
<G-vec00620-002-s017><chastise.züchtigen><de> Weil Ich die Essenz des Menschen deutlich gesehen habe, bin Ich qualifiziert, den Menschen zu züchtigen und ihn zu richten, weil jeder Mensch von Mir kam, aber von Satan korrumpiert wurde.
<G-vec00620-002-s018><chastise.züchtigen><en> 18. And the elders of that city shall take that man and chastise him;
<G-vec00620-002-s018><chastise.züchtigen><de> 18 Und die Ältesten jener Stadt sollen den Mann nehmen und ihn züchtigen.
<G-vec00620-002-s019><chastise.züchtigen><en> Chastise and Tame. (# 23) The cocky and stubborn horse-girl, the lazy maid, the spoiled granddaughter, the adventurous wife and several others are getting spanked in the varying sequences of this video.
<G-vec00620-002-s019><chastise.züchtigen><de> (# 23) Züchtigen und Zähmen(Chastise and Tame) Das protzige und halsstarrige Pferde-Mädchen, das faule Dienstmädchen, die verwöhnte Grosstochter, das abenteuerliche Weib und noch manche andere werden in den abwechslungsreichen Abschnitten dieses Videos gezüchtigt.
