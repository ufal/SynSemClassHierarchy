<G-vec00366-002-s076><cover.abdecken><en> FH Campus Wien is the only university to cover a wide range of highly skilled health and nursing professions with a bachelor's degree program and master's degree programs in Advanced Nursing Counseling (health and nursing counseling), Advanced Nursing Practice (management) and Advanced Nursing Education (teaching).
<G-vec00366-002-s076><cover.abdecken><de> Die FH Campus Wien ist die einzige Hochschule, die mit dem Bachelorstudium und den Masterlehrgängen für Gesundheits- und Pflegeberatung), Advanced Nursing Practice (Management) und Advanced Nursing Education (Lehre) ein breites Spektrum der höher qualifizierten Gesundheits- und Krankenpflege abdeckt.
<G-vec00366-002-s077><cover.abdecken><en> Bear in mind that the insurance will not cover incidents caused by unauthorized drivers.
<G-vec00366-002-s077><cover.abdecken><de> Berücksichtigen Sie bitte, dass diese Versicherung keine Ereignisse abdeckt, die von nicht autorisierten Fahrern verursacht wurden.
<G-vec00366-002-s078><cover.abdecken><en> For these reasons, it is very important to make sure that your insurance policy will cover such scenarios, and that the limit of coverage is high enough.
<G-vec00366-002-s078><cover.abdecken><de> Aus diesen Gründen ist es sehr wichtig, dass Ihre Versicherung solche Vorfälle abdeckt und die Deckungssummen hoch genug festgelegt sind.
<G-vec00366-002-s079><cover.abdecken><en> The alchemist himself is the Wild Symbol of the game, and this can expand to cover entire reels as it lands.
<G-vec00366-002-s079><cover.abdecken><de> Der Alchemist selbst ist das Wild Symbol des Spiels und kann sich so erweitern, dass es ganze Walzen abdeckt.
<G-vec00366-002-s080><cover.abdecken><en> The use of templates to cover up parts of the canvas so as to go on painting ‘blind’, is one of the methodological points de départ helping to achieve this controversial effect by which the artist here stages painting anew as feint and sleight of hand, presenting it as a statement against calculated intentionality and outworn (visual) experiences.
<G-vec00366-002-s080><cover.abdecken><de> Die Arbeit mit Schablonen, mit denen sie Partien der Leinwand abdeckt, um ‚blind‘ weiter zu malen, ist einer der methodischen Ausgangspunkte für die Realisierung dieses kontroversen Effekts, mit dem die Künstlerin die Malerei hier in neuer Form als Täuschungsmanöver in Szene setzt und uns als Statement gegen das Kalkül und abgenutzte (Seh-)Erfahrungen vor Augen führt.
<G-vec00366-002-s081><cover.abdecken><en> In order to ensure their acuity, the sensors must not be damaged or dirty, so the Google covers the sensors on the unmanned body with a glass cover.
<G-vec00366-002-s081><cover.abdecken><de> Um ihre Schärfe zu gewährleisten, dürfen die Sensoren nicht beschädigt oder verschmutzt sein, so dass Google die Sensoren am unbemannten Körper mit einer Glasabdeckung abdeckt.
<G-vec00366-002-s082><cover.abdecken><en> With clear statements regarding targeted financial ratios – net debt to adjusted EBITDA is to stay between 2 and 2.5, and a liquidity reserve that at a minimum is able to cover all maturities of the next 24 months – the Group intends to keep its A-/BBB rating and safeguard unrestricted access to the capital market.
<G-vec00366-002-s082><cover.abdecken><de> Mit klaren Aussagen zu den angestrebten Finanzrelationen - Netto-Finanzverbindlichkeiten zu bereinigtem EBITDA weiterhin zwischen 2 und 2,5 sowie eine Liquiditätsreserve, die mindestens die Fälligkeiten der nächsten 24 Monate abdeckt - will der Konzern ein Rating von A-/BBB halten und den uneingeschränkten Zugang zum Kapitalmarkt sicherstellen.
<G-vec00366-002-s083><cover.abdecken><en> Position it so that when you put the diaper on your son, the pad will cover his penis and bottom.
<G-vec00366-002-s083><cover.abdecken><de> Bringe es so an, dass es seinen Penis und seinen Hintern abdeckt, wenn du deinem Sohn die Windel anziehst.
<G-vec00366-002-s084><cover.abdecken><en> The Invert check box makes the gradient cover the parts of the image that it did not cover before.
<G-vec00366-002-s084><cover.abdecken><de> Das Umkehren-Kästchen führt dazu, dass der Gradient die Teile des Bildes abdeckt, die er zuvor nicht abgedeckt hat.
<G-vec00366-002-s085><cover.abdecken><en> The fourth area is material and resources which cover what green materials have been used in a particular project and finally indoor environmental quality which looks at measures taken to prevent air pollution and strategies established to gain more daylight into the complex and less thermal energy.
<G-vec00366-002-s085><cover.abdecken><de> Der vierte Bereich ist Material und Ressourcen, der abdeckt, welche umweltfreundlichen Materialien in einem bestimmten Projekt verwendet wurden und zuletzt noch die umweltfreundliche Qualität der Inneneinrichtung, die bewertet, welche Maßnahmen umgesetzt wurden, um Luftverschmutzung zu vermeiden und Maßnahmen, die eingesetzt wurden, um mehr Tageslicht zu gewinnen und weniger Thermalenergie für das Gebäude zu verbrauchen.
<G-vec00366-002-s086><cover.abdecken><en> Customer-specific torches are developed alongside the standard and modular solutions, which in fact cover the majority of applications.
<G-vec00366-002-s086><cover.abdecken><de> Neben Standard- und variablen Baukastenlösungen, die bereits den Großteil der Anwendungen abdeckt, werden auch kundenspezifische Brennervarianten entwickelt.
<G-vec00366-002-s087><cover.abdecken><en> As a general contractor, we contribute to project development, cover all specialist planning requirements, and make sure that project management supports your project every step of the way.
<G-vec00366-002-s087><cover.abdecken><de> Gesicherte Abwicklung Mit uns verfügen Sie über einen Generalunternehmer, der in der Projektentwicklung mitarbeitet, die Fachplanungen abdeckt und ein komplettes Projektmanagement in der Umsetzung gewährleistet.
<G-vec00366-002-s088><cover.abdecken><en> When using the standard contracts, the user always needs to make sure that the single clauses actually cover the individual circumstances they intend to have contractually settled.
<G-vec00366-002-s088><cover.abdecken><de> Bei der Verwendung der Vertragsmuster ist von der Verwenderin und dem Verwender immer zu beachten bzw zu prüfen, ob das Vertragsmuster bzw die einzelnen Klauseln den individuellen Sachverhalt, den die Verwenderin und der Verwender vertraglich zu regeln wünscht, auch abdeckt.
<G-vec00366-002-s089><cover.abdecken><en> Furthermore, the greater the intuitive confidence bettors expressed in one side winning, the greater the confidence they held that this team would also cover the point spread.
<G-vec00366-002-s089><cover.abdecken><de> Je größer darüber hinaus das von den Wettenden zum Ausdruck gebrachte intuitive Vertrauen in den Sieg eines Teams war, desto größer war auch ihr Vertrauen darin, dass dieses Team ebenfalls den Point Spread abdeckt.
<G-vec00366-002-s090><cover.abdecken><en> If the insurance they have taken out in their country of origin does not cover all legal and contractual liabilities incurred in Luxembourg they must either adapt their insurance or take out a specific civil liability insurance covering their activities and those of their employees.
<G-vec00366-002-s090><cover.abdecken><de> Wenn seine im Herkunftsland abgeschlossene Versicherung nicht die gesamte Haftpflicht in Luxemburg abdeckt, muss der Dienstleister seine Haftpflichtversicherung anpassen oder eine spezifische Haftpflichtversicherung für seine Tätigkeit sowie die seiner Angestellten abschließen.
<G-vec00366-002-s091><cover.abdecken><en> If you are unsure whether the mandibular advancement device fits your jaw, we have a tip for you: Cut a square out of a thicker, clean cardboard box, just big enough to fit in your mouth and cover your teeth.
<G-vec00366-002-s091><cover.abdecken><de> Sollten Sie sich unsicher sein, ob die Schiene für Ihren Kiefer passt, haben wir einen Tipp für Sie: Schneiden Sie aus einem dickeren, sauberen Pappkarton ein Quadrat aus, gerade so groß, dass es in Ihren Mund passt und die Zähne abdeckt.
<G-vec00366-002-s092><cover.abdecken><en> Cases in which a DRG (and thus a payment calculation) does not fully cover the use of medical devices are conceivable.
<G-vec00366-002-s092><cover.abdecken><de> Medizinische Anwendungen, bei denen die hinterlegte DRG den Sachkostenanteil des Medizinproduktes nicht vollständig abdeckt, sind vorstellbar.
<G-vec00366-002-s093><cover.abdecken><en> To cover your costs, consider taking out a cancellation insurance that will cover your refund.
<G-vec00366-002-s093><cover.abdecken><de> Um Ihre Kosten zu decken, sollten Sie eine Stornoversicherung abschließen, die Ihre Rückerstattung abdeckt.
<G-vec00366-002-s094><cover.abdecken><en> The Bosch flagship store here is set to play a key role in the premium shopping segment of the future, as it’s one of the first stores to cover many different categories — a USP in the world’s biggest e-commerce market.
<G-vec00366-002-s094><cover.abdecken><de> Im Premium Shopping der Zukunft spielt der Flagship-Store von Bosch eine bedeutende Rolle, denn er ist einer der ersten Stores, der zahlreiche Kategorien abdeckt – ein Alleinstellungsmerkmal auf dem größten E-Commerce-Markt der Welt.
<G-vec00366-002-s190><cover.bedecken><en> Cover the back of your head with your arms to protect your skull.
<G-vec00366-002-s190><cover.bedecken><de> Bedecke die Rückseite deines Kopfes mit deinen Armen, um deinen Schädel zu schützen.
<G-vec00366-002-s191><cover.bedecken><en> Cover any pipes or other objects with soil first to avoid damaging them with backfilled concrete.
<G-vec00366-002-s191><cover.bedecken><de> Bedecke die Leitungen oder andere Objekte zuerst mit Erde, damit sie nicht beschädigt werden.
<G-vec00366-002-s192><cover.bedecken><en> Cover the mold.
<G-vec00366-002-s192><cover.bedecken><de> Bedecke die Form.
<G-vec00366-002-s193><cover.bedecken><en> In order to enjoy the pure aroma of energy, do not cover the thing with lacquer, or use acrylic.
<G-vec00366-002-s193><cover.bedecken><de> Um das reine Aroma der Energie zu genießen, bedecke das Ding nicht mit Lack oder verwende Acryl.
<G-vec00366-002-s194><cover.bedecken><en> Cover your skin thickly in moisturizer and then put on a layer to protect the moisturizer while it soaks in.
<G-vec00366-002-s194><cover.bedecken><de> Bedecke deine Haut mit einer dicken Schicht Pflegecreme und lege dann eine Stoffschicht darauf, um die Pflegecreme zu schützen, während die Creme einzieht.
<G-vec00366-002-s195><cover.bedecken><en> Crusade Prayer (98) For the Grace of God to cover world leaders
<G-vec00366-002-s195><cover.bedecken><de> (98) Gebet, damit die Gnade Gottes die Weltführer bedecke.
<G-vec00366-002-s196><cover.bedecken><en> When finished, take some plastic wrap, cover everything up and refrigerate for at least 6 hours before serving.
<G-vec00366-002-s196><cover.bedecken><de> Anschließend bedecke alles mit Frischhaltefolie und stelle es vor dem Servieren für mindestens 6 Stunden kalt.
<G-vec00366-002-s197><cover.bedecken><en> She readjusts her bra, and I cover her with the duvet.
<G-vec00366-002-s197><cover.bedecken><de> Sie zieht ihren BH herunter und ich bedecke sie mit dem Quilt.
<G-vec00366-002-s198><cover.bedecken><en> Cover your whole head in the mask and leave it on for 20-30 minutes.
<G-vec00366-002-s198><cover.bedecken><de> Bedecke den gesamten Kopf mit der Maske und lass sie 20 – 30 Minuten einwirken.
<G-vec00366-002-s199><cover.bedecken><en> Be sure to cover plants to protect them from overspray.
<G-vec00366-002-s199><cover.bedecken><de> Bedecke Pflanzen, um sie vor dem Farbnebel zu schützen.
<G-vec00366-002-s200><cover.bedecken><en> Cover the blister with a bandage.
<G-vec00366-002-s200><cover.bedecken><de> Bedecke die Brandblase mit einem Verband.
<G-vec00366-002-s201><cover.bedecken><en> Cover the area in sand.
<G-vec00366-002-s201><cover.bedecken><de> Bedecke den Bereich mit Sand.
<G-vec00366-002-s202><cover.bedecken><en> Cover the seeds in a warm damp paper towel for a few hours, while you prepare your soil.
<G-vec00366-002-s202><cover.bedecken><de> Bedecke die Samen ein paar Stunden lang mit einem warmen, feuchten Papiertuch, während du den Boden vorbereitest.
<G-vec00366-002-s203><cover.bedecken><en> Cover your hair with a shower cap or plastic wrap.
<G-vec00366-002-s203><cover.bedecken><de> Bedecke deine Haare mit einer Duschhaube oder Plastikfolie.
<G-vec00366-002-s204><cover.bedecken><en> After you remove the chicken and vegetables to a platter, cover it for 20 minutes before slicing.
<G-vec00366-002-s204><cover.bedecken><de> Wenn du das Huhn und das Gemüse auf eine Platte gegeben hast, bedecke es vor dem Aufschneiden 20 Minuten.
<G-vec00366-002-s205><cover.bedecken><en> Instead of cutting a flap open, you can leave a hole at the top of the balloon (i.e., don't cover it with papier-mâché) and fill the piñata through this hole. Do not cheat!
<G-vec00366-002-s205><cover.bedecken><de> Anstatt ein Loch zu schneiden, kannst du auch einfach ein Loch an der Spitze des Ballons lassen (d. h. bedecke es nicht mit Pappmaché) und die Piñata durch dieses Loch befüllen.
<G-vec00366-002-s206><cover.bedecken><en> I liberate my mind, and cover it by the precious blood of Jesus Christ.
<G-vec00366-002-s206><cover.bedecken><de> Ich befreie meine Gedanken und ich bedecke sie durch das kostbare Blut Jesu Christi.
<G-vec00366-002-s207><cover.bedecken><en> Cover your head to remind you that YAHUSHUA is the King of Jews and we are covered by our Redeemer who lives.
<G-vec00366-002-s207><cover.bedecken><de> Bedecke deinen Kopf, um dich daran zu erinnern, daß YAHUSHUA der König der Juden ist und wir bedeckt sind durch unseren Erlöser, der lebt.
<G-vec00366-002-s208><cover.bedecken><en> Cover the box spring with the mattress cover too.
<G-vec00366-002-s208><cover.bedecken><de> Bedecke auch den Federkern mit dem Matratzenüberzug.
<G-vec00366-002-s247><cover.behandeln><en> Non-scientific trainings cover topics such as presentation skills, scientific writing, leadership skills, career planning, time management, conflict management and many more.
<G-vec00366-002-s247><cover.behandeln><de> Nicht-wissenschaftliche Trainings behandeln zum Beispiel die Themen Selbstpräsentation, wissenschaftliches Schreiben, Führungskräfteentwicklung, Karriereplanung, Zeit- oder Konfliktmanagement und vieles mehr.
<G-vec00366-002-s248><cover.behandeln><en> We just want to mention that a language called “Brazilian” doesn’t exist and that there is a distinction between European and Brazilian Portuguese (we only cover Brazilian Portuguese).
<G-vec00366-002-s248><cover.behandeln><de> Hier soll nur kurz erwähnt werden, dass es die Sprache “Brasilianisch” nicht gibt und zwischen Europäischem und Brasilianischem Portugiesisch unterschieden wird (wir behandeln nur das Brasilianische Portugiesisch).
<G-vec00366-002-s249><cover.behandeln><en> The modules cover currently important subjects which are selected annually in co-operation with the partners of the survey.
<G-vec00366-002-s249><cover.behandeln><de> Die jährlich wechselnden Module behandeln Themen, die in enger Abstimmung mit den Nutzern der Untersuchung festgelegt werden.
<G-vec00366-002-s250><cover.behandeln><en> Our team works closely together with your staff to cover all aspects of your customized solution.
<G-vec00366-002-s250><cover.behandeln><de> Unsere Mitarbeiter arbeiten mit Ihrem Team zusammen, um maßgeschneiderte Lösungen zu erstellen, die alle Aspekte ihres täglichen Bedarfs behandeln.
<G-vec00366-002-s251><cover.behandeln><en> All courses cover specific topics, but may also be tailored to your needs.
<G-vec00366-002-s251><cover.behandeln><de> Alle Kurse behandeln spezifische Themen, können jedoch auch auf Ihre Bedürfnisse zugeschnitten werden.
<G-vec00366-002-s252><cover.behandeln><en> Still, this cooking courses program gives a great flexibility and can cover also traditional meat dishes as well as pizza and bread making.
<G-vec00366-002-s252><cover.behandeln><de> Das Kursprogramm ist allerdings sehr flexibel und kann auch traditionelle Fleischgerichte und andere italienische Spezialitäten wie Pizza und italienische Brote behandeln.
<G-vec00366-002-s253><cover.behandeln><en> Cover subjects like domestic policy, foreign policy, interpretation of the constitution, criticisms, and proponents’ and opponents’ viewpoints.
<G-vec00366-002-s253><cover.behandeln><de> Behandeln Sie Themen wie Innenpolitik, Außenpolitik, Interpretation der Verfassung, Kritik und Ansichten von Befürwortern und Gegnern.
<G-vec00366-002-s254><cover.behandeln><en> It displays, once again in graphical form, all documents that cover a similar topic, so perfectly that full-text searching is only needed to enter the knowledge map.
<G-vec00366-002-s254><cover.behandeln><de> Eine ebenfalls grafische Anzeige aller Dokumente, die ein ähnliches Thema behandeln, und die so perfekt funktioniert, dass Sie die Volltextsuche nur zum Einstieg in das Wissensnetz benötigen.
<G-vec00366-002-s255><cover.behandeln><en> We cover topics from News Entertainment, Sports and Business.
<G-vec00366-002-s255><cover.behandeln><de> Wir behandeln Themen von Nachrichten Unterhaltung, Sport und Wirtschaft.
<G-vec00366-002-s256><cover.behandeln><en> We will cover this later.
<G-vec00366-002-s256><cover.behandeln><de> Wir werden dies später behandeln.
<G-vec00366-002-s257><cover.behandeln><en> We cover the troubles and politics in detail but we also look music, art, and sport.
<G-vec00366-002-s257><cover.behandeln><de> Wir behandeln detailliert die Probleme und die Politik, sehen aber auch Musik, Kunst und Sport aus.
<G-vec00366-002-s258><cover.behandeln><en> In this lesson, we will cover: the different terms used in a bakery, measurement of ingredients, common nouns, proper nouns and exercises.
<G-vec00366-002-s258><cover.behandeln><de> In dieser Lektion werden wir behandeln: die verschiedenen Begriffe, die in einer Bäckerei verwendet werden, die Messung von Zutaten, allgemeine Substantive, Eigennamen und Übungen.
<G-vec00366-002-s259><cover.behandeln><en> The theoretical modules will take place in the vocational college (Berufsfachschule) and cover topics such as sales & marketing, business & social studies, retailing & accounting, and business processes in Retail.
<G-vec00366-002-s259><cover.behandeln><de> Die theoretischen Module werden in der Berufsschule absolviert und behandeln Themen wie Vertrieb und Marketing, Betriebswirtschaft und Soziales, Handel und Rechnungswesen sowie Geschäftsprozesse im Handel.
<G-vec00366-002-s260><cover.behandeln><en> The units are designed to cover basic day-to-day tasks such as writing e-mails, to more specific tasks such as press releases and minutes of meetings.
<G-vec00366-002-s260><cover.behandeln><de> Die Unterrichtseinheiten behandeln grundlegende Alltagsaufgaben vom Verfassen von E-Mails bis hin zu spezielleren Texten wie Pressemitteilungen oder Protokollen von Meetings.
<G-vec00366-002-s261><cover.behandeln><en> The final topic we will cover is the implication of recreational drug use in disrupted sleep.
<G-vec00366-002-s261><cover.behandeln><de> Das letzte Thema, das wir behandeln werden, ist die Auswirkung von Freizeitdrogenkonsum bei gestörtem Schlaf.
<G-vec00366-002-s262><cover.behandeln><en> We will first cover 1.c4 c5, and everything which does not transition to the Nf3 lines.
<G-vec00366-002-s262><cover.behandeln><de> Wir behandeln zuerst 1.c4 c5 und alles, was nicht zu den 1.Sf3-Varianten überleitet.
<G-vec00366-002-s263><cover.behandeln><en> Other topics cover a wide range of general interest subjects ranging from Russian cuisine to history.
<G-vec00366-002-s263><cover.behandeln><de> Weitere Themen behandeln ein weites Feld allgemein interessanter Aspekte von der russischen Küche bis hin zur Geschichte.
<G-vec00366-002-s264><cover.behandeln><en> We cover server choice and configuration in Chapter 6, Server Configuration, but the point we'd like to briefly make here is simply that the answers to some of these other questions might have implications that force your hand when deciding where your repository will live.
<G-vec00366-002-s264><cover.behandeln><de> Die Auswahl und Konfigurierung des Servers werden wir in Kapitel 6, Konfiguration des Servers behandeln; jedoch möchten wir an dieser Stelle kurz darauf hinweisen, dass die Antworten auf einige der anderen Fragen zur Folge haben, dass Sie bei der Entscheidung über den Speicherort für das Projektarchiv keine freie Wahl mehr haben.
<G-vec00366-002-s265><cover.behandeln><en> Therefore, library education courses cover "responsibly deal with information: avoid plagiarism" within the environment of the standard "effective use of information".
<G-vec00366-002-s265><cover.behandeln><de> Daher behandeln bibliothekspädagogische Kurse im Teil "Informationen verarbeiten" auch den Abschnitt "Verantwortungsbewusst mit Informationen umgehen: Plagiate vermeiden".
<G-vec00366-002-s399><cover.decken><en> Planetary gearboxes designed for Delta applications are available in 4 sizes and cover a ratio range of i=16-55.
<G-vec00366-002-s399><cover.decken><de> Das für Delta Applikationen konzipierte Planetengetriebe ist in 4 Baugrößen erhältlich und deckt den Übersetzungsbereich von i=16-55 ab.
<G-vec00366-002-s400><cover.decken><en> Insurance * shall cover claims which are subject to limitation pursuant to the 1996 convention * and shall provide cover up to the liability limitation thresholds laid down in that Convention.
<G-vec00366-002-s400><cover.decken><de> Die Versicherung * deckt Seeforderungen ab, die der Haftungsbeschränkung nach dem Übereinkommen von 1996 * unterliegen und muss eine Deckung bis zu den in diesem Übereinkommen vorgesehenen Haftungshöchstbeträgen gewährleisten.
<G-vec00366-002-s401><cover.decken><en> Suitable candidates are invited to attend an interview with the Academic Director which will cover the way that the PhD relates to and will help your professional development; and your knowledge and appreciation of current thinking in one or more areas of management.
<G-vec00366-002-s401><cover.decken><de> Geeignete Kandidaten werden aufgefordert, an einem Interview mit dem Lehrgangsleiter teilzunehmen, das die Art und Weise deckt, die das PhD Studium betrifft und Ihrer beruflichen Entwicklung hilft; und Ihr Wissen und Wertschätzung des gegenwärtigen Denkens in einem oder mehreren Bereichen der Verwaltung.
<G-vec00366-002-s402><cover.decken><en> This interview will cover how Oreganol P73 is beneficial for common health challenges.
<G-vec00366-002-s402><cover.decken><de> Dieses Interview deckt wie Oreganol P73 für häufige Gesundheitsprobleme von Vorteil ist.
<G-vec00366-002-s403><cover.decken><en> A high level of microfine light-diffusing pigments helps cover dark circles and blur the appearance of fine lines and wrinkles, leaving the eye area skin looking refreshed and youthfully bright. on any Elizabeth Arden products.
<G-vec00366-002-s403><cover.decken><de> Ein hoher Anteil an mikroskopischen, lichtbrechenden Pigmenten deckt Augenringe ab und verwischt feine Linien und Falten, damit die Haut der Augenpartie jugendlich strahlend und frisch wirkt.
<G-vec00366-002-s404><cover.decken><en> ‘The insurance referred to in Article 3(1) of [the First Directive] shall cover personal injuries and damage to property suffered by pedestrians, cyclists and other non-motorised users of the roads who, as a consequence of an accident in which a motor vehicle is involved, are entitled to compensation in accordance with national civil law. …’
<G-vec00366-002-s404><cover.decken><de> „Artikel 1a Die in Artikel 3 Absatz 1 der Richtlinie 72/166/EWG genannte Versicherung deckt Personen- und Sachschäden von Fußgängern, Radfahrern und anderen nicht motorisierten Verkehrsteilnehmern, die nach einzelstaatlichem Zivilrecht einen Anspruch auf Schadenersatz aus einem Unfall haben, an dem ein Kraftfahrzeug beteiligt ist.
<G-vec00366-002-s405><cover.decken><en> Health insurance with accident cover only insures treatment costs such as medical expenses, hospital costs and medication.
<G-vec00366-002-s405><cover.decken><de> Diese Krankenpflegeversicherung mit Unfalleinschluss deckt aber nur die anfallenden Heilungskosten wie Arzt- und Spitalkosten oder Medikamente.
<G-vec00366-002-s406><cover.decken><en> This Guarantee does not cover your data; any software or PlayStation games; any PlayStation peripherals; any PlayStation accessories; or any other peripherals or accessories.
<G-vec00366-002-s406><cover.decken><de> Diese Garantie deckt keine gespeicherten Daten, Software oder PlayStation-Spiele, keine PlayStation-Peripheriegeräte, kein PlayStation-Zubehör und keine anderen Peripheriegeräte oder Zubehör ab.
<G-vec00366-002-s407><cover.decken><en> Our warranty doesn’t cover wear from normal use.
<G-vec00366-002-s407><cover.decken><de> Die Apple-Garantie deckt keinen Verschleiß ab, der durch normalen Gebrauch entsteht.
<G-vec00366-002-s408><cover.decken><en> Mineralissima foundations even out your skin tone, cover imperfections, provide sun protection (all our foundations have a natural sunblock) yet feel weightless without drying out your skin.
<G-vec00366-002-s408><cover.decken><de> Mineralissima Foundations eignen sich auch für sehr empfindliche Haut, perfektioniert Ihren natürlichen Hautton, deckt kleine Makel ab und bietet Sonnenschutz.
<G-vec00366-002-s409><cover.decken><en> In the service field we cover every aspect of the traffic safety process chain – from system development, production and installation of the monitoring infrastructure to image capture and automated processing.
<G-vec00366-002-s409><cover.decken><de> Im Bereich der Dienstleistungen deckt Jenoptik die gesamte begleitende Prozesskette ab – von der Systementwicklung über den Aufbau und die Installation der Überwachungsinfrastruktur bis zur Aufnahme der Verstoßbilder und deren automatische Weiterverarbeitung.
<G-vec00366-002-s410><cover.decken><en> Clouds will cover all the Earth, but the light of God will illuminate you.
<G-vec00366-002-s410><cover.decken><de> Die Dunkelheit deckt die ganze Erde, aber das Licht Gottes erleuchtet euch.
<G-vec00366-002-s411><cover.decken><en> Our range of traditional and rapid detection solutions for pathogens cover both long-known disease agents and new ones such as E. coli O157, and we are constantly updating our portfolio as the need arises.
<G-vec00366-002-s411><cover.decken><de> Unser Angebot an Lösungen für den traditionellen und schnellen Nachweis von Pathogenen deckt sowohl klassische als auch neue Krankheitserreger wie E. coli O157 ab und wir aktualisieren unser Portfolio ständig nach den neuesten Erkenntnissen.
<G-vec00366-002-s412><cover.decken><en> The amount of compensable Damage shall cover redress of the Damage, as determined by amicable agreement, expert appraisal or the competent courts.
<G-vec00366-002-s412><cover.decken><de> Die Höhe des ersetzbaren Schadens deckt die Schadensersatzleistung, wie sie durch gütliche Einigung, auf dem Weg eines Sachverständigengutachtens oder durch die zuständigen Gerichte festgelegt wurde.
<G-vec00366-002-s413><cover.decken><en> The warranty covers normal consumer use and does not cover damage that occurs in shipment or failure that results from 11” alterations, accident, misuse, abuse, neglect, wear and tear, inadequate maintenance, commercial use, or unreasonable use of the unit.
<G-vec00366-002-s413><cover.decken><de> Die Garantie setzt einen normalen Gebrauch des Gerätes voraus und deckt keine, während des Transports hervorgerufenen Schäden oder Beschä-digun-gen hervorgerufen durch Änderungen am Produkt, unvorhergesehene Vorfälle, unsachgemäßen Gebrauch, Mißbrauch, Nachlässigkeit, frühzeitige Abnutzung und Beschädigung, unsachgemäbe Wartung, im Laden hervorgerufene Beschädigungen, unsachgemäße Handhabung.
<G-vec00366-002-s414><cover.decken><en> Recommendation: Arrange additional commercial insurance which can cover these fees before you travel.
<G-vec00366-002-s414><cover.decken><de> Empfehlung: Vereinbaren Sie vor Ihrer Reise eine zusätzliche private Versicherung, die diese Gebühren deckt.
<G-vec00366-002-s415><cover.decken><en> 008:016 "When any one lights a lamp, he does not cover it with a vessel or hide it under a couch; he puts it on a lampstand, that people who enter the room may see the light.
<G-vec00366-002-s415><cover.decken><de> Aufgabe der Jünger 16 Niemand zündet eine Lampe an und deckt sie mit einem Gefäß zu oder stellt sie unter das Lager, sondern setzt sie auf den Leuchter, damit die, die eintreten, das Licht sehen.
<G-vec00366-002-s416><cover.decken><en> The risk of just one single use is too high for the stand lessor as a single use does not cover the fabrication costs.
<G-vec00366-002-s416><cover.decken><de> Das Risiko eines nur einmaligen Einsatzes ist für den Standvermieter zu hoch, da ein einmaliger Einsatz die Kosten der Fertigung nicht deckt.
<G-vec00366-002-s417><cover.decken><en> We cover our capital requirements from net cash flow, and from short-term and long-term financing.
<G-vec00366-002-s417><cover.decken><de> WACKER deckt seinen Kapitalbedarf aus dem Netto-Cashflow sowie durch kurzfristige- und langfristige Finanzierungen.
<G-vec00366-002-s646><cover.umfassen><en> Our services cover everything, including consulting and analysis of the actual situation, constant and intensive project support, and delivery of flexible and user-oriented software and hardware.
<G-vec00366-002-s646><cover.umfassen><de> Unser Angebot umfasst alles von der Beratung und der Analyse des Ist-Zustandes über die ständige und intensive Projektbegleitung bis hin zur Lieferung flexibler und anwenderorientierter Software und Hardware.
<G-vec00366-002-s647><cover.umfassen><en> The price for the carriage services provided under the Contract of Carriage brokered by Us with the Selected Carrier(s) is included in the Full Price (Art. 3.1 hereof) and if not specifically ordered during the Booking it does not cover any extra services provided by the Selected Carrier in connection with the carriage to the Destination.
<G-vec00366-002-s647><cover.umfassen><de> Der Preis der Beförderungsleistungen unter dem durch uns vermittelten Beförderungsvertrag mit einer gewählten Fluggesellschaft ist im Gesamtpreis (Artikel 3.1 dieser AGB) enthalten und umfasst keinerlei zusätzliche Leistungen durch die gewählte Fluggesellschaft in Verbindung mit der Beförderung zum Zielort.
<G-vec00366-002-s648><cover.umfassen><en> They cover three years and are updated and revised on an annual basis.
<G-vec00366-002-s648><cover.umfassen><de> Es umfasst drei Jahre und wird jährlich aktualisiert und ergänzt.
<G-vec00366-002-s649><cover.umfassen><en> The main focus of "light engineering" studies cover lectures, tutorials and practical training in the range of...
<G-vec00366-002-s649><cover.umfassen><de> Der Studienschwerpunkt Lichttechnik umfasst Vorlesungen, Übungen und Praktika in den Bereichen...
<G-vec00366-002-s650><cover.umfassen><en> Our planning services cover our entire product range for painting, final assembly including all fill-up and test procedures, and efficient air pollution control.
<G-vec00366-002-s650><cover.umfassen><de> Unser Planungsangebot umfasst den gesamten Lieferumfang rund um die Lackierung, die Endmontage mit allen Befüll- und Prüfprozessen sowie die effiziente Abluftreinigung.
<G-vec00366-002-s651><cover.umfassen><en> 17 (1) Freedom of teaching shall cover, in the context of the teaching tasks to be fulfilled, the organisation of classes, seminars and lectures as regards their content and methodology and the right to express expert scientific and artistic opinions.
<G-vec00366-002-s651><cover.umfassen><de> 17 (1) Die Freiheit der Lehre umfasst im Rahmen der zu erfüllenden Lehraufgaben die inhaltliche und methodische Gestaltung von Lehrveranstaltungen sowie das Recht auf Äußerung von wissenschaftlichen und künstlerischen Lehrmeinungen.
<G-vec00366-002-s652><cover.umfassen><en> Quality inspections cover all relevant areas of the armoring process – disassembling, bending, welding, installation of the armor and bullet-proof glass, assembly – insuring that our armored cars have no visible or invisible flaws.
<G-vec00366-002-s652><cover.umfassen><de> Die Qualittskontrolle umfasst sämtliche relevanten Bereiche des Umbau- und Panzerungsprozesses - die Demontage, das Anbringen der Anbindungen, die Schweissarbeiten, die Montage der Panzerung und der Panzergläser, das Finishing - dabei wird stets garantiert, daß unsere Fahrzeuge weder sichtbare noch versteckte Mängel aufweisen.
<G-vec00366-002-s653><cover.umfassen><en> By submitting any information or material, you give the Company an unlimited and irrevocable license to use, execute, show, modify and transmit such information, Material or comments, including any underlying idea, concept or know-how (the term “Material” is intended to cover all projects, files or other attachments sent to us).
<G-vec00366-002-s653><cover.umfassen><de> Durch die Bereitstellung von Informationen oder Materialien gewähren Sie ein unbegrenztes und unwiderrufliches Lizenzrecht in Bezug auf die Nutzung, Umsetzung, Anzeige, Änderung und Übermittlung dieser Informationen, Materialien oder Kommentare, einschließlich aller zugrundeliegender Überlegungen, Konzepte oder des entsprechenden Know-hows (der Begriff "Material" umfasst alle uns übermittelten Projekte, Dateien oder sonstigen Anhänge).
<G-vec00366-002-s654><cover.umfassen><en> The first of which will cover the basic principles of the Price Action strategy and will be open to any traders who wish to attend.
<G-vec00366-002-s654><cover.umfassen><de> Der erste Teil umfasst die Grundprinzipien der Kursbewegungsstrategie und ist für alle interessierten Teilnehmer offen.
<G-vec00366-002-s655><cover.umfassen><en> PwC and asset control PwC's income tax advisory services cover all current tax matters.
<G-vec00366-002-s655><cover.umfassen><de> Das Dienstleistungsangebot von PwC im Bereich der Ertragsteuerberatung umfasst zum einen die gesamte laufende steuerliche Beratung.
<G-vec00366-002-s656><cover.umfassen><en> Please bear in mind, however, that it must be valid in Austria and provide sufficient cover for different health issues (covering medical costs of more than 30,000 euros, including guarantee to cover possible recovery and repatriation costs, and it must be valid for the whole duration of your stay in Austria).
<G-vec00366-002-s656><cover.umfassen><de> Hierbei ist aber zu beachten, dass der Gültigkeitsbereich Österreich umfasst und ausreichender Schutz für verschiedene Krankheitsfälle gegeben ist (Deckungssumme deutlich über 30.000 Euro, mit Garantie der Übernahme etwaiger Berge- und Rückführungskosten, für die gesamte Aufenthaltsdauer gültig).
<G-vec00366-002-s657><cover.umfassen><en> Objectives The investment is planned to cover schemes in both of SGN’s networks—the Scotland Gas Networks business (i.e. all of Scotland) and the Southern Gas Networks business (i.e. southern England).
<G-vec00366-002-s657><cover.umfassen><de> Ziele Das Projekt umfasst Investitionen in beiden SGN-Netzen - sowohl im Scotland Gas Network (d.h. in ganz Schottland) als auch im Southern Gas Network (d.h. im Süden Englands).
<G-vec00366-002-s658><cover.umfassen><en> Its innovative range of services cover the entire property life cycle.
<G-vec00366-002-s658><cover.umfassen><de> Das innovative Dienstleistungsangebot umfasst den gesamten Lebenszyklus von Immobilien.
<G-vec00366-002-s659><cover.umfassen><en> The activities of Dayland Group cover all aspects of project development, including site selection, construction and leasing, as well as marketing and operation.
<G-vec00366-002-s659><cover.umfassen><de> Der Tätigkeitsbereich der Dayland Group umfasst die gesamte Projektentwicklung, im Speziellen die Standortauswahl, die Errichtung sowie die Vermietung bis hin zu Marketing und Betrieb.
<G-vec00366-002-s660><cover.umfassen><en> ESPON activities cover all EU Member States, plus Iceland, Liechtenstein, Norway and Switzerland, and involve more than 130 bodies across the continent.
<G-vec00366-002-s660><cover.umfassen><de> Das Netz umfasst alle EU-Mitgliedstaaten sowie Island, Liechtenstein, Norwegen und die Schweiz und besteht aus mehr als 130 Einrichtungen in ganz Europa.
<G-vec00366-002-s661><cover.umfassen><en> Lissoni and his multinational team thus comprehensively cover the areas of architecture, interior and product design, graphics, art direction and corporate identity.
<G-vec00366-002-s661><cover.umfassen><de> Mit seinem multinationalen Team umfasst Lissoni die Bereiche Architektur, Innenausstattung, Theater, Restaurants und Hotels, Boote, Läden, Verkaufsräume, Kunstausstellungen, Messestände, Innenausstattungen und Beleuchtung.
<G-vec00366-002-s662><cover.umfassen><en> Jansen services cover a wide and detailed field including testing, calculations and dimensioning.
<G-vec00366-002-s662><cover.umfassen><de> Der Service von Jansen umfasst ein detailliertes Spektrum mit Prüfungen, Berechnungen und Dimensionierung.
<G-vec00366-002-s663><cover.umfassen><en> Sexuality does cover a wider range than body parts and wider range of astrological possibilities than Scorpio or Mars.
<G-vec00366-002-s663><cover.umfassen><de> Sexualität umfasst ein viel breiteres Spektrum als Körperteile, und ein viel breiteres Spektrum astrologischer Zuordnungen als Skorpion oder Mars.
<G-vec00366-002-s664><cover.umfassen><en> Our products cover the entire range of functional and decorative electroplating technology, including the planning of new systems or the modification of existing plants.
<G-vec00366-002-s664><cover.umfassen><de> Unsere Produktpalette umfasst den gesamten Bereich der funktionellen und dekorativen Galvanotechnik, einschließlich Planung von Neuanlagen oder Umbau bereits bestehender Anlagen.
<G-vec00366-002-s722><cover.übernehmen><en> As public health funds are only permitted to cover a part of the cost – not the full cost – private dental cover is important for those who set a great store by modern and comprehensive dental care.
<G-vec00366-002-s722><cover.übernehmen><de> Da die gesetzlichen Krankenversicherungen die Kosten für Zahnersatz nur sehr eingeschränkt übernehmen dürfen, ist eine private Zusatzversicherung für alle diejenigen wichtig, die Wert auf eine zeitgemäße und leistungsstarke zahnmedizinische Versorgung legen.
<G-vec00366-002-s723><cover.übernehmen><en> There is a more affordable alternative: The moneyland.ch survey found that many banks cover the cost of transferring securities – either in whole or in part – for new customers.
<G-vec00366-002-s723><cover.übernehmen><de> Es gibt aber eine günstigere Alternative: Viele Banken übernehmen die Transfergebühren für einzelne neue Kunden nach einer individuellen Beurteilung ganz oder teilweise, wie die Umfrage von moneyland.ch ergeben hat.
<G-vec00366-002-s724><cover.übernehmen><en> The warranty for the DS/3DS, if something should happen during installation, we cover.
<G-vec00366-002-s724><cover.übernehmen><de> Die Haftung für Schäden an eurem DS/3DS, falls wir etwas beim Einbau beschädigen sollten, übernehmen wir.
<G-vec00366-002-s725><cover.übernehmen><en> Gross negligence waiver: We cover the costs of the damage, even if you are guilty of gross negligence – for example if you pass a red traffic light on your bike and cause an accident as a result, or if you cause a fire because you went to sleep with a lit cigarette.
<G-vec00366-002-s725><cover.übernehmen><de> Grobfahrlässigkeitsverzicht: Wir übernehmen die Schadenkosten auch, wenn Sie grob fahrlässig handeln – also beispielsweise mit dem Velo bei Rot weiterfahren und dadurch einen Unfall verursachen oder einen Brand entfachen, weil Sie mit der brennenden Zigarette eingeschlafen sind.
<G-vec00366-002-s726><cover.übernehmen><en> To get there from Luisenplatz we will take the tram 5 at 5:08 pm direction Kranichstein.Entrance fee: 5€ (we cover the rest.
<G-vec00366-002-s726><cover.übernehmen><de> Anfahrt vom Luisenplatz um 17:08 Uhr mit der Straßenbahn 5 Richtung Kranichstein.Eintritt: 5€ (Wir übernehmen den Rest.
<G-vec00366-002-s727><cover.übernehmen><en> While private health insurance companies sometimes contribute to the cost after submitting the invoice, the statutory health insurance funds do not cover the treatment cost of gold therapy since scientific studies are lacking.
<G-vec00366-002-s727><cover.übernehmen><de> Während sich private Krankenversicherungen nach Einreichen der Rechnung manchmal an den Kosten beteiligen, übernehmen die gesetzlichen Kassen die Behandlungskosten der Goldtherapie aufgrund fehlender wissenschaftlicher Studien grundsätzlich nicht.
<G-vec00366-002-s728><cover.übernehmen><en> They are also reviewing whether health insurance funds might cover the costs in future.
<G-vec00366-002-s728><cover.übernehmen><de> Zudem wird geprüft, ob in Zukunft Krankenkassen die Kosten übernehmen.
<G-vec00366-002-s729><cover.übernehmen><en> We have a limited possibility to cover travel expenses.
<G-vec00366-002-s729><cover.übernehmen><de> Wir haben eine begrenzte Möglichkeit, Reisekosten zu übernehmen.
<G-vec00366-002-s730><cover.übernehmen><en> There are major differences as to whether and to what extent public cost carriers cover or refund direct access treatment costs.
<G-vec00366-002-s730><cover.übernehmen><de> Ob und in welchem Umfang öffentliche Kostenträger in diesen Staaten die Behandlungskosten im Direktzugang übernehmen oder erstatten, ist sehr unterschiedlich.
<G-vec00366-002-s731><cover.übernehmen><en> We cover the cost of repairing your system or replacing the preselected components should they fail.
<G-vec00366-002-s731><cover.übernehmen><de> Wir übernehmen die Kosten für die Reparatur Ihres Systems oder für den Ersatz von ausgewählten Komponenten, wenn sie ausfallen.
<G-vec00366-002-s732><cover.übernehmen><en> For instance, if you deposit USD 100 by Moneybookers and then withdraw USD 100, you will see the full amount of USD 100 in your Moneybookers account as we cover all transaction fees both ways for you.
<G-vec00366-002-s732><cover.übernehmen><de> Wenn Sie beispielsweise 100 USD per Moneybookers einzahlen und dann 100 USD auszahlen lassen, erhalten Sie auf Ihrem Moneybookers-Konto den vollen Betrag in Höhe von 100 USD, weil wir die Transaktionsgebühren in beide Richtungen für Sie übernehmen.
<G-vec00366-002-s733><cover.übernehmen><en> Some universities cover the handling costs for their applicants.
<G-vec00366-002-s733><cover.übernehmen><de> Einige Hochschulen übernehmen die Bearbeitungskosten für ihre Bewerberinnen und Bewerber.
<G-vec00366-002-s734><cover.übernehmen><en> We cover 100% of the costs for design and gluing (no hidden costs).
<G-vec00366-002-s734><cover.übernehmen><de> Die Kosten für Design und Bekleben übernehmen wir zu 100% (keine versteckten Kosten).
<G-vec00366-002-s735><cover.übernehmen><en> Private insurances cover the cost of annual skin cancer screenings at any age.
<G-vec00366-002-s735><cover.übernehmen><de> Die privaten Krankenkassen übernehmen die Kosten des Hautkrebs-Screenings in jedem Lebensalter in jährlichen Abständen.
<G-vec00366-002-s736><cover.übernehmen><en> For Germany, the proceedings are as following: Basically if the indication is appropriate, the health insurance funds cover the costs for aids listed in the aids directory of the GKV Association (central interest group of the statutory health and nursing insurance funds in Germany).
<G-vec00366-002-s736><cover.übernehmen><de> Grundsätzlich übernehmen die Krankenkassen bei entsprechender Indikation die Kosten für Hilfsmittel, die im Hilfsmittelverzeichnis des GKV Spitzenverbandes (Zentrale Interessenvertretung der gesetzlichen Kranken- und Pflegekassen in Deutschland) gelistet sind.
<G-vec00366-002-s737><cover.übernehmen><en> In this capacity, the company will cover sales and client relationship management, as well as project delivery and business process consulting to Danish businesses.
<G-vec00366-002-s737><cover.übernehmen><de> In dieser Funktion wird die Firma den Vertrieb und die Kundenbetreuung sowie die Projektlieferung und die Businessprozess-Beratung für dänische Unternehmen übernehmen.
<G-vec00366-002-s738><cover.übernehmen><en> Meal & Beverage – If a Flight Change leads to your flight(s) being delayed by more than 4 hours, We will cover the cost of meal and beverages up to a total of 10 HKD per passenger covered by the Connection Guarantee.
<G-vec00366-002-s738><cover.übernehmen><de> Speisen und Getränke: Wenn eine Flugänderung zu einer Verspätung Ihres Flugs oder Ihrer Flüge um mehr als 4 Stunden führt, übernehmen wir die Kosten für Speisen und Getränke in Höhe von insgesamt maximal 10 CHF pro Fluggast, für den die Anschlussgarantie gilt.
<G-vec00366-002-s739><cover.übernehmen><en> Upon our request, rejected goods should be sent back to us in sufficient quantities for examination; we will cover the shipping costs where reported defects are proven to be justified.
<G-vec00366-002-s739><cover.übernehmen><de> Beanstandete Ware ist auf Verlangen in ausreichender Stückzahl an uns zur Befundung zurückzusenden; wir übernehmen die Transportkosten, wenn sich die Mängelrüge als richtig erweist.
<G-vec00366-002-s740><cover.übernehmen><en> Awareness-raising For fishing gear, which accounts for 27% of sea litter, producers would need to cover the costs of waste management from port reception facilities.
<G-vec00366-002-s740><cover.übernehmen><de> So werden Hersteller kunststoffhaltiger Fanggeräte die Kosten für das Einsammeln der Abfälle aus den Hafenauffangeinrichtungen sowie den Transport und die Behandlung dieser Abfälle übernehmen müssen.
<G-vec00872-002-s057><cover.abdecken><en> Pour into a bowl and cover with plastic wrap, so that no skin is forming.
<G-vec00872-002-s057><cover.abdecken><de> In eine Schüssel geben und mit Frischhaltefolie abdecken, so dass sich keine Haut bildet.
<G-vec00872-002-s058><cover.abdecken><en> Bio-on biopolymers have extraordinary properties that adapt to the injection and extrusion methods currently in use in the plastic industry and can cover a vast range of strategic applications: biomedical, packaging, design, clothing, automotive and more.
<G-vec00872-002-s058><cover.abdecken><de> Die Biopolymere der Firma Bio-on weisen hervorragende Eigenschaften auf, die sich für die derzeit in der Kunststoffindustrie gebräuchlichen Spritzguss- und Extrusionsverfahren eignen und ein vielfältiges Gebiet strategischer Anwendungsfelder abdecken: Biomedizin, Verpackung, Design, Bekleidungsindustrie, Automobilbranche etc.
<G-vec00872-002-s059><cover.abdecken><en> GEA will thus be in an even better position to cover the various customer requirements with the ideal pump solution from its own broad product portfolio.
<G-vec00872-002-s059><cover.abdecken><de> GEA wird dadurch noch besser in der Lage sein, die unterschiedlichen Kundenanforderungen mit der idealen Pumpenlösung aus dem eigenen, breiten Produktportfolio abdecken zu können.
<G-vec00872-002-s061><cover.abdecken><en> 4D for iOS already provides various list and detail form templates to cover most of your needs.
<G-vec00872-002-s061><cover.abdecken><de> 4D for iOS bietet bereits verschiedene Templates für Listen- oder Detail-Formulare, die gängige Anforderungen abdecken.
<G-vec00872-002-s062><cover.abdecken><en> SDG was brought in to support the development team in creating a business plan for the new technology—a plan that would cover the technical as well as the commercial details.
<G-vec00872-002-s062><cover.abdecken><de> Die SDG wurde beauftragt, das Entwicklungsteam bei der Erstellung eines Geschäftsplans für die neue Technologie zu unterstützen, der sowohl die technischen als auch die kommerziellen Faktoren abdecken sollte.
<G-vec00872-002-s063><cover.abdecken><en> Cover the dish with a cloth and leave to rest for another 15 minutes in a warm place.
<G-vec00872-002-s063><cover.abdecken><de> Die Form mit einem Tuch abdecken und nochmals an einem warmen Ort 15 Minuten rasten lassen.
<G-vec00872-002-s064><cover.abdecken><en> By having Dr. Stangl on board, we're pleased we're able to cover and expand our expertise in this increasingly important area of public commercial law" explains Dr. Hans Kristoferitsch (Head of the Public Commercial & European Law practice group at CHSH).
<G-vec00872-002-s064><cover.abdecken><de> Wir freuen uns, mit ihm auch diesen immer wichtigeren Bereich des öffentlichen Wirtschaftsrechts abdecken und ausbauen zu können“ freut sich Dr. Hans Kristoferitsch (Leiter der Praxisgruppe Öffentliches Wirtschaftsrecht bei CHSH).
<G-vec00872-002-s065><cover.abdecken><en> Once the curry is beginning to boil again, add 1 tsp of salt, garam masala, chicken pieces and all the juices from the bowl to the skillet, partially cover the skillet, reduce the heat and gently simmer the curry for 15 minutes
<G-vec00872-002-s065><cover.abdecken><de> Tomatenstücke und Joghurt dazugeben, das Curry umrühren und mit dem Deckel abdecken Sobald das Curry wieder anfängt zu kochen, die Hitze auf niedrig reduzieren und das Curry 15 Minuten lang leicht köcheln lassen.
<G-vec00872-002-s066><cover.abdecken><en> Just cover them with plastic wrap and store the baking dish in the fridge for up to 24 hours.
<G-vec00872-002-s066><cover.abdecken><de> Hierzu die Auflaufform einfach mit Frischhaltefolie abdecken und bis zu 24 Stunden im Kühlschrank aufbewahren.
<G-vec00872-002-s067><cover.abdecken><en> Combined with solar collectors and a storage system, the "solar fireplace system" can cover up to 100 % of a household's hot water demand.
<G-vec00872-002-s067><cover.abdecken><de> In Kombination mit einer Solaranlage und einem Speicher kann das Solar-Kaminsystem bis zu 100 Prozent des Warmwasserbedarfes für den gesamten Wohnbereich abdecken.
<G-vec00872-002-s068><cover.abdecken><en> Cover the bowl with cheesecloth and let the dough rise in a cool place until the volume increases by half, about 1½ hours. Lightly flour a work surface.
<G-vec00872-002-s068><cover.abdecken><de> Schritt 2 Die Schüssel mit einem Küchentuch abdecken und den Hefeteig etwa 1 Stunde an einem warmen Ort ruhen lassen, bis er etwa doppelt so hoch aufgegangen ist.
<G-vec00872-002-s069><cover.abdecken><en> Thanks to the newly developed purple ink, they have superior red shades that cover a wider spectrum.
<G-vec00872-002-s069><cover.abdecken><de> Dank der neuentwickelten Magenta-Tinte kriegen Sie auch bessere Rottöne, die ein breites Spektrum abdecken.
<G-vec00872-002-s070><cover.abdecken><en> The advantage is that I can cover the cardboard and the painting has enough time to dry slowly.
<G-vec00872-002-s070><cover.abdecken><de> Der Vorteil ist, dass ich den Karton abdecken kann und das Bild somit genügend Zeit hat langsam zu trocknen.
<G-vec00872-002-s071><cover.abdecken><en> After a few minutes, take the pan off the heat and cover with a cloth.
<G-vec00872-002-s071><cover.abdecken><de> Nach einigen Minuten die Pfanne vom Herd nehmen und mit einem Tuch abdecken.
<G-vec00872-002-s072><cover.abdecken><en> The insulation must not cover the vents.
<G-vec00872-002-s072><cover.abdecken><de> Die Isolierung darf die Lüftungsöffnungen nicht abdecken.
<G-vec00872-002-s073><cover.abdecken><en> With the ZLT200 we introduce a series of multi-purpose lasers that cover all the range from machine control, site work, pipe laying to interior finishing.
<G-vec00872-002-s073><cover.abdecken><de> Mit ZLT200 führen wir eine Reihe von Multifunktionslasern ein, die den gesamten Bereich von Maschinensteuerung, Baustellenarbeiten, Leitungsverlegung bis zum Innenausbau abdecken.
<G-vec00872-002-s074><cover.abdecken><en> The alliance offers solutions that cover the entire spectrum of information supply and data analysis: a unique combination of literature and information supply with the computer-aided analysis of large amounts of data.
<G-vec00872-002-s074><cover.abdecken><de> Die Allianz bietet Lösungen, die das gesamte Spektrum der Informationsversorgung und Datenanalyse abdecken: eine einmalige Kombination aus Literatur- und Informationsversorgung mit der computergestützten Analyse großer Datenmengen.
<G-vec00872-002-s075><cover.abdecken><en> Important is to inform the beekeeper beforehand about intended pesticide applications and the nature of the applied products, so he can cover or remove hives used for managed pollination during application.
<G-vec00872-002-s075><cover.abdecken><de> Es ist wichtig, den Imker vorher über die beabsichtigten Pestizidanwendungen und die Art der verwendeten Produkte zu informieren, damit er die für die kontrollierte Bestäubung verwendeten Bienenstöcke während der Anwendung abdecken oder entfernen kann.
<G-vec00872-002-s114><cover.abdecken><en> Greater standardization, less equipment diversity, fewer non-standard developments, vastly simplified quotation and planning process – all of these factors weigh into the calculation, as do higher sales expectations compared to the Siedle Multi system which used to cover comparable requirements in the past.
<G-vec00872-002-s114><cover.abdecken><de> Größere Standardisierung, weniger Gerätevielfalt, weniger Sonderentwicklungen, stark vereinfachte Angebote und Planungen – das alles geht in die Kalkulation ein, ebenso die höheren Absatzerwartungen gegenüber dem System Siedle-Multi, mit dem wir bisher vergleichbare Anforderungen abgedeckt haben.
<G-vec00872-002-s115><cover.abdecken><en> Solutions Cover the silage as soon as rolling has been completed
<G-vec00872-002-s115><cover.abdecken><de> Ein weiterer Grund ist, dass die Silage stark zeitverzögert abgedeckt wurde.
<G-vec00872-002-s116><cover.abdecken><en> In addition, the range of subsidies should be extended to cover all relevant livestock species.
<G-vec00872-002-s116><cover.abdecken><de> Zudem sollte das Förderspektrum so ausgeweitet werden, dass alle relevanten Nutztierarten abgedeckt werden.
<G-vec00872-002-s117><cover.abdecken><en> Cover the dough and leave for 30 minutes.
<G-vec00872-002-s117><cover.abdecken><de> Abgedeckt 30 Minuten ruhen lassen.
<G-vec00872-002-s118><cover.abdecken><en> The intelligent and creative use of a variety of light sources can cover a wide range of different needs in an uncompromising and aesthetic way.
<G-vec00872-002-s118><cover.abdecken><de> Durch intelligenten und kreativen Einsatz verschiedener Lichtquellen können innerhalb eines Raumkonzepts ohne Kompromisse unterschiedliche Bedürfnisse abgedeckt werden.
<G-vec00872-002-s119><cover.abdecken><en> A solar system of this type can cover about half of your hot water needs.
<G-vec00872-002-s119><cover.abdecken><de> Durch eine solche Anlage kann etwa die Hälfte des Warmwasserbedarfs durch Sonnenenergie abgedeckt werden.
<G-vec00872-002-s120><cover.abdecken><en> The different types (MBF, MCB, MCR, MVG, Custom Design) cover a wide range of applications – from small to large diameters and from low to high bore depths.
<G-vec00872-002-s120><cover.abdecken><de> Durch die unterschiedlichen Typen (MBF, MCB, MCR, MVG, Custom Design) wird ein breites Anwendungsspektrum abgedeckt - von kleinen bis großen Durchmessern und von geringen bis hohen Bohrungstiefen.
<G-vec00872-002-s121><cover.abdecken><en> The GAIN trimmer with protective cover allows you to adjust the input sensitivity of the microphone.
<G-vec00872-002-s121><cover.abdecken><de> Mit dem GAIN-Trimmer, der mit einer Schutzkappe abgedeckt ist, lässt sich die Eingangsempfindlichkeit des Mikrofons anpassen.
<G-vec00872-002-s122><cover.abdecken><en> For most consignments, this amount does not cover the total value of the shipment.
<G-vec00872-002-s122><cover.abdecken><de> Für die meisten Transporte ist der Gesamtwert der Sendung damit nicht abgedeckt.
<G-vec00872-002-s123><cover.abdecken><en> In environmental terms, the preferred option is to cover all flights departing from EU airports, as limiting the scope to “intra-EU” flights, which both depart and land in the EU, would address less than 40%[10] of the emissions from all flights departing from the EU.
<G-vec00872-002-s123><cover.abdecken><de> Nach der vom Umweltgesichtspunkt her bevorzugten Option sollten alle von EU-Flughäfen ausgehenden Flüge abgedeckt sein.. Eine Einengung auf Flüge „innerhalb der EU“, die sowohl in der EU abfliegen als auch landen, würde weniger als 40%[10] der Emissionen von allen aus der EU startenden Flügen bedeuten.
<G-vec00872-002-s124><cover.abdecken><en> Single sign-on might not cover all use cases.
<G-vec00872-002-s124><cover.abdecken><de> Durch Single-Sign-On sind möglicherweise nicht alle Anwendungsfälle abgedeckt.
<G-vec00872-002-s125><cover.abdecken><en> Click here to see our three levels of priority cover.
<G-vec00872-002-s125><cover.abdecken><de> Klicken Sie hier, um zu sehen, was von unseren drei Prioritätsebenen abgedeckt ist.
<G-vec00872-002-s126><cover.abdecken><en> Whilst the ingredients mentioned above cover the nutritional needs of human embryos, vitamins such as C, E, B2, B5 and B6 are also commonly added. They play an antioxidant role and stop and/or decrease the production of free radicals.
<G-vec00872-002-s126><cover.abdecken><de> Obwohl mit den oben bezeichneten Komponenten die Ernährungsbedürfnisse der menschlichen Embryonen abgedeckt wurden, ist auch die Zugabe von Vitaminen wie C, E, B2, B5 oder B6 üblich, und zwar aufgrund ihrer Wirkung als Antioxidantien, womit sie die Produktion von freien Radikalen verhindern und/oder verringern.
<G-vec00872-002-s127><cover.abdecken><en> Apply once a week an avocado mask over the hair, cover with a bathing cap and let it act for half an hour before washing normally, you can also use argan oil to help soften and moisturize mistreated hair.
<G-vec00872-002-s127><cover.abdecken><de> Wenden Sie einmal pro Woche eine Maske aus Avocado auf die Haare, mit einer Duschhaube abgedeckt und lassen Sie für eine halbe Stunde stehen, vor dem normalen Waschen, Sie können auch Arganöl verwenden, um empfindliches und strapaziertes Haar zu behandeln.
<G-vec00872-002-s128><cover.abdecken><en> Building on our comprehensive test methodology for classical and agile procedures, we cover the entire application life cycle from the initial requirements through going live to regular maintenance and upgrade cycles.
<G-vec00872-002-s128><cover.abdecken><de> Aufbauend auf unserer vollumfänglichen Testmethologie für klassische und agile Vorgehensweisen wird der ganze Application-Lifecycle von der Anforderung, über die Produktivsetzung bis zu den regelmäßigen Wartungs- und Erweiterungszyklen abgedeckt.
<G-vec00872-002-s129><cover.abdecken><en> But, for it to move from the margins into the mainstream, Impact Investing needs to reach all types of investors and cover all asset classes.
<G-vec00872-002-s129><cover.abdecken><de> Damit sich Impact Investing endgültig zu einem Mainstream-Anlageansatz entwickeln kann, müssen indes alle Anlegerkategorien erreicht und sämtliche Anlageklassen abgedeckt werden.
<G-vec00872-002-s131><cover.abdecken><en> This howto is a practical guide without any warranty - it doesn't cover the theoretical backgrounds.
<G-vec00872-002-s131><cover.abdecken><de> Diese Anleitung ist ein praktischer Leitfaden ohne jegliche Garantie - theoretisches Hintergrundwissen wird nicht abgedeckt.
<G-vec00872-002-s132><cover.abdecken><en> Cover and store in the refrigerator until ready to serve.
<G-vec00872-002-s132><cover.abdecken><de> Die Rouladen bis zur Verwendung abgedeckt im Kühlschrank aufbewahren.
<G-vec00872-002-s133><cover.abdecken><en> It is widely used to cover the wires, cables, wire harnesses, pipes and industrial hoses where the additional protection and high flame retardant are required.
<G-vec00872-002-s133><cover.abdecken><de> Es ist weit verbreitet, um die Drähte, Kabel, Kabelbäume, Rohre und Industrieschläuche abzudecken, wo der zusätzliche Schutz und das hohe Flammschutzmittel erforderlich sind.
<G-vec00872-002-s134><cover.abdecken><en> Together with its affiliated companies D-Trust GmbH and Maurer Electronics GmbH, the Bundesdruckerei Group is today in a position to meet market demand for full-scale one-stop solutions and to cover the entire value chain of state-of-the-art ID systems.
<G-vec00872-002-s134><cover.abdecken><de> Gemeinsam mit den Konzernunternehmen D-TRUST GmbH und Maurer Electronics GmbH ist die Bundesdruckerei-Gruppe heute in der Lage, marktgerechte Komplettlösungen aus einer Hand anzubieten und so die gesamte Wertschöpfungskette moderner ID-Systeme abzudecken.
<G-vec00872-002-s135><cover.abdecken><en> Furthermore, there is another type of PE tarpaulin, which is reinforced, clear, and especially well-suited to cover boat among other things.
<G-vec00872-002-s135><cover.abdecken><de> Außerdem gibt es einen weiteren durchsichtigen und verstärkten Typ der PE-Plane, der sich vor allem eignet, um Boote und andere Gegenstände abzudecken.
<G-vec00872-002-s136><cover.abdecken><en> To cover a broad gradient of land-use intensity defined by fertilization, mowing and grazing intensity, 150 grassland sites have been sampled.
<G-vec00872-002-s136><cover.abdecken><de> Um einen breiten Landnutzungsgradienten abzudecken, der durch die Intensität von Düngung, Mahd und Beweidung definiert wird, wurden 150 Grünlandflächen beprobt.
<G-vec00872-002-s137><cover.abdecken><en> Furthermore, Sysmex companion diagnostics (CDx) team offers services for the development of non-invasive cell-free DNA-based IVD tests supported by a growing network of partners to cover the entire IVD development process.
<G-vec00872-002-s137><cover.abdecken><de> Um den gesamten IVD-Entwicklungsprozess abzudecken, bietet das Companion-Diagnostics-Team von Sysmex Inostics, unterstützt von einem wachsenden Netzwerk von Partnern, außerdem Dienstleistungen für die Entwicklung nicht-invasiver, zellfreier DNA-basierter IVD-Tests an.
<G-vec00872-002-s138><cover.abdecken><en> To ensure a long service life, we advise you to cover the lounge set with a garden furniture cover in bad weather.
<G-vec00872-002-s138><cover.abdecken><de> Um eine lange Lebensdauer zu garantieren, empfehlen wir, das Loungeset bei schlechtem Wetter mit einem Gartenmöbel-Schutzüberzug abzudecken.
<G-vec00872-002-s139><cover.abdecken><en> The G-DRIVE minis and G-RAID with Thunderbolt are sufficient to cover most of Leitner’s storage needs in the field.
<G-vec00872-002-s139><cover.abdecken><de> Die G-DRIVE minis und G-RAID mit Thunderbolt sind ausreichend, um unterwegs die meisten Speicherbedürfnisse von Leitner abzudecken.
<G-vec00872-002-s140><cover.abdecken><en> Flying once over the Saarland Informatics Campus: Five international research institutes and three networked departments of Saarland University combine their expertise here to cover the entire spectrum of computer science.
<G-vec00872-002-s140><cover.abdecken><de> Einmal über den Saarland Informatics Campus fliegen: Fünf internationale Forschungsinstitute und drei vernetzte Fachrichtungen der Universität des Saarlandes bündeln hier ihre Kompetenzen, um das gesamte Spektrum der Informatik abzudecken.
<G-vec00872-002-s141><cover.abdecken><en> This calculator assumes that warranties are paid in advance to cover the replacement cost of a computer for three years.
<G-vec00872-002-s141><cover.abdecken><de> Bei dieser Berechnung wird vorausgesetzt, dass Gewährleistungen im Voraus gezahlt werden, um die Kosten für einen Ersatzcomputer alle drei Jahre abzudecken.
<G-vec00872-002-s142><cover.abdecken><en> This makes Siemens the first provider to be able to cover all of today’s demands for efficient and safe buildings using a single system.
<G-vec00872-002-s142><cover.abdecken><de> Damit ist Siemens als erster Anbieter überhaupt in der Lage, alle Anforderungen, die heute an effizient und sicher betriebene Gebäude gestellt werden, aus einem einzigen System abzudecken.
<G-vec00872-002-s143><cover.abdecken><en> Whether you want to follow proper etiquette, learn how to get the most out of your experience, or eat well during your meal, eating at a buffet is pretty simple and often worth it if you eat enough to cover the cost of food. Steps
<G-vec00872-002-s143><cover.abdecken><de> Du kannst lernen, den richtigen Benimmregeln zu folgen, wie du am meisten aus der Erfahrung herausholst oder wie du während der Mahlzeit gut isst, sodass bei einem Buffet zu essen ziemlich einfach wird und oft den Preis wert ist, wenn du genug isst, um die Kosten des Essens abzudecken.
<G-vec00872-002-s144><cover.abdecken><en> It is possible to cover all the nails with a varnish of one tone.
<G-vec00872-002-s144><cover.abdecken><de> Es ist möglich, alle Nägel mit einem Ton in einem Ton abzudecken.
<G-vec00872-002-s145><cover.abdecken><en> Add Intelligent dimmable control units and lamps to reduce energy consumption in case of long operating times and even cover and enhance ancillary areas such as corridors, stairways and basement garages.
<G-vec00872-002-s145><cover.abdecken><de> Fügen Sie intelligente dimmbare Steuergeräte und Lampen hinzu, um den Energieverbrauch bei langen Betriebszeiten zu reduzieren und sogar Nebenbereiche wie Flure, Treppenhäuser und Tiefgaragen abzudecken und zu verbessern.
<G-vec00872-002-s146><cover.abdecken><en> The goal is to cover all potential users of an application, a product or a system as extensively as possible.
<G-vec00872-002-s146><cover.abdecken><de> Das Ziel hierbei ist es immer, die potentiellen Benutzer einer Applikation, eines Produkts oder eines Systems möglichst umfassend abzudecken.
<G-vec00872-002-s147><cover.abdecken><en> When this symbol lands it expands to cover all three positions on the reel after the initial payout is calculated.
<G-vec00872-002-s147><cover.abdecken><de> Wenn dieses Symbol erscheint, dehnt es sich aus, um alle drei Positionen auf der Walze abzudecken, nachdem die anfängliche Auszahlung berechnet wurde.
<G-vec00872-002-s148><cover.abdecken><en> The Supplier Code represents a further level of these Codes and helps us to cover the supply chain with regard to the farms, the factories and the retailers as well.
<G-vec00872-002-s148><cover.abdecken><de> Der Lieferantenkodex stellt eine weitere Ebene dieser Kodizes dar und hilft uns, auch unsere vorgelagerte Lieferkette in Form unserer Lieferanten abzudecken.
<G-vec00872-002-s149><cover.abdecken><en> Busuu users only need to study an average of 22 hours over 2 months to cover the requirements for one college semester of Spanish.
<G-vec00872-002-s149><cover.abdecken><de> Busuu-Mitglieder brauchen im Schnitt nur 22 Lernstunden in zwei Monaten, um den Stoff eines gesamten Semesters Spanisch an der Universität abzudecken.
<G-vec00872-002-s150><cover.abdecken><en> For example, the museum’s decision from 2000 to use the maintenance funds to cover the expenses of an exhibition in Japan and the decision to build a café with the rent received for a wedding party held in the museum in 1998 instead of using the money to repair the roof led to a real catastrophe.
<G-vec00872-002-s150><cover.abdecken><de> Zum Beispiel führte die Entscheidung des Museums im Jahr 2000, die Erhaltungsressourcen dafür zu verwenden, die Kosten einer Ausstellung in Japan abzudecken, und die Entscheidung, mit der Miete einer Hochzeitsfeier, die 1998 im Museum abgehalten wurde, ein Café zu bauen, anstatt das Geld dafür zu verwenden, das Dach zu reparieren, zu einer wahrhaften Katastrophe.
<G-vec00872-002-s151><cover.abdecken><en> Another important function of the solder mask is to cover all traces, i.e. to isolate.
<G-vec00872-002-s151><cover.abdecken><de> Eine andere wichtige Funktion der Lötstoppmaske ist alle Leiterbahnen abzudecken, d.h. zu isolieren.
<G-vec00872-002-s380><cover.abdecken><en> Whether you want to do a beach holiday in the sun or hiking in the mountains - our trips cover a huge range of preferences.
<G-vec00872-002-s380><cover.abdecken><de> Ob Sie Ihren Spontanurlaub am Strand in der Sonne oder bei Wanderungen in den Bergen verbringen möchten – unsere Reisen decken eine große Bandbreite an Vorlieben ab.
<G-vec00872-002-s381><cover.abdecken><en> We design systems from a single source and cover all areas of paper manufacturing.
<G-vec00872-002-s381><cover.abdecken><de> Wir konzipieren Anlagen aus einer Hand und decken alle Bereiche der Papierherstellung ab.
<G-vec00872-002-s382><cover.abdecken><en> And because Flickr photos cover a range of subject matter – and are available in rights-managed and royalty-free licenses – you'll find options to meet the creative and budgetary needs of all your projects.
<G-vec00872-002-s382><cover.abdecken><de> Die Flickr-Bilder decken eine Fülle von Themen ab, sind im lizenzpflichtigen oder lizenzfreien Modell verfügbar und bieten Ihnen so eine kreative Auswahl für Ihre Projekte.
<G-vec00872-002-s383><cover.abdecken><en> Our hard work and excellent service resulted in great expansion of EdelSwiss, so now we cover entire Switzerland and its neighboring countries.
<G-vec00872-002-s383><cover.abdecken><de> Das Unternehmen wurde originell in Zürich, Schweiz, gegründet, aber dank unserer harten Arbeit und ausgezeichneten Service hat sich EdelSwiss seitdem erweitert und nun decken wir die ganze Schweiz und ihre Nahbarländer ab.
<G-vec00872-002-s384><cover.abdecken><en> Generally, these audits are thorough and cover several thousand aspects. Certifications
<G-vec00872-002-s384><cover.abdecken><de> In der Regel sind diese Prüfungen sehr gründlich und decken mehrere Tausende Punkte ab.
<G-vec00872-002-s385><cover.abdecken><en> To this end, we cover a broad spectrum of marketing texts.
<G-vec00872-002-s385><cover.abdecken><de> Hierbei decken wir bei den Marketing Übersetzungen eine große Bandbreite ab.
<G-vec00872-002-s386><cover.abdecken><en> As a Total Automation Solution Supplier, we are your ideal supporter on the way to a flexible and intelligent production of tomorrow; but we already cover many of the areas for you.
<G-vec00872-002-s386><cover.abdecken><de> Wir sind als Total Automation Solution Supplier Ihr idealer Begleiter auf dem Weg zur flexiblen und intelligenten Produktion von morgen und decken dabei schon heute viele Bereiche für Sie ab.
<G-vec00872-002-s387><cover.abdecken><en> We do not cover the shipping cost of exchanges, you will have to return and shipping back to your ship the exchanged items responsible. Notice
<G-vec00872-002-s387><cover.abdecken><de> 3.Wir decken nicht die Verschiffenkosten des Austausches ab, Sie sind verantwortlich für das Rückholporto und für die Verschiffen- und Behandlungskosten des Verschiffens der ausgetauschten Einzelteile zurück zu Ihnen.
<G-vec00872-002-s388><cover.abdecken><en> We also cover adjunct areas such as sequence alignments, database searches, nucleic acid extraction from your samples or set-up of your PCR work.
<G-vec00872-002-s388><cover.abdecken><de> Zusätzlich decken wir auch fachlich verwandte Fragestellungen ab, wie Sequenzvergleiche, Datenbanksuchen, Extraktion von Nukleinsäuren aus Ihrer Probe oder die Konfiguration Ihrer PCR.
<G-vec00872-002-s389><cover.abdecken><en> The two draft regulations on medical devices cover a wide range of products, from sticking plasters to hip replacements, pacemakers and laboratory tests for assessment of medical interventions.
<G-vec00872-002-s389><cover.abdecken><de> Die beiden Medizinprodukte-Verordnungen decken ein breites Spektrum von Produkten ab, vom Heftpflaster bis zu Hüftprothesen, Herzschrittmachern und Labortests für die Bewertung medizinischer Eingriffe.
<G-vec00872-002-s390><cover.abdecken><en> As one of Switzerland’s leading companies in the field of information engineering, with our services we cover the full spectrum of modern systems development.
<G-vec00872-002-s390><cover.abdecken><de> Als eine der in der Schweiz führenden Unternehmungen im Bereich Information-Engineering decken wir mit unseren Services das komplette Spektrum der modernen Systementwicklung ab.
<G-vec00872-002-s391><cover.abdecken><en> Large material stocks cover stoppages, errors and quality issues
<G-vec00872-002-s391><cover.abdecken><de> Hohe Materialbestände decken Ausfälle, Fehler und Qualitätseinbrüche ab.
<G-vec00872-002-s392><cover.abdecken><en> Universal Cover all use-cases and scenarios with one solution.
<G-vec00872-002-s392><cover.abdecken><de> Universell Decken Sie alle Anwendungsfälle und Szenarien mit einer Lösung ab.
<G-vec00872-002-s393><cover.abdecken><en> Both products resulting from veraPDF cover all areas and compliance levels of PDF/A, the ISO format for long-term archiving.
<G-vec00872-002-s393><cover.abdecken><de> Beide veraPDF-Ergebnisse decken sämtliche Bereiche und Konformitätsstufen des ISO-Formats für die Langzeitarchivierung, PDF/A ab.
<G-vec00872-002-s394><cover.abdecken><en> We cover all areas of engineering and are accustomed to reading up on new and complex topics very quickly.
<G-vec00872-002-s394><cover.abdecken><de> Wir decken sämtliche Gebiete der Technik ab und sind es gewohnt, uns rasch in neue und komplexe Themen einzuarbeiten.
<G-vec00872-002-s395><cover.abdecken><en> The 7 itineraries on offer cover all of the parishes of the Principality with different central themes: Romanesque art, traditions, trades, etc.
<G-vec00872-002-s395><cover.abdecken><de> Die 7 angebotenen Routen decken alle Gemeinden des Fürstentums mit verschiedenen zentralen Themen ab: romanische Kunst, Traditionen, Handwerk usw.
<G-vec00872-002-s396><cover.abdecken><en> We cover any and all components with brand-name products of leading manufacturers – be it simple KVM switches or double redundant and large modular matrix switches, be it interception-proof fibre glass cable or display ports, and a lot more.
<G-vec00872-002-s396><cover.abdecken><de> Wir decken sämtliche Komponenten mit Markenprodukten führender Hersteller ab – ob einfacher KVM-Umschalter oder doppelt redundante und modulare Großkreuzschiene, ob abhörsichere Glasfaserkabel oder DisplayPorts u. v. m.
<G-vec00872-002-s397><cover.abdecken><en> The collections of posthumous papers that have been brought together in the archives over many decades representatively cover the most important and internationally significant standpoints taken in Swiss architectural culture over a period of more than 150 years.
<G-vec00872-002-s397><cover.abdecken><de> Die über Jahrzehnte im Archiv zusammengeführten Nachlässe decken die für die Schweizer Baukultur wesentlichen und auch international bedeutenden Positionen über einen Zeitraum von mehr als 150 Jahren repräsentativ ab.
<G-vec00872-002-s398><cover.abdecken><en> We cover the entire life cycle of an investment.
<G-vec00872-002-s398><cover.abdecken><de> Wir decken den gesamten Lebenszyklus eines Investments ab.
<G-vec00872-002-s418><cover.abdecken><en> The warranty on this product does not cover any damage, loss or expense due to damage caused by accident, abuse, improper maintenance, use or misuse of the product.
<G-vec00872-002-s418><cover.abdecken><de> Die Gewährleistung auf dieses Produkt deckt keine Schäden, Verluste oder Kosten ab, die durch Schäden aus Unfällen, unsachgemäßer Beanspruchung, unzureichender Wartung, Nutzung oder Missbrauch des Produkts entstehen.
<G-vec00872-002-s419><cover.abdecken><en> Its huge range of connection variants and extended temperature range of -40 °C to +70 °C enable it to perfectly cover the requirements of industrial applications.
<G-vec00872-002-s419><cover.abdecken><de> Durch seine Vielzahl an Anschlussvarianten und seinen erweiterten Temperaturbereich von -40 °C bis +70 °C, deckt er die Anforderungen industrieller Applikationen perfekt ab.
<G-vec00872-002-s420><cover.abdecken><en> Our comprehensive range of specialized environmental services cover areas in your operations that involve carbon, energy, soil, water, air, noise and vibrations, crop and forest services and environmental audits to help you comply with environmental regulations for your industry.
<G-vec00872-002-s420><cover.abdecken><de> Unser umfassendes Angebot aus speziellen Umweltdienstleistungen deckt Bereiche in Ihrem Unternehmen ab, in denen es um Kohlenstoff, Energie, Boden, Wasser, Luft, Geräusche und Vibrationen, Anbau- und Forstwirtschaftsdienstleistungen und Umweltaudits geht, die Ihnen helfen, die Umweltbesitmmungen für Ihre Branche einzuhalten.
<G-vec00872-002-s421><cover.abdecken><en> The limited warranty also does not cover bracelets, crystals and batteries, or any damage to the case or hardware due to moisture that might have entered your TAG Heuer Connected Watch as a result of improper handling.
<G-vec00872-002-s421><cover.abdecken><de> Die eingeschränkte Garantie deckt auch keine Armbänder, Uhrgläser und Batterien ab und keine Schäden an Gehäuse oder Hardware, die durch Feuchtigkeit verursacht wurden, die aufgrund unsachgemäßer Handhabung in die TAG Heuer Connected Watch eindringen konnte.
<G-vec00872-002-s422><cover.abdecken><en> Milk Paint will show wood grain in most cases and can be used as a stain. Chalk-type paints are thicker and cover wood grain in most cases.
<G-vec00872-002-s422><cover.abdecken><de> Mit Milk Paint zeigt sich die Holzmaserung in vielen Fällen, Chalkpaint ist dicker und deckt die Holzmaserung in den meisten Fällen ab.
<G-vec00872-002-s423><cover.abdecken><en> The following tutorial doesn't cover how to hack the existing interfaces (or layouts), but how to add your own.
<G-vec00872-002-s423><cover.abdecken><de> Das folgende Tutorial deckt nicht ab, wie man die vorhandenen Interfaces (oder Layouts) selbst hacken, sondern seine eigenen hinzufügen kann.
<G-vec00872-002-s424><cover.abdecken><en> Nielsen, an S&P 500 company, has operations in over 100 countries that cover more than 90 percent of the world's population.
<G-vec00872-002-s424><cover.abdecken><de> Als S&P 500-Unternehmen ist Nielsen in über 100 Ländern tätig und deckt so mehr als 90 Prozent der Weltbevölkerung ab.
<G-vec00872-002-s425><cover.abdecken><en> The ETV pilot programme, which is entirely voluntary, will initially cover three areas: water treatment and monitoring; materials, waste and resources; and energy technologies.
<G-vec00872-002-s425><cover.abdecken><de> Das ETV-Pilotprogramm ist vollkommen freiwillig und deckt zunächst drei Bereiche ab: Abwasseraufbereitung und -überwachung, Stoffe, Abfall und Ressourcen sowie Energietechnologie.
<G-vec00872-002-s426><cover.abdecken><en> Understand. Solve. We cover the entire development process from planning over construction to commissioning and documentation.
<G-vec00872-002-s426><cover.abdecken><de> Die BSA Engineering deckt den gesamten Entwicklungsprozess von der Projektierung über die Konstruktion bis zur Inbetriebnahme und Dokumentation der Sondermaschinen ab.
<G-vec00872-002-s427><cover.abdecken><en> The limited warranty does not cover damage to the product due to external causes.
<G-vec00872-002-s427><cover.abdecken><de> Die beschränkte Garantie deckt keine Schäden am Produkt aufgrund von externen Ursachen ab.
<G-vec00872-002-s428><cover.abdecken><en> The funding programs cover the entire scientific training and career path of young people.
<G-vec00872-002-s428><cover.abdecken><de> Sie deckt mit ihren Förderprogrammen den gesamten wissenschaftlichen Ausbildungs- und Karriereweg junger Menschen ab.
<G-vec00872-002-s429><cover.abdecken><en> Axel Wolf is regarded as one of the leading figures in his field. His musical activities cover the entire spectrum from solo recitals and chamber music to the orchestra pit.
<G-vec00872-002-s429><cover.abdecken><de> Axel Wolf deckt als einer der profiliertesten Vertreter seines Instruments mit seinen musikalischen Aktivitäten ein großes Spektrum vom Solospiel über Kammermusik bis hin zum Orchestergraben ab.
<G-vec00872-002-s430><cover.abdecken><en> The guarantee does not cover labour charges or damages attributable to work performed by anyone else.
<G-vec00872-002-s430><cover.abdecken><de> Die Garantie deckt nicht Arbeitsaufwendungen oder Schäden ab, die durch die Arbeit von jemand anderem erbracht worden sind.
<G-vec00872-002-s431><cover.abdecken><en> It will also cover prior art that was cited in national proceedings for the same application if such documents became available to the EPO in its function as IPEA.
<G-vec00872-002-s431><cover.abdecken><de> Ferner deckt sie Dokumente des Stands der Technik ab, die in nationalen Verfahren zur Anmeldung angeführt wurden und dem EPA als IPEA zugänglich gemacht wurden.
<G-vec00872-002-s432><cover.abdecken><en> Our product range extends across all kinds of different areas to cover the interests of our customers.
<G-vec00872-002-s432><cover.abdecken><de> Unser Produktsortiment erstreckt sich über die verschiedensten Bereiche und deckt somit die wünsche unserer Kunden ab.
<G-vec00872-002-s433><cover.abdecken><en> The SLA does not cover protection from data loss.
<G-vec00872-002-s433><cover.abdecken><de> Die SLA deckt keinen Schutz gegen Datenverlust ab.
<G-vec00872-002-s434><cover.abdecken><en> A multitude of Intel Core i5 and Intel Core i7 processors cover the CPU section.
<G-vec00872-002-s434><cover.abdecken><de> Eine Vielzahl verschiedener Intel Core i5- und Intel Core i7-CPUs deckt den Prozessorbereich ab.
<G-vec00872-002-s435><cover.abdecken><en> Cover the pot with glass (mini greenhouse), so that the moisture stays.
<G-vec00872-002-s435><cover.abdecken><de> Das ganze deckt man mit Glas (Minigewächshaus) ab, so dass sich die Feuchtigkeit hält.
<G-vec00872-002-s436><cover.abdecken><en> Therefore, their diet does not cover the amount the body needs.
<G-vec00872-002-s436><cover.abdecken><de> Daher deckt ihre Ernährung nicht die Menge ab, die der Körper benötigt.
<G-vec00872-002-s209><cover.bedecken><en> [01/09/2008] Unbelievably thin films cover surfaces and that way change material properties - this idea evolves into a key technology.
<G-vec00872-002-s209><cover.bedecken><de> [01.09.2008] Hauchdünne Schichten bedecken Oberflächen und verändern so die Materialeigenschaften – diese Idee entwickelt sich zu einer Schlüsseltechnologie.
<G-vec00872-002-s210><cover.bedecken><en> Shrubs Trees During the winter months we can cover a portion of the soil near the roots with dry leaves or other mulch tissue; in this manner we will protect the plant from the harsh climate.
<G-vec00872-002-s210><cover.bedecken><de> In den Wintermonaten können wir die Erde in der Nähe der Wurzeln mit trockenen Blättern oder anderem Mulchgut bedecken, um die Pflanze gegen das strenge Klima zu schützen.Der Shoeblackplant braucht eine Mindesttemperatur höher als 15 °C, zu dieser Jahreszeit ist es wichtig, die nächtlichen Temperaturen zu überprüfen, bevor wir die Pflanze nach draußen bringen.
<G-vec00872-002-s211><cover.bedecken><en> Designed to cover full hands, the gloves feature high-impact slide guards that reduce the possibility of injury.
<G-vec00872-002-s211><cover.bedecken><de> Die Handschuhe sind so konzipiert, dass sie die Hände vollständig bedecken, und sie sind mit hochschlagfesten Schutzgittern ausgestattet, die die Verletzungsgefahr verringern.
<G-vec00872-002-s212><cover.bedecken><en> Place the meat in a bowl with the carrot and the onion cut in half, and the sachet of aromatic herbs and cover with wine.
<G-vec00872-002-s212><cover.bedecken><de> Das Fleisch mit der Karotte, der in der Mitte durchgeschnittenen Zwiebel und den Gewürzkräutern in eine Schüssel geben und mit dem Wein bedecken.
<G-vec00872-002-s213><cover.bedecken><en> In the not too distant future the Turf Effects Software Development Kit will be publicly released, enabling developers to apply a light touch of Turf Effects, as seen in Tom Clancy’s Ghost Recon Wildlands, or to cover entire fields and environments in Turf Effects grass.
<G-vec00872-002-s213><cover.bedecken><de> In nicht allzu ferner Zukunft wird das Turf Effects Software Development Kit veröffentlicht werden, das Entwicklern ermöglicht, Turf Effects entweder so zurückhaltend anzuwenden, wie es in Tom Clancy’s Ghost Recon Wildlands zu sehen ist, oder ganze Felder und Gebiete mit Turf Effects-Gras zu bedecken.
<G-vec00872-002-s214><cover.bedecken><en> Their ascetics cover their mouth with strips of cloth while speaking, otherwise they keep them in their hands.
<G-vec00872-002-s214><cover.bedecken><de> Ihre Asketen bedecken ihre Öffnung mit Streifen des Tuches beim Sprechen, andernfalls halten sie sie in ihren Händen.
<G-vec00872-002-s215><cover.bedecken><en> During the 15 free games (triggered by at least 3 Scatter) 3 different Wild symbols might appear with some luck that can cover entire reels and move along to neighboring reel positions which increases your winning chances.
<G-vec00872-002-s215><cover.bedecken><de> In den 15 Freispielen (ausgelöst durch mindestens 3 Scatter) können mit etwas Glück 3 verschiedene Wild-Symbole erscheinen, die in der Lage sind, komplette Walzen zu bedecken und auf benachbarte Walzenpositionen weiterzuwandern, was deine Gewinnchancen deutlich verbessert.
<G-vec00872-002-s216><cover.bedecken><en> Simply add pasta to the cooker and cover with water.
<G-vec00872-002-s216><cover.bedecken><de> Einfach Nudeln in den Kocher füllen und mit Wasser bedecken.
<G-vec00872-002-s217><cover.bedecken><en> Cover with another chocolate square.
<G-vec00872-002-s217><cover.bedecken><de> Mit einem weiteren Schokoladenrechteck bedecken.
<G-vec00872-002-s218><cover.bedecken><en> The Bubble-Me Colour Bath will cover children’s world with thousands of colour bubbles, while the Vichy or Ayurvedic Massage for Children will relax them and make them feel well.
<G-vec00872-002-s218><cover.bedecken><de> Das bunte Bubble-me-Bad wird die Kinderwelt mit tausenden farbigen Seifenblasen bedecken, die Vichy-Massage oder die kindergerechte Ayurveda-Massage wird sie entspannen und für ihr Wohlbefinden sorgen.
<G-vec00872-002-s219><cover.bedecken><en> Use a hat and clothes to cover your body.
<G-vec00872-002-s219><cover.bedecken><de> Nutzen Sie einen Sonnenhut und leichte Kleidung, um Ihren Körper zu bedecken.
<G-vec00872-002-s220><cover.bedecken><en> Thinking “The Buddha must not get wet” he looked around for something to cover it, but only could find an old shoe.
<G-vec00872-002-s220><cover.bedecken><de> Er dachte „Der Buddha darf nicht nass werden" und schaute sich nach etwas um, um ihn zu bedecken, fand aber nur einen alten Schuh.
<G-vec00872-002-s221><cover.bedecken><en> Using portable system on a blanket, pillow, or other type of cloth may cover the fan grills blocking the airflow that cools the system.
<G-vec00872-002-s221><cover.bedecken><de> Die Verwendung von tragbaren Systemen auf einer Decken, einem Kissen oder anderen Textilien kann die Lüftergitter bedecken und damit den Luftstrom zum Kühlen des Systems blockieren.
<G-vec00872-002-s222><cover.bedecken><en> When planting orange trees outside, dig a hole just deep enough to cover the roots.
<G-vec00872-002-s222><cover.bedecken><de> Grabe ein Loch, das gerade tief genug ist, um die Wurzeln zu bedecken.
<G-vec00872-002-s223><cover.bedecken><en> Vegetable oil (to cover the bottom of the wok to 1/2 inch)
<G-vec00872-002-s223><cover.bedecken><de> Den Boden des Glases ebenfalls mit Erdbeerscheiben bedecken.
<G-vec00872-002-s224><cover.bedecken><en> All three varieties also offer generous progressive jackpots: Cover your card in 37 calls in a 90 ball game, 25 or less in a 75 ball game, or 49 calls or less in a 5 line game and you'll be the lucky winner.
<G-vec00872-002-s224><cover.bedecken><de> Alle drei Varianten bieten außerdem großzügige progressive Jackpots: Bedecken Sie Ihre Karte in 37 Aufrufen in einem 90-Ball-Spiel, 25 oder weniger in einem 75-Ball-Spiel oder 49 Anrufe oder weniger in einem 5-Zeilen-Spiel, und Sie sind der glückliche Gewinner.
<G-vec00872-002-s225><cover.bedecken><en> The cake will swell and then subside once cooled. Cover with plenty of jam, excellent with that of raspberries.
<G-vec00872-002-s225><cover.bedecken><de> Bedecken Sie den Kuchen mit reichlich Marmelade, am besten Himbeermarmelade, und lagern Sie ihn im Kühlschrank.
<G-vec00872-002-s226><cover.bedecken><en> Wash the lemons and place in a small pot of water (the water should cover them).
<G-vec00872-002-s226><cover.bedecken><de> Die Zitronen waschen und in einen kleinen Topf mit Wasser legen (das Wasser sollte sie bedecken).
<G-vec00872-002-s227><cover.bedecken><en> A quarter of all marine species live in coral reefs, even though they cover only 0.1 percent of the ocean floor.
<G-vec00872-002-s227><cover.bedecken><de> Ein Viertel aller marinen Arten lebt an Korallenriffen, obwohl diese nur 0,1 Prozent des Meeresbodens bedecken.
<G-vec00872-002-s228><cover.bedecken><en> He has to wear a woman’s dress and has to cover his head, in such a way that no one can recognize him.
<G-vec00872-002-s228><cover.bedecken><de> Er zieht ein Frauenkleid an und bedeckt seinen Kopf so, dass keiner ihn erkennen kann.
<G-vec00872-002-s229><cover.bedecken><en> Oceans cover more than two-thirds of our planet and give us food, energy and other resources.
<G-vec00872-002-s229><cover.bedecken><de> Das Meer bedeckt zwei Drittel unseres Planeten, es schenkt uns Nahrung, Energie und andere Schätze.
<G-vec00872-002-s230><cover.bedecken><en> Cover their eyes and take them there, lay them down next to the dead bodies.
<G-vec00872-002-s230><cover.bedecken><de> Bedeckt ihre Augen und bringt sie dorthin, legt sie neben die toten Körper.
<G-vec00872-002-s231><cover.bedecken><en> Once there is some grey gel on one wall put the orange portal there and cover the wall of the other tower, then put the orange portal there and continue until you reach the top. Now it's time to cover the slanted platform next to the higher tower with the grey gel.
<G-vec00872-002-s231><cover.bedecken><de> Nun bringst du noch das graue Gel auf die kleine schräge Plattform neben dem höheren Turm, und wenn diese vollkommen bedeckt ist benutzt du ein Portal um auf den höheren der beiden Türme zu kommen.
<G-vec00872-002-s232><cover.bedecken><en> Dip the entire nib into an ink jar, making sure to cover the hole on the back of the nib.
<G-vec00872-002-s232><cover.bedecken><de> Tauche die gesamte Spitze in ein Tintenfass und achte darauf, dass das Loch auf der Rückseite der Spitze bedeckt ist.
<G-vec00872-002-s233><cover.bedecken><en> Put the moulds out of the fridge and cover everything with the couverture.
<G-vec00872-002-s233><cover.bedecken><de> Nehmt die Formen aus dem Kühlschrank und bedeckt alles mit der Schokolade.
<G-vec00872-002-s234><cover.bedecken><en> Will cover any shape or contour.
<G-vec00872-002-s234><cover.bedecken><de> Bedeckt jede Form oder Kontur.
<G-vec00872-002-s235><cover.bedecken><en> 9 They will neither harm nor destroy on all my holy mountain, for the earth will be filled with the knowledge of the Lord as the waters cover the sea.
<G-vec00872-002-s235><cover.bedecken><de> 9 Man wird weder Bosheit noch Schaden tun auf meinem ganzen heiligen Berge; denn das Land ist voll Erkenntnis des Herrn, wie Wasser das Meer bedeckt.
<G-vec00872-002-s236><cover.bedecken><en> Married women in Old Russia (a.k.a. Rus) were obliged to cover their heads and conceal their hair.
<G-vec00872-002-s236><cover.bedecken><de> Es war für verheiratete Frauen im alten Russland Pflicht, ihre Köpfe bedeckt und ihre Haare versteckt zu halten.
<G-vec00872-002-s237><cover.bedecken><en> It's not necessary to cover the sides as you can easily cut around with a knife to separate the cake from the pan.
<G-vec00872-002-s237><cover.bedecken><de> Grundsätzlich reicht es, wenn der Boden mit Backpapier bedeckt ist, die Ränder lassen sich gut mit einem Messer von der Form lösen.
<G-vec00872-002-s238><cover.bedecken><en> A merger (or fusion) of the nuclei cover the entire mass of the charge bomb and lasts until neutrons can find more unreacted thermonuclear fuel.
<G-vec00872-002-s238><cover.bedecken><de> Eine Fusion (oder Fusion) der Kerne bedeckt die gesamte Masse der Ladungsbombe und dauert so lange, bis Neutronen mehr nicht umgesetzten thermonuklearen Brennstoff finden können.
<G-vec00872-002-s239><cover.bedecken><en> 7 Cover the baking dish and bake the parsnips for 45 minutes or until they are tender.
<G-vec00872-002-s239><cover.bedecken><de> 7 Bedeckt die Backform und backt die Pastinaken 45 Minuten lang, oder bis sie euch eben weich genug sind.
<G-vec00872-002-s240><cover.bedecken><en> First melted with paraffin and cover the glass, carved in the surface of the wax pattern, and then coated with hydrofluoric acid can be washed to paraffin.
<G-vec00872-002-s240><cover.bedecken><de> Zuerst mit Paraffin geschmolzen und das Glas bedeckt, in die Oberfläche des Wachsmodells eingraviert und dann mit Flusssäure beschichtet, kann Paraffin gewaschen werden.
<G-vec00872-002-s241><cover.bedecken><en> The ski slopes tend to be wide, scenic and quiet with a reliable snow cover, making it excellent for young families to professionals.
<G-vec00872-002-s241><cover.bedecken><de> Die Skipisten sind meist breit, malerisch, ruhig und zuverlässig mit Schnee bedeckt, was sie zum perfekten Ziel sowohl für junge Familien als auch Profis macht.
<G-vec00872-002-s242><cover.bedecken><en> This walking tour combines Lisbon's many breathtaking viewpoints with the vibrant and creative Street Art that cover the streets.
<G-vec00872-002-s242><cover.bedecken><de> Diese Wanderung verbindet Lissabons viele atemberaubende Aussichtspunkte mit der lebendigen und kreativen Street Art, die die Straßen bedeckt.
<G-vec00872-002-s243><cover.bedecken><en> Malachi 2:13-16 And this is the second thing you do: You cover the altar of Yahweh with tears, With weeping and crying; So He does not regard the offering anymore, Nor receive it with goodwill from your hands.
<G-vec00872-002-s243><cover.bedecken><de> 2,13-16 Und zum andern tut ihr auch das: Ihr bedeckt den Altar des Yahweh mit Tränen, mit Weinen und Seufzen, so daß er sich nicht mehr zum Speisopfer wenden und es nicht mit Wohlgefallen aus euren Händen annehmen mag.
<G-vec00872-002-s244><cover.bedecken><en> You cover your eyes and choose someone without knowing who it is and give that person a massage all over the body.
<G-vec00872-002-s244><cover.bedecken><de> Ihr bedeckt eure Augen und wählt jemanden aus der Gruppe aus, ohne zu wissen wer es ist, und gebt ihm/ihr eine Körpermassage.
<G-vec00872-002-s245><cover.bedecken><en> Cover me with flowers, I die for love.
<G-vec00872-002-s245><cover.bedecken><de> Bedeckt mich mit Blumen, ich sterbe vor Liebe.
<G-vec00872-002-s246><cover.bedecken><en> As the view from space reveals, forests cover about one third of Earth’s landmass today.
<G-vec00872-002-s246><cover.bedecken><de> Wie der Blick aus dem All verrät, ist die Landmasse der Erde heute zu rund einem Drittel von Wäldern bedeckt.
<G-vec00872-002-s323><cover.bedecken><en> Place a few seed peanuts on top of the soil and cover.
<G-vec00872-002-s323><cover.bedecken><de> Gib ein paar Saat-Erdnüsse auf die Erde und decke sie zu.
<G-vec00872-002-s324><cover.bedecken><en> As soon as all were in bed and the lights extinguished, the frightful racket commenced, and presently entered Mr. and Mrs. Johnson's room with increased demonstrations, stripping the cover from their bed.
<G-vec00872-002-s324><cover.bedecken><de> Sobald alle zu Bett waren und die Lichter erloschen, begann das schreckliche Spektakel und es betrat mit verstärkten Demonstrationen das Zimmer von Herrn und Frau Johnson und zog die Decke von ihrem Bett.
<G-vec00872-002-s325><cover.bedecken><en> Multiple colours make the small knob either invisibly disappear under the cover or make it a colourful eye-catcher.
<G-vec00872-002-s325><cover.bedecken><de> Verschiedene Farben lassen den kleinen Knauf entweder unsichtbar unter der Decke verschwinden oder machen ihn zum farbenfrohen Blickfang.
<G-vec00872-002-s326><cover.bedecken><en> 12 And they shall take all the sacred vessels with which they officiate in the sanctuary and put them in a violet cloth and cover them with a cover of sea-cow skin and put them on a bar.
<G-vec00872-002-s326><cover.bedecken><de> 12 Und sie sollen alle Geräte+ des Dienstes nehmen, mit denen sie an der heiligen Stätte regelmäßig den Dienst verrichten, und sie sollen sie in ein Tuch in Blau legen und sie mit einer Decke aus Seehundsfellen+ bedecken und sie auf eine Trage legen.
<G-vec00872-002-s327><cover.bedecken><en> Wizard Towers are vulnerable to clusters of Barbarians or giants/any troops with very high health, so cover it with an air defense or Archer Towers.
<G-vec00872-002-s327><cover.bedecken><de> Zauberer-Türme sind gegenüber Gruppen von Barbaren oder Riesen/jeglichen Truppen mit sehr hoher Gesundheit verletzlich, also decke sie mit einer Luftverteidigung oder Bogenschützen-Türmen.
<G-vec00872-002-s328><cover.bedecken><en> The cover of the forest was dense, though the sun still tried to break through, speckling the ground in patches.
<G-vec00872-002-s328><cover.bedecken><de> Die Decke des Waldes war dicht, obwohl die Sonne immer noch versuchte zu durchbrechen und den Boden in Flecken zu sprießen.
<G-vec00872-002-s329><cover.bedecken><en> Cover: oil, abrasion and weather resistant polyurethane.
<G-vec00872-002-s329><cover.bedecken><de> Decke: spezielles, synthetisches Gummi, Öl-, Abrieb-und Witterungsbeständig.
<G-vec00872-002-s330><cover.bedecken><en> Not to freeze by the icy heights both have laid in addition to our warm sleeping-bags still a thin summer sleeping-bag virtually as a kind of cover about us and have connected with a zipper with the Isomatten.
<G-vec00872-002-s330><cover.bedecken><de> Um in den Eisigen Höhen nicht einzufrieren haben zusätzlich zu unseren warmen Schlafsäcken noch einen dünnen Sommerschlafsack quasi als Art Decke über uns beide gelegt und mit einem Reißverschluß mit den Isomatten verbunden.
<G-vec00872-002-s331><cover.bedecken><en> Cover the bowl with foil, place it in the water in the pot, cover with a lid, and steam for about 12 minutes.
<G-vec00872-002-s331><cover.bedecken><de> Decke die Schüssel mit Folie ab, stelle sie in das Wasser im Topf, decke den Topf mit dem Deckel ab und gare es etwa 12 Minuten.
<G-vec00872-002-s332><cover.bedecken><en> Cover the bowl with a wet towel or plastic wrap and keep them in the fridge while you prepare the other ingredients and supplies.
<G-vec00872-002-s332><cover.bedecken><de> Decke die Schüssel mit einem feuchten Handtuch oder Plastikfolie ab und bewahre sie im Kühlschrank auf, während du die anderen Zutaten und die Ausrüstung vorbereitest.
<G-vec00872-002-s333><cover.bedecken><en> Cover the dish and refrigerate it.
<G-vec00872-002-s333><cover.bedecken><de> Decke die Schüssel ab und stelle sie kühl.
<G-vec00872-002-s334><cover.bedecken><en> It was a rather bad day and so I would have preferred to got home directly into bed, pulling the cover over the head.
<G-vec00872-002-s334><cover.bedecken><de> Ich hatte einen eher schlechten Tag und somit wär ich irgendwie lieber daheim direkt ins Bett, Decke über den Kopf.
<G-vec00872-002-s335><cover.bedecken><en> Place sharp objects in the trunk or on the floor, or cover your seats with a thick blanket first.
<G-vec00872-002-s335><cover.bedecken><de> Lege scharfe Gegenstände in den Kofferraum oder auf den Boden, oder decke deine Sitze zuerst mit einer dicken Decke ab.
<G-vec00872-002-s336><cover.bedecken><en> The cover is bordered by a multi-stripe binding of real wood, whose diagonal motive reoccurs in the bottom joint.
<G-vec00872-002-s336><cover.bedecken><de> Eingefasst ist die Decke von einem mehrstreifigen Echtholz-Binding, dessen diagonales Motiv sich auch bei der Bodenfuge wiederfindet.
<G-vec00872-002-s337><cover.bedecken><en> I cover the first two with Microsoft Office365.
<G-vec00872-002-s337><cover.bedecken><de> Die ersten beiden decke ich mit Hilfe von Microsoft Office365 ab.
<G-vec00872-002-s338><cover.bedecken><en> Brush baked rolls with melted butter and cover with a clean kitchen towel to make softer dinner rolls.
<G-vec00872-002-s338><cover.bedecken><de> Bepinsel die gebackenen Brötchen mit geschmolzener Butter und decke sie mit einem Küchentuch ab, damit sie schön weich werden.
<G-vec00872-002-s339><cover.bedecken><en> Cover: abrasion, heat, ozone and weather resistant, EPDM rubber.
<G-vec00872-002-s339><cover.bedecken><de> Decke: abriebfester, wärme-, ozon- und witterungsbeständig EPDM-Gummi mit Keramikummantelung, bis zu +600°C beständig.
<G-vec00872-002-s340><cover.bedecken><en> When desired we embroider your cover with your name, initials or your individual Logo.
<G-vec00872-002-s340><cover.bedecken><de> Auf Wunsch besticken wir Ihre Decke mit Ihrem Namen, Initialen oder Ihrem individuellen Logo.
<G-vec00872-002-s341><cover.bedecken><en> 17:19 And a woman put a cover over the hole, and put crushed grain on top of it, and no one had any knowledge of it.
<G-vec00872-002-s341><cover.bedecken><de> 17:19 Da nahm die Frau eine Decke und breitete sie über die Brunnenöffnung und streute Getreidekörner darüber aus, so daß man nichts erkennen konnte.
<G-vec00872-002-s361><cover.bedecken><en> Switching families cover 8Gb/10Gb, while I2C and GPIO families offer port expander mux/level shifter/buffer functions.
<G-vec00872-002-s361><cover.bedecken><de> Die Switching-Produktfamilien decken 8Gb/10Gb ab, während die I2C- und GPIO-Produktfamilien Funktionen für Port-Expander und Mux/Pegelumsetzer/Buffer bieten.
<G-vec00872-002-s362><cover.bedecken><en> At the product delivery time, without significant reasons refusing to accept the product, the Buyer is obliged to cover the costs for the product delivery, and he is obligated to pay all the direct costs for returning the product to the Seller.
<G-vec00872-002-s362><cover.bedecken><de> Wenn der Käufer während der Anlieferung der Waren ohne wichtigem Grund auf die Übernahme der Waren sich verzichtet, muss er die Kosten der Warenanlieferung decken und alle direkte Kosten der Warenrücksendung an den Verkäufer bezahlen.
<G-vec00872-002-s363><cover.bedecken><en> New features cover all aspects from extended functionality (Web testing in combination with Java applets, detailed reports), improved user experience (no more JDK instrumentation, workbench view, incremental search), additional documentation ('Best Practices' part in the manual) to extensibility with several new APIs.
<G-vec00872-002-s363><cover.bedecken><de> Die neuen Features decken alle Aspekte ab, von erweiterter Funktionalität (Webtesten in Kombination mit Java Applets, detaillierte Reports), Anwenderfreundlichkeit (keine JDK Instrumentierung mehr, Workbench Ansicht, inkrementelle Suche), zusätzlicher Dokumentation ('Best Practices' Teil im Handbuch) zu Erweiterbarkeit mit mehreren neuen APIs.
<G-vec00872-002-s364><cover.bedecken><en> Remember: IAESTE placements are paid and should normally cover the cost of living in the host country.
<G-vec00872-002-s364><cover.bedecken><de> Die Praktika sind bezahlt und decken in der Regel die Lebenshaltungskosten im Gastland.
<G-vec00872-002-s365><cover.bedecken><en> You must be admitted to study in an eligible Canadian institution, have no criminal record, provide evidence of good physical health and demonstrate that you will be able to cover your expenses, including tuition, while you are in Canada.
<G-vec00872-002-s365><cover.bedecken><de> Sie müssen zugelassen sein, um in einer in Kanada zugelassenen Einrichtung studieren zu können, haben kein Vorstrafenregister, erbringen einen Nachweis über gute körperliche Gesundheit und Zeigen Sie, dass Sie in der Lage sein werden, Ihre Ausgaben, einschließlich Studiengebühren, zu decken, während Sie in Kanada sind.
<G-vec00872-002-s366><cover.bedecken><en> The international actors cover together with the OES-members the whole value chain and provide the potential for a mutual commercialization of the organic electronic.
<G-vec00872-002-s366><cover.bedecken><de> Die internationalen Akteure decken gemeinsam mit den OES-Mitgliedern die gesamte Wertschöpfungskette ab und stellen das Potential für eine gemeinsame Kommerzialisierung der organischen Elektronik.
<G-vec00872-002-s367><cover.bedecken><en> There is a 15% commission on all sales to help cover our expenses.
<G-vec00872-002-s367><cover.bedecken><de> 15 % Kommission sind auf allen Verkäufen, die uns helfen unsere Kosten zu decken.
<G-vec00872-002-s368><cover.bedecken><en> Terms of lease that includes a deposit of € 200.- and a power package of 9 units per day to cover all the current needs without air conditioning.
<G-vec00872-002-s368><cover.bedecken><de> Mietbedingungen, die eine Anzahlung von € 200.- und ein Kraftpaket von 9 Einheiten pro Tag, um alle aktuellen Bedürfnisse ohne Klimaanlage zu decken enthält.
<G-vec00872-002-s369><cover.bedecken><en> The junior professorship works specifically on approaches to utilize organic waste in densely populated urban areas with the goal to cover partly the demand of chemicals and materials.
<G-vec00872-002-s369><cover.bedecken><de> Wir arbeiten im Speziellen an Ansätzen, um organische Abfälle in dicht besiedelten urbanen Räumen zu verwerten, um den Bedarf an Chemikalien und Materialien in diesen Regionen teilweise zu decken.
<G-vec00872-002-s370><cover.bedecken><en> Our solutions cover the complete spectrum—from small and medium capacities up to major industrial large-scale production—and provide the customer with the flexibility to respond to such trends.
<G-vec00872-002-s370><cover.bedecken><de> Unsere Lösungen decken das komplette Spektrum von kleinen und mittleren Kapazitäten bis zur industriellen Grossproduktion ab und geben den Kunden die Flexibilität, um auf solche Trends zu reagieren.
<G-vec00872-002-s371><cover.bedecken><en> We aim to provide the most comprehensive global and local offering to all customers so we also cover a wide range of markets ranging from the biggest global events to local leagues and minority sports across USA and worldwide. LIVE BETTING
<G-vec00872-002-s371><cover.bedecken><de> Wir möchten allen Kunden das umfassendste globale und lokale Angebot bereitstellen, daher decken wir auch ein breites Spektrum von Märkten ab, angefangen bei den größten globalen Ereignissen, bis hin zu lokalen Ligen und Minderheitensportarten in ganz Europa und weltweit.
<G-vec00872-002-s372><cover.bedecken><en> For instance, if someone were to "bribe" Falun Gong practitioners--let's say around ten thousand US dollars per year for each practitioner to cover their living expenses--and let's say that there are only ten thousand practitioners in North America, then the cost for maintaining these "anti-China forces" would amount to at least one hundred million US dollars per year.
<G-vec00872-002-s372><cover.bedecken><de> Wenn zum Beispiel jemand Falun Gong Praktizierende bestechen wollte, sagen wir mal mit 10.000 US Dollar jährlich pro Person, um den Lebensunterhalt zu decken und angenommen, es gäbe wenigsten 10.000 Praktizierende in Nordamerika, dann würden sich die Kosten für den Unterhalt im Jahr auf hundert Millionen US Dollar belaufen.
<G-vec00872-002-s373><cover.bedecken><en> Also the adoption fee is a way to ensure to our organization that the adopter has the resources to cover the extra costs needed to provide a good home and responsible care for their animal.
<G-vec00872-002-s373><cover.bedecken><de> Ebenso ist die Adoptionsgebühr ein Weg um sicherzustellen, dass der Adoptant über die nötigen Mittel verfügt um anfallende Kosten zu decken um für ein gutes Zuhause und verantwortungsvolle Pflege seines Tieres zu sorgen.
<G-vec00872-002-s374><cover.bedecken><en> Our objective is to cover every need and desire of our clients offering the best possible services from the start to the end of the construction.
<G-vec00872-002-s374><cover.bedecken><de> Unser Ziel ist es, sämtliche Bedürfnisse und Wünsche unserer Kunden zu decken und ihnen vom Baubeginn bis zum Abschluss der Arbeiten, die besten Dienstleistungen zukommen zu lassen.
<G-vec00872-002-s375><cover.bedecken><en> If you are charged VAT, Tax, or custom duty fees, please be prepared to cover these charges.
<G-vec00872-002-s375><cover.bedecken><de> Sollten Ihnen Mehrwertsteuer, Steuern oder Zollgebühren auferlegt werden, gehen Sie sicher, dass Sie die Kosten dafür decken können.
<G-vec00872-002-s376><cover.bedecken><en> Our comprehensive range of tabletop, standing and double-chamber models lets us cover a wide variety of customer requirements as standard.
<G-vec00872-002-s376><cover.bedecken><de> Mit unserem umfangreichen Portfolio an Tisch-, Stand- und Doppelkammermaschinen decken wir standardmäßig eine Vielzahl unterschiedlichster Kundenanforderungen ab.
<G-vec00872-002-s377><cover.bedecken><en> To cover expenses we will charge an amount from each of the participants.
<G-vec00872-002-s377><cover.bedecken><de> Um die Kosten zu decken, berechnen wir einen Betrag von jedem der Teilnehmer.
<G-vec00872-002-s378><cover.bedecken><en> 100 g cover 2/3 of the daily requirement.
<G-vec00872-002-s378><cover.bedecken><de> 100 g decken 2/3 des Tagesbedarfs.
<G-vec00872-002-s379><cover.bedecken><en> If you would like us to present your house at our site, we will only charge you a small amount for every booking we generate in order to cover our variable costs.
<G-vec00872-002-s379><cover.bedecken><de> Wenn Sie uns Ihr Haus auf unserer Website präsentieren möchten, nur berechnen wir Ihnen eine kleine Menge für jede Buchung, die wir erzeugen, um unsere Variable Kosten zu decken.
<G-vec00872-002-s399><cover.bedecken><en> Planetary gearboxes designed for Delta applications are available in 4 sizes and cover a ratio range of i=16-55.
<G-vec00872-002-s399><cover.bedecken><de> Das für Delta Applikationen konzipierte Planetengetriebe ist in 4 Baugrößen erhältlich und deckt den Übersetzungsbereich von i=16-55 ab.
<G-vec00872-002-s400><cover.bedecken><en> Insurance * shall cover claims which are subject to limitation pursuant to the 1996 convention * and shall provide cover up to the liability limitation thresholds laid down in that Convention.
<G-vec00872-002-s400><cover.bedecken><de> Die Versicherung * deckt Seeforderungen ab, die der Haftungsbeschränkung nach dem Übereinkommen von 1996 * unterliegen und muss eine Deckung bis zu den in diesem Übereinkommen vorgesehenen Haftungshöchstbeträgen gewährleisten.
<G-vec00872-002-s401><cover.bedecken><en> Suitable candidates are invited to attend an interview with the Academic Director which will cover the way that the PhD relates to and will help your professional development; and your knowledge and appreciation of current thinking in one or more areas of management.
<G-vec00872-002-s401><cover.bedecken><de> Geeignete Kandidaten werden aufgefordert, an einem Interview mit dem Lehrgangsleiter teilzunehmen, das die Art und Weise deckt, die das PhD Studium betrifft und Ihrer beruflichen Entwicklung hilft; und Ihr Wissen und Wertschätzung des gegenwärtigen Denkens in einem oder mehreren Bereichen der Verwaltung.
<G-vec00872-002-s402><cover.bedecken><en> This interview will cover how Oreganol P73 is beneficial for common health challenges.
<G-vec00872-002-s402><cover.bedecken><de> Dieses Interview deckt wie Oreganol P73 für häufige Gesundheitsprobleme von Vorteil ist.
<G-vec00872-002-s403><cover.bedecken><en> A high level of microfine light-diffusing pigments helps cover dark circles and blur the appearance of fine lines and wrinkles, leaving the eye area skin looking refreshed and youthfully bright. on any Elizabeth Arden products.
<G-vec00872-002-s403><cover.bedecken><de> Ein hoher Anteil an mikroskopischen, lichtbrechenden Pigmenten deckt Augenringe ab und verwischt feine Linien und Falten, damit die Haut der Augenpartie jugendlich strahlend und frisch wirkt.
<G-vec00872-002-s404><cover.bedecken><en> ‘The insurance referred to in Article 3(1) of [the First Directive] shall cover personal injuries and damage to property suffered by pedestrians, cyclists and other non-motorised users of the roads who, as a consequence of an accident in which a motor vehicle is involved, are entitled to compensation in accordance with national civil law. …’
<G-vec00872-002-s404><cover.bedecken><de> „Artikel 1a Die in Artikel 3 Absatz 1 der Richtlinie 72/166/EWG genannte Versicherung deckt Personen- und Sachschäden von Fußgängern, Radfahrern und anderen nicht motorisierten Verkehrsteilnehmern, die nach einzelstaatlichem Zivilrecht einen Anspruch auf Schadenersatz aus einem Unfall haben, an dem ein Kraftfahrzeug beteiligt ist.
<G-vec00872-002-s405><cover.bedecken><en> Health insurance with accident cover only insures treatment costs such as medical expenses, hospital costs and medication.
<G-vec00872-002-s405><cover.bedecken><de> Diese Krankenpflegeversicherung mit Unfalleinschluss deckt aber nur die anfallenden Heilungskosten wie Arzt- und Spitalkosten oder Medikamente.
<G-vec00872-002-s406><cover.bedecken><en> This Guarantee does not cover your data; any software or PlayStation games; any PlayStation peripherals; any PlayStation accessories; or any other peripherals or accessories.
<G-vec00872-002-s406><cover.bedecken><de> Diese Garantie deckt keine gespeicherten Daten, Software oder PlayStation-Spiele, keine PlayStation-Peripheriegeräte, kein PlayStation-Zubehör und keine anderen Peripheriegeräte oder Zubehör ab.
<G-vec00872-002-s407><cover.bedecken><en> Our warranty doesn’t cover wear from normal use.
<G-vec00872-002-s407><cover.bedecken><de> Die Apple-Garantie deckt keinen Verschleiß ab, der durch normalen Gebrauch entsteht.
<G-vec00872-002-s408><cover.bedecken><en> Mineralissima foundations even out your skin tone, cover imperfections, provide sun protection (all our foundations have a natural sunblock) yet feel weightless without drying out your skin.
<G-vec00872-002-s408><cover.bedecken><de> Mineralissima Foundations eignen sich auch für sehr empfindliche Haut, perfektioniert Ihren natürlichen Hautton, deckt kleine Makel ab und bietet Sonnenschutz.
<G-vec00872-002-s409><cover.bedecken><en> In the service field we cover every aspect of the traffic safety process chain – from system development, production and installation of the monitoring infrastructure to image capture and automated processing.
<G-vec00872-002-s409><cover.bedecken><de> Im Bereich der Dienstleistungen deckt Jenoptik die gesamte begleitende Prozesskette ab – von der Systementwicklung über den Aufbau und die Installation der Überwachungsinfrastruktur bis zur Aufnahme der Verstoßbilder und deren automatische Weiterverarbeitung.
<G-vec00872-002-s410><cover.bedecken><en> Clouds will cover all the Earth, but the light of God will illuminate you.
<G-vec00872-002-s410><cover.bedecken><de> Die Dunkelheit deckt die ganze Erde, aber das Licht Gottes erleuchtet euch.
<G-vec00872-002-s411><cover.bedecken><en> Our range of traditional and rapid detection solutions for pathogens cover both long-known disease agents and new ones such as E. coli O157, and we are constantly updating our portfolio as the need arises.
<G-vec00872-002-s411><cover.bedecken><de> Unser Angebot an Lösungen für den traditionellen und schnellen Nachweis von Pathogenen deckt sowohl klassische als auch neue Krankheitserreger wie E. coli O157 ab und wir aktualisieren unser Portfolio ständig nach den neuesten Erkenntnissen.
<G-vec00872-002-s412><cover.bedecken><en> The amount of compensable Damage shall cover redress of the Damage, as determined by amicable agreement, expert appraisal or the competent courts.
<G-vec00872-002-s412><cover.bedecken><de> Die Höhe des ersetzbaren Schadens deckt die Schadensersatzleistung, wie sie durch gütliche Einigung, auf dem Weg eines Sachverständigengutachtens oder durch die zuständigen Gerichte festgelegt wurde.
<G-vec00872-002-s413><cover.bedecken><en> The warranty covers normal consumer use and does not cover damage that occurs in shipment or failure that results from 11” alterations, accident, misuse, abuse, neglect, wear and tear, inadequate maintenance, commercial use, or unreasonable use of the unit.
<G-vec00872-002-s413><cover.bedecken><de> Die Garantie setzt einen normalen Gebrauch des Gerätes voraus und deckt keine, während des Transports hervorgerufenen Schäden oder Beschä-digun-gen hervorgerufen durch Änderungen am Produkt, unvorhergesehene Vorfälle, unsachgemäßen Gebrauch, Mißbrauch, Nachlässigkeit, frühzeitige Abnutzung und Beschädigung, unsachgemäbe Wartung, im Laden hervorgerufene Beschädigungen, unsachgemäße Handhabung.
<G-vec00872-002-s414><cover.bedecken><en> Recommendation: Arrange additional commercial insurance which can cover these fees before you travel.
<G-vec00872-002-s414><cover.bedecken><de> Empfehlung: Vereinbaren Sie vor Ihrer Reise eine zusätzliche private Versicherung, die diese Gebühren deckt.
<G-vec00872-002-s415><cover.bedecken><en> 008:016 "When any one lights a lamp, he does not cover it with a vessel or hide it under a couch; he puts it on a lampstand, that people who enter the room may see the light.
<G-vec00872-002-s415><cover.bedecken><de> Aufgabe der Jünger 16 Niemand zündet eine Lampe an und deckt sie mit einem Gefäß zu oder stellt sie unter das Lager, sondern setzt sie auf den Leuchter, damit die, die eintreten, das Licht sehen.
<G-vec00872-002-s416><cover.bedecken><en> The risk of just one single use is too high for the stand lessor as a single use does not cover the fabrication costs.
<G-vec00872-002-s416><cover.bedecken><de> Das Risiko eines nur einmaligen Einsatzes ist für den Standvermieter zu hoch, da ein einmaliger Einsatz die Kosten der Fertigung nicht deckt.
<G-vec00872-002-s417><cover.bedecken><en> We cover our capital requirements from net cash flow, and from short-term and long-term financing.
<G-vec00872-002-s417><cover.bedecken><de> WACKER deckt seinen Kapitalbedarf aus dem Netto-Cashflow sowie durch kurzfristige- und langfristige Finanzierungen.
<G-vec00872-002-s532><cover.hüllen><en> The outer cover of this Lotus meditation cushion is easily removable by the zipper around the bottom.
<G-vec00872-002-s532><cover.hüllen><de> Die äußere Hülle dieses Lotus Meditationskissens ist durch den Reißverschluss am Boden leicht abnehmbar.
<G-vec00872-002-s533><cover.hüllen><en> During your travels or meetings, you may even place your MacBook on top of the cover, while using it.
<G-vec00872-002-s533><cover.hüllen><de> Während Ihrer Reisen oder Besprechungen können Sie Ihr MacBook sogar auf die Hülle stellen, wenn Sie es benutzen.
<G-vec00872-002-s534><cover.hüllen><en> The color of the thread does not matter. You will be putting this inside the liner cover.
<G-vec00872-002-s534><cover.hüllen><de> Die Garnfarbe spielt keine Rolle, da die Einlagen in die Hülle gesteckt werden.
<G-vec00872-002-s535><cover.hüllen><en> The see through cover enables you to see the contents whilst under water.
<G-vec00872-002-s535><cover.hüllen><de> Ich habe die Hülle im Video unter Wasser getestet.
<G-vec00872-002-s536><cover.hüllen><en> The cover is also perfectly suited for ornithologists: if it is fastened around camera and lens, it absorbs the noise of the camera when you trigger it. It therefore becomes an important tool for professional pictures.
<G-vec00872-002-s536><cover.hüllen><de> Auch für Ornithologen ist die Hülle optimal geeignet: wenn sie um die Kamera und das Objektiv angelegt wird, dämpft sie die Geräusche der Kamera bei der Auslösung und wird so zum wichtigen Werkzeug für professionelle Bilder.
<G-vec00872-002-s537><cover.hüllen><en> The pure ecru cotton cover is available in different colors.
<G-vec00872-002-s537><cover.hüllen><de> Für die Hülle aus reiner Ecru-Baumwolle stehen unterschiedliche Farben zur Auswahl.
<G-vec00872-002-s538><cover.hüllen><en> Protect the front of your Samsung Galaxy S7 Edge from scratches, scrapes and front-on impacts with the official S View cover.
<G-vec00872-002-s538><cover.hüllen><de> Schützen Sie die Vorderseite vor Ihrem Samsung Galaxy A5 vor Kratzern, Schrammen und sonstigen Einwirkungenmit der offiziellen S View Hülle.
<G-vec00872-002-s539><cover.hüllen><en> The process took place with him visibly, which takes place with every man, whose soul has spiritualized itself through love, so the bodily cover falls.
<G-vec00872-002-s539><cover.hüllen><de> An Ihm vollzog sich der Vorgang sichtbar, der sich an jedem Menschen vollzieht, dessen Seele sich vergeistigt hat durch die Liebe, so die körperliche Hülle fällt.
<G-vec00872-002-s540><cover.hüllen><en> If the dark cover would be pulled back from men and entry be granted to the light of eternal truth, so the earth would soon be an Eden, a place of happy, perfect spirit beings, who know no trouble anymore, because men would have reached the destination, having won back their original state, which guarantees a life in brightest light and full possession of power.
<G-vec00872-002-s540><cover.hüllen><de> Würde die dunkle Hülle von den Menschen zurückgeschlagen werden und dem Licht der ewigen Wahrheit Zutritt gewährt, so würde bald die Erde ein Eden sein, eine Stätte glückseliger, vollkommener Geistwesen, die keine Not mehr kennen, weil die Menschen das Ziel erreicht hätten, ihren Urzustand wiedergewonnen zu haben, der ein Leben in hellstem Licht und im Vollbesitz der Kraft verbürgt.
<G-vec00872-002-s541><cover.hüllen><en> If man moves in divine order, then also the state of ignorance will get lost; man will increase in understanding; his knowledge will be in accordance to truth; his thinking will always be right; his will turn towards good, and all activity will be caused by the love towards God and towards the neighbour – the soul of man will become perfect, as it is its purpose, and finally be able to take off the earthly cover to enter the spiritual kingdom as light being free from care, which can work in its own happiness in all power and wisdom.
<G-vec00872-002-s541><cover.hüllen><de> Bewegt sich der Mensch in göttlicher Ordnung, dann wird sich auch der Zustand der Unwissenheit verlieren, es wird der Mensch zunehmen an Erkenntnis, sein Wissen wird der Wahrheit entsprechen, sein Denken wird stets recht sein, sein Wille sich dem Guten zuwenden, und jegliche Tätigkeit wird die Liebe zu Gott und zum Nächsten zum Anlaß haben - es wird die Seele des Menschen vollkommen werden, wie es ihre Bestimmung ist, und die irdische Hülle zuletzt ablegen können, um unbeschwert einzugehen in das geistige Reich als Lichtwesen, das in aller Kraft und Weisheit wirken kann zur eigenen Beglückung.
<G-vec00872-002-s542><cover.hüllen><en> The quick-assembly strap makes immediate OPENING AND ASSEMBLY possible IN ONE MOTION, without first having to take the probe out of its cover.
<G-vec00872-002-s542><cover.hüllen><de> Die Schnellspannschlaufe ermöglicht unmittelbares ÖFFNEN UND SPANNEN MIT EINEM HANDGRIFF, ohne die Sonde vorher aus der Hülle nehmen zu müssen.
<G-vec00872-002-s543><cover.hüllen><en> The object was to design a durable cover, suitable for practical and everyday use, for an innovative cordless drill which is specially used for the treatment of dental roots, as well as for the iPad responsible for the controls of this instrument. There were particular requirements to be met by this project, not least with reference to hygiene and ease of cleaning.
<G-vec00872-002-s543><cover.hüllen><de> Für einen neuartigen, kabellosen Bohrer, der speziell zur Zahnwurzelbehandlung eingesetzt wird, sowie für ein iPad, das der Steuerung dieses Instrumentes dient, galt es eine dauerhafte und im Praxisalltag einsetzbare Hülle zu entwickeln, die nicht zuletzt besonderen Anforderungen hinsichtlich Hygiene und Reinigungsmöglichkeit genügen musste.
<G-vec00872-002-s544><cover.hüllen><en> The cover for the back of appreciating its X-Line design.
<G-vec00872-002-s544><cover.hüllen><de> Die Hülle für die Rückseite begeistert durch sein X-Line Design.
<G-vec00872-002-s545><cover.hüllen><en> For example, we have a stand-case, that in contrast to a normal cover opens on the top, so you can put your e-reader down on for example a table.
<G-vec00872-002-s545><cover.hüllen><de> Wir haben zum Beispiel eine Standhülle, die man im Gegensatz zu einer normalen Hülle oben öffnet, damit man seinen E-Reader zum Beispiel auf einem Tisch ablegen kann.
<G-vec00872-002-s546><cover.hüllen><en> The cover hardly adds anything to your iPad, so you can still take your iPad Air 2 easily.
<G-vec00872-002-s546><cover.hüllen><de> Die Hülle macht Ihr iPad kaum schwerer, also können Sie Ihr iPad Air 2 leicht mitnehmen.
<G-vec00872-002-s548><cover.hüllen><en> The Elite Carbon cover count with all outputs in order to fit perfectly with your mobile, so that you can get the best of it without remove the protection.
<G-vec00872-002-s548><cover.hüllen><de> Die Hülle hat alle Schlitze und Öffnungen, um perfekt mit Ihrem Handy zu passen, damit Sie das Beste davon genießen können, ohne es vom Schutz zu entfernen.
<G-vec00872-002-s549><cover.hüllen><en> Simple cover with rectangular viewing window, zipper, eyelet and optionally with logo.
<G-vec00872-002-s549><cover.hüllen><de> Einfache Hülle mit eckigem Sichtfenster, Reißverschluss und Öse; optional mit Logo.
<G-vec00872-002-s550><cover.hüllen><en> This fitted plastic cover helps protect the chair, but still retains the 570's curves and comfort.
<G-vec00872-002-s550><cover.hüllen><de> Diese passende Kunststoff Hülle schützt den Stuhl, ohne den Komfort und die Form des Kundenstuhls zu beeinträchtigen.
