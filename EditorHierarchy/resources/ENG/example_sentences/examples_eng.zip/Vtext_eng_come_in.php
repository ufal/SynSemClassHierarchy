<G-vec00070-002-s190><come_in.sein><en> Surf boots come in different thicknesses such as 0.5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm or even 7 mm thick.
<G-vec00070-002-s190><come_in.sein><de> Surfschuhe gibt es in verschiedenen Stärken wie 0,5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm oder sogar 7 mm.
<G-vec00070-002-s191><come_in.sein><en> Chatbots come in different shapes and forms.
<G-vec00070-002-s191><come_in.sein><de> Chatbots gibt es in verschiedenen Formen und Arten.
<G-vec00070-002-s192><come_in.sein><en> Beacons come in all kinds of different formats, are scalable and highly portable. Benefits:
<G-vec00070-002-s192><come_in.sein><de> Beacons gibt es in den unterschiedlichsten Formen, sie sind skalierbar und sehr portabel.
<G-vec00070-002-s193><come_in.sein><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Wiko Sunny You'll never have to buy another screen protector for the life of your phone with the Olixar 2-in-1 screen protector pack
<G-vec00070-002-s193><come_in.sein><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Galaxy A5 2017 haben.
<G-vec00070-002-s194><come_in.sein><en> The Nucleus 6 sound processors come in a variety of colours designed to blend in with hair and skin tones.
<G-vec00070-002-s194><come_in.sein><de> Den Nucleus 6 Soundprozessor gibt es in verschiedenen Farbtönen, die zu Haut- und Haarfarben passen.
<G-vec00070-002-s195><come_in.sein><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Huawei P8 Lite.
<G-vec00070-002-s195><come_in.sein><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Gear S3 Smartwatch haben.
<G-vec00070-002-s196><come_in.sein><en> PCs come in all shapes and sizes, and the exact same tweaks might have different effects on different PC setups.
<G-vec00070-002-s196><come_in.sein><de> PCs gibt es in allen Farben und Formen, und exakt gleiche Anpassungen können verschiedene Auswirkungen auf verschiedenen PCs haben.
<G-vec00070-002-s197><come_in.sein><en> These garments come in a wide variety of styles: Tops which create a wasp waist under A-line dresses, high-waisted panties which optimally slim the stomach, upper thighs and bottom for skinny trousers, and undergarments which form a slim silhouette from chest to knee under tight-fitting knitted dresses.
<G-vec00070-002-s197><come_in.sein><de> Die Formwäsche gibt es in den unterschiedlichsten Varianten: Tops, die eine Wespentaille unter A-Linien-Kleider zaubern, Highwaist-Panties, die Bauch, Oberschenkel und Po optimal für Skinny Hosen schmälern, und Unterkleider, die von Brust bis Knie eine schlanke Silhouette unter anliegenden Strickkleidern formen.
<G-vec00070-002-s198><come_in.sein><en> Progressive Slots come in all shapes and sizes in the world of Online Gambling.
<G-vec00070-002-s198><come_in.sein><de> Progressive Slots Gibt es in allen Formen und Größen in der Welt der Online-Glücksspiel.
<G-vec00070-002-s199><come_in.sein><en> Cap constructions come in many shapes and sizes.
<G-vec00070-002-s199><come_in.sein><de> Diese Kappenkonstruktionen gibt es in vielen Formen und Größen.
<G-vec00070-002-s200><come_in.sein><en> Short-term trades come in three varieties, the typical 60 second options and the newest addition called the 2 and 5-minute expiries.
<G-vec00070-002-s200><come_in.sein><de> Kurzfristige Trades gibt es in drei Sorten, die typischen 60 Sekunden Optionen und die neueste Ergänzung genannt die 2 und 5-Minuten-Abläufe.
<G-vec00070-002-s201><come_in.sein><en> Lens filters generally come in two varieties: screw-on and front filters.
<G-vec00070-002-s201><come_in.sein><de> In der Regel gibt es Linsenfilter in zwei Varianten: Anschraub- und Frontfilter.
<G-vec00070-002-s202><come_in.sein><en> Nacho trays come in black / large with 2 cups for nachos...
<G-vec00070-002-s202><come_in.sein><de> Nachoschalen gibt es in der Ausführung schwarz / groß mit...
<G-vec00070-002-s203><come_in.sein><en> Coins come in 50 øre as well as 1, 2, 5, 10 and 20 Kroner.
<G-vec00070-002-s203><come_in.sein><de> Münzen gibt es in 50 Öre sowie 1, 2, 5, 10 und 20 Kronen.
<G-vec00070-002-s204><come_in.sein><en> All three series come with matching leggings, which are not a only a sexy accessory for the beach, but also the perfect garment for any type of beach activity – from beach volleyball to yoga workouts.
<G-vec00070-002-s204><come_in.sein><de> Zu allen drei Serien gibt es die passende Hose im Leggins-Style, die nicht nur ein sexy Strand-Accessoire ist, sondern auch der ideale Begleiter für jede Form von Strandaktivität – von Beachvolleyball bis zum Yoga-Workout.
<G-vec00070-002-s205><come_in.sein><en> Themes come in many different shapes, from blank themes with only the bare necessities, to more advanced themes with tons of features.
<G-vec00070-002-s205><come_in.sein><de> Themes gibt es in vielen verschiedenen Formen, von leeren Themes mit nur dem Nötigsten bis hin zu fortgeschritteneren Themes mit unzähligen Funktionen.
<G-vec00070-002-s206><come_in.sein><en> Heart rate monitors come in a variety of different models, with varying levels of functionality.
<G-vec00070-002-s206><come_in.sein><de> Herzfrequenzmesser gibt es in verschiedenen Modellen mit unterschiedlichen Funktionen.
<G-vec00070-002-s208><come_in.sein><en> Hotels in Germany come in all price ranges and equipments.
<G-vec00070-002-s208><come_in.sein><de> Hotels in Deutschland gibt es in allen Preisklassen und Ausstattungen.
<G-vec00070-002-s247><come_in.sein><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00070-002-s247><come_in.sein><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00070-002-s248><come_in.sein><en> Featuring a shower, shared bathrooms also come with a bath and a bath or shower.
<G-vec00070-002-s248><come_in.sein><de> Das eigene Bad ist mit einer Badewanne oder einer Dusche ausgestattet.
<G-vec00070-002-s249><come_in.sein><en> Many tourists come here everyday to start for many mountain hikings and walks in the fabulous and magic Fanes region....
<G-vec00070-002-s249><come_in.sein><de> Es ist ein vielbesuchter Ausgangspunkt für eine Reihe von Bergbesteigungen und herrlichen Höhenwanderungen im sagenumworbenen...
<G-vec00070-002-s250><come_in.sein><en> The Race Control System bar sizes come in 45cm, 50cm and 55cm.
<G-vec00070-002-s250><come_in.sein><de> Die Race Controlsystembar ist in 45cm, 50cm und 55cm erhältlich.
<G-vec00070-002-s251><come_in.sein><en> Notably, the revised mine plan and the associated cost benefits started to come into effect in March.
<G-vec00070-002-s251><come_in.sein><de> Bemerkenswert ist, dass der überarbeitete Minenplan und die damit verbundenen Kostenvorteile im März in Kraft traten.
<G-vec00070-002-s252><come_in.sein><en> They come well-appointed with full modern amenities including free Wi-Fi, flat-screen TVs and mini bars.
<G-vec00070-002-s252><come_in.sein><de> Es ist mit modernen Annehmlichkeiten ausgestattet, die kostenfreies Wifi, einen Flachbildschirmfernseher und eine Minibar einschließen.
<G-vec00070-002-s253><come_in.sein><en> The latest generation of ROG motherboards, desktops and laptops come pre-installed with GameFirst V, powerful software that automatically prioritizes gaming and streaming network traffic.
<G-vec00070-002-s253><come_in.sein><de> Die neueste Generation der ROG-Mainboards, Desktops und Notebooks ist mit GameFirst V vorinstalliert, einer leistungsstarken Software, die Spiele und Streaming-Netzwerkverkehr automatisch priorisiert.
<G-vec00070-002-s254><come_in.sein><en> Featuring a walk-in shower, private bathrooms also come with a hairdryer and free toiletries.
<G-vec00070-002-s254><come_in.sein><de> Das angrenzende Bad ist mit einer Dusche und kostenfreien Pflegeprodukten ausgestattet.
<G-vec00070-002-s255><come_in.sein><en> Rooms and dormitories in Home Made House come with shared bathroom facilities.
<G-vec00070-002-s255><come_in.sein><de> Jedes Zimmer im Fabrika ist minimalistisch eingerichtet und bietet Zugang zum Gemeinschaftsbad.
<G-vec00070-002-s256><come_in.sein><en> These skinny fit maternity jeans by Queen mum come in a classic 5-pocket style.
<G-vec00070-002-s256><come_in.sein><de> Diese Umstandsjeans von Queen Mum ist eine klassische 5-Pocket-Slim-Jeans mit dunkler Waschung.
<G-vec00070-002-s257><come_in.sein><en> Instead we’re still fighting demons from the past that we thought we had long since exorcised — religious fundamentalism, nationalism — but they’ve all come back to haunt us.
<G-vec00070-002-s257><come_in.sein><de> Stattdessen bekämpfen wir Gespenster der Vergangenheit, die wir längst exorziert glaubten, religiösen Fundamentalismus, Nationalismus – alles ist wieder da.
<G-vec00070-002-s258><come_in.sein><en> Come, see the place where He was lying.
<G-vec00070-002-s258><come_in.sein><de> Seht, hier ist die Stelle, wo man ihn hingelegt hatte.
<G-vec00070-002-s259><come_in.sein><en> The rooms in Hotel Baudin come with a private toilet, a work desk, a closet, a dressing area and TV.
<G-vec00070-002-s259><come_in.sein><de> Dieses Hotel ist mit Heizung, einem Flachbildschirm-TV, einem Wandschrank, einem Ankleidebereich und eigener Toilette in jedem Gästezimmer ausgestattet.
<G-vec00070-002-s260><come_in.sein><en> riese und müller (ww.r-m.de) have presented their first e-bikes last year, and now they have come up with a new model: the Avenue hybrid, a comfy full suspension touring bike with a powerful TranzX support engine integrated into the front hub.
<G-vec00070-002-s260><come_in.sein><de> Die im letzten Jahr eingeführte E-Bike-Produktpalette von riese und müller (www.r-m.de) wird um ein Modell erweitert: Als komfortables Tourenrad mit Elektrounterstützung ist in der kommenden Saison das Avenue hybrid am Start.
<G-vec00070-002-s261><come_in.sein><en> From the blood of the dead, from the fat of the strong, the bow of Jonathan was not turned back, the sword of Saul did not come back unused.
<G-vec00070-002-s261><come_in.sein><de> 22 Der Bogen Jonathans hat nie gefehlt, und das Schwert Sauls ist nie leer wiedergekommen von dem Blut der Erschlagenen und vom Fett der Helden.
<G-vec00070-002-s262><come_in.sein><en> All rooms come with a flat-screen TV with satellite channels.
<G-vec00070-002-s262><come_in.sein><de> Die Unterkunft ist mit einem Flachbild-Sat-TV ausgestattet.
<G-vec00070-002-s263><come_in.sein><en> The private bathrooms come with a bath or shower and a toilet.
<G-vec00070-002-s263><come_in.sein><de> Das eigene Bad ist mit einer Badewanne oder Dusche und einem WC ausgestattet.
<G-vec00070-002-s264><come_in.sein><en> Hebrews 9:11: But Christ being come an high priest of good things to come, by a greater and more perfect tabernacle, not made with hands, that is to say, not of this building;
<G-vec00070-002-s264><come_in.sein><de> Unser gegenwärtiges Verhältnis zu Christus ist jedoch ein himmlisches; Er ist Hoherpriester in einer besseren und vollkommeneren Hütte, die nicht mit Händen gemacht ist, d. h. nicht zu dieser Schöpfung gehört; Er ist im Himmel, und wir haben dort unsern Platz.
<G-vec00070-002-s265><come_in.sein><en> The Pro versions come with more high-end parts than the other Xenon models, and the visual design has been upgraded as well.
<G-vec00070-002-s265><come_in.sein><de> Die Pro-Version ist mit mehr High-End-Teilen ausgestattet als die anderen Xenon-Modelle und auch das visuelle Design wurde verbessert.
<G-vec00070-002-s456><come_in.sein><en> Biofuel can come in solid, liquid, or gaseous form.
<G-vec00070-002-s456><come_in.sein><de> Biobrennstoffe können fester, flüssiger oder gasförmiger Natur sein.
<G-vec00070-002-s457><come_in.sein><en> It is very common for such potentially unwanted applications to come bundled with freeware and adware.
<G-vec00070-002-s457><come_in.sein><de> Es ist durchaus üblich, dass solche potenziell unerwünschten Anwendungen mit Freeware und Adware gebündelt sein.
<G-vec00070-002-s458><come_in.sein><en> 13 And seeing a fig-tree afar off, having leaves, he came, if haply he might find any thing on it: and when he came to it, he found nothing but leaves: for the time of figs had not yet come.
<G-vec00070-002-s458><come_in.sein><de> 13 Und er sah einen Feigenbaum von ferne, der Blätter hatte; da trat er hinzu, ob er etwas darauf fände, und da er hinzukam, fand er nichts denn nur Blätter, denn es war noch nicht Zeit, daß Feigen sein sollten.
<G-vec00070-002-s459><come_in.sein><en> The end of the Italian Grand Prix also marked the end of an epoch: After 16 years, Formel Schumi should come to an end for the time being, the end of the season also meaning the end of an era for Ferrari, the most successful epoch a Formula 1 driver ever had together with his team.
<G-vec00070-002-s459><come_in.sein><de> Dass Ende des Großen Preises von Italien markiert auch das rasende Ende einer Epoche: Nach 16 Jahren soll vorerst Schluss sein mit der Formel Schumi, geht zum Saisonende auch eine Zeitrechnung von Ferrari zu Ende, die erfolgreichste Epoche, die je ein Formel-1-Fahrer mit seinem Team hatte.
<G-vec00070-002-s460><come_in.sein><en> The embossed wax must come from organic farming.
<G-vec00070-002-s460><come_in.sein><de> Das Imprägnierwachs muss aus kontrolliert biologischem Anbau sein.
<G-vec00070-002-s461><come_in.sein><en> Therefore, it should come as no surprise that the background of the game shows a vast, barren landscape.
<G-vec00070-002-s461><come_in.sein><de> Daher sollte es keine Überraschung sein, dass der Hintergrund des Spiels eine weite, öde Landschaft zeigt.
<G-vec00070-002-s462><come_in.sein><en> Another example when the “nofollow" attribute can come handy are widget links.
<G-vec00070-002-s462><come_in.sein><de> Ein weiteres Beispiel für einen Fall, in dem das Attribut "nofollow" praktisch sein kann, sind Widget-Links.
<G-vec00070-002-s463><come_in.sein><en> 13:14 And it shall come to pass, that as the chased roe, and as sheep that no man gathereth, they shall turn every man to his own people, and shall flee every man to his own land.
<G-vec00070-002-s463><come_in.sein><de> 13:14 Und es wird wie mit einer verscheuchten Gazelle sein und wie mit einer Herde, die niemand sammelt: jeder wird sich zu seinem Volk wenden und jeder in sein Land fliehen.
<G-vec00070-002-s464><come_in.sein><en> Today the rule is: anyone can come in who earns their living in the sports business and who has a relevant business relationship with at least one of the exhibitors.
<G-vec00070-002-s464><come_in.sein><de> Heute gilt: Zugelassen ist, wer sein Geld im Sport Business verdient und mit mindestens einem Aussteller eine einschlägige Geschäftsbeziehung hat.
<G-vec00070-002-s465><come_in.sein><en> The Ability quickly to tie around the waist can come in handy always.
<G-vec00070-002-s465><come_in.sein><de> Die Fähigkeit, schnell binden Sie sich um die eigene Taille kann immer nützlich sein.
<G-vec00070-002-s466><come_in.sein><en> Its Facebook messenger block feature can come in handy for the parents to ensure that their kids don’t engage in inappropriate activities.
<G-vec00070-002-s466><come_in.sein><de> Die Facebook-Messenger-Block -Funktion kann für die Eltern nützlich sein, um sicherzustellen, dass ihre Kinder keine unangemessenen Aktivitäten ausführen.
<G-vec00070-002-s467><come_in.sein><en> INTRODUCTION Jesus tells us: “Whoever wishes to come after me must deny himself, take up his cross each day and follow me”. This is an invitation addressed to everyone: to those who are married and those who are single, to young people, adults and the elderly, to the rich and poor, and to people of every nationality.
<G-vec00070-002-s467><come_in.sein><de> EINFÜHRUNG Jesus sagt: „Wer mein Jünger sein will, der verleugne sich selbst, nehme täglich sein Kreuz auf sich und folge mir nach.“ Das ist eine Aufforderung, die allen gilt, Ledigen und Verheirateten, Jugendlichen, Erwachsenen und alten Menschen, Reichen und Armen, Menschen aller Nationalitäten.
<G-vec00070-002-s468><come_in.sein><en> The LTE and 3G model should come out by the end of November.
<G-vec00070-002-s468><come_in.sein><de> Die Version mit LTE- und 3G-fähigem Mobilfunkmodul soll bis Ende November lieferbar sein.
<G-vec00070-002-s469><come_in.sein><en> And we though thought that we must had come decent far.
<G-vec00070-002-s469><come_in.sein><de> Und wir meinten schon, dass wir ganz ordentlich vorangekommen sein muessten.
<G-vec00070-002-s470><come_in.sein><en> You’ll come to your own conclusions.
<G-vec00070-002-s470><come_in.sein><de> Sie werden dann in der Lage sein, eigene Schlüsse zu ziehen.
<G-vec00070-002-s471><come_in.sein><en> When making a green smoothie I can rest assure it’ll come out silky smooth, every time.
<G-vec00070-002-s471><come_in.sein><de> Wenn ich grüne Smoothies herstelle, dann kann ich mir sicher sein, dass jedes Mal ein seidig weicher flüssiger Smoothie entsteht.
<G-vec00070-002-s472><come_in.sein><en> 8 And David saith on that day, 'Any one smiting the Jebusite, (let him go up by the watercourse), and the lame and the blind -- the hated of David's soul,' -- because the blind and lame say, 'He doth not come into the house.'
<G-vec00070-002-s472><come_in.sein><de> 8Da sprach David an diesem Tage: Wer die Jebusiter schlägt und durch den Schacht hinaufsteigt und die Lahmen und Blinden erschlägt, die David verhasst sind, der soll Hauptmann und Oberster sein.
<G-vec00070-002-s473><come_in.sein><en> At the same time, there is debate as to whether tighter capital requirements could come with a longer-term cost for the real economy.
<G-vec00070-002-s473><come_in.sein><de> Gleichzeitig gibt es eine Debatte darüber, ob höhere Kapitalanforderungen mit längerfristigen Kosten für die Realwirtschaft verbunden sein könnten.
<G-vec00070-002-s474><come_in.sein><en> As the oil acts on the sensitive oral mucosa for 10 to 20 minutes, the oil seeds and nuts should come from certified organic farming.
<G-vec00070-002-s474><come_in.sein><de> Da das Öl 10 bis 20 Minuten auf die empfindliche Mundschleimhaut einwirkt, sollte die Auswahl eines dafür bevorzugten Öles unbedingt auf Bio-Pflanzenöle ausgerichtet sein, die aus Ölsaaten und Nüssen aus kontrolliert biologischem Anbau und kalt gepresst werden.
<G-vec00070-002-s513><come_in.sein><en> The proposed change shall come into effect two (2) months after the date of the change notice, unless you have given us notice that you object to the proposed changes before the changes come into effect.
<G-vec00070-002-s513><come_in.sein><de> Die geplante Änderung erlangt zwei (2) Monate nach dem Datum der Änderungsnachricht Gültigkeit, es sei denn, Sie benachrichtigen uns vor Umsetzung der Änderungen dahingehend, dass Sie mit der Änderung nicht einverstanden sind.
<G-vec00070-002-s514><come_in.sein><en> They also come with a flat-screen satellite TV, a seating area, and a bathroom with bathrobes and a hairdryer.
<G-vec00070-002-s514><come_in.sein><de> Ein Staubsauger, ein Flachbild-Sat-TV und ein Geschirrspüler sind ebenfalls vorhanden.
<G-vec00070-002-s515><come_in.sein><en> We'll be helpless to stop the process, we'll have to come back.
<G-vec00070-002-s515><come_in.sein><de> Und wir können den Prozess nicht aufhalten, wir sind gezwungen, zurückzukommen.
<G-vec00070-002-s516><come_in.sein><en> The comfortable rooms come with satellite TV and a fridge... xem hơn
<G-vec00070-002-s516><come_in.sein><de> Die komfortablen Zimmer sind mit Sat-TV und einem Kühlschrank ausgestattet.
<G-vec00070-002-s517><come_in.sein><en> Many of today's safety-oriented components also come equipped with their own bus interface and can be connected to the network directly.
<G-vec00070-002-s517><come_in.sein><de> Viele sicherheitsgerichtete Komponten sind darüber hinaus heutzutage mit einem eigenen Busanschluss ausgestattet und können direkt ans Netzwerk angeschlossen werden.
<G-vec00070-002-s518><come_in.sein><en> The rooms in Riad Amira Victoria & Spa come with individual climate control, an in-room safe, free Wi-Fi, a balcony and a wardrobe.
<G-vec00070-002-s518><come_in.sein><de> Sie alle sind mit WLAN, einem individuellen Temperaturregler, einem Laptop-geeigneten Safe, einem privaten Balkon und einem Kachelofen ausgestattet.
<G-vec00070-002-s519><come_in.sein><en> Our food processing knives and blades come in straight, circular, pointed tip, toothed, serrated, scalloped, perforated shapes and as interlocked blades for guillotine cutting.
<G-vec00070-002-s519><come_in.sein><de> Unsere Maschinenmesser und Industrieklingen für Folien- und Folienumformung sind in gerader, kreisförmiger, spitzer Spitze, gezahnt, gezahnt, gezähnt, perforiert und viele andere Formen.
<G-vec00070-002-s520><come_in.sein><en> On this feast of the Holy Apostles Peter and Paul, I am happy to welcome the French-speaking pilgrims who have come to Rome on the occasion of the conferral of the Pallium on the new Metropolitan Archbishops.
<G-vec00070-002-s520><come_in.sein><de> Nach diesen Worten in italienischer Sprache fuhr der Heilige Vater auf französisch fort: Herzlich begrüße ich die Pilger, die aus Frankreich und Afrika gekommen sind, um die neuen Metropolitan-Erzbischöfe zu begleiten.
<G-vec00070-002-s521><come_in.sein><en> In addition to a toilet, bathrooms come with a bath and a complimentary toiletries set.
<G-vec00070-002-s521><come_in.sein><de> Die Badezimmer sind ausgestattet mit eine Toilette und ein Bad, sowie eine Dusch-Badewannenkombination.
<G-vec00070-002-s522><come_in.sein><en> All rooms come with a private bathroom fitted with a bidet and shower.
<G-vec00070-002-s522><come_in.sein><de> Die Zimmer sind modern eingerichtet und mit einem eigenen Bad ausgestattet.
<G-vec00070-002-s523><come_in.sein><en> The rooms all come with an en suite bathroom, a direct dial telephone, satellite/ cable TV, and central heating.
<G-vec00070-002-s523><come_in.sein><de> Die zweckmäßig eingerichteten Zimmer sind mit einem Bad/WC, Direktwahltelefon, Internetzugang und Zentralheizung ausgestattet.
<G-vec00070-002-s524><come_in.sein><en> Basic rooms come with bunk beds.
<G-vec00070-002-s524><come_in.sein><de> Grundlegende Zimmer sind mit Etagenbetten ausgestattet.
<G-vec00070-002-s525><come_in.sein><en> Spacious rooms in this Wuxi hotel come outfitted with internet access, LCD TVs, bathtubs and all modern conveniences.
<G-vec00070-002-s525><come_in.sein><de> Die geräumigen Zimmer sind mit Internetzugang, LCD-TVs, Badewannen und sämtlichen modernen Annehmlichkeiten ausgestattet.
<G-vec00070-002-s526><come_in.sein><en> All of our shoes come with a 1-year guarantee against manufacturing defects.
<G-vec00070-002-s526><come_in.sein><de> Alle unsere Schuhe sind mit einer 2-Jahres-Garantie auf Herstellungsmängel ausgestattet.
<G-vec00070-002-s527><come_in.sein><en> You can load these machines with a forklift, by hand, or by using an infeed conveyor, and they come equipped with either an electrical or hydraulic drive.
<G-vec00070-002-s527><come_in.sein><de> WLK Zerkleinerer können per Förderband, Stapler oder manuell beschickt werden und sind wahlweise mit mechanischem oder hydraulischem Antrieb ausgestattet.
<G-vec00070-002-s528><come_in.sein><en> Some critics and armchair scholars have come to the conclusion that some of the revival story elements found in Joseph Smith's 1838 historical narrative are not really accurate, but rather are representative of a conflation of facts.
<G-vec00070-002-s528><come_in.sein><de> Einige Kritiker und Lehnsesselgelehrte sind zu dem Schluss gekommen, dass einige der Elemente der Erweckungsgeschichte, die man in Joseph Smiths historischem Bericht von 1838 findet, nicht wirklich genau seien, sondern die Verschmelzung unterschiedlicher Tatsachen darstellten.
<G-vec00070-002-s529><come_in.sein><en> And since they come as standard in iOS and OS X, these technologies transform Apple devices into affordable assistive devices.
<G-vec00070-002-s529><come_in.sein><de> Und da sie standardmäßig in iOS und OS X integriert sind, machen sie die Apple Geräte zu erschwinglichen Hilfswerkzeugen.
<G-vec00070-002-s530><come_in.sein><en> You use the code and objects you’re already familiar with to quickly develop your own solutions—solutions that work with the same single-console simplicity you’ve come to depend on from LANDesk.
<G-vec00070-002-s530><come_in.sein><de> Sie verwenden Code und Objekte, mit denen Sie bereits vertraut sind, zur zügigen Entwicklung eigener Lösungen, die ebenso einfach und über eine zentrale Konsole einsetzbar sind, wie alle anderen LANDesk Lösungen.
<G-vec00070-002-s531><come_in.sein><en> Toilet tissue Toilet tissue, small rolls, 2-ply, come in packages of 56 units each.
<G-vec00070-002-s531><come_in.sein><de> Toilettenpapier, Kleinrollen, 2-lagig, 400 Blatt sind lieferbar in der Packung mit 56 Stück.
<G-vec01096-002-s152><come_in.kommen><en> Then you have come to the right place.
<G-vec01096-002-s152><come_in.kommen><de> Dann sind Sie zum rechten Platz gekommen.
<G-vec01096-002-s153><come_in.kommen><en> You have come to the right page.
<G-vec01096-002-s153><come_in.kommen><de> Sie sind zur rechten Seite gekommen.
<G-vec01096-002-s154><come_in.kommen><en> "The hour is come that the Son of man should be glorified" (John 12:23).
<G-vec01096-002-s154><come_in.kommen><de> "Die Stunde ist gekommen, dass der Menschensohn verherrlicht werden sollte" (Johannes 12:23).
<G-vec01096-002-s155><come_in.kommen><en> The Spirit had come upon him powerfully, and he had broken down, weeping.
<G-vec01096-002-s155><come_in.kommen><de> Der Geist war mächtig auf ihn gekommen, und er war weinend zusammengebrochen.
<G-vec01096-002-s156><come_in.kommen><en> “For judgment I have come into this world, so that the blind will see and those who see will become blind.”
<G-vec01096-002-s156><come_in.kommen><de> 39Und Jesus sprach: Ich bin zum Gericht auf diese Welt gekommen, auf daß, die da nicht sehen, sehend werden, und die da sehen, blind werden.
<G-vec01096-002-s157><come_in.kommen><en> SHAKIR: Certainly a Messenger has come to you from among yourselves; grievous to him is your falling into distress, excessively solicitous respecting you; to the believers (he is) compassionate, 009.129
<G-vec01096-002-s157><come_in.kommen><de> Wahrlich, ein Gesandter ist zu euch gekommen aus eurer Mitte; schmerzlich ist es ihm, daß ihr in Unheil geraten solltet; eure Wohlfahrt begehrt er eifrig; gegen die Gläubigen ist er gütig, barmherzig.
<G-vec01096-002-s158><come_in.kommen><en> I twisted around and ran back the way I had come.
<G-vec01096-002-s158><come_in.kommen><de> Ich drehte mich weg und lief den Weg zurück, den wir gekommen waren.
<G-vec01096-002-s159><come_in.kommen><en> Make a photo of the defect and make photos that show how the product was installed and how it has come to the damage if possible.
<G-vec01096-002-s159><come_in.kommen><de> Fotografieren Sie den Defekt und versuchen Sie dabei, auf den Fotos deutlich zu machen, wie das Produkt eingebaut war und wie es zu dem Schaden gekommen ist.
<G-vec01096-002-s160><come_in.kommen><en> Gehazi answered, “Yes, but my master sent me to say, ‘Two young men who are members of a group of prophets have just now come to me from the hills of Ephraim.
<G-vec01096-002-s160><come_in.kommen><de> Mein Herr sendet mich und lässt sagen: Siehe, eben jetzt sind vom Gebirge Ephraim zwei junge Männer von den Söhnen der Propheten zu mir gekommen.
<G-vec01096-002-s161><come_in.kommen><en> 12 "But I tell you: Elijah has already come, and they didn't recognize him. On the contrary, they did whatever they pleased to him.
<G-vec01096-002-s161><come_in.kommen><de> 13 Aber ich sage euch, daß auch Elias gekommen ist, und sie haben ihm getan, was irgend sie wollten, so wie über ihn geschrieben steht.
<G-vec01096-002-s162><come_in.kommen><en> But I am sure I have always thought of Christmas-time, when it has come round—apart from the veneration due to its sacred name and origin, if anything belonging to it can be apart from that—as a good time; a kind, forgiving, charitable, pleasant time; the only time I know of, in the long calendar of the year, when men and women seem by one consent to open their shut-up hearts freely, and to think of people below them as if they really were fellow-passengers to the grave, and not another race of creatures bound on other journeys.
<G-vec01096-002-s162><come_in.kommen><de> Aber das weiß ich bestimmt, daß ich Weihnachten, wenn es gekommen ist, abgesehen von der Verehrung, die wir seinem heiligen Namen und Ursprung schuldig sind, immer als eine gute Zeit angeschaut habe, als eine liebe Zeit, als die Zeit der Vergebung und des Erbarmens, als die einzige Zeit, die ich im langen Kalenderjahr kenne, wo die Menschen einträchtig ihre verschlossenen Herzen auftun und die andern Menschen betrachten, als wenn sie wirklich Reisegenossen nach dem Grabe wären und nicht eine ganz andere Art von Lebewesen, die für einen ganz andern Weg vorgesehen sind.
<G-vec01096-002-s163><come_in.kommen><en> But I have also come to share with you the joys and hopes, efforts and commitments, ideals and aspirations of this diocesan community.
<G-vec01096-002-s163><come_in.kommen><de> Doch ich bin auch gekommen, um mit euch Freuden und Hoffnungen, Mühen und Anstrengungen, Ideale und Wünsche dieser Diözesangemeinschaft zu teilen.
<G-vec01096-002-s164><come_in.kommen><en> It’s a funny story that just goes to show how far both our businesses have come.
<G-vec01096-002-s164><come_in.kommen><de> Es ist eine lustige Geschichte, die zeigt, wie weit unsere beiden Unternehmen gekommen sind.
<G-vec01096-002-s165><come_in.kommen><en> 27She said to Him, Yes, Lord, I have believed [I do believe] that You are the Christ (the Messiah, the Anointed One), the Son of God, [even He] Who was to come into the world.
<G-vec01096-002-s165><come_in.kommen><de> 27Sie spricht zu ihm: HERR, ja, ich glaube, daß du bist Christus, der Sohn Gottes, der in die Welt gekommen ist.
<G-vec01096-002-s166><come_in.kommen><en> Acts 1, verse 8 and 9 “But you will receive power when the Holy Spirit has come upon you. You will be witnesses to me in Jerusalem, in all Judea and Samaria, and to the uttermost parts of the earth.”
<G-vec01096-002-s166><come_in.kommen><de> Apostelgeschichte 1, Vers 8 und 9 Aber ihr werdet Kraft empfangen, wenn der Heilige Geist auf euch gekommen ist; und ihr werdet meine Zeugen sein, sowohl in Jerusalem als auch in ganz Judäa und Samaria und bis an das Ende der Erde.
<G-vec01096-002-s167><come_in.kommen><en> 13Thou wilt rise up, thou wilt have mercy upon Zion: for it is the time to be gracious to her, for the set time is come. 14For thy servants take pleasure in her stones, and favour her dust.
<G-vec01096-002-s167><come_in.kommen><de> 13Du wirst aufstehen, wirst dich Zions erbarmen; denn es ist Zeit, es zu begnadigen, denn gekommen ist die bestimmte Zeit; 14Denn deine Knechte haben Gefallen an seinen Steinen und haben Mitleid mit seinem Schutt.
<G-vec01096-002-s168><come_in.kommen><en> And he said, No; but I have come as captain of the armies of the Lord.
<G-vec01096-002-s168><come_in.kommen><de> Er sprach: Nein, sondern ich bin ein Fürst über das Heer des HERRN und bin jetzt gekommen.
<G-vec01096-002-s169><come_in.kommen><en> 47 “If anyone hears my words but does not keep them, I do not judge that person. For I did not come to judge the world, but to save the world.
<G-vec01096-002-s169><come_in.kommen><de> 47 Und wenn jemand meine Worte hört und nicht glaubt, so richte ich ihn nicht; denn ich bin nicht gekommen, um die Welt zu richten, sondern damit ich die Welt rette.
<G-vec01096-002-s170><come_in.kommen><en> Today, mankind has once again come to the crossroads of the transformation of the transportation energy power system.
<G-vec01096-002-s170><come_in.kommen><de> Heute ist die Menschheit wieder an den Scheideweg der Transformation des Verkehrsenergiesystems gekommen.
<G-vec01096-002-s266><come_in.kommen><en> It was a feature of the UK implementation of the EMD that KYC measures did not come into play until a client had developed a material level of activity.
<G-vec01096-002-s266><come_in.kommen><de> Ein Merkmal der Umsetzung der EGR im Vereinigten Königreich bestand darin, dass das KYC-Prinzip erst zum Tragen kam, wenn ein Kunde beachtliche Aktivitäten entfaltete.
<G-vec01096-002-s267><come_in.kommen><en> I've come to understand the inner logic of the Tech. It is expressed in the Factors, the Axioms, and the Class VIII materials.
<G-vec01096-002-s267><come_in.kommen><de> Ich kam zum Verständnis der inneren Logik der Tech, die in den Faktoren, den Axiomen und den Class VIII Materialien ausgedrückt ist.
<G-vec01096-002-s268><come_in.kommen><en> No one has seen you come but you have come to stay.
<G-vec01096-002-s268><come_in.kommen><de> Niemand sah ihn kommen, aber er kam, um zu bleiben.
<G-vec01096-002-s269><come_in.kommen><en> Twice it has come with no tidings from abroad, but now finally with its return the knight and his servant ride back from Rome, bearing a papal ban against the widow who dared oppose the pious Bishop.
<G-vec01096-002-s269><come_in.kommen><de> Zweimal kam er, nun endlich ruft er den Rittern und Knechten ein Willkommen entgegen, die mit einem päpstlichen Briefe von Rom heimkehren, mit einem Bannbriefe über die Witwe, die den frommen Bischof zu beleidigen wagte.
<G-vec01096-002-s270><come_in.kommen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec01096-002-s270><come_in.kommen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec01096-002-s271><come_in.kommen><en> I was wearing a white gown but when reached where I was going, I come upon at least eight people sitting in chairs in half horseshoe shape.
<G-vec01096-002-s271><come_in.kommen><de> Ich trug ein weißes Gewand, aber als ich den Ort erreichte, zu dem ich hinstrebte, kam ich auf mindestens 8 Personen, die in Sesseln saßen, die hufeisenförmig aufgestellt waren.
<G-vec01096-002-s272><come_in.kommen><en> I'd come home off the road sometimes and find my wife crying.
<G-vec01096-002-s272><come_in.kommen><de> Ich kam einmal nach unserem Konzert nach Hause und fand meine Frau weinend zu Hause.
<G-vec01096-002-s273><come_in.kommen><en> Go, and you shall proceed, and come to the man of God to mount Carmel.
<G-vec01096-002-s273><come_in.kommen><de> 25 Also zog sie hin und kam zu dem Mann Gottes auf den Berg Karmel.
<G-vec01096-002-s274><come_in.kommen><en> The Term "summary" has come to us from the Latin language.
<G-vec01096-002-s274><come_in.kommen><de> Der Begriff "Zusammenfassung" kam zu uns aus der lateinischen Sprache.
<G-vec01096-002-s275><come_in.kommen><en> If Clara, who has been living in Jerusalem for years, remembers the joy of a year when she accompanied the person closest to her in the Basilica, her mother who had come to visit her, Elena waits for her parents and Sara remembers the joy of when she celebrated her Easter with his colleagues in a family atmosphere.
<G-vec01096-002-s275><come_in.kommen><de> Clara, die seit Jahren in Jerusalem wohnt, erinnert sich an die Freude des Jahres, als sie die Person, die ihr am meisten am Herzen liegt, nämlich ihre Mutter, die sie besuchen kam, in die Basilika begleitete, und so erwartet auch Elena ihre Eltern und Sara ist die Freude beim Feiern des Osterfestes mit ihren Kollegen in einer vertrauten Atmosphäre in Erinnerung geblieben.
<G-vec01096-002-s276><come_in.kommen><en> Despondent, we waited for someone from the team to come rescue us.
<G-vec01096-002-s276><come_in.kommen><de> Niedergeschlagen warteten wir darauf, dass jemand vom Team kam, um uns abzuholen.
<G-vec01096-002-s277><come_in.kommen><en> He did not realise where it had come from, though the servants who had drawn the water knew.
<G-vec01096-002-s277><come_in.kommen><de> Er wusste nicht, woher der Wein kam; die Diener aber, die das Wasser geschöpft hatten, wussten es.
<G-vec01096-002-s278><come_in.kommen><en> Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.
<G-vec01096-002-s278><come_in.kommen><de> Dennoch gewährte Ich diesen und ihren Vätern Versorgung in Fülle, bis die Wahrheit und ein offenkundiger Gesandter zu ihnen kam.
<G-vec01096-002-s279><come_in.kommen><en> They follow nothing but conjecture and what the souls desire!- Even though there has already come to them Guidance from their Lord!
<G-vec01096-002-s279><come_in.kommen><de> Sie folgen einem bloßen Wahn und dem Wunsche (ihres) Ichs, obwohl doch Weisung von ihrem Herrn zu ihnen kam.
<G-vec01096-002-s280><come_in.kommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec01096-002-s280><come_in.kommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec01096-002-s281><come_in.kommen><en> Dear children, I am your Mom and come from Heaven to lead you to My Lord.
<G-vec01096-002-s281><come_in.kommen><de> Ich bin eure Mutter und kam vom Himmel um euch zum Himmel zu fuehren.
<G-vec01096-002-s282><come_in.kommen><en> But because the Holy Spirit has come to dwell within us, and because of the promises in John 14, Jesus makes it very plain that Our Authentic Christian faith is not an esoteric religion, secret elite society, New Age or Buddhist doctrine.
<G-vec01096-002-s282><come_in.kommen><de> Aber weil der Heilige Geist kam, um in uns zu wohnen und aufgrund der Verheissungen in Johannes 14, macht es Jesus sehr deutlich, dass unser authentischer, christlicher Glaube keine esoterische Religion, keine geheime, elitäre Gesellschaft, kein New Age und keine buddhistische Lehre ist.
<G-vec01096-002-s283><come_in.kommen><en> But through their trespass salvation has come to the Gentiles, so as to make Israel jealous.
<G-vec01096-002-s283><come_in.kommen><de> Vielmehr kam durch ihr Versagen das Heil zu den Heiden, um sie selbst eifersüchtig zu machen.
<G-vec01096-002-s284><come_in.kommen><en> I saw her last one 16 months ago before I come to Germany.
<G-vec01096-002-s284><come_in.kommen><de> Ich habe sie zuletzt vor 16 Monaten gesehen, bevor ich nach Deutschland kam.
<G-vec01096-002-s285><come_in.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec01096-002-s285><come_in.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec01096-002-s286><come_in.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec01096-002-s286><come_in.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec01096-002-s287><come_in.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec01096-002-s287><come_in.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec01096-002-s288><come_in.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec01096-002-s288><come_in.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec01096-002-s289><come_in.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec01096-002-s289><come_in.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec01096-002-s290><come_in.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec01096-002-s290><come_in.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec01096-002-s291><come_in.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec01096-002-s291><come_in.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec01096-002-s292><come_in.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec01096-002-s292><come_in.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec01096-002-s293><come_in.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec01096-002-s293><come_in.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec01096-002-s294><come_in.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec01096-002-s294><come_in.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec01096-002-s295><come_in.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec01096-002-s295><come_in.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec01096-002-s296><come_in.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec01096-002-s296><come_in.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec01096-002-s297><come_in.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec01096-002-s297><come_in.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec01096-002-s298><come_in.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec01096-002-s298><come_in.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec01096-002-s299><come_in.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec01096-002-s299><come_in.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec01096-002-s300><come_in.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec01096-002-s300><come_in.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec01096-002-s301><come_in.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec01096-002-s301><come_in.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec01096-002-s302><come_in.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec01096-002-s302><come_in.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec01096-002-s303><come_in.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec01096-002-s303><come_in.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec01096-002-s304><come_in.kommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec01096-002-s304><come_in.kommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec01096-002-s305><come_in.kommen><en> All your wishes - come true here.
<G-vec01096-002-s305><come_in.kommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec01096-002-s306><come_in.kommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec01096-002-s306><come_in.kommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec01096-002-s307><come_in.kommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec01096-002-s307><come_in.kommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec01096-002-s308><come_in.kommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec01096-002-s308><come_in.kommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec01096-002-s309><come_in.kommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec01096-002-s309><come_in.kommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec01096-002-s310><come_in.kommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec01096-002-s310><come_in.kommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec01096-002-s311><come_in.kommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec01096-002-s311><come_in.kommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec01096-002-s312><come_in.kommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec01096-002-s312><come_in.kommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec01096-002-s313><come_in.kommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec01096-002-s313><come_in.kommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec01096-002-s314><come_in.kommen><en> Come wherever you are unknown.
<G-vec01096-002-s314><come_in.kommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec01096-002-s315><come_in.kommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec01096-002-s315><come_in.kommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec01096-002-s316><come_in.kommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec01096-002-s316><come_in.kommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec01096-002-s317><come_in.kommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec01096-002-s317><come_in.kommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec01096-002-s318><come_in.kommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec01096-002-s318><come_in.kommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec01096-002-s319><come_in.kommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec01096-002-s319><come_in.kommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec01096-002-s320><come_in.kommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec01096-002-s320><come_in.kommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec01096-002-s321><come_in.kommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec01096-002-s321><come_in.kommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec01096-002-s322><come_in.kommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec01096-002-s322><come_in.kommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec01096-002-s323><come_in.kommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec01096-002-s323><come_in.kommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec01096-002-s324><come_in.kommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec01096-002-s324><come_in.kommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec01096-002-s325><come_in.kommen><en> – English translation: I come from Britain.
<G-vec01096-002-s325><come_in.kommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec01096-002-s326><come_in.kommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec01096-002-s326><come_in.kommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec01096-002-s327><come_in.kommen><en> Will definitely come back if headed to this area again.
<G-vec01096-002-s327><come_in.kommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec01096-002-s328><come_in.kommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec01096-002-s328><come_in.kommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec01096-002-s329><come_in.kommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec01096-002-s329><come_in.kommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec01096-002-s330><come_in.kommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec01096-002-s330><come_in.kommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec01096-002-s331><come_in.kommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec01096-002-s331><come_in.kommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec01096-002-s332><come_in.kommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec01096-002-s332><come_in.kommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec01096-002-s333><come_in.kommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec01096-002-s333><come_in.kommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec01096-002-s334><come_in.kommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec01096-002-s334><come_in.kommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec01096-002-s335><come_in.kommen><en> I come from the picturesque city of brides, Sumy.
<G-vec01096-002-s335><come_in.kommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec01096-002-s336><come_in.kommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec01096-002-s336><come_in.kommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec01096-002-s337><come_in.kommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec01096-002-s337><come_in.kommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec01096-002-s338><come_in.kommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec01096-002-s338><come_in.kommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec01096-002-s339><come_in.kommen><en> And so I come to a second reflection.
<G-vec01096-002-s339><come_in.kommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec01096-002-s340><come_in.kommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec01096-002-s340><come_in.kommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec01096-002-s341><come_in.kommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec01096-002-s341><come_in.kommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec01096-002-s342><come_in.kommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec01096-002-s342><come_in.kommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec01096-002-s343><come_in.kommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec01096-002-s343><come_in.kommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec01096-002-s344><come_in.kommen><en> I love this country so it has been nice to be forced to come home.
<G-vec01096-002-s344><come_in.kommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec01096-002-s345><come_in.kommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec01096-002-s345><come_in.kommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec01096-002-s346><come_in.kommen><en> These now come from the cold stores.
<G-vec01096-002-s346><come_in.kommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec01096-002-s347><come_in.kommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec01096-002-s347><come_in.kommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec01096-002-s348><come_in.kommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec01096-002-s348><come_in.kommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec01096-002-s349><come_in.kommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec01096-002-s349><come_in.kommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec01096-002-s350><come_in.kommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec01096-002-s350><come_in.kommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec01096-002-s351><come_in.kommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec01096-002-s351><come_in.kommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec01096-002-s352><come_in.kommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec01096-002-s352><come_in.kommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec01096-002-s353><come_in.kommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec01096-002-s353><come_in.kommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec01096-002-s354><come_in.kommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec01096-002-s354><come_in.kommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec01096-002-s355><come_in.kommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec01096-002-s355><come_in.kommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec01096-002-s356><come_in.kommen><en> The artists come from Frohnau or other places.
<G-vec01096-002-s356><come_in.kommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec01096-002-s357><come_in.kommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec01096-002-s357><come_in.kommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec01096-002-s358><come_in.kommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec01096-002-s358><come_in.kommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec01096-002-s359><come_in.kommen><en> It looks like the babies all come in "twos" this spring.
<G-vec01096-002-s359><come_in.kommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec01096-002-s360><come_in.kommen><en> Come, see, hear, and marvel.
<G-vec01096-002-s360><come_in.kommen><de> Kommen, schauen, hören, staunen.
<G-vec01096-002-s361><come_in.kommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec01096-002-s361><come_in.kommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec01096-002-s362><come_in.kommen><en> Come to us, and you will not regret.
<G-vec01096-002-s362><come_in.kommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec01096-002-s363><come_in.kommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec01096-002-s363><come_in.kommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec01096-002-s364><come_in.kommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec01096-002-s364><come_in.kommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec01096-002-s365><come_in.kommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec01096-002-s365><come_in.kommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec01096-002-s366><come_in.kommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec01096-002-s366><come_in.kommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec01096-002-s367><come_in.kommen><en> Come and have a look or check our website.
<G-vec01096-002-s367><come_in.kommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec01096-002-s368><come_in.kommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec01096-002-s368><come_in.kommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec01096-002-s369><come_in.kommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec01096-002-s369><come_in.kommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec01096-002-s370><come_in.kommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec01096-002-s370><come_in.kommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec01096-002-s371><come_in.kommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec01096-002-s371><come_in.kommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec01096-002-s372><come_in.kommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec01096-002-s372><come_in.kommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec01096-002-s373><come_in.kommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec01096-002-s373><come_in.kommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec01096-002-s374><come_in.kommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec01096-002-s374><come_in.kommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec01096-002-s375><come_in.kommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec01096-002-s375><come_in.kommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec01096-002-s376><come_in.kommen><en> Come to Ulm – it will make a difference in your life.
<G-vec01096-002-s376><come_in.kommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec01096-002-s377><come_in.kommen><en> Just come, book it now and you will see for yourself.
<G-vec01096-002-s377><come_in.kommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec01096-002-s378><come_in.kommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec01096-002-s378><come_in.kommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec01096-002-s379><come_in.kommen><en> Here come easily in 4 steps to your desired server.
<G-vec01096-002-s379><come_in.kommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec01096-002-s399><come_in.kommen><en> Lights turn on when you come home.
<G-vec01096-002-s399><come_in.kommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec01096-002-s400><come_in.kommen><en> From there you will not come back.
<G-vec01096-002-s400><come_in.kommen><de> Von da kommst du nicht zurück.
<G-vec01096-002-s401><come_in.kommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec01096-002-s401><come_in.kommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec01096-002-s402><come_in.kommen><en> Will you come over and play for me.
<G-vec01096-002-s402><come_in.kommen><de> Kommst du rüber und spielst für mich.
<G-vec01096-002-s403><come_in.kommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec01096-002-s403><come_in.kommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec01096-002-s404><come_in.kommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec01096-002-s404><come_in.kommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec01096-002-s405><come_in.kommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec01096-002-s405><come_in.kommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec01096-002-s406><come_in.kommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec01096-002-s406><come_in.kommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec01096-002-s407><come_in.kommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec01096-002-s407><come_in.kommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec01096-002-s408><come_in.kommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec01096-002-s408><come_in.kommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec01096-002-s409><come_in.kommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec01096-002-s409><come_in.kommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec01096-002-s410><come_in.kommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec01096-002-s410><come_in.kommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec01096-002-s411><come_in.kommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec01096-002-s411><come_in.kommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec01096-002-s412><come_in.kommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec01096-002-s412><come_in.kommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec01096-002-s413><come_in.kommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec01096-002-s413><come_in.kommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec01096-002-s414><come_in.kommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec01096-002-s414><come_in.kommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec01096-002-s415><come_in.kommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec01096-002-s415><come_in.kommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec01096-002-s416><come_in.kommen><en> Moving forward is more like the platform you come from.
<G-vec01096-002-s416><come_in.kommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec01096-002-s417><come_in.kommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec01096-002-s417><come_in.kommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec01096-002-s418><come_in.kommen><en> The color must have come from cocoa powder.
<G-vec01096-002-s418><come_in.kommen><de> Die Farbe kommt von Kakaopulver.
<G-vec01096-002-s419><come_in.kommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec01096-002-s419><come_in.kommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec01096-002-s420><come_in.kommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec01096-002-s420><come_in.kommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec01096-002-s421><come_in.kommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec01096-002-s421><come_in.kommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec01096-002-s422><come_in.kommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec01096-002-s422><come_in.kommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec01096-002-s423><come_in.kommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec01096-002-s423><come_in.kommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec01096-002-s424><come_in.kommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec01096-002-s424><come_in.kommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec01096-002-s425><come_in.kommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec01096-002-s425><come_in.kommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec01096-002-s426><come_in.kommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec01096-002-s426><come_in.kommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec01096-002-s427><come_in.kommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec01096-002-s427><come_in.kommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec01096-002-s428><come_in.kommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec01096-002-s428><come_in.kommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec01096-002-s429><come_in.kommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec01096-002-s429><come_in.kommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec01096-002-s430><come_in.kommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec01096-002-s430><come_in.kommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec01096-002-s431><come_in.kommen><en> Come and see the place where the Lord was laid.
<G-vec01096-002-s431><come_in.kommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec01096-002-s432><come_in.kommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec01096-002-s432><come_in.kommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec01096-002-s433><come_in.kommen><en> Run up till you come to the snapping doors.
<G-vec01096-002-s433><come_in.kommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec01096-002-s434><come_in.kommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec01096-002-s434><come_in.kommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec01096-002-s435><come_in.kommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec01096-002-s435><come_in.kommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec01096-002-s436><come_in.kommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec01096-002-s436><come_in.kommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
