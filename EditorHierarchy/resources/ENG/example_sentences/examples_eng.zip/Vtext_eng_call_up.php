<G-vec00057-002-s133><call_up.anrufen><en> Automatically saves your device's call history to a calendar.
<G-vec00057-002-s133><call_up.anrufen><de> Speichert Anrufe automatisch im Kalender Ihres Geräts.
<G-vec00057-002-s134><call_up.anrufen><en> It displays the list of recent call that you have made or received.
<G-vec00057-002-s134><call_up.anrufen><de> Es wird die Liste der zuletzt durchgeführten oder angenommenen Anrufe angezeigt.
<G-vec00057-002-s135><call_up.anrufen><en> But when I call you never seem to be home
<G-vec00057-002-s135><call_up.anrufen><de> Aber wenn ich anrufe scheinst du nie Zuhause zu sein.
<G-vec00057-002-s136><call_up.anrufen><en> Login Mobile Spy Package, Monitor GPS locations, Call, SMS, Videos, Photos and Social Media and much more.
<G-vec00057-002-s136><call_up.anrufen><de> Login Mobiles Spionagepaket, Überwachung von GPS-Standorten, Anrufe, SMS, Videos, Fotos und Social Media und vieles mehr.
<G-vec00057-002-s137><call_up.anrufen><en> Call blending – using an auto dialing strategy such as predictive dialing combined with inbound call handling - drives significant efficiencies through the ability to allocate agents across contact channels through true and through automated multichannel blending defined by business rules.
<G-vec00057-002-s137><call_up.anrufen><de> Call Blending – mit einer Autodialer-Strategie wie Predictive Dialing, kombiniert mit der Behandlung eingehender Anrufe – eröffnet die Möglichkeit, die Mitarbeiter über die Kontaktkanäle hinweg über echtes oder automatisiertes Mehrkanal-Blending gemäß der Definition in den Geschäftsregeln zuzuweisen, und sorgt so für erhebliche Effizienz.
<G-vec00057-002-s138><call_up.anrufen><en> * Any kind of alcoholic drinks, hot shower, cold drinks, snacks, laundry, phone call, internet.
<G-vec00057-002-s138><call_up.anrufen><de> * Jede Art von alkoholischen Getränken, kalten Getränken, Wäscherei, Anrufe, Internet.
<G-vec00057-002-s139><call_up.anrufen><en> The module makes a GSM call or send an SMS (text) to each configured user number.
<G-vec00057-002-s139><call_up.anrufen><de> Das Modul macht GSM Anrufe und schickt SMS Nachrichten an jede eingestellte Benutzer-Telefonnummer.
<G-vec00057-002-s140><call_up.anrufen><en> Moreover, the call and demands of the Spirit resound in the very events of history, and so the Church can also be guided to a more profound understanding of the inexhaustible mystery of marriage and the family by the circumstances, the questions and the anxieties and hopes of the young people, married couples and parents of today.[9]
<G-vec00057-002-s140><call_up.anrufen><de> Und nicht nur das: Die Forderungen und Anrufe des göttlichen Geistes sprechen auch aus den Ereignissen der Geschichte, weshalb die Kirche auch durch die Situationen, Fragen, Ängste und Hoffnungen der Jugendlichen, der Eheleute und der Eltern von heute zu einer tieferen Kenntnis des unerschöpflichen Mysteriums der Ehe und Familie geführt werden kann (Vgl.
<G-vec00057-002-s141><call_up.anrufen><en> Operators accept the call in your name, take down caller information, then pass it to your dealership the next working day for processing.
<G-vec00057-002-s141><call_up.anrufen><de> Die Anrufe werden in Ihrem Namen angenommen, die Daten des Anrufers notiert und am nächsten Arbeitstag zur Bearbeitung in Ihr Autohaus weitergeleitet.
<G-vec00057-002-s142><call_up.anrufen><en> Select Menu > Settings > Call and from the following options: ● Call divert — to divert your incoming calls (network service).
<G-vec00057-002-s142><call_up.anrufen><de> Anrufen Wählen Sie Menü > Einstellungen > Anrufe und eine der folgenden Optionen: ● Rufumleitung — Zum Umleiten von Anrufen (Netzdienst).
<G-vec00057-002-s143><call_up.anrufen><en> There are many variants of settings: you can answer the incoming call shaking your smartphone or taking it to your ear, you can finish the conversation turning your device and others. Game features:
<G-vec00057-002-s143><call_up.anrufen><de> Es gibt viele Anpassungsmöglichkeiten, du kannst zum Beispiel Anrufe annehmen, indem du dein Smartphone schüttelst oder es zum Ohr bewegst, Auflegen kannst du, indem du dein Telefon mit dem Bildschirm auf den Tisch legst.
<G-vec00057-002-s144><call_up.anrufen><en> Settings for incoming phone call, email, and other notifications and for smartphone remaining battery notifications can be configured.
<G-vec00057-002-s144><call_up.anrufen><de> Einstellungen für eingehende Anrufe, E-Mails und andere Benachrichtigungen sowie für Hinweise über den Smartphone-Akkustand können konfiguriert werden.
<G-vec00057-002-s145><call_up.anrufen><en> Unwanted call blocking is a feature that helps block your Skype Number from receiving unwanted spam calls.
<G-vec00057-002-s145><call_up.anrufen><de> Das Blockieren unerwünschter Anrufe ist eine Funktion, mit dem Sie verhindern, dass Ihre Skype-Rufnummer unerwünschte Spam-Anrufe empfängt.
<G-vec00057-002-s146><call_up.anrufen><en> *Using Bixby may be limited under certain situations including without limitation during media (Video/Game/Voice) recording, during call (including outgoing call), Maximum power saving mode, Emergency mode, Kids Mode, and MirrorLink™.
<G-vec00057-002-s146><call_up.anrufen><de> ** Bixby kann unter bestimmten Bedingungen nur eingeschränkt nutzbar sein, zum Beispiel bei Medienaufnahmen (Video/Spiele/Sprache), Telefonaten (inklusive Anrufe), im maximalen Stromsparmodus, Notfallmodus, Kids Mode und bei MirrorLink™.
<G-vec00057-002-s147><call_up.anrufen><en> You also agree to not offer or use the Services as a service bureau by which the Services can be accessed by third parties or by which information produced pursuant to the Service is sold or given to third parties via pay per call or any other such arrangements whatsoever.
<G-vec00057-002-s147><call_up.anrufen><de> Ferner verpflichten Benutzer sich, die Dienstleistungen nicht als ein Serviceunternehmen anzubieten oder zu benutzen, über welches Dritte auf die Dienstleistungen zugreifen können oder die durch die Dienstleistungen erzeugten Informationen durch gebührenpflichtige Anrufe oder vergleichbare Service an Dritte verkauft oder weiter geleitet werden.
<G-vec00057-002-s148><call_up.anrufen><en> Cordless phone with answer machine With a digital answering machine, you'll never miss a call or message.
<G-vec00057-002-s148><call_up.anrufen><de> Schnurlostelefon mit Anrufbeantworter Der digitale Anrufbeantworter speichert zuverlässig alle Anrufe und Nachrichten.
<G-vec00057-002-s149><call_up.anrufen><en> “Placing a call is one of the most intuitive actions a consumer can take on their mobile phone, and calls are proving to be a very effective way to monetize mobile advertising, especially in service-based verticals.”
<G-vec00057-002-s149><call_up.anrufen><de> Anrufe haben sich außerdem als einer der effektivsten Wege erwiesen, mobile Werbung zu monetarisieren – insbesondere im Dienstleistersektor.“ Es hat sich gezeigt, dass besonders Unternehmen in der Service-Branche erfolgreich mit mobilem Click-to-Call arbeiten.
<G-vec00057-002-s150><call_up.anrufen><en> Tap the channel or direct message name to open the channel or conversation info, and choose Start a call.
<G-vec00057-002-s150><call_up.anrufen><de> Anrufe starten Tippe auf den Namen des Channels oder der Direktnachricht, um die Informationen für den Channel oder die Unterhaltung zu öffnen.
<G-vec00057-002-s151><call_up.anrufen><en> The call is coming to you company no matter if the caller originates in your geographical location or abroad.
<G-vec00057-002-s151><call_up.anrufen><de> Die Anrufe werden direkt zu Ihnen geleitet, egal ob der Anrufer im Inland oder im Ausland (mit Ländervorwahl) sitzt.
<G-vec00057-002-s152><call_up.anrufen><en> She told us to fear nothing and to continue to call upon lucifer, then she assured us that there is no power in the universe that can harm us.
<G-vec00057-002-s152><call_up.anrufen><de> Sie sagte uns, wir sollten nichts fürchten und weiterhin luzifer anrufen, dann versicherte sie uns, dass es keine Kraft im Universum gibt, die uns schaden könnte.
<G-vec00057-002-s153><call_up.anrufen><en> Alternatively you can send email, call or send SMS message.
<G-vec00057-002-s153><call_up.anrufen><de> Alternativ können Sie auch Anrufen oder eine Email oder SMS senden.
<G-vec00057-002-s154><call_up.anrufen><en> If you require an interpreter, you can call the Translating and Interpreting Service (TIS) on 131 450.
<G-vec00057-002-s154><call_up.anrufen><de> Wenn Sie einen Dolmetscher benötigen, können Sie den Übersetzer- und Dolmetscherdienst (TIS) unter 131 450 anrufen..
<G-vec00057-002-s155><call_up.anrufen><en> In Ireland you can call 1800 753 753.
<G-vec00057-002-s155><call_up.anrufen><de> In Irland können Sie 1800 753 753 anrufen.
<G-vec00057-002-s156><call_up.anrufen><en> You can send, once you return to your studies, a thank you note, or even make a call to wish them a “Merry Christmas”, for example.
<G-vec00057-002-s156><call_up.anrufen><de> Nachdem du zu deinem Studium zurückgekehrt bist, kannst du einen Dankesbrief schreiben oder sogar anrufen, um „Fröhliche Weihnachten“ zu wünschen.
<G-vec00057-002-s157><call_up.anrufen><en> Alternatively, you can send an email directly to book@sitgeshillsvillas.com or call + 34 659 516 745. Rental Prices
<G-vec00057-002-s157><call_up.anrufen><de> Alternativ können Sie direkt eine E-Mail an die Adresse book@sitgeshillsvillas.com senden oder uns unter +44 203 287 6597 anrufen.
<G-vec00057-002-s158><call_up.anrufen><en> If you would like to pay by credit card, then please let us know when you call to book your date.
<G-vec00057-002-s158><call_up.anrufen><de> Sie können für Ihre Escort Dame mit Kreditkarte über das Handy bezahlen – lassen Sie es uns einfach wissen, wenn Sie anrufen.
<G-vec00057-002-s159><call_up.anrufen><en> When you call us we will give you a reference ID number to allow you to log-in and finalize your booking by completing a booking form.
<G-vec00057-002-s159><call_up.anrufen><de> Wann Sie uns anrufen geben wir Ihnen eine Referenznummer damit Sie einloggen und Ihre Buchung fertig machen können (Buchungsformular ausfüllen).
<G-vec00057-002-s160><call_up.anrufen><en> Nevertheless, God wants us to ask, to turn to him in times of need, to cry out, implore, lament, call upon him, indeed, even to struggle with him in prayer.
<G-vec00057-002-s160><call_up.anrufen><de> Dennoch will Gott, dass wir „bitten“: dass wir uns in der Not unseres Lebens an ihn wenden, zu ihm schreien, flehen, klagen, ihn anrufen, ja sogar im Gebet mit ihm ringen.
<G-vec00057-002-s161><call_up.anrufen><en> To book within three days of your arrival, contact our Dining Reservation Service on +33 1 60 30 40 50 (international call rates apply, cost may vary according to network).
<G-vec00057-002-s161><call_up.anrufen><de> Dazu gibt es verschiedene Möglichkeiten: Bis zu zwei Monate vor Ihrer Ankunft können Sie unsere Reservierungszentrale anrufen: +33 1 60 30 40 50 (Internationale Telefongebühren fallen an.
<G-vec00057-002-s162><call_up.anrufen><en> Annie was our counsellor and she, she let me call her at any time of the day or night.
<G-vec00057-002-s162><call_up.anrufen><de> Annie war unsere Beraterin und sie sagte, ich könne sie zu jeder Tages- oder Nachtzeit anrufen.
<G-vec00057-002-s163><call_up.anrufen><en> Actions often relates to customer interaction, eg which product, recommendation or advertisement to be offered to a customer, which customers you should call and make an offer to before they leave you for a competitor, or how to design an offer to have maximum impact.
<G-vec00057-002-s163><call_up.anrufen><de> Aktionen beziehen sich oft auf die Kundeninteraktion, zum Beispiel, welches Produkt, welche Empfehlung oder Werbung einem Kunden angeboten werden soll, welche Kunden Sie anrufen und wem Sie ein Angebot machen sollten, um sie oder ihn nicht an einen Konkurrenten zu verlieren, oder wie Sie ein Angebot erstellen, das eine maximale Wirkung erzielt.
<G-vec00057-002-s164><call_up.anrufen><en> Well, you could call your broker and ask.
<G-vec00057-002-s164><call_up.anrufen><de> Sie könnten natürlich Ihren Broker anrufen und nachfragen.
<G-vec00057-002-s165><call_up.anrufen><en> If you want to call to Russia from your landline or mobile, mytello is the service for you.
<G-vec00057-002-s165><call_up.anrufen><de> Wenn Sie vom eigenen Handy oder Festnetz nach Russland anrufen wollen, sind Sie bei uns genau richtig.
<G-vec00057-002-s166><call_up.anrufen><en> (Acts 4:12) Nevertheless, there is a difference, for when the time of the Gentiles and God's grace for the nations soon comes to an end, God is not yet finished with Israel -- their time is coming whereby, God will turn back to His people and they will call on Him, whom they pierced, and He will answer them.
<G-vec00057-002-s166><call_up.anrufen><de> Dennoch gibt es einen Unterschied, denn während die Gnade Gottes zu den Nationen der Heiden bald zu Ende ist, ist Er doch mit Israel noch nicht fertig - die Zeit kommt, in der sich Gott wieder zu Seinem Volk kehrt und sie werden IHN anrufen, den sie durchbohrt haben.
<G-vec00057-002-s167><call_up.anrufen><en> At first I wanted to just give you a call, but then Dad decided to go on an overnight fishing trip and Mum had her own things to do.
<G-vec00057-002-s167><call_up.anrufen><de> Zuerst wollte ich dich nur anrufen, aber mein Vater beschloss, Nachtfischen zu gehen, und meine Mutter hatte ihre eigenen Pläne.
<G-vec00057-002-s168><call_up.anrufen><en> Additional interesting extras, for example, are call blocking, filtering of messages, a safe browsing function, parental controls, backup or encryption.
<G-vec00057-002-s168><call_up.anrufen><de> Weitere interessante Extras sind etwa das Blocken von Anrufen, das Filtern von Nachrichten, eine Safe-Browsing-Funktion, Kinderschutzfunktionen, Backup oder Verschlüsselung.
<G-vec00057-002-s169><call_up.anrufen><en> We’re reviewing all the information you provided and if you haven’t already heard from us, one of our tax advisors will call you shortly.
<G-vec00057-002-s169><call_up.anrufen><de> Ein Mitglied unseres australischen Steuerteams wird Sie in Kürze anrufen, um Ihren Antrag zu besprechen.
<G-vec00057-002-s170><call_up.anrufen><en> This means that when you call us, you will get someone with first-hand knowledge of the products, who understands your needs.
<G-vec00057-002-s170><call_up.anrufen><de> Wenn Sie uns anrufen, können Sie sich darauf verlassen, dass Ihr Kundenservice-Berater Ihre Bedürfnisse versteht und Ihnen Tipps aus erster Hand geben kann.
<G-vec00057-002-s190><call_up.anrufen><en> Note: Maybe somebody at Amazon made an analysis similar to this long before we did, and that’s why it is so hard to find a phone number to call Amazon (we invite the reader to look for it).
<G-vec00057-002-s190><call_up.anrufen><de> Hinweis: Vielleicht hat jemand bei Amazon lange vor uns eine ähnliche Analyse durchführen lassen, und es ist deshalb so kompliziert eine Telefonnummer zu finden, um bei Amazon anzurufen (wir laden den Leser ein eine zu suchen).
<G-vec00057-002-s191><call_up.anrufen><en> Upon our arrival the owner came to the house with the key, gave a clear explanation, told us to call him if there was anything.
<G-vec00057-002-s191><call_up.anrufen><de> Bei unserer Ankunft kam der Besitzer mit dem Schlüssel zum Haus, gab eine klare Erklärung und forderte uns auf, ihn anzurufen, falls etwas da wäre.
<G-vec00057-002-s192><call_up.anrufen><en> It is useless to call, no one will answer
<G-vec00057-002-s192><call_up.anrufen><de> Es ist zwecklos, anzurufen, Keiner wird antworten.
<G-vec00057-002-s193><call_up.anrufen><en> The authorities ask citizens to call 112 only if they came from areas where the virus is present.
<G-vec00057-002-s193><call_up.anrufen><de> Die Behörden fordern die Bürger auf, die 112 nur dann anzurufen, wenn sie aus Gebieten stammen, in denen das Virus vorhanden ist.
<G-vec00057-002-s194><call_up.anrufen><en> Each flight is different and requires special attention. If you have specific questions for your upcoming flights, do not hesitate to call us at +41 844 041 844.
<G-vec00057-002-s194><call_up.anrufen><de> Sollten Sie Fragen haben, zögern Sie bitte nicht, uns anzurufen: +41 844 041 844, oder senden Sie uns eine E-Mail: lunajets@lunajets.com.
<G-vec00057-002-s195><call_up.anrufen><en> Since not all art objects presented in our webshop are also in the Gallery in Maastricht, it is advisable if you want to see the art objects in real life, to call or email us in advance to avoid disappointment.
<G-vec00057-002-s195><call_up.anrufen><de> Da sich nicht alle in unserem Webshop präsentierten Kunstobjekte auch in der Galerie in Maastricht befinden, ist es ratsam, wenn Sie die Kunstobjekte im wirklichen Leben sehen möchten, uns im Voraus anzurufen oder eine E-Mail zu senden, um Enttäuschungen zu vermeiden.
<G-vec00057-002-s196><call_up.anrufen><en> I was soon struggling to maintain consciousness so I tried to call 911 with the phone at my bedside table.
<G-vec00057-002-s196><call_up.anrufen><de> Bald kämpfte ich darum das Bewusstsein zu behalten, also versuchte ich 911 anzurufen, mit dem Telefon auf dem Tisch neben meinem Bett.
<G-vec00057-002-s197><call_up.anrufen><en> All you have to do is call the staff cell phone number at any time, day or night.
<G-vec00057-002-s197><call_up.anrufen><de> Alles was du tun musst, ist die Personal-Handy-Nummer jederzeit anzurufen, Tag oder Nacht.
<G-vec00057-002-s198><call_up.anrufen><en> I literally ran to the phone to call him.
<G-vec00057-002-s198><call_up.anrufen><de> Ich rannte buchstäblich zum Telefon, um ihn anzurufen.
<G-vec00057-002-s199><call_up.anrufen><en> PRO TIP: If you prefer to call the organiser, check their event listing for a contact phone number to skip the email process.
<G-vec00057-002-s199><call_up.anrufen><de> EXPERTENTIPP: Wenn Sie es vorziehen, den Veranstalter anzurufen, überprüfen Sie die Veranstaltungsliste für eine Kontakttelefonnummer, um den E-Mail-Prozess zu überspringen.
<G-vec00057-002-s200><call_up.anrufen><en> You can also call a borrower or send them a text message directly from the reports on received and issued loans.
<G-vec00057-002-s200><call_up.anrufen><de> Im Bericht zu den aufgenommenen und vergebenen Darlehen haben Sie die Möglichkeit, einen Darlehensnehmer direkt anzurufen oder ihm eine SMS zu senden.
<G-vec00057-002-s201><call_up.anrufen><en> She manages to call her husband, who called our hotline number and we then alerted the Immigration Office and the Turkish police.
<G-vec00057-002-s201><call_up.anrufen><de> Es gelingt ihr, ihren Mann anzurufen und der wendet sich an das „Rote Telefon“ und wir melden den Fall der türkischen Polizei und dem dortigen Einwanderungsbüro.
<G-vec00057-002-s202><call_up.anrufen><en> Magui slowed down for a moment to let him step out into the street so that she could reach the telephone in the hall in order to call Hector.
<G-vec00057-002-s202><call_up.anrufen><de> Magui verhielt einen Augenblick, damit er auf die Straße träte, um so in die Diele ans Telefon gehen zu können und Hektor anzurufen.
<G-vec00057-002-s203><call_up.anrufen><en> If you have a subscription, but your call won’t connect, it’s likely that you are trying to call a number or destination not covered by your subscription.
<G-vec00057-002-s203><call_up.anrufen><de> Wenn Sie ein Abonnement haben, aber Ihr Anruf nicht verbunden wird, versuchen Sie möglicherweise, eine Nummer oder ein Ziel anzurufen, das von Ihrem Abonnement nicht abgedeckt wird.
<G-vec00057-002-s204><call_up.anrufen><en> Should you have got any interest in our products and solutions, remember to never wait to call us.
<G-vec00057-002-s204><call_up.anrufen><de> Wenn Sie Interesse an unseren Produkten und Lösungen haben, denken Sie daran, uns nie anzurufen.
<G-vec00057-002-s205><call_up.anrufen><en> We can use either Facetime or WhatsApp to video call you directly at the property.
<G-vec00057-002-s205><call_up.anrufen><de> Wir können entweder Facetime oder WhatsApp verwenden, um Sie direkt in der Unterkunft per Video anzurufen.
<G-vec00057-002-s206><call_up.anrufen><en> Since the text message does not guarantee a seat, Orange recommends its customers to call the cinema and reserve seats (no online reservation).
<G-vec00057-002-s206><call_up.anrufen><de> Da die SMS keine Platzgarantie darstellt, empfiehlt Orange seinen Kunden, zur Reservierung der gewünschten Sitzplätze im Kino anzurufen (keine Online-Reservierung).
<G-vec00057-002-s207><call_up.anrufen><en> So, after thinking for three minutes and starting to get frostbite, I pulled out my cell phone to call the firemen (in France the fireman take care of any rescue situation.
<G-vec00057-002-s207><call_up.anrufen><de> Nachdem ich drei Minuten lang nachgedacht und schon erste Frostbeulen bekam, zog ich mein Handy heraus, um die Feuerwehr anzurufen (in Frankreich kümmert sich der Feuerwehrmann um jede Rettungssituation.
<G-vec00057-002-s208><call_up.anrufen><en> McLean admitted they were true, and the victim’s family decided to call Riverside County Sheriff’s Department.
<G-vec00057-002-s208><call_up.anrufen><de> McLean gab zu, dass sie stimmten, und die Familie beschloss, die Polizeistation von Riverside County anzurufen.
<G-vec00057-002-s570><call_up.anrufen><en> Guests arriving by public transport call the hotel from the PostBus terminal or the tourist office.
<G-vec00057-002-s570><call_up.anrufen><de> Gäste, die mit öffentlichen Verkehrsmitteln anreisen, rufen das Hotel vom PostAuto-Terminal oder vom Tourismusbüro aus an.
<G-vec00057-002-s571><call_up.anrufen><en> Alternatively, call +44870 400 9121 (not toll-free) or your country-specific number.
<G-vec00057-002-s571><call_up.anrufen><de> Rufen Sie andernfalls +44870 400 9121 (gebührenpflichtig) oder Ihre länderspezifische Nummer an.
<G-vec00057-002-s572><call_up.anrufen><en> For EVE Audio demos in USA please contact our distributor EVE Audio US or call +1 845 378 1189.
<G-vec00057-002-s572><call_up.anrufen><de> Für eine Demo von EVE-Monitoren in den USA kontaktieren Sie bitte unseren Vertrieb EVE Audio US oder rufen an +1 845 378 1189.
<G-vec00057-002-s573><call_up.anrufen><en> Every day, people call psychotherapists offices for help in a crisis.
<G-vec00057-002-s573><call_up.anrufen><de> Jeden Tag rufen in den Psychotherapeutischen Praxen Menschen an, die Hilfe in einer Krise suchen.
<G-vec00057-002-s574><call_up.anrufen><en> Melding: questions, comments or concerns, please call us.
<G-vec00057-002-s574><call_up.anrufen><de> Wenn Sie Fragen, Anmerkungen oder Bedenken haben, rufen Sie uns bitte an.
<G-vec00057-002-s576><call_up.anrufen><en> AGROSPOL, Malý you have any questions, comments or concerns, please call us.
<G-vec00057-002-s576><call_up.anrufen><de> Schließen Wenn Sie Fragen, Anmerkungen oder Bedenken haben, rufen Sie uns bitte an.
<G-vec00057-002-s577><call_up.anrufen><en> View them on the page or call one of our employees for further information. Suzanna Dee
<G-vec00057-002-s577><call_up.anrufen><de> Sehen Sie sich diese auf der Seite an oder rufen Sie einen unserer Mitarbeiter für weitere Informationen an.
<G-vec00057-002-s578><call_up.anrufen><en> If you are a dog groomer and would like more information about KW and are interested in testing our competitively priced quality products, please do not hesitate to call or write to us.
<G-vec00057-002-s578><call_up.anrufen><de> Sind Sie Hundefriseur und daran interessiert, mehr über KW zu erfahren, und unsere hohe Qualität bei den Produkten zu wettbewerbsfähigen Preisen auszuprobieren – dann schreiben Sie uns oder rufen Sie uns an.
<G-vec00057-002-s579><call_up.anrufen><en> Also, if you need to find the address of the person or on the phone to find someone by the name, then just immediately call the detective agency " Private detective Kharkiv", which carries out its activities in the city Pervomajskij .
<G-vec00057-002-s579><call_up.anrufen><de> Auch, wenn Sie benötigen die Adresse der Person am Telefon zu wissen oder den Nachnamen, jemanden zu finden, rufen Sie einfach direkt an die Detektei "Kharkov Private Detective", die Pervomajskij im Gebiet der Stadt tätig ist.
<G-vec00057-002-s581><call_up.anrufen><en> Procédure au retour Please call the staff of Park & Fly as soon as you have collected your luggage.
<G-vec00057-002-s581><call_up.anrufen><de> Nach Ihrer Gepäckannahme, rufen Sie bitte die PMS Park & Fly Service Hotline an, um Ihre Ankunft zu bestätigen.
<G-vec00057-002-s582><call_up.anrufen><en> If you need help, call 972-385-0100. Ribbon Text Our Company
<G-vec00057-002-s582><call_up.anrufen><de> Wenn Sie Hilfe benötigen, rufen uns bitte an unter +31 (0)20 305 8620.
<G-vec00057-002-s583><call_up.anrufen><en> Simply give our Managed Security team a call now and they will have your data safe in no time.
<G-vec00057-002-s583><call_up.anrufen><de> Rufen Sie unser Managed Security-Team einfach an, damit es Ihre Daten im Handumdrehen schützt.
<G-vec00057-002-s584><call_up.anrufen><en> Please give us a call or send an email.
<G-vec00057-002-s584><call_up.anrufen><de> Bitte rufen Sie uns an oder schreiben Sie uns eine E-Mail.
<G-vec00057-002-s585><call_up.anrufen><en> To book, we kindly ask you to call on +41 (0)91 996 21 55 between 8am and 10pm from Monday to Sunday.
<G-vec00057-002-s585><call_up.anrufen><de> Um eine Reservierung vorzunehmen, rufen Sie bitte zwischen 08:00 und 22:00 Uhr, Montag bis Sonntag, unter +41 (91) 996 21 55 an.
<G-vec00057-002-s586><call_up.anrufen><en> Quick question? Call KBC Live
<G-vec00057-002-s586><call_up.anrufen><de> Rufen Sie KBC Live an, Tel.
<G-vec00057-002-s587><call_up.anrufen><en> In other call centres the 'human' work plays a crucial role: people call because they want to talk (besides ordering stuff).
<G-vec00057-002-s587><call_up.anrufen><de> Bei anderen Call Centern spielt die "menschliche" Arbeit eine zentrale Rolle: Die Leute rufen an, weil sie reden wollen (und nebenbei die Bestellung aufgeben).
<G-vec00057-002-s588><call_up.anrufen><en> They call us frequently, knowing they can rely on a fast, knowledgeable response to their requests for information.
<G-vec00057-002-s588><call_up.anrufen><de> Sie rufen uns häufig an und wissen, dass sie sich auf eine schnelle und kompetente Antwort auf ihre Fragen verlassen können.
<G-vec00057-002-s247><call_up.aufrufen><en> Whenever you call up a page from our website that contains one of these plugins, your browser establishes a connection directly with Facebook servers.
<G-vec00057-002-s247><call_up.aufrufen><de> Wenn Sie eine Webseite unseres Internetauftritts aufrufen, die ein solches Plugin enthält, baut Ihr Browser eine direkte Verbindung mit den Servern von Facebook auf.
<G-vec00057-002-s248><call_up.aufrufen><en> A player with access to such a database can call up detailed information about every one of his opponents without ever playing against those opponents himself.
<G-vec00057-002-s248><call_up.aufrufen><de> Ein Spieler, der Zugang zu einer solchen Datenbank hat, kann detaillierte Informationen über jeden einzelnen Gegner aufrufen, ohne dass er jemals selbst gegen diesen Gegner gespielt hat.
<G-vec00057-002-s249><call_up.aufrufen><en> As long as this atrocity has not ended, practitioners will continue to call for and end to the persecution.
<G-vec00057-002-s249><call_up.aufrufen><de> Solange diese Grausamkeiten nicht enden, werden Praktizierende weiterhin zu einer Beendigung der Verfolgung aufrufen.
<G-vec00057-002-s250><call_up.aufrufen><en> APIs from module A, that you tried to call from module B will be better placed in their own module C a lot of times because module A and B don’t have anything to do with one another.
<G-vec00057-002-s250><call_up.aufrufen><de> Oft gehört die API aus Modul A, die man von Modul B aufrufen wollte, doch eher in ein neues Modul C, weil Module B und A eigentlich nichts mit einander zu tun haben.
<G-vec00057-002-s251><call_up.aufrufen><en> Users can call out these data at any time without any special program setting.
<G-vec00057-002-s251><call_up.aufrufen><de> Sie können diese Daten jederzeit ohne spezielle Programmeinstellungen aufrufen.
<G-vec00057-002-s252><call_up.aufrufen><en> The proposer of a motion may call for a vote on any or all of the amendments individually or together; the proposer of an amendment may call for a vote only on that amendment and related amendments.
<G-vec00057-002-s252><call_up.aufrufen><de> Der Antragsteller und jeder Befürworter eines Beschlusses können zu einer Abstimmung über diesen Beschluss und alle damit zusammenhängenden Abänderungen aufrufen.
<G-vec00057-002-s253><call_up.aufrufen><en> Ultimately, to use this class, you simply need to instantiate it, know the path to a file full of questions, and then call the get_question_from_file method.
<G-vec00057-002-s253><call_up.aufrufen><de> Um diese Klasse zu verwenden, müssen Sie sie nur instanziieren, den Pfad zu einer Datei voller Fragen kennen und dann die Methode get_question_from_file aufrufen.
<G-vec00057-002-s254><call_up.aufrufen><en> Through F1 one can call the main menu with save and load function.
<G-vec00057-002-s254><call_up.aufrufen><de> Über F1 kann man das Hauptmenü mit Speicher- oder Ladefunktion aufrufen.
<G-vec00057-002-s255><call_up.aufrufen><en> If you call up a page on our website that contains such a plugin, your browser makes a direct connection to the AddThis server.
<G-vec00057-002-s255><call_up.aufrufen><de> Wenn Sie eine Seite unseres Webauftritts aufrufen, die ein solches Plugin enthält, stellt Ihr Browser eine direkte Verbindung zu den Servern von AddThis her.
<G-vec00057-002-s256><call_up.aufrufen><en> The target of a conversation does not need to call BEGIN DIALOG CONVERSATION.
<G-vec00057-002-s256><call_up.aufrufen><de> Das Ziel einer Konversation muss nicht BEGIN DIALOG CONVERSATION aufrufen.
<G-vec00057-002-s257><call_up.aufrufen><en> Emergency responders can call up pictures, floor plans and GPS coordinates to get a clear understanding of any situation before they even arrive on the scene.
<G-vec00057-002-s257><call_up.aufrufen><de> Notfallhelfer können Bilder, Grundrisse und GPS-Koordinaten aufrufen, um jede Situation umfassend einzuschätzen, noch bevor Sie am Schauplatz des Geschehens ankommen.
<G-vec00057-002-s258><call_up.aufrufen><en> • As an employee, you can easily call the Count jobs in the app.
<G-vec00057-002-s258><call_up.aufrufen><de> • Als Mitarbeiter können Sie ganz einfach die Zähl-Aufträge in der App aufrufen.
<G-vec00057-002-s259><call_up.aufrufen><en> When you call up a page on our website that contains such a plug-in, your browser creates a direct connection to the servers of Facebook.
<G-vec00057-002-s259><call_up.aufrufen><de> Wenn Sie eine Seite unseres Webauftritts aufrufen, die ein solches Plugin enthält, stellt Ihr Browser eine direkte Verbindung zu den Servern von Facebook her.
<G-vec00057-002-s260><call_up.aufrufen><en> In the next tutorial, you will learn where you need to place your service code, your server-side class files, so the Flex application can call them.
<G-vec00057-002-s260><call_up.aufrufen><de> In der nächsten Übung erfahren Sie, wo Sie Ihren Dienstcode, d. h. Ihre Server-seitigen Klassendateien, ablegen müssen, damit Ihre Flex-Applikation sie aufrufen kann.
<G-vec00057-002-s261><call_up.aufrufen><en> This is possible because is stored in the cookie, what products you have recently looked at and appropriate alternatives or additions to be picked as soon as you call up the page.
<G-vec00057-002-s261><call_up.aufrufen><de> Das ist möglich, weil im Cookie gespeichert ist, welche Produkte Sie sich zuletzt angeschaut haben und entsprechende Alternativen oder Ergänzungen herausgesucht werden, sobald Sie die Seite aufrufen.
<G-vec00057-002-s262><call_up.aufrufen><en> Figure 2 shows what happens when you call the base CLI command Azure.
<G-vec00057-002-s262><call_up.aufrufen><de> Abbildung 2 zeigt, was passiert, wenn Sie den Basis-CLI-Befehl Azure aufrufen.
<G-vec00057-002-s263><call_up.aufrufen><en> The posters are intentionally provocative, intended to capture the attention – and to call upon Telekom employees to immediately support violations against the Deutsche Telekom Code of Human Rights.
<G-vec00057-002-s263><call_up.aufrufen><de> Die Plakate sind bewusst provokant gestaltet und sollen Aufmerksamkeit erregen – und die Mitarbeiterinnen und Mitarbeiter der Telekom aufrufen, Verstöße gegen den Menschrechtskodex der Deutschen Telekom umgehend zu melden.
<G-vec00057-002-s264><call_up.aufrufen><en> You can interchange data, call methods remotely and process user dialogs in the remote system.
<G-vec00057-002-s264><call_up.aufrufen><de> Sie können Daten austauschen, Methoden aufrufen und Benutzerdialoge des aufgerufenen Systems direkt vom Benutzer innerhalb des Remote-Aufrufs bearbeiten lassen.
<G-vec00057-002-s265><call_up.aufrufen><en> A measurement of the data and subsequent assignment to the respective client identifier is therefore also possible if you call up other websites that also use the INFOnline GmbH measurement method („SZMnG“).
<G-vec00057-002-s265><call_up.aufrufen><de> Eine Messung der Daten und anschließende Zuordnung zu dem jeweiligen Client- Identifier ist daher auch dann möglich, wenn Sie andere Webseiten aufrufen, die ebenfalls das Messverfahren („SZMnG“) der INFOnline GmbH nutzen.
<G-vec00057-002-s266><call_up.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00057-002-s266><call_up.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00057-002-s267><call_up.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00057-002-s267><call_up.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00057-002-s268><call_up.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00057-002-s268><call_up.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00057-002-s269><call_up.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00057-002-s269><call_up.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00057-002-s270><call_up.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00057-002-s270><call_up.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00057-002-s271><call_up.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00057-002-s271><call_up.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00057-002-s272><call_up.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00057-002-s272><call_up.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00057-002-s273><call_up.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00057-002-s273><call_up.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00057-002-s274><call_up.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00057-002-s274><call_up.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00057-002-s275><call_up.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00057-002-s275><call_up.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00057-002-s276><call_up.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00057-002-s276><call_up.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00057-002-s277><call_up.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00057-002-s277><call_up.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00057-002-s278><call_up.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00057-002-s278><call_up.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00057-002-s279><call_up.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00057-002-s279><call_up.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00057-002-s280><call_up.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00057-002-s280><call_up.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00057-002-s281><call_up.aufrufen><en> Tried to call a removed routine.
<G-vec00057-002-s281><call_up.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00057-002-s282><call_up.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00057-002-s282><call_up.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00057-002-s283><call_up.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00057-002-s283><call_up.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00057-002-s284><call_up.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00057-002-s284><call_up.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00057-002-s513><call_up.rufen><en> It is the individual's own decision whether or not to believe and heed the divine call and faithfully fulfil the tasks assigned to him.
<G-vec00057-002-s513><call_up.rufen><de> Ob er dem göttlichen Ruf glaubt, folgt und treu die ihm zugewiesenen Aufgaben erfüllt, liegt in seiner Entscheidung.
<G-vec00057-002-s514><call_up.rufen><en> Call her – she looks forward to your coming.
<G-vec00057-002-s514><call_up.rufen><de> Ruf sie an – sie freut sich auf dein Kommen.
<G-vec00057-002-s515><call_up.rufen><en> Now is the time for the Renewal to forcefully respond to the call of prayer and give strong witness of its rich experience of prayer in the power of the Holy Spirit.
<G-vec00057-002-s515><call_up.rufen><de> Jetzt ist es an der Zeit, dass die Erneuerung entschieden auf den Ruf ins Gebet antwortet und von ihrer reichen Erfahrung mit dem Gebet aus der Kraft des Heiligen Geistes Zeugnis gibt.
<G-vec00057-002-s516><call_up.rufen><en> During personal interaction as well as when talking to large audiences she radiated the certainty that the mission of the Volunteers is the call of God to serve, to be transparencies of the love of God for us.
<G-vec00057-002-s516><call_up.rufen><de> Im persönlichen Kontakt wie auch beim Reden vor großem Publikum strahlte sie ihre Gewissheit aus, dass die Sendung des „Freiwilligen“ ein Ruf Gottes zum Dienen ist, ein Transparent Seiner Liebe für die Menschen zu sein.
<G-vec00057-002-s517><call_up.rufen><en> Everywhere I must seek my little sheep, which were lost; my call must get through everywhere, and for that reason my voice must sound again and again – again and again I must come in the word to men and call them home into the father house.
<G-vec00057-002-s517><call_up.rufen><de> Überall muss Ich Meine Schäflein suchen, die verloren waren, Mein Ruf muss überallhin dringen, und daher muss Meine Stimme immer wieder ertönen - immer wieder muss Ich im Wort kommen zu den Menschen und sie rufen heim ins Vaterhaus.
<G-vec00057-002-s518><call_up.rufen><en> And more than 500 uniformed comrades from Austria and the crown lands followed the call.
<G-vec00057-002-s518><call_up.rufen><de> Und mehr als 500 Uniformierte aus Österreich und den Kronländern folgten dem Ruf.
<G-vec00057-002-s519><call_up.rufen><en> United states and Britain have never been on the eyes of man, at best, is a ‘Call to come’ that is able to play only a doll’.
<G-vec00057-002-s519><call_up.rufen><de> Die Vereinigten Staaten und Britannien standen niemals vor Augen der Männer, bestenfalls ist es ein ‚Ruf nach Hause‘, den nur eine Puppe spielen kann.
<G-vec00057-002-s520><call_up.rufen><en> We therefore emphatically welcome the document produced by the joint working group of the World Council of Churches and the Roman Catholic Church on the topic "The Challenge of Proselytism and the Call to Common Witness", the insights of which can be helpful for future discussions.
<G-vec00057-002-s520><call_up.rufen><de> Wir begrüssen deshalb mit Nachdruck das Dokument der gemeinsamen Arbeitsgruppe zwischen dem Ökumenischen Rat der Kirchen und der Römisch-Katholischen Kirche zum Thema "Die Herausforderung des Proselytismus und der Ruf zum gemeinsamen Zeugnis", dessen Einsichten für das künftige Gespräch hilfreich sein könnten.
<G-vec00057-002-s521><call_up.rufen><en> It is time for those who incorporate the Feminine Principle, the women of this earth, to respond to the higher call that will awaken unprecedented expressions of the Mother Spirit.
<G-vec00057-002-s521><call_up.rufen><de> Es is an der Zeit für diejenigen, denen das feminine Prinzip innewohnt - die Frauen dieser Welt - ihrem höheren Ruf zu folgen, um noch nie zuvor bekannte Ausdrucksformen des Mutter-Archetyps zu erwecken.
<G-vec00057-002-s522><call_up.rufen><en> Over 2100 exhibitors from 43 countries and around 145,000 visitors from more than 100 nations heeded the call for “Intelligence in Production”.
<G-vec00057-002-s522><call_up.rufen><de> Dem Ruf nach „Intelligence in Production“ waren über 2100 Aussteller aus 43 Ländern und rund 145.000 Besucher aus mehr als 100 Nationen gefolgt.
<G-vec00057-002-s523><call_up.rufen><en> The word salat (prayer) literally means "call" and to perform it is to seek closeness to God.
<G-vec00057-002-s523><call_up.rufen><de> Das Wort Salat (Gebet) bedeutet wörtlich „Ruf" und es auszuführen bedeutet die Nähe Gottes zu suchen.
<G-vec00057-002-s524><call_up.rufen><en> Call us if you want to be picked up (for free).
<G-vec00057-002-s524><call_up.rufen><de> Ruf uns an, wenn du abgeholt werden möchtest (kostenlos).
<G-vec00057-002-s525><call_up.rufen><en> If you follow the call to nurture the light in a particular space your job is just beginning.
<G-vec00057-002-s525><call_up.rufen><de> Wenn ihr dem Ruf folgt, das Licht an einem bestimmten Ort zu hüten, dann beginnt eure Aufgabe gerade erst.
<G-vec00057-002-s526><call_up.rufen><en> 1 Number: The device will receive a call only if the caller's number is transmitted and if that number is in the number list.
<G-vec00057-002-s526><call_up.rufen><de> 1 Nummer: das Gerät nimmt einen Ruf nur entgegen, wenn der Anrufer in der Nummernliste steht und seine Rufnummer übermittelt wird.
<G-vec00057-002-s527><call_up.rufen><en> This call was given in mid Africa, but once called this entity roamed about a bit, answering The Call from others in the vicinity.
<G-vec00057-002-s527><call_up.rufen><de> Dieser Ruf wurde in Zentralafrika gegeben, doch einmal gerufen, reiste dieses Wesen ein bißchen herum und beantwortete den Ruf von anderen in der Nähe.
<G-vec00057-002-s529><call_up.rufen><en> The kidnapping and subsequent release of Neda, mother of Mãezinha, occurring in February 1989, was the immediate preparation for the call of God, and led our Founders to completely detach themselves from material goods.
<G-vec00057-002-s529><call_up.rufen><de> Die im Februar 1989 stattgefundene Entführung und anschließende Freilassung von Neda, der Mutter von Mãezinha, war die unmittelbare Vorbereitung auf den Ruf Gottes und veranlasste unsere Gründer dazu, sich vollständig von materiellen Gütern zu lösen.
<G-vec00057-002-s530><call_up.rufen><en> They were joined by extremist European left activists and volunteers who answered the call to help the Palestinians in the Gaza." ↑
<G-vec00057-002-s530><call_up.rufen><de> Ihnen schlossen sich linksradikale Aktivisten und Organisationen aus Europa an sowie Freiwillige, die dem Ruf folgten, den Palästinensern im Gazastreifen zu helfen und nicht in die Gewaltpläne der IHH eingeweiht waren.
<G-vec00057-002-s531><call_up.rufen><en> IVR remote control via DTMF not possible if outgoing gateway call is not in state CONNECTED.
<G-vec00057-002-s531><call_up.rufen><de> Die Steuerung eines IVR-Systems via DTMF ist nicht möglich solange der Ruf nicht vollständig aufgebaut ist.
<G-vec00057-002-s532><call_up.rufen><en> Contact us We’re here to help, so send us an e-mail, call us or chat to us live online.
<G-vec00057-002-s532><call_up.rufen><de> Wir helfen Dir gerne weiter, also sende uns doch einfach eine E-Mail, rufe uns an oder chatte live mit uns.
<G-vec00057-002-s533><call_up.rufen><en> 33:3 Call unto Me, and I will answer thee, and will tell thee great things, and hidden, which thou knowest not.
<G-vec00057-002-s533><call_up.rufen><de> 33:3 Rufe mich an, dann will ich dir antworten und will dir Großes und Unfaßbares mitteilen, das du nicht kennst.
<G-vec00057-002-s534><call_up.rufen><en> I call on both parties to continue their constructive approach in the next rounds of talks and to show the necessary willingness to compromise."
<G-vec00057-002-s534><call_up.rufen><de> Ich rufe beide Seiten dazu auf, auch in den folgenden Gesprächsrunden ihren bisherigen konstruktiven Ansatz weiterzuführen und die notwendige Kompromissbereitschaft zu zeigen“.
<G-vec00057-002-s535><call_up.rufen><en> I call some hotel service number and ask for explanations.
<G-vec00057-002-s535><call_up.rufen><de> Ich rufe eine Servicenummer des Hotels an und bitte um Erklärungen.
<G-vec00057-002-s536><call_up.rufen><en> Call upon God to convict you so deeply that you can say, “My sin is ever before me” (Psalm 51:3).
<G-vec00057-002-s536><call_up.rufen><de> Rufe zu Gott, dich so zu überzeugen, daß du sagen kannst, “Meine Sünde ist immer vor mir.” (Ps.
<G-vec00057-002-s537><call_up.rufen><en> 26 I call heaven and earth as witnesses this day, that you shall quickly perish from the land, which, when you have crossed over the Jordan, you will possess.
<G-vec00057-002-s537><call_up.rufen><de> 26. den Himmel und die Erde rufe ich heute als Zeugen gegen euch an: dann werdet ihr unverzüglich aus dem Land ausgetilgt sein, in das ihr jetzt über den Jordan zieht, um es in Besitz zu nehmen.
<G-vec00057-002-s538><call_up.rufen><en> He says, “Call to me and I will answer you, and will tell you great and hidden things that you have not known” (Jer.
<G-vec00057-002-s538><call_up.rufen><de> Er sagt: „Rufe zu mir, so will ich dir antworten und dir große, unfassbare Dinge mitteilen, die du nicht kennst“ (Jer.
<G-vec00057-002-s539><call_up.rufen><en> Males begin to call around March and throughout May.
<G-vec00057-002-s539><call_up.rufen><de> Männchen fangen an, im März und bis Mai Rufe auszustossen.
<G-vec00057-002-s540><call_up.rufen><en> 16I call my servant but he does not reply though I beg him with my own mouth.
<G-vec00057-002-s540><call_up.rufen><de> 16Meinem Knechte rufe ich, und er antwortet nicht; mit meinem Munde muss ich zu ihm flehen.
<G-vec00057-002-s541><call_up.rufen><en> Then call now and learn from a French teacher at a distance.
<G-vec00057-002-s541><call_up.rufen><de> Dann rufe jetzt an und lerne von einem Französischlehrer aus der Ferne.
<G-vec00057-002-s542><call_up.rufen><en> I always get there one more time, there’s nothing else I can do, even here, where I let my hand pass over the tall grass, raise my head and call, my hand, my distinctly real hand.
<G-vec00057-002-s542><call_up.rufen><de> Ich gelange da immer noch einmal hin, ich kann nicht anders, auch hier, wo ich die Hand übers hohe Gras streichen lasse, den Kopf hebe und rufe, meine Hand, meine ausgesprochen wirkliche Hand.
<G-vec00057-002-s543><call_up.rufen><en> Psalms 50:15 And call me in the day of trouble; I will deliver you, and you will glorify me."
<G-vec00057-002-s543><call_up.rufen><de> Psalms 50:15 Und rufe mich an in der Not, so will ich dich erretten, so sollst du mich preisen.
<G-vec00057-002-s544><call_up.rufen><en> I call heaven and earth to record this day against you, that I have set before you life and death, blessing and cursing: therefore choose life, that both thou and thy seed may live…
<G-vec00057-002-s544><call_up.rufen><de> Ich rufe Himmel und Erde an, um diesen Tag gegen dich festzuhalten, den ich dir vor Leben und Tod, Segen und Fluchen gestellt habe: also wähle das Leben, damit sowohl du als auch dein Same leben möge...
<G-vec00057-002-s545><call_up.rufen><en> Call the dialog to search and replace texts in the schematic.
<G-vec00057-002-s545><call_up.rufen><de> Rufe den Dialog, um Texte im Schaltplan zu suchen und zu ersetzen, auf.
<G-vec00057-002-s546><call_up.rufen><en> Call to me and I will answer you, and will tell you great and hidden things that you have not known. prayer listening
<G-vec00057-002-s546><call_up.rufen><de> Rufe mich an, so will ich dir antworten und will dir kundtun große und unfassbare Dinge, von denen du nichts weißt.
<G-vec00057-002-s547><call_up.rufen><en> If you fear that your parent may hurt you, your siblings, or themselves, call the emergency department.
<G-vec00057-002-s547><call_up.rufen><de> Wenn du Angst hast, dass dein Vater oder deine Mutter dich, deine Geschwister oder sich selbst verletzt, rufe den Notdienst.
<G-vec00057-002-s548><call_up.rufen><en> Plumbing, however, is another story. Then I call for help immediately.
<G-vec00057-002-s548><call_up.rufen><de> Klempnerarbeiten sind allerdings etwas ganz anderes: da rufe ich sofort um Hilfe.
<G-vec00057-002-s549><call_up.rufen><en> 16 Jesus said to her, "Go, call your husband, and come here."
<G-vec00057-002-s549><call_up.rufen><de> 16 Er sagte zu ihr: Geh, rufe deinen Mann und komm hierher.
<G-vec00057-002-s550><call_up.rufen><en> Use quirks and call on your companions to help you launch powerful attacks in which you also use the environment — or destroy it completely.
<G-vec00057-002-s550><call_up.rufen><de> Setze Macken ein und rufe Deine Begleiter zu Hilfe, um mächtige Angriffe zu starten, in denen Du auch die Umgebung einsetzt — oder vollständig zerstörst.
<G-vec00057-002-s551><call_up.rufen><en> If you wish to speak to us, please call our Reservation Center at ++84.4.3927 4120 and live chat during our business office hours.
<G-vec00057-002-s551><call_up.rufen><de> Wenn Sie mit uns sprechen möchten, rufen Sie bitte unsere Reservierungszentrale unter + +84.4.3927 4120 an oder per Live-Chat während unserer Geschäftszeiten.
<G-vec00057-002-s552><call_up.rufen><en> Call the sa_server_option system procedure, setting the ProcedureProfiling option to ON.
<G-vec00057-002-s552><call_up.rufen><de> Rufen Sie die Systemprozedur "sa_server_option" auf und setzen Sie die Option "ProcedureProfiling" auf ON.
<G-vec00057-002-s553><call_up.rufen><en> To go to layouts in an external file, define a script in that file using the Go to Layout script step, and call that script from the first file using the Perform Script script step.
<G-vec00057-002-s553><call_up.rufen><de> Um in Layouts in einer externen Datei zu wechseln, definieren Sie in der betreffenden Datei ein Script mit dem Scriptschritt „Gehe zu Layout“ und rufen dieses Script aus der ersten Datei mit dem Script ausführen Scriptschritt auf.
<G-vec00057-002-s554><call_up.rufen><en> We call our friends in Colombo and are relieved to hear, they have not been bothered; we send SMS and E-Mails to all our other friends and get to know, they too stayed healthy and unhit by Tsunami.
<G-vec00057-002-s554><call_up.rufen><de> Wir rufen unsere Freunde in Colombo an und hören erleichtert, dass sie nicht betroffen sind; versenden SMS und E-mails an unsere anderen Bekannten und hören, dass auch sie nicht zu Schaden gekommen sind.
<G-vec00057-002-s555><call_up.rufen><en> On your arrival back to Otopeni Airport, simply call us at 0786 015 300 / 0786 015 301 and our fast shuttle will wait for you in front of the Departures Terminal, A Zone to transfer you straight back to your car, in the parking place.
<G-vec00057-002-s555><call_up.rufen><de> Bei der Rückkehr, nachdem Sie die Kontrolle der Dokumente hinter sich haben, während Sie auf Ihr Gepäck warten, rufen Sie uns bei den Telefonnummer 0786 015 300 oder 0786 015 301 an und wir werden vor dem Terminal Abreisen, Zone A anwesend sein, für den Transfer zur AirParking und zur Übernahme Ihres Fahrzeugs.
<G-vec00057-002-s556><call_up.rufen><en> Harmonic sounds call forth feelings.
<G-vec00057-002-s556><call_up.rufen><de> Harmonische Töne rufen Gefühle hervor.
<G-vec00057-002-s557><call_up.rufen><en> Call us or write an e-mail and we will find the perfect package for you.
<G-vec00057-002-s557><call_up.rufen><de> Rufen Sie uns einfach an oder schreiben Sie uns eine E-Mail und wir finden bestimmt das perfekte Paket für Sie.
<G-vec00057-002-s558><call_up.rufen><en> Call 800-633-4410 to speak to a Korn Ferry representative or complete the form below.
<G-vec00057-002-s558><call_up.rufen><de> RUFEN SIE UNS AN UNTER 800-633-4410 UM MIT EINEM KORN FERRY MITARBEITER ZU SPRECHEN.
<G-vec00057-002-s559><call_up.rufen><en> Schmallenbach, however most people call me Schmalli.
<G-vec00057-002-s559><call_up.rufen><de> Mein Name ist Volker Schmallenbach, die Meisten rufen mich allerdings Schmalli.
<G-vec00057-002-s560><call_up.rufen><en> For suites, call (800) 544-9288 in the U.S. and Canada or your nearest Global Contact Center.
<G-vec00057-002-s560><call_up.rufen><de> Für die Buchung von Suiten rufen Sie aus den USA oder Kanada die Nummer +(1) 800 544 9288 an oder wenden Sie sich an Ihr nächstgelegenes Global Contact Center.
<G-vec00057-002-s561><call_up.rufen><en> We call upon the International Community to pay close attention to events that unfold within Israel and in the Occupied Territories, to make it absolutely clear that crimes against humanity will not be tolerated, and to take concrete measures to prevent such crimes from taking
<G-vec00057-002-s561><call_up.rufen><de> Wir rufen die internationale Gemeinschaft auf, die Vorkommnisse in Israel und den Besetzten Gebieten genau zu beobachten, um absolut klar zu machen, dass Verbrechen gegen die Menschheit nicht geduldet werden, sowie konkrete Maßnahmen zu ergreifen, um zu verhindern, dass solche Verbrechen stattfinden.
<G-vec00057-002-s562><call_up.rufen><en> We urgently call on kind hearted people and international human rights organizations to pay attention to the plight of Falun Gong practitioners, and hope that they will help end the persecution of Falun Gong.
<G-vec00057-002-s562><call_up.rufen><de> -Rao Wanglai Wir rufen dringend gutherzige Menschen und internationale Menschenrechtsorganisationen auf, der Notlage von Falun Gong-Praktizierenden Aufmerksamkeit zu schenken und hoffen, dass sie mithelfen werden, die Verfolgung von Falun Gong zu beenden.
<G-vec00057-002-s563><call_up.rufen><en> On the TV, a lot of broadcasts are broadcast, in which doctors call to be vigilant, watch their birthmarks, periodically consult a doctor.
<G-vec00057-002-s563><call_up.rufen><de> Im Fernsehen werden viele Sendungen ausgestrahlt, in denen Ärzte rufen, wachsam zu sein, ihre Muttermale zu beobachten, regelmäßig einen Arzt aufzusuchen.
<G-vec00057-002-s564><call_up.rufen><en> We condemn violent conflict in the world, more so violence committed in the name of religion, and call for an end to violent hostility.
<G-vec00057-002-s564><call_up.rufen><de> Wir verdammen gewaltsame Konflike in der Welt, besonders Gewalt im Namen der Religion und rufen zu einem Ende gewaltsamer Feindschaft auf....
<G-vec00057-002-s565><call_up.rufen><en> BUT: please call us before, to be sure that we are in.
<G-vec00057-002-s565><call_up.rufen><de> ABER: bevor Sie kommen, rufen Sie uns an um sicher zu gehen, dass wir auch da sind.
<G-vec00057-002-s566><call_up.rufen><en> Animal Companion – Your Call Pet additionally summons the first pet from your stable as a second companion to fight by your side.
<G-vec00057-002-s566><call_up.rufen><de> 'Tierbegleiter' – Euer 'Begleiter rufen' ruft zusätzlich den ersten Begleiter aus eurem Stall herbei, der als zweiter Gefährte an eurer Seite kämpft.
<G-vec00057-002-s567><call_up.rufen><en> 31Jesus answered them, ‘It is not the healthy who need a doctor, but those who are ill. 32I have not come to call the righteous, but sinners to repentance.’
<G-vec00057-002-s567><call_up.rufen><de> 31Und Jesus antwortete und sprach zu ihnen: Die Gesunden bedürfen nicht eines Arztes, sondern die Kranken; 32ich bin nicht gekommen, Gerechte zu rufen, sondern Sünder zur Buße.
<G-vec00057-002-s568><call_up.rufen><en> When the vehicle is going to be used again, the driver can call the vehicle.
<G-vec00057-002-s568><call_up.rufen><de> Soll das Fahrzeug wieder genutzt werden, kann der Fahrer das Fahrzeug rufen.
<G-vec00057-002-s569><call_up.rufen><en> Getting Started For additional information or to arrange an appointment to discuss your situation please call us at 518-584-5844 (x) 2311 or email us.
<G-vec00057-002-s569><call_up.rufen><de> Für weitere Informationen, oder um einen Termin zu vereinbaren und Ihren Fall zu besprechen, rufen Sie bitte Frau Alicia Butler unter der Rufnummer (+1)518-584-5844 (Durchwahl) 2311 an oder schicken Sie uns eine E-Mail.
<G-vec00057-002-s589><call_up.rufen><en> CALL NOW - +1 416-253-6666 (Toll Free: +1 800-265-8521) and speak to a customer service representative for more info.
<G-vec00057-002-s589><call_up.rufen><de> RUFEN SIE NOCH HEUTE AN +1 416-253-6666 (Gebührenfrei in Nordamerika: +1 800-265-8521) und erfahren Sie mehr von einem unserer Kundendienstmitarbeiter.
<G-vec00057-002-s590><call_up.rufen><en> Call the Samsung Contact Centre and ask for remote support.
<G-vec00057-002-s590><call_up.rufen><de> Rufen Sie das SamsungCallcenter an, und bitten Sie um Fernunterstützung.
<G-vec00057-002-s591><call_up.rufen><en> Or call the landlord Elisabeth Fihn at 0708-553609.
<G-vec00057-002-s591><call_up.rufen><de> Oder rufen Sie den Vermieter Elisabeth Fihn unter 0708-553609 an.
<G-vec00057-002-s592><call_up.rufen><en> German, English Simply call Gebr.
<G-vec00057-002-s592><call_up.rufen><de> Deutsch, Englisch Rufen Sie Gebr.
<G-vec00057-002-s593><call_up.rufen><en> Call MUCHO Hotline at 0800 077 800, free from MUCHO, cost of a local call from a fixed telephone.
<G-vec00057-002-s593><call_up.rufen><de> Rufen Sie den MUCHO Kundendienst an: 0800 077 800, gratis ab MUCHO; Kosten für einen lokalen Anruf ab Fixtelefon.
<G-vec00057-002-s594><call_up.rufen><en> If you suspect that you have an intestinal blockage, call an ambulance urgently or go to the doctor as soon as possible to prevent any serious complications.
<G-vec00057-002-s594><call_up.rufen><de> Wenn Sie den Verdacht haben, dass Sie eine Darmblockade haben, rufen Sie dringend einen Krankenwagen oder gehen Sie so schnell wie möglich zum Arzt, um schwerwiegende Komplikationen zu vermeiden.
<G-vec00057-002-s595><call_up.rufen><en> If you have any interest in tungsten radiation shielding, please feel free to email us: sales@chinatungsten.com or call us by: 0086 592 512 9696, 0086 592 512 9595.
<G-vec00057-002-s595><call_up.rufen><de> Wenn Sie Interesse an Wolfram Strahlenschutz haben, wenden Sie sich bitte an uns per E-Mail: sales@chinatungsten.com oder rufen Sie uns von: 0086 592 512 9696, 0086 592 512 9595.
<G-vec00057-002-s596><call_up.rufen><en> If you have questions regarding the EULAs that came with your purchase, please contact an in-store Microsoft Store sales associate or call customer service on 1800 267 785. Microsoft EULAs
<G-vec00057-002-s596><call_up.rufen><de> Bei Fragen zu den Endbenutzer-Lizenzverträgen, die mit Ihrem Kauf ausgeliefert wurden, wenden Sie sich an einen Mitarbeiter in der Microsoft-Filiale oder rufen Sie den Kundendienst an unter 0800 401065.
<G-vec00057-002-s597><call_up.rufen><en> If you get a cold or other infection while receiving Arava, call your doctor or health care professional.
<G-vec00057-002-s597><call_up.rufen><de> Wenn Sie eine Erkältung oder eine andere Infektion bekommen, während Sie dieses Medikament nehmen, rufen Sie Ihren Arzt oder Ärztin.
<G-vec00057-002-s598><call_up.rufen><en> Or call the landlord Linda Lindell at 070-5098939.
<G-vec00057-002-s598><call_up.rufen><de> Oder rufen Sie den Vermieter Linda Lindell unter 070-5098939 an.
<G-vec00057-002-s599><call_up.rufen><en> You can send us an email to contact@casas-ambiente.com or call us at +34 966 498 595.
<G-vec00057-002-s599><call_up.rufen><de> Sie können uns eine E-Mail senden an contact@casas-ambiente.com oder rufen Sie uns an unter +34 966 498 595.
<G-vec00057-002-s600><call_up.rufen><en> Use our freight fare search to find prices and information online or call now and talk to our knowledgeable freight ferry team for bookings and advice. If you aren’t carrying freight and are looking to make a tourist booking then please visit our Fishbourne Portsmouth Ferry page instead.
<G-vec00057-002-s600><call_up.rufen><de> Nutzen Sie unsere Frachfährensuche um Preise und Informationen online zu finden oder rufen Sie uns an um mit unseren Frachtexperten über Buchungen und Informationen zu sprechen Wenn Sie keine Fracht transportieren und eine normale Touristenbuchung durchführen wollen, besuchen Sie bitte unsere Fishbourne Portsmouth Fähre Seite.
<G-vec00057-002-s601><call_up.rufen><en> Refine your search or call us on +31(0)184 60 13 48.
<G-vec00057-002-s601><call_up.rufen><de> Präzisieren Sie Ihre Suche oder rufen Sie uns an: +31 (0) 184-60 13 48.
<G-vec00057-002-s602><call_up.rufen><en> Or call the landlord Malin Andersson at 0414-30938 (0706-640306).
<G-vec00057-002-s602><call_up.rufen><de> Oder rufen Sie den Vermieter Malin Andersson unter 0414-30938 (0706-640306) an.
<G-vec00057-002-s603><call_up.rufen><en> Contact For all inquiries and reservations, call the Villa Giulia, or send an email via the contact form.
<G-vec00057-002-s603><call_up.rufen><de> Kontakt Für alle Anfragen und Reservierungen rufen Sie die Villa Giulia an oder senden Sie eine E-Mail über das Kontaktformular.
<G-vec00057-002-s604><call_up.rufen><en> Please call us on 0800 330 8011, email us on groupsgrv@amba-hotel.com or use the contact form provided.
<G-vec00057-002-s604><call_up.rufen><de> Bitte rufen Sie uns an unter 0800 330 8011, senden Sie uns eine E-Mail an groupsgrv@amba-hotel.com oder verwenden Sie das bereitgestellte Kontaktformular.
<G-vec00057-002-s605><call_up.rufen><en> If this does not help, call your firewall settings or from the standard “control Panel”, or via the menu “Run” command firewall.cpl, and completely unplug.
<G-vec00057-002-s605><call_up.rufen><de> Wenn das nicht hilft, rufen Sie die Firewall-Einstellungen entweder von Standard „Control Panel” oder über das Menü „Run“ Befehl firewall.cpl ein, und deaktivieren Sie ihn vollständig.
<G-vec00057-002-s606><call_up.rufen><en> Please call the hotel no later than 18:00 on the day of arrival if you wish to check in later.
<G-vec00057-002-s606><call_up.rufen><de> Bitte rufen Sie das Hotel am Tag Ihrer Ankunft bis spätestens 18:00 Uhr an, falls Sie später einchecken wollen.
<G-vec00057-002-s607><call_up.rufen><en> • Reporting: Call your test results from a button.
<G-vec00057-002-s607><call_up.rufen><de> • Reporting: Rufen Sie Ihre Prüfergebnisse auf Knopfdruck ab.
<G-vec00057-002-s608><call_up.rufen><en> Call Swiss America trading right now: 1-800-289-2646.
<G-vec00057-002-s608><call_up.rufen><de> Ruft Swiss America Trading gleich jetzt an: 1-800-289-2646.
<G-vec00057-002-s609><call_up.rufen><en> Please leave your name and telephone number and UF Gabelstapler GmbH will call you back.
<G-vec00057-002-s609><call_up.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und UF Gabelstapler GmbH ruft Sie zurück.
<G-vec00057-002-s610><call_up.rufen><en> The Checkmk alert helpers call up their functions synchronously.
<G-vec00057-002-s610><call_up.rufen><de> Der Alerthelper von Checkmk ruft Ihre Funktionen synchron auf.
<G-vec00057-002-s611><call_up.rufen><en> call on him while he is near.
<G-vec00057-002-s611><call_up.rufen><de> Ruft ihn an, während er nahe ist.
<G-vec00057-002-s612><call_up.rufen><en> Please leave your name and telephone number and Delgado Freizeit GmbH will call you back.
<G-vec00057-002-s612><call_up.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und UnikTruck A/S ruft Sie zurück.
<G-vec00057-002-s613><call_up.rufen><en> It will call res_init(), if it has not already been called.
<G-vec00057-002-s613><call_up.rufen><de> Sie ruft res_init() auf, wenn es noch nicht aufgerufen wurde.
<G-vec00057-002-s614><call_up.rufen><en> opening, you must call, Ya Fattah, Ya Fattah, Ya Fattah.
<G-vec00057-002-s614><call_up.rufen><de> Für die Öffnung ruft ihr Ya Fattah, Ya Fattah, Ya Fattah.
<G-vec00057-002-s615><call_up.rufen><en> There are daily steamers from Piraeus to Corfu, Cephallonia and Zakynthos, though the same ship does not necessarily call at all three.
<G-vec00057-002-s615><call_up.rufen><de> Es gibt tägliche Dampfer von Piraeus zu Corfu, Cephallonia und Zakynthos, obwohl das gleiche Schiff nicht unbedingt überhaupt drei ruft.
<G-vec00057-002-s616><call_up.rufen><en> Please leave your name and telephone number and AGRAVIS Technik Center GmbH will call you back.
<G-vec00057-002-s616><call_up.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und AGRAVIS Technik Center GmbH ruft Sie zurück.
<G-vec00057-002-s617><call_up.rufen><en> Call to Allah.
<G-vec00057-002-s617><call_up.rufen><de> Ruft Allah an.
<G-vec00057-002-s618><call_up.rufen><en> Call xxx() to get the result for the aggregate when the group changes or after the last row has been processed.
<G-vec00057-002-s618><call_up.rufen><de> Es ruft xxx() auf, um das Aggregatergebnis zu erhalten, wenn die Gruppe wechselt oder nachdem die letzte Zeile verarbeitet wurde.
<G-vec00057-002-s619><call_up.rufen><en> Be aware of this and be clear about the assistance you call to yourself.
<G-vec00057-002-s619><call_up.rufen><de> Seid euch dessen bewußt, und seid klar in bezug auf die Unterstützung, die ihr zu euch ruft.
<G-vec00057-002-s620><call_up.rufen><en> Enlighten your peasant brothers, banish ignorance from the villages, call on the peasant poor to support the workers of town and country in their glorious struggle.
<G-vec00057-002-s620><call_up.rufen><de> Klärt eure Brüder, die Bauern, auf: vertreibt die Finsternis aus dem Dorf, ruft die Dorfarmut auf, die Arbeiter in Stadt und Land in ihrem ruhmvollen Kampf zu unterstützen.
<G-vec00057-002-s621><call_up.rufen><en> In my country Malaysia, the muezzin would call out to Muslims for prayer five times a day through loudspeakers from the minarets of mosques.
<G-vec00057-002-s621><call_up.rufen><de> In meinem Heimatland Malaysien ruft der Muezzin durch die Lautsprecher auf den Minaretten der Moscheen fünfmal am Tag die Muslime zum Gebet.
<G-vec00057-002-s622><call_up.rufen><en> If you call them to Guidance they would not hear; you see them looking at you and they see not.
<G-vec00057-002-s622><call_up.rufen><de> Und wenn ihr sie zur Rechtleitung ruft, hören sie nicht.
<G-vec00057-002-s623><call_up.rufen><en> 110 Say: "Call upon Allah, or call upon Rahman: by whatever name ye call upon Him, (it is well): for to Him belong the Most Beautiful Names.
<G-vec00057-002-s623><call_up.rufen><de> 110 Sag: Ruft Allah oder ruft den Allerbarmer an; welchen ihr auch ruft, Sein sind die schönsten Namen.
<G-vec00057-002-s626><call_up.rufen><en> Elijah said to the prophets of Baal, Choose you one bull for yourselves, and dress it first; for you are many; and call on the name of your god, but put no fire under.
<G-vec00057-002-s626><call_up.rufen><de> 25Und Elia sprach zu den Propheten Baals: Wählt ihr einen Stier und richtet zuerst zu, denn ihr seid viele, und ruft den Namen eures Gottes an, aber legt kein Feuer daran.
