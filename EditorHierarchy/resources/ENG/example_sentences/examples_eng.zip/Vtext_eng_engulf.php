<G-vec00576-002-s007><engulf.durchfluten><en> During your talk I felt a sensation engulf my body.
<G-vec00576-002-s007><engulf.durchfluten><de> Während Deines Vortrags fühlte ich eine Bewegung meinen Körper durchfluten.
<G-vec00576-002-s033><engulf.überfluten><en> It seemed that Gaddafi’s days were numbered and that soon the uprising would engulf Tripoli.
<G-vec00576-002-s033><engulf.überfluten><de> Es schien, als ob Gaddafis Tage gezählt wären, und dass der Aufstand bald die Hauptstadt Tripolis überfluten würde.
