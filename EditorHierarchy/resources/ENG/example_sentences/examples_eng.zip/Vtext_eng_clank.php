<G-vec01196-002-s039><clank.scheppern><en> When supermarkets receive nighttime deliveries, for example, the local residents' sleep shouldn't be disturbed by the rattle and clank of transport trolleys.
<G-vec01196-002-s039><clank.scheppern><de> Wenn zum Beispiel nachts die Supermärkte beliefert werden, darf das Rattern und Scheppern der Transportwagen die Anwohner nicht um den Schlaf bringen.
<G-vec01196-002-s040><clank.scheppern><en> I heard a clank, almost darkness, and someone tapping on my shoulder.
<G-vec01196-002-s040><clank.scheppern><de> Ich hörte ein Scheppern, fast Dunkelheit, und jemand tippt auf meine Schulter.
