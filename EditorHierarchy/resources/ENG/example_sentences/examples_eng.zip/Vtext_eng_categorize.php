<G-vec00488-002-s014><categorize.aufteilen><en> For some, it means that they categorize precisely their daily activities into different categories, for every 5 minutes period.
<G-vec00488-002-s014><categorize.aufteilen><de> Für die Einen bedeutet es, dass sie jeden Abend ihre Tätigkeiten auf fünf Minuten genau auf verschiedene Kategorien aufteilen müssen.
<G-vec00488-002-s019><categorize.bestimmen><en> In order to categorize them, they're split into 5 different sections: * '''Simple Items''' boost their associated attribute by 3.
<G-vec00488-002-s019><categorize.bestimmen><de> Um sie zu bestimmen, sind sie in 5 Kategorien unterteilt: "einfache" Items verstärken das dazugehörige Attribut um 3.
<G-vec00488-002-s020><categorize.bewerten><en> The benefits are clear: Speed limits, warnings and information can be activated in specific situations so that only the most relevant information is instantly conveyed to drivers, who no longer have to select and categorize the information they process.
<G-vec00488-002-s020><categorize.bewerten><de> Die Vorteile liegen auf der Hand: Geschwindigkeitsbegrenzungen, Warnungen und Hinweise können situationsbezogen geschaltet werden, sodass wirklich nur die relevanten Informationen zeitnah an die Fahrer übermittelt werden und von ihnen nicht noch selektiert oder bewertet werden müssen.
<G-vec00488-002-s043><categorize.einordnen><en> Business-oriented policies — Bot Manager enables organizations to categorize different types of bots and create management policies that define how traffic from different categories will be handled based on their business impact.
<G-vec00488-002-s043><categorize.einordnen><de> Geschäftsorientierte Regeln – Bot Manager ermöglicht Unternehmen, verschiedene Bot-Typen in Kategorien einzuordnen und Regeln zu erstellen, wie der Datenverkehr aus unterschiedlichen Kategorien zu handhaben ist – je nachdem, welche geschäftlichen Auswirkungen damit verbunden sind.
<G-vec00488-002-s032><categorize.einstufen><en> Alongside with the other military leaders of all members our MoD categorize the fights in eRep and pick out the important ones.
<G-vec00488-002-s032><categorize.einstufen><de> Gemeinsam mit den anderen Militärführern der Allianzstaaten legt unser Verteidigungsministerium dann fest, welche Schlachten als besonders wichtig einzustufen sind und welche man vernachlässigen kann.
<G-vec00488-002-s033><categorize.einstufen><en> #1 Prioritizing buyer personas: It is advisable to categorize buyer personas according to their priority.
<G-vec00488-002-s033><categorize.einstufen><de> #1 Priorisierung der Buyer Personas: Es empfiehlt sich, Buyer Personas nach Priorität einzustufen.
<G-vec00488-002-s034><categorize.einteilen><en> The Monarch LCS Radar allows administrators to log in and categorize appliances into distinct groups—such as dentistry, business, and medicine departments—and see only those units assigned to each category.
<G-vec00488-002-s034><categorize.einteilen><de> Monarch LCS Radar ermöglicht es Administratoren, sich anzumelden und Geräte in bestimmte Gruppen – etwa die Fachbereiche Zahnmedizin, BWL und Medizin – einzuteilen und nur die zur jeweiligen Kategorie gehörenden Units anzuzeigen.
<G-vec00488-002-s037><categorize.filtern><en> For all customers or cost centers within your organization you can create custom accounts and categorize them as CAPEX or OPEX, Non-Billable or Billable.
<G-vec00488-002-s037><categorize.filtern><de> Legen Sie für alle Kunden oder Kostenstellen eigene Accounts an und filtern Sie nach verschiedenen Kostenarten wie Betriebsausgaben oder -einnahmen, Investitionen oder abrechenbare Kundenaufträge.
<G-vec00488-002-s018><categorize.gliedern><en> Depending on the field of application we categorize the processing of biomass: Dry Processing In the dry process materials are treated which have to be aspirated during grinding process.
<G-vec00488-002-s018><categorize.gliedern><de> Den Aufschluss von Biomasse gliedern wir nach Anwendungsbereichen: Trockenaufschluss Beim Trockenaufschluss werden Stoffe aufbereitet, die in der Regel beim Zerkleinern aspiriert werden.
<G-vec00488-002-s039><categorize.kategorisieren><en> With over 140 different and distinct groups with their own traditions and culinary culture found in the Philippines, even without outside influence this cuisine would be extremely difficult to categorize.
<G-vec00488-002-s039><categorize.kategorisieren><de> Mit alleine über 140 unterschiedlichen Gruppierungen mit eigenen Traditionen und Kochkulturen auf den Philippinen, ist diese Küche unglaublich schwer zu greifen und kategorisieren.
<G-vec00488-002-s021><categorize.klassifizieren><en> A CRM system can help you identify and add new leads easily and quickly, and categorize them accurately.
<G-vec00488-002-s021><categorize.klassifizieren><de> Ein CRM-System kann Ihnen dabei helfen, neue Leads einfach und schnell zu identifizieren, zu Ihrer Datenbank hinzuzufügen und exakt zu klassifizieren.
<G-vec00488-002-s105><categorize.ordnen><en> This template will also categorize articles that include it into Category:Article stubs.
<G-vec00488-002-s105><categorize.ordnen><de> Diese Vorlage ordnet Artikel in die Kategorie:Stub ein und fügt einen Hinweis zum Artikel hinzu.
<G-vec00488-002-s107><categorize.organisieren><en> • Categorize recipes - You have the control to categorize your recipes in any way you like.
<G-vec00488-002-s107><categorize.organisieren><de> • Rezepte kategorisieren - Sie können Ihre Rezepte nach Ihren Wünschen organisieren.
<G-vec00488-002-s108><categorize.rubrizieren><en> The familiar idea we have of things as objects that we can categorize by means of language and then use for our own ends is for Benjamin only the visible, topmost layer - a symptom as it were - within which further, unconscious layers are stored.
<G-vec00488-002-s108><categorize.rubrizieren><de> Die uns geläufige Vorstellung von den Dingen als Objekten, die wir dank der Sprache rubrizieren und die wir für unsere Zwecke nutzen können, ist für Benjamin bloß die oberste Schicht, gleichsam ein Symptom, dem weitere, unbewusste Schichten eingelagert sind.
<G-vec00488-002-s112><categorize.sortieren><en> These lists are useful as they make it possible to really categorize you tasks.
<G-vec00488-002-s112><categorize.sortieren><de> Diese Listen ermöglichen das Sortieren der Aufgaben.
<G-vec00488-002-s113><categorize.stecken><en> According to a study published in the magazine Psychological Science, less intelligent people are more often homophobic or racist, and tend to categorize people prematurely.
<G-vec00488-002-s113><categorize.stecken><de> Laut einer Studie, die im Magazin „Psychological Science“ veröffentlicht wurde, sind weniger intelligente Menschen häufiger homophob, rassistisch und stecken Menschen vorschnell in Schubladen.
<G-vec00488-002-s114><categorize.strukturieren><en> Na at least I know how to archive, structure, and yes categorize.
<G-vec00488-002-s114><categorize.strukturieren><de> Na wenigstens weiß ich, wie man archiviert, kategorisiert und na ja strukturiert.
<G-vec00488-002-s116><categorize.vornehmen><en> Columns exemplify systems of design and order and receive enough interest from art and architecture theorists to cause them to want to categorize their style and epoch.
<G-vec00488-002-s116><categorize.vornehmen><de> Säulen exemplifizieren Gestaltungs- und Ordnungssysteme und erwecken bei Kunst- und Architekturtheoretikern genug Interesse, um an ihnen Stil- und Epochenzuordnungen vornehmen zu wollen.
<G-vec00488-002-s121><categorize.wiederfinden><en> If you've got more of a linear mind, it might make more sense to you to categorize your books alphabetically, for easy reference.
<G-vec00488-002-s121><categorize.wiederfinden><de> Wenn du linear denkst, dann ist es für dich vielleicht sinnvoller, deine Bücher alphabetisch zu sortieren, damit du sie einfach wiederfindest.
<G-vec00488-002-s086><categorize.übermitteln><en> If you rely on OTRS as your IT service software, your customers are able to use their own customer portal where they can accurately categorize and describe their incidents and service requests using input masks previously defined by you and your team.
<G-vec00488-002-s086><categorize.übermitteln><de> Mit OTRS als IT-Service Software nutzen Ihre Kunden ein eigenes Kundenportal, in dem sie Incidents und Service Requests über die von Ihnen definierten Eingabemasken schon vorher richtig kategorisiert und definiert an Sie übermitteln können.
<G-vec00916-002-s022><categorize.einordnen><en> Between this merciless harpoon-gunning you also find orchestra parts, a bit of Doom and even Black Metal (Goddess Of Death) - a mixture that still gives a coherent end-result. Yet that one is difficult to categorize and definitely needs more than just one run-through to capture it all.
<G-vec00916-002-s022><categorize.einordnen><de> Zwischen den schweren Harpunengeschützen gibt´s auch orchestrale Teile, ein bisschen Doom und Black Metal ist da auch dabei (Goddess Of Death) - eine Mischung, die ein stimmiges Ganzes ergibt, das sich bloß etwas schwer in ein Genre einordnen lässt und mehrere Durchläufe im Player braucht, um auch alles erfassen zu können...
<G-vec00916-002-s026><categorize.einordnen><en> We retrieve information from the form so as to assess and categorize your proposal.
<G-vec00916-002-s026><categorize.einordnen><de> Wir fragen Informationen ab, um deinen Vorschlag zu bewerten und einzuordnen.
<G-vec00916-002-s027><categorize.einordnen><en> I went to church and wanted to be Christian at the time, I just didn't know what to make of the experience and didn't try to categorize it.
<G-vec00916-002-s027><categorize.einordnen><de> Ich ging zur Kirche und wollte zu dieser Zeit ein Christ sein, ich wußte nur nicht, was ich mit der Erfahrung anfangen sollte und versuchte nicht, sie zu einzuordnen.
<G-vec00916-002-s028><categorize.einordnen><en> For this Futurae researchers collected tens of thousands of audio samples and used them in order to train the system and make it able to identify and categorize the recordings captured during SoundProof execution into different categories, depending on their sound content.
<G-vec00916-002-s028><categorize.einordnen><de> Forscher von Futurae sammelten dafür Zehntausende von Audio-Daten und nutzten sie, um das System zu trainieren und es in die Lage zu versetzen, die während der Ausführung von SoundProof aufgenommenen Aufnahmen zu identifizieren und, je nach Klanggehalt, in verschiedene Kategorien einzuordnen.
<G-vec00916-002-s029><categorize.einordnen><en> BancMate’s machine learning feature categorizes all expenses on the Recent Activity dashboard. The Action menu in Recent Activity allows users to click on a transaction to categorize it if machine learning has not done so already.
<G-vec00916-002-s029><categorize.einordnen><de> Das Aktionsmenü im Bereich „Jüngste Tätigkeiten“ versetzt den Nutzer in die Lage, auf eine Transaktion zu klicken, um diese in eine Kategorie einzuordnen, wenn dies nicht bereits durch die Maschinenlernfunktion geschehen ist.
<G-vec00916-002-s030><categorize.einordnen><en> The works of Herbert Hamak are not easy to categorize.
<G-vec00916-002-s030><categorize.einordnen><de> Die Arbeiten von Herbert Hamak sind nicht leicht in eine Kategorie einzuordnen.
<G-vec00916-002-s031><categorize.einordnen><en> They landed in the semi-dark room, the deliberately unidentifiable objects by some forty artists and designers, objects that without exception are something in between art, design, and design art, but that at first sight are difficult to categorize.
<G-vec00916-002-s031><categorize.einordnen><de> Im halbdunkeln Raum sind sie gelandet, die bewusst unidentifizierten Objekte von rund vierzig Künstlern und Designern, allesamt Objekte, die sich irgendwo zwischen Kunst, Design und Designart bewegen, auf den ersten Blick aber nur schwer einzuordnen sind.
<G-vec00916-002-s101><categorize.einordnen><en> I would categorize this colour as an olive green.
<G-vec00916-002-s101><categorize.einordnen><de> Die Farbe würde ich bei den olivgrün-Tönen einordnen.
<G-vec00916-002-s110><categorize.einordnen><en> On this basis, the Americans know where they stand and how to categorize the higher level of European collaboration.
<G-vec00916-002-s110><categorize.einordnen><de> Auf dieser Basis wissen die Amerikaner, woran sie sind und wie sie dieses Mehr an europäischem Miteinander einzuordnen haben.
<G-vec00916-002-s017><categorize.einteilen><en> Furthermore, the information gained by closed-ended questions allows researchers to categorize respondents into groups based on the options they have selected.
<G-vec00916-002-s017><categorize.einteilen><de> Außerdem können Forscher anhand der aus den geschlossenen Fragen gewonnenen Informationen die Befragten in Gruppen einteilen, abhängig von den von ihnen ausgewählten Optionen.
<G-vec00916-002-s023><categorize.einteilen><en> You can categorize the channels by nationality or genre, so you're never far from sports or concerts, two broadcasts that don't necessarily require you to understand the language.
<G-vec00916-002-s023><categorize.einteilen><de> Die Sender lassen sich nach Genre und Land einteilen, sodass man direkt das passende Sportevent oder Konzert findet — für beides muss man die Sprache nicht unbedingt beherrschen.
<G-vec00916-002-s024><categorize.einteilen><en> Furthermore, I propose that for the purposes of soul trapping we categorize all souls into two classes: the legal, or "White" souls, those smaller essences that are captured from beasts and animals, and illegal, or "Black" souls, which are derived from sentient mortals.
<G-vec00916-002-s024><categorize.einteilen><de> Außerdem schlage ich vor, dass wir zum Zweck des Seeleneinfangens alle Seelen in zwei Klassen einteilen: die erlaubten oder „weißen“ Seelen, jene kleineren Essenzen, die aus Tieren gewonnen werden, und die nicht erlaubten „schwarzen“ Seelen, die aus Sterblichen mit Bewusstsein stammen.
<G-vec00916-002-s015><categorize.kategorisieren><en> For example, you may want to categorize your members according to the department they belong to within your group: Marketing, Human Resources, Engineering, and so on.
<G-vec00916-002-s015><categorize.kategorisieren><de> Zum Beispiel können Sie die Mitglieder nach der Abteilungszugehörigkeit innerhalb Ihrer Gruppe kategorisieren: Marketing, Personalwesen, Technik usw.
<G-vec00916-002-s035><categorize.kategorisieren><en> You can also create new storage boxes to categorize files in your own way.
<G-vec00916-002-s035><categorize.kategorisieren><de> Sie können auch neue Boxen erstellen, um Elemente selbst zu kategorisieren.
<G-vec00916-002-s040><categorize.kategorisieren><en> Money Pro learns how you categorize transactions and predicts categories for the transactions being imported.
<G-vec00916-002-s040><categorize.kategorisieren><de> Money Pro lernt, wie Sie Ihre Transaktionen kategorisieren, und schlägt Kategorien für importierte Transaktionen vor.
<G-vec00916-002-s041><categorize.kategorisieren><en> Upload, categorize and insert files and images.
<G-vec00916-002-s041><categorize.kategorisieren><de> InsertFile: Dateien hochladen, kategorisieren und einfügen.
<G-vec00916-002-s044><categorize.kategorisieren><en> Categorize your content using the tagging function: Employees can give prospects various tags to unlock certain content in the digital Businesskit.
<G-vec00916-002-s044><categorize.kategorisieren><de> Kategorisiere Deine Inhalte mit Hilfe der Markierungsfunktion: Mitarbeiter können Interessenten verschiedene Markierungen geben, um bestimme Inhalte im digitalen Businesskit freizuschalten.
<G-vec00916-002-s045><categorize.kategorisieren><en> Categorize jobs by their status in the application process and keep anytime a global overview on your job applications.
<G-vec00916-002-s045><categorize.kategorisieren><de> Kategorisiere Jobs nach dem Status im Bewerbungsprozess und behalte so jederzeit den Überblick über deine Bewerbungen.
<G-vec00916-002-s046><categorize.kategorisieren><en> 0-100 If you want to assign a color category to your task, on the Task tab, in the Options group, click Categorize, and then click one of the color categories on the menu.
<G-vec00916-002-s046><categorize.kategorisieren><de> Zurückgestellt 0-100 Wenn Sie Ihrer Aufgabe eine Farbkategorie zuweisen möchten, klicken Sie auf der Registerkarte Aufgabe in der Gruppe Optionen auf Kategorisieren, und klicken Sie dann auf eine der Farbkategorien im Menü.
<G-vec00916-002-s047><categorize.kategorisieren><en> This distinction is obviously based on an ethnocentric motive to categorize humans in ethnic groups in order to conclude therefrom their biological as well as moral, intellectual or mental inequality.
<G-vec00916-002-s047><categorize.kategorisieren><de> Dieser Unterscheidung liegt offensichtlich ein ethnozentrisches Motiv zugrunde, Menschen in ethnischen Gruppen zu kategorisieren, um daraus ihre biologische sowie moralische, intellektuelle oder mentale Ungleichheit abzuleiten.
<G-vec00916-002-s048><categorize.kategorisieren><en> Categorize and process content in a fraction of the time and easily find key content or celebrities, places, and objects.
<G-vec00916-002-s048><categorize.kategorisieren><de> Kategorisieren und verarbeiten Sie Inhalte in einem Bruchteil der Zeit und finden Sie leicht wichtige Inhalte oder Prominente, Orte und Objekte.
<G-vec00916-002-s049><categorize.kategorisieren><en> For this, we used our statistical algorithms to categorize the matches into: high, medium, and low confidence matches.
<G-vec00916-002-s049><categorize.kategorisieren><de> Dafür haben wir unsere statistischen Algorithmen verwendet, um die Übereinstimmungen in Übereinstimmungen mit hohem, mittlerem und niedrigem Vertrauen zu kategorisieren.
<G-vec00916-002-s050><categorize.kategorisieren><en> Explore a JavaScript application that uses Computer Vision to perform optical character recognition (OCR); create smart-cropped thumbnails; plus detect, categorize, tag, and describe visual features, including faces, in an image.
<G-vec00916-002-s050><categorize.kategorisieren><de> Lernen Sie eine einfache Windows-Anwendung kennen, die maschinelles Sehen verwendet, um eine optische Zeichenerkennung (Optical Character Recognition, OCR) durchzuführen, intelligent zugeschnittene Miniaturansichten zu erstellen sowie visuelle Merkmale (einschließlich Gesichter) in einem Bild zu erkennen, zu kategorisieren, zu markieren und zu beschreiben.an image.
<G-vec00916-002-s051><categorize.kategorisieren><en> Advanced Phonebook 2.15 Categorize and store all your contacts in one place.
<G-vec00916-002-s051><categorize.kategorisieren><de> Advanced Phonebook 2.15 Kategorisieren und speichern Sie alle Ihre Kontakte an einem Ort.
<G-vec00916-002-s052><categorize.kategorisieren><en> • Categorize recipes - You have the control to categorize your recipes in any way you like.
<G-vec00916-002-s052><categorize.kategorisieren><de> • Rezepte kategorisieren - Sie können Ihre Rezepte nach Ihren Wünschen organisieren.
<G-vec00916-002-s053><categorize.kategorisieren><en> It has never been easier, to add domains, categorize and administrate them.
<G-vec00916-002-s053><categorize.kategorisieren><de> Nie war es einfacher Domains hinzuzufügen, zu kategorisieren und diese zu verwalten.
<G-vec00916-002-s054><categorize.kategorisieren><en> Many providers of expired domains categorize by industry and quality.
<G-vec00916-002-s054><categorize.kategorisieren><de> Viele Anbieter von Expired Domains kategorisieren nach Branche und Qualität.
<G-vec00916-002-s055><categorize.kategorisieren><en> These networks are responsible for how students gather and categorize information.
<G-vec00916-002-s055><categorize.kategorisieren><de> Diese Netzwerke sind dafür verantwortlich, wie Schüler Informationen sammeln und kategorisieren.
<G-vec00916-002-s056><categorize.kategorisieren><en> We manage and categorize large number of trusted manufacturers based on their special qualifications, we also build separate profiles for each supplier we work with, and score them according to standards like: Positive comment earned, average order proceeding time etc.
<G-vec00916-002-s056><categorize.kategorisieren><de> Wir verwalten und kategorisieren eine große Anzahl von vertrauenswürdigen Herstellern auf der Grundlage ihrer speziellen Qualifikationen, wir erstellen auch separate Profile für jeden Lieferanten, mit dem wir zusammenarbeiten und bewerten sie nach Standards wie: Positive Kommentare verdient, durchschnittliche Auftragslaufzeit etc.
<G-vec00916-002-s057><categorize.kategorisieren><en> The purpose of a radionics analysis is not to categorize a condition using a diagnostic name, but to identify all factors that have contributed to the clinical symptoms of the patient.
<G-vec00916-002-s057><categorize.kategorisieren><de> Der Zweck einer Radionuklidanalyse besteht nicht darin, einen Zustand anhand eines diagnostischen Namens zu kategorisieren, sondern alle Faktoren zu identifizieren, die zu den klinischen Symptomen des Patienten beigetragen haben.
<G-vec00916-002-s058><categorize.kategorisieren><en> Because the body produces Q10 of its own and because there is Q10 in almost any diet, it is seemingly impossible to categorize supplementation with Q10 as doping.
<G-vec00916-002-s058><categorize.kategorisieren><de> Da der Körper Q10 für sich selbst produziert und Q10 in fast jeder Nahrung enthalten ist, ist es scheinbar unmöglich, eine Nahrungsergänzung mit Q10 als Doping zu kategorisieren.
<G-vec00916-002-s059><categorize.kategorisieren><en> Note: • The word 'Activities' in the example can be changed to other descriptive words suitable to categorize the images.
<G-vec00916-002-s059><categorize.kategorisieren><de> Activities Hinweis: • Anstelle von "Activities" im Beispiel kann eine andere Beschreibung verwendet werden, um die Bilder zu kategorisieren.
<G-vec00916-002-s060><categorize.kategorisieren><en> These exogenous cues are efficient if they are semantic or perceptual and they interact depending on the possibility to semantically categorize the visual scene.
<G-vec00916-002-s060><categorize.kategorisieren><de> Beide Formen interagieren in ihrem Einfluss auf Change Blindness und visuelle Repräsentationen abhängig von der Möglichkeit die visuelle Szene semantisch zu kategorisieren.
<G-vec00916-002-s061><categorize.kategorisieren><en> It allows you to categorize them logically and then show only selected sets using Page Builder.
<G-vec00916-002-s061><categorize.kategorisieren><de> Es ermöglicht Ihnen, sie logisch zu kategorisieren und dann ausgewählte Sätze mit Page Builder anzuzeigen.
<G-vec00916-002-s062><categorize.kategorisieren><en> This new version of a popular Access template also lets you categorize each contact, send e-mail messages, and create maps of addresses.
<G-vec00916-002-s062><categorize.kategorisieren><de> Mit dieser neuen Version einer beliebten Access-Vorlage können Sie auch jeden Kontakt kategorisieren, E-Mails senden und Karten von Adressen erstellen.
<G-vec00916-002-s063><categorize.kategorisieren><en> To list the styles alphabetically and according to the type of style (class-based or id-based), select Categorize By Type.
<G-vec00916-002-s063><categorize.kategorisieren><de> Wählen Sie Nach Typ kategorisieren aus, um die Formatvorlagen alphabetisch und nach Formatvorlagentyp (klassen- oder ID-basiert) aufzulisten.
<G-vec00916-002-s064><categorize.kategorisieren><en> They categorize their own tournaments into special ones and regular ones.
<G-vec00916-002-s064><categorize.kategorisieren><de> Sie kategorisieren ihre eigenen Turniere nach Besonderheit und reguläre Turniere.
<G-vec00916-002-s065><categorize.kategorisieren><en> A central database to organize, categorize
<G-vec00916-002-s065><categorize.kategorisieren><de> Eine zentrale Datenbank zum Organisieren und Kategorisieren.
<G-vec00916-002-s066><categorize.kategorisieren><en> And just as I would categorize myself as a Christian for literally practising a branch of the Christian faith, such persons who do that as regards Judaism can similarly class themselves as Jews and logically, as a result, expect to be treated accordingly as Jews.
<G-vec00916-002-s066><categorize.kategorisieren><de> Und so wie ich mich als Christ für die buchstäbliche Ausübung eines Zweiges des christlichen Glaubens kategorisieren würde, können solche Personen, die das Judentum tun, sich gleichermaßen als Juden bezeichnen und logisch als solche erwarten, dass sie als Juden behandelt werden.
<G-vec00916-002-s067><categorize.kategorisieren><en> Because the countless possibilities to categorize things, the boundaries of how to divide these things are blurred.
<G-vec00916-002-s067><categorize.kategorisieren><de> Denn die unzähligen Möglichkeiten, Dinge zu kategorisieren, lassen die Grenzen der Einteilung verschwimmen.
<G-vec00916-002-s068><categorize.kategorisieren><en> Create, update, categorize, and discuss retail campaign management, promotions, and brand in one easy to use calendar application.
<G-vec00916-002-s068><categorize.kategorisieren><de> Erstellen, aktualisieren, kategorisieren und diskutieren Sie das Management von Einzelhandelskampagnen, Aktionen und Marken in einer benutzerfreundlichen Kalenderanwendung.
<G-vec00916-002-s069><categorize.kategorisieren><en> As some terms are hard to categorize, only the alphabetic list is complete.
<G-vec00916-002-s069><categorize.kategorisieren><de> Da einige Begriffe schwer zu kategorisieren sind, is lediglich die alphabetische Liste vollständig.
<G-vec00916-002-s070><categorize.kategorisieren><en> To see the rest, click All Categories on the Categorize menu.
<G-vec00916-002-s070><categorize.kategorisieren><de> Klicken Sie zum Anzeigen der restlichen Kategorien im Menü Kategorisieren auf Alle Kategorien.
<G-vec00916-002-s071><categorize.kategorisieren><en> Samanage also has the option to create incident tag clouds, which enable you to categorize cloud-based incidents.
<G-vec00916-002-s071><categorize.kategorisieren><de> Samanage bietet auch die Möglichkeit, Vorfalls-Tag-Wolken zu erstellen, mit denen Sie Vorfälle auf der Basis von Wolken kategorisieren können.
<G-vec00916-002-s072><categorize.kategorisieren><en> Organize and categorize your PDFs by inserting and customizing page elements as well as other such details into your document.
<G-vec00916-002-s072><categorize.kategorisieren><de> Organisieren und Kategorisieren Sie ihre PDFs, indem Sie Inhalte einfügen und anpassen.
<G-vec00916-002-s073><categorize.kategorisieren><en> Categorize products logically.
<G-vec00916-002-s073><categorize.kategorisieren><de> Kategorisieren Sie die Produkte logisch.
<G-vec00916-002-s074><categorize.kategorisieren><en> Add comments and categorize transactions.
<G-vec00916-002-s074><categorize.kategorisieren><de> Fügen Sie Kommentare hinzu und kategorisieren Sie Transaktionen.
<G-vec00916-002-s075><categorize.kategorisieren><en> Categorize members into teams, show them on any page.
<G-vec00916-002-s075><categorize.kategorisieren><de> Kategorisieren Sie Mitglieder und zeigen Sie sie auf jeder Seite an.
<G-vec00916-002-s076><categorize.kategorisieren><en> Categorize paragraph styles of the linguistics module.
<G-vec00916-002-s076><categorize.kategorisieren><de> Kategorisieren Sie Absatzstile des Linguistikmoduls.
<G-vec00916-002-s077><categorize.kategorisieren><en> Categorize your customers and contacts.
<G-vec00916-002-s077><categorize.kategorisieren><de> Kategorisieren Sie Ihre Kunden und Kontakte.
<G-vec00916-002-s078><categorize.kategorisieren><en> Tag and categorize open ended responses
<G-vec00916-002-s078><categorize.kategorisieren><de> Markieren und kategorisieren Sie offene Antworten.
<G-vec00916-002-s080><categorize.kategorisieren><en> This feature lets you condense, categorize, and even ignore lengthy e-mail exchanges with a single click, so you can manage large amounts of e-mail with ease.
<G-vec00916-002-s080><categorize.kategorisieren><de> Diese Eigenschaft lässt Sie kondensieren, kategorisiert und ignoriert sogar langatmige E-Mail-Austausch mit einem einzelnen Klicken, also können Sie große Mengen von E-Mail leicht handhaben.
<G-vec00916-002-s081><categorize.kategorisieren><en> How to choose between different question types, import questions, categorize them and randomize them.
<G-vec00916-002-s081><categorize.kategorisieren><de> Wie man zwischen verschiedenen Arten von Fragen wählt, Fragen importiert, kategorisiert und nach dem Zufallsprinzip anordnet.
<G-vec00916-002-s082><categorize.kategorisieren><en> File management In addition to video browsing and playback, Control Center can categorize and search uploaded files so users can quickly locate the video clip they are looking for.
<G-vec00916-002-s082><categorize.kategorisieren><de> Beweisverwaltung Zusätzlich zum Durchsuchen und Wiedergeben von Videos können im Control Center hochgeladene Dateien kategorisiert und durchsucht werden, sodass Benutzer den gewünschten Videoclip schnell finden können.
<G-vec00916-002-s083><categorize.kategorisieren><en> Machine Learning, Artificial Intelligence and Cognitive Search Using machine learning methods trained systems can be used to independently index and categorize vast amounts of data.
<G-vec00916-002-s083><categorize.kategorisieren><de> Machine Learning, Künstliche Intelligenz und Cognitive Search Mit Machine Learning Methoden können größere Datenmengen durch trainierte Systeme eigenständig erfasst und kategorisiert werden.
<G-vec00916-002-s084><categorize.kategorisieren><en> When you have F-Secure SAFE installed, the website safety ratings categorize the search results and give an indication how safe or potentially...
<G-vec00916-002-s084><categorize.kategorisieren><de> Wenn Sie F-Secure SAFE installiert haben, werden durch die Sicherheitsbewertung einer Website die Suchergebnisse kategorisiert und es wird darauf...
<G-vec00916-002-s085><categorize.kategorisieren><en> Just as with a personal first impression, website visitors digitally categorize you within a few seconds.
<G-vec00916-002-s085><categorize.kategorisieren><de> Genau wie beim persönlichen ersten Eindruck, kategorisiert der User Sie auch digital innerhalb weniger Sekunden.
<G-vec00916-002-s100><categorize.kategorisieren><en> Together with the metadata provided by DK Pro, these algorithms enabled us to detect and categorize 40% of all the acquired Wikipedia content by Person, Place, or Organization.
<G-vec00916-002-s100><categorize.kategorisieren><de> Zusammen mit den Metadaten, die wir durch DK Pro gewonnen haben, konnten diese Algorithmen 40 % des gesamten eingeholten Wikipedia-Contents nach Person, Ort, oderOrganisation erkennen und kategorisieren.
<G-vec00916-002-s111><categorize.kategorisieren><en> Discover how to categorize your remarks, paragraphs, styles and assign tasks to people.
<G-vec00916-002-s111><categorize.kategorisieren><de> Erfahren Sie, wie Sie Ihre Bemerkungen, Absätze und Stile kategorisieren und wie Sie Personen bestimmte Aufgaben zuweisen.
<G-vec00916-002-s115><categorize.kategorisieren><en> MAXQDA 2018 also expands on the advanced processing of partially standardized and open surveys – in the form of the new Categorize and Evaluate Survey Responses function.
<G-vec00916-002-s115><categorize.kategorisieren><de> Die wegweisende Prozessierung teilstandardisierter und offener Umfragen wird mit MAXQDA 2018 nun ebenfalls noch weiter ausgebaut – in Form der Funktion „Survey-Antworten kategorisieren und auswerten“.
<G-vec00916-002-s117><categorize.kategorisieren><en> We use retargeting on our website in order to categorize website users and assign them to certain user groups.
<G-vec00916-002-s117><categorize.kategorisieren><de> Wir verwenden auf unserer Webseite Retargeting, um Webseiten-Besucher in Nutzergruppen zu kategorisieren.
<G-vec00916-002-s120><categorize.kategorisieren><en> If you are not sure where to categorize your content, you can always click the globe representing “other.”
<G-vec00916-002-s120><categorize.kategorisieren><de> Wenn Du Dir nicht sicher bist, wie Du Deinen Inhalt kategorisieren solltest, klick’ auf die Weltkugel, die für ‘Sonstiges’ steht.
<G-vec00916-002-s093><categorize.klassifizieren><en> Search Philosophy If you want to categorize my eating habits, it would probably fall somewhere between vegetarian and „everything in moderation“.
<G-vec00916-002-s093><categorize.klassifizieren><de> Search Philosophie Wenn man meine Ernährung klassifizieren wollte, würde man wahrscheinlich irgendwo zwischen wollwertig und “alles in Maßen” landen.
<G-vec00916-002-s094><categorize.klassifizieren><en> Considering the present trends, let us categorize any case diameters more than 42mm as an oversize timepiece.
<G-vec00916-002-s094><categorize.klassifizieren><de> Lassen Sie uns angesichts der aktuellen Trends jede Armbanduhr mit einem Gehäusedurchmesser von mehr als 42 mm als große Uhr klassifizieren.
<G-vec00916-002-s095><categorize.klassifizieren><en> Site24x7 vCenter monitoring can discover your entire VMware virtual infrastructure through the vCenter server allowing you to discover virtual resources and categorize them into components such as Data Center, Cluster, ESX/ESXi hosts and more.
<G-vec00916-002-s095><categorize.klassifizieren><de> Mit der Site24x7-vCenter-Überwachung können Sie Ihre gesamte virtuelle VMware-Infrastruktur über die vCenter-Server aufdecken, virtuelle Ressourcen erschließen und diese in Komponenten wie Datencentern, Clustern, ESX/ESXi-Hosts und mehr klassifizieren.
<G-vec00916-002-s096><categorize.klassifizieren><en> If they don’t have one, categorize the transaction as a B2C.
<G-vec00916-002-s096><categorize.klassifizieren><de> Wenn Ihr Kunde keine hat, klassifizieren Sie die Transaktion als B2C.
<G-vec00916-002-s097><categorize.klassifizieren><en> This realization prompted the decision to invest in a Web Inspection System (WIS) from ISRA VISION - a system that provides the ability to identify and categorize quality relevant defects with a high degree of reliability.
<G-vec00916-002-s097><categorize.klassifizieren><de> Die Entscheidung fiel für ein Web Inspektionssystem (WIS) von ISRA VISION PARSYTEC, welches mit hoher Zuverlässigkeit qualitätsrelevante Fehler identifiziert und klassifiziert.
<G-vec00916-002-s098><categorize.klassifizieren><en> • The user interface enables you to edit, sort, search, categorize and eliminate duplicates easily.
<G-vec00916-002-s098><categorize.klassifizieren><de> • Über die Benutzerschnittstelle können doppelte Kontakte ganz leicht bearbeitet, sortiert, gesucht, klassifiziert oder gelöscht werden.
<G-vec00916-002-s102><categorize.ordnen><en> Seven industry experts categorize the ski touring trend for ISPO.com.
<G-vec00916-002-s102><categorize.ordnen><de> Teil 1 der Skitouren-Serie: Sieben Branchenexperten ordnen für ISPO.com den Skitouren-Trend ein.
<G-vec00916-002-s103><categorize.ordnen><en> There is plenty of software available that lets you categorize and manage pieces of art, photos or other objects.
<G-vec00916-002-s103><categorize.ordnen><de> Es gibt viele Programme, mit denen Sie Kunstgegenstände, Fotos oder andere Objekte ordnen und verwalten können.
<G-vec00916-002-s104><categorize.ordnen><en> In recent years, marine scientists have tried to identify and categorize the various aspects responsible for the mounting adverse impacts on our oceans.
<G-vec00916-002-s104><categorize.ordnen><de> Meereswissenschaftler haben in den vergangenen Jahren versucht, die verschiedenen Aspekte, auf die die zunehmende Belastung der Meere zurückzuführen ist, zu identifizieren und zu ordnen.
