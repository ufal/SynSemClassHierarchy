<G-vec00628-002-s063><cure.behandeln><en> “Our mission is to perform innovative research and translate discoveries to prevent, diagnose, and cure kidney diseases”, said Professor Ray Harris, director of the Vanderbilt Center for Kidney Disease at Vanderbilt University Medical Center.
<G-vec00628-002-s063><cure.behandeln><de> „Unsere Mission ist die Durchführung innovativer Forschung und die Umsetzung wissenschaftlicher Entdeckungen, um Nierenerkrankungen vorzubeugen, zu diagnostizieren und auch zu behandeln“, sagte Professor Ray Harris, Direktor des Vanderbilt Center for Kidney Disease am VUMC.
<G-vec00628-002-s064><cure.behandeln><en> Already many thousand years ago those have been effectively used to cure diseases and improve the human well-being.
<G-vec00628-002-s064><cure.behandeln><de> Schon vor vielen Jahrtausenden wurden diese wirksam eingesetzt, um Krankheiten zu behandeln und das menschliche Wohlbefinden zu steigern.
<G-vec00628-002-s065><cure.behandeln><en> The doctor said, "There is no operation available to cure this disease.
<G-vec00628-002-s065><cure.behandeln><de> Der Arzt sagte: „Es besteht keine operative Möglichkeit, um diese Krankheit zu behandeln.
<G-vec00628-002-s066><cure.behandeln><en> It is also a thyroid stimulator which aids cure conditions such as weight problems.
<G-vec00628-002-s066><cure.behandeln><de> Es ist zusätzlich eine Schilddrüsen-Stimulator, die zu behandeln Erkrankungen wie Übergewicht hilft.
<G-vec00628-002-s067><cure.behandeln><en> Alternative Action for African Development (AGADA) and Church World Service tested the ability of Moringa leaf powder to prevent or cure malnutrition in pregnant or breast-feeding women and their children in southwestern Senegal.
<G-vec00628-002-s067><cure.behandeln><de> Das Programm "Alternative Maßnahmen für die Entwicklung Afrikas (auf englich: AGADA) und der Church World Service untersuchten die Fähigkeit von Moringa oleifera-Blattpulver, der Unterernährung von schwangeren oder stillenden Frauen und ihren Kindern im Südwesten von Senegal vorzubeugen und zu behandeln.
<G-vec00628-002-s068><cure.behandeln><en> Many causes of hearing loss have no cure.
<G-vec00628-002-s068><cure.behandeln><de> Viele Ursachen für Schwerhörigkeit lassen sich nicht behandeln.
<G-vec00628-002-s069><cure.behandeln><en> By now his body and mind were so in tune with his work that he would suffer the emotional state that he needed to cure and try plants and flowers until he found the one that would help him.
<G-vec00628-002-s069><cure.behandeln><de> Er erlitt die Gefühlszustände selbst, die er behandeln wollte und probierte verschiedene Pflanzen und Blüten aus, bis er die eine Pflanze gefunden hatte, die ihm helfen konnte.
<G-vec00628-002-s070><cure.behandeln><en> Prevention is better than cure, so be careful with your beautiful new item of Maes & Hills.
<G-vec00628-002-s070><cure.behandeln><de> Vorbeugung ist jedoch immer besser als eine später notwendige Behandlung, deshalb empfehlen wir Ihnen, Ihre schöne Tasche von Maes & Hills immer pfleglich zu behandeln.
<G-vec00628-002-s071><cure.behandeln><en> For cure allergy the needed dose is 25 mg before going to bed.
<G-vec00628-002-s071><cure.behandeln><de> Um Allergie zu behandeln, ist die empfohlene Dosis 25 Mg vor dem Schlafen.
<G-vec00628-002-s072><cure.behandeln><en> To start with, this steroid is made use of to cure asthmatic steed.
<G-vec00628-002-s072><cure.behandeln><de> Zu Beginn wird dieses Steroid Stacks verwendet, um Asthma – Pferd zu behandeln.
<G-vec00628-002-s073><cure.behandeln><en> Treating gum disease with homemade remedies is possible, and can help to cure various gum problems, such as gingivitis, periodontal disease, and several other problems that need to be taken seriously.
<G-vec00628-002-s073><cure.behandeln><de> Entzündetes Zahnfleisch mit Hausmitteln zu behandeln, ist möglich, und kann dir helfen, verschiedene Zahnfleischprobleme wie Gingivitis, Periodontitis und verschiedene andere Probleme zu behandeln, die man ernst nehmen sollte.
<G-vec00628-002-s074><cure.behandeln><en> It is done in cases where it is not possible to cure a tooth and maintain or restore it on its root.
<G-vec00628-002-s074><cure.behandeln><de> Sie erfolgt dann, wenn es nicht möglich ist, den Zahn zu behandeln und zu erhalten oder den Zahn auf der Basis seiner eigenen Wurzel aufzubauen.
<G-vec00628-002-s126><cure.heilen><en> Identify the disease with the help of pictures and find out how to cure the disease.
<G-vec00628-002-s126><cure.heilen><de> Identifizieren Sie die Krankheit an Hand von Bildern und erfahren Sie, wie die Krankheit geheilt wird.
<G-vec00628-002-s127><cure.heilen><en> 51:9 “We would have cured Babylon, but there is no cure.
<G-vec00628-002-s127><cure.heilen><de> 9 Wir wollten Babel heilen; aber es wollte nicht geheilt werden.
<G-vec00628-002-s128><cure.heilen><en> The palliative amelioration that at first ensues from the treatment is far from being crowned by a rapid and perfect cure; on the contrary, the weak and ailing state of the parts thus treated (frequently also of the whole body), which always remains, sufficiently shows the error that is committed in attributing the local inflammation to a local plethora, and how sad are the consequences of such abstractions of blood; whereas this purely dynamic, apparently local, inflammatory irritation, can be rapidly and permanently removed by an equally small dose of aconite, or, according to circumstances, of belladonna, and the whole disease annihilated and cured, without such unjustifiable shedding of blood.
<G-vec00628-002-s128><cure.heilen><de> Die anfänglich davon erfo]gende, palliative Erleichterung wird durch schnellen und vollkommenen Heil-Erfolg keineswegs gekrönt, sondern die stets zurückbleibende Schwäche und Kränklichkeit des so behandelten Theiles (auch oft des übrigen Körpers) zeigt genugsam, wie fälschlich man die örtliche Entzündung in einer örtlichen Plethora suchte und wie traurig die Folgen solcher Blutentziehungen sind, - während dieser bloß dynamische, örtlich scheinende Entzündungs-Reiz durch eine gleich kleine Gabe Aconit, oder, nach den Umständen, von Belladonna schnell und dauerhaft getilgt und das ganze Uebel, ohne solch unmotivirtes Blut-Vergießen, gehoben und geheilt werden kann.
<G-vec00628-002-s129><cure.heilen><en> On their honeymoon trip he takes her to Australia to see Isaac of Uluru, a faith healer, hoping that he will cure her cancer.
<G-vec00628-002-s129><cure.heilen><de> In den Flitterwochen bringt Bernard Rose in der Hoffnung, dass ihre Krankheit vom Geisterheiler Isaac von Uluru geheilt wird, nach Australien.
<G-vec00628-002-s130><cure.heilen><en> You will notice improvement within a week or two, but depending on the degree of phimosis you should allow several more weeks for a complete cure.
<G-vec00628-002-s130><cure.heilen><de> Sie werden eine Verbesserung innerhalb von einer oder zwei Wochen feststellen, aber abhängig vom Grad der Phimose sollten Sie der Behandlung einige Wochen einräumen, um vollständig geheilt zu werden.
<G-vec00628-002-s131><cure.heilen><en> Since the glioblastoma is a very aggressive tumour, researchers do not expect to cure the patients but hope to increase survival.
<G-vec00628-002-s131><cure.heilen><de> Da das Glioblastom ein sehr aggressiver Tumor ist, erwarten die Forscher nicht, dass die Patienten geheilt werden, sie hoffen jedoch, die Überlebenszeit zu verlängern.
<G-vec00628-002-s132><cure.heilen><en> There is still no cure for this neurodegenerative disorder and with existing therapies, one can only hope to slow down the decline of cognitive function.
<G-vec00628-002-s132><cure.heilen><de> Nach wie vor kann diese neurodegenerative Erkrankung nicht geheilt werden und die bestehenden Therapien verlangsamen höchstens der Verlust der kognitiven Fähigkeiten.
<G-vec00628-002-s133><cure.heilen><en> To date, there is no cure for MS; however, this does not automatically mean that MS sufferers must use a wheelchair.
<G-vec00628-002-s133><cure.heilen><de> Bis heute kann die Multiple Sklerose nicht geheilt werden; das heißt aber auch nicht unbedingt, dass ein MS-Betroffener im Rollstuhl sitzen muss.
<G-vec00628-002-s134><cure.heilen><en> The early pioneers of bio-resonance were not discouraged by these complications and made the bold approximation that if they sampled this electric noise at any point on the body and then fed it through a simple electronic phase shifter that would effectively invert the signal and then feed it back to the client, this might cure his disease.
<G-vec00628-002-s134><cure.heilen><de> Die frühen Pioniere der Bioresonanz ließen sich durch diese Komplikationen nicht entmutigen und zogen den gewagten Schluss, dass eine Krankheit eventuell geheilt werden könne, wenn dieses elektrische Rauschen an einer beliebigen Körperstelle festgestellt und dann durch einen einfachen Phasenverschieber geleitet werden könnte, der das Signal umkehrt, um es dann an den Patienten zurückzuleiten.
<G-vec00628-002-s135><cure.heilen><en> Cystic fibrosis is a rare, life-threatening genetic disease for which there is no cure.
<G-vec00628-002-s135><cure.heilen><de> Die Mukoviszidose ist eine seltene, die Lebenserwartung senkende Erbkrankheit, die nicht geheilt werden kann.
<G-vec00628-002-s136><cure.heilen><en> In most cases, viral infections are not difficult to treat and naturally cure themselves in 1 or 2 weeks.
<G-vec00628-002-s136><cure.heilen><de> Virusinfektionen sind generell schwer zu behandeln und in den meisten Fällen werden sie durch unser Immunsystem selbst innerhalb von 1 bis 2 Wochen geheilt.
<G-vec00628-002-s137><cure.heilen><en> If you only treat the physical cause (medicine), it does not cure the health problem in a sustainable way.
<G-vec00628-002-s137><cure.heilen><de> Wenn du nur die physische Ursache (Medizin) behandelst, wird das Gesundheitsproblem nicht auf nachhaltige Weise geheilt.
<G-vec00628-002-s138><cure.heilen><en> LE: Bob, tell us about your low-cost technology that allows us to cure diseases like AIDS and cancer.
<G-vec00628-002-s138><cure.heilen><de> LE: Bob, erzählen Sie uns über ihre preisgünstige Technologie, mit welcher Krankheiten wie AIDS und Krebs geheilt werden können.
<G-vec00628-002-s139><cure.heilen><en> I am a veteran doctor so I know that medications could never cure the numerous illnesses I had in the past.
<G-vec00628-002-s139><cure.heilen><de> Ich bin eine alte Ärztin und weiß, dass zahlreiche Krankheiten, die ich vorher hatte, mit Medikamenten nicht geheilt werden können.
<G-vec00628-002-s140><cure.heilen><en> For some patients, this treatment will cure incontinence completely..
<G-vec00628-002-s140><cure.heilen><de> Bei einigen Patienten wird die Inkontinenz mit dieser Behandlung vollständig geheilt..
<G-vec00628-002-s141><cure.heilen><en> Resistance has been fuelled by the widespread misuse of antibiotics -- such as using them to treat viral infections like coughs and colds - which they are not able to cure.
<G-vec00628-002-s141><cure.heilen><de> Die Entstehung von Resistenzen wurde durch die weit verbreitete unsachgemäße Verwendung von Antibiotika angeheizt – beispielsweise durch den Einsatz von Antibiotika bei der Behandlung von Virusinfektionen wie Husten und Erkältungskrankheiten, die mit Antibiotika aber nicht geheilt werden können.
<G-vec00628-002-s142><cure.heilen><en> There is currently no cure for fibromyalgia, and treatment generally just consists of treatment management with certain medications (such as antidepressants, anti-seizure medication, opioids, and others), and some therapies (cognitive behavioural therapy, mind-body therapy, and exercise).
<G-vec00628-002-s142><cure.heilen><de> Fibromyalgie kann derzeit nicht geheilt werden und die Behandlung besteht in der Regel nur aus der Behandlung mit bestimmten Medikamenten (wie Antidepressiva, Antikonvulsiva, Opioiden und anderen) und einigen Therapien (kognitiver Verhaltenstherapie, Geist-Körper-Therapie und Übungen).
<G-vec00628-002-s143><cure.heilen><en> The miracle had occurred in 1976 with the sudden cure of a Carmelite nun suffering from terminal cancer.
<G-vec00628-002-s143><cure.heilen><de> Der Vorfall ereignete sich 1976 an einer Ordensfrau, die an Krebs im Endstadium litt und plötzlich geheilt war.
<G-vec00628-002-s144><cure.heilen><en> However: three out of four children and adolescents with cancer can be given a longterm cure from cancer.
<G-vec00628-002-s144><cure.heilen><de> Dennoch: Drei von vier Kindern und Jugendlichen mit Krebs können heute dank effizienter Methoden nachhaltig geheilt werden.
<G-vec00628-002-s157><cure.heilen><en> And I cure the blind and the leper, and I give life to the dead - by permission of Allah.
<G-vec00628-002-s157><cure.heilen><de> Und ich heile den Blinden und Aussätzigen, und ich rufe mit Erlaubnis Allâhs die Toten wieder ins Leben.
<G-vec00628-002-s158><cure.heilen><en> 4:47 Having heard that Jesus had come from Judaea to Galilee, he came to Him and begged Him to go down and cure his son; for he was at the point of death.
<G-vec00628-002-s158><cure.heilen><de> 4:47 Als dieser gehört hatte, daß Jesus aus Judäa nach Galiläa gekommen sei, ging er zu ihm hin und bat ihn, daß er herabkomme und seinen Sohn heile; denn er lag im Sterben.
<G-vec00628-002-s159><cure.heilen><en> I recovered and today I cure others as well.
<G-vec00628-002-s159><cure.heilen><de> Ich bin gesund geworden, und heute heile ich andere auch.
<G-vec00628-002-s160><cure.heilen><en> I said, “Alright, it doesn’t matter, I’ll cure this child, first.” They said, “No, Mother, but your plane!”
<G-vec00628-002-s160><cure.heilen><de> Als Ich das Kind sah, sagte Ich: „ In Ordnung, das spielt keine Rolle, Ich heile zuerst dieses Kind.“ Sie bestürmten Mich: „Nein, Mutter, Dein Flugzeug!“.
<G-vec00628-002-s161><cure.heilen><en> Find the Rose of Life to cure your father's illness and save an...
<G-vec00628-002-s161><cure.heilen><de> Finde die Rose des Lebens - heile die Krankheit deines Vat...
<G-vec00628-002-s162><cure.heilen><en> Cure all cute animals and follow the vaccination schedule.
<G-vec00628-002-s162><cure.heilen><de> Heile alle niedlichen Tierchen und impfe sie.
<G-vec00628-002-s163><cure.heilen><en> SCT has been used successfully for the past 80 years as treatment of many diseases where modern medicine cannot cure.
<G-vec00628-002-s163><cure.heilen><de> SCT wurde in den letzten 80 Jahren erfolgreich zur Behandlung vieler Krankheiten eingesetzt, bei denen moderne Medizin nicht heilen kann.
<G-vec00628-002-s164><cure.heilen><en> The confrontation with death, he was the opponent to life and as one of our greatest fears see us before this will cure anxiety.
<G-vec00628-002-s164><cure.heilen><de> Die Konfrontation mit dem Tod, den er als Gegenspieler zum Leben und als eine unserer größten Ängste sieht, soll uns vor dieser Angst heilen.
<G-vec00628-002-s165><cure.heilen><en> Our Oil consists of a formulation containing purely natural ingredients blended together in a specific proportion to fight and cure Vitiligo permanently.
<G-vec00628-002-s165><cure.heilen><de> Unser Öl besteht aus einer Formulierung, die rein natürlichen Zutaten miteinander vermischt in einem bestimmten Verhältnis zu bekämpfen und zu heilen Vitiligo dauerhaft.
<G-vec00628-002-s166><cure.heilen><en> On the one hand, it is necessary to cure the expectant mother to the end, so as not to infect during childbirth.
<G-vec00628-002-s166><cure.heilen><de> Auf der einen Seite ist es notwendig, die werdende Mutter bis zum Ende zu heilen, um während der Geburt nicht zu infizieren.
<G-vec00628-002-s167><cure.heilen><en> twelve together, and gave them power and authority overall demons, and to cure diseases.
<G-vec00628-002-s167><cure.heilen><de> Lk 9,1 Er forderte aber die Zwölfe zusammen und gab ihnen Gewalt und Macht über alle Teufel und daß sie Seuchen heilen konnten.
<G-vec00628-002-s168><cure.heilen><en> Completely cure the disease can not be.
<G-vec00628-002-s168><cure.heilen><de> Ganz zu heilen kann die Krankheit nicht sein.
<G-vec00628-002-s169><cure.heilen><en> “I want to help cure people to make use of my education.
<G-vec00628-002-s169><cure.heilen><de> “Ich möchte meine Ausbildung einsetzen, um Menschen zu heilen.
<G-vec00628-002-s170><cure.heilen><en> PharmaFirst products are food supplements and are not intended to diagnose, treat, cure or prevent any disease.
<G-vec00628-002-s170><cure.heilen><de> Dieses Produkt ist nicht dahingehend konzipiert, zu diagnostizieren, zu behandeln, zu heilen oder irgendeiner Krankheit vorzubeugen.
<G-vec00628-002-s171><cure.heilen><en> Even when I address it this way, some people still want me to cure their illnesses.
<G-vec00628-002-s171><cure.heilen><de> Obwohl ich es so klar erklärt habe, gibt es dennoch Leute, die mich darum bitten, ihre Krankheiten zu heilen.
<G-vec00628-002-s172><cure.heilen><en> “We had focused our attention on the presence of glyphosate in food, but did not think the products we use in all hospitals and health centers in the country to cure patients are contaminated with a carcinogenic product.
<G-vec00628-002-s172><cure.heilen><de> "Wir hatten unsere Aufmerksamkeit auf das mögliche Vorhandensein von Glyphosat im Essen konzentriert, dachten aber nicht, dass die Produkte, die wir in allen Krankenhäusern und Gesundheitszentren im Land tagtäglich einsetzen, um Patienten zu heilen, mit einem krebserzeugenden Produkt kontaminiert sein könnten.
<G-vec00628-002-s173><cure.heilen><en> As she shares the same blood as her father Klaus, her blood could presumably cure a werewolf bite.
<G-vec00628-002-s173><cure.heilen><de> Da sie das gleiche Blut wie ihr Vater besitzt, kann Hope wahrscheinlich einen Werwolfsbiss heilen.
<G-vec00628-002-s174><cure.heilen><en> 2 They watched him to see whether he would cure him on the sabbath, so that they might accuse him.
<G-vec00628-002-s174><cure.heilen><de> Und sie gaben Acht, ob Jesus ihn am Sabbat heilen werde; sie suchten nämlich einen Grund zur Anklage gegen ihn.
<G-vec00628-002-s175><cure.heilen><en> Also, herbal medicines are suggested to cure the imbalance and the disease.
<G-vec00628-002-s175><cure.heilen><de> Auch Kräutermedizin wird angeboten, um das Ungleichgewicht und die Krankheit zu heilen.
<G-vec00628-002-s176><cure.heilen><en> This temple of Sugamo district in Tokyo is home to the Jizo Bodhisattva whose healing water is said to cure all ills.
<G-vec00628-002-s176><cure.heilen><de> Dieser Tempel im Viertel Sugamo in Tokio ist die Heimat des Jizo Bodhisattva, dessen Wasser angeblich alle Krankheiten zu heilen vermag.
<G-vec00628-002-s177><cure.heilen><en> Neither of these two systems of capitalist political economy can cure the evils of the capitalist mode of production.
<G-vec00628-002-s177><cure.heilen><de> Keines der beiden Systeme der kapitalistischen Wirtschaftspolitik kann die Übel der kapitalistischen Produktionsweise heilen.
<G-vec00628-002-s178><cure.heilen><en> Medicinal mushrooms do not cure or heal directly, but they help the body to perform at its best.
<G-vec00628-002-s178><cure.heilen><de> Extrakte medizinischer Pilze heilen nicht, helfen aber unserem Körper, sich selbst zu heilen und gesund zu bleiben.
<G-vec00628-002-s179><cure.heilen><en> Overal Game Rating Poor Mel has every ailment in the book, and you`re the only one who can cure him!
<G-vec00628-002-s179><cure.heilen><de> Der arme Mel hat alle möglichen Krankheiten gleichzeitig und Du bist in diesem 3-Gewinnt-Spiel der Einzige, der ihn heilen kann.
<G-vec00628-002-s180><cure.heilen><en> It is very important that all the carotid teeth cure.
<G-vec00628-002-s180><cure.heilen><de> Es ist sehr wichtig, dass alle Karotiszähne heilen.
<G-vec00628-002-s181><cure.heilen><en> Whether this is enough to cure a disease remains to be demonstrated.
<G-vec00628-002-s181><cure.heilen><de> Ob das ausreicht, um eine Krankheit zu heilen, muss sich noch zeigen.
<G-vec00628-002-s205><cure.heilen><en> The Alchemist searches for elixir that can cure the illness of people.
<G-vec00628-002-s205><cure.heilen><de> Der Alchemist sucht nach einem Elixier, welches die Krankheiten der Menschheit heilt.
<G-vec00628-002-s206><cure.heilen><en> “Only salvation can be said to cure.
<G-vec00628-002-s206><cure.heilen><de> Nur von der Erlösung kann man sagen, dass sie heilt.
<G-vec00628-002-s207><cure.heilen><en> Ancient Theme The Alchemist searches for elixir that can cure the illness of people.
<G-vec00628-002-s207><cure.heilen><de> Antikes Thema Der Alchemist sucht nach einem Elixier, welches die Krankheiten der Menschheit heilt.
<G-vec00628-002-s208><cure.heilen><en> Whether it is a simple light spell to see where you're going in the dark, a fireball to blast a troll, or a cure wounds spell, use of magic can often be the turning point in an engagement.
<G-vec00628-002-s208><cure.heilen><de> Ein Lichtstrahl weist dir den Weg im Dunklen, ein Feuerball vernichtet einen Troll, ein Zauberspruch heilt eine Wunde - Magie kann sogar den Ausgang eines Kampfes beeinflussen.
<G-vec00628-002-s209><cure.heilen><en> This medication does not cure this condition, but it helps decrease symptoms such as fever, stomach pain, diarrhea, and rectal bleeding.
<G-vec00628-002-s209><cure.heilen><de> Dieses Medikament heilt diesen Zustand nicht, aber es hilft Symptome wie Fieber, Bauchschmerzen, Durchfall und rektale Blutungen zu verringern.
<G-vec00628-002-s210><cure.heilen><en> Water prevents and helps to cure back pain.
<G-vec00628-002-s210><cure.heilen><de> Wassertrinken verhindert und heilt Kreuzschmerzen.
<G-vec00628-002-s211><cure.heilen><en> So, wearing the stone has a positive effect on blood pressure, cure blood vessels and purifies the blood.
<G-vec00628-002-s211><cure.heilen><de> So, das tragen des Steines wirkt sich positiv auf den Blutdruck, heilt die Blutgefäße und reinigt das Blut.
<G-vec00628-002-s212><cure.heilen><en> Water prevents and helps to cure angina.
<G-vec00628-002-s212><cure.heilen><de> Wassertrinken verhindert und heilt Angina pectoris.
<G-vec00628-002-s213><cure.heilen><en> The water is believed to be holy and able to cure diseases.
<G-vec00628-002-s213><cure.heilen><de> Man glaubt, dass das Wasser heilig ist und Krankheiten heilt.
<G-vec00628-002-s251><cure.helfen><en> The product is a combination of all critical micronutrients that are traditionally believed to regulate the immune... cure or treatment have been intentionally withheld in accordance with your local laws.
<G-vec00628-002-s251><cure.helfen><de> Das Produkt ist eine Kombination aus allen kritischen Mikronährstoffen, von denen angenommen wird, dass sie das Immunsystem regulieren, jedes Organ ernähren und dabei helfen, alle Körpermechanismen in Schiffsform zu halten.
<G-vec00628-002-s252><cure.helfen><en> These hold the possibility for treatment with less side effects or to cure those children whose affection remains incurable up until now.
<G-vec00628-002-s252><cure.helfen><de> Sie bergen die Chance für Therapien mit geringen Nebenwirkungen oder auch dafür, jenen Kindern zu helfen, deren Krebs-Erkrankungen bislang als unheilbar galten.
<G-vec00628-002-s253><cure.helfen><en> Although it is a seemingly efficient choice to use guarantee programs as policy choice because most countries could directly use the institutional framework of an existing guarantee program, it is not self-evident whether state guarantee programs are the right medicine to cure distressed SMEs.
<G-vec00628-002-s253><cure.helfen><de> Obwohl Garantieprogramme, aufgrund der direkten Anwendbarkeit eines bereits bestehenden institutionellen Rahmens in den meisten Ländern, eine effiziente Wahl zu sein scheinen, ist es nicht offensichtlich, ob staatliche Garantieprogramme auch das richtige Mittel sind, um in Not geratenen KMU zu helfen.
<G-vec00628-002-s254><cure.helfen><en> Of course they all come from broken homes, but there's nothing a a few years of psychiatric treatment and, if necessary, a little exorcism won't cure.
<G-vec00628-002-s254><cure.helfen><de> Klar haben all die Kleinen Ihr eigenes Problem aber wir sind uns sicher, einige Jahre psychologische Unterstützung und nötigenfalls ein wenig Exorzismus werden da helfen.
<G-vec00628-002-s307><cure.kurieren><en> And if you want to cure greed, you change the greed gene, right?
<G-vec00628-002-s307><cure.kurieren><de> Und wenn Sie die Gier kurieren wollen, dann müssten Sie eben das Gier-Gen verändern.
<G-vec00628-002-s308><cure.kurieren><en> We cannot cure burnout, however, we can offer you an oasis of peace and relaxation in the heart of a mountain world.
<G-vec00628-002-s308><cure.kurieren><de> Wir können Burn Out Anzeichen zwar nicht kurieren, aber wir können Ihnen eine Oase der Ruhe und Entspannung, im Herzen der Bergwelt, bieten.
<G-vec00628-002-s309><cure.kurieren><en> She and Junta spend some time together trying to help cure each other of their problems.
<G-vec00628-002-s309><cure.kurieren><de> Sie und Junta verbringen einige Zeit zusammen um sich gegenseitig zu kurieren.
<G-vec00628-002-s310><cure.kurieren><en> A lemon tree in the atrium of the Corinth Museum and cure my sunburn, until I can get back to regular blogging.
<G-vec00628-002-s310><cure.kurieren><de> Ich muss mich erstmal wieder ein bisschen akklimatisieren, mich an den deutschen “Sommer” gewöhnen und meinen fiesen Sonnenbrand kurieren, bis ich mich wieder vollends ins Bloggen stürzen kann.
<G-vec00628-002-s311><cure.kurieren><en> No doctor can cure all cases.
<G-vec00628-002-s311><cure.kurieren><de> Kein Arzt vermag alle Fälle zu kurieren.
<G-vec00628-002-s312><cure.kurieren><en> The approach involves a strong preventative element – not only is prevention better than cure, prevention of further disturbance does cure (or more accurately, ‘allows the body to cure’) existing complaints.
<G-vec00628-002-s312><cure.kurieren><de> Die Vorgehensweise beinhaltet ein starkes präventives Element – nicht nur weil Vorsorge besser als Heilung ist, Prävention weitere Störungen und bestehende Beschwerden kuriert (oder genauer „es dem Körper erlaubt, diese zu kurieren“).
<G-vec00628-002-s313><cure.kurieren><en> If you want to maximize the cutting ability and ability to cure, the fat deposits should not exceed 10-13%.
<G-vec00628-002-s313><cure.kurieren><de> Wenn Sie die Ausschnittfähigkeit und Fähigkeit maximieren möchten zu kurieren, sollten die fetten Ablagerungen 10-13% nicht übersteigen.
<G-vec00628-002-s314><cure.kurieren><en> They cure anyone visiting the design exhibition who has reservations from the very outset: the cult of commodities is after all a clear indication of the ubiquitous withdrawal into the private sphere, of the disintegration of a society into individual interests with which one can tuck up on the sofa in front of the fire.
<G-vec00628-002-s314><cure.kurieren><de> Sie kurieren denjenigen, der schon mit grundsätzlichen Vorbehalten in die Designausstellung geht: Ist doch der Kult der Gebrauchsgegenstände deutliches Kennzeichen für den allenthalben beobachtbaren Rückzug ins Private, für das Zerfallen einer Gesellschaft in Einzelinteressen, mit denen man es sich auf dem heimischen Sofa bequem macht.
<G-vec00628-002-s315><cure.kurieren><en> However, if you're hoping to cure your acne fast it might be better to err on the side of caution and ditch the chocolate.
<G-vec00628-002-s315><cure.kurieren><de> Wenn du allerdings hoffst, deine Akne schnell zu kurieren, kann es vielleicht besser sein, auf Nummer sicher zu gehen und auf Schokolade zu verzichten.
<G-vec00628-002-s316><cure.kurieren><en> 7.0 TERMINATION. This License and the rights granted hereunder will terminate automatically if You fail to comply with terms herein and fail to cure such breach within 30 days of becoming aware of the breach.
<G-vec00628-002-s316><cure.kurieren><de> Diese Lizenz und die Rechte, die hierunter gewährleistet sind, werden automatisch beendet, falls Sie es unterlassen, die genannten Bedingungen zu erfüllen und es misslingt, solch eine Verletzung innerhalb von 30 Tagen nach Bekanntwerden der Verletzung zu kurieren.
<G-vec00628-002-s317><cure.kurieren><en> CieAura products do not diagnose, prevent, heal, treat, or cure any disease or injury.
<G-vec00628-002-s317><cure.kurieren><de> CieAura Produkte sollen keine Krankheit oder Verletzung diagnostizieren, verhindern, behandeln, heilen oder kurieren.
<G-vec00628-002-s318><cure.kurieren><en> There is no “magic food” that will cure or prevent anxiety.
<G-vec00628-002-s318><cure.kurieren><de> Es gibt keine Wundernahrung, die deine Ängste kurieren kann.
<G-vec00628-002-s319><cure.kurieren><en> *Yellow light:Supply energy for skin cells, promote gland effect, assist digestion,cure skin diseases and enhance immunity ability.
<G-vec00628-002-s319><cure.kurieren><de> *Yellow Licht: Liefern Sie Energie für Hautzellen, fördern Sie Drüseneffekt, unterstützen Sie Verdauung, kurieren Sie Hautkrankheiten und erhöhen Sie Immunitätsfähigkeit.
<G-vec00628-002-s320><cure.kurieren><en> Nobody hesitates to go and see a doctor when s/he suffers from long-term headaches or looks for a cure from stomach problems.
<G-vec00628-002-s320><cure.kurieren><de> Kein Mensch zögert, zu einem Arzt zu gehen, wenn er seit längerem Kopfschmerzen hat oder eine schwere Grippe kurieren will.
<G-vec00628-002-s321><cure.kurieren><en> There is nothing that can cure everything.
<G-vec00628-002-s321><cure.kurieren><de> Es gibt nichts, das alles kurieren kann.
<G-vec00628-002-s322><cure.kurieren><en> It is true we can cure, our memories, but not even our perceptions.
<G-vec00628-002-s322><cure.kurieren><de> 0 0 5/5 Zwar können wir unsere Erinnerungen kurieren, jedoch nicht unsere Erkenntnisse.
<G-vec00628-002-s323><cure.kurieren><en> But they usually do not cardinally cure the disease, only stop its progression, they are used as a temporary measure.
<G-vec00628-002-s323><cure.kurieren><de> Aber normalerweise kurieren sie die Krankheit nicht kardinal, sondern stoppen nur ihren Fortschritt, sie werden als vorübergehende Maßnahme benutzt.
<G-vec00628-002-s324><cure.kurieren><en> Bitter is one of the oldest types of tonic, used as a cure for stomach upsets in particular – which is why for many years it was called not simply bitter but ‘stomach bitter’.
<G-vec00628-002-s324><cure.kurieren><de> Magenbitter ist einer der ältesten Tonika und wurde insbesonders zum Kurieren von Übelkeit genutzt – deswegen wurde er viele Jahre lang nicht einfach Bitter, sondern “Magenbitter” genannt.
<G-vec00628-002-s325><cure.kurieren><en> Windows 8.1 addresses some of those issues, but what it doesn't do is cure Microsoft's schizophrenia.
<G-vec00628-002-s325><cure.kurieren><de> Windows 8,1 spricht einige jener Fragen an, aber, was es nicht tut, ist, Microsofts Schizophrenie zu kurieren.
