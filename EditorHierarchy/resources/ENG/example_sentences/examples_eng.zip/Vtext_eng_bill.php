<G-vec00206-002-s019><bill.abrechnen><en> For our work we charge fees, which we bill as proceedings progress or, at the latest, after the mandate has been completed.
<G-vec00206-002-s019><bill.abrechnen><de> Für unsere Tätigkeit entstehen Gebühren, die wir nach Verfahrensfortschritt abrechnen, spätestens aber nach Beendigung des Mandats.
<G-vec00206-002-s020><bill.abrechnen><en> These include plans to reduce the quota of suppliers who bill in Swiss francs.
<G-vec00206-002-s020><bill.abrechnen><de> Dazu gehört die geplante Reduktion des Anteils von Zulieferern, die in Schweizer Franken abrechnen.
<G-vec00206-002-s021><bill.abrechnen><en> Being able to settle the claim and bill the insurer, which means dealing with both the insurance company and the customer.
<G-vec00206-002-s021><bill.abrechnen><de> Den Schadensfall abwickeln und abrechnen können, dass heißt Zusammenarbeit mit der Versicherung und Ihren Kunden.
<G-vec00206-002-s022><bill.abrechnen><en> This way, building management can be certain every fire extinguisher has been inspected and is up to code – and the maintenance provider can bill this service precisely.
<G-vec00206-002-s022><bill.abrechnen><de> So kann der Eigentümer des Gebäudes sicher sein, dass jeder einzelne Feuerlöscher ordnungsgemäß inspiziert wurde – und der Wartungsanbieter die Dienstleistung präzise abrechnen.
<G-vec00206-002-s023><bill.abrechnen><en> The more you’ve accentuated when you bill in the Interchange++ model the bigger this problem will be.
<G-vec00206-002-s023><bill.abrechnen><de> Dieses Problem akzentuiert sich umsomehr, wenn Sie im Modell Interchange++ abrechnen.
<G-vec00206-002-s024><bill.abrechnen><en> With the AirPlus Company Account, you can pay and bill flight tickets, rail tickets, hotel rooms and rental cars through a central account.
<G-vec00206-002-s024><bill.abrechnen><de> Mit dem AirPlus Company Account können Sie Flug- und Bahntickets, Hotelübernachtungen, Reisebürogebühren und Mietwagen über ein zentrales Konto bezahlen und abrechnen.
<G-vec00206-002-s025><bill.abrechnen><en> Your firm will be able to bill more hours and earn higher profits from your work.
<G-vec00206-002-s025><bill.abrechnen><de> Außerdem kann Ihre Firma mehr Stunden abrechnen und höhere Gewinne aus Ihrer Arbeit erzielen.
<G-vec00206-002-s026><bill.abrechnen><en> In the third part of our series, we explain to hotel operators and providers of holiday apartments and condominiums how they can bill their guests for charging their electric cars in a legally compliant way.
<G-vec00206-002-s026><bill.abrechnen><de> Im dritten Teil unserer Serie erklären wir Hotelbetreibern und Anbietern von Ferienwohnungen und -häusern, wie sie das Laden der Elektroautos ihrer Gäste eichrechtskonform abrechnen können.
<G-vec00206-002-s027><bill.abrechnen><en> HotSpot Software is a software for WiFi billing, which helps you control and bill your customers for the Internet usage.
<G-vec00206-002-s027><bill.abrechnen><de> HotSpot Software ist eine Software zur WLAN-Abrechnung, mit der Sie Ihre Kunden für die Internetnutzung kontrollieren und abrechnen können.
<G-vec00206-002-s028><bill.abrechnen><en> However, there are already devices that can record load profiles, bill power at different tariff rates and control consumption loads.
<G-vec00206-002-s028><bill.abrechnen><de> Es gibt aber bereits Geräte, die Lastprofile aufzeichnen, Energie zu unterschiedlichen Tarifen abrechnen und Verbrauchslasten steuern können.
<G-vec00206-002-s328><bill.stellen><en> Financial information that is collected is used to bill the user for products and services.
<G-vec00206-002-s328><bill.stellen><de> Die erfassten Finanzinformationen werden verwendet, um dem Benutzer Produkte und Dienstleistungen in Rechnung zu stellen.
<G-vec00206-002-s329><bill.stellen><en> In this case we are entitled, as we see fit, to dispatch the goods at the expense and risk of the buyer or store the goods at our own discretion at the expense and risk of the buyer, and immediately bill the delivery of the goods.
<G-vec00206-002-s329><bill.stellen><de> In einem solchen Fall sind wir berechtigt, die Ware nach unserer Wahl auf Kosten und Gefahr des Käufers zu versenden oder die Ware nach eigenem Ermessen auf Kosten und Gefahr des Käufers zu lagern und die Warenlieferung sofort in Rechnung zu stellen.
<G-vec00206-002-s330><bill.stellen><en> We use an outside help platform, and a credit card processing company to bill you if you purchase services.
<G-vec00206-002-s330><bill.stellen><de> Wir verwenden eine externe Hilfeplattform und ein Kreditkartenunternehmen, um Ihnen beim Kauf von Dienstleistungen eine Rechnung zu stellen.
<G-vec00206-002-s331><bill.stellen><en> You can bill each customer for storage used, adding another revenue stream over and above the backup service itself.
<G-vec00206-002-s331><bill.stellen><de> Sie können jedem Kunden den in Anspruch genommenen Speicherplatz in Rechnung stellen, was Ihnen eine zusätzliche Einnahmequelle jenseits des eigentlichen Backup-Diensts beschert.
<G-vec00206-002-s332><bill.stellen><en> We use an outside help company, and a credit card processing company to bill you if you purchase services.
<G-vec00206-002-s332><bill.stellen><de> Wir verwenden eine externe Hilfefirma und eine Kreditkartenfirma, um Ihnen eine Rechnung zu stellen, wenn Sie Dienstleistungen kaufen.
<G-vec00206-002-s333><bill.stellen><en> If this is not cancelled 24 hours in advance, I will bill for one hour.
<G-vec00206-002-s333><bill.stellen><de> Wird diese nicht 24 Stunden vorher abgesagt, werde ich eine Stunde in Rechnung stellen.
<G-vec00206-002-s334><bill.stellen><en> If a dispute is upheld, the card issuer’s decision is final and we will bill the total transaction amount + dispute fee (25.00 in the transaction's currency) directly to you.
<G-vec00206-002-s334><bill.stellen><de> Wenn einer Streitigkeit stattgegeben wird, ist die Entscheidung des Kartenherausgebers endgültig, und wir werden Ihnen den Gesamtbetrag der Transaktion + die Dispute Gebühr (25.00 in der Währung der Transaktion) direkt in Rechnung stellen.
<G-vec00206-002-s335><bill.stellen><en> We may hold Data about the numbers and lengths of calls made in order to bill you for your services.
<G-vec00206-002-s335><bill.stellen><de> Wir werden Daten über die Anzahl und Dauer der von Ihnen getätigten Gespräche aufnehmen, um Ihnen die Dienstleistungen in Rechnung zu stellen zu können.
<G-vec00206-002-s336><bill.stellen><en> Interim billings enable you to bill customers immediately for the services you have performed outside the regular billing cycle of the contracts.
<G-vec00206-002-s336><bill.stellen><de> Zwischenabrechnungen bieten Ihnen die Möglichkeit von Ihnen erbrachte Leistungen an Kunden außerhalb des regulären Abrechnungszyklus der Verträge sofort in Rechnung zu stellen.
<G-vec00206-002-s337><bill.stellen><en> We use an outside help platform, and a credit card processing company to bill you if you purchase services.
<G-vec00206-002-s337><bill.stellen><de> Wir verwenden eine externe Supportplattform und ein Unternehmen für die Abwicklung von Kreditkartenzahlungen, um dir eine Rechnung zu stellen, wenn du Services erwirbst.
<G-vec00206-002-s338><bill.stellen><en> If applicable, the property will bill you directly.
<G-vec00206-002-s338><bill.stellen><de> Wenn dies zutreffend ist, wird Ihnen die Unterkunft dies direkt in Rechnung stellen.
<G-vec00206-002-s339><bill.stellen><en> As soon as the amount is definite, Alpine will provide the Traveller with the bill and will pay/transfer any outstanding balance to the Traveller.
<G-vec00206-002-s339><bill.stellen><de> Sobald der Betrag feststeht, wird Alpine dem Reisende die entsprechende Rechnung stellen und ihm den eventuellen Restbetrag auszahlen/überweisen.
<G-vec00206-002-s340><bill.stellen><en> Without prejudice to the foregoing provision, AO can bill the customer for goods, materials and personnel services which were procured specifically for the respective event and which AO cannot employ otherwise.
<G-vec00206-002-s340><bill.stellen><de> Unbeschadet voranstehender Regelung kann AO Waren, Materialien und Personaldienstleistungen, die speziell für die betroffene Veranstaltung angeschafft wurden und die AO nicht anderweitig einsetzen kann, dem Kunden in Rechnung stellen.
<G-vec00206-002-s341><bill.stellen><en> The German health insurance scheme will subsequently bill the domestic health insurance provider for their costs.
<G-vec00206-002-s341><bill.stellen><de> Mögliche Kosten wird die deutsche Krankenversicherung später der heimischen Krankenkasse in Rechnung stellen.
<G-vec00206-002-s342><bill.stellen><en> Logitech may also collect financial information to bill you for products and services that you purchased online.
<G-vec00206-002-s342><bill.stellen><de> Sie werden mglicherweise auch nach bestimmten Bankdaten gefragt, um Ihnen die Produkte und Dienstleistungen, die Sie online kaufen, in Rechnung stellen zu knnen.
<G-vec00206-002-s343><bill.stellen><en> If we are unable to rent the suite again, we are sorry to have to bill the reserved time – if you have a travel insurance, please inform us and them.
<G-vec00206-002-s343><bill.stellen><de> Ist eine Weitervermietung nicht möglich, müssen wir die gebuchte Zeit leider in Rechnung stellen - haben Sie eine Reiseversicherung abgeschlossen, können Sie diese einreichen.
<G-vec00206-002-s344><bill.stellen><en> As we bill our services by product and not by contract, you will receive multiple bills.
<G-vec00206-002-s344><bill.stellen><de> Da wir Ihnen die Dienstleistung pro Produkt und nicht pro Vertrag in Rechnung stellen, erhalten Sie auch mehrere Rechnungen.
<G-vec00488-002-s061><bill.berechnen><en> If the period allowed for payment is exceeded, we will bill you for the usual interest and administration charges.
<G-vec00488-002-s061><bill.berechnen><de> Wird das vorher genannte Zahlungsziel überschritten, berechnen wir übliche Zinsen und Mahnspesen.
<G-vec00488-002-s062><bill.berechnen><en> For proofreading we bill half of the price per line.
<G-vec00488-002-s062><bill.berechnen><de> Für das Korrekturlesen berechnen wir den halben Zeilenpreis.
<G-vec00488-002-s063><bill.berechnen><en> For many designers, one of the biggest organization challenges is keeping on top of how many hours you have worked so you know how much to bill clients, and this only gets more complicated when you involve a team or start outsourcing work.
<G-vec00488-002-s063><bill.berechnen><de> Für viele Designer besteht eine der größten Herausforderungen in Sachen Organisation darin, einen Überblick darüber zu behalten, wie viele Stunden sie gearbeitet haben, damit sie wissen, wie viel sie den Kunden berechnen müssen und es wird noch komplizierter, wenn du ein ganzes Team hast oder Arbeit auslagerst.
<G-vec00488-002-s064><bill.berechnen><en> In other areas, we bill for the service per minute.
<G-vec00488-002-s064><bill.berechnen><de> In anderen Gebieten berechnen wir den Service pro Minute.
<G-vec00488-002-s065><bill.berechnen><en> 2. In accordance with the contract, goods that are reported as ready for dispatch must be released immediately; otherwise we are entitled, after a warning, to either dispatch or store at our discretion at the buyer's cost and risk and to bill immediately.
<G-vec00488-002-s065><bill.berechnen><de> 2.Vertragsgemäß versandfertig gemeldete Ware muss unverzüglich abgerufen werden, andernfalls sind wir berechtigt, sie nach Mahnung auf Kosten und Gefahr des Käufers nach unserer Wahl zu versenden oder nach eigenem Ermessen zu lagern und sofort zu berechnen.
<G-vec00488-002-s066><bill.berechnen><en> We reserve the right to bill this effort with 30.00 Euro per requested data set.
<G-vec00488-002-s066><bill.berechnen><de> Wir behalten uns vor, diesen Aufwand mit je 30,00 Euro pro angefragtem Datensatz zu berechnen.
<G-vec00488-002-s067><bill.berechnen><en> We bill you in single currency namely ‘EURO’ for all the domains irrespective of country or domain extension.
<G-vec00488-002-s067><bill.berechnen><de> Wir berechnen Ihnen alle Domains in einer einzigen Währung, nämlich „EURO“ – unabhängig vom Land oder der Domain-Extension.
<G-vec00488-002-s068><bill.berechnen><en> A postage, packaging and insurance fee of 5 Euros is added to your bill if sent within Germany.
<G-vec00488-002-s068><bill.berechnen><de> Für Porto, Verpackung und Versicherung berechnen wir Ihnen bei Sendungen innerhalb Deutschlands einen Kostenanteil von 5,00 EUR.
<G-vec00488-002-s069><bill.berechnen><en> The suppliers bill all applicable taxes to LasVegas.com and LasVegas.com remits such taxes directly to the supplier.
<G-vec00488-002-s069><bill.berechnen><de> Die Anbieter berechnen LasVegas.com alle anwendbaren Steuern, und LasVegas.com überweist diese Steuern direkt an den entsprechenden Anbieter.
<G-vec00488-002-s070><bill.berechnen><en> Skip to main content MeetingSphere One We bill your subscription when you subscribe and will charge your credit card again when your subscription renews.
<G-vec00488-002-s070><bill.berechnen><de> Wir berechnen Ihr Abonnement (die 'Subskription') bei Abschluss und belasten Ihre Kreditkarte erneut, wenn sich das Abonnement um eine weitere Laufzeit verlängert.
<G-vec00488-002-s071><bill.berechnen><en> I guess we can bill this as Update 2.
<G-vec00488-002-s071><bill.berechnen><de> Ich vermute, dass wir dieses als Aktualisierung 2 berechnen können.
<G-vec00488-002-s072><bill.berechnen><en> We always bill the shipping costs at its best - often emerge not until the packing.
<G-vec00488-002-s072><bill.berechnen><de> Für Ihre Sendung berechnen wir grundsätzlich immer die günstigsten Versandkosten - was sich aber oftmals erst beim Verpacken ergibt.
<G-vec00488-002-s073><bill.berechnen><en> If the goods have already been used and show signs of usage, we reserve the right to bill the loss in value and your benefit of the usage of the goods.
<G-vec00488-002-s073><bill.berechnen><de> Wenn die Ware von Ihnen bereits benutzt wurde und Gebrauchsspuren aufweist, behalten wir uns vor, Ihnen den Wert der Nutzung der Ware zu berechnen.
<G-vec00488-002-s074><bill.berechnen><en> We are then required to bill VAT, because the delivery address is located in the Netherlands and we are a Dutch company.
<G-vec00488-002-s074><bill.berechnen><de> Dann sind wir dazu verpflichtet, Mehrwertsteuer zu berechnen, da sich die Lieferadresse sich in den Niederlanden befindet und wir eine niederländische Firma sind.
<G-vec00488-002-s075><bill.berechnen><en> Your financial information (including credit card transactions) is used to bill you for your purchase of products.
<G-vec00488-002-s075><bill.berechnen><de> Ihre finanziellen Informationen (einschließlich Kreditkartentransaktionen) werden verwendet, um Ihnen Ihren Erwerb der Produkte zu berechnen.
<G-vec00488-002-s076><bill.berechnen><en> We recruit experts in the most highly sought-after areas of IT and give you our unique guarantee of success: We will only bill you for our services after you have agreed to fill an open IT position with a candidate supplied by us.
<G-vec00488-002-s076><bill.berechnen><de> In den besonders gefragten IT-Schwerpunktbereichen rekrutieren wir für Sie IT-Experten mit Erfolgsgarantie: Nur wenn Sie sich entscheiden, Ihre IT-Stellen mit einem von uns vorgestellten Kandidaten zu besetzen, berechnen wir Ihnen ein Honorar für unsere Leistung.
<G-vec00488-002-s294><bill.kosten><en> Finally he had become so ill that his former shadow proposed a trip to a health resort offering to foot the bill as well, but on condition that he could act as the master now, and the writer would pretend to be his shadow.
<G-vec00488-002-s294><bill.kosten><de> Schließlich wurde der Mann so krank, dass sein ehemaliger Schatten ihm einen Ausflug zu einem Kurort auf seine Kosten vorschlug, allerdings unter der Bedingung, dass der ehemalige Schatten selbst als Herr auftreten dürfte, während der Schriftsteller so tun musste, als wäre er der Schatten.
<G-vec00488-002-s295><bill.kosten><en> Whether the bill is being paid for by the government or by an individual family, the stated goals of Knospe-ABA is the same – “We help a family work toward therapeutic independence.”
<G-vec00488-002-s295><bill.kosten><de> Unabhängig davon, ob die Kosten übernommen oder von der Familie selbst getragen werden, sind die verankerten Ziele der Knospe-ABA GmbH die gleichen - „Wir unterstützen Familien, damit sie ihr Kind letztendlich ohne intensive Verhaltensintervention fördern können“.
<G-vec00488-002-s296><bill.kosten><en> In the United Kingdom, for example, investment in flood defenses meant that 800,000 properties were protected during last winter’s storms, significantly reducing the bill for response and recovery.
<G-vec00488-002-s296><bill.kosten><de> In Großbritannien beispielsweise gelang es mit Investitionen in den Hochwasserschutz während der Stürme des letzten Winters 800.000 Liegenschaften zu schützen, wodurch auch die Kosten für Rettungs- und Wiederaufbaumaßnahmen deutlich gesenkt wurden.
<G-vec00488-002-s297><bill.kosten><en> The bill for refurbishing room interiors, technology, and staff training will run to some 500 million crowns.
<G-vec00488-002-s297><bill.kosten><de> Die Kosten für die Renovierung der Innenräume, der Technik und der Ausbildung des Personals belaufen sich auf rund 500 Millionen Kronen.
<G-vec00488-002-s298><bill.kosten><en> In all decarbonisation scenarios, the EU bill for fossil fuel imports in 2050 would be substantially lower than today.
<G-vec00488-002-s298><bill.kosten><de> Allen Dekarbonisierungsszenarios zufolge wären die Kosten für den Import fossiler Brennstoffe in die EU im Jahr 2050 deutlich niedriger als heute.
<G-vec00488-002-s299><bill.kosten><en> A few days ago we received a first bill, but evidently we do not know how much it will be in the end.
<G-vec00488-002-s299><bill.kosten><de> Vor ein paar Tagen sandte man uns diese vorläufige Aufstellung, aber wir wissen natürlich noch nicht, wie hoch die endgültigen Kosten sein werden.
<G-vec00488-002-s300><bill.kosten><en> In-patient claims. For treatment taking place in hospital, we can arrange, where possible, to settle your bill directly with the hospital.
<G-vec00488-002-s300><bill.kosten><de> Für Behandlungen, die in einem Krankenhaus stattfinden, können wir eine bargeldlose direkte Erstattung der Kosten mit dem Krankenhaus vereinbaren (wenn möglich).
<G-vec00488-002-s301><bill.kosten><en> We’ll reimburse you for the bill within seven days.
<G-vec00488-002-s301><bill.kosten><de> Wir erstatten Ihnen die Kosten innerhalb von 7 Tagen zurück.
<G-vec00488-002-s302><bill.kosten><en> And Deutsche Telekom will pick up the bill for the retrofitting.
<G-vec00488-002-s302><bill.kosten><de> Die Kosten für die Umrüstung trägt komplett die Telekom.
<G-vec00488-002-s303><bill.kosten><en> To get an estimate of your bill, please refer to our pricing calculator.
<G-vec00488-002-s303><bill.kosten><de> Eine ungefähre Schätzung Ihrer Kosten erhalten Sie mit unserem Preisrechner.
<G-vec00488-002-s304><bill.kosten><en> Who Will Pay the Bill?...
<G-vec00488-002-s304><bill.kosten><de> Wer trägt die Kosten?...
<G-vec00488-002-s305><bill.kosten><en> If your order is mass, you can obtain attractive discount rates on your bill.
<G-vec00488-002-s305><bill.kosten><de> Wenn Ihr Auftrag Masse ist, können Sie attraktive Rabattsätze auf Ihre Kosten erhalten.
<G-vec00488-002-s306><bill.kosten><en> The question of who would have to foot the bill of a Financial Transaction Tax continues to be an explosive issue.
<G-vec00488-002-s306><bill.kosten><de> Die Frage, wer die Kosten einer Finanztransaktionssteuer zu zahlen hätte, sorgt weiterhin für gehörigen Zündstoff.
<G-vec00488-002-s307><bill.kosten><en> PENETRATION TEST In an increasingly interconnected world, cybercriminals scent their opportunity to enrich themselves on your bill and not only inflict financial damage to you.
<G-vec00488-002-s307><bill.kosten><de> Penetrationstest In einer immer stärker vernetzten Welt wittern Cyberkriminelle ihre Chance, sich auf Ihre Kosten zu bereichern und Ihnen nicht nur finanziellen Schaden zuzufügen.
<G-vec00488-002-s308><bill.kosten><en> We must accommodate your request if it is reasonable, specifies the alternative means or location,and continues to permit us to bill and collect payment from you.
<G-vec00488-002-s308><bill.kosten><de> Wir werden Sie vorab über solche Kosten informieren, und Sie können Ihre Anfrage bei dieser Gelegenheit zurückziehen oder ändern.
