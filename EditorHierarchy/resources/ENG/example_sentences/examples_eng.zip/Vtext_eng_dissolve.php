<G-vec00198-002-s031><dissolve.auflösen><en> Tablets should be pressed so that they do not crumble, but not hard enough not to let them dissolve quickly in the stomach.
<G-vec00198-002-s031><dissolve.auflösen><de> Tabletten müssen so hart gepresst sein, dass sie nicht zerbröckeln, aber nicht härter, als dass sie im Magen aufgelöst werden.
<G-vec00198-002-s032><dissolve.auflösen><en> Dissolve 5 ± 0,1 g sucrose (commercial grade) in 95 ± 1 g of water.
<G-vec00198-002-s032><dissolve.auflösen><de> 5 ± 0,1 g Saccharose (handelsübliche Qualität) werden in 95 ± 1 g Wasser aufgelöst.
<G-vec00198-002-s033><dissolve.auflösen><en> It is enough to place the finished print in warm water and the butane-diol vinyl alcohol copolymer (BVOH) will completely dissolve, leaving only the 3D model.
<G-vec00198-002-s033><dissolve.auflösen><de> Den fertigen Druck einfach ins warme Wasser einlegen, und das Copolymer aus Vinylalkohol und Butandiol (BVOH) wird vollständig aufgelöst, sodass nur das 3D-Modell übrig bleibt.
<G-vec00198-002-s034><dissolve.auflösen><en> Yet the person in this dimension has vanished, since the body needs to be cremated or buried and it will eventually decompose and dissolve.
<G-vec00198-002-s034><dissolve.auflösen><de> Aber der Mensch in diesem Raum ist verschwunden, weil der Körper eingeäschert oder unter der Erde begraben werden muss und der Körper verwest und aufgelöst wird.
<G-vec00198-002-s035><dissolve.auflösen><en> Rigid dogmas dissolve and are reanimated with a new rhythm.
<G-vec00198-002-s035><dissolve.auflösen><de> Die starren Dogmen sind aufgelöst und werden mit einem neuen Rhythmus reanimiert.
<G-vec00198-002-s036><dissolve.auflösen><en> Thus there are areas where the surface almost appears opaque, although in other places it seems to dissolve in the changing rays of light as it emits colours.
<G-vec00198-002-s036><dissolve.auflösen><de> So gibt es Bereiche, in denen die Oberfläche fast opak erscheint, während sie an anderer Stelle durch den veränderten Lichteinfall aufgelöst wird und Farben freisetzt.
<G-vec00198-002-s037><dissolve.auflösen><en> The two doctors would then autopsy the victims, after which they would dissolve the bodies and ship the bones to a renowned anthropological institute in Berlin-Dahlem.
<G-vec00198-002-s037><dissolve.auflösen><de> Die beiden Ärzte hätten das Opfer darauf autopsiert, die Leiche anschließend aufgelöst und die Knochen an ein namhaftes anthropologisches Institut in Berlin-Dahlem gesandt.
<G-vec00198-002-s038><dissolve.auflösen><en> Tito, later to be ruler of Yugoslavia, testified long afterwards: ‘In 1938 when I was in Moscow... we were discussing whether to dissolve the Yugoslav Communist Party or not.
<G-vec00198-002-s038><dissolve.auflösen><de> Tito, der spätere Führer Jugoslawiens, bezeugte lange später: „Eine ähnliche Erfahrung hatte ich 1938 in Moskau gemacht, als wir darüber sprachen, ob unsere Kommunistische Partei aufgelöst werden sollte oder nicht.
<G-vec00198-002-s039><dissolve.auflösen><en> 1142 For a just cause, the Roman Pontiff can dissolve a non-consummated marriage between baptized persons or between a baptized party and a non-baptized party at the request of both parties or of one of them, even if the other party is unwilling.
<G-vec00198-002-s039><dissolve.auflösen><de> 1142 — Die nicht vollzogene Ehe zwischen Getauften oder zwischen einem getauften und einem ungetauften Partner kann aus einem gerechten Grund auf Bitten beider Partner oder eines Partners, selbst wenn der andere dem widerstrebt, vom Papst aufgelöst werden.
<G-vec00198-002-s040><dissolve.auflösen><en> Being a temporary application, after the pigments dissolve and fade out, patients can resume their former appearances.
<G-vec00198-002-s040><dissolve.auflösen><de> Als temporäre Anwendung, nachdem sich die Pigmente aufgelöst und verblasst haben, können die Patienten ihr früheres Erscheinungsbild wieder aufnehmen.
<G-vec00198-002-s041><dissolve.auflösen><en> With a regular Yoga Nidra practice these tensions are tackled on all levels and slowly dissolve.
<G-vec00198-002-s041><dissolve.auflösen><de> Durch die regelmäßige Praxis von Yoga Nidra werden diese Spannungen auf allen Ebenen angegangen und aufgelöst.
<G-vec00198-002-s042><dissolve.auflösen><en> Instant drinks - Dissolve in water for a pleasant tasting drink that can deliver large quantities or multiple APIs in a single dose. Lozenges
<G-vec00198-002-s042><dissolve.auflösen><de> Instantgetränke - In Wasser aufgelöst entsteht ein leckeres Getränk, das die Einnahme großer Wirkstoffmengen oder mehrerer Wirkstoffe ermöglicht.
<G-vec00198-002-s043><dissolve.auflösen><en> If there are any human hair styling products left in the hair, the wig shampoo will by itself dissolve them in the following wash.
<G-vec00198-002-s043><dissolve.auflösen><de> Sollten noch Reste von Echthaar-Stylingprodukten im Haar sein, werden diese im folgenden Waschgang vom Perücken-Shampoo automatisch aufgelöst.
<G-vec00198-002-s044><dissolve.auflösen><en> Sacrificial tooling material (not available for Fortus 380mc) ST-130 for sacrificial mandrels that withstand the heat and pressure of composite lay-up and dissolve easily from hollow part interiors
<G-vec00198-002-s044><dissolve.auflösen><de> Sacrificial-Tooling-Material ST-130 für Opferkerne, die den hohen Temperaturen und dem Druck bei Verbundschichtformen widerstehen und bei Bauteilen mit inneren Hohlräumen leicht aufgelöst werden können.
<G-vec00198-002-s045><dissolve.auflösen><en> In doing so, the edges of the shapes become blurred, dissolve in the fur or merge into one as a unique work of art.
<G-vec00198-002-s045><dissolve.auflösen><de> Dabei verschwimmen die Kanten der Formen, werden in Fell aufgelöst oder vermischen sich zu einem einzigen Gesamtkunstwerk.
<G-vec00198-002-s046><dissolve.auflösen><en> A study of 325 patients who had suffered an ischemic stroke showed that the standard thrombolytic therapy to dissolve clots helped women significantly less than men: three months after the event, only around 28.8% of men continued to suffer more than moderate functional impairment - compared to 44.2% of women.
<G-vec00198-002-s046><dissolve.auflösen><de> In einer Studie mit insgesamt 325 Patienten nach einem ischämischen Gehirnschlag zeigte sich, dass die übliche thrombolytische Therapie, mit der die Blutgerinnsel aufgelöst werden, Frauen deutlich weniger half als Männern: Drei Monate nach dem Ereignis waren nur noch 28,8 Prozent der betroffenen Männer von mehr als nur mäßigen Funktionsbeeinträchtigungen betroffen - aber 44,2 Prozent der Frauen.
<G-vec00198-002-s047><dissolve.auflösen><en> Therefore it was decided to dissolve the existing contracts.
<G-vec00198-002-s047><dissolve.auflösen><de> Aus diesem Grund sollen die bestehenden Verträge aufgelöst werden.
<G-vec00198-002-s048><dissolve.auflösen><en> Just like the fog can only dissolve under the sun's influence, a soul's blindness can only be cured by true Love.
<G-vec00198-002-s048><dissolve.auflösen><de> So wie Nebel nur von der Sonne aufgelöst werden kann, kann auch Blindheit in einer Seele nur durch die wahre Liebe geheilt werden.
<G-vec00198-002-s049><dissolve.auflösen><en> Dissolve generational conflict and allow new ways of working: The decision makers of most established companies belong to the so-called Generation X, who in contrast to the subsequent generations Y and Z did not grow up and were not socialized in an (increasingly) connected, digital world.
<G-vec00198-002-s049><dissolve.auflösen><de> Generationskonflikt auflösen und neue Arbeitsweisen zulassen: Entscheider etablierter Unternehmen sind weitestgehend Vertreter der sogenannten Generation X, die gegenüber der Folgegenerationen Y und Z nicht in einer (zunehmend) vernetzten, digitalen Welt aufgewachsen und sozialisiert sind.
<G-vec00198-002-s050><dissolve.auflösen><en> The drug should completely dissolve within 1 min.
<G-vec00198-002-s050><dissolve.auflösen><de> Das Rauschgift sollte sich innerhalb von 1 Minute völlig auflösen.
<G-vec00198-002-s051><dissolve.auflösen><en> We are shaped by every language and culture, drawn from every end of this Earth. And because we have tasted the bitter swill of civil war and segregation and emerged from that dark chapter stronger and more united, we cannot help but believe that the old hatreds shall someday pass; that the lines of tribe shall soon dissolve; that as the world grows smaller, our common humanity shall reveal itself; and that America must play its role in ushering in a new era of peace.
<G-vec00198-002-s051><dissolve.auflösen><de> Jede Sprache und Kultur aus jedem Winkel dieser Erde hat uns geprägt, und weil wir Bürgerkrieg und Rassentrennung bitter auf unserer Zunge geschmeckt haben, und gestärkter und geeinter aus diesem dunklen Kapitel hervorgegangen sind, können wir nicht anders als zu glauben, dass der alte Hass eines Tages überwunden sein wird, dass sich die Trennlinien zwischen Volksgruppen bald auflösen werden, dass in einer kleiner werdenden Welt unsere gemeinsame Menschlichkeit zum Vorschein kommen wird, und dass die Vereinigten Staaten ihre Rolle darin spielen müssen, eine neue Zeit des Friedens einzuläuten.
<G-vec00198-002-s052><dissolve.auflösen><en> Even after the new EU regulation, she said this problem will not dissolve into thin air: “Financing of medical innovation does not receive sufficient support from stakeholders of the German healthcare system”, Eggert said.
<G-vec00198-002-s052><dissolve.auflösen><de> Und auch nach der neuen EU-Verordnung werde sich dieses Problem nicht in Luft auflösen: “Die Finanzierung medizinischer Innovation wird von den Stakeholdern des deutschen Gesundheitssystems nicht ausreichend unterstützt”, kritisiert Eggert.
<G-vec00198-002-s053><dissolve.auflösen><en> According to the invention active ingredients are used in particular, whose main target is the vascular wall, as opposed to drugs that primarily inhibit blood clotting or promoting or dissolve blood clots or otherwise act as on blood components.
<G-vec00198-002-s053><dissolve.auflösen><de> Erfindungsgemäß werden insbesondere Wirkstoffe eingesetzt, deren Hauptangriffspunkt die Gefäßwand ist, im Gegensatz zu Arzneistoffen, die primär die Blutgerinnung hemmen oder fördern oder Blutgerinnsel auflösen oder sonst wie auf Blutkomponenten einwirken.
<G-vec00198-002-s054><dissolve.auflösen><en> The exfoliant will not completely dissolve, which is what you want.
<G-vec00198-002-s054><dissolve.auflösen><de> Die Peelingpartikel werden sich nicht vollständig auflösen, was auch gewünscht ist.
<G-vec00198-002-s055><dissolve.auflösen><en> Dissolve the espresso powder in a tablespoon of boiling water, then allow to cool slightly.
<G-vec00198-002-s055><dissolve.auflösen><de> Das Espressopulver in einem Esslöffel kochendem Wasser auflösen, anschließend etwas abkühlen lassen.
<G-vec00198-002-s056><dissolve.auflösen><en> Associated alternative approaches could help to dissolve battle lines and render them ambiguous.
<G-vec00198-002-s056><dissolve.auflösen><de> Damit verbundene andere Zugänge könnten Fronten auflösen helfen und sie uneindeutig machen.
<G-vec00198-002-s057><dissolve.auflösen><en> Dissolve with stirring.
<G-vec00198-002-s057><dissolve.auflösen><de> Unter Rühren auflösen.
<G-vec00198-002-s058><dissolve.auflösen><en> Press gelatine and dissolve under low heat. Stir liquid gelatine in curdmix and let it cool.
<G-vec00198-002-s058><dissolve.auflösen><de> Gelatine ausdrücken und bei niedriger Hitze auflösen und unter der Quarkcreme verrühren.
<G-vec00198-002-s059><dissolve.auflösen><en> He can easily dissolve our undesirable desire patterns, if we invoke his presence and seek his help.
<G-vec00198-002-s059><dissolve.auflösen><de> Er kann mit Leichtigkeit unsere nicht wünschenswerten Wunschmuster auflösen, wenn wir Seine Gegenwart anrufen und um Seine Hilfe bitten.
<G-vec00198-002-s060><dissolve.auflösen><en> Dissolve each serving in water for daily consumption.
<G-vec00198-002-s060><dissolve.auflösen><de> Auflösen jede Portion in Wasser für den täglichen Konsum.
<G-vec00198-002-s061><dissolve.auflösen><en> ...or dissolve in water.
<G-vec00198-002-s061><dissolve.auflösen><de> ... oder in Wasser auflösen.
<G-vec00198-002-s062><dissolve.auflösen><en> Thus, to stabilize its finances, Sasha Waltz had to dissolve her permanent ensemble and let go of approximately one third of the permanent employees in 2014.
<G-vec00198-002-s062><dissolve.auflösen><de> Um diese finanziell zu stabilisieren, musste Sasha Waltz 2014 ihr festes Ensemble sowie etwa ein Drittel der festen Mitarbeiterstellen auflösen.
<G-vec00198-002-s063><dissolve.auflösen><en> Squeeze out gelatine, dissolve on a low heat.
<G-vec00198-002-s063><dissolve.auflösen><de> Gelatine ausdrücken, bei schwacher Hitze auflösen.
<G-vec00198-002-s064><dissolve.auflösen><en> Dissolve the SALMIX® genuine liquorice stick over low heat in the chicken stock and white wine.
<G-vec00198-002-s064><dissolve.auflösen><de> Die SALMIX® Echte Lakritz Stange bei kleiner Hitze im Hühnerfond und Weißwein auflösen.
<G-vec00198-002-s065><dissolve.auflösen><en> Hydrogen, the lightest element, can easily dissolve and migrate within metals to make these otherwise ductile materials brittle and substantially more prone to failures.
<G-vec00198-002-s065><dissolve.auflösen><de> Wasserstoff, das hellste Element, kann sich innerhalb der Metalle leicht auflösen und migrieren, um diese andernfalls duktile Materialien spröde und im Wesentlichen anfälliger zu machen für Versagen.
<G-vec00198-002-s066><dissolve.auflösen><en> In additional the stay in the free nature is stimulating the creativity so that the spirit gets open for new solutions and for the dissolve of well-worn and hardenend structures.
<G-vec00198-002-s066><dissolve.auflösen><de> Hinzu kommt, dass der Aufenthalt in der freien Natur die Kreativität stimuliert und dass der Geist damit offen wird für neue Lösungsansätze und für das Auflösen von eingefahrenen und verhärteten Strukturen.
<G-vec00198-002-s067><dissolve.auflösen><en> The combined low-vacuum/gravitational bottles in the ASEPT® Drainage Kit L can actively dissolve such occlusions by means of initial suction through the low vacuum.
<G-vec00198-002-s067><dissolve.auflösen><de> Die kombinierten Niedervakuum-/Schwerkraft-Flaschen des ASEPT® Drainage Kit L können durch einen initialen Sog des Niedervakuums solche Okklusionen aktiv auflösen.
<G-vec00198-002-s068><dissolve.auflösen><en> Dissolve 50ml (half a cup) of HG polished tile cleaner in half a bucket (5L) of lukewarm water.
<G-vec00198-002-s068><dissolve.auflösen><de> Einen halben Liter HG Fliesen Kraftreiniger in einem halben Eimer (5 Liter) lauwarmem Wasser auflösen und mit einem Aufnehmer oder Mopp großzügig auf den Boden auftragen.
<G-vec00198-002-s069><dissolve.auflösen><en> As a mediator, he alone and together with Attorney at Law Nicole-Denise Fassbender, led different mediations, and by that was able to find solutions to dissolve long-standing differences of opinion between contractually connected and thereby disputed enterprises, avoiding public court trials.
<G-vec00198-002-s069><dissolve.auflösen><de> Als Mediator hat er allein und zusammen mit Frau Rechtsanwältin Nicole-Denise Fassbender verschiedene Wirtschaftsmediatonen geleitet und konnte auf diesem Wege teilweise langjährige Meinungsverschiedenheiten zwischen vertraglich verbundenen und hierdurch in Streit geratenen Unternehmungen auflösen, ohne hierbei auf den Gerichtsweg zurückgreifen zu müssen.
<G-vec00198-002-s070><dissolve.auflösen><en> Just a small piece into flowing, warm bath water and allow to dissolve.
<G-vec00198-002-s070><dissolve.auflösen><de> Einfach ein kleines Stück ins fließende, warme Badewasser geben und auflösen lassen.
<G-vec00198-002-s071><dissolve.auflösen><en> Simply drop a tab into your re-usable water bottle and watch it rapidly dissolve.
<G-vec00198-002-s071><dissolve.auflösen><de> Einfach ein Tabs in eine Wasserflasche fallen lassen und sich auflösen lassen.
<G-vec00198-002-s072><dissolve.auflösen><en> If you go swimming, try applying sunscreen at least half an hour before you get in, so it has time to soak into your skin before you swim and doesn't just dissolve into the water.
<G-vec00198-002-s072><dissolve.auflösen><de> Wenn du schwimmst, dann versuche den Sonnenschutz mindestens eine halbe Stunde vorher aufzutragen, damit er bevor du schwimmst Zeit hat in deine Haut einzuziehen und sich nicht einfach im Wasser auflöst.
<G-vec00198-002-s073><dissolve.auflösen><en> Such text passages are important because the LLC automatically will automatically dissolve without them as a result of the death or another type of departure by a partner.
<G-vec00198-002-s073><dissolve.auflösen><de> Eine solche Textpassage ist wichtig, weil die LLC sich ohne sie durch Tod oder eine andere Art des Ausscheiden eines Gesellschafters aus dem Unternehmen automatisch auflöst.
<G-vec00198-002-s074><dissolve.auflösen><en> Such is the transformative energy of these words, however, as gifted in this article, that they gradually dissolve the power of the beliefs and ideas and allow man’s potential to shine out - a human being endowed with enduring values.
<G-vec00198-002-s074><dissolve.auflösen><de> So ist allerdings die transformative Energie dieser Worte, wie sie in diesem Artikel geschenkt werden, dass sie Schritt für Schritt die Kraft der Überzeugungen und Ideen auflöst und dem menschlichen Potenzial erlauben nach Außen zu strahlen – ein menschliches Wesen, das mit dauerhaften Werten ausgestattet ist.
<G-vec00198-002-s075><dissolve.auflösen><en> A wax or wax has the property that it will wear out and dissolve after not too long (at most 2 to 3 months).
<G-vec00198-002-s075><dissolve.auflösen><de> Ein Wachs hat die Eigenschaft, dass es sich nicht so lange hält und auflöst (höchstens 2 bis 3 Monate).
<G-vec00198-002-s076><dissolve.auflösen><en> Along with passages in French, Vivier also sets the inexpressible to music in a fantasy language in which all semantics dissolve into pure sound.
<G-vec00198-002-s076><dissolve.auflösen><de> Neben Teilen auf Französisch vertont Vivier das Unaussprechliche in einer Fantasiesprache, in der sich jegliche Semantik in pure Lautlichkeit auflöst.
<G-vec00198-002-s077><dissolve.auflösen><en> Decontracting Massage Deep massage that together with techiques of stretching, mobilization and traction is proposed to dissolve any contractions and to soften the muscles.
<G-vec00198-002-s077><dissolve.auflösen><de> Muskelentspannende Massage Tiefenmassage, die durch Strecken, Ziehen und Bewegen der verschiedenen Muskelpartien eventuelle Verhärtungen auflöst und die Muskulatur geschmeidig macht.
<G-vec00198-002-s078><dissolve.auflösen><en> Only in very rare cases, when, for example, the closed mouth becomes tired because of its constant resistance, goes slack, light, first at the corners, then increasingly breaks open everywhere, so that another’s tongue begins to find in me, overpowers me with a love, which does not dissolve me, but, rather, makes a body whole, because these are lips, by which I can feel my own, or, for example, when the eyes grow tired, can no longer resist satisfying curiosity and begin to open with my mouth, and find a gaze, since someone sees my half shut lids, and so something happens – only in these rare cases, this falling of the body, therefore, do moments of love arise.
<G-vec00198-002-s078><dissolve.auflösen><de> Nur in seltenen Fällen, wenn etwa der geschlossene Mund müde wird durch den ständigen Widerstand, locker wird, leicht, zuerst in den Winkeln, dann zunehmend überall aufbricht, sodass eine fremde Zunge beginnt, in mich zu finden, mich überrumpelt mit einer Liebe, die mich nicht auflöst, die vielmehr einen ganzen Körper macht, da es Lippen sind, an denen meine eigenen fühlbar werden, oder wenn etwa die Augen müde werden, der Neugierde nicht mehr widerstehen und sich mit dem Mund beginnen zu öffnen, und einen Blick finden, da jemand meine halb geschlossenen Lider sieht, und somit etwas geschieht – nur in diesen seltenen Fällen, diesem Fallen des Körpers also entstehen Liebesmomente.
<G-vec00198-002-s098><dissolve.auflösen><en> But in the West it is easy to dissolve the ego, in the East it is very difficult.
<G-vec00198-002-s098><dissolve.auflösen><de> Aber im Westen ist es einfach, das Ego aufzulösen, im Osten ist es sehr schwierig.
<G-vec00198-002-s099><dissolve.auflösen><en> Struvite dissolution: URINARY S/O helps to dissolve all types of struvite stones.
<G-vec00198-002-s099><dissolve.auflösen><de> Struvitstein-Auflösung: Urinary S/O Moderate Calorie hilft, Struvitsteine wirksam aufzulösen.
<G-vec00198-002-s100><dissolve.auflösen><en> The organism is not able to dissolve the components of B12.
<G-vec00198-002-s100><dissolve.auflösen><de> Der Organismus ist nicht in der Lage, die Bestandteile von B12 aufzulösen.
<G-vec00198-002-s101><dissolve.auflösen><en> As a sound and colour therapist I help people and animals to dissolve blockages on a physical, emotional and mental level and to find inner harmony.
<G-vec00198-002-s101><dissolve.auflösen><de> Als Klang- und Farbtherapeutin helfe ich Menschen und Tieren, Blockaden auf körperlicher, emotionaler und seelischer Ebene aufzulösen und die innere Harmonie zu finden.
<G-vec00198-002-s102><dissolve.auflösen><en> Minde-Pouet took the occasion of the departure to dissolve the collection and to cancel the entry register, which still listed around 1,400 documents for the period from January to March.
<G-vec00198-002-s102><dissolve.auflösen><de> Minde-Pouet nahm die Kündigung zum Anlass, die Kriegssammlung aufzulösen und die Zugangsverzeichnisse abzubrechen, die für den Zeitraum Januar bis März noch rund 1.400 Dokumente verzeichneten.
<G-vec00198-002-s103><dissolve.auflösen><en> It has good cleansing properties and good ability to dissolve blood and organic residues.
<G-vec00198-002-s103><dissolve.auflösen><de> Es besitzt gute reinigende Eigenschaften und eine gute Fähigkeit, Blut und organische Reste aufzulösen.
<G-vec00198-002-s104><dissolve.auflösen><en> You can roll the vial gently between your fingers or hands but don't shake it to dissolve.
<G-vec00198-002-s104><dissolve.auflösen><de> Sie können die Phiole zwischen Ihren Fingern oder Händen leicht rollen aber rütteln sie nicht, um dich aufzulösen.
<G-vec00198-002-s105><dissolve.auflösen><en> 5.3 If the price increase exceeds 10%, the other party has the right to dissolve the agreement for 7 working days after notification of the price increase.
<G-vec00198-002-s105><dissolve.auflösen><de> 5.3 Wenn die Preiserhöhung 10% übersteigt, hat die andere Partei das Recht, den Vertrag für 7 Arbeitstage nach Bekanntgabe der Preiserhöhung aufzulösen.
<G-vec00198-002-s106><dissolve.auflösen><en> 10.2 The resolution to amend these Articles of Association or to dissolve the Association and to utilise the assets of the Association completely shall only be legally valid if 80 % of all members entitled to vote present or represented vote in favour hereof; decisive are weighted votes pursuant to Clause 6.4.
<G-vec00198-002-s106><dissolve.auflösen><de> 10.2 Der Beschluss, diese Satzung zu ändern oder den Verein aufzulösen und das Vereinsvermögen in seiner Gesamtheit zu verwenden, ist nur wirksam, wenn ihm 80 % aller anwesenden oder vertretenen Stimmberechtigten der Mitglieder zustimmen; maßgebend sind gewichtete Stimmen gemäß Ziffer 6.4.
<G-vec00198-002-s107><dissolve.auflösen><en> Pills to increase immunity should be dosed according to the manufacturer’s instructions, that is, no more than two tablets a day, with the need to drink at least one glass of water to dissolve more easily.
<G-vec00198-002-s107><dissolve.auflösen><de> Pillen zur Erhöhung der Immunität sollten nach den Anweisungen des Herstellers dosiert werden, das heißt, nicht mehr als zwei Tabletten pro Tag, mit der Notwendigkeit, mindestens ein Glas Wasser zu trinken, um leichter aufzulösen.
<G-vec00198-002-s108><dissolve.auflösen><en> We look where you always fall into the same pattern to dissolve these patterns.
<G-vec00198-002-s108><dissolve.auflösen><de> Wir schauen, wo Du immer in das gleiche Muster fällst, um diese Muster aufzulösen.
<G-vec00198-002-s109><dissolve.auflösen><en> It also gives the authorities the power to dissolve NGOs and prosecute staff based on vague allegations. Topics Middle East and North Africa
<G-vec00198-002-s109><dissolve.auflösen><de> Zudem gibt der Gesetzentwurf den Behörden die Befugnis, NGOs auf der Grundlage vager Anschuldigungen aufzulösen und Angestellte strafrechtlich zu verfolgen.
<G-vec00198-002-s110><dissolve.auflösen><en> He is on a journey through an urban landscape where nature seems to slowly dissolve, but the longing for a union remains, leaving him in a limbo of nostalgia and reality.
<G-vec00198-002-s110><dissolve.auflösen><de> Er ist auf einer Reise durch eine urbane Landschaft, in der sich die Natur langsam aufzulösen scheint, aber die Sehnsucht nach einer Vereinigung bleibt und lässt ihn in Nostalgie und Realität schweben.
<G-vec00198-002-s111><dissolve.auflösen><en> According to the Gelugpa tradition, in Highest Yoga Tantra, the Buddha taught the most profound instructions for transforming sensual pleasure into the quick path to enlightenment, which in turn depends upon the ability to gather and dissolve the inner winds (Sanskrit: prana) into the central channel through the power of meditation.
<G-vec00198-002-s111><dissolve.auflösen><de> Nach der Gelug-Tradition lehrte der Buddha im 'Höchsten Yoga-Tantra' die tiefgreifendsten Instruktionen zur Umwandlung von sinnlichem Vergnügen in den schnellen Pfad zur Erleuchtung, die andererseits von der Fähigkeit abhängt, die inneren Winde (tibetisch: rlung; Sanskrit: prana) im zentralen Kanal zu sammeln und durch die Macht der Meditation aufzulösen.
<G-vec00198-002-s112><dissolve.auflösen><en> Bellezi shall be authorised to dissolve the agreement if the customer does not or not fully comply with the obligations under the agreement and the customer has failed to comply with a notice of default sent.
<G-vec00198-002-s112><dissolve.auflösen><de> Bellezi ist befugt, den Vertrag aufzulösen, wenn der Kunde die Verpflichtungen aus dem Vertrag nicht oder nicht vollständig erfüllt und diese Erfüllung auch, nachdem er schriftlich in Verzug gesetzt worden ist, nicht nachholt.
<G-vec00198-002-s113><dissolve.auflösen><en> If by reasonable standards Channel Distribution B.V. cannot be required to fulfil one or more of its obligations due to any of the circumstances mentioned in article 10.2. it shall have the right to suspend performance of the agreement or to dissolve the agreement fully or partially, without recourse to the courts, without being liable to provide any form of compensation.
<G-vec00198-002-s113><dissolve.auflösen><de> Wenn nach vernünftigen Maßstäben Channel Distribution B.V. aufgrund eines der in Artikel 10.2 genannten Umstände nicht verpflichtet ist, eine oder mehrere ihrer Verpflichtungen zu erfüllen, hat sie das Recht, die Erfüllung des Vertrags auszusetzen oder den Vertrag ganz oder teilweise ohne Inanspruchnahme von Gerichten aufzulösen und ohne in irgendeiner Weise für Schadenersatz haftbar zu sein.
<G-vec00198-002-s114><dissolve.auflösen><en> We begin to dissolve these patterns, to free ourselves from repeating the same behavior from lifetime to lifetime.
<G-vec00198-002-s114><dissolve.auflösen><de> Wir beginnen, diese Muster aufzulösen, um uns davon zu befreien, dasselbe Verhalten von Leben zu Leben zu wiederholen.
<G-vec00198-002-s115><dissolve.auflösen><en> 70 grams of superphosphate is recommended not to be added as a powder, but rather to dissolve the mineral substance in water and pour the substrate onto it (this will make the phosphorus more “digestible” for young cabbage).
<G-vec00198-002-s115><dissolve.auflösen><de> Es wird empfohlen, 70 g Superphosphat nicht als Pulver zuzugeben, sondern die mineralische Substanz in Wasser aufzulösen und das Substrat darauf zu gießen (dies macht den Phosphor für jungen Kohl „verdaulicher“).
<G-vec00198-002-s116><dissolve.auflösen><en> When cooking in hot water, it is necessary to dissolve the soda, and then pour hydrogen peroxide into the resulting mixture and shake everything thoroughly, then pour into a bottle with a spray.
<G-vec00198-002-s116><dissolve.auflösen><de> Beim Kochen in heißem Wasser ist es notwendig, die Soda aufzulösen, und dann Wasserstoffperoxid in die resultierende Mischung gießen und alles gründlich schütteln, dann in eine Flasche mit einem Spray gießen.
<G-vec00198-002-s117><dissolve.auflösen><en> Crumble the yeast and dissolve it in the milk.
<G-vec00198-002-s117><dissolve.auflösen><de> Die Hefe zerbröseln und darin auflösen.
<G-vec00198-002-s118><dissolve.auflösen><en> Squeeze out gelatine and dissolve in wine mixture.
<G-vec00198-002-s118><dissolve.auflösen><de> Gelatine ausdrücken und darin auflösen.
<G-vec00198-002-s119><dissolve.auflösen><en> Pour in milk and dissolve miso paste on a medium heat.
<G-vec00198-002-s119><dissolve.auflösen><de> Milch hinzufügen und Misopaste darin bei mittlerer Hitze auflösen.
<G-vec00198-002-s131><dissolve.auflösen><en> Your back is kneaded to ensure implausible smoothness and within no time small tensions dissolve into nothing.
<G-vec00198-002-s131><dissolve.auflösen><de> Hier wird Ihr Rücken geschmeidig durchgeknetet und kleine Verspannungen in kurzer Zeit gelöst.
<G-vec00198-002-s132><dissolve.auflösen><en> This mixing and blending equipment can be used to mix liquids such as acids, alkalis and solvents with each other, dissolve solids in liquids, or blend several solids with each other.
<G-vec00198-002-s132><dissolve.auflösen><de> In diesen Mischanlagen können Flüssigkeiten wie Säuren, Laugen und Lösungsmittel miteinander verrührt, Feststoffe in flüssigen Medien gelöst oder auch mehrere Feststoffe miteinander vermischt werden.
<G-vec00198-002-s133><dissolve.auflösen><en> They come in powder and dissolve in water, you get an energy drink with a high concentration of carbohydrates.
<G-vec00198-002-s133><dissolve.auflösen><de> Sie kommen in Pulver und in Wasser gelöst, erhalten Sie einen Energydrink mit einer hohen Konzentration von Kohlenhydraten.
<G-vec00198-002-s134><dissolve.auflösen><en> As a preventative measure: Dissolve 10 g per 100 l aquarium water in a little water and disperse in the tank once a week.
<G-vec00198-002-s134><dissolve.auflösen><de> Zur Vorbeugung: Wöchentlich 10 g auf 100 l Aquarienwasser in etwas Wasser gelöst und im Becken verteilt.
<G-vec00198-002-s140><dissolve.auflösen><en> Dissolve this substance into water and keep it in the fridge.
<G-vec00198-002-s140><dissolve.auflösen><de> Löse diese Substanz in Wasser und lagere es im Kühlschrank.
<G-vec00198-002-s141><dissolve.auflösen><en> Dissolve 1 teaspoon of sea salt in the tea.
<G-vec00198-002-s141><dissolve.auflösen><de> Löse einen Teelöffel Meersalz im Tee.
<G-vec00198-002-s142><dissolve.auflösen><en> If I first said, I love the world, I now add likewise: I do not love it, for I annihilate it as I annihilate myself; I dissolve it.
<G-vec00198-002-s142><dissolve.auflösen><de> Sagte Ich erst, Ich liebe die Welt, so setze Ich jetzt ebenso hinzu: Ich liebe sie nicht, denn Ich vernichte sie, wie Ich Mich vernichte: Ich löse sie auf.
<G-vec00198-002-s143><dissolve.auflösen><en> Dissolve drops in half a glass of water or juice.
<G-vec00198-002-s143><dissolve.auflösen><de> Löse Tropfen in einem halben Glas Wasser oder Saft.
<G-vec00198-002-s144><dissolve.auflösen><en> Dissolve or mix a small amount of one substance at a time into a glass of clean water, and then test with a litmus strip.
<G-vec00198-002-s144><dissolve.auflösen><de> Löse oder mische eine kleine Menge der Substanz in einem Glas mit sauberen Wasser auf und teste sie dann mit einem Lackmustreifen.
<G-vec00198-002-s145><dissolve.auflösen><en> Place aside. Mix the active dried yeast with 1 cup warm water and stir well to dissolve.
<G-vec00198-002-s145><dissolve.auflösen><de> Löse die Hefe mit dem Zucker in einer Tasse warmen Wasser auf und stelle sie beiseite.
<G-vec00198-002-s146><dissolve.auflösen><en> Only if they are in good condition do they have the chance to survive the winter months. “I dissolve weak colonies and put two weak colonies together to build a strong colony,” explains Trodtfeld.
<G-vec00198-002-s146><dissolve.auflösen><de> Nur in einem guten Zustand haben sie Chancen, gut über die Wintermonate zu kommen: „Schwache Völker löse ich auf und mache aus zwei schwachen Völkern ein starkes Volk“, erklärt Trodtfeld.
<G-vec00198-002-s147><dissolve.auflösen><en> Dissolve a small amount of sea salt in a cup of warm water.
<G-vec00198-002-s147><dissolve.auflösen><de> Löse eine kleine Menge Meersalz in einer Tasse warmen Wassers auf.
<G-vec00198-002-s148><dissolve.auflösen><en> Directions: Dissolve 10 ml concentrate in 200 ml water.
<G-vec00198-002-s148><dissolve.auflösen><de> Löse 10 ml Konzentrat in 200 ml Wasser auf.
<G-vec00198-002-s149><dissolve.auflösen><en> Dissolve the sugar.
<G-vec00198-002-s149><dissolve.auflösen><de> Löse den Zucker auf.
<G-vec00198-002-s150><dissolve.auflösen><en> Directions: Dissolve 100g (4 measures) of powder in 200 ml of water or milk.
<G-vec00198-002-s150><dissolve.auflösen><de> Anweisung: Löse 100g (4 Maßeinheiten) Pulver in 200 ml Wasser oder Milch auf.
<G-vec00198-002-s151><dissolve.auflösen><en> So bring more love in this material world and dissolve your ego in love.
<G-vec00198-002-s151><dissolve.auflösen><de> Also bring mehr Liebe in die materielle Welt und löse das Ego in der Liebe auf.
<G-vec00198-002-s152><dissolve.auflösen><en> Dissolve some xylitol in your mouth and hold the saliva for 5 minutes, this might help.
<G-vec00198-002-s152><dissolve.auflösen><de> Löse etwas Xylit im Mund auf und behalte den Speichel fünf Minuten im Mund, dies könnte Abhilfe bringen.
<G-vec00198-002-s153><dissolve.auflösen><en> Dissolve the tincture in water, or place directly on your tongue.
<G-vec00198-002-s153><dissolve.auflösen><de> Löse die Tinktur in Wasser auf oder gib sie dir direkt auf die Zunge.
<G-vec00198-002-s154><dissolve.auflösen><en> Supplement Facts Directions Dissolve 10 ml Multi Hypotonic concentrate in 650 ml water.
<G-vec00198-002-s154><dissolve.auflösen><de> Löse 10 ml des Getränke-Konzentrats Multi Hypotonic in 650 ml Wasser auf.
<G-vec00198-002-s155><dissolve.auflösen><en> Simply dissolve the powder in water, stir and you’ve created a delicious orange-flavoured drink.
<G-vec00198-002-s155><dissolve.auflösen><de> Löse das Pulver einfach in Wasser auf, verrühre es und Du hast ein köstliches Getränk mit Orangengeschmack.
<G-vec00198-002-s156><dissolve.auflösen><en> To prepare a salt water rinse, dissolve 1 teaspoon of salt in a cup of warm water.
<G-vec00198-002-s156><dissolve.auflösen><de> Um eine Salzwasserlösung herzustellen, löse einen Teelöffel Salz in einer Tasse mit warmem Wasser auf.
<G-vec00198-002-s157><dissolve.auflösen><en> The consumer can dissolve the contract as long as this acceptance has not been confirmed.
<G-vec00198-002-s157><dissolve.auflösen><de> Solange der Erhalt nicht bestätigt ist, kann der Verbraucher den Vertrag lösen.
<G-vec00198-002-s158><dissolve.auflösen><en> A constipation caused by a bone can be difficult for the body to dissolve and can lead to several days of intensive care at an animal hospital.
<G-vec00198-002-s158><dissolve.auflösen><de> Eine Knochenverstopfung ist schwer zu lösen und kann eine mehrtägige Intensivbehandlung in der Tierklinik erforderlich machen.
<G-vec00198-002-s159><dissolve.auflösen><en> Chromium-bearing grades require higher heat treatment temperatures as chromium carbides are more difficult to dissolve into solution.
<G-vec00198-002-s159><dissolve.auflösen><de> Chromhaltige Typen erfordern höhere Wärmebehandlungstemperaturen, da Chromkarbide schwerer in Lösung zu lösen sind.
<G-vec00198-002-s160><dissolve.auflösen><en> All types of heat application are perceived as comforting, since they dissolve the reflectory hypertonia of the upper body muscles, in particular of the paravertebral dorsal extensor muscles, and encourage better blood circulation.
<G-vec00198-002-s160><dissolve.auflösen><de> Wärmeanwendungen aller Art werden als wohltuend empfunden, weil sie diesen reflektorischen Hypertonus der Rumpfmuskeln, insbesondere der paravertebralen Rückenstrecker, lösen und die Durchblutung fördern.
<G-vec00198-002-s161><dissolve.auflösen><en> Schematic diagram of absorption and compression taking place simultaneously in a reciprocating compressor to dissolve gases in liquids using the example of carbon dioxide.
<G-vec00198-002-s161><dissolve.auflösen><de> Schematische Darstellung der gleichzeitig stattfindenden Absorption und Kompression in einem Kolbenkompressor zum Lösen von Gasen in Flüssigkeiten am Beispiel von Kohlenstoffdioxid.
<G-vec00198-002-s162><dissolve.auflösen><en> It has the capability to increasingly dissolve tungsten carbide even in its solid state at increasing temperatures.
<G-vec00198-002-s162><dissolve.auflösen><de> Es ist in der Lage, bereits im festen Zustand mit steigender Temperatur in zunehmendem Maße Wolframkarbid zu lösen.
<G-vec00198-002-s163><dissolve.auflösen><en> Another possibility is to dissolve the stabilizer in a suitable solvent and applied to the particles of the polyalkenamer.
<G-vec00198-002-s163><dissolve.auflösen><de> Eine andere Möglichkeit besteht darin, den Stabilisator in einem geeigneten Lösemittel zu lösen und auf die Partikel des Polyalkenamers aufzubringen.
<G-vec00198-002-s164><dissolve.auflösen><en> Chemical cleaners dissolve the paint that way it penetrates deeper into the pores.
<G-vec00198-002-s164><dissolve.auflösen><de> Chemische Reiniger lösen die Farbe, so dass diese noch tiefer in die Poren eindringen können.
<G-vec00198-002-s165><dissolve.auflösen><en> Depilatory creams dissolve the hair, leaving a rounded tip at the end of the hair instead of the prickly edge resulting from razors.
<G-vec00198-002-s165><dissolve.auflösen><de> Die Enthaarungscremes von Veet lösen die Haare an der Wurzel, sodass das Haar einfach abbricht und Sie bis zu vier Tage stoppelfrei sind.
<G-vec00198-002-s166><dissolve.auflösen><en> Suggested method of administration: As a food additive, dissolve in your mouth or chew one tablet daily.
<G-vec00198-002-s166><dissolve.auflösen><de> Anwendungshinweis: Als Nahrungsergänzungsmittel, lösen Sie im Mund oder kauen Sie eine Tablette pro Tag.
<G-vec00198-002-s167><dissolve.auflösen><en> Warm lukewarm milk and dissolve the yeast in it.
<G-vec00198-002-s167><dissolve.auflösen><de> Milch lauwarm erwärmen und die Hefe darin lösen.
<G-vec00198-002-s168><dissolve.auflösen><en> I feel emotional blockages of other people when they are in my presence and can feel with my hands where they are in the body and dissolve these energies.
<G-vec00198-002-s168><dissolve.auflösen><de> Ich spüre emotionale Blockaden anderer Personen wenn sie in meiner Gegenwart sind und kann mit meinen Händen spüren wo sie sich im Körper befinden und diese Energien lösen.
<G-vec00198-002-s169><dissolve.auflösen><en> To dissolve grease and dirt, choose an alkaline, water-based cleaner: soaps, detergents, or a bit of baking soda dissolved in water will do, though should be used sparingly.
<G-vec00198-002-s169><dissolve.auflösen><de> Zum Lösen von Fett und Schmutz verwende einen alkalischen Reiniger auf Wasserbasis; Seifen, Waschmittel oder etwas in Wasser aufgelöstes Backsoda sind gut geeignet, jedoch solltest du wissen, dass alkalische Lösungen die Versiegelung im Laufe der Zeit matt aussehen lassen.
<G-vec00198-002-s170><dissolve.auflösen><en> The Ecover Classic Dishwasher Tabs powerfully dissolve stubborn food and grease residues with the help of pulp surfactants.
<G-vec00198-002-s170><dissolve.auflösen><de> Die Classic Tabs von Ecover lösen kraftvoll mit der Hilfe von Zellstoff-Tensiden hartnäckige Speiserückstände, angebranntes Essen und Fettreste.
<G-vec00198-002-s172><dissolve.auflösen><en> Dissolve the contents of one bag in 500 ml water while stirring and drink immediately.
<G-vec00198-002-s172><dissolve.auflösen><de> Den Inhalt eines Beutels unter Rühren in 500 ml Wasser lösen und alsbald trinken.
<G-vec00198-002-s173><dissolve.auflösen><en> Alcohol has the capability to dissolve both oil-soluble and water-soluble flavors.
<G-vec00198-002-s173><dissolve.auflösen><de> Alkohol hat die Fähigkeit, sowohl öl- als auch wasserlösliche Aromen zu lösen.
<G-vec00198-002-s174><dissolve.auflösen><en> The hydrothermal waters of the Upper Geyser Basins are neutral to weak alkaline and dissolve several minerals from the volcanic bedrock underground. It is an ideal biotope for thermophile microorganisms living in 131°F (55°C) hot water.
<G-vec00198-002-s174><dissolve.auflösen><de> Die hydrothermalen Wasser des Upper Geyser Basins sind neutral bis schwach basisch, lösen diverse Mineralien aus dem Vulkangestein und bilden einen idealen Lebensraum für thermophile Mikro-organismen im bis zu 55°C heißen Wasser.
<G-vec00198-002-s175><dissolve.auflösen><en> A simple tip to dissolve stubborn eye make-up is to soak lids and lashes for longer.
<G-vec00198-002-s175><dissolve.auflösen><de> Ein einfacher Tipp, um hartnäckiges Augen-Make-up besser zu lösen, ist, die Augenlider und Wimpern länger einzuweichen.
<G-vec00198-002-s176><dissolve.auflösen><en> To do this, remove the tank, fill it with water before fitting the new filter, dissolve three JURA descaling tablets in the water and leave to take effect.
<G-vec00198-002-s176><dissolve.auflösen><de> Dazu entnehmen Sie den Tank, füllen diesen vor dem Einsetzen des neuen Filters mit Wasser, lösen drei Entkalkungstabletten von JURA im Wasser auf und lassen das Ganze einwirken.
<G-vec00198-002-s177><dissolve.auflösen><en> Dissolve one level teaspoon (1.5g) in 6oz water or tea.
<G-vec00198-002-s177><dissolve.auflösen><de> Einnahme Lösen Sie einen gestrichenen Teelöffel in 200ml Wasser oder Tee auf.
<G-vec00198-002-s178><dissolve.auflösen><en> Dissolve the yeast in 550 ml of water, stir salt in the remaining water.
<G-vec00198-002-s178><dissolve.auflösen><de> Lösen Sie die Hefe in 550 ml Wasser und das Salz in die restliche 50 ml auf.
<G-vec00198-002-s179><dissolve.auflösen><en> The same architecture, the same engineering and use of the same application software dissolve the boundaries between drive-based and controller-based automation.
<G-vec00198-002-s179><dissolve.auflösen><de> Gleiche Architektur, gleiches Engineering sowie die Verwendung der gleichen Applikationssoftware lösen die Grenzen zwischen Drive-based und Controller-based Automation auf.
<G-vec00198-002-s180><dissolve.auflösen><en> Through intergenerational energetic work we dissolve them and create a new room for manoeuvre.
<G-vec00198-002-s180><dissolve.auflösen><de> Durch intergenerationales energetisches Arbeiten lösen wir sie auf und schaffen so einen neuen Handlungsspielraum.
<G-vec00198-002-s181><dissolve.auflösen><en> The featured works dissolve the body into smoke, partition it into pieces, reveal the limits of its control, and examine the traces it builds and leaves behind.
<G-vec00198-002-s181><dissolve.auflösen><de> Die gezeigten Arbeiten lösen den Körper in Rauch auf, teilen ihn in Stücke, legen die Grenzen seiner Kontrollierbarkeit offen und untersuchen die Spuren, die er produziert und zurücklässt.
<G-vec00198-002-s182><dissolve.auflösen><en> With the Uniserv Data Quality Cloud you dissolve duplicates and prevent new duplications.
<G-vec00198-002-s182><dissolve.auflösen><de> Mit der Uniserv Data Quality Cloud lösen Sie Dubletten auf und verhindern neue Dopplungen.
<G-vec00198-002-s183><dissolve.auflösen><en> 3 l of boiling water dissolve the soap crushed in the form of thin shavings.
<G-vec00198-002-s183><dissolve.auflösen><de> 3 l des siedenden Wassers lösen die in Form von den feinen Spänen verflachte Seife auf.
<G-vec00198-002-s184><dissolve.auflösen><en> We dissolve the barriers that were unwarranted for a beating heart that needs no protection.
<G-vec00198-002-s184><dissolve.auflösen><de> Wir lösen die Barrieren auf, die für ein schlagendes Herz, das keiner Abwehr bedarf, keine Berechtigung haben.
<G-vec00198-002-s185><dissolve.auflösen><en> The high-pressure areas there let the clouds dissolve and there is therefore no precipitate.
<G-vec00198-002-s185><dissolve.auflösen><de> Die dort auftretenden Hochdruckgebiete lösen die Wolken auf und es kommt deshalb zu keinem Niederschlag.
<G-vec00198-002-s186><dissolve.auflösen><en> If your sauce doesn't reach the consistency you require, simply dissolve 1 tbsp of corn flour in either some cold wine, stock or water and add gradually to the simmering sauce until it thickens.
<G-vec00198-002-s186><dissolve.auflösen><de> Wenn die Sauce nicht die Konsistenz erereicht, die Sie wünschen, lösen Sie einfach einen Esslöffel Maismehl in etwas kaltem Wein, Wasser oder Brühe auf und geben Sie die Mischung nach und nach in die Sauce, bis diese eindickt.
<G-vec00198-002-s187><dissolve.auflösen><en> So, Turks dissolve some locoum, a very sweet confectionery of rubbery texture with strong rose fragrance, in their coffee (see also cardamom).
<G-vec00198-002-s187><dissolve.auflösen><de> So lösen Türken in ihrem Kaffee (siehe auch Cardamom) gerne etwas locoum auf, ein sehr süßes, gummiartiges Konfekt mit starkem Rosenaroma.
<G-vec00198-002-s188><dissolve.auflösen><en> It is best to dissolve the iodine tablets in a glass with lukewarm water.
<G-vec00198-002-s188><dissolve.auflösen><de> Am besten lösen Sie die Jodtabletten in einem Glas mit lauwarmem Wasser auf.
<G-vec00198-002-s189><dissolve.auflösen><en> The proteic enzymes in these fruits dissolve the gelatine and prevent it from gelling.
<G-vec00198-002-s189><dissolve.auflösen><de> Die Eiweißenzyme in diesen Früchten lösen die Gelatine auf und verhindern, dass diese geliert.
<G-vec00198-002-s190><dissolve.auflösen><en> Dissolve the yeast and sugar in some water.
<G-vec00198-002-s190><dissolve.auflösen><de> Lösen Sie die Trockenhefe und den Zucker in lauwarmem Wasser auf.
<G-vec00198-002-s191><dissolve.auflösen><en> His works dissolve the boundaries between art and everyday life, between passive viewing and active participation.
<G-vec00198-002-s191><dissolve.auflösen><de> Seine Arbeiten lösen die Grenzen zwischen Kunst und Alltag, passivem Betrachten und aktiver Beteiligung auf.
<G-vec00198-002-s192><dissolve.auflösen><en> By strengthening the light grid on the planet we dissolve the plasma octopus and allow the EVENT to become reality.
<G-vec00198-002-s192><dissolve.auflösen><de> Indem wir das Licht-Gitternetz über dem Planeten stärken, lösen wir den Plasma-Oktopus auf und ermöglichen es so, dass das Event geschehen kann.
<G-vec00198-002-s193><dissolve.auflösen><en> Special stretching exercises address the meridians and dissolve blockages.
<G-vec00198-002-s193><dissolve.auflösen><de> Spezielle Dehnübungen sprechen die Meridiane an und lösen Blockaden auf.
<G-vec00198-002-s194><dissolve.auflösen><en> Dissolve the measured quantity of Professional Sea Salt in a clean container, stirring evenly all the time.
<G-vec00198-002-s194><dissolve.auflösen><de> Lösen Sie die abgemessene Menge Professional Sea Salt unter gleichmäßiger Wasserbewegung in einem sauberen Behälter auf.
<G-vec00198-002-s195><dissolve.auflösen><en> Gelatine softgel capsules dissolve faster and allow to achieve hard erection within several minutes.
<G-vec00198-002-s195><dissolve.auflösen><de> Softgel-Kapseln lösen sich schneller auf und führen so innerhalb von wenigen Minuten zu einer harten Erektion.
<G-vec00198-002-s196><dissolve.auflösen><en> Colors and words flow over the facade and become abstract compositions and dissolve again, various details of the production of beer are schematically integrated into the installation.
<G-vec00198-002-s196><dissolve.auflösen><de> Farben und Wörter fließen über die Fassade werden zu abstrakten Bildkompositionen und lösen sich wieder auf, verschiedene Details der Herstellung von Bier werden in die Installation schemenhaft integriert.
<G-vec00198-002-s197><dissolve.auflösen><en> The transport function is performed by healthy veins, and the glued ones dissolve within a year and a half.
<G-vec00198-002-s197><dissolve.auflösen><de> Die Transportfunktion wird von gesunden Venen übernommen, die geklebten lösen sich innerhalb von anderthalb Jahren auf.
<G-vec00198-002-s198><dissolve.auflösen><en> Physical and mental tensions dissolve, an improved cell metabolism promotes physical recovery processes.
<G-vec00198-002-s198><dissolve.auflösen><de> Körperliche und seelische Verspannungen lösen sich, ein verbesserter Zellstoffwechsel fördert physische Genesungsprozesse.
<G-vec00198-002-s199><dissolve.auflösen><en> Energy blockages dissolve.
<G-vec00198-002-s199><dissolve.auflösen><de> Energieblockierungen lösen sich.
<G-vec00198-002-s200><dissolve.auflösen><en> To the right, the bodhisattvas all dissolve into Avalokiteśvara.
<G-vec00198-002-s200><dissolve.auflösen><de> Zur Rechten lösen sich die Bodhisattvas in Avalokiteśvara auf.
<G-vec00198-002-s201><dissolve.auflösen><en> In addition, alkalis also dissolve well in ethanol.
<G-vec00198-002-s201><dissolve.auflösen><de> Außerdem lösen sich Alkalien gut in Ethanol.
<G-vec00198-002-s202><dissolve.auflösen><en> Gelatine softgel capsules dissolve faster and allow to achieve hard erection within several minutes.
<G-vec00198-002-s202><dissolve.auflösen><de> Cialis Super Softgel-Kapseln lösen sich schneller auf und führen so innerhalb von wenigen Minuten zu einer harten Erektion.
<G-vec00198-002-s203><dissolve.auflösen><en> In 4-6 months the threads dissolve completely.
<G-vec00198-002-s203><dissolve.auflösen><de> In 4-6 Monaten lösen die Drähte sich vollständig.
<G-vec00198-002-s204><dissolve.auflösen><en> During the copper refining process, impurities in the anode dissolve into the electrolyte or form anode slimes.
<G-vec00198-002-s204><dissolve.auflösen><de> Während des Kupferraffinationsprozess lösen sich die metallischen Verunreinigungen der Anode im Kupferelektrolyt oder formen einen sogennanten Anodenschlamm.
<G-vec00198-002-s205><dissolve.auflösen><en> Most pseudo-knots dissolve again during processing.
<G-vec00198-002-s205><dissolve.auflösen><de> Die meisten Pseudoknoten lösen sich während der Verarbeitung wieder.
<G-vec00198-002-s206><dissolve.auflösen><en> The allegedly compact, natural things dissolve beneath the surface into contingent significances and the visual coherence of objects merely shrouds the plurality of meanings.
<G-vec00198-002-s206><dissolve.auflösen><de> Die vermeintlich kompakten, natürlichen Dinge lösen sich unter ihren Oberflächen in kontingente Bedeutungen auf, und die scheinbare Einheit des Objekts verdeckt nur noch die Vielheit des Sinns.
<G-vec00198-002-s207><dissolve.auflösen><en> Fiber does not dissolve in water and is almost not digested in the stomach and intestines.
<G-vec00198-002-s207><dissolve.auflösen><de> Ballaststoffe lösen sich nicht in Wasser und werden im Magen und Darm fast nicht verdaut.
<G-vec00198-002-s208><dissolve.auflösen><en> All liquid flavors dissolve well in water and successfully supplement the bait.
<G-vec00198-002-s208><dissolve.auflösen><de> Alle flüssigen Aromen lösen sich gut in Wasser und ergänzen den Köder erfolgreich.
<G-vec00198-002-s209><dissolve.auflösen><en> Capsules just dissolve in a glass of water and in this way we obtain a tasty drink that is rich in minerals and vitamins.
<G-vec00198-002-s209><dissolve.auflösen><de> Kapseln lösen sich einfach in einem Glas Wasser auf und auf diese Weise erhalten wir ein leckeres Getränk, das reich an Mineralien und Vitaminen ist.
<G-vec00198-002-s210><dissolve.auflösen><en> Essential oils dissolve in water, are breathed in with the warm air ad provide support for the immune system.
<G-vec00198-002-s210><dissolve.auflösen><de> Ätherische Öle lösen sich im Wasser auf, werden mit der warmen Luft eingeatmet und unterstützen so das Immunsystem.
<G-vec00198-002-s211><dissolve.auflösen><en> Molybdenum and tungsten do not dissolve in an aluminum melt.
<G-vec00198-002-s211><dissolve.auflösen><de> Molybdän und Wolfram lösen sich in Aluminiumschmelze nicht.
<G-vec00198-002-s212><dissolve.auflösen><en> Due to their high content of evaporated salt, DEFROST products dissolve very well, which in turn guarantees that snow and ice melt quickly.
<G-vec00198-002-s212><dissolve.auflösen><de> Die DEFROST-Produkte lösen sich aufgrund des hohen Siedesalzgehalts sehr gut auf und garantieren dadurch ein schnelles Auftauen von Schnee und Glätte.
<G-vec00198-002-s213><dissolve.auflösen><en> Without separation, time and space dissolve, because they are simply measures of separation that we have structured and imposed on the universe.
<G-vec00198-002-s213><dissolve.auflösen><de> Ohne Trennung lösen sich Zeit und Raum auf, denn sie sind einfach Trennungsmaßnahmen, die wir dem Universum strukturiert und auferlegt haben.
<G-vec00198-002-s214><dissolve.auflösen><en> Children above 3 years of age – dissolve 1 sachet in ½ glass of warm water, once a day in the evening.
<G-vec00198-002-s214><dissolve.auflösen><de> Kinder über 3 Jahre alt - lösen Sie 1 Päckchen in ½ Glas warmem Wasser einmal am Tag abends auf.
<G-vec00198-002-s215><dissolve.auflösen><en> 2 grams per day: Dissolve 1 times daily 1.5 teaspoons* in a glass of chlorine-free water, tea or organic juice, or stir in the soup of muesli
<G-vec00198-002-s215><dissolve.auflösen><de> 2 Gramm pro Tag: Lösen Sie 1 Mal pro Tag 1,5 gestrichene Teelöffel* in Wasser, Tee oder Bio-Saft auf, oder rühren Sie in Wasser, Tee oder Bio-Saft auf, oder rühren Sie Fauna Mana in Suppe oder Müsli.
<G-vec00198-002-s216><dissolve.auflösen><en> Dissolve per shake 40 to 80 grams (1 to 2 scoops) of Perfect Rice Powder in 350 ml of milk or water.
<G-vec00198-002-s216><dissolve.auflösen><de> Lösen Sie pro Shake 50 bis 100 Gramm (2 bis 4 Messlöffel) Perfect Oats in mindestens 350 ml Milch oder Wasser auf.
<G-vec00198-002-s217><dissolve.auflösen><en> For the best result, first dissolve one component in water and then the other.
<G-vec00198-002-s217><dissolve.auflösen><de> Für das beste Ergebnis lösen Sie zuerst eine Komponente in Wasser und dann die andere.
<G-vec00198-002-s218><dissolve.auflösen><en> Dissolve 25g (full meter) in 200ml (one glass) of water or skimmed milk.
<G-vec00198-002-s218><dissolve.auflösen><de> Lösen Sie 25g (vollen Meter) in 200ml (ein Glas) Wasser oder Magermilch.
<G-vec00198-002-s219><dissolve.auflösen><en> Dissolve two or more cups to into a warm bath.
<G-vec00198-002-s219><dissolve.auflösen><de> Lösen Sie zwei oder mehr Tassen in ein warmes Bad.
<G-vec00198-002-s220><dissolve.auflösen><en> For bath: Dissolve 8-10 drops of spearmint essential oil in a tablespoon of honey or STENDERS bath milk that has been mixed with a little water.
<G-vec00198-002-s220><dissolve.auflösen><de> Zum Baden und für Hand- und Fussbäder: Lösen Sie 8-10 Tropfen Jasmineöl in Honig oder Milch auf und giessen Sie es ins Badewasser.
<G-vec00198-002-s221><dissolve.auflösen><en> This extraction does not dissolve the bound forms of the metal ions. Thus, the metal ions in the MMI solutions are the chemically active or ‘mobile’ component of the sample.
<G-vec00198-002-s221><dissolve.auflösen><de> Diese Extraktion löst die gebundenen Formen der Metallionen nicht, Deshalb sind die Metallionen der MMI-Lösungen die chemisch aktive oder "mobile" Komponente der Probe.
<G-vec00198-002-s222><dissolve.auflösen><en> It is water soluble and will easily dissolve chlorophyll, due to which the flavor of the product is grassy and bitter.
<G-vec00198-002-s222><dissolve.auflösen><de> Es ist wasserlöslich und löst leicht Chlorophyll auf, wodurch der Geschmack des Produkts grasig und bitter ist.
<G-vec00198-002-s223><dissolve.auflösen><en> Dissolve the clouds by observing a balanced life with healthy habits.
<G-vec00198-002-s223><dissolve.auflösen><de> Löst die Wolken durch das Beobachten eines ausgewogenen Leben mit gesunder Gewohnheiten.
<G-vec00198-002-s224><dissolve.auflösen><en> The soap-free cleanser transforms into a refreshing foam upon application, working to dissolve makeup and unclog pores for a cleansed and purified complexion.
<G-vec00198-002-s224><dissolve.auflösen><de> Bei der Anwendung verwandelt sich der seifenfreie Reiniger in einen erfrischenden Schaum, der Make-Up löst und verstopfte Poren reinigt, um dir einen sauberen und klaren Teint zu schenken.
<G-vec00198-002-s225><dissolve.auflösen><en> PreLavan Extra delivers exceptionally good foaming action, helping it to dissolve many different kinds of dirt from vehicle surfaces.
<G-vec00198-002-s225><dissolve.auflösen><de> PreLavan Extra bietet eine außergewöhnlich gute Schaumleistung und löst damit viele verschiedene Verschmutzungen von der Fahrzeugoberfläche.
<G-vec00198-002-s226><dissolve.auflösen><en> A constant current is applied between the anodes and the hull (mass), which causes copper to dissolve in the seawater.
<G-vec00198-002-s226><dissolve.auflösen><de> Zwischen den Anoden und der Hülle (Masse) wird ein konstanter Strom angelegt, welcher dafür sorgt, dass sich Kupfer im Seewasser löst.
<G-vec00198-002-s227><dissolve.auflösen><en> While most AHA (alpha-hydroxy acids) serums focus only on the exfoliation aspect that can sometimes lead to tightness and irritation, this multitasking booster is formulated to not only gently dissolve dead skin cells but also replenish moisture and strengthen the skin’s delicate barrier, with its hydrating blend of Hyaluronic Acid, Niacinamide and essential fatty acids from Organic Rosehip + Tamanu Oil.
<G-vec00198-002-s227><dissolve.auflösen><de> Während sich die meisten AHA (Alpha-Hydroxysäuren)-Seren nur auf den Peeling-Aspekt konzentrieren, der manchmal zu Irritationen führen kann, ist dieser Multitasking-Booster so formuliert, dass er nicht nur abgestorbene Hautzellen sanft löst, sondern auch Feuchtigkeit spendet und die Hautschutzbarriere dank enthaltener Hyaluronsäure, Niacinamid und essentiellen Fettsäuren aus organischem Hagebutten- und Tamanuöl stärkt.
<G-vec00198-002-s228><dissolve.auflösen><en> This incident inspired Alex Anwandter to make his impressively multi-layered debut. Demonstrating great sensitivity, he traces in the figure of the reclusive father the enormous pressure that exists to adhere to the fixed norms of masculinity – only to dissolve these norms in Pablo’s dream of living a life that is vibrantly queer.
<G-vec00198-002-s228><dissolve.auflösen><de> Der Fall inspirierte Alex Anwandter zu seinem beeindruckend vielschichtigen Debüt: Mit großem Feingefühl spürt er in der Zurückgezogenheit des Vaters dem gewaltsamen Druck eingeschworener Männlichkeitsnormen nach – und löst sie im bunten queeren Lebenstraum Pablos auf.
<G-vec00198-002-s229><dissolve.auflösen><en> These CO2 diffusers in bowl style dissolve up to 98% of the CO2 running through them.
<G-vec00198-002-s229><dissolve.auflösen><de> Der CO2 Nano Diffusor aus Glas löst bis zu 98% des durchströmenden CO2.
<G-vec00198-002-s230><dissolve.auflösen><en> Ethanol is a very popular solvent since it ethanol dissolve both polar (hydrophilic) and nonpolar (hydrophobic/lipophilic) substances.
<G-vec00198-002-s230><dissolve.auflösen><de> Ethanol ist ein sehr beliebtes Lösungsmittel, da es sowohl polare (hydrophile) als auch unpolare (hydrophobe / lipophile) Substanzen löst.
<G-vec00198-002-s231><dissolve.auflösen><en> Crystal salt combined with water will dissolve all the superfluous and poisonous waste products of our body so as to improve detoxification.
<G-vec00198-002-s231><dissolve.auflösen><de> Das Kristallsalz in Verbindung mit Wasser löst im Körper überflüssige oder giftige Abfallprodukte und fördert die Entschlackung.
<G-vec00198-002-s232><dissolve.auflösen><en> Dissolve in milk chocolate.
<G-vec00198-002-s232><dissolve.auflösen><de> Löst in Milchschokolade.
<G-vec00198-002-s233><dissolve.auflösen><en> True compassion, which is selfless, will dissolve human notions.
<G-vec00198-002-s233><dissolve.auflösen><de> Wahre Barmherzigkeit, die selbstlos ist, löst menschliche Anschauungen auf.
<G-vec00198-002-s234><dissolve.auflösen><en> However, if the spouses have not been living together for at least three years, the court will dissolve the marriage if it has broken down.
<G-vec00198-002-s234><dissolve.auflösen><de> Wenn die Ehegatten jedoch seit mindestens drei Jahren nicht mehr zusammenleben, löst das Gericht die Ehe auf, wenn sie gescheitert ist.
<G-vec00198-002-s235><dissolve.auflösen><en> Let your ego dissolve in love.
<G-vec00198-002-s235><dissolve.auflösen><de> Löst euer Ego in eurer Liebe auf.
<G-vec00198-002-s236><dissolve.auflösen><en> So the Buddha provides a third, more skillful alternative: Breathe through your discomfort and dissolve it away.
<G-vec00198-002-s236><dissolve.auflösen><de> Also bietet der Buddha eine dritte, tauglichere Alternative an: Man atmet durch das Unbehagen hindurch und löst es so auf.
<G-vec00198-002-s237><dissolve.auflösen><en> An organic stain will dissolve easily with a soft head brush, whereas a metal stain will stay put.
<G-vec00198-002-s237><dissolve.auflösen><de> Ein organischer Fleck löst sich leicht mit einem weichen Bürstenkopf, während ein metallischer Fleck davon unbeeindruckt bleibt.
<G-vec00198-002-s238><dissolve.auflösen><en> The link between the various pictorial elements does not dissolve within a spontaneous cognitive process; rather it is meant to unsettle and confront the viewer.
<G-vec00198-002-s238><dissolve.auflösen><de> Die Verbindung zwischen den einzelnen Bildelementen löst sich nicht in einem spontanen Erkenntnisprozess auf, soll den Betrachter dagegen irritieren und konfrontieren.
<G-vec00198-002-s239><dissolve.auflösen><en> Without the regular addition of phosphates to the water, the scale inside the lead pipes will dissolve, exposing the inside of the pipe itself to the water passing through it.
<G-vec00198-002-s239><dissolve.auflösen><de> Ohne die regelmäßige Zugabe von Phosphaten löst sich der Kesselstein in den Bleirohren auf und das durchfließende Wasser kommt mit den Rohrwänden in direkten Kontakt.
<G-vec00198-002-s240><dissolve.auflösen><en> The granules completely dissolve in the tongue and have a pleasant taste, which is especially important when taking medication by young children.
<G-vec00198-002-s240><dissolve.auflösen><de> Das Granulat löst sich vollständig in der Zunge auf und hat einen angenehmen Geschmack, was vor allem bei der Einnahme von Medikamenten bei kleinen Kindern wichtig ist.
<G-vec00198-002-s241><dissolve.auflösen><en> During the day, it is recommended to drink alkaline mineral water without gas, eliminating acidosis (acid reaction of the medium), which develops after a plentiful festive feast, and drink drinks to facilitate the work of the liver: herbal tea from chamomile, cowberries, honey water (a tablespoon of honey dissolve in a glass of warm water), warm natural grape and sweet apple juice.
<G-vec00198-002-s241><dissolve.auflösen><de> Während des Tages wird empfohlen, alkalisches Mineralwasser ohne Gas zu trinken, Azidose (saure Reaktion des Mediums) zu beseitigen, die sich nach einem reichlichen festlichen Fest entwickelt, und Getränke zu trinken, um die Leberarbeit zu erleichtern: Kräutertee aus Kamille, Preiselbeeren, Honigwasser (ein Esslöffel Honig löst sich auf ein Glas warmes Wasser), warme natürliche Traube und süßer Apfelsaft.
<G-vec00198-002-s242><dissolve.auflösen><en> During the opening of the exhibition, the massive block of ice will begin to melt, and the figure of the Swiss artist will gradually dissolve right before the eyes of the visitors.
<G-vec00198-002-s242><dissolve.auflösen><de> Während der Eröffnung beginnt der massive Eisblock zu schmelzen und die Figur des Schweizer Künstlers löst sich allmählich vor den Augen der Besucher auf.
<G-vec00198-002-s243><dissolve.auflösen><en> The fragrance will gradually dissolve in the water luring the fish.
<G-vec00198-002-s243><dissolve.auflösen><de> Der Duft löst sich allmählich im Wasser, das den Fisch anlockt.
<G-vec00198-002-s247><dissolve.auflösen><en> Flavor: Strawberry Directions: Dissolve 40 g of Iso Whey in 250 ml of cold water and take it after exercise.
<G-vec00198-002-s247><dissolve.auflösen><de> Anfahrt: Man löst 40 g Iso Whey in 250 ml kaltem Wasser und trinken Sie nach dem Training.
<G-vec00198-002-s248><dissolve.auflösen><en> Presentation: Pack with 1000 g Flavor: Chocolate Directions: Dissolve 40 g of Iso Whey in 250 ml of cold water and take it after exercise.
<G-vec00198-002-s248><dissolve.auflösen><de> Präsentation: Flasche mit 1000 g Geschmack: Schokolade Anfahrt: Man löst 40 g Iso Whey in 250 ml kaltem Wasser und trinken Sie nach dem Training.
<G-vec00198-002-s268><dissolve.auflösen><en> As the water becomes more saturated with sugar, it will take longer for it to dissolve in the water.
<G-vec00198-002-s268><dissolve.auflösen><de> Da das Wasser immer stärker mit Zucker gesättigt sein wird, wird es mit der Zeit immer länger dauern, bis sich der Zucker aufgelöst hat.
<G-vec00198-002-s269><dissolve.auflösen><en> Add the beeswax and wait for it to dissolve completely.
<G-vec00198-002-s269><dissolve.auflösen><de> Fügen Sie das Bienenwachs hinzu und warten Sie, bis es sich vollständig aufgelöst hat.
<G-vec00198-002-s270><dissolve.auflösen><en> Dip into the bath and let the salts dissolve to release the luxurious ingredients.
<G-vec00198-002-s270><dissolve.auflösen><de> Tauchen Sie in das Bad und lassen Sie die Salze sich auflösen, um die luxuriösen Inhaltsstoffe freizusetzen.
<G-vec00198-002-s271><dissolve.auflösen><en> Unexpected, because these apparent differences, often leading to prejudices regarding the academic and social performance of schools such as the Pietro Mancini school, dissolve as soon as you step inside.
<G-vec00198-002-s271><dissolve.auflösen><de> Unerwartet deshalb, weil diese scheinbaren Unterschiede, die häufig Vorurteile hinsichtlich der erzieherischen und sozialen Leistung von Schulen wie der Pietro Mancini wecken, sich auflösen, sobald man die Schwelle überschreitet.
<G-vec00198-002-s272><dissolve.auflösen><en> And how mantra can also cause the subtle energy-winds to enter and dissolve in the central channel, gaining access to the subtlest energy-wind and clear light mind.
<G-vec00198-002-s272><dissolve.auflösen><de> Ich verstehen auch, wie Mantras dazu führen können, dass subtile Energiewinde in den Zentralkanal eintreten und sich dort auflösen, um Zugang zum subtilsten Energiewind und dem Geist des klaren Lichts zu herhalten.
<G-vec00198-002-s273><dissolve.auflösen><en> During the first part (trés vitement), we accompany an adolescent romping around; the second part (gravement) which its rich and plentiful chords represents the abundance of life lived at its fullest, whereas the third part (lentement), in which the chords dissolve into Arpeggios-like ornaments in harmony with a slowly descending bass, reminds us of old age.
<G-vec00198-002-s273><dissolve.auflösen><de> Albert Schweitzer hat die Fantasie so gedeutet, daß die drei Teile die menschlichen Alterstufen darstellen: Im ersten Teil (très vitement) haben wir den jungen Springinsfeld vor uns, im zweiten Teil (lentement), wo sich die Akkorde nun in arpeggiohaften Figuren über einen langsam herabsteigenden Bass auflösen, das hohe Alter.
<G-vec00198-002-s274><dissolve.auflösen><en> Since the membranes are made of fat, and these solvents dissolve in fat, it is understandable why PCBs and benzene accumulate there and why the white cells then lose their special powers.
<G-vec00198-002-s274><dissolve.auflösen><de> Da diese Membranen aus Fett bestehen und diese Lösungsmittel sich in Fett auflösen, versteht man warum die PCBs und das Benzol sich dort akkumulieren, und warum die weißen Blutkörperchen dann ihre besonderen Fähigkeiten verlieren.
<G-vec00198-002-s275><dissolve.auflösen><en> When you take a closer look, you can see that is based on the logic of the Gründerzeit’s suite of rooms, whose spatial borders dissolve in modern openness.
<G-vec00198-002-s275><dissolve.auflösen><de> Bei genauerem Hinsehen folgt er der Logik gründerzeitlicher Zimmerfluchten, deren Raumgrenzen sich in moderner Offenheit auflösen.
<G-vec00198-002-s276><dissolve.auflösen><en> Gonné’s works originate to an experimental field between religion and mass consumption, which tickles in the double standards of the believer or the consumer and dissolve the borders between cult object and mass product.
<G-vec00198-002-s276><dissolve.auflösen><de> Bekannte Formen, Produkte, Wörter und Symbole werden in unbekannten, scheinbar falschen Kontexten arrangiert, wodurch sich die Grenzen zwischen Kultobjekt und Massenprodukt sowie Gläubiger und Konsument auflösen.
<G-vec00198-002-s277><dissolve.auflösen><en> Description Achieve natural pearly whites with Mr Blanc's Express Teeth Whitening Strips, a supply of peroxide-free whitening strips that dissolve on the teeth to safely whiten and brighten your smile, on-the-go.
<G-vec00198-002-s277><dissolve.auflösen><de> Du kannst natürlich weiße Beißerchen erzielen mit Mr Blanc Express Zahnweißstreifen, einem Vorrat von peroxidfreien Zahnweißstreifen, die sich auf den Zähnen auflösen, um dein Lächeln unterwegs sicher weiß zu machen und aufzuhellen.
<G-vec00198-002-s278><dissolve.auflösen><en> The small element is the family, it will dissolve faster than the big plate.
<G-vec00198-002-s278><dissolve.auflösen><de> Das kleine Element ist die Familie, sie wird sich schneller auflösen als die große Platte.
<G-vec00198-002-s279><dissolve.auflösen><en> These are meant to be put under the tongue so that they can dissolve.
<G-vec00198-002-s279><dissolve.auflösen><de> Diese sollen unter die Zunge gelegt werden, so dass sie sich auflösen kann.
<G-vec00198-002-s280><dissolve.auflösen><en> Our TIPS are recyclable and may be disposed of via the toilet as they dissolve in the water (like toilet paper) and will not clog the toilet..
<G-vec00198-002-s280><dissolve.auflösen><de> Unsere TIPS sind recycelbar und dürfen über die Toilette entsorgt werden, da sie sich im Wasser auflösen (wie Toilettenpapier) und die Toilette nicht verstopfen.
<G-vec00198-002-s281><dissolve.auflösen><en> Once activated, then on the second stage of anuttarayoga practice, the complete stage, you employ various methods to unblock the channel-knots and to cause the energy-winds to enter, abide, and dissolve in the central energy-channel.
<G-vec00198-002-s281><dissolve.auflösen><de> Ist es einmal aktiviert, benutzt man auf der zweiten Stufe der Anuttarayoga-Praxis, der Vollständigkeitsstufe, verschiedenste Methoden, um die Blockaden der Kanalknoten zu beseitigen und die Energiewinde in den Zentralkanal eintreten, dort verbleiben und sich auflösen zu lassen.
<G-vec00198-002-s282><dissolve.auflösen><en> That would be simple enough. He could add detergent to the containers and their cell membranes would dissolve.
<G-vec00198-002-s282><dissolve.auflösen><de> Nichts leichter als das: er brauchte bloß Detergentien in die Behälter zu träufeln, und ihre Zellmembranen würden sich auflösen.
<G-vec00198-002-s283><dissolve.auflösen><en> The video shows them swiping and zooming through the images on an iPad, identifying relatives and reconstructing lineages that dissolve in the soundtrack’s rhythms.
<G-vec00198-002-s283><dissolve.auflösen><de> Im Video wischen und zoomen sie sich auf einem iPad durch das Material, identifizieren Verwandte und rekonstruieren Familienlinien, die sich in den Rhythmen des Soundtracks auflösen.
<G-vec00198-002-s284><dissolve.auflösen><en> Granulates, which are compressed to form tablets, should be as hydrophilic as possible to ensure that they are easily wetted and dissolve quickly.
<G-vec00198-002-s284><dissolve.auflösen><de> Granulate, die zu Tabletten gepresst werden, sollten möglichst hydrophil sein, damit sie gut benetzt werden und sich schnell auflösen.
<G-vec00198-002-s285><dissolve.auflösen><en> Then, this wafer is subjected to directed beams of gallium atoms and arsenic molecules that dissolve in the gallium droplets.
<G-vec00198-002-s285><dissolve.auflösen><de> Danach wird dieser Wafer mit gerichteten Strahlen aus Galliumatomen und Arsenmolekülen bedampft, die sich in den Galliumtröpfchen auflösen.
<G-vec00198-002-s286><dissolve.auflösen><en> BioSilicon's semiconductor properties enable it to dissolve in the body at a controlled rate while slowly releasing drugs over hours, days, months, or even years.
<G-vec00198-002-s286><dissolve.auflösen><de> BioSilicon kann sich dank seiner Halbleitereigenschaften im Körper mit kontrollierter Geschwindigkeit auflösen und dabei über Stunden, Tage, Monate oder sogar Jahre hinweg langsam Medikamente freisetzen.
<G-vec00198-002-s287><dissolve.auflösen><en> On the contrary, after the stressful day at work my body longs for relaxation and my thoughts want to dissolve into mist.
<G-vec00198-002-s287><dissolve.auflösen><de> Im Gegenteil, nach dem stressigen Arbeitstag sehnt mein Körper sich nach Entspannung und meine Gedanken wollen sich in Nebel auflösen.
<G-vec00198-002-s288><dissolve.auflösen><en> Allow the salt to dissolve in the water before use.
<G-vec00198-002-s288><dissolve.auflösen><de> Lasse das Salz sich vor Gebrauch in dem Wasser auflösen.
<G-vec00198-002-s289><dissolve.auflösen><en> Combine the sugar and water in a small saucepan and bring to a boil over medium-high heat, stirring often to dissolve the sugar.
<G-vec00198-002-s289><dissolve.auflösen><de> Den Zucker und das Wasser in einen Topf geben und bei mittlerer Hitze aufkochen lassen, damit sich der Zucker auflöst.
<G-vec00198-002-s290><dissolve.auflösen><en> The next 12 months could be pivotal in determining whether this compact will be strengthened or will slowly dissolve.
<G-vec00198-002-s290><dissolve.auflösen><de> Die nächsten 12 Monate könnten ausschlaggebend für die Feststellung sein, ob dieser Vertrag gestärkt wird oder sich langsam auflöst.
<G-vec00198-002-s291><dissolve.auflösen><en> When making this solution, use hot water to help the baking soda dissolve more easily.
<G-vec00198-002-s291><dissolve.auflösen><de> Benutze bei der Herstellung dieser Lösung heißes Wasser, damit sich das Natron leichter auflöst.
<G-vec00198-002-s292><dissolve.auflösen><en> Stirring the mixture as it heats up promotes even heat distribution and will encourage the sugar to dissolve more swiftly.
<G-vec00198-002-s292><dissolve.auflösen><de> Indem du die Mischung umrührst, während sie sich erhitzt, stellst du sicher, dass die Hitze gleichmäßig verteilt wird und der Zucker sich schneller auflöst.
<G-vec00198-002-s293><dissolve.auflösen><en> Keep adding sugar until no more will dissolve.
<G-vec00198-002-s293><dissolve.auflösen><de> Gib weiteren Zucker hinein, bis er sich nicht mehr auflöst.
<G-vec00198-002-s294><dissolve.auflösen><en> Wave Just like a single wave will dissolve in the endless ocean, the Wave wall light fixture will blend effortlessly with both traditional and contemporary interior designs.
<G-vec00198-002-s294><dissolve.auflösen><de> Wave So wie eine einzige Welle sich im unendlichen Ozean auflöst, verschmilzt die Wandleuchte Wave perfekt mit sowohl traditionellen als auch modernen Inneneinrichtungen.
<G-vec00198-002-s295><dissolve.auflösen><en> Paparazzi reserves the right to terminate all Consultant Agreements upon 30 days notice if the Company elects to: (1) cease business operations; (2) dissolve as a business entity; or (3) terminate distribution of its products and/or services via direct selling channels.
<G-vec00198-002-s295><dissolve.auflösen><de> Talk Fusion behält sich das Recht vor, alle Geschäftspartnerverträge mit einer Frist von 30 Tagen zu kündigen, wenn das Unternehmen: (1) den Geschäftsbetrieb einstellt; (2) sich als Geschäftseinheit auflöst oder (3) den Vertrieb seiner Produkte und/oder Services über Direktvertriebskanäle einstellt.
<G-vec00198-002-s296><dissolve.auflösen><en> Formula - Our proprietary formula utilizes a quick-melt technology to provide you with a great tasting tablet that will dissolve in less than 1 minute.
<G-vec00198-002-s296><dissolve.auflösen><de> Bei unserer neuen proprietären Wirkstoffkombination machen wir uns die Quick-Melt-Technologie zunutze, um Ihnen eine großartig schmeckende Sublingual-Tablette anzubieten, die sich in weniger als 1 Minute auflöst.
<G-vec00198-002-s297><dissolve.auflösen><en> After Christian had cut open the diesel tank 2 years ago in the boatyard (in order to clean out the goo that had accumulated over 25 years) he resealed the tank with red silicone which now started to dissolve.
<G-vec00198-002-s297><dissolve.auflösen><de> Nachdem Christian den Tank vor 2 Jahren in der Werft aufgeschnitten hatte (um den Dreck von 25 Jahren raus zu putzen), versiegelte er den Tank mit rotem Silikon, das jetzt begann sich aufzulösen.
<G-vec00198-002-s298><dissolve.auflösen><en> Moksha can simultaneously be understood as a literal spiritual “breakthrough” after which the mysteries of existence seem to dissolve, or as a purposefully maintained state that recognizes the need for compassion, selflessness and acceptance.
<G-vec00198-002-s298><dissolve.auflösen><de> „Moksha“ kann sowohl als tatsächlicher spiritueller „Durchbruch“ verstanden werden, nach dem sich die Mysterien des Seins aufzulösen scheinen als auch als bewusst beibehaltenes Stadium, in dem du die Bedeutung von Mitgefühl, Selbstlosigkeit und Akzeptanz erkennst.
<G-vec00198-002-s299><dissolve.auflösen><en> In all these processes, the flocculant powder can be in contact with the slurry for a considerable time before it needs to complete its flocculation effect, and so there is time for the powder to dissolve.
<G-vec00198-002-s299><dissolve.auflösen><de> In allen diesen Verfahren kann das Ausflockungsmittel-Pulver für eine beträchtliche Zeitspanne mit der Aufschlämmung in Kontakt sein, bevor es seinen Ausflockungs- Effekt vervollständigen muss, und somit hat das Pulver Zeit, sich aufzulösen.
<G-vec00198-002-s300><dissolve.auflösen><en> But, since bilirubin indirect in water does not have the property to dissolve, even with its significant increase in the analysis there will be no deviations from the norm.
<G-vec00198-002-s300><dissolve.auflösen><de> Da Bilirubin, das in Wasser indirekt ist, nicht die Eigenschaft hat, sich aufzulösen, wird es selbst bei einer signifikanten Zunahme der Analyse keine Abweichungen von der Norm geben.
<G-vec00198-002-s301><dissolve.auflösen><en> Dental decay is an infection in your tooth where the enamel begins to dissolve in response to acid produced by bacteria.
<G-vec00198-002-s301><dissolve.auflösen><de> Zahnverfall ist eine Infektion im Zahn, bei der der Zahnschmelz aufgrund von Bakterienverfall beginnt, sich aufzulösen .
<G-vec00198-002-s302><dissolve.auflösen><en> The problem is that everything threatens to dissolve.
<G-vec00198-002-s302><dissolve.auflösen><de> Das Problem ist, dass alles sich aufzulösen droht.
<G-vec00198-002-s303><dissolve.auflösen><en> The way these emerge from the surface depends on the colourway in question: some have a pronounced graphic look, others seem to dissolve into the background and have a melange expression.
<G-vec00198-002-s303><dissolve.auflösen><de> Wie sich diese von der Oberfläche abheben, hängt von der jeweiligen Farbkombination ab: Einige verfügen über einen deutlich grafischen Look, andere scheinen sich im Hintergrund aufzulösen und bilden einen Mélange-Effekt.
<G-vec00198-002-s304><dissolve.auflösen><en> The method of use is quite simple, enough of the right amount of the drug to dissolve in water and drink a few sips.
<G-vec00198-002-s304><dissolve.auflösen><de> Die Methode der Verwendung ist ziemlich einfach, genug der richtigen Menge des Medikaments, um sich in Wasser aufzulösen und ein paar Schlucke zu trinken.
<G-vec00198-002-s305><dissolve.auflösen><en> However, as from a certain pH value not only the building material is absent, the calcification process itself becomes increasingly more difficult and the lime shells even start to dissolve.
<G-vec00198-002-s305><dissolve.auflösen><de> Ab einem bestimmten pH-Wert fehlt jedoch nicht nur der Baustoff und die Kalkbildung wird immer schwieriger, sondern die Kalkschalen beginnen sogar sich aufzulösen.
<G-vec00198-002-s306><dissolve.auflösen><en> The granite-covered rest area appears to dissolve in the water.
<G-vec00198-002-s306><dissolve.auflösen><de> Der granitbedeckte Sitzplatz scheint sich im Wasser aufzulösen.
<G-vec00198-002-s307><dissolve.auflösen><en> In this practice we create form in order to allow it to dissolve in giving it away.
<G-vec00198-002-s307><dissolve.auflösen><de> In dieser Praxis kreieren wir Form, um ihr zu erlauben, sich aufzulösen, indem wir sie weggeben.
<G-vec00198-002-s308><dissolve.auflösen><en> The central committee asked the Social Democratic members of the Soviet: (1) to invite the soviet to accept the RSDLP’s program and, when this was done, to recognise the leadership of the party and “ultimately dissolve in it”; (2) if the soviet refused to accept the program, to leave the soviet and expose the anti-proletarian nature of such organisations; (3) if the soviet, while refusing to accept the program, reserved to itself the right to decide its political stand in every case as it came up, to stay in the soviet but reserve the right to speak out on “the absurdity of such political leadership.”
<G-vec00198-002-s308><dissolve.auflösen><de> Das Zentralkomitee bat die sozialdemokratischen Mitglieder des Sowjets darum: (1) den Sowjet einzuladen, das Programm der SDAPR anzunehmen und, wenn das einmal gemacht worden sei, die Führung der Partei anzuerkennen und „sich schließlich in sie aufzulösen“; (2) falls der Sowjet es ablehne, das Programm anzunehmen, den Sowjet zu verlassen und das antiproletarische Wesen solcher Organisationen zu entlarven; (3) wenn der Sowjet, während er es ablehne, das Programm anzunehmen, sich das Recht vorbehalte, seine politischen Standpunkt in jedem Fall zu entscheiden, als er auftauche, im Sowjet zu bleiben aber sich das Recht vorzubehalten, über „die Absurdität einer solchen politischen Führung“ auszusagen.
<G-vec00198-002-s309><dissolve.auflösen><en> Under siege from the people, the Assembly had no alternative but to suspend the king and dissolve itself.
<G-vec00198-002-s309><dissolve.auflösen><de> Unter der Belagerung des Volkes hatte die Versammlung keine andere Wahl, als den König zu suspendieren und sich aufzulösen.
<G-vec00198-002-s310><dissolve.auflösen><en> Everything wavered, like the trees were only the ideas of trees, as ephemeral as a painting, threatening to dissolve if Christy merely reached out and touched them.
<G-vec00198-002-s310><dissolve.auflösen><de> Alles war in Bewegung, so als wären die Bäume nur Ideen von Bäumen, so vergänglich wie ein Gemälde, das drohte, sich aufzulösen, wenn Christy es berührte.
<G-vec00198-002-s311><dissolve.auflösen><en> In chemistry: mixing of two substances that cannot dissolve each other completely or react with each other completely.
<G-vec00198-002-s311><dissolve.auflösen><de> In der Chemie: Mischung von zwei Substanzen, die sich gegenseitig nicht komplett lösen oder nicht vollständig miteinander chemisch reagieren können.
<G-vec00198-002-s312><dissolve.auflösen><en> Furthermore, in such event Quantum Courage is also entitled to dissolve the contract.
<G-vec00198-002-s312><dissolve.auflösen><de> Im Übrigen ist in diesem Fall auch der Anbieter berechtigt, sich vom Vertrag zu lösen.
<G-vec00198-002-s313><dissolve.auflösen><en> After all, as scientists have already known for a long time, a mineral surface acquires a charge if it is dampened with static water because some ions dissolve better than others.
<G-vec00198-002-s313><dissolve.auflösen><de> Denn wie Wissenschaftler bereits lange wissen, lädt sich eine mineralische Oberfläche auch auf, wenn sie von unbewegtem Wasser benetzt wird, weil sich dabei manche Ionen besser lösen als andere.
<G-vec00198-002-s314><dissolve.auflösen><en> CAUTION: Using too much laser power or resolution which is too high can tear the fabric or dissolve the fibers, immediately or after the first wash at the latest.
<G-vec00198-002-s314><dissolve.auflösen><de> ACHTUNG: Bei zu viel Laserleistung oder einer zu hohen Auflösung kann der Stoff sofort oder spätestens nach dem ersten Waschgang reißen bzw können sich Fasern lösen.
<G-vec00198-002-s315><dissolve.auflösen><en> A fortified in this way Kickstarter will no longer dissolve in the operation and the toothing lasts forever.
<G-vec00198-002-s315><dissolve.auflösen><de> Ein auf diese Art befestigter Kickstarter wird sich im Betrieb nicht mehr lösen und die Verzahnung hält ewig.
<G-vec00198-002-s316><dissolve.auflösen><en> After this I used a mortar for mixing, to finen the pigments in order to allow it to dissolve better.
<G-vec00198-002-s316><dissolve.auflösen><de> Im Anschluss habe ich alles in einem Mörser vermengt, damit die Pigmente noch feiner werden und sich besser lösen.
<G-vec00198-002-s317><dissolve.auflösen><en> The term "sufficiently water-soluble" means that the agents readily dissolve in the other ingredients of the composition (and separation avoid thereof).
<G-vec00198-002-s317><dissolve.auflösen><de> Der Begriff "hinreichend wasserlöslich" bedeutet, dass sich die Mittel leicht in den anderen Bestandteilen der Zusammensetzung lösen (und Abtrennung davon vermeiden).
<G-vec00198-002-s318><dissolve.auflösen><en> As a dust collector, a container of water is used in them, passing through which dust particles dissolve and settle in it.
<G-vec00198-002-s318><dissolve.auflösen><de> Als Staubsammler verwenden sie einen Behälter mit Wasser, durch den Staubpartikel sich lösen und darin absetzen.
<G-vec00198-002-s319><dissolve.auflösen><en> It is unclear whether the particles released are stable in the environment or dissolve completely in a certain time or under certain conditions.
<G-vec00198-002-s319><dissolve.auflösen><de> Es ist unklar, ob freigesetzte Partikel in der Umwelt stabil sind oder sich in einer bestimmten Zeit oder unter bestimmten Bedingungen komplett lösen.
<G-vec00198-002-s323><dissolve.auflösen><en> Stirring to dissolve sugar.
<G-vec00198-002-s323><dissolve.auflösen><de> Zucker um Wasser auflösen.
<G-vec00198-002-s324><dissolve.auflösen><en> This is not yet sufficient, however; while the film former should initially be soluble or dispersible in water, the coating must not dissolve.
<G-vec00198-002-s324><dissolve.auflösen><de> Denn obwohl der Filmbildner zunächst in Wasser löslich oder dispergierbar sein soll, darf sich die Beschichtung später nicht mehr in Wasser auflösen.
<G-vec00198-002-s329><dissolve.auflösen><en> Citric acid has a very low pH value which means it is able to dissolve deposits.
<G-vec00198-002-s329><dissolve.auflösen><de> Zitronensäure hat durch ihren sehr niedrigen pH-Wert die Eigenschaft, entstandene Beläge wieder aufzulösen.
<G-vec00198-002-s330><dissolve.auflösen><en> As citric acid has a very low pH-value it is able to dissolve limescale deposits.
<G-vec00198-002-s330><dissolve.auflösen><de> Zitronensäure hat durch ihren sehr niedrigen pH-Wert die Eigenschaft, entstandene Kalkbeläge wieder aufzulösen.
<G-vec00198-002-s331><dissolve.auflösen><en> I am writing this down, because I want those goofballs, who are cursing my website to understand that for us, it is a pleasurable activity to dissolve their curses.
<G-vec00198-002-s331><dissolve.auflösen><de> Ich schreib das deswegen so, damit die Knalltüten, die sich anstrengen müssen um meine Webseite zu verhexen, verstehen, dass es für uns ein genüssliches Tun ist, es wieder aufzulösen.
<G-vec00198-002-s135><dissolve.kündigen><en> When purchasing products, a consumer has the right to dissolve a contract, without giving reasons, during a period of at least 14 days.
<G-vec00198-002-s135><dissolve.kündigen><de> Bei der Lieferung von Produkten: Beim Kauf von Produkten, hat der Verbraucher die Möglichkeit, den Vertrag ohne Angabe von Gründen innerhalb von 14 Tagen kündigen.
<G-vec00198-002-s136><dissolve.kündigen><en> The Consumer can dissolve the contract as long as this acceptance has not been confirmed by the Trader.
<G-vec00198-002-s136><dissolve.kündigen><de> Solange der Empfang der Angebotsannahme nicht bestätigt ist, kann der Verbraucher den Vertrag kündigen.
<G-vec00198-002-s137><dissolve.kündigen><en> The Client can dissolve the Agreement in accordance with paragraph 1 of this article by reporting the withdrawal (digital or in other form) to GBL Europe BV, within the withdrawal period, by means of the model form for right of withdrawal or in some other unequivocal way.
<G-vec00198-002-s137><dissolve.kündigen><de> Der Besteller kann diesen Vertrag gemäß dem Absatz 1 dieses Artikels durch die Meldung des Rücktritts (in digitaler oder anderer Form) an die Gesellschaft GBL Europe BV innerhalb des Rücktrittszeitraumes mit Hilfe des Musters des Formulars für Rücktritt vom Vertrag oder auf eine andere eindeutige Art und Weise kündigen.
<G-vec00198-002-s138><dissolve.kündigen><en> As long as the receipt of this acceptance has not been confirmed by the entrepreneur, the consumer can dissolve the agreement.
<G-vec00198-002-s138><dissolve.kündigen><de> Solange der Unternehmer den Erhalt dieser Annahme nicht bestätigt hat, kann der Verbraucher den Vertrag kündigen.
<G-vec00198-002-s139><dissolve.kündigen><en> With the purchase of our products, the consumer has the ability to dissolve the contract, without giving reasons for 14 days.
<G-vec00198-002-s139><dissolve.kündigen><de> Mit dem Kauf unserer Produkte hat der Verbraucher die Möglichkeit, den Vertrag zu kündigen, ohne Angabe von Gründen 14 Tage.
<G-vec00198-002-s327><dissolve.widerrufen><en> When purchasing products, the consumer has the ability to dissolve the contract without giving any reason for 14 days.
<G-vec00198-002-s327><dissolve.widerrufen><de> Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen.
