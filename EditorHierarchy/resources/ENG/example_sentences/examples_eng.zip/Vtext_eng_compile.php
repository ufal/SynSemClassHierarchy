<G-vec00709-002-s142><compile.kompilieren><en> Click the Compile button to check to see that the files compile without errors.
<G-vec00709-002-s142><compile.kompilieren><de> Klicken Sie auf kompilieren, um zu überprüfen, dass die Dateien fehlerfrei kompilieren.
<G-vec00709-002-s144><compile.kompilieren><en> Compile and sign the client application provided in source code.
<G-vec00709-002-s144><compile.kompilieren><de> Kompilieren und signieren Sie die als Quellcode bereitgestellte Clientanwendung.
<G-vec00709-002-s145><compile.kompilieren><en> This website uses the following third-party cookies: Google Analytics: Stores cookies to compile statistics on the volume of traffic and visitors of this website.
<G-vec00709-002-s145><compile.kompilieren><de> Diese Website verwendet die folgenden Cookies von Drittanbietern: Google Analytics: Speichert Cookies, um Statistiken über den Verkehr und das Volumen der Besuche dieses Web zu kompilieren.
<G-vec00709-002-s146><compile.kompilieren><en> We compile shaders into a program representation that is independent of the shading language, the renderer, and the target hardware platform.
<G-vec00709-002-s146><compile.kompilieren><de> Wir kompilieren Shader zu einem Programmkonstrukt, das von der Shading-Sprache, dem Renderer und der angedachten Hardware-Plattform unabhängig ist.
<G-vec00709-002-s147><compile.kompilieren><en> Installation Install kdelibs (version 4.0 or higher) provided by your Operating System or compile it according to these KDE4 intructions.
<G-vec00709-002-s147><compile.kompilieren><de> 6 Quellcode Installation Installieren Sie kdelibs (Version 4.0 oder höher) von Ihrem Betriebssystem oder kompilieren Sie es anhand dieserAnweisungen.
<G-vec00709-002-s148><compile.kompilieren><en> Using this is very easy, all you need to do is compile some units, and use these units in your program.
<G-vec00709-002-s148><compile.kompilieren><de> Mit diesem Beispiel ist es sehr einfach, alles was Sie tun müssen, ist das kompilieren einiger Units und diese Units können Sie dann in Ihrem Programm verwenden.
<G-vec00709-002-s149><compile.kompilieren><en> Last, you'll have to compile your work.
<G-vec00709-002-s149><compile.kompilieren><de> Zum Schluß mußt du deine Arbeit kompilieren.
<G-vec00709-002-s150><compile.kompilieren><en> For the more adventurous there is an easy way to compile your own custom kernel on Debian.
<G-vec00709-002-s150><compile.kompilieren><de> Für alle Experimentierfreudigen gibt es einen einfachen Weg, einen eigenen angepassten Kernel unter Debian zu kompilieren.
<G-vec00709-002-s151><compile.kompilieren><en> Makes the application compile faster, but causes problems if you change the source code and try to compile again.
<G-vec00709-002-s151><compile.kompilieren><de> Beschleunigt das Kompilieren des Programms, verursacht aber Fehler wenn du etwas am Quelltext änderst und nochmal kompilieren willst.
<G-vec00709-002-s152><compile.kompilieren><en> compile and install the mix software
<G-vec00709-002-s152><compile.kompilieren><de> Kompilieren und installieren der Mix Software.
<G-vec00709-002-s153><compile.kompilieren><en> With it, you can collect form data automatically and compile it in a table format.
<G-vec00709-002-s153><compile.kompilieren><de> Sie können damit Formulardaten automatisch erfassen und sie in einem Tabellenformat kompilieren.
<G-vec00709-002-s154><compile.kompilieren><en> This allows for the transfer of project files with specific rule definitions to a different user and/or BAE installation without having to transfer and compile the referenced rule definitions in a separate step.
<G-vec00709-002-s154><compile.kompilieren><de> Damit ist es nun auch möglich, Dateien, die eigene Regeldefinitionen verwenden, an einen anderen Anwender weiterzugeben, ohne dass dieser die Regeldefinitionen auf seine Installation übertragen und kompilieren müsste.
<G-vec00709-002-s155><compile.kompilieren><en> To compile it you need some development environment for your platform, Gammu and Python.
<G-vec00709-002-s155><compile.kompilieren><de> Zum Kompilieren benötigen Sie eine Entwicklungsumgebung für Ihre Plattform, Gammu und Python.
<G-vec00709-002-s156><compile.kompilieren><en> The Compile window did not appear for an invalid script.
<G-vec00709-002-s156><compile.kompilieren><de> Das Fenster zum Kompilieren erschien für ein ungültiges Skript nicht.
<G-vec00709-002-s157><compile.kompilieren><en> Extract the file as root user into your /usr/src/ directory and compile it your self.
<G-vec00709-002-s157><compile.kompilieren><de> Die Datei als root-Benutzer ins /usr/src/-Verzeichnis entpacken und dort kompilieren.
<G-vec00709-002-s158><compile.kompilieren><en> Should now compile and run on OS X.
<G-vec00709-002-s158><compile.kompilieren><de> Sollte nun kompilieren und ausführen unter OS X.
<G-vec00709-002-s159><compile.kompilieren><en> In the first post of this litte blog series I showed you how to install SASS manually and how to compile it using the terminal.
<G-vec00709-002-s159><compile.kompilieren><de> Im ersten Beitrag dieser kleinen Beitragsreihe habe ich euch gezeigt, wie ihr SASS installieren und manuell mit dem Terminal kompilieren könnt.
<G-vec00709-002-s160><compile.kompilieren><en> If you want Big Content to be displayed on iOS devices, then compile the receiving solution as an AppStore App.
<G-vec00709-002-s160><compile.kompilieren><de> Wenn großer Inhalt auch auf iOS-Geräten angezeigt werden soll, kompilieren Sie die empfangende Lösung als AppStore App.
<G-vec00709-002-s161><compile.kompilieren><en> Note: You must make some entry in the Subject box in order for the workflow to compile correctly.
<G-vec00709-002-s161><compile.kompilieren><de> Hinweis: Sie müssen etwas im Feld Betreff eingeben, damit der Workflow ordnungsgemäß kompiliert werden kann.
<G-vec00709-002-s162><compile.kompilieren><en> With RPM, you have the pristine sources along with patches that we used to compile from.
<G-vec00709-002-s162><compile.kompilieren><de> Mit RPM hat man sowohl die Originalquellen als auch den Patch, von dem kompiliert wurde.
<G-vec00709-002-s163><compile.kompilieren><en> Clicking 'Save and Exit' stores your choices on disk, and once this is done you can finally compile and install the kernel (as in Figure 40).
<G-vec00709-002-s163><compile.kompilieren><de> Durch Anklicken von Save and Exit werden die Einstellungen auf Platte gesichert, danach kann dann endlich der Kernel kompiliert und installiert werden (siehe Abbildung 40).
<G-vec00709-002-s164><compile.kompilieren><en> These static interfaces are still supported, to allow adapters that were developed in previous versions of the product to compile and deploy.
<G-vec00709-002-s164><compile.kompilieren><de> Diese statischen Schnittstellen werden weiter unterstützt, damit in Vorgängerversionen des Produkts entwickelte Adapter kompiliert und implementiert werden können.
<G-vec00709-002-s165><compile.kompilieren><en> The build step will actually compile all of the source code and produce the output images.
<G-vec00709-002-s165><compile.kompilieren><de> Im Schritt Build wird der Quellcode kompiliert und die Image-Dateien werden erzeugt.
<G-vec00709-002-s210><compile.zusammenstellen><en> So is our evidence-based approach to diagnostic: We compile for you a range of contemporary tests specially geared to your issue.
<G-vec00709-002-s210><compile.zusammenstellen><de> Unser Evidenz-basiertes Vorgehen ist es ebenfalls: Wir stellen eine Palette zeitgemäßer Tests für Sie zusammen, die auf Ihre individuelle Fragestellung zugeschnitten ist.
<G-vec00709-002-s211><compile.zusammenstellen><en> We compile porn videos on all major sites for you.
<G-vec00709-002-s211><compile.zusammenstellen><de> Wir stellen für Sie Porno-Videos auf allen wichtigen Seiten zusammen.
<G-vec00709-002-s212><compile.zusammenstellen><en> You can compile your own personal timetable as a PDF file here or for use on your mobile phone.
<G-vec00709-002-s212><compile.zusammenstellen><de> Dann stellen Sie sich hier Ihren individuellen Fahrplan als PDF-Datei oder auch direkt für Ihr Handy zusammen.
<G-vec00709-002-s213><compile.zusammenstellen><en> Together with you we compile a service package according to your wishes and requirements.
<G-vec00709-002-s213><compile.zusammenstellen><de> Gemeinsam mit Ihnen stellen wir ein Leistungspaket entsprechend Ihrer Wünsche und Anforderungen zusammen.
<G-vec00709-002-s214><compile.zusammenstellen><en> Or we can compile your documents for you into complete documentation.
<G-vec00709-002-s214><compile.zusammenstellen><de> Oder wir stellen Ihnen Ihre Dokumente zu Gesamtdokumentationen zusammen.
<G-vec00709-002-s215><compile.zusammenstellen><en> Every year, we compile a new hiking program for the spring and autumn.
<G-vec00709-002-s215><compile.zusammenstellen><de> Jedes Jahr stellen wir ein neues Wanderprogramm für Frühling und Herbst zusammen.
<G-vec00709-002-s216><compile.zusammenstellen><en> We would be happy to compile a free information package for you or to discuss your concrete needs in a free-of-charge online dialog.
<G-vec00709-002-s216><compile.zusammenstellen><de> Gern stellen wir ein kostenloses Informationspaket für Sie zusammen oder erörtern mit Ihnen gemeinsam in einem kostenfreien Online-Dialog Ihren konkreten Bedarf.
<G-vec00709-002-s217><compile.zusammenstellen><en> We can compile a suitable investment universe for you, whether you choose to base this on a sustainability concept using positive and/or negative criteria or on particular regions or issues.
<G-vec00709-002-s217><compile.zusammenstellen><de> Ob auf Basis eines Nachhaltigkeitskonzeptes mit Positiv- und/oder Negativkriterien oder im Hinblick auf bestimmte Regionen und Themen – wir stellen Ihnen das für Sie passende Anlageuniversum zusammen.
<G-vec00709-002-s218><compile.zusammenstellen><en> Compile your own present and wrap it in this beautiful white Dirkje gift box.
<G-vec00709-002-s218><compile.zusammenstellen><de> Stellen Sie Ihr eigenes Geschenk zusammen und verpacken Sie es in dieser schönen, weißen Dirkje Geschenkbox.
<G-vec00709-002-s219><compile.zusammenstellen><en> We’d be happy to compile a special menu or buffet for you, tailor-made to your express requirements.
<G-vec00709-002-s219><compile.zusammenstellen><de> Gerne stellen wir Ihnen auch ein ganz persönliches Menü oder Buffet aus unserer Küche zusammen.
<G-vec00709-002-s220><compile.zusammenstellen><en> You compile the necessary documents and complete the application form.
<G-vec00709-002-s220><compile.zusammenstellen><de> Sie stellen die benötigten Unterlagen zusammen und füllen das Antragsformular aus.
<G-vec00709-002-s221><compile.zusammenstellen><en> From Second World War books to Disney comic collections, thirst quenching wine guides to beautifully illustrated nature books, we compile the collections, produce them completely in-house and give you support with promoting the end product.
<G-vec00709-002-s221><compile.zusammenstellen><de> Von Büchern über den Zweiten Weltkrieg bis zu Sammlungen von Disney Comics und von Durst machenden Weinführern zu prachtvoll illustrierten Naturbänden, wir stellen die Sammlungen zusammen, produzieren sie komplett selbst und helfen Ihnen bei der Vermarktung des fertigen Werkes.
<G-vec00709-002-s222><compile.zusammenstellen><en> Thomas Cook’s individual organizational units compile the content for specific sales and marketing campaigns and send it to the company’s central dialog marketing department.
<G-vec00709-002-s222><compile.zusammenstellen><de> Die einzelnen Organisationseinheiten von Thomas Cook stellen die Inhalte der Mailings für die jeweiligen Vertriebs- und Marketingaktionen zusammen und übermitteln diese an das zentrale Dialogmarketing.
<G-vec00709-002-s223><compile.zusammenstellen><en> Compile exactly the data you need: quickly, flexibly and easily.
<G-vec00709-002-s223><compile.zusammenstellen><de> Stellen Sie genau die Daten zusammen, die Sie benötigen: schnell, flexibel und einfach.
<G-vec00709-002-s224><compile.zusammenstellen><en> Of course, we will take care of your guests' physical needs and compile a menu in coordination with you.
<G-vec00709-002-s224><compile.zusammenstellen><de> Selbstverständlich kümmern wir uns auch um das leibliche Wohl Ihrer Gäste und stellen nach Absprache mit Ihnen ein Menü zusammen.
<G-vec00709-002-s225><compile.zusammenstellen><en> At the same time that you conduct this review, compile a list of everything that has been done and publish it.
<G-vec00709-002-s225><compile.zusammenstellen><de> Zur gleichen Zeit, zu der Sie diese Überprüfung leiten, stellen Sie eine Liste von allen Dingen zusammen, die getan worden sind, und veröffentlichen Sie diese.
<G-vec00709-002-s226><compile.zusammenstellen><en> According to your ideas and customised to your request, we compile an individual selection of cover materials, books and processing examples.
<G-vec00709-002-s226><compile.zusammenstellen><de> Ganz Ihren Vorstellungen entsprechend und zu 100% angepasst auf Ihre Anfrage, stellen wir Ihnen ganz individuell eine Auswahl an Covermaterialien, Büchern oder Veredelungsbeispielen zusammen.
<G-vec00709-002-s227><compile.zusammenstellen><en> This is how companies compile their investment portfolios.
<G-vec00709-002-s227><compile.zusammenstellen><de> Unternehmen stellen so ihr Beteiligungsportfolio zusammen.
<G-vec00709-002-s247><compile.zusammenstellen><en> We decided to dig through our previous restaurant guides and also add some places that we never featured here before even though they belong to our personal favorites to compile a list of the best affordable restaurants in Berlin.
<G-vec00709-002-s247><compile.zusammenstellen><de> Wir haben uns entschieden, unsere Restaurant-Guides durchzugehen und einige Orte hinzuzufügen, die wir hier noch nie zuvor erwähnt haben, obwohl sie zu unseren persönlichen Favoriten gehören, um eine Liste der besten günstigen Restaurants in Berlin zusammenzustellen.
<G-vec00709-002-s248><compile.zusammenstellen><en> Cookies are also used to compile statistical data on your use of our Services.
<G-vec00709-002-s248><compile.zusammenstellen><de> Cookies werden außerdem verwendet, um statistische Daten über Ihre Nutzung unserer Dienstleistungen zusammenzustellen.
<G-vec00709-002-s249><compile.zusammenstellen><en> Based on this information and on behalf of the website operator, Google will prepare reports for KTM Fahrrad GmbH about website activity and other services associated with internet use in order to analyse your use of the website and compile reports about website activity.
<G-vec00709-002-s249><compile.zusammenstellen><de> Basierend auf diesen Informationen und im Auftrag vom Website-Betreiber erstellt Google für die KTM Fahrrad GmbH Reports über die Website-Aktivitäten und weiterer mit der Internetnutzung in Verbindung stehender Dienstleistungen, um Ihre Nutzung der Website auszuwerten und um Reports über die Website-Aktivität zusammenzustellen.
<G-vec00709-002-s250><compile.zusammenstellen><en> In the game, players slip into the role of journalists in a gamified research and editorial process to compile a newspaper with news about the Demilitarized Zone in Korea and the Berlin Wall.
<G-vec00709-002-s250><compile.zusammenstellen><de> Während des Spiels schlüpfen die Spielerinnen und Spieler in einem gamifizierten Recherche- und Redaktionsvorgang in die Rolle von Journalisten, um eine Zeitung mit Nachrichten rund um die entmilitarisierte Zone in Korea und die Berliner Mauer zusammenzustellen.
<G-vec00709-002-s251><compile.zusammenstellen><en> Google Analytics uses cookies or other tracking technologies to help us analyze how users interact with and use the Services, compile reports on the Services’ activity, and provide other services related to our Services’ activity and usage.
<G-vec00709-002-s251><compile.zusammenstellen><de> Google Analytics verwendet Cookies oder sonstige Tracking-Technologien, um uns bei der Analyse zu unterstützen, wie Nutzer mit den Webseiten interagieren und diese nutzen, um Berichte über die Aktivität der Webseiten zusammenzustellen und um sonstige Dienste im Zusammenhang mit der Aktivität und der Nutzung auf unseren Webseiten bereitzustellen.
<G-vec00709-002-s270><compile.zusammenstellen><en> With us, you can compile different services according to your needs.
<G-vec00709-002-s270><compile.zusammenstellen><de> So können Sie bei uns verschiedene Dienstleistungen nach ihrem Bedarf zusammenstellen.
<G-vec00709-002-s271><compile.zusammenstellen><en> Every student has to compile his or her own timetable.
<G-vec00709-002-s271><compile.zusammenstellen><de> Jeder Studierende muss sich seinen Stundenplan selbst zusammenstellen.
<G-vec00709-002-s272><compile.zusammenstellen><en> In an intuitive user interface, they could compile the results, turn them into meaningful graphics and export them – all without having to turn to special statistical evaluation programs.
<G-vec00709-002-s272><compile.zusammenstellen><de> Die Ergebnisse konnten sie dafür in einer intuitiven Nutzeroberfläche zusammenstellen, in aussagekräftige Grafiken umwandeln und exportieren, ohne dass dafür auf gesonderte statistische Auswertungsprogramme zurückgegriffen werden musste.
<G-vec00709-002-s273><compile.zusammenstellen><en> The latter you can use if you want to compile your server according to your own requirements themselves.
<G-vec00709-002-s273><compile.zusammenstellen><de> Letztere können Sie verwenden, sofern Sie Ihren Server frei nach Ihren eigenen Ansprüchen selbst zusammenstellen wollen.
<G-vec00709-002-s274><compile.zusammenstellen><en> If the player wishes to place a bet via a text message, he must compile a string of characters, which might remind computer scientists of a Ping of a certain IP address, however, does not mean anything to anybody else.
<G-vec00709-002-s274><compile.zusammenstellen><de> Will der Spieler eine Wette per SMS abgeben, muss er eine Zeichenkette zusammenstellen, die den Informatiker vielleicht noch an einen Ping an eine bestimmte IP-Adresse erinnert, jemand anderem jedoch gar nichts sagt.
<G-vec00709-002-s275><compile.zusammenstellen><en> Compile your personal playlist, save, edit and in the end Hand it to your wedding DJ.
<G-vec00709-002-s275><compile.zusammenstellen><de> Damit aber nicht genug, denn Ihr Hochzeit DJ spielt natürlich auch Ihre Lieblingstitel, die Sie sich in einer persönlichen Playliste zusammenstellen können.
<G-vec00709-002-s276><compile.zusammenstellen><en> Here, you can reorder parts, or compile your personal piece of furniture.
<G-vec00709-002-s276><compile.zusammenstellen><de> Sie können hier Einzelteile nachordern, oder sich die Komponenten für Ihre individuelle Konfiguration zusammenstellen.
<G-vec00709-002-s277><compile.zusammenstellen><en> With eleven proposed routes, overlapping at specific junctions, the architecture fans were able to compile their own individual course – or follow the already planned trails.
<G-vec00709-002-s277><compile.zusammenstellen><de> Mit elf verschiedenen Routenvorschlägen und dank der Überschneidung an bestimmten Knotenpunkten konnten sich die Architekturbegeisterten ihre Wunschroute individuell zusammenstellen – oder vorgeplanten Routen folgen.
<G-vec00709-002-s278><compile.zusammenstellen><en> Here you will be able to compile your own personal curriculum (in German only), but also find very general information on the respective course, such as contents, venue and time or information on the lecturers.
<G-vec00709-002-s278><compile.zusammenstellen><de> Hier können Sie sich Ihren persönlichen Stundenplan zusammenstellen, aber auch ganz allgemeine Information zur jeweiligen Veranstaltung finden wie Inhalte, Ort und Zeit oder Informationen zu den Dozenten.
<G-vec00709-002-s279><compile.zusammenstellen><en> Systematic retrieval of data or other content from Local Zoo.net's website to create or compile, directly or indirectly, a collection, database or directory without written permission from Local Zoo.net is prohibited.
<G-vec00709-002-s279><compile.zusammenstellen><de> Das systematische Abrufen von Daten oder anderen Inhalten dieser Site zum Erstellen oder Zusammenstellen einer Sammlung, Zusammenstellung, Datenbank oder eines Verzeichnisses ohne schriftliche Genehmigung von Cascade Designs, Inc., ob direkt oder indirekt, ist untersagt.
<G-vec00709-002-s280><compile.zusammenstellen><en> The modular design of the software allows us to compile customised solutions for any task.
<G-vec00709-002-s280><compile.zusammenstellen><de> Durch den modularen Aufbau der Software lässt sich eine passgenaue Lösung für jede Anforderung zusammenstellen.
<G-vec00709-002-s281><compile.zusammenstellen><en> Consumers can compile their own little herb gardens with Herb_vases by combining the required number of herb vases.
<G-vec00709-002-s281><compile.zusammenstellen><de> Mit Herb_vases kann der Verbraucher selber einen Kräutergarten zusammenstellen, indem er die gewünschte Anzahl Kräutervasen miteinander kombiniert.
<G-vec00709-002-s282><compile.zusammenstellen><en> This Compilers Guide provides conceptual issues and practical information and guidance for reporting authorities to compile and report natural gas and electricity price statistics to Eurostat based on the Regulation (EU) 2016/1952.
<G-vec00709-002-s282><compile.zusammenstellen><de> Compilers Dieser Leitfaden enthält konzeptionelle und praktische Informationen und Anleitungen für Berichterstatter, die die Preisstatistik für Erdgas und Strom auf Grundlage der Verordnung (EU) 2016/1952 zusammenstellen und an Eurostat berichten.
<G-vec00709-002-s283><compile.zusammenstellen><en> You can also easily compile this information as well as further technically relevant data with the help of our support tool.
<G-vec00709-002-s283><compile.zusammenstellen><de> Sie können diese Informationen und weitere relevante technische Daten auch einfach mit Hilfe unseres Support tool zusammenstellen.
<G-vec00709-002-s284><compile.zusammenstellen><en> This way you can compile a part of the course according to your individual interests.
<G-vec00709-002-s284><compile.zusammenstellen><de> So kannst du dir einen Teil des Kurses ganz nach deinen individuellen Interessen selbst zusammenstellen.
<G-vec00709-002-s285><compile.zusammenstellen><en> It therefore enables retailers to compile their product ranges in a highly focused manner and to implement them in their own stores, ensuring the success of their business.
<G-vec00709-002-s285><compile.zusammenstellen><de> Damit können Händler zielgerichtet ihre Sortimente zusammenstellen und es im Geschäft so umsetzen, wie es vor Ort den Geschäftserfolg sicherstellt.
<G-vec00709-002-s286><compile.zusammenstellen><en> This section also allows you to select any number of advertising content from the media library and compile it into an individual campaign.
<G-vec00709-002-s286><compile.zusammenstellen><de> Sie können eine beliebige Anzahl Ihrer Inhalte aus der Medien-Bibliothek auswählen und zu einer individuellen Kampagne zusammenstellen.
<G-vec00709-002-s287><compile.zusammenstellen><en> Given the large number of certificates the average organization uses, this type of information can be difficult and tedious to compile.
<G-vec00709-002-s287><compile.zusammenstellen><de> Angesichts der großen Anzahl von Zertifikaten, die eine durchschnittliche Organisation verwendet, kann das Zusammenstellen dieser Art von Informationen schwierig und langwierig sein.
<G-vec00709-002-s288><compile.zusammenstellen><en> On the one hand, every user has access to the entire portfolio of features and components and can choose exactly the ones that best suit their individual requirements, thus allowing them to compile a custom-made PLM for the entire company.
<G-vec00709-002-s288><compile.zusammenstellen><de> Zum einen kann jeder Anwender aus dem gesamten Portfolio gezielt jene Funktionen und Bausteine auswählen, die seinen individuellen Anforderungen entsprechen und sich so ein maßgeschneidertes PLM für das gesamte Unternehmen zusammenstellen.
<G-vec00709-002-s305><compile.zusammentragen><en> Compile and analyse data and information on adaptation measures and their effectiveness towards a publicly available comprehensive, integrated knowledge base.
<G-vec00709-002-s305><compile.zusammentragen><de> Daten zu Anpassungsmaßnahmen zusammentragen und analysieren und diese auf ihre Wirksamkeit bezüglich einer zugänglichen, verständlichen und integrativen Wissensbasis untersuchen.
<G-vec00709-002-s306><compile.zusammentragen><en> You may also compile keywords which you want to build in your article.
<G-vec00709-002-s306><compile.zusammentragen><de> Genauso kannst Du auch Keywords zusammentragen, die Du im Artikel einbauen willst.
<G-vec00709-002-s307><compile.zusammentragen><en> The project will compile all data to species and habitat diversity in a database that will serve amongst others to gain a typology of habitats for sustainable land-use and nature conservation purposes.
<G-vec00709-002-s307><compile.zusammentragen><de> Das Projekt wird die vorhandenen Diversitätsdaten in einer Datenbank zusammentragen, die unter anderem der für die nachhaltige Bewirtschaftung und den Naturschutz dringend erforderlichen Typisierung der Habitate dient.
<G-vec00709-002-s308><compile.zusammentragen><en> Otherwise, you may need to compile this information yourself.
<G-vec00709-002-s308><compile.zusammentragen><de> Anderenfalls müssen Sie diese Informationen selbst zusammentragen.
<G-vec00709-002-s328><compile.zusammentragen><en> To compile and report to third parties (like advertisers) aggregated statistics about our users in terms of numbers, traffic patterns, and information related to the site.
<G-vec00709-002-s328><compile.zusammentragen><de> Um zusammenzutragen und Dritten zu berichten (wie Werbekunden) über angesammelte Statistiken über unsere Nutzer was Anzahl, Verkehrsmuster und Informationen über die Site betrifft.
<G-vec00709-002-s329><compile.zusammentragen><en> But the goal of this Biennial is not to compile archives; it is to awaken visual artists’ consciousness of the importance of the past, which extends into the present.
<G-vec00709-002-s329><compile.zusammentragen><de> Doch das Ziel dieser Biennale besteht nicht darin, Archive zusammenzutragen, sondern es geht mehr darum, das Bewusstsein bildender Künstler für die Bedeutung der Vergangenheit, deren Präsenz bis in die Gegenwart reicht, zu wecken.
<G-vec00709-002-s330><compile.zusammentragen><en> To compile all the factors, the first step is to ensure every room of the building on site is inspected and the floor plans are included.
<G-vec00709-002-s330><compile.zusammentragen><de> Um alle Faktoren zusammenzutragen, wird im ersten Schritt jeder Raum des Gebäudes vor Ort begangen und die Grundrisspläne miteinbezogen.
<G-vec00709-002-s331><compile.zusammentragen><en> Inspired by this, I decided to compile a few pieces of history around Microsoft’s CRM product, to provide some context on where it originates from and how the platform has developed over the years.
<G-vec00709-002-s331><compile.zusammentragen><de> Davon inspiriert beschloss ich, ein paar Abschnitte aus der Geschichte des CRM-Produkts von Microsoft zusammenzutragen und die Ereignisse um seinen Ursprung und die Entwicklung der Plattform im Verlauf der Zeit in Zusammenhang zu setzen.
