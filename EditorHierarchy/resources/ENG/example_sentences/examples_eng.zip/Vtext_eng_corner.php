<G-vec00214-002-s190><corner.ecken><en> The little one thus fits into almost every corner and alcove.
<G-vec00214-002-s190><corner.ecken><de> Der Kleine passt also nahezu in alle Ecken und Nischen.
<G-vec00214-002-s191><corner.ecken><en> Getting to the corners: The corner crops are surprisingly good with the FE 24-70, something I would not have expected after the closer look on the border crops.
<G-vec00214-002-s191><corner.ecken><de> Kommen wir zu den Ecken: Die Ecken sind beim FE 24-70 überraschend gut – damit hätte ich nach der Begutachtung des Randbereiches nicht gerechnet.
<G-vec00214-002-s192><corner.ecken><en> Discover flavours from every corner of the world, and enjoy a dedicated Maldivian night complete with traditional live entertainment.
<G-vec00214-002-s192><corner.ecken><de> Entdecken Sie Aromen aus allen Ecken der Welt, und genießen Sie eine maldevische Nacht mit traditioneller Live-Unterhaltung.
<G-vec00214-002-s193><corner.ecken><en> A training pista on 60x20m, a race pista on 70x30m, 5 judges corner.
<G-vec00214-002-s193><corner.ecken><de> Es gibt einen Trainingsbereich von 60x20m, eine Rennpiste von 70x30m und 5 Ecken.
<G-vec00214-002-s194><corner.ecken><en> At sunrise and sunset on the Spring and Fall equinoxes, the corner of the pyramid casts a shadow of Kukulkan, a feathered serpent god, creating the illusion of a snake slithering down the North side with the sun’s movement.
<G-vec00214-002-s194><corner.ecken><de> In der Morgen- und Abenddämmerung, während der Tagundnachtgleiche im Frühling und Herbst, wird ein Schatten von Kukulkan in Form einer gefiederten Schlange in eine der Ecken der Pyramide projiziert.
<G-vec00214-002-s195><corner.ecken><en> In this book, top managers from each corner of the Danish corporate world finally speak up.
<G-vec00214-002-s195><corner.ecken><de> In diesem Buch nehmen Spitzenmanager aus allen Ecken der dänischen Wirtschaft das Blatt vom Mund.
<G-vec00214-002-s196><corner.ecken><en> SISTERS AND BROTHERS: THE ATTACK THAT OUR BRETHREN, THE PEOPLE OF OAXACA, SUFFERED AND ARE SUFFERING, CANNOT BE IGNORED BY THOSE WHO STRUGGLE FOR LIBERTY, JUSTICE AND DEMOCRACY IN EVERY CORNER OF THE PLANET.
<G-vec00214-002-s196><corner.ecken><de> BRÜDER UND SCHWESTERN: DER ANGRIFF, DEN UNSERE BRÜDER UND SCHWESTERN DER BEVÖLKERUNG VON OAXACA ERLITTEN HAT, KANN VON JENEN NICHT IGNORIERT WERDEN, DIE IN ALLEN ECKEN DES PLANETEN FÜR FREIHEIT, GERECHTIGKEIT UND DEMOKRATIE KÄMPFEN.
<G-vec00214-002-s197><corner.ecken><en> Football is played in every corner of the world.
<G-vec00214-002-s197><corner.ecken><de> Fußball wird in allen Ecken der Welt gespielt.
<G-vec00214-002-s198><corner.ecken><en> Our team connects from every corner of the world.
<G-vec00214-002-s198><corner.ecken><de> Unser Team stammt aus allen Ecken der Welt.
<G-vec00214-002-s199><corner.ecken><en> There is something about hearing a new accent, tasting a new dish, seeing a new corner of the globe that sparks this innate wanderlust that reminds me that we live in a truly beautiful and magnificent world.
<G-vec00214-002-s199><corner.ecken><de> Wenn ich andere Sprachen höre, unbekannte Gerichte probiere und neue Ecken der Welt kennenlerne, wird meine angeborene Reiselust entfacht, die mich daran erinnert, dass wir in einer wunderschönen Welt leben.
<G-vec00214-002-s200><corner.ecken><en> In the corner you could find one or the other dead rat as well.
<G-vec00214-002-s200><corner.ecken><de> In den Ecken konnte man leider auch die ein oder andere tote Ratte finden.
<G-vec00214-002-s201><corner.ecken><en> Completely covered in mirrors and with a striking diamond shape, the Diamond side table will shine bright in your home and add a touch of luxury to even the darkest corner. Product Details
<G-vec00214-002-s201><corner.ecken><de> Er ist vollkommen mit Spiegeln bedeckt und verzaubert den Betrachter mit seiner Diamantform – der Diamond Beistelltisch wird in Ihrem Zuhause glänzen und selbst den dunkelsten Ecken einen Hauch von Luxus verleihen.
<G-vec00214-002-s202><corner.ecken><en> Today it is not unusual if you have just 15 people in front of the stage because there is another concert just around the corner.
<G-vec00214-002-s202><corner.ecken><de> Heute ist es nichts ungewöhnliches, wenn nur 15 Nasen vor der Bühne stehen, weil drei Ecken weiter ebenfalls ein Konzert stattfindet.
<G-vec00214-002-s203><corner.ecken><en> A cosy corner with deck chairs invites you to rest and relax.
<G-vec00214-002-s203><corner.ecken><de> Zum Ruhen und Relaxen finden Sie gemütliche Ecken mit Liegestühlen.
<G-vec00214-002-s204><corner.ecken><en> Load your original face down on the right front corner of the glass. If you are copying a photo, position the photo on the glass so the long edge of the photo is along the front edge of the glass.
<G-vec00214-002-s204><corner.ecken><de> Positionieren Sie das Foto auf dem Vorlagenglas, so dass sich die lange Kante des Fotos an der vorderen Ecke des Glases befindet, wie durch die Führungen entlang der Ecken des Vorlagenglases gekennzeichnet.
<G-vec00214-002-s205><corner.ecken><en> Free Speak & Translate is an indispensable voice and text translator that allows you to communicate effectively in any corner of the globe.
<G-vec00214-002-s205><corner.ecken><de> Sprich & Übersetze Pro ist ein unverzichtbarer Stimmen- und Textübersetzer, mit dessen Hilfe Sie effektiv in allen Ecken der Erde kommunizieren können.
<G-vec00214-002-s206><corner.ecken><en> Produsent: VWR Collection Beskrivelse: These PP deep well plates feature double alignment corner notches and are labelled on three sides with an alphanumeric grid.
<G-vec00214-002-s206><corner.ecken><de> Lieferant: VWR Collection Beschreibung: Diese Deep-Well-Platten aus PP haben abgeschnittene Ecken zur Doppelausrichtung und sind an drei Seiten mit einem alphanumerischen Raster beschriftet.
<G-vec00214-002-s207><corner.ecken><en> As with traditional Business Cards, Rounded Corner Cards are printed on premium paper stock, and have the option of Printfinity – a different image on every card.
<G-vec00214-002-s207><corner.ecken><de> Wie die traditionellen Visitenkarten werden die Karten mit abgerundeten Ecken auf Premium-Papier gedruckt und jede Karte kann ein anderes Bild haben, wir nennen das Printfinity.
<G-vec00214-002-s208><corner.ecken><en> In the morning we'll give you the right charge and the energy you need to get through your lunch break, thanks to our abundant breakfast buffet with homemade cakes and savory corner.
<G-vec00214-002-s208><corner.ecken><de> Morgens geben wir Ihnen die richtige Ladung und die nötige Energie für die Mittagspause, dank unseres reichhaltigen Frühstücksbuffets mit hausgemachten Kuchen und herzhaften Ecken.
