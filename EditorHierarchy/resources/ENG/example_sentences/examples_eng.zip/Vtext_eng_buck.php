<G-vec00019-001-s020><buck.abwerfen><en> It will probably buck you off.
<G-vec00019-001-s020><buck.abwerfen><de> Es wird dich wahrscheinlich abwerfen.
<G-vec00019-001-s046><buck.bocken><en> Perhaps the horse was used as a rodeo bucking horse, or perhaps a person with a grudge against a former owner taught the horse to buck as cruel revenge.
<G-vec00019-001-s046><buck.bocken><de> Vielleicht wurde dein Pferd als bockendes Pferd bei Rodeos eingesetzt oder vielleicht hat eine Person mit einem Hass auf den Vorbesitzer dem Pferd das Bocken als grausame Rache beigebracht.
<G-vec00019-001-s047><buck.bocken><en> This will confuse the horse and he will buck even more.
<G-vec00019-001-s047><buck.bocken><de> Du wirst das Pferd verunsichern und es wird noch mehr bocken.
<G-vec00019-001-s048><buck.bocken><en> In order to inflate, the valve should be removed, after inflating it is enough to put in the valves and the child can buck at home as well as in the garden.
<G-vec00019-001-s048><buck.bocken><de> Zum Aufpumpen sollte das Ventil entfernt werden, nach dem Aufpumpen genügt es, die Ventile einzustecken und das Kind kann sowohl zu Hause als auch im Garten bocken.
<G-vec00019-001-s049><buck.bocken><en> Ethnicity does play a large role in self-identification for minorities, and role-models who buck the stereotypes are crucial in challenging everyone's assumptions.
<G-vec00019-001-s049><buck.bocken><de> Abstammung spielt eine große Rolle bei der Selbst-Identifikation für Minderheiten, und Vorbilder, die die Stereotypen bocken sind entscheidend an der Anfechtung aller Annahmen.
