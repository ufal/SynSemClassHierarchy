<G-vec01153-002-s025><cough_up.abhusten><en> Hot tea can be soothing to a sore throat, make mucus easier to cough up, and the steam can help ease inflammation.
<G-vec01153-002-s025><cough_up.abhusten><de> Heißer Tee kann Halsschmerzen beruhigen, Schleim leichter abgehustet werden lassen, und der Dampf kann dabei helfen, Entzündungen zu lindern.
<G-vec01153-002-s026><cough_up.abhusten><en> Surgery may be considered for people who have recurrent infections despite treatment or who cough up large amounts of blood.
<G-vec01153-002-s026><cough_up.abhusten><de> Die Operation kann auch bei Patienten erwogen werden, die trotz Behandlung an wiederkehrenden Infektionen leiden oder viel Blut abhusten.
<G-vec01153-002-s054><cough_up.heraushusten><en> Breathing through this tube was terrible because Otto reacted very sensitively and kept trying to cough or gag it out.
<G-vec01153-002-s054><cough_up.heraushusten><de> Das Atmen über die Kanüle war schrecklich, weil Otto sehr sensibel reagiert hat und immer wieder versuchte, sie herauszuhusten oder zu -würgen.
<G-vec01153-002-s022><cough_up.husten><en> The symptoms of swine flu in people are similar to the symptoms of regular human flu and include fever, cough, sore throat, body aches, headache, chills and fatigue.
<G-vec01153-002-s022><cough_up.husten><de> Die Symptome der Schweinegrippe sind ähnlich wie bei einer normalen saisonbedingten Grippe (saisonale Grippe) und umfassen Fieber, Müdigkeit, Appetitlosigkeit und Husten.
<G-vec01153-002-s023><cough_up.husten><en> Check with your doctor if any of these most COMMON side effects persist or become bothersome during using Proventil:cough, headache, nausea, nervousness, sinus inflammation, sore or dry throat, tremor, trouble sleeping, unusual taste in mouth, vomiting.
<G-vec01153-002-s023><cough_up.husten><de> Weniger schwere Nebenwirkungen von Albuterol können sein: Kopfschmerzen, Schwindel, Schlafstörungen (Schlaflosigkeit), Husten, Heiserkeit, Halsschmerzen, laufende oder verstopfte Nase, leichte Übelkeit, Erbrechen, trockener Mund und Rachen; Muskelschmerzen; oder Durchfall.
<G-vec01153-002-s050><cough_up.husten><en> Scientific studies prove its high antiseptic effect that is often used for inflammation, cough and gout.
<G-vec01153-002-s050><cough_up.husten><de> Wissenschaftliche Untersuchungen belegen seine hohe antiseptische Wirkung, die gern bei Entzündungen, gegen Husten und Gicht eingesetzt wird.
<G-vec01153-002-s058><cough_up.husten><en> HYSSOP LIQUID DROPS offer a variety of uses for respiratory support including reducing cough and wheezing, inducing a fever along with relieving anxiety and soothing nerves to promote restful sleep.
<G-vec01153-002-s058><cough_up.husten><de> YSOP TROPFEN bieten verschiedene Nutzungen für die Atemwegsunterstützung wie die Reduzierung von Huste, Keuchen, Fieber zusammen mit der Linderung von Angstgefühlen und Nerven um einen erholsamen Schlaf zu fördern.
<G-vec01153-002-s059><cough_up.husten><en> Cough if you need to cough.
<G-vec01153-002-s059><cough_up.husten><de> Huste, falls du husten musst.
<G-vec01153-002-s060><cough_up.husten><en> Dyspnea. Hoarseness of voice, pain in throat and cough.
<G-vec01153-002-s060><cough_up.husten><de> Heiserkeit der Stimme, Schmerzen im Hals und Husten.
<G-vec01153-002-s061><cough_up.husten><en> Cover up your laughter with a cough, if you don't have time to leave.
<G-vec01153-002-s061><cough_up.husten><de> Überdecke dein Lachen mit einem Husten, wenn dir die Zeit fehlt, um zu gehen.
<G-vec01153-002-s062><cough_up.husten><en> Severe COPD: You may cough even more and you cough up a lot of mucus.
<G-vec01153-002-s062><cough_up.husten><de> Schwere COPD: Betroffene husten sehr stark mit sehr viel Schleim.
<G-vec01153-002-s063><cough_up.husten><en> Mr. Wang's condition didn't improve as he continued to have a high fever, cough, shortness of breath, difficulty sitting still, and chest pain.
<G-vec01153-002-s063><cough_up.husten><de> Zudem bist du noch nicht ‚umerzogen‘.“ Herrn Wangs Zustand verbesserte sich nicht und er hatte weiterhin hohes Fieber, Husten, Kurzatmigkeit, Schwierigkeiten beim Sitzen sowie Schmerzen in der Brust.
<G-vec01153-002-s064><cough_up.husten><en> The smoke cloud it leaves is a minor obstacle; it distorts your vision slightly and causes your team to cough loudly.
<G-vec01153-002-s064><cough_up.husten><de> Die Rauchwolke behindert deine Sicht und lässt alle im Rauch Stehenden laut husten.
<G-vec01153-002-s065><cough_up.husten><en> According to Ayurveda, breathing disorder and cough can occur due to imbalances in the three energies that are responsible for the vital processes in the body.
<G-vec01153-002-s065><cough_up.husten><de> Laut Ayurveda können Atemstörungen und Husten aufgrund von Ungleichgewichten in den drei Energien auftreten, die für die Vitalprozesse im Körper verantwortlich sind.
<G-vec01153-002-s066><cough_up.husten><en> Dry cough is manifested with dry mucous membranes and related pinching pain.
<G-vec01153-002-s066><cough_up.husten><de> Der trockene Husten macht sich durch trockene Schleimhäute und stechenden Schmerz, der ihn begleitet, bemerkbar.
<G-vec01153-002-s067><cough_up.husten><en> In cases of throat ache and consistent cough, honey helps it the symptoms relief and clears the throat taking away the pain.
<G-vec01153-002-s067><cough_up.husten><de> • In Fällen von Halsschmerzen, sowie von ständigem Husten, hilft der Honig bei der Erleichterung dieser Symptomen, weil er den Hals lindert.
<G-vec01153-002-s068><cough_up.husten><en> Get emergency medical help if you have nausea, vomiting, loss of appetite, dizziness, drowsiness, headache, spinning sensation (vertigo), abdominal pain, jaundice, dark urine, cough, chest pain, watery diarrhea, hives, unexplained rash, itching, wheezing, swelling of the mouth or throat, difficulty breathing, numbness, loss of appetite, clay-colored stools, ringing in your ears, vaginal itching, vision problems, weight loss, confusion, weakness.
<G-vec01153-002-s068><cough_up.husten><de> Suchen Sie sofort nach Nothilfe, wenn Sie Übelkeit, Erbrechen, Appetitlosigkeit, Schwindel, Benommenheit, Kopfschmerzen, Drehschwindel (Vertigo), Bauchschmerzen, Gelbsucht, dunklen Urin, Husten, Brustschmerzen, wässrigen Durchfall, Nesselsucht, nicht erklärbaren Hautausschlag, Juckreiz, Atemnot, Schwellungen des Mundes oder Halses, Atemnot, Gewichtsverlust, Verwirrtheit, Schwäche haben.
<G-vec01153-002-s069><cough_up.husten><en> Cover-up: cough at the right moment to disguise suspicious noises.
<G-vec01153-002-s069><cough_up.husten><de> Vertuschen: husten Sie, um verdächtige Furzgeräusche zu verschleiern.
<G-vec01153-002-s070><cough_up.husten><en> Bad cough be conquered by the mixture with the onions, and sinusitis — chewing honeycomb (at least five times a day for fifteen minutes, followed by no such residue).
<G-vec01153-002-s070><cough_up.husten><de> Schlechter Husten wird durch die Mischung mit den Zwiebeln und Sinusitis - Kauen der Waben überwunden (mindestens fünf Mal am Tag für fünfzehn Minuten, gefolgt von solchen Rückständen).
<G-vec01153-002-s071><cough_up.husten><en> Asthma is a chronic disease that most often occurs in the form of attacks: wheezing during exhalation, tightness in the chest and dry cough, amongst others.
<G-vec01153-002-s071><cough_up.husten><de> Asthma ist eine chronische Erkrankung, die am häufigsten in Form von Anfällen in Erscheinung tritt: Keuchen beim Ausatmen, ein Engegefühl im Brustbereich, trockener Husten...
<G-vec01153-002-s072><cough_up.husten><en> If you experience symptoms such as a cough, a temperature, shortness of breath or feeling generally unwell, self-isolate at your accommodation and call 900 112 061 for instructions and to be put in touch with the appropriate medical centre.
<G-vec01153-002-s072><cough_up.husten><de> Wenn bei Ihnen Symptome wie Husten, Fieber, Kurzatmigkeit oder allgemeines Unwohlsein auftreten, isolieren Sie sich in Ihrer Unterkunft und rufen Sie die Nummer 900 112 061 an, damit man Sie anleiten und an das entsprechende Gesundheitszentrum überweisen kann.
<G-vec01153-002-s073><cough_up.husten><en> Symptoms include cough, runny nose, sore throat and fever, and in some cases, diarrhea.
<G-vec01153-002-s073><cough_up.husten><de> Mögliche Symptome sind Husten, Schnupfen, Halskratzen und Fieber sowie in einigen Fällen auch Durchfall.
<G-vec01153-002-s074><cough_up.husten><en> At me cough after 5 minutes of stay there began.
<G-vec01153-002-s074><cough_up.husten><de> Bei mir fing der Husten nach 5 Minuten die Aufenthalte dort an.
<G-vec01153-002-s075><cough_up.husten><en> At last it should be mentioned that at Keldur Research Institute, they are doing autopsy on horses, at no extra cost for their owners, should the cough be the cause for the horses’ death.
<G-vec01153-002-s075><cough_up.husten><de> Zuletzt sollte noch erwähnt werden, dass beim “Keldur Forschungszentrum” kostenfreie Autopsien an Pferden durchgeführt werden, wenn der Husten zum Tode des Tieres geführt hat.
<G-vec01153-002-s076><cough_up.husten><en> Unfortunately, he choked on a bite and started to cough.
<G-vec01153-002-s076><cough_up.husten><de> Leider verschluckte er sich und begann zu husten.
<G-vec01153-002-s077><cough_up.husten><en> This leads to a chronic cough and frequently to severe inflammation of the lung.
<G-vec01153-002-s077><cough_up.husten><de> Sie führt dadurch zu chronischem Husten und oftmals schweren Lungenentzündungen.
<G-vec01153-002-s078><cough_up.husten><en> Many people in a concert suddenly feel a need to cough when one person starts.
<G-vec01153-002-s078><cough_up.husten><de> In einem Konzert müssen plötzlich viele Menschen husten, wenn einer beginnt.
<G-vec01153-002-s079><cough_up.husten><en> - colds and bronchial catarrh, asthma, cough
<G-vec01153-002-s079><cough_up.husten><de> - Grippe, Erkältungen und Bronchialkatarrh, Asthma, Husten.
<G-vec01153-002-s080><cough_up.husten><en> No sustained infections have been found to occur. Symptoms of avian influenza in humans involve the typical influenza symptoms such as a fever, sore throat, muscle aches and cough.
<G-vec01153-002-s080><cough_up.husten><de> Symptome der Vogelgrippe Beim Menschen äußert sich die Infektion von Vogelgrippevirus Typ A (H5N1) als eine ernste Erkrankung mit Fieber über 38ºC, mit Husten, Atemnot, Halsschmerzen.
<G-vec01153-002-s081><cough_up.husten><en> Your son comes down with a cough.
<G-vec01153-002-s081><cough_up.husten><de> Dein Sohn ist dabei einen Husten zu bekommen.
<G-vec01153-002-s082><cough_up.husten><en> As for the cough, it occurs against the background of the defeat of the main entrance gate of the infection - the upper respiratory tract.
<G-vec01153-002-s082><cough_up.husten><de> Was den Husten betrifft, tritt er vor dem Hintergrund der Niederlage des Haupteingangstors der Infektion - der oberen Atemwege - auf.
<G-vec01153-002-s083><cough_up.husten><en> Sinusitis in children is suspected when a pus-filled discharge from the nose persists for more than 10 days along with extreme tiredness (fatigue) and cough.
<G-vec01153-002-s083><cough_up.husten><de> Ein Verdacht auf eine Nebenhöhlenentzündung bei Kindern liegt dann vor, wenn mindestens 10 Tage lang ein eitriger Ausfluss aus der Nase tritt und mit extremer Müdigkeit (Fatigue) und Husten einhergeht.
<G-vec01153-002-s084><cough_up.husten><en> Chronic cough, especially after you swallow something, should be checked out by your doctor—or they should at least be made aware of the issue so they can keep an eye on it, as well as tell you what other signs to be aware of (based on a variety of possible conditions, including esophageal cancer).
<G-vec01153-002-s084><cough_up.husten><de> Chronischer Husten, besonders nachdem Sie etwas schlucken, sollte von Ihrem Arzt untersucht werden – oder Sie sollten ihm zumindest davon berichten, damit er den Husten im Auge behalten und Ihnen sagen kann, auf welche anderen Anzeichen Sie achten sollten (basierend auf eine Reihe von möglichen Krankheiten, inklusive Speiseröhrenkrebs).
<G-vec01153-002-s085><cough_up.husten><en> You've probably heard that tea sweetened with honey can help a sore throat, but eating pure honey can actually stop a cough.
<G-vec01153-002-s085><cough_up.husten><de> Wahrscheinlich hast du schon gehört, dass mit Honig gesüßter Tee Halsschmerzen lindern kann; reinen Honig essen kann aber tatsächlich einen Husten stillen.
<G-vec01153-002-s086><cough_up.husten><en> • Persistent or chronic cough such as occurs with smoking, asthma, chronic bronchitis, or emphysema.
<G-vec01153-002-s086><cough_up.husten><de> • Es länger anhält oder bei chronischem Husten in Verbindung mit Rauchen, Asthma, Bronchitis oder Emphysemen.
<G-vec01153-002-s131><cough_up.husten><en> Some people cough themselves to sleep.
<G-vec01153-002-s131><cough_up.husten><de> So mancher hustet sich in den Schlaf.
