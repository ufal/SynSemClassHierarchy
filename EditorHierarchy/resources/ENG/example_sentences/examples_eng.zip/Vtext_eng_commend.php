<G-vec00675-002-s024><commend.anerkennen><en> We commend the great efforts that these states have undertaken since 1989-1990 to adapt their political, economic and legal frameworks to the standards of the European Union.
<G-vec00675-002-s024><commend.anerkennen><de> Wir anerkennen die großen Anstrengungen, die diese Staaten seit der Zeitenwende 1989/1990 unternommen haben, um ihr politisches System, ihre Wirtschaft und ihr Rechtssystem an die Standards der Europäischen Union anzupassen.
<G-vec00675-002-s033><commend.beglückwünschen><en> We commend Croatia on the progress it has made in its reform efforts, making full use of the options offered by Partnership for Peace (PfP), the Euro-Atlantic Partnership Council (EAPC) and the Intensified Dialogue.
<G-vec00675-002-s033><commend.beglückwünschen><de> Wir beglückwünschen Kroatien zu seinen Fortschritten in den Reformanstrengungen unter voller Nutzung der Optionen, die von der Partnerschaft für den Frieden und im Euro-Atlantischen Partnerschaftsrat sowie im Rahmen des intensivierten Dialogs angeboten werden.
<G-vec00675-002-s034><commend.beglückwünschen><en> We commend Adobe for trying to make Lightroom easier to use and a better experience.
<G-vec00675-002-s034><commend.beglückwünschen><de> Wir beglückwünschen Adobe zu dem Versuch, Lightroom einfacher benutzbar und zu einer besseren Erfahrung zu machen.
<G-vec00675-002-s047><commend.empfehlen><en> I commend this book as a valuable addition to the growing understanding of the global responsibility of the church of Jesus Christ from all nations.
<G-vec00675-002-s047><commend.empfehlen><de> Ich empfehle dieses Buch als einen wertvollen Beitrag zum wachsenden Verständnis der globalen Verantwortung der Gemeinde Jesu Christi in allen Ländern.
<G-vec00675-002-s048><commend.empfehlen><en> I commend unto you Phebe our sister, which is a servant of the church which is at Cenchrea:
<G-vec00675-002-s048><commend.empfehlen><de> 1 Ich empfehle euch unsere Schwester Phöbe, eine Diakonin der Gemeinde von Kenchreä.
<G-vec00675-002-s049><commend.empfehlen><en> I commend him to you.
<G-vec00675-002-s049><commend.empfehlen><de> Ich empfehle ihn euch.
<G-vec00675-002-s050><commend.empfehlen><en> Dear friends, with these words of encouragement, and with great affection, I commend you and your families to the loving intercession of Mary, Mother of the Church.
<G-vec00675-002-s050><commend.empfehlen><de> Liebe Freunde, mit diesen Worten der Ermutigung und mit großer Zuneigung empfehle ich euch und eure Familien der liebevollen Fürsprache Marias, Mutter der Kirche.
<G-vec00675-002-s051><commend.empfehlen><en> If you will level up with 3 + characters, I commend you all on another CH botting leave.
<G-vec00675-002-s051><commend.empfehlen><de> Wenn man mit 3+ Charakteren levelt,dann empfehle ich euch alle auf einem anderen CH botten zu lassen.
<G-vec00675-002-s052><commend.empfehlen><en> This is why I commend you to God in prayer, so that courage and foresight may be given to you in abundance.
<G-vec00675-002-s052><commend.empfehlen><de> Deshalb empfehle ich Sie Gott im Gebet, damit Ihnen in reichem Maß Mut und Scharfblick gegeben werden.
<G-vec00675-002-s053><commend.empfehlen><en> To Jesus Christ I commend my soul; Lord Jesus receive my soul.
<G-vec00675-002-s053><commend.empfehlen><de> An Jesus Christus empfehle ich meine Seele, Herr Jesus empfange meine Seele.
<G-vec00675-002-s054><commend.empfehlen><en> "My dear La Hurière, I commend De Mouy to your care, although I greatly fear nothing can be done for him.
<G-vec00675-002-s054><commend.empfehlen><de> »Mein lieber La Hurière,« sagte Heinrich, »ich empfehle Euch Herrn von Mouy, obgleich ich sehr befürchte, daß nichts mehr für ihn zu thun ist.
<G-vec00675-002-s055><commend.empfehlen><en> The previous diversity can be explained rather simply: Vacuum or pressure evaporators commend themselves depending on room geometry and range of applications.
<G-vec00675-002-s055><commend.empfehlen><de> Die bisherige Vielfalt erklärt sich ganz einfach: Je nach Raumgeometrie und Anwendungsfeld empfehlen sich saugende oder drückende Verdampfer.
<G-vec00675-002-s056><commend.empfehlen><en> Also, we commend WEBCON Business Process Suite for its flexibility, ease of use and wide range of capabilities offered out of the box.
<G-vec00675-002-s056><commend.empfehlen><de> Außerdem empfehlen wir die WEBCON Business Process Suite wegen ihrer Flexibilität, Benutzerfreundlichkeit und der umfangreichen Funktionen, die sie out-of-the-box bietet.
<G-vec00675-002-s057><commend.empfehlen><en> [For] we do not again commend ourselves to you, but [we are] giving to you occasion of boast in our behalf, that ye may have [such] with those boasting in countenance, and not in heart.
<G-vec00675-002-s057><commend.empfehlen><de> Wir empfehlen uns nicht wieder selbst bei euch, sondern geben euch Anlaß zum Ruhm unsertwegen, damit ihr ihn habt bei denen, die sich nach dem Ansehen rühmen und nicht nach dem Herzen.
<G-vec00675-002-s058><commend.empfehlen><en> "The good mechanical properties and the premium-quality surfaces commend the Long Fiber Injection procedure for large-format components in many markets, and especially in the automotive and commercial vehicle industry to meet the increasing demands of the CAFC (Corporate Average Fuel Consumption) program for a lower fleet consumption," explains Paul Condeelis, Vice President of Business Development at Romeo RIM.
<G-vec00675-002-s058><commend.empfehlen><de> "Die guten mechanischen Eigenschaften und die hochwertigen Oberflächen empfehlen das LFI-Verfahren für großflächige Bauteile in vielen Märkten und besonders in der Automobil- und Nutzfahrzeugindustrie um die steigenden Anforderungen nach geringerem Flottenverbrauch des CAFE (Corporate Average Fuel Consumption) Programms zu erfüllen" erklärt Marktteilnehmer unsere Anforderungen erfüllen können".
<G-vec00675-002-s059><commend.empfehlen><en> He should always come to Me and ask Me for clarification, he should at all times commend himself to Me and My protection. Then the adversary will not be able to deceive him and the person’s will itself would have warded off the danger, which cannot be forced by My adversary but which will always be strengthened by Me if he stays firmly focussed on Me.
<G-vec00675-002-s059><commend.empfehlen><de> Er sollte stets zu Mir kommen und Mich um Aufklärung bitten, er sollte sich immer mir und Meinem Schutz empfehlen, dann wird es Meinem Gegner nicht gelingen, ihn zu täuschen, und der Mensch selbst hätte die Gefahr gebannt durch seinen Willen, der nicht von Meinem Gegner gezwungen werden kann, der aber immer von Mir aus gestärkt wird, wenn er ernstlich Mir zugewandt bleibt.
<G-vec00675-002-s060><commend.empfehlen><en> To You we commend all our needs, in particular... and all children of the Polish Nation whether in their native land or elsewhere in the world.
<G-vec00675-002-s060><commend.empfehlen><de> Wir empfehlen dir alle unsere Nöte, besonders... alle Kinder des polnischen Volkes, egal ob sie in ihrem Heimatland oder sonst wo auf der Welt sind.
<G-vec00675-002-s061><commend.empfehlen><en> I can also commend the support we received as the machine was being installed and readied for use.
<G-vec00675-002-s061><commend.empfehlen><de> Außerdem kann ich den Support empfehlen, den wir bei der Installation der Maschine und Inbetriebnahme erhielten.
<G-vec00675-002-s062><commend.empfehlen><en> 12For we commend not ourselves again unto you, but give you occasion to glory on our behalf, that ye may have somewhat to answer them which glory in appearance, and not in heart.
<G-vec00675-002-s062><commend.empfehlen><de> 12 Denn wir empfehlen uns nicht nochmals selbst euch gegenüber, sondern wir geben euch Gelegenheit, euch unsretwegen zu rühmen, damit ihr es denen entgegenhalten könnt, die sich des Äußeren rühmen, aber nicht des Herzens.
<G-vec00675-002-s066><commend.fördern><en> 8:8 But food will not commend us to God.
<G-vec00675-002-s066><commend.fördern><de> 8:8 Aber die Speise fördert uns nicht vor Gott.
<G-vec00675-002-s020><commend.loben><en> The working group opens its comment letter on the IASB's ED/2013/6 Leases by expressly stating that the concepts developed fit well into the world of Islamic accounting and prominent Sharia'a scholars commend the IASB for the proposals.
<G-vec00675-002-s020><commend.loben><de> Die Arbeitsgruppe eröffnet ihre Stellungnahme zum IASB-Entwurf ED/2013/6 Leasingverhältnisse damit, dass sie ausdrücklich darauf hinweist, dass die entwickelten Konzepte gut in die Welt islamischer Bilanzierung passen und dass herausragende Scharia'a-Gelehrte den IASB für dessen Vorschläge loben.
<G-vec00675-002-s021><commend.loben><en> 538. It is right to commend Ayurvedic medicine.
<G-vec00675-002-s021><commend.loben><de> 538 Es ist richtig, die ajurvedische Medizin zu loben.
<G-vec00675-002-s068><commend.loben><en> He used His actual words and actions to tell the doubters, to tell those who only believed in God in heaven but did not believe in Christ: God did not commend their belief, nor did He commend their following which was full of doubts.
<G-vec00675-002-s068><commend.loben><de> Er gebrauchte Seine realen Worte und Handlungen, um den Zweiflern zu sagen, sie sollen denjenigen, die nur an Gott im Himmel und nicht an Christus glauben, das Folgende sagen: Gott hat weder ihren Glauben gelobt, noch hat Er ihr Folgen, das voller Zweifel war, gelobt.
<G-vec00675-002-s072><commend.loben><en> 14 or to governors, who are sent by him to punish those who do wrong and to commend those who do right.
<G-vec00675-002-s072><commend.loben><de> 14 oder den Statthaltern als seinen Gesandten zur Bestrafung der Übeltäter und zum Lob derer, die Gutes tun.
<G-vec00675-002-s073><commend.loben><en> I commend President Mahmoud Abbas and Prime Minister Salam Fayyad on this remarkable success.
<G-vec00675-002-s073><commend.loben><de> Ich lobe Präsident Mahmoud Abbas und Premierminister Salam Fayyad für diesen erstaunlichen Erfolg.
<G-vec00675-002-s074><commend.loben><en> “And for this I commend you and promise even more spiritual territory.
<G-vec00675-002-s074><commend.loben><de> “Und dafür lobe Ich euch und Ich verspreche euch noch mehr geistiges Territorium.
<G-vec00675-002-s075><commend.loben><en> I commend aok for being one of the only ones who continues to write articles for us, regardless of if he only does it to market his site, placate his ego, and generate affiliate money, whatever.
<G-vec00675-002-s075><commend.loben><de> Ich lobe aok dafür, dass er einer der Wenigen ist, die weiterhin Artikel für uns schreiben, unabhängig davon, warum er das tut, sei es um für seine Site zu werben, sein Ego zu befriedigen, Affiliate-Gelder zu verdienen, was auch immer.
<G-vec00675-002-s076><commend.loben><en> We especially want to commend your sales department and technologists, that have helped us with choosing the right chrusher.
<G-vec00675-002-s076><commend.loben><de> Wir möchten besonders Ihren Vertrieb und die Technologen loben, die uns bei der Auswahl des richtigen Zerkleinerers geholfen haben.
<G-vec00675-002-s077><commend.loben><en> I would like to take this opportunity to personally commend our personnel in Australia for an outstanding job, which ensured that despite these challenges our mill remained in operation with ample feed from our mines and stockpiles.
<G-vec00675-002-s077><commend.loben><de> Ich möchte diese Gelegenheit nutzen, um unser Personal in Australien persönlich für seine hervorragende Arbeit zu loben, die dafür gesorgt hat, dass unsere Mühle trotz dieser Herausforderungen mit reichlich Erzmaterial aus unseren Minen und Lagerbeständen in Betrieb blieb.
<G-vec00675-002-s078><commend.loben><en> •In that vein, we commend strongly the Secretary General’s efforts to refocus the United Nations on the urgent need to address climate change.
<G-vec00675-002-s078><commend.loben><de> •In diesem Sinne loben wir nachdrücklich die Bemühungen des Generalsekretärs, die Vereinten Nationen auf die dringende Notwendigkeit einer Bekämpfung des Klimawandels auszurichten.
<G-vec00675-002-s079><commend.loben><en> Let me commend the generosity of the Turkish people in hosting so many refugees," said Commissioner for Humanitarian Aid and Crisis Management Christos Stylianides.
<G-vec00675-002-s079><commend.loben><de> Ich möchte die Großzügigkeit der türkischen Bevölkerung loben, die so viele Flüchtlinge beherbergt“, sagte der Kommissar für humanitäre Hilfe und Krisenmanagement, Christos Stylianides.
<G-vec00675-002-s080><commend.loben><en> As a large group of the Faithful and Discreet Slave, a part of the anointed remnant of Christ’s Brothers from around the world, we wanted to commend you for your fine work that you have done.
<G-vec00675-002-s080><commend.loben><de> Als eine große Gruppe des treuen und verständigen Sklaven, ein Teil des gesalbten Überrestes der Brüder Christi auf der ganzen Welt, wollten wir dich für dein gutes Werk loben, das du verrichtet hast.
<G-vec00675-002-s081><commend.loben><en> It must also commend the extraordinarily comprehensive and high-quality Czech guide.
<G-vec00675-002-s081><commend.loben><de> Es muss auch loben die außerordentlich umfassenden und hochwertigen tschechischen Führer.
<G-vec00675-002-s082><commend.loben><en> If you have a different password for every website that looks like this: “4ESN5MC5!%Lsg9w”, then we commend you for your password management prowess and you can stop reading now.
<G-vec00675-002-s082><commend.loben><de> If you have a unterschiedliches Passwort für jeder Website haben, das wie folgt aussieht: “4ESN5MC5% Lsg9w!”, dann loben wir Sie für Ihre Talente in der Verwaltung von Passworten und Sie müssen nicht weiterlesen.
<G-vec00675-002-s022><commend.rühmen><en> One generation will commend your works to another; they will tell of your mighty acts.
<G-vec00675-002-s022><commend.rühmen><de> Eine Generation wird der andern rühmen deine Werke, deine Machttaten werden sie verkünden.
<G-vec00675-002-s086><commend.sprechen><en> I also commend the many individuals and organizations that provide medical, psychological, legal and social assistance to victims of torture and their families.
<G-vec00675-002-s086><commend.sprechen><de> Ich spreche auch den vielen Einzelnen und Organisationen Lob aus, die die Folteropfer und ihre Familien medizinisch, rechtlich und sozial unterstützen.
<G-vec00675-002-s091><commend.zollen><en> Commentators commend the decision and are confident that Gauck is assured of an honourable place in history.
<G-vec00675-002-s091><commend.zollen><de> Kommentatoren zollen der Entscheidung Respekt und glauben, dass sich Gauck seinen Platz in der Geschichte schon gesichert hat.
