<G-vec00426-002-s032><cry.aufschreien><en> Extraordinary things will come to pass in the Church and the world causing you to cry out in uncertainty and despair.
<G-vec00426-002-s032><cry.aufschreien><de> Ausserordentliche Dinge werden geschehen in Kirche und Welt, sodass ihr in Unsicherheit und Verzweiflung aufschreien werdet.
<G-vec00426-002-s033><cry.aufschreien><en> And, all cry out to be emancipated, I love porn.
<G-vec00426-002-s033><cry.aufschreien><de> Und, alle Emanzen werden aufschreien, ich liebe Pornos.
<G-vec00426-002-s034><cry.aufschreien><en> Why, the whole womanhood of England must cry out against such a thing.
<G-vec00426-002-s034><cry.aufschreien><de> Warum, alle Frauen von England müssten aufschreien gegen so eine Sache.
<G-vec00426-002-s035><cry.aufschreien><en> Sometimes, this aching throb hurts; it can make me want to cry out in the middle of the night, bury my head in my pillow and wish for a new life.
<G-vec00426-002-s035><cry.aufschreien><de> Manchmal tut mir das schmerzhafte Pochen weh; ich will mitten in der Nacht aufschreien, meinen Kopf in den Polster graben und mir ein neues Leben wünschen.
<G-vec00426-002-s036><cry.aufschreien><en> But the expected pain didn't come, he heard the guard's cry instead.
<G-vec00426-002-s036><cry.aufschreien><de> Doch der erwartete Schmerz blieb aus, statt dessen hörte er den Wächter aufschreien.
<G-vec00426-002-s095><cry.heulen><en> Well, not really, but since the record had been produced before (and I suppose with a very low budget) SIGH end up with an underground production that makes me want to cry.
<G-vec00426-002-s095><cry.heulen><de> Prinzipiell ja, aber da die Aufnahme bereits davor produziert worden war (und ich vermute - in Anbetracht eines fehlenden Labels - mit niedrigem Budget), muss sich der Hörer nun mit einer Underground-Produktion begnügen, die zum Heulen ist.
<G-vec00426-002-s096><cry.heulen><en> I do not know, I should be happy or rather cry.
<G-vec00426-002-s096><cry.heulen><de> Ich weiß nicht, soll ich mich freuen oder eher heulen.
<G-vec00426-002-s097><cry.heulen><en> And on the other hand, for example, we have the case of British Nobel Prize-winning biochemist Tim Hunt who at a conference in early June argued (whether in jest or seriously is not quite clear) that women and men should be assigned to separate laboratories because otherwise men would fall in love with female scientists “and if you criticise them they start to cry”.
<G-vec00426-002-s097><cry.heulen><de> Und auf der anderen Seite haben wir etwa den Fall des bri- tischen Biochemie-Nobelpreisträgers Tim Hunt, der auf einer Konferenz Anfang Juni dafür plädiert hatte (ob im Scherz oder ernsthaft ist nicht ganz klar), Frauen und Männern getrennte Labore zuzuweisen, weil man sich sonst eh in die Wissenschaftlerinnen verliebe, „und wenn du sie kritisierst, fangen sie an zu heulen“.
<G-vec00426-002-s098><cry.heulen><en> I did it and could cry for joy.
<G-vec00426-002-s098><cry.heulen><de> Ich habe es geschafft und könnte heulen vor Freude.
<G-vec00426-002-s099><cry.heulen><en> Evening, and morning, and at noon, will I pray, and cry aloud: and he shall hear my voice.
<G-vec00426-002-s099><cry.heulen><de> Des Abends, Morgens und Mittags will ich klagen und heulen, so wird er meine Stimme hören.
<G-vec00426-002-s100><cry.heulen><en> The dismayed audience in the Kulturbrauerei did not know whether they should be happy or rather cry when Jeff Hanneman received the award in the category God of Riffs.
<G-vec00426-002-s100><cry.heulen><de> Die betretene Menge in der Kulturbrauerei wusste nicht ob sie sich freuen oder lieber heulen sollte, als Jeff Hanneman posthum den Award in der Kategorie God Of Riffs erhielt.
<G-vec00426-002-s189><cry.rufen><en> Therefore, my dear children, with hearts open and full of love, cry out the name of the Heavenly Father that He may illuminate you with the Holy Spirit.
<G-vec00426-002-s189><cry.rufen><de> Darum, meine lieben Kinder, ruft mit offenem Herzen und voller Liebe den Namen des himmlischen Vaters an, damit Er euch mit dem heiligen Geiste erleuchte.
<G-vec00426-002-s190><cry.rufen><en> Though I use her now to cry out to the Bride, as a voice will cry out to the five wise virgins, do not compromise, be prepared for your bridegroom doth come for HIS Bride on a Rosh Hashanah and a Shabbat.
<G-vec00426-002-s190><cry.rufen><de> ICH benutze sie nun um zur Braut zu schreien, so wie eine Stimme die zu den fünf klugen Jungfrauen ruft, macht keine Kompromisse, seid bereit, denn euer Bräutigam kommt for SEINE Braut an einem Rosh Ha Shanah und am Sabbat.
<G-vec00426-002-s191><cry.rufen><en> “Even as you listen to this message, cry out to Me and I shall grant you the grace of profound thankfulness.
<G-vec00426-002-s191><cry.rufen><de> “Während ihr dieser Botschaft zuhört, ruft zu Mir hinaus und Ich werde euch die Gnade tiefgreifender Dankbarkeit gewähren.
<G-vec00426-002-s192><cry.rufen><en> UNIFY is a prophetic voice of the ashes of Auschwitz, which cry out for vengeance, but instead we cry for “Holy Vengeance”.
<G-vec00426-002-s192><cry.rufen><de> UNIFY ist eine prophetische Stimme der Asche von Auschwitz, die nach Vergeltung ruft – statt dessen aber rufen wir nach „Heiliger Vergeltung“.
<G-vec00426-002-s193><cry.rufen><en> 15 (John testified to him with the cry, 'This was he of whom I said, my successor has taken precedence of me, for he preceded me.')
<G-vec00426-002-s193><cry.rufen><de> 15 Johannes zeugt von ihm, ruft und spricht: Dieser war es, von dem ich gesagt habe: Nach mir wird kommen, der vor mir gewesen ist; denn er war eher als ich.
<G-vec00426-002-s091><cry.schreien><en> But more than this, Isabella, now 3, can sometimes wake to go to the toilet, or because she’s having a night terror or even cry out in her sleep.
<G-vec00426-002-s091><cry.schreien><de> Und daneben wacht auch Isabella, die inzwischen drei ist, manchmal auf, weil sie auf die Toilette muss oder einen Albtraum gehabt oder einfach nur im Schlaf geschrien hat.
<G-vec00426-002-s092><cry.schreien><en> Says Tyrone: “He didn’t cry, he just glared at me, full of hate.
<G-vec00426-002-s092><cry.schreien><de> Tyrone: „Er hat nicht geschrien, er schaute mich nur an, voller Hass.
<G-vec00426-002-s093><cry.schreien><en> 24 You shall bring both of them out to the gate of that city and stone them with stones so that they die, the girl because she did not cry out in the city, and the man because he humbled his neighbor's wife.
<G-vec00426-002-s093><cry.schreien><de> 5Mo 22,24 dann sollt ihr sie beide zum Tor jener Stadt hinausführen und sie steinigen, dass sie sterben; das Mädchen deshalb, weil es in der Stadt nicht geschrien hat, und den Mann deshalb, weil er der Frau seines Nächsten Gewalt angetan hat.
<G-vec00426-002-s094><cry.schreien><en> When parents hear about infant sleep training, they often think of babies left alone in their cribs to cry themselves to sleep.
<G-vec00426-002-s094><cry.schreien><de> Wenn Eltern von Schlaf-Training hören, denken viele dass sie ihr armes Baby alleine in seinem Bettchen liegen lassen müssen bis es sich in den Schlaf geschrien hat.
<G-vec00426-002-s336><cry.weinen><en> Hear my cry, hear my cry
<G-vec00426-002-s336><cry.weinen><de> Höre mein Weinen, höre mein Weinen.
<G-vec00426-002-s337><cry.weinen><en> You make me cry
<G-vec00426-002-s337><cry.weinen><de> Sie machen mich weinen.
<G-vec00426-002-s338><cry.weinen><en> I won't cry for you
<G-vec00426-002-s338><cry.weinen><de> Ich würde nicht um dich weinen.
<G-vec00426-002-s339><cry.weinen><en> Got no more tears to cry
<G-vec00426-002-s339><cry.weinen><de> Hab keine Tränen mehr zu weinen.
<G-vec00867-002-s042><cry.ausweinen><en> Kristine gets home toward morning, her clothes soaked with smoke and perfumes, and on her hot shoulder the old woman can finally have a cry and reject the words of comfort, saying: "All of this is good for me now.
<G-vec00867-002-s042><cry.ausweinen><de> Kristine kehrt gegen Morgen heim, ihre Kleider vollgesogen mit Rauch und Parfum, und an dieser heißen Schulter kann sich die Alte endlich ausweinen und Beruhigungen zurückweisen mit den Worten: Das kommt mir jetzt alles zugute.
<G-vec00867-002-s043><cry.ausweinen><en> If a friend needs help with an unpleasant chore, or if he or she just needs a shoulder to cry on, be there for them.
<G-vec00867-002-s043><cry.ausweinen><de> Wenn ein Freund Hilfe bei einer unschönen Aufgabe braucht oder er oder sie einfach eine Schulter zum Ausweinen braucht, sei da.
<G-vec00867-002-s044><cry.ausweinen><en> Just offering hugs, a shoulder to cry on, and an ear to talk to can help your friend move on.
<G-vec00867-002-s044><cry.ausweinen><de> Eine Umarmung, eine Schulter zum Ausweinen und ein Ohr zum Zuhören können deinem Freund helfen, diese Phase zu überstehen.
<G-vec00867-002-s045><cry.ausweinen><en> An old classmate of my 15 year old sister died of cancer last week and the first thing my mum offered her was a shoulder to cry on and a cup of tea.
<G-vec00867-002-s045><cry.ausweinen><de> Als ein alter Klassenkamerad meiner 15-jährigen Schwester letzte Woche an Krebs starb, war das erste, was meine Mutter ihr anbot, eine Schulter zum Ausweinen und eine Tasse Tee.
<G-vec00867-002-s046><cry.ausweinen><en> If a friend needs help with an unpleasant chore, or if they just need a shoulder to cry on, be there for them.
<G-vec00867-002-s046><cry.ausweinen><de> Wenn ein Freund Hilfe bei einer unangenehmen Aufgabe oder einfach eine Schulter zum Ausweinen braucht, dann sei für ihn da.
<G-vec00867-002-s047><cry.ausweinen><en> While a good Capricorn woman will always be willing to offer compassionate words of support and a loving shoulder to cry on during difficult times, they generally won't be satisfied in a relationship where they're expected to spend all of their excess energies helping you.
<G-vec00867-002-s047><cry.ausweinen><de> Eine gute Steinbock-Frau wird immer bereit sein, mit mitfühlenden Worten ihre Unterstützung zu bekunden und dir eine Schulter zum Ausweinen anzubieten, aber sie wird sich im Allgemeinen nicht in einer Beziehung wohl fühlen, in der von ihr erwartet wird, dass sie ihre ganze überschüssige Energie darauf verwenden muss, dir zu helfen.
<G-vec00867-002-s042><cry.sich_ausweinen><en> Kristine gets home toward morning, her clothes soaked with smoke and perfumes, and on her hot shoulder the old woman can finally have a cry and reject the words of comfort, saying: "All of this is good for me now.
<G-vec00867-002-s042><cry.sich_ausweinen><de> Kristine kehrt gegen Morgen heim, ihre Kleider vollgesogen mit Rauch und Parfum, und an dieser heißen Schulter kann sich die Alte endlich ausweinen und Beruhigungen zurückweisen mit den Worten: Das kommt mir jetzt alles zugute.
<G-vec00867-002-s043><cry.sich_ausweinen><en> If a friend needs help with an unpleasant chore, or if he or she just needs a shoulder to cry on, be there for them.
<G-vec00867-002-s043><cry.sich_ausweinen><de> Wenn ein Freund Hilfe bei einer unschönen Aufgabe braucht oder er oder sie einfach eine Schulter zum Ausweinen braucht, sei da.
<G-vec00867-002-s044><cry.sich_ausweinen><en> Just offering hugs, a shoulder to cry on, and an ear to talk to can help your friend move on.
<G-vec00867-002-s044><cry.sich_ausweinen><de> Eine Umarmung, eine Schulter zum Ausweinen und ein Ohr zum Zuhören können deinem Freund helfen, diese Phase zu überstehen.
<G-vec00867-002-s045><cry.sich_ausweinen><en> An old classmate of my 15 year old sister died of cancer last week and the first thing my mum offered her was a shoulder to cry on and a cup of tea.
<G-vec00867-002-s045><cry.sich_ausweinen><de> Als ein alter Klassenkamerad meiner 15-jährigen Schwester letzte Woche an Krebs starb, war das erste, was meine Mutter ihr anbot, eine Schulter zum Ausweinen und eine Tasse Tee.
<G-vec00867-002-s046><cry.sich_ausweinen><en> If a friend needs help with an unpleasant chore, or if they just need a shoulder to cry on, be there for them.
<G-vec00867-002-s046><cry.sich_ausweinen><de> Wenn ein Freund Hilfe bei einer unangenehmen Aufgabe oder einfach eine Schulter zum Ausweinen braucht, dann sei für ihn da.
<G-vec00867-002-s047><cry.sich_ausweinen><en> While a good Capricorn woman will always be willing to offer compassionate words of support and a loving shoulder to cry on during difficult times, they generally won't be satisfied in a relationship where they're expected to spend all of their excess energies helping you.
<G-vec00867-002-s047><cry.sich_ausweinen><de> Eine gute Steinbock-Frau wird immer bereit sein, mit mitfühlenden Worten ihre Unterstützung zu bekunden und dir eine Schulter zum Ausweinen anzubieten, aber sie wird sich im Allgemeinen nicht in einer Beziehung wohl fühlen, in der von ihr erwartet wird, dass sie ihre ganze überschüssige Energie darauf verwenden muss, dir zu helfen.
<G-vec00867-002-s298><cry.weinen><en> I cry tears of joy.
<G-vec00867-002-s298><cry.weinen><de> Ich weine Tränen der Freude.
<G-vec00867-002-s299><cry.weinen><en> When we arrive at the albergue that evening, I cry out of exhaustion and thankfulness for making it.
<G-vec00867-002-s299><cry.weinen><de> Als wir abends in der Herberge ankommen, weine ich vor Ersch?pfung und Dankbarkeit es geschafft zu haben.
<G-vec00867-002-s300><cry.weinen><en> I cry tears of happiness when I look at our wedding slideshow.
<G-vec00867-002-s300><cry.weinen><de> Ich weine jedes Mal vor Glück, wenn ich unsere Diashow anschaue.
<G-vec00867-002-s301><cry.weinen><en> Let yourself cry, scream, yell, or whatever you need to do to get your negative emotions out.
<G-vec00867-002-s301><cry.weinen><de> Weine, schreie, brülle oder tue was auch immer dir hilft, deine negativen Gefühle loszuwerden.
<G-vec00867-002-s302><cry.weinen><en> She has tried to fill the empty space in my bed, holding me each night until I cry myself to sleep.
<G-vec00867-002-s302><cry.weinen><de> Sie hat versucht, den leeren Raum in meinem Bett zu füllen, hält mich jede Nacht, bis ich mich in den Schlaf weine.
<G-vec00867-002-s303><cry.weinen><en> Then I started to cry a little.
<G-vec00867-002-s303><cry.weinen><de> Dann weine ich ein bisschen.
<G-vec00867-002-s304><cry.weinen><en> You take me in your arms when I cry.
<G-vec00867-002-s304><cry.weinen><de> Du nimmst mich in deine Arme, wenn ich weine.
<G-vec00867-002-s305><cry.weinen><en> “I went up to Chairman of the Board and said ‘I’m not gonna cry!’ and then I said, ‘Okay, I’m gonna cry!’ I was so utterly moved by the award.
<G-vec00867-002-s305><cry.weinen><de> „Ich sagte zum Vorsitzenden des Vorstands:,Ich werde nicht weinen!‘ Und dann sagte ich:,Na gut, dann weine ich eben!‘ Ich war von der Auszeichnung sehr gerührt.
<G-vec00867-002-s306><cry.weinen><en> Cry often, sleep restlessly, wake up from the slightest rustle.
<G-vec00867-002-s306><cry.weinen><de> Weine oft, schlaf unruhig, wache aus dem geringsten Rascheln auf.
<G-vec00867-002-s307><cry.weinen><en> I cry at commercials.
<G-vec00867-002-s307><cry.weinen><de> Ich weine bei Werbung.
<G-vec00867-002-s308><cry.weinen><en> 31 The Jews who were in the house with Mary, consoling her, saw Mary get up quickly and go outside. So they followed her, thinking that she was going to the tomb where they had buried Lazarus, in order to cry there.
<G-vec00867-002-s308><cry.weinen><de> 31 Die Juden, die bei ihr im Haus waren und sie trösteten, da sie sahen Maria, daß sie eilend aufstand und hinausging, folgten sie ihr nach und sprachen: Sie geht hin zum Grabe, daß sie daselbst weine.
<G-vec00867-002-s309><cry.weinen><en> Neither do I cry because of love for you.
<G-vec00867-002-s309><cry.weinen><de> Auch weine ich nicht aus Liebe zu euch.
<G-vec00867-002-s310><cry.weinen><en> I usually don't cry very easily, but at that time, I always wanted to cry.
<G-vec00867-002-s310><cry.weinen><de> Normalerweise weine ich nicht so leicht, doch in dieser Zeit musste ich immer wieder weinen.
<G-vec00867-002-s311><cry.weinen><en> Virgin Mary: I cry tears of blood for them and my Heart is heavy
<G-vec00867-002-s311><cry.weinen><de> Jungfrau Maria: Ich weine Bluttränen um euch, und Mein Herz ist schwer.
<G-vec00867-002-s312><cry.weinen><en> If I die of dehydration and someone finds this diary, I should mention that I cry every night.
<G-vec00867-002-s312><cry.weinen><de> Falls ich an Dehydrierung sterbe und jemand dieses Tagebuch findet, sollte ich erwähnen, dass ich jede Nacht weine.
<G-vec00867-002-s313><cry.weinen><en> Cry when you feel dirty, cry whenever your pacifier falls out, cry when you don't even know why you're crying.
<G-vec00867-002-s313><cry.weinen><de> Weine, wenn du schmutzig bist, heule, wenn dein Schnuller aus dem Mund fällt, weine, wenn du nicht einmal weißt, weshalb du weinst.
<G-vec00867-002-s315><cry.weinen><en> I have severe guilt I think about it and I cry.
<G-vec00867-002-s315><cry.weinen><de> Ich habe schwere Schuldgefühle, wenn ich daran denke und ich weine immer noch.
<G-vec00867-002-s316><cry.weinen><en> I also cry everyday.
<G-vec00867-002-s316><cry.weinen><de> Ich weine auch jeden Tag.
<G-vec00867-002-s317><cry.weinen><en> And don’t feel guilty for being crushed in spirit and not being able to do anything but cry.
<G-vec00867-002-s317><cry.weinen><de> Und fühle dich nicht schuldig dafür, im Geist gebrochen zu werden und nichts Anderes tun zu können als zu weinen.
<G-vec00867-002-s318><cry.weinen><en> More often the former is the case with us, so much so that, in a not too distant past, professional mourners were hired to cry and mourn in certain parts of the country.
<G-vec00867-002-s318><cry.weinen><de> Die erste Einschätzung ist bei uns aber viel häufiger, und zwar so sehr, dass es in einigen Teilen des Landes vor noch nicht allzu langer Zeit professionelle Trauernde gab, die man zum Weinen und Trauern anstellen konnte.
<G-vec00867-002-s319><cry.weinen><en> Many of them cry out of joy.
<G-vec00867-002-s319><cry.weinen><de> Mehrere weinen vor Freude.
<G-vec00867-002-s320><cry.weinen><en> Yonit began to cry.
<G-vec00867-002-s320><cry.weinen><de> Da begann Yonit zu weinen.
<G-vec00867-002-s322><cry.weinen><en> With them, we can talk, laugh, cry, argue and get along with afterwards.
<G-vec00867-002-s322><cry.weinen><de> Mit ihnen können wir reden, lachen, weinen, streiten und uns wieder vereinen.
<G-vec00867-002-s323><cry.weinen><en> I’m feeling cold, I’m feeling hot and I don’t know if I should cry or laugh.
<G-vec00867-002-s323><cry.weinen><de> Mir wird warm und kalt und ich weiß nicht ob ich lachen oder weinen soll.
<G-vec00867-002-s324><cry.weinen><en> At least, in that case, if you have got "no time", then surely you will have time to repent, to cry, to shed tears, at a time when nothing can be done.
<G-vec00867-002-s324><cry.weinen><de> Wenn das der Fall ist, wenn ihr immer "keine Zeit" habt, dann werdet ihr letzten Endes mit Sicherheit Zeit haben zu bereuen, zu weinen und Tränen zu vergießen – dann, wenn man nichts mehr tun kann.
<G-vec00867-002-s325><cry.weinen><en> Perlagie looked over at her daughter, peacefully sleeping in her bed, and began to cry.
<G-vec00867-002-s325><cry.weinen><de> Perlagie sah zu ihrer Tochter hinüber, die friedlich in ihrem Bettchen schlief, und begann zu weinen.
<G-vec00867-002-s326><cry.weinen><en> If you see a crying girlfriend who does not want to have a baby - you yourself will cry in reality because of a rather difficult situation.
<G-vec00867-002-s326><cry.weinen><de> Wenn du eine weinende Freundin siehst, die kein Baby haben will - wirst du selbst in einer eher schwierigen Situation weinen.
<G-vec00867-002-s327><cry.weinen><en> And then, he--he started to cry.
<G-vec00867-002-s327><cry.weinen><de> Und deshalb war er sehr traurig, und dann fing er an zu weinen.
<G-vec00867-002-s328><cry.weinen><en> An earthly father will hear the cry of his child.
<G-vec00867-002-s328><cry.weinen><de> Ein irdischer Vater wird das Weinen seines Kindes hören.
<G-vec00867-002-s329><cry.weinen><en> And every time I see them cry my heart breaks a bit more.
<G-vec00867-002-s329><cry.weinen><de> Und jedes Mal, wenn ich sie weinen sehe, bricht mein Herz ein Stück mehr.
<G-vec00867-002-s330><cry.weinen><en> I konnt do not sleep, only cry quietly at the night, I have prayed please she leaves me, do not take them from me...., however, them then said to us, allow to go me . I love you and am there always.
<G-vec00867-002-s330><cry.weinen><de> Ich konnt nicht schlafen, nur weinen still in die Nacht, ich habe gebetet bitte lass sie mir, nimm sie mir nicht....aber sie sagte uns dann, laßt mich gehen ..ich liebe euch und bin immer da .
<G-vec00867-002-s331><cry.weinen><en> Even whales would cry if they could hear this sample pack.
<G-vec00867-002-s331><cry.weinen><de> Selbst Wale würden weinen, wenn sie die Sounds dieser Klangbibliothek hören würden.
<G-vec00867-002-s332><cry.weinen><en> When the sisters rose, arm-in-arm, through the water in this way, their youngest sister would stand quite alone, looking after them, ready to cry, only that the mermaids have no tears, and therefore they suffer more.
<G-vec00867-002-s332><cry.weinen><de> Wenn die Schwestern so des Abends Arm in Arm hoch durch das Wasser hinaufstiegen, dann stand die kleinste Schwester allein und sah ihnen nach, und es war ihr, als ob sie weinen müsste; aber die Seejungfrau hat keine Tränen, und darum leidet sie weit mehr.
<G-vec00867-002-s333><cry.weinen><en> She sighed and began to cry.
<G-vec00867-002-s333><cry.weinen><de> Sie seufzte und begann zu weinen.
<G-vec00867-002-s334><cry.weinen><en> It will be too late to cry...
<G-vec00867-002-s334><cry.weinen><de> Es wird zu spät an zu weinen...
<G-vec00867-002-s335><cry.weinen><en> Join Mike and Nuang as they discover the true meanings of love, hate, and forgiveness. The Farang Affair is a must for anyone who has read Even Thai Girls Cry and for anyone destined to read One High Season: the final book of this unforgettable Thailand night of incredible passion they shared.
<G-vec00867-002-s335><cry.weinen><de> Begleite Mike und Nuang wenn sie die wahre Bedeutung von Liebe, Hass und Vergebung entdecken.„Die Farang Affäre“ ist ein Muss für jeden, der auch „Selbst Thai-Mädchen weinen“ gelesen hat und den Farang der ihre Schwester liebte, oder die Nacht der unglaublichen Leidenschaft die sie teilten, nicht vergessen.
<G-vec00867-002-s340><cry.weinen><en> That's what it is like if you don't cry.
<G-vec00867-002-s340><cry.weinen><de> Das entspricht dem, was passiert, wenn du nicht weinst.
<G-vec00867-002-s341><cry.weinen><en> You laugh, you cry, you radiate, you shine.
<G-vec00867-002-s341><cry.weinen><de> Du lachst, du weinst, du strahlst, du scheinst.
<G-vec00867-002-s342><cry.weinen><en> And you don't cry, and you are ferocious
<G-vec00867-002-s342><cry.weinen><de> Und du weinst nicht und bist wild.
<G-vec00867-002-s343><cry.weinen><en> You're so ugly when you cry (please)
<G-vec00867-002-s343><cry.weinen><de> Du siehst so hässlich aus, wenn du weinst.
<G-vec00867-002-s344><cry.weinen><en> You cry a lot and I wonder why.
<G-vec00867-002-s344><cry.weinen><de> Du weinst viel und ich frage mich, wieso.
<G-vec00867-002-s345><cry.weinen><en> you’re confused, lost, unsure, carrying the weight of your own potential on your aching shoulders, you still don’t have your life laid out, and you still cry about the little things.
<G-vec00867-002-s345><cry.weinen><de> du bist verwirrt, verloren, unsicher, trägst das Gewicht deines eigenen Potenzials auf deinen schmerzenden Schultern, du hast dein Leben nicht ausgemalt, und du weinst immer noch über kleine Dinge.
<G-vec00867-002-s346><cry.weinen><en> And you cry of emotion hearing a Bandoneon*
<G-vec00867-002-s346><cry.weinen><de> Und du weinst vor Rührung, wenn du ein Bandoneon hörst.
<G-vec00867-002-s347><cry.weinen><en> And you cry and you want to die.
<G-vec00867-002-s347><cry.weinen><de> Und du weinst und du willst sterben.
<G-vec00867-002-s348><cry.weinen><en> A baby will often cry a lot if they need to go to sleep.
<G-vec00867-002-s348><cry.weinen><de> Ein Baby weint oft viel, weil es schlafen will.
<G-vec00867-002-s349><cry.weinen><en> He advises other players to "Be strong and don't cry".
<G-vec00867-002-s349><cry.weinen><de> Sein Rat an andere Spieler: "Seid stark und weint nicht".
<G-vec00867-002-s350><cry.weinen><en> In my opinion, and you’ll have to forgive me for saying this, but if you’re going to cry when somebody dies, it’d be better to cry when somebody’s born.
<G-vec00867-002-s350><cry.weinen><de> Aus meiner Sicht, und mögen Sie mir verzeihen, dies zu sagen, für den Fall, daß Sie weinen, wenn jemand stirbt, ist es besser, wenn man weint, wenn jemand geboren wird.
<G-vec00867-002-s351><cry.weinen><en> You cry, walk another hundred meters, sit down again and cry once more.
<G-vec00867-002-s351><cry.weinen><de> Man weint, geht hundert Meter weiter, setzt sich wieder hin und weint erneut.
<G-vec00867-002-s353><cry.weinen><en> Only the father does not cry: it is pale, eyes shine moisture.
<G-vec00867-002-s353><cry.weinen><de> Nur der Vater weint nicht: er ist blass, die Augen glänzen von der Feuchtigkeit.
<G-vec00867-002-s354><cry.weinen><en> If you have found the right partner in your life, you can see the world from an entirely different angle, because suddenly there is someone with whom you can share everything. You can laugh together and cry together, you can find a solution for every problem and you have always someone by your side who stand behind you, even in hard situations.
<G-vec00867-002-s354><cry.weinen><de> Wenn man den richtigen Partner in seinem Leben gefunden hat, sieht man die Welt aus einem völlig anderen Blickwinkel, denn auf einmal ist dort jemand, mit dem man alles teilen kann, mit dem man lacht und weint, mit dem man für jedes Problem eine Lösung findet und der immer hinter einem steht, auch in schweren Situationen.
<G-vec00867-002-s355><cry.weinen><en> As a matter of fact, the mystic effort is not supposed to make a person cry over themself.
<G-vec00867-002-s355><cry.weinen><de> Übrigens soll die mystische Bemühung den Mensch nicht dazu verleiten, dass er über sich selbst weint.
<G-vec00867-002-s356><cry.weinen><en> It is a place to laugh and to cry, to play and to find peace.
<G-vec00867-002-s356><cry.weinen><de> Es ist der Ort, an dem man lacht und weint, an dem man tobt und zur Ruhe kommt.
<G-vec00867-002-s357><cry.weinen><en> If the child continues to cry, take him or her to a parent.
<G-vec00867-002-s357><cry.weinen><de> Wenn das Kind aber weiter weint, bringen Sie es am besten zu seinen Eltern.
<G-vec00867-002-s358><cry.weinen><en> She was convinced, even if I am going to be dead one day, please don't cry, because I am going to be happy.
<G-vec00867-002-s358><cry.weinen><de> Sie war davon überzeugt, selbst wenn ich mal sterbe, bitte weint nicht, weil ich froh sein werde.
<G-vec00867-002-s359><cry.weinen><en> Be prepared for the baby to cry and scream for 10-15 minutes after using them.
<G-vec00867-002-s359><cry.weinen><de> Bereiten Sie sich darauf vor, dass das Baby 10-15 Minuten nach dem Gebrauch weint und schreit.
<G-vec00867-002-s360><cry.weinen><en> The sad daughter would not cry when her mother picked her up from school, her cellphone pressed to her ear.
<G-vec00867-002-s360><cry.weinen><de> Die traurige Tochter weint nicht, wenn die Mutter sie mit dem iPhone am Ohr von der Schule abholt.
<G-vec00867-002-s361><cry.weinen><en> 12 «Emotionally unbearable» An interview with former Blick author Peter Hossli about his first book. Why he paid rent to the Mafia, where he goes to cry and why he goes off on assignment for selfish reasons.
<G-vec00867-002-s361><cry.weinen><de> 12 «Emotional nicht auszuhalten» Interview mit dem ehemaligen Blick-Autor Peter Hosslie über sein erstes Buch: Wieso er der Mafia Miete zahlte, wo er weint und wieso er aus Egoismus auf Reportage geht.
<G-vec00867-002-s362><cry.weinen><en> The de-escalating demonstrators who were not involved in the violence and who in the face of the pointless police actions became collateral damage didn’t cry a single tear in the radio and television reports. Nor did the police offer a single apology.
<G-vec00867-002-s362><cry.weinen><de> Übrigens: Den gewaltmäßig unbeteiligten und deeskalierenden DemonstrantInnen, die bei den ziellosen Polizeiaktionen regelmäßig als Kollateralschäden ihr Fett abkriegen weint kein einziger eine Träne in Funk und Fernsehen hinterher und auch von der Polizei hat man noch keine Entschuldigung vernommen.
<G-vec00867-002-s363><cry.weinen><en> The bladder reflects the psyche. When dark clouds blur the sky, the bladder often starts to cry.
<G-vec00867-002-s363><cry.weinen><de> Die Blase spiegelt die Psyche.Wenn dunkle Wolken den Himmel eintrüben, weint auch öfter mal die Blase.
<G-vec00867-002-s364><cry.weinen><en> You cry for them and there is no residual pain left inside of you.
<G-vec00867-002-s364><cry.weinen><de> Ihr weint für sie und es bleibt kein Schmerz in euch zurück.
<G-vec00867-002-s365><cry.weinen><en> The Elf infant continues to cry, but the sound is no longer muffled by its mother's cloak.
<G-vec00867-002-s365><cry.weinen><de> Das Elfenkind weint weiterhin, doch das Geräusch wird nicht mehr durch den Mantel seiner Mutter gedämpft.
<G-vec00867-002-s366><cry.weinen><en> ‘When you come to the South, you cry twice: once when you arrive and again when you leave‘.
<G-vec00867-002-s366><cry.weinen><de> “Wer in den Süden kommt, weint zweimal: wenn man ankommt und wenn man weggeht”.
<G-vec00867-002-s367><cry.weinen><en> She could not sleep and would cry the whole night whenever her son was being persecuted.
<G-vec00867-002-s367><cry.weinen><de> Wann immer ihr Sohn verfolgt wurde, konnte sie Nachts nicht schlafen und weinte die ganze Nacht hindurch.
<G-vec00867-002-s368><cry.weinen><en> I would cry before work and on the way to work and have to hide in the work toilets up to 12 times per day to "ritualise about my intrusive thoughts".
<G-vec00867-002-s368><cry.weinen><de> Ich weinte vor der Arbeit und auf dem Weg zur Arbeit und habe meine Zwänge auf der Toilette bis zu 12-mal pro Tag ritualisiert versteckt.
<G-vec00867-002-s369><cry.weinen><en> But every time I tried he’d wake up immediately and cry like crazy.
<G-vec00867-002-s369><cry.weinen><de> Aber jedes Mal, wenn ich es versuchte, wachte er auf und weinte wie verrückt.
<G-vec00867-002-s370><cry.weinen><en> Suddenly the colour rushed to her cheeks; she uttered a cry and hid her face in her hands.
<G-vec00867-002-s370><cry.weinen><de> Sie lehnte sich zurück, verbarg ihr Gesicht im Schnupftuch und weinte bitterlich.
<G-vec00867-002-s371><cry.weinen><en> He was weeping all the time and I would cry too.
<G-vec00867-002-s371><cry.weinen><de> Er hat die ganze Zeit geweint und ich weinte auch.
<G-vec00867-002-s372><cry.weinen><en> Whenever she saw other children playing with their parents she would cry.
<G-vec00867-002-s372><cry.weinen><de> Wenn sie andere Kinder mit ihren Eltern spielen sah, weinte sie.
<G-vec00867-002-s373><cry.weinen><en> He did not cry, but coughed and often breathed.
<G-vec00867-002-s373><cry.weinen><de> Er weinte nicht, sondern hustete und atmete oft.
<G-vec00867-002-s374><cry.weinen><en> I began to cry as I climbed down from Banner and fell to the ground by his feet.
<G-vec00867-002-s374><cry.weinen><de> Ich stieg von meinem alten Pferd, sank neben seinen Füßen zu Boden und weinte.
<G-vec00867-002-s375><cry.weinen><en> At times it was nearly unbearable, and I would cry and pray for strength to go on and not to feel so discouraged and alone.
<G-vec00867-002-s375><cry.weinen><de> Manchmal war es fast unerträglich und ich weinte und betete um Kraft, weitermachen zu können und mich nicht so mutlos und allein zu fühlen.
<G-vec00867-002-s376><cry.weinen><en> Hearing that the baby was "carried", go to him, not waiting for him to cry.
<G-vec00867-002-s376><cry.weinen><de> Als er hörte, dass das Baby "getragen" wurde, ging zu ihm und wartete nicht darauf, dass er weinte.
<G-vec00867-002-s377><cry.weinen><en> In the East, we recall the Buddha's human cry for a little bird before he got his enlightenment.
<G-vec00867-002-s377><cry.weinen><de> Im Osten erinnern wir uns daran, wie Buddha vor seiner Erleuchtung um einen kleinen Vogel weinte.
<G-vec00867-002-s378><cry.weinen><en> She took it up and gave it to him, saying the most beautiful things in the world, most beautifully expressed; I do not know where she learned them; God must have put them into her head, for the poor child was inspired to speak so nicely that it made me cry like a fool to hear her talk.
<G-vec00867-002-s378><cry.weinen><de> Sie nahm den Brief und hielt ihn ihm hin und sagte die schönsten und gefühlvollsten Dinge von der Welt, – ich weiß nicht, wo sie sie hernahm, Gott hat sie ihr eingegeben, denn das arme Mädchen sprach so ergreifend, daß ich weinte wie ein Schloßhund, als ich sie hörte.
<G-vec00867-002-s379><cry.weinen><en> I dropped my head, covered my face with my hands and began to cry again.
<G-vec00867-002-s379><cry.weinen><de> Ich beugte meinen Kopf nach vorne, verbarg mein Gesicht in meinen Händen und weinte erneut.
<G-vec00867-002-s380><cry.weinen><en> When the woman gave me the star of her mother, she began to cry bitterly.
<G-vec00867-002-s380><cry.weinen><de> Als die Frau mir den Stern ihrer Mutter gab, weinte sie bitterlich.
<G-vec00867-002-s381><cry.weinen><en> There was some energy contained in that message that made grown men cry or made them look up if they hadn’t yet awakened to their spirituality.
<G-vec00867-002-s381><cry.weinen><de> Sie enthielt eine Energie, die erwachsene Männer zum Weinen brachte oder sie veranlasste nach oben zu schauen, um zu sehen ob sie noch nicht in ihrer Spiritualität erwacht wären.
<G-vec00867-002-s382><cry.weinen><en> Sam Smith makes me cry.
<G-vec00867-002-s382><cry.weinen><de> Sam Smith bringt mich zum Weinen.
<G-vec00867-002-s383><cry.weinen><en> Euphoric melancholic melodies make your heart cry, but often leave a feeling of optimism.
<G-vec00867-002-s383><cry.weinen><de> Melancholisch euphorische Melodien bringen das Herz zum weinen, aber hinterlassen oft ein Gefühl des Optimismus.
<G-vec00867-002-s384><cry.weinen><en> I am human because it makes me cry to look at it.
<G-vec00867-002-s384><cry.weinen><de> Ich bin ein Mensch, denn es bringt mich zum weinen, es zu betrachten.
<G-vec00867-002-s385><cry.weinen><en> She even made me cry because she sang a Georgian song - "Suliko" - which I used to sing when I was a little child and, you know, hearing Georgian here in Finland is rather unusual...
<G-vec00867-002-s385><cry.weinen><de> Sie brachte mich sogar zum Weinen, denn sie sang das georgische Lied "Suliko", welches ich selbst immer als kleines Kind gesungen habe, und... Nun ja, es ist auch eher unüblich etwas Georgisches hier in Finnland zu hören...
<G-vec00867-002-s386><cry.weinen><en> It just grabs you, makes you laugh, cry, think, tap your feet and sing the next day.
<G-vec00867-002-s386><cry.weinen><de> Es packt sich einfach, bringt dich zum Lachen, zum Weinen, zum Denken, zum Tippen der Füßen und zum Singen der Texte am nächsten Tag.
<G-vec00867-002-s387><cry.weinen><en> So when she sat down to write her new album The Blade, released on Warner Music Nashville, she committed herself to finding songs that would make both her and her audience cry, laugh, think and, metaphorically, bleed.
<G-vec00867-002-s387><cry.weinen><de> Als sie sich also hinsetzte, um ihr neues Album The Blade zu schreiben, das auf Warner Music Nashville veröffentlicht wurde, verpflichtete sie sich, Songs zu finden, die sie und ihr Publikum zum Weinen, Lachen, Denken und, metaphorisch gesprochen, zum Bluten bringen würden.
<G-vec00867-002-s388><cry.weinen><en> Both, the landscape and the horse made me cry.
<G-vec00867-002-s388><cry.weinen><de> Beide, die Landschaft und das Pferd brachten mich zum Weinen.
<G-vec00867-002-s389><cry.weinen><en> However, studies show that it might not be too much estrogen that causes one person to weep more than another as much as higher testosterone in males might help them tune out emotions and avoid situations that would make them cry in the first place.
<G-vec00867-002-s389><cry.weinen><de> Studien zeigen jedoch, dass es nicht an zu viel Östrogen liegt, wenn eine Person mehr als eine andere weint und, dass erhöhtes Testosteron Männern helfen kann, Emotionen auszublenden und Situationen zu vermeiden, die sie zum Weinen bringen könnten.
<G-vec00867-002-s390><cry.weinen><en> When the singing ended, Dr. Cai kept silent for a few seconds. He then wiped away his tears and said to his audience, "The song makes me cry because I am deeply touched.
<G-vec00867-002-s390><cry.weinen><de> Als das Lied beendet war, schwieg er noch für einige Sekunden, dann wischte er seine Tränen fort und sagte zu dem Publikum: „Das Lied bringt mich zum Weinen, weil ich tief bewegt bin.
<G-vec00867-002-s391><cry.weinen><en> Onions make me cry when they are chopped.
<G-vec00867-002-s391><cry.weinen><de> 7 Gehackte Zwiebeln bringen mich zum Weinen.
<G-vec00867-002-s392><cry.weinen><en> But like I have often experienced in the past, once again I could cry, when I see such firstclass musicians up there on a stage in front of so less audiance, though the deserves so much more.
<G-vec00867-002-s392><cry.weinen><de> Wie ich schon des öfteren erlebt und dann betont habe, ist mir immer wieder zum Weinen zumute, wenn ich solchen Klassemusikern über den Weg laufe, die dann vor so wenigen Zuschauern spielen müssen.
