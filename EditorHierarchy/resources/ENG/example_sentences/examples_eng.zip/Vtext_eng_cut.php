<G-vec00555-002-s057><cut.abschneiden><en> After lots of futile attempts to save the mango trees, the only remaining option is to cut and burn them.
<G-vec00555-002-s057><cut.abschneiden><de> Nach vielen vergeblichen Versuchen bleibt nur die Möglichkeit, die kranken Bäume abzuschneiden und zu verbrennen.
<G-vec00555-002-s058><cut.abschneiden><en> Product Description This Selectable Portable 3G Cell Phone WiFi Jammer & GPS Signal Jammer that you are viewing here is the new designed signal jammer that is designed with the ability to cut off the signals of GSM, DCS, PCS, 3G,4G, 4G LTE,4G WiMax and WiFi GPS, i at the same time.
<G-vec00555-002-s058><cut.abschneiden><de> Produkt-Beschreibung Dieser auswählbare Handy-WiFi-Störsender des Portable-3G u. GPS-Signal-Störsender, dass Sie hier ansehen, ist der neue entworfene Signalstörsender, der mit der Fähigkeit, die Signale von G/M, von DCS, von PCS, von 3G, von 4G, von 4G LTE, von 4G WiMax und von GPS Lojack abzuschneiden entworfen ist, i gleichzeitig.
<G-vec00555-002-s059><cut.abschneiden><en> This allows the player running at him enough time to put pressure on him and cut off other options.
<G-vec00555-002-s059><cut.abschneiden><de> Dies gibt dem jeweils anlaufenden Spieler Zeit, ihn unter Druck zu setzen und weitere Optionen abzuschneiden.
<G-vec00555-002-s060><cut.abschneiden><en> A stove cut off may be used to cut off gas or power after a specified time.
<G-vec00555-002-s060><cut.abschneiden><de> Ein abgeschnittener Ofen wird verwendet möglicherweise, um Gas oder Leistung nach einer festgelegten Zeit abzuschneiden.
<G-vec00555-002-s061><cut.abschneiden><en> The heat can damage your curl pattern and the only way to remedy the damage is to cut the torched hair off.
<G-vec00555-002-s061><cut.abschneiden><de> Die Hitze kann die Struktur deiner Locken schädigen und die einzige Möglichkeit, diese Schäden zu heilen, ist es die verbrannten Haare abzuschneiden.
<G-vec00555-002-s062><cut.abschneiden><en> The girl was very impressed when her father told her that their country doctor easily could cut off a man's arm or leg, or even rip the belly and pull out the sick inside.
<G-vec00555-002-s062><cut.abschneiden><de> Das Mädchen war sehr beeindruckt, als der Vater ihm erzählte, dass es ihrem Landarzt nichts ausmacht, einen Arm oder ein Bein einem Menschen abzuschneiden oder sogar den Bauch zu reiβen und das Innere des Patienten herauszuziehen.
<G-vec00555-002-s063><cut.abschneiden><en> "I have run all the way in order to cut you off, Dr. Watson," said she.
<G-vec00555-002-s063><cut.abschneiden><de> It seems, „Ich bin den ganzen Weg gerannt, um Ihnen den Weg abzuschneiden, Dr. Watson“, sagte sie.
<G-vec00555-002-s064><cut.abschneiden><en> It could be set, using a decibel meter to provide a visual warning when the sound level at the neighbours property exceeded 45dB and to cut off mains power from the performers equipment if they continually ignored the warning lights.
<G-vec00555-002-s064><cut.abschneiden><de> Es konnte mit einem Dezibel-Meter gesetzt werden, um eine Sehwarnung zur Verfügung zu stellen, als der Geräuschpegel am Nachbareigentum 45 DB überschritten hat und Hauptmacht von der Darstellerausrüstung abzuschneiden, wenn sie ständig die Warnlichter ignoriert haben.
<G-vec00555-002-s065><cut.abschneiden><en> Crop (in the standalone version) lets you cut off unwanted areas in the image.
<G-vec00555-002-s065><cut.abschneiden><de> Das Freistellen-Werkzeug (nur in der Standalone-Version verfügbar) erlaubt es, unnötige Teile des Bildes abzuschneiden.
<G-vec00555-002-s066><cut.abschneiden><en> conventional vehicle door includes a complete outer skin with a window and lock hardware to cut off a vehicle cabin completely from the environment.
<G-vec00555-002-s066><cut.abschneiden><de> Eine herkömmliche Fahrzeugtür beinhaltet eine vollständige Außenhaut mit einem Fenster und Riegelhardware, um eine Fahrzeugkabine vollständig von der Umwelt abzuschneiden.
<G-vec00555-002-s067><cut.abschneiden><en> Beforehand, follow the roll of wallpaper to measure and cut off several strips, the size of the height of the pasted wall.
<G-vec00555-002-s067><cut.abschneiden><de> Zuvor folgen Sie der Rolle der Tapete, um mehrere Streifen zu messen und abzuschneiden, die Größe der Höhe der eingefügten Wand.
<G-vec00555-002-s068><cut.abschneiden><en> When the operation pressure of the mud pump is greater than the setting pressure, the discharge pressure of the mud pump push piston rod and the piston of the safety valve so as to open the shear pin board, and cut off the shear pin to immediately discharge the pressure of the mud pump from the outlet of the safety valve, thus to protect the mud pump effectively.
<G-vec00555-002-s068><cut.abschneiden><de> Wenn der Betriebsdruck der Schlammpumpe größer als der Einstelldruck ist, drückt der Abgabedruck der Schlammpumpe die Kolbenstange und den Kolben des Sicherheitsventils, um die Scherbolzenplatte zu öffnen und den Scherbolzen abzuschneiden, um sich sofort zu entladen der Druck der Schlammpumpe vom Auslass des Sicherheitsventils, um so die Schlammpumpe effektiv zu schützen.
<G-vec00555-002-s069><cut.abschneiden><en> Try to hit the zombies’ heads to cut them off with the ball for double score.
<G-vec00555-002-s069><cut.abschneiden><de> Versuchen Sie, die zombiesâ € ™ Köpfe, um sie abzuschneiden mit dem Ball für doppelte Punktzahl zu treffen.
<G-vec00555-002-s070><cut.abschneiden><en> He behaved in a noble-minded way towards them, but before setting them free, he ordered to cut off the nose of Rozhoň by a sickle as an exemplary act.
<G-vec00555-002-s070><cut.abschneiden><de> Er verhielt sich zu den Besiegten großzügig, jedoch bevor er ihnen die Freiheit schenkte, hatte er befohlen, Rozhoň zur Warnung die Nase mit Sichel abzuschneiden.
<G-vec00555-002-s071><cut.abschneiden><en> That is the reason why in some countries one is required to report capital wrong doings so to cut off ways to develop usuals from wrongs and gain benefit from the wrong deeds done by others in tolerating them, better taking part.
<G-vec00555-002-s071><cut.abschneiden><de> Das ist der Grund, warum es in manchen Ländern von einem gefordert wird, kapitales Fehlverhalten auf/anzuzeigen, um so die Gefahr des Üblichwerdens von Fehlhandlungen, und sich an Fehlhandlungen (auch mit Mitteln des Duldens) zu bereichern, abzuschneiden.
<G-vec00555-002-s072><cut.abschneiden><en> Many prefer to cut the spike entirely off and count on the plant building up its energy for a renewed larger new spike next growing season.
<G-vec00555-002-s072><cut.abschneiden><de> Viele ziehen es vor, die Spitze völlig abzuschneiden und auf dem Betrieb zu zählen, der seine Energie für eine erneuerte größere neue Spitze folgende wachsende Jahreszeit aufbaut.
<G-vec00555-002-s073><cut.abschneiden><en> While rolling the wrapper skin, to prevent the double folding of dough skin that causes uneven taste, a roller cutter is equipped to cut off the extra dough skin.
<G-vec00555-002-s073><cut.abschneiden><de> Während die Umhüllungshaut gerollt wird, um das doppelte Falten der Teighaut zu verhindern, das einen ungleichmäßigen Geschmack verursacht, ist ein Rollenschneider ausgerüstet, um die zusätzliche Teighaut abzuschneiden.
<G-vec00555-002-s074><cut.abschneiden><en> Your neighbor was correct to cut off the bad roots.
<G-vec00555-002-s074><cut.abschneiden><de> Dein Nachbar war korrekt, die schlechten Wurzeln abzuschneiden.
<G-vec00555-002-s075><cut.abschneiden><en> To cut supply lines to England Germany starts unrestricted submarine warfare in 1917.
<G-vec00555-002-s075><cut.abschneiden><de> Um die Nachschublinien der Briten abzuschneiden, startet Deutschland 1917 einen uneingeschränkten U-Boot-Krieg.
<G-vec00555-002-s076><cut.ausrotten><en> 6I have cut off nations; their battlements are desolate; I have made their streets waste, so that none passeth by; their cities are destroyed, so that there is no man, so that there is no inhabitant.
<G-vec00555-002-s076><cut.ausrotten><de> 6Ich habe Nationen ausgerottet, ihre Zinnen sind verödet; ich habe ihre Straßen verwüstet, daß niemand darüber zieht; ihre Städte sind verheert, daß niemand da ist, kein Bewohner mehr.
<G-vec00555-002-s077><cut.ausrotten><en> 17:14 For it is the life of all flesh; the blood of it is for the life thereof: therefore I said unto the children of Israel, All of you shall eat the blood of no manner of flesh: for the life of all flesh is the blood thereof: whosoever eats it shall be cut off.
<G-vec00555-002-s077><cut.ausrotten><de> 14 Denn des Leibes Leben ist in seinem Blut, solange es lebt; und ich habe den Kindern Israel gesagt: Ihr sollt keines Leibes Blut essen; denn des Leibes Leben ist in seinem Blut; wer es ißt, der soll ausgerottet werden.
<G-vec00555-002-s078><cut.ausrotten><en> 15 Ex 12, 15 Seven days shall ye eat unleavened bread; even the first day ye shall put away leaven out of your houses: for whosoever eateth leavened bread from the first day until the seventh day, that soul shall be cut off from Israel.
<G-vec00555-002-s078><cut.ausrotten><de> 15 Ex 12, 15 Sieben Tage sollt ihr Ungesäuertes essen; ja, am ersten Tage sollt ihr den Sauerteig aus euren Häusern wegtun; denn jeder, der Gesäuertes isset, von dem ersten Tage bis zu dem siebten Tage, selbige Seele soll ausgerottet werden aus Israel.
<G-vec00555-002-s079><cut.ausrotten><en> They are preserved forever, But the descendants of the wicked shall be cut off.
<G-vec00555-002-s079><cut.ausrotten><de> Ewiglich werden sie bewahrt, aber das Geschlecht der Frevler wird ausgerottet.
<G-vec00555-002-s080><cut.ausrotten><en> 48:9 For my name's sake will I defer my anger, and for my praise will I refrain for thee, {k} that I cut thee not off.
<G-vec00555-002-s080><cut.ausrotten><de> 9 Um meines Namens willen bin ich geduldig, und um meines Ruhms willen will ich mich dir zugut enthalten, daß du nicht ausgerottet werdest.
<G-vec00555-002-s081><cut.ausrotten><en> 20 But if those who are unclean do not purify themselves, they must be cut off from the community, because they have defiled the sanctuary of the Lord. The water of cleansing has not been sprinkled on them, and they are unclean.
<G-vec00555-002-s081><cut.ausrotten><de> 20 Wer aber unrein wird und sich nicht entsündigen will, der soll ausgerottet werden aus der Gemeinde; denn er hat das Heiligtum des HERRN unrein gemacht und ist nicht mit Reinigungswasser besprengt; darum ist er unrein.
<G-vec00555-002-s082><cut.ausrotten><en> [4] Behold, I have divided unto you by lot these nations that remain, to be an inheritance for your tribes, from Jordan, with all the nations that I have cut off, even unto the great sea westward.
<G-vec00555-002-s082><cut.ausrotten><de> 23:4 Seht, ich habe euch diese übriggebliebenen Völker durch das Los zugeteilt, einem jeden Stamm sein Erbteil, vom Jordan an, und alle Völker, die ich ausgerottet habe bis an das große Meer, wo die Sonne untergeht.
<G-vec00555-002-s083><cut.ausrotten><en> 21 And if anyone touches an unclean thing, whether human uncleanness or an unclean beast or any unclean detestable creature, and then eats some flesh from the sacrifice of the Lord's peace offerings, that person shall be cut off from his people.”
<G-vec00555-002-s083><cut.ausrotten><de> 7,21 Und wenn jemand mit etwas Unreinem in Berührung gekommen ist, es sei ein unreiner Mensch, ein unreines Vieh oder was sonst ein Greuel ist, und dann vom Fleisch des Dankopfers ißt, das dem HERRN gehört, der wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s084><cut.ausrotten><en> 9 and bringeth it not unto the door of the tent of meeting, to sacrifice it unto Jehovah; that man shall be cut off from his people.
<G-vec00555-002-s084><cut.ausrotten><de> 9und bringt es nicht vor die Tür der Stiftshütte, um es dem HERRN zu opfern, der wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s085><cut.ausrotten><en> However, many biblical scholars assert that this interpretation is false, and that the phrase "cut off from among their people" refers instead to sickness and early death sent by the all-knowing Yahweh himself.
<G-vec00555-002-s085><cut.ausrotten><de> Theologen sind jedoch heute der Ansicht, dass dies falsch ist und dass der Ausdruck „aus ihrem Volk ausgerottet werden" sich auf Krankheit und frühen Tod bezieht, den der allmächtige Gott schickt.
<G-vec00555-002-s086><cut.ausrotten><en> As for other flesh, anyone who is clean may eat such flesh. 20But the person who eats the flesh of the sacrifice of peace offerings which belong to the Lord, in his uncleanness, that person shall be cut off from his people.
<G-vec00555-002-s086><cut.ausrotten><de> Und was das Fleisch betrifft, jeder Reine darf das Fleisch essen; 20aber die Seele, welche Fleisch von dem Friedensopfer isset, das Jehova gehört, und ihre Unreinigkeit ist an ihr, selbige Seele soll ausgerottet werden aus ihren Völkern.
<G-vec00555-002-s087><cut.ausrotten><en> 30:38 Whoever makes any like it, for its sweet smell, will be cut off from his people.
<G-vec00555-002-s087><cut.ausrotten><de> 30:38 Wer es macht, damit er sich an dem Geruch erfreue, der soll ausgerottet werden aus seinem Volk.
<G-vec00555-002-s088><cut.ausrotten><en> Therefore every one that eateth it shall 9 bear his iniquity, because he hath profaned the hallowed thing of the LORD: and that soul shall be cut off from among his people.
<G-vec00555-002-s088><cut.ausrotten><de> 19,7 Wird aber am dritten Tage davon gegessen, so ist es ein Greuel und wird nicht wohlgefällig sein; 19,8 und wer davon ißt, muss seine Schuld tragen, weil er das Heilige des HERRN entheiligt hat, und ein solcher Mensch wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s089><cut.ausrotten><en> 34 Look unto Jehovah, and keep His way, And He doth exalt thee to possess the land, In the wicked being cut off -- thou seest!
<G-vec00555-002-s089><cut.ausrotten><de> Harre auf den HERRN und halte seinen Weg, so wird er dich erhöhen, daß du das Land erbest; du wirst es sehen, daß die Gottlosen ausgerottet werden.
<G-vec00555-002-s090><cut.ausrotten><en> 14 The uncircumcised male who is not circumcised in the flesh of his foreskin, that soul shall be cut off from his people.
<G-vec00555-002-s090><cut.ausrotten><de> 14Wenn aber ein Männlicher nicht beschnitten wird an seiner Vorhaut, wird er ausgerottet werden aus seinem Volk, weil er meinen Bund gebrochen hat.
<G-vec00555-002-s091><cut.ausrotten><en> 27 Whatever soul it be that eateth any manner of blood, that soul shall be cut off from his peoples.
<G-vec00555-002-s091><cut.ausrotten><de> 27Jeder, der Blut isst, wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s092><cut.ausrotten><en> 23:4 Behold, I have divided to you by lot these nations that remain, to be an inheritance for your tribes, from Jordan, with all the nations that I have cut off, even to the great sea westward.
<G-vec00555-002-s092><cut.ausrotten><de> 23:4 Sehet, ich habe euch die übrigen Völker durchs Los zugeteilet, einem jeglichen Stamm sein Erbteil, vom Jordan an, und alle Völker, die ich ausgerottet habe, und am großen Meer gegen der Sonnen Untergang.
<G-vec00555-002-s093><cut.ausrotten><en> 21 Anyone who touches something unclean—whether human uncleanness or an unclean animal or any unclean creature that moves along the groundb —and then eats any of the meat of the fellowship offering belonging to the LORD must be cut off from their people.’ ”
<G-vec00555-002-s093><cut.ausrotten><de> 21 Und wenn eine Person irgend etwas Unreines anrührt, die Unreinheit eines Menschen oder ein unreines Vieh oder irgend etwas unreines Abscheuliches, und sie ißt vom Fleisch des Heilsopfers, das dem HERRN gehört: diese Person soll aus ihren Volksgenossen ausgerottet werden.
<G-vec00555-002-s094><cut.ausrotten><en> 18If there is a man who lies with a menstruous woman and uncovers her nakedness, he has laid bare her flow, and she has exposed the flow of her blood; thus both of them shall be cut off from among their people.
<G-vec00555-002-s094><cut.ausrotten><de> 18Und wenn ein Mann bei einem Weibe liegt in ihrer Krankheit und ihre Blöße aufdeckt, so hat er ihre Quelle enthüllt, und sie hat die Quelle ihres Blutes aufgedeckt; sie sollen beide ausgerottet werden aus der Mitte ihres Volkes.
<G-vec00555-002-s095><cut.ausschneiden><en> Great advancements have been achieved in the Dynamic Photo function, which enables users to cut out images of a moving subject and paste them on a different still image that acts as a background.
<G-vec00555-002-s095><cut.ausschneiden><de> Die Dynamic Photo-Funktion, mit der ein sich bewegendes Motiv ausgeschnitten und auf ein anderes unbewegtes Hintergrundbild gesetzt werden kann, wurde erheblich verbessert.
<G-vec00555-002-s096><cut.ausschneiden><en> On the latter I stamped the first part of the sentiment and then fussy cut it out before stamping the second part as well.
<G-vec00555-002-s096><cut.ausschneiden><de> Auf das weiße Papier habe ich den Spruch gestempelt und es dann per Hand "ausgeschnitten" bevor ich dann noch den zweiten Teil hinzugestempelt habe.
<G-vec00555-002-s097><cut.ausschneiden><en> I stamped it once with black ink, once heat embossed it using golden embossing powder, then cut those out and put them on brown cardstock.
<G-vec00555-002-s097><cut.ausschneiden><de> Der ist einmal mit schwarzer Tinte und einmal golden embossed gestempelt, ausgeschnitten und auf braunen Cardstock geklebt.
<G-vec00555-002-s098><cut.ausschneiden><en> With large honeycombs, the curves are cut out of the sheet and tapered at each end.
<G-vec00555-002-s098><cut.ausschneiden><de> Bei den großen Waben werden die Kurven an jedem Ende verjüngt und aus der Platte ausgeschnitten.
<G-vec00555-002-s099><cut.ausschneiden><en> stamped the boy and girl images, colored them and then cut them out trimming closely.
<G-vec00555-002-s099><cut.ausschneiden><de> Ich habe den Jungen und das Mädchen abgestempelt, coloriert und dann anschließend konturengenau ausgeschnitten.
<G-vec00555-002-s100><cut.ausschneiden><en> I stamped the flowers again, wiped them with Distress Inks in colour, cut them out and glued them on.
<G-vec00555-002-s100><cut.ausschneiden><de> Die Blüten habe ich nochmal extra gestempelt, mit Distress Inks farbig gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s101><cut.ausschneiden><en> Some children cut out their footprints and draw something on it that deserves protection for them.
<G-vec00555-002-s101><cut.ausschneiden><de> Einige Kinder haben ihren Fußabdruck ausgeschnitten und etwas aus der Natur darauf gemalt, was für sie besonders schützenswert ist.
<G-vec00555-002-s102><cut.ausschneiden><en> Where it previously had to be tediously cut and adjusted, the pipe can now easily be inserted through the prepared inflow opening and the rainwater hopper mounted directly on the wall.
<G-vec00555-002-s102><cut.ausschneiden><de> Wo bisher langwierig ausgeschnitten und angepasst werden musste, kann das Rohr jetzt spielend leicht in die vorbereitete Zulauföffnung eingesteckt und der Regenfangkasten direkt an der Wand montiert werden.
<G-vec00555-002-s103><cut.ausschneiden><en> The image is colored with Copics and cut out by hand.
<G-vec00555-002-s103><cut.ausschneiden><de> Das Motiv ist mit Copics coloriert und ausgeschnitten.
<G-vec00555-002-s104><cut.ausschneiden><en> As a sheet material, for example textile materials such as woven or knitted fabrics, but also films are also conceivable, of which the markings are, for example punched or cut out.
<G-vec00555-002-s104><cut.ausschneiden><de> Als flächiges Material sind zB textile Materialien wie Gewebe oder Gewirke, aber auch Folien denkbar, aus denen die Markierungen zB ausgestanzt oder ausgeschnitten sind.
<G-vec00555-002-s105><cut.ausschneiden><en> Der Carstock mit den Motiven (eine Maus aus dem Mice Time to Celebrate Set, The paper with the stamped on images (a mouse from the Mice Time to Celebrate stamp set, one of the bears from the Joyful Heart Bears set and a piglet from the Piggy Pebbles set) ist glued behind the frame and the images were cut out so the pieces that would've been covered by the frame are on top of it.
<G-vec00555-002-s105><cut.ausschneiden><de> Den weißen Cardstock im Hintergrund, den ich schwarz gemattet und auf eine weiße Grundkarte geklebt habe, ist mit Distress Ink Tumbled Glass und verschiedenen "Flecken" aus dem Distressed ein Bär aus dem Joyful Heart Bears Set und noch ein Schweinchen aus dem Piggy Pebbles Set) ist hinter den Rahmen geklebt und die Motive so ausgeschnitten, dass die eigentlich vom Rahmen abgedeckten Teile der Tiere vorne über den Rahmen überstehen.
<G-vec00555-002-s106><cut.ausschneiden><en> I wiped the elephants with grey paint, cut them out and glued them on.
<G-vec00555-002-s106><cut.ausschneiden><de> Die Elefanten habe ich mit grauer Farbe gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s107><cut.ausschneiden><en> Comprehensive editing functions (e.g., block functions such as cut, copy, paste, move, even directly moving into other windows without using the clipboard).
<G-vec00555-002-s107><cut.ausschneiden><de> Umfangreiche Editierfunktionen (Blöcke können ausgeschnitten, eingefügt, verschoben oder in andere Programmfenster kopiert werden, auch direkt in andere Fenster ohne den Umweg über das Clipboard).
<G-vec00555-002-s108><cut.ausschneiden><en> From the dense cardboard, two identical figures are cut out.
<G-vec00555-002-s108><cut.ausschneiden><de> Aus dem dichten Karton werden zwei identische Figuren ausgeschnitten.
<G-vec00555-002-s109><cut.ausschneiden><en> And some of them, being cut out, can come to be an object on the wall.
<G-vec00555-002-s109><cut.ausschneiden><de> Einige werden dann ausgeschnitten und so kann man sie als eine Art Objekt an die Wand hängen.
<G-vec00555-002-s110><cut.ausschneiden><en> The span is 2 meters and own parts were cut out by hand for the feathers of the wings.
<G-vec00555-002-s110><cut.ausschneiden><de> Die Spannweite liegt bei 2 Metern und es wurden für die Federn der Flügel eigene Teile per Hand ausgeschnitten.
<G-vec00555-002-s111><cut.ausschneiden><en> In order to ensure the desired quality standard, these small openings must be cut out precisely.
<G-vec00555-002-s111><cut.ausschneiden><de> Um den gewünschten Qualitätsstandard gewährleisten zu können, müssen diese kleinen Öffnungen sehr passgenau ausgeschnitten werden.
<G-vec00555-002-s112><cut.ausschneiden><en> Each photo can be cut out and send as a postcard.
<G-vec00555-002-s112><cut.ausschneiden><de> Jedes Foto kann danach als Postkarte ausgeschnitten und weitergeschickt werden.
<G-vec00555-002-s113><cut.ausschneiden><en> Make a collage of images you cut out from magazines by overlapping them on your cardstock.
<G-vec00555-002-s113><cut.ausschneiden><de> Erstelle eine Collage aus Bildern, die du aus Zeitschriften ausgeschnitten hast, indem du sie überlappend auf dem Karton anbringst.
<G-vec00555-002-s228><cut.kürzen><en> On the back of 2012 when banks added more than 534.6 tons to gold reserves, the most since 1964, the move suggests a possible shift in dynamics as several banks have now cut their gold forecasts for 2013.
<G-vec00555-002-s228><cut.kürzen><de> Nach 2012, als die Banken mehr als 534,6 Tonnen an Goldreserven aufstockten, die größte Reserve seit 1964, zeigt diese Bewegung, dass die Dynamik vor einer Wende steht, da zahlreiche Banken nun ihre Gold-Prognosen für 2013 gekürzt haben.
<G-vec00555-002-s229><cut.kürzen><en> Though UK development funds have been made available to support health systems, with some positive results, the UK recently cut its aid to both countries as it promotes greater private healthcare across Africa.
<G-vec00555-002-s229><cut.kürzen><de> Obwohl öffentliche Gesundheitssysteme mit britischen Entwicklungshilfegeldern gefördert wurden, mit einigen positiven Ergebnissen, hat Großbritannien kürzlich seine Entwicklungshilfe an beide Länder gekürzt, da es überall in Afrika eine private Gesundheitsversorgung fördert.
<G-vec00555-002-s230><cut.kürzen><en> The World Bank predicts that, even under the most optimistic growth and reform scenarios, total public spending would have to be cut by an unprecedented 6.5 percent of GDP.
<G-vec00555-002-s230><cut.kürzen><de> Die Weltbank geht davon aus, dass sogar unter Voraussetzung der optimistischsten Wachstums- und Reformszenarien die öffentlichen Ausgaben um nie da gewesene 6,5 Prozent des BIP gekürzt werden müssten.
<G-vec00555-002-s231><cut.kürzen><en> Wages would have to be cut by means of inflation, the profit rate supported by lowering the interest rate, and the remaining unemployment absorbed by public works, until these measures produced the beginning of a new prosperity, at which point the economy could be left once again to the automatic mechanism of the market.
<G-vec00555-002-s231><cut.kürzen><de> Die Löhne müßten auf dem Wege der Inflation gekürzt, die Profitrate durch die Senkung der Zinsrate gestützt, und der verbleibende Rest der Arbeitslosigkeit durch öffentliche Ausgaben aufgesaugt werden, bis sich durch all diese Maßnahmen eine neue Konjunktur herausbildet, womit man die Wirtschaft für eine weitere Etappe dem Automatismus des Marktes überlassen könnte.
<G-vec00555-002-s232><cut.kürzen><en> (Brussels, 09.05.2018) According to a proposal tabled by the EU Commissioner for Budget and Human Resources Günther Oettinger, the agriculture budget is to be cut by five percent.
<G-vec00555-002-s232><cut.kürzen><de> (Brüssel, 09.05.2018) Nach Vorschlag von EU-Haushaltskommissar Günther Oettinger soll der Agrarhaushalt um fünf Prozent gekürzt werden.
<G-vec00555-002-s233><cut.kürzen><en> A second version, now cut to two acts, was staged at the Theater an der Wien in 1806 — with greater success, but with no demand for further performances.
<G-vec00555-002-s233><cut.kürzen><de> Eine zweite Fassung, nunmehr gekürzt auf zwei Akte, konnte 1806 im Theater an der Wien aufgeführt werden – mit mehr Erfolg, allerdings ohne weitere Nachfrage.
<G-vec00555-002-s234><cut.kürzen><en> That is why we have restore funds the Council has cut for research and development programmes, such as the EU’s Horizon 2020; aid for small and medium-sized enterprises; education, including the student mobility programme Erasmus+; and aid for the most deprived.
<G-vec00555-002-s234><cut.kürzen><de> Deshalb haben wir die Mittel wiedereingesetzt, die der Rat für Forschungs- und Entwicklungsprogramme gekürzt hat, beispielsweise Horizont 2020; Unterstützung für kleine und mittelgroße Unternehmen; Bildung, einschließlich des Studentenmobilitätsprogramms Erasmus+; und die Hilfe für bedürftige Bürgerinnen und Bürger.
<G-vec00555-002-s235><cut.kürzen><en> The last block of characters, read to the variable, will be cut to the amount of bytes really read.
<G-vec00555-002-s235><cut.kürzen><de> Der letzte Block der zu lesenden Zeichen wird in der Variable auf die tatsächliche benötigte Menge an Bytes gekürzt.
<G-vec00555-002-s236><cut.kürzen><en> The rear of the vehicle frame may be cut up to the first cross member behind the rear of the last axle of the suspension.
<G-vec00555-002-s236><cut.kürzen><de> Der hintere Teil des Fahrzeugrahmens darf bis zum ersten Querträger hinter dem hintersten Punkt der Radaufhängung der letzten Achse gekürzt werden.
<G-vec00555-002-s237><cut.kürzen><en> Can be cut every 3 LEDs (12V) / 6 LEDs (24V).
<G-vec00555-002-s237><cut.kürzen><de> Die Leiste kann alle 5cm(12V) / 10cm(24V) gekürzt werden.
<G-vec00555-002-s238><cut.kürzen><en> And whenever they are exposed, or their funding is cut, they scream that it is due to a right-wing plot.
<G-vec00555-002-s238><cut.kürzen><de> Und wo immer sie öffentlich blossgestellt werden oder ihre Finanzierung gekürzt wird, schreien sie, das sei Folge einer rechten Verschwörung.
<G-vec00555-002-s239><cut.kürzen><en> Over all, I still got a slight impression, that this set tonight has been even a bit cut down, due to the circumstances.
<G-vec00555-002-s239><cut.kürzen><de> Alles in allem kann ich mich aber des Eindrucks nicht erwehren, dass das Set noch mal um einige Tracks gekürzt wurde, auf Grund der Umstände.
<G-vec00555-002-s240><cut.kürzen><en> Since I am a little bit too small for a floor-length coat, I cut mine.
<G-vec00555-002-s240><cut.kürzen><de> Da ich mich aber für einen bodenlangen Mantel zu klein finde, habe ich den Mantel gekürzt.
<G-vec00555-002-s241><cut.kürzen><en> Just tell us if you want to have cut her watchband prior to shipment.
<G-vec00555-002-s241><cut.kürzen><de> Sagen Sie uns einfach, wenn Sie ihr Uhrenarmband vor dem Versand gekürzt haben möchten.
<G-vec00555-002-s242><cut.kürzen><en> “Usually at other studios you create the story and two days before ‘script lock’ they tell you they have to cut the game in half, asking if you can ‘just go ahead and adjust the story,'” he laughs.
<G-vec00555-002-s242><cut.kürzen><de> „In anderen Studios entwirft man die Story, um zwei Tage vor der Deadline für das Skript gesagt zu bekommen, dass das Spiel um die Hälfte gekürzt werden muss, und darum gebeten wird, mal eben schnell die Story anzupassen”, lacht er.
<G-vec00555-002-s243><cut.kürzen><en> Fuel subsidies were cut twice this year.
<G-vec00555-002-s243><cut.kürzen><de> Treibstoffsubventionen wurden dieses Jahr zweimal gekürzt.
<G-vec00555-002-s244><cut.kürzen><en> The disciplinary sanction continues to perpetuate even today: the pension of the man is still cut by 25%.
<G-vec00555-002-s244><cut.kürzen><de> Heute wird dem Polizisten seine Pension deshalb immer noch strafweise um ein Viertel gekürzt.
<G-vec00555-002-s245><cut.kürzen><en> Originally, Lifetime had ordered 20 episodes of the series, the number was later cut to only 14.
<G-vec00555-002-s245><cut.kürzen><de> Ursprünglich hatte Lifetime 20 Folgen der Serie geordert, diese Zahl wurde später auf 14 gekürzt.
<G-vec00555-002-s246><cut.kürzen><en> The extremely durable 300 mm blade made of hardened steel can be cut to size to suit your crops.
<G-vec00555-002-s246><cut.kürzen><de> Dieses unverwüstliche Jätmesser aus 300mm dickem, gehärtetem Stahl kann gekürzt werden, um sich so gut wie möglich an Ihre Reihenabstände anzupassen.
<G-vec00555-002-s380><cut.reduzieren><en> He told the forum it made sense to cut the number in the French-speaking region.
<G-vec00555-002-s380><cut.reduzieren><de> Im RTS-Forum schrieb er, in der französischsprachigen Westschweiz würde es durchaus Sinn machen, die Anzahl der Geräte zu reduzieren.
<G-vec00555-002-s381><cut.reduzieren><en> With a corrugated box cutting machine, you will not only be able to cut the costs of packaging supplies that your company uses, but you will also be able to cut the shipping costs that your company is constantly incurring as well.
<G-vec00555-002-s381><cut.reduzieren><de> Mithilfe von Wellpappe-Schneidemaschinen werden Sie nicht nur die Kosten der Verpackungsmaterialien Ihres Unternehmens, sondern auch die Versandkosten reduzieren können, die Ihrem Unternehmen laufend entstehen.
<G-vec00555-002-s382><cut.reduzieren><en> Cut energy costs across your distributed office by 35 percent and gain 100 percent visibility into the energy usage of every device in your data center.
<G-vec00555-002-s382><cut.reduzieren><de> Reduzieren Sie die Stromkosten an verteilten Standorten um 35 Prozent und sorgen Sie für vollständige Transparenz hinsichtlich des Energieverbrauchs jedes einzelnen Geräts in Ihrem Rechenzentrum.
<G-vec00555-002-s383><cut.reduzieren><en> In October 2012, a cogeneration plant was taken into service at the company's largest production site in Wiesloch-Walldorf, Germany. In the future, this plant will cut the site's energy costs by 10 percent and save 3,700 metric tons of CO2 each year.
<G-vec00555-002-s383><cut.reduzieren><de> Im Oktober 2012 ging am Standort Wiesloch-Walldorf - dem größten Produktionsstandort des Unternehmens - ein Blockheizkraftwerk in Betrieb, das künftig die Energiekosten des Standortes um zehn Prozent reduzieren wird, und das jährlich 3.700 Tonnen CO2 einspart.
<G-vec00555-002-s384><cut.reduzieren><en> And best of all, a line with of OneStep technology can cut your total cost of ownership drastically.
<G-vec00555-002-s384><cut.reduzieren><de> Und das Beste: Eine Prozesslinie mit OneStep-Technologie kann Ihre Gesamtbetriebskosten drastisch reduzieren.
<G-vec00555-002-s385><cut.reduzieren><en> One of the features of the polarizing filter is that it can cut out reflections that appear in a water surface or glass window.
<G-vec00555-002-s385><cut.reduzieren><de> Ein Merkmal von Polfiltern besteht darin, dass er Spiegelungen auf Wasseroberflächen oder Fensterscheiben erheblich reduzieren kann.
<G-vec00555-002-s386><cut.reduzieren><en> Sorry,you have to pay it first,but we'll cut the costs in your next order(20GP).
<G-vec00555-002-s386><cut.reduzieren><de> Tut mir leid müssen Sie es zuerst zahlen, aber wir reduzieren die Kosten in Ihrem folgenden Auftrag (20GP).
<G-vec00555-002-s387><cut.reduzieren><en> Cut engineering time and costs to meet your customers' expectations.
<G-vec00555-002-s387><cut.reduzieren><de> Reduzieren Sie Entwicklungszeit und -kosten und erfüllen Sie die Anforderungen Ihrer Kunden.
<G-vec00555-002-s388><cut.reduzieren><en> They’re not supposed to cut costs; they’re supposed to improve processes.
<G-vec00555-002-s388><cut.reduzieren><de> Sie sollen nicht Kosten reduzieren, sondern Prozesse verbessern.
<G-vec00555-002-s389><cut.reduzieren><en> The electricity costs for one and two-family homes can be cut by 25 to 40 percent.
<G-vec00555-002-s389><cut.reduzieren><de> Die Stromkosten im Ein- und Zweifamilienhaus lassen sich um 25 bis 40 Prozent reduzieren.
<G-vec00555-002-s390><cut.reduzieren><en> If your insulin is high, you're likely consuming too much sugar and need to cut back.
<G-vec00555-002-s390><cut.reduzieren><de> Wenn der Insulinspiegel hoch ist, konsumieren Sie wahrscheinlich zu viel Zucker und müssen Ihre Zuckerzufuhr reduzieren.
<G-vec00555-002-s391><cut.reduzieren><en> Writing about what you are doing can help you explore and express what you are feeling as you cut back or quit using marijuana.
<G-vec00555-002-s391><cut.reduzieren><de> Darüber zu schreiben, was du machst, kann dir helfen, herauszufinden und auszudrücken, was du empfindest, während du versuchst, deinen Marihuanakonsum zu reduzieren.
<G-vec00555-002-s392><cut.reduzieren><en> Take advantage of innovative products that optimize your manufacturing process, cut your water consumption and improve pulp quality.
<G-vec00555-002-s392><cut.reduzieren><de> Profitieren Sie von innovativen Produkten, die Ihren Herstellungsprozess optimieren, den Wasser- und Energieverbrauch reduzieren und die Zellstoffqualität verbessern.
<G-vec00555-002-s393><cut.reduzieren><en> Around the world, businesses of all shapes and sizes trust us to deliver technology systems that cut complexity, quickly.
<G-vec00555-002-s393><cut.reduzieren><de> Überall auf der Welt vertrauen Unternehmen aller Formen und Größen uns, Technologiesysteme zu liefern, die die Komplexität schnell reduzieren.
<G-vec00555-002-s394><cut.reduzieren><en> This is a bottle for life which you can use to cut down your personal plastic consumption in a heartbeat.
<G-vec00555-002-s394><cut.reduzieren><de> Diese Flasche kann euer neuer, lebenslanger Begleiter werden, mit dem ihr auch euren persönlichen Plastikverbrauch einfach reduzieren könnt.
<G-vec00555-002-s395><cut.reduzieren><en> Most likely I will cut back in the next few years, continuing to see my regular clients, but not taking on any new people.
<G-vec00555-002-s395><cut.reduzieren><de> Höchstwahrscheinlich werde ich in den nächsten paar Jahren reduzieren, das heißt meine regelmäßigen Kunden weiterhin treffen, aber keine neuen mehr annehmen.
<G-vec00555-002-s396><cut.reduzieren><en> If you want to cut your company’s trade show costs drastically, there is no way around meticulous planning.
<G-vec00555-002-s396><cut.reduzieren><de> Wer die Messekosten seines Unternehmens drastisch reduzieren möchte, kommt nicht um eine detaillierte Planung herum.
<G-vec00555-002-s397><cut.reduzieren><en> As a result, the charging time for a lithium-ion battery could be cut from an hour to just 12 minutes.
<G-vec00555-002-s397><cut.reduzieren><de> Demzufolge ließe sich die Ladezeit eines Lithium-Ionen-Akkus von einer Stunde auf gerade einmal zwölf Minuten reduzieren.
<G-vec00555-002-s398><cut.reduzieren><en> According to the developers, this device can significantly cut costs related to lab tests for diseases such as HIV, syphilis, and Lyme disease.
<G-vec00555-002-s398><cut.reduzieren><de> Entsprechend den Entwicklern kann diese Einheit die Kosten beträchtlich reduzieren, die auf Laborversuchen für Krankheiten wie HIV, Syphilis und Lyme-Borreliose in Verbindung gestanden werden.
<G-vec00555-002-s456><cut.schneiden><en> The machine uses a sawing unit to cut diagonally through the rectangular unprocessed part. It moves the two halves apart so that the four- or five-piece spindles can trim and profile the steps from all sides.
<G-vec00555-002-s456><cut.schneiden><de> Mit einem Sägeaggregat schneidet die Maschine diagonal durch den rechteckigen Rohling und fährt beide Hälften soweit auseinander, dass die Vier- oder Fünfachsspindel die Stufen ringsherum fräsen und profilieren kann.
<G-vec00555-002-s457><cut.schneiden><en> Peter Breuer, on the other hand, now prepares the schedule for the next several days, and works with his “music guy” to cut the songs down to a suitable length.
<G-vec00555-002-s457><cut.schneiden><de> Peter Breuer hingegen bereitet noch den Plan für die nächsten Tage vor und schneidet mit seinem Ton-Verantwortlichen die Songs auf die richtige Länge zu.
<G-vec00555-002-s458><cut.schneiden><en> Zum Vergrößern bitte anklicken / click to enlarge Take your scissors and your first piece of cardstock and cut your score lines exactly like the purple lines in the sketch show from the upper line to the middle mark you just made.
<G-vec00555-002-s458><cut.schneiden><de> Wiederholt das mit dem anderen Stück noch einmal genau Jetzt nehmt ihr euch eine Schere und schneidet beim ersten Stück Cardstock von oben bis zum markierten Mittelpunkt die Falzlinie ein, genau wie die lilafarbenen Linien in der Skizze es zeigen.
<G-vec00555-002-s459><cut.schneiden><en> Then cut a window in one of the large sections.
<G-vec00555-002-s459><cut.schneiden><de> Schneidet dann in einen der Deckel ein Fenster.
<G-vec00555-002-s460><cut.schneiden><en> If you cut the upper portion of your body, as soon as you see inside, it is all obnoxious horrible things.
<G-vec00555-002-s460><cut.schneiden><de> Wenn ihr in den oberen Teil des Körpers schneidet, sobald ihr hineinseht, ist alles darin abstoßend und grässlich.
<G-vec00555-002-s461><cut.schneiden><en> The dual blade system of this electric shaver lifts hairs to cut comfortably below skin level. Spring-released pop-up trimmer
<G-vec00555-002-s461><cut.schneiden><de> Das 2-Klingen-System dieses Elektrorasierers hebt die Haare an und schneidet sie direkt für eine sanfte Rasur an der Hautoberfläche ab.
<G-vec00555-002-s462><cut.schneiden><en> When laser head cut metals, there will produce some hot energy in laser head and laser device.
<G-vec00555-002-s462><cut.schneiden><de> Wenn der Laserkopf Metalle schneidet, wird im Laserkopf und im Lasergerät etwas heiße Energie erzeugt.
<G-vec00555-002-s463><cut.schneiden><en> The doctor under local anesthesia will cut a bridle or special scissors, or a laser.
<G-vec00555-002-s463><cut.schneiden><de> Der Arzt unter örtlicher Betäubung schneidet einen Zaum oder eine spezielle Schere oder einen Laser.
<G-vec00555-002-s464><cut.schneiden><en> File folder cards can be found many made with the punchboard....but not everyone has it...so I made one without First you cut your cardstock to the given size and lay it along the short side to the ScorPal and score at 10,5 cm...
<G-vec00555-002-s464><cut.schneiden><de> Immer wieder findet man File Folder Karten, die mit dem Punchboard gefertigt werden...allerdings hat ja nicht jeder so ein tolles Board zur Hand...und so habe ich eine File Folder Card ohne Punchboard für euch Als erstes schneidet ihr euren Cardstock auf die passende Größe zu...anschließend legt ihr euch den Cardstock mit der langen Seite oben am ScorPal an und falzt ihn bei 10,5cm...
<G-vec00555-002-s465><cut.schneiden><en> Cut a slit in the lime wedge and rub it around the rim of a tall beer glass.
<G-vec00555-002-s465><cut.schneiden><de> Schneidet den Limettenkeil ein und streicht damit den Glasrand eines Bierglases ein.
<G-vec00555-002-s466><cut.schneiden><en> And so you cut yourself off.
<G-vec00555-002-s466><cut.schneiden><de> Und auf diese Weise schneidet ihr euch selbst ab.
<G-vec00555-002-s467><cut.schneiden><en> When nearly dry cut the bread into small squares and season it well with powdered sage, salt and pepper.
<G-vec00555-002-s467><cut.schneiden><de> Man schneidet die Stücke 2 cm dick, salzt und pfeffert sie und wendet sie leicht in Mehl um.
<G-vec00555-002-s468><cut.schneiden><en> Take a cardboard disk with the diameter of the telescope's optic, cut two (or three) holes in it and place it in front of the telescope.
<G-vec00555-002-s468><cut.schneiden><de> Man nimmt im einfachsten Fall eine Pappscheibe, die die Teleskopöffnung abdeckt, schneidet zwei runde Löcher hinein und plaziert die Scheibe vor der Teleskopöffnung.
<G-vec00555-002-s469><cut.schneiden><en> Roughly cut out 2 pieces from an old jeans, which are about the same size and a little larger than the stamped image.
<G-vec00555-002-s469><cut.schneiden><de> Grob schneidet man nun 2 ungefähr gleich große Stücke aus einer alten Jeanshose, die ein bisschen größer sind als das gestempelte Motiv.
<G-vec00555-002-s470><cut.schneiden><en> Cut away the things of the world, accept the leadership of Jesus Christ, or you’ll perish as sure as the world.
<G-vec00555-002-s470><cut.schneiden><de> Schneidet die Dinge der Welt ab und nehmt die Führerschaft Jesu Christi an, sonst werdet ihr so sicher wie die Welt umkommen.
<G-vec00555-002-s471><cut.schneiden><en> He uses it to cut samples from every possible source, and later these serve as the main themes for pieces.
<G-vec00555-002-s471><cut.schneiden><de> Damit schneidet er aus allen möglichen Quellen Samples raus, die dann als Grundmotive für Stücke dienen.
<G-vec00555-002-s472><cut.schneiden><en> Interreg DiveSMART Baltic Method The Cutting Extinguisher technique consists of a mixture of water and cutting agent (abrasive) being ejected through a special nozzle at high pressure (>250 bar) to cut through all known building and construction materials.
<G-vec00555-002-s472><cut.schneiden><de> Bei der Schneidlöschtechnik wird dem Löschwasser über eine spezielle Düse unter hohem Druck (>250 bar) ein Schneidmittel (Abrasivmittel) zugesetzt, mit dessen Hilfe der Wasserstrahl durch alle bekannten Baumaterialien schneidet.
<G-vec00555-002-s473><cut.schneiden><en> You can use a good pair of kitchen scissors to cut through practically anything: paper, cardboard, corrugated cardboard, string, fabric, aluminium foil or cling film and other packaging used in the kitchen, as well as of course herbs, rosemary sprigs, rhubarb, flowers etc.
<G-vec00555-002-s473><cut.schneiden><de> Mit einer guten Küchenschere schneidet Ihr so gut wie alles: Papier, Pappe, Wellpappe, Bindfäden, Stoff, Alu- oder Plastikfolie und andere Verpackungen rund ums Kochen, aber natürlich auch Kräuter, Rosmarinzweige, Rhabarber, Blumen usw..
<G-vec00555-002-s474><cut.schneiden><en> Now cut the inside of the brim.
<G-vec00555-002-s474><cut.schneiden><de> Jetzt schneidet ihr den inneren Kreis der Krempe aus.
<G-vec00555-002-s494><cut.senken><en> This hybrid model protects your investment in legacy STBs and infrastructure while simultaneously helping you to cut costs and benefit from the greater functionality, speed of innovation and flexibility that comes with a move to the cloud.
<G-vec00555-002-s494><cut.senken><de> Dieses Hybridmodell schützt Ihre Investition in ältere STB und Infrastruktur und hilft Ihnen gleichzeitig Kosten zu senken und von der größeren Funktionalität, Innovationsgeschwindigkeit und Flexibilität zu profitieren, die mit dem Wechsel in die Cloud einhergehen.
<G-vec00555-002-s495><cut.senken><en> It reduces spending on unemployment benefits and enables us to cut the contributions needed to fund them.
<G-vec00555-002-s495><cut.senken><de> Das senkt die Ausgaben fürs Arbeitslosengeld und erlaubt es, die Abgaben dafür zu senken.
<G-vec00555-002-s496><cut.senken><en> We do not involve external providers which is how we can cut costs and increase flexibility.
<G-vec00555-002-s496><cut.senken><de> Durch den Verzicht auf externe Dienstleister, senken wir die Gesamtkosten und steigern die Flexibilität.
<G-vec00555-002-s497><cut.senken><en> Increase your efficiency and cut your costs by optimized processes and outstanding detergents.
<G-vec00555-002-s497><cut.senken><de> Steigern Sie Ihre Effizienz und senken Sie Ihre Kosten durch optimierte Prozesse und einzigartige Produkte.
<G-vec00555-002-s498><cut.senken><en> The editorial concluded, “For eight years, Republicans mercilessly attacked President Barack Obama for doing too little to cut federal deficits.
<G-vec00555-002-s498><cut.senken><de> Zum Schluss hieß es: „Die Republikaner haben Präsident Barack Obama acht Jahre lang unablässig vorgeworfen, er würde zu wenig tun, um das Haushaltsdefizit zu senken.
<G-vec00555-002-s499><cut.senken><en> Not only does GesySense offer higher reliability, but the system also helps to cut the energy consumption of the refrigerated delivery vehicles: Delivery vehicles with eutectic accumulator cooling, which do not have their own controller, but are only refrigerated when connected to the power grid, are real energy guzzlers.
<G-vec00555-002-s499><cut.senken><de> GesySense bietet nicht nur höhere Zuverlässigkeit, das System hilft auch, den Energiebedarf der Kühlfahrzeuge zu senken: Fahrzeuge mit eutektischer Speicherkühlung, die ohne eigene Regelung nur durch einen Netzanschluss gekühlt werden, sind wahre Energiefresser.
<G-vec00555-002-s500><cut.senken><en> It will radically cut the minute price for productions and make formats possible, that were previously too time-consuming or expensive to create and will allow “the creative” to produce animated content without the technical expertise needed today.
<G-vec00555-002-s500><cut.senken><de> Sie wird den Minutenpreis von Produktionen radikal senken und Formate ermöglichen, die davor zu zeitaufwändig und teuer in der Herstellung waren und den Kreativen ermöglichen, animierte Inhalte ohne das heute noch dafür benötigte technische Fachwissen zu produzieren.
<G-vec00555-002-s501><cut.senken><en> The petition, inspired by the words of Pope Francis in Laudato Si’, urges leaders to drastically cut carbon emissions.
<G-vec00555-002-s501><cut.senken><de> Die Petition, inspiriert durch die Worte von Papst Franziskus in Laudato Si´, verlangt die CO2-Emissionen drastisch zu senken.
<G-vec00555-002-s502><cut.senken><en> Compass wants to cut its greenhouse gas emissions by 20%, and Gloor and Compass managers like him are assisted by Zurich food start-up Eaternity.
<G-vec00555-002-s502><cut.senken><de> Compass will seine Treibhausgas-Emissionen um 20% senken, und Gloor und die anderen Manager der Gruppe werden dabei von der Zürcher Startup-Firma Eaternity unterstützt.
<G-vec00555-002-s503><cut.senken><en> Optimize power consumption and cut power and cooling costs by up to 20 percent during low utilization periods by automatically putting hosts in standby mode during low use times and powering them back up as needed with Distributed Power Management.
<G-vec00555-002-s503><cut.senken><de> Optimieren Sie den Stromverbrauch und senken Sie die Strom- und Kühlungskosten in Zeiten mit geringer Auslastung um bis zu 20%, indem Sie Hosts während solcher Zeiten automatisch mit Distributed Power Management in den Standby-Modus versetzen und nach Bedarf wieder hochfahren lassen.
<G-vec00555-002-s504><cut.senken><en> But we don’t have enough revenue to offer as much of a tax cut this year as I would like.
<G-vec00555-002-s504><cut.senken><de> Wir haben aber in diesem Jahr nicht genug Staatseinkünfte, um die Steuern um so viel zu senken, wie ich möchte.
<G-vec00555-002-s505><cut.senken><en> The benefit of this is as film is an expensive medium; cheaper options to cut cost can be explored.
<G-vec00555-002-s505><cut.senken><de> Der Vorteil davon ist, als Film ein teures Medium ist; billigere Möglichkeiten Kosten zu senken können erkundet werden.
<G-vec00555-002-s506><cut.senken><en> There's a quick way to cut your expenses, and it's literally at your fingertips.
<G-vec00555-002-s506><cut.senken><de> Es gibt eine Möglichkeit, mit der Sie Ihre Ausgaben im Handumdrehen senken können – und sie ist greifbar nah.
<G-vec00555-002-s507><cut.senken><en> Offers efficiency as high as 97% to cut energy usage and cost.
<G-vec00555-002-s507><cut.senken><de> Bietet Effizienz so hoch wie 97% auf den Energieverbrauch und die Kosten zu senken.
<G-vec00555-002-s508><cut.senken><en> This allows IT departments to cut their costs and to target their budgets more accurately towards application management.
<G-vec00555-002-s508><cut.senken><de> Dies ermöglicht es IT-Abteilungen Kosten zu senken und Budgets für das Application Management zielgerichteter einzusetzen.
<G-vec00555-002-s509><cut.senken><en> He expects the Federal Reserve to raise interest rates four times this year and other central banks will cut interest rates .
<G-vec00555-002-s509><cut.senken><de> Er geht davon aus, dass die Federal Reserve in diesem Jahr viermal die Zinsen erhöhen wird und andere Zentralbanken die Zinsen senken werden.
<G-vec00555-002-s510><cut.senken><en> Optimize power consumption and cut power and cooling costs by up to 20 percent during low utilization periods by automatically putting hosts in standby mode during low use times and powering them back up as needed with Distributed Power Management.
<G-vec00555-002-s510><cut.senken><de> Optimieren Sie den Energieverbrauch und senken Sie die Strom- und Kühlungskosten bei geringerer Auslastung um bis zu 20%, indem Sie Hosts mit Distributed Power Management in den Standby-Modus versetzen und nach Bedarf wieder hochfahren.
<G-vec00555-002-s511><cut.senken><en> Cost-effective calculation of insulation thickness and professional installation by KAEFER cut your energy costs and help protect the environment by reducing CO2 emissions.
<G-vec00555-002-s511><cut.senken><de> Wirtschaftliche Dämmdickenberechnung und fachgerechte Ausführung von KAEFER senken Ihre Energiekosten und unterstützen den Klimaschutz durch die Reduzierung der CO2-Belastung.
<G-vec00555-002-s512><cut.senken><en> During the 1979 election campaign, Clark had promised to cut taxes to stimulate the economy.
<G-vec00555-002-s512><cut.senken><de> Während des Wahlkampfs hatte er versprochen, die Steuern zu senken, um die Wirtschaft zu stimulieren.
<G-vec00555-002-s513><cut.zerschneiden><en> By contrast, the unique Skrunda radar station, alas, was blown up, and Soviet submarines were cut up into scrap.
<G-vec00555-002-s513><cut.zerschneiden><de> Leider wurde ein unikales Objekt – das Radioteleskop von Skrunda gesprengt, die sowjetischen U-Boote wurden zerschnitten...
<G-vec00555-002-s514><cut.zerschneiden><en> For scanning APS films with the Super Coolscan 9000 ED anyway the film has to be removed out of its cartridge, cut up and placed in a special strip film holder with glass.
<G-vec00555-002-s514><cut.zerschneiden><de> Um dennoch APS-Filme mit dem Super Coolscan 9000 ED zu scannen, müssen diese aus der Filmspule herausgenommen, zerschnitten und in einen speziellen Filmstreifenhalter mit Glaseinsatz eingelegt werden.
<G-vec00555-002-s515><cut.zerschneiden><en> A further plus point: The integrated spring steel strips also have an anti-theft function in the vertical direction: If the curtain is wilfully cut, only the cut to the next spring steel strip is possible.
<G-vec00555-002-s515><cut.zerschneiden><de> Weiterer Pluspunkt: Die integrierten Federstahlstreifen übernehmen in vertikaler Richtung auch eine Diebstahlschutzfunktion: Wird die Plane mutwillig zerschnitten, ist nur der Schnitt bis zum nächsten Federstahlstreifen möglich.
<G-vec00555-002-s516><cut.zerschneiden><en> The bottom of the gown and the sleeves are cut in wedges.
<G-vec00555-002-s516><cut.zerschneiden><de> Der untere Teil des Gewandes sowie die Ärmel sind zu Spitzen zerschnitten.
<G-vec00555-002-s517><cut.zerschneiden><en> If the mats are cut remove them carefully with a dog detangling comb with rotating teeth.
<G-vec00555-002-s517><cut.zerschneiden><de> Wenn die Matten zerschnitten sind versuchen Sie diese vorsichtig mit einem Hundekamm mit rotierenden Zähnen zu entfernen.
<G-vec00555-002-s518><cut.zerschneiden><en> The pain became serious as if my internal organs were cut into pieces.
<G-vec00555-002-s518><cut.zerschneiden><de> Die Schmerzen wurden so stark, als würden meine inneren Organe zerschnitten.
<G-vec00555-002-s519><cut.zerschneiden><en> The protective sleeves are vital to ensure that the sharp edges of the concrete do not cut the belts during this movement.
<G-vec00555-002-s519><cut.zerschneiden><de> Dass bei dieser Bewegung nicht die scharfen Kanten des Betons zerschnitten werden, dafür sind die Kantenschutzschläuche von erheblicher Bedeutung.
<G-vec00555-002-s520><cut.zerschneiden><en> If we had had stabbing weapons, then we had cut our intestines.
<G-vec00555-002-s520><cut.zerschneiden><de> Hätten wir Stichwaffen gehabt, wir hätten uns die Eingeweide zerschnitten.
<G-vec00555-002-s521><cut.zerschneiden><en> Found material is copied, cut, mirrored and glued.
<G-vec00555-002-s521><cut.zerschneiden><de> Vorgefundenes Material wird kopiert, zerschnitten, gespiegelt und geklebt.
<G-vec00555-002-s522><cut.zerschneiden><en> The picture on the right illustrates the procedure: A sharp knife is used to cut a wiper into three pieces (holder, arm and blade).
<G-vec00555-002-s522><cut.zerschneiden><de> Das Bild rechts zeigt das Prozedere: Mit einem scharfen Messer wird der Wischer in drei Teile (Halterung, Arm und Blatt) zerschnitten.
<G-vec00555-002-s523><cut.zerschneiden><en> In order to achieve a complete removal, the 300 t tripod has to be cut in parts.
<G-vec00555-002-s523><cut.zerschneiden><de> Dafür muss das 300 Tonnen schwere Fundament in mehrere Teile zerschnitten werden.
<G-vec00555-002-s524><cut.zerschneiden><en> Under threat is Cameroon’s coherent and unique ecosystem which like in Tanzania, will be cut into two parts.
<G-vec00555-002-s524><cut.zerschneiden><de> Genau wie in Tansania würde auch in Kamerun ein zusammenhängendes einzigartiges Ökosystem in zwei Teile zerschnitten.
<G-vec00555-002-s525><cut.zerschneiden><en> But when the royal envoy came to him, Joseph said,42 "Go back to your lord and ask him to inquire about the matter of the women who cut their hands.
<G-vec00555-002-s525><cut.zerschneiden><de> Als der Bote zu ihm kam, sagte er: "Kehr zu deinem Herrn zurück und frag ihn, wie es mit den Frauen steht, die sich ihre Hände zerschnitten.
<G-vec00555-002-s526><cut.zerschneiden><en> It proved difficult though, as the volume really overran the audience and the high frequencies of the squeezebox and electric guitar in particular cut through the eardrum.
<G-vec00555-002-s526><cut.zerschneiden><de> Das erwies sich jedoch meist als schwierig, da die Lautstärke das Publikum regelrecht überrollte und vor allem die hohen Frequenzen von Quetsche und E-Gitarre schier das Trommelfell zerschnitten.
<G-vec00555-002-s527><cut.zerschneiden><en> This is cut into small pieces and then ground it into a powder along with various types of recycled plastics.
<G-vec00555-002-s527><cut.zerschneiden><de> Dieses wird in kleine Teile zerschnitten und im Anschluss mit verschiedenen Arten von Recyclingkunststoffen zu einem Pulver gemahlen.
<G-vec00555-002-s528><cut.zerschneiden><en> We cut those animal hide thongs, threw away the two bottles of potions, and prayed to God for his protection.
<G-vec00555-002-s528><cut.zerschneiden><de> Wir zerschnitten diese Tierhautschnüre, warfen die zwei Medizinflaschen fort und baten Gott um seinen Schutz.
<G-vec00555-002-s529><cut.zerschneiden><en> In the video, the interview language is cut apart into individual word fragments.
<G-vec00555-002-s529><cut.zerschneiden><de> Die Interviewsprache wird hier in isolierte Worte zerschnitten und mit einer monologisierenden Off-Stimme kommentiert.
<G-vec00555-002-s530><cut.zerschneiden><en> Beef, buffalo, venison, rabbit or rattlesnake meat was cut into small chunks, seasoned with spicy dried chili peppers and slowly simmered in a pot over a campfire.
<G-vec00555-002-s530><cut.zerschneiden><de> Rindfleisch, Buffalo, Reh, Kaninchen oder Schlangenfleisch wurde in kleine Stückchen zerschnitten, mit heissen getrockneten Chili Pfeffern gewürzt und dann langsam in einem Topf über einem Kampingfeuer gekocht.
<G-vec00555-002-s531><cut.zerschneiden><en> A geometric shape which is cut up in one place is always the same.
<G-vec00555-002-s531><cut.zerschneiden><de> Gleich ist immer eine geometrische Form, die an einer Stelle zerschnitten ist.
<G-vec00555-002-s551><cut.zuschneiden><en> Now that blocks 1 through 12 of the BERNINA Triangle Quilt Along have been sewn, it’s time to cut out the remaining pieces.
<G-vec00555-002-s551><cut.zuschneiden><de> Nachdem nun Block 1 bis 12 des BERNINA Triangle Quilt-Alongs genäht sind, geht es ans Zuschneiden der übrigen Teile.
<G-vec00555-002-s552><cut.zuschneiden><en> Start by making a template of the walls to be papered, then you can test that the pieces are large enough before you cut out the real wallpaper.
<G-vec00555-002-s552><cut.zuschneiden><de> Beginnen Sie damit, eine Vorlage der Wände zu erstellen, die tapeziert werden soll, und testen Sie, ob die Teile groß genug sind, bevor Sie die eigentliche Tapete zuschneiden.
<G-vec00555-002-s553><cut.zuschneiden><en> We assemble it ourselves, as we cut the guide rails to the exact length in our workshop and then drill the appropriate holes. ” Michael Geisler adds: “Our customers are thrilled by the overall concept.
<G-vec00555-002-s553><cut.zuschneiden><de> Wir konfektionieren selbst, da wir die Führungsschienen in unserer Werkstatt auf die exakte Länge zuschneiden und anschließend die entsprechenden Bohrungen vornehmen.“ Michael Geisler ergänzt dazu: „Unsere Kunden sind vom Gesamtkonzept begeistert.
<G-vec00555-002-s554><cut.zuschneiden><en> If your design is irregularly shaped, you'll need to cut the restraints in order to follow the edges of your design.
<G-vec00555-002-s554><cut.zuschneiden><de> Wenn dein Design unregelmäßig geformt ist, wirst du die Randbefestigung zuschneiden müssen, damit du der Form von deinem Design entsprechen kannst.
<G-vec00555-002-s555><cut.zuschneiden><en> The Tapco Power Cut-Off can be used to accurately cut aluminium, steel, zinc or copper.
<G-vec00555-002-s555><cut.zuschneiden><de> Die Power Cut-Off von Tapco ist eine elektrische Rollenschere, die das präzise Zuschneiden von Aluminium, Stahl, Zink und Kupfer ermöglicht.
<G-vec00555-002-s556><cut.zuschneiden><en> Finally cut 5 big Chocolate Protein Bars.
<G-vec00555-002-s556><cut.zuschneiden><de> Aus der gekühlten Masse 5 große Schoko Eiweißriegel zuschneiden.
<G-vec00555-002-s557><cut.zuschneiden><en> 03 Cut 5.5 x 11 cm rectangles from the white and black cardboard.
<G-vec00555-002-s557><cut.zuschneiden><de> 03 Aus weißem und schwarzem Karton 5,5 x 11 cm große Rechtecke zuschneiden.
<G-vec00555-002-s558><cut.zuschneiden><en> Noir T30 Flat Bar is 600mm wide for maximum control and can be easily cut for customized fit.
<G-vec00555-002-s558><cut.zuschneiden><de> Der Noir T30 Flatbar ist 600 mm breit, bietet maximale Kontrolle und lässt sich einfach inviduell zuschneiden und anpassen.
<G-vec00555-002-s559><cut.zuschneiden><en> Cut a slice of lemon with a sharp knife on a chopping board and place in the drink to garnish.
<G-vec00555-002-s559><cut.zuschneiden><de> Mit einem scharfen Messer auf einem Schneidebrett eine Zitronenscheibe zuschneiden und als Garnitur auf das Getränk geben.
<G-vec00555-002-s560><cut.zuschneiden><en> Cut the fabric strip to a suitable size.
<G-vec00555-002-s560><cut.zuschneiden><de> Die Stoffstreifen auf die geeignete Größe zuschneiden.
<G-vec00555-002-s561><cut.zuschneiden><en> With a sharp knife and chopping board, cut a wedge of lemon and place on top of the drink to garnish.
<G-vec00555-002-s561><cut.zuschneiden><de> Mit einem scharfen Messer auf einem Schneidebrett eine Zitronenspalte zuschneiden und als Garnitur auf das Getränk geben.
<G-vec00555-002-s562><cut.zuschneiden><en> You can cut the hair for a even better fit.
<G-vec00555-002-s562><cut.zuschneiden><de> Sie können die Haare für eine noch bessere Passform zuschneiden.
<G-vec00555-002-s563><cut.zuschneiden><en> The pin board cork can be easily cut with a utility knife and a stop rail.
<G-vec00555-002-s563><cut.zuschneiden><de> Der Pinwand-Kork läßt sich ganz einfach mit einem Teppichmesser und einer Anschlagschiene zuschneiden.
<G-vec00555-002-s564><cut.zuschneiden><en> FOAMGLAS® can be easily cut and installed on site or is available prefabricated.
<G-vec00555-002-s564><cut.zuschneiden><de> FOAMGLAS® Dämmung lässt sich auf der Baustelle leicht zuschneiden und montieren oder ist vorgefertigt verfügbar.
<G-vec00555-002-s565><cut.zuschneiden><en> Cover with the second sheet of the dough and cut out squares to form the ravioli.
<G-vec00555-002-s565><cut.zuschneiden><de> Mit der zweiten Teigplatte abdecken, zuschneiden und nach Belieben Ravioli formen.
<G-vec00555-002-s566><cut.zuschneiden><en> Attention: With the rectangle you have the seam allowance included so you can cut on your lines.
<G-vec00555-002-s566><cut.zuschneiden><de> Achtung: Beim Rechteck habt ihr die Nahtzugaben schon mit eingerechnet, könnt hier also auf den Linien zuschneiden.
<G-vec00555-002-s567><cut.zuschneiden><en> Tips Your local lumber store will most likely cut the 2 x 4s to length for you... this is far less expensive than buying the proper power saw if you don't own it.
<G-vec00555-002-s567><cut.zuschneiden><de> Methode 7 von 7: Wertung Tipps Dein örtliches Holzlager kann dir die 2x4 Latten sicherlich auf Länge zuschneiden – dies ist wesentlich preisgünstiger als die richtige Säge zu kaufen, wenn du keine besitzt.
<G-vec00555-002-s568><cut.zuschneiden><en> Thanks to our range of CNC machinery in Butzbach, which includes a CNC panel saw, we can cut our own fire protection cladding for steel girders and pillars.
<G-vec00555-002-s568><cut.zuschneiden><de> Dank unseres CNC-Maschinenparks in Butzbach, wo neben anderen mit einer CNC-gesteuerten Plattensäge gearbeitet wird, können wir Brandschutzbekleidungen für Stahlträger und Stahlstützen selbst zuschneiden.
<G-vec00555-002-s569><cut.zuschneiden><en> Make sure to cut down your paper or film in complete darkness.
<G-vec00555-002-s569><cut.zuschneiden><de> Auf jeden Fall musst du Fotopapier und Film in absoluter Dunkelheit zuschneiden.
<G-vec00047-002-s019><cut.abschneiden><en> Wrap longer text over multiple lines to avoid text getting cut off in smaller breakpoints.
<G-vec00047-002-s019><cut.abschneiden><de> Ordnen Sie längeren Text über mehrere Zeilen an, um zu vermeiden, dass Text an kleineren Umbruchpunkten abgeschnitten wird.
<G-vec00047-002-s020><cut.abschneiden><en> A round chocolate cake (28 cm diameter) - the sides cut off and moved to the side as ears, one recipe of Cream Cheese Frosting.
<G-vec00047-002-s020><cut.abschneiden><de> Ein runder Schokoladenkuchen (28cm Durchmesser) - die Seiten abgeschnitten und als Ohren wieder seitlich angesetzt, 1 Rezept Schokoladenbuttercreme und ein paar Löffel baubles.
<G-vec00047-002-s021><cut.abschneiden><en> Note: Please keep your iPhone connecting with PC lest the process would be cut off.
<G-vec00047-002-s021><cut.abschneiden><de> Achtung: Bitte halten Sie die Verbindung zwischen Ihrem iPhone und Ihrem PC, so dass das Prozess nicht abgeschnitten werden wird.
<G-vec00047-002-s022><cut.abschneiden><en> In the autumn, before the onset of the first frost, last year's shoots, where the most powerful flowering took place, should be cut off almost to the ground (leave about 10 cm).
<G-vec00047-002-s022><cut.abschneiden><de> Im Herbst, vor dem Einsetzen des ersten Frosts, sollten die Triebe des letzten Jahres, in denen die stärkste Blüte stattfand, fast bis zum Boden abgeschnitten werden (etwa 10 cm Abstand lassen).
<G-vec00047-002-s023><cut.abschneiden><en> When the police eventually took her to a hospital, a doctor said the that circulation in her legs was cut off.
<G-vec00047-002-s023><cut.abschneiden><de> Als die Polizei sie schließlich ins Krankenhaus brachte, sagte der Arzt, dass die Blutzirkulation in ihren Beinen abgeschnitten sei.
<G-vec00047-002-s024><cut.abschneiden><en> If you have a large bathroom with a window, a French or a full balcony, then its decoration will be flowers: houseplants suitable for growing in a warm and humid climate or cut off, standing in vases.
<G-vec00047-002-s024><cut.abschneiden><de> Wenn Sie ein großes Badezimmer mit einem Fenster, einem französischen oder einem vollen Balkon haben, dann wird die Dekoration Blumen sein: Zimmerpflanzen, die für das Wachstum in einem warmen und feuchten Klima geeignet sind oder abgeschnitten werden und in Vasen stehen.
<G-vec00047-002-s025><cut.abschneiden><en> •“Cut it off and sold it,” said Della.
<G-vec00047-002-s025><cut.abschneiden><de> •"Abgeschnitten und verkauft," sagte Della.
<G-vec00047-002-s026><cut.abschneiden><en> Equipped with 22" in Length; 17" in Width; 18" in Depth product chamber with 40" Long x 7" OD grinding screw with 8" OD self sharpening cut off blades, 7½"ID threaded product discharge port with 8-5/8" diameter plate and has 42" floor clearance.
<G-vec00047-002-s026><cut.abschneiden><de> Ausgestattet mit 22" in der Länge, 17" in der Breite; 18" in Kammer Produkttiefe mit 40" Long x 7" OD Selbstschärf abgeschnitten Klingen, 7½ ‚ID Gewindeproduktabgabeöffnung mit 8-5 / 8‘ Durchmesser plate OD Schraube mit 8" Schleifen und hat 42" Bodenfreiheit.
<G-vec00047-002-s027><cut.abschneiden><en> There is a common network; however, its threads are cut off, and we have to reconnect them.
<G-vec00047-002-s027><cut.abschneiden><de> Es gibt ein gemeinsames Netz, doch dessen Fäden sind abgeschnitten, und wir müssen sie wieder verbinden.
<G-vec00047-002-s028><cut.abschneiden><en> Behind the bull a young boy sewn into a bear skin rode on a horse whose ears and tail were cut off.
<G-vec00047-002-s028><cut.abschneiden><de> Hinter dem Bullen ritt ein Junge genäht in ein Bärenfell auf einem Pferd, dessen Ohren und Schwanz abgeschnitten worden waren.
<G-vec00047-002-s029><cut.abschneiden><en> When the Wall went up in 1961, this triangular piece of land was cut off by the border installations; projecting into West Berlin, it was surrounded by a makeshift fence and left undeveloped.
<G-vec00047-002-s029><cut.abschneiden><de> Beim Bau der Mauer 1961 wurde der Zipfel durch die Sperranlagen abgeschnitten und blieb als nur provisorisch umzäunte, nach West-Berlin hinragende Brachfläche bestehen.
<G-vec00047-002-s030><cut.abschneiden><en> The war and the events of the war have cut completely across the line of development of the consciousness of the workers and given it a different direction to what might have been anticipated.
<G-vec00047-002-s030><cut.abschneiden><de> Der Krieg und die Ereignisse des Krieges haben die Entwicklungslinie des Bewusstseins der ArbeiterInnen völlig abgeschnitten und ihr eine andere Richtung gegeben, als man es vorhersehen konnte.
<G-vec00047-002-s031><cut.abschneiden><en> For the trunk of the Christmas tree, one of the slices has to be cut flat.
<G-vec00047-002-s031><cut.abschneiden><de> Für den Stamm des Tannenbaumes wird eine der Scheiben flach abgeschnitten.
<G-vec00047-002-s032><cut.abschneiden><en> Cronus, continued Sandro, was the son of the Earth Goddess and the God Uranus, and it was Cronus himself who cut off the gonads of his father and when he threw them into the sea from the foam appeared Aphrodite, goddess of love and sexuality. Venus, he continued saying, was the Roman heiress of the Greek Goddess Aphrodite.
<G-vec00047-002-s032><cut.abschneiden><de> Kronos, fuhr Sandro fort, war der Sohn des Gottes Uranus und der Göttin der Erde und als Kronos die Gonaden seines Vaters abgeschnitten hatte und ins Meer warf, erschien Venus, die Göttin der Liebe und der Sexualität, römische Erbin der griechischen Göttin Aphrodite, aus dem Meerschaum.
<G-vec00047-002-s033><cut.abschneiden><en> Also when I did not know your motives as yet – the connections being cut off – as at the time of the Brest-Litovsk peace, I defended you with your own motives.
<G-vec00047-002-s033><cut.abschneiden><de> Auch als ich Ihre Motive noch gar nicht kannte – die Verbindungen waren doch abgeschnitten –, wie beim Frieden von Brest-Litowsk, verteidigte ich Sie mit Ihren Motiven.
<G-vec00047-002-s034><cut.abschneiden><en> And it shall come to pass, as soon as the soles of the feet of the priests who bear the ark of the Lord, the Lord of all the earth, shall rest in the waters of the Jordan, that the waters of the Jordan shall be cut off, the waters that come down from upstream, and they shall stand as a heap.”
<G-vec00047-002-s034><cut.abschneiden><de> 13 Wenn dann die Fußsohlen der Priester, welche die Lade des HERRN, des Herrn der ganzen Erde, tragen, im Wasser des Jordan stillstehen, so wird das Wasser des Jordan, das Wasser, das von oben herabfließt, abgeschnitten werden, und es wird stehen bleiben wie ein Damm.
<G-vec00047-002-s035><cut.abschneiden><en> Many of them are just as cut off from any path toward integration into Canadian society as from the histories of their forebears, which was usually transmitted in the form of oral traditions and died out together with the banned dialects.
<G-vec00047-002-s035><cut.abschneiden><de> Von einer Integrationsmöglichkeit in die kanadische Gesellschaft sind sie oft genauso abgeschnitten wie von der meist mündlich überlieferten Geschichte ihrer Vorfahren, die zusammen mit den verbotenen Dialekten ausstarb.
<G-vec00047-002-s036><cut.abschneiden><en> It may need to bend or be cut off at certain points to look accurate.
<G-vec00047-002-s036><cut.abschneiden><de> An manchen Stellen kann das Muster gebogen oder abgeschnitten sein, damit es akkurater aussieht.
<G-vec00047-002-s037><cut.abschneiden><en> Intellectuals should no longer portray Internet users as secondary amateurs, cut off from a primary and primordial relationship with the world.
<G-vec00047-002-s037><cut.abschneiden><de> Intellektuelle sollten Netznutzer nicht länger als sekundäre Amateure zeichnen, die von einem primären und ursprünglichen Verhältnis zur Welt abgeschnitten sind.
<G-vec00047-002-s038><cut.abschneiden><en> Before scrapping it, make sure to cut off the mains cord so that the appliance cannot be re-used.
<G-vec00047-002-s038><cut.abschneiden><de> Machen Sie das Gerät vor der Verschrottung unbrauchbar, indem Sie das Netzkabel abschneiden.
<G-vec00047-002-s039><cut.abschneiden><en> - Standing upright, these you can simply cut with the Sword (usually leaves behind a Deku Stick).
<G-vec00047-002-s039><cut.abschneiden><de> - Aufrecht stehend (verwelkt), die kann man einfach mit dem Schwert abschneiden (hinterlässt meistens einen Deku-Stab).
<G-vec00047-002-s040><cut.abschneiden><en> He seems to be cold and brutal at first because he is quite serious, does many things on his own, chose brutal methods (e.g. he wanted to cut off his feet to free himself from wax) and talks in an insensitive way.
<G-vec00047-002-s040><cut.abschneiden><de> Auf den ersten Blick wirkt er etwas kalt und brutal, da er eine ziemlich ernste Person ist, vieles im Alleingang macht, brutale Methoden wählt (zB wollte er sich die Beine abschneiden, als er im Wachs drinsteckte) und unsentimentale Sprüche abgibt.
<G-vec00047-002-s041><cut.abschneiden><en> Only the harmonious song of the birds will cut off this silence.
<G-vec00047-002-s041><cut.abschneiden><de> Nur das harmonische Lied der Vögel wird dieses Schweigen abschneiden.
<G-vec00047-002-s042><cut.abschneiden><en> Cut away all protruding parts on the Trix C Track connection points and the fasteners on the first tie.
<G-vec00047-002-s042><cut.abschneiden><de> Abschneiden aller überstehenden Teile an der Trix C-Gleis-Anschlussstelle und der Kleineisen an der ersten Schwelle.
<G-vec00047-002-s043><cut.abschneiden><en> Wrap the leather around your wrist to determine how long to cut your pieces.
<G-vec00047-002-s043><cut.abschneiden><de> Wickle es dafür um dein Handgelenk, um zu bestimmen, wie lange du die Stücke abschneiden musst.
<G-vec00047-002-s044><cut.abschneiden><en> Cut and sew the threads.
<G-vec00047-002-s044><cut.abschneiden><de> Faden abschneiden und Faden vernähen.
<G-vec00047-002-s045><cut.abschneiden><en> Diamond Blades for Cut-Off Saws - Simply a cut above: The diamond blades for cut-off saws Wacker Neuson's diamond blade range is tailor-made for the BTS range of Wacker Neuson cut-off saws.
<G-vec00047-002-s045><cut.abschneiden><de> Einfach perfekt abschneiden: Mit Diamantscheiben für Trennschneider Das Diamantscheiben-Sortiment von Wacker Neuson ist speziell auf die Trennschneider-Modelle der BTS-Reihe von Wacker Neuson zugeschnitten.
<G-vec00047-002-s046><cut.abschneiden><en> Because as long as the EU doesn’t decide to lay barbed wire across Mediterranean beaches, or to turn back refugee boats with armed force, the sea border of the EU to the south cannot be ‘defended’: the EU cannot cut itself off from the Mediterranean – which, it is worth remembering, is in cultural historical terms, as the Mare Nostrum, the quintessential European sea – and from whose trade routes the EU most certainly does not want to cut itself off.
<G-vec00047-002-s046><cut.abschneiden><de> Aber Griechenland oder Italien oder die Länder auf der Balkanroute – ob EU oder nicht – haben keine Wahl: sie werden von Flüchtlingen überrannt, ganz egal, was sie tun, um das zu verhindern – denn solange die EU sich nicht entschließt, Stacheldraht auf Mittelmeerstränden zu verlegen oder Flüchtlingsboote mit Waffengewalt abzuwehren, kann die Wassergrenze der EU nach Süden gar nicht ‚geschützt’ werden: die EU kann sich nicht vom Mittelmeer abschneiden, das übrigens als Mare Nostrum kulturgeschichtlich das europäische Meer schlechthin ist – und von dessen Handelsrouten sich die EU keinesfalls abschneiden will.
<G-vec00047-002-s047><cut.abschneiden><en> This would in effect cut off the northern West Bank from the southern part, apart from a narrow bottleneck near Jericho.
<G-vec00047-002-s047><cut.abschneiden><de> Dies würde dann tatsächlich den nördlichen Teil der Westbank vom südlichen Teil abschneiden, abgesehen von einem engen Flaschenhals bei Jericho.
<G-vec00047-002-s048><cut.abschneiden><en> When diagram A.1 has been completed, cut and fasten the strand.
<G-vec00047-002-s048><cut.abschneiden><de> Wenn A.1 zu Ende gehäkelt wurde, den Faden abschneiden und vernähen.
<G-vec00047-002-s049><cut.abschneiden><en> To propagate roses using this method, you need to select a healthy rose plant and cut off a stem.
<G-vec00047-002-s049><cut.abschneiden><de> Um Rosen mit dieser Methode zu vermehren, musst du eine gesunde Rosenpflanze aussuchen und einen Stängel abschneiden.
<G-vec00047-002-s050><cut.abschneiden><en> For how to select the auto feed & cut mode, see "Setting of the DIP switches" (on page 11).
<G-vec00047-002-s050><cut.abschneiden><de> Lesen Sie den Abschnitt “Einstellung der DIP-Schalter” (auf Seite 10) hinsichtlich der Auswahl des Modus zum automatischen Einzug und Abschneiden.
<G-vec00047-002-s051><cut.abschneiden><en> Peel the lower third of the asparagus and cut the ends.
<G-vec00047-002-s051><cut.abschneiden><de> Das untere Drittel des Spargels schälen und die Enden abschneiden.
<G-vec00047-002-s052><cut.abschneiden><en> The prickly leaves can be cut slightly.
<G-vec00047-002-s052><cut.abschneiden><de> Die stachligen Blätter kann man etwas abschneiden.
<G-vec00047-002-s053><cut.abschneiden><en> First make a cut in the underside before you cut off a length from above.
<G-vec00047-002-s053><cut.abschneiden><de> Machen Sie zuerst einen Schnitt an der Unterseite, bevor Sie eine Länge von oben abschneiden.
<G-vec00047-002-s054><cut.abschneiden><en> In this case, you do not need to cut the stems.
<G-vec00047-002-s054><cut.abschneiden><de> In diesem Fall müssen Sie die Stiele nicht abschneiden.
<G-vec00047-002-s055><cut.abschneiden><en> Make a tassel for each end of the string as follows: Cut 12 threads of Cotton Viscose and 8 threads Vivaldi measuring 20 cm each.
<G-vec00047-002-s055><cut.abschneiden><de> An den Enden je 1 Quaste einziehen: 12 Fäden Cotton Viscose und 8 Fäden Vivaldi à 20 cm abschneiden.
<G-vec00047-002-s056><cut.abschneiden><en> He gives us directly the step by which we can cut off all unnecessary actions.
<G-vec00047-002-s056><cut.abschneiden><de> Er gibt uns direkt den Schritt, durch den wir alle unnötigen Handlungen abschneiden können.
<G-vec00047-002-s418><cut.abschneiden><en> Cut the cards out and put one in your wallet for the upcoming week.
<G-vec00047-002-s418><cut.abschneiden><de> Schneide die Tabellen aus und verstaue eine dieser Karten in deiner Brieftasche.
<G-vec00047-002-s419><cut.abschneiden><en> As you go along, cut each string 2 inches longer.
<G-vec00047-002-s419><cut.abschneiden><de> Schneide, wenn du weitermachst, jede Schnur 5 cm länger ab.
<G-vec00047-002-s420><cut.abschneiden><en> Place the foam on the linen and cut a fitting rectangle.
<G-vec00047-002-s420><cut.abschneiden><de> Platziere den Schaumstoff auf dem Leinen und schneide ein passendes Rechteck zum Einschlagen zu.
<G-vec00047-002-s421><cut.abschneiden><en> Meanwhile, wash and cut your chosen fruits.
<G-vec00047-002-s421><cut.abschneiden><de> Wasche und schneide inzwischen dein gewähltes Obst.
<G-vec00047-002-s422><cut.abschneiden><en> Cut the puff pastry into squares.
<G-vec00047-002-s422><cut.abschneiden><de> Schneide den Blätterteig in Quadrate.
<G-vec00047-002-s423><cut.abschneiden><en> Then, cut a leaf shape.
<G-vec00047-002-s423><cut.abschneiden><de> Schneide einen langen 1cm Klebebandstreifen.
<G-vec00047-002-s424><cut.abschneiden><en> Cut a log of pre-made cookie dough into even rounds.
<G-vec00047-002-s424><cut.abschneiden><de> Schneide den vorgefertigten Plätzchenteig in gleichmäßige, runde Stücke.
<G-vec00047-002-s425><cut.abschneiden><en> 9 Then He said: Take for me a three-year-old cow, a three-year-old goat, a three-year-old male sheep, a dove, and a young pigeon. 10 And he took all these animals, cut them up in halves for sacrifice, laying each half opposite the other half, but he did not cut the birds in half.
<G-vec00047-002-s425><cut.abschneiden><de> 1Mo 15,9 [9/10] Da sagte der Herr: »Bring mir eine dreijährige Kuh, eine dreijährige Ziege, einen dreijährigen Schafbock, eine Turteltaube und eine junge Taube; schneide sie mittendurch, und lege die Hälften einander gegenüber.
<G-vec00047-002-s426><cut.abschneiden><en> Let cool completely, then cut in half and fill with pastry cream and fruit preserve or jam.
<G-vec00047-002-s426><cut.abschneiden><de> Lass sie komplett auskühlen, schneide sie dann halb durch und fülle sie mit Hilfe eines Spritzbeutels mit der Crème und Marmelade.
<G-vec00047-002-s427><cut.abschneiden><en> Cut your pieces out.
<G-vec00047-002-s427><cut.abschneiden><de> Schneide deinen Stoff.
<G-vec00047-002-s428><cut.abschneiden><en> 2 Poke the knife through the belly of the fish and cut towards the tail.
<G-vec00047-002-s428><cut.abschneiden><de> Schneide den Schwanz ab, wenn du es nicht bereits getan hast und schneide den Kopf mit dem großen Messer ab.
<G-vec00047-002-s429><cut.abschneiden><en> Cut the exposed hair, with your scissors perpendicular to the comb or your fingers.
<G-vec00047-002-s429><cut.abschneiden><de> Schneide die freiliegenden Haare mit deiner Schere senkrecht zu deinem Kamm oder einen Fingern ab.
<G-vec00047-002-s430><cut.abschneiden><en> Do not cut off the thread or yarn; you will continue weaving with it.
<G-vec00047-002-s430><cut.abschneiden><de> Schneide den Faden nicht ab; du fährst damit fort, ihn zu weben.
<G-vec00047-002-s431><cut.abschneiden><en> If you bought a long fillet of salmon, carefully use a sharp knife to cut the salmon into individual fillets.
<G-vec00047-002-s431><cut.abschneiden><de> Falls du ein langes Lachsfilet gekauft hast, schneide es mit einem scharfen Messer vorsichtig in einzelne Filets.
<G-vec00047-002-s432><cut.abschneiden><en> Cut an end in the proper place with a scissors before laying it down.
<G-vec00047-002-s432><cut.abschneiden><de> Schneide eine Ecke an der richtigen Stelle mit einer Schere ein, bevor du es anbringst.
<G-vec00047-002-s433><cut.abschneiden><en> Cut off (a part of) the stem.
<G-vec00047-002-s433><cut.abschneiden><de> Schneide auch ein Stück vom Stiel ab.
<G-vec00047-002-s434><cut.abschneiden><en> To take a spore print, take a mushroom, cut the cap away from the stem using a sharp knife, and place it gills down on a piece of paper.
<G-vec00047-002-s434><cut.abschneiden><de> Um einen Sporenabdruck zu nehmen, nimm einen Pilz, schneide die Kappe mit einem scharfen Messer vom Stiel und leg sie mit den Lamellen nach unten auf ein Stück Papier.
<G-vec00047-002-s435><cut.abschneiden><en> 1 Cut cotton cloth into small squares.
<G-vec00047-002-s435><cut.abschneiden><de> 1 Schneide Baumwollstoff in kleine Quadrate.
<G-vec00047-002-s436><cut.abschneiden><en> Cut along the edge of the fold with sharp scissors.
<G-vec00047-002-s436><cut.abschneiden><de> Schneide mit einer scharfen Schere an der Kante der Faltung entlang.
<G-vec00047-002-s456><cut.abschneiden><en> The machine uses a sawing unit to cut diagonally through the rectangular unprocessed part. It moves the two halves apart so that the four- or five-piece spindles can trim and profile the steps from all sides.
<G-vec00047-002-s456><cut.abschneiden><de> Mit einem Sägeaggregat schneidet die Maschine diagonal durch den rechteckigen Rohling und fährt beide Hälften soweit auseinander, dass die Vier- oder Fünfachsspindel die Stufen ringsherum fräsen und profilieren kann.
<G-vec00047-002-s457><cut.abschneiden><en> Peter Breuer, on the other hand, now prepares the schedule for the next several days, and works with his “music guy” to cut the songs down to a suitable length.
<G-vec00047-002-s457><cut.abschneiden><de> Peter Breuer hingegen bereitet noch den Plan für die nächsten Tage vor und schneidet mit seinem Ton-Verantwortlichen die Songs auf die richtige Länge zu.
<G-vec00047-002-s458><cut.abschneiden><en> Zum Vergrößern bitte anklicken / click to enlarge Take your scissors and your first piece of cardstock and cut your score lines exactly like the purple lines in the sketch show from the upper line to the middle mark you just made.
<G-vec00047-002-s458><cut.abschneiden><de> Wiederholt das mit dem anderen Stück noch einmal genau Jetzt nehmt ihr euch eine Schere und schneidet beim ersten Stück Cardstock von oben bis zum markierten Mittelpunkt die Falzlinie ein, genau wie die lilafarbenen Linien in der Skizze es zeigen.
<G-vec00047-002-s459><cut.abschneiden><en> Then cut a window in one of the large sections.
<G-vec00047-002-s459><cut.abschneiden><de> Schneidet dann in einen der Deckel ein Fenster.
<G-vec00047-002-s460><cut.abschneiden><en> If you cut the upper portion of your body, as soon as you see inside, it is all obnoxious horrible things.
<G-vec00047-002-s460><cut.abschneiden><de> Wenn ihr in den oberen Teil des Körpers schneidet, sobald ihr hineinseht, ist alles darin abstoßend und grässlich.
<G-vec00047-002-s461><cut.abschneiden><en> The dual blade system of this electric shaver lifts hairs to cut comfortably below skin level. Spring-released pop-up trimmer
<G-vec00047-002-s461><cut.abschneiden><de> Das 2-Klingen-System dieses Elektrorasierers hebt die Haare an und schneidet sie direkt für eine sanfte Rasur an der Hautoberfläche ab.
<G-vec00047-002-s462><cut.abschneiden><en> When laser head cut metals, there will produce some hot energy in laser head and laser device.
<G-vec00047-002-s462><cut.abschneiden><de> Wenn der Laserkopf Metalle schneidet, wird im Laserkopf und im Lasergerät etwas heiße Energie erzeugt.
<G-vec00047-002-s463><cut.abschneiden><en> The doctor under local anesthesia will cut a bridle or special scissors, or a laser.
<G-vec00047-002-s463><cut.abschneiden><de> Der Arzt unter örtlicher Betäubung schneidet einen Zaum oder eine spezielle Schere oder einen Laser.
<G-vec00047-002-s464><cut.abschneiden><en> File folder cards can be found many made with the punchboard....but not everyone has it...so I made one without First you cut your cardstock to the given size and lay it along the short side to the ScorPal and score at 10,5 cm...
<G-vec00047-002-s464><cut.abschneiden><de> Immer wieder findet man File Folder Karten, die mit dem Punchboard gefertigt werden...allerdings hat ja nicht jeder so ein tolles Board zur Hand...und so habe ich eine File Folder Card ohne Punchboard für euch Als erstes schneidet ihr euren Cardstock auf die passende Größe zu...anschließend legt ihr euch den Cardstock mit der langen Seite oben am ScorPal an und falzt ihn bei 10,5cm...
<G-vec00047-002-s465><cut.abschneiden><en> Cut a slit in the lime wedge and rub it around the rim of a tall beer glass.
<G-vec00047-002-s465><cut.abschneiden><de> Schneidet den Limettenkeil ein und streicht damit den Glasrand eines Bierglases ein.
<G-vec00047-002-s466><cut.abschneiden><en> And so you cut yourself off.
<G-vec00047-002-s466><cut.abschneiden><de> Und auf diese Weise schneidet ihr euch selbst ab.
<G-vec00047-002-s467><cut.abschneiden><en> When nearly dry cut the bread into small squares and season it well with powdered sage, salt and pepper.
<G-vec00047-002-s467><cut.abschneiden><de> Man schneidet die Stücke 2 cm dick, salzt und pfeffert sie und wendet sie leicht in Mehl um.
<G-vec00047-002-s468><cut.abschneiden><en> Take a cardboard disk with the diameter of the telescope's optic, cut two (or three) holes in it and place it in front of the telescope.
<G-vec00047-002-s468><cut.abschneiden><de> Man nimmt im einfachsten Fall eine Pappscheibe, die die Teleskopöffnung abdeckt, schneidet zwei runde Löcher hinein und plaziert die Scheibe vor der Teleskopöffnung.
<G-vec00047-002-s469><cut.abschneiden><en> Roughly cut out 2 pieces from an old jeans, which are about the same size and a little larger than the stamped image.
<G-vec00047-002-s469><cut.abschneiden><de> Grob schneidet man nun 2 ungefähr gleich große Stücke aus einer alten Jeanshose, die ein bisschen größer sind als das gestempelte Motiv.
<G-vec00047-002-s470><cut.abschneiden><en> Cut away the things of the world, accept the leadership of Jesus Christ, or you’ll perish as sure as the world.
<G-vec00047-002-s470><cut.abschneiden><de> Schneidet die Dinge der Welt ab und nehmt die Führerschaft Jesu Christi an, sonst werdet ihr so sicher wie die Welt umkommen.
<G-vec00047-002-s471><cut.abschneiden><en> He uses it to cut samples from every possible source, and later these serve as the main themes for pieces.
<G-vec00047-002-s471><cut.abschneiden><de> Damit schneidet er aus allen möglichen Quellen Samples raus, die dann als Grundmotive für Stücke dienen.
<G-vec00047-002-s472><cut.abschneiden><en> Interreg DiveSMART Baltic Method The Cutting Extinguisher technique consists of a mixture of water and cutting agent (abrasive) being ejected through a special nozzle at high pressure (>250 bar) to cut through all known building and construction materials.
<G-vec00047-002-s472><cut.abschneiden><de> Bei der Schneidlöschtechnik wird dem Löschwasser über eine spezielle Düse unter hohem Druck (>250 bar) ein Schneidmittel (Abrasivmittel) zugesetzt, mit dessen Hilfe der Wasserstrahl durch alle bekannten Baumaterialien schneidet.
<G-vec00047-002-s473><cut.abschneiden><en> You can use a good pair of kitchen scissors to cut through practically anything: paper, cardboard, corrugated cardboard, string, fabric, aluminium foil or cling film and other packaging used in the kitchen, as well as of course herbs, rosemary sprigs, rhubarb, flowers etc.
<G-vec00047-002-s473><cut.abschneiden><de> Mit einer guten Küchenschere schneidet Ihr so gut wie alles: Papier, Pappe, Wellpappe, Bindfäden, Stoff, Alu- oder Plastikfolie und andere Verpackungen rund ums Kochen, aber natürlich auch Kräuter, Rosmarinzweige, Rhabarber, Blumen usw..
<G-vec00047-002-s474><cut.abschneiden><en> Now cut the inside of the brim.
<G-vec00047-002-s474><cut.abschneiden><de> Jetzt schneidet ihr den inneren Kreis der Krempe aus.
<G-vec00118-002-s342><cut.kürzen><en> Cut the hose to length with a sharp knife.
<G-vec00118-002-s342><cut.kürzen><de> Kürzen Sie den Schlauch mit einem scharfen Messer auf die erforderliche Länge.
<G-vec00118-002-s343><cut.kürzen><en> I would cut that's why they something in the front part.
<G-vec00118-002-s343><cut.kürzen><de> Ich werde sie deshalb im vorderen Teil etwas kürzen.
<G-vec00118-002-s344><cut.kürzen><en> You know and I know that weight loss happens when we cut our calories, eat healthy food, drink more water and exercise daily.
<G-vec00118-002-s344><cut.kürzen><de> Sie wissen, und ich weiß, dass die Gewichtsabnahme passiert, wenn wir kürzen auf unserer Kalorien, gesunde Lebensmittel zu essen, trinken Sie viel Wasser und tägliche Bewegung.
<G-vec00118-002-s345><cut.kürzen><en> Step 9 - cut the wires as shown.
<G-vec00118-002-s345><cut.kürzen><de> Schritt 9 - Die Anschlussdrähte wie gezeigt kürzen.
<G-vec00118-002-s346><cut.kürzen><en> Pompeo criticized Iran and China for instability in the world and said the United States urged the World Bank and the International Monetary Fund to cut funding to countries.
<G-vec00118-002-s346><cut.kürzen><de> Pompeo kritisierte den Iran und China wegen der Instabilität in der Welt und sagte, die Vereinigten Staaten hätten die Weltbank und den Internationalen Währungsfonds aufgefordert, die Mittel für Länder zu kürzen.
<G-vec00118-002-s347><cut.kürzen><en> By switching to Qualtrics, Alcoa cut the costs of its CX program by 50% and was able to develop customer-focused action plans months faster.
<G-vec00118-002-s347><cut.kürzen><de> Durch die Einführung von Qualtrics konnte Alcoa die Kosten des firmeneigenen Kundenzufriedenheitsprogramms um 50% kürzen und schneller einen entsprechenden Maßnahmenplan entwickeln.
<G-vec00118-002-s348><cut.kürzen><en> We’ve just had this Tea Party revolt that sent a whole lot of new kind of politicians to Washington, and all they can think about is cutting budgets, but only very, very few of them will talk about cutting the most obvious thing to cut of all – which is the defense budget.
<G-vec00118-002-s348><cut.kürzen><de> Wir hatten gerade diese Tea Party-Revolte, die eine ganze Menge von Politikern einer neuen Art nach Washington geschickt hat, und alles, worüber sie nachdenken können, sind Budgetkürzungen, aber nur sehr, sehr wenige von ihnen werden über das Kürzen der selbstverständlichsten Sache von allen, die zu kürzen sind, sprechen – das ist der Verteidigungshaushalt.
<G-vec00118-002-s349><cut.kürzen><en> Just the flower stem to your own desired length cut and fix it in a vase, ready.
<G-vec00118-002-s349><cut.kürzen><de> Einfach den Blütenstiel auf Ihre eigene Wunschlänge kürzen und in der Vase fixieren, fertig.
<G-vec00118-002-s350><cut.kürzen><en> The material flexibility gives designers broad illumination possibilities and can be cut to any customer requirements.
<G-vec00118-002-s350><cut.kürzen><de> Die Material Flexibilität ermöglicht Designern umfassende Beleuchtungsmöglichkeiten und lässt sich auf Kundenwunsch beliebig kürzen.
<G-vec00118-002-s351><cut.kürzen><en> I'm not exactly small at 1.76 m but I would have to cut good 5 cm.
<G-vec00118-002-s351><cut.kürzen><de> Ich bin mit 1,76 m nicht gerade klein aber ich hätte gut 5 cm kürzen können.
<G-vec00118-002-s352><cut.kürzen><en> As a result of the failed sales tax measure, Roberts was forced to break her campaign promise not to cut spending.
<G-vec00118-002-s352><cut.kürzen><de> Daraufhin musste sie Ausgaben kürzen und damit eines ihrer Wahlversprechen brechen.
<G-vec00118-002-s353><cut.kürzen><en> U.S. and Japan cut back on rice aid to Indonesia.
<G-vec00118-002-s353><cut.kürzen><de> Die "USA" und Japan kürzen Indonesien die Reishilfe.
<G-vec00118-002-s354><cut.kürzen><en> The only changes made to the stock bike was to cut the bars down to 770 mm and swap out the more summer friendly Maxxis High Roller II and Ardent SS tyres for some mud plugging Maxxis Shorty 2.3’s running 22/24 psi, the best all-around winter tyres on the market.
<G-vec00118-002-s354><cut.kürzen><de> Die einzigen Änderungen, die zum Serienbike gemacht wurden, waren das Kürzen des Lenkers auf 770 mm und der Tausch der eher sommerlichen Reifenkombination aus MAXXIS HighRoller II/Ardent SS mit den matschfräsenden MAXXIS Shorty 2,3, die bei 1,5–1,6 bar die besten Allround-Winterreifen auf dem Markt sind.
<G-vec00118-002-s355><cut.kürzen><en> Recently, it came to light that the British government wants to cut financial support to individuals whose asylum requests have been rejected.
<G-vec00118-002-s355><cut.kürzen><de> Zuletzt war bekannt geworden, dass die britische Regierung Menschen, deren Asylanträge abgelehnt wurden, die finanzielle Unterstützung kürzen will.
<G-vec00118-002-s356><cut.kürzen><en> Make sure that the slideshows you create are 15 seconds long or less, otherwise Instagram will cut the slideshow short.
<G-vec00118-002-s356><cut.kürzen><de> Stelle sicher, dass die Slideshows, die du erstellst, 15 Sekunden oder weniger dauern; anderenfalls wird Instagram die Slideshow kürzen.
<G-vec00118-002-s357><cut.kürzen><en> While the European Parliament responded to negative developments in Turkey by voting to cut pre-accession funding, there was disagreement among member states on the way forward.
<G-vec00118-002-s357><cut.kürzen><de> Während das Europäische Parlament auf die negativen Entwicklungen in der Türkei reagierte, indem es sich dafür aussprach, die der Türkei im Zuge der Beitrittsvorbereitungen bewilligten Mittel zu kürzen, waren sich die Mitgliedstaaten über die richtige Strategie uneins.
<G-vec00118-002-s358><cut.kürzen><en> If you have long nails, you may wish to cut back the nail under which the splinter is embedded before attempting to remove it.
<G-vec00118-002-s358><cut.kürzen><de> Wenn du sehr lange Nägel hast, solltest du den Nagel kürzen, unter dem der Splitter steckt, ehe du versuchst, ihn zu entfernen.
<G-vec00118-002-s359><cut.kürzen><en> Three sharp, rotating blades cut the grass.
<G-vec00118-002-s359><cut.kürzen><de> Drei scharfe, rotierende Klingen kürzen das Gras.
<G-vec00118-002-s360><cut.kürzen><en> Easily performing quick and straight cuts Sawing close to edges thanks to the new design, e.g. to cleanly cut off branches close to the trunk
<G-vec00118-002-s360><cut.kürzen><de> So kannst Du beispielsweise Kanthölzer unkompliziert kürzen oder Büsche und Äste schnell zurecht schneiden – und das dank des Geräte-Designs besonders nah am Stamm.
