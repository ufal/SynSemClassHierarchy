<G-vec00739-002-s000><acquiesce.dulden><en> (2) To the extent clarification of the biological father is necessary in proceedings concerning rights of contact or information pursuant to section 1686a of the Civil Code, each person must acquiesce to examinations, particularly the drawing of blood samples, unless the person cannot reasonably be expected to undergo the examination.
<G-vec00739-002-s000><acquiesce.dulden><de> (2) Soweit es in einem Verfahren, das das Umgangs- oder Auskunftsrecht nach § 1686a des Bürgerlichen Gesetzbuchs betrifft, zur Klärung der leiblichen Vaterschaft erforderlich ist, hat jede Person Untersuchungen, insbesondere die Entnahme von Blutproben, zu dulden, es sei denn, dass ihr die Untersuchung nicht zugemutet werden kann.
<G-vec00739-002-s004><acquiesce.hinnehmen><en> The best strategy to protect intellectual property rights is actually of little value if their holders acquiesce to the infringements of their rights on social media or in other areas without taking action.
<G-vec00739-002-s004><acquiesce.hinnehmen><de> Denn die beste Strategie zur Absicherung von Schutzrechten ist tatsächlich wenig wert, wenn deren Inhaber die Verletzungen ihrer Rechte in sozialen Medien oder anderen Bereichen tatenlos hinnehmen.
<G-vec00739-002-s002><acquiesce.zustimmen><en> “Okay,” I acquiesce.
<G-vec00739-002-s002><acquiesce.zustimmen><de> „Okay“, stimme ich zu.
<G-vec00739-002-s003><acquiesce.zustimmen><en> It really is amazing,” I acquiesce with her.
<G-vec00739-002-s003><acquiesce.zustimmen><de> Es ist wirklich erstaunlich“, stimme ich ihr zu.
