<G-vec00307-002-s019><encounter.antreffen><en> Additionally, we may encounter development issues that could delay or prevent us from developing products based on the SMD technology.
<G-vec00307-002-s019><encounter.antreffen><de> Zusätzlich können wir Entwicklung Ausgaben antreffen, die uns an sich entwickelnden Produkten verzögern oder verhindern konnten, die auf der SMD Technologie basierten.
<G-vec00307-002-s020><encounter.antreffen><en> It is an example for all who, even today, dedicate themselves passionately to the missionary cause of the Gospel, but encounter misunderstandings and opposition in the Church community.
<G-vec00307-002-s020><encounter.antreffen><de> Er ist für alle ein Beispiel, die heute mit Hingabe das Evangelium verkünden, und dabei Widerstand in der kirchlichen Gemeinschaft antreffen.
<G-vec00307-002-s021><encounter.antreffen><en> This bike tour encompasses the heart of Athens and includes some of the most exciting vistas that you will encounter on foot or on wheels.
<G-vec00307-002-s021><encounter.antreffen><de> Diese Tour umfasst das Herz von Athen einschließlich einiger der interessantesten Aussichten, die Sie per Fahrrad oder zu Fuß antreffen können.
<G-vec00307-002-s022><encounter.antreffen><en> Discover the lively atmosphere of the Jordaan, an area where you'll encounter many art galleries and nice cafés.
<G-vec00307-002-s022><encounter.antreffen><de> Entdecken Sie die lebendige Atmosphäre des Viertels Jordaan, in dem Sie viele Kunstgalerien und Lokale antreffen.
<G-vec00307-002-s023><encounter.antreffen><en> Your patience is tested when you encounter a new kind of priest, who changes his protections every few seconds, avoiding the elemental assaults you throw in his direction.
<G-vec00307-002-s023><encounter.antreffen><de> Ihre Geduld wird auf die Probe gestellt, wenn Sie eine neue Art Priester antreffen, der seine Schutzzauber alle paar Sekunden ändert, um Ihren Elementarattacken auszuweichen.
<G-vec00307-002-s024><encounter.antreffen><en> As model proteins encounter one another, they might stick together at any angle at which they collide (mediated by non-specific interactions), or bind in the correct orientation needed to form a crystal (mediated by directional interactions).
<G-vec00307-002-s024><encounter.antreffen><de> Da vorbildliche Proteine sich antreffen, hafteten möglicherweise sie zusammen in jedem möglichem Winkel, in dem sie (vermittelt durch unspezifische Interaktionen) zusammenstoßen, oder binden in der korrekten Orientierung, die benötigt wird, um einen Kristall zu bilden (vermittelt durch Richtungsinteraktionen).
<G-vec00307-002-s025><encounter.antreffen><en> Take a deep breath and go on an adventure beneath the ocean's waves at Children's Aquarium at Fair Park, where you will encounter all kinds of sea life.
<G-vec00307-002-s025><encounter.antreffen><de> Halten Sie die Luft an und gehen Sie auf eine Unterwasserreise in Children's Aquarium at Fair Park, wo Sie viele eigenartige Meeresbewohner antreffen werden.
<G-vec00307-002-s026><encounter.antreffen><en> At the centre of the circle of twelve in this White Lodge, we would encounter a thirteenth being.
<G-vec00307-002-s026><encounter.antreffen><de> In der Mitte dieses Kreises der Zwölf, in der Weißen Loge, würden wir ein dreizehntes Wesen antreffen.
<G-vec00307-002-s027><encounter.antreffen><en> It will also safeguard your PC from other infections you may encounter while surfing online.
<G-vec00307-002-s027><encounter.antreffen><de> Es wird auch Ihr PC vor anderen Infektionen schützen, die Sie beim Surfen online antreffen können.
<G-vec00307-002-s028><encounter.antreffen><en> It is still possible to encounter eagles, chamois, roe deer, groundhogs, red frogs and admire the beautiful blossoming of gentians, buttercups, arnica and wild orchids.
<G-vec00307-002-s028><encounter.antreffen><de> Hier kann man noch Adler, Gämsen, Rehe, Murmeltiere, Frösche antreffen sowie herrliche blühende Enziane, Ranunkel, Arnika und wilde Orchideen bewundern.
<G-vec00307-002-s029><encounter.antreffen><en> For example, you can encounter woodpeckers, buzzards, falcons, vipers, grass snakes and deer.
<G-vec00307-002-s029><encounter.antreffen><de> Sie können hier zum Beispiel Spechte, Bussarde, Falken, Otter, Ringelnattern und Rehe antreffen.
<G-vec00307-002-s030><encounter.antreffen><en> However, if you encounter any minor problems like headache, fatigue or muscle pain it is advisable to increase your water intake.
<G-vec00307-002-s030><encounter.antreffen><de> Jedoch wenn Sie irgendwelche kleinen Probleme wie Kopfschmerzen antreffen, Ermüdung- oder Muskelschmerz ist es ratsam, Ihren Wassereinlaß zu erhöhen.
<G-vec00307-002-s031><encounter.antreffen><en> With such nuanced movement patterns, learn which common faulty movement patterns and misunderstandings you will encounter when teaching exercises from the Slings in Motion Repertoire and how to proactively address them
<G-vec00307-002-s031><encounter.antreffen><de> Video: Fehlerhafte Bewegungsausführungen Lerne die häufigsten fehlerhaften Bewegungsmuster und Missverständnisse, die du bei der Ausführung der Slings in Motion Übungen antreffen wirst und wie du diese proaktiv angehen kannst.
<G-vec00307-002-s032><encounter.antreffen><en> With the rental of apartments Our branches and field experts guarantee a worry-free stay in your rented apartment or villa - no expensive advertising, content honest and accurate information, the holiday homes and villas are displayed clearly and carefully, just as you encounter them on site be.
<G-vec00307-002-s032><encounter.antreffen><de> Unsere Filialen und Sachverständigen vor Ort garantieren einen sorgenfreien Aufenthalt in Ihrer gemieteten Ferienwohnung oder Villa – keine teure Reklame, ehrlicher Inhalt und richtige Informationen, wobei die Ferienhäuser und Villen deutlich und gewissenhaft gezeigt werden, genau wie Sie sie vor Ort antreffen werden.
<G-vec00307-002-s033><encounter.antreffen><en> Owing to the large number of vehicles in our fleet, our work teams can be moved flexibly in our country and abroad alike, you can encounter with our service cars at every point of the country.
<G-vec00307-002-s033><encounter.antreffen><de> Dank unseres großen Kraftwagenparks sind unsere Arbeitsgruppen sowohl im Inland, als auch im Ausland flexibel einsetzbar, unsere Servicewagen können Sie überall in Ungarn antreffen.
<G-vec00307-002-s034><encounter.antreffen><en> Apart from the more obvious forms of plastic debris littering our oceans, which we also encounter on pretty much every tour, there are the more dangerous and detrimental microscopic pieces of plastic, collectively known as microplastic.
<G-vec00307-002-s034><encounter.antreffen><de> Abgesehen von den offensichtlichen Formen von Plastikmüll, die wir so gut wie auf jeder Tour auf dem Meer antreffen, gibt es natürlich auch die gefährlicheren und schädlicheren mikroskopischen Plastikteile, die gemeinsam als Mikroplastik bezeichnet werden.
<G-vec00307-002-s035><encounter.antreffen><en> We stand in the way of imports of dirty cars and expose corporate misbehaviour wherever we encounter it.
<G-vec00307-002-s035><encounter.antreffen><de> Wir stellen uns gegen den Import von schmutzigen Autos und entlarven unternehmerisches Fehlverhalten wann und wo immer wir es antreffen.
<G-vec00307-002-s112><encounter.aufeinandertreffen><en> As a sighting always requires an encounter between the animal and a human observer, the researchers also wanted to investigate the human side of the interaction.
<G-vec00307-002-s112><encounter.aufeinandertreffen><de> Da für Beobachtungen immer das Aufeinandertreffen von Wildtier und Mensch notwendig ist, wollten die Forschenden auch die menschliche Seite der Beobachtungen unter die Lupe nehmen.
<G-vec00307-002-s113><encounter.aufeinandertreffen><en> Ali had trained longer and harder for this fight than for their first encounter.
<G-vec00307-002-s113><encounter.aufeinandertreffen><de> Ali hatte länger und härter für diesen Kampf trainiert als für das erste Aufeinandertreffen.
<G-vec00307-002-s114><encounter.aufeinandertreffen><en> The work's finest stroke of audacity is the imaginary encounter at the end of the first act between Attila and Pope Leo, the character referred to in the dramatis personae as "Leone, an ancient Roman".
<G-vec00307-002-s114><encounter.aufeinandertreffen><de> Die größte Kühnheit des Stücks ist im imaginären Aufeinandertreffen Attilas mit Papst Leo, im Personenverzeichnis „Leone, ein alter Römer“, am Ende des ersten Aktes erreicht.
<G-vec00307-002-s115><encounter.aufeinandertreffen><en> UK: Not So Brief Encounter - Nuclear Trains at Carnforth ---------------------------------------------------------------------- Trains pulling containers of highly-radioactive nuclear fuel rods ("Nuclear Trains") regularly go through Carnforth.
<G-vec00307-002-s115><encounter.aufeinandertreffen><de> Bitte unterschreibt die Petition und verbreitet sie: Kein ganz so kurzes Aufeinandertreffen - Atomzüge in Carnforth ---------------------------------------------------------------------- Regelmäßig transportieren Züge Container mit hochradioaktiven Brennstäben ("Atomzüge") durch Carnforth.
<G-vec00307-002-s116><encounter.aufeinandertreffen><en> There then follows a classic encounter between Kirsty and her young protégé Megan, fighting each other competitively for the first time.
<G-vec00307-002-s116><encounter.aufeinandertreffen><de> Anschließend ist ein fast schon klassisches Aufeinandertreffen zwischen Kirsty und ihrem jungen Protegé Megan zu sehen, die hier zum ersten Mal in einem Wettbewerb gegeneinander antreten.
<G-vec00307-002-s117><encounter.aufeinandertreffen><en> The subsequent retaking of the prison, however, is an open wound and “the bloodiest one-day encounter between Americans since the Civil War,” according to the findings of the investigating New York State Special Commission.
<G-vec00307-002-s117><encounter.aufeinandertreffen><de> Die anschließende Rückeroberung des Gefängnisses wiederum ist eine offene Wunde und wurde von der mit der Aufarbeitung des Falls betrauten Sonderkommission des Staats New York als „das blutigste eintägige Aufeinandertreffen zwischen Amerikanern seit dem Bürgerkrieg“ eingestuft.
<G-vec00307-002-s118><encounter.aufeinandertreffen><en> A family symbol graciously representing the encounter between the outer and the inner world, where all the differences disappear.
<G-vec00307-002-s118><encounter.aufeinandertreffen><de> Ein bekanntes Symbol, das mit Anmut das Aufeinandertreffen zwischen äußerer und innerer Welt verkörpert, wobei sich Unterschiede auflösen.
<G-vec00307-002-s119><encounter.aufeinandertreffen><en> Usually only chasing for nurture, Cobras can be easily provoked or irritated and might consider any encounter a threat, fearlessly attacking everything regardless of its size.
<G-vec00307-002-s119><encounter.aufeinandertreffen><de> Obwohl sie normalerweise nur zur Ernährung jagen, können Cobras sehr einfach provoziert oder irritiert werden und könnten jedes Aufeinandertreffen als eine Bedrohung betrachten, furchtlos alles andgreifend, egal welche Größe es hat.
<G-vec00307-002-s120><encounter.aufeinandertreffen><en> He could then see with the naked eye the swirls created by this encounter.
<G-vec00307-002-s120><encounter.aufeinandertreffen><de> So ist es möglich, mit nacktem Auge die Wirbel und Strömungen zu sehen, die durch dieses Aufeinandertreffen entstehen.
<G-vec00307-002-s121><encounter.aufeinandertreffen><en> More than 200 objects show the culture of the Incas, their predecessors and the encounter with the European culture, a culture with a completely different value system.
<G-vec00307-002-s121><encounter.aufeinandertreffen><de> Über 200 Objekte zeigen in der Ausstellung die Kultur der Inka, ihre Vorgänger-Kulturen und das Aufeinandertreffen mit der europäischen Kultur, einer Kultur mit einem ganz anderen Wertesystem.
<G-vec00307-002-s421><encounter.aufstoßen><en> Sometimes, it is just a question of realization, but every now and then we encounter a practice we do not want to experience.
<G-vec00307-002-s421><encounter.aufstoßen><de> Manchmal ist es zwar nur eine Frage der Umsetzung, aber hin und wieder stoßen wir doch auf Praktiken, die wir nicht erleben wollen.
<G-vec00307-002-s422><encounter.aufstoßen><en> If you have made the same mistake, then you can also encounter the iOS 14/13.7 WhatsApp notification problem.
<G-vec00307-002-s422><encounter.aufstoßen><de> Wenn Sie diesen Fehler gemacht haben, stoßen Sie vielleicht ebenfalls auf das iOS 12 WhatsApp Benachrichtigungsproblem.
<G-vec00307-002-s423><encounter.aufstoßen><en> Around four in ten Europeans encounter problems when travelling within cities (38%).
<G-vec00307-002-s423><encounter.aufstoßen><de> Ungefähr vier von zehn Europäern (38 %) stoßen auf Probleme, wenn sie sich innerhalb der Städte fortbewegen.
<G-vec00307-002-s424><encounter.aufstoßen><en> The user(s) you are writing for might encounter problems during the life cycle of the product.
<G-vec00307-002-s424><encounter.aufstoßen><de> Die Benutzer, für die Sie schreiben, stoßen bei der Verwendung des Produkts vermutlich auf Probleme.
<G-vec00307-002-s425><encounter.aufstoßen><en> When looking for a Rolex Mickey Mouse, you're likely to first encounter older Datejust models, such as the ref. 1601.
<G-vec00307-002-s425><encounter.aufstoßen><de> Wenn Sie auf der Suche nach einer Rolex Mickey Mouse sind, stoßen Sie vermutlich als erstes auf ältere Datejust-Modelle, zum Beispiel mit der Referenznummer 1601.
<G-vec00307-002-s426><encounter.aufstoßen><en> If we neglect people today, we encounter non-cooperation tomorrow.
<G-vec00307-002-s426><encounter.aufstoßen><de> Vernachlässigen wir heute Menschen, stoßen wir morgen auf fehlende Zusammenarbeit.
<G-vec00307-002-s427><encounter.aufstoßen><en> The orchestra’s annual international concert tours encounter extremely receptive audiences.
<G-vec00307-002-s427><encounter.aufstoßen><de> Die jährlichen internationalen Konzerttourneen des Orchesters stoßen auf außerordentliche Resonanz.
<G-vec00307-002-s428><encounter.aufstoßen><en> At the entrance we encounter the “Eames Lounge Chair” in a black special edition.
<G-vec00307-002-s428><encounter.aufstoßen><de> Gleich am Eingang stoßen wir auf der „Eames Lounge Chair“, in schwarzer Sonderedition.
<G-vec00307-002-s429><encounter.aufstoßen><en> Foreign tourists rarely encounter problems.
<G-vec00307-002-s429><encounter.aufstoßen><de> Ausländische Touristen stoßen selten auf Probleme.
<G-vec00307-002-s430><encounter.aufstoßen><en> Somehow they are caught between two worlds: disabled people who are being attracted to the same sex encounter lots of bias and ostracism.
<G-vec00307-002-s430><encounter.aufstoßen><de> Irgendwie sitzen sie überall zwischen den Stühlen: behinderte Menschen, die das gleiche Geschlecht lieben, stoßen auf Vorurteile und Ausgrenzung von allen Seiten.
<G-vec00307-002-s431><encounter.aufstoßen><en> These and many other changes encounter a culture in the company that can promote or hinder digital transformation.
<G-vec00307-002-s431><encounter.aufstoßen><de> Diese und noch viele weitere Veränderungen stoßen im Unternehmen auf eine Kultur, die bei der digitalen Transformation förderlich oder hinderlich wirken kann.
<G-vec00307-002-s432><encounter.aufstoßen><en> Thanks to them, we encounter practice-relevant questions that can become the subject of a research project.
<G-vec00307-002-s432><encounter.aufstoßen><de> Dank ihnen stoßen wir einerseits auf praxisrelevante Fragestellungen, die Gegenstand eines Forschungsprojektes werden können.
<G-vec00307-002-s433><encounter.aufstoßen><en> Of course, sometimes we encounter difficulties.
<G-vec00307-002-s433><encounter.aufstoßen><de> Natürlich, manchmal stoßen wir auf Schwierigkeiten.
<G-vec00307-002-s434><encounter.aufstoßen><en> In everyday life, educational professionals often encounter difficulties in promoting their pupils and apprentices and therefore call for a consultation of specialized services.
<G-vec00307-002-s434><encounter.aufstoßen><de> Im pädagogischen Alltag stoßen die Fachleute häufig auf Schwierigkeiten bei der Förderung ihrer Schüler und Auszubildenden und fordern deshalb die Beratung von Fachdiensten ein.
<G-vec00307-002-s435><encounter.aufstoßen><en> Climbing up the slope you encounter a track (44min) (900 m) and continue along it upwards.
<G-vec00307-002-s435><encounter.aufstoßen><de> Weiter oben auf dem Hang stoßen Sie auf einen Wanderweg (44Min) (900 m) der steil empor steigt.
<G-vec00307-002-s436><encounter.aufstoßen><en> When professional products actually infiltrate the skin, they encounter the “security guards” of the outer skin there.
<G-vec00307-002-s436><encounter.aufstoßen><de> Wenn tatsächlich Berufsstoffe in die Haut eindringen, stoßen sie dort auf die Polizeiwache der Oberhaut.
<G-vec00307-002-s437><encounter.aufstoßen><en> We encounter the traces of the reality experienced by the Roma almost exclusively through depictions by outsiders, and must use these to imagine those parts considered impossible to represent.
<G-vec00307-002-s437><encounter.aufstoßen><de> Wir stoßen fast ausschließlich auf die Spuren des durch Andere repräsentierten Teils der Lebenswirklichkeit der Romvölker und müssen aus ihnen den für nicht repräsentierbar befundenen Teil erschließen.
<G-vec00307-002-s438><encounter.aufstoßen><en> In the course of this, we also encounter new and previously unknown things – after all, this is our fundamental research goal.
<G-vec00307-002-s438><encounter.aufstoßen><de> Dabei stoßen wir auch auf Neues und bislang Unbekanntes – das ist ja unser grundsätzliches Forschungsziel.
<G-vec00307-002-s439><encounter.aufstoßen><en> However, children with disabilities often encounter difficulties in the game if the marketed toys are not adapted to their needs, or when playing group games.
<G-vec00307-002-s439><encounter.aufstoßen><de> Leider stoßen sie jedoch häufig auf ihre Grenzen, da beworbene Spielzeuge entweder nicht auf ihre Bedürfnisse angepasst sind oder sie beim Gruppenspielen angemessen gefördert werden.
<G-vec00307-002-s093><encounter.auftreffen><en> The NIH sponsors most documents on this server; however, you may encounter documents sponsored along with private companies and other organizations.
<G-vec00307-002-s093><encounter.auftreffen><de> Die NIH sponsern die meisten Dokumente auf diesem Server; aber es kann sein, dass Sie auf Dokumente treffen, die zusammen mit privaten Unternehmen und anderen Organisationen gefördert wurden.
<G-vec00307-002-s094><encounter.auftreffen><en> Parents are unlikely to once encounter a bad appetite.
<G-vec00307-002-s094><encounter.auftreffen><de> Es ist unwahrscheinlich, dass Eltern einmal auf einen schlechten Appetit treffen.
<G-vec00307-002-s095><encounter.auftreffen><en> In addition, most of the standards that we encounter in the field of safety spectacles are those for military safety spectacles.
<G-vec00307-002-s095><encounter.auftreffen><de> Zudem sind die meisten Normen, auf die wir im Bereich der Schutzbrillen treffen, solche für militärische Schutzbrillen.
<G-vec00307-002-s096><encounter.auftreffen><en> “As you explore the furthest reaches of space and encounter various factions, all vying for power, the character you decide to become will determine how this player-driven story unfolds.
<G-vec00307-002-s096><encounter.auftreffen><de> Während die Spieler die äußersten Gebiete des Weltraums erkunden und auf verschiedene, machthungrige Fraktionen treffen, entscheiden sie mit dem von ihnen entwickelten Charakter über den Verlauf der spielergetriebenen Handlung.
<G-vec00307-002-s097><encounter.auftreffen><en> If you encounter those with the right mental powers, they can teach you to some extent.
<G-vec00307-002-s097><encounter.auftreffen><de> Wenn Sie auf jene treffen, welche die richtige geistige Kraft besitzen, so können diese Sie zu einem gewissen Maß belehren.
<G-vec00307-002-s098><encounter.auftreffen><en> The following section details which third party cookies you might encounter through this site.
<G-vec00307-002-s098><encounter.auftreffen><de> Im folgenden Abschnitt erfahren Sie, auf welche Cookies von Drittanbietern Sie durch diese Website treffen können.
<G-vec00307-002-s099><encounter.auftreffen><en> As they encounter the resistance of corporations and the capitalist state to their legitimate demands, working people will see ever more clearly the need for the revolutionary transformation of society.
<G-vec00307-002-s099><encounter.auftreffen><de> Wenn sie auf den Widerstand der Konzerne und des kapitalistischen Staates treffen, werden die Werktätigen die Notwendigkeit einer revolutionären Umgestaltung der Gesellschaft immer klarer erkennen.
<G-vec00307-002-s100><encounter.auftreffen><en> Funen is also called the garden of Denmark, and if you explore the surrounding area, you will inevitably encounter some of the island’s many farm shops and roadside stalls.
<G-vec00307-002-s100><encounter.auftreffen><de> Fünen wird auch „Garten von Dänemark“ genannt – wenn Sie einen Ausflug in die Umgebung unternehmen, werden Sie auf einige der zahlreichen Bauernhofläden und Stände am Straßenrand treffen.
<G-vec00307-002-s101><encounter.auftreffen><en> The game is highly addictive and as you progress you will encounter challenges that will test your abilities to the fullest.
<G-vec00307-002-s101><encounter.auftreffen><de> Das Spiel ist extrem süchtig machend und während Sie im Spiel fortschreiten, werden Sie auf Herausforderungen treffen, die Ihre Fähigkeiten in vollen Zügen testen.
<G-vec00307-002-s102><encounter.auftreffen><en> As government troops encounter stiff resistance from IS fighters, thousands of civilians are fleeing the fighting.
<G-vec00307-002-s102><encounter.auftreffen><de> Während die Truppen auf heftigen Widerstand von IS-Kämpfern treffen, fliehen Tausende von Zivilisten aus der umkämpften Stadt.
<G-vec00307-002-s103><encounter.auftreffen><en> Certain T lymphocytes remember such a specific immune response and when they encounter the same foreign substance at a later time, they trigger a rapid and effective immune response.
<G-vec00307-002-s103><encounter.auftreffen><de> Bestimmte T-Lymphozyten merken sich eine solche spezifische Abwehrreaktion und lösen, wenn sie zu einem späteren Zeitpunkt wieder auf denselben Fremdstoff treffen, eine schnelle und sehr wirkungsvolle Immunreaktion aus.
<G-vec00307-002-s104><encounter.auftreffen><en> With this, the rover will tested with as many different types of soil conditions as it could possibly encounter on Mars.
<G-vec00307-002-s104><encounter.auftreffen><de> Damit sollen möglichst viele Bodenbedingungen untersucht werden, auf die das Marsgefährt Exomars auf dem Mars treffen könnte.
<G-vec00307-002-s105><encounter.auftreffen><en> . PLAY In HD Plot: Goku and Vegeta encounter Broly, a Saiyan warrior unlike any fighter they've faced before.
<G-vec00307-002-s105><encounter.auftreffen><de> Dieser trägt den Titel Dragon Ball Super: Broly und handelt von Goku und Vegeta, die auf Broly treffen, eine Saiyajin-Kriegerin, wie sie sie noch nie gesehen hat.
<G-vec00307-002-s106><encounter.auftreffen><en> Researchers blame the familiarity: when people encounter something unexpected, such as strange colors or weights, our brains turn it into an unpleasant experience.
<G-vec00307-002-s106><encounter.auftreffen><de> Forscher beschuldigen die Vertrautheit: Wenn Menschen auf etwas Unerwartetes treffen, wie fremde Farben oder Gewichte, wird unser Gehirn zu einer unangenehmen Erfahrung.
<G-vec00307-002-s107><encounter.auftreffen><en> However, it is very likely that you will—just like on the bridge of a ship—encounter the decision-makers between monitors and phones.
<G-vec00307-002-s107><encounter.auftreffen><de> Sehr wahrscheinlich ist allerdings, dass Sie – wie auf der Brücke eines Schiffes – zwischen Monitoren und Telefonen auf die Entscheider treffen.
<G-vec00307-002-s108><encounter.auftreffen><en> You will encounter beautiful churches with ancient origins.
<G-vec00307-002-s108><encounter.auftreffen><de> Du wirst auf wundervolle Kirchen sehr antiken Ursprungs treffen.
<G-vec00307-002-s109><encounter.auftreffen><en> Yes, you can encounter many situations where you lose your data.
<G-vec00307-002-s109><encounter.auftreffen><de> Ja, Sie können auf viele Situationen treffen, in denen Sie Ihre Daten verlieren.
<G-vec00307-002-s110><encounter.auftreffen><en> Their exports would become less competitive and they would encounter heavy competition from the rump euro zone area in their home markets.
<G-vec00307-002-s110><encounter.auftreffen><de> Ihre Exporte würden an Wettbewerbsfähigkeit verlieren, und sie würden auf ihren Heimatmärkten auf starke Konkurrenz aus der Rumpf-Euro-Zone treffen.
<G-vec00307-002-s111><encounter.auftreffen><en> As a general rule, you don’t encounter floats in limped pots.
<G-vec00307-002-s111><encounter.auftreffen><de> Es gilt also die grundsätzliche Regel, dass du in limped Pots nicht auf Floats treffen wirst.
<G-vec00307-002-s122><encounter.auftreten><en> You may encounter an error when adding user groups.
<G-vec00307-002-s122><encounter.auftreten><de> Beim Hinzufügen von Benutzergruppen kann ein Fehler auftreten.
<G-vec00307-002-s123><encounter.auftreten><en> We are always happy to help and you can count on us doing our best to solve all problems you might encounter.
<G-vec00307-002-s123><encounter.auftreten><de> Wir stehen Ihnen jederzeit gerne zur Hilfe bereit und Sie können sich darauf verlassen, dass wir alles tun, um sämtliche Probleme zu lösen, die eventuell bei Ihnen auftreten.
<G-vec00307-002-s124><encounter.auftreten><en> The foam cushions provide optimal comfort as well as isolating any background noise you may encounter.
<G-vec00307-002-s124><encounter.auftreten><de> Die Schaumstoff-Kissen bieten optimalen Komfort sowie störende Hintergrundgeräusche, die auftreten können, zu isolieren.
<G-vec00307-002-s125><encounter.auftreten><en> However, sometimes you can encounter problems with screen sharing.
<G-vec00307-002-s125><encounter.auftreten><de> In einigen Fällen jedoch können Sie Probleme mit Bildschirmfreigabe auftreten.
<G-vec00307-002-s126><encounter.auftreten><en> Especially the party frame can cause some lags (retrieving, merging, sorting, filtering and displaying the buffs and debuffs of 5 party members is a lot of work to do - so this would be the first one to disable if you encounter any problems).
<G-vec00307-002-s126><encounter.auftreten><de> Speziell der Party Frame kann unter Umständen Lags/Ruckler verursachen (abrufen, zusammenführen, sortieren, filtern und anzeigen der Buffs und Debuffs von 5 Partymembers ist eine Menge Arbeit - Also wäre dieser Frame der erste den man deaktivieren sollte, falls Probleme auftreten).
<G-vec00307-002-s127><encounter.auftreten><en> As with every system update, we strongly recommend that you perform a backup before and after the upgrade, in case you encounter issues and need to roll back.
<G-vec00307-002-s127><encounter.auftreten><de> Wie bei jeder Systemaktualisierung empfehlen wir dringend, dass Sie vor und nach der Aktualisierung eine Sicherung für den Fall vornehmen, dass Probleme auftreten und Sie zu einem früheren Zustand zurückkehren müssen.
<G-vec00307-002-s128><encounter.auftreten><en> Use this manual if you encounter any problems, or have any questions.
<G-vec00307-002-s128><encounter.auftreten><de> Verwenden Sie dieses Handbuch, wenn Probleme oder Fragen auftreten.
<G-vec00307-002-s129><encounter.auftreten><en> Those programs are created to remove .Lurk file virus and similarly harmful infections, thus you shouldn’t encounter issues.
<G-vec00307-002-s129><encounter.auftreten><de> Diese Programme werden erstellt, um zu entfernen .Lurk file virus und ähnlich schädliche Infektionen, so sollten Sie keine Probleme auftreten.
<G-vec00307-002-s130><encounter.auftreten><en> If you encounter issues with the ERA Agent during installation, check the status log on the client machine to make sure ERA Agent is working properly.
<G-vec00307-002-s130><encounter.auftreten><de> Falls bei der Installation Probleme mit dem ERA Agenten auftreten, überprüfen Sie das Status-Log auf dem Client, um sicherzustellen, dass der ERA Agent korrekt ausgeführt wird.
<G-vec00307-002-s131><encounter.auftreten><en> If you do not want to encounter any virtual scams, you should stay away from adverts until you terminate Walasearch.com.
<G-vec00307-002-s131><encounter.auftreten><de> Wenn Sie keine virtuellen Betrügereien auftreten möchten, sollten Sie weg von Werbung bleiben, bis Sie Walasearch.com kündigen.
<G-vec00307-002-s132><encounter.auftreten><en> You may encounter this error if you’ve configured Tableau Server for trusted authentication.
<G-vec00307-002-s132><encounter.auftreten><de> Dieser Fehler kann auftreten, wenn Tableau Server für die vertrauenswürdige Authentifizierung konfiguriert worden ist.
<G-vec00307-002-s133><encounter.auftreten><en> When you create an event using the event Chrome extension, you may encounter the following error message: This selector is longer than 280 characters.
<G-vec00307-002-s133><encounter.auftreten><de> Wenn Sie ein Event mit der Chrome-Erweiterung für Events erstellen, kann die folgende Fehlermeldung auftreten: Dieser Selektor ist länger als 280 Zeichen.
<G-vec00307-002-s134><encounter.auftreten><en> If you encounter cyber criminals, chances are that you will get infected with malware.
<G-vec00307-002-s134><encounter.auftreten><de> Wenn Cyber-kriminelle auftreten, stehen die Chancen, dass Sie mit Malware infiziert werden.
<G-vec00307-002-s135><encounter.auftreten><en> If you still encounter issues, please contact support.
<G-vec00307-002-s135><encounter.auftreten><de> Wenn weiterhin Probleme auftreten, Support kontaktieren.
<G-vec00307-002-s136><encounter.auftreten><en> These are some of the situations that you may encounter with your data files.
<G-vec00307-002-s136><encounter.auftreten><de> “Dies sind einige der Situationen, die bei Ihren Datendateien auftreten können.
<G-vec00307-002-s137><encounter.auftreten><en> • Organisations that encounter data breaches will be subject to severe financial penalties as a result of their failure to protect the data.
<G-vec00307-002-s137><encounter.auftreten><de> • Organisationen, bei denen Datenschutzverletzungen auftreten, unterliegen strengen finanziellen Sanktionen als Folge ihres Versagens, die Daten zu schützen.
<G-vec00307-002-s138><encounter.auftreten><en> 81 This chapter lists some problems you might encounter when using your phone.
<G-vec00307-002-s138><encounter.auftreten><de> 86 Fehlerbehebung In diesem Kapitel werden Probleme aufgelistet, die bei der Verwendung des T elef ons auftreten können.
<G-vec00307-002-s139><encounter.auftreten><en> When you encounter this error message while opening / accessing Outlook PST file, then it is highly recommended to repair Outlook PST file.
<G-vec00307-002-s139><encounter.auftreten><de> Wenn Sie diese Fehlermeldung auftreten beim Öffnen / Zugriff auf Outlook-PST-Datei, dann ist es sehr empfehlenswert, um Outlook-PST-Datei zu reparieren.
<G-vec00307-002-s140><encounter.auftreten><en> Test Product All Wed'ze products are tested under the real conditions of use for which they were designed: in the snow, in the cold, and all the conditions you might encounter when skiing.
<G-vec00307-002-s140><encounter.auftreten><de> Qualitätstest Alle Wed'ze-Produkte werden unter realistischen Bedingungen getestet - bei Schnee, Kälte und allen anderen Bedingungen, die beim Skifahren auftreten können.
<G-vec00307-002-s155><encounter.begegnen><en> Encounter majestic creatures and discover long lost secrets as you venture on a quest into the depths of the ocean.
<G-vec00307-002-s155><encounter.begegnen><de> Begegne majestätischen Kreaturen und entdecke verloren geglaubte Geheimnisse, während du dich auf eine Reise in die Tiefen des Ozeans wagst.
<G-vec00307-002-s156><encounter.begegnen><en> Even when I thereby have to encounter this absolute silence...
<G-vec00307-002-s156><encounter.begegnen><de> Auch wenn ich dabei der absoluten Stille begegne...
<G-vec00307-002-s157><encounter.begegnen><en> Discover thriving wildlife, encounter monstrous beasts, and let curiosity guide you through an inevitable voyage of extinction.
<G-vec00307-002-s157><encounter.begegnen><de> Entdecke die prächtige Tierwelt, begegne monströsen Bestien und lass dich von deiner Neugierde auf eine Reise des unvermeidlichen Aussterbens führen.
<G-vec00307-002-s158><encounter.begegnen><en> During my walk through Fort Cochin I encounter Ashok.
<G-vec00307-002-s158><encounter.begegnen><de> Ich begegne Ashok bei meinem Spaziergang durch Fort Cochin.
<G-vec00307-002-s159><encounter.begegnen><en> I have tried to study the Fa more and look within whenever I encounter a conflict.
<G-vec00307-002-s159><encounter.begegnen><de> Ich habe versucht, das Fa mehr zu lernen und immer nach innen zu schauen, wenn ich einem Konflikt begegne.
<G-vec00307-002-s160><encounter.begegnen><en> Hope is knowing how to see — in the face of the poor whom we encounter every day — the same Lord who will come again one day to judge us according to the criteria we read in chapter 25 of the Gospel of Matthew: “As you did it to one of the least of my brethren, you did it to me” (v. 40).
<G-vec00307-002-s160><encounter.begegnen><de> Hoffnung bedeutet, im Gesicht der Armen, denen ich heute begegne, denselben Herrn sehen zu können, der eines Tages kommen wird, um uns nach dem Protokoll aus Matthäus 25 zu richten: »Was ihr für einen meiner geringsten Brüder getan habt, das habt ihr mir getan« (V. 40).
<G-vec00307-002-s161><encounter.begegnen><en> I now encounter this issue very often.
<G-vec00307-002-s161><encounter.begegnen><de> Ich begegne diesem Problem sehr oft.
<G-vec00307-002-s162><encounter.begegnen><en> -Conversations to Remember: Encounter personable items, philosophic undead, and rat hiveminds while walking the planes with the strangest collection of allies ever seen in an RPG.
<G-vec00307-002-s162><encounter.begegnen><de> Gespräche, um sich zu erinnern: Begegne sympathischen Objekten, philosophischen Untoten und im Gruppenkollektiv agierenden Ratten, während du die Ebenen mit der wohl eigenwilligsten Gruppe von Gefährten, die du je in einem Rollenspiel gesehen hast, durchstreifst.
<G-vec00307-002-s163><encounter.begegnen><en> In this context, the disciple grows in an ardent desire that all may encounter Christ and achieve the true freedom of the children of God.
<G-vec00307-002-s163><encounter.begegnen><de> In diesem Zusammenhang wächst im Jünger das brennende Verlangen, daß jeder Mensch Christus begegne und die wahre Freiheit der Kinder Gottes erlange.
<G-vec00307-002-s164><encounter.begegnen><en> I often encounter the same problem in the Bible, with the book of the Psalms where the goodness and bounty of God are praised in a wonderful way, but where psalmists also prayed God to crush the head of their enemy’s children against rocks.
<G-vec00307-002-s164><encounter.begegnen><de> Ich begegne oft dem selben Problem in der Bibel, mit dem Buch der Psalmen, wo die Güte und Liebe auf eine wundervolle Weise gepriesen werden, aber wo Psalmisten auch Gott darum gebeten haben, die Köpfe der Kinder seines Feinds zu zerschmettern.
<G-vec00307-002-s165><encounter.begegnen><en> Explore lush rainforests in Ranomafana National Park and encounter local flora and fauna – including 33 species of lemurs, one of which is the famous golden bamboo lemur.
<G-vec00307-002-s165><encounter.begegnen><de> Erkunde die dichten Regenwälder im Ranomafana Nationalpark und begegne der lokalen Flora und Fauna – darunter 33 Arten von Lemuren, wie auch dem berühmten goldenen Bambus-Lemur.
<G-vec00307-002-s317><encounter.erleben><en> The site got its name for being the largest reef in the area with the largest possibility to encounter unique under water panorama.
<G-vec00307-002-s317><encounter.erleben><de> Der Ort erhielt seinen Namen als das größte Riff in dieser Gegend mit der höchsten Wahrscheinlichkeit, einzigartige Unterwasser-Panoramas zu erleben.
<G-vec00307-002-s318><encounter.erleben><en> A dangerous one that many travelers encounter is Route 622 in Westfjords, a northwestern region of Iceland.
<G-vec00307-002-s318><encounter.erleben><de> Eine gefährliche Reise, die viele Reisende erleben, ist die Route 622 in Westfjords, einer nordwestlichen Region Islands.
<G-vec00307-002-s319><encounter.erleben><en> You encounter these young professionals in all sorts of everyday situations and learn sentences and expressions that you can put into practice right away.
<G-vec00307-002-s319><encounter.erleben><de> Sie erleben die Hauptpersonen in alltäglichen Situationen und lernen Sätze, die Sie sofort in der Praxis anwenden können.
<G-vec00307-002-s320><encounter.erleben><en> You can test their premium subscription and encounter unlimited downloads at the superior speed.
<G-vec00307-002-s320><encounter.erleben><de> Sie können ihr Premium-Abonnement testen und unbegrenzte Downloads mit der überlegenen Geschwindigkeit erleben.
<G-vec00307-002-s321><encounter.erleben><en> They encounter many strange things on there visit.
<G-vec00307-002-s321><encounter.erleben><de> Sie erleben dabei viele merkwürdige Dinge.
<G-vec00307-002-s322><encounter.erleben><en> In addition, they will encounter situations in which they will practice to function as cross-disciplinary „interpreters“ when working with colleagues from other fields, by drawing on their (methodological) knowledge from the field of Political Science and thus making a positive impact on joint project work.
<G-vec00307-002-s322><encounter.erleben><de> Zudem erleben sie Situationen, in denen sie üben, als „Mittler“ ihres eigenen Faches zu fungieren, indem sie bei der Zusammenarbeit mit fachfremden Kollegen auf ihre erworbenen (Methoden-)Kenntnisse aus dem Bereich der Politikwissenschaft zurückgreifen und damit gewinnbringend auf die Erarbeitung gemeinsamer Projekte einwirken.
<G-vec00307-002-s323><encounter.erleben><en> The series represent the four elements - Air, Water, Earth and Fire - and the 78 maps are read as archetypal aspects of the human experience that we may encounter in ourselves or the world.
<G-vec00307-002-s323><encounter.erleben><de> Die Serie repräsentiert die vier Elemente - Luft, Wasser, Erde und Feuer - und die 78 Karten werden als archetypische Aspekte der menschlichen Erfahrung gelesen, die wir in uns selbst oder in der Welt erleben können.
<G-vec00307-002-s324><encounter.erleben><en> Hikers, cyclists and outdoor enthusiasts will encounter fascinating routes in the nearby Black Forest, Vosges or the Swiss Alps.
<G-vec00307-002-s324><encounter.erleben><de> Wander-, Bike-, und Naturfreunde erleben faszinierende Strecken im Markgräfler Land, im nahe gelegenen Schwarzwald, den Vogesen oder in den Schweizer Alpen.
<G-vec00307-002-s325><encounter.erleben><en> View Photos Encounter luxury in our 5-star hotel in Bangkok, Thailand
<G-vec00307-002-s325><encounter.erleben><de> Erleben Sie Luxus pur in unserem 5-Sterne-Hotel in Bangkok, Thailand.
<G-vec00307-002-s326><encounter.erleben><en> In a traditional relationship you will sometimes face surprises or encounter misunderstandings.
<G-vec00307-002-s326><encounter.erleben><de> In einer traditionellen Beziehung werden Sie manchmal Überraschungen oder Missverständnisse erleben.
<G-vec00307-002-s327><encounter.erleben><en> We can all encounter bad times, or make mistakes, especially if we don’t have the expertise and experience .
<G-vec00307-002-s327><encounter.erleben><de> Wir alle können schlechte Zeiten erleben oder Fehler machen, besonders wenn wir nicht über das Fachwissen und die Erfahrung verfügen.
<G-vec00307-002-s328><encounter.erleben><en> Moving from the yogas of India and Asia to the western mystical traditions, we encounter a fascinating bit of history.
<G-vec00307-002-s328><encounter.erleben><de> Wenn wir uns von den Indischen und Asiatischen Yogis zur westlich-mystischen Tradition bewegen, erleben wir ein faszinierendes Stück Geschichte.
<G-vec00307-002-s329><encounter.erleben><en> making it the perfect place to combine activity with opulent indulgence. For those who would like to explore and encounter the country in a unique way, we can recommend Origen Extraordinary Escapes.
<G-vec00307-002-s329><encounter.erleben><de> Wer das Land auf ganz spezielle Weise erkunden und erleben möchte, dem empfehlen wir „Origen Extraordinary Escapes“: Dieses herausragende Unternehmen spezialisiert sich auf massgeschneiderte Reisen und Abendteuer-Touren für anspruchsvolle Touristen.
<G-vec00307-002-s330><encounter.erleben><en> Visitors regularly encounter new products and technologies here.
<G-vec00307-002-s330><encounter.erleben><de> Hier erleben Besucher regelmäßig neue Produkte und Technologien.
<G-vec00307-002-s331><encounter.erleben><en> Unwind and encounter the finest side of London with welcome additions as standard, including fast, complimentary BT Wi-fi, 32-inch LCD TV and Bose Ipod docking stations.
<G-vec00307-002-s331><encounter.erleben><de> Entspannen Sie sich und erleben Sie London von seiner schönsten Seite mit Standard-Ausstattungsmerkmalen wie schnellem kostenlosem BT-WLAN, 32-Zoll LCD-TV, Bose-iPod-Docking-Station und Schalldämmung für perfekte Nachtruhe.
<G-vec00307-002-s332><encounter.erleben><en> However, you can also have a close encounter with various species of ape there.
<G-vec00307-002-s332><encounter.erleben><de> Aber auch verschiedene Affenarten können Sie hier hautnah erleben.
<G-vec00307-002-s333><encounter.erleben><en> If you're sensitive to the small annoyances and verbal barbs we all encounter on a daily basis, you will end up devoting time and energy to things that, ultimately, don't matter.
<G-vec00307-002-s333><encounter.erleben><de> Wenn du empfindlich auf kleine Ärgernisse oder verbale Angriffe reagierst, die wir alle erleben, dann verschwendest du Zeit und Energie auf Dinge, die es nicht wert sind.
<G-vec00307-002-s334><encounter.erleben><en> As you embark on your maiden voyage upon Sharky’s pirate vessel, you’ll encounter unforeseen adventure and action that can result in some fairly lucrative payouts for your efforts.
<G-vec00307-002-s334><encounter.erleben><de> Sobald Sie sich auf die Jungfernfahrt auf Sharky's Piratenschiff aufmachen, erleben Sie unvorhersehbare Abenteuer und Action, die sich in einigen lukrativen Auszahlungen widerspiegeln.
<G-vec00307-002-s335><encounter.erleben><en> We want to ensure that when you visit any part of TeamViewer’s website, your journey will be user-friendly and particularly that you do not encounter technical problems and malfunctions.
<G-vec00307-002-s335><encounter.erleben><de> Wir möchten sicherstellen, dass Sie auf allen Bereichen unserer TeamViewer-Website nutzerfreundlich unterwegs sind, insbesondere, dass Sie keine technischen Störungen oder Funktionsfehler erleben.
<G-vec00307-002-s336><encounter.finden><en> It is a good idea to become familiar with these terms, or at least, refer back to this list if you encounter an unfamiliar word in the later sections.
<G-vec00307-002-s336><encounter.finden><de> Es ist eine gute Idee, sich mit diesem Vokabular vertraut zu machen oder zumindest auf diese Liste zurückzugreifen, wenn sie in einem späteren Abschnitt einen unbekannten Fachausdruck finden.
<G-vec00307-002-s337><encounter.finden><en> That is why, in addition to the newest medical technology, you will encounter extra care, warmth and the human touch.
<G-vec00307-002-s337><encounter.finden><de> Deshalb finden Sie bei uns neben der neuesten Medizin-Technik besonders Zuwendung, Wärme und menschliche Geborgenheit.
<G-vec00307-002-s338><encounter.finden><en> Wherever you may come from, whether from Austria or from any other part of the globe, at FACC you will encounter fascinating challenges and tasks in a strongly growing organization and a pleasant work environment as a member of a globally acting team.
<G-vec00307-002-s338><encounter.finden><de> Wo Sie auch herkommen, ob aus Österreich oder aus der ganzen Welt, bei der FACC finden Sie faszinierende Herausforderungen, spannende Tätigkeiten in einem stark wachsenden Unternehmen und ein angenehmes Betriebsklima in einem global agierenden Team.
<G-vec00307-002-s339><encounter.finden><en> Model aircraft flying Model aircraft pilots encounter perfect conditions up on the high plateau for letting their little treasures rise high up into the air.
<G-vec00307-002-s339><encounter.finden><de> Modellfliegen Modellflieger finden am Hochplateau beste Bedingungen vor, um ihre kleinen Lieblinge in die Lüfte steigen zu lassen.
<G-vec00307-002-s340><encounter.finden><en> One of the main inconveniences that many users will encounter when it comes to creating their own portals is the need to deal with code.
<G-vec00307-002-s340><encounter.finden><de> Eines der Hauptprobleme, die viele Nutzer bei der Erstellung von seinen eigenen Portalen finden, sind die Codezeilen.
<G-vec00307-002-s341><encounter.finden><en> It is our mission to announce and encounter Jesus in the style of Nazareth, contemplative and missionary.
<G-vec00307-002-s341><encounter.finden><de> Das ist unsere Mission: Jesus finden und verkünden- im Stile Nazareths, als Kontemplative und Missionare.
<G-vec00307-002-s342><encounter.finden><en> If you encounter any problem, you can contact their support team via live chat or a manned email that typically replies within a 24-hour period.
<G-vec00307-002-s342><encounter.finden><de> Wenn Sie keine Lösung finden, können Sie den Casino-Support über eine Live-Chat-Funktion, eine bemannte E-Mail oder ein Telefon kontaktieren.
<G-vec00307-002-s343><encounter.finden><en> If you encounter on our website links or references that violate legal provisions or lead to contents that violate legal provisions, please report this to us so that we can delete the link or reference to the corresponding site.
<G-vec00307-002-s343><encounter.finden><de> Sollten Sie Hinweise oder Links auf unseren Internetseiten finden, die gegen Rechtsvorschriften verstoßen oder auf Inhalte verweisen, die gegen Rechtsvorschriften verstoßen, so bitten wir Sie um einen entsprechenden Hinweis, um diese Hinweise oder Links zu entfernen.
<G-vec00307-002-s344><encounter.finden><en> The email marketing industry has a solid reputation as a whole, so many of the ESPs you encounter will have excellent reputations with ISPs and anti-spam organizations.
<G-vec00307-002-s344><encounter.finden><de> Die E-Mail Marketing Industrie hat weltweit als Ganzes eine solide Reputation, deshalb werden viele E-Mail-Marketing Dienstleistungsanbieter die Sie finden einen hervorragenden Ruf mit Ihren Internet Service Anbietern und Anti-Spam Organisationen haben.
<G-vec00307-002-s345><encounter.finden><en> At this point we encounter a landscape with a vegetation that is the result of man made changes in the ravine.
<G-vec00307-002-s345><encounter.finden><de> An dieser Stelle finden wir eine Landschaft mit einer Vegetation vor, die deutlich von Menschenhand gezeichnet ist.
<G-vec00307-002-s346><encounter.finden><en> In this task, the Authorities and the various forces of Mexican society will always encounter the solidarity of the Catholic Church.
<G-vec00307-002-s346><encounter.finden><de> Bei dieser Aufgabe werden die Behörden und die verschiedenen Kräfte der mexikanischen Gesellschaft seitens der katholischen Kirche stets loyale Mitarbeit und Solidarität finden.
<G-vec00307-002-s347><encounter.finden><en> A trick to easily encounter the demon is to set the "move" selection of the game to 1; then every battle will be with the final boss.
<G-vec00307-002-s347><encounter.finden><de> Ein Trick, den Dämonenkönig relativ problemlos zu finden, besteht darin, die "Bewegungs-Auswahl" des Spiels auf 1 zu setzen; so erscheint dieser Boss bei jedem Kampf.
<G-vec00307-002-s348><encounter.finden><en> Usually you encounter a line that failed, with the ultimate result being a Setup error.
<G-vec00307-002-s348><encounter.finden><de> In der Regel finden Sie eine Zeile, bei der ein Fehler aufgetreten ist, und die in einem Setup-Fehler resultiert.
<G-vec00307-002-s349><encounter.finden><en> The trade fair’s main target groups are industry, research and science. With backgrounds in the chemical industry, food, environmental technology and the life sciences, trade visitors to Hannover will encounter the latest products and solutions for lab technology, automation and infrastructure and for analytics and specialist services.
<G-vec00307-002-s349><encounter.finden><de> Die großen Zielgruppen der Messe sind Industrie, Forschung und Wissenschaft: Von der Chemieindustrie über Ernährung und Umwelttechnik bis zu den Life Sciences finden die Fachbesucher in Hannover die neuesten Produkte und Lösungen in den Bereichen Labortechnik, Laborautomation, Laborinfrastruktur, Analytik und fachlichen Dienstleistungen.
<G-vec00307-002-s350><encounter.finden><en> Inexperienced users in particular will encounter difficulties in operating terminals with a large array of different input and output components.
<G-vec00307-002-s350><encounter.finden><de> Gerade bei Terminals mit einer Vielzahl von Ein- und Ausgabekomponenten ist es für unerfahrene Nutzer schwierig, sich im Bedienablauf zurecht zu finden.
<G-vec00307-002-s351><encounter.finden><en> On the reels of Avalon, you will encounter the Coat of Arms, Goblets, the Crown, Treasure Chests, the Broach, and the generic poker card values that have been creatively crafted to match the theme.
<G-vec00307-002-s351><encounter.finden><de> Auf den Walzen finden Sie bei Avalon ein Wappen, Trinkbecher, die Krone, Schatzkisten, die Brosche sowie die normalen Spielkartenwerte, die passend zum Thema des Spiels grafisch angepasst wurden.
<G-vec00307-002-s352><encounter.finden><en> Here you'll encounter artistic boutiques, antique shops and atmospheric cafés.
<G-vec00307-002-s352><encounter.finden><de> Hier finden Sie Kunst- und Antiquitätengeschäfte und stimmungsvolle Lokale.
<G-vec00307-002-s353><encounter.finden><en> If you happen to have some old catalogs from the 1970s or 1980s, published by Yoseido in Tokyo - a forerunner and leading gallery for contemporary Japanese prints - you will encounter etchings and mezzotints by Koichi Sakamoto in nearly every issue.
<G-vec00307-002-s353><encounter.finden><de> Sollten Sie zufällig alte Kataloge aus den siebziger und achtziger Jahren von Yoseido in Tokyo besitzen - einer führneden Galerie für zeitgenössische japanische Grafikkunst - werden Sie in nahezu jeder Ausgabe Radierungen und Mezzotintos von Koichi Sakamoto finden.
<G-vec00307-002-s354><encounter.finden><en> We also encounter even such behavioural patterns with humans, thus probably helped to develop the "shame of genitalia", i.e. the anxiety to present your own genitalia not (permanently) openly visible, especially if their condition signals readiness for copulation.
<G-vec00307-002-s354><encounter.finden><de> Auch solche Verhaltensweisen finden wir beim Menschen wieder, sie trugen vermutlich dazu bei, die "Genitalscham" zu entwickeln, also das Bestreben, die eigenen Genitalien nicht (ständig) offen sichtbar zu präsentieren, insbesondere dann, wenn ihr Zustand Paarungsbereitschaft signalisiert.
<G-vec00307-002-s355><encounter.kommen><en> If you use a Windows Terminal Server/Citrix environment, the Across Clients need to be updated manually, as the automatic update routine may encounter problems.
<G-vec00307-002-s355><encounter.kommen><de> Bei der Verwendung einer Umgebung müssen die Across-Clients manuell aktualisiert werden, da es bei automatischen Aktualisierungen zu Problemen kommen kann.
<G-vec00307-002-s356><encounter.kommen><en> Due to the high resolution that 4K displays are running, you might encounter the information visible from within the client as too small.
<G-vec00307-002-s356><encounter.kommen><de> Durch die hohe Auflösung an 4K-Displays kann es dazu kommen, dass die Darstellung der Informationen im Client zu klein und dadurch nicht lesbar sind.
<G-vec00307-002-s357><encounter.kommen><en> If you skipped adding a Google Account when you first set up HTC Explorer, you may encounter problems when using some Google apps.
<G-vec00307-002-s357><encounter.kommen><de> Wenn Sie das Hinzufügen eines Google Kontos bei der erstmaligen Einrichtung des HTC Sensation übersprungen haben, könnte es bei der Verwendung von einigen Google -Apps zu Problemen kommen.
<G-vec00307-002-s358><encounter.kommen><en> On your way you will encounter all of the landscapes the park has to offer: from deciduous, coniferous, and mixed forests to wet and dry heaths, and shifting sand.
<G-vec00307-002-s358><encounter.kommen><de> Unterwegs kommen Sie an allen Landschaftstypen des Parks vorbei, an Laub-, Nadel- und Mischwäldern, über nasse und trockene Heidefelder und durch Flugsandlandschaften.
<G-vec00307-002-s359><encounter.kommen><en> If you skipped adding a Google Account when you first set up HTC Explorer, you may encounter problems when using some Google apps.
<G-vec00307-002-s359><encounter.kommen><de> Wenn Sie das Hinzufügen eines Google Kontos bei der erstmaligen Einrichtung des HTC Sensation XL mit Beats Audio übersprungen haben, könnte es bei der Verwendung von einigen Google -Apps zu Problemen kommen.
<G-vec00307-002-s360><encounter.kommen><en> Otherwise, you may encounter problems with certain operations such as editing the PATH environment variable or accessing the Service Control Manager.
<G-vec00307-002-s360><encounter.kommen><de> Andernfalls kann es bei bestimmten Operationen wie der Bearbeitung der Umgebungsvariablen PATH oder dem Zugriff auf den Service Control Manager zu Problemen kommen.
<G-vec00307-002-s361><encounter.kommen><en> Due to the new software we may encounter problems (such as general slowness) related to high load on the site, and we want to act on those swiftly.
<G-vec00307-002-s361><encounter.kommen><de> Aufgrund der neuen Software kann es zu Problemen kommen (zum Beispiel langsames Laden) aufgrund hoher Belastung auf der Webseite, und wir wollen solche Dinge schnellstmöglich aus der Welt schaffen.
<G-vec00307-002-s362><encounter.kommen><en> Here is Peter Hurley with details on his first encounter with Romania: “I could say that I have spent more than half of my life in Romania.
<G-vec00307-002-s362><encounter.kommen><de> Peter Hurley über seinen Entschluss, nach Rumänien zu kommen: „Ich könnte wohl sagen, dass ich mehr als die Hälfte meines Lebens in Rumänien verbracht habe.
<G-vec00307-002-s363><encounter.kommen><en> Even though you took thousands of precautions to keep your drive fit and running, we know it is almost certain to encounter an error message at some point of time.
<G-vec00307-002-s363><encounter.kommen><de> Obwohl Sie Tausende von Vorsichtsmaßnahmen getroffen haben, um Ihre Festplatte fit zu halten und zu betreiben, wissen wir, dass es zu einem bestimmten Zeitpunkt fast sicher zu einer Fehlermeldung kommen wird.
<G-vec00307-002-s364><encounter.kommen><en> In Germanic mythology, we encounter numerous gigantic gods.
<G-vec00307-002-s364><encounter.kommen><de> In der germanischen Mythologie kommen zahlreiche riesenhafte Götter vor.
<G-vec00307-002-s365><encounter.kommen><en> As our heroes set out on their journey again, they encounter a waterfall.
<G-vec00307-002-s365><encounter.kommen><de> Der alte Moormann Unsere Helden setzen ihre Reise fort und kommen an einen Wasserfall.
<G-vec00307-002-s366><encounter.kommen><en> Disabling Bazaarvoice-hosted CSS and relying entirely on your own CSS files increases your overhead and might cause you to encounter difficulties with future upgrades.
<G-vec00307-002-s366><encounter.kommen><de> Wenn Sie das von Bazaarvoice gehostete CSS deaktivieren und sich komplett auf Ihre eigenen CSS-Dateien verlassen, erhöht sich der Arbeitsaufwand und es kann zu Schwierigkeiten mit zukünftigen Upgrades kommen.
<G-vec00307-002-s367><encounter.kommen><en> When restoring a pre-enryption GPT disk image on an encrypted disk, you may encounter critical operating system failures.
<G-vec00307-002-s367><encounter.kommen><de> Beim Wiederherstellen des Images eines GPT-Bootdatenträgers auf den Zustand vor dessen Verschlüsselung kann es zu Funktionsstörungen des Betriebssystems kommen.
<G-vec00307-002-s387><encounter.sehen><en> On the way, we encounter such famous figures as the legendary Winter Kings, the polymath Athanasius Kircher and the poet Paul Fleming.
<G-vec00307-002-s387><encounter.sehen><de> Plötzlich sehen sich so berühmte Gestalten wie der legendäre Winterkönig Friedrich, der Universalgelehrte Athanasius Kircher oder der Arzt und Dichter Paul Fleming mit den Eulenspiegeleien des rücksichtslosesten aller Spaßmacher konfrontiert.
<G-vec00307-002-s388><encounter.sehen><en> If you don’t want to encounter annoying advertisements and other unnecessary presentations, you need the help of Web TV Easy.
<G-vec00307-002-s388><encounter.sehen><de> Wenn sie keine lästige Werbung und andere unnötige Einblendungen sehen möchten, brauchen sie die Unterstützung von Web TV...
<G-vec00307-002-s389><encounter.sehen><en> Just take a look at our gallery to see what you can encounter on your dives.
<G-vec00307-002-s389><encounter.sehen><de> Schau einfach in unsere Galerie, um zu sehen, was du bei deinen Tauchgängen sehen kannst.
<G-vec00307-002-s390><encounter.sehen><en> While abroad, you will encounter many situations, that don't come planned or expected.
<G-vec00307-002-s390><encounter.sehen><de> Im Ausland wirst du dich oft vor Situationen sehen, die du so nicht geplant oder erwartet hast.
<G-vec00307-002-s391><encounter.sehen><en> If you encounter any sort of error, reach out to our 24/7 SaferVPN chat support to get back online.
<G-vec00307-002-s391><encounter.sehen><de> Wenn Sie einen Fehler sehen, wenden Sie sich rund um die Uhr an den SaferVPN Chat-Support, um wieder online zu gehen.
<G-vec00307-002-s392><encounter.sehen><en> You also may encounter tracking technologies from third parties on certain pages of the websites that we do not control and have not authorized.
<G-vec00307-002-s392><encounter.sehen><de> Darüber hinaus sehen Sie möglicherweise Nachverfolgungstechnologien von Drittanbietern auf bestimmten Seiten der Website, die nicht unter unserer Kontrolle stehen und die wir nicht erlaubt haben.
<G-vec00307-002-s393><encounter.sehen><en> Discover the wonders from the underwater world and encounter sharks, rays and octopuses.
<G-vec00307-002-s393><encounter.sehen><de> Erkunden Sie die Wunder der Unterwasserwelt und sehen Sie Haie, Rochen und Kraken.
<G-vec00307-002-s394><encounter.sehen><en> Enjoy relaxed atmosphere and encounter some of the Territory's spectacular wildlife that roams the hotel's tropical gardens and manicured Globetrotters Voucher Info
<G-vec00307-002-s394><encounter.sehen><de> Genießen Sie die entspannte Atmosphäre und sehen Sie einige der spektakulären Tiere der Gegend, die durch die tropischen Gärten und über den gepflegten Rasen des Hotels wandern.
<G-vec00307-002-s395><encounter.sehen><en> You will encounter many roulette strategies on the net.
<G-vec00307-002-s395><encounter.sehen><de> Sie sehen nicht wenige Roulette Techniken rund um das Netz.
<G-vec00307-002-s396><encounter.sehen><en> This ensures your customers do not encounter warnings when they try to buy from you.
<G-vec00307-002-s396><encounter.sehen><de> Dadurch sehen Ihre Kunden keine Warnungen, wenn Sie bei Ihnen einkaufen wollen.
<G-vec00307-002-s397><encounter.sehen><en> This means that all the Chinese tourists that we encounter seemingly everywhere on this planet are only the advance guard, so to speak.
<G-vec00307-002-s397><encounter.sehen><de> Das heißt, die chinesischen Touristen, die wir überall auf der Welt sehen, sind nur eine kleine „Vorhut“.
<G-vec00307-002-s398><encounter.sehen><en> We had the opportunity to encounter snakes and monkeys during our work in the field and experience how it is like to work in the tropical forest surrounded by deadly snakes and spiders but also by stunning frogs and impressively huge trees.
<G-vec00307-002-s398><encounter.sehen><de> Wir hatten die Chance, während unserer Arbeit Schlangen und Affen zu sehen und zu erfahren, wie es ist, in einem tropischen Regenwald umringt von teils tödlichen Schlangen und Spinnen, aber auch wunderschönen Fröschen und überwältigend großen Bäumen zu arbeiten.
<G-vec00307-002-s399><encounter.sehen><en> In this Hanseatic town you'll encounter centuries-old monuments, beautiful townhouses and historic facades.
<G-vec00307-002-s399><encounter.sehen><de> In der ehemaligen mächtigen Hansestadt sehen Sie jahrhundertealte Denkmäler, schöne Bürgerhäuser und historische Giebel.
<G-vec00307-002-s400><encounter.sehen><en> In general, when you encounter a problem with an FTP transfer, examine the FTP log by selecting Site > Advanced > FTP Log.
<G-vec00307-002-s400><encounter.sehen><de> Sehen Sie bei Problemen mit FTP-Transfers in jedem Fall im FTP-Protokoll unter Site > Erweitert > FTP-Protokoll nach.
<G-vec00307-002-s401><encounter.sehen><en> You may also encounter other rays here, usually travelling in small schools.
<G-vec00307-002-s401><encounter.sehen><de> Vielleicht sehen Sie auch andere Rochen hier, die in der Regel in kleinen Schulen reisen.
<G-vec00307-002-s402><encounter.stoßen><en> By touch to the bathroom or toilet, but with a good chance that you will encounter something.
<G-vec00307-002-s402><encounter.stoßen><de> Durch Berührung zum Badezimmer oder zur Toilette, aber mit einer guten Chance, dass Sie auf etwas stoßen werden.
<G-vec00307-002-s403><encounter.stoßen><en> If you enable these cookies, you will encounter less targeted advertising.
<G-vec00307-002-s403><encounter.stoßen><de> Wenn Sie diese Cookies blockieren, stoßen Sie weniger auf gezielte Werbung.
<G-vec00307-002-s404><encounter.stoßen><en> Grab your camera and surprise the folks back home with the animals you can encounter in Munich!
<G-vec00307-002-s404><encounter.stoßen><de> Schnappt euch eure Kamera und überrascht eure Verwandten daheim damit, auf welche Tiere man in München so stoßen kann.
<G-vec00307-002-s405><encounter.stoßen><en> As a retailer or eCommerce brand, you’re likely to encounter many recurring questions throughout the day.
<G-vec00307-002-s405><encounter.stoßen><de> Als Einzelhändler werden Sie wahrscheinlich den ganzen Tag über auf viele wiederkehrende Fragen stoßen.
<G-vec00307-002-s406><encounter.stoßen><en> This is created from the expansion in red platelets that you will encounter while taking Boldenone.
<G-vec00307-002-s406><encounter.stoßen><de> Dies ist auf die Ausdehnung der roten Blutplättchen zurückzuführen, auf die Sie bei der Einnahme von Boldenone stoßen.
<G-vec00307-002-s407><encounter.stoßen><en> The first difficulty you may encounter is that you will need to decide on the breed of chickens.
<G-vec00307-002-s407><encounter.stoßen><de> Die erste Schwierigkeit, auf die Sie stoßen können, ist, dass Sie sich für die Hühnerrasse entscheiden müssen.
<G-vec00307-002-s408><encounter.stoßen><en> Most men encounter erection problems such as the Erectile Dysfunction, which is also referred to as a weak erection.
<G-vec00307-002-s408><encounter.stoßen><de> Die meisten Männer stoßen Erektionsprobleme wie die erektile Dysfunktion, die auch als eine schwache Erektion bezeichnet wird.
<G-vec00307-002-s409><encounter.stoßen><en> As he extends the range of his observations, he will meet with more cases of difficulty; for he will encounter a greater number of closely-allied forms.
<G-vec00307-002-s409><encounter.stoßen><de> Dehnt er nun den Kreis seiner Beobachtung weiter aus,so wird er auf mehr Schwierigkeiten stoßen; er wird einergrossen Anzahl nahe verwandter Formen begegnen.
<G-vec00307-002-s410><encounter.stoßen><en> Pets 94 is a tribute to the pets movie where the household pets go on an adventure where they encounter different difficulty.
<G-vec00307-002-s410><encounter.stoßen><de> Pets 94 ist eine Hommage an den Haustierfilm, in dem die Haustiere ein Abenteuer unternehmen, bei dem sie auf verschiedene Schwierigkeiten stoßen.
<G-vec00307-002-s411><encounter.stoßen><en> This makes it wonderfully refreshing to encounter a red that deliberately sidesteps the oak mine field by relying entirely on maturation in stainless steel tanks.
<G-vec00307-002-s411><encounter.stoßen><de> Das macht es wunderbar erfrischend, auf einen Roten zu stoßen, der diese Problematik durch die Lagerung im Edelstahltank radikal umgeht.
<G-vec00307-002-s412><encounter.stoßen><en> Lawnmowers usually encounter their limitations on steep slopes, where the grass is simply left to grow even further.
<G-vec00307-002-s412><encounter.stoßen><de> An steilen Hängen stoßen Rasenmäher oft an ihre Grenzen und Gräser bleiben dort stehen.
<G-vec00307-002-s413><encounter.stoßen><en> It also means that MRPeasy could leapfrog over the kind of software development bugs and glitches other suppliers encounter when making the transition to a higher functioning iteration.
<G-vec00307-002-s413><encounter.stoßen><de> Es bedeutet auch, dass MRPeasy die Art von Fehlern und Störungen bei der Softwareentwicklung, auf die andere Anbieter beim Übergang zu einer höher funktionierenden Iteration stoßen, überspringen könnte.
<G-vec00307-002-s414><encounter.stoßen><en> For example, it's possible that you may encounter fraudulent job opportunities when searching for jobs online, or you may receive fraudulent email that has had the sender's email address forged to make it appear as if it came from Monster.
<G-vec00307-002-s414><encounter.stoßen><de> Beispielsweise ist es möglich, dass Sie bei der Online-Stellensuche auf betrügerische Angebote stoßen oder betrügerische E-Mails mit gefälschten Absenderadressen erhalten, die wie E-Mails von Monster aussehen.
<G-vec00307-002-s415><encounter.stoßen><en> It will also help their heirs to avoid many legal and administrative complexities they might otherwise encounter on inheriting property in another member state.
<G-vec00307-002-s415><encounter.stoßen><de> Außerdem trägt sie dazu bei, zahlreiche rechtliche und administrative Schwierigkeiten aus dem Weg zu räumen, auf die die Erben sonst möglicherweise stoßen, wenn sie Vermögen in einem anderen Mitgliedstaat erben.
<G-vec00307-002-s416><encounter.stoßen><en> When you encounter problems with Audials One, please follow the instructions below.
<G-vec00307-002-s416><encounter.stoßen><de> Wenn Sie bei der Benutzung von Audials One auf Probleme stoßen, folgen Sie bitte diesen Anweisungen.
<G-vec00307-002-s417><encounter.stoßen><en> Despite the difficulties and criticism he may encounter, I encourage him to take the risk because peace building calls also for personal sacrifice ”.
<G-vec00307-002-s417><encounter.stoßen><de> Trotz der bestehenden Hindernisse und der Kritik, auf die er stoßen könnte, möchte ich ihn zum Risiko ermutigen, denn wenn man Frieden schaffen will, muss man risikobereit sein“.
<G-vec00307-002-s418><encounter.stoßen><en> Southern California hikers/climbers use San Jacinto to prepare themselves for high altitude environments they will encounter on major peaks in the Rockies and the Sierra Nevada.
<G-vec00307-002-s418><encounter.stoßen><de> Südkalifornische Wanderer / Kletterer bereiten sich auf San Jacinto vor, um sich auf die Höhenlagen vorzubereiten, auf die sie auf den wichtigsten Gipfeln der Rockies und der Sierra Nevada stoßen werden.
<G-vec00307-002-s419><encounter.stoßen><en> And once they have found that out, then they will probably also encounter the fact that our Sun, since its actual origin, is also many billions of years older than has been accepted up to now, just as they now also have to constantly revise the age of the universe.
<G-vec00307-002-s419><encounter.stoßen><de> Und wenn sie das dann herausgefunden haben, dann stoßen sie vermutlich auch darauf, dass auch unsere Sonne seit ihrem wirklichen Ursprung um viele Milliarden Jahre älter ist, als bisher angenommen wird, so wie sie sich nun auch stetig im Alter des Universums revidieren müssen.
<G-vec00307-002-s420><encounter.stoßen><en> Four weeks later, however, he and Friday encounter an uncharted land mass in the middle of the ocean.
<G-vec00307-002-s420><encounter.stoßen><de> Inmitten des Ozeans stoßen jedoch er und Freitag nach vier Wochen auf unbekanntes Terrain.
<G-vec00307-002-s440><encounter.treffen><en> Thus, already in his childhood can we encounter that peculiar trait of Nietzsche that can be observed in him throughout his life: to adopt a formal behaviour--in his writings, his striving for form, of which he, as we will soon see, already was aware very early.
<G-vec00307-002-s440><encounter.treffen><de> Bereits in der Kindheit also treffen wir auf jene Eigenart Nietzsches, die sich sein ganzes Leben hindurch beobachten läßt: sich ein förmliches Wesen zu geben – in seinem Schreiben wiederholt sich dieses Ringen um die Form, wovon er, wie wir sehen werden, bereits früh ein Bewußtsein hat.
<G-vec00307-002-s441><encounter.treffen><en> Eidinger) and Georg (Bjarne Mädel) encounter each other again at their father’s funeral.
<G-vec00307-002-s441><encounter.treffen><de> Christian (Lars Eidinger) und Georg (Bjarne Mädel) treffen nach 30 Jahren ausgerechnet auf der Beerdigung ihres Vaters wieder aufeinander.
<G-vec00307-002-s442><encounter.treffen><en> Hard and soft, living and dead material, authentic object and image, but also constancy and impermanence, art history and the digital age encounter one another in various constellations.
<G-vec00307-002-s442><encounter.treffen><de> Harte und weiche, lebendige und tote Materie, anwesender und abwesender Körper, reales Objekt und Abbild, aber auch Beständigkeit und Unbeständigkeit, Kunstgeschichte und digitales Zeitalter treffen in unterschiedlichen Konstellationen aufeinander.
<G-vec00307-002-s443><encounter.treffen><en> This common approach has been connecting us since this very first encounter and has led to a cooperation with endures since I’ve established my business.
<G-vec00307-002-s443><encounter.treffen><de> Dieser gemeinsame Ansatz verbindet uns nun seit diesem ersten Treffen und führte zu einer Zusammenarbeit, die quasi mit Gründung meiner Werksatt begann.
<G-vec00307-002-s444><encounter.treffen><en> You can encounter a beautiful and picturesque image of Athens if you choose to visit the street markets that are organized in every neighborhood one day a week.
<G-vec00307-002-s444><encounter.treffen><de> Eine schöne und malerische Seite Athens sind die Flohmärkte, die man an einem bestimmten Tag der Woche in jeder Nachbarschaft treffen kann.
<G-vec00307-002-s445><encounter.treffen><en> They all encounter each other in constantly changing constellations.
<G-vec00307-002-s445><encounter.treffen><de> Sie alle treffen in wechselnden Konstellationen aufeinander.
<G-vec00307-002-s446><encounter.treffen><en> Many children feel a similar impulse, often with almost fanatical force; I simply carried on and had the great good fortune to encounter wonderful teachers during my development.
<G-vec00307-002-s446><encounter.treffen><de> Viele Kinder spüren einen ähnlichen Impuls, oft mit fast fanatischer Kraft; ich habe einfach weitergemacht und hatte das große Glück, während meiner Entwicklung auf wundervolle Lehrer zu treffen.
<G-vec00307-002-s447><encounter.treffen><en> To have an allergy, the body must at least once encounter an allergen and develop an increased sensitivity to it.
<G-vec00307-002-s447><encounter.treffen><de> Um eine Allergie zu bekommen, muss der Körper mindestens einmal auf ein Allergen treffen und eine erhöhte Empfindlichkeit entwickeln.
<G-vec00307-002-s448><encounter.treffen><en> Lightness and heaviness encounter each other: In the first series of the picture story, seagulls in flight are depicted against a black background; in the second one, burned-out cars.
<G-vec00307-002-s448><encounter.treffen><de> Leichtigkeit und Schwere treffen aufeinander: vor schwarzem Grund sind im ersten Strang der Bilderzählung Möwen im Flug dargestellt, im zweiten ausgebrannte Autos.
<G-vec00307-002-s449><encounter.treffen><en> This encounter left the certainty: that the family is the foundation of a more just, fitting and organized society.
<G-vec00307-002-s449><encounter.treffen><de> Eine Gewissheit konnten alle aus dem Treffen mitnehmen: die Familie ist die Grundlage für eine gerechtere, würdigere und geordnetere Gesellschaft.
<G-vec00307-002-s450><encounter.treffen><en> When we encounter someone who mistreats us, instead of acting in anger, withdraw.
<G-vec00307-002-s450><encounter.treffen><de> Wenn wir jemanden treffen, der uns schlecht behandelt, anstatt im Zorn zu handeln, zurückzutreten.
<G-vec00307-002-s451><encounter.treffen><en> But I’m excited to finally let the cat out of the bag (no, not Ying-Yang… I mean a metaphorical cat) about four very special heads that Kutaro will encounter on his journey and aid him in his quest.
<G-vec00307-002-s451><encounter.treffen><de> Aber ich freue mich, endlich die Katze aus dem Sack lassen zu können (nein, nicht Ying Yang – ich meine die sprichwörtliche Katze), was vier besondere Köpfe angeht, die Kutaro auf dem Weg treffen und ihn bei seiner Mission unterstützen werden.
<G-vec00307-002-s452><encounter.treffen><en> The phrases are carefully organized in to 10 categories and 50 sub categories to handily suit your needs in different situations you may encounter while abroad.
<G-vec00307-002-s452><encounter.treffen><de> Die Phrasen sind sorgfältig in 10 Kategorien und 50 Unterkategorien organisiert, um Ihre Bedürfnisse in verschiedenen Situationen, die Sie im Ausland treffen können.
<G-vec00307-002-s453><encounter.treffen><en> On the ground floor the visitors encounter the dead body of a cow killed during a feud.
<G-vec00307-002-s453><encounter.treffen><de> Im Erdgeschoss treffen Besuchende zunächst auf eine Kuh, die in Folge einer Fehde getötet wurde.
<G-vec00307-002-s454><encounter.treffen><en> Warnings Don't assume that a mild, calm encounter with this person will end well for you; it may be weeks or months, but it's virtually guaranteed that you'll hear something horrible about yourself from a mutual acquaintance somewhere.
<G-vec00307-002-s454><encounter.treffen><de> Nimm nicht an, dass ein sanftes, ruhiges Treffen mit dieser Person gut für dich enden wird; es mag Wochen oder Monate dauern, aber es ist beinahe sicher, dass du von einer gemeinsamen Bekanntschaft irgendwo etwas Schreckliches über dich selbst hören wirst.
<G-vec00307-002-s455><encounter.treffen><en> Monks and pilgrims are, as we know, journeying not so much to a place, but to an encounter with Him who has always been waiting for us.
<G-vec00307-002-s455><encounter.treffen><de> Mönche und Pilger wissen sich auf dem Weg, nicht um an einen Ort zu gelangen, sondern um Den zu treffen, der schon immer auf sie gewartet hat.
<G-vec00307-002-s456><encounter.treffen><en> It put me in certain troubles that culminated in a decision: "I will leave as to avoid our encounter."
<G-vec00307-002-s456><encounter.treffen><de> Das erweckte in mir gewisse Sorgen, die in der Entscheidung kulminierten: Ich werde wegfahren, damit wir uns nicht treffen können.
<G-vec00307-002-s457><encounter.treffen><en> An important characteristic in Grasso’s work is the use of different temporalities that can often encounter each other in a single work.
<G-vec00307-002-s457><encounter.treffen><de> Ein wichtiges Charakteristikum im Werk Grassos ist der Einsatz unterschiedlicher Zeitlichkeiten, die oft in einem einzelnen Werk aufeinander treffen können.
<G-vec00307-002-s458><encounter.treffen><en> You can encounter him in a peculiar way during the Moustache Tour which includes his contemporary “double” as one of three guides to the cultural peculiarities of the Slovenian capital.
<G-vec00307-002-s458><encounter.treffen><de> Eine interessante Möglichkeit ihn zu „treffen“, ist eine Schnurrbarttour, bei der Sie von einem „Doppelgänger“ Jakopičs auf einen Streifzug durch die kulturellen Besonderheiten der slowenischen Hauptstadt mitgenommen werden.
<G-vec00307-002-s478><encounter.zusammentreffen><en> An encounter with landscape architect Michel Gesret in 1993 resulted in these ideas taking on more concrete form.
<G-vec00307-002-s478><encounter.zusammentreffen><de> Ein Zusammentreffen mit dem Landschaftsarchitekten Michel Gesret im Jahre 1993, führte dann zu einer Konkretisierung der Ideen.
<G-vec00307-002-s479><encounter.zusammentreffen><en> This publication is devoted to the relationship between two contrasting works by light artist James Turrell (*1943 in Los Angeles): Architectures of Light and Skyspaces, which explore the encounter between the architectural interior and the natural world outdoors.
<G-vec00307-002-s479><encounter.zusammentreffen><de> Die Publikation widmet sich dem Verhältnis zweier konträrer Werktypen des Lichtkünstlers und den Skyspaces, die das Zusammentreffen von architektonischem Innen- und natürlichem Außenraum untersuchen.
<G-vec00307-002-s480><encounter.zusammentreffen><en> After the concert, over a glass of wine and tasty snacks, there was a friendly encounter between GENUIN, the artists and the numerous concert-goers lasting until late in the evening.
<G-vec00307-002-s480><encounter.zusammentreffen><de> Anschließend gab es bei einem Glas Wein und einem leckeren Imbiss bis spät in den Abend hinein ein gemütliches Zusammentreffen zwischen GENUIN, den Künstlern und den zahlreichen Konzertbesuchern.
<G-vec00307-002-s481><encounter.zusammentreffen><en> This is a central element in Walter’s art. The unknown, the not yet seen, the not yet experienced must have place in his pictures, a fault line, as it were, that owes its existence to the accelerated drying process of two incompatible materials; parts of the picture, therefore, that result from the encounter of will and chance, that are consequently not controllable at the outset.
<G-vec00307-002-s481><encounter.zusammentreffen><de> Denn das ist ein zentrales Element in Walters Kunst: Unbekanntes, noch nicht Geschautes, nie Dagewesenes soll in seinen Bildern sein, eine Verwerfung etwa, die sich dem beschleunigten Trocknungsvorgang zweier unverträglicher Materialien verdankt, Stellen im Bild also, die aus dem Zusammentreffen von Willen und Zufall hervorgehen, die mithin vornweg nicht planbar sind – sind sie planbar geworden, also in das Repertoire der Ausdrucksmittel des Künstlers übergegangen, so sind sie wohl zielgerichtet einsetzbar, aber keine Neuheiten mehr.
<G-vec00307-002-s482><encounter.zusammentreffen><en> The encounter of Occident and Orient is one of the major topics of our time. This encounter is the theme of the present volume in regards to the Palestinian realm from 1799 to 1948.
<G-vec00307-002-s482><encounter.zusammentreffen><de> Das Zusammentreffen von Okzident und Orient als eines der Themen unserer Zeit wird in dem vorliegenden Sammelband hinsichtlich des Raumes Palästina historisch thematisiert.
<G-vec00307-002-s483><encounter.zusammentreffen><en> Your encounter with Mona was undoubtedly a stroke of luck for the world of perfumery.
<G-vec00307-002-s483><encounter.zusammentreffen><de> Ihr Zusammentreffen mit Mona war ohne Zweifel ein Glücksfall für die Parfümeriewelt.
<G-vec00307-002-s484><encounter.zusammentreffen><en> The encounter between the Biblical message and Greek thought was not simple chance [...].
<G-vec00307-002-s484><encounter.zusammentreffen><de> Das Zusammentreffen der biblischen Botschaft und des griechischen Denkens war kein Zufall [...].
<G-vec00307-002-s485><encounter.zusammentreffen><en> Thus for me the encounter with Willi Baumeister at the Academy in Stuttgart was a particularly special experience whose real meaning, as certainly was the case for many others, too, I first became aware of later.
<G-vec00307-002-s485><encounter.zusammentreffen><de> So war für mich das Zusammentreffen mit Willi Baumeister an der Akademie in Stuttgart ein ganz besonderes Erlebnis, dessen wirkliche Bedeutung mir, wie sicher vielen anderen auch, erst später bewußt wurde.
<G-vec00307-002-s486><encounter.zusammentreffen><en> My first encounter with Mince Pies was in London about 2 years ago.
<G-vec00307-002-s486><encounter.zusammentreffen><de> Mein erstes Zusammentreffen mit Mince Pies hatte ich in London vor 2 Jahren.
<G-vec00307-002-s487><encounter.zusammentreffen><en> The young man accelerates, but has no chance of avoiding an encounter with the police.
<G-vec00307-002-s487><encounter.zusammentreffen><de> Der junge Mann beschleunigt, kann ein Zusammentreffen mit der Polizei jedoch nicht vermeiden.
<G-vec00307-002-s488><encounter.zusammentreffen><en> As the story of a long-term analysis that moves gradually through the stages of the professor’s angry defensive posturing and religio-philosophical jousting to a deep mutual sympathy between patient and doctor, the book is rich in intellectual and emotional substance; but, in the professor’s recalling of key life events, it offers as well a full-bodied social canvas of its time: there are, for instance, chapters that tell of a close encounter with the mafia in the Red Hook section of Brooklyn, crashing a party in early 70’s Harlem and navigating the underground counterculture of mid-70’s Los Angeles.
<G-vec00307-002-s488><encounter.zusammentreffen><de> Als die Geschichte einer langfristigen Analyse, die sich graduell durch die Stufen des verärgerten, defensiven Getue des Professors und des religio-philosophischen Fechtens zu einer tiefen gegenseitigen Sympathie zwischen Patient und Doktor bewegt, ist das Buch reich an intellektueller und emotionaler Substanz; zudem liefert es, in den Erinnerungen des Professors an Schlüsselmomente seines Lebens, eine vollmundige soziale Leinwand seiner Zeit: es gibt, zum Beispiel, Kapitel, die von einem gefährlichen Zusammentreffen mit der Mafia in der Red Hook Section von Brooklyn erzählen, dem uneingeladenen Teilnehmen an einer Party im Harlem der frühen 70er, und dem Navigieren der Untergrundgegenkultur der Mitte der 70er in Los Angeles.
<G-vec00307-002-s489><encounter.zusammentreffen><en> Only writing and his encounter with Eik and her daughter manage to bring him back into the here and now.
<G-vec00307-002-s489><encounter.zusammentreffen><de> Nur das Schreiben und sein Zusammentreffen mit Eik und ihrer Tochter können ihn wieder zurück in die Gegenwart bringen.
<G-vec00307-002-s490><encounter.zusammentreffen><en> The upbeat and constructive meetings gave a special feeling of enthusiasm and interest in the coming celebrations and youth encounter in Schoenstatt. Star Weekend in March
<G-vec00307-002-s490><encounter.zusammentreffen><de> Die konstruktiven Treffen vermittelten den Anwesenden ein Gefühl von Begeisterung und wachem Interesse für die kommenden Feierlichkeiten und das Zusammentreffen der vielen Jugendlichen 2005 in Schönstatt.
<G-vec00307-002-s491><encounter.zusammentreffen><en> Through the encounter between students from different cultural backgrounds, [Q] STUDIES represent a place in which transdisciplinary and intercultural understanding is made possible and being practised.
<G-vec00307-002-s491><encounter.zusammentreffen><de> Durch das Zusammentreffen von Studierenden aus unterschiedlichen kulturellen Kontexten stellen die [Q]STUDIES einen Ort dar, in welchem transdisziplinäre und interkulturelle Verständigung ermöglicht und eingeübt wird.
<G-vec00307-002-s492><encounter.zusammentreffen><en> An encounter which will decide whether a new business relation is established or if your competitor gets the order you would have wanted.
<G-vec00307-002-s492><encounter.zusammentreffen><de> Das Zusammentreffen entscheidet, ob eine neue Geschäftsbeziehung entsteht oder ob Ihr Konkurrent den Auftrag erhält, den Sie sich gewünscht haben.
<G-vec00307-002-s493><encounter.zusammentreffen><en> Encounter of two Presidents: Michael Burke, Chairman and CEO of Louis Vuitton and Bernard Giudicelli, President of the French Tennis Federation, as well as renowned former tennis player and Roland-Garros Tournament Director, Guy Forget, for the delivery of the two trunks to Roland-Garros. Tags: Trunks, Trophies, Know-how 05/30
<G-vec00307-002-s493><encounter.zusammentreffen><de> Ein Zusammentreffen von Präsidenten bei der Übergabe der beiden Koffer an Roland-Garros: Michael Burke, Vorstand und Generaldirektor von Louis Vuitton, und Bernard Giudicelli, Präsident der French Tennis Federation, sowie Abonnieren Sie die digitalen News von Louis Vuitton und gehören Sie zu den Ersten, die über Produkte, Events und Neuigkeiten informiert werden.
<G-vec00307-002-s494><encounter.zusammentreffen><en> The performance begins with an encounter of a woman and a man, starting from a learned patriarchal relationship.
<G-vec00307-002-s494><encounter.zusammentreffen><de> Die Aufführung beginnt mit dem Zusammentreffen einer Frau und eines Mannes, basierend auf den Erfahrungen einer patriarchalischen Beziehung.
<G-vec00307-002-s495><encounter.zusammentreffen><en> My attempt to get around such “crochet traumata” had a fundamental influence on the overall form.This encounter with women of another generation and with other experiences turned out to be an essential component of the work.
<G-vec00307-002-s495><encounter.zusammentreffen><de> Der Versuch solche „Häkeltraumata“ zu umgehen, hat jedoch die gesamte förmliche Gestaltung wesentlich beeinflusst.Das Zusammentreffen mit Frauen einer anderen Generation und mit anderen Erfahrungen entpuppte sich als wesentlicher Bestandteil der Arbeit.
<G-vec00307-002-s496><encounter.zusammentreffen><en> "H2R - Mobility for sustainability 2014" offers new opportunities for economic development in the mobility sector thanks to the encounter of its exhibitors with the world of Green Business.
<G-vec00307-002-s496><encounter.zusammentreffen><de> "H2R - Mobility for sustainability 2014" bietet neue Chancen für die wirtschaftliche Entwicklung im Bereich der Mobilität dank dem Zusammentreffen seiner Akteure mit der Welt des Green Business.
