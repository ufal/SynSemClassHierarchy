<G-vec00197-001-s019><bear.aushalten><en> The Prophet, who was unable to read or write, replied 'I do not know how to read'. The angel then held him forcibly and pressed his chest so hard that he could not bear the pressure.
<G-vec00197-001-s019><bear.aushalten><de> Der Prophet, der weder lesen noch schreiben konnte, antwortete: ´Ich kann nicht lesen.´ Der Engel hielt ihn dann gewaltsam fest und drückte seine Brust so fest, dass er es kaum aushalten konnte.
<G-vec00197-001-s020><bear.aushalten><en> I think I screamed at one point and started to thrash around, as I could not bear the pain.
<G-vec00197-001-s020><bear.aushalten><de> Ich denke an einem Punkt schrie ich und begann mich herumzuwälzen, da ich den Schmerz nicht aushalten konnte.
<G-vec00197-001-s021><bear.aushalten><en> You have to be able to bear the truth.
<G-vec00197-001-s021><bear.aushalten><de> Die Realität muss man aushalten können.
<G-vec00197-001-s022><bear.aushalten><en> Usually a person could not bear it for more than three days, but Mr. Xu 's limbs were stretched like that for seven days the first time and then many more times thereafter.
<G-vec00197-001-s022><bear.aushalten><de> Für gewöhnlich konnte eine Person diese Folter nicht länger als drei Tage aushalten, doch Xu Daweis Gliedmassen wurden beim ersten Mal sieben Tage lang gezogen und später sogar noch länger.
<G-vec00197-001-s023><bear.aushalten><en> When the teacher or a superior on the path knows you are ready, that you are able to bear it, you are completely drawn out of the ego, pulled towards the real center and beyond.
<G-vec00197-001-s023><bear.aushalten><de> Wenn der Lehrer oder einer der Vorfahren auf dem Pfad weiß, dass du so weit bist, dass du es aushalten kannst, wirst du völlig aus dem Ego herausgeholt und zum wahren Zentrum und darüber hinaus gezogen.
<G-vec00197-001-s024><bear.aushalten><en> The love that came out from them washed over me in waves and was so pure and strong I could not bear it.
<G-vec00197-001-s024><bear.aushalten><de> Die Liebe die aus ihnen herauskam, wusch in Wellen über mich und war so rein und stark, dass ich es nicht aushalten konnte.
<G-vec00197-001-s025><bear.aushalten><en> All this together causes me to weep. I can bear it no longer and ask the Lady whether it might pass.
<G-vec00197-001-s025><bear.aushalten><de> Ich kann das nicht länger aushalten und frage die Frau, ob das von mir genommen werden könne.
<G-vec00197-001-s026><bear.aushalten><en> It was made plain to me that this process was going to be unpleasant, but I could stop it when it became too painful for me to bear.
<G-vec00197-001-s026><bear.aushalten><de> Es wurde mir klar gemacht, dass dieser Prozess unangenehm sein würde, aber ich könne es stoppen wenn ich den Schmerz nicht mehr aushalten würde.
<G-vec00197-001-s027><bear.aushalten><en> Under three things the earth quakes, And under four, it cannot bear up: Under a slave when he becomes king, And a fool when he is satisfied with food, Under an unloved woman when she gets a husband, And a maidservant when she supplants her mistress (Prov. 30:21-23).
<G-vec00197-001-s027><bear.aushalten><de> Unter drei Dingen erbebt die Erde, Und unter vieren kann sie es nicht aushalten: Unter einem Sklaven, wenn er König wird, Und einem Narren, wenn er Nahrung zur Genüge hat,Unter einer ungeliebten Frau, wenn sie geheiratet wird, Und einer Dienerin, wenn sie ihre Herrin aussticht (Spr 30:21-23).
<G-vec00197-001-s028><bear.aushalten><en> But were you to cause the soul‘s body great and sudden pain, then the soul shall not bear it for long and tear out, and you then can boil or roast a dead body and it shall feel no more punishment.
<G-vec00197-001-s028><bear.aushalten><de> Versetzest du den Leib der Seele aber augenblicklich in einen großen Schmerz, so wird solches die Seele nicht lange aushalten, sondern sogleich einen gewaltigen Riss tun, und du kannst dann einen völlig toten Leib sieden und braten, und er wird nichts mehr fühlen von der Strafe.
<G-vec00197-001-s029><bear.aushalten><en> I fell because I could not bear such power and glory.
<G-vec00197-001-s029><bear.aushalten><de> Ich fiel, da ich soviel Macht und Schönheit nicht aushalten konnte.
<G-vec00197-001-s030><bear.aushalten><en> And it is actually a beautiful state, you just have to bear it.
<G-vec00197-001-s030><bear.aushalten><de> Und es ist eigentlich ein schöner Zustand, nur aushalten musst du ihn.
<G-vec00197-001-s031><bear.aushalten><en> One must be able to bear both - also as those that divide these moments.
<G-vec00197-001-s031><bear.aushalten><de> Beides müsse man aushalten können - auch als derjenige, der mit einem diese Momente teile.
<G-vec00197-001-s032><bear.aushalten><en> And if there was intimacy there it was TOO INTIMATE so that one couldn’t bear this uneasy feeling of being trapped under water and slowly freezing.
<G-vec00197-001-s032><bear.aushalten><de> Und wenn da Nähe war, dann war es immer ZU NAH, so dasss man es nicht aushalten konnte ein beklemmendes Gefühl wie eingeschlossen sein unter Wasser und langsam festfrieren.
<G-vec00197-001-s033><bear.aushalten><en> The existing apron has had its load to bear. Over the past five decades, more than six million aircraft have taxied across its surface, with a total weight of over 290 million tonnes.
<G-vec00197-001-s033><bear.aushalten><de> Das bisherige Vorfeld hat schon einiges aushalten müssen: In den vergangenen fünf Jahrzehnten sind über sechs Millionen Flugzeuge mit einem Gesamtgewicht von mehr als 290 Millionen Tonnen über diese Flächen gerollt.
<G-vec00197-001-s034><bear.aushalten><en> Lu Hai was unable to bear this and called his aunt when he went to use the toilet.
<G-vec00197-001-s034><bear.aushalten><de> Lu Hai konnte dies nicht mehr aushalten und so rief er seine Tante an, als er auf die Toilette ging.
<G-vec00197-001-s035><bear.aushalten><en> And the old man did so and he immediately became so hot that he could hardly bear the heat, thanking Me profusely for such favor, but because he is now too hot, he would like to cool down a little.
<G-vec00197-001-s035><bear.aushalten><de> Und der Alte tat das, und es ward ihm gleich so warm, daß er es am Ende vor lauter Wärme nicht mehr aushalten konnte und Mir dafür gar gewaltig zu danken anfing für solch eine Wohltat; aber da es ihm nun zu warm wäre, so möchte er nun sich etwas abkühlen; denn es sei ihm ein wenig zu warm.
<G-vec00197-001-s036><bear.aushalten><en> The heart could not bear the realization of so gigantic a battle.
<G-vec00197-001-s036><bear.aushalten><de> Das Herz würde das Bewusstwerden einer so gigantischen Schlacht nicht aushalten.
<G-vec00197-001-s037><bear.aushalten><en> He only eats one bowl of rice and one bowl of soup for each meal, lives in a simple room and bears hardships that others cannot bear.
<G-vec00197-001-s037><bear.aushalten><de> Er isst zu jeder Mahlzeit nur eine Schale Reis und eine Schale Suppe, lebt in einem einfachen Raum und erträgt Schwierigkeiten, die andere nicht aushalten können.
<G-vec00197-001-s057><bear.behalten><en> You should also bear in mind that because of such terror and under the Untied Nations auspices 330,000persons were driven from Kosovo and Metohia.
<G-vec00197-001-s057><bear.behalten><de> Sie sollten auch Im Kopf behalten, dass wegen eines derartigen Terrors und unter der Schirmherrschaft der Vereinten Nationen 330.000Personen aus Kosovo und Methohija vertrieben wurden.
<G-vec00197-001-s058><bear.behalten><en> It is very important to bear in mind that warts could appear anywhere on the body.
<G-vec00197-001-s058><bear.behalten><de> Es ist sehr wichtig, im Auge zu behalten, die Warzen überall am Körper auftauchen könnten.
<G-vec00197-001-s059><bear.behalten><en> If your pastor tells you that the blood of Jesus Christ is there for you to commit sin and use it to bathe as bathing water, bear in mind that it does not work like that.
<G-vec00197-001-s059><bear.behalten><de> Wenn Ihr Pastor Ihnen sagt, dass das Blut Jesu Christi da ist, damit Sie Sünde begehen und es benutzten, um sich damit wie Badewasser zu baden, behalten Sie im Geist, dass das so nicht funktioniert.
<G-vec00197-001-s060><bear.behalten><en> (Although he will always bear the scars caused by the catastrophe on his legs and in his memories).
<G-vec00197-001-s060><bear.behalten><de> Es geht ihm gut, aber die Spuren der Katastrophe wird er für immer behalten: als Narben an den Beinen, und auch in seinen Erinnerungen.
<G-vec00197-001-s061><bear.behalten><en> We offer them with a happy state of mind, imagining that our honored guests are made comfortable and happy by them, and we bear in mind the voidness of everything involved in this.
<G-vec00197-001-s061><bear.behalten><de> Wir versuchen die Gaben mit einem glücklichen Geisteszustand darzubringen, und wir stellen uns vor, wie unsere geehrten Gäste es sich bequem machen und sich glücklich fühlen, und wir behalten die Leerheit von all den Dingen im Sinn, die mit dem Darbringen verbunden sind.
<G-vec00197-001-s062><bear.behalten><en> "And we should also bear in mind the further text in this verse: ""and like the sound of many waters and like the sound of mighty peals of thunder"", for we find it in just the same formulation once again – and only once again – in the Revelation, and it will also help us to identify the bride."
<G-vec00197-001-s062><bear.behalten><de> Und auch den weiteren Text in diesem Vers: „und wie ein Rauschen vieler Wasser und wie ein Rollen starker Donner” sollten wir im Auge behalten, denn wir finden ihn in genau derselben Formulierung noch einmal – und nur noch einmal - in der Offenbarung, und er wird uns auch helfen, die Braut zu identifizieren.
<G-vec00197-001-s063><bear.behalten><en> Companies need to bear this in mind when planning blogger engagement.
<G-vec00197-001-s063><bear.behalten><de> Genau das sollten Unternehmen bei der Planung von Blogger Engagement im Hinterkopf behalten.
<G-vec00197-001-s064><bear.behalten><en> It is essential to bear in mind that warts could appear anywhere on the body.
<G-vec00197-001-s064><bear.behalten><de> Es ist sehr wichtig, im Auge zu behalten, dass Warzen auf eine beliebige Stelle auf dem Körper zeigen.
<G-vec00197-001-s065><bear.behalten><en> Merely bear in mind, you still should do a reliable Blog post Cycle Treatment (PCT) as well as take the appropriate supplements to guarantee security along the road.
<G-vec00197-001-s065><bear.behalten><de> Lediglich im Auge behalten, sollten Sie dennoch eine effektive Post Cycle Therapie (PCT) zu tun und auch die entsprechenden Ergänzungen Sicherheit auf der Straße zu gewährleisten.
<G-vec00197-001-s066><bear.behalten><en> We should bear in mind that the role of the Law is to bring us to Christ and to help us believe in God’s righteousness through Him.
<G-vec00197-001-s066><bear.behalten><de> Wir sollten im Kopf behalten, dass es die Rolle des Gesetzes ist, uns zu Christus zu bringen und uns zu helfen, durch Ihn an die Gerechtigkeit Gottes zu glauben.
<G-vec00197-001-s067><bear.behalten><en> You should also bear in mind the tips we have given in the previous parts of this blog series.
<G-vec00197-001-s067><bear.behalten><de> Es lohnt sich auch, die Tipps, die wir in den anderen Teilen der Blogserie gegeben haben, in Erinnerung zu behalten.
<G-vec00197-001-s068><bear.behalten><en> Thus, the author of the Epistle to the Hebrews exhorts us to bear in mind those who announced the Gospel to us and who have already departed.
<G-vec00197-001-s068><bear.behalten><de> So ermahnt uns der Verfasser des Briefes an die Hebräer, jene in Erinnerung zu behalten, die uns das Evangelium verkündigt haben und bereits von uns gegangen sind.
<G-vec00197-001-s069><bear.behalten><en> One thing to bear in mind, much of Anavar's 'mildness' is likewise based upon very early research study where the dosing was in between 2 as well as 15 mgs.
<G-vec00197-001-s069><bear.behalten><de> "Die Hauptsache im Auge zu behalten, viel Anavar der ""Milde"" wird zusätzlich auf der Basis sehr frühen Forschungsstudie, wo die Dosierung zwischen 2 und 15 mgs war."
<G-vec00197-001-s070><bear.behalten><en> We should bear in mind that, judging from the small influence of most missionaries, a wandering crew from some semi-civilised land, if washed to the shores of America, would not have produced any marked effect on the natives, unless they had already become somewhat advanced.
<G-vec00197-001-s070><bear.behalten><de> Wir müssen im Auge behalten, dass eine wandernde Truppe aus irgend einem halb civilisirten Lande, wenn sie an die Küsten von Amerika angetrieben würde, nach dem geringen Einflüsse der meisten Missionäre zu urtheilen, keine ausgesprochene Wirkung auf die Eingeborenen geäussert haben würde, wenn diese nicht bereits in einem gewissen Grade fortgeschritten gewessen wären.
<G-vec00197-001-s071><bear.behalten><en> One shall bear in mind that NGOs can do a lot to strengthen democracy, but not everything - democratic authorities have to assume their own responsibility.
<G-vec00197-001-s071><bear.behalten><de> Man sollte in Erinnerung behalten, dass NGOs zwar viel für die Stärkung der Demokratie tun können - aber doch keine Alleskönner sind.
<G-vec00197-001-s072><bear.behalten><en> Like any type of medicine or supplement, there are some negative effects of Anavar to bear in mind.
<G-vec00197-001-s072><bear.behalten><de> Wie bei jeder Art von Drogen oder zu ergänzen, gibt es einige Nebenwirkungen von Anavar im Auge zu behalten.
<G-vec00197-001-s073><bear.behalten><en> The main thing to bear in mind, a lot of Anavar's 'mildness' is additionally based upon very early research study where the application was between 2 and 15 mgs.
<G-vec00197-001-s073><bear.behalten><de> "Die Hauptsache im Auge zu behalten, viel von Anavar der ""Milde"" wird zusätzlich auf Basis der frühen Forschung, wo die Anwendung zwischen 2 und 15 mgs war."
<G-vec00197-001-s074><bear.behalten><en> We ought, however, to be cautious in concluding that colours which appear to us dull, are not attractive to the females of certain species; we should bear in mind such cases as that of the common house-sparrow, in which the male differs much from the female, but does not exhibit any bright tints.
<G-vec00197-001-s074><bear.behalten><de> Wir sollten indessen in Bezug auf die Folgerung, dass Färbungen, welche uns trübe erscheinen, auch den Weibchen gewisser Species nicht anziehend sind, vorsichtig sein; wir sollten derartige Fälle im Sinne behalten, wie den gemeinen Haussperling, bei welchem das Männchen bedeutend vom Weibchen abweicht, aber keine hellen Farbentöne darbietet.
<G-vec00197-001-s075><bear.behalten><en> This point is important to bear in mind when we reflect on the two criticisms often leveled against the four categories of appropriate attention.
<G-vec00197-001-s075><bear.behalten><de> Es ist wichtig, diesen Punkt im Auge zu behalten, wenn wir uns mit zwei Kritikpunkten auseinandersetzen, die oft gegen die vier Kategorien der geeigneten Aufmerksamkeit ins Feld geführt werden.
<G-vec00442-001-s095><bear.bringen><en> “Our cooperation will bear fruit for both parties.
<G-vec00442-001-s095><bear.bringen><de> “Diese Kooperation wird für beide Seiten einen Gewinn bringen.
<G-vec00442-001-s096><bear.bringen><en> "For if those words of Christ and Peter are to be understood figuratively, they are not to be made to bear the meaning those people claim, but they are to be related to the meaning of that sword of which Matthew writes in this way: ""Think not that I am come to send peace on earth: I came not to send peace, but a sword."
<G-vec00442-001-s096><bear.bringen><de> Will man jene Worte Christi und Petri sinnbildlich nehmen, so sind sie doch nicht auf Das, was meine Gegner sagen, zu beziehen, sondern auf die Bedeutung jenes Schwertes, von welchem Matthäus schreibt: Glaubet nicht, daß ich in die Welt gekommen bin, den Frieden zu bringen: nicht bin ich gekommen, den Frieden zu bringen, sondern das Schwert.
<G-vec00442-001-s097><bear.bringen><en> The Salus Populi Romani is the mother that gives us health in growth, she gives us health in facing and overcoming problems, she gives us the health to make us free to make definitive choices. The mother teaches us how to be fruitful, to be open to life and to always bear good fruit, joyful fruit, hopeful fruit, and never to lose hope, to give life to others, physical and spiritual life.
<G-vec00442-001-s097><bear.bringen><de> Die »Salus Populi Romani« ist die Mutter, die uns das Wohlergehen im Wachstum schenkt, sie schenkt uns das Wohl beim Angehen und Überwinden der Probleme, sie schenkt uns Wohlergehen, indem sie uns frei macht für endgültige Entscheidungen; die Mutter lehrt uns, fruchtbar zu sein, für das Leben offen zu sein und immer Früchte des Guten zu bringen, Früchte der Freude, Früchte der Hoffnung, niemals die Hoffnung zu verlieren, den anderen das Leben zu schenken, physisch und geistlich.
<G-vec00442-001-s098><bear.bringen><en> Teenagers: Wrong movements while playing or doing sport often exert a more powerful shock to the spine than it can bear.
<G-vec00442-001-s098><bear.bringen><de> Teenager: Falsche Bewegungen bei Spiel und Sport bringen oft einen größeren Schock, als die Wirbelsäule tolerieren kann.
<G-vec00442-001-s099><bear.bringen><en> "15 ""But the ones that fell on the good ground are those who, having heard the word with a noble and good heart, keep it and bear fruit with patience."
<G-vec00442-001-s099><bear.bringen><de> 15 Das in der guten Erde aber sind die, welche in einem redlichen und guten Herzen das Wort, nachdem sie es gehört haben, bewahren und Frucht bringen mit Ausharren.
<G-vec00442-001-s100><bear.bringen><en> If you don't like one provider, you can always change later, though bear in mind that this may well change your email address too.
<G-vec00442-001-s100><bear.bringen><de> Wenn Sie einen Provider nicht mehr wollen, können Sie später immer wechseln, obgleich dieser Wechsel auch eine Änderung Ihrer E-Mail Adresse mit sich bringen wird.
<G-vec00442-001-s101><bear.bringen><en> “If the fruit we are to bear is love, its prerequisite is this ‘remaining’, which is profoundly connected with the kind of faith that holds on to the Lord and does not let go” (Jesus of Nazareth, Doubleday, New York 2007, p. 262).
<G-vec00442-001-s101><bear.bringen><de> »Wenn die Frucht, die wir bringen sollen, die Liebe ist, so ist ihre Voraussetzung eben dieses ›Bleiben‹, das ganz tief mit dem Glauben zu tun hat, der den Herrn nicht losläßt« (Jesus von Nazareth, Freiburg-Basel-Wien 2007, S. 307).
<G-vec00442-001-s102><bear.bringen><en> Yet, ecumenism will not bear lasting fruit unless it is accompanied by concrete actions of conversion that move our consciences and foster the healing of memory and of relationships.
<G-vec00442-001-s102><bear.bringen><de> Dennoch wird der Ökumenismus keine dauerhaften Früchte bringen, wenn er nicht von konkreten Gesten der Umkehr begleitet ist, die das Gewissen berühren und die Heilung der Erinnerungen und der Beziehungen fördern.
<G-vec00442-001-s103><bear.bringen><en> It is only through prayer that we can be part of Her plan and thus bear fruit.
<G-vec00442-001-s103><bear.bringen><de> Nur durch das Gebet allein können wir an Ihrem Plan teilhaben und Frucht bringen.
<G-vec00442-001-s104><bear.bringen><en> The disciples are commissioned to go and bear fruit; and they are given a legal right to use the Name of Jesus and to have the same authority that Jesus exercised in His earthly walk: JOHNÂ 16:23-24,26 .
<G-vec00442-001-s104><bear.bringen><de> Die Jünger werden beauftragt, hinzugehen und Frucht zu bringen; und sie bekommen ein gesetzmäßiges Recht, den Namen Jesu zu benutzen und dieselbe Autorität zu haben, wie sie Jesus in Seinem irdischen Wandel ausübte: JOHANNES 16:23-24,26 .
<G-vec00442-001-s105><bear.bringen><en> Today we are here at the tomb of the first of the Apostles to bear witness to love for Peter and the Successor of Peter.
<G-vec00442-001-s105><bear.bringen><de> Nun sind wir heute hier am Grab des ersten Apostels um unseren Glauben an Petrus und an den Petrusnachfolger, den Christus mit seinem Amt betraut, hat zum Ausdruck zu bringen.
<G-vec00442-001-s106><bear.bringen><en> Moreover, the Church is the Bride of Jesus Christ — I shall stop talking about the nuns — and nuns are the brides of Jesus Christ, and they draw all their strength from there, before the Tabernacle, before the Lord, in prayer with their Spouse, to bear his message.
<G-vec00442-001-s106><bear.bringen><de> Außerdem ist die Kirche Braut Christi – und damit beende ich das Thema der Ordensschwestern – und die Schwestern sind Bräute Christi, und daraus nehmen sie all ihre Kraft, vor dem Tabernakel, vor dem Herrn, im Gebet mit ihrem Bräutigam, um seine Botschaft zu bringen.
<G-vec00442-001-s107><bear.bringen><en> Each one of us is a branch of the one vine; and all of us together are called to bear the fruits of this common membership in Christ and in the Church.
<G-vec00442-001-s107><bear.bringen><de> Jeder von uns ist eine Rebe des einzigen Weinstocks; und alle zusammen sind wir berufen, die Früchte dieser gemeinsamen Zugehörigkeit zu Christus und der Kirche zu bringen.
<G-vec00442-001-s108><bear.bringen><en> We cannot bear eternal fruit unless we are willing, as a seed, to fall into the ground and die.
<G-vec00442-001-s108><bear.bringen><de> Wir können keine ewige Frucht bringen, bis wir willig sind, als ein Same in den Boden zu fallen und zu sterben.
<G-vec00442-001-s109><bear.bringen><en> The full potential in industrial automation or in the automotive industry – in economic terms, too – will first be brought to bear by 5G networks, and their significantly lower signal propagation delays.
<G-vec00442-001-s109><bear.bringen><de> Das volle Potenzial in der Industrieautomation oder im Bereich Automotive werden – auch in wirtschaftlicher Hinsicht – erst die 5G-Netze mit ihren deutlich niedrigeren Signallaufzeiten bringen.
<G-vec00442-001-s110><bear.bringen><en> For the younger elk cows it is common to bear only one calf.
<G-vec00442-001-s110><bear.bringen><de> Für die jüngeren Elchkühe ist es üblich nur ein Kalb auf die Welt zu bringen.
<G-vec00442-001-s111><bear.bringen><en> The sons of God are those who bear fruit.
<G-vec00442-001-s111><bear.bringen><de> Die Kinder Gottes sind die, die Frucht bringen.
<G-vec00442-001-s112><bear.bringen><en> "The second three, on the other hand, have an ""intact"" environment and also bear fruits."
<G-vec00442-001-s112><bear.bringen><de> "Die zweiten drei hingegen, haben eine ""intakte"" Umwelt und bringen auch Früchte."
<G-vec00442-001-s113><bear.bringen><en> Gardening of a roof If you decided to be engaged in gardening of a roof, be sure – this work will bear to you fruit.
<G-vec00442-001-s113><bear.bringen><de> Die Begrünung des Dachs Wenn Sie sich entschieden haben, sich mit der Begrünung des Dachs zu beschäftigen, seien Sie überzeugt – wird dieses Werk Ihnen die Früchte bringen.
<G-vec00442-001-s114><bear.bringen><en> Take holiday feelings home with you with the 28 cm tall Teddy bear wearing a blue shirt printed with the city skyline.
<G-vec00442-001-s114><bear.bringen><de> Im blauen Shirt mit Aufdruck der Stadt-Silhouette bringt der 28 cm große Teddybär Urlaubsgefühle aus Düsseldorf mit nach Hause.
<G-vec00442-001-s115><bear.bringen><en> Lightly lined and padded jacket, baby Sailor Lowell has two roomy front pockets with zip closure.Practical and functional, not tightening, not a band and does not bear any kind of discomfort to the wearer, allowing you to maintain complete freedom of movement.Resined and durable, is a real guarantee of quality and it is perfect in many occasions of everyday life.
<G-vec00442-001-s115><bear.bringen><de> Leicht gefüttert und gepolstert, die jacke von kind Sailor Lowell verfügt über zwei große fronttaschen mit reißverschluss.Praktisch und funktionell, nicht eng, nicht band und bringt jegliche art von beschwerden an den träger, so dass die absolute bewegungsfreiheit.Vergossen und beständig, ist eine echte garantie für qualität und ist perfekt allen gelegenheiten des täglichen lebens.
<G-vec00442-001-s116><bear.bringen><en> 8 Therefore bear fruits worthy of repentance, and do not begin to say to yourselves, 'We have Abraham as our father.'
<G-vec00442-001-s116><bear.bringen><de> 8 Bringt nun der Buße würdige Früchte; und beginnt nicht, bei euch selbst zu sagen: Wir haben Abraham zum Vater.
<G-vec00442-001-s117><bear.bringen><en> Any tree which does not bear good fruits will be cut down and cast into the fire.
<G-vec00442-001-s117><bear.bringen><de> Ein jeglicher Baum, der nicht gute Früchte bringt, wird abgehauen und ins Feuer geworfen.
<G-vec00442-001-s118><bear.bringen><en> You see, if we sow an apple seed, we will get an apple tree and from that apple tree, after a while it will bear apple fruits for us.
<G-vec00442-001-s118><bear.bringen><de> Sehen Sie, wenn wir einen Apfelkern aussäen, dann bekommen wir einen Apfelbaum; und dieser Apfelbaum bringt nach einiger Zeit Früchte, also Äpfel, für uns hervor.
<G-vec00442-001-s119><bear.bringen><en> In this is my Father glorified, that you bear much fruit; and so you will be my disciples.
<G-vec00442-001-s119><bear.bringen><de> Hierin wird mein Vater verherrlicht, daß ihr viel Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s120><bear.bringen><en> God's people are those people who bear fruit – for all of the last two thousand years.
<G-vec00442-001-s120><bear.bringen><de> Volk Gottes ist jenes Volk, das seine Früchte bringt - seit zweitausend Jahren.
<G-vec00442-001-s121><bear.bringen><en> We pray that the Word that is being sowed will bear fruit soon and not die away.
<G-vec00442-001-s121><bear.bringen><de> Wir beten, dass der ausgestreute Samen des Wortes Gottes bald Frucht bringt und nicht erstickt.
<G-vec00442-001-s122><bear.bringen><en> """But blessed is the man who trusts in the Lord"", the Pope continued. The prophet says of him: ""he is like a tree planted by water, that sends out its roots by the stream, and does not fear when heat comes, for its leaves remain green, and is not anxious in the year of drought, for it does not cease to bear fruit""."
<G-vec00442-001-s122><bear.bringen><de> Dagegen, so fuhr der Papst fort, indem er »das Gegenteil« davon hervorhob, sei »der Mann gesegnet, der auf den Herrn sich verlässt«, denn, wie in der Heiligen Schrift geschrieben stehe, »er ist wie ein Baum, der am Wasser gepflanzt ist und am Bach seine Wurzeln ausstreckt; Er hat nichts zu fürchten, wenn Hitze kommt; seine Blätter bleiben grün; auch in einem trockenen Jahr ist er ohne Sorge, unablässig bringt er seine Früchte«.
<G-vec00442-001-s123><bear.bringen><en> But it is not the free choice of such a society, if you explain it as a social principle of equal rank, for example, that two men take a woman to be a surrogate mother who will then bear a child for them, or whether one of two women gets planted in a seed from a man, so that the two women have a child.
<G-vec00442-001-s123><bear.bringen><de> Es ist aber keineswegs die freie Entscheidung einer solchen Gesellschaft, ob man es als sozial ebenbürtiges Prinzip erklärt, daß zum Beispiel zwei Männer sich eine Frau als Leihmutter nehmen, die dann für sie ein Kind zur Welt bringt, oder ob von zwei Frauen sich eine von einem Mann einen Samen einpflanzen läßt, damit die beiden Frauen dann auch ein Kind haben.
<G-vec00442-001-s124><bear.bringen><en> A celebration may be flawless on the exterior, very beautiful, but if it does not lead us to encounter Jesus Christ, it is unlikely to bear any kind of nourishment to our heart and our life.
<G-vec00442-001-s124><bear.bringen><de> Eine Feier kann vom äußerlichen Gesichtspunkt her einwandfrei, wunderschön sein, aber wenn sie uns nicht zur Begegnung mit Jesus Christus führt, dann besteht die Gefahr, dass sie unserem Herzen und unserem Leben keinerlei Nahrung bringt.
<G-vec00442-001-s125><bear.bringen><en> The tank-top woman Dubbed Deha does not mark, does not end and does not bear any type of discomfort to the wearer, allowing you to preserve the maximum freedom of movement .
<G-vec00442-001-s125><bear.bringen><de> Das tank-top von frau Lynette Deha nicht eng, nicht band und bringt jegliche art von beschwerden an den träger, so dass die erhaltung der bewegungsfreiheit .
<G-vec00442-001-s126><bear.bringen><en> Herein is my Father glorified, that ye bear much fruit; so shall ye be my disciples.
<G-vec00442-001-s126><bear.bringen><de> Hierin wird mein Vater verherrlicht, daÃ ihr viel Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s127><bear.bringen><en> "Then, continuing, the text says: ""I chose you and appointed you that you should go and bear fruit and that your fruit should abide"". With this we return to the beginning, to the image, to the Parable of the Vine: it is created to bear fruit."
<G-vec00442-001-s127><bear.bringen><de> Der Text sagt dann weiter: »Ich habe euch dazu bestimmt, daß ihr euch aufmacht und Frucht bringt und daß eure Frucht bleibt.« Damit kehren wir zum Anfang zurück, zum Bild, zum Gleichnis des Weinstocks: er ist geschaffen, um Frucht zu bringen.
<G-vec00442-001-s128><bear.bringen><en> If a man remains in me and I in him, he will bear much fruit; apart from me you can do nothing.
<G-vec00442-001-s128><bear.bringen><de> Wer in mir bleibt und in wem ich bleibe, der bringt reiche Frucht; denn getrennt von mir könnt ihr nichts vollbringen.
<G-vec00442-001-s129><bear.bringen><en> 8 My Father is honored by this, that you bear much fruit and show that you are my disciples.
<G-vec00442-001-s129><bear.bringen><de> 8 Hierin wird mein Vater verherrlicht, daß ihr viel Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s131><bear.bringen><en> As a short-term inhalation with colistin does not bear any risks, I would encourage you to have your daughter inhale colistin 24 hourse before and for 48 hours after visiting a swimming pool.
<G-vec00442-001-s131><bear.bringen><de> Da eine kurzzeitige Colistin-Inhalation keinerlei Risiken mit sich bringt, würde ich Sie darin bestärken, Ihre Tochter bei einem vorher geplanten Schwimmbadbesuch 24 Stunden vorher und für 48 Stunden nach dem Besuch mit Colistin inhalieren zu lassen.
<G-vec00442-001-s132><bear.bringen><en> This is to my Father's glory, that you bear much fruit, showing yourselves to be my disciples.
<G-vec00442-001-s132><bear.bringen><de> Mein Vater wird dadurch verherrlicht, dass ihr reiche Frucht bringt und meine Jünger werdet.
<G-vec00197-001-s226><bear.ertragen><en> While promotional usb flash driver, in addition to the printing of the LOGO, can bear extra advertising inside the usb flash driver, and the usb flash driver can be used for 5-6 years.Â
<G-vec00197-001-s226><bear.ertragen><de> Während Werbe-USB-Flash-Treiber, neben dem Druck der LOGO, ertragen können zusätzliche Werbung in den USB-Flash-Treiber und die USB-Flash-Treiber kann für 5-6 Jahre eingesetzt werden.
<G-vec00197-001-s227><bear.ertragen><en> Above all guard for me this great deposit of faith for which I live and fight, which I want to take with me as a companion, and which makes me bear all evils and despise all pleasures: I mean the profession of faith in the Father and the Son and the Holy Spirit.
<G-vec00197-001-s227><bear.ertragen><de> ,,Bewahrt mir vor allem dieses gute Vermächtnis, für das ich lebe und kämpfe, mit dem ich sterben will und das mich alle Übel ertragen und alle Vergnügungen geringschätzen läßt: nämlich das Bekenntnis des Glaubens an den Vater und den Sohn und den Heiligen Geist.
<G-vec00197-001-s228><bear.ertragen><en> Since God is against divorce and against remarriage, every person before committing themselves to getting married must make sure they are ready to bear all the responsibilities related to marriage and to bear the many difficulties including the unforeseen surprises and frustrations.
<G-vec00197-001-s228><bear.ertragen><de> Da Gott gegen die Scheidung und gegen die Wiederverheiratung ist, muss sich jede Person, bevor sie sich in der Ehe verpflichtet, vergewissern, dass sie bereit ist, alle Verantwortung zu übernehmen, die mit der Ehe zusammenhängt, und die zahlreichen Schwierigkeiten einschließlich der möglichen Überraschungen und Frustrationen zu ertragen.
<G-vec00197-001-s229><bear.ertragen><en> One of the things hardest to bear is obviously self-righteous indignation.
<G-vec00197-001-s229><bear.ertragen><de> Zu den Dingen, deren Schwingung am schwierigsten zu ertragen ist, gehört offensichtlich die moralische Entrüstung.
<G-vec00197-001-s230><bear.ertragen><en> 36:7 For their substance was too great for them to dwell together; and the land of their sojournings could not bear them because of their cattle.
<G-vec00197-001-s230><bear.ertragen><de> 36:7 Denn ihre Habe war zu groß, daß sie nicht beieinander wohnen konnten; und das Land, darin sie Fremdlinge waren, mochte sie nicht ertragen wegen ihrer Herden.
<G-vec00197-001-s231><bear.ertragen><en> "He announced that he could not bear to ""fire on his comrades,"" that ""rather than have a split, it is better to put a bullet in one's brain."""
<G-vec00197-001-s231><bear.ertragen><de> "Er kündigte an, er könne es nicht ertragen, ""auf seine Genossen zum schießen"", ""vielmehr als eine Spaltung zu haben, ist es besser, eine Kugel ins Gehirn einzuschießen""."
<G-vec00197-001-s232><bear.ertragen><en> The problem is that the working class is hamstrung by a leadership that accepts the need for the working class to bear some degree of austerity to “bail out” capitalism, while objecting that the terms and conditions dictated by the IMF and the European Central Bank (ECB) are too severe.
<G-vec00197-001-s232><bear.ertragen><de> Das Problem ist, dass die Arbeiterklasse durch eine Führung gelähmt wird, die akzeptiert, dass die Arbeiterklasse ein gewisses Maß an Austerität ertragen müsse, um dem Kapitalismus „aus der Klemme zu helfen“; und die nur beanstandet, die vom IWF und der Europäischen Zentralbank (EZB) diktierten Bedingungen und Konditionen seien zu hart.
<G-vec00197-001-s233><bear.ertragen><en> Not being of the Truth, they always find the Truth very hard, and cannot bear it.
<G-vec00197-001-s233><bear.ertragen><de> Da sie nicht von der Wahrheit sind, finden sie immer die Wahrheit zu hart, und sie können sie nicht ertragen.
<G-vec00197-001-s234><bear.ertragen><en> In other words, God cuts the time of the little horn short for the elect's sake because they could bear no more (Matt.
<G-vec00197-001-s234><bear.ertragen><de> Mit anderen Worten: Gott verkürzt die Zeit des kleinen Horns um der Erwählten Willen, weil sie nicht mehr ertragen könnten (Matt.
<G-vec00197-001-s235><bear.ertragen><en> Job's wife could not bear to be parted from her beloved husband for very long so she returned and was amazed when she saw his recovery.
<G-vec00197-001-s235><bear.ertragen><de> Hiobs Frau konnte es nicht ertragen, von ihrem geliebten Ehemann so lange getrennt zu sein, da kehrte sie zurück und war erstaunt, als sie ihn erholt sah.
<G-vec00197-001-s236><bear.ertragen><en> He had to restrain Himself because I couldn’t bear the joy he was pouring into me.
<G-vec00197-001-s236><bear.ertragen><de> Er musste sich zurückhalten, weil ich nicht die Glückseligkeit ertragen konnte, die er in mich goß.
<G-vec00197-001-s237><bear.ertragen><en> God has already prepared the burning hell for them, but He cannot bear to see people going to hell, for He has great pity on them.
<G-vec00197-001-s237><bear.ertragen><de> Gott hat die brennende Hölle bereits für sie vorbereitet, aber Er kann es nicht ertragen, zu sehen wie die Menschen in die Hölle kommen, denn Er hat großes Mitleid mit ihnen.
<G-vec00197-001-s238><bear.ertragen><en> Employers have to bear employees gossips within the working hours because for some extent it is good.
<G-vec00197-001-s238><bear.ertragen><de> Arbeitgeber müssen Klatsch und Tratsch innerhalb der Arbeitszeit ertragen, weil es zum Teil gut ist.
<G-vec00197-001-s239><bear.ertragen><en> I can’t even bear the thought of her in another room.
<G-vec00197-001-s239><bear.ertragen><de> Ich kann nicht einmal die Vorstellung von ihr in einem anderen Raum ertragen.
<G-vec00197-001-s240><bear.ertragen><en> Even now they wallow because something in them likes the wallowing and bear the cross because something in them chooses to suffer.
<G-vec00197-001-s240><bear.ertragen><de> Sie winden sich, weil etwas in ihnen dieses Sich-Winden will, dieses Ertragen des Kreuzes, – weil etwas in ihnen das Leiden wählt.
<G-vec00197-001-s241><bear.ertragen><en> Salvianus, a monk of Marseilles, wrote some decades later: “Roman humanitas is sought among the barbarians, in fact one can no longer bear the barbarous inhumanity that holds sway among the Romans” (De gubernatione Dei).
<G-vec00197-001-s241><bear.ertragen><de> Salvianus, ein Mönch aus Marseille, schrieb ein paar Jahrzehnte später: „Bei den Barbaren sucht man die römische humanitas, denn die Unmenschlichkeit der Römer ist nicht mehr zu ertragen“ (De gubernatione Dei).
<G-vec00197-001-s242><bear.ertragen><en> The (Christian) beliefs deficiency is now excused by the saying (of Jesus) that the the sick (Christians) cannot bear the truth, at all.
<G-vec00197-001-s242><bear.ertragen><de> Der Glaube wird nun also als mangelhaft eingestanden und dieser Mangel mit der Aussage entschuldigt, dass „die Kranken“ (Christen) gar nicht die Wahrheit ertragen können.
<G-vec00197-001-s243><bear.ertragen><en> So for the person who can bear a couple of days of rain in his vacation in Peru, April to June and September to November are appropriate months and far less touristy.
<G-vec00197-001-s243><bear.ertragen><de> Wer also in seinem Urlaub in Peru auch mal ein paar Tage Regen ertragen kann, für den sind die Monate April bis Juni und September bis November ebenso interessant und weit weniger touristisch.
<G-vec00197-001-s244><bear.ertragen><en> While promotional usb flash driver, in addition to the printing of the LOGO, can bear extra advertising inside the usb flash driver, and the usb flash driver can be used for 5-6 years.
<G-vec00197-001-s244><bear.ertragen><de> Während Werbe-USB-Flash-Treiber, neben dem Druck der LOGO, ertragen können zusätzliche Werbung in den USB-Flash-Treiber und die USB-Flash-Treiber kann für 5-6 Jahre eingesetzt werden.
<G-vec00197-001-s264><bear.gebären><en> Women can bear children with whom they are not biologically related.
<G-vec00197-001-s264><bear.gebären><de> Frauen können Kinder gebären, mit denen sie biologisch nicht verwandt sind.
<G-vec00197-001-s265><bear.gebären><en> 19 And God said to Abraham: Sara thy wife shall bear thee a son, and thou shalt call his name Isaac, and I will establish my covenant with him for a perpetual covenant, and with his seed after him.
<G-vec00197-001-s265><bear.gebären><de> 19 Da sprach Gott: Ja, Sara, dein Weib, soll dir einen Sohn gebären, den sollst du Isaak heißen; denn mit ihm will ich meinen ewigen Bund aufrichten und mit seinem Samen nach ihm.
<G-vec00197-001-s266><bear.gebären><en> For example, it was widely believed that a woman was destined to bear her children in pain and that such suffering was good for her since it would increase her motherly feelings.
<G-vec00197-001-s266><bear.gebären><de> So war man allgemein der Auffassung, es sei die Bestimmung der Frau, ihre Kinder unter Schmerzen zu gebären, und diese Qualen seien nützlich, weil sie die mütterlichen Gefühle nur vertieften.
<G-vec00197-001-s267><bear.gebären><en> By the close of this era she had become scarcely more than a human animal, consigned to work and to bear human offspring, much as the animals of the herd were expected to labor and bring forth young.
<G-vec00197-001-s267><bear.gebären><de> Als diese Ära zu Ende ging, war die Frau zu kaum mehr als einem menschlichen Tier geworden mit der Bestimmung, sich abzuarbeiten und menschliche Nachkommen zu gebären, geradeso wie von den Herdentieren erwartet wurde, dass sie arbeiteten und Junge warfen.
<G-vec00197-001-s268><bear.gebären><en> "In this dream a brilliant celestial messenger appeared to him and, among other things, said: ""Joseph, I appear by command of Him who now reigns on high, and I am directed to instruct you concerning the son whom Mary shall bear, and who shall become a great light in the world."
<G-vec00197-001-s268><bear.gebären><de> "In diesem Traum erschien ihm ein strahlender himmlischer Bote, der ihm unter anderem sagte: ""Joseph, ich erscheine dir auf Geheiß Dessen, der jetzt im Himmel herrscht, und ich habe den Auftrag, dich über den Sohn, den Maria gebären und der ein großes Licht in der Welt sein wird, zu unterrichten."
<G-vec00197-001-s269><bear.gebären><en> (Luke 1:34) Mary was told her that conception would be a supernatural act of God and that she would bear the God-man Jesus, and indeed she did.
<G-vec00197-001-s269><bear.gebären><de> Maria wurde gesagt, daß ihre Empfängnis eine übernatürliche Tat Gottes ist, und daß sie den Gott-Mensch Jesus gebären wird, und tatsächlich geschah es so.
<G-vec00197-001-s270><bear.gebären><en> "Name of the church ""kvashveti""comes from the Georgian word quasi (""stone "") and joint (""bear"")."
<G-vec00197-001-s270><bear.gebären><de> "Name der Kirche ""Kaschveti"" kommt aus dem georgischen Wort qua (""Stein"") und schwa (""gebären"")."
<G-vec00197-001-s271><bear.gebären><en> Your wife Elizabeth will bear you a son, and you shall name him John.
<G-vec00197-001-s271><bear.gebären><de> Deine Frau Elisabet wird dir einen Sohn gebären; dem sollst du den Namen Johannes geben.
<G-vec00197-001-s272><bear.gebären><en> Mothers of such high spiritual level usually bear spiritually evolved offspring.
<G-vec00197-001-s272><bear.gebären><de> Mütter mit einem solch hohen spirituellen Niveau gebären gewöhnlich spirituell hochentwickelte Kinder.
<G-vec00197-001-s273><bear.gebären><en> While both sexes are needed to make the creation of new human life possible, only women actually conceive, bear, and nurse children.
<G-vec00197-001-s273><bear.gebären><de> Zwar bedarf es zur Zeugung neuen menschlichen Lebens beider Geschlechter, aber die Frauen allein empfangen, gebären und nähren Kinder.
<G-vec00197-001-s274><bear.gebären><en> and you will bruise his heel.” 3:16 To the woman he said, “I will greatly multiply your pain in childbirth. In pain you will bear children. Your desire will be for your husband,
<G-vec00197-001-s274><bear.gebären><de> 3:16 Und zum Weibe sprach er: Ich will dir viel Schmerzen schaffen, wenn du schwanger wirst; du sollst mit Schmerzen Kinder gebären; und dein Wille soll deinem Mann unterworfen sein, und er soll dein HERR sein.
<G-vec00197-001-s275><bear.gebären><en> "Through him, you knew that a virgin would conceive and bear a son, who would be called Emanuel, which is to say, ""God with you."""
<G-vec00197-001-s275><bear.gebären><de> Durch ihn habt ihr erfahren, dass eine Jungfrau einen Sohn empfangen und gebären würde, welcher Immanuel genannt würde, was bedeutet: Gott mit uns.
<G-vec00197-001-s276><bear.gebären><en> Stories about ancient rebels, notable for their stature and courage in battle, are also frequently based in part on the heritage from these visitors, as the rebel most often carried some genetics from the rape of a female slave who managed somehow to escape and bear her oversized infant alive.
<G-vec00197-001-s276><bear.gebären><de> Geschichten über antike Rebellen, angesehen für ihre Statur und Mut in der Schlacht, basieren auch häufig zum Teil auf dem Erbe dieser Besucher, da der Rebell meistens ein paar Gene von der Vergewaltigung einer Frau in sich trug, die es dann irgendwie schaffte zu fliehen und ihr übergroßes Baby lebend zu gebären.
<G-vec00197-001-s277><bear.gebären><en> "And the Angel of the LORD said to her: ""Behold, you are with child, And you shall bear a son. You shall call his name Ishmael, Because the LORD has heard your affliction."
<G-vec00197-001-s277><bear.gebären><de> Und der Engel des HERRN sprach [weiter] zu ihr: Siehe, du bist schwanger und wirst einen Sohn gebären; dem sollst du den Namen Ismael geben, denn der HERR hat auf dein Elend gehört.
<G-vec00197-001-s278><bear.gebären><en> Discuss with your girlfriend this wonderful gift, let her choose one most favorite family photo, you will bear to the artist, to order a painting.
<G-vec00197-001-s278><bear.gebären><de> Verhandlungen mit meiner Freundin dieses wunderbare Geschenk, lassen Sie Sie wählen Sie eine Lieblings-Familienfoto, das du gebären wirst zum Künstler, was würden Sie das Bild bestellen.
<G-vec00197-001-s279><bear.gebären><en> Thus says the Lord of hosts, the God of Israel, to all the exiles whom I have sent into exile from Jerusalem to Babylon: Build houses and live in them; plant gardens and eat what they produce. Take wives and have sons and daughters; takes wives for your sons, and give your daughters in marriage, that they may bear sons and daughters; multiply there, and do not decrease.
<G-vec00197-001-s279><bear.gebären><de> So spricht der HERR Zebaoth, der Gott Israels, zu allen Weggeführten, die ich von Jerusalem nach Babel habe wegführen lassen: Baut Häuser und wohnt darin; pflanzt Gärten und esst ihre Früchte; nehmt euch Frauen und zeugt Söhne und Töchter, nehmt für eure Söhne Frauen und gebt eure Töchter Männern, dass sie Söhne und Töchter gebären; mehrt euch dort, dass ihr nicht weniger werdet.
<G-vec00197-001-s280><bear.gebären><en> 16 To the woman he said, I will greatly increase thy travail and thy pregnancy; with pain thou shalt bear children; and to thy husband shall be thy desire, and he shall rule over thee.
<G-vec00197-001-s280><bear.gebären><de> 16 Und zum Weibe sprach er: Ich will dir viel Schmerzen schaffen, wenn du schwanger wirst; du sollst mit Schmerzen Kinder gebären; und dein Verlangen soll nach deinem Manne sein, und er soll dein Herr sein.
<G-vec00197-001-s281><bear.gebären><en> Lk 1, 31 Behold, you shall conceive in your womb, and you shall bear a son, and you shall call his name: JESUS.
<G-vec00197-001-s281><bear.gebären><de> Lk 1, 31 und siehe, du wirst im Leibe empfangen und einen Sohn gebären, und du sollst seinen Namen Jesus heißen.
<G-vec00197-001-s282><bear.gebären><en> Here a lot depends not only on you, but also on your wife (age, ability to bear children).
<G-vec00197-001-s282><bear.gebären><de> Hier hängt nicht nur viel von Ihnen ab, sondern auch von Ihrer Frau (Alter, Fähigkeit, Kinder zu gebären).
<G-vec00197-001-s302><bear.halten><en> At the same time, we want to bear in remembrance Erich, our husband and father.
<G-vec00197-001-s302><bear.halten><de> Zugleich möchten wir die Erinnerung an Erich, unseren Ehemann und Vater, wach halten.
<G-vec00197-001-s303><bear.halten><en> Continue straight and then bear left until you reach the Archenhold Observatory.
<G-vec00197-001-s303><bear.halten><de> Fahren Sie weiter geradeaus und halten Sie sich links, bis Sie zur Archenhold-Sternwarte kommen.
<G-vec00197-001-s304><bear.halten><en> Alternate: Exit 6 (Elm Street): As you exit 190 bear left to the ramp and turn right onto Seneca Street.
<G-vec00197-001-s304><bear.halten><de> Exit 6: (Elm Street): Beim Verlassen der I 190 links halten und danach rechts auf die Seneca Street.
<G-vec00197-001-s305><bear.halten><en> Innovation is a fine thing, as are optimism and great plans, but we must also bear in mind that we are a country with a history of more than a thousand years.
<G-vec00197-001-s305><bear.halten><de> Die Erneuerung, die Hoffnung und große Pläne sind schöne Dinge, doch müssen wir uns dabei auch vor Augen halten, dass wir ein mehr als tausend Jahre altes Land sind.
<G-vec00197-001-s306><bear.halten><en> Clearly we cannot bear the fact that the past is the forever inaccessible territory, irrevocably lost to us, gone.
<G-vec00197-001-s306><bear.halten><de> Offenbar halten wir es schlecht aus, dass die Vergangenheit ein für immer unbetretbares Land ist, unwiderruflich verschwunden, futsch.
<G-vec00197-001-s307><bear.halten><en> This is because of the lack of male attributes, unlike other AAS, nevertheless bear in mind it is still a male hormonal agent and also must be utilized only by extremely knowledgeable ladies.
<G-vec00197-001-s307><bear.halten><de> Dies ergibt sich aus dem Fehlen von männlichen Attribute, im Gegensatz zu anderen AAS, halten jedoch daran, wie es ist immer noch eine männliche Hormonmittel als auch müssen durch außergewöhnlich qualifizierte Frauen Verwendung von nur gemacht werden.
<G-vec00197-001-s308><bear.halten><en> From Northern Wine Country Take U.S. Highway 101 South over the Golden Gate Bridge and bear right onto Lombard Street.
<G-vec00197-001-s308><bear.halten><de> Folgen Sie dem U.S. HighwayÂ 101 South Ã1⁄4ber die Golden Gate Bridge und halten Sie sich rechts in Richtung Lombard Street.
<G-vec00197-001-s309><bear.halten><en> It is always necessary to bear in mind the primacy of spiritual life as the basis of all pastoral planning.
<G-vec00197-001-s309><bear.halten><de> Man muss sich als Grundlage für jeden Pastoralplan immer den Primat des geistlichen Lebens vor Augen halten.
<G-vec00197-001-s310><bear.halten><en> The selected materials and the high quality machining bear up under this intensive stress.
<G-vec00197-001-s310><bear.halten><de> Die ausgewählten Materialien und die hochwertige Verarbeitung halten dieser intensiven Belastung stand.
<G-vec00197-001-s311><bear.halten><en> Bear we mind that Steam keeps updating their protection strategy thus we have to always keep updating our Steam Money Generator program at the same time.
<G-vec00197-001-s311><bear.halten><de> Halten Sie sich daran, dass wir Dampf hält die Aktualisierung ihrer Schutzstrategie so müssen wir immer halten die Aktualisierung unserer Steam-Geld-Generator-Programm in der gleichen Zeit.
<G-vec00197-001-s312><bear.halten><en> After about a half mile, bear right and follow signs to Juniper Lake.
<G-vec00197-001-s312><bear.halten><de> Nach etwa einer halben Meile, halten Sie sich rechts und folgen Sie den Schildern zu Juniper See.
<G-vec00197-001-s313><bear.halten><en> Go to the hospital and the Ascension Church, bear right and follow the signs to the compound.
<G-vec00197-001-s313><bear.halten><de> Gehen Sie auf das Krankenhaus und die Himmelfahrtskirche zu, halten Sie sich rechts und folgen Sie den Beschilderungen auf dem Compound.
<G-vec00197-001-s314><bear.halten><en> We bear left and after 300m reach the Pit Stopp cycle station (stop for a snack).
<G-vec00197-001-s314><bear.halten><de> Hier halten wir uns links und erreichen nach 300m die Radstation Pit Stopp (Einkehr).
<G-vec00197-001-s315><bear.halten><en> What we must bear in mind above everything else in this is that Goethe seeks the animal form again in the perfected human one; except that, with the former, the organs that serve more the animal functions come to the fore, are, as it were, the point toward which the whole structure tends and which the structure serves, whereas the human structure particularly develops those organs that serve spiritual functions.
<G-vec00197-001-s315><bear.halten><de> Was wir uns dabei vor allem gegenwärtig halten müssen, ist, daß Goethe die tierische Gestalt in der ausgebildeten menschlichen wieder aufsucht; nur daß dort die mehr den animalischen Verrichtungen dienenden Organe in den Vordergrund treten, gleichsam der Punkt sind, auf den die ganze Bildung hindeutet und dem sie dient, während die menschliche Bildung jene Organe besonders ausbildet, welche den geistigen Funktionen dienen.
<G-vec00197-001-s316><bear.halten><en> But they would be well advised to bear in mind the original origin of performance measurement as an improvement instrument and to also be aware that the so-called performance revolution has not been completed by a long shot.
<G-vec00197-001-s316><bear.halten><de> Ihm ist dabei aber zu empfehlen, sich die ursprüngliche Herkunft des Performance Measurement als Verbesserungsinstrument vor Augen zu halten und auch zu wissen, dass die sogenannte Performance Revolution längst nicht abgeschlossen ist.
<G-vec00197-001-s317><bear.halten><en> It would be useful to bear in mind two things for the future.
<G-vec00197-001-s317><bear.halten><de> In Zukunft sollte man sich zwei Dinge vor Augen halten.
<G-vec00197-001-s318><bear.halten><en> Bear right on the L52.
<G-vec00197-001-s318><bear.halten><de> Rechts halten auf der L52.
<G-vec00197-001-s319><bear.halten><en> In Thailand, it is very rude to carry banknotes in the back pocket as they bear the portrait of the monarch, who is a highly respected person.
<G-vec00197-001-s319><bear.halten><de> In Thailand ist es eine Respektlosigkeit, die Banknoten in der Gesäßtasche zu halten, weil auf ihnen das Porträt des Herrschers zu sehen ist, den eine große Ehre umkränzt.
<G-vec00197-001-s320><bear.halten><en> Anvarbek's arm on which the eagle is sitting rests on a support, otherwise he could not bear the weight for so long.
<G-vec00197-001-s320><bear.halten><de> Anvarbeks Arm, auf dem der Adler sitzt ruht auf einer Stütze, anders könnte er das Gewicht nicht so lange halten.
<G-vec00197-001-s416><bear.tragen><en> Account that these two years are made day internal sufferings, that I bear subduing me to the wish day God, to know better this same divine wish, you/they have made me progress more in the perfection that the precedents ten years.
<G-vec00197-001-s416><bear.tragen><de> Ich machte mir Rechnung, daß diese Zwei Jahre Tag Innen Leiden die ich trage, da unterwerfe ich mich zum Willen Tag Gott, um besser dieses derselbe zu kennen, sagen Willen wahr, sie ließen mir mehr in die Perfektion als die Präzedenzfälle zehn Jahre fortschreiten.
<G-vec00197-001-s417><bear.tragen><en> I summoned you here, and I bear a weapon that can hurt them.
<G-vec00197-001-s417><bear.tragen><de> Ich habe dich hierher beschworen, und ich trage eine Waffe, die sie verletzen kann.
<G-vec00197-001-s418><bear.tragen><en> In your forbearance take me not away; know that for your sake I bear reproach.
<G-vec00197-001-s418><bear.tragen><de> Raffe mich nicht hin nach deiner Langmut; erkenne, daß ich um deinetwillen Schmach trage.
<G-vec00197-001-s419><bear.tragen><en> The revelation I have made to you is a living revelation, and I desire that it shall bear appropriate fruits in each individual and in each generation in accordance with the laws of spiritual growth, increase, and adaptative development.
<G-vec00197-001-s419><bear.tragen><de> Die Offenbarung, die ich euch gemacht habe, ist eine lebendige Offenbarung, und ich wünsche, dass sie in jedem Einzelnen und in jeder Generation angemessene Früchte trage in Übereinstimmung mit den Gesetzen geistigen Wachstums, geistiger Steigerung und anpassungsfähiger Entwicklung.
<G-vec00197-001-s420><bear.tragen><en> I bear in my heart the insults of many people.
<G-vec00197-001-s420><bear.tragen><de> Ich trage in meinem Herzen die Beleidigungen vieler Menschen.
<G-vec00197-001-s421><bear.tragen><en> 17 From henceforth let no man trouble me: for I bear in my body the marks of the Lord Jesus.
<G-vec00197-001-s421><bear.tragen><de> 17 Hinfort mache mir niemand weiter Mühe; denn ich trage die Malzeichen des HErrn JEsu an meinem Leibe.
<G-vec00197-001-s422><bear.tragen><en> Then they compelled a certain man, Simon a Cyrenian, the father of Alexander and Rufus, as he was coming out of the country and passing by, to bear His cross.
<G-vec00197-001-s422><bear.tragen><de> Und sie zwingen einen Vorübergehenden, einen gewissen Simon von Kyrene, der vom Feld kam, den Vater Alexanders und Rufus', daß er sein Kreuz trage.
<G-vec00197-001-s423><bear.tragen><en> So long as I bear the Fa in mind, I will not treat things with as many human attachments as I did when we began our activities at the bus stop.
<G-vec00197-001-s423><bear.tragen><de> Solange ich das Fa in meinem Geiste trage, werde ich nicht Dinge mit vielen menschlichen Eigensinnen behandeln, wie ich dies zu Beginn unserer Aktivitäten an der Bushaltestelle tat.
<G-vec00197-001-s424><bear.tragen><en> 27 It is good for a man that he bear the yoke in his youth.
<G-vec00197-001-s424><bear.tragen><de> 27 Es ist ein köstlich Ding für einen Mann, daß er das Joch in seiner Jugend trage.
<G-vec00197-001-s425><bear.tragen><en> 17 From now on let no one trouble me, for I bear in my body the marks of the Lord Jesus.
<G-vec00197-001-s425><bear.tragen><de> 17 Hinfort mache mir niemand weiter Mühe; denn ich trage die Malzeichen Jesu an meinem Leibe.
<G-vec00197-001-s426><bear.tragen><en> I bear the responsibility for my entire team and my partners.
<G-vec00197-001-s426><bear.tragen><de> Ich trage die Verantwortung für mein gesamtes Team und die Partner.
<G-vec00197-001-s427><bear.tragen><en> 38 It shall be on Aaron's forehead, and Aaron shall bear the iniquity of the holy things, which the people of Israel shall make holy in all their holy gifts; and it shall be always on his forehead, that they may be accepted before the Lord.
<G-vec00197-001-s427><bear.tragen><de> 38 auf der Stirn Aarons, daß also Aaron trage die Missetat des Heiligen, das die Kinder Israel heiligen in allen Gaben ihrer Heiligung; und es soll allewege an seiner Stirn sein, daß er sie versöhne vor dem HERRN.
<G-vec00197-001-s428><bear.tragen><en> 2 Bear one another's burdens, and so carry out the Law of the Christ.
<G-vec00197-001-s428><bear.tragen><de> 2 Einer trage des andern Last, so werdet ihr das Gesetz Christi erfüllen.
<G-vec00197-001-s429><bear.tragen><en> 28:38 It shall be on Aaron’s forehead, and Aaron shall bear the iniquity of the holy things, which the children of Israel shall make holy in all their holy gifts; and it shall be always on his forehead, that they may be accepted before Yahweh.
<G-vec00197-001-s429><bear.tragen><de> 28:38 auf der Stirn Aarons, daß also Aaron trage die Missetat des Heiligen, das die Kinder Israel heiligen in allen Gaben ihrer Heiligung; und es soll allewege an seiner Stirn sein, daß er sie versöhne vor dem HERRN.
<G-vec00197-001-s430><bear.tragen><en> Let My grace be sufficient for you.... and patiently bear all burden imposed on you to serve your soul's state of maturity.... and grant Me your ear so that you can hear My voice.... open your heart to let My ray of love enter and penetrate you with My spirit: Time and again I convey My revelations to you humans, time and again I speak to people through the mouth of a servant who is devoted to Me and I truly don't do so without reason.... I know that it is necessary to provide people with a light where darkness exists in their hearts.
<G-vec00197-001-s430><bear.tragen><de> Lasse dir an Meiner Gnade genügen.... und trage alle Last geduldig, die dir auferlegt ist und zum Ausreifen deiner Seele dienet.... und schenke Mir dein Ohr, daß du vernehmen kannst Meine Stimme.... öffne dein Herz, daß Mein Liebestrahl in dich eindringen kann, und lasse dich erfüllen mit Meinem Geist: Immer wieder leite Ich Meine Offenbarungen euch Menschen zu, immer wieder spreche Ich durch den Mund eines Mir ergebenen Dieners euch Menschen an, und Ich tue das wahrlich nicht ohne Grund.... Ich weiß es, daß es nötig ist, den Menschen dort ein Licht zu geben, wo es noch dunkel ist in ihren Herzen.
<G-vec00197-001-s431><bear.tragen><en> "Rather, decision T 964/99 could be construed to mean that a ""diagnostic method"" within the meaning of Article 52(4) EPC might be present even if a physician did not necessarily have to bear responsibility for any of the steps."
<G-vec00197-001-s431><bear.tragen><de> "Die Entscheidung T 964/99 könnte vielmehr so verstanden werden, dass ein ""Diagnostizierverfahren"" nach Artikel 52 (4) EPÜ auch dann vorliegen könne, wenn ein Arzt nicht notwendigerweise für einen der Verfahrensschritte die Verantwortung trage."
<G-vec00197-001-s432><bear.tragen><en> 2 Bear one another’s burdens, and so fulfil the law of Christ.
<G-vec00197-001-s432><bear.tragen><de> 2 Einer trage des andern Last, so werdet ihr das Gesetz Christi erfüllen.
<G-vec00197-001-s433><bear.tragen><en> Every branch which bears fruit, the Father will cleanse that it may bear more fruit.
<G-vec00197-001-s433><bear.tragen><de> Jede Rebe, die Frucht trägt, wird der Vater reinigen, damit sie noch mehr Frucht trage.
<G-vec00197-001-s434><bear.tragen><en> Yes, be also confounded, and bear your shame, in that you have justified your sisters.
<G-vec00197-001-s434><bear.tragen><de> Und so werde auch du zu Schanden und trage deine Schmach, weil du deine Schwestern gerechtfertigt hast.
<G-vec00197-001-s435><bear.tragen><en> brand portfolio bear the same signature – the pursuit of the highest standards in terms of materials, functionality and emotive impact.
<G-vec00197-001-s435><bear.tragen><de> Markenwelt tragen eine Handschrift, die höchste Ansprüche an Materialität, Funktionalität und insbesondere auch Emotionalität kennzeichnet.
<G-vec00197-001-s436><bear.tragen><en> If any additional electrical components are fitted which do not serve to control the vehicle itself (for instance a refrigerator box, laptop or ventilator fan, etc.), these must bear the mark (manufacturer conformity declaration in the European Union).
<G-vec00197-001-s436><bear.tragen><de> Zusätzlich angeschlossene elektrische Geräte, die nicht der unmittelbaren Kontrolle des Fahrzeugs dienen, wie beispielsweise Kühlboxen, Computer oder Ventilatoren, müssen ein -Kennzeichen tragen (Konformitätserklärung der Hersteller in der Europäischen Union).
<G-vec00197-001-s437><bear.tragen><en> You bear the cost pertaining with the returning of the goods.
<G-vec00197-001-s437><bear.tragen><de> Sie tragen die unmittelbaren Kosten der Rücksendung der Waren.
<G-vec00197-001-s438><bear.tragen><en> It is usually left to the arbitral tribunal’s discretion to decide whether the unsuccessful party will bear the entire costs.
<G-vec00197-001-s438><bear.tragen><de> Es wird in der Regel an das Schiedsgericht nach Ermessen überlassen, zu entscheiden, ob die unterliegende Partei die gesamten Kosten tragen.
<G-vec00197-001-s439><bear.tragen><en> Women already bear the brunt of poverty.
<G-vec00197-001-s439><bear.tragen><de> Frauen tragen bereits bei der Armut die Hauptlast.
<G-vec00197-001-s440><bear.tragen><en> The risks shall be transferred to the Purchaser at the latest when the parts supplied are dispatched; this shall apply even where partial deliveries are effected, when we bear the shipping costs or where we take charge of shipping the delivery item.
<G-vec00197-001-s440><bear.tragen><de> Die Gefahr geht spätestens mit der Absendung der Lieferteile auf den Besteller über; dies gilt auch dann, wenn Teillieferungen erfolgen, wenn wir die Versendungskosten tragen, oder wenn wir die Beförderung des Liefergegenstandes übernehmen.
<G-vec00197-001-s441><bear.tragen><en> The building formwork is a temporary supporting structure, producing by the design, make concrete structure, components according to the required location, geometry shape, to maintain its in correct position, and to bear the weight of the construction template and the role of the external load on it.
<G-vec00197-001-s441><bear.tragen><de> Die Gebäudeschalung ist eine temporäre Tragkonstruktion, die nach dem Entwurf Betonkonstruktionen und Bauteile entsprechend der erforderlichen Position und Geometrieform herstellt, um ihre korrekte Position zu erhalten und das Gewicht der Konstruktionsschablone und die Rolle des Äußeren zu tragen laden Sie es auf.
<G-vec00197-001-s442><bear.tragen><en> 7:4 Now the children of Israel, when they saw the multitude of them, were greatly troubled, and said every one to his neighbour, Now will these men lick up the face of the earth; for neither the high mountains, nor the valleys, nor the hills, are able to bear their weight.
<G-vec00197-001-s442><bear.tragen><de> 7:4 Als die Israeliten ihre große Zahl sahen, waren sie tief bestürzt, und einer sagte zum andern: Diese Leute werden das ganze Land auffressen; weder die hohen Berge noch die Täler und Hügel werden ihre Last tragen können.
<G-vec00197-001-s443><bear.tragen><en> At last we bear alone the responsibility for our own life.
<G-vec00197-001-s443><bear.tragen><de> Letztendlich tragen allein wir die Verantwortung für unser eigenes Leben.
<G-vec00197-001-s444><bear.tragen><en> All bear the psychological and emotional scars of living in a war zone.
<G-vec00197-001-s444><bear.tragen><de> Alle tragen die psychologischen und emotionalen Narben des Lebens in einem Kriegsgebiet.
<G-vec00197-001-s445><bear.tragen><en> "Let us pray especially for the Ordinary Assembly of the Synod of Bishops currently taking place in Rome and whose theme is: ""The Word of God in the life and mission of the Church"", so that it may bear the fruits of authentic renewal in every Christian community."
<G-vec00197-001-s445><bear.tragen><de> In besonderer Weise beten wir für die Ordentliche Generalversammlung der Bischofssynode, die in Rom unter dem Thema stattfindet: »Das Wort Gottes im Leben und in der Sendung der Kirche.« Möge sie Früchte einer wahren Erneuerung jeder christlichen Gemeinschaft tragen.
<G-vec00197-001-s446><bear.tragen><en> Let us bear peace in our hearts, and bring it to our families and those we encounter.
<G-vec00197-001-s446><bear.tragen><de> Tragen wir Frieden in unsere Herzen, in unsere Familien, in den Herzen der Personen, denen wir begegnen.
<G-vec00197-001-s447><bear.tragen><en> To be eligible to bear the seal, products must fulfill a series of environmental, health and quality requirements.
<G-vec00197-001-s447><bear.tragen><de> Um das Siegel tragen zu dürfen, müssen die Produkte eine Reihe von Umwelt-, Gesundheits- und Qualitätsanforderungen erfüllen.
<G-vec00197-001-s448><bear.tragen><en> "According to van Roost, this would offer considerable potential for overcoming existing reservations about recycled materials.Onwards in solidarity Peter Sundt, EPRO Secretary General, finally picked up on Jan Bauer's idea and gave the participants some food for thought on their journeys home: ""As in many other ways in their daily work, farmers play a major part in determining whether all the measures around the world relating to the utilisation of used agricultural plastics will bear fruit."
<G-vec00197-001-s448><bear.tragen><de> "Damit, so van Roost, böte er ein breites Potenzial, um bestehende Vorbehalte gegen Rezyklate zu eliminieren.Im Schulterschluss zum Ziel Peter Sundt, Generalsekretär der EPRO, nahm abschließend die Gedanken von Jan Bauer auf und gab den Tagungsteilnehmern Ansätze zum Weiterdenken mit auf den Nachhauseweg: ""Wie auch sonst in seiner täglichen Arbeit entscheidet der Landwirt maßgeblich darüber, ob alle weltweiten Maßnahmen rund um die Verwertung landwirtschaftlich genutzter Kunststoffe Früchte tragen."
<G-vec00197-001-s449><bear.tragen><en> 15 You shall speak to the children of Israel, saying, ‘Whoever curses his God shall bear his sin.
<G-vec00197-001-s449><bear.tragen><de> 15 Und sage den Kindern Israel: Welcher seinem Gott flucht, der soll seine Sünde tragen.
<G-vec00197-001-s450><bear.tragen><en> The rest of the products or services that are mentioned in this Website or our Talk app and bear the trademarks of the respective organizations, companies, collaborating entities, associations or publications are their intellectual and industrial property and therefore those entities bear the relevant responsibility.
<G-vec00197-001-s450><bear.tragen><de> Die restlichen Produkte oder Dienste, die auf dieser Website oder unserer Talk App erwähnt werden und die Schutzmarken der jeweiligen Organisationen, Unternehmen, zusammenarbeitenden Einheiten, Vereinigungen oder Publikationen tragen, sind deren geistiges und gewerbliches Eigentum – daher tragen diese Einheiten die relevante Verantwortung.
<G-vec00197-001-s452><bear.tragen><en> 30 And in the breastpiece of judgment you shall put the Urim and the Thummim, and they shall be on Aaron's heart, when he goes in before the LORD. Thus Aaron shall bear the judgment of the people of Israel on his heart before the LORD regularly.
<G-vec00197-001-s452><bear.tragen><de> 30 Und du sollst in das Brustschild des Rechtsspruchs die Urim und Thummim legen, damit sie auf dem Herzen Aarons sind, wenn er hineingeht vor dem HERRN; und so soll Aaron den Rechtsspruch der Kinder Israels beständig auf seinem Herzen tragen vor dem HERRN.
<G-vec00197-001-s453><bear.tragen><en> 9 Because I have sinned against him, I will bear the LORD's wrath, until he pleads my case and establishes my right. He will bring me out into the light; I will see his righteousness.
<G-vec00197-001-s453><bear.tragen><de> 9 Den Zorn des HERRN will ich tragen - denn ich habe gegen ihn gesündigt -, bis er meine Sache hinausführt und mir Recht verschafft; er wird mich herausfüh ren ans Licht; ich werde mit Lust seine Gerechtigkeit schauen.
<G-vec00197-001-s454><bear.tragen><en> Körner wanted to donate the site to the city – under the proviso that it would create a park that would bear his name.
<G-vec00197-001-s454><bear.tragen><de> Körner wollte der Stadt das Gelände schenken – unter der Bedingung, dass ein Park angelegt wird, der seinen Namen trägt.
<G-vec00197-001-s455><bear.tragen><en> The wrought-iron banisters on the first floor bear the initials of Goethe's parents: JCG and CEG.
<G-vec00197-001-s455><bear.tragen><de> Das schmiedeeiserne Geländer im ersten Stock trägt die Initialen von Goethes Eltern: JCG und CEG.
<G-vec00197-001-s456><bear.tragen><en> b) During the period in which the subject matter of the goods or services is not in Auer Lighting's custody, the Supplier shall bear any risk of loss.
<G-vec00197-001-s456><bear.tragen><de> b) Während der Zeit, während der sich der Gegenstand der Lieferung oder Leistung nicht im Gewahrsam von Auer Lighting befindet, trägt der Auftragnehmer die Gefahr.
<G-vec00197-001-s457><bear.tragen><en> "By coming to express vague sentences on terrorism, Imam treated us like the perfect Obtuse through vagueness and duplicity, a good tree does not bear and which can not produce any fruit, as the son of a ""barren fig tree ' [cf."
<G-vec00197-001-s457><bear.tragen><de> "Durch kommen vage Sätze gegen den Terrorismus zum Ausdruck bringen, Imam behandelte uns wie die perfekte Obtuse durch Unbestimmtheit und Doppelzüngigkeit, ein guter Baum trägt nicht und die keine Früchte produzieren kann, als Sohn eines ""unfruchtbaren Feigenbaum ' [CF."
<G-vec00197-001-s458><bear.tragen><en> "The Apostle's statement ""is clear"", the Pope said. ""Faith that does not bear fruit in works is not faith""."
<G-vec00197-001-s458><bear.tragen><de> Die Aussage des Jakobus »ist eindeutig: ein Glaube, der keine Frucht trägt, ist kein Glaube«.
<G-vec00197-001-s459><bear.tragen><en> User will bear all risk associated with any content that user accesses.
<G-vec00197-001-s459><bear.tragen><de> Der Benutzer trägt alle Risiken in Verbindung mit beliebigen Inhalten, auf die der Benutzer zugreift.
<G-vec00197-001-s460><bear.tragen><en> The customer shall bear the costs of discounting and collection.
<G-vec00197-001-s460><bear.tragen><de> Die Kosten der Diskontierung und der Einziehung trägt der Kunde.
<G-vec00197-001-s461><bear.tragen><en> In this case, the Party shall bear the burden of proof for the existence of fault.
<G-vec00197-001-s461><bear.tragen><de> In diesem Fall trägt der Vertragspartner die Beweislast für das Vorliegen des Verschuldens.
<G-vec00197-001-s462><bear.tragen><en> shall bear the costs of return.
<G-vec00197-001-s462><bear.tragen><de> trägt die Kosten der Rücksendung.
<G-vec00197-001-s463><bear.tragen><en> Such a gripper needs to be soft to adapt to a great variety of geometries, but not too soft, as it will detach easily and not be able to bear weight for very long.
<G-vec00197-001-s463><bear.tragen><de> Ein solcher Greifer sollte zwar möglichst weich sein, damit er sich an verschiedenste Formen anschmiegen kann, allerdings auch nicht zu weich, weil er sich sonst zu leicht wieder ablöst und Gewichte nicht lange trägt.
<G-vec00197-001-s464><bear.tragen><en> 14:27 And whoever does not bear his cross and come after me, is not able to be my disciple.
<G-vec00197-001-s464><bear.tragen><de> 14:27 Und wer nicht sein Kreuz trägt und mir nachfolgt, ist nicht in der Lage, mein Jünger sein.
<G-vec00197-001-s465><bear.tragen><en> The Consumer does not bear the costs for performing services for the supply of water, gas or electricity that had not been made ready for sale in a limited volume or quantity, or for the supply of district heating, if: a. the Entrepreneur has not provided the Consumer with the statutorily required information about the right of withdrawal, the compensation of costs in case of withdrawal or the standard form for withdrawal, or; b. if the Consumer has not explicitly requested that the performance of the service or the supply of gas, water and electricity or district heating be started during the period of reflection.
<G-vec00197-001-s465><bear.tragen><de> Der Konsument trägt keine Kosten für Dienstleistung oder Lieferung von Gas, Wasser oder Elektrizität, die nicht bereit sind für Verkauf, in einem geringen Volumen oder einer geringen Menge, oder zur Lieferung der Stadtheizung, wenn: der Unternehmer den Konsumenten die gesetzlich vorgeschriebene Informationen über das Widerrufsrecht, die Kostenrückerstattung bei Widerruf oder das Modellformular für Widerruf nicht gegeben hat, oder; der Konsument nicht ausdrücklich um Beginn der Dienstleistung oder Lieferung von Gas, Wasser, Elektrizität oder Stadtheizung während der Überlegungsfrist ersucht hat.
<G-vec00197-001-s466><bear.tragen><en> 7.3 If a delay in despatching the goods necessitates the use of faster transport (express delivery, courier service), the Seller will bear the additional carriage costs.
<G-vec00197-001-s466><bear.tragen><de> 7.3 Wird bei verspätetem Versand der Lieferung ein beschleunigter Transport notwendig (Eilsendungen, Kurierdienste), so trägt der Lieferant die zusätzlichen Frachtkosten.
<G-vec00197-001-s467><bear.tragen><en> 7.4 The Customer shall have the sole liability for, and shall bear all risks and costs associated with the transfer of control of the Goods, including loading, unloading, correct handling and suitable storage of the Goods from Delivery and/or the new goods as described in point 7.1 above.
<G-vec00197-001-s467><bear.tragen><de> 7.4 Der Käufer hat die ausschließliche Haftung für das Auf- und Abladen, den korrekten Umgang mit den und die angemessene Lagerung der Handelsgüter(n) und/oder der neuen Handelsgüter(n) gemäß den Bestimmungen im obigen Artikel 7.1 und trägt alle Gefahren und Kosten in Bezug darauf.
<G-vec00197-001-s468><bear.tragen><en> If it is a gift from God to be shared; it is a talent which must bear fruit; it is a light that should not be hidden, but must alighten the whole house.
<G-vec00197-001-s468><bear.tragen><de> Doch der Glaube ist auch ein Geschenk, das wir mit anderen teilen sollen; er ist eine Gabe, die wir empfangen haben, damit sie Früchte trägt; er ist ein Licht, das nicht unter den Scheffel gestellt werden darf, sondern das ganze Haus erleuchten soll.
<G-vec00197-001-s469><bear.tragen><en> Should the ordering party be in default of acceptance it shall bear the risk of accidental destruction and accidental deterioration of the object purchased.
<G-vec00197-001-s469><bear.tragen><de> Gerät der Besteller in Annahmeverzug, trägt er die Gefahr des zufälligen Untergangs und einer zufälligen Verschlechterung der Kaufsache.
<G-vec00197-001-s470><bear.tragen><en> For employees taking part for the first time, the KION Group offers a special incentive in the form of starter blocks. Under KEEP 2016, the KION Group will bear the cost of one KION share (free share) in each of the first six blocks of shares that an employee takes up.
<G-vec00197-001-s470><bear.tragen><de> Für die Erstteilnahme gewährt die KION Group darüber hinaus den Mitarbeitern einen besonderen Anreiz in Form sogenannter Starterpakete: Im Rahmen von KEEP2016 trägt die KIONGroup bei den ersten sechs Aktienpaketen die Kosten für jeweils eine KION Aktie (Gratis-Aktie).
<G-vec00197-001-s471><bear.tragen><en> In the area of banking supervision, the work of previous years, also undertaken together with the Single Supervisory Mechanism (SSM), has continued to bear fruit.
<G-vec00197-001-s471><bear.tragen><de> In der Bankenaufsicht trägt die nachhaltige Arbeit der vergangenen Jahre – auch in Zusammenarbeit mit dem Einheitlichen Aufsichtsmechanismus (SSM) der EZB – weiter Früchte.
<G-vec00197-001-s472><bear.tragen><en> These accounts have shown us how the seed of the Gospel continues to germinate and bear fruit in various situations in today's world.
<G-vec00197-001-s472><bear.tragen><de> Diese Zeugnisse haben uns gezeigt, daß der Same des Evangeliums in den verschiedenen Situationen der heutigen Welt weiterhin keimt und Früchte trägt.
<G-vec00197-001-s473><bear.übernehmen><en> Since God is against divorce and against remarriage, every person before committing themselves to getting married must make sure they are ready to bear all the responsibilities related to marriage and to bear the many difficulties including the unforeseen surprises and frustrations.
<G-vec00197-001-s473><bear.übernehmen><de> Da Gott gegen die Scheidung und gegen die Wiederverheiratung ist, muss sich jede Person, bevor sie sich in der Ehe verpflichtet, vergewissern, dass sie bereit ist, alle Verantwortung zu übernehmen, die mit der Ehe zusammenhängt, und die zahlreichen Schwierigkeiten einschließlich der möglichen Überraschungen und Frustrationen zu ertragen.
<G-vec00197-001-s474><bear.übernehmen><en> Disclaimer: Despite careful control we bear no liability for the content of external links.
<G-vec00197-001-s474><bear.übernehmen><de> Haftungsausschluss: Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links.
<G-vec00197-001-s475><bear.übernehmen><en> We shall bear the costs for the exchange of faulty goods and their shipment to the site of installation provided that we are offered the opportunity of assessing the most favourable alternatives beforehand.
<G-vec00197-001-s475><bear.übernehmen><de> Die Kosten für den Umtausch der fehlerhaften Ware und deren Transport zur Einbaustelle übernehmen wir, solange uns im Vorwege die Möglichkeit gegeben wurde, die günstigsten Alternativen abzuwägen.
<G-vec00197-001-s476><bear.übernehmen><en> In this case, the platform operator must bear the costs of the insurance if certain conditions are met.
<G-vec00197-001-s476><bear.übernehmen><de> In diesem Fall muss der Plattform-Betreiber, sofern bestimmte Bedingungen erfüllt sind, die Kosten übernehmen.
<G-vec00197-001-s477><bear.übernehmen><en> But he soon sent to prison and will be Internet providers that guarantee a constant access to these sites, such as Torrents.ru, and thus do not bear any responsibility.
<G-vec00197-001-s477><bear.übernehmen><de> Aber er bald ins Gefängnis geschickt und Internet-Providern, die einen konstanten Zugang zu diesen Seiten, wie Torrents.ru garantiert werden, und somit übernehmen keine Verantwortung.
<G-vec00197-001-s478><bear.übernehmen><en> "Here, one can distinguish between models where institutions bear the costs of publication on behalf of ""their"" authors, and models where institutions finance a particular model completely (so that other authors also benefit from it)."
<G-vec00197-001-s478><bear.übernehmen><de> "Hierbei kann man unterscheiden zwischen Modellen, bei denen die Institutionen stellvertretend für ""ihre"" Autor/innen Kosten übernehmen, und solchen Modellen, bei denen Institutionen ein Modell komplett finanzieren (so dass auch andere Autor/innen davon profitieren)."
<G-vec00197-001-s479><bear.übernehmen><en> "If you opt for ""OUR"" you will bear all the costs as the principal."
<G-vec00197-001-s479><bear.übernehmen><de> Mit der Option «OUR» übernehmen Sie als Auftraggeber alle Kosten.
<G-vec00197-001-s480><bear.übernehmen><en> Though they were produced to the best of our knowledge, we shall bear no liability for any omission, error or translation inaccuracy that they might contain.
<G-vec00197-001-s480><bear.übernehmen><de> Obwohl wir diese Texte mit bestem Wissen und Gewissen erstellt haben, übernehmen wir keine Haftung für Missverständnisse, die aus ihrem Gebrauch hervorgehen könnten.
<G-vec00197-001-s481><bear.übernehmen><en> If the costs of the problem are not borne by the facility, then there is little perceived need to bear the costs of prevention.
<G-vec00197-001-s481><bear.übernehmen><de> Wenn die Kosten für das Problem nicht der Einrichtung selbst entstehen, dann sieht sie kaum einen Grund, die Kosten für die Prävention zu übernehmen.
<G-vec00197-001-s482><bear.übernehmen><en> It is quite common that Investa Immobiliengruppe joins forces with other companies to jointly bear the risk of complex development projects.
<G-vec00197-001-s482><bear.übernehmen><de> Häufig schließt sich die Investa Immobiliengruppe bei der Durchführung ihrer Immobilienprojekte mit weiteren Gesellschaften zusammen, um auf gemeinsames Risiko die Trägerschaft für anspruchsvolle Projekte zu übernehmen.
<G-vec00197-001-s483><bear.übernehmen><en> After the statutory period of 14 days the customer must bear the costs for the return delivery.
<G-vec00197-001-s483><bear.übernehmen><de> Nach Ablauf der gesetzlichen Rückgabefrist von 14 Tagen muss der Kunde die Kosten für die Rücksendung übernehmen.
<G-vec00197-001-s484><bear.übernehmen><en> Each person will bear the consequences of his choice in the next days.
<G-vec00197-001-s484><bear.übernehmen><de> Jeder wird die Verantwortung seiner Entscheidung in den nächsten Tagen übernehmen.
<G-vec00197-001-s485><bear.übernehmen><en> We or any other person or the organization, which took part in the creation of the site, don't bear any responsibility for any damages, even for any possible consequential damages.
<G-vec00197-001-s485><bear.übernehmen><de> Wir oder jede andere Person oder die Organisation, die an der Schaffung der Seite teilnahmen, übernehmen keine Verantwortung für jede Schäden, auch für eventuelle Folgeschäden.
<G-vec00197-001-s486><bear.übernehmen><en> Officials and other servants taking leave on personal grounds may continue to acquire pension rights provided that they also bear the cost of the employer's contribution.
<G-vec00197-001-s486><bear.übernehmen><de> Erläuterungen Beamte und sonstige Bedienstete, die sich in Urlaub aus persönlichen Gründen befinden, können weiterhin Ruhegehaltsan-sprüche erwerben, wenn sie auch die Kosten des Arbeitgeberbeitrags übernehmen.
<G-vec00197-001-s487><bear.übernehmen><en> We will bear the cost of returning the products.
<G-vec00197-001-s487><bear.übernehmen><de> Wir übernehmen die Kosten für die Rücksendung der Waren.
<G-vec00197-001-s488><bear.übernehmen><en> We bear no liability for printing errors, actuality of the information provided or for the content of external links.
<G-vec00197-001-s488><bear.übernehmen><de> Wir übernehmen keine Haftung für Druckfehler und Aktualität des Informationsangebotes sowie für die Inhalte externer Links.
<G-vec00197-001-s489><bear.übernehmen><en> We must bear such costs in addition to the agreed purchase price only if this has been expressively agreed and if the tools, drawings and models will become our property.
<G-vec00197-001-s489><bear.übernehmen><de> Zusätzlich zum vereinbarten Kaufpreis sind solche Kosten nur dann von uns zu übernehmen, wenn dies ausdrücklich vereinbart worden ist und die Werkzeuge, Zeichnungen und Modelle unser Eigentum werden.
<G-vec00197-001-s490><bear.übernehmen><en> We will bear any additional shipping costs caused thereby.
<G-vec00197-001-s490><bear.übernehmen><de> Dadurch entstehende zusätzliche Versandkosten werden wir übernehmen.
<G-vec00197-001-s491><bear.übernehmen><en> We also bear the costs for many medical check-ups.
<G-vec00197-001-s491><bear.übernehmen><de> Zudem übernehmen wir die Kosten für eine Vielzahl an Vorsorgeuntersuchungen.
<G-vec00241-002-s316><bear.(sich)_halten><en> After all, learning democracy means examining and analysing past and present happenings and to bear crimes against humanity in remembrance – to make sure that these aspects of our history cannot be repeated.
<G-vec00241-002-s316><bear.(sich)_halten><de> Denn Demokratie lernen heißt, sich mit den Geschehnissen aus Vergangenheit und Gegenwart auseinander zu setzen und auch die Erinnerung an Menschheitsverbrechen wach zu halten - damit sich diese Seiten unserer Geschichte nicht wiederholen können.
<G-vec00241-002-s317><bear.(sich)_halten><en> Potential property buyers should bear this in mind if you are interested in an object in the region: Even the well-known resorts are not self-employed in their planning, but depend on the strategies and decisions of the Administration in Calvià.
<G-vec00241-002-s317><bear.(sich)_halten><de> Diesen Umstand sollten sich potentielle Immobilienkäufer vor Augen halten, wenn Sie sich für ein Objekt in der Region interessieren: Selbst die bekannten Ferienorte sind nicht selbstständig in ihren Planungen, sondern abhängig von den Strategien und Entscheidungen der Administration in Calvià.
<G-vec00241-002-s318><bear.(sich)_halten><en> The difference between stainless steel and the chrome-plated pipe is dramatic: usually thin-walled pipes are chromed, they can not bear the load, and the chrome peels off quickly in damp places and the pipe starts to rust.
<G-vec00241-002-s318><bear.(sich)_halten><de> Der Unterschied zwischen einem Edelstahlrohr und einem verchromten Rohr ist auffallend: Verchromt werden normalerweise dünnwandige Rohre, sie halten keine Belastung aus, außerdem schält sich Chrom in feuchten Räumen schnell ab, und das Rohr beginnt zu rosten.
<G-vec00241-002-s319><bear.(sich)_halten><en> We must always bear this in mind.
<G-vec00241-002-s319><bear.(sich)_halten><de> Das müssen wir uns immer wieder vor Augen halten.
<G-vec00241-002-s320><bear.(sich)_halten><en> And then you hopefully bear it for a day or two and won't feel the need to go and read the blog next door.
<G-vec00241-002-s320><bear.(sich)_halten><de> Und dann halten Sie es hoffentlich einen oder zwei Tage aus und haben kein Bedürfnis, den Nachbarblog zu lesen.
<G-vec00241-002-s321><bear.(sich)_halten><en> •The turntable and the grills can bear a maximum load of 8 kg.
<G-vec00241-002-s321><bear.(sich)_halten><de> •Der Drehteller und die Roste halten einer Höchstbelastung von 8 kg stand.
<G-vec00241-002-s322><bear.(sich)_halten><en> WIN is the ideal choice for all original thinkers, who cannot bear the thought of boring kitchens; it inspires every creative cook in an inimitable way.
<G-vec00241-002-s322><bear.(sich)_halten><de> Für alle geistreichen originellen Typen, die nichts vom täglichen Einerlei in der Küche halten, ist WIN genau die richtige Lösung und inspiriert jeden kreativen Koch auf unverwechselbare Weise.
<G-vec00241-002-s323><bear.(sich)_halten><en> Here, primarily computational speed was of concern, in order to bear comparison with competing software.
<G-vec00241-002-s323><bear.(sich)_halten><de> Sie diente hauptsächlich einer Erhöhung der Rechengeschwindigkeit um mit konkurrierenden Programmen Schritt zu halten.
<G-vec00241-002-s324><bear.(sich)_halten><en> It is always necessary to bear in mind the primacy of spiritual life as the basis of all pastoral planning.
<G-vec00241-002-s324><bear.(sich)_halten><de> Man muss sich als Grundlage für jeden Pastoralplan immer den Primat des geistlichen Lebens vor Augen halten.
<G-vec00241-002-s325><bear.(sich)_halten><en> At the same time, we want to bear in remembrance Erich, our husband and father.
<G-vec00241-002-s325><bear.(sich)_halten><de> Zugleich möchten wir die Erinnerung an Erich, unseren Ehemann und Vater, wach halten.
<G-vec00241-002-s326><bear.(sich)_halten><en> Unfortunately we bear the sad fact of hunger way to seldom in mind.
<G-vec00241-002-s326><bear.(sich)_halten><de> Eine traurige Wahrheit, die wir uns viel zu selten vor Augen halten.
<G-vec00241-002-s327><bear.(sich)_halten><en> Bear right in the Schlosspark (castle park) and cross the bridge over the "Burgsee".
<G-vec00241-002-s327><bear.(sich)_halten><de> Im Schlosspark rechts halten und die Burgseebrücke überqueren.
<G-vec00241-002-s328><bear.(sich)_halten><en> And we try to avoid this of course and bear losses or produce expected losses for fear of losses.
<G-vec00241-002-s328><bear.(sich)_halten><de> “ Und das versuchen wir natürlich zu vermeiden und halten Verluste aus oder produzieren voraussichtliche Verluste aus Angst vor Verlusten.
<G-vec00241-002-s329><bear.(sich)_halten><en> The one thing you have to do is to bear witness to the truth.
<G-vec00241-002-s329><bear.(sich)_halten><de> Gutes tun heißt die Gebote halten, die der Herr uns gegeben hat.
<G-vec00241-002-s330><bear.(sich)_halten><en> Bear right onto Ebury Bridge and then bear left onto Warwick Way.
<G-vec00241-002-s330><bear.(sich)_halten><de> Halten Sie sich rechts, bis sie über die Brücke Ebury Bridge fahren, und halten Sie sich dann links bis zum Warwick Way.
<G-vec00241-002-s331><bear.(sich)_halten><en> But LEDA's strings do bear comparison with the homonymous class string of the C++ standard library; both classes offer nearly the same functionality.
<G-vec00241-002-s331><bear.(sich)_halten><de> Einem Vergleich mit der gleichnamigen Klasse string aus der C++-Standardbibliothek halten sie aber stand; die beiden Klassen besitzen nahezu dieselbe Funktionalität.
<G-vec00241-002-s332><bear.(sich)_halten><en> The other thing to bear in mind, the $45 million of aid from the US is just the tip of the iceberg.
<G-vec00241-002-s332><bear.(sich)_halten><de> Die andere Sache, die man sich vor Augen halten muss, ist, dass die 45-Millionen-USD-Hilfe der USA nur gerade die Spitze des Eisbergs sind.
<G-vec00241-002-s333><bear.(sich)_halten><en> Patients should bear in mind that the chance of a successful implantation diminishes with age, while the cost of further cycles can also be prohibitive for some people.
<G-vec00241-002-s333><bear.(sich)_halten><de> Die Patientinnen sollten sich vor Augen halten, dass die Erfolgsrate für eine IVF mit zunehmendem Alter abnimmt und für manch einen auch die Kosten für zusätzliche Zyklen untragbar sind.
<G-vec00241-002-s334><bear.(sich)_halten><en> We must of course always bear in mind that what concerns us most of all, what is most important, is the development of man himself.
<G-vec00241-002-s334><bear.(sich)_halten><de> Wir müssen uns natürlich immer vor Augen halten, daß das Wesentlichste, das uns interessieren kann an diesem ganzen Erdenwerden, die Entwickelung, die Heranbildung des Menschen selbst ist.
<G-vec00241-002-s035><bear.aushalten><en> The anticipation increases and your daughter can hardly bear to run into the stable and greet the horses.
<G-vec00241-002-s035><bear.aushalten><de> Die Vorfreude steigt und Ihre Tochter kann es kaum noch aushalten, in den Stall zu rennen und die Pferde zu begrüßen.
<G-vec00241-002-s036><bear.aushalten><en> The next day I called back my daughter who was sleeping off a drunk from not being able to bear the thought of her mom and dad separating.
<G-vec00241-002-s036><bear.aushalten><de> “Gleich am nächsten Tag rief ich meine Tochter an, die ihren Rausch ausschlief, den sie sich angetrunken hatte, weil sie es nicht aushalten konnte, dass sich ihre Eltern trennen wollten.
<G-vec00241-002-s038><bear.aushalten><en> Really unbelievably what these tires can bear, some of the thorns are over a centimeter long and go deep into the rubber.
<G-vec00241-002-s038><bear.aushalten><de> Wirklich unglaublich was diese Reifen aushalten, die Stachel sind teilweise über einen Zentimeter lang und stecken mitten im Gummi.
<G-vec00241-002-s039><bear.aushalten><en> Her husband proposed a divorce because he could not bear such persecution, and was afraid that the CCP would take away his job and harm their children.
<G-vec00241-002-s039><bear.aushalten><de> Ihr Ehemann machte den Vorschlag, sich scheiden zu lassen, da er diese Form der Verfolgung nicht aushalten konnte und befürchtete, das die KPCh dafür sorgen könnte, dass er seinen Job verliert und den Kindern etwas angetan werden könnte.
<G-vec00241-002-s042><bear.aushalten><en> You ask him to say something about what happens when you die, what he believes, how you can bear it, when it's hard enough during your life to stick at something, to have a lasting sense of belonging to something, and then just this perspective of darkness, the cold and worms.
<G-vec00241-002-s042><bear.aushalten><de> Du bittest ihn, dir etwas zu sagen zu dem, was da kommt, wenn man stirbt, was er glaubt, wie man das aushalten soll, wenn man es schon zu Lebzeiten kaum schafft, irgendwo dranzubleiben, irgendwo dauerhaft dazuzugehören, und danach nur die Aussicht auf Dunkel, Kälte und Würmer.
<G-vec00241-002-s043><bear.aushalten><en> The yearning was so strong, I simply couldn’t bear it.
<G-vec00241-002-s043><bear.aushalten><de> Die Sehnsucht war so groß, ich konnte das einfach nicht aushalten.
<G-vec00241-002-s044><bear.aushalten><en> I assure you on my honor, dear brother, that each day I pass in this world, I discover, little by little, that the Royal Crown and the title of Majesty do not bear comparison with that of a Christian.
<G-vec00241-002-s044><bear.aushalten><de> Ich versichere Sie, lieber Bruder, bei meiner Ehre, daß ich jeden Tag, den ich in dieser Welt verbringe, mehr und mehr entdecke, daß die Königskrone und der Titel Majestät den Vergleich mit dem eines Christen nicht aushalten.
<G-vec00241-002-s047><bear.aushalten><en> If you can bear to glance away from the food, you’ll find entertainment in the form of a three-piece band, a petting zoo (in cooler months), a wandering magician and a Chinese acrobatic troupe.
<G-vec00241-002-s047><bear.aushalten><de> Wenn Sie es aushalten, Ihren Blick vom Essen abzuwenden, können Sie sich von einer dreiköpfigen Band, einem Streichelzoo (in den kühleren Monaten), einem umherziehenden Zauberkünstler und einer chinesischen Akrobatentruppe unterhalten lassen.
<G-vec00241-002-s048><bear.aushalten><en> Someone practicing in a correct manner thus will also have to bear the difficult balancing act between the small reality and the big truth of his sacred part (when it has been searched consciously or manifests itself spontaneously).
<G-vec00241-002-s048><bear.aushalten><de> Ein korrekt Praktizierender wird also immer den schwierigen Spagat zwischen der kleinen Realität und der großen Wirklichkeit seines heiligen Anteils (wo dieser bewusst gesucht wird oder sich ebenfalls bereits spontan herstellt) aushalten müssen.
<G-vec00241-002-s049><bear.aushalten><en> One of the practitioners could not bear the physical torture and divulged my name along with names of several other practitioners.
<G-vec00241-002-s049><bear.aushalten><de> Einer der Praktizierenden konnte die physischen Folterungen nicht aushalten und verriet meinen Namen, zusammen mit Namen von mehreren anderen Praktizierenden.
<G-vec00241-002-s050><bear.aushalten><en> 5For this reason, when I could bear it no longer, I sent to learn about your faith, for fear that somehow the tempter had tempted you and our labor would be in vain.
<G-vec00241-002-s050><bear.aushalten><de> 5Darum auch, da ich es nicht länger aushalten konnte, sandte ich, um euren Glauben zu erfahren, ob nicht etwa der Versucher euch versucht habe und unsere Arbeit vergeblich gewesen sei.
<G-vec00241-002-s051><bear.aushalten><en> We are going to have to bear with each other for one and a half days now.
<G-vec00241-002-s051><bear.aushalten><de> Anderthalb Tage werden wir es jetzt gemeinsam miteinander aushalten müssen.
<G-vec00241-002-s052><bear.aushalten><en> If you study mathematics or biology or physics or history or sociology – then you have to grit your teeth at times, i.e. you have to bear a bit of pressure at times.
<G-vec00241-002-s052><bear.aushalten><de> Wenn du Mathematik studierst oder Biologie oder Physik oder Geschichte oder Soziologie – dann musst du auch mal die Zähne zusammenbeißen, d.h. du musst auch mal ein bisschen Druck aushalten.
<G-vec00241-002-s053><bear.aushalten><en> In a farewell letter, he said he could no longer bear the financial pressure placed on him by the tax authorities.
<G-vec00241-002-s053><bear.aushalten><de> In einem Abschiedsbrief schrieb er, er könne den finanziellen Druck, den die Steuerbehörde auf ihn ausübe, nicht mehr aushalten.
<G-vec00241-002-s073><bear.bedenken><en> You should bear in mind that in Armed Assault you’ll have a large amount of artillery available, with excellent animations and 3D optics, which will make this adventure an exciting fiction.
<G-vec00241-002-s073><bear.bedenken><de> Sie sollten bedenken, dass Ihnen in Armed Assault eine große Menge von Artillerie zur Verfügung steht, hervorragende Animationen und 3D-Optik, die dieses Abenteuer zu einer spannenden Fiktion machen.
<G-vec00241-002-s074><bear.bedenken><en> However, it is important to bear in mind that the treatment may not be effective at protecting against all types of malaria.
<G-vec00241-002-s074><bear.bedenken><de> Allerdings ist es wichtig zu bedenken, dass die Behandlung nicht gegen alle Arten von Malaria wirksam schützen kann.
<G-vec00241-002-s075><bear.bedenken><en> Please bear in mind that transmitting data over the Internet can be subject to security risks.
<G-vec00241-002-s075><bear.bedenken><de> Bedenken Sie, dass die Datenübertragung im Internet grundsätzlich mit Sicherheitslücken bedacht sein kann.
<G-vec00241-002-s076><bear.bedenken><en> Please bear this in mind when using these options.
<G-vec00241-002-s076><bear.bedenken><de> Bitte bedenken Sie dies bei der Nutzung dieser Angebote.
<G-vec00241-002-s077><bear.bedenken><en> Bear in mind that you are in the mountains, so you will need lots of energy for your day outdoors.
<G-vec00241-002-s077><bear.bedenken><de> Bedenken Sie auch, dass Sie hier in den Bergen sind, also viel Energie für Ihre Lieblingssportarten benötigen.
<G-vec00241-002-s078><bear.bedenken><en> Particularly fastidious tourists should bear in mind that dogs for Vietnamese restaurants aren’t caught in the streets.
<G-vec00241-002-s078><bear.bedenken><de> Besonders anspruchsvolle Touristen sollten bedenken, dass Hunde für vietnamesische Restaurants nicht auf der Straße gefangen werden.
<G-vec00241-002-s079><bear.bedenken><en> If you want to go on your own, you must bear in mind that there are no Alpine Club maps or similar for the Carpathians.
<G-vec00241-002-s079><bear.bedenken><de> Wer auf eigene Faust losziehen möchte muss bedenken, es gibt keine Alpenvereinskarten oder vergleichbares für die Karpaten.
<G-vec00241-002-s080><bear.bedenken><en> With some Asian dating sites you will need to bear in mind that English may not be a first language so this can be doubly pertinent.
<G-vec00241-002-s080><bear.bedenken><de> Mit einigen asiatischen Datierung Websites, müssen Sie bedenken, dass Englisch nicht eine erste Sprache sein kann, so dass diese doppelt relevant sein kann.
<G-vec00241-002-s081><bear.bedenken><en> You need to bear in mind that taking high quality and powerful medicines is essential in order to attain your preferred objectives.
<G-vec00241-002-s081><bear.bedenken><de> Sie müssen bedenken, dass Top-Qualität zu nehmen und auch starke Medikamente notwendig ist, um Ihre bevorzugten Ziele zu erreichen.
<G-vec00241-002-s082><bear.bedenken><en> During the game you’ll encounter more than 40 types of automated beings, all of them with different abilities that you’ll have to bear in mind when planning how to destroy them.
<G-vec00241-002-s082><bear.bedenken><de> Während des Spiels werden Sie mehr als 40 Arten von automatisierten Wesen begegnen, die alle mit unterschiedlichen Fähigkeiten ausgestattet sind, die Sie bei der Planung der Zerstörung bedenken müssen.
<G-vec00241-002-s083><bear.bedenken><en> It is essential to bear in mind that warts can appear anywhere on the body.
<G-vec00241-002-s083><bear.bedenken><de> Es ist notwendig, zu bedenken, dass Warzen überall am Körper auftreten könnten.
<G-vec00241-002-s084><bear.bedenken><en> Most lenders only require approximately 2% of the total loan, but bear in mind that you will still be required to pay some of the associated costs, such as recording fees and appraisal and compliance costs.
<G-vec00241-002-s084><bear.bedenken><de> Die meisten kreditgebenden Stellen benötigen nur ungefähr 2% des Gesamtdarlehens, aber bedenken, daß Sie noch angefordert werden, einige der verbundenen Kosten, wie Eintragungsgebühren und Schätzung und abgeführte Mehrwertsteuern zu zahlen.
<G-vec00241-002-s085><bear.bedenken><en> However, if you decide to do this on your own, bear in mind that the process of finding the right place can be very frustrating and time consuming.
<G-vec00241-002-s085><bear.bedenken><de> Wenn Sie sich allerdings entscheiden, dies auf eigene Faust zu tun, bedenken Sie, dass der Prozess der Suche nach dem richtigen Objekt sehr frustrierend und zeitraubend sein kann.
<G-vec00241-002-s086><bear.bedenken><en> You humans must always bear in mind that, at the time of the end, messengers will descend from above who will not succumb to his artful temptations, who are only receptive for the pure truth from above, which would never give in to his whisperings and thereby make themselves unsuitable for the receipt of the pure truth....
<G-vec00241-002-s086><bear.bedenken><de> Das müsset ihr Menschen immer bedenken, daß zur Zeit des Endes Boten von oben herniedersteigen, die seinen Verführungskünsten nicht erliegen, die nur für Mich, für die reine Wahrheit von oben, empfänglich sind, die niemals seinen Einflüsterungen nachgeben und sich selbst dadurch untauglich machen würden für den Empfang der reinen Wahrheit....
<G-vec00241-002-s087><bear.bedenken><en> It is just as crucial to bear in mind that warts are infectious.
<G-vec00241-002-s087><bear.bedenken><de> Es ist ebenso wichtig zu bedenken, dass Warzen sind ansteckend.
<G-vec00241-002-s088><bear.bedenken><en> It’s important to bear in mind that this happens not only to the animals we have been discussing, such as elephants, bears, and big cats, but also to many other animals who live in circuses.
<G-vec00241-002-s088><bear.bedenken><de> Es ist wichtig zu bedenken, dass das nicht nur auf die oben genannten Tiere, zum Beispiel Elefanten, Bären und Großkatzen, zutrifft, sondern auch auf viele andere Tiere, die in Zirkussen leben.
<G-vec00241-002-s089><bear.bedenken><en> And although the various external forms demonstrate their opposition to God.... God has nevertheless seized the spirit in order to guide it to its gradual ascent in the law of compulsion. That itself should teach you humans to view every work of creation with spiritual eyes, and you should bear in mind that God truly knows many things which are still hidden from you humans, hence you should not judge prematurely by criticising God's creations, which you are really not entitled to do.
<G-vec00241-002-s089><bear.bedenken><de> Und ob auch verschiedene Außenformen die Widersetzlichkeit gegen Gott verraten.... daß Gott aber das Geistige dennoch erfaßt hat, um es langsam im Mußgesetz zur Höhe zu führen, das allein schon soll euch Menschen jegliches Schöpfungswerk mit geistigen Augen ansehen lehren, und ihr sollt bedenken, daß Gott wahrlich um vieles weiß, was euch Menschen noch verborgen ist, und daß ihr darum nicht vorzeitig urteilen sollet, indem ihr an Schöpfungen Gottes Kritik übt, zu der ihr wahrlich nicht berechtigt seid.
<G-vec00241-002-s090><bear.bedenken><en> Bear in mind that the Swiss National Bank also introduced a kind of quantitative easing and expanded its balance sheet – long before we did, by the way.
<G-vec00241-002-s090><bear.bedenken><de> Bedenken Sie, auch die SNB hat eine Art von Quantitative Easing eingeführt und ihre Bilanz ausgeweitet – lange vor uns übrigens.
<G-vec00241-002-s091><bear.bedenken><en> And because you can already achieve on earth that your soul will be bright and translucent at the time of its passing away from earth you shall also humbly and patiently endure all suffering on earth.... you always ought to bear in mind that it is only beneficial for the maturity of your soul, you should not try to evade all affliction and always pray ‘Father, Thy will be done....’ For I know why I let you walk the path of suffering and why I spoke the Words ‘Follow Me....’ If you always try to imagine that I have walked the path before you, which has been so much harder and more sorrowful than yours, then for love of Me you should accept everything I send or allow to happen to you, for that is the light cross you have to bear in your earthly life, which only ever benefits your soul....
<G-vec00241-002-s091><bear.bedenken><de> Und weil ihr es auf Erden schon erreichen könnet, daß eure Seele hell und lichtdurchlässig ist bei ihrem Abscheiden von der Erde, darum sollet ihr auch alles Leid auf Erden ergeben und geduldig tragen.... ihr sollt immer bedenken, daß es nur förderlich für eure Seelenreife ist, ihr sollt euch nicht aller Leiden zu entledigen suchen, ihr sollt immer beten: „Vater, Dein Wille geschehe....“ Denn Ich weiß es, warum Ich euch den Weg des Leidens gehen lasse und warum Ich die Worte gesprochen habe: „Folget Mir nach....“ Wenn ihr immer euch vorzustellen suchet, daß Ich euch den Weg vorangegangen bin, der um vieles schwerer und leidvoller gewesen ist als der eure, dann sollet ihr aus Liebe zu Mir alles auf euch nehmen, was Ich über euch sende oder zulasse, denn es ist das kleine Kreuzlein, das euch zu tragen auferlegt wurde für euer Erdenleben und das immer nur heilsam ist für eure Seele....
<G-vec00241-002-s092><bear.berücksichtigen><en> Bear in mind that the insurance will not cover incidents caused by unauthorized drivers.
<G-vec00241-002-s092><bear.berücksichtigen><de> Berücksichtigen Sie bitte, dass diese Versicherung keine Ereignisse abdeckt, die von nicht autorisierten Fahrern verursacht wurden.
<G-vec00241-002-s093><bear.berücksichtigen><en> In carrying out these tasks, the committee must bear in mind the objective of a high level of employment in the formulation of EU policies.
<G-vec00241-002-s093><bear.berücksichtigen><de> Der Ausschuss bemüht sich bei der Wahrnehmung seiner Aufgaben, bei der Festlegung der EU-Politiken das Ziel eines hohen Beschäftigungsniveaus zu berücksichtigen.
<G-vec00241-002-s094><bear.berücksichtigen><en> Handy: bear in mind that one place might be suitable for a round stand, the other for a straight stand and the third for a corner stand.
<G-vec00241-002-s094><bear.berücksichtigen><de> Praktisch: Berücksichtigen Sie, dass ein Standort für einen runden Stand, ein zweiter für einen geraden Stand und ein dritter für einen Eckstand geeignet ist.
<G-vec00241-002-s095><bear.berücksichtigen><en> Before they reach for their checkbooks, however, they need to bear in mind that they can have no guarantees that they'll get their data back.
<G-vec00241-002-s095><bear.berücksichtigen><de> Bevor sie jedoch nach ihren Scheckbüchern greifen, müssen sie berücksichtigen, dass sie keine Garantie dafür haben können, dass sie ihre Daten zurückerhalten.
<G-vec00241-002-s096><bear.berücksichtigen><en> Warning The consumer must bear in mind that in case an administrative or legal authority determines that the reversal does not apply, the consumer shall be liable for all costs incurred as a result of requesting the reversal.
<G-vec00241-002-s096><bear.berücksichtigen><de> Hinweis: Der Verbraucher sollte berücksichtigen, dass wenn eine Verwaltungsbehörde oder ein Gericht beschließt, dass die Rückübertragung nicht rechtens ist, der Verbraucher für alle Kosten verantwortlich ist, die aus dem Antrag auf Rückübertragung entstehen könnten.
<G-vec00241-002-s097><bear.berücksichtigen><en> Bear in mind that you will need to adjust the settings of each browser and computer you use.
<G-vec00241-002-s097><bear.berücksichtigen><de> Berücksichtigen Sie, dass die Einstellungen für jeden Browser und für jedes Gerät separat angepasst werden müssen.
<G-vec00241-002-s098><bear.berücksichtigen><en> As you all know, for a realistic assessment of the labour market situation, it is important to bear in mind that unemployment in the euro area is, predominantly, of a structural rather than a conjunctural nature.
<G-vec00241-002-s098><bear.berücksichtigen><de> Um zu einer realistischen Einschätzung der Lage am Arbeitsmarkt zu kommen, ist - wie Sie alle wissen - zu berücksichtigen, daß Arbeitslosigkeit im Euro-Währungsgebiet in erster Linie strukturell, nicht konjunkturell bedingt ist.
<G-vec00241-002-s099><bear.berücksichtigen><en> 1 When different countries’ sovereign debt is compared, it is necessary to bear in mind that national economies vary in size.
<G-vec00241-002-s099><bear.berücksichtigen><de> 1 Beim Vergleich der Staatsverschuldung verschiedener Länder muss man berücksichtigen, dass die Volkswirtschaften verschieden groß sind.
<G-vec00241-002-s100><bear.berücksichtigen><en> It is important to bear in mind that we are not trying to understand the various forms that an ism takes, such as the doctrines of Buddhism or the philosophical views that define liberalism.
<G-vec00241-002-s100><bear.berücksichtigen><de> Hier ist es wichtig zu berücksichtigen, dass wir nicht versuchen die verschiedenen Formen der Ismen zu verstehen, wie zum Beispiel die Lehren des Buddhismus oder die philosophischen Sichtweisen die den Liberalismus definieren.
<G-vec00241-002-s101><bear.berücksichtigen><en> Please bear this in mind when deciding what information to publish on your profile.
<G-vec00241-002-s101><bear.berücksichtigen><de> Wir möchten dich bitten, dies bei der Entscheidung, welche Daten du auf deinem Profil offenlegst, zu berücksichtigen.
<G-vec00241-002-s102><bear.berücksichtigen><en> Pointing this out is important because it enables us to bear in mind a cultural and spiritual approach that is indispensable for understanding Isidore's personality.
<G-vec00241-002-s102><bear.berücksichtigen><de> Dieser Hinweis ist wichtig, weil er ermöglicht, eine für das Verständnis der Persönlichkeit Isidors unerläßliche kulturelle und spirituelle Annäherung zu berücksichtigen.
<G-vec00241-002-s103><bear.berücksichtigen><en> For Burundi, the call for early action may come late – yet, in similar cases the international community should bear in mind that prioritizing stability at the expense of democratic norms might not only have direct negative effects on democracy, but also jeopardize stability in the long-run.
<G-vec00241-002-s103><bear.berücksichtigen><de> Für Burundi mag der Ruf für frühzeitiges Handeln zu spät kommen – doch in ähnlichen Fällen sollte die internationale Gemeinschaft berücksichtigen, dass die Priorisierung von Stabilität auf Kosten der Einhaltung demokratischer Normen nicht nur unmittelbar negative Wirkungen für die Demokratie hat, sondern langfristig auch die Stabilität gefährden kann.
<G-vec00241-002-s104><bear.berücksichtigen><en> We must bear in mind that we are in an area of Atlantic climate where we can see an increased risk of rainfall for that season.
<G-vec00241-002-s104><bear.berücksichtigen><de> Wir sollten berücksichtigen, dass wir uns in einer Gegend mit Seeklima befinden, was die Niederschlagswahrscheinlichkeit für diese Jahreszeit erhöhen kann.
<G-vec00241-002-s105><bear.berücksichtigen><en> One has to bear in mind that the product gets more sensitive the higher the content of unsaturated fatty acids is.
<G-vec00241-002-s105><bear.berücksichtigen><de> Dabei bleibt jedoch zu berücksichtigen, dass das Produkt empfindlicher wird, je höher der Anteil an ungesättigten Fettsäuren ist.
<G-vec00241-002-s106><bear.berücksichtigen><en> Should there be additional wishes or requests, we will do our best to bear those in mind insofar possible.
<G-vec00241-002-s106><bear.berücksichtigen><de> Sollte es dennoch Wünsche oder Einschränkungen geben, werden wir diese, soweit es in unseren Möglichkeiten liegt, natürlich gerne berücksichtigen.
<G-vec00241-002-s107><bear.berücksichtigen><en> If you decide not to preserve the file structure, you should bear in mind that all the files that you've selected to restore will be restored to a single folder (with no subfolders).
<G-vec00241-002-s107><bear.berücksichtigen><de> Wenn Sie die Dateistruktur nicht beibehalten möchten, sollten Sie berücksichtigen, dass alle Dateien, die Sie zur Wiederherstellung ausgewählt haben, in einem einzigen Ordner (ohne Unterordner) wiederhergestellt werden.
<G-vec00241-002-s108><bear.berücksichtigen><en> I can only advise those interested in a franchise to bear this question in mind when comparing systems.
<G-vec00241-002-s108><bear.berücksichtigen><de> Ich kann Franchise-Interessenten nur raten, diese Frage beim Systemvergleich zu berücksichtigen.
<G-vec00241-002-s109><bear.berücksichtigen><en> Affected users should bear in mind that the leak doesn't pose an immediate threat to their accounts.
<G-vec00241-002-s109><bear.berücksichtigen><de> Betroffene Benutzer sollten berücksichtigen, dass das Leck keine unmittelbare Bedrohung für ihre Konten darstellt.
<G-vec00241-002-s129><bear.bringen><en> If a man remains in me and I in him, he will bear much fruit; apart from me you can do nothing.
<G-vec00241-002-s129><bear.bringen><de> Wer in mir bleibt und ich in ihm, der bringt viel Frucht; denn getrennt von mir könnt ihr nichts tun.
<G-vec00241-002-s130><bear.bringen><en> You should bear in mind that buying Christmas ornaments over the internet provides a different shopping experience to buying in-store.
<G-vec00241-002-s130><bear.bringen><de> Sie müssen bedenken, dass der Kauf von Weihnachtsdekoration über Internet eine andere Geschäftserfahrung mit sich bringt, als der Kauf in einem physischen Laden.
<G-vec00241-002-s131><bear.bringen><en> In the sutra ‚Tune of Brahma’ one finds ten points, which describe the karmic advantages that such actions bear.
<G-vec00241-002-s131><bear.bringen><de> Im Sutra „Tune of Brahma“ finden sich zehn Punkte, die erklären, welche karmischen Vorteile eine solche Handlung mit sich bringt.
<G-vec00241-002-s132><bear.bringen><en> The potential dangers of high-powered and bundled laser radiation are well known. But even modern LED lighting can bear dangers for the human body.
<G-vec00241-002-s132><bear.bringen><de> Bekannt sind die Gefahrenpotentiale von hochenergetischer und gebündelter Strahlung bei Laserprodukten, doch auch moderne LED-Beleuchtung bringt Gefahren für den menschlichen Körper mit sich.
<G-vec00241-002-s133><bear.bringen><en> 2 Every branch in me that does not bear fruit he takes away, and every one that bears fruit he cleanses, that it may bear more fruit.
<G-vec00241-002-s133><bear.bringen><de> 2 Jede Rebe an mir, die keine Frucht bringt, schneidet er ab und jede Rebe, die Frucht bringt, reinigt er, damit sie mehr Frucht bringt.
<G-vec00241-002-s134><bear.bringen><en> John 15:8: Herein is my Father glorified, that ye bear much fruit; so shall ye be my disciples.
<G-vec00241-002-s134><bear.bringen><de> 8 Hierin wird5 mein VaterVater verherrlicht, dass ihr viel Frucht bringt, und ihr werdet meine6 JüngerJünger werden.
<G-vec00241-002-s136><bear.bringen><en> If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing.
<G-vec00241-002-s136><bear.bringen><de> Wer in mir bleibt und ich in ihm, der bringt viel Frucht; denn ohne mich könnt ihr nichts tun.
<G-vec00241-002-s137><bear.bringen><en> However, faith is a gift that is given to us to be shared; it is a talent received so that it may bear fruit; it is a light that must never be hidden, but must illuminate the whole house.
<G-vec00241-002-s137><bear.bringen><de> Der Glaube ist aber ein Geschenk, das uns gegeben wird, damit wir es teilen; er ist ein Talent, das wir empfangen haben, damit es Frucht bringt; er ist ein Licht, das nicht verborgen bleiben darf, sondern das ganze Haus erleuchten soll.
<G-vec00241-002-s138><bear.bringen><en> A good tree cannot bear bad fruit, and a bad tree cannot bear good fruit.
<G-vec00241-002-s138><bear.bringen><de> 18 Es ist nicht möglich, dass ein guter Baum schlechte Früchte bringt und auch nicht, dass ein schlechter Baum gute Früchte bringt.
<G-vec00241-002-s140><bear.bringen><en> 8My Father is glorified by this, that you bear much fruit, and so prove to be My disciples.
<G-vec00241-002-s140><bear.bringen><de> 8Wenn ihr viel Frucht bringt und euch so als meine Jünger erweist, wird die Herrlichkeit meines Vaters sichtbar.
<G-vec00241-002-s142><bear.bringen><en> Every branch in Me that does not bear fruit, He takes away; and every branch that bears fruit, He cleanses it so that it may bear more fruit.
<G-vec00241-002-s142><bear.bringen><de> Jede Rebe an mir, die keine Frucht bringt, nimmt er weg; jede aber, die Frucht bringt, reinigt er, damit sie mehr Frucht bringt.
<G-vec00241-002-s145><bear.bringen><en> The Fanes-Sennes-Braies Nature Park hut is ideal for all ages: a museum which recounts the rise of the Dolomites and the exciting story of the Ursus ladinicus, an ancient indigenous cave bear species.
<G-vec00241-002-s145><bear.bringen><de> Wandern und die Natur von ihrer schönsten Seite erleben: Ideal für Jung und Alt ist das Naturparkhaus Fanes-Sennes-Prags, ein Museum das die Entstehung der Dolomiten oder Spannendes über den Höhlenbären von Conturines näher bringt.
<G-vec00241-002-s147><bear.bringen><en> 2 He takes away every branch in me that doesn’t bear fruit, and He prunes every branch that bears fruit, so that it may bear more fruit.
<G-vec00241-002-s147><bear.bringen><de> 2 Eine jeglich Rebe an mir, die nicht Frucht bringt, wird er wegnehmen; und eine jegliche, die da Frucht bringt, wird er reinigen, daß sie mehr Frucht bringe.
<G-vec00241-002-s167><bear.bären><en> Then check out our monthly Doll and Bear auction.
<G-vec00241-002-s167><bear.bären><de> Dann schauen Sie einmal in unserer monatlichen Puppen und Bären Auktion vorbei.
<G-vec00241-002-s168><bear.bären><en> Contact Us Information Pack A hugely emotional day at Nanning Bear Farm today - as a bear suspected of having liver cancer was dramatically given the all clear.
<G-vec00241-002-s168><bear.bären><de> Heute war ein sehr emotionaler Tag auf der Nanning Farm, als es für einen Bären der unter Verdacht stand Leberkrebs zu haben, Entwarnung gab.
<G-vec00241-002-s169><bear.bären><en> There are no more polar bear shows anymore and the music was restrained and no longer disturbing.
<G-vec00241-002-s169><bear.bären><de> Bären gibt es nicht mehr und auch die Musikberieselung ist dezent und nicht mehr störend.
<G-vec00241-002-s170><bear.bären><en> Frog - Bear's girlfriend.
<G-vec00241-002-s170><bear.bären><de> Frog - Bären Freundin.
<G-vec00241-002-s171><bear.bären><en> So many of these health issues have either only rarely or never been reported in any bear species.
<G-vec00241-002-s171><bear.bären><de> Viele dieser Krankheiten wurden kaum oder noch nie bei Bären gefunden.
<G-vec00241-002-s172><bear.bären><en> 5 And, behold, another beast, a second, like to a bear; and it was raised up on one side, and three ribs were in its mouth between its teeth: and they said thus unto it, Arise, devour much flesh.
<G-vec00241-002-s172><bear.bären><de> 5Und siehe, ein anderes Tier, das zweite, war gleich einem Bären und war auf der einen Seite aufgerichtet und hatte in seinem Maul zwischen seinen Zähnen drei Rippen.
<G-vec00241-002-s173><bear.bären><en> The Golden Bear is the highest prize awarded for the best film at the Berlinale.
<G-vec00241-002-s173><bear.bären><de> Den Goldenen Bären ist die höchste Auszeichnung für den besten Film auf der Berlinale ausgezeichnet.
<G-vec00241-002-s174><bear.bären><en> They are reminiscent of those of a small bear because the badger is also a plantigrade.
<G-vec00241-002-s174><bear.bären><de> Sie erinnern, (da es sich um einen Sohlengänger handelt) an die eines kleinen Bären.
<G-vec00241-002-s175><bear.bären><en> The Majestic Forest game can also do this and impress us with beautiful symbols of the bear, the wolf, the fox, the deer, and the stone bench.
<G-vec00241-002-s175><bear.bären><de> Auf den Walzen des Spielautomaten Majestic Forest sehen Sie die Kartensymbole, die Bären, die Wolfe, die Füchse und die Hirsche.
<G-vec00241-002-s176><bear.bären><en> Many visitors come to the Park to see a Moose or a bear.
<G-vec00241-002-s176><bear.bären><de> Viele Besucher kommen in den Park um einen Elch oder einen Bären zu sehen.
<G-vec00241-002-s177><bear.bären><en> The arm of the bear in "Marilyn and Russian bear" is die-cut and movable by means of a string attached to the reverse.
<G-vec00241-002-s177><bear.bären><de> Der Arm des Bären in "Marilyn und russischer Bär" ist ausgestanzt und beweglich montiert.
<G-vec00241-002-s178><bear.bären><en> Juliette Binoche won a Berlinale Silver Bear, a BAFTA and an Academy Award in 1997 for her role as the French-Canadian nurse Hana in The English Patient (1996, dir: Anthony Minghella).
<G-vec00241-002-s178><bear.bären><de> Den Silbernen Bären, den BAFTA und den Oscar gewann Juliette Binoche 1997 für ihre Darstellung der frankokanadischen Krankenschwester Hana Patient (Der englische Patient, 1996, R: Anthony Minghella).
<G-vec00241-002-s179><bear.bären><en> In the densely forested, uninhabited valleys you have excellent opportunities to spot wild geese, beavers, eagles, elk, bear, and moose.
<G-vec00241-002-s179><bear.bären><de> Die bewaldeten Flusstäler sind unbewohnt, Sie haben ausgezeichnete Gelegenheiten Wildgänse, Adler, Biber, Bären und Elche zu beobachten.
<G-vec00241-002-s180><bear.bären><en> Illustrator Dick Bruna designed the logo with iconic bear and various posters.
<G-vec00241-002-s180><bear.bären><de> Illustrator Dick Bruna gestaltete das Logo mit einem ikonischen Bären und verschiedenen Postern.
<G-vec00241-002-s181><bear.bären><en> We pull the thread, pull it off (make a sharp movement, as if cutting a thread) And put it in the needle (picture the action) We'll sew the shirt to the bear (make imaginary wide stitches, as if sewing) And sew it panties (shake your hands, imitating the sewn clothes).
<G-vec00241-002-s181><bear.bären><de> Wir ziehen den Faden, ziehen ihn ab (machen eine scharfe Bewegung, als ob wir einen Faden schneiden) Und stecke ihn in die Nadel (Bild der Handlung) Wir werden das Hemd zum Bären nähen (imaginäre, breite Stiche nähen) und Höschen nähen (Hände schütteln, genähte Kleidung nachmachen).
<G-vec00241-002-s182><bear.bären><en> I think the egg and the bear with glasses are very cute... okay, actually all four are cute! But I wanted to continue working at them!
<G-vec00241-002-s182><bear.bären><de> Ich fand gerade das Ei und den Bären mit der Brille sehr putzig... ok, eigentlich alle Vier... xD Ich wollte weiter an den Süßen arbeiten...
<G-vec00241-002-s183><bear.bären><en> Keep the Regime economy-friendly, yet do not hesitate to wreck it with a bear if you are relatively Depression-resistant.
<G-vec00241-002-s183><bear.bären><de> Halte das Regime wirtschaftsfreundlich, aber zögere auch nicht, die Wirtschaft mit einem Bären zu zerstören, falls du selbst relativ resistent gegen eine Depression bist.
<G-vec00241-002-s184><bear.bären><en> Bear The paw of the bear is a symbol of strength and serenity.
<G-vec00241-002-s184><bear.bären><de> Bär Die Tatze des Bären ist ein Symbol für Kraft und Gelassenheit.
<G-vec00241-002-s185><bear.bären><en> As much as I like these furry creatures I don´t want to end up as bear´s food.
<G-vec00241-002-s185><bear.bären><de> Ich mag Bären sehr, möchte aber ungern als deren Futter enden.
<G-vec00241-002-s221><bear.denken><en> Bear in mind that we're talking about passwords that are between 7 and 13 characters long and consist of letters and numbers.
<G-vec00241-002-s221><bear.denken><de> Denken Sie daran, dass es sich um Passwörter handelt, die zwischen 7 und 13 Zeichen lang sind und aus Buchstaben und Zahlen bestehen.
<G-vec00241-002-s222><bear.denken><en> Bear in mind that only authentic HGH can give you with the results that you truly expect.
<G-vec00241-002-s222><bear.denken><de> Denken Sie daran, die nur authentische HGH Ihnen die Auswirkungen liefern kann, die Sie wirklich erwarten.
<G-vec00241-002-s223><bear.denken><en> Bear in mind also that fetching a healthy cow takes on average 2.07 minutes, whereas an attention cow requires 3.54 minutes to fetch.
<G-vec00241-002-s223><bear.denken><de> Denken Sie auch daran, dass das Holen einer gesunden Kuh im Durchschnitt 2,07 Minuten dauert, während es 3,54 Minuten dauert, eine Problemkuh zu holen.
<G-vec00241-002-s224><bear.denken><en> But bear in mind – more successes mean less winning amount.
<G-vec00241-002-s224><bear.denken><de> Aber denken Sie daran – mehr Erfolg bedeuten weniger Gewinn Betrag.
<G-vec00241-002-s225><bear.denken><en> Bear in mind that we do not recommend you install this release on OSes other than the specified ones even though other platforms might also be suitable.
<G-vec00241-002-s225><bear.denken><de> Denken Sie daran, dass wir empfehlen Sie nicht, diese Version auf andere als die angegebenen Betriebssysteme zu installieren, auch wenn andere Plattformen könnten auch geeignet sein.
<G-vec00241-002-s226><bear.denken><en> Some would say for as long as you can, so bear in mind that it's a big and busy city with plenty to see and do.
<G-vec00241-002-s226><bear.denken><de> Manche würden sagen: Bleib so lange es geht!, also denken Sie daran: Es ist eine große Stadt, in der viel zu sehen und zu tun ist.
<G-vec00241-002-s228><bear.denken><en> Bear in mind that it’s not just the patient who benefits from this approach to imaging.
<G-vec00241-002-s228><bear.denken><de> Denken Sie daran, dass nicht nur der Patient von diesem Ansatz für die Bildgebung profitiert.
<G-vec00241-002-s229><bear.denken><en> Bear in mind what type of seat you've reserve before ordering food.
<G-vec00241-002-s229><bear.denken><de> Denken Sie daran, welche Sitzgelegenheit Sie reservieren, bevor Sie ihr Essen bestellen.
<G-vec00241-002-s230><bear.denken><en> Bear in mind that this details must never change beneficial medical guidance from your physician.
<G-vec00241-002-s230><bear.denken><de> Denken Sie daran, dass diese Informationen nie vorteilhaft klinische Anleitung von Ihrem Arzt ersetzen.
<G-vec00241-002-s233><bear.denken><en> However, bear in mind that such applications like this adware are often used by cyber criminals.
<G-vec00241-002-s233><bear.denken><de> Aber denken Sie daran, dass solche Anwendungen wie diese Adware häufig von Cyber-Kriminellen verwendet werden.
<G-vec00241-002-s234><bear.denken><en> Bear in mind that if you do not speak Portuguese, it could as well be an issue to have the best car rental for your holidays.
<G-vec00241-002-s234><bear.denken><de> Denken Sie daran, dass Wenn Sie nicht Portuguese sprechen, könnte es genauso gut ein Problem sein, die beste Autovermietung für Ihren Urlaub zu haben.
<G-vec00241-002-s235><bear.denken><en> Bear in mind that we are in the Christian era.
<G-vec00241-002-s235><bear.denken><de> Denken Sie daran, dass wir uns in der christlichen Zeit befinden.
<G-vec00241-002-s236><bear.denken><en> If you plan to take up residence in Switzerland after marrying or registering a partnership, bear in mind that your foreign spouse or partner will need a residence permit and may require an entry visa.
<G-vec00241-002-s236><bear.denken><de> Falls Sie beabsichtigen, nach der Heirat oder der Eintragung Ihrer Partnerschaft in der Schweiz Wohnsitz zu nehmen, denken Sie daran, dass Ihr ausländischer Partner eine Aufenthaltsgenehmigung benötigt und sich möglicherweise ein Einreisevisum beschaffen muss.
<G-vec00241-002-s237><bear.denken><en> Bear in mind that if you do not speak German, it could as well be an issue to have the best car rental for your holidays.
<G-vec00241-002-s237><bear.denken><de> Denken Sie daran, dass Wenn Sie nicht German sprechen, könnte es genauso gut ein Problem sein, die beste Autovermietung für Ihren Urlaub zu haben.
<G-vec00241-002-s238><bear.denken><en> Bear in mind; the real purpose of government is, always and everywhere, to enable the few to exploit the many.
<G-vec00241-002-s238><bear.denken><de> Denken Sie daran; Der eigentliche Zweck der Regierung besteht immer und überall darin, den Einzelnen in die Lage zu versetzen, die vielen auszunutzen.
<G-vec00241-002-s239><bear.denken><en> Bear in mind that when you get two bottles you wll get a third cost-free that suggests 3 month supply for you.
<G-vec00241-002-s239><bear.denken><de> Denken Sie daran, dass, wenn Sie zwei Flaschen bestellen Sie wll ein drittes kostenlos erhalten, die für Sie 3 Monate Versorgung anzeigt.
<G-vec00241-002-s240><bear.ertragen><en> It means risking being wronged yourself, knowing that in Christ you can bear all things.
<G-vec00241-002-s240><bear.ertragen><de> Sie bedeutet das Risiko einzugehen, dass dir Unrecht geschehen könnte, aber im Wissen, dass du in Christus alles ertragen kannst.
<G-vec00241-002-s241><bear.ertragen><en> It consists of what they call pre-delivery exercise to help pregnant women to be able to control themselves and bear the birth pains during delivery and to quickly regain the smooth functioning of their body systems after delivery.
<G-vec00241-002-s241><bear.ertragen><de> Es handelt sich um so gennante Sportarten, die den Frauen bei der Entbindung helfen sollen, sich zu beherrschen, und die Schmerzen zu ertragen, und schnell den guten Lauf des Körpers nach der Entbindung wieder zu finden.
<G-vec00241-002-s242><bear.ertragen><en> So, as the soul had to shape itself first, to now enliven the human body – as its present composition is completely different from the stages before where the course through the countless single beings brought about the unification in inconceivable long time to now embody itself in man – likewise the soul must now try to reach the state in earth existence that it can leave the dark stay in matter and rise to light regions to be able to bear exactly that fullness of light which is the epitome of happiness.
<G-vec00241-002-s242><bear.ertragen><de> So, wie sich die Seele zuvor bilden musste, um nun den menschlichen Körper zu beleben - wie ihre jetzige Beschaffenheit völlig unterschiedlich ist von den Vorstadien, wo der Gang durch unzählige Einzelwesen erst in undenklich langer Zeit die Einigung zustande brachte, um sich nun im Menschen zu verkörpern - ebenso muss nun im Erdendasein die Seele den Zustand zu erreichen suchen, daß sie den dunklen Aufenthalt in der Materie verlassen und sich in lichte Regionen erheben kann, um ebendie Lichtfülle, die der Inbegriff ist der Seligkeit, ertragen zu können.
<G-vec00241-002-s243><bear.ertragen><en> I told her I had it for years and although it had gotten much worse with pregnancy there was nothing to do but grin and bear it.
<G-vec00241-002-s243><bear.ertragen><de> Ich sagte ihr, dass ich das bereits seit Jahren hatte und obgleich es mit der Schwangerschaft wesentlich schlimmer geworden war, es außer lächeln und ertragen keine Abhilfe gäbe.
<G-vec00241-002-s244><bear.ertragen><en> (DB) Amos 7: 10 Then Amaziah the priest of Bethel sent to Jeroboam king of Israel, saying, Amos hath conspired against thee in the midst of the house of Israel: the land is not able to bear all his words.
<G-vec00241-002-s244><bear.ertragen><de> Amos wird aus Bethel ausgewiesen 10Da sandte Amazja, der Priester von Bethel, zu Jerobeam, dem König von Israel, und ließ ihm sagen: Amos hat eine Verschwörung wider dich angestiftet inmitten des Hauses Israel; das Land wird alle seine Worte nicht zu ertragen vermögen; (Jer.
<G-vec00241-002-s245><bear.ertragen><en> But the Baka and their neighbors continue to bear the brunt of the abuse, while the real problem – commercial poaching – goes largely unaddressed.
<G-vec00241-002-s245><bear.ertragen><de> Doch die Baka und ihre Nachbarn müssen weiterhin die Hauptlast der Misshandlungen ertragen, während das echte Problem – kommerzielle Wilderei – größtenteils außen vor bleibt.
<G-vec00241-002-s246><bear.ertragen><en> Bodily coexistence with my fellowmen provides the possibility to bear the infinity of space and time, their darkness and their silence.
<G-vec00241-002-s246><bear.ertragen><de> Die leibliche Koexistenz mit anderen gibt mir die Möglichkeit, die Unendlichkeit von Zeit und Raum, ihre Dunkelheit und ihr Schweigen zu ertragen.
<G-vec00241-002-s247><bear.ertragen><en> Sessile periphytic organisms have to bear the consequences of the lack of water coverage at low tide, added to which the force of the waves can be violent at times.
<G-vec00241-002-s247><bear.ertragen><de> Nicht nur die Folgen fehlender Wasserbedeckung bei Ebbe müssen sessile Aufwuchsorganismen ertragen, sondern auch eine mitunter gewalttätige Brandung.
<G-vec00241-002-s248><bear.ertragen><en> But some colleagues couldn't bear that I got the prize.
<G-vec00241-002-s248><bear.ertragen><de> Bloß manche Kollegen nicht, die konnten nicht ertragen, dass ich den Preis bekam.
<G-vec00241-002-s249><bear.ertragen><en> We cannot bear a world full of discrimination and repression any longer.
<G-vec00241-002-s249><bear.ertragen><de> Eine Welt voller Diskriminierungen und Unterdrückungen ertragen wir nicht länger.
<G-vec00241-002-s250><bear.ertragen><en> We need courage to no longer bear those locked up bright sides in ourselves. We need courage to release them from their prison.
<G-vec00241-002-s250><bear.ertragen><de> Wir brauchen Mut, die verschlossenen schönen Seiten in uns selbst nicht mehr zu ertragen, wir brauchen Mut, sie aus ihrem Gefängnis freizulassen.
<G-vec00241-002-s251><bear.ertragen><en> This stroke of fate was and remains hard to bear for all involved.
<G-vec00241-002-s251><bear.ertragen><de> Dieser Schicksalsschlag war und ist für alle Beteiligte nur schwer zu ertragen.
<G-vec00241-002-s252><bear.ertragen><en> They rather bear violence than love and prefer it to love.
<G-vec00241-002-s252><bear.ertragen><de> Sie ertragen eher Gewalt als Liebe und ziehen sie der Liebe vor.
<G-vec00241-002-s253><bear.ertragen><en> Only by the force of prayer can ye bear the weight of the trials that are already underway.
<G-vec00241-002-s253><bear.ertragen><de> Nur durch die Kraft des Gebetes koennt ihr das Gewicht der Pruefungen welche schon auf dem Wege sind ertragen.
<G-vec00241-002-s254><bear.ertragen><en> With spiritual practice we get the strength to bear pain on all fronts.
<G-vec00241-002-s254><bear.ertragen><de> Mit Spiritueller Praxis bekommen wir die Kraft, Schmerzen auf allen Ebenen des Lebens zu ertragen.
<G-vec00241-002-s255><bear.ertragen><en> Because the people cannot bear the truth for a longer time, become tired and always sink back again into their old judgment and death-bringing laziness. And then there is truly nothing else that can be done but, through the most extreme ways, awaken the people again and of old, bring them once more upon the ways and mountain paths of light and life.
<G-vec00241-002-s255><bear.ertragen><de> Denn die Menschen können für eine größere Länge der Zeit die Wahrheit nicht ertragen, werden müde und versinken allzeit wieder in ihre alte, Gericht und Tod bringende Trägheit, und es lässt sich dann wahrlich nichts anderes tun, als durch die äußersten Mittel die Menschen wieder zu erwecken und sie wieder in die alte Tätigkeit auf den Wegen und Steigen des Lichtes und Lebens zu versetzen.
<G-vec00241-002-s256><bear.ertragen><en> The soldier above all others prays for peace, for it is the soldier who must suffer and bear the deepest wounds and scars of We are going to have peace even if we have to fight for it.
<G-vec00241-002-s256><bear.ertragen><de> Krieg, Frieden Zitat von Douglas MacArthur Der Soldat betet am meisten von allen für den Frieden, denn er ist es der die Wunden und Narben des Krieges ertragen muss.
<G-vec00241-002-s257><bear.ertragen><en> But the certainty that everything is God's will, Who is love Himself, should enable you humans to bear everything with greater ease and it should be a comfort to you too that you are never left to your own devices, that there is always Someone Who cares about your spiritual maturity and wellbeing.
<G-vec00241-002-s257><bear.ertragen><de> Doch die Gewißheit, daß über allem Gottes Wille steht, Der in Sich die Liebe ist, sollte euch Menschen alles leichter ertragen lassen und euch auch ein Trost sein, daß ihr niemals euch selbst überlassen seid, daß immer Einer ist, Der um euer geistiges Ausreifen, um euer geistiges Wohl, bedacht ist.
<G-vec00241-002-s258><bear.ertragen><en> b) It has the ability to bear them; either by wealth or income sources.
<G-vec00241-002-s258><bear.ertragen><de> b) Es hat die Fähigkeit, sie zu ertragen; entweder durch Reichtum oder Einkommensquellen.
<G-vec00241-002-s259><bear.geben><en> Like the fascinating images of human beings and animals contained in the book, they bear testimony to the great art of book painting at the time of the Byzantine Empire.
<G-vec00241-002-s259><bear.geben><de> Ebenso wie die faszinierenden Darstellungen von Menschen und Tieren geben sie ein Zeugnis von der hohen Kunst der Buchmalerei im Byzantinischen Reich.
<G-vec00241-002-s260><bear.geben><en> Bear your testimony about how grateful you are to have the sacrament to help us remember Jesus Christ and what he has done for us.
<G-vec00241-002-s260><bear.geben><de> Geben Sie Zeugnis davon, wie dankbar Sie dafür sind, daß wir das Abendmahl haben, damit es uns an Jesus erinnert und daran, was er für uns getan hat.
<G-vec00241-002-s261><bear.geben><en> And so, on this Easter Sabbath, we bear testimony of the Redeemer of the world, He who was born the Only Begotten of the Father, He who went about doing good in the exercise of His divine power, He who died on Calvary’s hill, and He who rose to become the first fruits of the Resurrection.
<G-vec00241-002-s261><bear.geben><de> Und so geben wir an diesem Ostersonntag Zeugnis vom Erlöser der Welt, der als der Einziggezeugte des Vaters geboren wurde, von ihm, der in Ausübung seiner göttlichen Macht hinging und Gutes tat, vom ihm, der auf Golgota starb, und von ihm, der sich erhob und die Erstfrucht der Auferstehung wurde.
<G-vec00241-002-s262><bear.geben><en> God bless you millions of youth in our Church who worthily follow the patterns of the gospel and have within you a deep testimony—the testimony that all of us share and bear.
<G-vec00241-002-s262><bear.geben><de> Gott segne euch, die Millionen Jugendlichen in unserer Kirche, die ihr euch würdig am Evangelium ausrichtet und ein festes Zeugnis habt – das Zeugnis, das wir alle haben und geben.
<G-vec00241-002-s263><bear.geben><en> Small pieces of lead bear witness to the fact that my companions were the cause of a custom's agreement.
<G-vec00241-002-s263><bear.geben><de> Kleine Bleistückchen geben Zeugnis davon, daß meine Gefährten Anlaßfälle eines Zollübereinkommens sind.
<G-vec00241-002-s264><bear.geben><en> Inasmuch as the House of Justice hath power to enact laws that are not expressly recorded in the Book and bear upon daily transactions, so also it hath power to repeal the same.
<G-vec00241-002-s264><bear.geben><de> Da dieses Haus der Gerechtigkeit die Gewalt hat, Gesetze zu geben, die nicht ausdrücklich im Buche enthalten sind, und die laufenden Geschäfte zu regeln, hat es auch die Gewalt, solche Gesetze aufzuheben.
<G-vec00241-002-s265><bear.geben><en> The court museum and the penitentiary exhibition bear witness to past centuries.
<G-vec00241-002-s265><bear.geben><de> Gerichtsmuseum und Strafvollzugsausstellung geben Zeugnis über vergangene Jahrhunderte.
<G-vec00241-002-s266><bear.geben><en> Invite the children to bear testimony of the Book of Mormon.
<G-vec00241-002-s266><bear.geben><de> Lassen Sie auch die Kinder Zeugnis vom Buch Mormon geben.
<G-vec00241-002-s267><bear.geben><en> Some will try to falsify it and will try to rewrite the history of our ancestors on palimpsests but they will ineffably stumble on the march of time which will reveal to the eyes of the world their imposture and will consume this veil of joke because the truth is immarchable and so on. it is she who will bear witness to men at the appropriate time.
<G-vec00241-002-s267><bear.geben><de> Einige werden versuchen, es zu fälschen und die Geschichte unserer Vorfahren auf Palimpsesten neu zu schreiben, aber sie werden unbeschreiblich auf den Lauf der Zeit stoßen, der den Augen der Welt ihre Betrügerei offenbart und diesen Schleier der Witze verbraucht, weil die Wahrheit unveränderlich ist und so Sie wird zu gegebener Zeit den Menschen Zeugnis geben.
<G-vec00241-002-s268><bear.geben><en> I have had an unquenchable desire to bear testimony of the Father and of Jesus Christ.
<G-vec00241-002-s268><bear.geben><de> Ich hatte den unstillbaren Wunsch, vom Vater und von Jesus Christus Zeugnis zu geben.
<G-vec00241-002-s269><bear.geben><en> In addition to strengthening fidelity to the founding spirit, the role of the General Chapter is to adapt it appropriately for this day and age, discerning "what the Spirit is suggesting to the different communities" (Tertio Millennio Adveniente, n. 23) and seeking the best way to proclaim and bear witness to Christ in today's increasingly globalized world, as the theme chosen for your Chapter reflection indicates.
<G-vec00241-002-s269><bear.geben><de> Das Generalkapitel hat seinerseits den Auftrag, die Treue zum Geist der Anfänge zu festigen und ihn in einer für die heutige Zeit angemessenen Weise präsent zu machen, indem man das unterscheidet, »was der Geist den verschiedenen Gemeinschaften rät« (Tertio Millennio adveniente, 23), und indem – wie es im Motto des Kapitels heißt – die beste Weise gesucht wird, für Christus Zeugnis zu geben und ihn in der heutigen immer mehr globalisierten Welt zu verkünden.
<G-vec00241-002-s270><bear.geben><en> We bear witness of every sermon He ever gave, every prayer He ever uttered, every miracle He ever called down from heaven, and every redeeming act He ever performed.
<G-vec00241-002-s270><bear.geben><de> Wir geben Zeugnis von jeder Predigt, die er gehalten, jedem Gebet, das er gesprochen, jedem Wunder, das er vom Himmel herabgerufen, und jedem erlösenden Werk, das er vollbracht hat.
<G-vec00241-002-s271><bear.geben><en> During this meeting, Elder Bednar called on a young man and a young woman to bear their testimonies.
<G-vec00241-002-s271><bear.geben><de> Bei dieser Versammlung bat Elder Bednar zwei Jugendliche – einen Jungen und ein Mädchen –, Zeugnis zu geben.
<G-vec00241-002-s272><bear.geben><en> And my small flock shall bear witness till the end to the kingdom of God and his power - my promises are to come true that a strong faith is capable of everything and that the ones that are mine will be given what they ask for in this faith.
<G-vec00241-002-s272><bear.geben><de> Und Meine kleine Schar soll bis zuletzt ein Zeugnis geben vom Reich Gottes und Seiner Macht - und Meine Verheißungen sollen sich erfüllen, daß ein starker Glaube alles vermag und daß den Meinen gegeben wird, was sie erbitten in diesem Glauben.
<G-vec00241-002-s273><bear.geben><en> The stately façades with their magnificent entrance portals and the coats of arms carved in stone still bear witness to the splendid history of Dos Torres.
<G-vec00241-002-s273><bear.geben><de> Die herrschaftlichen Fassaden mit ihren Eingangsportalen und den in Stein gehauenen Wappen geben noch heute Zeugnis von der glanzvollen Geschichte des Ortes.
<G-vec00241-002-s274><bear.geben><en> His primary responsibility, however, is to bear witness of Christ.
<G-vec00241-002-s274><bear.geben><de> Die Hauptaufgabe eines Propheten ist es jedoch, Zeugnis von Christus zu geben.
<G-vec00241-002-s275><bear.geben><en> Demetrius hath good report of all men, and of the truth itself: yea, and we also bear record; and ye know that our record is true.
<G-vec00241-002-s275><bear.geben><de> Dem Demetrius wird Zeugnis gegeben von allen und von der Wahrheit selbst; aber auch wir geben Zeugnis, und du weißt, daß unser Zeugnis wahr ist.
<G-vec00241-002-s276><bear.geben><en> 4 And next spring let them depart to go over the great waters, and there promulgate my gospel, the fulness thereof, and bear record of my name.
<G-vec00241-002-s276><bear.geben><de> 4 Und laßt sie im nächsten Frühjahr abreisen und sich über die großen Wasser begeben und dort mein Evangelium verbreiten, ja, seine Fülle, und von meinem Namen Zeugnis geben.
<G-vec00241-002-s277><bear.geben><en> They were never rebuilt, so their ruins bear undistorted witness to the rapid rise and fall of this great civilization.
<G-vec00241-002-s277><bear.geben><de> Sie wurden niemals wieder aufgebaut, und ihre Ruinen geben deshalb ein unverfälschtes Zeugnis ab vom steilen Aufstieg und raschen Niedergang einer großen Zivilisation.
<G-vec00241-002-s278><bear.gebären><en> To the woman he said, I will greatly increase thy travail and thy pregnancy; with pain thou shalt bear children; and to thy husband shall be thy desire, and he shall rule over thee.
<G-vec00241-002-s278><bear.gebären><de> Und zum Weibe sprach er: Ich will dir viel Schmerzen schaffen, wenn du schwanger wirst; du sollst mit Schmerzen Kinder gebären; und dein Verlangen soll nach deinem Manne sein, und er soll dein Herr sein.
<G-vec00241-002-s279><bear.gebären><en> 19 And God said, Nay, but Sarah thy wife shall bear thee a son; and thou shalt call his name Isaac: and I will establish my covenant with him for an everlasting covenant for his seed after him.
<G-vec00241-002-s279><bear.gebären><de> 19 Und Gott sprach: Fürwahr, Sara, dein Weib, wird dir einen Sohn gebären, und du sollst ihm den Namen Isaak (H. Jizchak, auch Jischak: Lacher) geben; und ich werde meinen Bund mit ihm errichten zu einem ewigen Bunde für seinen Samen nach ihm.
<G-vec00241-002-s280><bear.gebären><en> 21. But my covenant will I establish with Isaac, which Sarah shall bear unto thee at this set time in the next year.
<G-vec00241-002-s280><bear.gebären><de> Genesis 17:18-21*.....Aber meinen Bund will ich aufrichten mit Isaak, den dir Sara gebären soll um diese Zeit im andern Jahr.
<G-vec00241-002-s281><bear.gebären><en> Manganese is necessary for normal growth, maintenance of reproductive function (ability to conceive, bear and give birth to a child), metabolism of connective tissue (tissue that is more or less present in all organs and tissues, forming their basis), bone formation, fat metabolism and carbohydrates - all these processes are extremely important during pregnancy, when the formation of tissues and organs of the fetus.
<G-vec00241-002-s281><bear.gebären><de> Mangan ist für das normale Wachstum, die Aufrechterhaltung der Fortpflanzungsfunktion (Fähigkeit, zu gebären, zu gebären und ein Kind zu gebären), den Stoffwechsel des Bindegewebes (mehr oder weniger in allen Organen und Geweben vorhandenes Gewebe), Knochenbildung, Fettstoffwechsel und Kohlenhydrate - alle diese Prozesse sind extrem wichtig während der Schwangerschaft, wenn die Bildung von Geweben und Organen des Fötus.
<G-vec00241-002-s282><bear.gebären><en> But he said unto me, Behold, thou shalt conceive, and bear a son;
<G-vec00241-002-s282><bear.gebären><de> Er sprach aber zu mir: Siehe, du wirst schwanger werden und einen Sohn gebären.
<G-vec00241-002-s283><bear.gebären><en> 13 But the angel said to him, “Don’t be afraid, Zacharias, because your request has been heard, and your wife, Elizabeth, will bear you a son, and you shall call his name John.
<G-vec00241-002-s283><bear.gebären><de> 13 Aber der Engel sprach zu ihm: Fürchte dich nicht, Zacharias; denn dein Gebet ist erhöret, und dein Weib Elisabeth wird dir einen Sohn gebären, des Namen sollst du Johannes heißen.
<G-vec00241-002-s284><bear.gebären><en> 17:19 God said, "No, but Sarah, your wife, will bear you a son. You shall call his name Isaac. I will establish my covenant with him for an everlasting covenant for his seed after him.
<G-vec00241-002-s284><bear.gebären><de> 17:19 Da sprach Gott: Ja, Sara, dein Weib soll dir einen Sohn gebären, den sollst du Isaak heißen; denn mit ihm will ich meinen ewigen Bund aufrichten und mit seinem Samen nach ihm.
<G-vec00241-002-s285><bear.gebären><en> 13 But the angel said unto him, Fear not, Zacharias: for thy prayer is heard; and thy wife Elisabeth shall bear thee a son, and thou shalt call his name John.
<G-vec00241-002-s285><bear.gebären><de> Lk 1,13 Aber der Engel sprach zu ihm: Fürchte dich nicht, Zacharias; denn dein Gebet ist erhöret, und dein Weib Elisabeth wird dir einen Sohn gebären, des Namen sollst du Johannes heißen.
<G-vec00241-002-s286><bear.gebären><en> she will bear a son, and you shall call his name Jesus, for he will save his people from their sins."
<G-vec00241-002-s286><bear.gebären><de> Und sie wird einen Sohn gebären, und du sollst seinen Namen Jesus heißen; denn er wird sein Volk erretten von ihren Sünden.
<G-vec00241-002-s287><bear.gebären><en> But My covenant I will establish with Isaac, whom Sarah will bear to you at this time next year."
<G-vec00241-002-s287><bear.gebären><de> 21 Aber meinen Bund will ich aufrichten mit Isaak, den dir Sara gebären soll um diese Zeit im nächsten Jahr.
<G-vec00241-002-s288><bear.gebären><en> Do not be afraid, Zechari′ah, for your prayer is heard, and your wife Elizabeth will bear you a son, and you shall call his name John.
<G-vec00241-002-s288><bear.gebären><de> 13 Aber der Engel sprach zu ihm: Fürchte dich nicht, Zacharias, denn dein Gebet ist erhört, und deine Frau Elisabeth wird dir einen Sohn gebären, dem sollst du den Namen Johannes geben.
<G-vec00241-002-s289><bear.gebären><en> Therefore the Lord himself will give you this sign: the virgin shall be with child, and bear a son, and shall name him Immanuel (God with us). (Isa 7:14).
<G-vec00241-002-s289><bear.gebären><de> „Seht, die Jungfrau wird ein Kind empfangen, sie wird einen Sohn gebären und sie wird ihm den Namen Immanuel (Gott mit uns) geben“ (Jes 7,14).
<G-vec00241-002-s290><bear.gebären><en> 13But the angel said unto him, Fear not, Zacharias: because thy supplication is heard, and thy wife Elisabeth shall bear thee a son, and thou shalt call his name John. 14And thou shalt have joy and gladness; and many shall rejoice at his birth.
<G-vec00241-002-s290><bear.gebären><de> 13Der Engel aber sprach zu ihm: fürchte dich nicht, Zacharias, dieweil deine Bitte erhört ist, und deine Frau Elisabet wird dir einen Sohn gebären, und du wirst ihm den Namen Johannes geben; 14und du wirst Freude und Wonne haben, und viele werden sich seiner Geburt freuen.
<G-vec00241-002-s291><bear.gebären><en> But the angel said to him, ‘Do not be afraid, Zechariah, for your prayer has been heard. Your wife Elizabeth will bear you a son, and you will name him Yohanan.
<G-vec00241-002-s291><bear.gebären><de> 13 Der Engel aber sprach zu ihm: Fürchte dich nicht, Zacharias, denn dein Flehen ist erhört, und dein Weib Elisabeth wird dir einen Sohn gebären, und du sollst seinen Namen Johannes heißen.
<G-vec00241-002-s292><bear.gebären><en> 3For thus says the Lord concerning the sons and daughters born in this place, and concerning their mothers who bear them, and their fathers who beget them in this land: 4"They will die of deadly diseases, they will not be lamented or buried; they will be as dung on the surface of the ground and come to an end by sword and famine, and their carcasses will become food for the birds of the sky and for the beasts of the earth."
<G-vec00241-002-s292><bear.gebären><de> 3Denn so spricht Jehova über die Söhne und über die Töchter, welche an diesem Orte geboren werden, und über ihre Mütter, die sie gebären, und über ihre Väter, die sie zeugen in diesem Lande: 4Sie sollen an schmerzlichen Krankheiten sterben, sie sollen nicht beklagt noch begraben werden, zu Dünger auf der Fläche des Erdbodens sollen sie werden; und durch Schwert und durch Hunger sollen sie vernichtet werden, und ihre Leichname sollen dem Gevögel des Himmels und den Tieren der Erde zur Speise dienen.
<G-vec00241-002-s293><bear.gebären><en> 3And an angel of the Lord appeared to her, and said: Thou art barren and without children: but thou shalt conceive and bear a son.
<G-vec00241-002-s293><bear.gebären><de> 3Und der Engel Jehovas erschien dem Weibe und sprach zu ihr: Siehe doch, du bist unfruchtbar und gebierst nicht; aber du wirst schwanger werden und einen Sohn gebären.
<G-vec00241-002-s294><bear.gebären><en> Nature has laid a special life program in us - we must conceive, bear and give birth to offspring.
<G-vec00241-002-s294><bear.gebären><de> Die Natur hat ein besonderes Lebensprogramm in uns gelegt - wir müssen Nachwuchs empfangen, gebären und gebären.
<G-vec00241-002-s295><bear.gebären><en> 3 And the angel of YHVH appeared unto the woman, and said unto her, Behold now, thou art barren, and bearest not: but thou shalt conceive, and bear a son.
<G-vec00241-002-s295><bear.gebären><de> 3 Und der Engel des HERRN erschien dem Weibe und sprach zu ihr:Siehe, du bist unfruchtbar und gebierst nicht; aber du wirst schwanger werden und einen Sohn gebären.
<G-vec00241-002-s296><bear.gebären><en> Reader: ““Don’t be afraid, Zacharias, because your request has been heard, and your wife, Elizabeth, will bear you a son, and you shall call his name John.
<G-vec00241-002-s296><bear.gebären><de> Und sie wird einen Sohn gebären, dem sollst du den Namen Jesus geben, denn er wird sein Volk retten von ihren Sünden.
<G-vec00241-002-s316><bear.halten><en> After all, learning democracy means examining and analysing past and present happenings and to bear crimes against humanity in remembrance – to make sure that these aspects of our history cannot be repeated.
<G-vec00241-002-s316><bear.halten><de> Denn Demokratie lernen heißt, sich mit den Geschehnissen aus Vergangenheit und Gegenwart auseinander zu setzen und auch die Erinnerung an Menschheitsverbrechen wach zu halten - damit sich diese Seiten unserer Geschichte nicht wiederholen können.
<G-vec00241-002-s317><bear.halten><en> Potential property buyers should bear this in mind if you are interested in an object in the region: Even the well-known resorts are not self-employed in their planning, but depend on the strategies and decisions of the Administration in Calvià.
<G-vec00241-002-s317><bear.halten><de> Diesen Umstand sollten sich potentielle Immobilienkäufer vor Augen halten, wenn Sie sich für ein Objekt in der Region interessieren: Selbst die bekannten Ferienorte sind nicht selbstständig in ihren Planungen, sondern abhängig von den Strategien und Entscheidungen der Administration in Calvià.
<G-vec00241-002-s318><bear.halten><en> The difference between stainless steel and the chrome-plated pipe is dramatic: usually thin-walled pipes are chromed, they can not bear the load, and the chrome peels off quickly in damp places and the pipe starts to rust.
<G-vec00241-002-s318><bear.halten><de> Der Unterschied zwischen einem Edelstahlrohr und einem verchromten Rohr ist auffallend: Verchromt werden normalerweise dünnwandige Rohre, sie halten keine Belastung aus, außerdem schält sich Chrom in feuchten Räumen schnell ab, und das Rohr beginnt zu rosten.
<G-vec00241-002-s319><bear.halten><en> We must always bear this in mind.
<G-vec00241-002-s319><bear.halten><de> Das müssen wir uns immer wieder vor Augen halten.
<G-vec00241-002-s320><bear.halten><en> And then you hopefully bear it for a day or two and won't feel the need to go and read the blog next door.
<G-vec00241-002-s320><bear.halten><de> Und dann halten Sie es hoffentlich einen oder zwei Tage aus und haben kein Bedürfnis, den Nachbarblog zu lesen.
<G-vec00241-002-s321><bear.halten><en> •The turntable and the grills can bear a maximum load of 8 kg.
<G-vec00241-002-s321><bear.halten><de> •Der Drehteller und die Roste halten einer Höchstbelastung von 8 kg stand.
<G-vec00241-002-s322><bear.halten><en> WIN is the ideal choice for all original thinkers, who cannot bear the thought of boring kitchens; it inspires every creative cook in an inimitable way.
<G-vec00241-002-s322><bear.halten><de> Für alle geistreichen originellen Typen, die nichts vom täglichen Einerlei in der Küche halten, ist WIN genau die richtige Lösung und inspiriert jeden kreativen Koch auf unverwechselbare Weise.
<G-vec00241-002-s323><bear.halten><en> Here, primarily computational speed was of concern, in order to bear comparison with competing software.
<G-vec00241-002-s323><bear.halten><de> Sie diente hauptsächlich einer Erhöhung der Rechengeschwindigkeit um mit konkurrierenden Programmen Schritt zu halten.
<G-vec00241-002-s326><bear.halten><en> Unfortunately we bear the sad fact of hunger way to seldom in mind.
<G-vec00241-002-s326><bear.halten><de> Eine traurige Wahrheit, die wir uns viel zu selten vor Augen halten.
<G-vec00241-002-s327><bear.halten><en> Bear right in the Schlosspark (castle park) and cross the bridge over the "Burgsee".
<G-vec00241-002-s327><bear.halten><de> Im Schlosspark rechts halten und die Burgseebrücke überqueren.
<G-vec00241-002-s328><bear.halten><en> And we try to avoid this of course and bear losses or produce expected losses for fear of losses.
<G-vec00241-002-s328><bear.halten><de> “ Und das versuchen wir natürlich zu vermeiden und halten Verluste aus oder produzieren voraussichtliche Verluste aus Angst vor Verlusten.
<G-vec00241-002-s329><bear.halten><en> The one thing you have to do is to bear witness to the truth.
<G-vec00241-002-s329><bear.halten><de> Gutes tun heißt die Gebote halten, die der Herr uns gegeben hat.
<G-vec00241-002-s330><bear.halten><en> Bear right onto Ebury Bridge and then bear left onto Warwick Way.
<G-vec00241-002-s330><bear.halten><de> Halten Sie sich rechts, bis sie über die Brücke Ebury Bridge fahren, und halten Sie sich dann links bis zum Warwick Way.
<G-vec00241-002-s331><bear.halten><en> But LEDA's strings do bear comparison with the homonymous class string of the C++ standard library; both classes offer nearly the same functionality.
<G-vec00241-002-s331><bear.halten><de> Einem Vergleich mit der gleichnamigen Klasse string aus der C++-Standardbibliothek halten sie aber stand; die beiden Klassen besitzen nahezu dieselbe Funktionalität.
<G-vec00241-002-s332><bear.halten><en> The other thing to bear in mind, the $45 million of aid from the US is just the tip of the iceberg.
<G-vec00241-002-s332><bear.halten><de> Die andere Sache, die man sich vor Augen halten muss, ist, dass die 45-Millionen-USD-Hilfe der USA nur gerade die Spitze des Eisbergs sind.
<G-vec00241-002-s333><bear.halten><en> Patients should bear in mind that the chance of a successful implantation diminishes with age, while the cost of further cycles can also be prohibitive for some people.
<G-vec00241-002-s333><bear.halten><de> Die Patientinnen sollten sich vor Augen halten, dass die Erfolgsrate für eine IVF mit zunehmendem Alter abnimmt und für manch einen auch die Kosten für zusätzliche Zyklen untragbar sind.
<G-vec00241-002-s334><bear.halten><en> We must of course always bear in mind that what concerns us most of all, what is most important, is the development of man himself.
<G-vec00241-002-s334><bear.halten><de> Wir müssen uns natürlich immer vor Augen halten, daß das Wesentlichste, das uns interessieren kann an diesem ganzen Erdenwerden, die Entwickelung, die Heranbildung des Menschen selbst ist.
<G-vec00241-002-s392><bear.tragen><en> 17. From now on let no man trouble me: for I bear in my body the marks of the Lord Jesus.
<G-vec00241-002-s392><bear.tragen><de> 17 Hinfort mache mir niemand weitere Mühe; denn ich trage die Malzeichen des Herrn Jesus an meinem Leib.
<G-vec00241-002-s393><bear.tragen><en> It shall be on Aaron's forehead, and Aaron shall bear the iniquity of the holy things, which the children of Israel shall make holy in all their holy gifts; and it shall be always on his forehead, that they may be accepted before Yahweh.
<G-vec00241-002-s393><bear.tragen><de> 38 Und es soll sein auf der Stirn Aarons, damit Aaron bei allen ihren Opfern alle Sünde trage, die an den heiligen Gaben der Kinder Israel haftet.
<G-vec00241-002-s395><bear.tragen><en> Yes he said in Galatians 6, "I bear in my body the marks of Jesus Christ." But wounds were not enough.
<G-vec00241-002-s395><bear.tragen><de> In Galater 6 sagte er: „Ich trage die Malzeichen des Herrn Jesus an meinem Leib.“ Aber Wunden waren nicht genug.
<G-vec00241-002-s396><bear.tragen><en> 17From now on let no one cause me trouble, for I bear on my body the marks of Jesus.
<G-vec00241-002-s396><bear.tragen><de> 17Hinfort mache mir keiner Mühe, denn ich trage die Malzeichen des Herrn Jesus an meinem Leibe.
<G-vec00241-002-s397><bear.tragen><en> Bear insult, bear injury, highest Yoga.
<G-vec00241-002-s397><bear.tragen><de> Trage Schaden, trage Schmähung, höchstes Yoga.
<G-vec00241-002-s399><bear.tragen><en> 14 And thou shalt put the staves into the rings on the sides of the ark, wherewith to bear the ark.
<G-vec00241-002-s399><bear.tragen><de> 14und stecke sie in die Ringe an den Seiten der Lade, dass man sie damit trage.
<G-vec00241-002-s400><bear.tragen><en> I bear the responsibility for these strengths.
<G-vec00241-002-s400><bear.tragen><de> Für diese Stärken trage ich die Verantwortung.
<G-vec00241-002-s401><bear.tragen><en> I feel that I bear everyone in prayer, in a present, God’s present, in which I gather together every one of my meetings, journeys and pastoral visits.
<G-vec00241-002-s401><bear.tragen><de> Ich spüre, daß ich alle im Gebet trage, in eine Gegenwart, welche die Gegenwart Gottes ist, in die ich jede Begegnung, jede Reise, jeden Pastoralbesuch hineinnehme.
<G-vec00241-002-s402><bear.tragen><en> 2 Gal 6, 2 Bear all of you one another's burdens, and so fulfill the law of Christ.
<G-vec00241-002-s402><bear.tragen><de> 2 Gal 6, 2 Einer trage des anderen Lasten, und also erfüllet das Gesetz des Christus.
<G-vec00241-002-s403><bear.tragen><en> Bear one another's burdens, and thus fulfil the law of the Christ.
<G-vec00241-002-s403><bear.tragen><de> Einer trage des andern Last, so werdet ihr das Gesetz Christi erfüllen.
<G-vec00241-002-s405><bear.tragen><en> May the Virgin Mary help us listen to this Gospel passage with open hearts and minds so that it may bear fruit in our life and that we may become witnesses of the happiness that does not disappoint, that of God who never disappoints.
<G-vec00241-002-s405><bear.tragen><de> Die Jungfrau Maria helfe uns, dieses Evangelium mit offenem Geist und Herzen zu hören, damit es in unserem Leben Früchte trage und wir Zeugen des Glücks werden, das nicht enttäuscht, des Glücks Gottes, das niemals enttäuscht.
<G-vec00241-002-s408><bear.tragen><en> 6:17 From henceforth let no man trouble me: for I bear in my body the marks of the Lord Jesus.
<G-vec00241-002-s408><bear.tragen><de> 6:17 Im übrigen mache mir niemand weitere Mühe; denn ich trage die Malzeichen Jesu an meinem Leibe.
<G-vec00241-002-s409><bear.tragen><en> 30 To the breastplate of judgement you will add the urim and the thummim, and these will be on Aaron's heart when he goes into Yahweh's presence, and Aaron will bear the Israelites' judgement on his heart, in Yahweh's presence, always.
<G-vec00241-002-s409><bear.tragen><de> 30 In die Brusttasche des Rechtsentscheids steck die Urim und die Tummim; sie sollen sich über dem Herzen Aarons befinden, wenn er vor den HERRN kommt; Aaron trage den Rechtsentscheid für die Israeliten über seinem Herzen ständig vor dem HERRN.
<G-vec00241-002-s410><bear.tragen><en> Bear ye one another's burdens, and so fulfil the law of Christ.
<G-vec00241-002-s410><bear.tragen><de> LUT | Einer trage des andern Last, so werdet ihr das Gesetz Christi erfüllen.
<G-vec00241-002-s449><bear.übernehmen><en> Maaspark Boschmolenplas therefore does not wish to bear any responsibility for personal data left behind by these partners.
<G-vec00241-002-s449><bear.übernehmen><de> Maaspark Boschmolenplas wünscht darum keine Verantwortung zu übernehmen für Personendaten, die bei diesen Partnern hinterlassen wurden.
<G-vec00241-002-s450><bear.übernehmen><en> If the trader has not declared that the consumer shall bear these costs or if the trader indicates a willingness to bear these costs himself, then the consumer shall not be liable to bear the costs of returning goods.
<G-vec00241-002-s450><bear.übernehmen><de> Wenn der Unternehmer nicht mitgeteilt hat, dass der Verbraucher diese Kosten zu übernehmen hat oder wenn der Unternehmer mitteilt, die Kosten selbst zu übernehmen, braucht der Verbraucher die Kosten für den Rücktransport nicht zu übernehmen.
<G-vec00241-002-s453><bear.übernehmen><en> We bear the liability for replacement deliveries and repair work to the same extent as for the goods delivered originally; the guarantee period starts a new for replacement deliveries.
<G-vec00241-002-s453><bear.übernehmen><de> Wir übernehmen die Haftung für Ersatzlieferungen und Reparaturarbeiten in demselben Maß wie für Originallieferungen von Waren; die Garantiefrist beginnt für Ersatzlieferungen erneut.
<G-vec00241-002-s454><bear.übernehmen><en> The management from Dunkermotoren agreed to this great project and was immediately willing to bear all the costs of the bike for Jeremy.
<G-vec00241-002-s454><bear.übernehmen><de> Die Geschäftsleitung von Dunkermotoren stimmte dieser tollen Sache zu und war sofort bereit, die Kosten für das Fahrrad für Jeremy zu übernehmen.
<G-vec00241-002-s455><bear.übernehmen><en> If you want to go back to the hotel just call a cab - we will bear the costs!
<G-vec00241-002-s455><bear.übernehmen><de> Wenn Sie zurück zum Hotel möchten, bestellen Sie sich einfach ein Taxi – die Kosten dafür übernehmen wir.
<G-vec00241-002-s456><bear.übernehmen><en> It is also possible to proceed at your own risk without advice, however we bear no responsibility for any damage that may be caused by using this software without the supervision of an Emsisoft expert.
<G-vec00241-002-s456><bear.übernehmen><de> Sie können auch selbstständig ohne Hilfe fortfahren; jedoch übernehmen wir keinerlei Verantwortung für etwaige Schäden, die aus der Nutzung dieses Programms ohne Anleitung durch einen Emsisoft-Experten entstehen.
<G-vec00241-002-s457><bear.übernehmen><en> 7.3 If the client is in arrears with payment or if deferment of payment has been expressly agreed, the client shall bear interest in the amount invoiced to Arcadia Filmproduktion by the house bank (including any commissions and loan processing costs), but at least 4 % above the respective discount rate of the Deutsche Bundesbank.
<G-vec00241-002-s457><bear.übernehmen><de> 7.3 Befindet sich der Auftraggeber mit der Zahlung im Verzug oder ist ausdrücklich Stundung vereinbart worden, hat der Auftraggeber Zinsen in der Höhe zu übernehmen, wie sie der Arcadia Filmproduktion von der Hausbank in Rechnung gestellt werden (einschließlich etwaiger Provisionen und Kreditbearbeitungskosten), mindestens jedoch in Höhe von 4 % über dem jeweiligen Diskontsatz der Deutschen Bundesbank.
<G-vec00241-002-s458><bear.übernehmen><en> The Spanish Government considers that the seller should bear all the costs associated with the replacement of the defective goods, including the cost of removing those goods and of installing the replacement goods, failing which the consumer would have to bear those costs twice, which would be incompatible with the high level of protection aimed at by the Directive.
<G-vec00241-002-s458><bear.übernehmen><de> Nach Auffassung der spanischen Regierung muss der Verkäufer alle Kosten im Zusammenhang mit der Ersatzlieferung für das mangelhafte Verbrauchsgut übernehmen, einschließlich der Kosten für dessen Ausbau und der Kosten für den Einbau des als Ersatz gelieferten Verbrauchsguts, da andernfalls der Verbraucher diese Kosten zweimal tragen müsste, was mit dem durch die Richtlinie angestrebten hohen Schutzniveau unvereinbar wäre.
<G-vec00241-002-s460><bear.übernehmen><en> Please remember to inform your bank that you will bear the complete bank charges.
<G-vec00241-002-s460><bear.übernehmen><de> Bitte vergessen Sie nicht Ihrer Bank mitzuteilen, dass Sie die Bankspesen übernehmen.
<G-vec00241-002-s461><bear.übernehmen><en> To make a proactive contribution to peace means that Japan will bear its own share of responsibility for assuring the security that supports global prosperity and stability.
<G-vec00241-002-s461><bear.übernehmen><de> Aktiv zum Frieden beizutragen bedeutet für Japan, eigene Verantwortung für die Sicherheit zu übernehmen, die Voraussetzung für Wohlstand und Stabilität in aller Welt ist.
<G-vec00241-002-s462><bear.übernehmen><en> By virtue of its special mandate, it can bear higher risks in individual transactions than commercial banks.
<G-vec00241-002-s462><bear.übernehmen><de> Durch ihr besonderes Mandat kann die OeEB im Vergleich zu Kommerzbanken höhere Risiken bei Einzeltransaktionen übernehmen.
<G-vec00241-002-s463><bear.übernehmen><en> Evdokimov: “We must bear the responsibility (for Kirov’s murder), because it is the venom with which we poisoned those around us during a 10-year period which made possible the realization of this crime.”
<G-vec00241-002-s463><bear.übernehmen><de> Jewdokimow: Wir müssen die Verantwortung (für den Kirowmord) übernehmen, denn das Gift, mit dem wir während eines Jahrzehnts die uns Nahestehenden vergifteten, ermöglichte die Ausführung des Verbrechens.
<G-vec00241-002-s464><bear.übernehmen><en> Secondly, undertakings must bear the costs arising as a result of auditors and other experts being called in or undertakings meeting their statutory disclosure and reporting requirements.
<G-vec00241-002-s464><bear.übernehmen><de> Zum anderen müssen die Unternehmen die Kosten übernehmen, die dadurch entstehen, dass Wirtschaftsprüfer und andere Sachverständige eingeschaltet werden oder die Unternehmen ihre gesetzlichen Auskunfts- und Berichtspflichten erfüllen.
<G-vec00241-002-s465><bear.übernehmen><en> For this, a new body will be set up, which will purchase electricity exclusively from the Israel Electric Corporation, and which will bear full responsibility for paying for the electricity consumption of the Palestinian residents.
<G-vec00241-002-s465><bear.übernehmen><de> Zu diesem Zweck soll eine Behörde eingerichtet werden, die den Strom ausschließlich von der israelischen Elektrizitätsgesellschaft kaufen und die volle Verantwortung zur Zahlung der Kosten für den Stromverbrauch der palästinensischen Bewohner übernehmen wird.
<G-vec00241-002-s466><bear.übernehmen><en> This means that suppliers who cause a complaint must bear the costs for this complaint.
<G-vec00241-002-s466><bear.übernehmen><de> Dies bedeutet, dass Anlieferer, die eine Reklamation verursachen, die Kosten für diese Reklamation übernehmen müssen.
<G-vec00241-002-s467><bear.übernehmen><en> 11.3 The supplier is also obliged to bear the cost of precautionary measures to be taken and compensate for any damage or loss incurred as a result thereof provided that the cause for the precautionary measures lies within the supplier’s sphere of control and/or his organizational responsibility and the supplier is himself directly liable to the third party.
<G-vec00241-002-s467><bear.übernehmen><de> 11.3 Der Lieferant ist auch verpflichtet, die Kosten für vorsorgliche Maßnahmen sowie daraus entstandene Schäden zu übernehmen, wenn die Ursache für die vorsorgliche Maßnahme im Herrschafts- und/oder Organisationsbereich des Lieferanten gesetzt ist und er im Aussenverhältnis selbst haftet.
<G-vec00328-002-s280><bear.gebären><en> 21. But my covenant will I establish with Isaac, which Sarah shall bear unto thee at this set time in the next year.
<G-vec00328-002-s280><bear.gebären><de> Genesis 17:18-21*.....Aber meinen Bund will ich aufrichten mit Isaak, den dir Sara gebären soll um diese Zeit im andern Jahr.
<G-vec00442-002-s297><bear.haben><en> If we bear them in mind, they will be of assistance to us in this sublime task of communion with God.
<G-vec00442-002-s297><bear.haben><de> Wenn wir sie vor Augen haben, werden sie auch uns helfen, im Gebet die Gemeinschaft mit Gott zu finden.
<G-vec00442-002-s298><bear.haben><en> Fourthly, we must bear in mind the circumstance that the resistance of the moribund classes in our country is not taking place in isolation from the outside world, but is receiving the support of the capitalist encirclement.
<G-vec00442-002-s298><bear.haben><de> Viertens muss man den Umstand im Auge haben, dass die untergehenden Klassen unseres Landes bei ihrem Widerstand nicht von der Außenwelt isoliert sind, sondern dass ihr Widerstand von der kapitalistischen Umwelt unterstützt wird.
<G-vec00442-002-s299><bear.haben><en> Finally well enough to leave Dr Xue's clinic and, as we have a quarantine garden at our bear rescue centre, Sissel, Rebecca and Karene, all happily agreed that both Si Bao and her pup could come to our bear sanctuary in Chengdu.
<G-vec00442-002-s299><bear.haben><de> Nachdem sie endlich gesund genug waren, um die Klinik von Dr. Xue zu verlassen und weil wir in unserem Rettungszentrum auch einen Quarantänegarten haben, waren Sissel, Rebecca und Karen gern einverstanden, dass Si Bao und ihr Junges zu uns nach Chengdu kommen.
<G-vec00442-002-s300><bear.haben><en> The Hungarian folk-tales bear a profound wisdom about the man's world.
<G-vec00442-002-s300><bear.haben><de> Die ungarische Volksmärchen haben tiefe Weisheit über die menschliche Welt in sich.
<G-vec00442-002-s301><bear.haben><en> We will bring to bear the EU's determined action to deliver a comprehensive response to the sovereign debt crisis: addressing the challenges of vulnerable countries; supporting growth through structural reform and differentiated and growth-friendly fiscal consolidation within the European Semester; strengthening euro area financial firewalls; funding and recapitalising banks; and strengthening economic governance in the euro area.
<G-vec00442-002-s301><bear.haben><de> Wir werden darlegen, welche entschlossenen Maßnahmen wir ergriffen haben, um die Staatsschuldenkrise umfassend anzugehen: Unterstützung gefährdeter Staaten, Wachstumsförderung durch Strukturreformen und eine ausdifferenzierte, wachstumsfreundliche Haushaltskonsolidierung im Rahmen des Europäischen Semesters, Stärkung des Schutzwalls für das Euro-Währungsgebiet, Finanzierung und Rekapitalisierung von Banken und eine konsequentere wirtschaftspolitische Steuerung im Euro-Währungsgebiet.
<G-vec00442-002-s302><bear.haben><en> Undoubtedly these questions bear upon a political dimension, since they require collective action, the traditional purview of modern politics.
<G-vec00442-002-s302><bear.haben><de> Diese Fragen haben zweifellos einen Bezug zu einer politischen Dimension, da sie nach kollektiver Handlung, dem traditionellen Bereich moderner Politik, verlangen.
<G-vec00442-002-s303><bear.haben><en> The prime target of the estate Pavlidis is the production of exceptional wines, which bear the special character of the area.
<G-vec00442-002-s303><bear.haben><de> Dieses Landgut hat unter anderen die Produktion erlesener Weinen als Hauptziel, die den besonderen Charakter des Gebiets haben.
<G-vec00442-002-s304><bear.haben><en> Unter Milchwasser is - like the whole project I in Wonderland - the attempt to combine video art and children theater in times, in which especially young kids bear a high media competence. Entrance free.
<G-vec00442-002-s304><bear.haben><de> Unter Milchwasser ist - wie das gesamte Projekt I in Wonderland - der Versuch, Videokunst und Kindertheater zusammen zu führen, in Zeiten, in denen gerade die Jüngsten schon eine hohe Medienkompetenz haben.
<G-vec00442-002-s305><bear.haben><en> Muslim immigration is the root cause of attacks like those in Copenhagen and Paris, the liberal-conservative daily Jyllands-Posten argues: "Many of the politicians active today bear responsibility for the mass immigration from the Middle East....
<G-vec00442-002-s305><bear.haben><de> Die Einwanderung muslimischer Migranten ist nach Ansicht der rechtsliberalen Tageszeitung Jyllands-Posten Ursache für Anschläge wie in Kopenhagen und Paris: "Viele der jetzt aktiven Politiker haben die Masseneinwanderung aus dem Nahen und Mittleren Osten zu verantworten....
<G-vec00442-002-s306><bear.haben><en> The barrenness of Sarah, Rebekah, and Rachel (the mothers of the Israelite nation) is significant in that their ability to finally bear children was a sign of the grace and favor of God.
<G-vec00442-002-s306><bear.haben><de> Die Unfruchtbarkeit von Sara, Rebekka und Rahel (die Mütter der Nation Israel) ist signifikant, da sie durch die Gnade und den Gefallen Gottes die Fähigkeit Kinder zu bekommen erlangt haben.
<G-vec00442-002-s307><bear.haben><en> 18 Aug 2019 Now that we are ready to have the most important basics for the teddy bear, he needs a task or a situation that will let him plunge into his adventures.
<G-vec00442-002-s307><bear.haben><de> Nachdem wir jetzt soweit sind, dass wir die wichtigsten Basics für den Teddybären haben, braucht er eine Aufgabe oder eine Situation, die ihn in seine Abenteuer stürzen lassen.
<G-vec00442-002-s308><bear.haben><en> New Apostolic parents bear the important responsibility of raising and consolidating their children in faith and in the fear of God.
<G-vec00442-002-s308><bear.haben><de> Eltern haben die Aufgabe, ihre Kinder im Glauben und in Gottesfurcht zu erziehen und zu festigen.
<G-vec00442-002-s309><bear.haben><en> We always bear in mind all packaging processes.
<G-vec00442-002-s309><bear.haben><de> Wir haben alle Verpackungsprozesse im Blick.
<G-vec00442-002-s310><bear.haben><en> Video Walkthrough Description It's your first day at the bear care studio.
<G-vec00442-002-s310><bear.haben><de> Sie haben nach Südafrika gereist, um mit erstaunlichen Tieren zu arbeiten und jetzt ist es Ihr erster Tag an der Erdmännchen Pflege-Studio.
<G-vec00442-002-s311><bear.haben><en> (2) The above-mentioned indemnification will only apply if you bear fault for the violation of the rights in question.
<G-vec00442-002-s311><bear.haben><de> (2) Die vorstehende Haftungsfreistellung gilt nur, soweit Sie die betreffende Rechtsverletzung zu vertreten haben.
<G-vec00442-002-s312><bear.haben><en> Therefore, vocalization of any sort that is out of the ordinary for your pet may indicate that their pain and anxiety has become too much for them to bear.
<G-vec00442-002-s312><bear.haben><de> Daher kann eine Vokalisierung, die für Ihr Haustier ungewöhnlich ist, darauf hinweisen, dass die Schmerzen und ein Angstzustand stark zugenommen haben.
<G-vec00442-002-s313><bear.haben><en> The customers of the three German telecommunication providers that are adopting it should enjoy the convenience of having fewer passwords, but they also need to bear in mind that the system they're using carries its own potential risks.
<G-vec00442-002-s313><bear.haben><de> Die Kunden der drei deutschen Telekommunikationsanbieter, die es übernehmen, sollten den Vorteil genießen, dass sie weniger Passwörter haben.
<G-vec00442-002-s314><bear.haben><en> Matching its surroundings, the organisers focus on topics which bear reference to the rural culture.
<G-vec00442-002-s314><bear.haben><de> Passend zum Spielort fokussieren sich die Veranstalter auf Themen, die einen Bezug zum landschaftlichen Kultur haben.
<G-vec00442-002-s315><bear.haben><en> Lisi and Michael Müller are actively involved: “The difficulty is to take into consideration the regional circumstances and at the same time to bear in mind the fastest and safest track.
<G-vec00442-002-s315><bear.haben><de> Lisi und Michael Müller helfen aktiv mit: „Die Schwierigkeit ist es, auf die regionalen Gegebenheiten Rücksicht zu nehmen und dabei die schnellste und sicherste Route im Hinterkopf zu haben.
<G-vec01185-002-s411><bear.tragen><en> 29 Aaron shall bear the names of the children of Israel in the breastplate of judgment on his heart, when he goes in to the holy place, for a memorial before Yahweh continually.
<G-vec01185-002-s411><bear.tragen><de> 29 Also soll Aaron die Namen der Kinder Israel in dem Brustschildlein für die Rechtspflege auf seinem Herzen tragen, wenn er in das Heilige geht, zum Gedächtnis vor dem HERRN, allezeit.
<G-vec01185-002-s412><bear.tragen><en> In such a case, the customer is not obliged to accept. Distrelec shall bear the cost if such an item is returned by post.
<G-vec01185-002-s412><bear.tragen><de> In diesem Fall ist der Kunde nicht zur Annahme verpflichtet und er hat nicht die Kosten der Rücksendung zu tragen.
<G-vec01185-002-s413><bear.tragen><en> You have to bear the normal costs of return if the delivered goods ordered and if the price of the item to be returned by not exceeding 40 euros or if you are at a higher price of the goods are not at the time of full payment or a contractually agreed part payment provided.
<G-vec01185-002-s413><bear.tragen><de> Sie haben die regelmäßigen Kosten der Rücksendung zu tragen, wenn die gelieferte Ware der bestellten entspricht und wenn der Preis der zurückzusendenden Sache einen Betrag von 40 Euro nicht übersteigt oder wenn Sie bei einem höheren Preis der Sache zum Zeitpunkt des Widerrufs noch nicht die Gegenleistung oder eine vertraglich vereinbarte Teilzahlung erbracht haben.
<G-vec01185-002-s414><bear.tragen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec01185-002-s414><bear.tragen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec01185-002-s415><bear.tragen><en> Our products are EN 13967, EN 13969, EN 13970, EN 14967 and EN 15814 certified, and bear the CE tested quality label.
<G-vec01185-002-s415><bear.tragen><de> Die Produkte sind nach EN 13967, EN 13969, EN 13970, EN 14967 und EN 15814 zertifiziert und tragen das CE-Zeichen für geprüfte Qualität.
<G-vec01185-002-s416><bear.tragen><en> In the Middle Ages, an Estate becomes emancipated as soon as it is allowed to bear a sword.
<G-vec01185-002-s416><bear.tragen><de> Im Mittelalter ist ein Stand emanzipiert, sobald er das Schwert tragen darf.
<G-vec01185-002-s417><bear.tragen><en> Of course, this burden is not ours alone to bear.
<G-vec01185-002-s417><bear.tragen><de> Natürlich können wir diese Last nicht allein tragen.
<G-vec01185-002-s418><bear.tragen><en> And the angels will be on its sides, andeight will, that Day, bear the Throne of thy Lord above them.
<G-vec01185-002-s418><bear.tragen><de> Und die Engel werden zu seinen Seiten stehen,und acht (Engel) werden an jenem Tage den Thron deines Herrn übersich tragen.
<G-vec01185-002-s420><bear.tragen><en> Tools 20 If a man lies with his uncle's wife, he has uncovered his uncle's nakedness: they shall bear their sin; they shall die childless.
<G-vec01185-002-s420><bear.tragen><de> 20 Wenn jemand bei seines Vaters Bruders Weibe schläft, der hat seines Vetters Scham geblößet; sie sollen ihre Sünde tragen: ohne Kinder sollen sie sterben.
<G-vec01185-002-s421><bear.tragen><en> Luke records this as the third temptation: “And he brought him to Jerusalem, and set him on a pinnacle of the temple, and said unto him, If thou be the Son of God, cast thyself down from hence: For it is written, He shall give his angels charge over thee, to keep thee: And in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone.”
<G-vec01185-002-s421><bear.tragen><de> Da führte ihn der Teufel mit sich in die Heilige Stadt und stellte ihn auf die Zinne des Tempels 6 und sprach zu ihm: Bist du Gottes Sohn, so laß dich hinab; denn es steht geschrieben: Er wird seinen Engeln über dir Befehl tun, und sie werden dich auf Händen tragen, auf daß du deinen Fuß nicht an einen Stein stoßest.
<G-vec01185-002-s422><bear.tragen><en> The OFSC can bear 16N.M impact 3 times,there is not any crack.
<G-vec01185-002-s422><bear.tragen><de> Das OFSC kann 16N.M Auswirkung 3mal tragen, dort ist nicht jeder möglicher Sprung.
<G-vec01185-002-s423><bear.tragen><en> The steel plates on top bear the weight of maintenance workers.
<G-vec01185-002-s423><bear.tragen><de> Die Stahlplatten tragen das Gewicht der Wartungstechniker.
<G-vec01185-002-s424><bear.tragen><en> Therefore, thus says the Lord God: I have lifted up my hand, so that the Gentiles, who are all around you, will themselves bear their shame.
<G-vec01185-002-s424><bear.tragen><de> 7 Darum spricht Gott der HERR: Ich hebe meine Hand auf zum Schwur: Wahrlich, eure Nachbarn, die Heiden ringsumher, sollen ihre Schande tragen.
<G-vec01185-002-s425><bear.tragen><en> This type of approach to Galileo would require heavy public financing, as the private sector alone cannot bear this kind of cost with a view to providing a free service for users.
<G-vec01185-002-s425><bear.tragen><de> Ein solches Vorgehen würde im Falle von Galileo bedeuten, dass erhebliche öffentliche Mittel aufgebracht werden müssen, da der Privatsektor allein nicht in der Lage ist, die Kosten zu tragen, die die Bereitstellung eines kostenlosen Dienstes für die Öffentlichkeit zur Folge hätte.
<G-vec01185-002-s426><bear.tragen><en> If the order value is less than 40 EUR, the customer shall bear the dispatch costs and the risks of dispatch, unless the supplied merchandise does not tally with what was ordered.
<G-vec01185-002-s426><bear.tragen><de> Bei einer Rücksendung aus einer Warenlieferung, deren Bestellwert insgesamt bis zu 40,- Euro beträgt, hat der Kunde die Kosten der Rücksendung zu tragen, wenn die gelieferte Ware der Bestellten entspricht.
<G-vec01185-002-s427><bear.tragen><en> The back of the camel can bear only a definite weight on it.
<G-vec01185-002-s427><bear.tragen><de> Der Rücken des Kamels nämlich kann nur eine bestimmte Menge an Last tragen.
<G-vec01185-002-s428><bear.tragen><en> We are well aware of the high level of responsibility we bear in our work.
<G-vec01185-002-s428><bear.tragen><de> Wir wissen, dass wir mit unserer Arbeit eine hohe Verantwortung tragen.
<G-vec01185-002-s429><bear.tragen><en> The sit-to-stand lift Sabina is intended for patients who can bear weight by themselves, but who may have problems standing up or walking.
<G-vec01185-002-s429><bear.tragen><de> Aufstehlifter Der Aufstehlifter Sabina wurde für Pflegebedürftige konzipiert, die ihr Gewicht selbst tragen können, jedoch unter Umständen Probleme beim Aufstehen oder Gehen haben.
