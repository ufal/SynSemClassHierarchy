<G-vec00519-002-s057><connect.anschließen><en> Action zones will demonstrate how to mount and cable drives and sensors, connect them to a controller and integrate them into a central system.
<G-vec00519-002-s057><connect.anschließen><de> In Aktionszonen wird vorgeführt, wie Antriebe und Sensoren montiert, verkabelt, an die Steuerung angeschlossen und in einem zentralen System integriert werden.
<G-vec00519-002-s058><connect.anschließen><en> Quickly and easily connect the Stream Mic to the Xbox One, PS4 Pro and PS4, PC and Mac via universal USB plug-and-play compatibility. Personalized Voice Tuning
<G-vec00519-002-s058><connect.anschließen><de> Dank der universellen Plug-and-Play-Kompatibilität ist das Stream Mic schnell und einfach per USB-Anschluss an Xbox One, PS4™ Pro, PS4™, PC und Mac angeschlossen.
<G-vec00519-002-s059><connect.anschließen><en> While standard relay will connect both batteries as soon as the engines runs, a FET isolator does not directly connect the batteries like that.
<G-vec00519-002-s059><connect.anschließen><de> Manchmal verbindet ein Batterieseparator keine große, aber ungeladene Batteriebank, weil die Gleichspannung sofort unter den Entkopplungswert fällt, sobald die Batterien angeschlossen sind.
<G-vec00519-002-s060><connect.anschließen><en> Naturally, for different shapes and sizes of shower trays it will be necessary to select and correctly connect the drain siphon.
<G-vec00519-002-s060><connect.anschließen><de> Für verschiedene Formen und Größen der Duschwannen muss natürlich der Ablaufsiphon gewählt und richtig angeschlossen werden.
<G-vec00519-002-s061><connect.anschließen><en> Step 1: Connect your Delkin Devices SD card to your computer.
<G-vec00519-002-s061><connect.anschließen><de> Schritt 1: Delkin Devices SD-Karte an den Computer angeschlossen.
<G-vec00519-002-s062><connect.anschließen><en> The network adapter is bus-powered which makes it easy to connect when you’re on the go.
<G-vec00519-002-s062><connect.anschließen><de> Er wird direkt über den USB-Port mit Strom versorgt und kann so unterwegs einfach angeschlossen werden.
<G-vec00519-002-s063><connect.anschließen><en> The outputs are unbalanced RCA and balanced XLR so you can connect professional high power PA systems without worrying about the sound quality.
<G-vec00519-002-s063><connect.anschließen><de> An die unsymmetrischen RCA- und symmetrischen XLR-Ausgänge kann ein professionelles Hochleistungs-PA-System angeschlossen werden, ohne dass die Soundqualität darunter leidet.
<G-vec00519-002-s064><connect.anschließen><en> Plug&Play is used in order to directly connect the TP series to commercially available Internet routers.
<G-vec00519-002-s064><connect.anschließen><de> Mittels Plug&Play wird die TP-Serie direkt an handelsübliche Internet- Router angeschlossen.
<G-vec00519-002-s065><connect.anschließen><en> This allows it to mate to an 6" pipe via flanged connection but connect a 4" pipe instead.
<G-vec00519-002-s065><connect.anschließen><de> Dadurch kann es über eine Flanschverbindung mit einem 6-Zoll-Rohr verbunden werden, stattdessen wird jedoch ein 4-Zoll-Rohr angeschlossen.
<G-vec00519-002-s066><connect.anschließen><en> It's simple to connect to the Miniserver, and allows you to send RS485 commands to any device with an RS485 interface.
<G-vec00519-002-s066><connect.anschließen><de> Einfach an den Miniserver angeschlossen können mit der RS485 Extension Befehle an ein Gerät mit RS485 Schnittstelle gesendet werden.
<G-vec00519-002-s067><connect.anschließen><en> There is no need for him to accidentally connect a malicious device or install malware.
<G-vec00519-002-s067><connect.anschließen><de> Es ist nicht erforderlich, dass ein schädliches Gerät angeschlossen oder Malware installiert wird.
<G-vec00519-002-s068><connect.anschließen><en> switch is the core component of a network – the device that all computers and other network devices connect to.
<G-vec00519-002-s068><connect.anschließen><de> Ein Koppler ist das Kernelement eines Netzwerkes - daran sind alle Computer und andere Netzwerkgeräte eines Netzwerkes angeschlossen.
<G-vec00519-002-s069><connect.anschließen><en> Enabling the system to connect with more dispensers, tanks gauges, third party back office and remotely hosted ERP/head office systems.
<G-vec00519-002-s069><connect.anschließen><de> Kann an zahlreichen Zapfsäulen, Tankinhaltsmesssysteme, externe Büro- und remote gehostete ERP / Zentralsysteme angeschlossen werden.
<G-vec00519-002-s070><connect.anschließen><en> So we have to connect the BT keyboard to the USB port of the PC, so that the state of charge indicator lights up.
<G-vec00519-002-s070><connect.anschließen><de> Also haben wir das BT Keyboard an den USB Port des PCs angeschlossen, womit die Ladezustands LED aufleuchtet.
<G-vec00519-002-s071><connect.anschließen><en> 0,50€ This 6-Pin Stackable Header for Arduino will allow you to easily connect your compatible shields on an Arduino base.
<G-vec00519-002-s071><connect.anschließen><de> 0,50€ Mit diesem stapelbaren 6-Pin-Steckverbinder für Arduino können kompatible Shields kinderleicht an einer Arduino-Platine angeschlossen werden.
<G-vec00519-002-s072><connect.anschließen><en> A while ago I started to experiment with Google Cardboard and noticed a strange problem with my Sony Xperia Z3 Compact: as soon as you connect a headphone the view will jump back to the initial position in some Cardboard applications.
<G-vec00519-002-s072><connect.anschließen><de> Schon vor einer Weile habe ich angefangen, mit Google Cardboard zu experimentieren und ein seltsames Problem mit meinem Sony Xperia Z3 Compact bemerkt: sobald ein Kopfhörer angeschlossen ist, springt die Ansicht in manchen Cardboard-Anwendungen regelmäßig auf die Nullstellung zurück.
<G-vec00519-002-s073><connect.anschließen><en> Once you reach the charging station, connect the vehicle to the charging station with a cable.
<G-vec00519-002-s073><connect.anschließen><de> Nach Erreichen der Ladestation wird das Fahrzeug mit dem Kabel an die Ladestation angeschlossen.
<G-vec00519-002-s074><connect.anschließen><en> If you connect the Brick to the PC over USB, you should see a new tab named "Industrial Analog Out Bricklet" in the Brick Viewer after a moment.
<G-vec00519-002-s074><connect.anschließen><de> Wenn der Brick per USB an den PC angeschlossen wird sollte einen Moment später im Brick Viewer ein neuer Tab namens "Sound Intensity Bricklet" auftauchen.
<G-vec00519-002-s075><connect.anschließen><en> If you connect the Brick to the PC over USB, you should see a new tab named "DMX Bricklet" in the Brick Viewer after a moment.
<G-vec00519-002-s075><connect.anschließen><de> Wenn der Brick per USB an den PC angeschlossen wird sollte einen Moment später im Brick Viewer ein neuer Tab namens "One Wire Bricklet" auftauchen.
<G-vec00519-002-s646><connect.herstellen><en> In XMLSpy, select the menu option Schema design | Connect to SchemaAgent Server or click the Connect to SchemaAgent Server icon in the Schema design toolbar.
<G-vec00519-002-s646><connect.herstellen><de> Wählen Sie in XMLSpy den Menübefehl Schema-Design | Verbindung zu SchemaAgent Server herstellen oder klicken Sie in der Schema-Design-Symbolleiste auf die Schaltfläche Verbindung zu SchemaAgent Server herstellen .
<G-vec00519-002-s647><connect.herstellen><en> PureVPN may occasionally fail to connect to a server.
<G-vec00519-002-s647><connect.herstellen><de> PureVPN kann gelegentlich keine Verbindung zu einem Server herstellen.
<G-vec00519-002-s648><connect.herstellen><en> SD-WAN allows you to orchestrate business and processes, quality of service (QoS) and security policies, as well as application access, regardless of where the worker or the application is, or what physical devices or networks may connect them at the moment of access.
<G-vec00519-002-s648><connect.herstellen><de> Mit SD-WAN lassen sich Business und Prozesse, Servicequalität (QoS) und Sicherheitsrichtlinien sowie der Anwendungszugriff orchestrieren, und zwar unabhängig davon, wo sich der Mitarbeiter oder die Anwendung befindet oder welche physischen Geräte oder Netzwerke während des Zugriffs die Verbindung herstellen.
<G-vec00519-002-s649><connect.herstellen><en> Unless you want to connect to a server in a specific country, you should always choose a server that’s located close to your current location.
<G-vec00519-002-s649><connect.herstellen><de> Wenn Sie keine Verbindung zu einem Server in einem bestimmten Land herstellen möchten, sollten Sie immer einen Server in der Nähe Ihres aktuellen Standorts auswählen.
<G-vec00519-002-s650><connect.herstellen><en> Using a Fluke vibration meter with the Fluke Connect® app, you can share inspection results and authorize next steps from the field, organize your measurements by asset in one location with EquipmentLog™ history, and securely connect and collaborate with others.
<G-vec00519-002-s650><connect.herstellen><de> Wenn Sie ein Schwingungsmessgerät von Fluke zusammen mit der Fluke Connect® App verwenden, können Sie Prüfergebnisse mit dem Team vor Ort gemeinsam nutzen, die Genehmigung zur Durchführung der nächsten Schritte einholen, Ihre Messungen gegliedert nach Gerät in der EquipmentLog™-Historie zentral speichern und mit einem ShareLive™-Videoanruf eine sichere Verbindung mit anderen herstellen, damit sie dieselben Ergebnisse wie Sie sehen können.
<G-vec00519-002-s651><connect.herstellen><en> You will also need to connect to the Internet regularly to keep your version of Office up-to-date and benefit from any bug-fixes.
<G-vec00519-002-s651><connect.herstellen><de> Ihre Desktopversion von Office wird ebenfalls automatisch auf dem neuesten Stand gehalten und aktualisiert, wenn Sie eine Verbindung zum Internet herstellen, damit Sie stets über die neuesten Tools für Ihre Arbeit verfügen.
<G-vec00519-002-s652><connect.herstellen><en> Using the in-built wireless connections that the mobile device has, the player can connect to the gaming servers to play their games online for the chance to win real money jackpots just as big as they could at any other online or brick and mortar casino.
<G-vec00519-002-s652><connect.herstellen><de> Mit Hilfe der im mobilen Gerät eingebauten drahtlosen Konnektivität kann der Spieler die Verbindung zu den Spiel-Servern herstellen, um deren Spiele online zu spielen, für die Chance, echte, genau so große Geld-Jackpots zu gewinnen, wie in jedem Online-Casino oder in jeder Spielbank aus Backstein und Mörtel.
<G-vec00519-002-s653><connect.herstellen><en> VNC Server's authentication scheme is completely separate from your RealVNC® account, so even if a malicious entity learns your account credentials and signs in to VNC Viewer as you, they still cannot connect.
<G-vec00519-002-s653><connect.herstellen><de> Das bedeutet, selbst wenn eine böswillige Entität Ihre Konto-Anmeldeinformationen in Erfahrung bringt und sich unter Ihrem Namen bei VNC Viewer anmeldet, kann sie immer noch keine Verbindung herstellen.
<G-vec00519-002-s654><connect.herstellen><en> If Acrobat can't connect to the cloud, the Save As dialog may not work correctly.
<G-vec00519-002-s654><connect.herstellen><de> Wenn Acrobat keine Verbindung zur Cloud herstellen kann, funktioniert das Dialogfeld „Speichern unter“ möglicherweise nicht ordnungsgemäß.
<G-vec00519-002-s655><connect.herstellen><en> TIP: Your local Rotary club can help you connect with your district.
<G-vec00519-002-s655><connect.herstellen><de> TIPP: Ihr örtlicher Rotary Club kann die Verbindung zum Distrikt herstellen.
<G-vec00519-002-s656><connect.herstellen><en> Well, sometimes can not connect.
<G-vec00519-002-s656><connect.herstellen><de> Nun, das kann manchmal keine Verbindung herstellen.
<G-vec00519-002-s657><connect.herstellen><en> Clients that do not support this level of encryption cannot connect.
<G-vec00519-002-s657><connect.herstellen><de> Clients, die diese Verschlüsselungsstufe nicht unterstützen, können keine Verbindung herstellen.
<G-vec00519-002-s658><connect.herstellen><en> If you turn off traffic for these endpoints, the device will not be able to connect to Windows Update and Microsoft Update to help keep the device secure.
<G-vec00519-002-s658><connect.herstellen><de> Wenn Sie den Datenverkehr für diese Endpunkte deaktivieren, kann das Gerät keine Verbindung mit Windows Update und Microsoft Update herstellen, um das Gerät zu schützen.
<G-vec00519-002-s659><connect.herstellen><en> If your iOS device still won’t connect, you should re-pair your device with the UE BOOM.
<G-vec00519-002-s659><connect.herstellen><de> Kann das iOS-Gerät noch immer keine Verbindung herstellen, pairen Sie das Gerät erneut mit dem UE MINI BOOM.
<G-vec00519-002-s660><connect.herstellen><en> When you later connect to your company network, your changes in Outlook automatically synchronize with SAP.
<G-vec00519-002-s660><connect.herstellen><de> Wenn Sie die Verbindung zum Unternehmensnetzwerk herstellen, synchronisiert Duet automatisch die in Outlook vorgenommenen Änderungen mit SAP.
<G-vec00519-002-s661><connect.herstellen><en> If you can't connect to Xbox Live, sign in with your Xbox Live gamertag.
<G-vec00519-002-s661><connect.herstellen><de> Wenn Sie keine Verbindung zu Xbox Live herstellen können, melden Sie sich mit Ihrem Xbox Live-Gamertag an.
<G-vec00519-002-s662><connect.herstellen><en> However, users whose mailboxes are on Exchange 2016 servers won’t be able to connect to Exchange 2010 public folders from clients that use Exchange Web Services (EWS), such as Outlook for Mac.
<G-vec00519-002-s662><connect.herstellen><de> Benutzer mit Postfächern auf Exchange Server 2013-Servern können allerdings über Clients, die Exchange-Webdienste wie Outlook für Mac verwenden, keine Verbindung zu öffentlichen Ordnern in Exchange 2007 oder Exchange 2010 herstellen.
<G-vec00519-002-s663><connect.herstellen><en> Users cannot connect to the computer that is running Exchange Server.
<G-vec00519-002-s663><connect.herstellen><de> Benutzer können keine Verbindung zu dem Computer herstellen, auf dem Exchange Server ausgeführt wird.
<G-vec00519-002-s664><connect.herstellen><en> This lets Outlook 2007 clients connect to the Client Access server that is closest to a user's mailbox.
<G-vec00519-002-s664><connect.herstellen><de> Dadurch können Outlook 2010 oder Outlook 2007 verwendende Clients die Verbindung zum Postfach eines Benutzers über den Clientzugriffsserver an diesem Standort herstellen.
<G-vec00519-002-s380><connect.schließen><en> If your inaccessible files or folders are on a removable hard drive or flash disk, connect it to a Windows PC where EaseUS hard drive recovery software installed. Make sure the software has detected your device.
<G-vec00519-002-s380><connect.schließen><de> Wenn die nicht zugreifbaren Dateien oder Ordner auf einer externen Festplatte oder einem USB-Stick gespeichert wurden, schließen Sie das Gerät an einen Windows-PC an, und starten Sie dann EaseUS Data Recovery Wizard um eine Datenrettung durchzuführen.
<G-vec00519-002-s381><connect.schließen><en> We will not only connect the server to the internet, but also install operating system Ubuntu LTS Linux, web server Apache, database MySQL, post service Postfix and other software according to your requirements.
<G-vec00519-002-s381><connect.schließen><de> Wir schließen nicht nur den Server ans Internet an, sondern installieren auch das Betriebssystem Ubuntu LTS, Webserver Apache, Datenbankmaschine MySQL, Postdienstleistung Postfix und weitere Software nach Ihrem Wunsch.
<G-vec00519-002-s382><connect.schließen><en> If not, you will not be able to connect the monitor to it.
<G-vec00519-002-s382><connect.schließen><de> Wenn nicht, schließen Sie den Monitor an ihn nicht zu.
<G-vec00519-002-s383><connect.schließen><en> When it does need a boost, simply connect it to a wall outlet or other power source via the cable provided, and it will recharge at 2.4A input.
<G-vec00519-002-s383><connect.schließen><de> Wenn er aufgeladen werden muss, schließen Sie ihn einfach mit dem mitgelieferten Kabel an eine Steckdose oder andere Stromquelle an und das Gerät wird mit bis zu 2,4 A* aufgeladen.
<G-vec00519-002-s384><connect.schließen><en> In our so-called “virtual power station”, we connect up various biogas plants to a large-scale generating unit and market the electricity via our partners and market leaders in this sector: energy2market.
<G-vec00519-002-s384><connect.schließen><de> In unserem sogenannten „virtuellen Kraftwerk“ schließen wir verschiedene Biogasanlagen zu einer großen Erzeugungseinheit zusammen und vermarkten Ihren Strom über unseren Partner und Marktführer in diesem Bereich: energy2market.
<G-vec00519-002-s385><connect.schließen><en> DVI cannot carry audio. To listen to the computer sound, connect the external speaker to the computer’s audio output connector.
<G-vec00519-002-s385><connect.schließen><de> Wenn Sie die Tonsignale des Computers ausgeben möchten, schließen den externen Lautsprecher an den Audioausgang des Computers an.
<G-vec00519-002-s386><connect.schließen><en> With a 10mm square chain you can flexibly connect your bike to a fixed object of your choice when you park.
<G-vec00519-002-s386><connect.schließen><de> Per 10-mm-Vierkantkette schließen Sie Ihr Bike beim Parken flexibel an ein festes Objekt Ihrer Wahl an.
<G-vec00519-002-s387><connect.schließen><en> In case if you would like to get back files from any other storage device then connect it to your iPod with the help of USB data cable.
<G-vec00519-002-s387><connect.schließen><de> Im Fall wenn Sie Dateien von einem anderen Speichermedium zurückbekommen möchten dann schließen sie Ihren iPod mit Hilfe des USB-Kabels.
<G-vec00519-002-s388><connect.schließen><en> ②Touch Interface: Transfer touch signal, connect with micro USB cable, provide touch and power supply function, commonly used to connect computer.
<G-vec00519-002-s388><connect.schließen><de> ②Noten-Schnittstelle: Übergangsnotensignal, schließen an Mikro-USB-Kabel an, liefern die Note und Stromversorgungsfunktion, allgemein verwendet, um Computer anzuschließen.
<G-vec00519-002-s389><connect.schließen><en> And connect ist with a visit to the Bodega Stratvs that will inspire you with world-renowned wines and a very attractive architecture.
<G-vec00519-002-s389><connect.schließen><de> Dem schließen wir uns an und empfehlen gleichfalls die Besichtigung der Bodega Stratvs, die Sie mit weltweit bekannten Spitzenweinen und einer äußerst attraktiven Architektur begeistern wird.
<G-vec00519-002-s390><connect.schließen><en> Connect the power cord for both the Acoustimass module and the music center to a working power outlet
<G-vec00519-002-s390><connect.schließen><de> Schließen Sie ein Ende des Netzkabels an das Acoustimass Modul und das andere Ende an eine Netzsteckdose an.
<G-vec00519-002-s391><connect.schließen><en> This unique adapter cable lets you connect almost any laptop or desktop computer to an HDMI® display or projector.
<G-vec00519-002-s391><connect.schließen><de> Mit diesem einzigartigen Adapterkabel schließen Sie nahezu jeden Laptop oder Desktop-Computer an einen HDMI®-Monitor oder -Projektor an.
<G-vec00519-002-s392><connect.schließen><en> Connect your Bluetooth devices easily and enjoy its 60 W output power.
<G-vec00519-002-s392><connect.schließen><de> Schließen Sie Bluetooth Geräte an und genießen Sie Musik mit 60 W Leistung.
<G-vec00519-002-s393><connect.schließen><en> Around 600 sidings connect industrial and commercial companies, as well as logistics centres, directly to SBB’s rail network.
<G-vec00519-002-s393><connect.schließen><de> Gegen 600 Anschlussgleise schließen Industrie- und Gewerbebetriebe sowie Logistikzentren direkt an das SBB-Schienennetz an.
<G-vec00519-002-s394><connect.schließen><en> You simply connect the transmitter to the signal source, for example a smartphone or CD player, via a mini USB or line connection.
<G-vec00519-002-s394><connect.schließen><de> Den Sender schließen Sie dabei einfach per Mini-USB oder Line-Anschluss an die Signalquelle, zum Beispiel Smartphone oder CD- Player, an.
<G-vec00519-002-s395><connect.schließen><en> Step 1: Open iTunes on Mac or PC, connect your iPhone to your computer.
<G-vec00519-002-s395><connect.schließen><de> Schritt 1: Schließen Sie das iPhone an Mac an und öffnen Sie iTunes.
<G-vec00519-002-s396><connect.schließen><en> But if you want to create a new backup with AnyTrans, please connect your iOS device.
<G-vec00519-002-s396><connect.schließen><de> Aber sofern Sie Daten direkt aufs Gerät wiederherstellen wollen, schließen Ihr Gerät bitte an.
<G-vec00519-002-s397><connect.schließen><en> The connecting strips connect an external Verbin an extension port to which a control valve or the like is connected and which corresponds in ordinary cases, a M4 screw.
<G-vec00519-002-s397><connect.schließen><de> Die Anschlußleisten schließen einen externen Verbin dungsanschluß ein, an den ein Steuerventil oder dergleichen angeschlossen wird und der in gewöhnlichen Fällen einem M4- Schraubanschluß entspricht.
<G-vec00519-002-s398><connect.schließen><en> If you need more volume, at home or on stage, you can easily connect your instrument to a keyboard amplifier.
<G-vec00519-002-s398><connect.schließen><de> Solten Sie zuhaus oder auf der Bühne mehr 'Power' wünschen, schließen Sie Ihr Keyboard an einen Keyboard-Verstärker an.
<G-vec00519-002-s266><connect.treten><en> Across the touchpoints we will offer the consumer compelling and seamless experiences as well as meaningful services and opportunities to connect and interact with our brand.
<G-vec00519-002-s266><connect.treten><de> Das muss ergänzt werden um sinnvolle Dienstleistungen und Möglichkeiten, mit unserer Marke in Kontakt zu treten und zu interagieren.
<G-vec00519-002-s267><connect.treten><en> YouTube has become one of the most popular ways to connect with the X and Y generations, reaching over 100 countries in 80 different languages.
<G-vec00519-002-s267><connect.treten><de> YouTube hat sich zu einer der beliebtesten Möglichkeiten entwickelt, mit der X- und Y-Generation in Kontakt zu treten, und erreicht über 100 Länder in 80 verschiedenen Sprachen.
<G-vec00519-002-s268><connect.treten><en> When you share information with us, for example by creating a User ID, we can make those services even better – to show you more relevant search results and ads, to help you connect with people or to make sharing with others quicker and easier.
<G-vec00519-002-s268><connect.treten><de> Wenn Sie uns Informationen mitteilen, zum Beispiel durch Erstellung eines Google-Kontos, können wir damit diese Dienste noch weiter verbessern – indem wir Ihnen relevantere Suchergebnisse und Werbung anzeigen, Ihnen dabei helfen, mit anderen in Kontakt zu treten oder schneller und einfacher Inhalte mit anderen zu teilen.
<G-vec00519-002-s269><connect.treten><en> el Loa A mystical route that will connect you with nature and your inner self, this is one of the favorite destinations for those who love spiritual life.
<G-vec00519-002-s269><connect.treten><de> 5 Tage in San Pedro de Atacama und Alto el Loa Auf dieser mystischen Rundreise werden Sie in engen Kontakt mit der Natur und Ihrem inneren Selbst treten.
<G-vec00519-002-s270><connect.treten><en> Video ads help businesses connect and interact with consumers on a more personal level.
<G-vec00519-002-s270><connect.treten><de> Videoanzeigen helfen Unternehmen, mit Verbrauchern auf einer persönlicheren Ebene in Kontakt zu treten und zu interagieren.
<G-vec00519-002-s271><connect.treten><en> Regular updates to the PS4 system software bring fresh new features and ways to connect, share and play. A fresh interface
<G-vec00519-002-s271><connect.treten><de> Die regelmäßigen Updates für die PS4-Systemsoftware sorgen für neue Funktionen und Möglichkeiten, mit anderen in Kontakt zu treten, Inhalte zu teilen und zu spielen.
<G-vec00519-002-s272><connect.treten><en> Either way, we seek to connect with our customers in a more personal way.
<G-vec00519-002-s272><connect.treten><de> Wir wollen mit unseren Kunden auf eine besonders persönliche Art in Kontakt treten.
<G-vec00519-002-s273><connect.treten><en> They prove that there is plenty of opportunities to connect with a massive audience.
<G-vec00519-002-s273><connect.treten><de> Sie beweisen, dass es unendlich viele Möglichkeiten gibt, um mit einer riesigen Zielgruppe in Kontakt zu treten.
<G-vec00519-002-s274><connect.treten><en> To achieve this, we team up with you and help you find new ways to connect with your potential and current customers.
<G-vec00519-002-s274><connect.treten><de> Um dies zu steigern, arbeiten wir mit dir zusammen und helfen dir, neue Wege zu finden, um mit deinen potenziellen und aktuellen Kunden in Kontakt zu treten.
<G-vec00519-002-s275><connect.treten><en> The Asana Community Forum lets Asana users and experts connect, share ideas, and help each other thrive.
<G-vec00519-002-s275><connect.treten><de> Das Asana-Community-Forum ermöglicht Asana-Nutzern und -Experten, in Kontakt zu treten, Ideen auszutauschen und sich gegenseitig zu helfen, erfolgreich zu sein.
<G-vec00519-002-s276><connect.treten><en> Retail brands are suffering from accelerating e-commerce adoption and need to find new ways to connect with digital shoppers.
<G-vec00519-002-s276><connect.treten><de> Handelsmarken leiden unter der zunehmenden Akzeptanz des E-Commerce und müssen neue Wege finden, um mit Digital Shoppers in Kontakt zu treten.
<G-vec00519-002-s277><connect.treten><en> Plenty of language learning sites offer forums and message boards where you can connect with other people looking to learn your language.
<G-vec00519-002-s277><connect.treten><de> Viele Sprachlernseiten im Internet bieten Foren an, in denen du mit Deutschlernern in Kontakt treten kannst.
<G-vec00519-002-s278><connect.treten><en> Multichannel marketing allows you to connect with your customers where they want, when they want and how they want.
<G-vec00519-002-s278><connect.treten><de> Durch Multi-Channel-Marketing können Sie mit Ihren Kunden in Kontakt treten, wo, wann und wie diese es wünschen.
<G-vec00519-002-s279><connect.treten><en> You can connect with new friends to help power your geocaching exploration.
<G-vec00519-002-s279><connect.treten><de> Du kannst mit neuen Freunden in Kontakt treten, welche Deine Geocaching Erkundungen unterstützen können.
<G-vec00519-002-s280><connect.treten><en> In addition, we want to give opportunity for all the digital services to connect with the engaged sports enthusiasts of Suunto.
<G-vec00519-002-s280><connect.treten><de> Zudem möchten wir allen digitalen Diensten die Möglichkeit geben, mit den engagierten Suunto Sportbegeisterten in Kontakt zu treten.
<G-vec00519-002-s281><connect.treten><en> There is something mysterious about mushrooms, they have always been used in alchemy and spiritual traditions to connect with the realm beyond our consciousness.
<G-vec00519-002-s281><connect.treten><de> Den Pilzen haftet etwas Geheimnisvolles an, sie wurden von je her in Alchemie und spirituellen Traditionen verwendet, um mit dem Reich jenseits unseres Bewussstseins in Kontakt zu treten.
<G-vec00519-002-s282><connect.treten><en> With millions of active daily players worldwide, support for 26 languages, 90+ payment methods, and pricing in 40 currencies, Steam is the place to reach a global audience and connect with customers.
<G-vec00519-002-s282><connect.treten><de> Mit Millionen an täglich aktiven Spielern weltweit, Unterstützung für 23 Sprachen, 40+ Zahlungsmethoden und Preisgestaltung in 20 Währungen ist Steam der Ort, um eine weltweite Audienz zu erreichen und mit Kunden in Kontakt zu treten.
<G-vec00519-002-s513><connect.verbinden><en> √ Connect with your friends through Facebook and help them grow their kingdom
<G-vec00519-002-s513><connect.verbinden><de> √ Verbinde dich per Facebook mit deinen Freunden und hilf ihnen, ihr Königreich aufzubauen.
<G-vec00519-002-s514><connect.verbinden><en> Simply connect to the I AM and live in this awareness.
<G-vec00519-002-s514><connect.verbinden><de> Verbinde dich einfach nur mit dem ICH BIN und lebe in diesem Gewahrsein.
<G-vec00519-002-s515><connect.verbinden><en> Just connect wirelessly with any PC, making use of the Bluetooth HID protocol.
<G-vec00519-002-s515><connect.verbinden><de> Verbinde dich drahtlos mit jedem PC über das Bluetooth HID-Protokoll.
<G-vec00519-002-s516><connect.verbinden><en> Alternatively, connect to wifi and the ELEMNT will upload your data to the ELEMNT companion app for more detailed reporting on your workout.
<G-vec00519-002-s516><connect.verbinden><de> Alternativ verbinde dich mit einem WLAN und der ELEMNT wird deine Daten mit der Companion App synchronisieren um eine detailiertere Ansicht deines Trainings zu erhalten.
<G-vec00519-002-s517><connect.verbinden><en> Find and compare these Chinese language programs below, and connect with universities throughout China and the world.
<G-vec00519-002-s517><connect.verbinden><de> Finde und vergleiche diese Chinesisch-Programme unten und verbinde dich mit Universitäten in ganz China und der Welt.
<G-vec00519-002-s518><connect.verbinden><en> Connect with her on twitter @navahf and follow #ppcpuppy on Instagram for ppc tips from HK.
<G-vec00519-002-s518><connect.verbinden><de> Verbinde dich mit ihr auf Twitter @navahf und folge #ppcpuppy auf Instagram für ppc Tipps von HK.
<G-vec00519-002-s519><connect.verbinden><en> Connect to the heartbeat of the Earth.
<G-vec00519-002-s519><connect.verbinden><de> Verbinde dich mit dem Herzschlag der Erde.
<G-vec00519-002-s520><connect.verbinden><en> Friends Connect with your friends or find new ones to have more fun on Battle of Glory.
<G-vec00519-002-s520><connect.verbinden><de> Freunde Verbinde dich mit deinen Freunden oder finde neue, um noch mehr Spaß auf Battle of Glory zu haben.
<G-vec00519-002-s521><connect.verbinden><en> Connect via one of these sites.
<G-vec00519-002-s521><connect.verbinden><de> Verbinde dich über einen der folgenden Dienste.
<G-vec00519-002-s522><connect.verbinden><en> Connect to Facebook and challenge your friends.
<G-vec00519-002-s522><connect.verbinden><de> Verbinde dich mit Facebook und fordere deine Freunde heraus.
<G-vec00519-002-s523><connect.verbinden><en> Connect via Wi-Fi and play from your favorite music streaming services, use them as Bluetooth speakers or grab an AUX cord and hook up the turntable.
<G-vec00519-002-s523><connect.verbinden><de> Verbinde dich per WLAN und streame deine Lieblingsmusik, verwende sie als Bluetooth-Lautsprecher oder schnapp dir ein AUX-Kabel und schließe sie an deinen Plattenspieler an.
<G-vec00519-002-s524><connect.verbinden><en> Connect with your partner to find out which first names you both like.
<G-vec00519-002-s524><connect.verbinden><de> Verbinde Dich mit Deiner Partnerin/Deinem Partner, um herauszufinden, welche Vornamen euch beiden gefallen.
<G-vec00519-002-s525><connect.verbinden><en> You can connect with your Facebook or Google account, or register with your email address.
<G-vec00519-002-s525><connect.verbinden><de> Verbinde dich mit deinem Facebook oder Google Konto oder registriere dich mit deiner E-Mail Adresse.
<G-vec00519-002-s526><connect.verbinden><en> HOLY SMOKES - Incense Angel Connect to the world of the heavenly host...
<G-vec00519-002-s526><connect.verbinden><de> HOLY SMOKES - Engelräucherungen Verbinde Dich mit der Welt der himmlischen Heerscharen...
<G-vec00519-002-s527><connect.verbinden><en> Connect to the shared printer from other Mac computers on the network.
<G-vec00519-002-s527><connect.verbinden><de> Verbinde dich von anderen Macs mit dem freigegebenen Drucker im Netzwerk.
<G-vec00519-002-s528><connect.verbinden><en> COMPETE IN LIVE EVENTS Connect to the NBA all year long with campaigns that keep you raining buckets in the most current events.
<G-vec00519-002-s528><connect.verbinden><de> NIMM AN LIVE-EVENTS TEIL Verbinde dich das ganze Jahr mit der NBA, indem du aktuelle Ereignisse im Rahmen von Kampagnen selbst spielst.
<G-vec00519-002-s529><connect.verbinden><en> Connect with friends and make the most of every run and ride.
<G-vec00519-002-s529><connect.verbinden><de> Verbinde dich mit Freunden und hole aus jedem Lauf und jeder Radfahrt das Meiste heraus.
<G-vec00519-002-s530><connect.verbinden><en> CHICAGO IN THE PALM OF YOUR HAND Connect and play LIVE with any Watch_Dogs player logged into their...
<G-vec00519-002-s530><connect.verbinden><de> GANZ CHICAGO IN DEINER HAND Verbinde dich und spiele LIVE mit jedem Watch_Dogs-Spieler, der sich mit...
<G-vec00519-002-s531><connect.verbinden><en> Connect with Personal Trainers, Nutritionist and other Fitness Enthusiasts.
<G-vec00519-002-s531><connect.verbinden><de> Verbinde dich mit Personal Trainern, Ernährungsberater und anderen Fitness-Enthusiasten.
<G-vec00519-002-s703><connect.verknüpfen><en> Follow the steps on screen to connect your vehicle to your account.
<G-vec00519-002-s703><connect.verknüpfen><de> Befolgen Sie die Bildschirmanweisungen, um Ihr Fahrzeug mit Ihrem Account zu verknüpfen.
<G-vec00519-002-s704><connect.verknüpfen><en> Thus we are able to connect the data processed by the above mentioned cookies to our advertising measures and efforts in order to determine and measure the conversion of our advertising efforts and effectiveness of them.
<G-vec00519-002-s704><connect.verknüpfen><de> Dadurch sind wir in der Lage, die von den oben genannten Cookies verarbeiteten Daten mit unseren Werbemaßnahmen und -bemühungen zu verknüpfen, um die Umsetzung unserer Werbemaßnahmen und deren Wirksamkeit zu ermitteln und zu messen.
<G-vec00519-002-s705><connect.verknüpfen><en> Digital Annual Report from Evonik “Creating the exceptional” is the motto of the following pages, where we’d like to present to you some of our ideas that combine disparate themes and connect well thought-out solutions....
<G-vec00519-002-s705><connect.verknüpfen><de> Online-Geschäftsbericht von Evonik Ungewöhnlich kreativ: Unter diesem Motto möchten wir Ihnen auf den folgenden Seiten Ideen vorstellen, die unterschiedliche Themen zusammenbringen und zu durchdachten Lösungen verknüpfen....
<G-vec00519-002-s706><connect.verknüpfen><en> In the dialog box, select the Facebook Ads account(s) to connect to HubSpot, then click Connect.
<G-vec00519-002-s706><connect.verknüpfen><de> Wählen Sie im Dialogfeld die Facebook Ads-Konten aus, die mit der HubSpot-Software verknüpft werden sollen, und klicken Sie auf Verknüpfen.
<G-vec00519-002-s707><connect.verknüpfen><en> We flexibly connect all popular cash register systems and card terminals with each other and ensure that they automatically communicate with each other.
<G-vec00519-002-s707><connect.verknüpfen><de> Wir verknüpfen flexibel alle gängigen Kassen und Kartenterminals miteinander und sorgen dafür, dass die beiden automatisch miteinander kommunizieren.
<G-vec00519-002-s708><connect.verknüpfen><en> In addition, with an extensive mention you can connect the Bedandbreakfast.eu availability calendar to other calendars with the iCal format.
<G-vec00519-002-s708><connect.verknüpfen><de> Daneben können Sie den Verfügbarkeitskalender von Bedandbreakfast.eu mit anderen Kalendern im iCal-Format verknüpfen.
<G-vec00519-002-s709><connect.verknüpfen><en> However, if we combine or connect aggregated data with your personal data so that it can directly or indirectly identify you, we treat the combined data as personal data which will be used in accordance with this privacy notice.
<G-vec00519-002-s709><connect.verknüpfen><de> Wenn wir jedoch aggregierte Daten mit Ihren persönlichen Daten kombinieren oder verknüpfen, um Sie direkt oder indirekt identifizieren zu können, behandeln wir die zusammengefassten Daten als personenbezogene Daten, die gemäß dieser Datenschutzerklärung verwendet werden.
<G-vec00519-002-s710><connect.verknüpfen><en> Grid development 50Hertz is currently planning and implementing a number of transmission line projects to strengthen ist grid and to connect Germany better with the electricity grids of neighbouring countries.
<G-vec00519-002-s710><connect.verknüpfen><de> 50Hertz plant und realisiert derzeit eine Reihe von Leitungsprojekten, um sein Übertragungsnetz zu verstärken und auszubauen und Deutschland besser mit den Stromnetzen der Nachbarländer zu verknüpfen.
<G-vec00519-002-s711><connect.verknüpfen><en> Let’s bear in mind that imagination is the creative faculty of the mind to form and connect images.
<G-vec00519-002-s711><connect.verknüpfen><de> Wir sollten stets bedenken, dass die Vorstellungskraft die kreative Begabung unseres Geistes ist, Bilder zu formen und zu verknüpfen.
<G-vec00519-002-s712><connect.verknüpfen><en> NFC labels made by Norwegian company Thinfilm, a pioneer in this area, connect real objects with the cloud.
<G-vec00519-002-s712><connect.verknüpfen><de> Die NFC-Label von Thinfilm aus Norwegen, einem Vorreiter auf diesem Gebiet, verknüpfen reale Objekte mit der Cloud.
<G-vec00519-002-s713><connect.verknüpfen><en> To object to the transmission and memorisation of the data linked to Amazon.com the subject shall not use on ArredaClick.com, "Amazon Pay" method of payment and must not create or connect himself or herself to "amazon Pay" platform through the insertion of Amazon.com credentials. 14.
<G-vec00519-002-s713><connect.verknüpfen><de> Zur Vermeidung der Übertragung und Speicherung der Daten bezüglich Amazon.com muss der Benutzer auf ArredaClick.com keine "Amzon Pay" Zahlungsmethode wählen und er muss nicht sein Kundenkonto mit der Platform "Amazon Pay" durch Anmeldedaten von Amazon.com anlegen oder verknüpfen.
<G-vec00519-002-s714><connect.verknüpfen><en> If you want to add several user accounts of your social media channel, login to your accounts one after another and connect them to Onlim. 5.
<G-vec00519-002-s714><connect.verknüpfen><de> Wenn Sie mehrere Benutzerkonten eines Social Media Kanals anbinden wollen, loggen Sie sich nacheinander in Ihre Social Media Konten ein und verknüpfen Sie die Konten mit Onlim.
<G-vec00519-002-s715><connect.verknüpfen><en> The students are able to identify, open up, and connect knowledge and material necessary for working on a scientific problem.
<G-vec00519-002-s715><connect.verknüpfen><de> Studierende können notwendiges Wissen und Material zur Bearbeitung eines wissenschaftlichen Problems identifizieren, erschließen und verknüpfen.
<G-vec00519-002-s716><connect.verknüpfen><en> The processes of formation and reconfiguration of fields of knowledge and interaction connect local and national parameters as well as transregional and/or transnational transaction.
<G-vec00519-002-s716><connect.verknüpfen><de> Die Prozesse der Herausbildung und Neukonfiguration von Wissen, Wissensfeldern und Handlung verknüpfen sowohl lokale und / oder nationale Faktoren als auch transregionale und transnacionale Verbindungen und Bewegungen.
<G-vec00519-002-s717><connect.verknüpfen><en> Students are intended to acquire scientific knowledge, which partly includes the curriculum of professional- and business education, and to connect this with professional practical basics, whereby the last is operationalised by standards.
<G-vec00519-002-s717><connect.verknüpfen><de> Ebenso wird angestrebt, fundiertes wissenschaftliches Wissen, das sich teilweise am Kerncurriculum der Sektion für Berufs- und Wirtschaftspädagogik orientiert, mit beruflicher Handlungskompetenz - also "Können" - zu verknüpfen, wobei Letzteres durch Standards operationalisiert wird.
<G-vec00519-002-s718><connect.verknüpfen><en> Recent results now demonstrate that neurons in a brain region that is critically involved in learning and memory processes can connect and form structurally normal networks without active signal transmission at their synaptic contact points.
<G-vec00519-002-s718><connect.verknüpfen><de> Neue Ergebnisse zeigen nun, dass sich Nervenzellen in einer für Lern- und Gedächtnisprozesse wichtigen Gehirnregion auch ganz ohne aktive Signalübertragung an ihren synaptischen Kontaktstellen zu normal strukturierten Netzwerken verknüpfen können.
<G-vec00519-002-s719><connect.verknüpfen><en> Our systems will connect to your domain name to retrieve the SSL Certificate.
<G-vec00519-002-s719><connect.verknüpfen><de> Unsere Systeme werden auf Ihren Domainnamen verknüpfen, um das SSL-Zertifikat abzurufen.
<G-vec00519-002-s720><connect.verknüpfen><en> In the right panel, click the Connect an app tab.
<G-vec00519-002-s720><connect.verknüpfen><de> Klicken Sie im rechten Bereich auf die Registerkarte „App verknüpfen“.
<G-vec00519-002-s721><connect.verknüpfen><en> For those ideas that are more theoretical, figure out how you can connect them to your life experiences and what you've learned from experiments you've conducted in the past.
<G-vec00519-002-s721><connect.verknüpfen><de> Finde bei den theoretischeren Ideen heraus, wie du sie mit den Erfahrungen deines Lebens verknüpfen kannst und was du aus Experimenten, die du in der Vergangenheit durchgeführt hast, lernen kannst.
<G-vec00519-002-s190><connect.vernetzen><en> Join Facebook to connect with Eva Hedman and others you may know.
<G-vec00519-002-s190><connect.vernetzen><de> Tritt Facebook bei, um dich mit Abdallah Mahoo und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s191><connect.vernetzen><en> Join Facebook to connect with Michelle Schramm and others you may know.
<G-vec00519-002-s191><connect.vernetzen><de> Tritt Facebook bei, um dich mit Michelle Schramm und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s192><connect.vernetzen><en> Join Facebook to connect with Michael Larsen and others you may know.
<G-vec00519-002-s192><connect.vernetzen><de> Tritt Facebook bei, um dich mit Michael Larsen und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s193><connect.vernetzen><en> The internet is a fantastic way to connect with other developers.
<G-vec00519-002-s193><connect.vernetzen><de> Das Internet ist ein großartiger Weg, um dich mit anderen Entwicklern zu vernetzen.
<G-vec00519-002-s194><connect.vernetzen><en> Join Facebook to connect with Hania Mir HAnia Mir and others you may know.
<G-vec00519-002-s194><connect.vernetzen><de> Tritt Facebook bei, um dich mit Hania Qafiti und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s195><connect.vernetzen><en> All this, plus the chance to have fun and connect with oilers from all over Europe, to share best practices and create friendships that will last a lifetime.
<G-vec00519-002-s195><connect.vernetzen><de> Erlebe das alles und die Chance, Dich zu amüsieren und Dich mit Ölliebhabern aus ganz Europa zu vernetzen, um die besten Tipps auszutauschen und Freundschaften zu schließen, die ein Leben lang halten werden.
<G-vec00519-002-s196><connect.vernetzen><en> Join Facebook to connect with Selma Aberle and others you may know.
<G-vec00519-002-s196><connect.vernetzen><de> Tritt Facebook bei, um dich mit Christian Aas und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s197><connect.vernetzen><en> Join Facebook to connect with Ras Porn and others you may know.
<G-vec00519-002-s197><connect.vernetzen><de> Tritt Facebook bei, um dich mit Hassan Alazawy und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s198><connect.vernetzen><en> Join Facebook to connect with Tisha Love and others you may know.
<G-vec00519-002-s198><connect.vernetzen><de> Tritt Facebook bei, um dich mit EL Lie und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s199><connect.vernetzen><en> View the profiles of people named Join Facebook to connect with and others you may know.
<G-vec00519-002-s199><connect.vernetzen><de> Tritt Facebook bei, um dich mit Rodolfo Salazar und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s201><connect.vernetzen><en> Join Facebook to connect with RK Kosmetik Papua and others you may know.
<G-vec00519-002-s201><connect.vernetzen><de> Tritt Facebook bei, um dich mit Rüko Baumaschinen und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s202><connect.vernetzen><en> to connect with Patrick Scheu and others you may know.
<G-vec00519-002-s202><connect.vernetzen><de> Tritt Facebook bei, um dich mit Patrick Scheu und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s203><connect.vernetzen><en> View the profiles of people named Join Facebook to connect with and others you may know.
<G-vec00519-002-s203><connect.vernetzen><de> Tritt Facebook bei, um dich mit Igor Bergam und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s204><connect.vernetzen><en> Join Facebook to connect with Pavel Ivanov and others you may know.
<G-vec00519-002-s204><connect.vernetzen><de> Tritt Facebook bei, um dich mit Giorgia Marito und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s205><connect.vernetzen><en> Join Facebook to connect with Marcin Morta and others you may know.
<G-vec00519-002-s205><connect.vernetzen><de> Tritt Facebook bei, um dich mit Fatima-Zlatko Husidic und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s206><connect.vernetzen><en> Join Facebook to connect with Katja Winterberg and others you may know.
<G-vec00519-002-s206><connect.vernetzen><de> Tritt Facebook bei, um dich mit George Manolas und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s207><connect.vernetzen><en> Join Facebook to connect with Eric Abram and others you may know.
<G-vec00519-002-s207><connect.vernetzen><de> Tritt Facebook bei, um dich mit Rainer Abram und anderen Nutzern, die du kennst, zu vernetzen.
<G-vec00519-002-s208><connect.vernetzen><en> Join Facebook to connect with Bianca Soares and others you may know.
<G-vec00519-002-s208><connect.vernetzen><de> Tritt Facebook bei, um dich mit Fahrul Rozi und anderen Nutzern, die du kennst, zu vernetzen.
