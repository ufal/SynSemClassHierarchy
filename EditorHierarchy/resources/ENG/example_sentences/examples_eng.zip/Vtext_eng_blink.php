<G-vec00838-002-s021><blink.blinken><en> Once the new address code is saved the remote's LED will blink twice again
<G-vec00838-002-s021><blink.blinken><de> Sobald der neue Code akzeptiert wurde, blinkt die LED der Fernbedienung zwei Mal.
<G-vec00838-002-s042><blink.blinken><en> The power LED will blink red.
<G-vec00838-002-s042><blink.blinken><de> Die Power-LED beginnt rot zu blinken.
<G-vec00838-002-s077><blink.blinken><en> In addition, experts advise to blink.
<G-vec00838-002-s077><blink.blinken><de> Darüber hinaus beraten Experten zu blinken.
<G-vec00838-002-s078><blink.blinken><en> The third action is optional: arenas using DMX usually have set their settings so that for instance stroboscopes will blink slower than in game.
<G-vec00838-002-s078><blink.blinken><de> Die dritte Aktion ist optional: Arenen mit DMX haben in der Regel ihre Einstellungen so eingestellt, dass zum Beispiel Stroboskope langsamer als im Spiel blinken.
<G-vec00838-002-s079><blink.blinken><en> You can also turn the LED permanently on/off, show a heartbeat or let it blink in sync with the PPS (pulse per second) output of the GPS module.
<G-vec00838-002-s079><blink.blinken><de> Die LED kann auch permanent an/aus gestellt werden, einen Herzschlag anzeigen oder im Rhythmus des PPS (Puls pro Sekunde) Ausgangs des GPS Moduls blinken.
<G-vec00838-002-s080><blink.blinken><en> Quick Blink (about twice every second): TICKR X is paired to a device.
<G-vec00838-002-s080><blink.blinken><de> Schnelles Blinken (etwa zwei Mal pro Sekunde): Der Wahoo RPM SPEED ist mit einem Gerät synchronisiert.
<G-vec00838-002-s081><blink.blinken><en> This may sound silly, but studies show that people who work in front of computers blink up to five times less than normal.
<G-vec00838-002-s081><blink.blinken><de> Das klingt komisch, aber Studien haben erwiesen das Leute die vor einem Computer arbeiten blinken bis zu fünf mal weniger als normal.
<G-vec00838-002-s082><blink.blinken><en> Heroines blink and the impression of liveliness.
<G-vec00838-002-s082><blink.blinken><de> Heroines blinken und der Eindruck von Lebendigkeit.
<G-vec00838-002-s083><blink.blinken><en> The two-color LED (RED / GREEN / OFF, Blink) have separate objects and can query its state.
<G-vec00838-002-s083><blink.blinken><de> Die zweifarbigen LED (ROT/ GRÜN/AUS, Blinken) besitzen separate Objekte und können ihren Zustand abfragen.
<G-vec00838-002-s084><blink.blinken><en> If you blink, you will miss Readsboro, which is a good thing.
<G-vec00838-002-s084><blink.blinken><de> Wenn Sie blinken, verpassen Sie Readsboro, was eine gute Sache ist.
<G-vec00838-002-s085><blink.blinken><en> After a few seconds, the WPS light at the front of the router will start to blink.
<G-vec00838-002-s085><blink.blinken><de> Nach ein paar Sekunden wird die LED auf der Vorderseite des Routers blinken.
<G-vec00838-002-s086><blink.blinken><en> The LEDs blink separately.
<G-vec00838-002-s086><blink.blinken><de> Die LEDs blinken unabhängig voneinander.
<G-vec00838-002-s087><blink.blinken><en> When it's pairing, the pedals will blink in an alternating blue diagonal pattern.
<G-vec00838-002-s087><blink.blinken><de> Bei der Paarung blinken die Blütenblätter in einem abwechselnden blauen diagonalen Muster.
<G-vec00838-002-s088><blink.blinken><en> CONNECTIONS PREPARATION TROUBLESHOOTING OTHERS CONTENTS Downloaded From ManualsPrinter.com Manuals 17 ERROR MESSAGES AND COUNTERMEASURES 2 If, for some reason, printing is not possible or an error occurs during printing, the indicators on the front panel will illuminate or blink.
<G-vec00838-002-s088><blink.blinken><de> INHALT 16 FEHLERMELDUNGEN & ABHILFEMAßNAHMEN 2 Wenn aus irgendeinem Grund der Druckbetrieb nicht möglich sein sollte oder ein Fehler während des Druckbetriebs auftreten sollte, leuchten oder blinken die Anzeigen auf dem Bedienfeld.
<G-vec00838-002-s089><blink.blinken><en> Values from 1 to 9 = single long blink at the moment of reporting motion.
<G-vec00838-002-s089><blink.blinken><de> Werte von 1 bis 9 = einzelnes langes Blinken im Moment des Bewegungsmeldens.
<G-vec00838-002-s090><blink.blinken><en> The hour digits are displayed and begin to blink.
<G-vec00838-002-s090><blink.blinken><de> Die Ziffern für die Stundenanzeige werden angezeigt und blinken.
<G-vec00838-002-s091><blink.blinken><en> When the battery capacity of the Bamboo Stylus fineline reaches 10%, the LED starts to blink red and you will need to recharge.
<G-vec00838-002-s091><blink.blinken><de> Sobald die Akkukapazität des Bamboo Fineline nur noch etwa 15 % beträgt, beginnt die LED rot zu blinken und du solltest den Stift wieder aufladen.
<G-vec00838-002-s092><blink.blinken><en> Click this button and the chassis LEDs of the selected NAS host will blink for easy identification.
<G-vec00838-002-s092><blink.blinken><de> Klicken Sie auf diese Schaltfläche und die Gehäuse-LEDs des ausgewählten NAS-Hosts blinken zur einfachen Identifikation.
<G-vec00838-002-s093><blink.blinken><en> Searching thermostat will blink with blue antenna for several seconds.
<G-vec00838-002-s093><blink.blinken><de> Während dem Suchen wird die blaue Antenne für einige Sekunden blinken.
<G-vec00838-002-s094><blink.blinken><en> Note: If all six buttons blink three times, you entered an invalid code.
<G-vec00838-002-s094><blink.blinken><de> Hinweis: Wenn alle sechs Tasten dreimal blinken, haben Sie einen ungültigen Code eingegeben.
<G-vec00838-002-s095><blink.blinken><en> Along the crowded streets neon lights blink signs for massage parlours, strip shows and escorts. Prostitutes, black, coloured and white - some of them Afrikaner girls from the small towns of the Platteland - stand on street corners or work from escort agencies and hotels like the Quirinale.
<G-vec00838-002-s095><blink.blinken><de> Neben den überfüllten Straßen blinken die Neonlichter der Prostituierte, schwarze, farbige und weiße - einige von ihnen afrikanische Mädchen aus den kleinen Städten der Platteland - stehen an den Straßenecken oder arbeiten bei Escort-Agenturen und Hotels wie das Quirinale.
<G-vec00838-002-s096><blink.blinken><en> The program will just cause a LED to blink.
<G-vec00838-002-s096><blink.blinken><de> Das Programm wird einfach eine LED blinken lassen.
<G-vec00838-002-s098><blink.blinken><en> The LED Alert signal should emit a long blink.
<G-vec00838-002-s098><blink.blinken><de> Das LED-Signal sollte ein langes Blinken zeigen.
<G-vec00838-002-s099><blink.blinken><en> For example, select Blink if you want the cursor to blink.
<G-vec00838-002-s099><blink.blinken><de> Wenn der Cursor beispielsweise blinken soll, aktivieren Sie „Blinken“.
<G-vec00838-002-s104><blink.blinken><en> If you want to drive all the way around the roundabout, then you'll blink right until you get out again, then you'll blink left again.
<G-vec00838-002-s104><blink.blinken><de> Wenn du ganz um den Kreisel fahren möchtest dann blinkst du rechts solange bis du wieder raus fährst, dann blinkst du wieder links.
<G-vec00838-002-s106><blink.blinken><en> The time determines how long a vehicle will blink on the left before it starts.
<G-vec00838-002-s106><blink.blinken><de> Die Zeit bestimmt, wie lange ein Fahrzeug links blinkt, bevor es losfährt.
<G-vec00838-002-s107><blink.blinken><en> Hub blink for locating network port by the flashing port light on Hub / Switch.
<G-vec00838-002-s107><blink.blinken><de> Hub blinkt zum Lokalisieren des Netzwerkanschlusses durch die blinkende Anschlussleuchte am Hub / Switch.
<G-vec00838-002-s108><blink.blinken><en> He looks in and sees Modell shackled to his bed, the red light continues to blink.
<G-vec00838-002-s108><blink.blinken><de> Er sieht Modell durch das Zellenfenster gefesselt an seinem Bett liegen, das rote Alarmlicht blinkt weiter.
<G-vec00838-002-s109><blink.blinken><en> If someone writes to one of these, the window will blink.
<G-vec00838-002-s109><blink.blinken><de> Wenn dort jemand was schreibt, blinkt das Fenster auf.
<G-vec00838-002-s110><blink.blinken><en> The blue WPS status LED above the button will blink.
<G-vec00838-002-s110><blink.blinken><de> Die blaue WPS-Status-LED über der Taste blinkt.
<G-vec00838-002-s111><blink.blinken><en> If something is wrong (SiteSpeed could not save the measurement in the logfile) then the icon will blink "error" in red.
<G-vec00838-002-s111><blink.blinken><de> Wenn etwas falsch ist (SiteSpeed konnte nicht die Messung in der Logdatei speichern) wird das Symbol "Fehler" in rot blinkt.
<G-vec00838-002-s112><blink.blinken><en> Then press and hold the button TIME SET until the display starts to blink regularly.
<G-vec00838-002-s112><blink.blinken><de> Halten Sie den Knopf TIME SET solange gedrückt bis die Anzeige blinkt.
<G-vec00838-002-s113><blink.blinken><en> During the few seconds of shutdown, but before power is removed from the main logic board, the SIL remains on and will not blink.
<G-vec00838-002-s113><blink.blinken><de> Während der wenigen Sekunden des Ausschaltens, aber bevor die Hauptplatine nicht mehr mit Strom versorgt wird, bleibt die Ruhezustandsanzeige eingeschaltet, blinkt jedoch nicht.
<G-vec00838-002-s114><blink.blinken><en> When the lamp operation time exceeds 3000 hours*1, the indicator will blink alternately between green and red (while the lamp is lit; when the lamp is not lit, the indicator will be lit red only) and the lamp replacement message will appear on the screen for 1 minute every time the lamp is turned on.
<G-vec00838-002-s114><blink.blinken><de> Übersteigt die Lampenbetriebszeit 3000 Stunden*1, blinkt die Anzeige abwechselnd grün und rot (solange die Lampe leuchtet; ist sie aus, leuchtet die Anzeige nur rot) und die Meldung zum Auswechseln der Lampe wird bei jedem Einschalten der Lampe 1 Minute lang angezeigt.
<G-vec00838-002-s115><blink.blinken><en> While cleaning is in progress, the respective cleaning program diode will blink.
<G-vec00838-002-s115><blink.blinken><de> Während das Reinigungsprogramm läuft, blinkt die entsprechende Leuchtdiode.
<G-vec00838-002-s116><blink.blinken><en> When starting up with an SD card inserted, the time to detect the SD card is now 1 second, which speeds up booting considerably, and the SD LED does not blink anymore during startup.
<G-vec00838-002-s116><blink.blinken><de> Wenn mit einer eingelegten SD-Karte gebooted wird, ist die Zeitspanne für die Erkennung der SD-karte nun auf 1 Sekunde verkürzt, und die LED am SD-Slot blinkt nicht mehr.
<G-vec00838-002-s117><blink.blinken><en> The WPS light (small light above WPS button) will blink green while it listens for your Wi-Fi device.
<G-vec00838-002-s117><blink.blinken><de> Die WPS-Anzeige (LED über der WPS-Taste) blinkt grün auf, während sie auf das Wi-Fi-Gerät wartet.
<G-vec00838-002-s118><blink.blinken><en> Caution! If you turn the programme selector dial to another programme when the machine is working, the red pilot light of button 8 will blink 3 times and the message Err is displayed to indicate a wrong selection.
<G-vec00838-002-s118><blink.blinken><de> Programmwahlschalter 1 Wird der Programmwahlschalter auf ein anderes Programm gestellt, während die Maschine arbeitet, blinkt die rote Kontrolllampe der Taste 9 3 Mal, und im Display erscheint die Meldung Err, um auf die falsche Auswahl aufmerksam zu machen.
<G-vec00838-002-s119><blink.blinken><en> A correct exposure will be obtained as long as the shutter speed and aperture display do not blink.
<G-vec00838-002-s119><blink.blinken><de> 3 Überprüfen Eine Standardbelichtung ist garantiert, solange die Anzeige für die Verschlusszeit oder den Blendenwert nicht blinkt.
<G-vec00838-002-s120><blink.blinken><en> After reading card Number, the buzzer will sound and the red LED will blink inside the panel.
<G-vec00838-002-s120><blink.blinken><de> Nach dem Lesen der Karte Nummer, Der Summer ertönt und die rote LED blinkt in der Anzeige.
<G-vec00838-002-s121><blink.blinken><en> Wait a few seconds until a long blink of the LED indicator.
<G-vec00838-002-s121><blink.blinken><de> Warten Sie einige Sekunden, bis die LED-Anzeige lange blinkt.
<G-vec00838-002-s122><blink.blinken><en> On/Off status: LED will blink green once when powered on and blink red once when powered off.
<G-vec00838-002-s122><blink.blinken><de> Ein-/Ausschalten: Die LED blinkt einmal grün, wenn das Gerät eingeschaltet wird und einmal rot, wenn der Tracker ausgeschaltet wird.
<G-vec00838-002-s123><blink.blinken><en> If the string is tuned ideally, the chromatic tuner will blink green.
<G-vec00838-002-s123><blink.blinken><de> Blinkt der Tuner rot, muss die Saite weiter gestimmt werden.
<G-vec00838-002-s124><blink.blinken><en> The external power light on the control panel will blink once the battery is fully depleted.
<G-vec00838-002-s124><blink.blinken><de> Die Lampe für die externe Stromversorgung am Bedienfeld blinkt einmal auf, wenn der Akku vollständig leer ist.
<G-vec00838-002-s125><blink.blinken><en> Basic Photography and Playback: Easy Auto Mode 24 Step 3 Focus and Shoot B During Recording While pictures are being recorded, the number of exposures remaining display will blink.
<G-vec00838-002-s125><blink.blinken><de> Fotografieren und Bildwiedergabe: Modus A (Automatik) 26 Schritt 3 Scharfstellen und Auslosen B Wahrend des Speicherns Wahrend des Speicherns von Bildern blinkt die Anzeige fur die Anzahl der verbleibenden Aufnahmen.
<G-vec00838-002-s126><blink.blinken><en> *1: Pressing any button makes clock display blink for 2 seconds but the recorder does not start.
<G-vec00838-002-s126><blink.blinken><de> *1: Durch Drücken einer beliebigen Taste blinkt die Uhranzeige für 2 Sekunden, der Recorder wird jedoch nicht gestartet.
<G-vec00838-002-s208><blink.blinken><en> The LED lights next to the power button blink red and green three times.
<G-vec00838-002-s208><blink.blinken><de> Die LED-Anzeigen neben der Haupttaste blinken dreimal von rot zu grün.
<G-vec00838-002-s226><blink.blinken><en> Sexy, glam or trendy, Blink creations will make the best of your looks!
<G-vec00838-002-s226><blink.blinken><de> Sexy, glamourös und trendy, die Modelle von Blink setzen Ihrem Look das Krönchen auf.
<G-vec00838-002-s253><blink.blinken><en> The product is now in pairing mode; The Under Bed Light will blink to indicate this
<G-vec00838-002-s253><blink.blinken><de> Das Produkt ist jetzt im Kopplungsmodus (das Unterbettlicht blinkt, um dies anzuzeigen).
<G-vec00838-002-s127><blink.blinzeln><en> I blink in a catalogue*...
<G-vec00838-002-s127><blink.blinzeln><de> Ich blinzel in einen Katalog*...
<G-vec00838-002-s128><blink.blinzeln><en> Maintain eye contact, keep your posture relaxed but straight (preferably standing with one foot slightly in front) and don't blink or look away a lot.
<G-vec00838-002-s128><blink.blinzeln><de> Schaue der Person in die Augen, habe eine entspannte aber aufrechte Körperhaltung (vorzugsweise mit einem Fuß vor dem anderen, wenn du stehst) und blinzele nicht oder schaue nicht oft weg.
<G-vec00838-002-s129><blink.blinzeln><en> If a blink exists, a mention message will pop up and ask you to save or cancel the picture.
<G-vec00838-002-s129><blink.blinzeln><de> Sollte ein Blinzeln vorhanden sein, wird eine Meldung erscheinen und Sie fragen, ob Sie das Bild speichern oder verwerfen möchten.
<G-vec00838-002-s130><blink.blinzeln><en> Tears burned her eyes but she couldn’t blink, couldn’t look away.
<G-vec00838-002-s130><blink.blinzeln><de> Tränen brannten in ihren Augen, aber sie konnte nicht blinzeln, nicht wegsehen.
<G-vec00838-002-s131><blink.blinzeln><en> Do not blink.
<G-vec00838-002-s131><blink.blinzeln><de> Nicht blinzeln.
<G-vec00838-002-s132><blink.blinzeln><en> Auto Blink behavior This behavior automatically triggers a layer, such as eyelids that blink or lights that you want to flicker.
<G-vec00838-002-s132><blink.blinzeln><de> Auto-Blinzeln-Verhalten Dieses Verhalten löst automatisch eine Ebene wie das Blinzeln von Augenlidern oder das Flackern von Lichtern aus.
<G-vec00838-002-s133><blink.blinzeln><en> **Flaw detection detects Eye Blink, Facial Blur and Backlight.
<G-vec00838-002-s133><blink.blinzeln><de> **Mängelerkennung erkennt Blinzeln, unscharfe Gesichter, Hintergrundbeleuchtung.
<G-vec00838-002-s134><blink.blinzeln><en> She gets eye drops so that her eyes won’t dry out under anaesthesia where most animals have their eyes open but can’t blink.
<G-vec00838-002-s134><blink.blinzeln><de> Sie bekommt wie alle Patienten Augentropfen, damit die Bindehaut nicht austrocknet in der Narkose, wo die meisten Tiere die Augen offen haben, aber nicht blinzeln.
<G-vec00838-002-s135><blink.blinzeln><en> A weak blink.
<G-vec00838-002-s135><blink.blinzeln><de> Ein schwaches Blinzeln.
<G-vec00838-002-s136><blink.blinzeln><en> Then almost like the next blink, I was in a huge glass house almost like something you see at the botanical gardens like the greenhouse.
<G-vec00838-002-s136><blink.blinzeln><de> Dann fast wie das nächste Blinzeln, war ich in einem riesigen Glashaus, fast wie etwas das man in botanischen Gärten sieht, wie ein Treibhaus.
<G-vec00838-002-s137><blink.blinzeln><en> During such practice, we may blink normally, without staring.
<G-vec00838-002-s137><blink.blinzeln><de> Während dieser Übungen sollten wir normal blinzeln, nicht starren.
<G-vec00838-002-s138><blink.blinzeln><en> Warrior’s eyes will now blink in combat stance.
<G-vec00838-002-s138><blink.blinzeln><de> Die Augen des Kriegers werden nun in der Kampfhaltung blinzeln.
<G-vec00838-002-s139><blink.blinzeln><en> It uses the power of your natural blink to help keep your lens in the right position, giving you clear, stable vision.
<G-vec00838-002-s139><blink.blinzeln><de> Diese nutzt das natürliche Blinzeln, um Ihre Linse in der richtigen Position zu halten und Ihnen so eine klare, stabile Sicht zu ermöglichen.
<G-vec00838-002-s140><blink.blinzeln><en> Liars tend to blink nervously, and it’s an easy sign for people to notice.
<G-vec00838-002-s140><blink.blinzeln><de> Lügner blinzeln meist nervös, was für andere ein deutliches Zeichen sein könnte.
<G-vec00838-002-s141><blink.blinzeln><en> Every blink of their beautiful eyes strike my heart.
<G-vec00838-002-s141><blink.blinzeln><de> Jedes Blinzeln ihrer schönen Augen schlagen mein Herz.
<G-vec00838-002-s142><blink.blinzeln><en> Click your left-mouse button to blink accordingly.
<G-vec00838-002-s142><blink.blinzeln><de> Klicken Sie mit der linken Maustaste um Ihren Charakter blinzeln zu lassen.
<G-vec00838-002-s143><blink.blinzeln><en> For example, the fetus, thanks to the work of the visual organs, is already able to react actively to light: if the light is too bright and falls on the pregnant woman's belly, the fruit will blink and even turn away from the source of the disturbing light.
<G-vec00838-002-s143><blink.blinzeln><de> Zum Beispiel kann der Fötus dank der Arbeit der Sehorgane bereits aktiv auf Licht reagieren: Wenn das Licht zu hell ist und auf den Bauch der schwangeren Frau fällt, wird die Frucht blinzeln und sich sogar von der Quelle des störenden Lichts abwenden.
<G-vec00838-002-s144><blink.blinzeln><en> It may sound obvious, but when using digital devices, we blink five times less than normally.
<G-vec00838-002-s144><blink.blinzeln><de> Das mag offensichtlich sein, aber bei der Verwendung digitaler Geräte blinzeln wir fünfmal weniger als normal.
<G-vec00838-002-s145><blink.blinzeln><en> Some people tend to blink rapidly when they're under stress.
<G-vec00838-002-s145><blink.blinzeln><de> Manche Leute blinzeln sehr schnell und oft, wenn sie gestresst sind.
<G-vec00838-002-s146><blink.blinzeln><en> She had been running away from catastrophe, and turned to see the dread figure of Kozilek...and then there was a blank space, a momentary blink, and now her soldiers were dead, and only she was alive.
<G-vec00838-002-s146><blink.blinzeln><de> Sie war vor der Katastrophe geflohen und hatte sich umgewandt, um die grauenvolle Gestalt Kozileks anzusehen... und dann war da nur eine leere Seite im Buch ihres Gedächtnisses, ein kurzes Blinzeln, und nun waren ihre Krieger tot und sie allein war noch am Leben.
<G-vec00838-002-s147><blink.blinzeln><en> I turn her hand palm up, and before she gets a chance to blink I swat the center of her palm with a riding crop which she now notices.
<G-vec00838-002-s147><blink.blinzeln><de> Ich drehe ihre Handfläche nach oben und bevor sie eine Chance hat zu blinzeln, schlage ich ihr mit der Reitgerte auf die Handfläche, die sie nun bemerkt.
<G-vec00838-002-s152><blink.blinzeln><en> Nobody dreams when they blink
<G-vec00838-002-s152><blink.blinzeln><de> Niemand träumt, wenn er blinzelt.
<G-vec00838-002-s157><blink.blinzeln><en> Take a nice long blink and close your eyes tightly right before the contest begins.
<G-vec00838-002-s157><blink.blinzeln><de> Blinzle ganz lange und schließe deine Augen komplett, bevor der Kampf beginnt.
<G-vec00838-002-s181><blink.blinzeln><en> Being did not even blink once.
<G-vec00838-002-s181><blink.blinzeln><de> Das Sein hat nicht einmal geblinzelt.
<G-vec00838-002-s213><blink.blinzeln><en> These are the calories your body needs to stay warm and perform basic function like blink your eyes or beat your heart.
<G-vec00838-002-s213><blink.blinzeln><de> Das sind die Kalorien, die Ihr Körper für Grundfunktionen verbraucht, wie Halten der Körpertemperatur, Blinzeln mit den Augen oder Herzschlag.
<G-vec00838-002-s225><blink.blinzeln><en> I knew I had to make eye contact with one of them, I barely had strength to blink my eyes repeatedly, but I did.
<G-vec00838-002-s225><blink.blinzeln><de> Ich wusste ich musste Augenkontakt mit einem von ihnen herstellen, ich hatte kaum die Kraft, mehrere Male mit meinen Augen zu blinzeln, aber es gelang.
<G-vec00838-002-s276><blink.blinzeln><en> When your gaze settles on someone you find attractive, you tend to blink more.
<G-vec00838-002-s276><blink.blinzeln><de> Wenn dein Blick auf jemandem zur Ruhe kommt, den du attraktiv findest, wirst du tendenziell mehr blinzeln.
<G-vec00838-002-s154><blink.blinzen><en> When I play it, I don’t blink.
<G-vec00838-002-s154><blink.blinzen><de> Wenn ich es spiele, blinzle ich nicht.
<G-vec00838-002-s155><blink.blinzen><en> I briefly blink, nod to the Pinakothek der Moderne, and then: off I go.
<G-vec00838-002-s155><blink.blinzen><de> Ich blinzle kurz, nicke der Pinakothek der Moderne zu, und dann geht´s los.
<G-vec00838-002-s156><blink.blinzen><en> If you're supposed to be near tears, blink hard, look downwards, fiddle with your clothes, and try to stare without blinking until your eyes water.
<G-vec00838-002-s156><blink.blinzen><de> Wenn du weinen oder den Tränen nahen sein sollst, blinzle viel, schaue nach unten und spiele an deiner Kleidung herum.
<G-vec00838-002-s256><blink.wechseln><en> Brunettes can be super kinky, so don’t be shocked if all of a sudden she goes from vanilla to fetish in the blink of an eye.
<G-vec00838-002-s256><blink.wechseln><de> Brünetten können super pervers sein, also wundere dich nicht, wenn sie plötzlich von brav zu Fetisch wechselt.
<G-vec00838-002-s277><blink.zwinkern><en> Blink a few times and look to the point farthest possible (best if it is in line with the other two points).
<G-vec00838-002-s277><blink.zwinkern><de> Zwinkere ein paar Mal und schaue zu dem für dich weit entferntesten Punkt, welcher sich nach Möglichkeit in einer Linie mit den anderen beiden befindet.
