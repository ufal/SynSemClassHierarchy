<G-vec00206-001-s380><average.mitteln><en> On average, 40 to 50 students participate in the Solar System School's program at any given time.
<G-vec00206-001-s380><average.mitteln><de> Im Mittel nehmen zwischen 40 und 50 DoktorandInnen gleichzeitig am Programm der Solar System School teil.
<G-vec00206-001-s381><average.mitteln><en> In average, the Holstein breed is not as good for fitness traits as some other breeds.
<G-vec00206-001-s381><average.mitteln><de> Die Holsteinrasse ist im Mittel für die Fitnessmerkmale vielleicht nicht ganz so gut wie andere Rassen.
<G-vec00206-001-s382><average.mitteln><en> The map shows the difference between snow cover duration in winter 2017/2018 compared with the long-term average (2000-2017).
<G-vec00206-001-s382><average.mitteln><de> Die Karte zeigt die Differenz zwischen der Schneebedeckungsdauer im Winter 2017/2018 zum langjährigen Mittel (2000-2017).
<G-vec00206-001-s383><average.mitteln><en> On the other hand, in the lagoons of some of the great southern Maldiva atolls, although thickly studded with reefs, every one without exception rises to the surface; and on an average there are less than two submerged reefs in each atoll: in the northern atolls, however, the submerged lagoon-reefs are not quite so rare.
<G-vec00206-001-s383><average.mitteln><de> Andrerseits erhebt sich in den Lagunen einiger der groszen südlichen Maldiva Atollo, trotz- dem sie dicht mit Riffen besetzt sind, jedes einzelne derselben ohne Ausnahme bis zur Oberfläche; und im Mittel gibt es nur weniger als zwei untergetauchte Riffe in jedem Atoll; in den nördlichen Atollen sind indessen die untergetauchten Lagunen-Riffe nicht ganz so selten.
<G-vec00206-001-s384><average.mitteln><en> In the last two decades the climatic conditions and thus the habitats of butterflies and bird in Europe have shifted northwards by an average of 249 km.
<G-vec00206-001-s384><average.mitteln><de> In den letzten beiden Jahrzehnten haben sich die Lebensräume der Tagfalter und Vögel in Europa im Mittel um 249 Kilometer nach Norden verschoben.
<G-vec00206-001-s385><average.mitteln><en> On an average of the last five years, employment in the last quarter of a year rose by just 165,000 people.
<G-vec00206-001-s385><average.mitteln><de> Im Mittel der letzten fünf Jahre hatte sich die Erwerbstätigkeit im letzten Quartal eines Jahres lediglich um 165 000 Personen erhöht.
<G-vec00206-001-s386><average.mitteln><en> Although the composition of an average body shows 50 to 60% fluid content, the distribution of fluid in our body's tissues varies considerably.
<G-vec00206-001-s386><average.mitteln><de> Im Mittel besteht der menschliche Körper zu 50 - 60% aus Wasser, allerdings schwankt der Wassergehalt in den verschiedenen Geweben erheblich.
<G-vec00206-001-s387><average.mitteln><en> Climate change has thus far led to a global average temperature increase of about one degree Celsius.
<G-vec00206-001-s387><average.mitteln><de> Der Klimawandel hat bisher zu einer Temperaturerhöhung um knapp ein Grad Celsius im globalen Mittel geführt.
<G-vec00206-001-s388><average.mitteln><en> These results do not contradict an anthropogenic climate change, which is causing the temperatures on Earth to increase on average.
<G-vec00206-001-s388><average.mitteln><de> Einem vom Menschen erzeugten Klimawandel, der die Temperaturen auf der Erde im Mittel ansteigen lässt, widersprechen diese Ergebnisse nicht.
<G-vec00206-001-s389><average.mitteln><en> For instance, immigration to Germany contributed an average of around 0.2 percentage point to growth between 2001 and 2017.
<G-vec00206-001-s389><average.mitteln><de> Beispielsweise betrug der Wachstumsbeitrag der Zuwanderung nach Deutschland im Mittel der Jahre 2001 bis 2017 rund 0,2 Prozentpunkte.
<G-vec00206-001-s390><average.mitteln><en> The evaluation of this data revealed that human milk samples in 1997 contained on average 60% less dioxins and furans than in 1990.
<G-vec00206-001-s390><average.mitteln><de> Die Auswertung dieser Daten ergab, dass Frauenmilchproben 1997 im Mittel ungefähr 60% weniger Dioxine und Furane enthielten als noch 1990.
<G-vec00206-001-s391><average.mitteln><en> On average each formwork was in use 66 times.
<G-vec00206-001-s391><average.mitteln><de> Im Mittel war jede Schalung 66 Mal im Einsatz.
<G-vec00206-001-s392><average.mitteln><en> For conformation (RZE 112, feet and legs 114) the value for overall udder is just average (102).
<G-vec00206-001-s392><average.mitteln><de> Im Exterieur (RZE 112, Fundament 114) ist der Wert für Gesamt-Euter mit 102 nur gut Mittel.
<G-vec00206-001-s393><average.mitteln><en> Both sexes have horns which are very long, and on average 100 cm, maximum can measure up to 164.8 cm.
<G-vec00206-001-s393><average.mitteln><de> Beide Geschlechter tragen Hörner, die sehr lang sind, und im Mittel 100 cm, maximal bis zu 164,8 cm messen können.
<G-vec00206-001-s394><average.mitteln><en> On average across the 26 Member States which participated in the study, 22.4 percent of the herds stocks tested positive for MRSA.
<G-vec00206-001-s394><average.mitteln><de> Im Mittel der 26 Staaten, die an der Untersuchung teilnahmen, waren 22,4 Prozent der Bestände positiv für MRSA, wie aus dem von der EFSA heute veröffentlichten Bericht zur EU-weiten Studie hervorgeht.
<G-vec00206-001-s395><average.mitteln><en> Climate models indicate that the local warming over Greenland is likely7 to be one to three times the global average.
<G-vec00206-001-s395><average.mitteln><de> Klimamodelle weisen darauf hin, dass die lokale Erwärmung über Grönland wahrscheinlich einbis dreimal so hoch sein wird wie das globale Mittel.
<G-vec00206-001-s396><average.mitteln><en> The buildings are with OKFF of the uppermost floor of 32.30 above terrain on average skyscrapers / special buildings of building class 5.
<G-vec00206-001-s396><average.mitteln><de> Die Gebäude sind mit OKFF des obersten Aufenthaltsgeschosses von 32.30 über Gelände im Mittel Hochhäuser/ Sonderbauten der Gebäudeklasse 5.
<G-vec00206-001-s397><average.mitteln><en> Data compiler Markit reported that manufacturing and service activity shrank faster in February than in January, and even the European Commission forecast a 0.3% contraction for 2013 and increases in unemployment, expected to average 12.2% across the zone.
<G-vec00206-001-s397><average.mitteln><de> Das Datenanalyseunternehmen Markit berichtet, dass der Industrie- und der Dienstleistungssektor im Februar schneller geschrumpft sind als im Januar und sogar die Europäische Kommission sagt einen Rückgang der Wirtschaftsleistung um 0,3% für 2013 und einen Anstieg der Arbeitslosigkeit auf im Mittel des Euroraums auf 12,2% voraus.
<G-vec00206-001-s398><average.mitteln><en> Physical preparation: Average, with a climb on difficult ground up to the panoramic ring route (altitude of 295 m)
<G-vec00206-001-s398><average.mitteln><de> Körperliche Vorbereitung: Mittel, Aufstieg auf anspruchsvollem Boden bis zum Panoramaring (Höhe 295 m).
