<G-vec00380-003-s048><brush_off.auffrischen><en> Some want to brush up their English to be ready for the next vacation in an English-speaking country, others just want to keep their brain fit.
<G-vec00380-003-s048><brush_off.auffrischen><de> Manche möchten ihr Englisch auffrischen, um für den nächsten Urlaub in einem englischsprachigen Land gewappnet zu sein, andere wollen einfach nur ihr Gehirn fit halten.
<G-vec00380-003-s049><brush_off.auffrischen><en> Clear explanations, interactive learning, and immediate feedback make it easy for you to brush up on your math skills.
<G-vec00380-003-s049><brush_off.auffrischen><de> Anschauliche Erklärungen, interaktives Lernen und sofortige Rückmeldungen unterstützen beim Auffrischen der Mathematikkenntnisse.
<G-vec00380-003-s050><brush_off.auffrischen><en> Whether you’re new to the markets or just looking to brush up on your skills, we offer a range of resources to help you find opportunities – and take your trading to the next level.
<G-vec00380-003-s050><brush_off.auffrischen><de> Egal, ob Sie neu an den Märkten sind oder einfach nur Ihre Fähigkeiten auffrischen möchten, wir bieten eine Reihe von Tools und Ressourcen, die Ihnen helfen, den nächsten Schritt auf Ihrer Trading-Reise zu machen.
<G-vec00380-003-s051><brush_off.auffrischen><en> Whether you want to improve your Spanish speaking skills before joining a Spanish immersion course in Latin America, brush up the Spanish that you learned during your last Spanish learning vacation, or you just don't have the time right now for a Spanish Course in Central or South America, you can still benefit from Online Spanish Lessons via Skype from the comfort and convenience of your office or home in the United States, Canada, Europe, Panama City or anywhere in the world.
<G-vec00380-003-s051><brush_off.auffrischen><de> Ob Sie Ihr Spanisch vor Ihrem Immersionsprogramm in Lateinamerika verbessern wollen, oder Ihr Spanisch vom letzten Sprachurlaub auffrischen möchten, oder ob Sie einfach keine Zeit für einen Spanischkurs in Zentral- oder Südamerika haben - Sie können jetzt an unserem Online Spanischunterricht via Skype bequem von Ihrem Büro oder von zu Hause aus teilnehmen.
<G-vec00380-003-s052><brush_off.auffrischen><en> A useful reference point for players that want to brush up on their rules is the 1990 publication "United States Backgammon Tournament Rules and Procedures."
<G-vec00380-003-s052><brush_off.auffrischen><de> Spieler die ihr Gedächtnis auffrischen möchten, können die Publikation von 1990 “United States Backgammon Regeln und Prozeduren” einsehen.
<G-vec00380-003-s053><brush_off.auffrischen><en> If necessary, you can brush up on the hue of the material by is a list of our Sales-Partner!
<G-vec00380-003-s053><brush_off.auffrischen><de> Bei Bedarf können Sie den Farbton des Materials durch Anwendung von Resysta Top Care Oil (RTCO) einmal jährlich wieder auffrischen.
<G-vec00380-003-s054><brush_off.auffrischen><en> On our shop you can find exclusive products that have marked the past eras: they are unique models, real collector’s pieces that you can brush up in your office or in your living room.
<G-vec00380-003-s054><brush_off.auffrischen><de> In unserem Shop finden Sie exklusive Produkte, die die vergangenen Epochen markiert haben: Sie sind einzigartige Modelle, echte Sammlerstücke, die Sie in Ihrem Büro oder in Ihrem Wohnzimmer auffrischen können.
<G-vec00380-003-s055><brush_off.auffrischen><en> A shorter stay may be suitable to learn the basics of a new foreign language or to brush up on already existing foreign language skills.
<G-vec00380-003-s055><brush_off.auffrischen><de> Für das Erlernen von Grundlagen einer neuen Fremdsprache sowie für das Auffrischen von bereits erlernten Fremdsprachen kann sich auch ein kürzerer Aufenthalt als sinnvoll herausstellen.
<G-vec00380-003-s056><brush_off.auffrischen><en> For an upcoming job interview, he wants to brush up and enhance his modelling skills.
<G-vec00380-003-s056><brush_off.auffrischen><de> Für ein anstehendes Interview möchte er seine Modelling-Kenntnisse auffrischen und erweitern.
<G-vec00380-003-s057><brush_off.auffrischen><en> This app is for everyone who enjoys solving puzzles or wants to brush up their French while playing.
<G-vec00380-003-s057><brush_off.auffrischen><de> Diese App richtet sich an alle, die gerne Rätsel lösen oder ihre Spanischkenntnisse spielerisch auffrischen möchten.
<G-vec00380-003-s058><brush_off.auffrischen><en> This permits you to learn a new variation or brush up on your skills, prior to taking any chances with your hard earned money.
<G-vec00380-003-s058><brush_off.auffrischen><de> Das erlaubt Ihnen, eine neue Variante erlernen oder auffrischen Ihre Fähigkeiten, vor der Einnahme von allen Chancen, mit Ihrem hart verdienten Geld.
<G-vec00380-003-s059><brush_off.auffrischen><en> Combining prescriptive, online knowledge development and in-water training, PADI ReActivate presents a flexible, convenient and interactive way to brush up divers’ skills, meeting the needs of recreational divers and PADI Professionals alike.
<G-vec00380-003-s059><brush_off.auffrischen><de> Durch Kombinieren der präskriptiven Entwicklung von Tauchkenntnissen online und Training im Wasser stellt PADI ReActivate eine flexible, bequeme und interaktive Möglichkeit dar, damit Taucher ihre Fertigkeiten auffrischen können und den Erwartungen von Sporttauchern und PADI Profis gleichermassen entsprechen.
<G-vec00380-003-s060><brush_off.auffrischen><en> This app is for everyone who enjoys solving puzzles or wants to brush up their Italian while playing.
<G-vec00380-003-s060><brush_off.auffrischen><de> Diese App richtet sich an alle, die gerne Rätsel lösen oder ihre Italienischkenntnisse spielerisch auffrischen möchten.
<G-vec00380-003-s061><brush_off.auffrischen><en> You can also use an interdental brush to clean hard-to-reach places.
<G-vec00380-003-s061><brush_off.auffrischen><de> Sie können Ihren Atem aber auch mit anderen Mitteln auffrischen.
<G-vec00380-003-s062><brush_off.auffrischen><en> If we want to learn or brush up on a foreign language, we must have a flexible ear, we must be able to decipher the rhythm, inflection and intonation of the new language.
<G-vec00380-003-s062><brush_off.auffrischen><de> Wollen wir eine Fremdsprache lernen oder wieder auffrischen, muss unser Ohr beweglich sein, das heißt, es muss den Rhythmus, die Sprachmelodie und die Intonation der neuen Sprache entschlüsseln können.
<G-vec00380-003-s063><brush_off.auffrischen><en> If you want to broaden, or brush up your language skills, then you’ve come to the right place.
<G-vec00380-003-s063><brush_off.auffrischen><de> Wenn Sie Ihre Fremdsprachenkenntnisse erweitern, oder wieder auffrischen möchten, dann sind Sie bei uns genau richtig.
<G-vec00380-003-s065><brush_off.auftragen><en> Apply over your foundation or BB Cream with the INIKA Kabuki Brush or with the INIKA Fan Brush to distribute the bronzer evenly.
<G-vec00380-003-s065><brush_off.auftragen><de> Mit der INIKA Kabuki Bürste oder mit der INIKA Fächerbürste über die Foundation oder BB Cream auftragen, um den Bronzer gleichmäßig zu verteilen.
<G-vec00380-003-s066><brush_off.auftragen><en> Apply mask to damp hair, brush with Coco & Eve Tangle Teaser and leave on Add your review
<G-vec00380-003-s066><brush_off.auftragen><de> Maske auf das feuchte Haar auftragen, mit dem Coco & Eve Tangle Teaser durchbürsten und zehn Minuten einwirken lassen, dann abspülen.
<G-vec00380-003-s067><brush_off.auftragen><en> That’s because the solvents are already beginning to evaporate— thickening and drying the polish—and repeated brushing causes the brush bristles to make small groves in the polish.
<G-vec00380-003-s067><brush_off.auftragen><de> Der Grund dafür ist, dass die Lösungsmittel bereits zu verdunsten beginnen— und der Nagellack so verdickt und trocknet.—Durch wiederholtes Auftragen hinterlassen die Pinselborsten kleine Unebenheiten im Lack.
<G-vec00380-003-s068><brush_off.auftragen><en> Thinly and evenly apply Micro Foundation Cream with a very fine-pore make-up sponge or foundation brush and set it with HD Micro Finish Powder.
<G-vec00380-003-s068><brush_off.auftragen><de> Micro Foundation Cream mit einem sehr feinporigen Schwämmchen oder Foundation-Pinsel dünn und gleichmäßig auftragen und mit MicroFinish Powder fixieren.
<G-vec00380-003-s069><brush_off.auftragen><en> The gel is easy to apply with a single tuft brush or an interdental brush.
<G-vec00380-003-s069><brush_off.auftragen><de> Das Gel lässt sich leicht mit einer Einbüschelbürste oder einer Interdentalbürste auftragen.
<G-vec00380-003-s070><brush_off.auftragen><en> Apply the lipstick directly to the lips or with a lip brush.
<G-vec00380-003-s070><brush_off.auftragen><de> Den Lippenstift direkt oder mit einem Lippenpinsel auf die Lippen auftragen.
<G-vec00380-003-s071><brush_off.auftragen><en> Let set and then apply your favorite eyeshadow with a ZOEVA eye brush and blend softly for a flawless finish.
<G-vec00380-003-s071><brush_off.auftragen><de> Kurz antrocknen lassen und anschließend die Lieblings-Lidschattenfarbe mit einem ZOEVA Lidschattenpinsel auf das Auge auftragen und sanft verblenden.
<G-vec00380-003-s072><brush_off.auftragen><en> Natural bristle brush imparts the perfect amount of colour.
<G-vec00380-003-s072><brush_off.auftragen><de> Natürlicher Borstenpinsel zum Auftragen der perfekten Farbmenge.
<G-vec00380-003-s073><brush_off.auftragen><en> • Brush shape and bristle formation facilitate a faster application by reducing time spent covering and blending.
<G-vec00380-003-s073><brush_off.auftragen><de> • Bürstenform und Borstenbildung erleichtern eine schnellere, einfachere Anwendung als herkömmliches Auftragen.
<G-vec00380-003-s074><brush_off.auftragen><en> The shaving brush is equipped with badger hair and applying shaving soap is a waltz.
<G-vec00380-003-s074><brush_off.auftragen><de> Der Rasierpinsel ist mit echtem Dachshaar ausgestattet und macht das gleichmäßige Auftragen der Rasierseife zum Kinderspiel.
<G-vec00380-003-s075><brush_off.auftragen><en> Apply fixative to the lipstick with the brush and leave it to dry. Composition Details
<G-vec00380-003-s075><brush_off.auftragen><de> Das Fixiermittel mit Hilfe eines Pinsels auf den Lippenstift auftragen und trocknen lassen.
<G-vec00380-003-s076><brush_off.auftragen><en> Thanks to its luxurious, fluffy natural-synthetic hair blend and tapered shape, the expert blending brush perfectly adapts to the eyelid crease, gradually building color and softening transitions for a flawless finish.
<G-vec00380-003-s076><brush_off.auftragen><de> Mit dem luxuriösen ZOEVA 127 Luxe Sheer Cheek wird das Auftragen und Verblenden von Puder-Rouge aufgrund der angeschrägten Form, die sich perfekt den Rundungen der Wangen anpasst, zu einem entspannenden Erlebnis.
<G-vec00380-003-s077><brush_off.auftragen><en> Use a comb or special hair dying brush to distribute the color evenly, massage the dye into the hair with your fingers, leave the product for 15 to 60 minutes.
<G-vec00380-003-s077><brush_off.auftragen><de> Nimm einen Kamm oder eine spezielle Haarfärbebürste zum gliechmäßigen Auftragen der Farbe, massiere sie mit den Fingern ein, und lasse sie zwischen 15 und 60 Minuten einwirken.
<G-vec00380-003-s078><brush_off.auftragen><en> Then blend the colours using the cylindrical eye brush from the Haute Punk Brush Set.
<G-vec00380-003-s078><brush_off.auftragen><de> Neben der aufgetragenen Farbe die mittleren Farben der Palette bis zur Augenbraue und den Schläfen auftragen.
<G-vec00380-003-s079><brush_off.auftragen><en> Tease with fingertips & layer more product to build height or brush through & finish. Ingredients
<G-vec00380-003-s079><brush_off.auftragen><de> Mit den Fingerspitzen verreiben und mehr vom Produkt auftragen um Höhe zu gewinnen oder durchbürsten und einwirken lassen.
<G-vec00380-003-s080><brush_off.auftragen><en> Annabelle Minerals mineral foundation application is most convenient using a designated foundation brush: flat top brush or kabuki brush.
<G-vec00380-003-s080><brush_off.auftragen><de> Die Mineral Foundations Annabelle Minerals lassen sich am besten mit den dafür vorhergesehenen Pinseln auftragen, dem Flat Top Pinsel und dem Kabuki Pinsel.
<G-vec00380-003-s081><brush_off.auftragen><en> 3 Using a small brush or q-tip, gently and carefully apply nail polish remover to any parts of your skin that have gotten nail polish on.
<G-vec00380-003-s081><brush_off.auftragen><de> Wenn ihr Nagellack auftragen möchtet, tragt eine Grundierung (Base Coat), zwei Schichten Nagellack und anschließend eine Schicht Top Coat auf.
<G-vec00380-003-s082><brush_off.auftragen><en> Brush more just above jaw, earlobe to chin. Blend all, stroking with fingertip. Brush and blend a touch on each side of face, at hairline.
<G-vec00380-003-s082><brush_off.auftragen><de> Einen Hauch auf jeder Seite des Gesichts, entlang der Haarlinie, auf die mittlere Stirnpartie, die Nase, den Amorbogen und das Kinn auftragen.
<G-vec00380-003-s083><brush_off.auftragen><en> The ideal brush for an easy and quick make-up application.
<G-vec00380-003-s083><brush_off.auftragen><de> Ideal zum einfachen und raschen Auftragen von Puder.
<G-vec00380-003-s158><brush_off.bürsten><en> Brush your skin – this trick helps you remove dead cells so that a new layer of cells can be created.
<G-vec00380-003-s158><brush_off.bürsten><de> Bürsten Sie Ihre Haut – dieser Trick hilft Ihnen, abgestorbene Zellen zu entfernen, sodass eine neue Zellschicht erstellt werden kann.
<G-vec00380-003-s159><brush_off.bürsten><en> Made for applying lipstick and gloss, simply apply a dab of colour in the centre of your lip and brush toward outer corners until your entire lip is covered.
<G-vec00380-003-s159><brush_off.bürsten><de> Gemacht für das Anwenden des Lippenstifts und des Glanzes, wenden Sie einfach einen Klecks der Farbe in der Mitte Ihrer Lippe an und bürsten Sie in Richtung zu den Außenecken, bis Ihre gesamte Lippe bedeckt ist.
<G-vec00380-003-s160><brush_off.bürsten><en> Brush growth with hinder riding this summer without some trail maintenance.
<G-vec00380-003-s160><brush_off.bürsten><de> Bürsten Sie das Wachstum und behindern Sie in diesem Sommer das Fahren, ohne die Spur zu pflegen.
<G-vec00380-003-s161><brush_off.bürsten><en> Brush back the natural hair’s edges to blend it with the weave hair.
<G-vec00380-003-s161><brush_off.bürsten><de> Bürsten Sie die Ränder des natürlichen Haares zurück, um es mit dem gewebten Haar zu mischen.
<G-vec00380-003-s162><brush_off.bürsten><en> Brush your hair afterwards.
<G-vec00380-003-s162><brush_off.bürsten><de> Bürsten Sie anschließend Ihr Haar.
<G-vec00380-003-s163><brush_off.bürsten><en> Massage into your scalp first and then brush any excess product out.
<G-vec00380-003-s163><brush_off.bürsten><de> Massieren Sie das Produkt zuerst ein und bürsten Sie alles, was zu viel ist, anschließend aus.
<G-vec00380-003-s164><brush_off.bürsten><en> And brush oil on the bottom of the mold to ensure smooth demolding.
<G-vec00380-003-s164><brush_off.bürsten><de> Und bürsten Sie Öl auf den Boden der Form, um ein reibungsloses Entformen zu gewährleisten.
<G-vec00380-003-s165><brush_off.bürsten><en> Never brush hair when it’s dry.
<G-vec00380-003-s165><brush_off.bürsten><de> Bürsten Sie niemals das Haar, wenn es trocken ist.
<G-vec00380-003-s166><brush_off.bürsten><en> Once footwear is dry, lightly brush with the soft side of the suede brush in one direction only.
<G-vec00380-003-s166><brush_off.bürsten><de> Bürsten Sie den trockenen Schuh sanft mit einer sehr weichen Veloursleder- oder Nubukbürste nur in einer Richtung.
<G-vec00380-003-s167><brush_off.bürsten><en> Brush some eyelash liquid at the eye's root, then brush the eyelash inside and outside several times.
<G-vec00380-003-s167><brush_off.bürsten><de> Bürsten Sie etwas Wimperflüssigkeit an der Wurzel des Auges, dann bürsten Sie die Wimper innerhalb und außerhalb mehrmals.
<G-vec00380-003-s168><brush_off.bürsten><en> Brush your hair every night with a natural bristle brush.
<G-vec00380-003-s168><brush_off.bürsten><de> Bürsten Sie Ihr Haar jeden Abend mit einer natürlichen Bürste.
<G-vec00380-003-s169><brush_off.bürsten><en> If you are busy with heat tools, paint your hair, brush your hair when it is wet and outside, or have thinning hair then this is really the answer.
<G-vec00380-003-s169><brush_off.bürsten><de> Wenn Sie mit Heizgeräten beschäftigt sind, streichen Sie Ihre Haare, bürsten Sie Ihr Haar, wenn es nass und draußen ist, oder haben Sie dünner werdendes Haar, dann ist dies wirklich die Antwort.
<G-vec00380-003-s170><brush_off.bürsten><en> Brush twice a day with fluoride toothpaste to remove food debris and plaque.
<G-vec00380-003-s170><brush_off.bürsten><de> Bürsten Sie Ihre Zahnprothese vor dem Einweichen, um Essensreste zu entfernen.
<G-vec00380-003-s171><brush_off.bürsten><en> Brush for about three minutes and try to reach all your teeth.
<G-vec00380-003-s171><brush_off.bürsten><de> Bürsten Sie für ungefähr drei Minuten und versuchen Sie alle Ihre Zähne zu erreichen.
<G-vec00380-003-s172><brush_off.bürsten><en> Brush afterwards still with a GogiPet ® slicker brush or GogiPet ® Multibrush trough.
<G-vec00380-003-s172><brush_off.bürsten><de> Bürsten Sie anschließend noch mit einer GogiPet ® Zupfbürste oder GogiPet® Multibrush durch.
<G-vec00380-003-s173><brush_off.bürsten><en> Brush the outer surfaces, the inner surfaces and the chewing surfaces of the teeth.
<G-vec00380-003-s173><brush_off.bürsten><de> Bürsten Sie auf diese Weise die Außenseiten und Innenseiten der Zähne.
<G-vec00380-003-s174><brush_off.bürsten><en> • Rinse and brush all channels and tubes.
<G-vec00380-003-s174><brush_off.bürsten><de> • Spülen und bürsten Sie alle Kanäle und Rohre.
<G-vec00380-003-s310><brush_off.putzen><en> Brush your teeth with a hydrogen peroxide and baking soda paste once a week.
<G-vec00380-003-s310><brush_off.putzen><de> Putze deine Zähne einmal wöchentlich mit einer Paste aus Wasserstoffperoxid und Backsoda (Natron).
<G-vec00380-003-s311><brush_off.putzen><en> 8 Brush and floss your teeth twice a day.
<G-vec00380-003-s311><brush_off.putzen><de> 8 Putze dir die Zähne zwei Mal täglich und verwende Zahnseide.
<G-vec00380-003-s312><brush_off.putzen><en> Brush your teeth and tongue before going to bed.
<G-vec00380-003-s312><brush_off.putzen><de> Putze deine Zähne und Zunge vor dem Zubettgehen.
<G-vec00380-003-s313><brush_off.putzen><en> Store the paste in a sealed jar, and brush your teeth with it two to three times daily.
<G-vec00380-003-s313><brush_off.putzen><de> Bewahre die Paste in einem verschlossenen Glas auf und putze deine Zähne zweimal oder dreimal täglich damit.
<G-vec00380-003-s314><brush_off.putzen><en> Brush your teeth with Epsom salt for an extra clean smile.
<G-vec00380-003-s314><brush_off.putzen><de> Putze deine Zähne mit Bittersalz für ein extra sauberes Lächeln.
<G-vec00380-003-s315><brush_off.putzen><en> Then brush your teeth as normal, paying special attention to the 16 visible teeth at the front.
<G-vec00380-003-s315><brush_off.putzen><de> Dann putze dir die Zähne wie normal und bearbeite vor allem die sichtbaren vorderen 16 Zähne.
<G-vec00380-003-s316><brush_off.putzen><en> Celibacy I brush off with my signature.
<G-vec00380-003-s316><brush_off.putzen><de> Das Zölibat putze ich weg mit meiner Unterschrift.
<G-vec00380-003-s317><brush_off.putzen><en> Brush your teeth after every meal.
<G-vec00380-003-s317><brush_off.putzen><de> Putze dir die Zähne jeden Tag.
<G-vec00380-003-s318><brush_off.putzen><en> Brush your tongue with your toothbrush.
<G-vec00380-003-s318><brush_off.putzen><de> Putze deine Zunge mit deiner Zahnbürste.
<G-vec00380-003-s319><brush_off.putzen><en> 6 Remove the trays and brush your teeth again.
<G-vec00380-003-s319><brush_off.putzen><de> Dann putze deine Zähne mit dem Gel für mindestens 2 Minuten wie üblich.
<G-vec00380-003-s320><brush_off.putzen><en> I brush my teeth with toothpaste and a toothbrush.
<G-vec00380-003-s320><brush_off.putzen><de> Ich putze mir die Zähne mit Zahnpasta und einer Zahnbürste.
<G-vec00380-003-s321><brush_off.putzen><en> First thing I do after I've woken up is brush my teeth.
<G-vec00380-003-s321><brush_off.putzen><de> Als allererstes putze ich mir die Zähne.
<G-vec00380-003-s322><brush_off.putzen><en> Bad breath can be offensive to others, so brush your teeth twice a day- once in the morning after breakfast and once before you go to bed and take some mint gum to chew after snacks and meals.
<G-vec00380-003-s322><brush_off.putzen><de> Schlechter Atem kann andere abstoßen, putze deine Zähne daher zweimal am Tag – morgens nach dem Frühstück und noch einmal vor dem Zubettgehen, und kaue Pfefferminzkaugummi nach dem Essen.
<G-vec00380-003-s323><brush_off.putzen><en> Brush and floss your teeth in between meals.
<G-vec00380-003-s323><brush_off.putzen><de> Putze und spüle dir die Zähne zwischen den Mahlzeiten.
