<G-vec00733-002-s038><calm_down.beruhigen><en> So calm down, stop thinking negative and empower yourself.
<G-vec00733-002-s038><calm_down.beruhigen><de> Also beruhige dich, hör auf negativ zu denken und bestärke dich selbst.
<G-vec00733-002-s039><calm_down.beruhigen><en> Calm yourself, I beseech you, I conjure you—the wound is slight.
<G-vec00733-002-s039><calm_down.beruhigen><de> Beruhige Dich, Herrin, ich bitte, ich beschwöre Dich...
<G-vec00733-002-s040><calm_down.beruhigen><en> Calm yourself with meditation.
<G-vec00733-002-s040><calm_down.beruhigen><de> Beruhige dich mit Meditation.
<G-vec00733-002-s041><calm_down.beruhigen><en> First of all, calm down and try to discuss the situation with the boss.
<G-vec00733-002-s041><calm_down.beruhigen><de> Beruhige dich zuerst und versuche die Situation mit dem Chef zu besprechen.
<G-vec00733-002-s042><calm_down.beruhigen><en> Calm yourself and have a copy of Yodot PPT Repair program installed in your Windows computer that can mend corrupted PowerPoint presentation effectively.
<G-vec00733-002-s042><calm_down.beruhigen><de> Beruhige dich und habe eine Kopie von Yodot PPT Repair-Programm in deinem Windows-Computer installiert, die eine beschädigte PowerPoint-Präsentation effektiv verbessern kann.
<G-vec00733-002-s043><calm_down.beruhigen><en> Calm the horse.
<G-vec00733-002-s043><calm_down.beruhigen><de> Beruhige das Pferd.
<G-vec00733-002-s044><calm_down.beruhigen><en> Depression, lack of energy, constant dissatisfaction, tension, rapid heart beat, feeling of numbness in my left hand, nervousness, and a little more aggressive attitude towards others, this I was made aware of more and more by my loved ones – calm down or you'll get sick.
<G-vec00733-002-s044><calm_down.beruhigen><de> Depression, Energiemangel, ständige Unzufriedenheit, Spannung, schneller Herzschlag, Taubheitsgefühl in der linken Hand, Nervosität, und ein wenig mehr aggressiver Haltung gegenüber anderen, dessen ich mehr und mehr von meinen Lieben bewusst gemacht worden bin, - beruhige dich oder du wirst krank werden.
<G-vec00733-002-s045><calm_down.beruhigen><en> Just do everything in your power, and calm down, "- says Tanya Remer Altman, MD.
<G-vec00733-002-s045><calm_down.beruhigen><de> Mach einfach alles in deiner Macht, und beruhige dich ", sagt Tanya Remer Altman, MD.
<G-vec00733-002-s046><calm_down.beruhigen><en> LOCKE: Calm down.
<G-vec00733-002-s046><calm_down.beruhigen><de> Locke: Beruhige dich.
<G-vec00733-002-s047><calm_down.beruhigen><en> Description Soothe and calm stressed, damaged skin with the Ananda Antioxidant-Rich Gentle Toner from organic experts Antipodes.
<G-vec00733-002-s047><calm_down.beruhigen><de> Beschreibung Beruhige gestresste, geschädigte Haut mit dem Ananda Antioxidant-Rich Gentle Toner von den organischen Experten von Antipodes.
<G-vec00733-002-s048><calm_down.beruhigen><en> Try to relax and calm down, with your hands on your chest.
<G-vec00733-002-s048><calm_down.beruhigen><de> Versuche dich zu entspannen und beruhige dich mit deinen Händen auf deiner Brust.
<G-vec00733-002-s049><calm_down.beruhigen><en> Please calm down a bit.
<G-vec00733-002-s049><calm_down.beruhigen><de> Bitte beruhige dich ein wenig.
<G-vec00733-002-s050><calm_down.beruhigen><en> Then Aunt Larisa would say severely: "Vitya, calm down!"
<G-vec00733-002-s050><calm_down.beruhigen><de> Tante Larisa sagte in so einem Moment immer: “Witja, beruhige dich!“.
<G-vec00733-002-s051><calm_down.beruhigen><en> As evening comes, mother drinks once, twice and again, raving, yelling, cursing men and father locks his study door while I entreat her: please calm down, once, twice and again.
<G-vec00733-002-s051><calm_down.beruhigen><de> Der Abend kommt, Mutter trinkt einmal, zweimal und wieder, wütet, brüllt, verflucht die Männer, während Vater sich in sein Zimmer schließt und ich zu ihr flehe: beruhige dich doch, einmal, zweimal und wieder.
<G-vec00733-002-s052><calm_down.beruhigen><en> Calm down and wait for the summer.
<G-vec00733-002-s052><calm_down.beruhigen><de> Beruhige dich und warte auf den Sommer.
<G-vec00733-002-s053><calm_down.beruhigen><en> Calm upset passengers, repair stuck doors, sell tickets correctly, and extend the ramp for wheel chair passengers in a timely manner.
<G-vec00733-002-s053><calm_down.beruhigen><de> Beruhige aufgebrachte Fahrgäste, repariere klemmende Türen, gib korrekt die Tickets aus und fahre die Rampe rechtzeitig für Rollstuhlfahrer aus.
<G-vec00733-002-s054><calm_down.beruhigen><en> If you have something against your brother, against your sister, go.... First pray, calm your soul, and then go and say to him, to her: I do not agree with this... you have done a bad thing...”.
<G-vec00733-002-s054><calm_down.beruhigen><de> Wenn du etwas gegen deinen Bruder, deine Schwester hast, dann geh hin… Bete erst einmal, beruhige dich, und dann geh hin und rede mit ihm oder mit ihr: »Ich bin damit nicht einverstanden… du hast Unrecht getan …«.
<G-vec00733-002-s055><calm_down.beruhigen><en> In a unique atmosphere, I will ensure you relax and calm down.
<G-vec00733-002-s055><calm_down.beruhigen><de> In einer einzigartigen Atmosphäre werde ich dafür sorgen, dass Sie sich entspannen und beruhigen.
<G-vec00733-002-s056><calm_down.beruhigen><en> Prolactin is also secreted in mother’s milk to calm a nursing baby.
<G-vec00733-002-s056><calm_down.beruhigen><de> Prolactin ist auch Bestandteil der Muttermilch, um ein Baby während des Stillens zu beruhigen.
<G-vec00733-002-s057><calm_down.beruhigen><en> Nervous, aggressive or excited animals should be given the possibility to calm down before initiation of treatment.
<G-vec00733-002-s057><calm_down.beruhigen><de> Nervösen, aggressiven oder aufgeregten Tieren sollte vor Behandlungsbeginn die Gelegenheit gegeben werden, sich zu beruhigen.
<G-vec00733-002-s058><calm_down.beruhigen><en> Calm down.
<G-vec00733-002-s058><calm_down.beruhigen><de> Beruhigen wir uns.
<G-vec00733-002-s059><calm_down.beruhigen><en> Through meditation, you will learn how to calm your thought waves so that your heart can reveal itself to you.
<G-vec00733-002-s059><calm_down.beruhigen><de> Durch Meditation lernst Du, Deine Gedankenwellen zu beruhigen, so dass sich Dir Dein Herz offenbaren kann.
<G-vec00733-002-s060><calm_down.beruhigen><en> My husband advised me to calm down.
<G-vec00733-002-s060><calm_down.beruhigen><de> Mein Mann riet mir, mich zu beruhigen.
<G-vec00733-002-s061><calm_down.beruhigen><en> Rather than meditating to calm and focus your mind, Loch teaches us to intentionally shift into open-hearted awareness, which is already calm, stable, and able to effortlessly focus.
<G-vec00733-002-s061><calm_down.beruhigen><de> Anstelle von Meditation, um den Geist zu beruhigen und zu fokussieren, lehrt Loch Kelly, bewusst in ein Gewahrsein mit offenem Herzen zu wechseln – in ein Gewahrsein, das bereits ruhig, gefestigt und in der Lage ist, ohne Anstrengung fokussiert zu sein.
<G-vec00733-002-s062><calm_down.beruhigen><en> This can help you when you need to focus, sleep, calm down, and relax after a long day.
<G-vec00733-002-s062><calm_down.beruhigen><de> Das kann Ihnen helfen, wenn Sie nach einem langen Tag fokussieren, schlafen, sich beruhigen und entspannen müssen.
<G-vec00733-002-s063><calm_down.beruhigen><en> On the way home, I was thinking: to calm themselves, ancient people would do breathing exercises even before writing.
<G-vec00733-002-s063><calm_down.beruhigen><de> Auf dem Heimweg dachte ich: “Um sich zu beruhigen würden ältere Leute erst einmal Atemübungen machen, sogar bevor sie sich ans Schreiben machen.
<G-vec00733-002-s064><calm_down.beruhigen><en> But not even the memory of the lavishly decorated display of the little patisserie was able to calm my mind.
<G-vec00733-002-s064><calm_down.beruhigen><de> Doch nicht einmal die Erinnerung an die aufwendig dekorierte Auslage der kleinen Patisserie konnte mein aufgebrachtes Gemüt beruhigen.
<G-vec00733-002-s065><calm_down.beruhigen><en> All the girls in this sex chat room are always hungry for desire and need to calm down using their sex toys all the time.
<G-vec00733-002-s065><calm_down.beruhigen><de> Alle Mädchen in diesem Sex-Chat-Raum sind immer hungrig nach Verlangen und müssen sich mit ihrem Sexspielzeug die ganze Zeit beruhigen.
<G-vec00733-002-s066><calm_down.beruhigen><en> The Brazilian patient tries to calm foreign patients who may be afraid of communication problems with the ICSEB team.
<G-vec00733-002-s066><calm_down.beruhigen><de> Der Brasilianer versucht, ausländischen Patienten und Patientinnen, die Angst vor Verständigungsschwierigkeiten mit dem ICSEB Team haben, zu beruhigen.
<G-vec00733-002-s067><calm_down.beruhigen><en> You can still soak up the sun, unless you have to help in the construction of some complex structure... or calm down a little prankster who decided to destroy the beautiful castle.
<G-vec00733-002-s067><calm_down.beruhigen><de> Sie können immer noch die Sonne genießen, es sei denn, Sie müssen beim Bau einer komplexen Struktur helfen... oder einen kleinen Scherz beruhigen, der sich entschieden hat, das schöne Schloss zu zerstören.
<G-vec00733-002-s068><calm_down.beruhigen><en> That could calm markets for a while.
<G-vec00733-002-s068><calm_down.beruhigen><de> Das könnte die Märkte eine Weile lang beruhigen.
<G-vec00733-002-s069><calm_down.beruhigen><en> Properly organized preparation for night rest helps the child to calm down and plunge into sound sleep, and wake up fresh and rested in the morning.
<G-vec00733-002-s069><calm_down.beruhigen><de> Eine ordnungsgemäß organisierte Vorbereitung für die Nachtruhe hilft dem Kind, sich zu beruhigen und in einen gesunden Schlaf zu tauchen und morgens frisch und ausgeruht aufzuwachen.
<G-vec00733-002-s070><calm_down.beruhigen><en> Aloe Vera and comfrey calm the already stressed skin.
<G-vec00733-002-s070><calm_down.beruhigen><de> Aloe Vera und Beinwell beruhigen die ohnehin gestresste Haut.
<G-vec00733-002-s071><calm_down.beruhigen><en> The familiar sounds from the womb calm newborns and help them fall asleep better.
<G-vec00733-002-s071><calm_down.beruhigen><de> Die vertrauten Klänge aus dem Mutterleib beruhigen Neugeborene und lassen sie besser einschlafen.
<G-vec00733-002-s072><calm_down.beruhigen><en> 12 And he said unto them, Take me up, and cast me forth into the sea: so shall the sea be calm around you; for I know well that because of me is this great tempest upon you.
<G-vec00733-002-s072><calm_down.beruhigen><de> ELB1905(i) 12 Und er sprach zu ihnen: Nehmet mich und werfet mich ins Meer, so wird das Meer sich gegen euch beruhigen; denn ich weiß, daß dieser große Sturm um meinetwillen über euch gekommen ist.
<G-vec00733-002-s073><calm_down.beruhigen><en> “When I feel hurt,” says a wife named Beatriz, “I try to calm down first.
<G-vec00733-002-s073><calm_down.beruhigen><de> Eine Ehefrau erzählt: „Fühle ich mich verletzt, versuche ich mich erst mal zu beruhigen.
<G-vec00733-002-s093><calm_down.beruhigen><en> Dr. Hauschka Rose Day Cream will nourish, protect and calm your complexion, making it the perfect choice for dry or sensitive skin that's prone to redness, irritation and couperose.
<G-vec00733-002-s093><calm_down.beruhigen><de> Besonders ideal für trockene oder empfindliche Haut, die zu Rötungen, Reizungen und Couperose neigt, erweicht Dr. Hauschka Rose Tagescreme, stärkt und schützt deine Haut, während dein Teint beruhigt wird.
<G-vec00733-002-s094><calm_down.beruhigen><en> Jack, to calm the uneasy masses, tells them a plan is in the works already.
<G-vec00733-002-s094><calm_down.beruhigen><de> Jack beruhigt die aufgeregten Überlebenden und sagt ihnen, dass sie schon an einem Plan arbeiten.
<G-vec00733-002-s095><calm_down.beruhigen><en> If the dog does not calm down or approach you within thirty seconds, abandon the attempt.
<G-vec00733-002-s095><calm_down.beruhigen><de> Wenn sich der Hund nicht innerhalb von 30 Sekunden beruhigt oder sich dir nähert, stelle deinen Versuch ein.
<G-vec00733-002-s096><calm_down.beruhigen><en> Modern: this works Deep Sleep Stress Less is a soothing natural remedy to help you breathe more easily and calm your senses promoting a better nights sleep.
<G-vec00733-002-s096><calm_down.beruhigen><de> Modern: this works Deep Sleep Stress Less ist ein natürliches Beruhigungsmittel, das Ihre Atmung erleichtert und Ihre Sinne beruhigt und so für besseren Schlaf sorgt.
<G-vec00733-002-s097><calm_down.beruhigen><en> In classical meditation, we try to calm the mind and stop all thought impulses.
<G-vec00733-002-s097><calm_down.beruhigen><de> Bei der klassischen Meditation wird der Geist beruhigt und versucht alle Gedankenregungen anzuhalten.
<G-vec00733-002-s098><calm_down.beruhigen><en> Collagen and elasticity is improved and skin feels calm, comfortable and perfectly balanced.
<G-vec00733-002-s098><calm_down.beruhigen><de> Kollagen und Elastizität wird verbessert und die Haut fühlt sich beruhigt, zufrieden und perfekt ausbalanciert an.
<G-vec00733-002-s099><calm_down.beruhigen><en> A psychiatrist might be able to offer you medication that will calm you or help you sleep, though these medications should be neither expected nor abused.
<G-vec00733-002-s099><calm_down.beruhigen><de> Ein Psychiater kann dir ein Medikament anbieten, das dich beruhigt oder dir helfen kann einzuschlafen, aber du solltest diese Medikamente weder erwarten noch missbrauchen.
<G-vec00733-002-s100><calm_down.beruhigen><en> I’m calm again and get up.
<G-vec00733-002-s100><calm_down.beruhigen><de> Ich bin wieder beruhigt und stehe auf.
<G-vec00733-002-s101><calm_down.beruhigen><en> Whether you are looking for something to energise you or something to calm you down at the end of the day, check out our Smart Liquids for a pleasant vaping experience.
<G-vec00733-002-s101><calm_down.beruhigen><de> Egal, ob Du nach etwas suchst, das Dich belebt oder am Ende des Tages beruhigt, unsere Smart-Liquids bieten eine angenehme Vaping-Erfahrung.
<G-vec00733-002-s102><calm_down.beruhigen><en> Kurt laughs and tries to calm her down: “Finding a snake is a mere accident, I am sure there will be no other.”
<G-vec00733-002-s102><calm_down.beruhigen><de> Mit lachenden Worten beruhigt Kurt sie: "Riesiger Zufall, daß wir überhaupt ein Schlange entdeckt haben, es wird sicherlich keine Zweite mehr geben".
<G-vec00733-002-s103><calm_down.beruhigen><en> As Miguel de Cervantes aptly put it: “Time ripens all things ….” In our speedy world, it is good to know a place where to slow down, to calm down and to come back down to earth.
<G-vec00733-002-s103><calm_down.beruhigen><de> Wie sagte Miguel de Cervantes so treffend: „Man muss der Zeit auch Zeit geben.“ In unserer beschleunigten Welt ist es gut einen Ort zu kennen, der einen entschleunigt, beruhigt und erdet.
<G-vec00733-002-s104><calm_down.beruhigen><en> It is essential that the appearance of calm on financial markets does not distract from the urgent need to address the euro area’s fundamental challenges.
<G-vec00733-002-s104><calm_down.beruhigen><de> Die Tatsache, dass sich die Finanzmärkte etwas beruhigt haben, sollte nicht davon ablenken, dass die grundlegenden Herausforderungen des Euroraums dringend angegangen werden müssen.
<G-vec00733-002-s105><calm_down.beruhigen><en> - Papa, and Nobby, please, calm down.
<G-vec00733-002-s105><calm_down.beruhigen><de> - Nela und Nobby, bitte beruhigt Euch.
<G-vec00733-002-s106><calm_down.beruhigen><en> Unsuccessful Superintendent Parr (Karl George Saebisch) remains without a clue, so the famous detective Derrick Yale (Klaus Juergen Wussow) is sent out to assist the unproductive Superintendent. Yale's sharp wit and outstanding reputation should calm down the enraged public.
<G-vec00733-002-s106><calm_down.beruhigen><de> Inspektor Parr (Karl Georg Saebisch) tappt im Dunkeln, weshalb ihm der berühmte Detektiv Derrick Yale (Klausjürgen Wussow) zur Seite gestellt wird, der für seinen Spürsinn bekannt ist und mit dessen hervorragendem Ruf die aufgebrachte Öffentlichkeit beruhigt werden soll.
<G-vec00733-002-s107><calm_down.beruhigen><en> We've added 2 new soundscapes to find out what keeps you calm.
<G-vec00733-002-s107><calm_down.beruhigen><de> Wir haben zwei neue Klanglandschaften hinzugefügt, mit denen Sie herausfinden können, was Sie beruhigt.
<G-vec00733-002-s108><calm_down.beruhigen><en> Restores calm and clarity to acne-prone skin.
<G-vec00733-002-s108><calm_down.beruhigen><de> Beruhigt und klärt zu Akne neigende Haut.
<G-vec00733-002-s109><calm_down.beruhigen><en> "We really hope that the situation will calm down after so much suffering.
<G-vec00733-002-s109><calm_down.beruhigen><de> „Wir hoffen, dass sich die Lage beruhigt, nachdem es soviel Leid gegeben hat.
<G-vec00733-002-s110><calm_down.beruhigen><en> Helps calm hypersensitive skin.
<G-vec00733-002-s110><calm_down.beruhigen><de> Beruhigt überempfindliche Haut.
<G-vec00733-002-s111><calm_down.beruhigen><en> Sensitive skin therefore requires extra special care to calm it and strengthen its barriers at the same time, thus making it more resistant.
<G-vec00733-002-s111><calm_down.beruhigen><de> Sensible Haut benötigt deshalb eine spezielle Pflege, die sie beruhigt und zugleich ihre Hautbarriere stärkt, damit sie widerstandsfähiger wird.
<G-vec00733-002-s241><calm_down.bewahren><en> A month later a New York Times correspondent wrote from Shanghai, “The Red troops began putting up posters in Chinese instructing the populace to be calm and assuring them they had nothing to fear.”
<G-vec00733-002-s241><calm_down.bewahren><de> Einen Monat später berichtete ein Korrespondent der New York Times aus Shanghai: Durch Plakate in Chinesisch forderte die Rote Armee die Bevölkerung auf, Ruhe zu bewahren, und versicherte ihr, sie habe nichts zu befürchten.
<G-vec00733-002-s242><calm_down.bewahren><en> A willingness to communicate, foreign language skills, a good grasp of the situation and the ability to remain calm even in stressful situations round off the requirements profile.
<G-vec00733-002-s242><calm_down.bewahren><de> Kommunikationsfreude, Fremdsprachenkenntnisse, eine gute Auffassungsgabe und die Fähigkeit, auch in stressigen Situationen die Ruhe zu bewahren, runden das Anforderungsprofil ab.
<G-vec00733-002-s243><calm_down.bewahren><en> Important: stay calm.
<G-vec00733-002-s243><calm_down.bewahren><de> Aber bei allem: Ruhe bewahren.
<G-vec00733-002-s244><calm_down.bewahren><en> Remaining calm is key.
<G-vec00733-002-s244><calm_down.bewahren><de> Ruhe bewahren ist der Schlüssel.
<G-vec00733-002-s245><calm_down.bewahren><en> Yet this is not a rehearsal, THIS IS FOR REAL and with unexpected or surprising events always possible, AND/ALTHOUGH CMAton at the steering wheel to adjust where necessary, I need to point out that remaining calm and balanced and well rested, as advised before, is the way to go.
<G-vec00733-002-s245><calm_down.bewahren><de> Jedoch ist dies keine Übung, DIES IST ECHT, und daher sind unerwartete und überraschende Ereignisse immer möglich, UND/OBWOHL CMAton am Steuerrad steht, um Anpassungen vorzunehmen wo nötig, muss Ich darauf hinweisen, daß - wie schon früher angeraten - der richtige Weg darin besteht, Ruhe zu bewahren, ausgeglichen zu bleiben und gut ausgeruht zu sein.
<G-vec00733-002-s246><calm_down.bewahren><en> But that's another thing that I have learnt – to remain calm, hear the other person out, reflect and then react.
<G-vec00733-002-s246><calm_down.bewahren><de> Aber auch das ist eine Sache, die ich gelernt habe: die Ruhe zu bewahren, andere ausreden zu lassen, nachzudenken und dann zu reagieren.
<G-vec00733-002-s247><calm_down.bewahren><en> The government tried not to raise the alarm and called on the population to ‘stay calm' and ‘quietly focus on their normal activities'.
<G-vec00733-002-s247><calm_down.bewahren><de> Die Regierung will Panik verhindern und ruft die Bevölkerung dazu auf, „Ruhe zu bewahren“ und „in Ruhe ihren gewohnten Tätigkeiten“ nachzugehen.
<G-vec00733-002-s248><calm_down.bewahren><en> The municipality has worked closely with religious leaders to calm the streets.
<G-vec00733-002-s248><calm_down.bewahren><de> Die Kommune hat dabei eng mit den religiösen Führern kooperiert, um die Ruhe auf den Straßen zu bewahren.
<G-vec00733-002-s249><calm_down.bewahren><en> Diaphragmatic breathing, like meditation, has been proven to reduce anxiety and stress and induce calm.
<G-vec00733-002-s249><calm_down.bewahren><de> Zwerchfellatmung, wie bei der Meditation, hat sich bewährt, wenn es darum geht, Angst und Stress zu reduzieren und Ruhe zu bewahren.
<G-vec00733-002-s250><calm_down.bewahren><en> It is not easy at the present time to remain calm, to observe calmly, judge calmly, speak
<G-vec00733-002-s250><calm_down.bewahren><de> Es ist nicht leicht, in diesen Tagen Ruhe bewahren: ruhig sehen, ruhig urteilen, ruhig reden.
<G-vec00733-002-s251><calm_down.bewahren><en> In the meantime, e-commerce companies must remain calm.
<G-vec00733-002-s251><calm_down.bewahren><de> In der Zwischenzeit gilt es für E-Commerce Unternehmen die Ruhe zu bewahren.
<G-vec00733-002-s252><calm_down.bewahren><en> Fortunately, there are a number of ways to help deal with the disappointment and stress and stay calm.
<G-vec00733-002-s252><calm_down.bewahren><de> Glücklicherweise gibt es eine Reihe von Möglichkeiten, die helfen mit der Enttäuschung und dem Stress umzugehen und Ruhe zu bewahren.
