<G-vec00599-002-s100><bomb.bombardieren><en> A sign of the broader “bomb Iran” sentiment was an exchange between strategists for the Center for Strategic and Budgetary Assessments (CSBA), which includes former officials from both Democratic and Republican administrations, and others from the Council on Foreign Relations.
<G-vec00599-002-s100><bomb.bombardieren><de> Einen Hinweis auf eine breitere Stimmung „Bombardiert den Iran“ lieferte ein Austausch zwischen Strategen des Zentrum für strategische und haushaltspolitische Einschätzungen, CSBA), dem auch Ex-Regierungsvertreter sowohl von Demokraten als auch von Republikanern angehören, und anderen vom Council on Foreign Relations.
<G-vec00599-002-s101><bomb.bombardieren><en> Bomb an enemy city with a B-17.
<G-vec00599-002-s101><bomb.bombardieren><de> Bombardiert eine feindliche Stadt mit einer B-17.
<G-vec00599-002-s102><bomb.bombardieren><en> This is like hating all Christians because a small faction of extremists decided to bomb an abortion clinic down the street.
<G-vec00599-002-s102><bomb.bombardieren><de> Das ist so, als würde man alle Christen hassen, weil eine kleine Gruppe von Extremisten eine Abtreibungsklinik am anderen Ende der Straße bombardiert hat.
<G-vec00604-002-s103><bomb.bomben><en> In this case, to get the code that will disarm the bomb that the Gangster in the Green Mask has planted in South City.
<G-vec00604-002-s103><bomb.bomben><de> Sie sind auf der Jagd nach dem Kode für die Entschärfung der Bombe, mit der der Schurke mit der grünen Maske Rache an Big City nehmen will.
<G-vec00604-002-s104><bomb.bomben><en> The plutonium for the nuclear bomb used in the Trinity test in New Mexico and the Fat Man bomb dropped on Nagasaki, Japan was created in the B reactor.
<G-vec00604-002-s104><bomb.bomben><de> Dort wurden daraus die Bombe für den Trinity-Test sowie Fat Man, die Bombe, die auf Nagasaki abgeworfen wurde, hergestellt.
<G-vec00604-002-s105><bomb.bomben><en> One of the players takes on the role of the Unexpected Hero, who finds a bomb and tries to defuse it.
<G-vec00604-002-s105><bomb.bomben><de> Einer der Spieler übernimmt die Rolle des Helden wider Willen, der die Bombe findet und versucht, sie zu entschärfen.
<G-vec00604-002-s106><bomb.bomben><en> She then announces to Widmore that she is taking Jack and Kate to the bomb.
<G-vec00604-002-s106><bomb.bomben><de> Richard glaubt ihm und sagt Ellie, sie solle ihn zur Bombe bringen.
<G-vec00604-002-s107><bomb.bomben><en> Mario will have to use his bomb to kill them and tear them into pieces.
<G-vec00604-002-s107><bomb.bomben><de> Mario wird seine Bombe verwenden, um sie zu töten und sie in Stücke reißen.
<G-vec00604-002-s108><bomb.bomben><en> Plant the bomb and move from Shadow to Shadow to strike enemies with deadly force.
<G-vec00604-002-s108><bomb.bomben><de> Pflanzen Sie die Bombe und bewegen sich von Schatten zu Schatten Gegner mit tödlicher Gewalt zu schlagen.
<G-vec00604-002-s109><bomb.bomben><en> Originally, this bomb was to be publicized only this week - or more precisely, defused and then made public in order to minimize the damage potential.
<G-vec00604-002-s109><bomb.bomben><de> Ursprünglich sollte diese Bombe erst diese Woche publik gemacht werden - oder genauer gesagt erst entschärft und dann öffentlich gemacht werden, um das Schadenspotenzial zu minimieren.
<G-vec00604-002-s110><bomb.bomben><en> Such as Kurt Westergaard, author of the caricature of Mohammed with a bomb in his turban, who now lives in a house-fortress, with cameras and security windows and machine-gun toting guards outside.
<G-vec00604-002-s110><bomb.bomben><de> Wie Kurt Westergaard, Autor der Karikatur von Mohammed mit einer Bombe in seinem Turban, die jetzt in einer Haus-Festung lebt, mit Kameras und Sicherheitsfenstern und Maschinenpistolen tragenden Wachen draußen.
<G-vec00604-002-s111><bomb.bomben><en> Basically, any bomb consists of explosive material and a mechanism to ignite it.
<G-vec00604-002-s111><bomb.bomben><de> Grundsätzlich besteht jede Bombe aus Sprengmaterial und einem Mechanismus zur Detonation.
<G-vec00604-002-s112><bomb.bomben><en> In the press, there were recently two very different examples: an eight-year-old boy smuggled across the border from Morocco to the Spanish exclave of Cueta, whose huddled silhouette appeared in a luggage X-ray scan, and a bomb.
<G-vec00604-002-s112><bomb.bomben><de> In der Presse gab es in letzter Zeit zwei sehr unterschiedliche Beispiele: ein achtjähriger Junge, der über die Grenze von Marokko in die spanische Exklave Ceuta geschmuggelt wurde, und dessen zusammengekauerte Silhouette bei einem Gepäckröntgenscan zum Vorschein kam, und eine Bombe.
<G-vec00604-002-s113><bomb.bomben><en> We learn about the members of the resistance group "White Rose", who fought with words and the carpenter Georg Elser, who tried to assassinate Hitler with a bomb, and many people who worked in secret and whose deeds are today largely forgotten.
<G-vec00604-002-s113><bomb.bomben><de> Wir begegnen neben den Mitgliedern der Widerstandsgruppe "Weisse Rose", die mit Worten kämpften und dem Schreiner Georg Elser, der versuchte, Hitler mit einer Bombe zu töten, auch vielen Menschen, die im Verborgenen wirkten und deren Taten heute weitgehend in Vergessenheit geraten sind.
<G-vec00604-002-s114><bomb.bomben><en> Stop defusing the bomb long enough to kill an enemy, then successfully finish defusing it
<G-vec00604-002-s114><bomb.bomben><de> Unterbrechen Sie das Entschärfen der Bombe, um einen Feind zu töten, und vollenden Sie die Entschärfung danach erfolgreich.
<G-vec00604-002-s115><bomb.bomben><en> But when Fereshteh goes to take her granny, a bomb hits her father’s
<G-vec00604-002-s115><bomb.bomben><de> Während Fereshteh loszieht, um ihre Großmutter zu holen, fällt eine Bombe auf das Haus ihrer Familie.
<G-vec00604-002-s116><bomb.bomben><en> The kids had a bomb.
<G-vec00604-002-s116><bomb.bomben><de> Die Kinder hatten eine Bombe.
<G-vec00604-002-s117><bomb.bomben><en> You are the only person who can avert disaster and reveal the bomb’s location.
<G-vec00604-002-s117><bomb.bomben><de> Du bist die einzige Person, die die Bombe finden und entschärfen kann.
<G-vec00604-002-s118><bomb.bomben><en> He wrote of his own fear of going to a restaurant or a supermarket, "for fear that there is a living bomb next to me".
<G-vec00604-002-s118><bomb.bomben><de> Er schrieb von seiner eigenen Furcht, in ein Restaurant oder einen Supermarkt zu gehen, „aus Angst, neben mir steht eine lebende Bombe“.
<G-vec00604-002-s119><bomb.bomben><en> My year began with a massive explosion in Beirut, just 400 metres from me, as a bomb killed the ex-prime minister Rafiq Hariri.
<G-vec00604-002-s119><bomb.bomben><de> Dieses Jahr begann für mich mit einer gewaltigen Explosion in Beirut, als eine Bombe in nur 400 Metern Entfernung von mir den ehemaligen Premierminister Rafiq Hariri tötete.
<G-vec00604-002-s120><bomb.bomben><en> The building had been hit by a bomb that had not detonate but broken the water system.
<G-vec00604-002-s120><bomb.bomben><de> Das Gebäude war von einer Bombe getroffen worden, die zwar nicht detoniert war, aber die Wasserleitungen zerstört hatte.
<G-vec00604-002-s121><bomb.bomben><en> Shortly after he had started the engine, a bomb in his car exploded.
<G-vec00604-002-s121><bomb.bomben><de> Kurz nachdem er der Motor gestartet hat, explodiert eine im Wagen angebrachte Bombe.
<G-vec00604-002-s122><bomb.bomben><en> Destroy 15 bomb gems.
<G-vec00604-002-s122><bomb.bomben><de> Zerstöre 15 Bomben.
<G-vec00604-002-s123><bomb.bomben><en> On the ground, bomb explosions can be seen, as a result the mass of refugees also explodes.
<G-vec00604-002-s123><bomb.bomben><de> Am Boden sieht man einschlagende zerberstende Bomben, woraufhin auch die Masse der Fliehenden zerbirst.
<G-vec00604-002-s124><bomb.bomben><en> And so the bomb kit is also a kid that is good for running around and sort of blowing things up while you're running around in the midst of you enemies.
<G-vec00604-002-s124><bomb.bomben><de> Auf diese Art ist das Bomben Kit auch äußerst nützlich um Dinge in die Luft zu jagen, während man zwischen den Reihen des Gegners hin und her rennt.
<G-vec00604-002-s125><bomb.bomben><en> When playing as Tails or Eggman, the player can lock-on and shoot down its bomb pods along with the Hornet for additional points.
<G-vec00604-002-s125><bomb.bomben><de> Wenn der Spieler mit Tails oder Dr. Eggman spielt, kann er auf alle Bomben sowie den Roboter selbst zielen und treffen, wodurch er spezielle Punkte bekommt.
<G-vec00604-002-s126><bomb.bomben><en> Jewish terrorists tried using brute force to bomb the British out of the country.
<G-vec00604-002-s126><bomb.bomben><de> Mit brachialer Gewalt versuchten jüdische Terroristen, die Briten aus dem Land zu bomben.
<G-vec00604-002-s127><bomb.bomben><en> A deadly variety of internationally banned bomb with particularly cruel effects had thus began to be used.
<G-vec00604-002-s127><bomb.bomben><de> Man beginnt mit der Verwendung einer todbringenden Auswahl von besonders grausamen und international verbotenen Bomben.
<G-vec00604-002-s128><bomb.bomben><en> The bomb effect refers to the phenomenon that produced “artificial” radiocarbon in the atmosphere due to nuclear bombs.
<G-vec00604-002-s128><bomb.bomben><de> Als Bomben Effekt bezeichnet man die von Atombomben ausgelöste “künstliche” C-14 Anreicherung in der Atmosphäre.
<G-vec00604-002-s129><bomb.bomben><en> Fight as the counter terrorist S.A.W.T CT team or the terrorist mafia leader and plant bomb.
<G-vec00604-002-s129><bomb.bomben><de> Kämpfen Sie als Team des Terrorismus-Terroristen S.A.W.T oder des Mafia-Führers und pflanzen Bomben.
<G-vec00604-002-s130><bomb.bomben><en> Fixed the issue when Sam was no longer in the jeep's turret after placing two bomb and being kill several time in 'Black Gold' mission.
<G-vec00604-002-s130><bomb.bomben><de> Behebung eines Fehlers, durch den Sam nicht mehr den Geschützturm des Jeeps bemannt hat, sobald zwei Bomben gelegt waren und er mehrfach innerhalb der Mission „Schwarzes Gold“ getötet wurde.
<G-vec00604-002-s131><bomb.bomben><en> The human brain can also do destructive things – such as build a bomb, indulge in genocide and take advantages of the computer’s weaknesses to wreck havoc the internet.
<G-vec00604-002-s131><bomb.bomben><de> Aber der Mensch ist auch in der Lage destruktive Dinge zu tun – wie zum Beispiel Bomben bauen, Völkermord zu begehen oder aber auch die Schwächen von Computern auszunutzen, um Chaos und Zerstörung bei der alltäglichen Nutzung des Internets zu bringen.
<G-vec00604-002-s132><bomb.bomben><en> The building suffered bomb damage during World War II and was set on fire by the retreating German army in 1945.
<G-vec00604-002-s132><bomb.bomben><de> Ende des Zweiten Weltkriegs wurde das Haus durch Bomben beschädigt und beim Abzug der Deutschen Wehrmacht in Brand gesteckt.
<G-vec00604-002-s133><bomb.bomben><en> Space bar to drop bomb.
<G-vec00604-002-s133><bomb.bomben><de> Leertaste, um Bomben fallen zu lassen.
<G-vec00604-002-s134><bomb.bomben><en> But don't worry, in our Free Online Bomb Games, no one will get hurt.
<G-vec00604-002-s134><bomb.bomben><de> Aber keine Sorge, bei unseren kostenlosen Online Bomben Spielen wird niemand verletzt.
<G-vec00604-002-s135><bomb.bomben><en> Therefore they can manufacture weapon or bomb with the gross things.
<G-vec00604-002-s135><bomb.bomben><de> Sie können Waffen oder Bomben mit diesen groben Dingen schaffen.
