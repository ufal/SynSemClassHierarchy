<G-vec00380-002-s162><discard.ablegen><en> When Revealed: Discard 1 random card from your hand.
<G-vec00380-002-s162><discard.ablegen><de> Wenn aufgedeckt: Lege 1 zufällige Karte von deiner Hand ab.
<G-vec00380-002-s163><discard.ablegen><en> If you succeed, discard Voice of the Jungle.
<G-vec00380-002-s163><discard.ablegen><de> Falls die Probe gelingt, lege die Stimme des Dschungels ab.
<G-vec00380-002-s164><discard.ablegen><en> Reaction: After you marshal Newly-Made Lord, choose a non-limited location with printed cost 3 or lower, and discard it from play.
<G-vec00380-002-s164><discard.ablegen><de> Reaktion: Nachdem du Frischgebackener Lord aufmarschieren lassen hast, wähle einen nicht-limitierten Ort mit aufgedruckten Kosten von 3oder weniger und lege ihn aus dem Spiel ab.
<G-vec00380-002-s165><discard.ablegen><en> Keep the wild card and the three-card straight flush and discard the other card.
<G-vec00380-002-s165><discard.ablegen><de> Behalte die Wild Card und den 3 karten Straight Flush und lege die andere Karte ab.
<G-vec00380-002-s166><discard.ablegen><en> Keep the four-card royal flush and discard the other card.
<G-vec00380-002-s166><discard.ablegen><de> Behalte den Vier Karten Royal Flush und lege die andere Karte ab.
<G-vec00380-002-s167><discard.ablegen><en> If you fail you must either (choose one): discard the top 5 cards of your deck, or take 1 direct damage and deal 1 damage to each of your allies.
<G-vec00380-002-s167><discard.ablegen><de> Falls die Probe misslingt, musst du entweder (wähle eins): Lege die obersten 5 Karten deines Decks ab oder nimm 1 direkten Schaden und füge jedem deiner Verbündeter-Vorteilskarten 1 Schaden zu.
<G-vec00380-002-s168><discard.ablegen><en> 1x 244 in Forced - At the end of the round, if The Gate to Hell is in play: Discard the location that is farthest from The Gate to Hell.
<G-vec00380-002-s168><discard.ablegen><de> - 3a Erzwungen - Falls sich am Ende der Runde Das Tor zur Hölle im Spiel befindet: Lege den Ort ab, der am weitesten vom Tor zur Hölle entfernt ist.
<G-vec00380-002-s169><discard.ablegen><en> If you control Arya Stark, discard Cat o' the Canals from play.
<G-vec00380-002-s169><discard.ablegen><de> Falls du Arya Stark kontrollierst, lege Cat von den Kanälen aus dem Spiel ab.
<G-vec00380-002-s170><discard.ablegen><en> Discard cards from the encounter deck until a Wight enemy is discarded.
<G-vec00380-002-s170><discard.ablegen><de> Lege Karten vom Begegnungsdeck ab, bis ein Unhold-Gegner abgelegt wird.
<G-vec00380-002-s171><discard.ablegen><en> When Revealed: Discard 1 villager token from the active location for each player in the game.
<G-vec00380-002-s171><discard.ablegen><de> Wenn aufgedeckt: Lege 1 Dorfbewohner-Marker für jeden Spieler im Spiel vom aktiven Ort ab.
<G-vec00380-002-s172><discard.ablegen><en> - If agenda 2c is in play, take 2 horror and discard 2 cards from your hand.
<G-vec00380-002-s172><discard.ablegen><de> - Falls sich Agenda 2c im Spiel befindet, nimm 2 Horror und lege 2 Karten von deiner Hand ab.
<G-vec00380-002-s173><discard.ablegen><en> 2x Set 259 Technologisches Reaction: After a Speeder or Fighter unit you control is focused to strike, discard an event card from your hand to have that unit gain () until the end of the strike.
<G-vec00380-002-s173><discard.ablegen><de> Reaktion: Nachdem eine Gleiter- oder Raumjäger-Einheit, die du kommandierst, auf einen Angriffsschlag fokussiert worden ist, lege eine Ereignis karte von deiner Hand ab, damit die Einheit bis zum Ende des Angriffsschlags () erhält.
<G-vec00380-002-s174><discard.ablegen><en> Response: After attached hero exhausts to defend an attack, discard the top card of the encounter deck.
<G-vec00380-002-s174><discard.ablegen><de> Reaktion: Nachdem der Held mit dieser Verstärkung erschöpft worden ist, um gegen einen Angriff zu verteidigen, lege die oberste Karte des Begegnungsdecks ab.
<G-vec00380-002-s175><discard.ablegen><en> 3x 028 in Marshalling: Discard Narrow Sea from play to reduce the cost of the next or character you play this phase by 2.
<G-vec00380-002-s175><discard.ablegen><de> Aufmarsch: Lege Narrow Sea aus dem Spiel ab, um die Kosten des nächsten - oder -Charakters, den du in dieser Phase spielst, um 2 zu reduzieren.
<G-vec00380-002-s247><discard.abwerfen><en> Discard a card from your hand and draw a card from your extra deck.
<G-vec00380-002-s247><discard.abwerfen><de> Wirf eine Karte aus deiner Hand ab und ziehe eine Karte aus deinem Extradeck.
<G-vec00380-002-s248><discard.abwerfen><en> Discard all the cards in your hand to the Graveyard.
<G-vec00380-002-s248><discard.abwerfen><de> Wirf alle Karten in deiner Hand auf den Friedhof ab.
<G-vec00380-002-s249><discard.abwerfen><en> FLIP: You can draw 2 cards, then discard 1 card.
<G-vec00380-002-s249><discard.abwerfen><de> FLIPP: Du kannst 2 Karten ziehen, dann wirf 1 Karte ab.
<G-vec00380-002-s250><discard.abwerfen><en> When this face-up card you control is targeted by an opponent's Effect Monster's effect, look at your opponent's hand and discard 1 card from their hand.
<G-vec00380-002-s250><discard.abwerfen><de> Bevor ein Monstereffekt deines Gegners aufgelöst wird, sieh dir die Hand deines Gegners an und wirf 1 Karte von seiner Hand ab.
<G-vec00380-002-s251><discard.abwerfen><en> Discard 1 card from your hand. Negate the effect of a Trap Card that targets 1 face-up Dragon-Type monster and destroy the Trap Card.
<G-vec00380-002-s251><discard.abwerfen><de> Wirf 1 Karte aus deiner Hand ab, um den Effekt einer Fallenkarte, die 1 offenes Monster vom Typ Drache als Ziel bestimmt, zu annullieren und die Fallenkarte zu zerstören.
<G-vec00380-002-s252><discard.abwerfen><en> Discard the remaining cards to the Graveyard.
<G-vec00380-002-s252><discard.abwerfen><de> Wirf die übrigen Karten auf deinen Friedhof ab.
<G-vec00380-002-s253><discard.abwerfen><en> When this card inflicts Battle Damage to your opponent by a direct attack, your opponent must discard 1 random card from their hand.
<G-vec00380-002-s253><discard.abwerfen><de> Wenn diese Karte deinem Gegner Kampfschaden durch einen direkten Angriff zufügt, wirf 1 zufällige Karte von der Hand deines Gegners ab.
<G-vec00380-002-s254><discard.abwerfen><en> Discard this card from your hand. Until the End Phase, make the Battle Damage to monsters that include "Gravekeeper's" in their card name 0.
<G-vec00380-002-s254><discard.abwerfen><de> Wirf diese Karte aus deiner Hand ab, um Kampfschaden, den alle Monster, deren Name "Grabwächter" enthält, bis zur End Phase dieses Spielzugs erhalten, 0 werden zu lassen.
<G-vec00380-002-s255><discard.abwerfen><en> At the end of your Battle Phase, if this card attacked or was attacked: Shuffle this card into the Deck or discard 1 card.
<G-vec00380-002-s255><discard.abwerfen><de> Am Ende deiner Battle Phase, falls diese Karte angegriffen hat oder angegriffen wurde: Mische diese Karte ins Deck oder wirf 1 Karte ab.
<G-vec00380-002-s044><discard.aufnehmen><en> The slowest player to do so needs to pick up all cards from the discard pile and add them to his hand.
<G-vec00380-002-s044><discard.aufnehmen><de> Der Spieler, der dabei am langsamsten ist, muss alle Karten aus dem Ablagestapel aufnehmen und seinem Blatt hinzufügen.
<G-vec00380-002-s045><discard.aufnehmen><en> In this situation a player must take the discard if the pile is not frozen and if the discard matches any of that player's melds.
<G-vec00380-002-s045><discard.aufnehmen><de> In dieser Situation muss ein Spieler den Ablagestapel aufnehmen, wenn er nicht blockiert oder gesperrt ist und wenn die abgelegte Karte zu einer vorherigen Auslage der Partnerschaft dieses Spielers passt.
<G-vec00380-002-s121><discard.entfernen><en> Cut off and discard the stems of the mushrooms, then toss them with a marinade made of a little lime juice, 4 Tbsp olive oil, rosemary, half of the thyme, salt and pepper.
<G-vec00380-002-s121><discard.entfernen><de> Die Stiele der Pilze entfernen und mit einer Marinade aus etwas Limettensaft, 4 Esslöffel Olivenöl, Rosmarin, der Hälfte des Thymians, Salz und Pfeffer bestreichen.
<G-vec00380-002-s122><discard.entfernen><en> Peel the fresh asparagus and discard the woody parts.
<G-vec00380-002-s122><discard.entfernen><de> Den frischen Spargel schälen und die holzigen Enden entfernen.
<G-vec00380-002-s123><discard.entfernen><en> Discard cinnamon stick.
<G-vec00380-002-s123><discard.entfernen><de> Zimtstange entfernen.
<G-vec00380-002-s124><discard.entfernen><en> While shredding the beef, you should also discard any fat.
<G-vec00380-002-s124><discard.entfernen><de> Während des Zerkleinerns solltest du ebenso das Fett entfernen.
<G-vec00380-002-s125><discard.entfernen><en> Function to select audio tracks and subtitles as well as the possibility to discard unwanted parts.
<G-vec00380-002-s125><discard.entfernen><de> Funktion, um Audiotracks und Untertitel auszuwählen und auch die Möglichkeit, ungewollte Teile zu entfernen.
<G-vec00380-002-s126><discard.entfernen><en> Discard after use and gently pat remaining serum into skin.
<G-vec00380-002-s126><discard.entfernen><de> Nach Gebrauch entfernen und die verbliebenen Pflegereste sanft in die Haut klopfen.
<G-vec00380-002-s127><discard.entfernen><en> Squeeze the spice bag carefully and discard.
<G-vec00380-002-s127><discard.entfernen><de> Den Gewürzbeutel vorsichtig ausdrücken und entfernen.
<G-vec00380-002-s128><discard.entfernen><en> Crop bitmap images directly within Illustrator to discard excess parts, reduce file size and improve performance.
<G-vec00380-002-s128><discard.entfernen><de> Bitmap-Bilder lassen sich direkt in Illustrator zuschneiden, um unerwünschte Bereiche zu entfernen, die Dateigröße zu reduzieren und Ladezeiten zu verkürzen.
<G-vec00380-002-s145><discard.entsorgen><en> Discard the used pre-filled syringe and other supplies in a sharps disposal container.
<G-vec00380-002-s145><discard.entsorgen><de> Entsorgen Sie die gebrauchte Fertigspritze und andere Materialien in einem durchstichsicheren Behälter.
<G-vec00380-002-s146><discard.entsorgen><en> Discard old gaskets, diaphragms and springs, and replace them with parts from an original manufacturer's repair kit.
<G-vec00380-002-s146><discard.entsorgen><de> Entsorgen Sie alte Dichtungen, Deckenscheiben und Federn und ersetzen Sie diese mit Teilen aus einem Reparatur-Kit des Originalherstellers.
<G-vec00380-002-s147><discard.entsorgen><en> Discard empty container with hazardous waste.
<G-vec00380-002-s147><discard.entsorgen><de> Entsorgen Sie den leeren Behälter im Sondermüll.
<G-vec00380-002-s148><discard.fallenlassen><en> Indeed, once the imperialists decide they no longer need their Kurdish nationalist stooges, they will discard them, as they have repeatedly done before.
<G-vec00380-002-s148><discard.fallenlassen><de> Es stimmt: Wenn die Imperialisten befinden, dass sie ihre kurdischen nationalistischen Handlanger nicht mehr brauchen, werden sie sie fallenlassen, wie sie es zuvor schon wiederholt getan haben.
<G-vec00380-002-s149><discard.fallenlassen><en> A far larger group will hear the facts and discard them, with any number of excuses.
<G-vec00380-002-s149><discard.fallenlassen><de> Eine weit größere Gruppe wird die Fakten hören und sie fallenlassen, mit irgendeiner Zahl von Entschuldigungen.
<G-vec00380-002-s181><discard.löschen><en> In the event that we become aware that a user under the age of 18 has shared any information, we will discard such information.
<G-vec00380-002-s181><discard.löschen><de> Sollte uns bekannt werden, dass ein Benutzer unter 18 Jahren Informationen bekannt gegeben hat, löschen wir diese Informationen.
<G-vec00380-002-s182><discard.löschen><en> You can discard objects created in Acrobat and in other applications.
<G-vec00380-002-s182><discard.löschen><de> Sie können in Acrobat DC und anderen Anwendungen erstellte Objekte löschen.
<G-vec00380-002-s183><discard.löschen><en> If your Membership is inactive for a period of over 365 days, PrinterStudio.de may remove and discard all Content uploaded by you or otherwise made available by you within the Service.
<G-vec00380-002-s183><discard.löschen><de> Wenn Ihre Mitgliedschaft über einen Zeitraum von 365 Tagen inaktiv ist, behält sich PrinterStudio.de das Recht vor, sämtlichen von Ihnen hochgeladenen oder sonst wie mit Hilfe unserer Services zugänglich gemachten Inhalt zu entfernen und zu löschen.
<G-vec00380-002-s184><discard.löschen><en> Despite the fact that contextual advertising systems try to combat the click fraud, their efforts are not enough, since in ambiguous situations they must judge between advertisers and ad sites and discard only clicks that are 100% cheats.
<G-vec00380-002-s184><discard.löschen><de> Obwohl die Systeme der Kontextwerbung gegen den Klickbetrug kämpfen, reicht es nicht aus, denn sie fungieren in uneindeutigen Situationen ähnlich wie ein Richter zwischen den Werbetreibenden und den Werbeplattformen und löschen nur Klicks, die mit hundertprozentiger Sicherheit Täuschungen sind.
<G-vec00380-002-s209><discard.verwerfen><en> Under Upload Pending, click Resolve, and then choose Discard.
<G-vec00380-002-s209><discard.verwerfen><de> Klicken Sie unter Upload ausstehend auf Auflösen, und wählen Sie dann Verwerfen aus.
<G-vec00380-002-s210><discard.verwerfen><en> If you decide you don't want to send your message, choose Discard.
<G-vec00380-002-s210><discard.verwerfen><de> Wenn Sie sich entscheiden, dass Sie Ihre Nachricht nicht senden möchten, wählen Sie Verwerfen aus.
<G-vec00380-002-s211><discard.verwerfen><en> If you decide not to keep your message, choose Discard.
<G-vec00380-002-s211><discard.verwerfen><de> Wenn Sie sich entscheiden, Ihre Nachricht nicht zu behalten, wählen Sie Verwerfen aus.
<G-vec00380-002-s155><discard.weglegen><en> Fold - Discard hand and no longer remain active to participate in the hand.
<G-vec00380-002-s155><discard.weglegen><de> Aussteigen: Karten weglegen und nicht mehr aktiv an diesem Spiel teilnehmen.
<G-vec00380-002-s237><discard.wegwerfen><en> The ceramic replicated soda and beer cans in a wire mesh basket reflect our propensity to consume and discard with little attention paid to our health, the environment, short and long term effects of our actions.
<G-vec00380-002-s237><discard.wegwerfen><de> Die aus Keramik nachgebildeten Getränkedosen in einem Drahtkorb spiegeln unsere Neigung wider, zu konsumieren und wegzuwerfen, ohne auf unsere Gesundheit, die Umwelt, die kurz- und langfristigen Folgen unseres Handelns zu achten.
<G-vec00380-002-s238><discard.wegwerfen><en> If you notice a toy that becomes ripped, torn, or has loose parts, it’s time to remove and discard that toy.
<G-vec00380-002-s238><discard.wegwerfen><de> Wenn Sie an einem Spielzeug Beschädigungen, lose Teile oder Fetzen feststellen, ist es an der Zeit, das Spielzeug wegzuwerfen.
<G-vec00380-002-s239><discard.wegwerfen><en> - ability to utilize by-products rather than discard them.
<G-vec00380-002-s239><discard.wegwerfen><de> - die Fähigkeit, Nebenprodukte zu verwenden, anstatt sie wegzuwerfen.
<G-vec00380-002-s240><discard.wegwerfen><en> The skill to gambling the machine is knowing which cards to discard.
<G-vec00380-002-s240><discard.wegwerfen><de> Das Know-how zum Spiel der Maschine ist, zu wissen, welche Karten wegzuwerfen.
<G-vec00380-002-s241><discard.wegwerfen><en> Please dispose of ashes and butts only in the ashtrays provided, don't flush them down the toilet nor discard them in our grounds or any other part of the Natural Reserve.
<G-vec00380-002-s241><discard.wegwerfen><de> Wir bitten Sie, die Zigarettenkippe ausschließlich in Aschenbechern zu entsorgen und bitte vermeiden Sie es, diese in das WC, in den Garten oder sonstwo im Reservat wegzuwerfen.
<G-vec00380-002-s108><discard.werfen><en> Every conceivable sweet treat, classic and exotic kinds of punch, and hot soups in bread quickly let us discard any thoughts of going on a diet!
<G-vec00380-002-s108><discard.werfen><de> Alle erdenklichen Süßigkeiten, klassische und exotische Punschsorten und heiße Suppen im Brot lassen uns mögliche Diätgedanken schnell über Bord werfen.
<G-vec00380-002-s109><discard.werfen><en> Enterprises that want to change and develop successfully need to be willing to liberate themselves from conventions and to discard solutions that have ceased to be effective.
<G-vec00380-002-s109><discard.werfen><de> Wer sich erfolgreich verändern und weiterentwickeln will, muss bereit sein, Konventionen anzugreifen und Altbewährtes über Bord zu werfen.
<G-vec00380-002-s110><discard.werfen><en> Further, I think that we must also discard certain other concepts taken from Marx's Capital -- where Marx was concerned with an analysis of capitalism -- and artificially applied to our socialist relations.
<G-vec00380-002-s110><discard.werfen><de> Mehr noch, ich denke, es ist notwendig, auch einige andere Begriffe über Bord zu werfen, die dem „Kapital“ von Marx entnommen sind, wo Marx sich mit der Analyse des Kapitalismus beschäftigt hat, und die unseren sozialistischen Verhältnissen künstlich angeheftet werden.
