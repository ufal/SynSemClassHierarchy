<G-vec00301-001-s038><clear_up.deaktivieren><en> We have improved quality control processes of clear stamps for scrapbooking to ensure each export qualified product.
<G-vec00301-001-s038><clear_up.deaktivieren><de> Wir haben von Deaktivieren Sie Briefmarken für scrapbooking verbesserte Qualitätskontrolle, jede Export qualifiziertes Produkt zu gewährleisten.
<G-vec00301-001-s039><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body can clear more fat.
<G-vec00301-001-s039><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr um sicherzustellen, dass Ihre physischen Körper viel mehr Fettgewebe deaktivieren kann.
<G-vec00301-001-s040><clear_up.deaktivieren><en> Select or clear the Use international settings check box.
<G-vec00301-001-s040><clear_up.deaktivieren><de> Aktivieren oder deaktivieren Sie das Kontrollkästchen Internationale Einstellungen verwenden.
<G-vec00301-001-s041><clear_up.deaktivieren><en> Then clear the wall brush and moistened with water.
<G-vec00301-001-s041><clear_up.deaktivieren><de> Deaktivieren Sie dann die Wand Pinsel und mit Wasser angefeuchtet.
<G-vec00301-001-s042><clear_up.deaktivieren><en> Clear Automatic date & time and Automatic time zone, and then set the time zone, date, and time as required.
<G-vec00301-001-s042><clear_up.deaktivieren><de> Deaktivieren Sie die Optionen Automatisch Datum & Uhrzeit und Automatische Zeitzone und stellen Sie anschließend die Zeitzone, das Datum und die Uhrzeit ein.
<G-vec00301-001-s043><clear_up.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00301-001-s043><clear_up.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Ressourcenpartner aktivieren das Kontrollkästchen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00301-001-s044><clear_up.deaktivieren><en> Bobble Shooter - Clear all the bubbles from the board .
<G-vec00301-001-s044><clear_up.deaktivieren><de> Bobble Shooter - Deaktivieren Sie alle Blasen vom Spielfeld.
<G-vec00301-001-s046><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This active ingredient really helps up your metabolic price so that your body could clear much more fat deposits.
<G-vec00301-001-s046><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: dieser Stoff hilft Ihre metabolische Preis um sicherzustellen, dass Ihre physischen Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00301-001-s047><clear_up.deaktivieren><en> Clear this option to prohibit Web service extensions from running on your Web server.
<G-vec00301-001-s047><clear_up.deaktivieren><de> Deaktivieren Sie diese Option, um das Ausführen der Webdiensterweiterungen auf dem Server nicht zuzulassen.
<G-vec00301-001-s048><clear_up.deaktivieren><en> order to detect subtle, keep clear the brain, read the thoughts of those who are thinking of you, very helpful and good help breathing exercises that produce different nostrils, it can be done sitting or standing in front of the open window, in a wellventilated room.
<G-vec00301-001-s048><clear_up.deaktivieren><de> um zu erkennen, subtil, zu halten deaktivieren Sie das Gehirn, lesen Sie die Gedanken derer, die daran denken, Sie, sehr hilfsbereit und gute Hilfe Atemübungen, die verschiedenen Nasenlöcher zu erzeugen, kann es getan sitzen oder stehen vor dem offenen Fenster, in einem gut werdenbelüfteten Raum.
<G-vec00301-001-s049><clear_up.deaktivieren><en> Clear the apples from seeds and rind, cut into strips.
<G-vec00301-001-s049><clear_up.deaktivieren><de> Deaktivieren Sie die Äpfel aus Samen und Rinde, in Streifen geschnitten.
<G-vec00301-001-s050><clear_up.deaktivieren><en> Clear all options.
<G-vec00301-001-s050><clear_up.deaktivieren><de> Deaktivieren Sie alle Optionen.
<G-vec00301-001-s051><clear_up.deaktivieren><en> To enable or prevent wireless networks from displaying in the Connect to a network dialog box, either select or clear Allow user to view denied networks.
<G-vec00301-001-s051><clear_up.deaktivieren><de> Aktivieren oder deaktivieren Sie Anzeigen von abgelehnten Netzwerken für Benutzer zulassen, um zu ermöglichen oder zu verhindern, dass Drahtlosnetzwerke im Dialogfeld Verbindung mit einem Netzwerk herstellen angezeigt werden.
<G-vec00301-001-s052><clear_up.deaktivieren><en> When the lake level rises another 2 or 3 feet, sunlight won’t reach the roots of plants and they will die and clear out the surface.
<G-vec00301-001-s052><clear_up.deaktivieren><de> Wenn der See steigt ein anderer 2 oder 3 Füße, Sonnenlicht wird nicht an die Wurzeln der Pflanzen, und sie werden sterben, und deaktivieren Sie die Oberfläche.
<G-vec00301-001-s053><clear_up.deaktivieren><en> If you’ve ever needed to force stop, or clear the data/cache from an app, this is a welcome addition as it makes finding this page much, much easier.
<G-vec00301-001-s053><clear_up.deaktivieren><de> Wenn Sie jemals benötigt wird, um Gewalt zu stoppen, oder deaktivieren Sie die Daten / Cache aus einer App, Dies ist eine willkommene Ergänzung, da es viel zu finden Diese Seite macht, viel einfacher.
<G-vec00301-001-s054><clear_up.deaktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00301-001-s054><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00301-001-s055><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body could clear much more fat deposits.
<G-vec00301-001-s055><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr, damit Ihr Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00301-001-s056><clear_up.deaktivieren><en> To stop filtering altogether, in the key table, clear the check box next to Image.
<G-vec00301-001-s056><clear_up.deaktivieren><de> Deaktivieren Sie in der Schlüsseltabelle das Kontrollkästchen neben Abbild, um die gesamte Filterung zu beenden.
<G-vec00301-001-s361><clear_up.klären><en> There was never a clear plan or idea of what we were to do.
<G-vec00301-001-s361><clear_up.klären><de> Es gab niemals einen klaren Plan oder Idee, was wir tun sollten.
<G-vec00301-001-s362><clear_up.klären><en> Sound is particularly convincing by its clear mids and highs.
<G-vec00301-001-s362><clear_up.klären><de> Das Klangbild überzeugt dabei vor allem durch seine klaren Mitten und Höhen.
<G-vec00301-001-s363><clear_up.klären><en> This premium vodka convinces with a very clear and clean nose.
<G-vec00301-001-s363><clear_up.klären><de> Dieser erstklassige Premium Wodka überzeugt mit einer äußerst klaren und sauberen Nase.
<G-vec00301-001-s364><clear_up.klären><en> The authentic Maggiatal valley is popular for its rich nature and bathing in crystal clear waters.
<G-vec00301-001-s364><clear_up.klären><de> Das ursprüngliche Maggiatal ist beliebt für die Vielfalt der Natur und das Baden im klaren Fluss.
<G-vec00301-001-s365><clear_up.klären><en> The laptop is also designed to be used for Skype conferencing: Talk to your colleagues about important details of your next presentation and rely on the clear sound of the speakers as well as the good recording quality of the Microphone.
<G-vec00301-001-s365><clear_up.klären><de> Der Laptop ist darüber hinaus auch dafür geeignet, für Skype-Konferenzen eingesetzt zu werden: Sprechen Sie mit Ihren Kollegen über wichtige Details Ihrer nächsten Präsentation und verlassen Sie sich auf den klaren Sound der Lautsprecher sowie die gute Aufnahme-Qualität des Mikrofons.
<G-vec00301-001-s366><clear_up.klären><en> These third kind of workers in My vineyard will not act through great miracles, but will only work by means of the pure word and the script, without receiving any other striking revelation, except the inner, living word in feelings and thoughts in their hearts, and they will be full of the clear and reasonable faith and will thus without miracle deeds raise the withered people-shoots of My vineyard and will then also from Me receive the same reward, which you have received as workers for a full day; since they will encounter it as much more difficult to believe what more than a thousand years ago happened here. {mt20,06-14}
<G-vec00301-001-s366><clear_up.klären><de> Diese dritten Arbeiter in Meinem Weinberge werden nicht durch große Wundertaten, sondern allein durch das reine Wort und durch die Schrift wirken, ohne eine andere auffallende Offenbarung zu bekommen als nur die des inneren, lebendigen Wortes im Gefühl und in den Gedanken in ihrem Herzen, und sie werden voll des klaren und vernunftvollen Glaubens sein und werden sonach ohne Wunderwerke die verdorrten Menschenreben Meines Weinberges aufrichten und werden von Mir denn auch denselben Lohn bekommen, den ihr als die Arbeiter des ganzen Tages bekommen werdet; denn sie werden es um sehr vieles schwerer haben, fest und ungezweifelt an das zu glauben, was über tausend Jahre vor ihnen hier geschah.
<G-vec00301-001-s367><clear_up.klären><en> The strength of a committed group people, when focused on a clear objective, is just amazing.
<G-vec00301-001-s367><clear_up.klären><de> Es ist beeindruckend wie viel Kraft von einer Gruppe ausgeht, die einem klaren Ziel verpflichtet ist.
<G-vec00301-001-s368><clear_up.klären><en> Tugging on rubber gloves, a laboratory worker kneels before a gushing spigot behind Kim Grosso’s house and positions an empty bottle under the clear, cold stream.
<G-vec00301-001-s368><clear_up.klären><de> Zwicken sich Gummihandschuhe, Laborant kniet vor einem sprudelnden Zapfen hinter Kim Grosso-Haus und positioniert eine leere Flasche unter dem klaren, kalten Strom.
<G-vec00301-001-s369><clear_up.klären><en> However, with a few exceptions, these strategies and plans do not contain clear quantitative targets for digitisation as indicated in the Recommendation and the related Council Conclusions.
<G-vec00301-001-s369><clear_up.klären><de> Diese Strategien und Pläne enthalten jedoch – mit wenigen Ausnahmen – keine klaren quantitativen Vorgaben für die Digitalisierung, wie sie in der Empfehlung und den entsprechenden Schlussfolgerungen des Rates vorgesehen waren.
<G-vec00301-001-s370><clear_up.klären><en> By dissolving them there at the center of the six main chakras, we manifest clear light mind, which we then use for generating deep awareness of voidness.
<G-vec00301-001-s370><clear_up.klären><de> Dadurch, dass wir sie dort am Zentrum der sechs Hauptchakras auflösen, manifestieren wir den Geist des klaren Lichts, den wir dann für die Erzeugung von tiefem Gewahrsein der Leerheit verwenden.
<G-vec00301-001-s371><clear_up.klären><en> Enjoy breathing the air on summer evenings and enjoy the great panorama – in clear weather conditions the view stretches from the Bohemian Forest to the Dachstein.
<G-vec00301-001-s371><clear_up.klären><de> An Sommerabenden durchatmen und das großartige Panorama genießen – bei klaren Wetterverhältnissen reicht die Sicht vom Böhmerwald bis zum Dachstein.
<G-vec00301-001-s372><clear_up.klären><en> It requires that you have a clear and credible belief of why you act like you do.
<G-vec00301-001-s372><clear_up.klären><de> Es erfordert, dass du einen klaren und zuverlässigen Glauben darüber hast, warum du so handelst.
<G-vec00301-001-s373><clear_up.klären><en> At Northern, this program will provide a clear pathway towards a bachelor degree for students completing Career and Technical Education associate degrees in Drafting, Electricity and Renewable Energy and Pre-engineering.
<G-vec00301-001-s373><clear_up.klären><de> Am Nord, wird dieses Programm bieten einen klaren Weg hin zu einem Bachelor-Abschluss für Schüler, die Karriere und technische Bildung Associate Degrees in Drafting, Strom und erneuerbare Energien und Pre-Engineering.
<G-vec00301-001-s374><clear_up.klären><en> """Our own galaxy, which we see on a clear night as the Milky Way, is just one of countless millions in the universe."
<G-vec00301-001-s374><clear_up.klären><de> """Unsere eigene Galaxie, die wir in einer klaren Nacht als die Milchstraße sehen, ist nur eine von zahllosen Millionen im Universum."
<G-vec00301-001-s375><clear_up.klären><en> The views from Villa Fiorita include Mount Vesuvius and, on clear days, the islands of Ischia and Procida.
<G-vec00301-001-s375><clear_up.klären><de> Vom Villa Fiorita genießen Sie malerische Ausblicke auf den Vesuv und an klaren Tagen auch auf die Inseln Ischia und Procida.
<G-vec00301-001-s376><clear_up.klären><en> RISE Education Cayman Ltd does not show any clear trend in the medium long term.
<G-vec00301-001-s376><clear_up.klären><de> RISE Education Cayman Ltd zeigt keinen klaren Trendkanal auf mittlere Sicht.
<G-vec00301-001-s377><clear_up.klären><en> This eight page PDF e-pattern includes full size patterns, materials list, detailed instructions written in English, and clear step-by-step photographs.
<G-vec00301-001-s377><clear_up.klären><de> Diese acht Seite PDF e-Muster enthält Muster in voller Größe, Stückliste, ausführliche Anweisungen geschrieben auf Englisch und klaren Schritt-für-Schritt-Fotografien.
<G-vec00301-001-s378><clear_up.klären><en> If you could choose the company you worked for or did business with, the company that made appropriate use of private jets would have a clear advantage in this regard.
<G-vec00301-001-s378><clear_up.klären><de> Wenn Sie Ihren Arbeitgeber oder Geschäftspartner frei wählen könnten, hätte das Unternehmen mit einer entsprechenden Nutzung von Privatjets einen klaren Vorsprung.
<G-vec00301-001-s379><clear_up.klären><en> Start with a clear topic sentence that introduces the main point of your paragraph.
<G-vec00301-001-s379><clear_up.klären><de> Beginne mit einem klaren Anfangssatz, der den Hauptinhalt des Abschnitts vorstellt.
<G-vec00301-001-s418><clear_up.klären><en> So we have to clear it.
<G-vec00301-001-s418><clear_up.klären><de> Das müssen wir klären.
<G-vec00301-001-s419><clear_up.klären><en> If you find mold, do not attempt to clear it up yourself, as you will probably just spread it around .
<G-vec00301-001-s419><clear_up.klären><de> Wenn Sie Schimmel zu finden, Versuchen Sie nicht, es zu klären, sich selbst, wie Sie wahrscheinlich nur breitete es rund.
<G-vec00301-001-s420><clear_up.klären><en> Before one starts to design a model, it should be clear which information one needs to construct the model and which information is available.
<G-vec00301-001-s420><clear_up.klären><de> Bevor ein Modell für ein System entworfen wird, ist zu klären, welche Information man für die Modellierung benötigt und welche Information über das System zur Verfügung steht.
<G-vec00301-001-s421><clear_up.klären><en> Therefore, in order to make the terms and conditions clear, please contact us directly. Â
<G-vec00301-001-s421><clear_up.klären><de> Setzen Sie sich daher bitte mit uns direkt in Verbindung, um die jeweiligen Bedingungen und Konditionen zu klären.
<G-vec00301-001-s422><clear_up.klären><en> In traditional Chinese medicine, the leaves are considered to be of sweet, bitter and cold properties, which are associated with the liver and lung meridians, and functions to clear lung heat (to manifest as a fever, headache, sore throat or cough) and clear fire in the liver.
<G-vec00301-001-s422><clear_up.klären><de> In der traditionellen chinesischen Medizin haben die Blätter süße, bittere und kalte Eigenschaften, die mit den Leber- und Lungenmeridianen assoziiert sind, und sie klären die Lungenwärme (manifestieren sich als Fieber, Kopfschmerzen, Halsschmerzen oder Husten) und klares Feuer in der Leber.
<G-vec00301-001-s423><clear_up.klären><en> Your destiny is to ascend and many of you have already risen to a point where you have little or no karma to clear.
<G-vec00301-001-s423><clear_up.klären><de> Eure Zielbestimmung ist, aufzusteigen, und Viele unter euch haben sich bereits bis zu einem Punkt weiter aufwärtsentwickelt, an dem sie kaum noch oder gar kein Karma mehr zu klären haben.
<G-vec00301-001-s424><clear_up.klären><en> The Ace of Swords means that we have the chance now to clear things which had been unclear or incomprehensible.
<G-vec00301-001-s424><clear_up.klären><de> Das As der Schwerter bedeutet, dass sich uns die Chance bietet, Dinge zu klären, die uns bisher unklar oder unverständlich waren, Verwicklungen aufzulösen, Konflikte zu beheben.
<G-vec00301-001-s425><clear_up.klären><en> If ‘Da Greco’ doesn’t scream Italian, I’m sure the food at this restaurant will clear things up.
<G-vec00301-001-s425><clear_up.klären><de> "Wenn 'Da Greco ""schreit nicht italienisch, ich bin sicher, das Essen in diesem Restaurant werden die Dinge klären."
<G-vec00301-001-s426><clear_up.klären><en> "And ""Any auditing is better than no auditing"", because if you want to stop all auditing, then you don't clear."
<G-vec00301-001-s426><clear_up.klären><de> "Und ""Irgendein Auditing ist besser als gar kein Auditing"", denn wenn Sie das gesamte Auditing stoppen, klären Sie nicht."
<G-vec00301-001-s427><clear_up.klären><en> Worry not, reading this article can help clear some doubts.
<G-vec00301-001-s427><clear_up.klären><de> Sorge, diesen Artikel lesen helfen einige Zweifel klären kann.
<G-vec00301-001-s428><clear_up.klären><en> Specifically, time alone made it prohibitive to clear a population of billions by training enough Professional Auditors to deliver one-on-one auditing to every preclear on Earth.
<G-vec00301-001-s428><clear_up.klären><de> Insbesondere war der Faktor der Zeit sehr hinderlich dabei, eine Bevölkerung von Milliarden von Menschen zu klären, indem man genügend professionelle Auditoren ausbildet, um jedem Preclear auf der Welt auf individueller Basis Auditing zu geben.
<G-vec00301-001-s429><clear_up.klären><en> Your system is designed that way in order to clear the suppressed emotions.
<G-vec00301-001-s429><clear_up.klären><de> Euer System ist in einer Art entworfen, um unterdrückte Emotionen zu klären.
<G-vec00301-001-s430><clear_up.klären><en> """Oh, thats no problem"", I said, ""I meet him sometimes"", and I asked the man if a document would help to clear the circumstances."
<G-vec00301-001-s430><clear_up.klären><de> """Kein Problem"", sagte ich, ""den treffe ich ja gelegentlich"" und fragte noch, ob denn ein entsprechendes Schriftstück die Sachlage klären könnte."
<G-vec00301-001-s431><clear_up.klären><en> If we cannot provide the performance expected, we clear up the causes together and find possible solutions.
<G-vec00301-001-s431><clear_up.klären><de> Wenn wir die erwartete Leistung nicht erbringen können, klären wir gemeinsam Ursachen und finden Lösungsmöglichkeiten.
<G-vec00301-001-s432><clear_up.klären><en> Let us clear out first what the only method of the evolutionary process is.
<G-vec00301-001-s432><clear_up.klären><de> Klären wir zuerst was die einzige Methode des evolutionären Prozesses ist.
<G-vec00301-001-s433><clear_up.klären><en> Strive to clear your emotional body of pain.
<G-vec00301-001-s433><clear_up.klären><de> Strebt danach euren emotionalen Schmerzkörper zu klären.
<G-vec00301-001-s434><clear_up.klären><en> Before we ask ourselves whether God has accepted our penitence, we should get it clear what penitence actually is.
<G-vec00301-001-s434><clear_up.klären><de> Bevor wir uns fragen, ob Gott unsere Buße angenommen hat, sollten wir klären, was Buße eigentlich ist.
<G-vec00301-001-s435><clear_up.klären><en> We shouldn’t get stuck in our own concepts, but clear the hindrances of the concepts we have created.
<G-vec00301-001-s435><clear_up.klären><de> Wir sollten nicht in den eigenen Konzepten stecken bleiben, sondern die Hindernisse der Konzepte, die wir geschaffen haben, klären.
<G-vec00301-001-s436><clear_up.klären><en> So if you want to participate in the Master Cylinder, it is highly recommended that you try to clear out any areas within you or your life that are untrue BEFORE you come.
<G-vec00301-001-s436><clear_up.klären><de> Darum wird es in höchstem Maße empfohlen, dass du probierst, alle Bereiche in dir und deinem Leben zu klären, die unwahr sind, BEVOR du kommst.
<G-vec00301-001-s475><clear_up.löschen><en> The following VBA code can help you quickly clear contents of a textbox when double-clicking on it. Please do as follows.
<G-vec00301-001-s475><clear_up.löschen><de> Der folgende VBA-Code kann Ihnen helfen, Inhalte eines Textfelds schnell zu löschen, wenn Sie darauf doppelklicken.
<G-vec00301-001-s476><clear_up.löschen><en> A graceful restart can fail if the original Apache instance is not able to clear all necessary resources.
<G-vec00301-001-s476><clear_up.löschen><de> Ein ordnungsgemäßer Start kann fehlschlagen, wenn die originale Apache-Instanz nicht alle nötigen Ressourcen löschen kann.
<G-vec00301-001-s477><clear_up.löschen><en> Cheques take an average of three working days to clear.
<G-vec00301-001-s477><clear_up.löschen><de> Schecks einen Durchschnitt von drei Werktagen zu löschen.
<G-vec00301-001-s478><clear_up.löschen><en> All papers clear and you can begin construction immediately.
<G-vec00301-001-s478><clear_up.löschen><de> Alle Papiere zu löschen und Sie können Bau sofort beginnen.
<G-vec00301-001-s479><clear_up.löschen><en> iMyFone Umate Pro is handy in such a situation, as it helps to clear Facebook cache,delete WeChat account,clear cache on iPad&clear off all the temporary files freeing up sufficient storage space in the device.
<G-vec00301-001-s479><clear_up.löschen><de> iMyFone Animate Pro ist praktisch, in einer solchen Situation, wie es hilft, klar Facebook-Cache, löschen WeChat Konto, Löschen des Cache auf dem iPad & Löschen Sie alle temporären Dateien ausreichend Speicherplatz im Gerät der Freisetzung.
<G-vec00301-001-s481><clear_up.löschen><en> If you clear the cookies from your browser, you need to set the opt-out cookie once again.
<G-vec00301-001-s481><clear_up.löschen><de> Löschen Sie die Cookies in diesem Browser, müssen Sie das Opt-out-Cookie erneut setzen.
<G-vec00301-001-s482><clear_up.löschen><en> Coconut powder also can promote capillary blood circulation, anti-aging; to help clear the accumulation of oxygen free radicals.
<G-vec00301-001-s482><clear_up.löschen><de> Kokos Pulver kann auch Kapillare Durchblutung, Anti-Aging fördern; zu helfen, die Anhäufung von freien Sauerstoffradikalen zu löschen.
<G-vec00301-001-s483><clear_up.löschen><en> NOTE: If the changes are not applied, clear your browser cache and try again.
<G-vec00301-001-s483><clear_up.löschen><de> Hinweis: Wenn keine Änderungen erscheinen, löschen Sie bitte den Browserchache und versuchen Sie es erneut.
<G-vec00301-001-s484><clear_up.löschen><en> Lake Placid area offers 27 clear, freshwater lakes with some of the best fishing anywhere.
<G-vec00301-001-s484><clear_up.löschen><de> Lake Placid Bereich Angebote 27 Löschen, Süßwasserseen mit einigen der besten Fisch überall.
<G-vec00301-001-s485><clear_up.löschen><en> Blue, I, water, calm, meditative mood … and the result: clear, világos gondolatok.
<G-vec00301-001-s485><clear_up.löschen><de> Blau, I, Wasser, beruhigen, meditative Stimmung … und das Ergebnis: löschen, világos gondolatok.
<G-vec00301-001-s486><clear_up.löschen><en> Just like Mozilla Firefox, you have to follow some easy instructions to clear download history from your browser.
<G-vec00301-001-s486><clear_up.löschen><de> Genau wie Mozilla Firefox, müssen Sie einige einfache Anweisungen zu Download-Verlauf löschen aus Ihrem Browser folgen.
<G-vec00301-001-s487><clear_up.löschen><en> "Confirm your choice by clicking ""Clear all""."
<G-vec00301-001-s487><clear_up.löschen><de> "Bestätigen Sie Ihre Auswahl durch Klicken auf ""Alle löschen""."
<G-vec00301-001-s488><clear_up.löschen><en> You can also click Clear Bets to remove all bets from the Casino Hold 'Em table and start over.
<G-vec00301-001-s488><clear_up.löschen><de> Sie können auch auf „Einsätze löschen“ klicken, um alle Ihre Wetten auf dem Casino Hold'em Tisch zu löschen und um neu anzufangen.
<G-vec00301-001-s489><clear_up.löschen><en> Shoot back and clear the screen to get away from this crazy music.
<G-vec00301-001-s489><clear_up.löschen><de> Schieß zurück und löschen Sie den Bildschirm, um weg von diesem verrückten Musik.
<G-vec00301-001-s490><clear_up.löschen><en> The last used folder to import audio into an Alchemy Source is now remembered after the File > Clear command has been used.
<G-vec00301-001-s490><clear_up.löschen><de> "Der letzte verwendete Ordner zum Importieren von Audio in eine Alchemy-Quelle wird nun gespeichert, nachdem der Befehl ""Ablage"" > ""Löschen"" verwendet wurde."
<G-vec00301-001-s491><clear_up.löschen><en> You can click the brush icon to clear your chat history.
<G-vec00301-001-s491><clear_up.löschen><de> Sie können auch auf das Besen-Symbol klicken, um Ihren Chat-Verlauf zu löschen.
<G-vec00301-001-s492><clear_up.löschen><en> To clear browsing history on Safari, you can click the clear history on the history page or under the show all history view, you can right click on the individual links and click the delete option.
<G-vec00301-001-s492><clear_up.löschen><de> Um den Browserverlauf in Safari zu löschen, können Sie auf der Verlaufsseite auf Verlauf löschen klicken oder unter Gesamten Verlauf anzeigen mit der rechten Maustaste auf die einzelnen Links klicken und auf die Option zum Löschen klicken.
<G-vec00301-001-s513><clear_up.reinigen><en> We clear and cut onions, we fry till golden color on a frying pan.
<G-vec00301-001-s513><clear_up.reinigen><de> Wir reinigen und schneiden die Zwiebel, obschariwajem bis zur goldigen Farbe auf der Pfanne.
<G-vec00301-001-s514><clear_up.reinigen><en> At first it is necessary to clear well skin tonic, or lotion.
<G-vec00301-001-s514><clear_up.reinigen><de> Erstens muss man gut die Haut tonikom, oder der Lotion reinigen.
<G-vec00301-001-s515><clear_up.reinigen><en> If you can do your part to clear the air today you could make a huge difference in how your children and grandchildren live in the future.
<G-vec00301-001-s515><clear_up.reinigen><de> Wenn Sie Ihren Teil tun, um die Luft zu reinigen Sie heute könnte einen großen Unterschied machen, wie Ihre Kinder und Enkelkinder leben in der Zukunft.
<G-vec00301-001-s516><clear_up.reinigen><en> The mask from a peach with starch addition will help to clear and moisten fat skin: on 1 fruit 1 teaspoon of starch from potatoes suffices.
<G-vec00301-001-s516><clear_up.reinigen><de> Die fettige Haut wird helfen, zu reinigen und, die Maske aus dem Pfirsich mit der Ergänzung der Stärke zu befeuchten: auf 1 Frucht ist genug es 1 Teelöffel der Stärke aus den Kartoffeln.
<G-vec00301-001-s517><clear_up.reinigen><en> Touch honey agarics, clear, wash out in cold water, bring to boiling in a pan and merge water.
<G-vec00301-001-s517><clear_up.reinigen><de> Die Hallimasche lesen Sie aus, reinigen Sie, waschen Sie im kalten Wasser aus, führen Sie bis zum Kochen im Kochtopf hin und ziehen Sie das Wasser zusammen.
<G-vec00301-001-s518><clear_up.reinigen><en> At breaks in work a laying cover with roofing felt or a brick dry, and before renewal of works clear of snow, naledi and a frozen solution.
<G-vec00301-001-s518><clear_up.reinigen><de> Bei den Pausen in der Arbeit das Mauerwerk bedecken tolem oder dem Ziegel nassucho, und vor der Erneuerung der Arbeiten reinigen vom Schnee, naledi und merslogo der Lösung.
<G-vec00301-001-s519><clear_up.reinigen><en> Mushrooms to wash up, clear if necessary, also small to cut.
<G-vec00301-001-s519><clear_up.reinigen><de> Die Pilze auszuwaschen, falls notwendig zu reinigen, auch klein zu schneiden.
<G-vec00301-001-s520><clear_up.reinigen><en> Prepare the footwear for painting: clear it and dry.
<G-vec00301-001-s520><clear_up.reinigen><de> Bereiten Sie die Schuhe zu pokraske vor: reinigen Sie sie und trocknen Sie aus.
<G-vec00301-001-s521><clear_up.reinigen><en> To clear it it will be faster possible, if right after over cookings to pour cold water.
<G-vec00301-001-s521><clear_up.reinigen><de> Es reinigen es kann schneller, wenn sofort nach dem Kochen, vom kalten Wasser zu begießen.
<G-vec00301-001-s522><clear_up.reinigen><en> He is now asked to clear himself of the charge and show that he was still a pious Jew.
<G-vec00301-001-s522><clear_up.reinigen><de> Es wird ihm nun aufgetragen, sich von dieser Anklage zu reinigen und darzutun, daß er noch ein frommer Jude sei.
<G-vec00301-001-s523><clear_up.reinigen><en> Your task - with the reliable weapon in hands to clear the city of evil spirits and to rescue the innocent.
<G-vec00301-001-s523><clear_up.reinigen><de> Ihre Aufgabe - mit den sicheren Waffen in den Händen, die Stadt von der Teufelei zu reinigen und, die Unschuldigen zu retten.
<G-vec00301-001-s524><clear_up.reinigen><en> Before repair the damaged place clear of unsteadily keeping parts and plaster which lags behind a wall at a lung postukivanii.
<G-vec00301-001-s524><clear_up.reinigen><de> Vor der Reparatur die beschädigte Stelle reinigen von es ist der sich haltenden Teilchen und des Putzes nicht haltbar, der von der Wand bei der Lunge postukiwanii zurückbleibt.
<G-vec00301-001-s525><clear_up.reinigen><en> Easy to clear, using a dish cloth to wipe stains or clean it with water.
<G-vec00301-001-s525><clear_up.reinigen><de> Leicht zu reinigen, mit einem Spültuch, um Flecken abzuwischen oder mit Wasser zu reinigen.
<G-vec00301-001-s526><clear_up.reinigen><en> Breed bokoplavy in a considerable quantity, they not only clear water, but also play essential and even defining role in a food of almost all fishes and waterfowls.
<G-vec00301-001-s526><clear_up.reinigen><de> Pflanzen sich bokoplawy in der großen Menge fort, sie nicht nur reinigen das Wasser, sondern auch spielen wesentlich und sogar die bestimmende Rolle in einer Ernährung ist es aller Fische und der Wasservögel praktisch.
<G-vec00301-001-s527><clear_up.reinigen><en> In the beginning clear a hollow of dead wood and smooth out a sharp knife of its edge to the healthy.
<G-vec00301-001-s527><clear_up.reinigen><de> Zunächst reinigen duplo vom toten Holz und säubern vom scharfen Messer seines Randes bis zur Gesunden.
<G-vec00301-001-s528><clear_up.reinigen><en> The day before the exhibition I sent forth-righteous thoughts in front of the Chinese embassy, in order to clear the field for the next day.
<G-vec00301-001-s528><clear_up.reinigen><de> Am Tag vor der Ausstellung sendete ich vor der chinesischen Botschaft aufrichtige Gedanken aus, um das Feld für den nächsten Tag zu reinigen.
<G-vec00301-001-s529><clear_up.reinigen><en> Having chosen a place for a fire, it is necessary to clear the earth of turf accurately.
<G-vec00301-001-s529><clear_up.reinigen><de> die Stelle für das Feuer Gewählt, muss man die Erde vom Rasen akkurat reinigen.
<G-vec00301-001-s530><clear_up.reinigen><en> For its preparation take one small tomato, clear of a peel (that it was easier to be made, it is possible to obdat it boiled water) and small cut pulp.
<G-vec00301-001-s530><clear_up.reinigen><de> Für ihre Vorbereitung nehmen Sie eine kleine Tomate, reinigen Sie von der Schale (damit es war es leichter, zu machen, man kann es abbrühen) und ist nareschte das Fruchtfleisch klein.
<G-vec00301-001-s531><clear_up.reinigen><en> If together with a band the edge of trousers at first unpick the turned in edge of a bottom of trousers was wiped also, clear of a dirt and iron.
<G-vec00301-001-s531><clear_up.reinigen><de> Wenn zusammen mit der Borte auch der Rand der Hosen abgerieben wurde, so reinigen zuerst otparywajut podognutyj der Rand des Unterteils der Hosen, vom Schmutz und bügeln.
<G-vec00301-003-s038><clear_up.deaktivieren><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00301-003-s038><clear_up.deaktivieren><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00301-003-s039><clear_up.deaktivieren><en> Clear all the IIS Resource Kit Tools and components check boxes except the Metabase Explorer 1.6 check box.
<G-vec00301-003-s039><clear_up.deaktivieren><de> Deaktivieren Sie alle IIS Resource Kit Tools und Komponenten Kontrollkästchen außer dem KontrollkästchenMetabase Explorer 1.6 .
<G-vec00301-003-s040><clear_up.deaktivieren><en> * Word wipe: Clear the board for a Power Point bonus.
<G-vec00301-003-s040><clear_up.deaktivieren><de> * Wort wischen: Deaktivieren Sie das Board für eine Power-Point-Bonus.
<G-vec00301-003-s041><clear_up.deaktivieren><en> All you need is 45,000 points and then clear all the jellies.
<G-vec00301-003-s041><clear_up.deaktivieren><de> Alles, was Sie brauchen, ist 45.000 Punkte und dann deaktivieren Sie alle Gelees.
<G-vec00301-003-s042><clear_up.deaktivieren><en> However if, for example, you want to limit the Objectionable content policy to outbound mail, you can clear all check boxes except Outbound.
<G-vec00301-003-s042><clear_up.deaktivieren><de> Wenn Sie die Einstellung jedoch auf ausgehende E-Mails beschränken möchten, können Sie alle Kontrollkästchen außer "Ausgehend" deaktivieren.
<G-vec00301-003-s043><clear_up.deaktivieren><en> Clear the check boxes for products you do not want to repair.
<G-vec00301-003-s043><clear_up.deaktivieren><de> Deaktivieren Sie Kontrollkästchen für Produkte, die nicht repariert werden sollen.
<G-vec00301-003-s044><clear_up.deaktivieren><en> Clear the check box next to the folder you want to keep off this device.
<G-vec00301-003-s044><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen neben dem Ordner, der auf diesem Gerät nicht angezeigt werden soll.
<G-vec00301-003-s045><clear_up.deaktivieren><en> Clear this check box to hide these updates.
<G-vec00301-003-s045><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00301-003-s046><clear_up.deaktivieren><en> Open the document library and clear all check marks so no files are selected.
<G-vec00301-003-s046><clear_up.deaktivieren><de> Öffnen Sie die Dokumentbibliothek, und deaktivieren Sie alle Häkchen, sodass keine Dateien ausgewählt sind.
<G-vec00301-003-s047><clear_up.deaktivieren><en> Click to clear the Use Cached Exchange Mode checkbox, click Next, and then click Finish.
<G-vec00301-003-s047><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen Exchange-Cache-Modus verwenden, klicken Sie auf Weiterund dann auf Fertig stellenklicken.
<G-vec00301-003-s048><clear_up.deaktivieren><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00301-003-s048><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00301-003-s049><clear_up.deaktivieren><en> Clear all eight exciting levels and enjoy the
<G-vec00301-003-s049><clear_up.deaktivieren><de> Deaktivieren Sie alle acht spannende Levels und genießen das Spiel.
<G-vec00301-003-s050><clear_up.deaktivieren><en> Clear the setting that blocks activation.
<G-vec00301-003-s050><clear_up.deaktivieren><de> Deaktivieren Sie die Einstellung, die die Aktivierung blockiert.
<G-vec00301-003-s051><clear_up.deaktivieren><en> Select the Temporary Internet files check box, clear the other check boxes, and then click Delete.
<G-vec00301-003-s051><clear_up.deaktivieren><de> Aktivieren Sie das Kontrollkästchen Temporäre Internetdateien, deaktivieren Sie die übrigen Kontrollkästchen, und klicken Sie auf Löschen.
<G-vec00301-003-s052><clear_up.deaktivieren><en> If you do not want the Connect to MobiLink Server dialog to appear when you start the Monitor without command line options, clear the checkbox beside this option.
<G-vec00301-003-s052><clear_up.deaktivieren><de> Wenn das Fenster Mit dem MobiLink-Server verbinden beim Aufruf des MobiLink-Monitors ohne Befehlszeilenoptionen nicht erscheinen soll, deaktivieren Sie das Kontrollkästchen zu dieser Option.
<G-vec00301-003-s053><clear_up.deaktivieren><en> Eat a grass and clear a level.
<G-vec00301-003-s053><clear_up.deaktivieren><de> Essen Sie alle das Gras und deaktivieren Sie die Ebene.
<G-vec00301-003-s054><clear_up.deaktivieren><en> Clear series of exiting levels and have fun.
<G-vec00301-003-s054><clear_up.deaktivieren><de> Deaktivieren Sie alle Ebenen und gewinnen das Spiel zu.
<G-vec00301-003-s055><clear_up.deaktivieren><en> If you do not want to display table headers, on the Tables tab, under Table Options, clear Header Row.
<G-vec00301-003-s055><clear_up.deaktivieren><de> Hinweis: Wenn Sie keine Tabellenüberschriften anzeigen möchten, können Sie sie später deaktivieren.
<G-vec00301-003-s056><clear_up.deaktivieren><en> Clear the check box to display the docking area at the bottom of the window.
<G-vec00301-003-s056><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um den Andockbereich unten im Vegas-Fenster anzuzeigen.
<G-vec00301-003-s095><clear_up.deutlichen><en> Our consultants place a clear focus on committed customer orientation and solutions that guarantee sustainable growth for your company and at the same time strengthen your organizational flexibility.
<G-vec00301-003-s095><clear_up.deutlichen><de> Unsere Berater setzen einen deutlichen Fokus auf konsequente Kundenorientierung und Lösungen, die nachhaltiges Wachstum für ihr Geschäft garantieren und gleichzeitig ihre organisatorische Agilität stärken.
<G-vec00301-003-s096><clear_up.deutlichen><en> After clear price decreases having occurred over the past three weeks in Germany, the market is expected to remain well balanced the week ahead.
<G-vec00301-003-s096><clear_up.deutlichen><de> Nach den deutlichen Preisrückgängen in den vergangenen drei Wochen in Deutschland wird auch in der kommenden Schlachtwoche mit einem ausgeglichenen Markt gerechnet.
<G-vec00301-003-s097><clear_up.deutlichen><en> Description XVII century mansion, with clear traces of the architecture of old Castilian Mancha.
<G-vec00301-003-s097><clear_up.deutlichen><de> Beschreibung XVII century mansion, mit deutlichen Spuren der Architektur der alten kastilischen Mancha.
<G-vec00301-003-s098><clear_up.deutlichen><en> Leif has to release a part of his clear plus for RZE in August to now 118.
<G-vec00301-003-s098><clear_up.deutlichen><de> Leif muss von seinem deutlichen Plus für RZE im August einen Teil wieder abgeben (RZE 118).
<G-vec00301-003-s099><clear_up.deutlichen><en> Many of the products shown in Birmingham reveal that KBA has a clear technological edge over its competitors.
<G-vec00301-003-s099><clear_up.deutlichen><de> Bei vielen in Birmingham vorgestellten Lösungen hat sich KBA einen deutlichen technischen Vorsprung gegenüber Mitbewerbern erarbeitet.
<G-vec00301-003-s100><clear_up.deutlichen><en> In our opinion the final goal of the Company is not only pure profit but self-development and growing a technology-based organization useful to the government and society, with a clear understanding of voluntarily taken non-commercial and socially oriented obligations.
<G-vec00301-003-s100><clear_up.deutlichen><de> Ohne das Endergebnis des Unternehmensbestehens als das konkrete Ziel im Wertausdruck oder sonstig zu betrachten, sterben wir nach der ständigen Unterstützung der Selbstentwicklung des Unternehmens und der methodischen Bildung der fertigungsgerechten Organisation, die dem Staat und der Gesellschaft den Nutzen bringt, mit der deutlichen Auffassung von den freiwillig übernommenen gemeinnützigen und sozialorientierten Verpflichtungen.
<G-vec00301-003-s101><clear_up.deutlichen><en> The results of the model provide a clear indication that the highest CO2 savings can be achieved with installed CSP plants in the Middle East and Northern Africa.
<G-vec00301-003-s101><clear_up.deutlichen><de> Die Modellergebnisse liefern einen deutlichen Hinweis darauf, dass die höchsten CO2- Einsparungen mit installierten CSP-Anlagen im Mittleren Osten und Nordafrika erzielt werden können.
<G-vec00301-003-s102><clear_up.deutlichen><en> The moving image section in hall 5.2, with clear growth, especially in the audio area, showed the direction in which the segment should develop in future at photokina.
<G-vec00301-003-s102><clear_up.deutlichen><de> Der Bewegtbildbereich in Halle 5.2 zeigte mit einem deutlichen Zugewinn vor allem im Bereich Audio, wohin das Segment sich auf der photokina zukünftig entwickeln soll.
<G-vec00301-003-s103><clear_up.deutlichen><en> We are again counting on clear growth in the second half of the year in comparison with the prior year’s period and with the first half of 2014.
<G-vec00301-003-s103><clear_up.deutlichen><de> In der zweiten Jahreshälfte rechnen wir wieder mit einem deutlichen Wachstum – im Vergleich zum Vorjahreszeitraum und zum ersten Halbjahr 2014.
<G-vec00301-003-s104><clear_up.deutlichen><en> In these times of rising costs and empty coffers, the long lifetime and clear energy savings achievable with SUNfarming Greenlights help to significantly lower public spending on lighting.
<G-vec00301-003-s104><clear_up.deutlichen><de> In den Zeiten steigender Kosten und leerer Kassen können dank der besonders langen Lebensdauer und deutlichen Energieeinsparung mit SUNfarming Greenlights die öffentlichen Ausgaben für Beleuchtung erheblich gesenkt werden.
<G-vec00301-003-s105><clear_up.deutlichen><en> The keys have a clear pressure point but a short key drop.
<G-vec00301-003-s105><clear_up.deutlichen><de> Die Tasten haben einen deutlichen Druckpunkt, aber einen kleinen Hub.
<G-vec00301-003-s106><clear_up.deutlichen><en> With the new duplex test bench, which RINGSPANN RCS’ engineering department actively helped to implement, the company based in Oberursel should have a clear competitive advantage within its industry.
<G-vec00301-003-s106><clear_up.deutlichen><de> Mit dem neuen Duplex-Prüfstand, an deren Realisierung das Engineering von RINGSPANN RCS aktiv mitgewirkt hat, dürfte das Oberurseler Unternehmen innerhalb seiner Branche über einen deutlichen Wettbewerbsvorteil verfügen.
<G-vec00301-003-s107><clear_up.deutlichen><en> The very quiet opening, even when under preload, and the high 5,000 N retention force are features of all products in the A4000 vector electric strike series: they are the result of clear optimisation of power vectors within the electric strike.
<G-vec00301-003-s107><clear_up.deutlichen><de> Das sehr leise Öffnen auch unter Vorlast und die hohen Haltekräfte von 5.000 N zeichnen die A4000 Vektortüröffner-Reihe aus: Sie sind das Ergebnis einer deutlichen Optimierung der Kraftvektoren innerhalb des Türöffners.
<G-vec00301-003-s108><clear_up.deutlichen><en> Everyone would like to make this happen, and golf4you has a clear head start in the game.
<G-vec00301-003-s108><clear_up.deutlichen><de> Jeder möchte es realisieren, aber golf4you hat einen deutlichen Vorsprung.
<G-vec00301-003-s109><clear_up.deutlichen><en> Construction materials with an EPD have a clear advantage when submitting tenders in sustainable building projects.
<G-vec00301-003-s109><clear_up.deutlichen><de> Baustoffe, die eine EPD vorweisen, haben einen deutlichen Vorteil bei der Teilnahme an nachhaltigen Bauprojekten.
<G-vec00301-003-s110><clear_up.deutlichen><en> The unusually serious Trio with its fugati and an almost painful mood builds a clear contrast to the boisterous prestissimo with hobbling rhythms and roaring chromaticism.
<G-vec00301-003-s110><clear_up.deutlichen><de> Einen deutlichen Kontrast zu dem übermütigen Prestissimo mit hinkenden Rhythmen und brausender Chromatik bildet das ungewöhnlich ernste Trio mit seinen Fugati und seiner fast schmerzlichen Stimmung.
<G-vec00301-003-s111><clear_up.deutlichen><en> 18% count on a clear rise of climatic refugees from particularly areas heavily concerned of the earth.
<G-vec00301-003-s111><clear_up.deutlichen><de> 18% rechnen mit einem deutlichen Anstieg von Klimaflüchtlingen aus besonders schwer betroffenen Gebieten der Erde.
<G-vec00301-003-s112><clear_up.deutlichen><en> The Spanish holiday season draws to a close gradually, so that export markets are being taken a closer look at in Spain again. Clear price reductions are coming along with it.
<G-vec00301-003-s112><clear_up.deutlichen><de> In Spanien neigt sich die Urlaubssaison allmählich dem Ende zu, so dass man dort wieder mehr auf die Exportmärkte schaut, was mit deutlichen Preisrückgängen einhergeht.
<G-vec00301-003-s113><clear_up.deutlichen><en> Lowest possible propeller speeds are not only good for maneuverability, but also allow the use of bigger propellers, which leads to clear increases in the efficiency of drive units.
<G-vec00301-003-s113><clear_up.deutlichen><de> Möglichst geringe Propellerdrehzahlen sind zudem nicht nur der Manövrierbarkeit zuträglich, sondern erlauben auch den Einsatz größerer Propeller, was zu einer deutlichen Erhöhung der Effizienz der Antriebsanlage führt.
<G-vec00301-003-s190><clear_up.eindeutigen><en> Consent shall mean any informed and unambiguous statement of intent by the data subject in the form of a declaration or other clear affirmative act by which the data subject indicates his or her consent to the processing of personal data concerning him or her.
<G-vec00301-003-s190><clear_up.eindeutigen><de> Eine Einwilligung ist jede von der betroffenen Person freiwillig für den bestimmten Fall in informierter Weise und unmissverständlich abgegebene Willensbekundung in Form einer Erklärung oder einer sonstigen eindeutigen bestätigenden Handlung, mit der die betroffene Person zu verstehen gibt, dass sie mit der Verarbeitung der sie betreffenden personenbezogenen Daten einverstanden ist.
<G-vec00301-003-s191><clear_up.eindeutigen><en> Each cartridge housing is individually marked for clear identification.
<G-vec00301-003-s191><clear_up.eindeutigen><de> Jedes Kerzengehäuse ist individuell zur eindeutigen Identifikation gekennzeichnet.
<G-vec00301-003-s192><clear_up.eindeutigen><en> RODRÍGUEZ MARADIAGA: But to say that it was lawful only «in the case of a clear and prolonged tyranny that grievously attacked the fundamental rights of the person and harmed in dangerous fashion the common good of the country».
<G-vec00301-003-s192><clear_up.eindeutigen><de> RODRÍGUEZ MARADIAGA: Aber nur, um herauszustellen, daß diese nur im „Fall der eindeutigen und lang dauernden Gewaltherrschaft, die die Grundrechte der Person schwer verletzt und dem Gemeinwohl des Landes ernsten Schaden zufügt“ legitim ist.
<G-vec00301-003-s193><clear_up.eindeutigen><en> One the one hand this serves for clear traceability of stamped parts, and on the other hand for visual monitoring of the correct machine parameters.
<G-vec00301-003-s193><clear_up.eindeutigen><de> Dies dient zum einen zur eindeutigen Nachverfolgbarkeit der Stanzteile und zum anderen zur optischen Kontrolle der richtigen Maschinenparameter.
<G-vec00301-003-s194><clear_up.eindeutigen><en> The concept comprises an unambiguous gesture that cannot be released accidentally to unlock the interaction. It must be performed consciously and then be confirmed by another clear gesture.
<G-vec00301-003-s194><clear_up.eindeutigen><de> Das Konzept beinhaltet eine eindeutige Geste zum Entsperren der Interaktion, die nicht zufällig ausgelöst werden kann: Sie muss bewusst eingesetzt und mit einer weiteren, eindeutigen Geste bestätigt werden.
<G-vec00301-003-s195><clear_up.eindeutigen><en> This number is also output in the documents to establish a clear reference to your article master.
<G-vec00301-003-s195><clear_up.eindeutigen><de> Diese Nummer wird auch in den Belegen ausgegeben, um einen eindeutigen Bezug zu Ihrem Artikelstamm herstellen zu können.
<G-vec00301-003-s196><clear_up.eindeutigen><en> In order to offer the potential for profiling and also clear guidance in the jungle of available organic produce, the BCS-ÖKO-Garantie assigns its own test seal which goes beyond the EC standards. On the market, this indicates the environmental consistency of all elements right down to the packaging.
<G-vec00301-003-s196><clear_up.eindeutigen><de> Um im "BIO-Angebots-Dschungel" die Möglichkeit zur Profilierung und zugleich zur eindeutigen Orientierung zu bieten, vergibt BCS-ÖKO-Garantie über den EG-Standard hinaus ein eigenes Prüfsiegel, das am Markt weitergehende Konsequenz bis zur Umweltverträglichkeit der Verpackung signalisiert.
<G-vec00301-003-s197><clear_up.eindeutigen><en> You can perfectly ADAPT YOUR SHOVELING STRATEGY and save important time thanks to the clear 1m marker, CONTRASTINGDEPTH SCALE and COLORFUL END SEGMENTS.
<G-vec00301-003-s197><clear_up.eindeutigen><de> Dank der eindeutigen 1 m - Markierung, der KONTRASTREICHEN TIEFENSKALA sowie der FARBIGEN ENDSEGMENTE kannst du deine SCHAUFELSTRATEGIE OPTIMAL ANPASSEN und wichtige Zeit sparen.
<G-vec00301-003-s198><clear_up.eindeutigen><en> If we make significant changes to the way in which we collect, use and/or disclose the personal data you provide to us, we will make you aware of this by providing you with a clear and clearly visible notice on the website.
<G-vec00301-003-s198><clear_up.eindeutigen><de> Sollten wir wesentliche Änderungen bei der Sammlung, der Nutzung und/oder der Weitergabe der uns von Ihnen zur Verfügung gestellten personenbezogenen Daten vornehmen, werden wir Sie durch einen eindeutigen und gut sichtbaren Hinweis auf der Website darauf aufmerksam machen.
<G-vec00301-003-s199><clear_up.eindeutigen><en> To exercise the right to cancel, you must inform us (enter postal address, telephone number and e-mail address here) of your decision to cancel this contract by a clear statement (e.g.
<G-vec00301-003-s199><clear_up.eindeutigen><de> Um Ihr Widerrufsrecht auszuüben, müssen Sie uns (CAMONDAS Schokoladen GmbH, An der Frauenkirche 20, 01067 Dresden, info@camondas.de, Telefon: 0351 49 76 98 43) mittels einer eindeutigen Erklärung (z.
<G-vec00301-003-s200><clear_up.eindeutigen><en> Now you has responded with a clear Statement on your Website on the rumors.
<G-vec00301-003-s200><clear_up.eindeutigen><de> Jetzt hat sie mit einem eindeutigen Statement auf ihrer Website auf die Gerüchte reagiert.
<G-vec00301-003-s201><clear_up.eindeutigen><en> In about half the cases, it is not possible to give a clear reason for the habitual abortions.
<G-vec00301-003-s201><clear_up.eindeutigen><de> In etwa der Hälfte der Fälle ist es nicht möglich, einen eindeutigen Grund für die wiederholten Fehlgeburten zu benennen.
<G-vec00301-003-s202><clear_up.eindeutigen><en> Pipeline operators all over the world are convinced of the clear cost advantages (CAPEX and OPEX).
<G-vec00301-003-s202><clear_up.eindeutigen><de> Die eindeutigen Kostenvorteile (CAPEX und OPEX) haben bereits Rohrbetreiber überall auf der Welt überzeugt.
<G-vec00301-003-s203><clear_up.eindeutigen><en> That means that elections to the European Parliament must become, more clearly than before, contests between clear political alternatives, and between the leaders representing those alternatives.
<G-vec00301-003-s203><clear_up.eindeutigen><de> Dies bedeutet, dass die Wahlen zum Europäischen Parlament noch deutlicher als bisher zu einem Wettstreit zwischen eindeutigen politischen Alternativen werden müssen und somit zwischen den politischen Vertretern dieser Alternativen.
<G-vec00301-003-s204><clear_up.eindeutigen><en> But in this case, I think it is quite clear that autocomplete should be reigned in because there would be no detriment to free speech involved.
<G-vec00301-003-s204><clear_up.eindeutigen><de> In diesem sehr speziellen und recht eindeutigen Fall jedoch finde ich, dass die Autovervollständigung manipuliert werden kann, da hier keine Bedrohung der Meinungsfreiheit vorliegt.
<G-vec00301-003-s205><clear_up.eindeutigen><en> If you cannot say something good, the Bible is clear: keep quiet.
<G-vec00301-003-s205><clear_up.eindeutigen><de> Wenn du nichts Gutes sagen kannst, hat die Bibel einen eindeutigen Rat: Halte deinen Mund.
<G-vec00301-003-s206><clear_up.eindeutigen><en> "Despite the clear and weighty evidence based on reputable scientific facts, large parts of the media, unwitting doctors and alleged “nutritionists” keep spreading incorrect and misleading facts about the animal food industry and archaic and faulty doctrines.
<G-vec00301-003-s206><clear_up.eindeutigen><de> "Trotz der überwältigend eindeutigen Beweislage aufgrund der seriösen wissenschaftlichen Fakten verbreiten große Teile der Presse, unwissende Ärzte und vermeintliche „Ernährungsexperten“ lieber Unwahrheiten und Irreführungen der Tierindustrie und falsche Lehrmeinungen vergangener Zeiten.
<G-vec00301-003-s207><clear_up.eindeutigen><en> Attractively designed 3D floor advertising leads to a clear advantage for the advertised brand over competitive products in the direct vicinity on the shelves.
<G-vec00301-003-s207><clear_up.eindeutigen><de> Attraktiv gestaltete Bodenwerbung wird von den Kunden als angenehme Überraschung beim Einkauf empfunden und führt zu einem eindeutigen Vorteil der zu bewerbenden Marke gegenüber Konkurrenzprodukten, die sich im Warenregal in unmittelbarer Nähe befinden.
<G-vec00301-003-s208><clear_up.eindeutigen><en> The novel booklets and puzzle magazines, as well as the publishing segments children's and youth books, audio and, in particular, LYX were the clear growth and earnings drivers in the last nine months.
<G-vec00301-003-s208><clear_up.eindeutigen><de> Die Verlagssparten Romanhefte und Rätselmagazine, Kinder- und Jugendbuch, Audio und insbesondere LYX gehörten in den vergangenen neun Monaten zu den eindeutigen Wachstums- und Ergebnismotoren innerhalb der Verlagsgruppe.
<G-vec00301-003-s342><clear_up.klaren><en> It offers a clear overview of all sponsors’ contracts, the ability to track easily all contract related activities and to have a communication history with each account.
<G-vec00301-003-s342><clear_up.klaren><de> Es bietet einen klaren Überblick über die Verträge aller Sponsoren, die Möglichkeit, alle vertragsbezogenen Aktivitäten leicht zu verfolgen und mit jedem Konto einen Kommunikationsverlauf zu haben.
<G-vec00301-003-s343><clear_up.klaren><en> Depending on the destination, there are sometimes quite rigid security regulations of public institutions for providers: This ranges from the audit requirement for operators and boatmen on the regular decrease of boats up to clear rules as regards the equipment to be carried.
<G-vec00301-003-s343><clear_up.klaren><de> Abhängig vom Zielgebiet existieren teils recht rigide Sicherheitsmaßgaben öffentlicher Institutionen für die Anbieter: Das reicht von der Prüfungspflicht für Unternehmer und Bootsführer über die regelmäßige Abnahme der Boote bis zu klaren Vorschriften, was die mitzuführende Ausrüstung angeht.
<G-vec00301-003-s344><clear_up.klaren><en> We place a clear focus on action competence and transversal skills for direct use in companies and teach you this in interdisciplinary classes.
<G-vec00301-003-s344><clear_up.klaren><de> Wir legen einen klaren Fokus auf Handlungs- und Querschnittskompetenz für den direkten Einsatz in Unternehmen und vermitteln Ihnen dies in interdisziplinären Lehrveranstaltungen.
<G-vec00301-003-s345><clear_up.klaren><en> The settled communists as well as a wide range of NGOs close to the WSF failed to take a clear stance on the side of Muslims and Dalits against the fascist-like communalist frenzy that saw its preliminary climaxes in the destruction of the destruction of the Babri mosque in Ayodhya in 1992 and in the Gujarat massacre of 2002.
<G-vec00301-003-s345><clear_up.klaren><de> Die etablierten Kommunistische Partei sowie auch die meisten der NGOs, die in einem Naheverhältnis zu dem WSF stehen, versagten im Einnehmen einer klaren Position auf der Seite der Moslems und Dalits gegen die faschistoide kommunalistische Raserei, die ihre vorläufigen Höhepunkte in der Zerstörung der Babri Moschee in Ayodhya 1992 und im Massaker von Gujarat 2002 fanden.
<G-vec00301-003-s346><clear_up.klaren><en> Through a pleasant tour, with clear images and without filters, our real estate agent will walk around the living room, kitchen and all the interiors and exteriors of the property.
<G-vec00301-003-s346><clear_up.klaren><de> Durch eine angenehme Tour, mit klaren Bildern und ohne Filter, wird unser Immobilienmakler durch das Wohnzimmer, die Küche und alle Innen- und Außenbereiche der Immobilie gehen.
<G-vec00301-003-s347><clear_up.klaren><en> We will create together an action plan in order to be clear about what and how you can actually achieve within or outside the organization.
<G-vec00301-003-s347><clear_up.klaren><de> In diesem Workshop erstellen wir gemeinsam einen Aktionsplan, um darüber im Klaren zu sein, wie Sie sich tatsächlich innerhalb oder auch außerhalb der Organisation verwirklichen können.
<G-vec00301-003-s348><clear_up.klaren><en> They help our customers enjoy clear benefits with costs and utilisation.
<G-vec00301-003-s348><clear_up.klaren><de> So verhelfen wir unseren Kunden zu klaren Kosten- und Nutzenvorteilen.
<G-vec00301-003-s349><clear_up.klaren><en> You will know how to increase your project success with a clear project order and a strong interaction with the project manager.
<G-vec00301-003-s349><clear_up.klaren><de> Sie erfahren, wie Sie Ihren Projekterfolg mit einem klaren Projektauftrag und einem starken Zusammenspiel mit der ProjektmanagerIn steigern.
<G-vec00301-003-s350><clear_up.klaren><en> There was never a clear plan or idea of what we were to do.
<G-vec00301-003-s350><clear_up.klaren><de> Es gab niemals einen klaren Plan oder Idee, was wir tun sollten.
<G-vec00301-003-s351><clear_up.klaren><en> We, CERATIZIT Germany GmbH, are responsible for this online offer and, as a teleservice provider, are obliged to inform you at the start of your visit to our online offer, in clear and simple language, about the nature, scope and purpose of the collection and use of personal data, and to do so in a precise, transparent, understandable and easily accessible form.
<G-vec00301-003-s351><clear_up.klaren><de> Wir, CERATIZIT Deutschland GmbH, sind Verantwortlicher für dieses Onlineangebot und haben als Anbieter eines Teledienstes Sie zu Beginn Ihres Besuches auf unserem Onlineangebot über Art, Umfang und Zwecke der Erhebung und Verwendung personenbezogener Daten in präziser, transparenter, verständlicher und leicht zugänglicher Form in einer klaren und einfachen Sprache zu unterrichten.
<G-vec00301-003-s352><clear_up.klaren><en> Needless to say, equally, if not more spectacular is the lake with its clear water and accompanying mountain panorama.
<G-vec00301-003-s352><clear_up.klaren><de> Natürlich ist der See mit seinem klaren Wasser und dem dazugehörigen Bergpanorama mindestens so spektakulär.
<G-vec00301-003-s353><clear_up.klaren><en> At the end it was only possible to enjoy take-offs in full afterburner in the dark clear sky.
<G-vec00301-003-s353><clear_up.klaren><de> Ab einem gewissen Zeitpunkt war es nur noch möglich die Starts mit vollem Nachbrenner im dunklen klaren Nachthimmel zu bestaunen.
<G-vec00301-003-s354><clear_up.klaren><en> Since short-acting insulin is clear and long-acting insulin is cloudy, you can use the following to help you remember the order when drawing insulin up: always start clear and end cloudy.
<G-vec00301-003-s354><clear_up.klaren><de> Da kurzfristig aktives Insulin klar und langfristig aktives trüb ist, kannst du Folgendes verwenden, um dir die Reihenfolge zu merken, wenn du Insulin aufziehst: "Startklar" – starte mit der klaren Flüssigkeit.
<G-vec00301-003-s355><clear_up.klaren><en> According to the BBC, Estonian Prime Minister Taavi Roivas called the verdict “a clear and grave violation of international law”.
<G-vec00301-003-s355><clear_up.klaren><de> Nach Angaben der BBC bezeichnete der estnische Ministerpräsident Taavi Roivas das Urteil als „klaren und schweren Verstoß gegen internationales Recht“.
<G-vec00301-003-s356><clear_up.klaren><en> Compared to the current RTI Strategy 2020, in which some things have fallen by the wayside, the new undertaking presents essential improvements, according to the FWF’s president, as it constitutes a joint approach, also involves the finance ministry, and features a clear division of tasks.
<G-vec00301-003-s356><clear_up.klaren><de> Im Gegensatz zur aktuellen FTI-Strategie 2020, bei der doch einiges auf der Strecke blieb, sieht der FWF-Präsident bei der nunmehr vorgestellten Initiative im gemeinsamen Vorgehen, der Einbeziehung auch des Finanzministeriums sowie der klaren Aufgabenverteilung wesentliche Verbesserungen.
<G-vec00301-003-s357><clear_up.klaren><en> KING KING KING survives short-lived fashion trends thanks to the elegance of its clear shapes.
<G-vec00301-003-s357><clear_up.klaren><de> KING KING Dank der Eleganz seiner klaren Form überdauert KING schnelllebige Modetrends.
<G-vec00301-003-s358><clear_up.klaren><en> "The signing of this contract demonstrates the strong commitment and the clear political will to create an independent global satellite navigation system in Europe," said the Chairman of the DLR Executive Board, Johann-Dietrich Wörner.
<G-vec00301-003-s358><clear_up.klaren><de> "Die Vertragsunterzeichnung verdeutlicht das große Engagement und den klaren politischen Willen zur Schaffung eines eigenständigen globalen Satellitennavigationssystems Europas", erklärt der DLR-Vorstandsvorsitzende Prof. Dr. Johann-Dietrich Wörner.
<G-vec00301-003-s359><clear_up.klaren><en> On a clear day, the shores of Iran from Sky.
<G-vec00301-003-s359><clear_up.klaren><de> An einem klaren Tag können Sie sogar die Grenze zum Iran von Sky aus sehen.
<G-vec00301-003-s360><clear_up.klaren><en> The HOFA PRO course has helped me tie together all the disparate threads of music production knowledge I’ve picked up over the years into a clear and comprehensive formal structure.
<G-vec00301-003-s360><clear_up.klaren><de> Der HOFA PRO Kurs hat mir geholfen, all die unterschiedlichen Wissensstränge der Musikproduktion, die ich im Laufe der Jahre gesammelt habe, zu einer klaren und umfassenden formalen Struktur zu verbinden.
<G-vec00301-003-s399><clear_up.klären><en> While historians in the Weimar Republic worked to clear Germany’s name, others chose their own path.
<G-vec00301-003-s399><clear_up.klären><de> Während Historiker in der Weimarer Republik daran arbeiteten, den Namen Deutschlands zu klären, wählten andere ihren eigenen Weg.
<G-vec00301-003-s400><clear_up.klären><en> I missed being given important back up information that could be explained in English (in less time) to clear up misunderstandings.
<G-vec00301-003-s400><clear_up.klären><de> Leider habe ich wichtige Hintergrundinformationen zum Kursablauf vermisst, die in Englisch (in kürzerer Zeit) hätten erklärt werden können, um Missverständnisse zu klären.
<G-vec00301-003-s401><clear_up.klären><en> And that is my message through this clear channel, who sits in this chair before you.
<G-vec00301-003-s401><clear_up.klären><de> Und das ist die Botschaft durch diesen klären Kanal, der in diesem Stuhl vor euch sitzt.
<G-vec00301-003-s402><clear_up.klären><en> The last day you rise early and clear out your cabin.
<G-vec00301-003-s402><clear_up.klären><de> Am letzten Tag stehen Sie früh auf und klären Ihre Kabine aus.
<G-vec00301-003-s403><clear_up.klären><en> David Marcus, the current Facebook Blockchain chain recently wrote a blog article that sort to defend and clear the air about Libra and complaints that the company has too much control over it.
<G-vec00301-003-s403><clear_up.klären><de> David Marcus, die aktuelle Facebook-Blockchain-Kette, hat kürzlich einen Blog-Artikel geschrieben, der die Luft über die Waage verteidigen und klären soll, und sich darüber beschwert, dass das Unternehmen zu viel Kontrolle darüber hat.
<G-vec00301-003-s404><clear_up.klären><en> The benefits of these courses for you will be to: Get clear on what you want for your health, relationships, money issues, work, other areas or life in general
<G-vec00301-003-s404><clear_up.klären><de> Sie klären für sich, was Sie für Ihre Gesundheit, Ihre Beziehungen, Ihre Arbeit, Ihre Lebensfreude und andere Bereiche Ihres Lebens erreichen wollen.
<G-vec00301-003-s405><clear_up.klären><en> Hope, we are able to clear at least some of them.
<G-vec00301-003-s405><clear_up.klären><de> Hoffe, wir können zumindest einige von ihnen klären.
<G-vec00301-003-s406><clear_up.klären><en> It helps us order our thoughts, clear our feelings, harmonize our body and expand our consciousness.
<G-vec00301-003-s406><clear_up.klären><de> Sie hilft, unsere Gedanken zu ordnen, unsere Gefühle zu klären, den Körper zu harmonisieren und unsere Bewusstheit auszudehnen.
<G-vec00301-003-s407><clear_up.klären><en> EU Commissioners Clear the Enigma: Muslim Immigrants for Muslim Support to Superpower Status Acc. to The Lisbon Treaty.
<G-vec00301-003-s407><clear_up.klären><de> EU Kommissare Klären Das Rätsel: Muslimische Zuwanderer Für Muslimische Stütze Für Supermachtstatus Supermagtsstatus I.h.t.
<G-vec00301-003-s408><clear_up.klären><en> AntiSpy is designed to clear the history of your activities on a PC.
<G-vec00301-003-s408><clear_up.klären><de> Antispion wird entworfen, um die Geschichte von Ihren Tätigkeiten auf einem PC zu klären.
<G-vec00301-003-s409><clear_up.klären><en> As far as to us this is known, we clear up the users about that.
<G-vec00301-003-s409><clear_up.klären><de> Soweit uns dies bekannt ist, klären wir die Nutzer darüber auf.
<G-vec00301-003-s410><clear_up.klären><en> Not only is it essential to clear our energy field of undesirable energy, but it's essential to replace that cleared energy with something of a higher vibration, otherwise, we'll attract the same old patterns again.
<G-vec00301-003-s410><clear_up.klären><de> Nicht nur ist es essentiell unser Enrgiefeld von unerwünschter Energie zu klären, jedoch ist es auch essentiell die geklärete Enerie mit etwas mit einer höheren Schwingung zu ersetzen, ansonsten werden dieselben alten Muster wieder angezogen.
<G-vec00301-003-s411><clear_up.klären><en> As each of you works to clear yourself of all that does not match the highest frequency so to is the collective.
<G-vec00301-003-s411><clear_up.klären><de> Indem jede/r von euch daran arbeitet, sich von allem zu klären, was nicht der höchsten Frequenz entspricht, tut es auch das Kollektiv.
<G-vec00301-003-s412><clear_up.klären><en> If these methods don't help your acne, there are still other treatments, including lasers, light treatments, microdermabrasion, or chemical peels to help clear your skin.
<G-vec00301-003-s412><clear_up.klären><de> Falls diese Methoden nicht gegen deine Akne helfen, gibt es noch andere Behandlungen (einschließlich Laser, Lichtbehandlungen, Mikrodermabrasion oder chemischer Peelings), die dabei helfen, deine Haut zu klären.
<G-vec00301-003-s413><clear_up.klären><en> If you have already decided your trip or you are thinking about it, we will clear up all your doubts.
<G-vec00301-003-s413><clear_up.klären><de> Wenn Sie Ihre Reise bereits entschieden haben oder darüber nachdenken, klären wir alle Ihre Zweifel auf.
<G-vec00301-003-s414><clear_up.klären><en> The picture for third quarter GDP growth in the US is starting to clear up.
<G-vec00301-003-s414><clear_up.klären><de> Das Bild für das BIP-Wachstum im dritten Quartal in den USA beginnt sich auch zu klären.
<G-vec00301-003-s415><clear_up.klären><en> However, not all the stories are true and there’s a lot of hot air being circulated, so here we clear up some of the myths…
<G-vec00301-003-s415><clear_up.klären><de> Allerdings sind nicht alle Geschichten wahr und es gibt eine Menge heiße Luft, darum klären wir hier einige der Mythen auf...
<G-vec00301-003-s416><clear_up.klären><en> There is only one question left to clear up, and that is the ninth planet’s name.
<G-vec00301-003-s416><clear_up.klären><de> Bleibt nur noch eine Frage zu klären, und zwar die des Namens.
<G-vec00301-003-s417><clear_up.klären><en> Obviously we still need to clear up that whole issue of new traffic regulations and hovering signs in the stratosphere.
<G-vec00301-003-s417><clear_up.klären><de> Zu klären wäre dann noch die Sache mit der Straßenverkehrsordnung und den schwebenden Verkehrsschildern in der Stratosphäre.
<G-vec00301-003-s475><clear_up.löschen><en> To clear the New Shortcut Key input field, press any of the control keys, Ctrl, Alt, or Shift.
<G-vec00301-003-s475><clear_up.löschen><de> Um die Eingabe im Feld "Tastaturkürzel drücken" zu löschen, drücken Sie eine der Tasten Strg, Alt oder Umschalt.
<G-vec00301-003-s476><clear_up.löschen><en> Expand Settings and select the check box next to Clear update cache.
<G-vec00301-003-s476><clear_up.löschen><de> Erweitern Sie Einstellungen und aktivieren Sie das Kontrollkästchen neben Update-Cache löschen.
<G-vec00301-003-s477><clear_up.löschen><en> However, you can clear the results in the Output Pane.
<G-vec00301-003-s477><clear_up.löschen><de> Sie können jedoch die Ergebnisse im Ausgabebereich löschen.
<G-vec00301-003-s478><clear_up.löschen><en> This is an amazing action game.One man army in war as a frontline commando...You are appointed as an sniper shooter, your mission is to clear the small enemy unit that will try to protect the city.You are equipped with a modern sniper...
<G-vec00301-003-s478><clear_up.löschen><de> Das ist ein erstaunliches Action-Spiel.Ein Mann Armee im Krieg als Frontline-Kommando...Sie werden als Scharfschützen-Shooter ernannt, Ihre Mission ist es, die kleine feindliche Einheit zu löschen, die versuchen wird, die Stadt zu schützen.Sie sind mit einer...
<G-vec00301-003-s479><clear_up.löschen><en> Clear your Internet tracks, sweep away temporary files you may have downloaded, and hide which programs you have recently used.
<G-vec00301-003-s479><clear_up.löschen><de> Löschen Sie Ihre Internet-Spuren, wegfegen temporäre Dateien, die Sie heruntergeladen haben, und verstecken sich, welche Programme Sie in letzter Zeit verwendet haben.
<G-vec00301-003-s480><clear_up.löschen><en> Solution 3: Clear the system cache Press the Guide button on your controller. Go to Settings and select System Settings.
<G-vec00301-003-s480><clear_up.löschen><de> Löschen des Systemcaches Drücken Sie auf dem Controller die Guide-Taste, wechseln Sie zu den "Einstellungen", und wählen Sie "Systemeinstellungen" aus.
<G-vec00301-003-s481><clear_up.löschen><en> Tap "Privacy" and then "Clear personal data".
<G-vec00301-003-s481><clear_up.löschen><de> Tippen Sie auf "Datenschutz" und dann auf "Persönliche Daten löschen".
<G-vec00301-003-s482><clear_up.löschen><en> To clear your history and cookies, go to Settings > Safari, and tap Clear History and Website Data.
<G-vec00301-003-s482><clear_up.löschen><de> Um den Verlauf und Cookies zu löschen, gehen Sie zu "Einstellungen" > "Safari", und tippen Sie auf "Verlauf und Websitedaten löschen".
<G-vec00301-003-s484><clear_up.löschen><en> In order to clear the data being stored by the border concepts GmbH, you can turn to the border concepts GmbH (dataprivacy(at)borderconcepts.biz) at any time.
<G-vec00301-003-s484><clear_up.löschen><de> Zum Löschen der von der border concepts GmbH gespeicherten Daten können Sie sich jederzeit an die border concepts GmbH wenden (datenschutz(at)borderconcepts.biz).
<G-vec00301-003-s485><clear_up.löschen><en> You can also clear formatting.
<G-vec00301-003-s485><clear_up.löschen><de> Sie können auch die Formatierung löschen.
<G-vec00301-003-s486><clear_up.löschen><en> To clear the operational indicators, press ON SCREEN twice.
<G-vec00301-003-s486><clear_up.löschen><de> Um die Betriebsanzeigen zu löschen, drücken Sie zweimal auf ON SCREEN.
<G-vec00301-003-s487><clear_up.löschen><en> First of all, you need to clear the file from cuts and possible rust.
<G-vec00301-003-s487><clear_up.löschen><de> Zunächst einmal müssen Sie die Datei aus Kürzungen und möglichem Rost löschen.
<G-vec00301-003-s488><clear_up.löschen><en> If you want to clear the text you entered, click the button [Clear].
<G-vec00301-003-s488><clear_up.löschen><de> Wollen Sie den eingegebenen Text wieder löschen, klicken Sie auf die Schaltfläche [Löschen].
<G-vec00301-003-s490><clear_up.löschen><en> Copy the rule, "Clear categories on mail."
<G-vec00301-003-s490><clear_up.löschen><de> Kopiere die Regel "Kategorie aus Mail löschen".
<G-vec00301-003-s491><clear_up.löschen><en> Clear passwords: Deletes any previously stored user names or passwords.
<G-vec00301-003-s491><clear_up.löschen><de> Kennwörter löschen: Löscht gespeicherte Kennwörter.
<G-vec00301-003-s492><clear_up.löschen><en> Match colors vertically to clear them.
<G-vec00301-003-s492><clear_up.löschen><de> Spiel Farben vertikal um sie zu löschen.
<G-vec00301-003-s493><clear_up.löschen><en> Here you will find options related to displaying recent searches or if you care to clear all of them when exiting the browser.
<G-vec00301-003-s493><clear_up.löschen><de> Hier finden Sie Optionen, um die Anzeige der aktuellen Suchanfragen zu ändern oder um alle zu löschen, wenn Sie den Browser schließen.
