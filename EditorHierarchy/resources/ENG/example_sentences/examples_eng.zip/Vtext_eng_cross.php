<G-vec00280-002-s057><cross.durchqueren><en> In the mean while scouts having been sent in all directions, he examines by what most convenient path he might cross the valley.
<G-vec00280-002-s057><cross.durchqueren><de> (8) In der Zwischenzeit sandte er Späher nach allen Richtungen aus, um auszukundschaften, wo man das Tal am bequemsten durchqueren könne.
<G-vec00280-002-s058><cross.durchqueren><en> Also you will cross the Silica Valley which features a very special and beautiful material – the Silica glass, also known as ‘Libyan glass’ or ‘desert emeralds’.
<G-vec00280-002-s058><cross.durchqueren><de> Außerdem durchqueren Sie das Silica-Glas-Feld, wo man ein ganz besonderes Material finden kann: das Silica-Glas, auch bekannt als ‚Libysches Wüstenglas‘.
<G-vec00280-002-s059><cross.durchqueren><en> On his bike tour through South Africa and suddenly separated from his two companions, 25-year-old Anselm faces a difficult decision: either return home or cross the Kalahari Desert alone.
<G-vec00280-002-s059><cross.durchqueren><de> Auf seiner Radreise durch Südafrika und plötzlich getrennt von seinen zwei Weggefährten, steht der 25-jährige Anselm vor einer schweren Entscheidung: ebenfalls nach Hause zurückkehren, oder alleine die Kalahari-Wüste durchqueren.
<G-vec00280-002-s060><cross.durchqueren><en> Then we cross an area vegetated with pines, from there the path becomes much more stony.
<G-vec00280-002-s060><cross.durchqueren><de> Dann durchqueren wir ein Latschengebiet, ab hier wird der Pfad deutlich steiniger.
<G-vec00280-002-s061><cross.durchqueren><en> Using boats, aristocrats could cross the city quickly and discreetly.
<G-vec00280-002-s061><cross.durchqueren><de> Aristokraten konnten die Stadt schnell und diskret per Boot durchqueren.
<G-vec00280-002-s062><cross.durchqueren><en> In this tour you will cross the northern areas of Paris to reach the foot of the Montmartre Hill.
<G-vec00280-002-s062><cross.durchqueren><de> Wir durchqueren die nördlichen Viertel von Paris, um den Fuß des Montmartre zu erreichen.
<G-vec00280-002-s063><cross.durchqueren><en> The black broken lines that cross the room give it a certain depth and color.
<G-vec00280-002-s063><cross.durchqueren><de> Die schwarzen unterbrochenen Linien, die den Raum durchqueren, geben ihm eine gewisse Tiefe und Farbe.
<G-vec00280-002-s064><cross.durchqueren><en> You should cross the pine wood in direction of south-east always going uphill.
<G-vec00280-002-s064><cross.durchqueren><de> Sie sollten den Kiefernwald in südöstlicher Richtung durchqueren und dabei immer 'bergauf' gehen.
<G-vec00280-002-s065><cross.durchqueren><en> On the right, you pass by a small rocky pinnacle with a cross, and you cross the upper part of Val Bona until you reach - with a final section between rocks and steps - the rocky terrace where the small Rifugio Torre di Pisa is located (2671 m).
<G-vec00280-002-s065><cross.durchqueren><de> Der Weg führt rechts an einer kleinen Felsspitze mit Gipfelkreuz vorbei, und Sie durchqueren den oberen Teil des Val Bona, um auf einem letzten Teilstück mit Felsen und Stufen die Felsenterrasse zu erreichen, auf der sich die kleine Hütte Torre di Pisa (2671 m) befindet.
<G-vec00280-002-s066><cross.durchqueren><en> We cross the village until the arrows divert us to the right, towards the train station.
<G-vec00280-002-s066><cross.durchqueren><de> Wir durchqueren das Dorf, bis die Pfeile uns nach rechts zum Bahnhof führen.
<G-vec00280-002-s067><cross.durchqueren><en> The yellow leaf Sunday [Sonntag], attached to the ceiling unfolds its centre through simple bends, which cross the middle horizontally, vertically, and diagonally.
<G-vec00280-002-s067><cross.durchqueren><de> Das gelbe Blatt Sonntag, das oben unter der Decke hängt, entfaltet ein Zentrum durch einfache Knicke, die horizontal, vertikal und diagonal die Mitte durchqueren.
<G-vec00280-002-s068><cross.durchqueren><en> During our adventurous drive up to the volcano, partially off-road, over cold lava streams we will cross hundreds of years old forests and make several stops to visit some of the most beautiful sites on Mount Etna by foot, accompanied by our English-speaking guide at all time.
<G-vec00280-002-s068><cross.durchqueren><de> Während wir den Vulkan hinauffahren, teilweise Off-Road, über die erkalteten Lavaströme der vergangenen Jahre, durchqueren wir auch Jahrhunderte alte Wälder und halten an einigen der schönsten Orte des Ätna, um diese zu Fuß in Begleitung eines deutschsprachigen Guides zu besichtigen.
<G-vec00280-002-s069><cross.durchqueren><en> As I noted above, Occupy emerges out of the flow of images of revolt (and languages of revolt) which cross our screens.
<G-vec00280-002-s069><cross.durchqueren><de> Wie bereits festgestellt, geht Occupy aus dem Strom der Bilder der Revolte (und der Sprachen der Revolte) hervor, die unsere Bildschirme durchqueren.
<G-vec00280-002-s070><cross.durchqueren><en> It can take up to an entire day per time zone that you cross to feel back to normal.
<G-vec00280-002-s070><cross.durchqueren><de> Pro Zeitzone, die wir durchqueren, kann es einen ganzen Tag dauern, bis wir uns wieder erholt fühlen.
<G-vec00280-002-s071><cross.durchqueren><en> We cross colorful quinoa fields painted in purples, yellows and reds, alternating with endemic species of flora and wildlife, indigenous settlements and the remains of ancient cultures.
<G-vec00280-002-s071><cross.durchqueren><de> Sie durchqueren farbenfrohe Quinoafelder in Lila-, Gelb- und Rottönen, die sich mit weiteren einheimischen Spezies der Pflanzen- und Tierwelt, indigenen Siedlungen und Relikten antiker Kultur abwechseln.
<G-vec00280-002-s072><cross.durchqueren><en> Pedestrians who cross the light-flooded passage experience their way as an interactive staging.
<G-vec00280-002-s072><cross.durchqueren><de> Passanten, die die lichtdurchflutete Passage durchqueren erleben ihren Weg als interaktive Inszenierung.
<G-vec00280-002-s073><cross.durchqueren><en> I had to cross a few mountains and valleys before I asked for a place to stay in a small town.
<G-vec00280-002-s073><cross.durchqueren><de> Einige Berge und Täler waren zu durchqueren bis ich abends in einem Dorf nach einem Schlafplatz fragte.
<G-vec00280-002-s074><cross.durchqueren><en> 4. There is a river you must cross but it is used by crocodiles, and you
<G-vec00280-002-s074><cross.durchqueren><de> 9 Frage Nummer 4: Sie müssen einen Fluss durchqueren, wissen aber, dass er von Krokodilen bewohnt wird.
<G-vec00280-002-s075><cross.durchqueren><en> The island is easy to visit by car: you can drive around the whole island in 2 hours and cross it from east to west in only 20 minutes.
<G-vec00280-002-s075><cross.durchqueren><de> Die Insel ist leicht mit dem Auto zu besichtigen: man kann die ganze Insel in 2 Stunden umrunden und in nur 20 Minuten von Ost nach West durchqueren.
<G-vec00280-002-s133><cross.kreuzen><en> Lines can cross each other except at black dots.
<G-vec00280-002-s133><cross.kreuzen><de> Linien können einander kreuzen außer an schwarzen Punkten.
<G-vec00280-002-s134><cross.kreuzen><en> To cross a long-haired breed with a dairy is stupid, only if the litter is slaughtered.
<G-vec00280-002-s134><cross.kreuzen><de> Eine langhaarige Rasse mit einer Molkerei zu kreuzen, ist nur dumm, wenn der Wurf geschlachtet wird.
<G-vec00280-002-s135><cross.kreuzen><en> On Fifth Avenue in New York, where the paths of successful urbanites and sophisticated jetsetters cross, we operate the Wempe Rolex Boutique inside the impressive Rolex Building.
<G-vec00280-002-s135><cross.kreuzen><de> An New Yorks Fifth Avenue, wo sich die Wege erfolgreicher Metropoliten und mondäner Weltenbummler kreuzen, führen wir die Rolex Boutique Wempe direkt im beeindruckenden Rolex Building.
<G-vec00280-002-s136><cross.kreuzen><en> Your connections must not cross.
<G-vec00280-002-s136><cross.kreuzen><de> Ihre Verbindungen müssen nicht kreuzen.
<G-vec00280-002-s137><cross.kreuzen><en> The timeline is an illusion but for just a brief moment when those timelines cross, the illusion is gone.
<G-vec00280-002-s137><cross.kreuzen><de> Die Zeitlinie ist eine Illusion, aber für einen kurzen Augenblick, wenn sich diese Zeitlinien kreuzen, ist die Illusion aufgehoben.
<G-vec00280-002-s138><cross.kreuzen><en> They went on to cross this with Power Sativa, a hybrid with Early Sativa and Power Haze XL as parents.
<G-vec00280-002-s138><cross.kreuzen><de> Sie fuhren damit fort, diese mit Power Sativa zu kreuzen, einem Hybriden mit Early Sativa und Power Haze XL als Eltern.
<G-vec00280-002-s139><cross.kreuzen><en> Baboons constantly cross one’s path.
<G-vec00280-002-s139><cross.kreuzen><de> Immer wieder kreuzen Paviane den Weg.
<G-vec00280-002-s140><cross.kreuzen><en> In addition to the steep slopes, few marked trails cross only short sections of the reserve.
<G-vec00280-002-s140><cross.kreuzen><de> Neben den steilen Hängen kreuzen wenige markierte Wanderwege nur sehr kleine Teile des Reservats.
<G-vec00280-002-s141><cross.kreuzen><en> Here you have to cross the main road to reach the fortress of Antimachia.
<G-vec00280-002-s141><cross.kreuzen><de> Hier musst du die Hauptstraße kreuzen, um zur Festung von Antimachia zu gelangen.
<G-vec00280-002-s142><cross.kreuzen><en> Animals like sloths, monkeys, toucans, crocodiles, Jesus Christ Lizards, and turtles might cross your way, including seeing the colorful world of tropical birds.
<G-vec00280-002-s142><cross.kreuzen><de> Tiere wie Faultiere, Affen, Tukane, Krokodile, Eidechsen und Schildkröten können Ihren Weg kreuzen und sogar die bunte Welt der tropischen Vögel sehen.
<G-vec00280-002-s143><cross.kreuzen><en> Remove all dead branches, together with those who cross each other, from spring to summer.
<G-vec00280-002-s143><cross.kreuzen><de> Entfernen Sie alle toten Ästen, zusammen mit denen, die sich kreuzen, vom Frühling zum Sommer.
<G-vec00280-002-s144><cross.kreuzen><en> It is working like this: the weft and warp are overlapping, and the warp and weft yarn with the same size, the wire along the long, the net width of weft are parallel to the net, the warp and weft wire cross, one at the top at the bottom, at an Angle of 90 °.
<G-vec00280-002-s144><cross.kreuzen><de> Es funktioniert so: Der Schuss und die Kette überlappen sich, und der Schuss und der Schussfaden mit der gleichen Größe, der Draht entlang der Länge, die Nettobreite des Schussfadens sind parallel zum Netz, der Schuss und die Kette kreuzen sich oben unten im Winkel von 90 °.
<G-vec00280-002-s145><cross.kreuzen><en> You are about to cross timelines with yourself and we tell you, that can be exciting for some.
<G-vec00280-002-s145><cross.kreuzen><de> Ihr seid dabei, die Zeitlinien mit euch selbst zu kreuzen und wir sagen euch, das kann für einige ganz schön aufregend sein.
<G-vec00280-002-s146><cross.kreuzen><en> The first manufacturing activity, at the time located on the ground floor of the family house, was the production of PVC cross spacers of different dimensions for the installation of tiles.
<G-vec00280-002-s146><cross.kreuzen><de> Die erste Geschäftstätigkeit, damals noch im Erdgeschoss des Familienhauses, war die Produktion von PVC Kreuzen zur Verlegung von Fliesen verschiedener Größen.
<G-vec00280-002-s147><cross.kreuzen><en> The rope used to cross the creek breaks, sending Leslie falling to her death.
<G-vec00280-002-s147><cross.kreuzen><de> Das Seil, das verwendet wird, um die Nebenflussbrüche zu kreuzen, sendet Leslie, das zu ihrem Tod fällt.
<G-vec00280-002-s148><cross.kreuzen><en> When allocating rooms, we take care that the paths of different groups do not cross if possible.
<G-vec00280-002-s148><cross.kreuzen><de> Bei der Zimmerverteilung achten wir darauf, dass die Wege unterschiedlicher Gruppen sich möglichst nicht kreuzen.
<G-vec00280-002-s149><cross.kreuzen><en> Stones, steep ascents, upended tree trunks which cross the image diagonally – a number of hurdles must be overcome on this path.
<G-vec00280-002-s149><cross.kreuzen><de> Steine, steile Anstiege, gestürzte Baumstämme, die als Diagonale den Bildraum kreuzen – manche Hindernisse gilt es auf diesem Weg zu überwinden.
<G-vec00280-002-s150><cross.kreuzen><en> Each cell must be visited exactly once; lines cannot cross.
<G-vec00280-002-s150><cross.kreuzen><de> Jedes Feld muss genau einmal besucht werden; Pfade dürfen sich nicht kreuzen.
<G-vec00280-002-s151><cross.kreuzen><en> Berlin is a place where gastronomic traditions from around the world cross.
<G-vec00280-002-s151><cross.kreuzen><de> Berlin ist ein typischer Ort, an dem sich Esskulturen aus aller Welt kreuzen.
<G-vec00280-002-s361><cross.überqueren><en> The simulation is so realistic that people stick to the rules of the road, watch out for traffic, and only cross the street at pedestrian crossings.
<G-vec00280-002-s361><cross.überqueren><de> Die Simulation ist dabei so realistisch, dass man sich an die Strassenregeln hält, auf den Verkehr achtet und die Straße nur bei Fussgängerstreifen überquert.
<G-vec00280-002-s362><cross.überqueren><en> We cross the railway tracks and turn left.
<G-vec00280-002-s362><cross.überqueren><de> Nachdem wir die Bahnlinie überquert haben, biegen wir gleich danach links ab.
<G-vec00280-002-s363><cross.überqueren><en> From there, he will cross the Black Sea to Istanbul and then sail on towards the Dardanelles and the former Troy.
<G-vec00280-002-s363><cross.überqueren><de> Von dort aus wird das Schwarze Meer überquert, nach Istanbul und weiter zum Mittelmeer Richtung Dardanellen und dem einstigen Troja gesegelt.
<G-vec00280-002-s364><cross.überqueren><en> Why Did The Chicken Cross The Road
<G-vec00280-002-s364><cross.überqueren><de> Ein Huhn überquert die Straße.
<G-vec00280-002-s365><cross.überqueren><en> Either park there and cross the motorway bridge to follow the trail on the northern side of the river Inn.
<G-vec00280-002-s365><cross.überqueren><de> In Haiming folgt man der Beschilderung "Outdoorzentrum" und überquert die Innbrücke zum Weiler "Magerbach".
<G-vec00280-002-s366><cross.überqueren><en> After the waterfall, when you reach the "Fields of An'she", cross the river and go inside the cave, there is Griffe-hirsute.
<G-vec00280-002-s366><cross.überqueren><de> Nach dem Wasserfeld, wenn ihr "Die Felder von An'she" erreicht, überquert den Fluss und geht in die Höhle, darin befindet sich Borstenschlund.
<G-vec00280-002-s367><cross.überqueren><en> At the end of the road, you cross a bridge over the Fosso Cervia and bear left onto another dirt road and follow the canal.
<G-vec00280-002-s367><cross.überqueren><de> Am Ende dieser Straße überquert man die Brücke über den Fosso Cervia, biegt links ab und wandert weiterhin auf einer Schotterstraße dem Kanal entlang.
<G-vec00280-002-s368><cross.überqueren><en> Then you cross Rainbow Bridge together. – Author unknown
<G-vec00280-002-s368><cross.überqueren><de> Dann überquert Ihr gemeinsam die Regenbogen-Brücke...
<G-vec00280-002-s369><cross.überqueren><en> The path along the Plaza de Obradoiro, descend by the Carballeira de San Lourenzo and cross the municipalities of Ames, Negreira and Mazaricos.
<G-vec00280-002-s369><cross.überqueren><de> Der Weg geht von der Plaza del Obradoiro aus über den Eichenhain von San Lourenzo und überquert die Gemeinden Ames, Negreira und Mazaricos.
<G-vec00280-002-s370><cross.überqueren><en> For example, in the Formula 1 section, you can bet when exactly will the winner cross the finish line.
<G-vec00280-002-s370><cross.überqueren><de> Bei der Formel 1 kann beispielsweise getippt werden, in welcher Zehntelsekunde der Sieger die Ziellinie überquert.
<G-vec00280-002-s371><cross.überqueren><en> Perhaps there are some snow fields to cross, but generally the climb is easy.
<G-vec00280-002-s371><cross.überqueren><de> Möglicherweise müssen einige Schneefelder überquert werden, aber Allgemein ist der Aufstieg einfach.
<G-vec00280-002-s372><cross.überqueren><en> Turn right into the Bodenegg Race Track (661), cross Venter Ache brook and return to Zwieselstein and Sölden. Getting There
<G-vec00280-002-s372><cross.überqueren><de> Dort biegt man rechts auf die Rennstrecke Bodenegg (661) ab, überquert die Venter Ache und kommt über Zwieselstein erneut zurück nach Sölden.
<G-vec00280-002-s374><cross.überqueren><en> Then you cross Rainbow Bridge together… Remember…….
<G-vec00280-002-s374><cross.überqueren><de> DANN überquert ihr die Regenbogen-Brücke gemeinsam.
<G-vec00280-002-s375><cross.überqueren><en> Even if a part of us were to cross it, everyone else would gradually begin to squeeze through this barrier following the thread of our connection.
<G-vec00280-002-s375><cross.überqueren><de> Selbst wenn nur ein Teil von uns diese Grenze überquert, fangen alle anderen an, über unseren Verbindungsfaden allmählich durch diese Schranke durchzusickern.
<G-vec00280-002-s376><cross.überqueren><en> At the first crossroad turn left and cross the Val Casies Valley stream to reach the hamlet of Wiesen (Hotel Tyrol, refreshment stop).
<G-vec00280-002-s376><cross.überqueren><de> An der ersten Kreuzung biegt man links ab und überquert den Talbach, um zum Weiler Wiesen zu gelangen.
<G-vec00280-002-s377><cross.überqueren><en> First you cross the drain of the waterfall over a small pedestrian bridge.
<G-vec00280-002-s377><cross.überqueren><de> Als erstes überquert man den Abfluss vom Wasserfall über eine kleine Fußgängerbrücke.
<G-vec00280-002-s378><cross.überqueren><en> Without noticing it, you can cross the state border with the U1 underground from Langenhorn.
<G-vec00280-002-s378><cross.überqueren><de> Ohne es zu bemerken, überquert man mit der U-Bahn U1 von Langenhorn kommend die Landesgrenze.
<G-vec00280-002-s379><cross.überqueren><en> The trail suddenly changes direction and shortly after you’ll reach a beautiful glade that you must cross pointing to the visible trail on the other side.
<G-vec00280-002-s379><cross.überqueren><de> Der Weg ändert plötzlich seine Richtung und erreicht dann schnell eine schöne Lichtung, die auf dem gut sichtbaren Pfad überquert werden muss.
<G-vec00280-002-s380><cross.überschreiten><en> Ketone bodies cross the blood brain barrier very readily.
<G-vec00280-002-s380><cross.überschreiten><de> Ketonkörper überschreiten die Blut-Gehirn-Schranke sehr schnell und leicht.
<G-vec00280-002-s381><cross.überschreiten><en> Dare to cross the limits of beauty.
<G-vec00280-002-s381><cross.überschreiten><de> Wagen Sie es die Grenzen der Schönheit zu überschreiten.
<G-vec00280-002-s382><cross.überschreiten><en> We can affirm that despondency will not cross the threshold of Our Abode, for joy lives there.
<G-vec00280-002-s382><cross.überschreiten><de> Wir können bestätigen, daß Verzagtheit die Schwelle Unserer Wohnstatt nicht überschreiten wird, denn dort lebt die Freude.
<G-vec00280-002-s383><cross.überschreiten><en> Flashlights from China, cars from Germany and coffee from Guatemala – whenever a product has to cross a border and arrive exactly where it is needed, logistics operations managers are at work.
<G-vec00280-002-s383><cross.überschreiten><de> Taschenlampen aus China, Autos aus Deutschland und Kaffee aus Guatemala – wenn ein Produkt eine Grenze überschreiten muss und genau dort ankommt, wo es benötigt wird, sind Speditionskaufleute am Werk.
<G-vec00280-002-s384><cross.überschreiten><en> We deliberately cross boundaries, both in our heads and in our organisation.
<G-vec00280-002-s384><cross.überschreiten><de> Wir überschreiten bewusst übliche Grenzen - in unseren Köpfen und in unserer Organisation.
<G-vec00280-002-s385><cross.überschreiten><en> In the course of the night and the following day, more than 10.000 refugees cross the Austrian border.
<G-vec00280-002-s385><cross.überschreiten><de> Im Laufe der Nacht und am darauf folgenden Tag überschreiten mehr als 10.000 Flüchtlinge die österreichische Grenze.
<G-vec00280-002-s386><cross.überschreiten><en> Hister required, then, of the Lygians a promise not to cross the boundary; to this they not only agreed, but gave hostages, among whom were the wife and daughter of their leader.
<G-vec00280-002-s386><cross.überschreiten><de> Hister verlangte nun von den Lygiern das Versprechen, die Grenze nicht zu überschreiten; diese verpflichteten sich nicht nur hierzu, sondern stellten auch Geiseln, unter denen sich die Gemahlin und die Tochter ihres Fürsten befanden.
<G-vec00280-002-s387><cross.überschreiten><en> These are red lines we cannot cross.
<G-vec00280-002-s387><cross.überschreiten><de> Dies sind rote Linien, die wir nicht überschreiten können.
<G-vec00280-002-s388><cross.überschreiten><en> Occasionally they even cross the frontiers of Afghanistan or Pakistan on their migrations.
<G-vec00280-002-s388><cross.überschreiten><de> Gelegentlich überschreiten sie bei ihren Wanderungen sogar die Grenzen nach Afghanistan oder Pakistan.
<G-vec00280-002-s389><cross.überschreiten><en> Seek not, then, to cross this Threshold until thou dost feel thyself entirely free from fear and ready for the highest responsibility.
<G-vec00280-002-s389><cross.überschreiten><de> Versuche nicht früher diese Schwelle zu überschreiten, bis du ganz frei von Furcht und bereit zu höchster Verantwortlichkeit dich fühlst.
<G-vec00280-002-s390><cross.überschreiten><en> Death does not as such appear in a picture, nor does a picture die; thus the application of photography make it possible to cross such boundaries.
<G-vec00280-002-s390><cross.überschreiten><de> Weder erscheint der Tod im Bild, noch ist das Bild dem Tode geweiht; Verwendungsformen der Fotografie ermöglichen es, solche Grenzziehungen zu überschreiten.
<G-vec00280-002-s391><cross.überschreiten><en> The Italians cross the border in Acquabona.
<G-vec00280-002-s391><cross.überschreiten><de> Die Italiener überschreiten die Grenze bei Acquabona.
<G-vec00280-002-s392><cross.überschreiten><en> Do not be afraid to cross the threshold of his dwelling, to speak with him face to face, as friends speak to each other (cf.
<G-vec00280-002-s392><cross.überschreiten><de> Habt keine Angst, die Schwelle seines Hauses zu überschreiten, mit ihm von Angesicht zu Angesicht zu reden, wie man sich mit einem Freund unterhält (vgl.
<G-vec00280-002-s393><cross.überschreiten><en> We only have discovered just recently what we are able to do as musicians, which barriers we may cross.
<G-vec00280-002-s393><cross.überschreiten><de> Wir haben eben erst entdeckt, wozu wir als Musiker in der Lage sind, welche Barrieren wir überschreiten können.
<G-vec00280-002-s394><cross.überschreiten><en> The Bride will cross a rustic bridge on the way to the beach area where she will meet up with her Groom and start a new life together.
<G-vec00280-002-s394><cross.überschreiten><de> Die Braut wird eine rustikale Brücke am Weg zum Strand überschreiten, wo sie sich mit ihrem Bräutigam treffen und ein neues Leben zu zweit beginnen wird.
<G-vec00280-002-s395><cross.überschreiten><en> A small group of Republicans were willing to cross party lines to rebuke Trump over his support for a conflict the United Nations has declared a humanitarian disaster, which has killed tens of thousands of civilians and left half the population of Yemen on the brink of starvation.
<G-vec00280-002-s395><cross.überschreiten><de> Eine kleine Gruppe von Republikanern war bereit, die eigenen Parteigrenzen zu überschreiten, um Donald Trump, der ebenfalls der Republikanischen Partei angehört, wegen seiner Unterstützung für einen Konflikt zu tadeln, den die Vereinten Nationen zu einer humanitären Katastrophe erklärt haben, da er Zehntausende von Zivilisten getötet und die Hälfte der Bevölkerung im Jemen am Rande des Hungers zurückgelassen hat.
<G-vec00280-002-s396><cross.überschreiten><en> It’s important to know that Chilean and Bolivian tour operators aren’t allowed to cross the border, so every border crossing comes with a new vehicle and driver.
<G-vec00280-002-s396><cross.überschreiten><de> Es ist wichtig zu wissen, dass die chilenischen und bolivianischen Tourenanbieter die Landesgrenze nicht überschreiten dürfen - jeder Grenzübergang hat somit auch einen Fahrzeug- und Fahrerwechsel zur Folge.
<G-vec00280-002-s397><cross.überschreiten><en> You cross the border between the region Département Champagne Ardenne and Bourgogne.
<G-vec00280-002-s397><cross.überschreiten><de> Wir überschreiten die Départementgrenze und die Grenze zwischen der Regionen Champagne-Ardenne und Bourgogne.
<G-vec00280-002-s398><cross.überschreiten><en> This explains why the nodal axis is so strongly associated with significant meetings with people who may challenge us, appear to thwart us, or who function as messengers, guides or teachers, helping us, and sometimes forcing us, to cross thresholds which would otherwise never occur to us, or which we are afraid to cross without some kind of help, guidance or encouragement.
<G-vec00280-002-s398><cross.überschreiten><de> Das erklärt, warum die Mondknotenachse so oft mit wichtigen Begegnungen mit Menschen assoziiert wird, die uns vielleicht herausfordern, uns scheinbar behindern oder für uns als Botschafter, Führer oder Lehrer fungieren; als solche helfen sie uns und zwingen uns manchmal sogar, Schwellen zu überschreiten, von denen wir uns sonst fernhalten würden oder die wir ohne Hilfe, Anleitung oder Ermutigung nicht zu überschreiten wagten.
<G-vec00882-002-s304><cross.überqueren><en> Cross the impressive Stoney Creek Bridge and stop for photos at Barron Gorge.
<G-vec00882-002-s304><cross.überqueren><de> Überqueren Sie die beeindruckende Stoney Creek Bridge und machen Sie Fotos beim Barron River Gorge.
<G-vec00882-002-s305><cross.überqueren><en> Upon exiting the station, cross the road facing the W12 Shopping Centre.
<G-vec00882-002-s305><cross.überqueren><de> Überqueren Sie beim Verlassen des Bahnhofs die Straße zum Einkaufszentrum W12.
<G-vec00882-002-s306><cross.überqueren><en> Cross the street and keep to the left.
<G-vec00882-002-s306><cross.überqueren><de> Überqueren Sie die Straße und halten Sie sich links.
<G-vec00882-002-s307><cross.überqueren><en> As you cross the Arctic Circle, the climate and landscapes become milder, but not less impressive.
<G-vec00882-002-s307><cross.überqueren><de> Mit Überqueren des Polarkreises werden sowohl das Klima als auch die Landschaft milder – jedoch nicht weniger eindrucksvoll.
<G-vec00882-002-s308><cross.überqueren><en> Cross the Cosne bridge towards Bourges.
<G-vec00882-002-s308><cross.überqueren><de> Überqueren Sie den „Pont de Cosne“ in Richtung Bourges.
<G-vec00882-002-s309><cross.überqueren><en> - Cross to the road opposite and take the 1st left into Osmanli Caddesi.
<G-vec00882-002-s309><cross.überqueren><de> - Überqueren Sie die gegenüberliegende Straße und biegen Sie in die erste Straße links ein, die Osmanli Caddesi.
<G-vec00882-002-s310><cross.überqueren><en> Cross the Mighty Mississippi to enter the realm of alligators, snakes, egrets, and other swamp creatures, and learn about the delicate wetlands ecosystem on a leisurely cruise.
<G-vec00882-002-s310><cross.überqueren><de> Überqueren Sie den Mächtigen Mississippi, um in das Reich der Alligatoren, Schlangen, Reiher und anderen Sumpfwesen zu gelangen, und lernen Sie auf einer gemütlichen Kreuzfahrt etwas über das empfindliche Feuchtgebietsökosystem.
<G-vec00882-002-s311><cross.überqueren><en> The hotel's unique location directly facing the beach, without any roads to cross to reach it, is perfect for families and those who don't want to have to give up an inspiring and unique panorama.
<G-vec00882-002-s311><cross.überqueren><de> Die einzigartige Lage des Hotels, das ohne Überqueren von Strassen direkt am Strand liegt, ist ideal für Familien und für alle, die nicht auf das Gefühl eines einzigartigen Panoramas verzichten mögen.
<G-vec00882-002-s312><cross.überqueren><en> Cross the magestic "Golfo Dulce" by boat and visit the non-profit Wildlife Caña Blanca Foundation.
<G-vec00882-002-s312><cross.überqueren><de> Überqueren Sie den majestätischen "Golfo Dulce" per Boot und besuchen Sie die gemeinnützige Stiftung Caña Blanca.
<G-vec00882-002-s313><cross.überqueren><en> Cross the fjords with the ferry from Lauvvik to Oanes or from Stavanger to Tau.
<G-vec00882-002-s313><cross.überqueren><de> Überqueren Sie die Fjorde mit der Fähre von Lauvvik bis Oanes oder von Stavanger nach Tau.
<G-vec00882-002-s314><cross.überqueren><en> Just cross the street and take tram line 2 which will bring you in 6 minutes to Grote Markt, which is the very city center.
<G-vec00882-002-s314><cross.überqueren><de> Überqueren Sie die Straße und nehmen Sie die Straßenbahnlinie 2, die Sie in 6 Minuten zum Grote Markt und zur Innenstadt bringen.
<G-vec00882-002-s315><cross.überqueren><en> If you cross the road with little traffic you can go fishing at the river bank (with a “Fiskekort” and “Statskort”, which are available during the season at the Møll Bensinstasjon petrol station), or you can go swimming.
<G-vec00882-002-s315><cross.überqueren><de> Überqueren Sie die Straße mit wenig Verkehr und Sie können am Flussufer angeln (mit "Fiskekort" und "Statskort", die in der Saison bei der Tankstelle Møll Bensinstasjon erhältlich sind) oder schwimmen gehen.
<G-vec00882-002-s316><cross.überqueren><en> When a car gets off the track, the other drivers are informed by yellow flags, warning displays, light signals and a countdown on the display in their cars when approaching the relevant section. When they cross the yellow slow zone line, overtaking is forbidden in this section and an 80kph speed limit is in force.
<G-vec00882-002-s316><cross.überqueren><de> Kommt ein Fahrzeug von der Strecke ab, dann werden die übrigen Piloten bei der Zufahrt auf den betreffenden Sektor durch gelbe Flaggen, Warntafeln, Lichtsignale und einen Countdown im Display ihres Auto darauf hingewiesen, dass mit Überqueren der gelben Slow Zone-Linie in diesem Abschnitt Überholverbot und eine Höchstgeschwindigkeit von 80 km/h gelten.
<G-vec00882-002-s317><cross.überqueren><en> Cross the bridge from the modern capital of Manama and step back in time on the island of Muharraq.
<G-vec00882-002-s317><cross.überqueren><de> Überqueren Sie die Brücke von der modernen Hauptstadt Manama und machen Sie eine Reise in die Vergangenheit, wenn Sie die Insel von Muharraq besuchen.
<G-vec00882-002-s318><cross.überqueren><en> Cross the suspension bridge and turn right.
<G-vec00882-002-s318><cross.überqueren><de> Überqueren Sie die Hängebrücke und biegen rechts ab.
<G-vec00882-002-s319><cross.überqueren><en> Play with over 50 characters. Cross roads, railways and rivers.
<G-vec00882-002-s319><cross.überqueren><de> Überqueren Sie Straßen, Bahngleise, Flüsse, Zäune...
<G-vec00882-002-s320><cross.überqueren><en> Cross the small wooden bridge to get to the ruins.
<G-vec00882-002-s320><cross.überqueren><de> Überqueren Sie die kleine Holzbrücke, um an die Burgruine zu gelangen.
<G-vec00882-002-s321><cross.überqueren><en> Cross the impressive Puente Nuevo bridge, Ronda´s most famous landmark, which straddles the deep Gorge and connects the Moorish part of Ronda with the modern part of the city.
<G-vec00882-002-s321><cross.überqueren><de> Überqueren Sie die eindrucksvolle Brücke Puente Nuevo, das berühmteste Wahrzeichen von Ronda, die die tiefe Schlucht überspannt und den maurischen Teil von Ronda mit dem modernen Teil der Stadt verbindet.
<G-vec00882-002-s322><cross.überqueren><en> Cross over "Freischützstraße" at the pedestrian crossing and walk down the right-hand side to number 9.
<G-vec00882-002-s322><cross.überqueren><de> Überqueren Sie an der Fußgängerampel die Freischützstraße und gehen Sie rechts bis zur Hausnummer 9.
<G-vec00882-002-s342><cross.überqueren><en> Up to a million people, mainly from Bangladesh, Egypt, Mali, Niger, Nigeria, Sudan and Syria are now in Libya waiting to cross the Mediterranean Sea, according to the IOM.
<G-vec00882-002-s342><cross.überqueren><de> Bis zu einer Million Menschen, vor allem aus Bangladesch, Ägypten, Mali, Niger, Nigeria, Sudan und Syrien sind derzeit in Libyen und warten darauf, dass Mittelmeer zu überqueren, so das IOM.
<G-vec00882-002-s343><cross.überqueren><en> Take the Südtunnel (south tunnel) towards the city center and cross the pedestrian traffic lights.
<G-vec00882-002-s343><cross.überqueren><de> Nutzen Sie den Südtunnel Richtung Innenstadt und überqueren Sie die Fußgängerampel.
<G-vec00882-002-s344><cross.überqueren><en> Crossy road - help a chicken cross a busy highway.
<G-vec00882-002-s344><cross.überqueren><de> Hilf in Crossy Road einem Huhn eine stark befahrene Straße zu überqueren.
<G-vec00882-002-s345><cross.überqueren><en> We go the whole distance with you, acting as a pacemaker – but we let you cross the finish line by yourself.
<G-vec00882-002-s345><cross.überqueren><de> Über die gesamte Strecke sind wir als Pacemaker an Ihrer Seite – aber die Ziellinie lassen wir Sie alleine überqueren.
<G-vec00882-002-s346><cross.überqueren><en> Further, we cross a ditch and we continue until on the right we meet with a little path that leads to the Grotta di Mezzogiorno.
<G-vec00882-002-s346><cross.überqueren><de> Auf diesem überqueren wir einen Graben und weiter geht es auf der Mittellinie des östlichen Berghangs bis zu einem Saumpfad, der zur “Grotta di Mezzogiorno” (Mittagsgrotte) führt.
<G-vec00882-002-s347><cross.überqueren><en> • Aristotle: It is the nature of chickens to cross roads.
<G-vec00882-002-s347><cross.überqueren><de> Aristoteles: Es ist die Natur von Hühnern, Straßen zu überqueren.
<G-vec00882-002-s348><cross.überqueren><en> It took us about 1 hour to cross the border from Laos to Cambodia and we can only confirm what everyone else says: they try to scam you best they can.
<G-vec00882-002-s348><cross.überqueren><de> Wir haben ungefähr eine Stunde gebraucht um die Grenze zu überqueren und wir können nur bestätigen was andere über diese Grenze sagen: sie versuchen einen auf jede mögliche Art zu verarschen.
<G-vec00882-002-s349><cross.überqueren><en> She was walking along the side of the street talking to someone, and I couldn't help but think that maybe she was talking to someone across the street because she wasn't allowed to cross it.
<G-vec00882-002-s349><cross.überqueren><de> Sie war zu Fuß auf der Seite der Straße im Gespräch mit jemandem, und ich konnte nicht helfen, aber denke, dass vielleicht war sie im Gespräch mit jemand über die Straße, weil sie nicht erlaubt war, sie zu überqueren.
<G-vec00882-002-s350><cross.überqueren><en> Lines must be placed in such a way to allow the object to cross and should not be placed in parallel near the edge of the image.
<G-vec00882-002-s350><cross.überqueren><de> Linien müssen so platziert werden, dass es dem Objekt möglich ist sie zu überqueren; nicht parallel oder am Rand des Bildes.
<G-vec00882-002-s351><cross.überqueren><en> After a short time period, you will cross a stream and follow the path, which will lead you into the spruce forest, before you will arrive up upon a hill.
<G-vec00882-002-s351><cross.überqueren><de> Nach kurzer Zeit überqueren sie einen Bach und folgen dem Pfad in den Fichtenwald hinein, bevor sie auf eine Anhöhe gelangen.
<G-vec00882-002-s352><cross.überqueren><en> It also lets us work out very precisely how often they cross certain roads," says Brieger.
<G-vec00882-002-s352><cross.überqueren><de> Außerdem lässt sich sehr genau bestimmen, wie häufig sie bestimmte Straßen überqueren“, sagt Brieger.
<G-vec00882-002-s353><cross.überqueren><en> While both of these forms can cross the blood-brain barrier to reach your brain, the phospholipid form does so far more efficiently.
<G-vec00882-002-s353><cross.überqueren><de> Während beide Formen die Blut-Hirn-Schranke überqueren können, um das Gehirn zu erreichen, ist die Phospholipidform diesbezüglich weit effizienter.
<G-vec00882-002-s354><cross.überqueren><en> Magnificent Lord of Puttaparthi, our master, grant us Your blessings so that we can cross the ocean of life, lift us up to You.
<G-vec00882-002-s354><cross.überqueren><de> Erhabener Gott von Puttaparthi, Meister, gib uns Deinen Segen, damit wir den Ozean des Lebens überqueren können, hebe uns zu Dir empor.
<G-vec00882-002-s355><cross.überqueren><en> Coming from Passau: Cross the Danube near Aschach and your holidays in St. Martin start (8km from Aschach, 15km from Eferding).
<G-vec00882-002-s355><cross.überqueren><de> Von Passau überqueren sie bei Aschach die Donau und schon beginnt Ihr Urlaub in St. Martin (8 km von Aschach, 15 km von Eferding entfernt).
<G-vec00882-002-s356><cross.überqueren><en> Press & Media Sales cross the Eisch and follow the cycle path before entering the Groussebësch.
<G-vec00882-002-s356><cross.überqueren><de> Wir kommen an der Abtei von Clairefontaine vorbei, überqueren die Eisch und kehren wieder zum Ausgangspunkt zurück.
<G-vec00882-002-s357><cross.überqueren><en> That's where he wants to cross the border.
<G-vec00882-002-s357><cross.überqueren><de> Dort wolle er die Grenze überqueren.
<G-vec00882-002-s358><cross.überqueren><en> We know that people from Liberia, Guinea and Sierra Leone cross our border with Mexico illegally.
<G-vec00882-002-s358><cross.überqueren><de> Wir wissen, dass Menschen aus Liberien, Guinea und Sierra Leone unsere Grenze zu Mexiko illegal überqueren.
<G-vec00882-002-s359><cross.überqueren><en> But the integrated character of hi-tech development, in which components cross borders during the manufacture of the final product, means that US companies will be hit by the trade war measures.
<G-vec00882-002-s359><cross.überqueren><de> Doch aufgrund des integrierten Charakters der Hightech-Entwicklung, in der Komponenten während der Herstellung des Endprodukts mehrere Landesgrenzen überqueren, werden auch amerikanische Unternehmen von den Handelskriegsmaßnahmen getroffen werden.
<G-vec00882-002-s360><cross.überqueren><en> The floods cross the border between Botswana and Namibia in December and will only reach Maun sometime in July.
<G-vec00882-002-s360><cross.überqueren><de> Die Fluten überqueren die Grenze zwischen Botswana und Namibia im Dezember und irgendwann im Juli wird Maun erreicht.
<G-vec00892-002-s114><cross.kreuzen><en> Since Christ’s Death on the Cross and his Resurrection constitute the content of the daily life of the Church (25) and the pledge of his eternal Passover, (26) the Liturgy has as its first task to lead us untiringly back to the Easter pilgrimage initiated by Christ, in which we accept death in order to enter into life. 7.
<G-vec00892-002-s114><cross.kreuzen><de> Da der Tod Christi am Kreuze und seine Auferstehung den Inhalt des täglichen Lebens der Kirche[25] und das Unterpfand ihres ewigen Ostern[26] bilden, hat die Liturgie als erste Aufgabe, uns unermüdlich auf den österlichen Weg zu führen, den uns Christus eröffnet hat und auf dem man es annimmt zu sterben, um in das Leben einzugehen.
<G-vec00892-002-s115><cross.kreuzen><en> But Jesus Christ redeemed them through his death on the cross.
<G-vec00892-002-s115><cross.kreuzen><de> Jesus Christus aber erlöste sie durch Seinen Tod am Kreuze.
<G-vec00892-002-s116><cross.kreuzen><en> Therefore we want to sacrifice and grow in unity, and we feel very strongly united in that way to the Black Cross Generation, the Founding generation of Schoenstatt.
<G-vec00892-002-s116><cross.kreuzen><de> Wir wollen Opfer bringen und zusammenwachsen, und wir fühlen uns stark verbunden mit der Generation der Schwarzen Kreuze, der Gründergeneration Schönstatts.
<G-vec00892-002-s117><cross.kreuzen><en> All our sins were passed on to Jesus before He took them to the Cross and shed blood for us.
<G-vec00892-002-s117><cross.kreuzen><de> All unsere Sünden wurden auf Jesus übertragen, bevor Er sie zu Kreuze trug und für uns Blut vergoß.
<G-vec00892-002-s118><cross.kreuzen><en> He who himself was soon to die upon the cross, stood with the keys of death, a conqueror of the grave, and asserted his right and power to give eternal life.
<G-vec00892-002-s118><cross.kreuzen><de> Er, der demnächst auf dem Kreuze sterben sollte, besaß die Schlüssel des Todes, als Besieger des Grabes und verkündete seine Berechtigung und Macht, das ewige Leben zu geben.
<G-vec00892-002-s119><cross.kreuzen><en> So the soldiers did these things, 25 but standing by the cross of Jesus were his mother and his mother's sister, Mary the wife of Clopas, and Mary Magdalene.
<G-vec00892-002-s119><cross.kreuzen><de> 25 Es standen aber bei dem Kreuze Jesu seine Mutter und die Schwester seiner Mutter, Maria, des Kleopas Weib, und Maria Magdalene.
<G-vec00892-002-s120><cross.kreuzen><en> GIA Publications - Seven Last Words from the Cross Pay Invoice
<G-vec00892-002-s120><cross.kreuzen><de> Die Sieben letzten Worte unseres Erlösers am Kreuze.
<G-vec00892-002-s121><cross.kreuzen><en> First, it is the baptism of Jesus, then the blood He shed at the Cross, and finally His resurrection from the dead.
<G-vec00892-002-s121><cross.kreuzen><de> Zuerst ist es die Taufe Jesu, dann das Blut, das Er am Kreuze vergossen hat und letztendlich Seine Wiederauferstehung von den Toten.
<G-vec00892-002-s122><cross.kreuzen><en> To repeat the move, take your back leg and cross it front of your front leg.
<G-vec00892-002-s122><cross.kreuzen><de> Um den Zug zu wiederholen, nimm dein Hinterbein und kreuze es vor deinem Vorderbein.
<G-vec00892-002-s123><cross.kreuzen><en> If He is the King of Israel, let Him now come down from the cross, and we will believe on Him.
<G-vec00892-002-s123><cross.kreuzen><de> Er ist Israels König; so steige er jetzt vom Kreuze herab, und wir wollen an ihn glauben.
<G-vec00892-002-s124><cross.kreuzen><en> It You are the Son of God, come down from the cross.¡±
<G-vec00892-002-s124><cross.kreuzen><de> Wenn du Gottes Sohn bist, so steige herab vom Kreuze.
<G-vec00892-002-s125><cross.kreuzen><en> 19:31 Now it was the day of getting ready for the Passover, and so that the bodies might not be on the cross on the Sabbath (because the day of that Sabbath was a great day), the Jews made a request to Pilate that their legs might be broken, and that they might be taken away.
<G-vec00892-002-s125><cross.kreuzen><de> 19:31 Die Juden nun baten den Pilatus, damit die Leiber nicht am Sabbath am Kreuze blieben, weil es Rüsttag war (denn der Tag jenes Sabbaths war groß), daß ihre Beine gebrochen und sie abgenommen werden möchten.
<G-vec00892-002-s126><cross.kreuzen><en> The people painted Swiss cross on the roofs of houses in the hopes that it would protect them from bombings.
<G-vec00892-002-s126><cross.kreuzen><de> Die Bevölkerung malte Schweizer Kreuze auf die Hausdächer, in der Hoffnung, das würde sie vor Bombenangriffen schützen.
<G-vec00892-002-s127><cross.kreuzen><en> I cross a couple of fog banks which originate at the Missouri.
<G-vec00892-002-s127><cross.kreuzen><de> Auch auf der Strecke weiter nach Norden kreuze ich mehrere Nebelbänke, die vom Missouri herauf ziehen.
<G-vec00892-002-s128><cross.kreuzen><en> Therefore the Rosicrucians look ardently forward to the day when the roses shall bloom upon the cross of humanity, therefore the Elder Brothers greet the aspiring soul with the words of the Rosicrucian Greeting: "May the Roses bloom upon your Cross," and therefore the greeting is given in the meetings of the Fellowship Centers by the leader to the assembled students, probationers and disciples who respond to the greeting by saying "And on yours, also."
<G-vec00892-002-s128><cross.kreuzen><de> Darum sehen die Rosenkreuzer voller Sehnsucht dem Tag entgegen, an dem die Rosen auf dem Kreuz der Menschheit erblühen werden, und deswegen begrüßen auch die Älteren Brüder die strebende Seele mit den Worten des Rosenkreuzergrußes: "Mögen die Rosen blühen auf deinem Kreuze", und darum wird auch derselbe Gruß in den Versammlungen der Gemeinschaftszentren vom Leiter an die versammelten Schüler, Prüflinge und Jünger gegeben, die den Gruß mit: "Und auch auf deinem" erwidern.
<G-vec00892-002-s129><cross.kreuzen><en> Now, cross both cloth ends behind your back at shoulder blade height.
<G-vec00892-002-s129><cross.kreuzen><de> Kreuze nun die beiden Tuchenden hinter deinem Rücken auf Schulterblatthöhe.
<G-vec00892-002-s130><cross.kreuzen><en> As we look at Jesus Christ, the Good Samaritan, we cannot forget that from the poverty of the manger to the total abandonment of the Cross, he chose to become one with the “least”.
<G-vec00892-002-s130><cross.kreuzen><de> Wenn wir unseren Blick auf Jesus Christus richten, den guten Samariter, können wir nicht vergessen, dass er – von der Armut der Krippe bis zur totalen Selbstentäußerung am Kreuze – einer der Ärmsten geworden ist.
<G-vec00892-002-s131><cross.kreuzen><en> The profound symbolism of the anchor and cross transforms the individual items of jewellery into protective talismen of a special kind: the anchor has its origins in seafaring and in general points to the question of what is our anchor in life, what gives us a firm footing.
<G-vec00892-002-s131><cross.kreuzen><de> Schützende Talismane für jeden Tag Die tiefe Symbolik der Anker und Kreuze macht die Schmuckstücke zu einem schützenden Talisman der besonderen Art: Der Anker hat seinen Ursprung in der Seefahrt und weist allgemein auf die Frage hin, was uns im Leben verankert, was uns Halt gibt.
<G-vec00892-002-s132><cross.kreuzen><en> Cross the left section over the middle section, then cross the right section over the middle section to make your braid. Then, take the middle section and cross it over the left side.
<G-vec00892-002-s132><cross.kreuzen><de> Kreuze die Mitte erst mit der linken Seite und anschließend mit der rechten Seite, nimm nun den mittleren Abschnitt und kreuze die linke Seite.
