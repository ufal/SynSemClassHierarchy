<G-vec00280-002-s057><cross.durchqueren><en> In the mean while scouts having been sent in all directions, he examines by what most convenient path he might cross the valley.
<G-vec00280-002-s057><cross.durchqueren><de> (8) In der Zwischenzeit sandte er Späher nach allen Richtungen aus, um auszukundschaften, wo man das Tal am bequemsten durchqueren könne.
<G-vec00280-002-s058><cross.durchqueren><en> Also you will cross the Silica Valley which features a very special and beautiful material – the Silica glass, also known as ‘Libyan glass’ or ‘desert emeralds’.
<G-vec00280-002-s058><cross.durchqueren><de> Außerdem durchqueren Sie das Silica-Glas-Feld, wo man ein ganz besonderes Material finden kann: das Silica-Glas, auch bekannt als ‚Libysches Wüstenglas‘.
<G-vec00280-002-s059><cross.durchqueren><en> On his bike tour through South Africa and suddenly separated from his two companions, 25-year-old Anselm faces a difficult decision: either return home or cross the Kalahari Desert alone.
<G-vec00280-002-s059><cross.durchqueren><de> Auf seiner Radreise durch Südafrika und plötzlich getrennt von seinen zwei Weggefährten, steht der 25-jährige Anselm vor einer schweren Entscheidung: ebenfalls nach Hause zurückkehren, oder alleine die Kalahari-Wüste durchqueren.
<G-vec00280-002-s060><cross.durchqueren><en> Then we cross an area vegetated with pines, from there the path becomes much more stony.
<G-vec00280-002-s060><cross.durchqueren><de> Dann durchqueren wir ein Latschengebiet, ab hier wird der Pfad deutlich steiniger.
<G-vec00280-002-s061><cross.durchqueren><en> Using boats, aristocrats could cross the city quickly and discreetly.
<G-vec00280-002-s061><cross.durchqueren><de> Aristokraten konnten die Stadt schnell und diskret per Boot durchqueren.
<G-vec00280-002-s062><cross.durchqueren><en> In this tour you will cross the northern areas of Paris to reach the foot of the Montmartre Hill.
<G-vec00280-002-s062><cross.durchqueren><de> Wir durchqueren die nördlichen Viertel von Paris, um den Fuß des Montmartre zu erreichen.
<G-vec00280-002-s063><cross.durchqueren><en> The black broken lines that cross the room give it a certain depth and color.
<G-vec00280-002-s063><cross.durchqueren><de> Die schwarzen unterbrochenen Linien, die den Raum durchqueren, geben ihm eine gewisse Tiefe und Farbe.
<G-vec00280-002-s064><cross.durchqueren><en> You should cross the pine wood in direction of south-east always going uphill.
<G-vec00280-002-s064><cross.durchqueren><de> Sie sollten den Kiefernwald in südöstlicher Richtung durchqueren und dabei immer 'bergauf' gehen.
<G-vec00280-002-s065><cross.durchqueren><en> On the right, you pass by a small rocky pinnacle with a cross, and you cross the upper part of Val Bona until you reach - with a final section between rocks and steps - the rocky terrace where the small Rifugio Torre di Pisa is located (2671 m).
<G-vec00280-002-s065><cross.durchqueren><de> Der Weg führt rechts an einer kleinen Felsspitze mit Gipfelkreuz vorbei, und Sie durchqueren den oberen Teil des Val Bona, um auf einem letzten Teilstück mit Felsen und Stufen die Felsenterrasse zu erreichen, auf der sich die kleine Hütte Torre di Pisa (2671 m) befindet.
<G-vec00280-002-s066><cross.durchqueren><en> We cross the village until the arrows divert us to the right, towards the train station.
<G-vec00280-002-s066><cross.durchqueren><de> Wir durchqueren das Dorf, bis die Pfeile uns nach rechts zum Bahnhof führen.
<G-vec00280-002-s067><cross.durchqueren><en> The yellow leaf Sunday [Sonntag], attached to the ceiling unfolds its centre through simple bends, which cross the middle horizontally, vertically, and diagonally.
<G-vec00280-002-s067><cross.durchqueren><de> Das gelbe Blatt Sonntag, das oben unter der Decke hängt, entfaltet ein Zentrum durch einfache Knicke, die horizontal, vertikal und diagonal die Mitte durchqueren.
<G-vec00280-002-s068><cross.durchqueren><en> During our adventurous drive up to the volcano, partially off-road, over cold lava streams we will cross hundreds of years old forests and make several stops to visit some of the most beautiful sites on Mount Etna by foot, accompanied by our English-speaking guide at all time.
<G-vec00280-002-s068><cross.durchqueren><de> Während wir den Vulkan hinauffahren, teilweise Off-Road, über die erkalteten Lavaströme der vergangenen Jahre, durchqueren wir auch Jahrhunderte alte Wälder und halten an einigen der schönsten Orte des Ätna, um diese zu Fuß in Begleitung eines deutschsprachigen Guides zu besichtigen.
<G-vec00280-002-s069><cross.durchqueren><en> As I noted above, Occupy emerges out of the flow of images of revolt (and languages of revolt) which cross our screens.
<G-vec00280-002-s069><cross.durchqueren><de> Wie bereits festgestellt, geht Occupy aus dem Strom der Bilder der Revolte (und der Sprachen der Revolte) hervor, die unsere Bildschirme durchqueren.
<G-vec00280-002-s070><cross.durchqueren><en> It can take up to an entire day per time zone that you cross to feel back to normal.
<G-vec00280-002-s070><cross.durchqueren><de> Pro Zeitzone, die wir durchqueren, kann es einen ganzen Tag dauern, bis wir uns wieder erholt fühlen.
<G-vec00280-002-s071><cross.durchqueren><en> We cross colorful quinoa fields painted in purples, yellows and reds, alternating with endemic species of flora and wildlife, indigenous settlements and the remains of ancient cultures.
<G-vec00280-002-s071><cross.durchqueren><de> Sie durchqueren farbenfrohe Quinoafelder in Lila-, Gelb- und Rottönen, die sich mit weiteren einheimischen Spezies der Pflanzen- und Tierwelt, indigenen Siedlungen und Relikten antiker Kultur abwechseln.
<G-vec00280-002-s072><cross.durchqueren><en> Pedestrians who cross the light-flooded passage experience their way as an interactive staging.
<G-vec00280-002-s072><cross.durchqueren><de> Passanten, die die lichtdurchflutete Passage durchqueren erleben ihren Weg als interaktive Inszenierung.
<G-vec00280-002-s073><cross.durchqueren><en> I had to cross a few mountains and valleys before I asked for a place to stay in a small town.
<G-vec00280-002-s073><cross.durchqueren><de> Einige Berge und Täler waren zu durchqueren bis ich abends in einem Dorf nach einem Schlafplatz fragte.
<G-vec00280-002-s074><cross.durchqueren><en> 4. There is a river you must cross but it is used by crocodiles, and you
<G-vec00280-002-s074><cross.durchqueren><de> 9 Frage Nummer 4: Sie müssen einen Fluss durchqueren, wissen aber, dass er von Krokodilen bewohnt wird.
<G-vec00280-002-s075><cross.durchqueren><en> The island is easy to visit by car: you can drive around the whole island in 2 hours and cross it from east to west in only 20 minutes.
<G-vec00280-002-s075><cross.durchqueren><de> Die Insel ist leicht mit dem Auto zu besichtigen: man kann die ganze Insel in 2 Stunden umrunden und in nur 20 Minuten von Ost nach West durchqueren.
<G-vec00280-002-s133><cross.kreuzen><en> Lines can cross each other except at black dots.
<G-vec00280-002-s133><cross.kreuzen><de> Linien können einander kreuzen außer an schwarzen Punkten.
<G-vec00280-002-s134><cross.kreuzen><en> To cross a long-haired breed with a dairy is stupid, only if the litter is slaughtered.
<G-vec00280-002-s134><cross.kreuzen><de> Eine langhaarige Rasse mit einer Molkerei zu kreuzen, ist nur dumm, wenn der Wurf geschlachtet wird.
<G-vec00280-002-s135><cross.kreuzen><en> On Fifth Avenue in New York, where the paths of successful urbanites and sophisticated jetsetters cross, we operate the Wempe Rolex Boutique inside the impressive Rolex Building.
<G-vec00280-002-s135><cross.kreuzen><de> An New Yorks Fifth Avenue, wo sich die Wege erfolgreicher Metropoliten und mondäner Weltenbummler kreuzen, führen wir die Rolex Boutique Wempe direkt im beeindruckenden Rolex Building.
<G-vec00280-002-s136><cross.kreuzen><en> Your connections must not cross.
<G-vec00280-002-s136><cross.kreuzen><de> Ihre Verbindungen müssen nicht kreuzen.
<G-vec00280-002-s137><cross.kreuzen><en> The timeline is an illusion but for just a brief moment when those timelines cross, the illusion is gone.
<G-vec00280-002-s137><cross.kreuzen><de> Die Zeitlinie ist eine Illusion, aber für einen kurzen Augenblick, wenn sich diese Zeitlinien kreuzen, ist die Illusion aufgehoben.
<G-vec00280-002-s138><cross.kreuzen><en> They went on to cross this with Power Sativa, a hybrid with Early Sativa and Power Haze XL as parents.
<G-vec00280-002-s138><cross.kreuzen><de> Sie fuhren damit fort, diese mit Power Sativa zu kreuzen, einem Hybriden mit Early Sativa und Power Haze XL als Eltern.
<G-vec00280-002-s139><cross.kreuzen><en> Baboons constantly cross one’s path.
<G-vec00280-002-s139><cross.kreuzen><de> Immer wieder kreuzen Paviane den Weg.
<G-vec00280-002-s140><cross.kreuzen><en> In addition to the steep slopes, few marked trails cross only short sections of the reserve.
<G-vec00280-002-s140><cross.kreuzen><de> Neben den steilen Hängen kreuzen wenige markierte Wanderwege nur sehr kleine Teile des Reservats.
<G-vec00280-002-s141><cross.kreuzen><en> Here you have to cross the main road to reach the fortress of Antimachia.
<G-vec00280-002-s141><cross.kreuzen><de> Hier musst du die Hauptstraße kreuzen, um zur Festung von Antimachia zu gelangen.
<G-vec00280-002-s142><cross.kreuzen><en> Animals like sloths, monkeys, toucans, crocodiles, Jesus Christ Lizards, and turtles might cross your way, including seeing the colorful world of tropical birds.
<G-vec00280-002-s142><cross.kreuzen><de> Tiere wie Faultiere, Affen, Tukane, Krokodile, Eidechsen und Schildkröten können Ihren Weg kreuzen und sogar die bunte Welt der tropischen Vögel sehen.
<G-vec00280-002-s143><cross.kreuzen><en> Remove all dead branches, together with those who cross each other, from spring to summer.
<G-vec00280-002-s143><cross.kreuzen><de> Entfernen Sie alle toten Ästen, zusammen mit denen, die sich kreuzen, vom Frühling zum Sommer.
<G-vec00280-002-s144><cross.kreuzen><en> It is working like this: the weft and warp are overlapping, and the warp and weft yarn with the same size, the wire along the long, the net width of weft are parallel to the net, the warp and weft wire cross, one at the top at the bottom, at an Angle of 90 °.
<G-vec00280-002-s144><cross.kreuzen><de> Es funktioniert so: Der Schuss und die Kette überlappen sich, und der Schuss und der Schussfaden mit der gleichen Größe, der Draht entlang der Länge, die Nettobreite des Schussfadens sind parallel zum Netz, der Schuss und die Kette kreuzen sich oben unten im Winkel von 90 °.
<G-vec00280-002-s145><cross.kreuzen><en> You are about to cross timelines with yourself and we tell you, that can be exciting for some.
<G-vec00280-002-s145><cross.kreuzen><de> Ihr seid dabei, die Zeitlinien mit euch selbst zu kreuzen und wir sagen euch, das kann für einige ganz schön aufregend sein.
<G-vec00280-002-s146><cross.kreuzen><en> The first manufacturing activity, at the time located on the ground floor of the family house, was the production of PVC cross spacers of different dimensions for the installation of tiles.
<G-vec00280-002-s146><cross.kreuzen><de> Die erste Geschäftstätigkeit, damals noch im Erdgeschoss des Familienhauses, war die Produktion von PVC Kreuzen zur Verlegung von Fliesen verschiedener Größen.
<G-vec00280-002-s147><cross.kreuzen><en> The rope used to cross the creek breaks, sending Leslie falling to her death.
<G-vec00280-002-s147><cross.kreuzen><de> Das Seil, das verwendet wird, um die Nebenflussbrüche zu kreuzen, sendet Leslie, das zu ihrem Tod fällt.
<G-vec00280-002-s148><cross.kreuzen><en> When allocating rooms, we take care that the paths of different groups do not cross if possible.
<G-vec00280-002-s148><cross.kreuzen><de> Bei der Zimmerverteilung achten wir darauf, dass die Wege unterschiedlicher Gruppen sich möglichst nicht kreuzen.
<G-vec00280-002-s149><cross.kreuzen><en> Stones, steep ascents, upended tree trunks which cross the image diagonally – a number of hurdles must be overcome on this path.
<G-vec00280-002-s149><cross.kreuzen><de> Steine, steile Anstiege, gestürzte Baumstämme, die als Diagonale den Bildraum kreuzen – manche Hindernisse gilt es auf diesem Weg zu überwinden.
<G-vec00280-002-s150><cross.kreuzen><en> Each cell must be visited exactly once; lines cannot cross.
<G-vec00280-002-s150><cross.kreuzen><de> Jedes Feld muss genau einmal besucht werden; Pfade dürfen sich nicht kreuzen.
<G-vec00280-002-s151><cross.kreuzen><en> Berlin is a place where gastronomic traditions from around the world cross.
<G-vec00280-002-s151><cross.kreuzen><de> Berlin ist ein typischer Ort, an dem sich Esskulturen aus aller Welt kreuzen.
<G-vec00280-002-s361><cross.überqueren><en> The simulation is so realistic that people stick to the rules of the road, watch out for traffic, and only cross the street at pedestrian crossings.
<G-vec00280-002-s361><cross.überqueren><de> Die Simulation ist dabei so realistisch, dass man sich an die Strassenregeln hält, auf den Verkehr achtet und die Straße nur bei Fussgängerstreifen überquert.
<G-vec00280-002-s362><cross.überqueren><en> We cross the railway tracks and turn left.
<G-vec00280-002-s362><cross.überqueren><de> Nachdem wir die Bahnlinie überquert haben, biegen wir gleich danach links ab.
<G-vec00280-002-s363><cross.überqueren><en> From there, he will cross the Black Sea to Istanbul and then sail on towards the Dardanelles and the former Troy.
<G-vec00280-002-s363><cross.überqueren><de> Von dort aus wird das Schwarze Meer überquert, nach Istanbul und weiter zum Mittelmeer Richtung Dardanellen und dem einstigen Troja gesegelt.
<G-vec00280-002-s364><cross.überqueren><en> Why Did The Chicken Cross The Road
<G-vec00280-002-s364><cross.überqueren><de> Ein Huhn überquert die Straße.
<G-vec00280-002-s365><cross.überqueren><en> Either park there and cross the motorway bridge to follow the trail on the northern side of the river Inn.
<G-vec00280-002-s365><cross.überqueren><de> In Haiming folgt man der Beschilderung "Outdoorzentrum" und überquert die Innbrücke zum Weiler "Magerbach".
<G-vec00280-002-s366><cross.überqueren><en> After the waterfall, when you reach the "Fields of An'she", cross the river and go inside the cave, there is Griffe-hirsute.
<G-vec00280-002-s366><cross.überqueren><de> Nach dem Wasserfeld, wenn ihr "Die Felder von An'she" erreicht, überquert den Fluss und geht in die Höhle, darin befindet sich Borstenschlund.
<G-vec00280-002-s367><cross.überqueren><en> At the end of the road, you cross a bridge over the Fosso Cervia and bear left onto another dirt road and follow the canal.
<G-vec00280-002-s367><cross.überqueren><de> Am Ende dieser Straße überquert man die Brücke über den Fosso Cervia, biegt links ab und wandert weiterhin auf einer Schotterstraße dem Kanal entlang.
<G-vec00280-002-s368><cross.überqueren><en> Then you cross Rainbow Bridge together. – Author unknown
<G-vec00280-002-s368><cross.überqueren><de> Dann überquert Ihr gemeinsam die Regenbogen-Brücke...
<G-vec00280-002-s369><cross.überqueren><en> The path along the Plaza de Obradoiro, descend by the Carballeira de San Lourenzo and cross the municipalities of Ames, Negreira and Mazaricos.
<G-vec00280-002-s369><cross.überqueren><de> Der Weg geht von der Plaza del Obradoiro aus über den Eichenhain von San Lourenzo und überquert die Gemeinden Ames, Negreira und Mazaricos.
<G-vec00280-002-s370><cross.überqueren><en> For example, in the Formula 1 section, you can bet when exactly will the winner cross the finish line.
<G-vec00280-002-s370><cross.überqueren><de> Bei der Formel 1 kann beispielsweise getippt werden, in welcher Zehntelsekunde der Sieger die Ziellinie überquert.
<G-vec00280-002-s371><cross.überqueren><en> Perhaps there are some snow fields to cross, but generally the climb is easy.
<G-vec00280-002-s371><cross.überqueren><de> Möglicherweise müssen einige Schneefelder überquert werden, aber Allgemein ist der Aufstieg einfach.
<G-vec00280-002-s372><cross.überqueren><en> Turn right into the Bodenegg Race Track (661), cross Venter Ache brook and return to Zwieselstein and Sölden. Getting There
<G-vec00280-002-s372><cross.überqueren><de> Dort biegt man rechts auf die Rennstrecke Bodenegg (661) ab, überquert die Venter Ache und kommt über Zwieselstein erneut zurück nach Sölden.
<G-vec00280-002-s374><cross.überqueren><en> Then you cross Rainbow Bridge together… Remember…….
<G-vec00280-002-s374><cross.überqueren><de> DANN überquert ihr die Regenbogen-Brücke gemeinsam.
<G-vec00280-002-s375><cross.überqueren><en> Even if a part of us were to cross it, everyone else would gradually begin to squeeze through this barrier following the thread of our connection.
<G-vec00280-002-s375><cross.überqueren><de> Selbst wenn nur ein Teil von uns diese Grenze überquert, fangen alle anderen an, über unseren Verbindungsfaden allmählich durch diese Schranke durchzusickern.
<G-vec00280-002-s376><cross.überqueren><en> At the first crossroad turn left and cross the Val Casies Valley stream to reach the hamlet of Wiesen (Hotel Tyrol, refreshment stop).
<G-vec00280-002-s376><cross.überqueren><de> An der ersten Kreuzung biegt man links ab und überquert den Talbach, um zum Weiler Wiesen zu gelangen.
<G-vec00280-002-s377><cross.überqueren><en> First you cross the drain of the waterfall over a small pedestrian bridge.
<G-vec00280-002-s377><cross.überqueren><de> Als erstes überquert man den Abfluss vom Wasserfall über eine kleine Fußgängerbrücke.
<G-vec00280-002-s378><cross.überqueren><en> Without noticing it, you can cross the state border with the U1 underground from Langenhorn.
<G-vec00280-002-s378><cross.überqueren><de> Ohne es zu bemerken, überquert man mit der U-Bahn U1 von Langenhorn kommend die Landesgrenze.
<G-vec00280-002-s379><cross.überqueren><en> The trail suddenly changes direction and shortly after you’ll reach a beautiful glade that you must cross pointing to the visible trail on the other side.
<G-vec00280-002-s379><cross.überqueren><de> Der Weg ändert plötzlich seine Richtung und erreicht dann schnell eine schöne Lichtung, die auf dem gut sichtbaren Pfad überquert werden muss.
<G-vec00280-002-s380><cross.überschreiten><en> Ketone bodies cross the blood brain barrier very readily.
<G-vec00280-002-s380><cross.überschreiten><de> Ketonkörper überschreiten die Blut-Gehirn-Schranke sehr schnell und leicht.
<G-vec00280-002-s381><cross.überschreiten><en> Dare to cross the limits of beauty.
<G-vec00280-002-s381><cross.überschreiten><de> Wagen Sie es die Grenzen der Schönheit zu überschreiten.
<G-vec00280-002-s382><cross.überschreiten><en> We can affirm that despondency will not cross the threshold of Our Abode, for joy lives there.
<G-vec00280-002-s382><cross.überschreiten><de> Wir können bestätigen, daß Verzagtheit die Schwelle Unserer Wohnstatt nicht überschreiten wird, denn dort lebt die Freude.
<G-vec00280-002-s383><cross.überschreiten><en> Flashlights from China, cars from Germany and coffee from Guatemala – whenever a product has to cross a border and arrive exactly where it is needed, logistics operations managers are at work.
<G-vec00280-002-s383><cross.überschreiten><de> Taschenlampen aus China, Autos aus Deutschland und Kaffee aus Guatemala – wenn ein Produkt eine Grenze überschreiten muss und genau dort ankommt, wo es benötigt wird, sind Speditionskaufleute am Werk.
<G-vec00280-002-s384><cross.überschreiten><en> We deliberately cross boundaries, both in our heads and in our organisation.
<G-vec00280-002-s384><cross.überschreiten><de> Wir überschreiten bewusst übliche Grenzen - in unseren Köpfen und in unserer Organisation.
<G-vec00280-002-s385><cross.überschreiten><en> In the course of the night and the following day, more than 10.000 refugees cross the Austrian border.
<G-vec00280-002-s385><cross.überschreiten><de> Im Laufe der Nacht und am darauf folgenden Tag überschreiten mehr als 10.000 Flüchtlinge die österreichische Grenze.
<G-vec00280-002-s386><cross.überschreiten><en> Hister required, then, of the Lygians a promise not to cross the boundary; to this they not only agreed, but gave hostages, among whom were the wife and daughter of their leader.
<G-vec00280-002-s386><cross.überschreiten><de> Hister verlangte nun von den Lygiern das Versprechen, die Grenze nicht zu überschreiten; diese verpflichteten sich nicht nur hierzu, sondern stellten auch Geiseln, unter denen sich die Gemahlin und die Tochter ihres Fürsten befanden.
<G-vec00280-002-s387><cross.überschreiten><en> These are red lines we cannot cross.
<G-vec00280-002-s387><cross.überschreiten><de> Dies sind rote Linien, die wir nicht überschreiten können.
<G-vec00280-002-s388><cross.überschreiten><en> Occasionally they even cross the frontiers of Afghanistan or Pakistan on their migrations.
<G-vec00280-002-s388><cross.überschreiten><de> Gelegentlich überschreiten sie bei ihren Wanderungen sogar die Grenzen nach Afghanistan oder Pakistan.
<G-vec00280-002-s389><cross.überschreiten><en> Seek not, then, to cross this Threshold until thou dost feel thyself entirely free from fear and ready for the highest responsibility.
<G-vec00280-002-s389><cross.überschreiten><de> Versuche nicht früher diese Schwelle zu überschreiten, bis du ganz frei von Furcht und bereit zu höchster Verantwortlichkeit dich fühlst.
<G-vec00280-002-s390><cross.überschreiten><en> Death does not as such appear in a picture, nor does a picture die; thus the application of photography make it possible to cross such boundaries.
<G-vec00280-002-s390><cross.überschreiten><de> Weder erscheint der Tod im Bild, noch ist das Bild dem Tode geweiht; Verwendungsformen der Fotografie ermöglichen es, solche Grenzziehungen zu überschreiten.
<G-vec00280-002-s391><cross.überschreiten><en> The Italians cross the border in Acquabona.
<G-vec00280-002-s391><cross.überschreiten><de> Die Italiener überschreiten die Grenze bei Acquabona.
<G-vec00280-002-s392><cross.überschreiten><en> Do not be afraid to cross the threshold of his dwelling, to speak with him face to face, as friends speak to each other (cf.
<G-vec00280-002-s392><cross.überschreiten><de> Habt keine Angst, die Schwelle seines Hauses zu überschreiten, mit ihm von Angesicht zu Angesicht zu reden, wie man sich mit einem Freund unterhält (vgl.
<G-vec00280-002-s393><cross.überschreiten><en> We only have discovered just recently what we are able to do as musicians, which barriers we may cross.
<G-vec00280-002-s393><cross.überschreiten><de> Wir haben eben erst entdeckt, wozu wir als Musiker in der Lage sind, welche Barrieren wir überschreiten können.
<G-vec00280-002-s394><cross.überschreiten><en> The Bride will cross a rustic bridge on the way to the beach area where she will meet up with her Groom and start a new life together.
<G-vec00280-002-s394><cross.überschreiten><de> Die Braut wird eine rustikale Brücke am Weg zum Strand überschreiten, wo sie sich mit ihrem Bräutigam treffen und ein neues Leben zu zweit beginnen wird.
<G-vec00280-002-s395><cross.überschreiten><en> A small group of Republicans were willing to cross party lines to rebuke Trump over his support for a conflict the United Nations has declared a humanitarian disaster, which has killed tens of thousands of civilians and left half the population of Yemen on the brink of starvation.
<G-vec00280-002-s395><cross.überschreiten><de> Eine kleine Gruppe von Republikanern war bereit, die eigenen Parteigrenzen zu überschreiten, um Donald Trump, der ebenfalls der Republikanischen Partei angehört, wegen seiner Unterstützung für einen Konflikt zu tadeln, den die Vereinten Nationen zu einer humanitären Katastrophe erklärt haben, da er Zehntausende von Zivilisten getötet und die Hälfte der Bevölkerung im Jemen am Rande des Hungers zurückgelassen hat.
<G-vec00280-002-s396><cross.überschreiten><en> It’s important to know that Chilean and Bolivian tour operators aren’t allowed to cross the border, so every border crossing comes with a new vehicle and driver.
<G-vec00280-002-s396><cross.überschreiten><de> Es ist wichtig zu wissen, dass die chilenischen und bolivianischen Tourenanbieter die Landesgrenze nicht überschreiten dürfen - jeder Grenzübergang hat somit auch einen Fahrzeug- und Fahrerwechsel zur Folge.
<G-vec00280-002-s397><cross.überschreiten><en> You cross the border between the region Département Champagne Ardenne and Bourgogne.
<G-vec00280-002-s397><cross.überschreiten><de> Wir überschreiten die Départementgrenze und die Grenze zwischen der Regionen Champagne-Ardenne und Bourgogne.
<G-vec00280-002-s398><cross.überschreiten><en> This explains why the nodal axis is so strongly associated with significant meetings with people who may challenge us, appear to thwart us, or who function as messengers, guides or teachers, helping us, and sometimes forcing us, to cross thresholds which would otherwise never occur to us, or which we are afraid to cross without some kind of help, guidance or encouragement.
<G-vec00280-002-s398><cross.überschreiten><de> Das erklärt, warum die Mondknotenachse so oft mit wichtigen Begegnungen mit Menschen assoziiert wird, die uns vielleicht herausfordern, uns scheinbar behindern oder für uns als Botschafter, Führer oder Lehrer fungieren; als solche helfen sie uns und zwingen uns manchmal sogar, Schwellen zu überschreiten, von denen wir uns sonst fernhalten würden oder die wir ohne Hilfe, Anleitung oder Ermutigung nicht zu überschreiten wagten.
