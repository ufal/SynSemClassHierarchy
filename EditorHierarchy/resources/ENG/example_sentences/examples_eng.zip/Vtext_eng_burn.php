<G-vec00721-002-s026><burn.abbrennen><en> We have taken yet another decision – one I knew nothing about because the decision was taken by the Member States but the Commission will be blamed anyway – this time to lay down how fast Christmas candles should burn.
<G-vec00721-002-s026><burn.abbrennen><de> Wir haben jetzt wieder eine Entscheidung getroffen, von der ich nichts wusste, weil diese Entscheidung von den Mitgliedstaaten getroffen wurde, aber die Kommission wird jetzt dafür schuldig gemacht – wir haben jetzt vorgeschrieben, wie schnell Weihnachtskerzen abbrennen dürfen.
<G-vec00721-002-s027><burn.abbrennen><en> Uneven joints often burn down one side if not packed tightly enough, as cannabis burns a lot quicker.
<G-vec00721-002-s027><burn.abbrennen><de> Da Cannabis viel schneller verbrennt, kann ein Joint auf einer Seite unregelmäßig abbrennen, wenn er nicht fest genug gedreht wurde.
<G-vec00721-002-s028><burn.abbrennen><en> A well-maintained lush landscape with mixed forests and fields, with springs and creeks flowing throughout the year would not burn down that easily.
<G-vec00721-002-s028><burn.abbrennen><de> Eine gut gepflegte, fruchtbare Landschaft mit Feldern und Wäldern in Mischkultur, mit Bächen und Quellen, die während des ganzen Sommers fließen, würde nicht so einfach abbrennen.
<G-vec00721-002-s029><burn.abbrennen><en> But, sometimes you just gotta burn away as well.
<G-vec00721-002-s029><burn.abbrennen><de> Aber manchmal muss man auch einfach alles abbrennen.
<G-vec00721-002-s030><burn.abbrennen><en> This meant that these rock-solid buildings could not burn down, and that Charlotte Amalie was therefore guaranteed supplies, even if the pharmacy fell victim to fire, hurricane or both. Foresighted employee policy
<G-vec00721-002-s030><burn.abbrennen><de> Das bedeutete, dass diese Gebäude aus solidem Stein nicht abbrennen konnten und dass die Versorgung für die Stadt Charlotte Amalie garantiert war, sogar wenn die Apotheke Opfer einer Brandkatastrophe, eines Hurrikans oder beidem werden würde.
<G-vec00721-002-s031><burn.abbrennen><en> The MAXXHEAT is a multi-purpose tool and can also be used to burn off paint.
<G-vec00721-002-s031><burn.abbrennen><de> Das MAXXHEAT ist ein Mehrzweckwerkzeug und kann auch zum Abbrennen von Farbe verwendet werden.
<G-vec00721-002-s032><burn.abbrennen><en> The third phase is then to burn the cleared areas.
<G-vec00721-002-s032><burn.abbrennen><de> Die dritte Stufe ist dann das Abbrennen der gerodeten Flächen.
<G-vec00721-002-s033><burn.abbrennen><en> The incense cones are lit at the top, then blow out the flame and burn on a fireproof surface.
<G-vec00721-002-s033><burn.abbrennen><de> Die Räucherkegel werden an der Spitze angezündet, die Flamme dann ausblasen und auf einer feuerfesten Unterlage abbrennen.
<G-vec00721-002-s034><burn.anbrennen><en> Our advice is therefore not to let your meat burn and not to overheat barbecue meat too often.
<G-vec00721-002-s034><burn.anbrennen><de> Wir raten daher, Ihr Fleisch nicht anbrennen zu lassen und Grillfleisch nicht zu oft zu überhitzen.
<G-vec00721-002-s035><burn.anbrennen><en> When modern, extra wide induction hob together with the powerful extractor nothing can burn.
<G-vec00721-002-s035><burn.anbrennen><de> Beim modernen, überbreiten Induktionskochfeld zusammen mit dem leistungsstarken Dunstabzug kann nichts mehr anbrennen.
<G-vec00721-002-s036><burn.anbrennen><en> Do not burn, it would be a pity, therefore, keep in mind.
<G-vec00721-002-s036><burn.anbrennen><de> Nicht anbrennen lassen, das wäre schade, deshalb im Auge behalten.
<G-vec00721-002-s037><burn.anbrennen><en> Volunteers helped to shift the oven every 17 minutes so as to not burn the dough.
<G-vec00721-002-s037><burn.anbrennen><de> Freiwillige halfen dabei, den Ofen alle 17 Minuten zu versetzen, um ein Anbrennen des Teiges zu verhindern.
<G-vec00721-002-s038><burn.anbrennen><en> Located in the Tyrolean Alps (a hotspot for winter sports), Mayrhofen is a never-ending party on and off the slopes, making it a popular destination for those who like to burn the candle at both ends.
<G-vec00721-002-s038><burn.anbrennen><de> Es befindet sich in den Tiroler Alpen (ein Hotspot für den Wintersport)- Mayrhofen ist eine nie endende Party auf und abseits der Pisten, ein beliebtes Ziel für diejenigen, die die Kerze an beiden Enden anbrennen lassen möchten.
<G-vec00721-002-s039><burn.anbrennen><en> Because of Titanium Excellence's special non-stick surface, with a hard mineral base, you will never burn your food.
<G-vec00721-002-s039><burn.anbrennen><de> Dank der speziellen Antihaft-Oberfläche von Titanium Excellence mit einer harten Mineralbasis kann Ihr Essen niemals anbrennen.
<G-vec00721-002-s040><burn.anbrennen><en> In addition, it boasts a strong resistance to thermal shocks and high non-adhesiveness, which guarantees that you will never burn your food.
<G-vec00721-002-s040><burn.anbrennen><de> Zusätzlich zeichnen sie sich durch eine starke Temperaturwechselbeständigkeit und eine hohe Antihaftbeschichtung aus, dank welcher Ihr Essen bestimmt nicht anbrennen wird.
<G-vec00721-002-s041><burn.anbrennen><en> The food can burn.
<G-vec00721-002-s041><burn.anbrennen><de> – Die Speisen können anbrennen.
<G-vec00721-002-s042><burn.anbrennen><en> This time I let it no longer burn with 10-4 advantage and realised directly the first match ball.
<G-vec00721-002-s042><burn.anbrennen><de> Dieses Mal ließ ich bei einer 10-4 Führung nichts mehr anbrennen u. verwandelte direkt den ersten Matchball.
<G-vec00721-002-s043><burn.anbrennen><en> Occasionally mix the florets with a wooden spoon, to avoid them to burn.
<G-vec00721-002-s043><burn.anbrennen><de> Die Röschen gelegentlich mit einem Kochlöffel vermengen, damit sie nicht anbrennen.
<G-vec00721-002-s044><burn.anbrennen><en> Don’t let the mixture boil to long or burn.
<G-vec00721-002-s044><burn.anbrennen><de> Achte darauf, dass du die Mischung nicht zu lange kochst oder anbrennen lässt.
<G-vec00721-002-s045><burn.anbrennen><en> Be careful, the mix tends to burn fast, if you don’t keep an eye on it.
<G-vec00721-002-s045><burn.anbrennen><de> Den Topf dabei immer im Auge behalten, weil die Mischung auch schnell anbrennen kann, wenn man nicht aufpasst.
<G-vec00721-002-s046><burn.anbrennen><en> If an absinthe spoon is used, take care that the sugar does not burn, nor drip into the absinthe, ruining its flavor.
<G-vec00721-002-s046><burn.anbrennen><de> Falls du einen Absinthlöffel benutzt, achte darauf, dass der Zucker weder anbrennt noch in den Absinth tropft und dadurch dessen Geschmack ruiniert.
<G-vec00721-002-s047><burn.anbrennen><en> The electronic thermostat ensures an optimum temperature of 48 -52 ° C, so that the chocolate remains liquid, but does not overheat and burn.
<G-vec00721-002-s047><burn.anbrennen><de> Das elektronische Thermostat sorgt für eine optimale Temperatur von 48-52°C, so dass die Schoklade flüssig bleibt, aber nicht überhitzt und anbrennt.
<G-vec00721-002-s048><burn.anbrennen><en> Because of this it is nearly impossible for whatever you have warming up nicely in the pan to burn or boil over.
<G-vec00721-002-s048><burn.anbrennen><de> Damit ist es nahezu unmöglich, dass eine im Topf erwärmte Substanz anbrennt oder überkocht.
<G-vec00721-002-s049><burn.anbrennen><en> So you’ll have to be very careful not to let them all burn.
<G-vec00721-002-s049><burn.anbrennen><de> Du musst also sehr aufmerksam sein, damit nichts anbrennt.
<G-vec00721-002-s050><burn.anbrennen><en> But we also have saucepans with this material so your eggs won’t burn.
<G-vec00721-002-s050><burn.anbrennen><de> Aber es gibt auch Pfannen mit diesem Material, damit ihr Ei nicht anbrennt.
<G-vec00721-002-s051><burn.anbrennen><en> But this recipe is really great, it's the first time that I managed not to burn the rice pudding. And I really like the lemon flavour thanks to the lemon zest (if you like, you can also add some lemon juice at the end - I haven't tried that so far).
<G-vec00721-002-s051><burn.anbrennen><de> Der Milchreis ist aber echt klasse, dank dem Rezept schaffe ich es zum ersten Mal seit langem, dass er mir nicht immer anbrennt, und ich mag die Zitronennote durch die Zitronenschale (wer mag, kann auch am Ende noch etwas Zitronensaft dazugeben, das habe ich bisher noch nicht ausprobiert).
<G-vec00721-002-s052><burn.anbrennen><en> Stir occasionally so that the buckwheat does not burn.
<G-vec00721-002-s052><burn.anbrennen><de> Ab und zu umrühren, damit der Buchweizen nicht anbrennt.
<G-vec00721-002-s053><burn.anbrennen><en> Reduce the heat to medium and cook for 3 to 4 minutes or until the peel is golden and soft—mind that it doesn’t burn.
<G-vec00721-002-s053><burn.anbrennen><de> Bei mittlerer Hitze etwa 3–4 Minuten köcheln lassen, bis die Schale golden und weich ist – aufpassen, dass sie nicht anbrennt.
<G-vec00721-002-s054><burn.anzünden><en> 17 The Light of Israel will become a fire, their Holy One a flame; in a single day it will burn and consume his thorns and his briers.
<G-vec00721-002-s054><burn.anzünden><de> 17 Und das Licht Israels wird ein Feuer sein, und sein Heiliger wird eine Flamme sein, und sie wird Assurs Dornen und Disteln anzünden und verzehren an einem einzigen Tag.
<G-vec00721-002-s055><burn.anzünden><en> 6 And the priest shall sprinkle the blood upon the altar of the LORD at the door of the tabernacle of the congregation and burn the fat for a sweet savour to the LORD.
<G-vec00721-002-s055><burn.anzünden><de> 6 Und der Priester soll das Blut auf den Altar des HERRN sprengen vor der Tür der Hütte des Stifts und das Fett anzünden zum süßen Geruch dem HERRN.
<G-vec00721-002-s056><burn.anzünden><en> but its inwards and its legs shall he wash with water: and the priest shall burn the whole on the altar, for a burnt-offering, an offering made by fire, of a sweet savor unto Jehovah.
<G-vec00721-002-s056><burn.anzünden><de> 9 Das Eingeweide aber und die Schenkel soll man mit Wasser waschen, und der Priester soll das alles anzünden auf dem Altar zum Brandopfer.
<G-vec00721-002-s057><burn.anzünden><en> 13 And you shall take all the fat that covers the entrails, the fatty lobe attached to the liver, and the two kidneys and the fat that is on them, and burn them on the altar like incense.
<G-vec00721-002-s057><burn.anzünden><de> 13 Und sollst nehmen alles Fett, das die Eingeweide bedeckt und das Netz über der Leber und die zwei Nieren und das Fett, das über ihnen ist, und es anzünden auf dem Altar.
<G-vec00721-002-s058><burn.anzünden><en> All the fat that covers its inner organs, as well as the lobe of its liver and its two kidneys, together with the fat that is on them, you shall take and burn on the altar.
<G-vec00721-002-s058><burn.anzünden><de> Und sollst alles Fett nehmen am Eingeweide und das Netz über der Leber und die zwei Nieren mit dem Fett, das darüber liegt, und sollst es auf dem Altar anzünden.
<G-vec00721-002-s059><burn.anzünden><en> The priest shall burn the fat on the altar,r but the brisket belongs to Aaron and his sons.
<G-vec00721-002-s059><burn.anzünden><de> Und der Priester soll das Fett anzünden auf dem Altar, aber die Brust soll Aarons und seiner Söhne sein.
<G-vec00721-002-s060><burn.anzünden><en> 7:31 Who shall burn the fat upon the altar, but the breast shall be Aaron's and his sons'.
<G-vec00721-002-s060><burn.anzünden><de> 7:31 Und der Priester soll das Fett anzünden auf dem Altar; und die Brust soll Aarons und seiner Söhne sein.
<G-vec00721-002-s061><burn.anzünden><en> And the priest shall offer the whole, and burn it upon the altar.
<G-vec00721-002-s061><burn.anzünden><de> Und der Priester soll es alles opfern und anzünden auf dem Altar zum Brandopfer.
<G-vec00721-002-s062><burn.anzünden><en> The priest shall sprinkle the blood on the altar of Yahweh at the door of the tent of meeting, and burn the fat for a sweet savor to Yahweh.
<G-vec00721-002-s062><burn.anzünden><de> Und der Priester soll das Blut auf den Altar des HERRN sprengen vor der Tür der Hütte des Stifts und das Fett anzünden zum süßen Geruch dem HERRN.
<G-vec00721-002-s063><burn.anzünden><en> And they will burn among them, and consume them, and there will not be one left to the house of Esau, for Jehovah hath spoken."
<G-vec00721-002-s063><burn.anzünden><de> Das werden sie anzünden und verzehren, daß dem Hause Esau nichts überbleibe; denn der HERR hat's geredet.
<G-vec00721-002-s064><burn.anzünden><en> 17 † “But you shall not redeem the firstborn of a cow, or the firstborn of a sheep, or the firstborn of a goat. They are holy. You shall sprinkle their blood on the altar, and shall burn their fat for an offering made by fire, for a pleasant aroma to Adonai .
<G-vec00721-002-s064><burn.anzünden><de> 17 Aber die erste Frucht eines Rindes oder Schafes oder einer Ziege sollst du nicht zu lösen geben, denn sie sind heilig; ihr Blut sollst du sprengen auf den Altar, und ihr Fett sollst du anzünden zum Opfer des süßen Geruchs dem HERRN.
<G-vec00721-002-s065><burn.anzünden><en> 1 "For, behold, the day comes, it burns as a furnace; and all the proud, and all who work wickedness, will be stubble; and the day that comes will burn them up," says the Lord of Hosts, "that it shall leave them neither root nor branch.
<G-vec00721-002-s065><burn.anzünden><de> Maleachi 3-b 19 Denn siehe, es kommt ein Tag, der brennen soll wie ein Ofen; da werden alle Verächter und Gottlosen Stroh sein, und der künftige Tag wird sie anzünden, spricht der HERR Zebaoth, und wird ihnen weder Wurzel noch Zweige lassen.
<G-vec00721-002-s066><burn.anzünden><en> 16 And if any man said to him, Let them not fail to burn the fat presently, and then take as much as thy soul desireth; then he would answer him, Nay; but thou shalt give it to me now: and if not, I will take it by force.
<G-vec00721-002-s066><burn.anzünden><de> 16 Wenn dann jemand zu ihm sagte: Laß erst das Fett anzünden und nimm darnach, was dein Herz begehrt, so sprach er zu ihm: Du sollst mir's jetzt geben; wo nicht so will ich's mit Gewalt nehmen.
<G-vec00721-002-s067><burn.anzünden><en> And the priest shall offer the whole, and burn it upon the altar: it is a burnt-offering, an offering made by fire, of a sweet savor unto Jehovah.
<G-vec00721-002-s067><burn.anzünden><de> 13 Aber das Eingeweide und die Schenkel soll man mit Wasser waschen, und der Priester soll es alles opfern und anzünden auf dem Altar zum Brandopfer.
<G-vec00721-002-s068><burn.anzünden><en> So the Light of Israel will be for a fire, And his Holy One for a flame; It will burn and devour His thorns and his briers in one day.
<G-vec00721-002-s068><burn.anzünden><de> 17 Und das Licht Israels wird ein Feuer sein, und sein Heiliger wird eine Flamme sein, und sie wird seine Dornen und Hecken anzünden und verzehren auf einen Tag.
<G-vec00721-002-s069><burn.anzünden><en> 4 1 “For, behold, the day comes, it burns as a furnace; and all the proud, and all who work wickedness, will be stubble; and the day that comes will burn them up,” says the LORD of Hosts, “that it shall leave them neither root nor branch.
<G-vec00721-002-s069><burn.anzünden><de> Maleachi 4 Maleachi 4 1Denn siehe, es kommt ein Tag, der brennen soll wie ein Ofen; da werden alle Verächter und Gottlosen Stroh sein, und der künftige Tag wird sie anzünden, spricht der HERR Zebaoth, und wird ihnen weder Wurzel noch Zweige lassen.
<G-vec00721-002-s070><burn.anzünden><en> 26 And he shall burn all its fat on the altar, like the fat of the sacrifice of the peace offering.
<G-vec00721-002-s070><burn.anzünden><de> 26 Aber alles sein Fett soll er auf dem Altar anzünden gleich wie das Fett des Dankopfers.
<G-vec00721-002-s071><burn.anzünden><en> 1:9 but its innards and its legs he shall wash with water. The priest shall burn the whole on the altar, for a burnt offering, an offering made by fire, of a pleasant aroma to Yahweh.
<G-vec00721-002-s071><burn.anzünden><de> 1:9 Das Eingeweide aber und die Schenkel soll man mit Wasser waschen, und der Priester soll das alles anzünden auf dem Altar zum Brandopfer.
<G-vec00721-002-s072><burn.anzünden><en> And if the man said unto him, They will surely burn the fat first, and then take as much as thy soul desireth; then he would say, Nay, but thou shalt give it me now: and if not, I will take it by force.
<G-vec00721-002-s072><burn.anzünden><de> Wenn dann jemand zu ihm sagte: Laß erst das Fett anzünden und nimm darnach, was dein Herz begehrt, so sprach er zu ihm: Du sollst mir's jetzt geben; wo nicht so will ich's mit Gewalt nehmen.
<G-vec00721-002-s082><burn.ausbrennen><en> Mixing will cause no heat, or burn out.
<G-vec00721-002-s082><burn.ausbrennen><de> Das Mischen verursacht keine Hitze oder Ausbrennen.
<G-vec00721-002-s083><burn.ausbrennen><en> After disinfection with a solution of potassium permanganate, it is necessary to sustain the ground for 2-3 days without planting so that the seeds do not burn out.
<G-vec00721-002-s083><burn.ausbrennen><de> Nach der Desinfektion mit einer Lösung von Kaliumpermanganat ist es notwendig, den Boden 2-3 Tage ohne Einpflanzen zu erhalten, damit die Samen nicht ausbrennen.
<G-vec00721-002-s084><burn.ausbrennen><en> Otherwise, however good your intentions, you can easily burn out and lose your connection to your heart.
<G-vec00721-002-s084><burn.ausbrennen><de> Ansonsten kannst du leicht ausbrennen und die Verbindung zu deinem Herzen verlieren, wie gut deine Absichten auch sein mögen.
<G-vec00721-002-s085><burn.ausbrennen><en> Obtaining world vision and experience is a prerequisite for preventing burn out, not putting the child into a hamster wheel or narrowing down the mindset.
<G-vec00721-002-s085><burn.ausbrennen><de> Der Erhalt der Weltsicht und -erfahrung ist eine Voraussetzung dafür, dass ein Ausbrennen verhindert wird, dass das Kind nicht in ein Hamsterrad gesteckt wird oder die Denkweise eingeschränkt wird.
<G-vec00721-002-s086><burn.ausbrennen><en> This includes checking the lighting (the lamps can burn out over time), the work of the air filter and compressor, temperature indicators and other things. - Checking the water quality.
<G-vec00721-002-s086><burn.ausbrennen><de> Dazu gehören das Überprüfen der Beleuchtung (die Lampen können im Laufe der Zeit ausbrennen), die Arbeit des Luftfilters und des Kompressors, Temperaturanzeigen und andere Dinge - Überprüfen der Wasserqualität.
<G-vec00721-002-s087><burn.ausbrennen><en> This is set by listing the number of hours it takes for 50 percent of a sample of identical products to burn out.
<G-vec00721-002-s087><burn.ausbrennen><de> Dies wird durch Auflisten der Anzahl von Stunden festgelegt, die zum Ausbrennen von 50 Prozent einer Probe identischer Produkte erforderlich sind.
<G-vec00721-002-s088><burn.ausbrennen><en> It burns easily, but it can burn out just as easily.
<G-vec00721-002-s088><burn.ausbrennen><de> Es brennt leicht, aber es kann genauso leicht ausbrennen.
<G-vec00721-002-s089><burn.ausbrennen><en> As used herein, the expression "crystalline ceramic oxide binder precursor material" refers to particulate additives which, when heated to a temperature sufficient to burn out organic materials present in the precursor agglomerate abrasive grain, may subsequently bond together to form a rigid ceramic oxide phase bonding the abrasive particles together and to provide a precursor agglomerate abrasive grain. abrasive grain" includes where the crystalline ceramic oxide binder precursor material has not yet bonded together sufficiently to provide precursor agglomerate abrasive grain that is handleable and collectable.
<G-vec00721-002-s089><burn.ausbrennen><de> Wie hier verwendet, ist der Begriff Wie hier verwendet, betrifft der Ausdruck „anorganischer Bindemittelvorläufer" teilchenförmige Additive, welche, wenn sie auf eine Temperatur erwärmt werden, die zum Ausbrennen von in dem Agglomeratteilchen vorliegenden organischen Materialien ausreicht, anschließend miteinander verschmelzen können, um eine starre anorganische Phase zu bilden, die die Agglomeratteilchen aneinander bindet.
<G-vec00721-002-s090><burn.ausbrennen><en> No worry about led burn out, compared with the traditional red and blue lights, our growing lamps lumen/PAR was increased 3 times.
<G-vec00721-002-s090><burn.ausbrennen><de> Keine Sorge vor dem Ausbrennen von LEDs, im Vergleich zu den traditionellen roten und blauen Lichtern wurde unser wachsendes Lampenlumen / PAR dreimal erhöht.
<G-vec00721-002-s091><burn.ausbrennen><en> Love is a truly fickle emotion that can burn out just as quickly and suddenly as it was originally ignited.
<G-vec00721-002-s091><burn.ausbrennen><de> Die Liebe ist eine Emotion, die wirklich launisch ausbrennen kann genauso schnell und plötzlich, wie sie ursprünglich war gezündet.
<G-vec00721-002-s092><burn.ausbrennen><en> This technique is used so that the curtains do not burn out from the sun, and their folds keep the shape well.
<G-vec00721-002-s092><burn.ausbrennen><de> Diese Technik wird verwendet, damit die Vorhänge nicht von der Sonne ausbrennen und ihre Falten die Form gut behalten.
<G-vec00721-002-s093><burn.ausbrennen><en> One example is David Brainerd, a missionary to the American Indians whose desire was "to burn out in one continual flame for God." He had a brief three-year ministry, during which hundreds of American Indians were converted.
<G-vec00721-002-s093><burn.ausbrennen><de> Ein Beispiel ist David Brainerd, ein Missionar unter den amerikanischen Indianern, dessen Verlangen es war, „in einer fortwährenden Flamme für Gott auszubrennen.“ Er führte einen kurzen, dreijährigen Dienst, währenddessen Hunderte amerikanischer Indianer bekehrt wurden.
<G-vec00721-002-s094><burn.ausbrennen><en> These items are inadequate and costly and it will just burn out your funds.
<G-vec00721-002-s094><burn.ausbrennen><de> Diese Produkte sind ineffizient und teuer, und es wird nur Ihre Finanzen auszubrennen.
<G-vec00721-002-s097><burn.ausbrennen><en> A long-term external short-circuit will generally cause the weak points in the circuit to burn out, and rarely cause thermal runaway events in the battery.
<G-vec00721-002-s097><burn.ausbrennen><de> Ein langfristiger externer Kurzschluss veranlaßt im Allgemeinen die Schwachpunkte im Stromkreis auszubrennen und verursacht selten thermische Durchgehenereignisse in der Batterie.
<G-vec00721-002-s098><burn.ausbrennen><en> Kinda hard to juggle everything between real life stuff, and the project(s) they are working on, and people tend to ‚burn out‘ sometimes.
<G-vec00721-002-s098><burn.ausbrennen><de> Es ist schwierig das echte Leben und die bearbeiteten Projekte unter einen Hut zu bringen und hin und wieder neigen Leute dazu „auszubrennen“.
<G-vec00721-002-s101><burn.ausbrennen><en> If we get up and sit in meditation, contemplate unattractiveness (asubha) or the elements (dhatu) so as to see the unsatisfactoriness inherent in the body and mind, point out and reveal these things to our intoxicated, indulgent mind; then we will be able to put forth effort to burn up the defilements of ignorance and delusion.
<G-vec00721-002-s101><burn.ausbrennen><de> Wenn wir aufstehen und in Meditation sitzen, das Unschöne (asubha) besinnen, oder die Elemente (dhatu), um die Unzulänglichkeit, die Körper und Geist innewohnt, zu sehen, diese Dinge aufzeigen und offenlegen vor unserem berauschten und leichtsinnigen Geist; dann werden wir fähig sein, Anstrengung aufzubringen, um die Befleckungen von Unwissenheit und Verblendung auszubrennen.
<G-vec00721-002-s102><burn.ausbrennen><en> And the back and forth threatens to burn out the audience in very much the same way as the maltreated Enterprise.
<G-vec00721-002-s102><burn.ausbrennen><de> Und das viele Hin und Her droht das Publikum ähnlich auszubrennen wie die geschundene Enterprise selbst.
<G-vec00721-002-s143><burn.brennen><en> In the small hours of that sleepless night, I burn the tip of a pair of scissors and disinfect them with alcohol, and I cut my skin to open my mouth and to phone for help.
<G-vec00721-002-s143><burn.brennen><de> In den frühen Morgenstunden in dieser Nacht, ich brenne die Spitze einer Schere und desinfiziere sie anschließend mit Alkohol um die Haut einzuschneiden, den Mund zu öffnen und zu telefonieren...
<G-vec00721-002-s144><burn.brennen><en> Assume the role of one of five heroes, and hack, slash, smash, burn and pierce the vile Skaven using a multitude of weapons.
<G-vec00721-002-s144><burn.brennen><de> Entscheide dich für einen von fünf Außenseiterhelden und dann hacke, schlitze, brenne und schmettere dir mit einer Vielzahl von Waffen und Power-ups deinen Weg durch die Armee der Rattenmenschen.
<G-vec00721-002-s145><burn.brennen><en> House of David, thus saith Jehovah: Judge with justice in the morning, and deliver him that is spoiled out of the hand of the oppressor, lest my fury go forth like fire and burn, and there be none to quench it, because of the evil of your doings.
<G-vec00721-002-s145><burn.brennen><de> Du Haus David, so spricht der Herr: Haltet des Morgens Gericht und errettet die Beraubten aus des Frevlers Hand, auf daß mein Grimm nicht ausfahre wie ein Feuer und brenne also, das niemand löschen könne, um eures bösen Wesens willen.
<G-vec00721-002-s146><burn.brennen><en> Always burn incense in a well-ventilated area away from pets and children.
<G-vec00721-002-s146><burn.brennen><de> Brenne Räucherstäbchen nur in gut belüfteten Räumen fern von Haustieren und Kindern ab.
<G-vec00721-002-s147><burn.brennen><en> Now you write your wish back on a piece of paper (in the end I would like to add: smoothly, full of joy and lightness so that it is really easy) and then burn off the candle.
<G-vec00721-002-s147><burn.brennen><de> Nun schreibst Du deinen Wunsch wieder auf einen Zettel (ich würde am Ende noch möglichst: reibungslos, voller Freude und Leichtigkeit hinzufügen damit es auch wirklich leicht geht) und dann brenne die Kerze ab.
<G-vec00721-002-s148><burn.brennen><en> I've been wating day and night, I burn for you.
<G-vec00721-002-s148><burn.brennen><de> Ich habe Tag und Nacht geweint, ich brenne für dich.
<G-vec00721-002-s149><burn.brennen><en> I'm getting a great workout and burn tons of calories.
<G-vec00721-002-s149><burn.brennen><de> Ich bekomme ein großes Training und brenne ich eine Tonne Kalorien.
<G-vec00721-002-s150><burn.brennen><en> Now let's see how to burn files to a CD-R or any other blank optical media.
<G-vec00721-002-s150><burn.brennen><de> Nun wollen wir sehen, wie brenne ich Dateien auf eine CD-R oder jede andere leere optische Medien.
<G-vec00721-002-s151><burn.brennen><en> Rip your music CDs or burn your files onto DVDs.
<G-vec00721-002-s151><burn.brennen><de> Rippe deine Musik-CDs oder brenne deine Daten auf DVDs.
<G-vec00721-002-s152><burn.brennen><en> But of the better, obligatory variety.”11 In Graz, Overdieck-Deutschbein probably worked alone. She reported: “I burn about every 4 weeks, because I have about 3 hours a day for pottery, according to household and garden (responsibilities).”12 The products from these years correspond to a general pottery workshop standard and appear rather inconspicuous.
<G-vec00721-002-s152><burn.brennen><de> Aber einen von der besseren, der verpflichtenden Sorte.“10 In Graz arbeitete Eva Overdieck-Deutschbein vermutlich allein, denn sie berichtet: „Ich brenne etwa alle 4 Wochen, weil ich am Tag etwa 3 Stunden Zeit für Toepferei habe, nach Haushalt und Garten.“11 Die Produkte aus diesen Jahren entsprechen einem allgemeinen Töpferwerkstattstandard und erscheinen eher unauffällig.
<G-vec00721-002-s153><burn.brennen><en> To install openSUSE Tumbleweed download the latest Tumbleweed ISO below, verify the download, burn it on a DVD or write it to a USB stick with ImageWriter and launch the installation from there after a reboot.
<G-vec00721-002-s153><burn.brennen><de> Lade dir eines der ISO-Abbilder der Liste unten herunter, verifiziere den Download, brenne es auf eine DVD oder schreibe es mit ImageWriter auf einen USB-Stick, und starte die Installation nach einem Neustart von dort.
<G-vec00721-002-s154><burn.brennen><en> 4 Circumcise yourselves to the Lord, and take away the foreskins of your heart, you men of Judah and inhabitants of Jerusalem; lest my wrath go forth like fire, and burn so that none can quench it, because of the evil of your doings.
<G-vec00721-002-s154><burn.brennen><de> 4 Beschneidet euch dem HERRN und tut weg die Vorhaut eures Herzens, ihr Männer in Juda und ihr Leute zu Jerusalem, auf daß nicht mein Grimm ausfahre wie Feuer und brenne, daß niemand löschen könne, um eurer Bosheit willen.
<G-vec00721-002-s155><burn.brennen><en> so my heart may always burn with your love.
<G-vec00721-002-s155><burn.brennen><de> Dass stets mein Herz von deiner Liebe brenne.
<G-vec00721-002-s156><burn.brennen><en> 21:12 House of David, thus saith Jehovah: Judge with justice in the morning, and deliver him that is spoiled out of the hand of the oppressor, lest my fury go forth like fire and burn, and there be none to quench it, because of the evil of your doings.
<G-vec00721-002-s156><burn.brennen><de> 21:12 Du Haus David, so spricht der HERR: Haltet des Morgens Gericht und errettet den Beraubten aus des Frevlers Hand, auf daß mein Grimm nicht ausfahre wie ein Feuer und brenne also, daß niemand löschen möge, um eures bösen Wesens willen.
<G-vec00721-002-s157><burn.brennen><en> Don't just burn the ISO file to the DVD by dragging and dropping it into the DVD and then burning it, as doing so will likely not yield a working disc.
<G-vec00721-002-s157><burn.brennen><de> Brenne die ISO-Datei nicht einfach auf die DVD, indem du sie per Drag & Drop auf die DVD ziehst und dann brennst, da dies vermutlich nicht zu einer funktionierenden Disk führt.
<G-vec00721-002-s158><burn.brennen><en> Print some t-shirts, burn some mixtapes and make other merchandise to sell at your shows.
<G-vec00721-002-s158><burn.brennen><de> Bedrucke T-Shirts, brenne einige Mix-Alben und mache andere Produkte, die du bei deinen Konzerten verkaufen kannst.
<G-vec00721-002-s159><burn.brennen><en> - Nero AirBurn: Burn files straight from your Android & iOS device
<G-vec00721-002-s159><burn.brennen><de> Nero AirBurn: brenne Dateien direkt von Deinem Android & iOS Gerät.
<G-vec00721-002-s160><burn.brennen><en> I refer to those verses that deal with the salt of the earth, the city on a hill and the lighted candle that should be allowed to shine and not burn hidden under a bushel.
<G-vec00721-002-s160><burn.brennen><de> Es sind jene Verse, die vom Salz der Erde, von der Stadt auf dem Berg und von dem angezündeten Licht handeln, damit es leuchte und nicht verborgen unter einem Scheffel brenne.
<G-vec00721-002-s161><burn.brennen><en> Then I burn inwardly with desire and have to control myself very well that I do not lay hands on myself - which is nevertheless often enough the case.
<G-vec00721-002-s161><burn.brennen><de> Dann brenne ich innerlich vor Begierde und muss mich schon sehr beherrschen, dass ich nicht Hand an mich selbst lege - was dennoch oft genug der Fall ist.
<G-vec00721-002-s162><burn.brennen><en> It provides 5 burning modes, namely Full Disc, Main Movie, Customize, Merge and Clone/Burn, which can fulfill your various burning needs.
<G-vec00721-002-s162><burn.brennen><de> Es bietet 5 Brennmodi, namens Komplett, Hauptfilm, Anpassen, Zusammenfügen und Klonen/Brennen an.
<G-vec00721-002-s163><burn.brennen><en> All you need to do is to burn your playlist with iTunes to TuneClone's virtual CD Burner, and TuneClone will convert music files in the playlist to MP3, WMA or WAV files automatically. TuneClone Features
<G-vec00721-002-s163><burn.brennen><de> Was Sie machen brauchen, ist nur, Ihre Playliste mit Ihrer Media Player Software auf dem TuneClone´s virtuellen CD Brenner zu brennen, und TuneClone wird Musikfiles in der Playliste in MP3, unbeschützten WMA- oder WAV-Files automatisch konvertieren.
<G-vec00721-002-s164><burn.brennen><en> Users can burn their video files into DVD easily with iSkysoft Video Converter Ultimate.
<G-vec00721-002-s164><burn.brennen><de> Man kann seine Videodateien mit iSkysoft Video Converter Ultimate ganz einfach auf DVD brennen.
<G-vec00721-002-s165><burn.brennen><en> 15. To see the world burn.
<G-vec00721-002-s165><burn.brennen><de> 15.... um die Welt brennen zu sehen.
<G-vec00721-002-s166><burn.brennen><en> Choose a drive from the Burn drive drop-down list to specify the drive you want to use to burn your Video CD.
<G-vec00721-002-s166><burn.brennen><de> Wählen Sie in der Dropdownliste Brenner das Laufwerk aus, das Sie zum Brennen der Video-CD verwenden möchten.
<G-vec00721-002-s167><burn.brennen><en> So not only does this drug help to build muscle, it can help to burn fat.
<G-vec00721-002-s167><burn.brennen><de> Errichtet diese Drogenhilfe so nicht nur Muskel, es kann helfen, Fett zu brennen.
<G-vec00721-002-s168><burn.brennen><en> Get the award-winning tools every organization needs to create, edit, back-up, protect, burn and share digital media. For Windows
<G-vec00721-002-s168><burn.brennen><de> Diese Lösung beinhaltet prämierte Werkzeuge, um digitale Medien zu erstellen, zu bearbeiten, zu sichern, zu schützen, zu brennen und zu teilen, die jedes Unternehmen haben sollte.
<G-vec00721-002-s170><burn.brennen><en> Even under high temperatures, the needles do not burn, but collapsed.
<G-vec00721-002-s170><burn.brennen><de> Selbst bei hohen Temperaturen brennen die Nadeln nicht, sondern kollabieren.
<G-vec00721-002-s171><burn.brennen><en> Just drag and drop music files from Windows Explorer or add them manually and hit "Burn".
<G-vec00721-002-s171><burn.brennen><de> Ziehen Sie bloß Musikdateien von Windows Explorer oder fügen Sie die Dateien manuell hinzu und klicken Sie "Brennen".
<G-vec00721-002-s172><burn.brennen><en> When you make a photo gallery disc, you create a disc that showcases your photos, or you can burn secured data discs with up to 256-bit encryption.
<G-vec00721-002-s172><burn.brennen><de> Sie können eine Fotogaleriedisc erzeugen, die all Ihre Fotos präsentiert oder Sicherheitsdatendiscs mit bis zu 256-bit Verschlüsselung brennen.
<G-vec00721-002-s173><burn.brennen><en> Burn Audio to CD: It allows creating CD from different audio file formats and video file
<G-vec00721-002-s173><burn.brennen><de> Audio auf CD brennen: Damit kann man CDs aus verschiedenen Audio- und Videodateien erstellen.
<G-vec00721-002-s174><burn.brennen><en> You can directly burn your WAV, MP3, OGG or WMA files to audio CD.
<G-vec00721-002-s174><burn.brennen><de> Sie können direkt Ihre WAV, MP3, OGG oder WMA-Dateien auf audio-CD brennen.
<G-vec00721-002-s175><burn.brennen><en> Burn the downloaded songs to CDs or make a car-playlist with all of them.
<G-vec00721-002-s175><burn.brennen><de> Brennen Sie die heruntergeladenen Songs auf CDs oder erstellen Sie eine Auto-Playlist aus ihnen.
<G-vec00721-002-s176><burn.brennen><en> This 510 dual coil version cartomizer produces great amounts of vapor due to the greater heating area of the dual coils, but have less potential to burn due to the higher individual resistance of each coil.
<G-vec00721-002-s176><burn.brennen><de> Diese 510 Dual Coil-Version Cartomizer produziert große Mengen von Dampf durch die größere Heizfläche des dualen Spulen, aber haben weniger Potenzial, aufgrund der höheren individuellen Widerstand jeder Spule zu brennen.
<G-vec00721-002-s177><burn.brennen><en> Here you can find VOB converter apps and learn how to burn VOB to DVD, convert VOB to AVI, VOB to DivX, VOB to MP4, VOB to FLV, VOB to iPod and other formats.
<G-vec00721-002-s177><burn.brennen><de> Hier können Sie VOB Konverter-Anwendungen finden und erfahren, wie man VOB auf eine DVD brennen, VOB in AVI, VOB in DivX, VOB in MP4, VOB in FLV, VOB in iPod und zu anderen Formaten umwandeln kann.
<G-vec00721-002-s178><burn.brennen><en> "Boggess was a monster, he shall burn in hell" and similar remarks from death penalty supporters against those who recognised that the death penalty brings no profit, and one who changed therefore his opinion because of the film.
<G-vec00721-002-s178><burn.brennen><de> Von: "Boggess war ein Monster, er soll in der Hölle brennen", über sachlich differenzierte Äußerungen pro und contra, bis zu Todesstrafe-Befürwortern, die aufgrund des Films für sich erkannten, dass die Todesstrafe keinerlei Gewinn bringt, und demzufolge ihre Meinung änderten, reicht die Palette.
<G-vec00721-002-s179><burn.brennen><en> Right click the playlist and choose "Burn Playlist to Disc".
<G-vec00721-002-s179><burn.brennen><de> Dann wählen Sie die Wiedergabeliste, die Sie in iTunes brennen möchten, und rechts klicken Sie die Wiedergabeliste.
<G-vec00721-002-s180><burn.brennen><en> Burn audio CDs for playback on a computer, in the car or on a stereo system with conversion of many formats.
<G-vec00721-002-s180><burn.brennen><de> Brennen Sie Audio-CDs zur Wiedergabe auf einem Computer, im Auto oder auf einer Stereoanlage mit Konvertierung in viele Formate.
<G-vec00721-002-s181><burn.brennen><en> If this is not the case or if it is a cloudy day, the lamp will not charge enough and it may burn less bright or the battery may run out faster.
<G-vec00721-002-s181><burn.brennen><de> Wenn dies nicht der Fall ist oder wenn es an einem bewölkten Tag ist, lädt sich die Lampe nicht ausreichend auf und brennt möglicherweise weniger hell oder der Akku kann schneller entladen werden.
<G-vec00721-002-s182><burn.brennen><en> Ligandrol itself doesn't burn fat, however it can be used to preserve muscle.
<G-vec00721-002-s182><burn.brennen><de> Ligandrol selbst brennt nicht Fett, gleichwohl es benutzt werden kann, um Muskel zu konservieren.
<G-vec00721-002-s183><burn.brennen><en> You burn out from going too slow and getting bored.")
<G-vec00721-002-s183><burn.brennen><de> Man brennt aus, wenn man zu langsam lebt und sich langweilt.
<G-vec00721-002-s184><burn.brennen><en> The cylinder head gasket can easily burn in hot weather if there’s a lack of coolant.
<G-vec00721-002-s184><burn.brennen><de> Bei fehlender Kühlflüssigkeit und Hitze brennt gerne mal die Zylinderkopfdichtung durch.
<G-vec00721-002-s185><burn.brennen><en> In addition, the white to yellowish coconut oil works perfectly for roasting, baking and stewing almost all dishes. It does not burn or smoke until just below 200 degrees Celsius.
<G-vec00721-002-s185><burn.brennen><de> Außerdem funktioniert das weiße bis gelbliche Kokosfett perfekt zum Braten, Backen und Dünsten von fast allen Gerichten: Es spritzt nicht, brennt nicht an und raucht erst bei knapp unter 200 Grad Celsius.
<G-vec00721-002-s186><burn.brennen><en> Burn videos to DVD (DVD disc, DVD folder, DVD IFO file, ISO).
<G-vec00721-002-s186><burn.brennen><de> Brennt Videos auf DVD (DVD Disk, DVD Ordner, DVD IFO Datei, ISO).
<G-vec00721-002-s187><burn.brennen><en> The ceramic filter does not burn, fracture, or deteriorate.
<G-vec00721-002-s187><burn.brennen><de> Der Keramik-Filter brennt, bricht oder verschlechtert sich nicht.
<G-vec00721-002-s188><burn.brennen><en> Extra DVD Creator allows you to specify NTSC or PAL, adjust 4:3 or 16:9 video aspect, set actions, and either burn to a DVD movie disk or DVD folder.
<G-vec00721-002-s188><burn.brennen><de> Extra DVD Creator ermöglicht es dir darüber hinaus, zwischen NTSC oder PAL zu wählen, ein 4:3 oder 16:9 Video-Format einzustellen und brennt entweder auf eine DVD oder in ein DVD-Verzeichnis.
<G-vec00721-002-s189><burn.brennen><en> When you burn for something, you can make a difference.
<G-vec00721-002-s189><burn.brennen><de> Wenn man für etwas brennt, dann kann man so einiges bewegen.
<G-vec00721-002-s190><burn.brennen><en> “But, behold, I say unto you, that you must study it out in your mind; then you must ask me if it be right, and if it is right I will cause that your bosom shall burn within you; therefore, you shall feel that it is right.
<G-vec00721-002-s190><burn.brennen><de> Aber siehe, ich sage dir: Du musst es mit deinem Verstand durcharbeiten; dann musst du mich fragen, ob es recht ist, und wenn es recht ist, werde ich machen, dass dein Herz in dir brennt; darum wirst du fühlen, dass es recht ist.
<G-vec00721-002-s191><burn.brennen><en> If performed correctly, meaning intensely enough, you'll feel that muscle "burn," which is a sign of lactic acid being released.
<G-vec00721-002-s191><burn.brennen><de> Wenn sie korrekt durchgeführt werden, also intensiv genug, dann fühlen Sie, dass dieser Muskel „brennt“, was ein Zeichen dafür ist, das Milchsäure freigegeben wird.
<G-vec00721-002-s192><burn.brennen><en> The shaving foam contains 0% alcohol and does not burn.
<G-vec00721-002-s192><burn.brennen><de> Die Haut brennt nicht, sondern ist beruhigt und geschützt.
<G-vec00721-002-s193><burn.brennen><en> And since the tobacco does not burn, the levels of harmful chemicals are significantly reduced.
<G-vec00721-002-s193><burn.brennen><de> Und da der Tabak nicht brennt, werden die Niveaus von schädlichen Chemikalien erheblich verringert.
<G-vec00721-002-s194><burn.brennen><en> Burn MP4 or any video files to DVD.
<G-vec00721-002-s194><burn.brennen><de> Brennt MP4 oder jede andere Videodatei auf DVD.
<G-vec00721-002-s195><burn.brennen><en> Ashampoo Burning Studio 20 does more than just burn data.
<G-vec00721-002-s195><burn.brennen><de> Das Ashampoo Burning Studio 20 brennt nicht einfach nur.
<G-vec00721-002-s196><burn.brennen><en> The more sunlight falls onto the solar cell, the brighter the bulb would burn.
<G-vec00721-002-s196><burn.brennen><de> Je mehr Sonnenlicht auf die Solarzelle fällt, desto heller brennt die Birne.
<G-vec00721-002-s197><burn.brennen><en> A mere 25mcg of Cytomel will burn a ton of fat; thats one tablet per day but your body will adapt quickly.
<G-vec00721-002-s197><burn.brennen><de> Ein bloßes 25mcg von Cytomel brennt eine Tonne Fett; die ist eine Tablette pro Tag, aber Ihr Körper passt sich schnell an.
<G-vec00721-002-s198><burn.brennen><en> A fire will continue to burn until actively extinguished or until the combustibles or oxygen is exhausted.
<G-vec00721-002-s198><burn.brennen><de> Ein Feuer brennt, solange es nicht aktiv gelöscht wird oder bis die Brennstoffe oder der Sauerstoff erschöpft sind.
<G-vec00721-002-s199><burn.brennen><en> So, the fuel will burn in the direction from top to bottom.
<G-vec00721-002-s199><burn.brennen><de> Und das bedeutet, der Brennstoff brennt in der Richtung von oben nach unten.
<G-vec00721-002-s290><burn.räuchern><en> 15 H3548 And the priest H7126 shall bring H4196 it unto the altar, H4454 and wring off H7218 its head, H6999 and burn H4196 it on the altar; H1818 and the blood H4680 thereof shall be drained out H7023 on the side H4196 of the altar;
<G-vec00721-002-s290><burn.räuchern><de> 15 H3548 Und der Priester H7126 bringe sie H4196 zum Altar H7218 und kneipe ihr den Kopf H6999 ein und räuchere H4196 sie auf dem Altar H1818, und ihr Blut H7023 soll ausgedrückt werden an die Wand H4196 des Altars .
<G-vec00721-002-s291><burn.räuchern><en> 2 (UKJV) "And he shall bring it to Aaron's sons the priests: and he shall take from it his handful of the flour thereof, and of the oil thereof, with all the frankincense thereof; and the priest shall burn the memorial of it upon the altar, to be an offering made by fire, of a sweet savour unto the LORD: "
<G-vec00721-002-s291><burn.räuchern><de> 2 (ELB) Und er soll es zu den Söhnen Aarons, den Priestern, bringen; und er nehme davon seine Hand voll, von seinem Feinmehl und von seinem Öl samt all seinem Weihrauch, und der Priester räuchere das Gedächtnisteil desselben auf dem Altar: es ist ein Feueropfer lieblichen Geruchs dem Jehova.
<G-vec00721-002-s292><burn.räuchern><en> 15 And the priest shall bring it to the altar, and wring off its head, and burn it on the altar. And the blood of it shall be drained out on the side of the altar.
<G-vec00721-002-s292><burn.räuchern><de> 15 Und der Priester bringe sie zum Altar und kneipe ihr den Kopf ein und räuchere sie auf dem Altar, und ihr Blut soll ausgedrückt werden an die Wand des Altars.
<G-vec00721-002-s294><burn.räuchern><en> Leviticus 1:15 And the priest shall bring it to the altar, and wring off its head, and burn it on the altar; and its blood shall be wrung out at the side of the altar:
<G-vec00721-002-s294><burn.räuchern><de> Leviticus 1:15 Und der Priester bringe sie zum Altar und kneipe ihr den Kopf ein und räuchere sie auf dem Altar, und ihr Blut soll ausgedrückt werden an die Wand des Altars .
<G-vec00721-002-s295><burn.räuchern><en> 12He shall bring it to the priest, and the priest shall take his handful of it as the memorial portion, and burn it on the altar, on the offerings of Yahweh made by fire. It is a sin offering.
<G-vec00721-002-s295><burn.räuchern><de> 12Und er soll es zu dem Priester bringen; und der Priester nehme davon seine Hand voll, das Gedächtnisteil desselben, und räuchere es auf dem Altar, auf den Feueropfern Jehovas: es ist ein Sündopfer.
<G-vec00721-002-s296><burn.räuchern><en> 15And the priest shall bring it unto the altar, and wring off his head, and burn it on the altar; and the blood thereof shall be wrung out at the side of the altar:#wring…: or, pinch off the head with the nail
<G-vec00721-002-s296><burn.räuchern><de> 15Und der Priester bringe sie zum Altar und kneipe ihr den Kopf ein und räuchere sie auf dem Altar, und ihr Blut soll ausgedrückt werden an die Wand des Altars.
<G-vec00721-002-s297><burn.räuchern><en> 25 Then the priest shall take the jealousy offering out of the woman's hand, and shall wave the offering before the LORD, and offer it upon the altar: 26 And the priest shall take an handful of the offering, even the memorial thereof, and burn it upon the altar, and afterward shall cause the woman to drink the water.
<G-vec00721-002-s297><burn.räuchern><de> 5,25 Und der Priester nehme aus der Hand der Frau das Speisopfer der Eifersucht und schwinge das Speisopfer vor dem HERRN und bringe es zum Altar; 5,26 und der Priester nehme eine Handvoll von dem Speisopfer als dessen Askara und räuchere es auf dem Altar; und danach soll er die Frau das Wasser trinken lassen.
<G-vec00721-002-s299><burn.räuchern><en> 5:25 And the priest shall take out of the woman's hand the oblation of jealousy, and shall wave the oblation before Jehovah, and shall present it at the altar. 5:26 And the priest shall take a handful of the oblation as a memorial thereof, and burn it upon the altar; and afterwards he shall make the woman drink the water.
<G-vec00721-002-s299><burn.räuchern><de> 25 Und der Priester nehme aus der Hand der Frau das Speisopfer der Eifersucht und schwinge das Speisopfer vor dem HERRN und bringe es zum Altar; 26 und der Priester nehme eine Handvoll von dem Speisopfer als dessen Askara und räuchere es auf dem Altar; und danach soll er die Frau das Wasser trinken lassen.
<G-vec00721-002-s300><burn.räuchern><en> 25Then the priest shall take the jealousy offering out of the woman's hand, and shall wave the offering before the Lord, and offer it upon the altar: 26And the priest shall take an handful of the offering, even the memorial thereof, and burn it upon the altar, and afterward shall cause the woman to drink the water.
<G-vec00721-002-s300><burn.räuchern><de> 25Und der Priester nehme aus der Hand des Weibes das Speisopfer der Eifersucht und webe das Speisopfer vor Jehova und bringe es zum Altar; 26und der Priester nehme eine Handvoll von dem Speisopfer als dessen Gedächtnisteil und räuchere es auf dem Altar; und danach soll er das Weib das Wasser trinken lassen.
<G-vec00721-002-s301><burn.räuchern><en> Lv 1, 15 And the priest shall bring it unto the altar, and wring off his head, and burn it on the altar; and the blood thereof shall be wrung out at the side of the altar:
<G-vec00721-002-s301><burn.räuchern><de> Lv 1, 15 Und der Priester bringe sie zum Altar und kneipe ihr den Kopf ein und räuchere sie auf dem Altar, und ihr Blut soll ausgedrückt werden an die Wand des Altars.
<G-vec00721-002-s302><burn.räuchern><en> 12: Then shall he bring it to the priest, and the priest shall take his handful of it, even a memorial thereof, and burn it on the altar, according to the offerings made by fire unto the LORD: it is a sin offering.
<G-vec00721-002-s302><burn.räuchern><de> 3Mo 5,12 Und er soll es zu dem Priester bringen; und der Priester nehme davon seine Hand voll, das Gedächtnisteil desselben, und räuchere es auf dem Altar, auf den Feueropfern Jehovas: es ist ein Sündopfer.
<G-vec00721-002-s303><burn.räuchern><en> 16 The priest shall burn as its memorial, part of its bruised grain, and part of its oil, along with all its frankincense: it is an offering made by fire to Yahweh.
<G-vec00721-002-s303><burn.räuchern><de> 16 Und der Priester soll das Gedächtnisteil desselben räuchern, von seinem Schrote und von seinem Öle, samt allem seinem Weihrauch: es ist ein Feueropfer dem Jahwe.
<G-vec00721-002-s304><burn.räuchern><en> 25 This is what the Commander of the armies of angels, the God whom we Israelis worship, says to you Israeli men: ‘You and your wives have said that you would continue to do what you promised, to burn incense and pour out wine to the goddess whom you call the Queen of Heaven.
<G-vec00721-002-s304><burn.räuchern><de> 25 So spricht der HERR Zebaoth, der Gott Israels: Ihr und eure Weiber habt mit einem Munde geredet und mit euren Händen vollbracht, was ihr sagt: Wir wollen unser Gelübde halten, die wir gelobt haben der Himmelskönigin, daß wir ihr räuchern und Trankopfer opfern.
<G-vec00721-002-s305><burn.räuchern><en> 7And Aaron shall burn thereon incense of sweet spices: every morning, when he dresseth the lamps, he shall burn it. 8And when Aaron lighteth the lamps at even, he shall burn it, a perpetual incense before Jehovah throughout your generations.
<G-vec00721-002-s305><burn.räuchern><de> 7Und Aaron soll wohlriechendes Räucherwerk auf ihm räuchern; Morgen für Morgen, wenn er die Lampen zurichtet, soll er es räuchern; 8und wenn Aaron die Lampen anzündet zwischen den zwei Abenden, soll er es räuchern: ein beständiges Räucherwerk vor Jehova bei euren Geschlechtern.
<G-vec00721-002-s307><burn.räuchern><en> But when he was strong, his heart was lifted up to his destruction: for he transgressed against the LORD his God, and went into the temple of the LORD to burn And Azariah the priest went in after him, and with him fourscore priests of the LORD, that were valiant men:
<G-vec00721-002-s307><burn.räuchern><de> 16 Und da er mächtig geworden war, überhob sich sein Herz zu seinem Verderben; denn er vergriff sich an dem HERRN, seinem Gott, und ging in den Tempel des HERRN, zu räuchern auf dem Räucheraltar.
<G-vec00721-002-s308><burn.räuchern><en> Leviticus 7:31 | The priest shall burn the fat on the altar, but the breast shall be for Aaron and his sons.
<G-vec00721-002-s308><burn.räuchern><de> 3.Mose/Levitikus 3:16 | Und der Priester soll es auf dem Altar räuchern: es ist eine Speise des Feueropfers zum lieblichen Geruch; alles Fett gehört Jehova.
<G-vec00721-002-s309><burn.räuchern><en> 15 And he shall take from it his handful of the flour of the meat offering, and of the oil thereof and all the frankincense which is upon the meat offering, and shall burn it upon the altar for a sweet savor, even the memorial of it unto the LORD.
<G-vec00721-002-s309><burn.räuchern><de> Und er soll davon seine Hand voll nehmen, vom Feinmehl des Speisopfers und von dessen Öl, und allen Weihrauch, der auf dem Speisopfer ist, und es auf dem Altar räuchern: es ist ein lieblicher Geruch, sein Gedächtnisteil für Jehova.
<G-vec00721-002-s310><burn.räuchern><en> 16:40 to be a memorial to the children of Israel, to the end that no stranger, who isn’t of the seed of Aaron, comes near to burn incense before Yahweh; that he not be as Korah, and as his company: as Yahweh spoke to him by Moses.
<G-vec00721-002-s310><burn.räuchern><de> 16:40 als ein Gedächtnis für die Kinder Israel, auf daß kein Fremder, der nicht vom Samen Aarons ist, herzunahe, um Räucherwerk vor Jehova zu räuchern, und es ihm nicht ergehe wie Korah und seiner Rotte, so wie Jehova durch Mose zu ihm geredet hatte.
<G-vec00721-002-s311><burn.räuchern><en> 16 But when he became strong, Uzziah's heart was so proud that his actions were sinful. He was not faithful to the Lord his God, for he went into the Lord's house to burn special perfume on the altar of special perfume.
<G-vec00721-002-s311><burn.räuchern><de> 16 Und als er mächtig geworden war, überhob sich sein Herz zu seinem Verderben; denn er verging sich gegen den HERRN, seinen Gott, und ging in den Tempel des HERRN, um auf dem Räucheraltar zu räuchern.
<G-vec00721-002-s312><burn.räuchern><en> 25 And he shall burn upon the altar the fat of the sin-offering.
<G-vec00721-002-s312><burn.räuchern><de> 25 Und das Fett des Sündopfers soll er auf dem Altar räuchern.
<G-vec00721-002-s313><burn.räuchern><en> 16 Lv 3, 16 And the priest shall burn them upon the altar: it is the food of the offering made by fire for a sweet savour: all the fat is the LORD's.
<G-vec00721-002-s313><burn.räuchern><de> 16 Lv 3, 16 Und der Priester soll es auf dem Altar räuchern: es ist eine Speise des Feueropfers zum lieblichen Geruch; alles Fett gehört Jehova.
<G-vec00721-002-s314><burn.räuchern><en> Who wants to burn incense, should pay attention to the perception of the images, thoughts and dreams during doing it.
<G-vec00721-002-s314><burn.räuchern><de> Wer mit dem Räuchern beginnen will, sollte dabei auf die Wahrnehmung innerer Bilder, Gedanken und Träume achten.
<G-vec00721-002-s315><burn.räuchern><en> 25 In every town in Judah he built high places to burn sacrifices to other gods and aroused the anger of the LORD, the God of his ancestors.
<G-vec00721-002-s315><burn.räuchern><de> Und in jeder einzelnen Stadt Judas machte er Höhen, um anderen Göttern zu räuchern, und er reizte den Herrn, den Gott seiner Väter, zum Zorn.
<G-vec00721-002-s316><burn.räuchern><en> And when Aaron lights the lamps in the evening, he shall burn incense upon it.
<G-vec00721-002-s316><burn.räuchern><de> Und auch wenn Aaron zur Abendzeit die Lampen zurichtet, soll er es räuchern.
<G-vec00721-002-s317><burn.räuchern><en> 17:6 And the priest shall sprinkle the blood upon the altar of the LORD at the door of the tabernacle of the congregation, and burn the fat for a sweet savor unto the LORD.
<G-vec00721-002-s317><burn.räuchern><de> 6 Und der Priester soll das Blut an den Altar Jahwes sprengen vor dem Eingang des Zeltes der Zusammenkunft und das Fett räuchern zum lieblichen Geruch dem Jahwe.
<G-vec00721-002-s318><burn.räuchern><en> 16 The priest shall burn them on the altar: it is the food of the offering made by fire, for a sweet savor; all the fat is Yahweh`s.
<G-vec00721-002-s318><burn.räuchern><de> 16 Und der Priester soll es auf dem Altar räuchern: es ist eine Speise des Feueropfers zum lieblichen Geruch; alles Fett gehört Jahwe.
<G-vec00721-002-s319><burn.schmelzen><en> Any steroid will certainly construct muscle mass and also burn fat.
<G-vec00721-002-s319><burn.schmelzen><de> Jede Steroid wird Muskeln aufbauen und auch Fett schmelzen.
<G-vec00721-002-s320><burn.schmelzen><en> Any type of supplements which contain these components will certainly trigger the thermogenic result which is specifically recognized for the ability to trigger fat and also burn the calories.
<G-vec00721-002-s320><burn.schmelzen><de> Alle Produkte, die diese Wirkstoffe enthalten, werden sicherlich die thermogene Wirkung auslösen, die bekannt ist, besonders für die Kapazität auf Fett zu drehen und schmelzen die Kalorien.
<G-vec00721-002-s321><burn.schmelzen><en> Synephrine enhances thermogenesis as well as allows your body to burn more fat and also do it much more efficiently, plus decrease your appetite at the very same time.
<G-vec00721-002-s321><burn.schmelzen><de> Synephrine erhöht die Thermogenese und erlaubt Ihrem Körper mehr Fett zu schmelzen und es viel effizienter machen, und den Hunger in der gleichen Zeit zu senken.
<G-vec00721-002-s322><burn.schmelzen><en> Bananas are likewise fantastic when you are attempting to burn fat and also construct muscle.
<G-vec00721-002-s322><burn.schmelzen><de> Bananen sind ebenfalls wunderbar, wenn Sie versuchen, Fett zu schmelzen und zu entwickeln Muskelgewebe.
<G-vec00721-002-s323><burn.schmelzen><en> Bananas are likewise excellent when you are trying to burn fat and also develop muscle mass.
<G-vec00721-002-s323><burn.schmelzen><de> Bananen sind ebenfalls wunderbar, wenn Sie versuchen, Fett zu schmelzen und Muskelmasse aufzubauen.
<G-vec00721-002-s324><burn.schmelzen><en> By improving thermogenesis your system has the ability to burn more fat.
<G-vec00721-002-s324><burn.schmelzen><de> Durch die Steigerung der Thermogenese Ihr System hat die Fähigkeit, mehr Fett zu schmelzen.
<G-vec00721-002-s325><burn.schmelzen><en> Anavar has a half-life of 8 to 9 hrs, so it is not difficult to burn through the steroid swiftly.
<G-vec00721-002-s325><burn.schmelzen><de> Anavar hat eine Halbwertszeit von 8 bis neun Stunden, so ist es einfach, schnell durch die Steroid zu schmelzen.
<G-vec00721-002-s326><burn.schmelzen><en> Synephrine increases thermogenesis and allows your body to burn more fat and also do it much more efficiently, plus minimize your cravings at the exact same time.
<G-vec00721-002-s326><burn.schmelzen><de> Synephrine erhöht die Thermogenese und ermöglicht es Ihrem Körper mehr Fett zu schmelzen und es viel effizienter machen, und Ihren Hunger in der gleichen Zeit zu verringern.
<G-vec00721-002-s327><burn.schmelzen><en> Anavar has a half-life of 8 to nine hrs, so it is easy to burn with the steroid swiftly.
<G-vec00721-002-s327><burn.schmelzen><de> Anavar hat eine Halbwertszeit von 8 bis 9 Stunden, so ist es nicht schwer, sich schnell über das Steroid zu schmelzen.
<G-vec00721-002-s328><burn.schmelzen><en> He started by dealing with a vast array of his own professional patients consisting of an appendectomy individual and burn patient.
<G-vec00721-002-s328><burn.schmelzen><de> Er begann mit der Behandlung einer breiten Palette von seinen ganz eigenen professionellen Patienten einschließlich einer Blinddarm Client und schmelzen Leidenden.
<G-vec00721-002-s329><burn.schmelzen><en> This launch of fats causes a thermogenic reaction, meaning you’ll burn also a lot more calories whilst keeping your lean body mass.
<G-vec00721-002-s329><burn.schmelzen><de> Diese Markteinführung von Fettsäuren führt zu einem thermogene Reaktion, was darauf hindeutet, Sie werden sogar mehr Kalorien schmelzen, während Ihre magere Körpermasse erhalten bleibt.
<G-vec00721-002-s330><burn.schmelzen><en> All the above constituents collaborate to burn fat, raise the metabolism, subdue appetite and also provide sustaining power while exercising.
<G-vec00721-002-s330><burn.schmelzen><de> Alle oben genannten Bestandteile arbeiten zusammen, um Fett zu schmelzen, verbessern den Stoffwechsel, den Appetit zu unterwerfen und geben auch erhaltende Kraft während des Trainings.
<G-vec00721-002-s331><burn.verbrennen><en> The ring around the activity display advances according to how many active calories you burn during the day compared to your goal. Table of Content
<G-vec00721-002-s331><burn.verbrennen><de> Der Ring rund um Ihr Aktivitätsdisplay schließt sich im Laufe des Tages immer weiter und zeigt dadurch an, wie viele aktive Kalorien Sie im Verhältnis zu Ihrem Ziel verbrannt haben.
<G-vec00721-002-s332><burn.verbrennen><en> Since more than 15 centuries people in Japan burn incense materials on different occasions.
<G-vec00721-002-s332><burn.verbrennen><de> Seit über 15 Jahrhunderten wird in Japan zu verschiedenen Gelegenheiten Räucherwerk verbrannt.
<G-vec00721-002-s334><burn.verbrennen><en> Cons: The garden totally burn by the sun.
<G-vec00721-002-s334><burn.verbrennen><de> Negativ:: Der Garten war total verbrannt von der Sonne.
<G-vec00721-002-s335><burn.verbrennen><en> Note that your wax should burn off in the kiln.
<G-vec00721-002-s335><burn.verbrennen><de> Beachte, dass das Abdeckwachs im Brennofen verbrannt sein sollte.
<G-vec00721-002-s336><burn.verbrennen><en> “You burn pieces of skin by putting them in a clay pot.
<G-vec00721-002-s336><burn.verbrennen><de> Die Haut der Elefanten wird in einem Tontopf verbrannt und die Asche wird mit Kokosöl gemischt.
<G-vec00721-002-s337><burn.verbrennen><en> The Chinese New Year is a time to light firecrackers, visit relatives, and burn faux paper money to one’s ancestors.
<G-vec00721-002-s337><burn.verbrennen><de> Beim chinesischen Neujahrsfest werden Feuerwerkskörper angezündet, Verwandte besucht und unechtes Papiergeld für die Vorfahren verbrannt.
<G-vec00721-002-s338><burn.verbrennen><en> Fat acid streams into the blood and will be burn by the muscles to gain more energy.
<G-vec00721-002-s338><burn.verbrennen><de> Fettsäuren strömen ins Blut und werden in der Muskulatur zur weiteren Energiegewinnung verbrannt.
<G-vec00721-002-s339><burn.verbrennen><en> There is evidence showing that Tabata training can burn as much as 15 calories per minute, or 400 calories in a half hour.
<G-vec00721-002-s339><burn.verbrennen><de> Beim Tabata-Training werden pro Minute circa 15 Kalorien verbrannt, das sind ungefähr 400 Kalorien in einer halben Stunde.
<G-vec00721-002-s340><burn.verbrennen><en> Particularly active abroad were, among others, Fritz Lang and Bertolt Brecht, who jointly made the movie “Hangmen Also Die” in the USA, Heinrich Mann who was elected honourary chairman of the “Schutzverband Deutscher Schriftsteller” (Union for the Protection of German Writers) and president of the “Deutsche Freiheitsbibliothek” (German Liberty Library), Oskar Maria Graf, who publicly protested against the omission of the nazis to ban and burn his books together with those of others (it was then done at the University of Munich), and Klaus Mann, who is famous in particular for his novel Mephisto, in which he describes the career of an ingenious actor (Gustav Gründgens) under the Nazis.
<G-vec00721-002-s340><burn.verbrennen><de> Besonders aktiv im Ausland waren unter anderem Fritz Lang und Bertolt Brecht, die in den USA gemeinsam den Film “Hangmen Also Die” drehten, Heinrich Mann, der schon in Paris zum Ehrenvorsitzenden des “Schutzverbandes Deutscher Schriftsteller” und zum Präsidenten der “Deutschen Freiheitsbibliothek” berufen wurde, Oskar Maria Graf, der öffentlich dagegen protestierte, dass seine Bücher nicht mit denen anderer verboten und verbrannt wurden (was dann in der Universität München nachgeholt wurde), und Klaus Mann, der besonders durch seinen auch verfilmten Roman Mephisto berühmt wurde, in dem die Karriere eines genialen Schauspielers (Gustaf Gründgens) unter den Nazis dargestellt wurde.
<G-vec00721-002-s341><burn.verbrennen><en> CATHERINE: I didn't burn you.
<G-vec00721-002-s341><burn.verbrennen><de> CATHERINE: Ich habe Sie nicht verbrannt.
<G-vec00721-002-s342><burn.verbrennen><en> When the ground it hard, you are going to burn more fuel.
<G-vec00721-002-s342><burn.verbrennen><de> Wenn der Boden hart ist, wird mehr Kraftstoff verbrannt.
<G-vec00721-002-s343><burn.verbrennen><en> Based on artificial data, you deforest one country with Agent Orange and burn it down with Napalm.
<G-vec00721-002-s343><burn.verbrennen><de> So wird basierend auf einem so entwickelten Bedrohungs-Szenario ein Land mit Agent Orange entlaubt und mit Napalm verbrannt.
<G-vec00721-002-s344><burn.verbrennen><en> For example, while handling these capacitors, electrostatic discharge (ESD) may burn it (ESD occurs when an exposed human finger touches other objects), so protective measures should be respected.
<G-vec00721-002-s344><burn.verbrennen><de> Beispielsweise könnten diese Kondensatoren bei der Handhabung durch elektrostatische Entladung (Electrostatic Discharge, ESD) verbrannt werden (eine ESD tritt auf, wenn man mit dem ungeschützten Finger andere Objekte berührt).
<G-vec00721-002-s345><burn.verbrennen><en> About how a priest breathed new life in his crippled body that saved him from withering away when his body was full of burn and his lungs tainted from poisonous fumes.
<G-vec00721-002-s345><burn.verbrennen><de> Darüber, wie ein Priester ihm den Lebenswillen eingehaucht hat, der ihn vom Wegsterben rettete, als er verbrannt und mit der Lunge voll ätzenden Gasen auf der Intensivstation lag.
<G-vec00721-002-s346><burn.verbrennen><en> “Then under Eleazar’s supervision burn the cow, the whole thing—hide, meat, blood, even its dung.
<G-vec00721-002-s346><burn.verbrennen><de> Die Kuh soll in seiner Gegenwart ganz verbrannt werden, mit Fell, Fleisch, Blut und Eingeweiden.
<G-vec00721-002-s347><burn.verbrennen><en> Whether e-cigarettes or IQOS, both have one important attribute in common: They run on electricity and use electrically-generated heat - this stands in contrast to normal cigarettes, which burn tobacco.
<G-vec00721-002-s347><burn.verbrennen><de> Ob E‑Zigaretten oder IQOS, beide haben eine große Gemeinsamkeit: Sie werden beide elektrisch betrieben und arbeiten somit mit elektrisch erzeugter Hitze – im Gegensatz zur normalen Zigarette, bei der Tabak verbrannt wird.
<G-vec00721-002-s348><burn.verbrennen><en> Laser rust removal: Using the characteristics of laser high energy, high frequency and high power, high energy is instantly deposited in a small area, and high temperature is used to burn the oxide layer, which is also called laser cleaning.
<G-vec00721-002-s348><burn.verbrennen><de> Laserrostentfernung: Unter Verwendung der Eigenschaften von Laser mit hoher Energie, hoher Frequenz und hoher Leistung wird hohe Energie sofort auf kleinem Raum abgeschieden, und die Oxidschicht wird mit hoher Temperatur verbrannt, was auch als Laserreinigung bezeichnet wird.
<G-vec00721-002-s349><burn.verbrennen><en> And all thy wives, and thy children shall be brought out to the Chaldeans, and thou shalt not escape their hands, but thou shalt be taken by the hand of the king of Babylon: and he shall burn this city with fire.
<G-vec00721-002-s349><burn.verbrennen><de> 23 Also werden dann alle deine Weiber und Kinder hinaus müssen zu den Chaldäern, und du selbst wirst ihren Händen nicht entgehen; sondern du wirst vom König von Babel gegriffen, und diese Stadt wird mit Feuer verbrannt werden.
<G-vec00721-002-s350><burn.verbrennen><en> "I burn, I destroy"...
<G-vec00721-002-s350><burn.verbrennen><de> Ich verbrenne, ich zerstöre..
<G-vec00721-002-s351><burn.verbrennen><en> 13,30 ‘Allow both to grow together until the harvest; and in the time of the harvest I will say to the reapers, "First gather up the tares and bind them in bundles to burn them up; but gather the wheat into my barn.
<G-vec00721-002-s351><burn.verbrennen><de> 13,30 Laßt beides miteinander wachsen bis zur Ernte; und um die Erntezeit will ich zu den Schnittern sagen: Sammelt zuerst das Unkraut und bindet es in Bündel, damit man es verbrenne; aber den Weizen sammelt mir in meine Scheune.
<G-vec00721-002-s352><burn.verbrennen><en> Little children, open your hearts and give me everything that is in them: joys, sorrows and each, even the smallest pain, that I may offer them to Jesus; so that with His immeasurable love, He may burn and transform your sorrows into the joy of His resurrection.
<G-vec00721-002-s352><burn.verbrennen><de> Meine lieben Kinder, öffnet eure Herzen und gebt mir all das, was in ihnen ist: Freuden, Trauer, und jeden, auch den kleinsten Schmerz, damit ich sie Jesus darbringen kann, so daß Er mit Seiner unermeßlichen Liebe eure Trauer verbrenne und in die Freude Seiner Auferstehung verwandle.
<G-vec00721-002-s353><burn.verbrennen><en> When I burn a bull on the altar as a sacrifice, I know it creates a pleasing odor for the Lord (Lev.
<G-vec00721-002-s353><burn.verbrennen><de> Wenn ich einen Bullen auf dem Altar als Opfergabe verbrenne, dann weiß ich, dass er für Den Herrn einen lieblichen Geruch entfaltet (Lev.
<G-vec00721-002-s354><burn.verbrennen><en> But the flesh of the bullock, and its skin, and it dung, shalt thou burn with fire without the camp: it is a sin-offering.
<G-vec00721-002-s354><burn.verbrennen><de> 14 Und das Fleisch des Farren, und seine Haut und seinen Mist verbrenne mit Feuer außen vor dem Lager; denn ein Sündopfer ist es.
<G-vec00721-002-s355><burn.verbrennen><en> I would say to these people: “Please, take back your cheque, burn it”. The People of God, namely, the Church, does not need dirty money. They need hearts open to the mercy of God.
<G-vec00721-002-s355><burn.verbrennen><de> Ich sage diesen Menschen: »Bitte, nimm deinen Scheck wieder mit, verbrenne ihn.« Das Volk Gottes, also die Kirche, braucht kein schmutziges Geld, sondern es braucht Herzen, die offen sind für die Barmherzigkeit Gottes.
<G-vec00721-002-s356><burn.verbrennen><en> You have not seen the rod in My hand or the flame with which I burn man, and that is why you are still haughty and intemperate in My presence.
<G-vec00721-002-s356><burn.verbrennen><de> Ihr habt nicht den Stab in Meiner Hand gesehen oder die Flamme, mit der Ich den Menschen verbrenne, und deswegen seid ihr in Meiner Gegenwart immer noch hochmütig und maßlos.
<G-vec00721-002-s357><burn.verbrennen><en> Before going to bed I burn my garbage, eat myself, tidy up the food and snacks ready for the next run.
<G-vec00721-002-s357><burn.verbrennen><de> Bevor ich in den Schlafsack krieche verbrenne ich noch den Abfall, esse selber etwas und richte Futter und Snacks für den nächsten Lauf.
<G-vec00721-002-s358><burn.verbrennen><en> Or, write it on a few loose pieces of paper and burn them later.
<G-vec00721-002-s358><burn.verbrennen><de> Oder schreibe es auf ein paar lose Blätter und verbrenne sie später.
<G-vec00721-002-s359><burn.verbrennen><en> Do not burn it like an idiot.
<G-vec00721-002-s359><burn.verbrennen><de> Verbrenne es nicht wie ein Idiot.
<G-vec00721-002-s360><burn.verbrennen><en> I easily burn them all on my bike.
<G-vec00721-002-s360><burn.verbrennen><de> Ich verbrenne sie alle leicht auf meinem Fahrrad.
<G-vec00721-002-s361><burn.verbrennen><en> Here’s how a lot of people think: "I’ll kowtow, burn incense, and worship Buddha, and if I’m a little bit pious my gong will grow."
<G-vec00721-002-s361><burn.verbrennen><de> Viele von uns denken halt so: Ich mache Kotau, verbrenne Räucherstäbchen, verehre Buddha, mein Herz bleibt fromm, dann wächst schon meine Kultivierungsenergie.
<G-vec00721-002-s362><burn.verbrennen><en> Burn witches (and alchemists), and while we we're at it, burn alleged witches, as well as those that looked, smelled or sounded like witches.
<G-vec00721-002-s362><burn.verbrennen><de> Verbrenne Hexen (und Alchemisten), und wenn wir schon dabei sind, verbrenne vorgebliche Hexen, ebenso sie diejenigen, die aussahen, rochen, oder klangen wie Hexen.
<G-vec00721-002-s364><burn.verbrennen><en> Burn this candle and summon the angel of healing.
<G-vec00721-002-s364><burn.verbrennen><de> Verbrenne diese Kerze und rufe den Engel der Liebe herbei.
<G-vec00721-002-s365><burn.verbrennen><en> 1 Burn calories and track them.
<G-vec00721-002-s365><burn.verbrennen><de> 1 Verbrenne Kalorien und zähle sie.
<G-vec00721-002-s366><burn.verbrennen><en> 4 And of these again thou shall take, and cast them into the midst of the fire, and burn them in the fire. From there a fire shall come forth into all the house of Israel.
<G-vec00721-002-s366><burn.verbrennen><de> 4 Und nimm wiederum etliches davon und wirf's in ein Feuer und verbrenne es mit Feuer; von dem soll ein Feuer auskommen über das ganze Haus Israel.
<G-vec00721-002-s367><burn.verbrennen><en> 2 Thus saith the Lord, the God of Israel: Go, and speak to Sedecias king of Juda, and say to him: Thus saith the Lord: Behold I will deliver this city into the hands of the king of Babylon, and he shall burn it with fire.
<G-vec00721-002-s367><burn.verbrennen><de> 2 So spricht Jehova, der Gott Israels: Geh und sprich zu Zedekia, dem König von Juda, und sage ihm: So spricht Jehova: Siehe, ich gebe diese Stadt in die Hand des Königs von Babel, daß er sie mit Feuer verbrenne.
<G-vec00721-002-s368><burn.verbrennen><en> Burn four enemies in five seconds.
<G-vec00721-002-s368><burn.verbrennen><de> Verbrenne vier Feinde in fünf Sekunden.
<G-vec00721-002-s369><burn.verbrennen><en> Every day, exercising will help you burn calories and build muscle and give your metabolism to increase, even at rest.
<G-vec00721-002-s369><burn.verbrennen><de> Die tägliche Ausübung hilft Ihnen, Kalorien verbrennen und Muskeln aufbauen und geben Sie Ihrem Stoffwechsel einen Schub auch in Ruhe.
<G-vec00721-002-s370><burn.verbrennen><en> “Thus says the Lord, the God of Israel: Go, and speak to Zedekiah, the king of Judah. And you shall say to him: Thus says the Lord: Behold, I will deliver this city into the hands of the king of Babylon, and he will burn it with fire.
<G-vec00721-002-s370><burn.verbrennen><de> 2 So spricht der HERR, der Gott Israels: Geh hin und sprich mit Zedekia, dem König von Juda, und sage zu ihm: So spricht der HERR: Siehe, ich will diese Stadt in die Hände des Königs von Babel geben, und er soll sie mit Feuer verbrennen.
<G-vec00721-002-s371><burn.verbrennen><en> This suggests that you do not supply ample power for the body to burn fat and build muscle mass correctly through the exercise.
<G-vec00721-002-s371><burn.verbrennen><de> Dies deutet darauf hin, dass Sie nicht genügend Kraft für den menschlichen Körper liefern, Fett zu verbrennen und auch Muskelmasse richtig mit der Übung bauen.
<G-vec00721-002-s372><burn.verbrennen><en> All participants came out of a bulking-up period and wanted to get drier and burn fat for the start of the season just ahead.
<G-vec00721-002-s372><burn.verbrennen><de> Alle Testpersonen kamen aus einer Bulkphase und wollten, mit dem Saisonstart in Aussicht, trockener werden und Fett verbrennen.
<G-vec00721-002-s373><burn.verbrennen><en> So get ready to burn up the asphalt as you speed toward the finish!
<G-vec00721-002-s373><burn.verbrennen><de> Macht euch also bereit, den Asphalt zu verbrennen, während ihr dem Ziel entgegen flitzt.
<G-vec00721-002-s374><burn.verbrennen><en> After lots of futile attempts to save the mango trees, the only remaining option is to cut and burn them.
<G-vec00721-002-s374><burn.verbrennen><de> Nach vielen vergeblichen Versuchen bleibt nur die Möglichkeit, die kranken Bäume abzuschneiden und zu verbrennen.
<G-vec00721-002-s375><burn.verbrennen><en> Qohor knew that the Dothraki would very soon break through the gates to rape, slave and burn at their pleasure.
<G-vec00721-002-s375><burn.verbrennen><de> Qohor wusste, dass die Dothraki sehr bald die Tore zerschmettern würden und schänden, versklaven und verbrennen würden, wie es ihnen gefiel.
<G-vec00721-002-s376><burn.verbrennen><en> If you burn rich mineral paper and general paper at the same time, you will find that the general paper burns to the ground quickly, on the contrary, fire of rich mineral paper is becoming smaller and smaller till it puts out.
<G-vec00721-002-s376><burn.verbrennen><de> Wenn Sie gleichzeitig reiches Mineralpapier und gewöhnliches Papier verbrennen, werden Sie feststellen, dass das allgemeine Papier schnell zu Boden brennt, im Gegenteil, das Feuer des reichen Mineralpapiers wird immer kleiner, bis es ausgeht.
<G-vec00721-002-s377><burn.verbrennen><en> The temperature shouldn’t be too high because the crepes burn easily.
<G-vec00721-002-s377><burn.verbrennen><de> Die Temperatur sollte außerdem nicht zu hoch sein, da die Pfannkuchen sonst schnell verbrennen.
<G-vec00721-002-s378><burn.verbrennen><en> 15 And it came to pass on the seventh day, that they said unto Samson's wife, Entice thy husband, that he may declare unto us the riddle, lest we burn thee and thy father's house with fire: have ye called us to take that we have? [is it] not [so]?
<G-vec00721-002-s378><burn.verbrennen><de> 15Am vierten Tage sprachen sie zu Simsons Frau: Überrede deinen Mann, dass er uns des Rätsels Lösung sagt, oder wir werden dich und deines Vaters Haus mit Feuer verbrennen.
<G-vec00721-002-s379><burn.verbrennen><en> By standing during the day, you can burn 50 more calories than sitting.
<G-vec00721-002-s379><burn.verbrennen><de> Wenn Sie tagsüber stehen, verbrennen Sie 50 Kalorien mehr als beim Sitzen.
<G-vec00721-002-s380><burn.verbrennen><en> This projector-based measuring system can also be useful for the aviation sector; some mechanical components, such as a turbine, cannot be 'painted' with patterns or templates for accurate measurement purposes – the paint would burn off when the turbine started.
<G-vec00721-002-s380><burn.verbrennen><de> Dieses Messverfahren mit den Projektoren kann der Luftfahrt ebenfalls nützlich sein: Einige technische Geräte wie beispielsweise eine Turbine können für eine genaue Vermessung nicht mit Mustern bemalt werden - die Farbe würde bei einem Einsatz der Turbine verbrennen.
<G-vec00721-002-s381><burn.verbrennen><en> Venerate the king and his wife, and do not burn them, since you know not when you may have need of these things, which improve the king and his wife.
<G-vec00721-002-s381><burn.verbrennen><de> Verehret den ‘König’ und seine ‘Gattin’, und wollet sie nicht verbrennen, da ihr nicht wißt, wann ihr jene (Dinge) braucht, die den ‘König’ und seine ‘Gattin’ veredeln.
<G-vec00721-002-s382><burn.verbrennen><en> More exercises, more walking, more running, as these exercises to burn calories at a very high level.
<G-vec00721-002-s382><burn.verbrennen><de> Mehr Bewegung, mehr zu Fuß gehen, mehr Joggen, da diese Übungen Ihre Kalorien verbrennen auf einem sehr hohen Zinssatz.
<G-vec00721-002-s383><burn.verbrennen><en> 19:4 because they have forsaken me, and have estranged this place [from me], and have burned incense in it unto other gods, whom neither they nor their fathers have known, nor the kings of Judah; and have filled this place with the blood of innocents; 19:5 and they have built the high places of Baal, to burn their sons in the fire as burnt-offerings unto Baal, which I commanded not, nor spake it, neither came it up into my mind: 19:6 therefore behold, days come, saith Jehovah, that this place shall no more be called Topheth, nor Valley of the son of Hinnom, but the valley of slaughter.
<G-vec00721-002-s383><burn.verbrennen><de> 4 Darum, weil sie mich verlassen und [mir] diesen Ort entfremdet und an ihm andern Göttern Rauchopfer dargebracht haben, [Göttern], die sie nicht kennen, weder sie noch ihre Väter, noch die Könige von Juda, und [weil] sie diesen Ort mit dem Blut Unschuldiger angefüllt haben 5 und die Höhen des Baal gebaut, um ihre Kinder als Brandopfer für den Baal im Feuer zu verbrennen, was ich nicht befohlen noch geredet habe und [was] mir nicht in den Sinn gekommen ist: 6 darum siehe, Tage kommen, spricht der HERR, da dieser Ort nicht mehr Tofet noch Tal Ben-Hinnom genannt werden wird, sondern Tal des Schlachtens.
<G-vec00721-002-s384><burn.verbrennen><en> 3 And you shall tear down their altars and break their statues and burn their graven images with fire;
<G-vec00721-002-s384><burn.verbrennen><de> 3 Und ihr sollt ihre Altäre niederreißen und ihre Gedenksteine zerbrechen und ihre Ascherim mit Feuer verbrennen und die Bilder ihrer Götter umhauen.
<G-vec00721-002-s385><burn.verbrennen><en> Instant Burn the Impure deals 3 damage to target creature.
<G-vec00721-002-s385><burn.verbrennen><de> Die Unreinen verbrennen fügt einer Kreatur deiner Wahl 3 Schadenspunkte zu.
<G-vec00721-002-s386><burn.verbrennen><en> Help burn fat and much more...
<G-vec00721-002-s386><burn.verbrennen><de> Hilfe Fett zu verbrennen und vieles mehr...
<G-vec00721-002-s387><burn.verbrennen><en> -- about the turn of the millennium there will come earthquakes and earth fires (p.242), the earth will burn, the air will not protect the humans any more from the fire, and the skin and the eyes will be destroyed by the sun (p.243).
<G-vec00721-002-s387><burn.verbrennen><de> -- um die Jahrtausendwende werden Erdbeben und Erdenbrände entstehen (S.242), die Erde wird verbrennen, die Luft wird die Menschen nicht mehr vor dem Feuer schützen, und Haut und Augen werden von der Sonne verzehrt werden (S.243).
<G-vec00721-002-s388><burn.verbrennen><en> The more muscle you have the more calories you burn throughout the day.
<G-vec00721-002-s388><burn.verbrennen><de> Je mehr Muskeln du hast, desto mehr Kalorien verbrennst du den ganzen Tag über.
<G-vec00721-002-s389><burn.verbrennen><en> The longer you can “run” in this position, the more fat your burn.
<G-vec00721-002-s389><burn.verbrennen><de> Je länger Du “rennst“, desto mehr Kalorien verbrennst Du.
<G-vec00721-002-s390><burn.verbrennen><en> Blisters occur whenever you burn your skin.
<G-vec00721-002-s390><burn.verbrennen><de> Blasen entstehen, wann immer du deine Haut verbrennst.
<G-vec00721-002-s391><burn.verbrennen><en> The more you move throughout the day, the more calories you'll burn.
<G-vec00721-002-s391><burn.verbrennen><de> Je mehr du dich tagsüber bewegst, desto mehr Kalorien verbrennst du.
<G-vec00721-002-s392><burn.verbrennen><en> Note that the faster your pace, the more calories you'll burn in that 30 minute time span.
<G-vec00721-002-s392><burn.verbrennen><de> Beachte bitte, dass du in dieser 30-minütigen Zeitspanne umso mehr Kalorien verbrennst, je schneller du läufst.
<G-vec00721-002-s393><burn.verbrennen><en> So ditch the low-fat fad and choose healthy fats to feel full longer, burn more calories, and have increased energy.
<G-vec00721-002-s393><burn.verbrennen><de> So bleibst du länger satt, verbrennst mehr Kalorien und fühlst dich voller Energie.
<G-vec00721-002-s394><burn.verbrennen><en> This gives the marshmallow some time to cool down so that it doesn't burn your mouth.
<G-vec00721-002-s394><burn.verbrennen><de> So kann sich das Marshmallow abkühlen, damit du dir nicht den Mund verbrennst.
<G-vec00721-002-s395><burn.verbrennen><en> It is a magic night when you can ask a wish and burn it in the bonfire so that it becomes a reality.
<G-vec00721-002-s395><burn.verbrennen><de> Es ist eine magische Nacht, wenn du einen Wunsch stellen kannst und ihn im Lagerfeuer verbrennst, so dass es zur Realität wird.
<G-vec00721-002-s396><burn.verbrennen><en> Description During an exercise you burn carbohydrates and lose salts and minerals.
<G-vec00721-002-s396><burn.verbrennen><de> Beschreibung Während einer Übung verbrennst du Kohlenhydrate und verlierst Salze und Mineralien.
<G-vec00721-002-s397><burn.verbrennen><en> In addition, you have the HIIT a afterburn, that means that you burn fat even after the completion of your training and not only along the way.
<G-vec00721-002-s397><burn.verbrennen><de> Zudem hast du beim HIIT einen Nachbrenneffekt, d.h. dass du selbst nach Abschluss deines Trainings noch Fett verbrennst und nicht nur währenddessen.
<G-vec00721-002-s398><burn.verbrennen><en> However, if you do harder or more difficult strokes, the total calories you burn will increase.
<G-vec00721-002-s398><burn.verbrennen><de> Falls du jedoch schwerere oder schwierigere Züge machst, steigen die Gesamtkalorien, die du verbrennst.
<G-vec00721-002-s399><burn.verbrennen><en> Turn chocolate, holding the edge of the bowl with the tea towel so you don't burn your fingers.
<G-vec00721-002-s399><burn.verbrennen><de> Rühre die Schokolade um, während Du den Rand der Schüssel mit dem Geschirrtuch hältst, so dass Du Dir nicht die Finger verbrennst.
<G-vec00721-002-s400><burn.verbrennen><en> Use pot holders when handling the jar filled with hot caramel sauce, as it will burn you.
<G-vec00721-002-s400><burn.verbrennen><de> Verwende Topflappen, damit du dich nicht verbrennst, wenn du den Topf oder den Behälter mit der heißen Karamellsauce berührst.
<G-vec00721-002-s401><burn.verbrennen><en> To lose weight, you will need to reduce your overall caloric intake so that you are eating fewer calories than you burn.
<G-vec00721-002-s401><burn.verbrennen><de> Um abzunehmen, musst du deine Kalorienzufuhr verringern, so dass du weniger Kalorien zu dir nimmst als du verbrennst.
<G-vec00721-002-s402><burn.verbrennen><en> If you don’t sweat very much, you still burn as many calories as your heavily sweating workout partner.
<G-vec00721-002-s402><burn.verbrennen><de> Wenn du weniger schwitzt, verbrennst du also nicht weniger als dein stärker schwitzender Trainingspartner.
<G-vec00721-002-s403><burn.verbrennen><en> Our cells make D-Ribose every day, however they simply can’t make it speedily, meaning when you exercise you burn it faster than the body can produce it.
<G-vec00721-002-s403><burn.verbrennen><de> Unsere Zellen produzieren D-Ribose täglich, jedoch langsam, was bedeutet, dass du es beim Training schneller verbrennst als es der Körper wieder produzieren kann.
<G-vec00721-002-s404><burn.verbrennen><en> If you burn your marshmallow the first few times, don't throw the marshmallow away.
<G-vec00721-002-s404><burn.verbrennen><de> Wenn du deine Marshmallows die ersten paar Male verbrennst, wirf die Marshmallows nicht weg.
<G-vec00721-002-s405><burn.verbrennen><en> Several times during our research we found the statement that you can only succeed with a weight loss if you consume less calories than you burn.
<G-vec00721-002-s405><burn.verbrennen><de> Mehrfach fanden wir bei unserer Recherche die Aussage, eine Gewichtsreduktion könne dir nur gelingen, wenn du weniger Kalorien zu dir nimmst, als du verbrennst.
<G-vec00721-002-s406><burn.verbrennen><en> In order to lose a pound of fat you must consume 3,500 less calories than you burn.
<G-vec00721-002-s406><burn.verbrennen><de> Um ein halbes Kilo Fett abzunehmen, musst du 3500 Kalorien weniger zu dir nehmen, als du verbrennst.
<G-vec00721-002-s407><burn.verbrennen><en> Behold, they shall be as stubble; the fire shall burn them; they shall not deliver themselves from the power of the flame: it shall not be a coal to warm at, nor a fire to sit before.
<G-vec00721-002-s407><burn.verbrennen><de> Siehe, sie sind wie Stoppeln, die das Feuer verbrennt; sie können ihr Leben nicht erretten vor der Flamme; denn es wird nicht eine Glut sein, dabei man sich wärme, oder ein Feuer, darum man sitzen möge.
<G-vec00721-002-s408><burn.verbrennen><en> Secondary Burn the ground you walk on, dealing 342% weapon damage each second.
<G-vec00721-002-s408><burn.verbrennen><de> Ihr verbrennt den Boden, auf dem Ihr wandelt, und alle Gegner, die in das Feuer geraten, erleiden jede Sekunde 342% Waffenschaden.
<G-vec00721-002-s409><burn.verbrennen><en> Tip: After about 25 minutes cover the pie with some tin-foil, so that it does not burn.
<G-vec00721-002-s409><burn.verbrennen><de> Tipp: Nach etwa 25 Minuten den Kuchen mit etwas Alufolie abdecken, damit er nicht verbrennt.
<G-vec00721-002-s410><burn.verbrennen><en> So either you freeze your hands while washing them or you burn them.
<G-vec00721-002-s410><burn.verbrennen><de> Also erfriert man entweder seine Haende oder verbrennt sie.
<G-vec00721-002-s411><burn.verbrennen><en> The teeth will wear, but the blade will not burn up
<G-vec00721-002-s411><burn.verbrennen><de> Die Zaehne werden zwar abgenutzt, aber das Saegeblatt verbrennt nicht.
<G-vec00721-002-s412><burn.verbrennen><en> While cardio does burn calories faster than weightlifting, if you want maximum fat burning, you need to do both.
<G-vec00721-002-s412><burn.verbrennen><de> Während Ausdauertraining Kalorien schneller verbrennt als Gewichte heben, musst du beides tun, um maximale Fettverbrennung zu erzielen.
<G-vec00721-002-s413><burn.verbrennen><en> If the answer to the question of how to burn fat fast still doesn't strike us as satisfactory, let's get into tennis.
<G-vec00721-002-s413><burn.verbrennen><de> Wenn uns die Antwort auf die Frage, wie man schnell Fett verbrennt, immer noch nicht zufriedenstellend erscheint, gehen wir zum Tennis.
<G-vec00721-002-s414><burn.verbrennen><en> "That was a prelude only, where you burn books, you also burn people in the end.
<G-vec00721-002-s414><burn.verbrennen><de> „Das war ein Vorspiel nur, dort wo man Bücher verbrennt, verbrennt man auch am Ende Menschen.
<G-vec00721-002-s416><burn.verbrennen><en> One of these slaves shall maintain the fire beneath thee, while the other shall anoint thy wretched limbs with oil, lest the roast should burn.
<G-vec00721-002-s416><burn.verbrennen><de> Auf dieses warme Bett sollst Du zu liegen kommen, ganz nackend, indes der eine Sklave das Feuer unter Dir erhält und der andere Deine Glieder recht hübsch mit Oel tränkt, damit der Braten nicht verbrennt.
<G-vec00721-002-s417><burn.verbrennen><en> Hafnium will resist corrosion in air due to the formation of an oxide film, although powdered hafnium will burn in air.
<G-vec00721-002-s417><burn.verbrennen><de> Hafnium widersteht aufgrund der Bildung einer Oxidschicht der Korrosion an der Luft, pulverförmiges Hafnium verbrennt jedoch an der Luft.
<G-vec00721-002-s418><burn.verbrennen><en> Firstly, burn your ego in the fire.
<G-vec00721-002-s418><burn.verbrennen><de> Verbrennt euch zuerst euer Ego.
<G-vec00721-002-s419><burn.verbrennen><en> You should also make sure that especially products with good reviews (from 4 stars rating) are advertised, otherwise you will “burn” your advertising budget.
<G-vec00721-002-s419><burn.verbrennen><de> Ebenso sollte darauf geachtet werden, dass vor allem Produkte mit guten Rezensionen (ab 4 Sterne Rating) beworben werden, denn andernfalls „verbrennt“ man sein Werbebudget.
<G-vec00721-002-s420><burn.verbrennen><en> Be careful not to burn the plant, although it already has a developed root system and should be ready to devour plenty of light.
<G-vec00721-002-s420><burn.verbrennen><de> Allerdings muss man aufpassen, damit man die Pflanze nicht verbrennt, und das, obwohl sich das Wurzelsystem schon vollständig entwickelt hat und für die Lichtaufnahme bereit ist.
<G-vec00721-002-s421><burn.verbrennen><en> The more lean tissue your body is made up of, the more calories you will burn during exercise
<G-vec00721-002-s421><burn.verbrennen><de> Je mehr fettfreies Gewebe Ihr Körper hat, desto mehr Kalorien verbrennt er beim Sport.
<G-vec00721-002-s422><burn.verbrennen><en> Nevertheless you can only use weight when you burn more calories than you eat. 4.
<G-vec00721-002-s422><burn.verbrennen><de> Jedoch nimmt man natürlich nur ab, wenn man weniger Kalorien zu sich nimmt, als man verbrennt.
<G-vec00721-002-s423><burn.verbrennen><en> When your metabolic increases, your body will burn more fat, including fat arms, fat belly, and so on.
<G-vec00721-002-s423><burn.verbrennen><de> Wenn Ihr Stoffwechsel erhöht, verbrennt der Körper mehr Fett, einschließlich Arm Fett, Bauchfett und so weiter.
<G-vec00721-002-s424><burn.verbrennen><en> The necessary amount of pigment can only be gleaned if the clothing doesn't burn completely, but instead slowly chars.
<G-vec00721-002-s424><burn.verbrennen><de> Nur wenn die Kleidung nicht vollständig verbrennt, sondern langsam verkohlt, kann die notwendige Menge an Pigmenten gewonnen werden.
<G-vec00721-002-s425><burn.verbrennen><en> Leather is a natural product which tends to burn during engraving or cutting; it also produces a particular smell.
<G-vec00721-002-s425><burn.verbrennen><de> Da es sich beim Leder um ein Naturprodukt handelt, das beim Lasergravieren oder -schneiden verbrennt, kommt es meist zu einer Geruchsentwicklung.
<G-vec00721-002-s519><burn.verbrennen><en> Weight loss is not just burn fat.
<G-vec00721-002-s519><burn.verbrennen><de> Gewichtsverlust ist nicht nur Fett zu verbrennen.
<G-vec00721-002-s520><burn.verbrennen><en> And the more calories you burn, the more weight you lose.
<G-vec00721-002-s520><burn.verbrennen><de> Und je mehr Kalorien zu verbrennen, desto mehr Gewicht verlieren Sie.
<G-vec00721-002-s521><burn.verbrennen><en> By mixing running, jogging, walking, and sprinting, it helps you effectively burn fat and slim down.
<G-vec00721-002-s521><burn.verbrennen><de> Durch die Verbindung von Laufen mit Joggen, Walking und Sprints hilft sie, Fett effektiv zu verbrennen und abzunehmen.
<G-vec00721-002-s522><burn.verbrennen><en> Protein is a source of energy, and it is this energy that we can implement and thereby burn calories by higher metabolic rate.
<G-vec00721-002-s522><burn.verbrennen><de> Protein ist eine Energiequelle, und es ist mit dieser Energie, die wir in der Lage sind zu nutzen und damit Kalorien verbrennen durch eine höhere Stoffwechselrate.
<G-vec00721-002-s523><burn.verbrennen><en> Both the capsicum and piperine have intensive thermogenic properties which can assist you burn fat by improving your body warmth.
<G-vec00721-002-s523><burn.verbrennen><de> Sowohl die Paprika und auch Piperin haben umfangreiche thermogene Eigenschaften, die Sie durch die Verbesserung Ihrer Temperatur Fett zu verbrennen helfen kann.
<G-vec00721-002-s524><burn.verbrennen><en> 30 Leave (them), that both may grow together till the harvest; and in the season of harvest I will say to the reapers, Gather first the zizania, and bind them (together in) bundles, that they may burn; but the wheat collect into my barns.
<G-vec00721-002-s524><burn.verbrennen><de> 30 Laßt es beides zusammen wachsen bis zur Ernte, und zur Zeit der Ernte werde ich den Schnittern sagen: Leset zuerst das Unkraut zusammen und bindet es in Bündel, um es zu verbrennen; den Weizen aber sammelt in meine Scheune.
<G-vec00721-002-s525><burn.verbrennen><en> They're like a highly narcissistic chess player who, seeing that 'check mate' is almost upon him, opts to knock all the pieces off the board (and maybe burn it... and the room) rather than suffer the ignominy of defeat.
<G-vec00721-002-s525><burn.verbrennen><de> Sie sind wie ein hoch-narzisstischer Schachspieler, der, wenn er sieht, dass das "Schach und Matt" kurz bevor steht, sich dazu entscheidet alle Figuren vom Brett zu stoßen (und es vielleicht zu verbrennen... genauso wie den Raum), anstatt die Schmach der Niederlage erleiden zu müssen.
<G-vec00721-002-s526><burn.verbrennen><en> This does more than burn every living thing it lands on - it consumes the oxygen.
<G-vec00721-002-s526><burn.verbrennen><de> Das tut mehr als jedes lebende Ding zu verbrennen, auf das es fällt - es verbraucht den Sauerstoff.
<G-vec00721-002-s527><burn.verbrennen><en> Several insurance claim that anavar assists burn fat.
<G-vec00721-002-s527><burn.verbrennen><de> Mehrere Versicherungsanspruch, dass anavar Fett zu verbrennen hilft.
<G-vec00721-002-s472><burn.verglühen><en> Scientists expect that most of it will burn up in the atmosphere, but some parts might survive and reach the surface.
<G-vec00721-002-s472><burn.verglühen><de> Dabei wird die gut zehn Meter lange Station größtenteils in der Atmosphäre verglühen, einige Trümmerstücke könnten aber die Erdoberfläche erreichen.
<G-vec00721-002-s473><burn.verglühen><en> Just as on Earth, the simplest way to reduce rubbish in space is to avoid it altogether – rocket stages and old satellites can be actively slowed down and made to burn up in the atmosphere.
<G-vec00721-002-s473><burn.verglühen><de> Wie auf der Erde ist auch im Weltraum der einfachste Weg, Müll zu reduzieren, ihn gleich zu vermeiden: Raketenstufen und alte Satelliten können aktiv gebremst und zum Verglühen in der Atmosphäre gebracht werden.
<G-vec00721-002-s474><burn.verglühen><en> This August, a controlled re-entry into Earth's atmosphere is expected to take place, during which the ATV will burn up completely over the South Pacific.
<G-vec00721-002-s474><burn.verglühen><de> Voraussichtlich im August dieses Jahres wird es kontrolliert in die Erdatmosphäre zurückgeführt, wo es über dem Südpazifik verglühen wird.
<G-vec00721-002-s475><burn.verglühen><en> After that, it will slowly re-enter Earth’s atmosphere, where it will burn up.
<G-vec00721-002-s475><burn.verglühen><de> Danach wird er langsam wieder in die Erdatmosphäre eintreten und verglühen.
<G-vec00721-002-s476><burn.verglühen><en> When the X-ray satellite ROSAT re-enters the atmosphere, which is expected to occur in October 2011, the satellite will disintegrate and most of the fragments will burn up in the extreme heat caused by atmospheric friction.
<G-vec00721-002-s476><burn.verglühen><de> Beim voraussichtlichen Wiedereintritt des Raumfahrzeugs in die Atmosphäre im Oktober 2011 wird der Satellit in Trümmerstücke zerbrechen und zum Teil durch die extreme Hitze verglühen.
<G-vec00721-002-s477><burn.verglühen><en> Last but not least, a European payload will burn up in Earth’s atmosphere for the first time in August this year in a fully controlled manner.
<G-vec00721-002-s477><burn.verglühen><de> Am Ende der Jules Verne-Mission, im August 2008, wird erstmals eine europäische Nutzlast kontrolliert in der Erdatmosphäre verglühen.
<G-vec00721-002-s478><burn.verglühen><en> So that the fibers do not burn up at temperatures of up to 900 degrees Celsius, the combustion has to be performed without oxygen.
<G-vec00721-002-s478><burn.verglühen><de> Damit die Fasern bei Temperaturen von bis zu 900 Grad Celsius nicht verglühen, muss die Verbrennung ohne Sauerstoff ablaufen.
<G-vec00721-002-s479><burn.verglühen><en> As they travel through the atmosphere, the meteorites burn up, which is why they are also called shooting stars.
<G-vec00721-002-s479><burn.verglühen><de> Wenn sie durch die Atmosphäre fallen, verglühen sie und werden dann Sternschnuppen genannt.
<G-vec00721-002-s480><burn.verglühen><en> In just a few weeks from now, the Chinese space station Tiangong-1 will re-enter the Earth’s atmosphere where it will to a large extent burn up.
<G-vec00721-002-s480><burn.verglühen><de> Die chinesische Raumstation Tiangong-1 wird in wenigen Wochen in die Erdatmosphäre eintreten und zu einem großen Teil verglühen.
<G-vec00721-002-s481><burn.verglühen><en> When the spacecraft re-enters the atmosphere at a speed of approximately 28,000 kilometres per hour, the X-ray observatory will break up into fragments, some of which will burn up by the extreme heat.
<G-vec00721-002-s481><burn.verglühen><de> Beim Wiedereintritt des Raumfahrzeugs in die Atmosphäre mit etwa 28.000 Kilometern pro Stunde wird der Röntgensatellit in Trümmerstücke zerbrechen und zum Teil durch die extreme Hitze verglühen.
<G-vec00721-002-s482><burn.verglühen><en> Whenever the Earth approaches one of these clouds of particles, a large number of the particles collide with Earth's atmosphere and burn up to create 'shooting stars' or, more accurately, to form meteors.
<G-vec00721-002-s482><burn.verglühen><de> Nähert sich diese Partikelwolke der Erde, dann stoßen viele der Teilchen mit der Erdatmosphäre zusammen und verglühen als Sternschnuppen beziehungsweise Meteore.
<G-vec00721-002-s483><burn.verglühen><en> In order to cope with this issue, ESA is currently looking for solutions to put ENVISAT into a lower orbit and to eventually let the satellite securely burn up when re-entering the Earth’s atmosphere.
<G-vec00721-002-s483><burn.verglühen><de> Um der Situation zu begegnen, sucht die ESA zurzeit nach Lösungsansätzen, um ENVISAT auf eine tiefere Umlaufbahn zu bringen und schließlich in der Erdatmosphäre kontrolliert und sicher verglühen zu lassen.
<G-vec00721-002-s484><burn.verglühen><en> An entering into the Earth's atmosphere and burn up is expected to be from 2025.
<G-vec00721-002-s484><burn.verglühen><de> Ein Eintritt in die Erdatmosphäre und sein Verglühen wird ab 2025 erwartet.
<G-vec00721-002-s485><burn.verglühen><en> “There is one negative point,” he admits: When CHEOPS will have fulfilled its mission in a few years, the satellite will burn up in the Earth’s atmosphere and the plaques will be destroyed.
<G-vec00721-002-s485><burn.verglühen><de> “Es gibt aber einen negativen Punkt”, gibt er zu: Hat CHEOPS seine Mission in einigen Jahren erfüllt, wird der Satellit in der Erdatmosphäre verglühen und die Plaketten dabei zerstört werden.
<G-vec00986-002-s528><burn.zünden><en> 25 Then take them from their hands and burn them on the altar along with the burnt offering for a pleasing aroma to the LORD, an offering made to the LORD by fire.
<G-vec00986-002-s528><burn.zünden><de> 25 Darnach nimm's von ihren Händen und zünde es an auf dem Altar zu dem Brandopfer, zum süßensüßen GeruchGeruch vor dem HERRN; denn das ist ein Feuer des HERRN.
<G-vec00986-002-s529><burn.zünden><en> 29:25 And you shall receive them of their hands, and burn them upon the altar for a burnt offering, for a sweet savour before the LORD: it is an offering made by fire unto the LORD.
<G-vec00986-002-s529><burn.zünden><de> 29:23 nimm's von ihren Händen und zünde es an auf dem Altar zu dem Brandopfer, zum süßen Geruch vor dem HERRN; denn das ist ein Feuer des HERRN.
<G-vec00986-002-s530><burn.zünden><en> 3 Burn some incense or a scented candle.
<G-vec00986-002-s530><burn.zünden><de> Zünde Räucherstäbchen oder eine Duftkerze an.
<G-vec00986-002-s531><burn.zünden><en> 31 And all the fat thereof shall he take away, as the fat is taken away from off the sacrifice of peace-offerings; and the priest shall burn it upon the altar for a sweet savor unto Jehovah; and the priest shall make atonement for him, and he shall be forgiven.
<G-vec00986-002-s531><burn.zünden><de> 31 Und all ihr Fett nehme er weg, wie das Fett von dem Dankopfer weggenommen wird, und der Priester zünde es auf dem Altar an zu einem Geruch der Ruhe für Jehovah, und der Priester sühne über ihm, und es wird ihm vergeben.
<G-vec00986-002-s532><burn.zünden><en> 25 You shall take them from their hands, and burn them on the altar on the burnt offering, for a pleasant aroma before Adonai: it is an offering made by fire to Adonai .
<G-vec00986-002-s532><burn.zünden><de> 25 Darnach nimm's von ihren Händen und zünde es an auf dem Altar zu dem Brandopfer, zum süßen Geruch vor dem HERRN; denn das ist ein Feuer des HERRN.
<G-vec00986-002-s535><burn.zünden><en> NIV And thou shalt receive them of their hands, and burn them upon the altar for a burnt offering, for a sweet savour before the LORD: it is an offering made by fire unto the LORD.
<G-vec00986-002-s535><burn.zünden><de> 25Darnach nimm es von ihren Händen und zünde es an auf dem Altar zum Brandopfer, zum süßen Geruch vor dem HERRN; es ist ein Feueropfer des HERRN.
<G-vec00986-002-s536><burn.zünden><en> 18 and thou shalt burn the whole ram upon the altar: it is a burnt-offering to Jehovah -- a sweet odour; it is an offering by fire to Jehovah.
<G-vec00986-002-s536><burn.zünden><de> 18 Und den ganzen Widder zünde an auf dem Altar; ein Brandopfer ist es dem Jehovah, ein Geruch der Ruhe, ein Feueropfer für Jehovah ist es.
<G-vec00986-002-s537><burn.zünden><en> 25 And the fat of the sin-offering shall he burn upon the altar.
<G-vec00986-002-s537><burn.zünden><de> 25 Und das Fett des Sündopfers zünde er auf dem Altar an.
