<G-vec00022-002-s004><budge.bewegen><en> Making the object budge without fully moving it from its place: a thullaccaya.
<G-vec00022-002-s004><budge.bewegen><de> Den Gegenstand bewegen, ohne ihn gänzlich von seinem Platz zu bringen: Ein thullaccaya.
<G-vec00022-002-s005><budge.bewegen><en> Here is a wooden box, which is easy to budge.
<G-vec00022-002-s005><budge.bewegen><de> Hier ist eine Holzkiste, die leicht zu bewegen ist.
<G-vec00022-002-s006><budge.bewegen><en> The Palestinians not only refused to budge but ridiculed the very idea.
<G-vec00022-002-s006><budge.bewegen><de> Die Palästinenser lehnten nicht nur ab sich zu bewegen, sondern verhöhnten die Idee.
<G-vec00022-002-s007><budge.bewegen><en> But Excalibur still did not budge.
<G-vec00022-002-s007><budge.bewegen><de> Aber Excalibur bewegte sich nicht.
<G-vec00022-002-s029><budge.bewegen><en> And it happens that the baby, being sufficiently developed, can not budge.
<G-vec00022-002-s029><budge.bewegen><de> Und es kommt vor, dass das Baby, wenn es ausreichend entwickelt ist, sich nicht bewegen kann.
<G-vec00022-002-s004><budge.sich_bewegen><en> Making the object budge without fully moving it from its place: a thullaccaya.
<G-vec00022-002-s004><budge.sich_bewegen><de> Den Gegenstand bewegen, ohne ihn gänzlich von seinem Platz zu bringen: Ein thullaccaya.
<G-vec00022-002-s005><budge.sich_bewegen><en> Here is a wooden box, which is easy to budge.
<G-vec00022-002-s005><budge.sich_bewegen><de> Hier ist eine Holzkiste, die leicht zu bewegen ist.
<G-vec00022-002-s006><budge.sich_bewegen><en> The Palestinians not only refused to budge but ridiculed the very idea.
<G-vec00022-002-s006><budge.sich_bewegen><de> Die Palästinenser lehnten nicht nur ab sich zu bewegen, sondern verhöhnten die Idee.
<G-vec00022-002-s007><budge.sich_bewegen><en> But Excalibur still did not budge.
<G-vec00022-002-s007><budge.sich_bewegen><de> Aber Excalibur bewegte sich nicht.
<G-vec00022-002-s029><budge.sich_bewegen><en> And it happens that the baby, being sufficiently developed, can not budge.
<G-vec00022-002-s029><budge.sich_bewegen><de> Und es kommt vor, dass das Baby, wenn es ausreichend entwickelt ist, sich nicht bewegen kann.
<G-vec00942-002-s020><budge.nachgeben><en> Made from high-quality leather with sturdy metal fixtures, they're able to withstand plenty of resistance from unruly subs, maintaining their form and refusing to budge.
<G-vec00942-002-s020><budge.nachgeben><de> Die Fesseln bestehen aus qualitativ hochwertigem Leder mit robusten Metallbeschlägen, die viel Widerstand von untergebenen Partnern aushalten und dabei ihre Form bewahren und nicht nachgeben.
<G-vec00942-002-s021><budge.nachgeben><en> Khamenei will not budge.
<G-vec00942-002-s021><budge.nachgeben><de> Khamenei wird nicht nachgeben.
<G-vec00942-002-s033><budge.umstimmen><en> I wouldn’t budge, as I knew there was nothing wrong with practicing Falun Dafa.
<G-vec00942-002-s033><budge.umstimmen><de> Ich ließ mich nicht umstimmen, da ich wusste, dass es nicht falsch ist, Falun Dafa zu praktizieren.
