<G-vec01040-002-s023><cling.festhalten><en> Without receiving permission to die, your loved one might cling to life for months, enduring unnecessary suffering and causing great anguish for the family.
<G-vec01040-002-s023><cling.festhalten><de> Ohne die Erlaubnis zu erhalten sterben zu dürfen, könnte dein geliebter Mensch für Monate am Leben festhalten, unnötiges Leiden erduldend und großen Kummer für die Familie bewirken.
<G-vec01040-002-s040><cling.festhalten><en> It may seem weird that we still cling to such tales when we have easy access to foolproof medical expertise that professionals have mastered over the years.
<G-vec01040-002-s040><cling.festhalten><de> Es mag seltsam erscheinen, dass wir uns immer noch an solchen Geschichten festhalten, wenn wir einfachen Zugang zu narrensicherer medizinischer Expertise haben, die Profis im Laufe der Jahre beherrschen.
<G-vec01040-002-s073><cling.festhalten><en> We also want to cling with all decisiveness to this, that we are justified only through the grace of God.
<G-vec01040-002-s073><cling.festhalten><de> Wir wollen auch mit aller Entschiedenheit daran festhalten, dass wir nur durch die Gnade Gottes gerechtfertigt sind.
<G-vec01040-002-s074><cling.festhalten><en> So it is a pedagogical gesture. But once the idea has been understood we don’t plan to cling to the term.
<G-vec01040-002-s074><cling.festhalten><de> Es ist eine pädagogische Geste und wenn die Idee einmal verstanden worden ist, planen wir nicht daran festzuhalten.
<G-vec01040-002-s081><cling.festhalten><en> For BEING, to which I now cling, is transient, only “beyond BEING” can the immortality of love be found.
<G-vec01040-002-s081><cling.festhalten><de> Denn das SEIN, an dem ich mich nun festhalte, ist vergänglich, allein „jenseits des SEINs“ ist die Unvergänglichkeit der Liebe zu finden.
<G-vec01040-002-s082><cling.festhalten><en> But the great “yes” of the decisive moment in our life – the “yes” to the truth that the Lord puts before us – must then be won afresh every day in the situations of daily life when we have to abandon our “I” over and over again, placing ourselves at the Lord’s disposal when deep down we would prefer to cling to our “I”.
<G-vec01040-002-s082><cling.festhalten><de> Aber das große Ja des entscheidenden Augenblicks in unserem Leben – das Ja zu der Wahrheit, die der Herr vor uns hinstellt – muss dann auch täglich neu eingeholt werden in den Situationen des Alltags, in denen wir immer wieder neu uns loslassen, uns freigeben müssen, wo wir eigentlich an uns festhalten möchten.
<G-vec01040-002-s083><cling.festhalten><en> If you really want to cling to your beliefs, which is something that we understand, then say NO.
<G-vec01040-002-s083><cling.festhalten><de> Wenn Ihr wirklich an Euren Glaubensmustern festhalten wollt, was etwas ist, das wir verstehen, dann sagt NEIN.
<G-vec01040-002-s084><cling.festhalten><en> A shock for tourists and residents that cling on to the picture-postcard image or to rules dictated by the requirements for preserving that greatly admired and unique medieval cityscape.
<G-vec01040-002-s084><cling.festhalten><de> Ein Schock für Touristen und Bewohner, die am Ansichtskartenbild oder an Regeln festhalten, die von den Erfordernissen für die Aufrechterhaltung dieses so sehr bewunderten und einzigartigen mittelalterlichen Stadtbildes diktiert werden.
<G-vec01040-002-s085><cling.festhalten><en> Are we clinging in ways that serve only to continue the round of suffering, or are we learning to hold to the ladder-like qualities that will eliminate craving and ignorance so that we can grow up and not have to cling.
<G-vec01040-002-s085><cling.festhalten><de> Halten wir uns derart fest, dass sich der Leidenskreislauf fortsetzt, oder lernen wir es allmählich, uns an die den Sprossen vergleichbaren Eigenschaften zu halten, die zur Beseitigung von Begehren und Unwissen führen, so dass wir uns weiterentwickeln können und letztlich an nichts mehr festzuhalten brauchen.
<G-vec01040-002-s086><cling.festhalten><en> Our part is to cling tenaciously to the revealed Word and to the institutions that He has created to preserve His Covenant.
<G-vec01040-002-s086><cling.festhalten><de> Unsere Aufgabe ist, mit aller Zähigkeit am offenbarten Wort und an den Institutionen, die Er zur Erhaltung Seines Bündnisses geschaffen hat, festzuhalten.
<G-vec01040-002-s126><cling.festhalten><en> First you apply them to things to which you might cling or crave, to see that the benefits of holding on to those things are far outweighed by the drawbacks.
<G-vec01040-002-s126><cling.festhalten><de> Zuerst fügen Sie diese den Dingen bei, an denen Sie halten oder danach verlangen wollen, um zu sehen, daß der Nutzen des Haltens an diesen Dingen, bei Weitem von den Nachteilen überwiegt wird.
<G-vec01040-002-s127><cling.festhalten><en> Once we recognize that it’s to his advantage to keep us incapacitated and immobilized by our guilt feelings, we can reject his lies, cling to the promises of Scripture, truly believe that we have died to sin, and begin to live for God in Christ (Romans 6:11).
<G-vec01040-002-s127><cling.festhalten><de> Wenn wir erst realisieren, dass Satan uns zu seinem eigenen Vorteil durch unsere Schuldgefühle lähmt, können wir seine Lügen ablehnen und uns an die Heilige Schrift halten, wirklich glauben, dass wir gegenüber der Sünde in den Augen Gottes gestorben sind und ein neues Leben für Gott in Christus begonnen haben (Römer 6,11).
<G-vec01040-002-s128><cling.festhalten><en> Cling tight to the two hanging bridges when you stop to admire the imposing view of the Rarámuri community of Bacajípare at the bottom of the gorge.
<G-vec01040-002-s128><cling.festhalten><de> Halten Sie sich sehr gut an den zwei Hängebrücken fest, während Sie die beeindruckende Aussicht auf die Rarámuri-Gemeinde von Bacajípare unten in der Schlucht bewundern.
<G-vec01040-002-s199><cling.festhalten><en> How the bloodsuckers overcome the variety of substrates and manage to cling on to various surfaces is shown by a current study by Dr. Dagmar Voigt (Technische Universität Dresden, Germany) and Professor Dr. Stanislav Gorb (Kiel University, Germany).
<G-vec01040-002-s199><cling.festhalten><de> Wie die Blutsauger die Vielfalt von solchen Substraten überwinden und sich auf verschiedenen Oberflächen festhalten, zeigt eine aktuelle Studie von Dr. Dagmar Voigt von der Technischen Universität Dresden (TUD) und Professor Stanislav Gorb von der Christian-Albrechts-Universität zu Kiel (CAU).
<G-vec01040-002-s200><cling.festhalten><en> Despite the seeming fragility, the whiskers possess great strength and are able to cling firmly to the support, pulling the whole shoot to it.
<G-vec01040-002-s200><cling.festhalten><de> Trotz der scheinbaren Zerbrechlichkeit besitzen die Schnurrhaare eine große Stärke und können sich fest am Träger festhalten und den gesamten Trieb daran ziehen.
<G-vec01040-002-s201><cling.festhalten><en> You have been spotted, and when you and your special friend finally meet you cling together in joyous reuion, never to be parted again.
<G-vec01040-002-s201><cling.festhalten><de> Du bist entdeckt worden, und wenn Du und Dein besonderer Freund sich endlich treffen, werdet Ihr Euch in freudiger Wiedervereinigung aneinander festhalten, um nie wieder getrennt zu werden.
<G-vec01040-002-s202><cling.festhalten><en> Our purpose in relating these things is to warn you that were they to maintain that those verses wherein the signs referred to in the Gospel are mentioned have been perverted, were they to reject them, and cling instead to other verses and traditions, you should know that their words were utter falsehood and sheer calumny.
<G-vec01040-002-s202><cling.festhalten><de> Wenn Wir auf diese Geschehnisse hinweisen, so ist Unsere Absicht, dich zu warnen: Sollten sie behaupten, die Verse des Evangeliums mit den angegebenen Zeichen seien verfälscht worden, sollten sie sie verwerfen und sich statt dessen an andere Verse und Überlieferungen halten, so solltest du wissen, daß ihre Worte völlig unwahr und bare Verleumdung sind.
<G-vec01040-002-s207><cling.festhalten><en> The British are desperate to cling to the island, and though the German navy cannot break through, the Luftwaffe owns the skies while the struggle below rages.
<G-vec01040-002-s207><cling.festhalten><de> Während britische Truppen die Insel um jeden Preis halten wollen und den Durchbruch der deutschen Flotte verhindern, beherrscht die Luftwaffe den Luftraum über der umkämpften Insel.
<G-vec01040-002-s041><cling.haften><en> 27 But Naaman's disease of the skin will cling to you and your descendants for ever.'
<G-vec01040-002-s041><cling.haften><de> 27 Der Aussatz Naamans aber soll für immer an dir und deinen Nachkommen haften.
<G-vec01040-002-s042><cling.haften><en> 60Moreover He will bring back on you all #Deut. 7:15the diseases of Egypt, of which you were afraid, and they shall cling to you.
<G-vec01040-002-s042><cling.haften><de> 60Und er wird alle Seuchen Ägyptens über dich bringen, vor denen du dich fürchtest; und sie werden an dir haften.
<G-vec01040-002-s121><cling.haften><en> 21 The Lord will make the pestilence cling to you until He has consumed you from the land into which you go to possess.
<G-vec01040-002-s121><cling.haften><de> 21Jehova wird die Pest an dir haften lassen, bis er dich aufreibt aus dem Lande, wohin du kommst, um es in Besitz zu nehmen.
<G-vec01040-002-s122><cling.haften><en> Often times they have a strong emotional bond with the mother and cling to them.
<G-vec01040-002-s122><cling.haften><de> Häufig Zeiten haben sie eine starke emotionale Bindung mit der Mutter und haften ihnen an.
<G-vec01040-002-s123><cling.haften><en> Instead, these vinyl coverings cling to the sides, backs and fronts of smartphones to provide scratch protection.
<G-vec01040-002-s123><cling.haften><de> Statt dessen haften diese Vinyl-Ummantlungen an den Seiten, Rücken und Vorderteilen der Smartphones um vor Kratzern zu schützen.
<G-vec01040-002-s124><cling.haften><en> If you don't know the truth you cling right there.
<G-vec01040-002-s124><cling.haften><de> Wenn Sie die Wahrheit nicht kennen, haften Sie genau dort an.
<G-vec01040-002-s125><cling.haften><en> And the longer they cling to the paintwork, the deeper the residues eat into the paintwork surfaces.
<G-vec01040-002-s125><cling.haften><de> Je länger sie auf dem Lack haften, desto tiefer fressen sich die Rückstände in die Lackoberfläche.
<G-vec01040-002-s043><cling.hängen><en> Canada move north, while the rest of the Americas cling to the Atlantic Rift while it separates.
<G-vec01040-002-s043><cling.hängen><de> Kanada bewegt sich nach Norden, während der Rest der Amerikas an dem Atlantischen Rücken hängen, während er sich trennt.
<G-vec01040-002-s060><cling.hängen><en> Not only does it look like a good time, but the bubbles actually cling to your Sims afterwards.
<G-vec01040-002-s060><cling.hängen><de> Das sieht nicht nur toll aus, sondern die Blasen bleiben auch an euren Sims hängen.
<G-vec01040-002-s132><cling.hängen><en> This will free the party of people who cling to its feet and prevent it from advancing.
<G-vec01040-002-s132><cling.hängen><de> Dies wird die Partei nur von Leuten befreien, die ihr an den Füßen hängen und sie am Vormarsch hindern.
<G-vec01040-002-s133><cling.hängen><en> It even eliminates static electricity, so dirt and dust particles won’t cling.
<G-vec01040-002-s133><cling.hängen><de> Sogar Reibungselektrizität kann nicht entstehen und somit bleibt Schmutz und Staub hängen.
<G-vec01040-002-s134><cling.hängen><en> While citizens have already embraced a diverse democracy for some time, political elites continue to cling more strongly to the representative System.
<G-vec01040-002-s134><cling.hängen><de> Während die Bürger in der vielfältigen Demokratie längst angekommen sind, hängen die politischen Eliten noch stärker am repräsentativen System.
<G-vec01040-002-s135><cling.hängen><en> In the short term, Mrs. Merkel, instead of immediate devaluation, painted the prospects of a very, very slow Euro death, which will allow her and her kind to cling on to the reins of power for a long time to come.
<G-vec01040-002-s135><cling.hängen><de> Auf kurze Sicht hin, zog Frau Merkel, statt der sofortigen Abwertung, einen sehr, sehr langsamen Eurotod in Betracht, der sie und ihresgleichen noch lange an der Nadel der Macht hängen lässt.
<G-vec01040-002-s136><cling.hängen><en> I guess many of us still cling on to those memories from our childhoods, where winter holidays and christmas always meant tons of snow and cold temperatures - which is what made that morning so special to me, since I didn't get to experience moments like that too often these past years.
<G-vec01040-002-s136><cling.hängen><de> Ich schätze, viele von uns hängen immer noch sehr an diesen Kindheitserinnerungen, die zu Weihnachten für gewöhnlich aus meterhohen Schneewänden und eisigen Temperaturen bestanden - was vor allem für mich Momente wie jene auf den Fotos umso besonderer macht, da ich diese in den letzten Jahren leider immer seltener miterleben durfte.
<G-vec01040-002-s137><cling.hängen><en> They cling to the traditional notion that the media are training their ever-watchful eyes on — and directing their ever-skeptical questions to — all branches and layers of government in order to keep our leaders in line.
<G-vec01040-002-s137><cling.hängen><de> Sie hängen der traditionellen Vorstellung an, die Medien würden ihre immer wachsamen Augen ausrichten auf alle Bereiche und Ebenen der Regierung, um unsere Führung bei der Stange zu halten – und ihre immer skeptischen Fragen stellen.
<G-vec01040-002-s138><cling.hängen><en> The hinges do cling tightly to the base unit, though.
<G-vec01040-002-s138><cling.hängen><de> Die Gelenke hängen hingegen sehr fest an der Base-Unit.
<G-vec01040-002-s139><cling.hängen><en> He will only rebuke him, saying, “You have not yet accepted the true knowledge and continue to cling to mistaken beliefs.
<G-vec01040-002-s139><cling.hängen><de> Er wird ihn nur zurechtweisen, indem Er sagt: „Du hast noch nicht das wahre Wissen akzeptiert und hängst immer noch an falschen Ansichten.
<G-vec01040-002-s140><cling.hängen><en> Often, the tongue will cling to the palate without even you realizing it.
<G-vec01040-002-s140><cling.hängen><de> Oftmals hängt die Zunge am Gaumen ohne dass du es überhaupt merkst.
<G-vec01040-002-s044><cling.klammern><en> You can do it with everything: paint, put on various supports, to cling to him different accessories and even break.
<G-vec01040-002-s044><cling.klammern><de> Sie können es mit allem zu tun: malen, auf verschiedenen Trägern setzen, um an ihn klammern verschiedene Accessoires und sogar brechen.
<G-vec01040-002-s142><cling.klammern><en> Cling onto a suit of armor's back for 30 seconds or longer.
<G-vec01040-002-s142><cling.klammern><de> Klammere dich 30 Sekunden oder länger an den Rücken einer Rüstung.
<G-vec01040-002-s143><cling.klammern><en> It's so ridiculous. We cling to our old ideas, our old... to this old world bound for extinction – we're afraid!
<G-vec01040-002-s143><cling.klammern><de> Wir klammern uns an unsere alten Ideen, unsere alten... an diese alte Welt, die verschwinden soll – wir haben Angst.
<G-vec01040-002-s144><cling.klammern><en> The framework of references that we cling to when we awake in the night, drenched with sweat because we have forgotten who we are.
<G-vec01040-002-s144><cling.klammern><de> Das Gerüst, an das wir uns klammern, wenn wir in der Nacht schweißgebadet aufwachen, weil wir vergessen hatten, wer wir sind.
<G-vec01040-002-s145><cling.klammern><en> •There she heard the beating waves sounding down through the water, and she thought, sure, he is sailing up there, he whom I love more than father or mother, he to whom my thoughts cling and in whose hand I would lay the destiny of my life.
<G-vec01040-002-s145><cling.klammern><de> •Dort unten hörte sie das Geräusch der sich brechenden Wellen durch das Wasser, und sie dachte: er segelt sicher dort oben, der, den ich mehr als Vater oder Mutter liebe, den, an den meine Gedanken klammern und in dessen Hand ich das Schicksal meines Lebens legen würde.
<G-vec01040-002-s146><cling.klammern><en> 2. let’s speed up our change, let’s not cling to the “good old world” but accept the disruption, a new speed of thinking, deciding and implementing, let’s learn to fail and see this as a milestone of alternative learning, let’s be happy about the support of the Digitals.
<G-vec01040-002-s146><cling.klammern><de> Beschleunigen wir unsere Veränderung, klammern wir uns nicht an die „schöne alte Welt“ sondern akzeptieren wir die Disruption, eine neue Geschwindigkeit des Denken, Entscheidens und Umsetzens, lernen wir zu Scheitern und dies als einen Meilenstein des alternativen Lernens zu sehen, freuen wir uns über die Unterstützung der „Digital Generation“.
<G-vec01040-002-s147><cling.klammern><en> If he makes a twisting try to cling to him if he passes by you, or is head-on before you, you should try to push him so that the attacker loses the ball.
<G-vec01040-002-s147><cling.klammern><de> Wenn er eine Täuschung macht, versucht zu Klammern, wenn er an euch vorbeizieht oder frontal vor euch ist, solltet ihr versuchen ihn zu stoßen, so dass der Angreifer den Ball verliert.
<G-vec01040-002-s148><cling.klammern><en> Have pity on yourselves, for ye shall witness the Day when God will have revealed Him Who is the Manifestation of His Own Self, invested with clear and irrefutable proofs, while ye will cling tenaciously to the words the Witnesses of the Bayán have uttered.
<G-vec01040-002-s148><cling.klammern><de> Habt Mitleid mit euch, denn ihr sollt Zeuge werden des Tags, an dem Gott Ihn offenbart, die Manifestation Seines Selbstes, versehen mit klaren und unabweisbaren Beweisen, doch ihr werdet euch hartnäckig an die Worte klammern, die des Bayán Zeugen sprachen.
<G-vec01040-002-s149><cling.klammern><en> The "East" was designed in such a way that in such a situation the ship could "cling" to the upper layer of the atmosphere, slow down the movement and calmly land or splash somewhere.
<G-vec01040-002-s149><cling.klammern><de> Der "Osten" war so konzipiert, dass sich das Schiff in einer solchen Situation an die obere Schicht der Atmosphäre "klammern", die Bewegung verlangsamen und ruhig landen oder irgendwo planschen konnte.
<G-vec01040-002-s150><cling.klammern><en> Choose round shapes for which the visitors and waiters will not cling or hurt.
<G-vec01040-002-s150><cling.klammern><de> Wählen Sie runde Formen, für die die Besucher und Kellner nicht klammern oder verletzen.
<G-vec01040-002-s151><cling.klammern><en> They do not cling.
<G-vec01040-002-s151><cling.klammern><de> Sie klammern nicht.
<G-vec01040-002-s152><cling.klammern><en> That was really cool! Two cling to my pussy and two on my nipples and then to breath or the vibrator.
<G-vec01040-002-s152><cling.klammern><de> Das war richtig geil!Zwei klammern an meiner Muschi und zwei an meinen Nippeln und dann noch den Vibrator reingeschoben.
<G-vec01040-002-s153><cling.klammern><en> We cling to relationships with a desperation that reflects the very real scarcity of love and pleasure in this world.
<G-vec01040-002-s153><cling.klammern><de> Wir klammern uns an Beziehungen mit einer Verzweiflung, die die reale Seltenheit der Liebe und des Vergnügens in dieser Welt reflektiert.
<G-vec01040-002-s154><cling.klammern><en> As we look to magic spells and the stars for guidance, we cling to the notion that the world of magic exists.
<G-vec01040-002-s154><cling.klammern><de> Wenn wir auf Zaubersprüche und Sterne zur Orientierung schauen, klammern wir uns an die Vorstellung, dass die Welt der Magie existiert.
<G-vec01040-002-s155><cling.klammern><en> The year is 2036. A quarter-century after nuclear war devastated the earth, a few thousand survivors still cling to existence beneath the ruins of Moscow, in the tunnels of the Metro.
<G-vec01040-002-s155><cling.klammern><de> Wir schreiben das Jahr 2036.Ein Vierteljahrhundert nach der nuklearen Vernichtung der Welt, klammern sich einige tausend Überlebende in den Metro-Tunneln der Ruinen Moskaus an ihre Existenz.
<G-vec01040-002-s156><cling.klammern><en> Trying to confront a monster that lives in a mansion, animals in the forest cling on to each other so they look like a giant monster.
<G-vec01040-002-s156><cling.klammern><de> Bei dem Versuch, ein Monster in einem Haus zu konfrontieren, klammern sich die Tiere des Waldes so zusammen, dass sie wie ein riesiges Monster aussehen.
<G-vec01040-002-s157><cling.klammern><en> Baby orang-utans cling to their mother's belly for the first few weeks of their lives.
<G-vec01040-002-s157><cling.klammern><de> Orang-Utan-Babys klammern sich in den ersten Wochen an den Bauch der Mutter.
<G-vec01040-002-s158><cling.klammern><en> At first you want to resist, and you cling in same parts to the voice as narrative for amount and way as well as to the objects of his artistic work.
<G-vec01040-002-s158><cling.klammern><de> Zunächst will man sich wehren, klammert gleichermaßen an die Stimme als Narrativ für Maß und Weg wie an die Objekte seiner künstlerischen Arbeiten.
<G-vec01040-002-s159><cling.klammern><en> Rather, cling to Me with greater resolve.
<G-vec01040-002-s159><cling.klammern><de> Klammert euch lieber mit noch größerer Entschlossenheit an Mich.
<G-vec01040-002-s160><cling.klammern><en> She hacks out alone or in company, and does not cling on other horses.
<G-vec01040-002-s160><cling.klammern><de> Sie hackt allein oder in Gesellschaft und klammert sich nicht an andere Pferde.
<G-vec01040-002-s161><cling.klammern><en> Consequently, they continue to blindly cling to the lopsided theology of exalting the Papal Gregorian Saturday (as determined by the man-made IDL) while professing Scripture as the sole rule of faith and duty.
<G-vec01040-002-s161><cling.klammern><de> Folglich klammert sie sich weiterhin blind an die einseitige Theologie der Erhöhung des päpstlichen, gregorianischen Samstags, der von der künstlichen IDG aus bestimmt wird, während sie sich zur Schrift als einzige Grundlage des Glaubens und der Pflicht bekennt.
<G-vec01040-002-s162><cling.klammern><en> It is now openly admitted that unions, businessmen and the state all speak the same language (only a tiny minority of union activists still cling desperately to the language of the former workers’ movement, the praises of which they continue to sing).
<G-vec01040-002-s162><cling.klammern><de> Mittlerweile wird es auch schon akzeptiert, dass die Gewerkschaften, die Geschäftsleute und der Staat die gleiche Sprache sprechen (einzig eine kleine Minderheit an Gewerkschaftsaktivisten klammert sich verzweifelt an die Sprache der früheren Arbeiterbewegung, deren Loblieder sie immer noch weiter singen).
<G-vec01040-002-s163><cling.klammern><en> But the essentials are reported truly and with remarkable vividness: the masses will no longer retreat, they resist with optimistic brilliance, they stay on the street even after murderous volleys, they cling, not to their lives, but to the pavement, to stones, to pieces of ice.
<G-vec01040-002-s163><cling.klammern><de> Das Wesentliche aber ist richtig und kraß wiedergegeben: die Masse will nicht mehr weichen, sie widersetzt sich mit optimistischer Wut, bleibt auf den Straßen auch nach den tödlichen Salven, klammert sich nicht an das Leben, sondern an das Pflaster, an die Steine, an das Eis.
<G-vec01040-002-s203><cling.klammern><en> We must cling, cling so tightly to the Truth that nothing can touch us.
<G-vec01040-002-s203><cling.klammern><de> Man müßte sich so stark an die Wahrheit klammern, daß einen nichts berühren kann.
<G-vec01040-002-s061><cling.kleben><en> But that’s not the only advantage: the fact that the tyres cling to the ground and iron out all its minor bumps, you’re destined to have a comfier ride on rough terrain with more traction.
<G-vec01040-002-s061><cling.kleben><de> Doch nicht nur die größere Kontaktfläche ist von Vorteil: Die Tatsache, dass sich der Reifen dem Untergrund besser anschmiegt und kleinere Unebenheiten förmlich aufsaugt, bringt den Vorteil, dass der Reifen im ruppigen Gelände viel satter auf dem Boden klebt und entsprechend länger Traktion behält.
<G-vec01040-002-s171><cling.kleben><en> There were immediate allegations that he was seeking to cling to power in the union in order to maintain his financial position.
<G-vec01040-002-s171><cling.kleben><de> Umgehend wurde ihm vorgeworfen, er würde an der Macht kleben, um seine finanzielle Position zu wahren.
<G-vec01040-002-s172><cling.kleben><en> In Scorpio we cling to earlier injuries. Uranus can serve as a solvent and acts like someone tearing away a plaster - short and a little painful, but much better than nibbling on the plaster for half an eternity.
<G-vec01040-002-s172><cling.kleben><de> Im Skorpion kleben wir an früheren Verletzungen, da kann Uranus als Lösungsmittel dienen und wirkt wie jemand, der uns ein Pflaster wegreisst – kurz und ein bisschen schmerzhaft, aber viel besser als wenn wir eine halbe Ewigkeit am Pflaster herumnibbeln.
<G-vec01040-002-s173><cling.kleben><en> You can also tell that the base has cooked enough when it is thick enough to cling to the back of your spoon.
<G-vec01040-002-s173><cling.kleben><de> Du kannst erkennen, dass die Basis ausreichend gekocht hat, wenn sie dick genug ist, um am Rücken deines Löffels kleben zu bleiben.
<G-vec01040-002-s044><cling.sich_klammern><en> You can do it with everything: paint, put on various supports, to cling to him different accessories and even break.
<G-vec01040-002-s044><cling.sich_klammern><de> Sie können es mit allem zu tun: malen, auf verschiedenen Trägern setzen, um an ihn klammern verschiedene Accessoires und sogar brechen.
<G-vec01040-002-s142><cling.sich_klammern><en> Cling onto a suit of armor's back for 30 seconds or longer.
<G-vec01040-002-s142><cling.sich_klammern><de> Klammere dich 30 Sekunden oder länger an den Rücken einer Rüstung.
<G-vec01040-002-s143><cling.sich_klammern><en> It's so ridiculous. We cling to our old ideas, our old... to this old world bound for extinction – we're afraid!
<G-vec01040-002-s143><cling.sich_klammern><de> Wir klammern uns an unsere alten Ideen, unsere alten... an diese alte Welt, die verschwinden soll – wir haben Angst.
<G-vec01040-002-s144><cling.sich_klammern><en> The framework of references that we cling to when we awake in the night, drenched with sweat because we have forgotten who we are.
<G-vec01040-002-s144><cling.sich_klammern><de> Das Gerüst, an das wir uns klammern, wenn wir in der Nacht schweißgebadet aufwachen, weil wir vergessen hatten, wer wir sind.
<G-vec01040-002-s145><cling.sich_klammern><en> •There she heard the beating waves sounding down through the water, and she thought, sure, he is sailing up there, he whom I love more than father or mother, he to whom my thoughts cling and in whose hand I would lay the destiny of my life.
<G-vec01040-002-s145><cling.sich_klammern><de> •Dort unten hörte sie das Geräusch der sich brechenden Wellen durch das Wasser, und sie dachte: er segelt sicher dort oben, der, den ich mehr als Vater oder Mutter liebe, den, an den meine Gedanken klammern und in dessen Hand ich das Schicksal meines Lebens legen würde.
<G-vec01040-002-s146><cling.sich_klammern><en> 2. let’s speed up our change, let’s not cling to the “good old world” but accept the disruption, a new speed of thinking, deciding and implementing, let’s learn to fail and see this as a milestone of alternative learning, let’s be happy about the support of the Digitals.
<G-vec01040-002-s146><cling.sich_klammern><de> Beschleunigen wir unsere Veränderung, klammern wir uns nicht an die „schöne alte Welt“ sondern akzeptieren wir die Disruption, eine neue Geschwindigkeit des Denken, Entscheidens und Umsetzens, lernen wir zu Scheitern und dies als einen Meilenstein des alternativen Lernens zu sehen, freuen wir uns über die Unterstützung der „Digital Generation“.
<G-vec01040-002-s147><cling.sich_klammern><en> If he makes a twisting try to cling to him if he passes by you, or is head-on before you, you should try to push him so that the attacker loses the ball.
<G-vec01040-002-s147><cling.sich_klammern><de> Wenn er eine Täuschung macht, versucht zu Klammern, wenn er an euch vorbeizieht oder frontal vor euch ist, solltet ihr versuchen ihn zu stoßen, so dass der Angreifer den Ball verliert.
<G-vec01040-002-s148><cling.sich_klammern><en> Have pity on yourselves, for ye shall witness the Day when God will have revealed Him Who is the Manifestation of His Own Self, invested with clear and irrefutable proofs, while ye will cling tenaciously to the words the Witnesses of the Bayán have uttered.
<G-vec01040-002-s148><cling.sich_klammern><de> Habt Mitleid mit euch, denn ihr sollt Zeuge werden des Tags, an dem Gott Ihn offenbart, die Manifestation Seines Selbstes, versehen mit klaren und unabweisbaren Beweisen, doch ihr werdet euch hartnäckig an die Worte klammern, die des Bayán Zeugen sprachen.
<G-vec01040-002-s149><cling.sich_klammern><en> The "East" was designed in such a way that in such a situation the ship could "cling" to the upper layer of the atmosphere, slow down the movement and calmly land or splash somewhere.
<G-vec01040-002-s149><cling.sich_klammern><de> Der "Osten" war so konzipiert, dass sich das Schiff in einer solchen Situation an die obere Schicht der Atmosphäre "klammern", die Bewegung verlangsamen und ruhig landen oder irgendwo planschen konnte.
<G-vec01040-002-s150><cling.sich_klammern><en> Choose round shapes for which the visitors and waiters will not cling or hurt.
<G-vec01040-002-s150><cling.sich_klammern><de> Wählen Sie runde Formen, für die die Besucher und Kellner nicht klammern oder verletzen.
<G-vec01040-002-s151><cling.sich_klammern><en> They do not cling.
<G-vec01040-002-s151><cling.sich_klammern><de> Sie klammern nicht.
<G-vec01040-002-s152><cling.sich_klammern><en> That was really cool! Two cling to my pussy and two on my nipples and then to breath or the vibrator.
<G-vec01040-002-s152><cling.sich_klammern><de> Das war richtig geil!Zwei klammern an meiner Muschi und zwei an meinen Nippeln und dann noch den Vibrator reingeschoben.
<G-vec01040-002-s153><cling.sich_klammern><en> We cling to relationships with a desperation that reflects the very real scarcity of love and pleasure in this world.
<G-vec01040-002-s153><cling.sich_klammern><de> Wir klammern uns an Beziehungen mit einer Verzweiflung, die die reale Seltenheit der Liebe und des Vergnügens in dieser Welt reflektiert.
<G-vec01040-002-s154><cling.sich_klammern><en> As we look to magic spells and the stars for guidance, we cling to the notion that the world of magic exists.
<G-vec01040-002-s154><cling.sich_klammern><de> Wenn wir auf Zaubersprüche und Sterne zur Orientierung schauen, klammern wir uns an die Vorstellung, dass die Welt der Magie existiert.
<G-vec01040-002-s155><cling.sich_klammern><en> The year is 2036. A quarter-century after nuclear war devastated the earth, a few thousand survivors still cling to existence beneath the ruins of Moscow, in the tunnels of the Metro.
<G-vec01040-002-s155><cling.sich_klammern><de> Wir schreiben das Jahr 2036.Ein Vierteljahrhundert nach der nuklearen Vernichtung der Welt, klammern sich einige tausend Überlebende in den Metro-Tunneln der Ruinen Moskaus an ihre Existenz.
<G-vec01040-002-s156><cling.sich_klammern><en> Trying to confront a monster that lives in a mansion, animals in the forest cling on to each other so they look like a giant monster.
<G-vec01040-002-s156><cling.sich_klammern><de> Bei dem Versuch, ein Monster in einem Haus zu konfrontieren, klammern sich die Tiere des Waldes so zusammen, dass sie wie ein riesiges Monster aussehen.
<G-vec01040-002-s157><cling.sich_klammern><en> Baby orang-utans cling to their mother's belly for the first few weeks of their lives.
<G-vec01040-002-s157><cling.sich_klammern><de> Orang-Utan-Babys klammern sich in den ersten Wochen an den Bauch der Mutter.
<G-vec01040-002-s158><cling.sich_klammern><en> At first you want to resist, and you cling in same parts to the voice as narrative for amount and way as well as to the objects of his artistic work.
<G-vec01040-002-s158><cling.sich_klammern><de> Zunächst will man sich wehren, klammert gleichermaßen an die Stimme als Narrativ für Maß und Weg wie an die Objekte seiner künstlerischen Arbeiten.
<G-vec01040-002-s159><cling.sich_klammern><en> Rather, cling to Me with greater resolve.
<G-vec01040-002-s159><cling.sich_klammern><de> Klammert euch lieber mit noch größerer Entschlossenheit an Mich.
<G-vec01040-002-s160><cling.sich_klammern><en> She hacks out alone or in company, and does not cling on other horses.
<G-vec01040-002-s160><cling.sich_klammern><de> Sie hackt allein oder in Gesellschaft und klammert sich nicht an andere Pferde.
<G-vec01040-002-s161><cling.sich_klammern><en> Consequently, they continue to blindly cling to the lopsided theology of exalting the Papal Gregorian Saturday (as determined by the man-made IDL) while professing Scripture as the sole rule of faith and duty.
<G-vec01040-002-s161><cling.sich_klammern><de> Folglich klammert sie sich weiterhin blind an die einseitige Theologie der Erhöhung des päpstlichen, gregorianischen Samstags, der von der künstlichen IDG aus bestimmt wird, während sie sich zur Schrift als einzige Grundlage des Glaubens und der Pflicht bekennt.
<G-vec01040-002-s162><cling.sich_klammern><en> It is now openly admitted that unions, businessmen and the state all speak the same language (only a tiny minority of union activists still cling desperately to the language of the former workers’ movement, the praises of which they continue to sing).
<G-vec01040-002-s162><cling.sich_klammern><de> Mittlerweile wird es auch schon akzeptiert, dass die Gewerkschaften, die Geschäftsleute und der Staat die gleiche Sprache sprechen (einzig eine kleine Minderheit an Gewerkschaftsaktivisten klammert sich verzweifelt an die Sprache der früheren Arbeiterbewegung, deren Loblieder sie immer noch weiter singen).
<G-vec01040-002-s163><cling.sich_klammern><en> But the essentials are reported truly and with remarkable vividness: the masses will no longer retreat, they resist with optimistic brilliance, they stay on the street even after murderous volleys, they cling, not to their lives, but to the pavement, to stones, to pieces of ice.
<G-vec01040-002-s163><cling.sich_klammern><de> Das Wesentliche aber ist richtig und kraß wiedergegeben: die Masse will nicht mehr weichen, sie widersetzt sich mit optimistischer Wut, bleibt auf den Straßen auch nach den tödlichen Salven, klammert sich nicht an das Leben, sondern an das Pflaster, an die Steine, an das Eis.
<G-vec01040-002-s203><cling.sich_klammern><en> We must cling, cling so tightly to the Truth that nothing can touch us.
<G-vec01040-002-s203><cling.sich_klammern><de> Man müßte sich so stark an die Wahrheit klammern, daß einen nichts berühren kann.
