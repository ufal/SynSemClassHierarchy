<G-vec00403-002-s020><commute.anreisen><en> Less affluent students, in particular, have to work while studying, commute far or get into debt.
<G-vec00403-002-s020><commute.anreisen><de> Insbesondere weniger wohlhabende Studierende müssen neben dem Studium arbeiten, weit anreisen oder sich verschulden.
<G-vec00403-002-s058><commute.erreichen><en> The area is also an easy commute, as it’s not far from Paddington Station.
<G-vec00403-002-s058><commute.erreichen><de> Die Gegend ist auch leicht zu erreichen, da sie nicht weit von der Paddington Station entfernt ist.
<G-vec00403-002-s059><commute.erreichen><en> The very easy and convenient access to the the skytrain (BTS) station allows a very comfortable commute to the city's sightseeings and main shopping areas. Pullman Bangkok Hotel G
<G-vec00403-002-s059><commute.erreichen><de> Die erstklassige Lage ermöglicht eine sehr gute Anbindung an die wichtigsten Straßen, Skytrain (BTS) und Flussverkehr, und garantiert so, dass alle Bereiche der Stadt bequem zu erreichen sind.
<G-vec00403-002-s061><commute.fahren><en> I commute to work by bicycle.
<G-vec00403-002-s061><commute.fahren><de> Ich fahre mit dem Fahrrad zur Arbeit.
<G-vec00403-002-s091><commute.kommen><en> 400 people live here and 800 Mexicans from the area commute every day to lure the last penny from the cruise ship guests.
<G-vec00403-002-s091><commute.kommen><de> 400 Leute wohnen hier und über 800 Mexikaner kommen jeden Tag hier her um den ganzen Kreuzfahrern das Geld aus der Tasche zu locken.
<G-vec00403-002-s092><commute.kommen><en> Even people living in Barcelona happily commute to Sitges on the weekend especially to take a dip in the crystal clear water before lazing around the white sands.
<G-vec00403-002-s092><commute.kommen><de> Auch die Einwohner von Barcelona kommen nach Sitges um hier im Meer baden zu gehen und sich auf dem weissen Sand auszuruhen.
<G-vec00403-002-s121><commute.pendeln><en> Many local people commute to work in nearby towns such as Westport and Castlebar, each of which have a growing industrial base.
<G-vec00403-002-s121><commute.pendeln><de> Viele Menschen aus Louisburgh pendeln ins nahe Westport und Castlebar zur Arbeit.
<G-vec00403-002-s076><commute.unternehmen><en> Most persons living with autism cannot commute alone.
<G-vec00403-002-s076><commute.unternehmen><de> Die Mehrheit der Personen mit Autismus kann nicht selbständig eine Fahrt unternehmen.
<G-vec00403-002-s156><commute.verkürzen><en> That might mean helping them avoid the frustration of sitting in traffic, cluing them in to a police trap or shaving five minutes off of their regular commute by showing them new routes they never even knew about.
<G-vec00403-002-s156><commute.verkürzen><de> Das bedeutet ihnen zu helfen die Frustration im Stau zu ersparen, vor Polizeikontrollen zu warnen oder die tägliche Pendelfahrt um 5 Minuten zu verkürzen, indem wir ihnen neue Wege aufzeigen, die sie vorher nicht kannten.
<G-vec00403-002-s157><commute.wandeln><en> Urging the authorities not to execute the 13 members of Aum Shinrikyo cult or any other prisoners, and to commute all existing death sentences.
<G-vec00403-002-s157><commute.wandeln><de> Bitte lassen Sie weder die 13 Mitglieder der Sekte Aum Shinrikyo noch andere Gefangene hinrichten und wandeln Sie alle Todesurteile um.
<G-vec00403-002-s158><commute.wandeln><en> Immediately establish a moratorium on executions and commute all death sentence as first steps towards abolition of the death penalty.
<G-vec00403-002-s158><commute.wandeln><de> Bitte erlassen Sie ein Hinrichtungsmoratorium und wandeln Sie als ersten Schritt hin zur Abschaffung der Todesstrafe alle Todesurteile in Haftstrafen um.
