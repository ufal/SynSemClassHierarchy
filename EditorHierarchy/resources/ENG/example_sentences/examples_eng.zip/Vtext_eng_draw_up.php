<G-vec00562-002-s114><draw_up.erarbeiten><en> Benchmarking Many years of operational experience at large and small companies in the life science sector enable us to evaluate your infrastructure, procedures and daily practices against international industrial standards and draw up pragmatic solutions together with you.
<G-vec00562-002-s114><draw_up.erarbeiten><de> Langjährige operationelle Erfahrungen in großen und kleinen Unternehmen der Life Science Branche setzen uns in die Lage, Ihre Infrastruktur sowie Verfahren und Alltagspraxis gegenüber internationalen Industrienormen zu beurteilen und gemeinsam mit Ihnen pragmatische Lösungsansätze zu erarbeiten.
<G-vec00562-002-s115><draw_up.erarbeiten><en> We analyse national and international policy concepts and instruments such as environmental labels and draw up sustainability strategies – especially for the trade sector – which are tailored to the respective protagonists.
<G-vec00562-002-s115><draw_up.erarbeiten><de> Wir analysieren nationale und internationale Politikkonzepte und -instrumente wie Umweltzeichen und erarbeiten Nachhaltigkeitsstrategien – beispielsweise für den Handel –, die auf die Akteure zugeschnitten sind.
<G-vec00562-002-s116><draw_up.erarbeiten><en> The task was a realistic disaster relief assignment for which participants in two-person teams had to draw up a meaningful strategic solution.
<G-vec00562-002-s116><draw_up.erarbeiten><de> Hier wird dann eine realitätsnahe Logistik-Aufgabe aus der Katastrophensoforthilfe gestellt, für die die Teilnehmer in Teams eine sinnvolle, strategische Lösung erarbeiten.
<G-vec00562-002-s117><draw_up.erarbeiten><en> The sherpa and his staff draw up the agenda for the German G7 Presidency, in close cooperation with the federal ministries.
<G-vec00562-002-s117><draw_up.erarbeiten><de> Der Sherpa und sein Stab erarbeiten – in enger Abstimmung mit den Bundesministerien – die Agenda der deutschen G7-Präsidentschaft.
<G-vec00562-002-s118><draw_up.erarbeiten><en> We also draw up package prices for you for large quantities of images and take into consideration any subsequent licenses for any as yet uncertain future re-use.
<G-vec00562-002-s118><draw_up.erarbeiten><de> Auch erarbeiten wir für Sie Paketpreise bei großen Bildmengen und berücksichtigen eventuelle Nachlizenzierungen für eine noch unsichere zukünftige Wiederverwendung.
<G-vec00562-002-s119><draw_up.erarbeiten><en> Together with the association, we draw up measures designed so enable sport clubs better to promote young talented players.
<G-vec00562-002-s119><draw_up.erarbeiten><de> Gemeinsam mit dem Verband erarbeiten wir Maßnahmen, um Vereine fitter für die Förderung des Nachwuchses zu machen.
<G-vec00562-002-s120><draw_up.erarbeiten><en> Our specialists can unlock your savings potential and draw up optimized concepts.
<G-vec00562-002-s120><draw_up.erarbeiten><de> Unsere Spezialisten decken Ihre Einsparpotenziale auf und erarbeiten optimierte Konzepte.
<G-vec00562-002-s121><draw_up.erarbeiten><en> Our site manager will visit you immediately, he will explain the whole issue of the construction, draw up a quote and set binding deadlines of the scaffolds completion.
<G-vec00562-002-s121><draw_up.erarbeiten><de> Unser Baumeister kann Sie sofort besuchen, die ganze Problematik des Baus erklären, ein Angebot erarbeiten und verbindliche Termine für den Gerüstbau nennen.
<G-vec00562-002-s122><draw_up.erarbeiten><en> More than 400 employees at 15 locations, in 13 countries, in three divisions work on countless projects - they develop software, advise our customers, draw up concepts, implement systems and enhance processes.
<G-vec00562-002-s122><draw_up.erarbeiten><de> Über 400 Mitarbeiter an 15 Standorten, in 13 Ländern, drei Geschäftsbereichen und unzähligen Projekten entwickeln Software, beraten unsere Kunden, erarbeiten Konzepte, implementieren Systeme und optimieren Abläufe.
<G-vec00562-002-s123><draw_up.erarbeiten><en> On this basis, we then draw up recommendations for implementation.
<G-vec00562-002-s123><draw_up.erarbeiten><de> Daraufhin erarbeiten wir Empfehlungen für die Umsetzung.
<G-vec00562-002-s124><draw_up.erarbeiten><en> As it usually concerns comparative measurements, it is necessary to know upfront the initial sound and vibration value in order to draw up a reliable analysis.
<G-vec00562-002-s124><draw_up.erarbeiten><de> Da es sich meist um Vergleichsmessungen geht, ist es notwendig den Anfangswert für Geräusch- und Schwingungsmessungen im Voraus zu kennen um eine zuverlässige Analyse zu erarbeiten.
<G-vec00562-002-s125><draw_up.erarbeiten><en> The Calibration Consulting experts draw up proposals to optimize the processes, methods, and tool chains, present them to the customer, and choose the best concept together with the customer.
<G-vec00562-002-s125><draw_up.erarbeiten><de> Die Calibration Consulting Experten erarbeiten Vorschläge zur Optimierung der Prozesse, Methoden und Toolketten, stellen diese dem Kunden vor und wählen gemeinsam mit ihm das beste Konzept aus.
<G-vec00562-002-s126><draw_up.erarbeiten><en> Whether you wish to re-equip your operation or are planning larger investments, we will draw up individually optimized concepts.
<G-vec00562-002-s126><draw_up.erarbeiten><de> Ob Sie Ihren Betrieb umrüsten wollen, oder größere Investitionen planen, wir erarbeiten individuell optimierte Konzepte.
<G-vec00562-002-s127><draw_up.erarbeiten><en> As well as manufacturing products in line with the technical specifications provided by our customers, we can also draw up the right solution for your application together with you and advise you on questions of further processing and product optimisation.
<G-vec00562-002-s127><draw_up.erarbeiten><de> Über die Herstellung von Produkten nach den technischen Spezifikationen unserer Kunden hinaus erarbeiten wir mit Ihnen zusammen die Lösung für Ihre Anwendung und beraten Sie weltweit zu Fragen der Weiterverarbeitung und Produktoptimierung.
<G-vec00562-002-s128><draw_up.erarbeiten><en> They will receive a fictitious commission from the Confederation to draw up a “2015 Risk Report” for Switzerland.
<G-vec00562-002-s128><draw_up.erarbeiten><de> Sie erhalten den fiktiven Auftrag des Bundes, einen «Risikobericht 2015» für die Schweiz zu erarbeiten.
<G-vec00562-002-s129><draw_up.erarbeiten><en> With the progress of design work, they supervise the progress of the certification process and draw up comprehensive documentation necessary for the evaluation.
<G-vec00562-002-s129><draw_up.erarbeiten><de> Mit dem Fortschritt der Entwurfsarbeiten überwachen sie den Fortschritt des Zertifizierungsverfahrens und erarbeiten umfassende Unterlagen für die Analyse.
<G-vec00562-002-s130><draw_up.erarbeiten><en> The UN Working Group on Business and Human Rights and the European Commission have called on governments to implement the UN Guiding Principles and draw up national action plans to that end.
<G-vec00562-002-s130><draw_up.erarbeiten><de> Die UN-Arbeitsgruppe zu Wirtschaft und Menschenrechten und auch die EU-Kommission haben die Regierungen aufgefordert, die UN-Leitprinzipien umzusetzen und dazu Nationale Aktionspläne zu erarbeiten.
<G-vec00562-002-s131><draw_up.erarbeiten><en> Draw up a map in which the number of Roma living in the individual countries of Europe are charted.
<G-vec00562-002-s131><draw_up.erarbeiten><de> Erarbeiten einer Karte, in der die Zahlen der in den einzelnen Ländern Europas lebenden Roma eingetragen werden.
<G-vec00562-002-s132><draw_up.erarbeiten><en> We draw up plans for updating and adapting existing events and provide support in implementing them.
<G-vec00562-002-s132><draw_up.erarbeiten><de> Wir erarbeiten Konzepte zur Aktualisierung und Marktanpassung bestehender Veranstaltungen und unterstützen bei ihrer Umsetzung.
<G-vec00562-002-s152><draw_up.erstellen><en> A logical continuation of the product development process is that, after elaborating the idea, verifying the appliance’s functionality, verifying mechanical features of structures and optimizing parts in order to reduce the mass or increase the bearing capacity, it is necessary to draw up product documents according to which these parts will be produced.
<G-vec00562-002-s152><draw_up.erstellen><de> Nachdem die Idee erarbeitet und die Funktionalität des Geräts überprüft wurden, die mechanischen Eigenschaften der Konstruktion geprüft und alle Teile optimiert wurden, damit die Masse so gering wie möglich gehalten oder eine stärkere Belastbarkeit hergestellt wird, muss im Prozess der Produktentwicklung auch die zugehörige Produktdokumentation erstellt werden, gemäß welcher die einzelnen Teile dann hergestellt werden.
<G-vec00562-002-s153><draw_up.erstellen><en> No later than two years after the entry into force of this Regulation, the Commission shall draw up a report on the application of the Regulation which, inter alia, takes into account economic developments and developments in international fora.
<G-vec00562-002-s153><draw_up.erstellen><de> Die Kommission erstellt bis spätestens zwei Jahre nach Inkrafttreten dieser Verordnung einen Bericht über die Anwendung dieser Verordnung, in dem unter anderem den wirtschaftlichen Entwicklungen und den in internationalen Gremien sich vollziehenden Entwicklungen Rechnung getragen wird.
<G-vec00562-002-s154><draw_up.erstellen><en> The Commission shall draw up a report in respect of the delegation of power not later than nine months before the end of the three-year period.
<G-vec00562-002-s154><draw_up.erstellen><de> Die Kommission erstellt spätestens neun Monate vor Ablauf dieses Dreijahreszeitraums einen Bericht über die Ausübung der Befugnisübertragung.
<G-vec00562-002-s155><draw_up.erstellen><en> It shall, on an annual basis, draw up a report to be submitted to the Board of Governors.
<G-vec00562-002-s155><draw_up.erstellen><de> Er erstellt jährlich einen Bericht, der dem Gouverneursrat vorzulegen ist.
<G-vec00562-002-s156><draw_up.erstellen><en> 6. Without prejudice to any measures agreed for the protection of persons, on the conclusion of the hearing, the executing authority shall draw up minutes indicating the date and place of the hearing, the identity of the person heard, the identities and functions of all other persons in the executing State participating in the hearing, any oaths taken and the technical conditions under which the hearing took place.
<G-vec00562-002-s156><draw_up.erstellen><de> (6) Unbeschadet etwaiger zum Schutz von Personen vereinbarter Maßnahmen erstellt die Vollstreckungsbehörde nach der Vernehmung ein Protokoll, das Angaben zum Termin und zum Ort der Vernehmung, zur Identität der vernommenen Person, zur Identität und zur Funktion aller anderen im Vollstreckungsstaat an der Vernehmung teilnehmenden Personen, zu einer etwaigen Vereidigung und zu den technischen Bedingungen, unter denen die Vernehmung stattfand, enthält.
<G-vec00562-002-s157><draw_up.erstellen><en> 2. In order to facilitate reporting, the Agency shall draw up and maintain a public list of standard contracts and update that list in a timely manner.
<G-vec00562-002-s157><draw_up.erstellen><de> (2) Zur Vereinfachung der Meldung erstellt und pflegt die Agentur eine öffentliche Liste von Standardverträgen, die sie fortlaufend aktualisiert.
<G-vec00562-002-s158><draw_up.erstellen><en> 2. The Commission shall draw up a work programme on the basis of this Decision.
<G-vec00562-002-s158><draw_up.erstellen><de> (2) Die Kommission erstellt auf der Grundlage dieses Beschlusses ein Arbeitsprogramm.
<G-vec00562-002-s159><draw_up.erstellen><en> The auditors draw up a comprehensive report once a year documenting the key findings of their audit.
<G-vec00562-002-s159><draw_up.erstellen><de> Die Revisionsstelle erstellt jährlich einen umfassenden Bericht, der die wichtigsten Erkenntnisse der Revision festhält.
<G-vec00562-002-s160><draw_up.erstellen><en> On the basis of these reports, the Commission shall draw up an annual report on the state of affairs of local Schengen cooperation to be submitted to the European Parliament and the Council.
<G-vec00562-002-s160><draw_up.erstellen><de> Auf der Grundlage dieser Berichte erstellt die Kommission einen Jahresbericht für jeden Konsularbezirk, der dem Europäischen Parlament und dem Rat vorgelegt wird.
<G-vec00562-002-s161><draw_up.erstellen><en> After a holistic check-up, our spa team will draw up a personal treatment, training, and nutrition plan for you that is tailored to you and your goals down to the last detail.
<G-vec00562-002-s161><draw_up.erstellen><de> Unser Spa-Team erstellt nach einem ganzheitlichen Check-up einen persönlichen Treatment-, Trainings- und Ernährungsplan für Sie, der bis ins Detail auf Sie und Ihre Ziele zugeschnitten ist.
<G-vec00562-002-s162><draw_up.erstellen><en> You can draw your own chart, download key figures as an Excel file, calculate your holdings for Rieter shares and/or download historical data.
<G-vec00562-002-s162><draw_up.erstellen><de> Es können eigene Tabellen und Diagramme erstellt und die Kennzahlen als Excel-Datei heruntergeladen werden.
<G-vec00562-002-s163><draw_up.erstellen><en> Option-dragging multiple selected MIDI Draw points no longer sometimes places the copied points at the wrong position.
<G-vec00562-002-s163><draw_up.erstellen><de> Beim Klick auf einen Marker wird jetzt nicht mehr sporadisch unerwartet ein weiterer kurzer Marker an derselben Position erstellt.
<G-vec00562-002-s164><draw_up.erstellen><en> If the search division considers that the application lacks unity of invention, it shall draw up a partial search report on the first invention.
<G-vec00562-002-s164><draw_up.erstellen><de> Dementsprechend hatte die Recherchenabteilung einen Recherchenbericht für die zuerst in den Patentansprüchen erwähnte Erfindung erstellt.
<G-vec00562-002-s165><draw_up.erstellen><en> Each Member State shall draw up and keep up to date a list of approved bodies, institutes and centres and their approval numbers and shall make it available to the other Member States and to the public.
<G-vec00562-002-s165><draw_up.erstellen><de> Jeder Mitgliedstaat erstellt eine Liste der zugelassenen Einrichtungen, Institute und Zentren und deren Zulassungsnummern, hält die Liste auf dem aktuellen Stand und stellt sie den übrigen Mitgliedstaaten und der Öffentlichkeit zur Verfügung.
<G-vec00562-002-s166><draw_up.erstellen><en> The competent authorities shall draw up an assessment report and comments on the dossier as regards the results of the analytical and pharmacotoxicological tests and the clinical trials of the medicinal product concerned.
<G-vec00562-002-s166><draw_up.erstellen><de> (4) Die zuständige Behörde erstellt einen Beurteilungsbericht und eine Stellungnahme zu dem Dossier hinsichtlich der Ergebnisse von analytischen, toxikologisch-pharmakologischen Tests und klinischen Versuchen mit dem betreffenden Arzneimittel.
<G-vec00562-002-s167><draw_up.erstellen><en> In this case, Patient Management will draw up the cost estimate for you with the justification letter for you to submit to your insurance company.
<G-vec00562-002-s167><draw_up.erstellen><de> Das Patientenmanagement erstellt in diesem Fall für Sie den Kostenvoranschlag mit dem Begründungsschreiben, die Sie bitte bei Ihrer Kasse einreichen.
<G-vec00562-002-s168><draw_up.erstellen><en> The Bulgarian company shall draw up a report for the corresponding fees on the basis of the settlement received in accordance with Art.
<G-vec00562-002-s168><draw_up.erstellen><de> Für die entsprechenden Gebühren erstellt das bulgarische Unternehmen anhand der erhaltenen Abrechnung Protokolle im Sinne des Art.
<G-vec00562-002-s169><draw_up.erstellen><en> The conformity assessment body shall draw up an evaluation report that records the activities undertaken in accordance with point 4 and their outcomes.
<G-vec00562-002-s169><draw_up.erstellen><de> Die Konformitätsbewertungsstelle erstellt einen Prüfungsbericht über die nach Ziffer 4 durchgeführten Schritte und die dabei erzielten Ergebnisse.
<G-vec00562-002-s170><draw_up.erstellen><en> I will introduce you how to draw a flower illustration.
<G-vec00562-002-s170><draw_up.erstellen><de> Dieses Mal zeige ich, wie man mit Hilfe von Illustrator eine Blume erstellt.
<G-vec00562-002-s247><draw_up.machen><en> Some models of cranes draw attention to themselves with angular shapes, while others, on the contrary, fascinate with smooth shapes and grace.
<G-vec00562-002-s247><draw_up.machen><de> Einige Modelle von Kranen machen mit eckigen Formen auf sich aufmerksam, während andere mit glatten Formen und Grazie faszinieren.
<G-vec00562-002-s248><draw_up.machen><en> Negative priorities: In view of contracting resources, the CoR will not be able to draw attention to every activity on every subject at every level.
<G-vec00562-002-s248><draw_up.machen><de> Negative Prioritäten Im Sinne einer Bündelung der Ressourcen wird der AdR nicht in der Lage sein, auf jede Aktivität zu jedem Thema auf jeder Ebene aufmerksam zu machen.
<G-vec00562-002-s249><draw_up.machen><en> Analyzing a social and political situation in Kobrin district, it is possible to draw conclusions that the situation was difficult.
<G-vec00562-002-s249><draw_up.machen><de> Die gesellschaftspolitische Situation auf Kobrynschtschine analysierend, kann man die Schlussfolgerungen darüber machen, dass die Situation kompliziert war.
<G-vec00562-002-s250><draw_up.machen><en> For opposite souls it is a relief, an easing of their worry about men, when they can draw the attention of them to that, what threatens them, for which they have a fine feeling, however do not have the right explanation.
<G-vec00562-002-s250><draw_up.machen><de> Für die jenseitigen Seelen ist es eine Erleichterung, eine Entlastung ihrer Sorge um die Menschen, wenn sie diese aufmerksam machen können auf das, was ihnen droht, wofür sie ein feines Empfinden, jedoch nicht die rechte Erklärung haben.
<G-vec00562-002-s251><draw_up.machen><en> Prowindo committee's members and representatives of the member companies have been invited by Prowindo to draw attention to the special situation of plastic recycling.
<G-vec00562-002-s251><draw_up.machen><de> Im Rahmen eines parlamentarischen Frühstücks lud Prowindo im Februar die Mitglieder des CDU Umweltausschusses sowie Vertreter der Mitglieds unternehmen ein, um auf die beson dere Situation des Kunststofffensterrecyclings aufmerksam zu machen.
<G-vec00562-002-s252><draw_up.machen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00562-002-s252><draw_up.machen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00562-002-s253><draw_up.machen><en> After learning the basic characteristics in the first level of our study – Bargue Drawings Copying Technique – we start learning how to draw real objects.
<G-vec00562-002-s253><draw_up.machen><de> Nach dem Erlernen von Zeichengrundlagen im ersten Level unseres Studiums – das Zeichnen von Bargue Kopien – geht es bei den Cast-Zeichnungen darum erste Studien von realen Gegenständen zu machen.
<G-vec00562-002-s254><draw_up.machen><en> Together with Sudanese members of both human rights organisations beat on drums in Berlin on Thursday in front of the Brandenburger Tor to draw attention to the growing danger of a new war.
<G-vec00562-002-s254><draw_up.machen><de> Gemeinsam mit Sudanesen trommelten Mitglieder beider Menschenrechtsorganisationen auf alten Ölfässern am Donnerstag in Berlin vor dem Brandenburger Tor, um auf die wachsende Gefahr eines neuen Krieges aufmerksam zu machen.
<G-vec00562-002-s255><draw_up.machen><en> We would like to draw your attention to our rules for your four-legged friends.
<G-vec00562-002-s255><draw_up.machen><de> Gern möchten wir Sie auf unsere Spielregeln für Ihren Vierbeiner aufmerksam machen.
<G-vec00562-002-s256><draw_up.machen><en> That’s why we want to draw some attention to this with what we share here on this website and hope that we can be helpful for you.
<G-vec00562-002-s256><draw_up.machen><de> Deshalb möchten wir mit dem, was wir hier auf dieser Webseite teilen, ein bisschen darauf aufmerksam machen und hoffen, dass wir euch eine Hilfe sein können.
<G-vec00562-002-s257><draw_up.machen><en> The InformNapalm international volunteer community’s publication tries to draw attention of the French citizens, the media and politicians to the facts of participation of the French residents in the illegal activities against Ukraine.
<G-vec00562-002-s257><draw_up.machen><de> Mit dieser Publikation möchte die internationale Freiwilligengemeinschaft InformNapalm die französischen Bürger, Medien und Politiker auf die Belege für die Involvierung von Franzosen in rechtswidrige Handlungen gegen die Ukraine aufmerksam machen.
<G-vec00562-002-s258><draw_up.machen><en> The markers have a chisel tip with which you can draw lasting lines varying in thickness from 1 to 5 mm.
<G-vec00562-002-s258><draw_up.machen><de> Die Marker haben eine schräge Spitze, mit der Sie dauerhafte Linien mit einer Stärke von 1 bis 5 mm machen können.
<G-vec00562-002-s259><draw_up.machen><en> We can draw their attention to the importance of recognizing the work of Jesus on the cross and to make use of it for themselves and through this to undertake the actual step to get out from the world of darkness, out of that part of the spiritual world, where the incomplete spirits go so that they then can reach the world of dawn and from there can then completely leave the world of darkness and reach the world of light, and finally be happy and free and complete; and become free forever from matter and from the imprisonment in it.
<G-vec00562-002-s259><draw_up.machen><de> Wir können sie auf die Wichtigkeit aufmerksam machen, das Werk Jesus am Kreuz anzuerkennen und für sich selbst nutzbar zu machen und dadurch den eigentlichen Schritt zu unternehmen, da aus der Welt der Finsternis herauszukommen, aus dem Teil der geistigen Welt, wohin die unvollkommenen Geister hinkommen, damit die dann in die Welt der Dämmerung gelangen können und von da aus dann ganz die Welt der Dunkelheit verlassen können und in die Welt des Lichtes gelangen, und endlich glücklich werden, und frei, und vollkommen; und für immer frei werden von der Materie und von der Gefangenschaft in ihr.
<G-vec00562-002-s260><draw_up.machen><en> He will apply all means to draw them off me, but my servants recognize and see through him.
<G-vec00562-002-s260><draw_up.machen><de> Er wird alle Mittel anwenden, um sie Mir abtrünnig zu machen, doch Meine Diener erkennen und durchschauen ihn.
<G-vec00562-002-s261><draw_up.machen><en> You may print off one copy, and may download extracts, of any page(s) from our Website for your personal reference and you may draw the attention of others within your organisation to material posted on our Website.
<G-vec00562-002-s261><draw_up.machen><de> Sie dürfen eine Kopie von beliebigen Seiten auf unserer Website zur persönlichen Nutzung ausdrucken oder Auszüge daraus herunterladen und Sie können andere in Ihrer Organisation auf Materialien aufmerksam machen, die auf unserer Website veröffentlicht sind.
<G-vec00562-002-s262><draw_up.machen><en> At a recent protest against the Pamplona bull run, a British woman used her boobs to draw attention to animal rights.
<G-vec00562-002-s262><draw_up.machen><de> Bei einem Protest gegen den Stierlauf von Pamplona hat eine Frau ihre Brüste gezeigt, um auf Tierrechte aufmerksam zu machen.
<G-vec00562-002-s263><draw_up.machen><en> It is supposed to sound the alarm, to draw attention to flaws in the financial system, and to circulate suggestions for improvements if anything goes wrong.
<G-vec00562-002-s263><draw_up.machen><de> Es soll "Alarm" rufen, auf Mängel im Finanzsystem aufmerksam machen und Verbesserungsvorschläge unterbreiten, wenn irgendetwas schiefläuft.
<G-vec00562-002-s264><draw_up.machen><en> “In order to draw attention to Rivella bravely, boldly and loudly, we wanted to inspire people for the brand where they can live out their activities and passion without restriction by stimulating fresh thinking,” explains Andreas Janous, Group Head at follow red, the core of the activation concept.
<G-vec00562-002-s264><draw_up.machen><de> „Um mutig, frech und laut auf Rivella aufmerksam zu machen, wollten wir Menschen dort für die Marke begeistern, wo sie mit Anregung zu frischem Denken ihre Tätigkeit und Leidenschaft uneingeschränkt ausleben können”, erklärt Andreas Janous, Group Head bei follow red den Kern des Aktivierungskonzepts.
<G-vec00562-002-s265><draw_up.machen><en> In the three-day event, there will be some valuable company that can draw attention immediately.
<G-vec00562-002-s265><draw_up.machen><de> Bei der dreitägigen Veranstaltung wird es ein wertvolles Unternehmen geben, das sofort auf sich aufmerksam machen kann.
<G-vec00562-002-s266><draw_up.malen><en> We can draw pictures there too.
<G-vec00562-002-s266><draw_up.malen><de> Wir malen dort auch.
<G-vec00562-002-s267><draw_up.malen><en> €350 Forgiveness In our artists group we were asked to draw a picture that symbolizes what forgiveness feels like.
<G-vec00562-002-s267><draw_up.malen><de> €350 Vergebung In unserer Künstlergruppe sollten wir ein Bild malen, dass für uns Vergebung darstellt.
<G-vec00562-002-s268><draw_up.malen><en> Furthermore he will point out the different motivations of the artist to draw a picture of himself.
<G-vec00562-002-s268><draw_up.malen><de> Außerdem wird er die unterschiedlichen Motiviationen des Künstlers, ein Bild von sich selbst zu malen, herausstellen.
<G-vec00562-002-s269><draw_up.malen><en> Traduceți LiveBoard is a free interactive whiteboard (blackboard) application that allows you to draw, visualize ideas, work together and chat with friends/colleagues in realtime.
<G-vec00562-002-s269><draw_up.malen><de> LiveBoard ist eine kostenlose, interaktive Whiteboard (Tafel) App die es Ihnen erlaubt zu malen, Ideen zu visualisieren, zusammen zu arbeiten und mit Freunden/Kollegen in Echtzeit zu chatten.
<G-vec00562-002-s270><draw_up.malen><en> Learn how to draw and paint from scratch with our video tutorials
<G-vec00562-002-s270><draw_up.malen><de> In unseren Videotutorials erfahren Sie, wie Sie eigene Bilder malen und zeichnen.
<G-vec00562-002-s271><draw_up.malen><en> On the Sabbath day we can write in our journals and write letters to or draw pictures for our relatives, friends, and the missionaries.
<G-vec00562-002-s271><draw_up.malen><de> • Am Sabbat können wir Tagebuch schreiben oder für Verwandte, Freunde oder Missionare einen Brief schreiben oder ein Bild malen.
<G-vec00562-002-s272><draw_up.malen><en> Watch that children do not have an opportunity to draw on your tests with pen.
<G-vec00562-002-s272><draw_up.malen><de> Man sollte aufpassen, dass Kinder nicht die Gelegenheit haben, mit einem Kugelschreiber auf den Testen zu malen.
<G-vec00562-002-s273><draw_up.malen><en> At the moment i like to draw abstract.
<G-vec00562-002-s273><draw_up.malen><de> Momentan hat es mir das abstrakte Malen angetan.
<G-vec00562-002-s274><draw_up.malen><en> In order to complete a painting called "The Rising Sun," for which she received the scholarship, she had to climb to the peak of a mountain by herself during a dark night, so that she could see the true picture of the sunrise and be able to draw it correctly.
<G-vec00562-002-s274><draw_up.malen><de> Um ein Gemälde mit dem Titel „Die aufgehende Sonne“ fertig zu stellen, für das sie das Stipendium erhalten habe, hätte sie in dunkler Nacht auf einen Berggipfel steigen müssen, damit sie den Sonnenaufgang wirklich real sehen und korrekt habe malen können.
<G-vec00562-002-s275><draw_up.malen><en> Product description 603.651.67 Perfect for small children to sit at and play, draw, do crafts or set the table for a cozy picnic in the garden.
<G-vec00562-002-s275><draw_up.malen><de> -Perfekt für die Kleinen, wenn sie zum Spielen, Malen oder Basteln Platz nehmen oder wenn sie ein Picknick im Garten veranstalten wollen.
<G-vec00562-002-s276><draw_up.malen><en> Have each child draw a picture of himself or herself doing a Sabbath activity.
<G-vec00562-002-s276><draw_up.malen><de> Lassen Sie jedes Kind ein Bild von dem malen, was es am Sabbat tun will.
<G-vec00562-002-s277><draw_up.malen><en> I had to draw them as they are really strange - they look like aliens in a way.
<G-vec00562-002-s277><draw_up.malen><de> Ich musste sie sofort malen - sie schauen ein wenig wie Ausserirdische aus.
<G-vec00562-002-s278><draw_up.malen><en> New pattern brushes and vector brush smoothing give you more expressive ways to draw inside Animate.
<G-vec00562-002-s278><draw_up.malen><de> Mit neuen Musterpinseln und Glättung für vektorbasierte Pinsel malen Sie ausdrucksstarke Bilder in Animate.
<G-vec00562-002-s279><draw_up.malen><en> Give the children paper and crayons or pencils and let them draw pictures of ways they can show love for others by being kind.
<G-vec00562-002-s279><draw_up.malen><de> Teilen Sie Papier und Stifte an die Kinder aus und lassen Sie die Kinder ein Bild davon malen, wie sie anderen ihre Liebe zeigen, indem sie nett und freundlich sind.
<G-vec00562-002-s280><draw_up.malen><en> When children draw roof tiles they generally choose the form of the fish-scale tile with its characteristic rounded ends.
<G-vec00562-002-s280><draw_up.malen><de> Malen Kinder einen Dachziegel, so wählen sie in der Regel die Form des Biberschwanzziegels – mit seiner prägnanten Rundung am Ende.
<G-vec00562-002-s281><draw_up.malen><en> I always loved to draw as a child.
<G-vec00562-002-s281><draw_up.malen><de> Ich mochte es als Kind immer zu malen.
<G-vec00562-002-s282><draw_up.malen><en> In this way, we can not only draw flat colours onto the virtual canvas, but can also create reliefs on the surface.
<G-vec00562-002-s282><draw_up.malen><de> Auf diese Weise können wir auf die virtuelle Leinwand nicht nur flache Farben malen, sondern auch Reliefs auf ihr erstellen.
<G-vec00562-002-s283><draw_up.malen><en> Instead there’s a huge sun in a really, really huge sky, like a three-year-old child might draw.
<G-vec00562-002-s283><draw_up.malen><de> Stattdessen scheint dort eine gewaltige Sonne in einem überlebensgroßen Himmel, so wie ein dreijähriges Kind sie malen würde.
<G-vec00562-002-s284><draw_up.malen><en> Draw a line along the upper edge of the eyelashes with the eyeshadow pencil.
<G-vec00562-002-s284><draw_up.malen><de> Malen Sie mit dem Lidschattenstift eine Linie entlang des oberen Wimpernrandes auf.
<G-vec00562-002-s323><draw_up.schöpfen><en> Moreover, just as we can draw upon beauty, desires and dreams can also provide growth to projects that have a soul.
<G-vec00562-002-s323><draw_up.schöpfen><de> Und genau so, wie man aus dem Schönen schöpfen kann, können auch Wünsche und Träume Projekte kreieren, die eine Seele haben.
<G-vec00562-002-s324><draw_up.schöpfen><en> Crosses that can be removed only by shouldering them, thus forcing us to draw from a Source of strength other than our own.
<G-vec00562-002-s324><draw_up.schöpfen><de> Kreuze, die nur bewältigt werden indem wir sie schultern und die uns zwingen aus einer anderen Kraftquelle als unserer eigenen zu schöpfen.
<G-vec00562-002-s325><draw_up.schöpfen><en> “A woman from Samaria came to draw water.
<G-vec00562-002-s325><draw_up.schöpfen><de> 7Kommt eine Frau aus Samarien, um Wasser zu schöpfen.
<G-vec00562-002-s326><draw_up.schöpfen><en> 24:19 When she had done giving him drink, she said, "I will also draw for your camels, until they have done drinking."
<G-vec00562-002-s326><draw_up.schöpfen><de> 24:19 Und da sie ihm zu trinken gegeben hatte, sprach sie: Ich will deinen Kamelen auch schöpfen, bis sie alle getrunken.
<G-vec00562-002-s327><draw_up.schöpfen><en> In this they will be able to draw on extensive resources, as the majority of perspectives are themselves covered by the expertise from the MGG network.
<G-vec00562-002-s327><draw_up.schöpfen><de> Dabei werden sie aus dem Vollen schöpfen, denn die meisten Perspektiven werden durch die Expertise aus dem MGG-Netzwerk selbst abgedeckt.
<G-vec00562-002-s328><draw_up.schöpfen><en> You can gain the ability to draw on the strength of your spirit through the physical body, which will be more important than ever before.
<G-vec00562-002-s328><draw_up.schöpfen><de> Ihr könnt die Fähigkeiten erwerben, mit eurem physischen Körper Kraft aus eurem Geist zu schöpfen; dies wird wichtiger sein als je zuvor.
<G-vec00562-002-s329><draw_up.schöpfen><en> At the beginning, children and adolescents draw paper by hand just as they did before the industrial revolution.
<G-vec00562-002-s329><draw_up.schöpfen><de> Zu Beginn schöpfen die Kinder und Jugendlichen Papier von Hand, so wie man es vor der industriellen Revolution fertigte.
<G-vec00562-002-s330><draw_up.schöpfen><en> 19 After she had given him a drink, she said, "I'll draw water for your camels too, until they have had enough to drink."
<G-vec00562-002-s330><draw_up.schöpfen><de> 19 Und da sie ihm zu trinken gegeben hatte, sprach sie: Ich will deinen Kamelen auch schöpfen, bis sie alle getrunken haben.
<G-vec00562-002-s331><draw_up.schöpfen><en> Let us go.” So they went to the city where the man of the true God was. 11 While they were going up the ascent to the city, they met girls going out to draw water.
<G-vec00562-002-s331><draw_up.schöpfen><de> 11 Während sie die Steige zur Stadt hinaufgingen, fanden sie Mädchen, die hinausgingen, um Wasser zu schöpfen.+ Da sagten sie zu ihnen: „Ist der Seher+ an diesem Ort?“ 12 Darauf antworteten sie ihnen und sprachen: „Ja.
<G-vec00562-002-s332><draw_up.schöpfen><en> When she had given him a drink, she said, “I’ll draw water for your camels, too, until they have had enough to drink.”
<G-vec00562-002-s332><draw_up.schöpfen><de> 19 Und als sie ihm genug zu trinken gegeben hatte, sprach sie: Ich will auch für deine Kamele schöpfen, bis sie genug getrunken haben.
<G-vec00562-002-s333><draw_up.schöpfen><en> 24:20 And she hasted, and emptied her pitcher into the gutter, and ran again unto the well to draw water, and drew for all his camels.
<G-vec00562-002-s333><draw_up.schöpfen><de> 20 Und eilte und goß den Krug aus in die Tränke und lief abermals zum Brunnen, zu schöpfen, und schöpfte allen seinen Kamelen.
<G-vec00562-002-s334><draw_up.schöpfen><en> Then you will obviously feel my help; then you will also give me possibilities through your faith and your love towards fellowmen, to reveal myself to you, so that you are certain of my perpetual presence and can draw power for every activity out of this awareness.
<G-vec00562-002-s334><draw_up.schöpfen><de> Dann werdet ihr Meine Hilfe offensichtlich spüren, dann werdet ihr Mir auch durch euren Glauben und eure Liebe zu den Mitmenschen Möglichkeit geben, Mich euch zu offenbaren, auf daß ihr Meiner immerwährenden Gegenwart gewiß seid und aus diesem Bewußtsein Kraft schöpfen könnet für jegliche Tätigkeit.
<G-vec00562-002-s335><draw_up.schöpfen><en> She hurried, and emptied her pitcher into the trough, and ran again to the well to draw, and drew for all his camels.
<G-vec00562-002-s335><draw_up.schöpfen><de> Und sie eilte und goß ihren Krug aus in die Tränkrinne, lief noch einmal zum Brunnen, um zu schöpfen, und schöpfte so für alle seine Kamele.
<G-vec00562-002-s336><draw_up.schöpfen><en> Draw new strength.
<G-vec00562-002-s336><draw_up.schöpfen><de> Neue Kraft schöpfen.
<G-vec00562-002-s337><draw_up.schöpfen><en> For the eternal Deity's activity will be noticeable there, pure love will refine people and turn their eyes towards heaven, they will recognise God, the Lord, by virtue of their inherently active love which is divine after all, and from this realisation they will draw the strength to overcome all difficulties in life....
<G-vec00562-002-s337><draw_up.schöpfen><de> Denn es wird dort das Wirken der ewigen Gottheit spürbar sein, es wird die reine Liebe die Menschen veredeln und ihren Blick nach oben wenden, sie werden Gott, den Herrn, erkennen kraft der in ihnen wirkenden Liebe, die doch göttlich ist, und sie werden aus dieser Erkenntnis die Kraft schöpfen, alles Schwere im Leben zu überwinden....
<G-vec00562-002-s338><draw_up.schöpfen><en> “… If there be those throughout the Church who by word or act have denied the faith, I pray that you may draw comfort and resolution from the example of Peter, who, though he had walked daily with Jesus, in an hour of extremity momentarily denied the Lord and also the testimony which he carried in his own heart.
<G-vec00562-002-s338><draw_up.schöpfen><de> … Wenn es innerhalb der Kirche Menschen gibt, die – durch Wort und Tat – den Glauben geleugnet haben, dann bete ich darum, daß sie aus dem Beispiel des Petrus Trost schöpfen und zu neuer Entschlußkraft angeregt werden, denn obwohl er ja jeden Tag mit Jesus zusammengewesen war, leugnete er in einer Stunde, als er großem Druck ausgesetzt war, den Herrn und auch das Zeugnis, das er im Herzen trug.
<G-vec00562-002-s339><draw_up.schöpfen><en> Frédéric Moser and Philippe Schwinger draw on a repertoire of imagery that embraces media events and war reporting, but also independent film and fringe theatre.
<G-vec00562-002-s339><draw_up.schöpfen><de> Frédéric Moser und Philippe Schwinger schöpfen aus einem Bildrepertoire, das Medien- oder Kriegsereignisse ebenso umfasst wie das Independent-Kino und alternative Theater.
<G-vec00562-002-s340><draw_up.schöpfen><en> 15 The woman says to Him, Sir, give me this Water so that I neither thirst nor come here to draw.
<G-vec00562-002-s340><draw_up.schöpfen><de> Da sagte die Frau zu ihm: Herr, gib mir dieses Wasser, damit ich keinen Durst mehr habe und nicht mehr hierher kommen muss, um Wasser zu schöpfen.
<G-vec00562-002-s341><draw_up.schöpfen><en> That in today's argument about the interpretation of the Council this fundamental principle of 'Ad fontes' is de facto evaded by revisionist circles, by again wanting to draw the church's identity only from the Tridentine tradition, is a dangerous stupidity.
<G-vec00562-002-s341><draw_up.schöpfen><de> Dass im heutigen Kampf um die Interpretation des Konzils von revisionistischen Kreisen dieses Grundprinzip des ad fontes faktisch unterlaufen wird, indem sie die Identität der Kirche wieder allein aus der tridentinischen Tradition schöpfen wollen, ist eine gefährliche Dummheit.
<G-vec00562-002-s494><draw_up.zeichnen><en> The system will automatically draw various types of charts on the basis of these information each month.
<G-vec00562-002-s494><draw_up.zeichnen><de> Das System zeichnet automatisch verschiedene Arten von Diagrammen aufgrund von diesen Informationen jeden Monat.
<G-vec00562-002-s495><draw_up.zeichnen><en> While it might take a raster image 1000 pixels to show the length of a line from point A to point B, a vector graphic of the same line would just plot the two end points and calculate the distance between them to draw the line.
<G-vec00562-002-s495><draw_up.zeichnen><de> Der Unterschied zwischen einer Vektorgrafik und einem Rasterbild ist einfach erklärt: Während ein Rasterbild 1.000 Pixel benötigt, um die Länge einer Linie von Punkt A zu Punkt B darzustellen, zeichnet eine Vektorgrafik lediglich die beiden Endpunkte und berechnet den Abstand zwischen beiden, um diesen als Linie abzubilden.
<G-vec00562-002-s496><draw_up.zeichnen><en> And today we will tell you how to draw it with colored pencils.
<G-vec00562-002-s496><draw_up.zeichnen><de> Und heute erzählen wir Ihnen, wie man es mit Buntstiften zeichnet.
<G-vec00562-002-s497><draw_up.zeichnen><en> ...... You see more if you draw a net and show all the sides of the cube.
<G-vec00562-002-s497><draw_up.zeichnen><de> ...... Man erkennt mehr, wenn man ein Netz zeichnet und so alle sechs Seitenflächen sichtbar macht.
<G-vec00562-002-s498><draw_up.zeichnen><en> How to draw a Sponge Bob step by step ..
<G-vec00562-002-s498><draw_up.zeichnen><de> Wie man einen Sponge Bob Schritt für Schritt zeichnet ..
<G-vec00562-002-s499><draw_up.zeichnen><en> People who draw, document: the time which passes while drawing.
<G-vec00562-002-s499><draw_up.zeichnen><de> Wer zeichnet, dokumentiert: Die Zeit, die währenddessen verstreicht.
<G-vec00562-002-s500><draw_up.zeichnen><en> ...and explains the stereographic projection: how to draw a map of the world.
<G-vec00562-002-s500><draw_up.zeichnen><de> ...und erklärt die stereografische Projektion: Wie man eine Weltkarte zeichnet.
<G-vec00562-002-s501><draw_up.zeichnen><en> Draw a plane instead of using an existing surface as the base objects.
<G-vec00562-002-s501><draw_up.zeichnen><de> Zeichnet eine Ebene anstatt dass eine bestehende Fläche als Basisobjekt verwendet wird.
<G-vec00562-002-s502><draw_up.zeichnen><en> Now take a Golden shadow and draw them thick strip in the middle of the eye.
<G-vec00562-002-s502><draw_up.zeichnen><de> Jetzt nehmen wir die Goldenen Schatten und zeichnet Sie einen dicken Streifen in der Mitte des Auges.
<G-vec00562-002-s503><draw_up.zeichnen><en> The person who manages to draw the best baby wins.
<G-vec00562-002-s503><draw_up.zeichnen><de> Wer das Baby am besten zeichnet, gewinnt.
<G-vec00562-002-s504><draw_up.zeichnen><en> How to draw Dora the explorer
<G-vec00562-002-s504><draw_up.zeichnen><de> Wie zeichnet man Dora aus der Zeichentrickserie...
<G-vec00562-002-s505><draw_up.zeichnen><en> Yes, no, the roller itself does not draw patterns, but it is possible to combine textures, combining with other methods of application.
<G-vec00562-002-s505><draw_up.zeichnen><de> Ja, nein, die Rolle selbst zeichnet keine Muster, aber es ist möglich, Texturen zu kombinieren, die sich mit anderen Anwendungsmethoden kombinieren lassen.
<G-vec00562-002-s506><draw_up.zeichnen><en> Furthermore, she likes to draw animals – mainly cats.
<G-vec00562-002-s506><draw_up.zeichnen><de> Ausserdem zeichnet sie gerne Tiere – hauptsächlich Katzen.
<G-vec00562-002-s507><draw_up.zeichnen><en> Perhaps you will not become a famous artist, butlearn the basics and learn how to draw simple things quite realistically.
<G-vec00562-002-s507><draw_up.zeichnen><de> Vielleicht wirst du kein berühmter Künstler werden, aberErlernen Sie die Grundlagen und lernen Sie, wie man einfache Dinge realistisch zeichnet.
<G-vec00562-002-s508><draw_up.zeichnen><en> If this value is set too low, the engine possibly may not draw all bounding boxes any more.
<G-vec00562-002-s508><draw_up.zeichnen><de> Ist dieser Wert zu niedrig gesetzt, zeichnet die Engine möglicherweise nicht mehr alle Bounding-Boxen.
<G-vec00562-002-s509><draw_up.zeichnen><en> In a next step, you draw again this way a little bit harder along the contours, so that the subject is gradually emerging from the clutter of lines.
<G-vec00562-002-s509><draw_up.zeichnen><de> Anschließend zeichnet man wieder und dieses mal etwas härter den Konturen entlang, so dass sich nach und nach aus dem Gewirr von Strichen das Motiv abzeichnet.
<G-vec00562-002-s510><draw_up.zeichnen><en> Callback function used to draw on the screen every frame.
<G-vec00562-002-s510><draw_up.zeichnen><de> Eine Rückruffunktion, welche in jeden Frame den Bildschirminhalt zeichnet.
<G-vec00562-002-s511><draw_up.zeichnen><en> With a special pen, he will draw an accurate draft onto the skin.
<G-vec00562-002-s511><draw_up.zeichnen><de> Mit einem Stift zeichnet er dazu eine exakte Skizze auf die Haut.
<G-vec00562-002-s512><draw_up.zeichnen><en> This simple lesson will help you learn and learn how to draw a spider with pencils. You will have the opportunity to choose which spider you are drawing - scary or funny.
<G-vec00562-002-s512><draw_up.zeichnen><de> In dieser einfachen Lektion lernen Sie, wie man eine Spinne mit Bleistiften zeichnet und lernt, welche Spinne Sie zeichnen - gruselig oder lustig.
