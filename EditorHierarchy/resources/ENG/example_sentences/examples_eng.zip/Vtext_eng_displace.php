<G-vec00555-002-s012><displace.ausbooten><en> In the United States, the right-wing demagogue Donald Trump has managed to displace the Republican establishment, while the leftist Bernie Sanders was unable to overtake the centrist Hillary Clinton.
<G-vec00555-002-s012><displace.ausbooten><de> In den USA ist es dem rechten Demagogen Donald Trump gelungen, das republikanische Establishment auszubooten, während es der Linke Bernie Sanders nicht geschafft hat, die gemäßigte Hillary Clinton zu überrunden.
<G-vec00555-002-s013><displace.bedrängen><en> Many pathogens and parasites displace the plants and cause enormous damage.
<G-vec00555-002-s013><displace.bedrängen><de> Viele Krankheitserreger und Parasiten bedrängen die Pflanzen und verursachen enorme Schäden.
<G-vec00555-002-s014><displace.bewegen><en> Your body has to be flexible to displace the centre of gravity.
<G-vec00555-002-s014><displace.bewegen><de> Der Körper soll flexibel sein, um den Schwerpunkt zu bewegen.
<G-vec00555-002-s019><displace.entheben><en> Although the presentation of the postcards takes place within the classical art scene, the photographers displace their work from this strongly regulated scene, by using this form of presentation.
<G-vec00555-002-s019><displace.entheben><de> Obwohl die Präsentation der Fotografien im Rahmen des klassischen Kunstbetriebs erfolgt, entheben die Fotografen ihre Arbeiten diesem stark reglementierten Betrieb durch die Form der Präsentation.
<G-vec00555-002-s016><displace.ersetzen><en> Co-author Jeffery Sobal simply stated that, “it is not clear whether women are using this particular strategy to increase feelings of fullness, avoid the consumption of other foods, or displace higher calorie beverages.” It’s notable, however, that drinking excessive amounts of water (or “fluid loading”) is a common symptom of eating disorders.
<G-vec00555-002-s016><displace.ersetzen><de> Co-Autor Jeffery Sobal sagte nur, dass „es nicht klar ist, ob die Frauen diese spezielle Methode benutzten, um das Völlegefühl zu steigern, andere Nahrungsmittel damit zu ersetzen, oder kalorienreiche Getränke gegen Wasser austauschten.“ Es muss aber angemerkt werden, dass der exzessive Konsum von Wasser (oder „fluid loading“) ein verbreitetes Symptom von Essstörungen ist.
<G-vec00555-002-s022><displace.fortbewegen><en> 4 Interestingly enough, physicists also say that the wave movement does not displace matter.
<G-vec00555-002-s022><displace.fortbewegen><de> 4 Seltsamerweise sagen auch die Physiker, daß eine Wellenbewegung die Materie nicht fortbewegt.
<G-vec00555-002-s011><displace.verdrängen><en> Displace the water with 2000 ml isopropanol/water mixture (5.3.3) at a rate of 10-30 ml/min.
<G-vec00555-002-s011><displace.verdrängen><de> Anschließend verdrängt man das Wasser mit 2000 ml Isopropanol-Wasser-Gemisch (5.3.3), ebenfalls bei einer Durchlaufgeschwindigkeit von 10-30 ml/min.
<G-vec00555-002-s056><displace.verlegen><en> These movements could damage or displace your leads or affect the neurostimulator's ability to provide stimulation.
<G-vec00555-002-s056><displace.verlegen><de> Diese Bewegungen können Ihre Leitungen schädigen, verlegen oder die Fähigkeit des Neurostimulators zur Stimulation beeinträchtigen.
<G-vec00555-002-s057><displace.vernachlässigen><en> Prince must alternate studying with physical activity, without allowing the latter to displace his duties as a student.
<G-vec00555-002-s057><displace.vernachlässigen><de> Prince muss lernen mit körperlicher Aktivität abzuwechseln, ohne dem Letzteren zu erlauben die Pflichten als Schüler zu vernachlässigen.
<G-vec00555-002-s058><displace.verscheuchen><en> The end of the Üouö overture - harmonious and somewhere between Ambros and Biermösl Blosn - can't quite displace an uneasy feeling.
<G-vec00555-002-s058><displace.verscheuchen><de> Und auch der Abschluss der Üouö betitelten Ouvertüre - harmonisch und irgendwo zwischen Ambros und Biermösl Blosn - kann ein ungutes Gefühl nicht ganz verscheuchen.
<G-vec00555-002-s062><displace.verschieben><en> As already mentioned, to argue against the impossibility archiving dance implies a discoursive move that will insist on the futurity of choreographic traces, their potentiality to displace normative bodies.
<G-vec00555-002-s062><displace.verschieben><de> Wie schon erwähnt setzt das Widerlegen der Behauptung, man könne Tanz nicht archivieren, einen diskursiven Wandel voraus, der die Zukünftigkeit choreografischer Spuren betont und ihr Potenzial, normative Körper zu verschieben vermag.
<G-vec00555-002-s066><displace.versetzen><en> The centrifugal forces which the motor generates displace the working device (conduit, table, shaped form) and the conveyed material mass by means of vibrations.
<G-vec00555-002-s066><displace.versetzen><de> Die Fliehkräfte, die der Motor erzeugt, versetzen das Nutzgerät (Rinne, Tisch, Form) und die Fördergutmasse in Schwingungen.
<G-vec00555-002-s067><displace.versetzten><en> Ultrasonic cleaners displace the water in the device with high-frequency vibrations.
<G-vec00555-002-s067><displace.versetzten><de> Ultraschallreiniger versetzten das Wasser in dem Gerät in hochfrequente Schwingungen.
<G-vec00555-002-s072><displace.vertreiben><en> Their advance is heralded by encroaching mists no wind can displace, trees twisting and buckling as though in agony, and a gathering darkness of supernatural perpetuity.
<G-vec00555-002-s072><displace.vertreiben><de> Ihr Vorrücken wird durch heran wallenden Nebel angekündigt, den kein Wind vertreiben kann, durch Bäume, die sich wie im Todeskampf verdrehen und verbiegen und durch eine heraufziehende Dunkelheit von übernatürlicher Dauer.
<G-vec00555-002-s051><displace.wegschaffen><en> We do everything to get things that hurt us ignore, to displace them to carry away it from our lives.
<G-vec00555-002-s051><displace.wegschaffen><de> Wir tun alles um Dinge die uns verletzen zu ignorieren, sie zu verdrängen, es aus unserem Leben wegzuschaffen.
