<G-vec00444-002-s042><ensue.folgen><en> If bare skin were hit, bad wounds would ensue.
<G-vec00444-002-s042><ensue.folgen><de> Wenn nackte Haut getroffen würde, wären schlimme Wunden die Folge.
