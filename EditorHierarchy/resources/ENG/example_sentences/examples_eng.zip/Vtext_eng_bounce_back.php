<G-vec00390-003-s024><bounce_back.abprallen><en> It will soon become part of you and negative suggestions will just bounce off you, even your own negative suggestions.
<G-vec00390-003-s024><bounce_back.abprallen><de> Es wird bald ein Teil von ihnen werden und negative Beeinflussungen werden einfach von Ihnen abprallen, sogar Ihre eigenen negativen Suggestionen.
<G-vec00390-003-s025><bounce_back.abprallen><en> Individual molecules may strike one another and bounce off like billiard balls without being deformed in any way.
<G-vec00390-003-s025><bounce_back.abprallen><de> Einzelne Moleküle könnten aufeinander stoßen und wie Billardkugeln abprallen, ohne auf irgendeine Art deformiert zu werden.
<G-vec00390-003-s026><bounce_back.abprallen><en> You can destroy the target with direct hit or use various surfaces to make the bullet bounce according to the needed trajectory.
<G-vec00390-003-s026><bounce_back.abprallen><de> Deine Ziele kannst du mit einem direkten Treffer zerstören oder verschiedene Oberflächen verwenden, von denen die Kugel abprallen kann.
<G-vec00390-003-s027><bounce_back.abprallen><en> In a downtrend, price can come up to or near the pivot and then bounce off and head towards the Support levels as a daily profit target.
<G-vec00390-003-s027><bounce_back.abprallen><de> In einem Downtrend kann der Kurs bis/nahe an den Pivot heran reichen und dann in Richtung der Unterstützungslevel als Tagesprofitziel abprallen.
<G-vec00390-003-s028><bounce_back.abprallen><en> Automation sensors can also sometimes bounce off a base if it’s not textured.
<G-vec00390-003-s028><bounce_back.abprallen><de> Automatisierungssensoren können manchmal auch von einer Basis abprallen, wenn sie nicht texturiert sind.
<G-vec00390-003-s029><bounce_back.abprallen><en> It emits impulses, which then bounce off and then come back.
<G-vec00390-003-s029><bounce_back.abprallen><de> Es sendet Impulse aus, die dann abprallen und dann zurück kommen.
<G-vec00390-003-s030><bounce_back.abprallen><en> The grenade can bounce off walls and uses mp.
<G-vec00390-003-s030><bounce_back.abprallen><de> Die Granate kann an Wänden abprallen und nutzt MP.
<G-vec00390-003-s031><bounce_back.abprallen><en> There is no exact science to determine which level price will bounce or if price will bounce off any of the levels at all.
<G-vec00390-003-s031><bounce_back.abprallen><de> Es gibt keine exakte Wissenschaft, die bestimmt, ab welchem Level der Kurs oder ob der Kurs überhaupt von einem dieser Levels abprallen wird.
<G-vec00390-003-s032><bounce_back.abprallen><en> The harmful emotional energies thrown at you will bounce off and help to keep you calm.
<G-vec00390-003-s032><bounce_back.abprallen><de> Die schädlichen emotionalen Energien, die in Deine Richtung geworfen werden, werden abprallen und Dir helfen, die Ruhe zu bewahren.
<G-vec00390-003-s033><bounce_back.abprallen><en> The use of thermoplastic polyurethane – reduces absorption of water and improves elasticity of the external surface of the ball, which ensures the right bounce.
<G-vec00390-003-s033><bounce_back.abprallen><de> Verwendung von TPU– reduziert die Wasserabsorption und erhöht die Flexibilität der äußeren Fußball-Schicht, was ein gutes Abprallen gewährleistet.
<G-vec00390-003-s034><bounce_back.abprallen><en> You and all who listen to you and want to serve me will now speak with tongues of angels and everything will bounce off them because now they also know that they have to hold out only a short time to be blessed; they know that well all formalities can stagger but never the church that Jesus Christ founded on earth - the true church, that cannot be conquered by the gates of hell.
<G-vec00390-003-s034><bounce_back.abprallen><de> Ihr, und alle, die euch anhören und Mir dienen wollen, werden nun reden mit Engelszungen, und an ihnen wird alles abprallen, denn nun wissen sie auch, daß sie nur eine kurze Zeit ausharren müssen, um selig zu werden, sie wissen, daß wohl alles Äußerliche wanken kann, niemals aber die Kirche, die Jesus Christus auf Erden gegründet hat - die wahre Kirche, die nicht von den Pforten der Hölle überwunden werden kann.
<G-vec00390-003-s035><bounce_back.abprallen><en> Conversely, if an incoming vehicle hit the thermosphere at too shallow an angle, it could well bounce back into space, like a pebble skipped across water.
<G-vec00390-003-s035><bounce_back.abprallen><de> Ist der Eintrittswinkel in die Thermosphäre dagegen zu klein, kann das Raumschiff auch abprallen und wieder in den Weltraum fliegen wie ein Kiesel, den man flach über das Wasser wirft.
<G-vec00390-003-s036><bounce_back.abprallen><en> When the physics animation speed is too fast, caused by objects that bounce off or objects that are hit by any Kinematic rigid body, then plane penetration may occur.
<G-vec00390-003-s036><bounce_back.abprallen><de> Wenn die Geschwindigkeit der Physik Animation auf Grund von Objekten, die abprallen oder Objekten, die von einem Kinematischen Rigid Body getroffen werden, zu schnell ist, kann es zu dem Durchdringen der Fläche kommen.
<G-vec00390-003-s037><bounce_back.abprallen><en> For creatures with targeted jumps, pressing jump again in midair will result in the tame falling straight down (to prevent erroneous cases where the dino may unintentionally bounce awkwardly)
<G-vec00390-003-s037><bounce_back.abprallen><de> Bei Kreaturen mit gezielten Sprüngen führt ein erneuter Druck auf den Sprung in der Luft dazu, dass das Gezähmte geradewegs nach unten fällt (um fehlerhafte Fälle zu vermeiden, in denen der Dino unbeabsichtigt unbeabsichtigt unangenehm abprallen kann).
<G-vec00390-003-s038><bounce_back.abprallen><en> Physics objects with higher Mass value can cause the ones with lower Mass value to bounce off more when they bump each other.
<G-vec00390-003-s038><bounce_back.abprallen><de> Physik Objekte mit einem größeren Masse Wert können verursachen, dass Objekte mit geringerer Masse, abprallen, wenn beide zusammenstoßen.
<G-vec00390-003-s039><bounce_back.abprallen><en> Even though the frontal plate may bounce some shells, relying on it is risky at best.
<G-vec00390-003-s039><bounce_back.abprallen><de> Obwohl einige Granaten von der Frontplatte abprallen können, ist es ziemlich riskant, sich darauf zu verlassen.
<G-vec00390-003-s040><bounce_back.abspringen><en> Visitors that bounce immediately (which you don’t want) when the old website gets forwarded they realize, “This isn’t the site I was looking for.”
<G-vec00390-003-s040><bounce_back.abspringen><de> Besucher, die sofort abspringen (was Sie nicht wollen), wenn die alte Webseite weitergeleitet wird, merken: „Das ist nicht die Seite, nach der ich gesucht habe“.
<G-vec00390-003-s041><bounce_back.abspringen><en> The ball should not bounce too high or too low, should not be too fast or too slow, and a ball hit at an angle should not rebound steeply, nor should it skid quickly off the surface.
<G-vec00390-003-s041><bounce_back.abspringen><de> Der Ball sollte weder zu hoch noch zu tief abspringen, weder zu schnell noch zu langsam sein und weder zu steil noch zu flach wegspringen.
<G-vec00390-003-s042><bounce_back.abspringen><en> When people bounce, it’s bad for your rankings.
<G-vec00390-003-s042><bounce_back.abspringen><de> Wenn Besucher abspringen ist das schlecht fürs Ranking.
<G-vec00390-003-s043><bounce_back.abspringen><en> Having contacts that constantly bounce and just plain not open your emails is like cancer to your list.
<G-vec00390-003-s043><bounce_back.abspringen><de> Kontakte zu haben, die ständig abspringen und Ihre E-Mails einfach nicht öffnen sind furchtbar für Ihre Liste.
<G-vec00390-003-s117><bounce_back.erholen><en> ZACA ELECTROLYTE RECOVERY is a natural remedy that helps you bounce back faster.
<G-vec00390-003-s117><bounce_back.erholen><de> ZACA KATER ERHOLUNG ist eine natürliches Heilmittel gegen Kater, das Ihrem Körper hilft sich nach übermäßigem Alkoholgenuss schneller zu erholen.
<G-vec00390-003-s118><bounce_back.erholen><en> Many people with depression wind up withdrawing from friends, family, and loved ones, but support form these loved ones can be one of the best ways to bounce back from depression.
<G-vec00390-003-s118><bounce_back.erholen><de> Viele Menschen mit einer Depression ziehen sich von Freunden, ihrer Familie und ihren Lieben zurück, aber Unterstützung von diesen Menschen kann eine der besten Möglichkeiten sein, sich von einer Depression zu erholen.
<G-vec00390-003-s119><bounce_back.erholen><en> Their opponents tried to bounce back but they just didn’t have the firepower.
<G-vec00390-003-s119><bounce_back.erholen><de> Ihre Gegner versuchten sich zu erholen, aber sie hatten einfach nicht die Feuerkraft.
<G-vec00390-003-s120><bounce_back.erholen><en> During this time, the marijuana plant has great recovery properties and we’ll bounce back from problems it may encounter.
<G-vec00390-003-s120><bounce_back.erholen><de> Während dieser Zeit hat die Marihuanapflanze große Erholungseigenschaften und wir werden uns von Problemen erholen, auf die sie stoßen kann.
<G-vec00390-003-s121><bounce_back.erholen><en> Plants are good at handling minor tissue damage and if the plant is healthy, it will bounce right back from the physical damage and even strengthens its resistance.
<G-vec00390-003-s121><bounce_back.erholen><de> Pflanzen sind gut darin mit kleineren Gewebeschäden umzugehen und wenn die Pflanze gesund ist, wird sie sich schnell von dem physikalischen Schaden erholen und wird sogar widerstandsfähiger.
<G-vec00390-003-s122><bounce_back.erholen><en> The concept of resilience has two dimensions: the inherent strength of an entity – an individual, a household, a community or a larger structure – to better resist stress and shock, and the capacity of this entity to bounce back rapidly from the impact.
<G-vec00390-003-s122><bounce_back.erholen><de> Der Begriff der Resilienz hat zwei Aspekte: die eigene Kraft, die es einem Individuum, einem Haushalt, einer Gemeinschaft oder einer größeren Einheit ermöglicht, Belastungen und Schocks standzuhalten, und die Fähigkeit, sich rasch von deren Folgen zu erholen.
<G-vec00390-003-s123><bounce_back.erholen><en> Gripple has the answers, and offers the ideal solutions to bounce back from the halt in construction caused by the COVID-19 crisis.
<G-vec00390-003-s123><bounce_back.erholen><de> Gripple hat die Antworten und bietet die idealen Lösungen, um sich von dem durch die COVID-19-Krise verursachten Baustopp zu erholen.
<G-vec00390-003-s157><bounce_back.hüpfen><en> Bounce the rabbit into all of the floating bricks to make them disappear.
<G-vec00390-003-s157><bounce_back.hüpfen><de> Lass den Hasen auf alle schwebenden Ziegelsteine hüpfen, um sie verschwinden zu lassen.
<G-vec00390-003-s158><bounce_back.hüpfen><en> Bounce the bunny to the tasty carrots.
<G-vec00390-003-s158><bounce_back.hüpfen><de> Lass den Hasen zu den leckeren Karotten hüpfen.
<G-vec00390-003-s168><bounce_back.prallen><en> Some of your airplanes bounce on the tarmac, and the same thing happens for the vehicles around: that’s a known bug, which can be solved by modifying the « Mesh Resolution » to 5m maximum.
<G-vec00390-003-s168><bounce_back.prallen><de> Einige Ihrer Flugzeuge prallen auf dem Asphalt, und das gleiche geschieht für die Fahrzeuge um: das ist ein bekannter Fehler, die durch Modifizierung der «Mesh-Auflösung» zu 5m maximal gelöst werden können.
<G-vec00390-003-s169><bounce_back.prallen><en> Be aware..the bullets bounce back.Play Rabbit Sniper 1.
<G-vec00390-003-s169><bounce_back.prallen><de> Pass auf... die Kugeln prallen hin und wieder zurück.
<G-vec00390-003-s170><bounce_back.prallen><en> To enhance this factor’s powers within our bodies, naturally occurring Hyaluronic Acid is included, as it is seen to boost skin’s elastic qualities and bounce by assisting collagen. Lift
<G-vec00390-003-s170><bounce_back.prallen><de> Um die Kraft dieses Faktors in unserem Körper zu erhöhen, ist natürlich vorkommende Hyaluronsäure enthalten, um die elastischen Eigenschaften der Haut zu fördern und durch die Unterstützung von Kollagen zu prallen.
<G-vec00390-003-s171><bounce_back.prallen><en> The sounds you create will bounce off obstacles, revealing the shape of the surrounding world.
<G-vec00390-003-s171><bounce_back.prallen><de> Die Töne, die Sie verursachen, prallen weg von den Hindernissen auf und decken die Form der umgebenden Welt auf.
<G-vec00390-003-s172><bounce_back.prallen><en> Bullets bounce – If this is ON, then your bullets will not die when they hit a wall. Instead, they will bounce off.
<G-vec00390-003-s172><bounce_back.prallen><de> Kugeln prallen ab – Wenn diese Option aktiviert ist, zerbrechen deine Kugeln nicht, wenn sie auf eine Mauer treffen, sondern prallen einfach ab.
<G-vec00390-003-s173><bounce_back.prallen><en> Be aware..the bullets bounce back.Play Rabbit Sniper 1. Tank Ball 1
<G-vec00390-003-s173><bounce_back.prallen><de> Pass auf... die Kugeln prallen hin und wieder zurück.Rabbit Sniper 1 spielen.
<G-vec00390-003-s174><bounce_back.prallen><en> Chips at temperatures of up to 850 °C just bounce off the energy supply system.
<G-vec00390-003-s174><bounce_back.prallen><de> Späne bis 850 °C prallen an der Energieführung einfach ab.
<G-vec00390-003-s189><bounce_back.schlagen><en> Bounce the ball through the hoops, triangles or...
<G-vec00390-003-s189><bounce_back.schlagen><de> Schlagen Sie den Ball durch die Reifen, Dreiecke oder...
<G-vec00390-003-s190><bounce_back.schlagen><en> Revolt was the rhythm of his breath, as it was freedom that made his heart bounce.
<G-vec00390-003-s190><bounce_back.schlagen><de> Revolte war der Rhythmus seines Atems, so wie es die Freiheit war, die sein Herz schlagen ließ.
<G-vec00390-003-s191><bounce_back.schlagen><en> Bounce the ball on the wall to get the Highscore.
<G-vec00390-003-s191><bounce_back.schlagen><de> Schlagen Sie den Ball an die Wand, um den Highscore zu bekommen.
<G-vec00390-003-s205><bounce_back.springen><en> Bounce on two bouncer scraps without touching the ground.
<G-vec00390-003-s205><bounce_back.springen><de> Springe auf zwei Hüpfschnipseln, ohne den Boden zu berühren.
<G-vec00390-003-s206><bounce_back.springen><en> Grow, bounce and roll through fantastical environments packed with secrets in this musical puzzle platformer.
<G-vec00390-003-s206><bounce_back.springen><de> Wachse, springe und rolle in diesem musikalischen Platformer durch fantastische Umgebungen voller Geheimnisse.
<G-vec00390-003-s256><bounce_back.treffen><en> Help Jerry race through fun-packed levels collecting cheese while avoiding Tom in this classic game of cat and mouse! Extreme Kitten Shoot the kitty out in the playground, tap and bounce objects to travel further.
<G-vec00390-003-s256><bounce_back.treffen><de> Hilf Jerry bei der rasenden Jagd nach dem Käse durch die abwechslungsreichen Ebenen des Katze und Maus Klassikers und vermeide vor allem, dass er Tom trifft.
<G-vec00390-003-s257><bounce_back.treffen><en> This technique also allows for adding one bounce global illumination effects by spawning virtual point light sources where light strikes a surface.
<G-vec00390-003-s257><bounce_back.treffen><de> Diese Technoloige erlaubt auch globale Illuminationseffekte bei einem Aufprall zu erzeugen indem Lichtquellen verteilt werden, wo Licht auf eine Oberfläche trifft.
<G-vec00390-003-s258><bounce_back.treffen><en> If you are too slow then you cannot bounce on the top for the whole section.
<G-vec00390-003-s258><bounce_back.treffen><de> Ist man zu langsam, trifft man nicht auf die Spitzen.
<G-vec00390-003-s264><bounce_back.zeigen><en> At the bounce house you can test your stamina in bad weather, too.
<G-vec00390-003-s264><bounce_back.zeigen><de> Hier könnt ihr übrigens auch bei schlechtem Wetter zeigen, wie viel Puste Ihr habt.
<G-vec00390-003-s265><bounce_back.zeigen><en> Come and watch nude trans hotties bounce their big asses while stroking their dicks for their webcam.
<G-vec00390-003-s265><bounce_back.zeigen><de> Kommen Sie und sehen Sie, wie nackte Trans-Hotties ihre großen Ärsche zeigen, während sie ihre Schwänze für ihre Webcam streicheln.
