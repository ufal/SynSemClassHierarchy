<G-vec00625-002-s044><bleed.ausbluten><en> Note COPIC MULTILINER and COPIC MULTILINER SP ink pens can be used for preliminary drawings and for making outlined Copic drawings because, in contrast to standard inking pens, when they are drawn over with COPIC MARKERS the ink will not smear or bleed.
<G-vec00625-002-s044><bleed.ausbluten><de> Hinweis Zum Vorzeichnen und Erstellen von umrandeten Copic-Zeichnungen eignen sich COPIC MULTILINER und COPIC MULTILINER SP, die im Gegensatz zu normalen Finelinern beim Übermalen mit COPIC MARKERN nicht ausbluten.
<G-vec00625-002-s045><bleed.ausbluten><en> stroke of ink can only bleed when the quality of the paper allows it to flow in narrow spaces.
<G-vec00625-002-s045><bleed.ausbluten><de> Ein Tintenstrich kann nur ausbluten, wenn das Papier aufgrund seiner Qualität in engen Räumen fließen kann.
<G-vec00625-002-s047><bleed.ausbluten><en> Fishes are taken out of the water and, while held manually, their gills or their hearts are cut with a knife so they bleed to death.
<G-vec00625-002-s047><bleed.ausbluten><de> Nachdem die Fische aus dem Wasser geholt wurden, werden sie in der Hand gehalten und ihre Kiemen oder Herzen mit einem Messer entfernt, sodass sie ausbluten.
<G-vec00625-002-s048><bleed.ausbluten><en> 1 Interchangeable lenses for Nikon SLR cameras and Nikon 1 Advanced Camera with Interchangeable Lenses 2 Optical Performance and Total Image Analyzer 3 Aberration occurs when light from one point of an object does not converge into a single point after transmission through an optical system, causing image "bleed" or "blur".
<G-vec00625-002-s048><bleed.ausbluten><de> ¹ Wechselobjektive für Spiegelreflexkameras von Nikon und Abbildungsfehler treten auf, wenn Licht von einem Punkt eines Objekts nicht in einem einzigen Punkt nach der Übertragung durch ein optisches System konvergiert, was sich in "Ausbluten" oder "Unschärfe" zeigt.
<G-vec00625-002-s049><bleed.ausbluten><en> At this point, it is but to complain that the FIFA “Tolerated the particularities of the transfer system in South America despite deviations from the own principles” (rain), reportedly to prevent a bleed out of the market.
<G-vec00625-002-s049><bleed.ausbluten><de> An dieser Stelle ist aber zu monieren, dass die FIFA „Besonderheiten des Transfersystems in Südamerika trotz Abweichungen von den eigenen Grundsätzen toleriert“ (Rain), angeblich um ein Ausbluten des Marktes zu verhindern.
<G-vec00625-002-s050><bleed.ausbluten><en> From the beginning of the latest Mosul operation, IS conducted a counterattack near the city of Kirkuk, in an effort to bleed resources away from the coalition’s efforts against Mosul.
<G-vec00625-002-s050><bleed.ausbluten><de> Zum Beginn der letzten Mossul-Operation führte der IS einen Gegenangriff in der Nähe der Stadt Kirkuk in der Hoffnung durch, die Koalition würde Ressourcen von Mossul abziehen und ausbluten.
<G-vec00625-002-s051><bleed.ausbluten><en> i² technology means the end of defects such as horizontal banding, step mismatch banding, ink mottle and bleed and the visible effects of missing or misfiring nozzles. i² technology benefits
<G-vec00625-002-s051><bleed.ausbluten><de> Die I² Technologie beseitigt viele der für Inkjets typischen Probleme wie Streifenbildung, Tintenflecken und Ausbluten sowie die sichtbaren Effekte von Aussetzern oder fehlerhaften Düsen.
<G-vec00625-002-s052><bleed.ausbluten><en> You can also make faces with the icing on the marshmallows, but depending on the consistency of the icing the color might bleed out into the marshmallows after some time.
<G-vec00625-002-s052><bleed.ausbluten><de> Man kann auch die Gesichter auf den Marshmallows mit dem Icing machen, aber je nachdem wie feucht das Icing ist, kann die Farbe in die Marshmallows ausbluten nach einer gewissen Zeit.
<G-vec00625-002-s053><bleed.ausbluten><en> Once integrated, they can no longer migrate, bleed or be extracted by various media.
<G-vec00625-002-s053><bleed.ausbluten><de> Einmal eingebaut können sie nicht mehr migrieren, ausbluten oder durch verschiedenste Medien extrahiert werden.
<G-vec00625-002-s054><bleed.ausbluten><en> This stain will not bleed or rub off.
<G-vec00625-002-s054><bleed.ausbluten><de> Diese Farbe wird nicht ausbluten und ist abriebfest.
<G-vec00625-002-s055><bleed.ausbluten><en> For example, one Guild Wars 2 warrior might decide to build his character around gradual damage which causes his opponents to bleed out, while another may choose to knock his opponents down, controlling their movement with slow, large attacks.
<G-vec00625-002-s055><bleed.ausbluten><de> Beispiel: Ein Guild Wars 2-Krieger könnte seinen Charakter auf sich stufenweise steigerndem Schaden aufbauen, der den Gegner ausbluten lässt, ein anderer könnte sich auf langsame, heftige Angriffe konzentrieren, die den Gegner zu Boden werfen und so daran hindern, sich zu bewegen.
<G-vec00625-002-s056><bleed.ausbluten><en> Town meetings heard speakers ranging from political theorists discussing issues of representation, down to rabble-rousers predicting a whole raft of British taxation that would eventually bleed them dry.
<G-vec00625-002-s056><bleed.ausbluten><de> In den Stadtversammlungen hörten Redner, die von politischen Theoretikern über Fragen der Repräsentation bis hin zu Hetzern reichten, die eine ganze Reihe britischer Steuern vorhersagten, die sie schließlich ausbluten lassen würden.
<G-vec00625-002-s057><bleed.ausbluten><en> In addition there are famines and population migration, which make the country virtually bleed in some areas.
<G-vec00625-002-s057><bleed.ausbluten><de> Hinzu kommen Hungerkrisen und Bevölkerungsmigration, die das Land in einigen Regionen praktisch ausbluten lassen.
<G-vec00625-002-s058><bleed.ausbluten><en> Despite relatively new, adverse circumstances by various large boat owners who try to bleed the smaller dive schools and wanted to attract strong in the price, Aloha can not get on and off now with much cozier boats and two deluxe dives in the sea.
<G-vec00625-002-s058><bleed.ausbluten><de> Trotz relativ neuer, widriger Umstände durch verschiedene große Bootbesitzer, die versuchen die kleineren Tauchschulen ausbluten zu lassen und kräftig im Preis anziehen wollten, lässt sich Aloha nicht kleinkriegen und sticht jetzt mit wesentlich gemütlicheren Booten und zwei Deluxe Tauchgängen in See.
<G-vec00625-002-s059><bleed.ausbluten><en> The leaders of the European powers were prepared to continue to bleed the continent white and would not have agreed to the armistice without the effect of the Russian Revolution.
<G-vec00625-002-s059><bleed.ausbluten><de> Die Führer der europäischen Mächte waren bereit, den Kontinent weiterhin ausbluten zu lassen und hätten ohne die Auswirkungen der russischen Revolution einem Waffenstillstand nicht zugestimmt.
<G-vec00625-002-s202><bleed.ausbluten><en> Regionally, Saudi Arabia and the United Arab Emirates are now seeking ways to compensate for the loss of Syria as a place where they could defy and bleed Iran.
<G-vec00625-002-s202><bleed.ausbluten><de> „Regional suchen Saudi-Arabien und die Vereinigten Arabischen Emirate nun nach Wegen, den Verlust Syriens an einem Ort auszugleichen, wo sie dem Iran trotzen und ihn ausbluten könnten.
<G-vec00625-002-s241><bleed.ausbluten><en> It wants, instead, to end cross-border terrorism by changing Pakistan's long-held belief that it could "bleed India with a thousand cuts" at low cost to itself and thus bring about a change in the status of Kashmir as part of India.
<G-vec00625-002-s241><bleed.ausbluten><de> Indien strebt vielmehr ein Ende des grenzüberschreitenden Terrorismus an, indem es die langjährige Überzeugung Pakistans attackiert, es könne Indien durch die - kostengünstige - Strategie der "vielen tausend Schnitte" ausbluten und so den Status Kaschmirs als ein Teil von Indien verändern.
<G-vec00625-002-s063><bleed.auslaufen><en> The KM-1 has been jointly designed with Komori, employs a specific UV-cured ink and thus so can print on any paper (up to 0.6 mm) without bleed – and is designed to allow a maximum of maintenance by the operator.
<G-vec00625-002-s063><bleed.auslaufen><de> Die KM-1 wurde gemeinsam mit Komori entworfen, verwendet eine spezielle UV-gehärtete Tinte und kann somit auf jedem Papier (bis 0,6 mm) drucken, ohne auszulaufen – und wurde entworfen, um maximale Instandhaltung durch den Bediener zu ermöglichen.
<G-vec00625-002-s043><bleed.bluten><en> Tiny blood vessels in the back of the eyes can become filled with blood and may bleed, resulting in damage to the retina and impaired eyesight.
<G-vec00625-002-s043><bleed.bluten><de> Die winzigen Blutgefäße im Augenhintergrund können anschwellen und bluten; dadurch wird die Netzhaut geschädigt und die Sehkraft beeinträchtigt.
<G-vec00625-002-s101><bleed.bluten><en> With his red and black outfit (‘Well, that’s so bad guys can’t see me bleed’), mask and weapons, he’s got to be one of the most unusual characters in the Marvel universe.
<G-vec00625-002-s101><bleed.bluten><de> Mit seinem schwarz-roten Outfit („Na, damit die Bösen nicht sehen, wenn ich blute“), seiner Maske und den Waffen gehört er wohl zu den ungewöhnlichsten Charaktere unter den Marvel-Helden.
<G-vec00625-002-s102><bleed.bluten><en> Dinner Bell is given as a reward by Red Lucy in The Thorn, after completing the quest Bleed Me Dry.
<G-vec00625-002-s102><bleed.bluten><de> Diese Waffe erhält man von Red Lucy im Thorn als Belohnung für den Abschluss der Quest Blute mich aus.
<G-vec00625-002-s103><bleed.bluten><en> Why I bleed and not you
<G-vec00625-002-s103><bleed.bluten><de> Warum ich blute, und du nicht.
<G-vec00625-002-s104><bleed.bluten><en> It's the fire that drives you, that forces you to hit harder, to keep going, to bleed.
<G-vec00625-002-s104><bleed.bluten><de> Es ist das Feuer, das dich antreibt, das dich zwingt, härter zu schlagen, weiterzumachen, zu bluten.
<G-vec00625-002-s105><bleed.bluten><en> Excess wax from the lipstick is thus removed and it will not bleed.
<G-vec00625-002-s105><bleed.bluten><de> Überschüssiges Wachs aus der Lippenstift ist damit entfernt und es wird nicht bluten.
<G-vec00625-002-s106><bleed.bluten><en> You have sore areas in your mouth which bleed a little.
<G-vec00625-002-s106><bleed.bluten><de> Sie haben wunde Stellen im Mund, die leicht bluten.
<G-vec00625-002-s107><bleed.bluten><en> His mental, emotional, and spiritual anguish were so great they caused Him to bleed from every pore (see Luke 22:44; D&C 19:18).
<G-vec00625-002-s107><bleed.bluten><de> Seine psychische, seelische und geistige Qual war so groß, dass sie ihn aus jeder Pore bluten ließ (siehe Lukas 22:44; LuB 19:18).
<G-vec00625-002-s108><bleed.bluten><en> However, Myrcella's nose starts to bleed and she collapses and dies in Jaime's arms.[41]
<G-vec00625-002-s108><bleed.bluten><de> Doch gerade in diesem Moment fängt ihre Nase an zu bluten und sie bekommt keine Luft mehr.
<G-vec00625-002-s109><bleed.bluten><en> I told Jean Tinguely of this vision and of my desire to let a picture bleed by shooting at it.
<G-vec00625-002-s109><bleed.bluten><de> Ich erzählte Jean Tinguely von dieser Vision und von meinem Wunsch, ein Bild bluten zu lassen, indem ich auf es schoß.
<G-vec00625-002-s110><bleed.bluten><en> Collaterals around the rectum can cause rectal varices that can bleed.
<G-vec00625-002-s110><bleed.bluten><de> Kollaterale um das Rektum können Rektumvarizen verursachen, die bluten können.
<G-vec00625-002-s111><bleed.bluten><en> John was one of the first heroes who actually bleed during their lone gunman action but there aren’t many people who can keep up with his cool badass attitude.
<G-vec00625-002-s111><bleed.bluten><de> John war einer der ersten Helden, die während ihrer “einsamer Held”-Action tatsächlich bluten, aber es gibt nicht viele Leute, die mit seiner coolen Badass-Attitüde mithalten können.
<G-vec00625-002-s112><bleed.bluten><en> The sufferings of the Lord Jesus Christ made Him bleed from every pore, but He overcame the pain and had the strength to forgive while on the cross.
<G-vec00625-002-s112><bleed.bluten><de> Das Leiden des Herrn Jesus Christus ließ ihn aus jeder Pore bluten, aber er überwand den Schmerz und hatte die Kraft, selbst am Kreuz seinen Peinigern zu vergeben.
<G-vec00625-002-s113><bleed.bluten><en> Early on, intestinal mucosal ulcerations caused by S. mansoni or S. japonicum may bleed and result in bloody diarrhea.
<G-vec00625-002-s113><bleed.bluten><de> Noch im frühen Stadium können S. mansoni oder S. japonicum zu Ulzerationen der Mukosa führen, die bluten oder zu blutigen Durchfällen führen können.
<G-vec00625-002-s114><bleed.bluten><en> Now let us listen to Oliver Stone. Stone said more than two decades ago: “I think America has to bleed.
<G-vec00625-002-s114><bleed.bluten><de> Wenden wir uns uns jetzt an Oliver Stone, der vor mehr als zwei Jahrzehnten sagte: “Ich denke, Amerika muss bluten.
<G-vec00625-002-s115><bleed.bluten><en> I'll make the sky bleed!
<G-vec00625-002-s115><bleed.bluten><de> Ich lasse den Himmel bluten.
<G-vec00625-002-s116><bleed.bluten><en> This time we want to talk about the men and women of every color and creed who serve together, and fight together, and bleed together under the same proud flag.
<G-vec00625-002-s116><bleed.bluten><de> Diesmal wollen wir über die Männer und Frauen jeglicher Hautfarbe und Religionszugehörigkeit sprechen, die unter derselben stolzen Flagge gemeinsam dienen, gemeinsam kämpfen und gemeinsam bluten.
<G-vec00625-002-s117><bleed.bluten><en> Currency speculators have forced entire countries to their knees, and the population is made to bleed for “rescue packages” and privatisations imposed by the IMF.
<G-vec00625-002-s117><bleed.bluten><de> Währungsspekulanten haben ganze Länder in die Knie gezwungen und für die vom IWF erzwungenen „Rettungsprogramme“ musste anschließend die Bevölkerung bluten.
<G-vec00625-002-s118><bleed.bluten><en> All will bleed.
<G-vec00625-002-s118><bleed.bluten><de> Alles wird bluten.
<G-vec00625-002-s119><bleed.bluten><en> If a million people are in danger we care but when a loved one is in the danger we bleed for them, we feel what they are going through, the characters journey becomes personal.
<G-vec00625-002-s119><bleed.bluten><de> Wenn eine Million Leute in Gefahr sind, fühlen wir mit, aber wenn ein geliebter Mensch in Gefahr ist, bluten wir für den Helden, wir fühlen das, was er gerade erleidet, und die Reise des Charakters wird persönlich.
<G-vec00625-002-s120><bleed.bluten><en> If we often bleed a lot, iron and vitamin B12 are very likely to be missing.
<G-vec00625-002-s120><bleed.bluten><de> Bluten wir häufig sehr viel, mangelt es sehr wahrscheinlich an Eisen und Vitamin B12.
<G-vec00625-002-s121><bleed.bluten><en> I use this specially for calligraphy because the paper is pretty sturdy and the ink doesn't bleed.
<G-vec00625-002-s121><bleed.bluten><de> Ich benutze dies speziell für Kalligraphie, weil das Papier ziemlich robust ist und die Tinte nicht bluten.
<G-vec00625-002-s122><bleed.bluten><en> When you scrape your knee, it's gotta bleed ta get better.
<G-vec00625-002-s122><bleed.bluten><de> Wenn man sich das Knie zerkratzt, dann muss es bluten, damit es besser werden kann.
<G-vec00625-002-s123><bleed.bluten><en> Sometimes a man can bleed
<G-vec00625-002-s123><bleed.bluten><de> Manchmal kann ein Mann bluten...
<G-vec00625-002-s124><bleed.bluten><en> Symptoms of gingivitis are swollen and reddened gums, which spontaneously bleed on contact.
<G-vec00625-002-s124><bleed.bluten><de> Anzeichen einer Gingivitis sind ein geschwollenes und gerötetes Zahnfleisch, welches bei Berührung spontan zu bluten beginnt.
<G-vec00625-002-s125><bleed.bluten><en> If your nail biting is such a problem that you're always biting your nails, frequently causing your cuticles to bleed, or even losing fingernails, you may not be able to stop biting your nails on your own.
<G-vec00625-002-s125><bleed.bluten><de> Falls du "immer" an deinen Nägeln kaust, deine Nagelhäute häufig zum Bluten bringst oder sogar Fingernägel verlierst, kannst du womöglich nicht allein damit aufhören.
<G-vec00625-002-s126><bleed.bluten><en> Frequent washing strips your skin of protective oils, causing the skin to crack and bleed.
<G-vec00625-002-s126><bleed.bluten><de> Häufiges Waschen entfernt schützende Öle von Ihrer Haut, wodurch die Haut rissig wird und bluten kann.
<G-vec00625-002-s128><bleed.bluten><en> Diseased gums are red, often swollen around the tooth necks and bleed easyly when being touched.
<G-vec00625-002-s128><bleed.bluten><de> Krankes Zahnfleisch ist gerötet, am Zahnhals oft geschwollen und blutet leicht bei Berührung.
<G-vec00625-002-s129><bleed.bluten><en> Gums often bleed when the teeth are covered with bacterial plaque or tartar.
<G-vec00625-002-s129><bleed.bluten><de> Das Zahnfleisch blutet oft weil Zahnstein oder Zahnbelag vorliegt.
<G-vec00625-002-s130><bleed.bluten><en> Gums that bleed after daily flossing can be a warning sign of gingivitis, the initial stage of gum disease.
<G-vec00625-002-s130><bleed.bluten><de> Wenn Ihr Zahnfleisch nach der täglichen Reinigung mit Zahnseide blutet, kann dies ein Warnzeichen für Gingivitis sein, das Frühstadium von Zahnfleischerkrankungen.
<G-vec00625-002-s131><bleed.bluten><en> In the elderly, the body increasingly loses its moisture and drains the nasal tissues, which is why in the elderly people often bleed from the nose.
<G-vec00625-002-s131><bleed.bluten><de> Bei älteren Menschen verliert der Körper zunehmend seine Feuchtigkeit und entwässert das Nasengewebe, weshalb bei älteren Menschen oft aus der Nase blutet.
<G-vec00625-002-s132><bleed.bluten><en> Like an object, when it is shot the pilot doesn't bleed or explode.
<G-vec00625-002-s132><bleed.bluten><de> Wie bei einem Objekt blutet oder explodiert der Pilot nicht, wenn man auf ihn schießt.
<G-vec00625-002-s133><bleed.bluten><en> It really hurts, you bleed a lot, and you keep spitting out blood for a while.
<G-vec00625-002-s133><bleed.bluten><de> Mancher springt auf, es tut sehr weh und blutet stark, man spuckt viel Blut.
<G-vec00625-002-s134><bleed.bluten><en> Healthy gums are pinkish, fills in the teeth interspaces completly and does not bleed.
<G-vec00625-002-s134><bleed.bluten><de> Gesundes Zahnfleisch ist bla?rosa, füllt die Zahnzwischenräume vollständig aus und blutet nicht.
<G-vec00625-002-s135><bleed.bluten><en> A healthy gum does not bleed, even if you are eating an apple, brush your teeth or the dentist is working in your mouth.
<G-vec00625-002-s135><bleed.bluten><de> Gesundes Zahnfleisch blutet nicht, selbst wenn Sie einen Apfel essen, Zähne putzen, oder der Zahnarzt im Mund arbeitet.
<G-vec00625-002-s136><bleed.bluten><en> If we avoid this, our breath starts to become bad, our gums bleed and recess, and as a long term result, our teeth start moving.
<G-vec00625-002-s136><bleed.bluten><de> Wenn wir dies vermeiden, wird unser Atem zu schlecht, unser Zahnfleisch blutet und verfällt, und als langfristiges Ergebnis beginnen unsere Zähne sich zu bewegen.
<G-vec00625-002-s137><bleed.bluten><en> Unique Passive: Critical strikes causes your target to bleed for an additional 60% bonus AD physical damage over 3 seconds. Undocumented Changes
<G-vec00625-002-s137><bleed.bluten><de> Durch kritische Treffer blutet dein Ziel 3 Sekunden lang in Höhe von 60 % deines zusätzlichen Fähigkeitsschadens (normaler Schaden).
<G-vec00625-002-s138><bleed.bluten><en> I don’t recommend the dog, seems like a good idea but the granite is really harsh on their feet, can make them bleed.
<G-vec00625-002-s138><bleed.bluten><de> Ich empfehle den Hund nicht, scheint eine gute Idee zu sein, aber der Granit ist sehr hart auf den Beinen und kann dazu führen, dass er blutet.
<G-vec00625-002-s139><bleed.bluten><en> ... if the gums bleed during the first trimester during tooth cleaning.
<G-vec00625-002-s139><bleed.bluten><de> ... wenn das Zahnfleisch während des ersten Trimesters während der Zahnreinigung blutet.
<G-vec00625-002-s140><bleed.bluten><en> There is a necrosis of tissues, the saliva becomes viscous, the gums swell and bleed, they even turn blue, hurt and itch and this is all accompanied by a large amount of plaque.
<G-vec00625-002-s140><bleed.bluten><de> Es gibt eine Nekrose von Geweben, der Speichel wird viskos, das Zahnfleisch schwillt an und blutet, sie werden sogar blau, schmerzen und jucken und das alles wird von einer großen Menge Plaque begleitet.
<G-vec00625-002-s141><bleed.bluten><en> I want your heart to bleed
<G-vec00625-002-s141><bleed.bluten><de> Ich will, dass dein Herz blutet.
<G-vec00625-002-s142><bleed.bluten><en> It will never bleed into your eyes, never make your hands slippery, and won't come off during the most rigorous activities in the water, wind, or blazing hot sun.
<G-vec00625-002-s142><bleed.bluten><de> Es blutet nie in Ihre Augen, bildet nie Ihre Hände glatt und wird nicht weg während der rigorosesten Tätigkeiten im Wasser, im Wind oder in der flammenden heißen Sonne kommen.
<G-vec00625-002-s143><bleed.bluten><en> When they force-fed me, the tube made my nose bleed non stop.
<G-vec00625-002-s143><bleed.bluten><de> Wenn man mich zwangsweise ernährte, blutete meine Nase durch den Schlauch ununterbrochen.
<G-vec00625-002-s144><bleed.bluten><en> They also slapped her face several times, causing it to bleed and swell.
<G-vec00625-002-s144><bleed.bluten><de> Man schlug ihr auch mehrere Male ins Gesicht, wodurch Chen Zhuoyi blutete und das Gesicht anschwoll.
<G-vec00625-002-s145><bleed.bluten><en> One officer punched him in the face repeatedly, causing him to bleed from the nose and mouth.
<G-vec00625-002-s145><bleed.bluten><de> Ein Beamter schlug ihm immer wieder ins Gesicht, wodurch er aus Nase und Mund blutete.
<G-vec00625-002-s146><bleed.bluten><en> Since yarrow stalks are quite stiff and pointed, it was not unlikely that the procedure would cause the nose to bleed.
<G-vec00625-002-s146><bleed.bluten><de> Da Schafgarbenstängel recht steif und spitz sind, war es sehr wahrscheinlich, dass die Nase durch diese Prozedur blutete.
<G-vec00625-002-s147><bleed.bluten><en> I bleed two liters of blood in my stomach, and was given around five blood transfusions.
<G-vec00625-002-s147><bleed.bluten><de> Ich blutete zwei Liter Blut in meinen Bauch, und erhielt ungefähr fünf Transfusionen.
<G-vec00625-002-s148><bleed.bluten><en> I bleed into the sac and the heart had no room to beat.
<G-vec00625-002-s148><bleed.bluten><de> Ich blutete in den Sack und das Herz hatte keinen Platz zum Schlagen.
<G-vec00625-002-s149><bleed.bluten><en> Ms. Xin was beaten severely and bleed profusely.
<G-vec00625-002-s149><bleed.bluten><de> Frau Xin wurde massiv geschlagen und blutete stark.
<G-vec00625-002-s150><bleed.bluten><en> Oftentimes, when she had only finished half of her meal, they would slap her face, causing her nose and mouth to bleed and her bowl to fall to the ground.
<G-vec00625-002-s150><bleed.bluten><de> Manchmal hatte sie noch nicht einmal ihre Mahlzeit zur Hälfte eingenommen und bekam von den Verbrechern Ohrfeigen, so dass ihre Nase und ihr Mund bluteten und ihre Essschale zu Boden fiel.
<G-vec00625-002-s151><bleed.bluten><en> The handcuffs cut Liang's wrists deeply causing them to swell and bleed.
<G-vec00625-002-s151><bleed.bluten><de> Die Handfesseln schnitten tief in Liang Xiulans Handgelenke, so dass sie anschwollen und bluteten.
<G-vec00625-002-s152><bleed.bluten><en> They inserted large rubber tubes into our nostrils to force feed us and caused our noses to bleed and made us throw up.
<G-vec00625-002-s152><bleed.bluten><de> Sie zwangsernährten uns, wobei sie lange Gummischläuche in unsere Nasenlöcher einführten, sodass unsere Nasen bluteten und wir uns übergeben mussten.
<G-vec00625-002-s153><bleed.bluten><en> In particular, the long-term sitting on small stools injured many practitioners, causing their buttocks' to bleed, and bloody scabs to stick to their clothing.
<G-vec00625-002-s153><bleed.bluten><de> Insbesondere das lange Sitzen auf den kleinen Stühlen verletzte viele Praktizierende, ihre Gesäße bluteten und auf ihrer Kleidung klebten Blutkrusten.
<G-vec00625-002-s249><bleed.bluten><en> So when she sat down to write her new album The Blade, released on Warner Music Nashville, she committed herself to finding songs that would make both her and her audience cry, laugh, think and, metaphorically, bleed.
<G-vec00625-002-s249><bleed.bluten><de> Als sie sich also hinsetzte, um ihr neues Album The Blade zu schreiben, das auf Warner Music Nashville veröffentlicht wurde, verpflichtete sie sich, Songs zu finden, die sie und ihr Publikum zum Weinen, Lachen, Denken und, metaphorisch gesprochen, zum Bluten bringen würden.
<G-vec00625-002-s020><bleed.verbluten><en> What is now occurring is an unprecedented mass slaughter that is reducing the adult working population of all the leading civilized countries to women, old people, and cripples. This blood-letting threatens to bleed the European workers' movement to death.
<G-vec00625-002-s020><bleed.verbluten><de> Was jetzt vorgeht, ist eine nie dagewesene Massenabschlachtung, die immer mehr die erwachsene Arbeiterbevölkerung aller führenden Kulturländer auf Frauen, Greise und Krüppel reduziert, ein Aderlaß, an dem die europäische Arbeiterbewegung zu verbluten droht.
<G-vec00625-002-s227><bleed.verbluten><en> In this mode you have bleed out time enemies can cut short with a brutal finisher.
<G-vec00625-002-s227><bleed.verbluten><de> In diesem Modus können Spieler außerdem verbluten und schnell mit einem Nahkampfangriff ausgeschaltet werden.
<G-vec00625-002-s228><bleed.verbluten><en> The sharks are then thrown back into the water where they either drown or bleed to death.
<G-vec00625-002-s228><bleed.verbluten><de> Danach werden die Haie ins Meer zurückgeworfen und verbluten.
<G-vec00625-002-s229><bleed.verbluten><en> The owner of the 7-11 store came over and said that if I didnít get to a hospital, I would bleed to death in just a few minutes.
<G-vec00625-002-s229><bleed.verbluten><de> Der Eigentümer des Geschäftes kam auf mich zu und sagte, dass ich in wenigen Minuten verbluten würde, wenn ich nicht ganz schnell ins Krankenhaus käme.
<G-vec00625-002-s230><bleed.verbluten><en> The alternative theatre scene, which has received no funding in the past three years, has been left to bleed out.
<G-vec00625-002-s230><bleed.verbluten><de> Sie ließ die alternative Theaterszene verbluten, die in den letzten drei Jahren keine Fördergelder bekommen hat.
<G-vec00625-002-s231><bleed.verbluten><en> They had to wade through the horrors of war, to be torn in pieces by grenades; they had to bleed to death for the interests of the capitalists; they had to heap up mountains of corpses, in order that the lesson: Capitalism leads to the bloodiest anarchy, to the destruction of the few cultural achievements which have been created, to the deepest misery of the masses and their literal enslavement, so that this lesson might be converted out of a theoretical thesis into a crying and burning certainty, at least in the minds of the front ranks of the working class.
<G-vec00625-002-s231><bleed.verbluten><de> Sie musste die Hölle des Weltkrieges durchschreiten, von Granaten in Stücke gerissen werden, sie musste verbluten für die Interessen des Kapitals, sie musste Berge von Leichen auftürmen, damit die Lehre: der Kapitalismus treibe zur blutigsten Anarchie, zur Vernichtung der geringen Kulturansätze, die geschaffen sind, zum tiefsten Elend der Massen, zu ihrer Versklavung im wahrsten Sinne des Wortes, damit diese Lehre sich aus einer theoretischen These in schreiendes und brennendes Bewußtsein wenigstens der Vorderreihen der Arbeiterschaft verwandelte.
<G-vec00625-002-s232><bleed.verbluten><en> "Harry, we can’t just let him lie here and bleed to death.
<G-vec00625-002-s232><bleed.verbluten><de> "Harry, wir können ihn nicht einfach hier liegen und verbluten lassen.
<G-vec00625-002-s234><bleed.verbluten><en> With placenta previa, if you start to bleed, you have one hour or less to get to the hospital before you bleed to death.
<G-vec00625-002-s234><bleed.verbluten><de> Bei Placenta praevia, wenn man anfängt mit bluten, hat man eine Stunde oder weniger um ins Krankenhaus zu gehen ehe man sich verblutet.
<G-vec00625-002-s235><bleed.verbluten><en> Did you want him to bleed to death?" Li Fei didn't answer.
<G-vec00625-002-s235><bleed.verbluten><de> Wolltet ihr, dass er verblutet?“ Li Fei antwortete wieder nicht.
<G-vec00625-002-s236><bleed.verbluten><en> While being operated on the surgeon severed an artery in my neck and I bleed to death.
<G-vec00625-002-s236><bleed.verbluten><de> Während ich operiert wurde, durchtrennte der Chirurg eine Arterie in meinem Hals und ich verblutete.
