<G-vec00169-001-s032><capture.aufnehmen><en> The joker in Batman have to capture at.
<G-vec00169-001-s032><capture.aufnehmen><de> Der Joker in Batman müssen bei der Aufnahme.
<G-vec00169-001-s033><capture.aufnehmen><en> The digester is a structure where fermented feces of animals and even human beings as surplus and scrap and rejections of vegetables, coffee pulp, you get a gas called biogas, useful for cooking, heating or water heating from small pigs other uses, thereby obtaining a clean energy source that plows the wood is not used for some than steel and will contribute to the capture of gases that cause global warming and deforestation.
<G-vec00169-001-s033><capture.aufnehmen><de> Der Kocher ist eine Struktur, wo fermentierte Kot der Tiere und sogar Menschen als Überschuss und Schrott und Ablehnungen von Gemüse, Kaffee Zellstoff, erhalten Sie eine Gas als Biogas bezeichnet, nützlich zum Kochen, Heizen oder Warmwasserbereitung von kleinen Schweinen andere Nutzungen, wodurch eine saubere Energiequelle, die das Holz Pflüge nicht für einige als Stahl verwendet und um die Aufnahme von Gasen, die globale Erwärmung und die Entwaldung verursachen beitragen.
<G-vec00169-001-s034><capture.aufnehmen><en> QTest saves all of the input/output flow from the browser used for the capture, as well as the context, the user's thinking time, and the parallelism and synchronization between connections to comply with and guarantee the user's actual behavior.
<G-vec00169-001-s034><capture.aufnehmen><de> QTest speichert alle Input/Output-Flows des für die Aufnahme genutzten Browsers, den Kontext, die Reaktionszeit des Users und die Parallelitäten und Synchronisation zwischen den Verbindungen um das Nutzerverhalten komplett zu simulieren.
<G-vec00169-001-s035><capture.aufnehmen><en> With the full range of image capture capabilities offered by today's advanced electronic devices, it's never been easier to make your pictures and videos look great, while making them even more spectacular with the addition of accessories.
<G-vec00169-001-s035><capture.aufnehmen><de> Durch das große Spektrum an Möglichkeiten zur Aufnahme von Bildern wie es von modernen elektronischen Geräten geboten wird ist es einfacher als je zuvor, die eigenen Bilder und Videos großartig aussehen zu lassen, wobei diese durch die Nutzung zusätzlicher Accessoires noch spektakulärer gestaltet werden können.
<G-vec00169-001-s036><capture.aufnehmen><en> These solutions often require specialist illuminators, the capture of multiple images with different lighting geometries and then software processing to extract synthetic images from the combination of illumination images.
<G-vec00169-001-s036><capture.aufnehmen><de> Diese Lösungen erfordern oft spezielle Beleuchtungen, die Aufnahme mehrerer Bilder mit unterschiedlichen Lichtgeometrien und eine ausgeklügelte Softwareverarbeitung, um synthetische Bilder aus der Kombination der verschieden beleuchteten Bilder zu erzeugen.
<G-vec00169-001-s037><capture.aufnehmen><en> There has been a historic decline due to the capture and export of thousands of birds from Angola, This has contributed, to a large extent, a significant reduction in the population Rosy-faced Lovebird in the south of the country.
<G-vec00169-001-s037><capture.aufnehmen><de> Es hat einen historischen Rückgang aufgrund der Aufnahme und Ausgabe von Tausenden von Vögeln aus Angola, Dies hat dazu beigetragen,, zu einem großen Teil, eine deutliche Reduktion der Population Rosenköpfchen im Süden des Landes.
<G-vec00169-001-s038><capture.aufnehmen><en> The PMD time-of-flight technology ensures detection of scenes and objects with just one image capture in three dimensions and without motion blur.
<G-vec00169-001-s038><capture.aufnehmen><de> PMD Time-of-Flight-Technologie Mit der PMD-Time-of-Flight-Technologie werden Szenen und Objekte mit nur einer Aufnahme dreidimensional und ohne Bewegungsverzerrung erfasst.
<G-vec00169-001-s039><capture.aufnehmen><en> Face Detection recognises up to 8 faces in a scene, optimising exposure, white balance, flash and other settings for portraits Capture spectacular panoramas
<G-vec00169-001-s039><capture.aufnehmen><de> Pro Szene können bis zu 8 Gesichter erkannt werden, wobei Optimalbelichtung, Weißabgleich, Blitz und andere Parameter zur Aufnahme von Porträts optimiert werden.
<G-vec00169-001-s040><capture.aufnehmen><en> Athens fell in 1456 in Belgrade, and narrowly escaped capture when a peasant army led by the Hungarian Janos Hunyadi held a place in the same year, however, Serbia, Bosnia, Wallachia and the Khanate of Crimea were all under the Ottoman control in 1478.
<G-vec00169-001-s040><capture.aufnehmen><de> Athen fiel im Jahre 1456 in Belgrad, und entkam nur knapp der Aufnahme, wenn ein Bauer Armee von der ungarischen Janos Hunyadi führte hielt einen Platz im selben Jahr jedoch, Serbien, Bosnien, der Walachei und der Khanat der Krim waren alle unter der osmanischen Kontrolle im Jahr 1478.
<G-vec00169-001-s041><capture.aufnehmen><en> But that this screenshot does not tell you is that 907 comes in three very different versions of each other, that 907 offers many customization options, and finally, that this capture screen does not tell you is that only a few days, this topic has risen among the best sellers of the month.
<G-vec00169-001-s041><capture.aufnehmen><de> Aber dass diese Screenshot nicht sagen, ist, dass 907 in drei sehr unterschiedliche Versionen von jedem anderen kommt, dass 907 bietet viele Anpassungsmöglichkeiten, und schließlich, dass diese Aufnahme Bildschirm nicht sagen, ist, dass nur ein paar Tage, dieses Thema zu den Bestsellern des Monats gestiegen.
<G-vec00169-001-s042><capture.aufnehmen><en> The IEI USB 3.0 Uncompressed Full HD Capture Box allows users to capture high-resolution footage from HDMI devices for livestreaming through DJ2 Live.
<G-vec00169-001-s042><capture.aufnehmen><de> Die IEI USB 3.0 Unkomprimierte Full HD Aufnahmebox ermöglicht Benutzern die Aufnahme von hochauflösendem Video von HDMI Geräten für das Live Streaming über DJ2 Live.
<G-vec00169-001-s043><capture.aufnehmen><en> The HEPA filter helps to capture even the finest dust, allergenic mites or animal allergens.
<G-vec00169-001-s043><capture.aufnehmen><de> Der HEPA-Filter hilft bei der Aufnahme des Feinstaubs, der die Allergie auslösenden Milben oder der tierischen Allergene.
<G-vec00169-001-s044><capture.aufnehmen><en> Once the capture is started, USB 3.0 data is displayed immediately on the screen.
<G-vec00169-001-s044><capture.aufnehmen><de> Sobald die Aufnahme gestartet ist werden USB 3.0 Daten unmittelbar auf dem Bildschirm angezeigt.
<G-vec00169-001-s045><capture.aufnehmen><en> The person in this article was quite sophisticated, wary of capture and had obtained information from dumpsters(shred those documents and wipe those hard drives), threatened DDoS attacks, etc.
<G-vec00169-001-s045><capture.aufnehmen><de> Die Person, die in diesem Artikel war ziemlich anspruchsvoll, Sie vorsichtig bei Aufnahme und erhalten hatte, Informationen aus Müllcontainern(zerkleinern, diese Dokumente und Wischen Sie diese Festplatten), DDoS-Attacken bedroht, usw..
<G-vec00169-001-s046><capture.aufnehmen><en> Five different vulnerabilities can be exploited by exposing the Ethereal program to specially created network traffic, be it by sniffing a live network or reading a capture file.
<G-vec00169-001-s046><capture.aufnehmen><de> "Fünf verschiedene Sicherheitslücken in diesem Programm können durch ""speziellen"" Datenverkehr über ein Netzwerk ausgenutzt werden, wenn Ethereal gerade zum Sniffen oder zur Aufnahme von Daten genutzt wird."
<G-vec00169-001-s047><capture.aufnehmen><en> That means that not only one point but a complete scene is measured in only one capture.
<G-vec00169-001-s047><capture.aufnehmen><de> Somit wird nicht nur ein Punkt, sondern eine komplette Szene in nur einer Aufnahme vermessen.
<G-vec00169-001-s048><capture.aufnehmen><en> The portrait mode has also been improved, now with the ability to adjust the level of background blur after capture, which is fun.
<G-vec00169-001-s048><capture.aufnehmen><de> Der Portrait-Modus wird verbessert, jetzt mit der Fähigkeit, das Niveau der Hintergrundunschärfe nach der Aufnahme anpassen, Das ist Spaß.
<G-vec00169-001-s049><capture.aufnehmen><en> The two Stellar Infinity detectors and the Vectron X-ray tube in the Somatom Force need less than a second to capture the entire upper body.
<G-vec00169-001-s049><capture.aufnehmen><de> Die beiden Stellar-Infinity-Detektoren und die Vectron-Röntgenröhren des Somatom Force benötigen für die Aufnahme des ganzen Oberkörpers nicht einmal eine Sekunde.
<G-vec00169-001-s050><capture.aufnehmen><en> Spyder5CAPTURE PRO: The ultimate bundle with all the essentials to manage color from capture to editing in any photography workflow.
<G-vec00169-001-s050><capture.aufnehmen><de> Spyder5CAPTURE PRO: Das ultimative Bundle mit allen notwendigen Werkzeugen für das Farbmanagement im fotografischen Workflow von der Aufnahme bis zur Bildbearbeitung.
<G-vec00169-001-s051><capture.aufnehmen><en> Capture photos, video along with burst shots, and long videos With Zoe Camera, you can take a photo, shoot video with burst shots, and capture video without having to switch camera modes.
<G-vec00169-001-s051><capture.aufnehmen><de> Fotos, Videos zusammen mit Serienaufnahmen, und lange Videos aufnehmen Mit der Zoe Kamera können Sie ein Foto, ein Video mit Serienaufnahmen und ein Video aufnehmen, ohne die Kameramodi ändern zu müssen.
<G-vec00169-001-s053><capture.aufnehmen><en> It can further capture the photos by hacking and front and back camera of the Android smartphone and can also hack the microphone silently to record the conversation and surroundings.
<G-vec00169-001-s053><capture.aufnehmen><de> Es kann weiterhin die Fotos durch Hacken und Vorder- und Rückkamera des Android-Smartphones aufnehmen und auch aufnehmen hack das Mikrofon still zu notieren Konversation und Umgebung.
<G-vec00169-001-s054><capture.aufnehmen><en> Thanks to the EX-TR150, you are now able to capture brilliant videos in full HD (H.264) with a resolution of up to 1920x1080 pixels.
<G-vec00169-001-s054><capture.aufnehmen><de> Mit der EX-TR150 können Sie brillante Full HD-Videos (H.264) mit einer Auflösung von bis zu 1920x1080 Pixel aufnehmen.
<G-vec00169-001-s055><capture.aufnehmen><en> Design a successful mount the monitor also has the button for quick image capture.
<G-vec00169-001-s055><capture.aufnehmen><de> Entwurf glücklich mit der Befestigung auf dem Monitor, hat auch auf die schnelle aufnehmen.
<G-vec00169-001-s056><capture.aufnehmen><en> The built-in 6pcs IR-cut LEDs enable this surveillance camera capture clear night vision images up to 10 meters distance.
<G-vec00169-001-s056><capture.aufnehmen><de> Die eingebauten 6pcs IR-Cut LEDs ermöglichen diese Überwachungskamera Bilder bis zu 10 Meter Entfernung aufnehmen.
<G-vec00169-001-s057><capture.aufnehmen><en> Pictures may be used by selecting the grid icon from the live view (capture) screen.
<G-vec00169-001-s057><capture.aufnehmen><de> Bilder können durch Drücken des Gitter-Symbols in der Live-View-Ansicht (Aufnehmen) hinzugefügt werden.
<G-vec00169-001-s058><capture.aufnehmen><en> Just connect to your computer with a USB cable and use your favorite recording software to capture your voice with harmonies and effects.
<G-vec00169-001-s058><capture.aufnehmen><de> Einfach den Computer mit dem USB-Kabel anschließen und mit Deiner bevorzugten Recordingssoftware Deinen Gesang mit Harmonisierung und Effekten aufnehmen.
<G-vec00169-001-s059><capture.aufnehmen><en> You can see what your employees have downloaded in terms of images and photos or they have used mobile phone camera to capture photos.
<G-vec00169-001-s059><capture.aufnehmen><de> Sie können sehen, was Ihre Mitarbeiter in Bezug auf Bilder und Fotos heruntergeladen haben, oder sie haben die Handykamera zum Aufnehmen von Fotos verwendet.
<G-vec00169-001-s060><capture.aufnehmen><en> If you have a V4L compatible radio tuner card, and wish to listen and capture sound with MPlayer, read the radio section.
<G-vec00169-001-s060><capture.aufnehmen><de> Wenn du eine V4L-kompatible Radioempfänger karte hast und mit MPlayer Radio hören oder aufnehmen möchtest, lies den Abschnitt radio.
<G-vec00169-001-s061><capture.aufnehmen><en> The world's best-selling digital media suite makes it easy to capture, enhance, save and share your photo, video and audio projects.
<G-vec00169-001-s061><capture.aufnehmen><de> Mit der weltweit meistverkauften Suite für digitale Medien ist das Aufnehmen, Verbessern, Speichern und Weitergeben Ihrer Foto-, Video- und Audio-Projekte ein Leichtes.
<G-vec00169-001-s062><capture.aufnehmen><en> Decide if you want to capture video with the camera.
<G-vec00169-001-s062><capture.aufnehmen><de> Entscheide, ob du Videoclips mit der Kamera aufnehmen möchtest.
<G-vec00169-001-s063><capture.aufnehmen><en> Alternatives to Dashti’s staged documentaries can be found in the works of Egyptian Rana El Nemr and Jordanian Tanya Habjouqa, both of whom directly capture people in urban settings.
<G-vec00169-001-s063><capture.aufnehmen><de> Alternativen zu Dashtis inszenierten Dokumentationen können in den Werken der Ägypterin Rana El Nemr und der Jordanierin Tanya Habjouqa gefunden werden, die beide Menschen im urbanen Umfeld direkt aufnehmen.
<G-vec00169-001-s064><capture.aufnehmen><en> Due to its structure, the slide adapter can capture frames of all thicknesses.
<G-vec00169-001-s064><capture.aufnehmen><de> Durch seine Konstruktion kann der Diahalter Rahmen in allen Stärken aufnehmen.
<G-vec00169-001-s065><capture.aufnehmen><en> Optimal for your Android smartphone, action cameras or drones, this high-performance microSD memory card lets you capture 4K UHD video, Full HD video and high-resolution photos.
<G-vec00169-001-s065><capture.aufnehmen><de> Optimal für Ihr Android-Smartphone, Actionkameras oder Drohnen - mit dieser hochleistungsfähige microSD-Speicherkarte können Sie 4K UHD Video, Full HD Video und hochauflösende Fotos aufnehmen.
<G-vec00169-001-s066><capture.aufnehmen><en> You can capture large images in XYZ with just a single click.
<G-vec00169-001-s066><capture.aufnehmen><de> Sie können mit nur einem Mausklick große Panoramabilder in XYZ aufnehmen.
<G-vec00169-001-s067><capture.aufnehmen><en> And, if you can capture 24 images of a horse per second, then you have a movie.
<G-vec00169-001-s067><capture.aufnehmen><de> Und wenn Sie 24 Bilder eines Pferdes pro Sekunde aufnehmen können, dann haben Sie einen Film.
<G-vec00169-001-s068><capture.aufnehmen><en> Ashampoo Snap for Android is a fully-fledged mobile application to capture, edit and share screenshots and images on your Android device.
<G-vec00169-001-s068><capture.aufnehmen><de> Voraussetzungen Meinungen Mit Ashampoo Snap für Android können Sie Screenshots und Bilder mühelos auf Ihrem Android Gerät aufnehmen, bearbeiten und teilen.
<G-vec00169-001-s069><capture.aufnehmen><en> Blaze Media Pro can capture video from available video devices (for example, from a TV tuner or a webcam), rip DVD movies, create videos from pictures or photos, decompile videos, extract audio from movies.
<G-vec00169-001-s069><capture.aufnehmen><de> Blaze Media Pro kann Video von verfügbaren Videogeräten aufnehmen (zum Beispiel, von einem TV-Tuner oder von einer Webkamera), DVD Filme rippen, Video aus Bilder oder Fotos erstellen, Videos dekompilieren, Ton aus Filmen extrahieren.
<G-vec00169-001-s070><capture.aufzeichnen><en> Independent analytical studies produced a shocking result - some IPhone applications are able to capture everything that happens on the phone screen.
<G-vec00169-001-s070><capture.aufzeichnen><de> Unabhängige analytische Studien haben ein schockierendes Ergebnis geliefert - einige IPhone-Anwendungen können alles aufzeichnen, was auf dem Telefonbildschirm passiert.
<G-vec00169-001-s071><capture.aufzeichnen><en> We also have the Kinect and its comrades that capture motion and allow us to control games.
<G-vec00169-001-s071><capture.aufzeichnen><de> Wir haben zuhause die Kinect und ähnliche Technologien, die unsere Bewegungen aufzeichnen und uns so Videospiele kontrollieren lassen.
<G-vec00169-001-s072><capture.aufzeichnen><en> When you click the Capture button you enter the capture window.
<G-vec00169-001-s072><capture.aufzeichnen><de> Wenn Sie auf die Schaltfläche Aufzeichnen klicken, gelangen Sie zum Aufzeichnen-Fenster.
<G-vec00169-001-s073><capture.aufzeichnen><en> This video recorder lets you capture video files directly on your PC or Mac using a webcam (video camera), or capture device (from video).
<G-vec00169-001-s073><capture.aufzeichnen><de> Kaufen Herunterladen Herunterladen Herunterladen Debut Mit diesem Video-Aufnahme-Programm kann man Videodateien mittels Webcam (Videokamera) oder Aufnahmegerät (von Video) direkt auf dem Computer aufzeichnen.
<G-vec00169-001-s074><capture.aufzeichnen><en> Find out which 4K HDR game clips you can capture on your Xbox One X.
<G-vec00169-001-s074><capture.aufzeichnen><de> Erfahren Sie, welche 4K HDR-Spielclips Sie auf Ihrer Xbox One X aufzeichnen können.
<G-vec00169-001-s075><capture.aufzeichnen><en> And you’ll be prompted before any app can capture keyboard activity or a photo or video of your screen.
<G-vec00169-001-s075><capture.aufzeichnen><de> Und du erhältst eine Anfrage, bevor eine App Tastatur aktivitäten aufzeichnen oder ein Foto oder Video von deinem Bildschirm machen kann.
<G-vec00169-001-s076><capture.aufzeichnen><en> Choose from 100 MHz or 200 MHz bandwidth models, with fast sampling rates up to 2.5 GS/s and 400 ps resolution to capture noise and other disturbances.
<G-vec00169-001-s076><capture.aufzeichnen><de> Zur Auswahl stehen Modelle mit 100 MHz oder 200 MHz Bandbreite, schnellen Abtastraten bis 2,5 GS/s und einer Auflösung von 400 ps zum Aufzeichnen von Rausch- und anderen Störsignalen.
<G-vec00169-001-s077><capture.aufzeichnen><en> Automatic batch capture is a quick way to capture scenes from a video tape.
<G-vec00169-001-s077><capture.aufzeichnen><de> Mit der automatischen Stapelaufzeichnung können Sie schnell Szenen von einer Videokassette aufzeichnen.
<G-vec00169-001-s078><capture.aufzeichnen><en> You record the traces by clicking on Transmit / Capture text.
<G-vec00169-001-s078><capture.aufzeichnen><de> Zum Aufzeichnen des Traces klicken Sie in der Menüleiste auf Übertragen / Text aufzeichnen.
<G-vec00169-001-s079><capture.aufzeichnen><en> In our experience, basically the collection of information is carried out by establishing covert surveillance photo, which can be used a miniature camera that can also record sound, and can only capture video.
<G-vec00169-001-s079><capture.aufzeichnen><de> Nach unserer Erfahrung ist im Grunde die Sammlung von Informationen durch die Einrichtung von CCTV Foto durchgefÃ1⁄4hrt, die eine Miniaturkamera, die auch Ton aufnehmen kann, kann verwendet werden, und nur Video aufzeichnen können.
<G-vec00169-001-s080><capture.aufzeichnen><en> To stop the trace, click on the HyperTerminal menus Transmit / Stop text capture.
<G-vec00169-001-s080><capture.aufzeichnen><de> Um den Trace wieder zu stoppen, klicken Sie im HyperTerminal in der oberen Menüleiste auf Übertragen / Text aufzeichnen beenden.
<G-vec00169-001-s081><capture.aufzeichnen><en> CyberLink PowerDVD lets you select your desired capture type and size quickly and conveniently before you are ready to capture a frame.
<G-vec00169-001-s081><capture.aufzeichnen><de> Mit CyberLink PowerDVD können Sie den gewünschten Aufnahmetyp und die Aufnahmegröße schnell und praktisch auswählen, bevor Sie ein Einzelbild aufzeichnen.
<G-vec00169-001-s082><capture.aufzeichnen><en> For the art, pre-press, billboard shops and other art manufactories, they need scanners presents high resolution to deliver perfect image quality to capture images.
<G-vec00169-001-s082><capture.aufzeichnen><de> Im Kunstgewerbe, beim Vordruck, in Werbeunternehmen und in anderen Kunstmanufakturen werden Scanner benötigt, die Bilder mit hoher Auflösung aufzeichnen und eine perfekte Bildqualität liefern.
<G-vec00169-001-s083><capture.aufzeichnen><en> To be more precise, you may pause the scene, play it in slow motion, or step frame, and then capture the exact desired frame of video.
<G-vec00169-001-s083><capture.aufzeichnen><de> Um genauere Ergebnisse zu erzielen, können Sie die Wiedergabe anhalten, die Szene im Zeitlupenmodus abspielen oder schrittweise Einzelbild für Einzelbild ansehen und anschließend das gewünschte Einzelbild aufzeichnen.
<G-vec00169-001-s084><capture.aufzeichnen><en> Set all camera parameters via wireless remote control and capture / review images or movie clips by simply pushing of a button.
<G-vec00169-001-s084><capture.aufzeichnen><de> Alle Kameraparameter via Fernbedienung einstellen und Bilder oder Movieclips durch einfachen Knopfdruck aufzeichnen/betrachten.
<G-vec00169-001-s085><capture.aufzeichnen><en> You can capture video from any source directly into any format that your preinstalled codecs support (such as most popular WebM, XviD, 3IVX...).
<G-vec00169-001-s085><capture.aufzeichnen><de> Sie können Videos von jeder Quelle direkt in jedes Format aufzeichnen, das Ihrem vorinstallierten Codec unterstützt (wie die beliebten WebM, XviD, 3IVX...).
<G-vec00169-001-s086><capture.aufzeichnen><en> You can capture video scenes (including the audio portion) from a DVD for use in your CyberLink PowerDirector project.
<G-vec00169-001-s086><capture.aufzeichnen><de> Sie können Videoszenen (inklusive Audioteil) von einer DVD aufzeichnen, um sie in Ihrem CyberLink PowerDirector-Projekt zu verwenden.
<G-vec00169-001-s087><capture.aufzeichnen><en> Add captured files to media library: select this option to import captured files into the media library directly after capture.
<G-vec00169-001-s087><capture.aufzeichnen><de> Aufgezeichnete Dateien zur Medienbibliothek hinzufügen: Wählen Sie diese Option aus, um aufgezeichnete Dateien direkt nach dem Aufzeichnen in die Medienbibliothek zu importieren.
<G-vec00169-001-s088><capture.aufzeichnen><en> In the process, they once and for all changed the relationship between the artist and the studio: it had now become a place for experimentation and composition, and the aim of recording was no longer to merely capture a performance for playback.
<G-vec00169-001-s088><capture.aufzeichnen><de> Sie veränderten ein für allemal das Verhältnis zwischen Künstlern und Studio: Es war nun zu einem Ort für Experimente und Komposition geworden, und das Ziel einer Aufnahme überstieg das bloße Aufzeichnen einer Darbietung für die Reproduktion.
<G-vec00169-001-s089><capture.aufnehmen><en> They make it easy to capture the flight of a bird or your friend's jump into the ocean.
<G-vec00169-001-s089><capture.aufnehmen><de> Sie machen es einfach, den Flug einen Vogels oder den Sprung eures Freundes in den Ozean aufzunehmen.
<G-vec00169-001-s090><capture.aufnehmen><en> Note: To avoid possible overwriting of lost photos, stop further use of digital camera to capture any new picture.
<G-vec00169-001-s090><capture.aufnehmen><de> Hinweis: Um ein mögliches Überschreiben von verlorenen Fotos zu vermeiden, sollten Sie die Digitalkamera nicht mehr verwenden, um ein neues Bild aufzunehmen.
<G-vec00169-001-s091><capture.aufnehmen><en> This data model, proven in practice, is designed to automatically capture and measure data from a wide variety of upstream systems.
<G-vec00169-001-s091><capture.aufnehmen><de> Dieses in der Praxis bewährte Datenmodell ist darauf ausgelegt, die Daten aus unterschiedlichsten Vorsystemen automatisiert aufzunehmen und zu messen.
<G-vec00169-001-s092><capture.aufnehmen><en> Santa Monica Studio supported the vision and provided the means for us to globe trot and capture something special.
<G-vec00169-001-s092><capture.aufnehmen><de> Santa Monica Studio hat unsere Vision unterstützt und uns die Mittel zur Verfügung gestellt, um die Welt zu bereisen und etwas ganz Besonderes aufzunehmen.
<G-vec00169-001-s093><capture.aufnehmen><en> Video Production students learn to plan video productions and field shoots, capture high-quality digital video images, work with digital video editing equipment, and direct multi-camera video productions.
<G-vec00169-001-s093><capture.aufnehmen><de> Die Videoproduktionsschüler lernen, Videoproduktionen und Außenaufnahmen zu planen, hochwertige digitale Videobilder aufzunehmen, mit digitalen Videobearbeitungsgeräten zu arbeiten und direkte Mehrkamera-Videoproduktionen.
<G-vec00169-001-s094><capture.aufnehmen><en> A free app that allows you to capture and share your gaming best moments.
<G-vec00169-001-s094><capture.aufnehmen><de> Plays.tv ermöglicht Ihnen Ihre besten Spielmomente aufzunehmen und zu teilen.
<G-vec00169-001-s095><capture.aufnehmen><en> Import from HDV and then your camcorder from the drop down to capture and then import videos from an attached HDV camcorder.
<G-vec00169-001-s095><capture.aufnehmen><de> Von HDV importieren und dann Ihren Camcorder aus dem Dropdown-Menü, um die Videos vom angehängten HDV Camcorder aufzunehmen und zu importieren.
<G-vec00169-001-s096><capture.aufnehmen><en> The Osmo Mobile 2 moves automatically to capture multiple photos then stitches them together to create a seamless image.
<G-vec00169-001-s096><capture.aufnehmen><de> Der Osmo Mobile 2 bewegt sich automatisch, um mehrere Fotos aufzunehmen, und setzt sie dann zu einem nahtlosen Bild zusammen.
<G-vec00169-001-s097><capture.aufnehmen><en> Just like working with natural light, I only had to make small adjustments to my position to capture the golden hour flare I wanted.
<G-vec00169-001-s097><capture.aufnehmen><de> Wie beim Arbeiten mit natürlichem Licht musste ich nur meine Position ein wenig anpassen, um den Flare-Effekt wie in der goldenen Stunde aufzunehmen.
<G-vec00169-001-s098><capture.aufnehmen><en> Import from DV and then your camcorder from the drop down to capture and then import videos from an attached DV camcorder.
<G-vec00169-001-s098><capture.aufnehmen><de> Von DV importieren und dann Ihren Camcorder aus dem Dropdown-Menü, um die Videos vom angehängten DV Camcorder aufzunehmen und zu importieren.
<G-vec00169-001-s099><capture.aufnehmen><en> This happenstance allows them to be used to capture images directly with great clarity that can be enlarged to sizes much bigger than traditional photography without loss of detail.
<G-vec00169-001-s099><capture.aufnehmen><de> Dieser Umstand ermöglicht es ihnen, Bilder direkt und sehr scharf aufzunehmen, die dann ohne Detailverlust viel stärker vergrößert werden können als digitale Fotos.
<G-vec00169-001-s100><capture.aufnehmen><en> Yet I have been unable to capture anything but a whiteness that means something, and means nothing.
<G-vec00169-001-s100><capture.aufnehmen><de> Doch war ich nicht in der Lage, irgendetwas anderes aufzunehmen als etwas Weißes, das alles und zugleich nichts bedeutet.
<G-vec00169-001-s101><capture.aufnehmen><en> Refractor telescopes use lenses instead of mirrors to capture the image and magnify it.
<G-vec00169-001-s101><capture.aufnehmen><de> Refraktorteleskope Linsen anstelle von Spiegeln das Bild aufzunehmen und es zu vergrößern.
<G-vec00169-001-s102><capture.aufnehmen><en> The MCU (1) gets the command from the connected PC to capture an image and starts the stepper motor of the manipulator.
<G-vec00169-001-s102><capture.aufnehmen><de> Die MCU (1) erhält vom angeschlossenen PC den Befehl, ein Bild aufzunehmen, und startet daraufhin den Schrittmotor des Manipulators (2).
<G-vec00169-001-s103><capture.aufnehmen><en> The technique again significantly increases the speed of MRI scans and can capture up to 100 images per second.
<G-vec00169-001-s103><capture.aufnehmen><de> Die Technik beschleunigte die MRT-Aufnahmen noch einmal deutlich und erlaubt es, bis zu 100 Bilder pro Sekunde aufzunehmen.
<G-vec00169-001-s104><capture.aufnehmen><en> We're all keen on searching the perfect moment to capture in a photo, but things get even more interesting with cinemagraphs.
<G-vec00169-001-s104><capture.aufnehmen><de> Wir alle suchen eifrig den perfekten Moment, ein Foto aufzunehmen, mit Cinemagrammen wird das Ganze noch interessanter.
<G-vec00169-001-s105><capture.aufnehmen><en> However, software can help to optimize the Dynamic Range for scanning allowing the scanner to capture as much image information as possible.
<G-vec00169-001-s105><capture.aufnehmen><de> Software kann allerdings helfen, den Dynamik-Umfang während des Scannens zu optimieren, um dem Scanner zu ermöglichen, möglichst viele Bildinformationen aufzunehmen.
<G-vec00169-001-s106><capture.aufnehmen><en> A lot of people tried to capture the precious scene with their cameras and camcorders.
<G-vec00169-001-s106><capture.aufnehmen><de> Viele Menschen versuchten, diese kostbare Szenerie mit ihren Fotoapparaten und Videokameras aufzunehmen.
<G-vec00169-001-s107><capture.aufnehmen><en> In fact, this camera is loaded with features that make it possible to capture amazing photos in any lighting.
<G-vec00169-001-s107><capture.aufnehmen><de> Tatsächlich ist diese Kamera mit Funktionen ausgestattet, die es ermöglichen, erstaunliche Fotos bei jeder Beleuchtung aufzunehmen.
<G-vec00169-001-s108><capture.aufzeichnen><en> BG SEX does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s108><capture.aufzeichnen><de> BG SEX gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s109><capture.aufzeichnen><en> It combines a digital audio recorder with a built-in high-speed chromatic tuner with metronome to capture a training session and review the results.
<G-vec00169-001-s109><capture.aufzeichnen><de> Es verbindet ein ultraschnelles chromatisches Stimmgerät mit einem Metronom und einem digitalen Audiorecorder, um eine Übungssession aufzuzeichnen und das Ergebnis zu überprüfen.
<G-vec00169-001-s110><capture.aufzeichnen><en> BongaCam Chat does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s110><capture.aufzeichnen><de> BongaCam Chat gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s111><capture.aufzeichnen><en> Your device can also wirelessly connect to external ANT+ sensors and other Garmin devices to capture even more performance data.
<G-vec00169-001-s111><capture.aufzeichnen><de> Das Gerät kann auch drahtlos eine Verbindung mit externen ANT+ Sensoren und anderen Geräten von Garmin herstellen, um zusätzliche Leistungsdaten aufzuzeichnen.
<G-vec00169-001-s112><capture.aufzeichnen><en> It is for internal use drone equipped with a camera to capture the surroundings from a height.
<G-vec00169-001-s112><capture.aufzeichnen><de> Einige Drohnen sind mit einer Kamera ausgestattet um die Umgebung während dem Flug aufzuzeichnen.
<G-vec00169-001-s113><capture.aufzeichnen><en> CAMSEX.SU does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s113><capture.aufzeichnen><de> CAMSEX.SU gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s114><capture.aufzeichnen><en> BBW Cams does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s114><capture.aufzeichnen><de> BBW Cams gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s115><capture.aufzeichnen><en> Darmowe Sex Kamerki does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s115><capture.aufzeichnen><de> Darmowe Sex Kamerki gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s116><capture.aufzeichnen><en> The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s116><capture.aufzeichnen><de> Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s117><capture.aufzeichnen><en> 69chat.me does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s117><capture.aufzeichnen><de> 69chat.me gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s118><capture.aufzeichnen><en> • Intercept events from another application - The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s118><capture.aufzeichnen><de> • Ereignisse von anderer Anwendung abfangen - Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s119><capture.aufzeichnen><en> Custom Size: select this option to capture images in the customized size specified on the Capture tab in the Settings window.
<G-vec00169-001-s119><capture.aufzeichnen><de> Benutzerdefinierte Größe: Wählen Sie diese Option aus, um Bilder in der Größe aufzuzeichnen, die Sie auf der Registerkarte Screenshot im Fenster Einstellungen festgelegt haben.
<G-vec00169-001-s120><capture.aufzeichnen><en> • Intercept events from another application – The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s120><capture.aufzeichnen><de> • Ereignisse von anderer Anwendung abfangen - Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s121><capture.aufzeichnen><en> Cams Avenue does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s121><capture.aufzeichnen><de> Cams Avenue gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s122><capture.aufzeichnen><en> After you have created the capture image, follow the instructions in the next section to boot a computer into the capture image and capture the operating system.
<G-vec00169-001-s122><capture.aufzeichnen><de> Befolgen Sie nach dem Erstellen des Aufzeichnungsabbilds die Anweisungen im nächsten Abschnitt, um einen Computer mit dem Aufzeichnungsabbild zu starten und das Betriebssystem aufzuzeichnen.
<G-vec00169-001-s123><capture.aufzeichnen><en> Incorporates a built-in logger to capture and store event history, alarms, and calibration information for later use.
<G-vec00169-001-s123><capture.aufzeichnen><de> Verfügt über einen integrierten Datenlogger, um den Ereignisverlauf, Alarme und Kalibrierinformationen für den späteren Gebrauch aufzuzeichnen und zu speichern.
<G-vec00169-001-s124><capture.aufzeichnen><en> Use a software like tcpdump or wireshark to capture the data.
<G-vec00169-001-s124><capture.aufzeichnen><de> Benutze eine Software wie tcpdump oder Wireshark, um die Daten aufzuzeichnen.
<G-vec00169-001-s125><capture.aufzeichnen><en> The picture will capture both your visible space and your holograms placed on top of it.
<G-vec00169-001-s125><capture.aufzeichnen><de> Das Bild wird Space sichtbar und Ihre Hologramme darüber platziert aufzuzeichnen.
<G-vec00169-001-s126><capture.aufzeichnen><en> Elsewhere within the Health and Social Care faculty, Panasonic remote cameras are used to capture practical elements of the University's Operating Department Practitioner (ODP) course.
<G-vec00169-001-s126><capture.aufzeichnen><de> Klinische Ausbildung auf höchstem Niveau An der Fakultät für Gesundheits- und Sozialwesen kommen darüber hinaus auch Panasonic Remote-Kameras zum Einsatz, um praktische Elemente der Kurse für Perioperativmediziner (ODPs) aufzuzeichnen.
<G-vec00169-001-s127><capture.bannen><en> If I recall correctly there were seven cameras in the house that night, trying to capture the magic of Poets of the Fall on film.
<G-vec00169-001-s127><capture.bannen><de> Wenn ich mich recht erinnere waren es sieben Kameras, mit denen an diesem Abend versucht wurde, die Magie, die ein Poets of the Fall Konzert ausmacht auf Film zu bannen.
<G-vec00169-001-s128><capture.bannen><en> By contrast, the Tyrolean artist Josef Anton Koch aimed to capture divine creation in his images of nature, as shown in his painting Bernese Oberland (1815).
<G-vec00169-001-s128><capture.bannen><de> Der Tiroler Künstler Josef Anton Koch versuchte dagegen, die göttliche Schöpfung in seinen Naturdarstellungen zu bannen, wie das Gemälde Berner Oberland (1815) zeigt.
<G-vec00169-001-s129><capture.bannen><en> “Wölfl, on the other hand, bred in Mozart’s school was always the same; never shallow, but always clear, and just by this more accessible for the majority … always he knew to exite interest, and to capture this unwaveringly to the flow of his well-ordered ideas.
<G-vec00169-001-s129><capture.bannen><de> »Wölfl hingegen, in Mozarts Schule gebildet blieb immerdar sich gleich; nie flach, aber stets klar, und eben deswegen der Mehrzahl zugänglicher … stets wußte er Antheil zu erregen, und diesen unwandelbar an den Reihengang seiner wohlgeordneten Ideen zu bannen.
<G-vec00169-001-s130><capture.bannen><en> Nonetheless, he managed to find musicians to work with him and his tried and tested accompanying musicians to capture an album that is thoroughly surprising for the Austrian.
<G-vec00169-001-s130><capture.bannen><de> Dennoch hat er es geschafft, Musiker aufzutun, um mit ihnen und seinen bewährten Begleitmusikern ein für den Österreicher durchaus überraschendes Album auf Tonträger zu bannen.
<G-vec00169-001-s131><capture.bannen><en> A photography teacher assaults a student during a lesson while the fellow students capture the event on film.
<G-vec00169-001-s131><capture.bannen><de> Ein Lehrer für Fotografie vergreift sich während der Schulstunde an einer Studentin, während die Kommilitonen die Szenerie fachgerecht auf Film bannen.
<G-vec00169-001-s132><capture.bannen><en> Where else can you capture simultaneously sea, a black beach, a lighthouse and a glacier in one photograph?
<G-vec00169-001-s132><capture.bannen><de> Wo kann man sonst schon Meer, schwarzen Strand, einen Leuchtturm sowie einen Gletscher gleichzeitig auf ein Foto bannen.
<G-vec00169-001-s133><capture.bannen><en> He tried to capture this on canvas.
<G-vec00169-001-s133><capture.bannen><de> Das hat er versucht, auf die Leinwand zu bannen.
<G-vec00169-001-s134><capture.bannen><en> Monday night’s concert at Irving Plaza had all the earmarks of a typical a-ha concert in Norway: journalists from VG, Dagbladet and other media on hand to cover the event; a line of fans waiting outside the venue from 8:00am; Lauren Savoy and a film crew on site to capture the concert on film; and fan parties organized to celebrate the occasion.
<G-vec00169-001-s134><capture.bannen><de> Übersetzung: Meike Beier Das Konzert im Irving Plaza am Montagabend wies alle Kennzeichen eines typischen a-ha-Konzertes in Norwegen auf: Journalisten von VG, Dagbladet und anderen Medien waren in Stellung, um über das Ereignis zu berichten; eine Schlange von Fans wartete seit 8 Uhr morgens vor dem Club; Lauren Savoy und eine Filmcrew war vor Ort, um das Konzert auf Film zu bannen; und Fanpartys wurden zur Feier des Tages organisiert.
<G-vec00169-001-s135><capture.bannen><en> Barthes' way of resisting cinema is not to remove himself from the fascination of the performance/ the performed illusion, or to capture it in shades of ideological criticism or counter discourses; instead, he resists cinema by surrendering himself to the movie as well as to the movie theater.
<G-vec00169-001-s135><capture.bannen><de> Barthes' Weise dem Kino zu widerstehen, ist es nun nicht, sich der Faszination des Spiels/Illusionsspiels zu entziehen, sie durch Ideologiekritik oder Gegenlektüren zu bannen, sondern sich sowohl dem Film als auch dem Kinoraum hinzugeben.
<G-vec00169-001-s136><capture.bannen><en> Sascha Weidner (1976–2015) had an eye for magic moments; he knew how to capture the poetic, the fleeting on paper.
<G-vec00169-001-s136><capture.bannen><de> Sascha Weidner (1976–2015) hatte den Blick für magische Momente, er wusste das Poetisch-Flüchtige auf Papier zu bannen.
<G-vec00169-001-s137><capture.bannen><en> Though Hollywood has attempted to capture these natural wonders, nothing compares to physically standing in the national park to immerse its grandeur.
<G-vec00169-001-s137><capture.bannen><de> Obgleich Hollywood vielfach versucht hat, diese Naturwunder für den Zuschauer auf Film zu bannen, ist das nichts im Vergleich dazu, diesen Nationalpark in all seiner Pracht aus nächster Nähe zu erleben und vollkommen in diese Welt einzutauchen.
<G-vec00169-001-s138><capture.bannen><en> capture on a wonderful photo.
<G-vec00169-001-s138><capture.bannen><de> auf ein wunderbares Foto bannen.
<G-vec00169-001-s243><capture.einfangen><en> "Museums should capture this, he continues, but he also wants the Museum Of London to be a place where you can ""look back and forecast on a macro level whilst future gazing, too..."
<G-vec00169-001-s243><capture.einfangen><de> "Museen sollten dies einfangen, führt er weiter aus, aber er möchte aus dem Museum of London auch einen Ort machen, an dem man ""zurückblicken kann während man zugleich, wenn vielleicht auch nur auf Makroebene, die Zukunft prognostiziert..."
<G-vec00169-001-s244><capture.einfangen><en> The mermaid was supposed to capture their odours from which she controlled their lives through mystical mirrors.
<G-vec00169-001-s244><capture.einfangen><de> Die Meerjungfrau sollte ihre Gerüche einfangen, aus denen sie ihr Leben durch mystische Spiegel kontrollierte.
<G-vec00169-001-s245><capture.einfangen><en> The show focuses on Toulouse-Lautrec’s preferred and frequently repeated motifs that reflect his constant interest in the human psyche: Topics which at the beginning of his artistic career are rooted in a rural ambiance and that over the course of his development increasingly capture the metropolis of Paris with its vibrant Fin de Siècle atmosphere and eyes fixed firmly on the future.
<G-vec00169-001-s245><capture.einfangen><de> Die Schau orientiert sich an den von Toulouse-Lautrec bevorzugten und immer wiederholten Sujets, die sein durchgängies Interesse an der menschlichen Psyche spiegeln: Themen, die zu Beginn seiner künstlerischen Laufbahn im ländlichen Ambiente verwurzelt sind und die im Laufe seiner Entwicklung immer mehr die in die Zukunft gerichtete Metropole Paris mit ihrer vibrierenden Atmosphäre des Fin de Siècle einfangen.
<G-vec00169-001-s246><capture.einfangen><en> "In his lecture Science && Fiction in the age of moon landings, Hubert Zitt will ""capture"" the zeitgeist of that time and show how people thought then and what visions they had with selected scenes from science fiction films and series."
<G-vec00169-001-s246><capture.einfangen><de> "Hubert Zitt wird in seinem Vortrag Science && Fiction im Zeitalter der Mondlandungen den damaligen Zeitgeist ""einfangen"" und anhand von ausgewählten Szenen aus Science-Fiction-Filmen und -Serien zeigen, wie die Menschen damals gedacht haben und welche Visionen sie hatten."
<G-vec00169-001-s247><capture.einfangen><en> CERN houses a machine called the antiproton decelerator, a storage ring that can capture and slow antiprotons to study their properties and behaviour.
<G-vec00169-001-s247><capture.einfangen><de> CERN besitzt eine Maschine die Antiproton-Entschleuniger heißt, ein Speicherring der Antiprotonen einfangen und verlangsamen kann, um ihre Eigenschaften und Verhalten zu studieren.
<G-vec00169-001-s248><capture.einfangen><en> He enjoys practising all areas of photography and loves getting creative with how we capture our paper; both on and off the wall.
<G-vec00169-001-s248><capture.einfangen><de> Er liebt den Umgang mit allen Bereichen der Fotografie und gestaltet gerne kreativ mit den Techniken, mit denen wir unser Papier einfangen, sowohl auf als auch abseits der Wand.
<G-vec00169-001-s249><capture.einfangen><en> In order to capture such great lighting moods, it is very important that the image is not exposed too much.
<G-vec00169-001-s249><capture.einfangen><de> Um solch tollen Lichtstimmungen einfangen zu können, ist es sehr wichtig, dass das Bild nicht zu hell belichtet wird.
<G-vec00169-001-s250><capture.einfangen><en> Punkka specialises in intimate close-up shots that capture the emotions of the wildlife right at the moment of the shot.
<G-vec00169-001-s250><capture.einfangen><de> Punkkas Spezialität sind intime Nahaufnahmen, welche die Emotionen der Tiere direkt zum Zeitpunkt der Aufnahme einfangen.
<G-vec00169-001-s251><capture.einfangen><en> The impressionists found out that they could capture the momentary and fleeting effects of light by painting en plein air.
<G-vec00169-001-s251><capture.einfangen><de> Die Impressionisten entdeckten, dass sie die momentanen und vorübergehenden Effekte des Lichts einfangen können, indem sie im Freilicht malen.
<G-vec00169-001-s252><capture.einfangen><en> One cannot capture a child for oneself, neither through overprotection, nor through excessive offers of gifts and other goods.
<G-vec00169-001-s252><capture.einfangen><de> Man kann ein Kind nicht für sich einfangen, weder durch Überhütung, noch durch das Überangebot von Geschenken und Konsum.
<G-vec00169-001-s253><capture.einfangen><en> The new filter will be the biggest of its kind in the world and will capture large additional amounts of dust.
<G-vec00169-001-s253><capture.einfangen><de> Dieser Neubau wird die weltweit größte Filteranlage für den Sinterprozess sein und große Mengen Staub zusätzlich einfangen.
<G-vec00169-001-s254><capture.einfangen><en> Featuring 170-degree wide angle lens, it can capture broader images.
<G-vec00169-001-s254><capture.einfangen><de> Mit 170-Grad-Weitwinkelobjektiv kann es breitere Bilder einfangen.
<G-vec00169-001-s255><capture.einfangen><en> With spectacular monuments dating back almost 800 years, such as the Amsterdamse Poort and Sint-Bavokerk, it's no wonder that so many great artists of the Golden Age wanted to capture its beauty and atmosphere.
<G-vec00169-001-s255><capture.einfangen><de> Bei den eindrucksvollen Monumenten, die fast 800 Jahre zurückreichen, wie der Amsterdamse Poort und die Sankt-Bavo-Kirche ist es kein Wunder, dass so viele großartige Künstler des Goldenen Zeitalters die Schönheit und Atmosphäre einfangen wollten.
<G-vec00169-001-s256><capture.einfangen><en> THE JOURNEY TO THE ISLAND …reach, carried by ferry, involves an emotional detachment and real from care on existing terra..e this is already one of the first miracles which can be observed…Then we wrapped the scenario of infinite horizons that already capture the soul…..and... Read » tweet
<G-vec00169-001-s256><capture.einfangen><de> DIE REISE ZUR INSEL...erreichen, einem Fährschiff befördert, beinhaltet eine emotionale Distanz und Echt von Pflege bestehender terra..e das ist schon eine der ersten Wunder, die beobachtet werden können...Dann das Szenario der unendlichen Horizonten, die schon die Seele einfangen gewickelt wir.....und...
<G-vec00169-001-s257><capture.einfangen><en> Naked, happy and completely natural, as if there would be no flash lights installed and no photographer present who wants to capture the sensual tension between an innocent playful little girl and a seductive, sexually alluring woman in provocative nude photos, the young Argentine Yana plays and cuddles obliviously with the teddy bears in the bed.
<G-vec00169-001-s257><capture.einfangen><de> Nackt, fröhlich und völlig natürlich, als wären da keine Blitzlichter aufgestellt und kein Fotograf anwesend, der die sinnliche Spannung zwischen unschuldig verspieltem kleinem Mädchen und sexuell verführerischer Frau in provokativen Aktfotografien einfangen will, spielt und kuschelt die junge Argentinierin Yana selbstvergessen mit den Teddybären im Bett.
<G-vec00169-001-s258><capture.einfangen><en> “As a parent of two children (8 & 10 years old), I was looking to create a game which would capture the imagination of the current generation of school-aged children – a game which would excite and absorb them, one where they could improve their skills, and primarily, a game able to keep their attention.
<G-vec00169-001-s258><capture.einfangen><de> “Als Vater zweier Kinder (8 & 10 Jahre alt), habe ich versucht ein Spiel zu entwickeln, dass die Vorstellungskraft der aktuellen Generation der Schulkinder einfängt – ein Spiel, dass sie begeistern und einfangen kann, eines bei dem sie ihre Fähigkeiten steigern können, und als wichtigstes, ein Spiel dass ihre Aufmerksamkeit behält.
<G-vec00169-001-s259><capture.einfangen><en> A mere few seconds that powerfully capture the friendship and unique collaboration between the two storied musicians.
<G-vec00169-001-s259><capture.einfangen><de> Nur wenige Sekunden, die die Freundschaft und die einzigartige Zusammenarbeit der beiden Musiker eindrucksvoll einfangen.
<G-vec00169-001-s260><capture.einfangen><en> Use Windows Movie Maker to preview the program and capture it to wmv, then extract the file to mp3.
<G-vec00169-001-s260><capture.einfangen><de> Verwenden Sie den Windows Movie Maker, um eine Vorschau des Programms und einfangen zu WMV, extrahieren Sie dann die Datei in MP3.
<G-vec00169-001-s261><capture.einfangen><en> All this has its limitations, because such recordings can capture only something that is gross and dense.
<G-vec00169-001-s261><capture.einfangen><de> All das hat aber Grenzen, da solche Aufnahmen nur etwas, das grobstofflich und verdichtet ist, einfangen können.
<G-vec00169-001-s281><capture.einnehmen><en> You say that you’re going to capture this place, and that men being there constitutes a risk factor.
<G-vec00169-001-s281><capture.einnehmen><de> Sie sagen, dass Sie diesen Ort einnehmen werden, und dass die Männer dort einen Risikofaktor darstellen.
<G-vec00169-001-s282><capture.einnehmen><en> "3 And this is what the LORD says: 'This city will certainly be handed over to the army of the king of Babylon, who will capture it.'"""
<G-vec00169-001-s282><capture.einnehmen><de> 3 So spricht der HERR: Diese Stadt wird ganz gewiß in die Hand des Heeres des Königs von Babel gegeben werden, und er wird sie einnehmen.
<G-vec00169-001-s283><capture.einnehmen><en> Its rugged construction and extremely wide measurement range up to 570 km/h will enable it to capture a leading position in the market.
<G-vec00169-001-s283><capture.einnehmen><de> Durch den robusten Aufbau und den äuÃ erst groÃ en Messbereich von bis zu 570 km/h wird es auf dem Markt eine hervorragende Stellung einnehmen.
<G-vec00169-001-s284><capture.einnehmen><en> 15 Then the king of the North will come and build up siege ramps and will capture a fortified city.
<G-vec00169-001-s284><capture.einnehmen><de> 15 Und der König des Nordens wird kommen und einen Wall aufschütten und eine befestigte Stadt einnehmen.
<G-vec00169-001-s285><capture.einnehmen><en> Once you have taken control of one of the crystals on the side of the map, you may capture the crystal in the middle.
<G-vec00169-001-s285><capture.einnehmen><de> Sobald ihr einen der Kristalle am Rand der Karte kontrolliert, könnt ihr den Kristall in der Mitte einnehmen.
<G-vec00169-001-s286><capture.einnehmen><en> _____ Cyrus would capture Babylon_____ George Washington would become president of the United States._____ Egypt would never again be a strong, leading nation._____ Morals would degenerate in the last days._____ Germany would have a 20-year drought._____ Babylon, once destroyed, would never be inhabited again.2.
<G-vec00169-001-s286><capture.einnehmen><de> _____ Cyrus würde Babylon einnehmen _____ Ronald Reagan würde Präsident der Vereinigten Staaten _____ Ägypten würde nie wieder eine starke, führende Macht werden _____ Moralischer Niedergang in den letzten Tagen _____ Eine 20-jährige Trockenheit in Deutschland _____ Babylon würde nach seiner Zerstörung nie wieder bewohnt werden 2.
<G-vec00169-001-s287><capture.einnehmen><en> With it in any case, you can not give slack, otherwise it will certainly capture leadership.
<G-vec00169-001-s287><capture.einnehmen><de> Mit ihm kann man auf keinen Fall Durchhang geben, sonst wird es sicherlich Führung einnehmen.
<G-vec00169-001-s288><capture.einnehmen><en> In Uplink, communication relays are dropped into the play area and players must capture and hold them to gain points.
<G-vec00169-001-s288><capture.einnehmen><de> In Uplink fallen Funkverstärker in den Spielbereich, die die Spieler einnehmen und halten müssen, um Punkte zu sammeln.
<G-vec00169-001-s289><capture.einnehmen><en> Whenever your commander is on a keep (not only your own, but also the keep of any enemy castles you capture) and you have enough gold, you can recruit units for your army.
<G-vec00169-001-s289><capture.einnehmen><de> Wenn sich dein Anführer auf einem Burgfried befindet (es muss nicht zwingend sein eigener sein, du kannst auch die Burgen Anderer einnehmen) und dir genug Gold zur Verfügung steht, kannst du Einheiten ausbilden.
<G-vec00169-001-s290><capture.einnehmen><en> The capture of souls at such an early age is a despicable thing.
<G-vec00169-001-s290><capture.einnehmen><de> Das Einnehmen von Seelen in einem so frühen Alter, ist eine verabscheuenswerte Handlung.
<G-vec00169-001-s291><capture.einnehmen><en> Before a military offensive is launched against the Caliphate metropolis, Mosul, Iraqi forces must capture several IS strongholds on the Euphrates.
<G-vec00169-001-s291><capture.einnehmen><de> Vor einer Militäroffensive gegen die Kalifatsmetropole Mosul müssen irakische Truppen mehrere IS-Hochburgen am Euphrat einnehmen.
<G-vec00169-001-s292><capture.einnehmen><en> The attacking fleet must sail into the harbour and capture the port, running the gauntlet of coastal gun defences.
<G-vec00169-001-s292><capture.einnehmen><de> Die angreifende Flotte muss in den Hafen segeln, ihn einnehmen und dabei den Kanonenbeschuss der Küstenverteidigung überstehen.
<G-vec00169-001-s293><capture.einnehmen><en> BLU must capture both control points on every stage, whereas RED must defend the points.
<G-vec00169-001-s293><capture.einnehmen><de> TR-Dustbowl BLU muss beide Control Points auf jeder Stage einnehmen, während RED dies verhindern muss.
<G-vec00169-001-s294><capture.einnehmen><en> 11:15 Then the king of the North will come and build up siege ramps and will capture a fortified city.
<G-vec00169-001-s294><capture.einnehmen><de> 11:15 Und der König des Nordens wird kommen und einen Wall aufschütten und eine feste Stadt einnehmen.
<G-vec00169-001-s295><capture.einfangen><en> "Film made it possible for the first time in the history of art and culture to capture time directly without stopping it – a phenomenon that Andrei Tarkovsky called in his eponymous essay ""sealed time""."
<G-vec00169-001-s295><capture.einfangen><de> "Mit dem Film war es zum ersten Mal in der Geschichte von Kunst und Kultur möglich, Zeit unmittelbar einzufangen ohne sie aufzuhalten – ein Phänomen, das Andrej Tarkowskij in dem gleichnamigen Essay ""šDie versiegelte Zeit' nannte."
<G-vec00169-001-s296><capture.einfangen><en> [book tip by Beat Mazenauer] Turbulent times lead to turbulent lives – and literature, which attempts to capture this turbulence.
<G-vec00169-001-s296><capture.einfangen><de> [Buchtipp von Beat Mazenauer] Turbulente Zeiten bringen turbulente Leben hervor - und eine Literatur, die solche Turbulenzen einzufangen versucht.
<G-vec00169-001-s297><capture.einfangen><en> Be it the use of the trombone to mimic the sound of the dung-chen (a very long Tibetan horn) or use of strings to capture the character indigenous folk tunes, the final musical experience is a result of informed imagination and collaborative effort.
<G-vec00169-001-s297><capture.einfangen><de> Sei es die Verwendung der Posaune, um den Klang des Dung-chen (ein sehr langes tibetisches Horn) nachzuahmen oder die Verwendung von Streichinstrumenten, um den Charakter der einheimischen Volksmusik einzufangen, das letztendliche musikalische Erlebnis ist das Ergebnis einer fundierten Vorstellungskraft und Zusammenarbeit.
<G-vec00169-001-s298><capture.einfangen><en> It was similar for the painter Jacques-Louis David, a supporter of the French Revolution, who tried to capture the Revolution’s meaning with three portraits.
<G-vec00169-001-s298><capture.einfangen><de> Ähnlich verhält es sich bei Jacques-Louis David, ein Kämpfer für die französische Revolution, der die Bedeu-tung der französischen Revolution mit drei Portraits einzufangen versuchte.
<G-vec00169-001-s299><capture.einfangen><en> With four film crew members the groox team is at the track to capture the best pictures of the athletes.
<G-vec00169-001-s299><capture.einfangen><de> Mit vier Kameraleuten ist das groox-Team an der Strecke um die besten Bilder der AthletInnen einzufangen.
<G-vec00169-001-s300><capture.einfangen><en> So we'll have to find a way to capture sunlight, so that at any time of the year sunlight can get in....
<G-vec00169-001-s300><capture.einfangen><de> Außerdem muss man einen Weg finden, um die Sonne einzufangen: damit sie zu jeder Jahreszeit hereinscheinen kann...
<G-vec00169-001-s301><capture.einfangen><en> """Only Bruce Weber can capture the energy of a group and orchestrate it in vibrant harmony."
<G-vec00169-001-s301><capture.einfangen><de> """Nur Bruce Weber schafft es, die Energie einer Gruppe einzufangen und diese mit einer strahlenden Harmonie zu inszenieren."
<G-vec00169-001-s302><capture.einfangen><en> I want to tell stories.Photography and writing is a way of life and a form to capture, express and share personal feelings and life with the world.
<G-vec00169-001-s302><capture.einfangen><de> Ich möchte Geschichten erzählen.Die Fotografie und das Schreiben sind eine Lebensart, eine Möglichkeit, Gefühle einzufangen, auszudrücken und mit der Welt zu teilen.
<G-vec00169-001-s303><capture.einfangen><en> They also ride on their raids, and endeavor to capture the camels of hostile clans.
<G-vec00169-001-s303><capture.einfangen><de> Sie reiten auch auf ihren Überfällen und bemühen sich, die Kamele feindlicher Clans einzufangen.
<G-vec00169-001-s304><capture.einfangen><en> "The latter succeeded to capture a certain ""campfire"" feeling, the acoustic instrument parts sounds like the guys are here with you in you living room, playing live (Kuni pole kodus, olen kaugel teel - Until I Arrive At Home, I'm On A Distant Road)."
<G-vec00169-001-s304><capture.einfangen><de> "Selbiger schaffte es auch, ein gewisses ""Lagerfeuer""-Feeling einzufangen, die Instrumente klingen bei akustischen Tracks/Parts so ""roh"" und ""pur"", als würden die Jungs leibhaftig im heimischen Wohnzimmer aufspielen (Kuni pole kodus, olen kaugel teel - Until I Arrive At Home, I'm On A Distant Road)."
<G-vec00169-001-s305><capture.einfangen><en> Get more time by capturing clocks and get more bubble juice when you capture a bubble bottle.
<G-vec00169-001-s305><capture.einfangen><de> Holen Sie sich mehr Zeit durch die Erfassung Uhren und weitere Blase Saft, wenn man eine Blase Flasche einzufangen.
<G-vec00169-001-s306><capture.einfangen><en> I have just begun a series of landscape paintings and am working to capture an essential 'Light'.
<G-vec00169-001-s306><capture.einfangen><de> Ich habe gerade begonnen eine Serie von Landschaften zu malen und arbeite daran ein essentielles 'Licht' einzufangen.
<G-vec00169-001-s307><capture.einfangen><en> The more bugs you capture in a bubble the more points you get.
<G-vec00169-001-s307><capture.einfangen><de> Je mehr Fehler Sie in einer Blase, desto mehr Punkte erhalten Sie einzufangen.
<G-vec00169-001-s308><capture.einfangen><en> Our inspirations were classic gangster movies and we tried to capture that atmosphere in a video game.
<G-vec00169-001-s308><capture.einfangen><de> Unsere Inspiration waren klassische Gangsterfilme und wir haben versucht, die Atmosphäre daraus in einem Videospiel einzufangen.
<G-vec00169-001-s309><capture.einfangen><en> "The Museum of the ""Festa"" (the Elche's Mystery Drama) intends to capture both in space and time part of the magic shrouding the ""Festa"" to show it to people visiting Elche all over the year."
<G-vec00169-001-s309><capture.einfangen><de> "Das ""Festa"" Museum versucht Teile des Magie umwobenen""Festa"" in Raum und Zeit einzufangen, um sie das ganze Jahr über den Leuten, die Elche besuchen, zu zeigen."
<G-vec00169-001-s310><capture.einfangen><en> From about 1628, Jan van Goyen attempted to capture spatial expanse as well as the quality of light and air with a palette tending towards tonality.
<G-vec00169-001-s310><capture.einfangen><de> Ab etwa 1628 versuchte Jan van Goyen die Weite des Raumes, wie auch Licht und Atmosphäre mit Hilfe einer zur Tonigkeit neigenden Palette einzufangen, welche um 1640 ihren Höhepunkt erreichte.
<G-vec00169-001-s311><capture.einfangen><en> "To capture this, the so-called ""bergamot-sponge"" method is used - a tradition carried out exclusively by hand, which collects the essential oils from the bergamot shell."
<G-vec00169-001-s311><capture.einfangen><de> "Um jenes einzufangen, wird die sogenannte ""Bergamotte-Schwamm"" Methode angewandt - eine ausschließlich per Hand ausgeführte Tradition, welche die essentiellen Öle aus der Schale der Bergamotte sammelt."
<G-vec00169-001-s312><capture.einfangen><en> It is not easy to capture this picture with the camera and reproduce it.
<G-vec00169-001-s312><capture.einfangen><de> Dieses Bild mit der Kamera einzufangen und wiederzugeben ist nicht einfach.
<G-vec00169-001-s313><capture.einfangen><en> "It is a formulation that also recalls a phrase of Roland Barthes, who pointed out that the complexity and constant process of ""becoming oneself"" are difficult to capture in a photograph: ""'Myself' never coincides with my image; for it is the image which is heavy, motionless, stubborn [...]; and 'myself' which is light, divided, dispersed [...]""."
<G-vec00169-001-s313><capture.einfangen><de> "Die Formulierung erinnert auch an eine Aussage Roland Barthes, der darauf hinwies, dass die Vielschichtigkeit und der ständige Prozess des Ich-Werdens schwer in einem Foto einzufangen sind: ""Mein 'Ich' ist's, das nie mit seinem Bild übereinstimmt; denn schwer, unbeweglich, eigensinnig ist schließlich das Bild [...]; leicht, vielteilig, auseinanderstrebend ist mein 'Ich' [...]""."
<G-vec00169-001-s314><capture.einnehmen><en> Try to capture and keep control of as many villages as possible to keep the gold coming in
<G-vec00169-001-s314><capture.einnehmen><de> Versuche, so viele Dörfer wie möglich einzunehmen und zu halten, um genügend Gold zu bekommen.
<G-vec00169-001-s315><capture.einnehmen><en> The superior enemy forces were eventually able to capture this first checkpoint and most of the town.
<G-vec00169-001-s315><capture.einnehmen><de> Die übermächtigen feindlichen Kräfte waren in der Lage, den ersten Stützpunkt und einen Großteil der Stadt einzunehmen.
<G-vec00169-001-s316><capture.einnehmen><en> As the holy city comes down from God out of heaven (Revelation 21:2), the wicked attempt to capture it.
<G-vec00169-001-s316><capture.einnehmen><de> Während die heilige Stadt von Gott aus dem Himmel herabkommt (Offenbarung 21:2), werden die Gottlosen versuchen, diese einzunehmen.
<G-vec00169-001-s317><capture.einnehmen><en> The objective of this mission is for a Taliban unit to capture a Patriot battery in Afghanistan to shoot down a Soviet helicopter on the other side of the border.
<G-vec00169-001-s317><capture.einnehmen><de> Bei dieser Mission ist es das Ziel einer Taliban Einheit kurzfristig eine Patriot Batterie in Afghanistan einzunehmen, um mit ihr einen sowjetischen Hubschrauber auf der anderen Seite der Grenze abzuschießen.
<G-vec00169-001-s318><capture.einnehmen><en> Over and over again hostile armies have tried to capture Luanda and it has always resulted in displacement and agony for the farming population around the city.
<G-vec00169-001-s318><capture.einnehmen><de> Immer wieder versuchten feindliche Armeen, Luanda einzunehmen und immer wieder führte das zu Vertreibung und Leid der bäuerlichen Bevölkerung um die Stadt herum.
<G-vec00169-001-s319><capture.einnehmen><en> To capture the city, your friendly tank convoy must reach the enemy city and it must win against the defense line setup by the defending city.
<G-vec00169-001-s319><capture.einnehmen><de> Um eine Stadt einzunehmen, muss Ihre eigene gepanzerte Kolonne die feindliche Stadt erreichen und die Verteidigung der feindlichen Stadt besiegen.
<G-vec00169-001-s320><capture.einnehmen><en> This stage works in the same manner as the Control game mode – each player can deploy a drone at a control point to capture it.
<G-vec00169-001-s320><capture.einnehmen><de> Diese Phase funktioniert auf dieselbe Weise, wie der Kontrolle-Spielmodus – die Spieler werfen an den Kontrollpunkten ihre Drohnen ab, um diese einzunehmen.
<G-vec00169-001-s321><capture.einnehmen><en> He will resume the battle against God as he tries to capture the holy city.
<G-vec00169-001-s321><capture.einnehmen><de> Er wird den Kampf gegen Gott wieder aufnehmen und versuchen, die heilige Stadt einzunehmen.
<G-vec00169-001-s322><capture.einnehmen><en> They surround the holy city to capture it (Revelation 20:9), and fire comes down from God out of heaven and devours them.
<G-vec00169-001-s322><capture.einnehmen><de> Sie umzingeln die heilige Stadt, um sie einzunehmen (Offenbarung 20:9), dann fällt Feuer von Gott aus dem Himmel und verzehrt sie.
<G-vec00169-001-s323><capture.einnehmen><en> But they are highly tactical units with the unique ability to capture buildings twice as fast as any other.
<G-vec00169-001-s323><capture.einnehmen><de> Sie sind hochtaktische Einheiten mit der einzigartigen Fähigkeit, Gebäude doppelt so schnell einzunehmen wie andere Zombies.
<G-vec00169-001-s324><capture.einnehmen><en> Apart from bringing the necessary talent, he also knew how to capture people with his charm and kindness.
<G-vec00169-001-s324><capture.einnehmen><de> Abgesehen davon, dass er das nötige Talent mitbrachte, verstand er es auch, die Leute mit seinem Charme und seiner Liebenswürdigkeit für sich einzunehmen.
<G-vec00169-001-s325><capture.einnehmen><en> When you shall besiege a city a long time, in making war against it to capture it, you shall not destroy its trees, nor wield an axe against them;
<G-vec00169-001-s325><capture.einnehmen><de> Wenn du eine Stadt viele Tage belagerst, um gegen sie zu kämpfen und sie einzunehmen, sollst du ihre Bäume nicht vernichten, indem du die Axt gegen sie schwingst.
<G-vec00169-001-s326><capture.einnehmen><en> If the attackers manage to capture the point before the time runs out, a payload must be taken to a target destination in the second section of the map.
<G-vec00169-001-s326><capture.einnehmen><de> Gelingt es dem angreifenden Team vor Ablauf der Zeit den Punkt einzunehmen, so muss im zweiten Abschnitt der Karte eine Fracht ins Ziel befördert werden.
<G-vec00169-001-s327><capture.einnehmen><en> To capture a control point, fly within range of the objective and tap the C directional button to deploy a drone.
<G-vec00169-001-s327><capture.einnehmen><de> Um einen Kontrollpunkt einzunehmen, müssen die Piloten in Reichweite des Ziels fliegen und die Richtungstaste C drücken, um eine Drohne abzusetzen.
<G-vec00169-001-s328><capture.einnehmen><en> NOTE: Satan will deceive people into believing that he was unjustly deposed from heaven and that together they can capture the city and take control.
<G-vec00169-001-s328><capture.einnehmen><de> Satan wird die Menschen glauben machen, dass er zu Unrecht aus dem Himmel ausgestossen worden sei und dass es ihnen mit vereinten Kräften gelingen würde, die Stadt einzunehmen und unter ihre Kontrolle zu bringen.
<G-vec00169-001-s329><capture.erfassen><en> It's fully adjustable, too, so you'll be able to capture great shots from creative new angles.
<G-vec00169-001-s329><capture.erfassen><de> Er ist außerdem voll verstellbar, sodass Sie tolle Aufnahmen aus kreativen neuen Blickwinkeln erfassen können.
<G-vec00169-001-s330><capture.erfassen><en> With original designs and very few units each seeking to capture the personality of the product looks.
<G-vec00169-001-s330><capture.erfassen><de> Mit originellem Design und nur sehr wenige Einheiten, Mehr... die jeweils versuchen, die Persönlichkeit zu erfassen der das Produkt aussieht.
<G-vec00169-001-s331><capture.erfassen><en> You can also create variables in a JavaScript action (Script task), to capture data that the script retrieves or calculates.
<G-vec00169-001-s331><capture.erfassen><de> Sie können auch in einer JavaScript-Action (Skriptaufgabe)-Aktion Variablen definieren, um Daten, die das Skript berechnet oder abruft, zu erfassen.
<G-vec00169-001-s332><capture.erfassen><en> The latter makes it possible to capture highlights and shadows that are not available with standard settings.
<G-vec00169-001-s332><capture.erfassen><de> Letzteres ermöglicht das Erfassen von Glanzlichtern und Schatten, die mit den Standardeinstellungen nicht verfügbar sind.
<G-vec00169-001-s333><capture.erfassen><en> The product labels and graphic elements on the front of the packaging box are very impressive and help to capture the attention of potential customers.
<G-vec00169-001-s333><capture.erfassen><de> Die Produktetikett und Grafikelemente auf der Vorderseite der Verpackung sind sehr beeindruckend und dazu beitragen, die Aufmerksamkeit potenzieller Kunden zu erfassen.
<G-vec00169-001-s334><capture.erfassen><en> There's no better way to capture the beauty of a city than to take a panoramic shot of it from up above or a clear, unobstructed spot—that should do the place justice.
<G-vec00169-001-s334><capture.erfassen><de> Drucken Es gibt keinen besseren Weg, um die Schönheit einer Stadt zu erfassen als eine Panorama-Aufnahme von oben oder von einer freien, unverbauten Stelle.
<G-vec00169-001-s335><capture.erfassen><en> From short distances, you can even view readings from modules through closed electrical panels. Plus no more writing down data as the CNX remote modules capture up to 65,000 sets of time stamped min/max/avg readings, using the optional PC adapter.
<G-vec00169-001-s335><capture.erfassen><de> Und Sie müssen keine Daten mehr von Hand notieren, da die CNX Fernmodule mithilfe des optionalen PC-Adapters bis zu 65.000 Werte mit Zeitstempel, Min./Max./Durchschnittswerten erfassen.
<G-vec00169-001-s336><capture.erfassen><en> Instagram detects whenever users capture a picture of their phone screens.
<G-vec00169-001-s336><capture.erfassen><de> Instagram erkennt, wenn Benutzer ein Bild von ihren Handy-Bildschirmen erfassen.
<G-vec00169-001-s337><capture.erfassen><en> Also does wedding photography, where he will help you to have an unforgettable memory of that day as important and as noted, giving a touch of originality and trying to capture the naturalness and spontaneity of the moment so important to you, where you really show your love story .
<G-vec00169-001-s337><capture.erfassen><de> Tut auch Hochzeitsfotos, wo er Ihnen helfen, eine unvergessliche Erinnerung an diesen Tag, wie wichtig und wie erwähnt haben, geben einen Hauch von Originalität und versuchen, die Natürlichkeit und Spontaneität des Moments, so wichtig für Sie, wo Sie wirklich zeigen Ihre Liebesgeschichte erfassen wird .
<G-vec00169-001-s338><capture.erfassen><en> In addition to this, Bank Austria offers hearing-impaired customers a special service at approximately 100 branches: Pick-up devices that capture the acoustic information and amplify it.
<G-vec00169-001-s338><capture.erfassen><de> DarÃ1⁄4ber hinaus bietet die Bank Austria fÃ1⁄4r ihre KundInnen mit eingeschränktem Hörvermögen in rund 100 Filialen ein besonderes Service: Induktionsgeräte, welche die akustischen Informationen erfassen und diese verstärken.
<G-vec00169-001-s339><capture.erfassen><en> It allows you to capture the everyday moment that happens around you and share them with family and friend everywhere.
<G-vec00169-001-s339><capture.erfassen><de> Es erlaubt Ihnen, den alltäglichen Moment zu erfassen, der um Sie herum geschieht und sie mit Familie und Freund überall teilen.
<G-vec00169-001-s340><capture.erfassen><en> Van Gogh worked rapidly with flickering strokes to capture the beautiful but fleeting effect.
<G-vec00169-001-s340><capture.erfassen><de> Transporter Gogh arbeitete schnell mit flackernd hüben erfassen den schön, aber flüchtig wirkung .
<G-vec00169-001-s341><capture.erfassen><en> """She wanted to capture the inner person, not just the exterior,"" says Kiljo."
<G-vec00169-001-s341><capture.erfassen><de> """Sie wollte den inneren Menschen, nicht nur das Äußere erfassen"", sagt Kiljo."
<G-vec00169-001-s342><capture.erfassen><en> Join Scratch and Cudgel on a harrowing adventure to find, capture, and collect the bounty on the evil Dr. Grimalkin.
<G-vec00169-001-s342><capture.erfassen><de> Registriert Scratch und Knüppel auf eine erschütternde Abenteuer zu finden, zu erfassen, zu sammeln und das Kopfgeld auf den bösen Dr. Grimalkin.
<G-vec00169-001-s343><capture.erfassen><en> On our page Colour reception you can read that our eye can percept an infinite nomber of colours. And anyway there are still numerous colour tones, which the human eye cannot capture, for instance in the infra red area. Some animal is superior to us in this point.
<G-vec00169-001-s343><capture.erfassen><de> Auf unserer Seite Farbwahrnehmung können Sie nachlesen, dass unser Auge praktisch unendlich viele Farben wahrnehmen kann; und doch gibt es zahlreiche Farbtöne, die das menschliche Auge nicht mehr erfassen kann, zum Beispiel im Infrarotbereich.
<G-vec00169-001-s344><capture.erfassen><en> Matrox Mura IPX capture cards feature DirectShow support to leverage existing applications to capture, decode and display physical and IP video sources.
<G-vec00169-001-s344><capture.erfassen><de> Matrox Mura IPX-Erfassungskarten unterstützen DirectShow, sodass vorhandene Anwendungen für das Erfassen, Decodieren und Anzeigen von physischen und IP-Videoquellen genutzt werden können.
<G-vec00169-001-s345><capture.erfassen><en> Here's a pumpkin you can't pick up at the patch.To capture the Halloween spirit,add this pumpkin charm to your necklace or bracelet and get ready for a real treat.
<G-vec00169-001-s345><capture.erfassen><de> Hier ist ein Kürbis nicht abholen können am patch.To erfassen die Halloween-Geist, fügen Sie diesen Kürbis Charme, um Ihre Halskette oder Armband und machen Sie sich bereit für einen echten Leckerbissen.
<G-vec00169-001-s346><capture.erfassen><en> The OCR Extension uses award-winning ABBYY® FineReader OCR software to capture text to add to searchable metadata fields within CONTENTdm collections.
<G-vec00169-001-s346><capture.erfassen><de> Die OCR-Erweiterung verwendet die preisgekrönte Software FineReader von ABBYY®, um OCR-Text zu erfassen und zu durchsuchbaren Metadatenfeldern in CONTENTdm-Sammlungen hinzuzufügen.
<G-vec00169-001-s347><capture.erfassen><en> You only have to drag the video link you want to capture to the main window, and the download will automatically start.
<G-vec00169-001-s347><capture.erfassen><de> Sie müssen nur den gewünschten Video-Link auf das Hauptfenster ziehen, um ihn zu erfassen und der Download startet automatisch.
<G-vec00169-001-s348><capture.erfassen><en> Make your smartphone a coding device and capture your daily activities live without any restrictions.
<G-vec00169-001-s348><capture.erfassen><de> Machen Sie Ihr Smartphone zum Kodier-Gerät und erfassen Sie live und ohne jegliche Einschränkungen Ihre täglichen Aktivitäten.
<G-vec00169-001-s349><capture.erfassen><en> Capture each activity as a task, and organize them into a solution.
<G-vec00169-001-s349><capture.erfassen><de> Erfassen Sie jede Tätigkeit als Aufgabe und organisieren Sie diese in einer Lösung.
<G-vec00169-001-s350><capture.erfassen><en> Capture physical objects with high detail accuracy using XYZPrinting's portable, cost-effective, high-resolution 3D scanner 2.0.
<G-vec00169-001-s350><capture.erfassen><de> Erfassen Sie physische Objekte mit hoher Detailgenauigkeit mit dem tragbaren, kostengünstigen und hochauflösenden 3D-Scanner 2.0 von XYZPrinting.
<G-vec00169-001-s351><capture.erfassen><en> Capture twice as much of the fluorescence signal with the 4Tune detection.
<G-vec00169-001-s351><capture.erfassen><de> Erfassen Sie doppelt so viel Fluoreszenzsignal mit dem 4Tune-Detektor.
<G-vec00169-001-s352><capture.erfassen><en> iPERL® water meters: Capture previously unmeasured low flow water, with unprecedented accuracy.
<G-vec00169-001-s352><capture.erfassen><de> iPERL® Wasserzähler: Erfassen Sie mit beispielloser Präzision zuvor nicht erfasstes Wasser bei niedrigen Durchflussraten.
<G-vec00169-001-s353><capture.erfassen><en> - Capture and crop a picture of a whiteboard or blackboard and share your meeting notes with co-workers.
<G-vec00169-001-s353><capture.erfassen><de> – Erfassen Sie ein Bild eines Whiteboards oder einer Tafel, beschneiden Sie es, und teilen Sie Ihre Besprechungsnotizen mit Arbeitskollegen.
<G-vec00169-001-s354><capture.erfassen><en> Capture facility placement details, bills of material data, loop make-up reports, work steps, and contract work information during the design process.
<G-vec00169-001-s354><capture.erfassen><de> Erfassen Sie die Details für Anlagenplatzierung, Materialdatenlisten, umfassende Schleifenberichte, Arbeitsschritte und Information zu Vertragsarbeit während des Planungsprozesses.
<G-vec00169-001-s355><capture.erfassen><en> Take a screenshot and capture the screen image...
<G-vec00169-001-s355><capture.erfassen><de> Machen Sie einen Screenshot und erfassen Sie das...
<G-vec00169-001-s356><capture.erfassen><en> – X3 Camera and Gimbal: Shoot stabilized 4K video and capture 12 megapixel images from the sky with DJI’s integrated camera and 3-axis gimbal system.
<G-vec00169-001-s356><capture.erfassen><de> - X3 Kamera und Gimbal: Nehmen Sie stabilisierte 4K-Videos auf und erfassen Sie 12 Megapixel-Bilder mit DJI’s integrierter Kamera und dem 3-Achsen Gimbalsystem.
<G-vec00169-001-s357><capture.erfassen><en> Kleptomania - Capture text from your screen using optical character recognition (OCR).
<G-vec00169-001-s357><capture.erfassen><de> Kleptomania - Erfassen Sie Text aus dem Bildschirm mit Hilfe der optischen Zeichenerkennung (OCR).
<G-vec00169-001-s358><capture.erfassen><en> However, parents can capture photos and images remotely with camera bug of the phone spy software for android.
<G-vec00169-001-s358><capture.erfassen><de> Aber Eltern können Erfassen Sie Fotos und Bilder aus der Ferne mit Kamera-Bug des Telefons Spion-Software für Android.
<G-vec00169-001-s359><capture.erfassen><en> Recordzilla - Capture video, audio, and pictures of anything you see on your computer screen and save it as video.
<G-vec00169-001-s359><capture.erfassen><de> Recordzilla - Erfassen Sie Video, Audio und Fotos von alles, was Sie auf Ihrem Bildschirm sehen, und speichern Sie sie als Video.
<G-vec00169-001-s360><capture.erfassen><en> Documentation: Capture detailed progress of individual tasks thus receiving a current overview.
<G-vec00169-001-s360><capture.erfassen><de> Dokumentation: Erfassen Sie detailliert den Fortschritt für einzelne Vorgänge und erhalten so einen aktuellen Überblick.
<G-vec00169-001-s361><capture.erfassen><en> Capture the motion of objects and scenes that slowly unfold before the human eyes.
<G-vec00169-001-s361><capture.erfassen><de> Erfassen Sie die Bewegung von Objekten und Szenen, die sich langsam vor Ihren Augen entfalten...
<G-vec00169-001-s362><capture.erfassen><en> VisioForge Video Recorder - Capture video from your screen, webcam, and IP camera.
<G-vec00169-001-s362><capture.erfassen><de> VisioForge Video Recorder - Erfassen Sie Videos von Ihrem Bildschirm, Webcam, und IP-Kamera.
<G-vec00169-001-s363><capture.erfassen><en> Capture every e-mail you received from a specific person / department with a dash.
<G-vec00169-001-s363><capture.erfassen><de> Erfassen Sie jede Mail, die Sie von einer bestimmten Person/Abteilung erhalten haben, mit einem Strich.
<G-vec00169-001-s364><capture.erfassen><en> Capture by holding down the left mouse button in the harbor by a crane loads.
<G-vec00169-001-s364><capture.erfassen><de> Erfassen Sie mit gedrückter linker Maustaste in den Hafen mit einem Kran Lasten.
<G-vec00169-001-s365><capture.erfassen><en> Capture the geometry of your items with astonishing precision.
<G-vec00169-001-s365><capture.erfassen><de> Erfassen Sie die Geometrie Ihres Objekts mit atemberaubender Präzision.
<G-vec00169-001-s366><capture.erfassen><en> Record multitrack live music, capture sound effects in surround, or document film shoots or events with multiple microphones.
<G-vec00169-001-s366><capture.erfassen><de> Nehmen Sie Livemusik mehrspurig auf, erfassen Sie Soundeffekte für Surround, oder zeichnen Sie mehrkanaligen Ton für Filmaufnahmen oder Veranstaltungen mit mehreren Mikrofonen auf.
<G-vec00169-001-s367><capture.erfassen><en> The integrated counter allows to capture the active power consumption exactly.
<G-vec00169-001-s367><capture.erfassen><de> Mit dem integrierten Wirkleistungszähler kann der Energieverbrauch (Wh/kWh) genau erfasst werden.
<G-vec00169-001-s368><capture.erfassen><en> Capture selected text from active application as a new note.
<G-vec00169-001-s368><capture.erfassen><de> Erfasst den markierten Text aus der aktiven Anwendung als neue Notiz.
<G-vec00169-001-s369><capture.erfassen><en> A total of seventeen cameras are mounted in different positions to capture the entire exterior of the vehicle.
<G-vec00169-001-s369><capture.erfassen><de> Insgesamt siebzehn Kameras sind an verschiedenen Positionen angebracht, so dass die gesamte Außenfläche eines Fahrzeuges erfasst werden kann.
<G-vec00169-001-s370><capture.erfassen><en> An optional barcode scanning unit can capture and verify all printed data, in line - enabling continuous post-production verification, quality control and traceability.
<G-vec00169-001-s370><capture.erfassen><de> Mittels einer optionalen Scannereinheit können die im Barcode gedruckten Daten zusätzlich erfasst werden, um spätere Rückverfolgbarkeitslösungen zu gewährleisten.
<G-vec00169-001-s371><capture.erfassen><en> Its VGA and HDMI input can capture video from many popular non-standard and standard definition sources.
<G-vec00169-001-s371><capture.erfassen><de> Der VGA-Eingang erfasst Videos aus vielen handelsüblichen standardisierten und standardisierten Definitionsquellen.
<G-vec00169-001-s372><capture.erfassen><en> Using the HandySCAN 3D technology to capture the shape of a baby’s head will provide clinicians with a simple, easy to use, fast and accurate 3D modeling solution.
<G-vec00169-001-s372><capture.erfassen><de> Mit der HandySCAN 3D Technologie kann der Schädel des Säuglings erfasst werden, und dem Mediziner steht damit eine einfache, benutzerfreundliche, schnelle und genaue 3D-Modell-Lösung zur Verfügung.
<G-vec00169-001-s373><capture.erfassen><en> They are equipped with instruments that measure and capture the loads and forces that act on various body parts and the type and severity of sustained injuries.
<G-vec00169-001-s373><capture.erfassen><de> Sie verfügen über eine Instru-mentierung, die Belastungen und Krafteinwirkungen auf einzelne Körperteile sowie Art und Ausmaß von Verletzungen erfasst.
<G-vec00169-001-s374><capture.erfassen><en> This will also help capture the object better.
<G-vec00169-001-s374><capture.erfassen><de> Auch das wird dazu beitragen, dass das Objekt besser erfasst werden kann.
<G-vec00169-001-s375><capture.erfassen><en> The IBM presentations detailed the innovative opportunities for the private and public organizations - how to grow new revenue streams, capture customers and gain progress towards an extended API ecosystem.
<G-vec00169-001-s375><capture.erfassen><de> Die IBM-Präsentationen setzten die innovativen Chancen für private und öffentliche Organisationen im Vordergrund – wie werden neue Umsatzströme generiert, Kunden erfasst und Fortschritte in Richtung eines erweiterten API-Ökosystems gemacht.
<G-vec00169-001-s376><capture.erfassen><en> No one liked the internal software to capture the material bills, so some people used them and some did not - and those who did it often made serious mistakes.
<G-vec00169-001-s376><capture.erfassen><de> Niemand mochte die interne Software, mit der die Materialrechnungen erfasst werden sollten, sodass manche Leute sie benutzten und manche nicht – und diejenigen, die es taten, machten oft schwere Fehler.
<G-vec00169-001-s377><capture.erfassen><en> By using mainly competitive sectors as comparator sectors, the productivity index primarily approximates technological progress (and does not capture catch-up effects due to the elimination of inefficiencies).
<G-vec00169-001-s377><capture.erfassen><de> "Durch die Verwendung wettbewerblicher Vergleichssektoren wird im Wesentlichen der technologische Fortschritt erfasst (jedoch nicht das Aufholen von Ineffizienzen, das so genannte „catch-up"")."
<G-vec00169-001-s378><capture.erfassen><en> Capture images at the highest Camera Link rates with support for the Full and 80-bit modes at up to 85MHz (single-Full model).
<G-vec00169-001-s378><capture.erfassen><de> Erfasst Bilder der höchsten Camera Link Bildraten mit Support des Full/80-bit Modus bei bis zu 85 MHz.
<G-vec00169-001-s379><capture.erfassen><en> These high-resolution scanners are able to capture even the smallest details, down to folds on clothes.
<G-vec00169-001-s379><capture.erfassen><de> Dank Hochleistungsscans und Präzisionsdruck können selbst die kleinsten Details wie Kleiderfalten erfasst werden.
<G-vec00169-001-s380><capture.erfassen><en> Capture and retrieve snapshots and obtain system information of remote computers.
<G-vec00169-001-s380><capture.erfassen><de> Momentaufnahmen und Systeminformationen von ferngesteuerten Computern können ebenfalls erfasst und abgerufen werden.
<G-vec00169-001-s381><capture.erfassen><en> It is usually not possible to capture all measuring points of a cycle; however, it has no effect on the calculation of the area if one or two measuring points are substituted by a straight line.
<G-vec00169-001-s381><capture.erfassen><de> Es ist in der Regel nicht zu erreichen, dass alle Messpunkte eines Umlaufs erfasst werden; es ist aber auch für die Berechnung der Fläche unerheblich, wenn ein oder zwei Punkte durch eine Gerade substituiert werden.
<G-vec00169-001-s382><capture.erfassen><en> Then he takes his camera at the heart of the event, into the ceremonies, the reception, to capture the vivid soul of this day while being very discreet.
<G-vec00169-001-s382><capture.erfassen><de> Im Mittelpunkt der Veranstaltung, während der Zeremonien, auf dem Empfang, überall erfasst der Videoraf das Leben der Orte und des Tages, all dies sehr diskret.
<G-vec00169-001-s383><capture.erfassen><en> But calculating access in this way does not capture everyone – the quality or number of hours of electricity available, or the number of people who can afford to have their homes connected are not taken into account.
<G-vec00169-001-s383><capture.erfassen><de> Diese Form der Berechnung erfasst indes nicht alle Aspekte: Unberücksichtigt bleiben die Qualität und Dauer der Stromversorgung und die Zahl derjenigen, die sich einen privaten Stromanschluss leisten können.
<G-vec00169-001-s384><capture.erfassen><en> A note on privacy: Of course, the guidance system does not capture data of individual network devices but solely the total number of all devices at respective locations.
<G-vec00169-001-s384><capture.erfassen><de> Hinweis zum Datenschutz: Selbstverständlich erfasst seatfinder nicht die Daten einzelner netzwerkfähiger Geräte, sondern ausschließlich die Gesamtzahl aller Geräte am jeweiligen Standort.
<G-vec00169-001-s385><capture.erfassen><en> When using Follow Me function, the aircraft's camera will lock on your mobile phone,Â tracking you automatically and capture your movement with a particular aerial view.
<G-vec00169-001-s385><capture.erfassen><de> "Wenn Sie die ""Follow Me"" -Funktion verwenden, wird die Kamera des Flugzeugs auf Ihrem Mobiltelefon gespeichert, so dass Sie automatisch verfolgt werden und Ihre Bewegung mit einer bestimmten Luftaufnahme erfasst wird."
<G-vec00169-001-s420><capture.erobern><en> The target is to capture the market with a simple and low priced limit switch box in mass production.
<G-vec00169-001-s420><capture.erobern><de> Das Ziel ist, den Markt, mit einer einfachen und günstigen Box in Massenfertigung, zu erobern.
<G-vec00169-001-s421><capture.erobern><en> 1759 - Seven Years' War: The British capture Quebec City .
<G-vec00169-001-s421><capture.erobern><de> 1759: Im Franzosen- und Indianerkrieg erobern die Briten Québec .
<G-vec00169-001-s422><capture.erobern><en> Your task is to capture Pokemon in the wild, train and upgrade them.
<G-vec00169-001-s422><capture.erobern><de> Deine Aufgabe ist es, Pokemon im wilden Zug zu erobern und zu verbessern.
<G-vec00169-001-s423><capture.erobern><en> It is nothing new, as duality allows for either one to capture your minds and souls.
<G-vec00169-001-s423><capture.erobern><de> Das ist nichts Neues, denn die Dualität gestattet beiden Seiten, eure Sinne und eure Seelen zu erobern.
<G-vec00169-001-s424><capture.erobern><en> a) Starting out from the fact of the partial stabilization of capitalism, the Party considers that we are in an interrevolutionary period, that in capitalist countries we are proceeding towards revolution, and that the fundamental task of the Communist Parties is to lay down a road to the masses, to strengthen the ties with the masses, to capture the mass organizations of the proletariat and to prepare the broad masses of the workers for the forthcoming revolutionary battles.
<G-vec00169-001-s424><capture.erobern><de> a) Ausgehend von der Tatsache der teilweisen Stabilisierung des Kapitalismus, ist die Partei der Auffassung, dass wir in einer Periode zwischen zwei Revolutionen leben, dass wir in den kapitalistischen Ländern der Revolution entgegengehen und dass die Hauptaufgabe der kommunistischen Parteien darin besteht, sich den Weg zu den Massen zu bahnen, die Verbindungen mit den Massen zu festigen, die Massenorganisationen des Proletariats zu erobern und die breiten Massen der Arbeiter für die kommenden revolutionären Kämpfe vorzubereiten.
<G-vec00169-001-s425><capture.erobern><en> The proletarian class struggle is the weapon by means of which the proletariat will capture political power and then expropriate the bourgeoisie in order to establish socialism.
<G-vec00169-001-s425><capture.erobern><de> Der Klassenkampf des Proletariats ist die Waffe, mit deren Hilfe es die politische Macht erobern wird, um dann die Bourgeoisie zu expropriieren und den Sozialismus zu errichten.
<G-vec00169-001-s426><capture.erobern><en> They have only become native to the Western world in recent years where they continue to capture more and more hearts and souls in the rural arena.
<G-vec00169-001-s426><capture.erobern><de> In der westlichen Welt sind sie erst seit wenigen Jahren heimisch geworden und erobern mehr und mehr die Herzen und Weiden im ländlichen Raum.
<G-vec00169-001-s427><capture.erobern><en> In this interview, he talks about his start at SCHLENK, his plans and how he will capture new markets.
<G-vec00169-001-s427><capture.erobern><de> Im Interview erzählt er von seinem Einstieg bei SCHLENK, seinen Plänen und wie er neue Märkte erobern will.
<G-vec00169-001-s428><capture.erobern><en> The teams will fight over control of a strategic region of the wilderness by trying to capture different locations and holding them.
<G-vec00169-001-s428><capture.erobern><de> Die Teams kämpfen um die Kontrolle über einen strategisch wichtigen Abschnitt der Wildnis, indem sie versuchen, verschiedene Punkte zu erobern und zu halten.
<G-vec00169-001-s429><capture.erobern><en> With its excellent ecological and physical qualities, the new biocomposite FluidSolids® developed in Switzerland has the potential to capture the market in the near future as an alternative material for myriads of products made of metal, wood, and especially plastic.
<G-vec00169-001-s429><capture.erobern><de> Mit seinen hervorragenden ökologischen und physikalischen Eigenschaften hat das in der Schweiz entwickelte neue Biokomposit FluidSolids® das Potenzial, in naher Zukunft den Markt als Alternativmaterial für eine Vielzahl von Produkten aus Metall, Holz und insbesondere Kunststoff zu erobern.
<G-vec00169-001-s430><capture.erobern><en> The object of mancala games is usually to capture more seeds than the opponent.
<G-vec00169-001-s430><capture.erobern><de> Die Aufgabe der Mancala-Spiele ist in der Regel zu mehr Samen als der Gegner zu erobern.
<G-vec00169-001-s431><capture.erobern><en> And the heart and mind of society is the target market that the gay rights campaign means to capture in order to win the courts.
<G-vec00169-001-s431><capture.erobern><de> Folglich sind Herz und Kopf einer Gesellschaft der Zielmarkt, den die Gay-Rights-Bewegung erobern will, um dann die Gerichte für sich zu gewinnen.
<G-vec00169-001-s432><capture.erobern><en> Such a move can help the firms ride the innovation wave and capture the market before many of their competitors.
<G-vec00169-001-s432><capture.erobern><de> Ein solcher Schritt die Unternehmen, die Innovationswelle und erobern den Markt vor vielen ihrer Konkurrenten reiten kann helfen.
<G-vec00169-001-s433><capture.erobern><en> Regarding to nine years of great success with professional monitors, ADAM strikes out in a new direction: They want to capture the market of Hi-Fi speakers.
<G-vec00169-001-s433><capture.erobern><de> Aufgrund des großen Erfolgs der Studiomonitore in den letzten neun Jahren, geht ADAM nun neue Wege: sie wollen den Markt der Hi-Fi Lautsprecher erobern.
<G-vec00169-001-s434><capture.erobern><en> Whoever wants to understand this prophetic parable of Jesus, which concerns His own death, must imagine how the Wolf, in the crucial hour, hurried closer to kill the Shepherd and to capture the flock of Christ.
<G-vec00169-001-s434><capture.erobern><de> Wer diese gleichnishafte Prophezeiung Jesu auf seinen eigenen Tod verstehen will, kann sich vorstellen, wie der Wolf in der entscheidenden Stunde heranhetzte, um den Hirten zu töten und die Herde Christi zu erobern.
<G-vec00169-001-s435><capture.erobern><en> On the contrary, who packs its child in cotton wool and does not leave no more from the eyes, it prevents a piece far to capture the world.
<G-vec00169-001-s435><capture.erobern><de> Im Gegenteil, wer sein Kind in Watte packt und nicht mehr aus den Augen lässt, hindert es ein Stück weit daran, sich die Welt selbst zu erobern.
<G-vec00169-001-s436><capture.erobern><en> The result is that inside the ruling apparatus faction, antagonistic factions arise that do not strive so much to capture the majority within the common faction as to seek for support in the institutions of the state apparatus.
<G-vec00169-001-s436><capture.erobern><de> Die Folge ist, dass innerhalb der herrschenden Apparatfraktion eigene feindliche Fraktionen entstehen, die nicht so sehr danach streben, die Mehrheit innerhalb der Gesamtfraktion zu erobern, als die Unterstützung der Einrichtungen des Staatsapparates zu erhalten.
<G-vec00169-001-s437><capture.erobern><en> It is known that during the invasion orcs have not managed to capture the dryad forests.
<G-vec00169-001-s437><capture.erobern><de> Es ist kein Geheimnis, dass die orkischen Truppen während der Invasion die Wälder von Dryaden nicht erobern konnten.
<G-vec00169-001-s438><capture.erobern><en> In Season Match 2 Prince January decides to capture the Fairytale Kingdom of nature the beauty.
<G-vec00169-001-s438><capture.erobern><de> In Season Match 2 beschließt Prinz Januar, das Märchenreich der schönen Natur zu erobern.
<G-vec00169-001-s477><capture.fangen><en> To capture, and then control a pegasuses, one needs a bridle made from leather curried in a special way that only the sages knew.
<G-vec00169-001-s477><capture.fangen><de> Um Pegasus-Pferde zu fangen und zu lenken, wird ein Zaum aus Leder benötigt, der von den Druiden auf eine besondere Art und Weise gegerbt werden muss.
<G-vec00169-001-s478><capture.fangen><en> Dia 4: White could decide to capture one stone...
<G-vec00169-001-s478><capture.fangen><de> Dia 4: Weiß könnte sich entscheiden, einen Stein zu fangen...
<G-vec00169-001-s479><capture.fangen><en> Imagining a thief intrudes your home or breaks your car at night, you will be able to capture all the actions.
<G-vec00169-001-s479><capture.fangen><de> Die Vorstellung eines Diebes dringt dein Zuhause ein oder bricht dein Auto nachts, du wirst alle Aktionen fangen können.
<G-vec00169-001-s480><capture.fangen><en> In the same way, if we have any discernment, we can capture and tame the demons of defilement so that they support us in being outstanding, all the way to the paths (magga) and fruitions (phala) leading to nibbana.
<G-vec00169-001-s480><capture.fangen><de> In selber Weise können wir, wenn wir etwas Einsicht haben, die Dämonen der Veruntrübung fangen und zügeln, sodass diese uns darin unterstützen, außergewöhnlich zu sein, den ganzen Weg zu den Pfaden (magga) und Früchten (phala) hinunter, die zu Nibbana führen.
<G-vec00169-001-s481><capture.fangen><en> From backpacks to duffels, slings to messenger bags, these utilitarian designs capture the freedom of movement between work, travel, and the great outdoors.
<G-vec00169-001-s481><capture.fangen><de> Von Rucksäcken über Reisetaschen und Schultertaschen bis hin zu Messengern - diese nützlichen Designs fangen die Bewegungsfreiheit zwischen Arbeit, Reisen und der freien Natur ein.
<G-vec00169-001-s482><capture.fangen><en> One of the quadrifid processes; much enlarged. It seemed to me an interesting question whether the minute bladders of Utricularia montana served, as in the previous species, to capture animals living in the earth, or in the dense vegetation covering the trees on which this species is epiphytic; for in this case we should have a new sub-class of carnivorous plants, namely, subterranean feeders.
<G-vec00169-001-s482><capture.fangen><de> Es schien mir eine interessante Frage zu sein, ob die kleinen Blasen der Utricularia montana wie in den vorhergehenden Arten dazu dienten, Thiere zu fangen, welche in der Erde oder in der dich- ten, die Bäume, auf denen diese Art epiphytisch wächst, bedeckenden Vegetation leben; denn in diesem Falle würden wir eine neue Unter- classe von fleischfressenden Pflanzen haben, nämlich solche, die sich unterirdisch ernähren.
<G-vec00169-001-s483><capture.fangen><en> The brickwork has been beautifully restored and double glazed windows with discreet aluminium frames that jut out slightly from the walls capture daylight.
<G-vec00169-001-s483><capture.fangen><de> Die Mauerarbeiten wurden wieder hergestellt, und doppelt verglaste Fenster mit dezenten Aluminium-Rahmen, die nur leicht aus den Wänden herausragen, fangen das Tageslicht ein.
<G-vec00169-001-s484><capture.fangen><en> The latest game craze, Pokémon GO, is a free-to-play, location-based augmented reality game where players use a mobile device to locate, capture, battle, and train virtual creatures, called Pokémon, who appear on the screen as if they were in the same real-world location as the player.
<G-vec00169-001-s484><capture.fangen><de> Die neueste Spielart, Pokémon GO ist ein frei spielbares, standortbasiertes augmented reality-Spiel nutzen, um virtuelle Kreaturen, geannt Pokémon, die auf dem Bildschirm erscheinen, als wären sie in der gleichen realen Welt wie die Spielenden, zu lokalisiweren, fangen, bekämpfen und trainieren.
<G-vec00169-001-s485><capture.fangen><en> On Earth or in space: telescopes capture light that has been on the move for billions of years.
<G-vec00169-001-s485><capture.fangen><de> Auf der Erde oder im Weltraum: Teleskope fangen Licht ein, das seit Milliarden von Jahren unterwegs ist.
<G-vec00169-001-s486><capture.fangen><en> The herbal formulas capture the essence of different traditions .
<G-vec00169-001-s486><capture.fangen><de> Die Kräuterformeln fangen die Essenz verschiedener Traditionen ein.
<G-vec00169-001-s487><capture.fangen><en> We will conjure and capture new shadows from the exhibition, using flashlights, paper and pens and a tricky Tangram.
<G-vec00169-001-s487><capture.fangen><de> Mit Taschenlampen, Papier und Stiften und einem kniffeligen Tangram zaubern wir neue Schatten und fangen die Schatten der Ausstellung ein.
<G-vec00169-001-s488><capture.fangen><en> Therefore, since your Flat wager and Odds wager capture the same amount (5 dollars each), you bridge your six dollars Odds wager by putting a 5 dollar chip literally beside to your five dollar Flat wager, and then placing the $1 chip so it bridges the 2 five dollar chips.
<G-vec00169-001-s488><capture.fangen><de> Deshalb, da Ihre Wohnung Wette und Quoten wetten, fangen die gleiche Menge (5 Dollar pro Stück), Brücke Sie Ihre sechs Dollar Quoten wetten, indem Sie einen 5-Dollar-Chip buchstäblich neben Ihrem Fünf-Dollar-Flat Wette, und das Setzen der $ 1 Jeton so Brücken die 2 Fünf-Dollar-Chips.
<G-vec00169-001-s489><capture.fangen><en> Marquard's photographs capture the singular essence of these individuals and at the same time transform them into icons of our time transcending the individual.
<G-vec00169-001-s489><capture.fangen><de> Marquardts Fotografien fangen die Unverwechselbarkeit dieser Individuen ein und verwandeln sie gleichzeitig zu Ikonen unserer Zeit, die über das Individuelle hinauswachsen.
<G-vec00169-001-s490><capture.fangen><en> No other plug-ins so faithfully capture the sound and behavior of classic analog equipment — from rare compressors and equalizers, to vintage reverb processors and tape machines.
<G-vec00169-001-s490><capture.fangen><de> Nur die Plug-Ins von UA fangen den Klang und das Verhalten klassischer analoger Geräte so originalgetreu ein - von seltenen Kompressoren und Equalizern bis hin zu legendären Hall-Prozessoren und Bandmaschinen.
<G-vec00169-001-s491><capture.fangen><en> The cotton jacquard dish towel has good ability to capture dust, grease and spills; it is eco-friendly and machine washable.
<G-vec00169-001-s491><capture.fangen><de> Das Baumwoll-Jacquard-Geschirrtuch hat eine gute Fähigkeit, Staub, Fett und Flüssigkeiten zu fangen; es ist umweltfreundlich und maschinenwaschbar.
<G-vec00169-001-s492><capture.fangen><en> B 105: Black cannot capture two White stones with a move at 108, because this would cost him one of his liberties.
<G-vec00169-001-s492><capture.fangen><de> S 105: Schwarz darf die beiden weißen Steine nicht mit 108 fangen, denn das würde ihn eine seiner Freiheiten kosten.
<G-vec00169-001-s493><capture.fangen><en> Patented water washing system: to capture most bacteria, dust and particles by water spraying like a rainfall.
<G-vec00169-001-s493><capture.fangen><de> Patentiertes Wasserwaschsystem: um die meisten Bakterien, Staub und Partikel durch Wasserspritzen wie ein Niederschlag zu fangen.
<G-vec00169-001-s494><capture.fangen><en> 3) Bruno... Generally speaking I am not a great fan of live albums; very few capture the moment and the thrill of the shared experience at the performance itself.
<G-vec00169-001-s494><capture.fangen><de> 3) Bruno… Generell gesprochen bin ich kein großer Fan von Livealben; sehr wenige fangen den Moment und die Aufregung der geteilten Erfahrung bei der Vorstellung selber ein.
<G-vec00169-001-s495><capture.fangen><en> The documentary and the CD capture the story of the legendary singer/songwriter Blaze Foley.
<G-vec00169-001-s495><capture.fangen><de> Der Dokumentarfilm und die CD fangen die Geschichte des legendären Singer/Songwriters Blaze Foley ein.
<G-vec00169-001-s496><capture.fassen><en> Life in the concentration camp; the death of women close to one; the worries about children, men, friends and relatives; the longing for home - all were reasons to capture pain, sorrow and longing in rhymed words.
<G-vec00169-001-s496><capture.fassen><de> Das Leben im KZ, der Tod nahestehender Frauen, die Sorge um Kinder, Männer, Freunde und Verwandte, die Sehnsucht nach der Heimat waren die Anlässe, Schmerz, Kummer und Sehnsucht in gereimte Worte zu fassen.
<G-vec00169-001-s497><capture.fassen><en> Thinking and concepts can impossibly capture this mystery.
<G-vec00169-001-s497><capture.fassen><de> Konzepte und Denken können dieses Mysterium unmöglich fassen.
<G-vec00169-001-s498><capture.fassen><en> Although it was not until nearly a century later that photography’s first pioneers roamed the alleys of Venice or attempted to capture the flair of Paris, these contemporary documents give an impression of the wonders that the great seducer encountered on his Grand Tour.
<G-vec00169-001-s498><capture.fassen><de> Obschon die Pioniere der Fotografie erst ein knappes Jahrhundert nach ihm durch Venedigs Gassen streiften oder das Pariser Flair zu fassen suchten, vermitteln diese Zeitdokumente doch einen Eindruck davon, welche Wunder dem begnadeten Verführer auf seiner Grand Tour begegneten.
<G-vec00169-001-s499><capture.fassen><en> He painted farmers at their work and visionary landscapes, which capture a stunning impression of the Alpine landscape.
<G-vec00169-001-s499><capture.fassen><de> Er malte Bauern bei der Arbeit und visionäre Landschaften, die den überwältigenden Eindruck der Alpenlandschaft fassen.
<G-vec00169-001-s500><capture.fassen><en> Collected emotions and thoughts that some would seek to capture in words have inspired the leader of the band, Cédric Gschwind, to write the pieces.
<G-vec00169-001-s500><capture.fassen><de> Gesammelte Emotionen und Gedanken, welche andere in Worte fassen, inspirierten den Bandleader Cédric Gschwind zu diesen Stücken.
<G-vec00169-001-s501><capture.fassen><en> We first have a picture in our heads – of a person dear to us, our last holiday, a new acquaintance – and only then, if it is required, do we strive to capture the picture we see in our minds in the medium of words and sentences.
<G-vec00169-001-s501><capture.fassen><de> Man hat zuerst ein Bild im Kopf – einen lieben Menschen, den letzten Urlaub, einen neuen Bekannten – und erst dann, so erforderlich, bemüht man sich das geistig geschaute Bild in Worte und Sätze zu fassen.
<G-vec00169-001-s502><capture.fassen><en> Fantin-Latour is also deeply impressed by the opening of «Rhinegold,» where the figures slowly emerge from the darkness, which he also tries to capture as an image.
<G-vec00169-001-s502><capture.fassen><de> Zutiefs beeindruckt ist Fantin-Latour auch von dem Beginn des »Rheingolds,« bei dem die Figuren sich langsam aus dem Dunkel lösen, was er ebenfalls in ein Bild zu fassen versucht.
<G-vec00169-001-s503><capture.fassen><en> I assume, as an artist, that I can neither lend someone a voice who previously lacked a voice nor capture something in a video as it really is.
<G-vec00169-001-s503><capture.fassen><de> Ich vermute, dass ich als Künstlerin weder einer Person die Stimme geben kann, die ihr fehlt, noch dass ich eine Sache in einem Video so fassen kann, wie sie wirklich ist.
<G-vec00169-001-s504><capture.fassen><en> Can Photography Capture our Age in Images?<br...
<G-vec00169-001-s504><capture.fassen><de> Kann Fotografie unsere Zeit in Bilder fassen?...
<G-vec00169-001-s505><capture.fassen><en> Director: Dr. Gabriele KastenmÃ1⁄4ller (acting)E-mail The Institute of Bioinformatics and Systems Biology (IBIS) analyses and interprets biological data in order to capture information on the etiology and progression of human diseases in rational models.
<G-vec00169-001-s505><capture.fassen><de> Direktor: Dr. Gabriele Kastenmüller (kommissarisch)E-Mail Das Institut für Bioinformatik und Systembiologie (IBIS) analysiert und interpretiert biologische Daten um Informationen zur Entstehung und dem Verlauf menschlicher Erkrankungen in rationale Modelle zu fassen.
<G-vec00169-001-s506><capture.fassen><en> 4.0.0 Skadge A career gangster and psychopath, Skadge had been enjoying a prestigious position at the top of Coruscant's most wanted list when a joint police, military and SIS task force managed to finally capture him.
<G-vec00169-001-s506><capture.fassen><de> 4.0.0 Skadge Skadge ist ein professioneller Verbrecher und Psychopath und hatte einen angesehenen Platz an der Spitze von Coruscants Liste der meistgesuchten Verbrecher, bis ihn eine Einsatztruppe aus Polizei, Militär und SID endlich fassen konnte.
<G-vec00169-001-s507><capture.fassen><en> Gunda Gruber attempts to capture in images the daily madness of traffic to which we are all exposed.
<G-vec00169-001-s507><capture.fassen><de> Gunda Gruber versucht, den alltäglichen Wahnsinn des Straßenverkehrs, dem wir alle ausgesetzt sind, in Bilder zu fassen.
<G-vec00169-001-s508><capture.fassen><en> At the beginning of “The Catastrophist” there was a piece of work that had been commissioned by the city of Chicago: bands and artists were asked to capture their relation with Chicago with the means of sound, in words or images – maybe this is due to my fairly naïve understanding of art, but I have always been rather sceptical of commissioned pieces of art.
<G-vec00169-001-s508><capture.fassen><de> Am Anfang von „The Catastrophist“ stand eine Auftragsarbeit der Stadt Chicago: Bands und Künstler sollten ihre Beziehung zu Chicago in Töne, Worte, Bilder fassen – vielleicht liegt es an meinem naiven Kunstverständnis, aber Auftragsarbeiten haben für mich immer einen faden Beigeschmack.
<G-vec00169-001-s509><capture.fassen><en> However, they are difficult to capture with conventional digital text analyses.
<G-vec00169-001-s509><capture.fassen><de> Sie sind jedoch mit konventionellen digitalen Textanalysen schwer zu fassen.
<G-vec00169-001-s510><capture.fassen><en> We should have made a greater effort to capture bin Laden, since the al Qaida is the terrorist threat number one.
<G-vec00169-001-s510><capture.fassen><de> Wir hätten uns mehr anstrengen sollen, um Bin Laden zu fassen, denn Al Qaida ist die terroristische Bedrohung Nummer eins.
<G-vec00169-001-s511><capture.fassen><en> It also stands in challenging contrast to the new media art forms that the younger artists use to capture in pictures such shocking events and processes as war and the decay of industrial infrastructure.
<G-vec00169-001-s511><capture.fassen><de> Es steht auch in einem herausfordernden Kontrast zu den neuen medialen Kunstformen, die von den jüngeren Künstlern angewandt werden, um schockierende Ereignisse und Prozesse, wie Krieg und Verfall der industriellen Infrastruktur, in Bilder zu fassen.
<G-vec00169-001-s512><capture.festhalten><en> With our popular Freud PEN you can capture your ideas, notes, experiences or dreams forever.
<G-vec00169-001-s512><capture.festhalten><de> So kannst du deine Ideen, Notizen, Erlebnisse oder Träume mit unserem beliebten Freud-STIFT für immer festhalten.
<G-vec00169-001-s513><capture.festhalten><en> Vasco da Gama is high-resolution animation software that allows you to capture and follow your unique travel experiences in detail.
<G-vec00169-001-s513><capture.festhalten><de> Denn bei Vasco da Gama handelt es sich um eine hochauflösende Animationssoftware, mit der Sie Ihre einzigartigen Reiseerlebnisse detailgetreu festhalten und nachzeichnen können.
<G-vec00169-001-s514><capture.festhalten><en> We decided to film it, because we had our stage set like when we toured in Europe and we wanted to capture it.
<G-vec00169-001-s514><capture.festhalten><de> Wir entschlossen uns, diesen Gig zu filmen, da der Bühnenaufbau dort genauso war, wie wir es schon auf der Europatour hatten, und das wollten wir festhalten.
<G-vec00169-001-s515><capture.festhalten><en> Photography is in fashion here and everybody wants to capture a special moment, a meeting, a wedding, a farewell,...
<G-vec00169-001-s515><capture.festhalten><de> Fotografie ist in Mode hier und jeder möchte einen besonderen Moment festhalten, ein Treffen, eine Hochzeit, ein Abschied,...
<G-vec00169-001-s516><capture.festhalten><en> You want to capture transparently all the information incurred during the sales process in one sales operation.
<G-vec00169-001-s516><capture.festhalten><de> Sie möchten alle während des Vertriebsprozesses anfallenden Informationen transparent in einem Vertriebsvorgang festhalten.
<G-vec00169-001-s517><capture.festhalten><en> A perfume is not dissimilar to a photograph - they both capture the essence of a special moment or mood, and keep the memory of it alive.
<G-vec00169-001-s517><capture.festhalten><de> Besonderheiten Ein Parfum ist einem Bild nicht unähnlich - können sie doch beide einen besonderen Moment oder eine Stimmung festhalten und so die Erinnerung daran lebendig halten.
<G-vec00169-001-s518><capture.festhalten><en> Images seemingly photographic, and sequences like those in an episodic film: Angelika Reitzer’s gaze is photo- and cinematographic; it strives respectively to capture and pursue something.
<G-vec00169-001-s518><capture.festhalten><de> Bilder, die fotografisch wirken, und Sequenzen wie aus Episodenfilmen: Angelika Reitzers Blick ist foto- und kinematografisch; einer, der etwas festhalten respektive etwas folgen will.
<G-vec00169-001-s519><capture.festhalten><en> With this collection, you can capture beloved memories in your scrapbook album or make your own romantic Valentine cards.
<G-vec00169-001-s519><capture.festhalten><de> Mit dieser Kollektion können Sie geliebte Erinnerungen in Ihrem Scrapbook-Album festhalten oder eigene romantische Valentinskarten basteln.
<G-vec00169-001-s520><capture.festhalten><en> We are familiar with photos of life in the townships by outstanding pioneers like David Goldblatt or Santu Mofokeng and many younger African artists who capture eye-catching, snapshot-like scenes of life in the streets and townships.
<G-vec00169-001-s520><capture.festhalten><de> Wir kennen die Fotos vom Leben in den Townships von herausragenden Foto-Pionieren wie David Goldblatt oder Santu Mofokeng und viele jÃ1⁄4ngere Positionen des Kontinents, die auffällige, schnappschussähnliche Szenen des Lebens in den Straßen und Armenvierteln festhalten.
<G-vec00169-001-s521><capture.festhalten><en> Photography has the quality of being able to capture moments.
<G-vec00169-001-s521><capture.festhalten><de> Fotografie hat die Eigenschaft, Momente festhalten zu können.
<G-vec00169-001-s522><capture.festhalten><en> As an IT support team, you may want to capture meaningful data about your users, their locations, and their devices and create workflows based on this information.
<G-vec00169-001-s522><capture.festhalten><de> Benutzerfelder Als IT-Supportteam müssen Sie möglicherweise sinnvolle Daten über Ihre Benutzer, deren Standorte und deren Geräte festhalten und auf Grundlage dieser Informationen Workflows erstellen.
<G-vec00169-001-s523><capture.festhalten><en> The water is pushed away from the camera lens so that you can capture what is under and over the water line.
<G-vec00169-001-s523><capture.festhalten><de> Das Wasser wird vom Objektiv der Kamera weggedrückt, so dass Sie das, was sich unter und über der Wasserlinie befindet, festhalten können.
<G-vec00169-001-s524><capture.festhalten><en> Like an expert witness testifying to the presence of a tree falling in a lonely forest, the selfie more or less establishes that beyond the cosmetic manipulations that transform the self into the selfie, is the real you, in real time, in real space, doing some real things that are so engrossing, exciting, fun and absorbing, that you had to capture the moment and then delay experiencing it just a little bit while you upload it to your social network of choice.
<G-vec00169-001-s524><capture.festhalten><de> Wie ein Experten-Augenzeuge, der dabei ist, wenn ein Baum in einem einsamen Wald umfällt, etabliert das Selfie mehr oder weniger, dass jenseits kosmetischer Manipulationen, die das Selbst in ein Selfie transformieren, es das reale Du ist, in Echtzeit, das reale Dinge tut, die uns so gefangen nehmen, so aufregend sind, so viel Spaß bereiten und absorbieren, dass du diesen Augenblick einfach festhalten musstest, nur um sein Erleben ein klein wenig aufzuschieben, während du ihn in ein soziales Netzwerk deiner Wahl hochlädst.
<G-vec00169-001-s525><capture.festhalten><en> The great pictures shot by photographer Julie Cate show impressively how beautiful and heartwarming it can be not only to relish these valuable moments but also to capture them on camera.
<G-vec00169-001-s525><capture.festhalten><de> Wie wunderschön und herzerwärmend es sein kann, diese kostbaren Momente nicht nur zu genießen, sondern auch festhalten zu lassen, zeigen uns die großartigen Aufnahmen von Fotografin Julie Cate.
<G-vec00169-001-s526><capture.festhalten><en> Enjoy new and smart ways to capture your ideas naturally and easily: Bamboo Ink lets you keep your head free for your thoughts and building fresh ideas.
<G-vec00169-001-s526><capture.festhalten><de> Ideen auf eine neue, smarte Art festhalten – ganz einfach und natürlich: Mit dem Bamboo Ink hast du den Kopf frei für deine Gedanken und neue Ideen.
<G-vec00169-001-s527><capture.festhalten><en> The second section is devoted exclusively to contemporary art. Andreas Gursky’s large-format photographic work Kamiokande (2007) demonstrates that scientific research facilities have their own aesthetic fascination. In the water-filled mine of a former colliery, a neutrino observatory was installed in which thousands of “photo eyes” capture the movement of these elementary particles.
<G-vec00169-001-s527><capture.festhalten><de> "Hier demonstriert Andreas Gursky großformatige Fotoarbeit Kamiokande (2007), dass wissenschaftliche Forschungsanlagen ihre ganz eigene ästhetische Faszination besitzen: In der mit Wasser gefüllten Mine eines ehemaligen Bergwerks wurde ein Neutrino-Observatorium installiert, in dem Tausende von ""Photo-Augen"" die Bewegung dieser Elementarteilchen festhalten."
<G-vec00169-001-s528><capture.festhalten><en> With the help of the trust, which he and his work got from the people, he was able to capture their personal stories and fates and give the modernization and consequences of development a human face.
<G-vec00169-001-s528><capture.festhalten><de> Durch das Vertrauen, das die Menschen dem Fotografen und seiner Arbeit entgegenbrachten, konnte er ihre Geschichten und Schicksale festhalten und so ein neues sehr persönliches Licht auf den Modernisierungsprozess und seine Folgen werfen.
<G-vec00169-001-s529><capture.festhalten><en> 2 Entering data in your Acer n35 Recording a message 26 Recording a message In any program where you can write or draw on the screen, you can also quickly capture thoughts, reminders, and phone numbers by recording a message.
<G-vec00169-001-s529><capture.festhalten><de> Aufnehmen einer Nachricht In allen Programmen, die Ihnen das Schreiben oder Zeichnen auf dem Bildschirm ermöglichen, können Sie Gedanken, GedächtnisstÃ1⁄4tzen und Telefonnummern durch Aufnehmen einer Nachricht schnell festhalten.
<G-vec00169-001-s530><capture.festhalten><en> No comment Photography is in fashion here and everybody wants to capture a special moment, a meeting, a wedding, a farewell,...
<G-vec00169-001-s530><capture.festhalten><de> Kein Kommentar Fotografie ist in Mode hier und jeder möchte einen besonderen Moment festhalten, ein Treffen, eine Hochzeit, ein Abschied,...
<G-vec00169-001-s531><capture.festhalten><en> When 50 years ago, Neil Armstrong became the first man to walk on the moon, optical glasses from SCHOTT helped capture this event in impressive images.
<G-vec00169-001-s531><capture.festhalten><de> Als Neil Armstrong vor 50 Jahren den Mond betrat, halfen optische Gläser von SCHOTT dabei, das Ereignis in eindrucksvollen Bildern festzuhalten.
<G-vec00169-001-s532><capture.festhalten><en> I am always conscious about getting some shots though, even if that means stopping in the middle of a stage to capture something important.
<G-vec00169-001-s532><capture.festhalten><de> Ich werde aber ständig auf der Suche nach guten Aufnahmen sein, selbst wenn das bedeutet, mitten in einer Prüfung anzuhalten und etwas Entscheidendes festzuhalten.
<G-vec00169-001-s533><capture.festhalten><en> However, you don't have to be a trained photographer to capture lovely memories in pictures.
<G-vec00169-001-s533><capture.festhalten><de> Doch um schöne Erinnerung in Bildern festzuhalten, müsst ihr kein ausgebildeter Fotograf sein.
<G-vec00169-001-s534><capture.festhalten><en> With the idea to capture our trip on photo and video, the idea to realize a short film project came up very quickly.
<G-vec00169-001-s534><capture.festhalten><de> Mit dem Gedanken unseren Trip auf Foto und Video festzuhalten, entstand ganz schnell die Idee, ein Kurzfilmprojekt zu realisieren.
<G-vec00169-001-s535><capture.festhalten><en> He used photography as a means to capture the living conditions during this time.
<G-vec00169-001-s535><capture.festhalten><de> Er nutzte das Mittel der Fotografie um die Lebensumstände während dieser Zeit festzuhalten.
<G-vec00169-001-s536><capture.festhalten><en> Exciting and unparalleled were the last months in 2008 - and reason enough to capture this period in a book.
<G-vec00169-001-s536><capture.festhalten><de> Als spannend und einmalig kann man die letzten Monate des Jahres 2008 bezeichnen – also ein guter Grund diese Zeit in einem Buch festzuhalten.
<G-vec00169-001-s537><capture.festhalten><en> DuringÂ MARS2013 she accompanies the fieldÂ crew as part of the media team in MoroccoÂ to capture stunning moments during theÂ simulation.
<G-vec00169-001-s537><capture.festhalten><de> Auf der MARS2013 Mission begleitet sie als Teil des ÖWF Media Teams die Feldcrew in Marokko um dort tolle Momente und Situationen auf der Reise und während der Feldsimulation in Bildern festzuhalten.
<G-vec00169-001-s538><capture.festhalten><en> The end trigger mode also enables you to capture 2 or 4 seconds before the MOVIE button is pressed, letting you capture the decisive moment.
<G-vec00169-001-s538><capture.festhalten><de> Um den entscheidenden Moment festzuhalten, ermöglicht Ihnen der End-Trigger-Modus die Aufnahme 2 oder 4 Sekunden vor dem Drücken der Filmaufnahmetaste.
<G-vec00169-001-s539><capture.festhalten><en> Since 2011, he has been revisiting the locations that inspired him back then in order to capture them in an impressive series of photographs.
<G-vec00169-001-s539><capture.festhalten><de> Seit 2011 sucht er die Drehorte, die ihn damals inspirierten, wieder auf, um sie nun als Fotograf in einer Serie beeindruckender Aufnahmen festzuhalten.
<G-vec00169-001-s540><capture.festhalten><en> I travel a lot and try to capture my impressions and experiences in pictures for those who stayed at home.
<G-vec00169-001-s540><capture.festhalten><de> Ich bin oft auf Reisen und versuche die Eindrücke und Erlebnisse für die Daheimgebliebenen in Bildern festzuhalten.
<G-vec00169-001-s541><capture.festhalten><en> Fine Art Photographer Katja Scherle was the third talented lady in the league, whose job it was, to capture the visions of the two artists in her incomparable way.
<G-vec00169-001-s541><capture.festhalten><de> Fine ArtFotografin Katja Scherle war die Dritte im Bunde, deren Aufgabe es war, die wahrgewordenen Visionen der beiden Künstlerinnen auf ihre unvergleichliche Weise festzuhalten.
<G-vec00169-001-s542><capture.festhalten><en> More than 500 precise body measurements and about 200 photographs are needed to capture even the smallest feature of a person in the most realistic detail possible.
<G-vec00169-001-s542><capture.festhalten><de> Mehr als 500 präzise Körpermessungen und etwa 200 Fotos sind nötig, um so detailgetreu wie möglich jedes noch so kleine Merkmal einer Person festzuhalten.
<G-vec00169-001-s543><capture.festhalten><en> In this connection, the exhibition features several documentary recordings of Ewa Partum's performances and speeches, along with the films from the 1970s and 1980s that tried to capture the phenomenon of Partum.
<G-vec00169-001-s543><capture.festhalten><de> In diesem Zusammenhang zeigt die Ausstellung mehrere dokumentarische Aufzeichnungen von Ewa Partums Performances und Reden sowie die Filme aus den siebziger und achtziger Jahren, die das Phänomen Partum festzuhalten versuchten.
<G-vec00169-001-s544><capture.festhalten><en> I always wanted to capture moments and impressions with photographs.
<G-vec00169-001-s544><capture.festhalten><de> Ich hatte schon immer das Bedürfnis, Momente und Eindrücke in Bildern festzuhalten.
<G-vec00169-001-s545><capture.festhalten><en> Biedermeier painting strove above all to capture the actual world within a picture.
<G-vec00169-001-s545><capture.festhalten><de> Die Malerei des Biedermeier war bestrebt, die tatsächliche Welt im Bild festzuhalten.
<G-vec00169-001-s546><capture.festhalten><en> It’s crucial to capture these precious jewels at whatever inconvenient time they strike.
<G-vec00169-001-s546><capture.festhalten><de> Es ist ganz wichtig sie festzuhalten, selbst wenn sie zu so unbequemen Zeitpunkten auftauchen.
<G-vec00169-001-s547><capture.festhalten><en> These are some of the methods that you could use to get rid of the Samsung camera failed notification that is not only very annoying, but it stops you from being able to capture moments that will forever be lost otherwise.
<G-vec00169-001-s547><capture.festhalten><de> Dies sind nur einige der Methoden, die Sie verwenden können, um loszuwerden die Samsung-Kamera ist fehlgeschlagen Meldung, dass nicht nur sehr ärgerlich, aber es hält Sie von der Möglichkeit, Momente festzuhalten, die sonst für immer verloren gehen.
<G-vec00169-001-s548><capture.festhalten><en> Thanks a photographer friend was present to capture one of these silent moments between Conrad and me this March in Heidelberg.
<G-vec00169-001-s548><capture.festhalten><de> Zum Glück war eine befreundete Fotografin da, um einen dieser stillen Momente zwischen Conrad und mir diesen März in Heidelberg festzuhalten.
<G-vec00169-001-s549><capture.festhalten><en> So my journey of the last ten years has brought me from the drawing of colorful faces and sport scenes to the attempt, to capture details of nature and humans in realistic oil paintings.
<G-vec00169-001-s549><capture.festhalten><de> So brachte mich meine Reise der letzten 10 Jahre vom malen von farbigen Gesichtern und Sportszenen, zu dem Versuch, Einzelheiten der Natur und Menschen in realistischen Ölbildern festzuhalten.
<G-vec00169-001-s569><capture.gefangen_nehmen><en> "2007-11-13 22:16:19 - Happiness fleeting ""You cannot capture happiness no matter how hard you may chase after it."
<G-vec00169-001-s569><capture.gefangen_nehmen><de> "2007-11-13 22:16:19 - Glück Flüchtig ""Sie können nicht Glück gefangennehmen, egal wie stark Sie nach ihm jagen können."
<G-vec00169-001-s570><capture.gefangen_nehmen><en> The wideness of the secluded mountains in the Greater Caucasus Mountain Range will capture you and our package which guarantees Austrian standards and small groups is the perfect framework for an unforgettable Heliski week.
<G-vec00169-001-s570><capture.gefangen_nehmen><de> Die Weiten der einsamen Bergwelt des Kaukasus werden Sie gefangennehmen – und durch unser Paket, das Ihnen österreichische Standards und Kleingruppen garantiert, ist ein unvergessliches Heliskierlebnis vorgegeben.
<G-vec00169-001-s571><capture.gefangen_nehmen><en> But if you constantly and very secretly adhere in yourself to the outer things and their enticements, and wander around in the limited region of your earthly wisdom and all kinds of experiences that you have gained as a blind person, then it still can happen to you that the evil spirit of the world will capture you completely, and as a pitiful victim, your body and soul will become his prey.
<G-vec00169-001-s571><capture.gefangen_nehmen><de> Wenn du aber in einem fort noch so geheim bei dir an den äußeren Dingen und ihren Reizen hängen wirst und herumschwärmen in dem engen Bereich deiner irdischen Weisheit und allerlei als ein Blinder erworbener Erfahrungen, so kann es dir schon noch begegnen, dass der böse Geist der Welt dich ganz gefangennehmen wird und du ihm als ein jammervolles Opfer zur Beute wirst mit Leib und Seele.
<G-vec00169-001-s572><capture.gefangen_nehmen><en> Some webmasters use a more informal 'guest book' method but it's basically the same thing, you capture e-mails and get permission to inform people of special events/updates relating to your site or product.
<G-vec00169-001-s572><capture.gefangen_nehmen><de> Einige webmasters benutzen ein formloseres ' Gastbuch ' Methode aber es sind im Allgemeinen die gleiche Sache, Sie gefangennehmen E-mails und erhalten Erlaubnis, Leute über spezielles zu informieren events/updates in bezug auf ist Ihren Aufstellungsort oder Produkt.
<G-vec00169-001-s573><capture.gefangen_nehmen><en> According to PC Dome, the patch addresses the following issues; attack from different angles, it is more difficult to pass enemy units, new random events such as escape, after battle the winner can capture goods, multiplayer support via e-mail.
<G-vec00169-001-s573><capture.gefangen_nehmen><de> Entsprechend PC Dome spricht die Korrektur die folgenden Punkte an; Angriff von den unterschiedlichen Winkeln, ist es schwieriger, feindliche Maßeinheiten, neue gelegentliche Fälle wie Entweichen, nach Schlacht, die der Sieger Waren gefangennehmen kann, Multispielerunterstützung zu führen über E-mail.
<G-vec00169-001-s574><capture.gefangen_nehmen><en> This Universal Serial Bus monitoring utility can spy, capture, view, log, analyze, test usb device activity performing connection traffic analysis with data acquisition and control.
<G-vec00169-001-s574><capture.gefangen_nehmen><de> Dieser Universalserienbus, der Dienstprogramm überwacht, kann die usb Vorrichtung Tätigkeit ausspionieren, gefangennehmen, ansehen, loggen, analysieren, prüfen, die Anschlußverkehrsauswertung mit Datenerfassung und Steuerung durchführt.
<G-vec00169-001-s575><capture.gefangen_nehmen><en> In fact, we should be adding to a winner and widening stops rather than working out how tight our stops can be to capture maximum profit.
<G-vec00169-001-s575><capture.gefangen_nehmen><de> Tatsächlich sollten wir einem Sieger hinzufügen und verbreiternd stoppt anstatt, ausarbeitend, wie fest unsere Anschläge maximalen Profit gefangennehmen sollen können.
<G-vec00169-001-s576><capture.gefangen_nehmen><en> Fifteen huge hits from the Broadway and The West End have been specially arranged for the Keyboard beginner, so that you can impress your friends and capture the magic of your favourite shows.
<G-vec00169-001-s576><capture.gefangen_nehmen><de> Fünfzehn enorme Schläge vom Broadway und vom West End sind besonders für den Tastaturanfänger vereinbart worden, damit du deine Freunde beeindrucken und die Magie deiner Lieblingsshows gefangennehmen kannst.
<G-vec00169-001-s577><capture.gefangen_nehmen><en> So, what we have is an exhibition within the exhibition; one which will certainly not fail to capture the interest of the numerous art lovers expected……….
<G-vec00169-001-s577><capture.gefangen_nehmen><de> So was wir haben, ist eine Ausstellung innerhalb der Ausstellung; man, der zweifellos das Interesse der zahlreichen kunstgeliebten gefangennehmen kann, erwartete..........
<G-vec00169-001-s578><capture.gefangen_nehmen><en> You can also capture their email addresses when you offer them a free trial from your website.
<G-vec00169-001-s578><capture.gefangen_nehmen><de> Sie können ihre email Adressen auch gefangennehmen, wenn Sie ihnen einen freien Versuch von Ihrer Web site anbieten.
<G-vec00169-001-s579><capture.gefangen_nehmen><en> But the word animates and makes the soul free and is therefore more valuable than a thousand signs which do not animate, but instead only capture the mind in that it fills it with fear.
<G-vec00169-001-s579><capture.gefangen_nehmen><de> Das Wort aber belebt und macht die Seele frei und ist darum mehr wert denn tausend Zeichen, die nicht beleben, sondern nur gefangennehmen das Gemüt, das sie mit Angst erfüllen.
<G-vec00169-001-s580><capture.gefangen_nehmen><en> In the end, Marshal Kung (Shih Kien) and his son (Yuen Biao) manage to capture Lung.
<G-vec00169-001-s580><capture.gefangen_nehmen><de> Marshal Kung (Shih Kien) und sein Sohn (Yuen Biao) können schließlich Lung gefangennehmen.
<G-vec00169-001-s581><capture.gefangen_nehmen><en> The relevant market equals the company's sales if it were to capture 100% of its specific niche of the market.
<G-vec00169-001-s581><capture.gefangen_nehmen><de> Der relevante Markt entspricht den Verkäufen der Firma, wenn er 100% seiner spezifischen Nische des Marktes gefangennehmen sollte.
<G-vec00169-001-s582><capture.gefangen_nehmen><en> I however never appear together with my opponent, therefore also my wooing about the love of men will never be connected with temptations of the world, which completely capture weak and unbelieving men and as a result of which power is withdrawn from them, to be active in love.
<G-vec00169-001-s582><capture.gefangen_nehmen><de> Ich trete jedoch niemals gemeinsam mit Meinem Gegner auf, also wird auch Mein Werben um die Liebe der Menschen niemals verbunden sein mit Lockungen der Welt, welche die schwachen oder ungläubigen Menschen restlos gefangennehmen und wodurch ihnen die Kraft entzogen wird, in Liebe tätig zu sein.
<G-vec00286-001-s569><capture.nehmen><en> "2007-11-13 22:16:19 - Happiness fleeting ""You cannot capture happiness no matter how hard you may chase after it."
<G-vec00286-001-s569><capture.nehmen><de> "2007-11-13 22:16:19 - Glück Flüchtig ""Sie können nicht Glück gefangennehmen, egal wie stark Sie nach ihm jagen können."
<G-vec00286-001-s570><capture.nehmen><en> The wideness of the secluded mountains in the Greater Caucasus Mountain Range will capture you and our package which guarantees Austrian standards and small groups is the perfect framework for an unforgettable Heliski week.
<G-vec00286-001-s570><capture.nehmen><de> Die Weiten der einsamen Bergwelt des Kaukasus werden Sie gefangennehmen – und durch unser Paket, das Ihnen österreichische Standards und Kleingruppen garantiert, ist ein unvergessliches Heliskierlebnis vorgegeben.
<G-vec00286-001-s571><capture.nehmen><en> But if you constantly and very secretly adhere in yourself to the outer things and their enticements, and wander around in the limited region of your earthly wisdom and all kinds of experiences that you have gained as a blind person, then it still can happen to you that the evil spirit of the world will capture you completely, and as a pitiful victim, your body and soul will become his prey.
<G-vec00286-001-s571><capture.nehmen><de> Wenn du aber in einem fort noch so geheim bei dir an den äußeren Dingen und ihren Reizen hängen wirst und herumschwärmen in dem engen Bereich deiner irdischen Weisheit und allerlei als ein Blinder erworbener Erfahrungen, so kann es dir schon noch begegnen, dass der böse Geist der Welt dich ganz gefangennehmen wird und du ihm als ein jammervolles Opfer zur Beute wirst mit Leib und Seele.
<G-vec00286-001-s572><capture.nehmen><en> Some webmasters use a more informal 'guest book' method but it's basically the same thing, you capture e-mails and get permission to inform people of special events/updates relating to your site or product.
<G-vec00286-001-s572><capture.nehmen><de> Einige webmasters benutzen ein formloseres ' Gastbuch ' Methode aber es sind im Allgemeinen die gleiche Sache, Sie gefangennehmen E-mails und erhalten Erlaubnis, Leute über spezielles zu informieren events/updates in bezug auf ist Ihren Aufstellungsort oder Produkt.
<G-vec00286-001-s573><capture.nehmen><en> According to PC Dome, the patch addresses the following issues; attack from different angles, it is more difficult to pass enemy units, new random events such as escape, after battle the winner can capture goods, multiplayer support via e-mail.
<G-vec00286-001-s573><capture.nehmen><de> Entsprechend PC Dome spricht die Korrektur die folgenden Punkte an; Angriff von den unterschiedlichen Winkeln, ist es schwieriger, feindliche Maßeinheiten, neue gelegentliche Fälle wie Entweichen, nach Schlacht, die der Sieger Waren gefangennehmen kann, Multispielerunterstützung zu führen über E-mail.
<G-vec00286-001-s574><capture.nehmen><en> This Universal Serial Bus monitoring utility can spy, capture, view, log, analyze, test usb device activity performing connection traffic analysis with data acquisition and control.
<G-vec00286-001-s574><capture.nehmen><de> Dieser Universalserienbus, der Dienstprogramm überwacht, kann die usb Vorrichtung Tätigkeit ausspionieren, gefangennehmen, ansehen, loggen, analysieren, prüfen, die Anschlußverkehrsauswertung mit Datenerfassung und Steuerung durchführt.
<G-vec00286-001-s575><capture.nehmen><en> In fact, we should be adding to a winner and widening stops rather than working out how tight our stops can be to capture maximum profit.
<G-vec00286-001-s575><capture.nehmen><de> Tatsächlich sollten wir einem Sieger hinzufügen und verbreiternd stoppt anstatt, ausarbeitend, wie fest unsere Anschläge maximalen Profit gefangennehmen sollen können.
<G-vec00286-001-s576><capture.nehmen><en> Fifteen huge hits from the Broadway and The West End have been specially arranged for the Keyboard beginner, so that you can impress your friends and capture the magic of your favourite shows.
<G-vec00286-001-s576><capture.nehmen><de> Fünfzehn enorme Schläge vom Broadway und vom West End sind besonders für den Tastaturanfänger vereinbart worden, damit du deine Freunde beeindrucken und die Magie deiner Lieblingsshows gefangennehmen kannst.
<G-vec00286-001-s577><capture.nehmen><en> So, what we have is an exhibition within the exhibition; one which will certainly not fail to capture the interest of the numerous art lovers expected……….
<G-vec00286-001-s577><capture.nehmen><de> So was wir haben, ist eine Ausstellung innerhalb der Ausstellung; man, der zweifellos das Interesse der zahlreichen kunstgeliebten gefangennehmen kann, erwartete..........
<G-vec00286-001-s578><capture.nehmen><en> You can also capture their email addresses when you offer them a free trial from your website.
<G-vec00286-001-s578><capture.nehmen><de> Sie können ihre email Adressen auch gefangennehmen, wenn Sie ihnen einen freien Versuch von Ihrer Web site anbieten.
<G-vec00286-001-s579><capture.nehmen><en> But the word animates and makes the soul free and is therefore more valuable than a thousand signs which do not animate, but instead only capture the mind in that it fills it with fear.
<G-vec00286-001-s579><capture.nehmen><de> Das Wort aber belebt und macht die Seele frei und ist darum mehr wert denn tausend Zeichen, die nicht beleben, sondern nur gefangennehmen das Gemüt, das sie mit Angst erfüllen.
<G-vec00286-001-s580><capture.nehmen><en> In the end, Marshal Kung (Shih Kien) and his son (Yuen Biao) manage to capture Lung.
<G-vec00286-001-s580><capture.nehmen><de> Marshal Kung (Shih Kien) und sein Sohn (Yuen Biao) können schließlich Lung gefangennehmen.
<G-vec00286-001-s581><capture.nehmen><en> The relevant market equals the company's sales if it were to capture 100% of its specific niche of the market.
<G-vec00286-001-s581><capture.nehmen><de> Der relevante Markt entspricht den Verkäufen der Firma, wenn er 100% seiner spezifischen Nische des Marktes gefangennehmen sollte.
<G-vec00286-001-s582><capture.nehmen><en> I however never appear together with my opponent, therefore also my wooing about the love of men will never be connected with temptations of the world, which completely capture weak and unbelieving men and as a result of which power is withdrawn from them, to be active in love.
<G-vec00286-001-s582><capture.nehmen><de> Ich trete jedoch niemals gemeinsam mit Meinem Gegner auf, also wird auch Mein Werben um die Liebe der Menschen niemals verbunden sein mit Lockungen der Welt, welche die schwachen oder ungläubigen Menschen restlos gefangennehmen und wodurch ihnen die Kraft entzogen wird, in Liebe tätig zu sein.
<G-vec00169-001-s583><capture.gefangen_nehmen><en> 2007-11-13 22:16:19 - 14 ways to add content to your web site - part 1 When I surf the Net, I often see web sites filled with beautiful graphics that strive to capture my attention.
<G-vec00169-001-s583><capture.gefangen_nehmen><de> 2007-11-13 22:16:19 - 14 Möglichkeiten, Inhalt Ihrer Web site hinzuzufügen - Teil 1 Wenn ich das Netz surfe, sehe ich häufig die Netzaufstellungsorte, die mit schönen Graphiken gefüllt werden, die sich bemühen, meine Aufmerksamkeit gefangenzunehmen.
<G-vec00169-001-s584><capture.gefangen_nehmen><en> Most individuals are looking for more meaning in their lives, as are businesses looking to capture the spirit of what they do.
<G-vec00169-001-s584><capture.gefangen_nehmen><de> Die meisten Einzelpersonen suchen nach mehr Bedeutung in ihren Leben, wie die Geschäfte seien Sie, die schauen, um gefangenzunehmen den Geist von, was sie.
<G-vec00169-001-s585><capture.gefangen_nehmen><en> The main goal of Sherwood Forest Fortunes is to capture the Sheriff that is hiding somewhere in the Sherwood Forest; when players finally lay their hands on him, they'll be rewarded with a huge bonus prize.
<G-vec00169-001-s585><capture.gefangen_nehmen><de> Das Hauptziel von Sherwood Forest Fortunes ist den Sheriff gefangenzunehmen, der irgendwo im Sherwood-Wald versteckt ist; wenn die Spieler ihn schließlich erwischen, werden sie mit einem riesigen Bonuspreis belohnt.
<G-vec00169-001-s586><capture.gefangen_nehmen><en> Such enterprises have the power to capture people's attention.
<G-vec00169-001-s586><capture.gefangen_nehmen><de> Solche Unternehmen haben die Energie, Aufmerksamkeit der Leute gefangenzunehmen.
<G-vec00169-001-s587><capture.gefangen_nehmen><en> Alexander and his army were heading north to capture Darius.
<G-vec00169-001-s587><capture.gefangen_nehmen><de> Alexander und seine Armee waren die Überschrift, die, Darius gefangenzunehmen Nord ist.
<G-vec00169-001-s588><capture.gefangen_nehmen><en> The book appeared in print in the middle of November - too late to capture Christmas sales.
<G-vec00169-001-s588><capture.gefangen_nehmen><de> Das Buch schien im Druck mitten in November - zu spät, Weihnachtsverkäufe gefangenzunehmen.
<G-vec00169-001-s589><capture.gefangen_nehmen><en> 2007-11-13 22:16:19 - Everybody is fixing their house or apartment up these days. use that digital camera to capture That's right, you go through all the trouble of making your house or apartment nicer by hauling yourself off to the local fix it yourself store or hiring some professionals to come in and do it for you, so why not capture an accurate record of it for posterity.
<G-vec00169-001-s589><capture.gefangen_nehmen><de> 2007-11-13 22:16:19 - Jeder repariert ihr Haus oder Wohnung herauf diese Tagesgebrauch diese digitale Kamera gefangenzunehmen Das ist recht, laufen Sie die ganze Mühe des Bildens Ihres Hauses oder Wohnung netter, indem Sie sich weg zur lokalen Verlegenheit es sich Speicher schleppen oder einige Fachleute anstellen, um hereinzukommen durch und tun ihn für Sie, also warum nicht Sicherung eine genaue Aufzeichnung von ihr für Nachwelt.
<G-vec00169-001-s590><capture.gefangen_nehmen><en> A newly formed company, called WorldLingo, has a solution that will help capture these lost sales.
<G-vec00169-001-s590><capture.gefangen_nehmen><de> Eine neugeformte Firma, angerufen WorldLingo, hat eine Lösung, die hilft, diese verlorenen Verkäufe gefangenzunehmen.
<G-vec00169-001-s591><capture.gefangen_nehmen><en> Photography and telegraphy, invented in the 1830s and 1840s, were among the first technologies to use chemical processes or electrical signals to capture or express images and words.
<G-vec00169-001-s591><capture.gefangen_nehmen><de> Die Fotographie und Telegraphie, erfunden im 1830s und im 1840s, gehörten zu den ersten Technologien, zum der chemischen Prozesse oder der elektrischen Signale zu benutzen, Bilder und Wörter gefangenzunehmen oder auszudrücken.
<G-vec00169-001-s592><capture.gefangen_nehmen><en> The Star Tribune sent a photographer to capture the scene.
<G-vec00169-001-s592><capture.gefangen_nehmen><de> Die Stern-Tribüne sendete einen Fotografen, um die Szene gefangenzunehmen.
<G-vec00169-001-s593><capture.gefangen_nehmen><en> Attendees spent time with an Adestra expert who provided feedback and useful advice about how they could improve their campaigns.Main LessonsData, data and more data is the main factor holding back B2B and B2C email marketersData Management:Many marketers are only capturing email address and failing to use follow-up communications to capture further information.
<G-vec00169-001-s593><capture.gefangen_nehmen><de> Teilnehmer verbrachten Zeit mit einem Adestra Experten, der Rückgespräch und nützlichen Rat zur Verfügung stellte über, wie sie ihre Kampagnen verbessern konnten.HauptlektionenDaten, Daten und mehr Daten sind der Hauptfaktor, der rückseitiges B2B und B2C email Marketingspezialisten hältDatenverwaltung:Viele Marketingspezialisten nehmen nur email address gefangen und können Anschlußkommunikationen verwenden, um nicht weitere Informationen gefangenzunehmen.
<G-vec00169-001-s594><capture.gefangen_nehmen><en> And we were THRILLED!Not a single photographer showed up to capture the moment.
<G-vec00169-001-s594><capture.gefangen_nehmen><de> Und wir wurden GEBEGEISTERT!Nicht zeigte sich ein einzelner Fotograf, um den Moment gefangenzunehmen.
<G-vec00169-001-s595><capture.gefangen_nehmen><en> Having been informed of the presence of the Russian ship in the Door of Split, the Marmont Marshal ordered with his artillery and his fleet to attack and capture the Russian ship.
<G-vec00169-001-s595><capture.gefangen_nehmen><de> Informierend über die Anwesenheit des russischen Schiffes in der Tür von Split befahl Marschall Marmont seiner Artillerie und seiner Flotte, das russische Schiff anzugreifen und gefangenzunehmen.
<G-vec00169-001-s596><capture.gefangen_nehmen><en> To ensure the safety of the group, of the chiefs of war are named: they are in charge of work of prevention of the risks of violence and they have the force armed to capture the criminals, to withdraw the weapons of the enemy hands.
<G-vec00169-001-s596><capture.gefangen_nehmen><de> Um die Sicherheit der Gruppe zu gewährleisten werden Kriegschefs ernannt: sie werden mit den Arbeiten der Vorbeugung der Gewaltrisiken beauftragt, und sie verfügen über die Streitkräfte, um die Verbrecher gefangenzunehmen, die Waffen der feindlichen Hände abzuziehen.
<G-vec00169-001-s597><capture.gefangen_nehmen><en> Now that you have the perfect decorations, don't forget to capture them on film.
<G-vec00169-001-s597><capture.gefangen_nehmen><de> Nun da Sie die vollkommenen Dekorationen haben, vergessen Sie nicht, sie auf Film gefangenzunehmen.
<G-vec00169-001-s598><capture.gefangen_nehmen><en> There were two other witnesses with me, and one of my friends was able to capture several photos.
<G-vec00169-001-s598><capture.gefangen_nehmen><de> Es gab zwei andere Zeugen mit mir, und einer meiner Freunde war in der Lage, mehrere Fotos gefangenzunehmen.
<G-vec00169-001-s599><capture.gefangen_nehmen><en> This time he builds a robot 'son' to help him capture Sonic.
<G-vec00169-001-s599><capture.gefangen_nehmen><de> "Dieses Mal errichtet er einen Roboter ""Sohn"", um ihm zu helfen, Sonic gefangenzunehmen."
<G-vec00286-001-s583><capture.nehmen><en> 2007-11-13 22:16:19 - 14 ways to add content to your web site - part 1 When I surf the Net, I often see web sites filled with beautiful graphics that strive to capture my attention.
<G-vec00286-001-s583><capture.nehmen><de> 2007-11-13 22:16:19 - 14 Möglichkeiten, Inhalt Ihrer Web site hinzuzufügen - Teil 1 Wenn ich das Netz surfe, sehe ich häufig die Netzaufstellungsorte, die mit schönen Graphiken gefüllt werden, die sich bemühen, meine Aufmerksamkeit gefangenzunehmen.
<G-vec00286-001-s584><capture.nehmen><en> Most individuals are looking for more meaning in their lives, as are businesses looking to capture the spirit of what they do.
<G-vec00286-001-s584><capture.nehmen><de> Die meisten Einzelpersonen suchen nach mehr Bedeutung in ihren Leben, wie die Geschäfte seien Sie, die schauen, um gefangenzunehmen den Geist von, was sie.
<G-vec00286-001-s585><capture.nehmen><en> The main goal of Sherwood Forest Fortunes is to capture the Sheriff that is hiding somewhere in the Sherwood Forest; when players finally lay their hands on him, they'll be rewarded with a huge bonus prize.
<G-vec00286-001-s585><capture.nehmen><de> Das Hauptziel von Sherwood Forest Fortunes ist den Sheriff gefangenzunehmen, der irgendwo im Sherwood-Wald versteckt ist; wenn die Spieler ihn schließlich erwischen, werden sie mit einem riesigen Bonuspreis belohnt.
<G-vec00286-001-s586><capture.nehmen><en> Such enterprises have the power to capture people's attention.
<G-vec00286-001-s586><capture.nehmen><de> Solche Unternehmen haben die Energie, Aufmerksamkeit der Leute gefangenzunehmen.
<G-vec00286-001-s587><capture.nehmen><en> Alexander and his army were heading north to capture Darius.
<G-vec00286-001-s587><capture.nehmen><de> Alexander und seine Armee waren die Überschrift, die, Darius gefangenzunehmen Nord ist.
<G-vec00286-001-s588><capture.nehmen><en> The book appeared in print in the middle of November - too late to capture Christmas sales.
<G-vec00286-001-s588><capture.nehmen><de> Das Buch schien im Druck mitten in November - zu spät, Weihnachtsverkäufe gefangenzunehmen.
<G-vec00286-001-s589><capture.nehmen><en> 2007-11-13 22:16:19 - Everybody is fixing their house or apartment up these days. use that digital camera to capture That's right, you go through all the trouble of making your house or apartment nicer by hauling yourself off to the local fix it yourself store or hiring some professionals to come in and do it for you, so why not capture an accurate record of it for posterity.
<G-vec00286-001-s589><capture.nehmen><de> 2007-11-13 22:16:19 - Jeder repariert ihr Haus oder Wohnung herauf diese Tagesgebrauch diese digitale Kamera gefangenzunehmen Das ist recht, laufen Sie die ganze Mühe des Bildens Ihres Hauses oder Wohnung netter, indem Sie sich weg zur lokalen Verlegenheit es sich Speicher schleppen oder einige Fachleute anstellen, um hereinzukommen durch und tun ihn für Sie, also warum nicht Sicherung eine genaue Aufzeichnung von ihr für Nachwelt.
<G-vec00286-001-s590><capture.nehmen><en> A newly formed company, called WorldLingo, has a solution that will help capture these lost sales.
<G-vec00286-001-s590><capture.nehmen><de> Eine neugeformte Firma, angerufen WorldLingo, hat eine Lösung, die hilft, diese verlorenen Verkäufe gefangenzunehmen.
<G-vec00286-001-s591><capture.nehmen><en> Photography and telegraphy, invented in the 1830s and 1840s, were among the first technologies to use chemical processes or electrical signals to capture or express images and words.
<G-vec00286-001-s591><capture.nehmen><de> Die Fotographie und Telegraphie, erfunden im 1830s und im 1840s, gehörten zu den ersten Technologien, zum der chemischen Prozesse oder der elektrischen Signale zu benutzen, Bilder und Wörter gefangenzunehmen oder auszudrücken.
<G-vec00286-001-s592><capture.nehmen><en> The Star Tribune sent a photographer to capture the scene.
<G-vec00286-001-s592><capture.nehmen><de> Die Stern-Tribüne sendete einen Fotografen, um die Szene gefangenzunehmen.
<G-vec00286-001-s593><capture.nehmen><en> Attendees spent time with an Adestra expert who provided feedback and useful advice about how they could improve their campaigns.Main LessonsData, data and more data is the main factor holding back B2B and B2C email marketersData Management:Many marketers are only capturing email address and failing to use follow-up communications to capture further information.
<G-vec00286-001-s593><capture.nehmen><de> Teilnehmer verbrachten Zeit mit einem Adestra Experten, der Rückgespräch und nützlichen Rat zur Verfügung stellte über, wie sie ihre Kampagnen verbessern konnten.HauptlektionenDaten, Daten und mehr Daten sind der Hauptfaktor, der rückseitiges B2B und B2C email Marketingspezialisten hältDatenverwaltung:Viele Marketingspezialisten nehmen nur email address gefangen und können Anschlußkommunikationen verwenden, um nicht weitere Informationen gefangenzunehmen.
<G-vec00286-001-s594><capture.nehmen><en> And we were THRILLED!Not a single photographer showed up to capture the moment.
<G-vec00286-001-s594><capture.nehmen><de> Und wir wurden GEBEGEISTERT!Nicht zeigte sich ein einzelner Fotograf, um den Moment gefangenzunehmen.
<G-vec00286-001-s595><capture.nehmen><en> Having been informed of the presence of the Russian ship in the Door of Split, the Marmont Marshal ordered with his artillery and his fleet to attack and capture the Russian ship.
<G-vec00286-001-s595><capture.nehmen><de> Informierend über die Anwesenheit des russischen Schiffes in der Tür von Split befahl Marschall Marmont seiner Artillerie und seiner Flotte, das russische Schiff anzugreifen und gefangenzunehmen.
<G-vec00286-001-s596><capture.nehmen><en> To ensure the safety of the group, of the chiefs of war are named: they are in charge of work of prevention of the risks of violence and they have the force armed to capture the criminals, to withdraw the weapons of the enemy hands.
<G-vec00286-001-s596><capture.nehmen><de> Um die Sicherheit der Gruppe zu gewährleisten werden Kriegschefs ernannt: sie werden mit den Arbeiten der Vorbeugung der Gewaltrisiken beauftragt, und sie verfügen über die Streitkräfte, um die Verbrecher gefangenzunehmen, die Waffen der feindlichen Hände abzuziehen.
<G-vec00286-001-s597><capture.nehmen><en> Now that you have the perfect decorations, don't forget to capture them on film.
<G-vec00286-001-s597><capture.nehmen><de> Nun da Sie die vollkommenen Dekorationen haben, vergessen Sie nicht, sie auf Film gefangenzunehmen.
<G-vec00286-001-s598><capture.nehmen><en> There were two other witnesses with me, and one of my friends was able to capture several photos.
<G-vec00286-001-s598><capture.nehmen><de> Es gab zwei andere Zeugen mit mir, und einer meiner Freunde war in der Lage, mehrere Fotos gefangenzunehmen.
<G-vec00286-001-s599><capture.nehmen><en> This time he builds a robot 'son' to help him capture Sonic.
<G-vec00286-001-s599><capture.nehmen><de> "Dieses Mal errichtet er einen Roboter ""Sohn"", um ihm zu helfen, Sonic gefangenzunehmen."
<G-vec00169-001-s600><capture.gewinnen><en> Unlike others, it shows process names initiated network connections and allows you to set filters to capture only the traffic you are interested in.
<G-vec00169-001-s600><capture.gewinnen><de> Verschieden von anderen zeigt es Prozess-Namen begonnene Netzverbindungen und erlaubt Ihnen, Filter einzubauen, um nur den Verkehr zu gewinnen, für den Sie sich interessieren.
<G-vec00169-001-s601><capture.gewinnen><en> Exuding a sense of classic beauty and grace, this hand bouquet will certainly capture everyone's attention on any special occasion.
<G-vec00169-001-s601><capture.gewinnen><de> Einen Sinn der klassischen Schönheit und Anmut ausstrahlend, wird dieses Handbukett sicher jedermanns Aufmerksamkeit bei jeder speziellen Gelegenheit gewinnen.
<G-vec00169-001-s602><capture.gewinnen><en> If your partner plays a card that captures a build belonging to you or your partner, and you have a card of that rank in your hand, you may ask your partner not to capture the build.
<G-vec00169-001-s602><capture.gewinnen><de> Wenn Ihr Partner eine Karte spielt, die einen Build gewinnt, den Sie oder Ihr Partner besitzen, und sich eine Karte mit diesem Rang in Ihrem Blatt befindet, können Sie Ihren Partner bitten, diesen Build nicht zu gewinnen.
<G-vec00169-001-s603><capture.gewinnen><en> But actually, there was, at least musically, no reason to do so as the quite melodic post-punk, hardcore sounds, Refused could be mentioned here, managed to capture my attention for the entire 30 minutes playing time.
<G-vec00169-001-s603><capture.gewinnen><de> Dafür gab ́s eigentlich, zumindest musikalisch, keinen Grund, denn die durchaus melodiösen Post-Punk, Hardcore Sounds, Refused seien hier mal erwähnt, konnten meine Aufmerksamkeit für die gesamten 30 Minuten Spielzeit gewinnen.
<G-vec00169-001-s604><capture.gewinnen><en> Knowing when your audience is most receptive, those moments when you can really capture someone's attention or change their mind, and then meeting them there with the right message: that's the next frontier.
<G-vec00169-001-s604><capture.gewinnen><de> Zu wissen, wann die gewünschte Zielgruppe am empfänglichsten ist, diese Momente zu erkennen, in denen man die Aufmerksamkeit eines Kunden gewinnen oder ihn umstimmen kann, und sie dann mit der richtigen Botschaft anzusprechen: Das macht die Werbung der Zukunft aus.
<G-vec00169-001-s605><capture.gewinnen><en> "Craig Goodwin, CEO commented ""This financing gives Naturally Splendid the financial flexibility to move forward aggressively to capture existing sales prospects and advance our near term market opportunities."
<G-vec00169-001-s605><capture.gewinnen><de> "CEO Craig Goodwin sagte: ""Diese Finanzierung bietet Naturally Splendid die finanzielle Flexibilität, um sich intensiv weiterentwickeln zu können, um potenzielle Kunden zu gewinnen und um unsere kurzfristigen Marktmöglichkeiten zu nutzen ."
<G-vec00169-001-s606><capture.gewinnen><en> Designed to capture your child's attention, 80% of Dino Lingo videos are presented as either 3D or 2D animations.
<G-vec00169-001-s606><capture.gewinnen><de> Um die Aufmerksamkeit Ihres Kindes zu gewinnen, besteht rund 80% des Videomaterials von Dino Lingo aus 3D oder 2D Animationen.
<G-vec00169-001-s607><capture.gewinnen><en> Our goal is to grow faster than the market and capture more market share.
<G-vec00169-001-s607><capture.gewinnen><de> Unser Ziel ist es, stärker als der Markt zu wachsen und somit Marktanteile zu gewinnen.
<G-vec00169-001-s608><capture.gewinnen><en> And, a little like watching the Croatian team play, a tour of the beauty and diversity of their origins will capture millions more hearts still.
<G-vec00169-001-s608><capture.gewinnen><de> Der kroatische Teamgeist der Nationalmannschaft und eine Reise in die schönen und so unterschiedlichen Heimatorte der Spiele, wird noch mehr Herzen gewinnen als das Team nach der Weltmeisterschaft.
<G-vec00169-001-s609><capture.gewinnen><en> If you play a capturing card as an action of type 1 or 5 (capture or discard), but fail to take all the cards you are entitled to capture, any opponent can insist (if they wish) that you capture all the cards that it is legal for you to take.
<G-vec00169-001-s609><capture.gewinnen><de> Wenn Sie eine gewinnende Karte als Aktion des Typs 1 oder 5 spielen (Gewinnen oder Ablegen), jedoch nicht alle Karten vom Tisch nehmen, zu denen Sie berechtigt sind, kann jeder Gegner verlangen (wenn er dies möchte), dass Sie alle Karten vom Tisch nehmen, zu denen Sie nach den Regeln berechtigt sind.
<G-vec00169-001-s610><capture.gewinnen><en> Being one of the first c ompanies to market, PVA looks to capture a significant portion of that potential revenue.
<G-vec00169-001-s610><capture.gewinnen><de> Als eines der ersten Unternehmen auf dem Markt ist PVA bestrebt, einen beträchtlichen Teil dieses potenziellen Umsatzes für sich zu gewinnen.
<G-vec00169-001-s611><capture.gewinnen><en> If you play a card that matches several separate cards, sets or builds you can capture them all.
<G-vec00169-001-s611><capture.gewinnen><de> Wenn Sie eine Karte spielen, die mehreren verschiedenen Karten, Kartensätzen oder Builds entspricht, dann gewinnen Sie alle.
<G-vec00169-001-s612><capture.gewinnen><en> All regions delivered impressive organic growth, demonstrating the Group's ability to capture market share through innovation.
<G-vec00169-001-s612><capture.gewinnen><de> Alle Regionen meldeten eine beeindruckende natürliche Wachstumsrate, was für die Fähighkeit von The Group steht, Marktanteile durch Innovation zu gewinnen.
<G-vec00169-001-s613><capture.gewinnen><en> You can use videos to capture the attention of your subscribers and customers.
<G-vec00169-001-s613><capture.gewinnen><de> Mit einem Video kannst Du die Aufmerksamkeit Deiner Abonnenten und Kunden gewinnen.
<G-vec00169-001-s614><capture.gewinnen><en> High-tech companies are still chasing demographic shifts in an effort to capture new consumers in burgeoning markets.
<G-vec00169-001-s614><capture.gewinnen><de> High-Tech-Unternehmen jagen noch immer der demografischen Entwicklung hinterher bei dem Versuch, neue Kunden in wachsenden Märkten zu gewinnen.
<G-vec00169-001-s615><capture.gewinnen><en> Empire Flippers has built a free website valuation tool as a way to capture leads.
<G-vec00169-001-s615><capture.gewinnen><de> Empire Flippers hat ein kostenloses Bewertungs-Werkzeug für Webseiten entwickelt, um Leads zu gewinnen.
<G-vec00169-001-s616><capture.gewinnen><en> We have many programs, which all offer you the benefits of partnering with a global software leader, together with the opportunity to capture new customers and access additional revenue streams.
<G-vec00169-001-s616><capture.gewinnen><de> Wir haben mehrere Programme, die Ihnen die Vorteile einer Zusammenarbeit mit einem führenden Softwarehersteller bieten sowie die Möglichkeit, neue Kunden zu gewinnen und zusätzliche Einnahmequellen zu erschließen.
<G-vec00169-001-s617><capture.gewinnen><en> Note that with two or four players there are no face up cards on the table at the start, so the first player cannot capture but must simply play a card.
<G-vec00169-001-s617><capture.gewinnen><de> Beachten Sie, dass bei zwei oder vier Spielern zu Beginn keine Karten aufgedeckt auf den Tisch gelegt werden, sodass der erste Spieler keine Karten gewinnen kann, sondern einfach eine Karte spielen muss.
<G-vec00169-001-s618><capture.gewinnen><en> aiming to allow educators to capture the attention of students through interactive instructional activities.
<G-vec00169-001-s618><capture.gewinnen><de> Durch den Einsatz von interaktiven Lehrmaßnahmen, wollen wir den Erziehern ermöglichen, die Aufmerksamkeit ihrer Schüler zu gewinnen.
<G-vec00169-001-s619><capture.halten><en> Universal Fish Eye for iPhone, Samsung, iPad, iPod Capture your most beautiful shots with the detachable and universal Fish Eye 235 °.
<G-vec00169-001-s619><capture.halten><de> Universal Fish Eye für iPhone, Samsung, iPad, iPod Halten Sie Ihre schönsten Aufnahmen mit dem abnehmbaren und universellen Fish Eye 235 ° fest.
<G-vec00169-001-s620><capture.halten><en> Sosnowska’s pictures likewise capture something entirely different from the taste of the crowd.
<G-vec00169-001-s620><capture.halten><de> Auch Sosnowskas Bilder halten etwas ganz anderes fest als das, wonach der Geschmack der Menge steht.
<G-vec00169-001-s621><capture.halten><en> With a host of slots that are guaranteed to make old-timers of slot gaming nostalgic, Amatic has tried to capture a good part of slot gaming community in a solid grip.
<G-vec00169-001-s621><capture.halten><de> Als Anbieter von Slots, die garantiert selbst Slotspiel-Veteranen in Nostalgie schwelgen lassen, versucht Amatic den Großteil der Slot-Gaming-Community fest im Griff zu halten.
<G-vec00169-001-s622><capture.halten><en> Sabine Bitter and Helmut Weber's recent photo-collages capture the paradox of emergent or new urban landscapes that are not newly built, but are newly shaped by urban transformation as it makes its way through economic expansion and creative destruction.
<G-vec00169-001-s622><capture.halten><de> Sabine Bitters und Helmut Webers neueste Fotocollagen halten das Paradoxon entstehender oder neuer Stadtlandschaften fest, die nicht neu erbaut, sondern im Zuge der urbanen Wandels durch ökonomische Expansion und schöpferische Zerstörung neu geformt werden.
<G-vec00169-001-s623><capture.halten><en> "His pictures of the Mississippi show ""non-places"" and uncultivated land, capture traces of absence and decay: the remains of sleeping places, signs scratched into walls, a horse next to a lonely car wreck."
<G-vec00169-001-s623><capture.halten><de> Seine Bilder vom Mississippi zeigen Unorte, Brachen, halten Spuren von Abwesenheit und Verfall fest: Hinterlassenschaften an Schlafstellen, in die Wände gekratzte Zeichen, ein Pferd neben einem einsamen Autowrack.
<G-vec00169-001-s624><capture.halten><en> Capture your personal World Cup moments and be inspired.
<G-vec00169-001-s624><capture.halten><de> Halten Sie Ihre persönlichen WM-Momente fest und lassen Sie sich inspirieren.
<G-vec00169-001-s625><capture.halten><en> He managed to make a living as a travelling photographer and seed salesman, and upon his death left almost 5,000 glass plates which were preserved merely by chance. These capture the archaic life of his compatriots in the Valle di Blenio, which at the time was totally isolated, and the gradual advent of modernism in a precise and sensitive way.
<G-vec00169-001-s625><capture.halten><de> Er fristete sein Leben als wandernder Fotograf und Samenhändler und hinterließ nach seinem Tod rund 5000 Glasplatten, die sich durch Zufall erhalten haben: sie halten das archaische Leben seiner Landsleute im damals noch abgeschotteten Valle di Blenio und den langsamen Einzug der Moderne präzis und einfühlsam fest.
<G-vec00169-001-s626><capture.halten><en> To create stunning images and capture the finest detail in its purest, clearest form.
<G-vec00169-001-s626><capture.halten><de> Kreieren Sie atemberaubende Bilder und halten Sie feinste Details in ihrer reinsten Form fest.
<G-vec00169-001-s627><capture.halten><en> Capture life just as you see it in true-to-life 4K HDR (HLG) images.
<G-vec00169-001-s627><capture.halten><de> Halten Sie Momente so wie Sie sie wahrnehmen in realistischen 4K HDR (HLG) Bildern fest.
<G-vec00169-001-s628><capture.halten><en> DOODLE CAM: Capture the best moments of your day and bring them to life with filters, text and other creative tools.
<G-vec00169-001-s628><capture.halten><de> Doodle-Kamera: Halten Sie die besten Momente Ihres Tages fest und erwecken Sie sie mit Filtern, Text und anderen kreativen Tools zum Leben.
<G-vec00169-001-s629><capture.halten><en> Chosen *Best of 2014* by Apple Capture your thoughts, discoveries, and ideas and simplify o...
<G-vec00169-001-s629><capture.halten><de> Von Apple als *Best of 2014* ausgewählt Halten Sie Gedanken, Entdeckungen und Ideen fest, u...
<G-vec00169-001-s630><capture.halten><en> -- CAPTURE ANYTHING -- Capture your thoughts, discoveries, and ideas and simplify overwhelming planning moments in your life with your very own digital notebook.
<G-vec00169-001-s630><capture.halten><de> -- ALLES EINFACH FESTHALTEN -- Halten Sie Gedanken, Entdeckungen und Ideen fest, und vereinfachen Sie überwältigende Planungsmomente in Ihrem Leben mit Ihrem ganz persönlichen digitalen Notizbuch.
<G-vec00169-001-s631><capture.halten><en> Painters at the MEISSEN Manufactory know the area and the vibrant show that Nature puts on there – bathing the scenery in colour so our painters can capture special moments and vey sensuously fuse them onto the glaze.
<G-vec00169-001-s631><capture.halten><de> Die Maler der Manufaktur MEISSEN kennen diese Gegend und das bewegte Schauspiel der Natur – sie lässt die Farben über die Landschaft fließen, die Maler halten die Momente fest und verschmelzen sie mit großer Sinnlichkeit auf der Glasur.
<G-vec00169-001-s632><capture.halten><en> Capture one of the most special days in a couples life and honor it with a beautiful hand painted portrait.
<G-vec00169-001-s632><capture.halten><de> Halten Sie einen der schönsten Tage in einem Leben fest und ehren Sie diesen Tag mit einem schönen handgemalten Porträt.
<G-vec00169-001-s633><capture.halten><en> Flytographer 30 Minute Vacation PhotoshootConnect with a local professional photographer in Reykjavik and capture your most memorable moments during this private photoshoot.
<G-vec00169-001-s633><capture.halten><de> Flytographer 90 Minuten Urlaubsfotos Treten Sie in Reykjavik mit einem lokalen Fotografen in Kontakt und halten Sie Ihre unvergesslichsten Momente während dieses privaten Fotoshootings fest.
<G-vec00169-001-s634><capture.können><en> Matrox Mura IPX capture cards feature DirectShow support to leverage existing applications to capture, decode and display physical and IP video sources.
<G-vec00169-001-s634><capture.können><de> Matrox Mura IPX-Erfassungskarten unterstützen DirectShow, sodass vorhandene Anwendungen für das Erfassen, Decodieren und Anzeigen von physischen und IP-Videoquellen genutzt werden können.
<G-vec00169-001-s635><capture.können><en> The pictures do not really capture her charisma adequately.
<G-vec00169-001-s635><capture.können><de> Die Fotos können ihr Charisma nicht wirklich wiedergeben.
<G-vec00169-001-s636><capture.können><en> At HANNOVER MESSE 2016, the developers from Delta Barth will be showing how manufacturing companies that carry out their own maintenance can use the new version of Deleco to make it much easier to capture data.
<G-vec00169-001-s636><capture.können><de> Auf der HANNOVER MESSE 2016 zeigen die Entwickler von Delta Barth, wie produzierende Unternehmen, welche die Wartung ihrer Anlagen selbst übernehmen, mit der neuen Version von Deleco den Arbeitsaufwand für die Datenerfassung deutlich minimieren können.
<G-vec00169-001-s637><capture.können><en> Only the combined powers of the three-eyed deity Er Lang Shen and the great Taoist Lord Lao-Tzu (Laozi) capture him at last.
<G-vec00169-001-s637><capture.können><de> Nur die gemeinsamen Kräfte der dreiäugigen Gottheit Er Lang Shen und des großen Daoisten Lao Tse können ihn am Ende fassen.
<G-vec00169-001-s638><capture.können><en> Only the combined powers of the three-eyed deity Er Lang Shen and the great Taoist Lord Laozi capture him at last.
<G-vec00169-001-s638><capture.können><de> Nur die gemeinsamen Kräfte der dreiäugigen Gottheit Er Lang Shen und des großen Daoisten Lao Tse können ihn am Ende fassen.
<G-vec00169-001-s639><capture.können><en> According to their preferred interpretation, these events provide evidence that, under weak institutions, popular mobilization and protests have a role in restricting the ability of connected firms to capture excess rents.
<G-vec00169-001-s639><capture.können><de> Gemäß der präferierten Hypothese der Autoren sind diese Erkenntnisse ein Hinweis dafür, dass im Fall schwacher Institutionen, weitverbreitete Mobilisierung und Proteste die Möglichkeiten regierungsnaher Firmen einschränken können, überhöhte Renten zu vereinnahmen.
<G-vec00169-001-s640><capture.können><en> Whether looking for defects on highly reflective metal or looking at corrosion in a dark pipe, count on the videoscope to capture the image you want.
<G-vec00169-001-s640><capture.können><de> Ob Sie nach Fehlern auf stark reflektierendem Metall oder nach Rostbildung in einem dunklen Rohr suchen – Sie können sich bei der Bildaufnahme stets auf das Videoskop verlassen.
<G-vec00169-001-s641><capture.können><en> Only recently thyssenkrupp Steel Europe began building a further modern fabric filter that will capture almost 99.99 percent of the dust generated by sinter production.
<G-vec00169-001-s641><capture.können><de> Erst kürzlich hat thyssenkrupp Steel Europe mit dem Bau eines weiteren, modernen Tuchfilters begonnen, mit dem nahezu 99,99 Prozent des Sinter-staubs verursacht durch die Sinterproduktion eingefangen werden können.
<G-vec00169-001-s642><capture.können><en> We will write whatever we want, have fun, and get tips from experts about how to better capture our thoughts and feelings in writing.
<G-vec00169-001-s642><capture.können><de> Wir schreiben, was wir wollen, haben Spaß dabei und erhalten Tipps von Profis, wie wir unsere Gedanken und GefÃ1⁄4hle besser aufschreiben können.
<G-vec00169-001-s643><capture.können><en> Furthermore, it is possible to capture different dynamic loads, which vary depending on the application and execution.
<G-vec00169-001-s643><capture.können><de> Natürlich können auch unterschiedliche dynamische Belastungen wie Zug, Druck und Torsion, die je nach Anwendung und Ausführung variieren können, aufgenohmen werden.
<G-vec00169-001-s644><capture.können><en> Providing possibility to quickly and cost-effectively develop solution that extracts data from forms and documents of virtually any type and complexity, FlexiCapture Engine is an ideal tool for ISVs, OEM vendors and service providers interested in developing data capture solutions.
<G-vec00169-001-s644><capture.können><de> FlexiCapture Engine bietet die Möglichkeit, auf schnelle und effiziente Weise Lösungen zu entwickeln, mit denen Daten nahezu jeder Art und Komplexität aus Formularen und Dokumenten extrahiert werden können.
<G-vec00169-001-s645><capture.können><en> UT283A power quality Analyzer is a comprehensive analysis, measurement of power quality equipment, which can measure not only the basic electric parameters, harmonics and interharmonics and other basic parameters, it can also capture and record in real time the voltage, current, power failures such as flicker.
<G-vec00169-001-s645><capture.können><de> Der UT283A Power Quality Analyzer ist eine umfassende Analyse, Messung von Power Quality-Geräten, mit der nicht nur die grundlegenden elektrischen Parameter, Harmonischen und Interharmonischen sowie andere grundlegende Parameter gemessen werden können, sondern auch die Spannung, den Strom und Stromausfälle in Echtzeit erfasst und aufgezeichnet werden können, z als Flackern.
<G-vec00169-001-s646><capture.können><en> Perhaps I was born with the desire to create, but the ability to create has taken endless hours of drawing and anatomical study to capture with accuracy, the subjects of my fascination.
<G-vec00169-001-s646><capture.können><de> Vielleicht wurde ich mit dem Wunsch geboren, Skulpturen zu erschaffen, aber die Fähigkeit es tatsächlich auch zu tun hat unzählige Stunden von zeichnerischen und anatomischen Studien erfordert um die Objekte meiner Begierde genau darstellen zu können.
<G-vec00169-001-s647><capture.können><en> Sony remains a highly desirable brand, and the Vaio T series aims to capture some of burgeoning ultrabook market.
<G-vec00169-001-s647><capture.können><de> Auch der Blog-Dienst Tumblr wurde auf Nutzerwunsch zu den Plattformen hinzugefügt, auf die Inhalte weitergeleitet werden können, so das Flickr-Blog.
<G-vec00169-001-s648><capture.können><en> It is possible, however, to capture CO2 from the atmosphere (direct air capture) and from flue-gas emissions at industrial sites.
<G-vec00169-001-s648><capture.können><de> Es gibt aber Möglichkeiten, wie wir CO2 wieder einfangen können, zum Beispiel aus Rauchgasemissionen der Industrie oder aus der Atmosphäre (Direct Air Capture).
<G-vec00169-001-s649><capture.können><en> To capture the largest possible area, Bosch uses cameras with a 180-degree angle of view.
<G-vec00169-001-s649><capture.können><de> Um einen möglichst großen Bereich darstellen zu können, verwendet Bosch Kameras mit einem Blickwinkel bis 180 Grad.
<G-vec00169-001-s669><capture.nehmen><en> We capture its gifts with experience and we pass them on.
<G-vec00169-001-s669><capture.nehmen><de> Wir nehmen ihre Geschenke mit Erfahrung auf und geben sie weiter.
<G-vec00169-001-s670><capture.nehmen><en> On the same day, Velibor Maksimovic and his co-defendants allegedly conducted patrols on the road and set up ambushes to intercept the column of Bosniaks and capture the men trying to reach the territory under the control of the Army of the Republic of Bosnia-Herzegovina (BiH).
<G-vec00169-001-s670><capture.nehmen><de> Am selben Tag sollen Velibor Maksimovic und seine Mitangeklagten auf der Straße Patrouillen und Hinterhalte aufgestellt haben, um die bosnische Kolonne abzufangen und jene Männer gefangen zu nehmen, die versuchten, das von der Armee der Republik Bosnien-Herzegowina kontrollierte Gebiet zu erreichen.
<G-vec00169-001-s671><capture.nehmen><en> In fact, it is questionable how much short-term liquidity is really required for a pension fund or whether the better option is not to accept reduced liquidity in order to capture more of the available outperformance.
<G-vec00169-001-s671><capture.nehmen><de> In diesem Kontext ist es fraglich, wie viel kurzfristige Liquidität eine Pensionskasse wirklich benötigt oder ob es nicht besser wäre, eine verminderte Liquidität in Kauf zu nehmen, um einen größeren Anteil der möglichen Überrendite zu realisieren.
<G-vec00169-001-s672><capture.nehmen><en> Capture with Five Clip Station is one of our handmade PANDORA Bracelet which is made out of solid Sterling Silver.
<G-vec00169-001-s672><capture.nehmen><de> Nehmen Sie mit Fünf Clip -Station ist eine unserer handgefertigten PANDORA -Armband, das aus massivem Sterling -Silber gefertigt ist .
<G-vec00169-001-s673><capture.nehmen><en> Designed for action cameras and drones: shoot video at up to 30 frames per second in 4K or capture HD footage at 240 frames per second on your GoPro®, action camera or drone to preserve every second of your latest adventure.
<G-vec00169-001-s673><capture.nehmen><de> Für Action-Kameras und Drohnen konzipiert: Drehen Sie Videos mit bis zu 30 Bildern pro Sekunde in 4k-Auflösung oder nehmen Sie HD-Videos mit Ihrer GoPro, Action-Kamera oder Drohne mit 240 Bildern pro Sekunde auf, um jeden Moment Ihres neuesten Abenteuers zu bewahren.
<G-vec00169-001-s674><capture.nehmen><en> Mount VIRB to your helmet and capture your entire adventure.
<G-vec00169-001-s674><capture.nehmen><de> Befestigen Sie die VIRB an Ihrem Helm, und nehmen Sie Ihr gesamtes Abenteuer auf.
<G-vec00169-001-s675><capture.nehmen><en> Having burnt their fingers in their attempt at a frontal attack on Moscow last year, the Germans planned to capture Moscow this year by a flanking movement and to end the war in the East in that way.
<G-vec00169-001-s675><capture.nehmen><de> Nachdem die Deutschen sich im vorigen Jahr bei dem Frontalstoß gegen Moskau die Finger verbrannt hatten, beabsichtigten sie in diesem Jahre, Moskau nunmehr durch ein Umgehungsmanöver zu nehmen und damit den Krieg im Osten zu beenden.
<G-vec00169-001-s676><capture.nehmen><en> The two sensors with 13-mexapixel (f/2.0) and 5-megapixel (f/2.2) support autofocus and capture videos with up to 720p.
<G-vec00169-001-s676><capture.nehmen><de> Die beiden Sensoren mit 13-Megapixel (f/2,0) und 5 Megapixel (f/2,2) unterstÃ1⁄4tzen Autofokus und nehmen Videos mit bis zu 720p auf.
<G-vec00169-001-s677><capture.nehmen><en> Capture the flavor of Jamaica while strolling through this tropical paradise.
<G-vec00169-001-s677><capture.nehmen><de> Nehmen Sie den Geschmack von Jamaika wahr, während Sie durch dieses tropische Paradies schlendern.
<G-vec00169-001-s678><capture.nehmen><en> Customizable buttons enhance productivity Quickly launch OneNote by clicking the top button and write notes (even on a locked screen), capture a screenshot, or activate Cortana.
<G-vec00169-001-s678><capture.nehmen><de> Rufen Sie durch Betätigen der oberen Taste schnell OneNote auf und schreiben Sie Notizen (sogar auf einem gesperrten Bildschirm), nehmen Sie einen Screenshot auf oder aktivieren Sie Cortana.
<G-vec00169-001-s679><capture.nehmen><en> Dukhs, having seen the uselessness of their attempts to capture him alive, withdrew.
<G-vec00169-001-s679><capture.nehmen><de> Die Afghanen erkannten die Vergeblichkeit ihres Versuches, ihn lebendig zu nehmen, und zogen sich zurück.
<G-vec00169-001-s680><capture.nehmen><en> On the same day, Slobodan Jakovljevic and his co-defendants allegedly conducted patrols on the road and set up ambushes to intercept the column of Bosniaks and capture the men trying to reach the territory under the control of the Army of Republic of Bosnia-Herzegovina (BiH).
<G-vec00169-001-s680><capture.nehmen><de> Am selben Tag sollen Slobodan Jakovljevic und seine Mitangeklagten auf der Straße patrouilliert und Hinterhalte aufgestellt haben, um die bosnische Kolonne abzufangen und jene Männer gefangen zu nehmen, die versuchten, das von der Armee der Republik Bosnien-Herzegowina kontrollierte Gebiet zu erreichen.
<G-vec00169-001-s681><capture.nehmen><en> Impressive voices capture every listener and give your project that certain something.
<G-vec00169-001-s681><capture.nehmen><de> Eindrucksvolle Stimmen nehmen jeden Zuhörer gefangen und verleihen deinem Projekt das gewisse Etwas.
<G-vec00169-001-s682><capture.nehmen><en> Other phones, however, only show what is in the middle of the image, but will capture more than the viewfinder shows.
<G-vec00169-001-s682><capture.nehmen><de> Andere Telefone zeigen jedoch nur das, was in der Mitte des Bilds ist, nehmen aber mehr auf, als im Sucher angezeigt wird.
<G-vec00169-001-s683><capture.nehmen><en> You cannot capture the 7 or the jack because the 6 is missing from the sequence.
<G-vec00169-001-s683><capture.nehmen><de> Man kann weder die 7 noch den B nehmen, weil die 6 in der Folge fehlt.
<G-vec00169-001-s684><capture.nehmen><en> Capture sufficient photographs of the natural wonder and then relax during the journey back to your original departure point in Reykjavik.
<G-vec00169-001-s684><capture.nehmen><de> Nehmen Sie genügend Fotos vom Naturwunder auf und entspannen Sie sich dann auf der Rückfahrt zu Ihrem ursprünglichen Ausgangspunkt in Reykjavik.
<G-vec00169-001-s685><capture.nehmen><en> British troops capture German trenches within hours of the explosions and consolidate their control over key battlefield positions in subsequent days.
<G-vec00169-001-s685><capture.nehmen><de> Britische Truppen nehmen die deutschen Schützengräben innerhalb von Stunden ein und konsolidieren in den nächsten Tagen ihre Kontrolle über wichtige Positionen auf dem Schlachtfeld.
<G-vec00169-001-s686><capture.nehmen><en> "Black's group above has indeed one eye; but in contrast to the general experience with ""me ari me nashi"" he will not be able to capture White's eyeless group below."
<G-vec00169-001-s686><capture.nehmen><de> "Die schwarze Gruppe rechts oben besitzt zwar ein Auge, wird jedoch die augenlose weiße Gruppe ganz im Gegensatz zur sonstigen Erfahrung mit ""me ari me nashi"" nicht vom Brett nehmen können."
<G-vec00169-001-s687><capture.nehmen><en> In fact, however, all electrons participate in the momentum transfer (owing to their motion in an atom) and capture from a -quantum a part of energy (because they are bound in the atomic coordinate system).
<G-vec00169-001-s687><capture.nehmen><de> In der Tat beteiligen sich alle Elektronen an der Impulsübertragung infolge ihrer Bewegung im Atom und nehmen dem Gamma-Quant einen Teil von Energie ab, weil sie im Atomsystem gebunden waren.
<G-vec00169-001-s688><capture.schlagen><en> While some investors choose to stay out of trading at this time, others are keen to capture breakouts in this volatility, and so reap greater profits.
<G-vec00169-001-s688><capture.schlagen><de> Zwar ziehen es einige Investoren vor, sich zu dieser Zeit vom Trading zurückzuziehen, aber andere wiederum wollen aus der Volatilität Profit schlagen.
<G-vec00169-001-s689><capture.schlagen><en> 4.3. Except as provided in Article 4.2, if the player having the move deliberately touches on the chessboard (a) one or more pieces of the same colour, he must move or capture the first piece touched that can be moved or captured, or (b) one piece of each colour, he must capture the opponent's piece with his piece or, if this is illegal, move or capture the first piece touched which can be moved or captured.
<G-vec00169-001-s689><capture.schlagen><de> 4.3 Berührt der Spieler, der am Zug ist, den Fall von Artikel 4.2 ausgenommen, absichtlich auf dem Brett (a) eine oder mehrere Figuren derselben Farbe, muss er die erste berührte Figur ziehen oder schlagen, welche gezogen oder geschlagen werden kann; oder (b) eine Figur jeder Farbe, muss er die gegnerische Figur mit seiner Figur schlagen oder, wenn dies nicht erlaubt ist, die erste berührte Figur ziehen oder schlagen, die gezogen oder geschlagen werden kann.
<G-vec00169-001-s692><capture.schlagen><en> B 27: Second possibility for Black is to capture the three white stones.
<G-vec00169-001-s692><capture.schlagen><de> S 27: Als zweite Möglichkeit bleibt Schwarz das Schlagen der drei weißen Steine.
<G-vec00169-001-s693><capture.schlagen><en> They can never move or capture backwards.
<G-vec00169-001-s693><capture.schlagen><de> Sie können sich niemals rückwärts bewegen oder rückwärts schlagen.
<G-vec00169-001-s694><capture.schlagen><en> Ignoring questions of Sente, in the Igo Hatsuyoron problem, White's capture of 20 stones costs her about 25 points locally.
<G-vec00169-001-s694><capture.schlagen><de> Lässt man Fragen von Vorhand und Nachhand außer Betracht, so kostet Weiß das Schlagen der 20 schwarzen Steine lokal um die 25 Punkte.
<G-vec00169-001-s695><capture.schlagen><en> [see variation] B 139: Black cannot capture the three White stones, because his earlier played marked stone took his centre group a liberty.
<G-vec00169-001-s695><capture.schlagen><de> [zur Variante] S 139: Schwarz darf die drei weißen Steine nicht schlagen, da sein früher gespielter markierter Stein seiner Zentrumsgruppe eine Freiheit genommen hat.
<G-vec00169-001-s696><capture.schlagen><en> Styria - a paradise for gourmets The landscape of Styria with its rolling hills and rugged mountain valleys can capture the hearts of nature lover higher.
<G-vec00169-001-s696><capture.schlagen><de> Die Steiermark – ein Paradies für Genießer Die Landschaft der Steiermark mit ihrer sanften Hügeln und wilden Bergtälern lässt das Herz jedes Naturliebhabers höher schlagen.
<G-vec00169-001-s697><capture.schlagen><en> The simplest measure for Black now is to capture the three White stones.
<G-vec00169-001-s697><capture.schlagen><de> Die einfachste Option für Schwarz ist nunmehr, die drei weißen Steine zu schlagen.
<G-vec00169-001-s698><capture.schlagen><en> A bishop can move and capture diagonally for any distance.
<G-vec00169-001-s698><capture.schlagen><de> Ein Läufer kann über eine beliebige Entfernung diagonal ziehen oder schlagen.
<G-vec00169-001-s699><capture.schlagen><en> [see variation] B 27: Black has to run for the life of his group with 27, as he is unable to capture the three White stones instead.
<G-vec00169-001-s699><capture.schlagen><de> [zur Variante] S 27: Schwarz muss mit 27 um das Leben seiner Gruppe rennen, da es ihm nicht möglich ist, stattdessen die drei weißen Steine zu schlagen.
<G-vec00169-001-s700><capture.schlagen><en> "White cannot safely capture the single ""external"" black stone with White 1."
<G-vec00169-001-s700><capture.schlagen><de> "Weiß kann den einzelnen ""externen"" schwarzen Stein nicht sicher mit 1 schlagen."
<G-vec00169-001-s701><capture.schlagen><en> After that it can move 1 square forward vertically to an empty square, or move 1 square forward diagonally to capture the opponent piece on that square.
<G-vec00169-001-s701><capture.schlagen><de> Anschließend kann er ein Quadrat senkrecht vorwärts auf ein leeres Quadrat ziehen oder ein Quadrat diagonal vorwärts, um die gegnerische Spielfigur auf diesem Quadrat zu schlagen.
<G-vec00169-001-s702><capture.schlagen><en> "Stones are said to be ""alive"" if they cannot be captured by the opponent, or if capturing them would enable a new stone to be played that the opponent could not capture."
<G-vec00169-001-s702><capture.schlagen><de> Steine werden als lebend bezeichnet, wenn sie vom Gegner nicht geschlagen werden können, oder wenn durch das Schlagen ein neuer Stein gesetzt werden kann, den der Gegner nicht schlagen kann.
<G-vec00169-001-s703><capture.schlagen><en> What we do not know with certainty is, 1.: if this Ko capture would be an option for White to win the game and 2.: - in addition - if White could afford not to resolve the Ko on the left with a second move there.
<G-vec00169-001-s703><capture.schlagen><de> Was wir jedoch nicht mit Sicherheit wissen ist, 1.: ob das Schlagen des Ko eine Option für Weiß wäre, die Partie zu gewinnen und 2.: - zusätzlich- inwieweit es sich Weiß leisten könnte, das Ko auch abschließend aufzulösen.
<G-vec00169-001-s704><capture.schlagen><en> A Mouse may not capture an Elephant or another Mouse on land directly from the River.
<G-vec00169-001-s704><capture.schlagen><de> Eine Maus im Fluss darf den gegnerischen Elefanten oder die gegnerische Maus an Land nicht schlagen.
<G-vec00569-002-s639><capture.(sich)_nehmen><en> You can capture 16 channels plus the main mix in high-resolution, 24-bit WAV format to SD card, USB drive, or direct to your Mac® or PC.
<G-vec00569-002-s639><capture.(sich)_nehmen><de> Nehmen Sie 16 Kanäle sowie die Stereo-Abmischung im WAV-Format (24 Bit) auf SD-Karte oder einen USB-Datenträger auf oder übertragen Sie diese Signale direkt zu Ihrem PC oder PC.
<G-vec00569-002-s640><capture.(sich)_nehmen><en> “Since an IS-BE cannot be “killed”, the objective has been to capture and immobilize IS-BEs.
<G-vec00569-002-s640><capture.(sich)_nehmen><de> Da ein IS-BE nicht „getötet“ werden kann, war das Ziel, IS-BEs gefangen zu nehmen und sie unbeweglich zu machen.
<G-vec00569-002-s641><capture.(sich)_nehmen><en> Sensors capture any remaining impulses, conveying them to the HAL system.
<G-vec00569-002-s641><capture.(sich)_nehmen><de> Sensoren nehmen die verbliebenen Restimpulse des Patienten auf und leiten diese an das HAL-System weiter.
<G-vec00569-002-s642><capture.(sich)_nehmen><en> Free professional HD quality camera and video capture.
<G-vec00569-002-s642><capture.(sich)_nehmen><de> Nehmen Sie professionelle Fotos in hoher Auflösung, HD-Qualität.
<G-vec00569-002-s643><capture.(sich)_nehmen><en> Simply capture the scene, review the image and touch the part of the photo you’d like to be pin sharp.
<G-vec00569-002-s643><capture.(sich)_nehmen><de> Nehmen Sie die Szene einfach auf, sehen Sie sich das Bild an und berühren Sie den Teil des Fotos, der gestochen scharf dargestellt werden soll.
<G-vec00569-002-s644><capture.(sich)_nehmen><en> And now, without the Cygnus, we have more space for the risky capture of the incoming large APP module.
<G-vec00569-002-s644><capture.(sich)_nehmen><de> Und jetzt haben wir dann auch mehr Platz um das sehr große APP-Modul in Empfang zu nehmen.
<G-vec00569-002-s646><capture.(sich)_nehmen><en> During a scan, you can easily capture images and video clips using a footswitch.
<G-vec00569-002-s646><capture.(sich)_nehmen><de> Während einer Untersuchung nehmen Sie Bilder und Videosequenzen ganz einfach über einen Fußschalter auf.
<G-vec00569-002-s647><capture.(sich)_nehmen><en> With Time-lapse Capture, shoot stills of a scene over a period of time with a chosen interval between each shot and edit the sequence into a high-quality 4K time-lapse movie.
<G-vec00569-002-s647><capture.(sich)_nehmen><de> Nehmen Sie mit der Zeitraffer-Erfassung Fotos einer Szene über einen Zeitraum mit einem festgelegten Intervall zwischen den einzelnen Aufnahmen auf, und verarbeiten Sie die Sequenz zu einem hochwertigen 4K-Film im Zeitraffer.
<G-vec00569-002-s648><capture.(sich)_nehmen><en> Latest newer versions of digital camera models can capture videos, sound and images with a high level of accuracy and efficiency.
<G-vec00569-002-s648><capture.(sich)_nehmen><de> Die letzten neueren Versionen von Digitalkameras nehmen Videos, Ton und Bilder mit hoher Genauigkeit und Effizienz auf.
<G-vec00569-002-s649><capture.(sich)_nehmen><en> 1862 – American Civil War: Battle of Memphis: Union forces capture Memphis, Tennessee, from the Confederates.
<G-vec00569-002-s649><capture.(sich)_nehmen><de> 1862: Im Amerikanischen Bürgerkrieg nehmen die Truppen der Nordstaaten Memphis in Tennessee ein.
<G-vec00569-002-s650><capture.(sich)_nehmen><en> The Globe and Mail reporters and videographers capture footage on location or in their newsroom studio using as many as four cameras shooting simultaneously.
<G-vec00569-002-s650><capture.(sich)_nehmen><de> Die Reporter und Videofilmer bei Globe and Mail nehmen ihr Material vor Ort oder im Nachrichtenstudio auf, wobei bis zu vier Kameras gleichzeitig eingesetzt werden.
<G-vec00569-002-s651><capture.(sich)_nehmen><en> Fett befriended Luke Skywalker on Panna, and nearly got the location of the new Rebel base out of him, but he was forced to retreat, and failed even to capture the young Jedi.
<G-vec00569-002-s651><capture.(sich)_nehmen><de> Zwar war es Kopatha in der Zwischenzeit gelungen, Han Solo gefangen zu nehmen, doch konnte dieser wieder entwischen, ohne dass Kopatha den Standort der Rebellen-Flotte erfahren hatte.
<G-vec00569-002-s652><capture.(sich)_nehmen><en> If you play a capturing card as an action of type 1 or 5 (capture or discard), but fail to take all the cards you are entitled to capture, any opponent can insist (if they wish) that you capture all the cards that it is legal for you to take.
<G-vec00569-002-s652><capture.(sich)_nehmen><de> Wenn Sie eine gewinnende Karte als Aktion des Typs 1 oder 5 spielen (Gewinnen oder Ablegen), jedoch nicht alle Karten vom Tisch nehmen, zu denen Sie berechtigt sind, kann jeder Gegner verlangen (wenn er dies möchte), dass Sie alle Karten vom Tisch nehmen, zu denen Sie nach den Regeln berechtigt sind.
<G-vec00569-002-s653><capture.(sich)_nehmen><en> You cannot capture the 7 or the jack because the 6 is missing from the sequence.
<G-vec00569-002-s653><capture.(sich)_nehmen><de> Man kann weder die 7 noch den B nehmen, weil die 6 in der Folge fehlt.
<G-vec00569-002-s654><capture.(sich)_nehmen><en> And if you ever have a carelessness to capture a captive, then either drag him to the HQ yourselves or noislessly finish him off at place.
<G-vec00569-002-s654><capture.(sich)_nehmen><de> Und solltet ihr so unvorsichtig sein und noch irgendjemanden in Gefangenschaft nehmen, dann schleppt ihn selbst in den Stab der Brigade oder erledigt ihn leise an Ort und Stelle.
<G-vec00569-002-s655><capture.(sich)_nehmen><en> Simply capture a Guide signal with the right timing, capture a Dub signal to be aligned, press one button, and a new aligned Dub is generated and returned to your DAW. Main Features
<G-vec00569-002-s655><capture.(sich)_nehmen><de> Sie nehmen einfach ein "Guide Signal" mit dem korrekten Timing als Referenz auf, dann das eigentliche "Dub Signal", welches angepasst werden muss, drücken einen Knopf und eine neue angepasste "Dub-Spur" wird in ihrer DAW erzeugt.
<G-vec00569-002-s656><capture.(sich)_nehmen><en> Perfect for gear-mounted shots, you can power the camera on/off, adjust settings, start/stop recording and capture photos.
<G-vec00569-002-s656><capture.(sich)_nehmen><de> Damit schalten Sie die Kamera ein und aus, passen Einstellungen an, starten und stoppen die Aufzeichnung und nehmen Fotos auf - Damit ist sie ideal für Aufnahmen, wenn Ihre GoPro an Ihrer Ausrüstung montiert ist.
<G-vec00569-002-s657><capture.(sich)_nehmen><en> Their sole purpose was to capture Jerusalem for the pope so that he could reign from there.
<G-vec00569-002-s657><capture.(sich)_nehmen><de> Der einzige Zweck dieser Unternehmungen besteht für den Papst darin, Jerusalem in Besitz zu nehmen, um von dort aus regieren zu können.
<G-vec00569-002-s658><capture.nehmen><en> Capture the lovely landscaped garden at Chateau-sur-Mer and if weather permits, take a brief walk at Fort Adams.Enjoy this fully narrated bus tour with details on residences of prominent people such as the Watts Sherman House, Kingscote, McCauley Hall and Belcourt Castle.
<G-vec00569-002-s658><capture.nehmen><de> Nehmen Sie den schönen Landschaftsgarten von Chateau-sur-Mer und wenn das Wetter es zulässt, unternehmen Sie einen kurzen Spaziergang im Fort Adams.
<G-vec00569-002-s659><capture.nehmen><en> Capture a game-winning goal from the far end of the soccer field, or a band rocking out even from the back row.
<G-vec00569-002-s659><capture.nehmen><de> Nehmen Sie das Siegertor vom anderen Ende des Fußballplatzes oder eine Band auf der Bühne von der letzten Reihe auf.
<G-vec00569-002-s660><capture.nehmen><en> Select which screen or segment of your screen you’d like to record, turn on your webcam, and capture video and audio simultaneously.
<G-vec00569-002-s660><capture.nehmen><de> Wählen Sie aus, welchen Bildschirm oder welchen Bereich des Bildschirms Sie aufnehmen möchten, schalten Sie die Webcam ein und nehmen Sie Bild und Ton gleichzeitig auf.
<G-vec00569-002-s661><capture.nehmen><en> Capture unforgettable images of the park’s soaring rock walls and craggy peaks then enjoy an invigorating hike to Yosemite Falls or Bridalveil Falls, where high-mountain rivers tumble from sheer granite cliffs.
<G-vec00569-002-s661><capture.nehmen><de> Nehmen Sie unvergessliche Bilder von den hoch aufragenden Felswänden und zerklüfteten Gipfeln des Parks auf und wandern Sie zu den Yosemite Falls oder Bridalveil Falls, wo Hochgebirgsflüsse von schroffen Granitfelsen stürzen.
<G-vec00569-002-s662><capture.nehmen><en> Capture fantastic photographs of alligators in their natural habitat, and relish the intimate atmosphere of a small-group, limited to only 6 passengers.
<G-vec00569-002-s662><capture.nehmen><de> Nehmen Sie fantastische Fotografien von Alligatoren in ihrem natürlichen Lebensraum auf und genießen Sie die intime Atmosphäre einer kleinen Gruppe mit nur 6 Passagieren.
<G-vec00569-002-s663><capture.nehmen><en> Capture exceptional detail, even indoors and without a flash, with a back-illuminated Exmor R® sensor.
<G-vec00569-002-s663><capture.nehmen><de> Nehmen Sie dank rückwärtig beleuchtetem EXMOR R® Sensor äußerst detailreiche Bilder auf – selbst in Innenräumen und ohne Blitz.
<G-vec00569-002-s664><capture.nehmen><en> Capture sounds using the AUX Input and play them back from the keyboard.
<G-vec00569-002-s664><capture.nehmen><de> Nehmen Sie Sounds über den AUX Eingang auf und spielen Sie sie über Ihr Keyboard wieder ab.
<G-vec00569-002-s665><capture.nehmen><en> Capture up to 1,110 still images and up to 80 minutes of movie footage³ on a single charge of the ultra-compact and lightweight lithium-ion rechargeable EN-EL15 battery.
<G-vec00569-002-s665><capture.nehmen><de> Nehmen Sie bis zu 1.110 Fotos oder Videos mit einer Länge bis zu 80 Minuten³ mit nur einer Akkuladung des leichten Lithium-Ionen-Akkus EN-EL15 auf.
<G-vec00569-002-s667><capture.nehmen><en> Capture your happy times with BoothCool.
<G-vec00569-002-s667><capture.nehmen><de> Nehmen Sie Ihre glücklichen Zeiten mit BoothCool gefangen.
<G-vec00569-002-s668><capture.nehmen><en> Capture perfectly synced video from multiple cameras with new MultiCam Capture.
<G-vec00569-002-s668><capture.nehmen><de> Nehmen Sie mit dem neuen MultiCam Capture mehrere Geräte gleichzeitig auf.
<G-vec00569-002-s669><capture.nehmen><en> Simply capture various objects and structures immediately in color from different angles.
<G-vec00569-002-s669><capture.nehmen><de> Nehmen Sie verschiedenste Objekte und Strukturen in kürzester Zeit aus unterschiedlichen Winkeln in Farbe auf.
<G-vec00569-002-s670><capture.nehmen><en> Capture the enchanting charm of these luxurious wedding dresses 2014 from Tbdress.
<G-vec00569-002-s670><capture.nehmen><de> Nehmen Sie das zauberhaften Charme der luxuriösen Hochzeitskleider 2014 von Tbdress .
<G-vec00569-002-s671><capture.nehmen><en> Capture the night sky in a whole new way.
<G-vec00569-002-s671><capture.nehmen><de> Nehmen Sie den Nachthimmel auf ganz neue Weise auf.
<G-vec00569-002-s672><capture.nehmen><en> Recording tools Capture program activity to show off your software, grab screenshots of important diagrams and statistics.
<G-vec00569-002-s672><capture.nehmen><de> Aufnahme-Tools Nehmen Sie Programmaktivität auf, um Ihre Software zu zeigen, machen Sie Screenshots von wichtigen Grafiken und Statistiken.
<G-vec00569-002-s673><capture.nehmen><en> Capture footage from your Mac screen at up to 60 fps, or reduce the output file size by capturing at 5-10 fps.
<G-vec00569-002-s673><capture.nehmen><de> Nehmen Sie Videos mit bis zu 60 fps auf oder stellen Sie die Bildrate auf bis zu 5 fps ein, um die Dateigröße zu reduzieren.
<G-vec00569-002-s675><capture.nehmen><en> Capture HD MP4 movies in the best way using this site which is any user's ideal choice.
<G-vec00569-002-s675><capture.nehmen><de> Nehmen Sie MP4-Filme in HD in der besten Weise mit dieser Webseite auf, nämlich die ideale Wahl des beliebigen Benutzers.
<G-vec00956-002-s297><capture.erfassen><en> DoubleClick, DoubleClick Bid Manager, DoubleClick Floodlight and DoubleClick Spotlight: DoubleClick, DoubleClick Floodlight and DoubleClick Spotlight allow us to capture and report on the actions of users who visit our website after viewing or clicking on one of our paid search ads.
<G-vec00956-002-s297><capture.erfassen><de> DoubleClick, DoubleClick Bid Manager, DoubleClick Floodlight und DoubleClick Spotlight: DoubleClick, DoubleClick Floodlight und DoubleClick Spotlight erlauben es uns, die Aktionen von Benutzern, die unsere Website besuchen, zu erfassen und darüber zu berichten, nachdem sie eine unserer bezahlten Suchanzeigen angesehen oder angeklickt haben.
<G-vec00956-002-s298><capture.erfassen><en> Automatically capture and analyze print file information from all print jobs.
<G-vec00956-002-s298><capture.erfassen><de> Erfassen und analysieren Sie die Druckdateidaten für alle Druckaufträge automatisch.
<G-vec00956-002-s299><capture.erfassen><en> Due to the large measurement volume and the possibility to capture detail scans at different locations of large parts without repositioning the laser tracker, the scanning process becomes extremely comfortable and time-saving.
<G-vec00956-002-s299><capture.erfassen><de> Durch das große Messvolumen und die Möglichkeit, Detailscans an verschiedensten Stellen großer Bauteile von der selben Trackerposition aus zu erfassen, wird ein besonders komfortables und zeitsparendes Arbeiten ermöglicht.
<G-vec00956-002-s300><capture.erfassen><en> The approach, therefore, is to visit different areas of your existing website where Quick View is implemented, trigger the Quick View, and capture the Ajax URL sent by the web page for loading the Quick View data or content.
<G-vec00956-002-s300><capture.erfassen><de> Der Ansatz besteht daher darin, unterschiedliche Bereiche Ihrer vorhandenen Website aufzurufen, auf denen die Schnellansicht implementiert ist, die Schnellansicht auszulösen und die Ajax-URL zu erfassen, die durch die Webseite zum Laden der Schnellansichtsdaten oder -inhalte gesendet wurde.
<G-vec00956-002-s301><capture.erfassen><en> SMART Podium encourages participation by letting presenters capture and save their audience’s ideas, feedback and questions on the fly. Untethered freedom
<G-vec00956-002-s301><capture.erfassen><de> SMART Podium begünstigt die Teilnahme der Zuhörerschaft, denn der Vortragende kann die Ideen, das Feedback und die Fragen der Zuhörer unmittelbar erfassen und dokumentieren.
<G-vec00956-002-s302><capture.erfassen><en> Filter TS The Torque Sensors for Reaction Torque have four sensing elements with strain gauges to capture the moment between the inner and outer annulus.
<G-vec00956-002-s302><capture.erfassen><de> Filtern TS Die Drehmomentsensoren für Reaktionsmoment verfügen über vier Messelemente mit Dehnungsmessstreifen, um das Moment zwischen innerem und äußerem Kreisring zu erfassen.
<G-vec00956-002-s303><capture.erfassen><en> Turkish president Erdogan says operation to capture Al- Bab nearly complete.
<G-vec00956-002-s303><capture.erfassen><de> Der türkische Präsident Erdogan sagt, dass er Al-Bab fast vollständig erfassen sollte.
<G-vec00956-002-s304><capture.erfassen><en> The image on the necklace is perfectly clear, we just don't have fancy cameras to capture it.
<G-vec00956-002-s304><capture.erfassen><de> Das Bild auf die Kette ist ganz klar, wir haben einfach nicht Phantasie Kameras, es zu erfassen.
<G-vec00956-002-s305><capture.erfassen><en> With the Control Units on the other hand all connected function modules and handles of the EMKA Rack Management are configured and operated in order to capture all accesses to server racks and all operating states.
<G-vec00956-002-s305><capture.erfassen><de> Über die Control Units werden wiederum alle angeschlossenen Funktionsmodule und Griffe des EMKA Rack Managements konfiguriert und bedient, um alle Zugriffe auf Serverschränke und alle Betriebszustände zu erfassen.
<G-vec00956-002-s306><capture.erfassen><en> At airport perimeters, PTZ cameras capture persons approaching or attempting to climb the fences at any time of the day or night.
<G-vec00956-002-s306><capture.erfassen><de> Zusätzlich erfassen PTZ Kameras jederzeit Personen, die sich Zäunen nähern oder versuchen, über Zäune zu klettern.
<G-vec00956-002-s307><capture.erfassen><en> A cell phone reading mode, activated with either a push of a button or a host terminal software command optimizes light levels to capture images or read bar codes from mobile phones or PDAs.
<G-vec00956-002-s307><capture.erfassen><de> Ein Handy-Modus, der entweder auf Knopfdruck oder durch einen Softwarebefehl des Host-Terminals ausgelöst wird, kann Bilder oder Barcodes von Mobiltelefonen und PDAs erfassen.
<G-vec00956-002-s308><capture.erfassen><en> Online booking systems also make it easier to capture data for accounting and evaluation.
<G-vec00956-002-s308><capture.erfassen><de> Auch das Erfassen von Daten zur Abrechnung und Auswertung wird durch Online-Buchungssysteme viel einfacher.
<G-vec00956-002-s309><capture.erfassen><en> It serves to capture your personal work and leisuretimes and clearly recycle.
<G-vec00956-002-s309><capture.erfassen><de> Sie dient dazu Ihre persönlichen Arbeits-und Freizeiten zu erfassen und übersichtlich aufzubereiten.
<G-vec00956-002-s310><capture.erfassen><en> We are developing new technologies like our µTAS biochip that can check a person's health from his or her saliva; a broad-waveband CIGS image sensor that can capture imagery from inside the human body without affecting it; a wearable pulse sensor to monitor health anywhere and anytime; an ultraviolet sensor to detect harmful UV radiation; and more.
<G-vec00956-002-s310><capture.erfassen><de> Wir entwickeln neue Technologien wie unseren µTAS-Biochip, der den Zustand einer Patienten über dessen Speichel überprüfen kann, einen CIGS-Bildsensor mit breitem Wellenbereich, der Bilder aus dem Inneren des menschlichen Körpers erfassen kann, ohne diesen zu beeinflussen, einen tragbaren Pulssensor, mit dem das Befinden jederzeit und überall überwacht werden kann und einen UV-Sensor zur Erkennung schädlicher UV-Strahlung usw.
<G-vec00956-002-s311><capture.erfassen><en> 180 of our Asian-based suppliers audited to capture and enhance their sustainability and EHS performance.
<G-vec00956-002-s311><capture.erfassen><de> 180 unserer asiatischen-basierte Lieferanten werden geprüft, um ihre Nachhaltigkeit zu erfassen und zu verbessern.
<G-vec00956-002-s312><capture.erfassen><en> The adaptive form uses various components and rules to capture details and adapts to user responses.
<G-vec00956-002-s312><capture.erfassen><de> Es verwendet verschiedene adaptive Formularkomponenten, um Eingaben zu erfassen und sich an Benutzerreaktionen anzupassen.
<G-vec00956-002-s313><capture.erfassen><en> The motion sensor and Face Recognition function automatically capture faces at parties.
<G-vec00956-002-s313><capture.erfassen><de> Der Bewegungssensor und die Gesichtserkennung erfassen automatisch die Gesichter auf Partys.
<G-vec00956-002-s314><capture.erfassen><en> Netigate's API can easily be integrated with your CRM, such as Salesforce to capture survey results and data.
<G-vec00956-002-s314><capture.erfassen><de> Netigates API kann einfach in Ihr CRM integriert werden, wie zum Beispiel Salesforce, um Umfrageergebnisse und Daten zu erfassen.
<G-vec00956-002-s315><capture.erfassen><en> Also it can help you capture the screenshot when you meet the pictures you like and share them with your friends.
<G-vec00956-002-s315><capture.erfassen><de> Auch kann es Ihnen helfen, den Screenshot zu erfassen, wenn Sie die Bilder kennen, die Sie mögen und teilen Sie sie mit Ihren Freunden.
<G-vec00956-002-s316><capture.erfassen><en> Help optimize selling opportunities and capture new leads by improving cross-sell and up-sell opportunities.
<G-vec00956-002-s316><capture.erfassen><de> Ermöglichen Sie die Optimierung von Verkaufschancen und erfassen Sie neue Leads durch die Verbesserung von Cross-Selling- und Up-Selling-Möglichkeiten.
<G-vec00956-002-s317><capture.erfassen><en> Extreme Bike Trials - Capture screen, annotate, and share your edited screenshots.
<G-vec00956-002-s317><capture.erfassen><de> CapShare - Erfassen Sie alles auf Ihrem Bildschirm und teilen Sie es auf Facebook mit einem Klick.
<G-vec00956-002-s318><capture.erfassen><en> Capture business documents using your smartphone with the KODAK Info Activate Solution Mobile App.
<G-vec00956-002-s318><capture.erfassen><de> Erfassen Sie geschäftliche Dokumente mit Ihrem Smartphone und der KODAK Info Activate Solution Mobile App.
<G-vec00956-002-s319><capture.erfassen><en> Upload the meeting’s documents, create and revise sketches together on an intuitive whiteboard, and capture conversation notes — everything is then conveniently prepared for automatic email delivery at the end of the session.
<G-vec00956-002-s319><capture.erfassen><de> Laden Sie bereits im Vorfeld sitzungsrelevante Dokumente hoch, erstellen Sie während der Sitzung gemeinsam eine Skizze auf dem intuitiven Whiteboard oder erfassen Sie Gesprächsnotizen - alles für den automatischen Email-Versand am Ende der Sitzung.
<G-vec00956-002-s322><capture.erfassen><en> Capture your built-in iSight as Picture-in-Picture movie, with you commenting the scenes.
<G-vec00956-002-s322><capture.erfassen><de> Erfassen Sie Ihre integrierten iSight als Picture-in-Picture-Film, mit Ihnen die Szenen zu kommentieren.
<G-vec00956-002-s323><capture.erfassen><en> Immerse – click – read out: Capture the surfactant content of your cleaning bath within seconds using surface tension with our Bubble Pressure Tensiometer – BPT Mobile.
<G-vec00956-002-s323><capture.erfassen><de> Eintauchen – klicken – ablesen: Erfassen Sie den Tensidgehalt Ihres Reinigungsbades in Sekunden mit unserem Bubble Pressure Tensiometer – BPT Mobile.
<G-vec00956-002-s324><capture.erfassen><en> Capture anything playing on your PC.
<G-vec00956-002-s324><capture.erfassen><de> Erfassen Sie alles auf Ihrem PC spielen.
<G-vec00956-002-s325><capture.erfassen><en> Capture receipts, VAT, categories and more on the mobile app.
<G-vec00956-002-s325><capture.erfassen><de> Erfassen Sie Belege, Mehrwertsteuer, Kategorien und mehr direkt in der mobilen App.
<G-vec00956-002-s326><capture.erfassen><en> Record your screen and capture video from multiple cameras.
<G-vec00956-002-s326><capture.erfassen><de> Nehmen Sie den Bildschirm auf und erfassen Sie Videos von mehreren Kameras.
<G-vec00956-002-s327><capture.erfassen><en> Description Capture your billing data with the powerful, compact MID approved 120.
<G-vec00956-002-s327><capture.erfassen><de> Beschreibung Erfassen Sie Ihre Fakturierungsdaten mit dem leistungsfähigen, kompakten 120 mit MID Zulassung.
<G-vec00956-002-s328><capture.erfassen><en> Debug Snapshot Capture the state of your application in production at a specific line location.
<G-vec00956-002-s328><capture.erfassen><de> Hiermit erfassen Sie in der Produktionsumgebung den Zustand Ihrer Anwendung an einer bestimmten Zeilenposition.
<G-vec00956-002-s329><capture.erfassen><en> Create depth, capture the expanse of a landscape, or use the ultra-wide angle perspective when shooting videos in confined spaces.
<G-vec00956-002-s329><capture.erfassen><de> Schaffen Sie Tiefe, erfassen Sie die Weite einer Landschaft oder nutzen Sie die Ultraweitwinkel-Perspektive, wenn Sie Videos in engen Räumen aufnehmen.
<G-vec00956-002-s330><capture.erfassen><en> Import and capture music from virtually any source, including CDs, LPs, tapes, and the web
<G-vec00956-002-s330><capture.erfassen><de> Importieren und erfassen Sie Musik von Quellen wie CDs, LPs, Tonbändern, dem Internet usw.
<G-vec00956-002-s331><capture.erfassen><en> Description Capture your thoughts, discoveries, and ideas with OneNote, your very own digital notebook.
<G-vec00956-002-s331><capture.erfassen><de> Beschreibung Erfassen Sie Ihre Gedanken, Erkenntnisse und Ideen mit OneNote, Ihrem ganz persönlichen, digitalen Notizbuch.
<G-vec00956-002-s332><capture.erfassen><en> Capture the unique beauty of this amazing national park.
<G-vec00956-002-s332><capture.erfassen><de> Erfassen Sie die einzigartige Schönheit dieses erstaunlichen Nationalparks.
<G-vec00956-002-s335><capture.erfassen><en> Proprietary device and camera streaming accelerates image capture rate and simultaneously transfers images to memory during acquisition, capturing dynamic cellular events in applications such as live cell/kinetic imaging.
<G-vec00956-002-s335><capture.erfassen><de> Das firmeneigene Geräte- und Kamerastreaming beschleunigt die Bilderfassungsrate und überträgt während der Erfassung simultan Bilder auf den Speicher, wodurch dynamische zelluläre Ereignisse in Anwendungen wie kinetischem oder Lebendzell-Imaging erfasst werden.
<G-vec00956-002-s336><capture.erfassen><en> The developers of the open-ended RPG The Witcher 3: Wild Hunt describe their bold creation as a “morally indifferent” fantasy world, but this fails to capture the gravity of the claim.
<G-vec00956-002-s336><capture.erfassen><de> Die Entwickler des Open-World-RPG The Witcher 3: Wild Hunt beschreiben ihr waghalsiges Werk als „moralisch abgestumpfte” Fantasiewelt, doch das erfasst es eigentlich nicht so ganz.
<G-vec00956-002-s337><capture.erfassen><en> If you are unlucky enough to be hit twice in a row then the dash cam would automatically record again and capture both events.
<G-vec00956-002-s337><capture.erfassen><de> Haben Sie das Pech, dass Ihr Fahrzeug zweimal hintereinander angestoßen wird, zeichnet die Dashcam auch dies wieder automatisch auf und erfasst beide Vorfälle.
<G-vec00956-002-s338><capture.erfassen><en> Logging can be helpful when you run into any issues, because logs note and capture information on how you use the app.
<G-vec00956-002-s338><capture.erfassen><de> Protokolle können bei Problemen hilfreich sein, da in Protokollen Informationen zur Verwendung der App aufgezeichnet und erfasst werden.
<G-vec00956-002-s339><capture.erfassen><en> The majority of companies specializing in behavioral targeting has taken the same, basic approach: One or more experts create a system of categories that capture any interesting phenomenon on the internet.
<G-vec00956-002-s339><capture.erfassen><de> Die Mehrheit der Unternehmen, die sich auf Behavioural Targeting spezialisiert haben, arbeiten nach dem gleichen Ansatz: Ein oder mehrere Experten definieren ein Kategoriensystem, mit dem alle relevanten Themen und Interessen im Internet erfasst werden sollen.
<G-vec00956-002-s340><capture.erfassen><en> AFI solution: Digital capture and automated processing of incoming order confirmations in SAP
<G-vec00956-002-s340><capture.erfassen><de> Die SAP Add-Ons sorgen dafür, dass eingehende Auftragsbestätigungen digital erfasst und transparent in SAP weiterverarbeitet werden.
<G-vec00956-002-s341><capture.erfassen><en> If this element has stylus capture and this property is true at the time of capture, this property remains true until stylus capture is lost and the stylus is not over its bounds. Touch, mouse, and ctlyOverProperty
<G-vec00956-002-s341><capture.erfassen><de> Wenn Mauseingaben von diesem Element erfasst werden und diese Eigenschaft zum Zeitpunkt der Erfassung true ist, gibt die Eigenschaft weiterhin true zurück, bis keine Erfassung von Mauseingaben mehr erfolgt und der Zeiger sich nicht mehr über den Begrenzungen befindet.
<G-vec00956-002-s342><capture.erfassen><en> Our current sensors capture the visible spectrum and near infrared from 360 to 960 nm.
<G-vec00956-002-s342><capture.erfassen><de> Unser aktuelles Sensorportfolio erfasst das sichtbare Spektrum und das nahe Infrarot von 360 bis 960 nm.
<G-vec00956-002-s343><capture.erfassen><en> In this year’s survey, we have introduced an additional category to capture ‘soft’ factors.
<G-vec00956-002-s343><capture.erfassen><de> Bei der diesjährigen Befragung haben wir eine zusätzliche Kategorie eingeführt, mit der „weiche“ Faktoren erfasst werden sollen.
<G-vec00956-002-s344><capture.erfassen><en> B Event Scan is an A to B trigger sequence that will trigger and capture burst event data of interest defined by the B Event setup menu.
<G-vec00956-002-s344><capture.erfassen><de> Die B-Ereignisabtastung ist eine Triggersequenz von A nach B, mit der bestimmte Burst-Ereignisdaten, die im Setup-Menü des B-Ereignisses definiert wurden, getriggert und erfasst werden.
<G-vec00956-002-s345><capture.erfassen><en> Nevertheless, pregnancy is not a phenomenon in the life of a woman and does not capture such a beautiful period of her life on film - this is stupid.
<G-vec00956-002-s345><capture.erfassen><de> Dennoch ist Schwangerschaft kein Phänomen im Leben einer Frau und erfasst eine so schöne Zeit ihres Lebens nicht auf Film - das ist dumm.
<G-vec00956-002-s346><capture.erfassen><en> This release extends the diversity of events that Session Recording can capture and provides centralized configuration of event logging policies.
<G-vec00956-002-s346><capture.erfassen><de> Dieses Release erweitert das Spektrum an Ereignissen, die mit der Sitzungsaufzeichnung erfasst werden können, und ermöglicht eine zentralisierte Konfiguration von Ereignisprotokollierungsrichtlinien.
<G-vec00956-002-s347><capture.erfassen><en> If some data has been streamed recently, yet content is not present in the client system, it indicates that the client integration did not fully capture it, and should be raised to client engineering.
<G-vec00956-002-s347><capture.erfassen><de> Wenn einige Daten kürzlich gestreamt wurden, der Inhalt jedoch nicht im Client-System vorhanden ist, weist dies darauf hin, dass die Client-Integration ihn nicht vollständig erfasst hat, und sollte auf das Client-Engineering übertragen werden.
<G-vec00956-002-s348><capture.erfassen><en> The gas will then pass through the electrode stack that will capture any moisture that is released during this chemical reaction and, more importantly, give a reading.
<G-vec00956-002-s348><capture.erfassen><de> Das Gas strömt anschließend durch das Elektrodenpaket, das jegliche während dieser chemischen Reaktion freigesetzte Feuchtigkeit erfasst und, was noch wichtiger ist, einen Messwert ausgibt.
<G-vec00956-002-s349><capture.erfassen><en> In particular, we here argue that Bayesian modeling is an important tool for automatically learning models from raw data and properly capture the uncertainty of the such models.
<G-vec00956-002-s349><capture.erfassen><de> Insbesondere argumentieren wir, dass Bayesian Modeling ein wichtiges Werkzeug für das automatische Lernen von Modellen durch rohen Daten ist und die Unsicherheit solcher Modelle angemessen erfasst.
<G-vec00956-002-s350><capture.erfassen><en> Hence you can easily capture even small writing and character input via the screen.
<G-vec00956-002-s350><capture.erfassen><de> So können selbst kleine Schriften und Zeicheneingaben problemlos über den Bildschirm für die Anwendung erfasst werden.
<G-vec00956-002-s351><capture.erfassen><en> The provided MicroSD card can capture comprehensive CPR event statistics for in-depth evaluation and debriefing.
<G-vec00956-002-s351><capture.erfassen><de> Eine integrierte MicroSD-Karte erfasst umfangreiche CPR-Ereignisstatistiken für eine eingehende Auswertung und ein effizientes Debriefing.
<G-vec00956-002-s352><capture.erfassen><en> To set this up, you define a workflow and forms that capture the recurring tasks in your business processes.
<G-vec00956-002-s352><capture.erfassen><de> Definieren und gestalten Sie dafür einen Workflow, der die wiederkehrenden Aufgaben in Ihren Geschäftsprozessen erfasst.
<G-vec00956-002-s353><capture.erfassen><en> It can also be used to capture and evaluate the newsletter recipients’ clicking behaviour.
<G-vec00956-002-s353><capture.erfassen><de> Darüber hinaus kann damit auch das Klickverhalten der Newsletter-Empfänger erfasst und ausgewertet werden.
<G-vec00956-002-s373><capture.erobern><en> Players can also capture flags while visiting other players’ Secret Bases.
<G-vec00956-002-s373><capture.erobern><de> Spieler können auch Flaggen erobern, wenn sie andere Geheim-Basen besuchen.
<G-vec00956-002-s374><capture.erobern><en> The conservative parties (The Republicans, The Australian Liberal Party and the British Conservative Party) capture the vote of the wealthier members in the Blue/Orange bands.
<G-vec00956-002-s374><capture.erobern><de> Die konservativen Parteien (die Republikaner, die australische liberale Partei und die britische konservative Partei) erobern die Stimmen der wohlhabenderen Mitglieder in den blau/orangen Bandbreiten.
<G-vec00956-002-s375><capture.erobern><en> Two armies fight to capture the flag of the opponent.
<G-vec00956-002-s375><capture.erobern><de> Zwei Armeen kämpfen darum, jeweils die Fahne des Gegners zu erobern.
<G-vec00956-002-s376><capture.erobern><en> I am indeed looking forward to capture market share there.”
<G-vec00956-002-s376><capture.erobern><de> Ich freue mich darauf, hier Marktanteile zu erobern“.
<G-vec00956-002-s377><capture.erobern><en> Products with low prices and sufficient quality mostly capture the market fast.
<G-vec00956-002-s377><capture.erobern><de> Produkte mit niedrigen Preisen und ausreichender Qualität erobern den Markt meist schnell.
<G-vec00956-002-s378><capture.erobern><en> Use your amazing powers to produce more batallions, defend your node with an awesome shield, boost the rage of your reptile warriors to defeat the enemy troops or to capture the enemy node faster, destroy your enemies with a big blast or freeze them to suffer a brutal impact in their scales.
<G-vec00956-002-s378><capture.erobern><de> Benutze deine unglaublichen Zauberkräfte, um mehr Kampftruppen zu schaffen, um deine Festung mit einem unglaublichen Schutzwall zu verteidigen, um die Wut deiner Reptilien zu erhöhen, um die Feindestruppen schneller zu vernichten oder die gegnerischen Festungen schneller zu erobern, um deine Gegner mit einer Riesenexplosion zu vernichten oder sie zeitweise einzufrieren, um eine brutale Auswirkung auf ihre Hautschuppen zu erwirken.
<G-vec00956-002-s379><capture.erobern><en> “We have no doubts that the deep-water container port will capture its position in the market.
<G-vec00956-002-s379><capture.erobern><de> „Es steht für uns außer Zweifel, dass der Containertiefwasserhafen seine Position am Markt erobern wird.
<G-vec00956-002-s380><capture.erobern><en> A large share of the companies that want to capture the German market come from the booming segment of mobile applications.
<G-vec00956-002-s380><capture.erobern><de> Ein großer Anteil von Firmen, die den deutschen Markt erobern wollen, kommt aus dem boomenden Segment der mobilen Applikationen.
<G-vec00956-002-s381><capture.erobern><en> No later than at this point is it time to capture new markets.
<G-vec00956-002-s381><capture.erobern><de> Spätestens dann ist es Zeit, neue Märkte zu erobern.
<G-vec00956-002-s382><capture.erobern><en> The sounds, scents and flavours of this land will capture your senses through a unique experience that you will live, relish and comprehend by visiting ancient churches, medieval castles and small villages where the rhythm of life remains unaltered over time.
<G-vec00956-002-s382><capture.erobern><de> Die Klänge, Düfte und Aromen dieses Landes werden Ihre Sinne durch eine einzigartige Erfahrung erobern, die Sie erleben, genießen und nachvollziehen können, indem Sie alte Kirchen, mittelalterliche Schlösser und kleine Dörfer besuchen, in denen der Rhythmus des Lebens über die Zeit unverändert bleibt.
<G-vec00956-002-s383><capture.erobern><en> As a member of the team, you will work with your teammates to capture and defend control points across the map or escort a payload to a destination within a time limit.
<G-vec00956-002-s383><capture.erobern><de> Als Mitglied des Teams arbeitet man gemeinsam mit den anderen Mitgliedern daran, die Kontrollpunkte, die auf der Map verteilt sind, zu erobern und anschließend zu verteidigen.
<G-vec00956-002-s384><capture.erobern><en> Rooms are uniquely decorated with original styles that catch your eye, capture your heart, and could never be mistaken for anywhere else you’ve ever stayed.
<G-vec00956-002-s384><capture.erobern><de> Die Zimmer sind mit originellen Stilen einzigartig dekoriert, die ihren Blick fangen, ihr Herz erobern und unverwechselbar mit jeglichem Ort sind, an dem Sie vorher waren.
<G-vec00956-002-s385><capture.erobern><en> These can successfully capture new markets with clever product differentiation.
<G-vec00956-002-s385><capture.erobern><de> Diese können durch geschickte Produktdifferenzierung erfolgreich den Markt erobern.
<G-vec00956-002-s386><capture.erobern><en> The largest US airborne operation of the war, its mission was to capture or destroy a major Viet Cong command centre.
<G-vec00956-002-s386><capture.erobern><de> Die Mission der größten US-Luftoperation des Krieges bestand darin, eine große Kommandozentrale in Vietnam zu erobern oder zu zerstören.
<G-vec00956-002-s387><capture.erobern><en> The C55 is an open boat from Sweden with a lifting keel. It was designed about 10 years ago but despite its excellent sailing performance it was never really able to capture the German market.
<G-vec00956-002-s387><capture.erobern><de> Die C55 ist ein offenes Hubkielboot aus Schweden, das vor etwa 10 Jahren entwickelt wurde, aber trotz seiner viel gelobten Segeleigenschaften nie wirklich den deutschen Markt erobern konnte.
<G-vec00956-002-s388><capture.erobern><en> They were unable to capture it.
<G-vec00956-002-s388><capture.erobern><de> Sie waren nicht in der Lage, sie zu erobern.
<G-vec00956-002-s389><capture.erobern><en> Pick up the Australium from its home position and capture it without dropping it.
<G-vec00956-002-s389><capture.erobern><de> Heben Sie das Australium an seiner Ausgangsposition auf und erobern Sie es, ohne es fallen zu lassen.
<G-vec00956-002-s391><capture.erobern><en> Twin Peaks / Warsong Gulch: 100 Conquest Points for every captured flag with an additional 100 Conquest Points awarded for every flag the winning team didn’t capture.
<G-vec00956-002-s391><capture.erobern><de> Zwillingsgipfel/Kriegshymnenschlucht: 100 Eroberungspunkte für jede eroberte Flagge und weitere 100 Eroberungspunkte für jede Flagge, die das Siegerteam nicht erobern konnte.
<G-vec00956-002-s392><capture.erobern><en> But if one can capture the original person, then he captures everyone.
<G-vec00956-002-s392><capture.erobern><de> Doch wenn jemand die ursprüngliche Person erobert, dann erobert er jeden.
<G-vec00956-002-s393><capture.erobern><en> Lost Caravan The Capture every location in the Battle for Stromgarde.
<G-vec00956-002-s393><capture.erobern><de> Erobert alle Orte in der Schlacht um die Dunkelküste.
<G-vec00956-002-s394><capture.erobern><en> It is a lively town with relaxing opportunities for shopping and exciting leisure activities - a town that will capture the hearts of its visitors.
<G-vec00956-002-s394><capture.erobern><de> Eine pulsierende Stadt, die mit entspannenden Einkaufserlebnissen, interessanten Sehenswürdigkeiten und erlebnisreichen Freizeiteinrichtungen die Herzen seiner Besucher erobert.
<G-vec00956-002-s395><capture.erobern><en> This allows the creation of more tailored Capture the Object experiences with an item spawner that adds extra functionality directly related to capture the object gameplay.
<G-vec00956-002-s395><capture.erobern><de> Erlaubt mehr maßgeschneiderte "Erobert das Objekt"-Erfahrungen mit einem Gegenstands-Spawnpunkt, der mehr Funktionen hinzufügt, welche direkt mit dem "Erobert das Objekt"-Gameplay zu tun haben.
<G-vec00956-002-s397><capture.erobern><en> More famous composers have lived here than in any other city, and music is literally in the air. Vienna is home to waltzing and operettas, while musicals “Made in Vienna” capture the hearts of international audiences.
<G-vec00956-002-s397><capture.erobern><de> Hier haben mehr berühmte Komponisten gelebt als in irgendeiner anderen Stadt, und Musik liegt förmlich in der Luft: Walzer und Operette sind hier zuhause, und Musicals „made in Vienna“ haben das internationale Publikum erobert.
<G-vec00956-002-s398><capture.erobern><en> Available alongside other Random Battles types, it’s exclusive to Tier X vehicles and follows the rules of Standard battles: capture an enemy base or destroy all opponents to secure victory.
<G-vec00956-002-s398><capture.erobern><de> Verfügbar neben den anderen Zufallsgefechtstypen, ist dieser Modus exklusiv für Fahrzeuge der Stufe X und folgt den Regeln des Standardgefechts: erobert die gegnerische Karte oder zerstört alle Gegner für den Sieg.
<G-vec00956-002-s399><capture.erobern><en> The rewards will be given only to those, who will capture the territory first.
<G-vec00956-002-s399><capture.erobern><de> Er wird nur an die gegeben, die das Gebiet als Erstes erobert haben.
<G-vec00956-002-s400><capture.erobern><en> Capture 10 points in naval battle whilst controlling ship or aircraft.
<G-vec00956-002-s400><capture.erobern><de> Erobert 10 Punkte in einer Seeschlacht, während ihr ein Schiff oder Flugzeug steuert.
<G-vec00956-002-s401><capture.erobern><en> Apps for mobile devices, like smartphones and tablets, did not capture the consumer market only, but also the shop floors.
<G-vec00956-002-s401><capture.erobern><de> Apps auf entsprechenden mobilen Geräten, wie Smartphones und Tablets, haben nicht nur den Consumer-Markt erobert, sondern dringen auch in die Produktionshallen vor.
<G-vec00956-002-s402><capture.erobern><en> My Units did not attack/capture/spy on the Hamlet.
<G-vec00956-002-s402><capture.erobern><de> Meine Einheiten haben das Dörfchen nicht angegriffen/erobert/ausspioniert.
<G-vec00956-002-s403><capture.erobern><en> Capture towers for your realm in World versus World.
<G-vec00956-002-s403><capture.erobern><de> Erobert Türme für Euer Reich im Welt gegen Welt.
<G-vec00956-002-s404><capture.erobern><en> Kill an enemy just before they capture the flag 10 times.
<G-vec00956-002-s404><capture.erobern><de> Töte einen Gegner 10 Mal kurz bevor er die Flagge erobert.
<G-vec00956-002-s405><capture.erobern><en> mine cart that is controlled by the opposing team within 20 yards of the depot, and then capture it.
<G-vec00956-002-s405><capture.erobern><de> Übernehmt die Kontrolle über eine vom gegnerischen Team kontrollierte Minenlore, die sich weniger als 20 Meter vom Depot entfernt befindet, und erobert sie dann.
<G-vec00956-002-s551><capture.gewinnen><en> You only have a few seconds to capture someone’s attention.
<G-vec00956-002-s551><capture.gewinnen><de> Sie haben nur ein paar Sekunden, um die Aufmerksamkeit eines anderen zu gewinnen.
<G-vec00956-002-s552><capture.gewinnen><en> But not all brands have enjoyed a sales boost, with some struggling to capture younger shoppers for instance.
<G-vec00956-002-s552><capture.gewinnen><de> Aber nicht alle Marken konnten sich über einen Verkaufsschub freuen und einige haben etwa Schwierigkeiten, jüngere Käufer zu gewinnen.
<G-vec00956-002-s553><capture.gewinnen><en> You are never obliged to make a capture, nor to make all possible captures with the card you play.
<G-vec00956-002-s553><capture.gewinnen><de> Außerdem können Sie einen Build nur gewinnen, wenn die von Ihnen gespielte Karte dessen Wert entspricht.
<G-vec00956-002-s554><capture.gewinnen><en> "India is emerging as one of the largest PV markets in the world, and JA Solar is well-positioned to continue to capture market share in the region.
<G-vec00956-002-s554><capture.gewinnen><de> „Indien entwickelt sich zu einem der größten FV-Märkte der Welt und JA Solar ist hervorragend positioniert, um weitere Marktanteile in der Region zu gewinnen.
<G-vec00956-002-s555><capture.gewinnen><en> The Praxidia AQA platform unlocks the full hidden potential of your QA resources, enabling Quality Analysts to capture rich insight driving intelligence from every monitored interaction.
<G-vec00956-002-s555><capture.gewinnen><de> Die AQA-Plattform von Praxidia erschließt das gesamte versteckte Potenzial Ihrer QS-Ressourcen und ermöglicht es Qualitätsanalysten, aus jeder überprüften Interaktion wertvolle Erkenntnisse zu gewinnen.
<G-vec00956-002-s556><capture.gewinnen><en> Federer rebounded in Cincinnati to capture his fifth title of the year.
<G-vec00956-002-s556><capture.gewinnen><de> Auch sein erstes Turnier der ATP Masters Series in Cincinnati konnte Murray gewinnen.
<G-vec00956-002-s557><capture.gewinnen><en> This new energy and the technology to capture it, will spring forth from the depths as the volcano erupts from the depths.
<G-vec00956-002-s557><capture.gewinnen><de> Diese neue Energie und die Technologie, um sie zu gewinnen, wird aus der Tiefe hervorsprudeln, wie der Vulkan aus den Tiefen hervorbricht.
<G-vec00956-002-s558><capture.gewinnen><en> Supervise teams of workers who capture water from wells and rivers.
<G-vec00956-002-s558><capture.gewinnen><de> Überwachen Sie Teams von Arbeitern, die Wasser aus Brunnen und Flüssen gewinnen.
<G-vec00956-002-s560><capture.gewinnen><en> This means that you can capture a larger share of the market while differentiating yourself from competitors.
<G-vec00956-002-s560><capture.gewinnen><de> Darum kannst Du einen größeren Marktanteil gewinnen, denn Du kannst Dich von Deinen Mitbewerbern abgrenzen.
<G-vec00956-002-s562><capture.gewinnen><en> You will be able to make comparisons about family consumption and formulate hypotheses about the past, express commitment and capture the consumer’s attention in advertising campaigns.
<G-vec00956-002-s562><capture.gewinnen><de> Sie sind in der Lage, Vergleiche über den Konsum in der Familie anzustellen und Hypothesen über die Vergangenheit zu formulieren, Engagement auszudrücken und die Aufmerksamkeit der Verbraucher in Werbekampagnen zu gewinnen.
<G-vec00956-002-s563><capture.gewinnen><en> Qualtrics is the leading global provider of data collection and analysis products for academic research, giving professors and students alike an all-in-one platform to capture real-time insights and draw solid conclusions. Purchase BEHAVIOUR
<G-vec00956-002-s563><capture.gewinnen><de> Qualtrics ist der weltweit führende Anbieter von Produkten zur Datenerhebung und -analyse für wissenschaftliche Forschung und bietet so Professoren wie Studenten eine umfassende Plattform, um in Echtzeit Insights zu gewinnen und fundierte Schlüsse zu ziehen.
<G-vec00956-002-s564><capture.gewinnen><en> The Swiss brands focused more on excellence to capture the hearts of wealthy customers.
<G-vec00956-002-s564><capture.gewinnen><de> Die Schweizer Marken haben sich mehr auf Spitzenleistungen konzentriert, um die Herzen wohlhabender Kunden zu gewinnen.
<G-vec00956-002-s565><capture.gewinnen><en> They laugh at every stronghold, for they build earthen ramps and capture them.
<G-vec00956-002-s565><capture.gewinnen><de> Alle Festungen werden ihnen ein Scherz sein; denn sie werden Schutt machen und sie doch gewinnen.
<G-vec00956-002-s566><capture.gewinnen><en> Header bidding has amplified a DSP’s ability to capture consumers’ attention for its advertisers.
<G-vec00956-002-s566><capture.gewinnen><de> Dank Header Bidding kann eine DSP die Aufmerksamkeit der Konsumenten für seine Werbekunden noch besser gewinnen.
<G-vec01169-002-s032><capture.aufnehmen><en> So-called snapshots can be used to capture and store individual images.
<G-vec01169-002-s032><capture.aufnehmen><de> Durch sogenannte Snapshots können Einzelbilder aufgenommen und in der Galerie der Cloud gespeichert werden.
<G-vec01169-002-s033><capture.aufnehmen><en> Capture 3 exposures of the same scene with high-speed continuous shooting, each at a different dynamic range setting (100%, 200% & 400%).
<G-vec01169-002-s033><capture.aufnehmen><de> Mit einem Druck auf den Auslöser werden 3 Aufnahmen Ihres Motivs mit unterschiedlichem Dynamikumfang (100 %, 200 % und 400 %) aufgenommen.
<G-vec01169-002-s034><capture.aufnehmen><en> Press the shutter once and the X100 will capture three exposures of the same scene in rapid succession, each using a different dynamic range setting (100%, 200% and 400%).
<G-vec01169-002-s034><capture.aufnehmen><de> Automatisch werden nacheinander drei Bilder mit unterschiedlichem Dynamikumfang (100%, 200%, 400%) aufgenommen.
<G-vec01169-002-s035><capture.aufnehmen><en> The X100S's Full HD Movie (1920 × 1080) can shoot at 60fps for very smooth movie capture.
<G-vec01169-002-s035><capture.aufnehmen><de> Im Full HD-Video Modus (1920 x 1080) können Videos mit 60 Bildern pro Sekunde aufgenommen werden.
<G-vec01169-002-s036><capture.aufnehmen><en> And note that our official photographer will capture you at one of the Festival evenings and send you the result.
<G-vec01169-002-s036><capture.aufnehmen><de> Ausserdem wirst du von unserem Fotografen bei einem Abendprogramm des Festivals aufgenommen; das Bild wird dir zugeschickt.
<G-vec01169-002-s037><capture.aufnehmen><en> Extended functions 50 Using the Magic Plus mode Using the 3D Photo mode In 3D Photo mode, you can capture scenes with a 3D effect.
<G-vec01169-002-s037><capture.aufnehmen><de> Erweiterte Funktionen 50 Magi c Pl us- Modu s v erwe nde n V erwenden des 3D-Aufnahmemodus Im 3D-Aufnahmemodus können Szenen mit 3D-Effekt aufgenommen werden.
<G-vec01169-002-s038><capture.aufnehmen><en> Panorama is a common photographing technique, usually used to capture ultra-wide landscapes.
<G-vec01169-002-s038><capture.aufnehmen><de> Panorama ist eine gängige Fotografietechnik, mit der häufig ultraweite Landschaften aufgenommen werden.
<G-vec01169-002-s039><capture.aufnehmen><en> While there are ways to increase the size of your lungs, there are also many ways to increase the amount of air taken in by your lungs, and the efficiency with which they capture oxygen.
<G-vec01169-002-s039><capture.aufnehmen><de> Während es Möglichkeiten gibt, die Lunge zu vergrößern, kann man auch die von den Lungen eingeatmete Luftmenge steigern, und die Effizienz, mit der Sauerstoff aufgenommen wird.
<G-vec01169-002-s040><capture.aufnehmen><en> Adobe Premiere Elements can capture or import video from the following devices.
<G-vec01169-002-s040><capture.aufnehmen><de> Mit Adobe Premiere Elements können Videos von den folgenden Geräten aufgenommen oder importiert werden.
<G-vec01169-002-s041><capture.aufnehmen><en> The team took over 500,000 reference images to capture London streets and locations used in the game.
<G-vec01169-002-s041><capture.aufnehmen><de> Über 500.000 Referenzfotos wurden für die virtuelle Nachbildung der Londoner Straßen und Orte, die im Spiel vorkommen, aufgenommen.
<G-vec01169-002-s042><capture.aufnehmen><en> But they never told us why they failed to capture that historic moment on video.
<G-vec01169-002-s042><capture.aufnehmen><de> Aber sie erklärten uns nie, warum sie jenen historischen Augenblick nicht auf Video aufgenommen haben.
<G-vec01169-002-s043><capture.aufnehmen><en> The profiles are based on metadata that identifies the camera and lens used to capture the photo, and then compensates accordingly.
<G-vec01169-002-s043><capture.aufnehmen><de> Die Profile basieren auf Exif-Metadaten, die die Kamera und das Objektiv, mit dem die Fotos aufgenommen wurden, identifizieren, und die Profile kompensieren die Fehler entsprechend.
<G-vec01169-002-s044><capture.aufnehmen><en> To capture the image, you can either long-press the screen or short press the volume button (the button may allow for a more stable grip).
<G-vec01169-002-s044><capture.aufnehmen><de> Ein Bild wird aufgenommen, wenn Sie mit einem Finger länger auf dem Bildschirm drücken, oder kurz die Lautstärketaste als Auslöser nutzen.
<G-vec01169-002-s065><capture.aufnehmen><en> Ashampoo Snap for Android is a fully-fledged mobile application to capture, edit and share screenshots and images on your Android device.
<G-vec01169-002-s065><capture.aufnehmen><de> Mit Ashampoo Snap für Android können Sie Screenshots und Bilder mühelos auf Ihrem Android Gerät aufnehmen, bearbeiten und teilen.
<G-vec01169-002-s066><capture.aufnehmen><en> This way, you can capture sharp, undistorted images of sports like tennis.
<G-vec01169-002-s066><capture.aufnehmen><de> So wird sichergestellt, dass Sie scharfe, unverzerrte Bilder von Sportveranstaltungen, wie beispielsweise Tennis aufnehmen können.
<G-vec01169-002-s067><capture.aufnehmen><en> You can capture the area around the mouse pointer, select a specific region to capture, or capture the desktop full screen.
<G-vec01169-002-s067><capture.aufnehmen><de> Sie können eine Umgebung des Mauszeigers, einen bestimmten Bereich oder den ganzen Bildschirm aufnehmen.
<G-vec01169-002-s068><capture.aufnehmen><en> Smile detection allows you to capture a face just as it smiles.
<G-vec01169-002-s068><capture.aufnehmen><de> Mit „Smile Detection“ können Sie ein Gesicht aufnehmen, genau wenn es lächelt.
<G-vec01169-002-s069><capture.aufnehmen><en> Completely remove unwanted objects from your picture. Signs, wires, people, or any image that distracts you from what you are trying to capture.
<G-vec01169-002-s069><capture.aufnehmen><de> Entfernen Sie alle unerwünschten Objekte aus dem Bild: Schilder, Kabel, Personen oder andere Elemente, die davon ablenken, was Sie eigentlich aufnehmen wollen.
<G-vec01169-002-s071><capture.aufnehmen><en> You can see your real-time iPhone screen, and capture anything visible in high quality.
<G-vec01169-002-s071><capture.aufnehmen><de> Sie können Ihren iPhone-Bildschirm von Echtzeit sehen und alles, was sichtbar ist, in hoher Qualität aufnehmen.
<G-vec01169-002-s072><capture.aufnehmen><en> While traditional hearing aids capture and process sound outside of the ear, Lyric uses the natural anatomy of the ear to amplify and give you a full, natural listening experience.
<G-vec01169-002-s072><capture.aufnehmen><de> Während herkömmliche Hörgeräte den Klang außerhalb des Ohrs aufnehmen und verarbeiten, nutzt Lyric die natürliche Anatomie des Ohres, um ein natürliches Hörerlebnis zu bieten.
<G-vec01169-002-s073><capture.aufnehmen><en> An ideal solution for intraoral imaging needs, the easy-to-use sensor allows users to capture exceptional images quickly and easily.
<G-vec01169-002-s073><capture.aufnehmen><de> Der benutzerfreundliche Sensor ist eine ideale Lösung für die Erfordernisse der intraoralen Bilderfassung und ermöglicht dem Benutzer das schnelle und einfache Aufnehmen außergewöhnlicher Bilder.
<G-vec01169-002-s078><capture.aufnehmen><en> Any game clips you capture while playing Gears of War 4 can be accessed via the Xbox app.
<G-vec01169-002-s078><capture.aufnehmen><de> Über die Xbox App können Sie auf alle Spielclips zugreifen, die Sie während des Spielens von Forza Horizon 4 aufnehmen.
<G-vec01169-002-s079><capture.aufnehmen><en> Tap Capture picture, tap to take a picture, and tap to add the picture as an attachment.
<G-vec01169-002-s079><capture.aufnehmen><de> Tippen Sie auf Bild aufnehmen, tippen Sie auf, um ein Foto aufzunehmen, und tippen Sie auf, um das Bild als Anhang hinzuzufügen.
<G-vec01169-002-s081><capture.aufnehmen><en> Through the specialized APP, you can easily capture pictures and videos with computer(with USB adapter) or smartphone(support OTG function).
<G-vec01169-002-s081><capture.aufnehmen><de> Durch die spezielle APP können Sie ganz einfach Fotos und Videos aufnehmen mit dem Computer (mit USB-Adapter) oder Smartphone (Unterstützung OTG-Funktion).
<G-vec01169-002-s082><capture.aufnehmen><en> The Huawei P20's 2X Hybrid Zoom means that if you want to capture more from a distance, now you can.
<G-vec01169-002-s082><capture.aufnehmen><de> Der 2X Hybrid Zoom des HUAWEI P20 bedeutet, dass du jetzt mehr aus der Ferne aufnehmen kannst ohne Einschränkung in der Bildqualität.
<G-vec01169-002-s083><capture.aufnehmen><en> In addition, they are available in industry-leading capacities so that photographers can capture a larger number of RAW or other high-resolution images.
<G-vec01169-002-s083><capture.aufnehmen><de> Außerdem sind die neuen Karten in marktführenden Speicherkapazitäten verfügbar, so dass Fotografen eine große Menge an RAW oder anderen hochauflösenden Bildern aufnehmen können.
<G-vec01169-002-s103><capture.aufnehmen><en> Voice Memos for Mac makes it easier than ever to capture personal reminders, class lectures, even interviews or song ideas.
<G-vec01169-002-s103><capture.aufnehmen><de> Mit Sprachmemos für Mac ist es einfacher denn je, persönliche Erinnerungen, Vorlesungen oder sogar Interviews oder Songideen aufzunehmen.
<G-vec01169-002-s104><capture.aufnehmen><en> You can say Cheese, Smile, Whiskey, Kimchi or LG. Sets a delay after the capture button is pressed.
<G-vec01169-002-s104><capture.aufnehmen><de> Wenn diese Funktion aktiviert ist, müssen Sie nur das Wort Cheese, Smile, Whiskey, Kimchi oder LG sagen, um ein Foto aufzunehmen.
<G-vec01169-002-s105><capture.aufnehmen><en> For your conferences, congress, meetings and colloquiums, we remain discreet and professional to capture the event better.
<G-vec01169-002-s105><capture.aufnehmen><de> Für Ihre Konferenzen, Kongresse, Meetings und Kolloquiums bleiben wir diskret und professionell, um das Event besser aufzunehmen.
<G-vec01169-002-s106><capture.aufnehmen><en> Video snapshots Use Video Snapshot mode to capture small sections of video that tell the story of the city.
<G-vec01169-002-s106><capture.aufnehmen><de> Videoschnappschüsse Nutzen Sie den Modus Video-Schnappschuss, um kurze Clips aufzunehmen, mit denen Sie die Geschichte der Stadt erzählen.
<G-vec01169-002-s107><capture.aufnehmen><en> With smarter imaging features and a 5 megapixel camera with LED flash, the smart camera offers a choice of image capture, editing and sharing options, including:
<G-vec01169-002-s107><capture.aufnehmen><de> Dank intelligenter Foto-Funktionen und einer 5-Megapixel-Kamera mit LED-Blitz bietet die Kamera eine Reihe von Möglichkeiten, Bilder aufzunehmen, zu bearbeiten und zu teilen.
<G-vec01169-002-s108><capture.aufnehmen><en> Use it to capture and enjoy life’s most precious moments before they zoom past.
<G-vec01169-002-s108><capture.aufnehmen><de> Nutze diese Funktion, um die wertvollsten Augenblicke aufzunehmen und zu genießen, bevor sie vorbei gezogen sind.
<G-vec01169-002-s109><capture.aufnehmen><en> As the backrest bends forwards a touch in its upper position to capture the lumbar spine, slightly increased pressure arises here.
<G-vec01169-002-s109><capture.aufnehmen><de> Da sich die Rückenlehne in ihrer oberen Position ein wenig nach vorn neigt, um die Lendenwirbelsäule aufzunehmen, entsteht hier ein leicht erhöhter Druck.
<G-vec01169-002-s110><capture.aufnehmen><en> The researchers, who are working with Johns Hopkins Technology Ventures to spin off this technology, say a commercial version might cost approximately 10 times less than currently available models, and they plan to refine the device to capture clearer images and monitor additional brain functions.
<G-vec01169-002-s110><capture.aufnehmen><de> Die Forscher, die mit Johns Hopkins Technology Ventures zusammenarbeiten, um diese Technologie auszulagern, sagen, dass eine kommerzielle Version etwa zehnmal weniger kosten könnte als derzeit verfügbare Modelle, und sie planen, das Gerät zu verfeinern, um klarere Bilder aufzunehmen und zusätzliche Gehirnfunktionen zu überwachen.
<G-vec01169-002-s111><capture.aufnehmen><en> It therefore directly influences the physiological characteristics of plants and their ability to capture carbon from the air and transform it into an organic form to produce biomass.
<G-vec01169-002-s111><capture.aufnehmen><de> Es ist direkt an dieser physiologischen Besonderheit der Pflanze beteiligt, der Fähigkeit, Kohlenstoff aus der Luft aufzunehmen und in eine organische Form umzuwandeln, um Biomasse zu erzeugen.
<G-vec01169-002-s112><capture.aufnehmen><en> Get a friend to bounce a tennis ball on a racquet and see how many times you can capture the ball in contact with the racquet.
<G-vec01169-002-s112><capture.aufnehmen><de> Bitten Sie einen Freund, einen Tennisball auf einem Schläger springen zu lassen, und versuchen Sie, möglichst oft den Augenblick aufzunehmen, in dem der Ball den Schläger berührt.
<G-vec01169-002-s113><capture.aufnehmen><en> We are most grateful to the Artist who was able to capture this spirit and wanted to return it to us with his Pescatore.
<G-vec01169-002-s113><capture.aufnehmen><de> Wir sind dem Künstler dankbar, der diesen Geist aufzunehmen gewusst hat und ihn uns mit dem Fischer zurückgeben wollte.
<G-vec01169-002-s114><capture.aufnehmen><en> Connect the large diaphragm CM25 condenser mic, plug in your guitar or a second microphone, and immediately capture studio-quality sound.
<G-vec01169-002-s114><capture.aufnehmen><de> Schließe das CM25 Großmembran-Kondensatormikrofon an und stöpsele deine Gitarre oder ein zweites Mikrofon ein, um sofort Musik in Studioqualität aufzunehmen.
<G-vec01169-002-s115><capture.aufnehmen><en> The Event Horizon Telescope (EHT) -- a planet-scale array of eight ground-based radio telescopes forged through international collaboration -- was designed to capture images of a black hole.
<G-vec01169-002-s115><capture.aufnehmen><de> Das Ereignishorizontteleskop (EHT, Event Horizon Telescope) – eine erdumspannende Anordnung von acht bodengebundenen Radioteleskopen, durch internationale Zusammenarbeit entstanden – wurde entwickelt, um Bilder von einem schwarzen Loch aufzunehmen.
<G-vec01169-002-s116><capture.aufnehmen><en> These often begin a month or so before Christmas Day and are a great place to capture action-packed photos of crowds enjoying fairground rides or ice skating.
<G-vec01169-002-s116><capture.aufnehmen><de> Sie beginnen meist einen Monat vor Weihnachten und sind ein großartiger Ort, um dynamische Bilder von Menschen aufzunehmen, die beispielsweise Karussell fahren oder eislaufen.
<G-vec01169-002-s117><capture.aufnehmen><en> You just need to hover your mouse over a window and click to capture the screenshot for it.
<G-vec01169-002-s117><capture.aufnehmen><de> Sie müssen Ihren Mauszeiger nur über ein Fenster bewegen und darauf klicken, um es aufzunehmen.
<G-vec01169-002-s118><capture.aufnehmen><en> Free Sound Recorder can be a good choice to capture videogame sounds, music from Internet and more.
<G-vec01169-002-s118><capture.aufnehmen><de> Free Sound Recorder eignet sich gut, um Sounds aus Videospielen oder Musik aus dem Internet aufzunehmen.
<G-vec01169-002-s119><capture.aufnehmen><en> I have the impression that the phone captures pictures with an underexposure step to capture as much detail as possible.
<G-vec01169-002-s119><capture.aufnehmen><de> Ich habe den Eindruck, dass das Telefon Bilder mit einem Unterbelichtungsschritt aufnimmt, um so viele Details wie möglich aufzunehmen.
<G-vec01169-002-s120><capture.aufnehmen><en> The reflective diffuser makes it possible to capture even moving subjects without blurring – irrespective of low ISO setting – up to 15m underwater.
<G-vec01169-002-s120><capture.aufnehmen><de> Der reflektive Diffusor ermöglicht es, sogar sich bewegende Motive ohne Unschärfen aufzunehmen ‑ auch bei niedriger ISO‑Einstellung und zwar bei bis zu 15 m unter Wasser.
<G-vec01169-002-s121><capture.aufnehmen><en> With this pixel shift camera, it takes only four seconds to capture a brilliant and sharp image in 36 shot mode.
<G-vec01169-002-s121><capture.aufnehmen><de> Mit dieser Pixel Shift Mikroskopkamera dauert es nur vier Sekunden, um ein brillantes und scharfes Bild mit 36 Shot-Modus aufzunehmen.
<G-vec01169-002-s640><capture.aufnehmen><en> “Since an IS-BE cannot be “killed”, the objective has been to capture and immobilize IS-BEs.
<G-vec01169-002-s640><capture.aufnehmen><de> Da ein IS-BE nicht „getötet“ werden kann, war das Ziel, IS-BEs gefangen zu nehmen und sie unbeweglich zu machen.
<G-vec01169-002-s641><capture.aufnehmen><en> Sensors capture any remaining impulses, conveying them to the HAL system.
<G-vec01169-002-s641><capture.aufnehmen><de> Sensoren nehmen die verbliebenen Restimpulse des Patienten auf und leiten diese an das HAL-System weiter.
<G-vec01169-002-s642><capture.aufnehmen><en> Free professional HD quality camera and video capture.
<G-vec01169-002-s642><capture.aufnehmen><de> Nehmen Sie professionelle Fotos in hoher Auflösung, HD-Qualität.
<G-vec01169-002-s643><capture.aufnehmen><en> Simply capture the scene, review the image and touch the part of the photo you’d like to be pin sharp.
<G-vec01169-002-s643><capture.aufnehmen><de> Nehmen Sie die Szene einfach auf, sehen Sie sich das Bild an und berühren Sie den Teil des Fotos, der gestochen scharf dargestellt werden soll.
<G-vec01169-002-s644><capture.aufnehmen><en> And now, without the Cygnus, we have more space for the risky capture of the incoming large APP module.
<G-vec01169-002-s644><capture.aufnehmen><de> Und jetzt haben wir dann auch mehr Platz um das sehr große APP-Modul in Empfang zu nehmen.
<G-vec01169-002-s646><capture.aufnehmen><en> During a scan, you can easily capture images and video clips using a footswitch.
<G-vec01169-002-s646><capture.aufnehmen><de> Während einer Untersuchung nehmen Sie Bilder und Videosequenzen ganz einfach über einen Fußschalter auf.
<G-vec01169-002-s647><capture.aufnehmen><en> With Time-lapse Capture, shoot stills of a scene over a period of time with a chosen interval between each shot and edit the sequence into a high-quality 4K time-lapse movie.
<G-vec01169-002-s647><capture.aufnehmen><de> Nehmen Sie mit der Zeitraffer-Erfassung Fotos einer Szene über einen Zeitraum mit einem festgelegten Intervall zwischen den einzelnen Aufnahmen auf, und verarbeiten Sie die Sequenz zu einem hochwertigen 4K-Film im Zeitraffer.
<G-vec01169-002-s648><capture.aufnehmen><en> Latest newer versions of digital camera models can capture videos, sound and images with a high level of accuracy and efficiency.
<G-vec01169-002-s648><capture.aufnehmen><de> Die letzten neueren Versionen von Digitalkameras nehmen Videos, Ton und Bilder mit hoher Genauigkeit und Effizienz auf.
<G-vec01169-002-s649><capture.aufnehmen><en> 1862 – American Civil War: Battle of Memphis: Union forces capture Memphis, Tennessee, from the Confederates.
<G-vec01169-002-s649><capture.aufnehmen><de> 1862: Im Amerikanischen Bürgerkrieg nehmen die Truppen der Nordstaaten Memphis in Tennessee ein.
<G-vec01169-002-s650><capture.aufnehmen><en> The Globe and Mail reporters and videographers capture footage on location or in their newsroom studio using as many as four cameras shooting simultaneously.
<G-vec01169-002-s650><capture.aufnehmen><de> Die Reporter und Videofilmer bei Globe and Mail nehmen ihr Material vor Ort oder im Nachrichtenstudio auf, wobei bis zu vier Kameras gleichzeitig eingesetzt werden.
<G-vec01169-002-s651><capture.aufnehmen><en> Fett befriended Luke Skywalker on Panna, and nearly got the location of the new Rebel base out of him, but he was forced to retreat, and failed even to capture the young Jedi.
<G-vec01169-002-s651><capture.aufnehmen><de> Zwar war es Kopatha in der Zwischenzeit gelungen, Han Solo gefangen zu nehmen, doch konnte dieser wieder entwischen, ohne dass Kopatha den Standort der Rebellen-Flotte erfahren hatte.
<G-vec01169-002-s652><capture.aufnehmen><en> If you play a capturing card as an action of type 1 or 5 (capture or discard), but fail to take all the cards you are entitled to capture, any opponent can insist (if they wish) that you capture all the cards that it is legal for you to take.
<G-vec01169-002-s652><capture.aufnehmen><de> Wenn Sie eine gewinnende Karte als Aktion des Typs 1 oder 5 spielen (Gewinnen oder Ablegen), jedoch nicht alle Karten vom Tisch nehmen, zu denen Sie berechtigt sind, kann jeder Gegner verlangen (wenn er dies möchte), dass Sie alle Karten vom Tisch nehmen, zu denen Sie nach den Regeln berechtigt sind.
<G-vec01169-002-s653><capture.aufnehmen><en> You cannot capture the 7 or the jack because the 6 is missing from the sequence.
<G-vec01169-002-s653><capture.aufnehmen><de> Man kann weder die 7 noch den B nehmen, weil die 6 in der Folge fehlt.
<G-vec01169-002-s654><capture.aufnehmen><en> And if you ever have a carelessness to capture a captive, then either drag him to the HQ yourselves or noislessly finish him off at place.
<G-vec01169-002-s654><capture.aufnehmen><de> Und solltet ihr so unvorsichtig sein und noch irgendjemanden in Gefangenschaft nehmen, dann schleppt ihn selbst in den Stab der Brigade oder erledigt ihn leise an Ort und Stelle.
<G-vec01169-002-s655><capture.aufnehmen><en> Simply capture a Guide signal with the right timing, capture a Dub signal to be aligned, press one button, and a new aligned Dub is generated and returned to your DAW. Main Features
<G-vec01169-002-s655><capture.aufnehmen><de> Sie nehmen einfach ein "Guide Signal" mit dem korrekten Timing als Referenz auf, dann das eigentliche "Dub Signal", welches angepasst werden muss, drücken einen Knopf und eine neue angepasste "Dub-Spur" wird in ihrer DAW erzeugt.
<G-vec01169-002-s656><capture.aufnehmen><en> Perfect for gear-mounted shots, you can power the camera on/off, adjust settings, start/stop recording and capture photos.
<G-vec01169-002-s656><capture.aufnehmen><de> Damit schalten Sie die Kamera ein und aus, passen Einstellungen an, starten und stoppen die Aufzeichnung und nehmen Fotos auf - Damit ist sie ideal für Aufnahmen, wenn Ihre GoPro an Ihrer Ausrüstung montiert ist.
<G-vec01169-002-s657><capture.aufnehmen><en> Their sole purpose was to capture Jerusalem for the pope so that he could reign from there.
<G-vec01169-002-s657><capture.aufnehmen><de> Der einzige Zweck dieser Unternehmungen besteht für den Papst darin, Jerusalem in Besitz zu nehmen, um von dort aus regieren zu können.
<G-vec01169-002-s658><capture.aufnehmen><en> Capture the lovely landscaped garden at Chateau-sur-Mer and if weather permits, take a brief walk at Fort Adams.Enjoy this fully narrated bus tour with details on residences of prominent people such as the Watts Sherman House, Kingscote, McCauley Hall and Belcourt Castle.
<G-vec01169-002-s658><capture.aufnehmen><de> Nehmen Sie den schönen Landschaftsgarten von Chateau-sur-Mer und wenn das Wetter es zulässt, unternehmen Sie einen kurzen Spaziergang im Fort Adams.
<G-vec01169-002-s659><capture.aufnehmen><en> Capture a game-winning goal from the far end of the soccer field, or a band rocking out even from the back row.
<G-vec01169-002-s659><capture.aufnehmen><de> Nehmen Sie das Siegertor vom anderen Ende des Fußballplatzes oder eine Band auf der Bühne von der letzten Reihe auf.
<G-vec01169-002-s660><capture.aufnehmen><en> Select which screen or segment of your screen you’d like to record, turn on your webcam, and capture video and audio simultaneously.
<G-vec01169-002-s660><capture.aufnehmen><de> Wählen Sie aus, welchen Bildschirm oder welchen Bereich des Bildschirms Sie aufnehmen möchten, schalten Sie die Webcam ein und nehmen Sie Bild und Ton gleichzeitig auf.
<G-vec01169-002-s661><capture.aufnehmen><en> Capture unforgettable images of the park’s soaring rock walls and craggy peaks then enjoy an invigorating hike to Yosemite Falls or Bridalveil Falls, where high-mountain rivers tumble from sheer granite cliffs.
<G-vec01169-002-s661><capture.aufnehmen><de> Nehmen Sie unvergessliche Bilder von den hoch aufragenden Felswänden und zerklüfteten Gipfeln des Parks auf und wandern Sie zu den Yosemite Falls oder Bridalveil Falls, wo Hochgebirgsflüsse von schroffen Granitfelsen stürzen.
<G-vec01169-002-s662><capture.aufnehmen><en> Capture fantastic photographs of alligators in their natural habitat, and relish the intimate atmosphere of a small-group, limited to only 6 passengers.
<G-vec01169-002-s662><capture.aufnehmen><de> Nehmen Sie fantastische Fotografien von Alligatoren in ihrem natürlichen Lebensraum auf und genießen Sie die intime Atmosphäre einer kleinen Gruppe mit nur 6 Passagieren.
<G-vec01169-002-s664><capture.aufnehmen><en> Capture sounds using the AUX Input and play them back from the keyboard.
<G-vec01169-002-s664><capture.aufnehmen><de> Nehmen Sie Sounds über den AUX Eingang auf und spielen Sie sie über Ihr Keyboard wieder ab.
<G-vec01169-002-s665><capture.aufnehmen><en> Capture up to 1,110 still images and up to 80 minutes of movie footage³ on a single charge of the ultra-compact and lightweight lithium-ion rechargeable EN-EL15 battery.
<G-vec01169-002-s665><capture.aufnehmen><de> Nehmen Sie bis zu 1.110 Fotos oder Videos mit einer Länge bis zu 80 Minuten³ mit nur einer Akkuladung des leichten Lithium-Ionen-Akkus EN-EL15 auf.
<G-vec01169-002-s666><capture.aufnehmen><en> Capture sufficient photographs of the natural wonder and then relax during the journey back to your original departure point in Reykjavik.
<G-vec01169-002-s666><capture.aufnehmen><de> Nehmen Sie genügend Fotos vom Naturwunder auf und entspannen Sie sich dann auf der Rückfahrt zu Ihrem ursprünglichen Ausgangspunkt in Reykjavik.
<G-vec01169-002-s667><capture.aufnehmen><en> Capture your happy times with BoothCool.
<G-vec01169-002-s667><capture.aufnehmen><de> Nehmen Sie Ihre glücklichen Zeiten mit BoothCool gefangen.
<G-vec01169-002-s668><capture.aufnehmen><en> Capture perfectly synced video from multiple cameras with new MultiCam Capture.
<G-vec01169-002-s668><capture.aufnehmen><de> Nehmen Sie mit dem neuen MultiCam Capture mehrere Geräte gleichzeitig auf.
<G-vec01169-002-s669><capture.aufnehmen><en> Simply capture various objects and structures immediately in color from different angles.
<G-vec01169-002-s669><capture.aufnehmen><de> Nehmen Sie verschiedenste Objekte und Strukturen in kürzester Zeit aus unterschiedlichen Winkeln in Farbe auf.
<G-vec01169-002-s670><capture.aufnehmen><en> Capture the enchanting charm of these luxurious wedding dresses 2014 from Tbdress.
<G-vec01169-002-s670><capture.aufnehmen><de> Nehmen Sie das zauberhaften Charme der luxuriösen Hochzeitskleider 2014 von Tbdress .
<G-vec01169-002-s671><capture.aufnehmen><en> Capture the night sky in a whole new way.
<G-vec01169-002-s671><capture.aufnehmen><de> Nehmen Sie den Nachthimmel auf ganz neue Weise auf.
<G-vec01169-002-s672><capture.aufnehmen><en> Recording tools Capture program activity to show off your software, grab screenshots of important diagrams and statistics.
<G-vec01169-002-s672><capture.aufnehmen><de> Aufnahme-Tools Nehmen Sie Programmaktivität auf, um Ihre Software zu zeigen, machen Sie Screenshots von wichtigen Grafiken und Statistiken.
<G-vec01169-002-s673><capture.aufnehmen><en> Capture footage from your Mac screen at up to 60 fps, or reduce the output file size by capturing at 5-10 fps.
<G-vec01169-002-s673><capture.aufnehmen><de> Nehmen Sie Videos mit bis zu 60 fps auf oder stellen Sie die Bildrate auf bis zu 5 fps ein, um die Dateigröße zu reduzieren.
<G-vec01169-002-s674><capture.aufnehmen><en> Quickly launch OneNote by clicking the top button and write notes (even on a locked screen), capture a screenshot, or activate Cortana.
<G-vec01169-002-s674><capture.aufnehmen><de> Rufen Sie durch Betätigen der oberen Taste schnell OneNote auf und schreiben Sie Notizen (sogar auf einem gesperrten Bildschirm), nehmen Sie einen Screenshot auf oder aktivieren Sie Cortana.
<G-vec01169-002-s675><capture.aufnehmen><en> Capture HD MP4 movies in the best way using this site which is any user's ideal choice.
<G-vec01169-002-s675><capture.aufnehmen><de> Nehmen Sie MP4-Filme in HD in der besten Weise mit dieser Webseite auf, nämlich die ideale Wahl des beliebigen Benutzers.
<G-vec01169-002-s085><capture.aufzeichnen><en> In the Preview window, use the control on the progress bar to scrub to the frame you want to capture, or just let the video play to the frame you want.
<G-vec01169-002-s085><capture.aufzeichnen><de> Verwenden Sie im Vorschaufenster das Steuerelement auf der Statusanzeige, um ein Scrubbing zu dem Frame auszuführen, den Sie aufzeichnen möchten, oder geben Sie das Video im gewünschten Frame wieder.
<G-vec01169-002-s086><capture.aufzeichnen><en> Roxio Easy Audio Capture makes it easy to capture Internet audio, whatever the source - if you can hear it, you can capture it.
<G-vec01169-002-s086><capture.aufzeichnen><de> Easy Audio Capture macht es einfach, Internetaudio aufzuzeichnen, und zwar unabhängig von der Quelle: Wenn Sie es hören können, können Sie es auch aufzeichnen.
<G-vec01169-002-s087><capture.aufzeichnen><en> Equipped with Bluetooth 4.0, VIRB XE can connect directly to wireless Bluetooth headsets or microphones to capture audio in high definition.
<G-vec01169-002-s087><capture.aufzeichnen><de> Über Bluetooth 4.0 kann die VIRB XE direkt eine Verbindung mit drahtlosen Bluetooth-Headsets oder -Mikrofonen herstellen und HD-Ton aufzeichnen.
<G-vec01169-002-s088><capture.aufzeichnen><en> The laptop's HD webcam is capable to capture 720p HD videos at 30 fps.
<G-vec01169-002-s088><capture.aufzeichnen><de> Die HD-Webcam des Laptops kann 720p-HD-Videos bei 30 fps aufzeichnen.
<G-vec01169-002-s089><capture.aufzeichnen><en> Capture as Wallpaper (Tile): select this option to set the captured image as tiled background wallpaper on your computer’s desktop.
<G-vec01169-002-s089><capture.aufzeichnen><de> Als Bildschrimhintergrund (Kacheln) aufzeichnen: Wählen Sie diese Option aus, um das aufgenommene Bild als gekacheltes Hintergrundbild auf dem Desktop des Computers anzuzeigen.
<G-vec01169-002-s090><capture.aufzeichnen><en> You can capture video from a video camera.
<G-vec01169-002-s090><capture.aufzeichnen><de> Sie können mit einer Videokamera Videos aufzeichnen.
<G-vec01169-002-s091><capture.aufzeichnen><en> We want to capture the first gravitational waves from a rotating neutron star.
<G-vec01169-002-s091><capture.aufzeichnen><de> Wir wollen die erste Gravitationswelle eines rotierenden Neutronensterns aufzeichnen.
<G-vec01169-002-s092><capture.aufzeichnen><en> +Expand RealPresence Media Suite Capture and stream video content—easily, reliably and automatically—whenever and wherever important information is presented.
<G-vec01169-002-s092><capture.aufzeichnen><de> Die Administratorfunktionen der Polycom RealPresence Capture-Serie stellen sicher, dass Sie Inhalte einfach, zuverlässig und automatisch aufzeichnen und streamen können – wann und wo auch immer wichtige Informationen präsentiert werden.
<G-vec01169-002-s093><capture.aufzeichnen><en> Bluetooth-enabled HD Audio: Equipped with Bluetooth 4.0, VIRB XE can connect directly to wireless Bluetooth headsets or microphones to capture audio in high definition.
<G-vec01169-002-s093><capture.aufzeichnen><de> Drahtloser HD-Ton Über Bluetooth 4.0 kann die VIRB XE direkt eine Verbindung mit drahtlosen Bluetooth-Headsets oder -Mikrofonen herstellen und HD-Ton aufzeichnen.
<G-vec01169-002-s094><capture.aufzeichnen><en> As Tor does not, and by design cannot, encrypt the traffic between an exit node and the destination server, any exit node is in a position to capture any traffic passing through it.
<G-vec01169-002-s094><capture.aufzeichnen><de> Da Tor die Daten zwischen Ausgangsrelais und Zielserver nicht verschlüsselt und konzeptionell nicht verschlüsseln kann, kann jedes Ausgangsrelais jeden beliebigen durch ihn hindurch geleiteten Datenverkehr aufzeichnen.
<G-vec01169-002-s095><capture.aufzeichnen><en> With the SZC-2002 license option for the BPU-4000, the PMW-F55 Live System allows you to capture HD slow-motion at 4x (max 240i or 240P) and also 6x Speed (max 360i or 360P).
<G-vec01169-002-s095><capture.aufzeichnen><de> Zweifache Zeitlupe in 4K und HD Mit der Option SZC-2002 für den BPU-4000 kann das F65-Livesystem 4K-Zeitlupe bei zweifacher Geschwindigkeit (100p) aufzeichnen.
<G-vec01169-002-s096><capture.aufzeichnen><en> Securlets also enable incident response and forensics to monitor, log and capture activities that occur within cloud applications.
<G-vec01169-002-s096><capture.aufzeichnen><de> Darüber hinaus unterstützen die Securelets eine leistungsfähige Incident Response und Forensik, sodass Sie sämtliche Aktivtäten in der Cloud überwachen, protokollieren und aufzeichnen können.
<G-vec01169-002-s097><capture.aufzeichnen><en> You can only imagine the kind of stunning photos you can capture with your camera.
<G-vec01169-002-s097><capture.aufzeichnen><de> Sie können sich kaum vorstellen, was für phantastische Fotos Sie mit Ihrer Kamera aufzeichnen können.
<G-vec01169-002-s098><capture.aufzeichnen><en> Capture video from a DV camcorder, VHS, GoPro, webcam, or all common video file formats including avi, wmv, mpv, divx and many more.
<G-vec01169-002-s098><capture.aufzeichnen><de> Video von DV-Camcorder, VHS, GoPro, Webcam aufzeichnen oder alle gängigen Videoformate importieren, inklusive AVI, WMV, DIVX und mehr.
<G-vec01169-002-s099><capture.aufzeichnen><en> Provides steps for using the browser capture feature to capture a Web session.
<G-vec01169-002-s099><capture.aufzeichnen><de> Enthält Anweisungen zur Verwendung des Browseraufnahmefeatures zum Aufzeichnen einer Websitzung.
<G-vec01169-002-s100><capture.aufzeichnen><en> Run Network Monitor on your Exchange 2003 computer, and use the default authentication settings to initiate an SMTP session from the client while you capture the traffic that is coming to the Exchange 2003 computer.
<G-vec01169-002-s100><capture.aufzeichnen><de> Führen Sie auf Ihrem Exchange 2003-Computer den Netzwerkmonitor aus, und verwenden Sie die Standardauthentifizierungseinstellungen, um eine SMTP-Sitzung vom Client aus zu initiieren, während Sie den auf dem Exchange 2003-Computer ankommenden Netzwerkverkehr aufzeichnen.
<G-vec01169-002-s101><capture.aufzeichnen><en> Enable this if you'd like your gameplay to be visible to other users by using Twitch to broadcast, or by using Game DVR to capture and share your gameplay footage.
<G-vec01169-002-s101><capture.aufzeichnen><de> Aktivieren Sie diese Option, wenn Sie Ihre Spielclips über Twitch an andere Benutzer übertragen möchten, oder wenn Sie mit Game DVR Spielclips aufzeichnen und teilen möchten.
<G-vec01169-002-s102><capture.aufzeichnen><en> This option enables the capture of a dump file.
<G-vec01169-002-s102><capture.aufzeichnen><de> Diese Option aktiviert das Aufzeichnen einer Speicherabbilddatei.
<G-vec01169-002-s122><capture.aufzeichnen><en> Movavi Screen Recorder is lightweight yet powerful video recording program that lets you capture streaming video and music from websites, save Skype calls, and preserve other screen recordings.
<G-vec01169-002-s122><capture.aufzeichnen><de> Movavi Screen Recorder ist eine einfache, jedoch leistungsfähige Videobearbeitungs-Software, die Ihnen hilft, Online-Videos und Musik von Webseiten aufzuzeichnen, Skype-Anrufe und andere Bildschirmaufnahmen zu speichern.
<G-vec01169-002-s123><capture.aufzeichnen><en> 9.14.camsexslut.com does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s123><capture.aufzeichnen><de> Adult Cams 18 gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s124><capture.aufzeichnen><en> Public Sex Chat Xxx Free Porn Cams does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s124><capture.aufzeichnen><de> Public Sex Chat Xxx Free Porn Cams gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s125><capture.aufzeichnen><en> Youporn does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s125><capture.aufzeichnen><de> Youporn gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s126><capture.aufzeichnen><en> Free Live Sex Chat does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s126><capture.aufzeichnen><de> Bongacams gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s127><capture.aufzeichnen><en> Free Sex Chat Online Young Girls does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s127><capture.aufzeichnen><de> Gay Cams - Free Live Sex Cam Chat gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s129><capture.aufzeichnen><en> 9.13. live-xcam | live camgirls does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s129><capture.aufzeichnen><de> 9.13. live-xcam | live camgirls gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s131><capture.aufzeichnen><en> Free Cams does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s131><capture.aufzeichnen><de> Free Cams gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s132><capture.aufzeichnen><en> Runetki Videochat does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s132><capture.aufzeichnen><de> Runetki Videochat gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s134><capture.aufzeichnen><en> BeblCams does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s134><capture.aufzeichnen><de> Video Ero Chat gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s135><capture.aufzeichnen><en> During the US presidential election campaign in 1992 he discovered a device he had constructed himself allowed him to capture unauthorized material transmitted via satellite to TV-stations, material that was not intended for use in public broadcasts.
<G-vec01169-002-s135><capture.aufzeichnen><de> Während der US-Präsidentschaftswahlen im Jahr 1992 entdeckt er, dass ein von ihm konstruierter Apparat in der Lage ist, nicht autorisierte Satellitenübertragungen, also Rohmaterial, das an Fernsehstationen, nicht aber an private Haushalte ausgestrahlt wird, aufzuzeichnen.
<G-vec01169-002-s136><capture.aufzeichnen><en> 1nudechat.com does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s136><capture.aufzeichnen><de> 1nudechat.com gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s137><capture.aufzeichnen><en> SexCamsgr.com does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s137><capture.aufzeichnen><de> SexCamsgr.com gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s138><capture.aufzeichnen><en> This module describes how to use the Windows Assessment and Deployment Kit (ADK) and Windows Deployment Services (WDS) to create, capture, and manage a desktop operating system image.
<G-vec01169-002-s138><capture.aufzeichnen><de> In dieser Unterrichtseinheit wird außerdem beschrieben, wie Windows Assessment and Deployment Kit (ADK) und Windows-Bereitstellungsdienste verwendet werden, um ein Desktopbetriebssystem-Image zu erstellen, aufzuzeichnen und zu verwalten.
<G-vec01169-002-s139><capture.aufzeichnen><en> Livebongacams.com does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s139><capture.aufzeichnen><de> GayChat.tv gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s140><capture.aufzeichnen><en> 9.13. bcams-online.com does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec01169-002-s140><capture.aufzeichnen><de> 9.13. bcams-online.com gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec01169-002-s240><capture.einfangen><en> To capture the invisible lines of the dance choreography by depicting the “pure signum”, i.e. the pure and very personal signature or trace of movement of a ballet dancer from the Vienna State Opera in colour on paper, Luis Casanova Sorolla immerses the guests at the Harmonie Vienna in the creative result of his “Signapura” works of art in many ways throughout the hotel.
<G-vec01169-002-s240><capture.einfangen><de> Die unsichtbaren Linien der tänzerischen Choreographie einfangen, in dem er das „pure Signum“, also die reine und ganz persönliche Unterschrift beziehungsweise Bewegungsspur eines Ballett-Tänzers der Wiener Staatsoper in Farbe auf Papier darstellt, lässt Luis Casanova Sorolla die Gäste des Harmonie Vienna im gesamten Hotel in vielfacher Weise in das schöpferische Ergebnis seiner „Signapura“-Kunstwerke eintauchen.
<G-vec01169-002-s241><capture.einfangen><en> As well as taking the family around the production plant, Mauro has also given them Grana Padano at different ageing stages to taste, so they can understand the difference between the cheese aged 9 months, over 16 months and the reserve variety, and thus capture the “vitality” of this constantly evolving product.
<G-vec01169-002-s241><capture.einfangen><de> Mauro hat die Familie nicht nur durch die Produktionsstätte geführt, sondern ihnen auch Grana Padano in verschiedenen Reifungsstadien zum Verkosten gegeben, damit sie den Unterschied zwischen dem 9 Monate, über 16 Monate alten Käse und der Riserva-Sorte verstehen und so die „Vitalität“ dieses sich ständig weiterentwickelnden Produktes einfangen können.
<G-vec01169-002-s242><capture.einfangen><en> To fully understand how much light, you need to capture for a scene, you need a way of measuring how much light is there.
<G-vec01169-002-s242><capture.einfangen><de> Um vollständig zu verstehen, wie viel Licht Sie für das Einfangen einer Szene benötigen, müssen Sie messen, wie viel Licht dort vorhanden ist.
<G-vec01169-002-s243><capture.einfangen><en> Elevating Patrick into a company-wide role will help us capture the imagination of players around the world by bringing an increased focus not just to the design of our games, but also the overarching creative energy we bring to every EA experience.
<G-vec01169-002-s243><capture.einfangen><de> Indem wir Patrick eine unternehmensweite Rolle übergeben, können wir die Vorstellungskraft von Spielern auf der ganzen Welt einfangen, weil wir uns nicht nur stärker auf das Design unserer Spiele konzentrieren, sondern auch auf die übergreifende Energie, die wir jedem EA-Erlebnis zuteil werden lassen.
<G-vec01169-002-s244><capture.einfangen><en> AV DVD Player - Morpher 3.0.53 AV DVD Player Morpher can play and morph audio - video streams in real-time, add effects to movies, convert video files to AVI & WMV, edit subtitles, capture images, record DVD audio, burn or erase VCD, and help design DVD/CD Covers.
<G-vec01169-002-s244><capture.einfangen><de> Zugehörige Schlüsselwörter: Notizen, Audio-Recorder, Aufnehmen, Recorder, Stimme, Ton-Aufnahme, Mikrofon, abspielen und morphen in realer Zeit, Effekte in Filme zufügen, Video Dateien in AVI und ASF konvertieren, Untertitel bearbeiten, Bilder einfangen, DVD Audio aufnehmen, VCD brennen oder löschen und DVD/CD Umschläge gestalten.
<G-vec01169-002-s245><capture.einfangen><en> Because of this you can find it straight away and you can easily capture it with a small telescope.
<G-vec01169-002-s245><capture.einfangen><de> Damit finden Sie ihn auf anhieb und können ihn schon mit einem kleinen Teleskop problemlos einfangen.
<G-vec01169-002-s247><capture.einfangen><en> The exclusive use of high-quality components and advanced technological features ensures, that LEWITT mics capture every sonic detail.
<G-vec01169-002-s247><capture.einfangen><de> Die ausschließliche Verwendung von Komponenten bester Qualität und innovative Features garantieren, dass LEWITT Mikrofone jedes akustische Detail einfangen.
<G-vec01169-002-s248><capture.einfangen><en> Ornamental tradition meets playful Boho: this timeless amulet with its paisley design in the shape of the Hand of Fatima plays with light and shade in a sophisticated manner and is believed to capture the life wishes of its wearer and protect them.
<G-vec01169-002-s248><capture.einfangen><de> Artikeldetails - trifft auf verspielte Boheme: Das zeitlose Amulett im Paisley-Design in Form der Hand Fatimas spielt raffiniert mit Licht und Schatten, soll die Lebenswünsche des Trägers einfangen und Schutz bieten.
<G-vec01169-002-s249><capture.einfangen><en> Inspired by the original works, these models contain all the tiny details that we could capture — whether the ornate detail of a jeweled card holder or the rich blue surface of a porcelain vase, it is all there.
<G-vec01169-002-s249><capture.einfangen><de> Inspiriert von den Originalarbeiten enthalten diese Modelle alle kleinen Details, die wir einfangen konnten – ob das kunstvolle Detail eines Schmuckkettenhalters oder die satte blaue Oberfläche einer Porzellanvase.
<G-vec01169-002-s250><capture.einfangen><en> Like today, for example, we were walking down the Highline and I saw something that I wanted to capture.
<G-vec01169-002-s250><capture.einfangen><de> Heute gingen wir beispielsweise die Highline entlang und ich sah etwas, das ich einfangen wollte.
<G-vec01169-002-s251><capture.einfangen><en> This category includes all images that capture the fascination of nature.
<G-vec01169-002-s251><capture.einfangen><de> Die Kategorie umfasst alle Fotografien, die das Faszinierende der Natur einfangen.
<G-vec01169-002-s252><capture.einfangen><en> D'Addario honors the Beatles' legacy with a unique collection of guitar picks, featuring iconic album covers and timeless images which capture the enduring spirit and essence of the "Fab Four. " Ominaisuudet
<G-vec01169-002-s252><capture.einfangen><de> D'Addario ehrt das Erbe der Beatles mit einer einzigartigen Auswahl an Gitarrenpicks, ikonischen Albumcovern und zeitlosen Bildern, die einfangen der dauerhafte Geist und das Wesen der "Fab Four".
<G-vec01169-002-s253><capture.einfangen><en> If there is a high proton density in the stellar plasma, even short-lived radionuclides can capture one or more protons before they beta decay.
<G-vec01169-002-s253><capture.einfangen><de> Steht jedoch eine hohe Protonendichte zur Verfügung, werden auch sehr kurzlebige Atomkerne noch ein oder mehrere Protonen einfangen, bevor sie zerfallen.
<G-vec01169-002-s254><capture.einfangen><en> While photos cannot capture the special ambiance of Coco Reef, we invite you to join us on this online tour of our resort.
<G-vec01169-002-s254><capture.einfangen><de> Während Fotos das besondere Ambiente des Coco Reef nicht einfangen können, laden wir Sie ein, an dieser Online-Tour durch unser Resort teilzunehmen.
<G-vec01169-002-s255><capture.einfangen><en> They modeled with ease and motivation, so that we were able to capture a great picture after another.
<G-vec01169-002-s255><capture.einfangen><de> Mit Leichtigkeit und Motivation haben wir ein tolles Bild nach dem anderen einfangen können.
<G-vec01169-002-s256><capture.einfangen><en> Founded by siblings Pia and Moritz Wüstenberg in 2012, London-based design studio Utopia & Utility has a knack for mixing materials in charmingly organic forms, specializing in vessels and lamps that capture the light—and our hearts.
<G-vec01169-002-s256><capture.einfangen><de> Die Geschwister Pia und Moritz Wüstenberg vom 2012 gegründeten Londoner Designstudio Utopia & Utility haben ein Händchen dafür, Materialien auf entzückende Weise zu organischen Gefäßen und Lampen zu machen, die das Licht einfangen und unsere Herzen höher schlagen lassen.
<G-vec01169-002-s257><capture.einfangen><en> For the capture of sand flies, place the trap at 1 meter high.
<G-vec01169-002-s257><capture.einfangen><de> Zum Einfangen der Sandmücken installieren Sie die Falle in etwa 1 Meter Höhe.
<G-vec01169-002-s258><capture.einfangen><en> The goal of a successful shooting, which will provide joy for you and the photographer alike, are great final results, which present you in many perspectives and capture your most beautiful, extraordinary and personal perspectives.
<G-vec01169-002-s258><capture.einfangen><de> Das Ziel eines erfolgreichen und bei dir, als auch beim Fotografen für Freude sorgendes Shooting sind tolle Endergebnisse, die dich in vielen Perspektiven darstellen und deine schönsten, außergewöhnlichsten, sowie persönlichsten Perspektiven einfangen.
<G-vec01169-002-s278><capture.einfangen><en> I just had a desire to capture the stories.
<G-vec01169-002-s278><capture.einfangen><de> Ich hatte nur den Wunsch, die Geschichten einzufangen.
<G-vec01169-002-s279><capture.einfangen><en> So my pictures are as natural and candid as possible and try to capture your personality and the moment in the most organic manner.
<G-vec01169-002-s279><capture.einfangen><de> Daher sind meine Bilder so natürlich und aufrichtig wie möglich und versuchen, Ihre Persönlichkeit und den Moment auf organischste Weise einzufangen.
<G-vec01169-002-s280><capture.einfangen><en> In the following photos I attempted to capture my feelings about a life amongst the mountains.
<G-vec01169-002-s280><capture.einfangen><de> In den folgenden Bildern versuchte ich meine Gefühle über ein Leben zwischen den Bergen einzufangen.
<G-vec01169-002-s281><capture.einfangen><en> Bring your camera to capture the marvelous scenery and variety of wildlife including whales, seals, dolphins, penguins and other marine life.
<G-vec01169-002-s281><capture.einfangen><de> Vergessen Sie nicht Ihre Kamera, um die einzigartige Natur und die reiche Tierwelt einzufangen, wie etwa Wale, Robben, Delfine, Pinguine und andere Meeresbewohner.
<G-vec01169-002-s282><capture.einfangen><en> After big hits such as Berlin Calling, Victoria, and B-Movie now comes a new attempt to capture the one thing that seems to be the city's main trademark. With Night Out,... read more
<G-vec01169-002-s282><capture.einfangen><de> Nach großen Hits wie "Berlin Calling", "Victoria" und "B-Movie" kommt nun ein neuer Versuch, das Einzige in einem Film einzufangen, was das Markenzeichen der Stadt zu sein...
<G-vec01169-002-s283><capture.einfangen><en> The cold blue and grey tones help capture the beauty of a rough and harsh environment hereby representing the essence of modern Nordic aesthetics. Product Details
<G-vec01169-002-s283><capture.einfangen><de> Die kühlen Blau- und Grautöne tragen dazu bei, die Schönheit der rauen und schroffen Natur einzufangen – und damit auch das Wesen der modernen skandinavischen Ästhetik.
<G-vec01169-002-s284><capture.einfangen><en> For a good TV broadcast it is important to capture the situation not only from one direction with the two cameras.
<G-vec01169-002-s284><capture.einfangen><de> Dabei gilt es die Situation nicht nur aus einer Richtung mit den beiden Kameras einzufangen.
<G-vec01169-002-s285><capture.einfangen><en> Interview: In the interview, Israeli director Kat Tolkovsky tells more about her intimate film „Nabbin„, the message behind it and how important it was to her to capture the Roma family in a sensitive way.
<G-vec01169-002-s285><capture.einfangen><de> Interview: Im Gespräch erzählt die israelische Regisseurin Kat Tolkovsky mehr über ihren intimen Film „Nabbin“, welche Botschaft dahinter steckt und wie wichtig es ihr war, die Roma Familie auf eine sensible Weise einzufangen.
<G-vec01169-002-s286><capture.einfangen><en> We’ve tried to capture some of the magic conveyed by the building, transforming our rooms into cosy settings full of positive sensations.
<G-vec01169-002-s286><capture.einfangen><de> Wir haben versucht, ein wenig von der Magie einzufangen, die das Gebäude ausstrahlt, indem wir sie in einladende Winkel voller positiver Sensationen verwandelt haben.
<G-vec01169-002-s287><capture.einfangen><en> Sometimes the images revolve around the events, only to come to rest at other moments in a concentrated standstill through which the film seeks to capture its spirits.
<G-vec01169-002-s287><capture.einfangen><de> Manchmal umkreisen die Bilder das Geschehen, dann wieder ist es konzentrierter Stillstand, durch den der Film seine Geister einzufangen sucht.
<G-vec01169-002-s288><capture.einfangen><en> My all sense organs were rushing to capture His beautiful Krishna like image.
<G-vec01169-002-s288><capture.einfangen><de> All meine Sinne beeilten sich, Sein schönes krishna-ähnliches Aussehen einzufangen.
<G-vec01169-002-s289><capture.einfangen><en> This unmatched super camera system includes a SuperZoom Lens, a 40 MP Super Sensing Camera, a 20 MP Ultra Wide Angle Lens, and a HUAWEI TOF Camera, giving you the freedom to capture your incredible moments.
<G-vec01169-002-s289><capture.einfangen><de> Dieses überlegene Kamerasystem mit SuperZoom-Objektiv, einer 40 MP-Super-Sensing-Kamera, einem 20 MP-Ultraweitwinkelobjektiv und einer HUAWEI-TOF-Kamera gibt Dir die Freiheit, einzigartige Momente für immer photographisch einzufangen.
<G-vec01169-002-s290><capture.einfangen><en> It was my first orthodox wedding and it was really interesting to capture the different rites.
<G-vec01169-002-s290><capture.einfangen><de> Es war meine erste orthodoxe Trauung und es war super interessant die unterschiedlichen Riten einzufangen.
<G-vec01169-002-s291><capture.einfangen><en> Bring your camera and try to capture the medieval atmosphere.
<G-vec01169-002-s291><capture.einfangen><de> Zücken Sie Ihre Kamera und versuchen Sie, die mittelalterliche Atmosphäre einzufangen.
<G-vec01169-002-s292><capture.einfangen><en> Preferably, the trapping field is adapted to radially capture the ions of at least.
<G-vec01169-002-s292><capture.einfangen><de> Vorzugsweise ist das Einfangfeld dazu ausgelegt, die Ionen wenigstens radial einzufangen.
<G-vec01169-002-s294><capture.einfangen><en> Visit to St.Petersburg, Russia will give you a unique chance to capture Peterhof beauty from its sources.
<G-vec01169-002-s294><capture.einfangen><de> Ein Besuch von St. Petersburg in Russland bietet Ihnen die einmalige Gelegenheit, die Schönheit von Peterhof aus seinen Quellen einzufangen.
<G-vec01169-002-s295><capture.einfangen><en> Transformers landed on a new planet to capture it.
<G-vec01169-002-s295><capture.einfangen><de> Transformers landete auf einem neuen Planeten, um es einzufangen.
<G-vec01169-002-s296><capture.einfangen><en> The main idea behind the production was to capture real life situations and then render cars over the top.
<G-vec01169-002-s296><capture.einfangen><de> Echte Situationen einzufangen und dort Autos hinein zu rendern war die Grund-Idee bei der Produktion.
<G-vec01169-002-s421><capture.einfangen><en> Each individual Pokémon is assigned CP at capture, which indicates how well that particular Pokémon will perform in battle.
<G-vec01169-002-s421><capture.einfangen><de> Jedem individuellen Pokémon werden beim Fangen WP zugewiesen, die angeben, wie gut dieses Pokémon im Kampf ist.
<G-vec01169-002-s422><capture.einfangen><en> And Jesus said to them, “Have you come out as against a robber, with swords and clubs to capture me?
<G-vec01169-002-s422><capture.einfangen><de> 26,55 Zu der Stunde sprach Jesus zu der Schar: Ihr seid ausgezogen wie gegen einen Räuber mit Schwertern und mit Stangen, mich zu fangen.
<G-vec01169-002-s423><capture.einfangen><en> Battaglini’s insistence on laying bare the inherent relativity of our lives is a fundamental characteristic of the work featured in this publication; these compositions capture the very essence of an artist whose desire to shatter the conventions of perceivable reality seems linked to a passion for art and his interest in diverse genres.
<G-vec01169-002-s423><capture.einfangen><de> Battaglinis Beharren auf der Verlegung der inhärenten Relativität unseres Lebens ist ein grundlegendes Merkmal des Werkes, das in dieser Veröffentlichung vorgestellt wird; Diese Kompositionen fangen das Wesen eines Künstlers ein, dessen Wunsch, die Konventionen der wahrnehmbaren Wirklichkeit zu zerstören, mit einer Leidenschaft für die Kunst und seinem Interesse an verschiedenen Genres verbunden ist.
<G-vec01169-002-s424><capture.einfangen><en> Other images by Brazilian photographer Mauricio Lima capture the exhaustion, the hardships and the helplessness.
<G-vec01169-002-s424><capture.einfangen><de> Andere Bilder des brasilianischen Fotografen Mauricio Lima fangen Erschöpfung, Bedrängnis und das Ausgeliefertsein ein.
<G-vec01169-002-s425><capture.einfangen><en> KIESELMANN dirt traps separate liquids from unwanted solids and capture these contaminants safely and reliably.
<G-vec01169-002-s425><capture.einfangen><de> KIESELMANN Schmutzfänger trennen Flüssigkeiten von unerwünschten Feststoffen und fangen diese Verunreinigungen sicher und zuverlässig auf.
<G-vec01169-002-s426><capture.einfangen><en> Seemingly drawn using an office computer during the meaningless hours spent at work, these cartoons capture in mercifully short scenes the repetitive tragedies of office life – pointless buzzwords, wasted restructuring exercises, repeated outsourcing and endemic insecurity.
<G-vec01169-002-s426><capture.einfangen><de> Vermutlich an einem Bürocomputer während sinnloser Arbeitsstunden gezeichnet, fangen diese Cartoons in kurzen Szenen die immer wiederkehrenden Tragödien des Bürolebens ein – leere Schlagworte, vergebliche Umstrukturierungsmaßnahmen, wiederholtes Outsourcing und endemische Unsicherheit.
<G-vec01169-002-s427><capture.einfangen><en> Particularly observant Osirans will have the unique chance to capture extremely elusive dragons from the Far East for seven days.
<G-vec01169-002-s427><capture.einfangen><de> Das Mondfest beginnt und besonders aufmerksame Osira werden in der Lage sein, sieben Tage lang extreme seltene Drachen aus dem Fernen Osten zu fangen.
<G-vec01169-002-s428><capture.einfangen><en> Gravel Cologne perfumes capture this spirit.
<G-vec01169-002-s428><capture.einfangen><de> Gravel Cologne Parfums fangen diesen Geist ein, wie keine andere Marke.
<G-vec01169-002-s429><capture.einfangen><en> This cage is specially made to capture Spirits.
<G-vec01169-002-s429><capture.einfangen><de> Dieser Käfig wurde eigens gefertigt, um Geister zu fangen.
<G-vec01169-002-s430><capture.einfangen><en> The traditional portraits capture the eye of every guest and match the design of the Villa.
<G-vec01169-002-s430><capture.einfangen><de> Die traditionellen Portraits fangen das Auge eines jeden Gastes ein und passen zum Design der Villa.
<G-vec01169-002-s431><capture.einfangen><en> Fog nets capture these drops of fog.
<G-vec01169-002-s431><capture.einfangen><de> Nebelnetze fangen diese Nebeltropfen ein.
<G-vec01169-002-s432><capture.einfangen><en> If you kill the dog you will be unable to capture it ever again.
<G-vec01169-002-s432><capture.einfangen><de> Falls du den Hund tötest, kannst du ihn niemals wieder fangen.
<G-vec01169-002-s433><capture.einfangen><en> When this new type of toy is placed directly into the Traptanium PortalTM, Portal Masters can "capture" a variety of special villains from the game and magically transport them from Skylands into the real world. Toys to Life, Life to Toys - Players will experience an exciting new level of Skylanders innovation through the Traptanium Portal, a new ring of magical energy which reverses the magic of the toys to life category by letting players bring digital characters into the physical world.
<G-vec01169-002-s433><capture.einfangen><de> Indem sie ein solches Spielzeug direkt ins Traptanium Portal stecken, können die Portalmeister eine Reihe von speziellen Schurken aus dem Spiel ´´fangen´´ und sie auf wundersame Weise aus den Skylands heraus in die reale Welt Spielzeuge zum Leben, Leben in Spielzeuge - Durch das Traptanium Portal, einen neuen Ring voller magischer Energie, der die Magie der zum Leben erwachenden Spielzeuge umkehrt und ihnen ermöglicht, digitale Charaktere in die reale Welt zu holen, erleben die Spieler eine spannende neue Innovation in der Skylanders-Reihe.
<G-vec01169-002-s434><capture.einfangen><en> Her photographs capture the special atmosphere of large cities such as Shanghai, Moscow, Chicago or Berlin.
<G-vec01169-002-s434><capture.einfangen><de> Ihre Fotografien fangen die spezifische Atmosphäre von Millionenstädten wie Shanghai, Moskau, Chicago oder Berlin ein.
<G-vec01169-002-s435><capture.einfangen><en> When he visits Kakashi later and finds Kakashi unconscious, he learns that he was defeated by Itachi, who has returned to Konoha to capture Naruto.
<G-vec01169-002-s435><capture.einfangen><de> Als er später Kakashi ohnmächtig im Krankenhaus findet, erfährt er, dass Kakashi von Itachi, der kurz in Konoha war, um Naruto zu fangen, besiegt wurde.
<G-vec01169-002-s436><capture.einfangen><en> And Saul and his men enclosed David and his men in the manner of a crown, so that they might capture them.
<G-vec01169-002-s436><capture.einfangen><de> David aber eilte, Saul zu entgehen, während Saul samt seinen Männern David und seine Männer umstellte, um sie zu fangen.
<G-vec01169-002-s437><capture.einfangen><en> I think it’s fantastic to be able to capture people as they are and especially as it is.
<G-vec01169-002-s437><capture.einfangen><de> Ich finde es fantastisch, Menschen so und so wie sie sind zu fangen.
<G-vec01169-002-s438><capture.einfangen><en> Five game-changing innovations revolutionize artificial intelligence, dribbling, ball control and physical play to create a true battle for possession across the entire pitch, deliver freedom and creativity in attack, and capture all the drama and unpredictability of real-world football.
<G-vec01169-002-s438><capture.einfangen><de> Die Verbesserungen in Bereichen wie künstliche Intelligenz, Dribbling, Ballkontrolle und Kollisionen machen den Kampf um den Ball so spannend wie nie, bieten im Angriff ungeahnte Freiheiten, ermöglichen kreative Spielzüge und fangen die Dramatik des echten Fußballs ein.
<G-vec01169-002-s439><capture.einfangen><en> Marquard's photographs capture the singular essence of these individuals and at the same time transform them into icons of our time transcending the individual.
<G-vec01169-002-s439><capture.einfangen><de> Marquardts Fotografien fangen die Unverwechselbarkeit dieser Individuen ein und verwandeln sie gleichzeitig zu Ikonen unserer Zeit, die über das Individuelle hinauswachsen.
<G-vec01169-002-s512><capture.einfangen><en> by the facets of the gemstones and the metal surface not only capture the glaze of the wearer, but also that of the beholder. Hammered Gold
<G-vec01169-002-s512><capture.einfangen><de> Licht, das von den Facetten der Edelsteine und der Oberfläche des Metalls gespiegelt wird, fängt nicht nur den Blick des Trägers, sondern auch den des Betrachters.
<G-vec01169-002-s513><capture.einfangen><en> Accordingly, she didn’t just capture a certain aesthetic, but the photos also look as spontaneous as they were probably created.
<G-vec01169-002-s513><capture.einfangen><de> Dementsprechend fängt sie nicht nur eine bestimmte Ästhetik ein, sondern die Bilder wirken oft so spontan wie sie vermutlich auch entstanden sind.
<G-vec01169-002-s514><capture.einfangen><en> Our muslin is now even more magical with these whimsical girl bibs that capture the sassy spirit of Marie, the fancy feline featured in Disney’s The Aristocats.
<G-vec01169-002-s514><capture.einfangen><de> Unser Musselin ist mit den Lätzchen für Jungen jetzt sogar noch zauberhafter und fängt die Stimmung des Dschungels mit den sorglosen Momenten aus dem Leben von Disneys König der Löwen wunderbar ein.
<G-vec01169-002-s516><capture.einfangen><en> Nude by Nature Natural Glow Loose Bronzer is designed to capture the warmth of healthy, sun-kissed skin.
<G-vec01169-002-s516><capture.einfangen><de> Der Nude by Nature Natural Glow Loose Bronzer fängt die Wärme von gesunder, sonnengeküsster Haut ein.
<G-vec01169-002-s517><capture.einfangen><en> The dress by OASIS capture all moments: The shimmer of crystal glasses of champagne, the prospering atmosphere and the glowing of the guest eyes.
<G-vec01169-002-s517><capture.einfangen><de> Das Kleid von OASIS fängt alles ein: Das Glänzen der kristallenen Champagner Gläser, die florierende Stimmung, die leuchtenden Augen der Gäste.
<G-vec01169-002-s518><capture.einfangen><en> She is known as a person who loves to help out, laughs a lot and likes to capture special moments and places.
<G-vec01169-002-s518><capture.einfangen><de> Sie ist bekannt für ihre hilfreiche Art, lacht viel und fängt gerne spezielle Momente und Orte ein.
<G-vec01169-002-s519><capture.einfangen><en> Rings The light reflected by the facets of the gemstones and the metal surface not only capture the glaze of the wearer, but also that of the beholder.
<G-vec01169-002-s519><capture.einfangen><de> Das Licht, das von den Facetten der Edelsteine und der Oberfläche des Metalls gespiegelt wird, fängt nicht nur den Blick des Trägers, sondern auch den des Betrachters.
<G-vec01169-002-s520><capture.einfangen><en> A better lens assembly can also capture more distant rays and can focus them onto the sensor.
<G-vec01169-002-s520><capture.einfangen><de> Ein besseres Objektiv fängt selbst weiter entferntere Lichtstrahlen ein.
<G-vec01169-002-s521><capture.einfangen><en> Maayan Strauss, (Israel) is striving to capture the poetic elements hidden within the most practical, foul, and coveted treasure: OIL.
<G-vec01169-002-s521><capture.einfangen><de> Maayan Strauss (Israel) fängt die poetischen Elemente versteckt in dem nützlichsten, stinkendsten und begehrtesten Schatz: ÖL.
<G-vec01169-002-s522><capture.einfangen><en> Beginning in 2000, Hamid Sardar immersed himself in this fascinating people’s way of life, following them throughout their daily rituals, hunting expeditions, and spiritual practices to capture their centuries-old practices.
<G-vec01169-002-s522><capture.einfangen><de> Seit dem Jahr 2000 begleitet Hamid Sardar das Leben dieser faszinierenden Gemeinschaften, verfolgt ihre Alltagsrituale, Jagdzüge und spirituellen Praktiken und fängt so ihre jahrhundertealten Traditionen ein.
<G-vec01169-002-s523><capture.einfangen><en> No tour will capture the imagination or has as much historical significance as one to the Galapagos Islands.
<G-vec01169-002-s523><capture.einfangen><de> Keine Tauch Safari fängt die Phantasie ein, oder hat so viel historische Bedeutung, wie eine an den Galapagos-Inseln.
<G-vec01169-002-s526><capture.einfangen><en> I feel like in film as well as the intentions are – sometimes it doesn’t capture the realities, even just the quiet moments.
<G-vec01169-002-s526><capture.einfangen><de> Ich habe manchmal das Gefühl, dass man im Film nur versuchen kann, es richtig darzustellen – manchmal fängt so ein Film die Realität nicht ein, nicht einmal die ruhigen Momente.
<G-vec01169-002-s527><capture.einfangen><en> This air filter will capture other large particle contaminants to keep surfaces free of dust longer in your home.
<G-vec01169-002-s527><capture.einfangen><de> Dieser Luftfilter fängt andere große Partikelkontaminationen auf, um die Oberflächen länger frei von Staub in Ihrem Haus zu halten.
<G-vec01169-002-s528><capture.einfangen><en> “Man of Fire” lurks in the shadows of Dark Punk music, and will capture you with its powerful and contagious rhythm, pounding bass lines, and the leading guitars.
<G-vec01169-002-s528><capture.einfangen><de> "Man on Fire" lauert im Shatten von Dark Punk und fängt dich mit den kraftvollen und stetigen Rhythmus, den treibenden Bass und Leadgitarren.
<G-vec01169-002-s529><capture.einfangen><en> The warm October sun helps capture the harmony and happiness of the day.
<G-vec01169-002-s529><capture.einfangen><de> Die warme Oktober-Sonne fängt die Harmonie und Zufriedenheit des Tages ein.
<G-vec01169-002-s530><capture.einfangen><en> And this bitter alas fitting expression does capture the extremely stressful situation of Korean students to a frighteningly accurate degree.
<G-vec01169-002-s530><capture.einfangen><de> Diese bittere, doch leider zutreffende Beschreibung fängt die extrem stressreiche Situation der koreanischen Studierenden erschreckend gut ein.
<G-vec01169-002-s455><capture.festhalten><en> With my pictures I want to capture extraordinary views and impressive moments and make them visible to other people.
<G-vec01169-002-s455><capture.festhalten><de> Mit meinen Bildern möchte ich außergewöhnliche Ansichten und eindrucksvolle Augenblicke festhalten und für andere Menschen sichtbar machen.
<G-vec01169-002-s456><capture.festhalten><en> It’s something you need to capture for the rest of your life.
<G-vec01169-002-s456><capture.festhalten><de> Das sind Dinge, die Sie den Rest Ihres Lebens festhalten sollten.
<G-vec01169-002-s457><capture.festhalten><en> The scenes enable you to capture specific subjects, whilst the aperture and shutter speed priority offer the photographer plenty of freedom to unleash endless creativity.
<G-vec01169-002-s457><capture.festhalten><de> Die Szenen erlauben das Festhalten spezifischer Motive und die Blenden- und Verschlusszeitvorauswahl bietet dem Fotografen alle Freiheit, um sich kreativ auszuleben.
<G-vec01169-002-s458><capture.festhalten><en> Creating a “meeting debrief” is an easy way to capture and remember details about your contacts.
<G-vec01169-002-s458><capture.festhalten><de> In einer Art Zusammenfassung könnt ihr Informationen zu euren Kontakten festhalten.
<G-vec01169-002-s459><capture.festhalten><en> With it, you can capture snapshots of your group work.
<G-vec01169-002-s459><capture.festhalten><de> Mit ihr können Sie Momentaufnahmen Ihrer Gruppenarbeit festhalten.
<G-vec01169-002-s460><capture.festhalten><en> We offer video services for weddings, baptisms, birthdays, and other events that you wish to capture onto video or DVD.
<G-vec01169-002-s460><capture.festhalten><de> Wir bieten Videodienste für Hochzeiten, Taufen, Geburtstage und andere Anlässe an, die Sie auf Video oder DVD festhalten wollen.
<G-vec01169-002-s461><capture.festhalten><en> Some moments you just have to capture in a picture.
<G-vec01169-002-s461><capture.festhalten><de> Manche Augenblicke muss man einfach in einem Bild festhalten.
<G-vec01169-002-s462><capture.festhalten><en> In an ifolor photo book you can capture the best snapshots and remember the unique atmosphere of a festival once again.
<G-vec01169-002-s462><capture.festhalten><de> In einem ifolor Fotobuch können Sie die besten Schnappschüsse festhalten und sich so noch einmal an die einzigartige Atmosphäre eines Festivals zurückerinnern.
<G-vec01169-002-s463><capture.festhalten><en> Capture priceless moments: You'll be designing your own photo book in a matter of minutes.
<G-vec01169-002-s463><capture.festhalten><de> Schöne Momente festhalten: In nur wenigen Minuten gestalten Sie Ihr eigenes Fotobuch.
<G-vec01169-002-s464><capture.festhalten><en> If you want to really let off steam in the world and want to capture the many small inconspicuous things impressively, you can’t avoid buying a macro lens.
<G-vec01169-002-s464><capture.festhalten><de> Wenn Du Dich in der Welt richtig austoben möchtest und die vielen kleinen unscheinbaren Dinge eindrucksvoll festhalten möchtest, kommst Du um den Kauf eines Makro-Objektives nicht herum.
<G-vec01169-002-s465><capture.festhalten><en> MB: I never really believed in style in photography, but more in a way to approach and see the subjects one is interested in trying to capture.
<G-vec01169-002-s465><capture.festhalten><de> MB: Was die Fotografie betrifft, so habe ich nie wirklich an Stile geglaubt, sondern eher an eine Art der Herangehensweise und des Betrachtens von Motiven, die man gerne festhalten möchte.
<G-vec01169-002-s466><capture.festhalten><en> Equipped with a DSLR she was asked to capture what nature means to her and later develop her own negatives in the school’s darkroom.
<G-vec01169-002-s466><capture.festhalten><de> Sie sollte in einem Foto festhalten, was die Natur für sie bedeutet und das Foto in der schuleigenen Dunkelkammer entwickeln.
<G-vec01169-002-s467><capture.festhalten><en> Instagram is a simple way to capture and share the world's moments.
<G-vec01169-002-s467><capture.festhalten><de> Mit Instagram kannst du die Augenblicke der Welt festhalten und teilen.
<G-vec01169-002-s468><capture.festhalten><en> The great photographer Marianne Sabado got one of the sought after keys and was honored to capture all the proceedings behind the adorable iron gate for us.
<G-vec01169-002-s468><capture.festhalten><de> Die bemerkenswerte Fotografin Marianne Sabado bekam ebenfalls einen der begehrten Schlüssel und durfte die Geschehnisse hinter dem bezaubernden Eisentor für uns festhalten.
<G-vec01169-002-s469><capture.festhalten><en> The audience is invited to become part of meter and take part in the competition: write a text, capture a moment with the camera or create an illustration that deals with a core theme and shows a personal view of the design cosmos.
<G-vec01169-002-s469><capture.festhalten><de> Das Publikum ist eingeladen Teil von meter zu werden und beim Wettbewerb mitzumachen: einen Text schreiben, einen Moment mit der Kamera festhalten oder eine Illustration gestalten, die sich mit einem Kernthema befasst und einen persönlichen Blick auf den Designkosmos zeigt.
<G-vec01169-002-s470><capture.festhalten><en> The Xperia XZs has Super slow motion video recording, plus Predictive Capture that’s ready to take photos before you are.
<G-vec01169-002-s470><capture.festhalten><de> Das Xperia XZs kann Videos in Super slow motion festhalten und verfügt über vorhersagende Aufnahmen – diese neue Technologie nimmt bereits Fotos auf, während du noch überlegst auszulösen.
<G-vec01169-002-s471><capture.festhalten><en> The processor, in combination with the fast autofocus, ensure that the camera reacts quickly, so that you can also capture fun action moments.
<G-vec01169-002-s471><capture.festhalten><de> Der Prozessor sorgt, in Kombination mit dem schnellen Autofokus, dafür, dass die Kamera schnell reagiert, somit kann man auch schnelle Aktionsmomente festhalten.
<G-vec01169-002-s472><capture.festhalten><en> Wandering into Sultanahmet is like stepping back in time, so make sure your camera is fully charged, as you will want to capture every aspect of it. 3.
<G-vec01169-002-s472><capture.festhalten><de> In Sultanahmet zu spazieren ist wie eine Reise in die Vergangenheit, also vergewissert euch, dass eure Kamera aufgeladen ist, da ihr bestimmt alle Winkel der Gegend festhalten wollt.
<G-vec01169-002-s473><capture.festhalten><en> This means that we always work in tandem during a shoot so that we can see more and capture more in pictures.
<G-vec01169-002-s473><capture.festhalten><de> Das heißt, dass wir bei einem Shoot immer zu zweit arbeiten, sodass wir viel mehr sehen und viel mehr bildlich festhalten können.
<G-vec01169-002-s474><capture.festhalten><en> Many photographers were at drinktec 2013 to capture the atmosphere of the exhibition in pictures.
<G-vec01169-002-s474><capture.festhalten><de> Zahlreiche Fotografen waren auf der drinktec 2013 unterwegs, um die Atmosphäre der Messe in Bildern festzuhalten.
<G-vec01169-002-s475><capture.festhalten><en> If you are in France, Germany, Spain or the UK, we would love to invite you to capture what you see, share it and be part of a the pan-european Flickr Calendar 2014 project.
<G-vec01169-002-s475><capture.festhalten><de> Wenn du in Frankreich, Deutschland, Spanien oder Großbritannien wohnst, möchten wir dich dazu einladen, deine Umgebung im Bild festzuhalten, mit uns zu teilen und Teil des paneuropäischen Flickr Projekts für unseren Kalendar 2014 zu werden.
<G-vec01169-002-s476><capture.festhalten><en> In her quest to capture the little pieces of life, Kelly has photographed hundreds of newborn babies, mentored photographers and held newborn posing classes across nearly 20 countries.
<G-vec01169-002-s476><capture.festhalten><de> In ihrem Streben, die kleinen und doch so bedeutenden Momente des Lebens festzuhalten, hat sie hunderte von neugeborenen Babys fotografiert, als Mentorin für Fotografen fungiert und Kurse über Neugeborenenportraits in fast 20 Ländern gegeben.
<G-vec01169-002-s477><capture.festhalten><en> To capture his observations of his excursions in images, he invited the Neapolitan artist Peter Fabris to accompany him.
<G-vec01169-002-s477><capture.festhalten><de> Um seine Beobachtungen in Bildern festzuhalten, ließ er sich auf seinen Exkursionen durch den Neapolitaner Künstler Peter Fabris begleiten.
<G-vec01169-002-s478><capture.festhalten><en> In Norway, Richard spent time with The Lofoten Seaweed Company to capture the richness of the islands and local people.
<G-vec01169-002-s478><capture.festhalten><de> Richard verbrachte in Norwegen Zeit mit der Lofoten Seaweed Company, um die Vielfalt der Inseln und der Einwohner festzuhalten.
<G-vec01169-002-s479><capture.festhalten><en> Another touchdown, another home run, another victory lane… I was just one of a gang of photographers trying to capture the same moment.
<G-vec01169-002-s479><capture.festhalten><de> Noch ein Touchdown, noch ein Homerun, noch eine Siegesserie... Ich war nur einer von vielen Fotografen, die versuchten, den gleichen Moment festzuhalten.
<G-vec01169-002-s480><capture.festhalten><en> The cameras had to make an effort to capture all the impressions.
<G-vec01169-002-s480><capture.festhalten><de> Die Kameras bekamen wieder viel zu tun, um all die Eindrücke festzuhalten.
<G-vec01169-002-s481><capture.festhalten><en> In fact, many painters and photographers love visiting Mallorca at this time of year to capture the moment when the island seems covered in snow.
<G-vec01169-002-s481><capture.festhalten><de> Tatsächlich reisen viele Maler und Fotografen zu dieser Zeit nach Mallorca, um den Moment festzuhalten, in dem die Insel wie „verschneit" aussieht.
<G-vec01169-002-s482><capture.festhalten><en> Once these hito have developed creative and imaginative ideas to capture the business's upward potential, the kane, or money, should be allocated to the specific ideas and programs generated by individual managers.
<G-vec01169-002-s482><capture.festhalten><de> Sobald dieses Hito die kreativen und phantasiereichen Ideen entwickelt hat, um das Aufwärtspotential des Unternehmens festzuhalten, sollte das Kane oder das Geld den spezifischen Ideen und den Programmen zugeteilt werden, die von den einzelnen Managern erzeugt werden.
<G-vec01169-002-s483><capture.festhalten><en> This filigree bridge crafted from blackened 925 Sterling silver offers you the possibility to express your very own feelings and to capture your personal moments of happiness for all eternity.
<G-vec01169-002-s483><capture.festhalten><de> Die filigrane Brücke aus geschwärztem 925er Sterlingsilber gibt Ihnen die Möglichkeit, mit einer kostenlosen Gravur Ihren Gefühlen Ausdruck zu verleihen und Ihre persönlichen Glücksmomente für die Ewigkeit festzuhalten.
<G-vec01169-002-s484><capture.festhalten><en> Learn more about the range below, and find the best model to capture your memories in perfect focus.
<G-vec01169-002-s484><capture.festhalten><de> Nachfolgend erfahren Sie mehr über unsere Produktreihe und finden das optimale Modell, um Ihre Erinnerungen perfekt fokussiert festzuhalten.
<G-vec01169-002-s486><capture.festhalten><en> Therefore I decided that my art can be my way, to capture these moments with the hope that the viewer will be encouraged to take more time to look at these details in daily life.
<G-vec01169-002-s486><capture.festhalten><de> Somit entschied ich, dass die Kunst mein Weg sein kann, diese Momente festzuhalten, in der Hoffnung, dass es die Betrachter dazu ermuntert, sich mehr Zeit zu nehmen diese Einzelheiten im täglichen Leben zu finden und zu beachten.
<G-vec01169-002-s487><capture.festhalten><en> However, you may want to at least capture the basic ideas in these chapters.
<G-vec01169-002-s487><capture.festhalten><de> Gleichwohl kann es wichtig sein, deren Inhalte zumindest in Grundzügen festzuhalten.
<G-vec01169-002-s488><capture.festhalten><en> In addition, the personal companion allows you to capture creative ideas, to write down experiences while traveling or to draw sketches of monumental buildings.
<G-vec01169-002-s488><capture.festhalten><de> Darüber hinaus ermöglicht der persönliche Begleiter, kreative Ideen festzuhalten, Erlebnisse auf Reisen niederzuschreiben oder Skizzen von monumentalen Bauwerken zu zeichnen.
<G-vec01169-002-s489><capture.festhalten><en> I was driven by the need to capture those small situations, which seem to get lost in the rush of everyday life, without expectations and in the moment...well I`m still looking for them.
<G-vec01169-002-s489><capture.festhalten><de> Ich war getrieben von dem Bedürfnis, diese kleinen Situationen festzuhalten, die sich scheinbar im Alltag des Alltags ohne Erwartungen und im Moment verlieren... Nun, ich suche immer noch nach ihnen.
<G-vec01169-002-s490><capture.festhalten><en> Ideal if you’re a budding photographer wanting to get closer to the action, the new PowerShot camera features high zoom, new creative shooting modes and a range of connectivity features, giving you the ability to capture and share special moments with ease.
<G-vec01169-002-s490><capture.festhalten><de> Sie bringen mit ihrer hohen Zoomleistung jeden Fotografen näher an das Geschehen, bieten neue Kreativmodi und viele Optionen, um besondere Momente noch einfacher festzuhalten und zu teilen.
<G-vec01169-002-s491><capture.festhalten><en> Like no other photographer Howard Roffman manages to capture images of young men and their passions.
<G-vec01169-002-s491><capture.festhalten><de> Junge Männer auf der Suche nach Zärtlichkeit: Wie kaum ein anderer Fotograf schafft es der Amerikaner Howard Roffman, die Schönheit der Jugend in zeitlosen Fotos festzuhalten.
<G-vec01169-002-s492><capture.festhalten><en> Not for pushig my luck, but to capture the pursuit and yearn of fortune of those whow were ready to play the game.
<G-vec01169-002-s492><capture.festhalten><de> Nicht etwa um mein Glück zu wagen, sondern um das Ringen, Jagen und Bangen anderer um und nach eben jenem stimmungsvoll im Bilde festzuhalten.
<G-vec01169-002-s568><capture.festhalten><en> Capture those special moments in a Skype call with your loved ones or record important meeting with colleagues.
<G-vec01169-002-s568><capture.festhalten><de> Halten Sie besondere Momente in einem Skype-Anruf mit Ihren Lieben fest oder zeichnen Sie wichtige Besprechungen mit Kollegen auf.
<G-vec01169-002-s569><capture.festhalten><en> We'll also have a promotion area in each central station, come visit us and we'll send you to the city of love, Paris, and capture this moment with a polaroid-picture for you.
<G-vec01169-002-s569><capture.festhalten><de> Dort verführen wir unsere Besucher einen Augenblick in die Stadt der Liebe, nach Paris, und halten diesen Moment mit einem Polaroid-Foto für die Besucher fest.
<G-vec01169-002-s570><capture.festhalten><en> These pellets capture the calcium and magnesium ions (which cause the limescale) and replace them with harmless sodium ions.
<G-vec01169-002-s570><capture.festhalten><de> Diese Körner halten die Kalzium- und Magnesiumionen (die für die Kalkablagerung verantwortlich sind) fest und ersetzen sie durch unschädliche Natriumionen.
<G-vec01169-002-s571><capture.festhalten><en> Power-Lifting Suction works together with an advanced filter to capture 99% of dog and cat allergens. So long, pet hair
<G-vec01169-002-s571><capture.festhalten><de> Das fortschrittliche Filtersystem fängt 99 % aller Schimmelpilze, Pollen, Hausstaubmilben, Hunde- und Katzenallergene ein, um Hautschuppen aus Ihrem Leben zu halten.
<G-vec01169-002-s572><capture.festhalten><en> For Christine, photos capture a very special moment for eternity.
<G-vec01169-002-s572><capture.festhalten><de> Für Christine halten Fotos einen ganz besonderen Moment für die Ewigkeit fest.
<G-vec01169-002-s573><capture.festhalten><en> These data centres capture the heat generated by the servers and distribute it to the surrounding building.
<G-vec01169-002-s573><capture.festhalten><de> Diese Datenzentren halten die von den Servern erzeugte Wärme zurück und geben sie an das umliegende Gebäude ab.
<G-vec01169-002-s574><capture.festhalten><en> Capture your meet and greet moment at Sea Lion Point and take home memories of a fun-filled day spent with these playful creatures.
<G-vec01169-002-s574><capture.festhalten><de> Halten Sie diesen besonderen Augenblick am Sea Lion Point auf einem Erinnerungsfoto fest, das Sie für immer an diesen unvergesslichen Tag mit den verspielten Geschöpfen erinnern wird.
<G-vec01169-002-s575><capture.festhalten><en> Photographs capture a special moment in a special place – a supposedly simple portrayal of reality.
<G-vec01169-002-s575><capture.festhalten><de> Fotografien halten einen besonderen Moment an einem speziellen Ort fest – eine vermeintlich einfache Wiedergabe der Realität.
<G-vec01169-002-s576><capture.festhalten><en> Capture all those changes, all those unique moments in photos and create something impressive from them.
<G-vec01169-002-s576><capture.festhalten><de> Halten Sie besondere Momente in Fotos fest und erstellen Sie unvergessliche Momente mit Ihrem Baby.
<G-vec01169-002-s577><capture.festhalten><en> We capture beautiful memories for you since 2010.
<G-vec01169-002-s577><capture.festhalten><de> Wir halten wunderschöne Momente fest seit 2010.
<G-vec01169-002-s578><capture.festhalten><en> Summerending With the title Summerending, the Swiss artists Adrian Schiess (*1959 in Zurich) and Annelies Štrba (*1947 in Zug) summon that time of year when summer crosses over into autumn: this is the atmospheric and sometimes melancholy season of transition the two internationally acclaimed artists capture in a new group of flower still lifes.
<G-vec01169-002-s578><capture.festhalten><de> Summerending Mit dem Titel Summerending beziehen sich die Schweizer Künstler Adrian Schiess (*1959 in Zürich) und Annelies Štrba (*1947 in Zug) auf jene Jahreszeit, in welcher der Sommer in den Herbst übergeht: Diese stimmungsvolle und zuweilen wehmütige Zeit des Übergangs halten die beiden international bekannten Künstler in einer neuen Werkgruppe von Blumenstillleben fest, welche einen engen Dialog zwischen Fotografie und Malerei eingehen.
<G-vec01169-002-s579><capture.festhalten><en> Capture the details and bright colors.
<G-vec01169-002-s579><capture.festhalten><de> Halten Sie Details und leuchtende Farben...
<G-vec01169-002-s580><capture.festhalten><en> Another passion of us is travelling - so we capture beautiful Zaubermomente (=magic moments) all around the world and share them with you on our Blog or our Facebook sites (Weddings & Couples, Dogs & Horses).
<G-vec01169-002-s580><capture.festhalten><de> Eine weitere Leidenschaft von uns ist das Reisen - so halten wir auf der ganzen Welt wunderschöne Zaubermomente fest und teilen sie mit Euch auf unserem Blog und unseren Facebookseiten (Hochzeitsreportagen & Paarfotoshootings, Hundefotografie & Pferdefotografie).
<G-vec01169-002-s581><capture.festhalten><en> A group photo will capture the special moment of success for eternity – dressed as British detectives.
<G-vec01169-002-s581><capture.festhalten><de> Ein Gruppenfoto mit Führungspersonen und Mitarbeitern halten den Moment als Erinnerung fest – standesgemäß verkleidet als britische Detektive.
