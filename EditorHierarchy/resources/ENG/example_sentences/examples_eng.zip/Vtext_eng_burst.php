<G-vec00867-002-s101><burst.ausbrechen><en> The Twilight Burst finish is a smart aesthetic for this high performance pack.
<G-vec00867-002-s101><burst.ausbrechen><de> Die Dämmerung brach Finish ist eine intelligente Ästhetik für dieses high-Performance-Paket.
<G-vec00867-002-s102><burst.ausbrechen><en> When I first heard it, immediately burst into tears.
<G-vec00867-002-s102><burst.ausbrechen><de> Als ich es das erste Mal hörte, brach es sofort in Tränen aus.
<G-vec00867-002-s103><burst.ausbrechen><en> An adult serious woman, a leading worker, simply burst into tears and sobbed like a child.
<G-vec00867-002-s103><burst.ausbrechen><de> Eine erwachsene, ernsthafte Frau, ein führender Arbeiter, brach einfach in Tränen aus und schluchzte wie ein Kind.
<G-vec00867-002-s104><burst.ausbrechen><en> Sleeping better for you now?” Claire almost burst into tears.
<G-vec00867-002-s104><burst.ausbrechen><de> Läßt er dich jetzt besser schlafen?« Ciaire brach fast in Tränen aus.
<G-vec00867-002-s105><burst.ausbrechen><en> Sky rockets burst over Times Square.
<G-vec00867-002-s105><burst.ausbrechen><de> Sky Raketen brach über den Times Square.
<G-vec00867-002-s106><burst.ausbrechen><en> Cecil Gant burst upon the scene during World War II with what author Arnold Shaw considers the first R&B hit, I Wonder, the story of a lonely soldier missing his girl back home.
<G-vec00867-002-s106><burst.ausbrechen><de> Cecil Gant brach während des Zweiten Weltkriegs mit dem, was der Autor Arnold Shaw als den ersten R&B-Hit betrachtet, I Wonder, die Geschichte eines einsamen Soldaten, der sein Mädchen zu Hause vermisst.
<G-vec00867-002-s107><burst.ausbrechen><en> She burst through the glass doors into the rain, looking around the parking lot.
<G-vec00867-002-s107><burst.ausbrechen><de> Sie brach durch die Glastür in den Regen und schaute auf den Parkplatz.
<G-vec00867-002-s108><burst.ausbrechen><en> When this was said, Yodhajiva the headman sobbed & burst into tears.
<G-vec00867-002-s108><burst.ausbrechen><de> Als dieses gesagt war, schluchzte Yodhajiva und brach in Tränen aus.
<G-vec00867-002-s109><burst.ausbrechen><en> The two looked at each other with hard eyes, then the first soldier burst in laughter, a nasty laughter, and let Simon go, going to sit to a table.
<G-vec00867-002-s109><burst.ausbrechen><de> Die beiden erblickten sich einander mit starren Augen, dann brach der erste Militär in häßliches Lachen aus aber ließ Simon frei und ging hin, um Platz zu nehmen.
<G-vec00867-002-s110><burst.ausbrechen><en> Sigarda burst out of her sisters' chest smeared with blood and ichor, like an abhorrent birth, and crashed to the ground in the plaza below.
<G-vec00867-002-s110><burst.ausbrechen><de> Sigarda brach – von Blut und Eingeweiden bedeckt wie bei einer grausigen Geburt – aus der Brust ihrer Schwestern heraus und stürzte auf den Platz unter ihnen.
<G-vec00867-002-s111><burst.ausbrechen><en> From the tip of his wand burst the silver doe: she landed on the office floor, bounded across the office and soared out of the window.
<G-vec00867-002-s111><burst.ausbrechen><de> Aus der Spitze seines Zauberstabs brach die silberne Hirschkuh hervor: Sie landete auf dem Boden des Büros, sprang mit einem Satz durch den Raum und rauschte aus dem Fenster.
<G-vec00867-002-s112><burst.ausbrechen><en> “I can not hurt-she-s-ee!” – Plangent cry burst from my throat, and I felt complete exhaustion.
<G-vec00867-002-s112><burst.ausbrechen><de> “Ich kann es nicht schaden, sie-s-ee!” – Plangent Schrei brach aus meiner Kehle, und ich fühlte mich völlig erschöpft.
<G-vec00867-002-s113><burst.ausbrechen><en> Then the new reality burst forth; paradise opened its gates, and everything was different than expected.
<G-vec00867-002-s113><burst.ausbrechen><de> Dann brach die neue Wirklichkeit aus, das Paradies öffnete seine Pforten, und alles kam ganz anders.
<G-vec00867-002-s114><burst.ausbrechen><en> Baard trembled in all his limbs, he sat down on the bed foot, and burst into tears.
<G-vec00867-002-s114><burst.ausbrechen><de> Baard schlotterten die Knie, er setzte sich an das Fußende des Bettes und brach in heftiges Weinen aus.
<G-vec00867-002-s115><burst.ausbrechen><en> I almost burst into tears when I saw him coming closer and closer….He’s such a beautiful bear.
<G-vec00867-002-s115><burst.ausbrechen><de> Ich brach fast in Tränen aus, als ich ihn näher und näher kommen sah ….Er ist ein so schöner Bär.
<G-vec00867-002-s116><burst.ausbrechen><en> Buildings were destroyed, and a dam burst, further inundating the town.
<G-vec00867-002-s116><burst.ausbrechen><de> Gebäude wurden zerstört, und ein Damm brach zusammen und überflutete die Stadt weiter.
<G-vec00867-002-s117><burst.ausbrechen><en> The unique copy, who was tattooed all over his body with Hells Angels and snake images burst out laughing when he saw the writing on Brian’s motorcycle jacket.
<G-vec00867-002-s117><burst.ausbrechen><de> Das am ganzen Körper mit Hells Angels und Schlangen Tattoos tätowierte Unikat brach in lautes Lachen aus, als es den Schriftzug auf Brians Motorradjacke sah.
<G-vec00867-002-s118><burst.ausbrechen><en> Aunt Petunia burst into tears and hugged her son, while Harry ducked under the table so they wouldn’t see him laughing.
<G-vec00867-002-s118><burst.ausbrechen><de> Tante Petunia brach in Tränen aus und drückte ihren Sohn an die Brust, während Harry unter den Tisch abtauchte, damit sie sein Lachen nicht sehen konnten.
<G-vec00867-002-s119><burst.ausbrechen><en> — When I showed my patent to Mark 7 on the last video call, he burst into tears and immediately showed it to his designers.
<G-vec00867-002-s119><burst.ausbrechen><de> Als ich Dan von Mark 7 beim letzten Videotelefonat mein Patent gezeigt habe, brach er in Tränen aus und zeigte es sofort seinen Konstrukteuren.
<G-vec00867-002-s120><burst.ausbrechen><en> We just burst into tears.
<G-vec00867-002-s120><burst.ausbrechen><de> Wir brachen in Tränen aus.
<G-vec00867-002-s121><burst.ausbrechen><en> Her friends burst into raucous laughter since it didn’t play the usual bell sound but her own moaning from moments ago, her begging and whimpering while she was getting fucked next door.
<G-vec00867-002-s121><burst.ausbrechen><de> Ihre Freundinnen brachen in schallendes Gelächter aus, denn statt des üblichen Glockenspiels hörte sie sich selbst, ihr Stöhnen von wenigen Augenblicken zuvor, ihr Betteln und Winseln, als sie nebenan gefickt wurde.
<G-vec00867-002-s122><burst.ausbrechen><en> Wild wolves burst through the gate.
<G-vec00867-002-s122><burst.ausbrechen><de> Wilde Wölfe brachen durchs Tor.
<G-vec00867-002-s123><burst.ausbrechen><en> Mapuhi relieved his feelings by sending her reeling from a box on the ear; while Tefara and Nauri burst into tears and continued to upbraid him after the manner of women. Diebe.
<G-vec00867-002-s123><burst.ausbrechen><de> Mapuhi verschaffte seinen Gefühlen Luft, indem er ihr kräftig eins aufs Ohr gab, so dass sie zurücktaumelte; Tefara und Nauri brachen in Tränen aus und machten ihm weiter Vorhaltungen, wie Frauen eben so sind.
<G-vec00867-002-s124><burst.ausbrechen><en> 14 days later the wounds on my buttocks burst open and for four weeks were in a festering condition.
<G-vec00867-002-s124><burst.ausbrechen><de> Nach 14 Tagen brachen die Wunden am Gesäß auf und eiterten durch vier Monate.
<G-vec00867-002-s125><burst.ausbrechen><en> Dykes burst, people were killed and the damage was huge.
<G-vec00867-002-s125><burst.ausbrechen><de> Deiche brachen, Menschen wurden getötet und der Schaden war groß.
<G-vec00867-002-s126><burst.ausbrechen><en> When defenders of the city tasted unattractive broth, they so much burst of energy and they started to beat off the attacks of enemies with such a rage, that the enemies got confused and retreated.
<G-vec00867-002-s126><burst.ausbrechen><de> Als Verteidiger der Stadt eine unattraktive Brühe schmeckten, brachen sie so viel Energie und sie begannen, die Angriffe von Feinden mit solch einer Wut zu schlagen, dass die Feinde verwirrt und zurückgezogen wurden.
<G-vec00867-002-s127><burst.ausbrechen><en> Those habits were buried deep down -- and later they burst out even stronger.
<G-vec00867-002-s127><burst.ausbrechen><de> Diese Verhaltensweisen wurden tief vergraben - und später brechen sie um so stärker aus.
<G-vec00867-002-s128><burst.ausbrechen><en> Constricted image formats burst open, curved and contorted surfaces expand space and transcend into installations and sculptural shapes.
<G-vec00867-002-s128><burst.ausbrechen><de> Eingeengte Bildformate brechen auf, gebogene und gekrümmte Flächen dehnen sich in den Raum aus und transzendieren zu Installationen und skulpturalen Formen.
<G-vec00867-002-s129><burst.ausbrechen><en> When pipes are exposed to subzero temperatures they can burst, leading to considerable damage and disruption.
<G-vec00867-002-s129><burst.ausbrechen><de> Bei Temperaturen unter dem Nullpunkt können Rohre brechen und damit beträchtliche Schäden und Ausfälle hervorrufen.
<G-vec00867-002-s130><burst.ausbrechen><en> They are looking for a method to fully express themselves, to burst free from their self-imposed lethargy, to run like the wind wild and unhindered, to sweep across the planet bringing lasting change, but some key element is missing.
<G-vec00867-002-s130><burst.ausbrechen><de> Sie schauen nach einer Möglichkeit, sich ganz auszudrücken, frei zu brechen aus ihrer selbst auferlegten Lethargie, wild und ungehindert wie der Wind zu rennen, über den Planeten zu fegen und andauernde Änderungen zu bringen, aber es fehlt noch ein Schlüsselelement.
<G-vec00867-002-s131><burst.ausbrechen><en> The ultra quick, high-power light impulses burst the colour pigments of the tattoo ink which are stored in the second skin layer.
<G-vec00867-002-s131><burst.ausbrechen><de> Der ultrakurze, hochenergetische Lichtimpuls bricht die in der zweiten Hautschicht eingelagerten Farbpartikel der Tattoo-Tinte auf.
<G-vec00867-002-s132><burst.ausbrechen><en> PAUL: (burst into laughter)No, no.
<G-vec00867-002-s132><burst.ausbrechen><de> PAUL (bricht in Gelächter aus): Nein, nein.
<G-vec00867-002-s133><burst.ausbrechen><en> It is no accident that the Revolution burst out precisely in Paris, in that Catholic France, eldest daughter of the Church, in which had been forged the Gallican and royal weapons of the struggle against Rome, but which was in the meantime close to the heart of Catholic Rome.
<G-vec00867-002-s133><burst.ausbrechen><de> Nicht zufällig bricht die Revolution gerade in Paris aus, in jenem katholischen Frankreich, älteste Tochter der Kirche, in der die gallikanischen und königlichen Werkzeuge des Kampfes gegen Rom geschmiedet wurden, das zugleich aber auch im Herzen des römischen Katholizismus war.
