<G-vec00279-002-s050><beat.aufschlagen><en> Combine mascarpone and heavy cream in a bowl and beat until nearly stiff.
<G-vec00279-002-s050><beat.aufschlagen><de> Mascarpone und Sahne aufschlagen, bis die Masse fast steif ist.
<G-vec00279-002-s051><beat.aufschlagen><en> Beat on high speed in the standing mixer until you get a stiff meringue and the bottom of the bowl reaches room temperature.
<G-vec00279-002-s051><beat.aufschlagen><de> In der Küchenmaschine aufschlagen, bis eine sehr steife Meringue entstanden ist und der Schüsselboden Raumtemperatur hat.
<G-vec00279-002-s052><beat.aufschlagen><en> Beat butter with sugar, vanilla sugar and honey.
<G-vec00279-002-s052><beat.aufschlagen><de> Butter mit Zucker, Vanillezucker und Honig aufschlagen.
<G-vec00279-002-s053><beat.aufschlagen><en> Slowly add the sugar and cinnamon and beat on high speed until light and fluffy.
<G-vec00279-002-s053><beat.aufschlagen><de> Den Zucker und Zimt mischen, in die Schüssel einrieseln lassen und auf höchster Stufe aufschlagen, bis alles hell und luftig ist.
<G-vec00279-002-s054><beat.aufschlagen><en> In a large bowl, beat egg whites, sugar, vanilla extract and salt.
<G-vec00279-002-s054><beat.aufschlagen><de> In einer großen Schüssel Eiweiße, Zucker, Vanilleextrakt und Salz aufschlagen.
<G-vec00279-002-s055><beat.aufschlagen><en> Our top tip: Quick Rigatoni Pasta Bake: Boil 250g rigatoni pasta until al dente. Beat 4 eggs and mix together with salt, black pepper, a crushed garlic clove, a dash of olive oil, paprika powder, a finely chopped red chili pepper or dried chili flakes and 200g grated cheese.
<G-vec00279-002-s055><beat.aufschlagen><de> Verwendungsvorschlag Unser Tipp: Schneller Rigatoniauflauf - 250 g Rigatoni Nudeln al dente kochen, 4 Eier aufschlagen und mit Salz, schwarzem Pfeffer, einer gepressten Knoblauchzehe, etwas Olivenöl, Paprikapulver, einer kleingehackten roten Chilischote oder getrockneten Chili Flocken und 200g geriebenem Käse vermischen.
<G-vec00279-002-s056><beat.aufschlagen><en> Beat the eggs, season with salt and pepper and whisk.
<G-vec00279-002-s056><beat.aufschlagen><de> Eier aufschlagen, mit Salz und Pfeffer würzen und verquirlen.
<G-vec00279-002-s057><beat.aufschlagen><en> For the vanilla frosting beat margarine with an electric mixer until very soft.
<G-vec00279-002-s057><beat.aufschlagen><de> Für die Vanilleglasur die Margarine mit dem Mixer sehr weich aufschlagen.
<G-vec00279-002-s058><beat.aufschlagen><en> Beat the egg and sugar, then stir in the starch.
<G-vec00279-002-s058><beat.aufschlagen><de> Zucker und Ei aufschlagen, dann die Stärke unterrühren.
<G-vec00279-002-s059><beat.aufschlagen><en> Beat the butter and sugar in a large bowl until light and airy.
<G-vec00279-002-s059><beat.aufschlagen><de> Weiche Butter und Zucker in einer großen Schüssel luftig aufschlagen.
<G-vec00279-002-s060><beat.aufschlagen><en> Beat the eggs with sugar and honey until creamy.
<G-vec00279-002-s060><beat.aufschlagen><de> Eier mit Zucker und Honig cremig aufschlagen.
<G-vec00279-002-s061><beat.aufschlagen><en> Beat the egg yolk and coat the puff pastry with it.
<G-vec00279-002-s061><beat.aufschlagen><de> Eigelb aufschlagen und den Blätterteig damit bepinseln.
<G-vec00279-002-s092><beat.besiegen><en> Beat the opponents in space to earn more points.
<G-vec00279-002-s092><beat.besiegen><de> Besiege die Gegner im Weltraum, um mehr Punkte zu erzielen.
<G-vec00279-002-s093><beat.besiegen><en> Pick up the strongest Poker hand or bluff your way to victory as you beat your opponents and win free chips.
<G-vec00279-002-s093><beat.besiegen><de> Spiele das beste Poker-Spiel mit Deinen stärksten Händen oder bluffe Dir den Weg zum Sieg - besiege Deine Gegner, gewinne kostenlose Chips und beweise, dass Du der beste Poker-Spieler bist.
<G-vec00279-002-s094><beat.besiegen><en> Beat Your Friends, Connect to Autolog.
<G-vec00279-002-s094><beat.besiegen><de> Besiege deine Freunde,Verbinde dich mit Autolog.
<G-vec00279-002-s095><beat.besiegen><en> Beat the Ditto (or just run away) and immediately fly to Lavender Town without fighting anything else.
<G-vec00279-002-s095><beat.besiegen><de> Besiege das Ditto (oder renne einfach weg) und fliege sofort nach Lavandia, ohne vorher gegen jemand anders zu kämpfen.
<G-vec00279-002-s096><beat.besiegen><en> Beat the opposing team by using the right tools at your disposal.
<G-vec00279-002-s096><beat.besiegen><de> Besiege das gegnerische Team durch Einsatz der richtigen Dinge, die dir zur Verfügung stehen.
<G-vec00279-002-s097><beat.besiegen><en> So beat her and she'll show you how to use that pink dildo.
<G-vec00279-002-s097><beat.besiegen><de> Besiege sie und sie zeigt dir, wie man das Ding benutzt.
<G-vec00279-002-s098><beat.besiegen><en> Help Pato, the raccoon dog, on his mysterious mission and beat The Red Count to rescue your kidnapped crew.
<G-vec00279-002-s098><beat.besiegen><de> Hilf Pato dem Marderhund bei seiner geheimnisvollen Mission und besiege den "Roten Grafen", um deine entführte Crew zu befreien.
<G-vec00279-002-s099><beat.besiegen><en> Join and switch teams, earn sponsor rewards, beat your rivals and race with a teammate.
<G-vec00279-002-s099><beat.besiegen><de> Wähle in GRID: Autosport aus Vertragsangeboten von verschiedenen Teams, verdiene dir Sponsorengelder, besiege deine Rivalen und fahre mit einem Teamkameraden an deiner Seite.
<G-vec00279-002-s100><beat.besiegen><en> Beat the boss to advance to the next level.
<G-vec00279-002-s100><beat.besiegen><de> Besiege den Boss, um den nächsten Level zu erreichen.
<G-vec00279-002-s101><beat.besiegen><en> Viral Victory Beat a Developer in a Ranked Match, or anyone with this Achievement.
<G-vec00279-002-s101><beat.besiegen><de> Besiege einen Entwickler (oder jemanden, der diesen Erfolg erreicht hat) in einem Ranglisten-Spiel.
<G-vec00279-002-s277><beat.höherschlagen><en> Tuning fans invited to take a seat inside will be inspired by the interior which has been completely restyled, making the heart of every individualist beat faster.
<G-vec00279-002-s277><beat.höherschlagen><de> Beim Probesitzen werden Tuning-Fans auch vom Interieur begeistert sein, denn ein kompletter Fondumbau lässt das Herz jedes Individualisten höherschlagen.
<G-vec00279-002-s278><beat.höherschlagen><en> “The Rita Limacher bookshop at Kleiner Schlossplatz lets the creative heart beat faster.
<G-vec00279-002-s278><beat.höherschlagen><de> „Die Buchhandlung Rita Limacher am Kleinen Schlossplatz lässt das Herz der Kreativen höherschlagen.
<G-vec00279-002-s279><beat.höherschlagen><en> Her undeniable erotic radiance combined with her confidence will make your heart beat faster and prompt you to conquer this hot model in every way possible.
<G-vec00279-002-s279><beat.höherschlagen><de> Ihre unübersehbare erotische Ausstrahlung gepaart mit Ihrer selbstbewussten Art, lässt Ihr Herz höherschlagen und fordert Sie auf, dieses heisse Model in jeder Hinsicht erobern zu wollen.
<G-vec00279-002-s280><beat.höherschlagen><en> Sexy Adventure Pirate Lady costume not only the hearts of sailors beat faster, but also landlubbers ensures curved saber.
<G-vec00279-002-s280><beat.höherschlagen><de> Sexy Kostüm das nicht nur die Herzen aller Seefahrer höherschlagen lässt, sondern auch bei Landratten für geschwungene Säbel sorgt.
<G-vec00279-002-s281><beat.höherschlagen><en> KIDS XXL – A wide range of adorable motifs such as ballerinas, astronauts, knights and cheerful sea creatures or circus animals will make every child’s heart beat faster.
<G-vec00279-002-s281><beat.höherschlagen><de> KIDS XXL – Viele verschiedene und süße Motive wie Ballerinas, Astronauten, Ritter, lustige Meeres- oder Zirkustiere lassen jedes Kinderherz höherschlagen.
<G-vec00279-002-s282><beat.höherschlagen><en> This feeling let the heart of every sports car fan beat faster.
<G-vec00279-002-s282><beat.höherschlagen><de> Ein unglaubliches Gefühl, welches das Herz jedes Sportautoliebhabers höherschlagen lässt.
<G-vec00279-002-s283><beat.höherschlagen><en> The perfect training infrastructure in Seefeld could easily make athletes’ hearts skip a beat.
<G-vec00279-002-s283><beat.höherschlagen><de> Die perfekte Infrastruktur in Seefeld lässt Sportlerherzen aus aller Welt höherschlagen.
<G-vec00279-002-s284><beat.höherschlagen><en> A lovely camping scene, with a camp fire under the bright stars, will make the heart of every outdoor activities fan beat faster.
<G-vec00279-002-s284><beat.höherschlagen><de> Eine romantische Campingsszene, mit einem Lagerfeuer unter den leuchtenden Sternen lässt das Herz eines jeden Outdoor Fans höherschlagen.
<G-vec00279-002-s285><beat.höherschlagen><en> The successful colourful design that uses light pink, light blue, pink and white will make the hearts of little girls beat faster while the polished finish sets off the motif in the best way possible.
<G-vec00279-002-s285><beat.höherschlagen><de> Die gelungene Farbgestaltung aus Hellrosa, Hellblau, Pink und Weiß lässt Mädchenherzen höherschlagen, während die polierte Oberfläche das Motiv optimal zur Geltung bringt.
<G-vec00279-002-s286><beat.höherschlagen><en> Infinity – symbol of eternal love and friendship: this set for women, comprising filigree ear studs and a feminine necklace, will not only make hearts beat that little bit faster, they also create a timelessly-elegant look.
<G-vec00279-002-s286><beat.höherschlagen><de> Infinity – Zeichen ewiger Liebe und Freundschaft: Das Set für Damen aus filigranen Ohrsteckern und femininem Collier lässt nicht nur Herzen höherschlagen, sondern erschafft auch mühelos einen zeitlos-eleganten Look.
<G-vec00279-002-s287><beat.höherschlagen><en> Rafting – the Isel, one of the top rafting rivers in Europe, offers everything that makes the heart of every white water fan beat faster with excitement.
<G-vec00279-002-s287><beat.höherschlagen><de> Schnupperklettern Rafting – die Isel, einer der Top-Raftingflüsse Europas, bietet alles, was das Herz jedes Wildwasserfans höherschlagen lässt.
<G-vec00279-002-s288><beat.höherschlagen><en> Something exquisitely close to the heart: these heart-shaped ear studs featuring faceted diamonds will instantly make the heart of the person receiving them beat that little bit faster.
<G-vec00279-002-s288><beat.höherschlagen><de> Bitte beachten Sie Eine edle Herzensangelegenheit: Der Ohrstecker in Herzform aus facettierten Diamanten lässt das Herz des Beschenkten im Nu höherschlagen.
<G-vec00279-002-s289><beat.höherschlagen><en> Imposing waves, impressive rapids and powerful rollers make every rafter's heart beat faster.
<G-vec00279-002-s289><beat.höherschlagen><de> Imposante Wellen, beeindruckende Stromschnellen und wuchtige Walzen lassen jedes Rafter Herz höherschlagen.
<G-vec00279-002-s290><beat.höherschlagen><en> A powerful aroma and the iconic amp design make hearts beat faster.
<G-vec00279-002-s290><beat.höherschlagen><de> Kräftige Noten und das kultige Verstärker-Design lassen das Herz höherschlagen.
<G-vec00279-002-s291><beat.höherschlagen><en> The approaching ride over the Nordschleife makes the heart of the KTM Member of the Executive Board beat faster: “The Nürburgring and specifically the Nordschleife is something very special for each race driver and likewise for each manufacturer. It is a unique circuit that that is extraordinarily challenging.
<G-vec00279-002-s291><beat.höherschlagen><de> “ Vor allem die bevorstehende Fahrt auf der Nordschleife lässt das Herz des KTM-Vorstands höherschlagen: „Der Nürburgring mit der Nordschleife ist für jeden Rennfahrer, aber auch für jeden Hersteller etwas Besonderes, eine einmalige Rennstrecke sowie eine außergewöhnliche Herausforderung.
<G-vec00279-002-s292><beat.höherschlagen><en> Home-grown herbs, mixed with colourful flowers, make every gardener's heart beat a little faster.
<G-vec00279-002-s292><beat.höherschlagen><de> Selbst angebaute Kräuter, gemischt mit farbenprächtigen Blumen, lassen jedes Gärtner-Herz höherschlagen.
<G-vec00279-002-s293><beat.höherschlagen><en> You´ll find all the engine parts here that make your heart beat faster.
<G-vec00279-002-s293><beat.höherschlagen><de> Hier findest du alle Motorteile, die das Herz höherschlagen lassen.
<G-vec00279-002-s294><beat.höherschlagen><en> We are looking forward to a talk that will make your Techie heart beat faster.
<G-vec00279-002-s294><beat.höherschlagen><de> Wir freuen uns auf einen Vortrag, der das Techie-Herz höherschlagen lassen wird.
<G-vec00279-002-s295><beat.höherschlagen><en> Fifteen lifts, 65 kilometres of varied slopes and cosy refreshment facilities make every skier‘s and snowboarder's heart beat faster.
<G-vec00279-002-s295><beat.höherschlagen><de> Fünfzehn Liftanlagen, 65 abwechslungsreiche Pistenkilometer und gemütliche Einkehrmöglichkeiten lassen jedes Skifahrer- und Snowboarder-Herz höherschlagen.
<G-vec00279-002-s353><beat.schlagen><en> Beat a friend’s highlight (best score of a friend)
<G-vec00279-002-s353><beat.schlagen><de> Schlage das Highlight (Rekord) eines Freundes.
<G-vec00279-002-s354><beat.schlagen><en> Beat Pigsy to the top of the Decaying Titan. Bad Doggy
<G-vec00279-002-s354><beat.schlagen><de> Schlage Pigsy beim Rennen zur Spitze des verfallenden Titanen.
<G-vec00279-002-s355><beat.schlagen><en> Beat initial Best Lap times in all variations of England.
<G-vec00279-002-s355><beat.schlagen><de> Schlage die anfänglichen Bestrundenzeiten bei allen Varianten von England.
<G-vec00279-002-s356><beat.schlagen><en> Beat initial Best Lap times in all variations of Canada.
<G-vec00279-002-s356><beat.schlagen><de> Schlage die anfänglichen Bestrundenzeiten bei allen Varianten von Kanada.
<G-vec00279-002-s357><beat.schlagen><en> In a large bowl, beat the eggs and then add the ricotta cheese, 1 1/2 cups of mozzarella cheese, garlic powder, parsley, salt, and pepper.
<G-vec00279-002-s357><beat.schlagen><de> Schlage die Eier in einer große Schüssel und füge den Ricotta-Käse, 1 ½ Tassen Mozzarella, Knoblauchpulver, Petersilie, Salz und Pfeffer hinzu.
<G-vec00279-002-s358><beat.schlagen><en> Beat the mixture in a stand mixer, until it is white and fluffy.
<G-vec00279-002-s358><beat.schlagen><de> Schlage die Mischung in der Küchenmaschine auf, bis diese hell und schaumig ist.
<G-vec00279-002-s359><beat.schlagen><en> Save all prisoners from their cage and beat all the different enemies.
<G-vec00279-002-s359><beat.schlagen><de> Rette alle Gefangenen aus ihren Käfigen und schlage die verschiedenen Feinde.
<G-vec00279-002-s360><beat.schlagen><en> Or beat by hand with a wooden spoon in a bowl.
<G-vec00279-002-s360><beat.schlagen><de> Oder schlage von Hand mit einem Holzlöffel in einer Schüssel.
<G-vec00279-002-s361><beat.schlagen><en> 30 Someone else? You beat the 25 licensed players.
<G-vec00279-002-s361><beat.schlagen><de> Schlage alle 25 Lizenzspieler in einem Spielmodus deiner Wahl.
<G-vec00279-002-s362><beat.schlagen><en> Beat until the mixture feels luke warm.
<G-vec00279-002-s362><beat.schlagen><de> Schlage es weiter bis die Mischung sich lauwarm anfühlt.
<G-vec00279-002-s363><beat.schlagen><en> Beat the eggs in a bowl and season with salt and pepper.
<G-vec00279-002-s363><beat.schlagen><de> Schlage die Eier in einer Schüssel, verquirle sie und gebe etwas Salz und Pfeffer hinzu.
<G-vec00279-002-s364><beat.schlagen><en> 15 Police Brutality Beat a Shield to death using the Telescopic Baton.
<G-vec00279-002-s364><beat.schlagen><de> 15 Polizeigewalt Schlage einen Schild mit dem Teleskop-Schlagstock tot.
<G-vec00279-002-s365><beat.schlagen><en> Beat one of the eggs and season it with a pinch of salt.
<G-vec00279-002-s365><beat.schlagen><de> Schlage eines der Eier auf und würze es mit einer Prise Salz.
<G-vec00279-002-s366><beat.schlagen><en> Pour the heavy cream into a mixer, and beat on high.
<G-vec00279-002-s366><beat.schlagen><de> Gieße die Schlagsahne in einen Mixer und schlage sie auf hoher Stufe auf.
<G-vec00279-002-s367><beat.schlagen><en> Beat the hackers with this 3 pack of stainless steel webcam covers for your Laptops, tablets and smartphones.
<G-vec00279-002-s367><beat.schlagen><de> Schlage die Hacker mit dieser 3er Packung aus Edelstahl Webcam Abdeckungen für Ihren Laptop, Tablets und Smartphones.
<G-vec00279-002-s368><beat.schlagen><en> Beat the egg in a bowl and mix it well with the banana.
<G-vec00279-002-s368><beat.schlagen><de> Schlage die Eier in die Schüssel und vermenge sie gut mit der Banane.
<G-vec00279-002-s369><beat.schlagen><en> Beat one fist into the other palm alternating for 5 minutes.
<G-vec00279-002-s369><beat.schlagen><de> Schlage für 5 Minuten abwechselnd mit den Fäusten in die jeweils andere Handfläche.
<G-vec00279-002-s370><beat.schlagen><en> Beat the Giant Eel within 60 Seconds in 'Aim for the Eel.'. Survivor
<G-vec00279-002-s370><beat.schlagen><de> Schlage den Riesenaal in 60 Sekunden in "Wer den Aal hat, hat die Qual".
<G-vec00279-002-s371><beat.schlagen><en> Beat the clock, avoid obstacles and find new pathways in 19 point-to-point Carkour runs.
<G-vec00279-002-s371><beat.schlagen><de> Schlage die Uhr, weiche Hindernissen aus und finde neue Wege bei 19 Punkt-zu-Punkt-Carkour-Läufen.
<G-vec00279-002-s488><beat.toppen><en> But to lie in Birgit's garden, the Danube to enjoy the views and tranquility is almost impossible to beat.
<G-vec00279-002-s488><beat.toppen><de> Aber in Birgits Garten zu liegen, die Donau,die Aussicht und Ruhe zu genießen ist fast nicht zu toppen.
<G-vec00279-002-s489><beat.toppen><en> There is no category, anyway, that could beat the above mentioned.
<G-vec00279-002-s489><beat.toppen><de> Ohnehin gibt es keine Kategorien, die die oben genannten toppen könnten.
<G-vec00279-002-s490><beat.toppen><en> It seemed impossible to us to beat this show.
<G-vec00279-002-s490><beat.toppen><de> Diese Show zu toppen, schien für uns unmöglich.
<G-vec00279-002-s491><beat.toppen><en> If you are looking for a peaceful retreat in nature and still want to quickly visit all the places on Lake Garda, this place is hard to beat.
<G-vec00279-002-s491><beat.toppen><de> Wenn man eine ruhige Unterkunft in der Natur sucht und trotzdem schnell alle Orte am Gardasee besuchen möchte, ist dieser Platz kaum zu toppen.
<G-vec00279-002-s492><beat.toppen><en> I enjoy my time with them more than almost anything else in Australia (the ocean is hard to beat).
<G-vec00279-002-s492><beat.toppen><de> Ich genieße meine Zeit mit ihnen mehr, als fast alles andere in Australien (der Ozean ist nur schwer zu toppen).
<G-vec00279-002-s493><beat.toppen><en> When it comes to cheap nightlife in Copenhagen, you can’t beat a street food market.
<G-vec00279-002-s493><beat.toppen><de> Wenn es um günstiges Nachtleben in Kopenhagen geht, kann nichts einen Streetfood Markt toppen.
<G-vec00279-002-s494><beat.toppen><en> Enthusiastic comments such as “Just awesome!” and “… you can’t beat it!” hardly reflect the exhilaration at this evening.
<G-vec00279-002-s494><beat.toppen><de> Die begeisterten Kommentare, „Einfach überwältigend!“ und „…nicht zu toppen!“, geben nur annähernd die überragende Stimmung an diesem Abend wider.
<G-vec00279-002-s495><beat.toppen><en> Downhill it is hard to beat because the stiff and lightweight carbon Spine every force pulse transmits directly to the ski.
<G-vec00279-002-s495><beat.toppen><de> Bergab ist er kaum zu toppen, weil das steife und superleichte Carbon Spine jeden Kraftimpuls direkt auf den Ski überträgt.
<G-vec00279-002-s496><beat.toppen><en> Unfortunately, no one around our area can beat that, well, not unfortunately but luckily, “We will come back”.
<G-vec00279-002-s496><beat.toppen><de> Leider kann das hier bei uns keiner toppen, d.h. aber nicht leider sondern sehr gern, „Wir werden wieder kommen“.
<G-vec00279-002-s497><beat.toppen><en> The choice is overwhelming, and not to beat.
<G-vec00279-002-s497><beat.toppen><de> Die Auswahl ist überwältigend und nicht mehr zu toppen.
<G-vec00279-002-s498><beat.toppen><en> So we took the classic legendary Condom Catsuit made of fine Radical Rubber and thought how we could probably beat this great piece of a rubber suit again.
<G-vec00279-002-s498><beat.toppen><de> Wir nahmen uns also den Condom Catsuit aus normalem Radical Rubber Latex her und dachten nach, wie wir ihn wohl nochmals toppen könnten.
<G-vec00279-002-s499><beat.toppen><en> Nordtveit: (laughs) It's true that my time here will be hard to beat.
<G-vec00279-002-s499><beat.toppen><de> Nordtveit: (lacht) Es stimmt, eigentlich ist das kaum zu toppen.
<G-vec00279-002-s500><beat.toppen><en> And yet – or for that very reason – the Psychedelic Experience Festival 2019 presents a line-up, that is hard to beat in the North German festival summer.
<G-vec00279-002-s500><beat.toppen><de> Und dennoch – oder gerade deshalb präsentiert das Psychedelic Experience Festival 2019 ein Line-up, das im norddeutschen Festivalsommer wohl schwer zu toppen ist.
<G-vec00279-002-s501><beat.toppen><en> It was clear that we could not expect to beat our fantastic score from 2009: 32 tuna and a blue shark.
<G-vec00279-002-s501><beat.toppen><de> Dass wir unser Traumergebnis von 2009 in keinem Fall – zumindest die Stückzahl von 32 Tunas und einem Blauhai - toppen konnten, war uns vorher klar.
<G-vec00279-002-s519><beat.unterbieten><en> During the second and final qualifying on Friday afternoon no driver was able to beat the times Allan McNish and Emanuele Pirro set during the first session on Thursday.
<G-vec00279-002-s519><beat.unterbieten><de> Während des zweiten und letzten Zeittrainings in Road Atlanta am Freitagnachmittag schaffte es kein Fahrer, die Zeiten zu unterbieten, die Allan McNish und Emanuele Pirro bereits in der ersten Trainingssitzung am Donnerstag gefahren waren.
<G-vec00279-002-s520><beat.unterbieten><en> If you manage to beat your best time, the app will show you a popup with a cup and your time.
<G-vec00279-002-s520><beat.unterbieten><de> Wenn du es schaffst, deine Bestzeit zu unterbieten, präsentiert dir die App ein Popup mit einem Pokal und deiner Zeit.
<G-vec00279-002-s521><beat.unterbieten><en> Our team members were satisfied with their results of sporting performance and are highly motivated to beat their running time next year.
<G-vec00279-002-s521><beat.unterbieten><de> Jeder Läufer unseres Teams war mit seiner Leistung zufrieden und ist motiviert seine Laufzeit nächstes Jahr zu unterbieten.
<G-vec00279-002-s522><beat.unterbieten><en> We will aim to beat the price you are paying your legacy provider, for the paid period.
<G-vec00279-002-s522><beat.unterbieten><de> Wir streben an, den Preis zu unterbieten, den Ihnen Ihr bisheriger Provider für den bezahlten Zeitraum berechnet.
<G-vec00279-002-s523><beat.unterbieten><en> By contrast, the makers of smaller and lighter vehicles are even required to beat the 95 g/km target.
<G-vec00279-002-s523><beat.unterbieten><de> Dagegen müssen jene Autobauer, die kleinere und leichtere Fahrzeuge bauen, die Schwelle von 95 g/km sogar unterbieten.
<G-vec00279-002-s524><beat.unterbieten><en> If you find the same custom tablet skins somewhere else for a lower price, we'll beat it, so that you can get the best service and all of our perks like free design services and free shipping to anywhere in the world. Why Choose Us
<G-vec00279-002-s524><beat.unterbieten><de> Falls Sie die gleiche maßgefertigte Tablet-Schutzhaut irgendwo anders zu einem niedrigeren Preis finden, dann unterbieten wir diesen, sodass Sie den besten Service und alle unsere Sonderleistungen, wie etwa den kostenlosen Design-Service und Versand überall in die Welt, geboten bekommen.
<G-vec00279-002-s525><beat.unterbieten><en> You can also race yourself by trying to beat the time of your previously recorded routes.
<G-vec00279-002-s525><beat.unterbieten><de> Du kannst auch gegen dich selbst Rennen fahren, indem Du versuchst, die Zeit deiner zuvor aufgezeichneten Routen zu unterbieten.
<G-vec00279-002-s526><beat.unterbieten><en> We have a Price Beat Guarantee that allows us to beat lower prices on comparable custom laptop sleeves offered by our competitors.
<G-vec00279-002-s526><beat.unterbieten><de> Wir haben eine Niedrigpreisgarantie, die uns ermöglicht, niedrigere Preise auf vergleichbare maßgefertigte Laptop-Taschen zu unterbieten, die von unseren Wettbewerben angeboten werden.
<G-vec00279-002-s527><beat.unterbieten><en> Additionally, if you are able to find a less expensive offer with comparable rental conditions somewhere else, we will match the price or even beat it!
<G-vec00279-002-s527><beat.unterbieten><de> Sollten Sie einen billigeren Mietwagen mit vergleichbaren Bedingungen bei einem anderen Anbieter finden, werden wir versuchen unseren Preis anzugleichen oder sogar den Preis zu unterbieten.
<G-vec00279-002-s528><beat.unterbieten><en> A customer contacted us asking if we could beat a competitor’s slow rupture disc delivery time.
<G-vec00279-002-s528><beat.unterbieten><de> Ein Kunde wandte sich an uns mit der Anfrage, ob wir die langen Lieferzeiten eines Wettbewerbers für Berstscheiben unterbieten könnten.
<G-vec00279-002-s547><beat.verprügeln><en> All those holed up on the city’s outskirts were forced to look on as people were chased, beat up, pushed down high walls and injured, gassed and shot by rubber bullets and water cannons.
<G-vec00279-002-s547><beat.verprügeln><de> Alle, die sich nicht am Stadtrand eingeigelt hatten, mussten mitansehen, wie Menschen gejagt, verprügelt,von Mauern herunter gestossen, mit Tränengas besprüht und mit Wasserwerfern beschossen wurden.
<G-vec00279-002-s548><beat.verprügeln><en> Whenever I cried out, male prisoners, including Li Jing, would beat me fiercely.
<G-vec00279-002-s548><beat.verprügeln><de> Jedes Mal wenn ich schrie, wurde ich von männlichen Insassen, darunter auch Li Jing, heftig verprügelt.
<G-vec00279-002-s549><beat.verprügeln><en> 15:07 (13:07) Then we beat her up, not too hard, undressed her for fun and beat her up, laughing at her stupid tits that jumped sprightly jumped while we hit her, but in the end she did lose consciousness and her tits became completely stupid so we even laughed to tears because of their uncompromising stupidity.
<G-vec00279-002-s549><beat.verprügeln><de> 15:07 (13:07) Dann haben wir sie verprügelt, nicht doll, haben sie zum Spaß ausgezogen und geschlagen, über ihre blöden Titten, die hin und her hüpften als wir sie schlugen, kichernd, aber dann hat sie völlig das Bewußtsein verloren und ihre Titten wurden da völlig blöd, und ihre Blödheit war schon fast zum Weinen.
<G-vec00279-002-s550><beat.verprügeln><en> She told them, “They [prison officials] wanted to 'transform' me and beat me badly.”
<G-vec00279-002-s550><beat.verprügeln><de> Sie erzählte ihnen: „Sie [die Gefängniswärter] wollen mich umerziehen und haben mich schrecklich verprügelt“.
<G-vec00279-002-s551><beat.verprügeln><en> Prisoners in the same cell beat her three times.
<G-vec00279-002-s551><beat.verprügeln><de> Drei Mal wurde sie von Gefangenen aus ihrer Zelle verprügelt.
<G-vec00279-002-s552><beat.verprügeln><en> In Sarajevo we beat up a bunch of Nazis.
<G-vec00279-002-s552><beat.verprügeln><de> In Sarajevo haben wir einen Haufen Nazis verprügelt.
<G-vec00279-002-s553><beat.verprügeln><en> “A few days ago four policemen beat me up.
<G-vec00279-002-s553><beat.verprügeln><de> "Vier Polizisten haben mich vor ein paar Tagen verprügelt.
<G-vec00279-002-s554><beat.verprügeln><en> If any practitioner refused, guards would put him in a dark room, where six drug abusers took turns to torture and beat him.
<G-vec00279-002-s554><beat.verprügeln><de> Wenn ein Praktizierender diesem Befehl nicht nachkommen wollte, dann wurde er von den Wärtern in einen dunklen Raum gesteckt, wo er von sechs Drogenabhängigen gefoltert und verprügelt wurde.
<G-vec00279-002-s555><beat.verprügeln><en> The same three guards also beat other detained Falun Gong practitioners in the past.
<G-vec00279-002-s555><beat.verprügeln><de> In der Vergangenheit hatten dieselben Drei auch andere inhaftierte Falun-Gong-Praktizierende verprügelt.
<G-vec00279-002-s556><beat.verprügeln><en> Policeman Chang Jun and other National Security Team members beat Guo Xiurong.
<G-vec00279-002-s556><beat.verprügeln><de> Dort wurde sie von den Polizisten Chang Jun und den Leuten von der nationalen Sicherheit verprügelt.
<G-vec00279-002-s606><beat.überbieten><en> In the setting sun nature plays a symphony of colors, hard to beat for drama and art.
<G-vec00279-002-s606><beat.überbieten><de> In der untergehenden Sonne spielt die Natur eine Sinfonie der Farben, an Dramaturgie und Kunst kaum zu überbieten.
<G-vec00279-002-s607><beat.überbieten><en> When it comes to beauty nothing can beat nature.
<G-vec00279-002-s607><beat.überbieten><de> Wenn es um Schönheit geht, kann nichts die Natur überbieten.
<G-vec00279-002-s608><beat.überbieten><en> Unlock and upgrade new boards to give you new advantages and ways to beat the high scores of the competition.
<G-vec00279-002-s608><beat.überbieten><de> Schalte neue Boards frei, upgrade sie und erhalte neue Fähigkeiten und Vorteile, um die Highscores deiner Gegner zu überbieten.
<G-vec00279-002-s609><beat.überbieten><en> Makanyi in Timbavati was a sensational experience with incredibly attentive staff, the friendliness and service are hard to beat.
<G-vec00279-002-s609><beat.überbieten><de> Makanyi in Timbavati war ein sensationelles Erlebnis mit wahnsinnig aufmerksamen Mitarbeitern, die in Freundlichkeit und Service kaum zu überbieten sind.
<G-vec00279-002-s610><beat.überbieten><en> An unmatched view of Las Vegas -- hotels, houses, the whole thing -- surrounds the patio and on beautiful summer nights it's pretty hard to beat sitting on one of the VIP couches at the club, taking in the city.
<G-vec00279-002-s610><beat.überbieten><de> Vom Patio aus hat man einen unvergleichbaren Blick auf Las Vegas - Hotels, Häuser, einfach alles - und an einem herrlichen Sommerabend auf einem der VIP-Sofas zu sitzen und die Aussicht zu genießen ist wohl kaum zu überbieten.
<G-vec00279-002-s611><beat.überbieten><en> This could explain the results of the GTX 480M, which can not really beat the ATI Mobility Radeon HD 5870.
<G-vec00279-002-s611><beat.überbieten><de> Dies dürfte mitunter auch eine Erklärung für das Abschneiden der GTX 480M sein, die in diesem Test die Performance verschiedener Notebooks mit ATI Mobility Radeon HD 5870 nicht wirklich überbieten kann.
<G-vec00279-002-s612><beat.überbieten><en> The flexibility and time-efficiency granted by private aviation is difficult to beat and our experienced team regularly responds to urgent flight requests with private jets ready to fly less than an hour after the client’s enquiry.
<G-vec00279-002-s612><beat.überbieten><de> Die Flexibilität und Zeiteffizienz der privaten Luftfahrt ist schwer zu überbieten und unser erfahrenes Team reagiert regelmäßig auf dringende Fluganfragen mit Privatjets, die weniger als eine Stunde nach der Anfrage des Kunden flugbereit sind.
<G-vec00279-002-s613><beat.überbieten><en> The fabulous view from the dance floor out over the Pudong financial district is difficult to beat – as indeed is the shameless
<G-vec00279-002-s613><beat.überbieten><de> Denn die spekta kuläre Aussicht von der Tanzfläche auf das Finanz viertel Pudong ist kaum zu überbieten.
<G-vec00279-002-s614><beat.überbieten><en> Hard to beat in absurdity, today we are using Holocaust to enforce a submission of Germans under the fatal and massively Islamizing migration politics of the German government, along with a reverse to the worst of the Middle Ages.
<G-vec00279-002-s614><beat.überbieten><de> An Absurdität kaum zu überbieten, nutzen wir heute den Holocaust um eine Unterwerfung der Deutschen unter die fatale und massiv islamisierende Migrationspolitik der Bundesregierung zu erzwingen, einhergehend mit einem Rückschritt ins tiefste Mittelalter.
<G-vec00279-002-s615><beat.überbieten><en> With their long flowering season, roses grown en masse, in a dedicated border, are hard to beat for the sheer exuberance of flower and enticing fragrance.
<G-vec00279-002-s615><beat.überbieten><de> Der unglaubliche Überschwang der Blüten und der betörende Duft ganzer Gruppen von Rosen konzentriert auf einer Fläche und gepaart mit ihrer langen Blütezeit ist kaum zu überbieten.
<G-vec00279-002-s616><beat.überbieten><en> With a dispenser display directly under the screen, your presence will be hard to beat.
<G-vec00279-002-s616><beat.überbieten><de> Mit einer Dispenser-Auflage direkt unter dem Bildschirm ist Ihr Auftritt kaum mehr zu überbieten.
<G-vec00279-002-s617><beat.übertreffen><en> We’re not talking about a simple bracelet here but rather about the Swarovski’s activity tracker – by day the Activity Crystal counts my steps, by night it tracks my sleep pattern and when it comes to sport it motivates me to give my all, to improve and beat myself again and again.
<G-vec00279-002-s617><beat.übertreffen><de> Es handelt sich nicht bloß um ein chices Armband, sondern um den Activity Tracker von Swarovski – tagsüber misst der Activity Crystal meine Schritte, nachts meinen Schlafrhythmus und beim Sport motiviert er mich, alles zu geben, um mich selber immer und immer wieder zu übertreffen.
<G-vec00279-002-s618><beat.übertreffen><en> Take a trip to this wild and exciting terrain and you’ll be rewarded with outstanding views, picturesque bays and beaches, and natural surroundings that are hard to beat.
<G-vec00279-002-s618><beat.übertreffen><de> Bei einer Reise in diese wilde, aufregende Gegend werden Sie mit schönen Ausblicken, malerischen Buchten und Stränden sowie einer Landschaft belohnt, die kaum zu übertreffen ist.
<G-vec00279-002-s619><beat.übertreffen><en> The same stand for incredibly dense and voluminous clouds whose taste is second to none and hard to beat.
<G-vec00279-002-s619><beat.übertreffen><de> Selbige stehen für unglaublich dichte und voluminöse Wolken, deren Geschmack seinesgleichen sucht und nur schwer zu übertreffen ist.
<G-vec00279-002-s620><beat.übertreffen><en> Whitsundays Sailing Whitsundays Sailing It's hard to beat the romance of sailing through the Whitsundays - 74 idyllic, mostly uninhabited islands tucked inside the Great Barrier Reef and Coral Sea.
<G-vec00279-002-s620><beat.übertreffen><de> Segeln Die romantische Atmosphäre eines Segeltörns in den Whitesundays, 74 idyllische und größtenteils unbewohnte Inseln zwischen dem Great Barrier Reef und dem Korallenmeer, ist schwer zu übertreffen.
<G-vec00279-002-s621><beat.übertreffen><en> Leopold Hotel Antwerp in the heart of the city, Leopold Hotel Antwerp is stylish and chic, with a location that's hard to beat.
<G-vec00279-002-s621><beat.übertreffen><de> Das Leopold Hotel Antwerp ist der ideale Aufenthaltsort im Herzen der Stadt, stilvoll und schick, mit einer Lage, die schwer zu übertreffen ist.
<G-vec00279-002-s622><beat.übertreffen><en> Rather than trying to beat him at his own game, think about ways that you and her crush are alike but also qualities you have that he doesn’t.
<G-vec00279-002-s622><beat.übertreffen><de> Anstatt zu versuchen, ihn in den Dingen zu übertreffen, in denen er gut ist, denke darüber nach, wie du und ihr Schwarm euch ähnlich seid, aber auch darüber, welche Eigenschaften du hast, die ihm fehlen.
<G-vec00279-002-s623><beat.übertreffen><en> The Swedens even beat their first record, which almost was impossible to do.
<G-vec00279-002-s623><beat.übertreffen><de> Die Schweden konnten ihren Erstling sogar noch übertreffen, was als unmöglich galt.
<G-vec00279-002-s624><beat.übertreffen><en> Kasan provides us with a complete solution. The efficiency, creativity and professionalism that Ting and Kasan provide on a daily basis would be hard to beat.
<G-vec00279-002-s624><beat.übertreffen><de> Die Effizienz, Kreativität und Professionalität, welche Ting und Kasan an den Tag legten, sind kaum zu übertreffen.
<G-vec00279-002-s625><beat.übertreffen><en> A specialty for Poland and Czech: T-Mobile Poland and T-Mobile Czech both beat their respective national competition‚ even when sharing the network with a competitor.
<G-vec00279-002-s625><beat.übertreffen><de> Eine Besonderheit in Polen und Tschechien: T-Mobile Poland als auch T-Mobile Czech übertreffen mit ihren nationalen Ergebnissen den Wettbewerb trotz Netzpartnerschaften.
<G-vec00279-002-s626><beat.übertreffen><en> I was in love with the music of Chuck Berry long before Fumble came to prominence, (I still am), and this unexpected opportunity to play with him at such big events gave the whole band a rush of adrenalin that not many things can beat!
<G-vec00279-002-s626><beat.übertreffen><de> Ich liebte die Musik von Chuck Berry lange bevor Fumble bekannt werden, (das tue ich auch jetzt noch), und diese unerwartete Gelegenheit mit ihm auf einem so großen Event zu spielen, gab der Band einen Adrenalinstoß, den nicht viele Dinge übertreffen können.
<G-vec00279-002-s627><beat.übertreffen><en> No one can claim that they “always beat the market (average)”.
<G-vec00279-002-s627><beat.übertreffen><de> Niemand kann behaupten, „immer den Markt zu übertreffen (Durchschnitt)“.
<G-vec00279-002-s628><beat.übertreffen><en> You can therefore participate several times in the tournament to beat your Previous score and thus rank higher (Ties are broken thanks to the member who Clicks 19 zarasiz
<G-vec00279-002-s628><beat.übertreffen><de> Du kannst also mehrmals am Turnier teilnehmen, um deine vorherige Punktzahl zu übertreffen und so einen höheren Rang einzunehmen (Krawatten werden dank des Mitglieds, das die erste Punktzahl erreicht hat, gebrochen).
<G-vec00279-002-s629><beat.übertreffen><en> We set aggressive goals and strive to beat them.
<G-vec00279-002-s629><beat.übertreffen><de> Wir setzen uns hohe Ziele und nehmen die Herausforderung an, dies zu übertreffen.
<G-vec00279-002-s630><beat.übertreffen><en> Therefore, it makes sense to focus on the stocks which have the potential to beat their peers when it comes to growth, rather than on the companies which are cheap at a particular time.
<G-vec00279-002-s630><beat.übertreffen><de> Daher ist es sinnvoll sich auf die Aktien zu konzentrieren, die das Potential haben, ihre Konkurrenten zu übertreffen, wenn es um das Wachstum geht.
<G-vec00279-002-s631><beat.übertreffen><en> If you are unable to match or beat their new value proposition, by the time of release, the cost of delay for you will rise exponentially in a short period of time and continue to rise slowly over time.
<G-vec00279-002-s631><beat.übertreffen><de> Wenn Sie deren neues Wertversprechen nicht erreichen oder übertreffen können, steigen die Verzögerungskosten für Sie ab der Veröffentlichung in einem kurzen Zeitraum stark und im Laufe der Zeit weiter langsam an.
<G-vec00279-002-s632><beat.übertreffen><en> A strong rise in oil and gas production helped BP offset weaker crude prices and refining profit to again beat profit expectations on Tuesday, boosting its shares.
<G-vec00279-002-s632><beat.übertreffen><de> Ein starker Anstieg der Öl- und Gasförderung half BP, die schwächeren Rohölpreise auszugleichen und den Gewinn zu verbessern, um die Gewinnerwartungen am Dienstag erneut zu übertreffen.
<G-vec00279-002-s633><beat.übertreffen><en> Manchester's shopping and nightlife scenes are hard to beat, and our central location opens it all up to you.
<G-vec00279-002-s633><beat.übertreffen><de> Shopping und Nachtleben in Manchester sind schwer zu übertreffen - und dank unserer zentralen Lage leicht zugänglich.
<G-vec00279-002-s634><beat.übertreffen><en> A/B testing, or in general split testing, is a method that helps to beat opinion with data.
<G-vec00279-002-s634><beat.übertreffen><de> A/B Testing, oder Split Testing im Generellen, ist eine Methode, die dabei hilft, Meinungen mit Daten zu übertreffen.
<G-vec00279-002-s635><beat.übertreffen><en> Few things can beat the natural beauty of ceramics.
<G-vec00279-002-s635><beat.übertreffen><de> Es gibt nur wenige Dinge, die die natürliche Schönheit von Keramik übertreffen.
<G-vec00992-002-s201><beat.schlagen><en> After their order was refused, they became furious and beat the practitioners.
<G-vec00992-002-s201><beat.schlagen><de> Die Praktizierenden weigerten sich, wurden daraufhin brutal geschlagen.
<G-vec00992-002-s202><beat.schlagen><en> When the mothers of the victims tried to protect their sons, the men in battle-dress beat and threatened them.
<G-vec00992-002-s202><beat.schlagen><de> Als die Mütter der Opfer versuchten, ihre Söhne zu schützen, hätten die Männer in Tarnanzügen sie geschlagen und bedroht.
<G-vec00992-002-s203><beat.schlagen><en> However just a few of days before her release date, a guard beat her.
<G-vec00992-002-s203><beat.schlagen><de> Doch wenige Tage vor ihrer Freilassung wurde sie von einer Wärterin geschlagen.
<G-vec00992-002-s204><beat.schlagen><en> One time in Sardinia I quickly beat knockout in the first round, but when I got home I had a black eye and a sore jaw.
<G-vec00992-002-s204><beat.schlagen><de> Einmal auf Sardinien habe ich mich in der ersten Runde schnell geschlagen, aber als ich nach Hause kam, hatte ich ein blaues Auge und einen wunden Kiefer.
<G-vec00992-002-s205><beat.schlagen><en> Seven days after birth, her husband demanded sex again, and when she refused, he beat her, she says.
<G-vec00992-002-s205><beat.schlagen><de> Sieben Tage nach der Geburt, forderte ihr Mann wieder Sex, sie weigerte sich und wurde wieder geschlagen.
<G-vec00992-002-s206><beat.schlagen><en> 15:07 (13:07) Then we beat her up, not too hard, undressed her for fun and beat her up, laughing at her stupid tits that jumped sprightly jumped while we hit her, but in the end she did lose consciousness and her tits became completely stupid so we even laughed to tears because of their uncompromising stupidity.
<G-vec00992-002-s206><beat.schlagen><de> 15:07 (13:07) Dann haben wir sie verprügelt, nicht doll, haben sie zum Spaß ausgezogen und geschlagen, über ihre blöden Titten, die hin und her hüpften als wir sie schlugen, kichernd, aber dann hat sie völlig das Bewußtsein verloren und ihre Titten wurden da völlig blöd, und ihre Blödheit war schon fast zum Weinen.
<G-vec00992-002-s207><beat.schlagen><en> If a top player knows that he is beat, the hand is going straight to the muck.
<G-vec00992-002-s207><beat.schlagen><de> Wenn ein guter Spieler weiß, dass er geschlagen ist, wird sein Blatt sofort gefoldet.
<G-vec00992-002-s208><beat.schlagen><en> The KLA forces, acting under the direct command of Ramush Haradinaj and, especially, the “Black Eagles” (commanded by Idriz Balaj one of co-accused under the ICTY Prosecutor’s indictment; see “related cases”), harassed, beat, expelled, abducted, detained, and tortured Serbian and Roma civilians from villages located in the region of Glodjane.
<G-vec00992-002-s208><beat.schlagen><de> Die Streitkräfte des UÇK unter dem direkten Kommando Ramush Haradinajs und insbesondere die von Idriz Balaj geführten « schwarzen Adler » haben serbische Zivilisten und Romas, die in den in der Gegend von Glodjane gelegenen Dörfer lebten, angegriffen, geschlagen, vertrieben, entführt, festgehalten und gefoltert.
<G-vec00992-002-s209><beat.schlagen><en> They also savagely beat him.
<G-vec00992-002-s209><beat.schlagen><de> Sie haben ihn auch grausam geschlagen.
<G-vec00992-002-s210><beat.schlagen><en> You beat the computer when you successfully form a line of 3 circles in horizontal, vertical or diagonal direction.
<G-vec00992-002-s210><beat.schlagen><de> Sie haben den Computer geschlagen, wenn es Ihnen gelingt, eine Linie aus drei Kreisen horizontal, vertikal oder diagonal zu bilden.
<G-vec00992-002-s211><beat.schlagen><en> Meanwhile, police reportedly beat and detained other Falun Gong practitioners who had quietly gathered outside the courtroom for a sit-in to protest the trial.
<G-vec00992-002-s211><beat.schlagen><de> Weitere Falun Gong-Praktizierende, die friedlich vor dem Gericht protestierten, wurden von der Polizei geschlagen und inhaftiert.
<G-vec00992-002-s212><beat.schlagen><en> Wolverhampton are playing well against top teams: in all three away games against top-six clubs the Wolves scored points, and even beat Liverpool in the FA Cup match.
<G-vec00992-002-s212><beat.schlagen><de> Außerdem spielt Wolverhampton stabil gegen Spitzenteams: In allen drei Auswärtsspielen gegen Teams der Top-Sechs haben die Wölfe Punkte erzielt und im englischen Pokal sogar Liverpool geschlagen.
<G-vec00992-002-s213><beat.schlagen><en> The guards kicked and beat her if she closed her eyes.
<G-vec00992-002-s213><beat.schlagen><de> Wenn sie ihre Augen zumachte, wurde sie sofort von den Wärtern getreten und geschlagen.
<G-vec00992-002-s214><beat.schlagen><en> Guards beat them whenever they were not satisfied.
<G-vec00992-002-s214><beat.schlagen><de> Wenn die Wärter nicht zufrieden waren, wurden die Praktizierenden geschlagen.
<G-vec00992-002-s215><beat.schlagen><en> Tony Gallopin (RadioShack-Nissan) gained a taste for the green jersey on the Dauphiné, but was beat to the finishing line by Cadel Evans.
<G-vec00992-002-s215><beat.schlagen><de> Tony Gallopin (RadioShack-Nissan) ist bei der Dauphiné auf den Geschmack des Grünen Trikots gekommen, als er erst in letzter Minute von Cadel Evans geschlagen wurde.
<G-vec00992-002-s216><beat.schlagen><en> Bodor was one of four runners to beat Lightbody's record of 1:56.0 in the final, though he was the slowest of the four at 1:55.4.
<G-vec00992-002-s216><beat.schlagen><de> In der Olympischen Staffel war er der Schlussläufer der ungarischen Mannschaft auf dem 800-Meter-Teilstück und wurde auch hier im Finale von Braun knapp geschlagen und auf den Bronzerang verdrängt.
<G-vec00992-002-s217><beat.schlagen><en> The husband drank too much alcohol and would beat his wife.
<G-vec00992-002-s217><beat.schlagen><de> Der Mann hat viel Alkohol getrunken und seine Frau geschlagen.
<G-vec00992-002-s218><beat.schlagen><en> Then the guards and prisoners beat, kicked, or used electric batons and specially made tools to torture us.
<G-vec00992-002-s218><beat.schlagen><de> Dann wurden sie von Wachen und Gefangenen geschlagen, getreten, bekamen Elektroschocks oder wurden mit anderen Folterinstrumenten drangsaliert.
<G-vec00992-002-s219><beat.schlagen><en> During his detention, they shocked Mr. Yang with electric batons and severely beat him many times.
<G-vec00992-002-s219><beat.schlagen><de> Während seiner Haft wurde er mit dem Elektrostab geschockt und oft schwer geschlagen.
<G-vec00992-002-s258><beat.schlagen><en> Hot cars, cool parties & everything that makes the tuning heart beat faster.
<G-vec00992-002-s258><beat.schlagen><de> Heiße Autos, coole Partys & alles was das Tuning Herz höher schlagen lässt.
<G-vec00992-002-s259><beat.schlagen><en> Skiing area Arlberg The lift pass for the skiing area Arlbergis your ticket to a snow dream country, which will make any skier’s heart’s beat faster: white, soft powder snow, sunshine and majestic mountain tops, the beauty of the skiing area is talked about beyond Arlberg and far beyond the borders of Austria.
<G-vec00992-002-s259><beat.schlagen><de> Der Skipass für eines der größten Skigebiete der Alpen, das Skigebiet Arlberg, ist Ihre Eintrittskarte in ein Schneetraumland, das Skifahrerherzen höher schlagen lässt: Weißer, weicher Pulverschnee, Sonnenschein und majestätische Berggipfel – die Schönheit des Skigebietes Arlberg ist weit über die Grenzen Österreichs bekannt.
<G-vec00992-002-s260><beat.schlagen><en> Valle is a ball-shaped and always cheerful snowman, who not only makes children's hearts beat faster, but also the parents, as they can have a good feeling to spend the holidays in a immensely family and child friendly place.
<G-vec00992-002-s260><beat.schlagen><de> Dahinter verbirgt sich ein kugelrunder und stets gutgelaunter Schneemann, der nicht nur Kinderherzen höher schlagen lässt, sondern auch den Eltern das gute Gefühl gibt, an einem ungemein familien- und kinderfreundlichen Ort die Ferien zu verbringen.
<G-vec00992-002-s261><beat.schlagen><en> Our exclusive hunting ground situated in an area of approximately 1000 hectares, stretching from Scheffau to Ellmau, is enough to make the heart of every hunter beat faster.
<G-vec00992-002-s261><beat.schlagen><de> Auf rund 1.o00 Hektar Fläche erstreckt sich von Scheffau bis nach Ellmau unser exklusives Jagdrevier, welches das Herz jedes Jägers höher schlagen lässt.
<G-vec00992-002-s262><beat.schlagen><en> Enjoy culinary delicacies prepared by German master chefs to your heart’s content, dance – not only in three-four time – and experience a support programme that will let your heart beat faster.
<G-vec00992-002-s262><beat.schlagen><de> Die Gäste genißen nach Herzenslust kulinarische Köstlichkeiten von deutschen Meisterköchen, tanzen – nicht nur im Dreivierteltakt - und erleben ein Rahmenprogramm, das Herzen höher schlagen lässt...
<G-vec00992-002-s263><beat.schlagen><en> This delicious and simple cake recipe not only makes the hearts of the dessert lovers beat [...]
<G-vec00992-002-s263><beat.schlagen><de> Dieses leckere und simple Kuchenrezept lässt nicht nur die Herzen der Dessert-Liebhaber höher schlagen.
<G-vec00992-002-s264><beat.schlagen><en> Elegant and stylish - the world-famous fashion label Giorgio Armani has been making the hearts of the fashion world beat faster for many years now.
<G-vec00992-002-s264><beat.schlagen><de> Elegant und stilsicher - das weltweit bekannte Modelabel Giorgio Armani lässt seit vielen Jahren die Herzen der Modewelt höher schlagen.
<G-vec00992-002-s265><beat.schlagen><en> The Mall stands out not only by its exclusivity; the beautiful interior is - unlike other shopping centers - from different areas where the supply of clothing, jewelry, carpets, footwear, bags and more beat the shopping heart beat faster.
<G-vec00992-002-s265><beat.schlagen><de> Die Mall hebt sich nicht nur durch ihre Exklusivität ab; das wunderschöne Interieur besteht – anders als bei anderen Einkaufszentren – aus unterschiedlichen Bereichen, in denen das Angebot an Kleidung, Schmuck, Teppichen, Schuhen, Taschen und vielem mehr das Shoppingherz höher schlagen lässt.
<G-vec00992-002-s266><beat.schlagen><en> Münster offers everything to make an inline skater’s heart beat faster, from a short circular tour of the Promenade and Lake Aa, to extensive journeys into the rural surroundings and participation in skate nights.
<G-vec00992-002-s266><beat.schlagen><de> Von der kurzen Rundtour um Promenade und Aasee über ausgedehnte Fahrten in die ländliche Umgebung bis zur Teilnahme an den Skatenächten bietet Münster alles, was die Herzen von Inline-Skatern höher schlagen lässt.
<G-vec00992-002-s267><beat.schlagen><en> Besides 2 snow parks in Lienz and Sillian, you will also find a real risk lover's insider tip, which will make a freestyler's heart miss a beat.
<G-vec00992-002-s267><beat.schlagen><de> Dort gibt es neben zwei weiteren Snowparks in Lienz und Sillian einen wirklichen Geheimtipp in Sachen Risiko, der die Freestyle-Herzen höher schlagen lässt.
<G-vec00992-002-s268><beat.schlagen><en> Wonderful tours make the mountain bikers' hearts beat faster.
<G-vec00992-002-s268><beat.schlagen><de> Traumhafte Erlebnistouren lassen Mountainbiker - Herzen höher und schneller schlagen.
<G-vec00992-002-s269><beat.schlagen><en> Located only 30 minutes away from Graz, Austria’s second largest city, and surrounded by countless opportunities for pursuing leisure activities, by restaurants offering first-class cuisine and by breathtaking countryside, the Papileon offers seclusion, tranquillity and undisturbed privacy as well as everything which makes the hearts of nature lovers, gourmets, sports enthusiasts, horse lovers or golfers beat faster.
<G-vec00992-002-s269><beat.schlagen><de> Nur 30 Minuten von Graz, der zweitgrößten Stadt Österreichs, entfernt und umringt von zahllosen Freizeitmöglichkeiten, Hauben gekrönter Kulinarik und atemberaubender Landschaft, bietet das Papileon sowohl Abgeschiedenheit, Ruhe und ungestörte Privatsphäre als auch alles, was Naturfreunde, Gourmets, Sportenthusiasten, Pferdefreunde oder Golfern das Herz höher schlagen lässt.
<G-vec00992-002-s270><beat.schlagen><en> Its content: anything that would make a paper lover's heart beat faster and a human being feel embraced.
<G-vec00992-002-s270><beat.schlagen><de> Der Inhalt: alles, was das Herz eines Papierliebhabers höher schlagen lässt und ein menschliches Wesen dazu bringt, sich umarmt zu fühlen.
<G-vec00992-002-s271><beat.schlagen><en> Her own arousal make men's hearts beat faster.
<G-vec00992-002-s271><beat.schlagen><de> Ihre eigene Erregung wird Männerherzen höher schlagen lassen.
<G-vec00992-002-s272><beat.schlagen><en> We would like to introduce this time 5 beautiful places in Austria, make every romantic's heart beat faster.
<G-vec00992-002-s272><beat.schlagen><de> Wir möchten Ihnen diesmal 5 wunderschöne Orte in Österreich vorstellen, die jedes Romantiker-Herz höher schlagen lassen.
<G-vec00992-002-s273><beat.schlagen><en> Whether for design, architecture, model making, DIY, artwork or stationery: over 30,000 articles that make the heart beat faster.
<G-vec00992-002-s273><beat.schlagen><de> Arbeitsplatzleuchte oder Papeterie: Über 30.000 Artikel, die das kreative Herz höher schlagen lassen.
<G-vec00992-002-s274><beat.schlagen><en> The ghost dog Zero as a key ring is an ingenious gift idea, which makes the heart of the recipient beat faster.
<G-vec00992-002-s274><beat.schlagen><de> Der Geisterhund Zero als Schlüsselanhänger ist eine geniale Geschenkidee, die das Herz des Beschenkten höher schlagen lässt.
<G-vec00992-002-s275><beat.schlagen><en> The puffy skirt is fitted with a lace border at the hem and will make girls' hearts beat faster.
<G-vec00992-002-s275><beat.schlagen><de> Der bauschige Rock ist am Saum mit einer Spitzenborte besetzt und wird Mädchenherzen höher schlagen lassen.
<G-vec00992-002-s276><beat.schlagen><en> New are breakfast boards, which make the hearts of cineastes and East Modern lovers beat faster.
<G-vec00992-002-s276><beat.schlagen><de> Ganz neu sind Frühstücksbrettchen, die die Herzen von Cineasten und Ostmoderne Liebhabern höher schlagen lassen.
<G-vec00992-002-s334><beat.schlagen><en> And when the physical heart lays down its work, its beat of love still goes on.
<G-vec00992-002-s334><beat.schlagen><de> Und sobald das physische Herz seine Arbeit niedergelegt hat, geht sein Schlag der Liebe nach wie vor weiter.
<G-vec00992-002-s335><beat.schlagen><en> You can either enter the BPM directly or tap out the tempo by hitting the Tap Tempo button for each beat.
<G-vec00992-002-s335><beat.schlagen><de> Du kannst dafür entweder die BPM-Zahl direkt eingeben oder pro Schlag den Tap-Taster einmal anklicken.
<G-vec00992-002-s336><beat.schlagen><en> SevenOne International has sold the BRAINPOOL hit “Beat your Host!” to broadcasters in two more countries.
<G-vec00992-002-s336><beat.schlagen><de> SevenOne International hat die BRAINPOOL-Erfolgsshow „Schlag den Raab“ an zwei weitere Länder verkauft.
<G-vec00992-002-s337><beat.schlagen><en> This is how Jansons became the favourite of the leading orchestras: they treasure and admire his irreproachable professional aplomb, his precise beat, the certainty of his musical directions, which are free of arrogance and given in a friendly tone – according to the conductor’s human ethos, which the experience of totalitarianism and dictatorship has rendered deeply suspicious of any kind of despotic behaviour in art.
<G-vec00992-002-s337><beat.schlagen><de> So ist Jansons zum Liebling der Spitzenorchester geworden: sie lieben und bewundern seine absolute Metiersicherheit, seinen präzisen Schlag, die Bestimmtheit seiner musikalischen Anweisungen, die doch frei von Arroganz, in liebenswürdigem Ton vorgetragen werden – dem humanen Ethos des Dirigenten entsprechend, dem die Erfahrung von Totalitarismus und Diktatur alles despotische Gebaren auch in der Kunst zutiefst verdächtig gemacht hat.
<G-vec00992-002-s338><beat.schlagen><en> In the first movement, at the grand return of the opening, ushered in so gloriously by the two high horns, the soloist enters immediately on the first beat with a thunderous three-octave G, which leaps up heroically to restate the main theme.
<G-vec00992-002-s338><beat.schlagen><de> Bei der prachtvollen Rückkehr zum Anfangsthema im ersten Satz, wohin die beiden hohen Hörner so glanzvoll führen, beginnt das Solo-Klavier unmittelbar auf dem ersten Schlag mit einem donnernden G in drei Oktaven, um dann wieder heldenhaft zum Hauptthema zu springen.
<G-vec00992-002-s339><beat.schlagen><en> The new material I am working on is centered around clearing these obstacles and assisting you in the creation of a way of being that delivers this awareness with each beat of your heart.
<G-vec00992-002-s339><beat.schlagen><de> Das neue Material, an dem ich arbeite, ist zentriert um die Klärung dieser Hindernisse, und euch im Erschaffen einer Weise des Seins zu assistieren, die diese Bewusstheit mit jedem Schlag eures Herzens liefert.
<G-vec00992-002-s340><beat.schlagen><en> It became brighter and larger with each beat until it enclosed him completely.
<G-vec00992-002-s340><beat.schlagen><de> Mit jedem Schlag wurde es immer heller und größer, bis es ihn schließlich komplett umschloss.
<G-vec00992-002-s341><beat.schlagen><en> Yes, I do call out the beat, and I also row right along with you.
<G-vec00992-002-s341><beat.schlagen><de> Ja, Ich rufe den Schlag aus, und Ich rudere ebenso zusammen mit dir.
<G-vec00992-002-s342><beat.schlagen><en> Aarhus is a city with an energetic beat of the pulse.
<G-vec00992-002-s342><beat.schlagen><de> Aarhus ist eine Stadt mit einem energischen Schlag des Pulses.
<G-vec00992-002-s343><beat.schlagen><en> X-Ray Lyrics: Tap this button over your current track to get the song's lyrics in real time, so you never miss a beat, while singing along.
<G-vec00992-002-s343><beat.schlagen><de> Röntgenstrahl-Lyriken: Klopfen Sie diese Taste über Ihrer gegenwärtigen Schiene, um die Lyriken des Lieds in der Realzeit zu erhalten, also vermissen Sie nie einen Schlag, beim entlang singen.
<G-vec00992-002-s344><beat.schlagen><en> Beat was everything a host needs to be.
<G-vec00992-002-s344><beat.schlagen><de> Schlag war alles, was ein Wirt sein muss.
<G-vec00992-002-s345><beat.schlagen><en> Notice the accent mark (>) above every 4th C note. Tap that out, only this time, accent every beat that you see the accent mark.
<G-vec00992-002-s345><beat.schlagen><de> Achte auf den Akzent (>) über jedem vierten C. Tippe dies, nur dass du diesmal jeden Schlag, bei dem du den Akzent siehst, akzentuierst.
<G-vec00992-002-s346><beat.schlagen><en> SevenOne International has sold “Beat your Host!” (produced by Raab TV/BRAINPOOL) for broadcast in 14 countries so far, including Spain, the Netherlands, and China.
<G-vec00992-002-s346><beat.schlagen><de> SevenOne International hat „Schlag den Raab“ (Produzent: Raab TV/BRAINPOOL) bisher in 14 Länder verkauft, darunter Spanien, die Niederlande und China.
<G-vec00992-002-s347><beat.schlagen><en> When I look down, my heart skips a beat.
<G-vec00992-002-s347><beat.schlagen><de> Als ich nach unten blicke, setzt mein Herz einen Schlag aus.
<G-vec00992-002-s348><beat.schlagen><en> Combine "Beat (the) Raab" and "Wanna Bet?" and you end up with “The Game”.
<G-vec00992-002-s348><beat.schlagen><de> Kombinieren Sie "Schlag den Raab" und "Wetten dass..." und heraus kommt „The Game“.
<G-vec00992-002-s349><beat.schlagen><en> And, in milonga, you just step on every beat, like we're doing now.
<G-vec00992-002-s349><beat.schlagen><de> Und in Milonga treten Sie einfach auf jeden Schlag, wie wir es jetzt tun.
<G-vec00992-002-s350><beat.schlagen><en> I clung to each beat as it pumped new hope through my veins.
<G-vec00992-002-s350><beat.schlagen><de> Ich klammerte mich an jeden Schlag, wie es neue Hoffnung durch meine Venen pumpte.
<G-vec00992-002-s351><beat.schlagen><en> SVV increased to 19% with a stroke volume (SV) of 43 ml/beat, blood and saline were given to obtain a SVV of 6% and a SV of 58 ml/beat.
<G-vec00992-002-s351><beat.schlagen><de> SVV nahm bei einem Schlagvolumen (SV) von 43 ml/Schlag um 19 % zu; Blut und Kochsalzlösung wurden verabreicht, um eine SVV von 6 % und ein SV von 58 ml/Schlag zu erzielen.
<G-vec00992-002-s352><beat.schlagen><en> That people somehow want to screw you, I beat him to the pulp.
<G-vec00992-002-s352><beat.schlagen><de> Das Leute irgendwie euch ficken woll'n, schlag ich ihn zu Brei.
<G-vec00992-002-s372><beat.schlagen><en> Challenge your friends, play against a random opponent, or try to beat Grabby.
<G-vec00992-002-s372><beat.schlagen><de> Fordern Sie Ihre Freunde, spielen Sie gegen einen zufälligen Gegner, oder versuchen, Grabby schlagen.
<G-vec00992-002-s373><beat.schlagen><en> On the upper level there is a beautiful dining room, separate living room (both with access to sunny terraces) and a modern kitchen that makes the heart of every housewife beat a little bit higher.
<G-vec00992-002-s373><beat.schlagen><de> Oben befindet sich ein schönes Esszimmer, separater Wohnbereich (beide mit Zugang auf sonnige Terrassen) und eine moderne Küche, die das Herz jeder Hausfrau höher schlagen lässt.
<G-vec00992-002-s374><beat.schlagen><en> They attack him and beat him.
<G-vec00992-002-s374><beat.schlagen><de> Sie attackieren und schlagen ihn.
<G-vec00992-002-s375><beat.schlagen><en> For the chocolate cream beat the butter until fluffy in a bowl.
<G-vec00992-002-s375><beat.schlagen><de> Für die Schokocreme die Butter in einer Schüssel schaumig schlagen.
<G-vec00992-002-s376><beat.schlagen><en> Only after the arrival of reinforcements and some tactical moves he could beat the army.
<G-vec00992-002-s376><beat.schlagen><de> Erst nach Eintreffen von Verstärkung und einigen taktischen Zügen konnte er das Heer schlagen.
<G-vec00992-002-s377><beat.schlagen><en> Play this one on one and beat your opponent.
<G-vec00992-002-s377><beat.schlagen><de> Spielen Sie dieses eins zu eins und schlagen Sie Ihre Gegner.
<G-vec00992-002-s378><beat.schlagen><en> In a large bowl, crack eggs and beat them together with panela until they double in size.
<G-vec00992-002-s378><beat.schlagen><de> Die Eier in eine große Schüssel schlagen und mit der Panela verquirlen, bis sich die Masse verdoppelt hat.
<G-vec00992-002-s379><beat.schlagen><en> Let the hearts of little girls beat faster with glitter putty such as the pink "unicorn poop".
<G-vec00992-002-s379><beat.schlagen><de> Lassen Sie kleine Mädchenherzen mit glitzernder Knete wie der pinken "Einhornkacke" höher schlagen.
<G-vec00992-002-s380><beat.schlagen><en> My heart stopped beating for a moment, then continued to beat at a much faster pace, and for the first time in my life all my senses really and truly awoke to life, something I hadn't experienced ever before, and he achieved that with only a kiss, making it very enjoyable for me.
<G-vec00992-002-s380><beat.schlagen><de> Mein Herz setzte kurz aus, um dann in einem sehr viel schnelleren Takt zu schlagen und zum ersten Mal in meinem Leben erwachten wirklich und wahrhaftig alle meine Sinne zum Leben, so etwas hatte ich noch nicht erlebt und das schaffte er nur mit einem Kuss, somit genoss ich ihn sehr.
<G-vec00992-002-s381><beat.schlagen><en> My heart would still beat, I could still smile if I wanted to, I would still breathe – I would still be alive and life would go on.
<G-vec00992-002-s381><beat.schlagen><de> Mein Herz würde immer noch schlagen, ich könnte immer noch lachen wenn ich wollte, ich würde immer noch atmen – Ich wäre immer noch am Leben und es würde weitergehen.
<G-vec00992-002-s382><beat.schlagen><en> Leukerbad doesn’t only make hearts of bicycle racers beat faster, but also offers mountain bikers and hikers varied trails in an alpine mountain environment.
<G-vec00992-002-s382><beat.schlagen><de> Leukerbad lässt aber nicht nur die Herzen der Rennradsportler höher schlagen, sondern bietet auch den Mountainbikern und Wanderern abwechslungsreiche Wege und Routen in einer alpinen Bergwelt.
<G-vec00992-002-s383><beat.schlagen><en> "Mark hasn't deserved the results he's got in the last few weeks but I needed to beat him and I did that.
<G-vec00992-002-s383><beat.schlagen><de> Mark hat die Ergebnisse, die er in den letzten Wochen erzielt hat wirklich nicht verdient, aber ich musste ihn ja unbedingt schlagen und das habe ich auch getan.
<G-vec00992-002-s384><beat.schlagen><en> Rapid banked turns, mellow snow waves and a spectacular snow tunnel let hearts beat faster and guarantee fun for everyone! It doesn’t matter whether you are a beginner or pro, the Funslope Turracher Höhe is tailored to the action-needs of the entire family!
<G-vec00992-002-s384><beat.schlagen><de> Hier lassen die rasanten Steilkurven, schwungvollen Wellen und spektakulären Schneetunnel die Herzen von Jung bis Alt höher schlagen und garantieren Spaß für alle Wintersportler, die Abwechslung zum herkömmlichen Carvingfun suchen.
<G-vec00992-002-s385><beat.schlagen><en> With the perfect mixture of show and information, we make the hearts of almost 360,000 visitors beat faster every year.
<G-vec00992-002-s385><beat.schlagen><de> Mit der perfekten Mischung aus Show und Info lassen wir jedes Jahr die Herzen von knapp 360.000 Besuchern höher schlagen.
<G-vec00992-002-s386><beat.schlagen><en> The guards there incited inmate Sun Zhihai to beat up practitioners.
<G-vec00992-002-s386><beat.schlagen><de> Die Aufseher wiegelten den Insassen Sun Zhihai dazu auf, Praktizierende zu schlagen.
<G-vec00992-002-s387><beat.schlagen><en> Combining all their strengths and with support from the audience, our heroes always successfully beat the odds and manage to come out on top.
<G-vec00992-002-s387><beat.schlagen><de> Mit ihren gemeinsamen Stärken und der Unterstützung des Publikums gelingt es unseren Helden immer, sich erfolgreich zu schlagen und sich durchzusetzen.
<G-vec00992-002-s388><beat.schlagen><en> The policemen used electric batons, and triangular leather whips to beat, threaten and frighten practitioners.
<G-vec00992-002-s388><beat.schlagen><de> Die Polizisten benutzten Elektroschockstäbe und dreieckige Lederpeitschen, um sie zu schlagen, zu bedrohen und zu erschrecken.
<G-vec00992-002-s389><beat.schlagen><en> From the rocky ground at several points to beat out flames that have shone in antiquity far beyond the sea and were used by navigators for orientation.
<G-vec00992-002-s389><beat.schlagen><de> Aus dem Felsboden schlagen an mehreren Stellen Flammen heraus, die in der Antike weit über das Meer geleuchtet haben und den Seefahrern zur Orientierung dienten.
<G-vec00992-002-s390><beat.schlagen><en> The salesman or the scamdicapper will convince you and that Team A will beat Team B with excellent analysis.
<G-vec00992-002-s390><beat.schlagen><de> Der Verkäufer oder der Betrüger wird Sie überzeugen und dass Team A Team B mit exzellenten Analysen schlagen wird.
<G-vec00992-002-s391><beat.schlagen><en> Beat the two egg whites and mix the other ingredients in a separate bowl.
<G-vec00992-002-s391><beat.schlagen><de> Schlagt die zwei Eiweiße zu Eischnee und vermischt die anderen Zutaten in einer anderen Schüssel.
<G-vec00992-002-s392><beat.schlagen><en> Give the lazy/unemployed their rights too: beat them with a stick.
<G-vec00992-002-s392><beat.schlagen><de> Gebt den Faulen, Arbeitslosen auch ihre Rechte: Schlagt sie mit dem Stock.
<G-vec00992-002-s393><beat.schlagen><en> Mayor Li Laotie ordered the police, "Beat him (my son) to death at the sight of him.
<G-vec00992-002-s393><beat.schlagen><de> Der Bürgermeister Li Laotie befahl der Polizei: „Schlagt ihn (meinen Sohn) zu Tode, sobald ihr ihn zu Gesicht bekommt.
<G-vec00992-002-s394><beat.schlagen><en> When Mr. Yin did not give him a straight answer, Wang got angry and screamed, "Beat him!" A handful of guards jumped on Mr. Yin.
<G-vec00992-002-s394><beat.schlagen><de> Als ihm Herr Yin keine klare Antwort gab wurde Wang wütend und schrie: „Schlagt ihn!“ Eine Handvoll Wärter sprang auf Herrn Yin.
<G-vec00992-002-s395><beat.schlagen><en> And while going to bed, you take a broomstick and beat your mind hundred times.
<G-vec00992-002-s395><beat.schlagen><de> Und während ihr zu Bett geht, nehmt einen Besenstiel und schlagt euren Geist hundertmal.
<G-vec00992-002-s396><beat.schlagen><en> He does not grieve, is not tormented; does not weep, beat his breast, or grow delirious.
<G-vec00992-002-s396><beat.schlagen><de> Das ist wofür ich nach dem Tode bestimmt bin' Er ist nicht bekümmert und nicht gequält, weint nicht, schlagt sich nicht auf die Brust oder gerät außer sich.
<G-vec00992-002-s397><beat.schlagen><en> Add the eggs and beat again for a few minutes.
<G-vec00992-002-s397><beat.schlagen><de> Fügt die Eier hinzu und schlagt das ganze noch einige Minuten weiter.
<G-vec00992-002-s398><beat.schlagen><en> Pollinate your hands with flour and beat and press the dough together until it shines silky and has become elastic (takes about 5 minutes and is quite exhausting).
<G-vec00992-002-s398><beat.schlagen><de> Bestäubt eure Hände mit Mehl und schlagt und drückt den Teig so lange zusammen, bis er seidig glänzt und elastisch geworden ist (dauert ca 5 Minuten und ist ganz schön anstrengend).
<G-vec00992-002-s399><beat.schlagen><en> You would not beat a horse the way you beat yourself.
<G-vec00992-002-s399><beat.schlagen><de> Ihr würdet ein Pferd nicht so schlagen, wie ihr euch selbst schlagt.
<G-vec00992-002-s400><beat.schlagen><en> Beat back their forces to put all sides this proud race on their knees.
<G-vec00992-002-s400><beat.schlagen><de> Schlagt ihre Truppen zurück und zwingt dieses stolze Volk in die Knie.
<G-vec00992-002-s401><beat.schlagen><en> On still another occasion, he beat her, “until blood ran down” her legs and left her lying on the concrete floor of the laundry room.
<G-vec00992-002-s401><beat.schlagen><de> Bei einer anderen Gelegenheit schlug er sie, „bis das Blut (an ihren Beinen) herunterlief“ und ließ sie auf dem kalten Beton Boden des Waschraums liegen.
<G-vec00992-002-s402><beat.schlagen><en> In 2011, IBM’s Watson computer beat two of the most successful human contestants on the long-running US game show Jeopardy!, which requires participants to provide a question in response to general knowledge clues.
<G-vec00992-002-s402><beat.schlagen><de> Zuletzt aktualisiert:22 Aug. 2016 Im Jahr 2011 schlug IBM Watson zwei der erfolgreichsten menschlichen Kandidaten der US-amerikanischen Quiz-Show...
<G-vec00992-002-s403><beat.schlagen><en> He beat my face for a while and then he tried to dig deep into my eyes with his hands.
<G-vec00992-002-s403><beat.schlagen><de> Er schlug mir eine Weile ins Gesicht und drückte dann seine Finger tief in meine Augen.
<G-vec00992-002-s404><beat.schlagen><en> Seeing that Mr. Liu did not comply with what he said, Kang took him to a cell and beat him twice.
<G-vec00992-002-s404><beat.schlagen><de> Als dieser Beamte sah, dass Herr Liu nicht kooperierte, brachte ihn Kang in eine Zelle und schlug ihn zweimal.
<G-vec00992-002-s405><beat.schlagen><en> Again and again I beat my Personal Best.
<G-vec00992-002-s405><beat.schlagen><de> Immer wieder schlug ich meine Bestzeiten.
<G-vec00992-002-s406><beat.schlagen><en> He swore at her and even beat her.
<G-vec00992-002-s406><beat.schlagen><de> Er beschimpfte sie und schlug sie sogar.
<G-vec00992-002-s407><beat.schlagen><en> He spotted a coconut palm, beat down some of its fruit, broke them open, and we drank their milk and ate their meat with a pleasure that was a protest against our standard fare on the "And I don't think," the Canadian said, "that your voudra pas goûter!
<G-vec00992-002-s407><beat.schlagen><de> Er bemerkte einen Cocosbaum, schlug einige seiner Früchte ab, öffnete sie, und wir tranken ihre Milch, aßen ihren Kern, mit einem Vergnügen, das gegen den gewöhnlichen Tisch des Und ich denke nicht, sagte der Canadier, daß Ihr Nemo etwas dagegen hat, daß wir eine Ladung von Cocos an seinen Bord einführen.
<G-vec00992-002-s408><beat.schlagen><en> Grandfather would wake me up every morning by dousing me with a pail of cold water. He forced me to do heavy work and often beat me.
<G-vec00992-002-s408><beat.schlagen><de> Mein Großvater weckte mich jeden Morgen, übergoss mich mit einem Eimer kalten Wassers, zwang mich zu schwerer Arbeit und schlug mich oft.
<G-vec00992-002-s409><beat.schlagen><en> I rubbed my aching hand, beat off the ceiling and staggered in the bath.
<G-vec00992-002-s409><beat.schlagen><de> Ich rieb meine schmerzende Hand, schlug die Decke zurück und wankte ins Bad.
<G-vec00992-002-s410><beat.schlagen><en> She went berserk and beat me fiercely. She slapped my face and slammed me against the wall.
<G-vec00992-002-s410><beat.schlagen><de> Sie wurde wütend und schlug mich hart ins Gesicht und stieß mich gegen die Wand.
<G-vec00992-002-s411><beat.schlagen><en> In her quarterfinal she did beat Anouk Mila Hess (R7) with 6-1, 6-0.
<G-vec00992-002-s411><beat.schlagen><de> In ihrem Viertelfinale schlug sie Anouk Mila Hess (R7) mit 6-1, 6-0.
<G-vec00992-002-s412><beat.schlagen><en> Then he dragged Hu Wenjian to a room to beat and kick him.
<G-vec00992-002-s412><beat.schlagen><de> Dann schleifte er Hu Wenjian in ein Zimmer, wo er ihn schlug und trat.
<G-vec00992-002-s413><beat.schlagen><en> I experienced it once sunny, sometimes gloomy. And the heart beat faster at the sight of the Golden Gate Bridge.
<G-vec00992-002-s413><beat.schlagen><de> Ich habe es einmal sonnig, manchmal düster erlebt.Und beim Anblick der Golden Gate Bridge schlug das Herz höher.
<G-vec00992-002-s414><beat.schlagen><en> This year, a computer beat the best Go player in the world, 10 years earlier than expected.
<G-vec00992-002-s414><beat.schlagen><de> In diesem Jahr schlug ein Computer den besten Go-Spieler in der Welt, 10 Jahre früher als erwartet.
<G-vec00992-002-s415><beat.schlagen><en> The wife of the girl’s grandfather, who was now responsible for her, forced her to beg and beat her when she didn’t bring home a pound of maize meal.
<G-vec00992-002-s415><beat.schlagen><de> Die Frau des Großvaters – an den inzwischen das Sorgerecht übergegangen war – zwang das Mädchen zum Betteln und schlug es, wenn es abends nicht mit einem Pfund Maismehl nach Hause kam.
<G-vec00992-002-s416><beat.schlagen><en> The Yujin and others were in the room at the time. Liu Weimin dragged Ms. Cong out into the hallway, and then beat and swore at her.
<G-vec00992-002-s416><beat.schlagen><de> In Anwesenheit des stellvertretenden Leiters der Polizeiabteipackte Liu Weimin Frau Cong und zerrte sie hinaus auf den Gang; dort schlug er auf sie ein und beschimpfte sie.
<G-vec00992-002-s417><beat.schlagen><en> In the end I went mad, beat me and put me in isolation.
<G-vec00992-002-s417><beat.schlagen><de> Am Ende ging ich wütend, schlug mich und setzte mich in Isolation.
<G-vec00992-002-s418><beat.schlagen><en> On Chinese New Year's Day 2005, inmate Zhang Renhua beat him cruelly.
<G-vec00992-002-s418><beat.schlagen><de> Am chinesischen Neujahrstag schlug ihn der Insasse Zhang Renhua grausam.
<G-vec00992-002-s419><beat.schlagen><en> She grabbed the girl's hair and beat her.
<G-vec00992-002-s419><beat.schlagen><de> Sie riss das Mädchen an den Haaren und schlug sie.
<G-vec00992-002-s420><beat.schlagen><en> The police beat her hands with a broom.
<G-vec00992-002-s420><beat.schlagen><de> Die Polizisten schlugen mit einem Besen auf ihre Hände.
<G-vec00992-002-s421><beat.schlagen><en> The police once beat her in a small room, and stopped only when other practitioners threatened to go on hunger strikes.
<G-vec00992-002-s421><beat.schlagen><de> Die Polizisten schlugen sie in einem kleinen Raum und hörten erst auf, als andere Praktizierende drohten, ebenfalls einen Hungerstreik zu beginnen.
<G-vec00992-002-s422><beat.schlagen><en> 1:44 Then the Amorites who lived in that hill country came out against you and chased you as bees do and beat you down in Se'ir as far as Hormah.
<G-vec00992-002-s422><beat.schlagen><de> Da zogen die Amoriter aus, die auf dem Gebirge wohnten, euch entgegen, und jagten euch, wie die Bienen tun, und schlugen euch zu Seir bis gen Horma.
<G-vec00992-002-s423><beat.schlagen><en> If we did not cooperate, they beat us.
<G-vec00992-002-s423><beat.schlagen><de> Als wir nicht kooperierten, schlugen sie uns.
<G-vec00992-002-s424><beat.schlagen><en> Once they arrived at the bureau, four officers severely beat her for several hours.
<G-vec00992-002-s424><beat.schlagen><de> Als sie dort ankamen, schlugen vier Beamte mehrere Stunden lang auf sie ein.
<G-vec00992-002-s425><beat.schlagen><en> The next night the devils came and began their gambols anew. They fell on the King’s son, and beat him much more severely than the night before, until his body was covered with wounds.
<G-vec00992-002-s425><beat.schlagen><de> In der folgenden Nacht kamen die Teufel wieder, fingen ihr Spiel an, fielen aber bald über den Königssohn her und schlugen ihn gewaltig, viel härter [171] als in der vorigen Nacht, daß sein Leib voll Wunden ward.
<G-vec00992-002-s426><beat.schlagen><en> If the tourist refused, we would beat him/her.
<G-vec00992-002-s426><beat.schlagen><de> Wenn sich der/die Tourist/in weigerte, schlugen wir ihn/sie.
<G-vec00992-002-s427><beat.schlagen><en> 3 And they did beat the gold into thin plates, and cut it into wires, to work it in the blue, and in the purple, and in the scarlet, and in the fine linen, the work of the skilful workman.
<G-vec00992-002-s427><beat.schlagen><de> 3 Und sie schlugen das GoldGold und schnitten's zu Faden, daß man's künstlich wirken konnte unter den blauen und roten PurpurPurpur, ScharlachScharlach und weiße LeinwandLeinwand.
<G-vec00992-002-s428><beat.schlagen><en> Guardsmen broke into the houses, destroyed fascists grenades, pricked bayonets, beat with butts, shot at point blank range.
<G-vec00992-002-s428><beat.schlagen><de> Die Gardisten drangen in die Häuser ein, zerstörten die Faschisten von den Granatäpfeln, spalteten von den Bajonetten, schlugen von den Kolben, erschossen ins Gesicht.
<G-vec00992-002-s429><beat.schlagen><en> 35 And the tenants took his servants and beat one, killed another, and stoned another.
<G-vec00992-002-s429><beat.schlagen><de> 35Aber die Weingärtner ergriffen seine Knechte und schlugen den einen, den andern töteten sie, den dritten steinigten sie.
<G-vec00992-002-s430><beat.schlagen><en> Inmates strictly monitor practitioners while they work, and often beat and swear at them.
<G-vec00992-002-s430><beat.schlagen><de> Insassen überwachten sie bei der Arbeit streng, schlugen und beschimpften sie oft.
<G-vec00992-002-s431><beat.schlagen><en> The police violently beat him using electric batons.
<G-vec00992-002-s431><beat.schlagen><de> Die Polizisten schlugen mit Elektroknüppeln brutal auf ihn ein.
<G-vec00992-002-s432><beat.schlagen><en> With silent approval from Lu Jun, the head of Division Four, the inmates from Cell Nine often beat him brutally, which led to his death.
<G-vec00992-002-s432><beat.schlagen><de> Mit dem stillen Einverständnis von Lu Jun, dem Leiter der vierten Abteilung, schlugen die Insassen von Zelle neun ihn oft brutal zusammen, was zu seinem Tod führte.
<G-vec00992-002-s433><beat.schlagen><en> Both of them grabbed me and beat me frenziedly.
<G-vec00992-002-s433><beat.schlagen><de> Beide packten mich und schlugen mich heftig.
<G-vec00992-002-s434><beat.schlagen><en> But Porto has other habits and customs: the old tradition was for revellers to beat each other on the head with a leek, but now they use plastic hammers; and besides the firework display at midnight on the River Douro in the centre of Porto, people also release colourful hot air balloons into the sky, making one of the most beautiful spectacles in these popular celebrations.
<G-vec00992-002-s434><beat.schlagen><de> Aber Porto hat noch weitere Sitten und Gebräuche: während die Feiernden früher mit Lauchstangen auf die Köpfe ihrer Begleiter schlugen, benutzen sie dafür heute Plastikhämmerchen; dazu werden in Porto neben dem fantastischen Feuerwerk, das um Mitternacht mitten im Fluss Douro gezündet wird, auch farbige Heißluftballons in einer der schönsten Feierlichkeiten dieser Volksfeste gestartet.
<G-vec00992-002-s435><beat.schlagen><en> The inmates beat and swore at Ms. Sun and tied her to a bed for more than 40 days.
<G-vec00992-002-s435><beat.schlagen><de> Die Insassen schlugen und fluchten auf Frau Sun und banden sie für mehr als 40 Tage an ein Bett.
<G-vec00992-002-s436><beat.schlagen><en> And there arose a great storm of wind, and the waves beat into the ship, so that it was now full.
<G-vec00992-002-s436><beat.schlagen><de> Und es erhob sich ein großer Sturm, und die Wellen schlugen in das Schiff, sodass es sich schon zu füllen begann.
<G-vec00992-002-s437><beat.schlagen><en> The police and drug addict inmates beat her all over, and poked needles into her legs and arms.
<G-vec00992-002-s437><beat.schlagen><de> Die Polizeibeamten und drogensüchtigen Häftlinge schlugen sie am ganzen Körper und stießen Nadeln in ihre Arme und Beine.
<G-vec00992-002-s438><beat.schlagen><en> Armed government troops fired warning shots into the air and beat, arrested and disrobed three monks.
<G-vec00992-002-s438><beat.schlagen><de> Bewaffnete Regierungstruppen feuerten Warnschüsse in die Luft, schlugen, verhafteten und entkleideten drei Mönche.
<G-vec00992-002-s439><beat.schlagen><en> Thank you for making the earth hold its orbit and my heart have its beat.
<G-vec00992-002-s439><beat.schlagen><de> Danke dir dafür, dass die Welt in ihrem Umlauf bleibt und mein Herz noch schlägt.
<G-vec00992-002-s440><beat.schlagen><en> Inhalants cause the heart to beat irregularly and more rapidly.
<G-vec00992-002-s440><beat.schlagen><de> Schnüffelstoffe verursachen, dass das Herz unregelmäßig und schneller schlägt.
<G-vec00992-002-s441><beat.schlagen><en> Alcohol disrupts the nervous system that guides the heart in regular beating, and can temporarily cause the heart to beat too rapidly or irregularly.
<G-vec00992-002-s441><beat.schlagen><de> Alkohol unterbricht das Nervensystem, das den gleichmäßigen Herzschlag reguliert und kann dazu beitragen, dass das Herz temporär zu schnell oder unregelmäßig schlägt.
<G-vec00992-002-s442><beat.schlagen><en> Our hearts beat in the same rhythm, the same melody.
<G-vec00992-002-s442><beat.schlagen><de> Unser Herz schlägt im gleichen Takt, die gleiche Melodie.
<G-vec00992-002-s443><beat.schlagen><en> Rest assured however, nothing can beat the feeling if you can finally harvest her finest-grade Sativa bud because you will only need a took or two to know that all the wait was totally worth it and then some!
<G-vec00992-002-s443><beat.schlagen><de> Doch ruhig Blut, nichts schlägt das Gefühl, wenn Du die Ernte endlich hinter Dir hast und den ersten Zug von ihren Erste-Sahne-Sativa-Blüten genießen wirst, denn dann weißt Du, dass sich das Warten mehr als gelohnt hat.
<G-vec00992-002-s444><beat.schlagen><en> Today once again our hearts skip a beat: we are proud to present you the fascinating variety of breathtaking inspirations and unbelievable creativity.
<G-vec00992-002-s444><beat.schlagen><de> Hochzeitsinspirationsvielfalt mit irischem Charme Heute schlägt unser Herz wieder Purzelbäume – wir dürfen eine faszinierende Vielfalt an Inspirationen und unglaubliche Kreativität bestaunen.
<G-vec00992-002-s445><beat.schlagen><en> The result: a 3-litre wine box beat a glass wine bottle in all aspects, generating on an average less than a fifth of the CO2 emissions (17.9 %) as the same volume of bottled wine.
<G-vec00992-002-s445><beat.schlagen><de> Das Ergebnis: die Drei Liter-Bag in Box schlägt die Glasflasche in allen Belangen und verursacht für die gleiche Menge Wein durchschnittlich weniger als ein Fünftel (17,9 %) an CO2-Emissionen.
<G-vec00992-002-s446><beat.schlagen><en> This is called a 10 Card Charlie and it will beat all hands other than Blackjack.
<G-vec00992-002-s446><beat.schlagen><de> Dies nennt man 10 Card Charlie und diese Hand schlägt alle anderen Hände mit Ausnahme von Blackjack.
<G-vec00992-002-s447><beat.schlagen><en> There is no better proof that emotions beat rationality.
<G-vec00992-002-s447><beat.schlagen><de> Einen besseren Beweis gibt es kaum: Emotion schlägt Rationalität.
<G-vec00992-002-s448><beat.schlagen><en> One of the main features reported by anxious people is feeling the heart beat fast, beating hard, like a throbbing.
<G-vec00992-002-s448><beat.schlagen><de> Eines der Hauptmerkmale, das von ängstlichen Menschen berichtet wird, ist das Gefühl, das Herz schlägt schnell und schlägt hart wie ein Pochen.
<G-vec00992-002-s449><beat.schlagen><en> She later learns that Percy beat her father, causing her and her cabin to dislike Percy.
<G-vec00992-002-s449><beat.schlagen><de> Ihre Zuneigung schlägt jedoch in Verachtung um, als sie erfährt, dass Percy ein Kind von Poseidon ist.
<G-vec00992-002-s450><beat.schlagen><en> Being in nature lets my heart beat faster.
<G-vec00992-002-s450><beat.schlagen><de> Dabei noch in der Natur zu sein – da schlägt mein Herz höher.
<G-vec00992-002-s451><beat.schlagen><en> In addition, one of the men (47) beat a woman (29), two adolescents are also beaten, one Turks denied the personal details, another wants to prevent his entrainment.
<G-vec00992-002-s451><beat.schlagen><de> Darüber hinaus schlägt einer der Männer (47) eine Frau (29), zwei Jugendliche werden ebenfalls geschlagen, ein Türke verweigert die Personalien, ein weiterer will dessen Mitnahme verhindern.
<G-vec00992-002-s452><beat.schlagen><en> Our hearts beat for documentary and fiction films with a unique artistic signature and an original narration, with the ability to entertain it’s spectators.
<G-vec00992-002-s452><beat.schlagen><de> Unser Herz schlägt für Dokumentarfilme und für Spielfilme mit künstlerischer Handschrift oder origineller Erzählweise sowie für das Dokumentarische mit Tendenz zur Fiktionalisierung.
<G-vec00992-002-s453><beat.schlagen><en> Your heart starts to beat faster.
<G-vec00992-002-s453><beat.schlagen><de> Ihr Herz schlägt schneller.
<G-vec00992-002-s454><beat.schlagen><en> The hearts of our guides beat for powder - they always enjoy untracked slopes and know the area like the back of their hand.
<G-vec00992-002-s454><beat.schlagen><de> Dafür schlägt auch das Herz unserer Guides - sie genießen selbst in jeder freien Minute unverspurte Hänge und kennen die Region wie ihre Westentasche.
<G-vec00992-002-s455><beat.schlagen><en> Barcelona beat Mallorca Lionel Messi hit a double as FC Barcelona made it ten wins from 11 Liga outings in a 4-2 success at RCD Mallorca, and second-placed Club Atlético de Madrid also triumphed.
<G-vec00992-002-s455><beat.schlagen><de> Barcelona schlägt Mallorca Lionel Messi hat beim 4:2-Sieg gegen RCD Mallorca doppelt zugeschlagen und eine alte Bestmarke von Pelé geknackt, für Spitzenreiter FC Barcelona war es der zehnte Sieg im elften Spiel.
<G-vec00992-002-s456><beat.schlagen><en> Since a man's heart beat faster.
<G-vec00992-002-s456><beat.schlagen><de> Da schlägt ein Männerherz höher.
<G-vec00992-002-s457><beat.schlagen><en> What does your heart beat for, what is the motivating force?
<G-vec00992-002-s457><beat.schlagen><de> Wofür das Herz schlägt, also wo ist die treibende Motivation.
<G-vec00992-002-s529><beat.verprügeln><en> He ordered guards to pull my hair, and beat and verbally abuse me, which left permanent scars on my body.
<G-vec00992-002-s529><beat.verprügeln><de> Sie befahl den Wachen, mich an den Haaren zu ziehen, zu verprügeln und mich zu beschimpfen.
<G-vec00992-002-s530><beat.verprügeln><en> The same is true for little Ronaldens, who told me: “Mimi, when you walked by my house the other day, I wanted to call your name but my mom didn’t let me”. Ever since, he comes by every day, gives me a hug, and says: “You know, I don’t like my new school at all, they beat me every day, and send me back home, because I did not take my books along or because daddy didn’t pay.
<G-vec00992-002-s530><beat.verprügeln><de> Das Gleiche gilt für den kleinen Ronaldens, der mir erzählte: „Mimi, als du neulich an meinem Haus vorbeigegangen bist, wollte ich dich rufen, aber Mama hat es mir verboten.“ Seitdem kommt er jeden Tag zu mir, umarmt mich und sagt: „Weißt du, ich mag meine neue Schule überhaupt nicht, sie verprügeln mich, sie schicken mich zurück, weil ich keine Bücher habe oder weil Papa nicht bezahlt hat.
<G-vec00992-002-s531><beat.verprügeln><en> And lo and behold: there’s no one left for us to scorn and beat and kill, because Jesus already suffered all of that.
<G-vec00992-002-s531><beat.verprügeln><de> Und siehe: da ist niemand mehr, den wir verschmähen und verprügeln und ermorden können, weil Jesus es alles schon gelitten hat.
<G-vec00992-002-s532><beat.verprügeln><en> It’s better to beat up lawyers.
<G-vec00992-002-s532><beat.verprügeln><de> Es ist einfacher die Anwälte zu verprügeln.
<G-vec00992-002-s533><beat.verprügeln><en> At first he thinks they are going to beat him up, but they tell him that he is amazing and want him in Glee club.
<G-vec00992-002-s533><beat.verprügeln><de> Erst denkt Roderick, dass sie gekommen sind, um ihn zu verprügeln, doch sie sagen ihm, dass er etwas Besonderes ist und sie ihm im Glee Club wollen.
<G-vec00992-002-s534><beat.verprügeln><en> As two throwing knives whizzed by, scraping the side of my head, I was started to feel the urge to beat someone up.
<G-vec00992-002-s534><beat.verprügeln><de> Während zwei geworfene Messer vorbei zischten und an meinem Kopf kratzten, begann ich den Drang zu fühlen jemanden zu verprügeln.
<G-vec00992-002-s535><beat.verprügeln><en> When the paramilitary commander found out, he ordered his men to beat her; she lost the baby.
<G-vec00992-002-s535><beat.verprügeln><de> Als der paramilitärische Kommandant von der Schwangerschaft erfuhr, befahl er seinen Männern Carolina zu verprügeln; sie verlor das Baby.
<G-vec00992-002-s536><beat.verprügeln><en> Example: Right-wing extremist hooligans beat up a dark-skinned man because they think he is a foreigner.
<G-vec00992-002-s536><beat.verprügeln><de> Beispiel: Rechtsextremistische Schläger verprügeln einen dunkelhäutig aussehenden Mann, weil sie ihn für einen Ausländer halten.
<G-vec00992-002-s537><beat.verprügeln><en> A tribal leader in one of India’s tiger reserves is fearing for his safety after a wildlife official urged his community to beat him and drive him out for defending their right to remain on their land.
<G-vec00992-002-s537><beat.verprügeln><de> Ein indigener Anführer in einem von Indiens Tigerreservaten fürchtet um seine Sicherheit, nachdem ein Wildhüter seine Gemeinde drängte, ihn zu verprügeln und fortzujagen, weil er ihr Recht verteidigt hatte, auf ihrem Land zu bleiben.
<G-vec00992-002-s538><beat.verprügeln><en> Ma Aiping incited drug offenders to beat me and verbally abuse me.
<G-vec00992-002-s538><beat.verprügeln><de> Ma Aiping stachelte Drogenabhängige an, mich zu verprügeln und verbal zu misshandeln.
<G-vec00992-002-s539><beat.verprügeln><en> Guards in the detention centre ordered inmates to beat them daily.
<G-vec00992-002-s539><beat.verprügeln><de> Gefängniswärter wiesen Insassen an, sie täglich zu verprügeln.
<G-vec00992-002-s540><beat.verprügeln><en> Because we could not afford to pay the authorities the money they intended to extort from us, they came to our residence to threaten and beat me.
<G-vec00992-002-s540><beat.verprügeln><de> Weil wir den Behörden das Geld nicht bezahlen konnten, das sie von uns zu erpressen beabsichtigten, kamen sie in unsere Wohnung, um mich zu bedrohen und zu verprügeln.
<G-vec00992-002-s541><beat.verprügeln><en> Guard Dong Jian said, "How could we call this place a strictly controlled cell if we don't beat people?" After a long time, the inmates were exhausted and stopped.
<G-vec00992-002-s541><beat.verprügeln><de> Wächter Dong Jian sagte: „Wie könnten wir diesen Platz eine strikt kontrollierte Zelle nennen, wenn wir Menschen nicht verprügeln?“ Nach einer langen Zeit waren die Insassen erschöpft und hörten auf.
<G-vec00992-002-s542><beat.verprügeln><en> You do not want to mentally beat up the bully any more than you would physically.
<G-vec00992-002-s542><beat.verprügeln><de> Mögest du den brutalen Menschen mental nicht mehr verprügeln, als du das körperlich tust.
<G-vec00992-002-s543><beat.verprügeln><en> Ms. Li was not able to work, but Liu Chunzhi said she was pretending, and she led others to beat her again.
<G-vec00992-002-s543><beat.verprügeln><de> Als Li nicht arbeiten konnte, behauptete Liu Chunzhi, sie würde simulieren und forderte die anderen auf, Li zu verprügeln.
<G-vec00992-002-s544><beat.verprügeln><en> Soon will come the big day, the competition, though he actually doesn’t exactly know why he runs. Maybe because he always had to run away so that the others wouldn’t beat him up.
<G-vec00992-002-s544><beat.verprügeln><de> Bald ist der große Tag des Wettkampfes, aber so genau weiß er nicht mehr, warum er eigentlich läuft, vielleicht, weil er immer weglaufen musste, damit ihn die anderen nicht verprügeln.
<G-vec00992-002-s545><beat.verprügeln><en> Female guard Feng Bing ordered inmates Li Xia, Qi Hong and Li Ling to beat me.
<G-vec00992-002-s545><beat.verprügeln><de> Die Wärterin Feng Bing wies die Insassinnen Li Xia, Qi Hong und Li Ling an, mich zu verprügeln.
<G-vec00992-002-s546><beat.verprügeln><en> One way forward - I am a big fan of Raymond Chandler and his fictional character Philip Marlowe and even have a homepage with Philip Marlowe and Mike Hammer: so I'm biased, of course, for this film, but because of James anyway:) I think this film great class, and James is a really good Marlowe (with Humphrey Bogart still my number 1 remains in terms of Marlowe) An almost amusing side story was the scene, was allowed to beat up where James Bruce Lee .
<G-vec00992-002-s546><beat.verprügeln><de> Eines vorne weg - ich bin ein großer Fan von Raymond Chandler und seiner Romanfigur Philip Marlowe und habe sogar eine eigene Homepage zu Philip Marlowe und Mike Hammer: und deswegen bin ich natürlich noch voreingenommener für diesen Film, als wegen James sowieso schon:) Ich finde diesen Film große Klasse und James ist ein wirklich guter Marlowe (wobei Humphrey Bogart trotzdem meine Nummer 1 bleibt in Sachen Marlowe) Ein fast amüsante Nebenstory war die Szene, wo James Bruce Lee verprügeln durfte.
