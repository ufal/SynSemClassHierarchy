<G-vec00782-002-s019><adorn.akzentuieren><en> Charming furnishings and flawless details adorn the splendid bedroom and the separate living room.
<G-vec00782-002-s019><adorn.akzentuieren><de> Das großartige Schlafzimmer und der separate Wohnbereich werden durch stilvolles Mobiliar und makellose Details akzentuiert.
<G-vec00782-002-s029><adorn.anbringen><en> Solar cells adorn the face of the site’s largest canteen.
<G-vec00782-002-s029><adorn.anbringen><de> Auf der Fassade der größten Kantine im Werk sind Solarzellen angebracht.
<G-vec00782-002-s041><adorn.anbringen><en> Precious mosaics adorn at the outer walls here.
<G-vec00782-002-s041><adorn.anbringen><de> Bereits an den Außenwänden sind kostbare Mosaike angebracht.
<G-vec00782-002-s035><adorn.ausschmücken><en> There are also other special symbols that adorn the entire aspects of the game.
<G-vec00782-002-s035><adorn.ausschmücken><de> Es gibt auch andere spezielle Symbole, welche die gesamten Aspekte des Spiels ausschmücken.
<G-vec00782-002-s036><adorn.ausschmücken><en> It is worth registering your visit in advance, as the unexceptional facade of this Romanesque castle chapel gives no hint of the magnificent Gothic frescoes that adorn the entire interior.
<G-vec00782-002-s036><adorn.ausschmücken><de> Ein Besuch mit Voranmeldung lohnt sich, denn nichts lässt an der äußerlich unscheinbaren romanischen Burgkapelle auf die prunkvollen gotischen Fresken schließen, welche den gesamten Innenraum ausschmücken.
<G-vec00782-002-s039><adorn.bereichern><en> Churches of big importance adorn this city: the church of Santa Maria della Spina for example is considered one of the most beautiful Gothic churches in Italy.
<G-vec00782-002-s039><adorn.bereichern><de> Wichtige Kirchen bereichern die Stadt: Die Kirche von Santa Maria della Spina wird zum Beispiel als eine der schönsten gotischen Kirchen Italiens gehalten.
<G-vec00782-002-s044><adorn.betonen><en> Vertical black braids adorn your curves.
<G-vec00782-002-s044><adorn.betonen><de> Vertikale schwarze Borten betonen die weiblichen Kurven.
<G-vec00782-002-s047><adorn.dekorieren><en> Then adorn your wall with a letter that has a unique place in your heart—find the right typography poster for you.
<G-vec00782-002-s047><adorn.dekorieren><de> Dekoriere dein Zuhause mit einem Buchstaben, der einen ganz besonderen Platz in deinem Herzen hat – finde das perfekte Typografie-Poster.
<G-vec00782-002-s048><adorn.dekorieren><en> At the end adorn the fridge, and a day just by pulling the majority of vegetables and fruits.
<G-vec00782-002-s048><adorn.dekorieren><de> Am Ende dekorieren sie den Kühlschrank, und eines Tages ziehen sie die meisten Gemüse und Früchte an.
<G-vec00782-002-s049><adorn.dekorieren><en> Philadelphia, USA: More than 2500 exquisitely colourful mural paintings adorn facades of houses and fire protecting walls with motifs as diverse as the city and its inhabitants.
<G-vec00782-002-s049><adorn.dekorieren><de> Philadelphia, USA: Mehr als 2500 farbenprächtige Wandgemälde dekorieren Hausfassaden und Brandmauern mit Motiven, so vielfältig wie die Stadt und ihre Bewohner.
<G-vec00782-002-s147><adorn.dekorieren><en> Long Shirt "Hippie Chic": comfortable, freedom movements, metal beads that adorn the front part of the garment, belt with feathers
<G-vec00782-002-s147><adorn.dekorieren><de> Das Kleid/Tunika "Hippie Chic": bequem, Freiheitsbewegungen, Metallperlen, die den vorderne Teil des Kleidungsstücks dekorieren, Gürtel mit Federn.
<G-vec00782-002-s054><adorn.einsetzen><en> Onyx stones, and precious stones to adorn the ephod and the rational.
<G-vec00782-002-s054><adorn.einsetzen><de> Onyxsteine und Steine zum Einsetzen für das Ephod und für das Brustschild.
<G-vec00782-002-s058><adorn.garnieren><en> Pour soda on top and adorn with blackberries and mint leaves.
<G-vec00782-002-s058><adorn.garnieren><de> Mit Sodawasser aufgießen und mit Brombeeren und Minzblätter garnieren.
<G-vec00782-002-s059><adorn.garnieren><en> Adorn with sultanas, powdered cinnamon and a few leaves of mint.
<G-vec00782-002-s059><adorn.garnieren><de> Garnieren Sie ihn mit Rosinen, Zimtpulver und ein paar Blättern Minze.
<G-vec00782-002-s062><adorn.gestalten><en> Adorn garden, terrace and balcony according to your wishes - with seven colours to choose from no problem.
<G-vec00782-002-s062><adorn.gestalten><de> Gestalten Sie Garten, Terrasse und Balkon ganz nach Ihren Vorstellungen – bei sieben zur Wahl stehenden Farben kein Problem.
<G-vec00782-002-s030><adorn.schmücken><en> The elegant little porcelain plates with the traditional inscriptions "H" for hot and "C" for cold, which adorn the mixer handles, are typically nostalgic.
<G-vec00782-002-s030><adorn.schmücken><de> Charakteristisch nostalgisch sind auch die edlen Porzellanplättchen mit der traditionellen Beschriftung "H" für heiß und "C" für kalt, die die Armaturengriffe schmücken.
<G-vec00782-002-s045><adorn.schmücken><en> His now iconic works were to adorn large billboards, whole building walls and city lights in all their glory and question whether Schiele's art, one hundred years after his death, is still perceived by society as being too daring to span the arc to the here and now.
<G-vec00782-002-s045><adorn.schmücken><de> Seine weltberühmten Werke sollten in voller Pracht große Plakatstellen, ganze Hauswände und Citylights schmücken und mit der Frage, ob Schieles Kunst hundert Jahre nach dessen Tod von der Gesellschaft als immer nochzu gewagt empfunden wird, den Bogen ins Hier und Heute spannen.
<G-vec00782-002-s056><adorn.schmücken><en> Sled dogs and houses in almost all colours adorn the rocky landscape.
<G-vec00782-002-s056><adorn.schmücken><de> Schlittenhunde und Häuser in fast allen erdenklichen Farben schmücken die felsige Landschaft.
<G-vec00782-002-s061><adorn.schmücken><en> The terrace offers sun all morning and is adorn by lemon trees and is equipped with an outdoors shower.
<G-vec00782-002-s061><adorn.schmücken><de> Die Terrasse bietet den ganzen Morgen Sonne und ist von Zitronenbäumen geschmückt und mit einer Dusche im Freien ausgestattet.
<G-vec00782-002-s068><adorn.schmücken><en> From those times, still today are visible numerous luxurious rustic villas, Venetian houses and streets that adorn the old heart of the town of Umag, reminding us of turbulent and past times and hiding the traces of Gothic and Renaissance architecture.
<G-vec00782-002-s068><adorn.schmücken><de> Aus dieser Zeit stammen zahlreiche noch immer erhaltene luxuriöse rustikale Villen, venezianische Häuser und kiesbedeckte Straßen, die die Altstadt von Umag schmücken und an die turbulenten und vergangenen Zeiten mit Spuren der Architektur der Gotik und Renaissance erinnern.
<G-vec00782-002-s071><adorn.schmücken><en> Fine Details Many fine joints and details adorn this table, which doesn`t feature a single straight line.
<G-vec00782-002-s071><adorn.schmücken><de> Kleine Details Viele kleine Details und Kupplungen schmücken diesen Tisch, so dass es keine gerade Linie entsteht.
<G-vec00782-002-s079><adorn.schmücken><en> As you may have noticed, I adorn myself with a new accessory.
<G-vec00782-002-s079><adorn.schmücken><de> Wie ihr vielleicht bemerkt habt, schmück ich mich mit einem neuen Accessoire.
<G-vec00782-002-s080><adorn.schmücken><en> Tip: Adorn with simple fresh greenery for a dash of boho glam. get inspired
<G-vec00782-002-s080><adorn.schmücken><de> Tipp: Schmücke die Frisur mit frischen Blüten oder Rankengewächs für einen Hauch von Boho-Glam.
<G-vec00782-002-s081><adorn.schmücken><en> Adorn your temples with the adornment of trust- worthiness and piety. Help, then, your Lord with the hosts of goodly deeds and a praiseworthy character....
<G-vec00782-002-s081><adorn.schmücken><de> Schmücke deinen Tempel (Körper) mit dem Mantel der Vertrauenswürdigkeit und der Redlichkeit, alsdann hilf deinem Herrn mit den Heerscharen guter Taten und guter Sitten.
<G-vec00782-002-s082><adorn.schmücken><en> I adorn myself with restlessness and increasingly need a companion who makes me addicted.
<G-vec00782-002-s082><adorn.schmücken><de> Ich schmücke mich mit Unruhe und brauche zunehmend einen Begleiter der mich abhängig macht.
<G-vec00782-002-s083><adorn.schmücken><en> I’ll oil my latex from ‘Savage Wear‘ or adorn myself with the feathers from ‘Benno von Stein‘ or….the decision will be hard.
<G-vec00782-002-s083><adorn.schmücken><de> Ich werde mein Latex von ‘Savage Wear‘ ölen oder schmücke mich doch mit den Federn von ‘Benno von Stein‘ oder….die Entscheidung wird schwer werden.
<G-vec00782-002-s084><adorn.schmücken><en> Try on fitted pieces in flattering colors, and adorn yourself with plenty of fun, funky accessories.
<G-vec00782-002-s084><adorn.schmücken><de> Wähle stattdessen körperbetonte Stücke in schmeichelhaften Farben und schmücke dich mit vielen aufregenden und flippigen Accessoires.
<G-vec00782-002-s085><adorn.schmücken><en> Simple and clean shapes will adorn your home and garden, and at the same time can make your job of caring for the plants.
<G-vec00782-002-s085><adorn.schmücken><de> Einfache und saubere Formen schmücken Ihr Heim und Garten, und zur gleichen Zeit vereinfachen sie Ihre Arbeit bei der Pflanzenpflege.
<G-vec00782-002-s086><adorn.schmücken><en> Seven golf courses adorn South Tyrol - and two of them are very close to our 4-star superior, romantic Hotel Oberwirt: Lana Golf Club and the golf club in Passeier Valley.
<G-vec00782-002-s086><adorn.schmücken><de> 7 Golfplätze schmücken Südtirol – 2 davon sind ganz in der Nähe unseres 4-Sterne-Superior Romantik Hotel Oberwirt: der Golfcourt Lana und der Golfclub im Passeiertal.
<G-vec00782-002-s087><adorn.schmücken><en> This beauty will adorn your wrist at approximately 7 1/2” / 19cm.
<G-vec00782-002-s087><adorn.schmücken><de> Diese Schönheit wird Ihr Handgelenk bei etwa 7 1/2 "/ 19 cm schmücken.
<G-vec00782-002-s088><adorn.schmücken><en> Many embroideries by himself adorn the walls of the restaurant / tea room with English decor.
<G-vec00782-002-s088><adorn.schmücken><de> Viele Stickereien schmücken die Wände des Restaurants / Teestube mit englischem Dekor.
<G-vec00782-002-s089><adorn.schmücken><en> We put on the dress on the doll, we adorn it with buttons, ribbons.
<G-vec00782-002-s089><adorn.schmücken><de> Wir ziehen das Kleid auf die Puppe, wir schmücken es mit Knöpfen, Bändern.
<G-vec00782-002-s090><adorn.schmücken><en> Magic is in the details at Astarte, beginning with the twinkling Swarovski stones that adorn the ceiling above each suite’s Jacuzzi-pool, and ending with the personalized service each guest enjoys.
<G-vec00782-002-s090><adorn.schmücken><de> Magie ist ausführlich bei Astarte und fängt mit den Twinkling Swarovski Steinen an, die die Decke über Jacuzzi-Lache jeder Suite schmücken, und Ende mit dem personifizierten Service, den jeder Gast genießt.
<G-vec00782-002-s091><adorn.schmücken><en> Clothing is used as a “second skin” that may shield, reveal or adorn.
<G-vec00782-002-s091><adorn.schmücken><de> Als „zweite Haut“ funktioniert Bekleidung, die abschirmen, verbergen und schmücken kann.
<G-vec00782-002-s092><adorn.schmücken><en> 9 In like manner also, that women adorn themselves in modest apparel, with shamefacedness and sobriety; not with broided hair, nor gold, or pearls, or costly array;
<G-vec00782-002-s092><adorn.schmücken><de> 9 Ebenso schmücken sich die Frauen in bescheidener Kleidung mit Scham und Nüchternheit; Weder mit Haarflechten, noch mit Gold, Perlen oder teuren Gegenständen.
<G-vec00782-002-s093><adorn.schmücken><en> Also a variety of cultural events, which must be one of our sophisticated and educated Escort Dusseldorf exploring ladies adorn this beautiful city.
<G-vec00782-002-s093><adorn.schmücken><de> Auch eine Vielzahl an kulturellen Events, die es mit einer unserer niveauvollen und gebildeten Escort Düsseldorf Damen zu erkunden gilt, schmücken diese schöne Stadt.
<G-vec00782-002-s094><adorn.schmücken><en> Here, the individual small dandelion blossoms are flying around tentatively and adorn this beautiful napkin from the Naturals series by Paper+Design in a very elegant way.
<G-vec00782-002-s094><adorn.schmücken><de> Hier fliegen die einzelnen kleinen Löwenzahnblüten zaghaft umher und schmücken sehr elegant diese wunderschöne Serviette aus der Naturals Serie von Paper+Design.
<G-vec00782-002-s095><adorn.schmücken><en> Round Catalina Ash badges adorn each shell.
<G-vec00782-002-s095><adorn.schmücken><de> Runde Catalina Ash Abzeichen schmücken jede Schale.
<G-vec00782-002-s096><adorn.schmücken><en> Two crossed swords behind a shield with lilies and lions as coats of arms and characteristic red crosses as symbols of the Order of Knights adorn your LARP decoration.
<G-vec00782-002-s096><adorn.schmücken><de> Zwei gekreuzte Schwerter hinter einem Schild mit Lilien und Löwen als Wappen sowie charakteristische rote Kreuze als Symbol des Ritterordens schmücken deine LARP-Deko.
<G-vec00782-002-s097><adorn.schmücken><en> If you wish to adorn your wrist with the model Racing IV, join the bidding and win this precious creation.
<G-vec00782-002-s097><adorn.schmücken><de> Wenn Sie Ihr Handgelenk zukünftig mit der Racing IV schmücken möchten, dann bieten Sie jetzt mit.
<G-vec00782-002-s098><adorn.schmücken><en> In a transfigured vision of God's temple, we can interpret the different elements as the symbol and image of the variety of gifts and charisms with which the divine Craftsman has wished to adorn the Church, his mystical Bride. 3.
<G-vec00782-002-s098><adorn.schmücken><de> In einer Abwandlung der Vision vom Tempel Gottes kann man die verschiedenen Elemente als Symbol und Bild der vielfältigen Gaben und Charismen deuten, mit denen der göttliche Künstler die Kirche, seine mystische Braut, hat schmücken wollen.
<G-vec00782-002-s099><adorn.schmücken><en> From the hills and lookouts, point your camera at the pastel colours that adorn the crumbling walls of captivating Lisbon.
<G-vec00782-002-s099><adorn.schmücken><de> Von den Hügeln und Ausflügen, zeigen Sie Ihre Kamera auf die Pastellfarben, die die zerbröckelnden Wände der faszinierenden Lissabon schmücken.
<G-vec00782-002-s100><adorn.schmücken><en> The Latin word velare means ‘to cloak’, but also ‘to clothe’ and ‘to decorate’ – just like Velia, a shade that can be used to either conceal or adorn.
<G-vec00782-002-s100><adorn.schmücken><de> Das lateinische Wort „velare“ bedeutet „verhüllen“ aber auch „bekleiden“ und „schmücken“ – genau wie der Farbton Velia, der ebenso zu verhüllen als auch zu Schmücken imstande ist.
<G-vec00782-002-s101><adorn.schmücken><en> The flowers envelope, dress and adorn the body.
<G-vec00782-002-s101><adorn.schmücken><de> Die Blumen umhüllen, kleiden und schmücken den Körper.
<G-vec00782-002-s102><adorn.schmücken><en> Cabochons can be used to produce or adorn almost any piece of jewelry.
<G-vec00782-002-s102><adorn.schmücken><de> Cabochons können verwendet werden, zu produzieren oder schmücken fast jedes Schmuckstück.
<G-vec00782-002-s103><adorn.schmücken><en> More than 20 colourful murals adorn buildings in the town centre, showcasing the history of Inyo County.
<G-vec00782-002-s103><adorn.schmücken><de> Mehr als zwanzig farbenprächtige Wandgemälde schmücken Gebäude in der Innenstadt und illustrieren die Geschichte von Inyo County.
<G-vec00782-002-s104><adorn.schmücken><en> They don’t need to because they stand for themselves and do not have to adorn themselves with names of others.
<G-vec00782-002-s104><adorn.schmücken><de> Sie brauchen es auch nicht, weil sie für sich stehen und sich nicht mit Namen schmücken müssen, die ihnen nicht entsprechen.
<G-vec00782-002-s105><adorn.schmücken><en> At Jordan, clearly defined, individual blooms and stylised floral elements adorn the high-quality background materials.
<G-vec00782-002-s105><adorn.schmücken><de> Bei Jordan schmücken konkret definierte Einzelblüten und stilisierte florale Elemente die hochwertigen Grundqualitäten.
<G-vec00782-002-s106><adorn.schmücken><en> Feast your eyes upon the much debated Mona Lisa and admire the Renaissance masterpieces that adorn its walls, with free entry with the Paris Pass.
<G-vec00782-002-s106><adorn.schmücken><de> Ergötzen Sie Ihre Augen an der viel diskutierten Mona Lisa, bewundern Sie die Meisterwerke aus der Renaissance, die die Wände schmücken – und mit dem Paris-Pass ist der Eintritt sogar frei.
<G-vec00782-002-s107><adorn.schmücken><en> Numerous places of interest adorn this road tour.
<G-vec00782-002-s107><adorn.schmücken><de> Zahlreiche Sehenswürdigkeiten schmücken diese Straßentour.
<G-vec00782-002-s108><adorn.schmücken><en> Adorn your locks with fragrant wreaths And follow joyful happy urges, Greet Spring with cheerful dances, The victor, who conquered all in love.
<G-vec00782-002-s108><adorn.schmücken><de> Schmücket die Locken mit duftigen Kränzen Und folget der Freude beglückendem Drang, Begrüßet den Frühling mit heiteren Tänzen, Den Sieger, der Alles in Liebe bezwang.
<G-vec00782-002-s109><adorn.schmücken><en> I love the different colours that adorn it, the beautiful clothes that dress it, the brilliant works emanating from it, its similar passionate loves.
<G-vec00782-002-s109><adorn.schmücken><de> Ich liebe die unterschiedlichen Farben, mit denen sie sich schmückt, die schönen Kleider, die sie trägt, die prächtigen Werke, die aus ihr hervorgehen, die gleichartigen Lieben, mit denen sie sich begeistert.
<G-vec00782-002-s110><adorn.schmücken><en> In the staircase, a skeleton latex torso looks particularly good, while a skeleton garland may adorn the rest of the apartment.
<G-vec00782-002-s110><adorn.schmücken><de> Im Treppenaufgang macht sich ein Skelett Torso aus Latex besonders gut, während eine Skelet Girlande vielleicht den Rest der Wohnung schmückt.
<G-vec00782-002-s111><adorn.schmücken><en> Having hunger, you will become irritable, in this condition a new swimsuit is unlikely to adorn you.
<G-vec00782-002-s111><adorn.schmücken><de> Wenn Sie Hunger haben, werden Sie reizbar, in diesem Zustand ist es unwahrscheinlich, dass ein neuer Badeanzug Sie schmückt.
<G-vec00782-002-s112><adorn.schmücken><en> He tries to find stories in precious metals and adorn them with gemstones.
<G-vec00782-002-s112><adorn.schmücken><de> Er versucht, Geschichten in Edelmetallen zu finden und schmückt sie mit Edelsteinen.
<G-vec00782-002-s113><adorn.schmücken><en> Nature’s canvas; golden, crimson, bronze strokes adorn this season.
<G-vec00782-002-s113><adorn.schmücken><de> Die Leinwand der Natur: Diese Jahreszeit schmückt sich in goldenen, purpurroten und bronzefarbenen Pinselstrichen.
<G-vec00782-002-s114><adorn.schmücken><en> Such rings adorn the forefinger of the right hand of the bride.
<G-vec00782-002-s114><adorn.schmücken><de> Solch ein Ring schmückt den Zeigefinger der rechten Hand der Braut.
<G-vec00782-002-s115><adorn.schmücken><en> 5 For in this way in former times the holy women also, who hoped in God, used to adorn themselves, and were submissive to their own husbands; 6 just as Sarah obeyed Abraham, calling him lord.
<G-vec00782-002-s115><adorn.schmücken><de> 5 Denn so schmückten sich auch einst die heiligen Frauen, die ihre Hoffnung auf Gott setzten und sich ihren Männern unterordneten: 6 wie Sara dem Abraham gehorchte und ihn Herr nannte, deren Kinder ihr geworden seid, indem ihr Gutes tut und keinerlei Schrecken fürchtet.
<G-vec00782-002-s116><adorn.schmücken><en> It has been the center of the daily life and monuments from around the world adorn this place.
<G-vec00782-002-s116><adorn.schmücken><de> Es ist das Zentrum der Unterhaltung gewesen und Denkmäler aus aller Welt schmückten diese Anlage.
<G-vec00782-002-s119><adorn.säumen><en> The historic old town of Marbella is famous for its typical Andalusian whitewashed houses and orange trees that adorn the streets and squares.
<G-vec00782-002-s119><adorn.säumen><de> Die Altstadt Marbellas besticht durch die für Andalusien typischen weißen Häuser und Orangenbäume, die die Straßen und Plätze säumen.
<G-vec00782-002-s078><adorn.verleihen><en> Fountains, temples and statues were built to adorn the gardens with a touch of Renaissance style.
<G-vec00782-002-s078><adorn.verleihen><de> Brunnen, kleine Tempel und Skulpturen, die dem Garten einen Hauch des Renaissancestils verliehen, wurden errichtet.
<G-vec00782-002-s077><adorn.verschönen><en> Elaborate flower designs are worked into the glass walls and glass doors; the marble columns are decorated with realistic flower mosaics, and flowers in relief adorn the interior walls – very unusual for a mosque. And something else is striking: the rooms are as bright as daylight.
<G-vec00782-002-s077><adorn.verschönen><de> In Glaswände und -türen sind künstlerische Blumen-Motive eingearbeitet, die Marmorsäulen zieren realistische Blumenmosaiken, Reliefblumen verschönen Innenwände – sehr ungewöhnlich für eine Moschee, in der noch etwas auffällt: die Räume sind taghell.
<G-vec00782-002-s117><adorn.verschönern><en> But there are also great swathes of indigenous plants, such as the santo pine or the strawberry tree, as well as beautiful palm tree groves which adorn the residential areas.
<G-vec00782-002-s117><adorn.verschönern><de> Aber es gibt auch große Gebiete mit heimischen Pflanzen - etwa Pino santo oder El Madroñal - sowie schöne Palmenhaine, die die Siedlungsbereiche verschönern.
<G-vec00782-002-s121><adorn.verschönern><en> From now on players can adorn their farms with unusual decorations.
<G-vec00782-002-s121><adorn.verschönern><de> Ab sofort können die Spieler ihre Bauernhöfe mit ausgefallenen Dekorationen verschönern.
<G-vec00782-002-s122><adorn.verschönern><en> High knot density allowed skillful artisans to create all breathtaking, nature-related patterns which undoubtedly have a chance to adorn contemporary interior arrangements due to their timeless elegance and versatile appeal.
<G-vec00782-002-s122><adorn.verschönern><de> Dank der hohen Knotendichte konnten geschickte Handwerker alle atemberaubenden, naturbezogenen Muster herstellen, die aufgrund ihrer zeitlosen Eleganz und Vielseitigkeit zweifellos die Möglichkeit haben, moderne Inneneinrichtungen zu verschönern.
<G-vec00782-002-s123><adorn.verschönern><en> Alabaster is a high-quality materials and objects in alabaster adorn any room.
<G-vec00782-002-s123><adorn.verschönern><de> Der Alabaster ist ein wertvolles Material und die Gegenstände aus Alabaster verschönern jede Umgebung.
<G-vec00782-002-s124><adorn.verschönern><en> Long strips of stone adorn the facade both horizontally and vertically.
<G-vec00782-002-s124><adorn.verschönern><de> Lange Streifen aus Stein sowohl waagrecht als auch senkrecht verschönern die Fassade.
<G-vec00782-002-s125><adorn.verschönern><en> The historical town centre includes Villa Pertini, Piazza del Popolo and Piazza Ortona, where visitors can admire the Cathedral of 1852 dedicated to Saint John the Baptist and the monument dedicated to the fallen of the war that adorn the town.
<G-vec00782-002-s125><adorn.verschönern><de> Im historischen Zentrum befinden sich die Villa Pertini, die Piazza del Popolo und die Piazza Ortona, wo man die 1852 dem Heiligen Johannes dem Täufer geweihte Kathedrale und das den Kriegsopfern gewidmete Denkmal bewundern kann, die die Stadt verschönern.
<G-vec00782-002-s126><adorn.verschönern><en> I feel grateful when I can permit our poets to adorn my leisure for a brief space.
<G-vec00782-002-s126><adorn.verschönern><de> Dankbar fühl' ich mich schon, wenn ich unseren Dichtern gestatten kann, mir die Ruhe auf kurze Zeit zu verschönern.
<G-vec00782-002-s127><adorn.verschönern><en> This embroidery is also well suited to adorn another fabric of your choice from our range.
<G-vec00782-002-s127><adorn.verschönern><de> Diese Stickerei ist auch gut geeignet, um ein anderes Textil Ihrer Wahl aus unserem Sortiment zu verschönern.
<G-vec00782-002-s128><adorn.versehen><en> In order to nevertheless create a visual identity, two large format images adorn the new building’s facades.
<G-vec00782-002-s128><adorn.versehen><de> Um trotzdem ein markantes Erscheinungsbild zu erzeugen, werden die Fassaden des Neubaus mit zwei großflächigen Abbildungen versehen.
<G-vec00782-002-s129><adorn.versehen><en> Beautiful wooden floors and beamed wooden ceilings adorn the whole apartment.
<G-vec00782-002-s129><adorn.versehen><de> Das ganze Apartment ist mit Holzlaminat und Holzdecken versehen.
<G-vec00782-002-s130><adorn.versehen><en> Tender buttons adorn the slit opening at the back, adding sophistication to the top.
<G-vec00782-002-s130><adorn.versehen><de> Eine mit zartem Knöpfchen versehene Schlitzöffnung im Rücken verleiht dem Top Raffinesse.
<G-vec00782-002-s065><adorn.verzieren><en> A beautiful cut warm brown bar of wood adorn this necklace.
<G-vec00782-002-s065><adorn.verzieren><de> Diese Halskette wird von einem schön zugeschnittenen Holzstab in warmem Braun verziert.
<G-vec00782-002-s132><adorn.verzieren><en> Use Trollbeads hair jewellery with your favourite beads and adorn your hairstyles with a stunning Find your inspiration here
<G-vec00782-002-s132><adorn.verzieren><de> Verwende Trollbeads Haarschmuck mit deinen Lieblingsbeads und verziere deine Frisuren mit einem atemberaubenden Alltagslook oder für festliche Anlässe.
<G-vec00782-002-s133><adorn.verzieren><en> Adorn loose locks with this textured braid for a free-spirited look.
<G-vec00782-002-s133><adorn.verzieren><de> Verziere Deine lockere Mähne mit diesem strukturierten Flechtelement für einen ungezwungenen Look.
<G-vec00782-002-s134><adorn.verzieren><en> Small prints adorn the sleeves.
<G-vec00782-002-s134><adorn.verzieren><de> Kleine Prints verzieren die Ärmel.
<G-vec00782-002-s135><adorn.verzieren><en> Choose a white or yellow gold necklace chain and adorn it with your choice of black, white or rose cultured pearls.
<G-vec00782-002-s135><adorn.verzieren><de> Wählen Sie eine Weiß- oder Gelbgold-Kette für Ihren Anhänger und verzieren Sie es mit Zuchtperlen Ihrer Wahl von Schwarz, Weiß bis hin zu Rose.
<G-vec00782-002-s136><adorn.verzieren><en> Textured swirls adorn the shaft of this glorious glass dildo, giving you incredible intimate massages.
<G-vec00782-002-s136><adorn.verzieren><de> Strukturierte Wirbel verzieren den Schaft dieses umwerfenden Glasdildos für unvergleichliche intime Massagen.
<G-vec00782-002-s137><adorn.verzieren><en> It was this piece which inspired Jaeger‑LeCoultre’s master enameller to adorn the reverse of this Reverso Tribute Enamel.
<G-vec00782-002-s137><adorn.verzieren><de> Von ihr ließ sich der Meister-Emailleur von Jaeger‑LeCoultre inspirieren, um die Rückseite der Reverso Tribute Enamel zu verzieren.
<G-vec00782-002-s138><adorn.verzieren><en> 64 stone busts adorn the garden wall.
<G-vec00782-002-s138><adorn.verzieren><de> 64 Steinbüsten verzieren die Gartenmauer.
<G-vec00782-002-s139><adorn.verzieren><en> In a vast range of shapes and sizes, you will find every form of luxury ceiling light imaginable to beautifully adorn your home.
<G-vec00782-002-s139><adorn.verzieren><de> In einer großen Auswahl an Formen und Größen finden Sie alle nur erdenklichen luxuriösen Deckenbeleuchtungen, um Ihr Zuhause wunderschön zu verzieren.
<G-vec00782-002-s140><adorn.verzieren><en> Orange coloured decorative seams adorn the sides.
<G-vec00782-002-s140><adorn.verzieren><de> Orangefarbene Dekonähte verzieren die Seiten.
<G-vec00782-002-s141><adorn.verzieren><en> We used the stitching pattern to adorn our knitted tealight candleholders.
<G-vec00782-002-s141><adorn.verzieren><de> Wir haben die kleine Stichvorlage verwendet um unsere gestrickten Teelichthüllen zu verzieren.
<G-vec00782-002-s142><adorn.verzieren><en> Shallow sea, castles in the sand and children’s excited voices adorn the beaches which we have chosen.
<G-vec00782-002-s142><adorn.verzieren><de> Die Strände, die wir ausgewählt haben, sind mit seichtem Wasser, Sandburgen und fröhlichen Kinderstimmen verziert.
<G-vec00782-002-s143><adorn.verzieren><en> Carrera's iconic Flag motif and logo lettering adorn the temples, making this pair a real style statement meant to transcend well beyond seasons. Unisex full-rim aviator eyeglasses
<G-vec00782-002-s143><adorn.verzieren><de> Die Bügel sind mit dem kultigen Flaggenmotiv und dem Logo von Carrera verziert, wodurch diese Brille zu einem wahren Stilausdruck wird, der weit über die Jahreszeiten hinausgehen soll.
<G-vec00782-002-s118><adorn.zieren><en> While palace frescos adorn the walls of the classroom and you have access to a comprehensive library, you also have many different audio and video recordings available to you as learning material.
<G-vec00782-002-s118><adorn.zieren><de> Während die Fresken des Palazzos sogar Klassenzimmer zieren und Sie Zugang zu einer umfangreichen Bibliothek haben, stehen Ihnen auch vielfältige Audio- und Videoaufnahmen als Lernmaterial zur Verfügung.
<G-vec00782-002-s152><adorn.zieren><en> The scattered letters which adorn the towel, is the typography of Arne Jacobsen.
<G-vec00782-002-s152><adorn.zieren><de> Die markanten Buchstaben, die wie eine Bordüre die Schale von Design Letters zieren, stammen aus der Typografie von Arne Jacobsen.
<G-vec00782-002-s156><adorn.zieren><en> For evening wear animal skin trims and feathers adorn the styles.
<G-vec00782-002-s156><adorn.zieren><de> Am Abend zieren Fellbesätze und Federn die Modelle.
<G-vec00782-002-s157><adorn.zieren><en> The autumn colors inspired by meadows and forests, now adorn the new collections and make us want more.
<G-vec00782-002-s157><adorn.zieren><de> Die Herbstfarben, inspiriert von Wiesen und Wäldern, zieren jetzt die neuen Kollektionen und machen Lust auf mehr.
<G-vec00782-002-s158><adorn.zieren><en> Many of his works adorn synagogue architecture and other venues for worship.
<G-vec00782-002-s158><adorn.zieren><de> Viele seiner Arbeiten zieren Synagogen und andere Andachtshäuser.
<G-vec00782-002-s159><adorn.zieren><en> A cute bunny and intricate ornaments adorn plates, cups, egg cups and other Easter products in the annual edition.
<G-vec00782-002-s159><adorn.zieren><de> Ein niedlicher Hase und detailreiche Ornamente zieren Teller, Tasse, Eierbecher sowie weitere Osterartikel der Jahresedition.
<G-vec00782-002-s160><adorn.zieren><en> On behalf of the Italian Renaissance artists will adorn the frescoes of plenty.
<G-vec00782-002-s160><adorn.zieren><de> Im Namen der italienischen Renaissance Künstler der italienischen Renaissance Künstler zieren die Fresken des Überflusses.
<G-vec00782-002-s161><adorn.zieren><en> Contrastive white embroidered PENTA Sports logos adorn both sides of the headrest while an elliptical aluminium emblem with relief lettering details the backrest.
<G-vec00782-002-s161><adorn.zieren><de> Kontrastreich weiß eingestrickte PENTA Sports-Logos zieren die Kopflehne auf beiden Seiten sowie die Rückseite der Rückenlehne, während eine elliptische Aluminiumplakette mit Reliefbeschriftung an der Rückenlehne platziert wurde.
<G-vec00782-002-s162><adorn.zieren><en> Successful, highly melodic leads adorn the song structure as well as again very discreetly scattered symphonic nuances.
<G-vec00782-002-s162><adorn.zieren><de> Gelungene, höchst melodische Leads zieren die Songstruktur ebenso wie erneut sehr dezent eingestreute symphonische Nuancen.
<G-vec00782-002-s163><adorn.zieren><en> In the huge burial hall, which was completed recently after decades of building work, calligraphy, mirror mosaics and the stalactite decorations known as muqarnas adorn the walls and dome.
<G-vec00782-002-s163><adorn.zieren><de> In der gigantischen Grabhalle, die nach jahrzehntelanger Bautätigkeit kürzlich fertig gestellt wurde, zieren kalligraphische Schriftzüge, Spiegelmosaike und die Muqarnas genannte Stalaktitendekoration Wände und Kuppel.
<G-vec00782-002-s164><adorn.zieren><en> Brands such as Taft (3 Wetter Taft), Gliss Kur or Schauma are omnipresent in the media and adorn the supermarket shelves.
<G-vec00782-002-s164><adorn.zieren><de> Marken wie Taft (3 Wetter-Taft), Gliss Kur oder Schauma sind in den Medien omnipräsent und zieren die Supermarktregale.
<G-vec00782-002-s165><adorn.zieren><en> Exhort servants to be obedient unto their own masters, and to please them well in all things; not answering again; not purloining, but shewing all good fidelity; that they may adorn the doctrine of God our Saviour in all things.
<G-vec00782-002-s165><adorn.zieren><de> 9 Die Sklaven [ermahne], ihren eigenen Herren sich in allem unterzuordnen, sich wohlgefällig zu machen, nicht zu widersprechen, 10 nichts zu unterschlagen, sondern alle gute Treue zu erweisen, damit sie die Lehre, die unseres Heiland-Gottes ist, in allem zieren.
<G-vec00782-002-s166><adorn.zieren><en> Frescoes and chandeliers adorn the ceiling, boxes flank the sides.
<G-vec00782-002-s166><adorn.zieren><de> Fresken und Kronleuchter zieren die Decke, seitlich befinden sich Logen.
<G-vec00782-002-s167><adorn.zieren><en> Oil paintings and other pictures adorn the walls.
<G-vec00782-002-s167><adorn.zieren><de> Ölgemälde und andere Bilder zieren die Wände.
<G-vec00782-002-s168><adorn.zieren><en> The traces of the years adorn the metal and imbue it with character.
<G-vec00782-002-s168><adorn.zieren><de> Die Spuren der Jahre zieren das Blech, geben ihm Charakter.
<G-vec00782-002-s169><adorn.zieren><en> The blue and white Blucher Lace Espadrilles soft leather adorn a conspicuous zigzag print.
<G-vec00782-002-s169><adorn.zieren><de> Die blau weißen Blucher Schnür-Espadrilles aus weichem Leder zieren ein auffälliger Zick-Zack Print.
<G-vec00782-002-s170><adorn.zieren><en> In addition to heavily used living spaces, some collections can even adorn objects such as shops or offices without being detrimental to their appearance.
<G-vec00782-002-s170><adorn.zieren><de> Neben stark beanspruchten Wohnräumen können manche Kollektionen sogar Objekte wie Geschäfte oder Büros zieren, ohne dass es ihrem Äußeren abträglich ist.
<G-vec00782-002-s171><adorn.zieren><en> Two busts still adorn the building’s façade today.
<G-vec00782-002-s171><adorn.zieren><de> Zwei Büsten zieren auch heute noch die Fassade des Hauses.
<G-vec00782-002-s172><adorn.zieren><en> Chandeliers adorn the formal restaurant and breakfast is offered on site as well.
<G-vec00782-002-s172><adorn.zieren><de> Kronleuchter zieren das elegante Restaurant und das Frühstück wird ebenfalls in der Unterkunft angeboten.
<G-vec00782-002-s173><adorn.zieren><en> Kähler is adding a new chapter in partnership with Turi Heisselberg Pedersen, whose matt glaze and architectural shapes adorn five different vases in the new Kontur collection.
<G-vec00782-002-s173><adorn.zieren><de> Ein neues Kapitel fügt Kähler in Partnerschaft mit Turi Heisselberg Pedersen hinzu, dessen Mattglasuren und architektonische Formen fünf verschiedene Vasen in der neuen Kontur-Kollektion zieren.
<G-vec00782-002-s174><adorn.zieren><en> They adorn jackets, costumes or hats and are simply part of carnival.
<G-vec00782-002-s174><adorn.zieren><de> Sie zieren Jacken, Kostüme oder Hüte und gehören zum Fasching einfach dazu.
<G-vec00782-002-s175><adorn.zieren><en> All travel takes place exclusively via these waterways – whether by vaporetto, water taxi or the famous gondolas which adorn the cityscape and are so popular with tourists from all over the world.
<G-vec00782-002-s175><adorn.zieren><de> Der Verkehr findet ausschließlich auf dem Wasser statt - ob mit Vaporetto, Wassertaxi oder den berühmten Gondeln, die das Stadtbild zieren und besonders bei Touristen aus aller Welt beliebt sind.
<G-vec00782-002-s176><adorn.zieren><en> Sporty black stripes adorn the short sleeves for a contrasting look and an amazing style.
<G-vec00782-002-s176><adorn.zieren><de> Sportliche, schwarze Streifen zieren die kurzen Ärmel und erzeugen so einen perfekten Kontrast.
<G-vec00782-002-s177><adorn.zieren><en> Native American religion I cannot abide any religions that adorn the face of our planet that has gathering houses.
<G-vec00782-002-s177><adorn.zieren><de> Indianische Religion Ich kann keine der Religionen befolgen die das Gesicht unseres Planeten zieren, welche Versammlungshäuser hat.
<G-vec00782-002-s178><adorn.zieren><en> Small golden toothed wheels adorn the front of the lace necklace.
<G-vec00782-002-s178><adorn.zieren><de> Kleine Zahnräder zieren als Verschluss die Vorderseite des Spitzen Halsbands.
<G-vec00782-002-s179><adorn.zieren><en> They adorn both front panels, the slits and the sleeves.
<G-vec00782-002-s179><adorn.zieren><de> Sie zieren Vorderteile, Schlitze und die Ärmel.
<G-vec00782-002-s180><adorn.zieren><en> The vinyl records of the White Album were the first to adorn the Apple Records logo: a green apple of the Granny Smith variety, once from the outside, once in cross-section.
<G-vec00782-002-s180><adorn.zieren><de> Die Vinyl-Schallplatten des Weißen Albums waren die ersten, die das Logo von Apple Records zierte: ein grüner Apfel der Sorte Granny Smith, einmal von außen, einmal im Querschnitt.
<G-vec00972-002-s077><adorn.verschönern><en> Elaborate flower designs are worked into the glass walls and glass doors; the marble columns are decorated with realistic flower mosaics, and flowers in relief adorn the interior walls – very unusual for a mosque. And something else is striking: the rooms are as bright as daylight.
<G-vec00972-002-s077><adorn.verschönern><de> In Glaswände und -türen sind künstlerische Blumen-Motive eingearbeitet, die Marmorsäulen zieren realistische Blumenmosaiken, Reliefblumen verschönen Innenwände – sehr ungewöhnlich für eine Moschee, in der noch etwas auffällt: die Räume sind taghell.
<G-vec00972-002-s065><adorn.verziern><en> A beautiful cut warm brown bar of wood adorn this necklace.
<G-vec00972-002-s065><adorn.verziern><de> Diese Halskette wird von einem schön zugeschnittenen Holzstab in warmem Braun verziert.
