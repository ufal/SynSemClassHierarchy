<G-vec00118-002-s070><dampen.eindämmen><en> The author appreciates above all high quality of the workmanship and the materials used for the manufacture, as well as the solutions used to dampen the case.
<G-vec00118-002-s070><dampen.eindämmen><de> Der Autor schätzt vor allem die hohe Qualität der Verarbeitung, die Materialien sowie die Lösungen zum Dämmen des Gehäuses.
<G-vec00118-002-s071><dampen.eindämmen><en> SACHS suspension strut mounts for light commercial vehicles decouple disturbing oscillations and dampen vibrations and wheel noise.
<G-vec00118-002-s071><dampen.eindämmen><de> SACHS Federbeinstützlager für Transporter entkoppeln Störschwingungen und dämmen Vibrationen und Radabrollgeräusche.
<G-vec00118-002-s118><dampen.mildern><en> The cab rests on two rubber isolators at the front and two fully integrated shock absorbers at the rear which dampen the vibrations coming through the frame.
<G-vec00118-002-s118><dampen.mildern><de> Die Kabine ruht vorne auf zwei Silentblöcken sowie hinten auf zwei voll integrierten Stoßdämpfern, die Vibrationen des Rahmens mildern.
<G-vec00118-002-s117><dampen.mindern><en> It can be filled with sand to dampen vibrations.
<G-vec00118-002-s117><dampen.mindern><de> Der Mast kann mit Sand gefüllt werden, um Vibrationen zu mindern.
