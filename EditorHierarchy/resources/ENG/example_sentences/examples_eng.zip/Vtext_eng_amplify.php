<G-vec00108-002-s050><amplify.ausführen><en> Let us amplify that a bit.
<G-vec00108-002-s050><amplify.ausführen><de> Lassen Sie uns das ein bisschen ausführen.
<G-vec00108-002-s069><amplify.ausführen><en> Many of his writings and hundreds of his lectures amplify the data in this chapter and provide a complete understanding of this basic of human relationships.
<G-vec00108-002-s069><amplify.ausführen><de> Viele seiner Schriften und Hunderte seiner Vorträge führen die in diesem Kapitel beschriebenen Daten näher aus und bieten ein vollständiges Verstehen dieser Grundlage menschlicher Beziehungen.
