<G-vec00389-002-s039><crush.(sich)_brechen><en> We also crush concrete compound paving stones or railway track ballast without any problems with our rock breaker, the PTH crusher.
<G-vec00389-002-s039><crush.(sich)_brechen><de> Wir brechen mit unserem Steinbrechern der PTH Crusher & PTH Multi Crusher Serie ebenfalls problemlos Betonverbundpflaster, Asphaltbeläge oder Schotter auf Bahntrassen.
<G-vec00389-002-s040><crush.(sich)_brechen><en> · The PEA assumes treatment of approximately 78% of the mineralized material tonnage by crush and agglomeration, with the remaining 22% treated as run-of-mine.
<G-vec00389-002-s040><crush.(sich)_brechen><de> · In der PEA wird angenommen, dass etwa 78 Prozent der Tonnage des mineralisierten Materials mittels Brechen und Anhäufung und die restlichen 22 Prozent mittels Förderverarbeitung behandelt werden.
<G-vec00389-002-s041><crush.(sich)_brechen><en> Unable to crush the spirit of millions who had experienced improved health and positive life changes from Falun Gong, Jiang’s regime has intensified its propaganda campaign to turn public opinion against the practise while quietly imprisoning, torturing and even murdering those who practise it.
<G-vec00389-002-s041><crush.(sich)_brechen><de> Unfähig, die Spiritualität von Millionen zu brechen, die eine verbesserte Gesundheit und eine Verbesserung der Lebensqualität durch Falun Gong bekommen haben, hat Jiangs Regime seine Propagandakampagne entfacht, um die öffentliche Meinung gegen die Praxis aufzubringen, während es heimlich jene die es praktizieren einsperrt, foltert und zu Tode bringt.
<G-vec00389-002-s042><crush.(sich)_brechen><en> In mining business, Mario Sinacola & Sons have already successfully used the machines to mine pay minerals for many years, for Wirtgen surface miners cut, crush and load the material in a single operation.
<G-vec00389-002-s042><crush.(sich)_brechen><de> Im Mininggeschäft setzt Mario Sinacola & Sons die Maschinen bereits seit Jahren erfolgreich zum Abbau von Nutzmineralien ein, denn Wirtgen Surface Miner schneiden, brechen und verladen das Material in einem Arbeitsgang.
<G-vec00389-002-s043><crush.(sich)_brechen><en> All GT Probe, RAB, RC, and diamond core samples were prepared using procedure PRP70-250 (crush, split and pulverize 250 g to 200 mesh) and analyzed by method FA430 (30g fire assay with AAS finish) and AQ200 (0.5g, aqua regia digestion and ICP-MS analysis).
<G-vec00389-002-s043><crush.(sich)_brechen><de> Alle GT Probe-, RAB-, RC- und Diamantkernproben wurden mit dem Verfahren PRP70-250 (Brechen, Spalten und Pulverisieren von 250 g bis 200 mesh) hergestellt und mit der Methode FA430 (30g Brandprobe mit AAS-Finish) und AQ200 (0,5g, Aqua Regia-Aufschluss und ICP-MS-Analyse) analysiert.
<G-vec00389-002-s044><crush.(sich)_brechen><en> For a reason: unlike you might think, icebreakers do not forcefully "split" open the ice, but they "slide" on top of the iceshield and crush it down with their immense weight.
<G-vec00389-002-s044><crush.(sich)_brechen><de> Eisbrecher haben eine andere Form - sie sind runder: anders als gedacht "teilen" Eisbrecher die Eisfläche nicht mit dem Bug; sondern "schieben" sich darauf um es mit ihrem immensen Gewicht nach unten zu brechen.
<G-vec00389-002-s045><crush.(sich)_brechen><en> The high-grade, soft, free-dig saprolite-hosted ore, requiring no primary crush or grind combined with a simple and proven flowsheet results in low capital intensity and extremely low operating costs.
<G-vec00389-002-s045><crush.(sich)_brechen><de> Das hochgradige, weiche, mittels freier Grabungen zugängliche Saprolitherz, das kein primäres Brechen oder Zerkleinern erfordert, führt zusammen mit einem einfachen und bewährten Fließschema zu einer geringen Kapitalintensität und extrem niedrigen Betriebskosten.
<G-vec00389-002-s046><crush.(sich)_brechen><en> Her tank, the Fighting Girlfriend (was sent to Smolensk to crush German resistance.
<G-vec00389-002-s046><crush.(sich)_brechen><de> Ihr Panzer, genannt Fighting Girlfriend (wurde nach Smolensk beordert, um den deutschen Widerstand zu brechen.
<G-vec00389-002-s047><crush.(sich)_brechen><en> Do not crush the tablet.
<G-vec00389-002-s047><crush.(sich)_brechen><de> Brechen Sie die Tablette nicht.
<G-vec00389-002-s022><crush.aufbrechen><en> Crush the heads with a hammer; remove the large pieces of shell.
<G-vec00389-002-s022><crush.aufbrechen><de> Die Köpfe mit einem Hammer aufbrechen und die großen Schalenstücke entfernen.
<G-vec00389-002-s023><crush.aufbrechen><en> In the same way one day your friends from the Invisible world will come, will crush the doors of your prisons and will say: “Go outside on free!” Today all contemporary people find under the spiritual slavery of the Turks, which they have to set free from.
<G-vec00389-002-s023><crush.aufbrechen><de> Auf dieselbe Weise werden eines Tages eure Freunde von der Unsichtbaren Welt kommen, die Türen eurer Gefängnisse aufbrechen und sagen: „Geht in der Freiheit hinaus!“ Alle heutigen Menschen befinden sich jetzt unter der geistigen Herrschaft der „Türken“, wovon sie sich befreien sollen.
<G-vec00389-002-s024><crush.aufbrechen><en> My titanium wrench can crack a rusted nut from a bolt as easily as it can crush skulls.
<G-vec00389-002-s024><crush.aufbrechen><de> Mein Titan Schraubenschlüssel kann ebenso leicht eine Mutter aus einem Bolzen brechen, als auch Schädel aufbrechen.
<G-vec00389-002-s029><crush.ausschalten><en> He sent his cousin Wang Yi (with what he considered to be overwhelming force, some 430,000 men, intending to crush the newly constituted Han regime.
<G-vec00389-002-s029><crush.ausschalten><de> Als Wang Mang erkannte, dass Gengshi sich zu einer ernsthaften Bedrohung entwickelte, schickte er seinen Vetter Wang Yi (mit einer Streitmacht von 430.000 Mann aus, um die neu eingesetzte Han-Dynastie auszuschalten.
<G-vec00389-002-s030><crush.ausschalten><en> Go behind enemy lines in one of history’s hottest conflict zones and do what it takes to crush the axis powers once and for all.
<G-vec00389-002-s030><crush.ausschalten><de> Wag dich in einem der gefährlichsten Konfliktgebiete der Geschichte hinter die feindlichen Linien und gib alles, um die Achsenmächte ein für alle Mal auszuschalten.
<G-vec00389-002-s035><crush.besiegen><en> They were sure of their victory and wanted to crush their enemy, not to end the battle with an armistice.
<G-vec00389-002-s035><crush.besiegen><de> Sie waren sich nämlich ihres Sieges sicher, wollten den Feind besiegen und nicht die Schlacht durch die Annahme dieses Waffenstillstandes beenden.
<G-vec00389-002-s036><crush.besiegen><en> Each of the 225 levels requires logic, skill, and brute force to crush the enemy.
<G-vec00389-002-s036><crush.besiegen><de> Für jeden der 225 Levels werden Logik, Geschick und rohe Gewalt benötigt, um den Feind zu besiegen.
<G-vec00389-002-s037><crush.besiegen><en> Even a small Varga soldier could surely crush her.
<G-vec00389-002-s037><crush.besiegen><de> Sogar ein kleiner Varga-Soldat könnte sie sicherlich besiegen.
<G-vec00389-002-s038><crush.besiegen><en> Each character brings their unique fighting style to the arena – utilising special attacks, unique moves and an Awesome Attack to crush their opponents.
<G-vec00389-002-s038><crush.besiegen><de> Jeder Charakter verfügt über seinen ganz eigenen Kampfstil und setzt Spezialangriffe, einzigartige Techniken und eine Ehrfurcht gebietende Geheimtechnik ein, um seine Gegner zu besiegen.
<G-vec00389-002-s039><crush.brechen><en> We also crush concrete compound paving stones or railway track ballast without any problems with our rock breaker, the PTH crusher.
<G-vec00389-002-s039><crush.brechen><de> Wir brechen mit unserem Steinbrechern der PTH Crusher & PTH Multi Crusher Serie ebenfalls problemlos Betonverbundpflaster, Asphaltbeläge oder Schotter auf Bahntrassen.
<G-vec00389-002-s040><crush.brechen><en> · The PEA assumes treatment of approximately 78% of the mineralized material tonnage by crush and agglomeration, with the remaining 22% treated as run-of-mine.
<G-vec00389-002-s040><crush.brechen><de> · In der PEA wird angenommen, dass etwa 78 Prozent der Tonnage des mineralisierten Materials mittels Brechen und Anhäufung und die restlichen 22 Prozent mittels Förderverarbeitung behandelt werden.
<G-vec00389-002-s041><crush.brechen><en> Unable to crush the spirit of millions who had experienced improved health and positive life changes from Falun Gong, Jiang’s regime has intensified its propaganda campaign to turn public opinion against the practise while quietly imprisoning, torturing and even murdering those who practise it.
<G-vec00389-002-s041><crush.brechen><de> Unfähig, die Spiritualität von Millionen zu brechen, die eine verbesserte Gesundheit und eine Verbesserung der Lebensqualität durch Falun Gong bekommen haben, hat Jiangs Regime seine Propagandakampagne entfacht, um die öffentliche Meinung gegen die Praxis aufzubringen, während es heimlich jene die es praktizieren einsperrt, foltert und zu Tode bringt.
<G-vec00389-002-s042><crush.brechen><en> In mining business, Mario Sinacola & Sons have already successfully used the machines to mine pay minerals for many years, for Wirtgen surface miners cut, crush and load the material in a single operation.
<G-vec00389-002-s042><crush.brechen><de> Im Mininggeschäft setzt Mario Sinacola & Sons die Maschinen bereits seit Jahren erfolgreich zum Abbau von Nutzmineralien ein, denn Wirtgen Surface Miner schneiden, brechen und verladen das Material in einem Arbeitsgang.
<G-vec00389-002-s043><crush.brechen><en> All GT Probe, RAB, RC, and diamond core samples were prepared using procedure PRP70-250 (crush, split and pulverize 250 g to 200 mesh) and analyzed by method FA430 (30g fire assay with AAS finish) and AQ200 (0.5g, aqua regia digestion and ICP-MS analysis).
<G-vec00389-002-s043><crush.brechen><de> Alle GT Probe-, RAB-, RC- und Diamantkernproben wurden mit dem Verfahren PRP70-250 (Brechen, Spalten und Pulverisieren von 250 g bis 200 mesh) hergestellt und mit der Methode FA430 (30g Brandprobe mit AAS-Finish) und AQ200 (0,5g, Aqua Regia-Aufschluss und ICP-MS-Analyse) analysiert.
<G-vec00389-002-s044><crush.brechen><en> For a reason: unlike you might think, icebreakers do not forcefully "split" open the ice, but they "slide" on top of the iceshield and crush it down with their immense weight.
<G-vec00389-002-s044><crush.brechen><de> Eisbrecher haben eine andere Form - sie sind runder: anders als gedacht "teilen" Eisbrecher die Eisfläche nicht mit dem Bug; sondern "schieben" sich darauf um es mit ihrem immensen Gewicht nach unten zu brechen.
<G-vec00389-002-s045><crush.brechen><en> The high-grade, soft, free-dig saprolite-hosted ore, requiring no primary crush or grind combined with a simple and proven flowsheet results in low capital intensity and extremely low operating costs.
<G-vec00389-002-s045><crush.brechen><de> Das hochgradige, weiche, mittels freier Grabungen zugängliche Saprolitherz, das kein primäres Brechen oder Zerkleinern erfordert, führt zusammen mit einem einfachen und bewährten Fließschema zu einer geringen Kapitalintensität und extrem niedrigen Betriebskosten.
<G-vec00389-002-s046><crush.brechen><en> Her tank, the Fighting Girlfriend (was sent to Smolensk to crush German resistance.
<G-vec00389-002-s046><crush.brechen><de> Ihr Panzer, genannt Fighting Girlfriend (wurde nach Smolensk beordert, um den deutschen Widerstand zu brechen.
<G-vec00389-002-s047><crush.brechen><en> Do not crush the tablet.
<G-vec00389-002-s047><crush.brechen><de> Brechen Sie die Tablette nicht.
<G-vec00389-002-s090><crush.erdrücken><en> No no I can’t stop. Crush me with your love…but seriously it’s sweet of you to be so kind to me.
<G-vec00389-002-s090><crush.erdrücken><de> Erdrückt mich mit eurer Liebe… aber ernsthaft, es ist süß von euch, so lieb zu mir zu sein.
<G-vec00389-002-s091><crush.erdrücken><en> The CCP still positions itself as a promoter of the Olympic spirit, deceiving the world, even as it takes blatant steps to crush human rights across China.
<G-vec00389-002-s091><crush.erdrücken><de> Während die KPCh sich selber als Förderer des olympischen Geistes darstellt, in Wahrheit aber die Welt täuscht, und das selbst noch dann, wenn es offensichtlich die Menschenrechte in ganz China erdrückt.
<G-vec00389-002-s092><crush.erdrücken><en> But if a person, when asked a question, doesn't put down [the questioner], doesn't crush him, doesn't ridicule him, doesn't grasp at his little mistakes, then — that being the case — he is a person fit to talk with.
<G-vec00389-002-s092><crush.erdrücken><de> Aber wenn eine Person, der eine Frage gestellt, [den Fragenden] nicht runter macht, ihn nicht erdrückt, ihn nicht verspottet, seine kleinen Fehler nicht ergreift, dann, wenn das der Fall ist, ist er eine Person, die für Gespräche gerüstet ist.
<G-vec00389-002-s118><crush.niederschlagen><en> The Thirty Year War was a devastating conflict that started in 1618 as the Roman Catholic Church used its political and military power to crush the Protestant Reformation.
<G-vec00389-002-s118><crush.niederschlagen><de> Der Dreißigjährige Krieg war ein verheerender Konflikt, der 1618 begann als die römisch-katholische Kirche ihre politische und militärische Macht gebrauchte um die protestantische Reformation niederzuschlagen.
<G-vec00389-002-s119><crush.niederschlagen><en> However, this aid is a double-edged sword, because its dependence on US goodwill thus limits the freedom of action Israel has in its efforts to crush the revolt.
<G-vec00389-002-s119><crush.niederschlagen><de> Diese Hilfe ist aber ein zweischneidiges Schwert, denn die Abhängigkeit vom guten Willen der USA beschränkt Israels Handlungsfreiheit bei seinen Versuchen, die Revolte niederzuschlagen.
<G-vec00389-002-s120><crush.niederschlagen><en> They are ready at any moment to destroy the Petrograd Soviet and crush the Revolution....
<G-vec00389-002-s120><crush.niederschlagen><de> Sie sind jeden Moment bereit, den Petrograder Sowjet auseinanderzujagen und die Revolution niederzuschlagen.
<G-vec00389-002-s121><crush.niederschlagen><en> While deploring repression in Syria, the Saudi absolutist monarchy, a key US strategic ally and the world’s top oil producer, is engaged in a ruthless campaign to crush unrest in its predominantly Shia eastern region.
<G-vec00389-002-s121><crush.niederschlagen><de> Während sie die Unterdrückung in Syrien verteufelt, beteiligt sich die absolutistische Monarchie Saudi-Arabiens, ein äußerst wichtiger Verbündeter der USA und der weltweit größte Produzent von Erdöl, an einem gnadenlosen Feldzug, um Unruhen in seiner hauptsächlich schiitischen östlichen Region niederzuschlagen.
<G-vec00389-002-s122><crush.niederschlagen><en> In the case of the states of the Ferghana Valley, the fight against the ‘fundamentalist enemy’ is the perfect excuse to crush the slightest hint of opposition without causing too much fuss.
<G-vec00389-002-s122><crush.niederschlagen><de> Und wie der Fall der Staaten des Ferghana-Tals zeigt, ist der Kampf gegen den „fundamentalistischen Feind“ die perfekte Ausrede, um jede aufkeimende Opposition ohne viel Aufsehen niederzuschlagen.
<G-vec00389-002-s123><crush.quetschen><en> This reduces the chance that the weight slips out of your fingers and you actually crush your skull.
<G-vec00389-002-s123><crush.quetschen><de> Dies verringert die Wahrscheinlichkeit, dass das Gewicht aus Ihren Fingern rutscht und Sie Ihren Schädel quetschen.
<G-vec00389-002-s124><crush.quetschen><en> Since we already have spend a while in Siem Reap of course we know where the best place for this would be. So we drive back to our accommodation, then meet up and all 5 of us crush into a tuk-tuk for a night out in the city.
<G-vec00389-002-s124><crush.quetschen><de> Da wir ja schon eine Weile in Siem Riep sind, wissen wir natürlich, wo wir am günstigsten was Gutes finden und so fahren wir zurück zu unseren Unterkünften, treffen uns dann und quetschen uns zu Fünft in ein Tuktuk um die Stadt unsicher zu machen.
<G-vec00389-002-s125><crush.quetschen><en> A grain mill grinds with two mill-stones and cannot be used to crush flakes.
<G-vec00389-002-s125><crush.quetschen><de> Eine Getreidemühle mahlt mit 2 Mahlsteinen und kann keine Flocken quetschen.
<G-vec00389-002-s126><crush.quetschen><en> Do not crimp or crush the power cable and lay it in such a way as to prevent anyone from stepping on or tripping over it.
<G-vec00389-002-s126><crush.quetschen><de> Knicken oder quetschen Sie das Netzkabel nicht und verlegen Sie das Netzkabel so, dass niemand darauf treten oder darüber stolpern kann.
<G-vec00389-002-s127><crush.quetschen><en> Do not kink or crush the power cable and lay it in such a way as to prevent people from stepping on or tripping over it.
<G-vec00389-002-s127><crush.quetschen><de> Knicken oder quetschen Sie die Netzanschlussleitung nicht und verlegen Sie sie so, dass niemand darauf treten oder darüber stolpern kann.
<G-vec00389-002-s132><crush.schlagen><en> Perfect your ability to crush the games at the low and mid stakes, and get the right preparation for moving up even further.
<G-vec00389-002-s132><crush.schlagen><de> Perfektionier dein Spiel, um die Partien auf den Low- und Mid-Stakes solide zu schlagen und noch weiter aufzusteigen.
<G-vec00389-002-s133><crush.schlagen><en> During the night following up to the slaughter and on the morning thereof, the king amazes his exhausted soldiers when the English crush their enemy.
<G-vec00389-002-s133><crush.schlagen><de> In der Nacht vor und am Morgen der Schlacht kann der König seine erschöpften Männer derart begeistern, dass die Engländer den Gegner vernichtend schlagen.
<G-vec00389-002-s134><crush.schlagen><en> I prefer the outside, where the wind messes up my hair while listening to the sound the waves make, when they crush against the bottom of the ferry.
<G-vec00389-002-s134><crush.schlagen><de> Ich mag es am liebsten, draußen zu sitzen, wenn meine Haare im Wind flattern, während ich dem Klang der Wellen lausche, wie sie gegen die Unterseite der Fähre schlagen.
<G-vec00389-002-s166><crush.unterdrücken><en> 22 Do not exploit a poor person because he is poor and do not crush the needy in court,
<G-vec00389-002-s166><crush.unterdrücken><de> 22 Beraube den Armen nicht, ob er wohl arm ist, und unterdrücke den Elenden nicht im Tor.
<G-vec00389-002-s167><crush.unterdrücken><en> 72:4 He will defend the afflicted among the people and save the children of the needy; he will crush the oppressor.
<G-vec00389-002-s167><crush.unterdrücken><de> 72:4 Er schaffe den Elenden des Volkes Recht und helfe den Kindern der Armen und unterdrücke den Gewalttätigen.
<G-vec00389-002-s168><crush.verknallen><en> Play online flash game Fossil crush for free.
<G-vec00389-002-s168><crush.verknallen><de> Play online Flash-Spiel Fossil verknallt kostenlos.
<G-vec00389-002-s169><crush.verknallen><en> I’ve got a crush on Percy Jackson and Jacob Reckless (Both are already unavailable).
<G-vec00389-002-s169><crush.verknallen><de> Ich bin in Percy Jackson und Jacob Reckless verknallt (Beide sind schon vergeben).
<G-vec00389-002-s170><crush.verknallen><en> If he has a girlfriend and you think he has a great relationship and are happy for him without any complications, then you probably don't have a crush.
<G-vec00389-002-s170><crush.verknallen><de> Wenn er eine Freundin hat und du denkst, dass sie super zusammen passen, du ohne Einschränkungen glücklich für ihn bist, dann bist du sicher nicht verknallt.
<G-vec00389-002-s171><crush.verknallen><en> After Sam's AV Club comment, Freddie seems quite annoyed, because he knows that she has a crush on Shane.
<G-vec00389-002-s171><crush.verknallen><de> Nach Sams Technik-Club Äußerung sieht Freddie leicht verärgert aus, da sie das nur gesagt hat, weil sie in Shane verknallt war.
<G-vec00389-002-s172><crush.verknallen><en> You may be misreading the signs and thinking a really friendly girl has a crush on you.
<G-vec00389-002-s172><crush.verknallen><de> Du solltest also die Zeichen nicht missdeuten und denken, dass ein wirklich freundliches Mädchen in dich verknallt ist.
<G-vec00389-002-s173><crush.verknallen><en> For those of you stuck with a love-on for an Aries or even just a crush, don’t play games, they will go over his/her head.
<G-vec00389-002-s173><crush.verknallen><de> Diejenigen unter Ihnen, die sich in einen Widder verliebt haben oder nur verknallt sind, spielen keine Spiele, sie gehen ihm über den Kopf.
<G-vec00389-002-s174><crush.verknallen><en> So I was at a monthly rock 'n' roll dance party at a local bar when I saw him: the tall, dark, and handsome boy I had a mild crush on when I was in high school.
<G-vec00389-002-s174><crush.verknallen><de> Ich war auf einer monatlichen Rock'n' Roll-Party in einer Bar, als ich ihn sah: den großen, dunklen und gut aussehenden Typen, in den ich in der High School leicht verknallt war.
<G-vec00389-002-s175><crush.verknallen><en> Watching her crush and dominate Jade Emin would be hot.
<G-vec00389-002-s175><crush.verknallen><de> Es wäre heiß zu sehen, wie sie sich verknallt und Jade Emin dominiert.
<G-vec00389-002-s176><crush.verknallen><en> Description These two princesses have a crush on the same boy.
<G-vec00389-002-s176><crush.verknallen><de> Beschreibung Diese Prinzessinnen sind in denselben Jungen verknallt.
<G-vec00389-002-s177><crush.verlieben><en> If she doesn’t mention that he has a crush on anybody else, it’s probably a sign that she likes you.
<G-vec00389-002-s177><crush.verlieben><de> Wenn sie nicht erwähnt, dass sie in jemanden verliebt ist, ist das wahrscheinlich ein Zeichen, dass sie dich mag.
<G-vec00389-002-s178><crush.verlieben><en> She has a huge crush on her neighbor Jeremy, but manages to embarrass herself every time she's around him.
<G-vec00389-002-s178><crush.verlieben><de> Abbi ist in ihren Nachbarn Jeremy verliebt, schafft es aber, sich jedes Mal zu blamieren, wenn sie ihm begegnet.
<G-vec00389-002-s179><crush.verlieben><en> If the guy in question is always there for you when you need him and always down to spend time together, he might have a crush on you.
<G-vec00389-002-s179><crush.verlieben><de> Wenn der fragliche Junge immer für dich da ist, wenn du ihn brauchst, und immer gern Zeit mit dir verbringt, ist er möglicherweise in dich verliebt.
<G-vec00389-002-s180><crush.verlieben><en> At seven, she develops a crush on a housemaid named Collins, and is devastated when she sees Collins kissing a footman.
<G-vec00389-002-s180><crush.verlieben><de> Im Alter von sieben Jahren verliebt sie sich in eine Magd namens Collins und ist überaus enttäuscht, als sie sieht, wie Collins einen Diener des Hauses küsst.
<G-vec00389-002-s181><crush.verlieben><en> See if he has a friend who is always eyeing you and who you may think could have a crush on you instead.
<G-vec00389-002-s181><crush.verlieben><de> Also schau dich mal um, ob er einen Freund hat, der nach dir schielt und stattdessen in dich verliebt sein könnte.
<G-vec00389-002-s182><crush.vernichten><en> Crush opponents with incredibly powerful maneuvers and combinations of kicks.
<G-vec00389-002-s182><crush.vernichten><de> Vernichte deine Gegner mit unglaublichen Techniken und Schlagkombinationen.
<G-vec00389-002-s183><crush.vernichten><en> Earn respect, form an alliance and crush your enemies.
<G-vec00389-002-s183><crush.vernichten><de> Verdiene den Respekt, forme eine Allianz und vernichte deine Feinde.
<G-vec00389-002-s184><crush.vernichten><en> Crush hordes of demons and other enemies standing on your way. Game features:
<G-vec00389-002-s184><crush.vernichten><de> Vernichte Horden von Dämonen und anderer Feinde, die dir auf dem Weg entgegenkommen.
<G-vec00389-002-s185><crush.vernichten><en> Votes: 56 Coin master - go on an epic journey with vikings, head a village, play slots to crush enemies and get treasure.
<G-vec00389-002-s185><crush.vernichten><de> Stimmen: 63 Begib dich in Coin Master auf eine Reise mit Wikingern, führe ein Dorf an, spiele an Spielautomaten, vernichte deine Feinde und gewinne Schätze.
<G-vec00389-002-s186><crush.vernichten><en> Take part in great battles and crush strong opponents.
<G-vec00389-002-s186><crush.vernichten><de> Nimm an großen Schlachten teil und vernichte starke Gegner.
<G-vec00389-002-s187><crush.vernichten><en> - Train your army, lead them into battle, and crush your enemies.
<G-vec00389-002-s187><crush.vernichten><de> - Führe deine Truppen in epische Schlachten und vernichte deine Gegner.
<G-vec00389-002-s207><crush.zerdrücken><en> Strip eucalyptus leaves from stem, and gently crush with your hands.
<G-vec00389-002-s207><crush.zerdrücken><de> 4 Löse die Eukalyptusblätter vom Stil und zerdrücke sie sanft in deiner Hand.
<G-vec00389-002-s208><crush.zerdrücken><en> Using a clean potato masher or your hands, crush and squeeze the fruit to release its juices.
<G-vec00389-002-s208><crush.zerdrücken><de> Zerdrücke und presse das Obst mit einem Kartoffelstampfer oder deinen Händen, damit es den Saft freigibt.
<G-vec00389-002-s236><crush.zerkleinern><en> All GT Probe, RAB, RC, and diamond core samples were prepared using procedure PRP70-250 (crush, split and pulverize 250 g to 200 mesh) and analyzed by method FA430 (30g fire assay with AAS finish) and AQ200 (0.5g, aqua regia digestion and ICP-MS analysis).
<G-vec00389-002-s236><crush.zerkleinern><de> Alle Proben der GT Probe, RAB-, RC- und Kernbohrungen wurden mittels Verfahren PRP70-250 (zerkleinern, aufteilen und pulverisieren von 250 Gramm auf 200 Mesh) aufbereitet und analysiert mittels Verfahren FA430 (Brandprobe einer 30-Gramm-Einwaage mit anschließender AAS-Analyse) und AQ200 (lösen von 0,5 Gramm in Königswasser mit anschließender ICP-MS-Analyse).
<G-vec00389-002-s237><crush.zerkleinern><en> Add the garlic and ginger and also crush.
<G-vec00389-002-s237><crush.zerkleinern><de> Knoblauchzehe und Ingwer hinzugeben und ebenfalls zerkleinern.
<G-vec00389-002-s238><crush.zerkleinern><en> Wash the sweet corn and parsley, peel the ginger and crush.
<G-vec00389-002-s238><crush.zerkleinern><de> Petersilie waschen, Ingwer schälen und zerkleinern.
<G-vec00389-002-s239><crush.zerkleinern><en> With the help of the blender, you can easily crush, shake and mix.
<G-vec00389-002-s239><crush.zerkleinern><de> Mit Hilfe des Standmixers können Sie kinderleicht Zerkleinern, Shaken und Mixen.
<G-vec00389-002-s240><crush.zerkleinern><en> Place red and yellow candies in a plastic bag. Finely crush the candies with the flat side of a meat mallet or hammer.
<G-vec00389-002-s240><crush.zerkleinern><de> Rote und gelbe Bonbons in eine Plastiktüte geben und mit dem Nudelholz die Bobons zerkleinern.
<G-vec00389-002-s241><crush.zerkleinern><en> If you have trouble swallowing the tablet, you can also crush it first and then mix the powder with water or juice.
<G-vec00389-002-s241><crush.zerkleinern><de> Haben Sie Schwierigkeiten, die Tabletten im Ganzen zu schlucken, können Sie diese zunächst zerkleinern und anschließend das Pulver mit etwas Wasser oder Saft einnehmen.
<G-vec00389-002-s242><crush.zerkleinern><en> For this children’s finger food recipe you must first crush a packet of cookies in a bag with a tablespoon.
<G-vec00389-002-s242><crush.zerkleinern><de> Für diese Variante vom Kinder Fingerfood müssen Sie als erstes eine Packung Kekse in einem Beutel mit dem Esslöffel zerkleinern.
<G-vec00389-002-s243><crush.zerkleinern><en> (7) As the barrel rotates, the material is crushed between the individual pieces of grinding media that mix and crush the product into fine powder over a period of several hours.
<G-vec00389-002-s243><crush.zerkleinern><de> (7) Während sich der Zylinder dreht, wird das Material zwischen den einzelnen Mahlkörpern zerkleinert, die das Produkt über mehrere Stunden vermischen und in feines Pulver zerkleinern .
<G-vec00389-002-s244><crush.zerkleinern><en> - On the cupboard or on the edge of the cooker hood there are the alarm clock, some candlesticks, the “pista sale” (bowl with a pestle in wood used to crush the salt), the “moscarola” (glass container used to catch the flies), the “masenin da cafè” (coffee-grinder).
<G-vec00389-002-s244><crush.zerkleinern><de> - auf dem Küchenschrank oder auf dem Rand der Kaminhaube befindet sich der Wecker, einige Kerzenständer, der "pista sale" (Topf mit Holzstößel zum Zerkleinern des groben Salzes), die "moscarola" (Glasvase, die als Fliegenfalle verwendet wurde), der "masenin da cafè" (Kaffeemühle).
<G-vec00389-002-s245><crush.zerkleinern><en> The name ‘mortadella’ dates back to the Roman age and refers to the mortarium (mortar), a tool used since then to crush the pork meat and obtain a particular sausage.
<G-vec00389-002-s245><crush.zerkleinern><de> Und der Name ‘Mortadella’ geht eben auf die Zeit der Römer zurück und bezieht sich auf mortarium (Mörser), ein Gerät das seit damals zum Zerkleinern von Schweinefleisch eingesetzt wurde, das dann in Häuten abgefüllt wurde.
<G-vec00389-002-s246><crush.zerkleinern><en> Then crush the walnuts in a food processor with the rest of the ingredients.
<G-vec00389-002-s246><crush.zerkleinern><de> Am nächsten Tag in der Küchenmaschine mit allen Zutaten zerkleinern.
<G-vec00389-002-s247><crush.zerkleinern><en> Surface miners cut, crush and load rock in a single operation – a single machine completes the job of various different pieces of equipment.
<G-vec00389-002-s247><crush.zerkleinern><de> Surface Miner schneiden, zerkleinern und fördern das Gestein in einem Arbeitsgang – eine Maschine übernimmt die Arbeit verschiedener Geräte.
<G-vec00389-002-s248><crush.zerkleinern><en> Anavar is offered just in dental type; though, some guys choose to crush the tablet computers as well as mix it with a liquid which is not recommended, partially for purity sake and that it will certainly degrade in a liquid base.
<G-vec00389-002-s248><crush.zerkleinern><de> Anavar ist leicht verfügbar nur in mündlicher Art; Allerdings bevorzugen einige Leute, die Tabletten zu zerkleinern und es mit einer Flüssigkeit mischen, die nicht empfohlen wird, zum Teil für Reinheit willen, und dass es in einem Fluidboden brechen wird.
<G-vec00389-002-s249><crush.zerkleinern><en> They crush, clean, mix, separate and ferment raw materials, and they design plants that control these processes.
<G-vec00389-002-s249><crush.zerkleinern><de> Sie zerkleinern, reinigen, mischen, trennen und fermentieren Rohstoffe und sie entwerfen Anlagen, die diese Prozesse steuern.
<G-vec00389-002-s250><crush.zerkleinern><en> Crush the biscuits and mix with the melted butter.
<G-vec00389-002-s250><crush.zerkleinern><de> Die Kekse zerkleinern und die geschmolzene Butter dazu geben.
<G-vec00389-002-s251><crush.zerkleinern><en> The Intelli-Speed Motor Control senses contents and keeps optimal speed to efficiently crush ice cubes, purée soft fruits, blend frozen smoothies, and create everything from fresh and hot soups to sauces and salad dressings.
<G-vec00389-002-s251><crush.zerkleinern><de> Die Intelli-Speed-Motorsteuerung erkennt den Inhalt und passt die Geschwindigkeit optimal an – für ein gründliches Zerkleinern von Eis, Pürieren von weichem Obst, Mixen von gefrorenen Smoothies und alle anderen Rezeptideen von frischen und heißen Suppen bis hin zu Soßen und Salatdressings.
<G-vec00389-002-s252><crush.zerkleinern><en> After dried, it is not necessary to crush, sieve.
<G-vec00389-002-s252><crush.zerkleinern><de> Nach dem Trocknen ist es nicht erforderlich, das Sieb zu zerkleinern.
<G-vec00389-002-s253><crush.zerkleinern><en> Surface miners cut, crush and load rock in a single operation – a single machine completes the job of various different pieces of equipment.
<G-vec00389-002-s253><crush.zerkleinern><de> • Surface Miner schneiden, zerkleinern und fördern das Gestein in einem Arbeitsgang – eine Maschine übernimmt die Arbeit verschiedener Geräte.
<G-vec00389-002-s254><crush.zerkleinern><en> Put all ingredients in a powerful blender and crush until creamy.
<G-vec00389-002-s254><crush.zerkleinern><de> Alle Zutaten in einem leistungsstarken Mixer geben und cremig zerkleinern.
<G-vec00389-002-s255><crush.zermahlen><en> Put flaxseed in the blender and crush it.
<G-vec00389-002-s255><crush.zermahlen><de> Zubereitung Die Leinsamen im Mixer zermahlen.
<G-vec00389-002-s256><crush.zermahlen><en> Do not crush or chew before swallowing.
<G-vec00389-002-s256><crush.zermahlen><de> Nicht zermahlen oder kauen vor dem Schlucken.
<G-vec00389-002-s257><crush.zermahlen><en> The wildly popular Jamie Oliver Flavour Shaker, which allows cooks to quickly crush, mix, and extract flavor from whole spices for rubs and marinades, takes advantage of the GE resin’s heat resistance, transparency, durability, resistance to staining, and custom colorability.
<G-vec00389-002-s257><crush.zermahlen><de> Der äußerst beliebte Jamie Oliver Flavour Shaker, der Köchen ermöglicht, ganze Gewürze zum Einreiben und Marinieren von Speisen schnell zu zermahlen, zu mischen und ihr Aroma zu extrahieren, nutzt die Vorteile der Hitzefestigkeit, Transparenz, Haltbarkeit und Verfärbungsbeständigkeit sowie der individuellen Einfärbbarkeit des GE-Kunststoffs.
<G-vec00389-002-s258><crush.zermalmen><en> From: 45,00€ Horseback riding for beginners wanting to crush the body, all types of terrain, enjoying an unthinkable place that will surprise you with its diversity.
<G-vec00389-002-s258><crush.zermalmen><de> Route für Eingeweihte … die den Körper für alle Arten von Gelände zermalmen wollen und einen undenkbaren Ort genießen möchten, der Sie mit seiner Vielfalt überraschen wird, mit dem kanarischen Kiefernwäldern gekrönt und nur von einem Adler übertroffen, der mit dem Teide im Hintergrund über dem spektakulären Wolkenmeer fliegt.
<G-vec00389-002-s259><crush.zermalmen><en> 4 He will defend the afflicted among the people and save the children of the needy; he will crush the oppressor.
<G-vec00389-002-s259><crush.zermalmen><de> Er wird das elende Volk bei Recht erhalten und den Armen helfen und die Lästerer zermalmen.
<G-vec00389-002-s260><crush.zermalmen><en> The CCP used tanks to crush those young students who were protesting corruption.
<G-vec00389-002-s260><crush.zermalmen><de> Die KPC setzte Panzer ein, um diese jungen Studenten zu zermalmen, die gegen die Korruption protestierten.
<G-vec00389-002-s261><crush.zermalmen><en> Then they decide to hack the system and make their own rates to crush the crap and help better programmes along.
<G-vec00389-002-s261><crush.zermalmen><de> Dann entscheiden sie sich dazu, das System zu hacken und ihre eigenen Quoten zu machen, um den Murks zu zermalmen und besseren Programmen auf die Sprünge zu helfen.
<G-vec00389-002-s262><crush.zermalmen><en> The blows following one another in mere seconds crush the boiled bones until the catchment trough contains nothing but meal.
<G-vec00389-002-s262><crush.zermalmen><de> Die Schläge im Sekundentakt zermalmen die ausgekochten Knochen, bis in den Eisentrögen nur noch Mehl bleibt.
<G-vec00389-002-s263><crush.zermalmen><en> 15 “See, I will make you into a threshing sledge, new and sharp, with many teeth. You will thresh the mountains and crush them, and reduce the hills to chaff.
<G-vec00389-002-s263><crush.zermalmen><de> 15 Sieh, ich mache dich zum Dreschschlitten, schneidend scharf, neu, mit Klingen, Berge wirst du dreschen und zermalmen, und Hügel wirst du machen wie Spreu.
<G-vec00389-002-s264><crush.zermalmen><en> Dan 2,40 And there shall be a fourth kingdom, strong as iron, because iron breaks to pieces and shatters all things; and like iron which crushes, it shall break and crush all these.
<G-vec00389-002-s264><crush.zermalmen><de> Dan 2,40 Und das vierte wird hart sein wie Eisen; denn wie Eisen alles zermalmt und zerschlägt, ja, wie Eisen alles zerbricht, so wird es auch alles zermalmen und zerbrechen.
<G-vec00389-002-s265><crush.zermalmen><en> Towards the unity of man and all living things, towards the unity of God and of the world.”[10] To achieve this perfect world, it is thus necessary to mix, crush, dissolve all national resistances and ethnic or religious identities.
<G-vec00389-002-s265><crush.zermalmen><de> Nach Einigung zwischen dem Menschen und allen Lebenwesen, nach Einigung von Gott mit der Welt.“ (8) Um diese perfekte Welt zu erreichen, ist es notwendig, alle nationalen Widerstände und alle ethnischen oder religiösen Identitäten zu zermalmen, zu zerstrampeln und zu zersetzen.
<G-vec00389-002-s266><crush.zermalmen><en> 44 And ithe one who falls on this stone will be broken to pieces; and jwhen it falls on anyone, it will crush him.”5
<G-vec00389-002-s266><crush.zermalmen><de> 18 Wer auf diesen Stein fällt, der wird zerschellen; auf wen er aber fällt, den wird er zermalmen.
<G-vec00389-002-s267><crush.zermalmen><en> The wheels of The Chariot often crush what should have remained unharmed.
<G-vec00389-002-s267><crush.zermalmen><de> Oft zermalmen die Räder des Wagen, was besser heil geblieben wäre.
<G-vec00389-002-s268><crush.zermalmen><en> (44) And in the days of these kings, the God of Heaven shall set up a kingdom which shall never be destroyed. And the kingdom shall not be left to other peoples, but it shall crush and destroy all these kingdoms, and it shall stand forever.
<G-vec00389-002-s268><crush.zermalmen><de> (44) Aber in den Tagen jener Könige wird der Gott des Himmels ein Königreich aufrichten, das in Ewigkeit nicht untergehen wird; und sein Reich wird keinem anderen Volk überlassen werden; es wird alle jene Königreiche zermalmen und ihnen ein Ende machen; es selbst aber wird in Ewigkeit bestehen.
<G-vec00389-002-s269><crush.zermalmen><en> It shall crush and shatter all things like iron.
<G-vec00389-002-s269><crush.zermalmen><de> Es wird wie Eisen alles zermalmen und zerschlagen.
<G-vec00389-002-s270><crush.zermalmen><en> They continue to break down all walls and crush them to dust, just like in their debut album. They deliver brutal thrash metal in its purest form, and of course the trademark features of Testament that fans have come to expect.
<G-vec00389-002-s270><crush.zermalmen><de> Wie schon zu ihren Anfangszeiten reißen sie ohne Kompromisse alle Mauern und Wände ein und zermalmen sie zu Staub, sie liefern ungebrochenen und brutalen Thrash-Metal in seiner reinsten Form, natürlich kommen dabei die typischen Testament-Trademarks nicht zu kurz.
<G-vec00389-002-s271><crush.zermalmen><en> Let his brain relax but for an instant, and the cage would fly up and shatter the wheels, break the rope, crush the men, bring all the work of the mine to a stand-still.
<G-vec00389-002-s271><crush.zermalmen><de> Lässt sein Gehirn nur einen Augenblick den Dienst versagen, der Fahrstuhl wird in die Höhe gegen die Welle fliegen, dieselbe zertrümmern, die Seile zerreissen, die Menschen zermalmen und alle Arbeit in der Mine zum Stillstand bringen.
<G-vec00389-002-s272><crush.zermalmen><en> 15And I will put enmity between thee and the woman, and between thy seed and her seed; he shall crush thy head, and thou shalt crush his heel.
<G-vec00389-002-s272><crush.zermalmen><de> 15 Und ich werde Feindschaft setzen zwischen dir und der Frau, zwischen deinem Samen und ihrem Samen; er wird dir den Kopf zermalmen, und du, du wirst ihm die Ferse zermalmen.
<G-vec00389-002-s275><crush.zerquetschen><en> I crush ice, grind flour weekly
<G-vec00389-002-s275><crush.zerquetschen><de> Ich zerquetsche Eis, mahle wöchentlich Mehl.
<G-vec00389-002-s276><crush.zerquetschen><en> Collect coins and crush cars and objects.
<G-vec00389-002-s276><crush.zerquetschen><de> Sammle Münzen und zerquetsche Hindernisse.
<G-vec00389-002-s277><crush.zerquetschen><en> Place them in a bowl and, using a fork or masher, crush the tomatoes.
<G-vec00389-002-s277><crush.zerquetschen><de> Leg sie in eine Schüssel und zerquetsche sie mit einer Gabel oder einem Stampfer.
<G-vec00389-002-s278><crush.zerquetschen><en> I sit down on her appreciative with my sexy tightbutt and crush her.
<G-vec00389-002-s278><crush.zerquetschen><de> Ich setze mich mit meinem prallen heißen Strumpfhosenarsch genüßlich auf sie und zerquetsche sie.
<G-vec00389-002-s279><crush.zerquetschen><en> I crush it with my chop and my soles.
<G-vec00389-002-s279><crush.zerquetschen><de> Ich zerquetsche alles mit meinen Hacken und meinen Sohlen.
<G-vec00389-002-s280><crush.zerquetschen><en> Shake, crush, transform and match your way through hundreds of fun levels in this delicious puzzle adventure.
<G-vec00389-002-s280><crush.zerquetschen><de> Schüttele, zerquetsche, verwandle und verbinde deinen Weg durch hunderte spaßige Levels in diesem köstlichen Puzzle Abenteuer.
<G-vec00389-002-s281><crush.zerquetschen><en> If you have whole meat, then crush it to the state of minced meat.
<G-vec00389-002-s281><crush.zerquetschen><de> Wenn du ganzes Fleisch hast, dann zerquetsche es in den Zustand der Füllung.
<G-vec00389-002-s301><crush.zerschlagen><en> But the regime has not been able to crush the movement of workers, peasants and youth.
<G-vec00389-002-s301><crush.zerschlagen><de> Es gelang dem Regime nicht, die Bewegung der ArbeiterInnen, Bauern und Jugend zu zerschlagen.
<G-vec00389-002-s302><crush.zerschlagen><en> With no regard for losses and a swath of devastation, they crush a net of intrigues: there is much more about the production of mediaproductions Contact in Hamburg
<G-vec00389-002-s302><crush.zerschlagen><de> Ohne Rücksicht auf Verluste und eine Schneise der Verwüstung nach sich ziehend, zerschlagen sie ein Netz aus Intrigen: Denn hinter der Entführung steckt viel mehr als eine bloße Lösegeldforderung.
<G-vec00389-002-s303><crush.zerschlagen><en> Right-wing nationalist groups despised it as an unfair and oppressive diktat, designed to crush and humiliate Germany.
<G-vec00389-002-s303><crush.zerschlagen><de> Rechtsnationalistische Gruppen verachteten es als unfair und bedrückend Diktat, entworfen, um Deutschland zu zerschlagen und zu demütigen.
<G-vec00389-002-s304><crush.zerschlagen><en> The soil in which the Nazis grew was that of an imperialist power that had been defeated in World War I and faced the challenge of an insurgent working class the rulers had to crush.
<G-vec00389-002-s304><crush.zerschlagen><de> Der Grund für das Anwachsen der Nazis war eine imperialistische Macht, die im Ersten Weltkrieg besiegt worden war und deren Herrscher mit einer rebellischen Arbeiterklasse konfrontiert waren, die sie zerschlagen mussten.
<G-vec00389-002-s305><crush.zerschlagen><en> To promote this programme he and before him the Danish social Democrats – and now every politician in the world are using Muslim immigration to crush the national states and Christian religion.
<G-vec00389-002-s305><crush.zerschlagen><de> Um dieses Programm zu fördern benutzte er – und vor ihm die dänischen Sozialdemokraten - und jetzt jeder Politiker der Welt die muslimische Einwanderung, um die Nationalstaaten und die christliche Religion zu zerschlagen.
<G-vec00389-002-s306><crush.zerschlagen><en> But it was the will of the Lord to crush him with infirmity.
<G-vec00389-002-s306><crush.zerschlagen><de> 10 So wollte ihn der HERR zerschlagen mit Krankheit.
<G-vec00389-002-s307><crush.zerschlagen><en> Since iron crushes and smashes all things; and as the iron that shatters all these, it will crush and shatter.
<G-vec00389-002-s307><crush.zerschlagen><de> Wie zerschmetterndes Eisen wird es sie alle zerschlagen und zerschmettern.
<G-vec00389-002-s308><crush.zerschlagen><en> Their goal was not just to crush the opposing army but, if possible, to bring about its disintegration.
<G-vec00389-002-s308><crush.zerschlagen><de> Ihr Ziel war es nicht nur, die gegnerische Armee zu zerschlagen, sondern, wenn möglich, ihren Zerfall herbeizuführen.
<G-vec00389-002-s309><crush.zerschlagen><en> But it suited the French emperor who sought to crush them separately. Retreat began.
<G-vec00389-002-s309><crush.zerschlagen><de> Aber es kam dem französischen Kaiser sehr zustatten, der strebte sie getrennt zu zerschlagen.
<G-vec00389-002-s310><crush.zerschlagen><en> The colonialist fascist regime walked out on the negotiation table in Imralı where Abdullah Öcalan is imprisoned, and started applying an outrageous massacre policy intensifying the colonialist war in Bakurê (Northern) Kurdistan, occupying Rojava starting from Jarablus, beating off the national independence referendum in Başurê (Southern) Kurdistan with warmongering in order to crush any kind of national statute or demands of national statute of Kurdish people, to pulverize and liquidate struggles aiming to get collective national rights, by completely breaking their will.
<G-vec00389-002-s310><crush.zerschlagen><de> Das kolonialistische faschistische Regime hat in Imrali, wo Abdullah Öcalan eingesperrt ist, den Verhandlungstisch umgeworfen und eine unbändige Blutpolitik eingeleitet, um den kolonialistischen Krieg in Bakurê (Norden) Kurdistan zu intensivieren, Rojava angefangen bei Jarablus zu besetzen und das Referendum für nationale Unabhängigkeit in Başurê (Süden) Kurdistan durch Kriegstreiberei zurückzuschlagen - alles mit dem Ziel jegliche Form eines nationalen Status und jegliche Forderung nach einer nationalen Status des kurdischen Volkes zu zerschlagen, jeglichen Kampf um kollektive nationale Rechte zu liquidieren, jeglichen Willen und jegliche Bestrebungen in diese Richtung zu brechen.
<G-vec00389-002-s311><crush.zerschlagen><en> Fight as the Finnish against an overwhelming threat, or play as the Soviets and crush the last Finnish defensive lines.
<G-vec00389-002-s311><crush.zerschlagen><de> Führen Sie die finnischen Streitkräfte gegen einen übermächtigen Feind aufs Feld oder befehligen Sie die Sowjets und zerschlagen Sie die letzten finnischen Verteidigungslinien inmitten eines unnachgiebigen nordischen Winters.
<G-vec00389-002-s312><crush.zerschlagen><en> During that memorable time the Carnegie Steel Company organized a conspiracy to crush the Amalgamated Association of Iron and Steel Workers.
<G-vec00389-002-s312><crush.zerschlagen><de> In dieser denkwürdigen Zeit wurde im Carnegie-Stahlwerk ein Komplott ausgeheckt, um den Zusammenschluss der Eisen- und Stahlwerker zu zerschlagen.
<G-vec00389-002-s313><crush.zerschlagen><en> In the end, however, the CCP was able to crush the strikes and ship many working-class activists off to labor camps.
<G-vec00389-002-s313><crush.zerschlagen><de> Am Ende war die KPCh jedoch in der Lage, den Streik zu zerschlagen und viele Aktivisten der Arbeiterklasse in Arbeitslager zu schicken.
<G-vec00389-002-s314><crush.zerschlagen><en> “Either the bureaucracy, becoming ever more the organ of the world bourgeoisie in the workers’ state, will overthrow the new forms of property and plunge the country back to capitalism; or the working-class will crush the bureaucracy and open the way to socialism.”
<G-vec00389-002-s314><crush.zerschlagen><de> Entweder wird die Bürokratie, die ja immer mehr zum Organ der Weltbourgeoisie im Arbeiterstaat wird, die neuen Eigentumsformen umstürzen und das Land in den Kapitalismus zurückwerfen, oder die Arbeiterklasse wird die Bürokratie zerschlagen und den Weg zum Sozialismus anbahnen.
<G-vec00389-002-s315><crush.zerschlagen><en> While China has yet to threaten sending in the army — as it did against pro-democracy protesters in Beijing in 1989 — the Shenzhen exercises were a sign of its ability to crush the demonstrations, even at the cost to Hong Kong's reputation as a safe haven for business and international exchange.
<G-vec00389-002-s315><crush.zerschlagen><de> Während China noch nicht mit dem Einsatz der Armee gedroht hat – wie 1989 gegen demokratiefördernde Demonstranten in Peking -, waren die Übungen in Shenzhen ein Zeichen seiner Fähigkeit, die Demonstrationen zu zerschlagen, selbst auf Kosten von Hongkongs Ruf als sicherer Hafen für Geschäfts- und internationaler Austausch.
<G-vec00389-002-s316><crush.zerschlagen><en> The Wehrmacht had planned to crush the resistance of the Soviet Border Guards in just 30 minutes, yet most of them held out for several days, allowing Soviet army units to prepare for the fight more properly.
<G-vec00389-002-s316><crush.zerschlagen><de> Die Wehrmacht wollte den Widerstand der sowjetischen Grenzwache in nur 30 Minuten zerschlagen, doch diese hielten mehrere Tage durch, damit sich die Armeeeinheiten besser auf den bevorstehenden Kampf vorbereiten konnten.
<G-vec00389-002-s317><crush.zerschlagen><en> In contrast, our Trotskyist international tendency fought in defense of the workers state, distributing tens of thousands of leaflets calling on Soviet workers to crush the counterrevolutionary forces led by Yeltsin and backed by the George H.W. Bush White House.
<G-vec00389-002-s317><crush.zerschlagen><de> Im Gegensatz dazu kämpfte unsere trotzkistische Internationale für die Verteidigung des Arbeiterstaats und verteilte Zehntausende von Flugblättern mit dem Aufruf an die sowjetischen Arbeiter, die konterrevolutionären Kräfte unter Führung Jelzins, unterstützt vom Weißen Haus George H. W. Bushs, zu zerschlagen.
<G-vec00389-002-s318><crush.zerschlagen><en> The conventional Stalinist and Social Democratic representation of Nazism and fascism as simply tools of the capitalist class, used to crush working class organizations, always omitted one of their central dimensions: These movements, in terms of their own self-understanding and their mass appeal, were revolts.
<G-vec00389-002-s318><crush.zerschlagen><de> Die konventionellen stalinistischen und sozialdemokratischen Darstellungen von Nazismus und Faschismus als Werkzeugen der Kapitalisten, benutzt um die Organisationen der Arbeiterklasse zu zerschlagen, unterschlugen schon immer eine ihrer zentralen Dimensionen: Diese Bewegungen, sowohl ihrem Selbstverständnis nach wie in ihrer Anziehungskraft für die Massen, waren Revolten.
<G-vec00389-002-s319><crush.zerschlagen><en> Crush your deck.
<G-vec00389-002-s319><crush.zerschlagen><de> Dein Deck zu zerschlagen.
<G-vec00389-002-s320><crush.zerschmettern><en> Fight against many opponents and crush strong bosses.
<G-vec00389-002-s320><crush.zerschmettern><de> Bekämpfe zahlreiche Feinde und zerschmettere starke Bosse.
<G-vec00389-002-s321><crush.zerschmettern><en> Mighty and Triumphant King, crush your enemies under your feet and liberate me and those I love from the oppressive attacks and the horrible consequences of sin.
<G-vec00389-002-s321><crush.zerschmettern><de> Mächtiger und triumphaler König, zerschmettere deine Feinde unter deinen Füßen und befreie mich und meine Lieben von den bedrückenden Angriffen und schrecklichen Folgen der Sünde.
<G-vec00389-002-s331><crush.zerstampfen><en> You can also use a mortar and pestle, if you have one, to crush tomatoes.
<G-vec00389-002-s331><crush.zerstampfen><de> Du kannst die Tomaten auch mit einem Mörtel und Stößel zerstampfen.
<G-vec00389-002-s332><crush.zerstampfen><en> Put them in a deep receptacle with the salt and the garlic and crush.
<G-vec00389-002-s332><crush.zerstampfen><de> Mit Salz und dem Knoblauch in ein tiefes Gefäß geben und zerstampfen.
<G-vec00389-002-s333><crush.zerstoßen><en> Crush the ice, and put it into the other beaker.
<G-vec00389-002-s333><crush.zerstoßen><de> Das Eis zerstoßen und in das zweite Becherglas füllen.
<G-vec00389-002-s334><crush.zerstoßen><en> Place graham crackers in a plastic bag and crush with a rolling pin until fine.
<G-vec00389-002-s334><crush.zerstoßen><de> Vollkorn-Butterkekse in einen Plastikbeutel legen und mit einem Nudelholz fein zerstoßen.
<G-vec00389-002-s335><crush.zerstören><en> Rail of WarGuide your loaded war train into battle and crush the occupying forces.
<G-vec00389-002-s335><crush.zerstören><de> Jetzt kaufen Für nur €6.99 Ähnliche Spiele Rail of WarFühre Schlachten und zerstöre den Feind, der dein Land erobern will.
<G-vec00389-002-s336><crush.zerstören><en> Crush the bloodthirsty zombies into pieces, and shoot them with the help of your huge arsenal.
<G-vec00389-002-s336><crush.zerstören><de> Zerstöre die blutrünstigen Zombies in Stücke und erschieße sie mit Hilfe deines riesigen Arsenals.
<G-vec00389-002-s337><crush.zerstören><en> Use an explosive arsenal of weapons against the enemies and also find the car and crush the remaining Stickman.
<G-vec00389-002-s337><crush.zerstören><de> Benutze ein explosives Waffenarsenal gegen die Feinde und finde das Auto und zerstöre den restlichen Stickman.
<G-vec00389-002-s346><crush.zertreten><en> I crush the little cream filled cake under my bare feet and make him lick and suck the crushed foot off my toes and foot soles.
<G-vec00389-002-s346><crush.zertreten><de> Ich zertrete das creme-gefüllte Teilchen mit meinen nackten Füßen und zwinge ihn dann es von meinen Zehen zu lutschen und von meinen Sohlen abzulecken.
<G-vec00389-002-s347><crush.zertreten><en> He want me to do crush all possible things.
<G-vec00389-002-s347><crush.zertreten><de> Er möchte, das ich alle möglichen Dinge zertrete.
<G-vec00389-002-s348><crush.zertreten><en> I drop some pieces on the floor and crush them under the soles of my ankle boots - then make the slave lick the banana mash from my boot soles.
<G-vec00389-002-s348><crush.zertreten><de> Ich lasse ein paar Stücke auf den Boden fallen und zertrete sie unter den Sohlen meiner Stiefeletten - dann muss er den Bananenmatsch von den Stiefelsohlen lecken.
<G-vec00389-002-s349><crush.zertreten><en> Dirty and worthless. I crush a banana until only porridge remains and if you are lucky you can lick it off my dirty feet.
<G-vec00389-002-s349><crush.zertreten><de> Ich zertrete eine Banane, bis nur noch Brei übrig bleibt - und wenn du Glück hast, darfst du den dann vielleicht noch von meinen dreckigen Füssen Heute habe ich mir für meinen treuen Sklaven etwas Besonderes ausgedacht.
<G-vec00389-002-s350><crush.zertreten><en> Virginia wouldn't believe me when I told her how I feed losers from my dirty shoe soles - so I'm going to show her:-D I grab a banana, break off a piece and throw it on the ground - then crush it under my boot sole and feed it to the slave.
<G-vec00389-002-s350><crush.zertreten><de> Virginia wollte mir nicht glauben, dass es tatsächlich Loser gibt, die von dreckigen Schuhsohlen fressen - also werde ich es ihr zeigen:-D Ich nehme eine Banane, breche ein Stück ab und schmeisse es auf den Boden - dann zertrete ich es unter meinen Stiefeln und verfüttere es an den Sklaven.
