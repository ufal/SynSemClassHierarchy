<G-vec00380-002-s036><divest.deinvestieren><en> Fossil Fuel investments are a risk for investors and the planet -– that’s why we’re calling on institutions to divest from these companies.
<G-vec00380-002-s036><divest.deinvestieren><de> Investitionen in Kohle, Öl und Gas sind ein Risiko für Investierende und den Planeten zugleich – deshalb rufen wir Institutionen dazu auf, aus den entsprechenden Unternehmen zu deinvestieren.
<G-vec00380-002-s034><divest.trennen><en> Your Excellency will acknowledge that there are certain original inherent rights belonging to the people, which the parliament itself cannot divest them of, consistent with their own constitution.
<G-vec00380-002-s034><divest.trennen><de> Ihre Exzellenz wird anerkennen, dass es bestimmte ursprüngliche Grundrechte des Volkes gibt, von denen das Parlament sie im Einklang mit ihrer eigenen Verfassung nicht trennen kann.
<G-vec00380-002-s025><divest.verschwenden><en> 4) wager only what you are able to manage to divest yourself of.
<G-vec00380-002-s025><divest.verschwenden><de> 4) Bet, was Sie in der Lage sind zu leisten, zu verschwenden.
<G-vec00380-002-s022><divest.veräußern><en> We felt it was urgent to divest those businesses we were not in a position to transform.
<G-vec00380-002-s022><divest.veräußern><de> Wir hielten es für dringend erforderlich, diese Geschäftsfelder, die keiner Transformation unterzogen werden konnten, zu veräußern.
