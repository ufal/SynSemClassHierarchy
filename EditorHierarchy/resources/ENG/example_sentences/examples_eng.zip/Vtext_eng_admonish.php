<G-vec00620-002-s003><admonish.ermahnen><en> In saying this Jesus did not mean that we cannot refer to what is bad as bad anymore, nor that we are not allowed to admonish a sinner.
<G-vec00620-002-s003><admonish.ermahnen><de> Jesus hat mit diesen Worten nicht gemeint, daß man das Falsche nicht mehr falsch nennen darf, auch nicht, daß man Sünder nicht ermahnen darf.
<G-vec00620-002-s004><admonish.ermahnen><en> Always more and more urgently I admonish you to change your attitude, which indeed does not need to be bad, but is adapted too earthly to be suitably for the spiritual kingdom.
<G-vec00620-002-s004><admonish.ermahnen><de> Immer dringender ermahne Ich euch zur Wandlung eurer Gesinnung, die zwar nicht schlecht zu sein braucht, doch zu irdisch eingestellt ist, um für das geistige Reich tauglich zu sein.
<G-vec00620-002-s005><admonish.ermahnen><en> “I admonish and encourage you.
<G-vec00620-002-s005><admonish.ermahnen><de> “Ich ermahne und ermutige euch.
<G-vec00620-002-s006><admonish.ermahnen><en> Admonish everyone moreover to observe prudence as ordained by Him, and in the Name of God advise them, saying: It behoveth every one in this Day of God to dedicate himself to the teaching of the Cause with utmost prudence and steadfastness.
<G-vec00620-002-s006><admonish.ermahnen><de> Ermahne einen jeden, Klugheit walten zu lassen, wie Er es verordnet hat, und im Namen Gottes rate ihnen mit den Worten: Es obliegt an diesem Tage Gottes jedermann, sich mit äußerster Klugheit und Standhaftigkeit dem Lehren der Sache Gottes zu widmen.
<G-vec00620-002-s007><admonish.ermahnen><en> And time and again I admonish you to love, because only love will awaken the spirit within you to life so that it can manifest itself.
<G-vec00620-002-s007><admonish.ermahnen><de> Und immer wieder ermahne Ich euch zur Liebe, weil nur durch die Liebe der Geist in euch erweckt wird zum Leben, daß er sich nun auch äußern kann.
<G-vec00620-002-s008><admonish.ermahnen><en> And thus, in view of the near end I admonish you all to make every effort to improve your soul.
<G-vec00620-002-s008><admonish.ermahnen><de> Und darum ermahne Ich euch alle, in Anbetracht des nahen Endes noch eifrig an eurer Seele zu arbeiten.
<G-vec00620-002-s009><admonish.ermahnen><en> I admonish you: Those I call are not those who have not been corrupted, but those I choose are those who truly love Me.
<G-vec00620-002-s009><admonish.ermahnen><de> Ich ermahne euch: Diejenigen, die Ich zu Mir rufe, sind nicht die, die niemals verdorben wurden, vielmehr sind diejenigen, die Ich auswähle, die, die Mich wirklich lieben.
<G-vec00620-002-s010><admonish.ermahnen><en> 14Not [as] putting you to shame do I write these things, but as my beloved children I do admonish,
<G-vec00620-002-s010><admonish.ermahnen><de> 14Nicht euch zu beschämen schreibe ich dieses, sondern ich ermahne euch als meine geliebten Kinder.
<G-vec00620-002-s011><admonish.ermahnen><en> Yet continue to admonish: for admonition profiteth the true believers.
<G-vec00620-002-s011><admonish.ermahnen><de> Doch fahre fort, (sie) zu ermahnen; denn die Ermahnung nützt den Gläubigen.
<G-vec00620-002-s012><admonish.ermahnen><en> Admonish and educate is the responsibility of husband.
<G-vec00620-002-s012><admonish.ermahnen><de> Ermahnen und zu erziehen ist die Verantwortung des Mannes.
<G-vec00620-002-s013><admonish.ermahnen><en> He, too, will proclaim the imminent end and admonish people to expect it daily and hourly.
<G-vec00620-002-s013><admonish.ermahnen><de> Auch er wird das nahe Ende künden und die Menschen ermahnen, es täglich und stündlich zu erwarten.
<G-vec00620-002-s014><admonish.ermahnen><en> Nations, I said: I will come to admonish the nations and to give consolation to my children, the apostles and all nations.
<G-vec00620-002-s014><admonish.ermahnen><de> Völker, ich habe gesagt: Ich komme, die Völker zu ermahnen und meinen Kindern, den Aposteln und allen Völkern Trost zu spenden.
<G-vec00620-002-s015><admonish.ermahnen><en> 20:31 Wherefore watch ye, remembering that by the space of three years I ceased not to admonish every one night and day with tears.
<G-vec00620-002-s015><admonish.ermahnen><de> 20:31 Darum wacht und denkt daran, daß ich drei Jahre lang Nacht und Tag nicht aufgehört habe, einen jeden unter Tränen zu ermahnen.
<G-vec00620-002-s016><admonish.ermahnen><en> After all, church discipline (that is, the readiness to admonish brothers and sisters who sin, and in the case of their unwillingness to change, to separate from them) is a question of love and of the identity of the community.
<G-vec00620-002-s016><admonish.ermahnen><de> Letztlich ist die Gemeindezucht (das heißt, die Bereitschaft, sündige Geschwister zu ermahnen und bei mangelnder Bereitschaft zur Änderung, sich auch von ihnen zu trennen) eine Frage der Liebe und der Identität der Gemeinde.
<G-vec00620-002-s017><admonish.ermahnen><en> It’s going to grow because the shepherds and the sheep come together in intimate relationships in which they admonish the wayward, encourage the worried, hold up the weak, are long suffering with the wearisome and render loving goodness to the wicked.
<G-vec00620-002-s017><admonish.ermahnen><de> Sie wird wachsen, weil die Hirten und die Schafe eine enge Beziehung aufbauen und zusammenkommen, um die Abtrünnigen zu ermahnen, die Besorgten zu ermutigen, die Schwachen zu stützen, langmütig gegen die Ermüdenden zu sein und den Boshaften mit liebevoller Güte zu begegnen.
<G-vec00620-002-s018><admonish.ermahnen><en> It is our task to admonish those who err and to denounce the evil and injustice of certain ways of acting, for the sake of setting victims free and raising up those who have fallen.
<G-vec00620-002-s018><admonish.ermahnen><de> Unsere Aufgabe ist es, den zu ermahnen, der einen Fehler begeht, indem wir die Schlechtigkeit und Ungerechtigkeit gewisser Verhaltensweisen anprangern, mit dem Ziel, die Opfer zu befreien und den Gefallenen aufzuheben.
<G-vec00620-002-s019><admonish.ermahnen><en> 8wHear, O my people, while I admonish you!
<G-vec00620-002-s019><admonish.ermahnen><de> 9Höre, mein Volk, ich will dich ermahnen.
<G-vec00620-002-s020><admonish.ermahnen><en> "Since it is senseless to admonish producers, our parental task is to protect our children from an avalanche of things that are not age-appropriate and impede harmonious development," she said.
<G-vec00620-002-s020><admonish.ermahnen><de> "Da es sinnlos ist, Produzenten zu ermahnen, besteht unsere elterliche Aufgabe darin, unsere Kinder vor einer Lawine von Dingen zu schützen, die nicht altersgerecht sind und eine harmonische Entwicklung behindern", sagte sie.
<G-vec00620-002-s021><admonish.ermahnen><en> Yet Paul did not only direct his words to the preachers, but to all the church members, with the expectation that they mutually teach and admonish one another.
<G-vec00620-002-s021><admonish.ermahnen><de> Paulus richtet jedoch seine Worte nicht allein an die Prediger, sondern an alle Gemeindeglieder, damit sie sich gegenseitig lehren und ermahnen sollen.
<G-vec00620-002-s022><admonish.ermahnen><en> 16 Let the message of Christ dwell among you richly as you teach and admonish one another with all wisdom through psalms, hymns, and songs from the Spirit, singing to God with gratitude in your hearts.
<G-vec00620-002-s022><admonish.ermahnen><de> 16 Lasst das Wort des Christus reichlich in euch wohnen in aller Weisheit; lehrt und ermahnt einander und singt mit Psalmen und Lobgesängen und geistlichen Liedern dem Herrn lieblich in eurem Herzen.
<G-vec00620-002-s024><admonish.ermahnen><en> 2) Brothers and sisters who are there to help, comfort and admonish each other (ROMANS 14:19; COLOSSIANS 3:16).
<G-vec00620-002-s024><admonish.ermahnen><de> 2) Brüder und Schwestern, die da sind, um sich gegenseitig zu helfen, zu ermutigen und zu ermahnen (RÖMER 14:19; KOLOSSER 3:16).
<G-vec00620-002-s025><admonish.ermahnen><en> Whatever arises, you go, “No big deal.” Admonish yourself just that much, and it should be enough.
<G-vec00620-002-s025><admonish.ermahnen><de> Was immer aufkommt, erwidern Sie: „Keine große Sache.“ Ermahnen Sie sich selbst nur so weit, und es sollte genug sein.
<G-vec00620-002-s027><admonish.ermahnen><en> Let him admonish, instruct, deflect you away from poor manners.
<G-vec00620-002-s027><admonish.ermahnen><de> Laßt ihn euch ermahnen, belehren, wegführen von schlechten Umgangsformen.
<G-vec00620-002-s035><admonish.ermahnen><en> Holger Seitz had to admonish him again and again during the test games to be more alert during switching actions and to return to the game faster after lost duels.
<G-vec00620-002-s035><admonish.ermahnen><de> Holger Seitz musste ihn bei den Testspielen immer wieder ermahnen, bei Umschaltaktionen wacher zu sein und nach verlorenen Zweikämpfen schneller ins Spielgeschehen zurückzukehren.
<G-vec00620-002-s044><admonish.ermahnen><en> 8 Hear, O my people, while I admonish you!
<G-vec00620-002-s044><admonish.ermahnen><de> Höre, mein Volk, ich will dich ermahnen.
<G-vec00620-002-s028><admonish.mahnen><en> For I want to warn and admonish men of what is coming; I want to open every possibility to them to prepare themselves because it will come suddenly and unexpected also for the knowing.
<G-vec00620-002-s028><admonish.mahnen><de> Denn Ich will die Menschen warnen und mahnen vor dem Kommenden, Ich will ihnen jede Möglichkeit erschließen, sich vorzubereiten, weil es plötzlich und unerwartet kommen wird auch für die Wissenden.
<G-vec00620-002-s029><admonish.mahnen><en> We will not admonish web sites with which we are in competition or infringe our rights without having pointed out the illegality beforehand and given them the right to remedy the infringement.
<G-vec00620-002-s029><admonish.mahnen><de> Wir mahnen Webseiten, mit denen wir im Wettbewerb stehen oder die unsere Rechte verletzen, nicht ab, ohne diese vorher auf die Rechtswidrigkeit hingewiesen und ihnen insoweit Möglichkeit zur Beseitigung der Rechtswidrigkeit gegeben zu haben.
<G-vec00620-002-s030><admonish.mahnen><en> My call is the coaxing call of a good shepherd Who does not want to lose even one small sheep from His flock, and Who speaks Words of love to you in order to hold on to you, in order to warn and admonish you that you will not get entangled in the snares of the one who wants to steal you from Me.
<G-vec00620-002-s030><admonish.mahnen><de> Mein Ruf ist der Lockruf eines guten Hirten, Der nicht will, daß Ihm ein Schäflein aus Seiner Herde verlorengehe, und Der auch zu euch Worte der Liebe spricht, um euch zu halten, um euch zu warnen und zu mahnen, auf daß ihr nicht jenem in die Fallstricke geratet, der euch Mir entwenden will.
<G-vec00620-002-s031><admonish.mahnen><en> A Slovak proverb says: "Words admonish, examples move". Yes, dear Brothers and Sisters, you too, with the "style" of your Christian life, can make a great contribution to the evangelisation of today’s world and to the construction of a more just and more fraternal society.
<G-vec00620-002-s031><admonish.mahnen><de> Ein slowakisches Sprichwort sagt: »Worte mahnen, Vorbilder überzeugen.« Ja, liebe Brüder und Schwestern, durch den »Stil« eures christlichen Lebens könnt auch ihr einen bedeutsamen Beitrag leisten zur Evangelisierung der heutigen Welt und zum Aufbau einer gerechteren und brüderlicheren Gesellschaft.
<G-vec00620-002-s032><admonish.mahnen><en> Goblet: 7:160 All people of your kind (humankind), be a unity (community) in which you admonish yourselves through the teaching of the prophets to the truth,...
<G-vec00620-002-s032><admonish.mahnen><de> Kelch: 7:160 Seid alle Euresgleichen (Menschheit) eine Einigkeit (Gemeinschaft), die ihr euch selbst durch die Lehre der Propheten zur Wahrheit mahnt,...
<G-vec00620-002-s033><admonish.rügen><en> A regular person, going to work, to school or to college, or a person pursuing all different kinds of jobs around the city, can be recorded up to 300 times just in one day.3 In 2003, so-called Talking CCTV cameras were installed, for video surveillance with loud speakers through which security officers can admonish passers-by.
<G-vec00620-002-s033><admonish.rügen><de> Wer ganz normal zur Arbeit, zur Schule oder an die Uni geht, oder wer mehrere Erledigungen in der Stadt macht, wird innerhalb eines Tages bis zu 300 Mal aufgezeichnet.3 Seit 2003 installiert man sogenannte “sprechende Überwachungskameras”, wo zur Videoü-berwachung noch Lautsprecher dazukommen, mit denen Sicherheitsbeamte Passanten rügen können.
<G-vec00620-002-s036><admonish.vermahnen><en> 15 and do not esteem him as an enemy, but admonish him as a brother.
<G-vec00620-002-s036><admonish.vermahnen><de> 15 Doch haltet ihn nicht als einen Feind, sondern vermahnet ihn als einen Bruder.
<G-vec00620-002-s037><admonish.vermahnen><en> And we exhort you, brethren, admonish the disorderly, encourage the fainthearted, support the weak, be longsuffering toward all.
<G-vec00620-002-s037><admonish.vermahnen><de> Wir ermahnen aber euch, liebe Brüder, vermahnet die Ungezogenen, tröstet die Kleinmütigen, traget die Schwachen, seid geduldig gegen jedermann.
<G-vec00620-002-s039><admonish.vorwerfen><en> At the museum, I was working with a young generation of Germans, the inheritors of the guilt of the collective, and with a boss who might have had every right to admonish them for “their” sins.
<G-vec00620-002-s039><admonish.vorwerfen><de> Am Museum arbeitete ich mit einer jungen Generation von Deutschen zusammen, den Erben der Kollektivschuld, und mit einem Chef, der allen Grund gehabt hätte, ihnen „ihre“ Sünden vorzuwerfen.
<G-vec00620-002-s040><admonish.warnen><en> Nay, it is the Truth from thy Lord, that thou mayest admonish a people to whom no warner has come before thee: in order that they may be rightly guided.
<G-vec00620-002-s040><admonish.warnen><de> Nein, es ist die Wahrheit von deinem Herrn, auf daß du ein Volk warnen mögest, zu dem vor dir kein Warner gekommen ist, damit sie dem rechten Weg folgen mögen.
<G-vec00620-002-s043><admonish.zurechtweisen><en> 2Thessalonians 3/15 Yet count him not as an enemy, but admonish him as a brother.
<G-vec00620-002-s043><admonish.zurechtweisen><de> 2.Thessalonicher 3/15 und achtet ihn nicht als einen Feind, sondern weiset ihn zurecht als einen Bruder.
<G-vec00620-002-s045><admonish.zurechtweisen><en> Should bhikkhunīs — one, two, or three — who are followers and partisans of that bhikkhunī, say, "Do not, ladies, admonish that bhikkhunī in any way.
<G-vec00620-002-s045><admonish.zurechtweisen><de> Sollten Bhikkhunīs, eine, zwei, oder drei, welche Anhänger und Verfechter dieser Bhikkhunī sind, sagen: "Tut nicht, Damen, diese Bhikkhunī, in dieser Weise zurechtweisen.
