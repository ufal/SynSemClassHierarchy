<G-vec00919-002-s038><add_up.addieren><en> The EDATE function requires two values (also referred to as argument): the start date and the number of months that you want to add or subtract.
<G-vec00919-002-s038><add_up.addieren><de> Für die EDATUM-Funktion werden zwei Werte (auch als Argumente bezeichnet) benötigt: das Startdatum und die Anzahl der Monate, die Sie addieren oder subtrahieren möchten.
<G-vec00919-002-s039><add_up.addieren><en> To the product price it is to be add the delivery cost, which can vary depending on the chosen mode of delivery and/or the total cost of the order.
<G-vec00919-002-s039><add_up.addieren><de> Zum Produktpreis sind die Versandkosten zu addieren, die je nach gewählter Versandart und / oder Gesamtkosten der Bestellung variieren können.
<G-vec00919-002-s040><add_up.addieren><en> Next to the resulting number of panels add 10% when plating the square of the rectangular shape.
<G-vec00919-002-s040><add_up.addieren><de> Neben der resultierenden Anzahl von Paneelen addieren 10% beim Plattieren des Quadrats der rechteckigen Form.
<G-vec00919-002-s041><add_up.addieren><en> Customized size, material, color, and design, add your logo, meeting your unique jewellery.
<G-vec00919-002-s041><add_up.addieren><de> Kundengebundene Größe, Material, Farbe und Entwurf, addieren Ihr Logo und treffen Ihren einzigartigen Schmuck.
<G-vec00919-002-s042><add_up.addieren><en> Sometimes worker are not willing to add the oil everyday.
<G-vec00919-002-s042><add_up.addieren><de> Manchmal sind Arbeitskraft nicht bereit, das tägliche Öl zu addieren.
<G-vec00919-002-s043><add_up.addieren><en> And we do not need to add the oil manually.
<G-vec00919-002-s043><add_up.addieren><de> Und wir brauchen nicht, das Öl manuell zu addieren.
<G-vec00919-002-s044><add_up.addieren><en> We will add more material as we prepare it.
<G-vec00919-002-s044><add_up.addieren><de> Wir addieren mehr Material, wie wir es vorbereiten.
<G-vec00919-002-s045><add_up.addieren><en> Inns double the value of a road, while Cathedrals add a bonus point per city tile.
<G-vec00919-002-s045><add_up.addieren><de> Wirtshäuser verdoppeln den Wert von Straßen, Kathedralen addieren pro Stadtkarte einen Punkt.
<G-vec00919-002-s046><add_up.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00919-002-s046><add_up.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00919-002-s047><add_up.addieren><en> The calculator can add, subtract, multiply and divide.
<G-vec00919-002-s047><add_up.addieren><de> Die Rechenmaschine kann addieren, subtrahieren, dividieren und multiplizieren.
<G-vec00919-002-s048><add_up.addieren><en> Path combinations (Add/Subtract/Intersect/Exclude Overlap) are nondestructive.
<G-vec00919-002-s048><add_up.addieren><de> Pfadkombinationen (Addieren/Subtrahieren/Schnittmenge bilden/Überlappung ausschließen) sind nicht destruktiv.
<G-vec00919-002-s049><add_up.addieren><en> This year we add an grey board laminated machine, can process the grey board laminated with duplex board, black card and kraft paper.
<G-vec00919-002-s049><add_up.addieren><de> Dieses Jahr addieren wir eine Graupappe lamellierte Maschine, können die Graupappe verarbeiten, die mit Duplexbrett, schwarzer Karte und Kraftpapier lamelliert wird.
<G-vec00919-002-s050><add_up.addieren><en> It is also available to add new one.
<G-vec00919-002-s050><add_up.addieren><de> Es ist auch verfügbar, Neues zu addieren.
<G-vec00919-002-s051><add_up.addieren><en> The amounts of components A) and B) add up to at least about 75 wt .-%, preferably at least 90 wt .-%, in particular 100 wt .-%, based on the total weight of the composition.
<G-vec00919-002-s051><add_up.addieren><de> Die Mengen der Komponenten A) und B) addieren sich vorzugsweise zu mindestens 75 Gew.-%, bevorzugt zu mindestens 90 Gew.-%, insbesondere zu 100 Gew.-%, bezogen auf das Gesamtgewicht der Zusammensetzung.
<G-vec00919-002-s052><add_up.addieren><en> To add a specific subnet, right click in the list, select the Add network option and enter the specific details for that network.
<G-vec00919-002-s052><add_up.addieren><de> Um ein Subnetz hinzuzufügen, rechts klicken Sie in der Liste, selektieren Sie die Netzwerk addieren Option und geben die entsprechenden Daten für das Netz ein.
<G-vec00919-002-s053><add_up.addieren><en> We must never add, subtract or change the doctrine of Christ or to whom He gave authority to record His written word.
<G-vec00919-002-s053><add_up.addieren><de> Wir dürfen nie addieren, subtrahieren oder die Lehre von Christus oder zu denen er Vollmacht gab, seine geschriebene Wort aufzunehmen.
<G-vec00919-002-s054><add_up.addieren><en> FreeVIEW → Used by millions of people worldwide, Family Tree Builder helps you research your family history, build your family tree and add photos, historical records and more.
<G-vec00919-002-s054><add_up.addieren><de> Weltweit verwendet durch Millionen Leute, hilft Family Tree Builder Ihnen, Ihre Familiengeschichte zu erforschen, Ihren Stammbaum zu errichten und Fotos, historische Aufzeichnungen und mehr zu addieren.
<G-vec00919-002-s055><add_up.addieren><en> This is because the ropes themselves can add additional space.
<G-vec00919-002-s055><add_up.addieren><de> Dieses ist, weil die Seile selbst zusätzlichen Raum addieren können.
<G-vec00919-002-s056><add_up.addieren><en> The annual losses add up to billions and threaten the reputation, liquidity and credit capacity of your business.
<G-vec00919-002-s056><add_up.addieren><de> Die jährlichen Schäden addieren sich zu Milliarden und gefährden die Reputation, Liquidität und Kreditfähigkeit Ihres Unternehmens.
<G-vec00919-002-s133><add_up.dazugeben><en> Add the sundried tomatoes and stir to distribute evenly.
<G-vec00919-002-s133><add_up.dazugeben><de> Rasch einrühren und dann das restliche Wasser dazugeben und zu einen geschmeidigen Teig rühren.
<G-vec00919-002-s134><add_up.dazugeben><en> Add the other ingredients after turning.
<G-vec00919-002-s134><add_up.dazugeben><de> Nach dem Wenden die anderen Zutaten dazugeben.
<G-vec00919-002-s135><add_up.dazugeben><en> Gradually add the remaining broth.
<G-vec00919-002-s135><add_up.dazugeben><de> Die restliche Brühe nach und nach dazugeben.
<G-vec00919-002-s136><add_up.dazugeben><en> Add the eggs one after another and mix well in between.
<G-vec00919-002-s136><add_up.dazugeben><de> Die Eier einzeln dazugeben und jeweils gut unterrühren.
<G-vec00919-002-s137><add_up.dazugeben><en> Add the sour cream and mix until smooth.
<G-vec00919-002-s137><add_up.dazugeben><de> Den Schmand (sour cream) dazugeben und glattrühren.
<G-vec00919-002-s138><add_up.dazugeben><en> Mix the almonds with the sugar, add to the bowl and fold in.
<G-vec00919-002-s138><add_up.dazugeben><de> Die gemahlenen Mandeln mit dem Zucker vermischen und dann zur Schüssel dazugeben und kurz unterrühren.
<G-vec00919-002-s139><add_up.dazugeben><en> Add the fresh herbs and pomegranate seeds and mix well.
<G-vec00919-002-s139><add_up.dazugeben><de> Quorn Hack, Brotkrümel, verkopftes Ei und Petersilie dazugeben und untermischen.
<G-vec00919-002-s140><add_up.dazugeben><en> Continuing to whisk, add flour, baking powder, and cinnamon.
<G-vec00919-002-s140><add_up.dazugeben><de> Unter Rühren Mehl, Backpulver und Zimt dazugeben und verrühren.
<G-vec00919-002-s141><add_up.dazugeben><en> Add the espresso followed by the water to lower the alcohol content.
<G-vec00919-002-s141><add_up.dazugeben><de> Den Zucker im Espresso schmelzen und das Wasser dazugeben.
<G-vec00919-002-s142><add_up.dazugeben><en> Sift the confectioner's sugar and cocoa into a bowl, add cream cheese and mix well.
<G-vec00919-002-s142><add_up.dazugeben><de> Puderzucker und Kakao in eine Schüssel sieben, den Frischkäse dazugeben und gut verrühren - es sollte eine cremige Masse entstehen.
<G-vec00919-002-s143><add_up.dazugeben><en> Add the minced basil.
<G-vec00919-002-s143><add_up.dazugeben><de> Das gehackte Basilikum dazugeben.
<G-vec00919-002-s144><add_up.dazugeben><en> Add the herbs, garlic, salt and pepper and cook for another 5 minutes. Add the water and cook until it evaporates.
<G-vec00919-002-s144><add_up.dazugeben><de> Gewürze zufügen und noch einmal für 5 min braten, anschließend das Wasser dazugeben und kochen, bis es verdampft ist.
<G-vec00919-002-s145><add_up.dazugeben><en> Add the rice noodles and garnish your soup with fresh cilantro, fresh chili and add some more tamari or lime juice if you prefer.
<G-vec00919-002-s145><add_up.dazugeben><de> Nun die Reisnudeln dazugeben und die Suppe mit etwas frischem Koriander und frischen Chili oder Peperoni garnieren.
<G-vec00919-002-s146><add_up.dazugeben><en> Add the eggs and mix to combine.
<G-vec00919-002-s146><add_up.dazugeben><de> Die Joghurtmasse dazugeben und schnell zuzsammenschlagen.
<G-vec00919-002-s147><add_up.dazugeben><en> Grate the carrots very fine and add the sprouts and cabbage.
<G-vec00919-002-s147><add_up.dazugeben><de> Die Möhren sehr fein raspeln und den Rosenkohl und Kohl dazugeben.
<G-vec00919-002-s148><add_up.dazugeben><en> Clean the avocado, blend the pulp with extra virgin olive oil, chili, and lime juice and add the coffee.
<G-vec00919-002-s148><add_up.dazugeben><de> Die Avocado säubern, das Fruchtfleisch mit nativem Olivenöl, Chili und Limettensaft pürieren und den Kaffee dazugeben.
<G-vec00919-002-s149><add_up.dazugeben><en> The 2-nd glass of water and the salt add.
<G-vec00919-002-s149><add_up.dazugeben><de> Das 2.Glas Wasser und das Salz dazugeben.
<G-vec00919-002-s150><add_up.dazugeben><en> Finally, add the cooked mussels.
<G-vec00919-002-s150><add_up.dazugeben><de> Zuletzt die gekochten Muscheln dazugeben.
<G-vec00919-002-s151><add_up.dazugeben><en> Finally, add the drained mandarins with a little of the liquid and fold in.
<G-vec00919-002-s151><add_up.dazugeben><de> Zum Schluss die abgetropfen Mandarinen mit ein wenig von der Flüssigkeit dazugeben und unterheben.
<G-vec00919-002-s209><add_up.einfügen><en> Besides adding an audio file, you can also use Wondershare Filmora (originally Wondershare Video Editor) to record and add your own voiceover.
<G-vec00919-002-s209><add_up.einfügen><de> Neben dem Hinzufügen einer Audiodatei, können Sie mit Wondershare Filmora auch Ihre eigenen Voiceover aufnehmen und einfügen.
<G-vec00919-002-s210><add_up.einfügen><en> Yes, you can add playlists just like albums or songs to a Box.
<G-vec00919-002-s210><add_up.einfügen><de> Ja, du kannst Playlists genau wie Alben oder einzelne Songs in eine Box einfügen.
<G-vec00919-002-s211><add_up.einfügen><en> In the Add Field dialog box, type a name for your new field, and then click OK.
<G-vec00919-002-s211><add_up.einfügen><de> Klicken Sie im Dialogfeld Adressfeld einfügen auf die gewünschten Adresselemente, und klicken Sie dann auf OK.
<G-vec00919-002-s212><add_up.einfügen><en> To add Endpoint Management enterprise functionality to mobile apps, you wrap them with the MDX Toolkit.
<G-vec00919-002-s212><add_up.einfügen><de> Zum Einfügen von Endpoint Management-Unternehmensfunktionen werden mobile Apps mit dem MDX Toolkit umschlossen.
<G-vec00919-002-s213><add_up.einfügen><en> If you are editing a wiki page or a publishing page, click an editable area of the page where you want to add the Content Query Web Part.
<G-vec00919-002-s213><add_up.einfügen><de> Wenn Sie eine Wiki-Seite oder eine Veröffentlichungsseite bearbeiten, klicken Sie an einer bearbeitbaren Position auf der Seite, an der Sie das Webpart für Inhaltsabfragen einfügen möchten.
<G-vec00919-002-s214><add_up.einfügen><en> We would like to add a litte logo like the one you can see on the right to a number of images.
<G-vec00919-002-s214><add_up.einfügen><de> Wir würden gern ein kleines Logo, wie du es rechts sehen kannst, in eine Anzahl von Bildern einfügen.
<G-vec00919-002-s215><add_up.einfügen><en> Enter the Re number, the measured coefficients cl und cd, and the corresponding angle of attack alpha in the edit fields below the list. Then click on 'Add' to have the data assigned to the list.
<G-vec00919-002-s215><add_up.einfügen><de> Trage die Re-Zahl, die gemessenen Beiwerte ca und cw und den jeweiligen Anstellwinkel alpha in die Eingabefelder unter der Liste ein und klicke auf 'Einfügen', um sie in die Liste zu übertragen.
<G-vec00919-002-s216><add_up.einfügen><en> Also, you can add own additions to the privacy policy with this plugin which are kept by an update of the plugin.
<G-vec00919-002-s216><add_up.einfügen><de> Außerdem kannst du über dieses Plugin eigene Abschnitte einfügen, welche auch bei einem Update der Datenschutzerklärung bestehen bleiben.
<G-vec00919-002-s217><add_up.einfügen><en> To add a new field, click on the relevant form and choose the type of field you would like to add on a form panel, opened next to the text editor toolbar
<G-vec00919-002-s217><add_up.einfügen><de> Um ein neues Feld einzufügen, klicken Sie auf das betreffende Formular und wählen Sie den Feldtyp, den Sie einfügen möchten, aus der Formularanzeige, die sich neben dem Texteditorfeld öffnet.
<G-vec00919-002-s218><add_up.einfügen><en> You could add, for example, a second therapist’s availability to the schedule.
<G-vec00919-002-s218><add_up.einfügen><de> Du kannst beispielsweise die Verfügbarkeit eines zweiten Therapeuten in demselben Kalender einfügen.
<G-vec00919-002-s219><add_up.einfügen><en> When you're modifying the Touch Bar, the icon (Space) indicates an empty slot where you can add a command.
<G-vec00919-002-s219><add_up.einfügen><de> Wenn Sie die Touch Bar ändern, bezeichnet das Symbol eine freie Stelle, an der Sie einen Befehl einfügen können.
<G-vec00919-002-s220><add_up.einfügen><en> With the Coupa app, you can use voice entry to add expense lines, take photos to capture receipts, and submit your expense report without ever opening your laptop.
<G-vec00919-002-s220><add_up.einfügen><de> Mit der Coupa-App können Sie sprachgesteuert zusätzliche Reisekosten-Positionen ergänzen, fotografierte Quittungen einfügen und Ihre Abrechnung ohne Laptop absenden.
<G-vec00919-002-s221><add_up.einfügen><en> add background music easily.
<G-vec00919-002-s221><add_up.einfügen><de> Hintergrundmusik einfügen.
<G-vec00919-002-s222><add_up.einfügen><en> Everyone can create a profile on gigmit and link it with their social media profiles, add their own songs and videos and use the gigmit Artist Page as their Electronic Press Kit.
<G-vec00919-002-s222><add_up.einfügen><de> Jeder kann sich ein Profil bei gigmit anlegen und seine Social Media Profile verknüpfen, Songs und Videos einfügen und die gigmit Artist Page als sein eigenes Electronic Press Kit nutzen.
<G-vec00919-002-s223><add_up.einfügen><en> You can add a different time tag right next to the original one so that you don't have to type it twice.
<G-vec00919-002-s223><add_up.einfügen><de> Du kannst einen anderen Zeit-Tag rechts neben dem Originalen einfügen, damit du ihn nicht zweimal eingeben musst.
<G-vec00919-002-s224><add_up.einfügen><en> In Step 4 of the Email Creation Process, go to the block where you would like to add your Flickr image.
<G-vec00919-002-s224><add_up.einfügen><de> Im Schritt 4 des E-Mail Erstellungs-Vorgang, gehen Sie auf den Block wo Sie das Flickr Bild einfügen wollen.
<G-vec00919-002-s225><add_up.einfügen><en> You can then add a comment on the right side of the app pane.
<G-vec00919-002-s225><add_up.einfügen><de> Anschließend können Sie auf der rechten Seite des App-Fensters einen Kommentar einfügen.
<G-vec00919-002-s226><add_up.einfügen><en> Subsequently I have to assemble the films, add music and label it; this is a job again.
<G-vec00919-002-s226><add_up.einfügen><de> Nachher muss ich dafür die Filme zusammenstellen, Musik einfügen und beschriften, das ist auch wieder eine Arbeit für sich.
<G-vec00919-002-s227><add_up.einfügen><en> The rectangle/square and ellipse/circle tools allow you to add mark-up or simple drawings to your documents.
<G-vec00919-002-s227><add_up.einfügen><de> Mit den Werkzeugen Rechteck/Quadrat und Ellipse/Kreis können Sie Hervorhebungen oder einfache Skizzen in Dokumente einfügen.
<G-vec00919-002-s095><add_up.hinzufügen><en> You can add another document for the device Dell SE400 Network Hardware.
<G-vec00919-002-s095><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Accton Technology Network Hardware EH2041S Netzwerkgerät hinzufügen.
<G-vec00919-002-s096><add_up.hinzufügen><en> Now add rosewater and mix until a soft, but not stick paste has formed.
<G-vec00919-002-s096><add_up.hinzufügen><de> Nun das Rosenwasser hinzufügen und weitermixen, bis ein weiches, aber nicht klebriges Marzipan entstanden ist.
<G-vec00919-002-s097><add_up.hinzufügen><en> You can add another document for the device Creda 5kg Clothes Dryer.
<G-vec00919-002-s097><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Creda 5kg Kleiderföhn hinzufügen.
<G-vec00919-002-s098><add_up.hinzufügen><en> You can add another document for the device Whirlpool Side By Side Refrigerator 7GS6SHAXKB01 Refrigerator.
<G-vec00919-002-s098><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Whirlpool Side By Side Refrigerator ED2YHGXLT01 Kühlschrank hinzufügen.
<G-vec00919-002-s099><add_up.hinzufügen><en> Please see example in GuiXT tutorial 6 Add images.
<G-vec00919-002-s099><add_up.hinzufügen><de> Vergleichen Sie hierzu das GuiXT Tutorial 6 Abbildungen hinzufügen.
<G-vec00919-002-s100><add_up.hinzufügen><en> You can add another document for the device Dell XPS TM373 Laptop.
<G-vec00919-002-s100><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Dell XPS TM373 Laptop hinzufügen.
<G-vec00919-002-s101><add_up.hinzufügen><en> You can add another document for the device Xerox CX PRINT SERVER 560 All in One Printer.
<G-vec00919-002-s101><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Xerox CX PRINT SERVER 560 Multifunktionsgerät hinzufügen.
<G-vec00919-002-s102><add_up.hinzufügen><en> You can add another document for the device Whirlpool Refrigerator GD5SHAXMQ00 Refrigerator.
<G-vec00919-002-s102><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Whirlpool Refrigerator GD5SHAXMQ00 Kühlschrank hinzufügen.
<G-vec00919-002-s103><add_up.hinzufügen><en> You can add another document for the device Motorola TIMEPORT 270c Cell Phone.
<G-vec00919-002-s103><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Motorola TIMEPORT 270c Handy hinzufügen.
<G-vec00919-002-s104><add_up.hinzufügen><en> You can add another document for the device Sony Ericsson walkman W980 Cell Phone.
<G-vec00919-002-s104><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Sony Ericsson walkman W980 Handy hinzufügen.
<G-vec00919-002-s105><add_up.hinzufügen><en> You can add another document for the device Sony Flat Panel Television FWD-42PV Flat Panel Television.
<G-vec00919-002-s105><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Sony Flat Panel Television FWD-42PV Flachfernseher hinzufügen.
<G-vec00919-002-s106><add_up.hinzufügen><en> You can add another document for the device Diamond D662 Car Speaker.
<G-vec00919-002-s106><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Diamond D363I Lautsprecher hinzufügen.
<G-vec00919-002-s107><add_up.hinzufügen><en> You can add another document for the device Frigidaire 100BTU-25 Air Conditioner.
<G-vec00919-002-s107><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Frigidaire 100BTU-25 Klimaanlage hinzufügen.
<G-vec00919-002-s108><add_up.hinzufügen><en> You can add another document for the device Beverage-Air VM7 Refrigerator.
<G-vec00919-002-s108><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Beverage-Air VM7 Kühlschrank hinzufügen.
<G-vec00919-002-s109><add_up.hinzufügen><en> You can add another document for the device Asus Barebone System RS720QE7RS12 Server.
<G-vec00919-002-s109><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Asus Barebone System ESC4000FDRG2 Server hinzufügen.
<G-vec00919-002-s110><add_up.hinzufügen><en> You can add another document for the device Whirlpool Refrigerator ED5PBAXVQ00 Refrigerator.
<G-vec00919-002-s110><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Whirlpool Refrigerator ED5PBAXVQ00 Kühlschrank hinzufügen.
<G-vec00919-002-s111><add_up.hinzufügen><en> Once you have changed the Marriage Tag Type to add these roles, you can not only use it for new marriages you enter, but you can also go back to existing Marriage tags and apply the new roles to them as well
<G-vec00919-002-s111><add_up.hinzufügen><de> Sobald Sie den Elementtyp "Heirat" über das Hinzufügen dieser Funktionen verändert haben, können Sie hiervon nicht nur für neue Eheschließungen, die Sie erfassen, Gebrauch machen, sondern Sie können vielmehr auch zu bereits vorhandenen Heirats-Elementen "zurückgehen" und auch bei diesen die neu erstellten Funktionen anwenden.
<G-vec00919-002-s112><add_up.hinzufügen><en> They can then add cash expenses, driving expenses and per diem allowances in local and foreign currency.
<G-vec00919-002-s112><add_up.hinzufügen><de> Möglich ist auch das Hinzufügen von Barauslagen, Fahrspesen und Pauschalen in lokaler und ausländischer Währung.
<G-vec00919-002-s113><add_up.hinzufügen><en> You can add another document for the device Samsung Eternity II SGH-A597 Cell Phone.
<G-vec00919-002-s113><add_up.hinzufügen><de> Sie können das nächste Dokument für das Gerät Samsung Eternity II SGH-A597 Handy hinzufügen.
<G-vec00919-002-s266><add_up.hinzufügen><en> Webmaster: Add your Site to our list FOR FREE for a lot of new visitors.
<G-vec00919-002-s266><add_up.hinzufügen><de> Füge deinen Link KOSTENLOS zu unserer Sammlung hinzu für viele neue Besucher.
<G-vec00919-002-s267><add_up.hinzufügen><en> Add 1 teaspoon of borax.
<G-vec00919-002-s267><add_up.hinzufügen><de> Füge einen Teelöffel Borax hinzu.
<G-vec00919-002-s268><add_up.hinzufügen><en> I enjoy adding killer drills to make the workshops sweat then add challenging dance movement exercises, to add speed and precision to a dancer’s vocabulary.
<G-vec00919-002-s268><add_up.hinzufügen><de> Ich liebe mörderischen Drill, damit meine Kurse so richtig ins Schwitzen kommen, und füge auch gern ein paar herausfordernde Tanzübungen hinzu, damit meine Schülerinnen sich einprägen, was Tempo und Präzision im Tänzerinnen-Vokabular bedeuten.
<G-vec00919-002-s269><add_up.hinzufügen><en> Add your team name, player name and player number.
<G-vec00919-002-s269><add_up.hinzufügen><de> Füge deinen Teamnamen, Spielerinitialien, Sponsorlogo und Teamkrone hinzu.
<G-vec00919-002-s270><add_up.hinzufügen><en> Add comments about questions or other answers to their respective comment sections, not as a new answer.
<G-vec00919-002-s270><add_up.hinzufügen><de> Füge Kommentare zu Fragen oder anderen Antworten im Kommentarbereich hinzu, nicht als neue Antwort.
<G-vec00919-002-s271><add_up.hinzufügen><en> Top 100 servers hosted in Canada, add your Unturned server and advertise with us.
<G-vec00919-002-s271><add_up.hinzufügen><de> Top 100 Server die in Canada gehostet werden, füge Deinen Unturned Server hinzu und mach Werbung bei uns.
<G-vec00919-002-s272><add_up.hinzufügen><en> do like to add touches of reality to my fiction, but in the end my stories are born purely from my imagination.
<G-vec00919-002-s272><add_up.hinzufügen><de> Ich füge meiner Fiktion gern etwas Realität hinzu, aber am Ende sind meine Geschichten rein aus meiner Vorstellung geboren.
<G-vec00919-002-s273><add_up.hinzufügen><en> 4 Add the grounds.
<G-vec00919-002-s273><add_up.hinzufügen><de> 4 Füge den gemahlenen Kaffee hinzu.
<G-vec00919-002-s274><add_up.hinzufügen><en> Add specific AK 47 flavor and aroma to all kinds of oils, herbal extractions, and resins.
<G-vec00919-002-s274><add_up.hinzufügen><de> Füge allen Arten von Ölen, Kräuterextrakten und Harzen spezifisches Chemdawg 4 Aroma und Aroma hinzu.
<G-vec00919-002-s275><add_up.hinzufügen><en> Top 100 private servers hosted in Israel, add your Conquer Online server and advertise with us.
<G-vec00919-002-s275><add_up.hinzufügen><de> Top 100 Privat Server die in Egypt gehostet werden, füge Deinen Conquer Online Server hinzu und mach Werbung bei uns.
<G-vec00919-002-s276><add_up.hinzufügen><en> Now, whenever you're discovering new books in blinks that you want to send to your Kindle, simply add them to your Blinkist library.
<G-vec00919-002-s276><add_up.hinzufügen><de> Wenn du nun neue Bücher entdeckst, welche du zum Kindle senden möchtest, füge sie einfach deiner Blinkist Bibliothek hinzu.
<G-vec00919-002-s277><add_up.hinzufügen><en> Add some hashtags.
<G-vec00919-002-s277><add_up.hinzufügen><de> Füge einige Hashtags hinzu.
<G-vec00919-002-s278><add_up.hinzufügen><en> Add any texts as a final touch.
<G-vec00919-002-s278><add_up.hinzufügen><de> Füge beliebige Texte als letzten Schliff hinzu.
<G-vec00919-002-s279><add_up.hinzufügen><en> I stir one tablespoon in my porridge every morning, or add it to soups, pasta sauces, or to energy balls.
<G-vec00919-002-s279><add_up.hinzufügen><de> Ich rühre morgens einen Esslöffel in mein Porridge, füge es zu Suppen hinzu, rühre es in Pasta-Saucen, oder mische es in Energiebälle.
<G-vec00919-002-s280><add_up.hinzufügen><en> Top 100 private servers hosted in Russia, add your OGame server and advertise with us.
<G-vec00919-002-s280><add_up.hinzufügen><de> Top 100 Privat Server die in Russia gehostet werden, füge Deinen OGame Server hinzu und mach Werbung bei uns.
<G-vec00919-002-s281><add_up.hinzufügen><en> Description Add features to your checkout item.
<G-vec00919-002-s281><add_up.hinzufügen><de> Beschreibung Füge in deinem Checkout Artikelmerkmale hinzu.
<G-vec00919-002-s282><add_up.hinzufügen><en> As this blend is fast absorbing, we recommend having it 30-60 minutes’ post-workout — add 1 sachet to water or milk, whichever you prefer.
<G-vec00919-002-s282><add_up.hinzufügen><de> Da diese Mischung schnell absorbiert wird, empfehlen wir 30-60 Minuten nach dem Training den Eiweißshake einzunehmen – füge je nach Belieben 1 Messlöffel (25 g) zu Wasser oder Milch hinzu.
<G-vec00919-002-s283><add_up.hinzufügen><en> You can discard 1 Spell; add 1 LIGHT Ritual Monster or 1 Ritual Spell from your Deck to your hand.
<G-vec00919-002-s283><add_up.hinzufügen><de> Du kannst 1 Zauber abwerfen; füge deiner Hand 1 LICHT Ritualmonster oder 1 Ritualzauber von deinem Deck hinzu.
<G-vec00919-002-s284><add_up.hinzufügen><en> Add Sav_09 as a friend
<G-vec00919-002-s284><add_up.hinzufügen><de> Füge Victor236 als Freund hinzu.
<G-vec00919-002-s304><add_up.hinzufügen><en> In Office 365, Group members typically create their own Groups, add themselves to Groups they want to join, or are invited by Group owners.
<G-vec00919-002-s304><add_up.hinzufügen><de> In Office 365 erstellen Gruppenmitglieder in der Regel ihre Gruppen selbst, fügen sich selbst zu Gruppen hinzu, an denen sie teilnehmen möchten, oder werden von anderen Gruppenbesitzern eingeladen.
<G-vec00919-002-s305><add_up.hinzufügen><en> You can also add information on Michelin restaurants, tourist attractions or hotels in Hörbranz or Dornbirn.
<G-vec00919-002-s305><add_up.hinzufügen><de> Fügen Sie Ihrem Routenplan Feldkirch - Dornbirn Informationen zu Restaurants, Sehenswürdigkeiten und Hotels in Dornbirn hinzu.
<G-vec00919-002-s306><add_up.hinzufügen><en> If we add another dimension, everyone can watch them in 3D on their smartphone with any virtual reality viewer like Google Cardboard, Samsung Gear VR and the like.
<G-vec00919-002-s306><add_up.hinzufügen><de> Fügen wir eine weitere Dimension hinzu, lassen sich Panoramen in 3D am Smartphone mit einem VR Headset wie Google Cardboard, Samsung Gear VR oder ähnlichen betrachten.
<G-vec00919-002-s307><add_up.hinzufügen><en> If you like, please add yourself as a fan – Thanks from your friends at WorldLingo.
<G-vec00919-002-s307><add_up.hinzufügen><de> Wenn Sie mögen, bitte fügen Sie sich als Ventilator hinzu - Dank von Ihren Freunden bei WorldLingo.
<G-vec00919-002-s308><add_up.hinzufügen><en> Then, we add a layer Mask and reduce the smoke significantly.
<G-vec00919-002-s308><add_up.hinzufügen><de> Wir fügen eine Ebenenmaske hinzu und schwächen den Rauch stark ab.
<G-vec00919-002-s309><add_up.hinzufügen><en> The event and its effects add something to the world, and this can change what is already constituted.
<G-vec00919-002-s309><add_up.hinzufügen><de> Das Ereignis und seine Effekte fügen der Welt etwas hinzu, und dieses Hinzugefügte kann eine Veränderung dessen bewirken, was bereits konstituiert ist.
<G-vec00919-002-s310><add_up.hinzufügen><en> By the way, we continuously update CopyTrans Contacts and add new features too.
<G-vec00919-002-s310><add_up.hinzufügen><de> Wir aktualisieren CopyTrans Contacts regelmäßig und fügen auch neue Funktionen hinzu.
<G-vec00919-002-s311><add_up.hinzufügen><en> Both respect traditional methods and utilize local products but add a contemporary, creative spin.
<G-vec00919-002-s311><add_up.hinzufügen><de> Beide respektieren traditionelle Methoden und nutzen lokale Produkte, fügen dem aber einen zeitgemäßen kreativen Dreh hinzu.
<G-vec00919-002-s312><add_up.hinzufügen><en> With a beautiful pair of diamond earrings, you add an elegant touch to any look.
<G-vec00919-002-s312><add_up.hinzufügen><de> Mit schönen Diamant-Ohrringen fügen Sie eine elegante Note zu jedem Look hinzu.
<G-vec00919-002-s313><add_up.hinzufügen><en> We offer over 300 game titles from four different operators and we add new games each month.
<G-vec00919-002-s313><add_up.hinzufügen><de> Wir bieten über 300 Spieltitel von vier verschiedenen Entwicklern und wir fügen ständig neue Spiele hinzu.
<G-vec00919-002-s314><add_up.hinzufügen><en> Change the colors, add your own photos and text to customize the layout for just about any business.
<G-vec00919-002-s314><add_up.hinzufügen><de> Ändern Sie die Farben, und fügen Sie eigene Fotos und Text hinzu, um das Layout für ein beliebiges Unternehmen anzupassen.
<G-vec00919-002-s315><add_up.hinzufügen><en> We still add the ending -ing to the semantic verb, and instead of one future-time word, two - shall / will plus be.
<G-vec00919-002-s315><add_up.hinzufügen><de> Wir fügen dem semantischen Verb noch die Endung -ing hinzu, und statt eines Zukunftswortes zwei - soll / wird plus sein.
<G-vec00919-002-s316><add_up.hinzufügen><en> Most manufacturers add their own security features on top of what Google adds by default.
<G-vec00919-002-s316><add_up.hinzufügen><de> Die meisten Hersteller fügen dem, was Google standardmäßig draufhat, ihre eigenen Sicherheits-Features hinzu.
<G-vec00919-002-s317><add_up.hinzufügen><en> This is basically the highest form of verbal praise we can give, when we are so blown away by things, we add at least 7 o’s and at least the same number of whatever consonant letter follows the vowel.
<G-vec00919-002-s317><add_up.hinzufügen><de> Dies ist im Grunde die höchste Form von verbalem Lob, das wir geben können, wenn wir von den Dingen so hinreißen, fügen wir mindestens 7 o's hinzu und mindestens die gleiche Anzahl von Konsonanten, die dem Vokal folgen.
<G-vec00919-002-s318><add_up.hinzufügen><en> They add too small amount of characteristics and must be used only if you have nothing else to upgrade.
<G-vec00919-002-s318><add_up.hinzufügen><de> Sie fügen zu wenig Eigenschaften hinzu und dürfen nur verwendet werden, wenn du nichts anderes zu aktualisieren hast.
<G-vec00919-002-s319><add_up.hinzufügen><en> You can add the Comic filter, then adjust it in the inspector or the heads-up display (HUD).
<G-vec00919-002-s319><add_up.hinzufügen><de> Fügen Sie den Comic-Filter hinzu, und passen Sie ihn im Informationsfenster oder in der Schwebepalette an.
<G-vec00919-002-s320><add_up.hinzufügen><en> Most applications on computers and portable devices add some type of personal information to documents and images upon creation or modification.
<G-vec00919-002-s320><add_up.hinzufügen><de> Die meisten Anwendungen auf Computern und tragbaren Geräten fügen bei der Erstellung oder Änderung irgendeine Art von persönlichen Informationen zu Dokumenten und Bildern hinzu.
<G-vec00919-002-s321><add_up.hinzufügen><en> You can add up to 62 cores and 240 GB of RAM (AMD CPUs) for each VM, or 27 cores and 120 GB RAM for Intel CPUs.
<G-vec00919-002-s321><add_up.hinzufügen><de> Fügen Sie pro VM bis zu 62 Cores und 240 GB RAM (bei AMD-CPU), beziehungsweise 27 Cores und 120 GB RAM (bei Intel-CPU) hinzu.
<G-vec00919-002-s322><add_up.hinzufügen><en> You can also add information on Michelin restaurants, tourist attractions or hotels in Altstätten or Arbon.
<G-vec00919-002-s322><add_up.hinzufügen><de> Fügen Sie Ihrem Routenplan Roggwil - Arbon Informationen zu Restaurants, Sehenswürdigkeiten und Hotels in Arbon hinzu.
<G-vec00919-002-s342><add_up.hinzufügen><en> If you don't include the unsubscribe merge tag, Mailchimp will add a footer to your campaign that includes an unsubscribe link.
<G-vec00919-002-s342><add_up.hinzufügen><de> Wenn du kein Zusammenführungs-Tag für die Abbestellung einfügst, fügt Mailchimp eine Fußzeile zu deiner Kampagne hinzu, die einen Abbestell-Link enthält.
<G-vec00919-002-s343><add_up.hinzufügen><en> 7 Will add 2 lines of Universal Wheels similar to the photo you send us.
<G-vec00919-002-s343><add_up.hinzufügen><de> 7 fügt 2 Linien von den Universalrädern hinzu, die dem Foto ähnlich sind, das Sie uns senden.
<G-vec00919-002-s344><add_up.hinzufügen><en> WordPress will automatically add those translations to your website if they hit 100% completion at least once.
<G-vec00919-002-s344><add_up.hinzufügen><de> WordPress fügt diese Übersetzungen automatisch zu Ihrer Website hinzu, sobald eine Vervollständigung von 100% erreicht ist.
<G-vec00919-002-s345><add_up.hinzufügen><en> When a Server Administrator selects a person they wish to add to their server's team of IRCops, they will add an O:line for that person into the configuration file.
<G-vec00919-002-s345><add_up.hinzufügen><de> Wenn ein Server Administrator eine bestimmte Person ausgesucht hat, die er zum Oper auf seinem Server machen will, so fügt er eine Zeile in der Konfigurationsdatei hinzu, die sogenannte O:line für die betreffende Person.
<G-vec00919-002-s346><add_up.hinzufügen><en> Game Serial Code: Used to upgrade your account from a free-to-play account, add expansion packs, and unlock additional features when creating or upgrading your account.
<G-vec00919-002-s346><add_up.hinzufügen><de> Seriennummerncode: Mit diesem Code wertet ihr euren kostenlosen Account auf, fügt Erweiterungen hinzu und schaltet zusätzliche Features bei der Erstellung oder Aufwertung eures Accounts frei.
<G-vec00919-002-s347><add_up.hinzufügen><en> Add instant preview for color matching.
<G-vec00919-002-s347><add_up.hinzufügen><de> Fügt sofortige Vorschau für Farbe Anpassung hinzu.
<G-vec00919-002-s348><add_up.hinzufügen><en> Using the snap knob, you can not only determine the character of the attack phase, but also add noise to the signal.
<G-vec00919-002-s348><add_up.hinzufügen><de> Der Snap-Regler legt nicht nur den Charakter des Anschlags fest, sondern fügt dem Signal auch Rauschen hinzu und imitiert so einen Snare-Teppich.
<G-vec00919-002-s349><add_up.hinzufügen><en> Equally, adding comments to a gallery will not add files to the gallery, nor change any files in the gallery or on your web server.
<G-vec00919-002-s349><add_up.hinzufügen><de> Noch einmal: das Hinzufügen von Kommentaren zu Ihrer Galerie fügt weder Ihrer Galerie Dateien hinzu, noch werden Dateien Ihrer Galerie oder auf Ihrem Webserver verändert.
<G-vec00919-002-s350><add_up.hinzufügen><en> Add hashtags to your Stories to help them reach more people, just like posts in the feed.
<G-vec00919-002-s350><add_up.hinzufügen><de> Fügt auch Hashtags bei euren Stories hinzu, um mehr Menschen zu erreichen.
<G-vec00919-002-s351><add_up.hinzufügen><en> Once you’ve successfully launched the sidebar, select Searchmetrics as your “Data Source” and add a new account.
<G-vec00919-002-s351><add_up.hinzufügen><de> Nachdem die Sidebar gelauncht ist, wählt Searchmetrics als eure “Data Source” und fügt einen neuen Account hinzu.
<G-vec00919-002-s352><add_up.hinzufügen><en> Forge will add a public key to your account when you create a server.
<G-vec00919-002-s352><add_up.hinzufügen><de> Forge fügt Ihrem Konto einen öffentlichen Schlüssel hinzu, wenn Sie einen Server erstellen.
<G-vec00919-002-s353><add_up.hinzufügen><en> Conflict: In May, the second free update will add new features to the Dark Zone and add a new incursion in the iconic Columbus Circle.
<G-vec00919-002-s353><add_up.hinzufügen><de> Konflikt: Das zweite kostenlose Update, das im Mai erscheint, fügt der Dark Zone neue Features hinzu und bietet einen weiteren Übergriff auf dem bekannten Columbus Circle.
<G-vec00919-002-s354><add_up.hinzufügen><en> Let’s make the image more like 3D. Add a new layer named “Shadow” and add a black layer mask.
<G-vec00919-002-s354><add_up.hinzufügen><de> Jetzt sorgen wir für einen plastischen Effekt: Erstellt zuerst eine neue Ebene namens “Schattierung” und fügt eine schwarze Ebenenmaske hinzu.
<G-vec00919-002-s355><add_up.hinzufügen><en> RSS Feed RSS Comments Feed Add our application to your Facebook page and it will remind you and your friends about a new giveaway on a daily basis.
<G-vec00919-002-s355><add_up.hinzufügen><de> Cool YouTube To Mp3 Converter hilft euch beim Herunterladen von Fügt unsere Anwendung eurer Facebook Seite hinzu und sie wird euch und eure Freunde täglich an ein neues Giveaway erinnern.
<G-vec00919-002-s356><add_up.hinzufügen><en> Drivers select defects, add comments, review previous inspections and certify that the repair performed fixed the defect(s) identified.
<G-vec00919-002-s356><add_up.hinzufügen><de> Der Fahrer legt den Defekt fest, fügt seine Anmerkungen hinzu, prüft vorangegangene Inspektionen und bestätigt, dass die durchgeführten Reparaturen den angezeigten Defekt beseitigt haben.
<G-vec00919-002-s357><add_up.hinzufügen><en> Please add the item a short letter with order number and reason.
<G-vec00919-002-s357><add_up.hinzufügen><de> Bitte fügt der Sendung ein kurzes Schreiben mit Ordernummer und Grund/Bitte hinzu.
<G-vec00919-002-s358><add_up.hinzufügen><en> Add in new policies and zones to create popular hotspots and provide enough taxis and trains to get to and from the clubs! Download QR-Code
<G-vec00919-002-s358><add_up.hinzufügen><de> Fügt neue Richtlinien und Zonen hinzu, um populäre Hotspots zu erschaffen und sorgt für genug Taxis und Busse, damit eure Stadtbewohner zu den Clubs kommen und von dort auch wieder wegkommen können.
<G-vec00919-002-s359><add_up.hinzufügen><en> A new component in the MAPILab Toolbox - "Reply All Forget" doesn't add any addition buttons on the ribbon.
<G-vec00919-002-s359><add_up.hinzufügen><de> Die neue Komponente der MAPILab Toolbox "Reply All" Forget fügt keine zusätzlichen Buttons hinzu.
<G-vec00919-002-s360><add_up.hinzufügen><en> The Java ES Installer does not add a platform entry for an existing directory server installation (DIRECTORY_MODE=2).
<G-vec00919-002-s360><add_up.hinzufügen><de> Der Installer fügt für die bereits vorhandene Verzeichnisinstallation keinen Plattformeintrag hinzu (6202902).
<G-vec00919-002-s437><add_up.hinzufügen><en> Use them in your layout right away, add to the Swatches panel for future use or save to Adobe Color.
<G-vec00919-002-s437><add_up.hinzufügen><de> Sie lassen sich sofort im Layout einsetzen, zum Farbfelder-Bedienfeld hinzufügen oder in Adobe Color speichern.
<G-vec00919-002-s438><add_up.hinzufügen><en> To this, we can add: “using the right energy-efficient technology”.
<G-vec00919-002-s438><add_up.hinzufügen><de> Dazu können wir „mit der richtigen energieeffizienten Technologie“ hinzufügen.
<G-vec00919-002-s439><add_up.hinzufügen><en> You can also add keywords in bulk.
<G-vec00919-002-s439><add_up.hinzufügen><de> Sie können auch Keywords in einem Massenvorgang hinzufügen.
<G-vec00919-002-s440><add_up.hinzufügen><en> Tip: If you want to import a folder, please click the "Add files to iPod" drop-down button, and choose the "Add Folder to List" option.
<G-vec00919-002-s440><add_up.hinzufügen><de> Tipp: Wenn Sie einen Ordner importieren möchten, klicken Sie bitte auf "Den Ordner zum Gerät hinzufügen".
<G-vec00919-002-s441><add_up.hinzufügen><en> Add sound effect to emphasis front right.
<G-vec00919-002-s441><add_up.hinzufügen><de> Soundeffekte hinzufügen, um vorne rechts zu unterstreichen.
<G-vec00919-002-s442><add_up.hinzufügen><en> ▼ Add, emulsify and leave to cool in refrigerator.
<G-vec00919-002-s442><add_up.hinzufügen><de> Ein anderes Produkt Hinzufügen, emulgieren und im Kühlschrank abkühlen lassen.
<G-vec00919-002-s443><add_up.hinzufügen><en> Beat the egg yolks with the sugar and the cream cheese in a bowl until frothy, add the vanilla grains.
<G-vec00919-002-s443><add_up.hinzufügen><de> Die Eigelb mit dem Zucker und dem Frischkäse in einer Schüssel schaumig rühren, das Vanillemark hinzufügen.
<G-vec00919-002-s444><add_up.hinzufügen><en> The new article interface gives you a lot of options, but all you need to do is add a title and put something in the content area.
<G-vec00919-002-s444><add_up.hinzufügen><de> Die neue Artikel-Schnittstelle gibt Ihnen eine Menge von Optionen, aber alles, was Sie tun müssen, ist einen Titel hinzufügen und legen Sie etwas in den Content-Bereich.
<G-vec00919-002-s445><add_up.hinzufügen><en> Obliterate the following items from: Do not allow any site to show desktop notifications Add new fax Scanning content...
<G-vec00919-002-s445><add_up.hinzufügen><de> Die folgenden Elemente löschen: Anzeige von Desktop-Benachrichtigungen für keine Website zulassen Neues Faxgerät hinzufügen Der Inhalt wird durchsucht...
<G-vec00919-002-s446><add_up.hinzufügen><en> You add questions to tests and surveys in the same way, but you don't add points to survey questions because they aren't graded.
<G-vec00919-002-s446><add_up.hinzufügen><de> Sie können in gleicher Weise Fragen in Tests und Umfragen einfügen, jedoch keine Punkte zu Umfrageoptionen hinzufügen.
<G-vec00919-002-s447><add_up.hinzufügen><en> Click Add Chart Element.
<G-vec00919-002-s447><add_up.hinzufügen><de> Klicken Sie auf Diagrammelement hinzufügen.
<G-vec00919-002-s448><add_up.hinzufügen><en> Click on 'Edit' > 'Add Outline item' or simply click ⌘⇧D.
<G-vec00919-002-s448><add_up.hinzufügen><de> Klicken Sie auf 'Bearbeiten' > 'Gliederungselement hinzufügen' oder verwenden Sie die Tastenkombination ⌘⇧D.
<G-vec00919-002-s449><add_up.hinzufügen><en> You can then schedule the recorded profile, and add other actions you want it to perform.
<G-vec00919-002-s449><add_up.hinzufügen><de> Sie können dann das aufgezeichnete Profil planen und weitere Aktionen hinzufügen, die es ausführen soll.
<G-vec00919-002-s450><add_up.hinzufügen><en> Mail On the left bar, click on the 'Add' link next to 'Contacts'.
<G-vec00919-002-s450><add_up.hinzufügen><de> Auf der linken Leiste, klicken Sie auf dem Link "Hinzufügen" neben 'Kontakte'.
<G-vec00919-002-s451><add_up.hinzufügen><en> Hover over the widget you want to add to a different Dashboard.
<G-vec00919-002-s451><add_up.hinzufügen><de> Bewegen Sie die Maus über das Widget, das Sie einem anderen Dashboard hinzufügen wollen.
<G-vec00919-002-s452><add_up.hinzufügen><en> In a saucepan mix the coconut milk and the curry, add the cream and bring to a boil, then whisk with a mixer.
<G-vec00919-002-s452><add_up.hinzufügen><de> In einem kleinen Topf Kokosmilch und Curry vermischen, die Sahne hinzufügen, alles zum Kochen bringen und dann im Mixer pürieren.
<G-vec00919-002-s453><add_up.hinzufügen><en> To do this, please go to My Account settings in the Client Portal area, click ‘Manage Credit Cards’ > ‘Add Credit Card Now’ and follow the prompts.
<G-vec00919-002-s453><add_up.hinzufügen><de> Gehen Sie dazu in Ihrem Kundenportal zu "Meine Kontoeinstellungen", klicken Sie auf "Kreditkarten verwalten"> Jetzt Kreditkarte hinzufügen und Anweisungen befolgen.
<G-vec00919-002-s454><add_up.hinzufügen><en> This allows you to add new applications and services very quickly.
<G-vec00919-002-s454><add_up.hinzufügen><de> So können Sie sehr schnell neue Anwendungen und Dienste hinzufügen.
<G-vec00919-002-s455><add_up.hinzufügen><en> If you do not add an action, then the $MT_EMBEDDEDMESSAGE page source will not be created.
<G-vec00919-002-s455><add_up.hinzufügen><de> Wenn Sie keine Aktion hinzufügen, wird die Seitenquelle $MT_EMBEDDEDMESSAGE nicht erstellt.
<G-vec00919-002-s456><add_up.hinzufügen><en> With the wall stickers, you can add subtle dots or sparkles in a few minutes and create a fun twist on the walls.
<G-vec00919-002-s456><add_up.hinzufügen><de> Mit diesen Wandaufklebern bekommen die Wände in wenigen Minuten subtile Punkte oder ein Funkeln hinzugefügt, die einen lustigen Twist schaffen.
<G-vec00919-002-s457><add_up.hinzufügen><en> It has all the features of messaging apps and more specific ways like stickers and doodles to add on during te conversation.
<G-vec00919-002-s457><add_up.hinzufügen><de> Es hat alle Features der Messaging-Apps und spezifischere Arten wie Aufkleber und Kritzeleien auf während des Gesprächs hinzugefügt.
<G-vec00919-002-s458><add_up.hinzufügen><en> It will also simplify engineering and repairs, upgrade onboard status sensors and add an extra layer of control redundancy in the event of accidents.
<G-vec00919-002-s458><add_up.hinzufügen><de> Gleichzeitig werden Technik und Reparaturen vereinfacht, die Status-Sensoren an Bord aufgerüstet und eine zusätzliche Ebene der Steuerungsredundanz bei Unfällen hinzugefügt.
<G-vec00919-002-s459><add_up.hinzufügen><en> You can add shipping fees through the online store settings.
<G-vec00919-002-s459><add_up.hinzufügen><de> Liefergebühren können in den Einstellungen des Online-Shops hinzugefügt werden.
<G-vec00919-002-s460><add_up.hinzufügen><en> To only show colors for a specific product, you should filter on this product or alternatively add the dimension "products".
<G-vec00919-002-s460><add_up.hinzufügen><de> Um nur die für ein bestimmtes Produkt gewählten Farben anzuzeigen, sollte auf dieses Produkt gefiltert werden oder "Produkte" als Dimension hinzugefügt werden.
<G-vec00919-002-s461><add_up.hinzufügen><en> See Customize the Quick Access Toolbar to learn how to add commands.
<G-vec00919-002-s461><add_up.hinzufügen><de> Wenn Sie wissen möchten, wie Befehle hinzugefügt werden, lesen Sie Anpassen der Symbolleiste für den Schnellzugriff.
<G-vec00919-002-s462><add_up.hinzufügen><en> If you didn’t add your wallet address we will ask you to do so before continuing to the payment.
<G-vec00919-002-s462><add_up.hinzufügen><de> Wenn du deine Wallet-Adresse nicht hinzugefügt hast, werden wir dich bitten, dies zu tun, bevor du mit der Zahlung fortfährst.
<G-vec00919-002-s463><add_up.hinzufügen><en> Add OCS Driver
<G-vec00919-002-s463><add_up.hinzufügen><de> OCS Treiber hinzugefügt.
<G-vec00919-002-s464><add_up.hinzufügen><en> In the lists, choose the conditions that you want to add to the rule.
<G-vec00919-002-s464><add_up.hinzufügen><de> Wählen Sie in den Listen die Bedingungen aus, die der Regel hinzugefügt werden sollen.
<G-vec00919-002-s465><add_up.hinzufügen><en> Subscriptions are cumulative, so if you pay for an additional year of service, it will add to your current subscription or free year-long trial.
<G-vec00919-002-s465><add_up.hinzufügen><de> Abos sind kumulativ, das heißt, wenn Sie für ein weiteres Jahr bezahlen, wird es zu Ihrem jetzigen Abo oder kostenlosen Jahr hinzugefügt.
<G-vec00919-002-s466><add_up.hinzufügen><en> With Subversion, you can add, - delete, copy, and rename both files and directories.
<G-vec00919-002-s466><add_up.hinzufügen><de> Mit Subversion - können sowohl Dateien als auch Verzeichnisse - hinzugefügt, gelöscht, kopiert und umbenannt werden.
<G-vec00919-002-s467><add_up.hinzufügen><en> Edit (Add, Delete or Change) any of the information and Save your changes.
<G-vec00919-002-s467><add_up.hinzufügen><de> Bearbeiten (Hinzugefügt, gelöscht oder geändert) beliebige Informationen und Speichern Sie Ihre Änderungen.
<G-vec00919-002-s468><add_up.hinzufügen><en> With a click at "edit" you will get to the details view, where you can add rules.
<G-vec00919-002-s468><add_up.hinzufügen><de> Mit einem Klick auf "bearbeiten" gelangen Sie zur Detailansicht, in der die Regel hinzugefügt wird.
<G-vec00919-002-s469><add_up.hinzufügen><en> At frequencies away from center frequency, add Channel Response to the Absolute Amplitude Accuracy.
<G-vec00919-002-s469><add_up.hinzufügen><de> Bei Frequenzen ungleich der Mittenfrequenz muss zur absoluten Amplitudengenauigkeit die Kanalantwort hinzugefügt werden.
<G-vec00919-002-s470><add_up.hinzufügen><en> Pressing the return or space keys will turn a square black or add a circle respectively, and pressing the key again will show the number again or remove the circle.
<G-vec00919-002-s470><add_up.hinzufügen><de> Durch Drücken der Eingabe- oder Leertaste wird ein Quadrat schwarz gefärbt oder respektive ein Kreis hinzugefügt und durch erneutes Drücken der Taste wird wieder die Zahl gezeigt oder der Kreis entfernt.
<G-vec00919-002-s471><add_up.hinzufügen><en> The designer can add ribs on thin walls die casting to increase component strength.
<G-vec00919-002-s471><add_up.hinzufügen><de> Beim Entwurf können bei dünnen Wänden Verbindungsrippen hinzugefügt werden, um die Festigkeit des Teils zu erhöhen.
<G-vec00919-002-s472><add_up.hinzufügen><en> If you would like a user to be able to edit dashboards, queries, and datasets without you sharing them first, you should add them as an admin.
<G-vec00919-002-s472><add_up.hinzufügen><de> Wenn ein Benutzer Dashboards, Querys und Verbindungen bearbeiten soll, ohne dass diese vorher mit ihm geteilt werden müssen, muss er als Administrator hinzugefügt werden.
<G-vec00919-002-s473><add_up.hinzufügen><en> Select the Data Disc option from the homepage and you will be directed to another screen where you can add audio files to the software interface.
<G-vec00919-002-s473><add_up.hinzufügen><de> Nachdem Sie Ihre Dateien erfolgreich hinzugefügt haben, wählen Sie die DVD-Menüvorlage rechts in der Softwareoberfläche.
<G-vec00919-002-s474><add_up.hinzufügen><en> You can add offices, users and features easily to grow and customize your communications for a true competitive advantage.
<G-vec00919-002-s474><add_up.hinzufügen><de> Standorte, Benutzer und Funktionen können leicht hinzugefügt werden, sodass Sie dem Wachstum Ihres Unternehmens Rechnung tragen und sich mit Ihrer Kommunikationslösung einen echten Wettbewerbsvorteil verschaffen können.
<G-vec00919-002-s475><add_up.hinzufügen><en> No such ‘confession’ is even pretended to by the Jharkhand Police to add my name to this case.
<G-vec00919-002-s475><add_up.hinzufügen><de> Keines dieser „Geständnisse“ wurde überhaupt von der Polizei Jharkhands präsentiert, um meinen Namen zu diesem Fall hinzuzufügen.
<G-vec00919-002-s476><add_up.hinzufügen><en> Help from the developer community from those that want to add code, documentation, or samples
<G-vec00919-002-s476><add_up.hinzufügen><de> Die Entwickler-Community kann dabei helfen, Code, Dokumentation oder Beispiele hinzuzufügen.
<G-vec00919-002-s477><add_up.hinzufügen><en> Fortunately it's not hard to add chapter numbers to your captions and have them automatically update if you move a figure from chapter to chapter in the course of editing.
<G-vec00919-002-s477><add_up.hinzufügen><de> Glücklicherweise ist es nicht schwierig, Ihren Beschriftungen Kapitelnummern hinzuzufügen und sie automatisch aktualisieren zu lassen, wenn Sie eine Abbildung während der Dokumentbearbeitung zwischen den Kapiteln verschieben.
<G-vec00919-002-s478><add_up.hinzufügen><en> Shachtman forgets to add that Lenin’s hope did not at all materialize.
<G-vec00919-002-s478><add_up.hinzufügen><de> Shachtman vergißt hinzuzufügen, daß sich Lenins Hoffnung nicht verwirklichte.
<G-vec00919-002-s479><add_up.hinzufügen><en> Allows the app to change or add to personal profile information stored on your device, such as your name and contact information.
<G-vec00919-002-s479><add_up.hinzufügen><de> Ermöglicht der App, auf Ihrem Gerät gespeicherte persönliche Profildaten zu ändern, darunter Ihren Namen und Ihre Kontaktdaten, sowie Daten hinzuzufügen.
<G-vec00919-002-s480><add_up.hinzufügen><en> Our rooms are double with the possibility to add a third bed. We also have a room with a box room incorporated, complete with bunk beds for the children.
<G-vec00919-002-s480><add_up.hinzufügen><de> Es gibt die Möglichkeit, in alle unsere Doppelzimmer ein drittes Bett hinzuzufügen: außerdem gibt es ein Zimmer mit einem inneren Kinderzimmer mit Etagenbett.
<G-vec00919-002-s481><add_up.hinzufügen><en> Being open source, decentralized and with the ability to add smart contracts, it offers a great deal of transparency and trust between the people who use it, thus avoiding any third-party intermediaries.
<G-vec00919-002-s481><add_up.hinzufügen><de> Als dezentralisierte Open-Source-Technologie mit der Möglichkeit, Smart Contracts hinzuzufügen, bietet die Blockchain enorm viel Transparenz und schafft Vertrauen zwischen den Benutzern, ohne dass Drittparteien als Vermittler erforderlich sind.
<G-vec00919-002-s482><add_up.hinzufügen><en> To add a new term for which an entry and therefore at least one term already exists in the same or another language, you must first select the respective entry or term.
<G-vec00919-002-s482><add_up.hinzufügen><de> Um einen neuen Term hinzuzufügen, für den es bereits einen Eintrag und somit mindestens auch schon einen Term in einer anderen oder derselben Sprache gibt, müssen Sie zunächst den entsprechenden Eintrag oder Term auswählen.
<G-vec00919-002-s483><add_up.hinzufügen><en> When you add the plants to your ecosystem, make sure to separate them and add them individually.
<G-vec00919-002-s483><add_up.hinzufügen><de> Wenn du die Pflanzen zu deinem Ökosystem hinzufügst, achte darauf, sie zu trennen und einzeln hinzuzufügen.
<G-vec00919-002-s484><add_up.hinzufügen><en> Users can add Text and Image both watermarks to their PDF files by utilizing this program.
<G-vec00919-002-s484><add_up.hinzufügen><de> Es ist möglich, Wasserzeichen auf mehrere PDF-Dateien hinzuzufügen, die in einem Ordner gespeichert sind.
<G-vec00919-002-s485><add_up.hinzufügen><en> To add picture watermark, please click "Add Picture Watermark" button, and choose a picture in the dialog that opens, and adjust the settings below.
<G-vec00919-002-s485><add_up.hinzufügen><de> Um Bildwasserzeichen hinzuzufügen, klicken Sie bitte auf „Bildwasserzeichen hinzufügen“, wählen Sie ein Bild aus dem geöffneten Dialog aus und passen Sie die Einstellungen an.
<G-vec00919-002-s486><add_up.hinzufügen><en> d products and even cookery schools to add ‘edutainment’.
<G-vec00919-002-s486><add_up.hinzufügen><de> Sogar Kochschulen sind denkbar, um 'Edutainment“-Elemente hinzuzufügen.
<G-vec00919-002-s487><add_up.hinzufügen><en> If you want to let other people administer the folder, click the Add button to add their names.
<G-vec00919-002-s487><add_up.hinzufügen><de> Wenn Sie anderen Personen den Ordner zu verwalten lassen möchten, klicken Sie auf die Schaltfläche Hinzufügen, um deren Namen hinzuzufügen.
<G-vec00919-002-s488><add_up.hinzufügen><en> If not, click on the “Plus” sign to add AdGuard and then tick it.
<G-vec00919-002-s488><add_up.hinzufügen><de> Wenn nicht, klicken Sie auf das "Plus"-Zeichen, um AdGuard hinzuzufügen und dann anzukreuzen.
<G-vec00919-002-s489><add_up.hinzufügen><en> Send your agents on raids to foreign lands to steal world wonders and monuments, to add them to your collection.
<G-vec00919-002-s489><add_up.hinzufügen><de> Entsende Agenten in fremde Länder und reiß dir Weltwunder und Denkmäler unter den Nagel, um sie deiner Sammlung hinzuzufügen.
<G-vec00919-002-s490><add_up.hinzufügen><en> To add entries to the menu, you can either create a /boot/grub/custom.cfg file or modify the /etc/grub.d/50_custom file.
<G-vec00919-002-s490><add_up.hinzufügen><de> Um Einträge zum Menü hinzuzufügen, können Sie entweder eine Datei namens /boot/grub/custom.cfg erstellen oder die Datei /etc/grub.d/50_custom ändern.
<G-vec00919-002-s491><add_up.hinzufügen><en> To add additional site owners, enter an employee's name under Add additional owners.
<G-vec00919-002-s491><add_up.hinzufügen><de> Um weitere Websitebesitzer hinzuzufügen, geben Sie unter Weitere Besitzer hinzufügen den Namen eines Mitarbeiters ein.
<G-vec00919-002-s492><add_up.hinzufügen><en> Start the program and click “Import” to add PowerPoint files.
<G-vec00919-002-s492><add_up.hinzufügen><de> Starten Sie das Programm und klicken Sie auf "Import" PowerPoint-Dateien hinzuzufügen.
<G-vec00919-002-s493><add_up.hinzufügen><en> That’s why we have made it so easy to add your own fonts to Crello.
<G-vec00919-002-s493><add_up.hinzufügen><de> Deshalb haben wir es so einfach gemacht, Crello eigene Schriftarten hinzuzufügen.
<G-vec00919-002-s570><add_up.hinzufügen><en> If we also wanted to add them to a tool bar, we could have given icons to the actions.
<G-vec00919-002-s570><add_up.hinzufügen><de> Wollten wir sie auch zu einer Werkzeugleiste hinzufügen, könnten wir für die Aktionen auch Icons festlegen.
<G-vec00919-002-s571><add_up.hinzufügen><en> In the dropdown menu on the After Sale Log page there is an option to "add a note".
<G-vec00919-002-s571><add_up.hinzufügen><de> Im Sales-Management-Menü finden Sie die Option "Notiz hinzufügen".
<G-vec00919-002-s572><add_up.hinzufügen><en> Learn how to add a payment method if you don't have one on file.
<G-vec00919-002-s572><add_up.hinzufügen><de> Hier erfahren Sie, wie Sie eine Zahlungsmethode hinzufügen, wenn Sie noch keine hinterlegt haben.
<G-vec00919-002-s573><add_up.hinzufügen><en> Learn how to add images, audio/music and video.
<G-vec00919-002-s573><add_up.hinzufügen><de> Erfahren Sie, wie Sie Bilder, Audio/Musik und Videos hinzufügen.
<G-vec00919-002-s574><add_up.hinzufügen><en> Less To make room for more information in a table, you can add rows and columns without leaving Word Online.
<G-vec00919-002-s574><add_up.hinzufügen><de> Wenn Sie Platz für weitere Daten in einer Tabelle benötigen, können Sie Zeilen und Spalten hinzufügen, ohne Word Online verlassen zu müssen.
<G-vec00919-002-s575><add_up.hinzufügen><en> You'll learn to add functionality to your app that lets users upload images from their device's gallery or camera, then rotate and automatically resize the images, and finally save the modified images to your database.
<G-vec00919-002-s575><add_up.hinzufügen><de> Sie erfahren, wie Sie Funktionen zu Ihrer App hinzufügen, mit denen Benutzer Bilder aus der Galerie oder von der Kamera ihres Geräts hochladen können, diese drehen, automatisch in der Größe anpassen und die bearbeiteten Bilder schließlich in Ihrer Datenbank speichern können.
<G-vec00919-002-s576><add_up.hinzufügen><en> Opens the Select Devices dialog, from which target devices to add to this view are selected.
<G-vec00919-002-s576><add_up.hinzufügen><de> Öffnet das Dialogfeld “Select Devices”, in dem Sie Zielgeräte auswählen und dieser Ansicht hinzufügen können.
<G-vec00919-002-s577><add_up.hinzufügen><en> Follow these steps to create a new project, add videos and graphics, and apply transitions.
<G-vec00919-002-s577><add_up.hinzufügen><de> Diese Anleitung zeigt Ihnen, wie Sie ein neues Projekt erstellen, Video-Clips und Grafiken hinzufügen und Überblendungen anwenden.
<G-vec00919-002-s578><add_up.hinzufügen><en> In the Add Role Services dialog, expand Web Server, then Application Development, select ASP.NET and CGI.
<G-vec00919-002-s578><add_up.hinzufügen><de> Erweitern Sie im Dialogfeld "Rollendienste hinzufügen" zuerst "Webserver" und dann "Anwendungsentwicklungsfeatures".
<G-vec00919-002-s579><add_up.hinzufügen><en> 1.To add a new computer, click Computers, Add New and then select Computers (alternatively click the gear icon next to existing Static group and then click Add New).
<G-vec00919-002-s579><add_up.hinzufügen><de> 1.Um einen neuen Computer hinzuzufügen, navigieren Sie zur Registerkarte Computer, klicken Sie auf Neue hinzufügen und wählen Sie Computer aus (oder klicken Sie auf das Zahnradsymbol neben einer vorhandenen statischen Gruppe und anschließend auf Neue hinzufügen).
<G-vec00919-002-s580><add_up.hinzufügen><en> Right-click NIS Servers, and then click Add NIS Server.
<G-vec00919-002-s580><add_up.hinzufügen><de> Klicken Sie mit der rechten Maustaste auf NIS-Server, und klicken Sie dann auf NIS-Server hinzufügen.
<G-vec00919-002-s581><add_up.hinzufügen><en> This page describes how to add video-on-demand apps to the App channels list in OneGuide.
<G-vec00919-002-s581><add_up.hinzufügen><de> Auf dieser Seite wird erläutert, wie Sie Video-on-Demand-Apps zur Liste der App-Kanäle in OneGuide hinzufügen.
<G-vec00919-002-s582><add_up.hinzufügen><en> You may have to add all the available domains of a particular website, if they do have different once for different device platforms like mobile, tablet and a computer because the blacklist works with only the domain specified.
<G-vec00919-002-s582><add_up.hinzufügen><de> Möglicherweise müssen Sie alle verfügbaren Domains einer bestimmten Webseite hinzufügen, wenn sie für verschiedene Geräteplattformen wie Handy, Tablet und Computer unterschiedlich sind, da die Blacklist nur mit der angegebenen Domain funktioniert.
<G-vec00919-002-s583><add_up.hinzufügen><en> If you know any other happy ending massages in Cebu, please leave a comment below and I will add it to this guide.
<G-vec00919-002-s583><add_up.hinzufügen><de> Wenn du noch andere Happy Ending Massagen in Cebu kennst, dann hinterlasse bitte unten einen Kommentar und ich werde sie zu diesem Guide hinzufügen.
<G-vec00919-002-s584><add_up.hinzufügen><en> Once you set up a team page, add event types for invitees to choose from.
<G-vec00919-002-s584><add_up.hinzufügen><de> Sobald Sie eine Teamseite eingerichtet haben, können Sie Ereignistypen hinzufügen, aus denen Eingeladene wählen können.
<G-vec00919-002-s585><add_up.hinzufügen><en> Learn how in this video, Add fades to audio with the Audition waveform display.
<G-vec00919-002-s585><add_up.hinzufügen><de> Erfahren Sie in diesem Video, wie Sie Ein- und Ausblendungen mit der Auditions-Wellenformanzeige zu Audio hinzufügen.
<G-vec00919-002-s586><add_up.hinzufügen><en> Number of metrics in a single panel: Adobe Analytics offers the ability to add virtually as many metrics to a freeform table as your screen can fit.
<G-vec00919-002-s586><add_up.hinzufügen><de> Anzahl der Metriken in einem einzelnen Fenster: In Adobe Analytics können Sie so viele Metriken zu einer Freiformtabelle hinzufügen, wie auf den Bildschirm passen.
<G-vec00919-002-s587><add_up.hinzufügen><en> I describe how to add the Report Server Content types later in this article under Integration with Report Builder 3.0.
<G-vec00919-002-s587><add_up.hinzufügen><de> Weiter unten im Abschnitt Integration in Report Builder 3.0 wird beschrieben, wie Sie die Report Server-Inhaltstypen manuell hinzufügen.
<G-vec00919-002-s588><add_up.hinzufügen><en> But Outlook prefers that you build distribution lists from your Contacts, so you first must add the sender to an address book in Contacts.
<G-vec00919-002-s588><add_up.hinzufügen><de> In Outlook werden Verteilerlisten jedoch aus Ihren Kontakten erstellt, daher müssen Sie also den Absender zuerst zu einem Adressbuch in den Kontakten hinzufügen.
<G-vec00919-002-s608><add_up.zugeben><en> Add 2 teaspoons of cocoa powder to the remaining batter and mix until incorporated.
<G-vec00919-002-s608><add_up.zugeben><de> Zum restlichen Teig zwei Teelöffel Kakao zugeben und unterrühren.
<G-vec00919-002-s609><add_up.zugeben><en> Add rice and brown the rice for short time.
<G-vec00919-002-s609><add_up.zugeben><de> Reis zugeben und unter Rühren kurz anrösten.
<G-vec00919-002-s610><add_up.zugeben><en> Add the cream cheese and vanilla extract and mix until well combined.
<G-vec00919-002-s610><add_up.zugeben><de> Frischkäse und Vanille Extrakt zugeben und gut verrühren.
<G-vec00919-002-s611><add_up.zugeben><en> Add the desired amount of pigment and mix.
<G-vec00919-002-s611><add_up.zugeben><de> Die gewünschte Menge an Pigment zugeben und mischen.
<G-vec00919-002-s612><add_up.zugeben><en> Simmer for approx 20 minutes; you might need to add some water, if the sauce thickens too much.
<G-vec00919-002-s612><add_up.zugeben><de> Ca 20 Minuten koecheln lassen, evt etwas Wasser zugeben, falls sie zu sehr eindickt.
<G-vec00919-002-s613><add_up.zugeben><en> Add canadian whisky.
<G-vec00919-002-s613><add_up.zugeben><de> Kanadischer Whisky zugeben.
<G-vec00919-002-s614><add_up.zugeben><en> If needed, add a tiny bit of water.
<G-vec00919-002-s614><add_up.zugeben><de> Falls nötig einen Schuss Wasser zugeben.
<G-vec00919-002-s615><add_up.zugeben><en> Do not add water.
<G-vec00919-002-s615><add_up.zugeben><de> Kein Wasser zugeben.
<G-vec00919-002-s616><add_up.zugeben><en> Add chestnuts, garlic and bacon.
<G-vec00919-002-s616><add_up.zugeben><de> Maronen, Knoblauch und Speck zugeben.
<G-vec00919-002-s617><add_up.zugeben><en> Top off with some freshly ground black pepper, stir and add a large slice of cucumber.
<G-vec00919-002-s617><add_up.zugeben><de> Mit etwas frisch zerstoßenen Pfefferkörnern abrunden, umrühren und eine große Gurkenscheibe zugeben.
<G-vec00919-002-s618><add_up.zugeben><en> Add the white wine and let cook until some of the wine has reduced.
<G-vec00919-002-s618><add_up.zugeben><de> Den Weißwein zugeben und koecheln lassen, bis der Wein leicht eingekocht ist.
<G-vec00919-002-s619><add_up.zugeben><en> Then add the whisked eggs and rice and bring to the boil again.
<G-vec00919-002-s619><add_up.zugeben><de> Anschliessend verrührte Eier sowie Reis zugeben und nochmal zum Kochen bringen.
<G-vec00919-002-s620><add_up.zugeben><en> Add the chopped onion after 2 minutes and cook as well.
<G-vec00919-002-s620><add_up.zugeben><de> Nach etwa 2 Minuten die Zwiebeln zugeben und mitkochen – dauert etwa 10-15 Minuten.
<G-vec00919-002-s621><add_up.zugeben><en> If necessary, add some more water (possibly up to about 80 ml).
<G-vec00919-002-s621><add_up.zugeben><de> Gegebenenfalls mehr Wasser zugeben (eventuell etwa 80 ml).
<G-vec00919-002-s622><add_up.zugeben><en> Add the oil and butter mixture
<G-vec00919-002-s622><add_up.zugeben><de> Eier und Öl zugeben und unterrühren.
<G-vec00919-002-s623><add_up.zugeben><en> Add in the milk and beat until just combined.
<G-vec00919-002-s623><add_up.zugeben><de> Milch zugeben und gerade so lange rühren, bis alles vermischt ist.
<G-vec00919-002-s624><add_up.zugeben><en> Skim any fat or impurities off the top periodically and add more liquid as needed to keep the bones covered.
<G-vec00919-002-s624><add_up.zugeben><de> Dabei das Fett und Verunreinigungen an der Oberfläche regelmäßig abschöpfen und nach Bedarf mehr Flüssigkeit zugeben damit die Knochen immer bedeckt sind.
<G-vec00919-002-s625><add_up.zugeben><en> As you can see, this salad is very colorful, you can add some more ingredients or leave some out, change whatever you like.
<G-vec00919-002-s625><add_up.zugeben><de> Wie Ihr sehen koennt, sieht der Salat wunderbar bunt aus, da kann man auch je nach Geschmack Zutaten zugeben oder weglassen.
<G-vec00919-002-s626><add_up.zugeben><en> 1) Heat up a pan then add the honey.
<G-vec00919-002-s626><add_up.zugeben><de> 1) Eine Pfanne erhitzen, den Honig zugeben und aufschäumen lassen.
