<G-vec00728-002-s019><click.anklicken><en> If you click the Facebook “Like button” when you are logged on to your Facebook account, you may link the contents of our sites on your Facebook profile.
<G-vec00728-002-s019><click.anklicken><de> Wenn Sie den Facebook "Like-Button" anklicken während Sie in Ihrem Facebook-Account eingeloggt sind, können Sie die Inhalte unserer Seiten auf Ihrem Facebook-Profil verlinken.
<G-vec00728-002-s020><click.anklicken><en> +In most mail programs, this should appear as a blue link +which you can just click on.
<G-vec00728-002-s020><click.anklicken><de> +In den meisten Email-Programmen erscheint dieser Link blau, so dass Sie diesen anklicken können.
<G-vec00728-002-s021><click.anklicken><en> Markets Markets To learn more about the markets we serve, click on any of the icons below.
<G-vec00728-002-s021><click.anklicken><de> Märkte Märkte Um mehr über unsere Märkte zu erfahren, eines der unten gezeigten Symbole anklicken.
<G-vec00728-002-s022><click.anklicken><en> 2.3 When you click on the “conclude order” button at the end of the ordering procedure, you are submitting a binding order for the goods contained within the shopping basket at the total price quoted to you there.
<G-vec00728-002-s022><click.anklicken><de> 2.3 Durch Anklicken des Buttons „Bestellung abschließen“ am Ende des Bestellvorgangs geben Sie eine verbindliche Bestellung der im Warenkorb enthaltenen Waren zu dem Ihnen dort mitgeteilten Gesamtpreis ab.
<G-vec00728-002-s023><click.anklicken><en> Whenever you are asked to fill in a form on the website, look for the box that you can click to indicate whether or not you wish to receive future contact from us.
<G-vec00728-002-s023><click.anklicken><de> Wenn Sie gebeten werden, ein Formular auf der Website auszufüllen, suchen Sie nach dem Kästchen, das Sie anklicken können, um anzugeben, dass Sie nicht möchten, dass die Informationen von irgendjemandem für Direktmarketingzwecke verwendet werden.
<G-vec00728-002-s024><click.anklicken><en> If you would like Coiltrade Stahlhandel GmbH to call you back about Steel Products, please click on the button "Display contact details", enter your contact details in the mailing form and click on Send.
<G-vec00728-002-s024><click.anklicken><de> Eine Übersicht zu Stahlprodukte sowie zum gesamten Lieferprogramm erhalten Sie beim Anklicken des grünen Buttons "Produkte und Dienstleistungen" oder Sie gehen direkt auf die WEB Seiten von Coiltrade Stahlhandel GmbH.
<G-vec00728-002-s025><click.anklicken><en> Click the 'wrench' icon in the upper right corner and select 'Settings'.
<G-vec00728-002-s025><click.anklicken><de> Den Schraubenschlüssel in der oberen rechten Ecke anklicken und „Einstellungen“ auswählen.
<G-vec00728-002-s026><click.anklicken><en> You will only be sent further information about our offers only if you expressly click on this option, and you can unsubscribe at any time.
<G-vec00728-002-s026><click.anklicken><de> Auch weitere Informationen über unsere Angebote erhalten Sie – jederzeit widerruflich – nur dann, wenn Sie diese Option ausdrücklich anklicken.
<G-vec00728-002-s027><click.anklicken><en> The function will not be automatically loaded, but only if you click the “comments” link.
<G-vec00728-002-s027><click.anklicken><de> Diese Funktion wird nicht automatisch geladen, sondern erst wenn Sie den entsprechenden Link anklicken.
<G-vec00728-002-s028><click.anklicken><en> All this leads to the fact that the declarations of consent presented by the providers are usually long and complicated – and that we increasingly click "I agree" without having thoroughly read and understood everything.
<G-vec00728-002-s028><click.anklicken><de> Dies alles führt dazu, dass die Einwilligungserklärungen, welche die Anbieter uns vorlegen, meist lang und kompliziert sind – und dass wir immer öfter "Ich stimme zu" anklicken, ohne alles gründlich gelesen und verstanden zu haben.
<G-vec00728-002-s029><click.anklicken><en> This only happens if you actively click on one of these social sharing buttons.
<G-vec00728-002-s029><click.anklicken><de> Dies geschieht jedoch erst dann, wenn Sie aktiv eine dieser Schaltflächen anklicken.
<G-vec00728-002-s030><click.anklicken><en> German, English Please click on the link "Show products and services" or on the web address of Braun & Partner GmbH.
<G-vec00728-002-s030><click.anklicken><de> Deutsch, Englisch Das gesamte Lieferprogramm, Adressdaten, Telefon- und Faxnummern finden Sie beim Anklicken des grünen Buttons "Produkte und Dienstleistungen".
<G-vec00728-002-s031><click.anklicken><en> The tracking pixel is loaded on your device when you respond to any ad we send via Twitter, for example when you click on a link to our page.
<G-vec00728-002-s031><click.anklicken><de> Der Zählpixel wird auf Ihrem Endgerät geladen, wenn Sie auf eine von uns über Twitter geschaltete Anzeigen reagieren, etwa weil Sie einen enthaltenen Link auf unsere Seite anklicken.
<G-vec00728-002-s032><click.anklicken><en> Only with this activation is a connection set up with the social network, independent of whether you actually click on the social plugin, or not.
<G-vec00728-002-s032><click.anklicken><de> Erst mit dieser Aktivierung wird eine Verbindung mit dem sozialen Netzwerk aufgebaut, unabhängig davon, ob Sie die Social Plugins tatsächlich anklicken.
<G-vec00728-002-s033><click.anklicken><en> For your security, you will then receive an E-mail containing a confirmation link, please click this link to confirm your E-mail address.
<G-vec00728-002-s033><click.anklicken><de> Zu Ihrer Sicherheit erhalten Sie dann von uns eine E-Mail mit einem Bestätigungslink, den Sie bitte anklicken, um Ihre E-Mail-Adresse zu bestätigen.
<G-vec00728-002-s034><click.anklicken><en> Our contact languages German, English Please click on the green button "Show contact details" and send a message regarding Stainless Steel Kitchens to K2 Edelstahl - technik & Metallbau Berlin.
<G-vec00728-002-s034><click.anklicken><de> Deutsch, Englisch Beim Anklicken des grünen Buttons "Produkte und Dienstleistungen" finden Sie außer Edelstahlküchen noch weitere Angebote von K2 Edelstahl - technik & Metallbau Berlin.
<G-vec00728-002-s035><click.anklicken><en> For example, if you download movie quotes, you can enter a part of some quote into this field and click "Search" to find the movie.
<G-vec00728-002-s035><click.anklicken><de> Zum Beispiel, wenn Sie Zitaten aus Filmen herunterladen, können Sie einen Teil eines Zitats in dieses Feld eingeben und "Suche" anklicken, um den Film zu finden.
<G-vec00728-002-s036><click.anklicken><en> With UBS Safe you can save all your passwords digitally in a secure location – and from 2019, never click on “Forgot my Password" again.
<G-vec00728-002-s036><click.anklicken><de> Mit UBS Safe können Sie all Ihre Passwörter digital an einem sicheren Ort speichern – und in 2019 nie mehr "Passwort vergessen" anklicken.
<G-vec00728-002-s037><click.anklicken><en> You can create a link on another page, then click the link you just inserted, to create the new page:
<G-vec00728-002-s037><click.anklicken><de> Du kannst einen neuen Link auf irgendeiner Seite irgendwo einfügen und diesen neuen Link anklicken, um eine neue Seite anzulegen.
<G-vec00728-002-s152><click.drücken><en> 3) Click on "Start".
<G-vec00728-002-s152><click.drücken><de> 3) Drücken Sie "Start".
<G-vec00728-002-s153><click.drücken><en> Define now a name for the custom field, e.g. 'Value List' and click on 'Save'.
<G-vec00728-002-s153><click.drücken><de> Definieren Sie nun einen Namen für das eigene Feld, zB 'Einsatzgebiet', geben Sie die gewünschten Werte ein und drücken Sie auf 'Speichern'.
<G-vec00728-002-s154><click.drücken><en> From the HP Smart app home screen, select your printer, and then click Printer Settings to open the printer settings screen.
<G-vec00728-002-s154><click.drücken><de> Um das Druckermodell schnell zu finden, halten Sie die Taste STRG gedrückt und drücken Sie dann F, um ein Suchfeld zu öffnen.
<G-vec00728-002-s155><click.drücken><en> Once that's done, scroll to the bottom of the page and click on ENERGIZE.
<G-vec00728-002-s155><click.drücken><de> Wenn das erstmal erledigt ist, gehen Sie zum Ende der Seite und drücken Sie auf ENERGIZE.
<G-vec00728-002-s156><click.drücken><en> We take a white color and click on the red in the middle.
<G-vec00728-002-s156><click.drücken><de> Nehmen Sie die weiße Farbe und drücken Sie die rote in der Mitte.
<G-vec00728-002-s157><click.drücken><en> Click the Options button on the toolbar
<G-vec00728-002-s157><click.drücken><de> Drücken Sie in der Symbolleiste die Schaltfläche Optionen.
<G-vec00728-002-s158><click.drücken><en> Click Extensions → Manage in the top menu.
<G-vec00728-002-s158><click.drücken><de> Drücken Sie Extensions → Manage Im oberen Menü.
<G-vec00728-002-s159><click.drücken><en> Click the Windows logo (on the Taskbar).
<G-vec00728-002-s159><click.drücken><de> Drücken Sie auf der Taskleiste Windows-Logo.
<G-vec00728-002-s160><click.drücken><en> Click once to show the blue pin you can select to adjust a specific edit.
<G-vec00728-002-s160><click.drücken><de> Drücken Sie einmal, um den blauen Pin anzuzeigen, mit dem eine Anpassung gezielt bearbeitet werden kann.
<G-vec00728-002-s161><click.drücken><en> If you want to bookmark a page you are at, just click on Ctrl and D buttons at once.
<G-vec00728-002-s161><click.drücken><de> Wenn Sie auf einer Webseite, auf der Sie sich befinden, ein Lesezeichen setzen wollen, drücken Sie einfach gleichzeitig die Ctrl und D Tasten.
<G-vec00728-002-s162><click.drücken><en> Click on the plus sign to open a drive or folder, click to select it and then click Ok.
<G-vec00728-002-s162><click.drücken><de> Klicken Sie auf den Plus-Zeichen, um das Laufwerk oder den Ordner zu öffnen, klicken Sie es an, um auszuwählen, und drücken Sie OK.
<G-vec00728-002-s163><click.drücken><en> Click "OK" to increase your experience in this site.
<G-vec00728-002-s163><click.drücken><de> Drücken Sie "OK" Ihre Erfahrung auf unserer Seite zu verbessern.
<G-vec00728-002-s164><click.drücken><en> If you want to close the window again, simply click the [options] key once more.
<G-vec00728-002-s164><click.drücken><de> Wenn Sie das Fenster wieder schließen möchten, drücken Sie die [Option] Taste einfach nochmals.
<G-vec00728-002-s165><click.drücken><en> (7) "OK" button Click this button to save your settings and exit the dialog box.
<G-vec00728-002-s165><click.drücken><de> "OK" Taste Drücken Sie diese Taste, um ihre Einstellungen zu speichern und den Dialog zu verlassen.
<G-vec00728-002-s166><click.drücken><en> Click the OK button.
<G-vec00728-002-s166><click.drücken><de> Drücken Sie die Sprachtaste.
<G-vec00728-002-s167><click.drücken><en> If you edit the payment, enter the correct information, then click the Record button
<G-vec00728-002-s167><click.drücken><de> Wenn Sie die Zahlung bearbeiten, geben Sie die richtigen Informationen ein und drücken Sie dann die Schaltfläche Erfassen.
<G-vec00728-002-s168><click.drücken><en> Click Alt+F and scroll over Tools.
<G-vec00728-002-s168><click.drücken><de> Drücken Sie Alt + F, und gehen Sie auf Extras.
<G-vec00728-002-s169><click.drücken><en> Click the operating button and turn on the machine and the knife will be sharpened fully automatically.
<G-vec00728-002-s169><click.drücken><de> Drücken Sie den Bedienknopf, schalten Sie die Maschine an und das Messer wird automatisch geschärft.
<G-vec00728-002-s170><click.drücken><en> Insert your DVD disc into DVD-Rom, then run the program, click "Load DVD" button to load DVD movie to the program.
<G-vec00728-002-s170><click.drücken><de> Legen Sie die Quell-DVD in Ihre Computer-DVD-ROM ein, starten Sie den Ripper, drücken Sie die Taste „DVD Disc“, um die zuvor eingelegte DVD zu importieren.
<G-vec00728-002-s057><click.klicken><en> Every time I read "Displays your 're not a robot", when writing a comment, I consider hard whether I shouldn't click X directly.
<G-vec00728-002-s057><click.klicken><de> Jedes Mal wenn ich kommentiere und dieses "Zeigt das Ihr kein Roboter seid", lese, überlege ich schwer, ob ich nicht schon direkt auf X klicken soll.
<G-vec00728-002-s058><click.klicken><en> Double opt-in – The customer needs to click a link in a confirmation email in order to get the Emarsys opt-in field set to TRUE.
<G-vec00728-002-s058><click.klicken><de> Double Opt-In Der Kunde muss auf einen Link in einer Bestätigungs-E-Mail klicken, um das Emarsys Opt-In-Feld auf TRUE zu setzen.
<G-vec00728-002-s059><click.klicken><en> Right-click the header of the column or row. Choose Insert Rows or Insert Columns.
<G-vec00728-002-s059><click.klicken><de> Eine Spalte wählen Sie aus, indem Sie auf den Spaltenkopf klicken, in dem die Buchstabenkennung der Spalte angezeigt wird.
<G-vec00728-002-s060><click.klicken><en> You can then click “Cookies” and block or allow individual cookies.
<G-vec00728-002-s060><click.klicken><de> Sie können dann auf "Cookies" klicken und einzelne Cookies blockieren oder zulassen.
<G-vec00728-002-s061><click.klicken><en> Click Next.
<G-vec00728-002-s061><click.klicken><de> Auf Next klicken.
<G-vec00728-002-s062><click.klicken><en> You can also click the Advanced >> button and adjust output parameters manually in the Output File section of the Conversion Options tab.
<G-vec00728-002-s062><click.klicken><de> Sie können auch auf den Button Erweitert >> klicken und die Ausgabeparameter manuell in der Sektion Ausgabedatei der Registerkarte Umwandlungsoptionen einstellen.
<G-vec00728-002-s063><click.klicken><en> When it comes to scratch cards online, you can either scratch off the panels one-by-one if you want to prolong the ectasy, or you can click a button that will scratch all the panels off in one fail swoop.
<G-vec00728-002-s063><click.klicken><de> Wenn es darum geht, Karten online freizurubbeln, können Sie die Felder entweder einzeln freirubbeln, wenn Sie die Ekstase ausdehnen möchten oder Sie können auf eine Taste klicken, die alle Felder auf einen Schlag freilegt.
<G-vec00728-002-s064><click.klicken><en> When you click “Go to Circle”, the circle-view view is invoked, and the circle is stretched to fill the viewBox rectangle.
<G-vec00728-002-s064><click.klicken><de> Wenn Sie auf "Go to Circle" klicken, wird die Ansicht circle-view aufgerufen, und der Kreis wird so gestreckt, dass er das viewBox-Rechteck füllt.
<G-vec00728-002-s065><click.klicken><en> You may also click... to browse the repository and find the desired branch.
<G-vec00728-002-s065><click.klicken><de> Sie können auch auf... klicken, um den gewünschten Zweig zu finden.
<G-vec00728-002-s066><click.klicken><en> Click the button "Print" in the bottom right corner to save the PDF file.
<G-vec00728-002-s066><click.klicken><de> Auf den Button "Print" rechts unten klicken, um die Datei zu speichern.
<G-vec00728-002-s067><click.klicken><en> So click on the links below and take a sun-drenched trip along Tropico’s beautiful sandy beaches and almost dormant volcanos (there’s only a 65% chance of an eruption in the coming weeks) by clicking on the links below. El Presidente is back!
<G-vec00728-002-s067><click.klicken><de> Das folgende Video nimmt Einreisewillige mit auf eine sonnenverwöhnte Tour entlang der schönen Sandstrände und fast inaktiven Vulkane von Tropico (in den kommenden Wochen besteht nur eine Chance von 65% auf einen Ausbruch), indem sie auf die unten stehenden Links klicken.
<G-vec00728-002-s068><click.klicken><en> To completely close the Content Optimizer, you can simply click the arrow in the upper right corner of the bar.
<G-vec00728-002-s068><click.klicken><de> Um den Content Optimizer komplett zu schließen, können Sie ganz einfach oben rechts im Balken auf den Pfeil klicken.
<G-vec00728-002-s069><click.klicken><en> Tip: As an alternative to the following procedure, if you have recently opened the site, you can point to Recent Sites on the File menu, and then click the site that you want to open.
<G-vec00728-002-s069><click.klicken><de> Tipp: Alternativ zum folgenden Verfahren können Sie unmittelbar nach dem Öffnen der Website im Menü Datei auf Zuletzt geöffnete Websites zeigen und dann auf die Website klicken, die Sie öffnen möchten.
<G-vec00728-002-s070><click.klicken><en> In order to apply the voucher, the customer need to visit his cart and enter the voucher in the suitable field and click "Add".
<G-vec00728-002-s070><click.klicken><de> Um die Warenkorb-Regel anzuwenden, muss der Kunde seinen Warenkorb besuchen, den Code im Gutschein-Feld eingeben und auf "Hinzufügen" klicken.
<G-vec00728-002-s071><click.klicken><en> If you continue to use this website without changing your cookie settings or you click "Accept" below then you are consenting to this.
<G-vec00728-002-s071><click.klicken><de> Wenn Sie diese Website weiterhin verwenden, ohne die Cookie-Einstellungen zu ändern, oder Sie unten auf "akzeptieren " klicken, stimmen Sie diesem zu.
<G-vec00728-002-s072><click.klicken><en> This window appears after you click the Alter PMFs button.
<G-vec00728-002-s072><click.klicken><de> Dieses Fenster wird angezeigt, wenn Sie auf die Schaltfläche PMFs ändern klicken.
<G-vec00728-002-s073><click.klicken><en> You can click the Publish tab to see redesigned pages that have been published on your sandbox domain.
<G-vec00728-002-s073><click.klicken><de> Sie können auf die Registerkarte Veröffentlichen klicken, um die neu gestalteten Seiten anzuzeigen, die in Ihrer Sandbox-Domain veröffentlicht wurden.
<G-vec00728-002-s074><click.klicken><en> Be sure to click Save after adding student sections.
<G-vec00728-002-s074><click.klicken><de> Achten Sie darauf, nach dem Hinzufügen von Schülerabschnitten auf Speichern zu klicken.
<G-vec00728-002-s075><click.klicken><en> In the appeared list of installed programs, you can find and select [email protected] ransomware and click on Uninstall button.
<G-vec00728-002-s075><click.klicken><de> In der erscheinenden Liste der installierten Programme können Sie [email protected] Ransomware finden und auswählen und auf die Schaltfläche Deinstallieren klicken.
<G-vec00728-002-s076><click.klicken><en> For details on what each of these tools does, click here.
<G-vec00728-002-s076><click.klicken><de> Für Details zu den einzelnen Werkzeugen bitte hier klicken.
<G-vec00728-002-s077><click.klicken><en> For more information about music in the Holocaust, including bibliographic references, click here.
<G-vec00728-002-s077><click.klicken><de> Für weitere Informationen über Musik im Holocaust, einschließlich bibliographischer Hinweise, bitte hier klicken.
<G-vec00728-002-s078><click.klicken><en> German, English For an overview of all available Air Mattresses at EITEL PLASTIC GmbH, please click on the blue link “Show products and services” or on the web address of EITEL PLASTIC GmbH.
<G-vec00728-002-s078><click.klicken><de> Deutsch, Englisch Um einen kompletten Überblick zu Luftmatratzen und weiteren Produkten von EITEL PLASTIC GmbH zu erhalten, benutzen Sie bitte den Link "Lieferprogramm" oder klicken auf die WEB Adresse von EITEL PLASTIC GmbH.
<G-vec00728-002-s079><click.klicken><en> Create a new data feed with the plus symbol (+). Give it a name and then click on Next.
<G-vec00728-002-s079><click.klicken><de> Erstellen Sie nun bitte über das Plus-Symbol einen neuen Datenfeed, vergeben einen Namen und klicken auf Weiter.
<G-vec00728-002-s080><click.klicken><en> message Security check* If you can't read the word, click here.
<G-vec00728-002-s080><click.klicken><de> Nachricht Sicherheitsabfrage* Wenn Sie das Wort nicht lesen können, bitte hier klicken.
<G-vec00728-002-s081><click.klicken><en> Click on these thumbnail images to enlarge them
<G-vec00728-002-s081><click.klicken><de> Bitte auf die einzelnen Bilder klicken, um sie zu vergrößern.
<G-vec00728-002-s082><click.klicken><en> Click here for more information about the Open House.
<G-vec00728-002-s082><click.klicken><de> Bitte hier klicken für weitere Informationen zur Hausmesse.
<G-vec00728-002-s083><click.klicken><en> Simply click on the button below to call the Mac App Store for DubbySnap.
<G-vec00728-002-s083><click.klicken><de> Bitte einfach auf den untenstehenden Button klicken, um den Mac App Store für DubbySnap aufzurufen.
<G-vec00728-002-s084><click.klicken><en> Click here for the English version.
<G-vec00728-002-s084><click.klicken><de> Bitte hier klicken, um die deutsche Version herunterzuladen.
<G-vec00728-002-s085><click.klicken><en> For an overview of all available Gas pressure thermometers at BUSSE Industrietechnik GmbH, please click on the blue link “Show products and services” or on the web address of BUSSE Industrietechnik GmbH.
<G-vec00728-002-s085><click.klicken><de> BUSSE Um einen kompletten Überblick zu Maschinenthermometer und weiteren Produkten von BUSSE Industrietechnik GmbH zu erhalten, benutzen Sie bitte den Link "Lieferprogramm" oder klicken auf die WEB Adresse von BUSSE Industrietechnik GmbH.
<G-vec00728-002-s086><click.klicken><en> Simply click on the button below to call the Mac App Store for Colorblender.
<G-vec00728-002-s086><click.klicken><de> Bitte einfach auf den untenstehenden Button klicken, um den Mac App Store für Colorblender aufzurufen.
<G-vec00728-002-s087><click.klicken><en> adoptapig To view all the products in this shop, click here.
<G-vec00728-002-s087><click.klicken><de> adoptapig Um alle Produkte dieser Boutique zu sehen, bitte hier klicken.
<G-vec00728-002-s088><click.klicken><en> German, English For an overview of all available Ring Brushes at Werkzeug Weber GmbH & Co. KG, please click on the blue link “Show products and services” or on the web address of Werkzeug Weber GmbH & Co.
<G-vec00728-002-s088><click.klicken><de> Um einen kompletten Überblick zu Lötwasserpinsel und weiteren Produkten von Werkzeug Weber GmbH & Co. KG zu erhalten, benutzen Sie bitte den grünen Button "Produkte und Dienstleistungen" oder klicken direkt auf die WEB Adresse von Werkzeug Weber GmbH & Co. KG.
<G-vec00728-002-s089><click.klicken><en> Click on the picture of the carpet you are interested in for more information.
<G-vec00728-002-s089><click.klicken><de> Bitte klicken Sie für ausführlichere Informationen auf den jeweiligen Teppich.
<G-vec00728-002-s090><click.klicken><en> To download, click on the picture (pdf 479 KB).
<G-vec00728-002-s090><click.klicken><de> Zum Download bitte auf das Bild klicken (pdf 318 KB).
<G-vec00728-002-s091><click.klicken><en> Click here to enter the site.
<G-vec00728-002-s091><click.klicken><de> Bitte hier klicken, um weitergeleitet zu werden.
<G-vec00728-002-s092><click.klicken><en> Then click on the link if you want to upload up to 3 more images.
<G-vec00728-002-s092><click.klicken><de> Falls Sie mehr als 3 Bilder hochladen wollen, bitte auf den Link klicken.
<G-vec00728-002-s093><click.klicken><en> Our contact languages German, English For an overview of all available Varnishing machines at Binder GmbH, please click on the blue link “Show delivery programme” or on the web address of Binder GmbH.
<G-vec00728-002-s093><click.klicken><de> Bernhäuser Um einen kompletten Überblick zu Lackierroboter und weiteren Produkten von FANUC FA Deutschland GmbH zu erhalten, benutzen Sie bitte den grünen Button "Produkte und Dienstleistungen" oder klicken direkt auf die WEB Adresse von FANUC FA Deutschland GmbH.
<G-vec00728-002-s094><click.klicken><en> Bran of Shiofan's Borzoi x Each Dog have his own Page. Click on the Photo.
<G-vec00728-002-s094><click.klicken><de> Bran of Shiofan's Borzoi x Jeder Hund hat seine eigene Seite, bitte auf das Foto klicken.
<G-vec00728-002-s190><click.klicken><en> A first mouse click allows to select the point where we want to position the camera and with a second click we will be able to define the direction of the scene setting (this function quickly allows to set the position and orientation of the scene setting point of view).
<G-vec00728-002-s190><click.klicken><de> Auswahl des Werkzeugs Kamera Mit einem ersten Mausklick wählen wir den Punkt aus, wo das Kameraobjektiv positioniert werden soll, mit einem zweiten Klick definieren wir die Richtung für den Bildausschnitt (Position und Orientierung der Szenen-Ansicht können schnell geändert werden).
<G-vec00728-002-s192><click.klicken><en> Click here to watch our video which will show you how to get to the Centre.
<G-vec00728-002-s192><click.klicken><de> Klick hier um unser Video zu sehen, dass dir den Weg zum Zentrum zeigt.
<G-vec00728-002-s193><click.klicken><en> Having access to the Android Market opens up a world of possibilities where hundreds of thousands of apps and games are just a click away.
<G-vec00728-002-s193><click.klicken><de> Der Zugang zum Android Market eröffnet eine Welt der Möglichkeiten, wo Hunderttausende von Anwendungen und Spiele sind nur einen Klick entfernt.
<G-vec00728-002-s194><click.klicken><en> A stellar radio experience is now just a click away –
<G-vec00728-002-s194><click.klicken><de> Ein brillantes Radio-Erlebnis erwartet Euch nur einen Klick weit entfernt.
<G-vec00728-002-s195><click.klicken><en> A click on Install starts the update.
<G-vec00728-002-s195><click.klicken><de> Ein Klick auf Installieren startet das Update.
<G-vec00728-002-s196><click.klicken><en> Help is only a click away, and if required Schuler Service can directly access the machine.
<G-vec00728-002-s196><click.klicken><de> Die Hilfe ist nur einen Klick entfernt, und bei Bedarf kann sich auch der Schuler Service direkt auf die Maschine schalten.
<G-vec00728-002-s197><click.klicken><en> Another click at zoomed state causes the image to full zoom out again.
<G-vec00728-002-s197><click.klicken><de> Ein weiterer Klick im gezoomten Zustand bewirkt, dass das Bild wieder vollständig herauszoomt.
<G-vec00728-002-s198><click.klicken><en> A simple click is all it takes to create the personal climate of choice at home.
<G-vec00728-002-s198><click.klicken><de> Mit nur einem Klick lässt sich das persönliche Wunschklima zuhause schaffen.
<G-vec00728-002-s199><click.klicken><en> At Dubli, every click brings you one step closer to Cash Back.
<G-vec00728-002-s199><click.klicken><de> Bei BSP Rewards bringt dich jeder Klick deinem Cash Back einen Schritt näher.
<G-vec00728-002-s200><click.klicken><en> Click the Skate fish coloring pages to view printable version or color it online (compatible with iPad and Android tablets).
<G-vec00728-002-s200><click.klicken><de> Klick das Bild Fröhliche Fische an, um die Druckversion zu sehen, oder um es online anzumalen (kompatibel mit iPad und Android Tablets).
<G-vec00728-002-s201><click.klicken><en> The solution can connect to all social media pages and candidates can apply with a click on their phone or tablet device.
<G-vec00728-002-s201><click.klicken><de> Die Lösung kann sich mit allen Social-Media-Seiten verbinden und Kandidaten können sich mit einem Klick auf ihr Smartphone oder Tablet bewerben.
<G-vec00728-002-s202><click.klicken><en> How: Drag an vehicle to a lightbox. The lightbox has to be open (click on Triangle).
<G-vec00728-002-s202><click.klicken><de> Der Leuchttisch muss aufgeklappt sein (Klick auf den Dreieckpfeil neben dem Leuchttisch-Namen).
<G-vec00728-002-s203><click.klicken><en> You should hear a little click when the relay is switched on and the LED should go on.
<G-vec00728-002-s203><click.klicken><de> Du solltest einen kleinen Klick hören, wenn das Relai anzieht und die LED sollte angehen.
<G-vec00728-002-s204><click.klicken><en> Otherwise a click on the symbol has no effect.
<G-vec00728-002-s204><click.klicken><de> Ansonsten hat ein Klick auf das Symbol keine Wirkung.
<G-vec00728-002-s205><click.klicken><en> Click the Two Giraffes in Love coloring pages to view printable version or color it online (compatible with iPad and Android tablets).
<G-vec00728-002-s205><click.klicken><de> Klick das Bild Two Giraffes in Love an, um die Druckversion zu sehen, oder um es online anzumalen (kompatibel mit iPad und Android Tablets).
<G-vec00728-002-s206><click.klicken><en> magayo Lotto allows you to download and update the draw results for the supported games easily with a single click.
<G-vec00728-002-s206><click.klicken><de> Mit magayo Lotto können Sie die Ziehungsergebnisse der unterstützten Spiele einfach mit einem einzigen Klick herunterladen und aktualisieren.
<G-vec00728-002-s207><click.klicken><en> Once you have done that, KVV.mobil will open the stadtmobil app when you are about to reserve a car, enabling you to do so with only one click.
<G-vec00728-002-s207><click.klicken><de> Haben Sie sich die App heruntergeladen und dort ein Profil angelegt, öffnet KVV.mobil bei einer Buchungsanfrage die stadtmobil App, sodass Sie Ihr Wunschfahrzeug bequem mit einem Klick reservieren können.
<G-vec00728-002-s208><click.klicken><en> For instance, it can solve this particular problem with just one click.
<G-vec00728-002-s208><click.klicken><de> So kann es beispielsweise dieses spezielle Problem mit nur einem Klick lösen.
<G-vec00728-002-s209><click.klicken><en> Check your PC and network for all kinds of issues in just one easy click.
<G-vec00728-002-s209><click.klicken><de> Überprüfen Sie PC und Netzwerk in nur einem Klick auf alle Arten von Problemen.
<G-vec00728-002-s210><click.klicken><en> Facebook will place a cookie on your computer if you click an ad that has been placed on Facebook by OPTIMAL SYSTEMS.
<G-vec00728-002-s210><click.klicken><de> Bei Klick auf eine von OPTIMAL SYSTEMS auf Facebook geschaltete Anzeige, wird von Facebook ein Cookie auf Ihrem Rechner platziert.
<G-vec00728-002-s211><click.klicken><en> A click on a picture will enlarge it!
<G-vec00728-002-s211><click.klicken><de> Für eine größere Abbildung genügt ein Klick auf das jeweilige Bild.
<G-vec00728-002-s212><click.klicken><en> It is the best Android to nokia contacts transfer. With its help, you can transfer contacts from Android to Nokia just with 1 click.
<G-vec00728-002-s212><click.klicken><de> Mit dessen Hilfe können Sie alle Textnachrichten auf Ihrem alten Android-Handy, Nokia-Handy und iPhone mit einem Klick auf das neue Android-Handy oder iPhone übertragen.
<G-vec00728-002-s213><click.klicken><en> Click the edit button, and then the Add a picture button.
<G-vec00728-002-s213><click.klicken><de> Klick auf den „Bearbeiten“-Button und dann den „Bild hinzufügen“-Button.
<G-vec00728-002-s214><click.klicken><en> To purchase an item worn by a model or contributor, click the “shop for this item” link at the bottom of the picture.
<G-vec00728-002-s214><click.klicken><de> Um ein Produkt zu bestellen, das von einem Model oder einem Wettbewerbs-Teilnehmer getragen wird, klick auf den Produktnamen am unterem Rand des Bildes.
<G-vec00728-002-s215><click.klicken><en> With a click at "edit" you will get to the details view, where you can add rules.
<G-vec00728-002-s215><click.klicken><de> Mit einem Klick auf "bearbeiten" gelangen Sie zur Detailansicht, in der die Regel hinzugefügt wird.
<G-vec00728-002-s216><click.klicken><en> Just click into the picture to watch the movie.
<G-vec00728-002-s216><click.klicken><de> Ein Klick auf das Vorschaubild startet den Film.
<G-vec00728-002-s217><click.klicken><en> Via the pop-up menu (right mouse button click, or the button), the Spectrums catalog and a variety of spectrum generators are available.
<G-vec00728-002-s217><click.klicken><de> Über das Popup-Menü (erreichbar per Klick auf die rechte Maustaste oder den Schalter sind der Spektrenkatalog und die verschiedenen Spektrengeneratoren aufrufbar.
<G-vec00728-002-s218><click.klicken><en> The current status of the Server service and the database to which it is currently connected will be displayed when you click the Server Status button.
<G-vec00728-002-s218><click.klicken><de> Durch Klick auf die Schaltfläche Server Status wird der aktuelle Status des Serverdienstes angezeigt und ebenso, mit welcher Datenbank dieser aktuell verbunden ist.
<G-vec00728-002-s219><click.klicken><en> The nice thing is when you’re on a centralized platform is if there’s a structural change that you make, you can deploy it out across millions of pages at once just with a click of a button.
<G-vec00728-002-s219><click.klicken><de> Das Schöne ist, wenn Sie auf einer zentralen Plattform sind, wenn es eine strukturelle Veränderung gibt, die Sie vornehmen, können Sie sie über Millionen von Seiten auf einmal bereitstellen, nur mit einem Klick auf eine Schaltfläche.
<G-vec00728-002-s220><click.klicken><en> A mere click of the Restore button will instantly export SMS from the backup and save them back on your phone.
<G-vec00728-002-s220><click.klicken><de> Ein Klick auf die Schaltfläche Wiederherstellen exportiert sofort SMS aus dem Backup und speichert sie auf Ihrem Telefon.
<G-vec00728-002-s221><click.klicken><en> Feel the spin of a virtual trackball, the click of a scroll wheel, or the shot of a rifle.
<G-vec00728-002-s221><click.klicken><de> Fühlen Sie die Drehung eines virtuellen Trackballs, den Klick auf ein Mausrad oder den Rückstoß bei einem Gewehrschuss.
<G-vec00728-002-s222><click.klicken><en> • For iPhone 6/6 Plus/5s/5c/5/4s, iPad Air/mini with Retina display/mini, iPad with Retina display, The new iPad, iPad 2, iPod touch 5, you can recover Messages, Contacts, Call History, Calendar, Notes, Reminders, Safari Bookmark, WhatsApp History with a click button of a button.
<G-vec00728-002-s222><click.klicken><de> • Für diese Geräte - iPhone 6/6 Plus/5s/5c/5/4s, iPad Air/mini mit Retina display/mini, iPad mit Retina display, The new iPad, iPad 2 und iPod touch 5 können Sie Nachrichten, Konkakte, Anruflisten, Kalender, Notizen, Erinnerungen, Safari Lesezeichen, WhatsApp Verläufe mit einem Klick auf dem Button wiederherstellen.
<G-vec00728-002-s223><click.klicken><en> You can use the Firefox Screenshots feature to take, download and share screenshots with just a click of a button.
<G-vec00728-002-s223><click.klicken><de> Mit Firefox Screenshots können Sie Bildschirmfotos mit nur einem Klick auf eine Schaltfläche aufnehmen, herunterladen und teilen.
<G-vec00728-002-s224><click.klicken><en> Scroll down and click the entry under Web browser.
<G-vec00728-002-s224><click.klicken><de> Scrolle nach unten und klick auf Web Browser.
<G-vec00728-002-s225><click.klicken><en> The Force Touch trackpad is engineered to deliver a responsive, uniform click no matter where you press the surface.
<G-vec00728-002-s225><click.klicken><de> Das Force Touch Trackpad erzeugt einen reaktionsschnellen, einheitlichen Klick, egal wo du auf die Oberfläche drückst.
<G-vec00728-002-s226><click.klicken><en> For a save an comfortable car trip with your baby you use the Joolz iZi Go Modular baby car seat. In addition, you can attach the car seat to the Hub using the adapters with just one click.
<G-vec00728-002-s226><click.klicken><de> Mit dem Joolz Hub 3-in-1 kannst du dazu noch die beliebte Joolz Babyschale mit nur einem Klick auf den Buggy befestigen, so hast du das ideale Set zu Fuß und die hohe Sicherheit im Auto.
<G-vec00728-002-s227><click.klicken><en> A simple click to an entry will assign the regarding profile to your static data.
<G-vec00728-002-s227><click.klicken><de> Ein einfacher Klick auf einen Eintrag genügt, um das betreffende Profil Ihrer Statik zuzuordnen.
<G-vec00728-002-s228><click.klicken><en> Click a hairstyle, then click locks of hair and select colours for them.
<G-vec00728-002-s228><click.klicken><de> Klicke eine Frisur und dann Haarlocken an, um die Farbe auszusuchen.
<G-vec00728-002-s229><click.klicken><en> Please click on "Save".
<G-vec00728-002-s229><click.klicken><de> Bitte klicke auf "Speichern" (save).
<G-vec00728-002-s230><click.klicken><en> Search for a server and click on "Connect".
<G-vec00728-002-s230><click.klicken><de> Suche Dir einen Server aus und klicke auf „Verbinden“.
<G-vec00728-002-s231><click.klicken><en> If the game freezes, just click inside it (games can get unresponsive if you click elsewhere on the page).
<G-vec00728-002-s231><click.klicken><de> Bär das Spiel einfriert, klicke einfach darauf (Spiele können aufhören zu reagieren wenn man woanders auf der Seite klickt).
<G-vec00728-002-s232><click.klicken><en> Click here for instructions on how to enable JavaScript in your browser. Calendario
<G-vec00728-002-s232><click.klicken><de> Klicke hier für eine Anleitung die dir zeigt, wie du JavaScript in deinem Browser aktivierst.
<G-vec00728-002-s234><click.klicken><en> If you aren't being forwarded, please click here.
<G-vec00728-002-s234><click.klicken><de> Klicke hier falls Du nicht automatisch weitergeleitet wirst.
<G-vec00728-002-s235><click.klicken><en> Open this email and click on the link.
<G-vec00728-002-s235><click.klicken><de> Öffne diese E-Mail und klicke auf den Link.
<G-vec00728-002-s236><click.klicken><en> Click on "Settings" or "Preferences."
<G-vec00728-002-s236><click.klicken><de> Klicke "Einstellungen" oder "Präferenzen" an.
<G-vec00728-002-s238><click.klicken><en> Use Mouse to click on the chocolate blocks to make them disappear.
<G-vec00728-002-s238><click.klicken><de> Klicke mit der Maus auf die Schokoladenblöcke und sie verschwinden.
<G-vec00728-002-s239><click.klicken><en> Find Search.heasycouponsaccess.com related add-ons and click on “Disable” button.
<G-vec00728-002-s239><click.klicken><de> Finde Search.heasycouponsaccess.com zugehörige Add-ons und klicke auf “Disable”.
<G-vec00728-002-s240><click.klicken><en> Click on Zoom.
<G-vec00728-002-s240><click.klicken><de> Klicke Zoom an.
<G-vec00728-002-s241><click.klicken><en> Click on the link below to watch what happened next.
<G-vec00728-002-s241><click.klicken><de> Klicke auf den Link unten und schaue dir an, wie es weitergeht.
<G-vec00728-002-s242><click.klicken><en> Click the "Photos" option in the menu on the left.
<G-vec00728-002-s242><click.klicken><de> Klicke die "Fotos"-Option im linken Menü an.
<G-vec00728-002-s243><click.klicken><en> It will open "Account" tab, now click on the 'Subscription' button.
<G-vec00728-002-s243><click.klicken><de> 2.Es öffnet sich das "Konto" Fenster, klicke nun auf die Schaltfläche 'Abonnement'.
<G-vec00728-002-s244><click.klicken><en> Click here to see to what songs you can dance in the mini disco this summer.
<G-vec00728-002-s244><click.klicken><de> Klicke hier, um zu sehen, zu welchen Liedern im Sommer in der Minidisco getanzt wird.
<G-vec00728-002-s245><click.klicken><en> Click on the dropdown menu and choose the language you want the game in.
<G-vec00728-002-s245><click.klicken><de> Klicke auf das Dropdown-Menü und wähle die Sprache, die du für das Spiel wünscht.
<G-vec00728-002-s246><click.klicken><en> Find .whycry File Virus related add-ons and click on “Disable” button.
<G-vec00728-002-s246><click.klicken><de> Finde .whycry Extension Virus zugehörige Add-ons und klicke auf “Disable”.
<G-vec00728-002-s247><click.klicken><en> From the Tools menu, select "Options." 2. At the "Preferences" tab, under E-mail, click "Junk E-mail."
<G-vec00728-002-s247><click.klicken><de> Wenn Outlook geöffnet und das "Home"-Tab gewählt ist, klicke auf "Junk" (in der "Löschen"-Gruppe) und wähle Junk-E-Mail.
<G-vec00728-002-s248><click.klicken><en> Click the triangle pointing to the category "Buddies".
<G-vec00728-002-s248><click.klicken><de> Klicke auf das Dreieck, das auf die Kategorie "Freunde"(Buddies) zeigt.
<G-vec00728-002-s249><click.klicken><en> Click the red marked word/link "here" below the last text box to get to the overview page of your Discord apps.
<G-vec00728-002-s249><click.klicken><de> Klicke unter dem letzten Textfeld auf das rot markierte Wort "here", um die Übersicht deiner Discord-Apps aufzurufen.
<G-vec00728-002-s250><click.klicken><en> To view your Ranking against the other players, click "Rankings" from the user menu.
<G-vec00728-002-s250><click.klicken><de> Um deinen Rankingplatz unter anderen Spielern zu sehen, klicke im Nutzermenü auf "Ranking"..
<G-vec00728-002-s251><click.klicken><en> Check the box next to "Password protect this Album," choose a password, and click "Save Changes."
<G-vec00728-002-s251><click.klicken><de> Aktiviere die Box neben „Album mit Kennwort absichern", gib ein Kennwort ein und klicke auf Änderungen speichern.
<G-vec00728-002-s252><click.klicken><en> Slack will display the top three records – simply click Show details to see more or to view it in Salesforce.
<G-vec00728-002-s252><click.klicken><de> Slack wird die Top Drei deiner Einträge anzeigen – klicke einfach auf Details anzeigen, um mehr zu sehen oder sie in Salesforce zu öffnen.
<G-vec00728-002-s253><click.klicken><en> Click below to continue to for example 1606 view a listing of cities in the region.
<G-vec00728-002-s253><click.klicken><de> Klicke unten zum Beispiel auf Gelderland, Noord-Brabant und Noord-Holland um eine Übersicht von Städten in der Region einsehen zu können.
<G-vec00728-002-s254><click.klicken><en> - Wilh a pre booked ticket just click „proceed“ to go to the streaming window and use the login data we sent.
<G-vec00728-002-s254><click.klicken><de> - Mit einem Vorverkaufs-Ticket klicke auf „proceed“, um zum Streaming-Fenster zu gelangen, dort dann die von uns gesendeten Login-Daten verwenden.
<G-vec00728-002-s255><click.klicken><en> To add a shop icon, click the camera icon at the bottom right of the image.
<G-vec00728-002-s255><click.klicken><de> Um ein Shop-Symbol hinzuzufügen, klicke rechts neben dem Bild auf das Kamerasymbol.
<G-vec00728-002-s256><click.klicken><en> Click the "Device" icon to open your iPhone's summary tab.
<G-vec00728-002-s256><click.klicken><de> Klicke auf das "Geräte"-Icon, um die Übersicht deines iPhones zu öffnen.
<G-vec00728-002-s257><click.klicken><en> Click the dropdown box under the Footer option in the Insert tab.
<G-vec00728-002-s257><click.klicken><de> Klicke auf das Auswahlmenü unter den Optionen für die Fußzeile in dem Bedienfeld 'Einfügen'.
<G-vec00728-002-s258><click.klicken><en> Click below to continue to for example Dieverbrug, Nieuw-Roden and Schoonebeek, to view a listing of cities in the region.
<G-vec00728-002-s258><click.klicken><de> Klicke unten zum Beispiel auf Barger-Compascuum, Vledderveen und Zuidvelde um eine Übersicht von Städten in der Region einsehen zu können.
<G-vec00728-002-s259><click.klicken><en> 2... click [apply] to display the selected modified wind in the forecast
<G-vec00728-002-s259><click.klicken><de> 2... Klicke auf [Übernehmen], um den ausgewählten modifizierten Wind in der Vorhersage anzuzeigen.
<G-vec00728-002-s260><click.klicken><en> 4 Click the link for your operating system.
<G-vec00728-002-s260><click.klicken><de> 4 Klicke auf den Link für dein Betriebssystem.
<G-vec00728-002-s261><click.klicken><en> Edit any of the fields or options as needed, click save, and your changes will be applied.
<G-vec00728-002-s261><click.klicken><de> Bearbeite alle Felder oder Option nach Belieben und klicke auf Speichern, um deine Änderungen zu übernehmen.
<G-vec00728-002-s262><click.klicken><en> To learn more about this object (including spectral information), click "Explore" to open its Object Explorer entry.
<G-vec00728-002-s262><click.klicken><de> Um mehr über dieses Objekt (einschließlich Spektralinformationen) zu erfahren, klicke auf "Explore", um den Object Explorer aufzurufen.
<G-vec00728-002-s263><click.klicken><en> Group items by a tag: Click the Group button, then choose Tags.
<G-vec00728-002-s263><click.klicken><de> Objekte nach einem Tags gruppieren: Klicke auf die Taste „Gruppe“ und wähle „Tags“ aus.
<G-vec00728-002-s264><click.klicken><en> Click "Start Hotspot" to start your new network.
<G-vec00728-002-s264><click.klicken><de> Klicke auf "Hotspot starten", um dein neues Netzwerk zu starten.
<G-vec00728-002-s265><click.klicken><en> To delete an item, click the item to select it, then click the red X icon at the top of the window.
<G-vec00728-002-s265><click.klicken><de> Klicke das Gerät dafür an und klicke dann oben im Fenster auf das rote X.
<G-vec00728-002-s266><click.klicken><en> When you are finished selecting your metric, you can either click the How button or click Done.
<G-vec00728-002-s266><click.klicken><de> Klicken Sie nach Auswahl der gewünschten Metrik entweder auf How oder Done.
<G-vec00728-002-s267><click.klicken><en> If you want to know more about the products in Power supply, please click the product details to view parameters, models, pictures, prices and other information about Power Inverter,Car Power Inverter,Power Supply.
<G-vec00728-002-s267><click.klicken><de> Wenn Sie mehr über die Produkte in Energieversorgung wissen wollen, klicken Sie bitte die Produktdetails, um Parameter, Modelle, Bilder, Preise und andere Infos zu Wechselrichter,Auto-Wechselrichter,Energieversorgung,,, zu sehen.
<G-vec00728-002-s268><click.klicken><en> German, English If you would like CGE Continental Glass Engineering GmbH to call you back about Glass plant, please click on the button "Display contact details", enter your contact details in the mailing form and click on Send.
<G-vec00728-002-s268><click.klicken><de> CGE Continental Deutsch, Englisch Wenn Sie zu Glasanlagen einen Rückruf von CGE Continental Glass Engineering GmbH wünschen, klicken Sie bitte auf den Link "Kontaktdaten", tragen im Mailformular Ihre Anfragen ein und klicken auf Senden.
<G-vec00728-002-s270><click.klicken><en> If you have not yet linked your account to the Google Account, please click on the appropriate button (see next screenshot).
<G-vec00728-002-s270><click.klicken><de> Falls Sie Ihren Account noch nicht mit dem Google-Account verknüpft haben, klicken Sie bitte auf den entsprechenden Button (siehe nächster Screenshot).
<G-vec00728-002-s271><click.klicken><en> To switch to a different title, simple select a new program (Live or ComeBack TV or Recording) and click on the cast symbol.
<G-vec00728-002-s271><click.klicken><de> Um einen anderen Titel abzuspielen, einfach eine neue Sendung (Live oder Comeback oder Recording) auswählen und auf das Cast Symbol klicken.
<G-vec00728-002-s272><click.klicken><en> Click here to watch.
<G-vec00728-002-s272><click.klicken><de> Hier klicken und anschauen.
<G-vec00728-002-s273><click.klicken><en> Before, users had to manually provide links per Amazon international site to the website visitors, or provide a list of links and let the user choose which one to click on.
<G-vec00728-002-s273><click.klicken><de> Zuvor mussten die Benutzer Links zu den Website-Besuchern manuell über die internationale Website von Amazon bereitstellen oder eine Liste von Links bereitstellen und den Benutzer auswählen lassen, auf welchen er klicken sollte.
<G-vec00728-002-s274><click.klicken><en> "1" up to the number from the heads of the car with the mouse click and create.
<G-vec00728-002-s274><click.klicken><de> "1" bis zu der Anzahl der Köpfe des Autos mit der Maus klicken und zu schaffen.
<G-vec00728-002-s275><click.klicken><en> To download all illustrations of a particular product category at one time, please click on one of the following links.
<G-vec00728-002-s275><click.klicken><de> Um sich sämtliche Zeichnungen einer bestimmten Produktkategorie auf einen Rutsch herunterzuladen, klicken Sie bitte auf einen der nachfolgenden Links.
<G-vec00728-002-s276><click.klicken><en> If you want to know more about the products in Trucks, please click the product details to view parameters, models, pictures, prices and other information about Trucks.
<G-vec00728-002-s276><click.klicken><de> Wenn Sie mehr über die Produkte in Diisocyanat wissen wollen, klicken Sie bitte die Produktdetails, um Parameter, Modelle, Bilder, Preise und andere Infos zu Diisocyanat zu sehen.
<G-vec00728-002-s277><click.klicken><en> If you want to know more about the products in Portable Catalogue, please click the product details to view parameters, models, pictures, prices and other information about Portable Car Washer,Portable Automatic Car Washer,High Pressure Car Washer.
<G-vec00728-002-s277><click.klicken><de> Wenn Sie mehr über die Produkte in Bullet Proof Helm wissen wollen, klicken Sie bitte die Produktdetails, um Parameter, Modelle, Bilder, Preise und andere Infos zu Bullet Proof Helm zu sehen.
<G-vec00728-002-s278><click.klicken><en> Find Shopop under in the list and click Uninstall button near it.
<G-vec00728-002-s278><click.klicken><de> Finden Shopop unter in der Liste und klicken Deinstallieren Taste in der Nähe davon.
<G-vec00728-002-s279><click.klicken><en> If spammers can get enough people to click on fake stories and visit their sites, they’ll make money off the ads they show.
<G-vec00728-002-s279><click.klicken><de> Wenn Spammer genügend Personen dazu bringen, auf ihre Falschmeldungen zu klicken und ihre Seiten zu besuchen, nehmen sie über die dort angezeigten Werbeanzeigen Geld ein.
<G-vec00728-002-s280><click.klicken><en> For an overview of all available Small Electric Motors at ACT Motor GmbH, please click on the blue link “Show products and services” or on the web address of ACT Motor GmbH.
<G-vec00728-002-s280><click.klicken><de> Um eine Übersicht zu Kleinelektromotoren und dem weiteren Lieferprogramm von ACT Motor GmbH zu erhalten, klicken Sie bitte auf den Buttons "Produkte und Dienstleistungen" oder auf die WEB Adresse von ACT Motor GmbH.
<G-vec00728-002-s281><click.klicken><en> For an overview of all available Extrusion Components at EUG Extrusions- und Gummitechnik GmbH, please click on the blue link “Show products and services” or on the web address of EUG Extrusions- und Gummitechnik GmbH.
<G-vec00728-002-s281><click.klicken><de> Um eine Übersicht zu allen verfügbaren Extrusionsteile bei EUG Extrusions- und Gummitechnik GmbH zu erhalten, klicken Sie bitte auf den blauen Link "Lieferprogramm" oder auf die WEB Adresse von EUG Extrusions- und Gummitechnik GmbH.
<G-vec00728-002-s282><click.klicken><en> Alternatively to the browser add-on or within browsers on mobile devices, you can also click the following link to prevent future collection by Google Analytics within this website (the opt-out works only in this browser and only for this domain).
<G-vec00728-002-s282><click.klicken><de> Alternativ zum Browser-Plugin können Sie diesen Link klicken, um die Erfassung durch Google Analytics auf dieser Website zukünftig zu verhindern.
<G-vec00728-002-s283><click.klicken><en> Find WikiTime under in the list and click Uninstall button near it.
<G-vec00728-002-s283><click.klicken><de> Finden WikiTime unter in der Liste und klicken Deinstallieren Taste in der Nähe davon.
<G-vec00728-002-s284><click.klicken><en> Two clicks for increased data protection: the button only activates once you click here. You can then send your recommendation to Google+.
<G-vec00728-002-s284><click.klicken><de> 2 Klicks für mehr Datenschutz: Erst wenn Sie hier klicken, wird der Button aktiv und Sie können Ihre Empfehlung an Google+ senden.
<G-vec00728-002-s285><click.klicken><en> Tip: If you want to import a folder, please click the "Add files to iPod" drop-down button, and choose the "Add Folder to List" option.
<G-vec00728-002-s285><click.klicken><de> Tipp: Wenn Sie einen Ordner importieren möchten, klicken Sie bitte auf "Den Ordner zum Gerät hinzufügen".
<G-vec00728-002-s286><click.klicken><en> In the Junk folder, select the message or messages you want to delete, then click the Delete button in the toolbar.
<G-vec00728-002-s286><click.klicken><de> Auf dem Mac wählen Sie die E-Mail aus und klicken in der Mail-Symbolleiste auf die Taste "Keine Werbung".
<G-vec00728-002-s287><click.klicken><en> For a route-planning please click the appropriate link in the info-window and enter your location.
<G-vec00728-002-s287><click.klicken><de> Für eine Routenplanung klicken Sie bitte auf den entsprechenden Link im kleinen Infofenster und geben Ihren Standort an.
<G-vec00728-002-s288><click.klicken><en> We then need to click the temperature value within the data set.
<G-vec00728-002-s288><click.klicken><de> Anschließend klicken wir im Datensatz auf den Wert der Temperatur.
<G-vec00728-002-s289><click.klicken><en> On the Before You Begin page of the Validate a Configuration Wizard, click Next.
<G-vec00728-002-s289><click.klicken><de> Klicken Sie auf der Seite Vorbemerkungen des Konfigurationsüberprüfungs-Assistenten auf Weiter.
<G-vec00728-002-s290><click.klicken><en> To add picture watermark, please click "Add Picture Watermark" button, and choose a picture in the dialog that opens, and adjust the settings below.
<G-vec00728-002-s290><click.klicken><de> Um Bildwasserzeichen hinzuzufügen, klicken Sie bitte auf „Bildwasserzeichen hinzufügen“, wählen Sie ein Bild aus dem geöffneten Dialog aus und passen Sie die Einstellungen an.
<G-vec00728-002-s291><click.klicken><en> If you are looking for a rental car in Sweden, but in a city other than Uppsala, please click through to the Car rental Sweden page, where you can choose in which city in Sweden you want to rent a car. Book
<G-vec00728-002-s291><click.klicken><de> Wenn Sie einen Mietwagen in Großbritannien suchen, aber gerne in einer anderen Stadt als Wellingborough, klicken Sie bitte durch zu der Autovermietung Großbritannien Seite, auf der Sie aussuchen können, in welcher Stadt in Großbritannien Sie Ihr Fahrzeug mieten wollen.
<G-vec00728-002-s292><click.klicken><en> If you need to bind a text box to a different field, right-click the text box, and then click Change Binding on the shortcut menu.
<G-vec00728-002-s292><click.klicken><de> Wenn Sie ein Textfeld an ein anderes Feld binden müssen, klicken Sie mit der rechten Maustaste auf das Textfeld und klicken dann im Kontextmenü auf Bindung ändern.
<G-vec00728-002-s293><click.klicken><en> To edit a subquery in the Query Editor, highlight the subquery in the Criteria box, and click the Expression Editor button.
<G-vec00728-002-s293><click.klicken><de> Unterabfrage bearbeiten Um eine Unterabfrage im Abfrage-Editor zu bearbeiten, markieren Sie das Feld Kriterien und klicken auf die Schaltfläche Ausdruck-Editor.
<G-vec00728-002-s294><click.klicken><en> For route planning, please click on the red marker and then “directions to”.
<G-vec00728-002-s294><click.klicken><de> Für eine Routenplanung klicken Sie bitte auf die rote Markierung und dann auf „Wegbeschreibung hierher“.
<G-vec00728-002-s295><click.klicken><en> If you are looking for a rental car in Norway, but in a city other than Sandane, please click through to the Car rental Norway page, where you can choose in which city in Norway you want to rent a car.
<G-vec00728-002-s295><click.klicken><de> Wenn Sie einen Mietwagen in Norwegen suchen, aber gerne in einer anderen Stadt als Drammen, klicken Sie bitte durch zu der Autovermietung Norwegen Seite, auf der Sie aussuchen können, in welcher Stadt in Norwegen Sie Ihr Fahrzeug mieten wollen.
<G-vec00728-002-s296><click.klicken><en> After choosing the proper version you can save tags (click "Save tracks info").
<G-vec00728-002-s296><click.klicken><de> Danach klicken wir "Tags speichern" auf der Werkzeugleiste an (2).
<G-vec00728-002-s297><click.klicken><en> When you click on a menu item, subitems appear directly under the item. These enable you to navigate directly to the individual categories.
<G-vec00728-002-s297><click.klicken><de> Wenn Sie auf einen Menüpunkt klicken, klappt direkt unter dem Punkt die Subnavigation auf, mit der Sie in den einzelnen Rubriken navigieren können.
<G-vec00728-002-s298><click.klicken><en> Deutsch Français English Español Italiano To access downloads for your registered product please enter your name, email address and serial number below and then click the submit button.
<G-vec00728-002-s298><click.klicken><de> Um Downloads für das von Ihnen registrierte Produkt aufzurufen, geben Sie nachfolgend bitte Ihren Namen, die E-Mail-Adresse und die Seriennummer ein und klicken dann auf die Schaltfläche „Senden“.
<G-vec00728-002-s299><click.klicken><en> And then you can click the "Start" button to start the ripping process.
<G-vec00728-002-s299><click.klicken><de> Jetzt klicken Sie auf die Start Taste und beginnen den Konvertierungsprozess.
<G-vec00728-002-s300><click.klicken><en> If you want Cakewalk to send this bank every time you open this project, make sure the bank is selected (highlighted), then click the Sysx view Settings menu and choose Auto Send on/off.
<G-vec00728-002-s300><click.klicken><de> Soll SONAR die soeben importierte SysEx-Bank bei jedem Öffnen der Projektdatei automatisch an Ihr Instrument senden, so markieren Sie die Bank erneut, klicken auf das Menü Einstellungen der SysEx-Ansicht und wählen Automatisch senden ein/aus aus.
<G-vec00728-002-s301><click.klicken><en> Select the image and click Insert.
<G-vec00728-002-s301><click.klicken><de> Wir markieren ein Bild und klicken auf Einfügen.
<G-vec00728-002-s302><click.klicken><en> When you are finished, click Resize.
<G-vec00728-002-s302><click.klicken><de> Klicken Sie abschließend auf Resize (Größe ändern).
<G-vec00728-002-s303><click.klicken><en> In case you want to re-import your landing page design package after making some changes to it, you can click Clear in the settings menu.
<G-vec00728-002-s303><click.klicken><de> Wenn Sie das Designpaket mit der Einstiegsseite erneut importieren möchten, nachdem Sie dieses geändert haben, klicken Sie im Einstellungsmenü auf Entfernen.
<G-vec00728-002-s304><click.klicken><en> We don't have any links related to Nantwich Town - if you would like to submit one, click the link below.
<G-vec00728-002-s304><click.klicken><de> Wir haben keine Links in Bezug zu Nantwich Town - wenn Sie einen eintragen möchten, klicken Sie den Link unten.
<G-vec00728-002-s305><click.klicken><en> Click on the logo to go to the website of the respective association or network.
<G-vec00728-002-s305><click.klicken><de> Klicken Sie auf das Logo, um auf die Website des jeweiligen Vereins oder Netzwerks zu gelangen.
<G-vec00728-002-s306><click.klicken><en> Please click on the green button "Show contact details" and send a message regarding Wound supply systems to ADL Anti Dekubitus Lagerungssysteme GmbH.
<G-vec00728-002-s306><click.klicken><de> Klicken Sie bitte auf den Link "Kontaktdaten anzeigen" und schreiben an ADL Anti Dekubitus Lagerungssysteme GmbH eine Mail.
<G-vec00728-002-s307><click.klicken><en> Step 3. Here Click All Add-ons and choose Igffinancial.com pop-up for its removal.
<G-vec00728-002-s307><click.klicken><de> Schritt 3 – Klicken Sie hier alle Add-Ons und wählen Sie Igffinancial.com pop-up, um loszuwerden.
<G-vec00728-002-s308><click.klicken><en> Then click on "Advanced settings".
<G-vec00728-002-s308><click.klicken><de> Klicken Sie anschließend auf "Erweiterte Einstellungen".
<G-vec00728-002-s309><click.klicken><en> Our contact languages German, English For an overview of all available Garden wood at Alfred Schönthaler GmbH, please click on the blue link “Show products and services” or on the web address of Alfred Schönthaler GmbH.
<G-vec00728-002-s309><click.klicken><de> Unsere Korrespondenzsprachen Deutsch, Englisch Klicken Sie bitte auf den Link "Lieferprogramm" oder auf die WEB Adresse von A.Karstensen GmbH & Co. KG.
<G-vec00728-002-s310><click.klicken><en> Albufeira Click to see all this supplier's products.
<G-vec00728-002-s310><click.klicken><de> Albufeira Klicken Sie, um alle Produkte dieses Lieferanten zu sehen.
<G-vec00728-002-s311><click.klicken><en> Standards The Best of Frankfurt Click here to see more properties near popular landmarks in Frankfurt
<G-vec00728-002-s311><click.klicken><de> Das Beste von Frankfurt am Main Klicken Sie hier, um mehr Unterkünfte in der Nähe von bekannten Sehenswürdigkeiten in Frankfurt am Main zu sehen.
<G-vec00728-002-s312><click.klicken><en> Click on each ingredient below for a full description.
<G-vec00728-002-s312><click.klicken><de> Klicken Sie auf jeden Inhaltsstoff hierunter für eine vollständige Beschreibung.
<G-vec00728-002-s313><click.klicken><en> Click here to register: // Create a new account
<G-vec00728-002-s313><click.klicken><de> Klicken Sie hier, um sich zu registrieren: // Artikelnr.
<G-vec00728-002-s314><click.klicken><en> The mouse on the chart you can select the interesting time interval, and when you click on the upper circle to get all the earthquakes occurred during the selected hour, including over the last.
<G-vec00728-002-s314><click.klicken><de> Mit der Maus auf der Kurve markieren Sie bitte den gewünschten Zeitraum, und klicken Sie auf dessen Obere Kreis — Holen Sie sich alle Erdbeben für die ausgewählte Stunde, einschließlich der letzten.
<G-vec00728-002-s315><click.klicken><en> Click, if you do not support Ahmed Nazif.
<G-vec00728-002-s315><click.klicken><de> Klicken Sie, falls Sie Horst Köhler nicht unterstützen.
<G-vec00728-002-s316><click.klicken><en> Click on the respective Borgers company whose General Conditions of Sale you are looking for.
<G-vec00728-002-s316><click.klicken><de> Klicken Sie die jeweilige Borgers-Gesellschaft an, deren Verkaufsbedingungen Sie suchen.
<G-vec00728-002-s317><click.klicken><en> As soon as you can see the dialog window please click on "save file" or "run".
<G-vec00728-002-s317><click.klicken><de> Sobald sich das Dialogfeld öffnet klicken Sie bitte auf "Datei speichern" oder "Ausführen".
<G-vec00728-002-s318><click.klicken><en> Mac To set this "desktop backgrounds - Transformers, #17253" as wallpaper background on your desktop, select above resolution links, then click on the "Download" button to save image on your desktop computer.
<G-vec00728-002-s318><click.klicken><de> Mac Um "Transformatoren - Desktop Wallpapers, #17253" als Hintergrundbild auf Ihrem Desktop zu setzen, wählen Sie die Bildauflösung oben und klicken Sie auf den Button "Herunterladen", Bild auf Ihrem PC zu speichern.
<G-vec00728-002-s319><click.klicken><en> If you want to read more about our EMC competences click here Solaris-Shield™
<G-vec00728-002-s319><click.klicken><de> Wenn Sie mehr über unsere EMV-Kompetenzen erfahren möchten, klicken Sie bitte hier.
<G-vec00728-002-s320><click.klicken><en> Click HERE to create your own souvenir key tag design
<G-vec00728-002-s320><click.klicken><de> Klicken Sie HIER, um Ihren eigenen Souvenir-Acrylschlüsselanhänger zu gestalten.
<G-vec00728-002-s321><click.klicken><en> Click on 'Edit' > 'Add Outline item' or simply click ⌘⇧D.
<G-vec00728-002-s321><click.klicken><de> Klicken Sie auf 'Bearbeiten' > 'Gliederungselement hinzufügen' oder verwenden Sie die Tastenkombination ⌘⇧D.
<G-vec00728-002-s322><click.klicken><en> The Best of San Carlos de Bariloche Click here to see more properties near popular landmarks in San Carlos de Cities
<G-vec00728-002-s322><click.klicken><de> Das Beste von San Carlos de Bariloche Klicken Sie hier, um mehr Unterkünfte in der Nähe von bekannten Sehenswürdigkeiten in San Carlos de Bariloche zu sehen.
<G-vec00728-002-s323><click.klicken><en> To add your support, click here.
<G-vec00728-002-s323><click.klicken><de> Wenn ihr sie unterschreiben möchtet, klickt hier.
<G-vec00728-002-s324><click.klicken><en> Personal information can contain certain personal information - for example, if you click to "remember me" when logging in, a cookie will store your username.
<G-vec00728-002-s324><click.klicken><de> Manche Cookies beinhalten persönliche Informationen – ein Beispiel: Klickt man beim Anmelden auf “Angemeldet bleiben”, speichert ein Cookie den Benutzernamen.
<G-vec00728-002-s325><click.klicken><en> Each Hotels’ Check-in time varies, please click on the 'more info' option which is available when you select a specific hotel.
<G-vec00728-002-s325><click.klicken><de> Die Anreiseuhrzeit unterscheidet sich bei jedem Hotel, bitte klickt bei eurem Hotel auf "Weitere Informationen".
<G-vec00728-002-s326><click.klicken><en> With the Detail layer selected, click on the image where the blemish is:
<G-vec00728-002-s326><click.klicken><de> Während die „Detail“-Ebene ausgewählt ist, klickt auf dem Bild auf die Unreinheiten.
<G-vec00728-002-s327><click.klicken><en> If you want to read the full story of the wonderful wedding in Berlin please click here.
<G-vec00728-002-s327><click.klicken><de> Wenn ihr die ganze Geschichte dieser wunderbaren Hochzeit in Berlin lesen wollt klickt hier.
<G-vec00728-002-s328><click.klicken><en> If you don't want to put up the building, click on the crossed out wooden wheel without selecting any raw materials.
<G-vec00728-002-s328><click.klicken><de> Möchte man das Gebäude nicht bauen, wählt man keine Rohstoffe aus und klickt auf das durchkreuzte Holzrad.
<G-vec00728-002-s329><click.klicken><en> If you want to know where, you still can get that hot piece or need inspiration, how to style it, click here.
<G-vec00728-002-s329><click.klicken><de> Wenn ihr wissen wollt, wo man das begehrte Teil noch kriegen kann oder Inspirationen braucht, wie man es stylt, klickt hier.
<G-vec00728-002-s330><click.klicken><en> Then click on the desired material type, select the quantity that you would like to buy/sell and then complete the transaction with the "ausführen" button.
<G-vec00728-002-s330><click.klicken><de> Dann klickt man den gewünschten Rohstoff an, wählt die Anzahl, die man ver/kaufen möchte und tätigt die Transaktion mit "ausführen".
<G-vec00728-002-s331><click.klicken><en> Click Next and you'll see the cube moving in a preview.
<G-vec00728-002-s331><click.klicken><de> Klickt Weiter und Ihr seht, wie sich der Würfel in der Vorschau bewegt.
<G-vec00728-002-s332><click.klicken><en> Then you click on the button which looks like a monitor.
<G-vec00728-002-s332><click.klicken><de> Dann klickt ihr auf das monitorähnliche Symbol.
<G-vec00728-002-s333><click.klicken><en> If you click directly on the edit button of a template, you get to the receipts.
<G-vec00728-002-s333><click.klicken><de> Klickt man direkt auf den Bearbeitungsbutton bei einer Vorlage (Bearbeitung von Belegen), gelangt man zu den Belegen.
<G-vec00728-002-s334><click.klicken><en> If you would like more information, simply click on the images and you get the full information on each of the pictured products.
<G-vec00728-002-s334><click.klicken><de> Wenn Ihr mehr Infos möchtet, klickt einfach auf die Bilder und Ihr bekommt die volle Info jeweils zu dem abgebildeten Produkt.
<G-vec00728-002-s335><click.klicken><en> If you want to learn more about the individual and technical steps, just click here.
<G-vec00728-002-s335><click.klicken><de> Falls ihr noch mehr über die einzelnen und auch technischen Schritte erfahren möchtet, klickt einfach hier.
<G-vec00728-002-s336><click.klicken><en> Just select the game mode you'd like to play and click the "I will invite my own teammates" button to begin inviting friends to join you.
<G-vec00728-002-s336><click.klicken><de> Wählt einfach den Spielmodus, den ihr bevorzugt, und klickt die "Ich werde meine eigenen Teammitglieder einladen"-Schaltfläche, um mit der Einladung eurer Freunde zu beginnen.
<G-vec00728-002-s337><click.klicken><en> Click here for more information and registration.
<G-vec00728-002-s337><click.klicken><de> Klickt hier für mehr Informationen und Anmeldung.
<G-vec00728-002-s338><click.klicken><en> For example, someone searching “buy coffee table” is likely to click on many results to see what’s out there.
<G-vec00728-002-s338><click.klicken><de> Jemand, der nach „Kaffeetisch kaufen“ sucht, klickt wahrscheinlich auf viele Ergebnisse, um zu sehen, was es alles gibt.
<G-vec00728-002-s339><click.klicken><en> Click on Load video to unblock YouTube.
<G-vec00728-002-s339><click.klicken><de> Klickt auf Video laden, um die Blockierung zu YouTube aufzuheben.
<G-vec00728-002-s340><click.klicken><en> Click through the photos below to get an idea of our evening...
<G-vec00728-002-s340><click.klicken><de> Klickt euch einfach durch die Bilder unten...
<G-vec00728-002-s341><click.klicken><en> If users also want to become co-organizers of the event on the XING platform, they simply click on „Sales Channels > Event on XING> Edit event on XING“.
<G-vec00728-002-s341><click.klicken><de> Wenn ein Nutzer auch Mitveranstalter des Events auf XING werden möchte, klickt er einfach auf „Verkaufskanäle > Event auf XING > Event auf XING bearbeiten“.
<G-vec00728-002-s399><click.klicken><en> Please click on the link "Show products and services" or on the web address of SYNCRAFT® Engineering GmbH. You will then see an overview for High Frequency Assembly and other offers from SYNCRAFT® Engineering GmbH.
<G-vec00728-002-s399><click.klicken><de> Um einen kompletten Überblick zu Hochfrequenztechnik und weiteren Produkten von EPA GmbH zu erhalten, benutzen Sie bitte den grünen Button "Produkte und Dienstleistungen" oder klicken direkt auf die WEB Adresse von EPA GmbH.
<G-vec00728-002-s400><click.klicken><en> More technical info's are to be found in the data sheet, just click at the info button, pls.
<G-vec00728-002-s400><click.klicken><de> Details entnehmen Sie bitte dem Datenblatt, dazu auf den Info-Button klicken.
<G-vec00728-002-s401><click.klicken><en> Admins can click on any item in the security report that has one or more affected users.
<G-vec00728-002-s401><click.klicken><de> Als Administrator können Sie auf jeden Eintrag im Sicherheitsbericht klicken, für den es einen oder mehrere betroffene Benutzer gibt.
<G-vec00728-002-s402><click.klicken><en> If you should delete your cookies, you will need to click the link again.
<G-vec00728-002-s402><click.klicken><de> Löschen Sie Ihre Cookies, müssen Sie den Link erneut klicken.
<G-vec00728-002-s403><click.klicken><en> Click Forgot Your Password on the sign-in page.
<G-vec00728-002-s403><click.klicken><de> Sie können auf der Anmeldeseite auf Passwort vergessen klicken.
<G-vec00728-002-s404><click.klicken><en> Configure the scanner by opening the "Avira Control Center", then click on Extras → Configuration.
<G-vec00728-002-s404><click.klicken><de> Konfigurieren Sie den Scanner indem Sie das "Avira Control Center" öffnen, dann auf Extras → Konfiguration klicken.
<G-vec00728-002-s405><click.klicken><en> Our contact languages German, English Please click on the link "Show products and services" or on the web address of Janz.
<G-vec00728-002-s405><click.klicken><de> Deutsch, Englisch Um sich einen Überblick über alle verfügbaren Bühnenlichteffekte bei Kirchhoff GmbH zu verschaffen, benutzen Sie bitte den Link "Lieferprogramm anzeigen" oder klicken auf die WEB Adresse von Kirchhoff GmbH.
<G-vec00728-002-s406><click.klicken><en> Click on the ‘Insert to page’ button in the navigation bar at the top of the screen.
<G-vec00728-002-s406><click.klicken><de> Sie können außerdem auf den ‚Bilder und Videos hinzufügen‘-Knopf klicken, der sich oben im Fenster der Anwendung befindet.
<G-vec00728-002-s407><click.klicken><en> Please be sure to click on the Save button for the block as well.
<G-vec00728-002-s407><click.klicken><de> Bitte vergewissern Sie sich das Sie auch auf die Speichern Taste der bearbeiteten Blocks klicken.
<G-vec00728-002-s408><click.klicken><en> Click on the picture above to display my personal profile and contact info.
<G-vec00728-002-s408><click.klicken><de> Sie können auch auf mein Bild klicken, um mein persönliches Profil und meine Kontaktdaten aufzurufen.
<G-vec00728-002-s409><click.klicken><en> Our contact languages German, English For an overview of all available Pocket Calendars at Büro Profi Potsdam GmbH, please click on the blue link “Show products and services” or on the web favoritesAdded to favorites
<G-vec00728-002-s409><click.klicken><de> Unsere Korrespondenzsprachen Deutsch, Englisch Eine Übersicht zu den Kontaktdaten von Büro Profi Potsdam GmbH mit Telefonnummern, Adresse und Mailformular erhalten Sie, wenn Sie den Link "Kontaktdaten" klicken.
<G-vec00728-002-s410><click.klicken><en> This can help customers make a more qualified decision about whether to click on your ads.
<G-vec00728-002-s410><click.klicken><de> So unterstützen Sie Ihre Kunden dabei, eine differenziertere Entscheidung darüber zu treffen, ob sie auf Ihre Anzeigen klicken.
<G-vec00728-002-s411><click.klicken><en> Two clicks for more data privacy: click here to activate the button and send your recommendation.
<G-vec00728-002-s411><click.klicken><de> 2 Klicks für mehr Datenschutz: Erst wenn Sie hier klicken, wird der Button aktiv und Sie können Ihre Empfehlung senden.
<G-vec00728-002-s412><click.klicken><en> Remove the GPU from its antistatic packaging and carefully align it with both the rear retention bracket and the slot itself, and then gently push it into the PCIe* x16 slot (you may hear a click).
<G-vec00728-002-s412><click.klicken><de> Entnehmen Sie die Grafikkarte aus ihrer antistatischen Verpackung und richten Sie sie sorgfältig sowohl an der hinteren Halterung als auch am Steckplatz selbst aus, und drücken Sie sie anschließend vorsichtig in den PCIe*-x16-Steckplatz (dabei hören Sie möglicherweise ein Klicken).
<G-vec00728-002-s413><click.klicken><en> Use the mouse to click on the different pieces of the puzzle to rotate them around to get the configuration you want.
<G-vec00728-002-s413><click.klicken><de> Benutzen Sie die Maus, um auf die verschiedenen Teile des Puzzles zu klicken,und diese umzudrehen um die Konfiguration zu erhalten, die Sie wollen.
<G-vec00728-002-s415><click.klicken><en> Step 3. Click on the button marked "convert" and you will be able to start the entire process.
<G-vec00728-002-s415><click.klicken><de> Sobald all diese Schritte abgeschlossen sind, müssen Sie auf die Schaltfläche "Konvertieren" klicken und warten, bis der Konvertierungsvorgang abgeschlossen hat.
<G-vec00728-002-s416><click.klicken><en> Our contact languages German, English Please click on the link "Show products and services" or on the web address of Albrecht Werkzeuge + Maschinen Handelsgesellschaft mbH.
<G-vec00728-002-s416><click.klicken><de> Deutsch, Englisch Um einen kompletten Überblick zu Feilkloben und weiteren Produkten von albw Handels GmbH zu erhalten, benutzen Sie bitte den Link "Lieferprogramm" oder klicken auf die WEB Adresse von albw Handels GmbH.
<G-vec00728-002-s417><click.klicken><en> To edit rules, click on the “Edit” button in the lower left corner of the Configuration window.
<G-vec00728-002-s417><click.klicken><de> Sie können auch auf die Pfeil-Schaltfläche in der oberen rechten Ecke dieses Fensters klicken, um die Haupt-Benutzeroberfläche von NetBarrier X8 zu öffnen.
