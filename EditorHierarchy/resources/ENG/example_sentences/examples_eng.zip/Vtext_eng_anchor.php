<G-vec01141-002-s097><anchor.ankern><en> Ithaca is the smaller one of both and has gorgeous bays to anchor in.
<G-vec01141-002-s097><anchor.ankern><de> Ithaka ist die kleinere der beiden Inseln und hat atemberaubende Buchten zum Ankern.
<G-vec01141-002-s098><anchor.ankern><en> You can anchor at the Bight and then explore the famous treasure caves.
<G-vec01141-002-s098><anchor.ankern><de> Man kann in einer Bucht ankern und von dort aus die berühmten Schatzhöhlen erkunden.
<G-vec01141-002-s099><anchor.ankern><en> We go upriver and anchor in Skradin, shortly before the famous Krka waterfalls.
<G-vec01141-002-s099><anchor.ankern><de> Wir fahren flussaufwärts und ankern in Skradin, kurz vor den berühmten Krka-Wasserfällen.
<G-vec01141-002-s100><anchor.ankern><en> Within a distance of 200m around the pier it is prohibited to drop anchor so as not to hinder the passing of public transportation.
<G-vec01141-002-s100><anchor.ankern><de> Ankern ist im Umfeld von 200 Metern vom Kaikopf verboten, um der Steuerung der öffentlichen Schiffsverkehrmittel nicht im Wege zu sein; Freizeitsegler können an der Nordseite des Kais entlang anlegen.
<G-vec01141-002-s101><anchor.ankern><en> After the second Törntag also driving licence-free crews over the Plauer lake there may drive and beside the city Brandenburg the idyllische sea-chain of the Beetzsee Riewendsee water way explore and for example for bathing anchor.
<G-vec01141-002-s101><anchor.ankern><de> Nach dem zweiten Törntag dürfen auch führerscheinfreie Crews über den Plauer See fahren und neben der Stadt Brandenburg die idyllische Seenkette der Beetzsee-Riewendsee-Wasserstraße erkunden und dort zum Beispiel zum Baden ankern.
<G-vec01141-002-s102><anchor.ankern><en> In order to stay near the beach, we usually anchor at the edge of Salinas, in front of Sa Trinxa.
<G-vec01141-002-s102><anchor.ankern><de> Um nahe des Strandes verweilen zu können, ankern wir meist etwas am Rand vor Salinas vor dem Beachclub Sa Trinxa.
<G-vec01141-002-s103><anchor.ankern><en> The music was at anchor, where we wanted to rest a bit, a bit too loud.
<G-vec01141-002-s103><anchor.ankern><de> Die Musik war beim Ankern, wo wir eigentlich ein bisschen Ruhe wollten, etwas zu laut.
<G-vec01141-002-s104><anchor.ankern><en> On our way back we maybe have the opportunity to visit the harbour of "Ocumare de la Costa" or we anchor in the bay of Cata.
<G-vec01141-002-s104><anchor.ankern><de> Auf unserer Rückfahrt haben wir vielleicht noch Gelegenheit, dem Hafen von Ocumare einen Besuch abzustatten, oder in der Bucht von Cata zu ankern, bevor wir gegen 17.00 Uhr wieder nach Puerto Colombia zurückkehren.
<G-vec01141-002-s105><anchor.ankern><en> At the end of a long day we anchor in the Moonlight Cove, a small bay at the eastern side of the Mc Carty Fiord.
<G-vec01141-002-s105><anchor.ankern><de> Am Ende eines langen Tages ankern wir in der Moonlight Cove, einer kleinen Bucht kurz vor dem Ausgang des Mc Carty Fjords.
<G-vec01141-002-s106><anchor.ankern><en> In the early afternoon we work our way in between the shallows and anchor off Mormake Dupu village dock with the help of the brothers Idelfonso and Venancio in their dugout.
<G-vec01141-002-s106><anchor.ankern><de> Am fruehen Nachmittag ankern wir mit Hilfe der Brueder Idelfonso und Venancio gegenueber dem Dock von Mormake Dupu.
<G-vec01141-002-s107><anchor.ankern><en> Before we reach the port in Sali, we shall naturally drop anchor in one of the coves and take a swimming break. DAY 4
<G-vec01141-002-s107><anchor.ankern><de> Bevor wir in den Hafen von Sali einlaufen, ankern wir natürlich in einer der zahlreichen Buchten mit glasklarem Wasser, um ein erfrischendes Bad zu nehmen.
<G-vec01141-002-s108><anchor.ankern><en> The navigator is recommended to anchor in the surroundings of the small island.
<G-vec01141-002-s108><anchor.ankern><de> Den Skippern wird empfohlen, in der unmittelbaren Umgebung der kleinen Inseln zu ankern.
<G-vec01141-002-s109><anchor.ankern><en> On the next day we sail through lots of fishing boats and nets past a wonderful mangrove forest and anchor in the northwest of Penang.
<G-vec01141-002-s109><anchor.ankern><de> Am nächsten Tag segeln wir durch ein Gewirr an Fischerbooten hindurch an einer schönen Mangrovenküste vorbei und ankern im Nordwesten von Penang.
<G-vec01141-002-s110><anchor.ankern><en> We anchor in a little bay off the small town Chacala.
<G-vec01141-002-s110><anchor.ankern><de> Wir ankern in einer kleinen Bucht vor dem Ort Chacala.
<G-vec01141-002-s111><anchor.ankern><en> We’ve dropped anchor in a bay next to a marina and a lot of tourism.
<G-vec01141-002-s111><anchor.ankern><de> Jetzt ankern wir in einer Bucht mit Marina und viel Tourismus.
<G-vec01141-002-s112><anchor.ankern><en> Make for Curieuse and anchor for the night in Laraie Bay, on the east coast, or head back to Baie Ste Anne if you need supplies.
<G-vec01141-002-s112><anchor.ankern><de> Fahren Sie nach Curieuse und ankern Sie für die Nacht in Baie Laraie, Ostküste, oder gehen Sie zurück zu Baie Sainte Anne, falls Sie Wasser benötigen.
<G-vec01141-002-s113><anchor.ankern><en> The half day boat trip from Formentera's port in La Savina takes you along the rocky west coast to a beautiful sandy bay where you will anchor to enjoy the prepared food and the sea.
<G-vec01141-002-s113><anchor.ankern><de> Die halbtägige Bootstour ab Formenteras Hafen in La Savina führt Sie entlang der felsigen Westküste zu einer wunderschönen Sandbucht, in der Sie ankern werden, um das vorbereitete Essen und das Meer genießen zu können.
<G-vec01141-002-s114><anchor.ankern><en> The use of a depth gauge will facilitate this operation and we can confirm on what surface we are intending to anchor.
<G-vec01141-002-s114><anchor.ankern><de> Der Einsatz eines Aquascopes würde diese Operation erleichtern, und wir könnten sicher feststellen, über welcher Oberfläche wir ankern wollen.
<G-vec01141-002-s115><anchor.ankern><en> - Now we head back inside the lagoon where the water is turquoise blue and anchor up at a new special spot on the reef for another snorkel.
<G-vec01141-002-s115><anchor.ankern><de> - Nun geht es zurück in die Lagune, wo das Wasser türkisblau ist und wir werden an einem neuen besonderen Ort auf dem Riff für einen weiteren Schnorchel ankern.
<G-vec01141-002-s219><anchor.befestigen><en> Carriers/child seats must be secured with the seatbelts at two anchor points and must be provided by the adult accompanying the child.
<G-vec01141-002-s219><anchor.befestigen><de> Die Babyschalen/Kleinkindersitze müssen mit Zweipunktgurten zu befestigen sein und sind von der Begleitung der Babys/Kleinkinder mitzubringen.
<G-vec01141-002-s220><anchor.befestigen><en> Anchor the change (more).
<G-vec01141-002-s220><anchor.befestigen><de> Befestigen Sie die Änderung.
<G-vec01141-002-s221><anchor.befestigen><en> Here are seven ways to anchor that wayward reader from your first paragraph to your last:1.
<G-vec01141-002-s221><anchor.befestigen><de> Sind hier sieben Möglichkeiten, diesen wayward Leser von Ihrem ersten Punkt an Ihrem Letzten zu befestigen:1.
<G-vec01141-002-s222><anchor.befestigen><en> The suspension trainer can be mounted on a door by means of the provided door anchor - it's ideal while travelling, i.e..
<G-vec01141-002-s222><anchor.befestigen><de> Dank des mitgelieferten Türankers lässt sich der Schlingentrainer an der Tür befestigen, ideal zum Beispiel auf Reisen.
<G-vec01141-002-s223><anchor.befestigen><en> Attach clip to multiple-position anchor.
<G-vec01141-002-s223><anchor.befestigen><de> Clip an Multi-Positionsanker befestigen.
<G-vec01141-002-s224><anchor.befestigen><en> Like almost all catsharks, they lay egg cases, using curly tendrils at each end to anchor them.
<G-vec01141-002-s224><anchor.befestigen><de> Wie fast alle Katzenhaie legen sie Eikapseln und nutzen geringelten Fäden an jedem Ende, um sie zu befestigen.
<G-vec01141-002-s258><anchor.verankern><en> Periodically, the Magnetic Lasso tool adds fastening points to the selection border to anchor previous segments.
<G-vec01141-002-s258><anchor.verankern><de> Mit dem Magnetisches-Lasso-Werkzeug werden der Auswahlbegrenzung in gleichmäßigen Abständen Befestigungspunkte hinzugefügt, um vorherige Segmente zu verankern.
<G-vec01141-002-s259><anchor.verankern><en> But what you still need is more of the spiritual circuitry around you to further anchor, ground, and elevate your thinking from the animal nature that is still buried in fear, to be dominated and influenced to the status of security and confidence in the glory of your personhood as children of light and life.
<G-vec01141-002-s259><anchor.verankern><de> Aber was ihr noch braucht, ist mehr von dem geistigen Schaltkreis um euch herum, um euer Denken weiter zu verankern, zu erden und zu erheben von der tierischen Natur, die noch in Angst vergraben ist, damit ihr dominiert und beeinflusst werdet zu dem Status von Sicherheit und Zuversicht in die Herrlichkeit eures Personseins als Kinder von Licht und Leben.
<G-vec01141-002-s260><anchor.verankern><en> Anchors: lets you create dependencies, for example to anchor a ComboBox to the right side of a Label.
<G-vec01141-002-s260><anchor.verankern><de> Zum Beispiel können Sie jetzt die linke Seite eines TEdit an der rechten Seite eines TLabel verankern.
<G-vec01141-002-s261><anchor.verankern><en> If the graphic has been placed in a frame, you can anchor the graphic in a fixed position inside the frame.
<G-vec01141-002-s261><anchor.verankern><de> Wenn die Grafik in einen Rahmen gestellt worden ist, können Sie sie an einer festen Position innerhalb des Rahmens verankern.
<G-vec01141-002-s262><anchor.verankern><en> Anchor Y Axis at Zero: Forces the y axis to zero even if values range above zero.
<G-vec01141-002-s262><anchor.verankern><de> Y-Achse bei null verankern: Erzwingt für die y-Achse den Wert null, selbst wenn deren Werte über null liegen.
<G-vec01141-002-s263><anchor.verankern><en> They have a special function; they anchor the aura to the physical body.
<G-vec01141-002-s263><anchor.verankern><de> Ihre spezielle Funktion ist es, die Aura am physischen Körper zu verankern.
<G-vec01141-002-s264><anchor.verankern><en> As a pianist who became a politician, Kestenberg was visionary in his ability to formulate music education as a socio-political task and, moreover, to anchor that vision in concrete measures for actual political reform.
<G-vec01141-002-s264><anchor.verankern><de> Als Pianist, der in die Politik wechselte, gelang es Kestenberg, musikalische Bildung als politisch-sozialen Auftrag visionär zu formulieren und überdies in konkreten Reformvorhaben realpolitisch zu verankern.
<G-vec01141-002-s265><anchor.verankern><en> This is made up of four different muscles and their associated tendons, which surround the shoulder joint, stabilise it and anchor it securely in the joint socket.
<G-vec01141-002-s265><anchor.verankern><de> Sie besteht aus vier verschiedenen kleinen Muskeln und den dazugehörigen Sehnen, die das Schultergelenk umschließen, stabilisieren und fest in der Gelenkpfanne verankern.
<G-vec01141-002-s266><anchor.verankern><en> Agility is the ability to react fast and flexibly to change and to be able to act in forward-looking steps. If we take this concept and anchor it only in the operative units, then we will still be slow and remain likely to chose the paths that used to be successful in the past.
<G-vec01141-002-s266><anchor.verankern><de> Wenn wir die Grundidee der Agilität, die Fähigkeit schnell und flexibel auf Änderungen reagieren zu können oder auch iterativ vorausschauend agieren zu können, nur in den operativen Einheiten verankern, dann werden wir weiter langsam bleiben und eher das tun, was in der Vergangenheit erfolgreich war.
<G-vec01141-002-s267><anchor.verankern><en> In certain parts of the world, where bread and wine are not customary or obtainable, it is now sometimes held that local food and drink serve better to anchor the eucharist in everyday life.
<G-vec01141-002-s267><anchor.verankern><de> In einigen Teilen der Welt, in denen Brot und Wein nicht üblich oder nicht erhältlich sind, wird heute manchmal die Auffassung vertreten, daß ortsübliche Nahrungsmittel und Getränke die Eucharistie besser im täglichen Leben verankern können.
<G-vec01141-002-s268><anchor.verankern><en> The OIC is deemed the most suitable institution to represent the world Caliphate, with its mission to anchor the universal Ummah in the Koran and Sunna.
<G-vec01141-002-s268><anchor.verankern><de> Die OIC wird als passendste Institution zur Repräsentation des Weltkalifats angesehen, deren Mission es ist, die weltumspannende Umma in Koran und Sunna zu verankern.
<G-vec01141-002-s269><anchor.verankern><en> Stable organizations are necessary to anchor sustainable solutions in communities.
<G-vec01141-002-s269><anchor.verankern><de> Stabile Organisationen sind notwendig, um Lösungen nachhaltig in Gemeinden zu verankern.
<G-vec01141-002-s270><anchor.verankern><en> You can also add more pins by clicking the areas you want to transform or anchor.
<G-vec01141-002-s270><anchor.verankern><de> Sie können auch weitere Pins hinzufügen, indem Sie auf die Bereiche klicken, die Sie umwandeln oder verankern möchten.
<G-vec01141-002-s271><anchor.verankern><en> But whatever the size of your company or its branch of activity, it’s much harder to anchor a uniform customer orientation throughout the firm.
<G-vec01141-002-s271><anchor.verankern><de> Egal wie gross Ihr Unternehmen ist und in welcher Branche es tätig ist: Einen einheitlichen Kundenfokus im Unternehmen zu verankern, ist dagegen schon anspruchsvoller.
<G-vec01141-002-s272><anchor.verankern><en> In order to sustainably anchor quality work in the product development process, we were also to describe the quality strategy and its added value as well as the control model for the various quality activities.
<G-vec01141-002-s272><anchor.verankern><de> Um die Qualitätsarbeit bereits im Produktentstehungsprozess nachhaltig zu verankern, sollte zudem die Q-Strategie und deren Mehrwert sowie das Steuerungsmodell für die verschiedenen Qualitätsaktivitäten beschrieben werden.
<G-vec01141-002-s273><anchor.verankern><en> He called on the responsible national and state ministries to firmly anchor preventive burglary protection measures in building regulations – especially in light of the expected support by the population.
<G-vec01141-002-s273><anchor.verankern><de> Er appellierte an die zuständigen Ministerien in Bund und Ländern, Maßnahmen zum vorbeugenden Einbruchschutz fest in den Bauordnungen zu verankern – gerade mit Blick auf die zu erwartende Unterstützung durch die Bevölkerung.
<G-vec01141-002-s274><anchor.verankern><en> The 11:11 Sacred Dances are very powerful tools to anchor the Ultra Greater Reality into the physical.
<G-vec01141-002-s274><anchor.verankern><de> Die heiligen Tänze der 11:11 sind sehr mächtige Werkzeuge um die größere Realität im Physischen zu verankern.
<G-vec01141-002-s275><anchor.verankern><en> About 80 of these boxes were distributed to schools as visual aids in order to anchor the utopian idea of the democratic Gute Form among future consumers in the period of upheaval that the economic miracle during the reconstruction of Germany constituted.
<G-vec01141-002-s275><anchor.verankern><de> Etwa 80 dieser Kisten wurden als Anschauungsmaterial an Schulen verteilt, um in der vom Wiederaufbau Deutschlands geprägten Umbruchphase des Wirtschaftswunders den utopischen Gedanken der demokratischen, »Guten Form« bei den zukünftigen Konsumenten zu verankern.
<G-vec01141-002-s276><anchor.verankern><en> On our way we anchor of for lunch and swim at the south side of Ios.
<G-vec01141-002-s276><anchor.verankern><de> Auf unserem Weg verankern wir zum Mittagessen und schwimmen auf der Südseite von Ios.
<G-vec01141-002-s277><anchor.verankern><en> Then the flower begins to wrap with new petals, which also anchor at the base.
<G-vec01141-002-s277><anchor.verankern><de> Dann fängt die Blume an, sich mit neuen Blütenblättern zu umhüllen, die ebenfalls an der Basis verankert sind.
<G-vec01141-002-s278><anchor.verankern><en> When your subconscious is in deep relaxation as experienced during hypnosis, it can be directly accessed to anchor suggestions intended to bring about the desired change.
<G-vec01141-002-s278><anchor.verankern><de> Durch den Entspannungszustand, den du durch die Hypnose erreichst, können die Suggestionen, welche die gewünschte Veränderung herbeiführen sollen, in deinem Unterbewusstsein platziert und verankert werden.
<G-vec01141-002-s279><anchor.verankern><en> This has to do with how you assimilate this energy and how you deal with and anchor each one of these waves of energy as they come in.
<G-vec01141-002-s279><anchor.verankern><de> Das hat damit zu tun, wie ihr diese Energie assimiliert und wie ihr mit jeder der hereinkommenden Energiewellen umgeht und sie verankert.
<G-vec01141-002-s280><anchor.verankern><en> Internally, we are working on a legally binding proposal on how to anchor it within TTIP: publicly appointed, independent justices would give judgements in a transparent procedure with a possibility for review.
<G-vec01141-002-s280><anchor.verankern><de> Intern arbeiten wir an einem rechtsverbindlichen Vorschlag, wie er in TTIP verankert wird: Öffentlich ernannte, unabhängige Richter sollen in transparenten Verfahren Urteile mit Revisionsmöglichkeit sprechen.
<G-vec01141-002-s281><anchor.verankern><en> Anchor that piece of you on the planet firmly, then you can expand without the problems because there will be all kinds of challenges if you begin expanding and moving into a large energy field without clear definition or without grounding.
<G-vec01141-002-s281><anchor.verankern><de> Verankert diesen Teil von euch fest auf dem Planeten, dann könnt ihr euch ohne Probleme ausdehnen, denn es wird anfangs allerlei Herausforderungen geben, wenn ihr beginnt euch auszudehnen und euch in ein großes Energiefeld begebt ohne klare Definition oder ohne Erdung.
<G-vec01141-002-s282><anchor.verankern><en> Bioinformatic analysis of the protein fragments revealed in about half of the nearly 700 proteins, no evidence of structures that commonly anchor proteins to a cell surface.
<G-vec01141-002-s282><anchor.verankern><de> Die bioinformatische Auswertung der identifizierten Proteinfragmente zeigte, dass sich bei etwa der Hälfte der fast 700 Proteine gar keine Hinweise auf die charakteristischen Strukturen fanden, mit denen Proteine normalerweise auf einer Zelloberfläche verankert werden.
<G-vec01141-002-s283><anchor.verankern><en> A special highlight is the programme for children, which seeks to anchor art in the everyday life of children and young people in a playful way with various tours and workshops.
<G-vec01141-002-s283><anchor.verankern><de> Eine ganz besondere Herzensangelegenheit ist das Kinderprogramm, mit dem Kunst auf spielerische Weise in unterschiedlichen Führungen und Workshops im Alltag von Kindern und Jugendlichen verankert werden soll.
<G-vec01141-002-s284><anchor.verankern><en> The profound symbolism of the anchor and cross transforms the individual items of jewellery into protective talismen of a special kind: the anchor has its origins in seafaring and in general points to the question of what is our anchor in life, what gives us a firm footing.
<G-vec01141-002-s284><anchor.verankern><de> Schützende Talismane für jeden Tag Die tiefe Symbolik der Anker und Kreuze macht die Schmuckstücke zu einem schützenden Talisman der besonderen Art: Der Anker hat seinen Ursprung in der Seefahrt und weist allgemein auf die Frage hin, was uns im Leben verankert, was uns Halt gibt.
<G-vec01141-002-s285><anchor.verankern><en> When approaching Cai Be, the Ship drops anchor to moor midstream where the river is several kilometers wide. Including dinner.
<G-vec01141-002-s285><anchor.verankern><de> Bei der Ankunft in Cai Be verankert das Schiff für die Nacht in einem Ort, wo der Fluss mehrere Kilometer breit ist.
<G-vec01141-002-s286><anchor.verankern><en> In order to catch its prey, the spider will typically anchor its hind legs to a stone or a plant, with its front legs resting on the surface of the water, ready to ambush.
<G-vec01141-002-s286><anchor.verankern><de> Um ihre Beute zu fangen, verankert sich die Spinne mit ihren Hinterbeinen an einem Felsen oder einer Pflanze und platziert ihre Vorderbeine auf der Wasseroberfläche, bereit die Beute zu attackieren.
<G-vec01141-002-s287><anchor.verankern><en> Anchor the kingdom of peace in your self.
<G-vec01141-002-s287><anchor.verankern><de> Verankert das Friedensreich in euch selbst.
<G-vec01141-002-s288><anchor.verankern><en> Does not anchor boats and uses drift diving techniques whenever possible to avoid damaging the underwater habitat Close x Prev Next
<G-vec01141-002-s288><anchor.verankern><de> Verankert keine Boote und wendet nach Möglichkeit Strömungstauchtechniken an, um Schäden am Unterwasserlebensraum zu vermeiden.
<G-vec01141-002-s289><anchor.verankern><en> The specially selected components in this security set make it possible to anchor both the computer casing (CPU) and the monitor to the workspace, simply and without tools.
<G-vec01141-002-s289><anchor.verankern><de> Mit den speziell ausgewählten Einzelteilen dieses Sets können sowohl der Rechner (CPU), als auch der Monitor auf einfache Weise und ohne Werkzeug am Arbeitsplatz verankert werden.
<G-vec01141-002-s290><anchor.verankern><en> And in order to anchor the show in the present, a large part of the exhibition is dedicated to Martens’ latest work.
<G-vec01141-002-s290><anchor.verankern><de> Um außerdem im Heute verankert zu sein, widmet sich ein großer Teil der Ausstellung Martens’ aktuellsten Werken.
<G-vec01141-002-s291><anchor.verankern><en> Then, with the Text Content tool selected, place the text insertion point at the point in text where you want to anchor the item or group and choose Edit > Paste (Command+V/Ctrl+V).
<G-vec01141-002-s291><anchor.verankern><de> Platzieren Sie nun bei aktiviertem Werkzeug Textinhalt die Texteinfügemarke an die Stelle im Text, an der das Objekt oder die Gruppe verankert werden soll und wählen Sie Bearbeiten > Einsetzen (Befehl+V/Strg+V).
<G-vec01141-002-s292><anchor.verankern><en> To enable the electricians to work quickly and efficiently, a fully equipped AMA sub-platform is sited in each gate and all that is subsequently required is to anchor it to the platform.
<G-vec01141-002-s292><anchor.verankern><de> Damit die Elektriker effektiv und zügig arbeiten können, steht in jedem Gate ein komplett montiertes AMA-Podest bereit und muss noch nur auf der Plattform verankert werden.
