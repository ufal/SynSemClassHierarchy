<G-vec00993-002-s141><curl_up.biegen><en> A Bombay cat or kitten's tail is neither too long or too short and finishes with a curl.
<G-vec00993-002-s141><curl_up.biegen><de> Der Schwanz einer Bombay-Katze oder ihrer Kätzchen ist weder zu kurz noch zu lang und endet leicht gebogen.
<G-vec00993-002-s137><curl_up.krümmen><en> Simply curl your middle fingers forward again and pinch it between your thumb and index finger.
<G-vec00993-002-s137><curl_up.krümmen><de> Krümme deine mittleren Finger einfach wieder nach vorn und drücke sie zwischen deinem Daumen und Zeigefinger zusammen.
<G-vec00993-002-s138><curl_up.krümmen><en> Curl the strip so that the striking strip is in the inside of the loop.
<G-vec00993-002-s138><curl_up.krümmen><de> Krümme den Streifen so, dass seine Reibeflächen auf der Innenseite der Schlafe sind.
<G-vec00993-002-s271><curl_up.winden><en> Each fiber seems to curl and fray as if life is still flowing through it.
<G-vec00993-002-s271><curl_up.winden><de> Jede Faser scheint sich zu winden und zu ringeln, als ob sie noch immer von Leben durchdrungen wäre.
<G-vec00993-002-s276><curl_up.zusammenrollen><en> Most fibres, especially longer ones, tend to curl, and there have been several efforts to describe this phenomenon in terms of a single parameter.
<G-vec00993-002-s276><curl_up.zusammenrollen><de> Die meisten Fasern, besonders längere, neigen zum Zusammenrollen, und es hat die unterschiedlichsten Ansätze gegeben, dieses Phänomen durch einen einzigen Parameter zu beschreiben.
