<G-vec00258-003-s019><come_out.bieten><en> Many rooms come with a spectacular view over the hills.
<G-vec00258-003-s019><come_out.bieten><de> Viele Zimmer bieten eine tolle Ausblick auf die Berge an.
<G-vec00258-003-s020><come_out.bieten><en> Some rooms come with a view of Battery Park.
<G-vec00258-003-s020><come_out.bieten><de> Die modernen Hotelzimmer bieten einen Blick auf die Skyline.
<G-vec00258-003-s021><come_out.bieten><en> Rooms come with the garden view.
<G-vec00258-003-s021><come_out.bieten><de> Die Zimmer bieten einen wunderbaren Ausblick auf den Garten.
<G-vec00258-003-s022><come_out.bieten><en> Non-smoking rooms come with an in-room safe, climate control, flat-screen TV, a dining area and a closet. The property offers a bathroom with a shower and a bidet.
<G-vec00258-003-s022><come_out.bieten><de> Die En-suite Zimmer bieten einen Zimmersafe, eine Minibar, Kabelfernsehen mit Video-on-demand, einen Wohnbereich und einen Schreibtisch sowie eine tolle Aussicht auf das Meer.
<G-vec00258-003-s023><come_out.bieten><en> Rooms in Hotel Garni Elba come with a coffee/tea maker.
<G-vec00258-003-s023><come_out.bieten><de> Die Zimmer im Hotel Garni Elba mit einer Küche bieten Kaffeemaschine/Teekocher.
<G-vec00258-003-s024><come_out.bieten><en> Classic-style rooms at the Il Corallo bed and breakfast come with a TV and a private bathroom including a hairdryer.
<G-vec00258-003-s024><come_out.bieten><de> Die Doppelzimmer sind im klassischen Stil eingerichtet, und bieten Ihnen einen Flachbild-TV und ein eigenes Bad mit einem Haartrockner und Handtüchern.
<G-vec00258-003-s025><come_out.bieten><en> Some rooms come with a stunning view of Arabian Gulf.
<G-vec00258-003-s025><come_out.bieten><de> Die Zimmer bieten einen tollen Blick auf die Lagune.
<G-vec00258-003-s026><come_out.bieten><en> Guest units come with air conditioning, tiled floors and a private terrace with serene ocean views.
<G-vec00258-003-s026><come_out.bieten><de> Die Unterkünfte bieten eine Klimaanlage, Fliesenböden und eine private Terrasse mit ruhigem Meerblick.
<G-vec00258-003-s027><come_out.bieten><en> With astonishing brightness, incomparable contrast and captivating color, images come to life with much greater brightness while also featuring much deeper, more nuanced darks.
<G-vec00258-003-s027><come_out.bieten><de> Mithilfe punktueller Dimmfunktion und hoher maximaler Helligkeit bis zu 600 Nit werden Bilder mit sichtbaren Höhepunkten zum Leben erweckt, die tiefere, nuanciertere Schwarztöne bieten.
<G-vec00258-003-s028><come_out.bieten><en> World of Judaica's Israeli Bookmarks come in a variety of styles and shapes.
<G-vec00258-003-s028><come_out.bieten><de> Wir bieten eine Vielfalt an Mesusas,Tallitot, Jüdischem Schmuck und weiteren Dingen an.
<G-vec00258-003-s029><come_out.bieten><en> Certain rooms come with a balcony.
<G-vec00258-003-s029><come_out.bieten><de> Einige Zimmer bieten einen Balkon.
<G-vec00258-003-s030><come_out.bieten><en> Rooms come with a private bathroom equipped with a bath or shower.
<G-vec00258-003-s030><come_out.bieten><de> Die Zimmer bieten Ihnen ein eigenes Bad mit einer Badewanne oder einer Dusche.
<G-vec00258-003-s031><come_out.bieten><en> The rooms come with en suite bathrooms featuring a shower, free toiletries and a hairdryer.
<G-vec00258-003-s031><come_out.bieten><de> Sie bieten private Badezimmer, die über eine Dusche, einen Fön und eine Badewanne verfügen.
<G-vec00258-003-s032><come_out.bieten><en> All rooms come with a seating area and a toilet with shower, hairdryer and free toiletries.
<G-vec00258-003-s032><come_out.bieten><de> Alle Zimmer bieten einen Sitzbereich sowie ein Bad mit Dusche, Haartrockner und kostenlosen Pflegeprodukten.
<G-vec00258-003-s033><come_out.bieten><en> Quality materials and thorough workmanship guarantee a long service life and a reflection of excellence for years to come.
<G-vec00258-003-s033><come_out.bieten><de> Qualitativ hochwertige Materialien und solide Ausführung bieten die Gewähr für lange Lebensdauer und ein auf Dauer attraktives Erscheinungsbild.
<G-vec00258-003-s034><come_out.bieten><en> The apartments come with a kitchen, a dining area and a private bathroom.
<G-vec00258-003-s034><come_out.bieten><de> Die Apartments bieten Ihnen eine Küche, einen Essbereich und ein eigenes Bad.
<G-vec00258-003-s035><come_out.bieten><en> Some hotel rooms come with a panoramic view over the sea.
<G-vec00258-003-s035><come_out.bieten><de> Die Zimmer bieten einen tollen Ausblick auf das Meer.
<G-vec00258-003-s036><come_out.bieten><en> Room description The spacious rooms each come with a bath/ shower, a hairdryer, a direct dial telephone, a satellite TV, a radio and high speed Internet access.
<G-vec00258-003-s036><come_out.bieten><de> Zimmerbeschreibung Die Hotelzimmer bieten ein eigenes Badezimmer mit Dusche/Badewanne und Haartrockner sowie ein Direktwahltelefon, ein TV-Gerät mit Sat.-Kanälen, ein Radio und DSL-Internetzugang.
<G-vec00258-003-s037><come_out.bieten><en> These comfortable rooms come with a hairdryer and a Jacuzzi supplied in a designer bathroom.
<G-vec00258-003-s037><come_out.bieten><de> Die Zimmer bieten En-suite-Badezimmer mit einer Badewanne, einem Fön und einem Jacuzzi.
<G-vec00258-003-s076><come_out.entstehen><en> Something Great will come of it...
<G-vec00258-003-s076><come_out.entstehen><de> Es wird Großartiges daraus entstehen...
<G-vec00258-003-s077><come_out.entstehen><en> The basis for peace of mind is self-confidence and inner strength, which come from the practice of love and compassion, with a sense of respect for others and concern for their well-being.
<G-vec00258-003-s077><come_out.entstehen><de> Die Grundlage für geistigen Frieden ist Selbstvertrauen und innere Stärke, die durch die Praxis von Liebe und Mitgefühl, mit einem Gefühl des Respekts gegenüber anderen und einer Sorge um ihr Wohlergehen, entstehen.
<G-vec00258-003-s078><come_out.entstehen><en> My works come about in Hamburg Altona and Großenwörden in the inspiring Osteland.
<G-vec00258-003-s078><come_out.entstehen><de> Meine Arbeiten entstehen in Hamburg Altona und in Großenwörden im inspirierenden Osteland.
<G-vec00258-003-s079><come_out.entstehen><en> Combined with khaki, gold, thistle and indigo blue, interesting cold/warm contrasts come to light.
<G-vec00258-003-s079><come_out.entstehen><de> Kombiniert mit Khaki, Gold, Distelgrün und Indigo Blue entstehen interessante Kalt-Warm-Kontraste.
<G-vec00258-003-s080><come_out.entstehen><en> This is how the best services come about.
<G-vec00258-003-s080><come_out.entstehen><de> Auf diese Weise entstehen die besten Services.
<G-vec00258-003-s081><come_out.entstehen><en> An alternative approach may come from the potential therapeutic qualities of CBD.
<G-vec00258-003-s081><come_out.entstehen><de> Ein alternativer Ansatz könnte aus den potenziell therapeutischen Qualitäten von CBD entstehen.
<G-vec00258-003-s082><come_out.entstehen><en> Everything actually needs to come into being from nothing.
<G-vec00258-003-s082><come_out.entstehen><de> Alles muss eigentlich aus dem Nichts entstehen.
<G-vec00258-003-s083><come_out.entstehen><en> They come as well when the priesthood service is to members within the quorum.
<G-vec00258-003-s083><come_out.entstehen><de> Sie entstehen auch, wenn das Kollegium durch das Priestertum den Mitgliedern in seinen eigenen Reihen dient.
<G-vec00258-003-s084><come_out.entstehen><en> Or we can provide a complete team so the aforementioned problems don’t come up in the first place.
<G-vec00258-003-s084><come_out.entstehen><de> Oder wir stellen gleich ein komplettes Team, damit die oben beschriebenen Probleme erst gar nicht entstehen können.
<G-vec00258-003-s085><come_out.entstehen><en> And when a group unites against something, an amazingly powerful strength can come out of it.
<G-vec00258-003-s085><come_out.entstehen><de> Und wenn sich eine Gruppe gegen etwas vereinigt, kann daraus eine mächtige Energie entstehen.
<G-vec00258-003-s086><come_out.entstehen><en> It is important for self-confidence, but it can only come from someone else.
<G-vec00258-003-s086><come_out.entstehen><de> Sie ist wichtig für das Selbstbewusstsein, kann aber nicht aus dem eigenen Ich heraus entstehen.
<G-vec00258-003-s087><come_out.entstehen><en> At least I was able to sense, how his manipulated photographs could come into being.
<G-vec00258-003-s087><come_out.entstehen><de> Zumindest erahne ich gerade, wie seine manipulierte Fotografie entstehen könnte.
<G-vec00258-003-s088><come_out.entstehen><en> The object of much of today’s humanities research and cultural criticism is to demonstrate how an imaginary geography or an imagined community develops permanence and boundaries and ultimately replaces reality itself, and how this happens through identification processes in which some elements are discarded in order for that community’s identity to come into being, be it Swedish, Nordic, European or global.
<G-vec00258-003-s088><come_out.entstehen><de> Gegenstand der geisteswissenschaftlichen Forschung und Kulturkritik ist heute häufig, aufzuzeigen, wie eine imaginäre Geographie oder imaginäre Gemeinschaft Stabilität und Grenzen erhält und am Ende selbst den Platz der Wirklichkeit einnimmt, und wie dies durch Identifikationsprozesse geschieht, in denen manches aussortiert wird, damit die eigene Identität entstehen kann, ganz gleich ob schwedisch, nordisch, europäisch oder global.
<G-vec00258-003-s089><come_out.entstehen><en> Netflix also reported that more than 60% of its rentals come from recommendations that are based off of hyper personalization data. **
<G-vec00258-003-s089><come_out.entstehen><de> Auch Netflix berichtet, dass 60% ihrer Verkäufe aus Vorschlägen entstehen, die Kunden aufgrund ihrer personalisierten Daten erhalten.
<G-vec00258-003-s090><come_out.entstehen><en> You need creativity and skill to make Bronze Age decorations from metal and let the Middle Ages come to life with self decorated beads.
<G-vec00258-003-s090><come_out.entstehen><de> Kreativität und Geschick sind gefragt, wenn aus Metall bronzezeitliche Geschmeide entstehen und selbst verzierte Perlen das Mittelalter auferstehen lassen.
<G-vec00258-003-s091><come_out.entstehen><en> I’m not quite sure how the pictures come about, and why they are what they are.
<G-vec00258-003-s091><come_out.entstehen><de> Ich weiß nicht genau, wie die Bilder entstehen, und woran es liegt, wie sie sind.
<G-vec00258-003-s092><come_out.entstehen><en> Yet we all have long known that extraordinary ideas seldom come from nowhere.
<G-vec00258-003-s092><come_out.entstehen><de> Dabei wissen wir längst, dass außergewöhnliche Einfälle selten aus einem Vakuum heraus entstehen.
<G-vec00258-003-s093><come_out.entstehen><en> The relevant research is in the tradition of the resource-based basis and has not yet decided sufficiently what exactly dynamical capabilities are, where they are rooted in the organization, how they come into being, and how their advantage can be unfolded.
<G-vec00258-003-s093><come_out.entstehen><de> Die in der Tradition des ressourcen-orientierten Ansatzes stehende einschlägige Forschung hat bislang jedoch noch nicht hinreichend bestimmt, was genau unter dynamischen Fähigkeiten zu verstehen ist, wo in der Organisation sie zu verorten sind, wodurch sie entstehen und wie genau sich ihr Nutzen entfaltet.
<G-vec00258-003-s094><come_out.entstehen><en> Time and again almost magical moments come up - so great is the intimacy between the protagonists on stage and the audience.
<G-vec00258-003-s094><come_out.entstehen><de> So entstehen auch immer wieder fast schon magische Momente - so groß wird die Innigkeit zwischen den Akteuren auf der Bühne und dem Publikum.
<G-vec00258-003-s114><come_out.finden><en> "Players like him are hard to come by.
<G-vec00258-003-s114><come_out.finden><de> "Es ist sehr schwer, einen Spieler wie ihn zu finden.
<G-vec00258-003-s115><come_out.finden><en> You’ll hardly come across a model that is prettier and better.
<G-vec00258-003-s115><come_out.finden><de> Ein Exemplar, das schöner oder besser ist, werden Sie mit Sicherheit nicht finden.
<G-vec00258-003-s116><come_out.finden><en> Right in the center of Rotterdam, next to Blaak Station, you will come across this chocolate paradise in the Markthal.
<G-vec00258-003-s116><come_out.finden><de> Mitten im Zentrum von Rotterdam, neben der Blaak Station, finden Sie dieses Schokoladenparadies in der Markthal.
<G-vec00258-003-s117><come_out.finden><en> Our team is made up of people from various backgrounds who together can come up with an answer to any question.
<G-vec00258-003-s117><come_out.finden><de> Es besteht aus Menschen verschiedener Hintergrunds, die gemeinsam für jede Frage eine Antwort finden können.
<G-vec00258-003-s118><come_out.finden><en> It is a humanitarian imperative that the suffering, hunger and deaths finally come to an end.
<G-vec00258-003-s118><come_out.finden><de> Es ist ein Gebot der Menschlichkeit, dass Leiden, Hungern und Sterben endlich ein Ende finden.
<G-vec00258-003-s119><come_out.finden><en> In practice, work opportunities are rather more limited, although there is some seasonal tourist industry work available during the summer if you have the requisite skills and language abilities (Norwegian will come in handy).
<G-vec00258-003-s119><come_out.finden><de> In der Praxis ist die Arbeitserlaubnis trotzdem erschwert, obwohl du sehr schnell in der saisonalen Tourismusbranche eine Arbeit finden kannst, vorausgesetzt, du besitzt die nötigen Anforderungen und Sprachkenntnisse in Norwegisch.
<G-vec00258-003-s120><come_out.finden><en> If you want to learn English, make friends, have fun and explore the UK come and join us in the July and/or August.
<G-vec00258-003-s120><come_out.finden><de> Wenn Sie Englisch lernen, Freunde finden, Spaß haben und das Vereinigte Königreich erkunden möchten, besuchen Sie uns im Juli und / oder August.
<G-vec00258-003-s121><come_out.finden><en> It had saved his ears more then once to be able to come up with a believable explanation why some disaster was not at all related to the fact that he had been close.
<G-vec00258-003-s121><come_out.finden><de> Damit hatte er seine Ohren mehr als einmal retten können, wenn es darum ging eine glaubhaften Erklärung zu finden für die Tatsache, warum irgendeine Katastrophe ganz sicher nichts mit seiner Anwesenheit zu tun hatte.
<G-vec00258-003-s122><come_out.finden><en> It seems like it should be fairly easy for the two sides to come together.
<G-vec00258-003-s122><come_out.finden><de> Es scheint, als sollte es für die beiden Seiten relativ leicht sein, eine Einigung zu finden.
<G-vec00258-003-s123><come_out.finden><en> My immune system has crashed completely, I welcome each bacteria and virus I come across.
<G-vec00258-003-s123><come_out.finden><de> Mein Immunsystem ist so im Eimer, dass ich jede Bakterie und jeden Virus mitnehmen, den ich finden kann.
<G-vec00258-003-s124><come_out.finden><en> True unicorns that meet all of our criteria are hard to come by.
<G-vec00258-003-s124><come_out.finden><de> Wahre Unicorns, die alle unsere Kriterien erfüllen, sind jedoch schwer zu finden.
<G-vec00258-003-s125><come_out.finden><en> I, therefore, do not believe anybody could come up with a universal “sufficient condition” based on which you can always tell whether or not an enterprise has been acting ethically or not.
<G-vec00258-003-s125><come_out.finden><de> So glaube ich nicht, dass es genügt und gelingt, eine allgemeine „hinreichende Bedingung“ zu finden, an der gemessen werden kann, ob ein Unternehmen ethisch handelt oder nicht.
<G-vec00258-003-s126><come_out.finden><en> At that point the Iranian professor believed he’d come up with another argument.
<G-vec00258-003-s126><come_out.finden><de> In diesem Augenblick glaubte der Professor, ein anderes Argument zu finden.
<G-vec00258-003-s127><come_out.finden><en> One more fascinating variation you may come across web is Pontoon.
<G-vec00258-003-s127><come_out.finden><de> Eine andere interessante Internet-basierte Varianz Sie finden könnte, ist Pontoon.
<G-vec00258-003-s128><come_out.finden><en> The very goal of our industry is to come up with a smart and effective solution for these challenges.
<G-vec00258-003-s128><come_out.finden><de> Genau dies ist das Ziel unserer Branche: intelligente und effektive Lösungen für diese Herausforderungen zu finden.
<G-vec00258-003-s129><come_out.finden><en> Currently, there is not enough data and evidence to come up with a solution for that.
<G-vec00258-003-s129><come_out.finden><de> Gegenwärtig gibt es nicht genügend Daten und Beweise, um eine Lösung dafür zu finden.
<G-vec00258-003-s130><come_out.finden><en> Talking to other singles who have similar interests is a great way to come up with ideas to do on a first date.
<G-vec00258-003-s130><come_out.finden><de> Triff andere,die ähnliche Interessen haben, das ist ein perfekter Weg, um Ideen zu finden für gemeinsame Unternehmungen beim ersten Treffen.
<G-vec00258-003-s131><come_out.finden><en> Being a flexible co-packer, we would like to think along with you to come to your personal packaging solution.
<G-vec00258-003-s131><come_out.finden><de> Als flexibler Copacker arbeiten wir gerne mit Ihnen zusammen, um die für Sie ideale Verpackungslösung zu finden.
<G-vec00258-003-s132><come_out.finden><en> He added that he had been waiting for a lifetime to come up with a character together with his dad.
<G-vec00258-003-s132><come_out.finden><de> Er fügte hinzu, dass er auf ein Leben lang gewartet habe, um zusammen mit seinem Vater eine Figur zu finden.
<G-vec00258-003-s133><come_out.gehen><en> There are breathtaking film sets where visitors can come into close contact with the jaws of a great white shark, look underneath Marilyn Monroe's skirt or learn about fear at Jurassic Park.
<G-vec00258-003-s133><come_out.gehen><de> In atemberaubenden Filmkulissen können Besucher auf Tuchfühlung mit dem weißen Hai gehen, Marilyn Monroe unter den Rock schauen oder im Jurassic Park das Fürchten lernen.
<G-vec00258-003-s134><come_out.gehen><en> 44:25 And they shall come at no dead person to become unclean; but for father, or for mother, or for son, or for daughter, for brother, or for sister that hath had no husband, they may become unclean.
<G-vec00258-003-s134><come_out.gehen><de> 44:25 Und keiner soll zu dem Leichnam eines Menschen gehen, daß er unrein werde; nur allein wegen Vater und Mutter, und wegen Sohn und Tochter, wegen eines Bruders und wegen einer Schwester, die keines Mannes gewesen ist, dürfen sie sich verunreinigen.
<G-vec00258-003-s135><come_out.gehen><en> This is where interfaces and the single responsibility principle can come to work hand in hand.
<G-vec00258-003-s135><come_out.gehen><de> Hier können Schnittstellen und das Prinzip der einheitlichen Verantwortung Hand in Hand gehen.
<G-vec00258-003-s136><come_out.gehen><en> May your dream will come true this year.
<G-vec00258-003-s136><come_out.gehen><de> Möge Eure Wünsche auch in diesem Jahr in Erfüllung gehen.
<G-vec00258-003-s137><come_out.gehen><en> I hope you have a wonderful new year, and all your dreams and wished come true next year.
<G-vec00258-003-s137><come_out.gehen><de> Ich hoffe ihr habt ein wunderschönes neues Jahr und all eure Wünsche und Träume gehen dieses Jahr in Erfüllung.
<G-vec00258-003-s138><come_out.gehen><en> Sport has always played an important role in my life, in part because I come from a family of athletes.
<G-vec00258-003-s138><come_out.gehen><de> Auch Sport spielte schon immer eine wichtige Rolle in meinem Leben, egal ob Fußball spielen mit meinen Freunden oder einfach im Morgengrauen joggen gehen.
<G-vec00258-003-s139><come_out.gehen><en> Bishops should encourage priests to come to Medjugorje, to Our Lady's school.
<G-vec00258-003-s139><come_out.gehen><de> Die Bischöfe sollten die Menschen ermutigen, nach Medjugorje zu gehen, in die Schule der Muttergottes.
<G-vec00258-003-s140><come_out.gehen><en> 29 Let no evil talk come out of your mouths, but only what is useful for building up, as there is need, so that your words may give grace to those who hear.
<G-vec00258-003-s140><come_out.gehen><de> 29 Lasset kein faul Geschwätz aus eurem Munde gehen, sondern was nützlich zur Besserung ist, wo es not tut, daß es holdselig sei zu hören.
<G-vec00258-003-s141><come_out.gehen><en> It's just necessary to come to a doctor and pick up that medicine, which, according to the dose and type of hormone, will suit you.
<G-vec00258-003-s141><come_out.gehen><de> Es ist nur notwendig, zu einem Arzt zu gehen und die Medizin zu holen, die je nach Dosis und Art des Hormons zu Ihnen passt.
<G-vec00258-003-s142><come_out.gehen><en> Numerous performers, musicians, actors and entertainers come out onto the streets, and the entire city operates as a public space for the presentation of Croatian tradition.
<G-vec00258-003-s142><come_out.gehen><de> Viele Darsteller, Musiker, Performance-Künstler, Schauspieler und Unterhalter gehen auf die Straßen, während die ganze Stadt den Eindruck erweckt, ein öffentlicher Raum für die Vorstellung der kroatischen Tradition zu sein.
<G-vec00258-003-s143><come_out.gehen><en> The gift certificates of Ferienart Resort & Spa are always welcome and make small and bigger dreams come true.
<G-vec00258-003-s143><come_out.gehen><de> Die Geschenkgutscheine des Ferienart Resort & Spa sind immer willkommen und lassen kleine und größere Wünsche in Erfüllung gehen.
<G-vec00258-003-s144><come_out.gehen><en> But these privileges also come with duties.
<G-vec00258-003-s144><come_out.gehen><de> Diese Privilegien gehen jedoch mit Pflichten einher.
<G-vec00258-003-s145><come_out.gehen><en> They remind you that difficult moments and things that come to an end are signs of something beautiful and new that will soon arise.
<G-vec00258-003-s145><come_out.gehen><de> Sie erinnern daran, dass schwierige Momente und Dinge, die zu Ende gehen, Zeichen von etwas Schönem und Neuem sind, das bald auftauchen wird.
<G-vec00258-003-s146><come_out.gehen><en> Who listens to me, he has won much, because what I promise a man will indeed come true.
<G-vec00258-003-s146><come_out.gehen><de> Wer Mich anhöret, der hat viel gewonnen, denn was Ich einem Menschen verspreche, wird wahrlich in Erfüllung gehen.
<G-vec00258-003-s147><come_out.gehen><en> Thus, you will never come up empty and your apartment is always visitors fit, no matter what happens.
<G-vec00258-003-s147><come_out.gehen><de> Somit gehen Sie nie leer aus und Ihre Wohnung ist immer besuchertauglich, egal was auch passiert.
<G-vec00258-003-s148><come_out.gehen><en> Legend has it that if you want something while you ring the church bell, your wish might come true.
<G-vec00258-003-s148><come_out.gehen><de> Die Legende besagt es, wenn Sie etwas wünschen, während Sie die Kirchenglocke läuten, könnte Ihr Wunsch in Erfüllung gehen.
<G-vec00258-003-s149><come_out.gehen><en> 20 And now you will be silent and not able to speak until the day this happens, because you did not believe my words, which will come true at their appointed time.” (Luke 1:13-20)
<G-vec00258-003-s149><come_out.gehen><de> 1:20 Aber weil du meinen Worten nicht geglaubt hast, die in Erfüllung gehen, wenn die Zeit dafür da ist, sollst du stumm sein und nicht mehr reden können bis zu dem Tag, an dem all das eintrifft.
<G-vec00258-003-s150><come_out.gehen><en> They pleaded with me not to come.
<G-vec00258-003-s150><come_out.gehen><de> Sie haben auf mich eingeredet, nicht zu gehen.
<G-vec00258-003-s151><come_out.gehen><en> Because every Theum virtual expert knows about the others, users can query across them transparently and in parallel as new ones come online—without having to know where to look.
<G-vec00258-003-s151><come_out.gehen><de> Weil jeder virtuelle Experte von Theum jeden anderen „kennt“, können Anwender Abfragen über alle virtuellen Experten hinweg transparent und parallel ausführen, sobald neue virtuellen Experten online gehen – ohne deren Adresse zu kennen.
<G-vec00258-003-s171><come_out.gelangen><en> The customer hereby grants the Bank a lien on valuables of any kind which, in the course of banking business, may come into the possession or power of disposition of the Bank through acts of the customer or of third parties for account of the customer.
<G-vec00258-003-s171><come_out.gelangen><de> Der Kunde räumt hiermit der BayernLB ein Pfandrecht ein an Werten jeder Art, die im bankmäßigen Geschäftsverkehr durch den Kunden oder durch Dritte für seine Rechnung in ihren Besitz oder ihre sonstige Verfügungsmacht gelangen.
<G-vec00258-003-s172><come_out.gelangen><en> And we need to make the bridge between the results of research on one hand and the potential investors on the other, for innovation to come out of the lab and onto the market.
<G-vec00258-003-s172><come_out.gelangen><de> Und wir müssen Brücken bauen zwischen den Forschungsergebnissen einerseits und potentiellen Investoren andererseits, damit die Innovation vom Labor auf den Markt gelangen kann.
<G-vec00258-003-s173><come_out.gelangen><en> 9 If they say thus to us, Stand still until we come to you, then we will stay in our place, and will not go up to them.
<G-vec00258-003-s173><come_out.gelangen><de> 9 Wenn sie dann zu uns sagen: «Steht stille, bis wir zu euch gelangen!» so wollen wir an unserm Ort stehenbleiben und nicht zu ihnen hinaufsteigen.
<G-vec00258-003-s174><come_out.gelangen><en> The parties will subsequently consult and try to come to an agreement.
<G-vec00258-003-s174><come_out.gelangen><de> Die Parteien werden sich daraufhin beraten und versuchen, zu einer Einigung zu gelangen.
<G-vec00258-003-s175><come_out.gelangen><en> After around 30 minutes, you will come to the clearing with the Ellmau Stone Circle.
<G-vec00258-003-s175><come_out.gelangen><de> Nach circa 30 Minuten gelangen Sie an die Lichtung mit dem Ellmauer Steinkreis.
<G-vec00258-003-s176><come_out.gelangen><en> You will look for me; and as I said to the Jews so now I say to you, “Where I am going, you cannot come.”
<G-vec00258-003-s176><come_out.gelangen><de> Ihr werdet mich suchen, und was ich den Juden gesagt habe, sage ich jetzt auch euch: Wohin ich gehe, dorthin könnt ihr nicht gelangen.
<G-vec00258-003-s177><come_out.gelangen><en> If you come to our website via a Google advert, Google AdWords will place a cookie on your device ("conversion cookie").
<G-vec00258-003-s177><come_out.gelangen><de> Wenn Sie über eine Googleanzeige auf unsere Webseite gelangen, setzt Google Adwords einen Cookie auf Ihrem Gerät („Conversion Cookie“).
<G-vec00258-003-s178><come_out.gelangen><en> The works resulting from this experience address our frequently ambiguous attitude to what is foreign to us: whereas “exotic” luxury items and food such as tropical fruit are regarded as positive and precious, people who come to us as refugees from the same countries are often rejected as being “foreign,” and their “exotic” nature is sometimes even perceived as a threat.
<G-vec00258-003-s178><come_out.gelangen><de> Die in der Folge entstandene Arbeiten thematisieren unser oft zwiespältiges Verhältnis zum Fremden: so wird das ‚Exotische‘ in Form von Luxusgütern und Essen, etwa den geschätzten Südfrüchten, als positiv und begehrenswert empfunden, während Menschen, die aus denselben Regionen der Erde als Geflüchtete zu uns gelangen, aufgrund ihrer ‚Fremdheit‘ Ablehnung erfahren, oder das ‚Exotische‘ gar als Bedrohung empfunden wird.
<G-vec00258-003-s179><come_out.gelangen><en> Over the past weeks, frequent interactions took place to come to a common understanding on the way forward for a long-term, strategic ESA–EU partnership, building on the successes so far: Galileo and EGNOS already provide world-class navigation services and Copernicus is the most complete Earth observation system in the world.
<G-vec00258-003-s179><come_out.gelangen><de> In den letzten Wochen haben zahlreiche Gespräche stattgefunden, um zu einem gemeinsamen Verständnis über das weitere Vorgehen im Hinblick auf eine langfristige strategische Partnerschaft zwischen der ESA und der EU zu gelangen, die auf den bisherigen Erfolgen aufbaut: Galileo und EGNOS bieten bereits Navigationsdienste der Spitzenklasse, und Copernicus ist das umfassendste Erdbeobachtungssystem der Welt.
<G-vec00258-003-s180><come_out.gelangen><en> Let the inner joy within you come to the surface.
<G-vec00258-003-s180><come_out.gelangen><de> Lasst die innere Freude inwendig in euch an die Oberfläche gelangen.
<G-vec00258-003-s181><come_out.gelangen><en> In a further advantageous embodiment of the invention, an impermeable immersion liquid protective layer is at least one surface of the terminating element, which can come into contact with immersion liquid, is applied.
<G-vec00258-003-s181><come_out.gelangen><de> Bei einer weiteren vorteilhaften Ausgestaltung der Erfindung ist auf wenigstens eine Oberfläche des Abschlußelements, die mit Immersionsflüssigkeit in Berührung gelangen kann, eine für Immersionsflüssigkeit undurchlässige Schutzschicht aufgebracht.
<G-vec00258-003-s182><come_out.gelangen><en> “Through your prayer, night and day, you bring before God the lives of so many of our brothers and sisters who for various reasons cannot come to him to experience his healing mercy, even as he patiently waits for them.
<G-vec00258-003-s182><come_out.gelangen><de> Durch euer Gebet tragt ihr Tag und Nacht das Leben vieler Brüder und Schwestern vor den Herrn, die aus verschiedenen Gründen nicht zu ihm gelangen und die Erfahrung seiner heilenden Barmherzigkeit machen können, während er sie erwartet, um ihnen Gnade zu erweisen.
<G-vec00258-003-s183><come_out.gelangen><en> See what we come to.
<G-vec00258-003-s183><come_out.gelangen><de> Seht, wozu wir gelangen.
<G-vec00258-003-s184><come_out.gelangen><en> This affects your health and energy (apart from the fact that plastic residues come into your food).
<G-vec00258-003-s184><come_out.gelangen><de> Dies ist negativ für Ihre Gesundheit und Energie (neben der Tatsache, dass Plastikreste ins Essen gelangen).
<G-vec00258-003-s185><come_out.gelangen><en> In Stage 2 of the Product Backlog, Items come exclusively from Stage 3.
<G-vec00258-003-s185><come_out.gelangen><de> In die Stufe 2 des Product Backlogs gelangen Items ausschließlich aus der Stufe 3.
<G-vec00258-003-s186><come_out.gelangen><en> From here, the path follows the stream bank and a little further on we come to the narrow part of the stream, where the gorge virtually begins.
<G-vec00258-003-s186><come_out.gelangen><de> Von hier aus folgt der Pfad dem Flussufer und ein bisschen weiter gelangen wir zur Enge des Flusslaufes, an der die Schlucht eigentlich beginnt.
<G-vec00258-003-s187><come_out.gelangen><en> With the help of this Upper Force, the world can come to the correct condition.
<G-vec00258-003-s187><come_out.gelangen><de> Mit Hilfe dieser Höheren Kraft kann die Welt zum richtigen Zustand gelangen.
<G-vec00258-003-s188><come_out.gelangen><en> We use the information to compile reports and to help us improve the website. The cookies collect information in an anonymous form, including the number of visitors to the websites, where visitors have come to the website from and the pages they visited.
<G-vec00258-003-s188><come_out.gelangen><de> Wir verwenden diese Daten, um Berichte zu erstellen und unsere Website zu verbessern Die Cookies erfassen Daten anonymisiert; es wird beispielsweise die Anzahl der Website-Besucher registriert, von wo aus Besucher auf die Websites gelangen sowie die Seiten, die sie besuchen.
<G-vec00258-003-s189><come_out.gelangen><en> Going past St. Johann im Pongau you will finally come to the region of Zell am See-Kaprun and to the Seehotel Bellevue, which is located in Thumersbach on the eastern lakeshore.
<G-vec00258-003-s189><come_out.gelangen><de> Über St. Johann im Pongau gelangen Sie schließlich in die Region Zell am See-Kaprun und zum Seehotel Bellevue, welches sich bei Thumersbach am östlichen Ufer des Zeller Sees befindet.
<G-vec00258-003-s285><come_out.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00258-003-s285><come_out.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00258-003-s286><come_out.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00258-003-s286><come_out.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00258-003-s287><come_out.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00258-003-s287><come_out.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00258-003-s288><come_out.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00258-003-s288><come_out.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00258-003-s289><come_out.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00258-003-s289><come_out.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00258-003-s290><come_out.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00258-003-s290><come_out.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00258-003-s291><come_out.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00258-003-s291><come_out.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00258-003-s292><come_out.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00258-003-s292><come_out.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00258-003-s293><come_out.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00258-003-s293><come_out.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00258-003-s294><come_out.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00258-003-s294><come_out.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00258-003-s295><come_out.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00258-003-s295><come_out.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00258-003-s296><come_out.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00258-003-s296><come_out.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00258-003-s297><come_out.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00258-003-s297><come_out.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00258-003-s298><come_out.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00258-003-s298><come_out.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00258-003-s299><come_out.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00258-003-s299><come_out.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00258-003-s300><come_out.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00258-003-s300><come_out.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00258-003-s301><come_out.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00258-003-s301><come_out.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00258-003-s302><come_out.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00258-003-s302><come_out.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00258-003-s303><come_out.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00258-003-s303><come_out.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00258-003-s551><come_out.stammen><en> But where does this Life come from to raise the dead?
<G-vec00258-003-s551><come_out.stammen><de> Woher stammt aber dieses Leben, das die Toten auferstehen lässt.
<G-vec00258-003-s552><come_out.stammen><en> 93.30% 97.80% The majority of visitors come from United States.
<G-vec00258-003-s552><come_out.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Deutschland, Reino Unido, Kanada, Indien & Vereinigte Staaten.
<G-vec00258-003-s553><come_out.stammen><en> Fun fact: Welsh ponies come from Wales and date back to the time of the Celts.
<G-vec00258-003-s553><come_out.stammen><de> Interessante Tatsache: Das Welsh-Pony stammt aus Wales und hat seine Ursprünge in der Zeit der Kelten.
<G-vec00258-003-s554><come_out.stammen><en> The majority of visitors come from United States, Italy, Greece, Spain, Poland & Chile.
<G-vec00258-003-s554><come_out.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Türkei, Polen, Spanien, Niederlande, Schweiz und Deutschland.
<G-vec00258-003-s555><come_out.stammen><en> Most of our clients come from the creative sector.
<G-vec00258-003-s555><come_out.stammen><de> Ein Großteil unserer KundInnen stammt aus dem Kreativbereich.
<G-vec00258-003-s556><come_out.stammen><en> The majority of visitors come from Germany, France, Indonesia, United Kingdom, Austria & Uruguay. City City Rank
<G-vec00258-003-s556><come_out.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Spanien, Deutschland, Australien, Vietnam, Reino Unido und Schweiz.
<G-vec00258-003-s557><come_out.stammen><en> Approximately half of all fossil resources now come from sources lying below the sea floor.
<G-vec00258-003-s557><come_out.stammen><de> Inzwischen stammt rund die Hälfte der fossilen Bodenschätze aus unter dem Meeresgrund liegenden Quellen.
<G-vec00258-003-s558><come_out.stammen><en> Even his Fleur de Sel does not just come from anywhere, rather he produces it himself.
<G-vec00258-003-s558><come_out.stammen><de> Auch sein Fleur de Sel stammt nicht von irgendwo, sondern aus seiner eigenen Produktion.
<G-vec00258-003-s559><come_out.stammen><en> A web analysis service collects, inter alia, data about the website from which a person has come (the so-called referrer), which sub-pages were visited, or how often and for what duration a sub-page was viewed.
<G-vec00258-003-s559><come_out.stammen><de> Ein Webanalysedienst erhebt unter anderem Daten über die Website, von der eine Person stammt (sogenannter Referrer), welche Unterseiten besucht wurden oder wie oft und für wie lange eine Unterseite aufgerufen wurde.
<G-vec00258-003-s560><come_out.stammen><en> Those who come from Eritrea and ask for asylum in Switzerland will have higher hurdles in the future.
<G-vec00258-003-s560><come_out.stammen><de> Wer aus Eritrea stammt und in der Schweiz um Asyl ersucht, hat künftig höhere Hürden.
<G-vec00258-003-s561><come_out.stammen><en> This is quite correct; but the proletariat must also recognize that the ‘national' element does not come from the oppressed and exploited masses, but from their oppressors and exploiters - the bourgeoisie.
<G-vec00258-003-s561><come_out.stammen><de> Dies ist ganz richtig, aber das Proletariat muss auch anerkennen, dass das nationale Element nicht von den unterdrückten und ausgebeuteten Massen stammt, sondern von ihren Unterdrückern und Ausbeutern - die Bourgeoisie.
<G-vec00258-003-s562><come_out.stammen><en> Many of the best grapes come from the limestone Arrábida hills high over the peninsula’s southern coast.
<G-vec00258-003-s562><come_out.stammen><de> Ein Großteil der besten Trauben stammt aus dem kalksteinhaltigen Arrábida Hügelland, das sich hoch über der südlichen Küste der Halbinsel erstreckt.
<G-vec00258-003-s563><come_out.stammen><en> Approximately one third of the members come from the fields of administration and education and approximately two thirds from the world of business, from bank institutes to medium-sized companies to global corporations.
<G-vec00258-003-s563><come_out.stammen><de> Rund ein Drittel der Mitglieder stammt aus dem Verwaltungs- und Bildungsbereich, etwa zwei Drittel aus der Wirtschaft, vom Bankinstitut über das mittelständische Unternehmen bis hin zum Weltkonzern.
<G-vec00258-003-s564><come_out.stammen><en> The basic prerequisites are that the ingredients come from the region, that production is regional, and that the products are firmly rooted in regional gastronomy.
<G-vec00258-003-s564><come_out.stammen><de> Grundvoraussetzungen sind, dass der Rohstoff aus der Region stammt, die Produktion örtlich erfolgt und die Produkte in der regionalen Gastronomie verankert sind.
<G-vec00258-003-s565><come_out.stammen><en> Authentication is a security measure implemented by NTP to ensure that the time signal that is sent comes from where it claims to come from.
<G-vec00258-003-s565><come_out.stammen><de> Die Authentifizierung ist eine Sicherheitsmaßnahme, die von NTP implementiert wird, um sicherzustellen, dass das gesendete Zeitsignal von der Stelle kommt, von der es angeblich stammt.
<G-vec00258-003-s566><come_out.stammen><en> The essential oils come from organic farming.
<G-vec00258-003-s566><come_out.stammen><de> Oliven-ätherische Öl stammt aus kontrolliert biologischem Anbau.
<G-vec00258-003-s567><come_out.stammen><en> The majority of international clients come from Venezuela, Jordan and China.
<G-vec00258-003-s567><come_out.stammen><de> Der Großteil der internationalen Kunden stammt aus Venezuela und Jordanien sowie aus China.
<G-vec00258-003-s568><come_out.stammen><en> Smartly Dressed Games is the name of the company that was created by Nelson and this probably isn’t the last title to come from them.
<G-vec00258-003-s568><come_out.stammen><de> Smartly Dressed Games ist der Name der Firma, die von Nelson gegründet wurde, und das ist wahrscheinlich nicht der letzte Titel, der von ihnen stammt.
<G-vec00258-003-s569><come_out.stammen><en> It’s name come from the work “Skufos” which namastea dating means giant cup in ancient Greek, and it is because it looks like one morphologically as it is surrounded from the higher mountain tops of Lefka Ori.
<G-vec00258-003-s569><come_out.stammen><de> Der Name stammt von “Skufos”, was auf Altgriechisch große Tasse bedeutet: und das aufgrund dessen, weil der Ort von den höheren Berggipfeln von Lefka Ori umgeben ist.
<G-vec00258-003-s570><come_out.treffen><en> In the process, people can come together who work in various forms of the care sector: professional care providers, caregivers in family and neighbour contexts, and those in self-care situations.
<G-vec00258-003-s570><come_out.treffen><de> Dabei treffen Menschen zusammen, die in verschiedener Form Arbeitende in diesem Bereich sind: Beruflich Sorgearbeitende, Sorgearbeitende in familiären und nachbarschaftlichen Zusammenhängen und in der Selbstsorge Tätige.
<G-vec00258-003-s571><come_out.treffen><en> Here you will come across a lot of young people and probably for the first time in a long time feel that there is something happening in the South Island!
<G-vec00258-003-s571><come_out.treffen><de> Hier wirst du viele junge Menschen treffen und vermutlich zum ersten Mal seit längerer Zeit das Gefühl haben, dass in Neuseeland ja doch etwas los ist.
<G-vec00258-003-s572><come_out.treffen><en> All the Syrians, as the UN Security Council resolution says, must sit down and come to an agreement.
<G-vec00258-003-s572><come_out.treffen><de> Alle Syrer sollten in Übereinstimmung mit der Resolution des UN-Sicherheitsrats am Verhandlungstisch zusammenkommen und eine Vereinbarung treffen.
<G-vec00258-003-s573><come_out.treffen><en> The prophet Isaiah brings to view the fearful deception which will come upon the wicked, causing them to count themselves secure from the judgments of God: "We have made a covenant with death, and with hell are we at agreement. When the overflowing scourge shall pass through, it shall not come unto (378) us; for we have made lies our refuge, and under falsehood have we hid ourselves." Isa.
<G-vec00258-003-s573><come_out.treffen><de> Der Prophet Jesaja weist auf die furchtbare Täuschung hin, welche über die Gottlosen kommen wird, so daß sie sich vor den Gerichten Gottes sicher fühlen: „Wir haben mit dem Tode einen Bund und mit der Hölle einen Vertrag gemacht; wenn eine Flut dahergeht, wird sie uns nicht treffen; denn wir haben die Lüge zu unserer Zuflucht und Heuchelei zu unserem Schirm gemacht.“ (Jes.
<G-vec00258-003-s574><come_out.treffen><en> Things often come to me with time, so a day later I sat on the beach and cried.
<G-vec00258-003-s574><come_out.treffen><de> Einen Tag später – manchmal treffen mich Dinge mit Zeitverzögerung – habe ich dann am Strand gesessen und geweint.
<G-vec00258-003-s575><come_out.treffen><en> If you cannot manage to come from Sunday to Sunday, try and come from Thursday or Friday evening until Sunday.
<G-vec00258-003-s575><come_out.treffen><de> Wer nicht von Sonntag bis Sonntag an den Treffen teilnehmen kann, sollte am Donnerstag- oder spätestens Freitagabend ankommen und bis Sonntag bleiben.
<G-vec00258-003-s576><come_out.treffen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00258-003-s576><come_out.treffen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00258-003-s577><come_out.treffen><en> As in the best tradition, the workshop is the natural place in which craftsmanship and design come together, inextricably linking production and design.
<G-vec00258-003-s577><come_out.treffen><de> Wie in der besten Tradition ist die Werkstatt der Ort, an dem sich Handwerk und Design treffen und dabei Produktion und Planung unlösbar miteinander verbinden.
<G-vec00258-003-s578><come_out.treffen><en> Numerous national and international representatives from business and politics will come together for this first-class event in order to discuss the most current topics.
<G-vec00258-003-s578><come_out.treffen><de> Anlässlich des hochkarätigen Anlasses treffen sich zahlreiche nationale und internationale Vertreter aus Wirtschaft und Politik in Vaduz, um topaktuelle Themen zu diskutieren.
<G-vec00258-003-s579><come_out.treffen><en> Then we pass through the gates of Heaven and come across the proud people who humbly pray the Pater Noster.
<G-vec00258-003-s579><come_out.treffen><de> Dann werden wir durch die Pforte des Himmels gehen und treffen die Stolzen die demütig das Pater Noster beten.
<G-vec00258-003-s580><come_out.treffen><en> Digitalisation and sustainability – two key “mega trends” come together.
<G-vec00258-003-s580><come_out.treffen><de> Digitalisierung und Nachhaltigkeit – hier treffen zwei Megatrends aufeinander.
<G-vec00258-003-s581><come_out.treffen><en> Schedule of events You can come and get to know the JBL team personally at the following events in April 2018.
<G-vec00258-003-s581><come_out.treffen><de> Auf folgenden Veranstaltungen können Sie uns im Juni 2018 treffen und das JBL Team persönlich kennenlernen.
<G-vec00258-003-s582><come_out.treffen><en> Wherever you go, you will come across open-minded people who will be happy to speak English with you.
<G-vec00258-003-s582><come_out.treffen><de> Überall werden Sie auf aufgeschlossene Menschen treffen, die gerne mit Ihnen Englisch plaudern.
<G-vec00258-003-s583><come_out.treffen><en> If these high-stakes talks come to pass, they would be the first between a sitting US president and a North Korean leader.
<G-vec00258-003-s583><come_out.treffen><de> Eine Reise des nordkoreanischen Außenministers nach Schweden nährt nun Spekulationen über den Austragungsort für dieses erste Treffen zwischen einem amtierenden US-Präsidenten und einem nordkoreanischen Machthaber.
<G-vec00258-003-s584><come_out.treffen><en> Because particular bodily organs correspond to every point, it is possible to come to the conclusion about state of this organs.
<G-vec00258-003-s584><come_out.treffen><de> Weil es jedem Punkt bestimmte Körperorgane entsprechen, ist auf Grund des gemessenen Widerstandes den Beschluss über den Stand dieser Organe zu treffen.
<G-vec00258-003-s585><come_out.treffen><en> Graduates of the Master of Science in International Cooperation in Urban Development come upon a broad field of work which has a strong demand for professionals in international projects about urban development.
<G-vec00258-003-s585><come_out.treffen><de> Absolventen und Absolventinnen des Master of Science International Cooperation in Urban Development treffen auf ein weites Arbeitsfeld mit einer starken Nachfrage nach Fachkräften für internationale Projekte im Bereich der Stadtentwicklung.
<G-vec00258-003-s586><come_out.treffen><en> Divers, snorkelers and musicians dressed in whimsical nautical costumes come together every year in Florida for the Underwater Music Festival.
<G-vec00258-003-s586><come_out.treffen><de> Taucher, Schnorchler und Musiker treffen sich Jahr für Jahr in Florida für das Unterwasser-Musik-Festival.
<G-vec00258-003-s587><come_out.treffen><en> The event aims to create a space in which different voices come together to start dialogue and find solutions and answers to the social, emotional and health problems that women face in today's society. The Forum is an open event, free of charge, with an open debate on women's issues.
<G-vec00258-003-s587><come_out.treffen><de> Mit diesem Forum will versucht werden ein Raum zu schaffen, in welchem sich verschiedene Stimmen treffen, unterschiedliche Meinungen ausgetauscht werden um so einen Dialog anzuregen und Lösungen und Antworten auf die soziale, emotionale und gesundheitliche Problematik zu finden, mit welcher sich die Frau tagtäglich in der Gesellschaft konfrontiert sieht.
<G-vec00258-003-s588><come_out.treffen><en> In the living room, family and friends come together for mutual hours.
<G-vec00258-003-s588><come_out.treffen><de> Im Wohnzimmer treffen sich Familie und Freunde für gemeinsame Stunden.
<G-vec00258-003-s589><come_out.treten><en> Also the cooperation with students regarding bachelor’s and master’s theses as well as compulsory internships, new findings come to light that are included in further product development.
<G-vec00258-003-s589><come_out.treten><de> Auch bei der Zusammenarbeit mit Studierenden in Hinblick auf Bachelor- und Masterarbeiten sowie Pflichtpraktika treten regelmäßig neue Erkenntnisse zu Tage, die in die weitere Produktentwicklung miteinfließen.
<G-vec00258-003-s590><come_out.treten><en> Lung cancer typically develops slowly and symptoms often come on gradually.
<G-vec00258-003-s590><come_out.treten><de> Lungenkrebs entwickelt sich gewöhnlich langsam und die Symptome treten oft schrittweise auf.
<G-vec00258-003-s591><come_out.treten><en> They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.
<G-vec00258-003-s591><come_out.treten><de> Und sie sollen hineingehen in mein Heiligtum und vor meinen Tisch treten, mir zu dienen und meine Sitten zu halten.
<G-vec00258-003-s592><come_out.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which lie outside the area of responsibility of the author, a liability obligation would come into force only in the case in which the contents are aware and technically possible and reasonable, the Use in case of illegal content.
<G-vec00258-003-s592><come_out.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00258-003-s593><come_out.treten><en> In the case of direct or indirect references to third-party websites ("hyperlinks"), which are outside the responsibility of the author, a liability obligation would only come into force in the case in which the author is aware of the contents and is technically possible and reasonable, To prevent the use in the case of unlawful content.
<G-vec00258-003-s593><come_out.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten (“Hyperlinks”), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00258-003-s594><come_out.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which are beyond the scope of responsibility of Ryf Sports, a liability obligation would only come into effect in the case in which Ryf Sports is aware of the content and it technically possible and reasonable to prevent the use of illegal content.
<G-vec00258-003-s594><come_out.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches von Ryf Sports liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem Ryf Sports von den Inhalten Kenntnis hat und es technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00258-003-s595><come_out.treten><en> emmerich exclusivbrillen GmbH & Co. reserves the right to amend the conditions of the present agreement in part or in full at any time and any such amendments come into force immediately following their publication on the website.
<G-vec00258-003-s595><come_out.treten><de> emmerich exclusivbrillen GmbH & Co.KG behält sich das Recht vor, die Bestimmungen dieses Vertrages jederzeit, ganz oder teilweise abzuändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Webseite in Kraft.
<G-vec00258-003-s596><come_out.treten><en> The resolutions passed at the Extraordinary General Meeting of Kaba will come into effect upon completion of the merger.
<G-vec00258-003-s596><come_out.treten><de> Die Beschlüsse der außerordentlichen Generalversammlung von Kaba treten mit dem Vollzug des Zusammenschlusses in Kraft.
<G-vec00258-003-s597><come_out.treten><en> Any provision of the Contract that expressly or by implication is intended to come into or continue in force on or after termination shall remain in full force and effect.
<G-vec00258-003-s597><come_out.treten><de> 8.6 Jedwede Bestimmung des Vertrags, die ausdrücklich oder stillschweigend in Kraft treten oder bei oder nach Kündigung in Kraft bleiben soll, bleibt in Kraft.
<G-vec00258-003-s600><come_out.treten><en> If amendments are merely insignificant, they shall come into force immediately.
<G-vec00258-003-s600><come_out.treten><de> Sollte es sich lediglich um unwesentliche Änderungen handeln, treten diese umgehend in Kraft.
<G-vec00258-003-s601><come_out.treten><en> Everybody shall come in touch with their own greatness, their own divinity.
<G-vec00258-003-s601><come_out.treten><de> Jeder soll vielmehr mit seiner eigenen Größe, seiner eigenen Göttlichkeit in Verbindung treten.
<G-vec00258-003-s602><come_out.treten><en> All direct or indirect references to other Internet sites (links), which lie outside the area of responsibility of the author, any liability obligation would only come into effect if the author is aware of the contents, and it would be technically possible and reasonable for him to prevent the use in the event of illegal contents.
<G-vec00258-003-s602><come_out.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00258-003-s603><come_out.treten><en> Straight line projection of the zone upwards indicates that it will come to surface (likely under till cover) very near the north boundary of the Burns Block.
<G-vec00258-003-s603><come_out.treten><de> Die geradlinige Weiterführung der Zone nach oben weist darauf hin, dass sie sehr nahe an der nördlichen Grenze des Burns Blocks zu Tage treten wird (wahrscheinlich unterhalb einer Geschiebemergelschicht).
<G-vec00258-003-s604><come_out.treten><en> The changed terms and conditions come in the place of the previous version of the General Terms and Conditions.
<G-vec00258-003-s604><come_out.treten><de> Die geänderten Bedingungen treten an die Stelle der vorhergehenden allgemeinen Geschäftsbedingungen.
<G-vec00258-003-s605><come_out.treten><en> In the case of direct or indirect references to external websites („links“), which are outside the responsibility of the website operator, a liability obligation would only come into force in the case where the website operator is aware of the contents and it is technically possible for him And it would be reasonable to prevent the use of illegal contents.
<G-vec00258-003-s605><come_out.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00258-003-s607><come_out.treten><en> The new prices will come into force from the announcement of the regulation. The cost of transport and other expenses are calculated separately.
<G-vec00258-003-s607><come_out.treten><de> Die neuen Preise treten mit der Bekanntgabe der Verordnung in Kraft, die Kosten für Transport und Sonstiges werden gesondert berechnet.
<G-vec00258-003-s627><come_out.verfügen><en> The rooms, suites and apartments at Garni Anni come with a balcony with mountain views and a bathroom with shower or bath.
<G-vec00258-003-s627><come_out.verfügen><de> Die Zimmer, Suiten und Apartments im Garni Anni verfügen über einen Balkon mit Bergblick und ein Badezimmer mit einer Dusche oder Badewanne.
<G-vec00258-003-s628><come_out.verfügen><en> All of our products come with a 100 percent guarantee of customer satisfaction.
<G-vec00258-003-s628><come_out.verfügen><de> Alle unsere Produkte verfügen über eine 100-prozentige Garantie der Zufriedenheit unserer Kunden.
<G-vec00258-003-s629><come_out.verfügen><en> Rooms come with flat-screen TVs and tea/coffee making facilities.
<G-vec00258-003-s629><come_out.verfügen><de> Die Zimmer verfügen über einen Flachbild-TV sowie Tee- und Kaffeezubehör.
<G-vec00258-003-s630><come_out.verfügen><en> The welcoming rooms come with a bathroom with a hairdryer, a direct dial telephone, a hire safe and a minibar.
<G-vec00258-003-s630><come_out.verfügen><de> Die freundlich eingerichteten Zimmer verfügen über Bad/WC, Haartrockner, Minibar, Mietsafe und Direktwahltelefon.
<G-vec00258-003-s631><come_out.verfügen><en> Rooms at Sheraton Sopot come with air conditioning and a flat-screen satellite TV.
<G-vec00258-003-s631><come_out.verfügen><de> Die Zimmer im Sheraton Colonia Golf And Spa Resort verfügen über eine Minibar, einen TV und ein eigenes Bad.
<G-vec00258-003-s632><come_out.verfügen><en> All these pickups come with 25K pots, stereo jack, battery clip and other mounting hardware.
<G-vec00258-003-s632><come_out.verfügen><de> Alle AHB-1 Tonabnehmer verfügen über 25K Töpfe, Klinkenstecker, Batterie-Clip und andere Montage-Hardware.
<G-vec00258-003-s633><come_out.verfügen><en> Divná pani Luxury Gallery Rooms provides certain rooms with garden views, and all rooms come with a private bathroom.
<G-vec00258-003-s633><come_out.verfügen><de> Das Divná pani Luxury Gallery Rooms bietet Zimmer mit Gartenblick und alle Zimmer verfügen über ein eigenes Bad.
<G-vec00258-003-s634><come_out.verfügen><en> All units come with a terrace, a kitchenette with a fridge, and a private bathroom with bath or shower.
<G-vec00258-003-s634><come_out.verfügen><de> Die modernen Zimmer verfügen über Holzböden, Kabel/Sat-TV, einen Wasserkocher sowie ein eigenes Bad mit einer Warmwasserdusche.
<G-vec00258-003-s635><come_out.verfügen><en> They come with a microwave, an electric kettle and a fridge as well as bathrooms with a shower, a spa bathtub and dressing gowns.
<G-vec00258-003-s635><come_out.verfügen><de> Sie verfügen über eine Mikrowelle, einen Wasserkocher und eine Kaffee-/Teemaschine sowie über private Badezimmer mit einer Dusche, einem Jacuzzi und kostenlosen Pflegeprodukten.
<G-vec00258-003-s636><come_out.verfügen><en> The rooms come with a private or shared bathroom.
<G-vec00258-003-s636><come_out.verfügen><de> Alle Zimmer verfügen über ein eigenes Bad oder bieten Zugang zu einem Gemeinschaftsbad.
<G-vec00258-003-s637><come_out.verfügen><en> Thus they are virtually maintenance-free, very rarely prone to malfunctions, require no lubricants, may be positioned exactly, have a constant stroke speed, and come with a mechanical self-locking mechanism.
<G-vec00258-003-s637><come_out.verfügen><de> So sind sie nahezu wartungsfrei, wenig fehleranfällig, schmiermittelfrei, exakt positionierbar und verfügen über eine konstante Hubgeschwindigkeit sowie über eine mechanische Selbsthemmung.
<G-vec00258-003-s638><come_out.verfügen><en> All units come with a patio, a kitchen with an oven and a microwave, and a private bathroom with bidet.
<G-vec00258-003-s638><come_out.verfügen><de> Alle Unterkünfte verfügen über eine Terrasse, eine Küche mit einem Backofen und einer Mikrowelle sowie ein eigenes Bad mit einem Bidet.
<G-vec00258-003-s639><come_out.verfügen><en> Bathrooms come with a shower, complimentary toiletries and towels.
<G-vec00258-003-s639><come_out.verfügen><de> Badezimmer verfügen über eine Dusche, einen Fön und Handtücher.
<G-vec00258-003-s640><come_out.verfügen><en> All rooms at the Cinco Calderas come with en suite bathroom complete with amenities.
<G-vec00258-003-s640><come_out.verfügen><de> Alle Zimmer im Cinco Calderas verfügen über ein eigenes Bad mit Pflegeprodukten.
<G-vec00258-003-s641><come_out.verfügen><en> rooms at the Linne come with satellite TV, tea/coffee facilities and a private bathroom with a shower.
<G-vec00258-003-s641><come_out.verfügen><de> Die hellen Zimmer im Linne verfügen über Sat-TV, Kaffee- und Teezubehör sowie ein eigenes Bad mit einer Dusche.
<G-vec00258-003-s642><come_out.verfügen><en> Featuring a balcony with outdoor furniture, the bright apartments come with tiled floors and a kitchenette.
<G-vec00258-003-s642><come_out.verfügen><de> Die hellen Apartments verfügen über einen Balkon mit Gartenmöbeln sowie Fliesenböden und eine Küchenzeile.
<G-vec00258-003-s643><come_out.verfügen><en> All wooden furnished, rooms here come with Satellite television, a fan, and a desk.
<G-vec00258-003-s643><come_out.verfügen><de> Alle mit Holz eingerichteten Zimmer verfügen über Sat-TV, einen Ventilator und einen Schreibtisch.
<G-vec00258-003-s644><come_out.verfügen><en> The non-smoking apartments and studios at the Cathedral all come with a private bathroom with a shower or a bathtub, a fully equipped kitchenette, and a satellite TV.
<G-vec00258-003-s644><come_out.verfügen><de> Die rauchfreien Apartments und Studios im Cathedral verfügen alle über ein eigenes Bad mit einer Dusche oder einer Badewanne, eine komplett ausgestattete Küchenzeile und Sat-TV.
<G-vec00258-003-s645><come_out.verfügen><en> Newer DVD players often come with a high definition upconversion feature as well.
<G-vec00258-003-s645><come_out.verfügen><de> Neuere DVD-Player verfügen häufig auch über eine Funktion zur Konvertierung in High Definition.
<G-vec00524-002-s190><come_out.geben><en> Surf boots come in different thicknesses such as 0.5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm or even 7 mm thick.
<G-vec00524-002-s190><come_out.geben><de> Surfschuhe gibt es in verschiedenen Stärken wie 0,5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm oder sogar 7 mm.
<G-vec00524-002-s191><come_out.geben><en> Chatbots come in different shapes and forms.
<G-vec00524-002-s191><come_out.geben><de> Chatbots gibt es in verschiedenen Formen und Arten.
<G-vec00524-002-s192><come_out.geben><en> Beacons come in all kinds of different formats, are scalable and highly portable. Benefits:
<G-vec00524-002-s192><come_out.geben><de> Beacons gibt es in den unterschiedlichsten Formen, sie sind skalierbar und sehr portabel.
<G-vec00524-002-s193><come_out.geben><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Wiko Sunny You'll never have to buy another screen protector for the life of your phone with the Olixar 2-in-1 screen protector pack
<G-vec00524-002-s193><come_out.geben><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Galaxy A5 2017 haben.
<G-vec00524-002-s194><come_out.geben><en> The Nucleus 6 sound processors come in a variety of colours designed to blend in with hair and skin tones.
<G-vec00524-002-s194><come_out.geben><de> Den Nucleus 6 Soundprozessor gibt es in verschiedenen Farbtönen, die zu Haut- und Haarfarben passen.
<G-vec00524-002-s195><come_out.geben><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Huawei P8 Lite.
<G-vec00524-002-s195><come_out.geben><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Gear S3 Smartwatch haben.
<G-vec00524-002-s196><come_out.geben><en> PCs come in all shapes and sizes, and the exact same tweaks might have different effects on different PC setups.
<G-vec00524-002-s196><come_out.geben><de> PCs gibt es in allen Farben und Formen, und exakt gleiche Anpassungen können verschiedene Auswirkungen auf verschiedenen PCs haben.
<G-vec00524-002-s197><come_out.geben><en> These garments come in a wide variety of styles: Tops which create a wasp waist under A-line dresses, high-waisted panties which optimally slim the stomach, upper thighs and bottom for skinny trousers, and undergarments which form a slim silhouette from chest to knee under tight-fitting knitted dresses.
<G-vec00524-002-s197><come_out.geben><de> Die Formwäsche gibt es in den unterschiedlichsten Varianten: Tops, die eine Wespentaille unter A-Linien-Kleider zaubern, Highwaist-Panties, die Bauch, Oberschenkel und Po optimal für Skinny Hosen schmälern, und Unterkleider, die von Brust bis Knie eine schlanke Silhouette unter anliegenden Strickkleidern formen.
<G-vec00524-002-s198><come_out.geben><en> Progressive Slots come in all shapes and sizes in the world of Online Gambling.
<G-vec00524-002-s198><come_out.geben><de> Progressive Slots Gibt es in allen Formen und Größen in der Welt der Online-Glücksspiel.
<G-vec00524-002-s199><come_out.geben><en> Cap constructions come in many shapes and sizes.
<G-vec00524-002-s199><come_out.geben><de> Diese Kappenkonstruktionen gibt es in vielen Formen und Größen.
<G-vec00524-002-s200><come_out.geben><en> Short-term trades come in three varieties, the typical 60 second options and the newest addition called the 2 and 5-minute expiries.
<G-vec00524-002-s200><come_out.geben><de> Kurzfristige Trades gibt es in drei Sorten, die typischen 60 Sekunden Optionen und die neueste Ergänzung genannt die 2 und 5-Minuten-Abläufe.
<G-vec00524-002-s201><come_out.geben><en> Lens filters generally come in two varieties: screw-on and front filters.
<G-vec00524-002-s201><come_out.geben><de> In der Regel gibt es Linsenfilter in zwei Varianten: Anschraub- und Frontfilter.
<G-vec00524-002-s202><come_out.geben><en> Nacho trays come in black / large with 2 cups for nachos...
<G-vec00524-002-s202><come_out.geben><de> Nachoschalen gibt es in der Ausführung schwarz / groß mit...
<G-vec00524-002-s203><come_out.geben><en> Coins come in 50 øre as well as 1, 2, 5, 10 and 20 Kroner.
<G-vec00524-002-s203><come_out.geben><de> Münzen gibt es in 50 Öre sowie 1, 2, 5, 10 und 20 Kronen.
<G-vec00524-002-s204><come_out.geben><en> All three series come with matching leggings, which are not a only a sexy accessory for the beach, but also the perfect garment for any type of beach activity – from beach volleyball to yoga workouts.
<G-vec00524-002-s204><come_out.geben><de> Zu allen drei Serien gibt es die passende Hose im Leggins-Style, die nicht nur ein sexy Strand-Accessoire ist, sondern auch der ideale Begleiter für jede Form von Strandaktivität – von Beachvolleyball bis zum Yoga-Workout.
<G-vec00524-002-s205><come_out.geben><en> Themes come in many different shapes, from blank themes with only the bare necessities, to more advanced themes with tons of features.
<G-vec00524-002-s205><come_out.geben><de> Themes gibt es in vielen verschiedenen Formen, von leeren Themes mit nur dem Nötigsten bis hin zu fortgeschritteneren Themes mit unzähligen Funktionen.
<G-vec00524-002-s206><come_out.geben><en> Heart rate monitors come in a variety of different models, with varying levels of functionality.
<G-vec00524-002-s206><come_out.geben><de> Herzfrequenzmesser gibt es in verschiedenen Modellen mit unterschiedlichen Funktionen.
<G-vec00524-002-s208><come_out.geben><en> Hotels in Germany come in all price ranges and equipments.
<G-vec00524-002-s208><come_out.geben><de> Hotels in Deutschland gibt es in allen Preisklassen und Ausstattungen.
<G-vec00524-002-s209><come_out.haben><en> The girl's shorts come with a textile side stripe and ensure freedom of movement thanks to the supple viscose material - perfect companions for the next summer!
<G-vec00524-002-s209><come_out.haben><de> Die Mädchen Shorts haben seitlich einen farblich passenden Besatz und machen aufgrund der angenehmen Viskose-Qualität jede Bewegung mit – ein toller Begleiter für den nächsten Sommer.
<G-vec00524-002-s210><come_out.haben><en> They come with a black leather upper and a removable insole for hygiene and practicality.
<G-vec00524-002-s210><come_out.haben><de> Sie haben ein Obermaterial aus schwarzem Leder und eine hygienische und praktische herausnehmbare sohle.
<G-vec00524-002-s211><come_out.haben><en> Come and find our new presentation of the wonderful smelling incense sticks from Paris in our store in the Belgian quarter in Cologne.
<G-vec00524-002-s211><come_out.haben><de> Wir haben Parfums, Keramik, Räucherstäbchen, Duftkerzen und Papeterie bei uns im Store in Köln.
<G-vec00524-002-s212><come_out.haben><en> Passengers really do come first here! Travel in the VIP seats above the driver's cab on the GoldenPass SuperPanoramic train from Montreux to Zweisimmen, and you'll feel like you are flying!
<G-vec00524-002-s212><come_out.haben><de> Hier haben Passagiere die Nase vorn: Wer im GoldenPass SuperPanoramic von Montreux nach Zweisimmen die VIP-Plätze bucht, hat das Gefühl zu fliegen, denn sie befinden sich hoch über dem Führerstand ganz vorne im Zug.
<G-vec00524-002-s213><come_out.haben><en> © direktbroker-FX, Alle wing: CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage.
<G-vec00524-002-s213><come_out.haben><de> Adresse: direktbroker.de AG, Risikohinweis: CFDs sind komplexe Instrumente und haben ein hohes Risiko, durch Hebelwirkung schnell Geld zu verlieren.
<G-vec00524-002-s214><come_out.haben><en> It is not clear why the ESM or this debt repayment fund should come up with any different results – they are in effect the same.
<G-vec00524-002-s214><come_out.haben><de> Es ist nicht ersichtlich, warum ESM und dieser Schuldentilgungsfonds verschiedene Ergebnisse haben sollten – sie entsprechen einander.
<G-vec00524-002-s215><come_out.haben><en> And because Mac, iPhone, iPad and iPod touch all come equipped with FaceTime, you can talk to iOS and macOS users across the street or across the globe.
<G-vec00524-002-s215><come_out.haben><de> Und weil Mac, iPhone, iPad und iPod touch alle FaceTime haben, kannst du überall mit Benutzern von iOS und macOS sprechen.
<G-vec00524-002-s216><come_out.haben><en> The bathrooms come with a bathtub, a shower and free toiletries for more comfort.
<G-vec00524-002-s216><come_out.haben><de> Die Badezimmer haben eine Badewanne, eine Dusche und kostenlose Pflegeprodukte für mehr Komfort.
<G-vec00524-002-s217><come_out.haben><en> Some hotel rooms come with a wonderful view over the city.
<G-vec00524-002-s217><come_out.haben><de> Gäste haben die Möglichkeit, einen wunderbaren Blick auf den Hafen zu bewundern.
<G-vec00524-002-s218><come_out.haben><en> The expensive models come with a built-in sensor that lets the drone steer clear of large and small objects.
<G-vec00524-002-s218><come_out.haben><de> De kostspieligeren Modelle haben einen eingebauten Sensor, der die Drohnen um große Gegenstände herum steuern lässt.
<G-vec00524-002-s219><come_out.haben><en> The luxury rooms are 40 m², and all come with balconies and terraces with a pool, sea or garden view.
<G-vec00524-002-s219><come_out.haben><de> Die Luxuszimmer sind 40 qm groß und haben Balkon oder Terrasse mit Ausblick auf den Pool, das Meer oder den Garten.
<G-vec00524-002-s220><come_out.haben><en> Most units come with a balcony.
<G-vec00524-002-s220><come_out.haben><de> Die meisten Unterkünfte haben einen Balkon.
<G-vec00524-002-s221><come_out.haben><en> The truth is, I think, that Patrick wants to put a girl in his park who looks like the girls in his magazine, which only proves once again his remote controlled nature, and there’s more to come, because Patrick wants a girl to make him come who is sexually competent but has never had sex and this, I think, is where Patrick’s remote-controlled nature reaches its limitlessly stupid climax.
<G-vec00524-002-s221><come_out.haben><de> Tatsächlich, denke ich weiter, will Patrick sich ein Mädchen in sein Gehege stellen, das so aussieht wie die Mädchen aus seinem Magazin, was sein Ferngesteuertsein einmal mehr auf den Punkt bringt und es erreicht noch seinen unglaublichen Höhepunkt, denn seinen Höhepunkt, denke ich, will Patrick von einem Mädchen verschafft haben, das sexuell kompetent ist, aber noch nie Sex hatte und an dieser Stelle, denke ich, erreicht Patricks Ferngesteuertsein in seiner ganzen unbegrenzten Dummheit seinen Höhepunkt.
<G-vec00524-002-s222><come_out.haben><en> The right images on the web may come with copyright restrictions.
<G-vec00524-002-s222><come_out.haben><de> Die richtigen Bilder im Web haben möglicherweise Copyright Beschränkungen.
<G-vec00524-002-s223><come_out.haben><en> Both of them come with a Full HD display, but only the HP comes with a contrast-rich IPS panel with wide viewing angles.
<G-vec00524-002-s223><come_out.haben><de> Beide haben eine Full-HD-Anzeige, doch nur HP setzt auf ein blickwinkelstabiles und kontraststarkes IPS-Panel.
<G-vec00524-002-s224><come_out.haben><en> There is a statement in the "Remarks" to the effect that society is not powerless against the laws of science, that man, having come to know economic laws, can utilize them in the interests of society.
<G-vec00524-002-s224><come_out.haben><de> In den „Bemerkungen“ ist der bekannte Leitsatz enthalten, dass die Gesellschaft den Gesetzen der Wissenschaft gegenüber nicht machtlos ist, dass die Menschen, wenn sie die ökonomischen Gesetze erkannt haben, dieselben im Interesse der Gesellschaft ausnutzen können.
<G-vec00524-002-s225><come_out.haben><en> The rooms come with en suite bathrooms featuring a shower, a hairdryer and complimentary toiletries.
<G-vec00524-002-s225><come_out.haben><de> Die Zimmer haben einen modernen Dekor und En-suite-Badezimmer mit einer Dusche, Morgenmänteln und einem Fön.
<G-vec00524-002-s226><come_out.haben><en> 2014 will be a crucial year in deciding who will come out ahead in future years.
<G-vec00524-002-s226><come_out.haben><de> 2014 entscheidet sich, wer in den kommenden Jahren die Nase vorn haben wird.
<G-vec00524-002-s227><come_out.haben><en> Most models come with three or four shelves; exceptions to this are the double door freezer and double door bakery freezer.
<G-vec00524-002-s227><come_out.haben><de> Die meisten Gefrierschränke haben drei oder vier Fächer; eine Ausnahme stellen hier der zweitürige Gefrierschrank sowie der zweitürige Bäckerei-Gefrierschrank dar.
<G-vec00524-002-s456><come_out.sein><en> Biofuel can come in solid, liquid, or gaseous form.
<G-vec00524-002-s456><come_out.sein><de> Biobrennstoffe können fester, flüssiger oder gasförmiger Natur sein.
<G-vec00524-002-s457><come_out.sein><en> It is very common for such potentially unwanted applications to come bundled with freeware and adware.
<G-vec00524-002-s457><come_out.sein><de> Es ist durchaus üblich, dass solche potenziell unerwünschten Anwendungen mit Freeware und Adware gebündelt sein.
<G-vec00524-002-s458><come_out.sein><en> 13 And seeing a fig-tree afar off, having leaves, he came, if haply he might find any thing on it: and when he came to it, he found nothing but leaves: for the time of figs had not yet come.
<G-vec00524-002-s458><come_out.sein><de> 13 Und er sah einen Feigenbaum von ferne, der Blätter hatte; da trat er hinzu, ob er etwas darauf fände, und da er hinzukam, fand er nichts denn nur Blätter, denn es war noch nicht Zeit, daß Feigen sein sollten.
<G-vec00524-002-s459><come_out.sein><en> The end of the Italian Grand Prix also marked the end of an epoch: After 16 years, Formel Schumi should come to an end for the time being, the end of the season also meaning the end of an era for Ferrari, the most successful epoch a Formula 1 driver ever had together with his team.
<G-vec00524-002-s459><come_out.sein><de> Dass Ende des Großen Preises von Italien markiert auch das rasende Ende einer Epoche: Nach 16 Jahren soll vorerst Schluss sein mit der Formel Schumi, geht zum Saisonende auch eine Zeitrechnung von Ferrari zu Ende, die erfolgreichste Epoche, die je ein Formel-1-Fahrer mit seinem Team hatte.
<G-vec00524-002-s460><come_out.sein><en> The embossed wax must come from organic farming.
<G-vec00524-002-s460><come_out.sein><de> Das Imprägnierwachs muss aus kontrolliert biologischem Anbau sein.
<G-vec00524-002-s461><come_out.sein><en> Therefore, it should come as no surprise that the background of the game shows a vast, barren landscape.
<G-vec00524-002-s461><come_out.sein><de> Daher sollte es keine Überraschung sein, dass der Hintergrund des Spiels eine weite, öde Landschaft zeigt.
<G-vec00524-002-s462><come_out.sein><en> Another example when the “nofollow" attribute can come handy are widget links.
<G-vec00524-002-s462><come_out.sein><de> Ein weiteres Beispiel für einen Fall, in dem das Attribut "nofollow" praktisch sein kann, sind Widget-Links.
<G-vec00524-002-s463><come_out.sein><en> 13:14 And it shall come to pass, that as the chased roe, and as sheep that no man gathereth, they shall turn every man to his own people, and shall flee every man to his own land.
<G-vec00524-002-s463><come_out.sein><de> 13:14 Und es wird wie mit einer verscheuchten Gazelle sein und wie mit einer Herde, die niemand sammelt: jeder wird sich zu seinem Volk wenden und jeder in sein Land fliehen.
<G-vec00524-002-s464><come_out.sein><en> Today the rule is: anyone can come in who earns their living in the sports business and who has a relevant business relationship with at least one of the exhibitors.
<G-vec00524-002-s464><come_out.sein><de> Heute gilt: Zugelassen ist, wer sein Geld im Sport Business verdient und mit mindestens einem Aussteller eine einschlägige Geschäftsbeziehung hat.
<G-vec00524-002-s465><come_out.sein><en> The Ability quickly to tie around the waist can come in handy always.
<G-vec00524-002-s465><come_out.sein><de> Die Fähigkeit, schnell binden Sie sich um die eigene Taille kann immer nützlich sein.
<G-vec00524-002-s466><come_out.sein><en> Its Facebook messenger block feature can come in handy for the parents to ensure that their kids don’t engage in inappropriate activities.
<G-vec00524-002-s466><come_out.sein><de> Die Facebook-Messenger-Block -Funktion kann für die Eltern nützlich sein, um sicherzustellen, dass ihre Kinder keine unangemessenen Aktivitäten ausführen.
<G-vec00524-002-s467><come_out.sein><en> INTRODUCTION Jesus tells us: “Whoever wishes to come after me must deny himself, take up his cross each day and follow me”. This is an invitation addressed to everyone: to those who are married and those who are single, to young people, adults and the elderly, to the rich and poor, and to people of every nationality.
<G-vec00524-002-s467><come_out.sein><de> EINFÜHRUNG Jesus sagt: „Wer mein Jünger sein will, der verleugne sich selbst, nehme täglich sein Kreuz auf sich und folge mir nach.“ Das ist eine Aufforderung, die allen gilt, Ledigen und Verheirateten, Jugendlichen, Erwachsenen und alten Menschen, Reichen und Armen, Menschen aller Nationalitäten.
<G-vec00524-002-s468><come_out.sein><en> The LTE and 3G model should come out by the end of November.
<G-vec00524-002-s468><come_out.sein><de> Die Version mit LTE- und 3G-fähigem Mobilfunkmodul soll bis Ende November lieferbar sein.
<G-vec00524-002-s469><come_out.sein><en> And we though thought that we must had come decent far.
<G-vec00524-002-s469><come_out.sein><de> Und wir meinten schon, dass wir ganz ordentlich vorangekommen sein muessten.
<G-vec00524-002-s470><come_out.sein><en> You’ll come to your own conclusions.
<G-vec00524-002-s470><come_out.sein><de> Sie werden dann in der Lage sein, eigene Schlüsse zu ziehen.
<G-vec00524-002-s471><come_out.sein><en> When making a green smoothie I can rest assure it’ll come out silky smooth, every time.
<G-vec00524-002-s471><come_out.sein><de> Wenn ich grüne Smoothies herstelle, dann kann ich mir sicher sein, dass jedes Mal ein seidig weicher flüssiger Smoothie entsteht.
<G-vec00524-002-s472><come_out.sein><en> 8 And David saith on that day, 'Any one smiting the Jebusite, (let him go up by the watercourse), and the lame and the blind -- the hated of David's soul,' -- because the blind and lame say, 'He doth not come into the house.'
<G-vec00524-002-s472><come_out.sein><de> 8Da sprach David an diesem Tage: Wer die Jebusiter schlägt und durch den Schacht hinaufsteigt und die Lahmen und Blinden erschlägt, die David verhasst sind, der soll Hauptmann und Oberster sein.
<G-vec00524-002-s473><come_out.sein><en> At the same time, there is debate as to whether tighter capital requirements could come with a longer-term cost for the real economy.
<G-vec00524-002-s473><come_out.sein><de> Gleichzeitig gibt es eine Debatte darüber, ob höhere Kapitalanforderungen mit längerfristigen Kosten für die Realwirtschaft verbunden sein könnten.
<G-vec00524-002-s474><come_out.sein><en> As the oil acts on the sensitive oral mucosa for 10 to 20 minutes, the oil seeds and nuts should come from certified organic farming.
<G-vec00524-002-s474><come_out.sein><de> Da das Öl 10 bis 20 Minuten auf die empfindliche Mundschleimhaut einwirkt, sollte die Auswahl eines dafür bevorzugten Öles unbedingt auf Bio-Pflanzenöle ausgerichtet sein, die aus Ölsaaten und Nüssen aus kontrolliert biologischem Anbau und kalt gepresst werden.
<G-vec00524-002-s665><come_out.werden><en> These working groups are thematically orientated towards those future technologies that are relevant for the future of German industry and that the startups are active in: materials technologies, pharma, biotechnology and genetic technology, medical technology, energy technologies, digital business models/smart services and Industry 4.0 as well as integrated mobility (with more to come).
<G-vec00524-002-s665><come_out.werden><de> Die Arbeitsgruppen orientieren sich dabei thematisch an den für die Zukunft der deutschen Industrie relevanten Zukunftstechnologien, in denen die Startups aktiv sind: Materialtechnologien, integrierte Mobilität (die Liste wird schrittweise erweitert).
<G-vec00524-002-s666><come_out.werden><en> Come and see the ice kingdom at night when the spotlights light up the ice.
<G-vec00524-002-s666><come_out.werden><de> Besonders faszinierend – das Eiskönigreich in der Nacht, wenn es von Scheinwerfern angeleuchtet wird.
<G-vec00524-002-s667><come_out.werden><en> First, take the time to visit the Roman ruins on the Sirmione peninsula, a touristy and lively little town located on a promontory surrounded by water, where the singer Maria Callas liked to come to relax.
<G-vec00524-002-s667><come_out.werden><de> Nehmen Sie sich zuerst die Zeit, um die Ruinen aus römischer Zeit auf der Halbinsel Sirmione zu besuchen, einer lebendigen kleinen Stadt, die gerne von Touristen besucht wird und sich auf einem Felsen befindet, der von Wasser umgeben wird und wo die Sängerin Maria Callas sich gerne erholte.
<G-vec00524-002-s668><come_out.werden><en> All products in the Anal Fantasy range come with an anal pleasure preparation kit, including: 2 small finger sleeves, a desensitising anal cream, a lubricant especially designed for anal penetration as well as some sex toy cleaning fluid.
<G-vec00524-002-s668><come_out.werden><de> Jedes Produkt der „Anal Fantasy“ Modelle wird mit einem Sortiment zur Vorbereitung für das anale Vergnügen geliefert, einschließlich: 2 kleine Gummimanschetten für Finger, eine anale Desensibilisierungs-Creme, ein spezielles Gleitmittel für die anale Penetration und ein Sexspielzeugreiniger.
<G-vec00524-002-s669><come_out.werden><en> Most fitness trackers today come with a heart rate monitor built in.
<G-vec00524-002-s669><come_out.werden><de> Die Herzfrequenz wird bei beiden Fitness Trackern auch in gleicher Frequenz gemessen.
<G-vec00524-002-s670><come_out.werden><en> Should a significant deterioration in the Buyer’s financial circumstances occur or be expected to occur in future for objective reasons which does not come to our knowledge until after conclusion of the contract, we are entitled to demand cash pre-payments for future deliveries, or temporarily refuse delivery and invoice the goods on notification of readiness for shipment.
<G-vec00524-002-s670><come_out.werden><de> Für den Fall, dass in den Vermögensverhältnissen des Käufers eine wesentliche Verschlechterung eingetreten ist oder aufgrund objektiver Umstände für die Zukunft erwartet wird und wir hiervon erst nach dem Abschluss Kenntnis bekommen, können wir für weitere Lieferungen Vorauszahlungen in bar verlangen oder aber die Lieferungen einstweilen verweigern und die Ware bei Versandbereitschaft in Rechnung stellen.
<G-vec00524-002-s671><come_out.werden><en> Bass Drums are one of the most important parts of the drum kit, and come in various depths and diameters to produce different tones and pitches.
<G-vec00524-002-s671><come_out.werden><de> Die Bassdrum ist eines der wichtigsten Teile des Drum Kits und wird in verschiedenen Tiefen und Durchmessern produziert, sodass unterschiedliche Klänge und Tonhöhen entstehen.
<G-vec00524-002-s672><come_out.werden><en> Another reason is the tradition how they raise them animals, a way to come generations by generations.
<G-vec00524-002-s672><come_out.werden><de> Ein weiterer Grund ist die traditionelle Art der Tierzucht, die von Generation zu Generation weitergegeben wird.
<G-vec00524-002-s673><come_out.werden><en> It’s a holiday fantasy for parents of young football fans come true: a luxurious beach resort for them and a summer soccer camp for the kids.
<G-vec00524-002-s673><come_out.werden><de> Eine Urlaubsfantasie für Eltern von jungen Fußballfans wird wahr: ein luxuriöses Strandresort für sie und ein Fußball-Sommercamp für die Kids.
<G-vec00524-002-s674><come_out.werden><en> Binoculars come with a pouch, strap and optics cleaning cloth. The Scalpel
<G-vec00524-002-s674><come_out.werden><de> Das Fernglas wird mit einer Tasche, einem Riemen und einem Optikreinigungstuch geliefert.
<G-vec00524-002-s675><come_out.werden><en> Essential oils come from plants, while fragrance oils are usually artificially created and often contain synthetic chemicals.
<G-vec00524-002-s675><come_out.werden><de> Ersteres wird aus Pflanzen gewonnen, während Duftöle normalerweise künstlich hergestellt sind und häufig synthetische Chemikalien enthalten.
<G-vec00524-002-s676><come_out.werden><en> While Dean distracts Amara, Sam, Metatron and the Prophet Donatello Redfield come to Lucifer's rescue.
<G-vec00524-002-s676><come_out.werden><de> In Die Familie der Finsternis wird Luzifer von Amara durch ihre Macht gefoltert, aber er wird später von Sam, Metatron und Donatello Redfield gerettet.
<G-vec00524-002-s677><come_out.werden><en> The headphones come with a generous amount of accessories such as an extra pair of leatherette cushions and an airplane adapter.
<G-vec00524-002-s677><come_out.werden><de> Die Ausstattung wird mit dem üppigen Lieferumfang abgerundet, der ein zusätzliches Paar Velours-Ohrpolster und einen Flugzeug-Adapter beinhaltet.
<G-vec00524-002-s678><come_out.werden><en> Making the dream come true.
<G-vec00524-002-s678><come_out.werden><de> Damit der Traum wahr wird.
<G-vec00524-002-s679><come_out.werden><en> In the book of Galatians it happens to come under the brand name of circumcision and mosaic legalism.
<G-vec00524-002-s679><come_out.werden><de> Im Brief an die Galater wird das unter dem Namen „Beschneidung“ und „mosaischer Legalismus“ beschrieben.
<G-vec00524-002-s680><come_out.werden><en> The message that a continuation of the mission of Christianity would come can be found in Jesus’ predictions about the comforter, the holy spirit: "I have yet many things to say unto you, but ye cannot bear them now."
<G-vec00524-002-s680><come_out.werden><de> Die Botschaft, dass es eine Fortsetzung der Mission des Christentums geben wird, findet man in Jesu Voraussagen über den Sprecher, den Heiligen Geist: ”Ich habe euch noch Vieles zu sagen, aber ihr könnt es jetzt nicht tragen”.
<G-vec00524-002-s681><come_out.werden><en> The unique design and maximum functionality come together in a perfect symbiosis between the lines of the blade and the handle.
<G-vec00524-002-s681><come_out.werden><de> Die hochwertige Ausstrahlung des Natur-materials wird durch einen Mosaik-Pin in der Griff-mitte und die dekorative Endkappe aus Stahl zusätz-lich unterstrichen.
<G-vec00524-002-s682><come_out.werden><en> The new system is also significantly more energy-efficient and less labor-intensive than the previous lighting system, allowing it to inspire visitors for years to come.
<G-vec00524-002-s682><come_out.werden><de> Das neue System ist wesentlich energiesparender als das vorige und gleichzeitig auch weniger arbeitsintensiv – Eine Inspiration für jeden Besucher, die noch über Jahre hin faszinieren wird.
<G-vec00524-002-s683><come_out.werden><en> Moses said to Yahweh, ‘The people can’t come up to Mount Sinai, for you warned us, saying, “Set bounds around the mountain, and sanctify it.”’
<G-vec00524-002-s683><come_out.werden><de> 23 Und Mose sprach zu Jehova: Das Volk wird den Berg Sinai nicht ersteigen können; denn du hast uns ja gewarnt und gesagt: Mache eine Grenze um den Berg und heilige ihn.
<G-vec00097-002-s152><come_out.kommen><en> Then you have come to the right place.
<G-vec00097-002-s152><come_out.kommen><de> Dann sind Sie zum rechten Platz gekommen.
<G-vec00097-002-s153><come_out.kommen><en> You have come to the right page.
<G-vec00097-002-s153><come_out.kommen><de> Sie sind zur rechten Seite gekommen.
<G-vec00097-002-s154><come_out.kommen><en> "The hour is come that the Son of man should be glorified" (John 12:23).
<G-vec00097-002-s154><come_out.kommen><de> "Die Stunde ist gekommen, dass der Menschensohn verherrlicht werden sollte" (Johannes 12:23).
<G-vec00097-002-s155><come_out.kommen><en> The Spirit had come upon him powerfully, and he had broken down, weeping.
<G-vec00097-002-s155><come_out.kommen><de> Der Geist war mächtig auf ihn gekommen, und er war weinend zusammengebrochen.
<G-vec00097-002-s156><come_out.kommen><en> “For judgment I have come into this world, so that the blind will see and those who see will become blind.”
<G-vec00097-002-s156><come_out.kommen><de> 39Und Jesus sprach: Ich bin zum Gericht auf diese Welt gekommen, auf daß, die da nicht sehen, sehend werden, und die da sehen, blind werden.
<G-vec00097-002-s157><come_out.kommen><en> SHAKIR: Certainly a Messenger has come to you from among yourselves; grievous to him is your falling into distress, excessively solicitous respecting you; to the believers (he is) compassionate, 009.129
<G-vec00097-002-s157><come_out.kommen><de> Wahrlich, ein Gesandter ist zu euch gekommen aus eurer Mitte; schmerzlich ist es ihm, daß ihr in Unheil geraten solltet; eure Wohlfahrt begehrt er eifrig; gegen die Gläubigen ist er gütig, barmherzig.
<G-vec00097-002-s158><come_out.kommen><en> I twisted around and ran back the way I had come.
<G-vec00097-002-s158><come_out.kommen><de> Ich drehte mich weg und lief den Weg zurück, den wir gekommen waren.
<G-vec00097-002-s159><come_out.kommen><en> Make a photo of the defect and make photos that show how the product was installed and how it has come to the damage if possible.
<G-vec00097-002-s159><come_out.kommen><de> Fotografieren Sie den Defekt und versuchen Sie dabei, auf den Fotos deutlich zu machen, wie das Produkt eingebaut war und wie es zu dem Schaden gekommen ist.
<G-vec00097-002-s160><come_out.kommen><en> Gehazi answered, “Yes, but my master sent me to say, ‘Two young men who are members of a group of prophets have just now come to me from the hills of Ephraim.
<G-vec00097-002-s160><come_out.kommen><de> Mein Herr sendet mich und lässt sagen: Siehe, eben jetzt sind vom Gebirge Ephraim zwei junge Männer von den Söhnen der Propheten zu mir gekommen.
<G-vec00097-002-s161><come_out.kommen><en> 12 "But I tell you: Elijah has already come, and they didn't recognize him. On the contrary, they did whatever they pleased to him.
<G-vec00097-002-s161><come_out.kommen><de> 13 Aber ich sage euch, daß auch Elias gekommen ist, und sie haben ihm getan, was irgend sie wollten, so wie über ihn geschrieben steht.
<G-vec00097-002-s162><come_out.kommen><en> But I am sure I have always thought of Christmas-time, when it has come round—apart from the veneration due to its sacred name and origin, if anything belonging to it can be apart from that—as a good time; a kind, forgiving, charitable, pleasant time; the only time I know of, in the long calendar of the year, when men and women seem by one consent to open their shut-up hearts freely, and to think of people below them as if they really were fellow-passengers to the grave, and not another race of creatures bound on other journeys.
<G-vec00097-002-s162><come_out.kommen><de> Aber das weiß ich bestimmt, daß ich Weihnachten, wenn es gekommen ist, abgesehen von der Verehrung, die wir seinem heiligen Namen und Ursprung schuldig sind, immer als eine gute Zeit angeschaut habe, als eine liebe Zeit, als die Zeit der Vergebung und des Erbarmens, als die einzige Zeit, die ich im langen Kalenderjahr kenne, wo die Menschen einträchtig ihre verschlossenen Herzen auftun und die andern Menschen betrachten, als wenn sie wirklich Reisegenossen nach dem Grabe wären und nicht eine ganz andere Art von Lebewesen, die für einen ganz andern Weg vorgesehen sind.
<G-vec00097-002-s163><come_out.kommen><en> But I have also come to share with you the joys and hopes, efforts and commitments, ideals and aspirations of this diocesan community.
<G-vec00097-002-s163><come_out.kommen><de> Doch ich bin auch gekommen, um mit euch Freuden und Hoffnungen, Mühen und Anstrengungen, Ideale und Wünsche dieser Diözesangemeinschaft zu teilen.
<G-vec00097-002-s164><come_out.kommen><en> It’s a funny story that just goes to show how far both our businesses have come.
<G-vec00097-002-s164><come_out.kommen><de> Es ist eine lustige Geschichte, die zeigt, wie weit unsere beiden Unternehmen gekommen sind.
<G-vec00097-002-s165><come_out.kommen><en> 27She said to Him, Yes, Lord, I have believed [I do believe] that You are the Christ (the Messiah, the Anointed One), the Son of God, [even He] Who was to come into the world.
<G-vec00097-002-s165><come_out.kommen><de> 27Sie spricht zu ihm: HERR, ja, ich glaube, daß du bist Christus, der Sohn Gottes, der in die Welt gekommen ist.
<G-vec00097-002-s166><come_out.kommen><en> Acts 1, verse 8 and 9 “But you will receive power when the Holy Spirit has come upon you. You will be witnesses to me in Jerusalem, in all Judea and Samaria, and to the uttermost parts of the earth.”
<G-vec00097-002-s166><come_out.kommen><de> Apostelgeschichte 1, Vers 8 und 9 Aber ihr werdet Kraft empfangen, wenn der Heilige Geist auf euch gekommen ist; und ihr werdet meine Zeugen sein, sowohl in Jerusalem als auch in ganz Judäa und Samaria und bis an das Ende der Erde.
<G-vec00097-002-s167><come_out.kommen><en> 13Thou wilt rise up, thou wilt have mercy upon Zion: for it is the time to be gracious to her, for the set time is come. 14For thy servants take pleasure in her stones, and favour her dust.
<G-vec00097-002-s167><come_out.kommen><de> 13Du wirst aufstehen, wirst dich Zions erbarmen; denn es ist Zeit, es zu begnadigen, denn gekommen ist die bestimmte Zeit; 14Denn deine Knechte haben Gefallen an seinen Steinen und haben Mitleid mit seinem Schutt.
<G-vec00097-002-s168><come_out.kommen><en> And he said, No; but I have come as captain of the armies of the Lord.
<G-vec00097-002-s168><come_out.kommen><de> Er sprach: Nein, sondern ich bin ein Fürst über das Heer des HERRN und bin jetzt gekommen.
<G-vec00097-002-s169><come_out.kommen><en> 47 “If anyone hears my words but does not keep them, I do not judge that person. For I did not come to judge the world, but to save the world.
<G-vec00097-002-s169><come_out.kommen><de> 47 Und wenn jemand meine Worte hört und nicht glaubt, so richte ich ihn nicht; denn ich bin nicht gekommen, um die Welt zu richten, sondern damit ich die Welt rette.
<G-vec00097-002-s170><come_out.kommen><en> Today, mankind has once again come to the crossroads of the transformation of the transportation energy power system.
<G-vec00097-002-s170><come_out.kommen><de> Heute ist die Menschheit wieder an den Scheideweg der Transformation des Verkehrsenergiesystems gekommen.
<G-vec00097-002-s266><come_out.kommen><en> It was a feature of the UK implementation of the EMD that KYC measures did not come into play until a client had developed a material level of activity.
<G-vec00097-002-s266><come_out.kommen><de> Ein Merkmal der Umsetzung der EGR im Vereinigten Königreich bestand darin, dass das KYC-Prinzip erst zum Tragen kam, wenn ein Kunde beachtliche Aktivitäten entfaltete.
<G-vec00097-002-s267><come_out.kommen><en> I've come to understand the inner logic of the Tech. It is expressed in the Factors, the Axioms, and the Class VIII materials.
<G-vec00097-002-s267><come_out.kommen><de> Ich kam zum Verständnis der inneren Logik der Tech, die in den Faktoren, den Axiomen und den Class VIII Materialien ausgedrückt ist.
<G-vec00097-002-s268><come_out.kommen><en> No one has seen you come but you have come to stay.
<G-vec00097-002-s268><come_out.kommen><de> Niemand sah ihn kommen, aber er kam, um zu bleiben.
<G-vec00097-002-s269><come_out.kommen><en> Twice it has come with no tidings from abroad, but now finally with its return the knight and his servant ride back from Rome, bearing a papal ban against the widow who dared oppose the pious Bishop.
<G-vec00097-002-s269><come_out.kommen><de> Zweimal kam er, nun endlich ruft er den Rittern und Knechten ein Willkommen entgegen, die mit einem päpstlichen Briefe von Rom heimkehren, mit einem Bannbriefe über die Witwe, die den frommen Bischof zu beleidigen wagte.
<G-vec00097-002-s270><come_out.kommen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00097-002-s270><come_out.kommen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00097-002-s271><come_out.kommen><en> I was wearing a white gown but when reached where I was going, I come upon at least eight people sitting in chairs in half horseshoe shape.
<G-vec00097-002-s271><come_out.kommen><de> Ich trug ein weißes Gewand, aber als ich den Ort erreichte, zu dem ich hinstrebte, kam ich auf mindestens 8 Personen, die in Sesseln saßen, die hufeisenförmig aufgestellt waren.
<G-vec00097-002-s272><come_out.kommen><en> I'd come home off the road sometimes and find my wife crying.
<G-vec00097-002-s272><come_out.kommen><de> Ich kam einmal nach unserem Konzert nach Hause und fand meine Frau weinend zu Hause.
<G-vec00097-002-s273><come_out.kommen><en> Go, and you shall proceed, and come to the man of God to mount Carmel.
<G-vec00097-002-s273><come_out.kommen><de> 25 Also zog sie hin und kam zu dem Mann Gottes auf den Berg Karmel.
<G-vec00097-002-s274><come_out.kommen><en> The Term "summary" has come to us from the Latin language.
<G-vec00097-002-s274><come_out.kommen><de> Der Begriff "Zusammenfassung" kam zu uns aus der lateinischen Sprache.
<G-vec00097-002-s275><come_out.kommen><en> If Clara, who has been living in Jerusalem for years, remembers the joy of a year when she accompanied the person closest to her in the Basilica, her mother who had come to visit her, Elena waits for her parents and Sara remembers the joy of when she celebrated her Easter with his colleagues in a family atmosphere.
<G-vec00097-002-s275><come_out.kommen><de> Clara, die seit Jahren in Jerusalem wohnt, erinnert sich an die Freude des Jahres, als sie die Person, die ihr am meisten am Herzen liegt, nämlich ihre Mutter, die sie besuchen kam, in die Basilika begleitete, und so erwartet auch Elena ihre Eltern und Sara ist die Freude beim Feiern des Osterfestes mit ihren Kollegen in einer vertrauten Atmosphäre in Erinnerung geblieben.
<G-vec00097-002-s276><come_out.kommen><en> Despondent, we waited for someone from the team to come rescue us.
<G-vec00097-002-s276><come_out.kommen><de> Niedergeschlagen warteten wir darauf, dass jemand vom Team kam, um uns abzuholen.
<G-vec00097-002-s277><come_out.kommen><en> He did not realise where it had come from, though the servants who had drawn the water knew.
<G-vec00097-002-s277><come_out.kommen><de> Er wusste nicht, woher der Wein kam; die Diener aber, die das Wasser geschöpft hatten, wussten es.
<G-vec00097-002-s278><come_out.kommen><en> Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.
<G-vec00097-002-s278><come_out.kommen><de> Dennoch gewährte Ich diesen und ihren Vätern Versorgung in Fülle, bis die Wahrheit und ein offenkundiger Gesandter zu ihnen kam.
<G-vec00097-002-s279><come_out.kommen><en> They follow nothing but conjecture and what the souls desire!- Even though there has already come to them Guidance from their Lord!
<G-vec00097-002-s279><come_out.kommen><de> Sie folgen einem bloßen Wahn und dem Wunsche (ihres) Ichs, obwohl doch Weisung von ihrem Herrn zu ihnen kam.
<G-vec00097-002-s280><come_out.kommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec00097-002-s280><come_out.kommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec00097-002-s281><come_out.kommen><en> Dear children, I am your Mom and come from Heaven to lead you to My Lord.
<G-vec00097-002-s281><come_out.kommen><de> Ich bin eure Mutter und kam vom Himmel um euch zum Himmel zu fuehren.
<G-vec00097-002-s282><come_out.kommen><en> But because the Holy Spirit has come to dwell within us, and because of the promises in John 14, Jesus makes it very plain that Our Authentic Christian faith is not an esoteric religion, secret elite society, New Age or Buddhist doctrine.
<G-vec00097-002-s282><come_out.kommen><de> Aber weil der Heilige Geist kam, um in uns zu wohnen und aufgrund der Verheissungen in Johannes 14, macht es Jesus sehr deutlich, dass unser authentischer, christlicher Glaube keine esoterische Religion, keine geheime, elitäre Gesellschaft, kein New Age und keine buddhistische Lehre ist.
<G-vec00097-002-s283><come_out.kommen><en> But through their trespass salvation has come to the Gentiles, so as to make Israel jealous.
<G-vec00097-002-s283><come_out.kommen><de> Vielmehr kam durch ihr Versagen das Heil zu den Heiden, um sie selbst eifersüchtig zu machen.
<G-vec00097-002-s284><come_out.kommen><en> I saw her last one 16 months ago before I come to Germany.
<G-vec00097-002-s284><come_out.kommen><de> Ich habe sie zuletzt vor 16 Monaten gesehen, bevor ich nach Deutschland kam.
<G-vec00097-002-s304><come_out.kommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec00097-002-s304><come_out.kommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec00097-002-s305><come_out.kommen><en> All your wishes - come true here.
<G-vec00097-002-s305><come_out.kommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec00097-002-s306><come_out.kommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec00097-002-s306><come_out.kommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec00097-002-s307><come_out.kommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00097-002-s307><come_out.kommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00097-002-s308><come_out.kommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec00097-002-s308><come_out.kommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec00097-002-s309><come_out.kommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00097-002-s309><come_out.kommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00097-002-s310><come_out.kommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec00097-002-s310><come_out.kommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec00097-002-s311><come_out.kommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec00097-002-s311><come_out.kommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec00097-002-s312><come_out.kommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec00097-002-s312><come_out.kommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec00097-002-s313><come_out.kommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec00097-002-s313><come_out.kommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec00097-002-s314><come_out.kommen><en> Come wherever you are unknown.
<G-vec00097-002-s314><come_out.kommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec00097-002-s315><come_out.kommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec00097-002-s315><come_out.kommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec00097-002-s316><come_out.kommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec00097-002-s316><come_out.kommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec00097-002-s317><come_out.kommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec00097-002-s317><come_out.kommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec00097-002-s318><come_out.kommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec00097-002-s318><come_out.kommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec00097-002-s319><come_out.kommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec00097-002-s319><come_out.kommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec00097-002-s320><come_out.kommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec00097-002-s320><come_out.kommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec00097-002-s321><come_out.kommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec00097-002-s321><come_out.kommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec00097-002-s322><come_out.kommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec00097-002-s322><come_out.kommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec00097-002-s323><come_out.kommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec00097-002-s323><come_out.kommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec00097-002-s324><come_out.kommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00097-002-s324><come_out.kommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00097-002-s325><come_out.kommen><en> – English translation: I come from Britain.
<G-vec00097-002-s325><come_out.kommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec00097-002-s326><come_out.kommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00097-002-s326><come_out.kommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00097-002-s327><come_out.kommen><en> Will definitely come back if headed to this area again.
<G-vec00097-002-s327><come_out.kommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec00097-002-s328><come_out.kommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec00097-002-s328><come_out.kommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec00097-002-s329><come_out.kommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec00097-002-s329><come_out.kommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec00097-002-s330><come_out.kommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec00097-002-s330><come_out.kommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00097-002-s331><come_out.kommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec00097-002-s331><come_out.kommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00097-002-s332><come_out.kommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec00097-002-s332><come_out.kommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec00097-002-s333><come_out.kommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec00097-002-s333><come_out.kommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec00097-002-s334><come_out.kommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec00097-002-s334><come_out.kommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec00097-002-s335><come_out.kommen><en> I come from the picturesque city of brides, Sumy.
<G-vec00097-002-s335><come_out.kommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec00097-002-s336><come_out.kommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec00097-002-s336><come_out.kommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec00097-002-s337><come_out.kommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec00097-002-s337><come_out.kommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec00097-002-s338><come_out.kommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec00097-002-s338><come_out.kommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec00097-002-s339><come_out.kommen><en> And so I come to a second reflection.
<G-vec00097-002-s339><come_out.kommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec00097-002-s340><come_out.kommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec00097-002-s340><come_out.kommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec00097-002-s341><come_out.kommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec00097-002-s341><come_out.kommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec00097-002-s342><come_out.kommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec00097-002-s342><come_out.kommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec00097-002-s343><come_out.kommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec00097-002-s343><come_out.kommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec00097-002-s344><come_out.kommen><en> I love this country so it has been nice to be forced to come home.
<G-vec00097-002-s344><come_out.kommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec00097-002-s345><come_out.kommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec00097-002-s345><come_out.kommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec00097-002-s346><come_out.kommen><en> These now come from the cold stores.
<G-vec00097-002-s346><come_out.kommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec00097-002-s347><come_out.kommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec00097-002-s347><come_out.kommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec00097-002-s348><come_out.kommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec00097-002-s348><come_out.kommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec00097-002-s349><come_out.kommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec00097-002-s349><come_out.kommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec00097-002-s350><come_out.kommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec00097-002-s350><come_out.kommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec00097-002-s351><come_out.kommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec00097-002-s351><come_out.kommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec00097-002-s352><come_out.kommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec00097-002-s352><come_out.kommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec00097-002-s353><come_out.kommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00097-002-s353><come_out.kommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00097-002-s354><come_out.kommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec00097-002-s354><come_out.kommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec00097-002-s355><come_out.kommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec00097-002-s355><come_out.kommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec00097-002-s356><come_out.kommen><en> The artists come from Frohnau or other places.
<G-vec00097-002-s356><come_out.kommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec00097-002-s357><come_out.kommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec00097-002-s357><come_out.kommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec00097-002-s358><come_out.kommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec00097-002-s358><come_out.kommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec00097-002-s359><come_out.kommen><en> It looks like the babies all come in "twos" this spring.
<G-vec00097-002-s359><come_out.kommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec00097-002-s360><come_out.kommen><en> Come, see, hear, and marvel.
<G-vec00097-002-s360><come_out.kommen><de> Kommen, schauen, hören, staunen.
<G-vec00097-002-s361><come_out.kommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec00097-002-s361><come_out.kommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec00097-002-s362><come_out.kommen><en> Come to us, and you will not regret.
<G-vec00097-002-s362><come_out.kommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec00097-002-s363><come_out.kommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec00097-002-s363><come_out.kommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec00097-002-s364><come_out.kommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec00097-002-s364><come_out.kommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec00097-002-s365><come_out.kommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec00097-002-s365><come_out.kommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec00097-002-s366><come_out.kommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec00097-002-s366><come_out.kommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec00097-002-s367><come_out.kommen><en> Come and have a look or check our website.
<G-vec00097-002-s367><come_out.kommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec00097-002-s368><come_out.kommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec00097-002-s368><come_out.kommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec00097-002-s369><come_out.kommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec00097-002-s369><come_out.kommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec00097-002-s370><come_out.kommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec00097-002-s370><come_out.kommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec00097-002-s371><come_out.kommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec00097-002-s371><come_out.kommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec00097-002-s372><come_out.kommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec00097-002-s372><come_out.kommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec00097-002-s373><come_out.kommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec00097-002-s373><come_out.kommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec00097-002-s374><come_out.kommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec00097-002-s374><come_out.kommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec00097-002-s375><come_out.kommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec00097-002-s375><come_out.kommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec00097-002-s376><come_out.kommen><en> Come to Ulm – it will make a difference in your life.
<G-vec00097-002-s376><come_out.kommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec00097-002-s377><come_out.kommen><en> Just come, book it now and you will see for yourself.
<G-vec00097-002-s377><come_out.kommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec00097-002-s378><come_out.kommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec00097-002-s378><come_out.kommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec00097-002-s379><come_out.kommen><en> Here come easily in 4 steps to your desired server.
<G-vec00097-002-s379><come_out.kommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec00097-002-s399><come_out.kommen><en> Lights turn on when you come home.
<G-vec00097-002-s399><come_out.kommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec00097-002-s400><come_out.kommen><en> From there you will not come back.
<G-vec00097-002-s400><come_out.kommen><de> Von da kommst du nicht zurück.
<G-vec00097-002-s401><come_out.kommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec00097-002-s401><come_out.kommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec00097-002-s402><come_out.kommen><en> Will you come over and play for me.
<G-vec00097-002-s402><come_out.kommen><de> Kommst du rüber und spielst für mich.
<G-vec00097-002-s403><come_out.kommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec00097-002-s403><come_out.kommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec00097-002-s404><come_out.kommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec00097-002-s404><come_out.kommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec00097-002-s405><come_out.kommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec00097-002-s405><come_out.kommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec00097-002-s406><come_out.kommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec00097-002-s406><come_out.kommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec00097-002-s407><come_out.kommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec00097-002-s407><come_out.kommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec00097-002-s408><come_out.kommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec00097-002-s408><come_out.kommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00097-002-s409><come_out.kommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec00097-002-s409><come_out.kommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec00097-002-s410><come_out.kommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec00097-002-s410><come_out.kommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec00097-002-s411><come_out.kommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec00097-002-s411><come_out.kommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec00097-002-s412><come_out.kommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec00097-002-s412><come_out.kommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec00097-002-s413><come_out.kommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec00097-002-s413><come_out.kommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec00097-002-s414><come_out.kommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec00097-002-s414><come_out.kommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00097-002-s415><come_out.kommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec00097-002-s415><come_out.kommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec00097-002-s416><come_out.kommen><en> Moving forward is more like the platform you come from.
<G-vec00097-002-s416><come_out.kommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec00097-002-s417><come_out.kommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec00097-002-s417><come_out.kommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec00097-002-s418><come_out.kommen><en> The color must have come from cocoa powder.
<G-vec00097-002-s418><come_out.kommen><de> Die Farbe kommt von Kakaopulver.
<G-vec00097-002-s419><come_out.kommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec00097-002-s419><come_out.kommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec00097-002-s420><come_out.kommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec00097-002-s420><come_out.kommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec00097-002-s421><come_out.kommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec00097-002-s421><come_out.kommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec00097-002-s422><come_out.kommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec00097-002-s422><come_out.kommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec00097-002-s423><come_out.kommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec00097-002-s423><come_out.kommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec00097-002-s424><come_out.kommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec00097-002-s424><come_out.kommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec00097-002-s425><come_out.kommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00097-002-s425><come_out.kommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00097-002-s426><come_out.kommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec00097-002-s426><come_out.kommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec00097-002-s427><come_out.kommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec00097-002-s427><come_out.kommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec00097-002-s428><come_out.kommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec00097-002-s428><come_out.kommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec00097-002-s429><come_out.kommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec00097-002-s429><come_out.kommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec00097-002-s430><come_out.kommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec00097-002-s430><come_out.kommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec00097-002-s431><come_out.kommen><en> Come and see the place where the Lord was laid.
<G-vec00097-002-s431><come_out.kommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec00097-002-s432><come_out.kommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec00097-002-s432><come_out.kommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec00097-002-s433><come_out.kommen><en> Run up till you come to the snapping doors.
<G-vec00097-002-s433><come_out.kommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec00097-002-s434><come_out.kommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec00097-002-s434><come_out.kommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec00097-002-s435><come_out.kommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec00097-002-s435><come_out.kommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec00097-002-s436><come_out.kommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec00097-002-s436><come_out.kommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
