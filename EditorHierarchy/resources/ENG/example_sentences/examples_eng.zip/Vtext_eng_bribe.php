<G-vec01072-002-s011><bribe.bestechen><en> New action “Bribe Office Holder”: Bribe an office holder to gain political influence.
<G-vec01072-002-s011><bribe.bestechen><de> Neue Maßnahme „Amtsträger bestechen“: Bestecht einen Amtsträger und erhaltet politischen Einfluss.
<G-vec01072-002-s012><bribe.bestechen><en> Bribe siblings to go to the movies.
<G-vec01072-002-s012><bribe.bestechen><de> Besteche Geschwister, damit sie ins Kino gehen.
<G-vec01072-002-s013><bribe.bestechen><en> She had to change five cars and bribe her way through the military checkpoints up to the Lebanese border.
<G-vec01072-002-s013><bribe.bestechen><de> Sie hatte fünf Autos zu ändern und ihren Weg durch die militärischen Checkpoints an der libanesischen Grenze zu bestechen.
<G-vec01072-002-s014><bribe.bestechen><en> Since then, Jiang Zemin has used China's governmental system to bribe Russia with economic interests.
<G-vec01072-002-s014><bribe.bestechen><de> Seitdem hat Jiang Zemin Chinas Regierungssystem dazu benutzt, Russland mit ökonomischen Interessen zu bestechen.
<G-vec01072-002-s015><bribe.bestechen><en> Trump tries to bribe the German company working on the development of a possible vaccine and to win the vaccine only for America.
<G-vec01072-002-s015><bribe.bestechen><de> Trump versucht die deutsche Firma, die an der Entwicklung eines möglichen Impfstoffs arbeitet, zu bestechen und den Impfstoff nur für Amerika zu gewinnen.
<G-vec01072-002-s016><bribe.bestechen><en> Level 7: You can also bribe the guards on the way with a cigarette.
<G-vec01072-002-s016><bribe.bestechen><de> Level 7: Die Wachen am Weg kann man auch mit einer Zigarette bestechen.
<G-vec01072-002-s017><bribe.bestechen><en> The country has a single market on paper, with free circulation of goods and equal rates of customs and value added tax, yet corruption within public authorities is rife and businesses often have to bribe or obey politicians to be able to operate.
<G-vec01072-002-s017><bribe.bestechen><de> Das Land hat zwar offiziell einen Binnenmarkt, mit freiem Warenverkehr und gleichen Zoll- und Mehrwertsteuersätzen, doch ist die Korruption in den Behörden weit verbreitet und Geschäfte müssen häufig Politiker bestechen oder ihnen gehorchen, um arbeiten zu können.
<G-vec01072-002-s018><bribe.bestechen><en> Hans Jessen tried to bribe him with 100 Rigsdalers so that he could return to Holland, but that was not accepted.
<G-vec01072-002-s018><bribe.bestechen><de> Hans Jessen versuchte zwar, ihn mit 100 Reichstalern zu bestechen, in Holland anzulegen, das gelang ihm aber nicht.
<G-vec01072-002-s019><bribe.bestechen><en> They bribe them with money and they accept it.
<G-vec01072-002-s019><bribe.bestechen><de> Sie bestechen sie mit Geld und sie nehmen es an.
<G-vec01072-002-s020><bribe.bestechen><en> The dignitaries of church and state will unite to bribe, persuade, or compel all classes to honor the Sunday.
<G-vec01072-002-s020><bribe.bestechen><de> Die Würdenträger der Kirche und des Staates werden sich vereinigen, um alle Klassen von Menschen zu bestechen, zu überzeugen oder zu zwingen den Sonntag zu ehren.
<G-vec01072-002-s021><bribe.bestechen><en> In both cases, an intermediary in Denmark contacted players to bribe them in order to achieve a certain score.
<G-vec01072-002-s021><bribe.bestechen><de> Dabei soll über einen Mittelsmann in Dänemark Kontakt zu Spielern aufgenommen worden sein, um sie zu bestechen und damit ein bestimmtes Spielergebnis zu erzielen.
<G-vec01072-002-s022><bribe.bestechen><en> Studying business administration, Anna-Lena loves everything minimalistic, neat and structured and it is very easy to bribe her with chocolate and other sweets.
<G-vec01072-002-s022><bribe.bestechen><de> Die BWL-Studentin liebt es minimalistisch, ordentlich und strukturiert und ist mit Schokolade und anderen Süßigkeiten sehr leicht zu bestechen.
<G-vec01072-002-s023><bribe.bestechen><en> I also liked how they integrated it in the Ferengi culture with Nog trying to bribe Sisko. Destiny
<G-vec01072-002-s023><bribe.bestechen><de> Aber ich fand es auch gut, wie sie die Ferengi-Kultur integriert haben, in dem Nog versucht hat, Sisko zu bestechen.
<G-vec01072-002-s024><bribe.bestechen><en> A big scandal occurred after Monsanto succeeded to bribe/threaten the editor of the journal “Food and Chemical Toxicology” in 2013 to to delete a peer-reviewed article one year after publication.
<G-vec01072-002-s024><bribe.bestechen><de> Ein großes Skandal ereignete sich, nachdem es Monsanto gelang, den Editor der Zeitschrift “Food and Chemical Toxicology” im Jahr 2013 dazu zu bestechen/drohen, einen peer-reviewed Artikel ein Jahr nach der Veröffentlichung zu löschen.
<G-vec01072-002-s025><bribe.bestechen><en> Recently in the Kirov region in an attempt to bribe a large scale was detained by police.
<G-vec01072-002-s025><bribe.bestechen><de> Kürzlich im Gebiet Kirow in einem Versuch zu bestechen in großem Umfang von der Polizei festgenommen wurde.
<G-vec01072-002-s026><bribe.bestechen><en> They bribe the gaoler Schmidt, so that Maddalena can take the place of a condemned prisoner and see Chénier.
<G-vec01072-002-s026><bribe.bestechen><de> Sie bestechen den Gefängnisaufseher Schmidt, damit Maddalena zu Chénier ins Gefängnis gelangen und den Platz einer zum Tod verurteilten Gefangenen einnehmen kann.
<G-vec01072-002-s027><bribe.bestechen><en> The EU can bribe the national elites by appealing to their vanity and sense of importance, by elevating them from a national to an “international level” and by giving them nice cars and fancy jobs with power unrestrained by silly prosaic things such as the will of the people.
<G-vec01072-002-s027><bribe.bestechen><de> Die EU kann die nationalen Eliten bestechen, indem sie an deren Eitelkeit und Sinn für Wichtigkeit appelliert, indem sie sie von nationalem auf internationales Niveau hebt und indem sie ihnen schöne Autos und tolle Jobs gibt, mit von so verrückten einfachen Sachen wie dem Volkswillen unbegrenzter Macht.
<G-vec01072-002-s028><bribe.bestechen><en> She was taken to a private clinic on Anxi Road in Lanzhou to forcibly give her a transfusion, while Fang Zhiqiang went to the Second Forced Labour Camp in Lanzhou to try and bribe the guards into taking her.
<G-vec01072-002-s028><bribe.bestechen><de> Sie wurde in eine Privatklinik in der Anxi Straße in Lanzhou gebracht, wo man ihr gewaltsam eine Transfusion gab, während Fang Zhiqiang in das zweite Zwangsarbeitslager in Lanzhou ging, um zu versuchen und die Wärter zu bestechen, sie aufzunehmen.
<G-vec01072-002-s030><bribe.bestechen><en> The defender (the side who has made the passive INT DR) may try to bribe the enemy to avoid a battle.
<G-vec01072-002-s030><bribe.bestechen><de> Der Verteidiger (die Seite, welche den passiven INT DR durchgeführt hat) darf versuchen den Gegner zu bestechen, um somit ein Gefecht zu vermeiden.
<G-vec01072-002-s054><bribe.bestechen><en> The Rabbi told the guard to keep half and use the rest to bribe the other officials.
<G-vec01072-002-s054><bribe.bestechen><de> Der Rabbi forderte die Wache auf, die Hälfte zu behalten und die andere Hälfte des Bestechungsgeldes zu verwenden, um die anderen Beamten zu bestechen.
<G-vec01072-002-s060><bribe.bestechen><en> “Criminal entrepreneurs are quite prepared to plant people inside major organisations to blackmail or bribe employees,” says BT Security head Mark Hughes.
<G-vec01072-002-s060><bribe.bestechen><de> „Professionelle Kriminelle sind dazu bereit, Leute in großen Firmen einzuschleusen, um Mitarbeiter zu erpressen oder zu bestechen“, so Mark Hughes, Security-Leiter bei BT.
<G-vec01072-002-s062><bribe.bestechen><en> You need to bribe the guest post readers if you want to convert them into your subscribers.
<G-vec01072-002-s062><bribe.bestechen><de> Du musst die Leser des Gastbeitrags bestechen, wenn Du sie als Abonnenten gewinnen willst.
<G-vec01072-002-s078><bribe.bestechen><en> “As a result, we are now witnessing a phenomenon in which people are trying to bribe recruiters to join the military, not to evade the draft like it has been before,” she wrote.
<G-vec01072-002-s078><bribe.bestechen><de> "Dadurch beobachten wir jetzt ein Phänomen, bei dem die Leute versuchen, die Rekrutierter zu bestechen, um ins Militär zu kommen und nicht um der Einberufung zum Wehrdienst zu entgehen, wie es vorher war", schreibt sie weiter.
<G-vec01072-002-s090><bribe.bestechen><en> Even their attempts to bribe him were not successful.
<G-vec01072-002-s090><bribe.bestechen><de> Sie versuchten sogar, den Wächter zu bestechen.
<G-vec01072-002-s079><bribe.schmieren><en> If you are not playing alone, it might be sensible in some circumstances to “bribe” a fellow player with a high card so the soloist has as few points in his tricks as possible.
<G-vec01072-002-s079><bribe.schmieren><de> Spielst du nicht allein, kann es unter Umständen sinnvoll sein, deinem Mitspieler eine hohe Karte zu „schmieren“, sodass der Solist möglichst wenige Augen in seinen Stichen hat.
