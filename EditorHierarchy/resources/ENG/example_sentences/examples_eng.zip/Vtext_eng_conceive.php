<G-vec00402-002-s023><conceive.annehmen><en> If there is any possibility that this number is anything close to accurate, we have to conceive of a very large and extraordinary bureaucratic machine that handles the coordination and tracking of such a project.
<G-vec00402-002-s023><conceive.annehmen><de> Wenn es eine Möglichkeit gibt, dass diese Anzahl einigermaßen nahe an der Wahrheit liegt, dann müssten wir annehmen, dass es eine große und außergewöhnliche ‘bürokratische Maschine’ gibt, die die Koordination und Verwaltung von solch einem Projekt vornimmt.
<G-vec00402-002-s027><conceive.auffassen><en> Husserl's aim was to understand the production or constitution of meaning in the act of perception, i.e. to comprehend the processes that make us conceive an object in a certain way.
<G-vec00402-002-s027><conceive.auffassen><de> Husserls Ziel war es, die Sinngebung in der Wahrnehmung zu verstehen - also die bei der Wahrnehmung ablaufenden Prozesse zu durchschauen, die uns Gegenstände als so und so bestimmte aufzufassen veranlassen.
<G-vec00402-002-s026><conceive.aufnehmen><en> Only one of many types of thought processes within your minds can conceive of things in a linear manner.
<G-vec00402-002-s026><conceive.aufnehmen><de> Nur einer von vielen Typen von Gedankenprozessen in eurem Verstand kann Dinge in einer linearen Weise aufnehmen.
<G-vec00402-002-s029><conceive.ausdenken><en> Power greedy, so ego-maniacally hollow, they were willing to do anything at all their warped imaginations could conceive of to maintain their power and forestall the day of reckoning.
<G-vec00402-002-s029><conceive.ausdenken><de> Machtgierig, so egowahnsinnig hohl waren sie bereit, alles zu tun, was sie in ihren verworfenen Phantasien ausdenken konnten, um ihre Macht zu behalten und dem Tag der Abrechnung zuvor zu kommen.
<G-vec00402-002-s030><conceive.ausdenken><en> And yet, she had experienced more at this young age than a modern writer could possibly conceive of for a heroine in his book.
<G-vec00402-002-s030><conceive.ausdenken><de> Und doch hatte sie schon mehr erlebt, als sich irgendein moderner Autor für seine Romanheldin ausdenken könnte.
<G-vec00402-002-s031><conceive.ausdenken><en> Finally however there was no form that functioned really well, which means we always have to conceive of new forms.
<G-vec00402-002-s031><conceive.ausdenken><de> Letztlich funktioniert aber keine Form richtig gut, so dass wir uns immer wieder neue Formen ausdenken.
<G-vec00402-002-s052><conceive.begreifen><en> Many priests I have met and I meet in Medjugorje do not conceive their coming only as accompanying the pilgrims.
<G-vec00402-002-s052><conceive.begreifen><de> Eine Menge Priester, die ich getroffen habe und die ich noch immer in Meðugorje treffe, begreiffen ihr Kommen nicht nur als eine Begleitung der gläubigen Pilger.
<G-vec00402-002-s063><conceive.bekommen><en> There are many old wives’ tales that claim to help you conceive a baby boy.
<G-vec00402-002-s063><conceive.bekommen><de> Es gibt viele Ammenmärchen, die sagen, wie du einen Jungen bekommst.
<G-vec00402-002-s064><conceive.bestehen><en> No division of body and soul is envisaged, because Hebrew anthropology cannot conceive such a separation: the human being is not divided in this way, but is an animated body.
<G-vec00402-002-s064><conceive.bestehen><de> Es ist nicht an eine Trennung von Leib und Seele gedacht, weil nach der jüdischen Anthropologie der Mensch nicht aus Leib und Seele besteht, sondern ein beseelter Leib ist.
<G-vec00402-002-s065><conceive.betrachten><en> In addition, community water supply organisations conceive water as a social good with traditional, ancestral, and spiritual dimensions that guide its management and provision.
<G-vec00402-002-s065><conceive.betrachten><de> Kommunale Wasserversorger betrachten Wasser außerdem als ein soziales Gut mit traditionellen, historischen und spirituellen Dimensionen, die seine Bewirtschaftung und die Versorgung bestimmen.
<G-vec00402-002-s067><conceive.bringen><en> The next two years of trying to conceive, unfortunately, did not bring the desired results.
<G-vec00402-002-s067><conceive.bringen><de> Die nächsten zwei Jahre der Bemühungen brachten leider nicht die gewünschten Ergebnisse.
<G-vec00402-002-s083><conceive.denken><en> Your dating of the pyramids is completely erroneous; they are much, much, much older than what you could conceive.
<G-vec00402-002-s083><conceive.denken><de> Eure Datierung der Pyramiden von Ägypten ist total falsch, sie sind viel, viel, viel älter als Ihr es denken könnt.
<G-vec00402-002-s084><conceive.einbringen><en> We always check the costs and benefits of the ideas that we conceive and of the projects we develop.
<G-vec00402-002-s084><conceive.einbringen><de> Überprüfen wir immer die Kosten und Nutzen der Ideen, die wir einbringen, und des Projektes, das wir entwickeln.
<G-vec00402-002-s236><conceive.empfangen><en> 5:28 If the woman isn’t defiled, but is clean; then she shall be free, and shall conceive seed.
<G-vec00402-002-s236><conceive.empfangen><de> 5:28 Wenn aber das Weib sich nicht verunreinigt hat und rein ist, so wird sie unversehrt bleiben und Samen empfangen.
<G-vec00402-002-s109><conceive.entwerfen><en> In a newly founded studio, interior designers conceive bespoke solutions for our clients as well as future users and occupants.
<G-vec00402-002-s109><conceive.entwerfen><de> In einem neu gegründeten Atelier entwerfen Innenarchitekt/innen maßgeschneiderte Lösungen für unsere Bauherren, zukünftige Nutzer und Bewohner.
<G-vec00402-002-s110><conceive.entwickeln><en> We conceive and verify in practice any operating procedures, technologies, machines and equipments as used to accelerate, reduce price and improve a quality of sheet metalworking.
<G-vec00402-002-s110><conceive.entwickeln><de> In der Praxis entwickeln und prüfen wir die Vorgänge, Technologien, Maschinen und Anlagen nach, die zur Beschleunigung, Verbilligung und Verbesserung der Herstellung von dünnen Blechen bestimmt sind.
<G-vec00402-002-s111><conceive.entwickeln><en> We conceive and produce intelligent office furniture systems and interior fittings for B2B projects.
<G-vec00402-002-s111><conceive.entwickeln><de> Wir entwickeln und produzieren intelligente Büromöbelsysteme und Inneneinrichtungslösungen für den Geschäftskundenbereich.
<G-vec00402-002-s112><conceive.entwickeln><en> Guy ought to stay clear of taking Anavar if they are attempting to conceive a youngster as a decrease in the production of sperm is a common negative effects.
<G-vec00402-002-s112><conceive.entwickeln><de> Guy sollten die Einnahme von Anavar verhindern, wenn sie versuchen, ein Kind zu entwickeln, wie ein Rückgang der Produktion von Spermien ist eine übliche Nebenwirkung.
<G-vec00402-002-s113><conceive.entwickeln><en> We conceive and realise workshops, media projects and events throughout Europe.
<G-vec00402-002-s113><conceive.entwickeln><de> Wir entwickeln und realisieren Workshops, Mediaprojekte und Veranstaltungen.
<G-vec00402-002-s114><conceive.entwickeln><en> When the courses were first introduced in 2003 it was necessary to engage in many methodological considerations and to conceive of methodological concepts, which at that time had not been developed or documented elsewhere.
<G-vec00402-002-s114><conceive.entwickeln><de> Als die Kurse 2003 erstmals starteten, war es nötig, viele methodische Überlegungen anzustellen und methodische Konzepte zu entwickeln, die bis dahin nicht entwickelt oder dokumentiert waren.
<G-vec00402-002-s118><conceive.erahnen><en> Surely, we stand too near the colossal edifice His hand has reared to be able, at the present stage of the evolution of His Revelation, to claim to be able even to conceive the full measure of its promised glory.
<G-vec00402-002-s118><conceive.erahnen><de> Wir stehen dem gewaltigen Bauwerk, das Seine Hand errichtet hat, sicherlich zu nahe, um beim gegenwärtigen Stand der Entwicklung Seiner Offenbarung den Anspruch erheben zu dürfen, wir könnten das volle Maß seiner verheißenen Herrlichkeit auch nur erahnen.
<G-vec00402-002-s119><conceive.erdenken><en> The individual, beautiful garments for a dignified farewell – this basic idea led the fashion designer Afra Banach to newly conceive clothing for the deceased.
<G-vec00402-002-s119><conceive.erdenken><de> Das individuelle, schöne Gewand für ein würdevolles Abschiednehmen – diese Grundidee führt Modedesignerin Afra Banach dazu, Totenkleidung neu zu erdenken.
<G-vec00402-002-s120><conceive.erdenken><en> As architects of identity, we conceive and construct buildings, interiors and landscapes; we develop products and communication measures.
<G-vec00402-002-s120><conceive.erdenken><de> Als Architekten der Identität erdenken und erbauen wir Gebäude, Innenräume und Landschaften, entwickeln Produkte und Kommunikationsmaßnahmen.
<G-vec00402-002-s144><conceive.erfassen><en> We know we never can attain this representation: our weakness is too great. But at least we desire the ability to conceive an infinite intelligence for which this representation could be possible, a sort of great consciousness which should see all, and which should classify all in its time, as we classify, in our time, the little we see.
<G-vec00402-002-s144><conceive.erfassen><de> Wir wissen, daß wir dieses Bild niemals besitzen werden, dazu reichen unsere Kräfte nicht aus; aber wir möchten wenigstens einen unendlichen Geist erfassen können, dem diese Vorstellung möglich ist, eine Art großer Seele, die alles sieht und alles in ihre Zeit einordnet, so wie wir das Wenige, was wir sehen, in unsere Zeit einordnen.
<G-vec00402-002-s126><conceive.erfüllen><en> The New Apostolic Church supports a couple’s efforts to conceive a child through artificial insemination using the sperm of the husband.
<G-vec00402-002-s126><conceive.erfüllen><de> Die Neuapostolische Kirche unterstützt das Bemühen, durch künstliche Befruchtung mit dem Samen des Ehemannes den Kinderwunsch zu erfüllen.
<G-vec00402-002-s127><conceive.erhalten><en> What matters is that it is now possible to conceive of a scientific explanation of all creation.
<G-vec00402-002-s127><conceive.erhalten><de> Worauf es ankommt, ist, dass es jetzt möglich ist, eine wissenschaftliche Erklärung für die ganze Schöpfung zu erhalten.
<G-vec00402-002-s128><conceive.erhalten><en> It took five generations of this rigorous and selective breeding to conceive what is considered the first real Bubblegum to hit the markets of Holland.
<G-vec00402-002-s128><conceive.erhalten><de> Es dauerte fünf Generationen solch strenger und selektiver Zucht, um zu erhalten, was die erste wirkliche Bubblegum sein sollte, die in den Niederlanden auf den Markt kam.
<G-vec00402-002-s129><conceive.erschaffen><en> There has been all that you have been able to learn, to integrate and to conceive before the passage into the new cycle, before 2012.
<G-vec00402-002-s129><conceive.erschaffen><de> Es gab alles was Ihr lernen, integrieren, erschaffen konntet, vor dem Übergang in diesen neuen Zyklus, vor 2012.
<G-vec00402-002-s130><conceive.ersinnen><en> Those who conceive of or authorize any form of torture and other cruel, inhuman or degrading treatment, and those who commit such acts, should not go unpunished.
<G-vec00402-002-s130><conceive.ersinnen><de> Jene, die jegliche Form von Folter und anderer grausamer, unmenschlicher und erniedrigender Behandlung ersinnen oder erlauben und jene, die solche Akte ausführen, sollen nicht ungestraft davon kommen.
<G-vec00402-002-s131><conceive.ersinnen><en> That all men have inalienable rights to conceive, choose, assist or support their own organizations, churches and governments;
<G-vec00402-002-s131><conceive.ersinnen><de> Daß alle Menschen unveräußerliche Rechte haben, ihre eigenen Organisationen, Kirchen und Regierungen zu ersinnen, zu wählen, zu fördern und zu unterstützen.
<G-vec00402-002-s132><conceive.erstellen><en> Based on their wishes, we conceive a design that complies with all the applicable standards and requirements.
<G-vec00402-002-s132><conceive.erstellen><de> Aufgrund der Wünsche erstellen wir einen Entwurf, der allen Normen und Anforderungen entspricht.
<G-vec00402-002-s153><conceive.erzeugen><en> The hormones in the pills, once introduced into the organism, prevent ovulation, so the egg is absent and the woman cannot conceive as long as she continues the treatment.
<G-vec00402-002-s153><conceive.erzeugen><de> Sobald die Hormone in den Pillen in den Organismus eingeführt sind, verhindern sie den Eisprung, so dass das Ei fehlt und die Frau kein Kind erzeugen kann, solange sie die Behandlung fortsetzt.
<G-vec00402-002-s136><conceive.fassen><en> We can hardly yet conceive that we are free, again permitted to live, and that our native country is under the protection of the German Army.
<G-vec00402-002-s136><conceive.fassen><de> Wir können es noch kaum fassen, daß wir frei sind, daß wir wieder leben dürfen, daß unsere Heimat unter dem Schutze der deutschen Waffen steht.
<G-vec00402-002-s139><conceive.geben><en> We cannot conceive any other title for Mary other than “Mother.”
<G-vec00402-002-s139><conceive.geben><de> Man kann Maria keinen anderen Titel geben, der nicht „die Mutter” wäre.
<G-vec00402-002-s209><conceive.gebären><en> Isaiah 7:14 Therefore the Lord himself shall give you a sign; Behold, a virgin shall conceive, and bear a son, and shall call his name Immanuel.
<G-vec00402-002-s209><conceive.gebären><de> Jesaja 7:14 Darum so wird euch der HERR selbst ein Zeichen geben: Siehe, eine Jungfrau ist schwanger und wird einen Sohn gebären, den wird sie heißen Immanuel.
<G-vec00402-002-s137><conceive.gestalten><en> Conceive easily your offers according to your needs and options thanks to a flexible platform.
<G-vec00402-002-s137><conceive.gestalten><de> Flexibel Gestalten Sie Ihre Angebote ganz einfach nach Ihren Bedürfnissen dank einer flexiblen Plattform.
<G-vec00402-002-s147><conceive.glauben><en> Hence, I conceive, we must give up sterility, although undoubtedly in a lesser or greater degree of very frequent occurrence, as an unfailing mark by which species can be distinguished from races, i.e. from those forms which have descended from a common stock.
<G-vec00402-002-s147><conceive.glauben><de> Ich glaube deshalb, daß wir die Unfrucht- barkeit, obwohl diese zweifellos sehr häufig in größerem oder geringerem Grade auftritt, nicht als ein unfehlbares Merk- zeichen betrachten dürfen, durch das Spezies von Rassen, d. h. von solchen Formen, die aus einem gemeinsamen Stamme hervorgegangen sind, unterschieden werden können.
<G-vec00402-002-s231><conceive.hervorbringen><en> However, we conceive of this Forum essentially as a CONCRETE TOOL FOR ACTION.
<G-vec00402-002-s231><conceive.hervorbringen><de> Für uns soll dieses Forum aber vor allem ganz KONKRETE AKTIONEN hervorbringen.
<G-vec00402-002-s191><conceive.kommen><en> 38 And he put them in the troughs, where the water was poured out: that when the flocks should come to drink, they might have the rods before their eyes, and in the sight of them might conceive.
<G-vec00402-002-s191><conceive.kommen><de> 38und legte die Stäbe, die er geschält hatte, in die Tränkrinnen, wo die Herden hinkommen mussten zu trinken, dass sie da empfangen sollten, wenn sie zu trinken kämen.
<G-vec00402-002-s186><conceive.konzipieren><en> Founded in 2004, we conceive, design and develop efficient solutions for over 200 companies of all sizes and industries.
<G-vec00402-002-s186><conceive.konzipieren><de> 2004 gegründet, konzipieren, gestalten und entwickeln wir seitdem effiziente Lösungen für über 200 Unternehmen aller Größen und Branchen.
<G-vec00402-002-s190><conceive.kreieren><en> Use it to conceive your own multiplayer battlegrounds and campaigns, and share them with your friends.
<G-vec00402-002-s190><conceive.kreieren><de> Benutzt ihn, um eure eigenen Mehrspielerschlachtfelder und –kampagnen zu kreieren und teilt diese mit euren Freunden.
<G-vec00402-002-s232><conceive.sollen><en> However, he did not conceive his Gallery to be just an exhibition of art works, but also as a didactic tool: in fact, in 1620 he founded a Drawing Academy within the Ambrosian Art Gallery, for teaching painting, sculpture and architecture.
<G-vec00402-002-s232><conceive.sollen><de> Nach dem Willen Borromeos sollte sie jedoch nicht nur ein Kunstmuseum sein, sondern auch ausbilden, und daher rief er 1620 die Accademia del Disegno ins Leben, an der Malerei, Bildhauerei und Architektur gelehrt wurden.
<G-vec00402-002-s233><conceive.stellen><en> We usually conceive of human nutrition as “food intake” in terms of a unidirectional process from outside to inside.
<G-vec00402-002-s233><conceive.stellen><de> Gewöhnlich stellen wir uns die menschliche Ernährung im Sinne der „Nahrungsaufnahme“ als ein Geschehen vor, das von außen nach innen verläuft.
<G-vec00402-002-s243><conceive.verstehen><en> In this essay we question this statist response to the terrorist attacks and offer some vision of how the United States and other global actors might have and can still conceive of their possibilities for action under a cosmopolitan vision of political responsibility.
<G-vec00402-002-s243><conceive.verstehen><de> In diesem Aufsatz wollen wir die dadurch vorgegebene staatszentrierte Antwort auf die Terrorangriffe hinterfragen und eine Alternative vorschlagen, wie die USA und andere globale Akteure ihre Handlungsmöglichkeiten im Rahmen eines kosmopolitischen Begriffs politischer Verantwortung hätten verstehen können – und immer noch verstehen können.
<G-vec00402-002-s268><conceive.vorstellen><en> It is not something you can perceive, or even conceive in its fullness; but it is something you can intuit, something you can feel, hopefully something that finds some resonance within you when Mother Spirit and I say, you are indeed a very complex being, largely unknown to yourself simply because you are still so much pure potential, taking your first few hesitant steps into eternity.
<G-vec00402-002-s268><conceive.vorstellen><de> Es ist nicht etwas, das ihr wahrnehmen oder gar in seiner Vollständigkeit euch vorstellen könnt; aber es ist etwas, das ihr ahnen könnt, fühlen könnt, hoffentlich etwas, das etwas Resonanz in euch findet, wenn Muttergeist und ich sagen, ihr seid tatsächlich ein sehr komplexes Wesen, zum größten Teil euch selbst unbekannt, einfach weil ihr noch so sehr pures Potenzial seid, indem ihr eure ersten paar zögerlichen Schritte in die Ewigkeit macht.
<G-vec00402-002-s278><conceive.werden><en> 07/04 Share The Fédération Internationale de Football Association (FIFA) has commissioned Louis Vuitton to conceive the trunk case which carries the World Cup 2014 trophy all football players dream to hold.
<G-vec00402-002-s278><conceive.werden><de> Share Der Weltfußballverband (FIFA) beauftragte Louis Vuitton mit dem Entwurf eines Koffers, in dem die begehrteste Trophäe der Fußballwelt, der WM-Pokal 2014, transportiert werden soll.
<G-vec00402-002-s154><conceive.zeugen><en> Low sperm quality is a key factor behind the problems many couples experience when trying to conceive.
<G-vec00402-002-s154><conceive.zeugen><de> Schlechte Spermienqualität ist ein entscheidender Faktor für die Probleme, die viele Paare erleben, wenn sie versuchen Kinder zu zeugen.
<G-vec00493-002-s189><conceive.ausgestalten><en> Some people think there’s nothing simpler and set to work armed with good intentions. They employ a professional to conceive, validate and develop a design.
<G-vec00493-002-s189><conceive.ausgestalten><de> “Nichts leichter als das”, denkt sich manch einer und macht sich – mit guten Absichten bewaffnet – an die Arbeit: Ein Design wird von Profis konzipiert, validiert und ausgestaltet.
<G-vec00493-002-s032><conceive.beabsichtigen><en> Never did I conceive that all men should be alike.
<G-vec00493-002-s032><conceive.beabsichtigen><de> Ich beabsichtigte niemals, dass alle Menschen gleich sein sollen.
<G-vec00493-002-s102><conceive.eintippen><en> As soon as you get a positive pregnancy test, the first thing you probably want to do is type “conception calculator” or “When did I conceive?” into Google.
<G-vec00493-002-s102><conceive.eintippen><de> Sobald dein Schwangerschaftstest ein positives Ergebnis zeigt, ist deine erste Idee wahrscheinlich, etwas wie „Empfängnisrechner“ oder „Wann war meine Empfängnis?“ in Google einzutippen.
<G-vec00493-002-s229><conceive.eintreten><en> It is therefore possible today to pinpoint very precisely the causes of an inability to conceive and start the right treatment methods based on the results.
<G-vec00493-002-s229><conceive.eintreten><de> Daher ist es heute möglich, sehr genau zu bestimmen, warum keine Schwangerschaft eintritt, und auf Basis dieser Erwägungen die zielführendsten Behandlungsschritte einzuleiten.
<G-vec00493-002-s234><conceive.entwickeln><en> They take a very long time to conceive the thought of this stop motion music video.
<G-vec00493-002-s234><conceive.entwickeln><de> Sie brauchen sehr lange, um den Gedanken dieses Stop-Motion-Musikvideos zu entwickeln.
<G-vec00493-002-s248><conceive.erscheinen><en> Johan is so simple that it would be hard to conceive a simpler form.
<G-vec00493-002-s248><conceive.erscheinen><de> Couchtisch Johan ist so einfach, dass eine einfachere Form kaum vorstellbar erscheint.
<G-vec00493-002-s138><conceive.geben><en> But instead of indulging themselves in medieval romanticism their sole aim is to show which tradition is theirs and that they have enough imagination to conceive an appropriate motivational guide for their work.
<G-vec00493-002-s138><conceive.geben><de> Aber sie frönen da keiner Mittelalteromantik, sondern zeigen nur an, in welcher Tradition sie stehen möchten und daß sie auch über Phantasie verfügen, um sich und ihrer Arbeit einen Anhaltspunkt zur Motivation zu geben.
<G-vec00493-002-s160><conceive.knüpfen><en> Although most of the privileges resulting from the status of public body have already been determined by federal law, be it by provisions of the Constitution, be it by ordinary federal law, the Laender are free to conceive additional privileges that apply within their territory.
<G-vec00493-002-s160><conceive.knüpfen><de> Auch wenn das Gros der mit dem Körperschaftstatus verbundenen Privilegien bereits bundesrechtlich vorgesehen ist, sei es durch grundgesetzliche Vorgabe, sei es durch einfaches Bundesrecht, ist es den Ländern freigestellt, darüber hinausgehende landesspezifische Privilegien an den Status zu knüpfen.
<G-vec00493-002-s192><conceive.leben><en> Therefore, be at peace with God, whatever you conceive Him to be, and whatever your labors and aspirations, in the noisy confusion of life, keep peace with your soul.
<G-vec00493-002-s192><conceive.leben><de> Lebe deshalb in Frieden mit Gott, wen immer Du dafür hälst und lebe in Frieden mit Deiner Seele, was immer Dein Tun und Streben im lärmigen Durcheinander des Lebens sei.
<G-vec00493-002-s287><conceive.übersteigen><en> “The prospects that God has opened up to our view are wonderful and grand; the imagination cannot conceive of them.
<G-vec00493-002-s287><conceive.übersteigen><de> Die Aussichten, die Gott vor unserem Blick eröffnet hat, sind wunderbar und großartig; sie übersteigen jegliche Vorstellungskraft.
<G-vec00660-002-s057><conceive.bekommen><en> Therefore, if the wife has a rhesus conflict, and her husband does not, and you have decided to conceive a second child, such a vaccine is simply necessary.
<G-vec00660-002-s057><conceive.bekommen><de> Wenn also die Frau einen Rhesuskonflikt hat und ihr Ehemann dies nicht tut, und Sie beschlossen haben, ein zweites Kind zu bekommen, ist ein solcher Impfstoff einfach notwendig.
<G-vec00660-002-s058><conceive.bekommen><en> For example, delays can occur in women who are keen to quickly conceive a child.
<G-vec00660-002-s058><conceive.bekommen><de> Zum Beispiel können Verzögerungen bei Frauen auftreten, die daran interessiert sind, ein Kind schnell zu bekommen.
<G-vec00660-002-s059><conceive.bekommen><en> And gynecology advise sage to women who can not conceive a child for a long time.
<G-vec00660-002-s059><conceive.bekommen><de> Und die Gynäkologie berät Frauen, die lange kein Kind bekommen können.
<G-vec00660-002-s060><conceive.bekommen><en> It can be very painful to not be able to conceive children, especially when we do not know the reason.
<G-vec00660-002-s060><conceive.bekommen><de> Es kann sehr schmerzlich sein, keine Kinder bekommen zu können, besonders wenn man nicht weiß warum.
<G-vec00660-002-s061><conceive.bekommen><en> You will conceive and give birth to a son, and you will name him Jesus.
<G-vec00660-002-s061><conceive.bekommen><de> Du wirst einen Sohn bekommen und sollst ihn Jesus nennen.
<G-vec00660-002-s062><conceive.bekommen><en> If you want to conceive multiple children with the same genetic origin, we recommend purchasing the relevant amount of straws for other children you plan on having.
<G-vec00660-002-s062><conceive.bekommen><de> Wenn Sie mehrere Kinder mit dem gleichen genetischen Ursprung bekommen möchten, empfehlen wir Ihnen, die entsprechende Menge an Samenhalmen für die gewünschten Kinder zu erwerben.
<G-vec00660-002-s150><conceive.bekommen><en> If no causes that affect fertility are found, it is possible to control the body in such a way that it is possible to conceive.
<G-vec00660-002-s150><conceive.bekommen><de> Findet man Ursachen, die den Kinderwunsch verhindern, so kann man den Körper so gut wie möglich steuern, um ein Kind zu bekommen.
<G-vec00660-002-s151><conceive.emfpangen><en> Gabriel continues: “Behold you will conceive and bear a son and you will name him Jesus” (Lk 1:30-31).
<G-vec00660-002-s151><conceive.emfpangen><de> Du wirst ein Kind empfangen, einen Sohn wirst du gebären: dem sollst du den Namen Jesus geben.
<G-vec00660-002-s152><conceive.emfpangen><en> Biblical Text “The angel said to her, ‘…You are to conceive and bear a son, and you must name him Jesus’” (Luke 1:30-31).
<G-vec00660-002-s152><conceive.emfpangen><de> «Da sagte der Engel zu ihr:... Du wirst ein Kind empfangen, einen Sohn wirst du gebären: dem sollst du den Namen Jesus geben » (Lk 1, 30-31).
<G-vec00660-002-s087><conceive.empfangen><en> I conceive this land with all its beings totally within myself.
<G-vec00660-002-s087><conceive.empfangen><de> Ich empfange dieses Land mit all seinen Wesen ganz in mir selbst.
<G-vec00660-002-s088><conceive.empfangen><en> She had just heard that she was to conceive and bear a child, who would reign on the throne of David as the Son of the Most High.
<G-vec00660-002-s088><conceive.empfangen><de> Sie hatte gerade gehört, daß sie ein Kind empfangen und zur Welt bringen sollte, das als Sohn des Allerhöchsten auf dem Thron Davids herrschen würde.
<G-vec00660-002-s089><conceive.empfangen><en> Topping the list is the Church of the Annunciation, which is situated on the spot where Gabriel announced to Mary that she would conceive a child through the Holy Spirit.
<G-vec00660-002-s089><conceive.empfangen><de> Am wichtigsten ist hier die Verkündigungsbasilika, die an der Stelle steht, an der Gabriel Maria verkündete, dass sie ein Kind durch den Heiligen Geist empfangen würde.
<G-vec00660-002-s090><conceive.empfangen><en> Behold, I was brought forth in iniquity, and in sin did my mother conceive me.
<G-vec00660-002-s090><conceive.empfangen><de> Psalm 51, 7 Denn ich bin in Schuld geboren; in Sünde hat mich meine Mutter empfangen.
<G-vec00660-002-s091><conceive.empfangen><en> 5 Behold, in iniquity was I brought forth, and in sin did my mother conceive me.
<G-vec00660-002-s091><conceive.empfangen><de> 5 Siehe, ich bin in sündlichem Wesen geboren, und meine Mutter hat mich in Sünden empfangen.
<G-vec00660-002-s092><conceive.empfangen><en> Nature has laid a special life program in us - we must conceive, bear and give birth to offspring.
<G-vec00660-002-s092><conceive.empfangen><de> Die Natur hat ein besonderes Lebensprogramm in uns gelegt - wir müssen Nachwuchs empfangen, gebären und gebären.
<G-vec00660-002-s093><conceive.empfangen><en> It will be about products that are the "engine" of male and female fertility, i.e. the ability of the body to conceive.
<G-vec00660-002-s093><conceive.empfangen><de> Es wird um Produkte gehen, die der "Motor" der männlichen und weiblichen Fruchtbarkeit sind, d.h. die Fähigkeit des Körpers zu empfangen.
<G-vec00660-002-s094><conceive.empfangen><en> On this occasion, a sound wave which will conceive after reflexion in a border layer again is usually generated by means of ultrasonic converter.
<G-vec00660-002-s094><conceive.empfangen><de> Hierbei wird üblicherweise mittels Ultraschallwandler eine Schallwelle erzeugt, die nach Reflexion an einer Grenzschicht wieder empfangen wird.
<G-vec00660-002-s095><conceive.empfangen><en> There is a relationship between the ability to conceive a mother and her daughter.
<G-vec00660-002-s095><conceive.empfangen><de> Es besteht eine Beziehung zwischen der Fähigkeit, eine Mutter und ihre Tochter zu empfangen.
<G-vec00660-002-s096><conceive.empfangen><en> But Katya does not stop trying to conceive a baby...
<G-vec00660-002-s096><conceive.empfangen><de> Aber Katya hört nicht auf, ein Baby zu empfangen...
<G-vec00660-002-s098><conceive.empfangen><en> 38 And he put them in the troughs, where the water was poured out: that when the flocks should come to drink, they might have the rods before their eyes, and in the sight of them might conceive.
<G-vec00660-002-s098><conceive.empfangen><de> 38 und legte die Stäbe, die er geschält hatte, in die Tränkrinnen vor die Herden, die kommen mussten, zu trinken, daß sie da empfangen sollten, wenn sie zu trinken kämen.
<G-vec00660-002-s133><conceive.erzeugen><en> There is no need to turn the jars to conceive a vacuum.
<G-vec00660-002-s133><conceive.erzeugen><de> Es ist nicht nötig die Deckel umzudrehen um ein Vakuum zu erzeugen.
<G-vec00660-002-s097><conceive.gebären><en> “Therefore the Lord himself shall give you a sign. Behold a virgin shall conceive, and bear a son, and his name shall be called Emmanuel.”
<G-vec00660-002-s097><conceive.gebären><de> Mt 1:23 Siehe: Die Jungfrau wird empfangen und einen Sohn gebären und sie werden ihm den Namen Immanuel geben, das heißt übersetzt: Gott mit uns.
<G-vec00660-002-s140><conceive.gebären><en> Manganese is necessary for normal growth, maintenance of reproductive function (ability to conceive, bear and give birth to a child), metabolism of connective tissue (tissue that is more or less present in all organs and tissues, forming their basis), bone formation, fat metabolism and carbohydrates - all these processes are extremely important during pregnancy, when the formation of tissues and organs of the fetus.
<G-vec00660-002-s140><conceive.gebären><de> Mangan ist für das normale Wachstum, die Aufrechterhaltung der Fortpflanzungsfunktion (Fähigkeit, zu gebären, zu gebären und ein Kind zu gebären), den Stoffwechsel des Bindegewebes (mehr oder weniger in allen Organen und Geweben vorhandenes Gewebe), Knochenbildung, Fettstoffwechsel und Kohlenhydrate - alle diese Prozesse sind extrem wichtig während der Schwangerschaft, wenn die Bildung von Geweben und Organen des Fötus.
<G-vec00660-002-s141><conceive.gebären><en> OT Prophecy: Therefore the Lord Himself will give you a sign: Behold, the virgin (almah) shall conceive and bear a Son, and shall call His name Immanuel.
<G-vec00660-002-s141><conceive.gebären><de> AT Prophezeiung: Darum wird euch der Herr von sich aus ein Zeichen geben: Seht, die Jungfrau (almah) wird ein Kind empfangen, sie wird einen Sohn gebären und sie wird ihm den Namen Immanuel (Gott mit uns) geben.
<G-vec00660-002-s142><conceive.gebären><en> With polyps, medical curettage of the uterine cavity helps not only to avoid uterine bleeding that occurs due to his presence, but also to conceive a child.
<G-vec00660-002-s142><conceive.gebären><de> Bei Polypen hilft die medizinische Kürettage der Gebärmutterhöhle nicht nur, Gebärmutterblutungen zu vermeiden, die aufgrund seiner Anwesenheit auftreten, sondern auch ein Kind zu gebären.
<G-vec00660-002-s143><conceive.gebären><en> The child of God who tells a lie through his tongue is actually offering his tongue as a womb for Satan to conceive a lie.
<G-vec00660-002-s143><conceive.gebären><de> Das Kind Gottes, das mit seiner Zunge eine Lüge erzählt, bietet in Wirklichkeit Satan seine Zunge als Schoß an, eine Lüge zu gebären.
<G-vec00660-002-s167><conceive.konzipieren><en> For a longer time and in light of present crises, there has been no lack of calls for fundamental reformations of the economics and management theory, to conceive them anew as part of the social sciences and humanities.
<G-vec00660-002-s167><conceive.konzipieren><de> Seit längerem und im Licht gegenwärtiger Krisen hat es nicht an Rufen nach fundamentalen Reformen von Wirtschafts- und Management-Theorien gefehlt, um sie wieder neu als Teil der Geisteswissenschaften zu konzipieren.
<G-vec00660-002-s168><conceive.konzipieren><en> Faith and reason, unaided by mota, cannot conceive and construct a logical universe.
<G-vec00660-002-s168><conceive.konzipieren><de> Ohne Hilfe der Mota können Glaube und Verstand kein logisches Universum konzipieren und konstruieren.
<G-vec00660-002-s169><conceive.konzipieren><en> As the number-one strategy and management consultancy for the European financial world, we conceive tailor-made solutions, make them calculable and implement them with our innovative approach.
<G-vec00660-002-s169><conceive.konzipieren><de> Als Nummer 1 der Strategie- und Managementberatungen für die europäische Finanzwelt konzipieren wir maßgeschneiderte, innovative Lösungen mit unseren Kunden und setzen sie um.
<G-vec00660-002-s170><conceive.konzipieren><en> You may opt for one of these models or you can conceive your own personalised Gafsa tapestry.
<G-vec00660-002-s170><conceive.konzipieren><de> Sie können aus diesen Modellen wählen oder Ihren eigenen personalisierten Gafsa Wandteppich konzipieren.
<G-vec00660-002-s171><conceive.konzipieren><en> Our constant attention to recipe development, the crafting of new flavours and the quality of our ingredients, has enabled us to improve flavours and conceive new products to satisfy the most varied and complex tastes. Variety of products
<G-vec00660-002-s171><conceive.konzipieren><de> Da unser Augenmerk stets auf der Entwicklung von Rezepturen, der Schaffung neuer Geschmacksrichtungen und der Qualität unserer Zutaten liegt, konnten wir den Geschmack verfeinern und neue Produkte konzipieren, die den unterschiedlichsten und anspruchsvollsten Geschmäckern gerecht werden.
<G-vec00660-002-s172><conceive.konzipieren><en> In contrast, Sociology of Emotion introduces the concept of interaction, which makes it possible to conceive of entirely new and impersonal emotions, emotions that emanate from interhuman encounters.
<G-vec00660-002-s172><conceive.konzipieren><de> Dem gegenüber bringt die Soziologie der Emotionen die Denkfigur der Interaktion in Anschlag, die es möglich macht ganz neue unpersönliche Emotionen zu konzipieren, Emotionen, die aus zwischenmenschlichen Begegnungen erst hervorgehen.
<G-vec00660-002-s173><conceive.konzipieren><en> While Charles Avery, Paolo Chiasera and Martin Pohl use painting to conceive new exhibitions (or have them curated by someone else) that only take place on the delicate mechanisms and relations between the artist and their audience. more...
<G-vec00660-002-s173><conceive.konzipieren><de> Während Charles Avery, Paolo Chiasera und Martin Pohl Ausstellungen konzipieren, die ausschließlich auf der Leinwand “stattfinden”, untersuchen Dorothy Miller, Lea von Wintzingerode und Amelie von Wulffen in ihren Arbeiten die sensiblen Mechanismen und Beziehungen zwischen dem Künstler und seinem Publikum.
<G-vec00660-002-s174><conceive.konzipieren><en> Rather than conceive an exhibition project that smoothes over differences, and, like pork soup, blends the inherent tensions between aesthetic and critical concepts in a melting pot of indistinguishable parts, between social diversity and cultural differences; or between national and secular identities on the one hand, and ethnic and religious identifications on the other; or between civic rights of indigenes and human rights of aliens.
<G-vec00660-002-s174><conceive.konzipieren><de> Statt ein Ausstellungsprojekt zu konzipieren, das die Differenzen einebnet und, wie die Schweinesuppe, die inhärenten Spannungen zwischen ästhetischen und kritischen Konzepten in einem Schmelztiegel aus ununterscheidbaren Bestandteilen vermischt, zwischen sozialer Vielfalt und kulturellen Unterschieden; oder zwischen nationalen und säkularen Iden-titäten einerseits, ethnischen und religiösen Identifikationen andererseits; oder zwischen den Bürgerrechten der Einheimischen und den Menschenrechten der Ausländer_innen.
<G-vec00660-002-s175><conceive.konzipieren><en> At littera, we conceive, write and edit the content of your site.
<G-vec00660-002-s175><conceive.konzipieren><de> Bei littera konzipieren, schreiben und editieren wir den Inhalt Ihrer Website.
<G-vec00660-002-s176><conceive.konzipieren><en> Their comprehension of political rule, the way they perceive and authenticate ‘truth’ and an understanding of what appeals to their constituency are the main dimensions of my analysis on how these movements conceive and affect the democratic order
<G-vec00660-002-s176><conceive.konzipieren><de> Ihr Verständnis von politischer Herrschaft, die Art und Weise, wie sie „Wahrheit" authentifizieren, und eine Erarbeitung dessen, was ihre Unterstützer anspricht, sind die wichtigsten Dimensionen meiner Analyse darüber, wie diese Bewegungen die demokratische Ordnung konzipieren und beeinflussen.
<G-vec00660-002-s177><conceive.konzipieren><en> Everything from one source – 160 employees in Germany, China and Spain conceive, design and produce tools and devices based on the latest research.
<G-vec00660-002-s177><conceive.konzipieren><de> Alles aus einer Hand - Mehr als 160 Mitarbeiter in Deutschland, China und Spanien konzipieren, konstruieren und fertigen Werkzeuge und Vorrichtungen nach neuesten Erkenntnissen.
<G-vec00660-002-s178><conceive.konzipieren><en> It is the task of EnSoC to conceive and implement research projects at own facilities or in cooperation with other institutions, to bring together research and practice, to disseminate scientific results by publications and events, and to promote scientific education and advanced training.
<G-vec00660-002-s178><conceive.konzipieren><de> Aufgaben des EnSoC sind, in eigenen Einrichtungen oder in Kooperation mit weiteren Institutionen Forschungsvorhaben zu konzipieren und zu realisieren, Forschung und Praxis zusammenzuführen, wissenschaftliche Erkenntnisse durch Veröffentlichungen und Veranstaltungen zu verbreiten sowie die wissenschaftliche Aus- und Weiterbildung zu fördern.
<G-vec00660-002-s179><conceive.konzipieren><en> We do not conceive primarily for the idea but for the target group.
<G-vec00660-002-s179><conceive.konzipieren><de> Wir konzipieren nicht primär für die Idee, sondern für die Zielgruppe.
<G-vec00660-002-s180><conceive.konzipieren><en> Services Responsive web design As a digital agency we conceive and design high-quality websites and web apps that are perfectly tailored to the needs and expectations of users as well your company’s goals.
<G-vec00660-002-s180><conceive.konzipieren><de> Als Digitalagentur konzipieren und gestalten wir hochwertige Websites und Web-Apps, die optimal auf die Bedürfnisse und Erwartungen ihrer Nutzer sowie die Ziele Ihres Unternehmens zugeschnitten sind.
<G-vec00660-002-s181><conceive.konzipieren><en> The New Year is a new beginning in every one of our lives and a great opportunity to conceive and form bold, forward-thinking ideas, explore new paths and discover profitable opportunities.
<G-vec00660-002-s181><conceive.konzipieren><de> Das neue Jahr ist ein Neubeginn in jedem unserer Leben und eine große Chance, mutige, zukunftsweisende Ideen zu konzipieren und zu gestalten, neue Wege zu gehen und profitable Möglichkeiten zu entdecken.
<G-vec00660-002-s182><conceive.konzipieren><en> We quickly identify possible fault sources and then conceive individually optimised solutions for each client.
<G-vec00660-002-s182><conceive.konzipieren><de> Rasch identifizieren wir mögliche Fehlerquellen und konzipieren anschließend individuell optimale Lösungen für den jeweiligen Kunden.
<G-vec00660-002-s183><conceive.konzipieren><en> They want to start experiments to conceive interceptor missions and give politics a kind of emergency plan.
<G-vec00660-002-s183><conceive.konzipieren><de> Sie wollen Experimente starten, Abfang-Missionen konzipieren und der Politik eine Art Notfallplan an die Hand geben.
<G-vec00660-002-s184><conceive.konzipieren><en> We work with you to conceive and revise new viable business models and services.
<G-vec00660-002-s184><conceive.konzipieren><de> Wir konzipieren und überarbeiten mit Ihnen innovative und tragfähige Geschäftsmodelle und Dienstleistungen.
<G-vec00660-002-s185><conceive.konzipieren><en> Alternatively, we conceive and realise tailor-made new rental locations.
<G-vec00660-002-s185><conceive.konzipieren><de> Alternativ konzipieren und realisieren wir maßgeschneiderte neue Standorte zur Miete.
<G-vec00660-002-s210><conceive.werden><en> To make sure you don't miss your shot, start trying to conceive a few days before you think you might ovulate.
<G-vec00660-002-s210><conceive.werden><de> Um sicher zu gehen, dass du deine Chance nicht verpasst, beginne ein paar Tage vor dem erwarteten Eisprung mit den Versuchen schwanger zu werden.
<G-vec00660-002-s211><conceive.werden><en> If you are currently trying to conceive, please consult your doctor before using the lubricant.
<G-vec00660-002-s211><conceive.werden><de> Sollten Sie gerade versuchen schwanger zu werden, wenden Sie sich bitte vor der Verwendung des Gleitmittels an Ihren Arzt.
<G-vec00660-002-s212><conceive.werden><en> In these cases, it may be difficult to conceive naturally, as the egg either destroys the fallopian tube or is not captured by the fallopian tube and therefore disappears into the abdominal cavity.
<G-vec00660-002-s212><conceive.werden><de> Wenn dies der Fall ist, kann es schwierig sein, auf natürlichem Wege schwanger zu werden, da die Eizelle entweder im Eileiter abstirbt oder nicht vom Eileiter aufgefangen wird und in die Bauchhöhle geht.
<G-vec00660-002-s213><conceive.werden><en> Thanks to the new technique, it is possible to conceive quickly because there is no need to synchronise the menstrual cycles of the egg donor and the recipient.
<G-vec00660-002-s213><conceive.werden><de> Dank des neuen Verfahrens kann man schneller schwanger werden, ohne hormonelle Synchronisierung der Monatsperiode von Empfängerin und Spenderin der Eizelle.
<G-vec00660-002-s214><conceive.werden><en> But he said unto me, Behold, thou shalt conceive, and bear a son;
<G-vec00660-002-s214><conceive.werden><de> Er sprach aber zu mir: Siehe, du wirst schwanger werden und einen Sohn gebären.
<G-vec00660-002-s215><conceive.werden><en> If you have a medical condition (especially kidney stones or dysfunction, hyperparathyroidism, hypercalcemia, lymphoma, or sarcoidosis), are pregnant, lactating, trying to conceive, under the age of 18, or taking medications, consult your healthcare professional before using this product.
<G-vec00660-002-s215><conceive.werden><de> Fragen Sie vor Einnahme des Produktes Ihren Arzt, falls Sie an einer Sarkoidose, oder falls Sie schwanger sind, stillen, versuchen, schwanger zu werden, unter 18 Jahre alt sind oder Medikamente einnehmen.
<G-vec00660-002-s216><conceive.werden><en> Few women plan to immediately conceive after birth.
<G-vec00660-002-s216><conceive.werden><de> Wenige Frauen planen, sofort nach der Geburt schwanger zu werden.
<G-vec00660-002-s217><conceive.werden><en> 3Then the angel of the Lord appeared to the woman and said to her, "Behold now, you are barren and have borne no children, but you shall conceive and give birth to a son.
<G-vec00660-002-s217><conceive.werden><de> 3Und der Engel Jehovas erschien dem Weibe und sprach zu ihr: Siehe doch, du bist unfruchtbar und gebierst nicht; aber du wirst schwanger werden und einen Sohn gebären.
<G-vec00660-002-s218><conceive.werden><en> Obese women can still conceive with a smooth pregnancy and give birth to a healthy baby.
<G-vec00660-002-s218><conceive.werden><de> Übergewichtige Frauen können immer noch mit einer glatten Schwangerschaft schwanger werden und die Geburt eines gesunden Babys geben.
<G-vec00660-002-s219><conceive.werden><en> Because of this intermittent temporary return of ovarian function, approximately 5-10% of women with POI may still conceive.
<G-vec00660-002-s219><conceive.werden><de> Aufgrund dieser zeitweilig wiederhergestellten Funktion der Eierstöcke, können 5-10 % der Frauen mit POI auf natürlichem Weg schwanger werden.
<G-vec00660-002-s220><conceive.werden><en> 7But he said to me, 'Behold, you shall conceive and give birth to a son, and now you shall not drink wine or strong drink nor eat any unclean thing, for the boy shall be a Nazirite to God from the womb to the day of his death.'"
<G-vec00660-002-s220><conceive.werden><de> 7Und er sprach zu mir: Siehe, du wirst schwanger werden und einen Sohn gebären; und nun, trinke weder Wein noch starkes Getränk, und iß nichts Unreines; denn ein Nasir Gottes soll der Knabe sein von Mutterleibe an bis zum Tage seines Todes.
<G-vec00660-002-s221><conceive.werden><en> Again, it all comes back to the fertile window and those 6 days that you can conceive each cycle.
<G-vec00660-002-s221><conceive.werden><de> Wieder kommt alles auf das fruchtbare Fenster und jene 6 Tage zurück, in denen du in jedem Zyklus schwanger werden kannst.
<G-vec00660-002-s222><conceive.werden><en> Above you could find out if you can conceive after ovulation.
<G-vec00660-002-s222><conceive.werden><de> Oben können Sie herausfinden, ob Sie nach dem Eisprung schwanger werden können.
<G-vec00660-002-s223><conceive.werden><en> It was written that a virgin would conceive and in her womb the Word would take on Flesh.
<G-vec00660-002-s223><conceive.werden><de> Es stand geschrieben, dass eine Jungfrau schwanger würde, und dass in ihrem Schosse "Das Wort" Fleisch werden würde.
<G-vec00660-002-s225><conceive.werden><en> Our findings also showed that many healthcare providers also may not be doing enough to support women following a miscarriage, even in providing accurate guidance about how long to wait before trying to conceive again.
<G-vec00660-002-s225><conceive.werden><de> Unsere Umfrageergebnisse zeigten auch, dass viele Mediziner vielleicht nicht genug tun, um Frauen nach einer Fehlgeburt zu unterstützen, und sei es auch nur dadurch, dass sie die richtigen Anweisungen geben, wie lange die Frau warten sollte, bis sie wieder versucht, schwanger zu werden.
<G-vec00660-002-s226><conceive.werden><en> The main thing is to be able to conceive.
<G-vec00660-002-s226><conceive.werden><de> Hauptsache, man kann schwanger werden.
<G-vec00660-002-s227><conceive.werden><en> 3 And the angel of YHVH appeared unto the woman, and said unto her, Behold now, thou art barren, and bearest not: but thou shalt conceive, and bear a son.
<G-vec00660-002-s227><conceive.werden><de> 3 Und der Engel des HERRN erschien dem Weibe und sprach zu ihr:Siehe, du bist unfruchtbar und gebierst nicht; aber du wirst schwanger werden und einen Sohn gebären.
<G-vec00660-002-s228><conceive.werden><en> In order for a woman to conceive as soon as possible, it was fumigated with special incenses.
<G-vec00660-002-s228><conceive.werden><de> Damit eine Frau so schnell wie möglich schwanger werden konnte, wurde sie mit speziellen Räuchern begast.
<G-vec00660-002-s280><conceive.zeugen><en> At the same time, some couples unsuccessfully may try to conceive a child for years.
<G-vec00660-002-s280><conceive.zeugen><de> Zur gleichen Zeit versuchen einige Paare erfolglos, ein Kind jahrelang zu zeugen.
<G-vec00660-002-s281><conceive.zeugen><en> It is not difficult to guess how these changes can affect the quality of the spermatozoa formed and the ability of the smoker to conceive a healthy child.
<G-vec00660-002-s281><conceive.zeugen><de> Es ist nicht schwer zu erraten, wie diese Veränderungen die Qualität der Spermatozoen und die Fähigkeit des Rauchers beeinflussen können, ein gesundes Kind zu zeugen.
<G-vec00660-002-s282><conceive.zeugen><en> Male germ cells (sperm) can be cryopreserved (frozen) before chemotherapy or radiotherapy and, in the case of a loss of function of a male patient’s gonads (testes), are used to conceive his own child.
<G-vec00660-002-s282><conceive.zeugen><de> Männliche Keimzellen (Spermien) können vor einer Chemo- oder Strahlentherapie kryokonserviert (eingefroren) werden und im Fall eines Funktionsverlustes der männlichen Keimdrüsen (Hoden) verwendet werden, um ein eigenes Kind zu zeugen.
<G-vec00660-002-s283><conceive.zeugen><en> Astroglide TTC is a lubricant that favours sperm motility, a key factor for couples who want to conceive.
<G-vec00660-002-s283><conceive.zeugen><de> Astroglide TTC ist ein Gleitmittel, das zur Beweglichkeit der Spermien beiträgt, dem wesentlichen Element für Paare, die ein Kind zeugen möchten.
<G-vec00660-002-s284><conceive.zeugen><en> Apollo approaches her to conceive with her Rome’s ruler to be, in the presence of his sister Artemis.
<G-vec00660-002-s284><conceive.zeugen><de> Apollo nähere sich, um mit ihr den künftigen Herrscher Roms zu zeugen, während seine Schwester Artemis der Szene beiwohne.
