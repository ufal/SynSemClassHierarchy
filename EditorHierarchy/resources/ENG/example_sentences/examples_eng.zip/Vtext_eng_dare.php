<G-vec01061-002-s048><dare.sich_trauen><en> However, if you dare to stray from their all-encompassing yet well-designed pizza list, you can expect a range of great Italian classic dishes as well as Cologne’s traditional dishes.
<G-vec01061-002-s048><dare.sich_trauen><de> Wenn du dich traust, die umfassende Pizza-Karte beiseite zu legen, erwarten dich neben den klassischen italienischen Gerichten, auch lokale kölsche Traditionsgerichte.
<G-vec01061-002-s049><dare.sich_trauen><en> Play him anything before just because you do not dare to talk to him, if he notices it, it is even worse for him and you will soon not want him, if you never have anything from sex.
<G-vec01061-002-s049><dare.sich_trauen><de> Spiele ihm nichts vor, nur weil Du Dich nicht traust mit ihm zu reden, wenn er es merkt, ist es für ihn noch schlimmer und Du wirst ihn bald nicht mehr wollen, wenn Du nie etwas vom Sex hast.
<G-vec01061-002-s050><dare.sich_trauen><en> Try the looping water-slide, The Scorpion's Tail, if you dare.
<G-vec01061-002-s050><dare.sich_trauen><de> Probieren Sie die Looping Wasserrutsche, The Scorpion Tail, wenn du dich traust.
<G-vec01061-002-s108><dare.sich_trauen><en> But when everything was over and the perpetrators had fled, the police "dare" to appear.
<G-vec01061-002-s108><dare.sich_trauen><de> Erst als alles vorbei war und die Täter die Flucht ergriffen hatten, hat sich die Polizei „getraut“ zu erscheinen.
<G-vec01061-002-s109><dare.sich_trauen><en> But I did not dare to follow their example immediately.
<G-vec01061-002-s109><dare.sich_trauen><de> Das habe ich mich aber nicht gleich getraut.
<G-vec01061-002-s110><dare.sich_trauen><en> The location is breathtaking – in more than one sense: atop a cliff where there’s always strong winds and on this day it felt like a force 9 blowing on the Beaufort scale (if I may quote Billy Joel) – so I didn’t dare go too close to the edge.
<G-vec01061-002-s110><dare.sich_trauen><de> Die Lage ist atemberaubend, an einer Steilküste, wo immer ordentlich Wind geht – an diesem Tag eher Orkanstärke, so dass ich mich wirklich nicht an den Rand getraut habe.
<G-vec01061-002-s111><dare.sich_trauen><en> His flatmates and friends had already been worried about his absence during the evening but didn’t dare to leave the house to search for him due to the ongoing Pegida demonstration.
<G-vec01061-002-s111><dare.sich_trauen><de> Seine Mitbewohner_innen und Freund_innen hatten sich bereits am Abend Sorgen gemacht, sie hatten sich aber aufgrund der laufenden Pegida-Demonstration nicht aus dem Haus getraut, um nach ihrem Freund zu suchen.
<G-vec01061-002-s112><dare.sich_trauen><en> Afterwards I didn't dare mention this event to others for fear that they would not believe me.
<G-vec01061-002-s112><dare.sich_trauen><de> Ich habe mich hinterher gar nicht getraut, diesen Vorfall anderen gegenüber zu erwähnen, aus Furcht, sie würden mir das nicht glauben.
<G-vec01061-002-s113><dare.sich_trauen><en> We did not want to go on Berlin beta, therefore we felt obligated to go on AR the Electronica and easily did not dare to say to them they would be just as bloed and we also, because we would have come.
<G-vec01061-002-s113><dare.sich_trauen><de> Wir wollten naemlich nicht auf die Berlin Beta gehen, deshalb fuehlten wir uns verpflichtet, auf die Ars Electronica zu gehen, und haben uns einfach nicht getraut, ihnen zu sagen, sie waeren genauso bloed und wir auch, weil wir gekommen waeren.
<G-vec01061-002-s114><dare.sich_trauen><en> After I did not dare to learn to surf in Bali, I had overcome myself and completed a one-week surf course.
<G-vec01061-002-s114><dare.sich_trauen><de> Nachdem ich mich auf Bali nicht getraut hatte, surfen zu lernen, habe ich mich überwunden und einen einwöchigen Surfkurs absolviert.
<G-vec01061-002-s115><dare.sich_trauen><en> Preamble: I wanted to write this article at the end of June but I didn't dare.
<G-vec01061-002-s115><dare.sich_trauen><de> Diesen Artikel wollte ich noch Ende Juni schreiben, aber ich habe mich nicht getraut.
<G-vec01061-002-s163><dare.sich_trauen><en> But you know, only if you dare...
<G-vec01061-002-s163><dare.sich_trauen><de> Aber wissen Sie, nur wenn Sie sich trauen...
<G-vec01061-002-s164><dare.sich_trauen><en> The main thing - before you dare to apply a tattoo, you should pay special attention to the ways of caring for a new ornament to the ankle.
<G-vec01061-002-s164><dare.sich_trauen><de> Die Hauptsache - bevor Sie sich trauen, eine Tätowierung anzubringen, sollten Sie besondere Aufmerksamkeit auf die Weisen des Interessierens für eine neue Verzierung des Knöchels richten.
<G-vec01061-002-s165><dare.sich_trauen><en> Let your young ghost hunter join Jack and Parker – if they dare.
<G-vec01061-002-s165><dare.sich_trauen><de> Lassen Sie Ihre Nachwuchs-Geisterjäger mit Jack und Parker losziehen – falls sie sich trauen.
<G-vec01061-002-s166><dare.sich_trauen><en> Places filled with danger and foreboding where no ordinary man would dare to journey.
<G-vec01061-002-s166><dare.sich_trauen><de> Orte, gefüllt mit Gefahr und düsterer Vorahnung, wo kein gewöhnlicher Mann sich zu reisen trauen würde.
<G-vec01061-002-s167><dare.sich_trauen><en> Allianz, is the home for those who dare.
<G-vec01061-002-s167><dare.sich_trauen><de> Die Allianz ist das Zuhause für alle, die sich trauen.
<G-vec01061-002-s168><dare.sich_trauen><en> In winter, many plants wait patiently buried in the earth until they dare to come out of the ground in spring.
<G-vec01061-002-s168><dare.sich_trauen><de> Viele Pflanzen machen es im Winter dann so: Sie harren geduldig in der Erde aus, bis sie sich im Frühling wieder aus dem Boden trauen.
<G-vec01061-002-s169><dare.sich_trauen><en> Here is a door to an arcane realm of wisdom & enchantment, if you dare to enter.
<G-vec01061-002-s169><dare.sich_trauen><de> Hier ist eine Tür zu einer geheimnisvollen Reich der Weisheit und Verzauberung, wenn Sie sich trauen zu gelangen.
<G-vec01061-002-s170><dare.sich_trauen><en> Although some people do not dare to take it themselves, they all want to read.
<G-vec01061-002-s170><dare.sich_trauen><de> Obwohl einige sich nicht trauen es selber anzunehmen, wollen sie es alle lesen.
<G-vec01061-002-s171><dare.sich_trauen><en> I think it is amazing when girls dare to wear caps and show their own style.
<G-vec01061-002-s171><dare.sich_trauen><de> Ich finde es toll wenn sich Mädchen trauen Caps zu tragen und ihren Stil zeigen.
<G-vec01061-002-s172><dare.sich_trauen><en> Because they dare to be different and capture their customer’s enthusiasm.
<G-vec01061-002-s172><dare.sich_trauen><de> Weil sie sich trauen, anders zu sein und dadurch die Begeisterung ihrer Kunden einfangen können.
<G-vec01061-002-s173><dare.sich_trauen><en> You have dare to do it and go to the boundaries.
<G-vec01061-002-s173><dare.sich_trauen><de> Man muss sich trauen und an Grenzen gehen.
<G-vec01061-002-s174><dare.sich_trauen><en> Round birthdays or family celebrations become an unforgettable event when some of their invited guests dare to spend two to three hours in a sheltered setting, finally painting, discovering, value and fearlessly choosing colors, shapes and lines like when you were a kid.
<G-vec01061-002-s174><dare.sich_trauen><de> Runde Geburtstage oder Familienfeste, werden zu einem unvergesslichen Ereignis, wenn sich einige ihrer geladenen Gäste für 2 bis 3 Stunden in einem geschützten Rahmen trauen, endlich mal wieder zu malen, zu entdecken, sich wert- und angstfrei für Farben, Formen und Linien zu entscheiden, wie damals als Sie Kind waren.
<G-vec01061-002-s175><dare.sich_trauen><en> Obviously she did not dare to join the group, a cast-out, balancing between wanting and daring.
<G-vec01061-002-s175><dare.sich_trauen><de> Offenbar traute sie sich nicht, sich der Gruppe anzuschliessen, ein Aussenseiter, hin- un hergerissen zwischen wollen und sich nicht trauen.
<G-vec01061-002-s176><dare.sich_trauen><en> These garments, perfect synthesis of fashion and transgressive spirit, will make the happiness of those who love to dare and want to be "different".
<G-vec01061-002-s176><dare.sich_trauen><de> Diese Kleidungsst├╝cke, eine perfekte Synthese von Mode und transgressivem Geist, werden das Gl├╝ck derer machen die es lieben, sich zu trauen und "anders" sein zu wollen.
<G-vec01061-002-s177><dare.sich_trauen><en> In issuing the manifesto, our aim is to address this sensitive issue and attempt to give people support so that they dare to stand up and fight for what they believe in.
<G-vec01061-002-s177><dare.sich_trauen><de> Wir wollen mit dem Manifest den Finger in die Wunde legen und versuchen, Menschen zu unterstützen, damit sie sich trauen, Haltung zu zeigen.
<G-vec01061-002-s178><dare.sich_trauen><en> Together with their clients, Freund & Reiter develop the decisive process steps and give them the courage to dare.
<G-vec01061-002-s178><dare.sich_trauen><de> Gemeinsam erarbeiten Freund & Reiter mit ihren Kunden die entscheidenden Prozessschritte und geben ihnen Mut sich zu trauen.
<G-vec01061-002-s179><dare.sich_trauen><en> SLAG: I could tell you some really funny stories, about what people do, or dare to do, just to look important and cool on stage.
<G-vec01061-002-s179><dare.sich_trauen><de> SLAG: Ich könnte ein paar richtig lustige Geschichten erzählen, was Leute tun oder sich trauen zu tun, bloß damit sie wichtig und cool aussehen auf der Bühne.
<G-vec01061-002-s180><dare.sich_trauen><en> Who thinks it’s all about strength, will not dare to use these alternatives, and stay in the positioning battle.
<G-vec01061-002-s180><dare.sich_trauen><de> Wer denkt, dass es immer um Stärke geht, wird sich nicht trauen, diese Alternativen anzuwenden, und im Positionierungskampf bleiben.
<G-vec01061-002-s181><dare.sich_trauen><en> Maybe your cadWeazle can be the link between those who desperately need one and those who could use one but would never dare to do it.
<G-vec01061-002-s181><dare.sich_trauen><de> Vielleicht ist Ihr cadWeazle endlich mal ein Rollstuhl, der eine Brücke schlägt zwischen denen, die ihn unbedingt brauchen und denen, die einen gebrauchen könnten, sich aber nie trauen würden, einen zu nutzen.
<G-vec01061-002-s182><dare.sich_trauen><en> If you dare, you can plunge into the depths yourself.
<G-vec01061-002-s182><dare.sich_trauen><de> Wer sich traut, kann sich hier gleich selbst in die Tiefe stürzen.
<G-vec01061-002-s183><dare.sich_trauen><en> For me homeland is where you dare to criticise something.
<G-vec01061-002-s183><dare.sich_trauen><de> Heimat ist für mich da, wo man sich traut, etwas zu kritisieren.
<G-vec01061-002-s184><dare.sich_trauen><en> For those who dare to venture into our nightmare world, we salute your bravery.
<G-vec01061-002-s184><dare.sich_trauen><de> Wer sich traut, in unsere Albtraumwelt vorzudringen, dem ist unser Respekt jedenfalls sicher.
<G-vec01061-002-s185><dare.sich_trauen><en> If you do dare to go inside, you will be rewarded.
<G-vec01061-002-s185><dare.sich_trauen><de> Doch wer sich einmal hinein traut, wird belohnt.
<G-vec01061-002-s186><dare.sich_trauen><en> Those who dare to approach the casts made from polyester resin closely are rewarded with an unabashed look at things which could never be studied so uninhibitedly at the model itself: wrinkles, facial hair and other bodily imperfections.
<G-vec01061-002-s186><dare.sich_trauen><de> Wer sich traut, nahe an die Abgüsse aus Polyesterharz heranzutreten, kann fasziniert betrachten, was er am lebenden Vorbild wohl nicht so ungeniert begucken dürfte: Falten, Härchen und andere körperliche Unvollkommenheiten.
<G-vec01061-002-s198><dare.sich_trauen><en> Dare to say something like that, even if it seems weird or the statement may even be wrong.
<G-vec01061-002-s198><dare.sich_trauen><de> Trau Dich so etwas zu sagen, auch wenn es Dir komisch vorkommt oder das Statement sogar falsch sein kann.
<G-vec01061-002-s199><dare.sich_trauen><en> Do you dare, even if you are a beginner and YOU get the highest pleasure from the finest transsexual erotic.
<G-vec01061-002-s199><dare.sich_trauen><de> Trau Dich, auch wenn Du Anfänger bist und DU kommst in den höchsten Genuss transsexueller Erotik vom Feinsten.
<G-vec01061-002-s200><dare.sich_trauen><en> Dare in the depths of passion.
<G-vec01061-002-s200><dare.sich_trauen><de> Trau dich in die Untiefen der Leidenschaft.
<G-vec01061-002-s201><dare.sich_trauen><en> Make this year the year that you dare to bare.
<G-vec01061-002-s201><dare.sich_trauen><de> Mach dieses Jahr zu deinem Jahr und trau dich was.
<G-vec01061-002-s202><dare.sich_trauen><en> I do not dare thinking about what could have happened if we had continued what if we had arrived earlier at an agreement with the interested parties from the USA who had shown up quite swanky at our office in Richard Wagner Street, what if… What is left is the probably best live album in the history of German rock music.
<G-vec01061-002-s202><dare.sich_trauen><de> Ich traue mich nicht darüber nachzudenken, wenn wir damals weiter gemacht hätten, wenn wir vielleicht schon früher mit den Interessenten aus den den USA,die recht großkotzig in unserem Büro in der Richard Wagner Straße aufgekreuzt waren, handelseinig geworden wären, wenn…… Geblieben ist das wohl beste Live Album in der Geschichte der Deutschen Rockmusik.
<G-vec01061-002-s203><dare.sich_trauen><en> Apart from the fact that I’m not in the Middle East or the Bronx or in a war zone, I dare to travel alone as a woman.
<G-vec01061-002-s203><dare.sich_trauen><de> Mal ganz davon abgesehen davon, dass ich weder in den mittleren Osten oder in die Bronx reise oder in ein Kriegsgebiet, traue ich mich alleine als Frau zu reisen.
<G-vec01061-002-s204><dare.sich_trauen><en> I do not dare to judge myself if something like this can happen or not.
<G-vec01061-002-s204><dare.sich_trauen><de> Ich traue mir nicht zu, zu beurteilen, ob sowas passieren kann oder nicht.
<G-vec01061-002-s205><dare.sich_trauen><en> (I don’t dare to mention the Cambridge Univeristy Library which my supervisor presented me as one of the most ugly buildings of Cambridge).
<G-vec01061-002-s205><dare.sich_trauen><de> (Ich traue mich gar nicht, die Uni-Bibliothek zu erwähnen, die mir mein Betreuer bei meinem ersten Besuch als eines der hässlichsten Gebäude von Cambridge vorstellte).
<G-vec01061-002-s206><dare.sich_trauen><en> www.don´t dare to dance it, but it is on my mind.
<G-vec01061-002-s206><dare.sich_trauen><de> Obwohl ich mich nicht traue, ihn zu tanzen, behalte ich ihn stets im Sinn.
<G-vec01061-002-s207><dare.sich_trauen><en> Perhaps I’ll dare to go to Kosovo for the European Championship in May.
<G-vec01061-002-s207><dare.sich_trauen><de> Vielleicht traue ich mich, im Mai in den Kosovo zu gehen für die Europäische Meisterschaft.
<G-vec01061-002-s208><dare.sich_trauen><en> I definitely dare to go further than before.
<G-vec01061-002-s208><dare.sich_trauen><de> Ich traue mich auf jeden Fall weiter weg als früher.
<G-vec01061-002-s209><dare.sich_trauen><en> I dare say that he’s somebody who has great respect for life”, explained Zeilic.
<G-vec01061-002-s209><dare.sich_trauen><de> Ich traue mich zusagen, dass er jemand ist, der einen großen Respekt vor dem Leben hat“, erklärte Zeilic.
<G-vec01061-002-s210><dare.sich_trauen><en> Who knows me knows I dare not always so with blobs and color.
<G-vec01061-002-s210><dare.sich_trauen><de> Also wer mich kennt, ich traue mich nicht immer so mit Klecksen und Farbe.
<G-vec01061-002-s212><dare.sich_trauen><en> But I really don’t dare to make that shaky assumption in front of Mr. Richard Sears now.
<G-vec01061-002-s212><dare.sich_trauen><de> Ich traue mich aber nicht, diese wacklige Vermutung hier jetzt vor Richard Sears auszubreiten.
<G-vec01061-002-s213><dare.sich_trauen><en> Dare to be bold and different.
<G-vec01061-002-s213><dare.sich_trauen><de> Traue dich, mutig und anders zu sein.
<G-vec01061-002-s214><dare.sich_trauen><en> If you truly are the God of infinite love, the God whose love is so staggering that it surpasses knowledge (Ephesians 3:19) with the power to go far beyond what I can ask or think (Ephesians 3:20), I dare to ask for love that surpasses my wildest dreams.
<G-vec01061-002-s214><dare.sich_trauen><de> Wenn du tatsächlich der Gott der unendlichen Liebe bist, der Gott dessen Liebe so gewaltig ist, dass es alle Erkenntnis übersteigt (Epheser 3:19), mit einer Kraft, die stärker ist, als alles, was ich erbitten oder mir ausdenken könnte (Epheser 3:20), dann traue ich mich, dich nach der Liebe zu fragen, die meine kühnsten Träume übersteigt.
<G-vec01061-002-s215><dare.sich_trauen><en> Description Dare to bare with this works' Perfect Legs Sculpt and Shine Serum, an innovative highlighter that helps define and shape your legs with its light-diffusing powders and subtle golden glow.
<G-vec01061-002-s215><dare.sich_trauen><de> Beschreibung Traue dich mit dem this works 'Perfect Legs Sculpt and Shine-Serum, einem innovativen Highlighter, der mit seinem lichtstreuenden Puder und seinem feinen goldenen Glanz deine Beine definiert und formt, deine Beine zu zeigen.
<G-vec01061-002-s216><dare.sich_trauen><en> "Dare to walk the fine line between risk and return.
<G-vec01061-002-s216><dare.sich_trauen><de> «Traue dich, den schmalen Grad zwischen Risiko und Rendite zu gehen.
<G-vec01061-002-s217><dare.sich_trauen><en> Dare to live the life you have dreamed for yourself.
<G-vec01061-002-s217><dare.sich_trauen><de> Traue Dich ein Leben zu leben, wie Du es Dir immer gewünscht hast.
<G-vec01061-002-s218><dare.sich_trauen><en> Start with short touches on the shoulder during the conversation. Depending on the reaction, you can also dare to touch her hand a little longer, for example.
<G-vec01061-002-s218><dare.sich_trauen><de> Fange am besten mit kurzen Berührungen an der Schulter während des Gesprächs an und traue Dich je nach Reaktion auch, die Hand beispielsweise etwas länger zu berühren.
<G-vec01061-002-s219><dare.sich_trauen><en> That's where I can try out things that I wouldn't otherwise dare to.
<G-vec01061-002-s219><dare.sich_trauen><de> Da kann ich dann die Sachen ausprobieren, die ich mich sonst nicht trauen würde.
<G-vec01061-002-s220><dare.sich_trauen><en> Only when we dare to leave our comfort zone can we begin to learn.
<G-vec01061-002-s220><dare.sich_trauen><de> Nur wenn wir uns trauen, unsere Komfortzone zu verlassen, können wir beginnen, zu lernen.
<G-vec01061-002-s221><dare.sich_trauen><en> Speed skating + short track clothing with correct color, yes we dare.
<G-vec01061-002-s221><dare.sich_trauen><de> Eisschnelllauf + Short Trackbekleidung mit richtig Farbe, ja das trauen wir uns.
<G-vec01061-002-s222><dare.sich_trauen><en> Dare to unwind and just listen to the sound of the lapping waves. You’ll feel right at home in our apartments from where you can contemplate views of the sky blending with the sea.
<G-vec01061-002-s222><dare.sich_trauen><de> Trauen Sie sich abzuschalten und nur dem Rauschen der Wellen zu lauschen, während Sie von unseren Appartements einen Ausblick genießen, bei dem der Himmel mit dem Meer verschmilzt.
<G-vec01061-002-s223><dare.sich_trauen><en> Dare to stand out with e-Skates that are stylish, cool and fun to master.
<G-vec01061-002-s223><dare.sich_trauen><de> Trauen Sie sich, mit E-Skates herauszustechen, die stylish und cool sind.
<G-vec01061-002-s224><dare.sich_trauen><en> It took a week for the delegates to really dare to put this into practice.
<G-vec01061-002-s224><dare.sich_trauen><de> Es hat eine Woche gedauert, bis sich die Delegierten auch wirklich trauen, das umzusetzen.
<G-vec01061-002-s225><dare.sich_trauen><en> Nevertheless, we dare to offer you a guarantee and to refund your fees in case you were not satisfied with our services.
<G-vec01061-002-s225><dare.sich_trauen><de> Dennoch trauen wir uns eine Garantie zu und erstatten Ihnen das Honorar zurück, wenn die Leistung nicht gestimmt hat.
<G-vec01061-002-s226><dare.sich_trauen><en> It is not just obedience that needs to be taught in a civilised society, but also disobedience needs space and instruction as well courageous people, who dare to disobey instructions at strategic moments.
<G-vec01061-002-s226><dare.sich_trauen><de> Dieses Geschäft verlässt garantiert niemand ohne die eine oder andere Nicht nur Gehorsam will in einer zivilisierten Gesellschaft gelernt sein, auch der Ungehorsam braucht Raum und Anleitung sowie couragierte Menschen, die sich in wichtigen Momenten trauen, ungehorsam zu sein.
<G-vec01061-002-s227><dare.sich_trauen><en> Chef Adam Aamann does what few dare: he successfully reinterprets smørrebrød.
<G-vec01061-002-s227><dare.sich_trauen><de> Chefkoch Adam Aamann tut etwas, das sich nur wenige trauen: Er interpretiert Smørrebrød erfolgreich neu.
<G-vec01061-002-s228><dare.sich_trauen><en> We believe that with a well-developed, wide and, where possible and necessary, structurally separate cycling infrastructure, many people who presently do not dare to cycle in city traffic would also start using bicycles.
<G-vec01061-002-s228><dare.sich_trauen><de> Wir glauben, dass mit einer gut ausgebauten, breiten und, wo möglich und nötig, baulich getrennten Fahrradinfrastruktur viele Menschen, die sich momentan nicht in den Stadtverkehr trauen, auch das Fahrrad nutzen würden.
<G-vec01061-002-s229><dare.sich_trauen><en> They have much fun in the rubber boots and also dare deeply into the water.
<G-vec01061-002-s229><dare.sich_trauen><de> Sie haben viel Spaß in den Gummistiefeln und trauen sich auch tief ins Wasser.
<G-vec01061-002-s230><dare.sich_trauen><en> The Social Democrats are just as perplexed as most of their European colleagues, and the conservatives don't dare to turn the page on Merkel.
<G-vec01061-002-s230><dare.sich_trauen><de> Die Sozialdemokraten sind genauso ratlos wie die meisten ihrer europäischen Kollegen, und die Konservativen trauen sich nicht, das Kapitel Merkel abzuschließen.
<G-vec01061-002-s231><dare.sich_trauen><en> Those who are still living in Iraq hardly dare to step out of their houses for fear of falling victim to a crime.
<G-vec01061-002-s231><dare.sich_trauen><de> Diejenigen, die noch im Irak leben, trauen sich aus Angst davor, Opfer eines Verbrechens zu werden, kaum mehr aus ihren Häusern.
<G-vec01061-002-s232><dare.sich_trauen><en> Or you or your employees can guess what strategy the respective short posting contains (only the best ones dare to do so).
<G-vec01061-002-s232><dare.sich_trauen><de> Oder Sie oder Ihre Mitarbeitenden raten, welche Strategie das jeweilige Kurz-Posting beinhaltet (Das trauen sich nur die Besten).
<G-vec01061-002-s233><dare.sich_trauen><en> Not to be touched, not to be helplessly at the mercy of constant harassment and everyday insults in the bus, to dare to say “NO” at all and to defend oneself against sexist violence: this is not understandable for Indian women and girls.
<G-vec01061-002-s233><dare.sich_trauen><de> Sich nicht angrabschen zu lassen, der ständigen Belästigung und den alltäglichen Anzüglichkeiten im Bus nicht hilflos ausgeliefert zu sein, sich überhaupt zu trauen „NEIN!“ zu sagen und sich gegen sexistische Gewalt zu wehren: das ist nicht selbst verständlich für indische Frauen und Mädchen.
<G-vec01061-002-s234><dare.sich_trauen><en> Do you dare to experience something new.
<G-vec01061-002-s234><dare.sich_trauen><de> Trauen Sie sich etwas Neues zu erleben.
<G-vec01061-002-s235><dare.sich_trauen><en> Jump from a bridge while a bungee cord keeps you safe or dare to go parasailing.
<G-vec01061-002-s235><dare.sich_trauen><de> Dann stürzen Sie sich am Bungee-Seil von einer Brücke oder trauen Sie sich ans Parasailing.
<G-vec01061-002-s236><dare.sich_trauen><en> Only the wisest and bravest dare to start an adventure in the challenging weather conditions evoked by sprinkling secret powders in the air.
<G-vec01061-002-s236><dare.sich_trauen><de> Nur die Weisesten und Mutigsten trauen sich, unter bestimmten Wetterbedingungen ein Abenteuer zu starten, die von einem geheimnisvollen, rieselnden Pulver in der Luft hervorgerufen wurden.
<G-vec01061-002-s237><dare.sich_trauen><en> The policeman threatens to pack our things, but they don´t dare to do more than carrying one bag from left to right.
<G-vec01061-002-s237><dare.sich_trauen><de> Die Polizisten drohen unsere Sachen einzupacken, aber mehr als eine Tasche von links nach rechts tragen trauen sie sich nicht.
<G-vec01061-002-s238><dare.sich_trauen><en> Influencers dare to successfully use their questions as a frame of reference.
<G-vec01061-002-s238><dare.sich_trauen><de> Influencer trauen sich mit Erfolg ihre Fragen als Referenzrahmen zu nehmen.
<G-vec01061-002-s239><dare.sich_trauen><en> Try it to your heart’s content, style your hair and dare to transform yourself every now and then – you’ll be surprised what you’ve got in you.
<G-vec01061-002-s239><dare.sich_trauen><de> Probieren Sie sich nach Herzenslust aus, stylen Sie sich die Haare und trauen Sie sich, sich hin und wieder zu verwandeln – Sie werden überrascht sein, was alles in Ihnen steckt.
<G-vec01061-002-s240><dare.sich_trauen><en> Dare, choose your design regardless of the small, or large hallway.
<G-vec01061-002-s240><dare.sich_trauen><de> Trauen Sie sich, wählen Sie Ihr Design unabhängig von der kleinen oder großen Halle.
<G-vec01061-002-s241><dare.sich_trauen><en> Dare to try.
<G-vec01061-002-s241><dare.sich_trauen><de> Trauen Sie sich.
<G-vec01061-002-s242><dare.sich_trauen><en> Everyone wants to go, but only a few people dare.
<G-vec01061-002-s242><dare.sich_trauen><de> Jeder will einmal hin, aber nur die wenigsten Menschen trauen sich.
<G-vec01061-002-s243><dare.sich_trauen><en> There is free software to handle MP3 format, to play it and to generate it, but because it's patented in many countries, many distributors of free software don't dare include those programs; so if they distribute the GNU+Linux system, their system doesn't include a player for MP3.
<G-vec01061-002-s243><dare.sich_trauen><de> Es gibt freie Software, um mit dem MP3-Format umzugehen, es abzuspielen und zu generieren, doch da es in vielen Ländern patentiert ist, trauen sich viele Herausgeber freier Software nicht, diese Programme miteinzubeziehen; wenn sie also das GNU/Linux-System herausgeben, enthält ihr System kein Abspielprogramm für MP3.
<G-vec01061-002-s244><dare.sich_trauen><en> They rely on diversification and services and dare to make mistakes.
<G-vec01061-002-s244><dare.sich_trauen><de> Sie setzen auf Diversifikation sowie Services und trauen sich, Fehler zu machen.
<G-vec01061-002-s245><dare.sich_trauen><en> They don’t dare to present their ideas on a big stage, let alone expand and implement them.
<G-vec01061-002-s245><dare.sich_trauen><de> Sie trauen sich nicht, ihre Ideen auf einer großen Bühne zu präsentieren, geschweige denn weiter auszubauen und umzusetzen.
<G-vec01061-002-s246><dare.sich_trauen><en> More and more people dare to share their experiences on the path of ascension on Youtube, and thus carry many pearls into the community of lightworkers and light warriors.
<G-vec01061-002-s246><dare.sich_trauen><de> Immer mehr Menschen trauen sich auf Youtube ihre Erlebnisse auf dem Aufstiegspfad zu teilen, und tragen so viele Perlen in die Gemeinschaft der Lichtarbeiter und Lichtkrieger.
<G-vec01061-002-s247><dare.sich_trauen><en> He’s allowed to, many dead are speaking now in their choked voices, now they dare to, because my own language is not keeping any eye on me.
<G-vec01061-002-s247><dare.sich_trauen><de> Er darf das, viele Tote sprechen jetzt mit ihren erstickten Stimmen, jetzt trauen sie sich das, weil meine eigene Sprache nicht auf mich aufpaßt.
<G-vec01061-002-s248><dare.sich_trauen><en> How dare she tell people the truth.
<G-vec01061-002-s248><dare.sich_trauen><de> Sie traut sich, sie sagt den Menschen die Wahrheit.
<G-vec01061-002-s249><dare.sich_trauen><en> Often, especially in times of the Internet, clients dare to “google” problems on their own.
<G-vec01061-002-s249><dare.sich_trauen><de> Gerade in Zeiten des Internets traut man sich häufig zu, Probleme auf eigene Faust zu "ergoogeln".
<G-vec01061-002-s250><dare.sich_trauen><en> Unless you dare to sit on the tin can and have a closer look.
<G-vec01061-002-s250><dare.sich_trauen><de> Außer man traut sich, direkt auf die Blechkiste zu steigen und sich die Sache aus der Nähe anzusehen.
<G-vec01061-002-s251><dare.sich_trauen><en> The sun illuminates the flowery patio, the wind doesn't dare enter into this paradise, and the shade of the mulberry is often welcome.
<G-vec01061-002-s251><dare.sich_trauen><de> Dort lässt die Sonne den blumenbewachsenen Patio aufleuchten, der Wind traut sich nicht dieses Paradies zu betreten und die schattenspendenden Maulbeerbäume bringen willkommene Abkühlung.
<G-vec01061-002-s252><dare.sich_trauen><en> But the ECB does not dare to restart its sovereign bond-buying program with the aim of providing additional economic stimulus, because national central banks in the eurozone already hold large amounts of their own governments’ bonds.
<G-vec01061-002-s252><dare.sich_trauen><de> Die EZB traut sich jedoch nicht, zur Stimulation der Wirtschaft ihr Programm zum Ankauf von Staatsanleihen neu aufzulegen, weil die nationalen Notenbanken der Eurozone bereits jetzt große Mengen der Anleihen ihrer eigenen Regierungen halten.
<G-vec01061-002-s253><dare.sich_trauen><en> Her boyfriend and she dare to speak with her, proposing a threesome to start in porn with her advice.
<G-vec01061-002-s253><dare.sich_trauen><de> Zusammen mit ihrem Freund traut sie sich sie anzusprechen und ihr einen Dreier vorzuschlagen, um so beim Porno einzusteigen.
<G-vec01061-002-s254><dare.sich_trauen><en> We had just fallen in love - a feeling that does tend to make you a little crazy – and you sometimes dare to do things that you perhaps wouldn't in other life situations.
<G-vec01061-002-s254><dare.sich_trauen><de> Wir waren frisch verliebt und dieses frisch Verliebtsein macht einen ja so ein bisschen gaga – und man traut sich manchmal Dinge, die man in einer anderen Lebenssituation vielleicht nicht umsetzen würde.
<G-vec01061-002-s255><dare.sich_trauen><en> Then, however, none of the other demons openly dare to say anything against it.
<G-vec01061-002-s255><dare.sich_trauen><de> Dann traut sich allerdings auch keiner der anderen Dämonen offen dagegen etwas zu sagen.
<G-vec01061-002-s048><dare.trauen><en> However, if you dare to stray from their all-encompassing yet well-designed pizza list, you can expect a range of great Italian classic dishes as well as Cologne’s traditional dishes.
<G-vec01061-002-s048><dare.trauen><de> Wenn du dich traust, die umfassende Pizza-Karte beiseite zu legen, erwarten dich neben den klassischen italienischen Gerichten, auch lokale kölsche Traditionsgerichte.
<G-vec01061-002-s049><dare.trauen><en> Play him anything before just because you do not dare to talk to him, if he notices it, it is even worse for him and you will soon not want him, if you never have anything from sex.
<G-vec01061-002-s049><dare.trauen><de> Spiele ihm nichts vor, nur weil Du Dich nicht traust mit ihm zu reden, wenn er es merkt, ist es für ihn noch schlimmer und Du wirst ihn bald nicht mehr wollen, wenn Du nie etwas vom Sex hast.
<G-vec01061-002-s050><dare.trauen><en> Try the looping water-slide, The Scorpion's Tail, if you dare.
<G-vec01061-002-s050><dare.trauen><de> Probieren Sie die Looping Wasserrutsche, The Scorpion Tail, wenn du dich traust.
<G-vec01061-002-s108><dare.trauen><en> But when everything was over and the perpetrators had fled, the police "dare" to appear.
<G-vec01061-002-s108><dare.trauen><de> Erst als alles vorbei war und die Täter die Flucht ergriffen hatten, hat sich die Polizei „getraut“ zu erscheinen.
<G-vec01061-002-s109><dare.trauen><en> But I did not dare to follow their example immediately.
<G-vec01061-002-s109><dare.trauen><de> Das habe ich mich aber nicht gleich getraut.
<G-vec01061-002-s110><dare.trauen><en> The location is breathtaking – in more than one sense: atop a cliff where there’s always strong winds and on this day it felt like a force 9 blowing on the Beaufort scale (if I may quote Billy Joel) – so I didn’t dare go too close to the edge.
<G-vec01061-002-s110><dare.trauen><de> Die Lage ist atemberaubend, an einer Steilküste, wo immer ordentlich Wind geht – an diesem Tag eher Orkanstärke, so dass ich mich wirklich nicht an den Rand getraut habe.
<G-vec01061-002-s111><dare.trauen><en> His flatmates and friends had already been worried about his absence during the evening but didn’t dare to leave the house to search for him due to the ongoing Pegida demonstration.
<G-vec01061-002-s111><dare.trauen><de> Seine Mitbewohner_innen und Freund_innen hatten sich bereits am Abend Sorgen gemacht, sie hatten sich aber aufgrund der laufenden Pegida-Demonstration nicht aus dem Haus getraut, um nach ihrem Freund zu suchen.
<G-vec01061-002-s112><dare.trauen><en> Afterwards I didn't dare mention this event to others for fear that they would not believe me.
<G-vec01061-002-s112><dare.trauen><de> Ich habe mich hinterher gar nicht getraut, diesen Vorfall anderen gegenüber zu erwähnen, aus Furcht, sie würden mir das nicht glauben.
<G-vec01061-002-s113><dare.trauen><en> We did not want to go on Berlin beta, therefore we felt obligated to go on AR the Electronica and easily did not dare to say to them they would be just as bloed and we also, because we would have come.
<G-vec01061-002-s113><dare.trauen><de> Wir wollten naemlich nicht auf die Berlin Beta gehen, deshalb fuehlten wir uns verpflichtet, auf die Ars Electronica zu gehen, und haben uns einfach nicht getraut, ihnen zu sagen, sie waeren genauso bloed und wir auch, weil wir gekommen waeren.
<G-vec01061-002-s114><dare.trauen><en> After I did not dare to learn to surf in Bali, I had overcome myself and completed a one-week surf course.
<G-vec01061-002-s114><dare.trauen><de> Nachdem ich mich auf Bali nicht getraut hatte, surfen zu lernen, habe ich mich überwunden und einen einwöchigen Surfkurs absolviert.
<G-vec01061-002-s115><dare.trauen><en> Preamble: I wanted to write this article at the end of June but I didn't dare.
<G-vec01061-002-s115><dare.trauen><de> Diesen Artikel wollte ich noch Ende Juni schreiben, aber ich habe mich nicht getraut.
<G-vec01061-002-s163><dare.trauen><en> But you know, only if you dare...
<G-vec01061-002-s163><dare.trauen><de> Aber wissen Sie, nur wenn Sie sich trauen...
<G-vec01061-002-s164><dare.trauen><en> The main thing - before you dare to apply a tattoo, you should pay special attention to the ways of caring for a new ornament to the ankle.
<G-vec01061-002-s164><dare.trauen><de> Die Hauptsache - bevor Sie sich trauen, eine Tätowierung anzubringen, sollten Sie besondere Aufmerksamkeit auf die Weisen des Interessierens für eine neue Verzierung des Knöchels richten.
<G-vec01061-002-s165><dare.trauen><en> Let your young ghost hunter join Jack and Parker – if they dare.
<G-vec01061-002-s165><dare.trauen><de> Lassen Sie Ihre Nachwuchs-Geisterjäger mit Jack und Parker losziehen – falls sie sich trauen.
<G-vec01061-002-s166><dare.trauen><en> Places filled with danger and foreboding where no ordinary man would dare to journey.
<G-vec01061-002-s166><dare.trauen><de> Orte, gefüllt mit Gefahr und düsterer Vorahnung, wo kein gewöhnlicher Mann sich zu reisen trauen würde.
<G-vec01061-002-s167><dare.trauen><en> Allianz, is the home for those who dare.
<G-vec01061-002-s167><dare.trauen><de> Die Allianz ist das Zuhause für alle, die sich trauen.
<G-vec01061-002-s168><dare.trauen><en> In winter, many plants wait patiently buried in the earth until they dare to come out of the ground in spring.
<G-vec01061-002-s168><dare.trauen><de> Viele Pflanzen machen es im Winter dann so: Sie harren geduldig in der Erde aus, bis sie sich im Frühling wieder aus dem Boden trauen.
<G-vec01061-002-s169><dare.trauen><en> Here is a door to an arcane realm of wisdom & enchantment, if you dare to enter.
<G-vec01061-002-s169><dare.trauen><de> Hier ist eine Tür zu einer geheimnisvollen Reich der Weisheit und Verzauberung, wenn Sie sich trauen zu gelangen.
<G-vec01061-002-s170><dare.trauen><en> Although some people do not dare to take it themselves, they all want to read.
<G-vec01061-002-s170><dare.trauen><de> Obwohl einige sich nicht trauen es selber anzunehmen, wollen sie es alle lesen.
<G-vec01061-002-s171><dare.trauen><en> I think it is amazing when girls dare to wear caps and show their own style.
<G-vec01061-002-s171><dare.trauen><de> Ich finde es toll wenn sich Mädchen trauen Caps zu tragen und ihren Stil zeigen.
<G-vec01061-002-s172><dare.trauen><en> Because they dare to be different and capture their customer’s enthusiasm.
<G-vec01061-002-s172><dare.trauen><de> Weil sie sich trauen, anders zu sein und dadurch die Begeisterung ihrer Kunden einfangen können.
<G-vec01061-002-s173><dare.trauen><en> You have dare to do it and go to the boundaries.
<G-vec01061-002-s173><dare.trauen><de> Man muss sich trauen und an Grenzen gehen.
<G-vec01061-002-s174><dare.trauen><en> Round birthdays or family celebrations become an unforgettable event when some of their invited guests dare to spend two to three hours in a sheltered setting, finally painting, discovering, value and fearlessly choosing colors, shapes and lines like when you were a kid.
<G-vec01061-002-s174><dare.trauen><de> Runde Geburtstage oder Familienfeste, werden zu einem unvergesslichen Ereignis, wenn sich einige ihrer geladenen Gäste für 2 bis 3 Stunden in einem geschützten Rahmen trauen, endlich mal wieder zu malen, zu entdecken, sich wert- und angstfrei für Farben, Formen und Linien zu entscheiden, wie damals als Sie Kind waren.
<G-vec01061-002-s175><dare.trauen><en> Obviously she did not dare to join the group, a cast-out, balancing between wanting and daring.
<G-vec01061-002-s175><dare.trauen><de> Offenbar traute sie sich nicht, sich der Gruppe anzuschliessen, ein Aussenseiter, hin- un hergerissen zwischen wollen und sich nicht trauen.
<G-vec01061-002-s176><dare.trauen><en> These garments, perfect synthesis of fashion and transgressive spirit, will make the happiness of those who love to dare and want to be "different".
<G-vec01061-002-s176><dare.trauen><de> Diese Kleidungsst├╝cke, eine perfekte Synthese von Mode und transgressivem Geist, werden das Gl├╝ck derer machen die es lieben, sich zu trauen und "anders" sein zu wollen.
<G-vec01061-002-s177><dare.trauen><en> In issuing the manifesto, our aim is to address this sensitive issue and attempt to give people support so that they dare to stand up and fight for what they believe in.
<G-vec01061-002-s177><dare.trauen><de> Wir wollen mit dem Manifest den Finger in die Wunde legen und versuchen, Menschen zu unterstützen, damit sie sich trauen, Haltung zu zeigen.
<G-vec01061-002-s178><dare.trauen><en> Together with their clients, Freund & Reiter develop the decisive process steps and give them the courage to dare.
<G-vec01061-002-s178><dare.trauen><de> Gemeinsam erarbeiten Freund & Reiter mit ihren Kunden die entscheidenden Prozessschritte und geben ihnen Mut sich zu trauen.
<G-vec01061-002-s179><dare.trauen><en> SLAG: I could tell you some really funny stories, about what people do, or dare to do, just to look important and cool on stage.
<G-vec01061-002-s179><dare.trauen><de> SLAG: Ich könnte ein paar richtig lustige Geschichten erzählen, was Leute tun oder sich trauen zu tun, bloß damit sie wichtig und cool aussehen auf der Bühne.
<G-vec01061-002-s180><dare.trauen><en> Who thinks it’s all about strength, will not dare to use these alternatives, and stay in the positioning battle.
<G-vec01061-002-s180><dare.trauen><de> Wer denkt, dass es immer um Stärke geht, wird sich nicht trauen, diese Alternativen anzuwenden, und im Positionierungskampf bleiben.
<G-vec01061-002-s181><dare.trauen><en> Maybe your cadWeazle can be the link between those who desperately need one and those who could use one but would never dare to do it.
<G-vec01061-002-s181><dare.trauen><de> Vielleicht ist Ihr cadWeazle endlich mal ein Rollstuhl, der eine Brücke schlägt zwischen denen, die ihn unbedingt brauchen und denen, die einen gebrauchen könnten, sich aber nie trauen würden, einen zu nutzen.
<G-vec01061-002-s182><dare.trauen><en> If you dare, you can plunge into the depths yourself.
<G-vec01061-002-s182><dare.trauen><de> Wer sich traut, kann sich hier gleich selbst in die Tiefe stürzen.
<G-vec01061-002-s183><dare.trauen><en> For me homeland is where you dare to criticise something.
<G-vec01061-002-s183><dare.trauen><de> Heimat ist für mich da, wo man sich traut, etwas zu kritisieren.
<G-vec01061-002-s184><dare.trauen><en> For those who dare to venture into our nightmare world, we salute your bravery.
<G-vec01061-002-s184><dare.trauen><de> Wer sich traut, in unsere Albtraumwelt vorzudringen, dem ist unser Respekt jedenfalls sicher.
<G-vec01061-002-s185><dare.trauen><en> If you do dare to go inside, you will be rewarded.
<G-vec01061-002-s185><dare.trauen><de> Doch wer sich einmal hinein traut, wird belohnt.
<G-vec01061-002-s186><dare.trauen><en> Those who dare to approach the casts made from polyester resin closely are rewarded with an unabashed look at things which could never be studied so uninhibitedly at the model itself: wrinkles, facial hair and other bodily imperfections.
<G-vec01061-002-s186><dare.trauen><de> Wer sich traut, nahe an die Abgüsse aus Polyesterharz heranzutreten, kann fasziniert betrachten, was er am lebenden Vorbild wohl nicht so ungeniert begucken dürfte: Falten, Härchen und andere körperliche Unvollkommenheiten.
<G-vec01061-002-s198><dare.trauen><en> Dare to say something like that, even if it seems weird or the statement may even be wrong.
<G-vec01061-002-s198><dare.trauen><de> Trau Dich so etwas zu sagen, auch wenn es Dir komisch vorkommt oder das Statement sogar falsch sein kann.
<G-vec01061-002-s199><dare.trauen><en> Do you dare, even if you are a beginner and YOU get the highest pleasure from the finest transsexual erotic.
<G-vec01061-002-s199><dare.trauen><de> Trau Dich, auch wenn Du Anfänger bist und DU kommst in den höchsten Genuss transsexueller Erotik vom Feinsten.
<G-vec01061-002-s200><dare.trauen><en> Dare in the depths of passion.
<G-vec01061-002-s200><dare.trauen><de> Trau dich in die Untiefen der Leidenschaft.
<G-vec01061-002-s201><dare.trauen><en> Make this year the year that you dare to bare.
<G-vec01061-002-s201><dare.trauen><de> Mach dieses Jahr zu deinem Jahr und trau dich was.
<G-vec01061-002-s202><dare.trauen><en> I do not dare thinking about what could have happened if we had continued what if we had arrived earlier at an agreement with the interested parties from the USA who had shown up quite swanky at our office in Richard Wagner Street, what if… What is left is the probably best live album in the history of German rock music.
<G-vec01061-002-s202><dare.trauen><de> Ich traue mich nicht darüber nachzudenken, wenn wir damals weiter gemacht hätten, wenn wir vielleicht schon früher mit den Interessenten aus den den USA,die recht großkotzig in unserem Büro in der Richard Wagner Straße aufgekreuzt waren, handelseinig geworden wären, wenn…… Geblieben ist das wohl beste Live Album in der Geschichte der Deutschen Rockmusik.
<G-vec01061-002-s203><dare.trauen><en> Apart from the fact that I’m not in the Middle East or the Bronx or in a war zone, I dare to travel alone as a woman.
<G-vec01061-002-s203><dare.trauen><de> Mal ganz davon abgesehen davon, dass ich weder in den mittleren Osten oder in die Bronx reise oder in ein Kriegsgebiet, traue ich mich alleine als Frau zu reisen.
<G-vec01061-002-s204><dare.trauen><en> I do not dare to judge myself if something like this can happen or not.
<G-vec01061-002-s204><dare.trauen><de> Ich traue mir nicht zu, zu beurteilen, ob sowas passieren kann oder nicht.
<G-vec01061-002-s205><dare.trauen><en> (I don’t dare to mention the Cambridge Univeristy Library which my supervisor presented me as one of the most ugly buildings of Cambridge).
<G-vec01061-002-s205><dare.trauen><de> (Ich traue mich gar nicht, die Uni-Bibliothek zu erwähnen, die mir mein Betreuer bei meinem ersten Besuch als eines der hässlichsten Gebäude von Cambridge vorstellte).
<G-vec01061-002-s206><dare.trauen><en> www.don´t dare to dance it, but it is on my mind.
<G-vec01061-002-s206><dare.trauen><de> Obwohl ich mich nicht traue, ihn zu tanzen, behalte ich ihn stets im Sinn.
<G-vec01061-002-s207><dare.trauen><en> Perhaps I’ll dare to go to Kosovo for the European Championship in May.
<G-vec01061-002-s207><dare.trauen><de> Vielleicht traue ich mich, im Mai in den Kosovo zu gehen für die Europäische Meisterschaft.
<G-vec01061-002-s208><dare.trauen><en> I definitely dare to go further than before.
<G-vec01061-002-s208><dare.trauen><de> Ich traue mich auf jeden Fall weiter weg als früher.
<G-vec01061-002-s209><dare.trauen><en> I dare say that he’s somebody who has great respect for life”, explained Zeilic.
<G-vec01061-002-s209><dare.trauen><de> Ich traue mich zusagen, dass er jemand ist, der einen großen Respekt vor dem Leben hat“, erklärte Zeilic.
<G-vec01061-002-s210><dare.trauen><en> Who knows me knows I dare not always so with blobs and color.
<G-vec01061-002-s210><dare.trauen><de> Also wer mich kennt, ich traue mich nicht immer so mit Klecksen und Farbe.
<G-vec01061-002-s212><dare.trauen><en> But I really don’t dare to make that shaky assumption in front of Mr. Richard Sears now.
<G-vec01061-002-s212><dare.trauen><de> Ich traue mich aber nicht, diese wacklige Vermutung hier jetzt vor Richard Sears auszubreiten.
<G-vec01061-002-s213><dare.trauen><en> Dare to be bold and different.
<G-vec01061-002-s213><dare.trauen><de> Traue dich, mutig und anders zu sein.
<G-vec01061-002-s214><dare.trauen><en> If you truly are the God of infinite love, the God whose love is so staggering that it surpasses knowledge (Ephesians 3:19) with the power to go far beyond what I can ask or think (Ephesians 3:20), I dare to ask for love that surpasses my wildest dreams.
<G-vec01061-002-s214><dare.trauen><de> Wenn du tatsächlich der Gott der unendlichen Liebe bist, der Gott dessen Liebe so gewaltig ist, dass es alle Erkenntnis übersteigt (Epheser 3:19), mit einer Kraft, die stärker ist, als alles, was ich erbitten oder mir ausdenken könnte (Epheser 3:20), dann traue ich mich, dich nach der Liebe zu fragen, die meine kühnsten Träume übersteigt.
<G-vec01061-002-s215><dare.trauen><en> Description Dare to bare with this works' Perfect Legs Sculpt and Shine Serum, an innovative highlighter that helps define and shape your legs with its light-diffusing powders and subtle golden glow.
<G-vec01061-002-s215><dare.trauen><de> Beschreibung Traue dich mit dem this works 'Perfect Legs Sculpt and Shine-Serum, einem innovativen Highlighter, der mit seinem lichtstreuenden Puder und seinem feinen goldenen Glanz deine Beine definiert und formt, deine Beine zu zeigen.
<G-vec01061-002-s216><dare.trauen><en> "Dare to walk the fine line between risk and return.
<G-vec01061-002-s216><dare.trauen><de> «Traue dich, den schmalen Grad zwischen Risiko und Rendite zu gehen.
<G-vec01061-002-s217><dare.trauen><en> Dare to live the life you have dreamed for yourself.
<G-vec01061-002-s217><dare.trauen><de> Traue Dich ein Leben zu leben, wie Du es Dir immer gewünscht hast.
<G-vec01061-002-s218><dare.trauen><en> Start with short touches on the shoulder during the conversation. Depending on the reaction, you can also dare to touch her hand a little longer, for example.
<G-vec01061-002-s218><dare.trauen><de> Fange am besten mit kurzen Berührungen an der Schulter während des Gesprächs an und traue Dich je nach Reaktion auch, die Hand beispielsweise etwas länger zu berühren.
<G-vec01061-002-s219><dare.trauen><en> That's where I can try out things that I wouldn't otherwise dare to.
<G-vec01061-002-s219><dare.trauen><de> Da kann ich dann die Sachen ausprobieren, die ich mich sonst nicht trauen würde.
<G-vec01061-002-s220><dare.trauen><en> Only when we dare to leave our comfort zone can we begin to learn.
<G-vec01061-002-s220><dare.trauen><de> Nur wenn wir uns trauen, unsere Komfortzone zu verlassen, können wir beginnen, zu lernen.
<G-vec01061-002-s221><dare.trauen><en> Speed skating + short track clothing with correct color, yes we dare.
<G-vec01061-002-s221><dare.trauen><de> Eisschnelllauf + Short Trackbekleidung mit richtig Farbe, ja das trauen wir uns.
<G-vec01061-002-s222><dare.trauen><en> Dare to unwind and just listen to the sound of the lapping waves. You’ll feel right at home in our apartments from where you can contemplate views of the sky blending with the sea.
<G-vec01061-002-s222><dare.trauen><de> Trauen Sie sich abzuschalten und nur dem Rauschen der Wellen zu lauschen, während Sie von unseren Appartements einen Ausblick genießen, bei dem der Himmel mit dem Meer verschmilzt.
<G-vec01061-002-s223><dare.trauen><en> Dare to stand out with e-Skates that are stylish, cool and fun to master.
<G-vec01061-002-s223><dare.trauen><de> Trauen Sie sich, mit E-Skates herauszustechen, die stylish und cool sind.
<G-vec01061-002-s224><dare.trauen><en> It took a week for the delegates to really dare to put this into practice.
<G-vec01061-002-s224><dare.trauen><de> Es hat eine Woche gedauert, bis sich die Delegierten auch wirklich trauen, das umzusetzen.
<G-vec01061-002-s225><dare.trauen><en> Nevertheless, we dare to offer you a guarantee and to refund your fees in case you were not satisfied with our services.
<G-vec01061-002-s225><dare.trauen><de> Dennoch trauen wir uns eine Garantie zu und erstatten Ihnen das Honorar zurück, wenn die Leistung nicht gestimmt hat.
<G-vec01061-002-s226><dare.trauen><en> It is not just obedience that needs to be taught in a civilised society, but also disobedience needs space and instruction as well courageous people, who dare to disobey instructions at strategic moments.
<G-vec01061-002-s226><dare.trauen><de> Dieses Geschäft verlässt garantiert niemand ohne die eine oder andere Nicht nur Gehorsam will in einer zivilisierten Gesellschaft gelernt sein, auch der Ungehorsam braucht Raum und Anleitung sowie couragierte Menschen, die sich in wichtigen Momenten trauen, ungehorsam zu sein.
<G-vec01061-002-s227><dare.trauen><en> Chef Adam Aamann does what few dare: he successfully reinterprets smørrebrød.
<G-vec01061-002-s227><dare.trauen><de> Chefkoch Adam Aamann tut etwas, das sich nur wenige trauen: Er interpretiert Smørrebrød erfolgreich neu.
<G-vec01061-002-s228><dare.trauen><en> We believe that with a well-developed, wide and, where possible and necessary, structurally separate cycling infrastructure, many people who presently do not dare to cycle in city traffic would also start using bicycles.
<G-vec01061-002-s228><dare.trauen><de> Wir glauben, dass mit einer gut ausgebauten, breiten und, wo möglich und nötig, baulich getrennten Fahrradinfrastruktur viele Menschen, die sich momentan nicht in den Stadtverkehr trauen, auch das Fahrrad nutzen würden.
<G-vec01061-002-s229><dare.trauen><en> They have much fun in the rubber boots and also dare deeply into the water.
<G-vec01061-002-s229><dare.trauen><de> Sie haben viel Spaß in den Gummistiefeln und trauen sich auch tief ins Wasser.
<G-vec01061-002-s230><dare.trauen><en> The Social Democrats are just as perplexed as most of their European colleagues, and the conservatives don't dare to turn the page on Merkel.
<G-vec01061-002-s230><dare.trauen><de> Die Sozialdemokraten sind genauso ratlos wie die meisten ihrer europäischen Kollegen, und die Konservativen trauen sich nicht, das Kapitel Merkel abzuschließen.
<G-vec01061-002-s231><dare.trauen><en> Those who are still living in Iraq hardly dare to step out of their houses for fear of falling victim to a crime.
<G-vec01061-002-s231><dare.trauen><de> Diejenigen, die noch im Irak leben, trauen sich aus Angst davor, Opfer eines Verbrechens zu werden, kaum mehr aus ihren Häusern.
<G-vec01061-002-s232><dare.trauen><en> Or you or your employees can guess what strategy the respective short posting contains (only the best ones dare to do so).
<G-vec01061-002-s232><dare.trauen><de> Oder Sie oder Ihre Mitarbeitenden raten, welche Strategie das jeweilige Kurz-Posting beinhaltet (Das trauen sich nur die Besten).
<G-vec01061-002-s233><dare.trauen><en> Not to be touched, not to be helplessly at the mercy of constant harassment and everyday insults in the bus, to dare to say “NO” at all and to defend oneself against sexist violence: this is not understandable for Indian women and girls.
<G-vec01061-002-s233><dare.trauen><de> Sich nicht angrabschen zu lassen, der ständigen Belästigung und den alltäglichen Anzüglichkeiten im Bus nicht hilflos ausgeliefert zu sein, sich überhaupt zu trauen „NEIN!“ zu sagen und sich gegen sexistische Gewalt zu wehren: das ist nicht selbst verständlich für indische Frauen und Mädchen.
<G-vec01061-002-s234><dare.trauen><en> Do you dare to experience something new.
<G-vec01061-002-s234><dare.trauen><de> Trauen Sie sich etwas Neues zu erleben.
<G-vec01061-002-s235><dare.trauen><en> Jump from a bridge while a bungee cord keeps you safe or dare to go parasailing.
<G-vec01061-002-s235><dare.trauen><de> Dann stürzen Sie sich am Bungee-Seil von einer Brücke oder trauen Sie sich ans Parasailing.
<G-vec01061-002-s236><dare.trauen><en> Only the wisest and bravest dare to start an adventure in the challenging weather conditions evoked by sprinkling secret powders in the air.
<G-vec01061-002-s236><dare.trauen><de> Nur die Weisesten und Mutigsten trauen sich, unter bestimmten Wetterbedingungen ein Abenteuer zu starten, die von einem geheimnisvollen, rieselnden Pulver in der Luft hervorgerufen wurden.
<G-vec01061-002-s237><dare.trauen><en> The policeman threatens to pack our things, but they don´t dare to do more than carrying one bag from left to right.
<G-vec01061-002-s237><dare.trauen><de> Die Polizisten drohen unsere Sachen einzupacken, aber mehr als eine Tasche von links nach rechts tragen trauen sie sich nicht.
<G-vec01061-002-s238><dare.trauen><en> Influencers dare to successfully use their questions as a frame of reference.
<G-vec01061-002-s238><dare.trauen><de> Influencer trauen sich mit Erfolg ihre Fragen als Referenzrahmen zu nehmen.
<G-vec01061-002-s239><dare.trauen><en> Try it to your heart’s content, style your hair and dare to transform yourself every now and then – you’ll be surprised what you’ve got in you.
<G-vec01061-002-s239><dare.trauen><de> Probieren Sie sich nach Herzenslust aus, stylen Sie sich die Haare und trauen Sie sich, sich hin und wieder zu verwandeln – Sie werden überrascht sein, was alles in Ihnen steckt.
<G-vec01061-002-s240><dare.trauen><en> Dare, choose your design regardless of the small, or large hallway.
<G-vec01061-002-s240><dare.trauen><de> Trauen Sie sich, wählen Sie Ihr Design unabhängig von der kleinen oder großen Halle.
<G-vec01061-002-s241><dare.trauen><en> Dare to try.
<G-vec01061-002-s241><dare.trauen><de> Trauen Sie sich.
<G-vec01061-002-s242><dare.trauen><en> Everyone wants to go, but only a few people dare.
<G-vec01061-002-s242><dare.trauen><de> Jeder will einmal hin, aber nur die wenigsten Menschen trauen sich.
<G-vec01061-002-s243><dare.trauen><en> There is free software to handle MP3 format, to play it and to generate it, but because it's patented in many countries, many distributors of free software don't dare include those programs; so if they distribute the GNU+Linux system, their system doesn't include a player for MP3.
<G-vec01061-002-s243><dare.trauen><de> Es gibt freie Software, um mit dem MP3-Format umzugehen, es abzuspielen und zu generieren, doch da es in vielen Ländern patentiert ist, trauen sich viele Herausgeber freier Software nicht, diese Programme miteinzubeziehen; wenn sie also das GNU/Linux-System herausgeben, enthält ihr System kein Abspielprogramm für MP3.
<G-vec01061-002-s244><dare.trauen><en> They rely on diversification and services and dare to make mistakes.
<G-vec01061-002-s244><dare.trauen><de> Sie setzen auf Diversifikation sowie Services und trauen sich, Fehler zu machen.
<G-vec01061-002-s245><dare.trauen><en> They don’t dare to present their ideas on a big stage, let alone expand and implement them.
<G-vec01061-002-s245><dare.trauen><de> Sie trauen sich nicht, ihre Ideen auf einer großen Bühne zu präsentieren, geschweige denn weiter auszubauen und umzusetzen.
<G-vec01061-002-s246><dare.trauen><en> More and more people dare to share their experiences on the path of ascension on Youtube, and thus carry many pearls into the community of lightworkers and light warriors.
<G-vec01061-002-s246><dare.trauen><de> Immer mehr Menschen trauen sich auf Youtube ihre Erlebnisse auf dem Aufstiegspfad zu teilen, und tragen so viele Perlen in die Gemeinschaft der Lichtarbeiter und Lichtkrieger.
<G-vec01061-002-s247><dare.trauen><en> He’s allowed to, many dead are speaking now in their choked voices, now they dare to, because my own language is not keeping any eye on me.
<G-vec01061-002-s247><dare.trauen><de> Er darf das, viele Tote sprechen jetzt mit ihren erstickten Stimmen, jetzt trauen sie sich das, weil meine eigene Sprache nicht auf mich aufpaßt.
<G-vec01061-002-s248><dare.trauen><en> How dare she tell people the truth.
<G-vec01061-002-s248><dare.trauen><de> Sie traut sich, sie sagt den Menschen die Wahrheit.
<G-vec01061-002-s249><dare.trauen><en> Often, especially in times of the Internet, clients dare to “google” problems on their own.
<G-vec01061-002-s249><dare.trauen><de> Gerade in Zeiten des Internets traut man sich häufig zu, Probleme auf eigene Faust zu "ergoogeln".
<G-vec01061-002-s250><dare.trauen><en> Unless you dare to sit on the tin can and have a closer look.
<G-vec01061-002-s250><dare.trauen><de> Außer man traut sich, direkt auf die Blechkiste zu steigen und sich die Sache aus der Nähe anzusehen.
<G-vec01061-002-s251><dare.trauen><en> The sun illuminates the flowery patio, the wind doesn't dare enter into this paradise, and the shade of the mulberry is often welcome.
<G-vec01061-002-s251><dare.trauen><de> Dort lässt die Sonne den blumenbewachsenen Patio aufleuchten, der Wind traut sich nicht dieses Paradies zu betreten und die schattenspendenden Maulbeerbäume bringen willkommene Abkühlung.
<G-vec01061-002-s252><dare.trauen><en> But the ECB does not dare to restart its sovereign bond-buying program with the aim of providing additional economic stimulus, because national central banks in the eurozone already hold large amounts of their own governments’ bonds.
<G-vec01061-002-s252><dare.trauen><de> Die EZB traut sich jedoch nicht, zur Stimulation der Wirtschaft ihr Programm zum Ankauf von Staatsanleihen neu aufzulegen, weil die nationalen Notenbanken der Eurozone bereits jetzt große Mengen der Anleihen ihrer eigenen Regierungen halten.
<G-vec01061-002-s253><dare.trauen><en> Her boyfriend and she dare to speak with her, proposing a threesome to start in porn with her advice.
<G-vec01061-002-s253><dare.trauen><de> Zusammen mit ihrem Freund traut sie sich sie anzusprechen und ihr einen Dreier vorzuschlagen, um so beim Porno einzusteigen.
<G-vec01061-002-s254><dare.trauen><en> We had just fallen in love - a feeling that does tend to make you a little crazy – and you sometimes dare to do things that you perhaps wouldn't in other life situations.
<G-vec01061-002-s254><dare.trauen><de> Wir waren frisch verliebt und dieses frisch Verliebtsein macht einen ja so ein bisschen gaga – und man traut sich manchmal Dinge, die man in einer anderen Lebenssituation vielleicht nicht umsetzen würde.
<G-vec01061-002-s255><dare.trauen><en> Then, however, none of the other demons openly dare to say anything against it.
<G-vec01061-002-s255><dare.trauen><de> Dann traut sich allerdings auch keiner der anderen Dämonen offen dagegen etwas zu sagen.
<G-vec01061-002-s064><dare.wagen><en> The defendants didn’t dare to come to Belgium.
<G-vec01061-002-s064><dare.wagen><de> Die Angeklagten haben es nicht gewagt, nach Belgien zu kommen.
<G-vec01061-002-s065><dare.wagen><en> However, to refresh these classics, I dare marriage of fruit and spice plants, some of my preparations.
<G-vec01061-002-s065><dare.wagen><de> Um jedoch diese Klassiker zu erneuern, habe ich es gewagt, Früchte und Gewürzpflanzen in einigen meiner Zubereitungen zu vermischen.
<G-vec01061-002-s066><dare.wagen><en> 10) Antin´s impersonation, if that is the correct word, of a woman of color who is also a ballerina who is also an expatriate is one of the few works I am aware of besides Cindy Sherman in her Bus Riders series to have dare to work in "black face".
<G-vec01061-002-s066><dare.wagen><de> Eine exzellente Auseinandersetzung über die Komplexität von wenn das der korrekte Ausdruck ist - einer Farbigen, die auch eine im Ausland lebende Ballerina ist, gehört meines Wissens neben Cindy Sherman Bus-Riders-Series zu den ganz wenigen Werken, die es gewagt haben, schwarz geschminkte Schauspieler auftreten zu lassen.
<G-vec01061-002-s067><dare.wagen><en> photos: Philipp Pusch If you would even dare to try to take party photos at Berghain you would probably be banned to hell or worse.
<G-vec01061-002-s067><dare.wagen><de> Falls man es auch nur wagen sollte zu versuchen im Berghain Partyfotos zu machen, würde man wahrscheinlich sofort in die Hölle verbannt werden (also ins Lab) oder Schlimmeres.
<G-vec01061-002-s068><dare.wagen><en> On the last few hundred meters to the camp, I’m even thinking if we shouldn’t dare to climb the Descabezado tomorrow.
<G-vec01061-002-s068><dare.wagen><de> Schnapsideen Auf den letzten paar hundert Metern zum Camp überlege ich sogar schon, ob wir es morgen nicht doch wagen sollten.
<G-vec01061-002-s069><dare.wagen><en> I love to jog along the Main River and if you dare, just sign up at the famous Frankfurt Rowing Club.
<G-vec01061-002-s069><dare.wagen><de> Ich laufe gerne am Main entlang und wenn Sie es wagen, melden Sie sich einfach beim berühmten Frankfurter Ruderclub an.
<G-vec01061-002-s070><dare.wagen><en> Dare to awaken your senses!
<G-vec01061-002-s070><dare.wagen><de> Es wagen, seine Sinne zu wecken.
<G-vec01061-002-s071><dare.wagen><en> This day can be a test of what Senate, Cops and Padovicz expect if they dare to evict us.
<G-vec01061-002-s071><dare.wagen><de> Dieser Tag kann ein Austesten sein, was Senat, Cops und Padovicz erwarten, wenn sie es wagen sollten uns zu räumen.
<G-vec01061-002-s072><dare.wagen><en> At that time, you must dare to choose.
<G-vec01061-002-s072><dare.wagen><de> Zu diesem Zeitpunkt müssen Sie es wagen zu wählen.
<G-vec01061-002-s073><dare.wagen><en> Only those who dare to let go of the human mindset and attachments can become true cultivators.
<G-vec01061-002-s073><dare.wagen><de> Nur jene, die es wagen menschliche Gesinnungen und Eigensinne abzulegen, können wahre Kultivierende werden.
<G-vec01061-002-s074><dare.wagen><en> He is ready to fight all enemies who dare approach him and to defend his king and his chivalrous ideals against all-comers.
<G-vec01061-002-s074><dare.wagen><de> Er ist bereit, alle Feinde zu schlagen, die es wagen, ihm zu nahe zu kommen, und seinen König und seine ritterlichen Vorstellungen gegen jeden Widerstand zu verteidigen.
<G-vec01061-002-s075><dare.wagen><en> Let’s struggle to be the kind of people who dare to give the same confession of our beliefs.
<G-vec01061-002-s075><dare.wagen><de> Lassen Sie uns darum kämpfen, solche Menschen zu sein, die es wagen, zu unserem Glauben dasselbe Bekenntnis zu machen.
<G-vec01061-002-s076><dare.wagen><en> "Everyone who wants to speak to the Drunlord has a matter of utmost urgency, else he wouldn't dare to demand audience with the Drunlord.
<G-vec01061-002-s076><dare.wagen><de> "Jeder, der mit dem Drunfürsten sprechen will, hat eine dringende Angelegenheit, sonst würde er es nicht wagen, mit dem Drunfürsten sprechen zu wollen.
<G-vec01061-002-s077><dare.wagen><en> If you dare, try to do it in your kitchen.
<G-vec01061-002-s077><dare.wagen><de> Wenn Sie es wagen, versuchen Sie es in Ihrer Küche zu tun.
<G-vec01061-002-s078><dare.wagen><en> A real luxury for those who dare to enjoy it.
<G-vec01061-002-s078><dare.wagen><de> Ein wahrer Luxus für diejenigen, die es wagen, es zu genießen.
<G-vec01061-002-s079><dare.wagen><en> I debated back and forth for a long time, if I dare to transact such an expensive purchase over the internet.
<G-vec01061-002-s079><dare.wagen><de> Ich habe lange hin und herüberlegt, ob ich es wagen kann, eine so teure Bestellung über das Internet abzuwickeln.
<G-vec01061-002-s080><dare.wagen><en> A Nightmare on Elm Street 4: The Dream Master Proving there’s no rest for the wicked, the unspeakably evil and diabolically hilarious Freddy Kruger is again resurrected from the grave to wreak havoc upon those who dare to dream.
<G-vec01061-002-s080><dare.wagen><de> A Nightmare on Elm Street 4 Der unbeschreibbar böse und teuflisch heitere Freddy Krueger ist wieder aus seinem Grab auferstanden und richtet Verheerung bei denjenigen an, die es wagen zu Träumen und beweist damit, dass das böse nicht ruht.
<G-vec01061-002-s081><dare.wagen><en> No Jew would dare to enter a shisha bar wearing a kippah.
<G-vec01061-002-s081><dare.wagen><de> Kein Jude würde es noch wagen, mit einer Kippa in eine Shisha-Bar zu gehen.
<G-vec01061-002-s082><dare.wagen><en> Otherwise, they wouldn't dare to come to your home.
<G-vec01061-002-s082><dare.wagen><de> Andernfalls würden sie es nicht wagen, in die Wohnung zu kommen.
<G-vec01061-002-s083><dare.wagen><en> Those who dare can take the opportunity to take a dip in Åsunden, you can always warm up in the sauna afterwards!
<G-vec01061-002-s083><dare.wagen><de> Diejenigen, die es wagen, können die Gelegenheit wahrnehmen ein Bad im Åsunden zu nehmen und können sich immer danach in der Sauna aufwärmen.
<G-vec01061-002-s084><dare.wagen><en> Bon appétit! Designed by Femmes design solutions for lifestyle clients that dare to take things in a new direction.
<G-vec01061-002-s084><dare.wagen><de> Régionales ist eine Kreativagentur aus Kopenhagen, die maßgeschneiderte Designlösungen für jene Lifestyle-Kunden anbietet, die es wagen, Dingen eine neue Richtung zu geben.
<G-vec01061-002-s085><dare.wagen><en> Now I could dare to try.
<G-vec01061-002-s085><dare.wagen><de> Also konnte ich es wagen.
<G-vec01061-002-s086><dare.wagen><en> I do not think you dare to publish my answers point-to-point, so I invite those who read you to read other sites.
<G-vec01061-002-s086><dare.wagen><de> Ich glaube nicht, dass du es wagst, meine Antworten Punkt-zu-Punkt zu veröffentlichen, also lade ich diejenigen, die dich lesen, dazu ein, andere Seiten zu lesen.
<G-vec01061-002-s087><dare.wagen><en> I want to know what you ache for and if you dare to dream of meeting your hearts longing.
<G-vec01061-002-s087><dare.wagen><de> Ich will wissen, wonach du dich sehnst, und ob du es wagst davon zu träumen, der Sehnsucht deines Herzens zu begegnen.
<G-vec01061-002-s088><dare.wagen><en> Before releasing her, the director from the security department of the police station, threatened her, saying: "If you dare to take part in any [Falun Gong] activity, we will send you directly to a labour camp."
<G-vec01061-002-s088><dare.wagen><de> Vor ihrer Entlassung drohte Dang Fagui, der Direktor der Sicherheitsabteilung der Polizeiwache, ihr und sagte: „Wenn du es nur wagst an einer dieser [Falun Gong] Aktivitäten teilzunehmen, schicken wir dich direkt ins Arbeitslager.“ Kurz nach ihrer Entlassung starb sie an Hepatitis.
<G-vec01061-002-s089><dare.wagen><en> and if you dare to dream of meeting your heart’s longing.
<G-vec01061-002-s089><dare.wagen><de> Und ob du es wagst, dem Verlangen deines Herzens zu begegnen.
<G-vec01061-002-s090><dare.wagen><en> Those who would dare reach the highest levels of skill can tackle Master Challenges.
<G-vec01061-002-s090><dare.wagen><de> Wer es wagt, die höchsten Fähigkeiten anzustreben, kann sich an den Meister-Herausforderungen versuchen.
<G-vec01061-002-s091><dare.wagen><en> Challenge if you dare, for we are the Blades, and we will defeat any who come to our door...
<G-vec01061-002-s091><dare.wagen><de> Fordert heraus, wenn Ihr es wagt, denn wir sind die Klingen[5] und werden jeden besiegen, der an unsere Tür kommt...
<G-vec01061-002-s092><dare.wagen><en> I was enlightened to the principle that as long as we learn to look inward, the evil will not dare to persecute us.
<G-vec01061-002-s092><dare.wagen><de> Ich erkannte dieses Prinzip, dass solange wir lernen, nach innen zu schauen, es das Böse nicht wagt, uns zu verfolgen.
<G-vec01061-002-s093><dare.wagen><en> By tolerating Israel’s nuclear arsenal while simultaneously opposing the Iranian nuclear programme, the USA and the EU must bear chief responsibility for fact that hardly any opposition politicians in Iran dare to question the nuclear policies of the Islamic Republic.
<G-vec01061-002-s093><dare.wagen><de> Mit der Tolerierung von Israels Atomwaffenarsenal bei gleichzeitiger Bekämpfung des iranischen Atomprogramms tragen USA und EU die Hauptverantwortung dafür, dass kaum ein Oppositionspolitiker im Iran es wagt, die Atompolitik der Islamischen Republik in Frage zu stellen.
<G-vec01061-002-s094><dare.wagen><en> If the German government, the Prussian ministers, allow themselves to persecute the Poles so openly, and the Hakatist scum dare to bark at us, the responsibility lies with those classes of the German people, whose applause or silence, or insincere defense of Polish identity, maintain the pressure of Germanization.
<G-vec01061-002-s094><dare.wagen><de> Wenn die deutsche Regierung, wenn die preußischen Minister es sich erlauben, die Polen so offen zu verfolgen, und das Hakatistengesindel es wagt, uns laut anzukeifen, so tragen die Verantwortung dafür gerade alle die Klassen des deutschen Volkes, die entweder durch ihren Beifall oder ihr Schweigen oder durch heuchlerische Verteidigung des Polentums nur den Druck der Germanisierung aufrechterhalten.
<G-vec01061-002-s095><dare.wagen><en> Yet, the definition of this separation can be seen as that which stands between the 'free thinking West' that enthusiastically seals its past in a black box and the 'open minded East' who dare to raise questions about the past.
<G-vec01061-002-s095><dare.wagen><de> Doch die Beschreibung dieser Trennung kann als das gesehen werden, was zwischen dem "freidenkenden Westen" steht, der mit Begeisterung seine Vergangenheit in einem schwarzen Kasten einschweißt und dem "geistig offenen" Osten, der es wagt, Fragen über die Vergangenheit aufzuwerfen.
<G-vec01061-002-s096><dare.wagen><en> The only exception to that rule is when I allow you to see your faults so you dare not lift up your head high and put down others…not even in a fleeting thought.
<G-vec01061-002-s096><dare.wagen><de> Die einzige Ausnahme zu jener Regel ist, wenn Ich zulasse, dass ihr eure Fehler seht, damit ihr es nicht wagt, euren Kopf in die Höhe zu strecken und Andere herab zu stufen… nicht einmal in einem flüchtigen Gedanken.
<G-vec01061-002-s097><dare.wagen><en> We will ask you to be a part of it, if you so dare.
<G-vec01061-002-s097><dare.wagen><de> Wir laden euch ein dran teilzunehmen, wenn ihr es wagt.
<G-vec01061-002-s098><dare.wagen><en> And now his spirit, forever unable to rest, haunts this geocache and those who dare seek it out.
<G-vec01061-002-s098><dare.wagen><de> Sein Geist, der keine Ruhe findet, bewacht nun diesen Geocache und spukt jeden, der es wagt ihn zu suchen.
<G-vec01061-002-s099><dare.wagen><en> - Unleash deadly special-action attacks and finishing sword-moves that deliver a grizzly end to any who dare to battle against you in war.
<G-vec01061-002-s099><dare.wagen><de> - Entfessle tödliche Sonderangriffe und Gnadenstöße, die jeden verfluchen, der es wagt dich im Krieg herauszufordern.
<G-vec01061-002-s100><dare.wagen><en> She was tied to a bed to be force-fed. The perpetrators were also greatly moved by her unyielding spirit and asked, " How can you, such a gentle lady, be so firm in Falun Gong and dare to recite the Fa when we force-feed you?"
<G-vec01061-002-s100><dare.wagen><de> Die Täter waren von ihrem festen Glauben betroffen und fragten: „Wie kommt es, dass so eine kleine Frau dermaßen an ihrem Glauben an Falun Gong festhält und sie es wagt, während wir sie misshandeln, das Fa auswendig zu lernen?“ Sie erklärte ihnen: „Möglicherweise ist dies die einzige Gelegenheit, sie zu treffen.
<G-vec01061-002-s101><dare.wagen><en> In a burst of inky black smoke, Sorin Markov set off to discover who would dare intrude on his plane.
<G-vec01061-002-s101><dare.wagen><de> In einer Wolke aus tintigem, schwarzem Rauch machte Sorin Markov sich auf, herauszufinden, wer es wagte, in seine Welt einzudringen.
<G-vec01061-002-s102><dare.wagen><en> Anyone who would dare to stare into her eyes now would feel that manic, strong power again.
<G-vec01061-002-s102><dare.wagen><de> Jeder, der es jetzt noch wagte, Sie anzuschauen, würde diese irre und starke Macht wieder fühlen.
<G-vec01061-002-s103><dare.wagen><en> Free to delve further into her art, Syndra now aims to grow powerful enough to destroy the weak, foolish leaders of Ionia - and anyone else who would dare to shackle her greatness.
<G-vec01061-002-s103><dare.wagen><de> Da sie sich nun eingehend mit ihrer Kunst befassen kann, hat sie es sich zum Ziel gemacht, mächtig genug zu werden, um die schwächlichen, dümmlichen Herrscher Ionias zerstören zu können – und mit ihnen jeden, der es wagte, ihre Größe in Fesseln legen zu wollen.
<G-vec01061-002-s104><dare.wagen><en> The Mummy has arisen...wakened from his centuries-long slumber, the evil Imhotep is once again freed from his wraps, unleashing his wrath on all who dare enter the sacred temple.
<G-vec01061-002-s104><dare.wagen><de> Die Mumie ist auferstanden... erwacht aus ihrem jahrhundertelangen Schlummer lässt Sie nun ihren Zorn an jedem aus, der es wagte in Ihren Tempel einzudringen.
<G-vec01061-002-s119><dare.wagen><en> ...For those who don't dare to jump, we also offer sight seeing flights.
<G-vec01061-002-s119><dare.wagen><de> ...Wem der Sprung zu gewagt ist, der kann bei uns Rundflüge buchen.
<G-vec01061-002-s120><dare.wagen><en> Without even realizing it, my fears have turned into enthusiasm: despite being insanely afraid of height, I’ve walked up and down a lot of slippery slopes, after a while, I would even dare to go to the bathroom at night, despite the fair chance that I could be awaited for a midnight snack by a Jaguar, and when I even got to see a snake, which had been my worst-case-scenario, I was more excited than scared.
<G-vec01061-002-s120><dare.wagen><de> Ohne es zu bemerken, haben sich meine Ängste dabei in Begeisterung gewandelt: trotz wahnsinniger Höhenangst, bin ich rutschige Abhänge hinauf und hinunter geklettert, habe mich irgendwann auch nachts auf Toilette gewagt und der Möglichkeit getrotzt, dass mich dort ein Jaguar zum Mitternachtssnack erwarten könnte, und als ich am vorletzten Tag doch noch eine gefürchtete Schlange erblickte, war ich sogar viel mehr erstaunt, als verängstigt.
<G-vec01061-002-s121><dare.wagen><en> The 37% share of French businesses which have already adopted or plan to adopt a “Smart Industry” roadmap must therefore set an example and support very small and small and medium-sized industrial enterprises which don’t yet dare to make the transition.
<G-vec01061-002-s121><dare.wagen><de> Die 37 % aller französischen Unternehmen, die bereits eine Roadmap zur „Industrie von morgen“ umgesetzt haben oder noch umsetzen werden, müssen bereits heute mit gutem Beispiel vorangehen und die mittelständischen Industriefirmen unterstützen, die den Schritt bisher noch nicht gewagt haben.
<G-vec01061-002-s122><dare.wagen><en> Despite this crash diet the case appears to be unimpressed by selective pressure and, according to Toshiba, is supposed to withstand a fall from 76 centimeters (~2.5 feet) without a scratch. We admittedly did not dare to put this statement to the test, but our subjective impression confirms the quality of the construction.
<G-vec01061-002-s122><dare.wagen><de> Trotz dieser Radikaldiät zeigt sich das Gehäuse unbeeindruckt von punktuellen Belastungen und soll laut Toshiba sogar einen Sturz aus 76 Zentimetern Höhe unbeschadet überstehen – dies praktisch zu überprüfen, haben wir zwar nicht gewagt, doch bestätigt unser subjektiver Eindruck die Qualität der Konstruktion.
<G-vec01061-002-s123><dare.wagen><en> Right at the beginning of the discussion, Prof. Dr. Dr. Rainer Hering talked about “mehr Archivierung wagen” (dare more archiving) following Willy Brand’s famous slogan “Mehr Demokratie wagen” (dare more democracy).
<G-vec01061-002-s123><dare.wagen><de> Bereits zu Beginn der Diskussion hatte Prof. Dr. Dr. Rainer Hering in Anlehnung an Willy Brand davon gesprochen, dass vielleicht „mehr Archivierung“ gewagt werden müsse.
<G-vec01061-002-s124><dare.wagen><en> It's only then, when you dare the first step, that the fitness evolution can start.
<G-vec01061-002-s124><dare.wagen><de> Denn nur, wenn dieser erste Schritt gewagt wird, kann die Fitness-Evolution starten.
<G-vec01061-002-s125><dare.wagen><en> At the Leipzig college, people dare to develop signatures that seem to undermine the diktat of Socialist Realism.
<G-vec01061-002-s125><dare.wagen><de> An der Leipziger Hochschule werden Handschriften gewagt, die das Diktat des sozialistischen Realismus zu unterlaufen scheinen.
<G-vec01061-002-s126><dare.wagen><en> I had thought that your hospitality had something to do with the fact that Orrin and I happen to be your superiors and you didn’t dare refuse our request on that account.
<G-vec01061-002-s126><dare.wagen><de> Ich hätte gedacht, dass deine Gastfreundschaft eher etwas mit der Tatsache zu tun hat, dass Orrin und ich zufällig deine Vorgesetzten sind und du aus diesem Grund nicht gewagt hättest, unsere Anfrage abzulehnen.
<G-vec01061-002-s127><dare.wagen><en> An open and sincere dialogue with critical factions among the various denominations is a prime necessity in creating a climate of understanding from which we may dare to take the first steps outside.
<G-vec01061-002-s127><dare.wagen><de> Erst ein offener und ernstgemeinter Dialog mit den kritischen Kräften in den Konfessionen kann ein Klima der Verständigung schaffen, aus dem heraus auch der Schritt nach außen gewagt werden kann.
<G-vec01061-002-s187><dare.wagen><en> The fast fashion shorts are the essential garment to face those embarrassing summer days or to dare during the seasons with cooler weather.
<G-vec01061-002-s187><dare.wagen><de> Die Pronto Moda Shorts sind das unentbehrliche Kleidungsstück, um sich den heißen Sommertagen zu stellen oder sich bei kühlem Wetter zu den Jahreszeiten zu wagen.
<G-vec01061-002-s188><dare.wagen><en> Will you dare to walk across the famous suspension bridge, the longest in the world, or get a squirrel's eye view of the vast rain forest by crossing from one viewing platform to another along small suspension bridges up in the treetops, or follow the granite precipice of Capilano Canyon on a 50-cm-wide, labyrinthine path called the Cliffwalk?
<G-vec01061-002-s188><dare.wagen><de> Ein Ausflug zum Capilano Suspension Bridge Park ist ein Erlebnis: Man kann sich entweder über die berühmte sowie weltweit längste und höchste Hängebrücke wagen oder hoch oben in den Baumwipfeln (Treetops Adventures) über kleine Hängebrücken von Plattform zu Plattform laufen.
<G-vec01061-002-s189><dare.wagen><en> If you dare to dive into the network of the historical streets and alleys of the old center you will be amazed.
<G-vec01061-002-s189><dare.wagen><de> Wenn Sie sich ins Netzwerk der historischen Straßen des alten Zentrums wagen, werden Sie staunen.
<G-vec01061-002-s190><dare.wagen><en> People who dare to venture into new territory and who will be the first to test our breakthrough pump innovation: the Wilo-Stratos MAXO.
<G-vec01061-002-s190><dare.wagen><de> Menschen, die sich mit uns auf Neuland wagen und unsere bahnbrechende Pumpen-Innovation als erste in der Praxis testen: die Wilo-Stratos MAXO.
<G-vec01061-002-s191><dare.wagen><en> The musicians and amateurs who dare to stand before this star, this extraordinary demon, with their empty phrases, have not even honor enough to thank him for providing them the occasion for phrases that they certainly would never be able to dream up in such abundance about Haydn's forerunners and contemporaries.
<G-vec01061-002-s191><dare.wagen><de> Die Musiker u. Laien, die sich mit ihrem Phrasenschwinden vor diese Sonne, diesen unheimlichen Dämon zu stellen wagen, haben nicht einmal so viel Anstand, ihm dafür zu danken, daß er ihnen Gelegenheit zu den Phrasen schenkt, die sie sich in solcher Fülle von Haydn's Vorgängern oder Zeitgenossen gewiß nicht holen könnten.
<G-vec01061-002-s192><dare.wagen><en> With him, he was able to dare major projects and develop his designer skills.
<G-vec01061-002-s192><dare.wagen><de> Bei ihm konnte er sich an bedeutende Großprojekte wagen und seine designerischen Fähigkeiten weiterentwickeln.
<G-vec01061-002-s193><dare.wagen><en> Once you've found the appropriate rental skis, you can belt on the "boards" and dare down the slopes.
<G-vec01061-002-s193><dare.wagen><de> Wenn Sie die passenden Leihskier schon gefunden haben, können Sie sich die „Bretter“ gleich anschnallen und sich die Pisten hinunter wagen.
<G-vec01061-002-s194><dare.wagen><en> There is another interesting way of how to teach a child to crawl - to show him a personal example (especially this option works with those children who have long learned to stand on all fours, but do not dare to move forward).
<G-vec01061-002-s194><dare.wagen><de> Es gibt eine andere interessante Art und Weise, wie man einem Kind das Krabbeln beibringen kann - um ihm ein persönliches Beispiel zu zeigen (insbesondere diese Option funktioniert bei Kindern, die längst gelernt haben, auf allen vieren zu stehen, sich aber nicht zu bewegen wagen).
<G-vec01061-002-s195><dare.wagen><en> The building consists of a lot of glass and a transparent platform that "lets" everyone in the air, who is courageous enough to dare.
<G-vec01061-002-s195><dare.wagen><de> Das Gebäude besteht aus viel Glas und einer durchsichtigen Plattform, die jeden in der Luft "schweben" lässt, der mutig genug ist um sich auf sie zu wagen.
<G-vec01061-002-s196><dare.wagen><en> Besides the darkness, many fierce winter storms make you re-consider at least three times whether you really want to dare going out to the university.
<G-vec01061-002-s196><dare.wagen><de> Dazu kommen die starken Winterstürme, die über die Stadt fegen und bei denen man sich dreimal überlegt, ob man den Weg zur Uni wagen soll.
<G-vec01061-002-s197><dare.wagen><en> “They are persistent enough to dare even the seemingly unplayable.
<G-vec01061-002-s197><dare.wagen><de> „Sie sind hartnäckig genug, sich auch an scheinbar Unspielbares zu wagen.
<G-vec01061-002-s256><dare.wagen><en> But (this much I dare to say already) U2’s new album carries its predecessor’s crown proudly.
<G-vec01061-002-s256><dare.wagen><de> Aber – das wage ich auch nach dem zweimaligen Hören zu sagen – diese Platte wird diesem Anspruch gerecht.
<G-vec01061-002-s257><dare.wagen><en> I don’t even dare to dream about any satiety.
<G-vec01061-002-s257><dare.wagen><de> Vom Sättigungsgefühl wage ich im Getto nicht einmal zu träumen.
<G-vec01061-002-s258><dare.wagen><en> I dare to say you haven't read a single Falun Gong book.
<G-vec01061-002-s258><dare.wagen><de> Ich wage zu sagen, dass Sie kein einziges Falun Gong-Buch gelesen haben.
<G-vec01061-002-s259><dare.wagen><en> As told before, I will now dare the mission to unite the football jerseys from every national team around the world in one collection.
<G-vec01061-002-s259><dare.wagen><de> Wie bereits angekündigt wage nun auch ich die Mission, die Fußballtrikots aller Nationalmannschaften dieser Erde in einer Sammlung zu vereinen.
<G-vec01061-002-s260><dare.wagen><en> "I dare say my wrongs are the talk of the county.
<G-vec01061-002-s260><dare.wagen><de> »Ich wage zu behaupten, dass jeder in dieser Gegend von dem Unrecht spricht, dass mir widerfährt.
<G-vec01061-002-s261><dare.wagen><en> Dare to be totally yourself knowing all that you are.
<G-vec01061-002-s261><dare.wagen><de> Wage ganz Dich selbst zu sein, indem Du alles kennst, was Du bist.
<G-vec01061-002-s262><dare.wagen><en> My son, do not dare to say a word about this One, and do not confine the God of all to mental images.
<G-vec01061-002-s262><dare.wagen><de> Mein Sohn, wage nicht ein Wort über Diesen zu sagen, und begrenze den Gott von allem nicht auf seelische Bilder.
<G-vec01061-002-s263><dare.wagen><en> Never dare you on slippery soil, then you will not fall down.
<G-vec01061-002-s263><dare.wagen><de> Wage dich nie auf schlüpfrigen Boden, dann wirst du nicht hinfallen.
<G-vec01061-002-s264><dare.wagen><en> I dare not say that I tried the best chocolate in the world here, but it is certainly one of the best.
<G-vec01061-002-s264><dare.wagen><de> Ich wage nicht sagen, dass ich versuchte die beste Schokolade in der Welt, aber es ist sicherlich eines der besten.
<G-vec01061-002-s265><dare.wagen><en> Of course, I don't dare to slack off in doing the three things either.
<G-vec01061-002-s265><dare.wagen><de> Natürlich wage ich auch nicht, beim Tun der Drei Dinge nachzulassen.
<G-vec01061-002-s266><dare.wagen><en> Let what‘s in front of your very own eyes seduce you, and dare to navigate the side streets of the Ku’damm without social media recommendations to guide your way.
<G-vec01061-002-s266><dare.wagen><de> Das analoge Abenteuer: Man lasse sich von seinen ganz persönlichen visuellen Eindrücken verführen und wage das Navigieren durch die Seitenstraßen des Ku‘damms, ohne dabei Social-Media-Empfehlungen zu folgen.
<G-vec01061-002-s267><dare.wagen><en> And yet, dare we say it.
<G-vec01061-002-s267><dare.wagen><de> Und dennoch sagen wir, wage es.
<G-vec01061-002-s268><dare.wagen><en> As far as I'm concerned... Ronnie breaks through open doors with it - because I KNOW that he's good, and I dare to predict that he'll gain a lot of new fans with this album, since it's very hard to escape the magic of MAGICA.
<G-vec01061-002-s268><dare.wagen><de> Soweit es mich betrifft... rennt Ronnie mit MAGICA nur offenen Türen ein, - denn ich WEISS, daß er gut ist, und ich wage zu prophezeien, daß er mit diesem Album sicher eine Menge neuer Fans für sich gewinnen wird, ist es doch nur schwer möglich, sich dem Zauber von MAGICA zu verschließen.
<G-vec01061-002-s269><dare.wagen><en> I dare to say that in a way, Tchaikovsky experienced his own death through the music.
<G-vec01061-002-s269><dare.wagen><de> Ich wage zu behaupten, dass Tschaikowsky seinen eigenen Tod durch die Musik erfahren hat.
<G-vec01061-002-s270><dare.wagen><en> It is true that the list is not complete, but I dare to believe that you will improve it.
<G-vec01061-002-s270><dare.wagen><de> Es ist wahr, dass die Liste nicht vollständig ist, aber ich wage zu glauben, dass Sie es verbessern werden.
<G-vec01061-002-s271><dare.wagen><en> I don't dare to say what my future flavour will be but I believe my work will arouse people's spiritual resonance and a kind of spiritual enjoyment at the same time.
<G-vec01061-002-s271><dare.wagen><de> Ich wage nicht, zu sagen, was mein zukünftiges Aroma sein wird, aber ich glaube, dass meine Arbeit einen sinnlichen Widerhall sowie eine Art Sinnesfreude bei den Menschen erwecken wird.
<G-vec01061-002-s272><dare.wagen><en> Please enable The task you would like me to fulfill is so difficult that I do not dare to refuse.
<G-vec01061-002-s272><dare.wagen><de> Die Aufgabe, die Sie mir übertragen wollen, ist so schwierig, daß ich nicht wage, sie abzulehnen.
<G-vec01061-002-s273><dare.wagen><en> I dare to write this last sentence because it is taken from a letter from the desert.
<G-vec01061-002-s273><dare.wagen><de> Diesen letzten Satz wage ich zu schreiben, weil er einem Briefe aus der Wüste entnommen ist.
<G-vec01061-002-s274><dare.wagen><en> Big cars often drive fast over the rocks, but I do not dare to do that, because the road is not only rocky, but also uneven and bumpy at lower frequencies.
<G-vec01061-002-s274><dare.wagen><de> Große Autos fahren oft schnell über die Steine, aber ich wage nicht, das zu tun, weil der Weg nicht nur steinig ist, sondern auch niederfrequent uneben.
<G-vec01061-002-s275><dare.wagen><en> I dare to say that this is the best decision I have ever made and will make in my life.
<G-vec01061-002-s275><dare.wagen><de> Ich wage es zu sagen, dass es die beste Entscheidung ist, die ich jemals getroffen habe und treffen werde.
<G-vec01061-002-s276><dare.wagen><en> One of the most beautiful members of the genus – Anyway, I dare to say from the whole lake, too – is X. papilio from Tembwe area.
<G-vec01061-002-s276><dare.wagen><de> Einer der schönsten Vertreter der Gattung, und ich wage es zu behaupten auch aus dem ganzen See ist X. papilio von dem Gebiet Tembwe.
<G-vec01061-002-s277><dare.wagen><en> I don’t dare to listen to any other messages, so I’m not going to let you in.
<G-vec01061-002-s277><dare.wagen><de> Ich wage es nicht, mir andere Botschaften anzuhören, deswegen werde ich dich nicht hereinlassen.
<G-vec01061-002-s278><dare.wagen><en> The best thing you can do is swallow the little stones, and do not dare to make a face, slave contender.
<G-vec01061-002-s278><dare.wagen><de> Die kleinen Steinchen schluckst du am besten auch, und wage es nicht, dabei die Miene zu verziehen, Sklavenanwärter.
<G-vec01061-002-s279><dare.wagen><en> Upon feeling an affirmative response I now dare to step into the position of the Creator.
<G-vec01061-002-s279><dare.wagen><de> So wage ich es, in die Position des Schöpfers zu gehen, indem ich mich über den Schöpferstein stelle.
<G-vec01061-002-s280><dare.wagen><en> They can say “don’t even dare to look in my direction again”, a “I am ready for summer and my inner sun is always shining”, a simple ” just in case you don’t know I am a true New Yorker”, or a ” I am cool, I don’t care if you think I am weird.” and of course the “Yes, I had an amazing night yesterday and today my face looks like I’ve been hit by a truck, but it was worth it”.
<G-vec01061-002-s280><dare.wagen><de> Sie können sagen: ” Wage es nicht nochmal in meine Richtung zu schauen”, oder “Ich bin sowas von bereit für den Sommer,mir ist egal ob die Sonne scheint, für mich ist jetzt Sommer”, aber auch “hey, falls noch nicht klar war, dass ich ein echter New Yorker bin, dürfe es ja jetzt klar geworden sein”, vielleicht auch “Ich bin cool und es ist mir scheißegal ob du denkst ich bin bekloppt”, und natürlich das klassische “Jap, gestern Nacht war super und deswegen sieht mein Gesicht nach dem einer Schnapsleiche aus, aber es hat sich gelohnt!”.
<G-vec01061-002-s281><dare.wagen><en> Dare to be more, because who you are is more important than any possession.
<G-vec01061-002-s281><dare.wagen><de> Wage es, mehr zu sein, denn dein Sein zählt mehr als alles andere.
<G-vec01061-002-s282><dare.wagen><en> After all, it was namely H. MARCUSE who socio-prophylactically excommunicated each leftist already in 1968, in case he would dare to resist to an improvement of the public health system.
<G-vec01061-002-s282><dare.wagen><de> Hat doch H. MARCUSE jeden Linken schon 1968 sozialprophylaktisch unter Acht und Bann gestellt, für den Fall, er wage es, sich einer Verbesserung des Gesundheitswesens zu widersetzen.
<G-vec01061-002-s283><dare.wagen><en> This is no more than a hunch though; I dare not try it out.
<G-vec01061-002-s283><dare.wagen><de> Aber das ist nicht mehr als ein Gefühl, ich wage es nicht auszuprobieren.
<G-vec01061-002-s284><dare.wagen><en> Hahnemann said ‘Aude sapere (Dare to know)’.
<G-vec01061-002-s284><dare.wagen><de> Hahnemann sagte: „Aude sapere (Wage es, zu wissen)“.
<G-vec01061-002-s285><dare.wagen><en> Therefore, I dare to sort out and supplement the contents of the text, but almost all the finer words and deeper meanings I wrote the way I heard them before.
<G-vec01061-002-s285><dare.wagen><de> Deshalb wage ich es, die Inhalte des Texts auszusortieren und zu ergänzen, fast all die feinsinnigen Worte und tieferen Bedeutungen habe ich jedoch so niedergeschrieben wie ich sie zuvor gehört habe.
<G-vec01061-002-s286><dare.wagen><en> Dare for a moment to stop the course you have taken in your life and look at your reality.
<G-vec01061-002-s286><dare.wagen><de> Wage es für einen Augenblick, den Kurs zu stoppen, den du in deinem Leben eingeschlagen hast, und schau dir deine Wirklichkeit an.
<G-vec01061-002-s287><dare.wagen><en> I dare say, WordPress has so much more to offer than others.
<G-vec01061-002-s287><dare.wagen><de> Ich wage zu behaupten, hat WordPress so viel mehr zu bieten als andere.
<G-vec01061-002-s288><dare.wagen><en> Whether that makes the subject any clearer I dare doubt.
<G-vec01061-002-s288><dare.wagen><de> Ob dies den ganzen Sachverhalt allerdings klarer macht, wage ich zu bezweifeln.
<G-vec01061-002-s289><dare.wagen><en> It's different than usual, and I dare say that in Europe we are the only one with this great collection of game titles and official licensed merchandise.
<G-vec01061-002-s289><dare.wagen><de> Es ist anders als sonst, und ich wage zu sagen, dass wir in Europa der einzige mit dieser großen Sammlung von Spieletitel und offizielle Lizenzprodukte sind.
<G-vec01061-002-s290><dare.wagen><en> She has worked as a diplomat, a courier, and—dare I say it—a spy.
<G-vec01061-002-s290><dare.wagen><de> Sie hat als Diplomatin, Kurierin und – so wage ich es, zu sagen – Spionin gedient.
<G-vec01061-002-s291><dare.wagen><en> In general, Czech society, and I dare say societies in many other so-called post-communist countries, do not by and large feel that it is integrated into a European society of citizens.
<G-vec01061-002-s291><dare.wagen><de> Im Allgemeinen empfindet sich die tschechische Gesellschaft – und ich wage zu behaupten, dass dieser Befund auch auf viele andere sogenannte postkommunistische Länder zutrifft – als kein besonders gut integrierter Teil der europäischen BürgerInnengemeinschaft.
<G-vec01061-002-s292><dare.wagen><en> You can also try the new-age (dare I say, disruptive) popups – welcome page ads.
<G-vec01061-002-s292><dare.wagen><de> Du kannst auch die New-Age (ich wage zu sagen, störenden) Pop-ups – Begrüßungsanzeigen – ausprobieren.
<G-vec01061-002-s293><dare.wagen><en> Building a website using a professional web builder can be easy and dare I say it, fun.
<G-vec01061-002-s293><dare.wagen><de> Das Erstellen einer Webseite mit einem professionellen Webseiten-Baukasten kann einfach sein und ich wage es zu sagen, Spaß machen.
<G-vec01061-002-s294><dare.wagen><en> In fact, without having made any serious study, I dare say the same of gallstones and cholecystectomy (gallbladder removal).
<G-vec01061-002-s294><dare.wagen><de> In der Tat, ohne selbst eine seriöse Studie, wage ich zu sagen das gleiche von Gallensteinen und Gallenblase (Entfernung der Gallenblase).
<G-vec01061-002-s295><dare.wagen><en> With this bribery comes “heroic feats” that Maniac has to complete, including a dare to go to the East End.
<G-vec01061-002-s295><dare.wagen><de> Mit dieser Bestechung kommt "heroische Kunststücke", die Maniac zu vervollständigen hat, darunter auch ein Wagen, nach Osten zu gehen.
<G-vec01061-002-s296><dare.wagen><en> But together, we can dare to embark on a new future.
<G-vec01061-002-s296><dare.wagen><de> Aber gemeinsam können wir den Start in eine neue Zukunft wagen.
<G-vec01061-002-s297><dare.wagen><en> With Schnuffelienchen, the first singing bunny, joins a long time again a female among the many colleagues who dare to step into a music career.
<G-vec01061-002-s297><dare.wagen><de> Mit Schnuffelienchen, dem ersten singenden Haschen, gesellt sich seit langem mal wieder ein weibliches Wesen unter den zahlreichen Kollegen, die den Schritt in eine Musikkarriere wagen.
<G-vec01061-002-s298><dare.wagen><en> This party could vote against the Act, and had to do so for fundamental reasons of principle, but in light of the mood of the people it did not dare to thwart the bill's being passed into law simply by absenting itself from the debate, as it might have done and which would have been much easier.
<G-vec01061-002-s298><dare.wagen><de> Sie konnte wohl und musste aus grundsätzlichen Erwägungen dagegen stimmen, durfte es aber im Hinblick auf die Stimmung des Volkes nicht wagen, das Zustandekommen des Gesetzes durch das einfachere Mittel des Fernbleibens von der Sitzung zu verhindern.
<G-vec01061-002-s299><dare.wagen><en> Description: She is brutal and logical, has fantastically formed, big tits and owns a verbal eroticism with which it nearly nobody would dare to contradict: CARMEN RIVERA.
<G-vec01061-002-s299><dare.wagen><de> Der Schwarze Dorn - Zuchtigung Auf Dem Gutshof Sie ist knallhart und konsequent, hat fantastisch geformte, groe Titten und besitzt eine Verbalerotik, bei der es nahezu niemand wagen wrde, zu widersprechen: CARMEN RIVERA.
<G-vec01061-002-s300><dare.wagen><en> Previously they want to do nothing, not dare to take a single step.
<G-vec01061-002-s300><dare.wagen><de> Vorher wollen sie nichts tun, keinen einzigen Schritt wagen.
<G-vec01061-002-s301><dare.wagen><en> In the UFOPLAN project "Dare to Transform", the FFU works together with Politics for Tomorrow and other partners to develop an education program as a learning and transformation laboratory for strengthening competences needed to shape a sustainable future.
<G-vec01061-002-s301><dare.wagen><de> Im UFOPLAN-Projekt „Transformationen wagen“ erarbeitet das FFU gemeinsam mit Politics for Tomorrow und weiteren Partnern wissenschaftlich fundiert und gemeinsam mit Praxispartner/innen ein Weiterbildungsprogramm als Lern- und Transformationslabor, das Mitarbeitene in ihren Organisationen stärkt, Wandelprozesse in Richtung Nachhaltigkeit zu gestalten.
<G-vec01061-002-s302><dare.wagen><en> Hamburg was the first German city to decide to comprehensively come to terms with its “colonial heritage”, and to dare a new start in “German commemorative culture”.
<G-vec01061-002-s302><dare.wagen><de> Hamburg hat als erste deutsche Großstadt beschlossen, das »koloniale Erbe« umfassend aufzuarbeiten und einen Neustart in der »deutschen Erinnerungskultur« zu wagen.
<G-vec01061-002-s303><dare.wagen><en> People dare to commit any evil. They think that nobody sees them, and so they do bad things.
<G-vec01061-002-s303><dare.wagen><de> Die Menschen wagen dann, alles Schlechte zu tun, sie glauben, dass niemand das sehen kann, und dann tun sie Schlechtes.
<G-vec01061-002-s304><dare.wagen><en> Sport fanatics don’t even dare to think of conventional ice creams as part of their strict nutritional plan.
<G-vec01061-002-s304><dare.wagen><de> Sportfanatiker müssen nicht einmal auch nur zu denken wagen konventionelles Eis als ein Teil ihres strikten Ernährungsplans aufzunehmen.
<G-vec01061-002-s305><dare.wagen><en> We dream, we dare and we strive to create an effortless and joyful digital life for everyone.
<G-vec01061-002-s305><dare.wagen><de> Wir träumen, wagen, und wir bemühen uns, ein müheloses und freudiges digitales Leben für jedermann zu schaffen.
<G-vec01061-002-s306><dare.wagen><en> 7For scarcely for [the] just [man] will one die, for perhaps for [the] good [man] some one might also dare to die;
<G-vec01061-002-s306><dare.wagen><de> 7 Denn kaum wird jemand für einen Gerechten sterben; denn für den Gütigen möchte vielleicht jemand auch zu sterben wagen.
<G-vec01061-002-s307><dare.wagen><en> These are evidence to suggest there is an interest from many sides to include the stamp in research and teaching, to dare to look through this “window into history”, as Gautschi aptly writes.
<G-vec01061-002-s307><dare.wagen><de> Es scheint also von mancherlei Seite das Interesse zu bestehen, die Briefmarke in Forschung und Unterricht miteinzubeziehen, den Ausblick durch dieses “Fenster in die Geschichte”, wie Gautschi treffend schreibt, zu wagen.
<G-vec01061-002-s308><dare.wagen><en> It is up to you to dare a new beginning.
<G-vec01061-002-s308><dare.wagen><de> Es liegt an dir einen Anfang zu wagen.
<G-vec01061-002-s309><dare.wagen><en> Thinking that Master would want me to save people and the captain would not dare to interrupt me, I smiled and said to the inmates, “I truly speak for your good.
<G-vec01061-002-s309><dare.wagen><de> Bei dem Gedanken, dass der Meister möchte, dass ich Menschen errette und die Kapitänin nicht wagen würde, mich zu unterbrechen, lächelte ich und sagte zu ihnen: „Was ich sage, ist wirklich zu eurem Besten.
<G-vec01061-002-s310><dare.wagen><en> Beginners can take their first steps directly in front of the door, advanced learners can dare themselves onto the Rittisberg or go by bus to one of the skiing regions in the surrounding area.
<G-vec01061-002-s310><dare.wagen><de> Anfänger können die ersten Rutschversuche direkt vor der Haustüre tätigen, Fortgeschrittene wagen sich auf den Rittisberg oder lassen sich mit dem Skibus auf die großen Skiberge der Region bringen.
<G-vec01061-002-s311><dare.wagen><en> The idea that the Egyptians would dare to attack the invincible Israeli army seemed ridiculous.
<G-vec01061-002-s311><dare.wagen><de> Der Gedanke, dass die Ägypter die unbesiegbare israelische Armee anzugreifen wagen würden, erschien lächerlich.
<G-vec01061-002-s312><dare.wagen><en> And people allow themselves to be captivated by it, they make every effort to comply with the demands and dare not change old traditions and customs which are, however, of no benefit whatsoever for the development of their souls.
<G-vec01061-002-s312><dare.wagen><de> Und die Menschen lassen sich davon gefangennehmen, sie sind eifrig bemüht, den Anforderungen nachzukommen, und wagen nicht, an alten Überlieferungen oder traditionsmäßig übernommenen Sitten und Gebräuchen zu rütteln, die aber ihren Seelen nicht den geringsten Fortschritt eintragen.
<G-vec01061-002-s313><dare.wagen><en> For their part, the Republicans dare not appease white voters in a similar way because the Civil Rights legacy is so
<G-vec01061-002-s313><dare.wagen><de> Für ihren Teil, die Republikaner wagen nicht, weiße Wähler in ähnlicher Weise zu beruhigen, weil das Bürgerrecht-Erbe so stark ist.
<G-vec01061-002-s314><dare.wagen><en> Built by a mad baron to bring notoriety to his town, only the brave or foolish would dare to enter Deathtrap Dungeon.
<G-vec01061-002-s314><dare.wagen><de> Von einem verrückten Baron gebaut, um seiner Stadt einen schlechten Ruf zu bringen, wagen es nur die Mutigen oder Dummen, Deathtrap Dungeon zu betreten.
<G-vec01061-002-s315><dare.wagen><en> Usually young mothers do not dare to perform the exercises immediately after birth, for fear of harming their body, which has not yet recovered after the baby has been born and born.
<G-vec01061-002-s315><dare.wagen><de> Gewöhnlich wagen es junge Mütter nicht, die Übungen unmittelbar nach der Geburt auszuführen, aus Angst, ihren Körper zu schädigen, der sich nach der Geburt und Geburt des Babys noch nicht erholt hat.
<G-vec01061-002-s316><dare.wagen><en> We dare not reject this one-and-only Way of salvation (John 14:6).
<G-vec01061-002-s316><dare.wagen><de> Wir wagen es nicht, den einen und einzigen Weg zur Erlösung und Rettung abzulehnen (Johannes 14,6).
<G-vec01061-002-s317><dare.wagen><en> Divided there is little we can do--for we dare not meet a powerful challenge at odds and split asunder.
<G-vec01061-002-s317><dare.wagen><de> Geteilt gibt es wenig, was wir tun können, denn wir wagen es nicht, uns einer gewaltigen Herausforderung zu stellen.
<G-vec01061-002-s318><dare.wagen><en> However, if we then look at the physical characteristics of women, we dare to make sure that most ladies benefit from training their main muscle groups three times a week.
<G-vec01061-002-s318><dare.wagen><de> Wenn wir uns dann jedoch die körperlichen Eigenschaften von Frauen ansehen, wagen wir es sicherzustellen, dass die meisten Frauen dreimal pro Woche von einem Training ihrer Hauptmuskelgruppen profitieren.
<G-vec01061-002-s319><dare.wagen><en> Many people dare not openly talk about your needs, desires and preferences.
<G-vec01061-002-s319><dare.wagen><de> Viele Menschen wagen es nicht offen über Ihre Bedürfnisse, Wünsche und Vorlieben zu sprechen.
<G-vec01061-002-s320><dare.wagen><en> The Neo-Nazis and their milieu dare to behave so brazenly only because the government and the security services fully support them.
<G-vec01061-002-s320><dare.wagen><de> Die Neonazis und ihre Mitläufer wagen es nur deshalb so unverschämt aufzutreten, weil die Regierung und die Sicherheitskräfte voll hinter ihnen stehen.
<G-vec01061-002-s321><dare.wagen><en> The town was never safer; criminals don't dare to break the law under my watch.
<G-vec01061-002-s321><dare.wagen><de> Fisgael war nie sicherer; Verbrecher wagen es gar nicht, das Gesetz unter meiner Aufsicht zu brechen.
<G-vec01061-002-s322><dare.wagen><en> Dare to explicitly chat with them or with them to find out more about their passions or just have a casual conversation in Indonesian.
<G-vec01061-002-s322><dare.wagen><de> Wagen Sie es, mit ihnen explizit zu chatten oder mit ihnen zu flirten, um mehr über ihre Leidenschaften zu erfahren, oder führen Sie einfach eine zufällige Konversation in Indonesisch.
<G-vec01061-002-s323><dare.wagen><en> Dare to know me and live with me passionate and morbid moments.
<G-vec01061-002-s323><dare.wagen><de> Wagen Sie es, mich zu kennen und mit mir leidenschaftliche und krankhafte Momente zu leben.
<G-vec01061-002-s324><dare.wagen><en> Bear orators speak of Brun's exile, but few dare acknowledge the titan the Clan's betrayal produced. $6.99
<G-vec01061-002-s324><dare.wagen><de> Bären-Redner sprechen von Bruns Verbannung, aber nur wenige wagen es, den Titanen anzuerkennen, den der Betrug des Klans hervorgebracht hat.
<G-vec01061-002-s325><dare.wagen><en> Few would dare explore these distant and dangerous places; fewer still would expect to return.
<G-vec01061-002-s325><dare.wagen><de> Nur Wenige wagen es, diese entfernten und gefahrenvollen Orte zu erforschen.
<G-vec01061-002-s326><dare.wagen><en> Dare to explicitly chat with them or with them to find out more about their passions or just have a casual conversation in Portuguese.
<G-vec01061-002-s326><dare.wagen><de> Wagen Sie es, mit ihnen explizit zu chatten oder mit ihnen zu flirten, um mehr über ihre Leidenschaften zu erfahren, oder führen Sie einfach eine zufällige Konversation in Portugiesisch.
<G-vec01061-002-s327><dare.wagen><en> Hooded seals, who hold the suckling record, but also the grey seals who give birth on land do not dare to go into water when they have pups and the mother gives the pup everything it can.
<G-vec01061-002-s327><dare.wagen><de> Mützenrobben, die den Säugerekord halten, aber auch die Kegelrobben, die an Land gebären, wagen es nicht ins Wasser zu gehen, wenn sie Junge haben und die Mütter geben den Jungen alles was sie geben können.
<G-vec01061-002-s328><dare.wagen><en> Learning how much a store wigwam costs, many parents do not dare to overpay for lightweight construction and create it themselves.
<G-vec01061-002-s328><dare.wagen><de> Wenn man erfährt, wie teuer ein Ladenwigwam ist, wagen es viele Eltern nicht, für Leichtbau zu viel zu bezahlen und sie selbst zu schaffen.
<G-vec01061-002-s329><dare.wagen><en> If it’s appropriate, dare to be different with a video slideshow cover letter.
<G-vec01061-002-s329><dare.wagen><de> Wenn es angemessen ist, wagen Sie es, mit einem Begleitschreiben mit Videoslideshow anders zu sein.
<G-vec01061-002-s330><dare.wagen><en> But still, in the end, few dare to follow the story-teller on his journey.
<G-vec01061-002-s330><dare.wagen><de> Und doch: Am Ende wagen es nur wenige, dem Erzähler auf seiner Wanderung zu folgen.
<G-vec01061-002-s331><dare.wagen><en> We are happy to share our knowledge about Leuven, reflect on the most famous buildings and squares, but also dare to depart from the beaten track.
<G-vec01061-002-s331><dare.wagen><de> Wir teilen gerne unser Wissen über Leuven, reflektieren die berühmtesten Gebäude und Plätze und wagen es auch, von den ausgetretenen Pfaden abzuweichen.
<G-vec01061-002-s332><dare.wagen><en> Others hardly dare to use their special abilities, because they were unbearably tortured for using them in former lives and now they are living their recent lives unknowingly of those past ones.
<G-vec01061-002-s332><dare.wagen><de> Andere wagen es kaum ihre speziellen Kräfte zu benutzen, weil sie dafür in früheren Leben mal unerträglich gefoltert wurden und sie leben in einem unbewussten Leben so vor sich hin ohne über die Vergangenheit etwas zu wissen.
<G-vec01061-002-s333><dare.wagen><en> Hundred thousands of tourists travel the south coast of France between Menton and Saint-Tropez; but only a few dare to continue to the west.
<G-vec01061-002-s333><dare.wagen><de> Hunderttausende von Touristen fahren Frankreichs Südküste zwischen Menton und Saint-Tropez ab; aber weiter nach Westen wagen sich nur wenige.
<G-vec01061-002-s334><dare.wagen><en> We dare to take a look at the future and give tips on differentiation.
<G-vec01061-002-s334><dare.wagen><de> Wir wagen einen Ausblick und geben Tipps, wie sich Kanzleien geschickt durch die Revolution bewegen können.
<G-vec01061-002-s335><dare.wagen><en> Dare to enter the mysterious, exhilarating Jurassic World slot experience.
<G-vec01061-002-s335><dare.wagen><de> Wagen Sie sich, das mysteriöse, aufregende Slotspiel "Jurassic World" zu probieren.
<G-vec01061-002-s336><dare.wagen><en> So Christians, even when they do not see how unbaptised children can be saved, nevertheless dare to hope that God will embrace them in his saving mercy.
<G-vec01061-002-s336><dare.wagen><de> So wagen Christen, selbst wenn sie nicht zu sehen vermögen, wie ungetaufte Kinder gerettet werden können, dennoch zu hoffen, dass Gott diese Kinder in seinem rettenden Erbarmen an sich ziehen wird.
<G-vec01061-002-s337><dare.wagen><en> We even dare say it is the best multi-purpose clip in the world.
<G-vec01061-002-s337><dare.wagen><de> Wir wagen sogar zu behaupten, dass es sich um die beste Mehrzweckklemme der Welt handelt.
<G-vec01061-002-s338><dare.wagen><en> Hotel Mountain bike special Trend sport on two wheels: Conquer the most beautiful bike trails in the Ahrn Valley with local guides, dare to enter the high-wire gardens and profit from the generous discounts provided…
<G-vec01061-002-s338><dare.wagen><de> Jetzt Pauschale für Familien, die mehr erleben wollen: Entdecken Sie die ganze Erlebnisfülle des Südtiroler Ahrntals und genießen Sie abwechslungsreiche Tage mit Ihren Liebsten auf zwei Rädern: Erobern Sie die schönsten Biketrails des Ahrntals mit ortskundigen Guides, wagen Sie sich in den Hochseilgarten und profitieren Sie von großzügigen Ermäßigungen.
<G-vec01061-002-s339><dare.wagen><en> Few dare to wander too far into the wasteland, fearful of Sand People, hideous monsters and worst of all: the utterly unknown.
<G-vec01061-002-s339><dare.wagen><de> Nur wenige wagen sich weit in die Ödnis hinein, aus Angst vor Sandleuten, Monstern und am allerschlimmsten: vor dem absolut Unbekannten.
<G-vec01061-002-s340><dare.wagen><en> Trend sport on two wheels: Conquer the most beautiful bike trails in the Ahrn Valley with local guides, dare to enter the high-wire gardens and profit from the generous discounts provided…
<G-vec01061-002-s340><dare.wagen><de> Trendsport auf zwei Rädern: Erobern Sie die schönsten Biketrails des Ahrntals mit ortskundigen Guides, wagen Sie sich in den Hochseilgarten und profitieren Sie von großzügigen Ermäßigungen.
<G-vec01061-002-s341><dare.wagen><en> At secluded beaches even Filipinas discard some of their prudence and dare to go into the water without t-shirts and short pants for once.
<G-vec01061-002-s341><dare.wagen><de> An abgeschiedeneren Stränden legen auch Filipinas ein wenig ihrer Scham ab und wagen sich einmal ohne T-Shirts und kurze Hosen ins Wasser.
<G-vec01061-002-s342><dare.wagen><en> Dare to go to the treetops in the forest climbing gardens in Enzklösterle, Mehliskopf and Dornstetten-Hallwangen.
<G-vec01061-002-s342><dare.wagen><de> Wagen Sie sich auf die Bäume in den Waldklettergärten in Enzklösterle, am Mehliskopf sowie in Dornstetten-Hallwangen.
<G-vec01061-002-s343><dare.wagen><en> Enjoy the picturesque countryside and dare to climb to the summit.
<G-vec01061-002-s343><dare.wagen><de> Genießen Sie die malerischen Landstriche und wagen Sie den Aufstieg zum Gipfel.
<G-vec01061-002-s344><dare.wagen><en> The power of Elitis, their motto: Dare to innovate and act as explorers in the field of wallcovering.
<G-vec01061-002-s344><dare.wagen><de> Die Kraft von Elitis, ihr Motto: Wagen Sie Innovationen und treten Sie als Entdecker auf dem Gebiet der Wandbekleidung auf.
<G-vec01061-002-s345><dare.wagen><en> Dare a run down the legendary "Streif" or enjoy the magical mountain panorama with a leisurely run down to the valley.
<G-vec01061-002-s345><dare.wagen><de> Wagen Sie eine Abfahrt auf der legendären Streif oder genießen Sie das traumhafte Bergpanorama bei einer gemütlichen Talabfahrt.
<G-vec01061-002-s346><dare.wagen><en> Dare to jump into the refreshing water and afterwards, relax right by the pool or on one of the sun loungers with view to Sciliar and Co.
<G-vec01061-002-s346><dare.wagen><de> Wagen Sie einen Sprung in das erfrischende Nass und entspannen Sie hinterher direkt am Outdoorpool oder auf einer der Sonnenliegen mit Blick auf Schlern und Co.
<G-vec01061-002-s347><dare.wagen><en> They stand in the doorway one next to the other like organ pipes, stare wide-eyed at my hunting trophies, and out of fear dare not speak.
<G-vec01061-002-s347><dare.wagen><de> Sie stellen sich wie Orgelpfeifen nebeneinander an der Thür auf, starren mit weit offenen Augen meine Jagdtrophäen an und wagen vor Angst nicht zu sprechen.
<G-vec01061-002-s348><dare.wagen><en> That is something one only dares to do, only has the courage to do, because one is sustained by the love of the Master – and because we realize what great joy we bring to our Master when we dare reveal ourselves, when we stop hiding.
<G-vec01061-002-s348><dare.wagen><de> Man wagt das, man traut sich das, weil getragen von der Liebe des Meisters – und durch das Erkennen, welch große Freude wir dem Meister bereiten dadurch, dass wir das wagen, dass wir aufhören uns zu verstecken.
<G-vec01061-002-s349><dare.wagen><en> And so, people dare not say “I will make you such and such, you shall such and such,” for they know that they do not possess such power; it is not up to them, and even if they say such things, their words would be empty, and nonsense, driven by their desire and ambition.
<G-vec01061-002-s349><dare.wagen><de> Und so wagen die Leute nicht zu sagen: „Ich werde dich zu dem und dem machen, du wirst dieses und jenes“, denn sie wissen, dass sie keine solche Macht besitzen; es liegt nicht an ihnen, und selbst dann, wenn sie solche Dinge sagen würden, wären ihre Worte leer und unsinnig, angetrieben durch ihren Wunsch und ihren Ehrgeiz.
<G-vec01061-002-s350><dare.wagen><en> Lavrov is confident that no one would dare call him a liar – that would, after all, be the language of the Cold War.
<G-vec01061-002-s350><dare.wagen><de> Er setzt darauf, dass es niemand wagen wird, ihn einen Lügner zu nennen – das wäre ja die Sprache des Kalten Krieges.
<G-vec01061-002-s351><dare.wagen><en> His words prompted great merriment among us, which was heightened by the fact that we knew we could not dare laugh out loud.
<G-vec01061-002-s351><dare.wagen><de> Diese Worte riefen eine tolle Heiterkeit in uns hervor, die noch dadurch verstärkt wurde, daß wir wußten, wir könnten es nicht wagen, laut zu lachen.
<G-vec01061-002-s352><dare.wagen><en> Yashar encourages young people to dare to experiment and to see Yashar as a laboratory.
<G-vec01061-002-s352><dare.wagen><de> Yashar ermutigt junge Menschen, Experimente zu wagen und Yashar als Laborraum zu verstehen.
<G-vec01061-002-s353><dare.wagen><en> You put such strong pressure on your ideas that they no longer dare present themselves to you, they’re so afraid of not being dressed in a way you’d approve of.
<G-vec01061-002-s353><dare.wagen><de> Sie setzen Ihre Ideen derart unter Druck, daß diese es nicht mehr wagen, sich Ihnen zu zeigen, so groß ist ihre Angst, nicht auf Ihre Billigung rechnen zu können.
<G-vec01061-002-s354><dare.wagen><en> “The dreams that you dare to dream really do come true”
<G-vec01061-002-s354><dare.wagen><de> Die Träume, die du wagst zu träumen, werden Wirklichkeit.
<G-vec01061-002-s355><dare.wagen><en> Just one, I repeat, with whom you dare to be yourself.“
<G-vec01061-002-s355><dare.wagen><de> Jemand, ich wiederhole, mit dem du wagst du selbst zu sein.
<G-vec01061-002-s356><dare.wagen><en> However, Death came to the physician, made a dark and angry face, threatened him with his finger, and said, "You have betrayed me. I will overlook it this time because you are my godson, but if you dare to do it again, it will cost you your neck, for I will take you yourself away with me."
<G-vec01061-002-s356><dare.wagen><de> Der Tod aber kam zu dem Arzte, machte ein böses und finsteres Gesicht, drohte mit dem Finger und sagte: "Du hast mich hinter das Licht geführt, diesmal will ich dir's nachsehen, weil du mein Pate bist, aber wagst du das noch einmal, so verfiel die Tochter des Königs in eine schwere Krankheit.
<G-vec01061-002-s357><dare.wagen><en> As though you must deign outside approval before you dare move forward.
<G-vec01061-002-s357><dare.wagen><de> Als ob du dir äußere Billigung gönnen musst, bevor du wagst, weiterzugehen.
<G-vec01061-002-s358><dare.wagen><en> Who doesn’t dare, doesn’t win.
<G-vec01061-002-s358><dare.wagen><de> Wer nicht wagt, der nicht gewinnt.
<G-vec01061-002-s359><dare.wagen><en> The WRX Line is the ideal line for the athletic woman skier - the woman who is fashion-conscious and loves to dare something new.
<G-vec01061-002-s359><dare.wagen><de> WRX Line ist die ideale Linie für die sportliche Fahrerin, die modebewusst unterwegs ist und gerne etwas Neues wagt.
<G-vec01061-002-s360><dare.wagen><en> Every one of them took one thing back home: Those who dare to do something new, will win – and lay the foundation for individual and common success.
<G-vec01061-002-s360><dare.wagen><de> Eins nahmen alle mit nach Hause: Wer Neues wagt, gewinnt – und schafft die Basis für persönlichen und gemeinsamen Erfolg.
<G-vec01061-002-s361><dare.wagen><en> If it doesn't dare to, the AKP will grow more than ever into a mere power-preserving apparatus.
<G-vec01061-002-s361><dare.wagen><de> Wagt sie das nicht, wird die AKP noch stärker als bisher zum reinen Machterhaltungsapparat verkommen.
<G-vec01061-002-s362><dare.wagen><en> Dare to be different, get yourself a naughty piece for the living room – love life!”
<G-vec01061-002-s362><dare.wagen><de> Wagt das Andere, räumt um, holt euch ein freches Teil ins Wohnzimmer – liebt das Leben!“ Typisch Alexander eben.
<G-vec01061-002-s363><dare.wagen><en> Rom 5:7 For one will hardly die for a righteous man; though perhaps for the good man someone would dare even to die.
<G-vec01061-002-s363><dare.wagen><de> 7Nun stirbt kaum jemand um eines Gerechten willen; um des Guten willen wagt er vielleicht sein Leben.
<G-vec01061-002-s364><dare.wagen><en> Dare a dip in the cool Lake Reed (Reedsee) or enjoy the unforgettable sunrise at Gamskarkogel (highest grass-covered mountain in Europe).
<G-vec01061-002-s364><dare.wagen><de> Wagt einen Sprung in den kühlen Reedsee oder genießt den unvergesslichen Sonnenaufgang am Gamskarkogel.
<G-vec01061-002-s365><dare.wagen><en> If everybody doubts, dare to believe.
<G-vec01061-002-s365><dare.wagen><de> Wenn alle zweifeln, wagt zu glauben.
<G-vec01061-002-s366><dare.wagen><en> The driver said, "Singapore dare not offend China and has to please the CCP.
<G-vec01061-002-s366><dare.wagen><de> Der Fahrer meinte: „Singapur wagt nicht, China bloßzustellen und muss der KPCh gefällig sein.
<G-vec01061-002-s367><dare.wagen><en> They devour these splendours with greedy eyes, but very seldom does one of them dare to yield to the inborn impulse and take what would serve for the satisfaction of his most urgent needs.
<G-vec01061-002-s367><dare.wagen><de> Sie verschlingen diese Herrlichkeiten mit gierigen Blicken, doch wagt es selten einer, dem angeborenen Triebe Folge zu leisten und sich zu nehmen, was er zur Befriedigung seiner dringendsten Bedürfnisse nötig hat.
<G-vec01061-002-s368><dare.wagen><en> He is the incarnate Word, and therefore the Word of God comes to us not as an idea but as a person and event, who calls us to that which our prayer does not dare to hope for.
<G-vec01061-002-s368><dare.wagen><de> Er ist das fleischgewordene Wort, und daher kommt das Wort Gottes nicht zu uns als eine Idee, sondern als eine Person und ein Ereignis, das uns dazu beruft, was unser Gebet nicht zu hoffen wagt.
<G-vec01061-002-s369><dare.wagen><en> Don’t miss out on such an event if you dare to face the monster and discover a true hidden gem.
<G-vec01061-002-s369><dare.wagen><de> Wer es also wagt, dem Monster ins Antlitz zu blicken und einen Geheimtipp zu entdecken, sollte so ein Spektakel nicht versäumen.
<G-vec01061-002-s370><dare.wagen><en> But if he wants to wear a kilt, which is without any doubt considered a man's garment, he might not dare to wear it out, because of a slight resemblance with a woman's skirt or just because it is different.
<G-vec01061-002-s370><dare.wagen><de> Möchte er aber einen Kilt, der ausnahmslos für eine Kleidung für Männer gehalten wird, dann wagt er in vielen Fällen nicht den Kilt zu tragen, weil er mit einem Rock eine schwache Ähnlichkeit hat, oder bloß, weil er anders und außergewöhnlich ist.
<G-vec01061-002-s371><dare.wagen><en> Attacks and murders against members of this community usually remain unrequited because the Pakistani courts do not dare to bring Moslem violent criminals to justice.
<G-vec01061-002-s371><dare.wagen><de> Übergriffe und Morde an Angehörigen dieser Glaubensrichtung bleiben meist ungesühnt, da die pakistanische Justiz nicht wagt, muslimische Gewalttäter zur Rechenschaft zu ziehen.
<G-vec01061-002-s372><dare.wagen><en> Find correct words to make her dare to risk at work.
<G-vec01061-002-s372><dare.wagen><de> Finden Sie richtige Worte, damit sie auf der Arbeit zu riskieren wagt.
<G-vec01061-002-s373><dare.wagen><en> Verily, worldwide one doesn’t dare to acknowledge that the events in the world are eerily and, above all, biblically fulfilling themselves.
<G-vec01061-002-s373><dare.wagen><de> Wahrlich, weltweit wagt man nicht zu erkennen, dass die Ereignisse in der Welt dabei sind, sich gruselig und vor allem biblisch zu erfüllen.
<G-vec01061-002-s374><dare.wagen><en> You did that, and now why dare not admit it?" The police then asked Ms. Liang, "Who have you told about this?"
<G-vec01061-002-s374><dare.wagen><de> Ihr habt das getan und jetzt wagt ihr nicht, das zuzugeben?“ Die Polizisten fragten Frau Liang: „Wem hast du davon erzählt?“ Sie sagte: „Ich habe es jedem erzählt, der mir begegnete.
<G-vec01061-002-s375><dare.wagen><en> If you dare to take a glance into the depths below, you will find the Rinnensee at its base.
<G-vec01061-002-s375><dare.wagen><de> Wagt man den Blick in die Tiefe, liegt einem der Rinnensee zu Füßen.
<G-vec01061-002-s376><dare.wagen><en> People dare to swim only in calm days, but without going very far out to the sea.
<G-vec01061-002-s376><dare.wagen><de> Man wagt schwimmen nur in ruhigen Tage, aber in der Nahe von der Ufer.
<G-vec01061-002-s377><dare.wagen><en> Who is compassionate to squares and circles, dare not discard the compasses and squares.
<G-vec01061-002-s377><dare.wagen><de> Wer mit Quadraten und Kreisen mitfühlend ist, wagt es nicht, die Kompasse und Quadrate zu verwerfen.
<G-vec01061-002-s378><dare.wagen><en> Who is compassionate to his children, dare not stop giving them clothes and food.
<G-vec01061-002-s378><dare.wagen><de> Wer mit seinen Kindern mitfühlend ist, wagt es nicht aufhören, ihnen Kleidung und Nahrung zu geben.
<G-vec01061-002-s379><dare.wagen><en> We dare you to stretch to see what is there, push your boundaries and your comfort zones a little bit more.
<G-vec01061-002-s379><dare.wagen><de> Wagt es euch auszustrecken, um zu sehen was es da gibt, Schiebt eure Grenzen und Komfortzonen noch ein wenig weiter hinaus.
<G-vec01061-002-s380><dare.wagen><en> Therefore, he does not dare complain to the authorities for their release.
<G-vec01061-002-s380><dare.wagen><de> Daher wagt er es nicht, bei den Behörden Beschwerde einzulegen.
<G-vec01061-002-s381><dare.wagen><en> Because he's full of fear of harder punishment, he doesn't dare to defend himself and hopes, that she'll soon stop the merciless facesitting punishment.
<G-vec01061-002-s381><dare.wagen><de> Aus Angst vor einer noch schlimmeren Bestrafung, wagt es der Loser nicht sich gegen Adriana zu wehren und hofft, dass sie bald mit ihrer gemeinen Facesitting-Bestrafung aufhört.
<G-vec01061-002-s382><dare.wagen><en> Only if the victim is confronted with the truth in the presence of others, will s/he dare to think rationally again.
<G-vec01061-002-s382><dare.wagen><de> Erst wenn das Opfer in Gegenwart anderer mit der Wahrheit konfrontiert wird, »wagt« es wieder, selbständig rational zu denken.
<G-vec01061-002-s383><dare.wagen><en> Now her child is 3 years old but they still dare not return home.
<G-vec01061-002-s383><dare.wagen><de> Jetzt ist ihr Kind drei Jahre alt, doch sie wagt es immer noch nicht, nach Hause zurück zu kehren.
<G-vec01061-002-s384><dare.wagen><en> Dare to push yourselves beyond the limitations of light and dark to see the absolute incredible beauty in the truth of the color of god.
<G-vec01061-002-s384><dare.wagen><de> Wagt es über die Begrenzungen von Licht und Dunkel hinauszugehen und die absolute unglaubliche Schönheit in der Wahrheit der göttlichen Farben zu sehen.
<G-vec01061-002-s385><dare.wagen><en> Dare to do the two-step if you have to in order to catch up.
<G-vec01061-002-s385><dare.wagen><de> Wagt es den Doppelschritt zu machen wenn es notwendig ist aufzuholen.
<G-vec01061-002-s386><dare.wagen><en> If you are looking for the ultimate thrill, we dare you to try out the L2, the world’s first double-loop water slide.
<G-vec01061-002-s386><dare.wagen><de> Wer im Badeurlaub in Tirol den Adrenalinkick sucht, der wagt sich auf die L2, die weltweit erste Doppellooping-Wasserrutsche.
<G-vec01061-002-s387><dare.wagen><en> The slave has to suffer brutally and doesn’t dare to argue when Jane instills her yellow piss into him.
<G-vec01061-002-s387><dare.wagen><de> Der Sklave muss brutal leiden und wagt sich nicht zu widersprechen als ihm Jane ihre gelbe Pisse einflosst.
<G-vec01061-002-s388><dare.wagen><en> The moment you dare to embrace your true nature with all your needs will make a breakthrough to lasting joy of work possible.
<G-vec01061-002-s388><dare.wagen><de> Der Durchbruch zu anhaltender Arbeitsfreude gelingt in dem Moment, in dem man wagt, sich auf sein ganzes Wesen mit allen seinen Bedürfnissen einzulassen.
<G-vec01061-002-s389><dare.wagen><en> You have to see the drawbacks of the things you're holding onto, and then you'll let go automatically — as when you grab hold of fire and realize how hot it is, you'll automatically let go and never dare touch it again.
<G-vec01061-002-s389><dare.wagen><de> Man muss die Schattenseiten der Dinge erkennen, an die man sich klammert, dann lässt man automatisch los -- so wie bei einem Feuer, wenn man hineingreift und merkt, wie heiß es ist, lässt man automatisch los und wagt nie mehr, es zu berühren.
<G-vec01061-002-s390><dare.wagen><en> Isaac does not dare search for treasure, but he keeps coming back, wandering around the bridge.
<G-vec01061-002-s390><dare.wagen><de> Isaac wagt nicht nach Schatz zu suchen, aber er kommt immer wieder zurück und wandert um die Brücke herum.
<G-vec01061-002-s391><dare.wagen><en> I firmly believe that Master is right around us, and that as long as we do everything righteously, the evil dare not do anything.
<G-vec01061-002-s391><dare.wagen><de> Ich glaube fest, dass der Meister genau in unserer Nähe ist und dass, solange wir alles aufrichtig tun, das Böse nicht wagt, etwas zu unternehmen.
<G-vec01061-002-s392><dare.wagen><en> Or, on the contrary, the father is emphatically courageous and harsh and careless about any successes and achievements of his son, so the boy does not dare compete with him, but prefers to join his mother.
<G-vec01061-002-s392><dare.wagen><de> Oder im Gegenteil, der Vater ist betont mutig und hart und unvorsichtig über irgendwelche Erfolge und Leistungen seines Sohnes, also wagt der Junge nicht, mit ihm zu konkurrieren, sondern zieht es vor, sich seiner Mutter anzuschließen.
<G-vec01061-002-s393><dare.wagen><en> And what did this regime here dare to do: the majority of the state parliament of Berlin, the "Abgeordnetenhaus", voted to give its blessing to the interests of the purchasers of dubious real estate investment funds which actually do not consist in ordinary civil business but are unlawful donations to certain persons, amounting to billions; they even gave additional guarantees for these funds.
<G-vec01061-002-s393><dare.wagen><de> Und was wagte dieses Regime hier: Die Mehrheit des Abgeordnetenhauses beschloss, die Interessen von Käufern zweifelhafter Immobilienfonds, die in Wahrheit keine Geschäfte im bürgerlichen Sinne, sondern gesetzwidrige Geschenke im Milliardenumfang an bestimmte Personen darstellen, abzusegnen und sogar noch zusätzlich zu garantieren.
<G-vec01061-002-s394><dare.wagen><en> I didn’t dare to drink water in the evening, since they didn’t allow Falun Gong practitioners to go to the restrooms at night.
<G-vec01061-002-s394><dare.wagen><de> Ich wagte nicht, abends Wasser zu trinken, da wir nachts nicht auf die Toilette gehen durften.
<G-vec01061-002-s395><dare.wagen><en> I did not dare to face Master’s photo, but faced the corridor.
<G-vec01061-002-s395><dare.wagen><de> Ich wagte nicht, auf das Bild des Meisters zu blicken, sondern schaute auf den Korridor.
<G-vec01061-002-s396><dare.wagen><en> Today we will make it a big fare.” The guards hid in their office and called their superior, but the superior did not dare to come.
<G-vec01061-002-s396><dare.wagen><de> Heute werden wir mal ganz groß was machen.“ Die Wärter versteckten sich in ihrem Büro und riefen ihren Chef an; aber der wagte nicht zu kommen.
<G-vec01061-002-s397><dare.wagen><en> The soundtrack switches continually, to twitch between speed rush and slow motion suspense, from thunderous musical melodrama to lurching baby stroller sizzle to breathless silence—which takes the upper hand when the climax arrives that Eisenstein did not dare to show: how the baby is catapulted from the stroller and set soaring in flight, which is appropriately absurdly savored—until the inevitable impact.
<G-vec01061-002-s397><dare.wagen><de> Zum Zucken zwischen Geschwindigkeitsrausch und Zeitlupen-Suspense wechselt die Tonspur immer wieder von tosender Musik-Melodramatik zu schlingerndem Kinderwagenschmurgeln zu atemloser Stille – die überhand nimmt, wenn der Höhepunkt kommt, den Eisenstein nicht zu zeigen wagte: Wie das Baby aus dem Wagen katapultiert wird und zu einem Höhenflug ansetzt, der angemessen absurd ausgekostet wird – bis zum unvermeidlichen Aufschlag.
<G-vec01061-002-s398><dare.wagen><en> I didn’t dare to speak of this vision to anyone.
<G-vec01061-002-s398><dare.wagen><de> Von dieser Vision wagte ich nicht, mit irgend jemandem zu sprechen.
<G-vec01061-002-s399><dare.wagen><en> Little Molly and Anthony often stood by this mountain, and one day Molly said, "Do you dare to knock and say, 'Lady Halle, Lady Halle, open the door: Tannhauser is here!'" But Anthony did not dare.
<G-vec01061-002-s399><dare.wagen><de> Die kleine Molly und Anton standen oft an dem Berge, da sagte sie einmal: "Getraust Du Dich anzuklopfen und zu rufen: Frau Holle, Frau Holle, mach auf, hier ist Tannhäuser" Doch das wagte Anton nicht.
<G-vec01061-002-s400><dare.wagen><en> Allthough he started recording in the 1980ies it took so long for him to dare to record Piano Solos. And it was worth waiting.
<G-vec01061-002-s400><dare.wagen><de> Und obwohl er schon Mitte der 1980er Jahre das erste Mal im Studio war, hat es doch so lange gedauert, bis er sich an eine reine Klavier-CD wagte.
<G-vec01061-002-s401><dare.wagen><en> In fact, I wanted to enjoy peace of mind, but did not dare to let go of my attachments.
<G-vec01061-002-s401><dare.wagen><de> Eigentlich wollte ich Seelenfrieden genießen, wagte aber nicht, meine Eigensinne loszulassen.
<G-vec01061-002-s402><dare.wagen><en> The forced labour camp did not dare to keep her, so they urged the complex to take her back.
<G-vec01061-002-s402><dare.wagen><de> Das Arbeitslager wagte nicht, sie aufzunehmen und forderte das Stahlwerk auf, sie zurückzunehmen.
<G-vec01061-002-s403><dare.wagen><en> That I didn't dare to publish.
<G-vec01061-002-s403><dare.wagen><de> Dass ich nicht wagte, zu veröffentlichen.
<G-vec01061-002-s404><dare.wagen><en> I went so far as to ask Him a third time, but He still said "No!" and I did not dare to insist further.
<G-vec01061-002-s404><dare.wagen><de> Ich ging soweit, Ihn ein drittes Mal zu bitten, aber Er sagte nur: `Nein`, und ich wagte nicht, weiter in Ihn zu dringen.
<G-vec01061-002-s405><dare.wagen><en> Only when it had grown very dark did I dare to run home.
<G-vec01061-002-s405><dare.wagen><de> Erst als es schon recht dunkel war, wagte ich den Lauf zu meiner Wohnung.
<G-vec01061-002-s406><dare.wagen><en> Then Moses, trembling, did not dare to look at it.
<G-vec01061-002-s406><dare.wagen><de> Moses aber erzitterte und wagte nicht, es zu betrachten.
<G-vec01061-002-s407><dare.wagen><en> He thought they should be expelled to Germany, but he did not dare to take this step because it might "arouse a tremendous outcry against Switzerland in all civilized countries."
<G-vec01061-002-s407><dare.wagen><de> Er dachte, dass sie nach Deutschland ausgeschafft werden sollten, aber er wagte nicht, diesen Schritt zu unternehmen, weil es "in allen zivilisierten Ländern einen fürchterlichen Aufschrei gegen die Schweiz geben" könnte.
<G-vec01061-002-s408><dare.wagen><en> The princess was so shocked that she did not dare to resist, and thieves can easily escaped with their booty.
<G-vec01061-002-s408><dare.wagen><de> Die Prinzessin war so geschockt, dass sie nicht zu widersetzen wagte, und Diebe mit ihrer Beute leicht entkommen kann.
<G-vec01061-002-s409><dare.wagen><en> Until recently, even the catholic sect which actively serves satan, and which is well recognized as a dead church, and has no regard for God, did not dare to raise up women as "priests".
<G-vec01061-002-s409><dare.wagen><de> Bis vor Kurzem wagte selbst die satan aktiv dienende katholische Sekte - die man gut als tote Gemeinde bezeichnet und die gar keine Rücksicht für Gott hat - nicht, die Frauen zu "Priesterinnen" zu machen.
<G-vec01061-002-s410><dare.wagen><en> Nobody would dare to define our German Pope as insane when he writes that Catholics share a belief in hell with “the Protestant friends” (in “Einführung in das Christentum” (“Introduction to Christianity”)).
<G-vec01061-002-s410><dare.wagen><de> Keiner wagte es indes, unseren deutschen Alt-Papst als Verrückten zu definieren, wenn er schreibt, die Katholiken würden „mit den protestantischen Freunden“ den Glauben an die Hölle teilen (in „Einführung in das Christentum“).
<G-vec01061-002-s411><dare.wagen><en> For a long time, the pagan father did not dare to turn to the true faith, but after a miraculous case of healing he believed in Jesus Christ and converted to Christianity.
<G-vec01061-002-s411><dare.wagen><de> Der heidnische Vater wagte es lange nicht, sich dem wahren Glauben zuzuwenden, aber nach einem Wunderfall der Heilung glaubte er an Jesus Christus und bekehrte sich zum Christentum.
<G-vec01061-002-s412><dare.wagen><en> Even the Chinese President Xi Jinping did not dare to do such a thing in Vietnam.
<G-vec01061-002-s412><dare.wagen><de> Auch der chinesische Präsident Xi Jinping wagte es nicht, in Vietnam so etwas zu tun.
<G-vec01061-002-s413><dare.wagen><en> He did not dare visit the plant, however, or speak to the workers, who bitterly denounced him to the press.
<G-vec01061-002-s413><dare.wagen><de> Er wagte es jedoch nicht, die Fabrik zu besuchen oder mit Arbeitern zu sprechen, die ihn in der Presse erbittert anklagten.
<G-vec01061-002-s414><dare.wagen><en> Feeling the sudden pressure, the former mentor didn’t dare turn around.
<G-vec01061-002-s414><dare.wagen><de> Da er den Druck deutlich spürte, wagte es der ehemalige Mentor nicht, sich umzudrehen.
<G-vec01061-002-s415><dare.wagen><en> I didn’t dare to call my art ‘queer’, even though I was working with these topics long before.
<G-vec01061-002-s415><dare.wagen><de> Ich wagte es früher nicht, meine Kunst queer zu nennen, obwohl ich mit diesen Themen schon lange davor gearbeitet hatte.
<G-vec01061-002-s416><dare.wagen><en> And I wanted very much to, but I didn't dare.
<G-vec01061-002-s416><dare.wagen><de> Dabei wollte ich das sehr, wagte es aber nicht.
<G-vec01061-002-s417><dare.wagen><en> Upon hearing the wise and compassionate questions from Sakyamuni, the person was speechless and never dare to curse Sakyamuni again.
<G-vec01061-002-s417><dare.wagen><de> Wenn ich deine Beschimpfungen nicht annehme, wer bekommt dann die Beschimpfung?“ Als die Person die weisen und barmherzigen Worte von Shakyamuni hörte, war sie sprachlos und wagte es nie mehr, Shakyamuni erneut zu beschimpfen.
<G-vec01061-002-s418><dare.wagen><en> I thought long and did not dare to answer you.
<G-vec01061-002-s418><dare.wagen><de> Ich dachte lange und wagte es nicht, Ihnen zu antworten.
<G-vec01061-002-s419><dare.wagen><en> And no one was able to answer Him a word, nor from that day on did anyone dare question Him anymore.
<G-vec01061-002-s419><dare.wagen><de> Und niemand konnte ihm ein Wort antworten, noch wagte jemand von dem Tag an, ihn weiter zu befragen.
<G-vec01061-002-s420><dare.wagen><en> I didn't dare go out in the cold where he would be waiting.
<G-vec01061-002-s420><dare.wagen><de> Ich wagte nicht, hinaus in die Kälte zu gehen, wo er wartete.
<G-vec01061-002-s421><dare.wagen><en> I wanted to run out of that room, but I didn't dare move.
<G-vec01061-002-s421><dare.wagen><de> Ich wollte aus dem Zimmer laufen, aber ich wagte nicht, mich zu bewegen.
<G-vec01061-002-s422><dare.wagen><en> He didn’t dare answer.
<G-vec01061-002-s422><dare.wagen><de> Er wagte es nicht zu antworten.
<G-vec01061-002-s423><dare.wagen><en> It's very likely that the medical examiner, the officer and the doctor knew those scars were caused by electric shocks, but didn't dare to speak out.
<G-vec01061-002-s423><dare.wagen><de> Es ist sehr wahrscheinlich, dass der medizinische Gutachter, der Beamte und der Arzt wussten, dass diese Narben durch Elektroschocks verursacht wurden, aber nicht wagten, es auszusprechen.
<G-vec01061-002-s424><dare.wagen><en> In fact, as if wounded by the ugliness of the old buildings and by the narrow and tortuous streets, he burned Rome in so obvious a way that quite a number of the consular class, though having surprised his servants on their properties with tow and torches, did not dare touch them; and some stores, near to the Golden House, of which he desired to occupy the area, were demolished with siege equipment and given to the flames, because they were built in stone.
<G-vec01061-002-s424><dare.wagen><de> So als fühle er sich beleidigt von der Häßlichkeit der alten Gebäude, der engen, gewundenen Straßen, steckte er Rom in Brand, und das auf so offensichtliche Weise, daß es viele Konsuln, die doch auf ihren Grundstücken seine Kammerdiener mit Strohbündeln und Fackeln sahen, nicht wagten, sie anzurühren; und einige Gebäude, in der Nähe der Domus aurea, ein Grundstück, das er in Besitz zu nehmen gedachte, wurden mit Kriegsmaschinen niedergemacht und in Brand gesteckt, da aus Stein gebaut.
<G-vec01061-002-s425><dare.wagen><en> This declaration was aimed at Prussia and Bismarck, for whose policies even the Liberals did not dare to stand up in those days, although in their hearts, they were in favor of annexation by Prussia.
<G-vec01061-002-s425><dare.wagen><de> Der Beschluß zielte gegen Preußen und Bismarck, für dessen Politik damals selbst diejenigen Liberalen nicht einzutreten wagten, die innerlich für eine Annexion an Preußen waren.
<G-vec01061-002-s426><dare.wagen><en> My husband and daughter were terrified and did not dare to talk to me.
<G-vec01061-002-s426><dare.wagen><de> Mein Mann und meine Tochter waren erschrocken und wagten nicht mit mir zu reden.
<G-vec01061-002-s427><dare.wagen><en> Even for Germany, the internationally collated Stigma Index paints a bleak picture: 70% of those infected fear revealing their status and a quarter of those who dare to take the step report having had bad experiences, frequently at medical facilities.
<G-vec01061-002-s427><dare.wagen><de> Selbst in Deutschland zeichnet der international erhobene Stigma-Index ein düsteres Bild: 70% der Infizierten haben Angst, sich zu outen und ein Viertel derjenigen, die den Schritt wagten, berichteten von schlechten Erfahrungen, nicht selten in medizinischen Einrichtungen.
<G-vec01061-002-s428><dare.wagen><en> Mats and me 'ud be the only ones for him, and sometimes we didn't dare cheer too loud.
<G-vec01061-002-s428><dare.wagen><de> Mats und ich waren meist die einzigen auf seiner Seite, doch manchmal wagten wir nicht, ihn laut anzufeuern.
<G-vec01061-002-s429><dare.wagen><en> When the guards met with their retribution, they did not dare to beat us again.
<G-vec01061-002-s429><dare.wagen><de> Wenn die Wärter Vergeltung für ihre Taten erhielten, wagten sie nicht, uns wieder zu schlagen.
<G-vec01061-002-s430><dare.wagen><en> It’s always great to see how the greys patrol the open water while the smaller blacktip reef sharks hardly dare to leave the shallow reef top.
<G-vec01061-002-s430><dare.wagen><de> Wie meistens zogen die Grauen in kleinen Gruppen vor der Wand vorbei während die kleineren Schwarzspitzenriffhaie kaum wagten, ihr Revier über dem flachen Riffdach zu verlassen.
<G-vec01061-002-s434><dare.wagen><en> In light of these threats, it is hard to see how any Palestinian businessman living under the rule of the Palestinian Authority in the West Bank and Hamas in the Gaza Strip would dare to take the dangerous step of participating in a US-led conference that is being denounced by Palestinian leaders as a "conspiracy" to eliminate the Palestinian cause and rights.
<G-vec01061-002-s434><dare.wagen><de> Angesichts dieser Drohungen ist es schwer zu erkennen, wie es ein palästinensischer Geschäftsmann, der unter der Herrschaft der Palästinensischen Autonomiebehörde im Westjordanland und der Hamas im Gazastreifen lebt, schaffen sollte, den gefährlichen Schritt zu wagen, an einer von den USA geführten Konferenz teilzunehmen, die von den palästinensischen Führern als "Verschwörung" zur Liquidierung der palästinensischen Sache und Rechte angeprangert wird.
<G-vec01061-002-s435><dare.wagen><en> powerful & harmonious The great success of the red Bucefalo gave the winemakers of Lunaria the idea to dare the experiment of making wine from partially dried grapes.
<G-vec01061-002-s435><dare.wagen><de> fruchtbetont & harmonisch Der große Erfolg des roten Bucefalo brachte die Winzer von Lunaria auf die Idee, das Experiment, Wein aus teilweise getrockneten Trauben herzustellen, auch in weiß zu wagen.
<G-vec01061-002-s436><dare.wagen><en> Daily Life: Two-thirds of respondents say they do not dare hold the hand of their same-sex partner in public. In the case of homosexual and bisexual men, the proportion is 75 percent.
<G-vec01061-002-s436><dare.wagen><de> Alltag: Zwei Drittel der Befragten gaben an, es nicht zu wagen, in der Öffentlichkeit die Hand ihres gleichgeschlechtlichen Partners zu halten; bei homo- und bisexuellen Männern lag dieser Anteil bei 75 Prozent.
<G-vec01061-002-s437><dare.wagen><en> It is simply in our DNA to dare try new things, dare be at the forefront.
<G-vec01061-002-s437><dare.wagen><de> Der Mut Neues zu wagen und eine Vorreiterrolle einzunehmen, liegt einfach in unserer DNA.
<G-vec01061-002-s438><dare.wagen><en> Drive to dare new things
<G-vec01061-002-s438><dare.wagen><de> Antrieb, um neue Dinge zu wagen.
<G-vec01061-002-s439><dare.wagen><en> Only to dare a huge step beyond now: away from Emocore.
<G-vec01061-002-s439><dare.wagen><de> Nur, um jetzt den großen Ausfallschritt zu wagen: Weg vom Emocore.
<G-vec01061-002-s440><dare.wagen><en> In light of the acute danger and the bleak future perspectives, many young Jewish men and women were much more inclined to dare take this step, as the example of Lucy Greif shows, who shortly after her wedding emigrated to the USA along with her husband.
<G-vec01061-002-s440><dare.wagen><de> Junge Jüdinnen und Juden waren angesichts der akuten Bedrohung und der finsteren Zukunftsperspektiven vielfach eher bereit, diesen Schritt zu wagen, wie auch das Beispiel Lucy Greifs zeigt, die kurz nach ihrer Heirat zusammen mit ihrem Mann in die USA auswanderte.
