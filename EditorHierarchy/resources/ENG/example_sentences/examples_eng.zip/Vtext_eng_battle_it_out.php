<G-vec01002-002-s076><battle_it_out.bekämpfen><en> In order to function quick and successfully, Hiprolean X-S attempts to battle all weight loss problems at once.
<G-vec01002-002-s076><battle_it_out.bekämpfen><de> Um schnell und effizient zu arbeiten, versucht Hiprolean XS, alle Gewichtsverlust Probleme sofort zu bekämpfen.
<G-vec01002-002-s077><battle_it_out.bekämpfen><en> The area surrounding the fire where such risks would be highest are in fact closed to the public and therefore inaccessible, but the additional radiation risk to firefighters is making it difficult to send adequate personnel to battle the blaze.
<G-vec01002-002-s077><battle_it_out.bekämpfen><de> Die Umgebung, die das Feuer umgibt, wo solche Risiken am höchsten sind, sind in der Tat für die Öffentlichkeit geschlossen und daher unzugänglich, aber das zusätzliche Strahlenrisiko für Feuerwehrmänner macht es schwierig, adäquates Personal zu schicken, um die Flammen zu bekämpfen.
<G-vec01002-002-s078><battle_it_out.bekämpfen><en> You battle the ignorance that’s been guiding your hunger, and you come out with something much better.
<G-vec01002-002-s078><battle_it_out.bekämpfen><de> Sie bekämpfen die Unwissenheit, die Ihren Hunger anführt, und Sie kommen da mit etwas viel besserem heraus.
<G-vec01002-002-s079><battle_it_out.bekämpfen><en> Still, even if modern Mars is barren and lifeless after all, keeping any future human habitations clean will be key, as will understanding the best ways to battle earthly germs that might flourish in microgravity.
<G-vec01002-002-s079><battle_it_out.bekämpfen><de> Selbst, wenn der Mars also ein toter Planet sein sollte, wird es unerlässlich sein, künftige menschliche Habitate so sauber wie möglich zu halten – und zu verstehen, wie man irdische Keime am besten bekämpfen kann, die in der Schwerelosigkeit gedeihen.
<G-vec01002-002-s080><battle_it_out.bekämpfen><en> 1 It happened after this, that the children of Moab, and the children of Ammon, and with them some of the Ammonites, came against Jehoshaphat to battle.
<G-vec01002-002-s080><battle_it_out.bekämpfen><de> Und es geschah danach, da kamen die Moabiter und die Ammoniter und mit ihnen andere neben den Ammonitern, um Josaphat zu bekämpfen.
<G-vec01002-002-s081><battle_it_out.bekämpfen><en> As you explore the huge stretch of the Big MT crater and its many underground labs, you'll confront strange mutated animals, battle terrifying new atomic robots, and discover a new home base to call your own.
<G-vec01002-002-s081><battle_it_out.bekämpfen><de> Während Sie die Weiten des Big MT Kraters und seiner unterirdischen Labore erkunden, begegnen Sie seltsam mutierten Tieren, bekämpfen neue schreckenerregende Roboter und entdecken einen weiteren Ort, den Sie Ihr eigen nennen können.
<G-vec01002-002-s082><battle_it_out.bekämpfen><en> Another detour takes you into a 360-degree, 3D jungle that feels startlingly real, especially when King Kong emerges to battle dinosaurs—with your tram rocking and rolling in the middle of the brawl.
<G-vec01002-002-s082><battle_it_out.bekämpfen><de> Ein weiterer Weg führt Sie zu einem 360 Grad, 3D Dschungel, der sehr real wirkt, gerade dann, wenn King Kong auftaucht, um die Dinosaurier zu bekämpfen - während Ihr Waggon wackelt und schaukelt.
<G-vec01002-002-s083><battle_it_out.bekämpfen><en> Players must battle the undead and embark on a chilling journey through a snowy Bavarian village in Germany that holds a twisted secret to an unimaginable supernatural power.
<G-vec01002-002-s083><battle_it_out.bekämpfen><de> Die Spieler müssen die Untoten bekämpfen und sich auf eine frostige Reise durch ein verschneites, bayerisches Dorf begeben, welches das Geheimnis einer unvorstellbaren, übernatürlichen Macht birgt.
<G-vec01002-002-s084><battle_it_out.bekämpfen><en> It was widely agreed that armies have a great need to battle extremism as they are an important symbol of statehood.
<G-vec01002-002-s084><battle_it_out.bekämpfen><de> Man war sich allgemein einig, dass Armeen ein großes Bedürfnis haben den Extremismus zu bekämpfen, da sie ein wichtiges Symbol der Staatlichkeit sind.
<G-vec01002-002-s085><battle_it_out.bekämpfen><en> Explore and Discover - Battle enemies, solve puzzles, and seek out the world's greatest treasures.
<G-vec01002-002-s085><battle_it_out.bekämpfen><de> Entdeckungen und Erkundungen - Bekämpfen Sie Feinde, lösen Sie Puzzle und suchen Sie nach den größten Schätzen der Welt.
<G-vec01002-002-s086><battle_it_out.bekämpfen><en> Transform into 16 of the most popular Invizimals, using their unique powers and abilities to solve puzzles and battle against your enemies.
<G-vec01002-002-s086><battle_it_out.bekämpfen><de> Verwandle dich in 16 der beliebtesten Invizimals und nutze ihre Kräfte und Fähigkeiten, um Rätsel zu lösen und deine Gegner zu bekämpfen.
<G-vec01002-002-s087><battle_it_out.bekämpfen><en> Get a taste of the past and battle others with our complete list of the most popular .IO games! Don't let the graphics fool you.
<G-vec01002-002-s087><battle_it_out.bekämpfen><de> Holen Sie sich einen Vorgeschmack auf die Vergangenheit und bekämpfen Sie andere mit unserer vollständigen Liste der beliebtesten .IO-Spiele Lassen Sie sich von der Grafik nicht täuschen.
<G-vec01002-002-s088><battle_it_out.bekämpfen><en> In Pokémon Sword and Pokémon Shield, players will embark on a new adventure through the Galar region, where they’ll catch, battle and trade newly discovered Pokémon and uncover the mystery behind Legendary Pokémon Zacian and Zamazenta.
<G-vec01002-002-s088><battle_it_out.bekämpfen><de> In Pokémon Schwert und Pokémon-SchildBegeben Sie sich auf ein neues Abenteuer in der Galar-Region, in der Sie neu entdeckte Pokémon und das Geheimnis der legendären Pokémon Zacian und Zamazenta fangen, bekämpfen und tauschen.
<G-vec01002-002-s089><battle_it_out.bekämpfen><en> Since its consumption doesn't result in torpidity, couchlock, tension or neurosis, Harlequin is an ideal method to battle queasiness.
<G-vec01002-002-s089><battle_it_out.bekämpfen><de> Harlekin ist eine ideale Methode, um Übelkeit zu bekämpfen, da sein Verzehr nicht zu Trägheit, Couchlock, Anspannung oder Neurose führt.
<G-vec01002-002-s090><battle_it_out.bekämpfen><en> They’ll travel to Romania to battle the Legends and claim their place in CS:GO history.
<G-vec01002-002-s090><battle_it_out.bekämpfen><de> Sie werden alle nach Rumänien reisen, um die Legenden zu bekämpfen und ihren Platz in der Geschichte von CS:GO zu beanspruchen.
<G-vec01002-002-s091><battle_it_out.bekämpfen><en> Then use her special abilities to solve puzzles and battle enemies.
<G-vec01002-002-s091><battle_it_out.bekämpfen><de> Setze anschließend ihre Spezialfähigkeiten ein, um Rätsel zu lösen und Gegner zu bekämpfen.
<G-vec01002-002-s092><battle_it_out.bekämpfen><en> The king is Cagnazzo, the Archfiend of Water, whom Cecil's party defeats in battle.
<G-vec01002-002-s092><battle_it_out.bekämpfen><de> Dort erfahren sie, dass der König in Wirklichkeit Cagnazzo war, Geist des Wasserkristalls, den sie bekämpfen.
<G-vec01002-002-s093><battle_it_out.bekämpfen><en> The media exposure of the issue since Kodjo’s government (2000-2002) probably has more to do with political exploitation than a serious intent to battle a phenomenon that increasingly shapes the political and administrative culture and owes its existence to the structure of the political system and the dominance of the Etat-rhizôme.
<G-vec01002-002-s093><battle_it_out.bekämpfen><de> Deren Mediatisierung seit der Regierung Kodjo (2000-2002) hat wahrscheinlich mehr mit einer politischen Instrumentalisierung als mit einer ernsthaften Absicht zu tun, ein Phänomen zu bekämpfen, das die politische und Verwaltungskultur zunehmend prägt und zudem der Struktur des politischen Systems und der Vorherrschaft des „Etat-rhizôme“ geschuldet ist.
<G-vec01002-002-s094><battle_it_out.bekämpfen><en> In essence, it slows time so that players can better dodge falling blocks, battle quick enemies, and more.
<G-vec01002-002-s094><battle_it_out.bekämpfen><de> Im Prinzip verlangsamt sie also die Zeit, so dass ihr fallenden Blöcken besser ausweichen und schnelle Gegner bekämpfen könnt.
<G-vec01002-002-s264><battle_it_out.kämpfen><en> So it is noteworthy that, as the US-led invasion of Iraq--and with it, America's clash with the Islamic world--grows more heated, Russia's battle with Muslim Chechens may be waning into something like peace.
<G-vec01002-002-s264><battle_it_out.kämpfen><de> Es ist daher beachtenswert, dass, zur Zeit der Invasion in den Irak unter Führung der USA und während Amerikas Zusammenstoß mit der islamischen Welt dadurch an Hitze gewinnt, Russlands Kämpfe mit den mohammedanischen Tschetschenen zu etwas wie einem Frieden abflauen könnten.
<G-vec01002-002-s265><battle_it_out.kämpfen><en> The oldest mention on the target from 972 commemorates the arrival of the first German immigrants, and the latest from 1841 records the dedication of the memorial for loyalty and commitment, Treue und Beharrlichkeit, which the city exhibited during the battle in 1809.
<G-vec01002-002-s265><battle_it_out.kämpfen><de> Die älteste Erwähnung auf der Scheibe bindet sich an das Jahr 972 und erinnert an die Ankunft der ersten deutschen Immigranten, die jüngste bindet sich an das Jahr 1841, als im Rathaussaal ein Denkmal der Treue und Beharrlichkeit, die die Stadt während der Kämpfe im Jahre 1809 erwiesen habe, enthüllt wurde.
<G-vec01002-002-s266><battle_it_out.kämpfen><en> Battle with more than 35 different enemies, including sneaky penguins, exploding foxes and ninja squirrels.
<G-vec01002-002-s266><battle_it_out.kämpfen><de> Kämpfe gegen über 35 verschiedene Gegner, darunter hinterlistige Pinguine, explodierende Füchse und Ninja-Eichhörnchen.
<G-vec01002-002-s267><battle_it_out.kämpfen><en> Upgrade your skills and weapons and battle your way through many levels.
<G-vec01002-002-s267><battle_it_out.kämpfen><de> Dann fange gleich damit an und kämpfe dich durch viele Level.
<G-vec01002-002-s268><battle_it_out.kämpfen><en> Hack computer terminals: Enter a virtual world to escape mazes, battle in arenas, and race to find the code.
<G-vec01002-002-s268><battle_it_out.kämpfen><de> • Hacke Computerterminals – Betritt eine virtuelle Welt, um aus Labyrinthen zu entkommen, kämpfe in Arenen, und finde so schnell wie möglich den Code.
<G-vec01002-002-s269><battle_it_out.kämpfen><en> Fittingly, the Galactic Republic and Separatist Alliance enter Star Wars: Legion with two of the most recognisable leaders in the galaxy leading their troops into battle.
<G-vec01002-002-s269><battle_it_out.kämpfen><de> Passenderweise führen zwei der bekanntesten Anführer der Galaxis die Galaktische Republik und die Separatisten-Allianz in die Kämpfe von Star Wars: Legion.
<G-vec01002-002-s270><battle_it_out.kämpfen><en> Battle fearsome foes alongside your partner, Malroth – Accompanying you on your quest is the mysterious Malroth, an aggressive amnesiac with a fondness for fighting foes.
<G-vec01002-002-s270><battle_it_out.kämpfen><de> Kämpfe an der Seite deines Freundes Malroth – Deine Begleitung auf deiner Mission ist der mysteriöse Malroth, grober Gedächtnisloser mit einer Vorliebe fürs Verprügeln von Feinden.
<G-vec01002-002-s271><battle_it_out.kämpfen><en> Other goodies available only in the Resident Evil 5: Gold Edition include two costume packs and the famous Resident Evil 5 Versus Mode, where you and up to three of your friends can battle hideous creatures or each other via PlayStation Network.
<G-vec01002-002-s271><battle_it_out.kämpfen><de> Resident Evil 5: Gold Edition wartet außerdem mit zwei Kostümpaketen und dem legendären Versus-Modus für Resident Evil 5 auf, in dem du dich mit bis zu drei Freunden irrwitzigen Geschöpfen entgegenstellen oder Kämpfe über das PlayStation Network austragen kannst.
<G-vec01002-002-s272><battle_it_out.kämpfen><en> Battle for world domination.
<G-vec01002-002-s272><battle_it_out.kämpfen><de> Kämpfe um die Weltherrschaft.
<G-vec01002-002-s273><battle_it_out.kämpfen><en> At the site of the 1864 battle there is a modern centre which explains the historical background for the battle.
<G-vec01002-002-s273><battle_it_out.kämpfen><de> Am Ort der Schlacht von 1864 erklärt ein modernes Zentrum die geschichtlichen Hintergründe der Kämpfe.
<G-vec01002-002-s274><battle_it_out.kämpfen><en> All versus all battle: search for weapons, find a safe zone, plunder your enemies... survive until the end.
<G-vec01002-002-s274><battle_it_out.kämpfen><de> Kämpfe gegen alle: suche nach Waffen, finde einen sicheren Bereich, plündere deine Feinde... überlebe, bis du der Letzte bist, der noch lebt.
<G-vec01002-002-s275><battle_it_out.kämpfen><en> Collect an unbeatable team of heroes and engage in a battle with strong monsters that want to conquer your world.
<G-vec01002-002-s275><battle_it_out.kämpfen><de> Sammle ein unschlagbares Team von Helden und kämpfe mit starken Monstern, die deine Welt erobern wollen.
<G-vec01002-002-s276><battle_it_out.kämpfen><en> Battle by tapping – Pokémon Quest uses simple touch controls that can be enjoyed by everyone
<G-vec01002-002-s276><battle_it_out.kämpfen><de> Kämpfe durch Berühren: Pokémon Quest bietet eine einfache Berührungssteuerung, die jeder meistern kann.
<G-vec01002-002-s278><battle_it_out.kämpfen><en> Battle with Batman and his super allies in outer space and across the Lantern worlds.
<G-vec01002-002-s278><battle_it_out.kämpfen><de> Kämpfe mit Batman und seinen verbündeten Superhelden im Weltraum und in verschiedenen Lantern-Welten.
<G-vec01002-002-s279><battle_it_out.kämpfen><en> Battle and carnage are the lifeblood of the Barbarian Bloddwalkers.
<G-vec01002-002-s279><battle_it_out.kämpfen><de> Kämpfe und Gemetzel sind ihr Lebenssaft.
<G-vec01002-002-s280><battle_it_out.kämpfen><en> Defeat over 20 different types of opponents and battle for the Highscore.
<G-vec01002-002-s280><battle_it_out.kämpfen><de> Besiege über 20 unterschiedliche Gegnertypen und kämpfe um den Highscore.
<G-vec01002-002-s281><battle_it_out.kämpfen><en> In LEGO Indiana Jones 2, everyone can build, battle and brawl their way through their favourite cinematic moments from the Indiana Jones movie series – or create their own.
<G-vec01002-002-s281><battle_it_out.kämpfen><de> Fans können LEGO bauen, Kämpfe austragen und sich durch ihre Lieblings-Filmszenen schlagen, von Indys Begegnung mit Schlangen bis zu seiner überstürzten Flucht vor einer gewaltigen Felskugel.
<G-vec01002-002-s282><battle_it_out.kämpfen><en> Working at adidas Group is not a battle to be won, it’s a journey into the unknown.
<G-vec01002-002-s282><battle_it_out.kämpfen><de> Bei Ihrer Arbeit bei adidas müssen Sie keine Kämpfe gewinnen – vielmehr befinden Sie sich auf einer Reise ins Unbekannte.
<G-vec01002-002-s283><battle_it_out.kämpfen><en> Over 350 unique, historically accurate vehicles battle each other in 7-on-7 battles in more than 25 locations in multiple modes.
<G-vec01002-002-s283><battle_it_out.kämpfen><de> Über 350 einzigartige, historisch genaue Fahrzeuge kämpfen hier in 7-gegen-7-Gefechten an mehr als 25 Orten in mehreren Modi gegeneinander.
<G-vec01002-002-s284><battle_it_out.kämpfen><en> The game is very spooky and you must battle against the SS forces in Transylvania.
<G-vec01002-002-s284><battle_it_out.kämpfen><de> Das Spiel ist sehr unheimlich und Sie müssen kämpfen gegen die SS-Truppen in Transylvania.
<G-vec01002-002-s285><battle_it_out.kämpfen><en> Battle your way to the Loom Chamber in under 10 minutes.
<G-vec01002-002-s285><battle_it_out.kämpfen><de> Kämpfen Sie sich in unter 10 Minuten zur Webstuhlkammer vor.
<G-vec01002-002-s286><battle_it_out.kämpfen><en> To help you pick a strong group to bring to battle, six Pokémon will automatically be recommended to use in the battle based your opponents’ strengths and weaknesses.
<G-vec01002-002-s286><battle_it_out.kämpfen><de> Um dir beim Auswählen einer starken Gruppe zum Kämpfen zu helfen, werden automatisch basierend auf den Stärken und Schwächen deines Gegners sechs Pokémon für den Kampf vorgeschlagen.
<G-vec01002-002-s287><battle_it_out.kämpfen><en> Navy vs. Army is a fun skill shot game with physics engine where some guys of Navy and Army battle against each other.
<G-vec01002-002-s287><battle_it_out.kämpfen><de> Navy vs. Army ist ein lustiges Geschicklichkeits Schiessspiel, in dem Typen aus der Navy und der Armee gegeneinander kämpfen.
<G-vec01002-002-s288><battle_it_out.kämpfen><en> 20 And the men of Israel went out to battle against Benjamin; and the men of Israel put themselves in array to fight against them at Gibeah.
<G-vec01002-002-s288><battle_it_out.kämpfen><de> 20 Und die Männer von Israel zogen aus, um mit Benjamin zu kämpfen, und stellten sich in Schlachtordnung auf zum Kampf gegen Gibea.
<G-vec01002-002-s289><battle_it_out.kämpfen><en> Experts believe that number will likely swell, potentially driving at least another 1.5 million men, women and children to flee once the U.S.-backed battle for Mosul begins.
<G-vec01002-002-s289><battle_it_out.kämpfen><de> Experten sind der Meinung, dass die Zahl noch ansteigen wird, wenn noch 1,5 Millionen weitere Männer, Frauen und Kinder fliehen werden, um den von den USA unterstützen Kämpfen um Mosul zu entkommen.
<G-vec01002-002-s290><battle_it_out.kämpfen><en> Open to any to take the challenge and show to all that they have what it takes to be one of the best, teams battle to rise to the top through a series of ZOTAC CUP qualifiers building up to a ZOTAC CUP MASTERS live event where the best meet best.
<G-vec01002-002-s290><battle_it_out.kämpfen><de> Offen für alle, die sich der Herausforderung stellen möchten und es allen zeigen wollen, dass sie das Zeug dazu haben, ganz oben mitzuspielen und sich durch eine Reihe von ZOTAC CUP Online Qualifikationen und dem regionalen Finale kämpfen können.
<G-vec01002-002-s292><battle_it_out.kämpfen><en> Most planeswalkers can't be used as commanders, but these four have been designed specifically to fill that role, so you can battle with a true legend of the Multiverse by your side.
<G-vec01002-002-s292><battle_it_out.kämpfen><de> Die meisten Planeswalker können nicht als Kommandeure eingesetzt werden, diese vier aber sind eigens für eine solche Rolle konzipiert; du kannst also mit einer wahren Legende des Multiversums an deiner Seite kämpfen.
<G-vec01002-002-s293><battle_it_out.kämpfen><en> 2 Behold, we have not come out to battle against you that we might shed your blood for power; neither do we desire to bring any one to the ayoke of bondage.
<G-vec01002-002-s293><battle_it_out.kämpfen><de> 2 Siehe, wir sind nicht hergekommen, um gegen euch zu kämpfen, daß wir um der Macht willen euer Blut vergießen; wir haben auch nicht den Wunsch, irgend jemand unter das Joch der Knechtschaft zu bringen.
<G-vec01002-002-s294><battle_it_out.kämpfen><en> He teams up with his ex-girlfriend Marian and the Arab fighter Little John (Jamie Foxx) he came across during the battle.
<G-vec01002-002-s294><battle_it_out.kämpfen><de> Robin Hood beschließt gemeinsam mit seinem Verbündeten Little John (Jamie Foxx), die Missstände nicht länger hinzunehmen und gegen die vorherrschende Ungerechtigkeit zu kämpfen.
<G-vec01002-002-s295><battle_it_out.kämpfen><en> Save Aleppo The battle for the Syrian city of Aleppo has left hundreds of people dead or injured.
<G-vec01002-002-s295><battle_it_out.kämpfen><de> In den Kämpfen in und um Aleppo wurden in den letzten Tagen und Wochen Hunderte Menschen getötet oder verletzt.
<G-vec01002-002-s296><battle_it_out.kämpfen><en> Some Thing Cards even have uses in puzzles outside of battle, too!
<G-vec01002-002-s296><battle_it_out.kämpfen><de> Einige Dings-Karten kann man auch außerhalb von Kämpfen in Rätseln sehr gut anwenden.
<G-vec01002-002-s297><battle_it_out.kämpfen><en> Eight of the top European teams will battle for dominance in the European Regionals at Gamescom, with the top three teams advancing to the World Championship in Los Angeles, California.
<G-vec01002-002-s297><battle_it_out.kämpfen><de> Acht der besten Teams aus Europa werden auf der gamescom um die Vorherrschaft kämpfen und die drei besten Teams rücken zur Weltmeisterschaft in Los Angeles, Kalifornien, vor.
<G-vec01002-002-s298><battle_it_out.kämpfen><en> Selected contestants will be pre-judged for craftsmanship off stage and then battle it out on the Main Stage for First Place in their respective categories.
<G-vec01002-002-s298><battle_it_out.kämpfen><de> Die ausgewählten Kandidaten werden vor Ort auf der VIECC Vienna Comic Con vorab für ihr handwerkliches Geschick abseits der Bühne von einer professionellen Cosplay Jury beurteilt und kämpfen anschließend auf der Hauptbühne um den ersten Platz in ihrer jeweiligen Kategorie.
<G-vec01002-002-s299><battle_it_out.kämpfen><en> Remember that you are very slow, so pick the spot you will be most useful in battle very carefully - you will most likely not have the chance to readjust your position later on.
<G-vec01002-002-s299><battle_it_out.kämpfen><de> Denkt auch daran, dass ihr euch eher langsam fortbewegt, also müsst ihr schon am Anfang festlegen, wo ihr mit eurem Panzer kämpfen möchtet, da ihr später wahrscheinlich keine Möglichkeit haben werdet, die Flanke zu wechseln.
<G-vec01002-002-s300><battle_it_out.kämpfen><en> At the same time, however, they are also so that God may do battle with Satan.
<G-vec01002-002-s300><battle_it_out.kämpfen><de> Gleichzeitig sind sie jedoch so, dass Gott mit Satan kämpfen kann.
<G-vec01002-002-s301><battle_it_out.kämpfen><en> Super Pokémon Rumble allows players to battle against waves of opposing wind-up Toy Pokémon, and connect with a friend to battle together.
<G-vec01002-002-s301><battle_it_out.kämpfen><de> In Super Pokémon Rumble können die Spieler gegen Spielzeug-Pokémon kämpfen und sich mit einem Freund verbinden, um gemeinsam in die Schlacht zu ziehen.
