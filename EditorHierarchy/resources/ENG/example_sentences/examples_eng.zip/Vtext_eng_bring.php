<G-vec00355-002-s494><bring.(sich)_nehmen><en> I plan to bring my family to Prague so that we will have a vacation time after the convention.
<G-vec00355-002-s494><bring.(sich)_nehmen><de> Ich will meine Familie mit zur Veranstaltung in Beverly Hills nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00355-002-s495><bring.(sich)_nehmen><en> In this case, please report to the IT support services directly and bring identification with you.
<G-vec00355-002-s495><bring.(sich)_nehmen><de> Wenden Sie sich dafür persönlich an den IT-Support und nehmen Sie zwecks eindeutiger Identifikation einen Ausweis mit.
<G-vec00355-002-s496><bring.(sich)_nehmen><en> The parents left you to decide what to bring and which foods to eat.
<G-vec00355-002-s496><bring.(sich)_nehmen><de> Die Eltern wollen dass Sie entscheiden was zu nehmen und welche Lebensmittel zu essen.
<G-vec00355-002-s497><bring.(sich)_nehmen><en> You may bring your own food on board if you follow the safety regulation with regard to carry-on baggage.
<G-vec00355-002-s497><bring.(sich)_nehmen><de> Sie können Ihre eigene Verpflegung mit an Bord nehmen, wenn Sie die Sicherheitsbestimmungen für Handgepäck befolgen.
<G-vec00355-002-s498><bring.(sich)_nehmen><en> I plan to bring my family to Sydney so that we will have a vacation time after the conference.
<G-vec00355-002-s498><bring.(sich)_nehmen><de> Ich will meine Familie mit zur Veranstaltung in Miami nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00355-002-s499><bring.(sich)_nehmen><en> Bring your swimsuit; A Victory Inn & Suites Phoenix North has an outdoor swimming pool.
<G-vec00355-002-s499><bring.(sich)_nehmen><de> Nehmen Sie ein Bad im Pool, Sie werden sicherlich mögen, dass das A Victory Inn & Suites Phoenix North ein Außenpool hat.
<G-vec00355-002-s500><bring.(sich)_nehmen><en> Bring it anywhere: the elegant finish in brushed metal makes it an elegant and classy accessory.
<G-vec00355-002-s500><bring.(sich)_nehmen><de> Nehmen Sie ihn überall mit hin: Die elegante Oberfläche aus gebürstetem Metall macht ihn zu einem edlen und stilvollen Accessoire.
<G-vec00355-002-s501><bring.(sich)_nehmen><en> Bring your iPhone with you.
<G-vec00355-002-s501><bring.(sich)_nehmen><de> Nehmen Sie Ihr iPhone mit.
<G-vec00355-002-s502><bring.(sich)_nehmen><en> In most countries, the transit authorities allow you to bring food through the security screening and on board.
<G-vec00355-002-s502><bring.(sich)_nehmen><de> Essen, welches die Bordsecurity erlaubt In den meisten Ländern erlaubt einem das Sicherheitspersonal, Essen durch die Kontrolle mit an Bord zu nehmen.
<G-vec00355-002-s503><bring.(sich)_nehmen><en> Bring your iPhone along to see pace and distance.
<G-vec00355-002-s503><bring.(sich)_nehmen><de> Nehmen Sie Ihr iPhone mit, um Geschwindigkeit und zurückgelegte Strecke zu messen.
<G-vec00355-002-s504><bring.(sich)_nehmen><en> When we bring our testosterone levels to a high level, the performance of the testosterone is enhanced.
<G-vec00355-002-s504><bring.(sich)_nehmen><de> Wenn wir unsere Testosteronspiegel zu einem hochrangigen Zustand nehmen, werden die oben genannten Merkmale des Testosteronhormons erhöht.
<G-vec00355-002-s505><bring.(sich)_nehmen><en> Bring yourself to do this 3-day private paddle surf course in one of the beaches of Gran Canaria.
<G-vec00355-002-s505><bring.(sich)_nehmen><de> Nehmen Sie an diesem 3-tägigen privaten Paddel-Surfkurs an einem der Strände von Gran Canaria teil.
<G-vec00355-002-s506><bring.(sich)_nehmen><en> Bring as much as you can in your hand luggage, but cut all your barriers to the right size before you fly (at least those you will be carrying in your hand luggage), since you will not always be allowed to bring scissors in your hand luggage.
<G-vec00355-002-s506><bring.(sich)_nehmen><de> Nehmen Sie so viel wie möglich in Ihrem Handgepäck mit, aber schneiden Sie jeden Hautschutz vor dem Flug auf die richtige Größe zu (zumindest diejenigen im Handgepäck), da Scheren im Handgepäck nicht immer erlaubt sind.
<G-vec00355-002-s507><bring.(sich)_nehmen><en> The taste of a holiday at the White Horse Inn can be enjoyed everywhere: with the homemade goods of the White Horse Inn you can bring a slice of Austria back home with you and enjoy traditional Austrian cuisine in your own home.
<G-vec00355-002-s507><bring.(sich)_nehmen><de> Rössl Spezialitäten Den Geschmack eines Urlaubs im Hotel Weisses Rössl können Sie nicht nur in St. Wolfgang genießen: Nehmen Sie aus dem Rössl-Shop Hausgemachtes mit – ein Souvenir aus Ihrem Österreich-Urlaub, das den Daheimgebliebenen Freude bereitet.
<G-vec00355-002-s508><bring.(sich)_nehmen><en> Oxea has also announced plans to bring its sixth world-scale carboxylic acids production plant on stream in 2021.
<G-vec00355-002-s508><bring.(sich)_nehmen><de> Zudem plant das Unternehmen, im Jahr 2021 seine sechste Großanlage zur Herstellung von Carbonsäuren in Betrieb zu nehmen.
<G-vec00355-002-s509><bring.(sich)_nehmen><en> Then bring the ball down across your body to your right hip, bending your elbows, again without rotating your head or chest.
<G-vec00355-002-s509><bring.(sich)_nehmen><de> Nehmen Sie ihre rechte Hand an die rechte Hüfte, oder legen Sie den Arm gerade rechts am Körper einfach ab.
<G-vec00355-002-s510><bring.(sich)_nehmen><en> Bring SmartCharge with you wherever you go.
<G-vec00355-002-s510><bring.(sich)_nehmen><de> Nehmen Sie SmartCharge mit.
<G-vec00355-002-s511><bring.(sich)_nehmen><en> To bring your Guide Dog into the cabin, please download and fill out the Application Form Guide Dog and send the completed form to KLMCARES@KLM.com.
<G-vec00355-002-s511><bring.(sich)_nehmen><de> Um Ihren Blindenhund mit in die Kabine zu nehmen, laden Sie bitte das Antragsformular Blindenhund herunter und füllen Sie es aus und senden dieses ausgefüllt anKLMCARES@klm.com.
<G-vec00355-002-s512><bring.(sich)_nehmen><en> Bring them ALL safely.
<G-vec00355-002-s512><bring.(sich)_nehmen><de> Nehmen Sie einfach alle mit.
<G-vec00355-002-s019><bring.bewirken><en> The Church Fathers strongly affirmed the faith of the Church in the efficacy of the Word of Christ and of the action of the Holy Spirit to bring about this conversion.
<G-vec00355-002-s019><bring.bewirken><de> Die Kirchenväter betonten entschieden den Glauben der Kirche, daß das Wort Christi und das Walten des Heiligen Geistes so wirkkräftig sind, daß sie diese Verwandlung zu bewirken vermögen.
<G-vec00355-002-s020><bring.bewirken><en> Sound development policies sustained by substantial development aid are crucial, yet they will not in themselves bring about any change unless they are effectively converted into concrete and coherent development action.
<G-vec00355-002-s020><bring.bewirken><de> Vernünftige entwicklungspolitische Konzepte, die sich auf substanzielle Hilfeleistungen stützen, sind von entscheidender Bedeutung, können aber nur Veränderungen bewirken, wenn sie in konkrete und kohärente Entwicklungsmaßnahmen umgesetzt werden.
<G-vec00355-002-s021><bring.bewirken><en> "The Atlas Copco ER heat recovery systems do not only achieve energy conservation, they also bring an ROI.
<G-vec00355-002-s021><bring.bewirken><de> "Die ER-Wärmerückgewinnungssysteme von Atlas Copco sind nicht nur für Energieeinsparungen verantwortlich, sie können auch eine schnelle Amortisation bewirken.
<G-vec00355-002-s022><bring.bewirken><en> The medical volunteer program is not designed to interfere with the Thai healthcare system or bring about major changes.
<G-vec00355-002-s022><bring.bewirken><de> Das medizinische Programm zielt nicht darauf ab, Eingriffe in das thailändische Gesundheitssystem zu bewirken oder größere Veränderungen herbeizuführen.
<G-vec00355-002-s023><bring.bewirken><en> They solve problems and can bring about profound changes in economy and society by implementing creative ideas.
<G-vec00355-002-s023><bring.bewirken><de> Sie lösen Probleme und können durch die Umsetzung kreativer Ideen einen tiefgreifenden Wandel in Wirtschaft und Gesellschaft bewirken.
<G-vec00355-002-s024><bring.bewirken><en> Be “not ashamed” to bring before the power of God, through your prayers, the miseries of mankind.
<G-vec00355-002-s024><bring.bewirken><de> Seid „schamlos“, schämt euch nicht, mit dem Gebet zu bewirken, dass das Elend der Menschen sich der Macht Gottes annähere.
<G-vec00355-002-s025><bring.bewirken><en> The measurement of the result of what love and charity may bring into the world is impossible.
<G-vec00355-002-s025><bring.bewirken><de> Man kann gar nicht ermessen, was Liebe und Nächstenliebe in der Welt bewirken können.
<G-vec00355-002-s026><bring.bewirken><en> For at least some of the hearers, however, the distressing call to repentance of the two servants of Christ will bring about true repentance.
<G-vec00355-002-s026><bring.bewirken><de> Bei einigen Einzelnen wird die erschütternde Bußpredigt der beiden Knechte Christi echte Buße bewirken.
<G-vec00355-002-s027><bring.bewirken><en> If a social justice movement manages to bring about real change in society, as is the case with animal protection, then it can be beaten down.
<G-vec00355-002-s027><bring.bewirken><de> Sollte eine soziale Bewegung eine echte Veränderung in der Gesellschaft bewirken, wie das der Tierschutzbewegung zunehmend gelungen ist, dann kann sie auf diese Weise zerschlagen werden.
<G-vec00355-002-s028><bring.bewirken><en> Temporary binders:Temporary binders bring about an increase in mechanical resistance at the surface of glazes and engobes hence leading to an improved touch-resistant finish.
<G-vec00355-002-s028><bring.bewirken><de> Temporäre Bindemittel:Temporäre Bindemittel bewirken eine Erhöhung der mechanischen Festigkeit an der Oberfläche von Glasuren und Engoben und führen zu einer Verbesserung der Grifffestigkeit.
<G-vec00355-002-s029><bring.bewirken><en> The codes of conduct envisaged will not bring a new balance into trade relations.
<G-vec00355-002-s029><bring.bewirken><de> Die ins Auge gefassten Verhaltenskodizes werden kein neues Gleichgewicht in den Handelsbeziehungen bewirken.
<G-vec00355-002-s030><bring.bewirken><en> The Dharma Gem refers to the states in which suffering and the causes for suffering have been removed forever and these evolving Buddha-nature networks have been activated and energized to the point at which they can bring about these states of removal.
<G-vec00355-002-s030><bring.bewirken><de> Das Dharma-Juwel bezieht sich auf Zustände, in denen das Leiden und die Ursachen des Leidens für immer beseitigt worden sind und die sich entwickelnden Buddha-Natur-Netzwerke aktiviert und bis zu dem Punkt hin angeregt worden sind, dass sie diese Zustände der Beseitigung bewirken.
<G-vec00355-002-s031><bring.bewirken><en> Daily application in the morning and evening is enough to start to bring about real improvement in joint pain in two to four weeks.
<G-vec00355-002-s031><bring.bewirken><de> Tägliches Auftragen morgens und abends ist ausreichend, um schon nach zwei bis 10 Tagen eine deutliche Verbesserung der Gelenkschmerzen bewirken zu können.
<G-vec00355-002-s032><bring.bewirken><en> A growing number of regulations—such as the recent European reporting obligation—come into play precisely to strengthen business responsibility and bring about change.
<G-vec00355-002-s032><bring.bewirken><de> Immer mehr Regularien – wie zuletzt die europäische Berichtspflicht – setzen hier an, um unternehmerische Verantwortung zu stärken und Veränderung zu bewirken.
<G-vec00355-002-s033><bring.bewirken><en> And you can bring about change: Send directly from your Android Phone a protest email to the manufacturer.
<G-vec00355-002-s033><bring.bewirken><de> Und Du kannst Veränderung bewirken: Schicke direkt von Deinem Android Phone eine Protestmail an den Hersteller.
<G-vec00355-002-s034><bring.bewirken><en> To this end, effective movement patterns will be selected for you, which will not only bring about progress in the actual training session but also in your everyday life, and also cause noticeable positive changes in your performance in other sports.
<G-vec00355-002-s034><bring.bewirken><de> Wesentlich im HOC – House Of Calisthenics Trainingskonzept ist die grundsätzliche Übertragbarkeit in den Alltag: Daher werden für dich effektive Bewegungsmuster ausgewählt, die nicht nur in der eigentlichen Trainingseinheit einen Fortschritt bewirken, sondern sich auch in deinem Alltag oder bei anderen Sportarten positiv bemerkbar machen.
<G-vec00355-002-s035><bring.bewirken><en> If the law has to change litigation has been identified as one of the tools that can bring about reform in this area.
<G-vec00355-002-s035><bring.bewirken><de> Will man das Rechtssystem ändern, erweisen sich Gerichtsverfahren als ein sinnvolles Mittel um Reformen in diesem Bereich zu bewirken.
<G-vec00355-002-s036><bring.bewirken><en> They bring about an expression of fatigue, accentuate the age and thus provoke a negative visual impression.
<G-vec00355-002-s036><bring.bewirken><de> Sie bewirken einen Ausdruck von Müdigkeit und Alter und rufen damit einen negativen Gesichtseindruck hervor.
<G-vec00355-002-s037><bring.bewirken><en> Isolation and withdrawing into one's own interests are never the way to restore hope and bring about a renewal. Rather, it is closeness, it is the culture of encounter.
<G-vec00355-002-s037><bring.bewirken><de> Die Isolierung und das Verschlossensein in sich selbst oder die eigenen Interessen sind nie der Weg, um wieder Hoffnung zu geben und Erneuerung zu bewirken, wohl aber die Nähe, die Kultur der Begegnung.
<G-vec00355-002-s038><bring.bieten><en> We only bring you the best quality acrylic bathtubs, massage tubs, hot tub,spa pool, outdoor tub and shower trays available in the world.
<G-vec00355-002-s038><bring.bieten><de> Wir bieten Ihnen nur die besten Acrylbadewannen, Massagewannen, Whirlpools, Whirlpools, Whirlpools und Duschwannen der Welt.
<G-vec00355-002-s039><bring.bieten><en> Vulkan Vegas Casino combines a unique gaming experience with a rich medieval theme to bring the player world-class entertainment at all times.
<G-vec00355-002-s039><bring.bieten><de> Das Vulkan Vegas Casino kombiniert ein einzigartiges Spielerlebnis mit einem reichhaltigen mittelalterlichen Thema, um dem Spieler jederzeit erstklassige Unterhaltung zu bieten.
<G-vec00355-002-s040><bring.bieten><en> Open hybrid clouds bring the interoperability, workload portability, and flexibility of open source to hybrid environments.
<G-vec00355-002-s040><bring.bieten><de> Offene Hybrid Clouds bieten die Interoperabilität, Workload-Portabilität und Flexibilität der Open Source-Technologie für Hybrid-Umgebungen.
<G-vec00355-002-s041><bring.bieten><en> In order to bring our customers new products, we occasionally place a few of our premium Christmas trees on clearance.
<G-vec00355-002-s041><bring.bieten><de> Um unseren Kunden neue Produkte bieten zu können, veranstalten wir von Zeit zu Zeit einen Ausverkauf unserer hochwertigen Weihnachtsbäume.
<G-vec00355-002-s042><bring.bieten><en> Server profile templates bring the power of 'infrastructure-as-code' to help you easily control multiple server profiles.
<G-vec00355-002-s042><bring.bieten><de> Serverprofilvorlagen bieten die Vorteile von „Infrastruktur als Code“-Lösungen, sodass Sie problemlos mehrere Serverprofile kontrollieren können.
<G-vec00355-002-s043><bring.bieten><en> This means you need to have central dashboards that bring all relevant information together for your staff to monitor and that you need to keep the customer informed throughout.
<G-vec00355-002-s043><bring.bieten><de> Das heißt, Sie müssen zentrale Dashboards haben, die Ihren Mitarbeitern alle relevanten Informationen zur Überwachung bieten und mit denen Sie die Kunden umfassend informieren.
<G-vec00355-002-s044><bring.bieten><en> One of the most critically acclaimed games in history, Call of Duty®4: Modern Warfare®, is back, remastered in true high-definition featuring enhanced textures, physically based rendering, high-dynamic range lighting and much more to bring a new generation experience to fans.
<G-vec00355-002-s044><bring.bieten><de> Mit Call of Duty®4: Modern Warfare® kehrt eines der beliebtesten Spiele der Geschichte in atemberaubendem HD mit verbesserten Texturen, physikalischem Rendering, HDR-Ausleuchtung und vielem mehr zurück, um einer neuen Generation von Fans dieses einmalige Erlebnis zu bieten.
<G-vec00355-002-s045><bring.bieten><en> Over the coming months, we’ll bring you fascinating content about some of Eurovision’s biggest stars.
<G-vec00355-002-s045><bring.bieten><de> In den kommenden Monaten bieten wir euch faszinierende Inhalte zu einigen der größten ESC-Stars.
<G-vec00355-002-s046><bring.bieten><en> These meetings bring a different approach.
<G-vec00355-002-s046><bring.bieten><de> Diese Treffen bieten eine andere Sicht.
<G-vec00355-002-s047><bring.bieten><en> We are a full live-service studio, with a team committed to producing the very best in mobile gaming, whilst striving to create, innovate and challenge the status quo to bring the most engaging games to our players.
<G-vec00355-002-s047><bring.bieten><de> Wir sind ein vollwertiges Live-Service-Studio mit einem Team, das es sich zur Aufgabe gemacht hat, beste Qualität im Mobile Gaming zu liefern, den Status Quo herauszufordern und unseren Spielern innovative und packende Spiele zu bieten.
<G-vec00355-002-s048><bring.bieten><en> These four temperature zones and the flexibility they bring make the Royal a unique model in our range.
<G-vec00355-002-s048><bring.bieten><de> Diese vier Temperaturzonen bieten höchstmögliche Flexibilität und machen dieses Gerät in unserem Sortiment einmalig.
<G-vec00355-002-s049><bring.bieten><en> In fact, we have made it our mission to achieve the best results available by exploring all avenues and possibilities to bring you the most viable commercial solutions.
<G-vec00355-002-s049><bring.bieten><de> In der Tat haben wir es uns zur Aufgabe gemacht, die besten verfügbaren Ergebnisse zu erzielen, indem wir alle Wege und Möglichkeiten ergründen, um Ihnen die wirtschaftlichsten Lösungen zu bieten.
<G-vec00355-002-s050><bring.bieten><en> From high-quality, whole slide scanners to data management software and powerful image analysis, we bring you the most comprehensive solution for digital pathology.
<G-vec00355-002-s050><bring.bieten><de> Wir bieten Ihnen die umfangreichste Lösung für Digitalpathologie, angefangen von hochwertigen Whole-Slide-Scannern bis hin zur Software für Datenmanagement und leistungsstarken Bildanalysen.
<G-vec00355-002-s051><bring.bieten><en> We bring the best data science to search. Use AI and data integrations to make search marketing about strategy instead of best guesses.
<G-vec00355-002-s051><bring.bieten><de> Wir bieten die beste datenwissenschaftliche Grundlage für Nutzen Sie KI- und Datenintegrationen, um beim Search Marketing Management strategisch vorgehen zu können, anstatt sich auf Vermutungen zu stützen.
<G-vec00355-002-s052><bring.bieten><en> Our mission is to bring you top-of-the-line managed WordPress hosting without compromises.
<G-vec00355-002-s052><bring.bieten><de> Unsere Mission ist es, dir erstklassiges Managed WordPress Hosting ohne Kompromisse zu bieten.
<G-vec00355-002-s053><bring.bieten><en> Though we think that the software is ready to be used in real animation workflows, but we would like more input from you to bring it to the level of completeness and quality that you’ve come to expect from Adobe creative applications.
<G-vec00355-002-s053><bring.bieten><de> Auch wenn Character Animator unserer Meinung nach bereit für die Verwendung in realen Animationsarbeitsabläufen ist, wissen wir jedoch auch, dass wir mehr Feedback von Ihnen benötigen, um Ihnen die Vollständigkeit und Qualität zu bieten, die Sie von Kreativanwendungen von Adobe gewohnt sind.
<G-vec00355-002-s054><bring.bieten><en> Whatever may bring you to Madrid, a convenient and safe transfer from Madrid Airport will ensure that your trip starts in the best possible way.
<G-vec00355-002-s054><bring.bieten><de> Egal, ob Sie geschäftlich oder privat unterwegs sind, wir bieten Ihnen einen bequemen und erschwinglichen Flughafentransfer vom Flughafen Madrid-Barajas an.
<G-vec00355-002-s055><bring.bieten><en> Promoting competition will ultimately bring better value to customers.
<G-vec00355-002-s055><bring.bieten><de> Die Förderung des Wettbewerbs wird letztendlich den Kunden einen besseren Wert bieten.
<G-vec00355-002-s056><bring.bieten><en> Our rooms bring the coziness and comfort with free WIFI, Internet free, 32" LCD TV with cable channels, iPod dock, safety box, tea and coffee maker.
<G-vec00355-002-s056><bring.bieten><de> Unsere Zimmer bieten mit kostenlosem WIFI, 32-Zoll-LCD-Fernseher mit Kabelkanälen, iPod-Dock, Safe, Tee- und Kaffeekocher Gemütlichkeit und Komfort.
<G-vec00355-002-s304><bring.bringen><en> Visitors are not allowed to drive directly to the house, but we will bring your baggage there for you .
<G-vec00355-002-s304><bring.bringen><de> Es besteht keine Fahrmöglichkeit für Sie zum Haus, allerdings wird das Gepäck von uns mit Ihnen hoch gebracht.
<G-vec00355-002-s305><bring.bringen><en> He was playing his acoustic guitar while she was standing at the doors, waiting for the tour manager to bring her to the band.
<G-vec00355-002-s305><bring.bringen><de> Er spielte auf seiner akustischen Gitarre, während sie an der Tür stand und darauf wartete, dass sie vom Tourmanager zur Band gebracht wurde.
<G-vec00355-002-s306><bring.bringen><en> Unfortunately the dress a tad too big and therefore it will be my first piece of clothing, ever that I will bring to the tailor.
<G-vec00355-002-s306><bring.bringen><de> Leider ist es mir ein wenig groß und so wird dieses Kleid mein erstes Stück sein, welches ich jemals zum Schneider gebracht habe.
<G-vec00355-002-s307><bring.bringen><en> Fixed network penetration peaked at around 32%, falling back slightly in response to recent price changes designed to bring prices more closely into line with costs as required by the acquis.
<G-vec00355-002-s307><bring.bringen><de> Die Anschlussdichte im Festnetz erreichte einen Höchststand von etwa 32 % und ging als Reaktion auf die jüngsten Tarifänderungen, mit denen die Tarife entsprechend den Vorgaben des Besitzstands in größere Übereinstimmung mit den echten Kosten gebracht werden sollen, leicht zurück.
<G-vec00355-002-s308><bring.bringen><en> 7:52, He asked to bring him to his home for one night.
<G-vec00355-002-s308><bring.bringen><de> 7:52 Er bat darum, für eine Nacht nach Hause gebracht zu werden.
<G-vec00355-002-s309><bring.bringen><en> But that has nearly nothing to do with my work on land and that did not bring me to deep-sea taxonomy.
<G-vec00355-002-s309><bring.bringen><de> Mit meiner täglichen Arbeit an Land hat das aber natürlich wenig zu tun und dieser Anreiz allein hat mich auch nicht zur Tiefsee-Taxonomie gebracht.
<G-vec00355-002-s310><bring.bringen><en> But the borrower did not bring nor did he deposit any money, since he came to the bank to get money he did not have.
<G-vec00355-002-s310><bring.bringen><de> Der Darlehensnehmer hat es jedoch weder gebracht noch eingezahlt, da er gekommen ist, um Geld zu holen, das er nicht besaß.
<G-vec00355-002-s311><bring.bringen><en> We continued to bring new and further stages of technical developments into the car in the second half of the season, but unfortunately they didn’t produce the performance gains we expected.
<G-vec00355-002-s311><bring.bringen><de> Wir haben auch in der zweiten Saisonhälfte technische Neu- und Weiterentwicklungen gebracht, sie haben aber leider nicht den erwarteten Zuwachs an Performance gebracht.
<G-vec00355-002-s312><bring.bringen><en> For this reason, it was first necessary to bring the different volumes of individual works to a unified level, as the volume can’t constantly be turned up and down on an aircraft, of course.
<G-vec00355-002-s312><bring.bringen><de> Daher mussten zunächst die unterschiedlichen Laufstärke der einzelnen Werke auf ein einheitliches Niveau gebracht werden, da man im Flugzeug natürlich nicht ständig lauter und leiser drehen kann.
<G-vec00355-002-s313><bring.bringen><en> Under the slogan “Bring it today, best in the morning, collect it tomorrow or already this evening”, W. Klinger is able to promise customers a highly appreciated full service.
<G-vec00355-002-s313><bring.bringen><de> Nach dem Motto: „Heute oder morgens gebracht, morgen oder schon abends gemacht“ bietet W. Klinger einen bei den Kunden gefragten Fullservice.
<G-vec00355-002-s314><bring.bringen><en> 3 And he proceeded to bring me there, and, look! there was a man.
<G-vec00355-002-s314><bring.bringen><de> 3 Als er mich dorthin gebracht hatte, erschien plötzlich ein Mann, der glänzend wie Erz aussah.
<G-vec00355-002-s315><bring.bringen><en> 11 Your gates shall be open continually; day and night they shall not be shut, that people may bring to you the wealth of the nations, with their kings led in procession.
<G-vec00355-002-s315><bring.bringen><de> 11 Deine Tore sollen stets offen stehen und weder Tag noch Nacht zugeschlossen werden, dass der Reichtum der Völker zu dir gebracht und ihre Könige herzugeführt werden.
<G-vec00355-002-s316><bring.bringen><en> There is a wheelchair available on all ships to use exclusively to bring the passenger into the cabin.
<G-vec00355-002-s316><bring.bringen><de> Auf allen Schiffen steht ein Rollstuhl zur Verfügung, den die Passagiere ausschließlich dafür nutzen können, in die Kabine gebracht zu werden.
<G-vec00355-002-s317><bring.bringen><en> It did not bring about a real social reform, although it became for the whole world a powerful threat and a challenge.
<G-vec00355-002-s317><bring.bringen><de> Er hat keine wirkliche Sozialreform zuwege gebracht, obwohl er für die ganze Welt zu einer mächtigen Bedrohung und einer Herausforderung geworden ist.
<G-vec00355-002-s318><bring.bringen><en> Hidden from view beneath the product surface of all highly complicated electronic systems is the pressure to develop at an acceptable price, manufacture and bring onto the market an utterly reliable as well as energy efficient product.
<G-vec00355-002-s318><bring.bringen><de> Für das Auge meist unsichtbar unter der Produktoberfläche verborgen, müssen elektronische Systeme mit höchster Komplexität in extrem kurzer Zeit zu einem akzeptablen Preis entworfen, hergestellt und auf den Markt gebracht werden und absolut zuverlässig sowie energieeffizient funktionieren.
<G-vec00355-002-s319><bring.bringen><en> Changing the page order within a PDF and then saving did not bring the desired effect.
<G-vec00355-002-s319><bring.bringen><de> Das Ändern der Seitenreihenfolge innerhalb einer PDF und das anschließende Speichern hat nicht den gewünschten Effekt gebracht.
<G-vec00355-002-s320><bring.bringen><en> I could rescue all my books and bring them back to Germany.
<G-vec00355-002-s320><bring.bringen><de> Meine sämtlichen Bücher habe ich gerettet und mit nach Deutschland gebracht.
<G-vec00355-002-s321><bring.bringen><en> Afterall, everyone wants that unique piece to bring back home.
<G-vec00355-002-s321><bring.bringen><de> Schließlich möchte jeder, dass dieses einzigartige Stück nach Hause gebracht wird.
<G-vec00355-002-s322><bring.bringen><en> We hope that these pages, which are constantly updated in order to bring you the very latest on our holiday menu, will help you plan your stay in advance.
<G-vec00355-002-s322><bring.bringen><de> Wir hoffen das diese Seiten, die ständig auf den neusten Stand gebracht werden, ihnen helfen werden ihren Aufenthalt so angenehm wie möglich im Voraus zu gestalten.
<G-vec00355-002-s171><bring.einbringen><en> If this recommendation is not followed, the Committee can bring the case to the ERGO Board of Management.
<G-vec00355-002-s171><bring.einbringen><de> Wird dieser Empfehlung nicht gefolgt, kann das Gremium den Fall in den ERGO Vorstand einbringen.
<G-vec00355-002-s172><bring.einbringen><en> This webinar dives deeper into Amazon SageMaker, with demos on using neural networks and embeddings for recommendations, and how you can bring your own R algorithm using the sample Juptyer notebooks to get you started.
<G-vec00355-002-s172><bring.einbringen><de> Dieses Webinar verschafft mit seinen Demos zur Nutzung neuronaler Netzwerke und empfohlenen Einbettungsmöglichkeiten tiefere Einblicke in Amazon SageMaker und zeigt, wie Sie zum Einstieg Ihren eigenen R-Algorithmus unter Verwendung der Juptyer-Notebooks einbringen.
<G-vec00355-002-s173><bring.einbringen><en> The earlier we get involved in a project, the better we can bring in our experience in the critical, early project stage.
<G-vec00355-002-s173><bring.einbringen><de> Je früher wir dabei in Ihr Projekt involviert werden, desto mehr Erfahrung können wir bereits in den besonders wichtigen, frühen Projektphasen einbringen.
<G-vec00355-002-s174><bring.einbringen><en> Wind or draft may bring microorganisms that can contaminate the Mondo® 'B+' XL Magic Mushroom grow kit.
<G-vec00355-002-s174><bring.einbringen><de> Wind oder Zugluft kann Mikroorganismen einbringen, die das Psilocybe cubensis Albino A+ XL Zauberpilze Growkit kontaminieren können.
<G-vec00355-002-s175><bring.einbringen><en> At first, members of the university should bring documents to the library network, which is why the university is entered standardly.
<G-vec00355-002-s175><bring.einbringen><de> Zunächst sollen nur Angehörige der Universität Dokumente in den Publikationsverbund einbringen, deshalb ist diese Hochschule als Standardwert eingetragen.
<G-vec00355-002-s176><bring.einbringen><en> Our aim is to bring our award-winning expertise in the film and automobile sectors to bear on other industries.
<G-vec00355-002-s176><bring.einbringen><de> Wir wollen unsere preisgekrönte Expertise aus der Film- und Automobilbranche für andere Branchen gewinnbringend einbringen.
<G-vec00355-002-s177><bring.einbringen><en> And that I can bring in my ideas and that the team can turn ideas into reality.
<G-vec00355-002-s177><bring.einbringen><de> Und dass ich meine Ideen einbringen kann und wir sie gemeinsam im Team verwirklichen.
<G-vec00355-002-s178><bring.einbringen><en> If interested, please contact the respective representative of your state group in order to bring the proposals in the faculty can.
<G-vec00355-002-s178><bring.einbringen><de> Bei Interesse wenden Sie sich bitte an die jeweiligen Vertreter Ihrer Statusgruppe, um die Vorschläge im Fachbereichsrat einbringen zu können.
<G-vec00355-002-s179><bring.einbringen><en> So everyone can bring in their own ideas from day one and actively help to shape the company's development.
<G-vec00355-002-s179><bring.einbringen><de> So kann auch jeder vom ersten Tag an eigene Ideen einbringen und die Unternehmensentwicklung aktiv mitgestalten.
<G-vec00355-002-s180><bring.einbringen><en> Wind or draft may bring microorganisms that can contaminate the Psilocybe cubensis XL Magic Mushroom grow kit.
<G-vec00355-002-s180><bring.einbringen><de> Wind oder Zugluft kann Mikroorganismen einbringen, die das Psilocybe cubensis XL Zauberpilze Growkit kontaminieren können.
<G-vec00355-002-s181><bring.einbringen><en> But I can see that it’s certainly possible to bring dissenting views to the debate and that they will be listened to.
<G-vec00355-002-s181><bring.einbringen><de> Ich sehe aber, dass man durchaus abweichende Standpunkte in die Debatte einbringen kann und dass dabei auch zugehört wird.
<G-vec00355-002-s182><bring.einbringen><en> In Italy there is very intensive economic development underway, that is supposed to bring the bosses immense profits, with the consequence of enormous increases in the accumulation.
<G-vec00355-002-s182><bring.einbringen><de> In Italien ist eine sehr intensive wirtschaftliche Entwicklung in Gang, die der Unternehmerschaft immense Profite einbringen soll, mit der Folge, daß die Akkumulation gewaltig anwächst.
<G-vec00355-002-s183><bring.einbringen><en> Both of them understand exactly where we’re coming from and know how to contribute ideas that bring new, beneficial aspects to the project.
<G-vec00355-002-s183><bring.einbringen><de> Beide verstehen genau, woher wir kommen und wissen wie sie Ideen einbringen können, die neue, vorteilhafte Aspekte zum Projekt hinzufügen.
<G-vec00355-002-s184><bring.einbringen><en> No sooner said than done, a “Doodle” is launched for setting up a meeting so that everyone can bring his ideas to advance the “Planet 9” folder.
<G-vec00355-002-s184><bring.einbringen><de> Mithilfe eines „Doodle“ wird nach einem Datum für ein Treffen gesucht, an dem jedermann seine Ideen einbringen kann, um die Forschung in Sachen „Planet 9“ weiterzubringen.
<G-vec00355-002-s185><bring.einbringen><en> 5 and it hath been on the sixth day, that they have prepared that which they bring in, and it hath been double above that which they gather day [by] day.'
<G-vec00355-002-s185><bring.einbringen><de> 5 Des sechsten Tages aber sollen sie zurichten, was sie einbringen, und es wird zwiefältig soviel sein, als sie sonst täglich sammeln.
<G-vec00355-002-s186><bring.einbringen><en> Through the built-in annotation feature you can bring yourself directly into the image and graphically communicate your feedback.
<G-vec00355-002-s186><bring.einbringen><de> Durch die integrierte Annotations Funktion können Sie sich direkt im Bild einbringen und Ihr Feedback grafisch übermitteln.
<G-vec00355-002-s187><bring.einbringen><en> We’re all certainly fans of the mid 90’s Swedish bands like Dissection, Dawn, Sacramentum, Unanimated… etc but there’s a lot of other influences and sounds that we bring into our music.
<G-vec00355-002-s187><bring.einbringen><de> Wir sind allesamt Fans von schwedischen Bands wie Dissection, Dawn, Sacramentum, Unanimated usw., aber es gibt viele andere Einflüsse und Sounds, die wir in unsere Musik einbringen.
<G-vec00355-002-s188><bring.einbringen><en> Ireland, Finland, Sweden and the Czech Republic have taken a stance against the plans, which estimates say could bring in as much as €5 billion in tax revenue annually.
<G-vec00355-002-s188><bring.einbringen><de> So haben sich Irland, Finnland, Schweden und die Tschechische Republik gegen die Steuerpläne ausgesprochen, die nach Schätzungen jährlich bis zu fünf Milliarden Euro an Steuereinnahmen einbringen könnten.
<G-vec00355-002-s189><bring.einbringen><en> According to Philip Grant, the Director of TRIAL, “Giorgio Malinverni will bring to TRIAL his wide knowledge of human rights issues which will further enhance its work in favour of the victims.
<G-vec00355-002-s189><bring.einbringen><de> Gemäss Philip Grant, ihrem Direktor: „Giorgio Malinverni wird bei TRIAL sein großes Wissen im Bereich der Menschenrechte sowie eine starke Sichtbarkeit für die Arbeit zur Unterstützung der Opfer einbringen.
<G-vec00355-002-s209><bring.erwecken><en> Humanity’s survival hinges on whether it is possible to bring deserts on the earth back to life.
<G-vec00355-002-s209><bring.erwecken><de> Denn für das Überleben der Menschheit ist es entscheidend, ob es gelingt, Wüsten auf der Erde wieder zum Leben zu erwecken.
<G-vec00355-002-s210><bring.erwecken><en> Despina is able to bring the men back to life.
<G-vec00355-002-s210><bring.erwecken><de> Despina weiß die Scheintoten zu neuem Leben zu erwecken.
<G-vec00355-002-s211><bring.erwecken><en> When He looked at all the works of His hands that had been beaten to death by the enemy He thought: I’ll bring that all back to life.
<G-vec00355-002-s211><bring.erwecken><de> Als Er die Werke betrachtete, die vom Gegner totgeschlagen waren, dachte Er bei sich selbst: Ich werde sie erwecken.
<G-vec00355-002-s212><bring.erwecken><en> Then, we bring the data to life creating the basis for the subsequent implementation of our standard products.
<G-vec00355-002-s212><bring.erwecken><de> Anschließend erwecken wir die Daten zum Leben auf Basis unserer Standardprodukte.
<G-vec00355-002-s213><bring.erwecken><en> Ayahuasca helps to gain insight into yourself, to find (re) find and heal lost soul parts and to bring the inner child to life.
<G-vec00355-002-s213><bring.erwecken><de> Ayahuasca hilft, Einblicke in sich selbst zu gewinnen, verlorene Seelenteile wiederzufinden und zu heilen und das innere Kind zum Leben zu erwecken.
<G-vec00355-002-s214><bring.erwecken><en> Citroën Italia and its “mission impossible”: to bring to life a never-before-seen special series!
<G-vec00355-002-s214><bring.erwecken><de> Citroën Italia stand vor einer ganz besonderen Mission – eine bislang nie gebaute Sonderserie zum Leben zu erwecken.
<G-vec00355-002-s215><bring.erwecken><en> Bring your tour to life with interactive access to never-before seen footage with tour cam
<G-vec00355-002-s215><bring.erwecken><de> Erwecken Sie Ihre Tour zum Leben mit interaktivem Zugang zu noch nie dagewesenem Filmmaterial mit Tour Cam.
<G-vec00355-002-s216><bring.erwecken><en> These "tableaux" bring to life a prophetic world with a corporeal power that permeates the atmosphere of the Museum.
<G-vec00355-002-s216><bring.erwecken><de> Mit ihrer physischen Kraft erwecken diese tableaux eine prophetische Welt, die die Atmosphäre des Museums durchdringt.
<G-vec00355-002-s217><bring.erwecken><en> AUDIO XF’s superb sound systems bring your music to life.
<G-vec00355-002-s217><bring.erwecken><de> Die ausgezeichneten Klangsysteme des Jaguar XF erwecken Ihre Musik zum Leben.
<G-vec00355-002-s218><bring.erwecken><en> Real dealers bring the cards and balls of classic casino games such as Baccarat, Roulette; Casino Hold’em and Blackjack to life.
<G-vec00355-002-s218><bring.erwecken><de> Echte Dealer erwecken die Karten und Bälle von klassischen Casinospielen wie Baccarat, Roulette, Casino Hold’em und Blackjack zum Leben.
<G-vec00355-002-s219><bring.erwecken><en> After all, in the end it is people our customers who bring our products to life.
<G-vec00355-002-s219><bring.erwecken><de> Denn schließlich sind es die Menschen, unsere Kunden, die unsere Produkte zum Leben erwecken.
<G-vec00355-002-s220><bring.erwecken><en> You can bring these solutions with the customer’s employees to life.
<G-vec00355-002-s220><bring.erwecken><de> Sie können diese Lösungen mit den Mitarbeitern des Kunden zum Leben erwecken.
<G-vec00355-002-s221><bring.erwecken><en> His name, the Living Statue meant each one inspired awe, because you saw it, that he could bring himself carved figures to life when he wanted.
<G-vec00355-002-s221><bring.erwecken><de> Sein Name, der Lebendige Statue bedeutete, flößte jedem Ehrfurcht ein, denn man ersah daraus, daß er selbst geschnitzte Figuren zum Leben erwecken konnte, wenn er wollte.
<G-vec00355-002-s222><bring.erwecken><en> IdeaMax puts productivity at the next level to bring your next great idea to life.
<G-vec00355-002-s222><bring.erwecken><de> IdeaMax setzt die Produktivität auf die nächste Stufe, um Ihre nächste große Idee zum Leben zu erwecken.
<G-vec00355-002-s223><bring.erwecken><en> Teespring is the free and easy way to bring your ideas to life.
<G-vec00355-002-s223><bring.erwecken><de> Teespring ist die kostenfreie und einfache Art, um deine Ideen zum Leben zu erwecken.
<G-vec00355-002-s224><bring.erwecken><en> Bring your party to life with style and chic with Meri Meri gorgeous tinsel fringe garland.
<G-vec00355-002-s224><bring.erwecken><de> Erwecken Sie Ihre Party mit Stil und Chic mit der wunderschönen Lametta-Fransengirlande von Meri Meri.
<G-vec00355-002-s225><bring.erwecken><en> This also would help to increase the receptivity to any aid that may be given to him and to bring about the reliance.
<G-vec00355-002-s225><bring.erwecken><de> Das würde auch dazu beitragen, die Empfangsbereitschaft für alle gewährte Hilfe zu erhöhen und das Vertrauen zu erwecken.
<G-vec00355-002-s226><bring.erwecken><en> We can bring this magical paper into life with IT.
<G-vec00355-002-s226><bring.erwecken><de> Dieses magische Papier können wir in der IT zum Leben erwecken.
<G-vec00355-002-s227><bring.erwecken><en> We just want to share our engaging curriculum with you – the educators who will bring it to life.
<G-vec00355-002-s227><bring.erwecken><de> Wir möchten nur unseren engagierten Lehrplan mit Ihnen teilen - die Pädagogen, die ihn zum Leben erwecken werden.
<G-vec00355-002-s266><bring.führen><en> The ministers decided on recommendations for all 27 EU countries regarding sound economic policy and economic reforms that will help bring Europe out of the crisis and boost growth and job creation.
<G-vec00355-002-s266><bring.führen><de> Die Minister einigten sich auf Empfehlungen für alle 27 EU-Länder in Bezug auf eine gesunde Wirtschaftspolitik und Reformen, die Europa aus der Krise führen, das Wachstum ankurbeln und Jobs schaffen sollen.
<G-vec00355-002-s267><bring.führen><en> Yet, the decline could likewise bring about wellness issues given that the body sheds a security layer versus any type of diseases.
<G-vec00355-002-s267><bring.führen><de> Dennoch kann die Abnahme auch zu gesundheitlichen Problemen führen, weil der Körper eine Schutzschicht gegen alle Arten von Krankheiten verliert.
<G-vec00355-002-s268><bring.führen><en> 24 "'I will take you from the nations and gather you from all the countries; then I will bring you to your land.
<G-vec00355-002-s268><bring.führen><de> Denn ich will euch aus den Heiden holen und euch aus allen Landen versammeln und wieder in euer Land führen.
<G-vec00355-002-s269><bring.führen><en> All participants agreed that it makes sense to use such a cooperation as a medium to bring the Earth observation and OSGeo communities closer together.
<G-vec00355-002-s269><bring.führen><de> Alle Beteiligten waren sich darüber einig, dass es sinnvoll ist eine solche Kooperation als Medium zu nutzen, um die Erdbeobachtungs- und die OSGeo-Community enger zusammen zu führen.
<G-vec00355-002-s270><bring.führen><en> Place your fingertips behind your head, lift your upper back off of the mat, and rotate your torso to bring your right elbow toward your left knee.
<G-vec00355-002-s270><bring.führen><de> Drehe deinen Oberkörper, um deinen rechten Ellenbogen zum linken Knie zu führen.
<G-vec00355-002-s271><bring.führen><en> How I labor morning, noon and night to prepare the days lesson and all the connections you must make to bring you to your next appointed times.
<G-vec00355-002-s271><bring.führen><de> Wie Ich am Morgen, am Nachmittag und in der Nacht arbeite, um die Lektionen für den Tag vorzubereiten und all die Verbindungen, die ihr machen müsst, um euch zu euren nächsten Terminen zu führen.
<G-vec00355-002-s272><bring.führen><en> From this it follows, however, that it was precisely on this major question that we had to bring the masses of the workers up against the treachery of the General Council, and that is what we did.
<G-vec00355-002-s272><bring.führen><de> Daraus aber folgt, dass man den Arbeitermassen eben in dieser wichtigsten Frage den Verrat des Generalrats greifbar vor Augen führen musste, was von uns auch getan wurde.
<G-vec00355-002-s273><bring.führen><en> It is Zentrum Paul Klee’s ambitious goal to bring together as many of the three artists‘ works – now scattered across the whole world – and to reveal the fascinating pictorial ‘competition’ that inspired Klee and Macke in particular to produce their supreme artistic achievements.
<G-vec00355-002-s273><bring.führen><de> Es ist das ehrgeizige Ziel des Zentrum Paul Klee, möglichst viele der heute über die ganze Welt verstreuten Arbeiten der drei Künstler zusammen zu führen und den faszinierenden bildnerischen «Wettstreit» zu veranschaulichen, der vor allem Klee und Macke während ihrer Reise zu künstlerischen Höchstleistungen inspirierte.
<G-vec00355-002-s274><bring.führen><en> 5 (UKJV) As also the high priest does bear me witness, and all the estate of the elders: from whom also I received letters unto the brethren, and went to Damascus, to bring them which were there bound unto Jerusalem, in order to be punished.
<G-vec00355-002-s274><bring.führen><de> 5 (ELB) wie auch der Hohepriester und die ganze Ältestenschaft mir Zeugnis gibt, von denen ich auch Briefe an die Brüder empfing und nach Damaskus reiste, um auch diejenigen, die dort waren, gebunden nach Jerusalem zu führen, auf daß sie gestraft würden.
<G-vec00355-002-s275><bring.führen><en> They bring together information and tasks from various systems and automate workflows.
<G-vec00355-002-s275><bring.führen><de> Sie führen Daten und Aufgaben aus verschiedenen Systemen zusammen und automatisieren Workflows.
<G-vec00355-002-s276><bring.führen><en> God's grace working in the heart of an individual may bring about a desire to communicate with someone who understands.
<G-vec00355-002-s276><bring.führen><de> Gottes Gnade, die im Herzen jedes Einzelnen tätig ist, mag zu dem Wunsch führen, mit jemandem zu sprechen, der auch versteht.
<G-vec00355-002-s277><bring.führen><en> While temperatures stay pleasant year-round, hurricane season is a serious threat that may bring in heavy rains (or worse) that can ruin plans.
<G-vec00355-002-s277><bring.führen><de> Während die Temperaturen das ganze Jahr über angenehm bleiben, ist die Hurrikansaison eine ernsthafte Bedrohung, die zu heftigen Regenfällen (oder schlechter) führen kann, die die Pläne ruinieren können.
<G-vec00355-002-s278><bring.führen><en> At the same time it wants to bring Germany to autarky, i.e., onto the road of provincialism and voluntary restriction.
<G-vec00355-002-s278><bring.führen><de> Gleichzeitig will er Deutschland zur Autarkie führen, d.h. auf den Weg des Provinzialismus und der Selbstbeschränkung.
<G-vec00355-002-s279><bring.führen><en> Take the Maienfeld exit and drive towards Bad Ragaz. This will bring you directly to the Grand Resort Bad Ragaz (right after the roundabout on the left side).
<G-vec00355-002-s279><bring.führen><de> Nehmen Sie die Ausfahrt Maienfeld und fahren Sie in Richtung Bad Ragaz, dies wird Sie direkt zum Grand Resort Bad Bad Ragaz führen (nach dem Kreisverkehr auf der linken Seite).
<G-vec00355-002-s280><bring.führen><en> 2 and asked him for letters to the synagogues at Damascus, so that if he found any belonging to the Way, men or women, he might bring them bound to Jerusalem.
<G-vec00355-002-s280><bring.führen><de> 2 und erbat sich von ihm Briefe nach Damaskus an die Synagogen, in der Absicht, wenn er irgendwelche Anhänger des Weges1 fände, ob Männer oder Frauen, sie gebunden nach Jerusalem zu führen.
<G-vec00355-002-s281><bring.führen><en> The task of the enemy is to bring people into corruption by deception, which finally ends with eternal damnation.
<G-vec00355-002-s281><bring.führen><de> Die Aufgabe des Feindes ist durch Täuschung die Menschen ins Verderben zu führen, welche schlussendlich mit der ewigen Verdammnis endet.
<G-vec00355-002-s282><bring.führen><en> Among them the figure of Elijah stands out, impelled by God to bring the people to conversion.
<G-vec00355-002-s282><bring.führen><de> Unter ihnen hebt sich die Gestalt des Elija heraus, der von Gott erweckt wurde, um das Volk zur Umkehr zu führen.
<G-vec00355-002-s283><bring.führen><en> "Cristian will first supervise the challenging development of our next generation core satellite systems, Meteosat Third Generation (MTG) and the EUMETSAT Polar System of Second Generation (EPS-SG), which we expect will bring forecasting of high-impact weather into a new era in the next decade.
<G-vec00355-002-s283><bring.führen><de> „Cristian wird zunächst die anspruchsvolle Entwicklung der nächsten Generation unserer wichtigsten Satellitensysteme, überwachen, von denen wir uns erhoffen, dass sie die Vorhersagen schwerer Wetterphänomene im Laufe des kommenden Jahrzehnts in eine neue Ära führen werden.
<G-vec00355-002-s284><bring.führen><en> The test device is capable of switching currents up to 500 A and includes safety functions which bring the device to a secure state during malfunction.
<G-vec00355-002-s284><bring.führen><de> Der Prüfstand kann Ströme bis zu 500 A schalten und bietet Sicherheitsfunktionen, die das Gerät bei Fehlverhalten in einen sicheren Zustand führen.
<G-vec00355-002-s285><bring.geben><en> On Valentine's Day, couples in Surin in northeastern Thailand can get married on the back of an elephant, which is supposed to bring them good luck.
<G-vec00355-002-s285><bring.geben><de> Am Valentinstag können sich Paare in Surin, im Nordosten von Thailand, auf dem Rücken eines Elefanten während einer traditionellen Zeremonie noch einmal das "Ja-Wort" geben.
<G-vec00355-002-s286><bring.geben><en> Explore sky100's various multimedia exhibits, including a 28-metre-long multimedia story wall and a Sky-High Tech Zone, which uses Augmented Reality (AR) and Virtual Reality (VR) technology to bring a whole new perspective to the city.
<G-vec00355-002-s286><bring.geben><de> Entdecken Sie im sky100 die verschiedenen Multimedia-Exponate, darunter eine 28 Meter lange Multimedia-Story-Wall und eine Sky-High Tech Zone, in der erweiterte Realität (AR) und virtuelle Realität (VR) zum Einsatz kommen, um der Stadt eine völlig neue Perspektive zu geben.
<G-vec00355-002-s287><bring.geben><en> If you would like to enjoy the fish you caught for dinner, please bring the cleaned and gutted fish to the kitchen by no later than 4:30 pm.
<G-vec00355-002-s287><bring.geben><de> Wenn Sie Ihre "Selbstgefangenen" am Abend essen wollen, dann geben Sie den Fisch bis spätestens 16:30 Uhr geputzt und ausgenommen in der Küche ab.
<G-vec00355-002-s288><bring.geben><en> Miriam Corro, HR generalist in Escobedo, Mexico, discovered a career with Avery Dennison where she can develop personally and professionally, and bring her best self to work every day.
<G-vec00355-002-s288><bring.geben><de> Miriam Corro, HR-Generalistin in Escobedo (Mexiko) verfolgt bei Avery Dennison erfolgreich eine berufliche Karriere, bei der sie sich persönlich und beruflich weiterentwickeln und jeden Tag ihr Bestes geben kann.
<G-vec00355-002-s289><bring.geben><en> We bring concrete floor back to life, transforming it from an unpleasant, marked and dusty surface to a perfectly even, highly-resistant and perfectly shining, aestethically beautiful and easy to clean floor.
<G-vec00355-002-s289><bring.geben><de> Wir geben jedem noch so unschönen, fleckigen und staubigen Betonboden neues Leben, verwandeln ihn in eine perfekt glatte, sehr widerstandsfähige, perfekt polierte Oberfläche, schön und pflegeleicht.
<G-vec00355-002-s290><bring.geben><en> We want to bring you only the best updates, and unfortunately that sometimes means taking a little more time to get everything working properly.
<G-vec00355-002-s290><bring.geben><de> Wir wollen euch nur die besten Updates geben und das bedeutet manchmal leider, dass es etwas länger dauert, einem Update den letzten Feinschliff zu verpassen.
<G-vec00355-002-s291><bring.geben><en> Sloping lines, conical shapes and refined details bring a dynamic feel to the design; conveying a typical oriental style.
<G-vec00355-002-s291><bring.geben><de> Schräge Linien, konische Formen und ausgesuchte Details geben der Komposition Dynamik und verleihen ihr einen typisch orientalischen Stil.
<G-vec00355-002-s292><bring.geben><en> The Centre wishes to unite everybody who considers integration to be important, to support immigrants in their new homeland and bring up our children in two cultures.
<G-vec00355-002-s292><bring.geben><de> Das Zentrum möchte alle Menschen, die Integration für wichtig halten, vereinen, allen Zuwanderern in ihrer neuen Heimat Rückenstärkung geben und unsere Kinder in zwei Kulturen erziehen.
<G-vec00355-002-s293><bring.geben><en> We have established our Integrity Line to enable people to bring to our attention any concerns they may have.
<G-vec00355-002-s293><bring.geben><de> Wir haben unsere Integrity Line eingerichtet, um den Menschen die Möglichkeit zu geben, uns über jegliche Bedenken in diesem Zusammenhang zu unterrichten.
<G-vec00355-002-s294><bring.geben><en> Drop the dumplings into boiling salt water; bring to boil and then remove and drain.
<G-vec00355-002-s294><bring.geben><de> Nockerl in sprudelndes Salzwasser geben, kurz aufkochen lassen und dann abschöpfen.
<G-vec00355-002-s295><bring.geben><en> This more lengthy detention would not only extend the silencing of Assange. It would permit the US authorities ample time to bring extradition proceedings, which could take up to three years alone.
<G-vec00355-002-s295><bring.geben><de> Diese längere Haftstrafe würde Assange nicht nur länger zum Schweigen bringen, sondern den US-Behörden auch genug Zeit für ein Auslieferungsverfahren geben, das bis zu drei Jahre dauern könnte.
<G-vec00355-002-s296><bring.geben><en> And say to them, Thus saith the Lord GOD; Behold, I will take the children of Israel from among the heathen, whither they are gone, and will gather them on every side, and bring them into their own land:
<G-vec00355-002-s296><bring.geben><de> 17 Darum sprich: So sagt der HERR HERR: Ich will euch sammeln aus den Völkern und will euch sammeln aus den Ländern, dahin ihr zerstreut seid, und will euch das Land Israel geben.
<G-vec00355-002-s297><bring.geben><en> Bring it with you Built-in rechargeable batteries in both the baby monitor and camera means you can bring your KODAK CHERISH C520 wherever you go.
<G-vec00355-002-s297><bring.geben><de> Nehmen Sie es mit Eingebaute wiederaufladbare Akkus sowohl im Babyphone als auch in der Kamera geben Ihnen die Möglichkeit, Ihr KODAK CHERISH C520 überall hin mitnehmen zu können.
<G-vec00355-002-s298><bring.geben><en> The Angel said: Be not afraid Mary, thou shall bring forth a Son, and thou shall call His name Jesus......
<G-vec00355-002-s298><bring.geben><de> Der Engel sprach: Fürchte dich nicht, Maria, du wirst einen Sohn gebären und du sollst ihm den Namen Jesus geben...
<G-vec00355-002-s299><bring.geben><en> Having been given the gift of a second life, she wants to use it to bring hope to people with HIV, and to fight against stigmatisation.
<G-vec00355-002-s299><bring.geben><de> Dieses zweite Leben will sie nutzen, um anderen Menschen mit HIV Hoffnung zu geben und gegen die Stigmatisierung zu kämpfen.
<G-vec00355-002-s300><bring.geben><en> We are excited to finally be able to bring you the software that will change the way users interact with the website or application you are offering.
<G-vec00355-002-s300><bring.geben><de> Wir freuen uns euch eine Software an die Hand geben zu können, die die Art der Interaktion der Nutzer mit eurer Website oder App maßgeblich verändern wird.
<G-vec00355-002-s301><bring.geben><en> Bring your laundry to the front desk by 8:00 a.m.
<G-vec00355-002-s301><bring.geben><de> Geben Sie Ihre Wäsche bis 8:00 Uhr an der Rezeption ab.
<G-vec00355-002-s302><bring.geben><en> As you can see here, by the end of the morning they are filled with the fun and love that a rose (or a field of them) can bring.
<G-vec00355-002-s302><bring.geben><de> Wie man hier sehen kann, sind sie am Ende des Morgens erfüllt von der Freude und Liebe, die eine Rose (oder ein ganzes Feld davon) geben kann.
<G-vec00355-002-s303><bring.geben><en> Marula Oil: Enriched in vitamins C and D, it provides an intense source of nutrition, antioxidants, to bring to your hair, the nutrients it deserves.
<G-vec00355-002-s303><bring.geben><de> Marulaöl: Angereichert mit Vitaminen C und D, liefert es eine intensive Quelle an Nährstoffen & Antioxidantien, um Ihrem Haar die Nährstoffe zu geben, die es verdient.
<G-vec00355-002-s323><bring.holen><en> The combination of visiting a Japanese motorbike manufacturing plant and lobbying in Washington for import tariffs was a daring move on behalf of Harley's executives in their attempt to bring back profitability and growth to the company.
<G-vec00355-002-s323><bring.holen><de> Die Kombination des Besichtigens einer japanischen Motorradproduktionsanlage und des Beeinflussens in Washington für Importtarife war eine verwegene Bewegung im Namen der Hauptleiter Harleys in ihrem Versuch, Rentabilität und Wachstum zurück zu holen der Firma.
<G-vec00355-002-s324><bring.holen><en> To bring a small diversity of these beautiful objects into reality is what constantly motivates us, and we are always happy about requests for collaboration.
<G-vec00355-002-s324><bring.holen><de> Eine kleine Vielfalt dieser schönen Objekte in die Welt zu holen motiviert uns immer wieder, weshalb wir uns auch immer über Anfragen zur Kooperation freuen.
<G-vec00355-002-s325><bring.holen><en> If any of you are driven out to the farthest parts under heaven, from there YHWH your God will gather you, and from there He will bring you.
<G-vec00355-002-s325><bring.holen><de> 4 Wenn deine Verstoßenen am Ende des Himmels wären, [selbst] von dort wird der HERR, dein Gott, dich sammeln, und von dort wird er dich holen.
<G-vec00355-002-s326><bring.holen><en> "I wanted to keep the team together and I thought it was going to help the ownership bring all the guys back," Durant said.
<G-vec00355-002-s326><bring.holen><de> "Ich wollte, dass das Team zusammen bleibt und dachte, dass dies helfen würde, alle Jungs wieder an Bord zu holen.
<G-vec00355-002-s327><bring.holen><en> He wants to bring jazz to Chemnitz.
<G-vec00355-002-s327><bring.holen><de> Er will den Jazz nach Chemnitz holen.
<G-vec00355-002-s328><bring.holen><en> The purpose of an expert discussion is to bring all parties together aound one table and to enable an exchange of views about new developments.
<G-vec00355-002-s328><bring.holen><de> Das Fachgespräch hat die Aufgabe, alle Parteien an einen Tisch zu holen, um sich gegenseitig über neue Entwicklungen auszutauschen.
<G-vec00355-002-s329><bring.holen><en> Our goal was to bring the Baltic Sea to Berlin, to strengthen its foothold in the capital’s political and media consciousness.
<G-vec00355-002-s329><bring.holen><de> Unser Ziel war es, die Ostsee nach Berlin zu holen, um sie stärker im politischen und medialen Bewußtsein der Hauptstadt zu verankern.
<G-vec00355-002-s330><bring.holen><en> I pleaded with the Germans to bring a doctor, but I do not believe they understood me.
<G-vec00355-002-s330><bring.holen><de> Ich bat die Deutschen darum einen Arzt zu holen, aber ich glaube sie verstanden mich nicht.
<G-vec00355-002-s331><bring.holen><en> 5 So David assembled all Israel together, from the Shihor [the brook] of Egypt even to the entrance of Hamath, to bring the ark of God from Kiriath-jearim.
<G-vec00355-002-s331><bring.holen><de> 5 Also versammelte David das ganze Israel, vom Sihor Ägyptens an, bis man kommt gen Hamath, die Lade Gottes zu holen von Kirjath-Jearim.
<G-vec00355-002-s332><bring.holen><en> Lisa and Manuel came to get Nathan and Catalina to bring them to the dance floor.
<G-vec00355-002-s332><bring.holen><de> In dem Augenblick kamen Manuel und Lisa um sie zum Tanzen zur Strandbar zu holen.
<G-vec00355-002-s333><bring.holen><en> Bring the big match to your home with Football Mode, which uses acoustic data from a Brazilian football stadium.
<G-vec00355-002-s333><bring.holen><de> Mit dem Fußballmodus, für den akustische Daten eines brasilianischen Stadions erfasst wurden, holen Sie sich Fußballlaune ins Wohnzimmer.
<G-vec00355-002-s334><bring.holen><en> From my point of view, it is particularly important that the brands bring the target group to the table – not just as “interns”, but to provide meaningful input.
<G-vec00355-002-s334><bring.holen><de> Besonders wichtig ist aus meiner Sicht, dass die Brands sich die Zielgruppe mit an den Tisch holen – und das nicht als „Praktikanten“, sondern als aussagekräftige Impulsgeber.
<G-vec00355-002-s335><bring.holen><en> Bring yourself a piece of nostalgia into the house with a lamp that is otherwise known only from old banks, law offices and courtrooms.
<G-vec00355-002-s335><bring.holen><de> Holen Sie sich ein Stück Nostalgie ins Haus mit einer Lampe wie man Sie sonst nur aus alten Banken, Kanzleien und Gerichtssälen kennt.
<G-vec00355-002-s336><bring.holen><en> In this book, I bring you in as you bring your marketing into the present and make it a success driver for your company.
<G-vec00355-002-s336><bring.holen><de> In diesem Buch bringe ich Ihnen bei, wie Sie Ihr Marketing in die Gegenwart holen und es zu einem Erfolgstreiber in Ihrem Unternehmen machen.
<G-vec00355-002-s337><bring.holen><en> With this device, users can bring 3D applications into their field of vision by using gestures and voice commands.
<G-vec00355-002-s337><bring.holen><de> Andreas kann 3-D-Anwendungen in sein Blickfeld holen, die er mittels Gesten und Stimmbefehlen steuert.
<G-vec00355-002-s338><bring.holen><en> Apart from that, I want to bring more strong women up onto the stage and to make the fintech sector more feminine.
<G-vec00355-002-s338><bring.holen><de> Darüber hinaus möchte ich gern noch mehr starke Frauen auf die Bühne holen und die Fintech Branche insgesamt weiblicher machen.
<G-vec00355-002-s339><bring.holen><en> The armory is nearby, so you are welcome to pick up your weapon, bring back good old memories of Mercenaries, and kill as many infected creatures as you want.
<G-vec00355-002-s339><bring.holen><de> Die Waffenkammer ist nahe gelegen, also sind Sie willkommen, Ihre Waffe aufzuheben, gute alte Erinnerungen von Söldnern zurück zu holen, und so viele angesteckte Geschöpfe zu töten, die Sie wünschen.
<G-vec00355-002-s340><bring.holen><en> Your understanding will be highly appreciated if our holidays bring any inconveniences.
<G-vec00355-002-s340><bring.holen><de> Ihr Verständnis wird in hohem Grade geschätzt, wenn unsere Feiertage irgendwelche Unannehmlichkeiten holen.
<G-vec00355-002-s341><bring.holen><en> Our gins, juices, whiskeys and wines will bring you back to reality.
<G-vec00355-002-s341><bring.holen><de> Unsere Gins, Whiskeys und Weine holen dich zurück in die Realität.
<G-vec00355-002-s342><bring.kommen><en> We advise clients in researching and creating responsible artificial intelligence, which consists of ethical solutions striving to bring benefit to everyone, including privacy safeguards, excluding partiality factors and striving to upgrade artificial intelligence skills.
<G-vec00355-002-s342><bring.kommen><de> Wir beraten die Kunden bei der Forschung und Schaffung verantwortlicher künstlicher Intelligenz, die aus ethischen Lösungen besteht, die danach streben, allen zugute zu kommen, Datenschutzgarantien einschließen, Befangenheitsfaktoren ausschließen und nach Weiterentwicklung der Kompetenzen der künstlichen Intelligenz streben.
<G-vec00355-002-s343><bring.kommen><en> The Canadian Prairies were once roamed by dinosaurs and a visit to the T.rex Discovery Centre in Eastend will bring you face to face with “Scotty”, one of the most complete dinosaur skeletons of its type in the world.
<G-vec00355-002-s343><bring.kommen><de> Die kanadischen Prärien wurden einst von Dinosauriern durchstreift, und bei einem Besuch im T.rex Discovery Centre in Eastend kommen Sie Angesicht zu Angesicht mit “Scotty”, einem der vollständigsten Dinosaurierskelette seiner Art weltweit.
<G-vec00355-002-s344><bring.kommen><en> This anniversary will bring heads of states, governments, the private sector, civil society, the academic world and global citizens together to push for gender equality.
<G-vec00355-002-s344><bring.kommen><de> Anlässlich dieses Jahrestages kommen Staats- und Regierungschefs, Vertreter der Privatwirtschaft, der Zivilgesellschaft, der Wissenschaft und der Weltbürger zusammen, um sich für die Gleichstellung der Geschlechter einzusetzen.
<G-vec00355-002-s345><bring.kommen><en> Our institute looks into possible technology paths, the role of different energy sources through time or the systemic changes necessary to bring new technologies to market.
<G-vec00355-002-s345><bring.kommen><de> Wie Technologiepfade aussehen könnten, welche Rolle verschiedene Energieträger über den Zeitverlauf einnehmen oder unter welchen systemischen Veränderungen neue Technologien in den Markt kommen, sind Forschungsfragen des Instituts.
<G-vec00355-002-s346><bring.kommen><en> We always say that investments bring along trade.
<G-vec00355-002-s346><bring.kommen><de> Wir sagen immer: Anlagen kommen mit dem Handel.
<G-vec00355-002-s347><bring.kommen><en> They often bring their own champagne and picnic basket to the Champs de Mars to ring in the New Year with friends and family in style.
<G-vec00355-002-s347><bring.kommen><de> Oftmals kommen Sie mit Champagner und Picknickkorb zum Champs de Mars, um dort das neue Jahr mit Familie und Freunden stilvoll zu begrüßen.
<G-vec00355-002-s348><bring.kommen><en> Music & Eye-Tracking - What eye movements, pupil dilation, and blinking activity tell us about musical processing A two-day conference organized by Elke B. Lange and Lauren K. Fink to bring together scholars at the intersection of music and eye-tracking research.
<G-vec00355-002-s348><bring.kommen><de> Konferenz In einer zweitägigen Konferenz, organisiert von Elke B. Lange (Max-Planck-Institut für empirische Ästhetik) und Lauren K. Fink (University of California), kommen internationale Wissenschaftlerinnen und Wissenschaftler an der Schnittstelle von Musik- und Eyetracking-Forschung zusammen.
<G-vec00355-002-s349><bring.kommen><en> This will already bring you quite close to the healthy Mediterranean lifestyle and a healthy diet.
<G-vec00355-002-s349><bring.kommen><de> So kommen Sie dem gesunden, mediterranen Lebensstil und einer gesunder Ernährung schon sehr nahe.
<G-vec00355-002-s350><bring.kommen><en> Added up, our senior consultants bring over 60 years of practical experience to the job.
<G-vec00355-002-s350><bring.kommen><de> Rechnen wir die Praxiserfahrung unserer Senior-Markenberater zusammen, kommen wir auf über 60 Jahre.
<G-vec00355-002-s351><bring.kommen><en> The Hybrid Talks bring experts together on a regular basis to present their experience and knowledge in short lectures.
<G-vec00355-002-s351><bring.kommen><de> Bei den Hybrid Talks kommen regelmäßig Experten zusammen, um in kurzen Vorträgen ihre Erfahrungen und Kenntnisse zu einem Thema vorzustellen.
<G-vec00355-002-s352><bring.kommen><en> 19 For I have chosen him, so that he will direct his children and his household after him to keep the way of the Lord by doing what is right and just, so that the Lord will bring about for Abraham what he has promised him.”
<G-vec00355-002-s352><bring.kommen><de> 19 Denn ich weiß, er wird befehlen seinen Kindern und seinem Hause nach ihm, daß sie des HERRN Wege halten und tun, was recht und gut ist, auf daß der HERR auf Abraham kommen lasse, was er ihm verheißen hat.
<G-vec00355-002-s353><bring.kommen><en> “Our mission at Virgin Pulse is to help organisations create thriving workplace cultures where employees are engaged, supported and empowered to bring their best selves to work, every day.
<G-vec00355-002-s353><bring.kommen><de> Unsere Mission bei Virgin Pulse besteht darin, Unternehmen zu helfen, blühende Arbeitsplatzkulturen zu schaffen, in denen Mitarbeiter sich stärker engagieren und dabei unterstützt und dazu aufgerufen werden, jeden Tag in ihrem bestmöglichen Zustand zur Arbeit zu kommen.
<G-vec00355-002-s354><bring.kommen><en> Please note that if you would like to bring your own motor boat, prior registration by the authorities is needed and it costs Euro 100,00.
<G-vec00355-002-s354><bring.kommen><de> Falls Sie mit Ihrem eigenen Boot kommen möchten, stellen wir gerne einen Anlegeplatz zur Verfügung.
<G-vec00355-002-s355><bring.kommen><en> Thought to strengthen life, bring about prosperity, growth and increase openness.
<G-vec00355-002-s355><bring.kommen><de> Soll das Leben stärken, Reichtum und Wachstum fördern und der Offenheit zugute kommen.
<G-vec00355-002-s356><bring.kommen><en> User leadership will bring new business cases, and then I’ll end up needing more employees, not fewer.
<G-vec00355-002-s356><bring.kommen><de> Denn mit der Nutzerführerschaft kommen die neuen Business-Cases, und damit brauch ich am Ende mehr Mitarbeiter und nicht weniger.
<G-vec00355-002-s357><bring.kommen><en> Clicking on this will bring you back to the overview map at any time.
<G-vec00355-002-s357><bring.kommen><de> Durch Klick auf diese Schaltfläche kommen Sie jederzeit wieder zur Übersicht zurück.
<G-vec00355-002-s358><bring.kommen><en> 19 For I have chosen him, so that he will direct his children and his household after him to keep the way of the Lord by doing what is right and just, so that the Lord will bring about for Abraham what he has promised him.”
<G-vec00355-002-s358><bring.kommen><de> 19 Denn ich habe ihn erkannt, damit er seinen Söhnen und seinem Haus nach ihm befehle, daß sie den Weg des HERRN bewahren, Gerechtigkeit und Recht zu üben, damit der HERR auf Abraham kommen lasse, was er über ihn geredet hat.
<G-vec00355-002-s359><bring.kommen><en> If you don’t want to bring your own boat, there are many boat charter companies who would love to help you out.
<G-vec00355-002-s359><bring.kommen><de> Wenn Sie nicht mit dem eigenen Boot kommen wollen, gibt es zahlreiche Bootvermieter, die Ihnen gerne weiterhelfen.
<G-vec00355-002-s360><bring.kommen><en> No matter if you feel like running or walking, if you bring your Nordic-Walking sticks or not, the Helsana Trail offers something for everyone - and thanks to the useful exercise boards, even advanced athletes might learn something new.
<G-vec00355-002-s360><bring.kommen><de> Touring Tracks forest Ob laufend oder walkend, mit oder ohne Nordic-Walking-Stöcke, auf den Helsana Trails kommen Bewegungsmenschen auf ihre Kosten – und dank der praktischen Übungstafeln können selbst Fortgeschrittene etwas dazulernen.
<G-vec00355-002-s361><bring.lassen><en> (3) to bring to bear the waking will and aspiration on the body in sleep.
<G-vec00355-002-s361><bring.lassen><de> 3. den wachen Willen und das Streben des Wachzustandes auch im Schlaf auf den Körper einwirken zu lassen.
<G-vec00355-002-s362><bring.lassen><en> They use anecdotes and a knowledge of history to portray their city and bring that history to life.
<G-vec00355-002-s362><bring.lassen><de> Mit Anekdoten und geschichtlichem Wissen porträtieren sie ihre Stadt und lassen die Historie lebendig werden.
<G-vec00355-002-s363><bring.lassen><en> ZIEGLER services help bring the world closer together.
<G-vec00355-002-s363><bring.lassen><de> ZIEGLER Dienstleistungen lassen die Welt zusammenrücken.
<G-vec00355-002-s364><bring.lassen><en> From planning outfits for offline or online campaigns, in daily business or while doing trend scouting, I can always bring in own ideas and can actively define standards.
<G-vec00355-002-s364><bring.lassen><de> Ob bei der Planung von Outfits für Online- und Offline-Kampagnen, im Tagesgeschäft oder bei Trendrecherchen, ich kann eigene Ideen einfließen lassen und so vieles selbst mitbestimmen.
<G-vec00355-002-s365><bring.lassen><en> From March 2015 on, duck-girl, caterpillar, and a seal are available in well-assorted gift and toy shops, on the internet, in department stores, and in more than 30 NICI shops to bring holiday feeling to everyone, however rainy or cold it might be outside.
<G-vec00355-002-s365><bring.lassen><de> Ab März 2015 erobern eine Entendame, eine lustige Raupe und ein Seehund den gut sortierten Geschenkartikel- und Spielwaren-Fachhandel, das Internet, die Warenhäuser sowie die über 30 NICI Shops und lassen jeden im kalten Deutschland an ihrem unvergesslichen Urlaubserlebnis teilhaben.
<G-vec00355-002-s366><bring.lassen><en> With a fused interest in technological advancement and a motivation to propel UAV’s to new heights, these two companies have united, combining knowledge and expertise that bring benefits to both companies.
<G-vec00355-002-s366><bring.lassen><de> Mit dem gemeinsamen Interesse am technologischen Fortschritt und der Motivation, UAVs in neue Höhen aufsteigen zu lassen, haben sich diese beiden Unternehmen zusammengeschlossen und kombinieren Wissen und Erfahrung, die beiden Unternehmen zugutekommen.
<G-vec00355-002-s367><bring.lassen><en> 16And the priest shall bring her near, and set her before Jehovah.
<G-vec00355-002-s367><bring.lassen><de> 16 Und der Priester soll sie herantreten lassen und sie vor den HERRN stellen.
<G-vec00355-002-s368><bring.lassen><en> Impressive exhibitions, customs, tradition, large adventure playground and craft demonstrations bring this open-air museum to life. Nature House Salzburg
<G-vec00355-002-s368><bring.lassen><de> Eindrucksvolle Ausstellungen, Brauchtum, Tradition, großer Erlebnisspielplatz und Handwerksvorführungen lassen dieses Freilichtmuseum zum leben erwecken.
<G-vec00355-002-s369><bring.lassen><en> What I am asking is that you always look for opportunities to bring up your faith in natural and normal ways with people—both in person as well as online.
<G-vec00355-002-s369><bring.lassen><de> Ich bitte Sie vielmehr darum, stets nach Gelegenheiten Ausschau zu halten, in den Gedankenaustausch mit anderen ganz natürlich und normal einfließen zu lassen, woran Sie glauben – sei es in Person oder online.
<G-vec00355-002-s370><bring.lassen><en> My lords, Matilda here somehow managed to bring a patient of hers back from the dead.
<G-vec00355-002-s370><bring.lassen><de> Meine Herren, Matilda hat es geschafft einen Patienten von den Toten auferstehen zu lassen.
<G-vec00355-002-s371><bring.lassen><en> His research projects answered the question about the forces which create new life and bring it into being.
<G-vec00355-002-s371><bring.lassen><de> Seine Forschungsarbeiten beantworteten die Frage nach den Kräften, die Leben entstehen lassen.
<G-vec00355-002-s372><bring.lassen><en> In fact, many of you have created lots of great circles around topics that interest you (like Photographers) to bring lots of great content to your stream.
<G-vec00355-002-s372><bring.lassen><de> Vielleicht haben Sie viele tolle Circles erstellt, die genau zu Ihrem Geschmack passen, wie in dem Fall von Fotographen, die vielleicht jede Menge interessante Neuigkeiten auf Ihren Datenstrom fließen lassen.
<G-vec00355-002-s373><bring.lassen><en> 6: And he shall bring forth thy righteousness as the light, and thy judgment as the noonday.
<G-vec00355-002-s373><bring.lassen><de> 5 Befiehl dem Herrn deinen Weg, und vertraue auf ihn, so wird er es vollbringen .6 Ja, er wird deine Gerechtigkeit aufgehen lassen wie das Licht und dein Recht wie den hellen Mittag.
<G-vec00355-002-s374><bring.lassen><en> At DJI, we give creators the tools they need to bring their imagination to life.
<G-vec00355-002-s374><bring.lassen><de> Wir von DJI geben Kreativen das Werkzeug um Fantasie lebendig werden zu lassen.
<G-vec00355-002-s375><bring.lassen><en> The goal of the campaign is to bring forgotten crises more strongly into the public focus, strengthen public interest in the humanitarian needs created by forgotten crises, and to bring people involved in forgotten crises the help that they need.
<G-vec00355-002-s375><bring.lassen><de> Ihr Ziel ist es, vergessene Krisen stärker in den Fokus der öffentlichen Wahrnehmung zu rücken und ein am humanitären Bedarf orientiertes öffentliches Interesse zu stärken, um Menschen in Not die erforderliche Hilfe zukommen lassen zu können.
<G-vec00355-002-s376><bring.lassen><en> 6 The same night when Herod was about to bring him out, Peter was sleeping between two soldiers, bound with two chains.
<G-vec00355-002-s376><bring.lassen><de> 6 Und da ihn Herodes wollte vorführen lassen, in derselben Nacht schlief Petrus zwischen zwei Kriegsknechten, gebunden mit zwei Ketten, und die Hüter vor der Tür hüteten das Gefängnis.
<G-vec00355-002-s377><bring.lassen><en> To bring changes within your organization to life, we take your employees by the hand, equip them with important professional knowledge and methodological expertise, and develop their soft skills and leadership skills.
<G-vec00355-002-s377><bring.lassen><de> Um Ihre Veränderungen leben zu lassen, nehmen wir Ihre Mitarbeiter an die Hand, vermitteln ihnen wichtiges Fach- und Methodenwissen und entwickeln deren Sozial- und Führungskompetenzen.
<G-vec00355-002-s378><bring.lassen><en> Exodus 7:5: And the Egyptians will know that I am the LORD when I stretch out my hand against Egypt and bring the Israelites out of it."
<G-vec00355-002-s378><bring.lassen><de> Ex 3,20 Erst wenn ich meine Hand ausstrecke und Ägypten niederschlage mit allen meinen Wundern, die ich in seiner Mitte vollbringe, wird er euch ziehen lassen.
<G-vec00355-002-s379><bring.lassen><en> Tex Gunning, CEO LeasePlan, said: „With our ‚Digital Power of One LeasePlan‘ strategy, we will use the latest technologies to bring our company into the digital world and make LeasePlan’s aspiration of ‚Any car, Anytime, Anywhere‘ a reality.
<G-vec00355-002-s379><bring.lassen><de> „Mit unserer LeasePlan‘ wollen wir die neuesten Technologien nutzen, um unser Unternehmen in die digitale Welt zu integrieren und die Vision ‚Any car, Anytime, Anywhere‘ Realität werden zu lassen“, sagt Tex Gunning, CEO von LeasePlan.
<G-vec00355-002-s380><bring.machen><en> 26:21 And if all of you walk contrary unto me, and will not hearken unto me; I will bring seven times more plagues upon you according to your sins.
<G-vec00355-002-s380><bring.machen><de> 21 Und wo ihr mir entgegen wandelt und mich nicht hören wollt, so will ich's noch siebenmal mehr machen, auf euch zu schlagen um eurer Sünden willen.
<G-vec00355-002-s381><bring.machen><en> RTI is working to bring the proven success of simulation technology in Aerospace and Defense applications to other commercial markets.
<G-vec00355-002-s381><bring.machen><de> RTI will die Vorteile der Simulationstechnologie aus der Luft- und Raumfahrt und Verteidigung auch für andere kommerzielle Märkte zugänglich machen.
<G-vec00355-002-s382><bring.machen><en> The Ballerina Bulldog concept is here to bring joy to children and young people, to motivate them to become conscious of their inner strengths, and to inspire them to be the best version of themselves.
<G-vec00355-002-s382><bring.machen><de> Das Ballerina Bulldogkonzept soll Kindern und Jugendlichen Mut und Freude machen, sie motivieren, sich ihrer inneren Stärke bewusst zu werden und sie dazu zu inspirieren, die beste Ausgabe ihrer selbst zu werden.
<G-vec00355-002-s383><bring.machen><en> The European imperialists are seizing on Erdogan’s massive wave of repression to posture as defenders of civil liberties and bring Erdogan to heel.
<G-vec00355-002-s383><bring.machen><de> Die europäischen Imperialisten greifen Erdogans massive Repressionswelle auf, um sich als Verteidiger bürgerlicher Freiheiten aufzuspielen und Erdogan gefügig zu machen.
<G-vec00355-002-s384><bring.machen><en> Huber also stressed how much commemorating John Calvin could help to bring out the wealth of different denominations in Protestantism, stating, "Traditions are like spectacles: we should look through them, not at them.
<G-vec00355-002-s384><bring.machen><de> Der Ratsvorsitzende hob außerdem hervor, wie sehr das Gedenken an Johannes Calvin dazu helfen könne, die verschiedenen konfessionellen Prägungen des Protestantismus in ihrem Reichtum sichtbar zu machen und führte aus „Traditionen sind wie Brillen: Man soll nicht auf sie starren, sondern durch sie hindurchschauen.
<G-vec00355-002-s385><bring.machen><en> Since 2011 the Council annually honours 100 ideas and projects which bring alive a sustainable way of thought and conduct in everyday life.
<G-vec00355-002-s385><bring.machen><de> Bereits seit 2011 zeichnet der Rat pro Jahr 100 Ideen und Projekte aus, die nachhaltiges Denken und Handeln im Alltag lebendig machen.
<G-vec00355-002-s386><bring.machen><en> They will work together seamlessly to bring intelligence to everyone, everywhere, on demand.
<G-vec00355-002-s386><bring.machen><de> Dadurch wird es möglich sein, Daten auf Abruf für alle und überall verfügbar zu machen.
<G-vec00355-002-s387><bring.machen><en> It restated the objective to bring basic broadband to all Europeans by 2013 and seeks to ensure that, by 2020, (i) all Europeans have access to much higher internet speeds of above 30 Mbps and (ii) 50% or more of European households subscribe to internet connections above 100 Mbps.
<G-vec00355-002-s387><bring.machen><de> Die EU hat sich das Ziel gesetzt, bis 2013 grundlegende Breitbanddienste für alle Europäer verfügbar zu machen und sicherzustellen, dass bis 2020 i) alle Europäer Zugang zu viel höheren Internetgeschwindigkeiten von über 30 Mbit/s haben und ii) mindestens 50 % aller europäischen Haushalte Internetzugänge mit über 100 Mbit/s haben.
<G-vec00355-002-s388><bring.machen><en> Then, indeed, the lawless one will be revealed, whom the Lord Jesus will do away with by the spirit of his mouth and bring to nothing by the manifestation of his presence.
<G-vec00355-002-s388><bring.machen><de> Dann allerdings wird der Gesetzlose geoffenbart werden, den der Herr Jesus beseitigen wird durch den Geist seines Mundes und zunichte machen durch das Kundwerden seiner Gegenwart.
<G-vec00355-002-s389><bring.machen><en> Following your reasoning (good spirits – evil spirits), the health-system, then, is but an evil spirit that has to be driven out from the earth, that we have to drive out in order to bring about the human species.
<G-vec00355-002-s389><bring.machen><de> Wenn ich Ihrer Argumentation folge (guter Geist – böser Geist), ist das Gesundheitswesen wohl auch ein böser Geist, der von der Erde vertrieben werden muss, den wir vertreiben müssen, um die Menschengattung zu machen.
<G-vec00355-002-s390><bring.machen><en> He constantly endeavoured to "look behind the scenes", to bring structures into view.
<G-vec00355-002-s390><bring.machen><de> Immer versuchte er, "dahinter" zu blicken, Strukturen sichtbar zu machen.
<G-vec00355-002-s391><bring.machen><en> Access Switches Aruba switches bring performance and reliability to the mobile-first campus.
<G-vec00355-002-s391><bring.machen><de> Switches Switches von Aruba machen den vorrangig mobilen Campus leistungsfähig und zuverlässig.
<G-vec00355-002-s392><bring.machen><en> We bring to your attention selected quotes from Soviet films.
<G-vec00355-002-s392><bring.machen><de> Wir machen Sie auf ausgewählte Zitate aus sowjetischen Filmen aufmerksam.
<G-vec00355-002-s393><bring.machen><en> I would also like to bring to your attention that processing special categories of personal data has to comply with even more stringent requirements.
<G-vec00355-002-s393><bring.machen><de> Des Weiteren möchte ich gerne noch darauf aufmerksam machen, dass die Verarbeitung von besonderen personenbezogenen Daten noch strengere Voraussetzungen zu erfüllen hat.
<G-vec00355-002-s394><bring.machen><en> Plus, some market players will bring out software-based tools that can answer certain questions and therefore eliminate the need to consult a lawyer.
<G-vec00355-002-s394><bring.machen><de> Dazu wird es Marktakteure geben, die bei gewissen Fragen den Gang zum Anwalt obsolet machen, weil diese gestützt auf softwarebasierte Tools beantwortet werden können.
<G-vec00355-002-s395><bring.machen><en> Therefore it is written 'God will destroy the wisdom of the wise, and will bring to nothing the understanding of the prudent', and therefore people fail to recognise the truth, as long as the spirit of God cannot work in them through love, despite studying.
<G-vec00355-002-s395><bring.machen><de> Und darum steht es geschrieben: „Gott wird den Verstand der Verständigen verwerfen und die Weisheit der Weisen zunichte machen“, und darum erkennen die Menschen nicht die Wahrheit trotz Studium, solange nicht der Geist Gottes in ihnen wirken kann durch die Liebe.
<G-vec00355-002-s396><bring.machen><en> “Through your prayer, night and day, you bring before God the lives of so many of our brothers and sisters who for various reasons cannot come to him to experience his healing mercy, even as he patiently waits for them.
<G-vec00355-002-s396><bring.machen><de> Durch euer Gebet tragt ihr Tag und Nacht das Leben vieler Brüder und Schwestern vor den Herrn, die aus verschiedenen Gründen nicht zu ihm gelangen und die Erfahrung seiner heilenden Barmherzigkeit machen können, während er sie erwartet, um ihnen Gnade zu erweisen.
<G-vec00355-002-s397><bring.machen><en> To bring it back to normal, it has to be reformatted to FAT32 on a Windows-based computer.
<G-vec00355-002-s397><bring.machen><de> Um es wieder normal zu machen, muss es in FAT32 auf einem Windows-basierten Computer neu formatiert werden.
<G-vec00355-002-s398><bring.machen><en> He wanted to bring the exhibits to life with concerts and shows.
<G-vec00355-002-s398><bring.machen><de> Er wollte das Museum durch Konzerte und die Schau der Ausstellungsstücke lebendig machen.
<G-vec00355-002-s456><bring.mitbringen><en> Spyridon itself is very accommodating and has enabled me to bring my cat.
<G-vec00355-002-s456><bring.mitbringen><de> Spyridon selber ist sehr zuvorkommend und hat es mir ermöglicht meine Katze mitzubringen.
<G-vec00355-002-s457><bring.mitbringen><en> Seating is first-come, first-served, and movie-goers are encouraged to bring blankets or low lawn chairs.
<G-vec00355-002-s457><bring.mitbringen><de> Sitzen ist First-Come, First-Served, und Kinobesucher werden aufgefordert, Decken oder niedrige Liegestühle mitzubringen.
<G-vec00355-002-s458><bring.mitbringen><en> Then you scan (w… It is always possible to bring your own assemblies to the workshop to test the various measurement methods.
<G-vec00355-002-s458><bring.mitbringen><de> Es ist jederzeit möglich, eigene Baugruppen als Beispiel für die Anwendung des Messverfahrens zum Workshop mitzubringen.
<G-vec00355-002-s459><bring.mitbringen><en> If you wish to use your car during your stay, you are advised to bring snow chains or studded tires.
<G-vec00355-002-s459><bring.mitbringen><de> Wenn Sie während Ihres Aufenthaltes Ihr Auto nutzen möchten, wird Ihnen empfohlen, Schneeketten oder Reifen mit Spikes mitzubringen.
<G-vec00355-002-s460><bring.mitbringen><en> Equipment: cable TV; radio; internet access (please bring your own network cable) (included); iron/ironing board; gas central heating.
<G-vec00355-002-s460><bring.mitbringen><de> Einrichtung: Netzwerkkabel mitzubringen (inklusive); Bügeleisen/-brett; Gas-Zentralheizung.
<G-vec00355-002-s461><bring.mitbringen><en> Our dogs will still be here, so make sure you bring them some treats.
<G-vec00355-002-s461><bring.mitbringen><de> Unsere Hunde bleiben zuhause, also denkt dran ihnen ein paar Leckerlis mitzubringen.
<G-vec00355-002-s462><bring.mitbringen><en> Very often, juice and cake sellers are walking along the beach: by reason of hygiene we recommend that you rather go to the nearest cafe or that you bring your own food with you.
<G-vec00355-002-s462><bring.mitbringen><de> Sehr oft gehen an diesen Stränden Verkäufer vorbei, die Kuchen und Getränke anbieten: aus hygienischen Gründen raten wir Ihnen, lieber zum nächsten Cafe zu gehen, oder einfach ihr eigenes Essen mitzubringen.
<G-vec00355-002-s463><bring.mitbringen><en> We ask our guests to bring their own sleeping bag.
<G-vec00355-002-s463><bring.mitbringen><de> Die Gäste sind gebeten, den eigenen Schlafsack mitzubringen.
<G-vec00355-002-s464><bring.mitbringen><en> However, you do not need to bring towels or bed linen, as the apartments are fully equipped.
<G-vec00355-002-s464><bring.mitbringen><de> Sie brauchen keine Bettwäsche mitzubringen, da diese in der Ausstattung des Apartment eingeschlossen ist.
<G-vec00355-002-s465><bring.mitbringen><en> These helped us the basic equipment for cooking available (the chef happy but I would recommend some parts bring your own).
<G-vec00355-002-s465><bring.mitbringen><de> Dazu stand uns die basic Ausrüstung zum kochen zur Verfügung (den kochfreudigen würde ich jedoch empfehlen einige teile selbst mitzubringen).
<G-vec00355-002-s466><bring.mitbringen><en> Remember to bring a printed copy of your reservation request email to verify that you have paid the 10% deposit. Cancellation Policy
<G-vec00355-002-s466><bring.mitbringen><de> Vergessen Sie nicht die Kopie Ihres Reservationsantrages mitzubringen, damit Sie beweisen können, dass Sie eine 10% Anzahlung gemacht haben.
<G-vec00355-002-s467><bring.mitbringen><en> Don’t forget to bring your electronic devices and headphones to get connected.
<G-vec00355-002-s467><bring.mitbringen><de> Denken Sie daran, Ihre elektronischen Geräte und Kopfhörer mitzubringen, um sich zu verbinden.
<G-vec00355-002-s468><bring.mitbringen><en> This app is an excellent choice for interior designers and anyone who wishes to build or do some DIYs and are too lazy to bring a measuring tape with them.
<G-vec00355-002-s468><bring.mitbringen><de> Diese App ist eine ausgezeichnete Wahl für Innenarchitekten und alle, die etwas basteln oder basteln möchten und zu faul sind, um ein Maßband mitzubringen.
<G-vec00355-002-s469><bring.mitbringen><en> It would also be recommended to bring something new, something better than what the market is currently offering.
<G-vec00355-002-s469><bring.mitbringen><de> Es wäre auch empfehlenswert, etwas Neues mitzubringen, etwas Besseres als das, was der Markt derzeit anbietet.
<G-vec00355-002-s470><bring.mitbringen><en> The guests are asked to bring along something.
<G-vec00355-002-s470><bring.mitbringen><de> Die Gäste werden gebeten, etwas mitzubringen.
<G-vec00355-002-s471><bring.mitbringen><en> We provide each guest with ecologic soap and shampoo, which has cero environmental impact, very low froth production and is absorbed highly by the traps and filters residing at the mouths of each of our septic tanks; we prohibit the use of soaps, shampoos, rinses, creams and other none bio-degradable productcs, all which are confiscated and only returned to their owner prior to his leaving from the visitors centre, even though we ask all our guests not to bring them in the first place.
<G-vec00355-002-s471><bring.mitbringen><de> Wir geben jedem Gast oekologisch-umweltfreundliche Seife und Schampoo, welche keinen negativen Einfluss auf die Umwelt tragen, geringe Schaumbildung aufweisen und von den Filtern der Abortgruben in hohem Maasse absorbiert werden; wir verbieten jeglichen Gebrauch umweltschaedlicher Seifen, Schampoos, Hautkraemen und sonstige Produkte, welche beschlagnahmt und dem Besitzer erst am Tage seiner Abfahrt zurueck erstattet werden; wir empfehlen unseren Gaesten diese Produkte gar nicht erst mitzubringen.
<G-vec00355-002-s472><bring.mitbringen><en> We recommend that you bring appropriate equipment and book a guide.
<G-vec00355-002-s472><bring.mitbringen><de> Wir empfehlen Ihnen, entsprechende Ausrüstung mitzubringen und einen Führer zu buchen.
<G-vec00355-002-s473><bring.mitbringen><en> Participants are kindly requested to bring their own copies of documentation with them to the session.
<G-vec00355-002-s473><bring.mitbringen><de> Alle Teilnehmer werden freundlich gebeten, ihre Tagungsunterlagen selbst mitzubringen.
<G-vec00355-002-s474><bring.mitbringen><en> Policies Upon prior requests, guests will be allowed to bring pets into the property with additional conditions regarding size, number of pets, and days at the property.
<G-vec00355-002-s474><bring.mitbringen><de> Laut früherer Anfrage ist es Gästen gestattet Haustiere in die Unterkunft mitzubringen, sofern die Richtlinien bezüglich Größe, Anzahl und Aufenthaltslänge der Tiere eingehalten werden.
<G-vec00355-002-s475><bring.mitnehmen><en> By definition it is a Holiday Home that can be towed, which means to bring the proper home on holiday.
<G-vec00355-002-s475><bring.mitnehmen><de> Per Definition handelt es sich um eine bewegliche Ferienwohnung und bietet daher die Möglichkeit, das eigene Zuhause in den Urlaub mitzunehmen.
<G-vec00355-002-s476><bring.mitnehmen><en> It may be fun to bring a friend.
<G-vec00355-002-s476><bring.mitnehmen><de> Es kann Spaß machen, eine Freundin mitzunehmen.
<G-vec00355-002-s477><bring.mitnehmen><en> If you have not used one before if might be a good idea to buy a few different types and bring them all with you.
<G-vec00355-002-s477><bring.mitnehmen><de> Falls du noch nie ein solches angewendet hast, wäre es wahrscheinlich empfehlenswert, verschiedene Modelle zu kaufen und sie alle mitzunehmen.
<G-vec00355-002-s478><bring.mitnehmen><en> Always remember to print the e-visa sent through email and bring it along when traveling.
<G-vec00355-002-s478><bring.mitnehmen><de> Denken Sie immer daran, das E-Visum per E-Mail zu drucken und es auf Reisen mitzunehmen.
<G-vec00355-002-s479><bring.mitnehmen><en> Remember to bring the printed proof of purchase.
<G-vec00355-002-s479><bring.mitnehmen><de> Empfehlungen Denken Sie daran, Ihr Ticket auszudrucken und mitzunehmen.
<G-vec00355-002-s480><bring.mitnehmen><en> Don’t forget to bring your favourite pair of headphones, as not all carriers offer headphones on the coach.
<G-vec00355-002-s480><bring.mitnehmen><de> Vergiss nicht, deine Lieblings-Kopfhörer mitzunehmen, nachdem nicht alle Anbieter Kopfhörer für den Bus anbieten.
<G-vec00355-002-s481><bring.mitnehmen><en> Don’t forget to obtain health and travel insurance, and please remember to bring enough medication to last the duration of your stay.
<G-vec00355-002-s481><bring.mitnehmen><de> Vergessen Sie auch nicht die Nachweise für Ihre Kranken- und Reiseversicherung, und denken Sie daran, für die Dauer Ihres Aufenthalts ausreichend Medikamente mitzunehmen.
<G-vec00355-002-s482><bring.mitnehmen><en> In order to ensure that your efforts and investments have sustainable positive results, we will help you bring your staff and your organisation on board, by actively shaping the change process.
<G-vec00355-002-s482><bring.mitnehmen><de> Damit sich Ihre Anstrengungen und Investitionen nachhaltig auszahlen, helfen wir Ihnen, Ihre Mitarbeiter und Ihre Organisation mitzunehmen, indem wir den Veränderungsprozess aktiv gestalten.
<G-vec00355-002-s483><bring.mitnehmen><en> Feel free to upload as many products as you want, post as many videos and images as needed and bring in all the traffic you require.
<G-vec00355-002-s483><bring.mitnehmen><de> Zögern Sie nicht, so viele Produkte wie Sie möchten hochzuladen, so viele Videos und Bilder wie nötig zu posten und den gesamten Traffic mitzunehmen, den Sie benötigen.
<G-vec00355-002-s484><bring.mitnehmen><en> Recommended equipment: Backpack with water bottle, extra clothing, camera, sunglasses; guide will bring necessary safety equipment
<G-vec00355-002-s484><bring.mitnehmen><de> Hinweis: Wir empfehlen für den Ausflug einen Rucksack mitzunehmen mit Wasserflasche, Wechselkleidung, Kamera und Sonnenbrille.
<G-vec00355-002-s485><bring.mitnehmen><en> Do not forget to bring bicycles with you: the Valsugana cycle starts at about 300 meters from the area and is also practicable by younger children as it does not present great difficulties.
<G-vec00355-002-s485><bring.mitnehmen><de> Vergessen Sie nicht, Fahrräder mitzunehmen: Der Valsugana-Radweg beginnt etwa 300 m von der Umgebung entfernt und ist auch für jüngere Kinder praktikabel, da er keine großen Schwierigkeiten bereitet.
<G-vec00355-002-s486><bring.mitnehmen><en> But my girlie has today Christmas celebration in class and the teacher asked all the children to bring cookies.
<G-vec00355-002-s486><bring.mitnehmen><de> Aber das Töchterlein hat heute Weihnachtsfeier in der Klasse und die Lehrerin bat alle Kinder, Kekse mitzunehmen.
<G-vec00355-002-s487><bring.mitnehmen><en> 14The disciples had forgotten to bring enough bread and had only one loaf with them in the boat.
<G-vec00355-002-s487><bring.mitnehmen><de> 14Und sie vergaßen Brote mitzunehmen, und hatten nichts bei sich auf dem Schiffe als nur ein Brot.
<G-vec00355-002-s488><bring.mitnehmen><en> We advise you to bring bikes with you, as there will be no shortage of opportunities for using them on the ultra-long cycle tracks along the way, which are also safe for children.
<G-vec00355-002-s488><bring.mitnehmen><de> Wir empfehlen, Ihre Fahrräder mitzunehmen, denn sie werden zahlreiche Gelegenheiten haben, diese auf den langen kindersicheren Fahrradwegen zu nutzen.
<G-vec00355-002-s489><bring.mitnehmen><en> We will make at least one longer stop during the trip; we recommend you bring along a hot beverage and something to eat.
<G-vec00355-002-s489><bring.mitnehmen><de> Während der Tour machen wir wenigstens eine längere Pause, wir empfehlen Ihnen ein heißes Getränk und einige Snacks mitzunehmen.
<G-vec00355-002-s490><bring.mitnehmen><en> That didn't only give Shinji the possibility to bring a romantic movie that they had at home, but he also didn't have to go there and change the reels several times.
<G-vec00355-002-s490><bring.mitnehmen><de> Das gab Shinji nicht nur die Möglichkeit einen romantischen Film von Zuhause mitzunehmen, sondern er würde nicht des Öfteren hochgehen müssen, um die Filmrollen zu wechseln.
<G-vec00355-002-s491><bring.mitnehmen><en> They provide life jackets in the room so remember bring along with you.
<G-vec00355-002-s491><bring.mitnehmen><de> Schwimmwesten gibt es leihweise im Zimmer, man muss nur daran denken, sie mitzunehmen.
<G-vec00355-002-s492><bring.mitnehmen><en> Remember to bring dishes and everything else you need for cooking.
<G-vec00355-002-s492><bring.mitnehmen><de> Vergessen Sie nicht, genug Geschirr und die nötigsten Küchenutensilien mitzunehmen.
<G-vec00355-002-s493><bring.mitnehmen><en> We kindly ask our guests not to bring or eat food bought elsewhere into the territory of the hotel.
<G-vec00355-002-s493><bring.mitnehmen><de> Wir bitten unsere Gäste die außer Haus gekauften Lebensmittel und Getränke nicht ins Hotelareal mitzunehmen und zu konsumieren.
<G-vec00355-002-s494><bring.nehmen><en> I plan to bring my family to Prague so that we will have a vacation time after the convention.
<G-vec00355-002-s494><bring.nehmen><de> Ich will meine Familie mit zur Veranstaltung in Beverly Hills nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00355-002-s495><bring.nehmen><en> In this case, please report to the IT support services directly and bring identification with you.
<G-vec00355-002-s495><bring.nehmen><de> Wenden Sie sich dafür persönlich an den IT-Support und nehmen Sie zwecks eindeutiger Identifikation einen Ausweis mit.
<G-vec00355-002-s496><bring.nehmen><en> The parents left you to decide what to bring and which foods to eat.
<G-vec00355-002-s496><bring.nehmen><de> Die Eltern wollen dass Sie entscheiden was zu nehmen und welche Lebensmittel zu essen.
<G-vec00355-002-s497><bring.nehmen><en> You may bring your own food on board if you follow the safety regulation with regard to carry-on baggage.
<G-vec00355-002-s497><bring.nehmen><de> Sie können Ihre eigene Verpflegung mit an Bord nehmen, wenn Sie die Sicherheitsbestimmungen für Handgepäck befolgen.
<G-vec00355-002-s498><bring.nehmen><en> I plan to bring my family to Sydney so that we will have a vacation time after the conference.
<G-vec00355-002-s498><bring.nehmen><de> Ich will meine Familie mit zur Veranstaltung in Miami nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00355-002-s499><bring.nehmen><en> Bring your swimsuit; A Victory Inn & Suites Phoenix North has an outdoor swimming pool.
<G-vec00355-002-s499><bring.nehmen><de> Nehmen Sie ein Bad im Pool, Sie werden sicherlich mögen, dass das A Victory Inn & Suites Phoenix North ein Außenpool hat.
<G-vec00355-002-s500><bring.nehmen><en> Bring it anywhere: the elegant finish in brushed metal makes it an elegant and classy accessory.
<G-vec00355-002-s500><bring.nehmen><de> Nehmen Sie ihn überall mit hin: Die elegante Oberfläche aus gebürstetem Metall macht ihn zu einem edlen und stilvollen Accessoire.
<G-vec00355-002-s501><bring.nehmen><en> Bring your iPhone with you.
<G-vec00355-002-s501><bring.nehmen><de> Nehmen Sie Ihr iPhone mit.
<G-vec00355-002-s502><bring.nehmen><en> In most countries, the transit authorities allow you to bring food through the security screening and on board.
<G-vec00355-002-s502><bring.nehmen><de> Essen, welches die Bordsecurity erlaubt In den meisten Ländern erlaubt einem das Sicherheitspersonal, Essen durch die Kontrolle mit an Bord zu nehmen.
<G-vec00355-002-s503><bring.nehmen><en> Bring your iPhone along to see pace and distance.
<G-vec00355-002-s503><bring.nehmen><de> Nehmen Sie Ihr iPhone mit, um Geschwindigkeit und zurückgelegte Strecke zu messen.
<G-vec00355-002-s504><bring.nehmen><en> When we bring our testosterone levels to a high level, the performance of the testosterone is enhanced.
<G-vec00355-002-s504><bring.nehmen><de> Wenn wir unsere Testosteronspiegel zu einem hochrangigen Zustand nehmen, werden die oben genannten Merkmale des Testosteronhormons erhöht.
<G-vec00355-002-s505><bring.nehmen><en> Bring yourself to do this 3-day private paddle surf course in one of the beaches of Gran Canaria.
<G-vec00355-002-s505><bring.nehmen><de> Nehmen Sie an diesem 3-tägigen privaten Paddel-Surfkurs an einem der Strände von Gran Canaria teil.
<G-vec00355-002-s506><bring.nehmen><en> Bring as much as you can in your hand luggage, but cut all your barriers to the right size before you fly (at least those you will be carrying in your hand luggage), since you will not always be allowed to bring scissors in your hand luggage.
<G-vec00355-002-s506><bring.nehmen><de> Nehmen Sie so viel wie möglich in Ihrem Handgepäck mit, aber schneiden Sie jeden Hautschutz vor dem Flug auf die richtige Größe zu (zumindest diejenigen im Handgepäck), da Scheren im Handgepäck nicht immer erlaubt sind.
<G-vec00355-002-s507><bring.nehmen><en> The taste of a holiday at the White Horse Inn can be enjoyed everywhere: with the homemade goods of the White Horse Inn you can bring a slice of Austria back home with you and enjoy traditional Austrian cuisine in your own home.
<G-vec00355-002-s507><bring.nehmen><de> Rössl Spezialitäten Den Geschmack eines Urlaubs im Hotel Weisses Rössl können Sie nicht nur in St. Wolfgang genießen: Nehmen Sie aus dem Rössl-Shop Hausgemachtes mit – ein Souvenir aus Ihrem Österreich-Urlaub, das den Daheimgebliebenen Freude bereitet.
<G-vec00355-002-s508><bring.nehmen><en> Oxea has also announced plans to bring its sixth world-scale carboxylic acids production plant on stream in 2021.
<G-vec00355-002-s508><bring.nehmen><de> Zudem plant das Unternehmen, im Jahr 2021 seine sechste Großanlage zur Herstellung von Carbonsäuren in Betrieb zu nehmen.
<G-vec00355-002-s509><bring.nehmen><en> Then bring the ball down across your body to your right hip, bending your elbows, again without rotating your head or chest.
<G-vec00355-002-s509><bring.nehmen><de> Nehmen Sie ihre rechte Hand an die rechte Hüfte, oder legen Sie den Arm gerade rechts am Körper einfach ab.
<G-vec00355-002-s510><bring.nehmen><en> Bring SmartCharge with you wherever you go.
<G-vec00355-002-s510><bring.nehmen><de> Nehmen Sie SmartCharge mit.
<G-vec00355-002-s511><bring.nehmen><en> To bring your Guide Dog into the cabin, please download and fill out the Application Form Guide Dog and send the completed form to KLMCARES@KLM.com.
<G-vec00355-002-s511><bring.nehmen><de> Um Ihren Blindenhund mit in die Kabine zu nehmen, laden Sie bitte das Antragsformular Blindenhund herunter und füllen Sie es aus und senden dieses ausgefüllt anKLMCARES@klm.com.
<G-vec00355-002-s512><bring.nehmen><en> Bring them ALL safely.
<G-vec00355-002-s512><bring.nehmen><de> Nehmen Sie einfach alle mit.
<G-vec00355-002-s513><bring.schaffen><en> The hope that the Messiah would bring peace on earth is one of the reasons that the Jews didn’t accept Jesus as the Messiah.
<G-vec00355-002-s513><bring.schaffen><de> Die Hoffnung, dass der Messias Frieden auf dieser Erde schaffen wird, war einer der Gründe, warum die Juden Jesus nicht als Messias akzeptierten.
<G-vec00355-002-s514><bring.schaffen><en> This is a completely new way of safely storing health data and will bring about more trust and protection in the population.“
<G-vec00355-002-s514><bring.schaffen><de> Das ist ein vollkommen neuer Weg in der sicheren Speicherung von Gesundheitsdaten und wird mehr Vertrauen und Schutz in der Bevölkerung schaffen.
<G-vec00355-002-s515><bring.schaffen><en> Through offices established nationally, offering teacher trainings, and classroom projects and resources tailored to the national languages and school curricula, ESERO trains teachers so that they can bring space to the classroom and make their lessons more inspiring and effective.
<G-vec00355-002-s515><bring.schaffen><de> Durch landesweit eingerichtete Büros, die Lehrerfortbildungen, Unterrichtsprojekte und Ressourcen anbieten, die auf die Sprachen der Mitgliedsstaaten und unterschiedliche Lehrpläne zugeschnitten sind, bildet ESERO Lehrer aus, damit sie Platz im Klassenzimmer schaffen und ihren Unterricht inspirierender und effektiver gestalten können.
<G-vec00355-002-s516><bring.schaffen><en> And this not only because the horrors of war give rise to proletarian revolt – no revolt can bring about socialism unless the economic conditions for socialism are ripe – but because state-monopoly capitalism is a complete material preparation for socialism, the threshold of socialism, a rung on the ladder of history between which and the rung called socialism there are no intermediate rungs’ As a result, ‘socialism is merely state-monopoly capitalism which is made to serve the interests of the whole people and has to that extent ceased to be capitalist monopoly’.
<G-vec00355-002-s516><bring.schaffen><de> Und das nicht nur deshalb, weil der Krieg mit seinem Entsetzen den proletarischen Aufstand gebiert – kein Aufstand kann den Sozialismus schaffen, wenn er ökonomisch nicht gereift ist –, sondern deshalb, weil der staatsmonopolistische Kapitalismus eine vollkommene materielle Vorbereitung des Sozialismus ist, die Eingangspforte zu ihm, weil er in der historischen Leiter jene Stufe bedeutet, zwischen welcher und der folgenden Stufe, die man Sozialismus nennt, es keine zwischenliegenden Stufen gibt.“ Folglich ist „der Sozialismus nichts anderes als ein staatskapitalistisches Monopol, eingestellt zum Nutzen des ganzen Volkes und insofern kein kapitalistisches Monopol mehr“.
<G-vec00355-002-s517><bring.schaffen><en> Until now practice was either understood as an application of theory, as a mere consequence, or it was assumed that practice must inspire theory, that it could bring forth new theories.
<G-vec00355-002-s517><bring.schaffen><de> Bis jetzt hat man entweder die Praxis als eine Applikation der Theorie, als bloße Konsequenz verstanden; oder man hat gemeint, die Praxis müsse die Theorie inspirieren, sie könne neue Theorien schaffen.
<G-vec00355-002-s518><bring.schaffen><en> Let us help you to expand on your ideas or bring new possibilities to the table, whether it’s a corporate event, product launch, a private party or an exclusive show.
<G-vec00355-002-s518><bring.schaffen><de> Lassen Sie uns Ihnen helfen, Ihre Ideen zu erweitern oder neue Möglichkeiten für den Tisch zu schaffen, sei es eine Firmenveranstaltung, eine Produkteinführung, eine private Party oder eine exklusive Show.
<G-vec00355-002-s519><bring.schaffen><en> Rural related organizations therefore need to find ways to bring about effective, voluntary and trust-based networking among experts, both within and beyond the confines of their own institutions.
<G-vec00355-002-s519><bring.schaffen><de> Ländliche Organisationen müssen daher Wege finden, eine effektive, freiwillige und auf Vertrauen basierende Vernetzung von Experten zu schaffen, sowohl innerhalb als auch jenseits der Grenzen ihrer eigenen Institutionen.
<G-vec00355-002-s520><bring.schaffen><en> This could bring new "growth."
<G-vec00355-002-s520><bring.schaffen><de> Dies könne neues "Wachstum" schaffen.
<G-vec00355-002-s521><bring.schaffen><en> Evaluate the project portfolio to bring clarity and allow improvements in reviewing projects.
<G-vec00355-002-s521><bring.schaffen><de> Bewertung des Projektportfolios, um bei der Prüfung von Projekten Klarheit zu schaffen und Verbesserungen zu ermöglichen.
<G-vec00355-002-s522><bring.schaffen><en> The first months of the child's presence in the mother's womb bring about a particular bond which already possesses an educational significance of its own.
<G-vec00355-002-s522><bring.schaffen><de> Die ersten Monate seiner Gegenwart im Mutterschob schaffen eine besondere Bindung, die bereits jetzt einen erzieherischen Wert annimmt.
<G-vec00355-002-s523><bring.schaffen><en> In particular, every member of the lay faithful is himself responsible for building the human city with the contribution of his professionalism, witness and commitment to participation, thereby helping to bring into being an appropriate legislation and then to set an example by loyally abiding by it.
<G-vec00355-002-s523><bring.schaffen><de> Insbesondere ist jeder gläubige Laie aufgerufen, eigenverantwortlich zum Aufbau der »Stadt der Menschen« mit seinem Fachwissen, mit seinem Zeugnis und mit seiner engagierten Teilnahme beizutragen und so mitzuhelfen, eine angemessene Gesetzgebung zu schaffen und in ihrer treuen Befolgung ein Vorbild zu sein.
<G-vec00355-002-s524><bring.schaffen><en> We want to bring jobs.
<G-vec00355-002-s524><bring.schaffen><de> Wir schaffen gerne Jobs.
<G-vec00355-002-s525><bring.schaffen><en> The Vicenza Fair has been chosen to bring a relaxing corner in the most glamorous space of the event, becoming thus a real protagonist of the golden cinema world.
<G-vec00355-002-s525><bring.schaffen><de> Die Messe Vicenza wurde gewählt, um eine Entspannungsecke in den glanzvollsten Ereignis zu schaffen und somit zum Protagonisten der goldenen Kinowelt zu werden.
<G-vec00355-002-s526><bring.schaffen><en> With these simple words he described the miracle of the birth of Jesus Christ and stated the reason for which God's Son had taken on flesh: in order to bring about redemption and give human beings the opportunity to become children of God.
<G-vec00355-002-s526><bring.schaffen><de> Mit diesen schlichten Worten beschrieb er das Wunder der Geburt Jesu Christi und nannte den Grund, weshalb Gottes Sohn Mensch wurde: um Erlösung zu schaffen und den Menschen die Möglichkeit zu eröffnen, Gotteskinder zu werden.
<G-vec00355-002-s527><bring.schaffen><en> The sale is the result of a two-year process, during which TAG managed to bring about a zoning situation for this property that made a sale at this price possible in the first place.
<G-vec00355-002-s527><bring.schaffen><de> Der Verkauf ist das Ergebnis eines zweijährigen Prozesses, in dem es den Mitarbeitern der TAG gelungen ist, für dieses Grundstück eine baurechtliche Situation zu schaffen, die den Verkauf zu diesem Preis überhaupt erst möglich machte.
<G-vec00355-002-s528><bring.schaffen><en> In his mind, there’s no reason that universities in Poland shouldn’t be able to benefit from the promotional opportunities that collegiate esports programs bring to schools in other countries.
<G-vec00355-002-s528><bring.schaffen><de> Für ihn gibt es keinen Grund, warum Universitäten in Polen nicht ebenso von den Werbemöglichkeiten profitieren sollten, die universitäre Esportsprogramme in anderen Ländern schaffen.
<G-vec00355-002-s529><bring.schaffen><en> 4 He will judge the poor of the people, and he will bring salvation to the sons of the poor. And he will humble the false accuser.
<G-vec00355-002-s529><bring.schaffen><de> 4Er wird Recht schaffen den Elenden des Volkes; er wird retten die Kinder des Armen, und den Bedrücker wird er zertreten.
<G-vec00355-002-s530><bring.schaffen><en> The Cisco ASR 5000 Series was developed to address the anticipated increase in performance requirements that the next generation of the mobile Internet will bring.
<G-vec00355-002-s530><bring.schaffen><de> Die Cisco ASR Serie 5000 bietet die erforderlichen Funktionen, um eine Umgebung zu schaffen, die die nächste Generation des mobilen Internet in vollem Umfang unterstützt.
<G-vec00355-002-s531><bring.schaffen><en> The complex circumstances of our day make it necessary for public authority to intervene more often in social, economic and cultural matters in order to bring about favorable conditions which will give more effective help to citizens and groups in their free pursuit of man's total well-being.
<G-vec00355-002-s531><bring.schaffen><de> Die heutzutage stets verwickelter werdenden Verhältnisse zwingen die staatliche Autorität, häufiger in soziale, wirtschaftliche und kulturelle Angelegenheiten einzugreifen; sie will damit geeignetere Voraussetzungen dafür schaffen, daß die Staatsbürger und gesellschaftlichen Gruppen wirksamer in Freiheit das Wohl des Menschen in jeder Hinsicht verwirklichen können.
<G-vec00355-002-s551><bring.sorgen><en> For many years these evenings are very popular among visitors and locals as they bring enjoyment and a varied entertainment programme during the late hours on hot summer days.
<G-vec00355-002-s551><bring.sorgen><de> Diese Abende erfreuen sich seit Jahren großer Beliebtheit, sorgen sie doch in den heißen Sommerabenden für ausgelassene Stimmung bei einem abwechslungsreichen Unterhaltungsprogramm.
<G-vec00355-002-s552><bring.sorgen><en> Cherry, Hard Maple, Red Oak and Walnut bring style and drama to any space.
<G-vec00355-002-s552><bring.sorgen><de> Amerikanische Kirsche, kanadischer Ahorn, Roteiche und Walnuss sorgen in jedem Raum für eine stilvolle und fesselnde Atmosphäre.
<G-vec00355-002-s553><bring.sorgen><en> LED rear light, incorporated into the classically inspired and stylish tail set-up, bring a distinctive rear light pattern and power efficiency.
<G-vec00355-002-s553><bring.sorgen><de> Neue LED-Rückleuchten, die sich perfekt in das klassisch inspirierte und elegante Heck einfügen, sorgen für ein unverwechselbares Lichtmuster und beste Energieeffizienz.
<G-vec00355-002-s554><bring.sorgen><en> World-class products and software maximise operations and bring new growth opportunities.
<G-vec00355-002-s554><bring.sorgen><de> Erstklassige Produkte und Software optimieren den Betrieb und sorgen für neue Wachstumschancen.
<G-vec00355-002-s555><bring.sorgen><en> Trade winds and the warm temperature of the sub-tropical Atlantic Ocean bring this part of the island year-round balmy weather.
<G-vec00355-002-s555><bring.sorgen><de> Die Passatwinde und das warme Klima des subtropischen Atlantiks sorgen für ein mildes Klima - ganzjährig.
<G-vec00355-002-s556><bring.sorgen><en> Back Tasty cocktails, authentic decor and fitting music bring you a little bit of Cuba right to the City of Bern.
<G-vec00355-002-s556><bring.sorgen><de> Zurück Schmackhafte Cocktails, authentische Dekoration und passende Musik sorgen für ein kleines Cuba inmitten der Stadt Bern.
<G-vec00355-002-s557><bring.sorgen><en> Your stay is based on self-catering. Please bring your own bed linen, towels and tea towels.
<G-vec00355-002-s557><bring.sorgen><de> Der Aufenthalt beruht auf Selbstversorgung, für Bettwäsche, Handtücher und Geschirrtücher sorgen Sie bitte selbst.
<G-vec00355-002-s558><bring.sorgen><en> He had no idea that God could bring provision in a completely unexpected way.
<G-vec00355-002-s558><bring.sorgen><de> Er hatte keine Vorstellung davon, dass Gott auf komplett unerwartete Weise dafür sorgen konnte.
<G-vec00355-002-s559><bring.sorgen><en> Regular updates to the PS4 system software bring fresh new features and ways to connect, share and play. A fresh interface
<G-vec00355-002-s559><bring.sorgen><de> Die regelmäßigen Updates für die PS4-Systemsoftware sorgen für neue Funktionen und Möglichkeiten, mit anderen in Kontakt zu treten, Inhalte zu teilen und zu spielen.
<G-vec00355-002-s560><bring.sorgen><en> He will sing at the Bergedorfer city festival on the last weekend in August and bring musical variety.
<G-vec00355-002-s560><bring.sorgen><de> So wird er beim Bergedorfer Stadtfest am letzten Augustwochenende für musikalische Abwechslung sorgen.
<G-vec00355-002-s561><bring.sorgen><en> Enabled routers bring an extra layer of security to your smart home.
<G-vec00355-002-s561><bring.sorgen><de> HomeKit kompatible Router sorgen für zusätzlichen Schutz in deinem Smart Home.
<G-vec00355-002-s562><bring.sorgen><en> Our world-class R&D team embodies the company’s drive to bring the best in passenger communication to life.
<G-vec00355-002-s562><bring.sorgen><de> Unser hervorragendes Forschungs- und Entwicklungsteam verkörpert das Bestreben des Unternehmens, für die bestmögliche Fahrgastkommunikation zu sorgen.
<G-vec00355-002-s563><bring.sorgen><en> The front flap is embellished with contrasting saddle stitches for equestrian appeal, while the glint of brass hardware and dangling tassel bring a feminine flourish.
<G-vec00355-002-s563><bring.sorgen><de> Der Überschlag erhält durch kontrastierende Sattlernähte einen auf den Reitsport verweisenden Reiz, während die funkelnden Metalldetails aus Messing und die herabhängende Quaste für eine feminine Note sorgen.
<G-vec00355-002-s564><bring.sorgen><en> Choose from 100% Arabica coffee or cold juices to complement your breakfast and you're ready for a full day of adventure or business. The Motocross racing, horse shows, and rodeo are all popular attractions that bring in guests from around the country.
<G-vec00355-002-s564><bring.sorgen><de> Reiner Arabica-Kaffee oder gekühlter Saft sorgen für den perfekten Start in Ihren Arbeits- oder Urlaubstag.Gäste aus dem ganzen Land besuchen die Motocrossrennen, Pferdeshows und Rodeoveranstaltungen in der Region.
<G-vec00355-002-s565><bring.sorgen><en> In the dry season from May to September the occasional 'Surazo' - a cold wind blowing up from Patagonia can bring a bit of rain and cold weather conditions that can drop temperatures as low as 10°C!
<G-vec00355-002-s565><bring.sorgen><de> In der Trockenzeit von Mai bis September kann der wiederkehrende Südwind, 'Sur' oder 'Surazo' genannt, der aus Patagonien hier heraufweht, für Temperaturstürze und ein wenig Regen sorgen.
<G-vec00355-002-s566><bring.sorgen><en> Our catering and convention services professionals are dedicated to providing seamless, impressive service and bring intuition and expertise to each unique event.
<G-vec00355-002-s566><bring.sorgen><de> Unsere Mitarbeiter im Catering- und Konferenzservice bieten einen reibungslosen und beeindruckenden Service und sorgen bei jeder Veranstaltung für das nötige Maß an Intuition und Fachwissen.
<G-vec00355-002-s567><bring.sorgen><en> These currencies also bring to the market different transaction speeds.
<G-vec00355-002-s567><bring.sorgen><de> Diese Währungen sorgen auch für unterschiedliche Transaktionsgeschwindigkeiten auf dem Markt.
<G-vec00355-002-s568><bring.sorgen><en> The top’s 30+ UPF helps you stay protected against the sun’s rays for longer, while innovative tiny air channels in the yarn and intelligent mesh positioning help bring cooling ventilation where it’s needed most.
<G-vec00355-002-s568><bring.sorgen><de> Das Material schützt mit UV-Schutzfaktor 30+ vor Sonnenstrahlung, während innovative winzige Luftkanäle im Garn und strategisch platzierte Netzeinsätze dort für Belüftung sorgen, wo es am nötigsten ist.
<G-vec00355-002-s569><bring.sorgen><en> Salvia can bring you a heavy trip.
<G-vec00355-002-s569><bring.sorgen><de> Salvia kann für einen ordentlichen Trip sorgen.
<G-vec00355-002-s570><bring.stellen><en> d) That state institutions intensify the implementation of laws that protect children from sexual exploitation in tourism and bring to justice the offenders through intensive, co-ordinated and consistent efforts at all levels of society, and in collaboration with international organizations.
<G-vec00355-002-s570><bring.stellen><de> d. Staatliche Institutionen sollten die Durchsetzung der Gesetze zum Schutze der Kinder vor der sexuellen Ausbeutung im Tourismus verstärken und die Gesetzesbrecher durch intensive, koordinierte und nachdrückliche Anstrengungen in allen Bereichen der Gesellschaft und in Zusammenarbeit mit den internationalen Organisationen vor Gericht stellen.
<G-vec00355-002-s571><bring.stellen><en> Premise In an epoch in which from more parts and in all sectors of human activities we invoke the recovery of their ethics, sport that in its deep meaning “establishes an original and fundamental ethics” it is in the frontline to bring back person’s values to the centre of attention.
<G-vec00355-002-s571><bring.stellen><de> In dieser Zeit, in der von allen Seiten und in allen Bereichen der menschlichen Tätigkeit auf die Wiedererlangung der Ethik gepocht wird, steht der Sport, dessen tiefe Bedeutung einer “ursprünglichen, grundsätzlichen Ethik” gleichkommt, in vorderster Linie, um die Werte der Person in den Mittelpunkt zu stellen.
<G-vec00355-002-s572><bring.stellen><en> The principle of universal jurisdiction of national courts allows any state to bring the perpetrators of war crimes to justice before its courts, regardless of where those crimes were committed and regardless of the nationality of their perpetrators.
<G-vec00355-002-s572><bring.stellen><de> Das Prinzip der universalen Rechtsprechung nationaler Gerichte erlaubt jedem Staat, Täter von Kriegsverbrechen vor sein Gericht zu stellen, ungeachtet dessen, wo diese Verbrechen begangen wurden und ungeachtet von der Nationalität der Täter.
<G-vec00355-002-s573><bring.stellen><en> The Office Mills from Haas bring CNC performance and reliability to industries that are unable to fit a “normal” machine into their facilities.
<G-vec00355-002-s573><bring.stellen><de> Mikro-Fräsmaschine Die Mikrodrehmaschinen von Haas stellen den Branchen, die für eine “normale” CNC-Maschine keinen Platz haben, eine hohe Leistung und Zuverlässigkeit zur Verfügung.
<G-vec00355-002-s574><bring.stellen><en> For WCS Spring and Summer, we will be partnering with StarLadder to bring you two live events in Kiev, Ukraine.
<G-vec00355-002-s574><bring.stellen><de> Für die WCS Spring und Summer haben wir uns mit StarLadder zusammengetan, um für euch zwei Live-Events in der ukrainischen Hauptstadt Kiew auf die Beine zu stellen.
<G-vec00355-002-s575><bring.stellen><en> Instead of visiting multiple sites to determine whether or not a certain online casino is fit for you, we’ve done all the hard work to bring you a list of the best online casinos currently available.
<G-vec00355-002-s575><bring.stellen><de> Anstatt mehrere unterschiedliche Seiten zu besuchen, um heruaszufinden, welches Online Casino am besten zu Ihnen passt, haben wir die ganze Fleißarbeit für Sie erledigt und stellen Ihnen die besten Online Casinos und Ihre aktuellen Angebote vor.
<G-vec00355-002-s576><bring.stellen><en> Our clients are interested in these products and we strive to bring them all content that is relevant to them.
<G-vec00355-002-s576><bring.stellen><de> Unsere Kunden sind an diesen Produkten interessiert, daher bemühen wir uns, ihnen alle für sie relevanten Inhalte zur Verfügung zu stellen.
<G-vec00355-002-s577><bring.stellen><en> They belong to specific BCG practice areas and bring knowledge and experience to our clients and colleagues.
<G-vec00355-002-s577><bring.stellen><de> Sie gehören spezifischen Practice Areas von BCG an und stellen ihre Kenntnisse und ihre Erfahrung für unsere Kunden und Kollegen zur Verfügung.
<G-vec00355-002-s578><bring.stellen><en> Their recent partnership with Be Prepared Period, a website designed to educate young girls and their parents, is helping to bring healthy period care to the forefront of women’s health initiatives.
<G-vec00355-002-s578><bring.stellen><de> Ihre neueste Zusammenarbeit mit Be Prepared Period, einer Webseite, die junge Mädchen und ihre Eltern informieren möchte, hilft gesunde Menstruationspflege an die oberste Stelle von Initiativen zur Gesundheit von Frauen zu stellen.
<G-vec00355-002-s579><bring.stellen><en> We bring you the widest range of tennis products from all the top brands to choose from.
<G-vec00355-002-s579><bring.stellen><de> Wir stellen dir die größte und spannendste Kollektion von Tennisprodukten zur Auswahl.
<G-vec00355-002-s580><bring.stellen><en> The fine applicator will bring the smallest amount of lubricant precisely and only in the point where is needed.
<G-vec00355-002-s580><bring.stellen><de> Der feine Applikator ermöglicht eine hochpräzise Auftragung geringster Mengen von Schmiermittel auf den erforderlichen Stellen.
<G-vec00355-002-s581><bring.stellen><en> In this case use only water and bring the coolant concentration back up to the correct level as soon as possible by putting in the specified additive.
<G-vec00355-002-s581><bring.stellen><de> Verwenden Sie in diesem Fall zunächst nur Wasser und stellen Sie das richtige Mischungsverhältnis mit dem vorgeschriebenen Kühlmittelzusatz schnellstmöglich wieder her.
<G-vec00355-002-s582><bring.stellen><en> Bring your bike to a stand and lock it by pressing the red button on the lock and sliding the bolt downwards.
<G-vec00355-002-s582><bring.stellen><de> Stellen das Rad an einer Call a Bike-Station ab und drücke zum Abschließen wieder den roten Knopf links am Schloss.
<G-vec00355-002-s583><bring.stellen><en> Manufacturers who consider or have reason to believe that a product which they have placed on the market is not safe or is otherwise not in conformity with this Regulation shall immediately take the corrective action necessary to bring that product into conformity, to withdraw it or recall it, if appropriate.
<G-vec00355-002-s583><bring.stellen><de> (5) Händler, die der Auffassung sind oder Grund zur Annahme haben, dass ein von ihnen auf dem Markt bereitgestelltes Produkt nicht dieser Richtlinie entspricht, stellen sicher, dass die erforderlichen Korrekturmaßnahmen ergriffen werden, um die Konformität dieses Produkts herzustellen oder es gegebenenfalls zurückzunehmen oder zurückzurufen .
<G-vec00355-002-s584><bring.stellen><en> We bring the profitable use of technology to the forefront instead of fast depreciating property or license rights.
<G-vec00355-002-s584><bring.stellen><de> Wir stellen den gewinnbringenden Einsatz der Technologie in den Vordergrund - nicht das schnell an Wert verlierende Eigentum oder Lizenzrecht.
<G-vec00355-002-s585><bring.stellen><en> Thanks to going public, we have the resources to develop our products and, when successful, bring them to the patients who need them.
<G-vec00355-002-s585><bring.stellen><de> Dank des Börsengangs verfügen wir über die Ressourcen, unsere Produkte zu entwickeln und im Erfolgsfall den Patienten zur Verfügung zu stellen, die sie brauchen.
<G-vec00355-002-s586><bring.stellen><en> We bring the software, you bring the services.
<G-vec00355-002-s586><bring.stellen><de> Wir stellen die Software zur Verfügung, Sie die Services.
<G-vec00355-002-s587><bring.stellen><en> If you don’t have a blog just mail us your stuff and we will bring it online as a guest post!
<G-vec00355-002-s587><bring.stellen><de> Falls ihr keinen Blog habt, könnt ihr uns einfach per Mail euer Rezept und die Fotos zukommen lassen und wir stellen es dann in Form eines Gastbeitrags online.
<G-vec00355-002-s588><bring.stellen><en> If you want to have a wedding ceremony outside the town hall you have to bring 2 witnesses.
<G-vec00355-002-s588><bring.stellen><de> Außerhalb des Rathauses müssen Sie selbst zwei Trauzeugen stellen.
<G-vec00355-002-s589><bring.tragen><en> The German-American Institute (DAI), an institution of cultural life in Heidelberg that is widely renowned in Germany, seeks to bring new impulses to Heidelberg’s civil society with an open forum for the discussion of socially interesting questions.
<G-vec00355-002-s589><bring.tragen><de> IBA-Kuratorium Das Deutsch-Amerikanische Institut (DAI), eine nicht nur bundesweit beachtete Institution des kulturellen Lebens in Heidelberg, will mit einem offenen Forum für den Diskurs gesellschaftlich interessanter Fragen neue Impulse in die Heidelberger Zivilgesellschaft tragen.
<G-vec00355-002-s590><bring.tragen><en> It’s a non-profit organisation aimed at taking all of the academic work that takes place in robot applications and trying to bring that to the public domain, to raise awareness of both the general public and policy makers.
<G-vec00355-002-s590><bring.tragen><de> Eine gemeinnützige Organisation, die darauf abzielt, die gesamte akademische Arbeit im Bereich der Roboteranwendungen nach außen zu tragen und so das Bewusstsein der Öffentlichkeit und der politischen Entscheidungsträger dafür zu stärken.
<G-vec00355-002-s591><bring.tragen><en> The parents proudly bring these positive experiences to the company.
<G-vec00355-002-s591><bring.tragen><de> Die Eltern tragen diese positiven Erfahrungen stolz in den Betrieb.
<G-vec00355-002-s592><bring.tragen><en> We bring that attitude with us out into the world.
<G-vec00355-002-s592><bring.tragen><de> Diese Einstellung tragen wir in die Welt hinaus.
<G-vec00355-002-s593><bring.tragen><en> As the main sponsor since 2014, we have helped bring unforgettable athletics moments to this Italian-speaking region of Switzerland. Visit website
<G-vec00355-002-s593><bring.tragen><de> Seit 2014 tragen wir als Hauptsponsorin dazu bei, dieser Region in der italienischsprachigen Schweiz unvergessliche sportliche Momente zu bereiten.
<G-vec00355-002-s594><bring.tragen><en> The idea to bring the film from the streets to the streets was not an easy task.
<G-vec00355-002-s594><bring.tragen><de> Die Idee, den Film von der Straße auf die Straße zu tragen gestaltete sich nicht ganz einfach.
<G-vec00355-002-s595><bring.tragen><en> The mountains bring forth grass for him; all the beasts of the field will play there.
<G-vec00355-002-s595><bring.tragen><de> 20 Die Berge tragen Futter für ihn, und alle wilden Tiere spielen dort.
<G-vec00355-002-s596><bring.tragen><en> You ultimately learn how to gain from your interior strength to then be able to bring this experience in your everyday life.
<G-vec00355-002-s596><bring.tragen><de> Man lernt aus der eigenen inneren Kraft zu schöpfen, um danach diese Erfahrung in den Alltag zu tragen.
<G-vec00355-002-s597><bring.tragen><en> 40:20 Surely the mountains bring him forth food, where all the beasts of the field play.
<G-vec00355-002-s597><bring.tragen><de> 40:20 Doch die Berge tragen ihm Futter zu / und alle Tiere des Feldes spielen dort.
<G-vec00355-002-s598><bring.tragen><en> The level of LDL (Low Density Lipoprotein), which bring the cholesterol to the tissues, increases in the presence of an excess of the latter.
<G-vec00355-002-s598><bring.tragen><de> Die Anzahl der LDL (Low Density Lipoprotein), die das Cholesterin ins Gewebe tragen, erhöht einen Überschuss des letzteren.
<G-vec00355-002-s599><bring.tragen><en> Also, between June and September, bring everything you need to protect yourself from the sun and heat.
<G-vec00355-002-s599><bring.tragen><de> Zwischen Juni und September sollten Sie so viel wie möglich zum Schutz gegen die Sonne und die Hitze tragen.
<G-vec00355-002-s600><bring.tragen><en> High Technologies Park programmers receive at least $1000 a month, while on average $2000, and they bring such a valuable foreign currency in the country.
<G-vec00355-002-s600><bring.tragen><de> High-Tech Park-Programmierer erhalten mindestens 850 € pro Monat und durchschnittlich 1700 € und somit tragen sie eine wertvolle Fremdwährung ins Land.
<G-vec00355-002-s601><bring.tragen><en> Because you have considerable inner tension between your security needs and the more romantic and idealistic side of your nature, you are likely to bring a certain amount of conflict into your relationship with Brad simply because you are torn between reality and your dream of love.
<G-vec00355-002-s601><bring.tragen><de> Zwischen Ihren Sicherheitsbedürfnissen und der eher romantischen und idealistischen Seite Ihres Wesens besteht eine beträchtliche innere Spannung, und so tragen Sie wahrscheinlich gewisse Konflikte in die Beziehung zu Brad hinein - einfach deshalb, weil Sie zwischen der Wirklichkeit und Ihrem Traum von der Liebe hin- und hergerissen sind.
<G-vec00355-002-s602><bring.tragen><en> Our Lord’s hands, extended on the Cross, also invite us to contemplate our participation in his eternal priesthood and thus our responsibility, as members of his body, to bring the reconciling power of his sacrifice to the world in which we live.
<G-vec00355-002-s602><bring.tragen><de> Die am Kreuz ausgestreckten Hände unseres Herrn laden uns auch ein, unsere Teilhabe an seinem ewigen Priestertum zu betrachten und von da her unsere Verantwortung zu sehen, als Glieder seines Leibes die versöhnende Kraft seines Opfers in die Welt zu tragen, in der wir leben.
<G-vec00355-002-s603><bring.tragen><en> However, children also serve as multipliers when they bring their knowledge back to their communities and are especially suited to serve as ‘climate ambassadors’.
<G-vec00355-002-s603><bring.tragen><de> Kinder gelten aber auch als Multiplikatoren, wenn sie ihr Wissen in ihre Heimatgemeinden tragen und sind als sogenannte Klimabotschafter besonders geeignet.
<G-vec00355-002-s604><bring.tragen><en> Many culture professionals and academics around the world have got in touch with us via our model and bring their findings to bear in their own societies back at home.
<G-vec00355-002-s604><bring.tragen><de> Viele Kulturschaffende und Wissenschaftler in der Welt knüpfen über unser Modell Kontakt zu uns und tragen die gewonnenen Erkenntnisse dann wiederum nach Hause in die eigene Gesellschaft.
<G-vec00355-002-s605><bring.tragen><en> 92:14 They shall still bring forth fruit in old age; they shall be fat and flourishing;
<G-vec00355-002-s605><bring.tragen><de> Ps 92,15 Noch im hohen Alter wird er Frucht tragen, immer ist er kraftvoll und frisch.
<G-vec00355-002-s606><bring.tragen><en> Truly, the seed, the talent, the grace of God is there, and man has simply to work, take the seeds to bring them to the bankers.
<G-vec00355-002-s606><bring.tragen><de> Es ist wahr, den Samen, das Talent, die Gnade gibt der liebe Gott, und der Mensch hat bloß die Arbeit, den Samen aufzunehmen, das Geld zu Wechslern zu tragen.
<G-vec00355-002-s607><bring.tragen><en> That is why, we, former prisoners of concentration camps and ghettos should bring alive the memory of those tragic days as we were witnesses of the destruction of the Jewish people.
<G-vec00355-002-s607><bring.tragen><de> Deswegen sollen wir, die ehemaligen Häftlinge der Konzentrationslager und Ghettos, als Zeugen der Vernichtung des jüdischen Volks die lebendige Erinnerung der tragischen Tage tragen.
<G-vec00355-002-s608><bring.verleihen><en> Our long, short or medium red earrings, pure or mixed with other colors bring vitality to everyday outfits or for any event such as parties, weddings or cocktails.
<G-vec00355-002-s608><bring.verleihen><de> Unsere lange, kurzen oder mittelroten Ohrringe, pur oder gemischt mit anderen Farben, verleihen Alltagsoutfits oder Veranstaltungen wie Partys, Hochzeiten oder Cocktailpartys Vitalität.
<G-vec00355-002-s609><bring.verleihen><en> The combination of Cinema 4D and Redshift will bring an unprecedented accessibility and efficiency to 3D production.
<G-vec00355-002-s609><bring.verleihen><de> Die Kombination aus Cinema 4D und Redshift wird der 3D-Produktion eine bisher ungekannte Flexibilität und Effizienz verleihen.
<G-vec00355-002-s610><bring.verleihen><en> The Beethoven Suite awaits you with numerous fancy equipment details that bring Beethoven’s work to life.
<G-vec00355-002-s610><bring.verleihen><de> Die Beethoven Suite erwartet Sie mit zahlreichen ausgefallenen Ausstattungsdetails, die nicht nur Werken von Beethoven Klang und Raum verleihen.
<G-vec00355-002-s611><bring.verleihen><en> Cover seams and zip detailing on the sides bring a casual sporty flair to the design.
<G-vec00355-002-s611><bring.verleihen><de> Covernähte und Zipper-Details an den Seiten verleihen dem Design sportives Casual Flair.
<G-vec00355-002-s612><bring.verleihen><en> The voluminous Air-Sole and sock-like fit bring modern comforts to a shoe inspired by the '91 Air Max 180.
<G-vec00355-002-s612><bring.verleihen><de> Die voluminöse Air-Sole und die sockenähnliche Passform verleihen dem Schuh, der vom Air Max 180 aus dem Jahr 1991 inspiriert wurde, modernen Tragekomfort.
<G-vec00355-002-s613><bring.verleihen><en> This fusion of tradition with the modern style is the reason we can offer unique tile lines and bring a breath of fresh air into our customers’ interiors.
<G-vec00355-002-s613><bring.verleihen><de> Die Fusion von Tradition und Modernität ermöglicht es, den Kunden einzigartige Fliesenkollektionen anzubieten, die Innenräumen einen Hauch Frische verleihen.
<G-vec00355-002-s614><bring.verleihen><en> Dark roasted South American Arabicas with a touch of Robusta bring out the subtle cocoa and roasted cereal notes of this full-bodied decaffeinated espresso.
<G-vec00355-002-s614><bring.verleihen><de> Dunkel geröstete Arabicas aus Südamerika und ein Hauch von Robusta verleihen diesem vollmundigen koffeinfreien Espresso seine subtilen Noten von Kakao und geröstetem Getreide.
<G-vec00355-002-s615><bring.verleihen><en> The natural materials bring warmth and kindness to the facility, while the wide open view of nature soothes and relaxes. CONNECT WITH US Facebook
<G-vec00355-002-s615><bring.verleihen><de> Die sorgfältig ausgewählten natürlichen Materialien verleihen den Räumen eine Atmosphäre der Wärme und Freundlichkeit, und der weite offene Blick auf die Natur wirkt beruhigend und entspannend.
<G-vec00355-002-s616><bring.verleihen><en> Look at this mineral: however far it may evolve, it only evolves in its own condition; you cannot bring the crystal to a state where it can attain to sight: this is impossible.
<G-vec00355-002-s616><bring.verleihen><de> Sieh dieses Mineral: So weit es sich auch entfalten mag, es entfaltet sich nur auf seiner eigenen Stufe; man kann dem Kristall keine Stufe verleihen, in der es Sehkraft erlangen kann, dies ist unmöglich.
<G-vec00355-002-s617><bring.verleihen><en> This freedom has appealed to major stylists such as Vivienne Westwood, Jean-Paul Gaultier or Jason Wu who have been able to express their creative genius in order to bring to life models that have become iconic such as Karl Lagerfeld’s Glam stiletto with its ice cream...
<G-vec00355-002-s617><bring.verleihen><de> Diese Freiheit hat die bekanntesten Modedesigner wie Vivienne Westwood, Jean-Paul Gaulthier oder Jason Wu begeistert, die damit ihrem kreativen Genie Ausdruck verleihen konnten und Modelle entwickelten, die zu Ikonen wurden, wie die Glam-Pumps mit Eishörnchenabsatz von Karl Lagerfeld.
<G-vec00355-002-s618><bring.verleihen><en> Videos of glaciers and clear messages bring a highly emotional, high-quality component to the technological product.
<G-vec00355-002-s618><bring.verleihen><de> Gletschervideos und klare Botschaften verleihen dem technologischen Produkt eine stark emotionale und hochwertige Komponente.
<G-vec00355-002-s619><bring.verleihen><en> Services Thinner, faster, stronger, more flexible – graphene has the potential to bring a new dimension to technologies in fields as varied as fashion, medicine and transport.
<G-vec00355-002-s619><bring.verleihen><de> Dünner, schneller, stärker, flexibler – Graphen kann Technologien eine neue Dimension verleihen, und das in Fachgebieten, die so unterschiedlich sind wie Mode, Medizin und Verkehr.
<G-vec00355-002-s620><bring.verleihen><en> Product zoom Different patch motifs bring an eye-catching touch to this cosy, comfortable piece.
<G-vec00355-002-s620><bring.verleihen><de> Zoom Zoom Verschiedene Aufnäher-Motive verleihen diesem Hemd eine auffallende Note.
<G-vec00355-002-s621><bring.verleihen><en> Elegant pleated bands bring a feminine touch to this graphic Lacoste Live tee.
<G-vec00355-002-s621><bring.verleihen><de> Elegante Plisseestreifen verleihen diesem grafischen "Lacoste L!VE"-T-Shirt einen femininen Touch.
<G-vec00355-002-s622><bring.verleihen><en> A light toning palette and modern ceramics bring incredible charm and serenity to the atmosphere of this room.
<G-vec00355-002-s622><bring.verleihen><de> Eine helle Tonpalette und moderne Keramik verleihen der Atmosphäre dieses Raumes unglaublichen Charme und Gelassenheit.
<G-vec00355-002-s623><bring.verleihen><en> The large windows bring a lot of brightness in the chalet, especially in the large living room with its modern stone fireplace that recalls this notion of mountain chalet.
<G-vec00355-002-s623><bring.verleihen><de> Die großen Fenster verleihen dem Chalet viel Helligkeit, vor allem im großen Wohnzimmer mit dem modernen Steinkamin, der an diese Vorstellung eines Berghauses erinnert.
<G-vec00355-002-s624><bring.verleihen><en> Griebel’s figures bring shape to this grappling with our place on the planet, their abjection reflecting the personal, psychological turmoil in attempting to rethink our place in the universe.
<G-vec00355-002-s624><bring.verleihen><de> Griebels Figuren verleihen dieser Auseinandersetzung mit unserem Platz auf dem Planeten Form, ihr Elend spiegelt die persönlichen, psychischen Turbulenzen in dem Versuch, unseren Platz im Universum zu überdenken.
<G-vec00355-002-s625><bring.verleihen><en> The new mode is available for all players and will bring a new experience to the game: teams' smaller size provides more room for maneuver and the contribution of each player to the battle result rises.
<G-vec00355-002-s625><bring.verleihen><de> Der neue Modus wird für alle Spieler verfügbar sein und dem Spiel eine neue Dimension verleihen: Kleinere Teams haben mehr Spielraum für Taktiken und erfordern den Beitrag eines jeden Spielers, um das Gefecht zu gewinnen.
<G-vec00355-002-s626><bring.verleihen><en> Thousands of people voted and together we’re going to bring new breadth to the global climate change conversation just as our leaders prepare to meet in Copenhagen this December in an effort to agree on lasting solutions to this crisis.
<G-vec00355-002-s626><bring.verleihen><de> Tausende von Menschen haben abgestimmt und gemeinsam werden wir der globalen Diskussion um den Klimawandel neue Bedeutung verleihen, genau wie unsere Spitzenpolitiker, die sich auf ein Treffen in Kopenhagen vorbereiten, bei dem eine nachhaltige Lösung für diese Krise gefunden werden soll.
<G-vec00355-002-s627><bring.zurückbringen><en> Remember: if you bring back any duty-free goods you bought when you travelled out from Ireland, these count as part of your allowance.
<G-vec00355-002-s627><bring.zurückbringen><de> Nicht vergessen: Wenn Sie zollfreie Waren zurückbringen, die Sie gekauft haben, als Sie Irland verlassen haben, zählen diese zu Ihrer Zollbefreiung.
<G-vec00355-002-s628><bring.zurückbringen><en> Deliver him into my keeping, and I will bring him back to you.
<G-vec00355-002-s628><bring.zurückbringen><de> Gib ihn in meine Hand, und ich werde ihn zu dir zurückbringen.
<G-vec00355-002-s629><bring.zurückbringen><en> During this time the students can pick up the equipment they need for their projects and also bring back the tools they no longer need.
<G-vec00355-002-s629><bring.zurückbringen><de> Während dieser Zeit können die Studierenden die für ihr Projekt notwendige Ausrüstung abholen und zurückbringen.
<G-vec00355-002-s630><bring.zurückbringen><en> Shopping: you can bring back superb masks, wooden statues, colorful jewelry.
<G-vec00355-002-s630><bring.zurückbringen><de> Einkaufen: Sie können hervorragende Masken, hölzerne Statuen, bunte Schmuckstücke zurückbringen.
<G-vec00355-002-s631><bring.zurückbringen><en> But if we bring that closer to ignorance, it is because we believe that when the heart is not ready enough, sometimes some teachings come and do not settle until the day the Lord will speak again.
<G-vec00355-002-s631><bring.zurückbringen><de> Aber wenn wir dies zur Unwissenheit zurückbringen, dann deshalb, weil wir uns selbst sagen, dass, wenn das Herz nicht genug vorbereitet ist, manchmal bestimmte Lehren kommen und sich nicht niederlassen, bis zu dem Tag, an dem der Herr noch sprechen wird.
<G-vec00355-002-s632><bring.zurückbringen><en> Furthermore, we like to bring back some 80’s style with our retro jackets in which you can really make a statement.
<G-vec00355-002-s632><bring.zurückbringen><de> Außerdem möchten wir mit unseren Retrojacken den Stil der 80er Jahre zurückbringen.
<G-vec00355-002-s633><bring.zurückbringen><en> Because we come pick you up and bring you back home it doesn t really matter where you wish to stay in Amed.
<G-vec00355-002-s633><bring.zurückbringen><de> Weil wir Sie vom Hotel abholen und wieder nach Hause zurückbringen, ist es egal wo in Amed Sie übernachten moechten.
<G-vec00355-002-s634><bring.zurückbringen><en> Now be aware and consider what word I shall bring again to him that sent me.
<G-vec00355-002-s634><bring.zurückbringen><de> Nun wisse und sieh, was für eine Antwort ich dem zurückbringen soll, der mich gesandt hat.
<G-vec00355-002-s635><bring.zurückbringen><en> I bring him not to thee: deliver him into my hand, and I will
<G-vec00355-002-s635><bring.zurückbringen><de> Gieb ihn in meine Hand und ich werde ihn zu dir zurückbringen.
<G-vec00355-002-s636><bring.zurückbringen><en> I wonder if a hypnotist could bring the memory back.
<G-vec00355-002-s636><bring.zurückbringen><de> Ich frage mich ob ein Hypnotiseur mir die Erinnerung zurückbringen könnte.
<G-vec00355-002-s637><bring.zurückbringen><en> In other words, David seemed to be saying that he would see his baby son (in heaven), though he could not bring him back.
<G-vec00355-002-s637><bring.zurückbringen><de> Mit anderen Worten: David wollte wohl sagen, dass er das Kind (im Himmel) wiedersehen würde, obwohl er es nicht zurückbringen konnte.
<G-vec00355-002-s638><bring.zurückbringen><en> 23:4 If you meet yours enemy's ox or his ass going astray, you shall surely bring it back to him again.
<G-vec00355-002-s638><bring.zurückbringen><de> 23:4 Wenn du den Ochsen deines Feindes oder seinen Esel umherirrend antriffst, sollst du ihn demselben jedenfalls zurückbringen.
<G-vec00355-002-s639><bring.zurückbringen><en> The relations of Russia and Syria are not new, we will try to bring them back to the previous level”, said the opposition leader.
<G-vec00355-002-s639><bring.zurückbringen><de> Die Beziehungen zwischen Russland und Syrien sind nicht neu, und wir versuchen, sie auf das vorherige Niveau zurückbringen», sagte der Oppositionsführer .
<G-vec00355-002-s640><bring.zurückbringen><en> At the end of the rental period you can bring the sets back to us or send them to us.
<G-vec00355-002-s640><bring.zurückbringen><de> Am Ende der Mietzeit können Sie die Sets zu uns zurückbringen oder uns zusenden.
<G-vec00355-002-s641><bring.zurückbringen><en> Due to our cost-per-click pricing model you still only pay for the users that we were able to bring back to the site.
<G-vec00355-002-s641><bring.zurückbringen><de> Da unsere Preisgestaltung auf dem CPC-Modell basiert, zahlen Sie nur für die Nutzer, die wir tatsächlich auf Ihre Seite zurückbringen.
<G-vec00355-002-s642><bring.zurückbringen><en> It is also this originality that will allow your brand to stay in the mind of your audience and bring them back to your platforms.
<G-vec00355-002-s642><bring.zurückbringen><de> Durch diese Originalität wird Ihre Marke im Gedächtnis Ihrer Zielgruppe bleiben und sie auf Ihre Plattformen zurückbringen.
<G-vec00355-002-s643><bring.zurückbringen><en> This strain will take you back in time and will bring back memories of smoking the original white widow.
<G-vec00355-002-s643><bring.zurückbringen><de> Diese Sorte wird Sie in die Vergangenheit zurückversetzen und Erinnerungen an das Rauchen der ursprünglichen White Widow zurückbringen.
<G-vec00355-002-s644><bring.zurückbringen><en> To be honest, it was all right with me to bring back the child, because during the climbing I got ill, again.
<G-vec00355-002-s644><bring.zurückbringen><de> Ehrlich gesagt, mir war es ganz recht, dass ich das Kind zurückbringen musste, denn mir war beim Aufstieg schon wieder übel.
<G-vec00355-002-s645><bring.zurückbringen><en> Maybe the sounds and smells bring back memories of bad experiences as a child, or make you think that having treatment will hurt.
<G-vec00355-002-s645><bring.zurückbringen><de> Vielleicht sind es die Geräusche und Gerüche, die unangenehme Kindheitserinnerungen zurückbringen, oder mit denen man eine schmerzhafte Behandlung assoziiert.
<G-vec00011-002-s057><bring.bringen><en> “WE BRING IDEAS TO LIFE.” briefly describes Doehler’s holistic and strategic approach to innovation.
<G-vec00011-002-s057><bring.bringen><de> „WE BRING IDEAS TO LIFE.“ beschreibt prägnant den integrierten Leistungsansatz.
<G-vec00011-002-s058><bring.bringen><en> Unicorn Killer — fresh taste music: Bring Me The Horizon
<G-vec00011-002-s058><bring.bringen><de> Offizielle schwarze Mütze der britischen Band Bring Me The Horizon.
<G-vec00011-002-s059><bring.bringen><en> Bring your personal touch and your perspective, be open and direct but always be friendly.
<G-vec00011-002-s059><bring.bringen><de> Bring dich und deine Sichtweise ein, sei offen und direkt, aber immer freundlich.
<G-vec00011-002-s060><bring.bringen><en> Bring and pick up service from and to Toverland is possible.
<G-vec00011-002-s060><bring.bringen><de> Bring und Abholservice von und nach Toverland ist möglich.
<G-vec00011-002-s061><bring.bringen><en> Bring It In To start the betting on the first round.
<G-vec00011-002-s061><bring.bringen><de> Bring It In - um die Wette an die erste Runde zu beginnen.
<G-vec00011-002-s062><bring.bringen><en> You can choose from 20 arrangements for 18 instruments for the composition Santa, Bring My Baby Back (To Me).
<G-vec00011-002-s062><bring.bringen><de> Sie können aus 20 Arrangements für 18 Musikinstrumente der Komposition Santa, Bring My Baby Back (To Me) wählen.
<G-vec00011-002-s063><bring.bringen><en> Bring your own campervan.
<G-vec00011-002-s063><bring.bringen><de> Bring dein eigenes Reisemobil mit.
<G-vec00011-002-s064><bring.bringen><en> Bring torch or diving light, DSMB and wrist compass.
<G-vec00011-002-s064><bring.bringen><de> Bring Fackel oder Tauchlicht, DSMB und Handgelenk Kompass.
<G-vec00011-002-s065><bring.bringen><en> Remember to bring a padlock or buy one from reception for £3.50.
<G-vec00011-002-s065><bring.bringen><de> Bitte bring ein Vorhängeschloss mit oder kaufe eins an der Rezeption für £3.
<G-vec00011-002-s066><bring.bringen><en> You are able to buy new or use existing FileMaker software licenses via Bring Your Own License (BYOL).
<G-vec00011-002-s066><bring.bringen><de> Über Bring Your Own License (BYOL) können Sie neue FileMaker-Software-Lizenzen kaufen oder bereits bestehende Lizenzen verwenden.
<G-vec00011-002-s067><bring.bringen><en> Bring your own to share.
<G-vec00011-002-s067><bring.bringen><de> Bring dein Lieblingsspiel mit.
<G-vec00011-002-s068><bring.bringen><en> Bring Me Flowers - stock photography images.
<G-vec00011-002-s068><bring.bringen><de> Bring mir Blumen - Sammlung von photographischen Bildern.
<G-vec00011-002-s069><bring.bringen><en> Bring me peace and solace.
<G-vec00011-002-s069><bring.bringen><de> Bring mir Frieden und Trost.
<G-vec00011-002-s070><bring.bringen><en> In 2016, around 85% of packaging that was collected for recycling in Spain was collected via bring banks.
<G-vec00011-002-s070><bring.bringen><de> In 2016 wurde ungefähr 85% von Verpackungsmüll in Spanien durch „Bring Banks“ gesammelt.
<G-vec00011-002-s071><bring.bringen><en> 7 And this [is] of Judah: And he said, Hear, LORD, the voice of Judah, and bring him into his people. With his hands he contended for himself, and thou shall be a help against his adversaries.
<G-vec00011-002-s071><bring.bringen><de> 7 Und dieses von Juda; und er sprach: Höre, Jehova, die Stimme Juda's, und zu seinem Volke bring ihn, seine Hand streite für ihn, und Hülfe gegen seine Feinde sey du.
<G-vec00011-002-s072><bring.bringen><en> • Free Shopping: Bring with you what you do not need and take what you want.
<G-vec00011-002-s072><bring.bringen><de> • Umsonstladen: Bring mit, was Du nicht brauchst und nimm was Du willst.
<G-vec00011-002-s073><bring.bringen><en> The cover “Bring it home to me” followed, when Steve asked the audience to start snipping.
<G-vec00011-002-s073><bring.bringen><de> Es folgte das Cover „Bring it home to me“, wofür Steve das Publikum zum Schnippen aufforderte.
<G-vec00011-002-s074><bring.bringen><en> In this case it is necessary to say the following words: "The hair is long, drowned, bring me the spirit of water.
<G-vec00011-002-s074><bring.bringen><de> In diesem Fall ist es notwendig, die folgenden Worte zu sagen: "Die Haare sind lang, ertränkt, bring mir den Geist des Wassers.
<G-vec00011-002-s075><bring.bringen><en> Bring them in bring them in
<G-vec00011-002-s075><bring.bringen><de> Bring sie doch zurück zu mir.
<G-vec00011-002-s076><bring.bringen><en> Inhale as you bend your elbows and bring your butt towards the floor.
<G-vec00011-002-s076><bring.bringen><de> Atme ein, beuge die Ellbogen und bringe deinen Po zum Boden.
<G-vec00011-002-s077><bring.bringen><en> Let me be thy proper servant, who took him into my trust, and promised, saying: If I bring him not again, I will be guilty of sin against my father for ever.
<G-vec00011-002-s077><bring.bringen><de> Denn ich, dein Knecht, bin Bürge geworden für den Knaben gegen meinen Vater und sprach: Bringe ich ihn dir nicht wieder, so will ich mein Leben lang die Schuld tragen.
<G-vec00011-002-s078><bring.bringen><en> He is to bring it to the priest, who is to take a handful of it to be put on the burnt offering for Yahweh in order to recall this man to Yahweh.
<G-vec00011-002-s078><bring.bringen><de> 12 Er bringe es dem Priester, der davon eine Hand voll nimmt und als Gedächtnisanteil auf dem Altar mit den Feueropfern des Herrn in Rauch aufgehen lässt.
<G-vec00011-002-s079><bring.bringen><en> Bring yourself and your skills into the battle, slip into the role of a paratrooper, tank commander or sniper and immerse yourself in realistic battles.
<G-vec00011-002-s079><bring.bringen><de> Bringe Dich und Deine Fähigkeiten in den Kampf, schlüpfe in die Rolle eines Fallschirmjägers, Panzerkommandanten oder Scharfschützen und tauche ein in realistische Schlachten.
<G-vec00011-002-s080><bring.bringen><en> Now it happened one day that he was going to a fair; so he asked his daughter, who was named Betta, what she would like him to bring her on his return. And she said, "Papa, if you love me, bring me half a hundredweight of Palermo sugar, and as much again of sweet almonds, with four to six bottles of scented water, and a little musk and amber, also forty pearls, two sapphires, a few garnets and rubies, with some gold thread, and above all a trough and a little silver trowel."
<G-vec00011-002-s080><bring.bringen><de> Als er nun einmal zu einer Messe reisen musste, fragte er seine Tochter, die Betta hieß, was er ihr mitbringen solle, worauf sie erwiderte: »Wenn du mich liebhast, Väterchen, so bringe mir einen halben Zentner Palermozucker, einen halben süße Mandeln, vier bis sechs Flaschen wohlriechendes Wasser, etwas Moschus und Ambra, ferner etwa vierzig Stück Perlen, zwei Saphire, einige Granaten und Rubine, etwas Goldgespinst, besonders aber einen Backtrog und Kratzmesser von Silber.« Der Vater wunderte sich zwar über diese etwas unbescheidene Forderung, wollte aber seiner Tochter nicht widersprechen, er reiste daher zur Messe ab und brachte ihr bei seiner Rückkehr ganz genau alles, was sie gewünscht.
<G-vec00011-002-s081><bring.bringen><en> Bring your written notes with you when you go to the meeting, as well as any other coworkers who also wish to complain.
<G-vec00011-002-s081><bring.bringen><de> Bringe deine schriftlichen Notizen zu dem Meeting und sorge dafür, dass alle Kollegen, die deine Sache unterstützen, ebenfalls zu dem Termin erscheinen.
<G-vec00011-002-s082><bring.bringen><en> 23 And he shall bring them on the eighth day for his cleansing unto the priest, unto the door of the tabernacle of the congregation, before YHVH.
<G-vec00011-002-s082><bring.bringen><de> 23 und bringe sie am achten Tage seiner Reinigung zum Priester vor die Tür der Hütte des Stifts, vor den HERRN.
<G-vec00011-002-s083><bring.bringen><en> 4Then Pilate went out again, and said to them, PONTIUS PILATE Behold, I bring him out to you, that you may know that I find no basis for a charge against him.
<G-vec00011-002-s083><bring.bringen><de> Pilatus ging wieder hinaus und sagte zu ihnen: Seht ich bringe ihn zu euch heraus; ihr sollt wissen, das ich keinen Grund finde, ihn zu verurteilen.
<G-vec00011-002-s084><bring.bringen><en> Go deeper than the surface with personal stories and context that bring the experience to life.
<G-vec00011-002-s084><bring.bringen><de> Gehe tiefer als die Oberfläche und bringe deine Entdeckung mit persönlichen Geschichten und ihrem besonderen Hintergrund zum Leben.
<G-vec00011-002-s085><bring.bringen><en> 6:25 Then hear thou from heaven, and forgive the sin of thy people Israel, and bring them back into the land, which thou gavest to them, and their fathers.
<G-vec00011-002-s085><bring.bringen><de> 6:25 so höre du vom Himmel her und vergib die Sünde deines Volkes Israel; und bringe sie in das Land zurück, das du ihnen und ihren Vätern gegeben hast.
<G-vec00011-002-s086><bring.bringen><en> 5:7 And if he shall not be able to bring a lamb, then he shall bring for his trespass which he hath committed, two turtle-doves, or two young pigeons, to the LORD; one for a sin-offering, and the other for a burnt-offering.
<G-vec00011-002-s086><bring.bringen><de> 5:7 Vermag er aber nicht ein Schaf, so bringe er dem HERRN für seine Schuld, die er getan hat, zwo Turteltauben oder zwo junge Tauben, die erste zum Sündopfer, die andere zum Brandopfer.
<G-vec00011-002-s087><bring.bringen><en> Join the gods of Greek legend and bring peace to an ancient world on the brink of war!
<G-vec00011-002-s087><bring.bringen><de> Bringe einer alten Welt, die an der Schwelle des Krieges steht, Seite an Seite mit den griechischen Göttern Frieden.
<G-vec00011-002-s088><bring.bringen><en> In this book, I bring you in as you bring your marketing into the present and make it a success driver for your company.
<G-vec00011-002-s088><bring.bringen><de> In diesem Buch bringe ich Ihnen bei, wie Sie Ihr Marketing in die Gegenwart holen und es zu einem Erfolgstreiber in Ihrem Unternehmen machen.
<G-vec00011-002-s089><bring.bringen><en> 24When your people Israel are defeated by an enemy because they have sinned against you, and then they turn, praise your name, pray to you, and entreat you in this house, 25listen from heaven and forgive the sin of your people Israel, and bring them back to the land you gave them and their ancestors.
<G-vec00011-002-s089><bring.bringen><de> 24Und wenn dein Volk Israel vor dem Feinde geschlagen wird, weil sie wider dich gesündigt haben, und sie kehren um und bekennen deinen Namen und beten und flehen zu dir in diesem Hause: 25so höre du vom Himmel her und vergib die Sünde deines Volkes Israel; und bringe sie in das Land zurück, das du ihnen und ihren Vätern gegeben hast.
<G-vec00011-002-s090><bring.bringen><en> Bring your kicking leg out to the side or in front of you with the knee bent all the way.
<G-vec00011-002-s090><bring.bringen><de> Bringe das Bein, mit dem du trittst, zur Seite oder nach vorne mit gebeugtem Knie.
<G-vec00011-002-s091><bring.bringen><en> And I will bring you into the land of Israel.
<G-vec00011-002-s091><bring.bringen><de> Ich bringe euch zurück in das Land Israel.
<G-vec00011-002-s092><bring.bringen><en> So why is it, that you do not fight in the way of Allah, and for the abased among men, women, and children who say: 'Our Lord, bring us out from this village whose people are harmdoers, and give to us a guardian from You, and give to us a helper from You.
<G-vec00011-002-s092><bring.bringen><de> Was ist mit euch, daß ihr nicht auf Allahs Weg, und (zwar) für die Unterdrückten unter den Männern, Frauen und Kindern kämpft, die sagen: "Unser Herr, bringe uns aus dieser Stadt heraus, deren Bewohner ungerecht sind, und schaffe uns von Dir aus einen Schutzherrn, und schaffe uns von Dir aus einen Helfer.
<G-vec00011-002-s093><bring.bringen><en> Let the earth open that it may bring forth salvation, and let it cause righteousness to spring up together.
<G-vec00011-002-s093><bring.bringen><de> Die Erde tue sich auf und bringe Heil, und Gerechtigkeit wachse mit zu.
<G-vec00011-002-s094><bring.bringen><en> ¶ And if he cannot afford to bring a she lamb, then he shall bring for his sin offering two turtledoves or two young pigeons, one for a sin offering and the other for a burnt offering.
<G-vec00011-002-s094><bring.bringen><de> Kann er aber nicht so viel aufbringen, dass es für ein Lamm reicht, so bringe er dem Herrn für das, worin er gesündigt hat, als sein Schuldopfer zwei Turteltauben oder zwei junge Tauben dar; eine als Sündopfer, die andere als Brandopfer.
<G-vec00011-002-s095><bring.bringen><en> A war that would bring those swinging sixties to an end.
<G-vec00011-002-s095><bring.bringen><de> Ein Krieg, der diese "Swinging Sixties" zu einem bitteren Ende bringen würde.
<G-vec00011-002-s096><bring.bringen><en> We bring you up to date regarding the upcoming General Data Protection Regulation, provide information on recent judgements and (planned) legislation amendments.
<G-vec00011-002-s096><bring.bringen><de> Wir bringen Sie auf den neusten Stand zur kommenden Datenschutzgrundverordnung, informieren über aktuelle Urteile und (geplante) Gesetzesänderungen.
<G-vec00011-002-s097><bring.bringen><en> The Arabic reads, "Stab, and your hands will bring victory."
<G-vec00011-002-s097><bring.bringen><de> Der Text lautet: „Stich zu und deine Hände werden den Sieg bringen“ (Jerusalem Brigaden).
<G-vec00011-002-s098><bring.bringen><en> Then add the flour mixture to the pan along with the remaining vegetable broth. Stir constantly and bring to the boil.
<G-vec00011-002-s098><bring.bringen><de> Die Mehlmischung zusammen mit der restlichen Gemüsebrühe in die Pfanne geben und unter Rühren zum Kochen bringen.
<G-vec00011-002-s099><bring.bringen><en> It is our goal to bring products on the market that are as clean and pure as possible, and that contributes to a healthy lifestyle.
<G-vec00011-002-s099><bring.bringen><de> Unser Ziel ist es, ein Produkt auf den Markt zu bringen, das so sauber und rein wie möglich ist, und zu einem gesunden Lebensstil beiträgt.
<G-vec00011-002-s100><bring.bringen><en> “We are incredibly excited to bring virtual reality to PlayStation 4,” said Jim Ryan, President of Global Sales and Marketing, SIE and President of SIEE.
<G-vec00011-002-s100><bring.bringen><de> „Wir freuen uns wirklich sehr darauf, die virtuelle Realität auf PlayStation 4 zu bringen“, so Jim Ryan, President of Global Sales and Marketing von SIE sowie President von SIEE.
<G-vec00011-002-s101><bring.bringen><en> Surely that will bring Dawg out of hiding.
<G-vec00011-002-s101><bring.bringen><de> Das wird Dawg sicherlich aus dem Versteck bringen.
<G-vec00011-002-s102><bring.bringen><en> On point #2: Only properly trained drivers and escorts are fit to bring a heavy load transport safely and competently to its destination.
<G-vec00011-002-s102><bring.bringen><de> Zu Punkt 2: Nur gut geschulte Fahrer und Begleiter sind in der Lage, einen Schwertransport sicher und souverän ans Ziel zu bringen.
<G-vec00011-002-s103><bring.bringen><en> However, this means that the gym exercises and a balanced diet will not bring such good results if they are not supported by properly matched slimming pills.
<G-vec00011-002-s103><bring.bringen><de> Dies bedeutet jedoch, dass die Gymnastikübungen und eine ausgewogene Ernährung nicht so gute Ergebnisse bringen, wenn sie nicht durch richtig abgestimmte Schlankheitspillen unterstützt werden.
<G-vec00011-002-s104><bring.bringen><en> 6 You must also bring to the Supreme Priest a ram to be an offering to me in order that you will no longer be guilty.
<G-vec00011-002-s104><bring.bringen><de> 6 5:25 Aber für seine Schuld soll er dem HERRN zu dem Priester einen Widder von der Herde ohne Fehl bringen, der eines Schuldopfers wert ist.
<G-vec00011-002-s105><bring.bringen><en> One was at this point, however, still clearly said: it is never too late Even if you have exceeded the 45 some time ago, can be obtained by the regular daily intake of melatonin to normalize Zirbeldrüsenfunktion again and the natural, endogenous melatonin production to a level bring corresponds to a much younger body.
<G-vec00011-002-s105><bring.bringen><de> Eines sei an dieser Stelle jedoch noch deutlich gesagt: es ist nie zu spät Auch wenn man die 45 schon vor längerer Zeit überschritten hat, kann man durch die regelmäßige tägliche Einnahme von Melatonin, die Zirbeldrüsenfunktion wieder normalisieren und die natürliche, körpereigene Melatoninproduktion auf ein Niveau bringen, das einem wesentlich jüngeren Organismus entspricht.
<G-vec00011-002-s106><bring.bringen><en> The foreman told me, “You can bring the materials to the factory if you have any.
<G-vec00011-002-s106><bring.bringen><de> Der Vorarbeiter sagte, “Du kannst die Materialien in die Firma bringen, wenn du welche hast.
<G-vec00011-002-s107><bring.bringen><en> Close with a lid and bring to a boil.
<G-vec00011-002-s107><bring.bringen><de> Einen Deckel auflegen und zum Kochen bringen.
<G-vec00011-002-s108><bring.bringen><en> Many people believe that having a pharmacy in Ukraine is synonymous of success since normally in the cities there is a limit per zone, but still many coexist in a very close ratio, if you want to stand out about them and bring you more customers, please, sign up for our directory of Pharmacies in L’vivs’ka oblast’.
<G-vec00011-002-s108><bring.bringen><de> Viele Leute glauben, dass eine Apotheke in Deutschland gleichbedeutend mit Erfolg ist, denn normalerweise in den Städten gibt es eine Grenze pro Zone, aber immer noch viele koexistieren in einem sehr engen Verhältnis, wenn Sie sich über sie herausstellen und Ihnen mehr Kunden bringen wollen Bitte melden Sie sich für unser Verzeichnis von Apotheken in Veelböken.
<G-vec00011-002-s109><bring.bringen><en> The opulent main courses that bring a taste of the Orient to Cologne are also very well received by diners.
<G-vec00011-002-s109><bring.bringen><de> Aber auch die opulenten Hauptspeisen bringen einen Hauch Orient mit nach Köln und kommen bei den Gästen bestens an.
<G-vec00011-002-s110><bring.bringen><en> Great quality with popular, beautiful designs and melodious music bring you the warmest regards and unlimited happiness all the time, especially as a gift to your friends.
<G-vec00011-002-s110><bring.bringen><de> Große Qualität mit bekannten, schönen Designs und melodische Musik bringen Sie den herzlichsten Grüßen und unbegrenztes Glück die ganze Zeit, vor allem als Geschenk für Ihre Freunde.
<G-vec00011-002-s111><bring.bringen><en> The non-agricultural labourers of an Asiatic monarchy have little but their individual bodily exertions to bring to the task, but their number is their strength, and the power of directing these masses gave rise to the palaces and temples, the pyramids, and the armies of gigantic statues of which the remains astonish and perplex us.
<G-vec00011-002-s111><bring.bringen><de> Die nicht ackerbauenden Arbeiter einer asiatischen Monarchie haben außer ihren individuellen körperlichen Bemühungen wenig zum Werk zu bringen, aber ihre Zahl ist ihre Kraft, und die Macht der Direktion über diese Massen gab jenen Riesenwerken den Ursprung.
<G-vec00011-002-s112><bring.bringen><en> The ocean-going ships were converted for the purpose of sea rescue and patrol alternately off the Libyan coast, where most of the fleeing people, in the attempt to bring to safety, go in greatest mortal danger.
<G-vec00011-002-s112><bring.bringen><de> Die hochseetauglichen Schiffe wurden für den Zweck der Seenotrettung umgerüstet und patrouillieren abwechselnd vor der libyschen Küste, wo sich die meisten flüchtenden Menschen, bei dem Versuch sich in Sicherheit zu bringen, in größte Lebensgefahr begeben.
<G-vec00011-002-s113><bring.bringen><en> To benefit from this arrangement, please bring along the equivalent insurance form of your home health insurance.
<G-vec00011-002-s113><bring.bringen><de> Bringen Sie dazu bitte das entsprechende Formblatt der Krankenversicherung Ihres Heimatlandes mit.
<G-vec00011-002-s114><bring.bringen><en> Yamazaki Bring beauty & function to your home with Japanese homeware designer Yamazaki.
<G-vec00011-002-s114><bring.bringen><de> Yamazaki Bringen Sie mit dem japanischen Haushaltswaren-Designer Yamazaki Schönheit und Funktion in Ihr Zuhause.
<G-vec00011-002-s115><bring.bringen><en> There are many wet parts of the trail, you are inevitably going to get we, so bring waterproof shoes and clothes that will dry easy.
<G-vec00011-002-s115><bring.bringen><de> Es gibt viele nasse Teile des Weges, die Sie unweigerlich bekommen werden, bringen Sie also wasserdichte Schuhe und Kleidung mit, die leicht trocknen.
<G-vec00011-002-s116><bring.bringen><en> The House of Friendship is a wonderful place to bring your convention guests – your family and your friends from home.
<G-vec00011-002-s116><bring.bringen><de> Und das Schönste daran: Bringen Sie auch Ihre Gäste, Ihre Freunde, Ihre Familie mit.
<G-vec00011-002-s117><bring.bringen><en> Bring the water to a rolling boil, then add the sliced mushrooms.
<G-vec00011-002-s117><bring.bringen><de> Bringen Sie das Wasser zum kochen, dann geben Sie die in Scheiben geschnittenen Pilze dazu.
<G-vec00011-002-s118><bring.bringen><en> A travel cot (and a highchair) can be made available for either bedroom at no extra cost - just bring your own cot sheets.
<G-vec00011-002-s118><bring.bringen><de> Ein Kinderreisebett (und ein Hochstuhl) kann für beide Schlafzimmer ohne zusätzliche Kosten zur Verfügung gestellt werden - bringen Sie nur Ihre eigenen Kinderbett Bettwäsche.
<G-vec00011-002-s119><bring.bringen><en> Bring Payments to your iOS app
<G-vec00011-002-s119><bring.bringen><de> Bringen Sie Zahlungen zu Ihrer iOS App.
<G-vec00011-002-s120><bring.bringen><en> Bring 2 a 3 nuts to the hair.
<G-vec00011-002-s120><bring.bringen><de> Bringen Sie 2 ein 3 Muttern auf das Haar.
<G-vec00011-002-s121><bring.bringen><en> Bring a water bottle.
<G-vec00011-002-s121><bring.bringen><de> Bringen Sie eine Wasserflasche.
<G-vec00011-002-s122><bring.bringen><en> Follow the instructions and change his diaper, bring his favorite toys and play a while and make sure he gets tried and goes to sleep.
<G-vec00011-002-s122><bring.bringen><de> Folgen Sie den Anweisungen und wechseln Sie seine Windel, bringen Sie seine Lieblings-Spielzeug und spielen Sie eine Weile und stellen Sie sicher, er wird erprobt und in den Ruhezustand versetzt.
<G-vec00011-002-s123><bring.bringen><en> Bring focus, discipline and speed to your security operations center and mitigate the impact of data breaches with a swift, sure cyber incident response capability.
<G-vec00011-002-s123><bring.bringen><de> Bringen Sie Fokus, Disziplin und Tempo in Ihr Security Operations Center und vermindern Sie die Auswirkungen von Datenschutzverletzungen mit schnellen, zuverlässigen Funktionen zur Behandlung von Cyber-Incidents.
<G-vec00011-002-s124><bring.bringen><en> Wear your bathing suit under your wetsuit and bring a towel and your sense of adventure.
<G-vec00011-002-s124><bring.bringen><de> Tragen Sie Ihre Badesachen unter Ihrem Neoprenanzug und bringen Sie ein Handtuch und Ihre Abenteuerlust mit.
<G-vec00011-002-s125><bring.bringen><en> Discover with us secret boutiques, meet independent designers or ancient handicraft producers and bring back home an authentic Italian atmosphere.
<G-vec00011-002-s125><bring.bringen><de> Entdecken Sie mit uns geheime Boutiquen, treffen Sie unabhängige Designer oder alte Kunsthandwerker und bringen Sie eine authentische italienische Atmosphäre mit nach Hause.
<G-vec00011-002-s126><bring.bringen><en> Bonus tip: bring carnelian to the gym for a pocket-sized personal trainer who will always encourage you to do your very best.
<G-vec00011-002-s126><bring.bringen><de> Kleiner extra Tipp: Bringen Sie einen Karneol mit ins Fitnessstudio – als Personal Trainer im Taschenformat, der Sie stets ermutigen wird, Ihr Bestes zu geben.
<G-vec00011-002-s127><bring.bringen><en> Bring a friend, your child or anyone else you want to spend this time learning about the science of colours.
<G-vec00011-002-s127><bring.bringen><de> Bringen Sie einen Freund, Ihr Kind oder irgendjemand anderes, mit dem Sie diese Zeit verbringen möchten, um sich über die Wissenschaft der Farben zu informieren.
<G-vec00011-002-s128><bring.bringen><en> Bring extra weather gear and prepare for thunderstorms, or a sudden dip in the temperature.
<G-vec00011-002-s128><bring.bringen><de> Bringen Sie zusätzliche Kleidungsstücke mit und seien Sie auch auf ein Gewitter oder einen plötzlichen Temperatursturz vorbereitet.
<G-vec00011-002-s129><bring.bringen><en> With Pega Mashup, bring the intelligence of our Case Management directly to the customer touchpoint, instead of hard-coding logic into each channel independently.
<G-vec00011-002-s129><bring.bringen><de> Mit Pega Mashup bringen Sie die Intelligenz unseres Case Managements direkt zum Kundenkontaktpunkt, die Hartcodierung der Logik für jeden einzelnen Kanal entfällt.
<G-vec00011-002-s130><bring.bringen><en> You will find everything you need (linen and provisions, internal mini-market) so bring only your suitcases. Activity
<G-vec00011-002-s130><bring.bringen><de> Sie finden alles, was Sie brauchen (Bettwäsche und Proviant, Minimarkt), bringen Sie also nur Ihre Koffer mit.
<G-vec00011-002-s131><bring.bringen><en> Bring a good book, a camera, a glass of wine and a sense of adventure.
<G-vec00011-002-s131><bring.bringen><de> Bringen Sie ein gutes Buch, eine Kamera, ein Glas Wein und ein Gefühl von Abenteuer.
<G-vec00011-002-s132><bring.bringen><en> Use this rug as a decorative accessory in your living room or bring more comfort to your driveway.
<G-vec00011-002-s132><bring.bringen><de> Verwenden Sie diesen Teppich als dekoratives Accessoire in Ihrem Wohnzimmer oder bringen Sie mehr Komfort in Ihre Einfahrt.
<G-vec00011-002-s133><bring.bringen><en> One or more, she will bring a vintage style with its orange filaments.
<G-vec00011-002-s133><bring.bringen><de> Eine oder mehrere, bringt sie einen Vintage-Stil mit seinen orangefarbenen Filamente.
<G-vec00011-002-s134><bring.bringen><en> The rest of the day will bring cloudless weather.
<G-vec00011-002-s134><bring.bringen><de> Der Nachmittag bringt wechselnd bis stark bewölktes, aber verbreitet trockenes Wetter.
<G-vec00011-002-s135><bring.bringen><en> The evening will bring clouds with rain or sleet.
<G-vec00011-002-s135><bring.bringen><de> Die Mittagszeit bringt wechselhaftes Wetter mit ab und zu etwas Regen.
<G-vec00011-002-s136><bring.bringen><en> The noon will bring variable clouds with scattered rain showers.
<G-vec00011-002-s136><bring.bringen><de> Die Mittagszeit bringt unbeständiges und ab und zu nasses Wetter.
<G-vec00011-002-s137><bring.bringen><en> Android 7.0 System--High efficient Android 7.0 operating system with lower battery consumption and bring more high performance experience.
<G-vec00011-002-s137><bring.bringen><de> Android 7.0 System --Hochleistungsfähiges Android 7.0 Betriebssystem mit niedrigerem Batterieverbrauch und bringt mehr Hochleistungserfahrung.
<G-vec00011-002-s138><bring.bringen><en> The noon will bring variable cloudy, but mostly dry weather.
<G-vec00011-002-s138><bring.bringen><de> Der Nachmittag bringt sonniges oder leicht bewölktes Wetter.
<G-vec00011-002-s139><bring.bringen><en> Ex 23,20 "Behold, I am going to send an angel before you to guard you along the way and to bring you into the place which I have prepared.
<G-vec00011-002-s139><bring.bringen><de> 2Mo 23,20 Siehe, ich sende einen Engel vor dir her damit er dich auf dem Weg bewahrt und dich an den Ort bringt, den ich für dich bereitet habe.
<G-vec00011-002-s140><bring.bringen><en> Get the Noble Staff Components and bring it to Tataka.
<G-vec00011-002-s140><bring.bringen><de> Beschafft die Empyrianische Stabkomponente und bringt sie zu Tataka.
<G-vec00011-002-s141><bring.bringen><en> Givat Haviva is one of the biggest, oldest, and leading institutions which in Israel concern itself with Jewish Arab mutual understanding, which support cultural and religious pluralism, which work for democratic values and peace, and which bring the past of the Jewish people to the consciousness of the youth of today in its educational work.
<G-vec00011-002-s141><bring.bringen><de> Givat Haviva ist eines der größten, ältesten und führenden Institute, das sich in Israel für jüdisch-arabische Verständigung einsetzt, den kulturellen und religiösen Pluralismus fördert, für demokratische Werte und Frieden wirkt und die Vergangenheit des jüdischen Volkes in erzieherischer Arbeit der Jugend von heute nahe bringt.
<G-vec00011-002-s142><bring.bringen><en> The late evening will bring clouds with local snowfall.
<G-vec00011-002-s142><bring.bringen><de> Der Nachmittag bringt zeitweise sonniges Wetter.
<G-vec00011-002-s143><bring.bringen><en> We cannot predict what time will bring. But we can make it more beautiful.
<G-vec00011-002-s143><bring.bringen><de> Wir wissen nicht was die Zeit bringt, wir können sie aber schöner machen.
<G-vec00011-002-s144><bring.bringen><en> The night will bring cloudy, but mostly dry weather.
<G-vec00011-002-s144><bring.bringen><de> Der Nachmittag bringt wechselnd bewölktes und meist trockenes Wetter.
<G-vec00011-002-s145><bring.bringen><en> The noon will bring partly sunny, partly cloudy weather.
<G-vec00011-002-s145><bring.bringen><de> Die Mittagszeit bringt zeitweise sonniges Wetter.
<G-vec00011-002-s146><bring.bringen><en> Bring your tent, your passion and commitment and join us to stop the next generation of nuclear weapons from being built.
<G-vec00011-002-s146><bring.bringen><de> Bringt Euer Zelt, Eure Leidenschaft und Engagement und schließt Euch uns an, um zu verhindern, dass die nächste Generation von Atomwaffen gebaut wird.
<G-vec00011-002-s147><bring.bringen><en> Each sticker delivers a nice message for Christmas and will bring a chic touch to your gifts with their silver and gold colors.
<G-vec00011-002-s147><bring.bringen><de> Jeder Aufkleber liefert eine nette Nachricht für Weihnachten und bringt Ihren Geschenken mit ihren silbernen und goldenen Farben einen schicken Touch.
<G-vec00011-002-s148><bring.bringen><en> The evening will bring mostly cloudy weather.
<G-vec00011-002-s148><bring.bringen><de> Der Nachmittag bringt meist bewölktes, aber trockenes Wetter.
<G-vec00011-002-s149><bring.bringen><en> When one’s wishing turns to such subjects, he stops wishing and tries to acquire these by doing what he thinks will develop virtue and bring wisdom.
<G-vec00011-002-s149><bring.bringen><de> Wenn sich jemand solchen Themen zuwendet, hört er auf zu wünschen und versucht, diese zu erlangen, indem er das tut, von dem er glaubt, dass es Tugend entwickelt und Weisheit bringt.
<G-vec00011-002-s150><bring.bringen><en> The first stage only needs 10 Stars and will bring you 3000 Crystals, and the Microbiology Animated Paint if you have a Battle Pass.
<G-vec00011-002-s150><bring.bringen><de> Die erste Stufe benötigt nur 10 Sterne und bringt Euch 3000 Kristalle und die animierte Farbe «Mikrobiologie», wenn Ihr das Schlacht-Abonnement habt.
<G-vec00011-002-s151><bring.bringen><en> But Buddel is drunk so he might bring you to the wrong island.
<G-vec00011-002-s151><bring.bringen><de> Aber Buddel ist betrunken, deshalb kann es sein, dass er dich zur falschen Insel bringt.
<G-vec00011-002-s418><bring.mitbringen><en> Visitors will not be allowed to bring objects which could be misconstrued as weapons, including weapon-like cosplay items.
<G-vec00011-002-s418><bring.mitbringen><de> Besucher dürfen keine Objekte mitbringen, die für Waffen gehalten werden können, darunter waffenartige Cosplay-Gegenstände.
<G-vec00011-002-s419><bring.mitbringen><en> We hope that you will bring along your family and friends to enjoy this special occasion and look forward to sharing an unforgettable evening with you.
<G-vec00011-002-s419><bring.mitbringen><de> Wir hoffen, dass Sie Ihre Familie und Freunde mitbringen, um mit ihnen diesen besonderen Anlass zu feiern und wir freuen uns darauf, mit Ihnen allen einen unvergesslichen Abend zu verbringen.
<G-vec00011-002-s420><bring.mitbringen><en> Please inform the hotel in advance if you bring your pet. Hotel Facilities
<G-vec00011-002-s420><bring.mitbringen><de> Bitte informieren Sie das Hotel im Voraus, wenn Sie Ihr Haustier mitbringen.
<G-vec00011-002-s421><bring.mitbringen><en> The animal may not sleep in the Standard Igloos and you must bring an extra sleeping bag and blanket for your animal.
<G-vec00011-002-s421><bring.mitbringen><de> Das Tier darf nicht in den Standard-Iglus schlafen und Sie müssen einen eigenen Schlafsack und Decken für Ihr Tier mitbringen.
<G-vec00011-002-s422><bring.mitbringen><en> The town bell rings every hour - great for old world atmosphere and telling the time, but bring ear and the room is simple and comfortable.
<G-vec00011-002-s422><bring.mitbringen><de> Die Stadt Glocke läutet jede Stunde - ideal für alte Welt Atmosphäre und die Zeit, zu sagen, aber Ohrenstöpsel mitbringen, wenn Sie einen leichten Schlaf haben.
<G-vec00011-002-s423><bring.mitbringen><en> However, newcomers with basic knowledge also get a chance with knowis, if they want to develop further and bring the necessary motivation for the job.
<G-vec00011-002-s423><bring.mitbringen><de> Aber auch Quereinsteiger mit Grundlagenkenntnis bekommen bei knowis eine Chance, wenn sie sich weiterentwickeln möchten und die erforderliche Motivation für den Beruf mitbringen.
<G-vec00011-002-s424><bring.mitbringen><en> You can bring your own bed linen and towels or rent them on site at an extra cost of EUR 5 for towels and EUR 5 for bed linen per person per stay.
<G-vec00011-002-s424><bring.mitbringen><de> Ankündigungen Sie können Ihre eigene Bettwäsche und Handtücher mitbringen oder diese in der Unterkunft für EUR 6 für Bettwäsche und EUR 6 für Handtücher pro Person und Aufenthalt mieten.
<G-vec00011-002-s425><bring.mitbringen><en> It is not allowed to bring pets.
<G-vec00011-002-s425><bring.mitbringen><de> Das Mitbringen von Haustieren ist nicht gestattet.
<G-vec00011-002-s426><bring.mitbringen><en> Hungary | With these holiday houses it is explicitely allowed to bring pets so that your faithful four legged friend can also enjoy a relaxing and eventful holiday.
<G-vec00011-002-s426><bring.mitbringen><de> Ungarn | Bei diesen Ferienhäusern ist das Mitbringen von Haustieren ausdrücklich erlaubt, so dass auch ihr treuer Vierbeiner in den Genuss von erholsamen und ereignisreichen Urlaubstagen kommt.
<G-vec00011-002-s427><bring.mitbringen><en> A gentle, flowing yoga class for those who bring a little or a lot of yoga experience.
<G-vec00011-002-s427><bring.mitbringen><de> Eine sanfte, fließende Yoga Klasse für all jene, die ein wenig oder viel Yoga Erfahrung mitbringen.
<G-vec00011-002-s428><bring.mitbringen><en> Players are not required to bring their PS4 controllers.
<G-vec00011-002-s428><bring.mitbringen><de> Spieler müssen ihre PS4 Kontroller nicht mitbringen.
<G-vec00011-002-s429><bring.mitbringen><en> Now it happened one day that he was going to a fair; so he asked his daughter, who was named Betta, what she would like him to bring her on his return. And she said, "Papa, if you love me, bring me half a hundredweight of Palermo sugar, and as much again of sweet almonds, with four to six bottles of scented water, and a little musk and amber, also forty pearls, two sapphires, a few garnets and rubies, with some gold thread, and above all a trough and a little silver trowel."
<G-vec00011-002-s429><bring.mitbringen><de> Als er nun einmal zu einer Messe reisen musste, fragte er seine Tochter, die Betta hieß, was er ihr mitbringen solle, worauf sie erwiderte: »Wenn du mich liebhast, Väterchen, so bringe mir einen halben Zentner Palermozucker, einen halben süße Mandeln, vier bis sechs Flaschen wohlriechendes Wasser, etwas Moschus und Ambra, ferner etwa vierzig Stück Perlen, zwei Saphire, einige Granaten und Rubine, etwas Goldgespinst, besonders aber einen Backtrog und Kratzmesser von Silber.« Der Vater wunderte sich zwar über diese etwas unbescheidene Forderung, wollte aber seiner Tochter nicht widersprechen, er reiste daher zur Messe ab und brachte ihr bei seiner Rückkehr ganz genau alles, was sie gewünscht.
<G-vec00011-002-s430><bring.mitbringen><en> The Client shall not be allowed to bring along food or drinks to events.
<G-vec00011-002-s430><bring.mitbringen><de> Der Kunde darf Speisen und Getränke zu Veranstaltungen grundsätzlich nicht mitbringen.
<G-vec00011-002-s431><bring.mitbringen><en> You can’t bring goods from endangered species (CITES) into Sweden at any time without special permit.
<G-vec00011-002-s431><bring.mitbringen><de> Ohne Sondergenehmigung können Sie zu keiner Zeit Güter gefährdeter Arten (CITES) nach Schweden mitbringen.
<G-vec00011-002-s432><bring.mitbringen><en> A rustic mason’s canteen provides an inviting resting place where you can also bring your own snack.
<G-vec00011-002-s432><bring.mitbringen><de> Eine zünftige Steinhauerkantine steht zur Verfügung, in der man auch seine eigene Brotzeit mitbringen kann.
<G-vec00011-002-s433><bring.mitbringen><en> Who is not a couple should eventually bring a second blanket.
<G-vec00011-002-s433><bring.mitbringen><de> Wer kein Paar ist, sollte eventuell eine zweite Bettdecke mitbringen.
<G-vec00011-002-s434><bring.mitbringen><en> Customs As a citizen of the EU or EEA, you can bring your private household possessions with you without any customs formalities.
<G-vec00011-002-s434><bring.mitbringen><de> Zoll Als EU- oder EWR-Bürger können Sie den privaten Hausrat ohne Zollformalitäten mitbringen.
<G-vec00011-002-s435><bring.mitbringen><en> In Lindy Hop besides the above, there are even two completely different formats, depending on your focus: In Lindy Intensive, you will be working on your technique intensively all day long for three days, and should bring with you the necessary attitude, energy and drive.
<G-vec00011-002-s435><bring.mitbringen><de> Im Lindy Hop haben wir sogar zwei völlig verschiedene Formate, je nachdem, wo du den Schwerpunkt legen möchtest: Im Lindy Intensive wirst du intensiv an deiner Technik arbeiten und solltest hierfür auch die Energie und den Ehrgeiz mitbringen.
<G-vec00011-002-s436><bring.mitbringen><en> Yes you can bring your own motorcycle, and it can be any make or model.
<G-vec00011-002-s436><bring.mitbringen><de> Selbstverständlich können Sie Ihr eigenes Motorrad mitbringen, egal welche Marke oder welches Modell.
<G-vec00011-002-s437><bring.mitnehmen><en> The zenith has certainly not passed, but the industry also has to realise that growth can’t be forced, and in particular that you need to bring the consumer along on this path.
<G-vec00011-002-s437><bring.mitnehmen><de> Der Zenit ist sicherlich nicht überschritten, die Branche muss nur realisieren, dass man Wachstum nicht erzwingen kann und vor allem, dass man die Konsumenten auf diesem Weg mitnehmen muss.
<G-vec00011-002-s438><bring.mitnehmen><en> Well, for the simple reason that sending the books would cost a lot for Mervi but since she’s coming to Berlin in December she can bring the books with her.
<G-vec00011-002-s438><bring.mitnehmen><de> Nun, darauf gibt es eine einfache Antwort: Die Versendung der Bücher würde Mervi eine Menge kostren, da sie aber im Dezember nach Berlin kommen wird, kann sie die Bücher mitnehmen.
<G-vec00011-002-s439><bring.mitnehmen><en> You can bring sporting equipment and other items instead of a suitcase only if you have booked your flight in a fare that includes hold luggage (in this case sporting equipment is included in the free baggage allowance).
<G-vec00011-002-s439><bring.mitnehmen><de> Anstelle eines Koffers, können Sie auch Sportausrüstungen oder Gegenstände mitnehmen nur wenn Sie einen Flug in einem Tarif, der ein Aufgabegepäck inkludiert, gebucht haben.
<G-vec00011-002-s440><bring.mitnehmen><en> We recommend you bring sportswear and shoes and hiking boots with you.
<G-vec00011-002-s440><bring.mitnehmen><de> Empfehlenswert: Sportbekleidung, Sport- und Wanderschuhe mitnehmen.
<G-vec00011-002-s441><bring.mitnehmen><en> There are several kinds of lightweight purifiers you can bring on your trip.
<G-vec00011-002-s441><bring.mitnehmen><de> Es gibt mehrere leichte Wasserfilter, die du auf deinem Trip mitnehmen kannst.
<G-vec00011-002-s442><bring.mitnehmen><en> For visits to the towns of Menorca or field trips you will have to bring another type of footwear suitable for walking.
<G-vec00011-002-s442><bring.mitnehmen><de> Für Besuche in den Städten der Insel oder Ausflüge müsstet ihr andere Schuhe mitnehmen, die zum Laufen geeignet sind.
<G-vec00011-002-s443><bring.mitnehmen><en> The minimalistic and super light sweater is the ultimate insulation piece to bring along as it requires minimal space and keeps the weight down.
<G-vec00011-002-s443><bring.mitnehmen><de> Der minimalistische und extrem leichte Sweater ist das ultimative Isolationsteil zum Mitnehmen, da er kaum Platz benötigt und das Packgewicht nicht erhöht.
<G-vec00011-002-s444><bring.mitnehmen><en> Finally - and this is the main reason I would bring it to my island with me - it gets you consistently high time after time.
<G-vec00011-002-s444><bring.mitnehmen><de> Letztendlich ist der Grund warum ich sie auf meine Insel mitnehmen würde, dass sie einen jedes Mal konstant high macht.
<G-vec00011-002-s445><bring.mitnehmen><en> Sadly you cannot bring Agro with you to this fight because he doesn't like to jump down this kind of height and is also afraid of dark unknown waters.
<G-vec00011-002-s445><bring.mitnehmen><de> Leider kannst du Agro nicht mitnehmen, da dieser es nicht mag aus luftigen Höhen in unbekannte Gewässer mitsamt den darin lauernden Gefahren zu springen.
<G-vec00011-002-s446><bring.mitnehmen><en> Even though we are planning a vacation to Indonesia in October, I wouldn’t bring most of the summer clothes I have new in my wardrobe.
<G-vec00011-002-s446><bring.mitnehmen><de> Auch, wenn wir für den Oktober nochmal einen Sommerurlaub planen, so werde ich viele der Sommerkleidung nicht dorthin mitnehmen.
<G-vec00011-002-s447><bring.mitnehmen><en> You're allowed to bring a total of one liter, divided on ten 100ml bottles.
<G-vec00011-002-s447><bring.mitnehmen><de> Man darf insgesamt einen Liter mitnehmen, allerdings aufgeteilt in zehn 100ml Fläschchen.
<G-vec00011-002-s448><bring.mitnehmen><en> You can bring all the drinks you want to the camping ground.
<G-vec00011-002-s448><bring.mitnehmen><de> Auf den Zeltplatz kannst du alle Getränke mitnehmen, die du gerne dabeihaben magst.
<G-vec00011-002-s449><bring.mitnehmen><en> I will bring with me, in my heart, the impression of these days.
<G-vec00011-002-s449><bring.mitnehmen><de> Ich werde den Eindruck dieser Tage mitnehmen, in meinem Herzen behalten.
<G-vec00011-002-s450><bring.mitnehmen><en> An extra cushion or favorite blanket can be good to bring.
<G-vec00011-002-s450><bring.mitnehmen><de> Sie können auch ein zusätzliches Kissen oder die Lieblingsdecke mitnehmen.
<G-vec00011-002-s451><bring.mitnehmen><en> Weighing only 7.1 kg (15.7 lbs), the rugged S1 Pro lets you bring better sound to the party, BBQ or outdoor get-together.
<G-vec00011-002-s451><bring.mitnehmen><de> Mit seinen leichten 7,1 kg können Sie das robuste S1 Pro System überallhin mitnehmen, um auf jeder Party für einen noch besseren Klang zu sorgen.
<G-vec00011-002-s452><bring.mitnehmen><en> The supply lists for destinations on our website are provided directly by the local community-based projects that will receive them, enabling travelers to make informed decisions and bring items which meet the needs of the people who will be using them.
<G-vec00011-002-s452><bring.mitnehmen><de> Die Listen der Angebote der Ziele auf unserer Website werden direkt von den den lokalen Gemeinden, basierend auf deren Projekten, angeboten, was den Reisenden erlaubt informierte Entscheidungen darüber zu treffen, was Sie mitnehmen, das für die Menschen dort nützlich sein kann.
<G-vec00011-002-s453><bring.mitnehmen><en> The trekkers must bring their own ski equipment (a pair of skis, skiing boots) and adequate clothing.
<G-vec00011-002-s453><bring.mitnehmen><de> Die Teilnehmer der Expeditionen müßen ihre eigene Skiausrüstung mitnehmen (Skis, Skistiefel) und den geeigneten Anzug.
<G-vec00011-002-s454><bring.mitnehmen><en> It's a good idea to check with your local customs officials to ensure that you are able to bring certain items back into your home country.
<G-vec00011-002-s454><bring.mitnehmen><de> Vergewissere Dich bei örtlichen Zollbeamten, ob Du bestimmte Gegenstände in Dein Heimatland mitnehmen darfst.
<G-vec00011-002-s455><bring.mitnehmen><en> However if you would like to come on our longer Tours (3 and 4), you will need to bring your own cooking equipment, plates and cutlery.
<G-vec00011-002-s455><bring.mitnehmen><de> Wenn Sie jedoch eine unserer längeren Touren (3 oder 4) gewählt haben, sollten Sie lhr eigenes Kochzeug, Teller und Besteck mitnehmen.
