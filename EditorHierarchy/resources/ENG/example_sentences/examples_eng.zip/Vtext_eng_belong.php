<G-vec00366-002-s057><belong.angehören><en> They insisted that I was a dangerous socialist. The whole business was so offensive, so clearly a discrimination against the Russian revolutionaries, in contrast to the treatment accorded other passengers not so unfortunate as to belong to a nation allied to England, that some of the Russians sent a violent protest to the British authorities.
<G-vec00366-002-s057><belong.angehören><de> Die ganze Untersuchung trug einen so entwürdigenden Charakter und stellte die russischen Revolutionäre so offensichtlich unter einen Ausnahmezustand im Vergleich zu den anderen Passagieren, die nicht das Unglück hatten, einer England verbündeten Nation anzugehören, daß einige der Verhörten an Ort und Stelle an die englische Regierung einen energischen Protest gegen das Benehmen der englischen Polizeiagenten absandten.
<G-vec00366-002-s058><belong.angehören><en> A: You must know that our crime is being Palestinian, to belong to Palestine.
<G-vec00366-002-s058><belong.angehören><de> A: Natürlich, unser Verbrechen besteht darin, Palästinenser zu sein und Palästina anzugehören.
<G-vec00366-002-s059><belong.angehören><en> And I’m happy to belong to a community that doesn’t want to be silent.
<G-vec00366-002-s059><belong.angehören><de> Und ich bin glücklich, einer Community anzugehören, die nicht schweigen will.
<G-vec00366-002-s060><belong.angehören><en> The 'Universal Declaration of Human Rights' (UDHR), valid in Andorra, clearly states: “No one may be compelled to belong to an association.“ But that's what the law demands, namely the compulsory establishment of associations.
<G-vec00366-002-s060><belong.angehören><de> Die in Andorra gültige 'Allgemeine Erklärung der Menschenrechte' (AEMR) legt eindeutig fest: „Niemand darf gezwungen werden, einer Vereinigung anzugehören.“ Aber genau das fordert das Gesetz, nämlich die Gründung von Zwangsassoziationen.
<G-vec00366-002-s061><belong.angehören><en> Varieties of coloured light bound up with matter appear in many places to communicate with each other, belong to a cycle or determine the orientation of the painting.
<G-vec00366-002-s061><belong.angehören><de> Verschieden farbiges Licht, gebunden an die Materie, scheint vielerorts miteinander zu kommunizieren, einem Kreislauf anzugehören oder eine Richtung im Bild zu bestimmen.
<G-vec00366-002-s062><belong.angehören><en> But you need not to lose; you can defend yourselves any time through your free will to belong to me forever; and any time you can call on me for help.
<G-vec00366-002-s062><belong.angehören><de> Aber ihr brauchet nicht zu unterliegen, ihr könnet euch wehren jederzeit durch euren freien Willen, Mir anzugehören auf ewig, und ihr könnet jederzeit Mich um Beistand anrufen.
<G-vec00366-002-s063><belong.angehören><en> 3 Every person has the right to join or to belong to a religious community, and to follow religious teachings.
<G-vec00366-002-s063><belong.angehören><de> 3 Jede Person hat das Recht, einer Religionsgemeinschaft beizutreten oder anzugehören und religiösem Unterricht zu folgen.
<G-vec00366-002-s064><belong.angehören><en> In the history of mankind, we are the first people lucky enough to belong to a generation that can realise this human dream in its simplest and purest form.
<G-vec00366-002-s064><belong.angehören><de> Doch gerade wir haben das Glück, der ersten Generation anzugehören, die sich diesen Menschheitstraum in seiner einfachsten und reinsten Form erfüllen kann.
<G-vec00366-002-s065><belong.angehören><en> The wish to overcome death may seem unrealistic or belong to the sphere of religion, rather than serious science.
<G-vec00366-002-s065><belong.angehören><de> Der Wunsch nach Überwindung des Todes mag unrealistisch erscheinen oder eher dem Bereich der Religion und des Glaubens anzugehören als der seriösen Wissenschaft.
<G-vec00366-002-s066><belong.angehören><en> The members of the Protestant Free Church refuse to belong to a “state church”, they are the defenders of a clear separation of church and state and deny also the financing of the church over the church tax.
<G-vec00366-002-s066><belong.angehören><de> Die Mitglieder der evangelischen Freikirche lehnen es ab, einer „Staatskirche“ anzugehören, sie sind die Verfechter einer klaren Trennung von Kirche und Staat und verneinen auch die Finanzierung der Kirche über die Kirchensteuer.
<G-vec00366-002-s067><belong.angehören><en> As it is not a crime in Sweden to belong to, or support, a terrorist organization, Austrian authorities decided to keep the 17-year-old in custody in Austria and charge her there.
<G-vec00366-002-s067><belong.angehören><de> Da es in Schweden kein Verbrechen ist einer Terrororganisation anzugehören oder sie zu unterstützen, entschieden die österreichischen Behörden die 17-jährige in Österreich in Haft zu behalten und sie anzuklagen.
<G-vec00366-002-s068><belong.angehören><en> You confirm your order to belong to this group of customers
<G-vec00366-002-s068><belong.angehören><de> Sie bestätigen mit Ihrer Bestellung, diesem Kundenkreis anzugehören.
<G-vec00366-002-s069><belong.angehören><en> “I am entirely yours, most Holy Virgin, that I may more perfectly belong to God.”
<G-vec00366-002-s069><belong.angehören><de> « Ich bin ganz dein, o heilige Jungfrau, um noch vollkommener Gott anzugehören ».
<G-vec00366-002-s070><belong.angehören><en> Through the eyes of Torsten, we get to experience all facets of what it truly means to belong to a skate crew.
<G-vec00366-002-s070><belong.angehören><de> Durch Torstens Blick erfahren wir in allen Facetten, was es bedeutet und wie es sich anfühlt, einer Skate Crew anzugehören.
<G-vec00366-002-s071><belong.angehören><en> It may well be the case that they are even anxious not to belong to such parties or even to discuss with the leaders of such parties the kind of things that they and their movements no longer find attractive.
<G-vec00366-002-s071><belong.angehören><de> Möglicherweise sind die politischen Aktivisten sogar darauf bedacht, solchen Parteien eben gerade nicht anzugehören, ja nicht einmal mit ihrer jeweiligen Führung über deren für sie und ihre Bewegung nicht mehr relevanten Ideen und Ziele zu sprechen.
<G-vec00366-002-s072><belong.angehören><en> Consequently, Hesse's "Glass Bead Game" again tells us about the revolt of an individual, finding his truth far from all truths and religions. 83 year old Hesse wrote: "For the majority of people it's very useful to belong to a church or a religion.
<G-vec00366-002-s072><belong.angehören><de> Hesses Glasperlenspiel handelt darum wiederum von der Revolte eines einzelnen, der seine eigene Wahrheit, fern aller Kollektive, auch der Konfessionen und Religionen, findet: „Für die Mehrheit der Menschen ist es sehr gut, einer Kirche und einem Glauben anzugehören.
<G-vec00366-002-s073><belong.angehören><en> Represented in the first-born is the people of the covenant, ransomed from slavery in order to belong to God.
<G-vec00366-002-s073><belong.angehören><de> Im Erstgeborenen war das Volk des Alten Bundes verkörpert, das aus der Sklaverei freigekauft worden war, um Gott anzugehören.
<G-vec00366-002-s100><belong.dazugehören><en> She calls her education the „darkness of serious music“ where she first tried to belong, then to break free with the help of lo-fi synth pop.
<G-vec00366-002-s100><belong.dazugehören><de> Ihre Ausbildung bezeichnet sie als "darkness of serious music", zu der sie zunächst dazugehören wollte, sie dann aber als Ketten empfand, die sie mit ihrem Lofi Synth Pop abzuwerfen vesuchte.
<G-vec00366-002-s101><belong.dazugehören><en> I used the website to learn more about the history of the EU and which countries belong to it.
<G-vec00366-002-s101><belong.dazugehören><de> Ich habe hier ziemlich viel über die Geschichte der EU gelernt - und welche Länder dazugehören.
<G-vec00366-002-s102><belong.dazugehören><en> In the end, about 40 students from different disciplines will belong to the team.
<G-vec00366-002-s102><belong.dazugehören><de> Etwa 40 Studierende unterschiedlicher Fachrichtungen werden letztlich dazugehören.
<G-vec00366-002-s103><belong.dazugehören><en> It is not just immensely painful to live in this reality, it also prevents us from creating the world we want to live in by being who we really are, giving what we have to give, asking for what we need, enjoying the gifts that we get and trusting that we belong,
<G-vec00366-002-s103><belong.dazugehören><de> Sie ist nicht nur extrem schmerzhaft, sie hält uns auch davon ab, die Welt zu kreieren, in der wir leben wollen - indem wir ganz wir selber sind, geben, was wir zu geben haben, um das bitten, was wir brauchen, die Geschenke genießen, die wir bekommen und vertrauen, dass wir dazugehören.
<G-vec00366-002-s104><belong.dazugehören><en> Maybe because I left Israel, maybe because after you leave borders, family and friends behind, you want to be belong to something.
<G-vec00366-002-s104><belong.dazugehören><de> Vielleicht, weil ich Israel verlassen habe, vielleicht deshalb, du zu etwas dazugehören willst, nachdem du Grenzen, Familie und FreundInnen hinter dir gelassen hast.
<G-vec00366-002-s105><belong.dazugehören><en> But there are constantly little everyday moments that make me doubt whether I'm really allowed to belong here.
<G-vec00366-002-s105><belong.dazugehören><de> Es sind aber immer wieder die kleinen Momente im Alltag, die mich daran zweifeln lassen, dass ich wirklich dazugehören darf.
<G-vec00366-002-s106><belong.dazugehören><en> It is clear that masculine jewellery accessories today simply belong to the styling of many men.
<G-vec00366-002-s106><belong.dazugehören><de> Fest steht, dass maskuline Schmuck-Accessoires heute zum Styling vieler Männer einfach dazugehören.
<G-vec00366-002-s107><belong.dazugehören><en> Homophobia and Transphobia are redefined as the problems of youth of colour who apparently don’t speak proper German, whose Germanness is always questioned, and who simply don’t belong.
<G-vec00366-002-s107><belong.dazugehören><de> Homophobie und Transphobie werden hier als Probleme von Jugendlichen of Colour umdefiniert, die anscheinend nicht richtig Deutsch können, deren Deutschsein immer hinterfragt bleibt, und die schlicht nicht dazugehören.
<G-vec00366-002-s108><belong.dazugehören><en> And want to belong.
<G-vec00366-002-s108><belong.dazugehören><de> Und dazugehören wollen.
<G-vec00366-002-s109><belong.dazugehören><en> Now I wanted to risk it again, wanted to belong to somewhere, to contribute time, energy, skills for God’s ministry.
<G-vec00366-002-s109><belong.dazugehören><de> Nun wollte ich es noch einmal wagen, wollte zu etwas dazugehören, Zeit, Energie, Können für Gottes Dienst einbringen.
<G-vec00366-002-s110><belong.dazugehören><en> Any ever so small publication always includes, aside from the prospect of fulfilment of certain wishes and longings, a certain amount of defamation of other offers, what is more, the exclusiveness of the offer shows the difference between those few fortunate enough to belong, and the many pitiable package tourists.
<G-vec00366-002-s110><belong.dazugehören><de> Jede noch so kleine Veröffentlichung beinhaltet neben der Aussicht auf Erfüllung bestimmter Wünsche und Sehnsüchte immer auch eine gewisse Diffamierung anderer Angebote, darüber hinaus verweist die Exklusivität des Angebots auf das Gefälle zwischen den wenigen glücklichen, die dazugehören und den vielen bedauernswerten Pauschaltouristen.
<G-vec00366-002-s111><belong.dazugehören><en> Because I am deeply convinced that I am a child of God, I also have a lot of motivation to do my work well and to tackle even unloved tasks, which belong everywhere.
<G-vec00366-002-s111><belong.dazugehören><de> Weil ich zutiefst davon überzeugt bin, ein Kind Gottes zu sein, habe ich auch viel Motivation, meine Arbeit gut zu machen und selbst ungeliebte Aufgaben, die ja überall dazugehören, in Angriff zu nehmen.
<G-vec00366-002-s112><belong.dazugehören><en> Belong: Having a sense of belonging is probably one of the most gratifying human experience.
<G-vec00366-002-s112><belong.dazugehören><de> Dazugehören: Das Gefühl von Zugehörigkeit ist wahrscheinlich eine der befriedigendsten Erfahrungen des Menschen.
<G-vec00366-002-s244><belong.gehören><en> Ozawa and Aida (picture) both belong to the Group 1965, whose name refers to the members' year of birth (more here and here).
<G-vec00366-002-s244><belong.gehören><de> Ozawa und Aida (Bild) gehörten beide der Gruppe 1965 an, deren Name auf das Geburtsjahr der Mitglieder verwies (mehr hier und hier).
<G-vec00366-002-s245><belong.gehören><en> It's very likely that these domains used to belong to shoe brands and/or sellers.
<G-vec00366-002-s245><belong.gehören><de> Es ist sehr wahrscheinlich, dass diese Domains früher zu Schuhmarken und/oder Verkäufern gehörten.
<G-vec00366-002-s246><belong.gehören><en> They actually belong to the first ever artists to play this kinda music.
<G-vec00366-002-s246><belong.gehören><de> Sie gehörten zu den ersten Künstlern, die diesen Trend ins Leben gerufen haben Anfang der Neunziger Jahre.
<G-vec00366-002-s247><belong.gehören><en> To frame it drastically, you could say that behind all this is the fear of dying, because this is exactly what happened in former times, when people did not belong to a tribe and were not surrounded by tribe brothers and sisters.
<G-vec00366-002-s247><belong.gehören><de> Drastisch ausgedrückt könnte man sagen, dahinter steckt die Angst zu sterben, denn das ist genau das, was früher passierte, wenn wir Menschen nicht zu einem Stamm gehörten und von Stammesbrüdern- und Schwestern umgeben waren.
<G-vec00366-002-s248><belong.gehören><en> One night we had an argument and Karl said that once the party takes over the government, if we did not belong to the Nazi party, we would starve.
<G-vec00366-002-s248><belong.gehören><de> Eine Nacht hatten wir ein Argument, und Karl sagte, dass sobald die Partei die Regierung übernimmt, wenn wir nicht zur Nazipartei gehörten, würden wir hungern.
<G-vec00366-002-s249><belong.gehören><en> But also the shady tricks and the paradoxes of history, including the history of the Church belong to the facts.
<G-vec00366-002-s249><belong.gehören><de> Aber zu den Fakten gehörten ebenfalls die Winkelzüge und Paradoxien der Geschichte, auch der Kirchengeschichte.
<G-vec00366-002-s250><belong.gehören><en> Therefore, in the minds of Amnesty International, forensic experts coming to different conclusions than eyewitnesses do indeed belong in jail.
<G-vec00366-002-s250><belong.gehören><de> Daher gehörten nach Ansicht von Amnesty International Gerichtsgutachter, die zu anderen Schlussfolgerungen kommen als Augenzeugen, tatsächlich ins Gefängnis.
<G-vec00366-002-s251><belong.gehören><en> Most of those ministers did not belong to the most fortunate classes that would resort to painters and engravers, and photography was not available yet.
<G-vec00366-002-s251><belong.gehören><de> Die meisten von ihnen gehörten nicht zu den obersten Schichten der Gesellschaft, in denen man gerne und leicht auf Maler und Graveure Zugriff hatte, und die erschwinglichere Photographie stand noch nicht zur Verfügung.
<G-vec00366-002-s252><belong.gehören><en> Stealing, deception, and racketeering belong to the past.
<G-vec00366-002-s252><belong.gehören><de> Diebstahl, Betrug und Gaunereien gehörten der Vergangenheit an.
<G-vec00366-002-s253><belong.gehören><en> Therefore, questions about the way economic resources were to be allocated did not belong to the public realm[60], except to the extent that they referred to the setting of social controls to regulate the limited market or to the financing of "public" spending.
<G-vec00366-002-s253><belong.gehören><de> Daher gehörten (wie Aristoteles explizit bemerkte[119]) Fragen nach der wünschenswerten Art der Ressourcenallokation nicht in den öffentlichen Bereich, sofern es dabei nicht um die Etablierung sozialer Kontrollmechanismen zur Regulierung des begrenzten Marktes oder die Finanzierung „öffentlicher“ Ausgaben ging.
<G-vec00366-002-s254><belong.gehören><en> People, from whom it becomes known only after their accession, that they either already belong to the excluded group of people or have been added afterwards, subsequently must be removed after written consultation by removal from the membership.
<G-vec00366-002-s254><belong.gehören><de> Personen, von denen erst nach erfolgtem Beitritt bekannt wird, dass sie entweder bereits zum Zeitpunkt ihres Beitritts zu dem ausgeschlossenen Personenkreis gehörten oder danach hinzugekommen sind, sind nach schriftlicher Anhörung durch Streichung aus der Mitgliederliste zu entfernen.
<G-vec00366-002-s255><belong.gehören><en> But it's not just Western pro-Palestinians who have double standards but also many Muslims who argue they have the right to emigrate where ever they wish but who argue vehemently that the Jews don't belong in Palestine.
<G-vec00366-002-s255><belong.gehören><de> Doch es sind nicht gerade nur westliche Pro-Palästinenser, die eine Doppelmoral haben, sondern auch viele Muslime, die argumentieren, sie hätten das Recht, wohin immer sie wollten einzuwandern, die jedoch vehement argumentieren, dass die Juden nicht nach Palästina gehörten.
<G-vec00366-002-s256><belong.handeln><en> LA Confidential cannabis seeds by DNA Genetics belong to a feminised Indica-dominant cannabis strain derived from the cross between OG LA Affie and Afghani #1.
<G-vec00366-002-s256><belong.handeln><de> Bei den LA Confidential Hanfsamen von DNA Genetics handelt es sich um eine feminisierte Cannabissorte mit Indica-Dominanz, die aus der Kreuzung zweier 100%iger Indicas hervorgegangen ist, einer OG LA Affie und einer Afghani.
<G-vec00366-002-s257><belong.handeln><en> €27.00 €27.00 Amnesia Kush · Dinafem Seeds Amnesia Kush cannabis seeds by Dinafem Seeds belong to a Sativa-dominant feminized...
<G-vec00366-002-s257><belong.handeln><de> €27.00 €27.00 Amnesia Kush · Dinafem Seeds Bei den Hanfsamen der Amnesia Kush von Dinafem Seeds handelt es sich um eine...
<G-vec00366-002-s258><belong.handeln><en> Durban cannabis seeds by Sensi Seeds belong to a feminised Sativa-dominant cannabis strain derived from a selected South African genetics.
<G-vec00366-002-s258><belong.handeln><de> Bei den Durban Hanfsamen von Sensi Seeds handelt es sich um eine feminisierte Cannabissorte mit Sativa-Dominanz, deren ausgesuchte Genetik direkt aus Südafrika stammt.
<G-vec00366-002-s259><belong.handeln><en> Amnesia XXL Autoflowering Feminised Seeds Amnesia XXL Auto cannabis seeds by Dinafem Seeds belong to a feminized autoflowering Sativa-dominant cannabis strain that comes from the cross between a Original Amnesia and an Original Amnesia Autoflowering.
<G-vec00366-002-s259><belong.handeln><de> Bei den Marihuana-Samen Amnesia XXL Auto von Dinafem Seeds handelt es sich um eine selbstblühende, feminisierte Marihuana-Varietät mit Sativa-Dominanz, die aus der Verbindung einer Original Amnesia und einer Original Amnesia Autoflowering entstanden ist.
<G-vec00366-002-s260><belong.handeln><en> In addition to human control, an automatic system analyzes all the photos of the certified profiles to make sure they do not belong to another girl on the internet.
<G-vec00366-002-s260><belong.handeln><de> Zusätzlich zur Kontrolle durch unsere Mitarbeiter, kontrolliert ein automatisches System alle Bilder von Zertifizierten Profilen, um sicher zu sein, dass es sich nicht um Bilder anderer Mädchen aus dem Internet handelt.
<G-vec00366-002-s261><belong.handeln><en> Liberty Haze cannabis seeds by Barney's Farm belong to a feminized cannabis strain derived from the cross between a G13 male and a Chem Dawg 91.
<G-vec00366-002-s261><belong.handeln><de> Bei den Liberty Haze Hanfsamen von Barney's Farm handelt es sich um eine feminisierte Cannabissorte, die aus der Kreuzung einer männlichen G13 und der superschnellen Chem Dawg 91 hervorgegangen ist.
<G-vec00366-002-s262><belong.handeln><en> If the user would like to use the software on several portable storage media at the same time, this is covered by an individual licence as long as the storage media do not belong to third parties or another user.
<G-vec00366-002-s262><belong.handeln><de> Möchte der Anwender die Software auf mehreren portablen Speichermedien gleichzeitig verwenden, so ist dies durch eine Einzellizenz gedeckt, solange es sich nicht um Speichermedien Dritter oder das Speichermedium eines anderen Anwenders (User) handelt.
<G-vec00366-002-s263><belong.handeln><en> Select Option+ Add to Wishlist+ seeds by Dinafem Seeds belong to a feminized autoflowering...
<G-vec00366-002-s263><belong.handeln><de> Hersteller: Dinafem Seeds Auswählen Option+ Add to Wishlist+ Auf die Dinafem Seeds handelt es sich um eine feminiserte...
<G-vec00366-002-s265><belong.handeln><en> Delivery guarantee Tracking number Crystal Candy cannabis seeds by Sweet Seeds belong to a feminized, Indica-dominant marijuana plant with unknown origins.
<G-vec00366-002-s265><belong.handeln><de> Bei den Crystal Candy Hanfsamen von Sweet Seeds handelt es sich um eine feminisierte Cannabissorte mit Indica-Dominanz, deren genetische Ursprünge nicht bekannt gegeben wurden.
<G-vec00366-002-s266><belong.handeln><en> Reduced price! Cheese Autoflowering CBD cannabis seeds by Dinafem Seeds belong to a feminized CBD-rich cannabis strain derived from the cross between a Cheese XXL Autoflowering and an Auto CBD.
<G-vec00366-002-s266><belong.handeln><de> Bei den Marihuana-Samen Cheese Autoflowering CBD von Dinafem Seeds handelt es sich um eine selbstblühende, feminisierte Cannabis-Sorte mit einem hohen CBD-Gehalt, die aus der Kreuzung einer Cheese XXL Autoflowering und einer Auto CBD hervorgegangen ist.
<G-vec00366-002-s267><belong.handeln><en> Big Bud cannabis seeds by Sensi Seeds belong to a regular Indica-dominant cannabis strain derived from the cross between a Skunk #1 and a (Northern Lights x Big Bud).
<G-vec00366-002-s267><belong.handeln><de> Bei den Big Bud Hanfsamen von Sensi Seeds handelt es sich um eine reguläre Cannabissorte mit Indica-Dominanz, die aus der Kreuzung einer Skunk #1 mit einer (Northern Lights x Big Bud) hervorgegangen ist.
<G-vec00366-002-s268><belong.handeln><en> Passion #1 cannabis seeds by Dutch Passion belong to a regular cannabis strain regarded as one of the best strains available now for growing outdoors.
<G-vec00366-002-s268><belong.handeln><de> Bei den Passion #1 Hanfsamen von Dutch Passion handelt es sich um eine reguläre Cannabissorte, die in den 70er Jahren in Kalifornien entwickelt wurden.
<G-vec00366-002-s269><belong.handeln><en> Pineapple Skunk cannabis seeds by Humboldt Seed Organization belong to a feminized cannabis strain derived from an elite skunk phenotype.
<G-vec00366-002-s269><belong.handeln><de> Bei den Pineapple Skunk Hanfsamen von Humboldt Seed Organization handelt es sich um eine feminisierte Cannabissorte, die auf einen Skunk-Elite-Phänotyp zurückgeht.
<G-vec00366-002-s270><belong.handeln><en> Early Amnesia CBD cannabis seeds by Dinafem Seeds belong to a feminized CBD-rich cannabis strain derived from the cross between an Original Amnesia and an Auto CBD.
<G-vec00366-002-s270><belong.handeln><de> Bei den Marihuana-Samen Early Amnesia CBD von Dinafem Seeds handelt es sich um eine feminisierte Cannabis-Sorte mit einem hohen CBD-Gehalt, die aus der Kreuzung einer Original Amnesia und einer Auto CBD hervorgegangen ist.
<G-vec00366-002-s271><belong.handeln><en> Blue Dream Auto cannabis seeds by Humboldt Seeds Organization belong to a feminized autoflowering Sativa/Indica/Ruderalis cannabis strain derived from the cross between a Blue Dream and a Ruderalis.
<G-vec00366-002-s271><belong.handeln><de> Bei den Blue Dream Auto Hanfsamen von Humboldt Seed Organization handelt es sich um eine feminisierte Autoflowering-Marihuanasorte (Sativa/Indica/Ruderalis), die aus der Verbindung einer Blue Dream und einer Ruderalis hervorgegangen ist.
<G-vec00366-002-s272><belong.handeln><en> Hollands Hope cannabis seeds by Dutch Passion belong to a feminised cannabis strain that originates from the cross of a Viking and a Skunk #1.
<G-vec00366-002-s272><belong.handeln><de> Bei den Hollands Hope Hanfsamen von Dutch Passion handelt es sich um eine feminisierte Cannabissorte, die auf die Kreuzung einer Viking mit einer Skunk #1 zurückgeht.
<G-vec00366-002-s273><belong.handeln><en> Pineapple Express cannabis seeds by Barney's Farm belong to a feminized autoflowering Indica-dominant marijuana strain that derives from the cross of a Skunk #1, a Cheese, a Pineapple Chunk and a Ruderalis.
<G-vec00366-002-s273><belong.handeln><de> Bei den Pineapple Express Hanfsamen von Barney's Farm handelt es sich um eine feminisierte Autoflowering-Cannabissorte mit Indica-Dominanz, die aus der Kreuzung einer Ruderalis, einer Skunk #1, einer Cheese und einer Pineapple Chunk hervorgegangen ist.
<G-vec00366-002-s274><belong.handeln><en> The remaining artificial intelligence stocks belong to companies that provide the hardware, components, intellectual property or services that make up an A.I. platform.
<G-vec00366-002-s274><belong.handeln><de> Bei den verbleibenden künstliche Intelligenz Aktien handelt es sich um Unternehmen, die die Hardware, Komponenten, geistiges Eigentum oder Dienstleistungen bereitstellen, die eine K.I.-Plattform ausmachen.
<G-vec00366-002-s294><belong.hingehören><en> An entire industry is expanding into an area where it doesn’t belong.
<G-vec00366-002-s294><belong.hingehören><de> Eine ganze Industrie breitet sich da aus, wo sie nicht hingehört.
<G-vec00366-002-s295><belong.hingehören><en> There is no doubt that vitamin K2 is highly effective at directing calcium into your bones, where it is needed, and away from your arteries, where it does not belong.
<G-vec00366-002-s295><belong.hingehören><de> Es besteht kein Zweifel, dass Vitamin K2 hochwirksam Kalzium in die Knochen leitet und weg von den Arterien, wo es nicht hingehört, führt.
<G-vec00366-002-s296><belong.hingehören><en> So you ask: “What is that?” It’s the simple cleaning of the body of everything that does not belong in there.
<G-vec00366-002-s296><belong.hingehören><de> Ich frage – „Was ist das?“ – nun, einfach eine Säuberung des Körpers von allem, was da nicht hingehört.
<G-vec00366-002-s297><belong.hingehören><en> Smears on the tail in the ass and in the throat give security to find everything that does not belong there.
<G-vec00366-002-s297><belong.hingehören><de> Abstriche am Schwanz im Arsch und im Rachen geben Sicherheit, alles zu finden, was nicht dort hingehört.
<G-vec00366-002-s298><belong.hingehören><en> Looming danger lurks as well in a sick, alien culture that seeps into and pollutes all families, and emanates from an omnipotent, trigger-happy State itching to stick its snout where it does not belong and jail spouses and seize children.
<G-vec00366-002-s298><belong.hingehören><de> Drohende Gefahr lauert ebenso auch in der kranken und fremden Kultur, die immer mehr einsickert und alle Familien betrifft: Sie geht von einem allmächtigen und schießwütigen Staat aus, der darauf aus ist, seine Nase überall dorthin zu stecken, wo sie nicht hingehört, Ehegatten inhaftiert und Eltern ihre Kinder nimmt.
<G-vec00366-002-s299><belong.hingehören><en> It explains by means of a very innocent example that I have used the wrong gender — i.e. that I have put " he," the word denoting the sex or the sexual, where it does not belong.
<G-vec00366-002-s299><belong.hingehören><de> Sie erläutert an einem möglichst unschuldigen Beispiel, daß ich das Geschlechtswort am unrechten Platze gebrauche, also das Geschlechtliche (he) dort anbringe, wo es nicht hingehört.
<G-vec00366-002-s300><belong.hingehören><en> Every G Adventures tour puts good back into the world by helping you keep your travel dollars where they belong: with the local businesses that earn them.
<G-vec00366-002-s300><belong.hingehören><de> Jede G Adventures Reise macht die Welt ein Stück besser, da das Geld, das du unterwegs ausgibst, dort bleibt, wo es hingehört: Bei den lokalen Unternehmen vor Ort.
<G-vec00366-002-s301><belong.hingehören><en> A place to belong.
<G-vec00366-002-s301><belong.hingehören><de> Einen Ort, wo man hingehört.
<G-vec00366-002-s302><belong.hingehören><en> Afterwards it is difficult to remove if it gets to a place where it does not belong.
<G-vec00366-002-s302><belong.hingehören><de> Anschließend lässt es sich nur schlecht entfernen, falls es einmal an eine Stelle gelangt, wo es nicht hingehört.
<G-vec00366-002-s303><belong.hingehören><en> To impose 'I' where 'I' does not belong is ahankar (ego).
<G-vec00366-002-s303><belong.hingehören><de> Das 'Ich' einzuführen, wo 'Ich' nicht hingehört, ist Ego (Ahamkar).
<G-vec00366-002-s304><belong.hingehören><en> The climbing community has learned nothing insofar as they still climb up to altitudes where a human being doesn’t really belong.
<G-vec00366-002-s304><belong.hingehören><de> Die Bergsteigerwelt hat insofern nichts gelernt, dass sie immer noch dort hinaufsteigt, wo der Mensch eigentlich nicht hingehört.
<G-vec00366-002-s305><belong.liegen><en> rights belong exclusively to the author of the website.
<G-vec00366-002-s305><belong.liegen><de> Alle Rechte liegen ausschließlich bei dem Autor der Webseite.
<G-vec00366-002-s306><belong.liegen><en> The Rights to the game belong to XS Software JSCo.
<G-vec00366-002-s306><belong.liegen><de> Alle Rechte des Spiels liegen bei XS Software Ltd.
<G-vec00366-002-s307><belong.liegen><en> The rights to all mentioned and employed brands and trademarks belong exclusively to their owners.
<G-vec00366-002-s307><belong.liegen><de> Die Rechte aller erwähnten und benutzten Marken- und Warenzeichen liegen ausschließlich bei deren Besitzern.
<G-vec00366-002-s308><belong.liegen><en> Please note that the rights to these product trademarks belong to the manufacturer.
<G-vec00366-002-s308><belong.liegen><de> Bitte beachten Sie, dass die Rechte bei den Herstellern der jeweiligen Produkte liegen.
<G-vec00366-002-s309><belong.liegen><en> The copyrights belong to uvex group and remain undiminished if the pictures are incorporated into an archive, either electronically or manually.
<G-vec00366-002-s309><belong.liegen><de> Die Urheberrechte liegen bei der uvex Gruppe und bleiben auch in vollem Umfang bestehen, wenn Bilder elektronisch / händisch in ein Archiv übernommen werden.
<G-vec00366-002-s310><belong.liegen><en> Copyrights: All rights to images and texts belong to Kai Treude.
<G-vec00366-002-s310><belong.liegen><de> Urheberrechte: Alle Rechte auf Bilder und Texte liegen bei Kai Treude.
<G-vec00366-002-s311><belong.liegen><en> All rights belong exclusively to the Agency.
<G-vec00366-002-s311><belong.liegen><de> Sämtliche Rechte liegen ausschließlich bei der Agentur.
<G-vec00366-002-s312><belong.liegen><en> There exists a set of four points, no three of which belong to the same line.
<G-vec00366-002-s312><belong.liegen><de> Ein wichtiger Begriff in diesem Zusammenhang ist das Doppelverhältnis von vier Punkten, die auf einer Geraden liegen.
<G-vec00366-002-s313><belong.liegen><en> All music rights belong to the owner of this.
<G-vec00366-002-s313><belong.liegen><de> Alle Musikrechte liegen beim Besitzer dieser.
<G-vec00366-002-s314><belong.liegen><en> All copyrights for this website belong to BARTH GMBH. Liability
<G-vec00366-002-s314><belong.liegen><de> Die Urheberrechte dieser Website liegen vollständig bei BARTH GMBH.
<G-vec00366-002-s315><belong.liegen><en> Trained at Munich's Academy of Music, his musical beginnings belong to a late Romantic category of Brahmsian provenance.
<G-vec00366-002-s315><belong.liegen><de> Seine musikalischen Anfänge liegen freilich im Bereich spätromantischen Komponierens Brahms’scher Provenienz, wie sie ihm in München an der Akademie der Tonkunst vermittelt wurden.
<G-vec00366-002-s316><belong.liegen><en> All rights of the contents, offers, and images belong to the owners.
<G-vec00366-002-s316><belong.liegen><de> Alle Rechte dieser Seite bezüglich des Inhalts, der Angebote und der Bilder liegen bei den Urhebern.
<G-vec00366-002-s317><belong.liegen><en> Quelle: elegantvienna.com) Copyright for texts, graphics, design, photographs and source code published in elegantvienna.com belong to ElegantVienna.
<G-vec00366-002-s317><belong.liegen><de> Das Urheberrecht und die Nutzungsrechte für Texte, Grafiken, Design und Quellcode liegen bei ElegantVienna, sowie das Nutzungsrecht für die Bilder.
<G-vec00366-002-s318><belong.liegen><en> Moreover, those who come for the first time will be surprised by well-protected natural areas, some of which are far away from the towns while the others belong to them.
<G-vec00366-002-s318><belong.liegen><de> Einige befinden sich weit weg von den Küstenstädten, andere liegen mittendrin, und markieren sogenannte urbane Schnittstellen.
<G-vec00366-002-s319><belong.liegen><en> Most already belong to the constellation of Sagittarius.
<G-vec00366-002-s319><belong.liegen><de> Die meisten liegen im Feld des Sternbildes Sagittarius.
<G-vec00366-002-s320><belong.liegen><en> The German expellees remember places that have long since ceased to be German, in just the same way that Polish expellees refer to places that today belong to Ukraine or Lithuania.
<G-vec00366-002-s320><belong.liegen><de> Die deutschen Vertriebenen erinnern sich heute an Orte, die längst nicht mehr deutsch sind, genauso wie sich die polnischen Vertriebenen auf Orte beziehen, die heute in der Ukraine und Litauen liegen.
<G-vec00366-002-s322><belong.liegen><en> The content of the website is published for World-Wide-Web-usage only. Copyright and legal right of use for texts, graphics, design, and source code belong to the Free University of Bozen-Bolzano, so does the legal right for the photos.
<G-vec00366-002-s322><belong.liegen><de> Die Inhalte der Website sind im World-Wide-Web für den Online-Zugriff veröffentlicht, das Urheberrecht und die Nutzungsrechte (Copyright) für Texte, Graphiken, Design, Fotos und Quellcode liegen bei der Freien Universität Bozen, außer anders angegeben.
<G-vec00366-002-s323><belong.liegen><en> The rights belong to the Swiss Confederation, as represented by the Federal Office for Buildings and Logistics (FOBL).
<G-vec00366-002-s323><belong.liegen><de> Die Rechte liegen bei der Schweizerischen Eidgenossenschaft, vertreten durch das Bundesamt für Bauten und Logistik BBL.
<G-vec00366-002-s362><belong.stammen><en> According to the coroner the bones have been buried only for a couple of decades and belong to a small woman.
<G-vec00366-002-s362><belong.stammen><de> Laut dem Gerichtsmediziner wurden die Knochen erst vor wenigen Jahrzehnten vergraben und stammen von einer kleinen Frau.
<G-vec00366-002-s363><belong.stammen><en> All of the photographs on display belong to the collection of CAMERA WORK AG. They not only serve as a means of historically documenting Jackie's life, but are also impressive due to their iconography, composition, and aesthetics.
<G-vec00366-002-s363><belong.stammen><de> Alle gezeigten Photographien stammen aus dem Eigenbestand der CAMERA WORK AG und dienen nicht nur als Mittel der historischen Nachzeichnung des Lebens von Jackie, sondern beeindrucken zudem in ihrer Bildsprache, Komposition und Ästhetik.
<G-vec00366-002-s364><belong.stammen><en> The collection contains more than 3000 exclusive wood species and is solely composed of varieties which belong to our climate zone.
<G-vec00366-002-s364><belong.stammen><de> Auf der gesamten Anlage stehen weit über 3000 exklusive Gehölze, die ausschließlich aus Arten unserer Klimazone stammen.
<G-vec00366-002-s365><belong.stammen><en> If it assumes the role of teacher, it hampers the propagation of truth and tends to prepare the minds and the hearts of the young to become either ruthless tyrants or docile slaves, according to the class to which they belong.
<G-vec00366-002-s365><belong.stammen><de> Wenn sie Schulen gründet und erhält, so tut sie dies auch nur darum, um die Verbreitung der unabhängig gelehrten Wahrheit zu verhindern und den Geist der jungen Leute so zu erziehen, daß sie zu müßigen Tyrannen und gehorsamen Sklaven heranwachsen — je nach der Klasse, aus der sie stammen.
<G-vec00366-002-s366><belong.stammen><en> In accordance with accepted international standards, 3% of the parquet strips in a batch may belong to other grading classes - to accommodate unavoidable differences in the classes.
<G-vec00366-002-s366><belong.stammen><de> Laut international anerkannter Norm dürfen 3% der Parkettstäbe in einem Los aus anderen Sortierungsklassen stammen, um unvermeidbare Unterschiede in den Sortierklassen zu erlauben.
<G-vec00366-002-s367><belong.stammen><en> The paintings, sculptures, and ceramics belong to a private collection. They have not been shown before in this combination.
<G-vec00366-002-s367><belong.stammen><de> Sämtliche Bilder, Skulpturen und Keramiken stammen aus einer Privatsammlung und sind, in dieser Kombination, zum ersten Mal zu sehen.
<G-vec00366-002-s368><belong.stammen><en> Thetavern table and the other furniture shown on the pictures belong to our range of products.
<G-vec00366-002-s368><belong.stammen><de> Der Wirtshaustisch und die Bank, sowie die anderen Möbel auf den Fotos stammen aus unserem Sortiment.
<G-vec00366-002-s369><belong.stammen><en> The tapestries belong to an age of splendour in Flemish tapestry and were made in the best workshops in Brussels.
<G-vec00366-002-s369><belong.stammen><de> Die Wandteppiche stammen aus der Glanzzeit der flämischen Bildwirkerei und wurden in den besten Werkstätten Brüssels hergestellt.
<G-vec00366-002-s370><belong.stammen><en> With the richly decorated carriages and the coachmen with their high hats, they seem to belong to another period of time.
<G-vec00366-002-s370><belong.stammen><de> Mit den geschmückten Kutschen und den Kutschern mit den hohen Zylindern, scheinen sie aus einer anderen Zeit zu stammen.
<G-vec00366-002-s371><belong.stammen><en> But not all Swiss billionaires belong to the leisure class: around a third of Switzerland’s richest hail from average middle-class backgrounds and built their fortunes from scratch.
<G-vec00366-002-s371><belong.stammen><de> Allerdings stammen auch rund ein Drittel der reichsten Schweizer aus eher durchschnittlichen Mittelklasse-Verhältnissen und haben sich ihren Reichtum von Grund auf selbst erarbeitet.
<G-vec00366-002-s372><belong.stammen><en> This contextualization of the diverse minimalist tendencies is one of the most characteristic aspects of the DaimlerChrysler Corporation’s collection, to which belong all of the works exhibited here.
<G-vec00366-002-s372><belong.stammen><de> Diese Kontextualisierung der verschiedenen minimalistischen Tendenzen ist einer der herausragenden Aspekte der Sammlung DaimlerChrysler, aus der alle Werke dieser Ausstellung stammen.
<G-vec00366-002-s373><belong.stammen><en> More and more visitors belong to the group of people that are stimulated by emotions created by nature and art.
<G-vec00366-002-s373><belong.stammen><de> Die Besucher stammen aus der immer größer werdenden Schicht der Ausflügler und der Kategorie der Personen, die aus der Natur und der Kunst intensive Emotionen, Botschaften und Anreize gewinnen.
<G-vec00366-002-s374><belong.stammen><en> The works on display belong to Carlos Gross’s private collection, one of the largest set of lithographs by Giacometti worldwide.
<G-vec00366-002-s374><belong.stammen><de> Die Werke stammen aus der Privatsammlung von Carlos Gross, der eine der größten Sammlungen von Lithografien Giacomettis weltweit besitzt.
<G-vec00366-002-s375><belong.stammen><en> However, the most important remains, due to their good condition, found in the area belong to the Roman civilisation.
<G-vec00366-002-s375><belong.stammen><de> Die wichtigsten Fundstücke, aufgrund ihres Erhaltungsgrades, stammen jedoch aus der römischen Zeit.
<G-vec00366-002-s442><belong.zählen><en> All other African countries belong to the Sub-Saharan region.
<G-vec00366-002-s442><belong.zählen><de> Alle anderen afrikanischen Staaten zählen zur Region Subsahara.
<G-vec00366-002-s443><belong.zählen><en> and CSFV belong to genus Pestivirus, a group of pathogens comprising solely animal viruses.
<G-vec00366-002-s443><belong.zählen><de> BVDV und CSFV zählen zum Genus Pestivirus, das ausschließlich tierpathogene Erreger beinhaltet.
<G-vec00366-002-s444><belong.zählen><en> Also cultural institutions, IHKs, international chambers of commerce and associations belong to our members.
<G-vec00366-002-s444><belong.zählen><de> Auch kulturelle Einrichtungen, IHKs, internationale Handelskammern und Verbände zählen zu unseren Mitgliedern.
<G-vec00366-002-s445><belong.zählen><en> I look forward to assist you in all aspects of travel arrangements for hunting and fly fishing. I would highly appreciate if I you belong soon to my elite clients circle. Partner
<G-vec00366-002-s445><belong.zählen><de> Ich freue mich darauf Sie vielleicht schon bald zum Kreis meines elitären Kundenkreises zählen zu dürfen und Ihnen in allen Belangen der Reiseorganisation rund um Jagd und Fliegenfischen professionell mit Rat und Tat zur Seite stehen.
<G-vec00366-002-s446><belong.zählen><en> Fineness, length, cross-section, stiffness, and, referring to the synthetic, the fiber finish belong to the most important parameters for spinning effects of the fiber / water suspension.
<G-vec00366-002-s446><belong.zählen><de> Zu den bedeutenden Einflussgrößen für das Auftreten von Verspinnungen in der Faser/ Wassersuspension zählen die Faserparameter Feinheit, Länge, Querschnitt, Steifheit und bei Synthesefasern das Faserfinish.
<G-vec00366-002-s447><belong.zählen><en> Every car, city, home, and woman smells differently, and these sensations often belong to our most precious memories.
<G-vec00366-002-s447><belong.zählen><de> Jede Blume, jeder Wald, jedes Zuhause als auch jede Frau duften anders und diese Sinneseindrücke zählen oft zu unseren tiefsten Erinnerungen.
<G-vec00366-002-s448><belong.zählen><en> Both of them belong to the top drivers of the KF-class and are getting in on the forefront of the European Championship.
<G-vec00366-002-s448><belong.zählen><de> Beide zählen zu den Topfahrern in der KF-Kategorie und mischen in der Europameisterschaft ganz vorne mit.
<G-vec00366-002-s449><belong.zählen><en> The sea buckthorn berries belong to the most vitamin-packed fruits of our flora. They have in addition many valuable substances for nutrition purposes.
<G-vec00366-002-s449><belong.zählen><de> Die Sanddornbeeren zählen zu den vitaminreichsten Früchten unserer Flora und weisen eine Vielzahl weiterer ernährungsphysiologisch wertvoller Substanzen auf.
<G-vec00366-002-s450><belong.zählen><en> Packing lists belong to the sales documents.
<G-vec00366-002-s450><belong.zählen><de> Packscheine zählen zu den Vertriebsbelegen.
<G-vec00366-002-s451><belong.zählen><en> The awarded companies belong to the pacemakers in their industries.
<G-vec00366-002-s451><belong.zählen><de> Die ausgezeichneten Unternehmen zählen in ihren Branchen zu den Schrittmachern.
<G-vec00366-002-s452><belong.zählen><en> Also with their album "5: The Gray Chapter" they proved again they belong to the biggest in the Metal scene.
<G-vec00366-002-s452><belong.zählen><de> Auch mit ihrem Album „5: The Gray Chapter“ haben sie mal wieder bewiesen, dass sie zu den bedeutendsten Größen in der Metalszene zählen.
<G-vec00366-002-s453><belong.zählen><en> kN centrifugal force belong to the class of versatile all around plates, which are ideal for compacting paving stones, horticulture and landscaping, and the maintenance of roads, paths and parking lots.
<G-vec00366-002-s453><belong.zählen><de> Die DPU-Modelle mit einer Zentrifugalkraft von 30 kN zählen zu den vielseitigen Allroundern für Pflasterarbeiten, den Garten- und Landschaftsbau sowie für Instandhaltungsarbeiten an Straßen, Wegen und Parkplätzen.
<G-vec00366-002-s454><belong.zählen><en> Posting periods belong to the master files.
<G-vec00366-002-s454><belong.zählen><de> Buchungsperioden zählen zu den Stammdaten.
<G-vec00366-002-s455><belong.zählen><en> Nosocomial infections nowadays belong to the most common infections during hospitalization, because they are developed with a problem germ additionally to already existing illnesses. Moreover, problem germs tend to occur after discharge from a hospital.
<G-vec00366-002-s455><belong.zählen><de> Nosokomiale Infektionen zählen heute zu den häufigsten Infektionen während eines Krankenhausaufenthaltes, da diese zusätzlich zu einer bereits bestehenden Grunderkrankung mit einem Problemkeim erworben werden oder sich erst nach der Entlassung aus einem Krankenhaus manifestieren.
<G-vec00366-002-s456><belong.zählen><en> Also information about preferences, hobbies, memberships or which websites have been called up – all these belong to personal data.
<G-vec00366-002-s456><belong.zählen><de> Aber auch Daten über Vorlieben, Hobbys, Mitgliedschaften oder welche Webseiten von jemandem angesehen wurden zählen zu personenbezogenen Daten.
<G-vec00366-002-s457><belong.zählen><en> The four artists belong to a generation that experienced the most significant period of changes in Indonesia’s contemporary social and political situation first-hand.
<G-vec00366-002-s457><belong.zählen><de> Die vier ausstellenden Künstler zählen zu einer Generation, die eine Zeit wichtiger politischen Reformen und grundlegender sozialer und politischer Veränderungen in der zeitgenössischen Gesellschaft unmittelbar erlebt hat.
<G-vec00366-002-s458><belong.zählen><en> Its sister restaurants, which belong to Europe’s best steak houses are known by the name Surf´n Turf and are also recommended. They are located in Frankfurt’s West end.
<G-vec00366-002-s458><belong.zählen><de> Empfehlenswert sind auch die beiden Schwesterrestaurants, die seit langem zu den besten Steakhäusern Europas zählen und unter dem Namen Surf´n Turf im Frankfurter Westend zu finden sind.
<G-vec00366-002-s459><belong.zählen><en> Unreconciled cash accounts (checks) belong to the balance sheet accounts.
<G-vec00366-002-s459><belong.zählen><de> Zwischenkonten (Schecks) zählen zu den Bilanzkonten.
<G-vec00366-002-s460><belong.zählen><en> Countries such as England, Czech Republic, Croatia, Poland, Estonia and Hong Kong belong to the company's loyal customers.
<G-vec00366-002-s460><belong.zählen><de> So zählen heute Staaten wie England, Tschechien, Kroatien, Polen, Estland und Hong Kong zu treuen Kunden der Firma.
<G-vec00865-002-s019><belong.angehören><en> Genuine Membership All doctoral candidates admitted to pursue a doctoral degree at Philipps-Universität Marburg and all scholars holding a doctorate who are members of Philipps-Universität Marburg and do not belong to the professorial group may become members upon application.
<G-vec00865-002-s019><belong.angehören><de> Auf Antrag können alle an der Philipps-Universität Marburg zur Promotion zugelassenen Promovierenden und alle promovierten Wissenschaftlerinnen und Wissenschaftler, die Mitglieder der Philipps-Universität Marburg sind und die nicht der Professorengruppe angehören, Mitglied der MARA werden.
<G-vec00865-002-s020><belong.angehören><en> Even though they belong to different generations, the two men have a surprising amount in common.
<G-vec00865-002-s020><belong.angehören><de> Beide Männer haben, auch wenn sie unterschiedlichen Generationen angehören, überraschend vieles gemeinsam.
<G-vec00865-002-s021><belong.angehören><en> The third is the alphabet, which is different from Chinese ideography as well as from the Arabic and other alphabets; there are three major types of this writing, but it is manifest that they belong to the same family.
<G-vec00865-002-s021><belong.angehören><de> Das dritte ist die alphabetische Schrift, die sich sowohl von der chinesischen Bilderschrift als auch vom arabischen Alphabet und anderen Buchstabenschriften unterscheidet; von dieser Schrift existieren drei Hauptformen, die aber unverkennbar derselben Familie angehören.
<G-vec00865-002-s022><belong.angehören><en> But the last day will be a day of reckoning for all - will bring love and bliss to the ones who are mine and death and ruin to all who belong to my enemy because they will be pushed down into darkness and have to expiate their sins according to divine justice.
<G-vec00865-002-s022><belong.angehören><de> Doch der jüngste Tag wird eine Abrechnung sein für alle - Liebe und Seligkeit den Meinen bringen und Tod und Verderben für alle, die Meinem Gegner angehören, denn sie werden hinabgestoßen werden in die Finsternis und müssen ihre Sünden abbüßen laut göttlicher Gerechtigkeit.
<G-vec00865-002-s023><belong.angehören><en> It is shown that a certain type of MAI may belong to different MAI classes.
<G-vec00865-002-s023><belong.angehören><de> Eine MAI-Art kann dabei mehreren MAI-Klassen angehören.
<G-vec00865-002-s024><belong.angehören><en> Surely the likes of Albig and Gabriel should therefore soon belong to the past, provided the SPD doesn’t want to remain as the ghostly shadow of Merkel.
<G-vec00865-002-s024><belong.angehören><de> Sicher werden solche wie Albig und Gabriel deshalb bald der Vergangenheit angehören – vorausgesetzt die SPD will nicht länger der blasse Schatten von Merkel bleiben.
<G-vec00865-002-s025><belong.angehören><en> Yet he will have little success, for those who belong to Me are also capable of offering him resistance....
<G-vec00865-002-s025><belong.angehören><de> Doch er wird wenig Erfolg haben, denn die Mir angehören, sind auch fähig, ihm Widerstand zu leisten....
<G-vec00865-002-s026><belong.angehören><en> True members of this church of Mine understand each other even if they belong to different denominations and schools of thought, true members try to find each other and are happy to have found themselves, and true members are in innermost contact with Me Myself because they desire My Word and also recognise it as the right food and drink.
<G-vec00865-002-s026><belong.angehören><de> Rechte Glieder dieser Meiner Kirche verstehen sich, wenngleich sie verschiedenen Konfessionen und Geistesrichtungen angehören, rechte Glieder suchen einander und sind beglückt, sich gefunden zu haben, und rechte Glieder stehen in innigster Verbindung mit Mir Selbst, weil sie nach Meinem Wort verlangen und es auch erkennen als rechte Speise und rechten Trank.
<G-vec00865-002-s027><belong.angehören><en> Otherwise I would be prepared to prohibit the Jewish hospitals from admitting Aryans who do not belong to the Jewish religious community - with the exception of emergency cases.« The Mayor happily accepted the Gestapo's proposal, and jotted an unrestrained »good!« in the margin of Müller's letter.
<G-vec00865-002-s027><belong.angehören><de> Anderenfalls wäre ich bereit, den jüdischen Krankenhäusern die Aufnahme von Ariern, die nicht der jüdischen Religionsgemeinschaft angehören, - mit Ausnahme von Notfällen - von hier zu verbieten.« Der Oberbürgermeister nimmt die Anregung der Gestapo freudig an, vermerkt handschriftlich am Rande des Schreibens von Müller ein uneingeschränktes »gut!«.
<G-vec00865-002-s028><belong.angehören><en> When people belong to such an evil organization and do not stop that, then one can only assume that they themselves must be evil.
<G-vec00865-002-s028><belong.angehören><de> Wenn Leute einer solchen bösen Organisation angehören und damit nicht Schluß machen, dann kann man nur sagen, daß sie dann selbst böse sein müssen.
<G-vec00865-002-s029><belong.angehören><en> During the seminar there was presented information on the situation in the Moldovan media space and the engaged mass media, which belong nowadays to the oligarchs or political groups.
<G-vec00865-002-s029><belong.angehören><de> Während des Seminars wurden Informationen zur Situation im moldauischen Medienraum und in den engagierten Massenmedien präsentiert, die heute den Oligarchen oder politischen Gruppen angehören.
<G-vec00865-002-s030><belong.angehören><en> Even though these four principles of management, friendship, sublime joy, compassion and considered disregard belong to the past, they are unquestioned relevance for present-day management.
<G-vec00865-002-s030><belong.angehören><de> Obwohl diese vier Managementgrundsätze, Freundschaft, unbändige Freude, Mitgefühl und bewusste Nichtbeachtung, der Vergangenheit angehören, sind sie fraglos für das gegenwärtige Management relevant.
<G-vec00865-002-s031><belong.angehören><en> When – as is mostly the case, if the invention is important – these organisations belong to the rascals of the New World order, progress is turned into deadly weapons against mankind.
<G-vec00865-002-s031><belong.angehören><de> Wenn diese Organisationen dem haufen von Schurken der Neuen Weltordnung angehören - und das ist die Regel, wenn die Erfindung wichtig ist - werden die Fortschritte in tödliche Waffen gegen die Menschheit umgewandelt.
<G-vec00865-002-s032><belong.angehören><en> More than 200 sites are known in Europe, covering almost all the current European countries, which throughout history attended the signing of peace treaties that ended wars but also provided the advent of extended periods of social and economic development of regions, countries or kingdoms to which they belong.
<G-vec00865-002-s032><belong.angehören><de> Mehr als 200 Stätten sind in Europa bekannt, die fast alle derzeitigen europäischen Länder abdecken, die im Laufe der Geschichte an der Unterzeichnung von Friedensverträgen teilgenommen haben, die Kriege beendet haben, aber auch das Aufkommen langer Perioden der sozialen und wirtschaftlichen Entwicklung von Regionen, Ländern oder Königreichen, denen sie angehören, ermöglicht haben.
<G-vec00865-002-s033><belong.angehören><en> This does not apply, however, if you belong to the Anglican Church or the Orthodox Church.
<G-vec00865-002-s033><belong.angehören><de> Dies ist nicht der Fall, wenn Sie zum Beispiel der anglikanischen oder orthodoxen Kirche angehören.
<G-vec00865-002-s034><belong.angehören><en> Last but not least, the relations between the euro states and those EU members that do not yet belong to the monetary union are also an important factor.
<G-vec00865-002-s034><belong.angehören><de> Nicht zuletzt geht es auch um das Verhältnis der Eurostaaten zu den EU-Staaten, die der Währungsunion noch nicht angehören.
<G-vec00865-002-s035><belong.angehören><en> There are in the psychic fife, as we have heard, repressed wishes which belong to the first system, and to whose fulfilment the second system is opposed.
<G-vec00865-002-s035><belong.angehören><de> Es gibt, wie wir gehört haben, im Seelenleben verdrängte Wünsche, die dem ersten System angehören, gegen deren Erfüllung das zweite System sich sträubt.
<G-vec00865-002-s036><belong.angehören><en> Blessed Gérard’s Care Centre has not only had an enormous impact on the wellbeing of our patients who we provide with a comprehensive system of holistic care, but also on their families and the communities they belong to.
<G-vec00865-002-s036><belong.angehören><de> Blessed Gérard's Pflegezentrum hatte nicht nur einen enormen Einfluss auf das Wohlergehen unserer Patienten, denen wir ein umfassendes System ganzheitlicher Pflege bieten, sondern auch auf deren Familien und Gemeinden, denen sie angehören.
<G-vec00865-002-s037><belong.angehören><en> Both companies belong to the circle named "Friends of Technologies" want to bundle their competences together to offer powerful, optimized and individual products as well as solutions to their customers.
<G-vec00865-002-s037><belong.angehören><de> Der Kreis “Freunde der Technik”, dem DIENES und Rauschert angehören, möchte seinen Kunden durch diese Bündelung der Kompetenzen gemeinsam leistungsfähige, angepasste, individuelle Produkte und Lösungen anbieten.
<G-vec00865-002-s038><belong.angehören><en> I extend a special welcome to you, dear students, who belong to the community of the oldest ecclesiastical college of Rome.
<G-vec00865-002-s038><belong.angehören><de> Ganz besonders willkommen heiße ich euch, liebe Alumnen, die ihr der Gemeinschaft des ältesten kirchlichen Kollegs von Rom angehört.
<G-vec00865-002-s039><belong.angehören><en> For this, for the past two thousand years, the holy people of God, whatever the generation, status, race or culture they belong to, convenes every Sunday in the ecclesia eucaristica, publicly professing their own faith.
<G-vec00865-002-s039><belong.angehören><de> Darum findet sich seit 2000 Jahren das heilige Volk Gottes, gleichgültig, welcher Generation, Schicht, Rasse oder Kultur es angehört, jeden Sonntag in der ecclesia eucaristica zusammen, um öffentlich den eigenen Glauben zu bekennen.
<G-vec00865-002-s040><belong.angehören><en> You have a specific and important mission, that of keeping alive the relationship between the faith and the cultures of the peoples to whom you belong. You do this through popular piety.
<G-vec00865-002-s040><belong.angehören><de> Ihr habt einen besonderen und wichtigen Auftrag, nämlich die Beziehung zwischen dem Glauben und den Kulturen der Völker, denen ihr angehört, lebendig zu erhalten, und ihr tut dies durch die Volksfrömmigkeit.
<G-vec00865-002-s041><belong.angehören><en> Since there are more than one of these religions and since people do not belong to more than one religion, we can project that all people and all souls go to Hell.
<G-vec00865-002-s041><belong.angehören><de> Da es auf der Welt mehr als eine Religionen mit dieser Überzeugung gibt, und da niemand mehr als einer Religion angehört, kommen wir zu dem Schluss, dass alle Seelen in der Hölle enden.
<G-vec00865-002-s042><belong.angehören><en> If the requester does not belong to multiple organizations you will not see the Organization field on the ticket.
<G-vec00865-002-s042><belong.angehören><de> Wenn der Anfragende nicht mehreren Organisationen angehört, erscheint das Feld „Organisation“ nicht im Ticket.
<G-vec00865-002-s043><belong.angehören><en> No matter what generation you belong to, everyone can experience the fascination of nature in an individual way.
<G-vec00865-002-s043><belong.angehören><de> Egal welcher Generation man angehört, die Faszination der Natur lässt sich hier für jeden auf ganz eigene Weise erleben.
<G-vec00865-002-s044><belong.angehören><en> You define the profit center structure and the profit center to which the cost center is to belong.
<G-vec00865-002-s044><belong.angehören><de> Bei der Zuordnung bestimmen Sie die Profitcenterstruktur und das jeweilige Profitcenter, dem die Kostenstelle angehört.
<G-vec00865-002-s045><belong.angehören><en> For example, today the integral cause of the family and of life have been rediscovered and encouraged in many sectors as a value and a right that belong to the common patrimony of humanity.
<G-vec00865-002-s045><belong.angehören><de> So wird beispielsweise das gesamtheitliche Wesen der Familie und des Lebens heute in vielen Bereichen als Wert und Recht, das dem gemeinsamen Erbe der Menschheit angehört, neuentdeckt und gefördert.
<G-vec00865-002-s046><belong.angehören><en> This explains the striking fact that the hybrids are able to produce, besides the two parental forms, offspring which are like themselves; A a ----- and ----- a A both give the same union Aa, since, as already remarked above, it makes no difference in the result of fertilization to which of the two characters the pollen or egg cells belong.
<G-vec00865-002-s046><belong.angehören><de> Daraus erklärt sich die auffallende Erscheinung, dass die Hybriden im Stande sind, nebst den beiden Stammformen auch Nachkommen zu erzeugen, die ihnen selbst gleich sind; A/a und a/A geben beide dieselbe Verbindung Aa, da es, wie schon früher angeführt wurde, für den Erfolg der Befruchtung keinen Unterschied macht, welches von den beiden Merkmalen der Pollen- oder Keimzelle angehört.
<G-vec00865-002-s047><belong.angehören><en> 41 'If anyone gives you a cup of water to drink because you belong to Christ, then in truth I tell you, he will most certainly not lose his reward.
<G-vec00865-002-s047><belong.angehören><de> 41 Denn wer euch einen Becher Wasser zu trinken gibt deshalb, weil ihr Christus angehört, wahrlich, ich sage euch: Er wird nicht um seinen Lohn kommen.
<G-vec00865-002-s048><belong.angehören><en> 9:41 For whoever shall give you a cup of water to drink in my name, because ye belong to Christ, verily I say to you, he shall not lose his reward.
<G-vec00865-002-s048><belong.angehören><de> 41 Denn wer euch einen Becher Wasser zu trinken geben wird in [meinem] Namen, weil ihr Christus angehört, wahrlich, ich sage euch: er wird seinen Lohn nicht verlieren.
<G-vec00865-002-s049><belong.angehören><en> I believe that, culturally speaking, the vast majority of Tunisians belong to the centre of society.
<G-vec00865-002-s049><belong.angehören><de> Ich glaube, dass eine überwiegende Mehrheit der Tunesier kulturell gesehen der Mitte der Gesellschaft angehört.
<G-vec00865-002-s050><belong.angehören><en> But even if your company does not belong to one of these classic MST applying branches, a close look at the great potential of these small components surely is worthwhile.
<G-vec00865-002-s050><belong.angehören><de> Doch auch wenn Ihr Unternehmen keiner klassischen MST-Anwender-Branche angehört, lohnt sich die Beschäftigung mit dem großen Potenzial der kleinen Komponenten.
<G-vec00865-002-s051><belong.angehören><en> In the tab “Teams”, you can see the individual teams to which you belong.
<G-vec00865-002-s051><belong.angehören><de> Im Reiter „Teams“, sind die einzelnen Teams zu sehen, denen man selbst angehört.
<G-vec00865-002-s052><belong.angehören><en> And nothing should dominate it. Whether you belong to this country or that country, or this ‘ism’ or that ‘ism’.
<G-vec00865-002-s052><belong.angehören><de> Nichts sollte ihn dominieren, ganz egal, welchem Land ihr angehört oder welchem Ismus.
<G-vec00865-002-s053><belong.angehören><en> Indeed the project nomad (Dr. Antje Kahl) does not belong directly to any of the CRC’s subprojects.
<G-vec00865-002-s053><belong.angehören><de> Allerdings ist es so, dass die Projektnomadin (Dr. Antje Kahl) keinem der einzelnen Teilprojekte des SFBs direkt angehört.
<G-vec00865-002-s054><belong.angehören><en> This augmentation of surplus-value is pocketed by him, whether his commodities belong or not to the class of necessary means of subsistence that participate in determining the general value of labour-power.
<G-vec00865-002-s054><belong.angehören><de> Diese Steigerung des Mehrwerths findet für ihn statt, ob oder ob nicht seine Waare dem Umkreis der nothwendigen Lebensmittel angehört und daher bestimmend in den allgemeinen Werth der Arbeitskraft eingeht.
<G-vec00865-002-s055><belong.angehören><en> The College to which you belong, the neighbourhood in which you live and study, the tradition of faith and Christian witness that has formed you: all these are hallowed by the presence of many saints.
<G-vec00865-002-s055><belong.angehören><de> Das Kolleg, dem ihr angehört, die Umgebung, in der ihr lebt und studiert, die Glaubenstradition und das christliche Zeugnis, die euch geformt haben: sie alle werden geheiligt durch die Gegenwart zahlreicher Heiliger.
<G-vec00865-002-s056><belong.angehören><en> So sometimes yes, it makes a difference if you belong to a different faith.
<G-vec00865-002-s056><belong.angehören><de> Denn es macht zwar manchmal einen Unterschied, welcher Religion man angehört.
<G-vec00865-002-s130><belong.gehören><en> I belong to nowhere, because I like to be in other places and to always get new experiences.
<G-vec00865-002-s130><belong.gehören><de> Ich gehöre zu keinem Ort, weil ich gern an anderen Plätzen und immer auf der Suche nach einer neuen Erfahrung bin.
<G-vec00865-002-s131><belong.gehören><en> It is like a last name: if the first name is “I am Christian”, the last name is “I belong to the Church”.
<G-vec00865-002-s131><belong.gehören><de> Es ist wie ein Nachname: Wenn der Name lautet »Ich bin Christ«, so lautet der Nachname »Ich gehöre zur Kirche«.
<G-vec00865-002-s132><belong.gehören><en> I don’t belong to Germany.
<G-vec00865-002-s132><belong.gehören><de> Ich gehöre nicht zu Deutschland.
<G-vec00865-002-s133><belong.gehören><en> After belonging to the Father, every child should have the thought: Now that I belong to the Father, I will definitely go to heaven. However, you also have to think about what you want to become in heaven.
<G-vec00865-002-s133><belong.gehören><de> Nachdem ihr zum Vater gehört, sollte jedes Kind den Gedanken haben: „Nun, da ich zum Vater gehöre, werde ich ganz sicher in den Himmel gehen.“ Macht euch aber auch Gedanken darüber, was ihr im Himmel werden möchtet.
<G-vec00865-002-s134><belong.gehören><en> I belong to no one.
<G-vec00865-002-s134><belong.gehören><de> Ich gehöre niemandem.
<G-vec00865-002-s135><belong.gehören><en> „Oh my Jesus, I belong to you completely.
<G-vec00865-002-s135><belong.gehören><de> „O mein Jesus, ganz und gar gehöre ich dir.
<G-vec00865-002-s136><belong.gehören><en> However, all my life I felt that I belong to God.
<G-vec00865-002-s136><belong.gehören><de> Auch wenn ich mein ganzes Leben lang fühlte, dass ich zu Gott gehöre.
<G-vec00865-002-s137><belong.gehören><en> All these years, and I finally understood that I’m not a freak of nature, but that I belong to the next generation on the road to a new and better cooperation – in peace with myself and all life.
<G-vec00865-002-s137><belong.gehören><de> All die Jahre, und endlich verstehe ich, dass ich keine Laune der Natur bin, sondern zur nächsten Generation auf dem Weg zu einem neuen und besseren Miteinander gehöre – in Frieden mit mir selbst und allem Leben.
<G-vec00865-002-s138><belong.gehören><en> Harbouring the spiritual emotion (bhāv) that ‘I belong to others and all are mine’.
<G-vec00865-002-s138><belong.gehören><de> Die spirituelle Emotion (bhāv) empfinden, dass „alle eins sind, ich gehöre zu den Anderen und alle zu mir“.
<G-vec00865-002-s139><belong.gehören><en> I belong to the holy Kadis, and to avenge the Mokkadem I have waited for you in Maabdah.
<G-vec00865-002-s139><belong.gehören><de> Ich gehöre zur heiligen Kadirine und habe, um diese an dir zu rächen, in Maabdah auf dich gewartet.
<G-vec00865-002-s140><belong.gehören><en> “I do belong here, Paul.
<G-vec00865-002-s140><belong.gehören><de> “Ich gehöre hierher, Paul.
<G-vec00865-002-s141><belong.gehören><en> Q. I belong to a Charismatic Group, but the prayer is lengthy, confused and there is a lot of gesticulation.
<G-vec00865-002-s141><belong.gehören><de> F. Ich gehöre zu einer Erneuerungsgruppe, aber das Gebet wird oft lang hinausgezogen, ist verworren und gebärdenhaft.
<G-vec00865-002-s142><belong.gehören><en> And then there are the Type E: This group I belong to, definitely.
<G-vec00865-002-s142><belong.gehören><de> Und dann gibt es den Typ E: Zu dieser Gruppe gehöre ich definitiv dazu.
<G-vec00865-002-s143><belong.gehören><en> “Apparently, I do not belong to the number of“ competent engine operators, ”because I do not consider the NK-93 project to be innovative, since The methodology and design tools, production technologies of NK-93 production belong to the middle of the 80-s of the last century.
<G-vec00865-002-s143><belong.gehören><de> „Anscheinend gehöre ich nicht zur Anzahl der„ kompetenten Triebwerksbetreiber “, weil ich das NK-93-Projekt nicht als innovativ empfinde, da Die Methodik und Entwurfswerkzeuge, Produktionstechnologien der NK-93-Produktion gehören zur Mitte der 80-S des letzten Jahrhunderts.
<G-vec00865-002-s144><belong.gehören><en> I would like to make a distinction between us and the Americans. Obviously they have their own considerations. But I belong to a generation which grew up in the days when if Moscow did something on the international scene, let’s say in the UN, then it was clear that Hungary would follow its lead.
<G-vec00865-002-s144><belong.gehören><de> Ich möchte uns von den Amerikanern lösen, sicherlich besitzen sie ihre eigenen Gesichtspunkte, aber ich gehöre noch zu der Generation, die noch so aufgewachsen ist, dass wenn Moskau etwas in der internationalen Arena, sagen wir in der UNO, unternommen hat, man wissen konnte, Ungarn werde der Sowjetunion folgen.
<G-vec00865-002-s145><belong.gehören><en> Even though I sometimes feel like I don't belong in heaven because of those words, I live my life as cleanly and compassionately as possible.
<G-vec00865-002-s145><belong.gehören><de> Auch wenn ich manchmal fühle, daß ich nicht in den Himmel gehöre, wegen dieser Worte, leben ich mein Leben so rein und mitfühlend, wie möglich.
<G-vec00865-002-s146><belong.gehören><en> "I belong to such and such community.
<G-vec00865-002-s146><belong.gehören><de> "Ich gehöre zu dieser Familie.
<G-vec00865-002-s147><belong.gehören><en> He speaks several times about the University, to which, however, I do not belong.
<G-vec00865-002-s147><belong.gehören><de> Mehrmals spricht er von der Universität, an die ich aber nicht gehöre.
<G-vec00865-002-s148><belong.gehören><en> I belong to Him.
<G-vec00865-002-s148><belong.gehören><de> Ich gehöre zu Ihm.
<G-vec00865-002-s149><belong.gehören><en> Today a total of 900 cooperatives belong to the U.S. umbrella organisation America’s Cooperative Electric Utilities, providing 42 million customers with energy.
<G-vec00865-002-s149><belong.gehören><de> Heute gehören dem US-Dachverband America’s Cooperative Electric Utilities 900 Genossenschaften an, die 42 Millionen Kunden mit Energie versorgen.
<G-vec00865-002-s150><belong.gehören><en> The values shown in the Property Editor belong to the active object of your active document (be careful of which document is really active if you work on multiple documents).
<G-vec00865-002-s150><belong.gehören><de> Die im Eigenschafteneditor angezeigten Werte gehören zum aktiven Objekt des aktiven Dokuments (Vorsicht ist geboten, welches Dokument gerade aktiv ist, wenn mit mehreren Dokumenten gearbeitet wird).
<G-vec00865-002-s151><belong.gehören><en> And it is again totally free of integrated circuits (the two opamps you can see on the pics below don't belong to the filter; they serve as part of the Moog transistor matching circuit which I added to the board to be independent of any external test circuit).
<G-vec00865-002-s151><belong.gehören><de> Und auch diese Schaltung ist völlig frei von integrierten Schaltkreisen (die beiden OpAmps auf dem Bild unten gehören nicht zum Filter, sondern sind Bestandteil der Standard-Moog-Transistor-Matching - Schaltung, welche ich auf der Platine des T904A mit integriert habe, um von irgendwelchen externen Testschaltungen unabhängig zu bleiben).
<G-vec00865-002-s152><belong.gehören><en> That means, two fields can have the same label as long as they belong to different tables within the structure, but they cannot if they belong to the same table.
<G-vec00865-002-s152><belong.gehören><de> So dürfen zwei Felder dasselbe Label haben, solange sie innerhalb der Struktur zu verschiedenen Tabellen gehören, nicht jedoch, wenn sie zur selben Tabelle gehören.
<G-vec00865-002-s154><belong.gehören><en> Around 30 per cent of them belong to the Catholic, 20 per cent to the Reformed Church.
<G-vec00865-002-s154><belong.gehören><de> Ungefähr 30 Prozent davon gehören der katholischen, 20 Prozent der evangelischen Kirche an.
<G-vec00865-002-s155><belong.gehören><en> However, the large pool and a spacious terrace belong to almost every property in the country.
<G-vec00865-002-s155><belong.gehören><de> Allerdings gehören der große Pool und eine großzügige Terrasse fast zu jeder Immobilie auf dem Land.
<G-vec00865-002-s156><belong.gehören><en> The following Portuguese words have a similar or identical meaning as «homeostase» and belong to the same grammatical category. Portuguese synonyms of homeostase
<G-vec00865-002-s156><belong.gehören><de> Die folgenden Wörter im Wörterbuch Portugiesisch haben eine ähnliche oder gleiche Bedeutung wie «exame» und gehören zu derselben grammatikalischen Kategorie.
<G-vec00865-002-s157><belong.gehören><en> I acknowledge and agree that any material recorded or any original work made under this Agreement and/or when using Kristal Cams services (and all rights therein, including, without limitation, copyright) belong to and will be the sole and exclusive property of Kristal Cams.
<G-vec00865-002-s157><belong.gehören><de> Ich erkenne an und stimme zu, dass jedwedes aufgenommene Material oder jedwedes originale Werk, welches im Rahmen dieser Vereinbarung und/oder bei der Nutzung der video-girl.biz Dienste (und all hierin beinhalteten Rechte, einschließlich, jedoch ohne Beschränkung auf das Urheberrecht) hergestellt wurden, video-girl.biz gehören und deren alleiniges und exklusives Eigentum sind.
<G-vec00865-002-s158><belong.gehören><en> Le 6:14; Le 6:25; Le 7:1; Le 27:21; Le 27:28; Nu 18:14) 30 And the first of all the firstfruits of all kinds, and every offering of all kinds from all your offerings, shall belong to the priests.
<G-vec00865-002-s158><belong.gehören><de> 30 Das Beste von allen Erstlingsopfern jeglicher Art, all eure Hebeopfer jeglicher Art, die ihr entrichten müsst, gehören den Priestern; auch das Beste von eurem Schrotmehl sollt ihr dem Priester geben, damit Segen über deinem Hause ruhe.
<G-vec00865-002-s159><belong.gehören><en> Only visitors from China have increasingly become more and more over the last three fairs and today belong to the top ten visitor nations.
<G-vec00865-002-s159><belong.gehören><de> Einzig Besucher aus China sind über die letzten drei Veranstaltungen hinweg immer mehr geworden und gehören heute zu den Top-Ten-Besuchernationen.
<G-vec00865-002-s160><belong.gehören><en> Used capsules belong to residual waste.
<G-vec00865-002-s160><belong.gehören><de> Alte Kapseln gehören in den Restmüll.
<G-vec00865-002-s161><belong.gehören><en> It’s obvious that a city like San Francisco is more than the Golden Gate Bridge and Fisherman’s Wharf, but they belong uniquely to San Francisco as well.
<G-vec00865-002-s161><belong.gehören><de> Klar macht eine Stadt wie San Francisco mehr aus als die Golden Gate Bridge und die Fisherman’s Wharf, aber sie gehören doch eindeutig dazu.
<G-vec00865-002-s162><belong.gehören><en> The instruments of strategic planning and consulting belong to to our applied methods.
<G-vec00865-002-s162><belong.gehören><de> Die Instrumente der strategischen Planung und klassischen Unternehmensberatung gehören zu unseren angewandten Methoden.
<G-vec00865-002-s163><belong.gehören><en> To these silent movies belong "Holzhacker" (08), "Kaberett.
<G-vec00865-002-s163><belong.gehören><de> Dazu gehören die Stummfilme "Holzhacker" (08), "Kaberett.
<G-vec00865-002-s164><belong.gehören><en> Police say they do not know how many people belong to the gang, which was established in May.
<G-vec00865-002-s164><belong.gehören><de> Der Polizei ist nach eigenen Angaben nicht bekannt, wie viele Personen zu der im Mai gegründeten Gang gehören.
<G-vec00865-002-s165><belong.gehören><en> However, this coming in the clouds will also only be visible to those who belong to My Own, for My adversary's followers will be unable to see Me.
<G-vec00865-002-s165><belong.gehören><de> Doch dieses Kommen in den Wolken wird auch nur von denen gesichtet werden, die zu den Meinen gehören, denn die Anhänger Meines Gegners vermögen Mich nicht zu schauen.
<G-vec00865-002-s166><belong.gehören><en> I acknowledge and agree that any material recorded or any original work made under this Agreement and/or when using Pornohumedo services (and all rights therein, including, without limitation, copyright) belong to and will be the sole and exclusive property of Pornohumedo.
<G-vec00865-002-s166><belong.gehören><de> Ich erkenne an und stimme zu, dass jedwedes aufgenommene Material oder jedwedes originale Werk, welches im Rahmen dieser Vereinbarung und/oder bei der Nutzung der Veto Cams Dienste (und all hierin beinhalteten Rechte, einschließlich, jedoch ohne Beschränkung auf das Urheberrecht) hergestellt wurden, Veto Cams gehören und deren alleiniges und exklusives Eigentum sind.
<G-vec00865-002-s167><belong.gehören><en> The photographs belong to a model apartment.
<G-vec00865-002-s167><belong.gehören><de> Die Fotografien gehören zu einer Modell Wohnung.
<G-vec00865-002-s187><belong.gehören><en> The shirt features a roundneck and front print to show everyone that you belong to Captain Harry Potters Gryffindor team.
<G-vec00865-002-s187><belong.gehören><de> Das Shirt hat einen Rundhalsausschnitt und eine bedruckte Front, mit der du allen zeigst, dass du zu Captain Harry Potters Gryffindor Team gehörst.
<G-vec00865-002-s188><belong.gehören><en> If you try to find it and to care, you’ll lose track and belong to the jungle.
<G-vec00865-002-s188><belong.gehören><de> Versuchst du es zu finden, verläufst du dich und gehörst dem Dschungel.
<G-vec00865-002-s189><belong.gehören><en> Although you have experienced chastisement and judgment, your disposition is not renewed or changed as a result; you are still your old self, you still belong to Satan, and you are not someone who has been cleansed.
<G-vec00865-002-s189><belong.gehören><de> Obwohl du Züchtigung und Urteil erfahren hast, ist deine Disposition als Folge davon nicht erneuert oder geändert; du bist noch immer dein altes Selbst, du gehörst noch immer Satan und du bist nicht jemand, der gesäubert worden ist.
<G-vec00865-002-s190><belong.gehören><en> Elongate yourself to Heaven, for that is where you belong.
<G-vec00865-002-s190><belong.gehören><de> Verlängere dich zum Himmel, denn ihm gehörst du zu.
<G-vec00865-002-s191><belong.gehören><en> You could be turkish, kurdish, woman, member of the LGBTI movement or just not a fan of him – then you belong to the others.
<G-vec00865-002-s191><belong.gehören><de> Du kannst türkisch, kurdisch, Frau, Mitglied der LGBTI Bewegung oder einfach nur kein Fan von ihm sein – dann gehörst du zu den anderen.
<G-vec00865-002-s192><belong.gehören><en> As a sneaky serial killer masked you belong to the most famous horror movie characters of the US cinema.
<G-vec00865-002-s192><belong.gehören><de> Als hinterhältiger Serienkiller maskiert gehörst du damit zu den bekanntesten Horrorfilm Figuren des US Kinos.
<G-vec00865-002-s193><belong.gehören><en> Everybody matters: You belong to a dynamic, rapidly growing and extraordinarily innovative company and can fully develop your strengths.
<G-vec00865-002-s193><belong.gehören><de> Everybody matters: Du gehörst einem dynamischen, stark wachsenden und außerordentlich innovativen Unternehmen an und kannst Deine Stärken voll entfalten.
<G-vec00865-002-s194><belong.gehören><en> CUSTOMER_INFO ~ An encrypted version of the customer group you belong to.
<G-vec00865-002-s194><belong.gehören><de> CUSTOMER_INFO Eine verschlüsselte Version der Kundengruppe zu der du gehörst.
<G-vec00865-002-s195><belong.gehören><en> If you were able to answer YES to all or more points, then you too belong to the group of people whose clair senses are very good.
<G-vec00865-002-s195><belong.gehören><de> Wenn du alle oder mehrere Punkte mit JA beantworten konntest, gehörst auch du zur Gruppe der Menschen, deren Hellsinne gut ausgeprägt sind.
<G-vec00865-002-s196><belong.gehören><en> You belong to god, you belong to love.
<G-vec00865-002-s196><belong.gehören><de> Du gehörst zu Gott, du gehörst zur Liebe.
<G-vec00865-002-s198><belong.gehören><en> Your will belong to the elite of fans With with our exclusive Discount Club.
<G-vec00865-002-s198><belong.gehören><de> Mit unserem exklusiven Discount Club gehörst Du zur Elite der Fans.
<G-vec00865-002-s199><belong.gehören><en> After having completed an apprenticeship at EGGER you belong to the most attractive junior staff in your field and you will have a wide range of opportunities.
<G-vec00865-002-s199><belong.gehören><de> Mit einem Lehrabschluss bei EGGER gehörst du zu den gefragtesten Nachwuchsfachkräften in deinem Bereich und dir stehen Tür und Tor offen.
<G-vec00865-002-s200><belong.gehören><en> However, when I name you My friend, you are no longer a stranger, but belong to My house through My word that you faithfully embraced in your heart.
<G-vec00865-002-s200><belong.gehören><de> So Ich dich aber Meinen Freund nenne, da bist du kein Fremder mehr, sondern gehörst zu Meinem Hause durch Mein Wort, das du in dein Herz treulichst aufgenommen hast.
<G-vec00865-002-s201><belong.gehören><en> And that you belong to the good drivers in an industry with plenty of black sheep (from October 2019).
<G-vec00865-002-s201><belong.gehören><de> Und dass Du in einer Branche mit vielen schwarzen Schafen zu den guten Fahrern gehörst (ab Oktober 2019).
<G-vec00865-002-s202><belong.gehören><en> Now you know where you belong, where you ever belong, where you are ever wanted, where your place is, where you are treasured, held high, seen with the Eyes of Truth.
<G-vec00865-002-s202><belong.gehören><de> Nun weißt du, wohin du gehörst, wohin du seit eh und je gehörst, wo du seit eh und je erwünscht bist, wo dein Platz ist, wo du wertgeschätzt, hochgehalten, mit den Augen der Wahrheit in den Blick genommen bist.
<G-vec00865-002-s204><belong.gehören><en> 1,2,3 I belong with you, you belong with me you're my sweetheart
<G-vec00865-002-s204><belong.gehören><de> 1, 2, 3, Ich gehöre zu dir, du gehörst zu mir, du bist meine Süße.
<G-vec00865-002-s205><belong.gehören><en> And if you die, another smile, then you belong to me.
<G-vec00865-002-s205><belong.gehören><de> Und wenn du stirbst – ein weiteres Lächeln –, dann gehörst du mir.
<G-vec00865-002-s206><belong.gehören><en> The difference between win.win and any other DEX is that win.win will belong to the community of its users, will be safe, secure and will have no trading fees.
<G-vec00865-002-s206><belong.gehören><de> Der Unterschied zwischen win.win und jeder anderen DEX besteht darin, dass win.win zur Community seiner Benutzer gehört, sicher ist und keine Handelsgebühren erhebt.
<G-vec00865-002-s207><belong.gehören><en> 25 It was while she was being brought out that she sent to her father-in-law, saying, "I am with child by the man to whom these things belong."
<G-vec00865-002-s207><belong.gehören><de> 25 Als sie nun hinausgeführt wurde, da sandte sie zu ihrem Schwiegervater und ließ [ihm] sagen: Von einem Mann, dem dies gehört, bin ich schwanger.
<G-vec00865-002-s208><belong.gehören><en> This is a crowning of the fact, that we belong to the fastest growing companies in our country.
<G-vec00865-002-s208><belong.gehören><de> Dieses Ereignis ist für uns die Krönung der Tatsache, dass die Firma schon seit vielen Jahren zu den am schnellsten entwickelnden Firmen in Polen gehört.
<G-vec00865-002-s209><belong.gehören><en> Things that belong together come together here: Blaupunkt hobs with Multi Control enter a unique relationship – with the Multi Control extractor fan hoods.
<G-vec00865-002-s209><belong.gehören><de> Hier kommt zusammen, was zusammen gehört: Blaupunkt Kochfelder mit Multi Control gehen eine einzigartige Verbindung ein — mit den Multi Control Dunstabzugshauben.
<G-vec00865-002-s210><belong.gehören><en> 29 If you belong to Christ, then you are Abraham’s seed, and heirs according to the promise.
<G-vec00865-002-s210><belong.gehören><de> 29Wenn ihr aber zu Christus gehört, dann seid ihr Abrahams Nachkommen, Erben kraft der Verheißung.
<G-vec00865-002-s211><belong.gehören><en> Geographically, the company premises belong to the Upper Tannauer Valley.
<G-vec00865-002-s211><belong.gehören><de> Naturräumlich gehört das Firmengelände zum Oberen Tannauer Tal.
<G-vec00865-002-s212><belong.gehören><en> • The presentation of the website in a window that does not belong to Codi3, by "framing".
<G-vec00865-002-s212><belong.gehören><de> • Die Präsentation der Website mittels „Framing“ in einem Fenster, das nicht zu Codi3.com gehört.
<G-vec00865-002-s213><belong.gehören><en> The process appears to belong to software Citrix Web Client by unknown.
<G-vec00865-002-s213><belong.gehören><de> Der Prozess gehört offenbar zur Software Citrix Web Client der Firma unbekannt.
<G-vec00865-002-s214><belong.gehören><en> All of these qualifiers are potentially important in classifying drugs and substances, but many people argue that marijuana does not belong in Schedule I.
<G-vec00865-002-s214><belong.gehören><de> All diese Klassifizierungen sind potenziell wichtig beim Klassifizieren von Drogen und Substanzen, aber viele Menschen behaupten dass Marihuana nicht in Schedule 1 gehört.
<G-vec00865-002-s215><belong.gehören><en> Sometimes it happens that a menu or a panel does not belong to a certain hologram, but should be accessible from everywhere.
<G-vec00865-002-s215><belong.gehören><de> Mitunter kommt es aber vor, dass ein Menü oder ein Panel nicht zu einem bestimmten Hologramm gehört, sondern von überall aus zugänglich sein soll.
<G-vec00865-002-s216><belong.gehören><en> A timeline makes it crystal clear what tasks belong to what step and how long each step should take.
<G-vec00865-002-s216><belong.gehören><de> Durch eine Zeitleiste wird deutlich gemacht, welche Aufgabe zu welchem Schritt gehört und bis wann welcher Schritt abgeschlossen werden sollte.
<G-vec00865-002-s217><belong.gehören><en> Trump does not belong to these elites.
<G-vec00865-002-s217><belong.gehören><de> Trump gehört nicht zu diesen Eliten.
<G-vec00865-002-s218><belong.gehören><en> Since 2001, the Gütersloh-based company RWT GmbH (previously Ravensberger Wasseraufbereitungstechnik GmbH) and since 2004 the company Hydro-Elektrik AS in Norway belong as independently-operated members to the Hydro-Elektrik GmbH group of companies.
<G-vec00865-002-s218><belong.gehören><de> Seit 2001 gehört die Gütersloher Firma RWT GmbH (früher Ravensberger Wasser-aufbereitungstechnik GmbH) und seit 2004 die Firma Hydro-Elektrik AS in Norwegen als eigenständig operierende Unternehmen zur Firmengruppe Hydro-Elektrik GmbH.
<G-vec00865-002-s219><belong.gehören><en> When the girls were born, Tolya realized that now in his life there are changes and his mother does not belong to him a hundred percent.
<G-vec00865-002-s219><belong.gehören><de> Als die Mädchen geboren wurden, erkannte Tolya, dass es in seinem Leben Veränderungen gibt und seine Mutter nicht hundertprozentig zu ihm gehört.
<G-vec00865-002-s220><belong.gehören><en> As a result, Italy will belong to a group of countries such as Spain, Portugal, Brazil and China, which are already holiday destinations for TUI and are being consistently developed as markets to win new customer segments.
<G-vec00865-002-s220><belong.gehören><de> Damit gehört Italien zu einer Gruppe von Ländern wie Spanien, Portugal, Brasilien und China, die heute bereits Urlaubsdestinationen für TUI sind und auch als Markt für neue Kundengruppen konsequent entwickelt werden sollen.
<G-vec00865-002-s221><belong.gehören><en> There is another thing that is difficult for them: that the child does not belong to anyone, not even to its parents.
<G-vec00865-002-s221><belong.gehören><de> Noch eine weitere Tatsache fällt ihnen schwer: daß das Kind niemandem gehört, auch nicht den Eltern.
<G-vec00865-002-s222><belong.gehören><en> We appreciate your interest in Heinze Group. In Europe we belong to the leading companies in the area of plastic technologies, surface refining, electroplating and tool construction and production.
<G-vec00865-002-s222><belong.gehören><de> Wer zu den führenden Unternehmen in der Kunststofftechnik, der Oberflächenveredelung, des Werkzeug- und Formenbaus sowie vor allem der Galvanik in Europa gehört, der kann die Sicherheit und den Umweltschutz gar nicht ernst genug nehmen.
<G-vec00865-002-s223><belong.gehören><en> Anyway for my part I'm off here before the encore, just not to get between the whole crowd comiing out and also not to be late for a date.... okay, this doesn't belong here, does it?!!!
<G-vec00865-002-s223><belong.gehören><de> Anyway, ich für meinen Teil verdrücke mich noch vor dem letztendlichen Finale, um erstens nicht in den herausströmenden Massen zu ertrinken und um andererseits noch ein Date....... – nun das gehört wohl nicht mehr hier her...
<G-vec00865-002-s224><belong.gehören><en> Then he will belong to the church of Christ which requires no other name, which has no external attribute but the effectiveness of the strength of spirit, which can also be outwardly recognised by a way of life in love and wisdom.
<G-vec00865-002-s224><belong.gehören><de> Dann gehört er zur Kirche Christi, die keinen anderen Namen benötigt, die kein äußeres Merkmal aufzuweisen hat als nur die Wirksamkeit der Kraft des Geistes, die auch nach außen zu erkennen ist durch einen Lebenswandel in Liebe und Weisheit.
<G-vec00865-002-s225><belong.gehören><en> At that time, this area was still Bavarian, thus it did not belong to Tyrol.
<G-vec00865-002-s225><belong.gehören><de> Damals war die Gegend noch bayerisch, gehörte also nicht den Tirolern.
<G-vec00865-002-s226><belong.gehören><en> He almost caused a civil war just by choosing his wife – she did not belong to Tonga’s upper class.
<G-vec00865-002-s226><belong.gehören><de> Schon durch die Wahl seiner Ehefrau – sie gehörte nicht zur Oberschicht von Tonga – hätte er beinahe einen Bürgerkrieg ausgelöst.
<G-vec00865-002-s227><belong.gehören><en> He himself did not belong to any faith group.
<G-vec00865-002-s227><belong.gehören><de> Er selbst gehörte keiner der Glaubensgemeinschaften an.
<G-vec00865-002-s228><belong.gehören><en> He didn't belong to any of them, but he condemned the whole thing.
<G-vec00865-002-s228><belong.gehören><de> Er gehörte zu keiner von denen, sondern er verurteilte die ganze Sache.
<G-vec00865-002-s229><belong.gehören><en> But until this turning to me has occurred, often endless times pass, and in this time I struggle for every one soul, by me courting its love, because love alone only changes the will, which did not belong to me before.
<G-vec00865-002-s229><belong.gehören><de> Doch bis dieses Zuwenden zu Mir eingetreten ist, vergehen oft endlose Zeiten, und in dieser Zeit ringe Ich um eine jede Seele, indem Ich um ihre Liebe werbe, weil nur allein die Liebe den Willen wandelt, der Mir zuvor nicht gehörte.
<G-vec00865-002-s230><belong.gehören><en> But Warsaw did not belong to number of the large musical centres of Europe, and soon Chopin has felt requirement of departure abroad to enrich and expand the musical experience.
<G-vec00865-002-s230><belong.gehören><de> Aber Warschau gehörte zur Zahl der großen musikalischen Zentren Europas nicht, und bald hat Schopen das Bedürfnis der Abreise ins Ausland empfunden, um die musikalische Erfahrung zu bereichern und auszudehnen.
<G-vec00865-002-s231><belong.gehören><en> Once more we will pray for the little girls who died in a terrible bus accident in northern Chile; what those who prayed for them last Saturday, with great emotion, did not know was that fifteen year old Bernardita was a member of the Schoenstatt Girls’ Youth, and in June, she and her parents, who also belong to the Movement, visited Schoenstatt.
<G-vec00865-002-s231><belong.gehören><de> Noch einmal wird, wie schon am letzten Samstag, für die nuen Mädchen gebetet, die bei dem schrecklichen Busunglück im Norden Chiles ums Leben gekommen sind; als am letzten Samstag, noch ganz bewegt von der gerade erst erhaltenen Nachricht, die kleine Gruppe Jugendlicher im Urheiligtum betete, wusste ja niemand von ihnen, dass eine von ihnen, Bernardita, 15 Jahre alt, zur Schönstatt-Mädchenjugend gehörte und gerader erst im vergangenen Juni mit ihren Eltern, die ebenfalls zu Schönstatt gehören, in Schönstatt gewesen war.
<G-vec00865-002-s232><belong.gehören><en> That money didn't even belong to him.
<G-vec00865-002-s232><belong.gehören><de> Das Geld gehörte ihm nicht einmal.
<G-vec00865-002-s233><belong.gehören><en> Rightly Dickhut and the KAB/ML during that time were generally considered the extreme right-wingers of the ml-movement, a semi-revisionist organization which properly spoken did not really belong to the revolutionary spectrum.
<G-vec00865-002-s233><belong.gehören><de> Zurecht galten Dickhut und der KAB/ML damals allgemein als der Rechtsaußen der ml-Bewegung, eine halbrevisionistische Organisation, die eigentlich nicht ernsthaft ins revolutionäre Spektrum gehörte.
<G-vec00865-002-s234><belong.gehören><en> The statuette had once been gilded and used to belong to the treasure of the cathedral in Metz.
<G-vec00865-002-s234><belong.gehören><de> Die Skulptur war einmal vergoldet und gehörte zum Domschatz in Metz.
<G-vec00865-002-s235><belong.gehören><en> In fact, it Board of Ed issued us all with SchoolBooks, there was no way my parents were going to buy me a computer of my own, even though technically the SchoolBook didn't belong to me, and I wasn't supposed to install software on it or mod it.
<G-vec00865-002-s235><belong.gehören><de> Nachdem die Schulbehörde uns alle mit SchulBooks ausstaffiert hatte, hätten meine Eltern mir nie und nimmer noch einen eigenen Computer gekauft, obwohl das SchulBook ja streng genommen nicht mir gehörte, und auf dem sollte ich ja keine Software installieren oder es sonstwie tunen.
<G-vec00865-002-s236><belong.gehören><en> The garden with its chestnut trees used to belong to Baden’s Müller Brewery.
<G-vec00865-002-s236><belong.gehören><de> Der Garten mit den Kastanienbäumen gehörte früher zur Badener Brauerei Müller.
<G-vec00865-002-s237><belong.gehören><en> However to their number political and sexual equality of women, since did not belong.
<G-vec00865-002-s237><belong.gehören><de> Jedoch gehörte zu ihrer Zahl die politische und sexuelle Gleichberechtigung der Frauen, da nicht.
<G-vec00865-002-s238><belong.gehören><en> As far back as I can remember, I had always felt certain that I was dreaming and did not belong to this world, and that I would wake up soon.
<G-vec00865-002-s238><belong.gehören><de> Soweit wie ich mich erinnern kann, war ich immer sicher gewesen dass ich träumte und nicht zu dieser Welt gehörte, und dass ich bald wieder aufwachen würde.
<G-vec00865-002-s239><belong.gehören><en> And for the earth (which brings the problem down to a manageable size), a miracle means the sudden appearance of something that doesn't belong to the earth – and this entry of a principle that doesn't belong to the earth as a finite world causes a radical and instant change.
<G-vec00865-002-s239><belong.gehören><de> Und für die Erde (die das Problem auf etwas sehr Verständliches reduziert) ist das plötzliche Eindringen von etwas, das nicht zur Erde gehörte, ein Wunder – eine radikale und sofortige Änderung durch das Einführen eines Prinzips, das nicht zu dieser endlichen Welt, der Erde, gehörte.
<G-vec00865-002-s241><belong.gehören><en> Since the summer, the refugees have no longer been initially received at Münster's Social Welfare Office but at Oxford Barracks, which once used to belong to the British.
<G-vec00865-002-s241><belong.gehören><de> Seit dem Sommer geschieht die Erstaufnahme der Flüchtlinge nicht mehr im Sozialamt von Münster, sondern in der Oxford-Kaserne, die einst den Briten gehörte.
<G-vec00865-002-s242><belong.gehören><en> Barry Long did not belong to any spiritual tradition.
<G-vec00865-002-s242><belong.gehören><de> Barry Long gehörte keiner spirituellen Tradition an.
<G-vec00865-002-s243><belong.gehören><en> Belgium used to belong to the countries in Europe with a very conservative attitude towards gays until the mid-1990s and then became one of the most progressive countries regarding gay rights within only 10 years.
<G-vec00865-002-s243><belong.gehören><de> Belgien gehörte bis in die 1990er Jahre zu den Ländern in Europa mit einer sehr konservativen Einstellung gegenüber Schwulen und wandelte sich innerhalb von zehn Jahren zu einem der fortschrittlichsten Länder hinsichtlich der Rechte von Homosexuellen.
<G-vec00865-002-s275><belong.hingehören><en> New HEAD KERS technology originates from the Formula 1 world and puts HEAD skiers exactly where they belong: in pole position.
<G-vec00865-002-s275><belong.hingehören><de> Die neue HEAD KERS Technologie entstammt der Formel-1 und setzt HEAD Fahrer da hin, wo sie hingehören: in die Pole Position.
<G-vec00865-002-s276><belong.hingehören><en> "Today we find lightweight carrier bags everywhere, especially where they don't belong – caught up in trees or discarded along beaches.
<G-vec00865-002-s276><belong.hingehören><de> Diese leichten Tragtaschen finden wir heute auf Schritt und Tritt, und vor allem da, wo sie nicht hingehören: in Bäumen verheddert oder an Stränden weggeworfen.
<G-vec00865-002-s277><belong.hingehören><en> Put Mummy and Father back in the ground where they belong.
<G-vec00865-002-s277><belong.hingehören><de> Schicke Mami und Vater sofort wieder unter die Erde, wo sie hingehören.
<G-vec00865-002-s278><belong.hingehören><en> PROFILE: I would be worried that my data would end up somewhere it doesnʹt belong.
<G-vec00865-002-s278><belong.hingehören><de> PROFILE: Also ich hätte Angst davor, dass meine Daten irgendwo landen, wo sie nicht hingehören.
<G-vec00865-002-s279><belong.hingehören><en> You also get a team of professional translators who know the meaning of discretion, keeping your secrets where they belong -with you.
<G-vec00865-002-s279><belong.hingehören><de> Sie erhalten auch ein Team von professionellen Übersetzern, die wissen, was Diskretion heißt, und Ihre Geheimnisse dort behalten, wo Sie hingehören – bei Ihnen.
<G-vec00865-002-s280><belong.hingehören><en> If you are not having fun yourself, you do not belong there.
<G-vec00865-002-s280><belong.hingehören><de> Wenn Sie nicht mit sich machen Spaß, müssen Sie nicht dort hingehören.
<G-vec00865-002-s281><belong.hingehören><en> After this, the prolapsed haemorrhoid knots will be uplifted and fixed where they belong to and do not disturb.
<G-vec00865-002-s281><belong.hingehören><de> Anschließend werden die vorgefallenen Hämorrhoidenknoten hochgezogen und dort fixiert, wo sie hingehören und nicht stören.
<G-vec00865-002-s282><belong.hingehören><en> A place where people feel they belong.
<G-vec00865-002-s282><belong.hingehören><de> Einen Ort, an dem Menschen fühlen, daß sie hingehören.
<G-vec00865-002-s283><belong.hingehören><en> Because the KKE and the workers’ movement are the only ones who can send the looters, murderers, Nazis of Golden Dawn where they belong; to the trashcan of history next to their idols, Hitler, Mussolini, Metaxas and Papadopoulos.
<G-vec00865-002-s283><belong.hingehören><de> Die KKE und die Arbeiterbewegung sind die einzigen, die die Mörderbanden der Chrysi-Avgi-Nazis dorthin schicken können, wo sie hingehören: in den Mülleimer der Geschichte neben ihre Idole, Hitler, Mussolini, Metaxas und Papadopoulos.
<G-vec00865-002-s284><belong.hingehören><en> Ask such people what they really do own in life and if they really belong where they are and you will receive some surprising answers.
<G-vec00865-002-s284><belong.hingehören><de> Fragen Sie solche Menschen, was ihnen im Leben wirklich gehört und ob sie wirklich dort hingehören, wo sie sind, und Sie werden einige überraschende Antworten bekommen.
<G-vec00865-002-s285><belong.hingehören><en> Across the entire life cycle of our products, we swiftly and reliably ensure that the aircraft of our customers are where they belong - in the air.
<G-vec00865-002-s285><belong.hingehören><de> Wir sorgen zuverlässig und rasch über den gesamten Life Cycle, dass die Flugzeuge unserer Kunden dort sind, wo sie hingehören: in die Luft.
<G-vec00865-002-s286><belong.hingehören><en> Effective theft protection where it matters means your wheels and seatpost stay exactly where they belong.
<G-vec00865-002-s286><belong.hingehören><de> Die effektive Diebstahlsicherung hält Laufräder und Sattelstütze dort, wo sie hingehören.
<G-vec00865-002-s287><belong.hingehören><en> DO put things back where they belong — in any part of the house.
<G-vec00865-002-s287><belong.hingehören><de> Legen Sie die Dinge wieder da, wo sie hingehören – in einem Teil des Hauses.
<G-vec00865-002-s288><belong.hingehören><en> The built-in anti-insect net on the MET Elfo and Genio keeps bugs and other small bits and pieces outside the helmet, where they belong.
<G-vec00865-002-s288><belong.hingehören><de> Das im MET Elfo und Genio eingebaute Insektenschutznetz sorgt dafür, dass Insekten und andere kleine Teile dort bleiben, wo sie hingehören - Außerhalb des Helmes.
<G-vec00865-002-s289><belong.hingehören><en> Belly tops and bikinis belong where they belong – on the beach.
<G-vec00865-002-s289><belong.hingehören><de> Bauchfreie Oberteile und Bikinis gehören dahin, wo sie hingehören – an den Strand.
<G-vec00865-002-s290><belong.hingehören><en> 5And He leads them gently home again, where they belong.
<G-vec00865-002-s290><belong.hingehören><de> 5Und er führt sie wieder sanft nach Hause, wo sie hingehören.
<G-vec00865-002-s291><belong.hingehören><en> Love lift us up where we belong,
<G-vec00865-002-s291><belong.hingehören><de> Die Liebe hebt uns dorthin, wo wir hingehören.
<G-vec00865-002-s292><belong.hingehören><en> Rotate to view an area, and Maps keeps the names of streets and places where they belong.
<G-vec00865-002-s292><belong.hingehören><de> Und schaust du dir einen Bereich mit den Gesten für Rotieren oder Neigen genauer an, bleiben die Namen von Straßen und Orten da, wo sie hingehören.
<G-vec00865-002-s293><belong.hingehören><en> But, after a short while one starts appreciating this well balance sound with highlights only where they belong.
<G-vec00865-002-s293><belong.hingehören><de> Nach kurzer Zeit weiß man die Ausgewogenheit jedoch zu schätzen, denn sie setzt nur dort Glanzlichter, wo sie auch hingehören.
<G-vec00865-002-s084><belong.miteinbeziehen><en> The First images of the women belong to the Paleolithic era, at that time, the first statues of stone.
<G-vec00865-002-s084><belong.miteinbeziehen><de> Die Ersten Bilder von Frauen beziehen sich auf die Altsteinzeit, gerade in dieser Zeit erschienen die ersten Figuren aus Stein.
<G-vec00865-002-s085><belong.miteinbeziehen><en> Synopsis Obra may belong to another edition of this title.
<G-vec00865-002-s085><belong.miteinbeziehen><de> „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s086><belong.miteinbeziehen><en> Text: Welsh "About this title" may belong to another edition of this title.
<G-vec00865-002-s086><belong.miteinbeziehen><de> Inhaltsangabe: Henry „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s087><belong.miteinbeziehen><en> trade paperback "synopsis" may belong to another edition of this title.
<G-vec00865-002-s087><belong.miteinbeziehen><de> Brand „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s088><belong.miteinbeziehen><en> "synopsis" may belong to another edition of this title.
<G-vec00865-002-s088><belong.miteinbeziehen><de> Inhaltsangabe: Echoes „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s089><belong.miteinbeziehen><en> solid copy "synopsis" may belong to another edition of this title.
<G-vec00865-002-s089><belong.miteinbeziehen><de> Inhaltsangabe: „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s091><belong.miteinbeziehen><en> "synopsis" may belong to another edition of this title.
<G-vec00865-002-s091><belong.miteinbeziehen><de> Inhaltsangabe: Handbook „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s092><belong.miteinbeziehen><en> Synopsis The Flight of Ikaros: Travels in Greece During a Civil War (Travel Library) "synopsis" may belong to another edition of this title.
<G-vec00865-002-s092><belong.miteinbeziehen><de> Inhaltsangabe: The Flight of Ikaros: Travels in Greece During a Civil War (Travel Library) „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s093><belong.miteinbeziehen><en> "synopsis" may belong to another edition of this title.
<G-vec00865-002-s093><belong.miteinbeziehen><de> Titel: „Über diesen Titel“ kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s094><belong.miteinbeziehen><en> View all copies of this belong to another edition of this title.
<G-vec00865-002-s094><belong.miteinbeziehen><de> Die Inhaltsangabe kann sich auf eine andere Ausgabe dieses Titels beziehen.
<G-vec00865-002-s099><belong.miteinbeziehen><en> Both verbs belong to different people (“Asked” — to the Pope, and “Raise” — Lena).
<G-vec00865-002-s099><belong.miteinbeziehen><de> Beide Verben beziehen sich auf die verschiedenen Menschen („Bat» ä an den Papst und „Heben» ä an Lena).
