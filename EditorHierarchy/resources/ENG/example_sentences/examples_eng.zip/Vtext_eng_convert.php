<G-vec00030-002-s741><convert.wechseln><en> The exchange offices listed on this page allow you to convert Adv Cash EUR to Bank Card EUR.
<G-vec00030-002-s741><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Adv Cash EUR in Bank Card EUR zu wechseln.
<G-vec00030-002-s742><convert.wechseln><en> If you want to convert Adv Cash EUR to Perfect Money EUR with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00030-002-s742><convert.wechseln><de> Wenn Sie Adv Cash EUR in Perfect Money USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00030-002-s743><convert.wechseln><en> The exchange offices listed on this page allow you to convert Adv Cash EUR to Skrill USD.
<G-vec00030-002-s743><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Adv Cash EUR in Skrill USD zu wechseln.
<G-vec00030-002-s744><convert.wechseln><en> If you convert to a Server Core installation, Windows features, server roles, and GUI management tools that require a Server with a GUI installation will be uninstalled automatically.
<G-vec00030-002-s744><convert.wechseln><de> Wenn Sie zu einer Server Core-Installation wechseln, werden die Windows-Features, Serverrollen und GUI-Verwaltungstools, für die eine Serverinstallation mit grafischer Benutzeroberfläche erforderlich ist, automatisch entfernt.
<G-vec00030-002-s745><convert.wechseln><en> The exchange offices listed on this page allow you to convert Neteller EUR to Bank Card EUR.
<G-vec00030-002-s745><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Perfect Money EUR in Bank Card EUR zu wechseln.
<G-vec00030-002-s746><convert.wechseln><en> The exchange offices listed on this page allow you to convert Payeer USD to Bank Card EUR.
<G-vec00030-002-s746><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Payeer USD in Bank Card EUR zu wechseln.
<G-vec00030-002-s747><convert.wechseln><en> If you want to convert Adv Cash USD to Ethereum Classic with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00030-002-s747><convert.wechseln><de> Wenn Sie Adv Cash USD in Ethereum Classic mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00030-002-s748><convert.wechseln><en> The exchange offices listed on this page allow you to convert NEO to Litecoin.
<G-vec00030-002-s748><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, NEO in Litecoin zu wechseln.
<G-vec00030-002-s749><convert.wechseln><en> If you want to convert Stellar to Solid Trust Pay USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00030-002-s749><convert.wechseln><de> Wenn Sie Stellar in Solid Trust Pay USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00030-002-s750><convert.wechseln><en> The exchange offices listed on this page allow you to convert Payeer EUR to NEO.
<G-vec00030-002-s750><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Payeer EUR in NEO zu wechseln.
<G-vec00030-002-s751><convert.wechseln><en> The exchange offices listed on this page allow you to convert Neteller EUR to Adv Cash USD.
<G-vec00030-002-s751><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Perfect Money EUR in Adv Cash USD zu wechseln.
<G-vec00030-002-s752><convert.wechseln><en> If you want to convert Dash to WMZ with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00030-002-s752><convert.wechseln><de> Wenn Sie Dash in WMZ mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00030-002-s753><convert.wechseln><en> The exchange offices listed on this page allow you to convert Ripple to Ethereum Classic.
<G-vec00030-002-s753><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Ripple in Ethereum Classic zu wechseln.
<G-vec00030-002-s754><convert.wechseln><en> The exchange offices listed on this page allow you to convert Neteller USD to SEPA EUR.
<G-vec00030-002-s754><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Neteller USD in Perfect Money EUR zu wechseln.
<G-vec00030-002-s755><convert.wechseln><en> The exchange offices listed on this page allow you to convert Bitcoin Cash to Ethereum.
<G-vec00030-002-s755><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Bitcoin Cash in Ethereum zu wechseln.
<G-vec00030-002-s756><convert.wechseln><en> The exchange offices listed on this page allow you to convert Wire Transfer GBP to Perfect Money EUR.
<G-vec00030-002-s756><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Wire Transfer GBP in Perfect Money USD zu wechseln.
<G-vec00030-002-s757><convert.wechseln><en> If you want to convert MoneyGram USD to PayPal USD with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00030-002-s757><convert.wechseln><de> Wenn Sie MoneyGram USD in PayPal USD mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00030-002-s758><convert.wechseln><en> If you want to convert Ripple to Bitcoin with an additional discount, register as client of the respective site after you navigate to it using our link.
<G-vec00030-002-s758><convert.wechseln><de> Wenn Sie Ripple in Bitcoin mit einem zusätzlichen Rabatt wechseln möchten, melden Sie sich als Kunde der jeweiligen Website an, nachdem Sie diese über unseren Link aufgerufen haben.
<G-vec00030-002-s759><convert.wechseln><en> The exchange offices listed on this page allow you to convert Yandex Money to Dash.
<G-vec00030-002-s759><convert.wechseln><de> Die Wechselbüros, die auf dieser Seite aufgelistet sind, ermöglichen es Ihnen, Yandex Money in Dash zu wechseln.
<G-vec01132-002-s190><convert.konvertieren><en> When you convert paragraph text to point text, all characters outside the bounding box are deleted.
<G-vec01132-002-s190><convert.konvertieren><de> Sie können Punkttext in Absatztext konvertieren, um den Zeichenfluss innerhalb eines Begrenzungsrahmens einzustellen.
<G-vec01132-002-s191><convert.konvertieren><en> Before starting copying iTunes M4P and Apple Music songs to Huawei, ripping the DRM protection and convert these music the format supported by Huawei Mate 10 are required.
<G-vec01132-002-s191><convert.konvertieren><de> Bevor Sie mit dem Kopieren von iTunes M4P und Apple Music Songs auf Huawei beginnen, müssen Sie den DRM-Schutz kopieren und diese Musik in das von Huawei Mate 10 unterstützte Format konvertieren.
<G-vec01132-002-s192><convert.konvertieren><en> If you are going to convert the RPMSG to EML file, you must have the appropriate software.
<G-vec01132-002-s192><convert.konvertieren><de> Wenn Sie vorhaben, die Datei STD in SXD zu konvertieren, müssen Sie eine entsprechende Software besitzen.
<G-vec01132-002-s193><convert.konvertieren><en> And, just like MJML, it has custom tags that will automatically convert to HTML when it’s compiled.
<G-vec01132-002-s193><convert.konvertieren><de> Und genau wie MJML, es hat benutzerdefinierte tags, die automatisch in HTML konvertieren, wenn es kompiliert.
<G-vec01132-002-s194><convert.konvertieren><en> Note:You'll need to be connected to the internet to open ODF files and convert them to OOXML files.
<G-vec01132-002-s194><convert.konvertieren><de> Hinweis: Damit Sie ODF-Dateien öffnen und in OOXML-Dateien konvertieren können, muss eine Internetverbindung bestehen.
<G-vec01132-002-s195><convert.konvertieren><en> If, find your CDI file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s195><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei CDI konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format BIN zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s196><convert.konvertieren><en> Therefore, our task is to convert data provided in a random order and different formats into the required format.
<G-vec01132-002-s196><convert.konvertieren><de> Daher ist es unsere Aufgabe, die in zufälliger Reihenfolge und in verschiedenen Formaten bereitgestellten Daten in das gewünschte Format zu konvertieren.
<G-vec01132-002-s197><convert.konvertieren><en> To convert YouTube videos to WMV you will need a quality software that can handle the task of not only effectively download the videos but also efficiently convert it to WMV format.
<G-vec01132-002-s197><convert.konvertieren><de> Um YouTube-Videos in WMV zu konvertieren, benötigen Sie eine hochwertige Software, das kann die Aufgabe übernehmen, nicht nur die Videos effektiv zu herunterladen aber auch effizient in das WMV-Format konvertieren.
<G-vec01132-002-s198><convert.konvertieren><en> Open damaged, corrupted and inaccessible OST file and convert to PST file to recover Exchange mailbox folders easily.
<G-vec01132-002-s198><convert.konvertieren><de> Beschädigte oder unzugängliche OST-Datei mit OST2 Konverter öffnen und in PST-Datei konvertieren, um Postfach-Ordner von Exchange wiederherzustellen.
<G-vec01132-002-s199><convert.konvertieren><en> Home users can perform complicated partition operations by using this powerful but free partition manager to manage their hard disk partition such as Resizing partitions, Copying partitions, Create partition, Delete partition, Format partition, Convert partition, Explore partition, Hide partition, Change drive letter, Set active partition, Convert Dynamic Disk to Basic Disk, Surface Test, Change Partition Serial Number, Change Partition Type ID and Partition Recovery.
<G-vec01132-002-s199><convert.konvertieren><de> Privatbenutzer können mit diesem starken und dabei kostenlosen Partitionsmanager komplexe Partitionsvorgänge zur Verwaltung ihrer Festplattenpartition durchführen, beispielsweise eine Veränderung der Partitionsgröße, die Kopie von Partitionen, eine Partition erstellen, löschen, formatieren, konvertieren, erkunden und verstecken, den Laufwerkbuchstaben ändern, eine aktive Partition einrichten, einen dynamischen in einen Basisdatenträger konvertieren, einen Oberflächentest durchführen, die Seriennummer der Partition ändern, die Typ-ID dieser Partition ändern und eine Partition wiederherstellen.
<G-vec01132-002-s200><convert.konvertieren><en> This software can convert existing 2D-videos automatically into the third dimension.
<G-vec01132-002-s200><convert.konvertieren><de> Sie ist dazu in der Lage, 2D-Videos automatisch in die dritte Dimension zu konvertieren.
<G-vec01132-002-s201><convert.konvertieren><en> Miro Video Converter can convert your video files to mobile format quickly and without any fuss.
<G-vec01132-002-s201><convert.konvertieren><de> Miro Video Converter kann Ihre Videodateien schnell und ohne viel Aufwand in ein mobiles Format konvertieren.
<G-vec01132-002-s202><convert.konvertieren><en> Click CONVERT button to remove DRM and convert these files to plain format without losing original quality.
<G-vec01132-002-s202><convert.konvertieren><de> Klicken Sie auf der Schaltfläche "Konvertieren", um DRM zu entfernen und diese Audio-Datei in MP3-Format ohne Verlust der Qualität zu konvertieren.
<G-vec01132-002-s203><convert.konvertieren><en> Convert a PDF to Word in a couple of clicks – so you can start editing right away and increase your personal productivity.
<G-vec01132-002-s203><convert.konvertieren><de> In drei einfachen Schritten können Sie ein PDF in ein Excel-Dokument konvertieren und direkt daran arbeiten.
<G-vec01132-002-s204><convert.konvertieren><en> To drop the mirror database, you must first convert it to a scale-out database copy.
<G-vec01132-002-s204><convert.konvertieren><de> Um die Spiegeldatenbank löschen zu können, müssen Sie sie zunächst in eine Scale-Out-Datenbankkopie konvertieren.
<G-vec01132-002-s205><convert.konvertieren><en> To effectively convert MP3 to OGG format, you will need a powerful and professional converter software.
<G-vec01132-002-s205><convert.konvertieren><de> Um MP3 effektiv in das OGG-Format zu konvertieren, benötigen Sie eine leistungsstarke und professionelle Konvertersoftware.
<G-vec01132-002-s206><convert.konvertieren><en> To convert only one instance of the footage item, select the layer in the Timeline panel, and choose Layer > Convert To Layered Comp.
<G-vec01132-002-s206><convert.konvertieren><de> Wenn Sie nur eine Instanz des Footageelements konvertieren möchten, wählen Sie die Ebene im Zeitleistenfenster aus und klicken Sie dann auf „Ebene“ > „In Komposition mit Ebenen konvertieren“.
<G-vec01132-002-s207><convert.konvertieren><en> When edited using PlayMemories Home or Premiere Pro CC with Video Edit Components (optional plug-in software), you can convert 4K video to XAVC S format, playable using Sony's XAVC S compatible camera.
<G-vec01132-002-s207><convert.konvertieren><de> Nach der Bearbeitung mit PlayMemories Home oder Premiere Pro CC mit Video Edit Components (optionale Plugin-Software) können Sie 4K-Videos in das XAVC S-Format konvertieren, das mit der XAVC S-kompatiblen Kamera von Sony abspielbar ist.
<G-vec01132-002-s208><convert.konvertieren><en> If you are going to convert the XVID to DIVX file, you must have the appropriate software.
<G-vec01132-002-s208><convert.konvertieren><de> Wenn Sie vorhaben, die Datei DIVX in XVID zu konvertieren, müssen Sie eine entsprechende Software besitzen.
<G-vec01132-002-s228><convert.konvertieren><en> How to Rip and Convert DVD to PS3: Step 2> Insert the DVD into your optical drive, and DVDFab will load the content on the DVD automatically.
<G-vec01132-002-s228><convert.konvertieren><de> Wie rippe und konvertiere ich DVD zu WMV mit dem DVD to WMV Ripper: Schritt 2 > Legen Sie eine DVD in das optische Laufwerk ein und DVDFab wird den Inhalt der DVD automatisch laden.
<G-vec01132-002-s229><convert.konvertieren><en> Convert blog readers into leads and signups.
<G-vec01132-002-s229><convert.konvertieren><de> Konvertiere Blog-Leser in Leads und Anmeldungen.
<G-vec01132-002-s230><convert.konvertieren><en> Step 4 Convert MOV to MP4 with FFmpeg alternative
<G-vec01132-002-s230><convert.konvertieren><de> Schritt 4 Konvertiere MOV zu MP4.
<G-vec01132-002-s231><convert.konvertieren><en> Convert 1,000 paces to kilometer (pace to km).
<G-vec01132-002-s231><convert.konvertieren><de> Konvertiere 8 Schritte in km (pace in Kilometer).
<G-vec01132-002-s232><convert.konvertieren><en> If you would like to add a favicon for your desktop platform, convert any image into a favicon by using a favicon generator (search in Google) and save it to your computer.
<G-vec01132-002-s232><convert.konvertieren><de> Wenn du ein Favicon zu deiner Desktop-Plattform hinzufügen möchtest, konvertiere ein Bild mithilfe eines Favicon Generators (suche bei Google) in ein Favicon und speichere es auf deinem Computer.
<G-vec01132-002-s233><convert.konvertieren><en> Convert media files easily with Permute.
<G-vec01132-002-s233><convert.konvertieren><de> Konvertiere deine Mediendateien in das von dir benötigte Streaming-Format.
<G-vec01132-002-s234><convert.konvertieren><en> Convert your images from your mobile phone into a PDF file.
<G-vec01132-002-s234><convert.konvertieren><de> Konvertiere deine Bilder in ein PDF.
<G-vec01132-002-s235><convert.konvertieren><en> Convert 30 cm3 to m3 (cubic centimeters to cubic meters).
<G-vec01132-002-s235><convert.konvertieren><de> Konvertiere 459 hm3 in m3 (Kubikhektometer in Kubikmeter).
<G-vec01132-002-s236><convert.konvertieren><en> How to Convert DVD with DVDFab DVD Ripper: Step 4 > Now you can choose the titles, chapters, audio tracks and subtitles, define the names of the titles, and do advanced settings according to your needs.
<G-vec01132-002-s236><convert.konvertieren><de> Wie konvertiere ich DVD mit dem DVDFab DVD Ripper: Schritt 4 > Jetzt können Sie die Titel, Kapitel, Audiospuren und Untertitel auswählen, den Namen des Titels festlegen und weitere Einstellungen nach Ihren Wünschen vornehmen.
<G-vec01132-002-s237><convert.konvertieren><en> Then convert it to CMYK color mode and save it as a .psd file.
<G-vec01132-002-s237><convert.konvertieren><de> Konvertiere es dann zu CMYK und speichere es als .psd.
<G-vec01132-002-s238><convert.konvertieren><en> Click Convert to VM:
<G-vec01132-002-s238><convert.konvertieren><de> Klicken Sie auf Konvertiere zu VM.
<G-vec01132-002-s239><convert.konvertieren><en> Convert m2 to hm2 (square meter to square hectometer).
<G-vec01132-002-s239><convert.konvertieren><de> Konvertiere 9 m2 in hm2 (Quadratmeter in Quadrathektometer).
<G-vec01132-002-s240><convert.konvertieren><en> How to Rip and Convert DVD to Cell Phone with DVD to Cell Phone Ripper:Step 5 > Click the "folder" button to select a directory to save the output video.
<G-vec01132-002-s240><convert.konvertieren><de> Wie rippe und konvertiere ich DVD zu WMV mit dem DVD to WMV Ripper: Schritt 5 > Klicken Sie auf die „Ordner“ Taste und wählen ein Verzeichnis zum Speichern des Ausgabevideos aus.
<G-vec01132-002-s241><convert.konvertieren><en> How to Rip and Convert DVD to DivX/XviD with DVD to DivX/XviD Ripper:Step 2> Insert the DVD into your optical drive, and DVDFab will load the content on the DVD automatically.
<G-vec01132-002-s241><convert.konvertieren><de> Wie rippe und konvertiere ich DVD zu PVP mit dem DVD to PVP Ripper: Schritt 2 > Legen Sie eine DVD in das optische Laufwerk ein und DVDFab wird den Inhalt der DVD automatisch laden.
<G-vec01132-002-s242><convert.konvertieren><en> Edit and convert PDF files online in your browser.
<G-vec01132-002-s242><convert.konvertieren><de> Bearbeite und konvertiere PDF Dateien online in Deinem Browser.
<G-vec01132-002-s244><convert.konvertieren><en> How to Rip and Convert DVD to Xbox 360: Step 5> Click the "folder" button to select a directory to save the output video.
<G-vec01132-002-s244><convert.konvertieren><de> Wie konvertiere ich DVD mit dem DVDFab DVD Ripper: Schritt 5 > Klicken Sie auf die „Ordner“ Taste und wählen ein Verzeichnis zum Speichern des Ausgabevideos aus.
<G-vec01132-002-s245><convert.konvertieren><en> Or, select all and convert them in a batch.
<G-vec01132-002-s245><convert.konvertieren><de> Oder wähle alle aus und konvertiere sie in einer Charge.
<G-vec01132-002-s246><convert.konvertieren><en> TIP: The best file types for Facebook cover videos are MP4 and MOV – if your video is in a different format, convert it using Clipchamp.
<G-vec01132-002-s246><convert.konvertieren><de> TIPP: Die besten Dateitypen für Facebook-Cover-Videos sind MP4 und MOV – wenn dein Video in einem anderen Format vorliegt, konvertiere es mit Clipchamp.
<G-vec01132-002-s247><convert.konvertieren><en> You can use our software Contenta Converter PREMIUM to convert thousands of SR2 to black and white.
<G-vec01132-002-s247><convert.konvertieren><de> Antwort Sie können unsere Software Contenta Converter PREMIUM verwenden, um Tausende von SR2 zu PNG zu konvertieren.
<G-vec01132-002-s248><convert.konvertieren><en> All you need to do is to burn your playlist with iTunes to TuneClone's virtual CD Burner, and TuneClone will convert music files in the playlist to MP3, WMA or WAV files automatically. TuneClone Features
<G-vec01132-002-s248><convert.konvertieren><de> Was Sie machen brauchen, ist nur, Ihre Playliste mit Ihrer Media Player Software auf dem TuneClone´s virtuellen CD Brenner zu brennen, und TuneClone wird Musikfiles in der Playliste in MP3, unbeschützten WMA- oder WAV-Files automatisch konvertieren.
<G-vec01132-002-s249><convert.konvertieren><en> Click the Convert button at the lower-right bottom to start converting WMA files to the compatible format for your iOS device.
<G-vec01132-002-s249><convert.konvertieren><de> Klicken Sie nun auf die Konvertieren - Schaltfläche unten rechts im Programmfenster, um die Konvertierung von WMA in MP3-Dateien zu starten.
<G-vec01132-002-s250><convert.konvertieren><en> Another interesting feature is the ability to create, convert and extract multiple archives at once, which makes this application a real candidate for the best archiving utility on UNIX/Linux operating systems.
<G-vec01132-002-s250><convert.konvertieren><de> Ein weiteres interessantes Feature ist die Möglichkeit, mehrere Archive gleichzeitig zu erstellen, zu konvertieren und zu extrahieren, was diese Anwendung zu einem echten Kandidaten für das beste Archivierungsprogramm auf UNIX / Linux-Betriebssystemen macht.
<G-vec01132-002-s251><convert.konvertieren><en> Below is a list of programs that will convert the file XML to PDF.
<G-vec01132-002-s251><convert.konvertieren><de> Unten finden Sie eine Liste der Programme, die die Datei XML in PDF konvertieren.
<G-vec01132-002-s252><convert.konvertieren><en> It can convert .aa and .aax audiobooks to MP3/AAC/FLAC/WAV at lightning speed with lossless quality.
<G-vec01132-002-s252><convert.konvertieren><de> Es kann Benutzer helfen, DRM-Ed Apple Musik-Dateien, M4A/M4B/AA/AAX Hörbücher und M4P Songs zu normalen MP3/AAC/WAV mit 20X schneller Geschwindigkeit und verlustfreier Qualität zu konvertieren.
<G-vec01132-002-s253><convert.konvertieren><en> Click on Norwegian Krone or Mexican Peso to convert between that currency and all the other currencies.
<G-vec01132-002-s253><convert.konvertieren><de> Klicken Sie auf Norwegische Krone oder Mexikanischer Peso, um zwischen dieser Währung und allen anderen Währungen zu konvertieren.
<G-vec01132-002-s254><convert.konvertieren><en> The differences between these two applications can make it difficult to convert one of the file formats to the other.
<G-vec01132-002-s254><convert.konvertieren><de> Die Unterschiede zwischen diesen beiden Anwendungen kann es schwierig machen, eine der Dateiformate zum anderen zu konvertieren.
<G-vec01132-002-s255><convert.konvertieren><en> Optimized Presets: Directly convert files to fit Apple devices and Android devices.
<G-vec01132-002-s255><convert.konvertieren><de> Optimierte Voreinstellungen: Direkt Dateien zu Apple-Geräten konvertieren und Android-Geräte anzupassen.
<G-vec01132-002-s256><convert.konvertieren><en> You can also convert Powerpoint and Excel to PDF.
<G-vec01132-002-s256><convert.konvertieren><de> Außerdem lassen sich damit Powerpoint- und Excel-Dateien in PDF konvertieren.
<G-vec01132-002-s257><convert.konvertieren><en> Click the Convert All button at the lower-right bottom of the software window to start M2TS to AVI conversion.
<G-vec01132-002-s257><convert.konvertieren><de> Klicken Sie unten im Softwarefenster auf den Alle konvertieren -Knopf, um mit der M2TS zu AVI-Konvertierung zu beginnen.
<G-vec01132-002-s258><convert.konvertieren><en> Select the document you want to convert.
<G-vec01132-002-s258><convert.konvertieren><de> Wählen Sie das Dokument das Sie Konvertieren wollen.
<G-vec01132-002-s259><convert.konvertieren><en> Click the Convert button to convert WavPack/wv/wvc to wma.
<G-vec01132-002-s259><convert.konvertieren><de> Klicken Sie auf die Schaltfläche Konvertieren zu WavPack konvertieren / WV / WVC in wma.
<G-vec01132-002-s261><convert.konvertieren><en> But Reza was lacking the courage to convert publicly, fearing presecution from the Islamic state and even his family.
<G-vec01132-002-s261><convert.konvertieren><de> Aber es fehlte Reza der Mut, öffentlich zu konvertieren, da er eine Verfolgung durch den islamischen Staat und sogar seine eigene Familie befürchtete.
<G-vec01132-002-s262><convert.konvertieren><en> Furthermore, it is technically impossible to convert these templates 1:1, because the new system is built differently.
<G-vec01132-002-s262><convert.konvertieren><de> Außerdem ist es technisch nicht möglich, diese Vorlagen 1:1 zu konvertieren, weil das neue System anders aufgebaut ist.
<G-vec01132-002-s263><convert.konvertieren><en> Example: You want to convert 5 barrels into litres.
<G-vec01132-002-s263><convert.konvertieren><de> Beispiel: Sie wollen 5 Barrel (Erdöl) in Liter konvertieren.
<G-vec01132-002-s264><convert.konvertieren><en> If you already have gINT installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the gINT).
<G-vec01132-002-s264><convert.konvertieren><de> Wenn Sie PowerFlip schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm PowerFlip öffnen kann).
<G-vec01132-002-s265><convert.konvertieren><en> Use with Xcode to convert FileMaker apps into native iOS apps. FileMaker WebDirect
<G-vec01132-002-s265><convert.konvertieren><de> Zusammen mit Xcode lassen sich FileMaker-Apps in native iOS-Apps konvertieren.
<G-vec01132-002-s285><convert.konvertieren><en> DBF to DBF Converter 2.50 Convert your DBF files from one format to another.
<G-vec01132-002-s285><convert.konvertieren><de> Konvertieren Sie Ihre DBF-Dateien von einem Format in ein anderes.
<G-vec01132-002-s286><convert.konvertieren><en> Convert DOCX to TIFF - online and free - this page also contains information on the DOCX and TIFF file extensions.
<G-vec01132-002-s286><convert.konvertieren><de> Konvertieren Sie DOCX zu TIFF - online und kostenlos - diese Seite enthält auch Information über die DOCX und TIFF Datei Erweiterungen.
<G-vec01132-002-s287><convert.konvertieren><en> Convert M3U to MP4, MOV, AVI, MKV and other 150+ video/audio formats.
<G-vec01132-002-s287><convert.konvertieren><de> Komprimieren und konvertieren Sie mehr als 1000 Videoformate, darunter MP4, MOV, AVI, MKV, WMV.
<G-vec01132-002-s288><convert.konvertieren><en> Download Dragoman Convert the batches of images, photos, music, sound and archives.
<G-vec01132-002-s288><convert.konvertieren><de> Download Dragoman Konvertieren Sie die Reihen von Bildern, Fotos, Musik, Ton und Archive .
<G-vec01132-002-s289><convert.konvertieren><en> Convert a corrupt or healthy Outlook OST to a working PST file in a simple and hassle-free way using SFWare.
<G-vec01132-002-s289><convert.konvertieren><de> Konvertieren Sie eine beschädigte oder fehlerfreie Outlook-OST-Datei mit SFWare auf einfache und problemlose Weise in eine funktionierende PST-Datei.
<G-vec01132-002-s290><convert.konvertieren><en> Or convert to MP4 for playback on your iPhone, iPad and other Apple devices.
<G-vec01132-002-s290><convert.konvertieren><de> Oder konvertieren Sie in MP4 für die Wiedergabe auf Ihrem iPhone, iPad und anderen Apple-Geräten.
<G-vec01132-002-s291><convert.konvertieren><en> Convert videos to MP4 and MKV with the H.265 codec on systems with an Intel or NVIDIA graphics card with HEVC technology support.
<G-vec01132-002-s291><convert.konvertieren><de> Konvertieren Sie Videos in MP4 und MKV mit dem H.265 Codec auf Systemen mit einer Intel- oder NVIDIA-Grafikkarte mit der Unterstützung der HEVC-Technologie.
<G-vec01132-002-s292><convert.konvertieren><en> Convert PPTX to JPG - online and free - this page also contains information on the PPTX and JPG file extensions.
<G-vec01132-002-s292><convert.konvertieren><de> Konvertieren Sie DOCX zu JPG - online und kostenlos - diese Seite enthält auch Information über die DOCX und JPG Datei Erweiterungen.
<G-vec01132-002-s293><convert.konvertieren><en> Convert your RC car, truck or buggy into a pursuit car with the Police Car LED Light Beacon.
<G-vec01132-002-s293><convert.konvertieren><de> Konvertieren Sie Ihre RC Auto, LKW oder Buggy in eine Verfolgung Auto mit der Polizei-Auto-LED-Beleuchtungssystem.
<G-vec01132-002-s294><convert.konvertieren><en> Convert PDF to images, Word, Excel, PPT, EPUB and more formats.
<G-vec01132-002-s294><convert.konvertieren><de> Konvertieren Sie PDF in Word, Excel und andere Formate.
<G-vec01132-002-s295><convert.konvertieren><en> Download and convert online videos with 90X faster speed.
<G-vec01132-002-s295><convert.konvertieren><de> Downloaden und konvertieren Sie Online Videos 90 mal schneller.
<G-vec01132-002-s296><convert.konvertieren><en> Convert BMP to PS - online and free - this page also contains information on the BMP and PS file extensions.
<G-vec01132-002-s296><convert.konvertieren><de> Konvertieren Sie DCR zu BMP - online und kostenlos - diese Seite enthält auch Information über die DCR und BMP Datei Erweiterungen.
<G-vec01132-002-s297><convert.konvertieren><en> Convert PAGES to TXT - online and free - this page also contains information on the PAGES and TXT file extensions.
<G-vec01132-002-s297><convert.konvertieren><de> Konvertieren Sie DOC zu PAGES - online und kostenlos - diese Seite enthält auch Information über die DOC und PAGES Datei Erweiterungen.
<G-vec01132-002-s298><convert.konvertieren><en> Convert EPUB to LRF - online and free - this page also contains information on the EPUB and LRF file extensions.
<G-vec01132-002-s298><convert.konvertieren><de> Konvertieren Sie EPUB zu MOBI - online und kostenlos - diese Seite enthält auch Information über die EPUB und MOBI Datei Erweiterungen.
<G-vec01132-002-s299><convert.konvertieren><en> Convert your mighty NITRO BUMBLEBEE figure from CAMARO concept vehicle mode to battle-ready robot mode.
<G-vec01132-002-s299><convert.konvertieren><de> Konvertieren Sie Ihre mächtigen NITRO BUMBLEBEE Figur aus Camaro Concept Fahrzeug-Modus, um kampfbereite Roboter-Modus.
<G-vec01132-002-s300><convert.konvertieren><en> Convert PDF to JPG - online and free - this page also contains information on the PDF and JPG file extensions.
<G-vec01132-002-s300><convert.konvertieren><de> Konvertieren Sie PDF zu JPG - online und kostenlos - diese Seite enthält auch Information über die PDF und JPG Datei Erweiterungen.
<G-vec01132-002-s301><convert.konvertieren><en> Convert MSG to DOC - online and free - this page also contains information on the MSG and DOC file extensions.
<G-vec01132-002-s301><convert.konvertieren><de> Konvertieren Sie PDF zu DOC - online und kostenlos - diese Seite enthält auch Information über die PDF und DOC Datei Erweiterungen.
<G-vec01132-002-s302><convert.konvertieren><en> Or convert to play mode and timeless period of searching for as long as your convenience.
<G-vec01132-002-s302><convert.konvertieren><de> Oder konvertieren Sie den Modus und zeitlose Zeit der Suche, so lange wie Ihre Bequemlichkeit zu spielen.
<G-vec01132-002-s303><convert.konvertieren><en> Convert MOV to WAV - online and free - this page also contains information on the MOV and WAV file extensions.
<G-vec01132-002-s303><convert.konvertieren><de> Konvertieren Sie MOV zu WAV - online und kostenlos - diese Seite enthält auch Information über die MOV und WAV Datei Erweiterungen.
<G-vec01132-002-s304><convert.konvertieren><en> Program EASE SpeakerLab may also be used to convert files between different formats.
<G-vec01132-002-s304><convert.konvertieren><de> Das Programm KWalletManager kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s305><convert.konvertieren><en> Program Kodak EasyShare Software may also be used to convert files between different formats.
<G-vec01132-002-s305><convert.konvertieren><de> Das Programm AutoImager kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s306><convert.konvertieren><en> Program InfoStat may also be used to convert files between different formats.
<G-vec01132-002-s306><convert.konvertieren><de> Das Programm UnSqueez kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s307><convert.konvertieren><en> Program Aimersoft Video Converter may also be used to convert files between different formats.
<G-vec01132-002-s307><convert.konvertieren><de> Das Programm ZVR Converter kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s308><convert.konvertieren><en> Okoker WMV to DVD VCD DIVX MPEG Converter&Burner is a professional media conversion tool that can batch convert WMV to AVI, DIVX, DVD, VCD, MPEG and Burn to DVD/CD.
<G-vec01132-002-s308><convert.konvertieren><de> DETAILS Der WMV to AVI MPEG DVD WMV Converter ist ein leistungsfähiges und wunderbares Tool für konvertieren von WMV- oder ASF-Dateien in AVI, MPEG, VCD, SVCD, DVD-Formate.
<G-vec01132-002-s309><convert.konvertieren><en> I wasn’t able to find a proper app to convert PNG files to PDF documents on my Android smartphone until I found this one.
<G-vec01132-002-s309><convert.konvertieren><de> Ich konnte keine geeignete App zum Konvertieren von PNG-Dateien in PDF-Dokumente auf meinem Android-Smartphone finden, bis ich dieses gefunden habe.
<G-vec01132-002-s310><convert.konvertieren><en> The first step on how to batch convert Word to PDF is to download PDFelement Pro.
<G-vec01132-002-s310><convert.konvertieren><de> Der erste Schritt zum konvertieren von Word in PDF ist das herunterladen von PDFelement Pro.
<G-vec01132-002-s311><convert.konvertieren><en> Program Restricted Focus Viewer may also be used to convert files between different formats.
<G-vec01132-002-s311><convert.konvertieren><de> Das Programm PSDL Viewer kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s312><convert.konvertieren><en> Program Blue Iris may also be used to convert files between different formats.
<G-vec01132-002-s312><convert.konvertieren><de> Das Programm EclipseCrossword kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s313><convert.konvertieren><en> Program Min-U-Script Xpress may also be used to convert files between different formats.
<G-vec01132-002-s313><convert.konvertieren><de> Das Programm Min-U-Script Xpress kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s314><convert.konvertieren><en> Program Hyper-V may also be used to convert files between different formats.
<G-vec01132-002-s314><convert.konvertieren><de> Das Programm Hyper-V kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s315><convert.konvertieren><en> Program Bryce may also be used to convert files between different formats.
<G-vec01132-002-s315><convert.konvertieren><de> Das Programm Bryce kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s316><convert.konvertieren><en> Program X-Wing vs. TIE Fighter may also be used to convert files between different formats.
<G-vec01132-002-s316><convert.konvertieren><de> Das Programm X-Genics eManager kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s317><convert.konvertieren><en> Program Software Update Tool LR may also be used to convert files between different formats.
<G-vec01132-002-s317><convert.konvertieren><de> .JFFS2-kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s318><convert.konvertieren><en> Program Tekla BIMsight may also be used to convert files between different formats.
<G-vec01132-002-s318><convert.konvertieren><de> Das Programm ArcSoft Print Creations kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s319><convert.konvertieren><en> Program Microsoft Winqual may also be used to convert files between different formats.
<G-vec01132-002-s319><convert.konvertieren><de> Das Programm Microsoft Winqual kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s320><convert.konvertieren><en> Program Snes9x may also be used to convert files between different formats.
<G-vec01132-002-s320><convert.konvertieren><de> Das Programm Kasemake kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s321><convert.konvertieren><en> Program Video Effects may also be used to convert files between different formats.
<G-vec01132-002-s321><convert.konvertieren><de> Das Programm C64 Forever kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s322><convert.konvertieren><en> Program Adobe PhotoDeluxe may also be used to convert files between different formats.
<G-vec01132-002-s322><convert.konvertieren><de> Das Programm Adobe Kuler kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s323><convert.konvertieren><en> The formula you see on the left will be displayed for reference, while Excel will automatically convert the formula on the right into the appropriate result.
<G-vec01132-002-s323><convert.konvertieren><de> Die Formel auf der linken Seite wird als Referenz angezeigt, während Excel die Formel rechts automatisch in das entsprechende Ergebnis konvertiert.
<G-vec01132-002-s324><convert.konvertieren><en> We have a fantastic tool to convert Djibouti time zone and calculate time difference between Djibouti and other cities.
<G-vec01132-002-s324><convert.konvertieren><de> Wir haben ein fantastisches Tool das die Los Angeleser Zeitzone konvertiert und Zeitunterschiede zwischen Los Angeles und anderen Städten berechnet.
<G-vec01132-002-s325><convert.konvertieren><en> This method will not technically “convert” an image to a JPEG.
<G-vec01132-002-s325><convert.konvertieren><de> Diese Methode konvertiert ein Bild technisch gesehen nicht in ein jpeg.
<G-vec01132-002-s326><convert.konvertieren><en> Most kinds of data and content will convert, but how you format and interact with the data and content might be different between the formats.
<G-vec01132-002-s326><convert.konvertieren><de> Die meisten Daten- und Inhaltsarten werden zwar konvertiert, doch unterscheidet sich möglicherweise die Formatierung und Interaktion mit den Daten und Inhalten bei den beiden Formaten.
<G-vec01132-002-s327><convert.konvertieren><en> In the Name field on the Modify Style dialog, type the name of the Borland style to which you want to convert this style.
<G-vec01132-002-s327><convert.konvertieren><de> Geben Sie in das Feld Name den Namen des Borland-Formats ein, in das dieses Format konvertiert werden soll.
<G-vec01132-002-s328><convert.konvertieren><en> We have a fantastic tool to convert Tunisia time zone and calculate time difference between Tunisia and other cities.
<G-vec01132-002-s328><convert.konvertieren><de> Wir haben ein fantastisches Tool das die Sowetoer Zeitzone konvertiert und Zeitunterschiede zwischen Soweto und anderen Städten berechnet.
<G-vec01132-002-s329><convert.konvertieren><en> No more waiting for the tech guys to convert yet another product feed.
<G-vec01132-002-s329><convert.konvertieren><de> Kein Warten mehr, bis die Techniker einen weiteren Daten-Feed konvertiert haben.
<G-vec01132-002-s330><convert.konvertieren><en> Convert H.264 videos to various formats, such as MP4, AVI, MOV, FLV, VOB, 3GP, WMV, MKV, M4V, etc.
<G-vec01132-002-s330><convert.konvertieren><de> Konvertiert H.264 Videos in verschiedene Formate, wie MP4, AVI, FLV, VOB, 3GP, WMV, MKV, M4V usw.
<G-vec01132-002-s331><convert.konvertieren><en> The following tool will convert your entered text into images using Alias Font, and then you can right-click on the image to save it to embed image in forum posts
<G-vec01132-002-s331><convert.konvertieren><de> Das folgende Tool konvertiert den von Ihnen eingegebenen Text zu Bildern oder Logos, die Sie durch Rechtsklick auf das Bild herunterladen können.
<G-vec01132-002-s332><convert.konvertieren><en> When desired, you can choose to convert any placed asset into an embedded asset by choosing the Embed Link option.
<G-vec01132-002-s332><convert.konvertieren><de> Bei Bedarf können Sie festlegen, dass jedes platzierte Element in ein eingebettetes Element konvertiert wird, indem Sie die Option „Link einbetten“ auswählen.
<G-vec01132-002-s333><convert.konvertieren><en> How to Convert MKV to AVI Using DVDFab Video Converter
<G-vec01132-002-s333><convert.konvertieren><de> Hier ist ein Tipp, wie man Videos mit DVDFab zu MKV Videos konvertiert.
<G-vec01132-002-s334><convert.konvertieren><en> Here I'll show you how to convert AVCHD files on Mac using UniConverter for Mac.
<G-vec01132-002-s334><convert.konvertieren><de> Hier zeige ich Ihnen wie man AVCHD Dateien auf Mac mit iSkysoft UniConverter für Mac konvertiert.
<G-vec01132-002-s335><convert.konvertieren><en> Convert 3D Blu-ray to 3D M2TS Video > Step 5: Click the “Edit” button at the top right corner of Operation Window if you want to customize the resulting 3D video.
<G-vec01132-002-s335><convert.konvertieren><de> Konvertiert 3D Blu-rays zu 3D Videos auf Mac > Schritt 5: Klicken Sie auf „Bearbeiten“ am oberen Rand der Hauptoberfläche, wenn Sie das resultierende 3D Video anpassen wollen.
<G-vec01132-002-s336><convert.konvertieren><en> With the freeware DoubleTwist you can manage your songs and videos on your computer and sync it with your portable player or smartphone. The software is able to read following input formats: MP4, WMV, AVI, MPG, 3GP video files as well as MP3, AAC, WMA or WAV audio files and pictures in JPG, GIF, PNG or BMP fomrat and convert them, so you can use it on your mobile player or mobile phone.
<G-vec01132-002-s336><convert.konvertieren><de> Mit der kostenlosen Software DoubleTwist verwalten Sie Ihre Songs und Videos auf dem Computer und synchronisieren diese MP3-, AAC-, WMA oder WAV-Audiofiles oder Bilder in den Formaten JPG, GIF, PNG oder BMP und konvertiert diese so um dass Sie diese auf dem mobilen Player oder Smartphone nutzen können.
<G-vec01132-002-s337><convert.konvertieren><en> We have a fantastic tool to convert Neuquen time zone and calculate time difference between Neuquen and other cities.
<G-vec01132-002-s337><convert.konvertieren><de> Wir haben ein fantastisches Tool das die Aigaleoer Zeitzone konvertiert und Zeitunterschiede zwischen Aigaleo und anderen Städten berechnet.
<G-vec01132-002-s338><convert.konvertieren><en> When buying from a seller who lists in a currency other than your browsing currency, Etsy will convert the listing price for you.
<G-vec01132-002-s338><convert.konvertieren><de> Wenn du bei einem Verkäufer einkaufst, der seine Artikel in einer anderen Währung einstellt als derjenigen, in der du stöberst, konvertiert Etsy den Artikelpreis für dich.
<G-vec01132-002-s339><convert.konvertieren><en> After going all out with webPDF in early 2020, we are now using this solution to convert all emails.
<G-vec01132-002-s339><convert.konvertieren><de> Anfang 2020 sind wir dann in die Breite gegangen mit webPDF und nun werden alle E-Mails mit webPDF konvertiert.
<G-vec01132-002-s340><convert.konvertieren><en> Convert Blu-rays to popular videos and audio formats for playback on mobile and portable devices.
<G-vec01132-002-s340><convert.konvertieren><de> Konvertiert Blu-ray in beliebte Video- und Audioformate, um sie auf mobilen und tragbaren Geräten wiederzugeben.
<G-vec01132-002-s341><convert.konvertieren><en> Convert numbered lists to List Items that are formatted in HTML using the <ol> tag. Convert to Text
<G-vec01132-002-s341><convert.konvertieren><de> Konvertiert nummerierte Listen in Listenelemente, die in HTML mit dem Tag <ol> formatiert sind.
<G-vec01132-002-s380><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your ODT file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s380><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ODT konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s381><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your CAM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s381><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei LDF konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s382><convert.konvertieren><en> What can I also do? Unfortunately, if after performing the two previously described steps (trying to find your RAR file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions Nederlands
<G-vec01132-002-s382><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei RAR konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s383><convert.konvertieren><en> What can I also do? Unfortunately, if after performing the two previously described steps (trying to find your DB file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s383><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei DB konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s384><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your MP3 file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s384><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei MP3 konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s385><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your LIT file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s385><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei LIT konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s386><convert.konvertieren><en> If this fails, use the information previously described steps (trying to find your P65 file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s386><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei P65 konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s387><convert.konvertieren><en> If, despite that, steps (trying to find your ASC file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s387><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ASC konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s388><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your DESKTHEMEPACK file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s388><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei DOCHTML konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s389><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your ACSM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s389><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ACSM konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s390><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your NOTE file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s390><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei NOTE konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s391><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your JNT file converted by someone else, and the attempt to convert it to #IS# on your own) you but it certainly will give the best result. Language English
<G-vec01132-002-s391><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei PMD konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s392><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your HTM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s392><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei HTM konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s393><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your DOCX file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s393><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei DOCX konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s394><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your PPSX file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s394><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei PPSX konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s395><convert.konvertieren><en> If, described steps (trying to find your BIN file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left. You can Nederlands
<G-vec01132-002-s395><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei FH8 konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s396><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your IDEA file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s396><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei WEBARCHIVE konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s397><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your CAM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s397><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei MDI konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s398><convert.konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your ODP file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s398><convert.konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ODP konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s418><convert.konvertieren><en> Learn how to convert WRF to MP4, MOV, WMV online or offline for easy watching anytime anywhere in this article. … Jul 23,2019
<G-vec01132-002-s418><convert.konvertieren><de> In diesem Artikel erfahren Sie, wie Sie WRF in MP4, MOV, WMV online oder offline konvertieren, um sie jederzeit und überall anzusehen.
<G-vec01132-002-s419><convert.konvertieren><en> Type in the amount you want to convert and press the Convert button.
<G-vec01132-002-s419><convert.konvertieren><de> Geben Sie jeden Betrag, den Sie konvertieren möchten, und drücken Sie die Schaltfläche "Convert".
<G-vec01132-002-s420><convert.konvertieren><en> Decrease or increase the property value for each color component to convert that color channel to a darker or lighter shade of gray.
<G-vec01132-002-s420><convert.konvertieren><de> Erhöhen oder reduzieren Sie den Eigenschaftswert für die einzelnen Farbkomponenten, um den Farbkanal zu einem dunkleren oder helleren Grauton zu konvertieren.
<G-vec01132-002-s421><convert.konvertieren><en> Download Screenshot AnyMP4 PDF Converter Ultimate not only can convert PDF files to...
<G-vec01132-002-s421><convert.konvertieren><de> Mit diesem einfachen Konverter können Sie PDF-Dateien in unterschiedliche Textformate konvertieren: Word, TXT, RTF.
<G-vec01132-002-s422><convert.konvertieren><en> It can convert almost all kinds of DVD to Zune Movie / Zune Video format. DVD to Zune Movie...
<G-vec01132-002-s422><convert.konvertieren><de> Mit DVD zum iPhone Umformer, können Sie fast alle Arten DVD in Format des iPhone Videos konvertieren (mp4).
<G-vec01132-002-s423><convert.konvertieren><en> Learn which file formats you can use with Numbers, how to open them, and how to convert your Numbers spreadsheet into another format.
<G-vec01132-002-s423><convert.konvertieren><de> Hier erfahren Sie, welche Dateiformate Sie mit Numbers verwenden können, wie Sie sie öffnen und wie Sie Ihre Numbers-Tabelle in ein anderes Format konvertieren.
<G-vec01132-002-s424><convert.konvertieren><en> If you are using the UNIX-based operating system, install OpenOffice to convert rich text files and supported Microsoft Office files to PDF documents.
<G-vec01132-002-s424><convert.konvertieren><de> Wenn Sie das UNIX-basierte Betriebssystem verwenden, installieren Sie OpenOffice, um Rich Text-Dateien und unterstützte Microsoft Office-Dateien in PDF-Dokumente zu konvertieren.
<G-vec01132-002-s425><convert.konvertieren><en> With the help of this program you can encrypt your PDF docs with a password, edit them as easy on Microsoft Office Word, convert the PDF files to MS Word, Excel or PowerPoint, annotate the docs and create the PDF files in Excel, PowerPoint and Word.
<G-vec01132-002-s425><convert.konvertieren><de> Mit Hilfe dieses Programms können Sie Ihre PDF-Dokumente mit einem Passwort verschlüsseln, sie genauso einfach wie mit Microsoft Office Word bearbeiten, sie in MS Word, Excel oder Powerpoint konvertieren, die Dokumente mit Anmerkungen versehen und die PDF-Dateien in Excel, Powerpoint und Word gestalten.
<G-vec01132-002-s426><convert.konvertieren><en> New Markdown editor allows you to easily write, preview and convert Markdown content.
<G-vec01132-002-s426><convert.konvertieren><de> Neuer Markdown-Editor ermöglicht Ihnen, Markdown-Inhalte auf unkomplizierte Weise zu schreiben, eine Vorschau dazu anzuzeigen und sie zu konvertieren.
<G-vec01132-002-s427><convert.konvertieren><en> PDF to Word made easy: convert PDF to editable Microsoft Word files.
<G-vec01132-002-s427><convert.konvertieren><de> Sie können PDF-Dateien in Word scannen oder konvertieren.
<G-vec01132-002-s428><convert.konvertieren><en> Use Nitro Pro 7 to batch convert large collections of files to PDF or PDF/A with just a few clicks.
<G-vec01132-002-s428><convert.konvertieren><de> Mit Nitro Pro 7 können Sie mit nur wenigen Klicks große Sammlungen von Dateien per Stapelbearbeitung in das PDF- oder PDF/A-Format konvertieren.
<G-vec01132-002-s429><convert.konvertieren><en> Use FLV to MP3 Converter to convert the video to an audio file then transfer it your multimedia device and enjoy it.
<G-vec01132-002-s429><convert.konvertieren><de> Mit FLV to MP3 Converter können Sie das Video in eine Audio-Datei konvertieren, diese auf Ihr Multimedia-Gerät übertragen und dort genießen.
<G-vec01132-002-s430><convert.konvertieren><en> Use Océ VPconvert to automatically convert Xerox print data from VIPP to PS/PDF and easily submit it to Océ production printers.
<G-vec01132-002-s430><convert.konvertieren><de> Verwenden Sie Océ DPconnect, um Xerox-Drucktaten automatisch aus Xerox DigiPath- und Xerox FreeFlow-Umgebungen zu konvertieren und an Océ Produktionsdrucksysteme zu übertragen.
<G-vec01132-002-s431><convert.konvertieren><en> PDFMate PDF Converter Free PDFMate PDF Converter Free is a free application to convert PDF to plain Text, EPUB, Images, HTML, SWF, Word and PDF files.
<G-vec01132-002-s431><convert.konvertieren><de> Free PDF Konverter bietet Ihnen eine benutzerfreundliche Oberfläche, sodass Sie mit Free PDF Converter PDF Dateien zu EPUB, Text, Bild, HTML und SWF sehr leicht konvertieren.
<G-vec01132-002-s432><convert.konvertieren><en> If this is problematic, you can use the Add method, which enables you to specify more than one kind of time interval in a single method call and eliminates the need to convert time intervals to fractional parts of a day.
<G-vec01132-002-s432><convert.konvertieren><de> Wenn dies problematisch ist, können Sie die Add -Methode verwenden, die es Ihnen ermöglicht, mehr als eine Art Zeitintervall in einem einzelnen Methodenaufruf anzugeben, und es entfällt, dass Sie Zeitintervalle in Bruchteile einer Minute konvertieren müssen.
<G-vec01132-002-s433><convert.konvertieren><en> Easily convert your existing Windows Boot Camp partition to a new Parallels Desktop virtual machine.
<G-vec01132-002-s433><convert.konvertieren><de> Sie können Ihre vorhandene Windows Boot Camp-Partition in eine neue virtuelle Parallels Desktop-Maschine konvertieren.
<G-vec01132-002-s435><convert.konvertieren><en> If you are worried that the computer you are using for a presentation may not have PowerPoint, then use VideoPPT to convert your entire presentation to a video file.
<G-vec01132-002-s435><convert.konvertieren><de> Wenn Sie sich sorgen, dass der Computer, den Sie für eine Präsentation verwenden, möglicherweise kein PowerPoint hat, dann verwenden Sie VideoPPT, um Ihre gesamte Präsentation in eine Video-Datei zu konvertieren.
<G-vec01132-002-s436><convert.konvertieren><en> You can convert PDF to Word Doc without Adobe Acrobat Reader or Microsoft Word.
<G-vec01132-002-s436><convert.konvertieren><de> Sie können Ihr PDF auch mit Microsoft Word in ein Word-Dokument konvertieren.
<G-vec01132-002-s190><convert.sich_konvertieren><en> When you convert paragraph text to point text, all characters outside the bounding box are deleted.
<G-vec01132-002-s190><convert.sich_konvertieren><de> Sie können Punkttext in Absatztext konvertieren, um den Zeichenfluss innerhalb eines Begrenzungsrahmens einzustellen.
<G-vec01132-002-s191><convert.sich_konvertieren><en> Before starting copying iTunes M4P and Apple Music songs to Huawei, ripping the DRM protection and convert these music the format supported by Huawei Mate 10 are required.
<G-vec01132-002-s191><convert.sich_konvertieren><de> Bevor Sie mit dem Kopieren von iTunes M4P und Apple Music Songs auf Huawei beginnen, müssen Sie den DRM-Schutz kopieren und diese Musik in das von Huawei Mate 10 unterstützte Format konvertieren.
<G-vec01132-002-s192><convert.sich_konvertieren><en> If you are going to convert the RPMSG to EML file, you must have the appropriate software.
<G-vec01132-002-s192><convert.sich_konvertieren><de> Wenn Sie vorhaben, die Datei STD in SXD zu konvertieren, müssen Sie eine entsprechende Software besitzen.
<G-vec01132-002-s193><convert.sich_konvertieren><en> And, just like MJML, it has custom tags that will automatically convert to HTML when it’s compiled.
<G-vec01132-002-s193><convert.sich_konvertieren><de> Und genau wie MJML, es hat benutzerdefinierte tags, die automatisch in HTML konvertieren, wenn es kompiliert.
<G-vec01132-002-s194><convert.sich_konvertieren><en> Note:You'll need to be connected to the internet to open ODF files and convert them to OOXML files.
<G-vec01132-002-s194><convert.sich_konvertieren><de> Hinweis: Damit Sie ODF-Dateien öffnen und in OOXML-Dateien konvertieren können, muss eine Internetverbindung bestehen.
<G-vec01132-002-s195><convert.sich_konvertieren><en> If, find your CDI file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s195><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei CDI konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format BIN zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s196><convert.sich_konvertieren><en> Therefore, our task is to convert data provided in a random order and different formats into the required format.
<G-vec01132-002-s196><convert.sich_konvertieren><de> Daher ist es unsere Aufgabe, die in zufälliger Reihenfolge und in verschiedenen Formaten bereitgestellten Daten in das gewünschte Format zu konvertieren.
<G-vec01132-002-s197><convert.sich_konvertieren><en> To convert YouTube videos to WMV you will need a quality software that can handle the task of not only effectively download the videos but also efficiently convert it to WMV format.
<G-vec01132-002-s197><convert.sich_konvertieren><de> Um YouTube-Videos in WMV zu konvertieren, benötigen Sie eine hochwertige Software, das kann die Aufgabe übernehmen, nicht nur die Videos effektiv zu herunterladen aber auch effizient in das WMV-Format konvertieren.
<G-vec01132-002-s198><convert.sich_konvertieren><en> Open damaged, corrupted and inaccessible OST file and convert to PST file to recover Exchange mailbox folders easily.
<G-vec01132-002-s198><convert.sich_konvertieren><de> Beschädigte oder unzugängliche OST-Datei mit OST2 Konverter öffnen und in PST-Datei konvertieren, um Postfach-Ordner von Exchange wiederherzustellen.
<G-vec01132-002-s199><convert.sich_konvertieren><en> Home users can perform complicated partition operations by using this powerful but free partition manager to manage their hard disk partition such as Resizing partitions, Copying partitions, Create partition, Delete partition, Format partition, Convert partition, Explore partition, Hide partition, Change drive letter, Set active partition, Convert Dynamic Disk to Basic Disk, Surface Test, Change Partition Serial Number, Change Partition Type ID and Partition Recovery.
<G-vec01132-002-s199><convert.sich_konvertieren><de> Privatbenutzer können mit diesem starken und dabei kostenlosen Partitionsmanager komplexe Partitionsvorgänge zur Verwaltung ihrer Festplattenpartition durchführen, beispielsweise eine Veränderung der Partitionsgröße, die Kopie von Partitionen, eine Partition erstellen, löschen, formatieren, konvertieren, erkunden und verstecken, den Laufwerkbuchstaben ändern, eine aktive Partition einrichten, einen dynamischen in einen Basisdatenträger konvertieren, einen Oberflächentest durchführen, die Seriennummer der Partition ändern, die Typ-ID dieser Partition ändern und eine Partition wiederherstellen.
<G-vec01132-002-s200><convert.sich_konvertieren><en> This software can convert existing 2D-videos automatically into the third dimension.
<G-vec01132-002-s200><convert.sich_konvertieren><de> Sie ist dazu in der Lage, 2D-Videos automatisch in die dritte Dimension zu konvertieren.
<G-vec01132-002-s201><convert.sich_konvertieren><en> Miro Video Converter can convert your video files to mobile format quickly and without any fuss.
<G-vec01132-002-s201><convert.sich_konvertieren><de> Miro Video Converter kann Ihre Videodateien schnell und ohne viel Aufwand in ein mobiles Format konvertieren.
<G-vec01132-002-s202><convert.sich_konvertieren><en> Click CONVERT button to remove DRM and convert these files to plain format without losing original quality.
<G-vec01132-002-s202><convert.sich_konvertieren><de> Klicken Sie auf der Schaltfläche "Konvertieren", um DRM zu entfernen und diese Audio-Datei in MP3-Format ohne Verlust der Qualität zu konvertieren.
<G-vec01132-002-s203><convert.sich_konvertieren><en> Convert a PDF to Word in a couple of clicks – so you can start editing right away and increase your personal productivity.
<G-vec01132-002-s203><convert.sich_konvertieren><de> In drei einfachen Schritten können Sie ein PDF in ein Excel-Dokument konvertieren und direkt daran arbeiten.
<G-vec01132-002-s204><convert.sich_konvertieren><en> To drop the mirror database, you must first convert it to a scale-out database copy.
<G-vec01132-002-s204><convert.sich_konvertieren><de> Um die Spiegeldatenbank löschen zu können, müssen Sie sie zunächst in eine Scale-Out-Datenbankkopie konvertieren.
<G-vec01132-002-s205><convert.sich_konvertieren><en> To effectively convert MP3 to OGG format, you will need a powerful and professional converter software.
<G-vec01132-002-s205><convert.sich_konvertieren><de> Um MP3 effektiv in das OGG-Format zu konvertieren, benötigen Sie eine leistungsstarke und professionelle Konvertersoftware.
<G-vec01132-002-s206><convert.sich_konvertieren><en> To convert only one instance of the footage item, select the layer in the Timeline panel, and choose Layer > Convert To Layered Comp.
<G-vec01132-002-s206><convert.sich_konvertieren><de> Wenn Sie nur eine Instanz des Footageelements konvertieren möchten, wählen Sie die Ebene im Zeitleistenfenster aus und klicken Sie dann auf „Ebene“ > „In Komposition mit Ebenen konvertieren“.
<G-vec01132-002-s207><convert.sich_konvertieren><en> When edited using PlayMemories Home or Premiere Pro CC with Video Edit Components (optional plug-in software), you can convert 4K video to XAVC S format, playable using Sony's XAVC S compatible camera.
<G-vec01132-002-s207><convert.sich_konvertieren><de> Nach der Bearbeitung mit PlayMemories Home oder Premiere Pro CC mit Video Edit Components (optionale Plugin-Software) können Sie 4K-Videos in das XAVC S-Format konvertieren, das mit der XAVC S-kompatiblen Kamera von Sony abspielbar ist.
<G-vec01132-002-s208><convert.sich_konvertieren><en> If you are going to convert the XVID to DIVX file, you must have the appropriate software.
<G-vec01132-002-s208><convert.sich_konvertieren><de> Wenn Sie vorhaben, die Datei DIVX in XVID zu konvertieren, müssen Sie eine entsprechende Software besitzen.
<G-vec01132-002-s228><convert.sich_konvertieren><en> How to Rip and Convert DVD to PS3: Step 2> Insert the DVD into your optical drive, and DVDFab will load the content on the DVD automatically.
<G-vec01132-002-s228><convert.sich_konvertieren><de> Wie rippe und konvertiere ich DVD zu WMV mit dem DVD to WMV Ripper: Schritt 2 > Legen Sie eine DVD in das optische Laufwerk ein und DVDFab wird den Inhalt der DVD automatisch laden.
<G-vec01132-002-s229><convert.sich_konvertieren><en> Convert blog readers into leads and signups.
<G-vec01132-002-s229><convert.sich_konvertieren><de> Konvertiere Blog-Leser in Leads und Anmeldungen.
<G-vec01132-002-s230><convert.sich_konvertieren><en> Step 4 Convert MOV to MP4 with FFmpeg alternative
<G-vec01132-002-s230><convert.sich_konvertieren><de> Schritt 4 Konvertiere MOV zu MP4.
<G-vec01132-002-s231><convert.sich_konvertieren><en> Convert 1,000 paces to kilometer (pace to km).
<G-vec01132-002-s231><convert.sich_konvertieren><de> Konvertiere 8 Schritte in km (pace in Kilometer).
<G-vec01132-002-s232><convert.sich_konvertieren><en> If you would like to add a favicon for your desktop platform, convert any image into a favicon by using a favicon generator (search in Google) and save it to your computer.
<G-vec01132-002-s232><convert.sich_konvertieren><de> Wenn du ein Favicon zu deiner Desktop-Plattform hinzufügen möchtest, konvertiere ein Bild mithilfe eines Favicon Generators (suche bei Google) in ein Favicon und speichere es auf deinem Computer.
<G-vec01132-002-s233><convert.sich_konvertieren><en> Convert media files easily with Permute.
<G-vec01132-002-s233><convert.sich_konvertieren><de> Konvertiere deine Mediendateien in das von dir benötigte Streaming-Format.
<G-vec01132-002-s234><convert.sich_konvertieren><en> Convert your images from your mobile phone into a PDF file.
<G-vec01132-002-s234><convert.sich_konvertieren><de> Konvertiere deine Bilder in ein PDF.
<G-vec01132-002-s235><convert.sich_konvertieren><en> Convert 30 cm3 to m3 (cubic centimeters to cubic meters).
<G-vec01132-002-s235><convert.sich_konvertieren><de> Konvertiere 459 hm3 in m3 (Kubikhektometer in Kubikmeter).
<G-vec01132-002-s236><convert.sich_konvertieren><en> How to Convert DVD with DVDFab DVD Ripper: Step 4 > Now you can choose the titles, chapters, audio tracks and subtitles, define the names of the titles, and do advanced settings according to your needs.
<G-vec01132-002-s236><convert.sich_konvertieren><de> Wie konvertiere ich DVD mit dem DVDFab DVD Ripper: Schritt 4 > Jetzt können Sie die Titel, Kapitel, Audiospuren und Untertitel auswählen, den Namen des Titels festlegen und weitere Einstellungen nach Ihren Wünschen vornehmen.
<G-vec01132-002-s237><convert.sich_konvertieren><en> Then convert it to CMYK color mode and save it as a .psd file.
<G-vec01132-002-s237><convert.sich_konvertieren><de> Konvertiere es dann zu CMYK und speichere es als .psd.
<G-vec01132-002-s238><convert.sich_konvertieren><en> Click Convert to VM:
<G-vec01132-002-s238><convert.sich_konvertieren><de> Klicken Sie auf Konvertiere zu VM.
<G-vec01132-002-s239><convert.sich_konvertieren><en> Convert m2 to hm2 (square meter to square hectometer).
<G-vec01132-002-s239><convert.sich_konvertieren><de> Konvertiere 9 m2 in hm2 (Quadratmeter in Quadrathektometer).
<G-vec01132-002-s240><convert.sich_konvertieren><en> How to Rip and Convert DVD to Cell Phone with DVD to Cell Phone Ripper:Step 5 > Click the "folder" button to select a directory to save the output video.
<G-vec01132-002-s240><convert.sich_konvertieren><de> Wie rippe und konvertiere ich DVD zu WMV mit dem DVD to WMV Ripper: Schritt 5 > Klicken Sie auf die „Ordner“ Taste und wählen ein Verzeichnis zum Speichern des Ausgabevideos aus.
<G-vec01132-002-s241><convert.sich_konvertieren><en> How to Rip and Convert DVD to DivX/XviD with DVD to DivX/XviD Ripper:Step 2> Insert the DVD into your optical drive, and DVDFab will load the content on the DVD automatically.
<G-vec01132-002-s241><convert.sich_konvertieren><de> Wie rippe und konvertiere ich DVD zu PVP mit dem DVD to PVP Ripper: Schritt 2 > Legen Sie eine DVD in das optische Laufwerk ein und DVDFab wird den Inhalt der DVD automatisch laden.
<G-vec01132-002-s242><convert.sich_konvertieren><en> Edit and convert PDF files online in your browser.
<G-vec01132-002-s242><convert.sich_konvertieren><de> Bearbeite und konvertiere PDF Dateien online in Deinem Browser.
<G-vec01132-002-s244><convert.sich_konvertieren><en> How to Rip and Convert DVD to Xbox 360: Step 5> Click the "folder" button to select a directory to save the output video.
<G-vec01132-002-s244><convert.sich_konvertieren><de> Wie konvertiere ich DVD mit dem DVDFab DVD Ripper: Schritt 5 > Klicken Sie auf die „Ordner“ Taste und wählen ein Verzeichnis zum Speichern des Ausgabevideos aus.
<G-vec01132-002-s245><convert.sich_konvertieren><en> Or, select all and convert them in a batch.
<G-vec01132-002-s245><convert.sich_konvertieren><de> Oder wähle alle aus und konvertiere sie in einer Charge.
<G-vec01132-002-s246><convert.sich_konvertieren><en> TIP: The best file types for Facebook cover videos are MP4 and MOV – if your video is in a different format, convert it using Clipchamp.
<G-vec01132-002-s246><convert.sich_konvertieren><de> TIPP: Die besten Dateitypen für Facebook-Cover-Videos sind MP4 und MOV – wenn dein Video in einem anderen Format vorliegt, konvertiere es mit Clipchamp.
<G-vec01132-002-s247><convert.sich_konvertieren><en> You can use our software Contenta Converter PREMIUM to convert thousands of SR2 to black and white.
<G-vec01132-002-s247><convert.sich_konvertieren><de> Antwort Sie können unsere Software Contenta Converter PREMIUM verwenden, um Tausende von SR2 zu PNG zu konvertieren.
<G-vec01132-002-s248><convert.sich_konvertieren><en> All you need to do is to burn your playlist with iTunes to TuneClone's virtual CD Burner, and TuneClone will convert music files in the playlist to MP3, WMA or WAV files automatically. TuneClone Features
<G-vec01132-002-s248><convert.sich_konvertieren><de> Was Sie machen brauchen, ist nur, Ihre Playliste mit Ihrer Media Player Software auf dem TuneClone´s virtuellen CD Brenner zu brennen, und TuneClone wird Musikfiles in der Playliste in MP3, unbeschützten WMA- oder WAV-Files automatisch konvertieren.
<G-vec01132-002-s249><convert.sich_konvertieren><en> Click the Convert button at the lower-right bottom to start converting WMA files to the compatible format for your iOS device.
<G-vec01132-002-s249><convert.sich_konvertieren><de> Klicken Sie nun auf die Konvertieren - Schaltfläche unten rechts im Programmfenster, um die Konvertierung von WMA in MP3-Dateien zu starten.
<G-vec01132-002-s250><convert.sich_konvertieren><en> Another interesting feature is the ability to create, convert and extract multiple archives at once, which makes this application a real candidate for the best archiving utility on UNIX/Linux operating systems.
<G-vec01132-002-s250><convert.sich_konvertieren><de> Ein weiteres interessantes Feature ist die Möglichkeit, mehrere Archive gleichzeitig zu erstellen, zu konvertieren und zu extrahieren, was diese Anwendung zu einem echten Kandidaten für das beste Archivierungsprogramm auf UNIX / Linux-Betriebssystemen macht.
<G-vec01132-002-s251><convert.sich_konvertieren><en> Below is a list of programs that will convert the file XML to PDF.
<G-vec01132-002-s251><convert.sich_konvertieren><de> Unten finden Sie eine Liste der Programme, die die Datei XML in PDF konvertieren.
<G-vec01132-002-s252><convert.sich_konvertieren><en> It can convert .aa and .aax audiobooks to MP3/AAC/FLAC/WAV at lightning speed with lossless quality.
<G-vec01132-002-s252><convert.sich_konvertieren><de> Es kann Benutzer helfen, DRM-Ed Apple Musik-Dateien, M4A/M4B/AA/AAX Hörbücher und M4P Songs zu normalen MP3/AAC/WAV mit 20X schneller Geschwindigkeit und verlustfreier Qualität zu konvertieren.
<G-vec01132-002-s253><convert.sich_konvertieren><en> Click on Norwegian Krone or Mexican Peso to convert between that currency and all the other currencies.
<G-vec01132-002-s253><convert.sich_konvertieren><de> Klicken Sie auf Norwegische Krone oder Mexikanischer Peso, um zwischen dieser Währung und allen anderen Währungen zu konvertieren.
<G-vec01132-002-s254><convert.sich_konvertieren><en> The differences between these two applications can make it difficult to convert one of the file formats to the other.
<G-vec01132-002-s254><convert.sich_konvertieren><de> Die Unterschiede zwischen diesen beiden Anwendungen kann es schwierig machen, eine der Dateiformate zum anderen zu konvertieren.
<G-vec01132-002-s255><convert.sich_konvertieren><en> Optimized Presets: Directly convert files to fit Apple devices and Android devices.
<G-vec01132-002-s255><convert.sich_konvertieren><de> Optimierte Voreinstellungen: Direkt Dateien zu Apple-Geräten konvertieren und Android-Geräte anzupassen.
<G-vec01132-002-s256><convert.sich_konvertieren><en> You can also convert Powerpoint and Excel to PDF.
<G-vec01132-002-s256><convert.sich_konvertieren><de> Außerdem lassen sich damit Powerpoint- und Excel-Dateien in PDF konvertieren.
<G-vec01132-002-s257><convert.sich_konvertieren><en> Click the Convert All button at the lower-right bottom of the software window to start M2TS to AVI conversion.
<G-vec01132-002-s257><convert.sich_konvertieren><de> Klicken Sie unten im Softwarefenster auf den Alle konvertieren -Knopf, um mit der M2TS zu AVI-Konvertierung zu beginnen.
<G-vec01132-002-s258><convert.sich_konvertieren><en> Select the document you want to convert.
<G-vec01132-002-s258><convert.sich_konvertieren><de> Wählen Sie das Dokument das Sie Konvertieren wollen.
<G-vec01132-002-s259><convert.sich_konvertieren><en> Click the Convert button to convert WavPack/wv/wvc to wma.
<G-vec01132-002-s259><convert.sich_konvertieren><de> Klicken Sie auf die Schaltfläche Konvertieren zu WavPack konvertieren / WV / WVC in wma.
<G-vec01132-002-s261><convert.sich_konvertieren><en> But Reza was lacking the courage to convert publicly, fearing presecution from the Islamic state and even his family.
<G-vec01132-002-s261><convert.sich_konvertieren><de> Aber es fehlte Reza der Mut, öffentlich zu konvertieren, da er eine Verfolgung durch den islamischen Staat und sogar seine eigene Familie befürchtete.
<G-vec01132-002-s262><convert.sich_konvertieren><en> Furthermore, it is technically impossible to convert these templates 1:1, because the new system is built differently.
<G-vec01132-002-s262><convert.sich_konvertieren><de> Außerdem ist es technisch nicht möglich, diese Vorlagen 1:1 zu konvertieren, weil das neue System anders aufgebaut ist.
<G-vec01132-002-s263><convert.sich_konvertieren><en> Example: You want to convert 5 barrels into litres.
<G-vec01132-002-s263><convert.sich_konvertieren><de> Beispiel: Sie wollen 5 Barrel (Erdöl) in Liter konvertieren.
<G-vec01132-002-s264><convert.sich_konvertieren><en> If you already have gINT installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the gINT).
<G-vec01132-002-s264><convert.sich_konvertieren><de> Wenn Sie PowerFlip schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm PowerFlip öffnen kann).
<G-vec01132-002-s265><convert.sich_konvertieren><en> Use with Xcode to convert FileMaker apps into native iOS apps. FileMaker WebDirect
<G-vec01132-002-s265><convert.sich_konvertieren><de> Zusammen mit Xcode lassen sich FileMaker-Apps in native iOS-Apps konvertieren.
<G-vec01132-002-s285><convert.sich_konvertieren><en> DBF to DBF Converter 2.50 Convert your DBF files from one format to another.
<G-vec01132-002-s285><convert.sich_konvertieren><de> Konvertieren Sie Ihre DBF-Dateien von einem Format in ein anderes.
<G-vec01132-002-s286><convert.sich_konvertieren><en> Convert DOCX to TIFF - online and free - this page also contains information on the DOCX and TIFF file extensions.
<G-vec01132-002-s286><convert.sich_konvertieren><de> Konvertieren Sie DOCX zu TIFF - online und kostenlos - diese Seite enthält auch Information über die DOCX und TIFF Datei Erweiterungen.
<G-vec01132-002-s287><convert.sich_konvertieren><en> Convert M3U to MP4, MOV, AVI, MKV and other 150+ video/audio formats.
<G-vec01132-002-s287><convert.sich_konvertieren><de> Komprimieren und konvertieren Sie mehr als 1000 Videoformate, darunter MP4, MOV, AVI, MKV, WMV.
<G-vec01132-002-s288><convert.sich_konvertieren><en> Download Dragoman Convert the batches of images, photos, music, sound and archives.
<G-vec01132-002-s288><convert.sich_konvertieren><de> Download Dragoman Konvertieren Sie die Reihen von Bildern, Fotos, Musik, Ton und Archive .
<G-vec01132-002-s289><convert.sich_konvertieren><en> Convert a corrupt or healthy Outlook OST to a working PST file in a simple and hassle-free way using SFWare.
<G-vec01132-002-s289><convert.sich_konvertieren><de> Konvertieren Sie eine beschädigte oder fehlerfreie Outlook-OST-Datei mit SFWare auf einfache und problemlose Weise in eine funktionierende PST-Datei.
<G-vec01132-002-s290><convert.sich_konvertieren><en> Or convert to MP4 for playback on your iPhone, iPad and other Apple devices.
<G-vec01132-002-s290><convert.sich_konvertieren><de> Oder konvertieren Sie in MP4 für die Wiedergabe auf Ihrem iPhone, iPad und anderen Apple-Geräten.
<G-vec01132-002-s291><convert.sich_konvertieren><en> Convert videos to MP4 and MKV with the H.265 codec on systems with an Intel or NVIDIA graphics card with HEVC technology support.
<G-vec01132-002-s291><convert.sich_konvertieren><de> Konvertieren Sie Videos in MP4 und MKV mit dem H.265 Codec auf Systemen mit einer Intel- oder NVIDIA-Grafikkarte mit der Unterstützung der HEVC-Technologie.
<G-vec01132-002-s292><convert.sich_konvertieren><en> Convert PPTX to JPG - online and free - this page also contains information on the PPTX and JPG file extensions.
<G-vec01132-002-s292><convert.sich_konvertieren><de> Konvertieren Sie DOCX zu JPG - online und kostenlos - diese Seite enthält auch Information über die DOCX und JPG Datei Erweiterungen.
<G-vec01132-002-s293><convert.sich_konvertieren><en> Convert your RC car, truck or buggy into a pursuit car with the Police Car LED Light Beacon.
<G-vec01132-002-s293><convert.sich_konvertieren><de> Konvertieren Sie Ihre RC Auto, LKW oder Buggy in eine Verfolgung Auto mit der Polizei-Auto-LED-Beleuchtungssystem.
<G-vec01132-002-s294><convert.sich_konvertieren><en> Convert PDF to images, Word, Excel, PPT, EPUB and more formats.
<G-vec01132-002-s294><convert.sich_konvertieren><de> Konvertieren Sie PDF in Word, Excel und andere Formate.
<G-vec01132-002-s295><convert.sich_konvertieren><en> Download and convert online videos with 90X faster speed.
<G-vec01132-002-s295><convert.sich_konvertieren><de> Downloaden und konvertieren Sie Online Videos 90 mal schneller.
<G-vec01132-002-s296><convert.sich_konvertieren><en> Convert BMP to PS - online and free - this page also contains information on the BMP and PS file extensions.
<G-vec01132-002-s296><convert.sich_konvertieren><de> Konvertieren Sie DCR zu BMP - online und kostenlos - diese Seite enthält auch Information über die DCR und BMP Datei Erweiterungen.
<G-vec01132-002-s297><convert.sich_konvertieren><en> Convert PAGES to TXT - online and free - this page also contains information on the PAGES and TXT file extensions.
<G-vec01132-002-s297><convert.sich_konvertieren><de> Konvertieren Sie DOC zu PAGES - online und kostenlos - diese Seite enthält auch Information über die DOC und PAGES Datei Erweiterungen.
<G-vec01132-002-s298><convert.sich_konvertieren><en> Convert EPUB to LRF - online and free - this page also contains information on the EPUB and LRF file extensions.
<G-vec01132-002-s298><convert.sich_konvertieren><de> Konvertieren Sie EPUB zu MOBI - online und kostenlos - diese Seite enthält auch Information über die EPUB und MOBI Datei Erweiterungen.
<G-vec01132-002-s299><convert.sich_konvertieren><en> Convert your mighty NITRO BUMBLEBEE figure from CAMARO concept vehicle mode to battle-ready robot mode.
<G-vec01132-002-s299><convert.sich_konvertieren><de> Konvertieren Sie Ihre mächtigen NITRO BUMBLEBEE Figur aus Camaro Concept Fahrzeug-Modus, um kampfbereite Roboter-Modus.
<G-vec01132-002-s300><convert.sich_konvertieren><en> Convert PDF to JPG - online and free - this page also contains information on the PDF and JPG file extensions.
<G-vec01132-002-s300><convert.sich_konvertieren><de> Konvertieren Sie PDF zu JPG - online und kostenlos - diese Seite enthält auch Information über die PDF und JPG Datei Erweiterungen.
<G-vec01132-002-s301><convert.sich_konvertieren><en> Convert MSG to DOC - online and free - this page also contains information on the MSG and DOC file extensions.
<G-vec01132-002-s301><convert.sich_konvertieren><de> Konvertieren Sie PDF zu DOC - online und kostenlos - diese Seite enthält auch Information über die PDF und DOC Datei Erweiterungen.
<G-vec01132-002-s302><convert.sich_konvertieren><en> Or convert to play mode and timeless period of searching for as long as your convenience.
<G-vec01132-002-s302><convert.sich_konvertieren><de> Oder konvertieren Sie den Modus und zeitlose Zeit der Suche, so lange wie Ihre Bequemlichkeit zu spielen.
<G-vec01132-002-s303><convert.sich_konvertieren><en> Convert MOV to WAV - online and free - this page also contains information on the MOV and WAV file extensions.
<G-vec01132-002-s303><convert.sich_konvertieren><de> Konvertieren Sie MOV zu WAV - online und kostenlos - diese Seite enthält auch Information über die MOV und WAV Datei Erweiterungen.
<G-vec01132-002-s304><convert.sich_konvertieren><en> Program EASE SpeakerLab may also be used to convert files between different formats.
<G-vec01132-002-s304><convert.sich_konvertieren><de> Das Programm KWalletManager kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s305><convert.sich_konvertieren><en> Program Kodak EasyShare Software may also be used to convert files between different formats.
<G-vec01132-002-s305><convert.sich_konvertieren><de> Das Programm AutoImager kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s306><convert.sich_konvertieren><en> Program InfoStat may also be used to convert files between different formats.
<G-vec01132-002-s306><convert.sich_konvertieren><de> Das Programm UnSqueez kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s307><convert.sich_konvertieren><en> Program Aimersoft Video Converter may also be used to convert files between different formats.
<G-vec01132-002-s307><convert.sich_konvertieren><de> Das Programm ZVR Converter kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s308><convert.sich_konvertieren><en> Okoker WMV to DVD VCD DIVX MPEG Converter&Burner is a professional media conversion tool that can batch convert WMV to AVI, DIVX, DVD, VCD, MPEG and Burn to DVD/CD.
<G-vec01132-002-s308><convert.sich_konvertieren><de> DETAILS Der WMV to AVI MPEG DVD WMV Converter ist ein leistungsfähiges und wunderbares Tool für konvertieren von WMV- oder ASF-Dateien in AVI, MPEG, VCD, SVCD, DVD-Formate.
<G-vec01132-002-s309><convert.sich_konvertieren><en> I wasn’t able to find a proper app to convert PNG files to PDF documents on my Android smartphone until I found this one.
<G-vec01132-002-s309><convert.sich_konvertieren><de> Ich konnte keine geeignete App zum Konvertieren von PNG-Dateien in PDF-Dokumente auf meinem Android-Smartphone finden, bis ich dieses gefunden habe.
<G-vec01132-002-s310><convert.sich_konvertieren><en> The first step on how to batch convert Word to PDF is to download PDFelement Pro.
<G-vec01132-002-s310><convert.sich_konvertieren><de> Der erste Schritt zum konvertieren von Word in PDF ist das herunterladen von PDFelement Pro.
<G-vec01132-002-s311><convert.sich_konvertieren><en> Program Restricted Focus Viewer may also be used to convert files between different formats.
<G-vec01132-002-s311><convert.sich_konvertieren><de> Das Programm PSDL Viewer kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s312><convert.sich_konvertieren><en> Program Blue Iris may also be used to convert files between different formats.
<G-vec01132-002-s312><convert.sich_konvertieren><de> Das Programm EclipseCrossword kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s313><convert.sich_konvertieren><en> Program Min-U-Script Xpress may also be used to convert files between different formats.
<G-vec01132-002-s313><convert.sich_konvertieren><de> Das Programm Min-U-Script Xpress kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s314><convert.sich_konvertieren><en> Program Hyper-V may also be used to convert files between different formats.
<G-vec01132-002-s314><convert.sich_konvertieren><de> Das Programm Hyper-V kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s315><convert.sich_konvertieren><en> Program Bryce may also be used to convert files between different formats.
<G-vec01132-002-s315><convert.sich_konvertieren><de> Das Programm Bryce kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s316><convert.sich_konvertieren><en> Program X-Wing vs. TIE Fighter may also be used to convert files between different formats.
<G-vec01132-002-s316><convert.sich_konvertieren><de> Das Programm X-Genics eManager kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s317><convert.sich_konvertieren><en> Program Software Update Tool LR may also be used to convert files between different formats.
<G-vec01132-002-s317><convert.sich_konvertieren><de> .JFFS2-kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s318><convert.sich_konvertieren><en> Program Tekla BIMsight may also be used to convert files between different formats.
<G-vec01132-002-s318><convert.sich_konvertieren><de> Das Programm ArcSoft Print Creations kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s319><convert.sich_konvertieren><en> Program Microsoft Winqual may also be used to convert files between different formats.
<G-vec01132-002-s319><convert.sich_konvertieren><de> Das Programm Microsoft Winqual kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s320><convert.sich_konvertieren><en> Program Snes9x may also be used to convert files between different formats.
<G-vec01132-002-s320><convert.sich_konvertieren><de> Das Programm Kasemake kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s321><convert.sich_konvertieren><en> Program Video Effects may also be used to convert files between different formats.
<G-vec01132-002-s321><convert.sich_konvertieren><de> Das Programm C64 Forever kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s322><convert.sich_konvertieren><en> Program Adobe PhotoDeluxe may also be used to convert files between different formats.
<G-vec01132-002-s322><convert.sich_konvertieren><de> Das Programm Adobe Kuler kann auch zum Konvertieren von Dateien zwischen verschiedenen Formaten verwendet werden.
<G-vec01132-002-s323><convert.sich_konvertieren><en> The formula you see on the left will be displayed for reference, while Excel will automatically convert the formula on the right into the appropriate result.
<G-vec01132-002-s323><convert.sich_konvertieren><de> Die Formel auf der linken Seite wird als Referenz angezeigt, während Excel die Formel rechts automatisch in das entsprechende Ergebnis konvertiert.
<G-vec01132-002-s324><convert.sich_konvertieren><en> We have a fantastic tool to convert Djibouti time zone and calculate time difference between Djibouti and other cities.
<G-vec01132-002-s324><convert.sich_konvertieren><de> Wir haben ein fantastisches Tool das die Los Angeleser Zeitzone konvertiert und Zeitunterschiede zwischen Los Angeles und anderen Städten berechnet.
<G-vec01132-002-s325><convert.sich_konvertieren><en> This method will not technically “convert” an image to a JPEG.
<G-vec01132-002-s325><convert.sich_konvertieren><de> Diese Methode konvertiert ein Bild technisch gesehen nicht in ein jpeg.
<G-vec01132-002-s326><convert.sich_konvertieren><en> Most kinds of data and content will convert, but how you format and interact with the data and content might be different between the formats.
<G-vec01132-002-s326><convert.sich_konvertieren><de> Die meisten Daten- und Inhaltsarten werden zwar konvertiert, doch unterscheidet sich möglicherweise die Formatierung und Interaktion mit den Daten und Inhalten bei den beiden Formaten.
<G-vec01132-002-s327><convert.sich_konvertieren><en> In the Name field on the Modify Style dialog, type the name of the Borland style to which you want to convert this style.
<G-vec01132-002-s327><convert.sich_konvertieren><de> Geben Sie in das Feld Name den Namen des Borland-Formats ein, in das dieses Format konvertiert werden soll.
<G-vec01132-002-s328><convert.sich_konvertieren><en> We have a fantastic tool to convert Tunisia time zone and calculate time difference between Tunisia and other cities.
<G-vec01132-002-s328><convert.sich_konvertieren><de> Wir haben ein fantastisches Tool das die Sowetoer Zeitzone konvertiert und Zeitunterschiede zwischen Soweto und anderen Städten berechnet.
<G-vec01132-002-s329><convert.sich_konvertieren><en> No more waiting for the tech guys to convert yet another product feed.
<G-vec01132-002-s329><convert.sich_konvertieren><de> Kein Warten mehr, bis die Techniker einen weiteren Daten-Feed konvertiert haben.
<G-vec01132-002-s330><convert.sich_konvertieren><en> Convert H.264 videos to various formats, such as MP4, AVI, MOV, FLV, VOB, 3GP, WMV, MKV, M4V, etc.
<G-vec01132-002-s330><convert.sich_konvertieren><de> Konvertiert H.264 Videos in verschiedene Formate, wie MP4, AVI, FLV, VOB, 3GP, WMV, MKV, M4V usw.
<G-vec01132-002-s331><convert.sich_konvertieren><en> The following tool will convert your entered text into images using Alias Font, and then you can right-click on the image to save it to embed image in forum posts
<G-vec01132-002-s331><convert.sich_konvertieren><de> Das folgende Tool konvertiert den von Ihnen eingegebenen Text zu Bildern oder Logos, die Sie durch Rechtsklick auf das Bild herunterladen können.
<G-vec01132-002-s332><convert.sich_konvertieren><en> When desired, you can choose to convert any placed asset into an embedded asset by choosing the Embed Link option.
<G-vec01132-002-s332><convert.sich_konvertieren><de> Bei Bedarf können Sie festlegen, dass jedes platzierte Element in ein eingebettetes Element konvertiert wird, indem Sie die Option „Link einbetten“ auswählen.
<G-vec01132-002-s333><convert.sich_konvertieren><en> How to Convert MKV to AVI Using DVDFab Video Converter
<G-vec01132-002-s333><convert.sich_konvertieren><de> Hier ist ein Tipp, wie man Videos mit DVDFab zu MKV Videos konvertiert.
<G-vec01132-002-s334><convert.sich_konvertieren><en> Here I'll show you how to convert AVCHD files on Mac using UniConverter for Mac.
<G-vec01132-002-s334><convert.sich_konvertieren><de> Hier zeige ich Ihnen wie man AVCHD Dateien auf Mac mit iSkysoft UniConverter für Mac konvertiert.
<G-vec01132-002-s335><convert.sich_konvertieren><en> Convert 3D Blu-ray to 3D M2TS Video > Step 5: Click the “Edit” button at the top right corner of Operation Window if you want to customize the resulting 3D video.
<G-vec01132-002-s335><convert.sich_konvertieren><de> Konvertiert 3D Blu-rays zu 3D Videos auf Mac > Schritt 5: Klicken Sie auf „Bearbeiten“ am oberen Rand der Hauptoberfläche, wenn Sie das resultierende 3D Video anpassen wollen.
<G-vec01132-002-s336><convert.sich_konvertieren><en> With the freeware DoubleTwist you can manage your songs and videos on your computer and sync it with your portable player or smartphone. The software is able to read following input formats: MP4, WMV, AVI, MPG, 3GP video files as well as MP3, AAC, WMA or WAV audio files and pictures in JPG, GIF, PNG or BMP fomrat and convert them, so you can use it on your mobile player or mobile phone.
<G-vec01132-002-s336><convert.sich_konvertieren><de> Mit der kostenlosen Software DoubleTwist verwalten Sie Ihre Songs und Videos auf dem Computer und synchronisieren diese MP3-, AAC-, WMA oder WAV-Audiofiles oder Bilder in den Formaten JPG, GIF, PNG oder BMP und konvertiert diese so um dass Sie diese auf dem mobilen Player oder Smartphone nutzen können.
<G-vec01132-002-s337><convert.sich_konvertieren><en> We have a fantastic tool to convert Neuquen time zone and calculate time difference between Neuquen and other cities.
<G-vec01132-002-s337><convert.sich_konvertieren><de> Wir haben ein fantastisches Tool das die Aigaleoer Zeitzone konvertiert und Zeitunterschiede zwischen Aigaleo und anderen Städten berechnet.
<G-vec01132-002-s338><convert.sich_konvertieren><en> When buying from a seller who lists in a currency other than your browsing currency, Etsy will convert the listing price for you.
<G-vec01132-002-s338><convert.sich_konvertieren><de> Wenn du bei einem Verkäufer einkaufst, der seine Artikel in einer anderen Währung einstellt als derjenigen, in der du stöberst, konvertiert Etsy den Artikelpreis für dich.
<G-vec01132-002-s339><convert.sich_konvertieren><en> After going all out with webPDF in early 2020, we are now using this solution to convert all emails.
<G-vec01132-002-s339><convert.sich_konvertieren><de> Anfang 2020 sind wir dann in die Breite gegangen mit webPDF und nun werden alle E-Mails mit webPDF konvertiert.
<G-vec01132-002-s340><convert.sich_konvertieren><en> Convert Blu-rays to popular videos and audio formats for playback on mobile and portable devices.
<G-vec01132-002-s340><convert.sich_konvertieren><de> Konvertiert Blu-ray in beliebte Video- und Audioformate, um sie auf mobilen und tragbaren Geräten wiederzugeben.
<G-vec01132-002-s341><convert.sich_konvertieren><en> Convert numbered lists to List Items that are formatted in HTML using the <ol> tag. Convert to Text
<G-vec01132-002-s341><convert.sich_konvertieren><de> Konvertiert nummerierte Listen in Listenelemente, die in HTML mit dem Tag <ol> formatiert sind.
<G-vec01132-002-s380><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your ODT file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s380><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ODT konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s381><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your CAM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s381><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei LDF konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s382><convert.sich_konvertieren><en> What can I also do? Unfortunately, if after performing the two previously described steps (trying to find your RAR file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions Nederlands
<G-vec01132-002-s382><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei RAR konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s383><convert.sich_konvertieren><en> What can I also do? Unfortunately, if after performing the two previously described steps (trying to find your DB file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s383><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei DB konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s384><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your MP3 file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s384><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei MP3 konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s385><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your LIT file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s385><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei LIT konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s386><convert.sich_konvertieren><en> If this fails, use the information previously described steps (trying to find your P65 file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s386><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei P65 konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s387><convert.sich_konvertieren><en> If, despite that, steps (trying to find your ASC file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s387><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ASC konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s388><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your DESKTHEMEPACK file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s388><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei DOCHTML konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s389><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your ACSM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s389><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ACSM konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s390><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your NOTE file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s390><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei NOTE konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s391><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your JNT file converted by someone else, and the attempt to convert it to #IS# on your own) you but it certainly will give the best result. Language English
<G-vec01132-002-s391><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei PMD konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s392><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your HTM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s392><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei HTM konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s393><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your DOCX file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s393><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei DOCX konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s394><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your PPSX file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s394><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei PPSX konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s395><convert.sich_konvertieren><en> If, described steps (trying to find your BIN file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left. You can Nederlands
<G-vec01132-002-s395><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei FH8 konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s396><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your IDEA file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s396><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei WEBARCHIVE konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s397><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your CAM file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s397><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei MDI konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s398><convert.sich_konvertieren><en> Unfortunately, if after performing the two previously described steps (trying to find your ODP file converted by someone else, and the attempt to convert it to #IS# on your own) you still have a problem with your file, then there are only a few solutions left.
<G-vec01132-002-s398><convert.sich_konvertieren><de> Bedauerlicherweise, wenn nach der Durchführung der zwei früher beschriebenen Tätigkeiten (Versuche, die eigene Datei ODP konvertiert von einer anderen Person zu finden, und Versuche, sie selbst in das Format PDF zu konvertieren) Sie noch immer ein Problem mit Ihrer Datei haben, dann sind nicht viele Lösungen übrig geblieben.
<G-vec01132-002-s418><convert.sich_konvertieren><en> Learn how to convert WRF to MP4, MOV, WMV online or offline for easy watching anytime anywhere in this article. … Jul 23,2019
<G-vec01132-002-s418><convert.sich_konvertieren><de> In diesem Artikel erfahren Sie, wie Sie WRF in MP4, MOV, WMV online oder offline konvertieren, um sie jederzeit und überall anzusehen.
<G-vec01132-002-s419><convert.sich_konvertieren><en> Type in the amount you want to convert and press the Convert button.
<G-vec01132-002-s419><convert.sich_konvertieren><de> Geben Sie jeden Betrag, den Sie konvertieren möchten, und drücken Sie die Schaltfläche "Convert".
<G-vec01132-002-s420><convert.sich_konvertieren><en> Decrease or increase the property value for each color component to convert that color channel to a darker or lighter shade of gray.
<G-vec01132-002-s420><convert.sich_konvertieren><de> Erhöhen oder reduzieren Sie den Eigenschaftswert für die einzelnen Farbkomponenten, um den Farbkanal zu einem dunkleren oder helleren Grauton zu konvertieren.
<G-vec01132-002-s421><convert.sich_konvertieren><en> Download Screenshot AnyMP4 PDF Converter Ultimate not only can convert PDF files to...
<G-vec01132-002-s421><convert.sich_konvertieren><de> Mit diesem einfachen Konverter können Sie PDF-Dateien in unterschiedliche Textformate konvertieren: Word, TXT, RTF.
<G-vec01132-002-s422><convert.sich_konvertieren><en> It can convert almost all kinds of DVD to Zune Movie / Zune Video format. DVD to Zune Movie...
<G-vec01132-002-s422><convert.sich_konvertieren><de> Mit DVD zum iPhone Umformer, können Sie fast alle Arten DVD in Format des iPhone Videos konvertieren (mp4).
<G-vec01132-002-s423><convert.sich_konvertieren><en> Learn which file formats you can use with Numbers, how to open them, and how to convert your Numbers spreadsheet into another format.
<G-vec01132-002-s423><convert.sich_konvertieren><de> Hier erfahren Sie, welche Dateiformate Sie mit Numbers verwenden können, wie Sie sie öffnen und wie Sie Ihre Numbers-Tabelle in ein anderes Format konvertieren.
<G-vec01132-002-s424><convert.sich_konvertieren><en> If you are using the UNIX-based operating system, install OpenOffice to convert rich text files and supported Microsoft Office files to PDF documents.
<G-vec01132-002-s424><convert.sich_konvertieren><de> Wenn Sie das UNIX-basierte Betriebssystem verwenden, installieren Sie OpenOffice, um Rich Text-Dateien und unterstützte Microsoft Office-Dateien in PDF-Dokumente zu konvertieren.
<G-vec01132-002-s425><convert.sich_konvertieren><en> With the help of this program you can encrypt your PDF docs with a password, edit them as easy on Microsoft Office Word, convert the PDF files to MS Word, Excel or PowerPoint, annotate the docs and create the PDF files in Excel, PowerPoint and Word.
<G-vec01132-002-s425><convert.sich_konvertieren><de> Mit Hilfe dieses Programms können Sie Ihre PDF-Dokumente mit einem Passwort verschlüsseln, sie genauso einfach wie mit Microsoft Office Word bearbeiten, sie in MS Word, Excel oder Powerpoint konvertieren, die Dokumente mit Anmerkungen versehen und die PDF-Dateien in Excel, Powerpoint und Word gestalten.
<G-vec01132-002-s426><convert.sich_konvertieren><en> New Markdown editor allows you to easily write, preview and convert Markdown content.
<G-vec01132-002-s426><convert.sich_konvertieren><de> Neuer Markdown-Editor ermöglicht Ihnen, Markdown-Inhalte auf unkomplizierte Weise zu schreiben, eine Vorschau dazu anzuzeigen und sie zu konvertieren.
<G-vec01132-002-s427><convert.sich_konvertieren><en> PDF to Word made easy: convert PDF to editable Microsoft Word files.
<G-vec01132-002-s427><convert.sich_konvertieren><de> Sie können PDF-Dateien in Word scannen oder konvertieren.
<G-vec01132-002-s428><convert.sich_konvertieren><en> Use Nitro Pro 7 to batch convert large collections of files to PDF or PDF/A with just a few clicks.
<G-vec01132-002-s428><convert.sich_konvertieren><de> Mit Nitro Pro 7 können Sie mit nur wenigen Klicks große Sammlungen von Dateien per Stapelbearbeitung in das PDF- oder PDF/A-Format konvertieren.
<G-vec01132-002-s429><convert.sich_konvertieren><en> Use FLV to MP3 Converter to convert the video to an audio file then transfer it your multimedia device and enjoy it.
<G-vec01132-002-s429><convert.sich_konvertieren><de> Mit FLV to MP3 Converter können Sie das Video in eine Audio-Datei konvertieren, diese auf Ihr Multimedia-Gerät übertragen und dort genießen.
<G-vec01132-002-s430><convert.sich_konvertieren><en> Use Océ VPconvert to automatically convert Xerox print data from VIPP to PS/PDF and easily submit it to Océ production printers.
<G-vec01132-002-s430><convert.sich_konvertieren><de> Verwenden Sie Océ DPconnect, um Xerox-Drucktaten automatisch aus Xerox DigiPath- und Xerox FreeFlow-Umgebungen zu konvertieren und an Océ Produktionsdrucksysteme zu übertragen.
<G-vec01132-002-s431><convert.sich_konvertieren><en> PDFMate PDF Converter Free PDFMate PDF Converter Free is a free application to convert PDF to plain Text, EPUB, Images, HTML, SWF, Word and PDF files.
<G-vec01132-002-s431><convert.sich_konvertieren><de> Free PDF Konverter bietet Ihnen eine benutzerfreundliche Oberfläche, sodass Sie mit Free PDF Converter PDF Dateien zu EPUB, Text, Bild, HTML und SWF sehr leicht konvertieren.
<G-vec01132-002-s432><convert.sich_konvertieren><en> If this is problematic, you can use the Add method, which enables you to specify more than one kind of time interval in a single method call and eliminates the need to convert time intervals to fractional parts of a day.
<G-vec01132-002-s432><convert.sich_konvertieren><de> Wenn dies problematisch ist, können Sie die Add -Methode verwenden, die es Ihnen ermöglicht, mehr als eine Art Zeitintervall in einem einzelnen Methodenaufruf anzugeben, und es entfällt, dass Sie Zeitintervalle in Bruchteile einer Minute konvertieren müssen.
<G-vec01132-002-s433><convert.sich_konvertieren><en> Easily convert your existing Windows Boot Camp partition to a new Parallels Desktop virtual machine.
<G-vec01132-002-s433><convert.sich_konvertieren><de> Sie können Ihre vorhandene Windows Boot Camp-Partition in eine neue virtuelle Parallels Desktop-Maschine konvertieren.
<G-vec01132-002-s435><convert.sich_konvertieren><en> If you are worried that the computer you are using for a presentation may not have PowerPoint, then use VideoPPT to convert your entire presentation to a video file.
<G-vec01132-002-s435><convert.sich_konvertieren><de> Wenn Sie sich sorgen, dass der Computer, den Sie für eine Präsentation verwenden, möglicherweise kein PowerPoint hat, dann verwenden Sie VideoPPT, um Ihre gesamte Präsentation in eine Video-Datei zu konvertieren.
<G-vec01132-002-s436><convert.sich_konvertieren><en> You can convert PDF to Word Doc without Adobe Acrobat Reader or Microsoft Word.
<G-vec01132-002-s436><convert.sich_konvertieren><de> Sie können Ihr PDF auch mit Microsoft Word in ein Word-Dokument konvertieren.
<G-vec01132-002-s133><convert.sich_umwandeln><en> You can convert MP4 file to MOV as well as to variety of other formats with free online converter.
<G-vec01132-002-s133><convert.sich_umwandeln><de> Sie können MP4-Video in MOV sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s134><convert.sich_umwandeln><en> You can convert FLV file to AAC as well as to variety of other formats with free online converter.
<G-vec01132-002-s134><convert.sich_umwandeln><de> Sie können FLV-Video in AAC sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s135><convert.sich_umwandeln><en> You can convert PNG image to PALM as well as to variety of other formats with free online converter.
<G-vec01132-002-s135><convert.sich_umwandeln><de> Sie können PNG-Bild in PALM sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s136><convert.sich_umwandeln><en> You can convert SNB file to EPUB as well as to variety of other formats with free online converter.
<G-vec01132-002-s136><convert.sich_umwandeln><de> Sie können Unterlagen in PPT sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s137><convert.sich_umwandeln><en> You can convert SFW image to GIF as well as to variety of other formats with free online converter.
<G-vec01132-002-s137><convert.sich_umwandeln><de> Sie können SFW-Bild in GIF sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s139><convert.sich_umwandeln><en> You can convert DOT file to PNG as well as to variety of other formats with free online converter.
<G-vec01132-002-s139><convert.sich_umwandeln><de> Sie können DOT-Dokument in PNG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s140><convert.sich_umwandeln><en> You can convert MP4 file to JPEG as well as to variety of other formats with free online converter.
<G-vec01132-002-s140><convert.sich_umwandeln><de> Sie können MP4-Video in JPEG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s141><convert.sich_umwandeln><en> You can convert DOC file to PNG as well as to variety of other formats with free online converter.
<G-vec01132-002-s141><convert.sich_umwandeln><de> Sie können DOC-Dokument in PNG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s142><convert.sich_umwandeln><en> You can convert 3G2 file to MP4 as well as to variety of other formats with free online converter.
<G-vec01132-002-s142><convert.sich_umwandeln><de> Sie können 3G2-Video in MP4 sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s143><convert.sich_umwandeln><en> You can convert JPEG image to CUR as well as to variety of other formats with free online converter.
<G-vec01132-002-s143><convert.sich_umwandeln><de> Sie können JPEG-Bild in CUR sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s144><convert.sich_umwandeln><en> You can convert PCD image to JPEG as well as to variety of other formats with free online converter.
<G-vec01132-002-s144><convert.sich_umwandeln><de> Sie können PCD-Bild in JPEG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s145><convert.sich_umwandeln><en> You can convert WMA file to M4A as well as to variety of other formats with free online converter.
<G-vec01132-002-s145><convert.sich_umwandeln><de> Sie können WMA-Audio in M4A sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s146><convert.sich_umwandeln><en> You can convert MKV file to M4A as well as to variety of other formats with free online converter.
<G-vec01132-002-s146><convert.sich_umwandeln><de> Sie können MKV-Video in M4A sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s147><convert.sich_umwandeln><en> You can convert M4V file to WMV as well as to variety of other formats with free online converter.
<G-vec01132-002-s147><convert.sich_umwandeln><de> Sie können M4V-Video in WMV sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s148><convert.sich_umwandeln><en> You can convert FB2 file to DOC as well as to variety of other formats with free online converter.
<G-vec01132-002-s148><convert.sich_umwandeln><de> Sie können FB2-Dokument in DOC sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s149><convert.sich_umwandeln><en> You can convert FB2 file to SDW as well as to variety of other formats with free online converter.
<G-vec01132-002-s149><convert.sich_umwandeln><de> Sie können FB2-Dokument in SDW sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s150><convert.sich_umwandeln><en> You can convert FLV file to MP4 as well as to variety of other formats with free online converter.
<G-vec01132-002-s150><convert.sich_umwandeln><de> Sie können FLV-Video in MP4 sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s151><convert.sich_umwandeln><en> You can convert PNG image to RAR as well as to variety of other formats with free online converter.
<G-vec01132-002-s151><convert.sich_umwandeln><de> Sie können PNG-Bild in RAR sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s456><convert.sich_umwandeln><en> With this software you can convert one or thousands of JPG, located in one or many different folders into a PDF.
<G-vec01132-002-s456><convert.sich_umwandeln><de> Mit dieser Software kann ein pdf Dokument in eine Wortakte umgewandelt werden, ohne das Datenformat zu verlieren oder zu ändern.
<G-vec01132-002-s457><convert.sich_umwandeln><en> But: If the level is not sufficient we will convert the supervision into a lesson! weather information
<G-vec01132-002-s457><convert.sich_umwandeln><de> Allerdings: Sollte das Level nicht für eine Supervision ausreichen, wird die Einheit in Unterricht umgewandelt.
<G-vec01132-002-s458><convert.sich_umwandeln><en> Not only is it possible to convert patent applications into utility model applications and vice versa, but, quite importantly, it is also possible to branch off utility models from patent applications (with the patent application remaining valid independently).
<G-vec01132-002-s458><convert.sich_umwandeln><de> Von besonderer Bedeutung ist, dass Patent- und Gebrauchsmusteranmeldungen nicht nur jeweils ineinander umgewandelt werden können, sondern auch, dass es möglich ist, aus Patentanmeldungen Gebrauchsmuster abzuzweigen (wobei die Patentanmeldung unabhängig davon weiterverfolgt werden kann).
<G-vec01132-002-s459><convert.sich_umwandeln><en> All are simple, only clicking on the Export PDF button will convert your pert chart template into PDF, with no clarity loss.
<G-vec01132-002-s459><convert.sich_umwandeln><de> Alles ist ganz einfach, mit nur ein Klick auf den Knopf PDF exportieren wird Ihre PERT-Diagrammvorlage in eine PDF-Datei umgewandelt, ohne dass die Übersichtlichkeit leidet.
<G-vec01132-002-s460><convert.sich_umwandeln><en> Four queen berths and one cabin with two singles berths which can convert to a queen.
<G-vec01132-002-s460><convert.sich_umwandeln><de> Vier Queen-Betten und eine Kabine mit zwei Einzelbetten, die in eine Königin umgewandelt werden können.
<G-vec01132-002-s461><convert.sich_umwandeln><en> • In addition, RMX will issue to Mindoro 50,000,000 Performance Shares that will convert to full voting shares if RMX upgrades the Indicated Resource at Batangas to 600,000 oz of gold and completes a scoping study that demonstrates a viable gold mining project based on over 50% of the Indicated Resource converting to a Probable Ore Reserve or equivalent within 12 months of completing the transaction.
<G-vec01132-002-s461><convert.sich_umwandeln><de> • Zusätzlich wird RMX auf Mindoro 50.000.000 Performance-Aktien übertragen, die zu voll stimmberechtigten Aktien umgewandelt werden, wenn RMX die angezeigten Ressourcen bei Batangas zu 600.000 Unzen Gold aufwertet und eine Scoping-Studie durchführt, mit der die Machbarkeit eines Goldförderprojekts demonstriert wird, in dem innerhalb von 12 Monaten nach Abschluss der Transaktion über 50 % der angezeigten Ressourcen in wahrscheinliche Erzreserven oder eine gleichwertige Kategorie umgewandelt werden.
<G-vec01132-002-s462><convert.sich_umwandeln><en> Three Bedroom Luxury Apartment (Sleeps 6): This apartment has three bedrooms with King-size beds that can convert to twin beds.
<G-vec01132-002-s462><convert.sich_umwandeln><de> Diese Wohnung verfügt über drei Schlafzimmer mit Kingsize-Betten, die in zwei Einzelbetten umgewandelt werden können.
<G-vec01132-002-s463><convert.sich_umwandeln><en> Carbohydrates, such as pasta, convert easily to sugar.
<G-vec01132-002-s463><convert.sich_umwandeln><de> Kohlenhydrate wie Pasta werden leicht zu Zucker umgewandelt.
<G-vec01132-002-s464><convert.sich_umwandeln><en> Here, you can convert individual or multiple suggestions into purchase orders in one simple step.
<G-vec01132-002-s464><convert.sich_umwandeln><de> Hier können einzelne oder mehrere Vorschläge auf Knopfdruck in Bestellungen umgewandelt werden.
<G-vec01132-002-s465><convert.sich_umwandeln><en> In spite of its recent reform, FRONTEX remains, for example, a resource agency since it is appropriate to convert the agency into a real EU border police.
<G-vec01132-002-s465><convert.sich_umwandeln><de> Trotz seiner kürzlichen Reform bleibt beispielsweise FRONTEX eine Agentur für Ressourcen, obwohl sie in eine wirkliche Polizei für die Außengrenzen der Union umgewandelt werden sollte.
<G-vec01132-002-s466><convert.sich_umwandeln><en> One main focus of the product range is the hydraulic briquetting press produced by SPÄNEX, used to convert chips and dust into valuable briquettes during production processes.
<G-vec01132-002-s466><convert.sich_umwandeln><de> Einen Schwerpunkt des Produktprogramms stellen die von SPÄNEX hergestellten hydraulischen Brikettierpressen dar, mit denen die bei Produktionsprozessen anfallenden und abgesaugten Späne und Stäube in werthaltige Briketts umgewandelt werden.
<G-vec01132-002-s467><convert.sich_umwandeln><en> Yeast causes fermentable sugars to convert into alcohol and carbon dioxide.
<G-vec01132-002-s467><convert.sich_umwandeln><de> Hefe sorgt dafür, daß vergärbarer Zucker in Alkohol und Kohlensäure umgewandelt wird.
<G-vec01132-002-s468><convert.sich_umwandeln><en> "Adjust bids by placement" sets different bids by placement, and "dynamic bids - down only" adjusts bids down from there for opportunities where a click is less likely to convert to a sale.
<G-vec01132-002-s468><convert.sich_umwandeln><de> „Gebote nach Platzierung anpassen“ legt verschiedene Gebote nach Platzierung fest und „Dynamische Gebote - nur nach unten“ passt Gebote nach unten für Gelegenheiten an, bei denen weniger wahrscheinlich ist, dass sie bei einem Klick in einen Verkauf umgewandelt werden.
<G-vec01132-002-s469><convert.sich_umwandeln><en> When we no longer need your information for our purposes or legal obligations, we will destroy, delete or erase that information or convert it into an anonymous form.
<G-vec01132-002-s469><convert.sich_umwandeln><de> Wenn wir Ihre Daten nicht mehr für unsere Zwecke oder gesetzlichen Pflichten benötigen, werden diese Informationen von uns vernichtet, gelöscht oder entfernt oder in eine anonymisierte Form umgewandelt.
<G-vec01132-002-s470><convert.sich_umwandeln><en> (The Life Divine, p. 1108) In practice, this is the first preoccupation for creating a new earth-life, for bringing in a new order of beings - to create the inner life and then to convert our thought, feeling and action in the dynamic world into perfect instrument of that inner realisation.
<G-vec01132-002-s470><convert.sich_umwandeln><de> (The Life Divine, p. 1108) In der Praxis wird damit erstmals neues Leben auf der Erde erschaffen und eine neue Ordnung von Lebewesen eingeführt – nach der Gestaltung des Innenlebens werden die Gedanken, Gefühle und Handlungen in der dynamischen Welt in ein perfektes Werkzeug dieser inneren Erkenntnis umgewandelt.
<G-vec01132-002-s471><convert.sich_umwandeln><en> Powerful upright vacuum cleaner which is easy to convert into a powerful handheld unit.
<G-vec01132-002-s471><convert.sich_umwandeln><de> Leistungsstarker Staubsauger welcher einfach in einen Handstaubsauger umgewandelt werden kann.
<G-vec01132-002-s472><convert.sich_umwandeln><en> For instance, you can set the software to send the received data to the printer or convert them into a PDF file.
<G-vec01132-002-s472><convert.sich_umwandeln><de> Zum Beispiel können Sie die Software so einstellen, dass empfangene Daten zum Drucker geschickt oder in eine PDF-Datei umgewandelt werden.
<G-vec01132-002-s473><convert.sich_umwandeln><en> NOTE: The double cabins can convert to twin layouts.
<G-vec01132-002-s473><convert.sich_umwandeln><de> HINWEIS: Die Doppelkabinen können in Twin-Layouts umgewandelt werden.
<G-vec01132-002-s474><convert.sich_umwandeln><en> All are quite simple, only clicking on the Export PDF button will convert your garden design template into PDF.
<G-vec01132-002-s474><convert.sich_umwandeln><de> Alles ist ganz einfach, mit nur einem Klick auf den Knopf PDF exportieren wird Ihre Gartengestaltungsvorlage in PDF umgewandelt.
<G-vec01132-002-s513><convert.sich_umwandeln><en> Primetime uses a state-of-the-art drinking water treatment on board, with which we convert seawater into purified drinking water.
<G-vec01132-002-s513><convert.sich_umwandeln><de> Wir verwenden eine „state of the art“ Trinkwasser Aufbereitung an Board, mit der wir Meerwasser in erstklassiges Trinkwasser umwandeln.
<G-vec01132-002-s514><convert.sich_umwandeln><en> It's the best DVD ripper, which can convert DVD and all popular video formats to Apple TV (MP4/H.264 up to 1280x720).
<G-vec01132-002-s514><convert.sich_umwandeln><de> Es ist die beste DVD-Ripper, die DVD und alle gängigen Video-Formate zu Apple TV (MP4/H.264 bis zu 1280x720) umwandeln kann.
<G-vec01132-002-s515><convert.sich_umwandeln><en> It can convert toxic gases into water vapour and less harmful gases.
<G-vec01132-002-s515><convert.sich_umwandeln><de> Es kann giftige Gase in Wasserdampf und weniger schädliche Gase umwandeln.
<G-vec01132-002-s516><convert.sich_umwandeln><en> Type the number of Bushels per year (U.S.) you want to convert in the text box, to see the results in the table.
<G-vec01132-002-s516><convert.sich_umwandeln><de> Geben Sie die Anzahl der Million Gallonen pro Tag (US-Flüssigkeit) ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec01132-002-s517><convert.sich_umwandeln><en> We can convert both into a ready-made solution within a very short period of time.
<G-vec01132-002-s517><convert.sich_umwandeln><de> Wir können beides innerhalb kürzester Zeit in eine fertige Lösung umwandeln.
<G-vec01132-002-s518><convert.sich_umwandeln><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec01132-002-s518><convert.sich_umwandeln><de> Geben Sie die Anzahl der Rotation ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec01132-002-s519><convert.sich_umwandeln><en> A minimum of 200 EnergyPoints are required to convert points to money.
<G-vec01132-002-s519><convert.sich_umwandeln><de> Mindestens 200 EnergyPoints werden benötigt, um Punkte in Geld umwandeln zu können.
<G-vec01132-002-s520><convert.sich_umwandeln><en> All the forms of energy used that consume or convert a certain initial product, which does not self-renew, are called non-renewable: in the case of oil, we use oil until the resource ends (within a few years).
<G-vec01132-002-s520><convert.sich_umwandeln><de> Alle verwendeten Energieformen, die ein bestimmtes Ausgangsprodukt verbrauchen oder umwandeln, das sich nicht selbst erneuert, werden als nicht erneuerbar bezeichnet: Bei Öl verwenden wir Öl bis zum Ende der Ressource (innerhalb weniger Jahre).
<G-vec01132-002-s521><convert.sich_umwandeln><en> Or you let convert your commission into MMOGA balance in order to buy directly games, FIFA Coins and more at MMOGA.
<G-vec01132-002-s521><convert.sich_umwandeln><de> Oder Sie lassen Ihre Provision in MMOGA Guthaben umwandeln, um direkt Games, FIFA Coins und mehr bei MMOGA zu kaufen.
<G-vec01132-002-s522><convert.sich_umwandeln><en> • It can also convert surround sound audio as well.
<G-vec01132-002-s522><convert.sich_umwandeln><de> • Es kann auch Surround-Sound-Audio umwandeln.
<G-vec01132-002-s523><convert.sich_umwandeln><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec01132-002-s523><convert.sich_umwandeln><de> Geben Sie die Anzahl der kcal ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec01132-002-s524><convert.sich_umwandeln><en> Now I convert all my files easily and I can watch them with my family on the TV screen.
<G-vec01132-002-s524><convert.sich_umwandeln><de> Jetzt kann ich ganz einfach meine Aufnahmen umwandeln und sie dann mit meiner Familie auf unserem Fernseher ansehen.
<G-vec01132-002-s525><convert.sich_umwandeln><en> Note: if you want to convert several input files, all of them must have the same aspect values.
<G-vec01132-002-s525><convert.sich_umwandeln><de> Hinweis: Wenn Sie mehrere Eingabedateien umwandeln möchten, müssen sie das gleiche Bildseitenverhältnis haben.
<G-vec01132-002-s526><convert.sich_umwandeln><en> So-called bifacial solar cells can convert incident light into electrical current both on their fronts and backs.
<G-vec01132-002-s526><convert.sich_umwandeln><de> Sogenannte bifaziale Solarzellen können sowohl auf der Vorder- als auch auf der Rückseite einfallendes Licht in elektrischen Strom umwandeln.
<G-vec01132-002-s527><convert.sich_umwandeln><en> It can smoothly work with NSF file generated by IBM Lotus Notes 9.0 and earlier versions of it and smoothly convert them into MBOX file format.
<G-vec01132-002-s527><convert.sich_umwandeln><de> Es kann problemlos mit der NSF-Datei arbeiten, die von IBM Lotus Notes 9.0 und früheren Versionen erstellt wurde, und reibungslos in das MBOX-Dateiformat umwandeln.
<G-vec01132-002-s528><convert.sich_umwandeln><en> XRechnung has published open source XSLT style sheets to convert EN16931 XML to HTML, which also work on ZUGFeRD 2 and Factur-X files.
<G-vec01132-002-s528><convert.sich_umwandeln><de> Die XRechnung hat open-source XSLT style sheets veröffentlicht, die EN16931 XML in HTML umwandeln, und die auch mit ZUGFeRD 2 und Factur-X-Dateien funktionieren.
<G-vec01132-002-s529><convert.sich_umwandeln><en> The decimal integer you want to convert.
<G-vec01132-002-s529><convert.sich_umwandeln><de> Die Zahl, die Sie umwandeln möchten.
<G-vec01132-002-s530><convert.sich_umwandeln><en> About 5% of daily turnover is from companies and governments that buy or sell products and services in a foreign country or must convert profits made in foreign currencies into their domestic currency.
<G-vec01132-002-s530><convert.sich_umwandeln><de> Ungefähr 5 % des täglichen Umsatzes sind von Gesellschaften und Regierungen, die kaufen oder Produkte und Dienstleistungen in einem fremden Land verkaufen oder Gewinne umwandeln müssen, die in fremden Währungen in ihrer Innenwährung gemacht sind.
<G-vec01132-002-s531><convert.sich_umwandeln><en> I have a block that only contains images, but I cannot convert it into a product recommendation.
<G-vec01132-002-s531><convert.sich_umwandeln><de> Ich habe einen Block, der nur Bilder enthält, aber ich kann ihn nicht in eine Produktempfehlung umwandeln.
<G-vec01132-002-s532><convert.sich_umwandeln><en> A fluid power system refers to a mechanism (mechanical or electromechanical) that is used to convert energy (mostly mechanical) into fluid energy.
<G-vec01132-002-s532><convert.sich_umwandeln><de> Ein Fluidtechnik-System verwendet einen Mechanismus (mechanisch oder elektromechanisch), der Energie (größtenteils mechanisch) in Fluidenergie umwandelt.
<G-vec01132-002-s533><convert.sich_umwandeln><en> In order to safely use electric devices such as TVs, laptops or coffee machines on the road, you’ll need an inverter that will convert 12V or 24V direct current into 230V alternating current - e.g. in a camper van, motor home, allotment or boat.
<G-vec01132-002-s533><convert.sich_umwandeln><de> Um unterwegs elektrische Geräte wie Fernseher, Laptops oder Kaffeemaschinen wie gewohnt sicher betreiben zu können, braucht man einen solchen Spannungswandler, der 12 V oder 24 V Gleichstrom in 230 V Wechselstrom umwandelt – beispielsweise im Wohnmobil, im Campingbus, im Schrebergarten oder auf einem Boot.
<G-vec01132-002-s534><convert.sich_umwandeln><en> You can also try online video converter to convert your OGG files to MP3, if you don't want to install a computer program.
<G-vec01132-002-s534><convert.sich_umwandeln><de> Sie können es auch mit einem kostenlosen Online Videokonverter versuchen, der Ihre OGG Dateien in MP3 umwandelt, wenn Sie kein Computerprogramm installieren möchten.
<G-vec01132-002-s535><convert.sich_umwandeln><en> AVI MPEG WMV RM to MP3 Converter is a powerful tool to convert all video and audio files to MP3, WAV, WMA and OGG formats.
<G-vec01132-002-s535><convert.sich_umwandeln><de> Direct MIDI to MP3 Converter ist eine einfache Audio-Utility, die MIDI-Dateien in MP3-, WAV-, WMA- und OGG-Format umwandelt.
<G-vec01132-002-s536><convert.sich_umwandeln><en> Nowadays, due to the advantages of alternating current in terms of transformation and transport possibilities, the transport and distribution networks use almost exclusively alternating current. In the case of applications that need direct current, as in the case of rail using the third rail system, the alternating current arrives at a substation that uses a rectifier to convert it into direct current.
<G-vec01132-002-s536><convert.sich_umwandeln><de> Die Transport- und Verteilungsnetze nutzen heute aufgrund der Vorteile von Wechselstrom hinsichtlich der Transformations- und Transportmöglichkeiten fast ausschließlich Wechselstrom, bei Anwendungen, die Gleichstrom benötigen, wie bei der Schiene Durch den Einsatz des dritten Schienensystems gelangt der Wechselstrom in eine Umspannstation, die ihn mit einem Gleichrichter in Gleichstrom umwandelt.
<G-vec01132-002-s537><convert.sich_umwandeln><en> When you convert the said numbers to performance, you'll play games like Battlefield 1, Overwatch and Rocket League in Full HD resolution at about 50FPS on new CPUs.
<G-vec01132-002-s537><convert.sich_umwandeln><de> Wenn man die Sprache der Zahlen in Performance umwandelt, werden Sie auf den neuen CPUs Spiele wie Battlefield 1, Overwatch und Rocket League in Full HD-Auflösung mit etwa 50 FPS spielen.
<G-vec01132-002-s538><convert.sich_umwandeln><en> Actually it is a short movie, a western, which convert the lyrics into living pictures.
<G-vec01132-002-s538><convert.sich_umwandeln><de> Eigentlich ist es ein kurzer Film, ein Western, der den Songtext in bewegte Bilder umwandelt.
<G-vec01132-002-s539><convert.sich_umwandeln><en> The advantage of energy generation by a fuel cell compared to conventional combustion is that the fuel cell can convert chemical energy directly into electrical energy and does not first convert into heat (thermal energy), which must then be converted into electrical energy by a generator.
<G-vec01132-002-s539><convert.sich_umwandeln><de> Der Vorteil der Energiegewinnung durch eine Brennstoffzelle gegenüber einer herkömmlichen Verbrennung besteht darin, dass die Brennstoffzelle chemische Energie direkt in elektrische Energie umwandeln kann und nicht erst in Wärme (thermische Energie) umwandelt, die dann erst durch einen Generator in elektrische Energie gewandelt werden muss.
<G-vec01132-002-s540><convert.sich_umwandeln><en> For more details, please refer to tutorial: How to Convert iTunes Audiobooks to AAC with chapters kept.
<G-vec01132-002-s540><convert.sich_umwandeln><de> Weitere Details finden Sie im Tutorial: Wie man iTunes-Hörbücher in AAC umwandelt, wobei die Kapitel beibehalten werden.
<G-vec01132-002-s541><convert.sich_umwandeln><en> This indicates it is a male hormonal agent that does not convert testosterone into estrogen.
<G-vec01132-002-s541><convert.sich_umwandeln><de> Das bedeutet, es ist ein männlicher Hormonmittel, das nicht Testosteron in Östrogen umwandelt.
<G-vec01132-002-s542><convert.sich_umwandeln><en> Any future benefactor, as yet completely unknown, would be expected to buy into the Dada movement and not just convert the building into apartments.
<G-vec01132-002-s542><convert.sich_umwandeln><de> Von einem künftigen Käufer wird erwartet, dass er oder sie in die Dada-Bewegung investiert und nicht einfach das Gebäude in ein Mehrfamilienhaus umwandelt.
<G-vec01132-002-s543><convert.sich_umwandeln><en> In order to simplify your product requirements, we have designed a product configurator for you, which will step-by-step ask you for the most important product parameters and finally convert them into a request.
<G-vec01132-002-s543><convert.sich_umwandeln><de> Konfigurator Zur Vereinfachung Ihrer Produktanfragen haben wir für Sie einen Produktkonfigurator gestaltet, welcher von Ihnen Schritt für Schritt die wichtigsten Produktparameter abfragt und abschließend in eine Anfrage umwandelt.
<G-vec01132-002-s544><convert.sich_umwandeln><en> These same principles of tomographic imaging can also be applied to radionuclide scanning, in which the sensors for emitted radiation encircle the patient and computer techniques convert the sensor data into tomographic images; examples include single-photon emission CT (SPECT—see Radionuclide Scanning: Single-photon emission CT (SPECT)) and positron-emission tomography (PET—see Positron Emission Tomography (PET)).
<G-vec01132-002-s544><convert.sich_umwandeln><de> Dieselben Prinzipien der tomographischen Bildgebung können auch beim Radionuklid- Scannen verwendet werden, bei der die Sensoren für die emittierte Strahlung den Patienten umgeben und ein Computer die Sensordaten in tomographische Bilder umwandelt; Beispiele dafür sind das SPECT— Radionuklidszintigraphie: Einzel-positron-emission tomography).
<G-vec01132-002-s545><convert.sich_umwandeln><en> Get help from this solution and learn how to convert 4K to 1080P easily.
<G-vec01132-002-s545><convert.sich_umwandeln><de> Holen Sie sich Hilfe von dieser Lösung und lernen Sie, wie man 4K in 1080P einfach umwandelt.
<G-vec01132-002-s546><convert.sich_umwandeln><en> – Underneath the hob’s surface that is generally made of ceramic glass, an electronic generator shall be provided to convert power from ordinary to high frequency to speed some spiral coils;
<G-vec01132-002-s546><convert.sich_umwandeln><de> – unter den Kochfeldern, die gewöhnlich aus Glaskeramik bestehen, befindet sich ein Elektronikgenerator, der Strom von Normal- in Hochfrequenz umwandelt und ihn in spiralenförmige Spulen leitet.
<G-vec01132-002-s547><convert.sich_umwandeln><en> Just get the brief guide below to learn how to convert DV to MP4 for Windows (Windows 10 included).
<G-vec01132-002-s547><convert.sich_umwandeln><de> Bekommen Sie einfach die kurze Anleitung unten, um zu lernen, wie man DV in MP4 für Windows umwandelt (Windows 10 inklusive).
<G-vec01132-002-s548><convert.sich_umwandeln><en> Normally, before an EV with on-board charger can be used in this way, it would first have to be fitted with a power inverter (to convert the DC current into AC current), at a cost of several thousand euros.
<G-vec01132-002-s548><convert.sich_umwandeln><de> Bei Fahrzeugen mit On-Board-Charger ist dies in der Regel aber nur mit einem zusätzlichen, mehrere Tausend Euro teuren Wechselrichter möglich, der den Gleichstrom in Wechselstrom umwandelt.
<G-vec01132-002-s549><convert.sich_umwandeln><en> If we want to use this energy on a targeted basis during physical and mental activity, we have to know how our bodies convert food into energy.
<G-vec01132-002-s549><convert.sich_umwandeln><de> Wenn wir diese Energie bei körperlichen und geistigen Tätigkeiten gezielt einsetzen wollen, müssen wir wissen, wie unser Körper Nahrung in Energie umwandelt.
<G-vec01132-002-s550><convert.sich_umwandeln><en> This indicates it is a male hormonal agent that does not convert testosterone right into estrogen.
<G-vec01132-002-s550><convert.sich_umwandeln><de> Dies zeigt, es ist ein männliches Hormon, das nicht Testosteron in Östrogen umwandelt.
<G-vec01132-002-s608><convert.sich_umwandeln><en> However, they offer for an opportunity to convert to WAV or MP3 formats.
<G-vec01132-002-s608><convert.sich_umwandeln><de> Allerdings wird einem die Möglichkeit gegeben, WAV-Dateien in MP3-Dateien umzuwandeln.
<G-vec01132-002-s609><convert.sich_umwandeln><en> The amino acid, L-carnitine signals the body to convert the kept fat into power.
<G-vec01132-002-s609><convert.sich_umwandeln><de> Die Aminosäure, L-Carnitin signalisiert der Körper das Fett gehalten in Strom umzuwandeln.
<G-vec01132-002-s610><convert.sich_umwandeln><en> They convert carbon dioxide into organic compounds with the energy from hydrogen sulphide, a common compound in the sediments with the smell of rotten eggs.
<G-vec01132-002-s610><convert.sich_umwandeln><de> Sie nutzen die Energie aus Schwefelwasserstoff – jener Verbindung, die den Geruch von faulen Eiern hervorruft – im umgebenden Sediment, um Kohlendioxid in organische Verbindungen umzuwandeln.
<G-vec01132-002-s611><convert.sich_umwandeln><en> SOLUTION Leverage RichRelevance’s AI-based Personalization Cloud to convert digital interactions and disparate user data into personalized experiences.
<G-vec01132-002-s611><convert.sich_umwandeln><de> Nutzen Sie die, auf künstlicher Intelligenz basierende Personalisierungs-Cloud von RichRelevance, um digitale Interaktionen und die unterscheidlichsten Daten der Nutzer in personalisierte Erlebnisse umzuwandeln.
<G-vec01132-002-s612><convert.sich_umwandeln><en> Your brown adipose tissue is able to convert 100% of the energy supplied to heat and thereby increases your body temperature.
<G-vec01132-002-s612><convert.sich_umwandeln><de> Das braune Fettgewebe ist dazu in der Lage, 100% der zugeführten Energie in Wärme umzuwandeln und hierdurch die Körpertemperatur zu erhöhen.
<G-vec01132-002-s613><convert.sich_umwandeln><en> If you know your bra size, most merchants will be able to help you convert your bra size to a binder size.
<G-vec01132-002-s613><convert.sich_umwandeln><de> Wenn du deine BH-Größe kennst, können dir die meisten Händler helfen, deine BH-Größe in die Größe für ein Band umzuwandeln.
<G-vec01132-002-s614><convert.sich_umwandeln><en> If your blog gets 5000 visitors a month and you manage to convert even 200 of them into subscribers, then you’ll add 2400 extra people that serve as a source of repeat traffic each year.
<G-vec01132-002-s614><convert.sich_umwandeln><de> Wenn Dein Blog 5.000 Besucher pro Monat erzielt und es Dir gelingt 200 davon in Abonnenten umzuwandeln, dann fügst Du 2.400 zusätzliche Leute hinzu, die jedes Jahr als Quelle für wiederholten Traffic dienen.
<G-vec01132-002-s615><convert.sich_umwandeln><en> 19. September 2019 While last month the Ministry of Public Finance published a draft Government Ordinance obliging underperforming companies to convert their debts to associates and shareholders into stocks and shares, this month the authorities have revised the legal provisions in question.
<G-vec01132-002-s615><convert.sich_umwandeln><de> Während das Finanzministerium im vergangenen Monat den Entwurf einer Regierungsverordnung veröffentlichte, wonach leistungsschwache Unternehmen verpflichtet sein sollen, ihre Verbindlichkeiten gegenüber verbundenen Unternehmen und Gesellschaftern in Aktien und Anteile umzuwandeln, haben die Behörden die betreffenden rechtlichen Bestimmungen nun abgeschwächt – die Umwandlung wird nicht mehr verpflichtend sein, sondern optional.
<G-vec01132-002-s616><convert.sich_umwandeln><en> We want to help you convert a right way to support your ideas and innovations into the product / service and speed up implementation process.
<G-vec01132-002-s616><convert.sich_umwandeln><de> Wir möchten Ihnen dabei helfen, einen richtigen Weg um Ihre Ideen und Innovationen ins Produkt/Dienstleistung umzuwandeln und Realisierungsprozess zu beschleunigen.
<G-vec01132-002-s617><convert.sich_umwandeln><en> Once the screen capture has been taken, Screen Recording allows you to convert the video format to the most useful format for the users (AVI, MKV, MP4, WMF, SWF,...), to make the most of it.
<G-vec01132-002-s617><convert.sich_umwandeln><de> Sobald der Bildschirm eingefangen wurde, ermöglicht Ihnen Screen Recording, das Videoformat in das Format umzuwandeln,das für den Benutzer am nützlichsten erscheint(AVI,MKV,MP4,WMF,SWF...).
<G-vec01132-002-s618><convert.sich_umwandeln><en> There're increasingly more people looking for ways to convert M2TS to MKV in various forums, either for save up space for storage or being compatibe with media player.
<G-vec01132-002-s618><convert.sich_umwandeln><de> Es gibt ein steigende Anzahl von Leuten, die in Foren nach Methoden suchen, um M2TS in MKV umzuwandeln, entweder weil Sie Speicherplatz sparen oder Dateien mit Ihrem Media-Player kompatibel machen wollen.
<G-vec01132-002-s619><convert.sich_umwandeln><en> In order to convert the bonus in to cash and in order to qualify for cash out, the bonus needs to be wagered at least five times against odds 2.0 or higher.
<G-vec01132-002-s619><convert.sich_umwandeln><de> Um den Bonus in Bargeld umzuwandeln und um sich für Bargeld zu qualifizieren, muss der Bonus mindestens fünf Mal gegen die Quote 2,0 oder höhergesetzt werden.
<G-vec01132-002-s620><convert.sich_umwandeln><en> Library to convert HTML code to PDF files.
<G-vec01132-002-s620><convert.sich_umwandeln><de> Bibliothek um HTML-Code in PDF-Dateien umzuwandeln.
<G-vec01132-002-s621><convert.sich_umwandeln><en> The Secure Site Seal helps you convert visitors into paying customers by increasing the visible trust in your website.
<G-vec01132-002-s621><convert.sich_umwandeln><de> Das Secure Site Seal hilft Ihnen, Besucher in zahlende Kunden umzuwandeln, indem es das sichtbare Vertrauen in Ihre Website vergrößert.
<G-vec01132-002-s622><convert.sich_umwandeln><en> The FSC investigates novel pathways to convert renewable energy, for example from biomass or carbon dioxide, into liquid energy carriers, the so-called bio-hybrid fuels, and prepare them for utilization in the mobility sector.
<G-vec01132-002-s622><convert.sich_umwandeln><de> Der ab Januar 2019 geförderte Exzellenzcluster FSC erforscht innovative und erfolgversprechende Wege, um erneuerbare Energie mit biomassebasierten Rohstoffen und CO2 in flüssige Energieträger mit hoher Energiedichte, die „Bio-hybrid Fuels“, umzuwandeln und für den Mobilitätssektor nutzbar zu machen.
<G-vec01132-002-s623><convert.sich_umwandeln><en> This can be used to convert the event to a local time.
<G-vec01132-002-s623><convert.sich_umwandeln><de> Dies kann verwendet werden, um das Ereignis in eine lokale Zeit umzuwandeln.
<G-vec01132-002-s624><convert.sich_umwandeln><en> However, it is possible to convert your MQL EA or Indicator code to C# by following the link.
<G-vec01132-002-s624><convert.sich_umwandeln><de> Es ist jedoch möglich, Ihren MQ4-Code für Ihren EA oder Ihren Indikator in C# umzuwandeln, wenn Sie auf folgenden Link klicken.
<G-vec01132-002-s625><convert.sich_umwandeln><en> It is no longer necessary to convert to 24 Bit RGB.
<G-vec01132-002-s625><convert.sich_umwandeln><de> Es ist nicht mehr notwendig, sich zu 24-Bit-RGB umzuwandeln.
<G-vec01132-002-s626><convert.sich_umwandeln><en> The ability to access safety system data via the Internet of Things (IoT) in real time and to convert this into meaningful information unlocks enormous potential.
<G-vec01132-002-s626><convert.sich_umwandeln><de> Die Möglichkeit, über das Internet der Dinge (IoT) in Echtzeit auf Sicherheitssystemdaten zuzugreifen und diese in aussagekräftige Informationen umzuwandeln, birgt ein großes Potenzial.
<G-vec01132-002-s627><convert.sich_verwandeln><en> Full integration with your blog(s) to convert posts into emails.
<G-vec01132-002-s627><convert.sich_verwandeln><de> Komplette Integration mit Ihren Blogs, um Posts in E-Mails verwandeln zu können.
<G-vec01132-002-s628><convert.sich_verwandeln><en> And when you don't need the extra storage, unclip the front cover and convert it into a slim, lightweight case.
<G-vec01132-002-s628><convert.sich_verwandeln><de> Und wenn Sie den zusätzlichen Platz nicht benötigen, klipsen Sie die vordere Abdeckung ab und verwandeln die Hülle in eine schlanke, leichte Hülle.
<G-vec01132-002-s629><convert.sich_verwandeln><en> Use OCR (Optical Character Recognition) to convert paper files in up to 25 languages into digital, editable and searchable files.
<G-vec01132-002-s629><convert.sich_verwandeln><de> Nutzen Sie OCR (optische Zeichenerkennung) um Papierdokumente in bis zu 25 Sprachen in digitale, bearbeitbare und durchsuchbare Dateien zu verwandeln.
<G-vec01132-002-s630><convert.sich_verwandeln><en> Our goal should be to convert these into real and positive benefits, such as for the local communities we visit, where we can help generate economic opportunities and provide the stimulus for long-term sustainability.
<G-vec01132-002-s630><convert.sich_verwandeln><de> Tourismus hat weitreichende Folgen.Diese Folgen sollten wir verwandeln in wirkliches und positives Wohlergehen für die lokalen Gemeinschaften, die wir besuchen, denen wir dabei helfen können, ökonomische Fortschritte zu erreichen und Samen für nachhaltiges Tun zu legen.
<G-vec01132-002-s631><convert.sich_verwandeln><en> After wrapping my mind around the analytics side of things, I knew what I needed to do to convert my social media traffic.
<G-vec01132-002-s631><convert.sich_verwandeln><de> Als ich mich aber endlich an die Kennzahlen gewöhnt hatte, wusste ich, was ich tun musste, um meinen Social-Media-Traffic in Kunden zu verwandeln.
<G-vec01132-002-s632><convert.sich_verwandeln><en> The managers of Central Suites Barcelona, Belén and Pedro, are not only descendants of the initial owners of the house, but also keen travellers. Having completed a one year round the world trip, they made every effort to convert these suites into ideal apartments, the kind that they would like to find on their own travels.
<G-vec01132-002-s632><convert.sich_verwandeln><de> Die Geschäftsführer der Central Suites Barcelona, Belén und Pedro, Nachfahren der ursprünglichen Besitzer und passionierte Reisende, haben nach einer einjährigen Weltreise viele Anstrengungen unternommen, diese Suites in das ideale Appartement zu verwandeln, so wie sie es gerne auf ihren Reisen vorgefunden hätten.
<G-vec01132-002-s633><convert.sich_verwandeln><en> Using the dongle, you can convert your docking station into a wireless speaker you can control using your iPhone, Android smartphone or tablet from the comfort of your settee.
<G-vec01132-002-s633><convert.sich_verwandeln><de> Mit dem Dongle verwandeln Sie zudem Ihre Docking-Station in einen kabellosen Lautsprecher und können Sie bequem per iPhone, Android Smartphone oder Tablet vom Sofa aus bedienen.
<G-vec01132-002-s634><convert.sich_verwandeln><en> The option to convert frequent users into paying users.
<G-vec01132-002-s634><convert.sich_verwandeln><de> Die Möglichkeit, häufige Nutzer in zahlende Nutzer zu verwandeln.
<G-vec01132-002-s635><convert.sich_verwandeln><en> But we can convert the crows into swans.
<G-vec01132-002-s635><convert.sich_verwandeln><de> Doch wir können die Krähen in Schwäne verwandeln.
<G-vec01132-002-s636><convert.sich_verwandeln><en> This independence means that we are able to convert a design into a completed product very quickly.
<G-vec01132-002-s636><convert.sich_verwandeln><de> Aufgrund dieser Unabhängigkeit sind wir in der Lage ein Design sehr rasch in ein vollendetes Produkt zu verwandeln.
<G-vec01132-002-s637><convert.sich_verwandeln><en> PLAYTIME - ANYTIME Convert any smooth surface to a safari play time with the Bumbo Playtop Safari Suction Tray.
<G-vec01132-002-s637><convert.sich_verwandeln><de> Verwandeln Sie mit dem Spielaufsatz Safari, dem Aufsatz mit Saughaftung, jede glatte Oberfläche in eine Safari-Spielzeit.
<G-vec01132-002-s638><convert.sich_verwandeln><en> A few years later the EU bureaucracy had managed to convert this vision into a so-called “balanced approach”, based on a consensus without vision, taste, smell or color, grey as the skies above Brussels.
<G-vec01132-002-s638><convert.sich_verwandeln><de> Nach ein paar Jahren hatte es die EU-Bürokratie geschafft, diese Vision in einen sogenannten „ausgewogenen Ansatz“ („balanced approach“) zu verwandeln, dessen kleinster gemeinsamer Nenner ohne Vision, Kraft und Farbe war, grau wie der Himmel über Brüssel.
<G-vec01132-002-s639><convert.sich_verwandeln><en> It can be invisibly built into displays and convert them into payment and authentication interfaces.
<G-vec01132-002-s639><convert.sich_verwandeln><de> Die Antenne kann unsichtbar in Displays verbaut werden und diese in Zahlungs- und Authentifizierungsschnittstellen verwandeln.
<G-vec01132-002-s640><convert.sich_verwandeln><en> This is useful if you want to convert them into an HDR by hand later with another program.
<G-vec01132-002-s640><convert.sich_verwandeln><de> Das ist sinnvoll, wenn ihr diese später mit einem anderen Programm händisch in ein HDR zu verwandeln wollt.
<G-vec01132-002-s641><convert.sich_verwandeln><en> You are able “to weave bonds of belonging and togetherness which convert overcrowding into an experience of community in which the walls of the ego are torn down and the barriers of selfishness overcome” (ibid., 149).
<G-vec01132-002-s641><convert.sich_verwandeln><de> Ihr seid fähig, »Bande der Zugehörigkeit und des Zusammenlebens zu knüpfen, die das Gedränge in eine Gemeinschaftserfahrung verwandeln, wo die Wände des Ichs durchbrochen und die Schranken des Egoismus überwunden werden« (ebd., 149).
<G-vec01132-002-s642><convert.sich_verwandeln><en> We're looking for heroes: to go into battle alongside us courageously – and convert challenges into opportunities.
<G-vec01132-002-s642><convert.sich_verwandeln><de> Wir sind auf der Suche nach Helden: die mutig mit uns in den Kampf ziehen – und Challenges in Chancen verwandeln.
<G-vec01132-002-s643><convert.sich_verwandeln><en> And, here’s a neat trick; the app can even scan and convert your handwriting into digital text characters that you can then export.
<G-vec01132-002-s643><convert.sich_verwandeln><de> Ebenfalls prima: Die App kann Ihre Handschrift beim Exportieren sogar scannen und in digitalisierten Text verwandeln.
<G-vec01132-002-s644><convert.sich_verwandeln><en> The aim of the analysis is to convert data as quickly as possible into knowledge with which the company can use to take important decisions.
<G-vec01132-002-s644><convert.sich_verwandeln><de> Ziel der Analyse ist es, die Daten so schnell wie möglich in Wissen zu verwandeln und daraus entscheidungsrelevante Erkenntnisse für das Unternehmen zu gewinnen.
<G-vec01132-002-s665><convert.sich_wandeln><en> Thermoelectric generators (TEG) use this waste heat and convert it into electrical energy.
<G-vec01132-002-s665><convert.sich_wandeln><de> Thermoelektrische Generatoren (TEG) nutzen diese Abwärme und wandeln sie in elektrische Energie um.
<G-vec01132-002-s666><convert.sich_wandeln><en> We simply convert the invariable vectorized graphic format "PDF" into an editable format.
<G-vec01132-002-s666><convert.sich_wandeln><de> Wir wandeln hierfür das unveränderliche vektorisierte Grafikformat „PDF“ einfach in ein editierbares Format um.
<G-vec01132-002-s667><convert.sich_wandeln><en> With WAV to MP3 Converter you easily rip your audio CDs to MP3, FLAC or WMA files for use with your hardware player or convert files that do not play with other audio software.
<G-vec01132-002-s667><convert.sich_wandeln><de> Fazit: Der Free CD to MP3 Converter ist ein kostenloses CD-Ripper-Tool um Musik von Audio-CD's in MP3 oder andere Formate zu wandeln und auf Festplatte zu speichern.
<G-vec01132-002-s668><convert.sich_wandeln><en> We convert all elements, except for the foundation blocks, into analysis objects.
<G-vec01132-002-s668><convert.sich_wandeln><de> Wir wandeln alle Elemente (bis auf die Blockfundamente) in Analyseobjekte um.
<G-vec01132-002-s669><convert.sich_wandeln><en> Thermoelectric generators convert waste heat directly into electricity.
<G-vec01132-002-s669><convert.sich_wandeln><de> Thermoelektrische Generatoren wandeln Abwärme direkt in elektrischen Strom.
<G-vec01132-002-s670><convert.sich_wandeln><en> The current transformers of the PCE-LCTB 100 / 130V (45) series can detect primary currents from 400 A to 3200 A depending on the design and convert these into a 1 A or 5 A secondary current.
<G-vec01132-002-s670><convert.sich_wandeln><de> Die Hutschienen-Messgeräte der PCE-LCTB 100/100V (45) Serie können je nach Ausführung Primärströme von 400 A bis 2500 A erfassen und wandeln diese in einen 1 A oder 5 A Sekundärstrom um.
<G-vec01132-002-s671><convert.sich_wandeln><en> However, plants do something very similar: they convert the energy from sunlight into usable energy.
<G-vec01132-002-s671><convert.sich_wandeln><de> Dabei machen Pflanzen etwas ganz Ähnliches: Sie wandeln die Energie des Sonnenlichts in nutzbare Energie um.
<G-vec01132-002-s672><convert.sich_wandeln><en> Rightly all kinds of plants, through photosynthesis, convert solar energy into chemical energy, storing the energy in plants body.
<G-vec01132-002-s672><convert.sich_wandeln><de> Pflanzen setzen Sauerstoff durch Photosynthese frei, absorbieren Kohlendioxid und wandeln Sonnenenergie in chemische Energie zur Speicherung in Pflanzen um.
<G-vec01132-002-s673><convert.sich_wandeln><en> Close to the action, sensors convert mechanical parameters such as force, pressure, sound, vibrations, paths, positions or movements into digital or analogue signals. read more >>
<G-vec01132-002-s673><convert.sich_wandeln><de> Ganz nah am Ort des Geschehens wandeln Sensoren mechanische Größen wie Kraft, Druck, Schall, Schwingungen, Wege, Positionen oder Bewegungen in digitale oder analoge Signale um.
<G-vec01132-002-s674><convert.sich_wandeln><en> They convert water (steam) into mechanical energy just like the originals. This energy can be used to drive our models.
<G-vec01132-002-s674><convert.sich_wandeln><de> Wie ihre Vorbilder wandeln auch die Wilesco-Dampfmaschinen Wärme in mechanische Energie um, welche zum Antrieb von Modellen genutzt werden kann.
<G-vec01132-002-s675><convert.sich_wandeln><en> Hereby, the task was to convert various document formats of the old archive to the PDF/A format, to attach a digital signature, and to archive the document in the new system.
<G-vec01132-002-s675><convert.sich_wandeln><de> Hierbei war es die Aufgabe, die verschiedenen Dokumentenformate des alten Archivs in PDF/A zu wandeln, mit einer gültigen digitalen Signatur zu versehen und im neuen System zu archivieren.
<G-vec01132-002-s676><convert.sich_wandeln><en> Accreting black holes convert typically ten to thirty percent of the accreted rest mass energy into short-wavelength radiation and into nuclear winds.
<G-vec01132-002-s676><convert.sich_wandeln><de> Akkretierende Schwarze Löcher wandeln typischerweise zehn bis 30 Prozent der akkretierten Restmasse in Kurzwellenstrahlung und nukleare Winde um.
<G-vec01132-002-s677><convert.sich_wandeln><en> Convert ratchet spanners into ratchets.
<G-vec01132-002-s677><convert.sich_wandeln><de> Wandeln Ratschenschlüssel in Knarren um.
<G-vec01132-002-s678><convert.sich_wandeln><en> They convert light energy to an electrical signal output.
<G-vec01132-002-s678><convert.sich_wandeln><de> Sie wandeln Lichtenergie in elektrische Signale um.
<G-vec01132-002-s679><convert.sich_wandeln><en> The blades propel the water parallel to the revolving axis and thus convert the energy of the whirlwind into mechanical force.
<G-vec01132-002-s679><convert.sich_wandeln><de> Die Schaufeln der Turbine leiten den Wasserstrom parallel zur Drehachse um und wandeln somit die Energie des Wirbels in mechanische Arbeit um.
<G-vec01132-002-s680><convert.sich_wandeln><en> The microorganisms in the sand, for example, remove nitrate, which passes from agricultural land via rivers into coastal seas, and convert it into harmless nitrogen gas.
<G-vec01132-002-s680><convert.sich_wandeln><de> Die Mikroorganismen im Sand entfernen zum Beispiel Nitrat, das aus der Landwirtschaft über die Flüsse in die Küstenmeere gelangt, und wandeln es in harmloses Stickstoffgas um.
<G-vec01132-002-s681><convert.sich_wandeln><en> The latter – the sole production of N2 – is particularly intriguing: Some microbes convert NO to nitrous oxide (N2O), which is a potent greenhouse gas.
<G-vec01132-002-s681><convert.sich_wandeln><de> Letzteres – die alleinige Produktion von N2 – ist besonders faszinierend: Einige Mikroben wandeln NO in Lachgas (N2O) um, das ein starkes Treibhausgas ist.
<G-vec01132-002-s682><convert.sich_wandeln><en> Thanks to its One-Hand Fold its possible to convert it into a compact and free standing package.
<G-vec01132-002-s682><convert.sich_wandeln><de> Dank seiner Einhand-Faltmechanik lässt er sich einfach und platzsparend verstauen: es ist möglich den Kinderwagen einfach zu einem kompakten Paket zu wandeln.
<G-vec01132-002-s683><convert.sich_wandeln><en> Solar panels convert sunlight to electricity.
<G-vec01132-002-s683><convert.sich_wandeln><de> Solarpaneele wandeln Sonnenlicht in Strom um.
<G-vec01132-002-s684><convert.sich_wandeln><en> Convert your folders to albums for easy management.
<G-vec01132-002-s684><convert.sich_wandeln><de> Wandeln Sie Ihre Ordner für eine einfache Verwaltung in Alben um.
<G-vec01132-002-s685><convert.sich_wandeln><en> Convert files to PDF from any printable application, or create PDF files directly from your scanner.
<G-vec01132-002-s685><convert.sich_wandeln><de> Wandeln Sie Dateien aus einer beliebigen Druckanwendung in PDFs um oder erstellen Sie PDF-Dateien direkt mit Ihrem Scanner.
<G-vec01132-002-s686><convert.sich_wandeln><en> Then convert the data to text that can be edited and analyzed in Microsoft Excel.
<G-vec01132-002-s686><convert.sich_wandeln><de> Anschließend wandeln Sie den Text in Daten um, die Sie in Microsoft Excel bearbeiten und auswerten können.
<G-vec01132-002-s687><convert.sich_wandeln><en> Save the file to your computer's hard drive, then convert it.
<G-vec01132-002-s687><convert.sich_wandeln><de> Speichern Sie die Datei auf der Festplatte Ihres Computers und wandeln Sie sie dann um.
<G-vec01132-002-s688><convert.sich_wandeln><en> The photo suite can also be used on your regular photos taken outside of Cycloramic.- Immersive 3D viewer.- Video Conversion: Convert any photo into a video (240p, 360p, 480p, 720p or 1080p resolutions).- Panorama Photo to INSTAGRAM Video converter.- Share to Facebook, Twitter, INSTAGRAM (photo and video), email, sms and camera roll.-...
<G-vec01132-002-s688><convert.sich_wandeln><de> Die Fotosuite kann auf Ihren regelmäßigen Fotos auch benutzt werden, die außerhalb Cycloramic genommen werden.- Immersive 3D Projektor.- Videoumwandlung: Wandeln Sie jedes mögliches Foto in Auflösungen (um 240p, 360p, 480p, 720p oder 1080p) eines Bildschirmes.- Panorama Foto zum Instagram Bildschirm Converter.- Anteil zu Facebook, Twitter, Instagram (Foto und Bildschirm), email, sms und Kamera rollen.-...
<G-vec01132-002-s689><convert.sich_wandeln><en> Convert any 2D videos to a 3D format at ultrafast speeds.
<G-vec01132-002-s689><convert.sich_wandeln><de> Wandeln Sie 2D-Videos um, damit Sie diese auf 3D-fähigen Geräten abspielen können.
<G-vec01132-002-s690><convert.sich_wandeln><en> Convert the selection to path.
<G-vec01132-002-s690><convert.sich_wandeln><de> Wandeln Sie die Auswahl in einen Pfad um.
<G-vec01132-002-s691><convert.sich_wandeln><en> Select a free column chart template from the thousands of examples available in the Edraw Library and convert to word column chart template with one click.
<G-vec01132-002-s691><convert.sich_wandeln><de> Wählen Sie eine kostenlose Mindmap-Vorlage aus Tausende von Beispielen in der Edraw Software und wandeln Sie es in PowerPoint-Format mit nur einem Klick um.
<G-vec01132-002-s692><convert.sich_wandeln><en> To preserve rendering effects on an image stack, convert the Smart Object to a regular layer.
<G-vec01132-002-s692><convert.sich_wandeln><de> Um die Renderwirkungen auf einen Bildstapel beizubehalten, wandeln Sie das Smartobjekt in eine reguläre Ebene um.
<G-vec01132-002-s693><convert.sich_wandeln><en> Convert various formats to AVI, MPEG, VCD, and WMV in batch mode.
<G-vec01132-002-s693><convert.sich_wandeln><de> Wandeln Sie verschiedene Formate in AVI, MPEG, VCD und WMV in Schüben um.
<G-vec01132-002-s694><convert.sich_wandeln><en> Convert PowerPoint presentations to videos in no minute.
<G-vec01132-002-s694><convert.sich_wandeln><de> Wandeln Sie PowerPoint-Präsentationen in Videos um.
<G-vec01132-002-s695><convert.sich_wandeln><en> Convert your audio files between various formats: MP3, WMA, WAV, M4A, FLAC and others.
<G-vec01132-002-s695><convert.sich_wandeln><de> Wandeln Sie Ihre Audiodateien zwischen zahlreichen Formaten um: MP3, WMA, WAV, M4A, FLAC und andere.
<G-vec01132-002-s696><convert.sich_wandeln><en> With Digital Media Converter Pro, convert your recorded DVR-MS TV shows to your portable multimedia players and enjoy them anywhere you go.
<G-vec01132-002-s696><convert.sich_wandeln><de> Mit Digital Media Converter Pro, wandeln Sie Ihre aufgezeichneten DVR-MS TV-Sendungen in Ihre tragbaren Multimedia-Player um und genießen Sie sie überall.
<G-vec01132-002-s697><convert.sich_wandeln><en> Convert several video files at once and burn them onto a DVD/Blu-ray disc.
<G-vec01132-002-s697><convert.sich_wandeln><de> Wandeln Sie mehrere Videodateien auf einmal um und brennen Sie sie auf eine Blu-ray/DVD-Disk.
<G-vec01132-002-s698><convert.sich_wandeln><en> Select a free swot matrix template from the thousands of examples available in the Edraw Library and convert to PowerPoint swot matrix template with one click.
<G-vec01132-002-s698><convert.sich_wandeln><de> Wählen Sie ein kostenloses Concept-Map-Beispiel von Concept-Map-Vorlagen in der Bibliothek Edraw und wandeln Sie es in PPT-Format mit nur einem Klick.
<G-vec01132-002-s699><convert.sich_wandeln><en> Convert YouTube to MP3.
<G-vec01132-002-s699><convert.sich_wandeln><de> Wandeln Sie YouTube zu MP3 um.
<G-vec01132-002-s700><convert.sich_wandeln><en> Select a free IDEF diagram template from the thousands of examples available in the Edraw Library and convert it to word IDEF diagram template with one click.
<G-vec01132-002-s700><convert.sich_wandeln><de> Wählen Sie eine kostenlose Vorlage von Beispielen in der Bibliothek Edraws und wandeln Sie es in Word-Format mit nur einem Klick.
<G-vec01132-002-s701><convert.sich_wandeln><en> Use the SUM function and convert any numbers that you want to subtract to their negative values.
<G-vec01132-002-s701><convert.sich_wandeln><de> Verwenden Sie die FunktionSUMME, und wandeln Sie alle Zahlen, die sie subtrahieren möchten, in die entsprechenden negativen Werte um.
<G-vec01132-002-s702><convert.sich_wandeln><en> Select a free network diagram template from the thousands of examples available in the Edraw Library and convert to PowerPoint network diagram template with one click.
<G-vec01132-002-s702><convert.sich_wandeln><de> Wählen Sie eine kostenlose Vorlage in der Edraw Software und wandeln Sie es ins PPT-Format mit nur einem Klick.
<G-vec01132-002-s703><convert.sich_wandeln><en> During the day, solar cells convert solar energy into electricity and store it in the battery.
<G-vec01132-002-s703><convert.sich_wandeln><de> Tagsüber wandeln Solarzellen Sonnenenergie in Strom um und speichern sie in der Batterie.
<G-vec01132-002-s704><convert.sich_wandeln><en> Inverters convert direct current into alternating current. Description of the product target audience
<G-vec01132-002-s704><convert.sich_wandeln><de> Wechselrichter, auch Inverter genannt, wandeln Gleichstrom in Wechselstrom um.
<G-vec01132-002-s705><convert.sich_wandeln><en> That’s why casinos convert your Bitcoin deposit into casino credits and then you can use your credits any way you like on your favourite casino games.
<G-vec01132-002-s705><convert.sich_wandeln><de> Deswegen wandeln Casinos Ihre Bitcoin Einzahlung in Casino Credits um und dann können Sie Ihre Credits so zum Spielen Ihrer Lieblingsspiele nutzen, wie Sie es gerne möchten.
<G-vec01132-002-s706><convert.sich_wandeln><en> However, we convert it into special products.
<G-vec01132-002-s706><convert.sich_wandeln><de> Wir wandeln es jedoch in spezielle Produkte um.
<G-vec01132-002-s707><convert.sich_wandeln><en> Turbo retarders (fig. 9b) convert excessive kinetic energy of trucks into heat.
<G-vec01132-002-s707><convert.sich_wandeln><de> Turbo-Retarder (Bild 9b) wandeln die überschüssige kinetische Energie von Lkw in Wärme um.
<G-vec01132-002-s708><convert.sich_wandeln><en> PV power inverters convert the DC current of PV generators into AC current.
<G-vec01132-002-s708><convert.sich_wandeln><de> PV-Wechselrichter wandeln bekanntermaßen den Gleichstrom vom PV-Generator in Wechselstrom um.
<G-vec01132-002-s709><convert.sich_wandeln><en> In hydrogen-powered electric vehicles, fuel cells convert hydrogen into electricity that drives an electric motor.
<G-vec01132-002-s709><convert.sich_wandeln><de> Bei mit Wasserstoff betriebenen Elektrofahrzeugen wandeln Brennstoffzellen Wasserstoff in Strom um, der einen Elektromotor antreibt.
<G-vec01132-002-s710><convert.sich_wandeln><en> Taste receptors convert chemical stimuli into electric signals.
<G-vec01132-002-s710><convert.sich_wandeln><de> Seine Rezeptoren wandeln Licht in elektrische Impulse um.
<G-vec01132-002-s711><convert.sich_wandeln><en> With the freeware Free HTML5 Video Player and Converter you can convert your videos into a HTML5 compatible format.
<G-vec01132-002-s711><convert.sich_wandeln><de> Mit der kostenlosen Software Free HTML5 Video Player and Converter von DVD-Videosoft wandeln Sie Ihre Videos in das HTML5 Videoformat um.
<G-vec01132-002-s712><convert.sich_wandeln><en> Solar panels convert sunlight directly into electricity, using a process known as photovoltaics (PV).
<G-vec01132-002-s712><convert.sich_wandeln><de> Durch den Vorgang der Photovoltaik (PV) wandeln Solarmodule Sonnenlicht direkt in Strom um.
<G-vec01132-002-s713><convert.sich_wandeln><en> They convert plastic waste into gasoline and diesel and can thus benefit from it.
<G-vec01132-002-s713><convert.sich_wandeln><de> Sie wandeln Müll in Benzin und Diesel um und können so einen positiven Nutzen davon tragen.
<G-vec01132-002-s714><convert.sich_wandeln><en> With the help of these silicon structures, they convert precision mechanical movements into an electrical signal.
<G-vec01132-002-s714><convert.sich_wandeln><de> Mit Hilfe dieser Silizium-Strukturen wandeln sie feinmechanische Bewegungen in ein elektrisches Signal um.
<G-vec01132-002-s715><convert.sich_wandeln><en> They convert the mains AC voltage into a DC voltage of 24 V.
<G-vec01132-002-s715><convert.sich_wandeln><de> Sie wandeln die Netzwechselspannung in eine Betriebsspannung von DC 24 V um.
<G-vec01132-002-s716><convert.sich_wandeln><en> Muscles convert chemical energy directly into physical energy and heat.
<G-vec01132-002-s716><convert.sich_wandeln><de> Die Muskeln wandeln chemische Energie direkt in physische Energie und Wärme um.
<G-vec01132-002-s717><convert.sich_wandeln><en> To do this, our analysts convert their findings of malware authors’ new techniques into new algorithms, which our machines then use to learn how to make decisions when they receive new data.
<G-vec01132-002-s717><convert.sich_wandeln><de> Hierzu wandeln unsere Analytiker ihre Erkenntnisse zu den Techniken von Malware-Entwicklern in neue Algorithmen um, die unsere Maschinen dann einsetzen, um zu lernen und Entscheidungen zu treffen, sobald neue Daten eingehen.
<G-vec01132-002-s718><convert.sich_wandeln><en> Photovoltaic (PV) cells or solar cells convert energy of light directly into electricity.
<G-vec01132-002-s718><convert.sich_wandeln><de> Photovoltaik Photovoltaik-Zellen oder Solarzellen wandeln Lichtenergie direkt in Strom um.
<G-vec01132-002-s719><convert.sich_wandeln><en> Please convert fonts that are used in logos into paths as well.
<G-vec01132-002-s719><convert.sich_wandeln><de> Wandeln Sie auch in Logos die Schriften in Pfade um.
<G-vec01132-002-s720><convert.sich_wandeln><en> They bind to mineral surfaces or convert minerals through metabolic processes.
<G-vec01132-002-s720><convert.sich_wandeln><de> Sie binden an Mineraloberflächen oder wandeln mineralische Bestandteile durch Stoffwechselvorgänge um.
<G-vec01132-002-s721><convert.sich_wandeln><en> They are used to increase or decrease alternating current; they convert mains voltage into low current.
<G-vec01132-002-s721><convert.sich_wandeln><de> Sie werden zur Erhöhung oder Verringerung von Wechselstrom verwendet; sie wandeln Netzspannung in Schwachstrom um.
<G-vec01132-002-s722><convert.sich_wandeln><en> It is used to convert a binary number into a decimal number.
<G-vec01132-002-s722><convert.sich_wandeln><de> Sie wandelt eine binäre Zahl (Dualzahl) in eine dezimale Zahl um.
<G-vec01132-002-s723><convert.sich_wandeln><en> Hearing is a complicated process. Sound signals in the environment funnel into the ear, where a series of reactions convert acoustic energy into electrical impulses that the brain can understand.
<G-vec01132-002-s723><convert.sich_wandeln><de> Erfahrungsbeist ein komplexer Vorgang: Das Ohr nimmt den Umgebungsschall auf und wandelt die akustische Energie durch eine Abfolge von Reaktionen in elektrische Signale um, die das Gehirn verstehen kann.
<G-vec01132-002-s724><convert.sich_wandeln><en> (5): +100 Precision (6): When you use an elite skill, convert up to 5 conditions into boons.
<G-vec01132-002-s724><convert.sich_wandeln><de> (5): +100 Präzision (6): Wenn ihr eine Elite-Fertigkeit einsetzt, wandelt ihr bis zu 5 Zustände in Segen um.
<G-vec01132-002-s725><convert.sich_wandeln><en> The application will convert the data which is supported by the Android device and begin the transfer process.
<G-vec01132-002-s725><convert.sich_wandeln><de> Die Anwendung wandelt die vom Android-Gerät unterstützten Daten um, und der Übertragungsprozess beginnt.
<G-vec01132-002-s726><convert.sich_wandeln><en> Any Video convertor final Crack delivers all-in-one answer to convert most forms of audio and video formats.
<G-vec01132-002-s726><convert.sich_wandeln><de> Quick Media Converter HD 4.5.0 Quick Media Converter wandelt nahezu alle verbreiteten Audio und Video Dateiformate um.
<G-vec01132-002-s727><convert.sich_wandeln><en> When a cell needs energy it convert fat, carbohydrate, protein, and alcohol to the ATP (adenosine triphosphate), a molecule that stores energy in its chemical form.
<G-vec01132-002-s727><convert.sich_wandeln><de> Benötigt eine Zelle Energie, wandelt sie Fett, Kohlenhydrate, Proteine und Alkohol in das Molekül ATP (Adenosintriphosphat) um, das in seiner chemischen Form Energie speichert.
<G-vec01132-002-s728><convert.sich_wandeln><en> It is used to convert a hexadecimal number into a decimal number.
<G-vec01132-002-s728><convert.sich_wandeln><de> Sie wandelt eine hexadezimale Zahl in eine dezimale Zahl um.
<G-vec01132-002-s729><convert.sich_wandeln><en> Where the amount of fuel uplift or the amount of fuel remaining in the tanks is determined in units of volume, expressed in litres, the company shall convert that amount from volume to mass by using actual density values.
<G-vec01132-002-s729><convert.sich_wandeln><de> Wird die gebunkerte oder die in den Tanks verbliebene Kraftstoffmenge in Volumeneinheiten, ausgedrückt in Litern, bestimmt, so wandelt das Schifffahrtsunternehmen diese Menge anhand von realen Dichtewerten von Volumen in Masse um.
<G-vec01132-002-s730><convert.sich_wandeln><en> If you later should need the WAV file again with its original cue list, simply convert the MP3 file back to WAV and import the cue list from the cue list file.
<G-vec01132-002-s730><convert.sich_wandeln><de> Benötigt man später wieder die WAV-Datei mit der ursprünglichen Cue-List, wandelt man die MP3-Datei einfach wieder in eine WAV-Datei um und importiert anschließend aus der dazugehörigen Cue-List-Datei die Cue-List.
<G-vec01132-002-s731><convert.sich_wandeln><en> The ProCleave LD II has several new features that convert the ProCleave model from a manual to an automatic fiber cleaver.
<G-vec01132-002-s731><convert.sich_wandeln><de> Durch zahlreiche neue Features wandelt sich der ProCleave vom manuellen zum automatischen Fasercleaver.
<G-vec01132-002-s732><convert.sich_wandeln><en> The CEL-capable, fully resonant welding inverter detects in fully automatic fashion if the current supplied is alternating current (mains or generator) or direct current (battery) and will then convert this current into a uniform and powerful arc.
<G-vec01132-002-s732><convert.sich_wandeln><de> Der CEL-fähige, vollresonante Schweißinverter erkennt vollautomatisch, ob Strom als Wechselstrom (Netz oder Generator) oder Gleichstrom (Akku) geliefert wird und wandelt diesen in einen gleichmäßigen, druckvollen Lichtbogen um.
<G-vec01132-002-s733><convert.sich_wandeln><en> KEB has created tools for different tasks, which support you with the use of drive controllers and convert the complexity of possible adjustments on a user friendly basis.
<G-vec01132-002-s733><convert.sich_wandeln><de> KEB hat für verschiedene Aufgabenstellungen Werkzeuge geschaffen, die Sie in der Anwendung von Antriebsstellern unterstützen und die Komplexität möglicher Einstellungen auf eine bedienergeführte Basis wandelt.
<G-vec01132-002-s735><convert.sich_wandeln><en> The principle is fairly simple: the muscles convert chemically stored energy from free fatty acids, proteins, and carbohydrates into mechanical energy.
<G-vec01132-002-s735><convert.sich_wandeln><de> Das Prinzip ist ganz einfach: Der Muskel wandelt chemisch gespeicherte Energie aus freien Fettsäuren, Proteinen und Kohlenhydraten in mechanische Energie um.
<G-vec01132-002-s736><convert.sich_wandeln><en> In normal use the power electronics convert the current so that it can be fed into the household consumer unit or the national grid.
<G-vec01132-002-s736><convert.sich_wandeln><de> Im normalen USE-Case wandelt unsere Leistungselektronik den Strom so, dass er im Anschluss entweder in das Hausnetz oder in das öffentliche Verbrauchernetz eingespeist werden kann.
<G-vec01132-002-s737><convert.sich_wandeln><en> Convert an HDMI input to SDI output.
<G-vec01132-002-s737><convert.sich_wandeln><de> Wandelt eingehende HDMI-Signale für die SDI-Ausgabe um.
<G-vec01132-002-s738><convert.sich_wandeln><en> The program will then begin to upscale video resolution and convert it to the format you have chosen.
<G-vec01132-002-s738><convert.sich_wandeln><de> Das Programm beginnt dann Videoauflösung zu steigern und wandelt es in das Format, das Sie gewählt haben.
<G-vec01132-002-s739><convert.sich_wandeln><en> Therefore, it is makes no difference what form you consume, your body will still convert oxidized Q10 into active Q10.
<G-vec01132-002-s739><convert.sich_wandeln><de> Daher macht es keinen Unterschied, welche Form eingenommen wird, denn der Körper wandelt oxidiertes Q10 Ubichinon in aktives Q10 Ubichinol um.
<G-vec01132-002-s740><convert.sich_wandeln><en> The electronics convert the travelled distance and level signal which can be read via analogue 4-20mA or Modbus RTU and Profibus DP.
<G-vec01132-002-s740><convert.sich_wandeln><de> Die Elektronik wandelt die gefahrene Weglänge in ein Distanz- oder Füllstandssignal um, welches analog über 4-20mA oder Modbus RTU und Profibus DP ausgelesen werden kann.
<G-vec01132-002-s133><convert.umwandeln><en> You can convert MP4 file to MOV as well as to variety of other formats with free online converter.
<G-vec01132-002-s133><convert.umwandeln><de> Sie können MP4-Video in MOV sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s134><convert.umwandeln><en> You can convert FLV file to AAC as well as to variety of other formats with free online converter.
<G-vec01132-002-s134><convert.umwandeln><de> Sie können FLV-Video in AAC sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s135><convert.umwandeln><en> You can convert PNG image to PALM as well as to variety of other formats with free online converter.
<G-vec01132-002-s135><convert.umwandeln><de> Sie können PNG-Bild in PALM sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s136><convert.umwandeln><en> You can convert SNB file to EPUB as well as to variety of other formats with free online converter.
<G-vec01132-002-s136><convert.umwandeln><de> Sie können Unterlagen in PPT sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s137><convert.umwandeln><en> You can convert SFW image to GIF as well as to variety of other formats with free online converter.
<G-vec01132-002-s137><convert.umwandeln><de> Sie können SFW-Bild in GIF sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s139><convert.umwandeln><en> You can convert DOT file to PNG as well as to variety of other formats with free online converter.
<G-vec01132-002-s139><convert.umwandeln><de> Sie können DOT-Dokument in PNG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s140><convert.umwandeln><en> You can convert MP4 file to JPEG as well as to variety of other formats with free online converter.
<G-vec01132-002-s140><convert.umwandeln><de> Sie können MP4-Video in JPEG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s141><convert.umwandeln><en> You can convert DOC file to PNG as well as to variety of other formats with free online converter.
<G-vec01132-002-s141><convert.umwandeln><de> Sie können DOC-Dokument in PNG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s142><convert.umwandeln><en> You can convert 3G2 file to MP4 as well as to variety of other formats with free online converter.
<G-vec01132-002-s142><convert.umwandeln><de> Sie können 3G2-Video in MP4 sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s143><convert.umwandeln><en> You can convert JPEG image to CUR as well as to variety of other formats with free online converter.
<G-vec01132-002-s143><convert.umwandeln><de> Sie können JPEG-Bild in CUR sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s144><convert.umwandeln><en> You can convert PCD image to JPEG as well as to variety of other formats with free online converter.
<G-vec01132-002-s144><convert.umwandeln><de> Sie können PCD-Bild in JPEG sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s145><convert.umwandeln><en> You can convert WMA file to M4A as well as to variety of other formats with free online converter.
<G-vec01132-002-s145><convert.umwandeln><de> Sie können WMA-Audio in M4A sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s146><convert.umwandeln><en> You can convert MKV file to M4A as well as to variety of other formats with free online converter.
<G-vec01132-002-s146><convert.umwandeln><de> Sie können MKV-Video in M4A sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s147><convert.umwandeln><en> You can convert M4V file to WMV as well as to variety of other formats with free online converter.
<G-vec01132-002-s147><convert.umwandeln><de> Sie können M4V-Video in WMV sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s148><convert.umwandeln><en> You can convert FB2 file to DOC as well as to variety of other formats with free online converter.
<G-vec01132-002-s148><convert.umwandeln><de> Sie können FB2-Dokument in DOC sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s149><convert.umwandeln><en> You can convert FB2 file to SDW as well as to variety of other formats with free online converter.
<G-vec01132-002-s149><convert.umwandeln><de> Sie können FB2-Dokument in SDW sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s150><convert.umwandeln><en> You can convert FLV file to MP4 as well as to variety of other formats with free online converter.
<G-vec01132-002-s150><convert.umwandeln><de> Sie können FLV-Video in MP4 sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s151><convert.umwandeln><en> You can convert PNG image to RAR as well as to variety of other formats with free online converter.
<G-vec01132-002-s151><convert.umwandeln><de> Sie können PNG-Bild in RAR sowie zu einer Vielzahl anderer Formate mit kostenlosem Online-Konverter umwandeln.
<G-vec01132-002-s456><convert.umwandeln><en> With this software you can convert one or thousands of JPG, located in one or many different folders into a PDF.
<G-vec01132-002-s456><convert.umwandeln><de> Mit dieser Software kann ein pdf Dokument in eine Wortakte umgewandelt werden, ohne das Datenformat zu verlieren oder zu ändern.
<G-vec01132-002-s457><convert.umwandeln><en> But: If the level is not sufficient we will convert the supervision into a lesson! weather information
<G-vec01132-002-s457><convert.umwandeln><de> Allerdings: Sollte das Level nicht für eine Supervision ausreichen, wird die Einheit in Unterricht umgewandelt.
<G-vec01132-002-s458><convert.umwandeln><en> Not only is it possible to convert patent applications into utility model applications and vice versa, but, quite importantly, it is also possible to branch off utility models from patent applications (with the patent application remaining valid independently).
<G-vec01132-002-s458><convert.umwandeln><de> Von besonderer Bedeutung ist, dass Patent- und Gebrauchsmusteranmeldungen nicht nur jeweils ineinander umgewandelt werden können, sondern auch, dass es möglich ist, aus Patentanmeldungen Gebrauchsmuster abzuzweigen (wobei die Patentanmeldung unabhängig davon weiterverfolgt werden kann).
<G-vec01132-002-s459><convert.umwandeln><en> All are simple, only clicking on the Export PDF button will convert your pert chart template into PDF, with no clarity loss.
<G-vec01132-002-s459><convert.umwandeln><de> Alles ist ganz einfach, mit nur ein Klick auf den Knopf PDF exportieren wird Ihre PERT-Diagrammvorlage in eine PDF-Datei umgewandelt, ohne dass die Übersichtlichkeit leidet.
<G-vec01132-002-s460><convert.umwandeln><en> Four queen berths and one cabin with two singles berths which can convert to a queen.
<G-vec01132-002-s460><convert.umwandeln><de> Vier Queen-Betten und eine Kabine mit zwei Einzelbetten, die in eine Königin umgewandelt werden können.
<G-vec01132-002-s461><convert.umwandeln><en> • In addition, RMX will issue to Mindoro 50,000,000 Performance Shares that will convert to full voting shares if RMX upgrades the Indicated Resource at Batangas to 600,000 oz of gold and completes a scoping study that demonstrates a viable gold mining project based on over 50% of the Indicated Resource converting to a Probable Ore Reserve or equivalent within 12 months of completing the transaction.
<G-vec01132-002-s461><convert.umwandeln><de> • Zusätzlich wird RMX auf Mindoro 50.000.000 Performance-Aktien übertragen, die zu voll stimmberechtigten Aktien umgewandelt werden, wenn RMX die angezeigten Ressourcen bei Batangas zu 600.000 Unzen Gold aufwertet und eine Scoping-Studie durchführt, mit der die Machbarkeit eines Goldförderprojekts demonstriert wird, in dem innerhalb von 12 Monaten nach Abschluss der Transaktion über 50 % der angezeigten Ressourcen in wahrscheinliche Erzreserven oder eine gleichwertige Kategorie umgewandelt werden.
<G-vec01132-002-s462><convert.umwandeln><en> Three Bedroom Luxury Apartment (Sleeps 6): This apartment has three bedrooms with King-size beds that can convert to twin beds.
<G-vec01132-002-s462><convert.umwandeln><de> Diese Wohnung verfügt über drei Schlafzimmer mit Kingsize-Betten, die in zwei Einzelbetten umgewandelt werden können.
<G-vec01132-002-s463><convert.umwandeln><en> Carbohydrates, such as pasta, convert easily to sugar.
<G-vec01132-002-s463><convert.umwandeln><de> Kohlenhydrate wie Pasta werden leicht zu Zucker umgewandelt.
<G-vec01132-002-s464><convert.umwandeln><en> Here, you can convert individual or multiple suggestions into purchase orders in one simple step.
<G-vec01132-002-s464><convert.umwandeln><de> Hier können einzelne oder mehrere Vorschläge auf Knopfdruck in Bestellungen umgewandelt werden.
<G-vec01132-002-s465><convert.umwandeln><en> In spite of its recent reform, FRONTEX remains, for example, a resource agency since it is appropriate to convert the agency into a real EU border police.
<G-vec01132-002-s465><convert.umwandeln><de> Trotz seiner kürzlichen Reform bleibt beispielsweise FRONTEX eine Agentur für Ressourcen, obwohl sie in eine wirkliche Polizei für die Außengrenzen der Union umgewandelt werden sollte.
<G-vec01132-002-s466><convert.umwandeln><en> One main focus of the product range is the hydraulic briquetting press produced by SPÄNEX, used to convert chips and dust into valuable briquettes during production processes.
<G-vec01132-002-s466><convert.umwandeln><de> Einen Schwerpunkt des Produktprogramms stellen die von SPÄNEX hergestellten hydraulischen Brikettierpressen dar, mit denen die bei Produktionsprozessen anfallenden und abgesaugten Späne und Stäube in werthaltige Briketts umgewandelt werden.
<G-vec01132-002-s467><convert.umwandeln><en> Yeast causes fermentable sugars to convert into alcohol and carbon dioxide.
<G-vec01132-002-s467><convert.umwandeln><de> Hefe sorgt dafür, daß vergärbarer Zucker in Alkohol und Kohlensäure umgewandelt wird.
<G-vec01132-002-s468><convert.umwandeln><en> "Adjust bids by placement" sets different bids by placement, and "dynamic bids - down only" adjusts bids down from there for opportunities where a click is less likely to convert to a sale.
<G-vec01132-002-s468><convert.umwandeln><de> „Gebote nach Platzierung anpassen“ legt verschiedene Gebote nach Platzierung fest und „Dynamische Gebote - nur nach unten“ passt Gebote nach unten für Gelegenheiten an, bei denen weniger wahrscheinlich ist, dass sie bei einem Klick in einen Verkauf umgewandelt werden.
<G-vec01132-002-s469><convert.umwandeln><en> When we no longer need your information for our purposes or legal obligations, we will destroy, delete or erase that information or convert it into an anonymous form.
<G-vec01132-002-s469><convert.umwandeln><de> Wenn wir Ihre Daten nicht mehr für unsere Zwecke oder gesetzlichen Pflichten benötigen, werden diese Informationen von uns vernichtet, gelöscht oder entfernt oder in eine anonymisierte Form umgewandelt.
<G-vec01132-002-s470><convert.umwandeln><en> (The Life Divine, p. 1108) In practice, this is the first preoccupation for creating a new earth-life, for bringing in a new order of beings - to create the inner life and then to convert our thought, feeling and action in the dynamic world into perfect instrument of that inner realisation.
<G-vec01132-002-s470><convert.umwandeln><de> (The Life Divine, p. 1108) In der Praxis wird damit erstmals neues Leben auf der Erde erschaffen und eine neue Ordnung von Lebewesen eingeführt – nach der Gestaltung des Innenlebens werden die Gedanken, Gefühle und Handlungen in der dynamischen Welt in ein perfektes Werkzeug dieser inneren Erkenntnis umgewandelt.
<G-vec01132-002-s471><convert.umwandeln><en> Powerful upright vacuum cleaner which is easy to convert into a powerful handheld unit.
<G-vec01132-002-s471><convert.umwandeln><de> Leistungsstarker Staubsauger welcher einfach in einen Handstaubsauger umgewandelt werden kann.
<G-vec01132-002-s472><convert.umwandeln><en> For instance, you can set the software to send the received data to the printer or convert them into a PDF file.
<G-vec01132-002-s472><convert.umwandeln><de> Zum Beispiel können Sie die Software so einstellen, dass empfangene Daten zum Drucker geschickt oder in eine PDF-Datei umgewandelt werden.
<G-vec01132-002-s473><convert.umwandeln><en> NOTE: The double cabins can convert to twin layouts.
<G-vec01132-002-s473><convert.umwandeln><de> HINWEIS: Die Doppelkabinen können in Twin-Layouts umgewandelt werden.
<G-vec01132-002-s474><convert.umwandeln><en> All are quite simple, only clicking on the Export PDF button will convert your garden design template into PDF.
<G-vec01132-002-s474><convert.umwandeln><de> Alles ist ganz einfach, mit nur einem Klick auf den Knopf PDF exportieren wird Ihre Gartengestaltungsvorlage in PDF umgewandelt.
<G-vec01132-002-s513><convert.umwandeln><en> Primetime uses a state-of-the-art drinking water treatment on board, with which we convert seawater into purified drinking water.
<G-vec01132-002-s513><convert.umwandeln><de> Wir verwenden eine „state of the art“ Trinkwasser Aufbereitung an Board, mit der wir Meerwasser in erstklassiges Trinkwasser umwandeln.
<G-vec01132-002-s514><convert.umwandeln><en> It's the best DVD ripper, which can convert DVD and all popular video formats to Apple TV (MP4/H.264 up to 1280x720).
<G-vec01132-002-s514><convert.umwandeln><de> Es ist die beste DVD-Ripper, die DVD und alle gängigen Video-Formate zu Apple TV (MP4/H.264 bis zu 1280x720) umwandeln kann.
<G-vec01132-002-s515><convert.umwandeln><en> It can convert toxic gases into water vapour and less harmful gases.
<G-vec01132-002-s515><convert.umwandeln><de> Es kann giftige Gase in Wasserdampf und weniger schädliche Gase umwandeln.
<G-vec01132-002-s516><convert.umwandeln><en> Type the number of Bushels per year (U.S.) you want to convert in the text box, to see the results in the table.
<G-vec01132-002-s516><convert.umwandeln><de> Geben Sie die Anzahl der Million Gallonen pro Tag (US-Flüssigkeit) ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec01132-002-s517><convert.umwandeln><en> We can convert both into a ready-made solution within a very short period of time.
<G-vec01132-002-s517><convert.umwandeln><de> Wir können beides innerhalb kürzester Zeit in eine fertige Lösung umwandeln.
<G-vec01132-002-s518><convert.umwandeln><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec01132-002-s518><convert.umwandeln><de> Geben Sie die Anzahl der Rotation ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec01132-002-s519><convert.umwandeln><en> A minimum of 200 EnergyPoints are required to convert points to money.
<G-vec01132-002-s519><convert.umwandeln><de> Mindestens 200 EnergyPoints werden benötigt, um Punkte in Geld umwandeln zu können.
<G-vec01132-002-s520><convert.umwandeln><en> All the forms of energy used that consume or convert a certain initial product, which does not self-renew, are called non-renewable: in the case of oil, we use oil until the resource ends (within a few years).
<G-vec01132-002-s520><convert.umwandeln><de> Alle verwendeten Energieformen, die ein bestimmtes Ausgangsprodukt verbrauchen oder umwandeln, das sich nicht selbst erneuert, werden als nicht erneuerbar bezeichnet: Bei Öl verwenden wir Öl bis zum Ende der Ressource (innerhalb weniger Jahre).
<G-vec01132-002-s521><convert.umwandeln><en> Or you let convert your commission into MMOGA balance in order to buy directly games, FIFA Coins and more at MMOGA.
<G-vec01132-002-s521><convert.umwandeln><de> Oder Sie lassen Ihre Provision in MMOGA Guthaben umwandeln, um direkt Games, FIFA Coins und mehr bei MMOGA zu kaufen.
<G-vec01132-002-s522><convert.umwandeln><en> • It can also convert surround sound audio as well.
<G-vec01132-002-s522><convert.umwandeln><de> • Es kann auch Surround-Sound-Audio umwandeln.
<G-vec01132-002-s523><convert.umwandeln><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec01132-002-s523><convert.umwandeln><de> Geben Sie die Anzahl der kcal ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec01132-002-s524><convert.umwandeln><en> Now I convert all my files easily and I can watch them with my family on the TV screen.
<G-vec01132-002-s524><convert.umwandeln><de> Jetzt kann ich ganz einfach meine Aufnahmen umwandeln und sie dann mit meiner Familie auf unserem Fernseher ansehen.
<G-vec01132-002-s525><convert.umwandeln><en> Note: if you want to convert several input files, all of them must have the same aspect values.
<G-vec01132-002-s525><convert.umwandeln><de> Hinweis: Wenn Sie mehrere Eingabedateien umwandeln möchten, müssen sie das gleiche Bildseitenverhältnis haben.
<G-vec01132-002-s526><convert.umwandeln><en> So-called bifacial solar cells can convert incident light into electrical current both on their fronts and backs.
<G-vec01132-002-s526><convert.umwandeln><de> Sogenannte bifaziale Solarzellen können sowohl auf der Vorder- als auch auf der Rückseite einfallendes Licht in elektrischen Strom umwandeln.
<G-vec01132-002-s527><convert.umwandeln><en> It can smoothly work with NSF file generated by IBM Lotus Notes 9.0 and earlier versions of it and smoothly convert them into MBOX file format.
<G-vec01132-002-s527><convert.umwandeln><de> Es kann problemlos mit der NSF-Datei arbeiten, die von IBM Lotus Notes 9.0 und früheren Versionen erstellt wurde, und reibungslos in das MBOX-Dateiformat umwandeln.
<G-vec01132-002-s528><convert.umwandeln><en> XRechnung has published open source XSLT style sheets to convert EN16931 XML to HTML, which also work on ZUGFeRD 2 and Factur-X files.
<G-vec01132-002-s528><convert.umwandeln><de> Die XRechnung hat open-source XSLT style sheets veröffentlicht, die EN16931 XML in HTML umwandeln, und die auch mit ZUGFeRD 2 und Factur-X-Dateien funktionieren.
<G-vec01132-002-s529><convert.umwandeln><en> The decimal integer you want to convert.
<G-vec01132-002-s529><convert.umwandeln><de> Die Zahl, die Sie umwandeln möchten.
<G-vec01132-002-s530><convert.umwandeln><en> About 5% of daily turnover is from companies and governments that buy or sell products and services in a foreign country or must convert profits made in foreign currencies into their domestic currency.
<G-vec01132-002-s530><convert.umwandeln><de> Ungefähr 5 % des täglichen Umsatzes sind von Gesellschaften und Regierungen, die kaufen oder Produkte und Dienstleistungen in einem fremden Land verkaufen oder Gewinne umwandeln müssen, die in fremden Währungen in ihrer Innenwährung gemacht sind.
<G-vec01132-002-s531><convert.umwandeln><en> I have a block that only contains images, but I cannot convert it into a product recommendation.
<G-vec01132-002-s531><convert.umwandeln><de> Ich habe einen Block, der nur Bilder enthält, aber ich kann ihn nicht in eine Produktempfehlung umwandeln.
<G-vec01132-002-s532><convert.umwandeln><en> A fluid power system refers to a mechanism (mechanical or electromechanical) that is used to convert energy (mostly mechanical) into fluid energy.
<G-vec01132-002-s532><convert.umwandeln><de> Ein Fluidtechnik-System verwendet einen Mechanismus (mechanisch oder elektromechanisch), der Energie (größtenteils mechanisch) in Fluidenergie umwandelt.
<G-vec01132-002-s533><convert.umwandeln><en> In order to safely use electric devices such as TVs, laptops or coffee machines on the road, you’ll need an inverter that will convert 12V or 24V direct current into 230V alternating current - e.g. in a camper van, motor home, allotment or boat.
<G-vec01132-002-s533><convert.umwandeln><de> Um unterwegs elektrische Geräte wie Fernseher, Laptops oder Kaffeemaschinen wie gewohnt sicher betreiben zu können, braucht man einen solchen Spannungswandler, der 12 V oder 24 V Gleichstrom in 230 V Wechselstrom umwandelt – beispielsweise im Wohnmobil, im Campingbus, im Schrebergarten oder auf einem Boot.
<G-vec01132-002-s534><convert.umwandeln><en> You can also try online video converter to convert your OGG files to MP3, if you don't want to install a computer program.
<G-vec01132-002-s534><convert.umwandeln><de> Sie können es auch mit einem kostenlosen Online Videokonverter versuchen, der Ihre OGG Dateien in MP3 umwandelt, wenn Sie kein Computerprogramm installieren möchten.
<G-vec01132-002-s535><convert.umwandeln><en> AVI MPEG WMV RM to MP3 Converter is a powerful tool to convert all video and audio files to MP3, WAV, WMA and OGG formats.
<G-vec01132-002-s535><convert.umwandeln><de> Direct MIDI to MP3 Converter ist eine einfache Audio-Utility, die MIDI-Dateien in MP3-, WAV-, WMA- und OGG-Format umwandelt.
<G-vec01132-002-s536><convert.umwandeln><en> Nowadays, due to the advantages of alternating current in terms of transformation and transport possibilities, the transport and distribution networks use almost exclusively alternating current. In the case of applications that need direct current, as in the case of rail using the third rail system, the alternating current arrives at a substation that uses a rectifier to convert it into direct current.
<G-vec01132-002-s536><convert.umwandeln><de> Die Transport- und Verteilungsnetze nutzen heute aufgrund der Vorteile von Wechselstrom hinsichtlich der Transformations- und Transportmöglichkeiten fast ausschließlich Wechselstrom, bei Anwendungen, die Gleichstrom benötigen, wie bei der Schiene Durch den Einsatz des dritten Schienensystems gelangt der Wechselstrom in eine Umspannstation, die ihn mit einem Gleichrichter in Gleichstrom umwandelt.
<G-vec01132-002-s537><convert.umwandeln><en> When you convert the said numbers to performance, you'll play games like Battlefield 1, Overwatch and Rocket League in Full HD resolution at about 50FPS on new CPUs.
<G-vec01132-002-s537><convert.umwandeln><de> Wenn man die Sprache der Zahlen in Performance umwandelt, werden Sie auf den neuen CPUs Spiele wie Battlefield 1, Overwatch und Rocket League in Full HD-Auflösung mit etwa 50 FPS spielen.
<G-vec01132-002-s538><convert.umwandeln><en> Actually it is a short movie, a western, which convert the lyrics into living pictures.
<G-vec01132-002-s538><convert.umwandeln><de> Eigentlich ist es ein kurzer Film, ein Western, der den Songtext in bewegte Bilder umwandelt.
<G-vec01132-002-s539><convert.umwandeln><en> The advantage of energy generation by a fuel cell compared to conventional combustion is that the fuel cell can convert chemical energy directly into electrical energy and does not first convert into heat (thermal energy), which must then be converted into electrical energy by a generator.
<G-vec01132-002-s539><convert.umwandeln><de> Der Vorteil der Energiegewinnung durch eine Brennstoffzelle gegenüber einer herkömmlichen Verbrennung besteht darin, dass die Brennstoffzelle chemische Energie direkt in elektrische Energie umwandeln kann und nicht erst in Wärme (thermische Energie) umwandelt, die dann erst durch einen Generator in elektrische Energie gewandelt werden muss.
<G-vec01132-002-s540><convert.umwandeln><en> For more details, please refer to tutorial: How to Convert iTunes Audiobooks to AAC with chapters kept.
<G-vec01132-002-s540><convert.umwandeln><de> Weitere Details finden Sie im Tutorial: Wie man iTunes-Hörbücher in AAC umwandelt, wobei die Kapitel beibehalten werden.
<G-vec01132-002-s541><convert.umwandeln><en> This indicates it is a male hormonal agent that does not convert testosterone into estrogen.
<G-vec01132-002-s541><convert.umwandeln><de> Das bedeutet, es ist ein männlicher Hormonmittel, das nicht Testosteron in Östrogen umwandelt.
<G-vec01132-002-s542><convert.umwandeln><en> Any future benefactor, as yet completely unknown, would be expected to buy into the Dada movement and not just convert the building into apartments.
<G-vec01132-002-s542><convert.umwandeln><de> Von einem künftigen Käufer wird erwartet, dass er oder sie in die Dada-Bewegung investiert und nicht einfach das Gebäude in ein Mehrfamilienhaus umwandelt.
<G-vec01132-002-s543><convert.umwandeln><en> In order to simplify your product requirements, we have designed a product configurator for you, which will step-by-step ask you for the most important product parameters and finally convert them into a request.
<G-vec01132-002-s543><convert.umwandeln><de> Konfigurator Zur Vereinfachung Ihrer Produktanfragen haben wir für Sie einen Produktkonfigurator gestaltet, welcher von Ihnen Schritt für Schritt die wichtigsten Produktparameter abfragt und abschließend in eine Anfrage umwandelt.
<G-vec01132-002-s544><convert.umwandeln><en> These same principles of tomographic imaging can also be applied to radionuclide scanning, in which the sensors for emitted radiation encircle the patient and computer techniques convert the sensor data into tomographic images; examples include single-photon emission CT (SPECT—see Radionuclide Scanning: Single-photon emission CT (SPECT)) and positron-emission tomography (PET—see Positron Emission Tomography (PET)).
<G-vec01132-002-s544><convert.umwandeln><de> Dieselben Prinzipien der tomographischen Bildgebung können auch beim Radionuklid- Scannen verwendet werden, bei der die Sensoren für die emittierte Strahlung den Patienten umgeben und ein Computer die Sensordaten in tomographische Bilder umwandelt; Beispiele dafür sind das SPECT— Radionuklidszintigraphie: Einzel-positron-emission tomography).
<G-vec01132-002-s545><convert.umwandeln><en> Get help from this solution and learn how to convert 4K to 1080P easily.
<G-vec01132-002-s545><convert.umwandeln><de> Holen Sie sich Hilfe von dieser Lösung und lernen Sie, wie man 4K in 1080P einfach umwandelt.
<G-vec01132-002-s546><convert.umwandeln><en> – Underneath the hob’s surface that is generally made of ceramic glass, an electronic generator shall be provided to convert power from ordinary to high frequency to speed some spiral coils;
<G-vec01132-002-s546><convert.umwandeln><de> – unter den Kochfeldern, die gewöhnlich aus Glaskeramik bestehen, befindet sich ein Elektronikgenerator, der Strom von Normal- in Hochfrequenz umwandelt und ihn in spiralenförmige Spulen leitet.
<G-vec01132-002-s547><convert.umwandeln><en> Just get the brief guide below to learn how to convert DV to MP4 for Windows (Windows 10 included).
<G-vec01132-002-s547><convert.umwandeln><de> Bekommen Sie einfach die kurze Anleitung unten, um zu lernen, wie man DV in MP4 für Windows umwandelt (Windows 10 inklusive).
<G-vec01132-002-s548><convert.umwandeln><en> Normally, before an EV with on-board charger can be used in this way, it would first have to be fitted with a power inverter (to convert the DC current into AC current), at a cost of several thousand euros.
<G-vec01132-002-s548><convert.umwandeln><de> Bei Fahrzeugen mit On-Board-Charger ist dies in der Regel aber nur mit einem zusätzlichen, mehrere Tausend Euro teuren Wechselrichter möglich, der den Gleichstrom in Wechselstrom umwandelt.
<G-vec01132-002-s549><convert.umwandeln><en> If we want to use this energy on a targeted basis during physical and mental activity, we have to know how our bodies convert food into energy.
<G-vec01132-002-s549><convert.umwandeln><de> Wenn wir diese Energie bei körperlichen und geistigen Tätigkeiten gezielt einsetzen wollen, müssen wir wissen, wie unser Körper Nahrung in Energie umwandelt.
<G-vec01132-002-s550><convert.umwandeln><en> This indicates it is a male hormonal agent that does not convert testosterone right into estrogen.
<G-vec01132-002-s550><convert.umwandeln><de> Dies zeigt, es ist ein männliches Hormon, das nicht Testosteron in Östrogen umwandelt.
<G-vec01132-002-s608><convert.umwandeln><en> However, they offer for an opportunity to convert to WAV or MP3 formats.
<G-vec01132-002-s608><convert.umwandeln><de> Allerdings wird einem die Möglichkeit gegeben, WAV-Dateien in MP3-Dateien umzuwandeln.
<G-vec01132-002-s609><convert.umwandeln><en> The amino acid, L-carnitine signals the body to convert the kept fat into power.
<G-vec01132-002-s609><convert.umwandeln><de> Die Aminosäure, L-Carnitin signalisiert der Körper das Fett gehalten in Strom umzuwandeln.
<G-vec01132-002-s610><convert.umwandeln><en> They convert carbon dioxide into organic compounds with the energy from hydrogen sulphide, a common compound in the sediments with the smell of rotten eggs.
<G-vec01132-002-s610><convert.umwandeln><de> Sie nutzen die Energie aus Schwefelwasserstoff – jener Verbindung, die den Geruch von faulen Eiern hervorruft – im umgebenden Sediment, um Kohlendioxid in organische Verbindungen umzuwandeln.
<G-vec01132-002-s611><convert.umwandeln><en> SOLUTION Leverage RichRelevance’s AI-based Personalization Cloud to convert digital interactions and disparate user data into personalized experiences.
<G-vec01132-002-s611><convert.umwandeln><de> Nutzen Sie die, auf künstlicher Intelligenz basierende Personalisierungs-Cloud von RichRelevance, um digitale Interaktionen und die unterscheidlichsten Daten der Nutzer in personalisierte Erlebnisse umzuwandeln.
<G-vec01132-002-s612><convert.umwandeln><en> Your brown adipose tissue is able to convert 100% of the energy supplied to heat and thereby increases your body temperature.
<G-vec01132-002-s612><convert.umwandeln><de> Das braune Fettgewebe ist dazu in der Lage, 100% der zugeführten Energie in Wärme umzuwandeln und hierdurch die Körpertemperatur zu erhöhen.
<G-vec01132-002-s613><convert.umwandeln><en> If you know your bra size, most merchants will be able to help you convert your bra size to a binder size.
<G-vec01132-002-s613><convert.umwandeln><de> Wenn du deine BH-Größe kennst, können dir die meisten Händler helfen, deine BH-Größe in die Größe für ein Band umzuwandeln.
<G-vec01132-002-s614><convert.umwandeln><en> If your blog gets 5000 visitors a month and you manage to convert even 200 of them into subscribers, then you’ll add 2400 extra people that serve as a source of repeat traffic each year.
<G-vec01132-002-s614><convert.umwandeln><de> Wenn Dein Blog 5.000 Besucher pro Monat erzielt und es Dir gelingt 200 davon in Abonnenten umzuwandeln, dann fügst Du 2.400 zusätzliche Leute hinzu, die jedes Jahr als Quelle für wiederholten Traffic dienen.
<G-vec01132-002-s615><convert.umwandeln><en> 19. September 2019 While last month the Ministry of Public Finance published a draft Government Ordinance obliging underperforming companies to convert their debts to associates and shareholders into stocks and shares, this month the authorities have revised the legal provisions in question.
<G-vec01132-002-s615><convert.umwandeln><de> Während das Finanzministerium im vergangenen Monat den Entwurf einer Regierungsverordnung veröffentlichte, wonach leistungsschwache Unternehmen verpflichtet sein sollen, ihre Verbindlichkeiten gegenüber verbundenen Unternehmen und Gesellschaftern in Aktien und Anteile umzuwandeln, haben die Behörden die betreffenden rechtlichen Bestimmungen nun abgeschwächt – die Umwandlung wird nicht mehr verpflichtend sein, sondern optional.
<G-vec01132-002-s616><convert.umwandeln><en> We want to help you convert a right way to support your ideas and innovations into the product / service and speed up implementation process.
<G-vec01132-002-s616><convert.umwandeln><de> Wir möchten Ihnen dabei helfen, einen richtigen Weg um Ihre Ideen und Innovationen ins Produkt/Dienstleistung umzuwandeln und Realisierungsprozess zu beschleunigen.
<G-vec01132-002-s617><convert.umwandeln><en> Once the screen capture has been taken, Screen Recording allows you to convert the video format to the most useful format for the users (AVI, MKV, MP4, WMF, SWF,...), to make the most of it.
<G-vec01132-002-s617><convert.umwandeln><de> Sobald der Bildschirm eingefangen wurde, ermöglicht Ihnen Screen Recording, das Videoformat in das Format umzuwandeln,das für den Benutzer am nützlichsten erscheint(AVI,MKV,MP4,WMF,SWF...).
<G-vec01132-002-s618><convert.umwandeln><en> There're increasingly more people looking for ways to convert M2TS to MKV in various forums, either for save up space for storage or being compatibe with media player.
<G-vec01132-002-s618><convert.umwandeln><de> Es gibt ein steigende Anzahl von Leuten, die in Foren nach Methoden suchen, um M2TS in MKV umzuwandeln, entweder weil Sie Speicherplatz sparen oder Dateien mit Ihrem Media-Player kompatibel machen wollen.
<G-vec01132-002-s619><convert.umwandeln><en> In order to convert the bonus in to cash and in order to qualify for cash out, the bonus needs to be wagered at least five times against odds 2.0 or higher.
<G-vec01132-002-s619><convert.umwandeln><de> Um den Bonus in Bargeld umzuwandeln und um sich für Bargeld zu qualifizieren, muss der Bonus mindestens fünf Mal gegen die Quote 2,0 oder höhergesetzt werden.
<G-vec01132-002-s620><convert.umwandeln><en> Library to convert HTML code to PDF files.
<G-vec01132-002-s620><convert.umwandeln><de> Bibliothek um HTML-Code in PDF-Dateien umzuwandeln.
<G-vec01132-002-s621><convert.umwandeln><en> The Secure Site Seal helps you convert visitors into paying customers by increasing the visible trust in your website.
<G-vec01132-002-s621><convert.umwandeln><de> Das Secure Site Seal hilft Ihnen, Besucher in zahlende Kunden umzuwandeln, indem es das sichtbare Vertrauen in Ihre Website vergrößert.
<G-vec01132-002-s622><convert.umwandeln><en> The FSC investigates novel pathways to convert renewable energy, for example from biomass or carbon dioxide, into liquid energy carriers, the so-called bio-hybrid fuels, and prepare them for utilization in the mobility sector.
<G-vec01132-002-s622><convert.umwandeln><de> Der ab Januar 2019 geförderte Exzellenzcluster FSC erforscht innovative und erfolgversprechende Wege, um erneuerbare Energie mit biomassebasierten Rohstoffen und CO2 in flüssige Energieträger mit hoher Energiedichte, die „Bio-hybrid Fuels“, umzuwandeln und für den Mobilitätssektor nutzbar zu machen.
<G-vec01132-002-s623><convert.umwandeln><en> This can be used to convert the event to a local time.
<G-vec01132-002-s623><convert.umwandeln><de> Dies kann verwendet werden, um das Ereignis in eine lokale Zeit umzuwandeln.
<G-vec01132-002-s624><convert.umwandeln><en> However, it is possible to convert your MQL EA or Indicator code to C# by following the link.
<G-vec01132-002-s624><convert.umwandeln><de> Es ist jedoch möglich, Ihren MQ4-Code für Ihren EA oder Ihren Indikator in C# umzuwandeln, wenn Sie auf folgenden Link klicken.
<G-vec01132-002-s625><convert.umwandeln><en> It is no longer necessary to convert to 24 Bit RGB.
<G-vec01132-002-s625><convert.umwandeln><de> Es ist nicht mehr notwendig, sich zu 24-Bit-RGB umzuwandeln.
<G-vec01132-002-s626><convert.umwandeln><en> The ability to access safety system data via the Internet of Things (IoT) in real time and to convert this into meaningful information unlocks enormous potential.
<G-vec01132-002-s626><convert.umwandeln><de> Die Möglichkeit, über das Internet der Dinge (IoT) in Echtzeit auf Sicherheitssystemdaten zuzugreifen und diese in aussagekräftige Informationen umzuwandeln, birgt ein großes Potenzial.
<G-vec01132-002-s627><convert.verwandeln><en> Full integration with your blog(s) to convert posts into emails.
<G-vec01132-002-s627><convert.verwandeln><de> Komplette Integration mit Ihren Blogs, um Posts in E-Mails verwandeln zu können.
<G-vec01132-002-s628><convert.verwandeln><en> And when you don't need the extra storage, unclip the front cover and convert it into a slim, lightweight case.
<G-vec01132-002-s628><convert.verwandeln><de> Und wenn Sie den zusätzlichen Platz nicht benötigen, klipsen Sie die vordere Abdeckung ab und verwandeln die Hülle in eine schlanke, leichte Hülle.
<G-vec01132-002-s629><convert.verwandeln><en> Use OCR (Optical Character Recognition) to convert paper files in up to 25 languages into digital, editable and searchable files.
<G-vec01132-002-s629><convert.verwandeln><de> Nutzen Sie OCR (optische Zeichenerkennung) um Papierdokumente in bis zu 25 Sprachen in digitale, bearbeitbare und durchsuchbare Dateien zu verwandeln.
<G-vec01132-002-s630><convert.verwandeln><en> Our goal should be to convert these into real and positive benefits, such as for the local communities we visit, where we can help generate economic opportunities and provide the stimulus for long-term sustainability.
<G-vec01132-002-s630><convert.verwandeln><de> Tourismus hat weitreichende Folgen.Diese Folgen sollten wir verwandeln in wirkliches und positives Wohlergehen für die lokalen Gemeinschaften, die wir besuchen, denen wir dabei helfen können, ökonomische Fortschritte zu erreichen und Samen für nachhaltiges Tun zu legen.
<G-vec01132-002-s631><convert.verwandeln><en> After wrapping my mind around the analytics side of things, I knew what I needed to do to convert my social media traffic.
<G-vec01132-002-s631><convert.verwandeln><de> Als ich mich aber endlich an die Kennzahlen gewöhnt hatte, wusste ich, was ich tun musste, um meinen Social-Media-Traffic in Kunden zu verwandeln.
<G-vec01132-002-s632><convert.verwandeln><en> The managers of Central Suites Barcelona, Belén and Pedro, are not only descendants of the initial owners of the house, but also keen travellers. Having completed a one year round the world trip, they made every effort to convert these suites into ideal apartments, the kind that they would like to find on their own travels.
<G-vec01132-002-s632><convert.verwandeln><de> Die Geschäftsführer der Central Suites Barcelona, Belén und Pedro, Nachfahren der ursprünglichen Besitzer und passionierte Reisende, haben nach einer einjährigen Weltreise viele Anstrengungen unternommen, diese Suites in das ideale Appartement zu verwandeln, so wie sie es gerne auf ihren Reisen vorgefunden hätten.
<G-vec01132-002-s633><convert.verwandeln><en> Using the dongle, you can convert your docking station into a wireless speaker you can control using your iPhone, Android smartphone or tablet from the comfort of your settee.
<G-vec01132-002-s633><convert.verwandeln><de> Mit dem Dongle verwandeln Sie zudem Ihre Docking-Station in einen kabellosen Lautsprecher und können Sie bequem per iPhone, Android Smartphone oder Tablet vom Sofa aus bedienen.
<G-vec01132-002-s634><convert.verwandeln><en> The option to convert frequent users into paying users.
<G-vec01132-002-s634><convert.verwandeln><de> Die Möglichkeit, häufige Nutzer in zahlende Nutzer zu verwandeln.
<G-vec01132-002-s635><convert.verwandeln><en> But we can convert the crows into swans.
<G-vec01132-002-s635><convert.verwandeln><de> Doch wir können die Krähen in Schwäne verwandeln.
<G-vec01132-002-s636><convert.verwandeln><en> This independence means that we are able to convert a design into a completed product very quickly.
<G-vec01132-002-s636><convert.verwandeln><de> Aufgrund dieser Unabhängigkeit sind wir in der Lage ein Design sehr rasch in ein vollendetes Produkt zu verwandeln.
<G-vec01132-002-s637><convert.verwandeln><en> PLAYTIME - ANYTIME Convert any smooth surface to a safari play time with the Bumbo Playtop Safari Suction Tray.
<G-vec01132-002-s637><convert.verwandeln><de> Verwandeln Sie mit dem Spielaufsatz Safari, dem Aufsatz mit Saughaftung, jede glatte Oberfläche in eine Safari-Spielzeit.
<G-vec01132-002-s638><convert.verwandeln><en> A few years later the EU bureaucracy had managed to convert this vision into a so-called “balanced approach”, based on a consensus without vision, taste, smell or color, grey as the skies above Brussels.
<G-vec01132-002-s638><convert.verwandeln><de> Nach ein paar Jahren hatte es die EU-Bürokratie geschafft, diese Vision in einen sogenannten „ausgewogenen Ansatz“ („balanced approach“) zu verwandeln, dessen kleinster gemeinsamer Nenner ohne Vision, Kraft und Farbe war, grau wie der Himmel über Brüssel.
<G-vec01132-002-s639><convert.verwandeln><en> It can be invisibly built into displays and convert them into payment and authentication interfaces.
<G-vec01132-002-s639><convert.verwandeln><de> Die Antenne kann unsichtbar in Displays verbaut werden und diese in Zahlungs- und Authentifizierungsschnittstellen verwandeln.
<G-vec01132-002-s640><convert.verwandeln><en> This is useful if you want to convert them into an HDR by hand later with another program.
<G-vec01132-002-s640><convert.verwandeln><de> Das ist sinnvoll, wenn ihr diese später mit einem anderen Programm händisch in ein HDR zu verwandeln wollt.
<G-vec01132-002-s641><convert.verwandeln><en> You are able “to weave bonds of belonging and togetherness which convert overcrowding into an experience of community in which the walls of the ego are torn down and the barriers of selfishness overcome” (ibid., 149).
<G-vec01132-002-s641><convert.verwandeln><de> Ihr seid fähig, »Bande der Zugehörigkeit und des Zusammenlebens zu knüpfen, die das Gedränge in eine Gemeinschaftserfahrung verwandeln, wo die Wände des Ichs durchbrochen und die Schranken des Egoismus überwunden werden« (ebd., 149).
<G-vec01132-002-s642><convert.verwandeln><en> We're looking for heroes: to go into battle alongside us courageously – and convert challenges into opportunities.
<G-vec01132-002-s642><convert.verwandeln><de> Wir sind auf der Suche nach Helden: die mutig mit uns in den Kampf ziehen – und Challenges in Chancen verwandeln.
<G-vec01132-002-s643><convert.verwandeln><en> And, here’s a neat trick; the app can even scan and convert your handwriting into digital text characters that you can then export.
<G-vec01132-002-s643><convert.verwandeln><de> Ebenfalls prima: Die App kann Ihre Handschrift beim Exportieren sogar scannen und in digitalisierten Text verwandeln.
<G-vec01132-002-s644><convert.verwandeln><en> The aim of the analysis is to convert data as quickly as possible into knowledge with which the company can use to take important decisions.
<G-vec01132-002-s644><convert.verwandeln><de> Ziel der Analyse ist es, die Daten so schnell wie möglich in Wissen zu verwandeln und daraus entscheidungsrelevante Erkenntnisse für das Unternehmen zu gewinnen.
<G-vec01132-002-s665><convert.wandeln><en> Thermoelectric generators (TEG) use this waste heat and convert it into electrical energy.
<G-vec01132-002-s665><convert.wandeln><de> Thermoelektrische Generatoren (TEG) nutzen diese Abwärme und wandeln sie in elektrische Energie um.
<G-vec01132-002-s666><convert.wandeln><en> We simply convert the invariable vectorized graphic format "PDF" into an editable format.
<G-vec01132-002-s666><convert.wandeln><de> Wir wandeln hierfür das unveränderliche vektorisierte Grafikformat „PDF“ einfach in ein editierbares Format um.
<G-vec01132-002-s667><convert.wandeln><en> With WAV to MP3 Converter you easily rip your audio CDs to MP3, FLAC or WMA files for use with your hardware player or convert files that do not play with other audio software.
<G-vec01132-002-s667><convert.wandeln><de> Fazit: Der Free CD to MP3 Converter ist ein kostenloses CD-Ripper-Tool um Musik von Audio-CD's in MP3 oder andere Formate zu wandeln und auf Festplatte zu speichern.
<G-vec01132-002-s668><convert.wandeln><en> We convert all elements, except for the foundation blocks, into analysis objects.
<G-vec01132-002-s668><convert.wandeln><de> Wir wandeln alle Elemente (bis auf die Blockfundamente) in Analyseobjekte um.
<G-vec01132-002-s669><convert.wandeln><en> Thermoelectric generators convert waste heat directly into electricity.
<G-vec01132-002-s669><convert.wandeln><de> Thermoelektrische Generatoren wandeln Abwärme direkt in elektrischen Strom.
<G-vec01132-002-s670><convert.wandeln><en> The current transformers of the PCE-LCTB 100 / 130V (45) series can detect primary currents from 400 A to 3200 A depending on the design and convert these into a 1 A or 5 A secondary current.
<G-vec01132-002-s670><convert.wandeln><de> Die Hutschienen-Messgeräte der PCE-LCTB 100/100V (45) Serie können je nach Ausführung Primärströme von 400 A bis 2500 A erfassen und wandeln diese in einen 1 A oder 5 A Sekundärstrom um.
<G-vec01132-002-s671><convert.wandeln><en> However, plants do something very similar: they convert the energy from sunlight into usable energy.
<G-vec01132-002-s671><convert.wandeln><de> Dabei machen Pflanzen etwas ganz Ähnliches: Sie wandeln die Energie des Sonnenlichts in nutzbare Energie um.
<G-vec01132-002-s672><convert.wandeln><en> Rightly all kinds of plants, through photosynthesis, convert solar energy into chemical energy, storing the energy in plants body.
<G-vec01132-002-s672><convert.wandeln><de> Pflanzen setzen Sauerstoff durch Photosynthese frei, absorbieren Kohlendioxid und wandeln Sonnenenergie in chemische Energie zur Speicherung in Pflanzen um.
<G-vec01132-002-s673><convert.wandeln><en> Close to the action, sensors convert mechanical parameters such as force, pressure, sound, vibrations, paths, positions or movements into digital or analogue signals. read more >>
<G-vec01132-002-s673><convert.wandeln><de> Ganz nah am Ort des Geschehens wandeln Sensoren mechanische Größen wie Kraft, Druck, Schall, Schwingungen, Wege, Positionen oder Bewegungen in digitale oder analoge Signale um.
<G-vec01132-002-s674><convert.wandeln><en> They convert water (steam) into mechanical energy just like the originals. This energy can be used to drive our models.
<G-vec01132-002-s674><convert.wandeln><de> Wie ihre Vorbilder wandeln auch die Wilesco-Dampfmaschinen Wärme in mechanische Energie um, welche zum Antrieb von Modellen genutzt werden kann.
<G-vec01132-002-s675><convert.wandeln><en> Hereby, the task was to convert various document formats of the old archive to the PDF/A format, to attach a digital signature, and to archive the document in the new system.
<G-vec01132-002-s675><convert.wandeln><de> Hierbei war es die Aufgabe, die verschiedenen Dokumentenformate des alten Archivs in PDF/A zu wandeln, mit einer gültigen digitalen Signatur zu versehen und im neuen System zu archivieren.
<G-vec01132-002-s676><convert.wandeln><en> Accreting black holes convert typically ten to thirty percent of the accreted rest mass energy into short-wavelength radiation and into nuclear winds.
<G-vec01132-002-s676><convert.wandeln><de> Akkretierende Schwarze Löcher wandeln typischerweise zehn bis 30 Prozent der akkretierten Restmasse in Kurzwellenstrahlung und nukleare Winde um.
<G-vec01132-002-s677><convert.wandeln><en> Convert ratchet spanners into ratchets.
<G-vec01132-002-s677><convert.wandeln><de> Wandeln Ratschenschlüssel in Knarren um.
<G-vec01132-002-s678><convert.wandeln><en> They convert light energy to an electrical signal output.
<G-vec01132-002-s678><convert.wandeln><de> Sie wandeln Lichtenergie in elektrische Signale um.
<G-vec01132-002-s679><convert.wandeln><en> The blades propel the water parallel to the revolving axis and thus convert the energy of the whirlwind into mechanical force.
<G-vec01132-002-s679><convert.wandeln><de> Die Schaufeln der Turbine leiten den Wasserstrom parallel zur Drehachse um und wandeln somit die Energie des Wirbels in mechanische Arbeit um.
<G-vec01132-002-s680><convert.wandeln><en> The microorganisms in the sand, for example, remove nitrate, which passes from agricultural land via rivers into coastal seas, and convert it into harmless nitrogen gas.
<G-vec01132-002-s680><convert.wandeln><de> Die Mikroorganismen im Sand entfernen zum Beispiel Nitrat, das aus der Landwirtschaft über die Flüsse in die Küstenmeere gelangt, und wandeln es in harmloses Stickstoffgas um.
<G-vec01132-002-s681><convert.wandeln><en> The latter – the sole production of N2 – is particularly intriguing: Some microbes convert NO to nitrous oxide (N2O), which is a potent greenhouse gas.
<G-vec01132-002-s681><convert.wandeln><de> Letzteres – die alleinige Produktion von N2 – ist besonders faszinierend: Einige Mikroben wandeln NO in Lachgas (N2O) um, das ein starkes Treibhausgas ist.
<G-vec01132-002-s682><convert.wandeln><en> Thanks to its One-Hand Fold its possible to convert it into a compact and free standing package.
<G-vec01132-002-s682><convert.wandeln><de> Dank seiner Einhand-Faltmechanik lässt er sich einfach und platzsparend verstauen: es ist möglich den Kinderwagen einfach zu einem kompakten Paket zu wandeln.
<G-vec01132-002-s683><convert.wandeln><en> Solar panels convert sunlight to electricity.
<G-vec01132-002-s683><convert.wandeln><de> Solarpaneele wandeln Sonnenlicht in Strom um.
<G-vec01132-002-s684><convert.wandeln><en> Convert your folders to albums for easy management.
<G-vec01132-002-s684><convert.wandeln><de> Wandeln Sie Ihre Ordner für eine einfache Verwaltung in Alben um.
<G-vec01132-002-s685><convert.wandeln><en> Convert files to PDF from any printable application, or create PDF files directly from your scanner.
<G-vec01132-002-s685><convert.wandeln><de> Wandeln Sie Dateien aus einer beliebigen Druckanwendung in PDFs um oder erstellen Sie PDF-Dateien direkt mit Ihrem Scanner.
<G-vec01132-002-s686><convert.wandeln><en> Then convert the data to text that can be edited and analyzed in Microsoft Excel.
<G-vec01132-002-s686><convert.wandeln><de> Anschließend wandeln Sie den Text in Daten um, die Sie in Microsoft Excel bearbeiten und auswerten können.
<G-vec01132-002-s687><convert.wandeln><en> Save the file to your computer's hard drive, then convert it.
<G-vec01132-002-s687><convert.wandeln><de> Speichern Sie die Datei auf der Festplatte Ihres Computers und wandeln Sie sie dann um.
<G-vec01132-002-s688><convert.wandeln><en> The photo suite can also be used on your regular photos taken outside of Cycloramic.- Immersive 3D viewer.- Video Conversion: Convert any photo into a video (240p, 360p, 480p, 720p or 1080p resolutions).- Panorama Photo to INSTAGRAM Video converter.- Share to Facebook, Twitter, INSTAGRAM (photo and video), email, sms and camera roll.-...
<G-vec01132-002-s688><convert.wandeln><de> Die Fotosuite kann auf Ihren regelmäßigen Fotos auch benutzt werden, die außerhalb Cycloramic genommen werden.- Immersive 3D Projektor.- Videoumwandlung: Wandeln Sie jedes mögliches Foto in Auflösungen (um 240p, 360p, 480p, 720p oder 1080p) eines Bildschirmes.- Panorama Foto zum Instagram Bildschirm Converter.- Anteil zu Facebook, Twitter, Instagram (Foto und Bildschirm), email, sms und Kamera rollen.-...
<G-vec01132-002-s689><convert.wandeln><en> Convert any 2D videos to a 3D format at ultrafast speeds.
<G-vec01132-002-s689><convert.wandeln><de> Wandeln Sie 2D-Videos um, damit Sie diese auf 3D-fähigen Geräten abspielen können.
<G-vec01132-002-s690><convert.wandeln><en> Convert the selection to path.
<G-vec01132-002-s690><convert.wandeln><de> Wandeln Sie die Auswahl in einen Pfad um.
<G-vec01132-002-s691><convert.wandeln><en> Select a free column chart template from the thousands of examples available in the Edraw Library and convert to word column chart template with one click.
<G-vec01132-002-s691><convert.wandeln><de> Wählen Sie eine kostenlose Mindmap-Vorlage aus Tausende von Beispielen in der Edraw Software und wandeln Sie es in PowerPoint-Format mit nur einem Klick um.
<G-vec01132-002-s692><convert.wandeln><en> To preserve rendering effects on an image stack, convert the Smart Object to a regular layer.
<G-vec01132-002-s692><convert.wandeln><de> Um die Renderwirkungen auf einen Bildstapel beizubehalten, wandeln Sie das Smartobjekt in eine reguläre Ebene um.
<G-vec01132-002-s693><convert.wandeln><en> Convert various formats to AVI, MPEG, VCD, and WMV in batch mode.
<G-vec01132-002-s693><convert.wandeln><de> Wandeln Sie verschiedene Formate in AVI, MPEG, VCD und WMV in Schüben um.
<G-vec01132-002-s694><convert.wandeln><en> Convert PowerPoint presentations to videos in no minute.
<G-vec01132-002-s694><convert.wandeln><de> Wandeln Sie PowerPoint-Präsentationen in Videos um.
<G-vec01132-002-s695><convert.wandeln><en> Convert your audio files between various formats: MP3, WMA, WAV, M4A, FLAC and others.
<G-vec01132-002-s695><convert.wandeln><de> Wandeln Sie Ihre Audiodateien zwischen zahlreichen Formaten um: MP3, WMA, WAV, M4A, FLAC und andere.
<G-vec01132-002-s696><convert.wandeln><en> With Digital Media Converter Pro, convert your recorded DVR-MS TV shows to your portable multimedia players and enjoy them anywhere you go.
<G-vec01132-002-s696><convert.wandeln><de> Mit Digital Media Converter Pro, wandeln Sie Ihre aufgezeichneten DVR-MS TV-Sendungen in Ihre tragbaren Multimedia-Player um und genießen Sie sie überall.
<G-vec01132-002-s697><convert.wandeln><en> Convert several video files at once and burn them onto a DVD/Blu-ray disc.
<G-vec01132-002-s697><convert.wandeln><de> Wandeln Sie mehrere Videodateien auf einmal um und brennen Sie sie auf eine Blu-ray/DVD-Disk.
<G-vec01132-002-s698><convert.wandeln><en> Select a free swot matrix template from the thousands of examples available in the Edraw Library and convert to PowerPoint swot matrix template with one click.
<G-vec01132-002-s698><convert.wandeln><de> Wählen Sie ein kostenloses Concept-Map-Beispiel von Concept-Map-Vorlagen in der Bibliothek Edraw und wandeln Sie es in PPT-Format mit nur einem Klick.
<G-vec01132-002-s699><convert.wandeln><en> Convert YouTube to MP3.
<G-vec01132-002-s699><convert.wandeln><de> Wandeln Sie YouTube zu MP3 um.
<G-vec01132-002-s700><convert.wandeln><en> Select a free IDEF diagram template from the thousands of examples available in the Edraw Library and convert it to word IDEF diagram template with one click.
<G-vec01132-002-s700><convert.wandeln><de> Wählen Sie eine kostenlose Vorlage von Beispielen in der Bibliothek Edraws und wandeln Sie es in Word-Format mit nur einem Klick.
<G-vec01132-002-s701><convert.wandeln><en> Use the SUM function and convert any numbers that you want to subtract to their negative values.
<G-vec01132-002-s701><convert.wandeln><de> Verwenden Sie die FunktionSUMME, und wandeln Sie alle Zahlen, die sie subtrahieren möchten, in die entsprechenden negativen Werte um.
<G-vec01132-002-s702><convert.wandeln><en> Select a free network diagram template from the thousands of examples available in the Edraw Library and convert to PowerPoint network diagram template with one click.
<G-vec01132-002-s702><convert.wandeln><de> Wählen Sie eine kostenlose Vorlage in der Edraw Software und wandeln Sie es ins PPT-Format mit nur einem Klick.
<G-vec01132-002-s703><convert.wandeln><en> During the day, solar cells convert solar energy into electricity and store it in the battery.
<G-vec01132-002-s703><convert.wandeln><de> Tagsüber wandeln Solarzellen Sonnenenergie in Strom um und speichern sie in der Batterie.
<G-vec01132-002-s704><convert.wandeln><en> Inverters convert direct current into alternating current. Description of the product target audience
<G-vec01132-002-s704><convert.wandeln><de> Wechselrichter, auch Inverter genannt, wandeln Gleichstrom in Wechselstrom um.
<G-vec01132-002-s705><convert.wandeln><en> That’s why casinos convert your Bitcoin deposit into casino credits and then you can use your credits any way you like on your favourite casino games.
<G-vec01132-002-s705><convert.wandeln><de> Deswegen wandeln Casinos Ihre Bitcoin Einzahlung in Casino Credits um und dann können Sie Ihre Credits so zum Spielen Ihrer Lieblingsspiele nutzen, wie Sie es gerne möchten.
<G-vec01132-002-s706><convert.wandeln><en> However, we convert it into special products.
<G-vec01132-002-s706><convert.wandeln><de> Wir wandeln es jedoch in spezielle Produkte um.
<G-vec01132-002-s707><convert.wandeln><en> Turbo retarders (fig. 9b) convert excessive kinetic energy of trucks into heat.
<G-vec01132-002-s707><convert.wandeln><de> Turbo-Retarder (Bild 9b) wandeln die überschüssige kinetische Energie von Lkw in Wärme um.
<G-vec01132-002-s708><convert.wandeln><en> PV power inverters convert the DC current of PV generators into AC current.
<G-vec01132-002-s708><convert.wandeln><de> PV-Wechselrichter wandeln bekanntermaßen den Gleichstrom vom PV-Generator in Wechselstrom um.
<G-vec01132-002-s709><convert.wandeln><en> In hydrogen-powered electric vehicles, fuel cells convert hydrogen into electricity that drives an electric motor.
<G-vec01132-002-s709><convert.wandeln><de> Bei mit Wasserstoff betriebenen Elektrofahrzeugen wandeln Brennstoffzellen Wasserstoff in Strom um, der einen Elektromotor antreibt.
<G-vec01132-002-s710><convert.wandeln><en> Taste receptors convert chemical stimuli into electric signals.
<G-vec01132-002-s710><convert.wandeln><de> Seine Rezeptoren wandeln Licht in elektrische Impulse um.
<G-vec01132-002-s711><convert.wandeln><en> With the freeware Free HTML5 Video Player and Converter you can convert your videos into a HTML5 compatible format.
<G-vec01132-002-s711><convert.wandeln><de> Mit der kostenlosen Software Free HTML5 Video Player and Converter von DVD-Videosoft wandeln Sie Ihre Videos in das HTML5 Videoformat um.
<G-vec01132-002-s712><convert.wandeln><en> Solar panels convert sunlight directly into electricity, using a process known as photovoltaics (PV).
<G-vec01132-002-s712><convert.wandeln><de> Durch den Vorgang der Photovoltaik (PV) wandeln Solarmodule Sonnenlicht direkt in Strom um.
<G-vec01132-002-s713><convert.wandeln><en> They convert plastic waste into gasoline and diesel and can thus benefit from it.
<G-vec01132-002-s713><convert.wandeln><de> Sie wandeln Müll in Benzin und Diesel um und können so einen positiven Nutzen davon tragen.
<G-vec01132-002-s714><convert.wandeln><en> With the help of these silicon structures, they convert precision mechanical movements into an electrical signal.
<G-vec01132-002-s714><convert.wandeln><de> Mit Hilfe dieser Silizium-Strukturen wandeln sie feinmechanische Bewegungen in ein elektrisches Signal um.
<G-vec01132-002-s715><convert.wandeln><en> They convert the mains AC voltage into a DC voltage of 24 V.
<G-vec01132-002-s715><convert.wandeln><de> Sie wandeln die Netzwechselspannung in eine Betriebsspannung von DC 24 V um.
<G-vec01132-002-s716><convert.wandeln><en> Muscles convert chemical energy directly into physical energy and heat.
<G-vec01132-002-s716><convert.wandeln><de> Die Muskeln wandeln chemische Energie direkt in physische Energie und Wärme um.
<G-vec01132-002-s717><convert.wandeln><en> To do this, our analysts convert their findings of malware authors’ new techniques into new algorithms, which our machines then use to learn how to make decisions when they receive new data.
<G-vec01132-002-s717><convert.wandeln><de> Hierzu wandeln unsere Analytiker ihre Erkenntnisse zu den Techniken von Malware-Entwicklern in neue Algorithmen um, die unsere Maschinen dann einsetzen, um zu lernen und Entscheidungen zu treffen, sobald neue Daten eingehen.
<G-vec01132-002-s718><convert.wandeln><en> Photovoltaic (PV) cells or solar cells convert energy of light directly into electricity.
<G-vec01132-002-s718><convert.wandeln><de> Photovoltaik Photovoltaik-Zellen oder Solarzellen wandeln Lichtenergie direkt in Strom um.
<G-vec01132-002-s719><convert.wandeln><en> Please convert fonts that are used in logos into paths as well.
<G-vec01132-002-s719><convert.wandeln><de> Wandeln Sie auch in Logos die Schriften in Pfade um.
<G-vec01132-002-s720><convert.wandeln><en> They bind to mineral surfaces or convert minerals through metabolic processes.
<G-vec01132-002-s720><convert.wandeln><de> Sie binden an Mineraloberflächen oder wandeln mineralische Bestandteile durch Stoffwechselvorgänge um.
<G-vec01132-002-s721><convert.wandeln><en> They are used to increase or decrease alternating current; they convert mains voltage into low current.
<G-vec01132-002-s721><convert.wandeln><de> Sie werden zur Erhöhung oder Verringerung von Wechselstrom verwendet; sie wandeln Netzspannung in Schwachstrom um.
<G-vec01132-002-s722><convert.wandeln><en> It is used to convert a binary number into a decimal number.
<G-vec01132-002-s722><convert.wandeln><de> Sie wandelt eine binäre Zahl (Dualzahl) in eine dezimale Zahl um.
<G-vec01132-002-s723><convert.wandeln><en> Hearing is a complicated process. Sound signals in the environment funnel into the ear, where a series of reactions convert acoustic energy into electrical impulses that the brain can understand.
<G-vec01132-002-s723><convert.wandeln><de> Erfahrungsbeist ein komplexer Vorgang: Das Ohr nimmt den Umgebungsschall auf und wandelt die akustische Energie durch eine Abfolge von Reaktionen in elektrische Signale um, die das Gehirn verstehen kann.
<G-vec01132-002-s724><convert.wandeln><en> (5): +100 Precision (6): When you use an elite skill, convert up to 5 conditions into boons.
<G-vec01132-002-s724><convert.wandeln><de> (5): +100 Präzision (6): Wenn ihr eine Elite-Fertigkeit einsetzt, wandelt ihr bis zu 5 Zustände in Segen um.
<G-vec01132-002-s725><convert.wandeln><en> The application will convert the data which is supported by the Android device and begin the transfer process.
<G-vec01132-002-s725><convert.wandeln><de> Die Anwendung wandelt die vom Android-Gerät unterstützten Daten um, und der Übertragungsprozess beginnt.
<G-vec01132-002-s726><convert.wandeln><en> Any Video convertor final Crack delivers all-in-one answer to convert most forms of audio and video formats.
<G-vec01132-002-s726><convert.wandeln><de> Quick Media Converter HD 4.5.0 Quick Media Converter wandelt nahezu alle verbreiteten Audio und Video Dateiformate um.
<G-vec01132-002-s727><convert.wandeln><en> When a cell needs energy it convert fat, carbohydrate, protein, and alcohol to the ATP (adenosine triphosphate), a molecule that stores energy in its chemical form.
<G-vec01132-002-s727><convert.wandeln><de> Benötigt eine Zelle Energie, wandelt sie Fett, Kohlenhydrate, Proteine und Alkohol in das Molekül ATP (Adenosintriphosphat) um, das in seiner chemischen Form Energie speichert.
<G-vec01132-002-s728><convert.wandeln><en> It is used to convert a hexadecimal number into a decimal number.
<G-vec01132-002-s728><convert.wandeln><de> Sie wandelt eine hexadezimale Zahl in eine dezimale Zahl um.
<G-vec01132-002-s729><convert.wandeln><en> Where the amount of fuel uplift or the amount of fuel remaining in the tanks is determined in units of volume, expressed in litres, the company shall convert that amount from volume to mass by using actual density values.
<G-vec01132-002-s729><convert.wandeln><de> Wird die gebunkerte oder die in den Tanks verbliebene Kraftstoffmenge in Volumeneinheiten, ausgedrückt in Litern, bestimmt, so wandelt das Schifffahrtsunternehmen diese Menge anhand von realen Dichtewerten von Volumen in Masse um.
<G-vec01132-002-s730><convert.wandeln><en> If you later should need the WAV file again with its original cue list, simply convert the MP3 file back to WAV and import the cue list from the cue list file.
<G-vec01132-002-s730><convert.wandeln><de> Benötigt man später wieder die WAV-Datei mit der ursprünglichen Cue-List, wandelt man die MP3-Datei einfach wieder in eine WAV-Datei um und importiert anschließend aus der dazugehörigen Cue-List-Datei die Cue-List.
<G-vec01132-002-s731><convert.wandeln><en> The ProCleave LD II has several new features that convert the ProCleave model from a manual to an automatic fiber cleaver.
<G-vec01132-002-s731><convert.wandeln><de> Durch zahlreiche neue Features wandelt sich der ProCleave vom manuellen zum automatischen Fasercleaver.
<G-vec01132-002-s732><convert.wandeln><en> The CEL-capable, fully resonant welding inverter detects in fully automatic fashion if the current supplied is alternating current (mains or generator) or direct current (battery) and will then convert this current into a uniform and powerful arc.
<G-vec01132-002-s732><convert.wandeln><de> Der CEL-fähige, vollresonante Schweißinverter erkennt vollautomatisch, ob Strom als Wechselstrom (Netz oder Generator) oder Gleichstrom (Akku) geliefert wird und wandelt diesen in einen gleichmäßigen, druckvollen Lichtbogen um.
<G-vec01132-002-s733><convert.wandeln><en> KEB has created tools for different tasks, which support you with the use of drive controllers and convert the complexity of possible adjustments on a user friendly basis.
<G-vec01132-002-s733><convert.wandeln><de> KEB hat für verschiedene Aufgabenstellungen Werkzeuge geschaffen, die Sie in der Anwendung von Antriebsstellern unterstützen und die Komplexität möglicher Einstellungen auf eine bedienergeführte Basis wandelt.
<G-vec01132-002-s735><convert.wandeln><en> The principle is fairly simple: the muscles convert chemically stored energy from free fatty acids, proteins, and carbohydrates into mechanical energy.
<G-vec01132-002-s735><convert.wandeln><de> Das Prinzip ist ganz einfach: Der Muskel wandelt chemisch gespeicherte Energie aus freien Fettsäuren, Proteinen und Kohlenhydraten in mechanische Energie um.
<G-vec01132-002-s736><convert.wandeln><en> In normal use the power electronics convert the current so that it can be fed into the household consumer unit or the national grid.
<G-vec01132-002-s736><convert.wandeln><de> Im normalen USE-Case wandelt unsere Leistungselektronik den Strom so, dass er im Anschluss entweder in das Hausnetz oder in das öffentliche Verbrauchernetz eingespeist werden kann.
<G-vec01132-002-s737><convert.wandeln><en> Convert an HDMI input to SDI output.
<G-vec01132-002-s737><convert.wandeln><de> Wandelt eingehende HDMI-Signale für die SDI-Ausgabe um.
<G-vec01132-002-s738><convert.wandeln><en> The program will then begin to upscale video resolution and convert it to the format you have chosen.
<G-vec01132-002-s738><convert.wandeln><de> Das Programm beginnt dann Videoauflösung zu steigern und wandelt es in das Format, das Sie gewählt haben.
<G-vec01132-002-s739><convert.wandeln><en> Therefore, it is makes no difference what form you consume, your body will still convert oxidized Q10 into active Q10.
<G-vec01132-002-s739><convert.wandeln><de> Daher macht es keinen Unterschied, welche Form eingenommen wird, denn der Körper wandelt oxidiertes Q10 Ubichinon in aktives Q10 Ubichinol um.
<G-vec01132-002-s740><convert.wandeln><en> The electronics convert the travelled distance and level signal which can be read via analogue 4-20mA or Modbus RTU and Profibus DP.
<G-vec01132-002-s740><convert.wandeln><de> Die Elektronik wandelt die gefahrene Weglänge in ein Distanz- oder Füllstandssignal um, welches analog über 4-20mA oder Modbus RTU und Profibus DP ausgelesen werden kann.
