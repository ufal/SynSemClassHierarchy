<G-vec00770-002-s110><blur.unschärfen><en> The original signal processing of the X-Trans array featuring advanced noise separation technology combines with a newly developed noise reduction process that exploits the color differential to suppress chromatic blur, resulting in image quality far beyond its sensor size.
<G-vec00770-002-s110><blur.unschärfen><de> Die Originalsignalverarbeitung der X-Trans-Anordung verfügt über hochentwickelte Technologie zur Separation des Rauschens und ist mit einem neu entwickelten Rauschreduzierungsprozess kombiniert, der die Farbdifferenz ausnutzt, um chromatische Unschärfen zu unterdrücken.
<G-vec00770-002-s111><blur.unschärfen><en> In combination with Gaussian blur, you have even more options for creative video editing.
<G-vec00770-002-s111><blur.unschärfen><de> In Kombination mit den Gaußschen Unschärfen ergeben sich noch mehr Möglichkeiten für die kreative Videobearbeitung.
<G-vec00770-002-s112><blur.unschärfen><en> With advanced autofocus technology, motion is captured without blur.
<G-vec00770-002-s112><blur.unschärfen><de> Der fortschrittliche Autofokus fängt Bewegungen ohne Unschärfen ein.
<G-vec00770-002-s113><blur.unschärfen><en> DFI technology detects moving objects and reduces motion blur, simultaneously detecting stationary objects and reducing jagged edges.
<G-vec00770-002-s113><blur.unschärfen><de> Die DFI-Technologie erkennt Objekte in Bewegung und minimiert Unschärfen die durch die Bewegungen entstehen.
<G-vec00770-002-s114><blur.unschärfen><en> Due to the two objective-lenses of the 4Pi microscope, this problem is partially solved; Both focal light spots are superimposed, and the blur can be removed (at least to a certain extent).
<G-vec00770-002-s114><blur.unschärfen><de> Durch die beiden Objektiv-Linsen des 4Pi Mikroskops wird dieses Problem teilweise aufgehoben; Die beiden fokalen 'Lichtflecke' überlagern sich und Unschärfen werden (wenigstens zum Teil) ausgeglichen.
<G-vec00770-002-s115><blur.unschärfen><en> Built-in Optical SteadyShot image stabilization compensates for camera shake that can blur images when shooting handheld.
<G-vec00770-002-s115><blur.unschärfen><de> Der optische SteadyShot Bildstabilisator gleicht Verwacklungen aus, die bei handgeführten Aufnahmen zu Unschärfen führen können.
<G-vec00770-002-s116><blur.unschärfen><en> Optical SteadyShot with Intelligent Active Mode prevents camera shake and blur from ruining pictures.
<G-vec00770-002-s116><blur.unschärfen><de> Optischer SteadyShot mit intelligentem Active-Modus verhindert, dass Verwacklungen der Kamera und Unschärfen Ihre Bilder ruinieren.
<G-vec00770-002-s118><blur.unschärfen><en> In addition, utilizing the enhanced performance of the EXR Processor II, Lens Modulation Optimizer (LMO) factors are calculated to compensate for aberrations and diffraction blur that occur when light passes through the lens and then are applied to produce images with amazing sharpness. FUJIFILM X100 fujifilm-x.com
<G-vec00770-002-s118><blur.unschärfen><de> Zusätzlich dazu werden durch den Einsatz der verbesserten Leistungsfähigkeit des EXR Prozessor II Optimierungsfaktoren für die Linsenmodulation (LMO) berechnet, um Unschärfen durch Aberrationen (Abbildungsfehler) und Diffraktion zu kompensieren, die auftrefen, wenn Licht durch die Linse fällt, und werden dann angewendet, um ein Bild von erstaunlicher Schärfe zu produzieren.
<G-vec00770-002-s121><blur.unschärfen><en> It is not only great for group photos, but also comes in handy in macro photography and low exposure shots when you want to avoid blur caused by manual shutter release.
<G-vec00770-002-s121><blur.unschärfen><de> Die Selbstauslöserfunktion ist nicht nur perfekt für Gruppenaufnahmen, sondern auch zur Vermeidung von Unschärfen durch manuelles Auslösen, zum Beispiel bei Makroaufnahmen und Langzeitbelichtungen.
<G-vec00770-002-s122><blur.unschärfen><en> Compensation for five types of camera shake and minimal blur even in night shots show how the R II clearly makes the most of the image sensor's 42.4-megapixel resolution.
<G-vec00770-002-s122><blur.unschärfen><de> Durch den Ausgleich von fünf Arten von Kameraverwacklungen und nur minimale Unschärfen selbst bei Nachtaufnahmen nutzt die R II das volle Potenzial der 42,4 Megapixel Auflösung des Bildsensors optimal aus.
<G-vec00770-002-s123><blur.unschärfen><en> Turn any shape, video plane or paint stroke into a reflective surface; add blur to soften reflections; and use the Falloff feature to fade reflections as the object moves away from the light.
<G-vec00770-002-s123><blur.unschärfen><de> Verwandle eine Form, eine Videoebene oder einen Pinselstrich in eine reflektierende Fläche, lass Reflexionen durch Unschärfen weicher wirken und verwende die Funktion «Nachlassen» zum Ausblenden von Reflexionen, wenn sich das Objekt von der Lichtquelle wegbewegt.
<G-vec00770-002-s079><blur.verschwimmen><en> The plans for low buildings with soft contours blur the lines between urban space and waterfront.
<G-vec00770-002-s079><blur.verschwimmen><de> Die Pläne für niedrige Gebäude mit weichen Konturen lassen die Grenzen zwischen urbanem Raum und Küste verschwimmen.
<G-vec00770-002-s080><blur.verschwimmen><en> They often reveal much more than the subject matter suggests, and their astute references to iconic works of art history blur the boundaries between art and commercial photography.
<G-vec00770-002-s080><blur.verschwimmen><de> Oft zeigen sie mehr als nur das Dargestellte und lassen durch intelligent zitierte Bezüge zu ikonischen Werken der Kunstgeschichte die Grenze zwischen Kunst und Kommerz verschwimmen.
<G-vec00770-002-s126><blur.verschwimmen><en> Additionally, you automatically trigger Blur when you fall below 35% health.
<G-vec00770-002-s126><blur.verschwimmen><de> 'Verschwimmen' wird außerdem automatisch ausgelöst, wenn Eure Gesundheit unter 35% fällt.
<G-vec00770-002-s127><blur.verschwimmen><en> Driss says that the technical blur enables us to wipe out any spatial or temporal landmarks in order to propose the notion of immortality and timelessness.
<G-vec00770-002-s127><blur.verschwimmen><de> Driss sagt, dass das verfahrensbedingte Verschwimmen der Konturen uns ermöglicht, alle Orientierungspunkte in Raum und Zeit auszulöschen, um den Eindruck von Unsterblichkeit und Zeitlosigkeit zu erzeugen.
<G-vec00770-002-s128><blur.verschwimmen><en> Thus, borders between down- and upload and mere streaming begin to blur.
<G-vec00770-002-s128><blur.verschwimmen><de> Die Grenzen zwischen Down- und Upload und reinem Streaming verschwimmen.
<G-vec00770-002-s129><blur.verschwimmen><en> When they create music together they blur the boundaries between ancient music and new music, imaginary folklore and jazz-inspired improvisation.
<G-vec00770-002-s129><blur.verschwimmen><de> Wenn sie gemeinsam musizieren, verschwimmen die Grenzen von Alter und Neuer Musik, von imaginärer Folklore und jazzinspirierter Improvisation.
<G-vec00770-002-s130><blur.verschwimmen><en> Filled with a variety of comfortable seating groupings and intimate lounging areas, the lobby will embody the Edition’s next-generation spirit, a place where the lines between work and play begin to blur.
<G-vec00770-002-s130><blur.verschwimmen><de> Die mit einer Vielfalt an komfortablen Sitzgruppen und intimen Lounge-Bereichen möblierte Lobby wird den zukunftsorientierten Geist des Edition-Hotels verkörpern – ein Ort, an dem die Grenzen zwischen Arbeit und Spiel zu verschwimmen beginnen.
<G-vec00770-002-s131><blur.verschwimmen><en> Indeed, when they're examined closely, the motifs in his works seem to fall apart and the foregrounds and backgrounds blur, for instance in paintings such as Grand Riviere (2002).
<G-vec00770-002-s131><blur.verschwimmen><de> Tatsächlich scheinen sich bei genauerem Hinsehen die Motive auf seinen Arbeiten zu zersetzen, verschwimmen auf Bildern wie Grand Riviere (2002) Vordergrund und Hintergrund.
<G-vec00770-002-s132><blur.verschwimmen><en> As the franchise that "all sports video games should aspire to be" (GamesRadar), NBA 2K17 will take the game to new heights and continue to blur the lines between video game and reality.
<G-vec00770-002-s132><blur.verschwimmen><de> Die Reihe, der laut GamesRadar "alle Sportspiele nacheifern sollten", setzt mit NBA 2K17 neue Maßstäbe und lässt die Grenze zwischen Videospiel und Realität weiter verschwimmen.
<G-vec00770-002-s133><blur.verschwimmen><en> The boundaries between man and machine seem to blur more and more in the age of digitization.
<G-vec00770-002-s133><blur.verschwimmen><de> Die Grenzen zwischen Mensch und Maschine scheinen im Zeitalter der Digitalisierung immer mehr zu verschwimmen.
<G-vec00770-002-s134><blur.verschwimmen><en> Music, text and pictures create an imaginary war in which cause and effect blur.
<G-vec00770-002-s134><blur.verschwimmen><de> Musik, Text und Bilder imaginieren einen Krieg, in dem Ursache und Wirkung verschwimmen.
<G-vec00770-002-s135><blur.verschwimmen><en> Classic landscape photos tend to be as evenly sharp as possible, but it is also a good idea to play around with the sharpness and, for example, deliberately allow the foreground to blur.
<G-vec00770-002-s135><blur.verschwimmen><de> Klassisch sind Landschaftsaufnahmen möglichst gleichmässig scharf, doch bietet es sich auch hier an, mit der Schärfe zu spielen und den Vordergrund zum Beispiel absichtlich verschwimmen zu lassen.
<G-vec00770-002-s136><blur.verschwimmen><en> Reality and fear blur into each other.
<G-vec00770-002-s136><blur.verschwimmen><de> Die Realität und Ängste verschwimmen miteinander.
<G-vec00770-002-s137><blur.verschwimmen><en> The new retail revolution is giving rise to a number of food-service concepts, which is just one more way that the once-clear correlations between locations and their functions are starting to blur.
<G-vec00770-002-s137><blur.verschwimmen><de> Die neue Retail – Revolution treibt auch viele Konzepte in der Gastronomie voran und sorgt einmal mehr dafür, dass ehemals klare Zuschreibungen zwischen Orten und ihrer Nutzung verschwimmen.
<G-vec00770-002-s138><blur.verschwimmen><en> You often highlight androgynous elements and seem to blur gender boundaries.
<G-vec00770-002-s138><blur.verschwimmen><de> Du betonst oft androgyne Elemente, Gendergrenzen scheinen zu verschwimmen.
<G-vec00770-002-s139><blur.verschwimmen><en> It is necessary to use a good hood, otherwise the smells of food will blur throughout the apartment.
<G-vec00770-002-s139><blur.verschwimmen><de> Es ist notwendig, eine gute Kapuze zu verwenden, sonst wird der Geruch von Lebensmitteln in der gesamten Wohnung verschwimmen.
<G-vec00770-002-s140><blur.verschwimmen><en> This ensures that the colors do not blur.
<G-vec00770-002-s140><blur.verschwimmen><de> Dadurch wird sichergestellt, dass die Farben nicht verschwimmen.
<G-vec00770-002-s141><blur.verschwimmen><en> I remembered each flash as time began to blur
<G-vec00770-002-s141><blur.verschwimmen><de> Ich erinnerte mich an jeden Blitz, als die Zeit zu verschwimmen begann.
<G-vec00770-002-s142><blur.verschwimmen><en> A Laser guide star is used to create a bright spot in the sky, which can be used as an artificial reference star, allowing astronomers to measure how the real stars blur or twinkle, as normally seen from the ground.
<G-vec00770-002-s142><blur.verschwimmen><de> Es handelt sich dabei um eine kleinere Version des Laserleitsteverwendet, um einen hellen Fleck am Himmel zu erzeugen, der als künstlicher Referenzstern genutzt werden kann, welcher es den Astronomen erlaubt, zu messen, wie die wirklichen Sterne verschwimmen oder flimmern, so wie man es normalerweise vom Erdboden aus sieht.
<G-vec00770-002-s143><blur.verschwimmen><en> The dark background and white typeface race by in a blur.
<G-vec00770-002-s143><blur.verschwimmen><de> Der dunkle Hintergrund und die weiße Schrift verschwimmen.
<G-vec00770-002-s144><blur.verschwimmen><en> Someone who either has a low tolerance or has just taken a relatively big dose can get lightheaded, drowsy, and dizzy, their vision might blur or defocus, and they can get “pins and needles” (an uncomfortable tingling sensation).
<G-vec00770-002-s144><blur.verschwimmen><de> Jemand, der entweder eine geringe Toleranz oder gerade eine relativ große Dosis eingenommen hat, kann sich benommen fühlen, schläfrig und schwindlig, Deine Vision könnte verschwimmen oder unscharf werden und Du könntest ein starkes "Kribbeln" (ein unangenehmes Kribbeln, ja sogar Brennen) verspüren.
<G-vec00770-002-s145><blur.verschwimmen><en> One of the most hyped tech releases in years, the Magic Leap One uses proprietary technology to blur the line between the physical and digital like never before.
<G-vec00770-002-s145><blur.verschwimmen><de> Als einer der gehyptesten technischen Veröffentlichungen dieses Jahres verwendet der Magic Leap One firmeneigene Technologie, um die Linien zwischen dem Physischen und dem Digitalen wie nie zuvor verschwimmen zu lassen.
<G-vec00770-002-s146><blur.verschwimmen><en> Due to mix & match across all categories new styles are consistently created to blur the boundaries between day and night as well as indoor and outdoor.
<G-vec00770-002-s146><blur.verschwimmen><de> Durch Mix & Match über alle Kategorien hinweg entstehen immer wieder neue Styles, die die Grenzen zwischen Tag und Nacht sowie Indoor und Outdoor verschwimmen lassen.
<G-vec00770-002-s147><blur.verschwimmen><en> The duo specializes in works that blur the lines between furniture typologies and conceptual, representational objects.
<G-vec00770-002-s147><blur.verschwimmen><de> Das Duo spezialisiert sich auf Arbeiten, die die Grenzen zwischen Möbeltypologien und konzeptuellen Objekten verschwimmen lassen.
<G-vec00770-002-s148><blur.verschwimmen><en> This is making the interface between the virtual world and the physical world blur if not disappear.
<G-vec00770-002-s148><blur.verschwimmen><de> Dadurch verschwimmt die Schnittstelle zwischen der virtuellen Welt und der physischen Welt, wenn sie nicht verschwindet.
<G-vec00770-002-s149><blur.verschwimmen><en> But I normally show this very soft-spoken side of me, but when I start talking about myself and my casino conquests, that is when everything becomes a blur.
<G-vec00770-002-s149><blur.verschwimmen><de> Normalerweise zeige ich diese sehr leise Seite von mir, aber wenn ich anfange, über mich und meine Casino-Eroberungen zu sprechen, dann verschwimmt alles.
<G-vec00770-002-s150><blur.verschwimmen><en> With a +15 diopter, the Macro shifts the focus distance of the GoPro Hero5 allowing it to focus up close and blur everything in the background, allowing you to capture new underwater perspectives. Snap-on design
<G-vec00770-002-s150><blur.verschwimmen><de> Mit einem Dioptrienwert von +15 Dioptrien verschiebt das Makro die Fokusentfernung des GoPro Hero5, so dass er sich ganz nah fokussieren kann und alles im Hintergrund verschwimmt, so dass Sie neue Unterwasserperspektiven aufnehmen können.
<G-vec00770-002-s151><blur.verschwimmen><en> The goal: to implement systems that blur the line between HPC and AI and to provide open ecosystems, because one size does not fit all.
<G-vec00770-002-s151><blur.verschwimmen><de> Das Ziel: die Implementierung von Systemen, bei denen die Grenze zwischen HPC und KI verschwimmt, und das Angebot von offenen Systemumgebungen, da keine einzelne Lösung jeder Problemstellung gerecht wird.
<G-vec00770-002-s152><blur.verschwimmen><en> Everything is a blur.
<G-vec00770-002-s152><blur.verschwimmen><de> Alles ist verschwommen.
<G-vec00770-002-s153><blur.verschwimmen><en> I was on tour constantly, drunk pretty much the entire time and it was just a blur.
<G-vec00770-002-s153><blur.verschwimmen><de> Ich war ständig auf Tournee, habe die ganze Zeit über ziemlich viel getrunken und es war nur verschwommen.
<G-vec00770-002-s154><blur.verschwimmen><en> Iris Blur mode creates shallow depth-of-field effect, blurring the background while keeping the subject in focus. This mode is only available for the Home Deluxe and Business licenses.
<G-vec00770-002-s154><blur.verschwimmen><de> Das Hauptmotiv wird in Fokus gestellt, während der Hintergrund verschwommen wird (dieser Modus ist nur für die Lizenzen Home Deluxe und Business verfügbar).
<G-vec00770-002-s160><blur.verwischen><en> Blur photo background for your next advertising layout and see how it makes key visual pop up in the most elegant way.
<G-vec00770-002-s160><blur.verwischen><de> Verwische den Fotohintergrund für dein nächstes Anzeigenlayout und schau dir an, wie wichtige visuelle Elemente auf eleganteste Weise angezeigt werden.
<G-vec00770-002-s161><blur.verwischen><en> Blur the battle lines between game and glory.
<G-vec00770-002-s161><blur.verwischen><de> Verwische die Schlachtlinien zwischen Spiel und Ruhm.
<G-vec00770-002-s162><blur.verwischen><en> I like to blur the boundaries between furniture and spatial structure.
<G-vec00770-002-s162><blur.verwischen><de> Die Grenzen zwischen Möbel und Raumstruktur verwische ich gern.
<G-vec00770-002-s163><blur.verwischen><en> In this respect, Richter noted in the mid-sixties: “I blur in order to make everything equal, everything equally important and equally unimportant.
<G-vec00770-002-s163><blur.verwischen><de> So notierte Richter Mitte der sechziger Jahre: "Ich verwische, um alles gleich zu machen, alles gleich wichtig und gleich unwichtig.
<G-vec00770-002-s164><blur.verwischen><en> Nevertheless, utilizing a corporate director may blur the clear structure of a company and make it difficult to comprehend, especially for people who live in countries where corporate directors are not a common practice.
<G-vec00770-002-s164><blur.verwischen><de> Dennoch kann die Verwendung eines Unternehmens als Vorstand die klare Struktur einer Gesellschaft verwischen und sie schwierig zu verstehen machen, insbesondere für Leute, die in Ländern wohnen, in denen Unternehmen als Vorstände nicht üblich sind.
<G-vec00770-002-s165><blur.verwischen><en> These products are challenging to regulators as they blur the traditional lines between medicinal products, biologics and devices and cannot easily be reviewed under the standard review pathways that exist for each of the separate entities in isolation.
<G-vec00770-002-s165><blur.verwischen><de> Diese Produkte sind eine Herausforderung für die Regulatoren, da sie die traditionellen Grenzen zwischen Arzneimitteln, Biologika und Produkten verwischen und nicht einfach unter den Standardprüfprozeduren, die für jede der getrennten Einheiten isoliert existieren, geprüft werden können.
<G-vec00770-002-s166><blur.verwischen><en> The last step is to blur the edges of the board with the eraser and the image is complete.
<G-vec00770-002-s166><blur.verwischen><de> Als letzten Schritt verwischen Sie die Ränder des Holzes mit dem Radierer und das Bild ist vollendet.
<G-vec00770-002-s167><blur.verwischen><en> We think football fans will appreciate how Havok technology will blur the line between the sport and simulation, and provide a football experience that looks as real as can be.
<G-vec00770-002-s167><blur.verwischen><de> Wir denken, dass die Fußballfans es zu schätzen wissen werden, wie die Havok Techologie die Grenzen zwischen Realität und Simulation verwischen lässt und eine Fußballerfahrung liefert, die so realistisch wie möglich sein wird.
<G-vec00770-002-s168><blur.verwischen><en> Alcohol and gambling is a combination many people enjoy, but it can also blur your concentration and lead you to make stupid mistakes or make oversized bets.
<G-vec00770-002-s168><blur.verwischen><de> Alkohol und Glücksspiel ist eine Kombination, die viele Menschen genießen, aber es kann auch Ihre Konzentration verwischen und Sie dazu bringen, dumme Fehler zu machen oder übergroße Wetten zu machen.
<G-vec00770-002-s169><blur.verwischen><en> This software allows you to set aspect ratio, blur the black bars and crop out black bars successfully and effortlessly.
<G-vec00770-002-s169><blur.verwischen><de> Mit dieser Software können Sie das Seitenverhältnis einstellen, die schwarzen Balken verwischen und schwarze Balken erfolgreich und mühelos ausschneiden.
<G-vec00770-002-s170><blur.verwischen><en> In this season, 2015 the Gütermarkt is build on 6 different conceptual islands to blur the official borders between the ZK/U Center for Arts and Urbanistic and the city park in order to create an inclusive space for unexpected social relationships.
<G-vec00770-002-s170><blur.verwischen><de> In Jahr 2015 wird der Gütermarkt von 6 unterschiedlichen konzeptuellen Inseln getragen um so die Verwaltungsgrenzen zwischen dem ZK/U Zentrum für Kunst und Urbanistik und des Stadtpark zu verwischen und einen Ort zu schaffen welcher spontane, unerwartete Interaktion und sozialen Austausch fördert.
<G-vec00770-002-s171><blur.verwischen><en> Blur the area behind skinned areas (Windows 10 Anniversary [and later]).
<G-vec00770-002-s171><blur.verwischen><de> Verwischen Sie den Bereich hinter enthäuteten Bereichen (Windows 10 Jahrestag [und später]).
<G-vec00770-002-s172><blur.verwischen><en> (1998) ironically blur the thin dividing line separating information from disinformation, and question the ‘true' value of information in our society (whereby the German words for ‘true' and ‘merchandise' sound suspiciously alike).
<G-vec00770-002-s172><blur.verwischen><de> Ihre Internetprojekte »without_addresses« (1997) und »Dump Your Trash!« (1998) verwischen ironisch den schmalen Grat zwischen Information und Desinformation und hinterfragen den wahren Wert von Information in unserer Gesellschaft.
<G-vec00770-002-s173><blur.verwischen><en> Thanks to its composition you will be able to blur the makeup without it getting stuck in the sponge, and you will achieve a subtle and natural finish.
<G-vec00770-002-s173><blur.verwischen><de> Dank seiner Zusammensetzung können Sie das Makeup verwischen, ohne dass es im Schwamm stecken bleibt, und Sie erhalten ein subtiles und natürliches Finish.
<G-vec00770-002-s174><blur.verwischen><en> The property of red chalk in combination with black pastel chalk - lightly verreibbar blur without unintentionally - was a perfectly Griebel.
<G-vec00770-002-s174><blur.verwischen><de> Die Eigenschaft des Rötels in Kombination mit schwarzer Pastellkreide – leicht verreibbar ohne sich ungewollt zu verwischen –, setzte Griebel perfekt ein.
<G-vec00770-002-s175><blur.verwischen><en> The only reason to use a tripod during daylight hours is when you want to use a long shutter speed to create a particular effect, like using an ND filter to blur a waterfall.
<G-vec00770-002-s175><blur.verwischen><de> Der einzige Grund für die Verwendung eines Stativs während des Tageslichts ist, wenn Sie mit einer langen Belichtungszeit einen ganz bestimmten Effekt erzielen möchten – beispielsweise mit einem ND-Filter das fließende Wasser eines Wasserfalls zu verwischen.
<G-vec00770-002-s176><blur.verwischen><en> Reflections and overexposure blur the inside with the outside.
<G-vec00770-002-s176><blur.verwischen><de> Spiegelungen und Überstrahlungen verschränken und verwischen das Innen und Außen.
<G-vec00770-002-s177><blur.verwischen><en> Blur Walls provides the ability to blur to any image and set it as a wallpaper.
<G-vec00770-002-s177><blur.verwischen><de> Blur Walls bietet die Möglichkeit, zu jedem Bild verwischen und legen Sie es als Hintergrundbild.
<G-vec00770-002-s178><blur.verwischen><en> It allows you to make fine changes to colors and saturation, sharpen and blur images, apply vignette effects and combine multiple images, but it doesn't have the same huge toolbox as Pixlr Editor.
<G-vec00770-002-s178><blur.verwischen><de> Es ermöglicht Ihnen, feine Änderungen an Farben und Sättigung vorzunehmen, Bilder zu schärfen und zu verwischen, Vignetteneffekte anzuwenden und mehrere Bilder zu kombinieren, aber es verfügt nicht über die gleiche große Toolbox wie der Pixlr Editor.
<G-vec00770-002-s179><blur.verwischen><en> All performances meet the goal of transposing a new concept of creativity and interpretation; the aim is to blur the borders between old and contemporary music and between popular and serious music.
<G-vec00770-002-s179><blur.verwischen><de> Alle Aufführungen begegnen dem Anspruch, ein neues Konzept von kreativem Schaffen und Interpretation umzusetzen; Ziel ist es, die Grenzen zwischen alter und zeitgenössischer, populärer und ernster Musik zu verwischen.
<G-vec00770-002-s180><blur.verwischen><en> Using this application, you can suppress or blur the background.
<G-vec00770-002-s180><blur.verwischen><de> Mit dieser Anwendung können Sie den Hintergrund unterdrücken oder verwischen.
<G-vec00770-002-s181><blur.verwischen><en> With a subject roughly four feet away from the camera, the Note 8 uses both cameras to capture depth information and then blur the background, commonly referred to as bokeh.
<G-vec00770-002-s181><blur.verwischen><de> Bei einem Motiv, das ungefähr einen Meter von der Kamera entfernt ist, verwendet das Note 8 beide Kameras, um Tiefeninformationen zu erfassen und den Hintergrund, der gemeinhin als Bokeh bezeichnet wird, zu verwischen.
<G-vec00770-002-s182><blur.verwischen><en> Simply tap anywhere on the screen to assign focus and blur the background.
<G-vec00770-002-s182><blur.verwischen><de> Tipp einfach auf eine beliebige Stelle auf dem Bildschirm, um den Fokus zuzuweisen und den Hintergrund zu verwischen.
<G-vec00770-002-s183><blur.verwischen><en> A high level of microfine light-diffusing pigments helps cover dark circles and blur the appearance of fine lines and wrinkles, leaving the eye area skin looking refreshed and youthfully bright. on any Elizabeth Arden products.
<G-vec00770-002-s183><blur.verwischen><de> Ein hoher Anteil an mikroskopischen, lichtbrechenden Pigmenten deckt Augenringe ab und verwischt feine Linien und Falten, damit die Haut der Augenpartie jugendlich strahlend und frisch wirkt.
<G-vec00770-002-s184><blur.verwischen><en> It is the magic spark that violently bursts to blur the limit –which is supposedly so clear- between fantasy and reality, between what we invent and what we discover.
<G-vec00770-002-s184><blur.verwischen><de> Es ist der magische Funke, der gewaltig sprüht, die Grenzen verwischt – scheinbar klar – zwischen Fantasie und Realität, zwischen dem, was wir erfinden und entdecken.
<G-vec00770-002-s185><blur.verwischen><en> Video's Lens Blur City and Traffic Lights - Stockvideo...
<G-vec00770-002-s185><blur.verwischen><de> Gläser verwischt Lichter der Stadt und Verkehr – Footage...
<G-vec00770-002-s186><blur.verwischen><en> The Motion Blur filter blurs in a particular direction (from ‑360º to +360º) and at a specific distance (from 1 to 999).
<G-vec00770-002-s186><blur.verwischen><de> Verwischt einen Bereich in eine bestimmte Richtung (von -360 bis +360 Grad) und mit einer bestimmten Intensität (von 1 bis 999).
<G-vec00770-002-s187><blur.verwischen><en> The texts, by Franz Boas, Roger Caillois, Fernand Deligny, Asger Jorn and Pablo Lafuente, tangentially explore ideas about aesthetics and function, and blur the lines between objects of use and objects of contemplation.
<G-vec00770-002-s187><blur.verwischen><de> Über Texte von Franz Boas, Roger Caillois, Fernand Deligny, Asger Jorn und Pablo Lafuente nähert sich A Singular Form dem Themenkomplex Ästhetik und Funktion und verwischt dabei die Grenzen zwischen Gebrauchs- und Betrachtungsobjekt.
<G-vec00770-002-s188><blur.verwischen><en> Caution to potential partners of Aries: Don’t let your own potentially playful attitude towards competition blur the fact that your Fiery lover is not one to take a challenge lightly and will constantly accept any gauntlet thrown at his/her feet.
<G-vec00770-002-s188><blur.verwischen><de> Vorsicht vor potenziellen Partnern von Widder: Lassen Sie nicht zu, dass Ihre potenziell spielerische Einstellung gegenüber dem Wettbewerb die Tatsache verwischt, dass Ihr Fiery-Liebhaber sich keiner Herausforderung stellt und sich ständig mit Handschuhen abfinden wird, die ihm zu Füßen liegen.
<G-vec00770-002-s191><blur.weichzeichnen><en> Select the rectangular marquee tool and select an area that includes the areas that you do not want to blur.
<G-vec00770-002-s191><blur.weichzeichnen><de> Wählen Sie das rechteckige Marquee-Tool und einen Bereich, der die Bereiche umfasst, die Sie nicht weichzeichnen möchten.
<G-vec00770-002-s192><blur.weichzeichnen><en> We can touch up the borders with the tools Eraser, Blur Tool and Clone Stamp.
<G-vec00770-002-s192><blur.weichzeichnen><de> Die Ränder können mit den Werkzeugen Radiergummi, Weichzeichnen und Stempel korrigiert werden.
<G-vec00770-002-s193><blur.weichzeichnen><en> Blur: Use the blur slider to soften the edges of the mask to blend the selection.
<G-vec00770-002-s193><blur.weichzeichnen><de> Weichzeichnen: Mit dem Weichzeichnungsregler können Sie die Kanten der Maske weicher machen und die Auswahl so ohne scharfen Übergang einfügen.
<G-vec00770-002-s194><blur.weichzeichnen><en> The program provides five image processing modes: Refocus, Tilt-Shift, Iris Blur, Motion Blur, and Radial Blur.
<G-vec00770-002-s194><blur.weichzeichnen><de> Die Software stellt fünf Modi zur Verfügung: Scharfstellung, Iris-Weichzeichnung, Tilt-Shift, Bewegungsunschärfe und Radiales Weichzeichnen.
<G-vec00770-002-s195><blur.weichzeichnen><en> Box Blur effect Box Blur is similar to Fast Blur and Gaussian Blur, but Box Blur has the added advantage of an Iterations property, which allows you to control the quality of the blur.
<G-vec00770-002-s195><blur.weichzeichnen><de> „Feld weichzeichnen“ ist ähnlich wie „Schneller Weichzeichner“ und „Gaußscher Weichzeichner“, doch „Feld weichzeichnen“ verfügt über den zusätzlichen Vorteil der Eigenschaft „Iterationen“, mit der Sie die Qualität der Weichzeichnung steuern können.
<G-vec00770-002-s196><blur.weichzeichnen><en> ------ Blur Image: Pixelate the image to cover areas you do not want to show.
<G-vec00770-002-s196><blur.weichzeichnen><de> ------ Weichzeichnen: Verpixeln Sie Bereiche, die Sie nicht zeigen möchten.
<G-vec00770-002-s197><blur.weichzeichnen><en> To create this effect we use the Radial Blur Method.
<G-vec00770-002-s197><blur.weichzeichnen><de> In diesem Fall verwenden wir die Methode Radiales Weichzeichnen.
<G-vec00770-002-s198><blur.weichzeichnen><en> The software works in five modes: Refocus, Tilt-Shift, Iris Blur, Motion Blur, and Radial Blur. Windows:
<G-vec00770-002-s198><blur.weichzeichnen><de> AKVIS Refocus funktioniert in fünf Modi: Scharfstellung, Iris-Weichzeichnung, Tilt-Shift, Bewegungsunschärfe und Radiales Weichzeichnen.
<G-vec00770-002-s199><blur.weichzeichnen><en> The standard Angle parameter in the Motion Blur effect (Effects -> Blur -> Motion Blur...) has been replaced with a circular one which is more user-friendly.
<G-vec00770-002-s199><blur.weichzeichnen><de> Der Standard-Winkelparameter im Bewegungsunschärfe-Effekt (Effekte -> Weichzeichnen -> Bewegungsunschärfe...) wurde durch einen benutzerfreundlichen kreisförmigen Parameter ersetzt.
<G-vec00770-002-s200><blur.weichzeichnen><en> Check Preview, then set Mode: Multiply, Opacity: 100%, X & Y Offsets: 8 pt, and Blur: 0 pt.
<G-vec00770-002-s200><blur.weichzeichnen><de> Aktivieren Sie das Kontrollkästchen „Vorschau“, und nehmen Sie folgende Einstellungen vor: Modus: Multiplizieren; Deckkraft: 100 %; x-Versatz/y-Versatz: 8 pt; Weichzeichnen: 0 pt.
<G-vec00770-002-s201><blur.weichzeichnen><en> Streaming support — Achieve an even wider variety of rich visual effects, including blur, drop shadow, bevel, glow, and more, with bitmap filters you can apply through the user interface or scripting.Take advantage of Real Time Messaging Protocol (RTMP) to stream audio and video over the Internet. Manipulate ByteArrays — Save development time and reduce application-loading time using ByteArray datatype, which lets you easily access and manipulate binary data.
<G-vec00770-002-s201><blur.weichzeichnen><de> Streaming-Unterstützung – Mit Bitmap-Filtern, die wahlweise über die intuitive Benutzeroberfläche oder mithilfe eines Skripts aufgerufen werden, erzielen Sie beeindruckende visuelle Effekte wie Weichzeichnen, Schlagschatten, abgeflachte Kanten, Glühen u. v. m. Director unterstützt Audio- und bearbeiten – Die ByteArray-Klasse erleichtert den Zugang zu und die Bearbeitung von binären Daten, sodass Sie Projekte schneller abschließen und die Ladezeiten Ihrer Anwendungen verkürzen können.
<G-vec00770-002-s202><blur.weichzeichnen><en> Use the Selection Tools to mark the face that you want to blur.
<G-vec00770-002-s202><blur.weichzeichnen><de> Mithilfe eines der Auswahltools markieren Sie die Gesichter, welche Sie weichzeichnen möchten.
<G-vec00770-002-s203><blur.weichzeichnen><en> Whether on the web or on the go, we make it easy to blur or sharpen your photos with our photo editor.
<G-vec00770-002-s203><blur.weichzeichnen><de> Ob im Web oder von unterwegs – mit unserem Foto-Editor kannst du deine Fotos ganz einfach selbst weichzeichnen oder schärfen.
<G-vec00770-002-s204><blur.weichzeichnen><en> Blur: Specify a value, in pixels, for the blur of the shadow.
<G-vec00770-002-s204><blur.weichzeichnen><de> Weichzeichnen Geben Sie für das Weichzeichnen des Schattens einen Wert in Pixel an.
<G-vec00770-002-s206><blur.weichzeichnen><en> The Blur parameter lets you adjust the strength of the blur effect.
<G-vec00770-002-s206><blur.weichzeichnen><de> Mit dem Parameter Weichzeichnen können Sie die Intensität des Unschärfe-Effekts anzupassen.
