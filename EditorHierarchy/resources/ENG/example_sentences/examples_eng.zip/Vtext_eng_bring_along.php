<G-vec00011-002-s494><bring_along.(sich)_nehmen><en> I plan to bring my family to Prague so that we will have a vacation time after the convention.
<G-vec00011-002-s494><bring_along.(sich)_nehmen><de> Ich will meine Familie mit zur Veranstaltung in Beverly Hills nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00011-002-s495><bring_along.(sich)_nehmen><en> In this case, please report to the IT support services directly and bring identification with you.
<G-vec00011-002-s495><bring_along.(sich)_nehmen><de> Wenden Sie sich dafür persönlich an den IT-Support und nehmen Sie zwecks eindeutiger Identifikation einen Ausweis mit.
<G-vec00011-002-s496><bring_along.(sich)_nehmen><en> The parents left you to decide what to bring and which foods to eat.
<G-vec00011-002-s496><bring_along.(sich)_nehmen><de> Die Eltern wollen dass Sie entscheiden was zu nehmen und welche Lebensmittel zu essen.
<G-vec00011-002-s497><bring_along.(sich)_nehmen><en> You may bring your own food on board if you follow the safety regulation with regard to carry-on baggage.
<G-vec00011-002-s497><bring_along.(sich)_nehmen><de> Sie können Ihre eigene Verpflegung mit an Bord nehmen, wenn Sie die Sicherheitsbestimmungen für Handgepäck befolgen.
<G-vec00011-002-s498><bring_along.(sich)_nehmen><en> I plan to bring my family to Sydney so that we will have a vacation time after the conference.
<G-vec00011-002-s498><bring_along.(sich)_nehmen><de> Ich will meine Familie mit zur Veranstaltung in Miami nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00011-002-s499><bring_along.(sich)_nehmen><en> Bring your swimsuit; A Victory Inn & Suites Phoenix North has an outdoor swimming pool.
<G-vec00011-002-s499><bring_along.(sich)_nehmen><de> Nehmen Sie ein Bad im Pool, Sie werden sicherlich mögen, dass das A Victory Inn & Suites Phoenix North ein Außenpool hat.
<G-vec00011-002-s500><bring_along.(sich)_nehmen><en> Bring it anywhere: the elegant finish in brushed metal makes it an elegant and classy accessory.
<G-vec00011-002-s500><bring_along.(sich)_nehmen><de> Nehmen Sie ihn überall mit hin: Die elegante Oberfläche aus gebürstetem Metall macht ihn zu einem edlen und stilvollen Accessoire.
<G-vec00011-002-s501><bring_along.(sich)_nehmen><en> Bring your iPhone with you.
<G-vec00011-002-s501><bring_along.(sich)_nehmen><de> Nehmen Sie Ihr iPhone mit.
<G-vec00011-002-s502><bring_along.(sich)_nehmen><en> In most countries, the transit authorities allow you to bring food through the security screening and on board.
<G-vec00011-002-s502><bring_along.(sich)_nehmen><de> Essen, welches die Bordsecurity erlaubt In den meisten Ländern erlaubt einem das Sicherheitspersonal, Essen durch die Kontrolle mit an Bord zu nehmen.
<G-vec00011-002-s503><bring_along.(sich)_nehmen><en> Bring your iPhone along to see pace and distance.
<G-vec00011-002-s503><bring_along.(sich)_nehmen><de> Nehmen Sie Ihr iPhone mit, um Geschwindigkeit und zurückgelegte Strecke zu messen.
<G-vec00011-002-s504><bring_along.(sich)_nehmen><en> When we bring our testosterone levels to a high level, the performance of the testosterone is enhanced.
<G-vec00011-002-s504><bring_along.(sich)_nehmen><de> Wenn wir unsere Testosteronspiegel zu einem hochrangigen Zustand nehmen, werden die oben genannten Merkmale des Testosteronhormons erhöht.
<G-vec00011-002-s505><bring_along.(sich)_nehmen><en> Bring yourself to do this 3-day private paddle surf course in one of the beaches of Gran Canaria.
<G-vec00011-002-s505><bring_along.(sich)_nehmen><de> Nehmen Sie an diesem 3-tägigen privaten Paddel-Surfkurs an einem der Strände von Gran Canaria teil.
<G-vec00011-002-s506><bring_along.(sich)_nehmen><en> Bring as much as you can in your hand luggage, but cut all your barriers to the right size before you fly (at least those you will be carrying in your hand luggage), since you will not always be allowed to bring scissors in your hand luggage.
<G-vec00011-002-s506><bring_along.(sich)_nehmen><de> Nehmen Sie so viel wie möglich in Ihrem Handgepäck mit, aber schneiden Sie jeden Hautschutz vor dem Flug auf die richtige Größe zu (zumindest diejenigen im Handgepäck), da Scheren im Handgepäck nicht immer erlaubt sind.
<G-vec00011-002-s507><bring_along.(sich)_nehmen><en> The taste of a holiday at the White Horse Inn can be enjoyed everywhere: with the homemade goods of the White Horse Inn you can bring a slice of Austria back home with you and enjoy traditional Austrian cuisine in your own home.
<G-vec00011-002-s507><bring_along.(sich)_nehmen><de> Rössl Spezialitäten Den Geschmack eines Urlaubs im Hotel Weisses Rössl können Sie nicht nur in St. Wolfgang genießen: Nehmen Sie aus dem Rössl-Shop Hausgemachtes mit – ein Souvenir aus Ihrem Österreich-Urlaub, das den Daheimgebliebenen Freude bereitet.
<G-vec00011-002-s508><bring_along.(sich)_nehmen><en> Oxea has also announced plans to bring its sixth world-scale carboxylic acids production plant on stream in 2021.
<G-vec00011-002-s508><bring_along.(sich)_nehmen><de> Zudem plant das Unternehmen, im Jahr 2021 seine sechste Großanlage zur Herstellung von Carbonsäuren in Betrieb zu nehmen.
<G-vec00011-002-s509><bring_along.(sich)_nehmen><en> Then bring the ball down across your body to your right hip, bending your elbows, again without rotating your head or chest.
<G-vec00011-002-s509><bring_along.(sich)_nehmen><de> Nehmen Sie ihre rechte Hand an die rechte Hüfte, oder legen Sie den Arm gerade rechts am Körper einfach ab.
<G-vec00011-002-s510><bring_along.(sich)_nehmen><en> Bring SmartCharge with you wherever you go.
<G-vec00011-002-s510><bring_along.(sich)_nehmen><de> Nehmen Sie SmartCharge mit.
<G-vec00011-002-s511><bring_along.(sich)_nehmen><en> To bring your Guide Dog into the cabin, please download and fill out the Application Form Guide Dog and send the completed form to KLMCARES@KLM.com.
<G-vec00011-002-s511><bring_along.(sich)_nehmen><de> Um Ihren Blindenhund mit in die Kabine zu nehmen, laden Sie bitte das Antragsformular Blindenhund herunter und füllen Sie es aus und senden dieses ausgefüllt anKLMCARES@klm.com.
<G-vec00011-002-s512><bring_along.(sich)_nehmen><en> Bring them ALL safely.
<G-vec00011-002-s512><bring_along.(sich)_nehmen><de> Nehmen Sie einfach alle mit.
<G-vec00011-002-s057><bring_along.bringen><en> “WE BRING IDEAS TO LIFE.” briefly describes Doehler’s holistic and strategic approach to innovation.
<G-vec00011-002-s057><bring_along.bringen><de> „WE BRING IDEAS TO LIFE.“ beschreibt prägnant den integrierten Leistungsansatz.
<G-vec00011-002-s058><bring_along.bringen><en> Unicorn Killer — fresh taste music: Bring Me The Horizon
<G-vec00011-002-s058><bring_along.bringen><de> Offizielle schwarze Mütze der britischen Band Bring Me The Horizon.
<G-vec00011-002-s059><bring_along.bringen><en> Bring your personal touch and your perspective, be open and direct but always be friendly.
<G-vec00011-002-s059><bring_along.bringen><de> Bring dich und deine Sichtweise ein, sei offen und direkt, aber immer freundlich.
<G-vec00011-002-s060><bring_along.bringen><en> Bring and pick up service from and to Toverland is possible.
<G-vec00011-002-s060><bring_along.bringen><de> Bring und Abholservice von und nach Toverland ist möglich.
<G-vec00011-002-s061><bring_along.bringen><en> Bring It In To start the betting on the first round.
<G-vec00011-002-s061><bring_along.bringen><de> Bring It In - um die Wette an die erste Runde zu beginnen.
<G-vec00011-002-s062><bring_along.bringen><en> You can choose from 20 arrangements for 18 instruments for the composition Santa, Bring My Baby Back (To Me).
<G-vec00011-002-s062><bring_along.bringen><de> Sie können aus 20 Arrangements für 18 Musikinstrumente der Komposition Santa, Bring My Baby Back (To Me) wählen.
<G-vec00011-002-s063><bring_along.bringen><en> Bring your own campervan.
<G-vec00011-002-s063><bring_along.bringen><de> Bring dein eigenes Reisemobil mit.
<G-vec00011-002-s064><bring_along.bringen><en> Bring torch or diving light, DSMB and wrist compass.
<G-vec00011-002-s064><bring_along.bringen><de> Bring Fackel oder Tauchlicht, DSMB und Handgelenk Kompass.
<G-vec00011-002-s065><bring_along.bringen><en> Remember to bring a padlock or buy one from reception for £3.50.
<G-vec00011-002-s065><bring_along.bringen><de> Bitte bring ein Vorhängeschloss mit oder kaufe eins an der Rezeption für £3.
<G-vec00011-002-s066><bring_along.bringen><en> You are able to buy new or use existing FileMaker software licenses via Bring Your Own License (BYOL).
<G-vec00011-002-s066><bring_along.bringen><de> Über Bring Your Own License (BYOL) können Sie neue FileMaker-Software-Lizenzen kaufen oder bereits bestehende Lizenzen verwenden.
<G-vec00011-002-s067><bring_along.bringen><en> Bring your own to share.
<G-vec00011-002-s067><bring_along.bringen><de> Bring dein Lieblingsspiel mit.
<G-vec00011-002-s068><bring_along.bringen><en> Bring Me Flowers - stock photography images.
<G-vec00011-002-s068><bring_along.bringen><de> Bring mir Blumen - Sammlung von photographischen Bildern.
<G-vec00011-002-s069><bring_along.bringen><en> Bring me peace and solace.
<G-vec00011-002-s069><bring_along.bringen><de> Bring mir Frieden und Trost.
<G-vec00011-002-s070><bring_along.bringen><en> In 2016, around 85% of packaging that was collected for recycling in Spain was collected via bring banks.
<G-vec00011-002-s070><bring_along.bringen><de> In 2016 wurde ungefähr 85% von Verpackungsmüll in Spanien durch „Bring Banks“ gesammelt.
<G-vec00011-002-s071><bring_along.bringen><en> 7 And this [is] of Judah: And he said, Hear, LORD, the voice of Judah, and bring him into his people. With his hands he contended for himself, and thou shall be a help against his adversaries.
<G-vec00011-002-s071><bring_along.bringen><de> 7 Und dieses von Juda; und er sprach: Höre, Jehova, die Stimme Juda's, und zu seinem Volke bring ihn, seine Hand streite für ihn, und Hülfe gegen seine Feinde sey du.
<G-vec00011-002-s072><bring_along.bringen><en> • Free Shopping: Bring with you what you do not need and take what you want.
<G-vec00011-002-s072><bring_along.bringen><de> • Umsonstladen: Bring mit, was Du nicht brauchst und nimm was Du willst.
<G-vec00011-002-s073><bring_along.bringen><en> The cover “Bring it home to me” followed, when Steve asked the audience to start snipping.
<G-vec00011-002-s073><bring_along.bringen><de> Es folgte das Cover „Bring it home to me“, wofür Steve das Publikum zum Schnippen aufforderte.
<G-vec00011-002-s074><bring_along.bringen><en> In this case it is necessary to say the following words: "The hair is long, drowned, bring me the spirit of water.
<G-vec00011-002-s074><bring_along.bringen><de> In diesem Fall ist es notwendig, die folgenden Worte zu sagen: "Die Haare sind lang, ertränkt, bring mir den Geist des Wassers.
<G-vec00011-002-s075><bring_along.bringen><en> Bring them in bring them in
<G-vec00011-002-s075><bring_along.bringen><de> Bring sie doch zurück zu mir.
<G-vec00011-002-s076><bring_along.bringen><en> Inhale as you bend your elbows and bring your butt towards the floor.
<G-vec00011-002-s076><bring_along.bringen><de> Atme ein, beuge die Ellbogen und bringe deinen Po zum Boden.
<G-vec00011-002-s077><bring_along.bringen><en> Let me be thy proper servant, who took him into my trust, and promised, saying: If I bring him not again, I will be guilty of sin against my father for ever.
<G-vec00011-002-s077><bring_along.bringen><de> Denn ich, dein Knecht, bin Bürge geworden für den Knaben gegen meinen Vater und sprach: Bringe ich ihn dir nicht wieder, so will ich mein Leben lang die Schuld tragen.
<G-vec00011-002-s078><bring_along.bringen><en> He is to bring it to the priest, who is to take a handful of it to be put on the burnt offering for Yahweh in order to recall this man to Yahweh.
<G-vec00011-002-s078><bring_along.bringen><de> 12 Er bringe es dem Priester, der davon eine Hand voll nimmt und als Gedächtnisanteil auf dem Altar mit den Feueropfern des Herrn in Rauch aufgehen lässt.
<G-vec00011-002-s079><bring_along.bringen><en> Bring yourself and your skills into the battle, slip into the role of a paratrooper, tank commander or sniper and immerse yourself in realistic battles.
<G-vec00011-002-s079><bring_along.bringen><de> Bringe Dich und Deine Fähigkeiten in den Kampf, schlüpfe in die Rolle eines Fallschirmjägers, Panzerkommandanten oder Scharfschützen und tauche ein in realistische Schlachten.
<G-vec00011-002-s080><bring_along.bringen><en> Now it happened one day that he was going to a fair; so he asked his daughter, who was named Betta, what she would like him to bring her on his return. And she said, "Papa, if you love me, bring me half a hundredweight of Palermo sugar, and as much again of sweet almonds, with four to six bottles of scented water, and a little musk and amber, also forty pearls, two sapphires, a few garnets and rubies, with some gold thread, and above all a trough and a little silver trowel."
<G-vec00011-002-s080><bring_along.bringen><de> Als er nun einmal zu einer Messe reisen musste, fragte er seine Tochter, die Betta hieß, was er ihr mitbringen solle, worauf sie erwiderte: »Wenn du mich liebhast, Väterchen, so bringe mir einen halben Zentner Palermozucker, einen halben süße Mandeln, vier bis sechs Flaschen wohlriechendes Wasser, etwas Moschus und Ambra, ferner etwa vierzig Stück Perlen, zwei Saphire, einige Granaten und Rubine, etwas Goldgespinst, besonders aber einen Backtrog und Kratzmesser von Silber.« Der Vater wunderte sich zwar über diese etwas unbescheidene Forderung, wollte aber seiner Tochter nicht widersprechen, er reiste daher zur Messe ab und brachte ihr bei seiner Rückkehr ganz genau alles, was sie gewünscht.
<G-vec00011-002-s081><bring_along.bringen><en> Bring your written notes with you when you go to the meeting, as well as any other coworkers who also wish to complain.
<G-vec00011-002-s081><bring_along.bringen><de> Bringe deine schriftlichen Notizen zu dem Meeting und sorge dafür, dass alle Kollegen, die deine Sache unterstützen, ebenfalls zu dem Termin erscheinen.
<G-vec00011-002-s082><bring_along.bringen><en> 23 And he shall bring them on the eighth day for his cleansing unto the priest, unto the door of the tabernacle of the congregation, before YHVH.
<G-vec00011-002-s082><bring_along.bringen><de> 23 und bringe sie am achten Tage seiner Reinigung zum Priester vor die Tür der Hütte des Stifts, vor den HERRN.
<G-vec00011-002-s083><bring_along.bringen><en> 4Then Pilate went out again, and said to them, PONTIUS PILATE Behold, I bring him out to you, that you may know that I find no basis for a charge against him.
<G-vec00011-002-s083><bring_along.bringen><de> Pilatus ging wieder hinaus und sagte zu ihnen: Seht ich bringe ihn zu euch heraus; ihr sollt wissen, das ich keinen Grund finde, ihn zu verurteilen.
<G-vec00011-002-s084><bring_along.bringen><en> Go deeper than the surface with personal stories and context that bring the experience to life.
<G-vec00011-002-s084><bring_along.bringen><de> Gehe tiefer als die Oberfläche und bringe deine Entdeckung mit persönlichen Geschichten und ihrem besonderen Hintergrund zum Leben.
<G-vec00011-002-s085><bring_along.bringen><en> 6:25 Then hear thou from heaven, and forgive the sin of thy people Israel, and bring them back into the land, which thou gavest to them, and their fathers.
<G-vec00011-002-s085><bring_along.bringen><de> 6:25 so höre du vom Himmel her und vergib die Sünde deines Volkes Israel; und bringe sie in das Land zurück, das du ihnen und ihren Vätern gegeben hast.
<G-vec00011-002-s086><bring_along.bringen><en> 5:7 And if he shall not be able to bring a lamb, then he shall bring for his trespass which he hath committed, two turtle-doves, or two young pigeons, to the LORD; one for a sin-offering, and the other for a burnt-offering.
<G-vec00011-002-s086><bring_along.bringen><de> 5:7 Vermag er aber nicht ein Schaf, so bringe er dem HERRN für seine Schuld, die er getan hat, zwo Turteltauben oder zwo junge Tauben, die erste zum Sündopfer, die andere zum Brandopfer.
<G-vec00011-002-s087><bring_along.bringen><en> Join the gods of Greek legend and bring peace to an ancient world on the brink of war!
<G-vec00011-002-s087><bring_along.bringen><de> Bringe einer alten Welt, die an der Schwelle des Krieges steht, Seite an Seite mit den griechischen Göttern Frieden.
<G-vec00011-002-s088><bring_along.bringen><en> In this book, I bring you in as you bring your marketing into the present and make it a success driver for your company.
<G-vec00011-002-s088><bring_along.bringen><de> In diesem Buch bringe ich Ihnen bei, wie Sie Ihr Marketing in die Gegenwart holen und es zu einem Erfolgstreiber in Ihrem Unternehmen machen.
<G-vec00011-002-s089><bring_along.bringen><en> 24When your people Israel are defeated by an enemy because they have sinned against you, and then they turn, praise your name, pray to you, and entreat you in this house, 25listen from heaven and forgive the sin of your people Israel, and bring them back to the land you gave them and their ancestors.
<G-vec00011-002-s089><bring_along.bringen><de> 24Und wenn dein Volk Israel vor dem Feinde geschlagen wird, weil sie wider dich gesündigt haben, und sie kehren um und bekennen deinen Namen und beten und flehen zu dir in diesem Hause: 25so höre du vom Himmel her und vergib die Sünde deines Volkes Israel; und bringe sie in das Land zurück, das du ihnen und ihren Vätern gegeben hast.
<G-vec00011-002-s090><bring_along.bringen><en> Bring your kicking leg out to the side or in front of you with the knee bent all the way.
<G-vec00011-002-s090><bring_along.bringen><de> Bringe das Bein, mit dem du trittst, zur Seite oder nach vorne mit gebeugtem Knie.
<G-vec00011-002-s091><bring_along.bringen><en> And I will bring you into the land of Israel.
<G-vec00011-002-s091><bring_along.bringen><de> Ich bringe euch zurück in das Land Israel.
<G-vec00011-002-s092><bring_along.bringen><en> So why is it, that you do not fight in the way of Allah, and for the abased among men, women, and children who say: 'Our Lord, bring us out from this village whose people are harmdoers, and give to us a guardian from You, and give to us a helper from You.
<G-vec00011-002-s092><bring_along.bringen><de> Was ist mit euch, daß ihr nicht auf Allahs Weg, und (zwar) für die Unterdrückten unter den Männern, Frauen und Kindern kämpft, die sagen: "Unser Herr, bringe uns aus dieser Stadt heraus, deren Bewohner ungerecht sind, und schaffe uns von Dir aus einen Schutzherrn, und schaffe uns von Dir aus einen Helfer.
<G-vec00011-002-s093><bring_along.bringen><en> Let the earth open that it may bring forth salvation, and let it cause righteousness to spring up together.
<G-vec00011-002-s093><bring_along.bringen><de> Die Erde tue sich auf und bringe Heil, und Gerechtigkeit wachse mit zu.
<G-vec00011-002-s094><bring_along.bringen><en> ¶ And if he cannot afford to bring a she lamb, then he shall bring for his sin offering two turtledoves or two young pigeons, one for a sin offering and the other for a burnt offering.
<G-vec00011-002-s094><bring_along.bringen><de> Kann er aber nicht so viel aufbringen, dass es für ein Lamm reicht, so bringe er dem Herrn für das, worin er gesündigt hat, als sein Schuldopfer zwei Turteltauben oder zwei junge Tauben dar; eine als Sündopfer, die andere als Brandopfer.
<G-vec00011-002-s095><bring_along.bringen><en> A war that would bring those swinging sixties to an end.
<G-vec00011-002-s095><bring_along.bringen><de> Ein Krieg, der diese "Swinging Sixties" zu einem bitteren Ende bringen würde.
<G-vec00011-002-s096><bring_along.bringen><en> We bring you up to date regarding the upcoming General Data Protection Regulation, provide information on recent judgements and (planned) legislation amendments.
<G-vec00011-002-s096><bring_along.bringen><de> Wir bringen Sie auf den neusten Stand zur kommenden Datenschutzgrundverordnung, informieren über aktuelle Urteile und (geplante) Gesetzesänderungen.
<G-vec00011-002-s097><bring_along.bringen><en> The Arabic reads, "Stab, and your hands will bring victory."
<G-vec00011-002-s097><bring_along.bringen><de> Der Text lautet: „Stich zu und deine Hände werden den Sieg bringen“ (Jerusalem Brigaden).
<G-vec00011-002-s098><bring_along.bringen><en> Then add the flour mixture to the pan along with the remaining vegetable broth. Stir constantly and bring to the boil.
<G-vec00011-002-s098><bring_along.bringen><de> Die Mehlmischung zusammen mit der restlichen Gemüsebrühe in die Pfanne geben und unter Rühren zum Kochen bringen.
<G-vec00011-002-s099><bring_along.bringen><en> It is our goal to bring products on the market that are as clean and pure as possible, and that contributes to a healthy lifestyle.
<G-vec00011-002-s099><bring_along.bringen><de> Unser Ziel ist es, ein Produkt auf den Markt zu bringen, das so sauber und rein wie möglich ist, und zu einem gesunden Lebensstil beiträgt.
<G-vec00011-002-s100><bring_along.bringen><en> “We are incredibly excited to bring virtual reality to PlayStation 4,” said Jim Ryan, President of Global Sales and Marketing, SIE and President of SIEE.
<G-vec00011-002-s100><bring_along.bringen><de> „Wir freuen uns wirklich sehr darauf, die virtuelle Realität auf PlayStation 4 zu bringen“, so Jim Ryan, President of Global Sales and Marketing von SIE sowie President von SIEE.
<G-vec00011-002-s101><bring_along.bringen><en> Surely that will bring Dawg out of hiding.
<G-vec00011-002-s101><bring_along.bringen><de> Das wird Dawg sicherlich aus dem Versteck bringen.
<G-vec00011-002-s102><bring_along.bringen><en> On point #2: Only properly trained drivers and escorts are fit to bring a heavy load transport safely and competently to its destination.
<G-vec00011-002-s102><bring_along.bringen><de> Zu Punkt 2: Nur gut geschulte Fahrer und Begleiter sind in der Lage, einen Schwertransport sicher und souverän ans Ziel zu bringen.
<G-vec00011-002-s103><bring_along.bringen><en> However, this means that the gym exercises and a balanced diet will not bring such good results if they are not supported by properly matched slimming pills.
<G-vec00011-002-s103><bring_along.bringen><de> Dies bedeutet jedoch, dass die Gymnastikübungen und eine ausgewogene Ernährung nicht so gute Ergebnisse bringen, wenn sie nicht durch richtig abgestimmte Schlankheitspillen unterstützt werden.
<G-vec00011-002-s104><bring_along.bringen><en> 6 You must also bring to the Supreme Priest a ram to be an offering to me in order that you will no longer be guilty.
<G-vec00011-002-s104><bring_along.bringen><de> 6 5:25 Aber für seine Schuld soll er dem HERRN zu dem Priester einen Widder von der Herde ohne Fehl bringen, der eines Schuldopfers wert ist.
<G-vec00011-002-s105><bring_along.bringen><en> One was at this point, however, still clearly said: it is never too late Even if you have exceeded the 45 some time ago, can be obtained by the regular daily intake of melatonin to normalize Zirbeldrüsenfunktion again and the natural, endogenous melatonin production to a level bring corresponds to a much younger body.
<G-vec00011-002-s105><bring_along.bringen><de> Eines sei an dieser Stelle jedoch noch deutlich gesagt: es ist nie zu spät Auch wenn man die 45 schon vor längerer Zeit überschritten hat, kann man durch die regelmäßige tägliche Einnahme von Melatonin, die Zirbeldrüsenfunktion wieder normalisieren und die natürliche, körpereigene Melatoninproduktion auf ein Niveau bringen, das einem wesentlich jüngeren Organismus entspricht.
<G-vec00011-002-s106><bring_along.bringen><en> The foreman told me, “You can bring the materials to the factory if you have any.
<G-vec00011-002-s106><bring_along.bringen><de> Der Vorarbeiter sagte, “Du kannst die Materialien in die Firma bringen, wenn du welche hast.
<G-vec00011-002-s107><bring_along.bringen><en> Close with a lid and bring to a boil.
<G-vec00011-002-s107><bring_along.bringen><de> Einen Deckel auflegen und zum Kochen bringen.
<G-vec00011-002-s108><bring_along.bringen><en> Many people believe that having a pharmacy in Ukraine is synonymous of success since normally in the cities there is a limit per zone, but still many coexist in a very close ratio, if you want to stand out about them and bring you more customers, please, sign up for our directory of Pharmacies in L’vivs’ka oblast’.
<G-vec00011-002-s108><bring_along.bringen><de> Viele Leute glauben, dass eine Apotheke in Deutschland gleichbedeutend mit Erfolg ist, denn normalerweise in den Städten gibt es eine Grenze pro Zone, aber immer noch viele koexistieren in einem sehr engen Verhältnis, wenn Sie sich über sie herausstellen und Ihnen mehr Kunden bringen wollen Bitte melden Sie sich für unser Verzeichnis von Apotheken in Veelböken.
<G-vec00011-002-s109><bring_along.bringen><en> The opulent main courses that bring a taste of the Orient to Cologne are also very well received by diners.
<G-vec00011-002-s109><bring_along.bringen><de> Aber auch die opulenten Hauptspeisen bringen einen Hauch Orient mit nach Köln und kommen bei den Gästen bestens an.
<G-vec00011-002-s110><bring_along.bringen><en> Great quality with popular, beautiful designs and melodious music bring you the warmest regards and unlimited happiness all the time, especially as a gift to your friends.
<G-vec00011-002-s110><bring_along.bringen><de> Große Qualität mit bekannten, schönen Designs und melodische Musik bringen Sie den herzlichsten Grüßen und unbegrenztes Glück die ganze Zeit, vor allem als Geschenk für Ihre Freunde.
<G-vec00011-002-s111><bring_along.bringen><en> The non-agricultural labourers of an Asiatic monarchy have little but their individual bodily exertions to bring to the task, but their number is their strength, and the power of directing these masses gave rise to the palaces and temples, the pyramids, and the armies of gigantic statues of which the remains astonish and perplex us.
<G-vec00011-002-s111><bring_along.bringen><de> Die nicht ackerbauenden Arbeiter einer asiatischen Monarchie haben außer ihren individuellen körperlichen Bemühungen wenig zum Werk zu bringen, aber ihre Zahl ist ihre Kraft, und die Macht der Direktion über diese Massen gab jenen Riesenwerken den Ursprung.
<G-vec00011-002-s112><bring_along.bringen><en> The ocean-going ships were converted for the purpose of sea rescue and patrol alternately off the Libyan coast, where most of the fleeing people, in the attempt to bring to safety, go in greatest mortal danger.
<G-vec00011-002-s112><bring_along.bringen><de> Die hochseetauglichen Schiffe wurden für den Zweck der Seenotrettung umgerüstet und patrouillieren abwechselnd vor der libyschen Küste, wo sich die meisten flüchtenden Menschen, bei dem Versuch sich in Sicherheit zu bringen, in größte Lebensgefahr begeben.
<G-vec00011-002-s113><bring_along.bringen><en> To benefit from this arrangement, please bring along the equivalent insurance form of your home health insurance.
<G-vec00011-002-s113><bring_along.bringen><de> Bringen Sie dazu bitte das entsprechende Formblatt der Krankenversicherung Ihres Heimatlandes mit.
<G-vec00011-002-s114><bring_along.bringen><en> Yamazaki Bring beauty & function to your home with Japanese homeware designer Yamazaki.
<G-vec00011-002-s114><bring_along.bringen><de> Yamazaki Bringen Sie mit dem japanischen Haushaltswaren-Designer Yamazaki Schönheit und Funktion in Ihr Zuhause.
<G-vec00011-002-s115><bring_along.bringen><en> There are many wet parts of the trail, you are inevitably going to get we, so bring waterproof shoes and clothes that will dry easy.
<G-vec00011-002-s115><bring_along.bringen><de> Es gibt viele nasse Teile des Weges, die Sie unweigerlich bekommen werden, bringen Sie also wasserdichte Schuhe und Kleidung mit, die leicht trocknen.
<G-vec00011-002-s116><bring_along.bringen><en> The House of Friendship is a wonderful place to bring your convention guests – your family and your friends from home.
<G-vec00011-002-s116><bring_along.bringen><de> Und das Schönste daran: Bringen Sie auch Ihre Gäste, Ihre Freunde, Ihre Familie mit.
<G-vec00011-002-s117><bring_along.bringen><en> Bring the water to a rolling boil, then add the sliced mushrooms.
<G-vec00011-002-s117><bring_along.bringen><de> Bringen Sie das Wasser zum kochen, dann geben Sie die in Scheiben geschnittenen Pilze dazu.
<G-vec00011-002-s118><bring_along.bringen><en> A travel cot (and a highchair) can be made available for either bedroom at no extra cost - just bring your own cot sheets.
<G-vec00011-002-s118><bring_along.bringen><de> Ein Kinderreisebett (und ein Hochstuhl) kann für beide Schlafzimmer ohne zusätzliche Kosten zur Verfügung gestellt werden - bringen Sie nur Ihre eigenen Kinderbett Bettwäsche.
<G-vec00011-002-s119><bring_along.bringen><en> Bring Payments to your iOS app
<G-vec00011-002-s119><bring_along.bringen><de> Bringen Sie Zahlungen zu Ihrer iOS App.
<G-vec00011-002-s120><bring_along.bringen><en> Bring 2 a 3 nuts to the hair.
<G-vec00011-002-s120><bring_along.bringen><de> Bringen Sie 2 ein 3 Muttern auf das Haar.
<G-vec00011-002-s121><bring_along.bringen><en> Bring a water bottle.
<G-vec00011-002-s121><bring_along.bringen><de> Bringen Sie eine Wasserflasche.
<G-vec00011-002-s122><bring_along.bringen><en> Follow the instructions and change his diaper, bring his favorite toys and play a while and make sure he gets tried and goes to sleep.
<G-vec00011-002-s122><bring_along.bringen><de> Folgen Sie den Anweisungen und wechseln Sie seine Windel, bringen Sie seine Lieblings-Spielzeug und spielen Sie eine Weile und stellen Sie sicher, er wird erprobt und in den Ruhezustand versetzt.
<G-vec00011-002-s123><bring_along.bringen><en> Bring focus, discipline and speed to your security operations center and mitigate the impact of data breaches with a swift, sure cyber incident response capability.
<G-vec00011-002-s123><bring_along.bringen><de> Bringen Sie Fokus, Disziplin und Tempo in Ihr Security Operations Center und vermindern Sie die Auswirkungen von Datenschutzverletzungen mit schnellen, zuverlässigen Funktionen zur Behandlung von Cyber-Incidents.
<G-vec00011-002-s124><bring_along.bringen><en> Wear your bathing suit under your wetsuit and bring a towel and your sense of adventure.
<G-vec00011-002-s124><bring_along.bringen><de> Tragen Sie Ihre Badesachen unter Ihrem Neoprenanzug und bringen Sie ein Handtuch und Ihre Abenteuerlust mit.
<G-vec00011-002-s125><bring_along.bringen><en> Discover with us secret boutiques, meet independent designers or ancient handicraft producers and bring back home an authentic Italian atmosphere.
<G-vec00011-002-s125><bring_along.bringen><de> Entdecken Sie mit uns geheime Boutiquen, treffen Sie unabhängige Designer oder alte Kunsthandwerker und bringen Sie eine authentische italienische Atmosphäre mit nach Hause.
<G-vec00011-002-s126><bring_along.bringen><en> Bonus tip: bring carnelian to the gym for a pocket-sized personal trainer who will always encourage you to do your very best.
<G-vec00011-002-s126><bring_along.bringen><de> Kleiner extra Tipp: Bringen Sie einen Karneol mit ins Fitnessstudio – als Personal Trainer im Taschenformat, der Sie stets ermutigen wird, Ihr Bestes zu geben.
<G-vec00011-002-s127><bring_along.bringen><en> Bring a friend, your child or anyone else you want to spend this time learning about the science of colours.
<G-vec00011-002-s127><bring_along.bringen><de> Bringen Sie einen Freund, Ihr Kind oder irgendjemand anderes, mit dem Sie diese Zeit verbringen möchten, um sich über die Wissenschaft der Farben zu informieren.
<G-vec00011-002-s128><bring_along.bringen><en> Bring extra weather gear and prepare for thunderstorms, or a sudden dip in the temperature.
<G-vec00011-002-s128><bring_along.bringen><de> Bringen Sie zusätzliche Kleidungsstücke mit und seien Sie auch auf ein Gewitter oder einen plötzlichen Temperatursturz vorbereitet.
<G-vec00011-002-s129><bring_along.bringen><en> With Pega Mashup, bring the intelligence of our Case Management directly to the customer touchpoint, instead of hard-coding logic into each channel independently.
<G-vec00011-002-s129><bring_along.bringen><de> Mit Pega Mashup bringen Sie die Intelligenz unseres Case Managements direkt zum Kundenkontaktpunkt, die Hartcodierung der Logik für jeden einzelnen Kanal entfällt.
<G-vec00011-002-s130><bring_along.bringen><en> You will find everything you need (linen and provisions, internal mini-market) so bring only your suitcases. Activity
<G-vec00011-002-s130><bring_along.bringen><de> Sie finden alles, was Sie brauchen (Bettwäsche und Proviant, Minimarkt), bringen Sie also nur Ihre Koffer mit.
<G-vec00011-002-s131><bring_along.bringen><en> Bring a good book, a camera, a glass of wine and a sense of adventure.
<G-vec00011-002-s131><bring_along.bringen><de> Bringen Sie ein gutes Buch, eine Kamera, ein Glas Wein und ein Gefühl von Abenteuer.
<G-vec00011-002-s132><bring_along.bringen><en> Use this rug as a decorative accessory in your living room or bring more comfort to your driveway.
<G-vec00011-002-s132><bring_along.bringen><de> Verwenden Sie diesen Teppich als dekoratives Accessoire in Ihrem Wohnzimmer oder bringen Sie mehr Komfort in Ihre Einfahrt.
<G-vec00011-002-s133><bring_along.bringen><en> One or more, she will bring a vintage style with its orange filaments.
<G-vec00011-002-s133><bring_along.bringen><de> Eine oder mehrere, bringt sie einen Vintage-Stil mit seinen orangefarbenen Filamente.
<G-vec00011-002-s134><bring_along.bringen><en> The rest of the day will bring cloudless weather.
<G-vec00011-002-s134><bring_along.bringen><de> Der Nachmittag bringt wechselnd bis stark bewölktes, aber verbreitet trockenes Wetter.
<G-vec00011-002-s135><bring_along.bringen><en> The evening will bring clouds with rain or sleet.
<G-vec00011-002-s135><bring_along.bringen><de> Die Mittagszeit bringt wechselhaftes Wetter mit ab und zu etwas Regen.
<G-vec00011-002-s136><bring_along.bringen><en> The noon will bring variable clouds with scattered rain showers.
<G-vec00011-002-s136><bring_along.bringen><de> Die Mittagszeit bringt unbeständiges und ab und zu nasses Wetter.
<G-vec00011-002-s137><bring_along.bringen><en> Android 7.0 System--High efficient Android 7.0 operating system with lower battery consumption and bring more high performance experience.
<G-vec00011-002-s137><bring_along.bringen><de> Android 7.0 System --Hochleistungsfähiges Android 7.0 Betriebssystem mit niedrigerem Batterieverbrauch und bringt mehr Hochleistungserfahrung.
<G-vec00011-002-s138><bring_along.bringen><en> The noon will bring variable cloudy, but mostly dry weather.
<G-vec00011-002-s138><bring_along.bringen><de> Der Nachmittag bringt sonniges oder leicht bewölktes Wetter.
<G-vec00011-002-s139><bring_along.bringen><en> Ex 23,20 "Behold, I am going to send an angel before you to guard you along the way and to bring you into the place which I have prepared.
<G-vec00011-002-s139><bring_along.bringen><de> 2Mo 23,20 Siehe, ich sende einen Engel vor dir her damit er dich auf dem Weg bewahrt und dich an den Ort bringt, den ich für dich bereitet habe.
<G-vec00011-002-s140><bring_along.bringen><en> Get the Noble Staff Components and bring it to Tataka.
<G-vec00011-002-s140><bring_along.bringen><de> Beschafft die Empyrianische Stabkomponente und bringt sie zu Tataka.
<G-vec00011-002-s141><bring_along.bringen><en> Givat Haviva is one of the biggest, oldest, and leading institutions which in Israel concern itself with Jewish Arab mutual understanding, which support cultural and religious pluralism, which work for democratic values and peace, and which bring the past of the Jewish people to the consciousness of the youth of today in its educational work.
<G-vec00011-002-s141><bring_along.bringen><de> Givat Haviva ist eines der größten, ältesten und führenden Institute, das sich in Israel für jüdisch-arabische Verständigung einsetzt, den kulturellen und religiösen Pluralismus fördert, für demokratische Werte und Frieden wirkt und die Vergangenheit des jüdischen Volkes in erzieherischer Arbeit der Jugend von heute nahe bringt.
<G-vec00011-002-s142><bring_along.bringen><en> The late evening will bring clouds with local snowfall.
<G-vec00011-002-s142><bring_along.bringen><de> Der Nachmittag bringt zeitweise sonniges Wetter.
<G-vec00011-002-s143><bring_along.bringen><en> We cannot predict what time will bring. But we can make it more beautiful.
<G-vec00011-002-s143><bring_along.bringen><de> Wir wissen nicht was die Zeit bringt, wir können sie aber schöner machen.
<G-vec00011-002-s144><bring_along.bringen><en> The night will bring cloudy, but mostly dry weather.
<G-vec00011-002-s144><bring_along.bringen><de> Der Nachmittag bringt wechselnd bewölktes und meist trockenes Wetter.
<G-vec00011-002-s145><bring_along.bringen><en> The noon will bring partly sunny, partly cloudy weather.
<G-vec00011-002-s145><bring_along.bringen><de> Die Mittagszeit bringt zeitweise sonniges Wetter.
<G-vec00011-002-s146><bring_along.bringen><en> Bring your tent, your passion and commitment and join us to stop the next generation of nuclear weapons from being built.
<G-vec00011-002-s146><bring_along.bringen><de> Bringt Euer Zelt, Eure Leidenschaft und Engagement und schließt Euch uns an, um zu verhindern, dass die nächste Generation von Atomwaffen gebaut wird.
<G-vec00011-002-s147><bring_along.bringen><en> Each sticker delivers a nice message for Christmas and will bring a chic touch to your gifts with their silver and gold colors.
<G-vec00011-002-s147><bring_along.bringen><de> Jeder Aufkleber liefert eine nette Nachricht für Weihnachten und bringt Ihren Geschenken mit ihren silbernen und goldenen Farben einen schicken Touch.
<G-vec00011-002-s148><bring_along.bringen><en> The evening will bring mostly cloudy weather.
<G-vec00011-002-s148><bring_along.bringen><de> Der Nachmittag bringt meist bewölktes, aber trockenes Wetter.
<G-vec00011-002-s149><bring_along.bringen><en> When one’s wishing turns to such subjects, he stops wishing and tries to acquire these by doing what he thinks will develop virtue and bring wisdom.
<G-vec00011-002-s149><bring_along.bringen><de> Wenn sich jemand solchen Themen zuwendet, hört er auf zu wünschen und versucht, diese zu erlangen, indem er das tut, von dem er glaubt, dass es Tugend entwickelt und Weisheit bringt.
<G-vec00011-002-s150><bring_along.bringen><en> The first stage only needs 10 Stars and will bring you 3000 Crystals, and the Microbiology Animated Paint if you have a Battle Pass.
<G-vec00011-002-s150><bring_along.bringen><de> Die erste Stufe benötigt nur 10 Sterne und bringt Euch 3000 Kristalle und die animierte Farbe «Mikrobiologie», wenn Ihr das Schlacht-Abonnement habt.
<G-vec00011-002-s151><bring_along.bringen><en> But Buddel is drunk so he might bring you to the wrong island.
<G-vec00011-002-s151><bring_along.bringen><de> Aber Buddel ist betrunken, deshalb kann es sein, dass er dich zur falschen Insel bringt.
<G-vec00011-002-s304><bring_along.bringen><en> Visitors are not allowed to drive directly to the house, but we will bring your baggage there for you .
<G-vec00011-002-s304><bring_along.bringen><de> Es besteht keine Fahrmöglichkeit für Sie zum Haus, allerdings wird das Gepäck von uns mit Ihnen hoch gebracht.
<G-vec00011-002-s305><bring_along.bringen><en> He was playing his acoustic guitar while she was standing at the doors, waiting for the tour manager to bring her to the band.
<G-vec00011-002-s305><bring_along.bringen><de> Er spielte auf seiner akustischen Gitarre, während sie an der Tür stand und darauf wartete, dass sie vom Tourmanager zur Band gebracht wurde.
<G-vec00011-002-s306><bring_along.bringen><en> Unfortunately the dress a tad too big and therefore it will be my first piece of clothing, ever that I will bring to the tailor.
<G-vec00011-002-s306><bring_along.bringen><de> Leider ist es mir ein wenig groß und so wird dieses Kleid mein erstes Stück sein, welches ich jemals zum Schneider gebracht habe.
<G-vec00011-002-s307><bring_along.bringen><en> Fixed network penetration peaked at around 32%, falling back slightly in response to recent price changes designed to bring prices more closely into line with costs as required by the acquis.
<G-vec00011-002-s307><bring_along.bringen><de> Die Anschlussdichte im Festnetz erreichte einen Höchststand von etwa 32 % und ging als Reaktion auf die jüngsten Tarifänderungen, mit denen die Tarife entsprechend den Vorgaben des Besitzstands in größere Übereinstimmung mit den echten Kosten gebracht werden sollen, leicht zurück.
<G-vec00011-002-s308><bring_along.bringen><en> 7:52, He asked to bring him to his home for one night.
<G-vec00011-002-s308><bring_along.bringen><de> 7:52 Er bat darum, für eine Nacht nach Hause gebracht zu werden.
<G-vec00011-002-s309><bring_along.bringen><en> But that has nearly nothing to do with my work on land and that did not bring me to deep-sea taxonomy.
<G-vec00011-002-s309><bring_along.bringen><de> Mit meiner täglichen Arbeit an Land hat das aber natürlich wenig zu tun und dieser Anreiz allein hat mich auch nicht zur Tiefsee-Taxonomie gebracht.
<G-vec00011-002-s310><bring_along.bringen><en> But the borrower did not bring nor did he deposit any money, since he came to the bank to get money he did not have.
<G-vec00011-002-s310><bring_along.bringen><de> Der Darlehensnehmer hat es jedoch weder gebracht noch eingezahlt, da er gekommen ist, um Geld zu holen, das er nicht besaß.
<G-vec00011-002-s311><bring_along.bringen><en> We continued to bring new and further stages of technical developments into the car in the second half of the season, but unfortunately they didn’t produce the performance gains we expected.
<G-vec00011-002-s311><bring_along.bringen><de> Wir haben auch in der zweiten Saisonhälfte technische Neu- und Weiterentwicklungen gebracht, sie haben aber leider nicht den erwarteten Zuwachs an Performance gebracht.
<G-vec00011-002-s312><bring_along.bringen><en> For this reason, it was first necessary to bring the different volumes of individual works to a unified level, as the volume can’t constantly be turned up and down on an aircraft, of course.
<G-vec00011-002-s312><bring_along.bringen><de> Daher mussten zunächst die unterschiedlichen Laufstärke der einzelnen Werke auf ein einheitliches Niveau gebracht werden, da man im Flugzeug natürlich nicht ständig lauter und leiser drehen kann.
<G-vec00011-002-s313><bring_along.bringen><en> Under the slogan “Bring it today, best in the morning, collect it tomorrow or already this evening”, W. Klinger is able to promise customers a highly appreciated full service.
<G-vec00011-002-s313><bring_along.bringen><de> Nach dem Motto: „Heute oder morgens gebracht, morgen oder schon abends gemacht“ bietet W. Klinger einen bei den Kunden gefragten Fullservice.
<G-vec00011-002-s314><bring_along.bringen><en> 3 And he proceeded to bring me there, and, look! there was a man.
<G-vec00011-002-s314><bring_along.bringen><de> 3 Als er mich dorthin gebracht hatte, erschien plötzlich ein Mann, der glänzend wie Erz aussah.
<G-vec00011-002-s315><bring_along.bringen><en> 11 Your gates shall be open continually; day and night they shall not be shut, that people may bring to you the wealth of the nations, with their kings led in procession.
<G-vec00011-002-s315><bring_along.bringen><de> 11 Deine Tore sollen stets offen stehen und weder Tag noch Nacht zugeschlossen werden, dass der Reichtum der Völker zu dir gebracht und ihre Könige herzugeführt werden.
<G-vec00011-002-s316><bring_along.bringen><en> There is a wheelchair available on all ships to use exclusively to bring the passenger into the cabin.
<G-vec00011-002-s316><bring_along.bringen><de> Auf allen Schiffen steht ein Rollstuhl zur Verfügung, den die Passagiere ausschließlich dafür nutzen können, in die Kabine gebracht zu werden.
<G-vec00011-002-s317><bring_along.bringen><en> It did not bring about a real social reform, although it became for the whole world a powerful threat and a challenge.
<G-vec00011-002-s317><bring_along.bringen><de> Er hat keine wirkliche Sozialreform zuwege gebracht, obwohl er für die ganze Welt zu einer mächtigen Bedrohung und einer Herausforderung geworden ist.
<G-vec00011-002-s318><bring_along.bringen><en> Hidden from view beneath the product surface of all highly complicated electronic systems is the pressure to develop at an acceptable price, manufacture and bring onto the market an utterly reliable as well as energy efficient product.
<G-vec00011-002-s318><bring_along.bringen><de> Für das Auge meist unsichtbar unter der Produktoberfläche verborgen, müssen elektronische Systeme mit höchster Komplexität in extrem kurzer Zeit zu einem akzeptablen Preis entworfen, hergestellt und auf den Markt gebracht werden und absolut zuverlässig sowie energieeffizient funktionieren.
<G-vec00011-002-s319><bring_along.bringen><en> Changing the page order within a PDF and then saving did not bring the desired effect.
<G-vec00011-002-s319><bring_along.bringen><de> Das Ändern der Seitenreihenfolge innerhalb einer PDF und das anschließende Speichern hat nicht den gewünschten Effekt gebracht.
<G-vec00011-002-s320><bring_along.bringen><en> I could rescue all my books and bring them back to Germany.
<G-vec00011-002-s320><bring_along.bringen><de> Meine sämtlichen Bücher habe ich gerettet und mit nach Deutschland gebracht.
<G-vec00011-002-s321><bring_along.bringen><en> Afterall, everyone wants that unique piece to bring back home.
<G-vec00011-002-s321><bring_along.bringen><de> Schließlich möchte jeder, dass dieses einzigartige Stück nach Hause gebracht wird.
<G-vec00011-002-s322><bring_along.bringen><en> We hope that these pages, which are constantly updated in order to bring you the very latest on our holiday menu, will help you plan your stay in advance.
<G-vec00011-002-s322><bring_along.bringen><de> Wir hoffen das diese Seiten, die ständig auf den neusten Stand gebracht werden, ihnen helfen werden ihren Aufenthalt so angenehm wie möglich im Voraus zu gestalten.
<G-vec00011-002-s171><bring_along.einbringen><en> If this recommendation is not followed, the Committee can bring the case to the ERGO Board of Management.
<G-vec00011-002-s171><bring_along.einbringen><de> Wird dieser Empfehlung nicht gefolgt, kann das Gremium den Fall in den ERGO Vorstand einbringen.
<G-vec00011-002-s172><bring_along.einbringen><en> This webinar dives deeper into Amazon SageMaker, with demos on using neural networks and embeddings for recommendations, and how you can bring your own R algorithm using the sample Juptyer notebooks to get you started.
<G-vec00011-002-s172><bring_along.einbringen><de> Dieses Webinar verschafft mit seinen Demos zur Nutzung neuronaler Netzwerke und empfohlenen Einbettungsmöglichkeiten tiefere Einblicke in Amazon SageMaker und zeigt, wie Sie zum Einstieg Ihren eigenen R-Algorithmus unter Verwendung der Juptyer-Notebooks einbringen.
<G-vec00011-002-s173><bring_along.einbringen><en> The earlier we get involved in a project, the better we can bring in our experience in the critical, early project stage.
<G-vec00011-002-s173><bring_along.einbringen><de> Je früher wir dabei in Ihr Projekt involviert werden, desto mehr Erfahrung können wir bereits in den besonders wichtigen, frühen Projektphasen einbringen.
<G-vec00011-002-s174><bring_along.einbringen><en> Wind or draft may bring microorganisms that can contaminate the Mondo® 'B+' XL Magic Mushroom grow kit.
<G-vec00011-002-s174><bring_along.einbringen><de> Wind oder Zugluft kann Mikroorganismen einbringen, die das Psilocybe cubensis Albino A+ XL Zauberpilze Growkit kontaminieren können.
<G-vec00011-002-s175><bring_along.einbringen><en> At first, members of the university should bring documents to the library network, which is why the university is entered standardly.
<G-vec00011-002-s175><bring_along.einbringen><de> Zunächst sollen nur Angehörige der Universität Dokumente in den Publikationsverbund einbringen, deshalb ist diese Hochschule als Standardwert eingetragen.
<G-vec00011-002-s176><bring_along.einbringen><en> Our aim is to bring our award-winning expertise in the film and automobile sectors to bear on other industries.
<G-vec00011-002-s176><bring_along.einbringen><de> Wir wollen unsere preisgekrönte Expertise aus der Film- und Automobilbranche für andere Branchen gewinnbringend einbringen.
<G-vec00011-002-s177><bring_along.einbringen><en> And that I can bring in my ideas and that the team can turn ideas into reality.
<G-vec00011-002-s177><bring_along.einbringen><de> Und dass ich meine Ideen einbringen kann und wir sie gemeinsam im Team verwirklichen.
<G-vec00011-002-s178><bring_along.einbringen><en> If interested, please contact the respective representative of your state group in order to bring the proposals in the faculty can.
<G-vec00011-002-s178><bring_along.einbringen><de> Bei Interesse wenden Sie sich bitte an die jeweiligen Vertreter Ihrer Statusgruppe, um die Vorschläge im Fachbereichsrat einbringen zu können.
<G-vec00011-002-s179><bring_along.einbringen><en> So everyone can bring in their own ideas from day one and actively help to shape the company's development.
<G-vec00011-002-s179><bring_along.einbringen><de> So kann auch jeder vom ersten Tag an eigene Ideen einbringen und die Unternehmensentwicklung aktiv mitgestalten.
<G-vec00011-002-s180><bring_along.einbringen><en> Wind or draft may bring microorganisms that can contaminate the Psilocybe cubensis XL Magic Mushroom grow kit.
<G-vec00011-002-s180><bring_along.einbringen><de> Wind oder Zugluft kann Mikroorganismen einbringen, die das Psilocybe cubensis XL Zauberpilze Growkit kontaminieren können.
<G-vec00011-002-s181><bring_along.einbringen><en> But I can see that it’s certainly possible to bring dissenting views to the debate and that they will be listened to.
<G-vec00011-002-s181><bring_along.einbringen><de> Ich sehe aber, dass man durchaus abweichende Standpunkte in die Debatte einbringen kann und dass dabei auch zugehört wird.
<G-vec00011-002-s182><bring_along.einbringen><en> In Italy there is very intensive economic development underway, that is supposed to bring the bosses immense profits, with the consequence of enormous increases in the accumulation.
<G-vec00011-002-s182><bring_along.einbringen><de> In Italien ist eine sehr intensive wirtschaftliche Entwicklung in Gang, die der Unternehmerschaft immense Profite einbringen soll, mit der Folge, daß die Akkumulation gewaltig anwächst.
<G-vec00011-002-s183><bring_along.einbringen><en> Both of them understand exactly where we’re coming from and know how to contribute ideas that bring new, beneficial aspects to the project.
<G-vec00011-002-s183><bring_along.einbringen><de> Beide verstehen genau, woher wir kommen und wissen wie sie Ideen einbringen können, die neue, vorteilhafte Aspekte zum Projekt hinzufügen.
<G-vec00011-002-s184><bring_along.einbringen><en> No sooner said than done, a “Doodle” is launched for setting up a meeting so that everyone can bring his ideas to advance the “Planet 9” folder.
<G-vec00011-002-s184><bring_along.einbringen><de> Mithilfe eines „Doodle“ wird nach einem Datum für ein Treffen gesucht, an dem jedermann seine Ideen einbringen kann, um die Forschung in Sachen „Planet 9“ weiterzubringen.
<G-vec00011-002-s185><bring_along.einbringen><en> 5 and it hath been on the sixth day, that they have prepared that which they bring in, and it hath been double above that which they gather day [by] day.'
<G-vec00011-002-s185><bring_along.einbringen><de> 5 Des sechsten Tages aber sollen sie zurichten, was sie einbringen, und es wird zwiefältig soviel sein, als sie sonst täglich sammeln.
<G-vec00011-002-s186><bring_along.einbringen><en> Through the built-in annotation feature you can bring yourself directly into the image and graphically communicate your feedback.
<G-vec00011-002-s186><bring_along.einbringen><de> Durch die integrierte Annotations Funktion können Sie sich direkt im Bild einbringen und Ihr Feedback grafisch übermitteln.
<G-vec00011-002-s187><bring_along.einbringen><en> We’re all certainly fans of the mid 90’s Swedish bands like Dissection, Dawn, Sacramentum, Unanimated… etc but there’s a lot of other influences and sounds that we bring into our music.
<G-vec00011-002-s187><bring_along.einbringen><de> Wir sind allesamt Fans von schwedischen Bands wie Dissection, Dawn, Sacramentum, Unanimated usw., aber es gibt viele andere Einflüsse und Sounds, die wir in unsere Musik einbringen.
<G-vec00011-002-s188><bring_along.einbringen><en> Ireland, Finland, Sweden and the Czech Republic have taken a stance against the plans, which estimates say could bring in as much as €5 billion in tax revenue annually.
<G-vec00011-002-s188><bring_along.einbringen><de> So haben sich Irland, Finnland, Schweden und die Tschechische Republik gegen die Steuerpläne ausgesprochen, die nach Schätzungen jährlich bis zu fünf Milliarden Euro an Steuereinnahmen einbringen könnten.
<G-vec00011-002-s189><bring_along.einbringen><en> According to Philip Grant, the Director of TRIAL, “Giorgio Malinverni will bring to TRIAL his wide knowledge of human rights issues which will further enhance its work in favour of the victims.
<G-vec00011-002-s189><bring_along.einbringen><de> Gemäss Philip Grant, ihrem Direktor: „Giorgio Malinverni wird bei TRIAL sein großes Wissen im Bereich der Menschenrechte sowie eine starke Sichtbarkeit für die Arbeit zur Unterstützung der Opfer einbringen.
<G-vec00011-002-s323><bring_along.holen><en> The combination of visiting a Japanese motorbike manufacturing plant and lobbying in Washington for import tariffs was a daring move on behalf of Harley's executives in their attempt to bring back profitability and growth to the company.
<G-vec00011-002-s323><bring_along.holen><de> Die Kombination des Besichtigens einer japanischen Motorradproduktionsanlage und des Beeinflussens in Washington für Importtarife war eine verwegene Bewegung im Namen der Hauptleiter Harleys in ihrem Versuch, Rentabilität und Wachstum zurück zu holen der Firma.
<G-vec00011-002-s324><bring_along.holen><en> To bring a small diversity of these beautiful objects into reality is what constantly motivates us, and we are always happy about requests for collaboration.
<G-vec00011-002-s324><bring_along.holen><de> Eine kleine Vielfalt dieser schönen Objekte in die Welt zu holen motiviert uns immer wieder, weshalb wir uns auch immer über Anfragen zur Kooperation freuen.
<G-vec00011-002-s325><bring_along.holen><en> If any of you are driven out to the farthest parts under heaven, from there YHWH your God will gather you, and from there He will bring you.
<G-vec00011-002-s325><bring_along.holen><de> 4 Wenn deine Verstoßenen am Ende des Himmels wären, [selbst] von dort wird der HERR, dein Gott, dich sammeln, und von dort wird er dich holen.
<G-vec00011-002-s326><bring_along.holen><en> "I wanted to keep the team together and I thought it was going to help the ownership bring all the guys back," Durant said.
<G-vec00011-002-s326><bring_along.holen><de> "Ich wollte, dass das Team zusammen bleibt und dachte, dass dies helfen würde, alle Jungs wieder an Bord zu holen.
<G-vec00011-002-s327><bring_along.holen><en> He wants to bring jazz to Chemnitz.
<G-vec00011-002-s327><bring_along.holen><de> Er will den Jazz nach Chemnitz holen.
<G-vec00011-002-s328><bring_along.holen><en> The purpose of an expert discussion is to bring all parties together aound one table and to enable an exchange of views about new developments.
<G-vec00011-002-s328><bring_along.holen><de> Das Fachgespräch hat die Aufgabe, alle Parteien an einen Tisch zu holen, um sich gegenseitig über neue Entwicklungen auszutauschen.
<G-vec00011-002-s329><bring_along.holen><en> Our goal was to bring the Baltic Sea to Berlin, to strengthen its foothold in the capital’s political and media consciousness.
<G-vec00011-002-s329><bring_along.holen><de> Unser Ziel war es, die Ostsee nach Berlin zu holen, um sie stärker im politischen und medialen Bewußtsein der Hauptstadt zu verankern.
<G-vec00011-002-s330><bring_along.holen><en> I pleaded with the Germans to bring a doctor, but I do not believe they understood me.
<G-vec00011-002-s330><bring_along.holen><de> Ich bat die Deutschen darum einen Arzt zu holen, aber ich glaube sie verstanden mich nicht.
<G-vec00011-002-s331><bring_along.holen><en> 5 So David assembled all Israel together, from the Shihor [the brook] of Egypt even to the entrance of Hamath, to bring the ark of God from Kiriath-jearim.
<G-vec00011-002-s331><bring_along.holen><de> 5 Also versammelte David das ganze Israel, vom Sihor Ägyptens an, bis man kommt gen Hamath, die Lade Gottes zu holen von Kirjath-Jearim.
<G-vec00011-002-s332><bring_along.holen><en> Lisa and Manuel came to get Nathan and Catalina to bring them to the dance floor.
<G-vec00011-002-s332><bring_along.holen><de> In dem Augenblick kamen Manuel und Lisa um sie zum Tanzen zur Strandbar zu holen.
<G-vec00011-002-s333><bring_along.holen><en> Bring the big match to your home with Football Mode, which uses acoustic data from a Brazilian football stadium.
<G-vec00011-002-s333><bring_along.holen><de> Mit dem Fußballmodus, für den akustische Daten eines brasilianischen Stadions erfasst wurden, holen Sie sich Fußballlaune ins Wohnzimmer.
<G-vec00011-002-s334><bring_along.holen><en> From my point of view, it is particularly important that the brands bring the target group to the table – not just as “interns”, but to provide meaningful input.
<G-vec00011-002-s334><bring_along.holen><de> Besonders wichtig ist aus meiner Sicht, dass die Brands sich die Zielgruppe mit an den Tisch holen – und das nicht als „Praktikanten“, sondern als aussagekräftige Impulsgeber.
<G-vec00011-002-s335><bring_along.holen><en> Bring yourself a piece of nostalgia into the house with a lamp that is otherwise known only from old banks, law offices and courtrooms.
<G-vec00011-002-s335><bring_along.holen><de> Holen Sie sich ein Stück Nostalgie ins Haus mit einer Lampe wie man Sie sonst nur aus alten Banken, Kanzleien und Gerichtssälen kennt.
<G-vec00011-002-s336><bring_along.holen><en> In this book, I bring you in as you bring your marketing into the present and make it a success driver for your company.
<G-vec00011-002-s336><bring_along.holen><de> In diesem Buch bringe ich Ihnen bei, wie Sie Ihr Marketing in die Gegenwart holen und es zu einem Erfolgstreiber in Ihrem Unternehmen machen.
<G-vec00011-002-s337><bring_along.holen><en> With this device, users can bring 3D applications into their field of vision by using gestures and voice commands.
<G-vec00011-002-s337><bring_along.holen><de> Andreas kann 3-D-Anwendungen in sein Blickfeld holen, die er mittels Gesten und Stimmbefehlen steuert.
<G-vec00011-002-s338><bring_along.holen><en> Apart from that, I want to bring more strong women up onto the stage and to make the fintech sector more feminine.
<G-vec00011-002-s338><bring_along.holen><de> Darüber hinaus möchte ich gern noch mehr starke Frauen auf die Bühne holen und die Fintech Branche insgesamt weiblicher machen.
<G-vec00011-002-s339><bring_along.holen><en> The armory is nearby, so you are welcome to pick up your weapon, bring back good old memories of Mercenaries, and kill as many infected creatures as you want.
<G-vec00011-002-s339><bring_along.holen><de> Die Waffenkammer ist nahe gelegen, also sind Sie willkommen, Ihre Waffe aufzuheben, gute alte Erinnerungen von Söldnern zurück zu holen, und so viele angesteckte Geschöpfe zu töten, die Sie wünschen.
<G-vec00011-002-s340><bring_along.holen><en> Your understanding will be highly appreciated if our holidays bring any inconveniences.
<G-vec00011-002-s340><bring_along.holen><de> Ihr Verständnis wird in hohem Grade geschätzt, wenn unsere Feiertage irgendwelche Unannehmlichkeiten holen.
<G-vec00011-002-s341><bring_along.holen><en> Our gins, juices, whiskeys and wines will bring you back to reality.
<G-vec00011-002-s341><bring_along.holen><de> Unsere Gins, Whiskeys und Weine holen dich zurück in die Realität.
<G-vec00011-002-s418><bring_along.mitbringen><en> Visitors will not be allowed to bring objects which could be misconstrued as weapons, including weapon-like cosplay items.
<G-vec00011-002-s418><bring_along.mitbringen><de> Besucher dürfen keine Objekte mitbringen, die für Waffen gehalten werden können, darunter waffenartige Cosplay-Gegenstände.
<G-vec00011-002-s419><bring_along.mitbringen><en> We hope that you will bring along your family and friends to enjoy this special occasion and look forward to sharing an unforgettable evening with you.
<G-vec00011-002-s419><bring_along.mitbringen><de> Wir hoffen, dass Sie Ihre Familie und Freunde mitbringen, um mit ihnen diesen besonderen Anlass zu feiern und wir freuen uns darauf, mit Ihnen allen einen unvergesslichen Abend zu verbringen.
<G-vec00011-002-s420><bring_along.mitbringen><en> Please inform the hotel in advance if you bring your pet. Hotel Facilities
<G-vec00011-002-s420><bring_along.mitbringen><de> Bitte informieren Sie das Hotel im Voraus, wenn Sie Ihr Haustier mitbringen.
<G-vec00011-002-s421><bring_along.mitbringen><en> The animal may not sleep in the Standard Igloos and you must bring an extra sleeping bag and blanket for your animal.
<G-vec00011-002-s421><bring_along.mitbringen><de> Das Tier darf nicht in den Standard-Iglus schlafen und Sie müssen einen eigenen Schlafsack und Decken für Ihr Tier mitbringen.
<G-vec00011-002-s422><bring_along.mitbringen><en> The town bell rings every hour - great for old world atmosphere and telling the time, but bring ear and the room is simple and comfortable.
<G-vec00011-002-s422><bring_along.mitbringen><de> Die Stadt Glocke läutet jede Stunde - ideal für alte Welt Atmosphäre und die Zeit, zu sagen, aber Ohrenstöpsel mitbringen, wenn Sie einen leichten Schlaf haben.
<G-vec00011-002-s423><bring_along.mitbringen><en> However, newcomers with basic knowledge also get a chance with knowis, if they want to develop further and bring the necessary motivation for the job.
<G-vec00011-002-s423><bring_along.mitbringen><de> Aber auch Quereinsteiger mit Grundlagenkenntnis bekommen bei knowis eine Chance, wenn sie sich weiterentwickeln möchten und die erforderliche Motivation für den Beruf mitbringen.
<G-vec00011-002-s424><bring_along.mitbringen><en> You can bring your own bed linen and towels or rent them on site at an extra cost of EUR 5 for towels and EUR 5 for bed linen per person per stay.
<G-vec00011-002-s424><bring_along.mitbringen><de> Ankündigungen Sie können Ihre eigene Bettwäsche und Handtücher mitbringen oder diese in der Unterkunft für EUR 6 für Bettwäsche und EUR 6 für Handtücher pro Person und Aufenthalt mieten.
<G-vec00011-002-s425><bring_along.mitbringen><en> It is not allowed to bring pets.
<G-vec00011-002-s425><bring_along.mitbringen><de> Das Mitbringen von Haustieren ist nicht gestattet.
<G-vec00011-002-s426><bring_along.mitbringen><en> Hungary | With these holiday houses it is explicitely allowed to bring pets so that your faithful four legged friend can also enjoy a relaxing and eventful holiday.
<G-vec00011-002-s426><bring_along.mitbringen><de> Ungarn | Bei diesen Ferienhäusern ist das Mitbringen von Haustieren ausdrücklich erlaubt, so dass auch ihr treuer Vierbeiner in den Genuss von erholsamen und ereignisreichen Urlaubstagen kommt.
<G-vec00011-002-s427><bring_along.mitbringen><en> A gentle, flowing yoga class for those who bring a little or a lot of yoga experience.
<G-vec00011-002-s427><bring_along.mitbringen><de> Eine sanfte, fließende Yoga Klasse für all jene, die ein wenig oder viel Yoga Erfahrung mitbringen.
<G-vec00011-002-s428><bring_along.mitbringen><en> Players are not required to bring their PS4 controllers.
<G-vec00011-002-s428><bring_along.mitbringen><de> Spieler müssen ihre PS4 Kontroller nicht mitbringen.
<G-vec00011-002-s429><bring_along.mitbringen><en> Now it happened one day that he was going to a fair; so he asked his daughter, who was named Betta, what she would like him to bring her on his return. And she said, "Papa, if you love me, bring me half a hundredweight of Palermo sugar, and as much again of sweet almonds, with four to six bottles of scented water, and a little musk and amber, also forty pearls, two sapphires, a few garnets and rubies, with some gold thread, and above all a trough and a little silver trowel."
<G-vec00011-002-s429><bring_along.mitbringen><de> Als er nun einmal zu einer Messe reisen musste, fragte er seine Tochter, die Betta hieß, was er ihr mitbringen solle, worauf sie erwiderte: »Wenn du mich liebhast, Väterchen, so bringe mir einen halben Zentner Palermozucker, einen halben süße Mandeln, vier bis sechs Flaschen wohlriechendes Wasser, etwas Moschus und Ambra, ferner etwa vierzig Stück Perlen, zwei Saphire, einige Granaten und Rubine, etwas Goldgespinst, besonders aber einen Backtrog und Kratzmesser von Silber.« Der Vater wunderte sich zwar über diese etwas unbescheidene Forderung, wollte aber seiner Tochter nicht widersprechen, er reiste daher zur Messe ab und brachte ihr bei seiner Rückkehr ganz genau alles, was sie gewünscht.
<G-vec00011-002-s430><bring_along.mitbringen><en> The Client shall not be allowed to bring along food or drinks to events.
<G-vec00011-002-s430><bring_along.mitbringen><de> Der Kunde darf Speisen und Getränke zu Veranstaltungen grundsätzlich nicht mitbringen.
<G-vec00011-002-s431><bring_along.mitbringen><en> You can’t bring goods from endangered species (CITES) into Sweden at any time without special permit.
<G-vec00011-002-s431><bring_along.mitbringen><de> Ohne Sondergenehmigung können Sie zu keiner Zeit Güter gefährdeter Arten (CITES) nach Schweden mitbringen.
<G-vec00011-002-s432><bring_along.mitbringen><en> A rustic mason’s canteen provides an inviting resting place where you can also bring your own snack.
<G-vec00011-002-s432><bring_along.mitbringen><de> Eine zünftige Steinhauerkantine steht zur Verfügung, in der man auch seine eigene Brotzeit mitbringen kann.
<G-vec00011-002-s433><bring_along.mitbringen><en> Who is not a couple should eventually bring a second blanket.
<G-vec00011-002-s433><bring_along.mitbringen><de> Wer kein Paar ist, sollte eventuell eine zweite Bettdecke mitbringen.
<G-vec00011-002-s434><bring_along.mitbringen><en> Customs As a citizen of the EU or EEA, you can bring your private household possessions with you without any customs formalities.
<G-vec00011-002-s434><bring_along.mitbringen><de> Zoll Als EU- oder EWR-Bürger können Sie den privaten Hausrat ohne Zollformalitäten mitbringen.
<G-vec00011-002-s435><bring_along.mitbringen><en> In Lindy Hop besides the above, there are even two completely different formats, depending on your focus: In Lindy Intensive, you will be working on your technique intensively all day long for three days, and should bring with you the necessary attitude, energy and drive.
<G-vec00011-002-s435><bring_along.mitbringen><de> Im Lindy Hop haben wir sogar zwei völlig verschiedene Formate, je nachdem, wo du den Schwerpunkt legen möchtest: Im Lindy Intensive wirst du intensiv an deiner Technik arbeiten und solltest hierfür auch die Energie und den Ehrgeiz mitbringen.
<G-vec00011-002-s436><bring_along.mitbringen><en> Yes you can bring your own motorcycle, and it can be any make or model.
<G-vec00011-002-s436><bring_along.mitbringen><de> Selbstverständlich können Sie Ihr eigenes Motorrad mitbringen, egal welche Marke oder welches Modell.
<G-vec00011-002-s456><bring_along.mitbringen><en> Spyridon itself is very accommodating and has enabled me to bring my cat.
<G-vec00011-002-s456><bring_along.mitbringen><de> Spyridon selber ist sehr zuvorkommend und hat es mir ermöglicht meine Katze mitzubringen.
<G-vec00011-002-s457><bring_along.mitbringen><en> Seating is first-come, first-served, and movie-goers are encouraged to bring blankets or low lawn chairs.
<G-vec00011-002-s457><bring_along.mitbringen><de> Sitzen ist First-Come, First-Served, und Kinobesucher werden aufgefordert, Decken oder niedrige Liegestühle mitzubringen.
<G-vec00011-002-s458><bring_along.mitbringen><en> Then you scan (w… It is always possible to bring your own assemblies to the workshop to test the various measurement methods.
<G-vec00011-002-s458><bring_along.mitbringen><de> Es ist jederzeit möglich, eigene Baugruppen als Beispiel für die Anwendung des Messverfahrens zum Workshop mitzubringen.
<G-vec00011-002-s459><bring_along.mitbringen><en> If you wish to use your car during your stay, you are advised to bring snow chains or studded tires.
<G-vec00011-002-s459><bring_along.mitbringen><de> Wenn Sie während Ihres Aufenthaltes Ihr Auto nutzen möchten, wird Ihnen empfohlen, Schneeketten oder Reifen mit Spikes mitzubringen.
<G-vec00011-002-s460><bring_along.mitbringen><en> Equipment: cable TV; radio; internet access (please bring your own network cable) (included); iron/ironing board; gas central heating.
<G-vec00011-002-s460><bring_along.mitbringen><de> Einrichtung: Netzwerkkabel mitzubringen (inklusive); Bügeleisen/-brett; Gas-Zentralheizung.
<G-vec00011-002-s461><bring_along.mitbringen><en> Our dogs will still be here, so make sure you bring them some treats.
<G-vec00011-002-s461><bring_along.mitbringen><de> Unsere Hunde bleiben zuhause, also denkt dran ihnen ein paar Leckerlis mitzubringen.
<G-vec00011-002-s462><bring_along.mitbringen><en> Very often, juice and cake sellers are walking along the beach: by reason of hygiene we recommend that you rather go to the nearest cafe or that you bring your own food with you.
<G-vec00011-002-s462><bring_along.mitbringen><de> Sehr oft gehen an diesen Stränden Verkäufer vorbei, die Kuchen und Getränke anbieten: aus hygienischen Gründen raten wir Ihnen, lieber zum nächsten Cafe zu gehen, oder einfach ihr eigenes Essen mitzubringen.
<G-vec00011-002-s463><bring_along.mitbringen><en> We ask our guests to bring their own sleeping bag.
<G-vec00011-002-s463><bring_along.mitbringen><de> Die Gäste sind gebeten, den eigenen Schlafsack mitzubringen.
<G-vec00011-002-s464><bring_along.mitbringen><en> However, you do not need to bring towels or bed linen, as the apartments are fully equipped.
<G-vec00011-002-s464><bring_along.mitbringen><de> Sie brauchen keine Bettwäsche mitzubringen, da diese in der Ausstattung des Apartment eingeschlossen ist.
<G-vec00011-002-s465><bring_along.mitbringen><en> These helped us the basic equipment for cooking available (the chef happy but I would recommend some parts bring your own).
<G-vec00011-002-s465><bring_along.mitbringen><de> Dazu stand uns die basic Ausrüstung zum kochen zur Verfügung (den kochfreudigen würde ich jedoch empfehlen einige teile selbst mitzubringen).
<G-vec00011-002-s466><bring_along.mitbringen><en> Remember to bring a printed copy of your reservation request email to verify that you have paid the 10% deposit. Cancellation Policy
<G-vec00011-002-s466><bring_along.mitbringen><de> Vergessen Sie nicht die Kopie Ihres Reservationsantrages mitzubringen, damit Sie beweisen können, dass Sie eine 10% Anzahlung gemacht haben.
<G-vec00011-002-s467><bring_along.mitbringen><en> Don’t forget to bring your electronic devices and headphones to get connected.
<G-vec00011-002-s467><bring_along.mitbringen><de> Denken Sie daran, Ihre elektronischen Geräte und Kopfhörer mitzubringen, um sich zu verbinden.
<G-vec00011-002-s468><bring_along.mitbringen><en> This app is an excellent choice for interior designers and anyone who wishes to build or do some DIYs and are too lazy to bring a measuring tape with them.
<G-vec00011-002-s468><bring_along.mitbringen><de> Diese App ist eine ausgezeichnete Wahl für Innenarchitekten und alle, die etwas basteln oder basteln möchten und zu faul sind, um ein Maßband mitzubringen.
<G-vec00011-002-s469><bring_along.mitbringen><en> It would also be recommended to bring something new, something better than what the market is currently offering.
<G-vec00011-002-s469><bring_along.mitbringen><de> Es wäre auch empfehlenswert, etwas Neues mitzubringen, etwas Besseres als das, was der Markt derzeit anbietet.
<G-vec00011-002-s470><bring_along.mitbringen><en> The guests are asked to bring along something.
<G-vec00011-002-s470><bring_along.mitbringen><de> Die Gäste werden gebeten, etwas mitzubringen.
<G-vec00011-002-s471><bring_along.mitbringen><en> We provide each guest with ecologic soap and shampoo, which has cero environmental impact, very low froth production and is absorbed highly by the traps and filters residing at the mouths of each of our septic tanks; we prohibit the use of soaps, shampoos, rinses, creams and other none bio-degradable productcs, all which are confiscated and only returned to their owner prior to his leaving from the visitors centre, even though we ask all our guests not to bring them in the first place.
<G-vec00011-002-s471><bring_along.mitbringen><de> Wir geben jedem Gast oekologisch-umweltfreundliche Seife und Schampoo, welche keinen negativen Einfluss auf die Umwelt tragen, geringe Schaumbildung aufweisen und von den Filtern der Abortgruben in hohem Maasse absorbiert werden; wir verbieten jeglichen Gebrauch umweltschaedlicher Seifen, Schampoos, Hautkraemen und sonstige Produkte, welche beschlagnahmt und dem Besitzer erst am Tage seiner Abfahrt zurueck erstattet werden; wir empfehlen unseren Gaesten diese Produkte gar nicht erst mitzubringen.
<G-vec00011-002-s472><bring_along.mitbringen><en> We recommend that you bring appropriate equipment and book a guide.
<G-vec00011-002-s472><bring_along.mitbringen><de> Wir empfehlen Ihnen, entsprechende Ausrüstung mitzubringen und einen Führer zu buchen.
<G-vec00011-002-s473><bring_along.mitbringen><en> Participants are kindly requested to bring their own copies of documentation with them to the session.
<G-vec00011-002-s473><bring_along.mitbringen><de> Alle Teilnehmer werden freundlich gebeten, ihre Tagungsunterlagen selbst mitzubringen.
<G-vec00011-002-s474><bring_along.mitbringen><en> Policies Upon prior requests, guests will be allowed to bring pets into the property with additional conditions regarding size, number of pets, and days at the property.
<G-vec00011-002-s474><bring_along.mitbringen><de> Laut früherer Anfrage ist es Gästen gestattet Haustiere in die Unterkunft mitzubringen, sofern die Richtlinien bezüglich Größe, Anzahl und Aufenthaltslänge der Tiere eingehalten werden.
<G-vec00011-002-s437><bring_along.mitnehmen><en> The zenith has certainly not passed, but the industry also has to realise that growth can’t be forced, and in particular that you need to bring the consumer along on this path.
<G-vec00011-002-s437><bring_along.mitnehmen><de> Der Zenit ist sicherlich nicht überschritten, die Branche muss nur realisieren, dass man Wachstum nicht erzwingen kann und vor allem, dass man die Konsumenten auf diesem Weg mitnehmen muss.
<G-vec00011-002-s438><bring_along.mitnehmen><en> Well, for the simple reason that sending the books would cost a lot for Mervi but since she’s coming to Berlin in December she can bring the books with her.
<G-vec00011-002-s438><bring_along.mitnehmen><de> Nun, darauf gibt es eine einfache Antwort: Die Versendung der Bücher würde Mervi eine Menge kostren, da sie aber im Dezember nach Berlin kommen wird, kann sie die Bücher mitnehmen.
<G-vec00011-002-s439><bring_along.mitnehmen><en> You can bring sporting equipment and other items instead of a suitcase only if you have booked your flight in a fare that includes hold luggage (in this case sporting equipment is included in the free baggage allowance).
<G-vec00011-002-s439><bring_along.mitnehmen><de> Anstelle eines Koffers, können Sie auch Sportausrüstungen oder Gegenstände mitnehmen nur wenn Sie einen Flug in einem Tarif, der ein Aufgabegepäck inkludiert, gebucht haben.
<G-vec00011-002-s440><bring_along.mitnehmen><en> We recommend you bring sportswear and shoes and hiking boots with you.
<G-vec00011-002-s440><bring_along.mitnehmen><de> Empfehlenswert: Sportbekleidung, Sport- und Wanderschuhe mitnehmen.
<G-vec00011-002-s441><bring_along.mitnehmen><en> There are several kinds of lightweight purifiers you can bring on your trip.
<G-vec00011-002-s441><bring_along.mitnehmen><de> Es gibt mehrere leichte Wasserfilter, die du auf deinem Trip mitnehmen kannst.
<G-vec00011-002-s442><bring_along.mitnehmen><en> For visits to the towns of Menorca or field trips you will have to bring another type of footwear suitable for walking.
<G-vec00011-002-s442><bring_along.mitnehmen><de> Für Besuche in den Städten der Insel oder Ausflüge müsstet ihr andere Schuhe mitnehmen, die zum Laufen geeignet sind.
<G-vec00011-002-s443><bring_along.mitnehmen><en> The minimalistic and super light sweater is the ultimate insulation piece to bring along as it requires minimal space and keeps the weight down.
<G-vec00011-002-s443><bring_along.mitnehmen><de> Der minimalistische und extrem leichte Sweater ist das ultimative Isolationsteil zum Mitnehmen, da er kaum Platz benötigt und das Packgewicht nicht erhöht.
<G-vec00011-002-s444><bring_along.mitnehmen><en> Finally - and this is the main reason I would bring it to my island with me - it gets you consistently high time after time.
<G-vec00011-002-s444><bring_along.mitnehmen><de> Letztendlich ist der Grund warum ich sie auf meine Insel mitnehmen würde, dass sie einen jedes Mal konstant high macht.
<G-vec00011-002-s445><bring_along.mitnehmen><en> Sadly you cannot bring Agro with you to this fight because he doesn't like to jump down this kind of height and is also afraid of dark unknown waters.
<G-vec00011-002-s445><bring_along.mitnehmen><de> Leider kannst du Agro nicht mitnehmen, da dieser es nicht mag aus luftigen Höhen in unbekannte Gewässer mitsamt den darin lauernden Gefahren zu springen.
<G-vec00011-002-s446><bring_along.mitnehmen><en> Even though we are planning a vacation to Indonesia in October, I wouldn’t bring most of the summer clothes I have new in my wardrobe.
<G-vec00011-002-s446><bring_along.mitnehmen><de> Auch, wenn wir für den Oktober nochmal einen Sommerurlaub planen, so werde ich viele der Sommerkleidung nicht dorthin mitnehmen.
<G-vec00011-002-s447><bring_along.mitnehmen><en> You're allowed to bring a total of one liter, divided on ten 100ml bottles.
<G-vec00011-002-s447><bring_along.mitnehmen><de> Man darf insgesamt einen Liter mitnehmen, allerdings aufgeteilt in zehn 100ml Fläschchen.
<G-vec00011-002-s448><bring_along.mitnehmen><en> You can bring all the drinks you want to the camping ground.
<G-vec00011-002-s448><bring_along.mitnehmen><de> Auf den Zeltplatz kannst du alle Getränke mitnehmen, die du gerne dabeihaben magst.
<G-vec00011-002-s449><bring_along.mitnehmen><en> I will bring with me, in my heart, the impression of these days.
<G-vec00011-002-s449><bring_along.mitnehmen><de> Ich werde den Eindruck dieser Tage mitnehmen, in meinem Herzen behalten.
<G-vec00011-002-s450><bring_along.mitnehmen><en> An extra cushion or favorite blanket can be good to bring.
<G-vec00011-002-s450><bring_along.mitnehmen><de> Sie können auch ein zusätzliches Kissen oder die Lieblingsdecke mitnehmen.
<G-vec00011-002-s451><bring_along.mitnehmen><en> Weighing only 7.1 kg (15.7 lbs), the rugged S1 Pro lets you bring better sound to the party, BBQ or outdoor get-together.
<G-vec00011-002-s451><bring_along.mitnehmen><de> Mit seinen leichten 7,1 kg können Sie das robuste S1 Pro System überallhin mitnehmen, um auf jeder Party für einen noch besseren Klang zu sorgen.
<G-vec00011-002-s452><bring_along.mitnehmen><en> The supply lists for destinations on our website are provided directly by the local community-based projects that will receive them, enabling travelers to make informed decisions and bring items which meet the needs of the people who will be using them.
<G-vec00011-002-s452><bring_along.mitnehmen><de> Die Listen der Angebote der Ziele auf unserer Website werden direkt von den den lokalen Gemeinden, basierend auf deren Projekten, angeboten, was den Reisenden erlaubt informierte Entscheidungen darüber zu treffen, was Sie mitnehmen, das für die Menschen dort nützlich sein kann.
<G-vec00011-002-s453><bring_along.mitnehmen><en> The trekkers must bring their own ski equipment (a pair of skis, skiing boots) and adequate clothing.
<G-vec00011-002-s453><bring_along.mitnehmen><de> Die Teilnehmer der Expeditionen müßen ihre eigene Skiausrüstung mitnehmen (Skis, Skistiefel) und den geeigneten Anzug.
<G-vec00011-002-s454><bring_along.mitnehmen><en> It's a good idea to check with your local customs officials to ensure that you are able to bring certain items back into your home country.
<G-vec00011-002-s454><bring_along.mitnehmen><de> Vergewissere Dich bei örtlichen Zollbeamten, ob Du bestimmte Gegenstände in Dein Heimatland mitnehmen darfst.
<G-vec00011-002-s455><bring_along.mitnehmen><en> However if you would like to come on our longer Tours (3 and 4), you will need to bring your own cooking equipment, plates and cutlery.
<G-vec00011-002-s455><bring_along.mitnehmen><de> Wenn Sie jedoch eine unserer längeren Touren (3 oder 4) gewählt haben, sollten Sie lhr eigenes Kochzeug, Teller und Besteck mitnehmen.
<G-vec00011-002-s475><bring_along.mitnehmen><en> By definition it is a Holiday Home that can be towed, which means to bring the proper home on holiday.
<G-vec00011-002-s475><bring_along.mitnehmen><de> Per Definition handelt es sich um eine bewegliche Ferienwohnung und bietet daher die Möglichkeit, das eigene Zuhause in den Urlaub mitzunehmen.
<G-vec00011-002-s476><bring_along.mitnehmen><en> It may be fun to bring a friend.
<G-vec00011-002-s476><bring_along.mitnehmen><de> Es kann Spaß machen, eine Freundin mitzunehmen.
<G-vec00011-002-s477><bring_along.mitnehmen><en> If you have not used one before if might be a good idea to buy a few different types and bring them all with you.
<G-vec00011-002-s477><bring_along.mitnehmen><de> Falls du noch nie ein solches angewendet hast, wäre es wahrscheinlich empfehlenswert, verschiedene Modelle zu kaufen und sie alle mitzunehmen.
<G-vec00011-002-s478><bring_along.mitnehmen><en> Always remember to print the e-visa sent through email and bring it along when traveling.
<G-vec00011-002-s478><bring_along.mitnehmen><de> Denken Sie immer daran, das E-Visum per E-Mail zu drucken und es auf Reisen mitzunehmen.
<G-vec00011-002-s479><bring_along.mitnehmen><en> Remember to bring the printed proof of purchase.
<G-vec00011-002-s479><bring_along.mitnehmen><de> Empfehlungen Denken Sie daran, Ihr Ticket auszudrucken und mitzunehmen.
<G-vec00011-002-s480><bring_along.mitnehmen><en> Don’t forget to bring your favourite pair of headphones, as not all carriers offer headphones on the coach.
<G-vec00011-002-s480><bring_along.mitnehmen><de> Vergiss nicht, deine Lieblings-Kopfhörer mitzunehmen, nachdem nicht alle Anbieter Kopfhörer für den Bus anbieten.
<G-vec00011-002-s481><bring_along.mitnehmen><en> Don’t forget to obtain health and travel insurance, and please remember to bring enough medication to last the duration of your stay.
<G-vec00011-002-s481><bring_along.mitnehmen><de> Vergessen Sie auch nicht die Nachweise für Ihre Kranken- und Reiseversicherung, und denken Sie daran, für die Dauer Ihres Aufenthalts ausreichend Medikamente mitzunehmen.
<G-vec00011-002-s482><bring_along.mitnehmen><en> In order to ensure that your efforts and investments have sustainable positive results, we will help you bring your staff and your organisation on board, by actively shaping the change process.
<G-vec00011-002-s482><bring_along.mitnehmen><de> Damit sich Ihre Anstrengungen und Investitionen nachhaltig auszahlen, helfen wir Ihnen, Ihre Mitarbeiter und Ihre Organisation mitzunehmen, indem wir den Veränderungsprozess aktiv gestalten.
<G-vec00011-002-s483><bring_along.mitnehmen><en> Feel free to upload as many products as you want, post as many videos and images as needed and bring in all the traffic you require.
<G-vec00011-002-s483><bring_along.mitnehmen><de> Zögern Sie nicht, so viele Produkte wie Sie möchten hochzuladen, so viele Videos und Bilder wie nötig zu posten und den gesamten Traffic mitzunehmen, den Sie benötigen.
<G-vec00011-002-s484><bring_along.mitnehmen><en> Recommended equipment: Backpack with water bottle, extra clothing, camera, sunglasses; guide will bring necessary safety equipment
<G-vec00011-002-s484><bring_along.mitnehmen><de> Hinweis: Wir empfehlen für den Ausflug einen Rucksack mitzunehmen mit Wasserflasche, Wechselkleidung, Kamera und Sonnenbrille.
<G-vec00011-002-s485><bring_along.mitnehmen><en> Do not forget to bring bicycles with you: the Valsugana cycle starts at about 300 meters from the area and is also practicable by younger children as it does not present great difficulties.
<G-vec00011-002-s485><bring_along.mitnehmen><de> Vergessen Sie nicht, Fahrräder mitzunehmen: Der Valsugana-Radweg beginnt etwa 300 m von der Umgebung entfernt und ist auch für jüngere Kinder praktikabel, da er keine großen Schwierigkeiten bereitet.
<G-vec00011-002-s486><bring_along.mitnehmen><en> But my girlie has today Christmas celebration in class and the teacher asked all the children to bring cookies.
<G-vec00011-002-s486><bring_along.mitnehmen><de> Aber das Töchterlein hat heute Weihnachtsfeier in der Klasse und die Lehrerin bat alle Kinder, Kekse mitzunehmen.
<G-vec00011-002-s487><bring_along.mitnehmen><en> 14The disciples had forgotten to bring enough bread and had only one loaf with them in the boat.
<G-vec00011-002-s487><bring_along.mitnehmen><de> 14Und sie vergaßen Brote mitzunehmen, und hatten nichts bei sich auf dem Schiffe als nur ein Brot.
<G-vec00011-002-s488><bring_along.mitnehmen><en> We advise you to bring bikes with you, as there will be no shortage of opportunities for using them on the ultra-long cycle tracks along the way, which are also safe for children.
<G-vec00011-002-s488><bring_along.mitnehmen><de> Wir empfehlen, Ihre Fahrräder mitzunehmen, denn sie werden zahlreiche Gelegenheiten haben, diese auf den langen kindersicheren Fahrradwegen zu nutzen.
<G-vec00011-002-s489><bring_along.mitnehmen><en> We will make at least one longer stop during the trip; we recommend you bring along a hot beverage and something to eat.
<G-vec00011-002-s489><bring_along.mitnehmen><de> Während der Tour machen wir wenigstens eine längere Pause, wir empfehlen Ihnen ein heißes Getränk und einige Snacks mitzunehmen.
<G-vec00011-002-s490><bring_along.mitnehmen><en> That didn't only give Shinji the possibility to bring a romantic movie that they had at home, but he also didn't have to go there and change the reels several times.
<G-vec00011-002-s490><bring_along.mitnehmen><de> Das gab Shinji nicht nur die Möglichkeit einen romantischen Film von Zuhause mitzunehmen, sondern er würde nicht des Öfteren hochgehen müssen, um die Filmrollen zu wechseln.
<G-vec00011-002-s491><bring_along.mitnehmen><en> They provide life jackets in the room so remember bring along with you.
<G-vec00011-002-s491><bring_along.mitnehmen><de> Schwimmwesten gibt es leihweise im Zimmer, man muss nur daran denken, sie mitzunehmen.
<G-vec00011-002-s492><bring_along.mitnehmen><en> Remember to bring dishes and everything else you need for cooking.
<G-vec00011-002-s492><bring_along.mitnehmen><de> Vergessen Sie nicht, genug Geschirr und die nötigsten Küchenutensilien mitzunehmen.
<G-vec00011-002-s493><bring_along.mitnehmen><en> We kindly ask our guests not to bring or eat food bought elsewhere into the territory of the hotel.
<G-vec00011-002-s493><bring_along.mitnehmen><de> Wir bitten unsere Gäste die außer Haus gekauften Lebensmittel und Getränke nicht ins Hotelareal mitzunehmen und zu konsumieren.
<G-vec00011-002-s494><bring_along.nehmen><en> I plan to bring my family to Prague so that we will have a vacation time after the convention.
<G-vec00011-002-s494><bring_along.nehmen><de> Ich will meine Familie mit zur Veranstaltung in Beverly Hills nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00011-002-s495><bring_along.nehmen><en> In this case, please report to the IT support services directly and bring identification with you.
<G-vec00011-002-s495><bring_along.nehmen><de> Wenden Sie sich dafür persönlich an den IT-Support und nehmen Sie zwecks eindeutiger Identifikation einen Ausweis mit.
<G-vec00011-002-s496><bring_along.nehmen><en> The parents left you to decide what to bring and which foods to eat.
<G-vec00011-002-s496><bring_along.nehmen><de> Die Eltern wollen dass Sie entscheiden was zu nehmen und welche Lebensmittel zu essen.
<G-vec00011-002-s497><bring_along.nehmen><en> You may bring your own food on board if you follow the safety regulation with regard to carry-on baggage.
<G-vec00011-002-s497><bring_along.nehmen><de> Sie können Ihre eigene Verpflegung mit an Bord nehmen, wenn Sie die Sicherheitsbestimmungen für Handgepäck befolgen.
<G-vec00011-002-s498><bring_along.nehmen><en> I plan to bring my family to Sydney so that we will have a vacation time after the conference.
<G-vec00011-002-s498><bring_along.nehmen><de> Ich will meine Familie mit zur Veranstaltung in Miami nehmen, sodass wir nach der Konferenz noch ein wenig Zeit zusammen verbringen können.
<G-vec00011-002-s499><bring_along.nehmen><en> Bring your swimsuit; A Victory Inn & Suites Phoenix North has an outdoor swimming pool.
<G-vec00011-002-s499><bring_along.nehmen><de> Nehmen Sie ein Bad im Pool, Sie werden sicherlich mögen, dass das A Victory Inn & Suites Phoenix North ein Außenpool hat.
<G-vec00011-002-s500><bring_along.nehmen><en> Bring it anywhere: the elegant finish in brushed metal makes it an elegant and classy accessory.
<G-vec00011-002-s500><bring_along.nehmen><de> Nehmen Sie ihn überall mit hin: Die elegante Oberfläche aus gebürstetem Metall macht ihn zu einem edlen und stilvollen Accessoire.
<G-vec00011-002-s501><bring_along.nehmen><en> Bring your iPhone with you.
<G-vec00011-002-s501><bring_along.nehmen><de> Nehmen Sie Ihr iPhone mit.
<G-vec00011-002-s502><bring_along.nehmen><en> In most countries, the transit authorities allow you to bring food through the security screening and on board.
<G-vec00011-002-s502><bring_along.nehmen><de> Essen, welches die Bordsecurity erlaubt In den meisten Ländern erlaubt einem das Sicherheitspersonal, Essen durch die Kontrolle mit an Bord zu nehmen.
<G-vec00011-002-s503><bring_along.nehmen><en> Bring your iPhone along to see pace and distance.
<G-vec00011-002-s503><bring_along.nehmen><de> Nehmen Sie Ihr iPhone mit, um Geschwindigkeit und zurückgelegte Strecke zu messen.
<G-vec00011-002-s504><bring_along.nehmen><en> When we bring our testosterone levels to a high level, the performance of the testosterone is enhanced.
<G-vec00011-002-s504><bring_along.nehmen><de> Wenn wir unsere Testosteronspiegel zu einem hochrangigen Zustand nehmen, werden die oben genannten Merkmale des Testosteronhormons erhöht.
<G-vec00011-002-s505><bring_along.nehmen><en> Bring yourself to do this 3-day private paddle surf course in one of the beaches of Gran Canaria.
<G-vec00011-002-s505><bring_along.nehmen><de> Nehmen Sie an diesem 3-tägigen privaten Paddel-Surfkurs an einem der Strände von Gran Canaria teil.
<G-vec00011-002-s506><bring_along.nehmen><en> Bring as much as you can in your hand luggage, but cut all your barriers to the right size before you fly (at least those you will be carrying in your hand luggage), since you will not always be allowed to bring scissors in your hand luggage.
<G-vec00011-002-s506><bring_along.nehmen><de> Nehmen Sie so viel wie möglich in Ihrem Handgepäck mit, aber schneiden Sie jeden Hautschutz vor dem Flug auf die richtige Größe zu (zumindest diejenigen im Handgepäck), da Scheren im Handgepäck nicht immer erlaubt sind.
<G-vec00011-002-s507><bring_along.nehmen><en> The taste of a holiday at the White Horse Inn can be enjoyed everywhere: with the homemade goods of the White Horse Inn you can bring a slice of Austria back home with you and enjoy traditional Austrian cuisine in your own home.
<G-vec00011-002-s507><bring_along.nehmen><de> Rössl Spezialitäten Den Geschmack eines Urlaubs im Hotel Weisses Rössl können Sie nicht nur in St. Wolfgang genießen: Nehmen Sie aus dem Rössl-Shop Hausgemachtes mit – ein Souvenir aus Ihrem Österreich-Urlaub, das den Daheimgebliebenen Freude bereitet.
<G-vec00011-002-s508><bring_along.nehmen><en> Oxea has also announced plans to bring its sixth world-scale carboxylic acids production plant on stream in 2021.
<G-vec00011-002-s508><bring_along.nehmen><de> Zudem plant das Unternehmen, im Jahr 2021 seine sechste Großanlage zur Herstellung von Carbonsäuren in Betrieb zu nehmen.
<G-vec00011-002-s509><bring_along.nehmen><en> Then bring the ball down across your body to your right hip, bending your elbows, again without rotating your head or chest.
<G-vec00011-002-s509><bring_along.nehmen><de> Nehmen Sie ihre rechte Hand an die rechte Hüfte, oder legen Sie den Arm gerade rechts am Körper einfach ab.
<G-vec00011-002-s510><bring_along.nehmen><en> Bring SmartCharge with you wherever you go.
<G-vec00011-002-s510><bring_along.nehmen><de> Nehmen Sie SmartCharge mit.
<G-vec00011-002-s511><bring_along.nehmen><en> To bring your Guide Dog into the cabin, please download and fill out the Application Form Guide Dog and send the completed form to KLMCARES@KLM.com.
<G-vec00011-002-s511><bring_along.nehmen><de> Um Ihren Blindenhund mit in die Kabine zu nehmen, laden Sie bitte das Antragsformular Blindenhund herunter und füllen Sie es aus und senden dieses ausgefüllt anKLMCARES@klm.com.
<G-vec00011-002-s512><bring_along.nehmen><en> Bring them ALL safely.
<G-vec00011-002-s512><bring_along.nehmen><de> Nehmen Sie einfach alle mit.
<G-vec00011-002-s589><bring_along.tragen><en> The German-American Institute (DAI), an institution of cultural life in Heidelberg that is widely renowned in Germany, seeks to bring new impulses to Heidelberg’s civil society with an open forum for the discussion of socially interesting questions.
<G-vec00011-002-s589><bring_along.tragen><de> IBA-Kuratorium Das Deutsch-Amerikanische Institut (DAI), eine nicht nur bundesweit beachtete Institution des kulturellen Lebens in Heidelberg, will mit einem offenen Forum für den Diskurs gesellschaftlich interessanter Fragen neue Impulse in die Heidelberger Zivilgesellschaft tragen.
<G-vec00011-002-s590><bring_along.tragen><en> It’s a non-profit organisation aimed at taking all of the academic work that takes place in robot applications and trying to bring that to the public domain, to raise awareness of both the general public and policy makers.
<G-vec00011-002-s590><bring_along.tragen><de> Eine gemeinnützige Organisation, die darauf abzielt, die gesamte akademische Arbeit im Bereich der Roboteranwendungen nach außen zu tragen und so das Bewusstsein der Öffentlichkeit und der politischen Entscheidungsträger dafür zu stärken.
<G-vec00011-002-s591><bring_along.tragen><en> The parents proudly bring these positive experiences to the company.
<G-vec00011-002-s591><bring_along.tragen><de> Die Eltern tragen diese positiven Erfahrungen stolz in den Betrieb.
<G-vec00011-002-s592><bring_along.tragen><en> We bring that attitude with us out into the world.
<G-vec00011-002-s592><bring_along.tragen><de> Diese Einstellung tragen wir in die Welt hinaus.
<G-vec00011-002-s593><bring_along.tragen><en> As the main sponsor since 2014, we have helped bring unforgettable athletics moments to this Italian-speaking region of Switzerland. Visit website
<G-vec00011-002-s593><bring_along.tragen><de> Seit 2014 tragen wir als Hauptsponsorin dazu bei, dieser Region in der italienischsprachigen Schweiz unvergessliche sportliche Momente zu bereiten.
<G-vec00011-002-s594><bring_along.tragen><en> The idea to bring the film from the streets to the streets was not an easy task.
<G-vec00011-002-s594><bring_along.tragen><de> Die Idee, den Film von der Straße auf die Straße zu tragen gestaltete sich nicht ganz einfach.
<G-vec00011-002-s595><bring_along.tragen><en> The mountains bring forth grass for him; all the beasts of the field will play there.
<G-vec00011-002-s595><bring_along.tragen><de> 20 Die Berge tragen Futter für ihn, und alle wilden Tiere spielen dort.
<G-vec00011-002-s596><bring_along.tragen><en> You ultimately learn how to gain from your interior strength to then be able to bring this experience in your everyday life.
<G-vec00011-002-s596><bring_along.tragen><de> Man lernt aus der eigenen inneren Kraft zu schöpfen, um danach diese Erfahrung in den Alltag zu tragen.
<G-vec00011-002-s597><bring_along.tragen><en> 40:20 Surely the mountains bring him forth food, where all the beasts of the field play.
<G-vec00011-002-s597><bring_along.tragen><de> 40:20 Doch die Berge tragen ihm Futter zu / und alle Tiere des Feldes spielen dort.
<G-vec00011-002-s598><bring_along.tragen><en> The level of LDL (Low Density Lipoprotein), which bring the cholesterol to the tissues, increases in the presence of an excess of the latter.
<G-vec00011-002-s598><bring_along.tragen><de> Die Anzahl der LDL (Low Density Lipoprotein), die das Cholesterin ins Gewebe tragen, erhöht einen Überschuss des letzteren.
<G-vec00011-002-s599><bring_along.tragen><en> Also, between June and September, bring everything you need to protect yourself from the sun and heat.
<G-vec00011-002-s599><bring_along.tragen><de> Zwischen Juni und September sollten Sie so viel wie möglich zum Schutz gegen die Sonne und die Hitze tragen.
<G-vec00011-002-s600><bring_along.tragen><en> High Technologies Park programmers receive at least $1000 a month, while on average $2000, and they bring such a valuable foreign currency in the country.
<G-vec00011-002-s600><bring_along.tragen><de> High-Tech Park-Programmierer erhalten mindestens 850 € pro Monat und durchschnittlich 1700 € und somit tragen sie eine wertvolle Fremdwährung ins Land.
<G-vec00011-002-s601><bring_along.tragen><en> Because you have considerable inner tension between your security needs and the more romantic and idealistic side of your nature, you are likely to bring a certain amount of conflict into your relationship with Brad simply because you are torn between reality and your dream of love.
<G-vec00011-002-s601><bring_along.tragen><de> Zwischen Ihren Sicherheitsbedürfnissen und der eher romantischen und idealistischen Seite Ihres Wesens besteht eine beträchtliche innere Spannung, und so tragen Sie wahrscheinlich gewisse Konflikte in die Beziehung zu Brad hinein - einfach deshalb, weil Sie zwischen der Wirklichkeit und Ihrem Traum von der Liebe hin- und hergerissen sind.
<G-vec00011-002-s602><bring_along.tragen><en> Our Lord’s hands, extended on the Cross, also invite us to contemplate our participation in his eternal priesthood and thus our responsibility, as members of his body, to bring the reconciling power of his sacrifice to the world in which we live.
<G-vec00011-002-s602><bring_along.tragen><de> Die am Kreuz ausgestreckten Hände unseres Herrn laden uns auch ein, unsere Teilhabe an seinem ewigen Priestertum zu betrachten und von da her unsere Verantwortung zu sehen, als Glieder seines Leibes die versöhnende Kraft seines Opfers in die Welt zu tragen, in der wir leben.
<G-vec00011-002-s603><bring_along.tragen><en> However, children also serve as multipliers when they bring their knowledge back to their communities and are especially suited to serve as ‘climate ambassadors’.
<G-vec00011-002-s603><bring_along.tragen><de> Kinder gelten aber auch als Multiplikatoren, wenn sie ihr Wissen in ihre Heimatgemeinden tragen und sind als sogenannte Klimabotschafter besonders geeignet.
<G-vec00011-002-s604><bring_along.tragen><en> Many culture professionals and academics around the world have got in touch with us via our model and bring their findings to bear in their own societies back at home.
<G-vec00011-002-s604><bring_along.tragen><de> Viele Kulturschaffende und Wissenschaftler in der Welt knüpfen über unser Modell Kontakt zu uns und tragen die gewonnenen Erkenntnisse dann wiederum nach Hause in die eigene Gesellschaft.
<G-vec00011-002-s605><bring_along.tragen><en> 92:14 They shall still bring forth fruit in old age; they shall be fat and flourishing;
<G-vec00011-002-s605><bring_along.tragen><de> Ps 92,15 Noch im hohen Alter wird er Frucht tragen, immer ist er kraftvoll und frisch.
<G-vec00011-002-s606><bring_along.tragen><en> Truly, the seed, the talent, the grace of God is there, and man has simply to work, take the seeds to bring them to the bankers.
<G-vec00011-002-s606><bring_along.tragen><de> Es ist wahr, den Samen, das Talent, die Gnade gibt der liebe Gott, und der Mensch hat bloß die Arbeit, den Samen aufzunehmen, das Geld zu Wechslern zu tragen.
<G-vec00011-002-s607><bring_along.tragen><en> That is why, we, former prisoners of concentration camps and ghettos should bring alive the memory of those tragic days as we were witnesses of the destruction of the Jewish people.
<G-vec00011-002-s607><bring_along.tragen><de> Deswegen sollen wir, die ehemaligen Häftlinge der Konzentrationslager und Ghettos, als Zeugen der Vernichtung des jüdischen Volks die lebendige Erinnerung der tragischen Tage tragen.
<G-vec00011-002-s627><bring_along.zurückbringen><en> Remember: if you bring back any duty-free goods you bought when you travelled out from Ireland, these count as part of your allowance.
<G-vec00011-002-s627><bring_along.zurückbringen><de> Nicht vergessen: Wenn Sie zollfreie Waren zurückbringen, die Sie gekauft haben, als Sie Irland verlassen haben, zählen diese zu Ihrer Zollbefreiung.
<G-vec00011-002-s628><bring_along.zurückbringen><en> Deliver him into my keeping, and I will bring him back to you.
<G-vec00011-002-s628><bring_along.zurückbringen><de> Gib ihn in meine Hand, und ich werde ihn zu dir zurückbringen.
<G-vec00011-002-s629><bring_along.zurückbringen><en> During this time the students can pick up the equipment they need for their projects and also bring back the tools they no longer need.
<G-vec00011-002-s629><bring_along.zurückbringen><de> Während dieser Zeit können die Studierenden die für ihr Projekt notwendige Ausrüstung abholen und zurückbringen.
<G-vec00011-002-s630><bring_along.zurückbringen><en> Shopping: you can bring back superb masks, wooden statues, colorful jewelry.
<G-vec00011-002-s630><bring_along.zurückbringen><de> Einkaufen: Sie können hervorragende Masken, hölzerne Statuen, bunte Schmuckstücke zurückbringen.
<G-vec00011-002-s631><bring_along.zurückbringen><en> But if we bring that closer to ignorance, it is because we believe that when the heart is not ready enough, sometimes some teachings come and do not settle until the day the Lord will speak again.
<G-vec00011-002-s631><bring_along.zurückbringen><de> Aber wenn wir dies zur Unwissenheit zurückbringen, dann deshalb, weil wir uns selbst sagen, dass, wenn das Herz nicht genug vorbereitet ist, manchmal bestimmte Lehren kommen und sich nicht niederlassen, bis zu dem Tag, an dem der Herr noch sprechen wird.
<G-vec00011-002-s632><bring_along.zurückbringen><en> Furthermore, we like to bring back some 80’s style with our retro jackets in which you can really make a statement.
<G-vec00011-002-s632><bring_along.zurückbringen><de> Außerdem möchten wir mit unseren Retrojacken den Stil der 80er Jahre zurückbringen.
<G-vec00011-002-s633><bring_along.zurückbringen><en> Because we come pick you up and bring you back home it doesn t really matter where you wish to stay in Amed.
<G-vec00011-002-s633><bring_along.zurückbringen><de> Weil wir Sie vom Hotel abholen und wieder nach Hause zurückbringen, ist es egal wo in Amed Sie übernachten moechten.
<G-vec00011-002-s634><bring_along.zurückbringen><en> Now be aware and consider what word I shall bring again to him that sent me.
<G-vec00011-002-s634><bring_along.zurückbringen><de> Nun wisse und sieh, was für eine Antwort ich dem zurückbringen soll, der mich gesandt hat.
<G-vec00011-002-s635><bring_along.zurückbringen><en> I bring him not to thee: deliver him into my hand, and I will
<G-vec00011-002-s635><bring_along.zurückbringen><de> Gieb ihn in meine Hand und ich werde ihn zu dir zurückbringen.
<G-vec00011-002-s636><bring_along.zurückbringen><en> I wonder if a hypnotist could bring the memory back.
<G-vec00011-002-s636><bring_along.zurückbringen><de> Ich frage mich ob ein Hypnotiseur mir die Erinnerung zurückbringen könnte.
<G-vec00011-002-s637><bring_along.zurückbringen><en> In other words, David seemed to be saying that he would see his baby son (in heaven), though he could not bring him back.
<G-vec00011-002-s637><bring_along.zurückbringen><de> Mit anderen Worten: David wollte wohl sagen, dass er das Kind (im Himmel) wiedersehen würde, obwohl er es nicht zurückbringen konnte.
<G-vec00011-002-s638><bring_along.zurückbringen><en> 23:4 If you meet yours enemy's ox or his ass going astray, you shall surely bring it back to him again.
<G-vec00011-002-s638><bring_along.zurückbringen><de> 23:4 Wenn du den Ochsen deines Feindes oder seinen Esel umherirrend antriffst, sollst du ihn demselben jedenfalls zurückbringen.
<G-vec00011-002-s639><bring_along.zurückbringen><en> The relations of Russia and Syria are not new, we will try to bring them back to the previous level”, said the opposition leader.
<G-vec00011-002-s639><bring_along.zurückbringen><de> Die Beziehungen zwischen Russland und Syrien sind nicht neu, und wir versuchen, sie auf das vorherige Niveau zurückbringen», sagte der Oppositionsführer .
<G-vec00011-002-s640><bring_along.zurückbringen><en> At the end of the rental period you can bring the sets back to us or send them to us.
<G-vec00011-002-s640><bring_along.zurückbringen><de> Am Ende der Mietzeit können Sie die Sets zu uns zurückbringen oder uns zusenden.
<G-vec00011-002-s641><bring_along.zurückbringen><en> Due to our cost-per-click pricing model you still only pay for the users that we were able to bring back to the site.
<G-vec00011-002-s641><bring_along.zurückbringen><de> Da unsere Preisgestaltung auf dem CPC-Modell basiert, zahlen Sie nur für die Nutzer, die wir tatsächlich auf Ihre Seite zurückbringen.
<G-vec00011-002-s642><bring_along.zurückbringen><en> It is also this originality that will allow your brand to stay in the mind of your audience and bring them back to your platforms.
<G-vec00011-002-s642><bring_along.zurückbringen><de> Durch diese Originalität wird Ihre Marke im Gedächtnis Ihrer Zielgruppe bleiben und sie auf Ihre Plattformen zurückbringen.
<G-vec00011-002-s643><bring_along.zurückbringen><en> This strain will take you back in time and will bring back memories of smoking the original white widow.
<G-vec00011-002-s643><bring_along.zurückbringen><de> Diese Sorte wird Sie in die Vergangenheit zurückversetzen und Erinnerungen an das Rauchen der ursprünglichen White Widow zurückbringen.
<G-vec00011-002-s644><bring_along.zurückbringen><en> To be honest, it was all right with me to bring back the child, because during the climbing I got ill, again.
<G-vec00011-002-s644><bring_along.zurückbringen><de> Ehrlich gesagt, mir war es ganz recht, dass ich das Kind zurückbringen musste, denn mir war beim Aufstieg schon wieder übel.
<G-vec00011-002-s645><bring_along.zurückbringen><en> Maybe the sounds and smells bring back memories of bad experiences as a child, or make you think that having treatment will hurt.
<G-vec00011-002-s645><bring_along.zurückbringen><de> Vielleicht sind es die Geräusche und Gerüche, die unangenehme Kindheitserinnerungen zurückbringen, oder mit denen man eine schmerzhafte Behandlung assoziiert.
