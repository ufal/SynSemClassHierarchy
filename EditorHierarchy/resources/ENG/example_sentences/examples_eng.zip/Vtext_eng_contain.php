<G-vec00366-002-s019><contain.aufweisen><en> The dietary proteins primarily selected here contain a high amount of BCAA. 4.
<G-vec00366-002-s019><contain.aufweisen><de> Hier werden vor allem Nahrungsproteine ausgewählt, die einen hohen Anteil an BCAA aufweisen.
<G-vec00366-002-s020><contain.aufweisen><en> Verify that the homepage and the sub-pages contain an appropriate description (a short and incisive sentence).
<G-vec00366-002-s020><contain.aufweisen><de> Kontrollieren Sie, ob die Startseite und die Folgeseiten eine angemessene Description (ein kurzer, aussagekräftiger Satz) aufweisen.
<G-vec00366-002-s021><contain.aufweisen><en> The word tourmaline means “multicolored stone” and sometimes a single stone may contain several different colors per se.
<G-vec00366-002-s021><contain.aufweisen><de> Das Wort Turmalin bedeutet „bunter Stein“; ein einzelner Stein kann manchmal mehrere Farben aufweisen.
<G-vec00366-002-s022><contain.aufweisen><en> The name can contain letters and numbers and can be at most 80 characters long.
<G-vec00366-002-s022><contain.aufweisen><de> Der Name kann eine maximale Länge von 80 Zeichen aufweisen und aus Buchstaben und Ziffern bestehen.
<G-vec00366-002-s023><contain.aufweisen><en> In other sectors, EU legislation could contain less detailed provisions enshrined in basic texts and thus be more flexible if, on the basis of framework legislation, the Commission’s competence to enact implementing measures through faster procedures was recognised.
<G-vec00366-002-s023><contain.aufweisen><de> In anderen Sektoren könnte das EU-Recht weniger ausführliche Bestimmungen in grundlegenden Texten aufweisen und damit flexibler werden, wenn auf der Grundlage von Rahmenrechtsakten die Zuständigkeit der Kommission, Umsetzungsmaßnahmen durch schnellere Verfahren vorzusehen, anerkannt würde.
<G-vec00366-002-s024><contain.aufweisen><en> In a third step the indication means will be detected with a sensor to determine which of the items are already clean enough and which of the items contain still dirt, which needs to be removed.
<G-vec00366-002-s024><contain.aufweisen><de> In einem dritten Schritt werden die Markierungsmittel mittels einer Detektionsvorrichtung erkannt; zur Bestimmung, welche der zu reinigenden Gegenstände ausreichend sauber sind und welche noch zu entfernende Verunreinigungen aufweisen.
<G-vec00366-002-s025><contain.aufweisen><en> In contrast to jams, compotes have to contain a minimum of 65% fruit.
<G-vec00366-002-s025><contain.aufweisen><de> Kompotte müssen im Gegensatz zu Konfitüren und Marmeladen einen Mindestfruchtgehalt von 65% aufweisen.
<G-vec00366-002-s026><contain.aufweisen><en> Gold powder was applied to all the illuminations that contain it in the original.
<G-vec00366-002-s026><contain.aufweisen><de> Goldpulver ist auf alle Illuminationen aufgetragen worden, die auch im Original Goldpulver aufweisen.
<G-vec00366-002-s027><contain.aufweisen><en> Products may be declared gluten free if they contain no more than 20 mg gluten per kg.
<G-vec00366-002-s027><contain.aufweisen><de> Als glutenfrei dürfen Produkte deklariert werden, die höchstens 20 mg Gluten pro kg aufweisen.
<G-vec00366-002-s028><contain.aufweisen><en> Links to Third Party Websites Our site may, from time to time, contain links to and from the websites belonging to our partner networks, advertisers and affiliates.
<G-vec00366-002-s028><contain.aufweisen><de> Unsere Webseite kann zwischenzeitlich Links zu den Webseiten unserer Konzerngesellschaften, ausgewählten Partner-Netzwerken, Werbekunden und verbundenen Unternehmen aufweisen und kann von deren Webseiten aus verlinkt werden.
<G-vec00366-002-s029><contain.aufweisen><en> To add other types of placeholders that contain content such as pictures, clip art, SmartArt graphics, charts, movies, sounds, and tables, on the Slide Master tab, in the Master Layout group, click the type of placeholder that you want to add.
<G-vec00366-002-s029><contain.aufweisen><de> Wenn Sie andere Platzhaltertypen hinzufügen möchten, die Inhalte wie Bilder, ClipArt, SmartArt-Grafiken, Diagramme, Filme, Sounds und Tabellen aufweisen, klicken Sie auf der Registerkarte Folienmaster in der Gruppe Masterlayout auf den hinzuzufügenden Platzhaltertyp.
<G-vec00366-002-s030><contain.aufweisen><en> Scientists have discovered that these regions each contain unique types of stem cells and progenitor cells.
<G-vec00366-002-s030><contain.aufweisen><de> Forscher haben herausgefunden, dass beide dieser Lungenregionen einzigartige Typen von Stammzellen und Vorläuferzellen aufweisen.
<G-vec00366-002-s031><contain.aufweisen><en> Because these peels contain a high sugar content because of the drying process, this causes a second fermentation.
<G-vec00366-002-s031><contain.aufweisen><de> Da diese Schalen aufgrund des Trocknungsprozesses einen hohen Zuckergehalt aufweisen, führt dies zu einer zweiten Gärung.
<G-vec00366-002-s032><contain.aufweisen><en> Standard cannabis flowers contain between 15–30% THC, depending on the strain, how they were grown, etc. Cannabis concentrates, on the other hand, can contain THC levels of well over 60%.
<G-vec00366-002-s032><contain.aufweisen><de> Normale Cannabisblüten enthalten – je nach Sorte, Anbauart und weiteren Faktoren – zwischen 15 und 30% THC, während Cannabiskonzentrate einen THC-Gehalt von weit über 60% aufweisen können.
<G-vec00366-002-s033><contain.aufweisen><en> This means that the range of the player has to contain more than only two opposing hand strengths.
<G-vec00366-002-s033><contain.aufweisen><de> Das bedeutet, dass der Spieler in der eigenen Range mehr als zwei entgegengesetzte Handstärken aufweisen kann.
<G-vec00366-002-s034><contain.aufweisen><en> Delivered items are to be accepted by the Buyer even if they contain minor faults and irrespective of his rights stated in Section 5.
<G-vec00366-002-s034><contain.aufweisen><de> Angelieferte Gegenstände sind, auch wenn sie unwesentliche Mängel aufweisen, vom Besteller unbeschadet seiner Rechte aus Ziffer 5 entgegenzunehmen.
<G-vec00366-002-s035><contain.aufweisen><en> Our sites may contain content which was not created by the operator itself.
<G-vec00366-002-s035><contain.aufweisen><de> Unsere Seiten können Inhalte aufweisen, die nicht vom Betreiber selbst erstellt wurden.
<G-vec00366-002-s036><contain.aufweisen><en> Oils are the true gold standard of skin care, mostly because they contain potent ingredients and optimum moisturizing properties.
<G-vec00366-002-s036><contain.aufweisen><de> Öle sind wirklich das Nonplusultra der Hautpflege, weil sie wirkungsvolle Inhaltsstoffe und feuchtigkeitsspendende Eigenschaften aufweisen.
<G-vec00366-002-s037><contain.aufweisen><en> The upper surface of the sub base should not contain any sharp objects that could damage the shock pad or the backing of the artificial grass carpet.
<G-vec00366-002-s037><contain.aufweisen><de> Die Oberfl äche der Tragschicht sollte keine spitzen und scharfen Bestandteile aufweisen, welche die Elastikschicht oder den Rücken des Kunstrasenbelages beschädigen könnten.
<G-vec00366-002-s057><contain.befinden><en> Should these linked websites contain content that is illegal or that otherwise violates good moral standards, Lyoness shall expressly distance itself from said content.
<G-vec00366-002-s057><contain.befinden><de> Sollten sich auf den verlinkten Webseiten rechtswidrige oder sonst gegen die guten Sitten verstoßende Inhalte befinden, so distanziert sich Lyoness ausdrücklich davon.
<G-vec00366-002-s058><contain.befinden><en> Apartamentos Casa Appointments: These two houses, Vidal 1 and Vidal 2, contain apartments of different sizes.
<G-vec00366-002-s058><contain.befinden><de> Ausstattung: In diesen beiden Häusern, Vidal 1 und Vidal 2, befinden sich Apartments von verschiedener Größe.
<G-vec00366-002-s059><contain.befinden><en> If the doctor accidentally takes home the device, which may also contain sensitive data, patient data protection is no longer guaranteed.
<G-vec00366-002-s059><contain.befinden><de> Wenn der Arzt das Gerät – auf dem sich unter Umständen auch sensible Daten befinden können – versehentlich mit nach Hause nimmt, ist der Datenschutz schon nicht mehr gewährleistet.
<G-vec00366-002-s060><contain.befinden><en> All rooms that contain hobs with burners – that use up air in the room they are installed in – require airing ducts.
<G-vec00366-002-s060><contain.befinden><de> In allen Räumen, in denen sich Kochfelder mit Brennern befinden - die den Räumlichkeiten, in denen sie installiert sind Luft entziehen - müssen Belüftungsöffnungen vorgesehen sein.
<G-vec00366-002-s061><contain.befinden><en> Ensure that the directory used to store prerequisite update files does not contain previously downloaded files.
<G-vec00366-002-s061><contain.befinden><de> Stellen Sie sicher, dass sich in dem Verzeichnis, in dem die erforderlichen Updatedateien gespeichert werden, keine zuvor heruntergeladenen Dateien befinden.
<G-vec00366-002-s062><contain.befinden><en> The complex consists of several buildings no higher than two stories, which contain rooms and suites.
<G-vec00366-002-s062><contain.befinden><de> Der Komplex besteht aus mehreren, maximal zweistöckigen Gebäuden, in denen sich die Zimmer und Suiten befinden.
<G-vec00366-002-s063><contain.befinden><en> If the display case can be locked up, then it will often contain valuable information or materials.
<G-vec00366-002-s063><contain.befinden><de> Ist der Schaukasten abschließbar, befinden sich häufig wertvolle Informationen oder Materialien darin.
<G-vec00366-002-s064><contain.befinden><en> Usually those elements contain all the information relating to your tyre size and specifications, as well as the appropriate tyre pressure.
<G-vec00366-002-s064><contain.befinden><de> Hier befinden sich üblicherweise alle Informationen zur Größe Ihrer Reifen sowie der geeignete Reifendruck.
<G-vec00366-002-s065><contain.befinden><en> The eco dog food does not contain any artificial colouring agents, flavourings or preservatives.
<G-vec00366-002-s065><contain.befinden><de> In dem Öko-Hundefutter befinden sich keinerlei künstlichen Farb-, Aroma- und Konservierungsstoffe.
<G-vec00366-002-s066><contain.befinden><en> The Wipf AG website may contain links to the websites of other providers.
<G-vec00366-002-s066><contain.befinden><de> Auf der Website der Wipf AG können sich Links auf die Seiten anderer Betreiber befinden.
<G-vec00366-002-s067><contain.befinden><en> They contain around 45,000 square meters of murals and more than 2,000 painted sculptures.
<G-vec00366-002-s067><contain.befinden><de> In ihnen befinden sich rund 45.000 Quadratmeter Wandmalereien und mehr als 2.000 bemalte Skulpturen.
<G-vec00366-002-s068><contain.befinden><en> The upper floors contain the office areas with views across the city and into the inner courtyard.
<G-vec00366-002-s068><contain.befinden><de> In den Obergeschossen befinden sich die Bürobereiche mit Blickbezügen sowohl in die Stadt, als auch in den Innenhof.
<G-vec00366-002-s069><contain.befinden><en> The archives of the Central Committee contain reports by our best physicians on the state of L.D.’s health.
<G-vec00366-002-s069><contain.befinden><de> Im Archiv des Zentralkomitees befinden sich Berichte unserer besten Ärzte über den Gesundheitszustand L.D.s.
<G-vec00366-002-s070><contain.befinden><en> The reverse sides of the stamps contain information on the species and their protection and the protection work done by WWF.
<G-vec00366-002-s070><contain.befinden><de> Auf der Rückseite befinden sich Informationen über die Tierarten, wie sie geschützt werden und welche Arbeit WWF dabei leistet.
<G-vec00366-002-s071><contain.befinden><en> These labels contain barcodes with unique IDs, which can be clearly assigned by the ERP system, supporting warehouse/production processes.
<G-vec00366-002-s071><contain.befinden><de> Auf den Labels befinden sich dann Barcodes mit eindeutigen IDs, die vom ERP System eindeutig zugeordnet werden können und somit Warehouse- und Produktionsprozesse unterstützen.
<G-vec00366-002-s072><contain.befinden><en> Belle's eldest brother, Maxime (Nicolas Gob) finds a jewel on her clothing, positing that the castle may contain further treasures.
<G-vec00366-002-s072><contain.befinden><de> Als Belles ältester Bruder ihr vornehmes Kleid sieht, nimmt er an, dass sich noch mehr Reichtümer im Schloss befinden.
<G-vec00366-002-s073><contain.befinden><en> This applies particularly to the island nations in the southwest Pacific, whose territorial waters contain the richest crusts.
<G-vec00366-002-s073><contain.befinden><de> Das betrifft vor allem die Inselstaaten im Südwestpazifik, in deren Hoheitsgebieten sich die ergiebigsten Krusten befinden.
<G-vec00366-002-s074><contain.befinden><en> UNIQA’s portfolios contain large quantities of risk insurance policies with a premium adjustment clause, particularly in Austria.
<G-vec00366-002-s074><contain.befinden><de> In den Portfolios von UNIQA, insbesondere in Österreich, befinden sich große Bestände von Risikoversicherungen mit Prämienanpassungsklauseln.
<G-vec00366-002-s075><contain.befinden><en> For this reason, quarantined domains should be leaf domains, their child domains should be only resource domains that contain no user accounts, or the quarantined domain should be in a separate forest.
<G-vec00366-002-s075><contain.befinden><de> Aus diesem Grund sollten unter Quarantäne stehende Domänen Endknotendomänen sein, ihnen untergeordnete Domänen sollten nur als Ressourcendomänen ohne Benutzerkonten dienen, oder die unter Quarantäne stehende Domäne sollte sich in einer separaten Gesamtstruktur befinden.
<G-vec00366-002-s095><contain.beinhalten><en> Note! The Leaderboard page will contain a search field where you can type your screen name and see information on what dates you have qualified or not qualified.
<G-vec00366-002-s095><contain.beinhalten><de> Anmerkung: Die Leaderboard-Seite beinhaltet ein Suchfeld, in das Sie Ihren Benutzernamen eingeben können, um zu sehen, an welchen Tagen Sie sich qualifizierten und an welchen Tagen Sie sich nicht qualifiziert haben.
<G-vec00366-002-s096><contain.beinhalten><en> The Bible itself doesn't contain any special instructions for its own disposal.
<G-vec00366-002-s096><contain.beinhalten><de> Die Bibel selbst beinhaltet keinerlei Instruktionen, wie sie entsorgt werden soll.
<G-vec00366-002-s097><contain.beinhalten><en> The supplier already now points out that, if the goods also contain a drive set, the legal regulations applicable to the so-called transport of dangerous goods must be observed.
<G-vec00366-002-s097><contain.beinhalten><de> Der Anbieter weist bereits jetzt darauf hin, dass, sofern die Ware auch einen Antriebssatz beinhaltet, die bezüglich sogenannter Gefahrgut-Transporte gültigen gesetzlichen Bestimmungen zu beachten sind.
<G-vec00366-002-s098><contain.beinhalten><en> Politics contain refugee topics, climate change and global warming, immigration laws, national and international economy and many more.
<G-vec00366-002-s098><contain.beinhalten><de> Politik beinhaltet aber auch Themen wie Klimawandel und die globale Erwärmung, Migration, nationale und internationale Wirtschaft und vieles mehr.
<G-vec00366-002-s099><contain.beinhalten><en> This means that they retain water that can contain a lot of germs and bacteria.
<G-vec00366-002-s099><contain.beinhalten><de> Das bedeutet, dass sie diese Wasserquellen absorbieren und oft beinhaltet das Wasser viele Keime und Bakterien.
<G-vec00366-002-s100><contain.beinhalten><en> Your comprehensive draft specification will contain brochures, technical data and facts as well as conditions applying to your STAHL commercial large-scale drier.
<G-vec00366-002-s100><contain.beinhalten><de> Ihr umfangreiches Konzept beinhaltet Prospektmaterial, technische Daten und Fakten sowie die Einkaufskonditionen für Ihren gewerblichen STAHL Groß-Trockner.
<G-vec00366-002-s101><contain.beinhalten><en> These chapters contain useful hints and tips to improve virtualization performance, scale and stability.
<G-vec00366-002-s101><contain.beinhalten><de> Dieses Kapitel beinhaltet nützliche Hinweise und Tipps, um die Leistung, Skalierbarkeit und Stabilität der Virtualisierung zu verbessern.
<G-vec00366-002-s102><contain.beinhalten><en> However, we are all allowed to be excited about what new features this release will actually contain.
<G-vec00366-002-s102><contain.beinhalten><de> Allerdings darf man gespannt sein, welche Neuerungen dieses Release dann tatsächlich beinhaltet.
<G-vec00366-002-s103><contain.beinhalten><en> The audiovisual archives of the Montreux Jazz Festival contain recordings from the greatest musicians of our times.
<G-vec00366-002-s103><contain.beinhalten><de> Das audiovisuelle Archiv des Montreux Jazz Festival beinhaltet die größten Musikschaffenden unserer Zeit.
<G-vec00366-002-s104><contain.beinhalten><en> Its leaves contain caffeine and are used to make infusions and a beverage called maté.
<G-vec00366-002-s104><contain.beinhalten><de> Es beinhaltet Koffein und wird für Infusionen und einem Getränk, das Mate genannt wird, verwendet.
<G-vec00366-002-s105><contain.beinhalten><en> Piracetol does not contain any human-made chemical component.
<G-vec00366-002-s105><contain.beinhalten><de> Piracetol beinhaltet nicht jede Art von Menschen verursachten chemischen Wirkstoff.
<G-vec00366-002-s106><contain.beinhalten><en> Our Website may contain links to other websites that are not under our control.
<G-vec00366-002-s106><contain.beinhalten><de> Unsere Webseite beinhaltet Links zu anderen Webseiten.
<G-vec00366-002-s107><contain.beinhalten><en> A master track doesn’t contain a pan or balance control because it’s never routed to another track.
<G-vec00366-002-s107><contain.beinhalten><de> Eine Masterspur beinhaltet nie einen Tonschwenk- oder Balanceregler, da sie nie an eine andere Spur geroutet wird.
<G-vec00366-002-s108><contain.beinhalten><en> The modern combi controls of the STILL cockpit contain all functions for guiding, operating and controlling the KANVAN.
<G-vec00366-002-s108><contain.beinhalten><de> Das moderne Kombi-Bedienelement STILL Cockpit beinhaltet alle Funktionen zum Steuern, Bedienen und Kontrollieren des KANVAN.
<G-vec00366-002-s109><contain.beinhalten><en> These German flashcard sets contain 1300 of the most important German vocabularies sorted by topic.
<G-vec00366-002-s109><contain.beinhalten><de> Diese Thai Flashkartenset beinhaltet 1300 der wichtigsten Thai-Vokabel thematisch sortiert und gruppiert.
<G-vec00366-002-s110><contain.beinhalten><en> The cerificate will contain the name of the course taken, course level, number of hours completed, and the level achieved.
<G-vec00366-002-s110><contain.beinhalten><de> Wenn Sie einen Enforex-Kurs erfolgreich abschließen, bekommen Sie ein Zertifikat, das die Art des belegten Kurses, die absolvierten Unterrichtseinheiten und das erreichte Sprachniveau beinhaltet.
<G-vec00366-002-s111><contain.beinhalten><en> Contain a specific list of user data that you’re requesting
<G-vec00366-002-s111><contain.beinhalten><de> Beinhaltet eine bestimmte Liste von Nutzerdaten die du anfragst.
<G-vec00366-002-s112><contain.beinhalten><en> Down payment from Paragraph 1 hereof shall contain the complete sum of Provider’s fee, elaborated in detail in Article 4, Paragraph 2 hereof.
<G-vec00366-002-s112><contain.beinhalten><de> Die Anzahlung aus dem ersten Absatz dieses Artikels beinhaltet im ganzen die Erstattung, die näher im Artikel 4, Absatz 2 dieser Bedingungen bestimmt ist.
<G-vec00366-002-s113><contain.beinhalten><en> Abstract: Energiekontor's 9M report gives a qualitative update on developments in the first nine months but does not contain explicit figures.
<G-vec00366-002-s113><contain.beinhalten><de> Zusammenfassung: Der 9M-Bericht von Energiekontor enthält ein qualitatives Update der Entwicklungen der ersten neun Monate, beinhaltet jedoch keine expliziten Zahlen.
<G-vec00366-002-s114><contain.bestehen><en> Their food should contain at least 45% protein, float, and be small enough to fit in the betta's mouth.
<G-vec00366-002-s114><contain.bestehen><de> Ihr Futter sollte zu mindestens 45% aus Protein bestehen, treiben und klein genug sein, dass es in ihre Mäuler passt.
<G-vec00366-002-s115><contain.bestehen><en> This Greater Israel will contain an Arab majority and a shrinking Jewish minority, turning it inevitably into an apartheid state, plagued by a permanent civil war and shunned by the world.
<G-vec00366-002-s115><contain.bestehen><de> Dieses Groß-Israel wird aus einer arabischen Mehrheit und einer schwindenden jüdischen Minderheit bestehen und wird unvermeidbar zu einem Apartsheidsstaat, der von einem ständigem Bürgerkrieg geplagt wird und den die Welt meidet.
<G-vec00366-002-s116><contain.bestehen><en> Full spectrum CBD refers to products that contain more than CBD, such as other plant molecules like THC and healthy fatty acids.
<G-vec00366-002-s116><contain.bestehen><de> Solche Öle, die man als Vollspektrumprodukte bezeichnet, bestehen nicht nur aus CBD, sondern auch aus verschiedenen anderen Pflanzenmolekülen.
<G-vec00366-002-s117><contain.bestehen><en> | 05.12.2017 Every smoothie should contain both fruits and vegetables: blueberries and kale are extremely nutritious yet low in calories.
<G-vec00366-002-s117><contain.bestehen><de> Jeder Smoothie sollte aus Gemüse und Obst bestehen: Sowohl Heidelbeeren als auch Grünkohl sind extrem nährstoffreich, dafür aber kalorienarm.
<G-vec00366-002-s118><contain.bestehen><en> Our distribution boards now contain 33% recycled plastic.
<G-vec00366-002-s118><contain.bestehen><de> Die dort produzierten Verteilerschränke bestehen von nun an aus 33% wiederverwertetem Polystyrol.
<G-vec00366-002-s119><contain.bestehen><en> This event requires 500 pts teams, which have to contain at least 5 figures.
<G-vec00366-002-s119><contain.bestehen><de> Für dieses Event werden 500 Punkte Teams benötigt, die aus mindestens 5 Figuren bestehen müssen.
<G-vec00366-002-s120><contain.bestehen><en> The password must be at least 8 characters long and contain a mix of letters and numbers.
<G-vec00366-002-s120><contain.bestehen><de> Das Passwort muss mindestens 8 Zeichen lang sein und aus Buchstaben und Ziffern bestehen.
<G-vec00366-002-s121><contain.bestehen><en> The Portal may contain certain exclusive services aimed at our customers and registered users, in which case access will be restricted.
<G-vec00366-002-s121><contain.bestehen><de> Im Portal können bestimmte exklusive Dienstleistungen für unsere Kunden oder für angemeldete Benutzer bestehen, so dass der Zugang zu diesen eingeschränkt sein könnte.
<G-vec00366-002-s122><contain.bestehen><en> CU boxes for products shipped to Europe contain 80% post-consumer fibre and are fully recyclable.
<G-vec00366-002-s122><contain.bestehen><de> Die Kartons für Produkte, die nach Europa versendet werden, bestehen zu 80 % aus gebrauchten Fasern, die vollständig wiederverwertbar sind.
<G-vec00366-002-s123><contain.bestehen><en> Sandvik does not assume any responsibility for the privacy practices or the contents of external websites to which the Site contain links.
<G-vec00366-002-s123><contain.bestehen><de> Sandvik übernimmt keine Verantwortung für die Datenschutzpraxis oder für den Inhalt externer Webseiten, zu denen Links bestehen.
<G-vec00366-002-s124><contain.bestehen><en> The GRS label may be used with final products, such as clothing or household textiles, if they contain a minimum of 20% recycled materials.
<G-vec00366-002-s124><contain.bestehen><de> Das Label des GRS darf bei Endprodukten wie Kleidungsstücken oder Heimtextilien verwendet werden, wenn diese zu mindestens 20 Prozent aus recycelten Materialien bestehen.
<G-vec00366-002-s125><contain.bestehen><en> Password: Password has to be at least 8 characters long and has to contain at least one capital letter, one lower document Article Description Model Usage
<G-vec00366-002-s125><contain.bestehen><de> Passwort: Das Passwort muss aus mindestens acht Zeichen, mindestens einem Groß- und einem Kleinbuchstaben, sowie einem Sonderzeichen und/oder einer Ziffer bestehen.
<G-vec00366-002-s126><contain.bestehen><en> All of the passwords you create should contain from 6 to 8 characters, and should contain both upper and lower-case characters, as well as punctuation characters.
<G-vec00366-002-s126><contain.bestehen><de> Alle Paßwörter, die Sie jetzt und in Zukunft vergeben, sollten aus 6 bis 8 Zeichen bestehen und neben großen und kleinen Buchstaben auch Satzzeichen oder Zahlen enthalten.
<G-vec00366-002-s127><contain.bestehen><en> Your production can contain a mixture of video and photos.
<G-vec00366-002-s127><contain.bestehen><de> Ihre Produktion kann aus einer Kombination von Video und Fotos bestehen.
<G-vec00366-002-s128><contain.bestehen><en> Thanks to its elevated degree of sensitivity, it also facilitates identification of mosaic embryos. In other words, embryos that contain a mix of normal and abnormal cells.
<G-vec00366-002-s128><contain.bestehen><de> Und dank seiner hohen Sensibilität erlaubt es auch die Identifizierung von Mosaik-Embryonen, d.h. Embryonen, die aus einer Mischung aus normalen und anormalen Zellen bestehen.
<G-vec00366-002-s129><contain.bestehen><en> Down products that contain as many as 91 individually cut pieces deliver the ultimate fit – more insulation around the torso and foot box, and full insulation around the head and forehead.
<G-vec00366-002-s129><contain.bestehen><de> Daunenprodukte, die aus 91 einzeln geschnittenen Teilen bestehen, haben die ultimative Anpassungsform – mehr Isolierung für den Oberkörper und die Füße, volle Isolierung am Kopf und der Stirn.
<G-vec00366-002-s130><contain.bestehen><en> The video should not contain photos, but must contain video of participants directly.
<G-vec00366-002-s130><contain.bestehen><de> Videos sollten nicht aus Fotografien bestehen, sondern unmittelbare Videoaufnahme der Teilnehmer enthalten.
<G-vec00366-002-s131><contain.bestehen><en> The names Lincoln and Kennedy each contain seven letters.
<G-vec00366-002-s131><contain.bestehen><de> Die Namen Lincon und Kennedy bestehen beide aus 7 Buchstaben.
<G-vec00366-002-s132><contain.bestehen><en> They are in the form of bulges from mucous membrane directed to the inside, and contain numerous arteriovenous communications.
<G-vec00366-002-s132><contain.bestehen><de> Sie haben eine Form der Ausbuchtung nach innen der Schleimhaut und bestehen aus arteriovenösen Verbindungen.
<G-vec00366-002-s228><contain.enthalten><en> It is also possible to integrate our classic and active varieties, however these should be limited to individual meals due to the milk products they contain.
<G-vec00366-002-s228><contain.enthalten><de> Es ist auch möglich unsere klassische und die active Variante zu integrieren, aufgrund der enthaltenen Milchprodukte, sollte dies jedoch auf einzelne Mahlzeiten beschränkt werden.
<G-vec00366-002-s229><contain.enthalten><en> This ordered method of presentation has the character of an archive: the single objects, and the very personal information they contain, are documented, and preserved for posterity.
<G-vec00366-002-s229><contain.enthalten><de> Diese geordnete Präsentationsweise hat archivarischen Charakter: Die einzelnen Objekte und die in ihnen enthaltenen sehr persönlichen Informationen werden dokumentiert und bewahrt.
<G-vec00366-002-s230><contain.enthalten><en> Tekla Structures has several tools you can use to import and export physical and reference models and the information they contain.
<G-vec00366-002-s230><contain.enthalten><de> Tekla Structures umfasst mehrere Werkzeuge, die Sie zum Importieren und Exportieren von physikalischen Modellen und Referenzmodellen sowie der darin enthaltenen Informationen verwenden können.
<G-vec00366-002-s231><contain.enthalten><en> In addition, we also ensure that the correct form of the documents is maintained, as this is as important as the data they contain for the success of the audit.
<G-vec00366-002-s231><contain.enthalten><de> Außerdem achten wir auf die Einhaltung der richtigen Form für die Unterlagen, denn diese spielt neben den enthaltenen Daten eine entscheidende Rolle für das Gelingen der Prüfung.
<G-vec00366-002-s232><contain.enthalten><en> Using XPath, you can even select tags based on the text they contain.
<G-vec00366-002-s232><contain.enthalten><de> Mithilfe von XPath können Sie auch Tags auswählen, die sich auf einen im Tag enthaltenen Text beziehen.
<G-vec00366-002-s233><contain.enthalten><en> Besides, it will let you mount virtual file images in the RAR, ZIP and MOU formats, which will let you use the files they contain, without having to extract them.
<G-vec00366-002-s233><contain.enthalten><de> Außerdem können Sie virtuelle Abbilder im RAR, ZIP und MOU Format mounten, damit Sie die enthaltenen Dateien anschauen können, ohne sie zu extrahieren.
<G-vec00366-002-s234><contain.enthalten><en> The micronutrients they contain are very well absorbed by the skin and their natural origin makes them particularly well tolerated, providing the skin with sustained nourishment with immediately visible effects.
<G-vec00366-002-s234><contain.enthalten><de> Die darin enthaltenen Mikronährstoffe werden von der Haut besonders gut aufgenommen und sind durch ihre natürliche Quelle besonders verträglich und schenken sofort sichtbar nachhaltige Pflegeergebnisse.
<G-vec00366-002-s235><contain.enthalten><en> Cookies allow a website to, among other things, store and retrieve information about the browsing habits of a user or their computer and, depending on the information they contain and the way they use their computer, may be used to recognize the user.
<G-vec00366-002-s235><contain.enthalten><de> Cookies ermöglichen es einer Website unter anderem, Informationen über die Surfgewohnheiten eines Nutzers oder seines Computers zu speichern und abzurufen und, abhängig von den darin enthaltenen Informationen und der Art und Weise, wie er seinen Computer benutzt, den Nutzer zu erkennen.
<G-vec00366-002-s236><contain.enthalten><en> In addition, you must be very careful with the products you use to eliminate pet odors, since the chemicals they contain are often harmful to the health of animals (and people).
<G-vec00366-002-s236><contain.enthalten><de> Darüber hinaus müssen Sie mit den Produkten, die Sie zur Beseitigung von Tiergerüchen verwenden, sehr vorsichtig sein, da die darin enthaltenen Chemikalien für die Gesundheit von Tieren (und Menschen) oft schädlich sind.
<G-vec00366-002-s237><contain.enthalten><en> Dyes essentially have two advantages: they can be preserved for three years, and the active ingredients they contain are quickly absorbed by the organism.
<G-vec00366-002-s237><contain.enthalten><de> Farbstoffe haben im Wesentlichen zwei Vorteile: Sie können drei Jahre lang konserviert werden, und die darin enthaltenen Wirkstoffe werden vom Organismus schnell absorbiert.
<G-vec00366-002-s238><contain.enthalten><en> Depending on the type of liquid or gel they contain, bottles with a compound curve often need to be fully squeezable at the bottom of the bottle where the curve is wider.
<G-vec00366-002-s238><contain.enthalten><de> Flaschen mit komplexer Wölbung müssen – abhängig von der enthaltenen Flüssigkeit – am unteren Ende, wo die Wölbung besonders stark ist, gut verformbar sein.
<G-vec00366-002-s239><contain.enthalten><en> Programs will display the color of the lowest allocation level among projects they contain that have any allocations.
<G-vec00366-002-s239><contain.enthalten><de> Programme zeigen die Farbe der niedrigsten Allokations-Stufe unter den darin enthaltenen Projekten an, die überhaupt Allokationen haben.
<G-vec00366-002-s240><contain.enthalten><en> They also contain carotenoids that have a positive effect on the eyes, because the blood circulation of the eyes is boosted.
<G-vec00366-002-s240><contain.enthalten><de> Die in den Beeren enthaltenen Carotinoide haben einen positiven Einfluss auf die Augen, da sie die Durchblutung der Augen fördern.
<G-vec00366-002-s241><contain.enthalten><en> The list of SVHC substances and the various substances they contain are listed on the website of the European Chemicals Agency (ECHA).
<G-vec00366-002-s241><contain.enthalten><de> Die Liste der SVHC-Stoffe und die darin enthaltenen verschiedene Substanzen wird auf den Internetseiten der Europäischen Chemikalienagentur (ECHA) veröffentlicht.
<G-vec00366-002-s242><contain.enthalten><en> Nevertheless, no guarantees can be made with regard to the correctness and accuracy of the information that they contain.
<G-vec00366-002-s242><contain.enthalten><de> Trotzdem kann keine Gewähr für die Fehlerfreiheit und Genauigkeit der enthaltenen Informationen übernommen werden.
<G-vec00366-002-s243><contain.enthalten><en> Find out how ABBYY FineReader Corporate can support you in managing document-related challenges and how you can start using your documents and the information they contain more efficiently.
<G-vec00366-002-s243><contain.enthalten><de> Erfahren Sie noch heute wie ABBYY FineReader Corporate Sie dabei unterstützen kann, Ihre Dokumente und die darin enthaltenen Informationen effizienter zu nutzen.
<G-vec00366-002-s244><contain.enthalten><en> You can also delete cookies stored on your computer to permanently delete the information they contain.
<G-vec00366-002-s244><contain.enthalten><de> Sie können auch auf Ihrem Computer gespeicherte Cookies löschen, um die darin enthaltenen Informationen dauerhaft zu löschen.
<G-vec00366-002-s245><contain.enthalten><en> That applies to their construction, but first and foremost to the materials they contain.
<G-vec00366-002-s245><contain.enthalten><de> An deren Konstruktion, vor allem aber an die darin enthaltenen Baustoffe.
<G-vec00366-002-s246><contain.enthalten><en> Cookies, among other things, are used to store and retrieve information about the browsing habits of a user or their system and, depending on the information they contain and the way they use their system, on the type of cookie and the information they collect, they may also be used to identify the user.
<G-vec00366-002-s246><contain.enthalten><de> Sie werden unter anderem dazu verwendet, auf dem Rechner des Besuchers Informationen über dessen Nutzerverhalten zu speichern, und können auch (abhängig von den enthaltenen Informationen, von den Systemeinstellungen des Nutzers, der Art des Cookies und den erhobenen Informationen) dazu verwendet werden, den Nutzer bei einem späteren Besuch wiederzuerkennen.
<G-vec00366-002-s266><contain.finden><en> The following pages contain information on our degree programmes and how to apply to study at FHWS as an exchange student as well as on study formalities and finances, our support programme, and language courses.
<G-vec00366-002-s266><contain.finden><de> Auf den folgenden Seiten finden Sie Informationen zu unseren Studiengängen, der Bewerbung für ein Auslandsstudium an der FHWS, aber auch Hinweise auf Formalitäten und Finanzen, das Betreuungsprogramm und Sprachkurse.
<G-vec00366-002-s267><contain.finden><en> Furthermore, the roots contain organic acids, starch, bitter substances, fats, sugar, mucilage.
<G-vec00366-002-s267><contain.finden><de> Weiterhin finden sich in der Wurzel organische Säuren, Stärke, Bitterstoffe, Fette, Zucker, Schleime.
<G-vec00366-002-s268><contain.finden><en> The VDV website may contain links to websites of other organizations.
<G-vec00366-002-s268><contain.finden><de> Auf der Website von VDV sind möglicherweise einige Verweise zu Websites von anderen Unternehmen zu finden.
<G-vec00366-002-s269><contain.finden><en> In addition, our salads often contain healthy and tasty wild herbs and edible flowers, too.
<G-vec00366-002-s269><contain.finden><de> In den Salaten finden Sie zudem gesunde, schmackhafte Wildkräuter und essbare Blüten.
<G-vec00366-002-s270><contain.finden><en> Your computer user's manual or help screen may contain more information on how to eliminate or control the use or storage of cookies.
<G-vec00366-002-s270><contain.finden><de> Weitere Informationen zum Löschen oder zu Einstellungen für die Nutzung und Speicherung von Cookies finden Sie im Benutzerhandbuch oder auf den Hilfsseiten Ihres Computers.
<G-vec00366-002-s271><contain.finden><en> The following pages contain photos and explanations of the altar, ambon, baptistery, altarpieces, tabernacle, Stations of the Cross, picture of the Virgin Mary, crucifixion group and pietà.
<G-vec00366-002-s271><contain.finden><de> Auf den folgenden Seiten finden sich Bilder und Erläuterungen zu folgenden Mobilien: Altar, Ambo, Taufstein, Altarbilder, Tabernakel, Kreuzweg, Bild der immerwährenden Hilfe, Kreuzigungsgruppe und Pieta.
<G-vec00366-002-s272><contain.finden><en> Because his watches contain many influences from machine engineering – indeed, he began his career with an apprenticeship as a mechanic – Zeitmaschine (“time machine”) emerged as the second part of the brand name.
<G-vec00366-002-s272><contain.finden><de> Da diverse Einflüsse aus dem Maschinenbau in seinen Uhren zu finden sind und er seine berufliche Tätigkeit mit einer Maschinenmechaniker Lehre begann, ergab sich Zeitmaschine als zweiten Teil des Markennamens.
<G-vec00366-002-s273><contain.finden><en> Sample Questions These pages contain instructions and examples for each of the subtests of TestAS.
<G-vec00366-002-s273><contain.finden><de> Auf diesen Seiten finden Sie Instruktionen und Beispiele zu jeder Aufgabengruppe des TestAS.
<G-vec00366-002-s274><contain.finden><en> These salt sediments contain microorganisms, which are estimated to be millions of years old.
<G-vec00366-002-s274><contain.finden><de> In diesen Salzsedimenten finden sich Mikroorganismen, deren Alter auf Millionen Jahre geschätzt wird.
<G-vec00366-002-s275><contain.finden><en> Wall pictures of old masters like Gustav Klimt are perfect for this trend and a great decorative highlight, as they contain the metallic trend colours.
<G-vec00366-002-s275><contain.finden><de> Super im Trend und tolle Deko-Highlights sind außerdem Wandbilder alter Meister wie Gustav Klimt, denn in ihnen finden sich die metallischen Trendfarben wieder.
<G-vec00366-002-s276><contain.finden><en> Our “Made in Germany” production process does without any unnecessary ingredients: Ogænics® products contain neither fillers, flowing agents nor preservatives nor allergens such as lactose or gluten and of course none of the ingredients have been genetically engineered.
<G-vec00366-002-s276><contain.finden><de> Bei der Produktion „Made in Germany“ lassen wir alles Überflüssige weg: In unseren Ogænics® Produkten finden Sie weder Füll-, Fließ- und Konservierungsstoffe noch Allergene wie Laktose oder Gluten und natürlich sind alle Inhaltsstoffe ohne Gentechnik.
<G-vec00366-002-s277><contain.finden><en> The following pages contain information on roadworks in and around Norderstedt, on traffic jams on motorways and A-roads as well as a list of disruptions on all relevant means of transport in the metropolitan area of Hamburg and Schleswig-Holstein.
<G-vec00366-002-s277><contain.finden><de> Auf diesen Seiten finden Sie Informationen zu Baustellen im Stadtgebiet, zu Staumeldungen auf Autobahnen und Bundesstraßen sowie einen umfassenden Störungsmelder für alle relevanten Verkehrsmittel der Metropolregion Hamburg und Schleswig-Holsteins.
<G-vec00366-002-s278><contain.finden><en> Plant-based foods such as bread, nuts or potatoes contain less zinc.
<G-vec00366-002-s278><contain.finden><de> Etwas weniger Zink ist in pflanzlichen Lebensmitteln sowie Brot, Nüssen oder Kartoffeln zu finden.
<G-vec00366-002-s279><contain.finden><en> The following pages contain more detailed explanations the different procedures of recovery of silver, gold, platinum, palladium and rhodium.
<G-vec00366-002-s279><contain.finden><de> Auf den folgenden Seiten finden Sie nähere Erläuterungen zu den verschiedenen Verfahren der Rückgewinnung von Silber, Gold, Platin, Palladium und Rhodium.
<G-vec00366-002-s280><contain.finden><en> Besides passages from his magnum opus, The Conscious Mind, many of Doepfner's images contain excerpts from the anthology Philosophy of Mind, epistemological positions from Descartes to the present.
<G-vec00366-002-s280><contain.finden><de> Neben Passagen aus seinem Hauptwerk »The Conscious Mind« sind auf manchen ihrer Bilder Textauszüge aus dem Sammelwerk »Philosophy of Mind« zu finden, Positionen der Erkenntnisphilosophie von Descartes bis zur Gegenwart.
<G-vec00366-002-s281><contain.finden><en> The tabs above contain information to help you start syncing events between Google Calendar and Microsoft Outlook.
<G-vec00366-002-s281><contain.finden><de> Unter den Tabs, die Sie oben sehen, finden Sie Informationen über die Synchronisierung von Terminen zwischen Google Kalender und Microsoft Outlook.
<G-vec00366-002-s282><contain.finden><en> They contain fragments from significant references to art history, photos, graphic designs, snippets of global pop culture and much more besides.
<G-vec00366-002-s282><contain.finden><de> In ihnen finden sich Fragmente wichtiger kunsthistorischer Bezugspositionen, Fotografien, grafischer Muster, Schnipsel globaler Popkultur und vieles mehr.
<G-vec00366-002-s283><contain.finden><en> Many caves contain relics from the past, such as paintings on the rock walls.
<G-vec00366-002-s283><contain.finden><de> In vielen Höhlen finden sich Relikte einer prähistorischen Zeit, wie etwa Statuen oder Malereien an den Wänden.
<G-vec00366-002-s284><contain.finden><en> That is, a search for "dog cat" returns all messages that contain that exact phrase, with space.
<G-vec00366-002-s284><contain.finden><de> Das heißt, eine Suche nach "Hund Katze" wird alle Einträge finden, die aus genau dieser Wortfolge, inklusive Leerzeichen bestehen.
<G-vec00366-002-s361><contain.umfassen><en> The “classified documents” contain eight file folders, that were not yet mad accessible.
<G-vec00366-002-s361><contain.umfassen><de> Die "Geheimakten" umfassen acht bisher noch nicht systematisch erschlossene Aktenordner.
<G-vec00366-002-s362><contain.umfassen><en> Self-regulatory initiatives must contain a well-designed monitoring system, with clearly identified responsibilities for industry and independent inspectors.
<G-vec00366-002-s362><contain.umfassen><de> Selbstregulierungsinitiativen umfassen ein gründlich konzipiertes Überwachungssystem mit klar aufgeführten Aufgaben für die Industrie und die unabhängigen Prüfer.
<G-vec00366-002-s363><contain.umfassen><en> The meadows, fields and streams contain about 1800 different plant varieties.
<G-vec00366-002-s363><contain.umfassen><de> Die Wiesen, Felder und Bäche umfassen 1800 verschiedene Pflanzenarten.
<G-vec00366-002-s364><contain.umfassen><en> Built in 2013, all rooms come equipped with a TV and contain a private bathroom.
<G-vec00366-002-s364><contain.umfassen><de> Alle im Jahre 2013 erbauten Zimmer sind mit einem TV ausgestattet und umfassen ein eigenes Bad.
<G-vec00366-002-s365><contain.umfassen><en> Information provided in this document is necessarily summarized and may not contain all available material information.
<G-vec00366-002-s365><contain.umfassen><de> Die Informationen in dieser Pressemeldung sind notwendigerweise zusammengefasst und könnten nicht alle verfügbaren wesentlichen Informationen umfassen.
<G-vec00366-002-s366><contain.umfassen><en> Liechtenstein Collections The Princely Collections contain major works of European art spanning five centuries and are among the most important private collections in the world.
<G-vec00366-002-s366><contain.umfassen><de> Die Fürstlichen Sammlungen umfassen Hauptwerke europäischer Kunst aus fünf Jahrhunderten und gehören heute zu den bedeutendsten privaten Kunstsammlungen der Welt.
<G-vec00366-002-s367><contain.umfassen><en> For example, a single session can contain multiple page views and ecommerce transactions.
<G-vec00366-002-s367><contain.umfassen><de> Beispielsweise kann ein einzelner Besuch mehrere Seitenaufrufe und E-Commerce-Transaktionen umfassen.
<G-vec00366-002-s368><contain.umfassen><en> The 150 multiple choice tasks contain all areas of business and situations at your workplace.
<G-vec00366-002-s368><contain.umfassen><de> Die 150 Multiple-Choice-Aufgaben des Tests umfassen sämtliche Wirtschaftsbereiche und Situationen am Arbeitsplatz.
<G-vec00366-002-s369><contain.umfassen><en> These conditions of use contain six sections, including this introduction.
<G-vec00366-002-s369><contain.umfassen><de> Diese Nutzungsbestimmungen umfassen zusammen mit dieser Einleitung sechs Abschnitte.
<G-vec00366-002-s370><contain.umfassen><en> Robert A. Mundell: “If, as seems plausible, a few countries in North Africa and the Middle East also choose to fix their currencies to the euro, the euro area could easily contain as many as 50 countries with a population exceeding 500 million”.
<G-vec00366-002-s370><contain.umfassen><de> Robert A. Mundell: “Wenn - und das kommt wahrscheinlich vor - einige Länder in Nord Afrika und dem Nahen Osten auch bevorzugen, ihre Währungen zum Euro zu fixieren, könnte die Eurozone leicht 50 Länder mit 500 Millionen und mehr Menschen umfassen “.
<G-vec00366-002-s371><contain.umfassen><en> Hard to believe that these three meals and afternoon snack only contain about 1,500 calories. Bon appetit!
<G-vec00366-002-s371><contain.umfassen><de> Kaum zu glauben, dass diese drei Hauptmahlzeiten und der süße Snack für zwischendurch nur 1.500 Kalorien umfassen.
<G-vec00366-002-s372><contain.umfassen><en> Collections in the storehouses of the Deutsche Kinemathek that have not yet been indexed contain approximately 600,000 photographs.
<G-vec00366-002-s372><contain.umfassen><de> Die noch nicht erschlossenen Sammlungen in den Depots der Deutschen Kinemathek umfassen rund 600.000 Fotografien.
<G-vec00366-002-s373><contain.umfassen><en> While classic change projects are usually reasonable, based on a clear strategy and contain concrete purposes - such as the introduction of a new software or a move - transformation processes are a lot more complex nowadays.
<G-vec00366-002-s373><contain.umfassen><de> Während die klassischen Change-Projekte meist nachvollziehbare Gründe haben, auf einer klaren Strategie basieren und konkrete Vorhaben umfassen – zum Beispiel die Einführung einer neuen Software oder ein Umzug, sind die heutigen Transformationsprozesse viel komplexer.
<G-vec00366-002-s374><contain.umfassen><en> Cookie files usually contain the name of the website they originate from, the time of their storage on the end user device and a unique number.
<G-vec00366-002-s374><contain.umfassen><de> Die Cookie-Dateien umfassen üblicherweise die Bezeichnung der Internetseite, von welcher sie stammen, die Zeit der Aufbewahrung dieser auf dem Endgerät und eine einmalige Nummer.
<G-vec00366-002-s375><contain.umfassen><en> A file can also contain multiple tables that, together, contain all the information about a particular topic or related topics (a relational database).
<G-vec00366-002-s375><contain.umfassen><de> Eine Datei kann mehrere Tabellen umfassen, die zusammen sämtliche Informationen zu einem bestimmten Thema oder verwandten Themen enthalten (eine relationale Datenbank).
<G-vec00366-002-s376><contain.umfassen><en> This spam may contain potentially offensive text and links to sites of dubious quality.
<G-vec00366-002-s376><contain.umfassen><de> Dieser Spam kann potenziell anstößige Textinhalte und Links zu unseriösen Websites umfassen.
<G-vec00366-002-s377><contain.umfassen><en> His subjects contain all classic categories: flowers, still lifes, landscapes, nudes, and portraits. He also included figural scenes from the Bible or mythology and the impressions from his youthful walks through Spain and Morocco.
<G-vec00366-002-s377><contain.umfassen><de> Seine Motive umfassen alle klassischen Themen: Stillleben, Landschaften, Akte, Porträts, Blumen und figürliche Szenen aus der Bibel, der Mythologie und den Eindrücken der prägenden Wanderung als Jugendlicher durch Spanien und Marokko.
<G-vec00366-002-s378><contain.umfassen><en> Rooms at Hotel Requinte contain a flat-screen TV, a minibar and a private bathroom with a hot shower. Towels and linens are provided.
<G-vec00366-002-s378><contain.umfassen><de> Die klimatisierten Zimmer im Estação da Fé sind einfach eingerichtet und umfassen einen Flachbild-TV, einen Schreibtisch und ein eigenes Bad mit einer Dusche.
<G-vec00366-002-s379><contain.umfassen><en> "The End Is Important In All Things" will contain 10 songs and will be released on CD and a limited vinyl + CD - edition.
<G-vec00366-002-s379><contain.umfassen><de> "The End Is Important In All Things" wird 10 Songs umfassen und auf CD sowie als limitierte LP+CD erscheinen.
