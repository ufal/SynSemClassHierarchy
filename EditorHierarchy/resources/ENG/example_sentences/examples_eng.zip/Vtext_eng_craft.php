<G-vec00001-001-s019><craft.basteln><en> Their inspiration is: craft, old things, traditional costumes, clear materials, unclear colours, everyday life, unobtrusive, nonchalant and contradiction.
<G-vec00001-001-s019><craft.basteln><de> Ihre Inspiration ist: Basteln, alte Sachen, traditionelle Kostüme, klare Materialien, unklare Farben, Alltagsleben, Unaufdringlichkeit, Nonchalance und Widerspruch.
<G-vec00001-001-s020><craft.basteln><en> A month ago, as reported first by CNET, the service launched into beta, and for the first time, people in the U.S., Canada, and Europe were able to use My Robot Nation’s simple Web-based design tools to craft their own miniature robots.
<G-vec00001-001-s020><craft.basteln><de> Vor einem Monat, wie berichtet erstmals von CNET, der Service in Beta gestartet, und zum ersten Mal, Menschen in den USA, Kanada, und Europa konnten My Robot Nation einfache Web-basierte Design-Tools nutzen, um ihre eigenen Miniatur-Roboter basteln.
<G-vec00001-001-s021><craft.basteln><en> We play and craft with immediately available woodland materials.
<G-vec00001-001-s021><craft.basteln><de> Wir spielen und basteln mit Waldmaterialien.
<G-vec00001-001-s022><craft.basteln><en> Our colorful Easter hens are very decorative, are easy to craft and can be made in a short period of time.
<G-vec00001-001-s022><craft.basteln><de> Bunte Osterhühner Unsere bunten Osterhühner sehen sehr dekorativ aus, lassen sich leicht basteln und können in kurzer Zeit hergestellt werden.
<G-vec00001-001-s023><craft.basteln><en> But should you want to craft a nest box or two for your garden together with the younger of your family and set them up, then you are not too late at all.
<G-vec00001-001-s023><craft.basteln><de> Aber wenn Sie zusammen mit den Jüngeren Ihrer Familie einen Nistkasten basteln und ihn aufhängen wollen, dann sind Sie noch nicht zu spät dran.
<G-vec00001-001-s024><craft.basteln><en> With a combination of craft paper, crayons or watercolors, as well as cotton wool and cotton wool pads, you can make a variety of art.
<G-vec00001-001-s024><craft.basteln><de> Mit einer Kombination aus Bastelpapier, Buntstiften oder Wasserfarben sowie Watte und Wattepads könnt ihr abwechslungskreise Kunst basteln.
<G-vec00001-001-s025><craft.basteln><en> We craft, cook, paint and make excursions into nature.
<G-vec00001-001-s025><craft.basteln><de> Wir basteln, kochen, schnitzen, malen und unternehmen Ausflüge in die Natur.
<G-vec00001-001-s026><craft.basteln><en> They can take part in numerous activities and entertainments, including craft projects, games and a library corner, all supervised by the staff of Crans-Montana Tourism and Congress.
<G-vec00001-001-s026><craft.basteln><de> Das Team von Crans-Montana Tourismus & Kongress betreut dort zahlreiche Animationen und Aktivitäten wie Basteln, Spiele und Bücherecke.
<G-vec00001-001-s027><craft.basteln><en> For craft and decorating work using STEINEL Gluematic 5000, Gluematic 3002 und Gluefix hot-melt glue applicators.
<G-vec00001-001-s027><craft.basteln><de> Zum Basteln und Dekorieren mit STEINEL Heißklebepistolen Gluematic 5000, Gluematic 3002 und Gluefix.
<G-vec00001-001-s028><craft.basteln><en> Suitable as a gift for children and grandchildren, or for yourself to craft over the holidays.
<G-vec00001-001-s028><craft.basteln><de> Geeignet als Geschenk für Kinder und Enkel, oder für Sie selbst zum Basteln über die Feiertage.
<G-vec00001-001-s029><craft.basteln><en> For our younger guests aged 3 to 10, we offer free and qualified childcare, so children can play, craft and paint to their heart's content after elevenses.
<G-vec00001-001-s029><craft.basteln><de> Für unsere kleinen Gäste von 3 bis 10 Jahren bieten wir kostenfreie und qualifizierte Kinderbetreuung an, um nach dem Essen nach Herzenslust zu spielen, basteln und malen.
<G-vec00001-001-s030><craft.basteln><en> Whether you choose a standard or custom size, we craft each dress to order.
<G-vec00001-001-s030><craft.basteln><de> Ob Sie eine Standardgröße oder benutzerdefinierte Größe zu wählen, basteln wir jedes Kleid zu bestellen.
<G-vec00001-001-s031><craft.basteln><en> So you want to make a cheap, fun craft that doesn't require going to the store and buying supplies? This is simple and perfect for young children.
<G-vec00001-001-s031><craft.basteln><de> Wenn du etwas Günstiges und Tolles basteln möchtest, wofür du nicht in den Laden gehen musst, um irgendetwas einzukaufen, ist das hier perfekt für kleine Kinder und dazu noch ganz einfach.
<G-vec00001-001-s032><craft.basteln><en> Craft great-looking email surveys with your own questions.
<G-vec00001-001-s032><craft.basteln><de> Basteln Sie großartig aussehende E-Mail-Umfragen mit Ihren eigenen Fragen.
<G-vec00001-001-s033><craft.basteln><en> Children will enjoy themselves with sports and craft activities or take the spotlight during one of the evening performances.
<G-vec00001-001-s033><craft.basteln><de> Kinder können sich mit Sport und Basteln ausleben oder sie stehen in einer der Abendshows im Rampenlicht.
<G-vec00001-001-s034><craft.basteln><en> Governments are now trying to craft rules to prevent a recurrence.
<G-vec00001-001-s034><craft.basteln><de> Die Regierungen versuchen nun Regeln zu basteln, um eine Wiederholung zu verhindern.
<G-vec00001-001-s035><craft.basteln><en> With arbitrarily long knitted cords can potpourri and craft along the way are also the fine motor skills and the patience of the children trained .
<G-vec00001-001-s035><craft.basteln><de> Mit den beliebig langen Strick-Schnüren lässt sich Allerlei basteln und ganz nebenbei werden auch noch die Feinmotorik und die Geduld der Kinder geschult.
<G-vec00001-001-s036><craft.basteln><en> First, the nature of the state itself: Europe has set out to transcend the state and craft a foreign policy based primarily on the principles of soft power.
<G-vec00001-001-s036><craft.basteln><de> Zuerst die Natur des Staates selbst: Europa hat sich vorgenommen, mächtiger als der Staat zu werden und eine Außenpolitik zu basteln, die in erster Linie auf den Prinzipien der weichen Macht basiert.
<G-vec00001-001-s037><craft.basteln><en> Handwritten Songbook We will craft a handwritten songbook for you with all the lyrics and exclusive photos from the studio and the last year.
<G-vec00001-001-s037><craft.basteln><de> Handgeschriebenes Songbook Wir basteln euch ein handgeschriebenes Songbook, das alle Lyrics beinhaltet, sowie exclusives Fotomaterial aus dem Studio und aus dem letzten Jahr.
<G-vec00001-001-s093><craft.entwickeln><en> When a slew of customers told the founder they were using holi (oil) to shave; she knew it was time to craft a new formula.
<G-vec00001-001-s093><craft.entwickeln><de> Als eine Reihe von Kunden der Gründerin erzählten, dass sie Holi (Öl) zum Rasieren verwenden, wusste sie, dass es an der Zeit war, eine neue Rezeptur zu entwickeln.
<G-vec00001-001-s094><craft.entwickeln><en> In the future, they will create fragrances for different product categories and craft their own style.
<G-vec00001-001-s094><craft.entwickeln><de> Künftig kreieren sie Düfte für verschiedene Produktkategorien und entwickeln ihren eigenen Stil.
<G-vec00001-001-s095><craft.entwickeln><en> The physics behind these changes has been used by the secret government to produce antigravity craft, teleportation, and even time travel.
<G-vec00001-001-s095><craft.entwickeln><de> Die Physik hinter diesem Wandel wurde von der Geheimregierung genutzt, um Antischwerkraft-Fahrzeuge zu entwickeln und Teleportation und sogar Zeitreisen zu ermöglichen.
<G-vec00001-001-s096><craft.entwickeln><en> All of Sofield's projects imbue a restrained luxury in design through choices in materials and craft as well as through a process of discovery where clients decipher their very own concept of luxury.
<G-vec00001-001-s096><craft.entwickeln><de> Alle Projekte von Sofield weisen ein Design auf, das durchdrungen ist von einem verhaltenen Luxus, was sich in der Auswahl des Materials und der Handwerkskunst äußert, aber auch in einem Entdeckungsprozess, in dem die Kunden ihr ganz eigenes Konzept von Luxus entwickeln.
<G-vec00001-001-s097><craft.entwickeln><en> ... detect and craft approaches as well as responses to disruptive innovations.
<G-vec00001-001-s097><craft.entwickeln><de> ... erkennen und entwickeln Ansätze für sowie Antworten auf disruptive Innovationen.
<G-vec00001-001-s098><craft.entwickeln><en> As a tooling manufacturer with extensive experience and a global customer base, we have a wealth of knowledge upon which to craft smart solutions.
<G-vec00001-001-s098><craft.entwickeln><de> Als Werkzeughersteller mit langjähriger Erfahrung und einem weltweiten Kundenstamm verfügen wir über umfassende Expertise und können so intelligente Lösungen entwickeln.
<G-vec00001-001-s099><craft.entwickeln><en> The report adds, “Ricoh’s broad product range combined with its burgeoning IT infrastructure services and professional services organization provide an extensive selection of resources from which to craft industry-specific and horizontal solutions.”
<G-vec00001-001-s099><craft.entwickeln><de> Der Bericht stellt ebenfalls heraus, dass Ricohs umfassendes Produktportfolio kombiniert mit den stetig wachsenden IT Infrastructure Services und der professionellen Service-Organisation eine umfangreiche Auswahl an Ressourcen bietet, die es dem Unternehmen ermöglichen, branchenspezifische und horizontale Lösungskonzepte zu entwickeln.
<G-vec00001-001-s100><craft.entwickeln><en> S/he will help you craft an exercise routine that fits your precise needs.
<G-vec00001-001-s100><craft.entwickeln><de> Sie oder er werden dir helfen, eine Routine beim Sport zu entwickeln, die genau auf deine Bedürfnisse zugeschnitten ist.
<G-vec00001-001-s101><craft.entwickeln><en> All of Sofield’s projects imbue a restrained luxury in design through choices in materials and craft as well as through a process of discovery where clients decipher their very own concept of luxury.
<G-vec00001-001-s101><craft.entwickeln><de> Alle Projekte von Sofield weisen ein Design auf, das von einem verhaltenen Luxus durchdrungen ist, was sich in der Auswahl des Materials und der Handwerkskunst äußert, aber auch in einem Entdeckungsprozess, in dem die Kunden ihr ganz eigenes Konzept von Luxus entwickeln.
<G-vec00001-001-s102><craft.entwickeln><en> The Naturefriends movement is seeking to boost sustainable tourism by way of long-term projects, such as the transborder ‘Landscape of the Year 2007-2009 – the Danube Delta’. African and European members of the Naturefriends movement engage in an exchange of experience and craft joint projects.
<G-vec00001-001-s102><craft.entwickeln><de> Mit langfristigen Projekten wie etwa in der grenzüberschreitenden ‚Landschaft des Jahres 2007-2009 Donaudelta’ arbeitet die Naturfreundebewegung daran, Tourismus nachhaltig zu entwickeln.
<G-vec00001-001-s103><craft.erstellen><en> If you use the same strategy to craft your call-to-action message, your target audience will be compelled to click the button text to find out what’s on the other side.
<G-vec00001-001-s103><craft.erstellen><de> Wenn Du dieselbe Strategie benutzt, um Deine Handlungsaufforderung zu erstellen, wird Deine Zielgruppe genötigt, herauszufinden, was auf der anderen Seite passiert.
<G-vec00001-001-s104><craft.erstellen><en> This will give us room to check all the devices for compatibility and then craft a volume discount based on the number of compatible phones.
<G-vec00001-001-s104><craft.erstellen><de> Dies gibt uns Raum, alle Geräte auf Kompatibilität zu überprüfen und dann einen Mengenrabatt basierend auf der Anzahl der kompatiblen Telefone zu erstellen.
<G-vec00001-001-s105><craft.erstellen><en> Once you touch a handful of daily visitors, you should craft an in-depth piece of compelling content that adds value to your audience.
<G-vec00001-001-s105><craft.erstellen><de> Sobald Du erst mal täglich eine Handvoll Besucher erreichst, solltest Du einen aussagekräftigen, lockenden Inhalt, der Deinem Publikum etwas bietet, erstellen.
<G-vec00001-001-s106><craft.erstellen><en> Because it'll help you craft a personalized ad message based on the user's psyche onÂ each platform.
<G-vec00001-001-s106><craft.erstellen><de> Weil es Dir helfen wird, basierend auf der Nutzerpsychologie der verschiedenen Plattformen, eine personalisierte Werbebotschaft zu erstellen.
<G-vec00001-001-s107><craft.erstellen><en> On the BA Graphic Communication degree, learn how to use words, images, colour, metaphor, symbols and stories to craft meaningful messages.
<G-vec00001-001-s107><craft.erstellen><de> Lernen Sie im BA Graphic Communication Grad, wie Sie Wörter, Bilder, Farben, Metapher, Symbole und Geschichten verwenden, um sinnvolle Botschaften zu erstellen.
<G-vec00001-001-s108><craft.erstellen><en> Those who don’t have a site but need a forum as a priority can turn to this forum software that also allows you to use a website maker to craft your forum around.
<G-vec00001-001-s108><craft.erstellen><de> Die die keine Webseite haben aber ein Forum mit Priorität brauchen, können diese Forumsoftware benutzen, die auch einen Webseitenersteller enthält um Ihr Forum zu erstellen.
<G-vec00001-001-s109><craft.erstellen><en> Next, analyze the best performing headlines and craft yours, using the winners as a template.
<G-vec00001-001-s109><craft.erstellen><de> Analysiere als Nächstes die Überschriften, die die beste Leistung erbringen und nutze sie als Vorlage, um Deine eigene zu erstellen.
<G-vec00001-001-s110><craft.erstellen><en> This skill is especially useful when students craft original, Spanish sentences with indirect object pronouns later in the lesson.
<G-vec00001-001-s110><craft.erstellen><de> Diese Fähigkeit ist besonders nützlich, wenn die Schüler Original, spanische Sätze mit indirekten Objektpronomen später in der Lektion erstellen.
<G-vec00001-001-s111><craft.erstellen><en> Few slaves had the education, leisure time, and permission necessary to craft lengthy autobiographies.
<G-vec00001-001-s111><craft.erstellen><de> Wenige Sklaven hatten die Ausbildung, Freizeit und Erlaubnis, um lange Autobiographien zu erstellen.
<G-vec00001-001-s112><craft.erstellen><en> If you’d like to pick the coordinate of a star you like and craft a certificate for someone yourself, this is perfectly fine.
<G-vec00001-001-s112><craft.erstellen><de> Wenn Du die Koordinaten eines Sterns selber aussuchen und ein eigenes Zertifikat für jemanden erstellen möchtest, kannst Du das gerne tun.
<G-vec00001-001-s113><craft.erstellen><en> With this foundation, and with guidance from faculty advisors, you'll craft a course of study that meets your interests and career goals.
<G-vec00001-001-s113><craft.erstellen><de> Mit dieser Grundlage und unter Anleitung von Fakultätsberatern erstellen Sie ein Studium, das Ihren Interessen und Karrierezielen entspricht.
<G-vec00001-001-s114><craft.erstellen><en> Our various artists have been inspired by the greatest various artists of all time like: Salvador Dali, Pablo Picasso, Edgar Degas, Alberto Giacometti, Fernando Botero, Eduardo Chillida, Joan Miro, Auguste Rodin, Andy Warhol and others... to craft personalized gifts.
<G-vec00001-001-s114><craft.erstellen><de> Unsere verschiedenen Künstlern worden von die größte aller Zeiten Künstlern inspieirt, wie: Salvador Dali, Pablo Picasso, Edgar Degas, Alberto Giacometti, Fernando Botero, Eduardo Chillida, Joan Miro, Auguste Rodin, Andy Warhol und anderen...um personalisierte Geschenke zu erstellen.
<G-vec00001-001-s115><craft.erstellen><en> Powered by the magic of Adobe Photoshop technology, Adobe Photoshop Lightroom CC for mobile lets you craft and share professional-quality images from your iPad, iPad Pro, iPhone, Android device, or Chromebook.
<G-vec00001-001-s115><craft.erstellen><de> Unterstützt von der Adobe Photoshop-Technologie können Sie mit Adobe Photoshop Lightroom CC for mobile professionelle Qualitätsbilder von Ihrem iPad, iPad Pro, iPhone, Android oder Chromebook erstellen und teilen.
<G-vec00001-001-s116><craft.erstellen><en> Tons of articles and blog posts have been written about how to craft headlines.
<G-vec00001-001-s116><craft.erstellen><de> Unmengen an Artikeln und Blog Posts wurden über das Erstellen von Überschriften veröffentlicht.
<G-vec00001-001-s117><craft.erstellen><en> You can craft a better headline when you understand your audience better than your competitors do.
<G-vec00001-001-s117><craft.erstellen><de> Du kannst bessere Überschriften erstellen, wenn Du Dein Publikum besser verstehst als Deine Konkurrenz.
<G-vec00001-001-s118><craft.erstellen><en> And you can craft a GDN campaign to show ads on LinkedIn for a lower cost than going through LinkedIn directly.
<G-vec00001-001-s118><craft.erstellen><de> Und Du kannst eine Kampagne über das Google-Werbenetzwerk erstellen, um Anzeigen auf LinkedIn zu niedrigeren Kosten zu schalten, anstatt die Anzeigen direkt über LinkedIn zu erstellen.
<G-vec00001-001-s119><craft.erstellen><en> You can leverage marketing statistics, trends and data to craft data-driven headlines for your blog posts.
<G-vec00001-001-s119><craft.erstellen><de> Du kannst Marketing Statistiken, Tendenzen und Daten wirksam einsetzen, um datenbasierte Überschriften für Deine Blog Posts zu erstellen.
<G-vec00001-001-s120><craft.erstellen><en> Craft a customized, specially designed background for your organization’s Twitter account which relates to your brand and mission.
<G-vec00001-001-s120><craft.erstellen><de> Erstellen Sie einen individuellen, speziellen Designhintergrund für ihr Organisation’s Twitter Konto, welches sich auf ihre Marke und ihre Mission bezieht.
<G-vec00001-001-s121><craft.erstellen><en> If the attackers learn about the type of connected device, they can craft and deploy a customized plugin that would be able — using AT commands — to steal data from that device and make changes in it, including changing the device’s firmware,” concludes Hromcová.
<G-vec00001-001-s121><craft.erstellen><de> "Wenn die Angreifer etwas über die Art des angeschlossenen Geräts erfahren, können sie ein benutzerdefiniertes Plugin erstellen und einsetzen, um mit AT-Befehlen Daten von diesem Gerät zu stehlen und Änderungen daran vorzunehmen, einschließlich der Änderung der Firmware des Geräts"", schließt Hromcová."
<G-vec00001-001-s130><craft.fertigen><en> We craft a sacred balance of our healthiest aspects.
<G-vec00001-001-s130><craft.fertigen><de> Wir fertigen eine heilige Balance unserer gesundesten Aspekte.
<G-vec00001-001-s131><craft.fertigen><en> We are pleased to craft a piece of jewellery in our workshops according to your individual desires.
<G-vec00001-001-s131><craft.fertigen><de> Gerne fertigen wir in unserem Atelier ein Schmuck- stück nach Ihren individuellen Wünschen an.
<G-vec00001-001-s132><craft.fertigen><en> The major thing we do that makes the difference, is to craft and seed, in better and more catalytic ways, the unconditional positive question.
<G-vec00001-001-s132><craft.fertigen><de> Die große Sache, die wir tun, die den Unterschied macht, ist es die unbedingte positive Frage in besseren und katalytischeren Weisen zu fertigen und zu säen.
<G-vec00001-001-s133><craft.fertigen><en> I tried it out immediately after and decide to craft a review.
<G-vec00001-001-s133><craft.fertigen><de> Ich versuchte es sofort nach und entscheiden, um eine Überprüfung zu fertigen.
<G-vec00001-001-s134><craft.fertigen><en> It has more than 150 recipes for craft, from ammo, med kits and batons to powerful energy guns; • your own shelter, your own ark — build all of the 11 unique buildings with blocks and improve them.
<G-vec00001-001-s134><craft.fertigen><de> Es enthält über 150 Anleitungen zum Fertigen von Munition, Medipacks und Schlagstöcken bis zu mächtigen Energiewaffen.• Deine Unterkunft, deine Arche: Erbaue alle 11 einzigartigen Gebäude aus Blöcken und verbessere sie.
<G-vec00001-001-s135><craft.fertigen><en> Craft a major to suit your particular interests with Environmental, Human Health, Secondary Teaching or an Individualized emphasis.
<G-vec00001-001-s135><craft.fertigen><de> Fertigen Sie ein Hauptfach, das Ihren speziellen Interessen entspricht, mit Umwelt, menschlicher Gesundheit, sekundärer Lehre oder einem individuellen Schwerpunkt.
<G-vec00001-001-s136><craft.fertigen><en> Einaudi 's crossover appeal emerges from his ability to craft subtle and compelling compositions and the music on Elements is absolutely no exception.
<G-vec00001-001-s136><craft.fertigen><de> Einaudi 's Crossover ergibt sich aus seiner Fähigkeit, subtile und überzeugende Kompositionen zu fertigen und die Musik auf Elements ist absolut keine Ausnahme.
<G-vec00001-001-s156><craft.gestalten><en> Reaching into the fields of marketing and advertising as well as creative disciplines, a communication design professional uses his or her understanding of consumer and constituent behavior to craft effective messages with the best reach and the most successful outcomes.
<G-vec00001-001-s156><craft.gestalten><de> Kommunikationsdesign greift in die Bereiche des Marketing, der Werbung und anderer kretaiver Studienfächer hinein, weshalb Fachleute im Kommunikationsdesign ihr Verständnis des Verbraucher- und Wählerverhaltens anwenden, um wirkungsvolle Nachrichten mit der besten Reichweite und den erfolgreichsten Ergebnissen zu gestalten.
<G-vec00001-001-s157><craft.gestalten><en> "The term ""black"" has countless meanings that will help you craft a unique, yet timeless domain."
<G-vec00001-001-s157><craft.gestalten><de> "Der Begriff ""black"" hat zahllose Bedeutungen, die Ihnen dabei helfen werden, eine einzigartige und doch zeitlose Domain zu gestalten."
<G-vec00001-001-s158><craft.gestalten><en> We partner with consumer health clients to craft people strategies that reflect the unique culture and requirements of their category and their organization.
<G-vec00001-001-s158><craft.gestalten><de> Wir arbeiten mit unseren Kunden zusammen, um Personalstrategien zu gestalten, die der einmaligen Unternehmenskultur und den Anforderungen der Unternehmen unserer Kunden gerecht werden.
<G-vec00001-001-s159><craft.gestalten><en> Gathering of Elements The Elements are the component used to craft different type of items for your Admiral.
<G-vec00001-001-s159><craft.gestalten><de> Die Elemente sind die Komponente, die verwendet werden, um verschiedene Arten von Gegenstäden für deinen Admiral zu gestalten.
<G-vec00001-001-s160><craft.gestalten><en> It's now more important than ever to craft a superior mobile experience for your customers visiting your e-commerce website because:
<G-vec00001-001-s160><craft.gestalten><de> Es ist also wichtiger denn je, die Erfahrung Deines Kunden, der über sein Handy auf Deine Webseite zugreift, so positiv wie möglich zu gestalten.
<G-vec00001-001-s161><craft.gestalten><en> Built-in Apps Ready to craft, calculate, communicate or illustrate.
<G-vec00001-001-s161><craft.gestalten><de> Integrierte Apps Bereit zum Gestalten, Rechnen, Kommunizieren und Illustrieren.
<G-vec00001-001-s162><craft.gestalten><en> Room to craft, innovate and build.
<G-vec00001-001-s162><craft.gestalten><de> Raum, zu gestalten, Neuerungen einzubringen und etwas aufzubauen.
<G-vec00001-001-s163><craft.gestalten><en> They bring the innovations and the ideas, they build the product and craft the marketing campaigns.
<G-vec00001-001-s163><craft.gestalten><de> Sie sorgen für die Innovationen und Ideen, sie stellen das Produkt her und gestalten die Marketingkampagnen.
<G-vec00001-001-s164><craft.gestalten><en> The foreign ministries of Europe are struggling with the question of how to craft a lasting political solution for Kosovo. The overriding objective of Europe's interior ministries is to prevent any further migration from the Balkans.
<G-vec00001-001-s164><craft.gestalten><de> Während Europas Außenministerien mit der Frage ringen, wie eine dauerhafte politische Lösung im Kosovo zu gestalten ist, ist es das vorrangige Ziel der europäischen Innenministerien, weitere Einwanderung aus dem Balkan zu verhindern.
<G-vec00001-001-s165><craft.gestalten><en> The course also has critical thinking and film literacy at its core, with workshops and seminars designed to build your ability to appreciate what has gone before as you craft the stories of the future.
<G-vec00001-001-s165><craft.gestalten><de> Der Kurs hat auch kritisches Denken und Filmkompetenz im Mittelpunkt, mit Workshops und Seminaren, die Ihnen die Möglichkeit bieten, das Geschehene zu schätzen, während Sie die Geschichten der Zukunft gestalten.
<G-vec00001-001-s166><craft.gestalten><en> You know what this action is, so you should craft campaigns that complement the action.
<G-vec00001-001-s166><craft.gestalten><de> Du weißt, was diese Handlung war, also solltest Du Kampagnen gestalten, die diese Handlung ergänzen.
<G-vec00001-001-s380><craft.herstellen><en> We are dedicated to creating the high quality products and providing the professional customer service in the metal craft......
<G-vec00001-001-s380><craft.herstellen><de> Wir haben es uns zur Aufgabe gemacht, qualitativ hochwertige Produkte herzustellen und professionellen Kundenservice in der......
<G-vec00001-001-s381><craft.herstellen><en> He now spends his working life making beautiful wood bowls and vases and boxes and travelling around craft fairs selling them.
<G-vec00001-001-s381><craft.herstellen><de> Er verbringt nun seine Zeit damit, wunderschöne Holzschalen, -vasen und -schatullen herzustellen und sie auf Kunsthandwerksmärkten zu verkaufen.
<G-vec00001-001-s382><craft.herstellen><en> We help craft bespoke fragrances for every personality.
<G-vec00001-001-s382><craft.herstellen><de> Wir helfen, individuelle Düfte für jede Persönlichkeit herzustellen.
<G-vec00001-001-s383><craft.herstellen><en> Piccolo Fiore has managed to craft a duo of wines that are, in essence, Sicily in a glass.
<G-vec00001-001-s383><craft.herstellen><de> Piccolo Fiore ist es gelungen, eine Duo Weine herzustellen, die, im wesentlichen, Sizilien im Glas.
<G-vec00001-001-s384><craft.herstellen><en> Get the ‘Craft Permit: Golden Armor with Patterns’ and ‘Craft Permit: Finest Female Casual Clothes - Women’ from Carolin (NPC) first then purchase the design blueprints from Ornella (NPC) in order to be able to craft Jarette’s Armor.
<G-vec00001-001-s384><craft.herstellen><de> ○ Ihr benötigt zunächst ein „Herstellungserlaubnisschein: Goldene Rüstung mit Mustern“ und „Herstellungserlaubnisschein: Feinste Freizeitkleidung für Frauen“, welche Ihr bei Carolin kaufen könnt und anschließend könnt Ihr den Entwurf von Ornella kaufen um Jarretts Rüstung herzustellen.
<G-vec00001-001-s385><craft.herstellen><en> For such purpose, our capacity to break, rebuild and craft objects are of vital importance.
<G-vec00001-001-s385><craft.herstellen><de> Zu diesem Zweck ist unsere Fähigkeit, Objekte zu zerstören, wieder aufzubauen und herzustellen, von entscheidender Bedeutung.
<G-vec00001-001-s386><craft.herstellen><en> The orcs had been so weakened by the years of wandering that they posed no grand threat, however, they had learned to craft and use the bow and blade.
<G-vec00001-001-s386><craft.herstellen><de> Die Orks waren durch jahrelange Wanderung derart geschwächt, dass sie keine allzu große Gefahr darstellten, dennoch hatten sie gelernt, Bögen und Schwerter zu benutzen und herzustellen.
<G-vec00001-001-s387><craft.herstellen><en> Click on this symbol with the left mouse button to make this craft once.
<G-vec00001-001-s387><craft.herstellen><de> Klicke mit der linken Maustaste auf das Symbol, um eines herzustellen.
<G-vec00001-001-s388><craft.herstellen><en> Recruit stalwart followers to man your base, and send them to loot dungeons, fulfill missions, and craft items, even if you’re offline.
<G-vec00001-001-s388><craft.herstellen><de> Rekrutiert mächtige Anhänger, die eure Basis bemannen und schickt sie aus, Dungeons zu plündern, Missionen zu erfüllen oder Gegenstände herzustellen – auch während ihr offline seid.
<G-vec00001-001-s389><craft.herstellen><en> From its bases in Monza and Milan, Frette uses only the finest fibres and most skilled artisans to craft a range of products that have come to embody luxury, comfort and creativity across the globe.
<G-vec00001-001-s389><craft.herstellen><de> Mit seinen Hauptsitzen in Monza und Mailand verwendet Frette nur die feinsten Fasern und die erfahrensten Handwerker, um ein Produktarrangement herzustellen, das auf der ganzen Welt für Luxus, Komfort und Kreativität steht.
<G-vec00001-001-s390><craft.herstellen><en> Shell is used here to craft a waterproof hooded parka with Lens detail subtly embedded into a zip sleeve pocket.
<G-vec00001-001-s390><craft.herstellen><de> Shell wird hier verwendet, um einen wasserdichten Kapuzenparka mit einem Linsen-Detail herzustellen, das dezent in eine Reißverschlusstasche eingebettet ist.
<G-vec00001-001-s476><craft.schaffen><en> This was an rewarding experience and I had a blast working the metal to craft something I will keep the rest of my life.
<G-vec00001-001-s476><craft.schaffen><de> Dies war ein sehr befriedigendes Erlebnis; es war toll, aus dem Metall etwas zu schaffen, das ich den Rest meines Lebens behalten kann.
<G-vec00001-001-s477><craft.schaffen><en> To push back this devastating threat, players must help the Survivors grow stronger, craft a makeshift arsenal and form unexpected alliances to fight for survival in a dangerous new frontier.
<G-vec00001-001-s477><craft.schaffen><de> Um diese verheerende Bedrohung zurückzudrängen, müssen die Spieler den Überlebenden helfen, stärker zu werden, ein provisorisches Waffenarsenal zu schaffen und unerwartete Allianzen zu bilden, um in einer gefährlichen Schlacht um das Überleben zu kämpfen.
<G-vec00001-001-s478><craft.schaffen><en> Essence of email marketing: You can craft a unique value proposition and build a solid rapport with your customers through an email marketing campaign.
<G-vec00001-001-s478><craft.schaffen><de> Wesentliches über E-Mail-Marketing: Du kannst über E-Mails ein Alleinstellungsmerkmal schaffen und ein gutes Verhältnis zu Deinen Kunden aufbauen.
<G-vec00001-001-s479><craft.schaffen><en> Tweet Description A light and non-sticky spray that works in partnership with your styler, tong or heated rollers to craft perfectly defined and long lasting curls, while protecting against heat damage.
<G-vec00001-001-s479><craft.schaffen><de> Tweet Description Ein leichtes und nicht klebendes Spray, das mit Ihrem Styler, Lockenstab oder heißen Lockenwicklern arbeitet, um perfekt definierte und langanhaltende Locken zu schaffen und gleichzeitig vor Hitzeschäden zu schützen.
<G-vec00001-001-s480><craft.schaffen><en> Carlson has long been heralded as a master of minimalism, and this full-length demonstrates his ability to craft compelling symphonic compositions while exercising extreme musical frugality.
<G-vec00001-001-s480><craft.schaffen><de> Carlson ist seit langem als Meister des Minimalismus bekannt, und dieses Album zeigt seine Fähigkeit, überzeugende symphonische Kompositionen zu schaffen und gleichzeitig extreme musikalische Sparsamkeit zu üben.
<G-vec00001-001-s481><craft.schaffen><en> Craft compelling customer experiences tailored to wherever customers are in their journeys, and engage with them in exactly the right way at any point along that journey.
<G-vec00001-001-s481><craft.schaffen><de> Schaffen Sie unwiderstehliche Kundenerlebnisse, präzise abgestimmt auf die Stelle, an der sich der Kunde auf der Customer Journey befindet, und sprechen Sie ihn an jedem Punkt auf die genau richtige Art und Weise an.
<G-vec00001-001-s482><craft.schaffen><en> It is our goal to craft a masterpiece out of every single automobile, so that our first-class, customer- care concept, ensures a perfect harmony between prestigious travel and successful business management for our valued clients.
<G-vec00001-001-s482><craft.schaffen><de> Unser Ziel ist es aus jedem gefertigten Van ein Meisterstück zu schaffen, damit in Kombination mit unserem erstklassigen Kundenservice, eine perfekte Balance zwischen prestigevollem Reisen und erfolgreicher Unternehmensführung für unsere wertvollen Kunden ermöglicht wird.
