<G-vec00665-002-s087><crawl.durchkriechen><en> www.However, on its way to freedom, the bee first has to crawl beneath the green stigma.
<G-vec00665-002-s087><crawl.durchkriechen><de> Auf dem Weg in die Freiheit muss die Biene allerdings erst unter der grünen Narbe durchkriechen.
<G-vec00665-002-s088><crawl.durchkriechen><en> They have built a high pyramide, a zip-line and other obstacles to climb on, jump around and crawl through.
<G-vec00665-002-s088><crawl.durchkriechen><de> Sie bauten eine hohe Pyramide, eine Seilbahn und andere Hindernisse, an welchen man hochklettern oder durchkriechen kann.
<G-vec00665-002-s104><crawl.herauskrabbeln><en> Since they cannot crawl out again in the same way, they have to crawl out in a different place, past the pollen sacks and the scar.
<G-vec00665-002-s104><crawl.herauskrabbeln><de> Da sie auf demselben Weg nicht wieder herauskrabbeln können, müssen sie an einer anderen Stelle, vorbei an den Pollensäcken und der Narbe wieder herauskrabbeln.
<G-vec00665-002-s106><crawl.herauskrabbeln><en> The double bed is in a corner, so that the partners in the dark "crawl out " must.
<G-vec00665-002-s106><crawl.herauskrabbeln><de> Das Doppelbett steht in einer Ecke, sodass der Partner im Dunkeln "herauskrabbeln "muss.
<G-vec00665-002-s107><crawl.herauskriechen><en> I lifted the bike a little so that she could crawl out, her aluminum panniers prevented the bike from crushing her leg.
<G-vec00665-002-s107><crawl.herauskriechen><de> Ich hob das Motorrad soweit an, dass sie darunter herauskriechen konnte, ihre Alukoffer verhinderten, dass das Motorrad ihr Bein zerschmetterte.
<G-vec00665-002-s108><crawl.herauskriechen><en> If you attack the Ant Hill, Banished Ants will crawl out and attack you.
<G-vec00665-002-s108><crawl.herauskriechen><de> Solltest du den Ant Hill angreifen, werden Banished Ants herauskriechen und dich angreifen.
<G-vec00665-002-s109><crawl.herumkriechen><en> And what the mightful ones in certain countries still afford themselves, other than the uncorrectnesses up to the corruption, prostitution and political murders, therewith also privately - or through their power - proves in connection with the ongoing scandals of certain state leaders and other people in leading political situations who crawl around and thereby at the expense of the taxpayers squander away their hard-earned tax money.
<G-vec00665-002-s109><crawl.herumkriechen><de> Und was sich die Mächtigen gewisser Länder außer den Unkorrektheiten bis hin zur Korruption, zur Hurerei und zum Politmord dabei auch privaterweise – oder durch ihre Macht – noch leisten, das beweisen die laufenden Skandale im Zusammenhang mit gewissen Staatsführern und sonstigen Leuten, die in führenden politischen Situationen herumkriechen und dabei noch auf Kosten der Steuerzahler deren sauer verdientes Steuergeld verschleudern.
<G-vec00665-002-s110><crawl.herumkriechen><en> He had to crawl around on all fours.
<G-vec00665-002-s110><crawl.herumkriechen><de> Er musste auf allen Vieren herumkriechen.
<G-vec00665-002-s124><crawl.krabbeln><en> Out of breath, I had to crawl contorting myself as best I could towards what I saw on the horizon, which was beginning to emerge and which seemed to be a forest.
<G-vec00665-002-s124><crawl.krabbeln><de> Außer Atem musste ich mich krabbeln lassen, so gut ich konnte, was ich am Horizont sah, das sich zu entwickeln begann und wie ein Wald aussah.
<G-vec00665-002-s125><crawl.krabbeln><en> The Raven antitotem makes a person weak, able to crawl and live on other people's handouts.
<G-vec00665-002-s125><crawl.krabbeln><de> Das Raven-Antitotem macht eine Person schwach, kann krabbeln und auf den Handzetteln anderer Menschen leben.
<G-vec00665-002-s126><crawl.krabbeln><en> When you take Bonny out of the cradle, she starts to crawl.
<G-vec00665-002-s126><crawl.krabbeln><de> Nimmt man Bonny aus der Wiege heraus, dann beginnt sie von ganz allein zu krabbeln.
<G-vec00665-002-s127><crawl.krabbeln><en> His parents noticed he had difficulty learning to crawl.
<G-vec00665-002-s127><crawl.krabbeln><de> Seinen Eltern fiel auf, dass er Mühe hatte mit dem Krabbeln.
<G-vec00665-002-s128><crawl.krabbeln><en> No one is embarrassed to crawl around barefoot in the grass like a young child for the purpose of research into the senses.
<G-vec00665-002-s128><crawl.krabbeln><de> Keinem ist es peinlich, zum Zweck der Sinneserforschung wie Kleinkinder barfuß im Gras zu krabbeln.
<G-vec00665-002-s129><crawl.krabbeln><en> Large white flakes swirling around and letting the world crawl under an ice cold fluffy quilt.
<G-vec00665-002-s129><crawl.krabbeln><de> Große weiße Flocken wirbelten herum und ließen die Welt unter einer eiskalten, flauschigen Steppdecke krabbeln.
<G-vec00665-002-s130><crawl.krabbeln><en> Not only is it eaten by anything that can crawl, it also melts and seeps into the ground during the heat of the day.
<G-vec00665-002-s130><crawl.krabbeln><de> Nicht nur wird es von allem, was krabbeln kann, gegessen, es schmilzt auch und versickert im Boden während der Hitze des Tages.
<G-vec00665-002-s131><crawl.krabbeln><en> More than 5,000 creatures, including sharks, rays, seahorses, octopi, and tropical fish (including entertaining “hey, that’s Nemo!” clownfish) swim, crawl, and slither through their underwater environments here.
<G-vec00665-002-s131><crawl.krabbeln><de> Über 5.000 Geschöpfe, darunter Haie, Rochen, Seepferdchen, Kraken und Tropenfische (einschließlich des unterhaltsamen Clownfischs - „Hey, da schwimmt ja Nemo!“), schwimmen, krabbeln und gleiten hier durch ihre Unterwasserwelt und bieten dabei vielerlei Möglichkeiten, sie zu beobachten.
<G-vec00665-002-s132><crawl.krabbeln><en> As young children we manipulated our own body weight to increase strength, balance and coordination, enabling us to sit, crawl, stand, squat, walk, run and jump.
<G-vec00665-002-s132><crawl.krabbeln><de> Als kleine Kinder haben wir unser eigenes Körpergewicht dazu verwendet, um Kraft, Balance und Koordination aufzubauen, damit wir in der Lage waren zu sitzen, zu krabbeln, zu stehen, die Knie zu beugen, zu gehen, zu laufen und zu springen.
<G-vec00665-002-s133><crawl.krabbeln><en> We can shoot a bow with the arrow repeatedly hitting a distant target, peck away quickly at a computer keyboard without thinking about the keys, crawl, walk, run, twirl around, climb, swim, do somersaults and flips, and perform “simple” tasks such as unscrewing a light bulb, brushing our teeth, and lacing up our shoes—again without thinking.
<G-vec00665-002-s133><crawl.krabbeln><de> Wir können mit Pfeil und Bogen immer wieder das weit entfernte Ziel treffen, sehr schnell und ohne darüber nachzudenken die Tastatur unseres PCs bedienen, krabbeln, gehen, laufen, uns im Kreis drehen, klettern, schwimmen, Purzelbäume und Salti schlagen und „einfache“ Aufgaben, wie das Herausdrehen einer Glühbirne, Zähne putzen, Schuhe schnüren – ohne Nachzudenken – meistern.
<G-vec00665-002-s134><crawl.krabbeln><en> One day I was playing with a coworker’s baby, Rafael, who was trying to crawl.
<G-vec00665-002-s134><crawl.krabbeln><de> Eines Tages spielte ich mit Rafael, dem Baby einer Kollegin, der gerade anfing zu krabbeln.
<G-vec00665-002-s135><crawl.krabbeln><en> The bugs will leave your stuff and crawl into the grass for shade.
<G-vec00665-002-s135><crawl.krabbeln><de> Die Wanzen werden deine Dinge verlassen und ins Gras krabbeln, um Schatten zu suchen.
<G-vec00665-002-s136><crawl.krabbeln><en> V-Connect The new V-Connect is an easy obstacle to run or crawl over.
<G-vec00665-002-s136><crawl.krabbeln><de> V-Connect Der neue V-Connect ist ein einfaches Hindernis zum Laufen oder Krabbeln.
<G-vec00665-002-s137><crawl.krabbeln><en> However, for the time being, the little cub will use its newly acquired sight to get to know its mum better and the 3-room mothering den where it currently lives - after all, the cub has to learn to crawl, which requires seeing to move around.
<G-vec00665-002-s137><crawl.krabbeln><de> Nun ja, vorerst entdeckt das Kleine seine Mama Giovanna und die komfortable „3-Zimmer-Wohnung“, in der sie derzeit leben – schließlich muss das Jungtier erst einmal das Krabbeln lernen, um sich fortzubewegen.
<G-vec00665-002-s138><crawl.krabbeln><en> On the carpet the child is comfortable to move around, crawl.
<G-vec00665-002-s138><crawl.krabbeln><de> Auf dem Teppich kann sich das Kind bequem bewegen und krabbeln.
<G-vec00665-002-s139><crawl.krabbeln><en> Warning notices ATTENTION To prevent possible injury from tangling, this toy must be removed when the child starts trying to crawl on all fours.
<G-vec00665-002-s139><crawl.krabbeln><de> Um mögliche Verletzungen durch Verheddern zu verhindern, ist dieses Spielzeug zu entfernen, wenn das Kind beginnt zu versuchen, auf allen Vieren zu krabbeln.
<G-vec00665-002-s140><crawl.krabbeln><en> When a child begins to crawl, and then walk, it will try to grab the cat, it can hit or throw it in the toy.
<G-vec00665-002-s140><crawl.krabbeln><de> Wenn ein Kind zu krabbeln und dann zu Fuß beginnt, wird es versuchen, die Katze zu greifen, kann es treffen, oder sie in ein Spielzeug werfen.
<G-vec00665-002-s141><crawl.krabbeln><en> I am letting many creepy-crawlies crawl over his ugly body, over his face, his lips.
<G-vec00665-002-s141><crawl.krabbeln><de> Ich lasse viele Insekten über seinen hässlichen Körper, sein Gesicht und seine Lippen krabbeln.
<G-vec00665-002-s142><crawl.krabbeln><en> To prevent possible injury by entanglement, remove the toy from the child's reach, as soon as it tries to crawl or crawl.
<G-vec00665-002-s142><crawl.krabbeln><de> Um mögliche Verletzungen durch Verheddern zu vermeiden, entfernen Sie das Spielzeug aus der Reichweite des Kindes, sobald dieses versucht zu krabbeln oder zu robben.
<G-vec00665-002-s143><crawl.krabbeln><en> By this age, he most likely began to master what experts call "the first kind of active movement," and, quite simply, he began to learn how to crawl.
<G-vec00665-002-s143><crawl.krabbeln><de> In diesem Alter begann er wahrscheinlich zu beherrschen, was Experten "die erste Art von aktiver Bewegung" nennen, und ganz einfach begann er zu lernen, wie man krabbelt.
<G-vec00665-002-s144><crawl.krabbeln><en> Drag and drop the commands from the bottom over the puppy to make him jump, crawl, roll over, and push.
<G-vec00665-002-s144><crawl.krabbeln><de> Ziehe die Befehle vom unteren Rand auf das Hündchen, damit er springt, krabbelt, sich rollt und schiebt.
<G-vec00665-002-s145><crawl.krabbeln><en> A musically gifted baby may crawl to the stereo when a particular tune is being played, or may 'find' Middle C repeatedly when seemingly striking piano keys at random.
<G-vec00665-002-s145><crawl.krabbeln><de> Ein musikalisch begabtes Baby krabbelt vielleicht zur Stereoanlage, wenn eine bestimmte Melodie gespielt wird, oder es “findet” das C mehrmals hintereinander, obwohl es scheinbar nur wahllos auf den Tasten herumklimpert.
<G-vec00665-002-s148><crawl.kriechen><en> I started the first attempts to crawl and lifted my butt.
<G-vec00665-002-s148><crawl.kriechen><de> Ich habe zum ersten Mal versucht zu kriechen und habe meinen Hintern hochgehoben.
<G-vec00665-002-s149><crawl.kriechen><en> into some caving gear and get ready to crawl and climb around Budapest's famous caves for 2,5 hours with a guide.
<G-vec00665-002-s149><crawl.kriechen><de> Kriechen und klettern Sie 2,5 Stunden lang in Budapests berühmte Höhlen mit einem Führer.
<G-vec00665-002-s150><crawl.kriechen><en> Thanks to the suit, Flash can crawl on walls.
<G-vec00665-002-s150><crawl.kriechen><de> Dank des Anzugs kann Flash an Wänden kriechen.
<G-vec00665-002-s151><crawl.kriechen><en> In the cave one can partly walk standing straight up, but often one has to crawl or climb through narrow passages. Visitors must not suffer from claustrophobia and be in quite good physical shape.
<G-vec00665-002-s151><crawl.kriechen><de> Zum Teil kann man in den Gängen aufrecht gehen, manchmal muss man aber auch durch enge Passagen kriechen oder klettern – Besucher sollten also keine Platzangst haben und eine gewisse Fitness mitbringen.
<G-vec00665-002-s152><crawl.kriechen><en> Russ just has to walk, or better duck and crawl between two others with light.
<G-vec00665-002-s152><crawl.kriechen><de> Russ muss also zwischen zwei anderen mit Licht laufen oder besser bücken und kriechen.
<G-vec00665-002-s153><crawl.kriechen><en> And today I want him to be my little beetle that has to crawl over the ground and to flap his wings.
<G-vec00665-002-s153><crawl.kriechen><de> Heute möchte ich, dass er ein kleiner Käfer ist der über den Boden kriechen und mit den Flügeln flattern muss.
<G-vec00665-002-s154><crawl.kriechen><en> Around the corner climb and crawl through the gap.
<G-vec00665-002-s154><crawl.kriechen><de> Dort um die Ecke klettern, und durch den Spalt kriechen.
<G-vec00665-002-s155><crawl.kriechen><en> Besides our activities there are also lots of possibilities to play in the Tollhaus: On the large tower for playing and climbing the kids can slide, climb, crawl and hang along.
<G-vec00665-002-s155><crawl.kriechen><de> Auch sonst erwarten die Kids im TOLLHAUS vielfältige Spielmöglichkeiten: Auf dem großen Spiel- und Kletterturm können sie rutschen, klettern, kriechen und hangeln.
<G-vec00665-002-s156><crawl.kriechen><en> MULDER: I was told once that the best way to regenerate body heat was to crawl naked into a sleeping bag with somebody else who's already naked.
<G-vec00665-002-s156><crawl.kriechen><de> MULDER: Ich habe mal gehört der beste Weg sich aufzuwärmen, wäre nackt in einen Schlafsack zu kriechen, zu jemandem, der schon nackt darin liegt.
<G-vec00665-002-s157><crawl.kriechen><en> Mia learned almost the same day to crawl stairs up and down.
<G-vec00665-002-s157><crawl.kriechen><de> Mia lernte fast am gleichen Tag die Treppen auf und runter zu kriechen.
<G-vec00665-002-s158><crawl.kriechen><en> They forced Shi Yingchun to "walk" again but she refused so they forced her to crawl, and again she refused.
<G-vec00665-002-s158><crawl.kriechen><de> Sie zwangen Shi Yingchun, noch einmal so zu „gehen“, doch sie weigerte sich, so dass sie sie zwangen, zu kriechen und auch das verweigerte sie.
<G-vec00665-002-s159><crawl.kriechen><en> In our aquariums, however, sometimes animals are kept, who like to crawl in caves and crevices.
<G-vec00665-002-s159><crawl.kriechen><de> In unseren Aquarien werden aber manchmal Tiere gehalten, die gerne in Höhlen und Spalten kriechen.
<G-vec00665-002-s160><crawl.kriechen><en> After several minutes of this torture, the four limbs are disabled and the victim is unable to even crawl or to put on clothes.
<G-vec00665-002-s160><crawl.kriechen><de> Nach wenigen Minuten dieser Folter sind die Gliedmaßen des Opfers behindert, so dass es danach noch nicht einmal kriechen und sich seine Kleidung anziehen kann.
<G-vec00665-002-s161><crawl.kriechen><en> He began to crawl, as blood trickled down.
<G-vec00665-002-s161><crawl.kriechen><de> Er fing an zu kriechen, während das Blut herunterlief.
<G-vec00665-002-s162><crawl.kriechen><en> Rush to the hare speed, not to crawl like a turtle.
<G-vec00665-002-s162><crawl.kriechen><de> Ansturm auf die Hasen Geschwindigkeit, nicht wie eine Schildkröte zu kriechen.
<G-vec00665-002-s163><crawl.kriechen><en> Negotiations concerning this matter resulted in the agreement that Aristotle, as a sign of his immortal love, was to crawl on all fours and in doing so, to allow Phyllis to sit on his back as if she were riding a horse or to put it more appropriate, as if she were riding an old donkey…
<G-vec00665-002-s163><crawl.kriechen><de> Diesbe-zügliche Verhandlungen endeten mit der Überein-kunft, daß Aristoteles als Zeichen seiner „unend-lichen Liebe“ auf allen Vieren kriechen sollte und Phyllis dabei – wie beim Reiten eines Pferdes oder passender ausgedrückt, beim Reiten eines alten Esels – auf seinem Rücken sitzen durfte.
<G-vec00665-002-s164><crawl.kriechen><en> The animals crawl across the funnel-shaped spathe or the upright spadix into the inflorescence, in order to deposit their eggs.
<G-vec00665-002-s164><crawl.kriechen><de> Die Tiere kriechen über das trichterförmige Hochblatt oder die aufrechte Blütenstandsachse in das Innere der Blume hinab, um dort ihre Eier abzulegen.
<G-vec00665-002-s165><crawl.kriechen><en> Grab the ledge and crawl into the gap.
<G-vec00665-002-s165><crawl.kriechen><de> Nach der Kante greifen und in den Spalt kriechen.
<G-vec00665-002-s166><crawl.kriechen><en> They crawl up on my bed, wrap their fingers round my throat.
<G-vec00665-002-s166><crawl.kriechen><de> Sie kriechen auf mein Bett, wickeln ihre Finger um meinen Hals.
<G-vec00665-002-s169><crawl.kriechen><en> Crawl to where the ladder is.
<G-vec00665-002-s169><crawl.kriechen><de> Kriecht bis zur Leiter.
<G-vec00665-002-s170><crawl.kriechen><en> If left in a sealed chamber, the iteration will crawl in circles and eventually slow as necrosis sets in.
<G-vec00665-002-s170><crawl.kriechen><de> Wenn sie in einer versiegelten Kammer gehalten wird, kriecht die Iteration im Kreis und wird unweigerlich langsamer, sobald die Nekrose einsetzt.
<G-vec00665-002-s171><crawl.kriechen><en> Power Up (upper body strength) Crawl through the gap and collect the V-Packer Ammo on the other side.
<G-vec00665-002-s171><crawl.kriechen><de> Power Up (Oberkörper) Kriecht hindurch und sammelt dort die V-Packer Ammo ein.
<G-vec00665-002-s172><crawl.kriechen><en> Arrogance causes the soul to crawl away into the flesh, and there the ability to perceive spiritual things is diminished and the spirit inside the soul becomes invisible.
<G-vec00665-002-s172><crawl.kriechen><de> Arroganz bewirkt, daß die Seele ins Fleisch kriecht, und dort ist dann die Fähigkeit geistige Dinge wahrzunehmen vermindert und der Geist innerhalb der Seele wird unsichtbar.
<G-vec00665-002-s173><crawl.kriechen><en> 25 So God made the wildlife of the earth according to their kinds, the livestock according to their kinds, and creatures that crawl on the ground according to their kinds. And God saw that it was good.
<G-vec00665-002-s173><crawl.kriechen><de> Und Gott machte die Tiere auf Erden nach seiner Art, und das Vieh nach seiner Art, und alles, was auf der Erde kriecht, nach seiner Art, und Gott sah, dass es gut war.
<G-vec00665-002-s174><crawl.kriechen><en> Now crawl into the gap on the right.
<G-vec00665-002-s174><crawl.kriechen><de> Kriecht nun in den Spalt rechts.
<G-vec00665-002-s175><crawl.kriechen><en> He will not crawl on the floor (even on wet), which means that a pregnant woman is less likely to slip and fall.
<G-vec00665-002-s175><crawl.kriechen><de> Er kriecht nicht auf den Boden (auch nicht nass), was bedeutet, dass eine schwangere Frau weniger leicht ausrutscht und fällt.
<G-vec00665-002-s176><crawl.kriechen><en> A dutiful son who does not flatter his parents, a decent civil servant who does not crawl before his master, these officials and sons are the noblest.
<G-vec00665-002-s176><crawl.kriechen><de> Ein pflichtbewußter Sohn, der seinen Eltern nicht schmeichelt, ein anständiger Beamter, der vor seinem Herrn nicht kriecht – diese Beamten und Söhne sind die edelsten.
<G-vec00665-002-s177><crawl.kriechen><en> Crawl through the narrow passage and drop down on the other side.
<G-vec00665-002-s177><crawl.kriechen><de> Kriecht hindurch und lasst euch auf der anderen Seite hinab.
<G-vec00665-002-s180><crawl.robben><en> In the past, miners literally had to crawl through the dust to travel through the mine.
<G-vec00665-002-s180><crawl.robben><de> Früher mussten die Bergleute buchstäblich durch den Staub robben, um durch das Bergwerk zu gelangen.
<G-vec00665-002-s181><crawl.robben><en> With amazing ease and elegance, the four performers twist and tumble, crawl, clamber and lift themselves through the network.
<G-vec00665-002-s181><crawl.robben><de> Kronen Zeitung Mit erstaunlicher Sicherheit und Eleganz turnen, robben, klettern, hanteln die vier Performer durch das Netzwerk.
<G-vec00665-002-s182><crawl.robben><en> To prevent possible injury by entanglement, remove the toy from the child's reach, as soon as it tries to crawl or crawl.
<G-vec00665-002-s182><crawl.robben><de> Um mögliche Verletzungen durch Verheddern zu vermeiden, entfernen Sie das Spielzeug aus der Reichweite des Kindes, sobald dieses versucht zu krabbeln oder zu robben.
<G-vec00665-002-s187><crawl.verkriechen><en> If a young doesn't have any desire to the seriousness of the life and wants to crawl away in the construction, the elderly immediately tow out it again and bring continuously new living loot, at which the puppies can now exercise seizing and killing.
<G-vec00665-002-s187><crawl.verkriechen><de> Wenn ein Junges keine Lust zum Ernst des Lebens hat und sich im Bau verkriechen will, schleppen die Alten es sofort wieder heraus und bringen laufend neue lebende Beute, an der sich die Welpen nun im Ergreifen und Töten üben können.
<G-vec00665-002-s188><crawl.verkriechen><en> One strategy is to crawl into a hole: you and Sally can stop sharing information for a week or two.
<G-vec00665-002-s188><crawl.verkriechen><de> Eine Strategie ist, sich in ein Loch zu verkriechen: Sie und Sally können für eine Woche oder zwei den Informationsaustausch einstellen.
<G-vec00665-002-s189><crawl.verkriechen><en> These are proud and endlessly domineering spirits, before whom everything has to crawl into the dust, and only do their bidding.
<G-vec00665-002-s189><crawl.verkriechen><de> Diese Geister sind stolz und über die Maßen herrschsüchtig; vor ihnen soll sich alles bis in den Staub verkriechen und nur das tun, was sie wollen.
<G-vec00665-002-s190><crawl.verkriechen><en> When it was actually happening though, I wanted to crawl inside myself.
<G-vec00665-002-s190><crawl.verkriechen><de> Im Moment als es geschah, wollte ich mich in mir selbst verkriechen.
<G-vec00665-002-s191><crawl.verkriechen><en> It’s the time when you like to crawl up on your sofa like a little marmot, in your comfy large sweater, a good book in one hand and in the other a warm cup of tea and a pair of cozy socks to keep you warm on cold November days.
<G-vec00665-002-s191><crawl.verkriechen><de> In dieser Zeit verkriecht man sich gerne mit einem bequemen, dicken Pullover auf dem Sofa, liesst ein gutes Buch, hält in der anderen Hand eine warme Tasse Tee und trägt warme Wollsocken, die einem die Füße in kalten Novembertagen warm halten.
<G-vec00665-002-s192><crawl.verkriechen><en> When people are sad, it's easy to want to crawl into a cave and want to be alone.
<G-vec00665-002-s192><crawl.verkriechen><de> Wenn jemand traurig ist, ist es normal, dass er sich verkriecht und allein sein will.
