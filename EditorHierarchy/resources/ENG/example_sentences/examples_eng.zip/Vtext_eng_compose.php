<G-vec00366-002-s019><compose.(sich)_aussuchen><en> As you compose a photograph with the EOS M, the camera’s Scene Intelligent Auto technology analyses the subject too, evaluating colour, brightness, movement and even detecting the presence of people.
<G-vec00366-002-s019><compose.(sich)_aussuchen><de> Wenn Sie mit der EOS M das Motiv aussuchen, analysiert die Automatische Motiverkennung die Szene hinsichtlich Farbe, Helligkeit und Bewegung – sie erkennt sogar, ob sich Personen im Bild befinden.
<G-vec00366-002-s020><compose.(sich)_aussuchen><en> As you compose a photograph with the EOS M, the camera's Scene Intelligent Auto technology analyses the subject too, evaluating colour, brightness, movement and even detecting the presence of people.
<G-vec00366-002-s020><compose.(sich)_aussuchen><de> Wenn Sie mit der EOS M das Motiv aussuchen, analysiert die Automatische Motiverkennung die Szene hinsichtlich Farbe, Helligkeit und Bewegung - sie erkennt sogar, ob sich Personen im Bild befinden.
<G-vec00366-002-s019><compose.aussuchen><en> As you compose a photograph with the EOS M, the camera’s Scene Intelligent Auto technology analyses the subject too, evaluating colour, brightness, movement and even detecting the presence of people.
<G-vec00366-002-s019><compose.aussuchen><de> Wenn Sie mit der EOS M das Motiv aussuchen, analysiert die Automatische Motiverkennung die Szene hinsichtlich Farbe, Helligkeit und Bewegung – sie erkennt sogar, ob sich Personen im Bild befinden.
<G-vec00366-002-s020><compose.aussuchen><en> As you compose a photograph with the EOS M, the camera's Scene Intelligent Auto technology analyses the subject too, evaluating colour, brightness, movement and even detecting the presence of people.
<G-vec00366-002-s020><compose.aussuchen><de> Wenn Sie mit der EOS M das Motiv aussuchen, analysiert die Automatische Motiverkennung die Szene hinsichtlich Farbe, Helligkeit und Bewegung - sie erkennt sogar, ob sich Personen im Bild befinden.
<G-vec00366-002-s021><compose.bilden><en> They compose antioxidant flavonoids such as ß-carotene, lutein, and zea-xanthin.
<G-vec00366-002-s021><compose.bilden><de> Sie bilden Antioxidans Flavonoide wie ß-Carotin, Lutein und Zeaxanthin.
<G-vec00366-002-s022><compose.bilden><en> While BBB paper composes a similar portion in both markets, reverse‑Yankee bonds (U.S. companies issuing in euros) have accounted for more than a quarter of the growth of the euro‑denominated BBB market over the past five years and now compose around 20% of the total.
<G-vec00366-002-s022><compose.bilden><de> Während an beiden Märkten ein ähnlicher Anteil auf BBB-Papiere entfällt, sind Reverse-Yankee-Bonds (auf Euro lautende Anleihen von US-Unternehmen) für mehr als ein Viertel des Wachstums der Euro-Anleihen mit BBB-Rating in den letzten fünf Jahren verantwortlich und bilden inzwischen rund 20% dieses Marktsegments.
<G-vec00366-002-s023><compose.bilden><en> Straight-lined, mid-speed beats carried from a warm, deep bass compose the structure for this rather mild melancholy
<G-vec00366-002-s023><compose.bilden><de> Geradelinige, mittelschnelle Beats, getragen von einem warmen, tiefen Bass, bilden das Gerüst für diesen eher sanft-melancholischen Song.
<G-vec00366-002-s024><compose.bilden><en> Thinking is the final part in the sequence of processes that compose nature.
<G-vec00366-002-s024><compose.bilden><de> Das Denken ist das letzte Glied in der Reihenfolge der Prozesse, die die Natur bilden.
<G-vec00366-002-s025><compose.bilden><en> Those three madrasahs compose a unique ensemble and appear to be the one of the brightest construction of great Persian Architecture.
<G-vec00366-002-s025><compose.bilden><de> Diese drei Medresen bilden ein einzigartiges Ensemble und sind eines der auffälligsten Bauwerke der großen persischen Architektur.
<G-vec00366-002-s026><compose.bilden><en> The ontological, linguistic-analytical, and phenomenological philosophical insights presented in Chapter One compose the lens through which five benchmark Bundesverfassungsgericht cases – on abortion, life imprisonment, transsexuals, state response to terrorist attacks, and the guarantee of a dignified subsistence minimum – are analyzed in Chapter Two.
<G-vec00366-002-s026><compose.bilden><de> Die ontologischen, sprachlich-analytischen und phänomenologischen philosophischen Erkenntnisse, vorgestellt im ersten Kapitel, bilden die Linse, durch die fünf maßgebliche Fälle des Bundesverfassungsgerichtes – über Abtreibung, lebenslange Freiheitsstrafe, Transsexualität, staatliche Reaktion auf Terroranschläge und die Gewährleistung eines menschenwürdigen Existenzminimums – im zweiten Kapitel analysiert werden.
<G-vec00366-002-s027><compose.bilden><en> Two volumes compose the main residence.
<G-vec00366-002-s027><compose.bilden><de> Zwei Bände bilden den Hauptwohnsitz.
<G-vec00366-002-s028><compose.bilden><en> In Poland there are approximately one hundred thousand non-governmental organisations (associations, foundations and social economy actors) which compose the third sector between free market dynamics and the state.
<G-vec00366-002-s028><compose.bilden><de> In Polen gibt es ungefähr 100.000 Nichtregierungsorganisationen (Verbände, Stiftungen und sozialwirtschaftliche Akteure), die zwischen der Dynamik des freien Marktes und dem Staat den Dritten Sektor bilden.
<G-vec00366-002-s029><compose.bilden><en> The groups have more than fifty thousand militants and compose important part of the Syrian moderate opponents.
<G-vec00366-002-s029><compose.bilden><de> Die Gruppen haben mehr als fünfzigtausend Militanten und bilden einen wichtigen Teil der syrischen gemäßigten Rebellen.
<G-vec00366-002-s030><compose.bilden><en> Together, we compose a potent force for genuine spiritual education.
<G-vec00366-002-s030><compose.bilden><de> Gemeinsam bilden wir eine starke Kraft für authentische geistige Bildung.
<G-vec00366-002-s031><compose.bilden><en> The approximately 8000 pieces compose an invaluable ethnographic fund ’readable’ in the frame of the folk art, folk costume, ethnography and photo-documents collections.
<G-vec00366-002-s031><compose.bilden><de> Die rund 8000 Stück bilden eine wertvolle Sammlung von Volkkunst, Trachten, Ethnographie, ein Foto-Hintergrund von unschätzbarem Wert als auch eine Reihe von ethnographischen Sammlungen von Dokumenten.
<G-vec00366-002-s032><compose.bilden><en> Foremost among the various energies and forces that compose and condition our existence, are the seven major types of Divine energy or force, i.e., the Seven Rays.
<G-vec00366-002-s032><compose.bilden><de> Unter den verschiedenen Energien und Kräften, die unsere Existenz bilden und bedingen, sind die sieben Haupttypen göttlicher Energie oder Kraft am wichtigsten, nämlich die sieben Strahlen.
<G-vec00366-002-s033><compose.bilden><en> When general conditions and the degree of organisational, political and tactical solidity of the class party reach a point where the general struggle for power is unleashed, the party which has led the revolutionary class to victory through the social war, leads it likewise in the fundamental task of breaking and demolishing all the military and administrative organs which compose the capitalist state. This demolition also strikes at the network of organs, whatever they may be, which pretend to represent the various opinions or interests through the intermediary of bodies of delegates.
<G-vec00366-002-s033><compose.bilden><de> Wenn die allgemeinen Bedingungen und die organisatorische, politische und praktische Festigkeit der Klassenpartei es zum Ausbruch des allgemeinen Kampfes für die Macht bringen, so leitet die Partei die revolutionäre Klasse, nachdem sie sie siegreich im sozialen Krieg geführt hat, auch bei der Ausführung der grundsätzlichen Aufgabe: die Zerschlagung und Vernichtung der Organe die den kapitalistischen Staat bilden, das heißt der bewaffneten Verteidigungsorgane und des allgemeinen Verwaltungsapparates, so wie aller angeblichen Vertretungen der Meinungen oder der Berufsinteressen durch Abgeordnetenorgane, welche sie auch sein.
<G-vec00366-002-s034><compose.bilden><en> In this perspective, the world is perceived as an intelligible whole, unified by the common reference of the beings that compose it to a divine originating principle, to a Logos.
<G-vec00366-002-s034><compose.bilden><de> In dieser Perspektive wird die Welt wahrgenommen als ein erkennbares Ganzes, geeint durch den gemeinsamen Bezug der Seinswirklichkeiten, die dieses Ganze bilden, zu einem göttlichen stiftenden Prinzip, einem Logos.
<G-vec00366-002-s035><compose.bilden><en> Our primary aim is to compose the ultimate top 50 of C64 games.
<G-vec00366-002-s035><compose.bilden><de> Unser Primärziel ist, die entscheidende Top-50 der Spiele C64 zu bilden.
<G-vec00366-002-s036><compose.bilden><en> The great talent of the musicians that compose this group, permits them to interpret the Baroque, Classical and Modern repertory with virtuosity, involving emotionality and interpretive variety, the keys to success from the audience and the critics, obtained in every concert.
<G-vec00366-002-s036><compose.bilden><de> Das große Talent der Musiker, die diese Gruppe bilden, erlaubt es ihnen, das Repertoire Barock, Klassik und Moderne virtuos zu interpretieren, wobei Emotionalität und Interpretationsvielfalt die Schlüssel zum Erfolg des Publikums und der Kritiker sind, die in jedem Konzert erreicht werden.
<G-vec00366-002-s056><compose.darstellen><en> Peer System B.V. cooperates with several secondary suppliers that compose different parts of the system.
<G-vec00366-002-s056><compose.darstellen><de> Peer System B.V. arbeitet zusammen mit einige Zulieferbetriebe, welche die verschiedene Unterteile des Systems darstellen.
<G-vec00366-002-s057><compose.darstellen><en> Michael Porter’s “Five Forces” from Competitive Strategy and PEST analysis can help explore environmental factors that might compose Opportunities or Threats.
<G-vec00366-002-s057><compose.darstellen><de> Michael Porters " Fünf Kräfte " aus der Competitive Strategy- und PEST-Analyse können dabei helfen, Umweltfaktoren zu erforschen, die Chancen oder Bedrohungen darstellen könnten.
<G-vec00366-002-s058><compose.denen><en> Each of the rooms that compose the Museum of Peasant Culture is devoted to a particular activity.
<G-vec00366-002-s058><compose.denen><de> Die verschiedenen Räume, aus denen das Museum des Bäuerlichen Lebens besteht, sind jeder einer besonderen Aktivität gewidmet.
<G-vec00366-002-s059><compose.denen><en> Inside the field Cardinal took a little trip into the world of the Roma, visiting containers and trailers of various families that compose the mosaic population of nearly 1000 residents of Via di Salone: Roma from Serbia, Bosnia, Romania and Montenegro.
<G-vec00366-002-s059><compose.denen><de> Im Lager legte der Kardinal eine kleine Reise in die Welt der Roma zurück und besuchte Container und Wohnwägen verschiedener Familien, in denen das Bevölkerungsmosaik von fast 1.000 Bewohnern von Via di Salone lebt: Roma aus Serbien, Bosnien, Rumänien und Montenegro.
<G-vec00366-002-s060><compose.denen><en> Substitutions can be made either within a Matchday, (during the different days that compose the Matchday) or between a Matchday and another;
<G-vec00366-002-s060><compose.denen><de> Auswechslungen können entweder während eines Spieltags (zwischen den einzelnen Tagen, aus denen ein Spieltag besteht) oder zwischen einem Spieltag und dem nächsten vorgenommen werden.
<G-vec00366-002-s067><compose.entwerfen><en> So the idea grew up slowly – actually visually – to compose several places that don’t belong together, but are somehow united by a single camera movement.
<G-vec00366-002-s067><compose.entwerfen><de> Daraus entwickelte sich die Idee Orte zu entwerfen, die nicht zusammengehören, aber durch eine einzige Kamerabewegung verbunden werden.
<G-vec00366-002-s068><compose.entwerfen><en> Creativity was the focus on the first competition day of the Grand Prix Gelatissimo: the participants were asked to compose gelato in a fantasy flavour.
<G-vec00366-002-s068><compose.entwerfen><de> Am ersten Wettbewerbstag des Grand Prix Gelatissimo stand die Kreativität im Vordergrund: Die Teilnehmer stellten sich der Aufgabe, ein Eis in der Geschmacksrichtung Fantasy Flavour zu entwerfen.
<G-vec00366-002-s086><compose.erstellen><en> Compose a memo with this template.
<G-vec00366-002-s086><compose.erstellen><de> Erstellen Sie mit dieser Vorlage ein professionelles Memo.
<G-vec00366-002-s087><compose.erstellen><en> Compose an email in the inbox to start a conversation with your contacts.
<G-vec00366-002-s087><compose.erstellen><de> Erstellen Sie eine E-Mail im Posteingang, um eine Konversation mit Ihren Kontakten zu beginnen.
<G-vec00366-002-s088><compose.formen><en> Design: Studio Klass Elements in bent glass compose “Foulard” the shelves.
<G-vec00366-002-s088><compose.formen><de> Design: Studio Klass Elemente aus gebogenem Glas formen das Regal Foulard.
<G-vec00366-002-s089><compose.formen><en> Moorish Pool and its path towards Canyon of the Vultures compose one of the most special places of tourist offer of the Province of Málaga.
<G-vec00366-002-s089><compose.formen><de> Der Maurenteich und sein Wanderweg in Richtung des Cañon des Aasgeiers formen eines der einzigartigsten Plätze, die die Provinz Málaga zu bieten hat.
<G-vec00366-002-s090><compose.formen><en> No ruler could ever command men to fashion the first tools, first use fire, invent the telescope and the steam engine, or compose the Iliad.
<G-vec00366-002-s090><compose.formen><de> Kein Herrscher konnte den Menschen je gebieten, die ersten Werkzeuge zu formen, sich des Feuers zu bedienen, Teleskop und Dampfmaschine zu erfinden oder die Ilias zu dichten.
<G-vec00366-002-s091><compose.formulieren><en> Composing Texts If you know German well, you may not take to write texts first in English and then to translate them, but you compose them right away in the target language.
<G-vec00366-002-s091><compose.formulieren><de> Texte verfassen Wenn Sie gut Englisch oder Französisch können, halten Sie sich meist nicht damit auf, Texte erst auf Deutsch zu schreiben und dann zu übersetzen, sondern formulieren sie gleich in der Fremdsprache.
<G-vec00366-002-s092><compose.formulieren><en> The first sentence is so hard to compose.
<G-vec00366-002-s092><compose.formulieren><de> Der erste Satz ist immer schwer zu formulieren.
<G-vec00366-002-s145><compose.komponieren><en> Young Gioachino Rossini was inspired by Goldoni’s comedy “Il matrimonio per concorso” to compose his energetic early work “La Gazzetta” – described as a dramma per musica but in fact a true opera buffa – which presents a humorous take on the influence of newspaper and media on the lives of people.
<G-vec00366-002-s145><compose.komponieren><de> Frei nach Goldonis Komödie „Il matrimonio per concorso“ komponierte der junge Gioachino Rossini sein schwungvolles Frühwerk „La Gazzetta“ – mit dramma per musica betitelt, doch eigentlich eine wahre opera buffa – in dem der Einfluss der Zeitung und der Medien auf das Leben der Menschen mit viel Humor persifliert wird.
<G-vec00366-002-s146><compose.komponieren><en> Prince would then compose the swan song of this period.
<G-vec00366-002-s146><compose.komponieren><de> Prince komponierte den Abgesang auf diese Zeit.
<G-vec00366-002-s147><compose.komponieren><en> After the Second World War she withdrew almost completely from public musical life, but continued to compose for the rest of her life.
<G-vec00366-002-s147><compose.komponieren><de> Nach dem zweiten Weltkrieg zog sie sich fast völlig aus dem öffentlichen Musikleben zurück, komponierte aber bis an ihr Lebensende weiter.
<G-vec00366-002-s065><compose.schreiben><en> Use your "other" computer to to log into your GMX Account. In your inbox, click the lock icon next to the "compose" button.
<G-vec00366-002-s065><compose.schreiben><de> Loggen Sie sich auf dem gewünschten Computer in Ihren GMX Account ein und klicken Sie im Posteingang auf das Schloss-Symbol neben der Schaltfläche E-Mail schreiben.
<G-vec00366-002-s066><compose.schreiben><en> Press [] → Compose.
<G-vec00366-002-s066><compose.schreiben><de> Drücken Sie [] → E-Mail schreiben.
<G-vec00366-002-s185><compose.setzen><en> "Maybe should soon rise you from the tub, the wet things depart, some dry in and itself before the open fire compose.", Robbie requested them, after an infinite while in which they had observed themselves in silence.
<G-vec00366-002-s185><compose.setzen><de> "Vielleicht sollten Sie bald aus der Wanne steigen, die nassen Sachen ausziehen, ein paar trockene an und sich vor das Kaminfeuer setzen", forderte Robbie sie, nach einer unendlichen Weile, in der sie sich schweigend beobachtet hatten, auf.
<G-vec00366-002-s186><compose.setzen><en> "Bad liars also compose such a look on", she said.
<G-vec00366-002-s186><compose.setzen><de> "Schlechte Lügner setzen auch solch eine Miene auf", sagte sie.
<G-vec00366-002-s197><compose.stellen><en> Compose your Cerchio Ghisallo modular kit in OCHRE colour starting with: Sprinter or Sport wheels FIRE MARKED laced with Novatec silver flip-flop hubs and Brooks B17 saddle and complete with: Terry aluminium/wood handlebar, Shorty mudguards, pedals..
<G-vec00366-002-s197><compose.stellen><de> Stellen Sie Ihr Cerchio Ghisallo kit modular in der Farbe OKKER individuell zusammen mit: Sport oder Sprint Laufrädern, Brandzeichen mit Novatec Flip-Flop Silber Nabenset und Brooks B17 Sattel und komplett mit: Terry Holzlenker mit Aluminiumschicht,..
<G-vec00366-002-s198><compose.stellen><en> Compose your Autodesk Vault Office 2020 subscription yourself or by contacting our service desk on +31 88 9322 333.
<G-vec00366-002-s198><compose.stellen><de> Stellen Sie Ihr Autodesk Vault 2020-Abonnement auf einfache Weise selbst zusammen, oder nehmen Sie unter +31 88 9322 333 Kontakt mit unserem Servicedesk auf.
<G-vec00366-002-s199><compose.stellen><en> Compose your own brochure
<G-vec00366-002-s199><compose.stellen><de> Stellen Sie Ihre eigene Broschüre zusammen.
<G-vec00366-002-s222><compose.verfassen><en> Compose test cases, organize these in test scenarios and execute them manually within the team.
<G-vec00366-002-s222><compose.verfassen><de> Verfassen Sie Testfälle, organisieren Sie diese in Testszenarien und führen Sie diese im Team manuell durch.
<G-vec00366-002-s223><compose.verfassen><en> Compose your message.
<G-vec00366-002-s223><compose.verfassen><de> Verfassen Sie Ihre Nachricht.
<G-vec00366-002-s224><compose.verfassen><en> Compose a team of cartoon heroes, each with their own style of play, backstories and grudges.
<G-vec00366-002-s224><compose.verfassen><de> Verfassen Sie eine Team von Comic-Helden, jede mit ihren eigenen Spielstile, Hintergrundgeschichten und Groll.
<G-vec00366-002-s225><compose.verfassen><en> Address and compose your email.
<G-vec00366-002-s225><compose.verfassen><de> Adressieren und verfassen Sie die E-Mail.
<G-vec00366-002-s226><compose.verfassen><en> Search for an article on a given subject, then compose an email to the author asking to reuse or link to the piece.
<G-vec00366-002-s226><compose.verfassen><de> Suchen Sie nach einem Artikel zu einem bestimmten Thema und verfassen Sie eine E-Mail an den Autor, in der Sie darum gebeten werden, das Stück wiederzuverwenden oder zu verlinken.
<G-vec00366-002-s227><compose.verfassen><en> Compose images of products, using video or still cameras, lighting equipment, props, or photo or video editing software.
<G-vec00366-002-s227><compose.verfassen><de> Verfassen Sie Bilder von Produkten, verwenden Sie Video- oder Standbildkameras, Beleuchtungsgeräte, Requisiten oder Foto- oder Videobearbeitungssoftware.
<G-vec00366-002-s228><compose.verfassen><en> 1 – Compose the mail – Use HTML formatting while you compose the mail.
<G-vec00366-002-s228><compose.verfassen><de> 1 – Verfassen Sie die Mail – Verwenden Sie HTML-Formatierung, während Sie die Mail verfassen.
<G-vec00366-002-s254><compose.zusammensetzen><en> is a software plug-in to create, edit, compose, or convert bitmap images.
<G-vec00366-002-s254><compose.zusammensetzen><de> ImageMagick-Software ist ein Software-Plug-in zum Erstellen, Bearbeiten, Zusammenzusetzen oder Konvertieren von Bitmapbildern.
<G-vec00366-002-s255><compose.zusammensetzen><en> This application enables employees to compose specific drawings from an existing library of graphic elements (details).
<G-vec00366-002-s255><compose.zusammensetzen><de> Diese Anwendung ermöglicht den Mitarbeitern spezifische Zeichnungen aus der vorhandenen Bibliothek von grafischen Elementen (Details) zusammenzusetzen.
<G-vec00366-002-s183><compose.zusammenstellen><en> You also have the possibility to compose your own menus according to your tastes; starter, main course, dessert (drinks not included in the price of the menu). Formulas
<G-vec00366-002-s183><compose.zusammenstellen><de> Sie haben natürlich die Möglichkeit, Ihre Menüs - Vorspeise, Hauptgericht, Dessert - selbst je nach Geschmack zusammenstellen (Getränke sind nicht im Menüpreis enthalten).
<G-vec00366-002-s184><compose.zusammenstellen><en> The built in report generator allows users to design and compose their specific output and analyses, and save these for future use.
<G-vec00366-002-s184><compose.zusammenstellen><de> Mit dem integrierten Berichtsgenerator können Nutzer selbst ihre spezifischen Berichte und Analysen zusammenstellen und diese zur weiteren Verwendung abspeichern.
