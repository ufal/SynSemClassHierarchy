<G-vec00297-002-s589><determine.bestimmen><en> Unless agreed otherwise, Supplier is entitled to determine the way of shipment (especially transport company, shipment route and packaging).
<G-vec00297-002-s589><determine.bestimmen><de> Soweit nicht etwas anderes bestimmt ist, ist der AN berechtigt, die Art der Versendung (insbesondere Transportunternehmen, Versandweg und Verpackung) selbst zu bestimmen.
<G-vec00297-002-s590><determine.bestimmen><en> Amid international criticism, the Dominican government has repeatedly argued that it has a right to determine who qualifies for citizenship.
<G-vec00297-002-s590><determine.bestimmen><de> Trotz zunehmender internationaler Kritik hat die dominikanische Regierung mehrfach dafür plädiert [5], selbst bestimmen zu können, wer die Voraussetzungen für eine Staatsbürgerschaft erfüllt und wer nicht.
<G-vec00297-002-s591><determine.bestimmen><en> Accommodation Leisure ESL offers a programme which allows you to determine the intensity of the course and its content as well as your personal or professional objectives.
<G-vec00297-002-s591><determine.bestimmen><de> Die Intensität des Unterrichts, den Kursinhalt sowie die Ziele, die Sie durch Ihren Sprachkurs erreichen möchten, können Sie mit diesem Programm selbst bestimmen.
<G-vec00297-002-s592><determine.bestimmen><en> If ppp cannot determine the hostname, it can manually be set later.
<G-vec00297-002-s592><determine.bestimmen><de> Falls ppp nicht in der Lage ist den Hostnamen selbst zu bestimmen, kann dieser auch später manuell eingetragen werden.
<G-vec00297-002-s593><determine.bestimmen><en> You can use many adaptation options to determine the design of the SEO report.
<G-vec00297-002-s593><determine.bestimmen><de> Über vielfältige Anpassungsmöglichkeiten können sie das Design der SEO-Reports selbst bestimmen.
<G-vec00297-002-s594><determine.bestimmen><en> An independent CD changer will play the CDs you put in the player in an order you determine.
<G-vec00297-002-s594><determine.bestimmen><de> Der eigenständige CD-Wechsler gewährleistet Ihnen einen ununterbrochenen Empfang einer größeren Anzahl von CD in der Reihenfolge, die Sie selbst bestimmen.
<G-vec00297-002-s595><determine.bestimmen><en> Ever again the importance of the leaders is emphasised, and it is only natural that professionals should decide about politics, be it in the democratic guise of congress discussions and resolutions. The history of Social Democracy is a series of fruitless attempts to let the members determine their own politics.
<G-vec00297-002-s595><determine.bestimmen><de> Immer fällt dabei das Hauptgewicht auf die Führer, und es ist selbstverständlich dabei, dass Fachleute die Politik bestimmen – sei es auch in der demokratischen Verkleidung der Kongressdiskussionen und Resolutionen –; die Geschichte der Sozialdemokratie ist eine Kette vergeblicher Bemühungen, die Mitglieder selbst ihre Politik bestimmen zu lassen.
<G-vec00297-002-s596><determine.bestimmen><en> Insofar as not otherwise agreed, Morita is entitled to determine the nature of consignment (particularly in terms of transport companies, shipping route, packaging).
<G-vec00297-002-s596><determine.bestimmen><de> Soweit nicht anders vereinbart, ist Morita berechtigt, die Art der Versendung (insbesondere Transportunternehmen, Versandweg, Verpackung) selbst zu bestimmen.
<G-vec00297-002-s597><determine.bestimmen><en> People believe that they cannot determine their own destiny, as it is largely influenced by external circumstances.
<G-vec00297-002-s597><determine.bestimmen><de> Die Menschen sind der Meinung, dass sie ihr Schicksal nicht selbst bestimmen können, da es überwiegend von äußeren Umständen beeinflusst wird.
<G-vec00297-002-s598><determine.bestimmen><en> HEIGHT TECH shall be entitled to determine the method of shipping unless agreed otherwise with the Customer in individual cases.
<G-vec00297-002-s598><determine.bestimmen><de> HEIGHT TECH ist berechtigt, die Art und Weise der Versendung selbst zu bestimmen, soweit mit dem Kunden im Einzelfall nicht etwas anderes vereinbart wird.
<G-vec00297-002-s599><determine.bestimmen><en> But it must not be forgotten that these stratifications are by no means based upon objective differences even remotely similar to those which determine the division into classes.
<G-vec00297-002-s599><determine.bestimmen><de> Es darf aber nicht vergessen werden, daß diese Schichtungen keineswegs auf auch nur ähnlich objektiven Differenzen beruhen, wie jene sind, die die Scheidung der Klassen selbst objektiv-ökonomisch bestimmen.
<G-vec00297-002-s600><determine.bestimmen><en> At present, the National Lottery is free to determine how the supervision is organized.
<G-vec00297-002-s600><determine.bestimmen><de> Die Nationallotterie kann zurzeit selbst bestimmen, wie ihre Kontrolle organisiert wird.
<G-vec00297-002-s601><determine.bestimmen><en> Unless otherwise agreed, we are entitled to determine the type of shipment (in particular transport company, shipping route, packaging).
<G-vec00297-002-s601><determine.bestimmen><de> Soweit nicht etwas anderes vereinbart ist, sind wir berechtigt, die Art der Versendung (insbesondere Transportunternehmen, Versandweg, Verpackung) selbst zu bestimmen.
<G-vec00297-002-s602><determine.bestimmen><en> Due to the clever design, the customer is able to determine the equipment, i.e. the applications of machine on an individual basis.
<G-vec00297-002-s602><determine.bestimmen><de> Durch die clevere Konstruktion ist der Kunde in der Lage, die Ausstattung und damit den Anwendungsbereich der Maschine individuell selbst zu bestimmen.
<G-vec00297-002-s603><determine.bestimmen><en> ESL offers a programme which allows you to determine the intensity of the course and its content as well as your personal or professional objectives.
<G-vec00297-002-s603><determine.bestimmen><de> ESL bietet ein Programm, das es Ihnen ermöglicht, die Intensität des Kurses, seinen Inhalt sowie Ihre - privaten oder beruflichen - Ziele selbst zu bestimmen.
<G-vec00297-002-s604><determine.bestimmen><en> You can determine how cookies are handled by adjusting the corresponding settings in your internet browser.
<G-vec00297-002-s604><determine.bestimmen><de> Sie können den Umgang mit Cookies durch die Einstellungen Ihres Internetbrowsers selbst bestimmen.
<G-vec00297-002-s606><determine.bestimmen><en> Unless otherwise stipulated, the supplier is authorised to determine the type of shipment (particularly transportation company, transportation route, packaging).
<G-vec00297-002-s606><determine.bestimmen><de> Soweit nicht etwas anderes vereinbart ist, ist der Lieferant berechtigt, die Art der Versendung (insbesondere Transportunternehmen, Versandweg, Verpackung) selbst zu bestimmen.
<G-vec00297-002-s607><determine.bestimmen><en> Freedom to produce great art is a set of material and spiritual conditions, and the freedom to determine one’s own obligations through contracts is as broad as the imagination of the contracting parties.
<G-vec00297-002-s607><determine.bestimmen><de> Die Freiheit, große Kunst zu schaffen, besteht in einem Ensemble materieller und geistiger Voraussetzungen, und die Freiheit, die eigenen Verpflichtungen durch Verträge selbst zu bestimmen, ist genauso groß wie die Vorstellungskraft der vertragsschließenden Parteien.
<G-vec00297-002-s152><determine.entscheiden><en> The project is classified under Annex II of Council Directive 85/337 as amended by Directive 91/11/C and 2003/35/EC, thus requiring the Member State to determine whether or not a formal Environmental Impact Assessment is required. Procurement
<G-vec00297-002-s152><determine.entscheiden><de> Das Projekt fällt unter Anhang II der Richtlinie des Rates 85/337/EWG (geändert durch die Richtlinien 91/11/EG und 2003/35/EG), wonach der betreffende Mitgliedstaat entscheidet, ob eine formale Umweltverträglichkeitsprüfung erforderlich ist oder nicht.
<G-vec00297-002-s153><determine.entscheiden><en> Zoning and planning at the municipal level thus serves as an important instrument that contributes significantly to climate protection and the preservation of air quality: A site plan that has been developed in accordance with the land use plan of a municipality has binding authority to determine whether land areas are used in a manner that the environment can tolerate.
<G-vec00297-002-s153><determine.entscheiden><de> Die kommunale Ebene der Bauleitplanung gilt dabei als wichtiges Instrument, das zum Schutz des Klimas und zur Luftreinhaltung wesentlich beitragen kann; denn mit dem aus dem Flächennutzungsplan einer Gemeinde entwickelten Bebauungsplan entscheidet sich rechtsverbindlich, ob Grund und Boden umweltverträglich genutzt werden.
<G-vec00297-002-s154><determine.entscheiden><en> This means that pupils can determine for themselves as to whether they develop the second language to a similar degree as their mother tongue or can simply use it as a second language at the end of their learning period.
<G-vec00297-002-s154><determine.entscheiden><de> Das heißt, jeder Lernpartner entscheidet selbst, ob er die zweite Sprache so aufbaut, dass er diese am Ende seiner Lernzeit analog seiner Muttersprache beherrscht oder ob er sie lediglich eben als Zweitsprache praktiziert.
<G-vec00297-002-s155><determine.entscheiden><en> Determined by human leukocyte antigens (see below) and used to determine whether a transplanted tissue or organ will be accepted by the recipient.
<G-vec00297-002-s155><determine.entscheiden><de> Sie wird durch die humanen Leukozytenantigene (siehe unten) festgelegt und entscheidet, ob ein transplantiertes Gewebe oder Organ von dem Empfänger angenommen wird.
<G-vec00297-002-s156><determine.entscheiden><en> (The electoral office will check the right to vote on the votes received and in case of doubt determine about their validity or invalidity, double casting of votes leads to invalidity).
<G-vec00297-002-s156><determine.entscheiden><de> (Das Wahlbüro prüft die Stimmberechtigung der eingegangenen Stimmen und entscheidet bei allfälliger Unklarheit über Gültigkeit oder Ungültigkeit; eine doppelte Stimmabgabe führt zu Ungültigkeit).
<G-vec00297-002-s157><determine.entscheiden><en> Upon receiving such a request, Creative shall determine whether you require such information for a legitimate purpose and, if so, Creative will provide such information to you within a reasonable time and on reasonable conditions.
<G-vec00297-002-s157><determine.entscheiden><de> Bei Erhalt solch einer Anfrage entscheidet Creative, ob die Informationen für einen angemessenen Zweck benötigt werden.
<G-vec00297-002-s158><determine.entscheiden><en> The first are the rich and the well born, the others the mass of the people...The people are turbulent and changing; they seldom judge and determine right.
<G-vec00297-002-s158><determine.entscheiden><de> Zu den Ersteren zählen die Reichen und diejenigen aus gutem Hause, die Letzteren bilden die Masse des Volkes… Die Bevölkerung ist unruhig und unbeständig; sie beurteilt und entscheidet sich selten richtig.
<G-vec00297-002-s159><determine.entscheiden><en> Comprehensive tax planning and tax advice in advance of corporate transactions and measures often determine their success.
<G-vec00297-002-s159><determine.entscheiden><de> Die frühzeitige und umfassende steuerrechtliche Planung und Begleitung unternehmerischer Maßnahmen entscheidet oftmals nicht zuletzt über deren Erfolg.
<G-vec00297-002-s160><determine.entscheiden><en> You also determine if both or either are real…or not.
<G-vec00297-002-s160><determine.entscheiden><de> Ihr entscheidet auch, ob beide real sind… oder nicht.
<G-vec00297-002-s161><determine.entscheiden><en> As with announcements, the administrator or moderators determine whether you can reply to sticky topics.
<G-vec00297-002-s161><determine.entscheiden><de> Genau wie bei Ankündigungen entscheidet auch hier der Administrator, wer wichtige Themen (oder Post-its) erstellen darf.
<G-vec00297-002-s162><determine.entscheiden><en> An important part of Awareness is to acknowledge that only the affected person can determine whether their personal boundaries were violated.
<G-vec00297-002-s162><determine.entscheiden><de> Ein wichtiger Anteil von Awareness ist die Anerkennung der Definitionsmacht: Ob ihre eigenen Grenzen überschritten wurden, entscheidet immer ausschließlich die betroffene Person.
<G-vec00297-002-s163><determine.entscheiden><en> This will determine which of the 4 relationships we have.
<G-vec00297-002-s163><determine.entscheiden><de> Diese Beziehung entscheidet, welches der vier möglichen Relationships vorliegt.
<G-vec00297-002-s164><determine.entscheiden><en> If you have requested EPP, then upon receipt of Additional Registration Data, Eventbrite will determine, in its discretion, whether you are qualified to use EPP.
<G-vec00297-002-s164><determine.entscheiden><de> Wenn Sie EPP angefragt haben, entscheidet Eventbrite nach Erhalt der zusätzlichen Registrierungsdaten nach eigenem Ermessen, ob Sie zur Nutzung von EPP berechtigt sind.
<G-vec00297-002-s165><determine.entscheiden><en> The requested authority shall determine, if necessary with the assistance of other public authorities, the enforcement measures to be taken to bring about the cessation or prohibition of the intra-Community infringement in a proportionate, efficient and effective way.
<G-vec00297-002-s165><determine.entscheiden><de> Die ersuchte Behörde entscheidet, gegebenenfalls mit der Unterstützung anderer Behörden, welche Durchsetzungsmaßnahmen getroffen werden, um auf verhältnismäßige, wirksame und effiziente Weise eine Einstellung oder ein Verbot des innergemeinschaftlichen Verstoßes zu bewirken.
<G-vec00297-002-s166><determine.entscheiden><en> The competent authority shall determine whether the conditions are met on the basis of the assessment referred to in paragraph 1 and other available information, particularly concerning the protection of the environment and human health.
<G-vec00297-002-s166><determine.entscheiden><de> Auf der Grundlage der in Absatz 1 genannten Bewertung und anderer verfügbarer Informationen, insbesondere in Bezug auf den Schutz der Umwelt und der menschlichen Gesundheit, entscheidet die zuständige Behörde, ob die Voraussetzungen erfüllt sind.
<G-vec00297-002-s167><determine.entscheiden><en> Most medications that treat creatinine levels also treat an underlying problem causing an increase in those levels, so your doctor will have to diagnose the underlying condition before you can determine which medication is right for you.
<G-vec00297-002-s167><determine.entscheiden><de> Die meisten Medikamente, die den Kreatininwert behandeln, kurieren auch die eigentliche Ursache, die zu den erhöhten Werten führt, daher muss dein Arzt zunächst die eigentliche Erkrankung diagnostizieren, bevor er entscheidet, welches Medikament für dich das richtige ist.
<G-vec00297-002-s168><determine.entscheiden><en> The properties of PUR determine how it is used.
<G-vec00297-002-s168><determine.entscheiden><de> Die Verwendung von PUR entscheidet sich nach den Eigenschaften des Materials.
<G-vec00297-002-s169><determine.entscheiden><en> Upon contacting Formlabs, our Customer Service team will determine whether you may be eligible for Warranty Service or Repair Service and authorize your return of Formlabs product(s) as appropriate.
<G-vec00297-002-s169><determine.entscheiden><de> Wenn Sie mit Formlabs in Kontakt treten, entscheidet unser Kundendienstteam, ob Sie für den Garantieservice oder den Reparaturservice in Frage kommen und autorisieren die Rückgabe Ihres Formlabs-Produkts.
<G-vec00297-002-s170><determine.entscheiden><en> Each masternode in the network is entitled to one vote on any given proposal, and a majority will determine whether or not a proposal is passed.
<G-vec00297-002-s170><determine.entscheiden><de> Jede Masternode kann über Vorschläge abstimmen und die Mehrheit der Stimmen entscheidet, ob ein Vorschlag akzeptiert wird.
<G-vec00297-002-s171><determine.erfassen><en> This makes it possible to quickly determine the publication phase of the individual learning resources.
<G-vec00297-002-s171><determine.erfassen><de> So lässt sich schnell erfassen, in welcher Publikationsphase die einzelnen Lernressourcen stehen.
<G-vec00297-002-s172><determine.erfassen><en> Since future conflicts will be distinctively shaped by the use of these means and methods of warfare, the question arises if and to what extent applicable law is adequate to determine and regulate increasingly dehumanized warfare.
<G-vec00297-002-s172><determine.erfassen><de> Da die Konfliktführung in der Zukunft aber von diesen Mitteln und Methoden entscheidend geprägt sein wird, stellt sich zwingend die Frage, ob und inwieweit das geltende Recht dazu geeignet ist, die Dehumanisierung der Kriegführung zu erfassen und effizient zu regeln.
<G-vec00297-002-s173><determine.erfassen><en> The cookie also helps DoubleClick to determine which advertisements have already been implemented into a browser, this in turn prevents repetition of the advertisement.
<G-vec00297-002-s173><determine.erfassen><de> DoubleClick kann über die Cookie-ID zudem erfassen, welche Werbeanzeigen bereits in einem Browser eingeblendet wurden, um Doppelschaltungen zu vermeiden.
<G-vec00297-002-s174><determine.erfassen><en> In particular, the FIFA Museum reserves the right to determine the final design, layout and functionality of the FIFA Museum Digital Platforms, which may involve the review, formatting and editing of User Submissions.
<G-vec00297-002-s174><determine.erfassen><de> Durch Ihre Nutzung der digitalen Plattformen des FIFA-Museums räumen Sie dem FIFA-Museum ausdrücklich das Recht ein, Ihre Daten zu erfassen und zu verarbeiten, insbesondere für die Anpassung des Leistungsangebots und von Werbung.
<G-vec00297-002-s175><determine.erfassen><en> And it’s precisely the direction and speed with which it drifts that the multicopter needs to determine.
<G-vec00297-002-s175><determine.erfassen><de> Genau diese Richtung und Geschwindigkeit der Drift soll der Multikopter erfassen.
<G-vec00297-002-s176><determine.erfassen><en> Combining this data from a large group of people can determine which substances should be interpreted as a sign of health or damage.
<G-vec00297-002-s176><determine.erfassen><de> Wenn solche Daten von einer großen Gruppe von Menschen zusammengetragen werden, ist es möglich, zu erfassen, welche Substanzen als Zeichen für Gesundheit oder Schäden interpretiert werden können.
<G-vec00297-002-s177><determine.erfassen><en> Hence, the goal of the paper is to determine if and to what extent German-Turkish literature with its esthetic methods takes stands that are critical or different to the discourse.
<G-vec00297-002-s177><determine.erfassen><de> Ziel der Arbeit ist es daher, mit Hilfe eines textnahen Interpretationsverfahrens zu erfassen, ob und inwiefern die deutsch-türkische Literatur mit ihren ästhetischen Verfahren kritische oder gar diskursfremde Standpunkte beziehen.
<G-vec00297-002-s178><determine.erfassen><en> With the help of this technology, it is possible to determine the precise dimensions of a measuring spot for the first time.
<G-vec00297-002-s178><determine.erfassen><de> Mit Hilfe dieser Technologie ist es somit erstmals möglich, die präzisen Abmessungen des Messflecks übersichtlich zu erfassen.
<G-vec00297-002-s179><determine.erfassen><en> In order to determine the real state of the routes under normal track and overhead wire loading conditions, we recommend that you make a normal rolling stock vehicle available for the testing.
<G-vec00297-002-s179><determine.erfassen><de> Um den realen Zustand der Strecken unter normaler Gleis- und Fahrleitungsbelastung zu erfassen, empfehlen wir, für die Messung ein normales Linienfahrzeug zur Verfügung zu stellen.
<G-vec00297-002-s180><determine.erfassen><en> Laboratory tests supply material-mechanical principles to determine the interaction of rolling shear stresses and compression perpendicular to the grain.
<G-vec00297-002-s180><determine.erfassen><de> Experimentelle Untersuchungen bilden die material-mechanische Grundlage, um den Einfluss der Spannungsinteraktionen von Rollschub und Querdruck senkrecht zur Faser zu erfassen.
<G-vec00297-002-s181><determine.erfassen><en> Taking into account the landscape sensitivity it is possible to determine environmental potentialities and restrictions and, at the same time, it is possible to formulate guidelines for sustainable land-use.
<G-vec00297-002-s181><determine.erfassen><de> Dies ermöglicht, das Umweltpotential und Restriktionen zu erfassen, auf deren Basis Richtlinien für eine nachhaltige Landnutzung abgeleitet werden können.
<G-vec00297-002-s182><determine.erfassen><en> These cameras can measure temperature variations of approximately 0.03 degrees Celsius and can determine the colour spectrum of the seawater.
<G-vec00297-002-s182><determine.erfassen><de> Sie können Temperaturunterschiede an der Meeresoberfläche von etwa 0,03 Grad Celsius messen und erfassen das Farbspektrum des Meerwassers.
<G-vec00297-002-s183><determine.erfassen><en> It was used to determine and forecast important astronomical and calendar events.
<G-vec00297-002-s183><determine.erfassen><de> Sie wurde zum Erfassen und Vorhersehen wichtiger, astronomischer Vorfälle und Kalenderereignisse genutzt.
<G-vec00297-002-s184><determine.erfassen><en> But yet, it is only one approach to determine "heavenly peace".
<G-vec00297-002-s184><determine.erfassen><de> Und dennoch ist dies nur ein Ansatz den himmlischen Frieden zu erfassen.
<G-vec00297-002-s185><determine.erfassen><en> The bulk material flows through two measuring channels, which use highly accurate, patented Smart Force Transducer technology to determine the actual flow rate. Read more Read less Benefits & Features
<G-vec00297-002-s185><determine.erfassen><de> Das Schüttgut fließt durch zwei Messkanäle, wobei die patentierten «Smart Force Transducer»-Lastzellen die Durchflussmenge pro Zeiteinheit zuverlässig und mit sehr hoher Genauigkeit erfassen.
<G-vec00297-002-s186><determine.erfassen><en> The ERNST compression systems offer great flexibility, precise measurements and the latest in data recording technology, in order to easily determine the structural stability of the test specimens with a high level of precision.
<G-vec00297-002-s186><determine.erfassen><de> Dachdrückanlagen Die Drückanlagen von ERNST bieten große Beweglichkeit, präzise Messung und eine Datenerfassung auf dem neuesten Stand der Technik, um die strukturelle Festigkeit der Prüflinge einfach und mit hoher Präzision erfassen zu können.
<G-vec00297-002-s187><determine.erfassen><en> It allows us to determine the effectiveness of the Facebook advertisements for our statistical and marketing research.
<G-vec00297-002-s187><determine.erfassen><de> So können wir die Wirksamkeit der Facebook-Werbeanzeigen für statistische und Marktforschungszwecke erfassen.
<G-vec00297-002-s188><determine.erfassen><en> As mobile technology has advanced, and gaming operators have introduced new technologies of their own to determine what is happening on the Live Casino table, these Live Casino games are now available for mobile devices.
<G-vec00297-002-s188><determine.erfassen><de> Mit dem Fortschritt der Mobilfunktechnologie und der Einführung neuer Technologien durch die Spielbetreiber, die erfassen, was am Live Casino-Tisch passiert, sind diese Live Casino-Spiele nun auch für Mobilgeräte verfügbar.
<G-vec00297-002-s189><determine.erfassen><en> As long as you're able to determine each of those, you're on the right track for more effective email marketing.
<G-vec00297-002-s189><determine.erfassen><de> Wenn sie diese drei Aspekte erfassen können, sind Sie auf gutem Wege zu einem effektiveren E-Mail-Marketing.
<G-vec00297-002-s190><determine.erkennen><en> Rely on the Upgrade Dependency Analyzer to determine whether your upgrade has an impact on other systems in your landscape.
<G-vec00297-002-s190><determine.erkennen><de> Mit dem Upgrade Dependency Analyzer erkennen Sie die Auswirkungen und Abhängigkeiten in Bezug auf andere Systeme in Ihrer SAP-Landschaft.
<G-vec00297-002-s191><determine.erkennen><en> A turbidity sensor is installed in the tank outlet, or in the yeast harvest line. When the yeast is removed from the beer the turbidity meter will determine the interface between the yeast and beer.
<G-vec00297-002-s191><determine.erkennen><de> Ein Trübungssensor wird direkt am Tankausgang oder in der Heferückführleitung installiert, um somit die Phasentrennung von Bier und Hefe zu erkennen und Produktverluste oder Produktkontamination zu vermeiden.
<G-vec00297-002-s192><determine.erkennen><en> Also a very important concept in BDSM, the value of which, however, quite difficult to determine.
<G-vec00297-002-s192><determine.erkennen><de> Auch ein sehr wichtiger Begriff in der BDSM, dessen Wert jedoch schwer zu erkennen.
<G-vec00297-002-s193><determine.erkennen><en> Seams and zippers: With any high-quality bag, you can immediately determine the quality by inspecting the seams and zips.
<G-vec00297-002-s193><determine.erkennen><de> Nähte und Reissverschlüsse: Wie bei allen hochwertigen Taschen ist die Qualität auf einen Blick an den Nähten und Reissverschlüssen zu erkennen.
<G-vec00297-002-s194><determine.erkennen><en> This software is able to precisely determine the position and orientation of a camera in relation to a given object, and to use this information to analyze camera images.
<G-vec00297-002-s194><determine.erkennen><de> Sie ist in der Lage, Position und Orientierung der Kamera in Relation zu einem Objekt exakt zu erkennen und so die Kamerabilder gezielt auszuwerten.
<G-vec00297-002-s195><determine.erkennen><en> You can determine whether a specific page on our website is encrypted by the locked key or padlock icon next to the address bar in your browser.
<G-vec00297-002-s195><determine.erkennen><de> Ob eine einzelne Seite unseres Internetauftrittes verschlüsselt übertragen wird, erkennen Sie an der geschlossenen Darstellung des Schüssel- beziehungsweise Schloss-Symbols in der unteren Statusleiste Ihres Browsers.
<G-vec00297-002-s196><determine.erkennen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00297-002-s196><determine.erkennen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00297-002-s197><determine.erkennen><en> Search engines use canonical URLs to determine and prevent duplicate content issues.
<G-vec00297-002-s197><determine.erkennen><de> Suchmaschinen verwenden kanonische URLs, um doppelte Content-Probleme zu erkennen und zu vermeiden.
<G-vec00297-002-s198><determine.erkennen><en> The mission’s goal was to determine the public-health risks and vulnerabilities related to the islands’ infrastructure, assess preparedness efforts and provide a ministerial task force with recommendations on ways to strengthen coordination and service provision in the event of a large new wave of migrants from North and sub-Saharan Africa.
<G-vec00297-002-s198><determine.erkennen><de> Das Ziel der Mission war es, in der Infrastruktur der Insel Gefahren und Schwachstellen für die öffentliche Gesundheit zu erkennen, ihre Vorbereitung auf Notlagen zu bewerten und Empfehlungen für eine ministerielle Arbeitsgruppe darüber abzugeben, wie die Koordinierung und Erbringung der Dienste für eine neuerliche große Migrationswelle aus Nordafrika und Afrika südlich der Sahara gerüstet werden können.
<G-vec00297-002-s199><determine.erkennen><en> Companies use this information to try and determine the risks and opportunities for the company's success.
<G-vec00297-002-s199><determine.erkennen><de> Dadurch versuchen Unternehmen, die Chancen und Risiken für den jeweiligen Unternehmenserfolg zu erkennen.
<G-vec00297-002-s200><determine.erkennen><en> You must determine the content that is essential for business and the factors that have the biggest impact on key figures.
<G-vec00297-002-s200><determine.erkennen><de> Man muss die Inhalte herausfiltern, die für das Geschäft wichtig sind, und erkennen, welche Faktoren die größten Auswirkungen auf Schlüsselzahlen haben.
<G-vec00297-002-s201><determine.erkennen><en> Since a wide range of different denture base materials is used, it is frequently difficult for the responsible dental technician to determine whether these materials provide perfect bonding to the denture teeth available.
<G-vec00297-002-s201><determine.erkennen><de> Durch den Einsatz verschiedenster Basismaterialien ist es für den verantwortungsbewußten Zahntechniker oft schwer zu erkennen, ob diese Materialien eine einwandfreie Verbindung mit den zur Verfügung stehenden Kunststoffzähnen eingehen.
<G-vec00297-002-s202><determine.erkennen><en> As a result they are able to determine early on, which findings about the effect of a drug are already available.
<G-vec00297-002-s202><determine.erkennen><de> So lässt sich schon frühzeitig erkennen, welche Erkenntnisse zur Wirkung eines Medikaments bereits vorliegen.
<G-vec00297-002-s203><determine.erkennen><en> You can determine how much you were at fault by the amount of suffering you have to endure.
<G-vec00297-002-s203><determine.erkennen><de> Am Ausmaß des Leidens, das du ertragen musst, kannst du erkennen, wie groß deine Fehler sind.
<G-vec00297-002-s204><determine.erkennen><en> It is easier to determine and exploit the opponents' profile, i.e.
<G-vec00297-002-s204><determine.erkennen><de> Es ist einfacher das Profil der Gegner zu erkennen und auszunutzen und bspw.
<G-vec00297-002-s205><determine.erkennen><en> This is done by means of session cookies in order to determine which individual pages of our website you visited before.
<G-vec00297-002-s205><determine.erkennen><de> So setzen wir sogenannte Session-Cookies ein, um zu erkennen, dass Sie einzelne Seiten unserer Website bereits besucht haben.
<G-vec00297-002-s206><determine.erkennen><en> The structure and organization of the tropical cyclone are tracked over 24 hours to determine if the storm has weakened, maintained its intensity, or strengthened.
<G-vec00297-002-s206><determine.erkennen><de> Dabei wird die Struktur eines tropischen Wirbelsturmes alle 24 Stunden analysiert, um zu erkennen, ob sich der Wirbelsturm verstärkt, abgeschwächt oder seine Intensität erhalten hat.
<G-vec00297-002-s207><determine.erkennen><en> The evaluations serve to provide us with information to determine the reading habits of our users and adapt our newsletter contents to the users or supply different contents according to the different interests of the users.
<G-vec00297-002-s207><determine.erkennen><de> Die Auswertungen dienen uns viel mehr dazu, die Lesegewohnheiten unserer Nutzer zu erkennen und unsere Inhalte auf sie anzupassen oder unterschiedliche Inhalte entsprechend den Interessen unserer Nutzer zu versenden.
<G-vec00297-002-s208><determine.erkennen><en> We investigate, describe, and assess the state of the environment in order to determine adverse impacts for humanity and the environment comprehensively and as early as possible.
<G-vec00297-002-s208><determine.erkennen><de> Wir ermitteln, beschreiben und bewerten den Zustand der Umwelt, um Beeinträchtigungen von Mensch und Umwelt möglichst frühzeitig und umfassend zu erkennen.
<G-vec00297-002-s228><determine.ermitteln><en> Instead of starting out with an app, we first developed the concept behind the app by working together with refugees to determine the requirements and possible approaches to finding solutions.
<G-vec00297-002-s228><determine.ermitteln><de> Statt sofort mit einer App zu beginnen, haben wir zunächst das Konzept einer App entwickelt in dem wir gemeinsam mit Flüchtlingen Anforderungen erarbeitet und mögliche Lösungsstrategien ermittelt haben.
<G-vec00297-002-s229><determine.ermitteln><en> Preliminary tests determine the required wick thickness
<G-vec00297-002-s229><determine.ermitteln><de> Durch Vorprüfungen wird ermittelt, welche Dochtstärke erforderlich ist.
<G-vec00297-002-s230><determine.ermitteln><en> The aim of this activity is to determine not only the direct causes of such events but also the more deep-seated reasons and other risks associated with them.
<G-vec00297-002-s230><determine.ermitteln><de> Durch diese Tätigkeit sollen nicht nur die unmittelbaren Ursachen solcher Ereignisse ermittelt, sondern auch deren tieferliegende Gründe und weitere mit ihnen verbundene Risiken gefunden werden.
<G-vec00297-002-s231><determine.ermitteln><en> The jury will then determine the winner based on this point system.
<G-vec00297-002-s231><determine.ermitteln><de> Danach ermittelt die Jury ebenfalls nach einem Punkteverfahren die Sieger.
<G-vec00297-002-s232><determine.ermitteln><en> In cases where it is impossible to determine the utilisation, the expenditure associated with the utilisation is decisive.
<G-vec00297-002-s232><determine.ermitteln><de> Wo die Nutzung nicht ermittelt werden kann, ist der mit der Nutzung verbundene Aufwand maßgebend.
<G-vec00297-002-s233><determine.ermitteln><en> This method is to be used to determine the economically optimal – in the sense of total costs over the lifecycle – national requirement levels for energy-saving building.
<G-vec00297-002-s233><determine.ermitteln><de> Mit dieser Methode sollen die wirtschaftlich optimalen – im Sinne von Gesamtkosten im Lebenszyklus – nationalen Anforderungsniveaus für das energiesparende Bauen ermittelt werden.
<G-vec00297-002-s234><determine.ermitteln><en> This makes it necessary to always determine a new a*act,R,Z correction factor for each light source.
<G-vec00297-002-s234><determine.ermitteln><de> Demnach muss für jedes Gerät bei jeder Lichtquelle ein neuer a*act,R,Z-Korrekturfaktor ermittelt werden.
<G-vec00297-002-s235><determine.ermitteln><en> The data from these three areas determine the level of sustainability of investment funds.
<G-vec00297-002-s235><determine.ermitteln><de> Mit Daten aus diesen drei Bereichen wird der Grad der Nachhaltigkeit von Anlagefonds ermittelt.
<G-vec00297-002-s236><determine.ermitteln><en> There you can perform a test and determine whether or not you are affected by a DNS leak.
<G-vec00297-002-s236><determine.ermitteln><de> Nun ermittelt diese Web-Applikation, ob Sie tatsächlich von einem DNS Leak betroffen sind.
<G-vec00297-002-s237><determine.ermitteln><en> In this model, we determine the worst-case time complexity of accessing such a robust storage, closing several fundamental complexity gaps. Uncontrolled Keywords:
<G-vec00297-002-s237><determine.ermitteln><de> In diesem Rahmen wird die Worst-Case Latenzzeit von Lese- und Schreibzugriff en auf ein robustes Storage untersucht und ermittelt, und dadurch werden etliche grundlegende Komplexitätslücken geschlossen.
<G-vec00297-002-s238><determine.ermitteln><en> The purpose of the Target Bonus is to determine which bonus you will be awarded.
<G-vec00297-002-s238><determine.ermitteln><de> Mit dem Zielbonus wird ermittelt, welchen Bonus Sie erhalten.
<G-vec00297-002-s239><determine.ermitteln><en> This enables you to determine the plants requirements and the corresponding correct dosing of the fertiliser.
<G-vec00297-002-s239><determine.ermitteln><de> So kann der Bedarf der Pflanzen ermittelt und die Dosierung des Düngers entsprechend vorgenommen werden.
<G-vec00297-002-s240><determine.ermitteln><en> The instrument uses image analysis to determine the number, size and size distribution of the bubbles of a foam generated under control in the instrument.
<G-vec00297-002-s240><determine.ermitteln><de> Das Instrument ermittelt per Bildanalyse die Anzahl, Größe und Größenverteilung der Schaumblasen eines im Gerät kontrolliert erzeugten Schaums.
<G-vec00297-002-s241><determine.ermitteln><en> Tensile tests determine the main mechanical properties of films, papers or other materials. Analytics
<G-vec00297-002-s241><determine.ermitteln><de> Im Zugversuch werden wesentliche mechanische Eigenschaften von Folien, Papieren oder anderen Materialien ermittelt.
<G-vec00297-002-s242><determine.ermitteln><en> However, this system doesn’t help determine the personal element or any auspicious direction.
<G-vec00297-002-s242><determine.ermitteln><de> Dieses System ermittelt nicht das persönliche Element oder die Richtung der Auspizien.
<G-vec00297-002-s243><determine.ermitteln><en> Mathematically, it is relatively easy to determine that there are 92 different ways to arrange the queens.
<G-vec00297-002-s243><determine.ermitteln><de> Mathematisch kann noch relativ einfach ermittelt werden, dass es 92 verschiedene Möglichkeiten gibt, die Damen aufzustellen.
<G-vec00297-002-s244><determine.ermitteln><en> The next step is to analyze the weak points with staff from the customer’s various departments, formulate targets, and determine the potential for improvement.
<G-vec00297-002-s244><determine.ermitteln><de> Im nächsten Schritt werden mit den Mitarbeitern der verschiedenen Abteilungen des Kunden die Schwachstellen analysiert, Ziele formuliert und das Verbesserungspotenzial ermittelt.
<G-vec00297-002-s245><determine.ermitteln><en> This process uses the IP address of a visitor to determine the region where that visitor is located.
<G-vec00297-002-s245><determine.ermitteln><de> Bei diesem Verfahren wird anhand der IP-Adresse eines Besuchers die Region ermittelt, in der er sich befindet.
<G-vec00297-002-s246><determine.ermitteln><en> The installer no longer needs to make time-consuming settings since the pump is able to determine the system curve itself.
<G-vec00297-002-s246><determine.ermitteln><de> Der Installateur muss keine aufwendigen Einstellungen mehr vornehmen, da die Pumpe die Anlagenkennlinie selbst ermittelt.
<G-vec00297-002-s285><determine.festlegen><en> The idea is to determine an upper ceiling on the leverage ratio of banks, and the banks should be obliged to “safe up” more capital in good times to have more buffer available in turbulent times (dynamic provisioning).
<G-vec00297-002-s285><determine.festlegen><de> Es soll eine Verschuldungsobergrenze für Banken festgelegt werden und die Banken sollen dazu veranlasst werden, in guten Zeiten mehr Eigenkapital „anzusparen“, um in turbulenten Zeiten mehr Puffer zur Verfügung zu haben.
<G-vec00297-002-s286><determine.festlegen><en> Those rules shall determine when the limitation period begins to run, the duration thereof and the circumstances under which it is interrupted or suspended.
<G-vec00297-002-s286><determine.festlegen><de> In diesen Vorschriften wird festgelegt, wann die Verjährungsfrist beginnt, ihre Dauer und unter welchen Umständen eine Unterbrechung oder Hemmung der Frist eintritt.
<G-vec00297-002-s287><determine.festlegen><en> It is not possible to determine precise departure times for the time being as unforeseen delays may occur during the test operation.
<G-vec00297-002-s287><determine.festlegen><de> Genaue Abfahrtszeiten können vorerst nicht festgelegt werden, da es im Testbetrieb zu nicht planbaren Verzögerungen kommen kann.
<G-vec00297-002-s288><determine.festlegen><en> This step will determine the information that will be included in your product sheets.
<G-vec00297-002-s288><determine.festlegen><de> In diesem Schritt werden die Informationen festgelegt, die in Ihren Produktblättern enthalten sein werden.
<G-vec00297-002-s289><determine.festlegen><en> A dialog box opens (this is different than in the assignment of online users) that you can use to determine the data that will be transmitted to the offline user.
<G-vec00297-002-s289><determine.festlegen><de> Nach der Zuweisung von Aufgaben an einen Offline-Benutzer öffnet sich (anders als bei der Zuweisung von Online-Benutzern) ein Dialogfenster, in dem die Daten festgelegt werden können, die dem Offline-Benutzer zur Bearbeitung der Aufgabe zur Verfügung stehen sollen.
<G-vec00297-002-s290><determine.festlegen><en> It starts with grading, since every new author will be evaluated using a sample text to determine the level of quality of their writing.
<G-vec00297-002-s290><determine.festlegen><de> Dies beginnt mit der Einstufung, denn bei jedem neuen Autor wird anhand eines Probetextes festgelegt, in welcher Qualitätsstufe er Texte schreiben kann.
<G-vec00297-002-s291><determine.festlegen><en> Save time by automating activation with rules that determine where and when technologies should be used.
<G-vec00297-002-s291><determine.festlegen><de> Sparen Sie Zeit, indem Sie die Aktivierung anhand von Regeln automatisieren, in denen festgelegt ist, wo und wann Technologien verwendet werden.
<G-vec00297-002-s292><determine.festlegen><en> 3. Where a base prospectus contains options with regard to the information required by the relevant securities note, the final terms shall determine which of the options is applicable to the individual issue by referring to the relevant sections of the base prospectus or by replicating such information.
<G-vec00297-002-s292><determine.festlegen><de> (3) Enthält ein Basisprojekt Optionen in Bezug auf die Angaben, die nach der entsprechenden Wertpapierbeschreibung erforderlich sind, so wird in den endgültigen Bedingungen festgelegt, welche dieser Optionen für die einzelne Emission gilt, entweder indem auf die entsprechenden Rubriken des Basisprospekts verwiesen wird oder indem die betreffenden Angaben wiederholt werden.
<G-vec00297-002-s293><determine.festlegen><en> If calls are being declined by clients, this selection of SIP responses can determine how they are declined, or how a decline is emulated.
<G-vec00297-002-s293><determine.festlegen><de> Werden Anrufe durch Clients abgewiesen, kann mit dieser Auswahl an SIP-Respones festgelegt werden, wie abgewiesen wird oder wie ein Abweisen emuliert wird.
<G-vec00297-002-s294><determine.festlegen><en> The term “sensitive personal data” refers to the different categories of personal data for which the European and other data protection law(s) determine the need for special treatment, which, in certain circumstances, also includes the requirement of an explicit consent.
<G-vec00297-002-s294><determine.festlegen><de> Der Begriff „sensible personenbezogene Daten“ bezieht sich auf die unterschiedlichen Kategorien personenbezogener Daten, für die im europäischen und in anderen Datenschutzrecht(en) die Notwendigkeit einer speziellen Behandlung festgelegt wird, wozu unter bestimmten Umständen auch das Erfordernis einer ausdrücklichen Einwilligung gehört.
<G-vec00297-002-s295><determine.festlegen><en> The Governing Council shall determine the terms and conditions of such transfers.
<G-vec00297-002-s295><determine.festlegen><de> Die Bedingungen für derartige Übertragungen werden vom EZB-Rat festgelegt.
<G-vec00297-002-s296><determine.festlegen><en> "3. The implementing rules shall determine the maximum period during which the situations referred to in paragraph 1 give rise to the exclusion of candidates or tenderers from participation in a procurement procedure.
<G-vec00297-002-s296><determine.festlegen><de> "(3) Der maximale Zeitraum, während dessen die in Absatz 1 genannten Ausschlussgründe den Ausschluss eines Bewerbers oder Bieters von der Teilnahme an einem Vergabeverfahren zur Folge haben, wird in den Durchführungsbestimmungen festgelegt.
<G-vec00297-002-s297><determine.festlegen><en> Customers can determine individually how often overviews of current assets or portfolios are required.
<G-vec00297-002-s297><determine.festlegen><de> Es kann individuell festgelegt werden, wie häufig aktuelle Übersichten über Portfolios oder Assets gewünscht werden.
<G-vec00297-002-s298><determine.festlegen><en> We determine in advance exactly what rights and obligations our service provider should have with regard to personal data.
<G-vec00297-002-s298><determine.festlegen><de> Es wird im Vorhinein genau von uns festgelegt, welche Rechte und Pflichten unser Dienstleister in Bezug auf personenbezogene Daten haben soll.
<G-vec00297-002-s299><determine.festlegen><en> The purpose of this Directive is to determine the conditions for the exercise of the right to family reunification by third country nationals residing lawfully in the territory of the Member States.
<G-vec00297-002-s299><determine.festlegen><de> In dieser Richtlinie werden die Bedingungen festgelegt, unter denen Forscher, die Drittstaatsangehörige sind, für einen Zeitraum von mehr als drei Monaten zur Durchführung eines Forschungsprojekts im Rahmen einer Aufnahmevereinbarung mit einer Forschungseinrichtung zum Aufenthalt in den Mitgliedstaaten zugelassen werden.
<G-vec00297-002-s300><determine.festlegen><en> To ensure that, bilateral trade agreements are imperative, primarily to determine exchange rates which neutralize the average price difference between trading partners.
<G-vec00297-002-s300><determine.festlegen><de> Dazu sind bilaterale Handelsvereinbarungen zu treffen, in denen vorrangig Wechselkurse festgelegt werden, die das durchschnittliche Preisgefälle neutralisieren.
<G-vec00297-002-s301><determine.festlegen><en> For each person of the synthetic population, the diaries from the time budget survey to subsequently determine, which activities they pursue within a workday.
<G-vec00297-002-s301><determine.festlegen><de> Anschließend wird für jede Person der synthetischen Bevölkerung anhand der Tagebücher aus der Zeitbudgeterhebung festgelegt, welchen Aktivitäten sie im betrachteten Zeitraum nachgeht.
<G-vec00297-002-s302><determine.festlegen><en> This constant is used to determine if a message has achieved a final state.
<G-vec00297-002-s302><determine.festlegen><de> Mit dieser Konstanten wird festgelegt, ob eine Nachricht einen endgültigen Status erreicht hat.
<G-vec00297-002-s303><determine.festlegen><en> You also need to determine the method of payment here (credit card) and you can take out insurance.
<G-vec00297-002-s303><determine.festlegen><de> Auch wird hier die Zahlungsart festgelegt (per Kreditkarte) und es besteht die Möglichkeit eine Versicherung abzuschließen.
<G-vec00297-002-s304><determine.feststellen><en> Conversion measurement: Conversion measurement is a method to determine the effectiveness of marketing measures.
<G-vec00297-002-s304><determine.feststellen><de> Konversionsmessung: Die Konversionsmessung ist ein Verfahren, mit dem die Wirksamkeit von Marketingmaßnahmen festgestellt werden kann.
<G-vec00297-002-s305><determine.feststellen><en> The analysis of the micrograph is useful to determine if the valid quality criteria are met during production.
<G-vec00297-002-s305><determine.feststellen><de> Durch die Analyse des Schliffbildes wird festgestellt, ob die gültigen Qualitätskriterien bei der Produktion eingehalten werden.
<G-vec00297-002-s306><determine.feststellen><en> A diagnostic HER2 test is used to determine if a patient has HER2-positive breast cancer.
<G-vec00297-002-s306><determine.feststellen><de> Mit Hilfe eines diagnostischen HER2-Tests wird festgestellt, ob eine Patientin an HER2-positivem Brustkrebs leidet.
<G-vec00297-002-s307><determine.feststellen><en> Following on from the few studies on the effects of school dogs to date, hypotheses are to be used to determine how a trained school dog can have an effect on the behaviour and emotions of pupils at German grammar schools after a relatively short period of time with the dog in the classroom.
<G-vec00297-002-s307><determine.feststellen><de> Angeknüpft an die bisher durchgeführten wenigen Studien zu den Effekten von Schulhunden soll hypothesenorientiert festgestellt werden, wie ein ausgebildeter Schulhund auf das Verhalten und die Emotionen der Schüler am Gymnasium nach relativ kurzer Einsatzzeit wirken kann.
<G-vec00297-002-s308><determine.feststellen><en> Based on these data, it is also possible to determine whether the fetus suffers from hypoxia.
<G-vec00297-002-s308><determine.feststellen><de> Anhand dieser Daten kann auch festgestellt werden, ob der Fötus an Hypoxie leidet.
<G-vec00297-002-s309><determine.feststellen><en> With IMC Teach, you can comprehensively train colleagues and determine important learning outcomes with integrated tests.
<G-vec00297-002-s309><determine.feststellen><de> Mit IMC Teach können Kollegen umfassend geschult und durch integrierte Tests wichtige Lernerfolge festgestellt werden.
<G-vec00297-002-s310><determine.feststellen><en> Determine whether any unit has been eliminated by combat or ranged attack or a combination of both.
<G-vec00297-002-s310><determine.feststellen><de> Es wird festgestellt, ob Einheiten im Nahkampf, durch Fernwaffen oder durch eine Kombination aus beidem eliminiert wurden.
<G-vec00297-002-s311><determine.feststellen><en> The cohort study is used to determine if there is an increased health risk related to the exposure.
<G-vec00297-002-s311><determine.feststellen><de> Mit Hilfe der Kohortenstudie wird festgestellt, ob ein erhöhtes Gesundheitsrisiko von der Exposition ausgeht.
<G-vec00297-002-s312><determine.feststellen><en> This is the only method to determine whether or not you are a good candidate for the procedure.
<G-vec00297-002-s312><determine.feststellen><de> Nur so kann festgestellt werden, ob Sie ein guter Kandidat für das Verfahren sind oder nicht.
<G-vec00297-002-s313><determine.feststellen><en> With the help of ultrasound can determine the condition of the tissues, detect tumors and cysts, stones in the ducts or diffuse changes.
<G-vec00297-002-s313><determine.feststellen><de> Mit Hilfe von Ultraschall kann der Zustand der Gewebe festgestellt werden, um Tumore und Zysten, Steine in den Kanälen oder diffuse Veränderungen zu erkennen.
<G-vec00297-002-s314><determine.feststellen><en> If nevertheless there should be an unmarked graphic, sound or text on the respective pages that is protected by third-party copyright, the operator has been unable to determine the copyright or the copyright is not in an area that can be controlled by the operator.
<G-vec00297-002-s314><determine.feststellen><de> Sollte sich auf den jeweiligen Seiten dennoch eine ungekennzeichnete, aber durch fremdes Copyright geschützte Grafik, ein Tondokument, eine Videosequenz oder Text befinden, so konnte das Copyright vom Betreiber/Autor nicht festgestellt werden.
<G-vec00297-002-s315><determine.feststellen><en> (3) The Master examination is to determine if the candidate is able to make up the coherences in an area of life sciences within the respective current scientific state and is capable of deploying scientific methods independently.
<G-vec00297-002-s315><determine.feststellen><de> (3) 1 Durch die Master-Prüfung soll festgestellt werden, ob der Kandidat oder die Kandidatin die Zusammenhänge in der Psychologie überblickt und die Fähigkeit besitzt, die verwendeten wissenschaftlichen Methoden selbständig anzuwenden.
<G-vec00297-002-s316><determine.feststellen><en> Measures to ensure that it is possible to subsequently verify and determine whether and by whom the data has been entered, altered, or removed from IT systems.
<G-vec00297-002-s316><determine.feststellen><de> Maßnahmen, die gewährleisten, dass nachträglich überprüft und festgestellt werden kann, ob und von wem die Daten in IT-Systeme eingegeben, verändert oder entfernt worden sind.
<G-vec00297-002-s317><determine.feststellen><en> Opposition proceedings are relatively simple and cheap, and determine whether the two trade marks are confusing.
<G-vec00297-002-s317><determine.feststellen><de> Im einfachen und relativ kostengünstigen Widerspruchsverfahren wird dann festgestellt, ob die Marken verwechselbar sind.
<G-vec00297-002-s318><determine.feststellen><en> By reading the incoming signal, it can thus recognise the particular satellite, determine the time taken by the signal to arrive and calculate the distance from the satellite.
<G-vec00297-002-s318><determine.feststellen><de> Beim Empfang eines Signals kann somit der Satellit, von dem das Signal ausgestrahlt wurde, festgestellt sowie die Laufzeit des Signals und damit auch die Entfernung zum Sendesatelliten berechnet werden.
<G-vec00297-002-s319><determine.feststellen><en> At the port of entry, upon granting entry to the United States, the Customs and Border Protection officer will determine the length of stay permitted.
<G-vec00297-002-s319><determine.feststellen><de> Nach der Zulassung der Einreise in die Vereinigten Staaten von Amerika wird von einem Beamten der Zoll- und Grenzschutzbehörde festgestellt, wie lange Sie sich dort aufhalten dürfen.
<G-vec00297-002-s320><determine.feststellen><en> To participate at the program we determine both in a particularly approval procedure for the german interested persons at the University of Cologne.
<G-vec00297-002-s320><determine.feststellen><de> Beides wird für Teilnehmer, die sich in Deutschland bewerben, in einem besonderen Zulassungsverfahren an der Universität zu Köln festgestellt.
<G-vec00297-002-s321><determine.feststellen><en> Prior to the trial, you may have a psychological evaluation to help determine if you are a good candidate for spinal cord stimulation.
<G-vec00297-002-s321><determine.feststellen><de> Vor dem Test führen wir möglicherweise ein psychologisches Beratungsgespräch mit Ihnen, bei dem festgestellt wird, ob eine Rückenmarkstimulation für Sie geeignet ist.
<G-vec00297-002-s322><determine.feststellen><en> Unable to determine the controller type for the disk '[Disk Name] VMDK name.'
<G-vec00297-002-s322><determine.feststellen><de> Der Kontrollertyp für die Festplatte '[Festplattenname] VMDK-Name' konnte nicht festgestellt werden.
<G-vec00297-002-s437><determine.finden><en> After recognizing the conflict, the volunteers should make a plan in order to determine and practice the most effective solution.
<G-vec00297-002-s437><determine.finden><de> Nachdem der Konflikt erkannt wurde, sollten die Freiwilligen einen Plan erstellen, um die bestmögliche Lösung zu finden und zu verwirklichen.
<G-vec00297-002-s438><determine.finden><en> They are not trying to determine any underlying cause: they are just using one treatment indiscriminately.
<G-vec00297-002-s438><determine.finden><de> Sie versuchen nicht die darunter liegende Ursache zu finden: sie wenden einfach eine einzige Behandlung an - überall.
<G-vec00297-002-s439><determine.finden><en> To help you determine the security and trustworthiness of cloud productivity services, we have identified privacy and security considerations to inform your decision. Review the features
<G-vec00297-002-s439><determine.finden><de> Hier finden Sie die wichtigsten Überlegungen betreffend die Datensicherheit und den Datenschutz, die Ihnen helfen, die Sicherheit und die Vertrauenswürdigkeit von Cloudanbietern und deren Diensten zu beurteilen.
<G-vec00297-002-s440><determine.finden><en> We determine the solution adapted to your requirements for the modernization and expansion of your plant.
<G-vec00297-002-s440><determine.finden><de> Wir finden die an Ihre Anforderungen angepasste Lösung zur Modernisierung und Erweiterung Ihrer Anlage.
<G-vec00297-002-s441><determine.finden><en> To quickly and reliably determine the desired position for laser processing read our tips and tricks for positioning aids.
<G-vec00297-002-s441><determine.finden><de> Lesen Sie auch unsere Tipps und Tricks zu Positionierungshilfen, um schnell und zuverlässig die gewünschte Position für die Laserbearbeitung zu finden.
<G-vec00297-002-s442><determine.finden><en> You’ll also want to determine which type of accommodations will suit your needs before booking a hotel in Vibo Valentia.
<G-vec00297-002-s442><determine.finden><de> Wir helfen Ihnen dabei, genau das richtige Hotelzimmer für jede Gelegenheit zu finden und bieten Ihnen eine große Auswahl aus 10 Hotels in Vibo Valentia.
<G-vec00297-002-s443><determine.finden><en> To determine the best solution, the hotel tested out 17 different brands of parking lot lighting.
<G-vec00297-002-s443><determine.finden><de> Das Hotel prüfte eine Vielzahl von Produkten und Marken, um die beste Lösung zu finden.
<G-vec00297-002-s444><determine.finden><en> The Arvato finance experts determine the best billing solutions for doctors and health insurance companies.
<G-vec00297-002-s444><determine.finden><de> Die Finance-Experten von Arvato finden für Ärzte oder Krankenkassen die passende Lösung rund um das Thema Abrechnung.
<G-vec00297-002-s445><determine.finden><en> They already have experience with fuel cells and want to test further systems to determine the most suitable machine for a large-scale implementation.
<G-vec00297-002-s445><determine.finden><de> Sie haben bereits Erfahrungen mit Brennstoffzellen und wollen weitere Systeme testen um ihren Favoriten für eine großflächige Einführung zu finden.
<G-vec00297-002-s446><determine.finden><en> Unfortunately for our testing this meant that we had to determine a way to simulate an elevated temperature.
<G-vec00297-002-s446><determine.finden><de> Leider bedeutete dies für unsere Tests, dass wir einen Weg finden mussten, um eine erhöhte Temperatur zu simulieren.
<G-vec00297-002-s447><determine.finden><en> You’ll also want to determine which type of accommodations will suit your needs before booking a hotel in Clear Spring.
<G-vec00297-002-s447><determine.finden><de> Wir helfen Ihnen dabei, genau das richtige Hotelzimmer für jede Gelegenheit zu finden und bieten Ihnen eine große Auswahl aus 10 Hotels in Clear Spring.
<G-vec00297-002-s448><determine.finden><en> Contact us so we can determine the best solution for your learning needs.
<G-vec00297-002-s448><determine.finden><de> Kontaktieren Sie uns, damit wir die beste Lösung für Ihre Lernbedürfnisse finden können.
<G-vec00297-002-s449><determine.finden><en> You’ll also want to determine which type of accommodations will suit your needs before booking a hotel in Virgin Gorda.
<G-vec00297-002-s449><determine.finden><de> Wir helfen Ihnen dabei, genau das richtige Hotelzimmer für jede Gelegenheit zu finden und bieten Ihnen eine große Auswahl aus 10 Hotels in Virgin Gorda.
<G-vec00297-002-s450><determine.finden><en> When formulating new recipes, we routinely prepare up to 70 alternative mixes to find the best combination of close to 150 ingredients, and to determine the specific fruit variety needed to satisfy the palates of our demanding taste panel.
<G-vec00297-002-s450><determine.finden><de> Bei der Entwicklung neuer Rezepturen erarbeiten wir regelmäßig bis zu 70 Varianten, um die besten Kombinationen aus annähernd 150 natürlichen Zutaten zu finden.
<G-vec00297-002-s451><determine.finden><en> To determine which processors are compatible with this release, use the VMware Compatibility Guide.
<G-vec00297-002-s451><determine.finden><de> Informationen dazu, welche Prozessoren mit dieser Version kompatibel sind, finden Sie im VMware-Kompatibilitätshandbuch.
<G-vec00297-002-s452><determine.finden><en> For that reason our most experienced ski instructors will talk to you one on one to determine which ability class is the best match for you.
<G-vec00297-002-s452><determine.finden><de> Deshalb führen unsere erfahrensten SkilehrerInnen zu Beginn ein persönliches Gespräch mit Ihnen, um die geeignete Leistungsgruppe für Sie zu finden.
<G-vec00297-002-s453><determine.finden><en> TV INPUT: HDMI To determine the location, use the remote that came with each device, and press a button as you are pointing at the device.
<G-vec00297-002-s453><determine.finden><de> TV INPUT: HDMI Um die richtige Stelle zu finden, richten Sie die Fernbedienungen der betreffenden Geräte auf das entsprechende Gerät aus, und drücken auf eine Taste.
<G-vec00297-002-s454><determine.finden><en> You’ll also want to determine which type of accommodations will suit your needs before booking a hotel in Wadi Rum.
<G-vec00297-002-s454><determine.finden><de> Wir helfen Ihnen dabei, genau das richtige Hotelzimmer für jede Gelegenheit zu finden und bieten Ihnen eine große Auswahl aus 6 Hotels in Wadi Rum.
<G-vec00297-002-s455><determine.finden><en> However, since the participants speak various languages, have used different course materials in their countries or have studied with different teaching methods, we will ask you to take a brief placement test on the first day of the course so that we can determine the class that is best suited to your needs.
<G-vec00297-002-s455><determine.finden><de> Nachdem das jedoch nur eine ungefähre Einschätzung Ihres tatsächlichen Niveaus ist, das ja auch von bereits erlernten Sprachen, von unterschiedlichen Lehrmethoden und Auslandsaufenthalten abhängig ist, bitten wir Sie, am ersten Kurstag einen kurzen Einstufungstest zu machen, damit wir für Sie das am besten geeignete Level finden können.
<G-vec00297-002-s475><determine.herausfinden><en> Let your companion determine the truth for them.
<G-vec00297-002-s475><determine.herausfinden><de> Lass deinen Gefährten die Wahrheit für sie herausfinden.
<G-vec00297-002-s476><determine.herausfinden><en> If you require the features that the add-in program provides, you must determine which Word add-in program includes the specific feature so that you can contact the vendor for an update.
<G-vec00297-002-s476><determine.herausfinden><de> Wenn Sie die Funktionen benötigen, die durch dieses Add-In verfügbar sind, müssen Sie herausfinden, welches Add-In von Word diese spezielle Funktion enthält, um den Hersteller bezüglich eines Updates zu kontaktieren.
<G-vec00297-002-s477><determine.herausfinden><en> They may be labeled on some transistors or you may be able to determine which lead is the base by studying the circuit diagram.
<G-vec00297-002-s477><determine.herausfinden><de> Auf gewissen Transistoren könnten sie beschriftet sein, ansonsten kannst du das vielleicht auch herausfinden indem du den Schaltplan untersuchst.
<G-vec00297-002-s478><determine.herausfinden><en> Equipped with Spark Station Analytics, WBBB sought to analyze a recent programming decision and determine whether it was successful.
<G-vec00297-002-s478><determine.herausfinden><de> Ausgerüstet mit der Spark Station Analytics, wollte WBBB eine neuerliche Programmgestaltungsentscheidung analysieren und herausfinden, ob diese erfolgreich war.
<G-vec00297-002-s479><determine.herausfinden><en> This information is used by us, so that we can determine the device’s general physical location as well as which geographic area our page’s visitors come from.
<G-vec00297-002-s479><determine.herausfinden><de> Durch diese Information können wir den allgemeinen geografischen Standort des Geräts herausfinden und die geografischen Lagen begreifen, woraus die Besucher unserer Webseite herkommen.
<G-vec00297-002-s480><determine.herausfinden><en> Quickly spot potential glitches, identify emerging issues and determine root causes by using embedded, predictive analytics to find and fix problems fast.
<G-vec00297-002-s480><determine.herausfinden><de> Schnell mögliche Störungen erkennen, aufkommende Probleme identifizieren und Ursachen herausfinden, indem Sie integrierte prädiktive Analysen zum schnellen Auffinden und Beheben von Problemen nutzen.
<G-vec00297-002-s481><determine.herausfinden><en> In addition, you can determine if the service is worth shelling out money for and, more importantly, if this particular marketing venue is right for you.
<G-vec00297-002-s481><determine.herausfinden><de> Außerdem können Sie herausfinden ob es sich lohnt für diese Dienstleistung Geld auszugeben, und noch wichtiger, ob diese Marketing Weise die richtige für Sie ist.
<G-vec00297-002-s482><determine.herausfinden><en> Although many players fail to take this step, you should determine which machine has the best payout schedule and then, obviously, use that particular one.
<G-vec00297-002-s482><determine.herausfinden><de> Obwohl viele Spieler dies vergessen, solltest du herausfinden, welcher Spielautomat die beste Gewinnausschüttung hat und dann auch nur diesen benutzen.
<G-vec00297-002-s483><determine.herausfinden><en> In his desire to please God, he resolved to determine what he could have done better, and then he diligently applied each lesson learned.
<G-vec00297-002-s483><determine.herausfinden><de> In seinem Bestreben, Gott zu gefallen, wollte er herausfinden, was er hätte besser machen können, und dann setzte er das, was er daraus lernte, gewissenhaft in die Tat um.
<G-vec00297-002-s484><determine.herausfinden><en> The police have yet to determine what the source of the explosion was.
<G-vec00297-002-s484><determine.herausfinden><de> Die Polizei muss noch herausfinden, was die Quelle der Explosion war.
<G-vec00297-002-s485><determine.herausfinden><en> We encourage you to walk through the steps below to determine what may be causing our system to miss your content.
<G-vec00297-002-s485><determine.herausfinden><de> Befolgen Sie die nachstehenden Schritte, um herausfinden, woran es liegen könnte, dass unser System Ihre Inhalte übersieht.
<G-vec00297-002-s486><determine.herausfinden><en> Looking forward, the researchers want to determine if this type of system is typical or not.
<G-vec00297-002-s486><determine.herausfinden><de> Die Forscher wollen jetzt herausfinden, ob derartige Schieflagen für Doppelsternsysteme typisch sind oder nicht.
<G-vec00297-002-s487><determine.herausfinden><en> It is helpful if the adult, the parent, assist that child in interpreting that time alone, so that they can determine that this is a time to be with God, to be with their Creator and to be within the growing, spiritual presence within themselves.
<G-vec00297-002-s487><determine.herausfinden><de> Es ist hilfreich, wenn die Erwachsenen, die Eltern, den Kindern bei der Interpretierung dieser Zeit "allein" assistieren, so daß sie herausfinden können, daß dies eine Zeit ist mit Gott zu sein, mit dem Schöpfer zu sein und inmitten in der wachsenden spirituellen Präsenz innerhalb ihrer selbst zu sein.
<G-vec00297-002-s488><determine.herausfinden><en> A trading firm could perform its batch reconciliations faster and also determine which scenarios often cause trades to break.
<G-vec00297-002-s488><determine.herausfinden><de> Ein Tradingunternehmen könnte einen schnelleren Batch-Datenabgleich durchführen und herausfinden, welche Szenarien häufig dazu führen, dass Trades platzen.
<G-vec00297-002-s489><determine.herausfinden><en> You can also determine which model you have by contacting Customer Service with the serial number located on the back of your motor base, under the bar code.
<G-vec00297-002-s489><determine.herausfinden><de> Sie können den Produktnamen Ihres Modells auch herausfinden, indem Sie unseren Kundenservice kontaktieren und die Seriennummer nennen, die sich auf der Rück- oder Unterseite der Motorbasis, unterhalb des Barcodes, befindet.
<G-vec00297-002-s490><determine.herausfinden><en> If you can determine what may develop, you have a huge advantage of winning.
<G-vec00297-002-s490><determine.herausfinden><de> Wenn Sie herausfinden können, was los ist zu entwickeln, haben Sie eine große Chance zu gewinnen.
<G-vec00297-002-s491><determine.herausfinden><en> The softness or firmness of the area is important to determine how flexible or rigid your product needs to be.
<G-vec00297-002-s491><determine.herausfinden><de> Die Beschaffenheit Ihres Unterbauches ist entscheidend, um herausfinden zu können, wie flexibel Ihre Versorgung sein sollte.
<G-vec00297-002-s492><determine.herausfinden><en> CT-perfusion can quickly determine which area of the brain is affected specifically by ischemia, and whether reversible or irreversible damage has occurred.
<G-vec00297-002-s492><determine.herausfinden><de> Durch die CT-Perfusion lässt sich rasch herausfinden, welche Hirnareale konkret von der Durchblutungsstörung betroffen sind, und ob es sich um reversible oder bereits irreversible Schäden handelt.
<G-vec00297-002-s493><determine.herausfinden><en> In your answer to this question you need to be honest and discuss your plans for the future so that the interviewer can then determine whether you are suitable for this internship or not.
<G-vec00297-002-s493><determine.herausfinden><de> Als Antwort auf diese Aufforderung musst du ehrlich sein und deine Pläne für die Zukunft beschreiben, damit der Interviewer herausfinden kann, ob du für dieses Praktikum geeignet bist oder nicht.
<G-vec00297-002-s665><determine.überprüfen><en> Napster reserves the right to modify the parameters of your Free Trial at any time, and to determine, in its sole discretion, whether you are eligible for a Free Trial.
<G-vec00297-002-s665><determine.überprüfen><de> Napster behält sich das Recht vor, auf eigenem Ermessen, den Nutzerinhalt zu überprüfen, editieren, einschränken, entfernen oder ansonsten zu genehmigen, jedoch ist Napster in keinem Fall verpflichtet Nutzerinhalte vorbeugend zu überwachen oder zu entfernen.
<G-vec00297-002-s666><determine.überprüfen><en> Controls are usually performed either right after the coating process or during maintenance to monitor the progress of corrosion and to determine whether parts should be re-coated.
<G-vec00297-002-s666><determine.überprüfen><de> Die Messungen werden entweder direkt nach dem Beschichtungsprozess oder bei Wartungsarbeiten durchgeführt, um die bereits entstandene Korrosion der Teile zu kontrollieren, und zu überprüfen, ob eine neue Beschichtung notwendig ist.
<G-vec00297-002-s667><determine.überprüfen><en> The data subject disputes the correctness of the personal data, for a length of time allowing the controller to check the personal data to determine if it is correct.
<G-vec00297-002-s667><determine.überprüfen><de> Die Richtigkeit der personenbezogenen Daten wird von der betroffenen Person bestritten, und zwar für eine Dauer, die es dem Verantwortlichen ermöglicht, die Richtigkeit der personenbezogenen Daten zu überprüfen.
<G-vec00297-002-s668><determine.überprüfen><en> A template downloaded from the library receives an ID with which empower docs is able to determine its currency once it is reopened – even if the document has been saved locally.
<G-vec00297-002-s668><determine.überprüfen><de> Eine Vorlage, die aus der Vorlagenbibliothek heruntergeladen wurde, erhält eine ID mit der empower docs deren Aktualität überprüfen kann, wenn die Vorlage lokal abgespeichert und nach längerer Zeit wieder geöffnet wird.
<G-vec00297-002-s669><determine.überprüfen><en> Restart Money, and then determine whether Money has Internet access.
<G-vec00297-002-s669><determine.überprüfen><de> Starten Sie Money neu, und überprüfen Sie, ob Money Zugang zum Internet hat.
<G-vec00297-002-s670><determine.überprüfen><en> Kingston Technology has commissioned an emissions audit by an outside firm to determine the amount of carbon dioxide being generated at our Orange County facility.
<G-vec00297-002-s670><determine.überprüfen><de> Kingston Technology hat den erzeugten Kohlendioxidausstoss in den Herstellungsanlagen in Orange County durch ein externes Unternehmen überprüfen lassen.
<G-vec00297-002-s671><determine.überprüfen><en> Tamper Evidence:The addition of a mechanism to the outer packaging of a drug allowing the user to determine whether the package has been manipulated will be a mandatory safety feature in Europe.
<G-vec00297-002-s671><determine.überprüfen><de> Tamper Evidence: Um zu überprüfen, ob die äußere Umhüllung einer Arzneimittelverpackung manipuliert wurde, wird eine entsprechende Vorrichtung als Sicherheitsmerkmal zur Pflicht in Europa.
<G-vec00297-002-s672><determine.überprüfen><en> Obtaining an Internet IP Address If your ADSL modem router is unable to access the internet, and your Internet LED is green or blinking green, you should determine whether the ADSL modem router is able to obtain a Internet IP address from the ISP.
<G-vec00297-002-s672><determine.überprüfen><de> 6 Abrufen einer Internet-IP-Adresse Wenn der Wireless ADSL-Modemrouter keinen Zugriff auf das Internet hat und die Internet-LED grün leuchtet oder blinkt, sollten Sie überprüfen, ob der Wireless ADSL-Modemrouter eine Internet-IP-Adresse vom Internet-Provider abrufen kann.
<G-vec00297-002-s673><determine.überprüfen><en> This view count threshold gives us enough information to determine the validity of a channel.
<G-vec00297-002-s673><determine.überprüfen><de> Diese Mindestanzahl an Aufrufen stellt uns genügend Informationen zur Verfügung, um die Berechtigung eines Kanals überprüfen zu können.
<G-vec00297-002-s674><determine.überprüfen><en> Before purchasing Damage Waiver you may wish to determine if your personal coverage is adequate to cover damage, theft, loss of revenue, administration fees, diminishment of value, and any towing, storage or impound fees.
<G-vec00297-002-s674><determine.überprüfen><de> Vor dem Erwerb der Haftungsbeschränkung (DW) sollten Sie überprüfen, ob Ihre private Versicherung Schäden, Diebstahl, Umsatzverluste, Bearbeitungsgebühren, Wertminderung und Abschlepp-, Lagerungs- oder Pfändungskosten ausreichend abdeckt.
<G-vec00297-002-s675><determine.überprüfen><en> You can determine this by looking at the dimensions as you move the cursor around.
<G-vec00297-002-s675><determine.überprüfen><de> Dies können Sie überprüfen, indem Sie beim Bewegen des Cursors auf die angezeigten Maße achten.
<G-vec00297-002-s676><determine.überprüfen><en> The manufacturer will be able to determine from the barcode whether the medicine is genuine or fake.
<G-vec00297-002-s676><determine.überprüfen><de> Der Hersteller kann anhand des Strichcodes überprüfen, ob es sich um ein Originalprodukt handelt.
<G-vec00297-002-s677><determine.überprüfen><en> The aim of the present study was hence to determine if stimulation of the sows, and therefore the success of AI could be enhanced even further by the presence of two boars during AI.
<G-vec00297-002-s677><determine.überprüfen><de> Ziel der vorliegenden Arbeit war es zu überprüfen, ob die Stimulation der Sauen und davon ausgehend die bei der KB erzielten Reproduktionsergebnisse durch die Anwesenheit von zwei Ebern während der KB nochmals verbessert werden können.
<G-vec00297-002-s678><determine.überprüfen><en> In addition, previously identified stamping issues can be compared to determine if the process has been improved in subsequent iterations.
<G-vec00297-002-s678><determine.überprüfen><de> Außerdem lassen sich früher identifizierte Issues vergleichen, um zu überprüfen, ob sich der Prozess in den nachfolgenden Iterationen verbessert hat.
<G-vec00297-002-s679><determine.überprüfen><en> When you write this script for the first time, you should ensure that you have enabled “chat” logging so you can determine if the conversation is going as expected.
<G-vec00297-002-s679><determine.überprüfen><de> Wenn Sie dieses Skript zum ersten Mal schreiben, sollten Sie sicherstellen, dass Sie “chat”-logging aktiviert haben, damit Sie überprüfen zu können, ob die Konversation zwischen Ihrem Rechner und dem Rechner des Providers wie erwartet abläuft.
<G-vec00297-002-s680><determine.überprüfen><en> To determine which brake pad references fit to your B - CLASS, we recommend you select the engine type of your Mercedes-Benz $serie in the drop down menu or enter your registration number.
<G-vec00297-002-s680><determine.überprüfen><de> Um die passende Antriebswelle für Ihren Mercedes-Benz B - KLASSE finden zu können, empfehlen wir Ihnen, die Einbauseite (Rad- oder Getriebeseite), die Verzahnung und die Länge Ihres Originalteils zu überprüfen.
<G-vec00297-002-s681><determine.überprüfen><en> Before prescribing Priligy, the doctor must first conduct a medical examination, including an orthostatic test to determine if the patient could be experiencing a reaction of the same name.
<G-vec00297-002-s681><determine.überprüfen><de> Vor dem Verschreiben von Priligy muss der Arzt erst eine medizinische Untersuchung veranlassen, einschließlich eines orthostatischen Tests, um zu überprüfen ob der Patient eine Reaktion darauf zeigen könnte.
<G-vec00297-002-s682><determine.überprüfen><en> You are therefore obliged to regularly check the date of the General Standard Terms and Conditions before making purchases to determine whether the General Standard Terms and Conditions from earlier orders may have changed.
<G-vec00297-002-s682><determine.überprüfen><de> Sie sind daher verpflichtet, anhand des Datums der AGB regelmäßig vor einem Einkauf zu überprüfen, ob sich die Ihnen aus früheren Bestellungen bekannten AGB gegebenenfalls geändert haben.
<G-vec00297-002-s683><determine.überprüfen><en> In the process we carry out a potential analysis and determine whether the employee matches your requirements through profile matching.
<G-vec00297-002-s683><determine.überprüfen><de> Dazu führen wir eine Potenzialanalyse durch und überprüfen durch Profilematching, ob die/der MitarbeiterIn zu Ihnen passt.
<G-vec00322-002-s590><determine.bestimmen><en> Amid international criticism, the Dominican government has repeatedly argued that it has a right to determine who qualifies for citizenship.
<G-vec00322-002-s590><determine.bestimmen><de> Trotz zunehmender internationaler Kritik hat die dominikanische Regierung mehrfach dafür plädiert [5], selbst bestimmen zu können, wer die Voraussetzungen für eine Staatsbürgerschaft erfüllt und wer nicht.
<G-vec00322-002-s152><determine.enstscheiden><en> The project is classified under Annex II of Council Directive 85/337 as amended by Directive 91/11/C and 2003/35/EC, thus requiring the Member State to determine whether or not a formal Environmental Impact Assessment is required. Procurement
<G-vec00322-002-s152><determine.enstscheiden><de> Das Projekt fällt unter Anhang II der Richtlinie des Rates 85/337/EWG (geändert durch die Richtlinien 91/11/EG und 2003/35/EG), wonach der betreffende Mitgliedstaat entscheidet, ob eine formale Umweltverträglichkeitsprüfung erforderlich ist oder nicht.
<G-vec00322-002-s153><determine.enstscheiden><en> Zoning and planning at the municipal level thus serves as an important instrument that contributes significantly to climate protection and the preservation of air quality: A site plan that has been developed in accordance with the land use plan of a municipality has binding authority to determine whether land areas are used in a manner that the environment can tolerate.
<G-vec00322-002-s153><determine.enstscheiden><de> Die kommunale Ebene der Bauleitplanung gilt dabei als wichtiges Instrument, das zum Schutz des Klimas und zur Luftreinhaltung wesentlich beitragen kann; denn mit dem aus dem Flächennutzungsplan einer Gemeinde entwickelten Bebauungsplan entscheidet sich rechtsverbindlich, ob Grund und Boden umweltverträglich genutzt werden.
<G-vec00322-002-s154><determine.enstscheiden><en> This means that pupils can determine for themselves as to whether they develop the second language to a similar degree as their mother tongue or can simply use it as a second language at the end of their learning period.
<G-vec00322-002-s154><determine.enstscheiden><de> Das heißt, jeder Lernpartner entscheidet selbst, ob er die zweite Sprache so aufbaut, dass er diese am Ende seiner Lernzeit analog seiner Muttersprache beherrscht oder ob er sie lediglich eben als Zweitsprache praktiziert.
<G-vec00322-002-s155><determine.enstscheiden><en> Determined by human leukocyte antigens (see below) and used to determine whether a transplanted tissue or organ will be accepted by the recipient.
<G-vec00322-002-s155><determine.enstscheiden><de> Sie wird durch die humanen Leukozytenantigene (siehe unten) festgelegt und entscheidet, ob ein transplantiertes Gewebe oder Organ von dem Empfänger angenommen wird.
<G-vec00322-002-s156><determine.enstscheiden><en> (The electoral office will check the right to vote on the votes received and in case of doubt determine about their validity or invalidity, double casting of votes leads to invalidity).
<G-vec00322-002-s156><determine.enstscheiden><de> (Das Wahlbüro prüft die Stimmberechtigung der eingegangenen Stimmen und entscheidet bei allfälliger Unklarheit über Gültigkeit oder Ungültigkeit; eine doppelte Stimmabgabe führt zu Ungültigkeit).
<G-vec00322-002-s157><determine.enstscheiden><en> Upon receiving such a request, Creative shall determine whether you require such information for a legitimate purpose and, if so, Creative will provide such information to you within a reasonable time and on reasonable conditions.
<G-vec00322-002-s157><determine.enstscheiden><de> Bei Erhalt solch einer Anfrage entscheidet Creative, ob die Informationen für einen angemessenen Zweck benötigt werden.
<G-vec00322-002-s158><determine.enstscheiden><en> The first are the rich and the well born, the others the mass of the people...The people are turbulent and changing; they seldom judge and determine right.
<G-vec00322-002-s158><determine.enstscheiden><de> Zu den Ersteren zählen die Reichen und diejenigen aus gutem Hause, die Letzteren bilden die Masse des Volkes… Die Bevölkerung ist unruhig und unbeständig; sie beurteilt und entscheidet sich selten richtig.
<G-vec00322-002-s159><determine.enstscheiden><en> Comprehensive tax planning and tax advice in advance of corporate transactions and measures often determine their success.
<G-vec00322-002-s159><determine.enstscheiden><de> Die frühzeitige und umfassende steuerrechtliche Planung und Begleitung unternehmerischer Maßnahmen entscheidet oftmals nicht zuletzt über deren Erfolg.
<G-vec00322-002-s160><determine.enstscheiden><en> You also determine if both or either are real…or not.
<G-vec00322-002-s160><determine.enstscheiden><de> Ihr entscheidet auch, ob beide real sind… oder nicht.
<G-vec00322-002-s161><determine.enstscheiden><en> As with announcements, the administrator or moderators determine whether you can reply to sticky topics.
<G-vec00322-002-s161><determine.enstscheiden><de> Genau wie bei Ankündigungen entscheidet auch hier der Administrator, wer wichtige Themen (oder Post-its) erstellen darf.
<G-vec00322-002-s162><determine.enstscheiden><en> An important part of Awareness is to acknowledge that only the affected person can determine whether their personal boundaries were violated.
<G-vec00322-002-s162><determine.enstscheiden><de> Ein wichtiger Anteil von Awareness ist die Anerkennung der Definitionsmacht: Ob ihre eigenen Grenzen überschritten wurden, entscheidet immer ausschließlich die betroffene Person.
<G-vec00322-002-s163><determine.enstscheiden><en> This will determine which of the 4 relationships we have.
<G-vec00322-002-s163><determine.enstscheiden><de> Diese Beziehung entscheidet, welches der vier möglichen Relationships vorliegt.
<G-vec00322-002-s164><determine.enstscheiden><en> If you have requested EPP, then upon receipt of Additional Registration Data, Eventbrite will determine, in its discretion, whether you are qualified to use EPP.
<G-vec00322-002-s164><determine.enstscheiden><de> Wenn Sie EPP angefragt haben, entscheidet Eventbrite nach Erhalt der zusätzlichen Registrierungsdaten nach eigenem Ermessen, ob Sie zur Nutzung von EPP berechtigt sind.
<G-vec00322-002-s165><determine.enstscheiden><en> The requested authority shall determine, if necessary with the assistance of other public authorities, the enforcement measures to be taken to bring about the cessation or prohibition of the intra-Community infringement in a proportionate, efficient and effective way.
<G-vec00322-002-s165><determine.enstscheiden><de> Die ersuchte Behörde entscheidet, gegebenenfalls mit der Unterstützung anderer Behörden, welche Durchsetzungsmaßnahmen getroffen werden, um auf verhältnismäßige, wirksame und effiziente Weise eine Einstellung oder ein Verbot des innergemeinschaftlichen Verstoßes zu bewirken.
<G-vec00322-002-s166><determine.enstscheiden><en> The competent authority shall determine whether the conditions are met on the basis of the assessment referred to in paragraph 1 and other available information, particularly concerning the protection of the environment and human health.
<G-vec00322-002-s166><determine.enstscheiden><de> Auf der Grundlage der in Absatz 1 genannten Bewertung und anderer verfügbarer Informationen, insbesondere in Bezug auf den Schutz der Umwelt und der menschlichen Gesundheit, entscheidet die zuständige Behörde, ob die Voraussetzungen erfüllt sind.
<G-vec00322-002-s167><determine.enstscheiden><en> Most medications that treat creatinine levels also treat an underlying problem causing an increase in those levels, so your doctor will have to diagnose the underlying condition before you can determine which medication is right for you.
<G-vec00322-002-s167><determine.enstscheiden><de> Die meisten Medikamente, die den Kreatininwert behandeln, kurieren auch die eigentliche Ursache, die zu den erhöhten Werten führt, daher muss dein Arzt zunächst die eigentliche Erkrankung diagnostizieren, bevor er entscheidet, welches Medikament für dich das richtige ist.
<G-vec00322-002-s168><determine.enstscheiden><en> The properties of PUR determine how it is used.
<G-vec00322-002-s168><determine.enstscheiden><de> Die Verwendung von PUR entscheidet sich nach den Eigenschaften des Materials.
<G-vec00322-002-s169><determine.enstscheiden><en> Upon contacting Formlabs, our Customer Service team will determine whether you may be eligible for Warranty Service or Repair Service and authorize your return of Formlabs product(s) as appropriate.
<G-vec00322-002-s169><determine.enstscheiden><de> Wenn Sie mit Formlabs in Kontakt treten, entscheidet unser Kundendienstteam, ob Sie für den Garantieservice oder den Reparaturservice in Frage kommen und autorisieren die Rückgabe Ihres Formlabs-Produkts.
<G-vec00322-002-s170><determine.enstscheiden><en> Each masternode in the network is entitled to one vote on any given proposal, and a majority will determine whether or not a proposal is passed.
<G-vec00322-002-s170><determine.enstscheiden><de> Jede Masternode kann über Vorschläge abstimmen und die Mehrheit der Stimmen entscheidet, ob ein Vorschlag akzeptiert wird.
<G-vec00322-002-s133><determine.entscheiden><en> If we determine that the correct price is higher than the stated price, we are not obligated to fulfill your order at the stated price.
<G-vec00322-002-s133><determine.entscheiden><de> Wenn wir entscheiden, dass der korrekte Preis höher ist als der angegebene Preis, sind wir nicht verpflichtet, die Bestellung zum angegebenen Preis auszuführen.
<G-vec00322-002-s134><determine.entscheiden><en> However, ultimately it is the strength and support of local churches and ecumenical youth networks which determine how the seeds planted in the stewards programme will take root in the stewards’ own soil.
<G-vec00322-002-s134><determine.entscheiden><de> Letztlich wird jedoch die Kraft und die Unterstützung der Ortskirchen und der ökumenischen Jugendnetzwerke darüber entscheiden, wie die mit dem Steward-Programm angelegte Saat in der eigenen Erde der Stewards aufgeht.
<G-vec00322-002-s135><determine.entscheiden><en> Creativity and innovations determine the ability of each and every company to compete.
<G-vec00322-002-s135><determine.entscheiden><de> Kreativität und Innovationen entscheiden über die Wettbewerbsfähigkeit jedes einzelnen Unternehmens.
<G-vec00322-002-s136><determine.entscheiden><en> Allow children to self-regulate – to determine when they are hungry and full.
<G-vec00322-002-s136><determine.entscheiden><de> Lassen Sie Kinder selbst entscheiden, wann sie hungrig oder satt sind.
<G-vec00322-002-s137><determine.entscheiden><en> If you determine to use this pill, it is necessary to comply with the suggested quantity and dieting instructions.
<G-vec00322-002-s137><determine.entscheiden><de> Wenn Sie sich entscheiden, diese Pille zu verwenden, ist es wichtig, die empfohlene Dosierung und Diäten Anweisungen zu folgen.
<G-vec00322-002-s138><determine.entscheiden><en> We will determine your compliance with this Agreement in our sole discretion and our decision shall be final and binding.
<G-vec00322-002-s138><determine.entscheiden><de> Wir entscheiden im alleinigen Ermessen über Ihre Einhaltung dieser Vereinbarung, und unsere Entscheidung ist endgültig und verbindlich.
<G-vec00322-002-s139><determine.entscheiden><en> The fifth field, (fs_freq), is used for these filesystems by the dump(8) command to determine which filesystems need to be dumped.
<G-vec00322-002-s139><determine.entscheiden><de> Das fünfte Feld, (fs_freq), wird von dump(8) benutzt, um zu entscheiden, welche Dateisysteme gedumpt werden müssen.
<G-vec00322-002-s140><determine.entscheiden><en> As before, feedback from this test will help us determine whether we need to make some adjustments before we go live with Competitive Mode, so be sure to share your thoughts on the current settings.
<G-vec00322-002-s140><determine.entscheiden><de> Feedback aus dieser Testrunde wird in zukünftigen Diskussionen über die Gestaltung des Ranked-Regelwerks mit einbezogen, bevor wir uns dazu entscheiden werden, mit dem kompetitiven Modus live zu gehen.
<G-vec00322-002-s141><determine.entscheiden><en> The ships you choose to field will determine everything.
<G-vec00322-002-s141><determine.entscheiden><de> Die Schiffe, die du in die Schlacht schickst, entscheiden alles.
<G-vec00322-002-s142><determine.entscheiden><en> In most cases the prostitute is at liberty to determine whether she or he will engage in a particular type of sexual activity, but forced prostitution exists in some places around the world as does sexual slavery.
<G-vec00322-002-s142><determine.entscheiden><de> In den meisten Fällen steht es der Prostituierten zu, frei zu entscheiden, ob er oder sie sich an bestimmten Arten von sexuellen Handlungen beteiligen will, aber es gibt auch Zwangsprostitution und sexuelle Sklaverei weltweit.
<G-vec00322-002-s143><determine.entscheiden><en> Based upon the set of rules programmed in advance, the machines themselves determine the timing and quantities of requests for resources.
<G-vec00322-002-s143><determine.entscheiden><de> Unter Berücksichtigung des vorab programmierten Regelwerks entscheiden die Maschinen eigenständig über den Zeitpunkt und den Umfang aller Ressourcen.
<G-vec00322-002-s144><determine.entscheiden><en> Regardless of the exact relationships and incidents between the different family members, those are the ones to stay with us our entire life and to determine much more in it than most are aware of... For these reasons the family is quite a private matter for most.
<G-vec00322-002-s144><determine.entscheiden><de> Und unabhängig welche genauen Lebensumstände und -ereignisse zwischen den Familienmitgliedern zustande kommen, begleiten doch genau diese uns ganz tief unser Leben lang und entscheiden leise über mehr als manch einem bewusst ist... Für viele ist daher die eigene Familie eine ziemlich private Angelegenheit.
<G-vec00322-002-s145><determine.entscheiden><en> We will determine, in our discretion, whether there has been a breach of this acceptable use policy through your use of our site.
<G-vec00322-002-s145><determine.entscheiden><de> AUSSETZUNG UND KÜNDIGUNG Wir entscheiden nach alleinigem Ermessen, ob Sie durch die Nutzung unserer Seite gegen diese Nutzungsrichtlinien verstoßen haben.
<G-vec00322-002-s146><determine.entscheiden><en> A professional can help you determine the best combination to meet your needs.
<G-vec00322-002-s146><determine.entscheiden><de> Ein professioneller Ernährungsberater kann dir helfen zu entscheiden, welche Kombination am besten zu deinen Bedürfnissen passt.
<G-vec00322-002-s147><determine.entscheiden><en> Your journey takes you from the forgotten catacombs beneath the subway to the desolate wastelands above, where your actions will determine the fate of mankind. Key Features
<G-vec00322-002-s147><determine.entscheiden><de> Ihre Reise führt Sie von vergessenen Katakomben unter dem Zugsystem zu den desolaten Wüsten der Außenwelt, in denen Ihre Aktionen das Schicksal der Menschheit entscheiden werden.
<G-vec00322-002-s149><determine.entscheiden><en> The User must carefully read this Privacy Policy, which has been written clearly and simply, to facilitate its understanding, and to freely and voluntarily determine whether he/she wishes to provide their personal data, or those of third parties.
<G-vec00322-002-s149><determine.entscheiden><de> Der Nutzer hat diese Datenschutzrichtlinie, die klar und einfach formuliert ist, um das Verständnis zu erleichtern, aufmerksam zu lesen, und aus freien Stücken zu entscheiden, ob er seine personenbezogenen Daten oder die Daten Dritter übermitteln möchte.
<G-vec00322-002-s150><determine.entscheiden><en> By improving the quality of the listings, potential customers can determine more easily whether your lease is the perfect lease for them.
<G-vec00322-002-s150><determine.entscheiden><de> Indem Sie die Qualität Ihrer Inserate optimieren, können potentielle Kunden leichter entscheiden, ob Ihr Angebot die idealen Konditionen für sie bietet.
<G-vec00322-002-s151><determine.entscheiden><en> It is necessary to process your application data in order to be able to determine whether there are grounds for establishing an employment relationship.
<G-vec00322-002-s151><determine.entscheiden><de> Die Bearbeitung Ihrer Bewerberdaten ist erforderlich, um über die Begründung eines Anstellungsverhältnisses entscheiden zu können.
<G-vec00322-002-s234><determine.ermitteln><en> This makes it necessary to always determine a new a*act,R,Z correction factor for each light source.
<G-vec00322-002-s234><determine.ermitteln><de> Demnach muss für jedes Gerät bei jeder Lichtquelle ein neuer a*act,R,Z-Korrekturfaktor ermittelt werden.
<G-vec00322-002-s322><determine.feststellen><en> Unable to determine the controller type for the disk '[Disk Name] VMDK name.'
<G-vec00322-002-s322><determine.feststellen><de> Der Kontrollertyp für die Festplatte '[Festplattenname] VMDK-Name' konnte nicht festgestellt werden.
<G-vec00322-002-s570><determine.prüfen><en> We will determine whether the offered vendor solutions match your requirements and run comparative prototype tests.
<G-vec00322-002-s570><determine.prüfen><de> Wir prüfen für Sie, ob die angebotenen Lösungen Ihren Anforderungen entsprechen und führen Vergleichstests an verschiedenen Prototypen durch.
<G-vec00322-002-s571><determine.prüfen><en> Use our free online compensation calculator to determine if you are eligible.
<G-vec00322-002-s571><determine.prüfen><de> Dann prüfen Sie doch mithilfe unseres Entschädigungsrechner, ob Ihnen eine Entschädigung zusteht – einfach, schnell und unverbindlich.
<G-vec00322-002-s572><determine.prüfen><en> You should consult an independent investment adviser prior to making an investment in a short ETP in order to determine its suitability for your circumstances. Index Details
<G-vec00322-002-s572><determine.prüfen><de> Sie sollten vor einer Anlageentscheidung den Rat eines unabhängigen Anlageberaters einholen, um zu prüfen, ob die Investition in ein Short-ETP unter Berücksichtigung Ihrer individuellen Situation für Sie geeignet ist.
<G-vec00322-002-s573><determine.prüfen><en> It will, therefore, be necessary to determine whether the practice of the hospitals managed by IR falls within the doctrine of the Catholic Church in that those services are provided in a way that distinguishes them clearly from the services provided by public hospitals.
<G-vec00322-002-s573><determine.prüfen><de> Daher wird zu prüfen sein, ob die Praxis der von IR betriebenen Krankenhäuser in Bezug auf die Erbringung dieser Leistungen der Lehre der katholischen Kirche in einer Art folgt, die sie in qualifizierter Weise von denen öffentlicher Krankenhäuser unterscheidet.
<G-vec00322-002-s574><determine.prüfen><en> 5.2 The buyer shall inspect visually and test the goods immediately upon receipt to determine whether the condition and quantity of the goods conforms to the applicable contractual agreement.
<G-vec00322-002-s574><determine.prüfen><de> 5.2 Der Käufer ist verpflichtet, unverzüglich nach Erhalt der Ware zu prüfen, ob die Beschaffenheit und Menge den vertraglichen Vereinbarungen entspricht.
<G-vec00322-002-s575><determine.prüfen><en> When an employee signs in at the terminal to get clothes, the software can determine whether the employee's driver's licence has to be checked.
<G-vec00322-002-s575><determine.prüfen><de> Meldet sich ein Mitarbeiter zur Kleiderausgabe am Terminal an, kann die Software prüfen, ob der Führerschein des Mitarbeiters kontrolliert werden muss.
<G-vec00322-002-s576><determine.prüfen><en> Shortly before our connecting flight the doctor saw me again to determine my health.
<G-vec00322-002-s576><determine.prüfen><de> Kurz vor dem Anschlussflug sah der Arzt nochmals nach mir, um meinen Gesundheitszustand zu prüfen.
<G-vec00322-002-s577><determine.prüfen><en> A more efficient approach would be to determine whether the rare and regional differences in the incidence of individual chemicals poses a health risk and warrants permanent monitoring.
<G-vec00322-002-s577><determine.prüfen><de> Effizienter ist, bei diesen selten und regional unterschiedlich auftretenden Stoffen einzelfallbezogen zu prüfen, ob ein gesundheitliches Risiko besteht und eine dauerhafte Überwachung sinnvoll ist.
<G-vec00322-002-s578><determine.prüfen><en> In each individual case, the authority concerned must determine whether and why an exception as stated in the law should be made, and provide the reasons for this in writing.
<G-vec00322-002-s578><determine.prüfen><de> Dennoch muss das BLV in jedem Einzelfall prüfen und schriftlich begründen, ob und – falls ja – warum eine der genannten Ausnahmen vorliegt.
<G-vec00322-002-s579><determine.prüfen><en> The Hamburg Welfare Agency, as the cost-bearer for Frieda’s treatment, required a yearly report in order to determine how long she would remain at the Institute.
<G-vec00322-002-s579><determine.prüfen><de> Jährlich forderte das Wohlfahrtsamt Hamburg, der damalige Kostenträger für Friedas Behandlung, Gutachten an, um zu prüfen, wie lange ihr Aufenthalt noch dauern würde.
<G-vec00322-002-s580><determine.prüfen><en> We process your personal data in order to determine whether you are travelling with a valid ticket.
<G-vec00322-002-s580><determine.prüfen><de> Wir verarbeiten Ihre personenbezogenen Daten, um zu prüfen, ob Sie mit einem gültigen Ticket reisen.
<G-vec00322-002-s581><determine.prüfen><en> It is User's sole responsibility to determine the accuracy of all advertising statements.
<G-vec00322-002-s581><determine.prüfen><de> Der Nutzer allein ist gehalten, die Fehlerfreiheit aller Angaben in der Produktwerbung zu prüfen.
<G-vec00322-002-s582><determine.prüfen><en> As far as possible and necessary, we will also determine whether and how the Change Request has implications on services renderes so far and their usability.
<G-vec00322-002-s582><determine.prüfen><de> Soweit möglich und notwendig, werden wir auch prüfen, inwieweit eine solche Änderung Auswirkungen auf bisher realisierte Leistungen und deren Nutzbarkeit hat.
<G-vec00322-002-s583><determine.prüfen><en> We will then determine whether the minimum number of 8 participants has been reached.
<G-vec00322-002-s583><determine.prüfen><de> Wir prüfen dann, ob die Mindestteilnehmendenzahl von 6 Personen erreicht ist.
<G-vec00322-002-s584><determine.prüfen><en> Our asset managers visit out clients four times a year, at home or at the office, to discuss the investment portfolio and determine whether the investment objectives are still up to date.
<G-vec00322-002-s584><determine.prüfen><de> Die Vermögensverwalter von Vimco kommen nämlich viermal pro Jahr zum Kunden, sei es zu Hause oder im Büro, um das Portfolio zu besprechen und zu prüfen, ob die Anlageziele noch aktuell sind.
<G-vec00322-002-s586><determine.prüfen><en> Note: Allianz reserves the right to determine coverage eligibility apart from Turo.
<G-vec00322-002-s586><determine.prüfen><de> Hinweis: Allianz behält sich – ungeachtet der Einschätzung durch Turo – das Recht vor zu prüfen, ob die Deckung gegeben ist.
<G-vec00322-002-s587><determine.prüfen><en> The most potent envelope immunogens developed in this thesis will be analyzed in a preclinical immunization study starting in June 2017 to determine whether their improved antigenicity and stability in vitro will ultimately translate into enhanced immunogenicity in vivo.
<G-vec00322-002-s587><determine.prüfen><de> Eine präklinische Immunisierungsstudie wird ab Juni 2017 prüfen, ob die in vitro demonstrierte verbesserte Antigenität und Stabilität der generierten Immunogene letztendlich auch deren Immunogenität positiv beeinflusst.
<G-vec00322-002-s588><determine.prüfen><en> “Intensive sharing across our industry particularly on future issues and technologies will help us to determine where we as a group can make a contribution and what key skills will be required in the future,” says OHB SE Management Board member Dr. Fritz Merkle.
<G-vec00322-002-s588><determine.prüfen><de> „Der intensive Austausch in der Branche insbesondere über zukünftige Themen und Technologien ermöglicht es uns, zu prüfen, wo wir als Unternehmensgruppe beitragsfähig sind und welche Schlüsselkompetenzen in Zukunft gefragt sind“, sagt OHB SE Vorstand Dr. Fritz Merkle.
<G-vec00127-002-s038><determine.bestimmen><en> Determine the purpose and audience.
<G-vec00127-002-s038><determine.bestimmen><de> Bestimme den Zweck und die Zielgruppe.
<G-vec00127-002-s039><determine.bestimmen><en> Determine the country codes which identify motorized vehicles from these countries.
<G-vec00127-002-s039><determine.bestimmen><de> Bestimme in weiterer Folge die Autokennzeichen dieser beiden Staaten.
<G-vec00127-002-s040><determine.bestimmen><en> Determine who will be in charge of what and when.
<G-vec00127-002-s040><determine.bestimmen><de> Bestimme, wer wann für was verantwortlich sein wird.
<G-vec00127-002-s041><determine.bestimmen><en> Just as the weatherman does not determine the weather, I likewise do not determine the results of scientific studies.
<G-vec00127-002-s041><determine.bestimmen><de> Ebenso wie der Wetterexperte nicht das Wetter bestimmt so bestimme ich nicht die Folgen wissenschaftlicher Untersuchungen.
<G-vec00127-002-s042><determine.bestimmen><en> Determine the market size.
<G-vec00127-002-s042><determine.bestimmen><de> Bestimme die Marktgröße.
<G-vec00127-002-s043><determine.bestimmen><en> Determine the angle, which is monitored by the camera.
<G-vec00127-002-s043><determine.bestimmen><de> Bestimme den Winkel, in dem die Überwachungskamera aufzeichnet.
<G-vec00127-002-s044><determine.bestimmen><en> 2 Determine whether your cervix is firm or soft.
<G-vec00127-002-s044><determine.bestimmen><de> 2 Bestimme, ob dein Muttermund weich oder fest ist.
<G-vec00127-002-s045><determine.bestimmen><en> 1 Determine the order of a reaction when doubling either reactant results in a doubling of the rate.
<G-vec00127-002-s045><determine.bestimmen><de> 1 Bestimme die Reaktionsordnung, wenn das Verdoppeln eines Reaktanten eine Verdopplung der Geschwindigkeit ergibt.
<G-vec00127-002-s046><determine.bestimmen><en> Step 2: Determine how to play your hands
<G-vec00127-002-s046><determine.bestimmen><de> Schritt 2: Bestimme, wie du deine Hände spielst.
<G-vec00127-002-s047><determine.bestimmen><en> Determine the fate of Earth and the Marvel universe 1 Players
<G-vec00127-002-s047><determine.bestimmen><de> Bestimme das Schicksal der Erde und des Marvel-Universums.
<G-vec00127-002-s048><determine.bestimmen><en> (5) Determine which formation layer is cut by this cutlet by comparing yi+i with hole coordinate yh, if y;,+1 < yh first layer is cut (this step is the same as Algorithm A).
<G-vec00127-002-s048><determine.bestimmen><de> (5) Bestimme, welche Formationslage geschnitten wird durch dieses kleine Fräselement durch das Vergleichen von y i+1 mit den Lochkoordinaten y h, wenn y i+1 < y h, dann ist die erste Lage geschnitten (dieser Schritt ist der Gleiche wie im algorithm A).
<G-vec00127-002-s049><determine.bestimmen><en> Determine the mother's ovulation date.
<G-vec00127-002-s049><determine.bestimmen><de> Bestimme den Eisprung der Mutter.
<G-vec00127-002-s050><determine.bestimmen><en> Simply select the month in which the season break should begin and determine how long it will last (max.
<G-vec00127-002-s050><determine.bestimmen><de> Wähle einfach den Monat aus, in welcher die Saisonpause beginnen soll und bestimme wie lange diese geht (max.
<G-vec00127-002-s051><determine.bestimmen><en> I model on a virtual body whose mass I determine in advance.
<G-vec00127-002-s051><determine.bestimmen><de> Ich modelliere an einem virtuellen Körper, dessen Masse ich im Vorfeld bestimme.
<G-vec00127-002-s052><determine.bestimmen><en> Sort through the things that constantly give you clutter and determine how useful it is to you.
<G-vec00127-002-s052><determine.bestimmen><de> Sortiere die Dinge, die ständig für Unordnung sorgen, und bestimme, wie nützlich sie sind.
<G-vec00127-002-s053><determine.bestimmen><en> I know how to prevent that spiritual knowledge, which originated from Me in all purity, gets into the wrong hands, for there is only a short time left until the end and I Myself determine which route the spiritual knowledge takes, and I will also always choose the right workers who will leave it unchanged and whose sacred awe prevents them from implementing changes which are not My will.
<G-vec00127-002-s053><determine.bestimmen><de> Ich werde es zu verhindern wissen, daß ein Geistesgut, das in aller Reinheit von Mir ausgegangen ist, in unrechte Hände kommt, denn die Zeit bis zum Ende ist nur noch kurz, und welche Wege das Geistesgut nimmt, das bestimme Ich Selbst, und Ich werde dafür auch immer die rechten Kräfte auswählen, die es unverändert lassen und die eine heilige Scheu hindert daran, eine Veränderung vorzunehmen, die nicht Mein Wille ist.
<G-vec00127-002-s054><determine.bestimmen><en> Determine if the hard drive is the problem.
<G-vec00127-002-s054><determine.bestimmen><de> Bestimme, ob die Festplatte das Problem ist.
<G-vec00127-002-s055><determine.bestimmen><en> But I even determine the hour of the earthly demise Myself, if the human being will not manifestly oppose Me and end his life himself and thereby indeed prolongs the state of death for an infinite time again, but he will never be able to end his existence....
<G-vec00127-002-s055><determine.bestimmen><de> Aber auch die Stunde des irdischen Vergehens bestimme Ich Selbst, wenn nicht der Mensch sich selbst offensichtlich Mir widersetzt und sein Leben selbst beendet und dadurch wohl den Todeszustand wieder endlos verlängert, niemals aber seine Existenz beenden kann....
<G-vec00127-002-s056><determine.bestimmen><en> 1 Determine the cause of your ear congestion.
<G-vec00127-002-s056><determine.bestimmen><de> 1 Bestimme die Ursache deiner Ohrverstopfung.
<G-vec00127-002-s057><determine.bestimmen><en> If you’d like to pay us a visit, it is best if you take your old lamp base with you, so that we can properly determine the size and the model.
<G-vec00127-002-s057><determine.bestimmen><de> Falls Sie uns im Möbelhaus besuchen möchten, dann können Sie Ihren alten Lampenfuß am besten mitbringen, sodass wir die Größe und das Modell gut bestimmen können.
<G-vec00127-002-s058><determine.bestimmen><en> Although FASR is a system designed for determine most of the in use setups it has a lack of terms.
<G-vec00127-002-s058><determine.bestimmen><de> Obwohl FASR als ein System festgelegt wurde, das ermöglichen soll, die meisten gängigen Setups zu bestimmen und zu benennen, besitzt es diesbezüglich einen Mangel.
<G-vec00127-002-s059><determine.bestimmen><en> [%] CT XRF analysis is used to determine the elements contained in activated carbon without prior digestion.
<G-vec00127-002-s059><determine.bestimmen><de> [%] CT Mit der RFA lassen sich die in der Aktivkohle enthaltenen Elemente ohne einen vorherigen Aufschluss bestimmen.
<G-vec00127-002-s060><determine.bestimmen><en> LT Ultra is able to design any new adaptive membranes using simulation programs and to determine their degree of deformation as a function of the control pressure.
<G-vec00127-002-s060><determine.bestimmen><de> LT-Ultra ist in der Lage mittels Simulationsprogrammen jegliche neue adaptive Membrane auszulegen und deren Deformationsgrad in Abhängigkeit des Ansteuerdrucks zu bestimmen.
<G-vec00127-002-s061><determine.bestimmen><en> Receive AI-driven suggestions to determine what access should be requested, approved or removed.
<G-vec00127-002-s061><determine.bestimmen><de> Erhalten Sie KI-gesteuerte Vorschläge, um zu bestimmen, welcher Zugriff angefragt, genehmigt oder entfernt werden soll.
<G-vec00127-002-s062><determine.bestimmen><en> Its aggregate state and physical properties largely determine the functions of this type of tissue.
<G-vec00127-002-s062><determine.bestimmen><de> Sein Aggregatzustand und seine physikalischen Eigenschaften bestimmen weitgehend die Funktionen dieses Gewebetyps.
<G-vec00127-002-s063><determine.bestimmen><en> The two-week synod is the beginning of a year long process that could determine the church’s approach on some of the social issues of today.
<G-vec00127-002-s063><determine.bestimmen><de> Die zweiwöchige Synode ist der Beginn eines einjährigen Prozesses, der das Verhalten der Kirche gegenüber einigen brennenden Fragen der heutigen Gesellschaft bestimmen könnte.
<G-vec00127-002-s064><determine.bestimmen><en> If you want to set the page margins for your publication to match the minimum margin that is supported by your printer, you must first determine the size of your printer's nonprintable region.
<G-vec00127-002-s064><determine.bestimmen><de> Wenn Sie die Seitenränder für Ihre Publikation entsprechend dem von Ihrem Drucker unterstützten minimalen Seitenrand festlegen möchten, müssen Sie zunächst die Größe des nicht druckbaren Bereichs Ihres Druckers bestimmen.
<G-vec00127-002-s065><determine.bestimmen><en> For instance in this “single-arm” study their is an absence of comparison with a control group in order to determine a “net effect” of the new approach.
<G-vec00127-002-s065><determine.bestimmen><de> So fehle etwa bei dieser „Single-arm“-Studie der Vergleich zu einer Kontrollgruppe, um einen „Netto-Effekt“ des neuen Ansatzes zu bestimmen.
<G-vec00127-002-s066><determine.bestimmen><en> By selecting Plain Chords, Pattern, or Sections, you can determine how the notes of a chord are played.
<G-vec00127-002-s066><determine.bestimmen><de> Indem Sie Akkorde, Pattern oder Bereiche auswählen, können Sie bestimmen, wie die Noten eines Akkords gespielt werden.
<G-vec00127-002-s067><determine.bestimmen><en> That decision is up to you...your actions will determine this.
<G-vec00127-002-s067><determine.bestimmen><de> Die Entscheidung liegt bei Ihnen, Ihr Handeln wird dies bestimmen.
<G-vec00127-002-s068><determine.bestimmen><en> They refer to the three parts that make up our personality and which decisively determine our actions in this world.
<G-vec00127-002-s068><determine.bestimmen><de> Sie beziehen sich auf die drei Anteile, die unsere Persönlichkeit bilden und maßgeblich unser Handeln in dieser Welt bestimmen.
<G-vec00127-002-s069><determine.bestimmen><en> In the normal run of things we proceed into a future whose content we determine through our concrete needs and plans, and from which we exclude the final horizon of death.
<G-vec00127-002-s069><determine.bestimmen><de> Im Normalfall verstehen wir uns von der Gegenwart her auf eine Zukunft hin, die wir durch unsere konkreten Bedürfnisse und Pläne inhaltlich bestimmen und aus der wir den Letzthorizont des Todes gerade ausklammern.
<G-vec00127-002-s070><determine.bestimmen><en> Or read about the four factors that determine the price of a diamond in our jewellery glossary.
<G-vec00127-002-s070><determine.bestimmen><de> Oder informieren Sie sich im Schmucklexikon nach, welche vier Faktoren den Preis eines Diamanten bestimmen.
<G-vec00127-002-s071><determine.bestimmen><en> We invest in knowledge and technology, because our customers determine how high the bar is set.
<G-vec00127-002-s071><determine.bestimmen><de> Wir investieren in Kenntnisse und Techniken, denn unsere Kunden bestimmen, wie hoch die Latte liegt.
<G-vec00127-002-s072><determine.bestimmen><en> It is not easy to determine how reliable a particular test is for a particular breed.
<G-vec00127-002-s072><determine.bestimmen><de> Es ist im Einzelfall nicht immer einfach, die Signifikanz eines bestemmten Tests für eine bestimmte Population zu bestimmen.
<G-vec00127-002-s073><determine.bestimmen><en> WingChun is the basis for your further development, which you yourself can freely and confidently determine.
<G-vec00127-002-s073><determine.bestimmen><de> WingChun ist die Basis für Ihre Weiterentwicklung, die Sie frei und selbstbewusst bestimmen.
<G-vec00127-002-s074><determine.bestimmen><en> Additional considerations Before you create the scope, determine starting and ending IP addresses to be used within it.
<G-vec00127-002-s074><determine.bestimmen><de> Weitere Überlegungen Bevor Sie den Bereich erstellen, bestimmen Sie die zu verwendenden Start- und End-IP-Adressen.
<G-vec00127-002-s075><determine.bestimmen><en> Therefore, it is wise to determine entry and exit points near these lines to avoid disappointment.
<G-vec00127-002-s075><determine.bestimmen><de> Daher ist es ratsam, Eintritts - und Austrittspunkte nahe diesen Linien zu bestimmen, um Enttäuschungen zu vermeiden.
<G-vec00127-002-s076><determine.bestimmen><en> ◆ Determine the installation location and layers.
<G-vec00127-002-s076><determine.bestimmen><de> ◆Bestimmen Sie den Installationsstandort und -schichten.
<G-vec00127-002-s077><determine.bestimmen><en> Determine the duration of the shortest and longest menstrual cycles in the analyzed period.
<G-vec00127-002-s077><determine.bestimmen><de> Bestimmen Sie die Dauer der kürzesten und längsten Menstruationszyklen im analysierten Zeitraum.
<G-vec00127-002-s078><determine.bestimmen><en> Determine the alcohol content of binary mixtures for various beverages using density, sound velocity, or refractive index.
<G-vec00127-002-s078><determine.bestimmen><de> Bestimmen Sie den Alkoholgehalt von Zweistoffgemischen für verschiedene Getränke mithilfe der Dichte, der Schallgeschwindigkeit oder des Brechungsindex.
<G-vec00127-002-s079><determine.bestimmen><en> Quickly determine whether or not the wall of a pressure vessel, exchanger, or tank can withstand piping loads.
<G-vec00127-002-s079><determine.bestimmen><de> Bestimmen Sie innerhalb kürzester Zeit, ob die Wand eines Druckbehälters, Wärmetauschers oder Tanks der Rohrbeanspruchung standhält oder nicht.
<G-vec00127-002-s080><determine.bestimmen><en> Determine where in your apartment, house or room is South-West.
<G-vec00127-002-s080><determine.bestimmen><de> Bestimmen Sie, wo in Ihrer Wohnung, Haus oder Zimmer ist Süd-Westen.
<G-vec00127-002-s081><determine.bestimmen><en> Before ordering the built-in closet cabinet, determine the place where it will be placed (the dimensions depend on it), and then think over the design, interior filling and appearance, with which the designer in the store will help you.
<G-vec00127-002-s081><determine.bestimmen><de> Bevor Sie den Einbauschrank bestellen, bestimmen Sie den Ort, an dem er aufgestellt werden soll (die Abmessungen hängen davon ab), und überlegen Sie sich dann über das Design, die Innenfüllung und das Aussehen, mit dem der Designer im Geschäft Ihnen helfen wird.
<G-vec00127-002-s082><determine.bestimmen><en> Determine the percentage of insurance period.
<G-vec00127-002-s082><determine.bestimmen><de> Bestimmen Sie den Prozentsatz der Versicherungsdauer.
<G-vec00127-002-s083><determine.bestimmen><en> Then determine the overall style of the room, plan the layout and design elements of the room.
<G-vec00127-002-s083><determine.bestimmen><de> Dann bestimmen Sie den gesamten Stil des Raumes, planen Sie das Layout und Design-Elemente des Raumes.
<G-vec00127-002-s084><determine.bestimmen><en> Determine the place where you will celebrate this event.
<G-vec00127-002-s084><determine.bestimmen><de> Bestimmen Sie den Ort, an dem Sie dieses Ereignis feiern werden.
<G-vec00127-002-s085><determine.bestimmen><en> Determine what exactly he is afraid of, and draw up a plan of action.
<G-vec00127-002-s085><determine.bestimmen><de> Bestimmen Sie, wovor genau er Angst hat, und erstellen Sie einen Aktionsplan.
<G-vec00127-002-s086><determine.bestimmen><en> Determine your brand’s identity by first figuring out your core values – the traits, beliefs, and essential decisions that drive it forward.
<G-vec00127-002-s086><determine.bestimmen><de> Bestimmen Sie die Identität Ihrer Marke, indem Sie zuerst Ihre zentralen Werte erkennen – die Eigenschaften, Überzeugungen und grundlegenden Entscheidungen, die hinter Ihrer Marke stehen.
<G-vec00127-002-s087><determine.bestimmen><en> Activity: determine if it's a business group or not.
<G-vec00127-002-s087><determine.bestimmen><de> Aktivität: Bestimmen Sie, ob es eine Businessgruppe ist oder nicht.
<G-vec00127-002-s088><determine.bestimmen><en> Determine the nature of the human person.
<G-vec00127-002-s088><determine.bestimmen><de> Bestimmen Sie die Art der menschlichen Person.
<G-vec00127-002-s089><determine.bestimmen><en> Determine the IPO structure at the beginning of the process.
<G-vec00127-002-s089><determine.bestimmen><de> Bestimmen Sie die IPO-Struktur zu Beginn des Verfahrens.
<G-vec00127-002-s090><determine.bestimmen><en> Determine and adjust the viscosity exactly at the defined temperature.
<G-vec00127-002-s090><determine.bestimmen><de> Bestimmen Sie die Viskosität bei einer exakt definierten Temperatur und passen Sie sie an.
<G-vec00127-002-s091><determine.bestimmen><en> Availability Availability Determine when you would like to be scheduled and explore our advanced availability options.
<G-vec00127-002-s091><determine.bestimmen><de> Verfügbarkeit Verfügbarkeit Bestimmen Sie, wann Sie eingeplant werden und entdecken Sie unsere erweiterten Verfügbarkeitsoptionen.
<G-vec00127-002-s092><determine.bestimmen><en> But what to do, wait another week before the delay (if it, of course, comes) - a long time, then determine the methods of "fortune telling".
<G-vec00127-002-s092><determine.bestimmen><de> Aber was zu tun ist, warten Sie eine weitere Woche vor der Verzögerung (wenn es natürlich kommt) - eine lange Zeit, dann bestimmen Sie die Methoden der "Wahrsagerei".
<G-vec00127-002-s093><determine.bestimmen><en> Determine power dissipation requirements.
<G-vec00127-002-s093><determine.bestimmen><de> Bestimmen Sie Verlustleistungsanforderungen.
<G-vec00127-002-s094><determine.bestimmen><en> Now determine which areas you want to make visible in the timetable.
<G-vec00127-002-s094><determine.bestimmen><de> Bestimmen Sie nun, welche Bereiche Sie im Timetable sichtbar machen wollen.
<G-vec00127-002-s095><determine.bestimmen><en> BYOK GmbH shall determine the type of packaging.
<G-vec00127-002-s095><determine.bestimmen><de> Die Art der Verpackung bestimmt die BYOK GmbH.
<G-vec00127-002-s096><determine.bestimmen><en> As a worldwide specialist in agar agar, Norevo has a thorough knowledge of the product, its geographical growing areas and its gelling properties that determine the application possibilities of agar agar in food and non-food sectors.
<G-vec00127-002-s096><determine.bestimmen><de> Norevo ist ein weltweit bekannter Agar Agar-Spezialist mit umfangreichem Wissen über das Produkt, die geografischen Ernteregionen und die Geliereigenschaften des Algenhydrokolloides, die die Anwendungsmöglichkeiten von Agar Agar im Lebensmittel- und Non-Food-Bereich bestimmt.
<G-vec00127-002-s097><determine.bestimmen><en> An equivalence test uses sample data to determine whether to reject the null hypothesis.
<G-vec00127-002-s097><determine.bestimmen><de> In einem Äquivalenztest wird anhand von Stichprobendaten bestimmt, ob die Nullhypothese zurückgewiesen werden muss.
<G-vec00127-002-s098><determine.bestimmen><en> The Tetra Aquatics app can be used to determine the water values quickly and reliably using a smartphone.
<G-vec00127-002-s098><determine.bestimmen><de> Mithilfe der Tetra Aquatics App können die Wasserwerte auch schnell und sicher per Smartphone bestimmt werden.
<G-vec00127-002-s099><determine.bestimmen><en> The number of gold symbols will determine which type of Jackpot you will win.
<G-vec00127-002-s099><determine.bestimmen><de> Die Anzahl der goldenen Symbole bestimmt, welche Art von Jackpot Sie gewinnen werden.
<G-vec00127-002-s100><determine.bestimmen><en> Characteristic of a grape in particular, determine many aspects of the wine that we elaborate.
<G-vec00127-002-s100><determine.bestimmen><de> Die Charakteristik einer Traube im Besonderen bestimmt viele Aspekte des Weins, den wir ausarbeiten.
<G-vec00127-002-s101><determine.bestimmen><en> The metal, with which the gold is mixed, comes to determine its colour.
<G-vec00127-002-s101><determine.bestimmen><de> Das Metall mit dem das Gold vermischt wird, bestimmt die Farbe.
<G-vec00127-002-s102><determine.bestimmen><en> However, you can select the labeling scheme to determine the name of the test results beforehand in a label list (list based testing).
<G-vec00127-002-s102><determine.bestimmen><de> Die Benennung der Testergebnisse kann jedoch schon vorher durch eine Label-Liste (Listenbasiertes Testen) bestimmt werden.
<G-vec00127-002-s103><determine.bestimmen><en> Assembly Load Trace: The following information can be helpful to determine why the assembly 'DOPC' could not be loaded.
<G-vec00127-002-s103><determine.bestimmen><de> Überwachung beim Laden der Assembly: Mit folgenden Informationen kann bestimmt werden, warum die Assembly Telerik.Web.UI nicht geladen werden konnte.
<G-vec00127-002-s104><determine.bestimmen><en> A blood sample is taken and analyzed to determine the total number of white blood cells and the percentages of each main type of white blood cell.
<G-vec00127-002-s104><determine.bestimmen><de> Hierzu wird eine Blutprobe entnommen und die Gesamtzahl der weißen Blutkörperchen sowie der prozentuale Anteil der wichtigsten weißen Blutkörperchenarten bestimmt.
<G-vec00127-002-s105><determine.bestimmen><en> SW3 determine how the data contained in the programmable controller I/O image table is used in the drive.
<G-vec00127-002-s105><determine.bestimmen><de> SW3 bestimmt, wie die in der E / A-Bildtabelle der programmierbaren Steuerung enthaltenen Daten im Antrieb verwendet werden.
<G-vec00127-002-s106><determine.bestimmen><en> A doctor will determine which type of patch to use.
<G-vec00127-002-s106><determine.bestimmen><de> Welche Art der Pflaster für Sie am angemessensten ist, wird vom Arzt bestimmt.
<G-vec00127-002-s107><determine.bestimmen><en> To determine the current key, SongBook will look at the {key:...} directive or (if not found) use the first chord of the song.
<G-vec00127-002-s107><determine.bestimmen><de> SongBook bestimmt die aktuelle Tonart aus der {key:...} Direktive oder (falls nicht vorhanden) aus dem ersten Akkord des Songs.
<G-vec00127-002-s108><determine.bestimmen><en> c Voxel is a geometric term that contributes to but does not determine resolution, and is provided here only for comparison.
<G-vec00127-002-s108><determine.bestimmen><de> c Voxel ist ein Begriff aus der Geometrie, der zur Auflösung beiträgt, diese aber nicht bestimmt, und wird hier nur als Vergleich angegeben.
<G-vec00127-002-s109><determine.bestimmen><en> Working closely with the development team and using extensive metrics based on player activity, they are able to determine what is normal player activity, what is unusual and what is exploiting.
<G-vec00127-002-s109><determine.bestimmen><de> Durch ihre enge Zusammenarbeit mit dem Entwicklungsteam und der Nutzung von umfangreichen Metriken des Spielerverhaltens könnte bestimmt werden, was normales Spielerverhalten, was ungewöhnlich und was ein Exploit sei.
<G-vec00127-002-s110><determine.bestimmen><en> Professionally with the customer will jointly determine the scope of the work and then prepared according to well-planned and executed and then quickly and accurately to be.
<G-vec00127-002-s110><determine.bestimmen><de> Fachkundig wird mit dem Kunden gemeinsam der Umfang der Arbeiten bestimmt und dann entsprechend gut vorbereitet und geplant um dann schnell und zielsicher ausgeführt zu werden.
<G-vec00127-002-s111><determine.bestimmen><en> Depending on the methods you specify creating and maintaining the System Tree, the server uses different characteristics to determine where to place systems.
<G-vec00127-002-s111><determine.bestimmen><de> Abhängig von den Methoden, mit denen die Systemstruktur erstellt und verwaltet wird, bestimmt der Server anhand unterschiedlicher Eigenschaften, wo Systeme eingeordnet werden sollen.
<G-vec00127-002-s112><determine.bestimmen><en> Determine whether the product is in fact defective or otherwise damaged.
<G-vec00127-002-s112><determine.bestimmen><de> Es wird bestimmt, ob das Produkt tatsächlich defekt oder anderweitig beschädigt ist.
<G-vec00127-002-s113><determine.bestimmen><en> The object of this experiment is to determine the velocity of sound in aluminum, copper, brass and steel rods.
<G-vec00127-002-s113><determine.bestimmen><de> Versuchsbeschreibung Es werden die Schallgeschwindigkeiten in Aluminium-, Kupfer-, Messing- und Stahlstäben bestimmt.
<G-vec00127-002-s266><determine.festlegen><en> It shall also, by the same majority, determine any payment to be made instead of remuneration.
<G-vec00127-002-s266><determine.festlegen><de> Er setzt mit derselben Mehrheit alle sonstigen als Entgelt gezahlten Vergütungen fest.
<G-vec00127-002-s267><determine.festlegen><en> Article 39 The Security Council shall determine the existence of any threat to the peace, breach of the peace, or act of aggression and shall make recommendations, or decide what measures shall be taken in accordance with Articles 41 and 42, to maintain or restore international peace and security.
<G-vec00127-002-s267><determine.festlegen><de> Artikel 39 (Maßnahmen zur Wahrung des Weltfriedens) Der Sicherheitsrat stellt fest, ob eine Bedrohung oder ein Bruch des Friedens oder eine Angriffshandlung vorliegt; er gibt Empfehlungen ab oder beschließt, welche Maßnahmen auf Grund der Artikel 41 und 42 zu treffen sind, um den Weltfrieden und die internationale Sicherheit zu wahren oder wiederherzustellen.
<G-vec00127-002-s268><determine.festlegen><en> First, apply light pressure to determine the exact location of Tara's pain.
<G-vec00127-002-s268><determine.festlegen><de> Stelle zunächst durch leichte Druckausübung die genaue Position von Taras Schmerzen fest.
<G-vec00127-002-s269><determine.festlegen><en> Vealeidja’s solution for this is professional project management services: we will determine the customer’s needs and goals and administer the entire building process, from design consultation, selection of contractors and preparation of documentation to obtaining the permit for use. The whole process is based on constant collaboration with the customer in order to guarantee the best
<G-vec00127-002-s269><determine.festlegen><de> Die Firma Vealeidja bietet als Lösung die Dienstleistung der professionellen Projektleitung: wir stellen die Bedürfnisse und Ziele des Auftraggebers fest, wir nehmen die Verwaltung des gesamten Bauablaufs in die Hand – von der Beratung zur Projektierung, der Auswahl der Bauunternehmer, der Zusammenstellung der Dokumentation bis hin zum Erwerb der Nutzungsgenehmigung.
<G-vec00127-002-s270><determine.festlegen><en> 5. On request, the Office or Board of Appeal shall determine the amount of the costs to be paid pursuant to the preceding paragraphs.
<G-vec00127-002-s270><determine.festlegen><de> In allen anderen Fällen setzt die Geschäftsstelle der Beschwerdekammer oder ein Mitarbeiter der Widerspruchsabteilung oder der Nichtigkeitsabteilung auf Antrag den zu erstattenden Betrag fest.
<G-vec00127-002-s271><determine.festlegen><en> Using the snap knob, you can not only determine the character of the attack phase, but also add noise to the signal.
<G-vec00127-002-s271><determine.festlegen><de> Der Snap-Regler legt nicht nur den Charakter des Anschlags fest, sondern fügt dem Signal auch Rauschen hinzu und imitiert so einen Snare-Teppich.
<G-vec00127-002-s272><determine.festlegen><en> You simply determine how many voices (sound tracks) your song will have, and then you choose the preset samples or create your own ones to your liking.
<G-vec00127-002-s272><determine.festlegen><de> Sie legen einfach fest, wie viele Stimmen (Tonspuren) Ihr Song haben wird, und dann wählen Sie die voreingestellten Muster oder erstellen Ihre eigenen ganz nach Ihren Wünschen.
<G-vec00127-002-s273><determine.festlegen><en> Based on the measures catalogue, the company management and the EnAW consultant determine how much energy and CO2 the establishment should save.
<G-vec00127-002-s273><determine.festlegen><de> Auf Basis des Massnahmenkatalogs legen Unternehmensleitung und EnAW-Berater fest, wie viel Energie und CO2 der Betrieb reduzieren soll.
<G-vec00127-002-s274><determine.festlegen><en> Under Mojikumi Compatibility Modes, determine whether you want to select Use New Vertical Scaling or Use CID-Based Mojikumi.
<G-vec00127-002-s274><determine.festlegen><de> Legen Sie unter Mojikumi-Kompatibilitätsmodi fest, ob Sie „Neue vertikale Skalierung verwenden“ oder „CID-basiertes Mojikumi“ auswählen möchten.
<G-vec00127-002-s275><determine.festlegen><en> In the occurrence, the ADAC GT Commission in consultation with the DMSB shall determine the vehicle's classification.
<G-vec00127-002-s275><determine.festlegen><de> In diesen Fällen legt das ADAC GT Komitee in Abstimmung mit dem DMSB die Einstufung der betreffenden Fahrzeuge fest.
<G-vec00127-002-s276><determine.festlegen><en> Select your Deletion rule to determine what happens to snapshots if the schedule's source disk is deleted.
<G-vec00127-002-s276><determine.festlegen><de> Legen Sie im Feld Löschregel fest, was mit den Snapshots geschieht, wenn das Quelllaufwerk gelöscht wird.
<G-vec00127-002-s277><determine.festlegen><en> I don’t want to strain to determine your curiosity. Thats why you’ll find here few pictures and sketches of the designs of my rewards.
<G-vec00127-002-s277><determine.festlegen><de> Damit deine Neugierde nicht zu fest strapaziert wird, findest du hier ein paar Abbildungen und Fotos der Entwürfe meiner Geschenke.
<G-vec00127-002-s278><determine.festlegen><en> Gabriele Frey does not want to entirely determine the interpretation of her paintings.
<G-vec00127-002-s278><determine.festlegen><de> Gabriele Frey legt sich nicht auf die Interpretation ihrer Werke fest.
<G-vec00127-002-s279><determine.festlegen><en> Determine if you have security software already installed on your computer.
<G-vec00127-002-s279><determine.festlegen><de> Stellen Sie fest, ob auf Ihrem Computer Sicherheitssoftware bereits installiert ist.
<G-vec00127-002-s280><determine.festlegen><en> Make rules and determine limits.
<G-vec00127-002-s280><determine.festlegen><de> Stellen Sie Regeln auf und setzen Sie Grenzen fest.
<G-vec00127-002-s281><determine.festlegen><en> They shall determine in advance the appropriate arrangements for this as well as for the representation of the respective positions at meetings of the bodies created by the Convention.
<G-vec00127-002-s281><determine.festlegen><de> Sie legen die dafür angemessenen Modalitäten und die Regeln für die Vertretung der jeweiligen Standpunkte bei den Zusammenkünften der im Rahmen des Übereinkommens eingerichteten Gremien im Voraus fest.
<G-vec00127-002-s282><determine.festlegen><en> The design briefs are a source of reference and basis for design, architects and to determine further specifications.
<G-vec00127-002-s282><determine.festlegen><de> Diese Designbriefs sind Quellenangaben und Basis für Designer und Architekten und dienen um spätere Spezifizierungen fest zu setzen.
<G-vec00127-002-s283><determine.festlegen><en> The Federal Council shall determine the date on which this Act comes into force.
<G-vec00127-002-s283><determine.festlegen><de> Der Bundesrat setzt den Beginn der Wirksamkeit dieses Gesetzes fest.
<G-vec00127-002-s284><determine.festlegen><en> Should the arbitrator determine that CSB has not entirely fulfilled its contractual obligations and that these are due, he shall determine a suitable period in which CSB shall have the opportunity to perform the deliveries and services that have been ascertained by the arbitrator as unfulfilled.
<G-vec00127-002-s284><determine.festlegen><de> Stellt der Schiedsgutachter fest, dass CSB ihre vertraglichen Pflichten noch nicht vollständig erfüllt hat und sind diese fällig, so bestimmt er eine angemessene Frist, in der CSB die Gelegenheit hat, die von dem Schiedsgutachter als noch nicht erbracht festgestellten Lieferungen und Leistungen zu erbringen.
<G-vec00127-002-s323><determine.festlegen><en> (w) offers for sale or selling any item, good or service that violates any applicable law or regulation or that we determine, in our sole discretion, is inappropriate for transmission through the Service.
<G-vec00127-002-s323><determine.festlegen><de> (w) Gegenstände, Waren oder Dienstleistungen zum Verkauf anbietet, deren Veräußerung gegen ein geltendes Gesetz verstößt oder für den oder die wir in unserem alleinigen Ermessen festlegen, dass dieser oder diese für eine Veräußerung durch den Dienst nicht geeignet ist.
<G-vec00127-002-s324><determine.festlegen><en> Reward: Corporations as principals of ideas challenges can determine a reward which is paid by the commissioning corporation after the end of the ideas challenge. The reward is paid to the user(s) if at least one idea project (referred to as "idea" below) has been submitted which meets the expectations of the commissioning corporation.
<G-vec00127-002-s324><determine.festlegen><de> Belohnung: Unternehmen als Auftraggeber von Ideenwettbewerben können eine Belohnung festlegen, die nach Ablauf des Ideenwettbewerbs durch das auftraggebende Unternehmen an den/die Benutzer ausbezahlt wird, sofern mindestens ein Ideenprojekt (im Folgenden kurz "Idee" genannt) eingereicht wurde, das den Erwartungen des auftraggebenden Unternehmens entspricht.
<G-vec00127-002-s325><determine.festlegen><en> The momentum of a movement collapses if there is no organization to plan and determine what the next steps will be, and in what order problems should be addressed.
<G-vec00127-002-s325><determine.festlegen><de> Der Schwung einer Bewegung fällt in sich zusammen, wenn es keine Organisation gibt, die die nächsten Schritte planen und festlegen kann, in welcher Reihenfolge welche Probleme angegangen werden sollen.
<G-vec00127-002-s326><determine.festlegen><en> Users can now determine whether the Okta dashboard is opened in their selected browser after sign-in by selecting the checkbox next to the Browser pop-up menu.
<G-vec00127-002-s326><determine.festlegen><de> Benutzer können jetzt festlegen, ob nach dem Anmelden das Okta Dashboard in ihrem ausgewählten Browser geöffnet werden soll, indem sie das Markierungsfeld neben dem Einblendmenü Browser markieren.
<G-vec00127-002-s327><determine.festlegen><en> The research is primarily to determine whether the speed of use energy has a significant impact on the formation of cancerous changes.
<G-vec00127-002-s327><determine.festlegen><de> Die eingeleiteten Untersuchungen sollen vor allem festlegen, ob das Tempo, mit dem wir Energie verbrauchen, wesentlichen Einfluss auf die Entstehung von neoplastischen Veränderungen hat.
<G-vec00127-002-s328><determine.festlegen><en> If your company is not the subsidiary of an international group operating according to IFRS requirements, then the IFRS transition will only mean that instead of the Hungarian Accounting Act, IFRS requirements will now determine how economic events should be booked.
<G-vec00127-002-s328><determine.festlegen><de> Falls das ungarische Unternehmen keine Tochtergesellschaft eines nach IFRS bilanzierenden internationalen Konzerns ist, bedeutet die Umstellung auf IFRS lediglich, dass anstelle des ungarischen Rechnungslegungsgesetzes nun die IFRS-Richtlinien festlegen, wie die wirtschaftlichen Vorgänge verbucht werden.
<G-vec00127-002-s329><determine.festlegen><en> In your initial consultation, our surgeon will evaluate your health, determine the extent of fat deposits in your abdominal region, and carefully assess your skin tone.
<G-vec00127-002-s329><determine.festlegen><de> Vor dem Eingriff Während des Vorgesprächs wird der Chirurg Ihren Gesundheitszustand und die Hautelastizität beurteilen und die Menge des zu entfernenden Fettgewebes festlegen.
<G-vec00127-002-s330><determine.festlegen><en> If the talks do not lead to a single unified approach soon, the Government would instead look to establish a consensus on a small number of clear options on the future relationship that could be put to the House in a series of votes to determine which course to pursue.
<G-vec00127-002-s330><determine.festlegen><de> Wenn die Gespräche nicht bald zu einem einzigen einheitlichen Ansatz führen, würde die Regierung stattdessen versuchen, einen Konsens über eine kleine Anzahl klarer Optionen für die zukünftigen Beziehungen zu finden, die dem Unterhaus in einer Reihe von Abstimmungen vorgelegt werden könnten, um einen Kurs festlegen zu können.
<G-vec00127-002-s331><determine.festlegen><en> On the Settings of the app, the user can determine how often Yepzon connects to the server, in other words with which delay the tracking can be started.
<G-vec00127-002-s331><determine.festlegen><de> Der Nutzer kann in der App unter Einstellungen selbst festlegen, wie oft Yepzon sich mit dem Server verbindet, also mit welcher Verzögerung die genaue Ortung begonnen werden kann.
<G-vec00127-002-s332><determine.festlegen><en> By testing a number of different color temperatures, we were able to determine the best night time environment for the residents of the area.
<G-vec00127-002-s332><determine.festlegen><de> Wir haben eine Vielzahl von unterschiedlichen Farbtemperaturen geprüft und konnten so die beste Ausleuchtung der Umgebung bei Nacht festlegen.
<G-vec00127-002-s333><determine.festlegen><en> This option enables you to determine that the packaging is to take place not immediately after the task assignment, but only when the offline translator retrieves the crossWAN packages.
<G-vec00127-002-s333><determine.festlegen><de> Über diese Option können Sie festlegen, dass die Paketerstellung nicht unmittelbar nach der Aufgabenzuweisung erfolgt, sondern erst bei der Abholung der crossWAN-Pakete durch den Offline-Übersetzer.
<G-vec00127-002-s334><determine.festlegen><en> The organization shall determine criteria to evaluate its environmental performance, using appropriate indicators;
<G-vec00127-002-s334><determine.festlegen><de> Die Organisation muss Kriterien für die Beurteilung ihrer Umweltleistung anhand passender Indikatoren festlegen.
<G-vec00127-002-s335><determine.festlegen><en> Additionally, you can determine whether and which character entities are to be converted automatically.
<G-vec00127-002-s335><determine.festlegen><de> Zudem können Sie festlegen, ob und wenn ja welche Zeichen-Entitäten automatisch konvertiert werden sollen.
<G-vec00127-002-s336><determine.festlegen><en> Plan of product realization determine the following: a. quality objectives and requirements for the product per the Inspection Procedure, b. the need to establish processes, documents, and provide resources specific to the product, c. required verification, validation, monitoring, inspection and test activities specific to the product and criteria for product acceptance pr the Validation Procedure and the Inspection Procedure, and d. records needed to provide evidence that the realization processes and resulting product fulfill requirements per Records Procedure.
<G-vec00127-002-s336><determine.festlegen><de> 25 22 Bei der Planung der Produktrealisierung muss die Organisation, soweit angemessen, Folgendes festlegen: a) Qualitätsziele und Anforderungen an das Produkt; b) die Notwendigkeit, Prozesse einzuführen, Dokumente zu erstellen und die produktspezifischen Ressourcen bereitzustellen; c) die erforderlichen produktspezifischen Verifizierungs-, Validierungs-, Überwachungs-, Mess- und Prüftätigkeiten sowie die Produktannahmekriterien; d) die erforderlichen Aufzeichnungen, um nachzuweisen, dass die Realisierungsprozesse und resultierenden Produkte die Anforderungen erfüllen (siehe 4.2.4).
<G-vec00127-002-s337><determine.festlegen><en> During import, you can determine which styles are loaded and what should occur if a loaded style has the same name as a style in the current document.
<G-vec00127-002-s337><determine.festlegen><de> Beim Importieren können Sie festlegen, welche Formate geladen werden und wie das Programm vorgehen soll, wenn ein geladenes Format den gleichen Namen wie ein bereits vorhandenes Format im aktuellen Dokument hat.
<G-vec00127-002-s338><determine.festlegen><en> By way of derogation from this rule, Member States may authorise the use of certain products, the characteristics of which they shall determine, by distilleries or vinegar factories or for industrial purposes, provided that this authorisation does not become an incentive to produce by means of unauthorised oenological practices.
<G-vec00127-002-s338><determine.festlegen><de> Abweichend von dieser Vorschrift dürfen die Mitgliedstaaten jedoch zulassen, dass bestimmte derartige Erzeugnisse, deren Merkmale sie festlegen, in einer Brennerei, einer Essigfabrik oder zu industriellen Zwecken verwendet werden, sofern diese Genehmigung sich nicht zu einem Anreiz entwickelt, Weinbauerzeugnisse unter Nutzung nicht zugelassener önologischer Verfahren zu produzieren.
<G-vec00127-002-s339><determine.festlegen><en> You can also use the alpha level to determine your personal risk tolerance.
<G-vec00127-002-s339><determine.festlegen><de> Über das Alpha-Niveau können Sie zudem Ihre persönliche Risikobereitschaft festlegen.
<G-vec00127-002-s340><determine.festlegen><en> Or Switzerland could determine the number of its residents should, by 2025, not exceed a given level.
<G-vec00127-002-s340><determine.festlegen><de> Alternativ könnte die Schweiz festlegen, dass die ständige Wohnbevölkerung bis 2025 nicht über eine bestimmte Schwelle wachsen soll.
<G-vec00127-002-s341><determine.festlegen><en> In the Accept Cookies section, you can determine if and when Safari should save the cookies of websites.
<G-vec00127-002-s341><determine.festlegen><de> Im Bereich „Cookies akzeptieren“ können Sie festlegen, ob und wann Safari die Cookies der Websites speichern soll.
<G-vec00127-002-s399><determine.festlegen><en> Task Duration: Thinking about how long you will be screwing for is a good way to determine the best cordless screwdriver for the job.
<G-vec00127-002-s399><determine.festlegen><de> Nutzungsdauer: Darüber nachzudenken, wie lange Sie schrauben müssen, ist ein guter Weg, um den besten Akkuschrauber für eine Aufgabe festzulegen.
<G-vec00127-002-s400><determine.festlegen><en> Again, bringing together the right mix of expertise, including the Lead Teacher, course faculty, staff of the Smart Hospital to work alongside the SRT team, insights into the process of curriculum integration are being gained and will determine future direction and scope for other courses.
<G-vec00127-002-s400><determine.festlegen><de> Auch hier ist es wieder das Ziel, durch eine richtige Mischung aus Experten-Know-how unter Einbeziehung des leitenden Dozenten, der Kursfakultät und des Personals des Smart Hospitals, das mit dem SRT-Team zusammenarbeiten soll, Einblicke in den Prozess der Lehrplanintegration zu gewinnen, um so die künftige Richtung und den Umfang für weitere Kurse festzulegen.
<G-vec00127-002-s401><determine.festlegen><en> This was accompanied by nominalism, a fascination with the mind and its ability to determine what things mean—to change unpredictable nature into a controllable tool.
<G-vec00127-002-s401><determine.festlegen><de> Das ging einher mit dem Nominalismus, einer Philosophie, die fasziniert war vom Verstand und dessen Fähigkeit, festzulegen, was etwas bedeutet – die unberechenbare Natur in ein kontrollierbares Werkzeug zu verwandeln.
<G-vec00127-002-s402><determine.festlegen><en> We have a board that has an annual meeting in March each year to determine, among other things, fishing license prices.
<G-vec00127-002-s402><determine.festlegen><de> Wir haben ein Gremium, das jedes Jahr im März eine jährliche Sitzung abhält, um unter anderem die Preise für Angelscheine festzulegen.
<G-vec00127-002-s403><determine.festlegen><en> After consulting with the parties and the mediator, the Center shall determine the final amount to be paid to the mediator, taking into consideration the hourly or daily rates and other factors such as the complexity of the subject matter of the dispute and of the mediation, the total time spent by the mediator, the diligence of the mediator and the rapidity of the mediation proceedings.
<G-vec00127-002-s403><determine.festlegen><de> Nach Beratung mit den Parteien und dem Dringlichkeitsschiedsrichter hat das Zentrum den an den Dringlichkeitsschiedsrichter zu zahlenden endgültigen Betrag festzulegen, wobei die Stundenund Höchstsätze sowie andere Umstände wie der Schwierigkeitsgrad der Streitsache und des Verfahrens auf dringlichen Rechtsschutz, die gesamte vom Dringlichkeitsschiedsrichter aufgewendete Zeit, die Sorgfalt des Dringlichkeitsschiedsrichters und die Schnelligkeit des Verfahrens auf dringlichen Rechtsschutz zu berücksichtigen sind.
<G-vec00127-002-s404><determine.festlegen><en> Before you say I do, be sure to make a consultation appointment to determine your wedding day hairstyle, veil placement, and make-up.
<G-vec00127-002-s404><determine.festlegen><de> Vereinbaren Sie unbedingt einen Beratungstermin, um die Frisur, die Platzierung des Schleiers und das Make-up für Ihren Hochzeitstag festzulegen.
<G-vec00127-002-s405><determine.festlegen><en> The Foundation has, in fact, been named the organisation of reference in the South, to determine priorities for the Interim Health Plan in the matter of nutrition.
<G-vec00127-002-s405><determine.festlegen><de> Die Stiftung wurde nämlich zur Referenzorganisation im Süden ernannt, um die Prioritäten im interimistischen Gesundheitsplan zur Ernährung festzulegen.
<G-vec00127-002-s406><determine.festlegen><en> The aim is to determine the operating hours so that the customer’s heating requirement is met and electricity is produced when a high price can be generated in the market.
<G-vec00127-002-s406><determine.festlegen><de> Ziel ist es, die Betriebsstunden so festzulegen, dass der Wärmebedarf des Kunden gedeckt ist und Strom erzeugt wird, wenn ein hoher Preis am Markt erzielt werden kann.
<G-vec00127-002-s407><determine.festlegen><en> Fibonacci expansions can help traders determine potential profit while retracements show where to place a stop.
<G-vec00127-002-s407><determine.festlegen><de> Die Fibonacci-Expansionen können Tradern helfen, potentielle Profite festzulegen, während die Retracements aufzeigen, wo ein Stop zu platzieren ist.
<G-vec00127-002-s408><determine.festlegen><en> Review these suggested stopping rules to help you determine a test duration.
<G-vec00127-002-s408><determine.festlegen><de> Diese Empfehlungen zum Beenden helfen Ihnen dabei, eine Testdauer festzulegen.
<G-vec00127-002-s409><determine.festlegen><en> For each article, you can specify settings in article properties to determine what happens when recipients view the shared article.
<G-vec00127-002-s409><determine.festlegen><de> Sie können für jeden Artikel Einstellungen in den Artikeleigenschaften angeben, um die Aktion festzulegen, die ausgeführt wird, wenn die Empfänger den geteilten Artikel anzeigen.
<G-vec00127-002-s410><determine.festlegen><en> Design an analytics blueprint to determine which parts of the business and operations need to factor into various decisions.
<G-vec00127-002-s410><determine.festlegen><de> Entwickeln Sie eine Analytik-Vorlage, um festzulegen, welche Teile des Unternehmens und der Prozesse in die unterschiedlichen Entscheidungen einbezogen werden müssen.
<G-vec00127-002-s411><determine.festlegen><en> The Committee will proceed to review, in early 2005, Italian housing policies as they relate to Roma, to determine whether they comply with Italy's obligations under the Revised European Social Charter.
<G-vec00127-002-s411><determine.festlegen><de> Anfang 2005 wird das Komitee die italienische Wohnpolitik in Bezug auf Roma prüfen, um festzulegen, ob Italiens Politik seiner Verpflichtungen mit der Europäischen Sozialcharta (revidiert) nachgeht.
<G-vec00127-002-s412><determine.festlegen><en> In addition, the App offers the possibility for Trackimo determine which activities he is supposed to send a message.
<G-vec00127-002-s412><determine.festlegen><de> Zudem bietet die App die Möglichkeit für Trackimo festzulegen, bei welchen Aktivitäten er eine Nachricht schicken soll.
<G-vec00127-002-s413><determine.festlegen><en> Thus, the shift of tax power to the municipalities, which should be a basic demand of a new democratic movement, would allow community assemblies to determine the amount of taxes as well as the way in which taxes would be charged on income, wealth, land and energy use, as well as consumption.
<G-vec00127-002-s413><determine.festlegen><de> So würde der Übergang des Besteuerungsrechts auf die Kommunen, der eine grundlegende Forderung demokratischer Bewegungen sein sollte, es den Gemeindeversammlungen erlauben, die Höhe der Steuern und die Art ihrer Erhebung auf Einkommen, Vermögen, Land- und Energieverbrauch sowie Konsum festzulegen.
<G-vec00127-002-s414><determine.festlegen><en> The SQL Anywhere optimizer uses column statistics to determine the best strategy for executing each statement.
<G-vec00127-002-s414><determine.festlegen><de> Der Optimierer in SQL Anywhere verwendet Spaltenstatistiken, um die beste Strategie für das Ausführen der einzelnen Anweisungen festzulegen.
<G-vec00127-002-s415><determine.festlegen><en> 3. This Directive shall not interfere with Member States’ competence to design and determine, within their marine waters, the extent and coverage of their maritime spatial plans.
<G-vec00127-002-s415><determine.festlegen><de> (3) Diese Richtlinie berührt nicht die Zuständigkeit der Mitgliedstaaten, innerhalb der Meeresgewässer den Umfang und die Reichweite ihrer maritimen Raumordnungspläne zu konzipieren und festzulegen.
<G-vec00127-002-s416><determine.festlegen><en> Add all the various time factors up to determine approximately how long the job will take you, and multiply that times your hourly rate.
<G-vec00127-002-s416><determine.festlegen><de> Beziehe all die verschiedenen Zeitfaktoren mit ein, um festzulegen, wie lang ein Job dauern wird, und multipliziere diese Zeit mit deinem Stundengehalt.
<G-vec00127-002-s417><determine.festlegen><en> In some cases a name declaration is required for children, in order to determine or change the birth name of the child before applying for a passport.
<G-vec00127-002-s417><determine.festlegen><de> In manchen Fällen ist vor der Beantragung eine Namenserklärung für Kinder erforderlich, um den Geburtsnamen des Kindes festzulegen oder zu ändern.
<G-vec00127-002-s532><determine.festlegen><en> The measuring units determine which measurements can be carried out.
<G-vec00127-002-s532><determine.festlegen><de> Die Messeinheiten legen fest, welche Messungen ausgeführt werden können.
<G-vec00127-002-s533><determine.festlegen><en> In coordination with our customers and the workpieces to be machined, we determine the size of the machine and determine the design as a machine with a moving table or as a moving column machine (gantry).
<G-vec00127-002-s533><determine.festlegen><de> In Abstimmung mit unseren Kunden und den zu bearbeitenden Werkstücken legen wir die Größe der Maschine fest und bestimmen die Ausführung als Maschine mit verfahrendem Tisch oder als Fahrständermaschine (Gantry).
<G-vec00127-002-s534><determine.festlegen><en> The productivity of your system matters – To enhance productivity, we work closely in a partnership with our customers to determine together which practical programs of machine and system maintenance are required and reasonable.
<G-vec00127-002-s534><determine.festlegen><de> Auf die Produktivität Ihrer Anlage kommt es an – Um die Produktivität sicherzustellen, arbeiten wir eng und partnerschaftlich mit unseren Kunden zusammen und legen gemeinsam fest, welche Wartungskonzepte für Geräte und Anlage erforderlich und sinnvoll sind.
<G-vec00127-002-s535><determine.festlegen><en> Like any business, key decisions like these are fundamental to your strategy and often determine how much you risk, what reward is available and how quickly and stably you will build your investment.
<G-vec00127-002-s535><determine.festlegen><de> Wie bei jeder Art von Business sind Schlüsselentscheidungen wie diese fundamental für ihre Strategie und legen oft fest, wie viel Sie riskieren, was Sie rasukriegen und wie schnell und konstant Sie ihr Investment aufbauen können.
<G-vec00127-002-s536><determine.festlegen><en> You determine yourself what is secured with the Ekey Multi.
<G-vec00127-002-s536><determine.festlegen><de> Sie legen selbst fest, was mit dem Ekey Multi gesichert wird.
<G-vec00127-002-s537><determine.festlegen><en> You determine who is working on which task and by when and what steps are to be taken.
<G-vec00127-002-s537><determine.festlegen><de> Sie legen fest, wer an welcher Aufgabe arbeitet und bis wann welche Schritte erreicht werden sollen.
<G-vec00127-002-s538><determine.festlegen><en> Where national regulatory authorities determine exemptions in this manner, they shall notify the Commission forthwith.
<G-vec00127-002-s538><determine.festlegen><de> Legen die nationalen Regulierungsbehörden solche Ausnahmen fest, teilen sie dies der Kommission unverzüglich mit.
<G-vec00127-002-s539><determine.festlegen><en> In BIC Governance you can determine precisely how many and which individuals are allowed to examine or do a release.
<G-vec00127-002-s539><determine.festlegen><de> In BIC Governance legen Sie genau fest, wie viele und welche Personen Prozesse prüfen oder freigeben dürfen.
<G-vec00127-002-s540><determine.festlegen><en> Tasters determine which forms show the most popular spirits and fortified wines to their greatest advantage on the nose and palate, without losing the carefully crafted nuances of distillation to the dominance of alcohol.
<G-vec00127-002-s540><determine.festlegen><de> Die Verkoster legen fest, welche Silhouette den beliebtesten Spirituosen und versetzten Weinen zum besten Vorteil für Nase und Gaumen gereicht, ohne die fein destillierten Nuancen an den Alkohol zu verlieren.
<G-vec00127-002-s541><determine.festlegen><en> There are two more variables to set in the svnserve.conf file: they determine what unauthenticated (anonymous) and authenticated users are allowed to do.
<G-vec00127-002-s541><determine.festlegen><de> Es sind noch zwei weitere Variablen in der Datei svnserve.conf zu setzten: Sie legen fest, was nicht authentifizierten (anonymen) und authentifizierten Nutzern erlaubt ist.
<G-vec00127-002-s542><determine.festlegen><en> Regional building regulations determine requirements for air ducts, air pipes and fire traps.
<G-vec00127-002-s542><determine.festlegen><de> Die Landesbauordnungen legen die Anforderungen an Schächte, Luftleitungen und Brandschutzklappen fest.
<G-vec00127-002-s543><determine.festlegen><en> You determine which style suits your home best and you indicate how large the glass portion of your future door should be.
<G-vec00127-002-s543><determine.festlegen><de> Sie legen fest, welcher Stil am besten zu Ihrem Haus passt und geben an, wie groß der Glasanteil Ihrer zukünftigen Tür sein darf.
<G-vec00127-002-s544><determine.festlegen><en> Determine the users you want to be able to sign in to the site.
<G-vec00127-002-s544><determine.festlegen><de> Legen Sie die Benutzer fest, die sich bei der Site anmelden können sollen.
<G-vec00127-002-s545><determine.festlegen><en> Here, you determine that the feed will be displayed on the personal page of a specified user, and in the News.
<G-vec00127-002-s545><determine.festlegen><de> Hier legen Sie fest, dass der Beitrag auf der persönlichen Seite eines definierten Benutzers und in den Neuigkeiten angezeigt wird.
<G-vec00127-002-s546><determine.festlegen><en> I/O modules determine the function of the module at the terminals.
<G-vec00127-002-s546><determine.festlegen><de> Peripheriemodule legen die Funktion des Moduls an den Klemmen fest.
<G-vec00127-002-s547><determine.festlegen><en> Before the drill we will determine what number they have to get to.
<G-vec00127-002-s547><determine.festlegen><de> Vor jedem Drill legen wir fest, welche Punktzahl sie erreichen müssen.
<G-vec00127-002-s548><determine.festlegen><en> Using this setting, you can determine where the message will go when you mark it as junk.
<G-vec00127-002-s548><determine.festlegen><de> Mit dieser Einstellung legen Sie fest, was mit der als Junk markierten Nachricht geschieht.
<G-vec00127-002-s549><determine.festlegen><en> Where a bidding zone consists of territories of more than one Member State, the concerned regulatory authorities or other designated competent authorities shall determine a single estimate of the value of lost load for that bidding zone.
<G-vec00127-002-s549><determine.festlegen><de> Umfasst eine Gebotszone Hoheitsgebiete mehr als eines Mitgliedstaats, so legen die betroffenen Regulierungsbehörden oder anderen benannten zuständigen Behörden für diese Gebotszone einen einzigen Wert der Zahlungsbereitschaft für die Beibehaltung der Stromversorgung fest.
<G-vec00127-002-s550><determine.festlegen><en> Results of the talks will be used to determine the length of the course required, the size of the group(s) and when lessons should take place.
<G-vec00127-002-s550><determine.festlegen><de> Basierend darauf legen wir gemeinsam den idealen Kursumfang, die Kurszeit und die Gruppengröße fest.
