<G-vec00595-002-s068><detach.(sich)_brechen><en> After having made the score it is necessary to detach the glass so that the oval or the round part remain intact.
<G-vec00595-002-s068><detach.(sich)_brechen><de> Nachdem wir den Einschnitt durchgeführt haben, muss das Glas gebrochen werden, damit Oval oder Kreis unversehrt bleiben.
<G-vec00595-002-s144><detach.(sich)_nehmen><en> To clean the blender blades, simple detach them from the blender jar and rinse.
<G-vec00595-002-s144><detach.(sich)_nehmen><de> Zum Reinigen nehmen Sie die Messereinheit einfach aus dem Mixbehälter und waschen sie unter fließendem Wasser ab.
<G-vec00595-002-s022><detach.abhängen><en> Once per turn: You can detach 1 Xyz Material from this card, then target 1 face-up monster your opponent controls; destroy it, unless your opponent pays 1000 Life Points to negate this effect.
<G-vec00595-002-s022><detach.abhängen><de> Einmal pro Spielzug: Du kannst ein Xyz-Material von dieser Karte abhängen und dann ein offenes Monster wählen, das dein Gegner kontrolliert; zerstöre es, es sei denn, dein Gegner zahlt 1000 Life Points, um diesen Effekt zu annullieren.
<G-vec00595-002-s093><detach.abkoppeln><en> Yet we detach ourselves from the environment by forcing our nights into days using electric light, and isolate ourselves in buildings that shield us from natural light.
<G-vec00595-002-s093><detach.abkoppeln><de> Dennoch koppeln wir uns von der Umwelt ab, indem wir mithilfe elektrischen Lichts die Nacht zum Tag machen und uns in Gebäuden verschanzen, die uns vom natürlichen Licht abschirmen.
<G-vec00595-002-s146><detach.ablösen><en> In the 1980s, for that reason the development of the first fieldbus generation was put into focus to detach the common parallel cabling.
<G-vec00595-002-s146><detach.ablösen><de> Deshalb wurde in den 80er Jahren die Entwicklung der ersten Feldbusgeneration in Angriff genommen, um die übliche Parallelverdrahtung abzulösen.
<G-vec00595-002-s143><detach.abmontieren><en> Before we send the clock we always detach both hands to avoid any damage in transport.
<G-vec00595-002-s143><detach.abmontieren><de> Bevor wir eine Uhr verschicken, montieren wir immer die beiden Zeiger ab, damit sie auf dem Transport keinen Schaden erleiden.
<G-vec00595-002-s083><detach.abnehmen><en> Detach the lid of the battery casing at the back of the meter and remove the old batteries.
<G-vec00595-002-s083><detach.abnehmen><de> Die Elektronikanzeige von der Halterung abnehmen und die Batterien an der Rückseite der Elektronikanzeige herausnehmen.
<G-vec00595-002-s147><detach.abreißen><en> The waters most probably detach these crystals from the neighbouring rocks, as at Frascati, near Rome.
<G-vec00595-002-s147><detach.abreißen><de> Wahrscheinlich reißt das Wasser diese Krystalle vom anstehenden Gestein ab, wie zu Frascati bei Rom.
<G-vec00595-002-s052><detach.absetzen><en> They’re designed to attach or detach in less than two seconds.
<G-vec00595-002-s052><detach.absetzen><de> Sie sind darauf ausgelegt, in weniger als zwei Sekunden auf- oder abgesetzt zu werden.
<G-vec00595-002-s089><detach.absondern><en> By clicking on the chart you can also detach each chart.
<G-vec00595-002-s089><detach.absondern><de> Indem Sie auf den Chart klicken, können sie ihn auch absondern.
<G-vec00595-002-s051><detach.abtrennen><en> You can detach (clear) a formula from a list name in several ways.
<G-vec00595-002-s051><detach.abtrennen><de> Sie können eine angehängte Formel von einer Liste auf mehrere Arten abtrennen.
<G-vec00595-002-s189><detach.abwerfen><en> 2 Level 3 monsters Once per turn: You can detach 1 Xyz Material from this card; all face-up Normal
<G-vec00595-002-s189><detach.abwerfen><de> Einmal pro Spielzug: Du kannst ein Monster im Friedhof deines Gegners wählen; wirf 1 Monster vom Typ Unterweltler ab und verbanne das gewählte Ziel.
<G-vec00595-002-s045><detach.abziehen><en> Convenient starter tabs simplify the handling of both layers and also make it easier to detach the label parts, even when wearing gloves.
<G-vec00595-002-s045><detach.abziehen><de> Komfortable Anfasslaschen ermöglichen dabei ein einfaches Handling der beiden Lagen und erleichtern auch das Abziehen der Teiletiketten, selbst mit Handschuhen.
<G-vec00595-002-s164><detach.befreien><en> In one word, it is important to detach oneself from everything that is known, to find the innocence of childhood and be amazed at new sensations, original tastes and subtle perceptions.
<G-vec00595-002-s164><detach.befreien><de> Kurz, man sollte sich von allem Bekannten befreien, in die Unschuld der Kindheit zurückkehren und sich von neuen Empfindungen, von Urgeschmack und feinsten Wahrnehmungen verführen lassen.
<G-vec00595-002-s068><detach.brechen><en> After having made the score it is necessary to detach the glass so that the oval or the round part remain intact.
<G-vec00595-002-s068><detach.brechen><de> Nachdem wir den Einschnitt durchgeführt haben, muss das Glas gebrochen werden, damit Oval oder Kreis unversehrt bleiben.
<G-vec00595-002-s055><detach.entfernen><en> Easy to attach/detach the pressure gauge or digital pressure switch due to attachment by clip.
<G-vec00595-002-s055><detach.entfernen><de> Manometer und digitaler Druckschalter sind aufgrund der Clipvorrichtung leicht zu befestigen und zu entfernen.
<G-vec00595-002-s076><detach.entkoppeln><en> Attempting to completely detach yourself from this system can only be a long-term goal at the moment.
<G-vec00595-002-s076><detach.entkoppeln><de> Sich von diesem System völlig zu entkoppeln ist nur langfristig möglich.
<G-vec00595-002-s086><detach.herauslösen><en> The film’s aesthetic aims at creating distance and to detach the filmed events from their everyday contexts, from so to speak the flow of life.
<G-vec00595-002-s086><detach.herauslösen><de> Die Ästhetik des Films zielt darauf, Distanz zu schaffen und das gefilmte Ereignis von seinen alltäglichen Kontexten, sozusagen aus dem Lebensfluss, herauszulösen.
<G-vec00595-002-s087><detach.herausnehmen><en> 1 Button Press the - button to release and detach the front control panel.
<G-vec00595-002-s087><detach.herausnehmen><de> 1 -Taste Drücken Sie die -Taste zum Herunterklappen und Herausnehmen des vorderen Bedienfeldes.
<G-vec00595-002-s096><detach.lassen><en> Kombornia Manor SPA A visit to our Spa is an invitation to totally detach yourself from the daily routine and set off for a journey full of exotic fragrances, subtle music, and rejuvenating massages and rituals in which a touch of human hands and human sensitivity are most important.
<G-vec00595-002-s096><detach.lassen><de> Kombornia Hof SPA Ein Besuch in unserem Spa-Zentrum soll für Sie eine Einladung sein, den Alltag hinter sich zu lassen und eine Reise voller exotischer Düfte, subtiler Musiktöne sowie wohltuender Massagen und Rituale anzutreten, bei der die menschliche Sensibilität im Mittelpunkt steht.
<G-vec00595-002-s097><detach.lassen><en> However, the pejorative stigmatization of all factory workers (including those under the moniker of “clandestine”) helps detach the brands from the problem.
<G-vec00595-002-s097><detach.lassen><de> Die Stigmatisierung aller Fabrikarbeiter (einschließlich der als „geheim” bezeichneten) trägt dazu bei, die Marken bei der Betrachtung des Problems außen vor zu lassen.
<G-vec00595-002-s098><detach.lassen><en> Detach from your rushed daily routine and invite your spouse for a romantic stay in our luxury hotel in the heart of the charming nature of the Beskydy Mountains.
<G-vec00595-002-s098><detach.lassen><de> Lassen Sie den Alltagsstress hinter sich, und laden Sie Ihre bessere Hälfte zu einem romantischen Aufenthalt in einem Luxushotel inmitten der bezaubernden Natur der Beskiden ein.
<G-vec00595-002-s103><detach.loslassen><en> These relaxation impulses in connection with the tripartite statement, are giving a signal to the body that this is the time to detach and restore the entity and integrity of the body.
<G-vec00595-002-s103><detach.loslassen><de> Diese Entspannungsimpulse im Anschluss an die 3-geteilte Aussage, signalisieren dem Körper, dass jetzt der Zeitpunkt ist, um loszulassen und die Ganzheit und Integrität des Körpers wiederherzustellen.
<G-vec00595-002-s057><detach.loslösen><en> The process is to detach one's consciousness from the body and to concentrate it on the deeper life so as to bring this deeper consciousness into the body.
<G-vec00595-002-s057><detach.loslösen><de> Der Vorgang besteht darin, sein Bewußtsein vom Körper loszulösen, es auf ein tiefgründiges Leben zu konzentrieren und auf diese Weise jenes tiefe Bewußtsein in den Körper zu bringen.
<G-vec00595-002-s102><detach.losmachen><en> Faster vessel turnaround times (attach in 30 seconds, detach in 10 seconds) ensuring efficient loading operations.
<G-vec00595-002-s102><detach.losmachen><de> Schnellere Schiffsumschlagszeiten (Anlegen in 30 Sekunden, Losmachen in 10 Sekunden); effiziente Ladevorgänge sind garantiert.
<G-vec00595-002-s079><detach.lösen><en> With the help of a spring bar tool you can detach this flap and the band slide can be easily shifted.
<G-vec00595-002-s079><detach.lösen><de> Mit einem Federstegbesteck kann diese Klappe gelöst und der Schlitten auf dem Band einfach verschoben werden.
<G-vec00595-002-s144><detach.nehmen><en> To clean the blender blades, simple detach them from the blender jar and rinse.
<G-vec00595-002-s144><detach.nehmen><de> Zum Reinigen nehmen Sie die Messereinheit einfach aus dem Mixbehälter und waschen sie unter fließendem Wasser ab.
<G-vec00595-002-s148><detach.schließen><en> PIZARRO No, but detach him from the stone. -There is no time to be lost.
<G-vec00595-002-s148><detach.schließen><de> PIZARRO Nein, aber schliess ihn vom Stein los.
<G-vec00595-002-s132><detach.sich_lösen><en> The cameras with a built-in GPS sensor detach again after a few days and can then be collected by the researchers.
<G-vec00595-002-s132><detach.sich_lösen><de> Die Kameras mit eingebautem GPS-Sensor lösen sich nach wenigen Tagen wieder und können dann von den Forschern eingesammelt werden.
<G-vec00595-002-s133><detach.sich_lösen><en> All plugs can be inserted well and detach not too easily from the respective drive.
<G-vec00595-002-s133><detach.sich_lösen><de> Sämtliche Stecker können gut aufgesteckt werden und lösen sich nicht zu leicht vom jeweiligen Laufwerk.
<G-vec00595-002-s134><detach.sich_lösen><en> Small eddies detach from the boundaries of the large ocean currents.
<G-vec00595-002-s134><detach.sich_lösen><de> Im Randbereich der großen Meeresströmungen lösen sich kleinere Wirbel ab.
<G-vec00595-002-s163><detach.trennen><en> Or, use the zpool detach command to detach the disk from the other pool.
<G-vec00595-002-s163><detach.trennen><de> Oder verwenden Sie den Befehl zpool detach, um die Festplatte aus dem anderen Pool zu trennen.
<G-vec00595-002-s184><detach.verabschieden><en> You detach from your suffering, which has never been yours.
<G-vec00595-002-s184><detach.verabschieden><de> Ihr verabschiedet euch von eurem Leiden, das niemals eures war.
