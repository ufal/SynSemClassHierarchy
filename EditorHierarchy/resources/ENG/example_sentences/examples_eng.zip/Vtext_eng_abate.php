<G-vec00055-002-s026><abate.abschwächen><en> In China, we continue to expect support measures for the construction industry; growth there will nevertheless abate.
<G-vec00055-002-s026><abate.abschwächen><de> In China rechnen wir weiter mit Stützungsmaßnahmen für die Bauwirtschaft; das Wachstum wird sich dort dennoch abschwächen.
<G-vec00055-002-s037><abate.mindern><en> Should such aforesaid cure fail, the customer shall be entitled to abate the remuneration or - in case of significant defects - to terminate the contract.
<G-vec00055-002-s037><abate.mindern><de> Ist die Nacherfüllung fehlgeschlagen, ist der Kunde berechtigt, die Gegenleistung zu mindern oder – bei erheblichen Mängeln – vom Vertrag zurückzutreten.
<G-vec00055-002-s043><abate.mindern><en> Malfunctions unrepresented by the OStaBG do not authorise the organiser to hold back or abate payments.
<G-vec00055-002-s043><abate.mindern><de> Störungen, die die OStaBG nicht zu vertreten hat, berechtigen den Veranstalter nicht, Zahlungen zurückzubehalten oder zu mindern.
<G-vec00055-002-s040><abate.reduzieren><en> If possible, ship only the truly indispensable items and try to buy when you arrive to abate some of the cost.
<G-vec00055-002-s040><abate.reduzieren><de> Wenn möglich, versenden Sie nur die wirklich unentbehrlichen Gegenstände und versuchen Sie zu kaufen, wenn Sie ankommen, um einige der Kosten zu reduzieren.
