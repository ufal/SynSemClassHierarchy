<G-vec00637-002-s027><bow.beugen><en> I have only to bow before these unfortunate circumstances.
<G-vec00637-002-s027><bow.beugen><de> Ich kann mich nur den unglücklichen Umständen beugen.
<G-vec00637-002-s028><bow.beugen><en> You will understand that sooner or later, because every mouth will confess that Jesus Christ is Lord and every knee will bow before him,“ Jonathan felt how well it works to use the word of God as a sharp two-edged sword.
<G-vec00637-002-s028><bow.beugen><de> Das wirst du früher oder später begreifen, denn jeder Mund wird bekennen, dass Jesus Christus Herr ist und jedes Knie wird sich vor ihm beugen“, Jonathan spürte, wie gut es tut das Wort Gottes als schärfstes zweischneidiges Schwert einzusetzen.
<G-vec00637-002-s029><bow.beugen><en> The ruling idol knows how to enforce its „subjectless“ (Marx) will by means of the „silent (implied) compulsion“ of competition to which even the powerful must bow, especially if they manage hundreds of factories and shift billions across the globe.
<G-vec00637-002-s029><bow.beugen><de> Der herrschende Götze weiß seinen subjektlosen Willen über den „stummen Zwang“ der Konkurrenz durchzusetzen, dem sich auch die Mächtigen beugen müssen, gerade wenn sie hunderte von Fabriken managen und Milliardensummen über den Globus schieben.
<G-vec00637-002-s030><bow.beugen><en> 11 For it is written, *I* live, saith [the] Lord, that to me shall bow every knee, and every tongue shall confess to God.
<G-vec00637-002-s030><bow.beugen><de> 11 Denn es steht geschrieben: "So wahr ich lebe, spricht der Herr, mir soll sich jedes Knie beugen, und jede Zunge soll Gott bekennen".
<G-vec00637-002-s031><bow.beugen><en> And at that moment, every knee will bow. Some in loving adoration, some in terror, but every knee will bow.
<G-vec00637-002-s031><bow.beugen><de> Und in diesem Moment wird sich jedes Knie beugen, manche in liebender Anbetung, andere vor Schrecken, aber jedes Knie wird sich beugen.
<G-vec00637-002-s032><bow.beugen><en> The LG G5 must bow to the Galaxy S7 in the multi-core test.
<G-vec00637-002-s032><bow.beugen><de> Nur beim Multi-Core-Test muss sich das LG G5 dem Galaxy S7 beugen.
<G-vec00637-002-s033><bow.beugen><en> 9 Wherefore also °God highly exalted him, and granted him a name, that which is above every name, 10 that at the name of Jesus every knee should bow, of heavenly and earthly and infernal [beings], 11 and every tongue confess that Jesus Christ [is] Lord to °God [the] Father's glory.
<G-vec00637-002-s033><bow.beugen><de> 9 Darum hat ihn auch Gott erhöht und hat ihm einen Namen gegeben, der über alle Namen ist, 10 daß in dem Namen Jesu sich beugen aller derer Kniee, die im Himmel und auf Erden und unter der Erde sind, 11 und alle Zungen bekennen sollen, daß Jesus Christus der HERR sei, zur Ehre Gottes, des Vaters.
<G-vec00637-002-s035><bow.beugen><en> 14:11 For it is written, “As I live, says the Lord, every knee will bow to me, and every tongue will give praise to God.”
<G-vec00637-002-s035><bow.beugen><de> 11Denn es steht geschrieben: "So wahr ich lebe, spricht der Herr, mir soll sich jedes Knie beugen, und jede Zunge soll Gott bekennen".
<G-vec00637-002-s036><bow.beugen><en> A woman doesn't know how to bow her knee to God until she learns how to bow her knee to her husband.
<G-vec00637-002-s036><bow.beugen><de> Eine Frau weiß erst, wie sie das Knie vor Gott richtig beugt, wenn sie gelernt hat, das Knie vor ihrem Ehemann zu beugen.
<G-vec00637-002-s037><bow.beugen><en> Let's bow our heads and have a word of prayer.
<G-vec00637-002-s037><bow.beugen><de> Lasst uns unsere Häupter beugen und beten.
<G-vec00637-002-s038><bow.beugen><en> It is customary to bow upon entering and leaving the dojo and also upon going on and off the mat.
<G-vec00637-002-s038><bow.beugen><de> Es ist üblich, beim betreten und verlassen des Dojo und auch beim gehen auf und von der Matte zu beugen.
<G-vec00637-002-s039><bow.beugen><en> Let the ruler be the first to show respect for science, because often the ruler does not consider himself obligated to bow before knowledge.
<G-vec00637-002-s039><bow.beugen><de> Möge der Regent als erster der Wissenschaft Achtung erweisen, denn der Regent sieht sich oft nicht verpflichtet, sich dem Wissen zu beugen.
<G-vec00637-002-s040><bow.beugen><en> When we bow, it is not a religious performance, but a sign of respect for the same spirit of Universal Creative Intelligence that is within us all.
<G-vec00637-002-s040><bow.beugen><de> Wenn wir beugen, ist es keine religiöse Vorstellung, sondern ein Zeichen des Respekts für den gleichen Geist der universellen kreativen Intelligenz, die in uns allen ist.
<G-vec00637-002-s041><bow.beugen><en> I do not bow to terrorism.
<G-vec00637-002-s041><bow.beugen><de> Ich werde mich dem Terror nicht beugen.
<G-vec00637-002-s042><bow.beugen><en> E-26 E-26 Now let us bow our heads just a moment, before we approach the Author of this Word.
<G-vec00637-002-s042><bow.beugen><de> E-14 Nun, laßt uns unsere Häupter für einen Moment beugen, ehe wir uns dem Autor dieses Wortes nähern.
<G-vec00637-002-s043><bow.beugen><en> Without the backing of Moscow, the socialist governments in Soviet bloc countries had no option but to bow to public pressure.
<G-vec00637-002-s043><bow.beugen><de> Ohne die Unterstützung Moskaus hatten die sozialistischen Regierungen in den Sowjetblockländern keine andere Wahl, als sich dem öffentlichen Druck zu beugen.
<G-vec00637-002-s044><bow.beugen><en> And now these leaders, having made their way to the great plain of Dura, were to bow in worship as soon as the royal orchestra began playing.
<G-vec00637-002-s044><bow.beugen><de> Und nun sollten sich diese Leiter, die sich auf den Weg bis zur weiten Ebene von Dura gemacht hatten, in Anbetung beugen, sobald das königliche Orchester zu spielen begann.
<G-vec00637-002-s045><bow.beugen><en> Rigid dogmas are established, religious rules are born, and you can only bow before the Tables of the Law, whereas in the beginning it was not so.
<G-vec00637-002-s045><bow.beugen><de> Man stellt starre Dogmen auf, religiöse Regeln bilden sich, und man muss sich den Gesetzestafeln beugen, während es zu Beginn ganz anders war.
<G-vec00637-002-s273><bow.beugen><en> Every knee shall bow and every tongue shall confess, D&C 88:104.
<G-vec00637-002-s273><bow.beugen><de> Jedes Knie wird sich beugen und jede Zunge wird bekennen, LuB 88:104.
<G-vec00637-002-s274><bow.beugen><en> Precisely in the smallest acts is free will manifested, and the Guide must bow in sorrow before this immutable law.
<G-vec00637-002-s274><bow.beugen><de> Gerade bei den kleinsten Taten bekundet sich der freie Wille, und der Führer muss sich diesem unwandelbaren Gesetz traurig beugen.
<G-vec00637-002-s276><bow.beugen><en> The sense of their greatness makes him bow in humility.
<G-vec00637-002-s276><bow.beugen><de> Der Gedanke an Seine Größe zwingt ihn, sich in Demut zu beugen.
<G-vec00637-002-s277><bow.beugen><en> 14:11 For it is written, "`As I live,` says the Lord, `to me every knee will bow. Every tongue will confess to God.`"
<G-vec00637-002-s277><bow.beugen><de> 11 Denn es steht geschrieben: `[So wahr] ich lebe, spricht der Herr, mir wird sich jedes Knie beugen, und jede Zunge wird Gott bekennen.
<G-vec00637-002-s279><bow.beugen><en> Glorified is He before Whom all the dwellers of earth and heaven bow down in adoration and unto Whom all men turn in supplication.
<G-vec00637-002-s279><bow.beugen><de> Verherrlicht ist Er, vor dem alle Bewohner der Erde und des Himmels in Anbetung sich beugen, an den alle Menschen flehend sich wenden.
<G-vec00637-002-s273><bow.sich_beugen><en> Every knee shall bow and every tongue shall confess, D&C 88:104.
<G-vec00637-002-s273><bow.sich_beugen><de> Jedes Knie wird sich beugen und jede Zunge wird bekennen, LuB 88:104.
<G-vec00637-002-s274><bow.sich_beugen><en> Precisely in the smallest acts is free will manifested, and the Guide must bow in sorrow before this immutable law.
<G-vec00637-002-s274><bow.sich_beugen><de> Gerade bei den kleinsten Taten bekundet sich der freie Wille, und der Führer muss sich diesem unwandelbaren Gesetz traurig beugen.
<G-vec00637-002-s275><bow.sich_beugen><en> And at that moment, every knee will bow. Some in loving adoration, some in terror, but every knee will bow.
<G-vec00637-002-s275><bow.sich_beugen><de> Und in diesem Moment wird sich jedes Knie beugen, manche in liebender Anbetung, andere vor Schrecken, aber jedes Knie wird sich beugen.
<G-vec00637-002-s276><bow.sich_beugen><en> The sense of their greatness makes him bow in humility.
<G-vec00637-002-s276><bow.sich_beugen><de> Der Gedanke an Seine Größe zwingt ihn, sich in Demut zu beugen.
<G-vec00637-002-s277><bow.sich_beugen><en> 14:11 For it is written, "`As I live,` says the Lord, `to me every knee will bow. Every tongue will confess to God.`"
<G-vec00637-002-s277><bow.sich_beugen><de> 11 Denn es steht geschrieben: `[So wahr] ich lebe, spricht der Herr, mir wird sich jedes Knie beugen, und jede Zunge wird Gott bekennen.
<G-vec00637-002-s278><bow.sich_beugen><en> 11 For it is written, As I live, says the Lord, every knee shall bow to me, and every tongue shall confess to God.
<G-vec00637-002-s278><bow.sich_beugen><de> 11 Denn es steht geschrieben: "So wahr ich lebe, spricht der Herr, mir soll sich jedes Knie beugen, und jede Zunge soll Gott bekennen".
<G-vec00637-002-s279><bow.sich_beugen><en> Glorified is He before Whom all the dwellers of earth and heaven bow down in adoration and unto Whom all men turn in supplication.
<G-vec00637-002-s279><bow.sich_beugen><de> Verherrlicht ist Er, vor dem alle Bewohner der Erde und des Himmels in Anbetung sich beugen, an den alle Menschen flehend sich wenden.
<G-vec00637-002-s280><bow.verbeugen><en> - The one who brought us this profile, we must bow to the belt.
<G-vec00637-002-s280><bow.verbeugen><de> - Derjenige, der uns dieses Profil gebracht hat, müssen wir zum Gürtel verbeugen.
<G-vec00637-002-s281><bow.verbeugen><en> WALK WITH ME and see my glory to every step with me learn to climb the mountains, no difficulty will be for you an obstacle, for every mountain will bow before us.
<G-vec00637-002-s281><bow.verbeugen><de> Walk With Me und meine Herrlichkeit sehen, um jeden Schritt mit mir zu lernen, die Berge zu erklimmen, wird keine Schwierigkeit für Sie ein Hindernis sein, denn jeder Berg wird vor uns verbeugen.
<G-vec00637-002-s282><bow.verbeugen><en> The great butterfly, impassive as always, seemed to bow slightly.
<G-vec00637-002-s282><bow.verbeugen><de> Der große Schmetterling, ausdruckslos wie immer, schien sich knapp zu verbeugen.
<G-vec00637-002-s283><bow.verbeugen><en> The Boss,[i] who really gives orders to all of them, and to whom they bow and flatter.
<G-vec00637-002-s283><bow.verbeugen><de> Der Herrscher, der in Wirklichkeit alle leitet, vor dem sie sich verbeugen und dem sie schmeicheln.
<G-vec00637-002-s284><bow.verbeugen><en> When two bhikkhus are naked, the senior bhikkhu should not get the junior bhikkhu to bow down to him or to perform a service for him.
<G-vec00637-002-s284><bow.verbeugen><de> Wenn zwei Bhikkhus nackt sind, sollte der ältere Bhikkhu den jüngeren Bhikkhu nicht veranlassen sich zu verbeugen, oder ihm einen Dienst zu erweisen.
<G-vec00637-002-s285><bow.verbeugen><en> Mogu'shan Palace Respect Bow to the Shado-Pan Novices when they bow to you after being defeated during the Master Snowdrift event in Shado-Pan Monastery on Heroic Difficulty.
<G-vec00637-002-s285><bow.verbeugen><de> Verbeugt Euch vor den Shado-Pan-Novizen, wenn sie sich vor Euch verbeugen, nachdem Ihr sie während des Ereignisses 'Meister Schneewehe' im Shado-Pan-Kloster auf dem Schwierigkeitsgrad 'Heroisch' bezwungen habt.
<G-vec00637-002-s286><bow.verbeugen><en> The viewer sees how a Japanese "common man" transforms himself into a Yakuza, and experiences what it is like to have people bow and step aside for you on the sidewalk.
<G-vec00637-002-s286><bow.verbeugen><de> Der Zuschauer erfährt, wie man als gewöhnlicher Japaner zum Yakuza wird und wie es sich anfühlt, wenn auf der Straße alle Passanten auf die Seite gehen oder sich verbeugen.
<G-vec00637-002-s287><bow.verbeugen><en> It is rather difficult to accept a photograph, because it is said that you should not bow to any.
<G-vec00637-002-s287><bow.verbeugen><de> Es ist ziemlich schwer, ein Foto zu akzeptieren, denn es wurde gesagt, ihr sollt euch vor keinem verbeugen.
<G-vec00637-002-s288><bow.verbeugen><en> 10 Respect Bow to the Shado-Pan Novices when they bow to you after being defeated during the Master Snowdrift event in Shado-Pan Monastery on Heroic Difficulty.
<G-vec00637-002-s288><bow.verbeugen><de> 10 Respekt Verbeugt Euch vor den Shado-Pan-Novizen, wenn sie sich vor Euch verbeugen, nachdem Ihr sie während des Ereignisses 'Meister Schneewehe' im Shado-Pan-Kloster auf dem Schwierigkeitsgrad 'Heroisch' bezwungen habt.
<G-vec00637-002-s289><bow.verbeugen><en> The story of Adam and Eve in the Qur'an indicates that it was the responsibility of both Adam and Eve that led to their expulsion from Heaven, though Adam was highly honored to the extent that the angels were ordered to bow down in his respect.
<G-vec00637-002-s289><bow.verbeugen><de> Die Geschichte von Adam und Eva im Koran verweist darauf, dass es sowohl Adams als auch Evas Verantwortung war, was zu ihrer Vertreibung aus dem Himmel führte, obwohl Adam so hoch geehrt war, dass den Engeln geboten wurde, sich in Ehrfurcht vor ihm zu verbeugen.
<G-vec00637-002-s307><bow.verneigen><en> We want to say this without pathos: We bow down before this resolve and rebellion, before the stamina and the hope that comes from it.
<G-vec00637-002-s307><bow.verneigen><de> Wir möchten das ohne Pathos sagen: Wir verneigen uns vor dieser Entschlossenheit und Rebellion, vor dem langem Atem und der Hoffnung, die davon ausgeht.
<G-vec00637-002-s308><bow.verneigen><en> He becomes that god of all gods that the world must bow before and establishes the abomination of desolation.
<G-vec00637-002-s308><bow.verneigen><de> Er wird zum Gott aller Götter, vor dem die Welt sich verneigen muss, und errichtet den Gräuel der Verwüstung.
<G-vec00637-002-s309><bow.verneigen><en> We bow before your merged divinity on earth.
<G-vec00637-002-s309><bow.verneigen><de> Wir verneigen uns vor deiner verschmolzenen Göttlichkeit auf Erden.
<G-vec00637-002-s310><bow.verneigen><en> From now on, she would have to bend her knee only before Lord Krayt – as to the members of the inner circle, it would suffice in future to bow briefly, while the low-ranking Sith she had dealt with so far would have to bow before her as well.
<G-vec00637-002-s310><bow.verneigen><de> Ab sofort würde sie nur noch vor Lord Krayt knien müssen – vor den Mitgliedern des inneren Zirkels würde es nunmehr genügen, sich kurz zu verneigen.
<G-vec00637-002-s311><bow.verneigen><en> Full of reverence we bow to Your feet.
<G-vec00637-002-s311><bow.verneigen><de> Wir verneigen uns in Ehrfurcht vor Deinen Füssen.
<G-vec00637-002-s312><bow.verneigen><en> Here we just stand in front of an incomprehensible puzzle, to which we can only bow down in astonishment.
<G-vec00637-002-s312><bow.verneigen><de> Hier stehen wir einfach vor unfassbaren Rätseln und können uns nur staunend vor alledem verneigen.
<G-vec00637-002-s313><bow.verneigen><en> You do not need to bow before me, as we are equal.
<G-vec00637-002-s313><bow.verneigen><de> Du brauchst dich nicht vor mir zu verneigen, weil wir gleich sind.
<G-vec00637-002-s314><bow.verneigen><en> I want to bow to this wise soul.
<G-vec00637-002-s314><bow.verneigen><de> Von dieser weisen Seele möchte ich mich verneigen.
<G-vec00637-002-s315><bow.verneigen><en> Mohammedan literature tells us that when the manbody was made, God ordered the angels to bow down to it. So great is man, you see.
<G-vec00637-002-s315><bow.verneigen><de> Mohammedanische Schriften sagen, dass bei der Erschaffung des menschlichen Körpers Gott die Engel hieß, sich davor zu verneigen; so groß ist der Mensch.
<G-vec00637-002-s316><bow.verneigen><en> When we bow down, we should kneel so that our lower legs, both hands and head touch the floor, and then we should say "Mathen Vandami" which means, "I am bowing down my head."
<G-vec00637-002-s316><bow.verneigen><de> Wenn wir uns verneigen, sollten wir nieder knien und mit unseren Unterschenkeln, beiden Händen und dem Kopf den Boden berühren und „Mathen Vandami“ sagen, was „Ich verneige mich“ bedeutet.
<G-vec00637-002-s317><bow.verneigen><en> One day Isola was sitting in the park and saw how the trees moved in the wind and how they seemed to bow down before her.
<G-vec00637-002-s317><bow.verneigen><de> Eines Tages sass Isola im park und sah, wie sich die Bäume im Wind bewegten und sich vor ihr zu verneigen schienen.
<G-vec00637-002-s318><bow.verneigen><en> When we bow to show respect to the Buddha, we’re showing respect for the potential of human beings.
<G-vec00637-002-s318><bow.verneigen><de> Wenn wir uns verneigen, um Respekt gegenüber dem Buddha zu zeigen, zeigen wir Respekt gegenüber dem Potenzal von menschlichen Wesen.
<G-vec00637-002-s319><bow.verneigen><en> Peter told his fellow Germans that it is tradition in China to use always both hands and to bow while transferring a thing.
<G-vec00637-002-s319><bow.verneigen><de> Peter erklärte seinen deutschen Landsleuten, dass es in China Tradition ist, bei der Übergabe einer Sache immer beide Hände zu benutzen und sich zu verneigen.
<G-vec00637-002-s320><bow.verneigen><en> We humbly ask their pardon for all the injustices they have suffered under the cover of the Orthodox Church and we bow down before the martyrs of this Ukrainian Greek Catholic Church.
<G-vec00637-002-s320><bow.verneigen><de> Wir bitten demütig um Vergebung für all das Unrecht, das sie unter dem Deckmantel der orthodoxen Kirche erleiden mussten und verneigen uns vor den Märtyrern der ukrainischen griechisch-katholischen Kirche“.
