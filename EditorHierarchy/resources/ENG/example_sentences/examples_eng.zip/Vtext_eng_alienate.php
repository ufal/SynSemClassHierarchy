<G-vec00996-002-s005><alienate.abschrecken><en> One nasty surprise can alienate a lot of users.
<G-vec00996-002-s005><alienate.abschrecken><de> Eine böse Überraschung kann viele Nutzer abschrecken.
<G-vec00996-002-s006><alienate.abschrecken><en> Even if Vona succeeds in marginalizing radicals, an intra-Jobbik fight may still alienate moderate voters.
<G-vec00996-002-s006><alienate.abschrecken><de> Selbst wenn Vona mit der Marginalisierung von radikalen Kräften Erfolg haben sollte, könnte ein parteiinterner Streit gemäßigte Wähler noch immer abschrecken, glaubt Lánczi.
<G-vec00996-002-s007><alienate.abschrecken><en> A poor choice, however, can lead to costly mistakes-and alienate the very audience your company hopes to serve.
<G-vec00996-002-s007><alienate.abschrecken><de> Eine schlechte Wahl kann jedoch kostspielige Fehler zur Folge haben und eben die Zielgruppe abschrecken, die Ihr Unternehmen ansprechen möchte.
<G-vec00996-002-s028><alienate.abschrecken><en> Negativity will not only alienate your audience but is also hard to understand.
<G-vec00996-002-s028><alienate.abschrecken><de> Negativität schreckt den Zuschauer ab und ist außerdem schwer zu verstehen.
<G-vec00996-002-s010><alienate.entfremden><en> Do not alienate yourself through your choice in clothing.
<G-vec00996-002-s010><alienate.entfremden><de> Entfremde dich nicht durch die Auswahl deiner Kleidung.
<G-vec00996-002-s011><alienate.entfremden><en> We have used it to alienate half of humanity from the giftgiving norm.
<G-vec00996-002-s011><alienate.entfremden><de> Wir haben es dazu verwendet, die halbe Menschheit der Idee des Schenkens zu entfremden.
<G-vec00996-002-s012><alienate.entfremden><en> Do not add to their burdens of guilt which you can be sure the devils taunt them with in an effort to alienate them from you.
<G-vec00996-002-s012><alienate.entfremden><de> Fügt nichts hinzu zu ihrer Schuldenlast, mit welcher sie die Teufel beladen, in einem Versuch, sie von euch zu entfremden.
<G-vec00996-002-s013><alienate.entfremden><en> Although some parents may genuinely believe their child has a ‘right to know the truth’, this should come at the child’s own pace and not be used to alienate them from their other family members.
<G-vec00996-002-s013><alienate.entfremden><de> Obwohl einige Eltern wirklich glauben, ihr Kind habe das „Recht, die Wahrheit zu erfahren“, sollte dies im eigenen Tempo geschehen und nicht dazu verwendet werden, sie von ihren anderen Familienmitgliedern zu entfremden.
<G-vec00996-002-s014><alienate.entfremden><en> By combining tragicomic and conflicting elements Juha Sääski is constructing entities, where even absurd associations do not alienate us from meeting reality, but might open new perspectives and show the true nature of subjects and phenomena more clealry and purely.
<G-vec00996-002-s014><alienate.entfremden><de> Durch die Verknüpfung widersprüchlicher Elemente schafft Juha Sääski Einheiten, in denen selbst absurde Assoziationen uns nicht von der Wirklichkeit entfremden, sondern im Gegenteil neue Blickwinkel eröffnen und uns die wahre Natur von Dingen und Phänomenen reiner und deutlicher vor Augen führen.
<G-vec00996-002-s015><alienate.entfremden><en> The "defensive war" Bayik is inferring would in all likelihood result in yet more deaths, attacks, car bombs and military action. It would not bring Turkey and the PKK a step closer at all, but would further alienate both sides, the Kurds and the Turks.
<G-vec00996-002-s015><alienate.entfremden><de> Denn ein "Verteidigungskrieg", wie Bayık ihn meint, würde wohl noch mehr Tote, Anschläge, Autobomben sowie Militäraktionen zur Folge haben und die Türkei und die PKK keinen Schritt näher bringen, sondern beide Seiten, Kurden und Türken, noch weiter entfremden.
<G-vec00996-002-s016><alienate.entfremden><en> Which may be the reason to alienate a man for further relations.
<G-vec00996-002-s016><alienate.entfremden><de> Das mag der Grund sein, einen Mann für weitere Beziehungen zu entfremden.
<G-vec00996-002-s017><alienate.entfremden><en> They only serve to alienate us from others and sentence us to a life on the triangle.
<G-vec00996-002-s017><alienate.entfremden><de> Sie dienen nur dazu, uns von anderen zu entfremden und uns zu einem Leben auf dem Dreieck zu verurteilen.
<G-vec00996-002-s025><alienate.entfremden><en> That would be foolhardy, it would alienate their listeners, and it would trouble the believers among the left themselves.
<G-vec00996-002-s025><alienate.entfremden><de> Das wäre töricht gewesen und würde sie nur ihren Zuhöreren entfremden, auch würden sie jene Linken verunsichern die selbst gläubig waren.
<G-vec00996-002-s019><alienate.enttäuschen><en> The West is doing everything to alienate eastern europe and vice versa.
<G-vec00996-002-s019><alienate.enttäuschen><de> Der Westen tut alles, um Osteuropa zu enttäuschen und vice versa.
<G-vec00996-002-s029><alienate.verfremden><en> Instead, I modify, alienate, get inspired, develop further, play … and the results are manifold.
<G-vec00996-002-s029><alienate.verfremden><de> So verfremdete ich, lies mich inspirieren, entwickelte weiter, spielte … Die Ergebnisse waren vielfältig.
<G-vec00996-002-s009><alienate.verschrecken><en> It was, therefore, impermissible to advance and fight for a socialist program, for it would alienate the democratic capitalists and drive them into the camp of the fascists.
<G-vec00996-002-s009><alienate.verschrecken><de> Es sei daher unzulässig, für ein sozialistisches Programm einzutreten, denn dies würde die demokratischen Kapitalisten verschrecken und ins Lager der Faschisten treiben.
