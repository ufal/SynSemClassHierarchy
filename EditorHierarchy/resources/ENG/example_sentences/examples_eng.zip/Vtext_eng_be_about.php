<G-vec00290-003-s133><be_about.lassen><en> A few dishes from our menu can be delivered to your home.
<G-vec00290-003-s133><be_about.lassen><de> Sie können sich eine Reihe von Gerichten auf der Speisekarte nach Hause liefern lassen.
<G-vec00290-003-s134><be_about.lassen><en> Modular furniture system, mobile on castors, with varnished or wooden surfaces, in two widths: 80 or 120 cm. Basic module to be extended with a monitor, a projector or for video conference.
<G-vec00290-003-s134><be_about.lassen><de> Modulares Möbelsystem, mobil auf Rollen, mit Lack- oder Holzoberflächen, in 80 oder 120 SIDEBOARDS Diese Sideboards lassen auf Knopfdruck Monitore oder Projektionswände in unterschiedlichen Größen zum Vorschein kommen.
<G-vec00290-003-s135><be_about.lassen><en> Factor analysis confirmed that within the first 6 items the burden of "other" working conditions could be allocated across the item, while 2 other item could be differentiated: stress due to lack of time and stress in the family.
<G-vec00290-003-s135><be_about.lassen><de> Faktorenanalytisch lassen sich die ersten sechs Bereiche bestätigen, die Belastungen durch sonstige Arbeitsbedingungen teilen sich zum Teil diesen Bereichen zu, zum anderen Teil lassen sich zwei weitere Bereiche ausdifferenzieren: Belastung durch Zeitmangel und Belastung in der Familie.
<G-vec00290-003-s136><be_about.lassen><en> We offer models with “stretch effect” that can be stretched, they provide your four-legged friend with more flexibility.
<G-vec00290-003-s136><be_about.lassen><de> So bieten wir beispielsweise Modelle mit „Stretcheffekt“, die sich von einer Grundlänge sehr lang ausdehnen lassen und so deinem Vierbeiner mehr Bewegungsfreiheiten lassen.
<G-vec00290-003-s137><be_about.lassen><en> If you don’t like it very much, you will be able to modify some aspects of the remix, such as the tempo or tone to custom it.
<G-vec00290-003-s137><be_about.lassen><de> Falls man damit noch nicht zufrieden ist, lassen sich einige Aspekte anpassen, etwa Tempo oder Tonhöhe.
<G-vec00290-003-s138><be_about.lassen><en> The German chancellor must not be taken in by the Ukrainian government's manoeuvring, the left-liberal daily Berliner Zeitung warns: "Otherwise she would jeopardise Germany's role as the most important mediator in this crisis, listened to in both Kiev and Moscow and currently able to get the opposing sides to sit down at a table.
<G-vec00290-003-s138><be_about.lassen><de> Die Bundeskanzlerin darf sich nicht von der ukrainischen Regierung vereinnahmen lassen, warnt die linksliberale Berliner Zeitung: "Sonst würde sie Deutschlands Rolle als wichtigster Vermittler in dieser Krise aufs Spiel setzen, der sowohl in Kiew als auch in Moskau Gehör findet und derzeit offenbar allein in der Lage ist, die Kontrahenten noch an einen Tisch zu bringen.
<G-vec00290-003-s139><be_about.lassen><en> If you stop the use, the data will be deleted.
<G-vec00290-003-s139><be_about.lassen><de> Wenn Sie die Bilder manuell anzeigen lassen, erfolgt das oben genannte Tracking.
<G-vec00290-003-s140><be_about.lassen><en> I.e., man must want to be helped; he must feel his trouble and strive to get out of it; he must feel the spiritual state as inadequate and carry desire to remedy it, then the spiritual guides are ready and also entitled by God to assist him.
<G-vec00290-003-s140><be_about.lassen><de> D.h., es muss der Mensch sich helfen lassen wollen, er muss seine Not empfinden und herauszukommen trachten, er muss also den Geisteszustand als mangelhaft empfinden und Verlangen tragen nach Hebung dessen, dann sind die geistigen Führer bereit und auch von Gott aus berechtigt, ihm beizustehen.
<G-vec00290-003-s141><be_about.lassen><en> At traffic lights, people with red-green color blindness should be guided by cues other than the color of the light.
<G-vec00290-003-s141><be_about.lassen><de> An Verkehrsampeln sollten sich Farbenblinde von anderen Merkmalen als der Farbe des Lichts leiten lassen.
<G-vec00290-003-s142><be_about.lassen><en> And it’s this distinctive MAX style - together with the premium quality evident in the overall fit and finish – that makes the XMAX 125 a scooter that you'll be proud to be seen with.
<G-vec00290-003-s142><be_about.lassen><de> Durch diesen unverwechselbaren MAX-Stil und die hochwertige Qualität, die durch die gesamte Verarbeitung deutlich wird, können Sie sich mit dem XMAX 125 jederzeit sehen lassen.
<G-vec00290-003-s143><be_about.lassen><en> Happened to be our anniversary so they insisted on a glass of wine on the house.
<G-vec00290-003-s143><be_about.lassen><de> Der Garten war schön, um abends mit einem Glas Wein den Tag ausklingen zu lassen.
<G-vec00290-003-s144><be_about.lassen><en> These tailored products save weight because they can be adapted from the outset to the actual stresses in the finished part.
<G-vec00290-003-s144><be_about.lassen><de> Tailored Strips sparen Gewicht, weil sie sich von vornherein an die tatsächlichen Belastungsverhältnisse im fertigen Bauteil anpassen lassen.
<G-vec00290-003-s145><be_about.lassen><en> You can have this program be installed on either your Mac or Windows computer and also this program is compatible with any iOS device and an iOS version including the iOS 11.
<G-vec00290-003-s145><be_about.lassen><de> Sie können dieses Programm entweder auf Ihrem Mac oder Windows-Computer installieren lassen und dieses Programm ist mit jedem iOS-Gerät und einer iOS-Version einschließlich iOS 11 kompatibel.
<G-vec00290-003-s146><be_about.lassen><en> Be inspired by the flair of Bolzano‘s old town and by the countless cultural treasures situated both in the mountains and in the valleys.
<G-vec00290-003-s146><be_about.lassen><de> Lassen Sie sich zum einen fürs Altstadtflair in Bozen begeistern, zum anderen von den vielen kulturellen Schätzen in Berg und Tal.
<G-vec00290-003-s147><be_about.lassen><en> Those are proteins that, unlike many other medications, cannot be chemically produced.
<G-vec00290-003-s147><be_about.lassen><de> Das sind Proteine, also Eiweißstoffe, die sich nicht chemisch herstellen lassen wie viele andere Medikamente.
<G-vec00290-003-s148><be_about.lassen><en> The material used for gift boxes should not only be fully functional when it comes to its firmness, but preferably, it should be easily disposed of with respect to the environment.
<G-vec00290-003-s148><be_about.lassen><de> Das für die Geschenk-Boxen verwendete Material sollte in Bezug auf Festigkeit voll funktionsfähig sein, aber es sollte sich, wenn möglich, auch einfach und umweltfreundlich entsorgen lassen.
<G-vec00290-003-s149><be_about.lassen><en> Some men and women choose to be sterilised for that reason.
<G-vec00290-003-s149><be_about.lassen><de> Manche Männer und Frauen haben sich aus diesem Grunde sterilisieren lassen.
<G-vec00290-003-s150><be_about.lassen><en> These types of tests can be helpful when you have a job position that requires certain specific interpersonal skills that can’t be assessed with just a quick face to face interview, especially if you are conducting many interviews a day.
<G-vec00290-003-s150><be_about.lassen><de> Diese Tests eignen sich insbesondere bei Stellen, die bestimmte soziale Kompetenzen benötigen, die sich nicht in einem kurzen persönlichen Gespräch einschätzen lassen – vor allem nicht wenn Sie viele Bewerbungsgespräche an einem Tag durchführen.
<G-vec00290-003-s151><be_about.lassen><en> Videos, photos and links received via instant messages in WhatsApp can now be previewed by tapping them lightly.
<G-vec00290-003-s151><be_about.lassen><de> WhatsApp Peek & Pop Videos, Fotos und Links könnt ihr euch in einer Vorschau anzeigen lassen, indem ihr leicht auf den jeweiligen Inhalt tippt .
<G-vec00290-003-s247><be_about.sein><en> 9.2 We will be entitled to make inquiries related to you, including credit checks, with third party credit and financial institutions, in accordance with the information you have provided to us.
<G-vec00290-003-s247><be_about.sein><de> 9.2 Wir sind berechtigt, Anfragen über Sie zu machen, inklusive Kreditüberprüfungen, mit Kredit- und Finanzinstitutionen von dritten Parteien in Übereinstimmung mit den Informationen, die Sie uns zur Verfügung gestellt haben.
<G-vec00290-003-s248><be_about.sein><en> By creating an account at Russian Embroidery you will be able to shop faster, be up to date on an orders status, and keep track of the orders you have previously made.
<G-vec00290-003-s248><be_about.sein><de> Durch Ihre Anmeldung bei Wild Technik sind Sie in der Lage schneller zu bestellen, kennen jederzeit den Status Ihrer Bestellungen und haben immer eine aktuelle Übersicht über Ihre bisherigen Bestellungen.
<G-vec00290-003-s249><be_about.sein><en> All functions of RFEM can be accessed in the menu bar.
<G-vec00290-003-s249><be_about.sein><de> Alle Funktionen von RFEM sind über diese Menüleiste zugänglich.
<G-vec00290-003-s250><be_about.sein><en> You can be enchanted by the sunny beaches and endless space of the Baltic, the murmur of the tide, the beautiful scenery, the timeless woods and forests and among them hundreds of charming streams, rivers and lakes.
<G-vec00290-003-s250><be_about.sein><de> Bezaubernd sind die sonnigen Strände und der weite Ostseeraum, die Schaumkronen der Wellen, die Schönheit der Landschaft, und die allgegenwärtigen Wälder voller reizvoller Bäche, Flüsse und Seen.
<G-vec00290-003-s251><be_about.sein><en> Property Location With a stay at Hotel Mariahilf in Munich (Au-Haidhausen), you'll be minutes from Mariahilfplatz and Deutsches Museum.
<G-vec00290-003-s251><be_about.sein><de> Lage Bei einem Aufenthalt im Hotel Mariahilf in München (Au - Haidhausen) sind Sie nur wenige Minuten entfernt von: Mariahilfplatz und Deutsches Museum.
<G-vec00290-003-s252><be_about.sein><en> In addition, Episode Interactive may notify authorities or take any actions it deems appropriate (including without limitation suspending your Account and your access to the Service), without notice to you if Episode Interactive suspects or determines that you may have (i) failed to comply with any provision of these Terms of Service or any policies or rules established by Episode Interactive; or (ii) engaged in actions relating to or in the course of using the Service that may be illegal or cause liability, harm, embarrassment, harassment, abuse or disruption for you, Episode Interactive, any third parties or the Service itself.
<G-vec00290-003-s252><be_about.sein><de> GREE kann darüber hinaus Behörden benachrichtigen oder Maßnahmen treffen, die es als angemessen erachtet (einschließlich, ohne Beschränkung, der Sperrung Ihres Benutzerkontos und Ihres Zugriffs auf den Dienst), ohne Sie darüber in Kenntnis zu setzen, wenn GREE der Ansicht ist oder zu der Feststellung gelangt, dass Sie möglicherweise gegen eine Bestimmung dieser Nutzungsbedingungen oder eine andere Richtlinie oder Regel von GREE verstoßen haben, oder sich an Handlungen in Bezug auf die oder im Rahmen der Nutzung des Dienstes beteiligten, die möglicherweise illegal sind oder zu einer Verpflichtung, einer Gefährdung oder einer anderen Störung für Sie, für GREE, für jegliche Drittpartei oder den Dienst selbst führen.
<G-vec00290-003-s253><be_about.sein><en> Bodybuilders call this method "training to failure," because you should be training with weights heavy enough that you eventually can't complete another rep.
<G-vec00290-003-s253><be_about.sein><de> Es bedeutet, dass du Gewichte hebst, die schwer genug sind, dass du "versagst", oder du unfähig bist, die Übung nach ein paar Wiederholungen zu beenden.
<G-vec00290-003-s254><be_about.sein><en> As for transport, you will be spoilt for choice: although travelling by car is still the fastest option, it only takes 30 minutes to get there by public transport.
<G-vec00290-003-s254><be_about.sein><de> Die Verkehrsverbindungen sind hervorragend: auch wenn die Fahrt mit dem Auto immer noch die schnellste Option ist, brauchen Sie mit öffentlichen Verkehrsmitteln nur 30 Minuten.
<G-vec00290-003-s255><be_about.sein><en> Any updates to the IB or other relevant information that is newly available shall be brought to the attention of the investigators in a timely manner.
<G-vec00290-003-s255><be_about.sein><de> Aktualisierungen des Handbuchs des Prüfers oder andere relevante Informationen, die neu verfügbar sind, sind den Prüfern rechtzeitig mitzuteilen.
<G-vec00290-003-s256><be_about.sein><en> The stylish furniture "to go" acts (also in COR's Living collection) as delicate connecting elements that can be combined with all pieces of furniture.
<G-vec00290-003-s256><be_about.sein><de> Die formschönen Möbel „to go“ funktionieren (auch in der Living-Kollektion von COR) als filigrane Bindeglieder, die mit allen Möbelstücken kombinierbar sind.
<G-vec00290-003-s257><be_about.sein><en> Moderator and speaker will be naked.
<G-vec00290-003-s257><be_about.sein><de> Moderator und Vortragender sind nackt.
<G-vec00290-003-s258><be_about.sein><en> To ensure this feature, the basis framework was designed in a way that components and technologies can be exchanged.
<G-vec00290-003-s258><be_about.sein><de> Die Anpassbarkeit ermoeglicht es, dass Komponenten und Technologien des Basisframeworks austauschbar sind.
<G-vec00290-003-s259><be_about.sein><en> House-shaped sarcophagi can be found there, temple-shaped houses of the dead and tumulus tombs, often with a burial chamber and benches inside.
<G-vec00290-003-s259><be_about.sein><de> Hausförmige Sarkophage sind dort zu finden, tempelförmige Totenhäuser und Tumulusgräber, in deren Innerem sich oft eine Grabkammer mit Bänken befindet.
<G-vec00290-003-s260><be_about.sein><en> Correction templates, print proofs and similar items by the principal should be considered approximate.
<G-vec00290-003-s260><be_about.sein><de> Korrekturvorlagen, Andruckmuster und ähnliches durch den Auftraggeber sind als annähernd zu betrachten.
<G-vec00290-003-s261><be_about.sein><en> 9. The index to the type-approved file submitted to the component authorities, which may be obtained on request, is attached.
<G-vec00290-003-s261><be_about.sein><de> 9 Das Inhaltsverzeichnis der bei der Genehmigungsbehörde hinterlegten Beschreibungsunterlagen, die auf Antrag erhältlich sind, liegt bei.
<G-vec00290-003-s262><be_about.sein><en> Only if we can raise our eyes to heaven each day and say “Our Father”, will we be able to be part of a process that can make us see things clearly and risk living no longer as enemies but as brothers and sisters.
<G-vec00290-003-s262><be_about.sein><de> Nur wenn wir jeden Tag fähig sind, die Augen zum Himmel zu richten und Vater unser zu sagen, werden wir in eine Dynamik eintreten können, die uns die Schau und das Wagnis eröffnet, nicht mehr als Feinde, sondern als Brüder und Schwestern zu leben.
<G-vec00290-003-s263><be_about.sein><en> From spring 2019, one-way journeys will be possible between 30 stations.
<G-vec00290-003-s263><be_about.sein><de> Ab Frühling 2019 sind Einwegfahrten zwischen 30 Standorten möglich.
<G-vec00290-003-s264><be_about.sein><en> With a velvety string sound, the subtle tonalities of Spanish culture unfold which can often just barely be perceived in the hot, gleaming sunlight.
<G-vec00290-003-s264><be_about.sein><de> Im samtigen Streicherklang entfalten sich die Zwischentöne der spanischen Kultur, die oftmals im gleißenden Sonnenlicht nicht wahrnehmbar sind.
<G-vec00290-003-s265><be_about.sein><en> You will be sexy and perfect for costume parties.
<G-vec00290-003-s265><be_about.sein><de> Sie sind sexy und perfekt für Kostüm-Parteien.
<G-vec00290-003-s285><be_about.werden><en> Neck muscles The musculature of the neck can be differentiated into superficial and deep muscles.
<G-vec00290-003-s285><be_about.werden><de> Bei der Muskulatur des Halses wird zwischen der oberflächlichen und der tiefen Muskulatur unterschieden.
<G-vec00290-003-s286><be_about.werden><en> Exact date to be determined when Mageia 6 is released.
<G-vec00290-003-s286><be_about.werden><de> Das genaue Datum, wann Mageia 6 veröffentlicht wird, wird noch entschieden.
<G-vec00290-003-s287><be_about.werden><en> Rather, one should use both channels for marketing in the search engine. AdWords in particular, to show up where one cannot yet be found through natural ways (through SEO).
<G-vec00290-003-s287><be_about.werden><de> Vielmehr sollte man beide Kanäle zum Marketing in der Suchmaschine nutzen: AdWords vor allem um dort zu erscheinen wo man noch nicht „natürlich“ (durch die SEO) gefunden wird.
<G-vec00290-003-s288><be_about.werden><en> This exaggeration could, however, cause some people to experience a feeling of tiredness during bathing and the beneficial effect of the sauna might not be felt.
<G-vec00290-003-s288><be_about.werden><de> Diese Übertreibung könnte jedoch dazu führen, dass manche Menschen während des Badens ein Gefühl der Müdigkeit verspüren und die wohltuende Wirkung der Sauna nicht wahrgenommen wird.
<G-vec00290-003-s289><be_about.werden><en> In order for the sensory stimuli to fully unfold, the mouth must be rinsed with Muscle Relax for 10-15 seconds before swallowing the shot.
<G-vec00290-003-s289><be_about.werden><de> Damit sich die sensorischen Reize vollumfänglich entfalten können, ist der Mund während 10-15 Sekunden mit Muscle Relax zu spülen, bevor der Shot geschluckt wird.
<G-vec00290-003-s290><be_about.werden><en> Please note guest credit cards must include an EMV chip to be accepted by the property.
<G-vec00290-003-s290><be_about.werden><de> Beachten Sie bitte, dass Gästegutschriften einen EMV-Chip enthalten müssen, der von der Unterkunft akzeptiert wird.
<G-vec00290-003-s291><be_about.werden><en> Well, this can be done using the xml:lang attribute in XHTML 1.1.
<G-vec00290-003-s291><be_about.werden><de> Dieses wird in XHTML 1.1 mit dem xml:lang Attribut bewerkstelligt.
<G-vec00290-003-s292><be_about.werden><en> I do not know if we are allowed to camp here or not, but it's almost dark and therefore we should be alright – no one will see us. Blast, I forgot the mosquito rings.
<G-vec00290-003-s292><be_about.werden><de> Keine Ahnung, ob wir hier lagern dürfen oder nicht, aber es ist eh bald dunkel und deshalb wird uns wohl auch keiner finden und verjagen – schiet, ich habe die Mückenringe vergessen.
<G-vec00290-003-s293><be_about.werden><en> PTFE or Teflon was invented in 1938 and can be refined for use in the medical industry for prolonged contact with skin.
<G-vec00290-003-s293><be_about.werden><de> PTFE oder Teflon wurde 1938 erfunden und wird sowohl in der Medizin als auch bei der Beschichtung von Bratpfannen verwendet.
<G-vec00290-003-s294><be_about.werden><en> This provides users with a high degree of flexibility and allows ArtemiS suite to be uses where it is actually needed.
<G-vec00290-003-s294><be_about.werden><de> Dies erlaubt eine besonders hohe Flexibilität, und ArtemiS suite wird dort eingesetzt, wo sie wirklich benötigt wird.
<G-vec00290-003-s295><be_about.werden><en> During factory acceptance tests (FAT), for example, a room may be occupied by a machine for up to several weeks.
<G-vec00290-003-s295><be_about.werden><de> Ein Raum wird beispielsweise während des Factory-Acceptance-Tests (FAT) bis zu mehreren Wochen mit einer Maschine belegt.
<G-vec00290-003-s296><be_about.werden><en> Because of this expansion a further growth of the number of visitors may be expected.
<G-vec00290-003-s296><be_about.werden><de> Mit dieser Erweiterung wird eine weitere Zunahme der Besucheranzahl erwartet.
<G-vec00290-003-s297><be_about.werden><en> Both experienced and hobby skiers value the cross-country village of Faistenau with its 54 kilometres of trails not only for the floodlit trail but also the perfect infrastructure directly at the start of the course and the two trails which can be served with a snow-making machine.
<G-vec00290-003-s297><be_about.werden><de> Genießer und Profis schätzen das Langlaufdorf Faistenau mit seinen 60 Loipenkilometern nicht nur wegen der Flutlichtloipe (5 km Skating & 5 km klassisch), sondern auch wegen der perfekten Infrastruktur, welche direkt am Loipeneinstieg geboten wird.
<G-vec00290-003-s298><be_about.werden><en> You agree that any claim arising out of or related to these Terms of Use or your use of the System must be filed within one year after it arose or be permanently barred.
<G-vec00290-003-s298><be_about.werden><de> Sie stimmen zu, dass jeder Anspruch, der sich aus oder im Zusammenhang mit den vorliegenden Nutzungsbedingungen oder Ihrer Nutzung des Systems ergibt, innerhalb eines Jahres nach Entstehen eingereicht werden muss, andernfalls wird er unwiderruflich ausgeschlossen.
<G-vec00290-003-s299><be_about.werden><en> Predictive applications evaluate vast amounts of user data in order to predict what offers a user might be interested in.
<G-vec00290-003-s299><be_about.werden><de> Predictive Applications werten große Mengen an Nutzerdaten aus, um daraus Vorhersagen darüber zu treffen, welche Leistungen und Angebote die Nutzer interessieren wird oder wie sie sich bei bestimmten Impulsen verhalten werden.
<G-vec00290-003-s300><be_about.werden><en> We offer the best budget hotels, hostels, apartments and bed and breakfasts, ensuring your trip to Vuokatti is a memorable one, be it for business or pleasure.
<G-vec00290-003-s300><be_about.werden><de> Wir bieten Ihnen die besten günstigen Hotels, Hostels, Ferienwohnungen und Pensionen in Skien, damit Ihr Urlaub oder Ihre Geschäftsreise ein voller Erfolg wird.
<G-vec00290-003-s301><be_about.werden><en> Although this appears a little unimportant, it is an ability which is not to be taken as well gently.
<G-vec00290-003-s301><be_about.werden><de> Obwohl dies scheint ein wenig unwichtig, es ist eine Funktion, die nicht so gut sanft gemacht wird.
<G-vec00290-003-s302><be_about.werden><en> In fact the shoes caused such a hype that they have continued to be reissued every year since.
<G-vec00290-003-s302><be_about.werden><de> Der Basketballschuh löste ganz im Gegenteil einen wahren Hype aus und wird seitdem jedes Jahr neu aufgelegt.
<G-vec00290-003-s303><be_about.werden><en> The estimated minimum lethal dose is 200 mg, but addicts may be able to tolerate ten times as much.
<G-vec00290-003-s303><be_about.werden><de> Die geschätzte letale Mindestdosis liegt bei 200 mg, jedoch wird bei Gewöhnung auch eine zehnfach höhere Dosis toleriert.
