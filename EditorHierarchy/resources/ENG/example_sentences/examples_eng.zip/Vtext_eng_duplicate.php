<G-vec00187-002-s203><duplicate.duplizieren><en> If, however, you'd like to duplicate an existing line item's settings, you can copy a line item instead.
<G-vec00187-002-s203><duplicate.duplizieren><de> Wenn Sie jedoch die Einstellungen einer vorhandenen Werbebuchung duplizieren möchten, können Sie stattdessen eine Werbebuchung kopieren.
<G-vec00187-002-s204><duplicate.duplizieren><en> For multiple designs, add multiple items to your cart or duplicate the order within your shopping cart.
<G-vec00187-002-s204><duplicate.duplizieren><de> Für mehrere Designs, fügen Sie mehrere Artikel zu Ihrem Warenkorb hinzu oder duplizieren Sie die Bestellung in Ihrem Warenkorb..
<G-vec00187-002-s205><duplicate.duplizieren><en> Therefore, despite the very good result, there is no clear conclusion, because most doctors cannot duplicate such perfect blood pressure measurements.
<G-vec00187-002-s205><duplicate.duplizieren><de> Trotz des sehr guten Ergebnisses gibt es aus diesem Grund keine eindeutige Schlussfolgerung, da die meisten Ärzte/Ärztinnen diese perfekte Blutdruckmessung nicht duplizieren können.
<G-vec00187-002-s206><duplicate.duplizieren><en> If you outgrow a partition, you can allocate a new partition from your unused space, duplicate your existing partition to the new partition, change /etc/fstab to point to the new partition, remount, you now have more space.
<G-vec00187-002-s206><duplicate.duplizieren><de> Sollte eine Partition über ihre Größe hinauswachsen, so kannst du eine neue Partition in dem unbenutzten Teil der Platte erzeugen, die bestehende Partition in die neue Partition duplizieren, /etc/fstab derart anpassen, dass es die neue Partition einhängt, neu einhängen, und du wirst mehr Platz haben.
<G-vec00187-002-s207><duplicate.duplizieren><en> The Duplicate context menu command copies the selected dataset and enables to change ERP-fields, but not geometry data.
<G-vec00187-002-s207><duplicate.duplizieren><de> Der Kontextmenübefehl Duplizieren kopiert den ausgewählten Datensatz und gibt Ihnen die Möglichkeit, die ERP-Felder, aber nicht die Geometriedaten, zu ändern.
<G-vec00187-002-s208><duplicate.duplizieren><en> It is forbidden to change, duplicate, adapt, outlay or use the content of this web site in any other way without the prior permission of Pentos AG.
<G-vec00187-002-s208><duplicate.duplizieren><de> Es ist untersagt, den Inhalt der Internetseiten zu verändern, zu duplizieren, anzugleichen, auszulegen oder anderweitig zu nutzen, ohne vorher eine schriftliche Erlaubnis der Pentos AG eingeholt zu haben.
<G-vec00187-002-s209><duplicate.duplizieren><en> Choose Edit menu > Duplicate.
<G-vec00187-002-s209><duplicate.duplizieren><de> •Wählen Sie Bearbeiten > Duplizieren.
<G-vec00187-002-s210><duplicate.duplizieren><en> To duplicate a theme, hover your mouse over the theme and click the Themes menu (), then select Duplicate.
<G-vec00187-002-s210><duplicate.duplizieren><de> Um ein Design zu duplizieren, setzen Sie den Mauszeiger auf das Design und klicken Sie auf das Menü „Designs“ () und dann auf Duplizieren.
<G-vec00187-002-s212><duplicate.duplizieren><en> Visit the Mirror and Duplicate page to get some information about this function.
<G-vec00187-002-s212><duplicate.duplizieren><de> Besuchen Sie den Artikel Spiegeln und Duplizieren, um einige Informationen über diese Funktion zu erhalten.
<G-vec00187-002-s213><duplicate.duplizieren><en> Duplicate or erase two USB drives simultaneously without connecting to a computer, using this standalone USB duplicator
<G-vec00187-002-s213><duplicate.duplizieren><de> Duplizieren oder löschen Sie zwei USB-Laufwerke gleichzeitig, ohne eine Verbindung zu einem Computer herzustellen.
<G-vec00187-002-s214><duplicate.duplizieren><en> If you try to use the "Duplicate these displays" feature, you'll get an error that says "The display settings could not be saved.
<G-vec00187-002-s214><duplicate.duplizieren><de> Wenn Sie versuchen, die Funktion "Diese Anzeigen duplizieren" zu aktivieren, erhalten Sie die Fehlermeldung "Die Anzeigeeinstellungen konnten nicht gespeichert werden.
<G-vec00187-002-s215><duplicate.duplizieren><en> Sell, lease, loan, distribute, transfer, sublicense, reproduce, duplicate, copy, trade or exploit the NVIDIA Account or access thereto or derive income from the use or provision of the NVIDIA Account, whether for direct commercial or monetary gain or otherwise, without NVIDIA's prior, express and written permission.
<G-vec00187-002-s215><duplicate.duplizieren><de> Ohne vorherige ausdrückliche, schriftliche Genehmigung von NVIDIA das NVIDIA Konto oder den Zugriff darauf verkaufen, verleasen, vermieten, verleihen, verteilen, übertragen, unterlizenzieren, reproduzieren, duplizieren, kopieren, eintauschen oder verwerten oder ein Einkommen aus der Verwendung oder der Bereitstellung des NVIDIA Kontos erzielen, weder durch direkte noch indirekte kommerzielle oder finanzielle Einnahmen.
<G-vec00187-002-s216><duplicate.duplizieren><en> Optional: you can duplicate this layer again to strengthen the effect.
<G-vec00187-002-s216><duplicate.duplizieren><de> Optinal könnt ihr diese Ebene auch noch einmal duplizieren um den Effekt zu verstärken.
<G-vec00187-002-s217><duplicate.duplizieren><en> Not to reproduce, duplicate, copy or re-sell any part of our site in contravention of the provisions of our terms of website use (see more details in the "Content Standards" section below).
<G-vec00187-002-s217><duplicate.duplizieren><de> Ferner stimmen Sie zu, unsere Seite nicht im Widerspruch zu unseren Nutzungsbedingungen auch nicht in Teilen zu vervielfältigen, zu duplizieren, zu kopieren oder weiterzuverkaufen.
<G-vec00187-002-s218><duplicate.duplizieren><en> Or, to give it an even more fundamental expression, no being can go free unless he is able to duplicate.
<G-vec00187-002-s218><duplicate.duplizieren><de> Um es noch grundlegender auszudrücken: Kein Wesen kann frei werden, es sei denn, es ist in der Lage zu duplizieren.
<G-vec00187-002-s219><duplicate.duplizieren><en> On each of them manifestations can be the most diverse, and can duplicate each other.
<G-vec00187-002-s219><duplicate.duplizieren><de> Auf jeder von ihnen können Manifestationen die vielfältigsten sein und sich gegenseitig duplizieren.
<G-vec00187-002-s220><duplicate.duplizieren><en> There are three buttons at the bottom of the page manager: duplicate page, copy page to a different Presenter file and the bin.
<G-vec00187-002-s220><duplicate.duplizieren><de> Am unteren Rand des Seitenmanagers befinden sich drei Schaltflächen: Seite duplizieren, Seite in eine andere Presenter-Datei kopieren und der Papierkorb.
<G-vec00187-002-s221><duplicate.duplizieren><en> Select Insert > New Page > Blank Page or Duplicate This Page.
<G-vec00187-002-s221><duplicate.duplizieren><de> Wählen Sie Einfügen > Neues Zeichenblatt > Dieses Zeichenblatt duplizieren aus.
<G-vec00187-002-s222><duplicate.duplizieren><en> Duplicate projects using Edit Mode or move drawings between projects.
<G-vec00187-002-s222><duplicate.duplizieren><de> Duplizieren Sie Projekte mit dem Bearbeitungsmodus oder verschieben Sie Zeichnungen zwischen Projekten.
<G-vec00187-002-s223><duplicate.duplizieren><en> Use this command to duplicate a selected object.
<G-vec00187-002-s223><duplicate.duplizieren><de> Mit diesem Befehl duplizieren Sie ein ausgewähltes Objekt.
<G-vec00187-002-s224><duplicate.duplizieren><en> - I duplicate the background layer again.
<G-vec00187-002-s224><duplicate.duplizieren><de> - Duplizieren Sie den Hintergrundebene noch einmal.
<G-vec00187-002-s225><duplicate.duplizieren><en> Duplicate the Blurred text and add another Motion Blur with a 162 Distance.
<G-vec00187-002-s225><duplicate.duplizieren><de> Duplizieren Sie den Unscharfen Text (Blurred text) und fügen Sie einen weiteren Bewegungsunschärfe (Motion Blur) mit einer Entfernung von 162 hinzu.
<G-vec00187-002-s226><duplicate.duplizieren><en> To Add a new caption, duplicate an existing <rdf:li> tag that contains caption text.
<G-vec00187-002-s226><duplicate.duplizieren><de> Um einen neuen Untertitel hinzuzufügen, duplizieren Sie ein vorhandenes <rdf:li>- Tag, das Untertitel-Text enthält.
<G-vec00187-002-s227><duplicate.duplizieren><en> Figure 14. Duplicate the selected element in Live View
<G-vec00187-002-s227><duplicate.duplizieren><de> Abbildung 14: Duplizieren Sie das ausgewählte Element in der Live-Ansicht.
<G-vec00187-002-s228><duplicate.duplizieren><en> Get duplicate recovery points on up to two additional sites or devices
<G-vec00187-002-s228><duplicate.duplizieren><de> Duplizieren Sie Wiederherstellungspunkte auf bis zu zwei zusätzliche Standorte oder Geräte.
<G-vec00187-002-s229><duplicate.duplizieren><en> Duplicate the slow transaction.
<G-vec00187-002-s229><duplicate.duplizieren><de> Duplizieren Sie die langsame Transaktion.
<G-vec00187-002-s230><duplicate.duplizieren><en> Duplicate the script that contains the errors.
<G-vec00187-002-s230><duplicate.duplizieren><de> Duplizieren Sie das Skript, das die Fehler enthält.
<G-vec00187-002-s231><duplicate.duplizieren><en> To Add a new caption, duplicate an existing <rdf:li> tag that contains caption text.
<G-vec00187-002-s231><duplicate.duplizieren><de> Um einen neuen Untertitel hinzuzufügen, duplizieren Sie einen vorhandenen < rdf: li > tag, der Beschriftungstext enthält.
<G-vec00187-002-s232><duplicate.duplizieren><en> You can duplicate the objects you selected by going to “Object” > “Edit” > “Duplicate Objects multiple…”.
<G-vec00187-002-s232><duplicate.duplizieren><de> Die ausgesuchten Objekte dupliziert ihr, indem ihr „Objekt“ > „Bearbeiten“ > „Mehrfach duplizieren…“ wählt.
<G-vec00187-002-s233><duplicate.duplizieren><en> Duplicate your master template to use for alternative target groups.
<G-vec00187-002-s233><duplicate.duplizieren><de> Dupliziert die Mastervorlage und passt sie für weitere Zielgruppen an.
<G-vec00187-002-s234><duplicate.duplizieren><en> Duplicate the lines layer.
<G-vec00187-002-s234><duplicate.duplizieren><de> Dupliziert die Linien-Ebene.
<G-vec00187-002-s235><duplicate.duplizieren><en> If the original and destination campaigns are promoting different apps, the “Have not downloaded this app” customer type will not duplicate.
<G-vec00187-002-s235><duplicate.duplizieren><de> Wenn Quell- und Zielkampagne unterschiedliche Apps bewerben, wird der Kundentyp „Haben die App nicht geladen“ nicht dupliziert.
<G-vec00187-002-s236><duplicate.duplizieren><en> 17 The next step is totally up to you. Play around with the fire, duplicate the fire-layer a few times, some of them give in front of Angelina, some put behind her.
<G-vec00187-002-s236><duplicate.duplizieren><de> 17 Der nächste Schritt bleibt komplett euch überlassen: Spielt nun mit dem Feuer, dupliziert es, ein paar Feuer-Ebenen lasst ihr vor der Ebene mit Angelina, ein paar gebt ihr hinter sie.
<G-vec00187-002-s237><duplicate.duplizieren><en> Duplicate Layer Duplicates the currently-selected layer
<G-vec00187-002-s237><duplicate.duplizieren><de> Dupliziert die derzeit ausgewählte Ebene.
<G-vec00187-002-s238><duplicate.duplizieren><en> Duplicate the layer (1), choose the transformation tool (2) and shrink the duplicate as seen on the image from top to bottom (3).
<G-vec00187-002-s238><duplicate.duplizieren><de> Dupliziert die Ebene (1), wählt das Skalieren-Werkzeug (2) und schiebt das Duplikat von oben nach unten etwas zusammen.
<G-vec00187-002-s239><duplicate.duplizieren><en> We’re trying to specifically improve the situation where the template is localized but the main content of a page remains duplicate/identical across language/country variants.
<G-vec00187-002-s239><duplicate.duplizieren><de> Unser Verbesserungsvorschlag bezieht sich auf den konkreten Fall, dass Vorlagen lokalisiert werden, der Haupt-Content der Seite jedoch in den verschiedenen Sprach-/Ländervarianten dupliziert wird und identisch bleibt.
<G-vec00187-002-s240><duplicate.duplizieren><en> Consequently, they cannot duplicate or replicate on other networks to run or replicate again.
<G-vec00187-002-s240><duplicate.duplizieren><de> Folglich können sie nicht in anderen Netzwerken dupliziert oder repliziert werden, um erneut ausgeführt oder repliziert zu werden.
<G-vec00187-002-s241><duplicate.duplizieren><en> Keyline Carat | Flat cylinder keysLearn how to duplicate flat cylinder keys with Keyline Carat.
<G-vec00187-002-s241><duplicate.duplizieren><de> Keyline Carat | Flache ZylinderschlüsselLernen Sie, wie man flache Zylinderschlüssel mit der Carat dupliziert.
<G-vec00187-002-s242><duplicate.duplizieren><en> To duplicate a workspace, select it, and click the New button.
<G-vec00187-002-s242><duplicate.duplizieren><de> Soll ein Arbeitsbereich dupliziert werden, wählen Sie ihn aus und klicken Sie auf die Schaltfläche „Neu“.
<G-vec00187-002-s243><duplicate.duplizieren><en> I couldn't figure out how to only duplicate one clip.
<G-vec00187-002-s243><duplicate.duplizieren><de> Ich konnte nicht herausfinden, wie man nur einen Clip dupliziert.
<G-vec00187-002-s244><duplicate.duplizieren><en> Clicking into a row of the column Block, you may open a popup menu enabling you to duplicate, remove, or insert a new line in the block.
<G-vec00187-002-s244><duplicate.duplizieren><de> Mit einem Klick in eine Zeile der Spalte Block kann ein Kontextmenü geöffnet werden, über das der Block dupliziert, gelöscht oder eine neue Zeile eingefügt werden soll.
<G-vec00187-002-s245><duplicate.duplizieren><en> You can duplicate any layer, including the Background layer, within an image.
<G-vec00187-002-s245><duplicate.duplizieren><de> Jede Ebene, auch die Hintergrundebene, kann innerhalb des jeweiligen Bildes dupliziert werden.
<G-vec00187-002-s246><duplicate.duplizieren><en> A single compressed file containing a collection of files and folders that duplicate a Windows installation on a disk volume.
<G-vec00187-002-s246><duplicate.duplizieren><de> Eine einzelne komprimierte Datei, die eine Sammlung von Dateien und Ordnern enthält, die eine Windows-Installation auf ein Datenträgervolume dupliziert.
<G-vec00187-002-s247><duplicate.duplizieren><en> The duplicate URL should 301 to the preferred URL.
<G-vec00187-002-s247><duplicate.duplizieren><de> Die duplizierte URL sollte per 301-Weiterleitung zur bevorzugten URL führen.
<G-vec00187-002-s248><duplicate.duplizieren><en> Deduplication helps minimize the size of your backups by eliminating redundant duplicate data.
<G-vec00187-002-s248><duplicate.duplizieren><de> Deduplizierung hilft dabei, die Größe Ihrer Sicherungen zu minimieren, indem redundant duplizierte Daten eliminiert werden.
<G-vec00187-002-s249><duplicate.duplizieren><en> In the rare cases in which Google perceives that duplicate content may be shown with intent to manipulate our rankings and deceive our users, we'll also make appropriate adjustments in the indexing and ranking of the sites involved.
<G-vec00187-002-s249><duplicate.duplizieren><de> In den seltenen Fällen, in denen wir annehmen müssen, dass duplizierte Inhalte das Ranking manipulieren oder unsere Nutzer täuschen sollen, nehmen wir außerdem entsprechenden Korrekturen an Index und Ranking der betreffenden Websites vor.
<G-vec00187-002-s250><duplicate.duplizieren><en> Duplicate Files: Allow you to identify and delete duplicate files on disk.
<G-vec00187-002-s250><duplicate.duplizieren><de> Duplicate Files: Sie können duplizierte Dateien identifizieren und löschen.
<G-vec00187-002-s251><duplicate.duplizieren><en> Redundant applications, duplicate data, and a lack of standardization frequently stem from efforts to manage complex infrastructure.
<G-vec00187-002-s251><duplicate.duplizieren><de> Redundante Anwendungen, duplizierte Daten und fehlende Standardisierung stammen häufig von Bemühungen, eine komplexe Infrastruktur zu verwalten.
<G-vec00187-002-s252><duplicate.duplizieren><en> 2 The problem may be the result of mismatched or duplicate IP address.
<G-vec00187-002-s252><duplicate.duplizieren><de> 2 Das Problem kann durch falsch abgestimmte oder duplizierte IP-Adressen verursacht werden.
<G-vec00187-002-s253><duplicate.duplizieren><en> None of the text from any preceding boxes in the story is copied onto the duplicate layer.
<G-vec00187-002-s253><duplicate.duplizieren><de> Es wird kein Text aus vorangehenden Textrahmen in die duplizierte Ebene kopiert.
<G-vec00187-002-s254><duplicate.duplizieren><en> In this case, you may inadvertently create duplicate tags.
<G-vec00187-002-s254><duplicate.duplizieren><de> In diesem Fall können Sie versehentlich duplizierte Tags erstellen.
<G-vec00187-002-s255><duplicate.duplizieren><en> Tap Duplicate. An empty, duplicate track with the same Touch Instrument and track settings appears below the original one.
<G-vec00187-002-s255><duplicate.duplizieren><de> Eine leere, duplizierte Spur mit den gleichen Einstellungen für Touch-Instrument und die Spur selbst wird unterhalb der Originalspur angezeigt.
<G-vec00187-002-s256><duplicate.duplizieren><en> If you'd like, you can move the duplicate product to a new Products Page.
<G-vec00187-002-s256><duplicate.duplizieren><de> Wenn Sie möchten, können Sie das duplizierte Produkt auf eine neue Produkt-Seite verschieben.
<G-vec00187-002-s257><duplicate.duplizieren><en> Repeat for each duplicate email.
<G-vec00187-002-s257><duplicate.duplizieren><de> Wiederholen Sie dies für jedes duplizierte E-Mail.
<G-vec00187-002-s258><duplicate.duplizieren><en> Vi har You are protected against any quality faults of this products caused by the seller (invalid, duplicate keys etc.).
<G-vec00187-002-s258><duplicate.duplizieren><de> Die Produktqualität ist garantiert und das Interesse der Kunden ist geschützt /gegen Probleme wie ungültige, duplizierte Keys, usw, die vom Verkäufer verursacht sind/.
<G-vec00187-002-s259><duplicate.duplizieren><en> If deselected, Lightroom Classic treats the duplicate JPEG as a sidecar file, and the raw file appears with the raw file extension and +jpg.
<G-vec00187-002-s259><duplicate.duplizieren><de> Wenn sie deaktiviert wird, behandelt Lightroom Classic die duplizierte JPEG-Datei als Filialdatei und die Raw-Datei wird mit der Dateierweiterung „raw“ und +jpg angezeigt.
<G-vec00187-002-s260><duplicate.duplizieren><en> The Copy/Paste feature continues to use the workflow where duplicate instances are created and linked back to the original master title clip.
<G-vec00187-002-s260><duplicate.duplizieren><de> Die Funktion Kopieren/Einfügen funktioniert weiterhin mit dem Workflow, wo duplizierte Instanzen erstellt und mit dem Originalnamen des Masterclips erstellt und verknüpft werden.
<G-vec00187-002-s261><duplicate.duplizieren><en> By specifying rel=“alternate” and hreflang=“pt-br” (code for Portuguese and Brazil), Google doesn’t count this “duplicate” content against me.
<G-vec00187-002-s261><duplicate.duplizieren><de> Indem ich rel=“alternate” und hreflang=“pt-br” (Code für Portugiesisch und Brasilien) festlege, indexiert Google meine Seite nicht als “duplizierten” Inhalt.
<G-vec00187-002-s262><duplicate.duplizieren><en> If your site suffers from duplicate content issues, and you don't follow the advice listed above, we do a good job of choosing a version of the content to show in our search results.
<G-vec00187-002-s262><duplicate.duplizieren><de> Falls Ihre Website duplizierten Content enthält und Sie nicht den oben beschriebenen Tipps folgen, tun wir unser Bestes, eine Version des Contents in unseren Suchergebnissen anzuzeigen.
<G-vec00187-002-s263><duplicate.duplizieren><en> To edit your images nondestructively, work on a duplicate layer.
<G-vec00187-002-s263><duplicate.duplizieren><de> Um Ihre Bilder zerstörungsfrei zu bearbeiten, arbeiten Sie auf einer duplizierten Ebene.
<G-vec00187-002-s264><duplicate.duplizieren><en> The main utility that we can get from this tool is to free space from our hard drive thanks to the elimination of duplicate files.
<G-vec00187-002-s264><duplicate.duplizieren><de> Der Hauptvorteil, der in diesem Werkzeug zu finden ist, ist Speicherplatz auf der Festplatte freizumachen, dank der Entfernung von duplizierten Dateien.
<G-vec00187-002-s315><duplicate.verdoppeln><en> You have created policies and set permissions at the user, file, application, storage or cloud level and you don’t want to duplicate your efforts.
<G-vec00187-002-s315><duplicate.verdoppeln><de> Sie haben Richtlinien und vergeben Rechte auf dem Benutzer-, Datei-, Anwendungs-, Speicher- oder Cloud-Level und möchten Ihren Aufwand nicht verdoppeln.
<G-vec00187-002-s316><duplicate.verdoppeln><en> Such a notification would duplicate the one effected by the producer of that article.
<G-vec00187-002-s316><duplicate.verdoppeln><de> Eine solche Mitteilung würde nämlich die vom Produzenten des betreffenden Erzeugnisses gemachte Mitteilung verdoppeln.
<G-vec00187-002-s317><duplicate.verdoppeln><en> According to an article by Lucy Siegle, journalist and writer on environmental issues, "290 million cows are killed per year to cover our current necessities and this numbers could duplicate in the next decade".
<G-vec00187-002-s317><duplicate.verdoppeln><de> Laut einem Artikel von Lucy Siegle, Journalistin und Autorin zu Umweltfragen, "werden 290 Millionen Kühe pro Jahr getötet, um unsere aktuellen Bedürfnisse zu decken, und diese Zahl könnte sich im nächsten Jahrzehnt verdoppeln".
<G-vec00187-002-s318><duplicate.vervielfältigen><en> All clients undertake to observe the Supplier's copyright and safeguard it in the context of their use, and also undertake not to duplicate, transmit or distribute by other means any copyright-protected information, software or other content provided by the Supplier.
<G-vec00187-002-s318><duplicate.vervielfältigen><de> Alle Mandanten verpflichten sich, das Urheberrecht des Anbieters zu beachten, im Rahmen ihrer Nutzung zu sichern und keine vom Anbieter verfügbar gemachten, urheberrechtlich geschützten Informationen, Software oder sonstigen Inhalte zu vervielfältigen, zu übertragen oder anderweitig zu verbreiten.
<G-vec00187-002-s319><duplicate.vervielfältigen><en> Another advantage of our Hornet scanner is that we can duplicate documents that are unsuitable for a sheet-fed scanner.
<G-vec00187-002-s319><duplicate.vervielfältigen><de> Ein weiterer Vorteil unseres "Hornet"-Scanners: Wir können Dokumente vervielfältigen, die nicht mehr für den Durchzugscanner geeignet sind.
<G-vec00187-002-s320><duplicate.vervielfältigen><en> You agree not to reproduce, duplicate, copy, sell, trade, resell or exploit for any commercial purposes, any portion of the Service (including your BigadoNetworks.com, LLC I.D.), use of the Service, or access to the Service.
<G-vec00187-002-s320><duplicate.vervielfältigen><de> Sie dürfen die Services oder Teile davon, ihre Benutzung oder den Zugang zu den Services nicht kopieren, vervielfältigen, nachahmen, verkaufen, weiterverkaufen oder für kommerzielle Zwecke welcher Art auch immer nutzen, soweit es Ihnen nicht ausdrücklich von Impro-theater.de gestattet wurde.
<G-vec00187-002-s321><duplicate.vervielfältigen><en> He is also forbidden to duplicate, copy or modify the delivered hardware and software.
<G-vec00187-002-s321><duplicate.vervielfältigen><de> Ihm ist ferner untersagt, die gelieferte Hard- und Software zu vervielfältigen, zu kopieren oder zu modifizieren.
<G-vec00187-002-s322><duplicate.vervielfältigen><en> Our Customer must not make such documents available to third parties as such nor its contents, nor shall our Customer publish or duplicate such documents without our prior express consent.
<G-vec00187-002-s322><duplicate.vervielfältigen><de> Der Kunde darf diese Unterlagen ohne unsere ausdrückliche Zustimmung weder als solche noch inhaltlich Dritten zugänglich machen, sie bekannt geben oder vervielfältigen.
<G-vec00187-002-s323><duplicate.vervielfältigen><en> The buyer is especially not entitled to duplicate products or make them accessible to third parties.
<G-vec00187-002-s323><duplicate.vervielfältigen><de> Der Käufer ist insbesondere nicht berechtigt, Produkte zu vervielfältigen oder sie Dritten zugänglich zu machen.
<G-vec00187-002-s324><duplicate.vervielfältigen><en> The customer may not make these items available to third parties without the express consent of the seller, either as such or in terms of content, disclose these items, use these items itself or through third parties, or duplicate them.
<G-vec00187-002-s324><duplicate.vervielfältigen><de> Der Kunde darf diese Gegenstände ohne ausdrückliche Zustimmung des Verkäufers weder als solche noch inhaltlich Dritten zugänglich machen, sie bekannt geben, selbst oder durch Dritte nutzen oder vervielfältigen.
<G-vec00187-002-s325><duplicate.vervielfältigen><en> Visitors to the Bardentreffen agree that the organiser – without being obliged to pay any remuneration – has the right to have image and sound recordings of the event made for documentation and for the organiser’s own advertising purposes, to duplicate those recordings, and to broadcast and use them.
<G-vec00187-002-s325><duplicate.vervielfältigen><de> Besucher des Bardentreffens willigen ein, dass der Veranstalter – ohne zur Zahlung einer Vergütung verpflichtet zu sein – berechtigt ist, für Dokumentation und Eigenwerbung Bild- und Tonaufnahmen von der Veranstaltung erstellen zu lassen, diese zu vervielfältigen, zu senden und zu nutzen.
<G-vec00187-002-s326><duplicate.vervielfältigen><en> Seventy-five years ago, Chester Carlson created an easier way to duplicate information on paper.
<G-vec00187-002-s326><duplicate.vervielfältigen><de> Vor 75 Jahren entwickelte Chester Carlson eine einfache Methode, um Schriftstücke zu vervielfältigen.
<G-vec00187-002-s327><duplicate.vervielfältigen><en> The Client may not make these objects as such nor their contents accessible to third parties and may not make them known nor use or duplicate them himself or through a third party.
<G-vec00187-002-s327><duplicate.vervielfältigen><de> Der Auftraggeber darf diese Gegenstände ohne unsere ausdrückliche Zustimmung weder als solche noch inhaltlich Dritten zugänglich machen, sie bekannt geben, selbst oder durch Dritte nutzen oder vervielfältigen.
<G-vec00187-002-s328><duplicate.vervielfältigen><en> Also for 12 months following the end of the contract, the Customer shall be obliged to treat in the strictest confidence all commercial and technical information which it receives from Surplex, in particular the personal data of other Customers and all information concerning the Objects, unless such information is generally known (without the Customer being responsible for such) and shall not use such or duplicate such information for purposes other than the fulfilment of the contract or make it accessible to third parties.
<G-vec00187-002-s328><duplicate.vervielfältigen><de> Der Kunde verpflichtet sich, alle geschäftlichen und technischen Informationen, die er von Surplex erhält, insbesondere die persönlichen Daten anderer Kunden und alle Informationen über die Objekte, soweit und solange sie nicht allgemein bekannt sind (ohne dass der Kunde dies zu vertreten hätte), auch 12 Monate über das Ende des Vertrages hinaus, streng vertraulich zu behandeln und weder für andere Zwecke als die Vertragserfüllung zu verwenden, zu vervielfältigen noch Dritten zugänglich zu machen.
<G-vec00187-002-s329><duplicate.vervielfältigen><en> modifying of the text. Permitted Copies. You may not duplicate or copy the Font Software except as needed to use it as
<G-vec00187-002-s329><duplicate.vervielfältigen><de> Sie dürfen die Schriftsoftware nur vervielfältigen oder kopieren, wenn es notwendig ist, um sie wie in diesem Vertrag ausdrücklich genehmigt zu nutzen.
<G-vec00187-002-s330><duplicate.vervielfältigen><en> You agree not to reproduce, duplicate, copy, sell, resell or exploit any portion of the Service, use of the Service, or access to the Service or any contact on the website through which the service is provided, without express written permission by us.
<G-vec00187-002-s330><duplicate.vervielfältigen><de> Sie erklären sich damit einverstanden, keinen Teil des Dienstes, die Nutzung des Dienstes oder den Zugang zum Service oder einen Kontakt, bei dem der Service erbracht wird, ohne vorherige schriftliche Zustimmung von uns wiederzugeben, zu vervielfältigen, zu kopieren, zu verkaufen, wiederzuverkaufen oder zu verwerten.
<G-vec00187-002-s331><duplicate.vervielfältigen><en> The functionality that is unique to Smart 3D allowed us to reuse major portions of plant models to duplicate several units of the projects.
<G-vec00187-002-s331><duplicate.vervielfältigen><de> Die einzigartigen Funktionen von Smart 3D haben es uns ermöglicht, große Teile des Anlagenmodells wiederzuverwenden und so verschiedene Baulose zu vervielfältigen.
<G-vec00187-002-s332><duplicate.vervielfältigen><en> In particular, the user is not authorized to "reverse engineer", decompile, disassemble, duplicate or use any part of the PORTAL to create a separate application or software.
<G-vec00187-002-s332><duplicate.vervielfältigen><de> Der Nutzer ist insbesondere nicht berechtigt, das PORTAL zu „reverse engineeren“, zu dekompilieren, zu disassemblieren, zu vervielfältigen oder jeglichen Teil des PORTALs zu benutzen, um eine separate Applikation oder Software zu erstellen.
<G-vec00187-002-s333><duplicate.vervielfältigen><en> Not to reproduce, duplicate, copy or re-sell any part of our site in contravention of the provisions of these terms.
<G-vec00187-002-s333><duplicate.vervielfältigen><de> • Einen Teil unserer Website nicht zu reproduzieren, zu vervielfältigen, zu kopieren oder weiter zu verkaufen, entgegen den Bestimmungen unserer Nutzungsbedingungen für die Website.
<G-vec00187-002-s334><duplicate.vervielfältigen><en> You are not allowed to change, copy, distribute, transfer, exhibit, demonstrate, duplicate, publish, license, establish derived work, convey or sell information, software, products or services receiving through this website.
<G-vec00187-002-s334><duplicate.vervielfältigen><de> Sie dürfen Informationen, Software, Produkte oder Serviceleistungen, die Sie über diese Webseite erhalten, nicht verändern, kopieren, vertreiben, übertragen, ausstellen, vorführen, vervielfältigen, veröffentlichen, lizenzieren, davon keine abgeleiteten Werke erstellen und nicht abtreten oder verkaufen.
<G-vec00187-002-s335><duplicate.vervielfältigen><en> The Supplier may not make them accessible to a third party or use them himself or allow them to be used by a third party or duplicate them without our express approval.
<G-vec00187-002-s335><duplicate.vervielfältigen><de> Der Lieferant darf sie ohne unsere ausdrückliche Zustimmung weder Dritten zugänglich machen noch selbst oder durch Dritte nutzen oder vervielfältigen.
<G-vec00187-002-s336><duplicate.vervielfältigen><en> The User is not authorised to duplicate and/or pass CASIO product images onto third parties.
<G-vec00187-002-s336><duplicate.vervielfältigen><de> Der Nutzer ist nicht berechtigt, die CASIO Produktabbildungen zu vervielfältigen und/oder an Dritte zu versenden.
<G-vec00187-002-s337><duplicate.vervielfältigen><en> Prior written permission is required to change, copy, duplicate, sell, lease, use, and supplement information, brand names and other content of this website, or to utilize it in a different way.
<G-vec00187-002-s337><duplicate.vervielfältigen><de> Informationen, Markennamen und sonstige Inhalte dieser Website dürfen ohne vorherige schriftliche Genehmigung weder verändert, kopiert, vervielfältigt, verkauft, vermietet, genutzt, ergänzt oder sonst wie verwertet werden.
<G-vec00187-002-s338><duplicate.vervielfältigen><en> The customer shall not duplicate and/or provide these to third parties.
<G-vec00187-002-s338><duplicate.vervielfältigen><de> Sie dürfen vom Kunden nicht vervielfältigt und/oder Dritten zugänglich gemacht werden.
<G-vec00187-002-s339><duplicate.vervielfältigen><en> It is not permissible to duplicate the contents in any form, completely or partially, to relay and/or publish or store the contents in an information system without prior written authorisation of the originator.
<G-vec00187-002-s339><duplicate.vervielfältigen><de> Die Inhalte dürfen weder ganz noch teilweise ohne vorherige schriftliche Genehmigung des Urhebers vervielfältigt, weitergegeben und/oder veröffentlicht oder in einem Informationssystem gespeichert werden.
<G-vec00187-002-s340><duplicate.vervielfältigen><en> You may not retransmit, reproduce, duplicate, copy, sell, resell or otherwise exploit the content on this site for commercial use unless we provide you with prior written permission to do so.
<G-vec00187-002-s340><duplicate.vervielfältigen><de> Der Inhalt dieser Website darf nur mit unserer vorherigen schriftlichen Genehmigung neu übertragen, reproduziert, vervielfältigt, kopiert, verkauft, weiterverkauft oder anderweitig für kommerzielle Zwecke genutzt werden.
<G-vec00187-002-s341><duplicate.vervielfältigen><en> It is forbidden to copy, duplicate or distribute the documents for commercial purposes.
<G-vec00187-002-s341><duplicate.vervielfältigen><de> Zu kommerziellen Zwecken dürfen diese nicht kopiert, vervielfältigt oder verbreitet werden.
<G-vec00187-002-s342><duplicate.vervielfältigen><en> You may not modify, edit, exploit, duplicate, transfer to third parties, make available to the public or otherwise distribute the Map Data.
<G-vec00187-002-s342><duplicate.vervielfältigen><de> Das Kartenmaterial darf von Dir nicht geändert, bearbeitet, verwertet, vervielfältigt, auf Dritte übertragen, öffentlich zugänglich gemacht oder anderweitig vertrieben werden.
<G-vec00187-002-s343><duplicate.vervielfältigen><en> Since the copyright and right of use for pictures, texts, graphics etc belong to Mir Tours & Services, it is not permitted to changem publish, give away or duplicate the website or its contents.
<G-vec00187-002-s343><duplicate.vervielfältigen><de> Da die Urheber-und Nutzungsrechte an allen Bildern, Texten und Grafiken Mir Tours & Services gehören, darf die Webseite von Mir Tours & Services sowie ihr Inhalt vom Nutzer nicht verändert, veröffentlicht, verkauft, weitergegeben oder vervielfältigt werden.
