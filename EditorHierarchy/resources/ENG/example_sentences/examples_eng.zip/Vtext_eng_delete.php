<G-vec00962-002-s076><delete.entfernen><en> Thus, you are able to block and/or delete the cookies installed on your device at any time.
<G-vec00962-002-s076><delete.entfernen><de> Daher können Sie die auf Ihrem Gerät installierten Cookies jederzeit genehmigen, sperren und/oder entfernen.
<G-vec00962-002-s077><delete.entfernen><en> Please try to logout in order to delete all cookies.
<G-vec00962-002-s077><delete.entfernen><de> Auch können Sie es versuchen sich auszuloggen, um die Cookies zu entfernen.
<G-vec00962-002-s078><delete.entfernen><en> You may at any time can exercise your right to deactivate or delete cookies from this website.
<G-vec00962-002-s078><delete.entfernen><de> Sie können jederzeit Ihren Anspruch ausüben, die Cookies dieser Webseite auszuschalten oder zu entfernen.
<G-vec00962-002-s079><delete.entfernen><en> If you are not willing to use the Licensed Software, either the Free Edition or the Standard/Professional/Enterprise Edition, after the Evaluation Period, delete all the copies installed in your computer with immediate effect.
<G-vec00962-002-s079><delete.entfernen><de> Wenn Sie die Lizenzierte Software, also entweder die Free Edition oder Standard/Professional/Enterprise Edition, nach dem Testzeitraum nicht weiterverwenden möchten, entfernen Sie bitte die Software mit sofortiger Wirkung von Ihrem Computer.
<G-vec00962-002-s080><delete.entfernen><en> When an according violation of law has come to our knowledge, we will delete this content anon.
<G-vec00962-002-s080><delete.entfernen><de> Bei Bekanntwerden von entsprechenden Rechtsverletzungen werden wir diese Inhalte umgehend entfernen.
<G-vec00962-002-s081><delete.entfernen><en> detection of relevant infringements of law we will immediately delete respective contents and links.
<G-vec00962-002-s081><delete.entfernen><de> Bei Bekanntwerden von entsprechenden Rechtsverletzungen werden wir entsprechende Inhalte und Links umgehend entfernen.
<G-vec00962-002-s082><delete.entfernen><en> You will be prompted to type the word "delete" to confirm your operation.
<G-vec00962-002-s082><delete.entfernen><de> Sie müssen anschließend das Word "Entfernen" eingeben, um die Aktion zu bestätigen.
<G-vec00962-002-s083><delete.entfernen><en> To delete a playlist on the Android app, tap the three horizontal dots underneath the playlist to bring up the menu. From there you can select ‘Delete playlist’.
<G-vec00962-002-s083><delete.entfernen><de> Um einen Track aus der Playlist zu entfernen, gehe auf die Playlist Seite in der SoundCloud App und tippe auf die drei horizontalen Punkte rechts neben dem Track.
<G-vec00962-002-s084><delete.entfernen><en> Set a new default search engine and delete Swagbucks Customized Web Search.
<G-vec00962-002-s084><delete.entfernen><de> Festlegen Sie eine neue Standard-Suchmaschine und entfernen Sie Amazon Smart Search.
<G-vec00962-002-s085><delete.entfernen><en> In addition, you can also delete all information previously saved via the settings of your browser.
<G-vec00962-002-s085><delete.entfernen><de> Außerdem können Sie auch alle Informationen, die bereits zu einem früheren Zeitpunkt gespeichert wurden, über die Einstellungen Ihres Browsers entfernen.
<G-vec00962-002-s086><delete.entfernen><en> Delete individual filters or procedures by using the Delete function displayed next to each selected option.
<G-vec00962-002-s086><delete.entfernen><de> Einzelne Filter und Aktionen entfernen Sie über die Funktion Löschen, die neben jeder ausgewählten Option angezeigt wird.
<G-vec00962-002-s087><delete.entfernen><en> + Add item to watch list - Delete item from watch list
<G-vec00962-002-s087><delete.entfernen><de> + Zur Merkliste hinzufügen - Von Merkliste entfernen DIPL.
<G-vec00962-002-s088><delete.entfernen><en> Find the registry entries associated with [email protected] Ransomware and Delete them Manually.
<G-vec00962-002-s088><delete.entfernen><de> Finden Sie die Registrierungseinträge mit [email protected] Ransomware und Entfernen Sie Erfolgreich.
<G-vec00962-002-s089><delete.entfernen><en> In order to still be able to import the product, we can click on the Related button to edit the raw data and, for example, correct or delete the URL.
<G-vec00962-002-s089><delete.entfernen><de> Um das Produkt dennoch zu importieren, können wir mit einem Klick auf den Related-Button die Rohdaten bearbeiten und beispielsweise die URL korrigieren oder entfernen.
<G-vec00962-002-s090><delete.entfernen><en> If you encounter on our website links or references that violate legal provisions or lead to contents that violate legal provisions, please report this to us so that we can delete the link or reference to the corresponding site.
<G-vec00962-002-s090><delete.entfernen><de> Sollten Sie Hinweise oder Links auf unseren Internetseiten finden, die gegen Rechtsvorschriften verstoßen oder auf Inhalte verweisen, die gegen Rechtsvorschriften verstoßen, so bitten wir Sie um einen entsprechenden Hinweis, um diese Hinweise oder Links zu entfernen.
<G-vec00962-002-s091><delete.entfernen><en> You can delete individual content from this list.
<G-vec00962-002-s091><delete.entfernen><de> Sie können einzelne Inhalte aus dieser Liste entfernen.
<G-vec00962-002-s092><delete.entfernen><en> Decide which key combination creates the Ctrl+Alt+Delete combination on the remote virtual desktop.
<G-vec00962-002-s092><delete.entfernen><de> Entscheiden Sie, welche Tastenkombination Strg+Alt+Entfernen auf dem remoten virtuellen Desktop generieren soll.
<G-vec00962-002-s093><delete.entfernen><en> Virus Delete Crypto-Loot Miner from Internet Explorer, Delete Crypto-Loot Miner from Windows 8, How to Delete Crypto-Loot Miner, Remove Crypto-Loot Miner from Internet Explorer, Remove Crypto-Loot Miner from Safari, Remove Crypto-Loot Miner from Windows 7, Remove Crypto-Loot Miner from Windows 8
<G-vec00962-002-s093><delete.entfernen><de> This entry was posted in Uncategorized and tagged Deinstallieren Sie Coin Miner von Windows 10, Deinstallieren Sie Coin Miner von Windows 7, Deinstallieren Sie Coin Miner von Windows 8, Entfernen Sie Coin Miner, Loschen Sie Coin Miner aus Windows 7, Schritte zum Entfernen von Coin Miner on December 27, 2017 by rimuoverespyware.
<G-vec00962-002-s094><delete.entfernen><en> Delete From Model See for a full description Section 10.4.3, “ Delete From Model”.
<G-vec00962-002-s094><delete.entfernen><de> Aus Modell entfernen Siehe vollständige Beschreibung unter Abschnitt 10.4.3, „ Aus Modell entfernen “.
<G-vec00962-002-s095><delete.löschen><en> Please consult your Internet browser’s documentation for information on how to do this and how to delete persistent cookies.
<G-vec00962-002-s095><delete.löschen><de> Rufen Sie hierfür die Dokumentation Ihres Internetbrowsers für die Informationen, wie Cookies und Persistent-Cookies gelöscht werden können, ab.
<G-vec00962-002-s096><delete.löschen><en> Note: You cannot delete a Paper Catalog entry if it is being used by a job, virtual printer, or preset.
<G-vec00962-002-s096><delete.löschen><de> Hinweis: Ein Paper Catalog-Eintrag kann nicht gelöscht werden, wenn er von einem Auftrag, einem virtuellen Drucker oder einer Vorgabe verwendet wird.
<G-vec00962-002-s097><delete.löschen><en> All users can see, edit, or delete their personal information at any time (except they cannot change their username).
<G-vec00962-002-s097><delete.löschen><de> Deine persönlichen Informationen können jederzeit von dir eingesehen, verändert oder gelöscht werden (der Username kann nicht verändert werden).
<G-vec00962-002-s098><delete.löschen><en> Because of this, after you delete information from our services, we may not immediately delete residual copies from our active servers and may not remove information from our backup systems.
<G-vec00962-002-s098><delete.löschen><de> Aus diesem Grund löscht Google möglicherweise verbliebene Vervielfältigungsstücke von Daten, die Sie aus Google-Diensten gelöscht haben, nicht sofort von deren aktiven Servern und entfernen diese Daten nicht von deren Sicherungssystemen.
<G-vec00962-002-s099><delete.löschen><en> Once the photos are stored on the computer, you can delete them from the memory card.
<G-vec00962-002-s099><delete.löschen><de> Sobald die Fotos auf dem Computer gespeichert wurden, können sie von der Speicherkarte gelöscht werden.
<G-vec00962-002-s100><delete.löschen><en> From the same editor, you can create a page or delete the current page using the + and - buttons.
<G-vec00962-002-s100><delete.löschen><de> Mit den Knöpfen + und - kann vom Editor aus eine Seite erstellt oder die aktuelle Seite gelöscht werden.
<G-vec00962-002-s101><delete.löschen><en> With Subversion, you can add, - delete, copy, and rename both files and directories.
<G-vec00962-002-s101><delete.löschen><de> Mit Subversion - können sowohl Dateien als auch Verzeichnisse - hinzugefügt, gelöscht, kopiert und umbenannt werden.
<G-vec00962-002-s102><delete.löschen><en> Edit (Add, Delete or Change) any of the information and Save your changes.
<G-vec00962-002-s102><delete.löschen><de> Bearbeiten (Hinzugefügt, gelöscht oder geändert) beliebige Informationen und Speichern Sie Ihre Änderungen.
<G-vec00962-002-s103><delete.löschen><en> Doing a soft reset will not delete any personal data, files or apps on your iPad mini.
<G-vec00962-002-s103><delete.löschen><de> Durch einen Warmstart werden keine persönlichen Daten, Dateien oder Apps von Ihrem iPad mini gelöscht.
<G-vec00962-002-s104><delete.löschen><en> Cookies are small data files stored on the hard drive of your computer or mobile device by a website. We may use both session cookies (which expire once you close your web browser) and persistent cookies (which stay on your computer or mobile device until you delete them) to provide you with a more personal and interactive experience on our website.
<G-vec00962-002-s104><delete.löschen><de> Session-Cookies werden nur für die Dauer Ihres Besuchs auf einer Website gespeichert und beim Schließen Ihres Browsers von Ihrem Gerät gelöscht; Dauerhafte Cookies werden nach dem Schließen des Browsers für einen bestimmten Zeitraum auf Ihrem Gerät gespeichert und werden dort verwendet, wo wir (oder ein Dritter) Sie für eine spätere Browsersitzung identifizieren müssen.
<G-vec00962-002-s105><delete.löschen><en> Nevertheless, we shall delete such external links immediately as soon as we become aware of any legal violations.
<G-vec00962-002-s105><delete.löschen><de> Bei Kenntnis von Rechtsverstößen werden jedoch derartige externe Links unverzüglich gelöscht.
<G-vec00962-002-s106><delete.löschen><en> We delete or anonymize personal data when it is no longer needed for the purposes it has been collected for.
<G-vec00962-002-s106><delete.löschen><de> Persönliche Daten werden laufend gelöscht oder anonymisiert, wenn die Zwecke, zu denen sie erfasst wurden, nicht mehr vorhanden sind.
<G-vec00962-002-s107><delete.löschen><en> Agree to the warning messages as it will delete the existing WhatsApp data on the target device.
<G-vec00962-002-s107><delete.löschen><de> Stimmen Sie den Warnmeldungen zu, da die vorhandenen WhatsApp-Daten auf dem Zielgerät gelöscht werden.
<G-vec00962-002-s108><delete.löschen><en> The data subject can at any time cancel delivery of a white paper and delete the profile which has been set up.
<G-vec00962-002-s108><delete.löschen><de> Der Bezug des Whitepapers kann durch den betroffenen Nutzer jederzeit gekündigt und das angelegte Profil gelöscht werden.
<G-vec00962-002-s109><delete.löschen><en> After that delete the .cat and .dat of this modification.
<G-vec00962-002-s109><delete.löschen><de> Zuletzt muss nur noch die .cat und die .dat dieser Modifikation gelöscht werden.
<G-vec00962-002-s110><delete.löschen><en> Deleting these older project and event files after a successful update does not delete original media.
<G-vec00962-002-s110><delete.löschen><de> Wenn Sie die älteren Projekt- und Ereignisdateien nach der erfolgreichen Aktualisierung löschen, werden die Originalmedien nicht gelöscht.
<G-vec00962-002-s111><delete.löschen><en> You cannot delete a resource pool if vShield Edge is installed on it.
<G-vec00962-002-s111><delete.löschen><de> Ein Ressourcenpool kann nicht gelöscht werden, wenn vShield Edge darin installiert ist.
<G-vec00962-002-s112><delete.löschen><en> The user must use the content and information contained on hotelcortijosantacruz.es in a diligent, correct and lawful manner, and specifically, only for personal use and not commercial, provided that they do not delete or amend the content or any mention of sources, copyrights and other information that identifies the rights of Cortijo Santa Cruz or of third parties, that is, respecting its original form.
<G-vec00962-002-s112><delete.löschen><de> Der Nutzer ist verpflichtet, die auf hotelcortijosantacruz.es gespeicherten Inhalte und Informationen sorgfältig, korrekt und rechtmäßig zu verwenden, insbesondere nur für den persönlichen und nicht kommerziellen Gebrauch, vorausgesetzt, dass der Inhalt oder jegliche Erwähnung von Quellen, Urheberrechten und anderen Daten, die die Rechte von Cortijo Santa Cruz oder Dritten bezeichnen, nicht gelöscht oder verändert wird, das heißt, unter Beachtung der ursprünglichen Form.
<G-vec00962-002-s113><delete.löschen><en> These files (Cookies) are automatically accepted by the majority of browsers, however you can delete them, or automatically define their blocking.
<G-vec00962-002-s113><delete.löschen><de> Diese Dateien (Cookies) werden von den meisten Browsern automatisch akzeptiert, können jedoch gelöscht oder automatisch blockiert werden.
<G-vec00962-002-s114><delete.löschen><en> Delete the Bionicle application icon that was in that folder previously.
<G-vec00962-002-s114><delete.löschen><de> Lösche das Bionicle Programm-Icon, das sich vorher in diesem Ordner befand.
<G-vec00962-002-s115><delete.löschen><en> Don't waste any time and delete watermarks, both from text and image files with We PDF Watermark Remover.
<G-vec00962-002-s115><delete.löschen><de> Verschwende keine Zeit und lösche Wasserzeichen, sowohl aus Texten wie auch aus Bildern mit We PDF Watermark Remover.
<G-vec00962-002-s116><delete.löschen><en> If that Cat Stevens song wasn't as relaxing as you wanted it to be, delete it and go softer.
<G-vec00962-002-s116><delete.löschen><de> Wenn dieses Lied von Cat Stevens nicht so entspannend war, wie du dachtest, lösche es und wähle etwas leiseres.
<G-vec00962-002-s117><delete.löschen><en> Delete a symbol from the currently selected library or any library defined by the project if no library is currently selected.
<G-vec00962-002-s117><delete.löschen><de> Lösche ein Bauteile aus der aktuell ausgewählten Bibliothek oder jeder anderen durch das Projekt festgelegten Bibliothek, wenn aktuell keine Bibliothek ausgewählt ist.
<G-vec00962-002-s118><delete.löschen><en> If you want me to delete both files and keep the secret, you must send me the Bitcoin payment.
<G-vec00962-002-s118><delete.löschen><de> Wenn Sie möchten, dass ich beide Dateien lösche und das Geheimnis bewahre, müssen Sie mir eine Bitcoin-Zahlung senden.
<G-vec00962-002-s119><delete.löschen><en> To solve this delete the BE Service directory (usually “C:\Program Files (x86)\Common Files\BattlEye”) and then try to launch your game again.
<G-vec00962-002-s119><delete.löschen><de> Um das zu beheben, lösche das BE Service Verzeichnis (normalerweise „C:\Program Files (x86)\Common Files\BattlEye”) und dann versuche das Spiel neu zu starten.
<G-vec00962-002-s120><delete.löschen><en> Somehow I never delete my pictures and I rather organize them in 123423 folders instead of deleting them.
<G-vec00962-002-s120><delete.löschen><de> Ich lösche irgendwie nie was und organisiere meine Bilder lieber in 12028 Ordnern anstatt welche zu löschen.
<G-vec00962-002-s121><delete.löschen><en> • Add, delete, and save Microsoft Exchange Notes and Tasks anytime.
<G-vec00962-002-s121><delete.löschen><de> • Füge hinzu, lösche und sichere Microsoft Exchange Notizen und Aufgaben zu jeder Zeit.
<G-vec00962-002-s122><delete.löschen><en> If you want to take out a sentence in the middle of a paragraph, simply highlight and delete.
<G-vec00962-002-s122><delete.löschen><de> Wenn du einen Satz inmitten eines Absatzes herausgreifen willst, markiere einfach und lösche.
<G-vec00962-002-s123><delete.löschen><en> Now, open Explorer and browse to the Packs and User Library locations you wrote down previously and delete them.
<G-vec00962-002-s123><delete.löschen><de> Öffnen nun Explorer und suche die Packs und User Library Verzeichnisse, die Du Dir weiter oben aufgeschrieben hattest, und lösche sie.
<G-vec00962-002-s124><delete.löschen><en> Delete Chrome history on your mobile device.
<G-vec00962-002-s124><delete.löschen><de> Lösche den Verlauf von Chrome auf deinem mobilen Gerät.
<G-vec00962-002-s125><delete.löschen><en> 1) delete the file IPHLPAPI.DLL from Darkstar's folder,
<G-vec00962-002-s125><delete.löschen><de> 1) Lösche die Datei IPHLPAPI.DLL aus dem Darkstar-Verzeichnis.
<G-vec00962-002-s126><delete.löschen><en> | I usually delete emails from The Outnet right away.
<G-vec00962-002-s126><delete.löschen><de> | Normalerweise lösche ich Emails von The Outnet immer sofort.
<G-vec00962-002-s127><delete.löschen><en> Edit or delete it, then start writing! GinoKelleners
<G-vec00962-002-s127><delete.löschen><de> Bearbeite oder lösche ihn und beginne mit dem Schreiben!...
<G-vec00962-002-s128><delete.löschen><en> Delete any and all plugins you’re not using, especially if the creators haven’t updated them for several months.
<G-vec00962-002-s128><delete.löschen><de> Lösche alle Plugins, die du nicht verwendest, insbesondere, wenn die Ersteller sie seit mehreren Monaten nicht aktualisiert haben.
<G-vec00962-002-s129><delete.löschen><en> Delete pornographic files on your computer and mobile devices.
<G-vec00962-002-s129><delete.löschen><de> Lösche alle pornografischen Dateien auf deinem Computer und deinem Mobilgerät.
<G-vec00962-002-s131><delete.löschen><en> We delete the data that arises in this context after the storage is no longer required, or limit the processing if there are statutory retention requirements.
<G-vec00962-002-s131><delete.löschen><de> Die in diesem Zusammenhang anfallenden Daten lösche ich, nachdem die Speicherung nicht mehr erforderlich ist.
<G-vec00962-002-s132><delete.löschen><en> “Simple Local Avatars” Fixed: Do not delete avatars just because they don’t exist on the local filesystem.
<G-vec00962-002-s132><delete.löschen><de> 2.1.1 Gefixt: Lösche keine Avatare, nur weil sie nicht auf dem lokalen Dateisystem vorhanden sind.
<G-vec00962-002-s133><delete.löschen><en> 3.6 WINDSOURCING.COM GmbH has the right to delete inactive accounts if they have not been used for more than one year after once-off prior notification.
<G-vec00962-002-s133><delete.löschen><de> 3.6 Die WINDSOURCING.COM GmbH ist berechtigt, inaktive Accounts bei Nichtbenutzung über einen Zeitraum von länger als einem Jahr nach einmaliger Vorankündigung zu löschen.
<G-vec00962-002-s134><delete.löschen><en> 33 Deleting or Copying Images At Once Specify images by a shooting month, and delete them or copy them to a card at once.
<G-vec00962-002-s134><delete.löschen><de> 33 Mehrere Bilder auf einmal löschen oder kopieren Sie können mehrere Bilder nach Aufnahmemonat auflisten und sie gleichzeitig löschen oder auf eine Karte kopieren.
<G-vec00962-002-s135><delete.löschen><en> Of course, you should also delete these emails without any further response.
<G-vec00962-002-s135><delete.löschen><de> Selbstverständlich sollen Sie auch diese Mails löschen, ohne darauf zu antworten.
<G-vec00962-002-s136><delete.löschen><en> Permanent cookies are automatically deleted from your computer when their expiry date is reached or when you delete them yourself before the expiry date.
<G-vec00962-002-s136><delete.löschen><de> Permanente Cookies werden automatisch von Ihrem Computer gelöscht, wenn deren Geltungsdauer (im Regelfall sechs Monate) erreicht ist oder Sie diese vor Ablauf der Geltungsdauer selbst löschen.
<G-vec00962-002-s137><delete.löschen><en> It is not necessary to manually delete KService::Ptrs, because they are reference counted.
<G-vec00962-002-s137><delete.löschen><de> Daher ist es nicht notwendig einen KService::Ptr von Hand zu löschen, da sie einen eingebauten Referenzzähler haben.
<G-vec00962-002-s138><delete.löschen><en> (3) The customer always has the option to retrieve the data stored by him under the button “My Account” in his profile, change or delete this.
<G-vec00962-002-s138><delete.löschen><de> (3) Der Kunde hat jederzeit die Möglichkeit, die von ihm gespeicherten Daten unter dem Button „Meine Daten“ in seinem Profil abzurufen, dieses zu ändern oder zu löschen.
<G-vec00962-002-s139><delete.löschen><en> The author reserves the right to change, supplement, delete or unpublish any or all the pages without further notice. 2.
<G-vec00962-002-s139><delete.löschen><de> Der Autor behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00962-002-s140><delete.löschen><en> The Licensor shall be free to delete any corresponding data of the Licensee’s, irrevocably and without prior notice, upon such a termination of the Agreement.
<G-vec00962-002-s140><delete.löschen><de> Der Lizenzgeberin steht es frei bei Beendigung entsprechende Daten der Lizenznehmerin unwiderruflich und ohne vorherige Mitteilung zu löschen.
<G-vec00962-002-s141><delete.löschen><en> The Manage accounts options allow you to add, delete, and change the e-mail settings.
<G-vec00962-002-s141><delete.löschen><de> Mit den Optionen unter Konten verwalten können Sie E-MailEinstellungen hinzufügen, löschen und ändern.
<G-vec00962-002-s142><delete.löschen><en> Piezīme. To delete a drawing markup, select it and press Delete.
<G-vec00962-002-s142><delete.löschen><de> Um eine Zeichenmarkierung zu löschen, wählen Sie sie aus und drücken Sie die Entf-Taste.
<G-vec00962-002-s143><delete.löschen><en> If you would like to request to review, correct, update, suppress, delete or otherwise limit our use of your Personal Data that has been previously provided to us, or if you would like to request to receive an electronic copy of your Personal Data for purposes of transmitting it to another company (to the extent this right to data portability is provided to you by applicable law), you may make a request by contacting us using the information provided in the “Contact Information for Bureau van Dijk” below.
<G-vec00962-002-s143><delete.löschen><de> Wenn Sie Ihre personenbezogenen Daten überprüfen, korrigieren, aktualisieren, beschränken oder löschen möchten oder wenn Sie eine elektronische Kopie Ihrer personenbezogenen Daten anfordern möchten, zum Zweck der Übermittlung an ein anderes Unternehmen (soweit Ihnen diese Rechte durch geltendes Recht zur Verfügung gestellt werden), kontaktieren Sie uns bitte per Kontaktformular.
<G-vec00962-002-s144><delete.löschen><en> 11.3 You may delete Cookies, however you may loose any information that enables you to access the Web Site more quickly.
<G-vec00962-002-s144><delete.löschen><de> 11.3 Sie können die Cookies jederzeit löschen, allerdings können Sie dadurch Informationen verlieren, die Ihnen einen schnelleren Zugriff auf die Webseite ermöglichen.
<G-vec00962-002-s145><delete.löschen><en> Configure access permissions for the Protected file types category for applications with high and low restrictions by blocking Write, Delete and Create actions.
<G-vec00962-002-s145><delete.löschen><de> Legen Sie für die Kategorie Zu schützende Dateitypen die Zugriffsregeln für Programme aus den Gruppen mit starken und schwachen Beschränkungen fest, indem Sie Schreiben, Löschen und Erstellen verbieten.
<G-vec00962-002-s146><delete.löschen><en> You will still be able to log on to a gated digital property if you decline or delete the persistent cookie that enables automatic recognition but you will need to log on each time.
<G-vec00962-002-s146><delete.löschen><de> Sie werden sich immer noch in eine geschlossene Community einloggen können, wenn Sie unseren dauerhaften Cookie ablehnen oder löschen, mit dem die automatische Erkennung aktiviert wird.
<G-vec00962-002-s147><delete.löschen><en> To delete Messages, go to: Your Account > Inbox Find the conversation you want to delete and check it, t...
<G-vec00962-002-s147><delete.löschen><de> Um Nachrichten zu löschen, gehen Sie zu: Ihr Konto > Inbox Suchen Sie die E-Mail-Konversation, die Sie lös...
<G-vec00962-002-s148><delete.löschen><en> To delete Safe Finder Virus and fix redirection issue, you must opt an immediate browser hijacker removal guide.
<G-vec00962-002-s148><delete.löschen><de> Um Safe Finder Virus zu löschen und das Umleitungsproblem zu beheben, müssen Sie sich für eine sofortige Anleitung zum Entfernen des Browser-Hijackers entscheiden.
<G-vec00962-002-s149><delete.löschen><en> If you decide to leave Match Ourself because you have found someone or just want to have a break you can delete your profile by going to Profile >> Account details and click on the Remove account button.
<G-vec00962-002-s149><delete.löschen><de> Solltest Du Dich dazu entschieden, Bunga-Bunga.de zu verlassen weil Du entweder jemanden gefunden hast oder einfach nur eine Pause willst, kannst Du Dein Profil löschen, indem Du zu Profil >> Kontoeinzelheiten gehst dort auf „Konto entfernen“ drückst.
<G-vec00962-002-s150><delete.löschen><en> You may change your cookie preferences or delete them at any time.
<G-vec00962-002-s150><delete.löschen><de> Sie können Ihre Cookie-Einstellungen jederzeit ändern oder löschen.
<G-vec00962-002-s151><delete.löschen><en> Tap the picture(s) you want to delete.
<G-vec00962-002-s151><delete.löschen><de> Tippe jedes Foto an, das du löschen möchtest.
<G-vec00962-002-s152><delete.löschen><en> Like Signal, Telegram offers the ability to automatically delete a message after a certain time.
<G-vec00962-002-s152><delete.löschen><de> Genau wie bei Signal kannst Du die Nachrichten nach einer bestimmten Zeit automatisch löschen lassen.
<G-vec00962-002-s153><delete.löschen><en> You can delete all other data including your user account data.
<G-vec00962-002-s153><delete.löschen><de> Alle weiteren Daten, inklusive Ihres Nutzerkontos, können Sie löschen lassen.
<G-vec00962-002-s154><delete.löschen><en> You have the right to know which of your personal data we have stored and which ones are being processed, to request to update or correct it, as well as in cases provided for by the law, to delete it, and to restrict or object to the processing even after you have provided your explicit consent.
<G-vec00962-002-s154><delete.löschen><de> Sie haben das Recht zu erfahren, welche Ihrer personenbezogenen Daten wir gespeichert haben und welche verarbeitet werden, ihre Aktualisierung oder Korrektur zu verlangen sowie in den gesetzlich vorgesehenen Fällen, sie löschen und die Verarbeitung einschränken zu lassen oder ihr zu widersprechen, selbst nachdem Sie Ihre ausdrückliche Einwilligung erteilt haben.
<G-vec00962-002-s155><delete.löschen><en> In addition, any time you can lock, rectify or delete their data collected with us.
<G-vec00962-002-s155><delete.löschen><de> Darüber hinaus können Sie jederzeit ihre bei uns erhobenen Daten sperren, berichtigen oder löschen lassen.
<G-vec00962-002-s156><delete.löschen><en> You can always lock your data we have collected, correct or delete and object to the anonymous or pseudonymous data collection and storage for optimization of our website.
<G-vec00962-002-s156><delete.löschen><de> Sie können jederzeit Ihre bei uns erhobenen Daten sperren, berichtigen oder löschen lassen und der anonymisierten oder pseudonymisierten Datenerhebung und -speicherung zu Optimierungszwecken unserer Website widersprechen.
<G-vec00962-002-s157><delete.löschen><en> You can always lock, correct or delete your data we collected.
<G-vec00962-002-s157><delete.löschen><de> Sie können jederzeit Ihre bei uns erhobenen Daten sperren, berichtigen oder löschen lassen.
<G-vec00962-002-s158><delete.löschen><en> Finally, you can leave a menu level above, the original images of all already in the Cloud backed up photos from your Smartphone to delete to free up space.
<G-vec00962-002-s158><delete.löschen><de> Zu guter Letzt können Sie eine Menüebene weiter oben die Originalbilder aller bereits in der Cloud gesicherten Fotos vom Smartphone löschen lassen, um Speicherplatz freizugeben.
<G-vec00962-002-s159><delete.löschen><en> You are free to change your personal data provided during registration at any time or to delete it completely from our database.
<G-vec00962-002-s159><delete.löschen><de> Registrierten Personen steht die Möglichkeit frei, die bei der Registrierung angegebenen personenbezogenen Daten jederzeit abzuändern oder vollständig aus dem Datenbestand des für die Verarbeitung Verantwortlichen löschen zu lassen.
<G-vec00962-002-s160><delete.löschen><en> You can also read about how you can inspect, change or delete your own data.
<G-vec00962-002-s160><delete.löschen><de> Außerdem erfahren Sie, wie Sie Auskunft zu Ihren eigenen Daten erhalten und diese ändern oder löschen lassen können.
<G-vec00962-002-s161><delete.löschen><en> You may ask us at any time to block, correct or delete your personal data collected by us.
<G-vec00962-002-s161><delete.löschen><de> Sie können jederzeit Ihre von uns erhobenen Daten sperren, berichtigen oder löschen lassen.
<G-vec00962-002-s162><delete.löschen><en> The consumer has at any time the right to access, modify, rectify and delete personal data.
<G-vec00962-002-s162><delete.löschen><de> Der Verbraucher ist berechtigt, jederzeit auf seine Daten zuzugreifen, sie zu ändern, zu berichtigen oder löschen zu lassen.
<G-vec00962-002-s163><delete.löschen><en> If you want to access, correct, update or delete your personal data, you can contact us at any time using the contact data stated in the “Contact us” section.
<G-vec00962-002-s163><delete.löschen><de> Wenn Sie auf Ihre persönlichen Daten zugreifen, diese korrigieren, aktualisieren oder löschen lassen möchten, können Sie sich jederzeit an uns wenden, indem Sie uns über die unter der Rubrik Kontaktaufnahme angegebenen Kontaktdaten kontaktieren.
<G-vec00962-002-s164><delete.löschen><en> In this case Jimdo is also entitled to delete the corresponding domain names of the Jimdo user at the relevant registrar (“CLOSE”).
<G-vec00962-002-s164><delete.löschen><de> In diesem Fall ist der Anbieter ferner dazu berechtigt, die Domain des Jimdo-Nutzers bei der jeweiligen Vergabestelle löschen zu lassen („CLOSE“).
<G-vec00962-002-s165><delete.löschen><en> You can rectify or delete your data.
<G-vec00962-002-s165><delete.löschen><de> Du kannst deine Daten berichtigen oder löschen lassen.
<G-vec00962-002-s166><delete.löschen><en> Furthermore, you can correct false information or have us delete data the storage of which is no longer required or is inadmissible.
<G-vec00962-002-s166><delete.löschen><de> Darüber hinaus können Sie unrichtige Daten berichtigen oder solche Daten löschen lassen, deren Speicherung unzulässig oder nicht mehr erforderlich ist.
<G-vec00962-002-s167><delete.löschen><en> You also have the right to amend, block or delete any data stored by us that relates to your person.
<G-vec00962-002-s167><delete.löschen><de> Sie haben ferner das Recht, Ihre bei uns gespeicherten Daten berichtigen, sperren oder löschen zu lassen.
<G-vec00962-002-s169><delete.löschen><en> You may correct and delete this information and revoke your consent to storage and use.
<G-vec00962-002-s169><delete.löschen><de> Sie können diese Daten korrigieren und löschen lassen und die Einwilligung für Speicherung und Verwendung widerrufen.
<G-vec00962-002-s170><delete.löschen><en> At any time you have the option to revoke the consent and to delete the applicant data.
<G-vec00962-002-s170><delete.löschen><de> Sie haben jederzeit die Möglichkeit, die Einwilligung zu widerrufen und die Bewerberdaten löschen zu lassen.
<G-vec00962-002-s171><delete.löschen><en> Step 3. Preview and select the photos you want to move > Click Delete button.
<G-vec00962-002-s171><delete.löschen><de> Schritt 3: Wählen Sie die Fotos aus, die Sie löschen möchten > Klicken Sie auf „ “(Löschen).
<G-vec00962-002-s172><delete.löschen><en> In order to delete Products from the basket, just select the checkbox(es) to the left and then click the button "apply".
<G-vec00962-002-s172><delete.löschen><de> Um Produkte zu löschen, setzen Sie den Haken in der Spalte "Löschen" und klicken dann auf den Button "Aktualisieren".
<G-vec00962-002-s173><delete.löschen><en> If you would like Idle Games to delete the data we have collected about you that we have received through Facebook, please contact us with your request to do so at privacy@idle-games.com.
<G-vec00962-002-s173><delete.löschen><de> Wenn Sie möchten, dass wir Ihren Eintrag in unserem System löschen, senden Sie uns bitte über support@iminent.com einen Antrag, dass wir Ihre personenbezogenen Daten aus unserer Datenbank löschen sollen.
<G-vec00962-002-s174><delete.löschen><en> Take the assistance of dr.fone toolkit - iOS Full Data Eraser to permanently delete your data with just one click.
<G-vec00962-002-s174><delete.löschen><de> Nehmen Sie dr.fone - Löschen (iOS Daten-Komplettentferner) zu Hilfe, um Ihre Daten mit nur einem Klick dauerhaft zu löschen.
<G-vec00962-002-s175><delete.löschen><en> Access to, correction or removal of data You have the right to access, correct or delete your personal data.
<G-vec00962-002-s175><delete.löschen><de> Auf Daten zugreifen, diese ändern oder löschen Sie haben das Recht, Ihre personengebundenen Daten einzusehen, zu korrigieren oder zu löschen.
<G-vec00962-002-s176><delete.löschen><en> After clicking the button the Edit/delete dataset window shows up.
<G-vec00962-002-s176><delete.löschen><de> Datensatz editieren/löschen: Nach Klick auf die Schaltfläche erscheint das Dialogfenster Datensatz editieren/löschen.
<G-vec00962-002-s177><delete.löschen><en> [THIS PICTURE IS PROTECTED] Delete the picture after cancelling the protection setting.
<G-vec00962-002-s177><delete.löschen><de> [DIESES BILD IST GESCHÜTZT] Löschen oder überschreiben Sie das Bild nach dem Löschen der Schutzeinstellung.
<G-vec00962-002-s178><delete.löschen><en> In the confirmation dialog, tap/click Delete to remove the custom changes.
<G-vec00962-002-s178><delete.löschen><de> Klicken Sie im Dialogfeld Suchanpassungen löschen auf Löschen, um die benutzerspezifischen Änderungen zu entfernen.
<G-vec00962-002-s179><delete.löschen><en> Use the "reset" button to delete a calculation.
<G-vec00962-002-s179><delete.löschen><de> Um ihre Rechnung zu löschen, drücken Sie den "löschen" Knopf.
<G-vec00962-002-s180><delete.löschen><en> After selecting the photos click on the delete the photos option to delete them.
<G-vec00962-002-s180><delete.löschen><de> Tippen Sie, nachdem Sie auf die Fotos geklickt haben, auf die „Fotos löschen“-Option, um sie zu löschen.
<G-vec00962-002-s181><delete.löschen><en> If you want to delete all downloaded videos and music, please click Clean list.
<G-vec00962-002-s181><delete.löschen><de> Wenn Sie alle heruntergeladenen Videos löschen möchten, klicken Sie auf Liste löschen.
<G-vec00962-002-s182><delete.löschen><en> - Collection of utilities for the maintenance of the hard drive (elimination of duplicates, delete obsolete files, defrag discs,...).
<G-vec00962-002-s182><delete.löschen><de> Tool-Sammlung für die Pflege der Festplatte (doppelte Dateien löschen, veraltete Dateien löschen, Festplatten defragmentieren...).
<G-vec00962-002-s183><delete.löschen><en> Accidental Deletion: Users may accidentally delete certain valuable files while deleting unwanted files from Mac desktop.
<G-vec00962-002-s183><delete.löschen><de> Versehentliches Löschen: Benutzer können versehentlich bestimmte wertvolle Dateien löschen, während sie unerwünschte Dateien vom Mac-Desktop löschen.
<G-vec00962-002-s184><delete.löschen><en> In order to block both the YouTube website and the YouTube app on your Android, you will need to have the YouTube app installed, though you can instead delete the YouTube app and then lock the Google Play Store later to prevent it from being downloaded again.
<G-vec00962-002-s184><delete.löschen><de> Um sowohl die Webseite als auch die App von YouTube auf deinem Android-Gerät zu blockieren, musst du die YouTube App installiert haben, auch wenn du diese stattdessen auch löschen und später den Google Play Store löschen kannst, um zu verhindern, dass sie wieder heruntergeladen wird.
<G-vec00962-002-s185><delete.löschen><en> In the event that you provide us with personal data, you will be able to delete these at any time.
<G-vec00962-002-s185><delete.löschen><de> Löschen der Daten Falls Sie personenbezogene Daten angegeben haben, können Sie diese jederzeit löschen.
<G-vec00962-002-s186><delete.löschen><en> To choose a different folder click Clear to delete predefined folder C:\ProgramData\ESET\ESET Endpoint Security\mirror and click Edit to browse for a folder on the local computer or shared network folder.
<G-vec00962-002-s186><delete.löschen><de> Um einen anderen Ordner auszuwählen, klicken Sie zunächst auf Löschen, um den vordefinierten Ordner C:\ProgramData\ESET\ESET Endpoint Antivirus\mirror zu löschen, und dann auf Bearbeiten, um nach einem lokalen oder einem Netzwerkordner zu suchen.
<G-vec00962-002-s187><delete.löschen><en> You can delete any of the roles that you created, but not the default AEM forms roles that are included in the product.
<G-vec00962-002-s187><delete.löschen><de> Rollen löschen Sie können alle von Ihnen erstellten Rollen löschen, jedoch nicht die AEM Forms-Standardrollen, die im Produkt enthalten sind.
<G-vec00962-002-s188><delete.löschen><en> To quickly delete an audio or video clip without unlinking it, ctrl-click the clip and choose either Delete Audio or Delete Video from the menu.
<G-vec00962-002-s188><delete.löschen><de> Klicken Sie bei gedrückter Strg-Taste auf den Clip und wählen Sie „Audio löschen“ oder „Video löschen“, um einen Audio- oder Videoclip schnell zu löschen, ohne die Verknüpfung aufzuheben.
<G-vec00962-002-s189><delete.löschen><en> • To delete your history, recent destinations, and searches, tap Clear Recents.
<G-vec00962-002-s189><delete.löschen><de> • Um den Verlauf, die letzten Ziele und Suchen zu löschen, tippen Sie auf Letzte löschen.
<G-vec00962-002-s190><delete.löschen><en> Delete all the SQL from the query.
<G-vec00962-002-s190><delete.löschen><de> Löschen Sie den gesamten SQL-Code aus der Abfrage.
<G-vec00962-002-s191><delete.löschen><en> After termination, delete all cookies when using public computers.
<G-vec00962-002-s191><delete.löschen><de> Löschen Sie nach Beendigung ebenso alle Cookies bei der Verwendung von öffentlichen Rechnern.
<G-vec00962-002-s192><delete.löschen><en> Delete the associated value in the dialog box, then click OK.
<G-vec00962-002-s192><delete.löschen><de> Löschen Sie den zugehörigen Wert im Dialogfeld und klicken Sie auf OK.
<G-vec00962-002-s193><delete.löschen><en> 50 g in PE-No results found, please delete some filter to get results.
<G-vec00962-002-s193><delete.löschen><de> Es wurde kein Ergebnis gefunden, bitte löschen sie einige Filter um Ergebnisse zu erhalten.
<G-vec00962-002-s194><delete.löschen><en> Delete the OmegaT program folder.
<G-vec00962-002-s194><delete.löschen><de> Löschen Sie den OmegaT-Programmordner.
<G-vec00962-002-s195><delete.löschen><en> Delete the Jaybird App from your phone.
<G-vec00962-002-s195><delete.löschen><de> Löschen Sie die Jaybird App von Ihrem Smartphone.
<G-vec00962-002-s196><delete.löschen><en> Move to Extensions and delete useless add-ons.
<G-vec00962-002-s196><delete.löschen><de> Verschieben Sie auf Erweiterungen, und löschen Sie nutzlos Add-ons.
<G-vec00962-002-s197><delete.löschen><en> Solution 3: Delete the podcast subscription
<G-vec00962-002-s197><delete.löschen><de> Lösung 4: Löschen Sie den Verlauf und die temporären Dateien des Browsers.
<G-vec00962-002-s198><delete.löschen><en> Delete your Bose® QuietControl® headphones from the Bluetooth® list on your device.
<G-vec00962-002-s198><delete.löschen><de> Löschen Sie die Bose QuietControl headphones aus der Bluetooth-Liste Ihres Geräts.
<G-vec00962-002-s199><delete.löschen><en> If none of the above topics fixes your problem, delete and reinstall Video Kinect. Here’s how:
<G-vec00962-002-s199><delete.löschen><de> Wenn das Problem nicht mithilfe eines der oben genannten Themen behoben werden kann, löschen Sie Video Kinect, und installieren Sie es erneut.
<G-vec00962-002-s200><delete.löschen><en> Delete the recording.
<G-vec00962-002-s200><delete.löschen><de> Löschen Sie die Aufzeichnungen.
<G-vec00962-002-s201><delete.löschen><en> To remove a row of your configuration: Delete the row by clicking the x button in the Action column.
<G-vec00962-002-s201><delete.löschen><de> Sie wollen eine Zeile Ihrer Konfiguration nicht behalten: Löschen Sie die betreffende Zeile mit einem Klick auf die x-Schaltfläche in der Spalte Aktion.
<G-vec00962-002-s202><delete.löschen><en> Securely delete files and folders that you don't ever want to be recovered.
<G-vec00962-002-s202><delete.löschen><de> Löschen Sie die Dateien und Ordner, die Sie nicht mehr wiederherstellen möchten.
<G-vec00962-002-s203><delete.löschen><en> To delete channels: If you are a corporate administrator, select the Delete existing channels, if present check box to delete any channels on your users' computers.
<G-vec00962-002-s203><delete.löschen><de> So löschen Sie Channels: Wenn Sie Administrator eines Unternehmens sind, aktivieren Sie das Kontrollkästchen Vorhandene Channels löschen, um eventuell vorhandene Channels auf den Computern der Benutzer zu löschen.
<G-vec00962-002-s204><delete.löschen><en> Please delete your messages carefully.
<G-vec00962-002-s204><delete.löschen><de> Bitte löschen Sie Ihre Nachrichten sorgfältig.
<G-vec00962-002-s205><delete.löschen><en> Delete the Duet Enterprise site
<G-vec00962-002-s205><delete.löschen><de> Löschen Sie die Duet Enterprise-Website.
<G-vec00962-002-s206><delete.löschen><en> First delete all previously stored cookies, then disable their storage for the future.
<G-vec00962-002-s206><delete.löschen><de> Löschen Sie daher zuerst alle bereits gespeicherten Cookies und deaktivieren Sie die Speicherung für die Zukunft.
<G-vec00962-002-s207><delete.löschen><en> Delete unwanted extensions from the list.
<G-vec00962-002-s207><delete.löschen><de> Löschen Sie unerwünschte Erweiterungen aus der Liste.
<G-vec00962-002-s208><delete.löschen><en> Delete the songs from your computer and from your iCloud Music Library.
<G-vec00962-002-s208><delete.löschen><de> Löschen Sie die Titel von Ihrem Computer und aus Ihrer iCloud-Musikmediathek.
<G-vec00962-002-s228><delete.löschen><en> In other instances, we may lock your account and require you to delete specific Tweets that violate this policy.
<G-vec00962-002-s228><delete.löschen><de> In anderen Fällen sperren wir deinen Account möglicherweise vorübergehend und verlangen, dass du bestimmte Tweets löschst, die gegen diese Richtlinie verstoßen.
<G-vec00962-002-s229><delete.löschen><en> If you delete your account or if your account is terminated by us due to a breach of these Terms, you will lose any accumulated credits.
<G-vec00962-002-s229><delete.löschen><de> Wenn du dein Konto löschst oder dein Konto aus irgendeinem Grund von uns gelöscht wurde wirst du deine ungenutzten Punkte verlieren.
<G-vec00962-002-s230><delete.löschen><en> WARNING: If you delete photos while iCloud Photo Library is turned on, the photos are deleted from iCloud and all your devices that use iCloud Photo Library.
<G-vec00962-002-s230><delete.löschen><de> ACHTUNG: Wenn du Fotos löschst, solange die iCloud-Fotomediathek aktiviert ist, werden die Fotos aus iCloud und von all deinen Geräten gelöscht, die die iCloud-Fotomediathek verwenden.
<G-vec00962-002-s231><delete.löschen><en> In all cases, once you delete a VOD, you will immediately lose access to the Vimeo On Demand page, comments, settings, and stats.
<G-vec00962-002-s231><delete.löschen><de> Auf jeden Fall verlierst du sofort Zugriff auf die Vimeo On Demand-Seite, Kommentare, Einstellungen und Statistiken, wenn du eine VOD löschst.
<G-vec00962-002-s232><delete.löschen><en> If you do not delete the account it will remain in force and you can activate it again in the future.
<G-vec00962-002-s232><delete.löschen><de> Löschst du den Account nicht, so bleibt er bestehen und kann zu einem späteren Zeitpunkt wieder aktiviert werden.
<G-vec00962-002-s233><delete.löschen><en> On the other hand, if you delete your Plenty of Fish profile, it will no longer be visible to anyone.
<G-vec00962-002-s233><delete.löschen><de> Falls du dein Plenty-of-Fish-Profil andererseits löschst, ist es für niemanden mehr sichtbar.
<G-vec00962-002-s234><delete.löschen><en> You can delete your Nintendo Account by selecting "Delete Account" from the Profile menu.
<G-vec00962-002-s234><delete.löschen><de> Wenn du deinen Nintendo-Account löschst, kannst du nicht weiter an My Nintendo teilnehmen.
<G-vec00962-002-s235><delete.löschen><en> These cookies will stay on your device until you delete them.
<G-vec00962-002-s235><delete.löschen><de> Die Cookies verbleiben auf Ihrem Endgerät, bis Du sie löschst.
<G-vec00962-002-s236><delete.löschen><en> This method completely delete your account, your profile, photos, videos, likes, comments, and followers.
<G-vec00962-002-s236><delete.löschen><de> Wenn du dein Konto löschst, sind dein Profil, deine Fotos, Videos, Kommentare, Vorlieben und Follower für immer weg.
<G-vec00962-002-s237><delete.löschen><en> Deleting Tweets Read about how to delete a Tweet.
<G-vec00962-002-s237><delete.löschen><de> Hier erfährst du, wie du einen Tweet löschst.
<G-vec00962-002-s238><delete.löschen><en> This wikiHow teaches you how to delete your Tinder account.
<G-vec00962-002-s238><delete.löschen><de> In diesem wikiHow zeigen wir dir, wie du deinen Tinder-Account löschst.
<G-vec00962-002-s239><delete.löschen><en> * You can easily manage your favorites by highlighting them as you can "read" or delete them.
<G-vec00962-002-s239><delete.löschen><de> * Du kannst Deine Favoriten ganz einfach verwalten, indem Du sie als „Gelesen“ markierst oder löschst.
<G-vec00962-002-s240><delete.löschen><en> Other cookies will remain saved on your device until you delete them.
<G-vec00962-002-s240><delete.löschen><de> Andere Cookies bleiben auf deinem Endgerät gespeichert, bis du diese löschst.
<G-vec00962-002-s241><delete.löschen><en> However, if you delete one of your five aliases, you can’t create a new one to replace it.
<G-vec00962-002-s241><delete.löschen><de> Wenn du allerdings eines deiner fünf Aliasse löschst, kannst du es nicht durch ein neues ersetzen.
<G-vec00962-002-s242><delete.löschen><en> Please make sure, that you wont delete the entries of other authors.
<G-vec00962-002-s242><delete.löschen><de> Bitte dringend darauf achten, daß Du nicht die Einträge anderer Autoren löschst.
<G-vec00962-002-s243><delete.löschen><en> We point out that this setting will be deleted if you delete your cookies.
<G-vec00962-002-s243><delete.löschen><de> Wir weisen Dich darauf hin, dass diese Einstellung gelöscht wird, wenn Du Deine Cookies löschst.
<G-vec00962-002-s244><delete.löschen><en> Don't worry, if you delete your profile from our platform, then it will also be removed from search engines.
<G-vec00962-002-s244><delete.löschen><de> Keine Sorge, wenn du dein Konto löschst, wird es auch aus Suchmaschinen wie Google entfernt.
<G-vec00962-002-s245><delete.löschen><en> If you delete Content, NM Equipment Services will use reasonable efforts to remove it from the Website, but you acknowledge that caching or references to the Content may not be made immediately unavailable.
<G-vec00962-002-s245><delete.löschen><de> Entfernen von Inhalten Wenn du Inhalte löschst, werden wir angemessene Anstrengungen unternehmen, diese von WordPress.com zu entfernen, damit sie nicht mehr öffentlich (oder bei einer privaten Website von den autorisierten Besuchern) angezeigt werden können.
<G-vec00962-002-s246><delete.löschen><en> If you delete your cookies regularly, you will need to click on the link again each time you visit this website.
<G-vec00962-002-s246><delete.löschen><de> Löschst Du deine Cookies regelmäßig, ist ein erneuter Klick auf den Link bei jedem Besuch dieser Website vonnöten.
<G-vec00962-002-s247><delete.löschen><en> If you delete this cookie from your system in the meantime, it must set the opt-out cookie again.
<G-vec00962-002-s247><delete.löschen><de> Löscht der Nutzer den entsprechenden Cookie zwischenzeitlich vom eigenen System, so muss er den Opt-Out-Cookie erneut setzten.
<G-vec00962-002-s249><delete.löschen><en> Disabling a cookie or category of cookie does not delete the cookie from the browser.
<G-vec00962-002-s249><delete.löschen><de> Das Deaktivieren eines Cookies oder einer Kategorie von Cookies löscht das Cookie nicht vom Browser.
<G-vec00962-002-s250><delete.löschen><en> (4) Rebuild Database: the PlayStation 3 system will delete all data on the HDD and rebuild the database.
<G-vec00962-002-s250><delete.löschen><de> (4) Datenbank neu aufbauen: Das PlayStation 3-System löscht alle Daten auf der Festplatte und baut die Datenbank neu auf.
<G-vec00962-002-s251><delete.löschen><en> This will delete the course walk CHP Starter HT.
<G-vec00962-002-s251><delete.löschen><de> Dies löscht die Geländestrecke CHP Starter HT.
<G-vec00962-002-s252><delete.löschen><en> You may also request Orion to complete or correct any inaccurate report that you have submitted through the system, or to correct or delete any data that is erroneous, unnecessary or incomplete or to request Orion to restrict the processing of personal data.
<G-vec00962-002-s252><delete.löschen><de> Sie können außerdem verlangen, dass Orion einen ungenauen Bericht, den Sie durch das System abgegeben haben, komplettiert oder korrigiert, oder Daten, die unkorrekt, unnötig oder unvollständig sind, korrigiert oder löscht, oder verlangen, dass Orion die Weiterverarbeitung persönlicher Daten einschränkt.
<G-vec00962-002-s253><delete.löschen><en> delete - Creates a Delete list of subnets.
<G-vec00962-002-s253><delete.löschen><de> delete - Löscht einen Konfigurationseintrag aus der Liste der Einträge.
<G-vec00962-002-s254><delete.löschen><en> PRIORIT AG will delete stored data with future effect if prompted by you to do so.
<G-vec00962-002-s254><delete.löschen><de> Die PRIORIT AG löscht die gespeicherten Daten, mit Wirkung für die Zukunft, wenn sie von Ihnen dazu aufgefordert wird.
<G-vec00962-002-s255><delete.löschen><en> In cases of incomplete, inaccurate or inappropriate Meta Info, Fengtao Software Inc. is obliged to delete or remove it from its DVDFab Server.
<G-vec00962-002-s255><delete.löschen><de> Solang die Meta Info unvollständig, ungenau oder ungeeignet ist, löscht oder entfernt Fengtao Software Inc. pflichtgemäß sie aus dem DVDFab Server.
<G-vec00962-002-s256><delete.löschen><en> In our Cookie Statement you will learn more about cookies and how to view, delete or disable cookies.
<G-vec00962-002-s256><delete.löschen><de> In unserer Cookie-Erklärung erhalten Sie Informationen über Cookies und erfahren, wie man sie anzeigt, löscht oder deaktiviert.
<G-vec00962-002-s257><delete.löschen><en> Note The contents of your wishlist will be deleted as soon as you delete your browser history or your cookies.
<G-vec00962-002-s257><delete.löschen><de> Sobald du den Browserverlauf oder die Cookies deines Browsers löscht, wird der Inhalt deiner Wunschliste gelöscht.
<G-vec00962-002-s258><delete.löschen><en> For example, if you delete an image you are using from the image manager and upload a new image with the same name again, you may still see the old image that no longer exists when you are logged out.
<G-vec00962-002-s258><delete.löschen><de> Wenn du zum Beispiel ein Bild, welches du verwendest, aus der Bildverwaltung löscht und ein neues Bild mit gleichen Namen wieder hochlädst kann es sein, dass du im ausgeloggten Zustand immer noch das alte Bild siehst, welches gar nicht mehr vorhanden ist.
<G-vec00962-002-s259><delete.löschen><en> By default, the Disk Cleanup utility does not delete files in the account-specific Temp folder that have been accessed within the last seven days.
<G-vec00962-002-s259><delete.löschen><de> Standardmäßig löscht die Datenbereinigungsfunktion keine Dateien im kontospezifischen Temp-Ordner, auf die während der letzten sieben Tage zugegriffen wurde.
<G-vec00962-002-s260><delete.löschen><en> However, this PC infection does not damage the Windows computer, but delete the System Restore points and Shadow Volume copies on the machine as well.
<G-vec00962-002-s260><delete.löschen><de> Diese PC-Infektion beschädigt jedoch nicht den Windows-Computer, sondern löscht auch die Systemwiederherstellungspunkte und die Shadow-Volume-Kopien auf dem Computer.
<G-vec00962-002-s261><delete.löschen><en> If you let someone recharge on your account and they delete items or claim ownership, deciding who the owner is may be difficult.
<G-vec00962-002-s261><delete.löschen><de> Wenn du zulässt, dass jemand dein Konto auflädt, und dieser Items löscht oder Besitzansprüche erhebt, kann es schwierig werden die Verhältnisse zu klären.
<G-vec00962-002-s262><delete.löschen><en> AdwCleaner doesn’t actually delete the found threats, but rather moves them to a quarantine directory that is commonly found under C:\AdwCleaner\Quarantine.
<G-vec00962-002-s262><delete.löschen><de> AdwCleaner löscht die gefundenen Bedrohungen nicht wirklich, sondern verschiebt sie in ein Quarantäne-Verzeichnis, das standardmäßig unter C:\AdwCleaner\Quarantine zu finden ist.
<G-vec00962-002-s263><delete.löschen><en> This option will delete the mail in the exchange server before the receiver opens the mail or read the mail in the inbox and there won’t be any impacts of the mail will be left in receivers Exchange Server.
<G-vec00962-002-s263><delete.löschen><de> Diese Option löscht die E-Mails auf dem Exchange-Server, bevor der Empfänger die E-Mail öffnet oder die E-Mails im Posteingang liest, und es werden keine Auswirkungen der E-Mails auf dem Empfänger-Exchange-Server verbleiben.
<G-vec00962-002-s264><delete.löschen><en> During the encryption process, the .RPD File Virus creates an encrypted copies of the system files and delete the original data.
<G-vec00962-002-s264><delete.löschen><de> Während des Verschlüsselungsprozesses erstellt das .RPD File Virus eine verschlüsselte Kopie der Systemdateien und löscht die ursprünglichen Daten.
<G-vec00962-002-s265><delete.löschen><en> It also provides information about whether the manufacturer will unexpectedly share the data with a third party and whether it will delete user data upon request.
<G-vec00962-002-s265><delete.löschen><de> Außerdem informiert er darüber, ob der Anbieter Daten unerwartet an Dritte weitergibt und ob er Nutzerdaten auf Anfrage löscht.
<G-vec00962-002-s304><delete.löschen><en> You have the right to withdraw your consent to us using your personal data at any time, and to request that we delete it
<G-vec00962-002-s304><delete.löschen><de> 6.5 Sie haben das Recht, Ihre Einwilligung zur Nutzung Ihrer persönlichen Daten jederzeit zu widerrufen und zu verlangen, dass Wir sie löschen.
<G-vec00962-002-s305><delete.löschen><en> A little " " after a city name denotes an obsolete database: you can delete it and you must upgrade to a newer version to use it.
<G-vec00962-002-s305><delete.löschen><de> Ein kleines " " nach dem Städtenamen markiert eine veraltete Datenbank: Sie können Sie löschen und eine neuere installieren, um sie benutzen zu können.
<G-vec00962-002-s306><delete.löschen><en> Use the Delete button to delete the VDI.
<G-vec00962-002-s306><delete.löschen><de> Verwenden Sie die Schaltfläche Löschen, um den VDI zu löschen.
<G-vec00962-002-s307><delete.löschen><en> You can delete cookies from your computer at any time using your browser.
<G-vec00962-002-s307><delete.löschen><de> Sie können sie selbst zu jedem beliebigen Zeitpunkt über Ihren Browser löschen.
<G-vec00962-002-s308><delete.löschen><en> This tool can help delete junk data and put your Mac back in excellent condition.
<G-vec00962-002-s308><delete.löschen><de> Mit diesem Tool können Sie Junk-Daten löschen und Ihren Mac wieder in einen hervorragenden Zustand versetzen.
<G-vec00962-002-s309><delete.löschen><en> Use this procedure to delete Administrators, Non-Administrators, or User-Specific Local Group Policy objects.
<G-vec00962-002-s309><delete.löschen><de> Mit diesem Verfahren können Sie Administratoren, Nicht-Administratoren und benutzerspezifische lokale Gruppenrichtlinienobjekte löschen.
<G-vec00962-002-s310><delete.löschen><en> You can also go to the Global Storage Settings Panel and follow the instructions (which may explain, for example, how to delete existing Flash LSOs (referred to as “information”), how to prevent Flash LSOs from being placed on your computer without your being asked, and how to block Flash LSOs that are not being delivered by the operator of the page you are on at the time).
<G-vec00962-002-s310><delete.löschen><de> Sie können auch im Bereich Global Storage Settings Panel den Anweisungen folgen (die beispielsweise erklären, wie Sie vorhandene Flash-LSOs (auf der Macromedia-Website als „Informationen“ bezeichnet) löschen, wie Sie verhindern können, dass Flash-LSOs unaufgefordert auf Ihrem Computer platziert werden, und (für Flash Player 8 und höher) wie Sie Flash-LSOs blockieren können, die nicht vom Betreiber der jeweiligen Seite bereitgestellt werden).
<G-vec00962-002-s311><delete.löschen><en> Most browsers automatically accept cookies, but you can delete or reject the enabled cookies.
<G-vec00962-002-s311><delete.löschen><de> Die meisten Browser akzeptieren automatisch diese Cookies, aber Sie können sie löschen und die Ablehnung der Cookies aktivieren.
<G-vec00962-002-s312><delete.löschen><en> Learn how to delete app hosting data, empty caches and remove other browsing data.
<G-vec00962-002-s312><delete.löschen><de> Erfahren Sie, wie Sie App-Hosting-Daten löschen, Caches leeren und andere Browsing-Daten entfernen.
<G-vec00962-002-s313><delete.löschen><en> Now you know how to delete Instagram photos from your Instagram account.
<G-vec00962-002-s313><delete.löschen><de> Jetzt wissen Sie, wie Sie Instagram-Fotos aus Ihrem Instagram-Konto löschen können.
<G-vec00962-002-s314><delete.löschen><en> In this Privacy Policy we have outlined what Personal Information may be collected on our Sites or through our Apps, why we collect it, how it may be used, how we safeguard it, who we might share it and what options you have in relation to updating or asking us to delete your Personal Information.
<G-vec00962-002-s314><delete.löschen><de> In dieser Datenschutzrichtlinie wird dargelegt, welche persönlichen Daten auf unseren Websites oder über unsere Apps erfasst werden können, warum wir sie sammeln, wie sie verwendet werden können, wie wir sie schützen, an wen wir sie weitergeben und welche Möglichkeiten Sie haben, Ihre persönlichen Daten zu aktualisieren oder von uns zu fordern, sie zu löschen.
<G-vec00962-002-s315><delete.löschen><en> Visitors have the same rights to access, correct or delete their personal data as do our Customers, as outlined in section “How can a Customer access, correct or delete your personal data?”
<G-vec00962-002-s315><delete.löschen><de> Besucher haben die gleichen Rechte auf Zugang, Berichtigung oder Löschung von persönlichen Daten wie unsere Kunden, wie im Abschnitt „Wie kann ein Kunde auf seine persönlichen Daten zugreifen, sie korrigieren oder sie löschen?“ beschrieben.
<G-vec00962-002-s316><delete.löschen><en> Change, restrict, delete. You may also have rights to change, restrict our use of, or delete your personal information.
<G-vec00962-002-s316><delete.löschen><de> • Änderung, Einschränkung, Löschung: Sie sind möglicherweise auch berechtigt, ihre personenbezogenen Daten zu ändern, meine Nutzung dieser Daten zu beschränken oder sie zu löschen.
<G-vec00962-002-s317><delete.löschen><en> You can delete all the cookies already stored on your computer and configure the main web browsers to block them.
<G-vec00962-002-s317><delete.löschen><de> Beispielsweise können Sie bereits auf ihrem Computer gespeicherte Cookies löschen und die gebräuchlichsten Webbrowser so einstellen, dass die Cookies blockiert werden.
<G-vec00962-002-s318><delete.löschen><en> Delete threat notifications on page 221 Use this task to delete threat notifications from the McAfee Labs Security Threats page.
<G-vec00962-002-s318><delete.löschen><de> Löschen von Benachrichtigungen über Bedrohungen auf Seite 247 Gehen Sie wie in dieser Aufgabe beschrieben vor, um Benachrichtigungen über Bedrohungen auf der Seite McAfee Labs Sicherheitsbedrohungen zu löschen.
<G-vec00962-002-s319><delete.löschen><en> Learn how to delete songs, music videos, shows, and movies from iCloud Music Library in Apple Music.
<G-vec00962-002-s319><delete.löschen><de> Hier erfahren Sie, wie Sie Titel, Musikvideos, TV-Sendungen und Filme aus der iCloud-Musikmediathek in Apple Music löschen.
<G-vec00962-002-s320><delete.löschen><en> When you use eBizUniverse’s services, we make good faith efforts to provide you with access to your personal information and either to correct this data if it is inaccurate or to delete such data at your request if it is not otherwise required to be retained by law or for legitimate business purposes.
<G-vec00962-002-s320><delete.löschen><de> Zugriff auf und Aktualisierung von persönlichen Daten Bei der Verwendung von Google-Services bemühen wir uns nach Treu und Glauben, Ihnen den Zugriff auf Ihre persönlichen Daten zu ermöglichen und diese Daten zu korrigieren, sollten diese fehlerhaft sein, oder sie auf Ihren Wunsch zu löschen, falls sie nicht aufgrund gesetzlicher Bestimmungen oder legitimer geschäftlicher Zwecke benötigt werden.
<G-vec00962-002-s321><delete.löschen><en> We may store unsubscribed e-mail addresses for up to three years on the basis of our legitimate interests before we delete, in order to be able to prove a previously given consent.
<G-vec00962-002-s321><delete.löschen><de> Wir können die ausgetragenen E-Mailadressen bis zu drei Jahren auf Grundlage unserer berechtigten Interessen speichern bevor wir sie löschen, um eine gegebene Einwilligung nachweisen zu können.
<G-vec00962-002-s322><delete.löschen><en> Mark Delete personal settings and then click the Reset button again.
<G-vec00962-002-s322><delete.löschen><de> Markieren Sie Persönliche Einstellungen löschen, und dann, Klicken Sie auf die Schaltfläche " Zurücksetzen " wieder.
