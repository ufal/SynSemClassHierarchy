<G-vec00942-002-s361><back_off.wiederkommen><en> When she wakes me up, I will often tell her to come back in five minutes, or ask her to put on the coffee, which will give me a brief reprieve.
<G-vec00942-002-s361><back_off.wiederkommen><de> Wenn sie mich aufweckt, sage ich ihr oft, sie solle in fünf Minuten wiederkommen, oder ich bitte sie, schon einmal den Kaffee aufzusetzen, so dass ich noch eine kurze Gnadenfrist habe.
<G-vec00942-002-s362><back_off.wiederkommen><en> We will definitely come back.
<G-vec00942-002-s362><back_off.wiederkommen><de> Kein Zweifel, wir werden wiederkommen.
<G-vec00942-002-s363><back_off.wiederkommen><en> Ideally, you should also have regular live chat hours, so users can come back if it is their preferred method of communication.
<G-vec00942-002-s363><back_off.wiederkommen><de> Idealerweise sollten Sie auch regelmäßige Live Chat-Stunden haben, so dass die Benutzer wiederkommen können, wenn sie am liebsten auf diese Weise kommunizieren möchten.
<G-vec00942-002-s364><back_off.wiederkommen><en> An Old Testament prophet reports with these words the reaction of those seeing their Savior finally coming back to take them with Him: «See, this is our God; we have waited for Him, and He will save us.
<G-vec00942-002-s364><back_off.wiederkommen><de> Welcher Prophet aus dem alten Testament hat die Reaktion derer, die ihren Erlöser wiederkommen sehen, um sie zu sich zu nehmen, wie folgt beschrieben: »Siehe, das ist unser Gott, auf den wir hofften, dass er uns helfe.
<G-vec00942-002-s365><back_off.wiederkommen><en> I will be back next year for sure.
<G-vec00942-002-s365><back_off.wiederkommen><de> Ich werde nächstes Jahr auf jeden Fall wiederkommen.
<G-vec00942-002-s366><back_off.wiederkommen><en> We can't wait to come back.
<G-vec00942-002-s366><back_off.wiederkommen><de> Wir werden bestimmt wiederkommen.
<G-vec00942-002-s367><back_off.wiederkommen><en> I'll definitely come back.
<G-vec00942-002-s367><back_off.wiederkommen><de> Ich werde bestimmt wiederkommen.
<G-vec00942-002-s368><back_off.wiederkommen><en> We can only urge Isabelle and her wonderful house... waiting to come back!
<G-vec00942-002-s368><back_off.wiederkommen><de> Ein wunderbarer Ort, wo wir würden gerne wiederkommen.
<G-vec00942-002-s369><back_off.wiederkommen><en> We felt very comfortable here and will definitely come back - many thanks and best regards from the Ruhr.
<G-vec00942-002-s369><back_off.wiederkommen><de> Wir haben uns hier sehr wohl gefühlt und werden bestimmt wiederkommen - vielen Dank und schöne Grüße aus dem Ruhrgebiet.
<G-vec00942-002-s370><back_off.wiederkommen><en> We also provide overall services to visitors, making sure they enjoy their visit and come back frequently.
<G-vec00942-002-s370><back_off.wiederkommen><de> Mit unseren Services stellen wir sicher, dass Besucher ihren Aufenthalt genießen können und gerne wiederkommen.
<G-vec00942-002-s371><back_off.wiederkommen><en> We hope that we can come back soon.
<G-vec00942-002-s371><back_off.wiederkommen><de> Wir hoffen, dass wir bald wiederkommen können.
<G-vec00942-002-s372><back_off.wiederkommen><en> We have probably felt us despite everything and would come back if the construction works are completed.
<G-vec00942-002-s372><back_off.wiederkommen><de> Wir haben uns trotz allem wohlgefühlt und würden wiederkommen, wenn die Bauarbeiten abgeschlossen sind.
<G-vec00942-002-s373><back_off.wiederkommen><en> I hope you will come back soon so you can enjoy all the upgrades we are doing.
<G-vec00942-002-s373><back_off.wiederkommen><de> Ich hoffe du wirst bald wiederkommen, damit du alle Upgrades genießen kannst, die wir gemacht haben.
<G-vec00942-002-s374><back_off.wiederkommen><en> Offer rides to both customers and VIP guests to make them feel special and keep them coming back.
<G-vec00942-002-s374><back_off.wiederkommen><de> Biete Fahrten für Kunden und VIP-Gäste an, damit sie sich rundum wohlfühlen – und wiederkommen.
<G-vec00942-002-s375><back_off.wiederkommen><en> We know that it is our quality craftsmanship and excellent service that keeps customers like you coming back.
<G-vec00942-002-s375><back_off.wiederkommen><de> Wir sind uns bewusst: Es liegt an unserer Qualitätsarbeit und dem ausgezeichneten Service, dass Kunden wie Sie immer wiederkommen.
<G-vec00942-002-s376><back_off.wiederkommen><en> We do recommend you try this alternative type of stay; we were really sad to leave, but I believe we will come back if Trevor allows us to;-).
<G-vec00942-002-s376><back_off.wiederkommen><de> Wir empfehlen Ihnen, diese alternative Form des Aufenthalts zu versuchen; wir waren wirklich traurig zu verlassen, aber ich glaube, wir werden wiederkommen, wenn Trevor ermöglicht es uns,;-).
<G-vec00942-002-s377><back_off.wiederkommen><en> Jeannette was for us a warm and caring hostess - we will most likely (but then in the summer to take advantage of the beautiful terrace) come back.
<G-vec00942-002-s377><back_off.wiederkommen><de> Jeannette war für uns eine herzliche und fürsorgliche Gastgeberin - wir werden höchstwahrscheinlich (dann aber im Sommer, um die schöne Terrasse zu nutzen) wiederkommen.
<G-vec00942-002-s378><back_off.wiederkommen><en> We are definitely going back.
<G-vec00942-002-s378><back_off.wiederkommen><de> Wir würden immer wiederkommen.
<G-vec00942-002-s379><back_off.wiederkommen><en> But for me it was not enough at all and I wasn't ready to leave, what means that I really have to come back.
<G-vec00942-002-s379><back_off.wiederkommen><de> Aber ich war definitiv noch nicht bereit zu gehen... was heißt, dass ich unbedingt wiederkommen muss.
<G-vec00942-002-s399><back_off.zurückblicken><en> From an economic point of view, Würth Industrie Service can look back on an eventful year 2019 and can continue the course of the past years, taking into account the current economic phase.
<G-vec00942-002-s399><back_off.zurückblicken><de> Würth Industrie Service kann aus wirtschaftlicher Sicht auf ein ereignisreiches Jahr 2019 zurückblicken und den Kurs der vergangenen Jahre unter Berücksichtigung der momentanen Konjunkturphase fortsetzen.
<G-vec00942-002-s400><back_off.zurückblicken><en> Our company can look back on five decades of successful history with a continuous innovative lead.
<G-vec00942-002-s400><back_off.zurückblicken><de> Unser Unternehmen kann auf fünf Jahrzehnte erfolgreiche Historie mit einem kontinuierlichen Innovationsvorsprung zurückblicken.
<G-vec00942-002-s401><back_off.zurückblicken><en> You shall leave with your family during the night, and let not anyone of you look back, except your wife; she is condemned along with those who are condemned.
<G-vec00942-002-s401><back_off.zurückblicken><de> Darum begib dich während eines Teils der Nacht mit deiner Familie auf den Weg, und keiner von euch soll zurückblicken - außer deiner Frau, denn was ihnen zustoßen wird, wird auch ihr zustoßen.
<G-vec00942-002-s402><back_off.zurückblicken><en> If you go back 40 years you can see groups like the Red Brigade or the Red Army Faction, which were made up of upper-middle class youngsters who became more radical for purely ideological reasons.
<G-vec00942-002-s402><back_off.zurückblicken><de> Wenn wir 40 Jahre zurückblicken, sehen wir, dass Gruppen wie die Rote Armee Fraktion oder die Roten Brigaden aus jungen Menschen aus der oberen Mittelschicht bestanden, die sich aus rein ideologischen Gründen radikalisiert hatten.
<G-vec00942-002-s403><back_off.zurückblicken><en> For this reason we are very proud of the number of our employees who can look back to an employment period at BUTTING spanning decades.
<G-vec00942-002-s403><back_off.zurückblicken><de> Wir sind deshalb sehr stolz darauf, dass eine Vielzahl unserer Mitarbeiter auf eine jahrzehntelange Tätigkeit für BUTTING zurückblicken kann.
<G-vec00942-002-s404><back_off.zurückblicken><en> When we look back, we can see how we have gone from jute to manufacturing plastics for containing biogas, materials for making major tensile structures, grilles for heat protection, barriers to contain hydrocarbon spills, products for transport, digital printing and signage, anti-vandal systems, pressure valve structures, and much more.
<G-vec00942-002-s404><back_off.zurückblicken><de> Wenn wir nun zurückblicken, stellen wir fest, dass wir von der Jute der Vergangenheit auf andere Produkte übergegangen sind, nämlich auf die Herstellung von Kunststoffen für Biogasspeicherung, Materialien für die Herstellung groβer Spannstrukturen, Gitter für den Wärmeschutz, Barrieren gegen Kohlenwasserstoffverschmutzungen, Materialien für den Transport, den Digitaldruck und die Beschriftung, Systeme gegen Vandalismus, Strukturen für Überdruck usw.
<G-vec00942-002-s405><back_off.zurückblicken><en> Sometimes people get lost in the shadows and as time moves on, we look back with at the past with a better understanding and can pull these people back in to the center.
<G-vec00942-002-s405><back_off.zurückblicken><de> Manchmal verschwinden Menschen in den Schatten, aber im Laufe der Zeit können wir mit einem besseren Verständnis zurückblicken und diese Menschen wieder in die Mitte ziehen.
<G-vec00942-002-s406><back_off.zurückblicken><en> Again FLG can look back on many years of experience and the needs of industry-oriented solutions.
<G-vec00942-002-s406><back_off.zurückblicken><de> Auch hier kann FLG auf eine langjährige Erfahrung zurückblicken und den Anforderungen einer branchengerechten Lösung gerecht werden.
<G-vec00942-002-s407><back_off.zurückblicken><en> Under the motto “25 years of ETAS – and still wild at heart,” we want to look back on our development from a small start-up, the so-called “young wild mavericks” within the Bosch Group, into an independent, globally successful company.
<G-vec00942-002-s407><back_off.zurückblicken><de> Unter dem Motto "25 years of ETAS – and still wild at heart", wollen wir auf unsere Entwicklung vom kleinen Start-up, den sogenannten „jungen Wilden“ innerhalb der Bosch-Gruppe, zu einem unabhängigen, weltweit erfolgreichen Unternehmen zurückblicken.
<G-vec00942-002-s408><back_off.zurückblicken><en> Very few major research facilities in the world can look back on such a long and successful career in the world of science.
<G-vec00942-002-s408><back_off.zurückblicken><de> Nur wenige Forschungsgroßgeräte auf der Welt können auf eine ähnlich lange und erfolgreiche Wissenschaftsgeschichte zurückblicken.
<G-vec00942-002-s409><back_off.zurückblicken><en> Being able to look back on a career spanning 45 years is a rarity in these days, when some band relationships hardly last longer than certain marriages.
<G-vec00942-002-s409><back_off.zurückblicken><de> Auf eine über 45-jährige Bandgeschichte zurückblicken zu können, ist in der heutigen Zeit, in der Bandbeziehungen manchmal nur knapp länger halten als diverse Ehen, schon ein Kunststück.
<G-vec00942-002-s410><back_off.zurückblicken><en> Especially the French Cidre from Normandy can look back on a long tradition.
<G-vec00942-002-s410><back_off.zurückblicken><de> Besonders der französische Cidre aus der Normandie kann auf eine lange Tradition zurückblicken.
<G-vec00942-002-s411><back_off.zurückblicken><en> UTAX GmbH looks back on a successful financial year in 2005.
<G-vec00942-002-s411><back_off.zurückblicken><de> Die UTAX GmbH kann auf ein positives Geschäftsjahr 2005 zurückblicken.
<G-vec00942-002-s412><back_off.zurückblicken><en> Münch Chemie can look back on an all round successful presence at this year's Tires & Rubber in Moscow.
<G-vec00942-002-s412><back_off.zurückblicken><de> Münch Chemie kann auf einen rundum gelungenen Auftritt auf der diesjährigen Tires & Rubber in Moskau zurückblicken.
<G-vec00942-002-s413><back_off.zurückblicken><en> About is a traditional company from East Germany (region of Saxony, not far from Dresden), which can look back on 139 years of history.
<G-vec00942-002-s413><back_off.zurückblicken><de> Die Firma Schamottewerk Radeburg GmbH ist ein traditionsreiches Unternehmen aus Ostdeutschland (Raum Sachsen, unweit von Dresden), welches auf eine 139 jährige Geschichte zurückblicken kann.
<G-vec00942-002-s414><back_off.zurückblicken><en> I know… You’re absolutely right, but when you’re in a mad dash, looking back is impossible.
<G-vec00942-002-s414><back_off.zurückblicken><de> Ich weiß… Sie haben absolut recht, aber wenn es hoch hergeht, kann man einfach nicht zurückblicken.
<G-vec00942-002-s415><back_off.zurückblicken><en> Only when both parts look back with satisfaction at an agreed and performed transaction the business appeared to me as corresponding with the claims of ethics and at the same time furnished with the guaranty of lastingness.
<G-vec00942-002-s415><back_off.zurückblicken><de> Erst wenn beide Teile auf ein abgeschlossenes und vollzogenes Geschäft mit Zufriedenheit zurückblicken, erschien mir das Geschäft den Forderungen der Moral entsprechend und gleichzeitig in vortheilhaftester Weise mit der Bürgschaft der Dauer ausgestattet.
<G-vec00942-002-s416><back_off.zurückblicken><en> It is only a handful of companies that can look back on such a dynamic and at the same time consistent development: ever since its inception, Würth has been in the black and with one exception only (business year 1975) succeeded in increasing its sales volume year after year - and more often than not with double-digit growth rates.
<G-vec00942-002-s416><back_off.zurückblicken><de> Nur wenige Unternehmen können auf eine derart dynamische und gleichzeitig konstante Entwicklung zurückblicken: Würth schreibt seit seiner Gründung stets schwarze Zahlen und konnte mit einer einzigen Ausnahme (Geschäftsjahr 1975) den Umsatz Jahr für Jahr steigern - häufig mit zweistelligen Wachstumsraten.
<G-vec00942-002-s417><back_off.zurückblicken><en> We have deep respect and understanding for this, and we hope that we can help you to dispel some of this worry, so that you can look back on this period as a good time in your life.
<G-vec00942-002-s417><back_off.zurückblicken><de> Wir hoffen, dass wir Ihnen helfen können, einige dieser Sorgen abzulegen, damit Sie auf diese Zeit als eine gute Zeit in Ihrem Leben zurückblicken können.
<G-vec00942-002-s418><back_off.zurückgehen><en> Afterwards, when I wanted to reply, He printed in me His firm but full of love authority, then He talked to me saying it was too early, that I could not enter the light and I had to go back because, 'I had something to do on Earth.'
<G-vec00942-002-s418><back_off.zurückgehen><de> Danach, als ich antworten wollte, prägte er mir seine feste Autorität ein, die aber voller Liebe war, dann redete er mit mir, sagte es sei zu früh, dass ich nicht ins Licht eingehen könnte, und dass ich zurückgehen müsste, da 'ich etwas auf der Erde zu tun hätte'.
<G-vec00942-002-s419><back_off.zurückgehen><en> After shouting at them and receiving no response, I resigned myself, thinking, 'OK, there is no way out, I'll go back to my body and wait for my death.' I went back under water, saw my entangled body floating with arms outstretched, and I went back into my body, peaceably awaiting death, eyes shut and starting to be bothered by the water.
<G-vec00942-002-s419><back_off.zurückgehen><de> Nachdem ich sie angeschrien hatte und keine Antwort erhielt, resignierte ich und dachte „OK, da gibt es keinen Weg nach draußen, ich will zu meinem Körper zurückgehen und auf meinen Tod warten.“ Ich ging zurück unter Wasser, sah meinen verwickelten Körper schweben, mit ausgestreckten Armen und ich ging zurück in meinen Körper, friedlich auf den Tod wartend, die Augen geschlossen und das Wasser begann mich zu stören.
<G-vec00942-002-s420><back_off.zurückgehen><en> All of a sudden, I was told I must go back into my body right now because it was not my time.
<G-vec00942-002-s420><back_off.zurückgehen><de> Ich hörte dann eine weibliche Stimme in meinem Kopf die mir sagte ich müsste zurückgehen es wäre nicht meine Zeit.
<G-vec00942-002-s421><back_off.zurückgehen><en> I really would like to go back there next year.
<G-vec00942-002-s421><back_off.zurückgehen><de> Ich würde wirklich gerne nächstes Jahr dorthin zurückgehen.
<G-vec00942-002-s422><back_off.zurückgehen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00942-002-s422><back_off.zurückgehen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00942-002-s423><back_off.zurückgehen><en> Once you have changed the Marriage Tag Type to add these roles, you can not only use it for new marriages you enter, but you can also go back to existing Marriage tags and apply the new roles to them as well
<G-vec00942-002-s423><back_off.zurückgehen><de> Sobald Sie den Elementtyp "Heirat" über das Hinzufügen dieser Funktionen verändert haben, können Sie hiervon nicht nur für neue Eheschließungen, die Sie erfassen, Gebrauch machen, sondern Sie können vielmehr auch zu bereits vorhandenen Heirats-Elementen "zurückgehen" und auch bei diesen die neu erstellten Funktionen anwenden.
<G-vec00942-002-s424><back_off.zurückgehen><en> Spiritual science has to go back from that what science, resting on the sense-perceptible phenomena, knows to say about the brain and nervous system to something working in the human being mentally-spiritually that can no longer be investigated with the senses that can be investigated only on the inner ways of the soul.
<G-vec00942-002-s424><back_off.zurückgehen><de> Die Geisteswissenschaft muss also zurückgehen von dem, was die äußere, auf die sinnenfälligen Erscheinungen sich stützende Wissenschaft über Gehirn und Nervensystem zu sagen weiß, auf etwas, was im Menschen als Seelisch-Geistiges selbst arbeitet, was nicht mehr mit den Sinnen erforscht werden kann, was nur auf den inneren Wegen der Seele erforscht werden kann.
<G-vec00942-002-s425><back_off.zurückgehen><en> He answered, 'Yes, you must go back.'
<G-vec00942-002-s425><back_off.zurückgehen><de> Er antwortete: 'Ja, du musst zurückgehen'.
<G-vec00942-002-s426><back_off.zurückgehen><en> But you just have to go back to the audience and to the artists to regain confidence in what you do.
<G-vec00942-002-s426><back_off.zurückgehen><de> Aber dann muss man zum Publikum zurückgehen und zu den Künstler*innen, um wieder Zuversicht zu schöpfen.
<G-vec00942-002-s427><back_off.zurückgehen><en> You may remain within the connections of phenomenology and learn to read them, and not, when I offer a complexity of phenomenon, turn back to atomic structures.
<G-vec00942-002-s427><back_off.zurückgehen><de> Sie möchte innerhalb des Zusammenhanges der Phänomene stehenbleiben und lesen lernen, und nicht, wenn ich einen Komplex von Phänomenen habe, von ihm aus zurückgehen auf Atomstrukturen.
<G-vec00942-002-s428><back_off.zurückgehen><en> After he wrote Born in Blood, he was intrigued, and so…He wrote Born in Blood about Freemasonry, and then he had to go back and research the history of the Knights Templar.
<G-vec00942-002-s428><back_off.zurückgehen><de> Nachdem er Born in Blood geschrieben hat, wurde er fasziniert, und so … schrieb er Born in Blood über die Freimaurerei, und dann musste er einen Schritt zurückgehen und über die Geschichte der Tempelritter nachforschen.
<G-vec00942-002-s429><back_off.zurückgehen><en> Now that I have found a Christmas net light for my outdoor decorations I will never go back to the old fashioned string bulbs at least when it comes to my shrubs.
<G-vec00942-002-s429><back_off.zurückgehen><de> Jetzt wo ich ein Weihnachten-Nettolicht für meine Außendekorationen gefunden habe, werde ich zu den alten geformten Schnur-Zwiebeln mindestens nie zurückgehen, wenn es zu meinen Büschen kommt.
<G-vec00942-002-s430><back_off.zurückgehen><en> I could stay with her or go back to my life.
<G-vec00942-002-s430><back_off.zurückgehen><de> Sie wurde gefragt ob sie bleiben oder zurückgehen wolle.
<G-vec00942-002-s431><back_off.zurückgehen><en> The further we go back the more we approach that out of which really originated what we today have in front of us as minerals, plant things and so forth: We approach the spiritual and the spiritual science tells us that that was not only formed out of a lifeless, fiery original nebula what faces us today in the diversity of Earth phenomena but that everything developed out of the spiritual, that originally our Earth was nothing but spirit.
<G-vec00942-002-s431><back_off.zurückgehen><de> Je weiter wir zurückgehen, desto mehr nähern wir uns dem, woraus wirklich entsprungen ist, was wir heute als Mineralien, Pflanzengebilde und so weiter vor uns habe: Wir nähern uns dem Geistigen und lassen uns von der Geisteswissenschaft sagen, daß nicht nur aus einem leblosen, feurigen Urnebel sich dasjenige gebildet hat, was uns heute in der Mannigfaltigkeit der Erderscheinungen gegenübertritt, sondern daß sich alles aus dem Geistigen herausgebildet hat, daß ursprünglich unsere Erde lauterer Geist war.
<G-vec00942-002-s432><back_off.zurückgehen><en> I knew I had to go back.
<G-vec00942-002-s432><back_off.zurückgehen><de> Ich wusste, ich musste zurückgehen.
<G-vec00942-002-s433><back_off.zurückgehen><en> This being communicated a feeling with the gist of the meaning, 'You can stay if you want, or you can go back.
<G-vec00942-002-s433><back_off.zurückgehen><de> Diese Wesenheit kommunizierte mir ein Gefühl mit dem Kern des Gemeinten, "Du kannst bleiben wenn du willst, oder du kannst zurückgehen.
<G-vec00942-002-s434><back_off.zurückgehen><en> Strictly speaking theoretical properties of space time do allow for this, although for any travelling back in time a worm hole would have to be created or found.
<G-vec00942-002-s434><back_off.zurückgehen><de> Streng genommen erlauben theoretische Eigenschaften der Raumzeit dies, obwohl für jedes Zurückgehen in der Zeit ein Wurmloch erzeugt oder gefunden werden müsste.
<G-vec00942-002-s435><back_off.zurückgehen><en> But then I can just turn back.
<G-vec00942-002-s435><back_off.zurückgehen><de> Ich kann dann aber einfach zurückgehen.
<G-vec00942-002-s436><back_off.zurückgehen><en> To understand the purpose of the transfiguration, we need to go back to a conversation that Jesus had with his disciples only a few days previously.
<G-vec00942-002-s436><back_off.zurückgehen><de> Um den Zweck der Umgestaltung zu verstehen, müssen wir auf ein Gespräch zurückgehen, das Jesus mit seinen Jüngern nur wenige Tage vorher geführt hatte.
<G-vec00942-002-s437><back_off.zurückkehren><en> However this is simply not my sort of course, so I will not be going back there frequently.
<G-vec00942-002-s437><back_off.zurückkehren><de> Allerdings ist dies ganz einfach nicht meine Art von Platz, daher werde ich nicht häufig dorthin zurückkehren.
<G-vec00942-002-s438><back_off.zurückkehren><en> The answer is to go back to the standards of God’s Word.
<G-vec00942-002-s438><back_off.zurückkehren><de> Die Antwort lautet: indem wir zu den Maßstäben von Gottes Wort zurückkehren.
<G-vec00942-002-s439><back_off.zurückkehren><en> You will have to come back to your doctor after some opportunity to determine whether the procedure was effective.
<G-vec00942-002-s439><back_off.zurückkehren><de> Sie müssen zu Ihrem Arzt zurückkehren, nachdem Sie die Gelegenheit hatten, festzustellen, ob das Verfahren erfolgreich war.
<G-vec00942-002-s440><back_off.zurückkehren><en> You can go back to the postcard service and send as many new cards as you want.
<G-vec00942-002-s440><back_off.zurückkehren><de> Sie können auch zum Postkarten-Service zurückkehren und eine neue Karte versenden.
<G-vec00942-002-s441><back_off.zurückkehren><en> This implies that the patient will be able to resume back to his/her daily activities immediately after a final medical check the afternoon of their intervention.
<G-vec00942-002-s441><back_off.zurückkehren><de> Dies bedeutet, dass der Patient unmittelbar nach einer abschließenden medizinischen Untersuchung am Nachmittag seiner Intervention zu seinen täglichen Aktivitäten zurückkehren kann.
<G-vec00942-002-s442><back_off.zurückkehren><en> I don't know where it was I just know I don't want to go back.
<G-vec00942-002-s442><back_off.zurückkehren><de> Ich weiß nicht, wo das war, ich weiß nur, dass ich nicht dorthin zurückkehren möchte.
<G-vec00942-002-s443><back_off.zurückkehren><en> Let's go back and think about that story just briefly.
<G-vec00942-002-s443><back_off.zurückkehren><de> Lasst uns zurückkehren und kurz über diese Geschichte nachdenken.
<G-vec00942-002-s444><back_off.zurückkehren><en> It shall not fade, but miraculous colour shall come back to it day after day.
<G-vec00942-002-s444><back_off.zurückkehren><de> Sie wird nicht verblassen, sondern wundersame Farbe wird Tag um Tag zu ihr zurückkehren.
<G-vec00942-002-s445><back_off.zurückkehren><en> We offer good services at a price that makes our customers come back to us.
<G-vec00942-002-s445><back_off.zurückkehren><de> Wir bieten guten Service und Preis, damit die Kunden zu uns zurückkehren.
<G-vec00942-002-s446><back_off.zurückkehren><en> Four days of zipping up our boots and going back to our roots.
<G-vec00942-002-s446><back_off.zurückkehren><de> Vier Tage, in denen wir zu unseren Wurzeln zurückkehren.
<G-vec00942-002-s447><back_off.zurückkehren><en> Go back to the basic calculation, enter these values in paragraph [4] and examine the calculation.
<G-vec00942-002-s447><back_off.zurückkehren><de> In die Grundberechnung zurückkehren, im Absatz [4] diese Werte eingeben und die Berechnung überprüfen.
<G-vec00942-002-s448><back_off.zurückkehren><en> We wanted to come back with a bang“, Danny blatantly puts it.
<G-vec00942-002-s448><back_off.zurückkehren><de> Wir wollten mit einem echten Knall zurückkehren!“ erklärt Danny unverblümt.
<G-vec00942-002-s449><back_off.zurückkehren><en> Setting a replay lag time enables you to take a database copy back to a specific point in time.
<G-vec00942-002-s449><back_off.zurückkehren><de> Durch das Festlegen einer Wiedergabeverzögerung können Sie bei einer Datenbankkopie zu einem bestimmten Zeitpunkt zurückkehren.
<G-vec00942-002-s450><back_off.zurückkehren><en> When you go back to your Shared Library and click View Budgets again, the shared budgets you created will appear in the table.
<G-vec00942-002-s450><back_off.zurückkehren><de> Wenn Sie zu Ihrer gemeinsamen Bibliothek zurückkehren und erneut auf Budgets anzeigen klicken, werden die von Ihnen erstellten gemeinsamen Budgets in der Tabelle angezeigt.
<G-vec00942-002-s451><back_off.zurückkehren><en> They said I had to go back because there are things I need to do.
<G-vec00942-002-s451><back_off.zurückkehren><de> Sie sagten ich müsse zurückkehren, denn es gäbe noch Dinge die ich tun müsste.
<G-vec00942-002-s452><back_off.zurückkehren><en> 18 And Moses went away and, returning to Jethro his father-in-law, said to him, Let me go back, I pray you, to my relatives in Egypt to see whether they are still alive.
<G-vec00942-002-s452><back_off.zurückkehren><de> 18Und Mose ging hin und kehrte zu Jethro, seinem Schwiegervater, zurück und sprach zu ihm: Laß mich doch gehen und zu meinen Brüdern zurückkehren, die in Ägypten sind, daß ich sehe, ob sie noch leben.
<G-vec00942-002-s453><back_off.zurückkehren><en> A switch doesn't allow you to get back to record mode at the same time by pressing the shutter release.
<G-vec00942-002-s453><back_off.zurückkehren><de> Bei einem Schalter kann man nämlich nicht direkt beim Drücken des Auslöseknopfs wieder in den Aufnahmemodus zurückkehren.
<G-vec00942-002-s454><back_off.zurückkehren><en> You will be able to go unnoticed until you go back to what you were doing with a double click of the mouse.
<G-vec00942-002-s454><back_off.zurückkehren><de> Du wirst unentdeckt bleiben und kannst zu deinen Aktivitäten mit einem Doppelklick der Maus zurückkehren.
<G-vec00942-002-s455><back_off.zurückkehren><en> To go back to your regular browsing window, tap the overlapping boxes, tap Private again, and tap Done.
<G-vec00942-002-s455><back_off.zurückkehren><de> Tippe zum Zurückkehren in das normale Browser-Fenster auf das Icon mit den überlappenden Kästchen, dann wieder auf Privat und schließlich auf Fertig.
<G-vec00942-002-s475><back_off.zurückkehren><en> Note: Press b to go back to the previous level.
<G-vec00942-002-s475><back_off.zurückkehren><de> TIPPS: Drücken Sie die Taste, um zum vorherigen Menüelement zurückzukehren.
<G-vec00942-002-s476><back_off.zurückkehren><en> Life can take you unexpected places, and that includes putting you back in a company you thought you had left for good.
<G-vec00942-002-s476><back_off.zurückkehren><de> Das Leben kann einen an unerwartete Orte führen, und dazu gehört auch, wieder in eine Firma zurückzukehren, von der man dachte, man hätte sie für immer verlassen.
<G-vec00942-002-s477><back_off.zurückkehren><en> You can start again from home or go back to the previous page.
<G-vec00942-002-s477><back_off.zurückkehren><de> Um zur vorherigen Seite zurückzukehren, verwenden Sie bitte einfach die "Zurück"-Taste Ihres Browsers.
<G-vec00942-002-s478><back_off.zurückkehren><en> 4:21 The Lord said 63 to Moses, “When you go back to Egypt, 64 see that you 65 do before Pharaoh all the wonders I have put under your control.
<G-vec00942-002-s478><back_off.zurückkehren><de> 21Und Jehova sprach zu Mose: Wenn du hinziehst, um nach Ägypten zurückzukehren, so sieh zu, daß du alle die Wunder, die ich in deine Hand gelegt habe, vor dem Pharao tuest.
<G-vec00942-002-s479><back_off.zurückkehren><en> This experience with living composers gave me the confidence to go back to the older scores, and to find my way, through the music.
<G-vec00942-002-s479><back_off.zurückkehren><de> Diese Erfahrungen mit lebenden Komponisten gaben mir das Vertrauen, zu den Partituren älterer Epochen zurückzukehren und durch die Musikgeschichte hindurch meinen eigenen Weg zu finden.
<G-vec00942-002-s480><back_off.zurückkehren><en> So the easiest and most elegant way to figure this out is to go back to the camera it all started with.
<G-vec00942-002-s480><back_off.zurückkehren><de> Und dann ist es schön, am einfachsten und sinnvollsten, zu der Kamera zurückzukehren, mit der alles anfing.
<G-vec00942-002-s481><back_off.zurückkehren><en> “With an increase in both workloads and the need to record greater levels of information, it became important for us to be able to access up-to-date information and legislation at the point required and at the touch of a button, rather than having to be back in the office in front of the PC.
<G-vec00942-002-s481><back_off.zurückkehren><de> “Durch die Steigerungen sowohl beim Arbeitsanfall als auch bei der Notwendigkeit, mehr Informationen aufzuzeichnen, wurde es für uns wichtig, an Ort und Stelle und auf Knopfdruck aktuelle Informationen und Vorschriften abrufen zu können anstatt ins Büro zurückzukehren und sich vor den PC setzen zu müssen.
<G-vec00942-002-s482><back_off.zurückkehren><en> While on a routine flight on the eve of his wedding, Alex dreams to get back home as soon as possible.
<G-vec00942-002-s482><back_off.zurückkehren><de> Während eines Routine-Fluges am Vorabend seiner Hochzeit, träumt Alex davon, so schnell wie möglich nach Hause zurückzukehren.
<G-vec00942-002-s483><back_off.zurückkehren><en> We are excited about being back to Thailand in just a month’s time with a new seminar topic and look forward to meeting our clients in person once again.
<G-vec00942-002-s483><back_off.zurückkehren><de> Wir freuen uns, in einem Monat mit einem neuen Seminarthema nach Thailand zurückzukehren und unsere Kunden wiederzusehen.
<G-vec00942-002-s484><back_off.zurückkehren><en> Every athlete can use CrossFit as a training method to go back better, stronger, faster to their own sport.
<G-vec00942-002-s484><back_off.zurückkehren><de> Jeder Athlet und jede Athletin kann CrossFit als Trainingsmethode anwenden um besser, schneller, stärker und leistungsfähiger zu seinem oder ihrem Sport zurückzukehren.
<G-vec00942-002-s485><back_off.zurückkehren><en> A place to come back from where you go away with the desire to try again the same feelings.
<G-vec00942-002-s485><back_off.zurückkehren><de> Ein Ort, um von dort zurückzukehren, wo du gehst mit dem Wunsch, wieder die gleichen Gefühle zu versuchen.
<G-vec00942-002-s486><back_off.zurückkehren><en> Because we have the strong in spirit and faith guide, the one, who leads, points out the goal, does not stop, does not allow us to go back, and does not allow us to fail or make mistakes.
<G-vec00942-002-s486><back_off.zurückkehren><de> Denn wir haben einen starken im Geiste und Glauben Führer, der leitet, aufs Ziel verweist, keinen Halt macht, erlaubt uns nicht zurückzukehren, erlaubt uns nicht zu irren oder Fehler zu machen.
<G-vec00942-002-s487><back_off.zurückkehren><en> — But I was eager to get back to my charge.
<G-vec00942-002-s487><back_off.zurückkehren><de> Doch ich war bestrebt, zu meinem Schützling zurückzukehren.
<G-vec00942-002-s488><back_off.zurückkehren><en> After spending wonderful days at the beach with your children, it will be a real pleasure to come back to the hotel to rest in one of our welcoming family rooms.
<G-vec00942-002-s488><back_off.zurückkehren><de> Nachdem Sie mit Ihren Kindern einen wunderschönen Tag am Strand verbracht haben, werden Sie sich freuen, in unser Hotel zurückzukehren und sich in einem der gemütlichen Familienzimmer auszuruhen.
<G-vec00942-002-s489><back_off.zurückkehren><en> It might feel temporarily lonely or even boring to be on your own after the end of a tumultuous relationship, but try to ride that feeling out instead of going back to your ex.
<G-vec00942-002-s489><back_off.zurückkehren><de> Du magst dich nach Beendigung einer turbulenten Beziehung vorübergehend einsam oder gelangweilt fühlen, versuche aber, diese Phase zu überstehen, ohne zu deinem Ex zurückzukehren.
<G-vec00942-002-s490><back_off.zurückkehren><en> I am very happy to come back to my childhood memories.
<G-vec00942-002-s490><back_off.zurückkehren><de> Ich freue mich sehr, zu meinen Kindheitserinnerungen zurückzukehren.
<G-vec00942-002-s491><back_off.zurückkehren><en> Just enough time to save up a bit of money to move back to their hometown and start small business or go back to school.
<G-vec00942-002-s491><back_off.zurückkehren><de> Gerade lange genug bis er ausreichend Geld gespart hat, um in seine Heimatstadt zurückzukehren und ein kleines Geschäft zu gründen oder wieder zur Schule zu gehen.
<G-vec00942-002-s492><back_off.zurückkehren><en> Bonuses Most online casinos give away a bonus to attract new customers and entice existing gamblers to come back.
<G-vec00942-002-s492><back_off.zurückkehren><de> Bonusse Die meisten Online-Casinos verschenken einen Bonus, um neue Kunden zu gewinnen und bestehende Spieler dazu zu bewegen, zurückzukehren.
<G-vec00942-002-s493><back_off.zurückkehren><en> Now it was time for Jesus to go back to Heaven.
<G-vec00942-002-s493><back_off.zurückkehren><de> Vierzig Tage später kam für Jesus der Zeitpunkt, in den Himmel zurückzukehren.
<G-vec00942-002-s456><back_off.zurückkommen><en> This will be your free lifetime membership to Camsola, meaning you can come back any time you want.
<G-vec00942-002-s456><back_off.zurückkommen><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei Camsola sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00942-002-s457><back_off.zurückkommen><en> This will be your free lifetime membership at meaning that you can come back any time you want.
<G-vec00942-002-s457><back_off.zurückkommen><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei Xxx Sex 66 sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00942-002-s458><back_off.zurückkommen><en> I kept looking down at the doors watching a police officer at the entrance knowing when the door opened up I could float out that way but at the same time I knew I couldn't come back if I left.
<G-vec00942-002-s458><back_off.zurückkommen><de> Ich schaute auch hinunter auf die Türen, einen Polizisten beim Eingang beobachtend, wissend dass ich wenn die Tür sich öffnen würde dort hinaus schweben könnte, aber gleichzeitig wusste ich dass ich nicht zurückkommen könnte wenn ich fortginge.
<G-vec00942-002-s459><back_off.zurückkommen><en> I accept alone and offer practically everything that will make you leave happy and want to come back.
<G-vec00942-002-s459><back_off.zurückkommen><de> Ich akzeptiere alleine und biete praktisch alles an, was dich glücklich macht und zurückkommen will.
<G-vec00942-002-s460><back_off.zurückkommen><en> We are those of Q’uo, and we thank you for asking us to be with you this afternoon. At this time, we would transfer the contact back to the one known as Jim, to see whether we may be of service in addressing further queries.
<G-vec00942-002-s460><back_off.zurückkommen><de> Wir sind jene von Q‘uo und wir verlassen euch in der Liebe und in dem Licht des Einen Schöpfers und möchten, zu dieser Zeit, zu demjenigen zurückkommen, der als Jim bekannt ist, um zu erfragen, ob es weitere Fragen gibt, die noch in den Gedanken der hier Anwesenden sind.
<G-vec00942-002-s461><back_off.zurückkommen><en> We want our readers to continue coming back and the site to become your and their daily bread.
<G-vec00942-002-s461><back_off.zurückkommen><de> Wir wollen, dass unsere Leser auch weiterhin zurückkommen und zu unserem täglichen Brot werden.
<G-vec00942-002-s462><back_off.zurückkommen><en> This will be your free lifetime membership at Free Live Sex Chat Girls on WebCam, meaning that you can come back any time you want.
<G-vec00942-002-s462><back_off.zurückkommen><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei VideoChat.guru sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00942-002-s463><back_off.zurückkommen><en> This will be your free lifetime membership at Paradise Ladyz, meaning that you can come back any time you want.
<G-vec00942-002-s463><back_off.zurückkommen><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei Paradise Ladyz sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00942-002-s464><back_off.zurückkommen><en> Once you land on Mars, you probably won't be coming back.
<G-vec00942-002-s464><back_off.zurückkommen><de> Sobald Sie auf dem Mars gelandet sind, werden Sie wahrscheinlich nicht mehr zurückkommen.
<G-vec00942-002-s465><back_off.zurückkommen><en> Again, this coming back into my body is something I have difficulty explaining in words.
<G-vec00942-002-s465><back_off.zurückkommen><de> Wiederum lässt sich dieses Zurückkommen in den Körper nur schwer mit Worten beschreiben.
<G-vec00942-002-s466><back_off.zurückkommen><en> It was hot and there was no time to consume some drinks, or to eat a snack, so we were really glad when we arrived back in the camp in the late afternoon to revive our spirits.
<G-vec00942-002-s466><back_off.zurückkommen><de> Es ist heiß, fast keine Zeit irgendwo zwischendurch ess- und trinkbares zu bekommen, so sind wir froh, trotz der vielen tollen Ansichten der Stadt, als wir ins Camp zurückkommen und dort unsere Lebensgeister wieder aufleben.
<G-vec00942-002-s467><back_off.zurückkommen><en> And then with those I was just waiting for them to finish before going back to my straw bed...
<G-vec00942-002-s467><back_off.zurückkommen><de> Mit diesen letzten konnte ich es nicht abwarten, daß sie ihr Geschäft fertig brächten, so daß ich zu meinem Strohlager zurückkommen konnte...
<G-vec00942-002-s468><back_off.zurückkommen><en> I can come back to this but I want to be brief.
<G-vec00942-002-s468><back_off.zurückkommen><de> Ich kann darauf zurückkommen, aber ich möchte nicht zu ausführlich werden.
<G-vec00942-002-s469><back_off.zurückkommen><en> When hearing a sound – you can acknowledge as ‘hearing, hearing,’ and then go back to the main body objects.
<G-vec00942-002-s469><back_off.zurückkommen><de> Wenn du ein Gerausch hörst, kannst du dies als "Hören, Hören" wahrnehmen und dann zu den Hauptobjekten des Körpers zurückkommen.
<G-vec00942-002-s470><back_off.zurückkommen><en> This will be your free lifetime membership at Extasy Webcam, meaning that you can come back any time you want.
<G-vec00942-002-s470><back_off.zurückkommen><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei Free Cam Sex sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00942-002-s471><back_off.zurückkommen><en> This will be your free lifetime membership at Horny Match Live, meaning that you can come back any time you want.
<G-vec00942-002-s471><back_off.zurückkommen><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei IntimWeb.ru sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00942-002-s472><back_off.zurückkommen><en> But I think I get to come back to this,
<G-vec00942-002-s472><back_off.zurückkommen><de> Und nun glaube ich, dass ich darauf zurückkommen kann.
<G-vec00942-002-s473><back_off.zurückkommen><en> We aim to get back to you within 48 hours, but usually respond more quickly than that.
<G-vec00942-002-s473><back_off.zurückkommen><de> Wir werden innerhalb von 48 Stunden auf Sie zurückkommen, antworten jedoch normalerweise schneller.
<G-vec00942-002-s474><back_off.zurückkommen><en> Zadar is a city you will certainly come back to, and you will want to take the original Zadar Maraschino liqueur with you.
<G-vec00942-002-s474><back_off.zurückkommen><de> Zadar ist eine Stadt, in die Sie sicher zurückkommen werden und mit Sich werden Sie den originellen Zadarer Likӧr Maraschino mitnehmen.
