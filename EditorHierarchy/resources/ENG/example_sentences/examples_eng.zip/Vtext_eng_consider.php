<G-vec00488-002-s038><consider.(sich)_ansehen><en> The natural scientists do it the other way around; they consider what is perfect to be only the mechanical sum total of simple processes.
<G-vec00488-002-s038><consider.(sich)_ansehen><de> Umgekehrt machen es die Naturforscher, die das Vollkommene nur als eine mechanische Summe der einfachen Vorgänge ansehen.
<G-vec00488-002-s039><consider.(sich)_ansehen><en> Being vital, energetic and non-fatalistic in her approach to history, which she conceived of as the fruit of human activity, and at the same time laying bare the deep contradictions of capitalism, Rosa Luxemburg did not consider that the victory of socialism was inevitable.
<G-vec00488-002-s039><consider.(sich)_ansehen><de> Rosa Luxemburgs vitale, energische und keinesfalls fatalistische Auffassung der Geschichte, die sie als Ergebnis menschlichen Handelns begriff, und ihre Analyse der tiefen Widersprüche des Kapitalismus, ließen sie den Sieg des Sozialismus nicht als unvermeidlich ansehen.
<G-vec00488-002-s040><consider.(sich)_ansehen><en> These individuals also likely do not feel the connection of friendship that most people consider ‘normal’.
<G-vec00488-002-s040><consider.(sich)_ansehen><de> Diese Personen empfinden wahrscheinlich auch nicht die Verbindung der Freundschaft, welche die meisten Menschen als 'normal' ansehen.
<G-vec00488-002-s041><consider.(sich)_ansehen><en> We used the survey to determine which sustainability topics stakeholders and top managers consider to be important for WACKER and how they rate our sustainability efforts.
<G-vec00488-002-s041><consider.(sich)_ansehen><de> Mit der Umfrage haben wir ermittelt, welche Nachhaltigkeitsthemen Stakeholder und Top-Management als wesentlich für WACKER ansehen und wie sie unsere Nachhaltigkeitsarbeit beurteilen.
<G-vec00488-002-s042><consider.(sich)_ansehen><en> Your doctor will consider an HDL of 60 mg/dL (or greater) ideal.
<G-vec00488-002-s042><consider.(sich)_ansehen><de> Dein Arzt wird einen HDL-Wert von 60 mg/dL (oder höher) als ideal ansehen.
<G-vec00488-002-s043><consider.(sich)_ansehen><en> (NancyL) ZT: 3. they may have to drink whatever water they can find, and should consider NO filters or electricity or fire available, and how to purify the water in those circumstances.
<G-vec00488-002-s043><consider.(sich)_ansehen><de> Sie mögen trinken müssen, was auch immer für Wasser sie finden können, und sollten keine Filter oder Elektrizität oder Feuer als verfügbar ansehen, und wie das Wasser unter diesen Umständen zu reinigen ist.
<G-vec00488-002-s044><consider.(sich)_ansehen><en> The priest, minister of the Sacrament of Reconciliation, must always consider it his duty to make transpire, in words and in drawing near to the penitent, the merciful love of God.
<G-vec00488-002-s044><consider.(sich)_ansehen><de> Der Priester, Spender des Sakraments der Versöhnung, soll es immer als seine Aufgabe ansehen, in den Worten und in der Weise, wie er sich an den Pönitenten wendet, die barmherzige Liebe Gottes durchscheinen zu lassen.
<G-vec00488-002-s045><consider.(sich)_ansehen><en> The only way they can retaliate against a God they consider cruel is to deny Him vehemently.
<G-vec00488-002-s045><consider.(sich)_ansehen><de> Der einzige Weg sich gegen einen Gott zu rächen, den sie als grausam ansehen, ist ihn vehement zu verleugnen.
<G-vec00488-002-s046><consider.(sich)_ansehen><en> But that's also because Chinese do not consider plagiarism a legal wrong but rather an appreciation of the original.
<G-vec00488-002-s046><consider.(sich)_ansehen><de> Dies liegt aber auch daran, dass Chinesen Plagiate nicht als Unrecht, sondern als Würdigung des Originals ansehen.
<G-vec00488-002-s047><consider.(sich)_ansehen><en> Give details below regarding your business such as whether you have an exhibition area, if you already commercialise other fitness brands (if so, which ones?), whether or not you have your own technical service and any other information that you consider relevant.
<G-vec00488-002-s047><consider.(sich)_ansehen><de> Nennen Sie uns im Folgenden nähere Einzelheiten zu Ihrem Unternehmen, wie zum Beispiel, ob Sie über Ausstellungsfläche verfügen, ob Sie bereits andere Fitnessmarken vertreiben (wenn ja, welche), ob Sie einen eigenen Kundendienst haben oder nicht und weitere Informationen, die Sie als relevant ansehen.
<G-vec00488-002-s048><consider.(sich)_ansehen><en> Well, the answer mainly depends on what the bond markets consider to be the appropriate reference period.
<G-vec00488-002-s048><consider.(sich)_ansehen><de> Die Antwort auf diese Frage hängt in erster Linie davon ab, welchen Referenzzeitraum die Anleihenmärkte als angemessen ansehen.
<G-vec00488-002-s049><consider.(sich)_ansehen><en> At the conclusion of the interview, the reporter asked what I would consider the ideal gift that members worldwide could give to me.
<G-vec00488-002-s049><consider.(sich)_ansehen><de> Am Ende des Interviews fragte mich der Reporter, was ich als ideales Geschenk der Mitglieder überall für mich ansehen würde.
<G-vec00488-002-s050><consider.(sich)_ansehen><en> (This argument assumes contemporary cogency in the light of the avowed aim of some gay militants to destroy the family, which they consider an "oppressive institution.")
<G-vec00488-002-s050><consider.(sich)_ansehen><de> (Dieses Argument beansprucht momentan seine Beweiskraft im Licht des erklärten Ziels einiger schwuler Militanter, die Familie zu zerstören, die sie als eine „unterdrückerische Einrichtung“ ansehen).
<G-vec00488-002-s051><consider.(sich)_ansehen><en> In a world that teaches us to leave out our imagination and stay rational and focused on (what we consider) the ‘important things’, there is only one place to retreat into: our own mind.
<G-vec00488-002-s051><consider.(sich)_ansehen><de> In einer Welt, die uns beibringt unsere Fantasie außen vor zu lassen und rational und darauf fokussiert zu bleiben, was wir als “die wichtigen Dinge” ansehen, gibt es nur einen einzigen Ort, an den wir uns zurückziehen können: unseren eigenen Verstand.
<G-vec00488-002-s052><consider.(sich)_ansehen><en> before God and men, conscious of their affiliation to the Western Christian community, conscious of their German origin, and realizing the common task of all nations of Europe, the elected representatives of millions of expellees, after careful deliberation and after having searched their conscience, have resolved to make public a so-lemn declaration to the German people and to the entire world, defining both the duties and the rights which the German expellees consider their basic law and an indispensable pre-condition for the establishment of a free and united Europe. 1.
<G-vec00488-002-s052><consider.(sich)_ansehen><de> Im Bewußtsein ihrer Verantwortung vor Gott und den Menschen, im Bewußtsein ihrer Zugehörigkeit zum christlich-abendländischen Kulturkreis, im Bewußtsein ihres deutschen Volkstums und in der Erkenntnis der gemeinsamen Aufgabe aller europäischen Völker, haben die erwählten Vertreter von Millionen Heimatvertriebenen nach reiflicher Überlegung und nach Prüfung ihres Gewissens beschlossen, dem deutschen Volk und der Weltöffentlichkeit gegenüber eine feierliche Erklärung abzugeben, die die Pflichten und Rechte festlegt, welche die deutschen Heimatvertriebenen als ihr Grundgesetz und als unumgängliche Voraussetzung für die Herbeiführung eines freien und geeinten Europas ansehen.
<G-vec00488-002-s053><consider.(sich)_ansehen><en> Given that naturally occurring cancer accounts for 23% of deaths in many developed countries, this means their risk is increased around 0.5%, which most people would probably consider acceptable.
<G-vec00488-002-s053><consider.(sich)_ansehen><de> Angesichts der Tatsache, dass natürlich auftretende Krebserkrankungen die Ursache für 23 % aller Todesfälle in vielen entwickelten Ländern darstellen, bedeutet dies, dass das Risiko dieser Beispielperson um 0,5 % höher liegt, was wahrscheinlich die meisten Leute als akzeptabel ansehen würden.
<G-vec00488-002-s054><consider.(sich)_ansehen><en> In fact, for many years, Norway has been approving a higher catch rate than what the IWC would theoretically consider sustainable, ignoring the results presented by the IWC Scientific Committee.
<G-vec00488-002-s054><consider.(sich)_ansehen><de> Tatsächlich genehmigt Norwegen seit Jahren eine weitaus höhere Fangquote, als die IWC theoretisch als nachhaltig ansehen würde und ignoriert die Ergebnisse des IWC-Wissenschaftsausschusses.
<G-vec00488-002-s055><consider.(sich)_ansehen><en> There will be much grief amongst people, love will grow cold, it will be the way it was before the great flood: increased enjoyment of life, sinfulness and unbelief.... everything occurs in such a way that people will consider it normal, and they do not consider it unusual because all their thoughts and endeavours are merely of a worldly nature.
<G-vec00488-002-s055><consider.(sich)_ansehen><de> Es wird viel Trübsal sein unter den Menschen, die Liebe wird erkalten, es wird sein wie vor der Sündflut: erhöhter Lebensgenuß, Sündhaftigkeit und Glaubenslosigkeit.... alles vollzieht sich so, daß die Menschen es als selbstverständlich ansehen und sie nichts Ungewöhnliches darin sehen, weil ihr Sinnen und Trachten nur weltlich gerichtet ist.
<G-vec00488-002-s056><consider.(sich)_ansehen><en> When we are compelled to think of a certain complex of sensations as connected, we are led to the concept of matter, which we consider to be the carrier of sensations.
<G-vec00488-002-s056><consider.(sich)_ansehen><de> Wenn wir uns gezwungen sehen, einen bestimmten Komplex von Empfindungen zusammenhängend zu denken, so kommen wir zum Begriffe der Substanz, die wir als Träger derselben ansehen.
<G-vec00488-002-s703><consider.(sich)_halten><en> Many of our readers consider the FX 5200 a "DirectX8 board" because the execution speed of DirectX9 shaders is rather slow.
<G-vec00488-002-s703><consider.(sich)_halten><de> Viele unser Leser halten die FX 5200 für eine "DirectX8-Karte", weil die Ausführungsgeschwindigkeit von DirectX9-Shadern ziemlich niedrig ist.
<G-vec00488-002-s704><consider.(sich)_halten><en> Many people consider it an imagination when they are able to see something.
<G-vec00488-002-s704><consider.(sich)_halten><de> Viele Menschen halten es für eine Vorstellung, wenn sie etwas sehen können.
<G-vec00488-002-s705><consider.(sich)_halten><en> Some BPMN experts consider collaboration diagrams, i.e. the modeling of different process participants in different pools, only as a pattern for business-to-business-collaboration.
<G-vec00488-002-s705><consider.(sich)_halten><de> Einige BPMN-Experten halten Kolloborationsdiagramme, also die Modellierung unterschiedlicher Prozessbeteiligter in jeweils eigenen Pools, nur für sinnvoll, um die Zusammenarbeit unterschiedlicher Unternehmen (B2B) darzustellen.
<G-vec00488-002-s706><consider.(sich)_halten><en> In addition to reconfirming the framework and principles it collectively adopted in December 2009, we consider it vital that the Council should also identify concrete measures to operationalize its agreed policy and thence move to implementation of the agreed objectives.
<G-vec00488-002-s706><consider.(sich)_halten><de> Außer der erneuten Bestätigung der Rahmenbedingungen und Grundsätze, die er im Dezember 2009 kollektiv angenommen hat, halten wir es für unerlässlich, dass der Rat auch konkrete Maßnahmen festlegt, um seine vereinbarte Politik umzusetzen und sich so auf die Erfüllung der vereinbarten Ziele hinbewegt.
<G-vec00488-002-s707><consider.(sich)_halten><en> Nevertheless, we consider it unjustified to extinguish those works of Simonov, which once served the Soviet Union of Lenin and Stalin.
<G-vec00488-002-s707><consider.(sich)_halten><de> Gleichwohl halten wir es für ungerechtfertigt, deswegen auch jenes Schaffen von Simonow auszulöschen, das einst der Sowjetunion Lenins und Stalins gedient hat.
<G-vec00488-002-s708><consider.(sich)_halten><en> But this sudden defeatism was not internationalism, but a distorted variety of patriotism —these gentlemen consider their fatherland to be the Kremlin, on which their welfare depends.
<G-vec00488-002-s708><consider.(sich)_halten><de> Aber dieser plötzliche Defätismus war nicht Internationalismus, sondern eine verzerrte Spielart des Patriotismus – diese Herren halten den Kreml, von dem ihr Wohlergehen abhängt, für ihr Vaterland.
<G-vec00488-002-s709><consider.(sich)_halten><en> Over 70 percent of the organizers consider World Snow Day very helpful when it comes to bringing new customers to ski resorts.
<G-vec00488-002-s709><consider.(sich)_halten><de> Über 70 Prozent der Organisatoren halten den World Snow Day für sehr hilfreich, wenn es darum geht, neue Kunden in die Ski-Resorts zu bringen.
<G-vec00488-002-s710><consider.(sich)_halten><en> Some consider walking up and down the best, others prefer lying prostrate.
<G-vec00488-002-s710><consider.(sich)_halten><de> Manche halten das Auf- und Abgehen für das Beste, andere die liegende Haltung.
<G-vec00488-002-s711><consider.(sich)_halten><en> Therefore, we consider the division into View Key, Spend Key and Payment ID very reasonable and helpful.
<G-vec00488-002-s711><consider.(sich)_halten><de> Daher halten wir die Einteilung in View Key, Spend Key und Payment-ID für sehr findig und hilfreich.
<G-vec00488-002-s712><consider.(sich)_halten><en> Many consider touching ourselves ‘down there’ to be a sin, something dirty that deserves condemnation.
<G-vec00488-002-s712><consider.(sich)_halten><de> Viele halten sich "da unten" zu berühren für Sünde, etwas Dreckiges, das es verdient verdammt zu werden.
<G-vec00488-002-s713><consider.(sich)_halten><en> But for some reason, the surrounding people consider it necessary to continually advise something, even if the pregnancy is not the first and there were already wonderful births behind, and wonderful healthy children grow up in the family.
<G-vec00488-002-s713><consider.(sich)_halten><de> Aber aus irgendeinem Grund halten die umliegenden Menschen es für notwendig, ständig etwas zu beraten, auch wenn die Schwangerschaft nicht die erste ist und bereits wunderbare Geburten dahinter standen und wunderbare gesunde Kinder in der Familie aufwachsen.
<G-vec00488-002-s714><consider.(sich)_halten><en> We consider a duty to thank the Mr. Pesakh Kaplan who did not regret efforts and wrote notes to these marches which I to him sang on memory 8.
<G-vec00488-002-s714><consider.(sich)_halten><de> Wir halten für eine Pflicht, Herrn Pessacha Kaplan zu danken, der nicht bemitleidend die Bemühungen und die Noten zu diesen Märschen schrieb, die ich mich ihm nach dem Gedächtnis 8 vor hin gesungen habe.
<G-vec00488-002-s715><consider.(sich)_halten><en> Many consider it an ideal substitute for Deca-Durabolin.
<G-vec00488-002-s715><consider.(sich)_halten><de> Viele halten es für einen idealen Ersatz für Deca-Durabolin.
<G-vec00488-002-s716><consider.(sich)_halten><en> 500 Piece/Pieces if you want to test the market we can consider low the MOQ . Port:
<G-vec00488-002-s716><consider.(sich)_halten><de> 500 Stück/Stücke wenn Sie den Markt prüfen möchten, können wir Tief halten für das MOQ.
<G-vec00488-002-s717><consider.(sich)_halten><en> We consider a detailed acquaintance, with us in the stable, very important.
<G-vec00488-002-s717><consider.(sich)_halten><de> Ein ausführliches Kennenlernen, bei uns im Stall, halten wir für sehr wichtig.
<G-vec00488-002-s718><consider.(sich)_halten><en> Many historians and political scientists consider this term inappropriate for the modern context.
<G-vec00488-002-s718><consider.(sich)_halten><de> Viele Historiker und Politikwissenschaftler halten diesen Begriff für den modernen Kontext für unangemessen.
<G-vec00488-002-s719><consider.(sich)_halten><en> Therefore, we consider it is our duty to draw your attention to certain dangers.
<G-vec00488-002-s719><consider.(sich)_halten><de> Daher halten wir es für unsere Pflicht, Ihre Aufmerksamkeit auf gewisse Gefahren zu ziehen.
<G-vec00488-002-s720><consider.(sich)_halten><en> Another figure is also highly interesting: When asked about reducing bureaucracy, 44% say that this topic is “very important”, and 26% even consider it “most important.”
<G-vec00488-002-s720><consider.(sich)_halten><de> Hochinterressant ist eine weitere Zahl: Befragt nach dem Abbau von Bürokratie, sagen 44 %, dieses Thema sei „sehr wichtig“, 26 % halten dies sogar für „am wichtigsten“.
<G-vec00488-002-s721><consider.(sich)_halten><en> A lot of people consider that the persecution of Falun Gong in China is the biggest violation against human rights.
<G-vec00488-002-s721><consider.(sich)_halten><de> Viele Menschen halten die Verfolgung in China für die schwerste Menschenrechtsverletzung überhaupt.
<G-vec00488-002-s950><consider.(sich)_überlegen><en> 1 Consider how your parents respond to your accomplishments.
<G-vec00488-002-s950><consider.(sich)_überlegen><de> 1 Überlege, wie deine Eltern auf deine Erfolge reagieren.
<G-vec00488-002-s951><consider.(sich)_überlegen><en> Consider whether you're not meeting your girlfriend's needs and what you can do to help meet them.
<G-vec00488-002-s951><consider.(sich)_überlegen><de> Überlege, ob du die Bedürfnisse deiner Freundin erfüllst und wie es dir gelingen kann, es zu tun.
<G-vec00488-002-s952><consider.(sich)_überlegen><en> When making a master list, consider using a computerized program such as Excel.
<G-vec00488-002-s952><consider.(sich)_überlegen><de> Überlege, ein Computerprogramm für die Erstellung der Master-Liste zu verwenden.
<G-vec00488-002-s953><consider.(sich)_überlegen><en> Consider what background information you personally would like to provide, how you would like to address the viewer.
<G-vec00488-002-s953><consider.(sich)_überlegen><de> Überlege, was Du persönlich an Hintergrundinformationen liefern möchtest, wie Du den Zuschauer ansprechen möchtest.
<G-vec00488-002-s954><consider.(sich)_überlegen><en> Consider hiring a lawyer to help guide you through the process of filing a restraining order.
<G-vec00488-002-s954><consider.(sich)_überlegen><de> Überlege, einen Rechtsanwalt aufzusuchen, um dir bei dem Antrag auf ein Kontaktverbot zu helfen.
<G-vec00488-002-s955><consider.(sich)_überlegen><en> Consider whether you want to tell me who you are, how you feel, what you want and how I should handle you.
<G-vec00488-002-s955><consider.(sich)_überlegen><de> Überlege, ob Du mir sagen möchtest, wer Du bist, wie Du fühlst, was Du willst und wie ich Dir begegnen soll.
<G-vec00488-002-s956><consider.(sich)_überlegen><en> Consider joining a team to get exercise and socialize at the same time.
<G-vec00488-002-s956><consider.(sich)_überlegen><de> Überlege, einem Team beizutreten, um gleichzeitig zu trainieren und neue Leute kennenzulernen.
<G-vec00488-002-s957><consider.(sich)_überlegen><en> Consider wearing light eyeshadow, some mascara, and light-colored lipstick or lip gloss.
<G-vec00488-002-s957><consider.(sich)_überlegen><de> Überlege, nur ein wenig Lidschatten, etwas Mascara und einen hellen Lippenstift oder Lipgloss zu tragen.
<G-vec00488-002-s958><consider.(sich)_überlegen><en> First, consider who you want to tell I love you.
<G-vec00488-002-s958><consider.(sich)_überlegen><de> Überlege zunächst, wem du „Ich liebe dich“ sagen willst.
<G-vec00488-002-s959><consider.(sich)_überlegen><en> Consider designating someone who is willing to go to the store to buy forgotten items.
<G-vec00488-002-s959><consider.(sich)_überlegen><de> Überlege, jemanden zu bestimmen, der einwilligt, in ein Geschäft einkaufen zu gehen, wenn etwas vergessen wurde.
<G-vec00488-002-s960><consider.(sich)_überlegen><en> This is why you should consider the carrier you want to travel with.
<G-vec00488-002-s960><consider.(sich)_überlegen><de> Überlege deshalb mit wem Du reisen möchtest.
<G-vec00488-002-s961><consider.(sich)_überlegen><en> Consider how quickly the illness came on.
<G-vec00488-002-s961><consider.(sich)_überlegen><de> Überlege, wie schnell die Krankheit aufgetreten ist.
<G-vec00488-002-s962><consider.(sich)_überlegen><en> Consider very carefully, WHAT you wish for - let your words be clear and exact.
<G-vec00488-002-s962><consider.(sich)_überlegen><de> Überlege sehr sorgfältig, WORUM Du bittest, sei ganz KLAR und formuliere so exakt wie möglich.
<G-vec00488-002-s963><consider.(sich)_überlegen><en> Consider where you’d most enjoy working.
<G-vec00488-002-s963><consider.(sich)_überlegen><de> Überlege, wo du am liebsten arbeiten würdest.
<G-vec00488-002-s964><consider.(sich)_überlegen><en> Consider the things you do better than other people, or that you are frequently complimented on.
<G-vec00488-002-s964><consider.(sich)_überlegen><de> Überlege, was du besser kannst als andere, oder wofür dir regelmäßig Komplimente gemacht werden.
<G-vec00488-002-s965><consider.(sich)_überlegen><en> Consider now, that the most advanced and civilized countries of the world have been turned into arsenals of explosives, that the continents of the globe have been transformed into huge camps and battlefields, that the peoples of the world have formed themselves into armed nations, and that the governments of the world are vying with each other as to who will first step into the field of carnage and bloodshed, thus subjecting mankind to the utmost degree of affliction.
<G-vec00488-002-s965><consider.(sich)_überlegen><de> Überlege, daß heute die fortschrittlichsten, zivilisiertesten Länder der Welt in Pulverfässer, die Kontinente des Erdballs in riesige Heerlager und Schlachtfelder verwandelt sind, daß die Völker der Welt sich zu waffenstarrenden Nationen formiert haben, daß die Regierungen der Welt miteinander wetteifern, wer den ersten Schritt auf das Feld des Gemetzels und Blutvergießens tut und so die Menschheit ins tiefste Elend stürzt.
<G-vec00488-002-s966><consider.(sich)_überlegen><en> Consider using pre-chopped onions, bell peppers or other frozen bagged vegetables.
<G-vec00488-002-s966><consider.(sich)_überlegen><de> Überlege, ob du bereits geschnittene Zwiebeln, Paprika oder anderes Gemüse aus Tiefkühlbeuteln verwenden möchtest.
<G-vec00488-002-s967><consider.(sich)_überlegen><en> Consider who your mom would enjoy sharing her special day with, and determine whether the party will be a surprise or not.
<G-vec00488-002-s967><consider.(sich)_überlegen><de> Überlege, mit wem deine Mutter gerne diesen besonderen Tag verbringen würde und überlege, ob es eine Überraschungsparty werden sollte oder nicht.
<G-vec00488-002-s968><consider.(sich)_überlegen><en> Consider installing a toad light.
<G-vec00488-002-s968><consider.(sich)_überlegen><de> Überlege, ein Krötenlicht zu installieren.
<G-vec00488-002-s038><consider.ansehen><en> The natural scientists do it the other way around; they consider what is perfect to be only the mechanical sum total of simple processes.
<G-vec00488-002-s038><consider.ansehen><de> Umgekehrt machen es die Naturforscher, die das Vollkommene nur als eine mechanische Summe der einfachen Vorgänge ansehen.
<G-vec00488-002-s039><consider.ansehen><en> Being vital, energetic and non-fatalistic in her approach to history, which she conceived of as the fruit of human activity, and at the same time laying bare the deep contradictions of capitalism, Rosa Luxemburg did not consider that the victory of socialism was inevitable.
<G-vec00488-002-s039><consider.ansehen><de> Rosa Luxemburgs vitale, energische und keinesfalls fatalistische Auffassung der Geschichte, die sie als Ergebnis menschlichen Handelns begriff, und ihre Analyse der tiefen Widersprüche des Kapitalismus, ließen sie den Sieg des Sozialismus nicht als unvermeidlich ansehen.
<G-vec00488-002-s040><consider.ansehen><en> These individuals also likely do not feel the connection of friendship that most people consider ‘normal’.
<G-vec00488-002-s040><consider.ansehen><de> Diese Personen empfinden wahrscheinlich auch nicht die Verbindung der Freundschaft, welche die meisten Menschen als 'normal' ansehen.
<G-vec00488-002-s041><consider.ansehen><en> We used the survey to determine which sustainability topics stakeholders and top managers consider to be important for WACKER and how they rate our sustainability efforts.
<G-vec00488-002-s041><consider.ansehen><de> Mit der Umfrage haben wir ermittelt, welche Nachhaltigkeitsthemen Stakeholder und Top-Management als wesentlich für WACKER ansehen und wie sie unsere Nachhaltigkeitsarbeit beurteilen.
<G-vec00488-002-s042><consider.ansehen><en> Your doctor will consider an HDL of 60 mg/dL (or greater) ideal.
<G-vec00488-002-s042><consider.ansehen><de> Dein Arzt wird einen HDL-Wert von 60 mg/dL (oder höher) als ideal ansehen.
<G-vec00488-002-s043><consider.ansehen><en> (NancyL) ZT: 3. they may have to drink whatever water they can find, and should consider NO filters or electricity or fire available, and how to purify the water in those circumstances.
<G-vec00488-002-s043><consider.ansehen><de> Sie mögen trinken müssen, was auch immer für Wasser sie finden können, und sollten keine Filter oder Elektrizität oder Feuer als verfügbar ansehen, und wie das Wasser unter diesen Umständen zu reinigen ist.
<G-vec00488-002-s044><consider.ansehen><en> The priest, minister of the Sacrament of Reconciliation, must always consider it his duty to make transpire, in words and in drawing near to the penitent, the merciful love of God.
<G-vec00488-002-s044><consider.ansehen><de> Der Priester, Spender des Sakraments der Versöhnung, soll es immer als seine Aufgabe ansehen, in den Worten und in der Weise, wie er sich an den Pönitenten wendet, die barmherzige Liebe Gottes durchscheinen zu lassen.
<G-vec00488-002-s045><consider.ansehen><en> The only way they can retaliate against a God they consider cruel is to deny Him vehemently.
<G-vec00488-002-s045><consider.ansehen><de> Der einzige Weg sich gegen einen Gott zu rächen, den sie als grausam ansehen, ist ihn vehement zu verleugnen.
<G-vec00488-002-s046><consider.ansehen><en> But that's also because Chinese do not consider plagiarism a legal wrong but rather an appreciation of the original.
<G-vec00488-002-s046><consider.ansehen><de> Dies liegt aber auch daran, dass Chinesen Plagiate nicht als Unrecht, sondern als Würdigung des Originals ansehen.
<G-vec00488-002-s047><consider.ansehen><en> Give details below regarding your business such as whether you have an exhibition area, if you already commercialise other fitness brands (if so, which ones?), whether or not you have your own technical service and any other information that you consider relevant.
<G-vec00488-002-s047><consider.ansehen><de> Nennen Sie uns im Folgenden nähere Einzelheiten zu Ihrem Unternehmen, wie zum Beispiel, ob Sie über Ausstellungsfläche verfügen, ob Sie bereits andere Fitnessmarken vertreiben (wenn ja, welche), ob Sie einen eigenen Kundendienst haben oder nicht und weitere Informationen, die Sie als relevant ansehen.
<G-vec00488-002-s048><consider.ansehen><en> Well, the answer mainly depends on what the bond markets consider to be the appropriate reference period.
<G-vec00488-002-s048><consider.ansehen><de> Die Antwort auf diese Frage hängt in erster Linie davon ab, welchen Referenzzeitraum die Anleihenmärkte als angemessen ansehen.
<G-vec00488-002-s049><consider.ansehen><en> At the conclusion of the interview, the reporter asked what I would consider the ideal gift that members worldwide could give to me.
<G-vec00488-002-s049><consider.ansehen><de> Am Ende des Interviews fragte mich der Reporter, was ich als ideales Geschenk der Mitglieder überall für mich ansehen würde.
<G-vec00488-002-s050><consider.ansehen><en> (This argument assumes contemporary cogency in the light of the avowed aim of some gay militants to destroy the family, which they consider an "oppressive institution.")
<G-vec00488-002-s050><consider.ansehen><de> (Dieses Argument beansprucht momentan seine Beweiskraft im Licht des erklärten Ziels einiger schwuler Militanter, die Familie zu zerstören, die sie als eine „unterdrückerische Einrichtung“ ansehen).
<G-vec00488-002-s051><consider.ansehen><en> In a world that teaches us to leave out our imagination and stay rational and focused on (what we consider) the ‘important things’, there is only one place to retreat into: our own mind.
<G-vec00488-002-s051><consider.ansehen><de> In einer Welt, die uns beibringt unsere Fantasie außen vor zu lassen und rational und darauf fokussiert zu bleiben, was wir als “die wichtigen Dinge” ansehen, gibt es nur einen einzigen Ort, an den wir uns zurückziehen können: unseren eigenen Verstand.
<G-vec00488-002-s052><consider.ansehen><en> before God and men, conscious of their affiliation to the Western Christian community, conscious of their German origin, and realizing the common task of all nations of Europe, the elected representatives of millions of expellees, after careful deliberation and after having searched their conscience, have resolved to make public a so-lemn declaration to the German people and to the entire world, defining both the duties and the rights which the German expellees consider their basic law and an indispensable pre-condition for the establishment of a free and united Europe. 1.
<G-vec00488-002-s052><consider.ansehen><de> Im Bewußtsein ihrer Verantwortung vor Gott und den Menschen, im Bewußtsein ihrer Zugehörigkeit zum christlich-abendländischen Kulturkreis, im Bewußtsein ihres deutschen Volkstums und in der Erkenntnis der gemeinsamen Aufgabe aller europäischen Völker, haben die erwählten Vertreter von Millionen Heimatvertriebenen nach reiflicher Überlegung und nach Prüfung ihres Gewissens beschlossen, dem deutschen Volk und der Weltöffentlichkeit gegenüber eine feierliche Erklärung abzugeben, die die Pflichten und Rechte festlegt, welche die deutschen Heimatvertriebenen als ihr Grundgesetz und als unumgängliche Voraussetzung für die Herbeiführung eines freien und geeinten Europas ansehen.
<G-vec00488-002-s053><consider.ansehen><en> Given that naturally occurring cancer accounts for 23% of deaths in many developed countries, this means their risk is increased around 0.5%, which most people would probably consider acceptable.
<G-vec00488-002-s053><consider.ansehen><de> Angesichts der Tatsache, dass natürlich auftretende Krebserkrankungen die Ursache für 23 % aller Todesfälle in vielen entwickelten Ländern darstellen, bedeutet dies, dass das Risiko dieser Beispielperson um 0,5 % höher liegt, was wahrscheinlich die meisten Leute als akzeptabel ansehen würden.
<G-vec00488-002-s054><consider.ansehen><en> In fact, for many years, Norway has been approving a higher catch rate than what the IWC would theoretically consider sustainable, ignoring the results presented by the IWC Scientific Committee.
<G-vec00488-002-s054><consider.ansehen><de> Tatsächlich genehmigt Norwegen seit Jahren eine weitaus höhere Fangquote, als die IWC theoretisch als nachhaltig ansehen würde und ignoriert die Ergebnisse des IWC-Wissenschaftsausschusses.
<G-vec00488-002-s055><consider.ansehen><en> There will be much grief amongst people, love will grow cold, it will be the way it was before the great flood: increased enjoyment of life, sinfulness and unbelief.... everything occurs in such a way that people will consider it normal, and they do not consider it unusual because all their thoughts and endeavours are merely of a worldly nature.
<G-vec00488-002-s055><consider.ansehen><de> Es wird viel Trübsal sein unter den Menschen, die Liebe wird erkalten, es wird sein wie vor der Sündflut: erhöhter Lebensgenuß, Sündhaftigkeit und Glaubenslosigkeit.... alles vollzieht sich so, daß die Menschen es als selbstverständlich ansehen und sie nichts Ungewöhnliches darin sehen, weil ihr Sinnen und Trachten nur weltlich gerichtet ist.
<G-vec00488-002-s056><consider.ansehen><en> When we are compelled to think of a certain complex of sensations as connected, we are led to the concept of matter, which we consider to be the carrier of sensations.
<G-vec00488-002-s056><consider.ansehen><de> Wenn wir uns gezwungen sehen, einen bestimmten Komplex von Empfindungen zusammenhängend zu denken, so kommen wir zum Begriffe der Substanz, die wir als Träger derselben ansehen.
<G-vec00488-002-s133><consider.beachten><en> However, the difference in size can be neglected in practice approximately. However, when applying the formula (1), it is necessary to consider the relation whether the angle used is only half the width of the main lobe, or both halves.
<G-vec00488-002-s133><consider.beachten><de> Der Größenunterschied kann aber in der Praxis näherungsweise vernachlässigt werden, man muss bei der Anwendung der Formel (1) jedoch den Bezug beachten, ob der verwendete Winkel nur die halbe Breite der Hauptkeule betrifft, oder beide Hälften.
<G-vec00488-002-s134><consider.beachten><en> To develop the best strategy you need to consider many different components and details.
<G-vec00488-002-s134><consider.beachten><de> Für die Entwicklung der bestmöglichen Strategie gibt es viele verschiedene Komponente und Details zu beachten.
<G-vec00488-002-s135><consider.beachten><en> Thus, there are numerous judicial decisions to consider.
<G-vec00488-002-s135><consider.beachten><de> Entsprechend gibt es eine Vielzahl an gerichtlichen Entscheidungen zu beachten.
<G-vec00488-002-s136><consider.beachten><en> The following features you should consider when buying an aroma diffuser, in order to get afterwards an ideal product without disappointment.
<G-vec00488-002-s136><consider.beachten><de> Folgende Merkmale solltest du beim Kauf eines Aroma-Diffusers beachten, um hinterher ein ideales Produkt ohne Enttäuschungen zu erhalten.
<G-vec00488-002-s137><consider.beachten><en> If you want to send an email directly through the contact form on the BRANDRUP website, please consider that these data are transferred encoded. Therefore, we cannot guarantee the confidentiality and integrity of the content of your emails.
<G-vec00488-002-s137><consider.beachten><de> Wenn Sie eine E-Mail direkt aus dem Kontaktbereich von BRANDRUP senden möchten, so sollten Sie beachten, dass diese Daten unverschlüsselt übertragen werden und somit keine Gewährleistung für die Vertraulichkeit und Integrität der E-Mail-Inhalte übernommen werden kann.
<G-vec00488-002-s138><consider.beachten><en> There are also some things to consider when making trailers.
<G-vec00488-002-s138><consider.beachten><de> Auch bei einem Trailer gibt es einiges zu beachten.
<G-vec00488-002-s139><consider.beachten><en> Here you will find practical and useful tips on what you should consider when designing printed circuit boards.
<G-vec00488-002-s139><consider.beachten><de> Hier erhalten Sie praxisnahe und hilfreiche Tipps, was Sie beim Design und Layout von Leiterplatten beachten sollten.
<G-vec00488-002-s140><consider.beachten><en> In the online marketing world, a current trend with many followers says that the best thing to do to optimise SEO content for search engines is, paradoxically, not to consider it.
<G-vec00488-002-s140><consider.beachten><de> Ein aktueller Trend mit vielen Anhängern in der Online Marketing Welt besagt, dass das Beste, was zu tun ist, um SEO Inhalte für Suchmaschinen zu optimieren darin besteht, ihn paradoxerweise nicht zu beachten.
<G-vec00488-002-s141><consider.beachten><en> Other than that, you have nothing to consider, except calm down the taxi driver once in a whilean order him to drive more relaxed.
<G-vec00488-002-s141><consider.beachten><de> Ansonsten müsst ihr nichts beachten, außer ab und zu den Taxifahrer zu bitten etwas entspannter zu fahren.
<G-vec00488-002-s142><consider.beachten><en> There are wagering requirements to consider – this refers to the number of times a player will need to play through the bonus, plus winnings before the total can be withdrawn as cash.
<G-vec00488-002-s142><consider.beachten><de> Es sind Wettanforderungen zu beachten – dies bezieht sich darauf, wie oft ein Spieler den Bonus durchspielen muss, plus Gewinne, bevor der Gesamtbetrag als Bargeld ausgezahlt werden kann.
<G-vec00488-002-s143><consider.beachten><en> Please consider: Your health insurance will only pay for placement of your children in another household, if this placement is in response to the particular situation and the children are not already taken care of at this place on a regular basis.
<G-vec00488-002-s143><consider.beachten><de> Bitte beachten: Für die Unterbringung von Kindern in einem anderen Haushalt kann die Krankenkasse nur dann aufkommen, wenn die Unterbringung nur wegen der besonderen Situation erfolgte und diese dort nicht sowieso regelmäßig betreut werden.
<G-vec00488-002-s144><consider.beachten><en> With an eye-catching line-up, the speakers discuss what businesses should consider when choosing a connected building or home platform and what role partnerships, cloud and mesh systems will play.
<G-vec00488-002-s144><consider.beachten><de> Mit einem beeindruckenden Aufgebot erörtern die Redner, was Unternehmen beachten sollten, wenn sie ein vernetztes Gebäude oder eine vernetzte Heimplattform wählen und welche Rolle Partnerschaften, Cloud und Mesh-Systeme spielen werden.
<G-vec00488-002-s145><consider.beachten><en> Please consider that if your car model and tyre size are not listed in our Buyer's Guide, it means that we can't guarantee the correct application for you vehicle.
<G-vec00488-002-s145><consider.beachten><de> Bitte beachten Sie, dass wir für die korrekte Verwendung der Schneekette an Ihrem Fahrzeug nicht garantieren können, wenn Ihr Fahrzeugmodell und die Reifengröße unter „Kaufhilfe“ nicht aufgelistet sind.
<G-vec00488-002-s146><consider.beachten><en> Through this concept, there is so much to consider, such as the uniformed size of all characters, optimizing the colors and contrasts as well as the perspective.
<G-vec00488-002-s146><consider.beachten><de> Bei der Umsetzung gibt es so einiges zu beachten, wie etwa die gleichbleibende Größe aller Schriftzeichen, die Optimierung der Farben und Kontraste sowie der Perpektive.
<G-vec00488-002-s147><consider.beachten><en> If you live outside the US, please consider the laws of your country when posting a review.
<G-vec00488-002-s147><consider.beachten><de> Wenn Sie nicht in den USA ansässig sind, beachten Sie bitte beim Verfassen und Veröffentlichen von Bewertungen die in Ihrem Land geltenden Gesetze.
<G-vec00488-002-s148><consider.beachten><en> This blog post has some great advice on things you should consider when designing emails for Dark Mode.
<G-vec00488-002-s148><consider.beachten><de> Dieser Blog bietet weitere nützliche Informationen über alles, was du beachten solltest, wenn du E-Mails für den Dark Mode gestaltest.
<G-vec00488-002-s149><consider.beachten><en> Utilise luminaires with asymmetrical or narrow-angle light distribution, consider glare limitation.
<G-vec00488-002-s149><consider.beachten><de> Leuchten mit asymmetrischer oder tiefstrahlender Lichtstärkeverteilung verwenden, Blendungsbegrenzung beachten.
<G-vec00488-002-s150><consider.beachten><en> There are many things to consider if you find yourself needing to feed a newborn kitten.
<G-vec00488-002-s150><consider.beachten><de> Wenn man ein neugeborenes Kätzchen mit der Hand aufziehen will, gibt es einiges zu beachten.
<G-vec00488-002-s151><consider.beachten><en> This article on Best Practices for Mobile Site Checkout will give you a full run-down of what you should consider when designing or improving your mobile site. Additional Resources
<G-vec00488-002-s151><consider.beachten><de> Dieser Artikel zum Thema „Best Practices für den Bestellvorgang auf mobilen Webseiten“ gibt Ihnen einen ausführlichen Überblick darüber, was Sie bei der Erstellung oder Optimierung Ihrer mobilen Webseite beachten sollten.
<G-vec00488-002-s171><consider.bedenken><en> Consider how greatly their thoughts were limited and how weak their minds.
<G-vec00488-002-s171><consider.bedenken><de> Bedenke, wie sehr ihre Gedanken begrenzt und wie unvollkommen ihre Ansichten waren.
<G-vec00488-002-s172><consider.bedenken><en> But speaking the truth, consider the age of the child.
<G-vec00488-002-s172><consider.bedenken><de> Aber wenn du die Wahrheit sagst, bedenke das Alter des Kindes.
<G-vec00488-002-s173><consider.bedenken><en> Just consider – until now we all thought that there was just the one kind.
<G-vec00488-002-s173><consider.bedenken><de> Man bedenke — bisher dachten wir alle, dass es nur diese eine Art gebe.
<G-vec00488-002-s174><consider.bedenken><en> Consider the color and texture of the things you are gluing.
<G-vec00488-002-s174><consider.bedenken><de> Bedenke die Farbe und Textur der Dinge, die du aufklebst.
<G-vec00488-002-s175><consider.bedenken><en> Consider your jokes timing and delivery.
<G-vec00488-002-s175><consider.bedenken><de> Bedenke Timing und Ausführung deiner Witze.
<G-vec00488-002-s176><consider.bedenken><en> Consider the effect of treasury stock on the debt-to-equity ratio.
<G-vec00488-002-s176><consider.bedenken><de> Bedenke den Effekt von Vorratsaktien auf die Eigenkapitalüberdeckung.
<G-vec00488-002-s177><consider.bedenken><en> 14In the day of prosperity be joyful, but in the day of adversity consider: God also hath set the one over against the other, to the end that man should find nothing after him.
<G-vec00488-002-s177><consider.bedenken><de> 14Am Tage der Wohlfahrt sei guter Dinge; aber am Tage des Unglücks bedenke: auch diesen wie jenen hat Gott gemacht, damit der Mensch nicht irgend etwas nach sich finde.
<G-vec00488-002-s178><consider.bedenken><en> See how you behaved in the valley; consider what you have done.
<G-vec00488-002-s178><consider.bedenken><de> Siehe an, wie du es treibst im Tal, und bedenke, wie du es ausgerichtet hast.
<G-vec00488-002-s179><consider.bedenken><en> Therefore am I troubled at his presence: when I consider, I am afraid of him.
<G-vec00488-002-s179><consider.bedenken><de> Darum erschrecke ich vor ihm; und wenn ich's bedenke, so fürchte ich mich vor ihm.
<G-vec00488-002-s180><consider.bedenken><en> EMPRESS: I consider the facts which I already have and tries a result to drag from it.
<G-vec00488-002-s180><consider.bedenken><de> PRAXEDA EMPRESS: Ich bedenke die Fakten, die ich schon habe und versuche daraus ein Fazit zu ziehen.
<G-vec00488-002-s181><consider.bedenken><en> Consider it, eh you me purchase.
<G-vec00488-002-s181><consider.bedenken><de> Bedenke es, eh Du mich anschaffst.
<G-vec00488-002-s182><consider.bedenken><en> Consider the eagerness with which certain peoples and nations have anticipated the return of Imám-Husayn, whose coming, after the appearance of the Qá'im, hath been prophesied, in days past, by the chosen ones of God, exalted be His glory.
<G-vec00488-002-s182><consider.bedenken><de> Bedenke das heftige Verlangen, mit dem bestimmte Völker und Nationen die Wiederkehr des Imám-Husayn erwartet haben, dessen Kommen nach dem Erscheinen des Qá'im die Erwählten Gottes - gepriesen sei Seine Herrlichkeit - in vergangenen Tagen vorausgesagt hatten.
<G-vec00488-002-s183><consider.bedenken><en> Consider that most V-8 engines are 90 degrees.
<G-vec00488-002-s183><consider.bedenken><de> Bedenke, dass die meisten V8 Motoren 90° Spreizung haben.
<G-vec00488-002-s184><consider.bedenken><en> Consider what great things our beloved Father of tender mercies in heaven has done for us.
<G-vec00488-002-s184><consider.bedenken><de> Bedenke was unser geliebter Vater im Himmel, voller Gnade für uns getan hat.
<G-vec00488-002-s185><consider.bedenken><en> Please simply consider that the grip of each mat, including the one made of natural rubber, will be affected by sweat or moisture as none of the materials mentioned above can absorb liquids and all small amounts of moisture and grease that your body emits will have an effect on the mat’s grip.
<G-vec00488-002-s185><consider.bedenken><de> Deshalb bedenke bitte, dass durch Schweißabsonderung oder Feuchtigkeit die Griffigkeit einer jeden Yogamatte, auch der aus Naturkautschuk, beeinträchtigt werden kann, da das Material nicht saugfähig ist und ein Feuchtigkeits- oder Fettfilm auf der Yogamatte automatisch zu einem Verlust der Griffigkeit führen kann.
<G-vec00488-002-s186><consider.bedenken><en> 7 Consider what I say, and may the Lord give you understanding in all things.
<G-vec00488-002-s186><consider.bedenken><de> 7 Bedenke, was ich sage; denn der Herr wird dir Verständnis geben in allen Dingen.
<G-vec00488-002-s187><consider.bedenken><en> The skiing: Consider now that Kamchatka is one of the most snowy places on earth, heaps of freshies on the hook.
<G-vec00488-002-s187><consider.bedenken><de> Auf Skiern erwartet dich folgendes: Bedenke, dass Kamtschatka zu den Regionen mit den gröβten Schneefallmengen der Welt gehört.
<G-vec00488-002-s188><consider.bedenken><en> Consider your motives.
<G-vec00488-002-s188><consider.bedenken><de> Bedenke deine Motive.
<G-vec00488-002-s189><consider.bedenken><en> Consider that the grey shape of the future development is not "fixed" but depends on the “scenario” you choose.
<G-vec00488-002-s189><consider.bedenken><de> Bedenke, dass der graue Bereich der zukünftigen Abschätzung nichts Feststehendes ist, sondern von dem "Szenario" abhängt, welches du wählst.
<G-vec00488-002-s266><consider.berücksichtigen><en> This will help to qualify trainees to consider environmental impacts in their economically oriented work processes and to learn how to develop and implement individual adaptation measures in their occupational field.
<G-vec00488-002-s266><consider.berücksichtigen><de> Dadurch werden die Auszubildenden qualifiziert, in den ökonomisch geprägten Arbeitsabläufen auch ökologische Auswirkungen zu berücksichtigen und sie lernen, wie sie in ihrem Berufsfeld individuelle Anpassungsmaßnahmen entwickeln und implementieren können.
<G-vec00488-002-s267><consider.berücksichtigen><en> -SHIPPING to the USA: From GUATEMALA, consider this when placing an order.
<G-vec00488-002-s267><consider.berücksichtigen><de> Versand: Wir befinden uns in GUATEMALA, Bitte berücksichtigen Sie dies, wenn Sie eine Bestellung aufgeben.
<G-vec00488-002-s268><consider.berücksichtigen><en> When making a NAS system decision, consider not only today's needs but what your storage demands look like 6, 12, and 24 months out.
<G-vec00488-002-s268><consider.berücksichtigen><de> Berücksichtigen Sie bei der Wahl eines NAS-Systems nicht nur Ihre heutigen Anforderungen, sondern auch Ihren möglichen Speicherbedarf in 6, 12 oder 24 Monaten.
<G-vec00488-002-s269><consider.berücksichtigen><en> Innovation is about creating value First, just consider the benefits of digital innovation at your company.
<G-vec00488-002-s269><consider.berücksichtigen><de> BEI INNOVATION GEHT ES UM WERTSCHÖPFUNG Zuerst berücksichtigen Sie die Vorteile der digitalen Innovation bei Ihrer Firma.
<G-vec00488-002-s270><consider.berücksichtigen><en> It is also important to consider your HMI, switches, handles, push buttons, and other interfaces as well.
<G-vec00488-002-s270><consider.berücksichtigen><de> Berücksichtigen Sie auch alle Benutzeroberflächen, Schalter, Griffe, Drucktasten und sonstigen Schnittstellen.
<G-vec00488-002-s271><consider.berücksichtigen><en> Shipping costs vary greatly depending on the value of materials and craftsmanship of the item and its final destination of the shipment.Shipping rates are clearly written in the description of each item and are not negotiable.Please consider this when ordering.
<G-vec00488-002-s271><consider.berücksichtigen><de> Versand- und Bearbeitungsgebühren variieren stark von dem Wert der Materialien und Handwerkskunst des Stückes und seiner endgültigen Versand destination.The Versandraten sind klar in der Beschreibung der einzelnen Artikel geschrieben und sind nicht negotiable.Please berücksichtigen Sie dies bei Ihrer Bestellung.
<G-vec00488-002-s272><consider.berücksichtigen><en> Please consider the upcoming holiday on 01th of November 2018 and the resulting shortened working week (calendar week 44) for your transport planning.
<G-vec00488-002-s272><consider.berücksichtigen><de> Bitte berücksichtigen Sie den am 01.11.2018 bevorstehenden Feiertag und die damit verbundene verkürzte Arbeitswoche (KW 44).
<G-vec00488-002-s273><consider.berücksichtigen><en> Consider the comments of just one reviewer: “This is a very poignant criticism of our culture, and one that deserves to be taken seriously.
<G-vec00488-002-s273><consider.berücksichtigen><de> Berücksichtigen Sie die Kommentare von bloß einem Kritiker: „Dies ist eine sehr scharfe Kritik unserer Kultur und eine, die man ernst nehmen muss.
<G-vec00488-002-s274><consider.berücksichtigen><en> Please consider the file system of this software's working folder, as well as the file systems of any network shared folders that are being used.
<G-vec00488-002-s274><consider.berücksichtigen><de> Bitte berücksichtigen Sie das Dateisystem des Arbeitsordners dieser Software, ebenso wie die Dateisysteme aller verwendeten gemeinsamen Netzwerkordner.
<G-vec00488-002-s275><consider.berücksichtigen><en> Cyber insurance. Consider how your cyber insurance policy reimburses for incident response (IR) expenses and ask your insurer about lower premiums if you can show a proactive approach to cyber security.
<G-vec00488-002-s275><consider.berücksichtigen><de> Cyberversicherung: Berücksichtigen Sie, wie Ihre Cyberversicherung die Kosten für Incident-Response-Einsätze erstattet, und erkundigen Sie sich bei Ihrem Versicherungsanbieter, ob die Beiträge niedriger ausfallen, wenn Sie einen proaktiven Cybersicherheitsansatz nachweisen können.
<G-vec00488-002-s276><consider.berücksichtigen><en> Consider only the peculiarities of the climate.
<G-vec00488-002-s276><consider.berücksichtigen><de> Berücksichtigen Sie nur die Besonderheiten des Klimas.
<G-vec00488-002-s277><consider.berücksichtigen><en> Consider also impurities and potentially different substance compositions when developing a read across argument.
<G-vec00488-002-s277><consider.berücksichtigen><de> Berücksichtigen Sie bei der Entwicklung einer Analogiekonzept-Argumentation außerdem Verunreinigungen und potenziell unterschiedliche Stoffzusammensetzungen.
<G-vec00488-002-s278><consider.berücksichtigen><en> You should consider this fact when you name objects in your Access database.
<G-vec00488-002-s278><consider.berücksichtigen><de> Berücksichtigen Sie diese Tatsache, wenn Sie Objekten in Ihrer Access-Datenbank Namen zuweisen.
<G-vec00488-002-s279><consider.berücksichtigen><en> Please consider that due to the deviation your trip from Neuschwanstein to Linderhof will last at least 10 minutes longer, and note the current traffic information.
<G-vec00488-002-s279><consider.berücksichtigen><de> Bitte berücksichtigen Sie bei Ihrer Planung, dass sich durch die Umleitung die Fahrtdauer von Linderhof nach Neuschwanstein um mindestens 10 Minuten verlängert und achten Sie auf die aktuellen Verkehrshinweise.
<G-vec00488-002-s280><consider.berücksichtigen><en> At the same time, consider names that end with a vowel, particularly a short ‘a’ or a long ‘e’ sound.
<G-vec00488-002-s280><consider.berücksichtigen><de> Berücksichtigen Sie gleichzeitig Namen, die mit einem Vokal enden, vor allem solche mit einem kurzen „a“ oder einem langen „e“ am Ende.
<G-vec00488-002-s281><consider.berücksichtigen><en> Consider privacy and protection when designing new systems and processes.
<G-vec00488-002-s281><consider.berücksichtigen><de> Berücksichtigen Sie Privatsphäre und Schutz beim Entwurf neuer Systeme und Verfahren.
<G-vec00488-002-s282><consider.berücksichtigen><en> For information about enabling these settings, see the Microsoft articles Enable TCP/IP Network Protocol for SQL Server and SQL Server Browser Service. Consider the effects of session sharing when planning your Session Recording deployment.
<G-vec00488-002-s282><consider.berücksichtigen><de> Informationen zur Aktivierung dieser Einstellungen finden Sie in den Microsoft-Artikeln Berücksichtigen Sie bei der Planung der Sitzungsaufzeichnungsbereitstellung die Auswirkungen der Sitzungsfreigabe.
<G-vec00488-002-s283><consider.berücksichtigen><en> Consider the implications of specialist groups – for example patients undergoing surgery, elderly, patients in critical care, paediatrics – all of whom may need additional care.
<G-vec00488-002-s283><consider.berücksichtigen><de> Berücksichtigen Sie die Folgen für Expertengruppen – beispielsweise im Falle von Patienten, die vor einer Operation stehen, älteren Patienten, Patienten auf der Intensivstation, in der Kinderklinik – sie alle benötigen zusätzliche Pflege.
<G-vec00488-002-s284><consider.berücksichtigen><en> Several operators in their mode of operation already do consider the bed grain size, determining the rates by sampling and laboratory analysis.
<G-vec00488-002-s284><consider.berücksichtigen><de> Mehrere Betreiber berücksichtigen in ihrer Betriebsweise die Korngröße des Bettes bereits, wobei sie die Werte durch Probenziehen und Laboranalyse ermitteln.
<G-vec00488-002-s399><consider.betrachten><en> Consider two computer games of completely differentGenres, but have gained immense popularity among "gamers" around the world.
<G-vec00488-002-s399><consider.betrachten><de> Betrachten wir zwei völlig unterschiedliche ComputerspieleGenres, aber haben immense Popularität unter "Gamer" auf der ganzen Welt gewonnen.
<G-vec00488-002-s400><consider.betrachten><en> Consider a few reasons for which the site has to be redone.
<G-vec00488-002-s400><consider.betrachten><de> Betrachten wir ein paar Gründe, aus denen die Website muss erneuert werden.
<G-vec00488-002-s401><consider.betrachten><en> Let's talk about how wheat germ oil is useful, consider the properties and its use as a product.
<G-vec00488-002-s401><consider.betrachten><de> Sprechen wir darüber, wie nützlich Weizenkeimöl ist, und betrachten wir die Eigenschaften und die Verwendung als Produkt.
<G-vec00488-002-s402><consider.betrachten><en> For example consider a legacy system with fully functioning DWDM 10G services in a 100 GHz frequency grid.
<G-vec00488-002-s402><consider.betrachten><de> Betrachten wir zum Beispiel ein älteres System mit voll funktionsfähigen DWDM-10G-Services in einem 100-GHz-Frequenznetz.
<G-vec00488-002-s403><consider.betrachten><en> As another example, consider the logic levels of GPIO lines.
<G-vec00488-002-s403><consider.betrachten><de> Betrachten wir als anderes Beispiel die Logikebenen von GPIO-Leitungen.
<G-vec00488-002-s404><consider.betrachten><en> Consider others who share "The Notebook" with you.
<G-vec00488-002-s404><consider.betrachten><de> Betrachten wir andere, die "The Notebook" mit Ihnen teilen.
<G-vec00488-002-s405><consider.betrachten><en> Consider the case of one B2B supplier that wanted to figure out what made some salespeople top performers.
<G-vec00488-002-s405><consider.betrachten><de> Betrachten wir den Fall eines B2B-Anbieters, der herausfinden wollte, was einige Verkäufer zu Top-Performern gemacht hat.
<G-vec00488-002-s406><consider.betrachten><en> Consider a household in the heat exchanger.
<G-vec00488-002-s406><consider.betrachten><de> Betrachten wir einen Haushalt in den Wärmetauscher.
<G-vec00488-002-s407><consider.betrachten><en> Weave on fingers Consider another option, how to weave loom bands bracelet "Caterpillar".
<G-vec00488-002-s407><consider.betrachten><de> Flechten an den Fingern Betrachten wir eine andere Option, wie Sie Weben ein Armband aus Gummibändern "Raupe".
<G-vec00488-002-s408><consider.betrachten><en> Consider a 180 degree turn.
<G-vec00488-002-s408><consider.betrachten><de> Betrachten wir eine 180 Grad-Wende.
<G-vec00488-002-s409><consider.betrachten><en> Consider not the contents by the users of WebMD as medical advice.
<G-vec00488-002-s409><consider.betrachten><de> User generated Content von WebMD betrachten wir nicht als medizinische Beratung.
<G-vec00488-002-s410><consider.betrachten><en> Let's consider in more detail all kinds of material.
<G-vec00488-002-s410><consider.betrachten><de> Betrachten wir alle Arten von Material detaillierter.
<G-vec00488-002-s411><consider.betrachten><en> So let's consider Eastern culture as the origin of the texture velvet; once European countries caught sight of that high-end luxury good, they as well started to create their own industry for velvet velour.
<G-vec00488-002-s411><consider.betrachten><de> Betrachten wir die östliche Kultur als den Ursprung dieser Textilie; als die europäischen Länder dieses hochwertige Luxusgut erblickten, begannen sie eine eigene Industrie für Die Herstellung von Samt aufzubauen.
<G-vec00488-002-s412><consider.betrachten><en> Consider, for example, the systematic counting of plants, spatial planning.
<G-vec00488-002-s412><consider.betrachten><de> Betrachten wir zum Beispiel die systematische Zählung von Pflanzen, die Raumplanung.
<G-vec00488-002-s413><consider.betrachten><en> Let’s consider a concrete example.
<G-vec00488-002-s413><consider.betrachten><de> Betrachten wir ein konkretes Beispiel.
<G-vec00488-002-s414><consider.betrachten><en> To find the answer to this question, consider some examples.
<G-vec00488-002-s414><consider.betrachten><de> Um diese Frage zu beantworten, betrachten wir einige Beispiele.
<G-vec00488-002-s415><consider.betrachten><en> Let’s consider the vanilla flavor first.
<G-vec00488-002-s415><consider.betrachten><de> Betrachten wir zuerst den Vanillegeschmack.
<G-vec00488-002-s416><consider.betrachten><en> Consider now a paradox of transformation of forces.
<G-vec00488-002-s416><consider.betrachten><de> Betrachten wir das Paradoxon von Kräftetransformation.
<G-vec00488-002-s417><consider.betrachten><en> Consider one scenario for the same.
<G-vec00488-002-s417><consider.betrachten><de> Betrachten wir ein Szenario für das gleiche.
<G-vec00488-002-s513><consider.denken><en> Because we wish to consider and act in the interests of subsequent generations as well.
<G-vec00488-002-s513><consider.denken><de> Weil wir auch an unsere nachfolgenden Generationen denken und in Ihrem Sinne handeln wollen.
<G-vec00488-002-s514><consider.denken><en> It matters to consider everything - the most important for me - one has to be able to empathize with the customer and organize the perfect event for him or her.
<G-vec00488-002-s514><consider.denken><de> Es gilt an vieles zu denken und - für mich das Wichtigste - man muss sich in den Kunden einfühlen können und für diesen den perfekten Event organisieren.
<G-vec00488-002-s515><consider.denken><en> Even though China, can be the “land of opportunity” for many businesses and deals can be made overnight, it’s always important to consider the long term.
<G-vec00488-002-s515><consider.denken><de> Auch wenn China für viele Unternehmen das “Land der Chancen” sein kann und Geschäfte über Nacht gemacht werden können, ist es immer wichtig, langfristig zu denken.
<G-vec00488-002-s516><consider.denken><en> This ebony honey is beyond what most guys would consider hardcore.
<G-vec00488-002-s516><consider.denken><de> Diese ebony Honig wird über das hinaus, was die meisten Jungs denken würden, hardcore.
<G-vec00488-002-s517><consider.denken><en> A verse in the Old Testament is one that touches my heart as we consider the principle of love.
<G-vec00488-002-s517><consider.denken><de> Wenn es um den Grundsatz Liebe geht, muss ich an eine Schriftstelle im Alten Testament denken.
<G-vec00488-002-s518><consider.denken><en> Clinical suspicion: It is relevant to consider Blau syndrome when a child presents a combination of symptoms (joint, skin, eye) out of the typical clinical triad.
<G-vec00488-002-s518><consider.denken><de> a) Klinischer Verdacht: Es ist wichtig, an das Blau-Syndrom zu denken, wenn sich ein Kind mit einer Kombination aus den drei typischen klinischen Symptomen (Gelenkschwellung, Hautveränderungen, Augenentzündung) vorstellt.
<G-vec00488-002-s519><consider.denken><en> Our safety concept means that we consider the safety of your plant with every service we offer – from beginning to end.
<G-vec00488-002-s519><consider.denken><de> Unser Sicherheitskonzept bedeutet, dass wir mit jeder Leistung, die wir anbieten, an die Sicherheit Ihrer Anlage denken - von Anfang an und bis zuletzt.
<G-vec00488-002-s520><consider.denken><en> Together with and on behalf of our customers, they consider how to exceed the status quo.
<G-vec00488-002-s520><consider.denken><de> Sie denken mit und für unsere Kunden über die Norm hinaus.
<G-vec00488-002-s521><consider.denken><en> But it would be nonsense to consider trying to make other people become anarchists and suggest that they enter our groups during the struggle.
<G-vec00488-002-s521><consider.denken><de> Es wäre jedoch ein Widersinn, zu denken, die Leute zu Anarchisten werden zu lassen, indem man vorschlägt, in unsere Gruppen einzutreten, zu dem Zweck, den Kampf auf anarchistische Weise anzugehen.
<G-vec00488-002-s522><consider.denken><en> In vain; for Caesar, by hasty marches, anticipated them in every place, nor did he allow any state leisure to consider the safety of others, in preference to their own.
<G-vec00488-002-s522><consider.denken><de> (4) Vergeblich, denn in Eilmärschen trat ihnen Caesar überall entgegen und ließ keinem Stamm Zeit, an seine eigene Rettung, geschweige denn an die anderer zu denken.
<G-vec00488-002-s523><consider.denken><en> We reserve the right to delete your account and all the data included on it, if we consider that you have misused it and / or broken any of these terms and conditions.
<G-vec00488-002-s523><consider.denken><de> Wir behalten uns das Recht vor Ihr Konto und all Ihre Daten darauf zu löschen, sollten wir denken, dass Sie die Geschäftsbedingungen missbrauchen und/oder gebrochen haben.
<G-vec00488-002-s524><consider.denken><en> For Poliński the commotion associated with the restoration of this architectural monument allows an opportunity to work unconventionally, to consider without constraints.
<G-vec00488-002-s524><consider.denken><de> Poliński nutzt die Unruhe der Renovierungsmaßnahmen am denkmalgeschützten Fachwerkbau als Gelegenheit, unkonventionell zu arbeiten – frei zu denken.
<G-vec00488-002-s525><consider.denken><en> We consider that Azerbaijan and Armenia are neighbor states and should live in peace condition.
<G-vec00488-002-s525><consider.denken><de> Wir denken, dass Aserbaidschan und Armenien als Nachbarländer in Frieden und Harmonie leben müssen.
<G-vec00488-002-s526><consider.denken><en> In line with the Paris climate accord, we must consider these issues in all areas of life...
<G-vec00488-002-s526><consider.denken><de> Im Sinne der Pariser Klimaziele müssen wir diese Themen in allen Lebensbereichen denken.
<G-vec00488-002-s527><consider.denken><en> These are images that lead us to consider our behaviour, because both a lack and an excess of salt spoil the taste of food, just as a lack or an excess of light impede vision.
<G-vec00488-002-s527><consider.denken><de> Diese Bilder lassen uns an unser Verhalten denken, denn sowohl der Mangel als auch das Übermaß an Salz machen die Nahrung ungenießbar, ebenso wie der Mangel oder das Übermaß an Licht das Sehen verhindern.
<G-vec00488-002-s528><consider.denken><en> As a luxury brand today we not only have to consider the wellbeing of our customers – we also need to have an increasing awareness of social tasks.
<G-vec00488-002-s528><consider.denken><de> Als Luxusmarke müssen wir heute nicht nur an das Wohl unserer Kunden denken, sondern auch zunehmend gesellschaftliche Aufgaben wahrnehmen.
<G-vec00488-002-s529><consider.denken><en> As this term is only known in the time of Thutmose III, one could now seriously consider them as original Cretan ships that were maintained in the Egyptian naval base.
<G-vec00488-002-s529><consider.denken><de> Im Zusammenhang mit den minoischen Fresken ist nunmehr ernsthaft an original kretische Schiffe zu denken, die in der ägyptischen Flottenstation überholt wurden.
<G-vec00488-002-s530><consider.denken><en> We consider these aspects for you and your office from the very beginning.
<G-vec00488-002-s530><consider.denken><de> Wir denken diese Aspekte von Anfang an für Sie und Ihre Büroräume mit.
<G-vec00488-002-s531><consider.denken><en> Naturally, a person, faced with pain and grief, can consider that the year will not be corrected.
<G-vec00488-002-s531><consider.denken><de> Natürlich kann eine Person, die mit Schmerz und Trauer konfrontiert ist, denken, dass das Jahr nicht korrigiert wird.
<G-vec00488-002-s532><consider.erachten><en> We consider crowdsourcing like a powerful accelerator that allows us to benchmark the market and to collect ideas rapidly.
<G-vec00488-002-s532><consider.erachten><de> Wir erachten Crowdsourcing als wirkungsvollen Beschleuniger, der uns ein Benchmarking des Marktes ermöglicht und gleichzeitig die rasche Sammlung von Ideen.
<G-vec00488-002-s533><consider.erachten><en> At Sigma we consider the capture system to be the key factor in photographic performance.
<G-vec00488-002-s533><consider.erachten><de> Bei Sigma erachten wir das Bilderfassungssystem als Schlüssel für fotografische Leistung.
<G-vec00488-002-s534><consider.erachten><en> As an investor, you’d want to consider it since it offers a sold background with a good price point making it a worthy investment.
<G-vec00488-002-s534><consider.erachten><de> Als Investor sollten Sie es erachten, da es einen soliden Hintergrund mit gutem Preis bietet, was es zu einer würdigen Investition macht.
<G-vec00488-002-s535><consider.erachten><en> Depending on how important you consider individual factors such as the bonus or the design, you should make your decision accordingly.
<G-vec00488-002-s535><consider.erachten><de> Je nachdem, wie wichtig Sie einzelne Faktoren erachten, wie den Bonus oder das Design, sollten Sie Ihre Entscheidung dahingehend ausrichten.
<G-vec00488-002-s536><consider.erachten><en> Where, in our view, there are sufficient grounds for believing that the Contractor has breached one of the foregoing clauses, we shall be entitled to suspend implementation of this contract without notice for as long as we consider it necessary to investigate the relevant conduct.
<G-vec00488-002-s536><consider.erachten><de> 11.10 Bestehen aus unserer Sicht hinreichende Gründe zu der Annahme, dass der Auftragnehmer gegen eine der vorstehenden Klauseln verstoßen hat, sind wir berechtigt, die Ausführung dieses Vertrages solange fristlos auszusetzen, wie wir es für notwendig erachten, um das relevante Verhalten zu untersuchen.
<G-vec00488-002-s537><consider.erachten><en> The list's author noted, "We consider the claims from the Guardians of the Islamic Revolution as the most credible one received so far," but the analysis concluded, "We cannot assign responsibility for this tragedy to any terrorist group at this time.
<G-vec00488-002-s537><consider.erachten><de> Am Ende dieser Liste vermerkte der Autor: „Wir erachten bislang das Bekennen der ‚Beschützer der islamischen Revolution‘ als das glaubwürdigste.“ Abschließend schreibt er: „Bis jetzt können wir die Verantwortung für diese Tragödie keiner Gruppe geben.
<G-vec00488-002-s538><consider.erachten><en> CM Studio /GASTRO-EDITION speaks the language of your guests - depending on the chosen package, we offer any language that you consider as important.
<G-vec00488-002-s538><consider.erachten><de> Mehrsprachigkeit CM Studio spricht die Sprache Ihrer Kunden – je nach gewähltem Paket bieten wir Ihnen jede Sprache die Sie für wichtig erachten.
<G-vec00488-002-s539><consider.erachten><en> Because it is easy to consider that if the humidity of the air decreases, that which already has been drawn into the powder, cannot go so soon by evaporation.
<G-vec00488-002-s539><consider.erachten><de> Denn es ist leicht zu erachten, daß wenn die Feuchtigkeit der Luft abnimmt, diejenige, welche sich schon vorher in das Pulver gezogen, nicht so bald wiederum durch die Ausdünstung davon gehen könne.
<G-vec00488-002-s540><consider.erachten><en> Stakers will not consider any claims or disputes on Games to be valid unless the said Games are directly registered in the Stakers’ database files or records.
<G-vec00488-002-s540><consider.erachten><de> Stakers wird keine Anforderungen oder Beschwerden über Spiele als gültig erachten, es sei denn, die genannten Spiele sind direkt in den Akten oder Aufzeichnungen der Stakers-Datenbank registriert.
<G-vec00488-002-s541><consider.erachten><en> The legislators therefore consider that both legal and technical knowledge is necessary.
<G-vec00488-002-s541><consider.erachten><de> Juristen erachten damit sowohl die Notwendigkeit juristischer als auch technischer Kenntnisse als notwendig.
<G-vec00488-002-s542><consider.erachten><en> Therefore, we consider irregularities in colour, form, texture and size not as a defect but as a characteristic of quality.
<G-vec00488-002-s542><consider.erachten><de> Deshalb erachten wir Unregelmäßigkeiten in Farbe, Form, Textur und Größe nicht als Mangel, sondern als Qualitätsmerkmal.
<G-vec00488-002-s543><consider.erachten><en> A new study of nearly 20,000 teens conducted by researchers from Brigham Young University, USA, found that those who are frequent churchgoers and who consider religion as highly important were half as likely to use marijuana or succumb to peer pressure to smoke and drink.
<G-vec00488-002-s543><consider.erachten><de> Eine neue Studie mit fast 20'000 Jugendlichen, ausgeführt von Forschern der Brigham Young University, USA, fand, dass häufige Kirchgänger und jene, die Religion als sehr wichtig erachten, halb so wahrscheinlich Marijuana konsumierten oder durch den Druck von Peer-Gruppen rauchten oder Alkohol tranken.
<G-vec00488-002-s544><consider.erachten><en> We consider this non-GAAP financial measure to be a useful metric for management and investors because it excludes the effect of share-based compensation expense and related income tax effects so that our management and investors can compare our recurring core business net results over multiple periods.
<G-vec00488-002-s544><consider.erachten><de> Wir erachten diese Non-GAAP-Finanzkennzahl als nützliche Kennzahl für den Vorstand und für Anleger, da sie die Auswirkungen der aktienbasierten Vergütungsaufwendungen und die zugehörigen Einkommensteuereffekte ausklammert, damit unser Vorstand und unsere Anleger unsere wiederkehrenden Nettoergebnisse unseres Kerngeschäfts über mehrere Zeiträume hinweg vergleichen können.
<G-vec00488-002-s545><consider.erachten><en> Nearly two thirds of all Germans over 16 years of age consider sports as important for health.
<G-vec00488-002-s545><consider.erachten><de> Knapp zwei Drittel aller Deutschen über 16 Jahren erachten Sport als wichtig für die Gesundheit.
<G-vec00488-002-s546><consider.erachten><en> Even in cases of commissioned articles such as product reviews, bloggers should write whatever they consider to be correct.
<G-vec00488-002-s546><consider.erachten><de> Selbst bei beauftragten Artikeln, etwa Produktbesprechungen, sollten sie schreiben dürfen, wie und was sie für gut erachten.
<G-vec00488-002-s547><consider.erachten><en> We consider patients fundamentally as independent and autonomous individuals, with different needs.
<G-vec00488-002-s547><consider.erachten><de> Wir erachten Patientinnen und Patienten grundsätzlich als selbständige und eigenverantwortliche Persönlichkeiten mit unterschiedlichen Bedürfnissen.
<G-vec00488-002-s548><consider.erachten><en> We may commission third parties for the implementation of all translation project work insofar as we consider this to be purposeful or required.
<G-vec00488-002-s548><consider.erachten><de> 3.2 Wir dürfen uns zur Ausführung aller Geschäfte, sofern wir dies für zweckmässig oder erforderlich erachten, Dritter bedienen.
<G-vec00488-002-s549><consider.erachten><en> If you do not want to accept this, if you consider information or documents to be sent to us in need of secrecy, or if you have data protection concerns of any kind please do not send us any e-Mails nor should you provide us with your e-mail address.
<G-vec00488-002-s549><consider.erachten><de> Falls Sie das nicht akzeptieren möchten, falls Sie uns zu übersendende Informationen oder Dokumente für geheimhaltungsbedürftig erachten, oder falls Sie datenschutzrechtliche Bedenken irgendwelcher Art haben, dann senden Sie uns bitte keine E-Mails, und teilen Sie uns auch nicht Ihre E-Mail Adresse mit.
<G-vec00488-002-s550><consider.erachten><en> If we consider a candidate adequate, we will call former employers for reference checks and this will give us an overall picture.
<G-vec00488-002-s550><consider.erachten><de> Erachten wir eine(n) Kandidatin(en) als geeignet, werden wir - um uns ein ganzheitliches Bild machen zu können - bei den ehemaligen Arbeitgebern Referenzen einholen.
<G-vec00488-002-s551><consider.erwägen><en> 2 Consider optional features.
<G-vec00488-002-s551><consider.erwägen><de> 2 Erwäge bestimmte Zusatzfunktionen.
<G-vec00488-002-s552><consider.erwägen><en> Consider adding some light oil.
<G-vec00488-002-s552><consider.erwägen><de> Erwäge, etwas leichtes Öl hinzuzugeben.
<G-vec00488-002-s553><consider.erwägen><en> Consider putting a hot wet towel around your beard and neck area.
<G-vec00488-002-s553><consider.erwägen><de> Erwäge, ein heißes, nasses Handtuch um deinen Bart- und Halsbereich zu legen.
<G-vec00488-002-s554><consider.erwägen><en> Consider starting with a layered braless look.
<G-vec00488-002-s554><consider.erwägen><de> Erwäge, mit einem BH-freien Layer-Look anzufangen.
<G-vec00488-002-s555><consider.erwägen><en> Consider alternative therapies.
<G-vec00488-002-s555><consider.erwägen><de> Erwäge alternative Therapien.
<G-vec00488-002-s556><consider.erwägen><en> CRITIAS Consider now, Socrates, the order of the feast as we have arranged it.
<G-vec00488-002-s556><consider.erwägen><de> KRITIAS Erwäge aber, Sokrates, die von uns festgestellte Aufeinanderfolge der dir bestimmten Gastgeschenke.
<G-vec00488-002-s557><consider.erwägen><en> Avoid these substances if possible, and consider rinsing your mouth out with water right after you enjoy them.
<G-vec00488-002-s557><consider.erwägen><de> Vermeide diese wenn möglich und erwäge, deinen Mund direkt im Anschluss mit Wasser auszuspülen, wenn du sie zu dir genommen hast.
<G-vec00488-002-s558><consider.erwägen><en> Consider helping others out where you can, to contribute back for the help you get.
<G-vec00488-002-s558><consider.erwägen><de> Erwäge anderen zu helfen, wo Du nur kannst, um Deinen Teil beizutragen.
<G-vec00488-002-s559><consider.erwägen><en> Consider adding push-up variations such as military push-ups, chest squeeze push-ups, and archer push-ups after three to four weeks to give your chest a new challenge.
<G-vec00488-002-s559><consider.erwägen><de> Erwäge nach drei bis vier Wochen zusätzliche Variationen der Liegestütz, wie militärische Liegestütz, enge Brust-Liegestütz oder Archer-Liegestütz und biete deinen Brustmuskeln eine neue Herausforderung.
<G-vec00488-002-s560><consider.erwägen><en> 7 Consider packing wet towelettes.
<G-vec00488-002-s560><consider.erwägen><de> 7 Erwäge, Feuchttücher einzupacken.
<G-vec00488-002-s561><consider.erwägen><en> If you’re not sure whether you’re applying your makeup properly or not, consider asking for a consultation at a makeup counter where you purchase products.
<G-vec00488-002-s561><consider.erwägen><de> Wenn du dir nicht sicher bist, ob du das Make-up richtig aufträgst oder nicht, erwäge, in der Kosmetikabteilung oder dort, wo du deine Produkte kaufst, um eine Beratung zu bitten.
<G-vec00488-002-s562><consider.erwägen><en> If you have a very dry scalp, consider leaving the oil on overnight.
<G-vec00488-002-s562><consider.erwägen><de> Erwäge, das Öl über Nacht einwirken zu lassen, wenn deine Kopfhaut sehr trocken ist.
<G-vec00488-002-s563><consider.erwägen><en> 14 In the day of prosperity be joyful, and in the day of adversity consider: God has made the one as well as the other, so that man may not find out anything that will be after him.
<G-vec00488-002-s563><consider.erwägen><de> 14 Am guten Tage sei guter Dinge, und am bösen Tage, da erwäge: auch diesen hat Gott ebenso wie jenen gemacht, damit der Mensch nicht ausfindig mache, was nach ihm geschieht7.
<G-vec00488-002-s564><consider.erwägen><en> Consider moving files to external storage.
<G-vec00488-002-s564><consider.erwägen><de> Erwäge, die Dateien auf einen externen Speicher zu verschieben.
<G-vec00488-002-s565><consider.erwägen><en> Consider applying peppermint lotion to your feet also, as it will tingle and invigorate them.
<G-vec00488-002-s565><consider.erwägen><de> Erwäge auch, deine Füße mit einer Pfefferminzlotion zu behandeln, da diese auf der Haut prickeln und die Füße beleben wird.
<G-vec00488-002-s566><consider.erwägen><en> Consider joining a volunteer organization for the needy.
<G-vec00488-002-s566><consider.erwägen><de> Erwäge einer ehrenamtlichen Organisation für bedürftige Menschen beizutreten.
<G-vec00488-002-s567><consider.erwägen><en> Consider the benefits and drawbacks of quantitative research.
<G-vec00488-002-s567><consider.erwägen><de> Erwäge die Vor- und Nachteile der quantitativen Recherche.
<G-vec00488-002-s568><consider.erwägen><en> Consider seeing a therapist or joining a support group if you feel overwhelmed, and try to maintain healthy routines: a nutritious diet, regular exercise, and plenty of sleep.
<G-vec00488-002-s568><consider.erwägen><de> Erwäge, einen Therapeuten aufzusuchen oder werde Mitglied in einer Selbsthilfegruppe falls du dich überwältigt fühlst.
<G-vec00488-002-s569><consider.erwägen><en> Consider pouring the oil into a small bottle with an eye dropper.
<G-vec00488-002-s569><consider.erwägen><de> Erwäge, das Öl in eine kleine Flasche mit einer Pipette zu füllen.
<G-vec00488-002-s703><consider.halten><en> Many of our readers consider the FX 5200 a "DirectX8 board" because the execution speed of DirectX9 shaders is rather slow.
<G-vec00488-002-s703><consider.halten><de> Viele unser Leser halten die FX 5200 für eine "DirectX8-Karte", weil die Ausführungsgeschwindigkeit von DirectX9-Shadern ziemlich niedrig ist.
<G-vec00488-002-s704><consider.halten><en> Many people consider it an imagination when they are able to see something.
<G-vec00488-002-s704><consider.halten><de> Viele Menschen halten es für eine Vorstellung, wenn sie etwas sehen können.
<G-vec00488-002-s705><consider.halten><en> Some BPMN experts consider collaboration diagrams, i.e. the modeling of different process participants in different pools, only as a pattern for business-to-business-collaboration.
<G-vec00488-002-s705><consider.halten><de> Einige BPMN-Experten halten Kolloborationsdiagramme, also die Modellierung unterschiedlicher Prozessbeteiligter in jeweils eigenen Pools, nur für sinnvoll, um die Zusammenarbeit unterschiedlicher Unternehmen (B2B) darzustellen.
<G-vec00488-002-s706><consider.halten><en> In addition to reconfirming the framework and principles it collectively adopted in December 2009, we consider it vital that the Council should also identify concrete measures to operationalize its agreed policy and thence move to implementation of the agreed objectives.
<G-vec00488-002-s706><consider.halten><de> Außer der erneuten Bestätigung der Rahmenbedingungen und Grundsätze, die er im Dezember 2009 kollektiv angenommen hat, halten wir es für unerlässlich, dass der Rat auch konkrete Maßnahmen festlegt, um seine vereinbarte Politik umzusetzen und sich so auf die Erfüllung der vereinbarten Ziele hinbewegt.
<G-vec00488-002-s707><consider.halten><en> Nevertheless, we consider it unjustified to extinguish those works of Simonov, which once served the Soviet Union of Lenin and Stalin.
<G-vec00488-002-s707><consider.halten><de> Gleichwohl halten wir es für ungerechtfertigt, deswegen auch jenes Schaffen von Simonow auszulöschen, das einst der Sowjetunion Lenins und Stalins gedient hat.
<G-vec00488-002-s708><consider.halten><en> But this sudden defeatism was not internationalism, but a distorted variety of patriotism —these gentlemen consider their fatherland to be the Kremlin, on which their welfare depends.
<G-vec00488-002-s708><consider.halten><de> Aber dieser plötzliche Defätismus war nicht Internationalismus, sondern eine verzerrte Spielart des Patriotismus – diese Herren halten den Kreml, von dem ihr Wohlergehen abhängt, für ihr Vaterland.
<G-vec00488-002-s709><consider.halten><en> Over 70 percent of the organizers consider World Snow Day very helpful when it comes to bringing new customers to ski resorts.
<G-vec00488-002-s709><consider.halten><de> Über 70 Prozent der Organisatoren halten den World Snow Day für sehr hilfreich, wenn es darum geht, neue Kunden in die Ski-Resorts zu bringen.
<G-vec00488-002-s710><consider.halten><en> Some consider walking up and down the best, others prefer lying prostrate.
<G-vec00488-002-s710><consider.halten><de> Manche halten das Auf- und Abgehen für das Beste, andere die liegende Haltung.
<G-vec00488-002-s711><consider.halten><en> Therefore, we consider the division into View Key, Spend Key and Payment ID very reasonable and helpful.
<G-vec00488-002-s711><consider.halten><de> Daher halten wir die Einteilung in View Key, Spend Key und Payment-ID für sehr findig und hilfreich.
<G-vec00488-002-s712><consider.halten><en> Many consider touching ourselves ‘down there’ to be a sin, something dirty that deserves condemnation.
<G-vec00488-002-s712><consider.halten><de> Viele halten sich "da unten" zu berühren für Sünde, etwas Dreckiges, das es verdient verdammt zu werden.
<G-vec00488-002-s713><consider.halten><en> But for some reason, the surrounding people consider it necessary to continually advise something, even if the pregnancy is not the first and there were already wonderful births behind, and wonderful healthy children grow up in the family.
<G-vec00488-002-s713><consider.halten><de> Aber aus irgendeinem Grund halten die umliegenden Menschen es für notwendig, ständig etwas zu beraten, auch wenn die Schwangerschaft nicht die erste ist und bereits wunderbare Geburten dahinter standen und wunderbare gesunde Kinder in der Familie aufwachsen.
<G-vec00488-002-s714><consider.halten><en> We consider a duty to thank the Mr. Pesakh Kaplan who did not regret efforts and wrote notes to these marches which I to him sang on memory 8.
<G-vec00488-002-s714><consider.halten><de> Wir halten für eine Pflicht, Herrn Pessacha Kaplan zu danken, der nicht bemitleidend die Bemühungen und die Noten zu diesen Märschen schrieb, die ich mich ihm nach dem Gedächtnis 8 vor hin gesungen habe.
<G-vec00488-002-s715><consider.halten><en> Many consider it an ideal substitute for Deca-Durabolin.
<G-vec00488-002-s715><consider.halten><de> Viele halten es für einen idealen Ersatz für Deca-Durabolin.
<G-vec00488-002-s716><consider.halten><en> 500 Piece/Pieces if you want to test the market we can consider low the MOQ . Port:
<G-vec00488-002-s716><consider.halten><de> 500 Stück/Stücke wenn Sie den Markt prüfen möchten, können wir Tief halten für das MOQ.
<G-vec00488-002-s717><consider.halten><en> We consider a detailed acquaintance, with us in the stable, very important.
<G-vec00488-002-s717><consider.halten><de> Ein ausführliches Kennenlernen, bei uns im Stall, halten wir für sehr wichtig.
<G-vec00488-002-s718><consider.halten><en> Many historians and political scientists consider this term inappropriate for the modern context.
<G-vec00488-002-s718><consider.halten><de> Viele Historiker und Politikwissenschaftler halten diesen Begriff für den modernen Kontext für unangemessen.
<G-vec00488-002-s719><consider.halten><en> Therefore, we consider it is our duty to draw your attention to certain dangers.
<G-vec00488-002-s719><consider.halten><de> Daher halten wir es für unsere Pflicht, Ihre Aufmerksamkeit auf gewisse Gefahren zu ziehen.
<G-vec00488-002-s720><consider.halten><en> Another figure is also highly interesting: When asked about reducing bureaucracy, 44% say that this topic is “very important”, and 26% even consider it “most important.”
<G-vec00488-002-s720><consider.halten><de> Hochinterressant ist eine weitere Zahl: Befragt nach dem Abbau von Bürokratie, sagen 44 %, dieses Thema sei „sehr wichtig“, 26 % halten dies sogar für „am wichtigsten“.
<G-vec00488-002-s721><consider.halten><en> A lot of people consider that the persecution of Falun Gong in China is the biggest violation against human rights.
<G-vec00488-002-s721><consider.halten><de> Viele Menschen halten die Verfolgung in China für die schwerste Menschenrechtsverletzung überhaupt.
<G-vec00488-002-s456><consider.nachdenken><en> We tell you the amazing truth about breast milk’s benefits after six months, and why every breastfeeding mum should consider it. References
<G-vec00488-002-s456><consider.nachdenken><de> Hier kommen die faszinierenden Fakten über die Vorteile von Muttermilch nach dem sechsten Monat und warum jede stillende Mutter darüber nachdenken sollte.
<G-vec00488-002-s457><consider.nachdenken><en> Apart from the consent given by the employee, the employer should consider whether or not the employee using the device/vehicle has any expectations with regard to privacy or not.
<G-vec00488-002-s457><consider.nachdenken><de> Abgesehen von der Zustimmung des Arbeitnehmers sollte der Arbeitgeber darüber nachdenken, ob der Mitarbeiter, der das Gerät / Fahrzeug nutzt, irgendwelche Erwartungen hinsichtlich der Privatsphäre hat oder nicht.
<G-vec00488-002-s458><consider.nachdenken><en> Let him also consider what his mind is, and what he himself as a conscious principle is.
<G-vec00488-002-s458><consider.nachdenken><de> Lassen Sie ihn auch darüber nachdenken, was sein Geist ist und was er selbst als bewusstes Prinzip ist.
<G-vec00488-002-s459><consider.nachdenken><en> With new technologies we have an enormous ability to generate more traffic but we have to consider whether this makes it easier to ‘share’?
<G-vec00488-002-s459><consider.nachdenken><de> Dank neuer Technologien haben wir eine enorme Fähigkeit, mehr E-Mail-Volumen zu erzeugen, müssen jedoch darüber nachdenken, ob das „Teilen“ hierdurch einfacher wird.
<G-vec00488-002-s460><consider.nachdenken><en> I think UNESCO should urgently consider making Pastéis de Belém a culinary heritage.
<G-vec00488-002-s460><consider.nachdenken><de> Ich finde, die UNESCO sollte dringend darüber nachdenken, die Pastéis de Belém zum kulinarischen Kulturerbe zu erheben.
<G-vec00488-002-s461><consider.nachdenken><en> You can consider including recipes and facts about tea to broaden your output.
<G-vec00488-002-s461><consider.nachdenken><de> Du kannst darüber nachdenken, Rezepte und Fakten über Tee beizulegen, um mehr nach draußen zu geben.
<G-vec00488-002-s462><consider.nachdenken><en> Further, expanding the sphere of participants beyond your organisation can prove to be a true game changer in ideation: you should consider involving industry experts, customers, suppliers or industry partners.
<G-vec00488-002-s462><consider.nachdenken><de> Außerdem kann es sich als entscheidender Schritt für den Erfolg der Ideenfindung erweisen, den Teilnehmerkreis über das eigene Unternehmen hinaus auszudehnen: Sie sollten darüber nachdenken, Branchenexperten, Kunden, Lieferanten oder Industriepartnern hinzuzuziehen.
<G-vec00488-002-s463><consider.nachdenken><en> As we consider what transpired then and since, we find that the global Bahá’í community now in view is not the same as when it embarked on the first six cycles of the current Plan.
<G-vec00488-002-s463><consider.nachdenken><de> Wenn wir darüber nachdenken, was damals und seitdem geschehen ist, stellen wir fest, dass die weltweite Bahá’í-Gemeinde, die wir jetzt sehen, nicht die gleiche ist wie zu der Zeit, als sie sich zu den ersten sechs Zyklen des aktuellen Plans aufmachte.
<G-vec00488-002-s464><consider.nachdenken><en> Goblet: 4:89... so that they may consider this and search for the way to the truth.
<G-vec00488-002-s464><consider.nachdenken><de> Kelch: 4:89... auf dass sie darüber nachdenken und den Weg zur Wahrheit suchen.
<G-vec00488-002-s465><consider.nachdenken><en> The worker should most earnestly consider what he really wants, how he means to achieve it, by what methods.
<G-vec00488-002-s465><consider.nachdenken><de> Der Arbeiter muss ernsthaft darüber nachdenken, was er wirklich will und mit welchen Methoden er sein Ziel zu erreichen hofft.
<G-vec00488-002-s466><consider.nachdenken><en> Brands also need to consider how they’re perceived in China.
<G-vec00488-002-s466><consider.nachdenken><de> Brands müssen zudem darüber nachdenken, wie sie in China wahrgenommen werden.
<G-vec00488-002-s467><consider.nachdenken><en> In many (if not most) cases, people are not even aware they believe these things, because they so much take them for granted that they never consider whether they are reasonable or resourceful beliefs (which I think is a much better way to evaluate what you believe than whether or not it is "true').
<G-vec00488-002-s467><consider.nachdenken><de> In vielen (wenn nicht den meisten) Fällen ist Menschen gar nicht bewusst, dass sie diese Dinge glauben, weil sie sie so sehr als selbstverständlich betrachten, dass sie nie darüber nachdenken, ob es sinnvolle oder hilfreiche Überzeugungen sind (was meiner Meinung nach eine wesentlich bessere Art ist, zu bewerten was man glaubt, als das Kriterium von "wahr" oder "nicht wahr").
<G-vec00488-002-s468><consider.nachdenken><en> Tank Tip: In order to improve your horrendous reload time, consider taking a Case of Cola with you into battle.
<G-vec00488-002-s468><consider.nachdenken><de> Panzertipp: Wenn ihr eure entsetzliche Nachladezeit verbessern wollt, solltet ihr darüber nachdenken, eine Kiste Cola mit ins Gefecht zu nehmen.
<G-vec00488-002-s469><consider.nachdenken><en> Also those who believe that their neat little chip makes their device a healing device should really consider who they are serving with this in reality.
<G-vec00488-002-s469><consider.nachdenken><de> Und auch diejenigen, die meinen, dass ihr toller Chip ihr Gerät zum Heilgerät macht, sollten auch mal wirklich darüber nachdenken, wem sie da in Wirklichkeit mit dienen.
<G-vec00488-002-s470><consider.nachdenken><en> I would certainly consider going back.
<G-vec00488-002-s470><consider.nachdenken><de> Ich würde mit Sicherheit darüber nachdenken, zurückzukommen.
<G-vec00488-002-s471><consider.nachdenken><en> The deacons and the elders who are not born again usually say, “I want to live virtuously, but I don’t know why it’s so difficult.” We must consider why they cannot help but live this way.
<G-vec00488-002-s471><consider.nachdenken><de> Die Diakone und Vorsitzenden, die nicht wiedergeboren sind, sagen normalerweise: „Ich will tugendhaft leben, aber ich weiß nicht, warum das so schwer ist.“ Wir müssen darüber nachdenken, warum sie nicht anders können, als so zu leben.
<G-vec00488-002-s472><consider.nachdenken><en> These are the cheapest seats you can buy, but once again, please consider that you will have to survive 17 hours in a seats only carriage before you reach Hat Yai.
<G-vec00488-002-s472><consider.nachdenken><de> Sie sind die billigsten Sitzplätze, die Sie überhaupt kaufen können, allerdings sollten Sie nochmals darüber nachdenken, dass Sie an die 17 Stunden auf einem dieser Sitze ausharren müssen, bis Sie Hat Yai erreichen.
<G-vec00488-002-s473><consider.nachdenken><en> As early as the procurement phase, manufacturers, suppliers, and service providers must consider how a system can remain operational and have access to spare parts throughout its complete life cycle.
<G-vec00488-002-s473><consider.nachdenken><de> Hersteller, Lieferanten und Dienstleister müssen bereits bei der Beschaffung gemeinsam darüber nachdenken, wie ein System betriebsbereit bleibt und über die gesamte Lebensdauer Zugang zu einer Ersatzteilversorgung hat.
<G-vec00488-002-s474><consider.nachdenken><en> Server owners may also want to consider giving moderator/admin rights to some trusted players on the server and to enable vote kicking.
<G-vec00488-002-s474><consider.nachdenken><de> Serverbesitzer sollten auch darüber nachdenken, vertrauenswürdigen Usern Moderator/Admin Rechte zu geben und Vote Kicking einzustellen.
<G-vec00488-002-s779><consider.prüfen><en> You should carefully consider whether such trading is suitable for you in light of your financial condition, level of experience and appetite for risk, and seek advice from an independent financial adviser, if you have any doubts. Log in
<G-vec00488-002-s779><consider.prüfen><de> Sie sollten sorgfältig prüfen, ob ein solcher Handel für Sie angesichts Ihrer finanziellen Lage, Ihres Erfahrungsstands und Ihrer Risikobereitschaft geeignet ist, und sich bei Zweifeln an einen unabhängigen Finanzberater wenden.
<G-vec00488-002-s780><consider.prüfen><en> It is important to carefully consider all the nuances - and do dishes, and their clearance.
<G-vec00488-002-s780><consider.prüfen><de> Es ist wichtig, alle Details sorgfältig zu prüfen - und abwaschen, und ihre Clearance.
<G-vec00488-002-s781><consider.prüfen><en> Sinister indeed, but maybe we still have a couple of days to consider what is to come and its meaning: Prison Planet 10 March 2011: “When cycle forecaster Charles Nenner told the Fox Business network yesterday that the Dow Jones was set to collapse to the 5,000 level on the back of a “major war” that will shake the globe at the end of 2012, hosts David Asman and Elizabeth MacDonald sat in stunned silence.
<G-vec00488-002-s781><consider.prüfen><de> Unheimlich, ja, aber vielleicht haben wir noch ein paar Tage, um zu prüfen, was uns bevorsteht, sowie dessen Bedeutung: Prison Planet 10 March 2011: “Als der Zyklus-Vorhersager, Charles Nenner, gestern dem Fox Business Network sagte, der Dow Jones werde auf 5.000 Punkten infolge eines “großen Krieges”, der die Erde Ende des Jahres 2012 ershüttern werde, fallen, saßen Gastgeber David und Elizabeth MacDonald Asman betäubt in Schweigen.
<G-vec00488-002-s782><consider.prüfen><en> The staff therefore thinks that the Board should consider whether to make narrow amendments to IFRS Standards to provide relief from discontinuing hedge accounting.
<G-vec00488-002-s782><consider.prüfen><de> Der Stab ist daher der Ansicht, dass der Board prüfen sollte, ob er die IFRS eng umrissen anpassen sollte, um vom Aufgeben des Hedge Accounting Erleichterung zu schaffen.
<G-vec00488-002-s783><consider.prüfen><en> We have to consider these questions afresh, because if we don t do so, others will.
<G-vec00488-002-s783><consider.prüfen><de> Wir müssen diese Fragen erneut prüfen, denn wenn wir es nicht tun, werden es andere tun.
<G-vec00488-002-s784><consider.prüfen><en> Density of knots are very important only for city woven carpets but for nomadic carpets we do not consider the density of knots.
<G-vec00488-002-s784><consider.prüfen><de> Dichte der Knoten ist sehr wichtig für die in der Stadt gewebten Teppiche, aber für die nomadischen Teppiche prüfen wir die Dichte der Knoten nicht.
<G-vec00488-002-s785><consider.prüfen><en> 5.The Dutch delegation requests the ADN Safety Committee to consider the proposed amendment in paragraph 4 and to take action as it deems appropriate.
<G-vec00488-002-s785><consider.prüfen><de> 5.Die niederländische Delegation bittet den ADN-Sicherheitsausschuss, den Änderungsvorschlag in Absatz 4 zu prüfen und die aus seiner Sicht notwendigen Maßnahmen zu ergreifen.
<G-vec00488-002-s786><consider.prüfen><en> 2. The Community institution or body referred to in paragraph 1 shall consider any such request, unless it is clearly unsubstantiated.
<G-vec00488-002-s786><consider.prüfen><de> (2) Die in Absatz 1 genannten Organe oder Einrichtungen der Gemeinschaft prüfen jeden derartigen Antrag, sofern dieser nicht offensichtlich unbegründet ist.
<G-vec00488-002-s787><consider.prüfen><en> Because we are open to suggestions and will be ready to consider whether we can fulfil this goal in one of our departments.
<G-vec00488-002-s787><consider.prüfen><de> Denn wir sind offen für Vorschläge und prüfen, ob wir diesem Wunsch in einer unserer Abteilungen nachkommen können.
<G-vec00488-002-s788><consider.prüfen><en> You should consider, and test, the types of queries that are likely to be performed to see whether performance improves with clustered indexes.
<G-vec00488-002-s788><consider.prüfen><de> Sie sollten die Typen von Abfragen, die wahrscheinlich durchgeführt werden, prüfen und testen, ob die Performance durch die Clustered-Indizes verbessert wird.
<G-vec00488-002-s789><consider.prüfen><en> Then it is necessary to consider what data is needed in each of these systems in order to generate the maximum benefit.
<G-vec00488-002-s789><consider.prüfen><de> Dann ist es notwendig zu prüfen, welche Daten in welchen Systemen benötigt werden, um hier den größtmöglichen Nutzen zu generieren.
<G-vec00488-002-s790><consider.prüfen><en> We will carefully consider your request as there may be circumstances which require us to, or allow us to, continue processing your data.
<G-vec00488-002-s790><consider.prüfen><de> Wir werden Ihren Antrag sorgfältig prüfen, da es Umstände gibt, die es für uns erforderlich machen, oder es uns erlauben, Ihre persönlichen Informationen weiterhin zu verarbeiten.
<G-vec00488-002-s791><consider.prüfen><en> The Council also noted that, given the important role to be played by biomass, full account should be taken of renewables in the development of Community policies on agriculture and waste management, inviting the Commission to consider the need for proposals to remove obstacles to the greater use of renewables.
<G-vec00488-002-s791><consider.prüfen><de> Ferner stellte er fest, dass wegen der wichtigen Rolle, die die Biomasse spielen wird, bei der Entwicklung von Gemeinschaftspolitiken im Bereich Landwirtschaft und Abfallwirtschaft den erneuerbaren Energieträgern uneingeschränkt Rechnung zu tragen ist, und forderte die Kommission auf, zu prüfen, ob Vorschläge zur Beseitigung von Hindernissen für eine breitere Nutzung erneuerbarer Energieträger erforderlich sind.
<G-vec00488-002-s792><consider.prüfen><en> You have to consider if battery is good enough before you buy and consider whether the price is reasonable to get the scooter.
<G-vec00488-002-s792><consider.prüfen><de> Sie haben zu prüfen, ob der Akku ist gut genug, bevor Sie kaufen und prüfen, ob der Preis angemessen ist, den Roller zu erhalten.
<G-vec00488-002-s794><consider.prüfen><en> We invite you to consider our offer and buy an apartment in a residential complex located directly on the beach.
<G-vec00488-002-s794><consider.prüfen><de> Wir laden Sie ein, unser Angebot zu prüfen und eine Wohnung in einer Wohnanlage direkt am Strand zu kaufen.
<G-vec00488-002-s795><consider.prüfen><en> If a new unknown communication is detected, you must carefully consider whether to allow or deny it.
<G-vec00488-002-s795><consider.prüfen><de> Wenn eine neue, unbekannte Verbindung erkannt wird, sollten Sie genau prüfen, ob diese zugelassen oder blockiert werden soll.
<G-vec00488-002-s796><consider.prüfen><en> 3. In the event of the original arbitration panel, or some of its members, being unable to reconvene to consider a request under paragraph 2, a new arbitration panel shall be established as set out in Article 171.
<G-vec00488-002-s796><consider.prüfen><de> (3) Für den Fall, dass das ursprüngliche Schiedspanel oder einige seiner Mitglieder nicht zusammentreten können, um ein Ersuchen nach Absatz 2 zu prüfen, wird ein neues Schiedspanel nach Artikel 171 eingesetzt.
<G-vec00488-002-s797><consider.prüfen><en> The Technical Board of Appeal is invited by the appellants to consider whether referral of the point of law to the Enlarged Board of Appeal would be appropriate.
<G-vec00488-002-s797><consider.prüfen><de> Die Technische Beschwerdekammer wird von der Beschwerdeführerin aufgefordert, zu prüfen, ob nicht die Große Beschwerdekammer mit dieser Rechtsfrage befaßt werden sollte.
<G-vec00488-002-s817><consider.sehen><en> We consider ourselves one of the leading dental practices and implantology centres in the region.
<G-vec00488-002-s817><consider.sehen><de> Wir sehen uns als eine der führenden Zahnarztpraxen und implantologischen Zentren der Region.
<G-vec00488-002-s818><consider.sehen><en> We consider this a beautiful action towards the comunity.
<G-vec00488-002-s818><consider.sehen><de> Wir sehen dies als eine schöne Geste gegenüber der Gemeinschaft.
<G-vec00488-002-s819><consider.sehen><en> According to the Cisco survey, companies consider these two advantages of mobility – employee productivity and better customer service – to be the most important.
<G-vec00488-002-s819><consider.sehen><de> Diese beiden Vorteile von Mobilität – Mitarbeiterproduktivität und besserer Kundenservice – sehen Unternehmen laut Cisco-Studie als die größten an.
<G-vec00488-002-s820><consider.sehen><en> We don’t consider ourselves as heroes or particularly positive characters.
<G-vec00488-002-s820><consider.sehen><de> Wir sehen uns selbst nicht als Helden oder als besonders gute Menschen.
<G-vec00488-002-s821><consider.sehen><en> In addition, the national parliaments consider themselves to be better legislators when it comes to organising social and health systems. Next steps…
<G-vec00488-002-s821><consider.sehen><de> Zudem sehen die nationalen Parlamente sich als die besseren Gesetzgeber, wenn es um die Ausgestaltung der Sozial- und Gesundheitssysteme geht.
<G-vec00488-002-s822><consider.sehen><en> Contrary to these facts, many expanding companies consider presenting their content in one other language, in particular by translating it into English, to be sufficient.
<G-vec00488-002-s822><consider.sehen><de> Entgegen dieser Fakten sehen viele expandierende Unternehmen die Darbietung ihrer Inhalte in eine weitere Sprache, nämlich durch eine Übersetzung ins Englische, als ausreichend an.
<G-vec00488-002-s823><consider.sehen><en> We consider this another form of impolite spam and just send you a reply pointing at this webpage.
<G-vec00488-002-s823><consider.sehen><de> Wir sehen dies als eine weitere Form von unhöflichem Spam und antworten oftmals mit einem Link auf diese Seite.
<G-vec00488-002-s824><consider.sehen><en> They consider the line of imams to be not only the political leaders of the Muslims, but also the religious authorities.
<G-vec00488-002-s824><consider.sehen><de> Sie sehen die Linie der Imame nicht nur als politische Führer der Muslime, sondern auch als die religiöse Autorität an.
<G-vec00488-002-s825><consider.sehen><en> At R-Biopharm we consider it our corporate responsibility to deliver high-quality products while acting in a socially and ecologically acceptable way.
<G-vec00488-002-s825><consider.sehen><de> Bei R-Biopharm sehen wir es als unsere unternehmerische Verantwortung an, qualitativ hochwertige Produkte zu liefern und dabei sozial und ökologisch verträglich zu handeln.
<G-vec00488-002-s826><consider.sehen><en> As a family-owned company we consider it our obligation to share our business success with people who, for various reasons, need particular support.
<G-vec00488-002-s826><consider.sehen><de> Als Familienunternehmen sehen wir es als unsere Verpflichtung an, an unserem Unternehmenserfolg Menschen teilhaben zu lassen, die aus verschiedensten Gründen Unterstützung benötigen.
<G-vec00488-002-s827><consider.sehen><en> As a producer of dried raw materials for the production of durable foods, we consider ourselves a representative of the "critical infrastructure" and contribute to the security of supply for the population.
<G-vec00488-002-s827><consider.sehen><de> Als Produzent von getrockneten Rohstoffen für die Herstellung von haltbaren Lebensmitteln, sehen wir uns als einen Vertreter der „kritischen Infrastruktur“ an und tragen zur Versorgungssicherheit der Bevölkerung bei.
<G-vec00488-002-s828><consider.sehen><en> “We were initially quite critical about PromoTex Expo but now we are very satisfied and consider hiving off the textile segment from PSI as a separate trade show a good move.
<G-vec00488-002-s828><consider.sehen><de> Inzwischen sind wir aber sehr zufrieden und sehen es als positiven Schritt, den Textilbereich in einer eigenen Messe aus der PSI auszugliedern.
<G-vec00488-002-s829><consider.sehen><en> As an ISO14001 certified organisation we consider the environment to be integral to all our business activities, and we are keen to contribute towards a sustainable society.
<G-vec00488-002-s829><consider.sehen><de> Als Unternehmen, das ISO 14001 zertifiziert ist, sehen wir die Umwelt, Gesundheit und Sicherheit als wesentlichen Teil unserer Geschäftsaktivitäten und sind sehr bestrebt, zu einer nachhaltigen Gesellschaft beizutragen.
<G-vec00488-002-s830><consider.sehen><en> That is why we consider it’s our obligation to publish on our site the following declaration on word of honor...
<G-vec00488-002-s830><consider.sehen><de> Deswegen sehen wir es als unsere Pflicht, an dieser Stelle folgende Ehrenerklärung unseres Stofflieferanten zu veröffentlichen: mehr...
<G-vec00488-002-s831><consider.sehen><en> Due to our established reputation as experts in protection gear we consider it our main responsibility to constantly improve our products in order to strengthen our position as the leading and most innovative brand on the international market.
<G-vec00488-002-s831><consider.sehen><de> MIT KOMPERDELL PERFEKT GESCHÜTZT Als der Experte für Sicherheitsbekleidung sehen wir es als unsere Verantwortung, unsere Produkte permanent weiter zu entwickeln und damit unsere Position als führende Innovationsmarke weiter auszubauen.
<G-vec00488-002-s832><consider.sehen><en> We consider this an elementary step to be a good person.
<G-vec00488-002-s832><consider.sehen><de> Wir sehen das als einen elementaren Schritt dazu, ein guter Mensch zu sein.
<G-vec00488-002-s833><consider.sehen><en> We also consider movement to be a prerequisite for the development of solutions that meet future requirements.
<G-vec00488-002-s833><consider.sehen><de> Wir sehen Bewegung auch als die Voraussetzung für Lösungsansätze, die die Anforderungen der Zukunft an uns stellen.
<G-vec00488-002-s834><consider.sehen><en> We, the people of the Ecological Movement of Thessaloniki and Oikopolis, consider it our duty to support these people during their rough journey towards safety and we collaborate closely with all the organizations and volunteer groups that are engaged in our city.
<G-vec00488-002-s834><consider.sehen><de> Wir, die Menschen der Ökologischen Bewegung Thessaloniki und Oikopolis, sehen es als unsere Pflicht, diese Menschen auf ihrem schwierigen Weg ein Stück Sicherheit zu gewährleisten und wir arbeiten eng mit allen Organisationen und Gruppen von Freiwilligen zusammen, die in unserer Stadt engagiert sind.
<G-vec00488-002-s835><consider.sehen><en> zooplus AG's Management Board and Supervisory Board consider it their task to further increase and productively exploit the various aspects of diversity - beyond the definition of targets for the proportion of women on the Management Board and Supervisory Board as well as in management positions.
<G-vec00488-002-s835><consider.sehen><de> Vorstand und Aufsichtsrat der zooplus AG sehen es als ihre Aufgabe an, die verschiedenen Aspekte der Vielfalt – über die Festlegung von Zielgrößen für den Frauenanteil im Vorstand und im Aufsichtsrat und in Führungspositionen hinaus – weiter zu steigern und produktiv zu nutzen.
<G-vec00488-002-s893><consider.sollen><en> Where additional detail is available consider using one or more areas tagged as 'apartments', 'terrace' or 'house'.
<G-vec00488-002-s893><consider.sollen><de> Wenn weitere Details verfügbar sind, sollten ein oder mehrere Flächen mit dem Attribut building=apartments, building=terrace oder building=house angelegt werden.
<G-vec00488-002-s894><consider.sollen><en> If you have lots of users, all of them using various printers, then you probably want to consider header pages as a necessary evil.
<G-vec00488-002-s894><consider.sollen><de> Deckblätter Wenn Sie viele Benutzer mit verschiedenen Druckern verwalten müssen, sollten Sie Deckblätter als notwendiges Übel akzeptieren.
<G-vec00488-002-s895><consider.sollen><en> In this case, you might consider clearing the server names cache.
<G-vec00488-002-s895><consider.sollen><de> In diesem Fall sollten Sie den Servernamencache bereinigen.
<G-vec00488-002-s896><consider.sollen><en> If Yoda were to escape her grip and arrive at the rendezvous by nightfall, the king could consider himself free to join the Republic; if not, she expected him to consider an alliance with the Separatists.
<G-vec00488-002-s896><consider.sollen><de> Als Yoda davon erfuhr, wettete er mit Ventress: Wenn er ihren Truppen entkommen konnte, sollten sich die Toydarianer und ihr König Katuunko der Republik im Krieg anschließen; wenn nicht, würden sie den Separatisten folgen.
<G-vec00488-002-s897><consider.sollen><en> Before crossing the bridge, you may wish to consider a short detour to Eidfjord. Visit the exhibitions at Hardangervidda Nature Centre and enjoy local produce at Hardangerviddahallen restaurant.
<G-vec00488-002-s897><consider.sollen><de> Bevor Sie den Hardangerfjord überqueren, sollten Sie einen Abstecher nach Eidfjord machen, um sich die interessanten Ausstellungen im Naturzentrum Hardangervidda anzusehen.
<G-vec00488-002-s898><consider.sollen><en> The very same factors to consider require to be dealt with as you would certainly do with any type of supplement including organic or natural active ingredients.
<G-vec00488-002-s898><consider.sollen><de> Die gleichen Überlegungen sollten aufgelöst werden, wie Sie sicherlich mit jeder Ergänzung mit organischen oder organischen Wirkstoffen tun würde.
<G-vec00488-002-s899><consider.sollen><en> If you're unable to find a flight that fits your schedule, you might consider flying into Treviso (TSF), which is 15.7 mi (25.3 km) away.
<G-vec00488-002-s899><consider.sollen><de> Wenn Sie für Ihren Reiseplan keinen Flug finden können, sollten Sie vielleicht nach Treviso (TSF) fliegen, das 26,5 km entfernt ist.
<G-vec00488-002-s900><consider.sollen><en> Runners looking for a shoe that is best suited for faster workouts or race events might consider a lightweight running shoe.
<G-vec00488-002-s900><consider.sollen><de> Läufer, die nach einem Schuh suchen, der sich am Besten für schnellere Trainingseinheiten oder Rennen eignet, sollten einen leichten Laufschuh auswählen.
<G-vec00488-002-s901><consider.sollen><en> Therefore, it is necessary to carefully consider the possible elements of the decor.
<G-vec00488-002-s901><consider.sollen><de> Daher sollten die möglichen Dekorelemente sorgfältig abgewogen werden.
<G-vec00488-002-s902><consider.sollen><en> However unlikely the marriage of industrial sofas, we have found a wide variety for you to consider on Pamono; ranging from industrial cantilevered sofas and couches with plush leather upholstery (that only hint at industrial style) to settees, loveseats, and chaises with an industrial twist.
<G-vec00488-002-s902><consider.sollen><de> Wie unwahrscheinlich diese Vereinigung auch klingen mag, wir bei Pamono haben eine große Vielfalt gefunden, die Sie nicht unbeachtet lassen sollten; von industriellen freitragenden Sofas und Couches mit vornehmer Lederpolsterung (das einzige Merkmal für den industriellen Stil) hin zu Polsterbänken, Zweisitzern und Chaiselongues mit industrieller Note.
<G-vec00488-002-s903><consider.sollen><en> Something else to think about, which as engineers we might not always consider, is cost.
<G-vec00488-002-s903><consider.sollen><de> Was wir als Entwickler vielleicht nicht immer beachten, aber sollten, sind die Kosten.
<G-vec00488-002-s904><consider.sollen><en> For documents that will be distributed widely, consider choosing Acrobat 5 (PDF 1.4) to ensure that all users can view and print the document.
<G-vec00488-002-s904><consider.sollen><de> Für Dokumente, die in großem Umfang verteilt werden, sollten Sie jedoch unter Umständen „Acrobat 5.0“ (PDF 1.4) oder „Acrobat 6.0“ (PDF 1.5) wählen, damit sichergestellt ist, dass alle Benutzer das Dokument anzeigen und drucken können.
<G-vec00488-002-s905><consider.sollen><en> So if you start seeing crystals in the jungle and ghost-dragons in your midlane, consider yourself warned - the juggernauts are here to stay.
<G-vec00488-002-s905><consider.sollen><de> Falls ihr also im Dschungel auf Kristalle und in der mittleren Lane auf Geisterdrachen stoßt, sollten bei euch die Alarmglocken läuten: die Dampfwalzen sind gekommen um zu bleiben.
<G-vec00488-002-s906><consider.sollen><en> In the light of that evaluation, taking into account all options, the Commission shall consider proposing appropriate regulatory changes, including legislative changes, in particular if the predicted market uptake is not satisfactory or in the event that sufficient alternative sources of long-term debt financing become available.
<G-vec00488-002-s906><consider.sollen><de> Anhand dieser Bewertung und unter Berücksichtigung aller Optionen schlägt die Kommission gegebenenfalls geeignete Änderungen der Regelungen, einschließlich legislativer Änderungen, vor, insbesondere wenn die prognostizierte Marktakzeptanz nicht zufriedenstellend sein sollte oder falls ausreichend andere Quellen der langfristigen Fremdfinanzierung zur Verfügung stehen sollten.
<G-vec00488-002-s907><consider.sollen><en> Because branch distribution points use client policy to discover which packages are assigned to them, you might consider creating a collection for branch distribution points so that you can configure a shorter client polling interval for these computers by using the collection specific settings.
<G-vec00488-002-s907><consider.sollen><de> Da Zweigverteilungspunkte die ihnen zugewiesenen Pakete mithilfe von Clientrichtlinien ermitteln, sollten Sie eine Sammlung für Zweigverteilungspunkte erstellen, damit Sie anhand der sammlungsspezifischen Einstellungen ein kürzeres Clientabrufintervall für diese Computer konfigurieren können.
<G-vec00488-002-s908><consider.sollen><en> As countries consider how best to allocate any additional health spending, it will be important to maintain a good balance between investments in policies to improve public health and prevention, and policies to improve access, quality and efficiency in health care delivery.
<G-vec00488-002-s908><consider.sollen><de> Die Mehrausgaben im Gesundheitswesen sollten ausgewogen verteilt werden: Zum einen in Maßnahmen zur Verbesserung der öffentlichen Gesundheit und der Prävention und zu andern in Maßnahmen zur Verbesserung des Zugangs zu Gesundheitsdienstleistungen, der Qualität und der Effizienz bei der Erbringung dieser Leistungen.
<G-vec00488-002-s909><consider.sollen><en> There are many reasons why you could consider growing your career at Hollister Incorporated.
<G-vec00488-002-s909><consider.sollen><de> Es gibt viele Gründe, warum Sie Ihre Karriere bei Hollister Incorporated fortsetzen sollten.
<G-vec00488-002-s910><consider.sollen><en> To transform your bathroom into a haven of peace and relaxation, it is important to consider this essential aspect. Start exploring
<G-vec00488-002-s910><consider.sollen><de> Um Ihr Badezimmer in einen Ort der Ruhe und Erholung zu verwandeln, sollten Sie diesem wesentlichen Aspekt besondere Aufmerksamkeit bei der Badgestaltung schenken.
<G-vec00488-002-s911><consider.sollen><en> Once you have rebooted the iPhone, you may consider disabling the iMessage for a while and turn it back on.
<G-vec00488-002-s911><consider.sollen><de> Nachdem Sie das iPhone neu gestartet haben, sollten Sie möglicherweise die iMessage für eine Weile deaktivieren und dann wieder einschalten.
<G-vec00488-002-s912><consider.sollten><en> If so, then consider Next Generation investing at Julius Baer.
<G-vec00488-002-s912><consider.sollten><de> Dann sollten Sie sich die Next-Generation-Anlagephilosophie bei Julius Bär anschauen.
<G-vec00488-002-s913><consider.sollten><en> After you have restarted and updated your Mac, and still it is sluggish, consider removing all the junk files including caches.
<G-vec00488-002-s913><consider.sollten><de> Wenn Sie Ihren Mac neu gestartet und aktualisiert haben und immer noch träge sind, sollten Sie alle Junk-Dateien einschließlich Caches entfernen.
<G-vec00488-002-s914><consider.sollten><en> Limited, FXCM South Africa (PTY) Ltd, any affiliates of aforementioned firms, or other firms within the FXCM group of companies [collectively the “FXCM Group”], carefully consider your financial situation and experience level.
<G-vec00488-002-s914><consider.sollten><de> Bevor Sie mit Produkten handeln, die von South Africa (PTY) Ltd, jeglicher Tochtergesellschaft der oben erwähnten Firmen oder anderen Firmen innerhalb der FXCM Gruppe [zusammengefasst "FXCM Gruppe"] angeboten werden, sollten Sie sorgfältig Ihre finanziellen Verhältnisse und Ihre Erfahrungswerte abwägen.
<G-vec00488-002-s915><consider.sollten><en> If you're traveling to Toamasina with children, consider a visit to the zoo.
<G-vec00488-002-s915><consider.sollten><de> Wenn Sie nach Frankreich mit Kindern unterwegs sind, sollten Sie den Zoo besuchen.
<G-vec00488-002-s916><consider.sollten><en> But before you jump in with both feet, it’s important to consider the implications of each opportunity and plan accordingly.
<G-vec00488-002-s916><consider.sollten><de> Bevor Sie sich jedoch auf die nächste Aktion stürzen, sollten Sie sich mit ihrem Ablauf und Zweck auseinandersetzen – und entsprechend planen.
<G-vec00488-002-s917><consider.sollten><en> If you're traveling to United States with kids, consider a visit to the zoo.
<G-vec00488-002-s917><consider.sollten><de> Wenn Sie nach Amsterdam mit Kindern unterwegs sind, sollten Sie den Zoo besuchen.
<G-vec00488-002-s918><consider.sollten><en> If you aren’t familiar with ValueTrack parameters or how tracking works, consider reviewing About ValueTrack parameters and Manage tracking and redirects in “URL options” before getting started.
<G-vec00488-002-s918><consider.sollten><de> Wenn Sie mit der Funktionsweise von ValueTrack-Parametern und Tracking noch nicht vertraut sind, sollten Sie zuerst die Hilfeartikel ValueTrack-Parameter und Tracking in Google Ads lesen.
<G-vec00488-002-s919><consider.sollten><en> If you're traveling to United States with kids, consider a visit to the zoo.
<G-vec00488-002-s919><consider.sollten><de> Wenn Sie nach Oslo mit Kindern unterwegs sind, sollten Sie den Zoo besuchen.
<G-vec00488-002-s920><consider.sollten><en> if you are considerin to Elope in Europe and you are looking for the best venues and location on where to get married in Europe you might as well consider the places that are close to Europe and are still one of the best places to elope in the World.
<G-vec00488-002-s920><consider.sollten><de> Wenn Sie Elope in Europa in Betracht ziehen und nach den besten Orten und Orten suchen, an denen Sie in Europa heiraten können, sollten Sie auch die Orte in Betracht ziehen, die in der Nähe von Europa liegen und immer noch einer der besten Orte sind, um in der Welt zu fliehen .
<G-vec00488-002-s921><consider.sollten><en> If you need to find the best alternative in the future, consider using FoneDog Toolkit- iOS Data Backup & Restore to create a safe and secure backup option.
<G-vec00488-002-s921><consider.sollten><de> Wenn Sie in Zukunft die beste Alternative finden müssen, sollten Sie FoneDog Toolkit - iOS Data Backup & Restore - verwenden, um eine sichere Backup-Option zu erstellen.
<G-vec00488-002-s922><consider.sollten><en> Caution If you find that considerable force is required to remove the boxed processor assembly, consider wearing gloves to protect your hands.
<G-vec00488-002-s922><consider.sollten><de> Vorsicht Wenn Sie feststellen, dass erhebliche Kraft erforderlich ist, um die Box-Prozessor-Baugruppe zu entfernen, sollten Sie tragen Handschuhe, um Ihre Hände zu schützen.
<G-vec00488-002-s923><consider.sollten><en> If your campaign’s goal is to generate maximum conversions for a given ad spend, consider changing the strategy to 'dynamic bids - up and down'.
<G-vec00488-002-s923><consider.sollten><de> Wenn das Ziel Ihrer Kampagne darin besteht, maximale Konversionen für bestimmte Werbeausgaben zu generieren, sollten Sie die Strategie auf „Dynamische Gebote - nach oben und unten“ umstellen.
<G-vec00488-002-s924><consider.sollten><en> If teaching VCE History for the first time, consider investing in some resources, both to provide you with teaching material and to expand your own knowledge.
<G-vec00488-002-s924><consider.sollten><de> Wenn Sie zum ersten Mal VCE-Geschichte unterrichten, sollten Sie in einige Ressourcen investieren, um Ihnen Unterrichtsmaterial zur Verfügung zu stellen und Ihr eigenes Wissen zu erweitern.
<G-vec00488-002-s925><consider.sollten><en> Hence, if this does not resolve unknown Error 4005, consider doing the next steps.
<G-vec00488-002-s925><consider.sollten><de> Wenn der unbekannte Fehler 4005 dadurch nicht behoben wird, sollten Sie die nächsten Schritte ausführen.
<G-vec00488-002-s926><consider.sollten><en> If you plan to deploy Outlook 2013 together with Exchange Server 2010, Exchange Server 2013 or Exchange Online, consider using the Exchange Server Personal Archive feature instead of Outlook 2013 AutoArchive.
<G-vec00488-002-s926><consider.sollten><de> Wenn Sie Outlook 2013 zusammen mit Exchange Server 2010, Exchange Server 2013 oder Exchange Online bereitstellen möchten, sollten Sie die persönlichen Archive von Exchange Server anstelle der AutoArchivierung von Outlook 2013 verwenden.
<G-vec00488-002-s927><consider.sollten><en> If you're traveling to Vietnam with kids, consider visit to the zoo.
<G-vec00488-002-s927><consider.sollten><de> Wenn Sie nach Vietnam mit Kindern unterwegs sind, sollten Sie den Zoo besuchen.
<G-vec00488-002-s928><consider.sollten><en> To cover your costs, consider taking out a cancellation insurance that will cover your refund.
<G-vec00488-002-s928><consider.sollten><de> Um Ihre Kosten zu decken, sollten Sie eine Stornoversicherung abschließen, die Ihre Rückerstattung abdeckt.
<G-vec00488-002-s929><consider.sollten><en> As a best practice for security, consider using Run as to perform this procedure.
<G-vec00488-002-s929><consider.sollten><de> Aus Sicherheitsgründen sollten Sie dieses Verfahren über "Ausführen als" ausführen.
<G-vec00488-002-s930><consider.sollten><en> If you haven't done this before, consider hiring a Microsoft partner to set up Skype for Business for you.
<G-vec00488-002-s930><consider.sollten><de> Wenn Sie damit keine Erfahrungen haben, sollten Sie möglicherweise einen Microsoft-Partner zur Einrichtung Skype for Business heranziehen.
<G-vec00488-002-s931><consider.verstehen><en> Since our foundation in 1997, we consider ourselves a competent contact partner in the fields of metal processing and mechanical engineering.
<G-vec00488-002-s931><consider.verstehen><de> Seit unserer Gründung 1997 verstehen wir uns als kompetenter Ansprechpartner in den Bereichen Metallverarbeitung und Maschinenbau.
<G-vec00488-002-s932><consider.verstehen><en> We consider each and every video to be the brand's identity and we work closely with the production team of the video.
<G-vec00488-002-s932><consider.verstehen><de> Wir verstehen jedes einzelne Video als Ausdruck der Identität einer Marke und arbeiten eng mit dem Produktionsteam des Videos zusammen.
<G-vec00488-002-s933><consider.verstehen><en> We consider this label, not as a limitation, but conferring upon us a distinct commitment and deliberate focus.
<G-vec00488-002-s933><consider.verstehen><de> Wir verstehen diese Bezeichnung keineswegs als eine Beschränkung, sondern als ein klares Bekenntnis und eine bewußte Konzentration: auf das Wesentliche.
<G-vec00488-002-s934><consider.verstehen><en> We consider insurance solutions that include complementary medicine to be our core objective and we have accumulated extensive experience in this field.
<G-vec00488-002-s934><consider.verstehen><de> Wir verstehen Versicherungslösungen mit Komplementärmedizin als unsere Kernaufgabe und haben darin eine reiche Erfahrung.
<G-vec00488-002-s935><consider.verstehen><en> We consider us as part of your quality commitment to your customers – Your success is a great recognition of our afford.
<G-vec00488-002-s935><consider.verstehen><de> Wir verstehen uns als Teil Ihres Qualitätsversprechens an Ihre Kunden - Ihr Erfolg ist eine große Anerkennung unserer Leistung.
<G-vec00488-002-s936><consider.verstehen><en> We consider load securing as contribution to a sustainable economy and as contribution to protect man and environment.
<G-vec00488-002-s936><consider.verstehen><de> Transportsicherung verstehen wir als Beitrag zu einer nachhaltigen Wirtschaft, zum Schutz von Mensch und Umwelt.
<G-vec00488-002-s937><consider.verstehen><en> LC: Personally and given the above, I don’t see any difference and I wish that artists would consider themselves also as educators, and educators also as artists.
<G-vec00488-002-s937><consider.verstehen><de> LC: Persönlich und bezogen auf oben stehendes, sehe ich keinen Unterschied und ich wünschte, dass KünstlerInnen sich auch als KunstvermittlerInnen verstehen würden, und KunstvermittlerInnen als Künstlerinnen.
<G-vec00488-002-s938><consider.verstehen><en> Having an intuitive understanding of what our Publishers need, you consider yourself a service provider that has a crucial role in supporting our clients’ path to success.
<G-vec00488-002-s938><consider.verstehen><de> Sie haben ein gutes Gespür für die Anforderungen unserer Publisher und verstehen sich als Dienstleister, der maßgeblich zum Erfolg der Kunden beiträgt.
<G-vec00488-002-s939><consider.verstehen><en> We consider the know-how of our employees acquired over generations to be a valuable asset.
<G-vec00488-002-s939><consider.verstehen><de> Das seit Generationen bestehende Knowhow unserer Mitarbeiter verstehen wir als wertvolles Gut.
<G-vec00488-002-s940><consider.verstehen><en> The task of prevention measures is to offer different perspectives, to stimulate discussion, and to generate the willingness to consider oneself as part of a society that allows competing views as well as various models of life and belief.
<G-vec00488-002-s940><consider.verstehen><de> Der Auftrag von Präventionsangeboten besteht darin, andere Sichtweisen anzubieten, Auseinandersetzung anzuregen und die Bereitschaft zu erzeugen, sich als Teil einer Gesellschaft zu verstehen, die konkurrierende Sichtweisen, Lebens- und Glaubensmodelle erlaubt.
<G-vec00488-002-s941><consider.verstehen><en> We see ourselves as a development partner to industry and consider innovation to be a holistic process that has to be initiated and implemented by all participants in the process chain.
<G-vec00488-002-s941><consider.verstehen><de> Wir sehen uns als Entwicklungspartner der Industrie und verstehen Innovation als ganzheitlichen Prozess, der von allen Akteuren der Prozesskette angestoßen und umgesetzt werden muss.
<G-vec00488-002-s942><consider.verstehen><en> They consider themselves the flagships of the region and are synonymous with excellent quality that visitors can see and taste.
<G-vec00488-002-s942><consider.verstehen><de> Sie verstehen sich als Aushängeschilder der Region und stehen für herausragende Qualität, die sicht- und schmeckbar ist.
<G-vec00488-002-s943><consider.verstehen><en> In Sufism, the term God is looked upon as the antipodal pole of an antinomy of which what we consider to be our personal self is the opposite pole.
<G-vec00488-002-s943><consider.verstehen><de> Im Sufismus wird Gott als der gegensätzliche Pol dessen betrachtet, was wir unter unserem persönlichen Selbst verstehen.
<G-vec00488-002-s944><consider.verstehen><en> At MUSTANG, we consider this sustainability management a way of continual improvement, whereby the high quality of the product always takes priority.
<G-vec00488-002-s944><consider.verstehen><de> Dieses Nachhaltigkeitsmanagement verstehen wir bei MUSTANG als Weg der kontinuierlichen Optimierung, wobei immer die hohe Produktqualität im Vordergrund steht.
<G-vec00488-002-s945><consider.verstehen><en> We consider compliance to be the correct conduct of the company and our staff - legal, cost-efficient and ethical.
<G-vec00488-002-s945><consider.verstehen><de> Unter Compliance verstehen wir das korrekte Verhalten des Unternehmens und unserer Mitarbeiter - rechtlich, wirtschaftlich und auch ethisch.
<G-vec00488-002-s946><consider.verstehen><en> If you continue browsing we consider that you agree to their use.
<G-vec00488-002-s946><consider.verstehen><de> Wenn Sie mit der Navigation fortfahren, verstehen wir, dass Sie ihre Verwendung akzeptieren.
<G-vec00488-002-s947><consider.verstehen><en> We not only consider the hammock a South American cultural possession that we aim to preserve, but also an everyday commodity for babies, children and travellers which we aim to spread in the world by contributing innovative products.
<G-vec00488-002-s947><consider.verstehen><de> Wir verstehen die Hängematte nicht nur als südamerikanisches Kulturgut und Symbole für Erholung und Entspannung, sondern auch als praktischen Alltagsgegenstand für Babys, Kinder und Reisende, zu dessen Verbreitung wir mit innovativen Produkten beitragen möchten.
<G-vec00488-002-s948><consider.verstehen><en> Integrity: We consider integrity to be the key human faculty that makes us reliable and credible individuals.
<G-vec00488-002-s948><consider.verstehen><de> Integrität: Unter Integrität verstehen wir die Haltung von Menschen, die sie zu verlässlichen und glaubwürdigen Persönlichkeiten machen.
<G-vec00488-002-s949><consider.verstehen><en> We consider industrial design to be more than just aesthetics.
<G-vec00488-002-s949><consider.verstehen><de> Unter Produktdesign verstehen wir mehr als optische Produktkosmetik.
<G-vec00488-002-s608><consider.ziehen><en> You may want to consider a different space if you're trying to accomplish a certain task.
<G-vec00488-002-s608><consider.ziehen><de> Vielleicht solltest du einen anderen Raum in Erwägung ziehen, wenn du eine bestimmte Aufgabe bewältigen willst.
<G-vec00488-002-s609><consider.ziehen><en> If you have a graphic logo, you might also want to consider asking for a version designed without the text.
<G-vec00488-002-s609><consider.ziehen><de> Wenn du ein grafisches Logo hast, solltest du auch in Erwägung ziehen, nach einer Version ohne Text zu fragen.
<G-vec00488-002-s610><consider.ziehen><en> We will recommend you to friends and will certainly consider you on our next sailing vacation.
<G-vec00488-002-s610><consider.ziehen><de> Wir werden Sie unseren Freunden empfehlen und Sie mit Sicherheit bei unserem nächsten Segelurlaub in Erwägung ziehen.
<G-vec00488-002-s611><consider.ziehen><en> You might want to consider getting someone to help you or renting wallpaper removal equipment to help the job along.
<G-vec00488-002-s611><consider.ziehen><de> Vielleicht möchtest du in Erwägung ziehen, jemanden um Hilfe zu bitten, oder dir eine Ausrüstung für das Entfernen von Tapete im Baumarkt auszuleihen.
<G-vec00488-002-s612><consider.ziehen><en> Smokers might want to consider a different choice, as Hotel Manofa is smoke free.
<G-vec00488-002-s612><consider.ziehen><de> Raucher könnten in Erwägung ziehen, dass der Aufenthalt im Hotel anders ist, da das Hotel Manofa rauchfrei ist.
<G-vec00488-002-s613><consider.ziehen><en> If you notice them occurring frequently, especially when coupled with physical ailments, you may want to consider getting another guinea pig.
<G-vec00488-002-s613><consider.ziehen><de> Wenn du diese häufig auftauchen siehst, vor allem in Verbindung mit körperlichen Leiden, möchtest du vielleicht in Erwägung ziehen, noch ein weiteres Meerschweinchen zu holen.
<G-vec00488-002-s614><consider.ziehen><en> U.S. ambassador to NATO Kay Bailey Hutchison said Washington remained committed to a diplomat solution but was prepared to consider a military strike if Russian development of the medium-range system continued.
<G-vec00488-002-s614><consider.ziehen><de> Die USA zögen zwar eine diplomatische Lösung vor, seien aber auch bereit, einen Militärschlag in Erwägung zu ziehen, sagte die US-Botschafterin bei der Nato, Kay Bailey Hutchison, am Dienstag.
<G-vec00488-002-s615><consider.ziehen><en> You should also consider one of our single or dual monitor arms to keep your screens where you want them while freeing up desk space.
<G-vec00488-002-s615><consider.ziehen><de> Sie sollten auch einen unserer Single- oder Dual-Monitorarme in Erwägung ziehen, um Ihre Bildschirme da zu halten, wo Sie sie haben wollen und gleichzeitig Platz auf dem Tisch zu schaffen.
<G-vec00488-002-s616><consider.ziehen><en> Marketing the benefits of rail travel (or the drawbacks of their current mode of travel) might help them to consider using rail travel.
<G-vec00488-002-s616><consider.ziehen><de> Öffentlichkeitsarbeit über die Vorteile des Bahnfahrens (oder die Nachteile der derzeit genutzten Verkehrsmittel) könnte unterstützend wirken, damit diese Personen die Bahnnutzung in Erwägung ziehen.
<G-vec00488-002-s617><consider.ziehen><en> If you answered yes to some of these questions, you may want to consider preventive actions.
<G-vec00488-002-s617><consider.ziehen><de> Sollten Sie einige der oben stehenden Fragen mit Ja beantwortet haben, sollten Sie es in Erwägung ziehen an Präventivmaßnahmen teilzunehmen.
<G-vec00488-002-s618><consider.ziehen><en> (3) In its resolution on the Commission recommendation on payment periods in commercial transactions(6), the European Parliament called on the Commission to consider transforming its recommendation into a proposal for a Council directive to be submitted as soon as possible.
<G-vec00488-002-s618><consider.ziehen><de> (3) In seiner Entschließung zu der Empfehlung der Kommission über die Zahlungsfristen im Handelsverkehr(6) forderte das Europäische Parlament die Kommission auf, die Umwandlung ihrer Empfehlung in einen Vorschlag für eine Richtlinie des Rates in Erwägung zu ziehen, der möglichst bald vorgelegt werden sollte.
<G-vec00488-002-s619><consider.ziehen><en> While it is a valid strategy to provide a one-time supplemental feed to quickly solve issues related to incomplete catalog data, you should consider an automated process to provide the supplemental data on an ongoing basis to ensure catalog completeness in the future.
<G-vec00488-002-s619><consider.ziehen><de> Obwohl sich diese Strategie durchaus eignet, um einmalig einen ergänzenden Feed bereitzustellen und auf diese Weise Probleme aufgrund unvollständiger Katalogdaten zu lösen, sollten Sie einen automatisierten Prozess in Erwägung ziehen, um die ergänzenden Daten regelmäßig auf wiederkehrender Basis bereitzustellen.
<G-vec00488-002-s620><consider.ziehen><en> But if you really want to tap into your full potential as a language learner, you should consider studying Italian in Italy.
<G-vec00488-002-s620><consider.ziehen><de> Wenn Sie aber Ihr volles Potenzial als Sprachenlernender ausschöpfen möchten, sollten Sie in Erwägung ziehen, Italienisch in Italien zu lernen.
<G-vec00488-002-s621><consider.ziehen><en> And then there were a few who carefully hinted that I might have to give men I was interested in a more clear signal of availability so that they could consider a silver fox among all those bunnies, gazelles, lionesses and other animals of prey…
<G-vec00488-002-s621><consider.ziehen><de> Und schließlich gibt es noch jene, die vorsichtig darauf hinweisen, dass ich vielleicht Männern, die mich interessieren, meinerseits deutlichere Signale zur Kontaktbereitschaft geben müsste, damit sie zwischen all den Häschen, Gazellen, Löwinnen und sonstigen Beutetieren…durchaus auch mal eine Silberfüchsin in Erwägung ziehen können.
<G-vec00488-002-s622><consider.ziehen><en> And with more information to guide them, prospective students can make better decisions from the moment they consider a graduate business degree to the time they enter the application phase.
<G-vec00488-002-s622><consider.ziehen><de> Mit mehr Informationen als Orientierungshilfe können potenzielle Studierende von dem Moment, an dem sie einen weiterführenden betriebswirtschaftlichen Hochschulabschluss in Erwägung ziehen, bis zum Zeitpunkt ihres Einstiegs in die Bewerbungsphase bessere Entscheidungen treffen.
<G-vec00488-002-s623><consider.ziehen><en> “The belief that the value of one’s assets can be best secured through property ownership was certainly an argument for many households to consider investing in property”, the Bundesbank points out.
<G-vec00488-002-s623><consider.ziehen><de> "Die Auffassung, dass sich durch Immobilieneigentum der Wert des Vermögens am besten sichern lasse, war für viele Haushalte sicherlich ein Argument, den Immobilienerwerb in Erwägung zu ziehen", erläutert die Bundesbank.
<G-vec00488-002-s624><consider.ziehen><en> We are happy to consider a broad range of research proposals within the business domain so long as they can be seen to offer the potential for rigour, originality, reach and impact.
<G-vec00488-002-s624><consider.ziehen><de> Wir freuen uns, eine breite Palette von Forschungsvorschlägen innerhalb der Geschäftsdomäne in Erwägung zu ziehen, solange sie das Potenzial für Strenge, Originalität, Reichweite und Wirkung aufweisen.
<G-vec00488-002-s625><consider.ziehen><en> After they showed that sharing information could reduce costs, other retailers became willing to consider the possibility at least.
<G-vec00488-002-s625><consider.ziehen><de> Nachdem sie gezeigt haben, dass das Teilen von Informationen Kosten senken kann, waren auch andere Einzelhändler gewillt, dies zumindest in Erwägung zu ziehen.
<G-vec00488-002-s626><consider.ziehen><en> If you've tried diet, exercise and skin creams, you may want to consider a more drastic measure to remove excess fat or skin around your neck.
<G-vec00488-002-s626><consider.ziehen><de> Falls du Diät, Sport und Hautcremes ausprobiert hast, solltest du vielleicht drastischere Maßnahmen in Erwägung ziehen, um überschüssiges Fett an deinem Hals entfernen zu lassen.
<G-vec00488-002-s950><consider.überlegen><en> 1 Consider how your parents respond to your accomplishments.
<G-vec00488-002-s950><consider.überlegen><de> 1 Überlege, wie deine Eltern auf deine Erfolge reagieren.
<G-vec00488-002-s951><consider.überlegen><en> Consider whether you're not meeting your girlfriend's needs and what you can do to help meet them.
<G-vec00488-002-s951><consider.überlegen><de> Überlege, ob du die Bedürfnisse deiner Freundin erfüllst und wie es dir gelingen kann, es zu tun.
<G-vec00488-002-s952><consider.überlegen><en> When making a master list, consider using a computerized program such as Excel.
<G-vec00488-002-s952><consider.überlegen><de> Überlege, ein Computerprogramm für die Erstellung der Master-Liste zu verwenden.
<G-vec00488-002-s953><consider.überlegen><en> Consider what background information you personally would like to provide, how you would like to address the viewer.
<G-vec00488-002-s953><consider.überlegen><de> Überlege, was Du persönlich an Hintergrundinformationen liefern möchtest, wie Du den Zuschauer ansprechen möchtest.
<G-vec00488-002-s954><consider.überlegen><en> Consider hiring a lawyer to help guide you through the process of filing a restraining order.
<G-vec00488-002-s954><consider.überlegen><de> Überlege, einen Rechtsanwalt aufzusuchen, um dir bei dem Antrag auf ein Kontaktverbot zu helfen.
<G-vec00488-002-s955><consider.überlegen><en> Consider whether you want to tell me who you are, how you feel, what you want and how I should handle you.
<G-vec00488-002-s955><consider.überlegen><de> Überlege, ob Du mir sagen möchtest, wer Du bist, wie Du fühlst, was Du willst und wie ich Dir begegnen soll.
<G-vec00488-002-s956><consider.überlegen><en> Consider joining a team to get exercise and socialize at the same time.
<G-vec00488-002-s956><consider.überlegen><de> Überlege, einem Team beizutreten, um gleichzeitig zu trainieren und neue Leute kennenzulernen.
<G-vec00488-002-s957><consider.überlegen><en> Consider wearing light eyeshadow, some mascara, and light-colored lipstick or lip gloss.
<G-vec00488-002-s957><consider.überlegen><de> Überlege, nur ein wenig Lidschatten, etwas Mascara und einen hellen Lippenstift oder Lipgloss zu tragen.
<G-vec00488-002-s958><consider.überlegen><en> First, consider who you want to tell I love you.
<G-vec00488-002-s958><consider.überlegen><de> Überlege zunächst, wem du „Ich liebe dich“ sagen willst.
<G-vec00488-002-s959><consider.überlegen><en> Consider designating someone who is willing to go to the store to buy forgotten items.
<G-vec00488-002-s959><consider.überlegen><de> Überlege, jemanden zu bestimmen, der einwilligt, in ein Geschäft einkaufen zu gehen, wenn etwas vergessen wurde.
<G-vec00488-002-s960><consider.überlegen><en> This is why you should consider the carrier you want to travel with.
<G-vec00488-002-s960><consider.überlegen><de> Überlege deshalb mit wem Du reisen möchtest.
<G-vec00488-002-s961><consider.überlegen><en> Consider how quickly the illness came on.
<G-vec00488-002-s961><consider.überlegen><de> Überlege, wie schnell die Krankheit aufgetreten ist.
<G-vec00488-002-s962><consider.überlegen><en> Consider very carefully, WHAT you wish for - let your words be clear and exact.
<G-vec00488-002-s962><consider.überlegen><de> Überlege sehr sorgfältig, WORUM Du bittest, sei ganz KLAR und formuliere so exakt wie möglich.
<G-vec00488-002-s963><consider.überlegen><en> Consider where you’d most enjoy working.
<G-vec00488-002-s963><consider.überlegen><de> Überlege, wo du am liebsten arbeiten würdest.
<G-vec00488-002-s964><consider.überlegen><en> Consider the things you do better than other people, or that you are frequently complimented on.
<G-vec00488-002-s964><consider.überlegen><de> Überlege, was du besser kannst als andere, oder wofür dir regelmäßig Komplimente gemacht werden.
<G-vec00488-002-s965><consider.überlegen><en> Consider now, that the most advanced and civilized countries of the world have been turned into arsenals of explosives, that the continents of the globe have been transformed into huge camps and battlefields, that the peoples of the world have formed themselves into armed nations, and that the governments of the world are vying with each other as to who will first step into the field of carnage and bloodshed, thus subjecting mankind to the utmost degree of affliction.
<G-vec00488-002-s965><consider.überlegen><de> Überlege, daß heute die fortschrittlichsten, zivilisiertesten Länder der Welt in Pulverfässer, die Kontinente des Erdballs in riesige Heerlager und Schlachtfelder verwandelt sind, daß die Völker der Welt sich zu waffenstarrenden Nationen formiert haben, daß die Regierungen der Welt miteinander wetteifern, wer den ersten Schritt auf das Feld des Gemetzels und Blutvergießens tut und so die Menschheit ins tiefste Elend stürzt.
<G-vec00488-002-s966><consider.überlegen><en> Consider using pre-chopped onions, bell peppers or other frozen bagged vegetables.
<G-vec00488-002-s966><consider.überlegen><de> Überlege, ob du bereits geschnittene Zwiebeln, Paprika oder anderes Gemüse aus Tiefkühlbeuteln verwenden möchtest.
<G-vec00488-002-s967><consider.überlegen><en> Consider who your mom would enjoy sharing her special day with, and determine whether the party will be a surprise or not.
<G-vec00488-002-s967><consider.überlegen><de> Überlege, mit wem deine Mutter gerne diesen besonderen Tag verbringen würde und überlege, ob es eine Überraschungsparty werden sollte oder nicht.
<G-vec00488-002-s968><consider.überlegen><en> Consider installing a toad light.
<G-vec00488-002-s968><consider.überlegen><de> Überlege, ein Krötenlicht zu installieren.
<G-vec00032-002-s190><consider.bedenken><en> They verify the chances of their utopian ideas of being implemented, consider possible obstacles and devise realistic solution approaches and strategies for action.
<G-vec00032-002-s190><consider.bedenken><de> Sie prüfen die utopischen Entwürfe auf ihre Umsetzungschancen, bedenken mögliche Hindernisse und entwerfen realisierbare Lösungsansätze und Handlungsstrategien.
<G-vec00032-002-s191><consider.bedenken><en> You must additionally consider that scarring could be unattractive and influence how you appear to others.
<G-vec00032-002-s191><consider.bedenken><de> Sie sollten auch bedenken, dass Narben unansehnlich sein könnte und auch nur beeinflussen, wie Sie auf andere zeigen.
<G-vec00032-002-s192><consider.bedenken><en> And there is a lot to consider...
<G-vec00032-002-s192><consider.bedenken><de> Und es gibt einiges zu bedenken...
<G-vec00032-002-s193><consider.bedenken><en> »We could lose it in the swamp as well,« Velena gave to consider.
<G-vec00032-002-s193><consider.bedenken><de> »Genauso könnten wir sie im Sumpf verlieren«, gab Velena zu bedenken.
<G-vec00032-002-s194><consider.bedenken><en> However, but I give to consider that if members want documentation of their requests, mail traffic with all board members as recipients is the right choice.
<G-vec00032-002-s194><consider.bedenken><de> Allerdings gebe ich zu bedenken, dass wenn Mitglieder eine Dokumentation ihrer Anfragen wünschen, der Mailverkehr mit allen Vorstandsmitgliedern als Empfänger der richtige Weg ist.
<G-vec00032-002-s195><consider.bedenken><en> Of course, a book full of messages about life, much to consider.
<G-vec00032-002-s195><consider.bedenken><de> Natürlich ein Buch voller Nachrichten über das Leben, viel zu bedenken.
<G-vec00032-002-s196><consider.bedenken><en> 32:29 Oh that they were wise, that they understood this, That they would consider their latter end!
<G-vec00032-002-s196><consider.bedenken><de> 32:29 Wenn sie weise wären, so würden sie dieses verstehen, ihr Ende bedenken.
<G-vec00032-002-s197><consider.bedenken><en> If any think their country or government is behind the times with capital punishment for any crime, no matter how heinous, they must consider that God was behind the times so much more when prescribing, yes, commanding the death penalty for at least a dozen offences in Israel’s former days.
<G-vec00032-002-s197><consider.bedenken><de> Wer denkt, sein Land oder seine Regierung ist altmodisch mit der Todesstrafe für irgendein Verbrechen, egal wie abscheulich, der muss bedenken, dass Gott noch viel, viel altmodischer war beim Verordnen, ja Befehlen der Todesstrafe für mindestens ein Dutzend Vergehen in Israels frühen Tagen.
<G-vec00032-002-s198><consider.bedenken><en> In this context, one should also consider that such blocking in the musical field would in any event have come ten years too late.
<G-vec00032-002-s198><consider.bedenken><de> Zu bedenken ist in diesem Zusammenhang, dass solche Sperren für den Musikbereich ohnehin um 10 Jahre zu spät kämen.
<G-vec00032-002-s199><consider.bedenken><en> One also needs to consider that the northern region of Kenya, bordering Ethiopia, is very remote and the tribes won’t just fight in the middle of the main street, and from Moyale, down there is only one street.
<G-vec00032-002-s199><consider.bedenken><de> Man muss auch bedenken, dass die nördliche Region Kenias, die an Äthiopien grenzt, sehr abgelegen ist und die Stämme nicht nur in der Mitte der Hauptstraße kämpfen werden, und von Moyale aus gibt es unten nur eine Straße.
<G-vec00032-002-s200><consider.bedenken><en> Things to Consider...
<G-vec00032-002-s200><consider.bedenken><de> Zu bedenken...
<G-vec00032-002-s201><consider.bedenken><en> [p.7] We encourage all who want to walk the path of marriage and family with the Church to personally consider the pioneering text Amoris laetitia and thus discover the wealth of the gospel of the family for one’s life.
<G-vec00032-002-s201><consider.bedenken><de> Wir ermutigen alle, die den Weg von Ehe und Familie mit der Kirche gehen wollen, den wegweisenden Text Amoris laetitia persönlich zu bedenken und so den Reichtum des Evangeliums der Familie für das eigene Leben zu entdecken.
<G-vec00032-002-s202><consider.bedenken><en> Those Minorityites who prepared themselves for a split should consider that they would be connected not for a week and not for the duration of the Soviet-Finnish War, but for years with a “leader” who has in his entire conception nothing in common with the proletarian revolution.
<G-vec00032-002-s202><consider.bedenken><de> Diese Leute von der Minderheit, die sich auf eine Spaltung vorbereiten, sollten bedenken, daß sie nicht für eine Woche und nicht für die Dauer des sowjetisch-finnischen Krieges, sondern jahrelang mit dem „Führer“ in Verbindung gebracht werden, der in seiner ganzen Konzeption nichts mit der proletarischen Revolution gemein hat.
<G-vec00032-002-s203><consider.bedenken><en> However, they don’t consider whether or not their cloud system has backup.
<G-vec00032-002-s203><consider.bedenken><de> Dabei bedenken sie nur selten, ob auch das genutzte Cloud-System über ein Backup verfügt.
<G-vec00032-002-s204><consider.bedenken><en> You are further to consider that you receive answers to questions, which move you, that I myself, your God and father from eternity, it is who speaks to you, that you therefore boast the most valuable – to be able to speak with the greatest spirit of infinity and are to be recognized by him of the favour of a reply, and that all this happens in deepest love towards you.
<G-vec00032-002-s204><consider.bedenken><de> Ihr sollt ferner bedenken, daß ihr Antwort empfanget auf Fragen, die euch bewegen, daß Ich Selbst, euer Gott und Vater von Ewigkeit, es bin, Der zu euch redet, daß ihr also das Wertvollste aufzuweisen habt - sprechen zu können mit dem größten Geist der Unendlichkeit und von Ihm der Gnade einer Antwort gewürdigt zu werden, und daß alles dies in tiefster Liebe zu euch sich vollzieht.
<G-vec00032-002-s205><consider.bedenken><en> Let them consider this, who think the perfection of our nature still consists, as before the Spirit was given, in the exercise of all its separate functions, animal and mental, not in the subjection and sacrifice of what is inferior in us to what is more excellent.
<G-vec00032-002-s205><consider.bedenken><de> Das sollen jene bedenken, die meinen, die Voll¬kommenheit unserer Natur bestehe noch wie vor der Verleihung des Geistes in der Betätigung aller ihrer einzelnen körperlichen und geistigen Funktionen, nicht aber in der entsagenden Unterwerfung unseres niedrigeren Ich unter das höhere.
<G-vec00032-002-s206><consider.bedenken><en> And – what we should consider: If he was to awake at all, he would be a 100 % invalide.
<G-vec00032-002-s206><consider.bedenken><de> Und - so gab er uns zu bedenken: Wenn er überhaupt wieder aufwachen könnte, dann würde er mit Sicherheit ein 100 %er Pflegefall werden.
<G-vec00032-002-s207><consider.bedenken><en> Make sure you consider the season when buying your wedding gown.
<G-vec00032-002-s207><consider.bedenken><de> Bedenken Sie beim Kauf Ihres Brautkleides unbedingt die Jahreszeit am Tag Ihrer Hochzeit.
<G-vec00032-002-s208><consider.bedenken><en> You should also consider where it will be exposed to sunlight, since the sand will dry more quickly there than in other places.
<G-vec00032-002-s208><consider.bedenken><de> Auch den Lichteinfall sollten Sie bedenken, da dieser dazu führt, dass der Sand unterschiedlich trocknet.
<G-vec00032-002-s209><consider.bedenken><en> Consider that before paying the requested money even crosses your mind.
<G-vec00032-002-s209><consider.bedenken><de> Bedenken Sie, dass vor der Zahlung das angeforderte Geld auch kreuzt Ihren Geist.
<G-vec00032-002-s210><consider.bedenken><en> But consider that the last will supersedes all previous wills if you do not expressively prohibit it.
<G-vec00032-002-s210><consider.bedenken><de> Bedenken Sie aber, dass das letzte Testament alle vorherigen widerruft, wenn man das nicht ausdrücklich ausschließt.
<G-vec00032-002-s211><consider.bedenken><en> Please consider that data transmission via the internet can always be subject to security vulnerabilities.
<G-vec00032-002-s211><consider.bedenken><de> Bedenken Sie, dass die Datenübertragung im Internet grundsätzlich mit Sicherheitslücken bedacht sein kann.
<G-vec00032-002-s212><consider.bedenken><en> First, consider the fact that companies on average use eight different channels to market their business and 12 or more digital marketing platforms and tools to manage them .
<G-vec00032-002-s212><consider.bedenken><de> Bedenken Sie die Tatsache, dass Unternehmen zur Vermarktung ihres Angebots durchschnittlich acht verschiedene Kanäle sowie mindestens zwölf digitale Marketingplattformen und Tools zu deren Steuerung benutzen .
<G-vec00032-002-s213><consider.bedenken><en> Please consider that the ViFit® Activity Tracker has an own storage space which contains any registered data for 15 days.
<G-vec00032-002-s213><consider.bedenken><de> Bitte bedenken Sie, dass der ViFit® Activity Tracker einen eigenen Speicher hat, der Werte insgesamt 15 Tage lang speichert.
<G-vec00032-002-s214><consider.bedenken><en> But today, I ask you to consider that much of accepted Sumo history is still based on our ancestors' first interpretations of tomes found beneath the Cambridge University Library ruins - over 300 timeslices ago.
<G-vec00032-002-s214><consider.bedenken><de> Aber bitte bedenken Sie, dass ein Großteil der allgemein anerkannten Sumo-Geschichte noch immer auf den ersten Interpretationen unserer Vorfahren bezüglich der Bücher basiert, die vor 300 Zeiteinheiten unter den Ruinen der Universitätsbibliothek von Cambridge gefunden wurden.
<G-vec00032-002-s215><consider.bedenken><en> Also consider the places where you typically travel .
<G-vec00032-002-s215><consider.bedenken><de> Bedenken Sie auch, an welche Ort Sie typischerweise reisen.
<G-vec00032-002-s216><consider.bedenken><en> Consider what kind of consequences this will have for the image, tourism and for the economy of your city and your country.
<G-vec00032-002-s216><consider.bedenken><de> Bedenken Sie welche Folgen das für das Image, den Tourismus und die Wirtschaft Ihrer Stadt und Ihres Landes hat.
<G-vec00032-002-s217><consider.bedenken><en> Consider what impact your documents will have on your company’s image.
<G-vec00032-002-s217><consider.bedenken><de> Bedenken Sie, welche Auswirkung Ihre Texte auf Ihr Firmenimage haben.
<G-vec00032-002-s218><consider.bedenken><en> Before you go scanning random Internet addresses for vulnerable FTP servers, consider that sysadmins may not appreciate you abusing their servers in this way.
<G-vec00032-002-s218><consider.bedenken><de> Bevor Sie anfangen, zufällige Internet-Adressen nach anfälligen FTP-Servern zu scannen, bedenken Sie, dass Sysadmins keinen Gefallen daran finden werden, dass Sie ihre Server auf diese Weise missbrauchen.
<G-vec00032-002-s219><consider.bedenken><en> Anmerkung: Consider that more than one client may be connected to one interface at a time, so that, unlike dial-in servers, port numbers are not unique for clients.
<G-vec00032-002-s219><consider.bedenken><de> Anmerkung: Bedenken Sie, dass mehr als nur ein Client über ein Interface verbunden sein kann; die Port-Nummer verweist also im Gegensatz zu Dial-in-Servern nicht eindeutig auf einen Client.
<G-vec00032-002-s220><consider.bedenken><en> One just need to observe the rule and to consider all.
<G-vec00032-002-s220><consider.bedenken><de> Man muss nur beachten die Regel und Bedenken Sie alle.
<G-vec00032-002-s221><consider.bedenken><en> Consider that in winter, your skin is already at a loss for moisture—due to dry air, chilly temperatures, indoor heating, car heating, and less humidity.
<G-vec00032-002-s221><consider.bedenken><de> Bedenken Sie, dass die Haut im Winter sowieso schon trocken ist – aufgrund der trockenen Luft, dem kühlen Wetter, den Heizungen im Auto und bei Ihnen zu Hause.
<G-vec00032-002-s222><consider.bedenken><en> Just consider what this means.
<G-vec00032-002-s222><consider.bedenken><de> Bedenken Sie, was das heißt.
<G-vec00032-002-s223><consider.bedenken><en> It is also recommended that you have someone with you at the birth who can translate the important information. Please consider this when choosing a birth partner.
<G-vec00032-002-s223><consider.bedenken><de> Auch zur Geburt empfiehlt es sich, jemanden bei sich zu haben, der wichtige Informationen übersetzen kann, bitte bedenken Sie dies bei der Wahl Ihrer Begleitperson.
<G-vec00032-002-s224><consider.bedenken><en> Please consider when you send your material it is the safest option.
<G-vec00032-002-s224><consider.bedenken><de> Bedenken Sie beim Versenden Ihres Materials an die sicherste Möglichkeit.
<G-vec00032-002-s225><consider.bedenken><en> You see, of course they are Jews, it is very clear, they are just Jews, but consider yourselves how many, – also party members – addressed their famous request to me or any other entity wherein it said that all Jews were swine of course, that only so-and-so was a decent Jew who was not to be harmed.
<G-vec00032-002-s225><consider.bedenken><de> Sehen Sie, natürlich sind es Juden, es ist ganz klar, es sind nur Juden, bedenken Sie aber selbst, wie viele – auch Parteigenossen – ihr berühmtes Gesuch an mich oder irgendeine Stelle gerichtet haben, in dem es hieß, daß alle Juden selbstverständlich Schweine seien, daß bloß der Soundso ein anständiger Jude sei, dem man nichts tun dürfe.
<G-vec00032-002-s226><consider.bedenken><en> My process continues with Snapseed, first with the 1:1 format for Instagram, which might sound too basic until you consider that the right crop is a huge part of the composition.
<G-vec00032-002-s226><consider.bedenken><de> Anschließend mache ich mit Snapseed weiter, zuerst mit dem 1:1-Format für Instagram, was sich zu grundlegend anhören kann, doch bedenken Sie, dass die richtige Zuschneidung ein riesiger Teil der Bildkomposition ist.
<G-vec00032-002-s227><consider.bedenken><en> Consider the following suggestions to help you do this: 1.
<G-vec00032-002-s227><consider.bedenken><de> Bedenken Sie dabei folgende Vorschläge: 1.
<G-vec00032-002-s228><consider.bedenken><en> A rather low “dosage”, if you consider that most of the Champagne wine we drink labelled as “Brut”, has a dosage up to 15 g/l of sugar.
<G-vec00032-002-s228><consider.bedenken><de> Eine vergleichsweise niedrige Dosis, wenn man bedenkt, dass es sich bei der überwiegenden Mehrheit des von uns getrunkenen Champagners um „Brut“ Weine handelt, denen man bis zu 15 g/L Zucker hinzusetzt.
<G-vec00032-002-s229><consider.bedenken><en> If you consider how the power of the moon pulls the water of the planet in the higher than normal spring tides, it is quite a phenomenon.
<G-vec00032-002-s229><consider.bedenken><de> Wenn man bedenkt, wie die Kraft des Mondes das Wasser des Planeten hochzieht und höhere, stärkere Gezeiten als normal hervor ruft, ist das ein ziemliches Phänomen.
<G-vec00032-002-s230><consider.bedenken><en> Martin Hollerup, Managing Director of Sandberg A/S, says: "When you consider how expensive it is to replace the screen on an iPhone or iPad, so you can now just smile even if a scratch occurs there.
<G-vec00032-002-s230><consider.bedenken><de> Martin Hollerup, Geschäftsführer von Sandberg A/S, erklärt: „Wenn man bedenkt, wie teuer ein neuer Bildschirm für ein iPhone oder iPad ist, können Sie es jetzt mit einem Lächeln hinnehmen, wenn es einen Kratzer gibt.
<G-vec00032-002-s231><consider.bedenken><en> If you consider that the economical use of resources and environmental awareness are important criteria for the most important target group when buying products, the importance of sustainably designed packaging is obvious.
<G-vec00032-002-s231><consider.bedenken><de> Wenn man bedenkt, dass gerade der sparsame Umgang mit Ressourcen und Umweltbewusstsein bedeutende Kriterien beim Kauf von Produkten der wichtigsten Zielgruppe sind, erklärt sich welche Bedeutung einer nachhaltig gestalteten Verpackung heute zugetragen wird.
<G-vec00032-002-s232><consider.bedenken><en> It has to be the way of it, if you consider what DNA does.
<G-vec00032-002-s232><consider.bedenken><de> Es kann nur so ablaufen, wenn ihr bedenkt was die DNS tut.
<G-vec00032-002-s233><consider.bedenken><en> However, this is perfectly okay if you consider that the average value for battery-powered vacuum cleaners is less than 10 minutes.
<G-vec00032-002-s233><consider.bedenken><de> Das ist aber völlig in Ordnung, wenn man bedenkt, dass der durchschnittliche Wert bei Akkustaubsaugern bei unter 10 Minuten liegt.
<G-vec00032-002-s234><consider.bedenken><en> Dr. Oz is one positive customer from several others, however when you again consider his track record, it’s a referral that carries a huge degree of credibility.
<G-vec00032-002-s234><consider.bedenken><de> Dr. Oz ist ein positiver Rezensent aus vielen anderen, aber wenn man einmal mehr seine Erfolgsbilanz bedenkt, es ist eine Empfehlung, die ein großes Maß an Glaubwürdigkeit trägt.
<G-vec00032-002-s235><consider.bedenken><en> A good rate if you consider that the notebook should mainly be used for undemanding office tasks.
<G-vec00032-002-s235><consider.bedenken><de> Ein guter Wert, wenn man bedenkt, dass das Notebook ja hauptsächlich für anspruchslose Bürotätigkeiten eingesetzt werden soll.
<G-vec00032-002-s236><consider.bedenken><en> Consider the game benefits of effects when adjusting their quality.
<G-vec00032-002-s236><consider.bedenken><de> Bedenkt die Vorteile dieser Effekte im Spiel, wenn ihr deren Qualität anpasst.
<G-vec00032-002-s239><consider.bedenken><en> Specifically: IDF does not consider statistical sample size.
<G-vec00032-002-s239><consider.bedenken><de> IDF bedenkt nicht die statistische Größe des Samples.
<G-vec00032-002-s241><consider.bedenken><en> Not too much when you consider what the Vital Hoop everything can release during exercise.
<G-vec00032-002-s241><consider.bedenken><de> Nicht zu viel, wenn man bedenkt, was der Vital Hoop beim Training alles freisetzen kann.
<G-vec00032-002-s243><consider.bedenken><en> And it’s not surprising when you consider that each of the three smartphone providers in the country offer access to Facebook (via its limited and text versions Facebook Lite and Facebook Flex).
<G-vec00032-002-s243><consider.bedenken><de> Was nicht wirklich überraschend ist, wenn man bedenkt, dass alle drei Smartphone-Anbieter des Landes Zugang zu Facebook anbieten – entweder eingeschränkt über Facebook Lite oder mit Facebook Flex für Textnachrichten.
<G-vec00032-002-s244><consider.bedenken><en> When you consider that James Dyson took 14 years, until his vacuum cleaner could be sold under his name, it is gratifying that his products are now offered worldwide in 47 countries.
<G-vec00032-002-s244><consider.bedenken><de> Wenn man bedenkt, dass James Dyson 14 Jahre benötigte, bis sein Staubsauger unter seinem Namen verkauft werden konnte, ist es erfreulich, dass seine Produkte mittlerweile in 47 Ländern weltweit angeboten werden.
<G-vec00032-002-s245><consider.bedenken><en> Safely arrived on the premises, we immediately saw many giant tortoises, a very moving experience, if you consider that these animals are sooo old.
<G-vec00032-002-s245><consider.bedenken><de> Auf dem Gelände sicher angekommen, sahen wir sofort viele Riesenschildkröten, ein sehr bewegendes Erlebnis, wen man bedenkt das diese Tiere schon sooo Alt sind.
<G-vec00032-002-s246><consider.bedenken><en> When you consider that you can use tapes with a grit 6000 for polishing, you understand that you can achieve an unrivalled sharpness.
<G-vec00032-002-s246><consider.bedenken><de> Wenn man bedenkt, dass die Politurbänder eine Körnung von 6000 aufweisen, dann verstehen Sie, dass sich mit damit eine unübertroffene Schärfe erreichen lässt.
<G-vec00149-002-s969><consider.(sich)_überlegen><en> Consider trying advanced AI and taxonomy powered recruitment tools that will help you identify the candidates with suitable abilities and experiences in the past – for example, a history of effectively working from home or completing projects independently. Establish communication rules
<G-vec00149-002-s969><consider.(sich)_überlegen><de> Überlegen Sie sich, mit KI und Taxonomie arbeitende Bewerbersuchmaschinen einzusetzen, mit deren Hilfe Sie Kandidaten mit passenden Fähigkeiten und vorherigen Berufserfahrungen leichter finden – zum Beispiel solche, die bereits eine Vergangenheit mit erfolgreicher Telearbeit und der autonomen Erledigung von Projekten vorweisen können.
<G-vec00149-002-s970><consider.(sich)_überlegen><en> Consider how you can tame a dragon in Maynkraft himself or using fashion.
<G-vec00149-002-s970><consider.(sich)_überlegen><de> Überlegen Sie, wie Sie einen Drachen in Maynkraft selbst oder mit Mode zähmen können.
<G-vec00149-002-s971><consider.(sich)_überlegen><en> Consider how Muslims (or, for that matter, Christians) imagine God deals with the souls of people who die without learning about the one true religion.
<G-vec00149-002-s971><consider.(sich)_überlegen><de> Überlegen Sie, wie die Muslime (oder, für diese Angelegenheit, Christen) vorstellen, Gott mit den Seelen der Menschen, die sterben, ohne das Lernen über die eine wahre Religion.
<G-vec00149-002-s972><consider.(sich)_überlegen><en> Consider how people like to work these days.
<G-vec00149-002-s972><consider.(sich)_überlegen><de> Überlegen Sie, wie Menschen heute bevorzugt arbeiten.
<G-vec00149-002-s973><consider.(sich)_überlegen><en> As you make your plan, consider what you will invite class members to do to help them learn from the scriptures and the words of latter-day prophets.
<G-vec00149-002-s973><consider.(sich)_überlegen><de> Überlegen Sie beim Aufstellen Ihres Plans, wozu Sie die Unterrichtsteilnehmer auffordern möchten, damit sie aus den heiligen Schriften und den Worten der Propheten aus den Letzten Tagen lernen.
<G-vec00149-002-s974><consider.(sich)_überlegen><en> Consider, by whom the information was obtained.
<G-vec00149-002-s974><consider.(sich)_überlegen><de> Überlegen Sie, von wem die Information stammt.
<G-vec00149-002-s975><consider.(sich)_überlegen><en> Consider whether the courses you’ll take will help you once you graduate.
<G-vec00149-002-s975><consider.(sich)_überlegen><de> Überlegen Sie, ob die Kurse, die Sie belegen, Ihnen nach Abschluss des Studiums weiterhelfen.
<G-vec00149-002-s976><consider.(sich)_überlegen><en> If you have limited funds available, consider applying exclusively for partner universities that accept the Language Certificate.
<G-vec00149-002-s976><consider.(sich)_überlegen><de> Überlegen Sie sich bei knappem Budget, ob Sie sich lieber nur auf Partneruniversitäten bewerben, die das Language Certificate akzeptieren.
<G-vec00149-002-s977><consider.(sich)_überlegen><en> Consider what effect you want to achieve: a natural holiday photo looks different than an application photo.
<G-vec00149-002-s977><consider.(sich)_überlegen><de> Überlegen Sie, welche Wirkung Sie erzielen möchten: Ein natürliches Urlaubsfoto wirkt anders als ein steriles Bewerbungsbild.
<G-vec00149-002-s978><consider.(sich)_überlegen><en> Consider what happened to the unprofitable servants in both parables that Jesus told.
<G-vec00149-002-s978><consider.(sich)_überlegen><de> Überlegen Sie, was passiert, die unnütze Knechte in beiden Gleichnissen, die Jesus erzählt.
<G-vec00149-002-s979><consider.(sich)_überlegen><en> Consider what a laserskin resurfacing.Currently, dermatologists and cosmetic surgeons use two types of lasers: carbon dioxide (C02) and erbium YAG-laser is.They have small differences, that is a subject of debate among physicians.Many surgeons claim that the C02 lasers better reduce wrinkles on the face, but it usually leads to a residual redness, follow the treatment, as well as some increase in pigment loss.Erbium YAG-lasers does not provide a good correction of wrinkles, but he gives no redness or skin turns pink for such a long period, and the possibility of pigment loss is significantly lower.At the moment of CO and erbium YAG-laser is give the successful combination of the advantages of both.
<G-vec00149-002-s979><consider.(sich)_überlegen><de> Überlegen Sie, was ein LaserSkin Resurfacing.Derzeit Dermatologen und Schönheitschirurgen verwenden zwei Arten von Lasern: Kohlendioxid (C02) und Erbium YAG-Laser ist.Sie haben kleine Unterschiede, das ist ein Thema der Debatte unter den Ärzten.Viele Chirurgen behaupten, dass die C02-Laser besser Falten im Gesicht zu reduzieren, aber es führt in der Regel zu einer Rest Rötung, folgen Sie der Behandlung sowie eine Erhöhung der Pigmentverlust.Erbium YAG-Laser bietet keine gute Korrektur von Falten, aber er gibt keine Rötung oder Haut wird rosa für einen so langen Zeitraum, und die Möglichkeit der Pigmentverlust ist deutlich geringer.Im Moment des CO und Erbium YAG-Laser ist die erfolgreiche Kombination der Vorteile beider geben.
<G-vec00149-002-s980><consider.(sich)_überlegen><en> Consider how the products will get to you and how they will be recycled after you.
<G-vec00149-002-s980><consider.(sich)_überlegen><de> Überlegen Sie, wie die Produkte zu Ihnen kommen und wie sie nach Ihnen recycelt werden.
<G-vec00149-002-s981><consider.(sich)_überlegen><en> Consider what needs to be done to make the interior create a holistic impression, and the wallpaper did not look like a foreign element, an extra piece of decor.
<G-vec00149-002-s981><consider.(sich)_überlegen><de> Überlegen Sie, was getan werden muss, damit das Interieur einen ganzheitlichen Eindruck hinterlässt, und die Tapete sah nicht wie ein fremdes Element aus, sondern ein zusätzliches Dekor.
<G-vec00149-002-s982><consider.(sich)_überlegen><en> Context is important. Consider who is involved in the discussion and how they represent the rest of the community.
<G-vec00149-002-s982><consider.(sich)_überlegen><de> Der Kontext ist wichtig: Überlegen Sie, wer an der Diskussion beteiligt ist und wie die Diskutanten den Rest der Gemeinschaft repräsentieren.
<G-vec00149-002-s983><consider.(sich)_überlegen><en> Consider adjusting your colour scheme and using seasonal banners or videos.
<G-vec00149-002-s983><consider.(sich)_überlegen><de> Überlegen Sie, das Farbschema anzupassen und setzen Sie saisonale Banner oder Videos ein.
<G-vec00149-002-s984><consider.(sich)_überlegen><en> Consider how quickly your little one is growing before investing in a reusable swim diaper.
<G-vec00149-002-s984><consider.(sich)_überlegen><de> Überlegen Sie, wie schnell Ihr Kleines wächst, bevor Sie in eine wiederverwendbare Schwimmwindel investieren.
<G-vec00149-002-s985><consider.(sich)_überlegen><en> Consider how your media plan would look on points of influence.
<G-vec00149-002-s985><consider.(sich)_überlegen><de> Überlegen Sie sich einmal, wie Ihr Mediaplan aussehen könnte, wenn er auf dem Einfluss basieren würde.
<G-vec00149-002-s986><consider.(sich)_überlegen><en> Consider how you can become an influential source of information for your audience by creating your own free content strategy, then amplifying it with paid media.
<G-vec00149-002-s986><consider.(sich)_überlegen><de> Überlegen Sie, wie Sie eine einflussreiche Quelle an Informationen für Ihr Publikum werden könnten, indem Sie Ihre eigene kostenlose Content-Strategie entwickeln, welche Sie mit Paid Media verstärken könnten.
<G-vec00149-002-s987><consider.(sich)_überlegen><en> Consider how to make a calculation using the sand filter.
<G-vec00149-002-s987><consider.(sich)_überlegen><de> Überlegen Sie, wie Sie eine Berechnung mit dem Sandfilter durchführen.
<G-vec00149-002-s1007><consider.(sich)_überlegen><en> Therefore - before you come to Heidelberg - we strongly advise you to carefully consider which services you will need to use at the university and to choose the visa and the form of registration (either #1 visiting doctoral candidate/visa §16b for study purposes OR #2 visiting researcher/visa §18d for research purposes) that will give you access to these services.
<G-vec00149-002-s1007><consider.(sich)_überlegen><de> Daher raten wir Ihnen dringend, vor der Beantragung des Visums sorgfältig zu überlegen, welche Dienstleistungen Sie an der Universität in Anspruch nehmen möchten und darauf basierend wählen Sie das Visum und die Form der Registrierung (entweder #1 Forschungsstudent/Visum §16b für Studienzwecke oder #2 Gastwissenschaftler/Visum §18d für Forschungszwecke), die Ihnen Zugang zu diesen Dienstleistungen ermöglichen.
<G-vec00149-002-s1008><consider.(sich)_überlegen><en> If we consider how it must be for each individual animal when they move in these large, fast groups we begin to understand why the animals are more reliant on their acoustics than they are on their vision.
<G-vec00149-002-s1008><consider.(sich)_überlegen><de> Wenn wir überlegen, wie es für jedes einzelne Tier sein muss, wenn es sich in diesen großen, schnellen Gruppen bewegt, beginnen wir zu verstehen, warum die Tiere mehr auf ihre Akustik als auf ihre Vision angewiesen sind.
<G-vec00149-002-s1009><consider.(sich)_überlegen><en> Since experience shows, however, that it is difficult to interpret the undefined terms of humanity, respect or even dignity as such, in the end the only help comes from the decision to stop and consider what is the true objective of medicine instead of relying on interpretation.
<G-vec00149-002-s1009><consider.(sich)_überlegen><de> Da es jedoch erfahrungsgemäss schwierig ist, die unbestimmten Begriffe Menschlichkeit, Ehrfurcht oder auch Würde als solche zu interpretieren, hilft letztlich nur die Entscheidung weiter, sich anstelle einer solchen Interpretation zu überlegen, welches denn die eigentliche Aufgabe der Medizin sei.
<G-vec00149-002-s1010><consider.(sich)_überlegen><en> Gamers should thoroughly consider the investment of 883 euro because laptops with a superior ATI HD 5650 and similarly strong processor are available for less.
<G-vec00149-002-s1010><consider.(sich)_überlegen><de> Spieler sollten sich die 882 Euro teure Anschaffung genau überlegen, denn Laptops mit besserer ATI HD 5650 und ähnlich starken Prozessoren gibt es auch für weniger Geld.
<G-vec00149-002-s1011><consider.(sich)_überlegen><en> However, you can consider whether it makes sense to write an hour back and forth with one person.
<G-vec00149-002-s1011><consider.(sich)_überlegen><de> Allerdings können Sie sich überlegen, ob es sinnvoll ist, mit einer Person eine Stunde hin und her zu schreiben.
<G-vec00149-002-s1012><consider.(sich)_überlegen><en> You should consider whether you understand how CFDs work and whether you can afford to take the high risk of losing your money.’
<G-vec00149-002-s1012><consider.(sich)_überlegen><de> Sie sollten sich überlegen, ob Sie es sich leisten können, das hohe Risiko einzugehen, möglicherweise einen Teil Ihres Geldes zu verlieren.
<G-vec00149-002-s1013><consider.(sich)_überlegen><en> After that, you can still consider which items you want to buy and what not and there. Real handy!
<G-vec00149-002-s1013><consider.(sich)_überlegen><de> Danach können Sie immer noch überlegen, welche Artikel Sie kaufen und möchten und welche momentan noch nicht.
<G-vec00149-002-s1014><consider.(sich)_überlegen><en> The United Nations factored the great world religions in different initiatives and discussions and consider with them together which strategies would help us to move on.
<G-vec00149-002-s1014><consider.(sich)_überlegen><de> Die Vereinten Nationen beziehen die großen Weltreligionen in verschiedene Initiativen und Gespräche mit ein und überlegen mit ihnen gemeinsam, welche Strategien helfen, hier weiter zu kommen.
<G-vec00149-002-s1015><consider.(sich)_überlegen><en> However, individuals must also carefully consider whether they might want to register the corresponding domain.
<G-vec00149-002-s1015><consider.(sich)_überlegen><de> Aber auch Privatpersonen müssen sich sehr gut überlegen, ob sie nicht auch die entsprechende Domain registrieren lassen möchten.
<G-vec00149-002-s1016><consider.(sich)_überlegen><en> Businesses are universally being called upon to consider how their resources may be applied against creating the maximum positive social impact, at a time when their usual ability to commercially transact has either come under serious threat or been immediately suspended.
<G-vec00149-002-s1016><consider.(sich)_überlegen><de> Die Unternehmen sind allgemein aufgefordert, zu überlegen, wie ihre Ressourcen gegen die Schaffung eines maximalen positiven sozialen Einflusses eingesetzt werden können, und das zu einem Zeitpunkt, an dem ihre üblichen Möglichkeiten zur kommerziellen Abwicklung entweder ernsthaft gefährdet oder sofort ausgesetzt wurden.
<G-vec00149-002-s1017><consider.(sich)_überlegen><en> In that constellation, we discussed how to move forwards in Libya at a time when important conflict parties have agreed on a peace agreement and we now need to consider how to get as many as possible to join in concluding a treaty that will lead to the establishment of a government of national unity.
<G-vec00149-002-s1017><consider.(sich)_überlegen><de> Gemeinsam haben wir in diesem Format darüber beraten, wie es in Libyen weitergehen kann zu einem Zeitpunkt, an dem wichtige Konfliktparteien sich auf ein Friedensabkommen verständigt haben und an dem wir überlegen müssen, wie wir möglichst viele zum Abschluss eines Vertrages bringen können, der zur Einsetzung einer Regierung der Nationalen Einheit führt.
<G-vec00149-002-s1018><consider.(sich)_überlegen><en> Carefully consider which is the origin of fear, how real he is, how real is the danger.
<G-vec00149-002-s1018><consider.(sich)_überlegen><de> Sorgfältig überlegen, Woher stammt die Angst, wie es wirklich ist, wie Real ist die Gefahr.
<G-vec00149-002-s1019><consider.(sich)_überlegen><en> This step will take time and cost, but let's still consider it - after all, the time and money spent on such a device will be worth it if you have a large family that uses a lot of hot water every day.
<G-vec00149-002-s1019><consider.(sich)_überlegen><de> Dieser Schritt wird Zeit und Kosten kosten, aber lasst es uns immer noch überlegen - schließlich sind die Zeit und das Geld, die für ein solches Gerät ausgegeben werden, es wert, wenn Sie eine große Familie haben, die jeden Tag viel heißes Wasser verbraucht.
<G-vec00149-002-s1020><consider.(sich)_überlegen><en> One should therefore consider in advance how to determine the offer price and quantity, since the fee is incurred directly and cannot be adjusted or adapted later, as well as PPC.
<G-vec00149-002-s1020><consider.(sich)_überlegen><de> Man sollte sich also vorher gut überlegen, wie man Angebotspreis und Stückzahl wählt, da die Gebühr direkt anfällt und nicht, wie bei PPC, nachträglich noch angepasst und justiert werden kann.
<G-vec00149-002-s1021><consider.(sich)_überlegen><en> In order to take part in the competition it is required that users will post the specification of their machine with a photograph on to the Club3D Facebook and whatever level your computer is we will consider how it can be upgraded to improve performance based on what components are already inside.
<G-vec00149-002-s1021><consider.(sich)_überlegen><de> Um an dem Wettbewerb teilzunehmen ist es erforderlich, dass die Teilnehmer die Spezifikation Ihres Rechners mit einem Bild bei Club3D Facebook posten und egal welchen Level der Computer hat, werden wir uns überlegen, was Sinn macht um diesen Computer aufzurüsten um die Leistung zu verbessern, basierend auf den Komponenten, die schon im Rechner sind.
<G-vec00149-002-s1022><consider.(sich)_überlegen><en> To those in charge, another important aspect to consider is that, in addition to the current preservative ventures, the creation of a high-quality "Füred wine track", with good local character will contribute heavily to local and foreign media viewing Balatonfüred as a city honoring its natural and cultural heritage.
<G-vec00149-002-s1022><consider.(sich)_überlegen><de> Für die Entscheider ist es ein weitere Punkt zu überlegen, dass eine mit hoher Qualität großzügig formierte "Kellerreihe von Füred" mit lokaler Charakter dazu zusteuern kann, dass Balatonfüred wieder als ihr natürliches und kulturelles Erbe ehrende Stadt von dem heimischen und ausländischen öffentlichen Urteil geschätzt sei.
<G-vec00149-002-s1023><consider.(sich)_überlegen><en> If you find the coverage area of your WiFi network less than satisfactory, you should consider using a WiFi extender.
<G-vec00149-002-s1023><consider.(sich)_überlegen><de> Wenn Sie die Abdeckungsreichweite Ihres Netzwerks weniger als zufriedenstellend finden, sollten Sie sich überlegen, einen WiFi-Extender zu nutzen.
<G-vec00149-002-s1024><consider.(sich)_überlegen><en> To give an answer to this question, first of all we will consider what should not be done by adults.
<G-vec00149-002-s1024><consider.(sich)_überlegen><de> Um eine Antwort auf diese Frage zu geben, werden wir zuerst überlegen, was Erwachsene nicht tun sollten.
<G-vec00149-002-s1025><consider.(sich)_überlegen><en> For the two projects that due to the strong competition have not been invited to submit full proposals, TU Dresden will now consider whether they can be in part implemented through other funding programmes.
<G-vec00149-002-s1025><consider.(sich)_überlegen><de> Für die Cluster, die trotz hoher Qualität aufgrund des starken Wettbewerbs nicht als Exzellenzcluster gefördert werden, wird die TU Dresden nun überlegen, ob und wie sie in Teilen gegebenenfalls über andere Förderprogramme realisiert werden können.
<G-vec00149-002-s247><consider.berücksichtigen><en> After the first 3 days, you can use skin care products again, but please also be sure to continue to consider all of the above points until the skin cells heal (usually in about 2 weeks).
<G-vec00149-002-s247><consider.berücksichtigen><de> Nach den 3 Tagen können Sie wieder Pflegeprodukte verwenden, bitte achten Sie darüber hinaus aber darauf, alle oben genannten Punkte auch weiterhin zu berücksichtigen, bis die Hautschüppchen verheilt sind (Dauer in der Regel bis zu 2 Wochen).
<G-vec00149-002-s248><consider.berücksichtigen><en> From this, you can be sure that we will be implementing cost- and energy-efficient solutions for all applications and when drawing up our offer, we also consider the security of your investment and your future developments.
<G-vec00149-002-s248><consider.berücksichtigen><de> Dabei können Sie sicher sein, dass wir für alle Anwendungen kostengünstige und energieeffiziente Lösungen realisieren und bei unserem Angebot auch die Investitionssicherheit und Ihre zukünftige Entwicklung berücksichtigen.
<G-vec00149-002-s249><consider.berücksichtigen><en> Before deciding to trade foreign exchange, you should carefully consider your investment objectives, level of experience, and risk appetite.
<G-vec00149-002-s249><consider.berücksichtigen><de> Vor der Entscheidung am Devisenmarkt zu handeln, sollten Sie sorgfältig Ihre Anlageziele, Erfahrung und Risikobereitschaft berücksichtigen.
<G-vec00149-002-s250><consider.berücksichtigen><en> When you build a scalable Unified Messaging environment, you must consider the effect that these users will have and the resources that each of these users will consume.
<G-vec00149-002-s250><consider.berücksichtigen><de> Beim Aufbau einer skalierbaren UM-Umgebung müssen Sie die Auswirkungen und die von jedem Benutzer beanspruchten Ressourcen berücksichtigen.
<G-vec00149-002-s251><consider.berücksichtigen><en> Another cost to consider is the running costs of the property.
<G-vec00149-002-s251><consider.berücksichtigen><de> Ein weiterer Kostenfaktor zu berücksichtigen ist, die laufenden Kosten der Immobilie.
<G-vec00149-002-s252><consider.berücksichtigen><en> A sustainable energy policy strategy has to consider partner country characteristics that affect the effectiveness and the desirability of policy instruments and overall responsibility for global climate change.Partner countries can be classified in three groups: Group I consists mainly of sub-Saharan African countries where energy poverty and unsustainable biomass use patterns prevail.
<G-vec00149-002-s252><consider.berücksichtigen><de> Eine in diesem Sinne nachhaltige Zusammenarbeit muss außerdem berücksichtigen, welche sozioökonomischen und institutionellen Bedingungen im Partnerland vorherrschen und ob dieses klimapolitische Verantwortung trägt oder nicht.Die Partnerländer können in drei Gruppen eingeteilt werden: Gruppe I besteht hauptsächlich aus Ländern Subsahara-Afrikas mit unzureichender Energieversorgung und nicht nachhaltiger Nutzung der Biomasse.
<G-vec00149-002-s253><consider.berücksichtigen><en> To grow onions on the windowsill in winter, you need to consider that there should not be near sources of heating.
<G-vec00149-002-s253><consider.berücksichtigen><de> Um im Winter Zwiebeln auf der Fensterbank wachsen zu lassen, müssen Sie berücksichtigen, dass es keine Heizquellen in der Nähe geben darf.
<G-vec00149-002-s254><consider.berücksichtigen><en> The Supervisory Board has specified concrete objectives regarding its composition. Taking the entrepreneurial situation into account, these targets must also consider the company’s international activities, potential conflicts of interest, the number of independent board members of the Supervisory Board, and diversity.
<G-vec00149-002-s254><consider.berücksichtigen><de> Der Aufsichtsrat hat für seine Zusammensetzung konkrete Ziele benannt, die unter Beachtung der unternehmerischen Situation die internationale Tätigkeit des Unternehmens, potenzielle Interessenkonflikte, die Anzahl von unabhängigen Aufsichtsratsmitgliedern und Vielfalt (Diversity) berücksichtigen sollen.
<G-vec00149-002-s255><consider.berücksichtigen><en> You should also consider your partner’s dietary preferences.
<G-vec00149-002-s255><consider.berücksichtigen><de> Du solltest außerdem die Ernährungsvorlieben deines Partners berücksichtigen.
<G-vec00149-002-s256><consider.berücksichtigen><en> A referral was also made in J 15/90, although the question was already pending, as the board wished to give the Enlarged Board the opportunity to consider another type of case which might be affected by its answer.
<G-vec00149-002-s256><consider.berücksichtigen><de> Auch in der Sache J 15/90 wurde vorgelegt, obwohl die Frage schon anhängig war, weil die Kammer der Großen Beschwerdekammer die Möglichkeit geben wollte, eine weitere Fallkonstellation zu berücksichtigen, die von der Lösung der Frage betroffen sein konnte.
<G-vec00149-002-s257><consider.berücksichtigen><en> 6.2 Anciennes versions When migrating assets into AEM, there are several steps to consider.
<G-vec00149-002-s257><consider.berücksichtigen><de> Ältere Versionen Beim Migrieren von Assets nach AEM sind verschiedene Schritte zu berücksichtigen.
<G-vec00149-002-s258><consider.berücksichtigen><en> Bans on various substances, the price of resources and waste management, and consumer behaviour are only some of the factors you need to consider – this is precisely where our Efficiency Engineering comes in.
<G-vec00149-002-s258><consider.berücksichtigen><de> Stoffverbote, Ressourcen- und Entsorgungspreise sowie Konsumverhalten sind nur einige der Faktoren, die Sie zu berücksichtigen haben – exakt hier setzt unser Efficiency Engineering an.
<G-vec00149-002-s259><consider.berücksichtigen><en> Once you have changed the privacy settings on your most recent post, Facebook will consider these settings for whenever you post something next time.
<G-vec00149-002-s259><consider.berücksichtigen><de> Sobald Sie die Privatsphäre-Einstellungen für Ihren letzten Beitrag geändert haben, wird Facebook diese Einstellungen bei Ihrem nächsten Beitrag berücksichtigen.
<G-vec00149-002-s260><consider.berücksichtigen><en> For instance, the satnav could prompt the driver to consider weather data on her route: If the sun is shining whilst the driver is at the supermarket, it would be expedient to recharge the car battery sooner than originally planned, thereby significantly increasing the proportion of solar power used in the recharging process, thus making it more environmentally friendly.
<G-vec00149-002-s260><consider.berücksichtigen><de> So könnte das Navi dem Fahrer empfehlen, bei seiner Route die Wetterdaten zu berücksichtigen: Wenn um 14 Uhr am Supermarkt die Sonne scheint, kann es möglicherweise sinnvoll sein, früher als geplant nachzuladen.
<G-vec00149-002-s261><consider.berücksichtigen><en> Hence it is crucial to - on the one hand consider social trends in technology development and on the other hand also make technological trends more accessible for users.
<G-vec00149-002-s261><consider.berücksichtigen><de> So gilt es einerseits gesellschaftliche Trends bereits in der Technologieentwickung zu berücksichtigen und andererseits Techniktrends für die Gesellschaft aufzubereiten.
<G-vec00149-002-s262><consider.berücksichtigen><en> A risk assessment will allow our experienced teams to consider any corrective action you need to take for the success of your project as well as to meet compliance with applicable regulations.
<G-vec00149-002-s262><consider.berücksichtigen><de> Eine Risikobeurteilung erlaubt unseren erfahrenen Teams, Korrekturmaßnahmen zu berücksichtigen, die Sie treffen müssen, um sowohl den Erfolg Ihres Projekts als auch die Einhaltung der geltenden Verordnungen zu gewährleisten.
<G-vec00149-002-s263><consider.berücksichtigen><en> Google and other search engines now "know" that there is a canonical version of this page that they should consider when indexing.
<G-vec00149-002-s263><consider.berücksichtigen><de> Google und andere Suchmaschinen “wissen” nun, dass es von dieser Seite eine kanonische Version gibt, die sie beim Indexieren berücksichtigen sollen.
<G-vec00149-002-s264><consider.berücksichtigen><en> Also to consider is that we all are only human and thus make mistakes and gather guilt.
<G-vec00149-002-s264><consider.berücksichtigen><de> Zu berücksichtigen ist ferner, dass wir alle nur Menschen sind und damit, dass wir Fehler machen, wir uns schuldig machen.
<G-vec00149-002-s265><consider.berücksichtigen><en> Important is of course to consider the range of the motorcycle and suitable breaks for charging.
<G-vec00149-002-s265><consider.berücksichtigen><de> Wichtig ist natürlich die Reichweite des Motorrads und passende Ladestopps zu berücksichtigen.
<G-vec00149-002-s285><consider.berücksichtigen><en> The amount of space used, available, and referenced by a file or file system does not consider pending changes.
<G-vec00149-002-s285><consider.berücksichtigen><de> Die von einer Datei oder einem Dateisystem belegte, verfügbare und referenzierte Festplattenkapazität berücksichtigt keine anstehenden Änderungen.
<G-vec00149-002-s286><consider.berücksichtigen><en> Hence the admissions procedure can only consider those applications for which the necessary documents have been submitted by the application deadline.
<G-vec00149-002-s286><consider.berücksichtigen><de> Daher können nur solche Anträge im Zulassungsverfahren berücksichtigt werden, denen bis zum Ablauf der Antragsfrist die erforderlichen Unterlagen beigefügt worden sind.
<G-vec00149-002-s287><consider.berücksichtigen><en> When you consider that all principals agreeing to share a lifetime do so out of unconditional love, that kind of very temporary arrangement doesn't seem as strange as it may upon first hearing of it.
<G-vec00149-002-s287><consider.berücksichtigen><de> Wenn ihr berücksichtigt, dass alle Prinzipien einer Vereinbarung, eine Lebenszeit zu teilen, aus bedingungsloser Liebe heraus geschehen, mag diese Art von sehr vorübergehendem Arrangement nicht so seltsam erscheinen, wie beim ersten Mal des davon Hörens.
<G-vec00149-002-s288><consider.berücksichtigen><en> In the context of the municipality’s strategic planning, the measures consider criteria such as damage reduction, flood risk mitigation, economic and technical feasibility as well as ecological and social impacts.
<G-vec00149-002-s288><consider.berücksichtigen><de> Die Massnahmenplanung berücksichtigt aus einer Gesamtschau heraus die Kriterien Schadenserwartung, Risikoverminderung, Wirtschaftlichkeit, technische Machbarkeit sowie ökologische und soziale Aspekte.
<G-vec00149-002-s289><consider.berücksichtigen><en> Notes 1 The Company continues to consider a number of factors in connection with the ongoing progress and evaluation of the construction, development and potential production of the Phoenix Gold Project, which will include, when available, the results from the mineral resource update and the ongoing optimization studies on the PEA2, as well as project financing opportunities and development timelines.
<G-vec00149-002-s289><consider.berücksichtigen><de> Anmerkungen 1 Das Unternehmen berücksichtigt in Zusammenhang mit den laufenden Fortschritten und der Bewertung der Bauarbeiten, der Erschließung und der potenziellen Produktion beim Goldprojekt Phoenix eine Reihe von Faktoren, einschließlich – sofern vorliegend – die Ergebnisse des Mineralressourcen-Updates und der laufenden Optimierungsstudien im Rahmen der PEA2 sowie Projektfinanzierungsmöglichkeiten und Zeitpläne der Erschließung.
<G-vec00149-002-s290><consider.berücksichtigen><en> In order to be able to consider data locking at any time, it is necessary to keep the data for control purposes in a lock file.
<G-vec00149-002-s290><consider.berücksichtigen><de> Damit eine Sperre von Daten jederzeit berücksichtigt werden kann, müssen diese Daten zu Kontrollzwecken in einer Sperrdatei vorgehalten werden.
<G-vec00149-002-s291><consider.berücksichtigen><en> We have therefore developed a process model, a migration plan and an integrated migration program especially for public administrations which take into account the needs of a migration (requirements, deadlines, resources) and at the same time consider the requirements of ongoing maintenance and further development.
<G-vec00149-002-s291><consider.berücksichtigen><de> Speziell für die öffentliche Verwaltung haben wir deshalb ein Vorgehensmodell, eine Migrationsplanung sowie ein integriertes Migrationsprogramm entwickelt, das den Belangen der Migration einer gesamten Anwendungslandschaft (Anforderungen, Termine, Ressourcen) Rechnung trägt und zugleich die Erfordernisse der laufenden Wartung und Weiterentwicklung berücksichtigt.
<G-vec00149-002-s292><consider.berücksichtigen><en> To improve the system properties, we consider innovative passive and active structural measures in addition to lightweight construction principles.
<G-vec00149-002-s292><consider.berücksichtigen><de> Zur Verbesserung der Systemeigenschaften werden neben Leichtprinzipien neuartige passive und aktive Strukturmaßnahmen berücksichtigt.
<G-vec00149-002-s293><consider.berücksichtigen><en> OUR COMMITMENT TO TRANSPARENCY Saint-Gobain and SageGlass consider the environmental impact of our businesses at every stage, from product design through manufacturing to the point of sale and product disposal at the end of life.
<G-vec00149-002-s293><consider.berücksichtigen><de> UNSER ENGAGEMENT FÜR MEHR TRANSPARENZ Bei Saint-Gobain und SageGlass wird die Umweltbelastung der Geschäftsprozesse in jeder Phase des Lebenszyklus eines Bauprojekts berücksichtigt: von der Planung über die Produktion bis hin zum Rückbau.
<G-vec00149-002-s294><consider.berücksichtigen><en> These tiles are very easy to lay because there is no special laying pattern to consider.
<G-vec00149-002-s294><consider.berücksichtigen><de> Diese Fliesen lassen sich sehr leicht verlegen, denn es muss kein besonderes Verlege-Muster berücksichtigt werden.
<G-vec00149-002-s295><consider.berücksichtigen><en> The publisher will consider all error corrections that are reported to him within the deadline set in the proof. Paragraph 15:
<G-vec00149-002-s295><consider.berücksichtigen><de> Der Verlag berücksichtigt alle Fehlerkorrekturen, die ihm innerhalb der bei der Übersendung des Probeabzuges gesetzen Frist mitgeteilt werden.
<G-vec00149-002-s296><consider.berücksichtigen><en> January 2011 Judge Dr. S. Aeppli did not agree with what Julius Baer`s detectives did to my family but he did not consider it in his written ruling.
<G-vec00149-002-s296><consider.berücksichtigen><de> Richter Dr. S. Aeppli distanzierte sich davon, was die Privatdetektive der Bank Julius Bär meiner Familie angetan hatte, aber er hatte diesen Sachverhalt in seinem Urteil weder erwähnt noch berücksichtigt.
<G-vec00149-002-s297><consider.berücksichtigen><en> To date they have discovered a total of 130 species of invertebrates, a surprising number if we consider the harsh living conditions that exist in an environment like this one.
<G-vec00149-002-s297><consider.berücksichtigen><de> Bis heute hat man insgesamt 130 wirbellose Tiere entdeckt, eine Zahl, die überrascht, wenn man die harten Lebensbedingungen in einer solchen Umgebung berücksichtigt.
<G-vec00149-002-s298><consider.berücksichtigen><en> When choosing materials one should always consider the specific application and local ambient conditions.
<G-vec00149-002-s298><consider.berücksichtigen><de> Bei der Materialwahl sollten immer die konkreten Einsatz- und Umgebungsbedingungen vor Ort berücksichtigt werden.
<G-vec00149-002-s299><consider.berücksichtigen><en> A safe flight in arbitrary scenarios requires a situational awareness that is able to consider the properties of the environment.
<G-vec00149-002-s299><consider.berücksichtigen><de> Der sichere Flug in beliebigen Szenarien erfordert ein Situationsbewusstsein, das die Eigenschaften der Umgebung mit berücksichtigt.
<G-vec00149-002-s300><consider.berücksichtigen><en> It may not be possible to consider project outlines received after the above date.
<G-vec00149-002-s300><consider.berücksichtigen><de> Projektskizzen, die nach dem oben angegebenen Zeitpunkt eingehen, können möglicherweise nicht mehr berücksichtigt werden.
<G-vec00149-002-s301><consider.berücksichtigen><en> What’s more, you must consider the running cost reduction of the machine which requires far less electricity than a traditional saw cutting system.
<G-vec00149-002-s301><consider.berücksichtigen><de> Dazu muss die Reduzierung der Betriebskosten der Maschine berücksichtigt werden, die weniger elektrische Energie als ein traditionelles Schneidesystem verbraucht.
<G-vec00149-002-s302><consider.berücksichtigen><en> The 3D solid model does consider the stress distribution at these diameter changes automatically without the need to guess average diameters or cone angles.
<G-vec00149-002-s302><consider.berücksichtigen><de> Das 3D-Volumenmodell berücksichtigt die Spannungsverteilung automatisch an der Stelle von Querschnittsveränderungen ohne dass versteifende Durchmesser oder Kegelwinkel geschätzt werden müssen.
<G-vec00149-002-s303><consider.berücksichtigen><en> In assessing overall costs rationale for dressing selection should consider impacts on other total costs, such as reducing pain on dressing change, which may facilitate out-patient management and/or return to work which reduce the financial burden to the hospital system and the patient/economy respectively.
<G-vec00149-002-s303><consider.berücksichtigen><de> Im Rahmen der Bewertung der Gesamtkosten sollten bezüglich der Auswahl des Verbands die Auswirkungen auf andere Gesamtkosten berücksichtigt werden, wie die Reduzierung von Schmerzen beim Verbandswechsel, wodurch die ambulante Behandlung der Patienten erleichtert und/oder eine Rückkehr an den Arbeitsplatz ermöglicht werden kann.
<G-vec00149-002-s570><consider.erwägen><en> From time to time, we review our security procedures to consider appropriate new technology and methods.
<G-vec00149-002-s570><consider.erwägen><de> Von Zeit zu Zeit überprüfen wir unsere Sicherheitsverfahren und erwägen geeignete neue Technologien und Methoden.
<G-vec00149-002-s571><consider.erwägen><en> Please consider upgrading to the latest version of your browser by clicking one of the following Find a store Technical Specifications
<G-vec00149-002-s571><consider.erwägen><de> Wenn Sie eine Aktualisierung zur neuesten Version Ihres Browsers erwägen, klicken Sie auf einen der folgenden Links.
<G-vec00149-002-s572><consider.erwägen><en> In an uncertain and ever more brutal world, the Northerners may finally consider banding together, lest they be defeated in detail.
<G-vec00149-002-s572><consider.erwägen><de> In einer ungewissen und immer brutaleren Welt könnten die Nordländer endlich erwägen, sich zu verbünden, um nicht einzeln besiegt zu werden.
<G-vec00149-002-s573><consider.erwägen><en> Administrators should consider performing any validation based on ephemeral transaction properties in both the start-commit and pre-commit hooks—the former to rule out invalid clients before those clients transmit the commit payload; the latter « just in case » the validation checks couldn't be performed by the start-commit hook.
<G-vec00149-002-s573><consider.erwägen><de> Deshalb sollten Administratoren erwägen, Validierungen, die auf flüchtigen Transaktions-Eigenschaften beruhen, sowohl im start-commit als auch im pre-commit Hook vorzunehmen – ersteres, um ungültige Clients auszuschließen, bevor sie die Daten der Übertragung senden, letzteres, „für alle Fälle“, falls die Validierung durch den start-commit Hook nicht möglich war.
<G-vec00149-002-s574><consider.erwägen><en> As the economy heats up, the Fed will consider taking on contractionary measures.
<G-vec00149-002-s574><consider.erwägen><de> Wenn sich die Wirtschaft aufheizt, wird die Fed erwägen, straffende Maßnahmen zu ergreifen.
<G-vec00149-002-s575><consider.erwägen><en> NATO and Russia encourage all States Parties to the CFE Treaty to consider reductions in their CFE equipment entitlements, as part of an overall effort to achieve lower equipment levels that are consistent with the transformation of Europe's security environment.
<G-vec00149-002-s575><consider.erwägen><de> Die NATO und Russland ermutigen alle KSE-Vertragsstaaten, eine Verringerung ihrer Obergrenzen für durch den Vertrag begrenzte Ausrüstungen als Teil der umfassenderen Bemühungen um niedrigere Obergrenzen für Ausrüstungen, die mit der Veränderung des europäischen Sicherheitsumfelds im Einklang stehen, zu erwägen.
<G-vec00149-002-s576><consider.erwägen><en> Thus you may even consider using modified designs (“themes”) for some regions.
<G-vec00149-002-s576><consider.erwägen><de> Man könnte also sogar erwägen, abgestimmte Designs („Themes“) für bestimmte Regionen zu verwenden.
<G-vec00149-002-s577><consider.erwägen><en> Most of system users consider having more amount of free disk space so as to save additional amount of information.
<G-vec00149-002-s577><consider.erwägen><de> Vielen Dank" Die meisten Systembenutzer erwägen, mehr freien Speicherplatz zur Verfügung zu haben, um zusätzliche Informationen zu sparen.
<G-vec00149-002-s578><consider.erwägen><en> To view this video please enable JavaScript, and consider upgrading to a web browser that supports HTML5 video.
<G-vec00149-002-s578><consider.erwägen><de> Um dieses Video anzusehen, aktivieren Sie bitte JavaScript und erwägen ein Upgrade auf einen Webbrowser, der zappelt die ganze Zeit herum.
<G-vec00149-002-s579><consider.erwägen><en> You might also consider turning the tile over and using the more abstract design on the reverse.
<G-vec00149-002-s579><consider.erwägen><de> Sie könnten auch erwägen, die Karten umzudrehen und das abstraktere Design auf der Rückseite zu verwenden.
<G-vec00149-002-s580><consider.erwägen><en> When you find a product that multiple people have personally recommended to you, then consider buying it.
<G-vec00149-002-s580><consider.erwägen><de> Wenn Sie ein Produkt finden, das mehrere Leute persönlich Ihnen empfohlen haben, erwägen Sie dann, es zu kaufen.
<G-vec00149-002-s581><consider.erwägen><en> You could also consider using some Specific phrases or adages with Exclusive importance.
<G-vec00149-002-s581><consider.erwägen><de> Sie könnten auch erwägen, einige spezielle Phrasen oder Sprichwörter mit besonderer Bedeutung zu verwenden.
<G-vec00149-002-s582><consider.erwägen><en> Please consider registering to shop on our web site.
<G-vec00149-002-s582><consider.erwägen><de> Bitte erwägen zu registrieren, um auf unserer Web site zu kaufen.
<G-vec00149-002-s583><consider.erwägen><en> Consider donating your own blood before any surgery that may require a blood transfusion, to eliminate the possibility of a blood-borne infection.
<G-vec00149-002-s583><consider.erwägen><de> Erwägen, dein eigenes Blut zu spenden bevor jede mögliche Chirurgie, die eine Bluttransfusion erfordern kann, um die Möglichkeit einer Blut-getragenen Infektion zu beseitigen.
<G-vec00149-002-s584><consider.erwägen><en> In total, 13% of Britons would consider taking drugs in the future.
<G-vec00149-002-s584><consider.erwägen><de> Insgesamt würden 13% der Briten erwägen, in der Zukunft Drogen zu nehmen.
<G-vec00149-002-s585><consider.erwägen><en> You can consider adding stop orders that can help you protect your profits and limit your losses.
<G-vec00149-002-s585><consider.erwägen><de> Sie können erwägen, Stoppaufträge hinzuzufügen, um Ihre Gewinne zu schützen und ihre Verluste zu begrenzen.
<G-vec00149-002-s586><consider.erwägen><en> At the outset, parents often do not consider medication as a first-choice treatment, but try other treatment methods first.
<G-vec00149-002-s586><consider.erwägen><de> Dabei erwägen die Eltern zu Beginn oft nicht etwa eine medikamentöse Behandlung als erstbeste Lösung, sondern probieren zuerst andere Behandlungsmethoden aus.
<G-vec00149-002-s587><consider.erwägen><en> Then you should consider applying as an expert for the Scientific Committee, the nerve centre of EFSA’s science.
<G-vec00149-002-s587><consider.erwägen><de> Dann sollten Sie erwägen, sich als sachverständiges Mitglied im wissenschaftlichen Gremium der EFSA für Tiergesundheit und Tierschutz (AHAW) zu bewerben.
<G-vec00149-002-s588><consider.erwägen><en> Here, we look at things to consider as you consider moving into management.
<G-vec00149-002-s588><consider.erwägen><de> In diesen Kursen betrachten wir einige Aspekte, die Sie beachten sollten, wenn Sie erwägen, sich in eine Management-Position zu begeben.
<G-vec00149-002-s589><consider.erwägen><en> Consider wearing a jacket and black jeans for an easy to wear, everyday look.
<G-vec00149-002-s589><consider.erwägen><de> Erwägen Sie das Tragen von einer Jacke und schwarzen Jeans für einen bequemen Alltags-Look.
<G-vec00149-002-s590><consider.erwägen><en> Consider using the size attribute to display the first set of options in a select control.
<G-vec00149-002-s590><consider.erwägen><de> Erwägen Sie, das size-Attribut zu verwenden, um die ersten Optionen einer Auswahlliste anzuzeigen.
<G-vec00149-002-s591><consider.erwägen><en> Consider that, however ephemeral therefore perishable your personal self may seem to you, it will continue to exist.
<G-vec00149-002-s591><consider.erwägen><de> Erwägen Sie, daß Ihr persönliches Selbst fortfahren wird zu existieren, wie flüchtig und daher vergänglich es Ihnen auch immer erscheinen mag.
<G-vec00149-002-s592><consider.erwägen><en> Consider wearing a jacket and black jeans for an easy to wear, everyday look.
<G-vec00149-002-s592><consider.erwägen><de> Erwägen Sie das Tragen von einer Jacke und schwarzen Jeans für ein sonntägliches Mittagessen mit Freunden.
<G-vec00149-002-s593><consider.erwägen><en> Consider using Blue's Attendant Console Enterprise or Professional in your projects, for reaching extra savings optimizing UCS investments and offering a better service to your customers. Sizing
<G-vec00149-002-s593><consider.erwägen><de> Erwägen Sie den Einsatz von Blue's Attendant Console Enterprise oder Professional in Ihren Projekten, um die Investition in Ihr UCS zu optimieren, Kosten einzusparen und gleichzeitig Ihren Kunden einen noch besseren Service zu bieten.
<G-vec00149-002-s594><consider.erwägen><en> What to do before you back up Consider these best practices before you define and run your first backup: 69 Best practices for backing up your data What to do before you back up 69 Schedule backups at a time when you know your computer is on.
<G-vec00149-002-s594><consider.erwägen><de> 60 60 Best Practice für das Sichern Ihrer Daten Bewährte Methoden für Backups Vor dem Backup Erwägen Sie diese bewährten Methoden, bevor Sie Ihr erstes Backup definieren und ausführen: Planen Sie Backups zu Zeiten, zu denen Ihr Computer eingeschaltet sein wird.
<G-vec00149-002-s595><consider.erwägen><en> Consider visiting your local dealer.
<G-vec00149-002-s595><consider.erwägen><de> Erwägen Sie, Ihren lokalen Händler zu besuchen.
<G-vec00149-002-s596><consider.erwägen><en> Consider purchasing a rug that can handle the high traffic that will occur in these areas.
<G-vec00149-002-s596><consider.erwägen><de> Erwägen Sie, eine Wolldecke zu kaufen, die den hohen Verkehr behandeln kann, der in diesen Bereichen auftritt.
<G-vec00149-002-s597><consider.erwägen><en> If they persist, or observe the appearance of bruises, consider the possibility of changing technique.
<G-vec00149-002-s597><consider.erwägen><de> Wenn sie hartnäckig bleiben oder Blutergüsse beobachten, erwägen Sie, die Technik zu wechseln.
<G-vec00149-002-s598><consider.erwägen><en> Consider the integrations offered by Dropbox and how they’ll affect your efficiency.
<G-vec00149-002-s598><consider.erwägen><de> Erwägen Sie die von Dropbox angebotenen Integrationen und wie sich diese auf Ihre Effizienz auswirken.
<G-vec00149-002-s599><consider.erwägen><en> Consider just some of the features in Ivanti solutions that help protect you from ransomware and other threats.
<G-vec00149-002-s599><consider.erwägen><de> Erwägen Sie einfach einige der Funktionen und Merkmale von Ivanti Lösungen, die dazu beitragen, Sie vor Ransomware und anderen Bedrohungen zu schützen.
<G-vec00149-002-s600><consider.erwägen><en> If you do not want to install a secondary site and you have clients in remote locations, consider using Windows BranchCache or distribution points that are enabled for bandwidth control and scheduling.
<G-vec00149-002-s600><consider.erwägen><de> Wenn Sie keinen sekundären Standort installieren möchten und es Clients an Remotestandorten gibt, erwägen Sie den Einsatz von Windows BranchCache oder von Verteilungspunkten, die für die Bandbreitensteuerung und Planung aktiviert sind.
<G-vec00149-002-s601><consider.erwägen><en> Consider requiring that documents or items be checked out before they are modified
<G-vec00149-002-s601><consider.erwägen><de> Erwägen Sie die Anforderung, dass Dokumente oder Elemente vor dem Ändern ausgecheckt werden.
<G-vec00149-002-s602><consider.erwägen><en> Consider the relationship between a Products table and an Orders table.
<G-vec00149-002-s602><consider.erwägen><de> Erwägen Sie die Beziehung zwischen einer Tabelle Products und der Tabelle Orders.
<G-vec00149-002-s603><consider.erwägen><en> Consider interviewing many prospective users to find out if their job titles actually indicates what they do or not.
<G-vec00149-002-s603><consider.erwägen><de> Erwägen Sie, mehrere potenzielle Benutzer zu befragen, um herauszufinden, inwiefern ihre Berufsbezeichnungen tatsächlich ihre beruflichen Tätigkeiten angeben.
<G-vec00149-002-s604><consider.erwägen><en> Consider wearing a deep blue jacket and Scotch & Soda Ralston Slim Fit Jean for an easy to wear, everyday look.
<G-vec00149-002-s604><consider.erwägen><de> Erwägen Sie das Tragen von einem dunkelblauen Sakko und weiße Jeans von Scotch & Soda für Ihren Bürojob.
<G-vec00149-002-s605><consider.erwägen><en> Please consider our extensions for Chrome or Firefox instead.
<G-vec00149-002-s605><consider.erwägen><de> Bitte erwägen Sie stattdessen unsere Erweiterungen für Chrome oder Firefox.
<G-vec00149-002-s606><consider.erwägen><en> In order to define your AOI, consider using our Interactive Area of Interest Selector or Google Earth.
<G-vec00149-002-s606><consider.erwägen><de> Erwägen Sie die Verwendung unserer interaktiven Interessenbereichswahlvorrichtung (Interactive Area of Interest Selector) oder von Google Earth, um Ihren Interessenbereich (AOI) zu definieren.
<G-vec00149-002-s607><consider.erwägen><en> If Cp is lower than your benchmark, consider how to improve your process by reducing its variation.
<G-vec00149-002-s607><consider.erwägen><de> Wenn Cp niedriger als der Benchmark-Wert ist, erwägen Sie, Ihren Prozess durch Verringern seiner Streuung zu verbessern.
<G-vec00149-002-s304><consider.ziehen><en> As a project generator we continue to review new opportunities, but at same time we need to consider all options to advance a district scale opportunity at San Martin.
<G-vec00149-002-s304><consider.ziehen><de> Als Projektgenerator prüfen wir weiterhin neue Möglichkeiten, aber gleichzeitig müssen wir alle Optionen in Betracht ziehen, um in San Martin eine Gelegenheit im Distriktmaßstab voranzubringen.
<G-vec00149-002-s305><consider.ziehen><en> Also, if you want to use webporno, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s305><consider.ziehen><de> Wenn Sie webporno nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s306><consider.ziehen><en> Also, if you want to use tnntcams, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s306><consider.ziehen><de> Wenn Sie camvideox nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s307><consider.ziehen><en> Also, if you want to use ProstoCams.com, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s307><consider.ziehen><de> Wenn Sie OnlineStrip.net nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s308><consider.ziehen><en> For a travel by car, you may consider parking at marked fee-paying parking locations.
<G-vec00149-002-s308><consider.ziehen><de> Für ihre Anfahrt mit dem Auto können Sie unter anderem die Markierten, zahlungspflichtigen Parkmöglichkeiten in Betracht ziehen.
<G-vec00149-002-s309><consider.ziehen><en> Also, if you want to use Free Live Sex Chat, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s309><consider.ziehen><de> Wenn Sie BongaCams - Live Sex Chat nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s310><consider.ziehen><en> Also, if you want to use Free Live Sex Chat 18 Girl Cam, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s310><consider.ziehen><de> Wenn Sie Free Live Sex Chat 18 Girl Cam nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s311><consider.ziehen><en> According to Reuss, it was important to consider that the Bible was made up of elements relating to the cultural history of Judaism for the Old Testament and primitive Christianity for the New Testament.
<G-vec00149-002-s311><consider.ziehen><de> Für Reuss muss die Entstehung der Bibel die Kulturgeschichte des Judentums für das Alte Testament und die des Urchristentums für das Neue Testament in Betracht ziehen.
<G-vec00149-002-s312><consider.ziehen><en> Also, if you want to use Bongacams.lv, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s312><consider.ziehen><de> Wenn Sie Bongacams.lv nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s314><consider.ziehen><en> Also, if you want to use Jerkoff Webcams Adult sex Chat, you have to consider that our website includes sexually explicit materials which might be prohibited in your region.
<G-vec00149-002-s314><consider.ziehen><de> Wenn Sie Jerkoff Webcams Adult sex Chat nutzen möchten, müssen Sie auch in Betracht ziehen, dass unsere Webseite sexuell eindeutige Inhalte enthält, die in Ihrer Region verboten sein könnten.
<G-vec00149-002-s315><consider.ziehen><en> Talk about how long you're willing to try treatments, what you're willing to spend, and when or if you'd both want to consider other options, such as adoption.
<G-vec00149-002-s315><consider.ziehen><de> Sprecht darüber, wie lange ihr bereit seit bestimmte Behandlungen auszuprobieren, was ihr bereit seit dafür aufzuwenden und wann oder ob ihr beide auch andere Optionen in Betracht ziehen würdet, wie eine Adoption.
<G-vec00149-002-s316><consider.ziehen><en> After taking this tour, you may also like to consider visiting the old Jewish Cemetry on the Lido.
<G-vec00149-002-s316><consider.ziehen><de> Nach dieser Tour können Sie auch den Besuch des alten jüdischen Friedhofs auf dem Lido in Betracht ziehen.
<G-vec00149-002-s317><consider.ziehen><en> I would like to urge the property industry to consider the possibilities of automation and networking as a serious new business field, because many aspects of home automation already go directly to electricians, and therefore, pass by the property industry.
<G-vec00149-002-s317><consider.ziehen><de> Der Immobilienwirtschaft möchte ich ans Herz legen, die Möglichkeiten der Automatisierung und Vernetzung als ernsthaftes, neues Geschäftsfeld in Betracht zu ziehen, denn schon heute gehen viele Gewerke für Heimautomatisierung direkt an den Elektriker und damit an der Immobilienwirtschaft vorbei.
<G-vec00149-002-s318><consider.ziehen><en> We needed to consider various scenarios, but we ultimately signed this agreement because both sides acted constructively.
<G-vec00149-002-s318><consider.ziehen><de> Wir mussten verschiedene Szenarien in Betracht ziehen, aber letztendlich haben wir diese Vereinbarung unterzeichnet, weil beide Seiten konstruktiv agierten.
<G-vec00149-002-s319><consider.ziehen><en> Maybe you wouldn’t want to employ yet another application to protect your data, but it’s an option you might want to consider.
<G-vec00149-002-s319><consider.ziehen><de> Vielleicht möchten Sie keine weitere Anwendung zum Schutz Ihrer Daten einsetzen, aber Sie sollten diese Option in Betracht ziehen.
<G-vec00149-002-s320><consider.ziehen><en> Before you consider using other tools to take a backup of your Firebird database, make sure that you know what the tools do and how a running database will be affected by them.
<G-vec00149-002-s320><consider.ziehen><de> Bevor Sie andere Tools zum Erstellen einer Sicherung Ihrer Firebird-Datenbank in Betracht ziehen, stellen Sie sicher, dass Sie wissen, was die Tools tun und wie sich eine laufende Datenbank auf sie auswirkt.
<G-vec00149-002-s321><consider.ziehen><en> Especially for first-time gamers, you have to consider this option.
<G-vec00149-002-s321><consider.ziehen><de> Speziell für Anfänger sollten Sie diese Option in Betracht ziehen.
<G-vec00149-002-s322><consider.ziehen><en> Aside from using the Mail app on your Mac, you can also try to consider using other email services on the web and an example of which is Gmail on the web.
<G-vec00149-002-s322><consider.ziehen><de> Neben der Verwendung der Mail-App auf Ihrem Mac können Sie auch andere E-Mail-Dienste im Web und ein Beispiel für Google Mail im Web in Betracht ziehen.
<G-vec00149-002-s969><consider.überlegen><en> Consider trying advanced AI and taxonomy powered recruitment tools that will help you identify the candidates with suitable abilities and experiences in the past – for example, a history of effectively working from home or completing projects independently. Establish communication rules
<G-vec00149-002-s969><consider.überlegen><de> Überlegen Sie sich, mit KI und Taxonomie arbeitende Bewerbersuchmaschinen einzusetzen, mit deren Hilfe Sie Kandidaten mit passenden Fähigkeiten und vorherigen Berufserfahrungen leichter finden – zum Beispiel solche, die bereits eine Vergangenheit mit erfolgreicher Telearbeit und der autonomen Erledigung von Projekten vorweisen können.
<G-vec00149-002-s970><consider.überlegen><en> Consider how you can tame a dragon in Maynkraft himself or using fashion.
<G-vec00149-002-s970><consider.überlegen><de> Überlegen Sie, wie Sie einen Drachen in Maynkraft selbst oder mit Mode zähmen können.
<G-vec00149-002-s971><consider.überlegen><en> Consider how Muslims (or, for that matter, Christians) imagine God deals with the souls of people who die without learning about the one true religion.
<G-vec00149-002-s971><consider.überlegen><de> Überlegen Sie, wie die Muslime (oder, für diese Angelegenheit, Christen) vorstellen, Gott mit den Seelen der Menschen, die sterben, ohne das Lernen über die eine wahre Religion.
<G-vec00149-002-s972><consider.überlegen><en> Consider how people like to work these days.
<G-vec00149-002-s972><consider.überlegen><de> Überlegen Sie, wie Menschen heute bevorzugt arbeiten.
<G-vec00149-002-s973><consider.überlegen><en> As you make your plan, consider what you will invite class members to do to help them learn from the scriptures and the words of latter-day prophets.
<G-vec00149-002-s973><consider.überlegen><de> Überlegen Sie beim Aufstellen Ihres Plans, wozu Sie die Unterrichtsteilnehmer auffordern möchten, damit sie aus den heiligen Schriften und den Worten der Propheten aus den Letzten Tagen lernen.
<G-vec00149-002-s974><consider.überlegen><en> Consider, by whom the information was obtained.
<G-vec00149-002-s974><consider.überlegen><de> Überlegen Sie, von wem die Information stammt.
<G-vec00149-002-s975><consider.überlegen><en> Consider whether the courses you’ll take will help you once you graduate.
<G-vec00149-002-s975><consider.überlegen><de> Überlegen Sie, ob die Kurse, die Sie belegen, Ihnen nach Abschluss des Studiums weiterhelfen.
<G-vec00149-002-s976><consider.überlegen><en> If you have limited funds available, consider applying exclusively for partner universities that accept the Language Certificate.
<G-vec00149-002-s976><consider.überlegen><de> Überlegen Sie sich bei knappem Budget, ob Sie sich lieber nur auf Partneruniversitäten bewerben, die das Language Certificate akzeptieren.
<G-vec00149-002-s977><consider.überlegen><en> Consider what effect you want to achieve: a natural holiday photo looks different than an application photo.
<G-vec00149-002-s977><consider.überlegen><de> Überlegen Sie, welche Wirkung Sie erzielen möchten: Ein natürliches Urlaubsfoto wirkt anders als ein steriles Bewerbungsbild.
<G-vec00149-002-s978><consider.überlegen><en> Consider what happened to the unprofitable servants in both parables that Jesus told.
<G-vec00149-002-s978><consider.überlegen><de> Überlegen Sie, was passiert, die unnütze Knechte in beiden Gleichnissen, die Jesus erzählt.
<G-vec00149-002-s979><consider.überlegen><en> Consider what a laserskin resurfacing.Currently, dermatologists and cosmetic surgeons use two types of lasers: carbon dioxide (C02) and erbium YAG-laser is.They have small differences, that is a subject of debate among physicians.Many surgeons claim that the C02 lasers better reduce wrinkles on the face, but it usually leads to a residual redness, follow the treatment, as well as some increase in pigment loss.Erbium YAG-lasers does not provide a good correction of wrinkles, but he gives no redness or skin turns pink for such a long period, and the possibility of pigment loss is significantly lower.At the moment of CO and erbium YAG-laser is give the successful combination of the advantages of both.
<G-vec00149-002-s979><consider.überlegen><de> Überlegen Sie, was ein LaserSkin Resurfacing.Derzeit Dermatologen und Schönheitschirurgen verwenden zwei Arten von Lasern: Kohlendioxid (C02) und Erbium YAG-Laser ist.Sie haben kleine Unterschiede, das ist ein Thema der Debatte unter den Ärzten.Viele Chirurgen behaupten, dass die C02-Laser besser Falten im Gesicht zu reduzieren, aber es führt in der Regel zu einer Rest Rötung, folgen Sie der Behandlung sowie eine Erhöhung der Pigmentverlust.Erbium YAG-Laser bietet keine gute Korrektur von Falten, aber er gibt keine Rötung oder Haut wird rosa für einen so langen Zeitraum, und die Möglichkeit der Pigmentverlust ist deutlich geringer.Im Moment des CO und Erbium YAG-Laser ist die erfolgreiche Kombination der Vorteile beider geben.
<G-vec00149-002-s980><consider.überlegen><en> Consider how the products will get to you and how they will be recycled after you.
<G-vec00149-002-s980><consider.überlegen><de> Überlegen Sie, wie die Produkte zu Ihnen kommen und wie sie nach Ihnen recycelt werden.
<G-vec00149-002-s981><consider.überlegen><en> Consider what needs to be done to make the interior create a holistic impression, and the wallpaper did not look like a foreign element, an extra piece of decor.
<G-vec00149-002-s981><consider.überlegen><de> Überlegen Sie, was getan werden muss, damit das Interieur einen ganzheitlichen Eindruck hinterlässt, und die Tapete sah nicht wie ein fremdes Element aus, sondern ein zusätzliches Dekor.
<G-vec00149-002-s982><consider.überlegen><en> Context is important. Consider who is involved in the discussion and how they represent the rest of the community.
<G-vec00149-002-s982><consider.überlegen><de> Der Kontext ist wichtig: Überlegen Sie, wer an der Diskussion beteiligt ist und wie die Diskutanten den Rest der Gemeinschaft repräsentieren.
<G-vec00149-002-s983><consider.überlegen><en> Consider adjusting your colour scheme and using seasonal banners or videos.
<G-vec00149-002-s983><consider.überlegen><de> Überlegen Sie, das Farbschema anzupassen und setzen Sie saisonale Banner oder Videos ein.
<G-vec00149-002-s984><consider.überlegen><en> Consider how quickly your little one is growing before investing in a reusable swim diaper.
<G-vec00149-002-s984><consider.überlegen><de> Überlegen Sie, wie schnell Ihr Kleines wächst, bevor Sie in eine wiederverwendbare Schwimmwindel investieren.
<G-vec00149-002-s985><consider.überlegen><en> Consider how your media plan would look on points of influence.
<G-vec00149-002-s985><consider.überlegen><de> Überlegen Sie sich einmal, wie Ihr Mediaplan aussehen könnte, wenn er auf dem Einfluss basieren würde.
<G-vec00149-002-s986><consider.überlegen><en> Consider how you can become an influential source of information for your audience by creating your own free content strategy, then amplifying it with paid media.
<G-vec00149-002-s986><consider.überlegen><de> Überlegen Sie, wie Sie eine einflussreiche Quelle an Informationen für Ihr Publikum werden könnten, indem Sie Ihre eigene kostenlose Content-Strategie entwickeln, welche Sie mit Paid Media verstärken könnten.
<G-vec00149-002-s987><consider.überlegen><en> Consider how to make a calculation using the sand filter.
<G-vec00149-002-s987><consider.überlegen><de> Überlegen Sie, wie Sie eine Berechnung mit dem Sandfilter durchführen.
<G-vec00149-002-s1007><consider.überlegen><en> Therefore - before you come to Heidelberg - we strongly advise you to carefully consider which services you will need to use at the university and to choose the visa and the form of registration (either #1 visiting doctoral candidate/visa §16b for study purposes OR #2 visiting researcher/visa §18d for research purposes) that will give you access to these services.
<G-vec00149-002-s1007><consider.überlegen><de> Daher raten wir Ihnen dringend, vor der Beantragung des Visums sorgfältig zu überlegen, welche Dienstleistungen Sie an der Universität in Anspruch nehmen möchten und darauf basierend wählen Sie das Visum und die Form der Registrierung (entweder #1 Forschungsstudent/Visum §16b für Studienzwecke oder #2 Gastwissenschaftler/Visum §18d für Forschungszwecke), die Ihnen Zugang zu diesen Dienstleistungen ermöglichen.
<G-vec00149-002-s1008><consider.überlegen><en> If we consider how it must be for each individual animal when they move in these large, fast groups we begin to understand why the animals are more reliant on their acoustics than they are on their vision.
<G-vec00149-002-s1008><consider.überlegen><de> Wenn wir überlegen, wie es für jedes einzelne Tier sein muss, wenn es sich in diesen großen, schnellen Gruppen bewegt, beginnen wir zu verstehen, warum die Tiere mehr auf ihre Akustik als auf ihre Vision angewiesen sind.
<G-vec00149-002-s1009><consider.überlegen><en> Since experience shows, however, that it is difficult to interpret the undefined terms of humanity, respect or even dignity as such, in the end the only help comes from the decision to stop and consider what is the true objective of medicine instead of relying on interpretation.
<G-vec00149-002-s1009><consider.überlegen><de> Da es jedoch erfahrungsgemäss schwierig ist, die unbestimmten Begriffe Menschlichkeit, Ehrfurcht oder auch Würde als solche zu interpretieren, hilft letztlich nur die Entscheidung weiter, sich anstelle einer solchen Interpretation zu überlegen, welches denn die eigentliche Aufgabe der Medizin sei.
<G-vec00149-002-s1010><consider.überlegen><en> Gamers should thoroughly consider the investment of 883 euro because laptops with a superior ATI HD 5650 and similarly strong processor are available for less.
<G-vec00149-002-s1010><consider.überlegen><de> Spieler sollten sich die 882 Euro teure Anschaffung genau überlegen, denn Laptops mit besserer ATI HD 5650 und ähnlich starken Prozessoren gibt es auch für weniger Geld.
<G-vec00149-002-s1011><consider.überlegen><en> However, you can consider whether it makes sense to write an hour back and forth with one person.
<G-vec00149-002-s1011><consider.überlegen><de> Allerdings können Sie sich überlegen, ob es sinnvoll ist, mit einer Person eine Stunde hin und her zu schreiben.
<G-vec00149-002-s1012><consider.überlegen><en> You should consider whether you understand how CFDs work and whether you can afford to take the high risk of losing your money.’
<G-vec00149-002-s1012><consider.überlegen><de> Sie sollten sich überlegen, ob Sie es sich leisten können, das hohe Risiko einzugehen, möglicherweise einen Teil Ihres Geldes zu verlieren.
<G-vec00149-002-s1013><consider.überlegen><en> After that, you can still consider which items you want to buy and what not and there. Real handy!
<G-vec00149-002-s1013><consider.überlegen><de> Danach können Sie immer noch überlegen, welche Artikel Sie kaufen und möchten und welche momentan noch nicht.
<G-vec00149-002-s1014><consider.überlegen><en> The United Nations factored the great world religions in different initiatives and discussions and consider with them together which strategies would help us to move on.
<G-vec00149-002-s1014><consider.überlegen><de> Die Vereinten Nationen beziehen die großen Weltreligionen in verschiedene Initiativen und Gespräche mit ein und überlegen mit ihnen gemeinsam, welche Strategien helfen, hier weiter zu kommen.
<G-vec00149-002-s1015><consider.überlegen><en> However, individuals must also carefully consider whether they might want to register the corresponding domain.
<G-vec00149-002-s1015><consider.überlegen><de> Aber auch Privatpersonen müssen sich sehr gut überlegen, ob sie nicht auch die entsprechende Domain registrieren lassen möchten.
<G-vec00149-002-s1016><consider.überlegen><en> Businesses are universally being called upon to consider how their resources may be applied against creating the maximum positive social impact, at a time when their usual ability to commercially transact has either come under serious threat or been immediately suspended.
<G-vec00149-002-s1016><consider.überlegen><de> Die Unternehmen sind allgemein aufgefordert, zu überlegen, wie ihre Ressourcen gegen die Schaffung eines maximalen positiven sozialen Einflusses eingesetzt werden können, und das zu einem Zeitpunkt, an dem ihre üblichen Möglichkeiten zur kommerziellen Abwicklung entweder ernsthaft gefährdet oder sofort ausgesetzt wurden.
<G-vec00149-002-s1017><consider.überlegen><en> In that constellation, we discussed how to move forwards in Libya at a time when important conflict parties have agreed on a peace agreement and we now need to consider how to get as many as possible to join in concluding a treaty that will lead to the establishment of a government of national unity.
<G-vec00149-002-s1017><consider.überlegen><de> Gemeinsam haben wir in diesem Format darüber beraten, wie es in Libyen weitergehen kann zu einem Zeitpunkt, an dem wichtige Konfliktparteien sich auf ein Friedensabkommen verständigt haben und an dem wir überlegen müssen, wie wir möglichst viele zum Abschluss eines Vertrages bringen können, der zur Einsetzung einer Regierung der Nationalen Einheit führt.
<G-vec00149-002-s1018><consider.überlegen><en> Carefully consider which is the origin of fear, how real he is, how real is the danger.
<G-vec00149-002-s1018><consider.überlegen><de> Sorgfältig überlegen, Woher stammt die Angst, wie es wirklich ist, wie Real ist die Gefahr.
<G-vec00149-002-s1019><consider.überlegen><en> This step will take time and cost, but let's still consider it - after all, the time and money spent on such a device will be worth it if you have a large family that uses a lot of hot water every day.
<G-vec00149-002-s1019><consider.überlegen><de> Dieser Schritt wird Zeit und Kosten kosten, aber lasst es uns immer noch überlegen - schließlich sind die Zeit und das Geld, die für ein solches Gerät ausgegeben werden, es wert, wenn Sie eine große Familie haben, die jeden Tag viel heißes Wasser verbraucht.
<G-vec00149-002-s1020><consider.überlegen><en> One should therefore consider in advance how to determine the offer price and quantity, since the fee is incurred directly and cannot be adjusted or adapted later, as well as PPC.
<G-vec00149-002-s1020><consider.überlegen><de> Man sollte sich also vorher gut überlegen, wie man Angebotspreis und Stückzahl wählt, da die Gebühr direkt anfällt und nicht, wie bei PPC, nachträglich noch angepasst und justiert werden kann.
<G-vec00149-002-s1021><consider.überlegen><en> In order to take part in the competition it is required that users will post the specification of their machine with a photograph on to the Club3D Facebook and whatever level your computer is we will consider how it can be upgraded to improve performance based on what components are already inside.
<G-vec00149-002-s1021><consider.überlegen><de> Um an dem Wettbewerb teilzunehmen ist es erforderlich, dass die Teilnehmer die Spezifikation Ihres Rechners mit einem Bild bei Club3D Facebook posten und egal welchen Level der Computer hat, werden wir uns überlegen, was Sinn macht um diesen Computer aufzurüsten um die Leistung zu verbessern, basierend auf den Komponenten, die schon im Rechner sind.
<G-vec00149-002-s1022><consider.überlegen><en> To those in charge, another important aspect to consider is that, in addition to the current preservative ventures, the creation of a high-quality "Füred wine track", with good local character will contribute heavily to local and foreign media viewing Balatonfüred as a city honoring its natural and cultural heritage.
<G-vec00149-002-s1022><consider.überlegen><de> Für die Entscheider ist es ein weitere Punkt zu überlegen, dass eine mit hoher Qualität großzügig formierte "Kellerreihe von Füred" mit lokaler Charakter dazu zusteuern kann, dass Balatonfüred wieder als ihr natürliches und kulturelles Erbe ehrende Stadt von dem heimischen und ausländischen öffentlichen Urteil geschätzt sei.
<G-vec00149-002-s1023><consider.überlegen><en> If you find the coverage area of your WiFi network less than satisfactory, you should consider using a WiFi extender.
<G-vec00149-002-s1023><consider.überlegen><de> Wenn Sie die Abdeckungsreichweite Ihres Netzwerks weniger als zufriedenstellend finden, sollten Sie sich überlegen, einen WiFi-Extender zu nutzen.
<G-vec00149-002-s1024><consider.überlegen><en> To give an answer to this question, first of all we will consider what should not be done by adults.
<G-vec00149-002-s1024><consider.überlegen><de> Um eine Antwort auf diese Frage zu geben, werden wir zuerst überlegen, was Erwachsene nicht tun sollten.
<G-vec00149-002-s1025><consider.überlegen><en> For the two projects that due to the strong competition have not been invited to submit full proposals, TU Dresden will now consider whether they can be in part implemented through other funding programmes.
<G-vec00149-002-s1025><consider.überlegen><de> Für die Cluster, die trotz hoher Qualität aufgrund des starken Wettbewerbs nicht als Exzellenzcluster gefördert werden, wird die TU Dresden nun überlegen, ob und wie sie in Teilen gegebenenfalls über andere Förderprogramme realisiert werden können.
