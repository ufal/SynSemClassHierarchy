<G-vec00361-002-s076><challenge.fordern><en> Challenge sixty computer controlled opponents over three levels of difficulty... Blazing Birds
<G-vec00361-002-s076><challenge.fordern><de> Schalte das vollständige Spiel Blazing Birds frei und fordere sechzig computergesteuerte Gegner auf drei Schwierigkeitsstufen...
<G-vec00361-002-s077><challenge.fordern><en> I challenge you not to let your resolve dribble out and your commitment to follow the Savior evaporate.
<G-vec00361-002-s077><challenge.fordern><de> Ich fordere euch auf, nicht zuzulassen, dass eure Entschlossenheit nachlässt und euer Vorsatz, dem Heiland zu folgen, sich verflüchtigt.
<G-vec00361-002-s078><challenge.fordern><en> Engage thrusters for intense side-scrolling space battles, challenge yourself in a variety of virtual reality minigames and come to the rescue of allies in all sorts of side-missions.
<G-vec00361-002-s078><challenge.fordern><de> Setze Druckantriebe für intensive Weltraumkämpfe ein, die über mehrere Seiten gescrollt werden, fordere dich selbst in einer Vielfalt von Virtual-Reality Minispielen heraus und komme Aliens in allen möglichen Nebenmissionen zu Hilfe.
<G-vec00361-002-s079><challenge.fordern><en> You can challenge rivals at Motorcycle Festivals divided into three different track typologies: from the thrills of the GP Tracks, through the beautiful landscapes of the Country Tracks, and all the way to the challenge of the City Tracks.
<G-vec00361-002-s079><challenge.fordern><de> Fordere Rivalen bei Motorrad-Events heraus, die in drei unterschiedliche Streckentypen aufgeteilt sind: vom Nervenkitzel der GP-Strecken über die malerischen Landschaften bei Überland-Strecken bis hin zu den Herausforderungen von Stadt-Strecken.
<G-vec00361-002-s080><challenge.fordern><en> Challenge your friends in a multiplayer car race and try to beat other skilled computer players.
<G-vec00361-002-s080><challenge.fordern><de> Fordere deine Freunde im Multiplayer-Rennen und versuchen, andere erfahrene Computer-Spieler zu schlagen.
<G-vec00361-002-s081><challenge.fordern><en> Challenge yourself to complete all three and become part of the TRIFECTA tribe.
<G-vec00361-002-s081><challenge.fordern><de> Fordere dich selbst heraus, nehme an allen drei Races teil und werde Teil des TRIFECTA-Stammes.
<G-vec00361-002-s082><challenge.fordern><en> Train and advance your abilities in six game modes, and challenge your family and friends in the Battle Race to become the Ultimate Champion.
<G-vec00361-002-s082><challenge.fordern><de> Trainiere und verbessere deine Fähigkeiten in sechs Spielmodi und fordere deine Familie und Freunde in Kampfrennen heraus, um der ultimative Champion zu werden.
<G-vec00361-002-s083><challenge.fordern><en> Challenge time and space in this all new puzzle game!
<G-vec00361-002-s083><challenge.fordern><de> Fordere Zeit und Raum in diesem brandneuen Puzzle-Spiel heraus.
<G-vec00361-002-s084><challenge.fordern><en> I challenge every single Fyros to convince me of the opposite, to defeat me in a fair duell.
<G-vec00361-002-s084><challenge.fordern><de> Ich fordere jeden einzelnen Fyros dazu auf mich vom Gegenteil zu überzeugen und mich in einem fairen Duell zu besiegen.
<G-vec00361-002-s085><challenge.fordern><en> I issue a challenge to you who are leaders and future leaders to recognize that the world is changing rapidly.
<G-vec00361-002-s085><challenge.fordern><de> Ich fordere Sie, die Sie derzeit Führungspositionen innehaben oder künftig innehaben werden, auf: Machen Sie sich bewusst, dass sich die Welt rasant verändert.
<G-vec00361-002-s086><challenge.fordern><en> Challenge your friends in unique multiplayer combat.
<G-vec00361-002-s086><challenge.fordern><de> Fordere deine Freunde zu einzigartigen Mehrspielerkämpfen heraus.
<G-vec00361-002-s087><challenge.fordern><en> Explore the new Kingdom of Trivia Crack and challenge your friends, family and classmates in trivia channels based on your favorite topics.
<G-vec00361-002-s087><challenge.fordern><de> Erforsche das neue Königreich von Trivia Crack und fordere deine Freunde, Familie und Klassenkameraden in Quiz Kanälen, die sich auf deine Lieblingsthemen beziehen, heraus.
<G-vec00361-002-s088><challenge.fordern><en> Then Challenge you brain to solve logic puzzles of every kind with our free brainteaser games.
<G-vec00361-002-s088><challenge.fordern><de> Dann fordere dein Gehirn heraus, Logikrätsel jeder Art mit unseren freien Brainteaser-Spielen zu lösen.
<G-vec00361-002-s089><challenge.fordern><en> Challenge your friends to a 1-minute gem-blasting competition!
<G-vec00361-002-s089><challenge.fordern><de> Fordere deine Freunde zu einem 1-minütigen Juwelen-Detonierspiel auf.
<G-vec00361-002-s090><challenge.fordern><en> Challenge your family, friends and other users on bab.la and compete for the number one position.
<G-vec00361-002-s090><challenge.fordern><de> Fordere Deine Freunde, Familie und andere Benutzer auf bab.la heraus und konkurriere um den ersten Weltranglisten-Platz.
<G-vec00361-002-s091><challenge.fordern><en> Challenge the computer to a chess960 (Random-Fischer) game. Bughouse Chess
<G-vec00361-002-s091><challenge.fordern><de> Fordere den Computer zu einer Partie Schach960 (Fischer-Random) heraus.
<G-vec00361-002-s092><challenge.fordern><en> Votes: 410 Mortal blade 3D - take a sword, put on outfit and challenge enemy knights, insidious usurpers and powers of evil.
<G-vec00361-002-s092><challenge.fordern><de> Nimm in Mortal Blade 3D dein Schwert, ziehe deine Rüstung an und fordere feindliche Ritter, listige Usurpatoren und die Mächte des Bösen heraus.
<G-vec00361-002-s093><challenge.fordern><en> Challenge friends and others in a battle of reaction, unleashing the champion within you.
<G-vec00361-002-s093><challenge.fordern><de> Fordere Freunde und andere in einem Reaktionswettkampf heraus, und entfessle den Champion in dir.
<G-vec00361-002-s094><challenge.fordern><en> Create your own custom levels and challenge your friends to beat it.
<G-vec00361-002-s094><challenge.fordern><de> Erstellen Sie Ihre eigenen Level und fordere deine Freunde zu schlagen.
<G-vec00361-002-s095><challenge.herausfordern><en> When you feel that doing something will make you feel confident and excited, but can't do it because of anxiety or self-consciousness, then at the same time, challenge yourself.
<G-vec00361-002-s095><challenge.herausfordern><de> Wenn du das Gefühl hast, dass etwas dir mehr Selbstvertrauen und Begeisterung bringen könnte, du dich aber gleichzeitig aufgrund von Ängsten und der eigenen Unsicherheit nicht traust es zu tun, fordere dich selbst dazu heraus.
<G-vec00361-002-s096><challenge.herausfordern><en> Challenge your friends on the leader boards to prove who is the best.
<G-vec00361-002-s096><challenge.herausfordern><de> Fordere deine Freunde beim Leaderboard heraus und beweise, wer der Beste ist.
<G-vec00361-002-s097><challenge.herausfordern><en> Discover your new favorite game, then challenge your friends and track your achievements.
<G-vec00361-002-s097><challenge.herausfordern><de> Entdecke dein neues Lieblingsspiel, fordere deine Freunde heraus und halte deine Erfolge fest.
<G-vec00361-002-s098><challenge.herausfordern><en> Challenge your cat by moving your fingers across the outside of the bag or box.
<G-vec00361-002-s098><challenge.herausfordern><de> Fordere deine Katze heraus, indem du mit deinen Fingern über die Außenseite der Tasche oder des Kartons streifst.
<G-vec00361-002-s099><challenge.herausfordern><en> After you've gone to a few club meetings, concerts, or volunteer sessions, and have a few conversations under your belt, challenge yourself to take the initiative and invite someone else to do something with you.
<G-vec00361-002-s099><challenge.herausfordern><de> Nachdem du zu ein paar Klub-Meetings, Konzerten oder Sitzungen von Ehrenamtlichen gegangen bist und ein paar Gespräche auf deinem Konto hast, fordere dich selbst heraus, die Initiative zu übernehmen und jemanden einzuladen, etwas mit dir zu unternehmen.
<G-vec00361-002-s100><challenge.herausfordern><en> Challenge friends online and engage in intense, action-packed real-time battles.
<G-vec00361-002-s100><challenge.herausfordern><de> Fordere deine Freunde online heraus und stürzt euch gemeinsam in packende, action-geladene Echtzeitschlachten.
<G-vec00361-002-s101><challenge.herausfordern><en> Challenge friends for thrilling competitions.
<G-vec00361-002-s101><challenge.herausfordern><de> Fordere Deine Freunde zu aufregenden Wettkämpfen heraus.
<G-vec00361-002-s102><challenge.herausfordern><en> Challenge the universe.
<G-vec00361-002-s102><challenge.herausfordern><de> Fordere das Universum heraus.
<G-vec00361-002-s103><challenge.herausfordern><en> Talk and challenge other players to games.
<G-vec00361-002-s103><challenge.herausfordern><de> Sprich mit anderen Spielen und fordere sie zu einem Spiel heraus.
<G-vec00361-002-s104><challenge.herausfordern><en> Connect to Facebook and challenge your friends.
<G-vec00361-002-s104><challenge.herausfordern><de> Verbinde dich mit Facebook und fordere deine Freunde heraus.
<G-vec00361-002-s105><challenge.herausfordern><en> Challenge friends online by connecting to Facebook, and show the world who the real boss is.
<G-vec00361-002-s105><challenge.herausfordern><de> Fordere Freunde online heraus, indem du dich mit Facebook verbindest und zeigst, wer der Boss ist.
<G-vec00361-002-s106><challenge.herausfordern><en> This is why I challenge YOU, to not share, retweet or consume the propaganda of these haters.
<G-vec00361-002-s106><challenge.herausfordern><de> Daher fordere ich Dich heraus, die Propaganda dieser Menschenhasser nicht zu teilen, zu retweeten oder zu konsumieren.
<G-vec00361-002-s107><challenge.herausfordern><en> Explore encounters, challenge powerful bosses and gain treasure in Dark Souls™: The Card Game. Take on the class of Herald, Knight, Assassin or Sorcerer in this officially licensed survival game for 1-4 players.
<G-vec00361-002-s107><challenge.herausfordern><de> Erlebe Begegnungen, fordere mächtige Bosse heraus und finde Schätze: Tritt ein in die Klasse des Herolds, Ritters, Assassinen oder Zauberers in diesem offiziell lizenzierten Survival-Spiel für 1 bis 4 Spieler.
<G-vec00361-002-s108><challenge.herausfordern><en> • Challenge friends and family through Facebook or find a random opponent
<G-vec00361-002-s108><challenge.herausfordern><de> • Fordere Freunde per SMS oder über Facebook heraus oder spiele gegen einen zufälligen Gegner.
<G-vec00361-002-s109><challenge.herausfordern><en> I challenge you to read Isaiah 53 and see if what I am saying is true.
<G-vec00361-002-s109><challenge.herausfordern><de> Ich fordere dich heraus, Jesaja 53 zu lesen und zu prüfen, ob das was ich sage wahr ist.
<G-vec00361-002-s110><challenge.herausfordern><en> Ask the dive guides about the best diving spots and challenge yourself.
<G-vec00361-002-s110><challenge.herausfordern><de> Frag die Tauchguides nach den besten Punkten zum Abtauchen und fordere dich selbst heraus.
<G-vec00361-002-s111><challenge.herausfordern><en> And wherever I go I challenge young people – as a friend – to live in the light and truth of Jesus Christ.
<G-vec00361-002-s111><challenge.herausfordern><de> Und überall, wo ich hinreise, fordere ich die jungen Menschen freundschaftlich heraus, im Licht und in der Wahrheit Jesu Christi zu leben.
<G-vec00361-002-s112><challenge.herausfordern><en> I challenge anyone who thinks that work in the Kindergarten is a simple matter of "daycare".
<G-vec00361-002-s112><challenge.herausfordern><de> Ich fordere jeden heraus, der glaubt, ein Kindergarten sei nur eine simple Frage der "Betreuung".
<G-vec00361-002-s113><challenge.herausfordern><en> Break records in classic races based on distance or time and challenge yourself again and again.
<G-vec00361-002-s113><challenge.herausfordern><de> Breche Fahrrekorde bei klassischen Rennen nach Streckenlänge oder Zeit und fordere dich jedes Mal neu heraus.
<G-vec00361-002-s399><challenge.hinterfragen><en> One declared goal of the network is to spread knowledge of the former youth concentration camp, to create a worthy memorial site, to strengthen an antifascist commemorative culture and to critically challenge state practices of remembering.
<G-vec00361-002-s399><challenge.hinterfragen><de> Ein erklärtes Ziel des Netzwerkes ist es, das ehemalige Jugendkonzentrationslager bekannt zu machen, einen würdigen Gedenkort zu schaffen, eine antifaschistische Erinnerungskultur zu stärken und staatliche Erinnerungspraxen kritisch zu hinterfragen.
<G-vec00361-002-s400><challenge.hinterfragen><en> We’ve made a long-standing commitment to programs and eligible community organizations that strive to challenge the status quo in education, health and services to U.S. veterans.
<G-vec00361-002-s400><challenge.hinterfragen><de> Wir setzen uns seit langem für Programme und geeignete soziale Organisationen ein, die den Status Quo hinsichtlich Bildung, medizinischer Versorgung und Serviceleistungen für US-Veteranen hinterfragen.
<G-vec00361-002-s401><challenge.hinterfragen><en> The paintings by the artist Maria Wolfram challenge the way we look at the world surrounding us.
<G-vec00361-002-s401><challenge.hinterfragen><de> Die Bilder der Künstlerin Maria Wolfram hinterfragen den Blick, den wir auf unsere Welt werfen.
<G-vec00361-002-s402><challenge.hinterfragen><en> A unique exhibition curated by the artist David Hammons, Quiet as it's Kept, an exhibition featuring three painters based in New York, seeks to challenge the comforting discourse surrounding the presumed transnational identity of abstract painting.
<G-vec00361-002-s402><challenge.hinterfragen><de> Mit der außergewöhnlichen Ausstellung Quiet as it's Kept, in der drei New Yorker Maler Arbeiten präsentieren, versucht der Kurator und Künstler DAVID HAMMONS den gängigen Diskurs um den angeblich übernationalen Charakter abstrakter Malerei zu hinterfragen.
<G-vec00361-002-s403><challenge.hinterfragen><en> In practice, we work closely with our developers to understand our goals, challenge assumptions, and test continuously.
<G-vec00361-002-s403><challenge.hinterfragen><de> In der Praxis bedeutet das eine enge Zusammenarbeit mit unseren Entwicklern, um unsere Ziele zu verstehen, Annahmen zu hinterfragen und kontinuierlich zu testen.
<G-vec00361-002-s404><challenge.hinterfragen><en> 10 We must be free to challenge all limits to freedom of expression and information justified on such grounds as national security, public order, morality and the protection of intellectual property.
<G-vec00361-002-s404><challenge.hinterfragen><de> 10 Wir sollten in der Lage sein, alle Einschränkungen der Meinungs- und Informationsfreiheit zu hinterfragen, die beispielsweise mit der Aufrechterhaltung der Moral, der öffentlichen Ordnung, der nationalen Sicherheit oder dem Schutz geistigen Eigentums begründet werden.
<G-vec00361-002-s405><challenge.hinterfragen><en> The platform aims to express the experience of thinking in several languages and to challenge the rigidity of existing forms of knowledge.
<G-vec00361-002-s405><challenge.hinterfragen><de> Es geht darum, das Denken in mehreren Sprachen erfahrbar zu machen und die Stabilität bestehender Wissensformationen zu hinterfragen.
<G-vec00361-002-s406><challenge.hinterfragen><en> Its current slowdown appears to arise from a failure by the Communist Party to challenge the monopoly powers of state-owned enterprises and to free up new sectors for private enterprise.
<G-vec00361-002-s406><challenge.hinterfragen><de> Der aktuelle Abschwung scheint dem Versäumnis der Kommunistischen Partei geschuldet zu sein, die Monopolstellung der Staatsbetriebe zu hinterfragen und neue Sektoren für Privatunternehmen zu öffnen.
<G-vec00361-002-s407><challenge.hinterfragen><en> It was probably a certain boredom I felt after these designs that made me want to challenge conventional tubular steel constructions.
<G-vec00361-002-s407><challenge.hinterfragen><de> Wahrscheinlich war es eine gewisse Langeweile nach diesen Entwürfen, die mich dazu bewegt hat, die gängigen Stahlrohrkonstruktionen zu hinterfragen.
<G-vec00361-002-s408><challenge.hinterfragen><en> In order to challenge this assumption a questionnaire was developed in the course of this master study and the employees at four Viennese institutions were asked how they evaluate KISS as an adequate choice for low threshold drug work.
<G-vec00361-002-s408><challenge.hinterfragen><de> Um diese Annahme zu hinterfragen wurde für diese Masterthese eine Fragebogenstudie entwickelt und die Mitarbeiter/inn/en von vier Wiener Einrichtungen wurden befragt, ob sie KISS als ein passendes Angebot für Klient/inn/en der niedrigschwelligen Drogenarbeit beurteilen.
<G-vec00361-002-s409><challenge.hinterfragen><en> We systematically challenge our methods and procedures at our dental practice in Dusseldorf.
<G-vec00361-002-s409><challenge.hinterfragen><de> In unserer Zahnarztpraxis in Düsseldorf hinterfragen wir systematisch unsere Methoden und Abläufe.
<G-vec00361-002-s410><challenge.hinterfragen><en> Against the background of Gerhard Oberhammer's hermeneutics of religious traditions the contributors challenge from their professional viewpoint the traditional understanding of the relationship between certainty of belief and truth and give reasons that certainty of belief found in a special religious tradition cannot claim absolute truth, even if its validity within a tradition is not to be denied. in religiöser Tradition
<G-vec00361-002-s410><challenge.hinterfragen><de> Vor dem Hintergrund der von Gerhard Oberhammer entwickelten Religionshermeneutik hinterfragen alle Autoren in ihren Beiträgen ein traditionelles Verständnis der Beziehung zwischen Glaubensgewissheit und Wahrheit, und machen Gründe dafür geltend, dass die Glaubensgewissheit in der jeweils untersuchten religiösen Tradition Bedingungen unterliegt, die ihr zwar einen Wahrheitsgehalt nicht absprechen, den Anspruch auf absolute Wahrheit jedoch in Frage stellen.
<G-vec00361-002-s411><challenge.hinterfragen><en> We collaborate with artists to develop and curate exhibition projects that challenge classical approaches and expand established formats.
<G-vec00361-002-s411><challenge.hinterfragen><de> In Zusammenarbeit mit Künstlern entwickeln und kuratieren wir Ausstellungsprojekte, die klassische Herangehensweisen hinterfragen und etablierte Formate erweitern.
<G-vec00361-002-s412><challenge.hinterfragen><en> In their work Schmidt Schmidt Hansen challenge the limitations of the methods by processing materials and ideas beyond a preconceived system or concept.
<G-vec00361-002-s412><challenge.hinterfragen><de> In ihrer Arbeit hinterfragen Schmidt Schmidt Hansen die begrenzten methodischen Möglichkeiten durch einen Prozess der Wiederholung von Materialien und Ideen, die das vorgegebene System oder Konzept transformieren.
<G-vec00361-002-s413><challenge.hinterfragen><en> Until that happens, be critical, do not hesitate to challenge formulated goals and adapt them to altered circumstances.
<G-vec00361-002-s413><challenge.hinterfragen><de> Bis dahin gilt es wachsam zu bleiben, die formulierten Ziele kritisch zu hinterfragen und bei Bedarf an neue Umstände anzupassen.
<G-vec00361-002-s414><challenge.hinterfragen><en> This course is aimed at any professional seeking to learn new skills and techniques to effectively solve problems and explore and challenge their own critical thinking style.
<G-vec00361-002-s414><challenge.hinterfragen><de> Dieses Training richtet sich an Projektmanager und Mitarbeiter, die Probleme mithilfe neuer Techniken lösen und ihre Art zu denken beleuchten und kritisch hinterfragen möchten.
<G-vec00361-002-s415><challenge.hinterfragen><en> Be able to speak up and challenge with the intent of making things better.
<G-vec00361-002-s415><challenge.hinterfragen><de> Seien Sie in der Lage, den Mund auf zu machen, und Dinge zu hinterfragen, um sie besser zu machen.
<G-vec00361-002-s416><challenge.hinterfragen><en> We are committed to delivering a uniform and sustainable product, and we challenge conventional thinking through innovation.
<G-vec00361-002-s416><challenge.hinterfragen><de> Wir haben den Anspruch, ein homogenes und nachhaltiges Produkt zu liefern, und hinterfragen konventionelle Denkweisen durch Innovation.
<G-vec00361-002-s417><challenge.hinterfragen><en> James Watt: We love to challenge people's perceptions about what beer is and how it can be served.
<G-vec00361-002-s417><challenge.hinterfragen><de> James Watt: Wir lieben es, die allgemeinen Vorstellungen zu hinterfragen, was Bier eigentlich ist und wie es präsentiert werden kann.
<G-vec00361-002-s304><challenge.stellen><en> They tell us that you rose to this challenge, blazing your own trails to the undead lurking there.
<G-vec00361-002-s304><challenge.stellen><de> Offenbar habt Ihr Euch der Herausforderung gestellt und selbst den Weg zu den lauernden Untoten dort freigekämpft.
<G-vec00361-002-s305><challenge.stellen><en> We were happy to take up this challenge and created the brand new triobike cargo big.
<G-vec00361-002-s305><challenge.stellen><de> Gerne haben wir uns dieser Herausforderung gestellt und haben das brandneue Triobike Cargo Big entwickelt.
<G-vec00361-002-s306><challenge.stellen><en> In order to reach a good and satisfactory way of life the therapist as well as the patient are both faced with a major challenge, namely to accept the topic: sexuality and cancer.
<G-vec00361-002-s306><challenge.stellen><de> Um eine gelungene befriedi-gende Lebenssituation für den Patienten zu erreichen, sind sowohl der Behandler als auch der Patient vor eine Herausforderung gestellt: nämlich sich dieses Themas Sexualität und Krebs anzunehmen.
<G-vec00361-002-s307><challenge.stellen><en> At the same time I want to thank each and every participant who took up this great challenge and submitted his or her ideas.
<G-vec00361-002-s307><challenge.stellen><de> Gleichzeitig möchte ich jedem Teilnehmer danken, der sich dieser großen Herausforderung gestellt und seine Ideen eingereicht hat.
<G-vec00361-002-s308><challenge.stellen><en> But she faces a formidable challenge – will she be able to overcome her fear and combine business with pleasure?
<G-vec00361-002-s308><challenge.stellen><de> Erst als sie dann vor eine große Herausforderung gestellt wird kann sie ihre Angst überwinden und am Ende das Angenehme mit dem Nützlichen verbinden.
<G-vec00361-002-s309><challenge.stellen><en> Jacking Pipes Under Railway Track in Třinec, CZ Pipelines crossing traffic routes, streams or buildings pose a big challenge to contractors.
<G-vec00361-002-s309><challenge.stellen><de> HOBAS GRP Třinec, CZ Wenn Rohrleitungen unter Verkehrswegen, Wasserläufen oder Gebäuden verlaufen, werden Bauherren vor eine große Herausforderung gestellt.
<G-vec00361-002-s310><challenge.stellen><en> SilverStone engineers, whom are used to creating no compromise products such as cases that offer world-class cooling with minimal noise, took up the challenge to design a cable that will allow SATA connectors to be used even with long graphics cards installed.
<G-vec00361-002-s310><challenge.stellen><de> Die Ingeneure von SilverStone, welche grundsätzlich beim Design von Produkten keine Kompromisse eingehen, beispielsweise bei der Entwicklung von Gehäusen, die, bei minimaler Lärmentwicklung, erstklassige Kühlung erlauben, haben sich der Herausforderung gestellt, ein Kabel zu entwickeln, das es gestattet, auf die SATA-Stecker zuzugreifen, selbst wenn eine lange Grafikkarte verwendet wird.
<G-vec00361-002-s311><challenge.stellen><en> We are glad you accepted our little challenge and that all of your cards are so beautiful and versatile.
<G-vec00361-002-s311><challenge.stellen><de> Wir freuen uns, dass ihr euch unserer kleinen Herausforderung gestellt habt und dabei so tolle und vielfältige Karten entstanden sind.
<G-vec00361-002-s312><challenge.stellen><en> Aurelia faced this challenge and was 7 weeks as volunteer in the Dominican Republic.
<G-vec00361-002-s312><challenge.stellen><de> Aurelia hat sich dieser Herausforderung gestellt und war 7 Wochen als Volunteer in der Dominikanischen Republik.
<G-vec00361-002-s313><challenge.stellen><en> Many online retailers have already stepped up to this challenge and are now performing active price management.
<G-vec00361-002-s313><challenge.stellen><de> Viele Online-Händler haben sich dieser Herausforderung bereits gestellt und betreiben ein aktives Preismanagement.
<G-vec00361-002-s314><challenge.stellen><en> After the remarkable success we had with our first collection of wallpapers, we took a big challenge to create the second one.
<G-vec00361-002-s314><challenge.stellen><de> Nach dem bemerkenswerten Erfolg, den wir mit unserer ersten Tapetenkollektion hatten, haben wir uns der großen Herausforderung gestellt, die zweite zu kreieren.
<G-vec00361-002-s315><challenge.stellen><en> The new film follows the same principle as the first Takko film: The friends face a challenge when something doesn’t quite go to plan.
<G-vec00361-002-s315><challenge.stellen><de> Der neue Film folgt dem gleichen Prinzip wie schon der erste Takko-Film: Die Freundinnen werden vor eine Herausforderung gestellt, als etwas nicht nach Plan läuft.
<G-vec00361-002-s316><challenge.stellen><en> Fearing the war, numerous property owners throughout the city sold their real estate, and in the midst of this tense situation, his next challenge confronted Paul Galli.
<G-vec00361-002-s316><challenge.stellen><de> Aus Furcht vor dem Krieg verkauften zahlreiche Hausbesitzer in der ganzen Stadt ihre Liegenschaften und mitten in der gespannten Lage wurde Paul Galli vor seine nächste Herausforderung gestellt.
<G-vec00361-002-s317><challenge.stellen><en> accepted the challenge and combined the sketch with the colors.
<G-vec00361-002-s317><challenge.stellen><de> Ich habe mich der Herausforderung gestellt und Sketch mit Farbe kombiniert.
<G-vec00361-002-s318><challenge.stellen><en> We have accepted this challenge and over the last five years have developed an innovative sensor technology that allows complete-surface registration, recognition and processing of tactile and gestural information. This sensor technology can be formed according to individual requirements, integrated directly on an object, cover large surfaces and is durable, produces its own energy and reasonably priced.
<G-vec00361-002-s318><challenge.stellen><de> Wir haben uns dieser Herausforderung gestellt und in den letzten fünf Jahren eine innovative Sensor-Technologie entwickelt, welche die vollflächige Registrierung, Erkennung und Verarbeitung von taktilen und gestischen Informationen ermöglicht und beliebig formbar, direkt am Objekt integrierbar, großflächig, beständig, energieautark und zudem kostengünstig ist.
<G-vec00361-002-s319><challenge.stellen><en> Over 6,000 climbers, including numerous top athletes, have already risen to the challenge.
<G-vec00361-002-s319><challenge.stellen><de> Über 6.000 Kletterer weltweit, darunter auch zahlreiche Top-Athleten, haben sich der Herausforderung bereits gestellt.
<G-vec00361-002-s320><challenge.stellen><en> In view of the current crisis of confidence in the OSCE, the Swiss Chairmanship was faced with the challenge of making limited but nonetheless concrete progress in an environment marked by deadlock.
<G-vec00361-002-s320><challenge.stellen><de> Der Vorsitz war in Anbetracht der aktuellen Vertrauenskrise in der OSZE vor die Herausforderung gestellt, kleine, aber konkrete Fortschritte in einem von Blockaden geprägten Umfeld zu erreichen.
<G-vec00361-002-s321><challenge.stellen><en> The Swiss brand has taken on the challenge and invites you along to its stand for an Express Manicure.
<G-vec00361-002-s321><challenge.stellen><de> Die Schweizer Marke hat sich der Herausforderung gestellt und erwartet Sie an ihrem Stand zur Express-Maniküre.
<G-vec00361-002-s322><challenge.stellen><en> Nevertheless I met the challenge and after some night shifts the logo is ready now.
<G-vec00361-002-s322><challenge.stellen><de> Trotzdem habe ich mich der Herausforderung gestellt und nach diversen Nachtschichten ist es nun fertig.
<G-vec00391-002-s114><challenge.fordern><en> Challenge your friends, play against a random opponent, or try to beat Grabby.
<G-vec00391-002-s114><challenge.fordern><de> Fordern Sie Ihre Freunde, spielen Sie gegen einen zufälligen Gegner, oder versuchen, Grabby schlagen.
<G-vec00391-002-s115><challenge.fordern><en> Situatively, these skills are often used in combination and challenge students on an intellectual, communicative and emotional level.
<G-vec00391-002-s115><challenge.fordern><de> Situativ kommen diese Fähigkeiten oft kombiniert zur Anwendung und fordern Studierende sowohl auf intellektueller und kommunikativer als auch auf emotionaler Ebene.
<G-vec00391-002-s116><challenge.fordern><en> Challenge your brain and try to get the marble out of the dice.
<G-vec00391-002-s116><challenge.fordern><de> Fordern Sie Ihr Gehirn und holen Sie die Kugel aus dem Würfel.
<G-vec00391-002-s117><challenge.fordern><en> The German toy manufacturer has been accompanying children on all their forays for 80 years – with games and toys that challenge and encourage and above all are a lot of fun.
<G-vec00391-002-s117><challenge.fordern><de> Der deutsche Spielwarenhersteller HABA begleitet Kinder seit 80 Jahren auf all ihren Streifzügen – mit Spielen und Spielsachen, die fordern, fördern und vor allem viel Freude machen.
<G-vec00391-002-s118><challenge.fordern><en> Further increasing volatility of the markets and the increasing regulatory pressure on the financial industry will continue to challenge the finance department of the company.
<G-vec00391-002-s118><challenge.fordern><de> Die sich weiter erhöhende Volatilität der Märkte sowie der zunehmende regulatorische Druck auf die Finanzindustrie wird die Finanzabteilung der Unternehmen weiter fordern.
<G-vec00391-002-s119><challenge.fordern><en> Challenge yourself using bodyweight exercises and dumbells in this class knowing that the effects will last long after its over.
<G-vec00391-002-s119><challenge.fordern><de> Fordern Sie sich in der Tabata Klasse mit Verwendung von Körpergewichtsübungen und Gewichten selbst heraus und seien Sie sicher, dass der Effekt dieses Workouts noch lange nachdem es schon beendet ist immer noch anhalten wird.
<G-vec00391-002-s120><challenge.fordern><en> Pokémon Diamond and Pokémon Pearl challenge players to explore the Sinnoh region in an incredibly deep RPG adventure.
<G-vec00391-002-s120><challenge.fordern><de> Pokémon Diamant-Edition und Pokémon Perl-Edition fordern die Spieler dazu heraus, die Sinnoh-Region zu erkunden.
<G-vec00391-002-s121><challenge.fordern><en> Bigger online battles - Challenge your friends in 5 completely new and engaging multiplayer modes and take part in massive online battles.
<G-vec00391-002-s121><challenge.fordern><de> Größere Online-Schlachten - Fordern Sie Ihre Freunde in 5 völlig neuen und packenden Multiplayer-Modi heraus und beteiligen Sie sich an gewaltigen Online-Schlachten.
<G-vec00391-002-s122><challenge.fordern><en> Challenge the computer at expert level andreach the 50% winning rate.
<G-vec00391-002-s122><challenge.fordern><de> Fordern Sie den Computer auf Expertenebene andreach die 50% Gewinnrate.
<G-vec00391-002-s123><challenge.fordern><en> Customers challenge us and we always bring new ideas to enhance print pieces.
<G-vec00391-002-s123><challenge.fordern><de> Die Kunden fordern von uns, dass wir immer neue Ideen bringen, um die Drucksache aufzuwerten.
<G-vec00391-002-s124><challenge.fordern><en> NewWorlds, Info-Text: From beneath the Nine Halls of Throal and the Kingdoms Inner Cities come three tales of adventure and mystery to challenge even the bravest and most cunning heroes.
<G-vec00391-002-s124><challenge.fordern><de> Dieses Buch erzählt drei abenteuerliche, mysteriöse Geschichten aus den Tiefen unter den Neun Hallen von Throal und den Inneren Städten des Königreichs, die selbst tapfere und kluge Helden zu fordern wissen.
<G-vec00391-002-s125><challenge.fordern><en> Your own body weight and minibands are enough to challenge yourself.
<G-vec00391-002-s125><challenge.fordern><de> Das eigene Körpergewicht und die Minibands reichen aus, um sich selbst zu fordern.
<G-vec00391-002-s126><challenge.fordern><en> Challenge more than 20 computer opponents in three different tournaments.
<G-vec00391-002-s126><challenge.fordern><de> Fordern Sie mehr als 20 Computer-Gegner in drei verschiedenen Turnieren.
<G-vec00391-002-s127><challenge.fordern><en> Challenge your erudition and logic to decipher the infinite number of words available in the game.
<G-vec00391-002-s127><challenge.fordern><de> Fordern Sie Ihre Gelehrsamkeit und Logik heraus, um die unendliche Anzahl von Wörtern im Spiel zu entziffern.
<G-vec00391-002-s128><challenge.fordern><en> We challenge and develop our employees.
<G-vec00391-002-s128><challenge.fordern><de> Wir fordern und fördern unsere Mitarbeiter.
<G-vec00391-002-s129><challenge.fordern><en> They challenge students to reflect, think critically and get the best out of themselves.
<G-vec00391-002-s129><challenge.fordern><de> Sie fordern Schüler zum Nachdenken heraus, denken kritisch und nutzen das Beste aus sich heraus.
<G-vec00391-002-s130><challenge.fordern><en> Our favorite projects are the kinds that challenge us across the full spectrum of our services, from planning through manufacturing to assembly.
<G-vec00391-002-s130><challenge.fordern><de> Projekte, die die gesamte Leistungstiefe von der Planung über Herstellung und Montage fordern, sind uns am liebsten.
<G-vec00391-002-s131><challenge.fordern><en> The rough nature high on the mountain ridges and summits will challenge and but also reward you.
<G-vec00391-002-s131><challenge.fordern><de> Die raue Natur auf den Kämmen und Gipfeln der Berge wird Sie fordern aber auch belohnen.
<G-vec00391-002-s132><challenge.fordern><en> We challenge every employee worldwide to do the right thing and to lead by example.
<G-vec00391-002-s132><challenge.fordern><de> Wir fordern jeden unserer Mitarbeitenden weltweit auf, das Richtige zu tun und mit gutem Beispiel voran zu gehen.
<G-vec00391-002-s152><challenge.stellen><en> Ultimately, however, many of these likeminded countries were unwilling to seriously challenge the status quo.
<G-vec00391-002-s152><challenge.stellen><de> Letztlich waren jedoch viele dieser gleichgesinnten Länder nicht bereit, den Status quo ernsthaft in Frage zu stellen.
<G-vec00391-002-s153><challenge.stellen><en> Three months later, India, the world’s largest democracy, tightened up its rules to restrict funds to any groups that challenge the country’s ‘economic interests’.
<G-vec00391-002-s153><challenge.stellen><de> Drei Monate darauf verschärfte Indien, das bevölkerungsreichste demokratische Land der Welt, seine Regeln, um die Finanzierung von Gruppen zu erschweren, die die „wirtschaftlichen Interessen“ des Landes in Frage stellen.
<G-vec00391-002-s154><challenge.stellen><en> But this should not be the reason to challenge these undertakings.
<G-vec00391-002-s154><challenge.stellen><de> Aber das darf nicht der Grund sein, solche Unternehmungen in Frage zu stellen.
<G-vec00391-002-s155><challenge.stellen><en> A doctor's evaluation Doctors may suspect dissociative fugue when people seem confused about their identity or are puzzled about their past or when confrontations challenge their new identity or absence of one.
<G-vec00391-002-s155><challenge.stellen><de> Ein Arzt kann den Verdacht auf dissoziative Fugue hegen, wenn Menschen wegen ihrer Identität verwirrt zu sein scheinen, wenn ihre Vergangenheit sie verwirrt, oder wenn Konfrontationen ihre neue Identität oder deren Fehlen in Frage stellen.
<G-vec00391-002-s156><challenge.stellen><en> Numerous levels for you to challenge.
<G-vec00391-002-s156><challenge.stellen><de> Zahlreiche Levels für Sie in Frage zu stellen.
<G-vec00391-002-s157><challenge.stellen><en> Ambitious: Stimulate innovative thinking and challenge the status quo.
<G-vec00391-002-s157><challenge.stellen><de> Ehrgeizig: Innovatives Denken fördern, den Status Quo prüfen und in Frage stellen.
<G-vec00391-002-s158><challenge.stellen><en> The aim of this article is not to challenge, nor even to attempt to explain clearly the astonishing picture of the fundamental laws of nature revealed by modern physics.
<G-vec00391-002-s158><challenge.stellen><de> Das Ziel dieses Artikels besteht nicht darin, das erstaunliche durch die moderne Physik enthüllte Bild der grundsätzlichen Gesetze der Natur in Frage zu stellen, noch auch es deutlich zu erklären.
<G-vec00391-002-s159><challenge.stellen><en> To do so, we built our own home: a productive center located in our dear region, thought to allow people to work and think as openly and widely, as they possibly can; two Sales Departments, that constantly challenge themselves to provide the best service; a Contract Division, to create fully customized projects; a Technical and Style Section, to shape new concepts, to develop your total look Corners; a Marketing Department, to show the world that creativity is not confined to sold items.
<G-vec00391-002-s159><challenge.stellen><de> Hierfür bauten wir unser eigenes Zuhause: ein Produktionszentrum in unserer geliebten Region, in dem die Menschen so offen und weit wie möglich arbeiten und denken können sollten; zwei Verkaufsabteilungen, die sich ständig selbst in Frage stellen, um den besten Service zu bieten; die Abteilung Contract, in der vollständig maßgeschneiderte Projekte kreiert wurden; eine Abteilung für Technik und Stil, um neue Konzepte zu gestalten und Ihre Total Look Corners zu entwickeln; eine Marketing-Abteilung, um der Welt zu zeigen, dass Kreativität nicht nur auf verkaufte Artikel beschränkt ist.
<G-vec00391-002-s160><challenge.stellen><en> If the patent proprietor is the sole appellant against an interlocutory decision maintaining a patent in amended form, neither the board nor the non-appealing opponent as a party to the proceedings as of right may challenge the maintenance of the patent as amended in accordance with the interlocutory decision.
<G-vec00391-002-s160><challenge.stellen><de> Ist der Patentinhaber der alleinige Beschwerdeführer gegen eine Zwischenentscheidung über die Aufrechterhaltung des Patents in geändertem Umfang, so kann weder die Beschwerdekammer noch der nicht beschwerdeführende Einsprechende als Beteiligter die Fassung des Patents gemäß der Zwischenentscheidung in Frage stellen.
<G-vec00391-002-s161><challenge.stellen><en> You think you prefer beef, but this bison ribeye is ready to challenge that opinion.
<G-vec00391-002-s161><challenge.stellen><de> Sie denken, Sie bevorzugen Rindfleisch, aber dieses Bison Ribeye ist bereit, diese Meinung in Frage zu stellen.
<G-vec00391-002-s162><challenge.stellen><en> We Europeans must summon the courage to challenge traditional views.
<G-vec00391-002-s162><challenge.stellen><de> Wir Europäer müssen den Mut aufbringen, überkommene Sichtweisen in Frage zu stellen.
<G-vec00391-002-s163><challenge.stellen><en> INEOS Olefins & Polymers Europe North I certainly view INEOS as an entrepreneurial chemical company because of its willingness to challenge existing working practices and attitudes in society.
<G-vec00391-002-s163><challenge.stellen><de> Bei INEOS geht es um die Leidenschaft – und Ich betrachte INEOS ganz klar als unternehmerisches Chemieunternehmen, weil es bereit ist, bestehende Arbeitsweisen und gesellschaftliche Einstellungen in Frage zu stellen.
<G-vec00391-002-s164><challenge.stellen><en> Publishers shouldn’t be afraid to challenge the status quo.
<G-vec00391-002-s164><challenge.stellen><de> Als Verlag sollten Sie sich nicht scheuen, den Status Quo in Frage zu stellen.
<G-vec00391-002-s165><challenge.stellen><en> Analyzing both location and upgrading processes as well as the labor process the study is able to challenge this perspective.
<G-vec00391-002-s165><challenge.stellen><de> Durch die Integration sowohl von lokalen Charakteristika und Upgradingprozessen als auch vom Arbeitsprozess ist die Studie in der Lage diese Perspektive in Frage zu stellen.
<G-vec00391-002-s166><challenge.stellen><en> (c) They shall act with honesty, integrity and independence of mind to effectively assess and challenge the decisions of the senior management and to effectively oversee and monitor management decision-making.
<G-vec00391-002-s166><challenge.stellen><de> c) Sie handeln aufrichtig, integer und unvoreingenommen, um die Entscheidungen des leitenden Managements effektiv zu beurteilen und in Frage zu stellen und die Entscheidungsfindung der Geschäftsleitung wirksam zu beaufsichtigen und zu überwachen.
<G-vec00391-002-s167><challenge.stellen><en> In particular, care will be needed to exclude changes which increase the opportunity for politicians to influence the judicial leadership or challenge judicial independence or authority.
<G-vec00391-002-s167><challenge.stellen><de> Insbesondere wird darauf zu achten sein, dass keine Änderungen vorgenommen werden, die Politikern größere Möglichkeiten einer Einflussnahme auf die Verantwortlichen der Justiz eröffnen oder die Unabhängigkeit oder Autorität der Justiz in Frage stellen.
<G-vec00391-002-s168><challenge.stellen><en> Our culture embraces different perspectives, open debate and the will to challenge convention.
<G-vec00391-002-s168><challenge.stellen><de> Unsere Unternehmenskultur schätzt verschiedene Blickwinkel, offene Diskussionen und den Willen, Konventionen in Frage zu stellen.
<G-vec00391-002-s169><challenge.stellen><en> As far as I'm concerned, there will always be brands that constantly challenge the idea of what a man should wear.
<G-vec00391-002-s169><challenge.stellen><de> Wenn es nach mir geht, wird es immer Marken geben, die unentwegt die Vorstellung, was ein Mann zu tragen habe in Frage stellen.
<G-vec00391-002-s170><challenge.stellen><en> To put an end to this, we work with C&A Foundation to challenge deep-seated cultural and social norms and improve transparency within our supply chain.
<G-vec00391-002-s170><challenge.stellen><de> Um dies zu beenden, arbeiten wir mit der C&A Foundation zusammen, um tief verwurzelte kulturelle und soziale Normen in Frage zu stellen und die Transparenz innerhalb unserer Lieferkette zu verbessern.
