<G-vec00332-001-s093><alert.alarmieren><en> If a girl dreams, like her beloved turned into a huge black spider, such a dream should alert her.
<G-vec00332-001-s093><alert.alarmieren><de> Wenn ein Mädchen träumt, wie sie Geliebte verwandelte sich in eine riesige schwarze SpinneEin solcher Traum sollte sie alarmieren.
<G-vec00332-001-s094><alert.alarmieren><en> We don't know what the results of the exam because ’ to alert hospital staff is a woman's pregnancy.
<G-vec00332-001-s094><alert.alarmieren><de> Wir wissen nicht, was die Ergebnisse der Prüfung weil ’ zu alarmieren, Krankenhauspersonal ist eine Frau die Schwangerschaft.
<G-vec00332-001-s095><alert.alarmieren><en> The lists are seeded with trace names that will alert the publications of your re-use of the names.
<G-vec00332-001-s095><alert.alarmieren><de> Die Listen werden mit Spur Namen gesät, die die Publikationen Ihrer Wiederverwendung der Namen alarmieren.
<G-vec00332-001-s096><alert.alarmieren><en> Tumors or other breast diseases measures warmer than surrounding tissue and can thereby alert a physician to a problem before a tumor is actually palpable.Medical doctors who interpret the breast scans are board certified and endure an additional two years of training to qualify as a thermologist.
<G-vec00332-001-s096><alert.alarmieren><de> Tumoren oder andere Brustkrankheiten mißt Wärmer als umgebendes Gewebe und kann einen Arzt zu einem Problem dadurch alarmieren, bevor ein Tumor wirklich offensichtlich ist.Medizinische Doktoren, die die Brustscans sind das bestätigte Brett deuten und halten zusätzlichen zwei Jahre der Ausbildung aus, zum als thermologist zu qualifizieren.
<G-vec00332-001-s097><alert.alarmieren><en> A baby monitor attached to the crib (where baby can’t reach it) will alert you to any nighttime—including struggling if baby stops breathing.
<G-vec00332-001-s097><alert.alarmieren><de> Ein Babyphon am Kinderbett, dort wo es Ihr Kind nicht erreichen kann, wird Sie nachts alarmieren – zum Beispiel, wenn Ihr Kind aufhört zu atmen.
<G-vec00332-001-s098><alert.alarmieren><en> Try to reach and alert these people by telephone.
<G-vec00332-001-s098><alert.alarmieren><de> Versuchen Sie, diese Personen telefonisch zu erreichen und zu alarmieren.
<G-vec00332-001-s099><alert.alarmieren><en> What is more, if a motion sensor is triggered, the smart home can alert a security service and feed a video stream to the owner’s smartphone.
<G-vec00332-001-s099><alert.alarmieren><de> Mehr noch: Springt ein Bewegungsmelder an, kann das Smart Home einen Sicherheitsdienst alarmieren und eine Videoaufnahme auf das Smartphone des Hausbewohners übermitteln.
<G-vec00332-001-s100><alert.alarmieren><en> Alert a doctor in that case.
<G-vec00332-001-s100><alert.alarmieren><de> Alarmieren Sie einen Arzt in diesem Fall.
<G-vec00332-001-s101><alert.alarmieren><en> A complete site which has in particular the merit to alert against (many) the risks of handling and recovery by sects.
<G-vec00332-001-s101><alert.alarmieren><de> Ein vollständiger Standort, der insbesondere den Verdienst hat, gegen die (zahlreich) Handhabungs- und Wiedergewinnungsrisiken durch Sekten zu alarmieren.
<G-vec00332-001-s102><alert.alarmieren><en> The siren not only can scare away the intruder, but also alert you and your neighbor, also people that around.
<G-vec00332-001-s102><alert.alarmieren><de> Die Sirene kann nicht nur den Eindringling wegschrecken, sondern auch Sie und Ihren Nachbarn alarmieren, auch Menschen, die um.
<G-vec00332-001-s103><alert.alarmieren><en> It’s also an experienced doctor whose job is to monitor the health of your hard drive and alert you in case it detects any potential issues; it’s a cleaning lady for your hard drive who can spot all unused files and space hogs; it’s a bank with a highly secure vault where you can store all your most important documents and images.
<G-vec00332-001-s103><alert.alarmieren><de> Genauso ist es ein erfahrener Arzt, dessen Job es ist, die Gesundheit Ihrer Festplatte zu überwachen und Sie zu alarmieren, falls er mögliche Probleme entdeckt; es ist eine Putzfee für Ihre Festplatte, die alle ungenutzten Dateien und Speicherfresser erspähen kann; es ist eine Bank mit einem sehr sicheren Tresorraum, wo Sie all Ihre wichtigsten Dokumente und Bilder speichern können.
<G-vec00332-001-s104><alert.alarmieren><en> Tire pressure monitoring systems are designed to monitor the air pressure of tires and to alert the driver in case of pressure loss.
<G-vec00332-001-s104><alert.alarmieren><de> Systeme für die Reifendruckkontrolle überwachen den Reifendruck und alarmieren den Fahrer, wenn der tatsächliche Druck vom Sollwert abweicht.
<G-vec00332-001-s105><alert.alarmieren><en> The announcement of the Apocalypse is the last wake-up call to alert the world to the drastic changes that will soon occur; therefore, we must take this warning seriously.
<G-vec00332-001-s105><alert.alarmieren><de> Die Ankündigung der Apokalypse ist ein letzter Weckruf, um die Welt über ihren so nahe bevorstehenden drastischen Wandel zu alarmieren; umso ernster müssen wir diese Warnung nehmen.
<G-vec00332-001-s106><alert.alarmieren><en> To inform and Alert.
<G-vec00332-001-s106><alert.alarmieren><de> Benachrichtigen und Alarmieren.
<G-vec00332-001-s107><alert.alarmieren><en> A high-quality free mac spyware removal program will also be able to alert you every time an attempt to install spyware or adware on your mac is made.
<G-vec00332-001-s107><alert.alarmieren><de> Ein hochwertiges freies Mac spyware AbbauprogrammIST auch in der Lage, Sie zu alarmieren, jedesmal wenn ein Versuch, spyware oder adware auf Ihren Mac anzubringen gebildet wird.
<G-vec00332-001-s108><alert.alarmieren><en> """Well-used worry can alert us to areas in our lives that need attention and change."
<G-vec00332-001-s108><alert.alarmieren><de> """Gut-verwendete Sorge kann uns zu den Bereichen in unseren Leben alarmieren, die Aufmerksamkeit und benötigen, ändern."
<G-vec00332-001-s109><alert.alarmieren><en> A secure area allows the group to Sleep Safe, but Honking Geese or a motion detecting Tachometer can alert those who are sleeping.
<G-vec00332-001-s109><alert.alarmieren><de> Ein sicheres Areal erlaubt der Gruppe, Sicher Zu Schlafen, aber Hupende Gänse oder ein Bewegungentdeckendes Tachometer kann jene alarmieren, die gerade schlafen.
<G-vec00332-001-s110><alert.alarmieren><en> It will also alert you in case the SIM card has been changed.
<G-vec00332-001-s110><alert.alarmieren><de> Es wird Ihnen auch für den Fall, alarmieren die SIM-Karte gewechselt wurde.
<G-vec00332-001-s111><alert.alarmieren><en> We, in the higher regions, are trying our best to alert people to what is about to happen.
<G-vec00332-001-s111><alert.alarmieren><de> Wir, in den höheren Regionen, versuchen unser Bestes, die Menschen darüber zu alarmieren, was im Begriff ist zu geschehen.
<G-vec00332-001-s112><alert.alarmieren><en> It's a sort of... not anxiety, but above all a vigilance, as if they were on the alert: “May we do nothing but what You want, think nothing but what You want, feel nothing but what You want, say nothing but what You want....” Constantly, uninterruptedly, night and day.
<G-vec00332-001-s112><alert.alarmieren><de> "Es ist eine Art... nicht Besorgnis, aber vor allem eine Wachsamkeit, als ob sie alarmiert worden wären: ""Nur tun, was Du willst, nur denken, was Du willst, nur fühlen, was Du willst, nur sagen, was Du willst..."" So ist das ständig, ununterbrochen, Tag und Nacht."
<G-vec00332-001-s113><alert.alarmieren><en> But being on high alert is just not enough.
<G-vec00332-001-s113><alert.alarmieren><de> Aber alarmiert zu sein genügt nicht.
<G-vec00332-001-s114><alert.alarmieren><en> Guerilla forces should always stay alert, be mobile, move swiftly and maintain secrecy.
<G-vec00332-001-s114><alert.alarmieren><de> Guerillakräfte sollten immer alarmiert sein, mobil sein, sich schnell bewegen und die Geheimhaltung erhalten.
<G-vec00332-001-s115><alert.alarmieren><en> If a visitor collapses near the entrance, the reception staff immediately start primary care and alert the doctors and nursing staff in the house. They take care of all further treatment, so that consistent care of emergency patients up to the transfer to an intensive care unit or emergency medical services is guaranteed.
<G-vec00332-001-s115><alert.alarmieren><de> Kollabiert ein Besucher am Eingang, beginnt das Empfangspersonal unverzüglich mit der Basisversorgung, alarmiert hausintern Ärzte und Pflegepersonal, die dann die weitere Behandlung übernehmen, so dass eine lückenlose Versorgung von Notfallpatienten bis zur Übergabe an eine Intensivstation oder den Rettungsdienst gewährleistet ist.
<G-vec00332-001-s116><alert.alarmieren><en> You can set up an alert when the exact title of your post appears, by putting it in quotation marks.
<G-vec00332-001-s116><alert.alarmieren><de> Du kannst es so einstellen, dass Dich das Tool automatisch alarmiert, wenn die exakte Überschrift Deines Posts irgendwo erscheint, indem Du ihn in Anführungszeichen setzt.
<G-vec00332-001-s117><alert.alarmieren><en> What we could try to construct is a system which will at least alert if something dubious is happening and which can tell you in great detail what was happening when the machine crashed and which will allow you to save your work and then crash.
<G-vec00332-001-s117><alert.alarmieren><de> Wir können versuchen ein System zu konstruieren, dass zumindest alarmiert wenn etwas merkwürdiges passiert und das Ihnen im Detail zeigt was passierte als die Maschine abstürzte und das es Ihnen ermöglicht Ihre Arbeit zu speichern und dann abstürzt.
<G-vec00332-001-s118><alert.alarmieren><en> Price Levels Alert Indicator Download Price Levels Alert Indicator will alert when price reaches preset levels.
<G-vec00332-001-s118><alert.alarmieren><de> Preisstufen Alarm Indicator herunterladen Preisstufen Warnanzeige alarmiert, wenn der Kurs voreingestellten Werte erreicht.
<G-vec00332-001-s119><alert.alarmieren><en> Dr. Sonoiya, head of the health department at the EAC headquarters, Arusha, Tanzania, reports that the EAC is on high alert due to the current Ebola outbreaks in the DRC.
<G-vec00332-001-s119><alert.alarmieren><de> Dr. Sonoiya, Leiter der Gesundheitsreferats im Headquarter der Ostafrikanischen Union, berichtet, die Ostafrikanische Union sei durch die Ebola-Ausbrüche in der DRC höchst alarmiert.
<G-vec00332-001-s120><alert.alarmieren><en> This is an emergency code that will quickly alert air traffic controllers that you have an emergency.
<G-vec00332-001-s120><alert.alarmieren><de> Das ist ein Notfall Code, welcher sofort die Flugverkehrskontrolle alarmiert, dass ein Notfall besteht.
<G-vec00332-001-s121><alert.alarmieren><en> First I am asking what is the responsibility of the Nigeria government in its economic and political choices, in its delay to alert the international community because this famine could have been predicted.
<G-vec00332-001-s121><alert.alarmieren><de> Ich frage mich, ob ihre wirtschaftlichen und politischen Entscheidungen richtig sind und wieso sie die internationale Gemeinschaft so spät alarmiert, da ja die Hungersnot voraussehbar war.
<G-vec00332-001-s122><alert.alarmieren><en> Once our threat hunters have confirmed that an anomaly is an actual threat, they will alert you in less than 30 minutes.
<G-vec00332-001-s122><alert.alarmieren><de> Sobald unsere Threat Hunter bestätigen, dass eine Anomalie tatsächlich eine Bedrohung darstellt, werden Sie in weniger als 30 Minuten alarmiert.
<G-vec00332-001-s123><alert.alarmieren><en> Indeed Turkey’s scientists are on the alert.
<G-vec00332-001-s123><alert.alarmieren><de> Türkische Wissenschaftler sind allerdings alarmiert.
<G-vec00332-001-s124><alert.alarmieren><en> The White Rhinoceros Its sad disappearance has come at a time when everyone is alert to the risks of ecological extinction and its consequences for humanity and at a time when all the understanding and technology at our disposal could be channelled towards the protection of this species.
<G-vec00332-001-s124><alert.alarmieren><de> Rhinozerosse: Trauriges Verschwinden zu einem Zeitpunkt, an dem alle Gewissen durch die Risiken des Artensterbens und seiner Folgen für die Menschheit alarmiert sind, zu einem Zeitpunkt, an dem wir all unser Wissen und unsere Technologien in den Dienst des Schutzes unserer Arten stellen könnten, da stirbt das letzte männliche weiße Rhinozeros aus...
<G-vec00332-001-s209><alert.machen><en> In addition, psychologists say that most of these symptoms should alert the parents, particularly the disappearance of money from home and the constant fluctuations emotional background of the child.
<G-vec00332-001-s209><alert.machen><de> Darüber hinaus sagen Psychologen, dass die meisten dieser Symptome sollten die Eltern aufmerksam machen, vor allem das Verschwinden von Geld von zu Hause und die ständigen Schwankungen emotionalen Hintergrund des Kindes.
<G-vec00332-001-s210><alert.machen><en> Perhaps that will alert us to the fact that secession of the south is not the end, but is one of a series of splits intended to dismantle the Arab world surrounding Egypt.
<G-vec00332-001-s210><alert.machen><de> Vielleicht wird uns auf die Tatsache aufmerksam machen, dass die Sezession des Südens nicht das Ende ist, sondern ein Teil einer Serie von Abspaltungen, die zum Ziel haben, die Ägypten umgebende arabische Welt zu sprengen.
<G-vec00332-001-s211><alert.machen><en> Audible alerts - The PSP is equipped with a programmable alarm to alert parents and caregivers when battery power is low or if communication between the implant and processor has been disrupted
<G-vec00332-001-s211><alert.machen><de> Akustischer Alarm: der PSP verfügt über einen programmierbaren Alarm, um Eltern oder sonstige Pflegepersonen auf einen niedrigen Batterieladestatus oder eine Unterbrechung der Kommunikationsverbindung zwischen Implantat und Prozessor aufmerksam zu machen.
<G-vec00332-001-s212><alert.machen><en> He wanted to alert us to a great thing.
<G-vec00332-001-s212><alert.machen><de> Er wollte uns auf etwas wichtiges aufmerksam machen.
<G-vec00332-001-s213><alert.machen><en> I was whispering, barely audibly, trying to alert someone to the fact that I could not breathe.
<G-vec00332-001-s213><alert.machen><de> Ich flüsterte, kaum hörbar, versuchte jemand auf die Tatsache aufmerksam zu machen dass ich nicht atmen konnte.
<G-vec00332-001-s214><alert.machen><en> "Provision of ""awareness campaigns"" to alert the employees of ICM Capital of the risk of conflicts of interest."
<G-vec00332-001-s214><alert.machen><de> "Bereitstellung von ""Sensibilisierungskampagnen"", um die Mitarbeiter von ICM Capital auf das Risiko von Interessenkonflikten aufmerksam zu machen."
<G-vec00332-001-s215><alert.machen><en> The bracelet will alert you to the different stages and the irregularities of sleep.
<G-vec00332-001-s215><alert.machen><de> Das Armband wird Sie auf die verschiedenen Stadien und Unregelmäßigkeiten des Schlafes aufmerksam machen.
<G-vec00332-001-s216><alert.machen><en> Therefore, health care providers should alert their patients about these potential drug interactions.
<G-vec00332-001-s216><alert.machen><de> Daher sollten Anbieter von Gesundheitsleistungen ihre Patienten über diese mögliche Wechselwirkungen mit anderen Medikamenten aufmerksam machen.
<G-vec00332-001-s217><alert.machen><en> During that time, Liz and Missy attended the weekly classes where Missy learned to alert Liz to a variety of environmental sounds.
<G-vec00332-001-s217><alert.machen><de> Liz und Missy besuchten einmal die Woche den Kurs, wo Missy lernte, Liz auf verschiedene Umweltgeräusche aufmerksam zu machen.
<G-vec00332-001-s218><alert.machen><en> The intent of the exclamation point within an equilateral triangle is to alert the user to the presence of important safety, and operating and maintenance instructions in this manual.
<G-vec00332-001-s218><alert.machen><de> Das Ausrufezeichen in einem Dreieck soll den Benutzer auf das Vorhandensein wichtiger Sicherheits-, Betriebs- und Wartungsanleitungen in diesem Handbuch aufmerksam machen.
<G-vec00332-001-s219><alert.machen><en> Management personnel in particular should set a good example and alert employees to a safe mode of operation or stipulate safe footwear.
<G-vec00332-001-s219><alert.machen><de> Gerade das Führungspersonal sollte hier mit gutem Beispiel vorangehen und Mitarbeiter auf eine sichere Arbeitsweise aufmerksam machen oder beispielsweise sicheres Schuhwerk vorschreiben.
<G-vec00332-001-s220><alert.machen><en> We can only alert [people] about the situation and ask the German government for help.
<G-vec00332-001-s220><alert.machen><de> Wir können nur auf die Situation aufmerksam machen und die Bundesregierung um Hilfe bitten.
<G-vec00332-001-s221><alert.machen><en> PURPOSE OF USE The tactile surface warning stud with a design of hemispherical projections in a colour contrasting with the colour of the surrounding surface and functional arrangement of hemispherical projections on the ground, that are recognizable by legs and white stick and can be also detected visually, are designed to alert and inform blind and partially sighted people about danger, provide directional guidance (change of direction) and information.
<G-vec00332-001-s221><alert.machen><de> VERWENDUNGSZWECK Die taktile Boden-Aufmerksamkeitsnoppen Â aus Relief eines halbkugelförmigen Vorsprunges in Kontrastfarbe mit der Farbe der umgebenden Oberfläche und funktioneller Anordnung der halbkreisförmiger Vorsprunge auf dem Boden, die durch die Beine oder mit dem Blindenstock erkennbar sind und können auch visuell registriert werden, sind so entworfen, um die Blinde und Sehbehinderte auf bevorstehende Gefahr aufmerksam zu machen und fÃ1⁄4r Richtungsinformationen und Richtungsanweisungen (Richtungswechsel) zu sorgen.
<G-vec00332-001-s222><alert.machen><en> A morning cup of coffee or strong tea can transform us from dreary and exhausted to energized and alert. Related Topics (Ads):
<G-vec00332-001-s222><alert.machen><de> Eine morgendliche Tasse Kaffee oder ein starker Tee kann uns die Müdigkeit und Erschöpfung nehmen und uns energiegeladen und aufmerksam machen.
<G-vec00332-001-s223><alert.machen><en> He is able to alert the police to the situation at hand, but unfortunately the L. A. police force as well as the FBI consists of idiots who misinterpret the situation completely and refuse to listen to McClane.
<G-vec00332-001-s223><alert.machen><de> Es gelingt ihm zwar, die Polizei auf die Situation aufmerksam zu machen, aber leider sind das mit einer Ausnahme alles Idioten, die nicht auf McClane hören und die Situation völlig falsch einschätzen.
<G-vec00332-001-s224><alert.machen><en> In the case of the Transitions Hub, we may use your personal information to alert you to new images or products that are available, updates or new services.
<G-vec00332-001-s224><alert.machen><de> Auf dem Transitions Hub nutzen wir unter Umständen Ihre personenbezogenen Informationen, um Sie auf neue Bilder und Produkte, Aktualisierungen oder neue Dienste aufmerksam zu machen.
<G-vec00332-001-s225><alert.machen><en> Stand-alone operation: as soon as smoke is detected, the detector will alert people in the vicinity to danger, acoustically and optically.
<G-vec00332-001-s225><alert.machen><de> Stand-Alone-Betrieb: Sobald der Rauch erkannt wird, wird der Detektor die Menschen in der Nähe auf Gefahren, akustisch und optisch aufmerksam machen.
<G-vec00332-001-s226><alert.machen><en> At the same time, Wanzl designed a new walkway for customers using stopper elements that alert customers to particular product offers.
<G-vec00332-001-s226><alert.machen><de> Gleichzeitig konzipierte Wanzl einen neuen Laufweg für die Kunden durch Stopper-Elemente, die auf besondere Produktangebote aufmerksam machen.
<G-vec00332-001-s227><alert.machen><en> The innovative Halo light will also alert you to the presence of a visitor when the doorbell can’t be heard.
<G-vec00332-001-s227><alert.machen><de> Der innovative HALO-Lichtring wird Sie auf die Ankunft eines Besuchers aufmerksam machen, wenn der Türgong nicht zu hören ist.
<G-vec00332-001-s251><alert.benachrichtigen><en> It then uses that information to detect or even predict conditions that could lead to process or equipment problems, and alert you so you can take action before the process is affected.
<G-vec00332-001-s251><alert.benachrichtigen><de> Diese Informationen werden dann verwendet, um Zustände zu erkennen oder sogar vorherzusagen, die zu Prozess- oder Ausrüstungsproblemen führen können, und um Sie zu benachrichtigen, damit Sie entsprechende Maßnahmen ergreifen können, bevor der Prozess beeinträchtigt wird.
<G-vec00332-001-s252><alert.benachrichtigen><en> You can use the included Virtualization Pack to discover and monitor Windows Server Hyper-V VMs and alert VM administrators of potential storage issues.
<G-vec00332-001-s252><alert.benachrichtigen><de> Sie können das im Lieferumfang enthaltene Virtualization Pack verwenden, um Windows Server Hyper-V VMs zu ermitteln und zu überwachen und VM-Administratoren über mögliche Storage-Probleme zu benachrichtigen.
<G-vec00332-001-s253><alert.benachrichtigen><en> If you don't feel comfortable reaching out to the person on your own or aren't sure how to reach them, you can also alert Twitter .
<G-vec00332-001-s253><alert.benachrichtigen><de> Wenn es dir unangenehm ist, selbst mit der Person Kontakt aufzunehmen, oder du nicht weißt, wie du sie erreichen sollst, kannst du auch Twitter benachrichtigen .
<G-vec00332-001-s254><alert.benachrichtigen><en> However, tripwolf reserves the right to send e-mail to Members at all times, regardless of their Account Settings, to alert them of material changes to their Membership.
<G-vec00332-001-s254><alert.benachrichtigen><de> Dennoch behält sich tripwolf das Recht vor, Mitgliedern jederzeit und unabhängig von ihren Account-Einstellungen E-Mails zuzusenden, um sie über Änderungen zu benachrichtigen, die ihre Mitgliedschaft betreffen.
<G-vec00332-001-s255><alert.benachrichtigen><en> To enhance the application, they added statistical process control (SPC) capabilities that alert operators to sensor values that are outside normal operating ranges.
<G-vec00332-001-s255><alert.benachrichtigen><de> Um die Anwendung zu erweitern, wurden Funktionen der statistischen Prozesskontrolle (SPC) hinzugefügt, die Mitarbeiter benachrichtigen, wenn Sensorwerte außerhalb der normalen Betriebsbereiche liegen.
<G-vec00332-001-s256><alert.benachrichtigen><en> Another powerful feature of this product is the ability to hide columns in Alert Me so that emails can be sent without worrying about the risk of exposing sensitive data.
<G-vec00332-001-s256><alert.benachrichtigen><de> Eine weitere leistungsstarke Funktion dieses Produkts ist die Möglichkeit, Spalten in Benachrichtigen auszublenden, so dass E-Mails versendet werden können, ohne dass man sich Gedanken über das Risiko sensible Daten offenzulegen, machen muss.
<G-vec00332-001-s257><alert.benachrichtigen><en> Kuri can even alert you when your children arrive home from school while you are still stuck in traffic.
<G-vec00332-001-s257><alert.benachrichtigen><de> Kuri kann Sie sogar benachrichtigen, wenn Ihre Kinder aus der Schule kommen, während Sie noch im Verkehrsstau stecken.
<G-vec00332-001-s258><alert.benachrichtigen><en> We alert you of any new aliases or addresses linked to your SSN, enabling you to prevent a variety of fraud.
<G-vec00332-001-s258><alert.benachrichtigen><de> Wir benachrichtigen Sie, falls neue Alias oder Adressen mit Ihrer Sozialversicherungsnummer verknüpft werden, sodass Sie eine Vielzahl von Betrugsmaschen verhindern können.
<G-vec00332-001-s259><alert.benachrichtigen><en> If traveling, alert your IT department beforehand, especially if you're going to be using public wireless Internet.
<G-vec00332-001-s259><alert.benachrichtigen><de> Wenn Sie geschäftlich verreisen, benachrichtigen Sie vorher Ihre IT-Abteilung, besonders wenn Sie vorhaben, öffentliches WLAN zu nutzen.
<G-vec00332-001-s260><alert.benachrichtigen><en> Proactively alert managers when attention is needed.
<G-vec00332-001-s260><alert.benachrichtigen><de> Benachrichtigen Sie Manager proaktiv, wenn ihre Aufmerksamkeit gefordert ist.
<G-vec00332-001-s261><alert.benachrichtigen><en> The information you provide is used only to alert you in the event that you win one of our contests. Buying games
<G-vec00332-001-s261><alert.benachrichtigen><de> Die von dir zur Verfügung gestellten Informationen werden nur verwendet, um dich zu benachrichtigen, falls du einen unserer Wettbewerbe gewinnen solltest.
<G-vec00332-001-s262><alert.benachrichtigen><en> If you learn that your child has provided us with Personal Data without your consent, you may alert us by contacting us as described below.
<G-vec00332-001-s262><alert.benachrichtigen><de> Wenn Sie Kenntnis davon erlangen, dass uns Ihr Kind ohne Ihr Einverständnis personenbezogene Daten zur Verfügung gestellt hat, können Sie uns darüber benachrichtigen, indem Sie wie weiter unten beschrieben Kontakt mit uns aufnehmen.
<G-vec00332-001-s263><alert.benachrichtigen><en> If you wish to withdraw your consent to ONTEX' use of cookies on this Website, or if you wish to delete or control the placing of cookies on your computer, you can change your browser settings to block cookies or to alert you when cookies are being sent to your device.
<G-vec00332-001-s263><alert.benachrichtigen><de> Wenn Sie Ihre Zustimmung zur Verwendung von Cookies durch ONTEX auf dieser Website widerrufen möchten oder wenn Sie die Platzierung von Cookies auf Ihrem Computer löschen oder kontrollieren möchten, können Sie Ihre Browsereinstellungen ändern, um Cookies zu unterbinden oder um Sie zu benachrichtigen, sobald Cookies an Ihr Gerät gesendet werden.
<G-vec00332-001-s264><alert.benachrichtigen><en> Have someone check your home regularly and alert you if anything important arrives in the mail.
<G-vec00332-001-s264><alert.benachrichtigen><de> Lass jemanden regelmäßig dein Zuhause überprüfen und dich benachrichtigen, wenn etwas wichtiges per Post eintrifft.
<G-vec00332-001-s265><alert.benachrichtigen><en> However, ZAINOO reserves the right to send e-mail to Members at all times, regardless of their Account Settings, to alert them of material changes to their Membership.
<G-vec00332-001-s265><alert.benachrichtigen><de> Dennoch behält sich ZAINOO das Recht vor, Mitgliedern jederzeit und unabhängig von ihren Account-Einstellungen E-Mails zuzusenden, um sie über Änderungen zu benachrichtigen, die ihre Mitgliedschaft betreffen.
<G-vec00332-001-s266><alert.benachrichtigen><en> Right to Repair - You have the right to alert us if any of your personal data is incorrect, if you changed your name or if you moved and we are obliged to correct the incorrect data.
<G-vec00332-001-s266><alert.benachrichtigen><de> Recht auf Reparatur - Sie haben das Recht, uns zu benachrichtigen, wenn Ihre persönlichen Daten falsch sind, Wenn Sie Ihren Namen geändert haben oder wenn Sie umgezogen sind, müssen wir die falschen Daten korrigieren.
<G-vec00332-001-s267><alert.benachrichtigen><en> Depending on the system you choose, CCTV can alert you when any of your perimeter is breached.
<G-vec00332-001-s267><alert.benachrichtigen><de> Abhängig vom gewählten System kann Ihre CCTV-Vorrichtung Sie benachrichtigen, wenn die Grundstücksgrenze an irgendeiner Stelle verletzt wird.
<G-vec00332-001-s268><alert.benachrichtigen><en> Â K Keyword Keywords alert you to conversations in channels you've joined about topics that interest you.
<G-vec00332-001-s268><alert.benachrichtigen><de> Keyword Keywords benachrichtigen dich über Unterhaltungen zu Themen, die dich interessieren und die in Channels stattfinden, denen du beigetreten bist.
<G-vec00332-001-s269><alert.benachrichtigen><en> The information you provide is used only to alert you in the event that you win one of our contests.
<G-vec00332-001-s269><alert.benachrichtigen><de> Die von dir zur Verfügung gestellten Informationen werden nur verwendet, um dich zu benachrichtigen, falls du einen unserer Wettbewerbe gewinnen solltest.
<G-vec00332-001-s270><alert.benachrichtigen><en> If you do not wish to receive cookies, you may set your browser to refuse all or some types of cookies, or to alert you when cookies are being sent by website tracking technologies and advertising.
<G-vec00332-001-s270><alert.benachrichtigen><de> Wenn Sie keine Cookies erhalten möchten, können Sie Ihren Browser so einstellen, dass er alle oder einige Arten von Cookies ablehnt oder Sie benachrichtigt, wenn Cookies durch Website-Tracking-Technologien und Werbung gesendet werden.
<G-vec00332-001-s271><alert.benachrichtigen><en> If you use Group Policy to disable Windows Firewall, or configure Windows Firewall with a rule that allows all inbound network traffic, then Windows Security Center will alert the user that there are security issues that the user should correct.
<G-vec00332-001-s271><alert.benachrichtigen><de> Wenn Sie die Windows-Firewall mithilfe einer Gruppenrichtlinie deaktivieren oder für die Windows-Firewall eine Regel konfigurieren, die den gesamten eingehenden Netzwerkverkehr zulässt, wird der Benutzer vom Windows-Sicherheitscenter benachrichtigt, dass Sicherheitsprobleme aufgetreten sind, die der Benutzer beheben sollte.
<G-vec00332-001-s272><alert.benachrichtigen><en> You can set your browser to refuse all or some browser cookies, or to alert you when websites set or access cookies.
<G-vec00332-001-s272><alert.benachrichtigen><de> Sie können Ihren Browser so einstellen, dass er alle oder einige Browser-Cookies ablehnt oder Sie benachrichtigt, wenn Websites Cookies setzen oder darauf zugreifen.
<G-vec00332-001-s273><alert.benachrichtigen><en> You can configure your browser to accept all or certain cookies or to alert you when a cookie is offered by a website's server.
<G-vec00332-001-s273><alert.benachrichtigen><de> Sie können Ihren Browser so konfigurieren, dass er alle oder bestimmte Cookies akzeptiert oder Sie benachrichtigt, wenn ein Cookie vom Server einer Website angeboten wird.
<G-vec00332-001-s274><alert.benachrichtigen><en> Players will receive updates via emails and in their software to alert them of any bonus reward opportunities.
<G-vec00332-001-s274><alert.benachrichtigen><de> Spieler erhalten per E-Mail sowie über iIhre Software Updates und werden über alle Bonus-Möglichkeiten benachrichtigt.
<G-vec00332-001-s275><alert.benachrichtigen><en> Whenever SG Site Scanner detects an issue with your website, it will alert you immediately so you can take action.
<G-vec00332-001-s275><alert.benachrichtigen><de> Wenn der SG Site Scanner ein Problem auf Deiner Webseite entdeckt, wirst Du sofort benachrichtigt, um geeignete Maßnahmen ergreifen zu können.
<G-vec00332-001-s276><alert.benachrichtigen><en> Event Log – can be configured to alert IT administrator when specific information is discovered in an event log
<G-vec00332-001-s276><alert.benachrichtigen><de> Ereignisprotokoll – lässt sich so konfigurieren, dass der Administrator automatisch benachrichtigt wird, wenn bestimmte Informationen in einem Ereignisprotokoll enthalten sind.
<G-vec00332-001-s277><alert.benachrichtigen><en> You can set your browser to alert you when a cookie is being used, and accept or reject the cookie.
<G-vec00332-001-s277><alert.benachrichtigen><de> Sie können Ihren Browser so einstellen, dass er Sie benachrichtigt, wenn ein Cookie genutzt wird und dann den Cookie akzeptieren oder ablehnen.
<G-vec00332-001-s278><alert.benachrichtigen><en> You can use it to track updated sites, and to alert you when an important server goes down or recovers.
<G-vec00332-001-s278><alert.benachrichtigen><de> Benutzen Sie Simon, um zu beobachten, ob Websites aktualisiert werden oder um sofort benachrichtigt zu werden, wenn ein wichtiger Server ausfällt oder einen Neustart macht.
<G-vec00332-001-s279><alert.benachrichtigen><en> On the date a new version of a product becomes available, you will receive an alert that you are entitled to the new version of your current product.
<G-vec00332-001-s279><alert.benachrichtigen><de> Verfügbarkeitsdatum der neuen Produktversion Sobald eine neue Version eines Produkts verfügbar ist, werden Sie benachrichtigt, dass Sie auf die neue Version aktualisieren können.
<G-vec00332-001-s280><alert.benachrichtigen><en> - ask for a stock alert when there's only one piece in your size left.
<G-vec00332-001-s280><alert.benachrichtigen><de> - werden Sie benachrichtigt, wenn nur noch ein Artikel in Ihrer Größe verfügbar ist.
<G-vec00332-001-s281><alert.benachrichtigen><en> Tick this box, and the software will alert you when it is your turn to enter the game.
<G-vec00332-001-s281><alert.benachrichtigen><de> Du wirst dann von der Software benachrichtigt, wenn du an der Reihe bist, in das Spiel einzusteigen.
<G-vec00332-001-s282><alert.benachrichtigen><en> However, Indeed may alert you when any of the above events occur.
<G-vec00332-001-s282><alert.benachrichtigen><de> Sie können von Indeed jedoch benachrichtigt werden, wenn eines der vorstehend aufgeführten Ereignisse eintritt.
<G-vec00332-001-s302><alert.geben><en> Register for an alert when tickets are available for John Legend Manchester.
<G-vec00332-001-s302><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s303><alert.geben><en> Register for an alert when tickets are available to buy for Beyonce Barcelona.
<G-vec00332-001-s303><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s304><alert.geben><en> Register for an alert when tickets are available to buy for Eros Ramazzotti.
<G-vec00332-001-s304><alert.geben><de> Wir sagen Ihnen bescheid, wenn die Karten von Eros Ramazzotti verfügbar sind.
<G-vec00332-001-s305><alert.geben><en> Register for an alert when tickets are available to buy for The Cure Stuttgart.
<G-vec00332-001-s305><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s306><alert.geben><en> Register for an alert when tickets are available for Valencia CF - Sevilla FC.
<G-vec00332-001-s306><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s307><alert.geben><en> Register for an alert when tickets are available to buy for Beyonce Zürich.
<G-vec00332-001-s307><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s308><alert.geben><en> Register for an alert when tickets are available to buy for Stoke City - Manchester City FC.
<G-vec00332-001-s308><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s309><alert.geben><en> Register for an alert when tickets are available to buy for James Morrison Bournemouth.
<G-vec00332-001-s309><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s310><alert.geben><en> Register for an alert when tickets are available for New York Knicks vs. Chicago Bulls.
<G-vec00332-001-s310><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s311><alert.geben><en> Your toothbrush tracks how long and hard you've brushed with each brush head, and will alert you when it's time to replace.
<G-vec00332-001-s311><alert.geben><de> Ihre Zahnbürste zeichnet auf, wie lange und mit wie viel Druck Sie mit jedem Bürstenkopf geputzt haben, und gibt Ihnen Bescheid, wenn der Bürstenkopf ausgetauscht werden sollte.
<G-vec00332-001-s312><alert.geben><en> Register for an alert when tickets are available to buy for Justin Bieber Köln.
<G-vec00332-001-s312><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s313><alert.geben><en> Register for an alert when tickets are available to buy for AS Chievo Verona.
<G-vec00332-001-s313><alert.geben><de> Wir sagen Ihnen bescheid, wenn die Karten von AS Chievo Verona verfügbar sind.
<G-vec00332-001-s314><alert.geben><en> Register for an alert when tickets are available to buy for Bryan Adams München.
<G-vec00332-001-s314><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s315><alert.geben><en> Register for an alert when tickets are available to buy for Rock In Rio.
<G-vec00332-001-s315><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s316><alert.geben><en> Register for an alert when tickets are available to buy for The Cure Madrid.
<G-vec00332-001-s316><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s317><alert.geben><en> Register for an alert when tickets are available to buy for Celta - RCD de la Coruña.
<G-vec00332-001-s317><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s318><alert.geben><en> Register for an alert when tickets are available to buy for Starlite Festival.
<G-vec00332-001-s318><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s319><alert.geben><en> Register for an alert when tickets are available to buy for HIM Manchester.
<G-vec00332-001-s319><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s320><alert.geben><en> Register for an alert when tickets are available to buy for Justin Bieber Barcelona.
<G-vec00332-001-s320><alert.geben><de> Tragen Sie sich ein, um bescheid zu bekommen, wann ihnen Tickets zur Verfügung stehen.
<G-vec00332-001-s330><alert.hinweisen><en> MyKronoz ZeSport2 Samsung Galaxy Watch If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s330><alert.hinweisen><de> MyKronoz ZeSport2 Samsung Galaxy Watch Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s331><alert.hinweisen><en> Suunto Spartan Sport Wrist HR If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s331><alert.hinweisen><de> Suunto Spartan Sport Wrist HR Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s332><alert.hinweisen><en> In order to watch an video on our website, a message will alert you that you need to accept YouTube cookies to do so.
<G-vec00332-001-s332><alert.hinweisen><de> Um ein Video auf unserer Website anzusehen, werden Sie in einer Nachricht darauf hingewiesen, dass Sie YouTube-Cookies akzeptieren müssen, um dies zu tun.
<G-vec00332-001-s333><alert.hinweisen><en> Fitbit Charge 3 Garmin Vivomove HR If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s333><alert.hinweisen><de> Fitbit Charge 3 Garmin Vivomove HR Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s334><alert.hinweisen><en> Polar M430 If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s334><alert.hinweisen><de> Polar M430 Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s335><alert.hinweisen><en> Fitbit Blaze If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s335><alert.hinweisen><de> Fitbit Blaze Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s336><alert.hinweisen><en> Has notifications Coros Pace If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s336><alert.hinweisen><de> Coros Pace Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s337><alert.hinweisen><en> Mobvoi TicWatch Pro Polar Vantage V (medium / large) If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s337><alert.hinweisen><de> Mobvoi TicWatch Pro Polar Vantage V (medium / large) Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s338><alert.hinweisen><en> Apple Watch Series 3 Huawei Watch 2 Classic If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s338><alert.hinweisen><de> Apple Watch Series 3 Huawei Watch 2 Classic Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s339><alert.hinweisen><en> Apple Watch Series 3 Samsung Galaxy Watch If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s339><alert.hinweisen><de> Apple Watch Series 3 Samsung Galaxy Watch Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s340><alert.hinweisen><en> LG Watch W7 If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s340><alert.hinweisen><de> LG Watch W7 Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s341><alert.hinweisen><en> Huawei Watch GT Polar Vantage V (medium / large) If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s341><alert.hinweisen><de> Polar Vantage V (medium / large) Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s342><alert.hinweisen><en> Polar Vantage V (medium / large) If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s342><alert.hinweisen><de> Polar Vantage V (medium / large) Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s343><alert.hinweisen><en> Huawei Watch GT Samsung Gear Sport If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s343><alert.hinweisen><de> Samsung Gear Sport Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s344><alert.hinweisen><en> Garmin Vivoactive 3 Samsung Galaxy Watch If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s344><alert.hinweisen><de> Garmin Vivoactive 3 Samsung Galaxy Watch Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s345><alert.hinweisen><en> Garmin Forerunner 235 Garmin Forerunner 645 Music If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s345><alert.hinweisen><de> Garmin Forerunner 235 Garmin Forerunner 645 Music Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s346><alert.hinweisen><en> Huawei Watch GT Mobvoi TicWatch Pro If you get a notification such as a call or message, the device will vibrate on your wrist or make a noise to alert you.
<G-vec00332-001-s346><alert.hinweisen><de> Mobvoi TicWatch Pro Wenn Du eine Benachrichtigung, wie zum Beispiel einen Anruf oder eine Nachricht erhälst, wirst Du vom Gerät, mit einer Vibration am Handgelenk oder einem Geräusch, darauf hingewiesen.
<G-vec00332-001-s393><alert.informieren><en> If we find new offers or listing price updates in category Flats For Sale, Canna you will receive an email alert.
<G-vec00332-001-s393><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zu vermieten, Westerwaldkreis erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s394><alert.informieren><en> If we find new offers or listing price updates in category Flats For Sale, Crevichon you will receive an email alert.
<G-vec00332-001-s394><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zum Verkauf, Landkreis Osterholz erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s395><alert.informieren><en> If we find new offers or listing price updates in category Flats For Rent, Guernsey you will receive an email alert.
<G-vec00332-001-s395><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Häuser zum Verkauf, Landkreis Ludwigslust-Parchim erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s396><alert.informieren><en> If we find new offers or listing price updates in category Houses For Rent, Fish Holm you will receive an email alert.
<G-vec00332-001-s396><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Grundstück zum Verkauf, Frankenthal (Pfalz) erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s397><alert.informieren><en> If we find new offers or listing price updates in category Houses For Rent, Cardiff you will receive an email alert.
<G-vec00332-001-s397><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Grundstück zum Verkauf, Kreis Segeberg erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s398><alert.informieren><en> If we find new offers or listing price updates in category Flats For Rent, West Lothian you will receive an email alert.
<G-vec00332-001-s398><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zu vermieten, Landkreis Verden erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s399><alert.informieren><en> If we find new offers or listing price updates in category Flats For Rent, Flintshire you will receive an email alert.
<G-vec00332-001-s399><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zum Verkauf, Landkreis Bautzen erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s400><alert.informieren><en> The software will alert you when it is your turn to place a bet (so you cannot place a bet out of turn).
<G-vec00332-001-s400><alert.informieren><de> Das Programm wird Sie informieren, wenn Sie an der Reihe zu wetten (damit Sie nicht werfen Sie Ihre Wette nicht in Ordnung) ist.
<G-vec00332-001-s401><alert.informieren><en> If we find new offers or listing price updates in category Flats For Sale, Pabay you will receive an email alert.
<G-vec00332-001-s401><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Grundstück zu vermieten, Landkreis Neunkirchen erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s402><alert.informieren><en> If we find new offers or listing price updates in category Land For Sale, Garff you will receive an email alert.
<G-vec00332-001-s402><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zum Verkauf, Landkreis Harz erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s403><alert.informieren><en> If we find new offers or listing price updates in category Flats For Sale, London Borough of Merton you will receive an email alert.
<G-vec00332-001-s403><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zu vermieten, Landkreis Hildburghausen erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s404><alert.informieren><en> If we find new offers or listing price updates in category Houses For Rent, Bridgend you will receive an email alert.
<G-vec00332-001-s404><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zum Verkauf, Landkreis Lüneburg erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s405><alert.informieren><en> If we find new offers or listing price updates in category Land For Sale, Neath Port Talbot you will receive an email alert.
<G-vec00332-001-s405><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Grundstück zum Verkauf, Kreis Stormarn erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s406><alert.informieren><en> If we find new offers or listing price updates in category Flats For Sale, Rusk Holm you will receive an email alert.
<G-vec00332-001-s406><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zum Verkauf, Kaiserslautern erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s407><alert.informieren><en> If we find new offers or listing price updates in category Houses For Sale, Midlothian you will receive an email alert.
<G-vec00332-001-s407><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Grundstück zu vermieten, Regierungsbezirk Düsseldorf erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s408><alert.informieren><en> We’ll alert you to any adjustments as quickly as we can. Look for information in our stations, on sncf.com and on your mobile via the SNCF direct app.
<G-vec00332-001-s408><alert.informieren><de> Wir informieren Sie darüber, sobald dies möglich ist, in den Bahnhöfen, auf den Websites sncf.com und infolignes.com sowie auf Ihrem Smartphone mit der App SNCF Direct.
<G-vec00332-001-s409><alert.informieren><en> If we find new offers or listing price updates in category Flats For Sale, The Heag you will receive an email alert.
<G-vec00332-001-s409><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Wohnungen zu vermieten, Landkreis Oberhavel erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s410><alert.informieren><en> If we find new offers or listing price updates in category Houses For Rent, Pembrokeshire you will receive an email alert.
<G-vec00332-001-s410><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Häuser zu vermieten, Landkreis Börde erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s411><alert.informieren><en> If we find new offers or listing price updates in category Houses For Sale, Trondra you will receive an email alert.
<G-vec00332-001-s411><alert.informieren><de> Falls wir ein neues Angebot oder eine Preisveränderung des bestehenden Angebots Häuser zum Verkauf, Landkreis Bad Dürkheim erhalten, werden wir Sie per E-Mail informieren.
<G-vec00332-001-s412><alert.machen><en> In combination with PDLS Plus, the marker light function briefly flashes the headlight at the pedestrian on the kerbside or in the carriageway three times to alert the driver's attention.
<G-vec00332-001-s412><alert.machen><de> In Kombination mit PDLS Plus blinkt der Scheinwerfer am Fahrbahnrand oder auf der Fahrbahn befindliche Fußgänger durch eine Markierungslichtfunktion sogar drei Mal kurz an, um den Fahrer gezielt auf sie aufmerksam zu machen.
<G-vec00332-001-s413><alert.machen><en> "Frequent footnotes throughout these volumes alert the reader to mistranslations, missing documents, and falsified copies (for example, XX 205 of the German volumes: ""This phrase does not appear in the original document."")."
<G-vec00332-001-s413><alert.machen><de> "Häufige Fußnoten überall in diesen Bänden machen den Leser auf Fehlübersetzungen, fehlende Dokumente und gefälschte Kopien aufmerksam (z.B., XX 205 auf deutsch: ""Dieser Satz ist in dem Originaldokument nicht enthalten"")."
<G-vec00332-001-s414><alert.machen><en> "Campaigns like 'Inglorious Fruits and Vegetables' (Intermarché, France) and 'Wonky Veg' boxes (Asda, UK) try to change the ""beauty"" perception. Price promotions for foods that are slightly damaged or nearing their expiry date also help reduce food waste.5 Innovative apps such as 'No Food Wasted' in the Netherlands, 'Food Loop' in Germany and 'Too Good to Go' in the UK, are connecting customers with supermarkets and restaurants to alert them to deals or surplus food available for collection."
<G-vec00332-001-s414><alert.machen><de> "Preisnachlässe für Lebensmittel, die leicht beschädigt oder kurz vor dem Verfallsdatum sind, tragen ebenfalls dazu bei, Lebensmittelverschwendung zu reduzieren.5 Innovative Apps wie 'No Food Wasted' (etwa: ""Kein Lebensmittel wird verschwendet"") in den Niederlanden 'Food Loop' in Deutschland und 'Too Good to Go' (etwa: ""zu gut zum Wegwerfen"") in Großbritannien bringen Kunden mit Supermärkten und Restaurants zusammen, und machen sie aufmerksam auf aktuelle Angebote und überschüssige Lebensmittel, die abgegeben werden können."
<G-vec00332-001-s415><alert.machen><en> 10.9. Governments at the appropriate level, in collaboration with national institutions and interest groups and with the support of regional and international organizations, should launch awareness-raising campaigns to alert and educate people on the importance of integrated land and land resources management and the role that individuals and social groups can play in it.
<G-vec00332-001-s415><alert.machen><de> 10.9 Die Regierungen sollen auf der entsprechenden Ebene in Zusammenarbeit mit nationalen Institutionen und Interessengruppen und mit Unterstützung regionaler und internationaler Organisationen bewußtseinsbildende Maßnahmen durchführen, um der Bevölkerung die Bedeutung einer integrierten Flächen- und Bodenressourcenbewirtschaftung und die dem Einzelnen und den gesellschaftlichen Gruppen dabei zufallende Rolle vor Augen zu führen und verständlich zu machen.
<G-vec00332-001-s416><alert.machen><en> Besides the using the reserach tools it is possible to create search profiles and to set up a search alert (RSS-Feed is available).
<G-vec00332-001-s416><alert.machen><de> Neben umfangreichen Rechercheoptionen besteht die Möglichkeit, sich eigene Suchprofile zusammenzustellen und von einem Alert-Dienst Gebrauch zu machen (auch als RSS-Feed möglich).
<G-vec00332-001-s417><alert.machen><en> A truck comes by playing a tune to alert you to its presence .
<G-vec00332-001-s417><alert.machen><de> Ein Lastwagen kommt, indem er eine Melodie zu Gegenwart machen Sie auf ihren.
<G-vec00332-001-s418><alert.machen><en> Villadiego and Castro alert us to the fact that sugar is one of the products we should make a big effort to avoid buying.
<G-vec00332-001-s418><alert.machen><de> Villadiego und Castro machen uns obendrein darauf aufmerksam, dass Zucker eines der Produkte ist, das wir nicht mehr kaufen sollten.
<G-vec00332-001-s419><alert.machen><en> The Alert Meter can be connected to a computer or laptop by means of the USB-Interface, thereby allowing an automatic and continuous measuring over a long period of time.
<G-vec00332-001-s419><alert.machen><de> Über eine USB-Daten-Schnittstelle können Sie das Formaldehyd - Messgerät zu einem PC oder Laptop verbinden und so kontinuierliche, automatische Dauermessungen der Formaldehyd - Konzentrationen über längere Zeiträume machen.
<G-vec00332-001-s420><alert.machen><en> Governments at the appropriate level, in collaboration with national institutions and interest groups and with the support of regional and international organizations, should launch awareness-raising campaigns to alert and educate people on the importance of integrated land and land resources management and the role that individuals and social groups can play in it.
<G-vec00332-001-s420><alert.machen><de> Bewußtseinsbildende Maßnahmen 10.9 Die Regierungen sollen auf der entsprechenden Ebene in Zusammenarbeit mit nationalen Institutionen und Interessengruppen und mit Unterstützung regionaler und internationaler Organisationen bewußtseinsbildende Maßnahmen durchführen, um der Bevölkerung die Bedeutung einer integrierten Flächen- und Bodenressourcenbewirtschaftung und die dem Einzelnen und den gesellschaftlichen Gruppen dabei zufallende Rolle vor Augen zu führen und verständlich zu machen.
<G-vec00332-001-s421><alert.machen><en> In cases where users opt-in, we use your information to send updates on Flexco. These updates will alert you to new products, special offers, events, changes to the website, upcoming trade shows, and new services from Flexco.
<G-vec00332-001-s421><alert.machen><de> Diese Aktualisierungen sollen Sie auf neue Produkte, Sonderangebote, Veranstaltungen, Änderungen der Webseite, bald stattfindende Messen und neue Dienstleistungen von Flexco aufmerksam machen.
<G-vec00332-001-s473><alert.sagen><en> Register for an alert when tickets are available to buy for Mark Knopfler.
<G-vec00332-001-s473><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Mark Knopfler verfügbar sind.
<G-vec00332-001-s474><alert.sagen><en> Register for an alert when tickets are available to buy for AS Saint Etienne.
<G-vec00332-001-s474><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von AS Saint Etienne verfügbar sind.
<G-vec00332-001-s475><alert.sagen><en> Register for an alert when tickets are available to buy for Rolling Stones Barcelona.
<G-vec00332-001-s475><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Rolling Stones Barcelona verfügbar sind.
<G-vec00332-001-s476><alert.sagen><en> Register for an alert when tickets are available to buy for Newcastle United - West Bromwich Albion.
<G-vec00332-001-s476><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Newcastle United - West Bromwich Albion verfügbar sind.
<G-vec00332-001-s477><alert.sagen><en> Register for an alert when tickets are available to buy for US Open Tennis.
<G-vec00332-001-s477><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von US Open Tennis verfügbar sind.
<G-vec00332-001-s478><alert.sagen><en> Register for an alert when tickets are available to buy for San Antonio Spurs.
<G-vec00332-001-s478><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von San Antonio Spurs verfügbar sind.
<G-vec00332-001-s479><alert.sagen><en> Register for an alert when tickets are available to buy for Enrique Iglesias.
<G-vec00332-001-s479><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Enrique Iglesias verfügbar sind.
<G-vec00332-001-s480><alert.sagen><en> Register for an alert when tickets are available to buy for The Vaccines.
<G-vec00332-001-s480><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von The Vaccines verfügbar sind.
<G-vec00332-001-s481><alert.sagen><en> Register for an alert when tickets are available to buy for Moto GP.
<G-vec00332-001-s481><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Moto GP verfügbar sind.
<G-vec00332-001-s482><alert.sagen><en> Register for an alert when tickets are available to buy for Mumford and Sons.
<G-vec00332-001-s482><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Mumford and Sons verfügbar sind.
<G-vec00332-001-s483><alert.sagen><en> Register for an alert when tickets are available to buy for West Ham United - Manchester United.
<G-vec00332-001-s483><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von West Ham United - Manchester United verfügbar sind.
<G-vec00332-001-s484><alert.sagen><en> Register for an alert when tickets are available to buy for Club World Cup.
<G-vec00332-001-s484><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Klub WM verfügbar sind.
<G-vec00332-001-s485><alert.sagen><en> Register for an alert when tickets are available to buy for Bryan Adams.
<G-vec00332-001-s485><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Bryan Adams verfügbar sind.
<G-vec00332-001-s486><alert.sagen><en> Register for an alert when tickets are available to buy for Franz Ferdinand.
<G-vec00332-001-s486><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Franz Ferdinand verfügbar sind.
<G-vec00332-001-s487><alert.sagen><en> Register for an alert when tickets are available to buy for Dave Matthews Band.
<G-vec00332-001-s487><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Dave Matthews Band verfügbar sind.
<G-vec00332-001-s488><alert.sagen><en> Register for an alert when tickets are available to buy for Olympique Marseille.
<G-vec00332-001-s488><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Olympique Marseille verfügbar sind.
<G-vec00332-001-s489><alert.sagen><en> Register for an alert when tickets are available to buy for Liverpool FC.
<G-vec00332-001-s489><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Liverpool FC verfügbar sind.
<G-vec00332-001-s490><alert.sagen><en> Register for an alert when tickets are available to buy for Atletico Madrid.
<G-vec00332-001-s490><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Atletico Madrid verfügbar sind.
<G-vec00332-001-s491><alert.sagen><en> Register for an alert when tickets are available to buy for Getafe CF - Real Betis.
<G-vec00332-001-s491><alert.sagen><de> Wir sagen Ihnen bescheid, wenn die Karten von Getafe CF - Levante UD verfügbar sind.
<G-vec00332-001-s586><alert.warnen><en> You can change the settings to block cookies or to alert you when cookies are being sent to your device.
<G-vec00332-001-s586><alert.warnen><de> Sie können die Einstellungen ändern, um Cookies zu blockieren oder Sie lassen sich warnen, wenn Cookies auf Ihr Gerät gesendet werden.
<G-vec00332-001-s587><alert.warnen><en> The Sandphones.site will show a “Confirm notifications” alert, asking you to subscribe to notifications from this website.
<G-vec00332-001-s587><alert.warnen><de> The Sandphones.site will show a “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Website zu abonnieren.
<G-vec00332-001-s588><alert.warnen><en> As they didn’t alert computer system about their installation, so it is actually very tough to detect and get rid of it.
<G-vec00332-001-s588><alert.warnen><de> Da sie nicht warnen Computersystem über ihre Montage, so ist es wirklich sehr schwer zu erkennen und es loswerden.
<G-vec00332-001-s589><alert.warnen><en> Notifications alert you to sudden changes so that you can reset your breath.
<G-vec00332-001-s589><alert.warnen><de> Benachrichtigungen warnen Sie vor plötzlichen Änderungen, damit Sie Atem holen können.
<G-vec00332-001-s590><alert.warnen><en> The Noteco.me site will display a “Confirm notifications” alert, asking you to subscribe to notifications from this site.
<G-vec00332-001-s590><alert.warnen><de> Die Noteco.me Website wird eine Anzeige “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Seite zu abonnieren.
<G-vec00332-001-s591><alert.warnen><en> This means we can alert you in time, before you risk an unplanned stop.
<G-vec00332-001-s591><alert.warnen><de> Das heißt, wir können Sie rechtzeitig warnen, bevor Sie einen ungeplanten Halt riskieren.
<G-vec00332-001-s592><alert.warnen><en> The Bigclicker.me will push a “Confirm notifications” alert, asking you to subscribe to alerts from this resource.
<G-vec00332-001-s592><alert.warnen><de> The Robotornotchecks.site site will display a “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Seite zu abonnieren.
<G-vec00332-001-s593><alert.warnen><en> The Yourfortunewheel.com will push a “Confirm notifications” alert, asking you to subscribe to alerts from this website.
<G-vec00332-001-s593><alert.warnen><de> Die Yourfortunewheel.com wird ein Push “bestätigen Benachrichtigungen” warnen, fragen Sie Benachrichtigungen von dieser Website abonnieren.
<G-vec00332-001-s594><alert.warnen><en> The Fireactive.fun will show a “Confirm notifications” alert, asking you to subscribe to alerts from this website.
<G-vec00332-001-s594><alert.warnen><de> The Fireactive.fun will show a “bestätigen Benachrichtigungen” warnen, fragen Sie Benachrichtigungen von dieser Website abonnieren.
<G-vec00332-001-s595><alert.warnen><en> When turning or reversing, H8 will give riders alert if there are obstacles to ensure the safety of rider and others.
<G-vec00332-001-s595><alert.warnen><de> Beim Drehen oder umkehren, H8 geben warnen Fahrer, wenn gibt es Hindernisse für die Sicherheit des Fahrers und andere.
<G-vec00332-001-s596><alert.warnen><en> The Nextlvlvideos.info site will push a “Confirm notifications” alert, asking you to subscribe to alerts from this resource.
<G-vec00332-001-s596><alert.warnen><de> The Nextlvlvideos.info site will push a “bestätigen Benachrichtigungen” warnen, fragen Sie Warnungen von dieser Ressource abonnieren.
<G-vec00332-001-s597><alert.warnen><en> This screening for women can alert you to the risk of thinning bones that could become osteoporosis later in life.
<G-vec00332-001-s597><alert.warnen><de> Dieser Scan für Frauen kann Sie frühzeitig vor Knochenschwund, der später zu Osteoporose führen kann, warnen.
<G-vec00332-001-s598><alert.warnen><en> Now you have an exciting solution that can alert you before NAS drives fail, helping you to prevent data loss.
<G-vec00332-001-s598><alert.warnen><de> Jetzt haben Sie eine spannende Lösung, die Sie warnen kann, bevor NAS-Laufwerke ausfallen, die Ihnen hilft, Datenverluste zu vermeiden.
<G-vec00332-001-s599><alert.warnen><en> The Tiledenherred.pro site will show a “Confirm notifications” alert, asking you to subscribe to notifications from this resource.
<G-vec00332-001-s599><alert.warnen><de> The Tiledenherred.pro site will show a “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Ressource zu abonnieren.
<G-vec00332-001-s600><alert.warnen><en> The Topcheck.pro site will push a “Confirm notifications” alert, asking you to subscribe to alerts from this resource.
<G-vec00332-001-s600><alert.warnen><de> The Medora.pro site will display a “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Website zu abonnieren.
<G-vec00332-001-s601><alert.warnen><en> The Robozones.pro site will push a “Confirm notifications” alert, asking you to subscribe to notifications from this site.
<G-vec00332-001-s601><alert.warnen><de> The Robozones.pro site will push a “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Seite zu abonnieren.
<G-vec00332-001-s602><alert.warnen><en> The Sinvariouspreverre.info site will show a “Confirm notifications” alert, asking you to subscribe to notifications from this site.
<G-vec00332-001-s602><alert.warnen><de> Die Sinvariouspreverre.info Website zeigt ein “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Seite zu abonnieren.
<G-vec00332-001-s603><alert.warnen><en> Libération 's criticisms of the WSWS for fighting to alert workers internationally to the war danger and mobilize them in struggle against imperialist war are shot through with bad faith.
<G-vec00332-001-s603><alert.warnen><de> Die Kritik der Libération an den Versuchen der WSWS, die weltweite Arbeiterklasse vor der Kriegsgefahr zu warnen und im Kampf gegen den imperialistischen Krieg zu mobilisieren, ist völlig unredlich.
<G-vec00332-001-s604><alert.warnen><en> The Warrangeroctors.pro will display a “Confirm notifications” alert, asking you to subscribe to notifications from this site.
<G-vec00332-001-s604><alert.warnen><de> Die Warrangeroctors.pro wird eine Anzeige “bestätigen Benachrichtigungen” warnen, fragen Sie, um Benachrichtigungen von dieser Seite zu abonnieren.
<G-vec00332-001-s636><alert.warnen><en> This lightweight wide-angle reflector stands upright to alert other road users even in strong winds and on slippery surfaces.
<G-vec00332-001-s636><alert.warnen><de> Das leichte Warndreieck mit Weitwinkelreflektor kippt auch bei starkem Wind und rutschigem Untergrund nicht um und warnt so andere Verkehrsteilnehmer.
<G-vec00332-001-s637><alert.warnen><en> This movement, the Avatars joined in an only one voice, intends to alert the human being that the time is short.
<G-vec00332-001-s637><alert.warnen><de> Diese Bewegung zusammen mit den Avataren, kommt eine Stimme warnt die Menschen, dass die Zeit knapp ist.
<G-vec00332-001-s638><alert.warnen><en> """We ask - it has restated - a control aimed and capillary for all the territory of competence through a public direction of the agencies, firstly of Authority of Harbour System, Harbour-office and Arpal as previsore that evolving of the conditions monitors before weather and during the weather alert, to the aim of being able to decide the operativity less or of the ports of call and the terminals."
<G-vec00332-001-s638><alert.warnen><de> """fragen wir eine zielt Kontrolle,- hat es bekräftigt -, und warnt es kapillar von all Gebiet von der Kompetenz durch eine allgemeine Regie von den Körperschaften, in primis von der Autorität von dem Hafen System, Capitaneria und Arpal wie Previsore meteorologisch damit zu können oder die Einsatzbereitschaft von den Zwischenlandungen von den Terminals und weniger entscheiden, der meteorologisches vorher, sich von den Bedingungen und während sie zu entwickeln monitorisiert."
<G-vec00332-001-s639><alert.warnen><en> EAO, the expert partner for Human Machine Interfaces, has developed an intelligent, configurable sound module to alert people to potentially dangerous situations, such as at automatic train doors or pedestrian crossings and lift doors.
<G-vec00332-001-s639><alert.warnen><de> EAO, der Experte für Human Machine Interfaces (HMIs), hat ein intelligentes, konfigurierbares Sound Modul entwickelt, das Personen vor gefährlichen Situationen warnt, die zum Beispiel beim Schließen von Zugtüren im öffentlichen Personenverkehr, an Fußgängerüberwegen oder Lifttüren entstehen können.
<G-vec00332-001-s640><alert.warnen><en> CommManager in contrast to other conventional security systems do not have a keyboard, which is the weak link in the system, giving attackers time to make a quick break (eg, taking valuable equipment and escape before the signal will alert the person) .
<G-vec00332-001-s640><alert.warnen><de> CommManager im Gegensatz zu anderen herkömmlichen Sicherheitssysteme nicht über eine Tastatur, was ist das schwache Glied im System, geben Angreifern Zeit, um eine kurze Pause zu machen (zB, unter wertvolle Ausrüstung und die Flucht vor dem Signal warnt die Person) .
<G-vec00332-001-s641><alert.warnen><en> "In the beginning of 2004, Jiang Zemin encouraged his confidant, Chen Zhili, the current Secretary of the Department of Education, to start a campaign throughout the nation's educational system under the slogan, ""Fight the XX (slanderous words omitted) and Alert the Educational System!"" Chen Zhili created the slogan, ""Fight the XX,"" to defame Falun Gong, a peaceful practice based on the principles of Truthfulness, Compassion, and Tolerance, to incite hatred and to form support for Jiang's persecution policies."
<G-vec00332-001-s641><alert.warnen><de> Mit Beginn des Jahres 2004, ermutigte Jiang Zemin seinen Vertrauten Chen Zhili, den gegenwärtigen Sekretär des Ministeriums für Bildung, eine Kampagne im gesamten Bildungssystem der Nation zu beginnen, mit dem schlagenden Satz: „Bekämpft die XX (verleumdende Worte ausgelassen) und warnt das Bildungssystem!“ Chen Zhili kreierte den Slogan: „Bekämpft die XX“, um Falun Gong zu diffamieren, eine friedvolle Praxis, die auf den Prinzipien Zhen, Shan, Ren (Wahrhaftigkeit, Barmherzigkeit und Nachsicht) beruht, um im Volk Hass zu erzeugen und Unterstützung für Jiang Zemins Verfolgungstaktiken zu bekommen.
<G-vec00332-001-s642><alert.warnen><en> For example, if a pedestrian approaches from the right, a lighting sequence is triggered to alert the driver.
<G-vec00332-001-s642><alert.warnen><de> Beispielsweise warnt eine entsprechende Lichtgestaltung im Fahrzeug, wenn ein Fußgänger von rechts kommt.
<G-vec00332-001-s643><alert.warnen><en> This clock may not only alert the user by audio and visual signals, but also perform some pre-configured actions, like starting an application, turning off the computer, and so on.
<G-vec00332-001-s643><alert.warnen><de> Diese Uhr kann nicht nur warnt den Benutzer durch akustische und visuelle Signale, sondern führen auch einige vorkonfigurierte Aktionen, wie das Starten einer Anwendung, den Computer auszuschalten, und so weiter.
<G-vec00332-002-s114><alert.alarmieren><en> Create your own personalized push notifications to alert you when people come and go, a water leak is detected, even if the garage door has been left ajar.
<G-vec00332-002-s114><alert.alarmieren><de> Mehr über Intercom Anywhere Seien Sie alarmiert, wenn Personen kommen und gehen, ein Wasserleck erkannt wird oder wenn das Garagentor offen gelassen wurde.
<G-vec00332-002-s115><alert.alarmieren><en> If an emergency arises, just press the alarm button to alert your helpers.
<G-vec00332-002-s115><alert.alarmieren><de> Im Notfall drücken Sie einfach auf den Alarmknopf und Ihre Helfer werden alarmiert.
<G-vec00332-002-s116><alert.alarmieren><en> 4.1 x 3.9, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s116><alert.alarmieren><de> 3.3 x 3.3, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s117><alert.alarmieren><en> Analog, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s117><alert.alarmieren><de> Bronze, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s118><alert.alarmieren><en> Black, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s118><alert.alarmieren><de> Armbanduhren, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s119><alert.alarmieren><en> Multi-Colored, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s119><alert.alarmieren><de> Black, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s120><alert.alarmieren><en> Pink, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s120><alert.alarmieren><de> Silber, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s121><alert.alarmieren><en> FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s121><alert.alarmieren><de> Video FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s122><alert.alarmieren><en> Uptrends verifies that your certificates are running properly, and will alert you in the event yours has been hacked or has expired.
<G-vec00332-002-s122><alert.alarmieren><de> Uptrends prüft, ob deine Zertifikate richtig funktionieren, und alarmiert dich, wenn sie gehackt wurden oder abgelaufen sind.
<G-vec00332-002-s124><alert.alarmieren><en> Our powerful spy software will alert you when your child is into something suspicious
<G-vec00332-002-s124><alert.alarmieren><de> Unsere leistungsfähige Spion-Software alarmiert dich, falls dein Kind etwas misstrauisch geworden ist.
<G-vec00332-002-s125><alert.alarmieren><en> 4, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s125><alert.alarmieren><de> 30m, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s127><alert.alarmieren><en> International Information Policy and Security Council (IIPSC) researches, debates and alert the importance of early warning signs and signals that act as an international ” Watchdog ” to educate and promote solutions to issues of importance such as cyber security, global threats and scholarly education at all levels.
<G-vec00332-002-s127><alert.alarmieren><de> Das IIPSC erforscht, debattiert und alarmiert die Bedeutung der frühen Warnzeichen und Signale, agiert als internationaler “Wachhund”, erzieht/belehrt und fördert Lösungen zu Fragen von Bedeutung wie der Cyber-Sicherheit, globalen Bedrohungen und wissenschaftlicher Ausbildung an Alle Ebenen.
<G-vec00332-002-s129><alert.alarmieren><en> After 10 minutes of inactivity, or no button pushes, the device will alert you and then shut off.
<G-vec00332-002-s129><alert.alarmieren><de> Nach 10-minütiger Inaktivität, bei der keine Tasten gedrückt werden, alarmiert Sie das Gerät und schaltet sich anschließend ab.
<G-vec00332-002-s130><alert.alarmieren><en> The sensor is activated (and powered) by stomach fluid, and the patient’s physiological data is output to an accompanying smartphone app, that will alert them if a medicine isn’t taken as scheduled.
<G-vec00332-002-s130><alert.alarmieren><de> Der Sensor wird durch Magensaft aktiviert und die physiologischen Parameter des Patienten an eine zugehörige Smartphone-App weitergeleitet, die den Betroffenen alarmiert, wenn das Medikament falsch eingenommen wurde.
<G-vec00332-002-s131><alert.alarmieren><en> Our proven analysis algorithms detect the size, speed and direction of movement of an object and alert the monitoring control center in real time.
<G-vec00332-002-s131><alert.alarmieren><de> Unser tausendfach bewährter Analysealgorithmus erkennt die Größe, die Geschwindigkeit und die Bewegungsrichtung eines Objekts und alarmiert in Echtzeit Ihre Überwachungszentrale.
<G-vec00332-002-s240><alert.benachrichtigen><en> Cookies. If you do not wish us to collect cookies, you may set your browser to refuse cookies, or to alert you when cookies are being sent.
<G-vec00332-002-s240><alert.benachrichtigen><de> Wenn Sie mit einem Browser auf die Dienste zugreifen, können Sie den Browser so konfigurieren, dass er alle Cookies akzeptiert, alle Cookies ablehnt oder Sie benachrichtigt, wenn ein Cookie gesendet wird.
<G-vec00332-002-s241><alert.benachrichtigen><en> If you would prefer, you may set your browser to refuse cookies or alert you when cookies are being sent; however, it is possible that some parts of our sites will not function properly if you do so.
<G-vec00332-002-s241><alert.benachrichtigen><de> Sie können Ihre Browser-Einstellungen jedoch so ändern, dass Cookies abgelehnt werden oder Sie bei jedem Senden von Cookies benachrichtigt werden; gewisse Funktionen unserer Homepage werden dadurch jedoch eventuell deaktiviert.
<G-vec00332-002-s242><alert.benachrichtigen><en> If an abnormal condition is detected, it will alert the operator and instruct them to take appropriate action.
<G-vec00332-002-s242><alert.benachrichtigen><de> Falls ein Störzustand erkannt wird, benachrichtigt das Programm den Fahrer und gibt konkrete Anweisungen zur Problemlösung.
<G-vec00332-002-s243><alert.benachrichtigen><en> You can set your browser to refuse all or some browser cookies or to alert you when websites set or access cookies.
<G-vec00332-002-s243><alert.benachrichtigen><de> [Sie können Ihren Browser so einstellen, dass er alle oder einige Arten von Cookies nicht zulässt, oder dass er Sie benachrichtigt, wenn Websites Cookies platzieren oder darauf zugreifen.
<G-vec00332-002-s244><alert.benachrichtigen><en> The parent unit will alert you when your monitor is out of range or when the power is low, helping you to make sure that you are always connected to your baby.
<G-vec00332-002-s244><alert.benachrichtigen><de> Die Elterneinheit benachrichtigt Sie, wenn das Babyphone außer Reichweite oder der Akku schwach ist, sodass Sie sicher sein können, dass Sie immer mit Ihrem Baby verbunden sind.
<G-vec00332-002-s245><alert.benachrichtigen><en> When the product is not available we will give you the option to sign up to an alert to let you know when it is back in stock.
<G-vec00332-002-s245><alert.benachrichtigen><de> Wenn das Produkt nicht verfügbar ist, haben Sie die Möglichkeit benachrichtigt zu werden, um informiert zu werden, sobald wir das Produkt wieder verkaufen.
<G-vec00332-002-s246><alert.benachrichtigen><en> OpManager monitors these file and folders and alert you straightaway, if it finds any deviations from the expected behavior.
<G-vec00332-002-s246><alert.benachrichtigen><de> Falls die Lösung dabei Abweichungen vom erwarteten Verhalten erkennt, werden Sie umgehend benachrichtigt.
<G-vec00332-002-s247><alert.benachrichtigen><en> Cookies You can set your browser to refuse all or some browser cookies, or to alert you when websites set or access cookies.
<G-vec00332-002-s247><alert.benachrichtigen><de> [Sie können Ihren Browser so einstellen, dass er alle oder einige Arten von Cookies nicht zulässt, oder dass er Sie benachrichtigt, wenn Websites Cookies platzieren oder darauf zugreifen.
<G-vec00332-002-s248><alert.benachrichtigen><en> You can set your browser to block or alert you about these cookies, but some parts of the site will not then work.
<G-vec00332-002-s248><alert.benachrichtigen><de> Sie können Ihren Browser so einstellen, dass er Sie über diese Cookies blockiert oder benachrichtigt, aber einige Teile der Webseite funktionieren dann nicht.
<G-vec00332-002-s249><alert.benachrichtigen><en> Use the improved asset status badges to alert you when team members edit projects even before they share the changes.
<G-vec00332-002-s249><alert.benachrichtigen><de> Nutzen Sie die verbesserten Elementstatus-Badges, um benachrichtigt zu werden, wenn Team-Mitglieder Projekte bearbeiten, noch bevor diese die Änderungen freigeben.
<G-vec00332-002-s250><alert.benachrichtigen><en> Firstly, set your CRM system to alert you if identical data is entered into the database, this way you can keep your data clean.
<G-vec00332-002-s250><alert.benachrichtigen><de> Hierfür gibt es einige Tipps und Tricks: Stellen Sie in Ihrem CRM-System als allererstes die Warnfunktion ein, die Sie benachrichtigt, sobald identische Daten in die Datenbank eingegeben werden.
<G-vec00332-002-s251><alert.benachrichtigen><en> You can set your browser to refuse all or some browser cookies, or to alert you when cookies are being sent.
<G-vec00332-002-s251><alert.benachrichtigen><de> Sie können Ihren Browser so konfigurieren, dass alle oder bestimmte Cookies abgelehnt werden, oder dass Sie benachrichtigt werden, wenn Cookies gesendet werden.
<G-vec00332-002-s252><alert.benachrichtigen><en> Web browsers allow users to set their browser to refuse all or some browser cookies, or to alert you when cookies are being sent.
<G-vec00332-002-s252><alert.benachrichtigen><de> Sie können die Einstellungen Ihres Browsers so anpassen, dass alle oder einige Browser-Cookies abgelehnt werden oder Sie benachrichtigt werden, wenn Cookies gesandt werden.
<G-vec00332-002-s253><alert.benachrichtigen><en> Never leave your phone behind again -- The wireless leash will alert you when your watch is out of range.
<G-vec00332-002-s253><alert.benachrichtigen><de> Nie mehr Ihr Telefon vergessen – Die „Unsichtbare Leine“ benachrichtigt Sie, wenn sich Ihre Uhr außer Reichweite befindet.
<G-vec00332-002-s254><alert.benachrichtigen><en> Create an Email Alert We will send you an email alert when something matching this search will be added for sale on Mascus.
<G-vec00332-002-s254><alert.benachrichtigen><de> Geben Sie eine kostenlose Suchanfrage auf, und Sie werden per Email benachrichtigt, sobald Ihr gesuchtes Produkt zum Verkauf auf Mascus angeboten wird.
<G-vec00332-002-s256><alert.benachrichtigen><en> You can set your browser to refuse all or some browser cookies, or to alert you when websites set or access cookies.
<G-vec00332-002-s256><alert.benachrichtigen><de> COOKIES Sie können Ihren Browser so einstellen, dass er alle oder bestimmte Browser-Cookies ablehnt oder Sie benachrichtigt, wenn Websites Cookies setzen oder darauf zugreifen.
<G-vec00332-002-s257><alert.benachrichtigen><en> You can set your browser to refuse all or some browser cookies, or to alert you when websites set or access cookies.
<G-vec00332-002-s257><alert.benachrichtigen><de> Sie können Ihren Browser so einstellen, dass alle oder bestimmte Cookies abgelehnt werden, oder dass Sie benachrichtigt werden, wenn Websites Cookies setzen oder auf Cookies zugreifen.
<G-vec00332-002-s258><alert.benachrichtigen><en> Real-time alert notifications keep users completely in touch when important news breaks on their favorite subjects.
<G-vec00332-002-s258><alert.benachrichtigen><de> Die Benutzer werden in Echtzeit benachrichtigt, wenn wichtige Nachrichten zu ihren Lieblingsthemen erscheinen und bleiben so stets auf dem Laufenden.
<G-vec00332-002-s291><alert.entsprechen><en> April 1921 in We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s291><alert.entsprechen><de> Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s292><alert.entsprechen><en> We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s292><alert.entsprechen><de> Bestsellers Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s295><alert.entsprechen><en> Concierto de We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s295><alert.entsprechen><de> Wolfgang Amadeus Mozart (1756-1791) • Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s296><alert.entsprechen><en> Messiaen - Vocalise, you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s296><alert.entsprechen><de> Preisalarm Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s297><alert.entsprechen><en> Chandos Records We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s297><alert.entsprechen><de> String Quartet Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s299><alert.entsprechen><en> Advance Music, 190 pages, book (introduction & scores) + CD We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s299><alert.entsprechen><de> Preisalarm Ludwig van Beethoven (1770-1827) - String Quartet Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s303><alert.entsprechen><en> Denon Records We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s303><alert.entsprechen><de> Oboe Quartet Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s305><alert.entsprechen><en> Tangent Rephlex Records We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s305><alert.entsprechen><de> Neuware, versiegelt / Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s307><alert.entsprechen><en> collection Destinations We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s307><alert.entsprechen><de> Kollektion Destinations Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s308><alert.entsprechen><en> Description Price alert Birgit We'll inform you if the price of this product will be changed according to your price alert.
<G-vec00332-002-s308><alert.entsprechen><de> Joaquin Rodrigo (1901-1999) - Concierto de Aranjuez Wir informieren Sie gern darüber, falls der Preis dieses Artikels Ihrem Wunschpreis entspricht.
<G-vec00332-002-s341><alert.informieren><en> Please enter your email so we can alert you when the Backpack Happy in is back in stock.
<G-vec00332-002-s341><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Rucksack Hala in wieder lieferbar ist.
<G-vec00332-002-s342><alert.informieren><en> - Alert the dog pounds as well as the nearest vets.
<G-vec00332-002-s342><alert.informieren><de> Informieren Sie die Tierheime sowie die nächst gelegenen Tierärzte.
<G-vec00332-002-s343><alert.informieren><en> This message appears to alert that your account expired, please renew to keep using.
<G-vec00332-002-s343><alert.informieren><de> Diese Meldung wird angezeigt, um zu informieren, dass Ihr Konto abgelaufen ist, bitte erneuern, um weiter zu verwenden.
<G-vec00332-002-s344><alert.informieren><en> Preventive maintenance program tracks time to next service interval and can optionally alert to upcoming interval due soon, or past due service.
<G-vec00332-002-s344><alert.informieren><de> Instandhaltungsprogramme zeichnen die Zeit bis zum nächsten Serviceintervall auf und können optional rechtzeitig über einen anstehenden Service oder über einen verpassten Service informieren.
<G-vec00332-002-s345><alert.informieren><en> After the software has been updated successfully and after you have rebooted the camera, message windows may alert you of configuration parameters not matching.
<G-vec00332-002-s345><alert.informieren><de> Nach erfolgreicher Aktualisierung der Software und einem Neustart der Kamera können Meldungsfenster erscheinen, die über nicht übereinstimmende Konfigurationsparameter informieren.
<G-vec00332-002-s346><alert.informieren><en> It is simple—raise a red flag to be left alone and use the yellow flag to alert our staff for service.
<G-vec00332-002-s346><alert.informieren><de> Es ist einfach, eine rote Fahne zu erheben, um allein gelassen zu werden und die gelbe Flagge zu benutzen, um unsere Mitarbeiter für den Dienst zu informieren.
<G-vec00332-002-s347><alert.informieren><en> We asked representatives of community leaders to monitor the election reporting in their locality and alert radio managers of any hate speech that was aired.
<G-vec00332-002-s347><alert.informieren><de> Wir baten die Repräsentanten von Dorfvorstehern, die Wahlberichterstattung in ihrem Ort zu überwachen und die Radiomanager zu informieren, wenn irgendwo Hassreden verbreitet wurden.
<G-vec00332-002-s348><alert.informieren><en> We will alert you to any known security threats affecting Bazaarvoice systems.
<G-vec00332-002-s348><alert.informieren><de> Wir werden Sie über jegliche bekannte Sicherheitsbedrohungen informieren, die sich auf die Bazaarvoice-Systeme auswirken.
<G-vec00332-002-s349><alert.informieren><en> Please enter your email so we can alert you when the Pile Yupik Half in is back in stock.
<G-vec00332-002-s349><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Flor Yupik Half in wieder lieferbar ist.
<G-vec00332-002-s350><alert.informieren><en> Please enter your email so we can alert you when the Beanie Fal in is back in stock.
<G-vec00332-002-s350><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Beanie-Mütze Fal in wieder lieferbar ist.
<G-vec00332-002-s351><alert.informieren><en> It is also your responsibility to alert Google or the relevant partner if you believe that the security of the information in the Google Wallet application has been compromised.
<G-vec00332-002-s351><alert.informieren><de> Sie sind ebenfalls dafür verantwortlich, Google oder den betreffenden Partner zu informieren, wenn Sie den Verdacht haben, dass unbefugt auf die Informationen in der Google Wallet-App zugegriffen wurde.
<G-vec00332-002-s352><alert.informieren><en> Please enter your email so we can alert you when the Fleece Teide in is back in stock.
<G-vec00332-002-s352><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Fleece Teide in wieder lieferbar ist.
<G-vec00332-002-s353><alert.informieren><en> Please enter your email so we can alert you when the Hoodie Burgee in is back in stock.
<G-vec00332-002-s353><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Kapuzensweatshirt Burgee in wieder lieferbar ist.
<G-vec00332-002-s354><alert.informieren><en> In this breaking news edition, we alert our readers to a series of materials recently released by the IRS.
<G-vec00332-002-s354><alert.informieren><de> In dieser Eilmitteilung informieren wir unsere Leser über die kürzlich veröffentlichten Materialien von der IRS.
<G-vec00332-002-s355><alert.informieren><en> Please enter your email so we can alert you when the Parka coat Aliwal in is back in stock.
<G-vec00332-002-s355><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Parka Skidoo Tribe in wieder lieferbar ist.
<G-vec00332-002-s356><alert.informieren><en> If substantial changes are made to the use of the data related to the user on the part of the Data Controller, the latter will alert the user by posting them with the utmost evidence on its pages or through alternative or similar means.
<G-vec00332-002-s356><alert.informieren><de> Werden wesentliche Änderungen an der Nutzung der Daten des Anwenders durch den Inhaber vorgenommen, wird dieser den Anwender durch Veröffentlichung auf seinen Seiten oder auf andere oder ähnliche Weise deutlich sichtbar informieren.
<G-vec00332-002-s357><alert.informieren><en> They offer insight into why a character might make a certain decision, and alert us if something seems out of character.
<G-vec00332-002-s357><alert.informieren><de> Sie geben Aufschluss darüber, warum ein Charakter eine bestimmte Entscheidung treffen kann, und informieren uns, wenn etwas außerhalb des Charakters erscheint.
<G-vec00332-002-s358><alert.informieren><en> We will alert you about any changes by updating the “Last updated” date of these Terms and Conditions and you waive any right to receive specific notice of each such change.
<G-vec00332-002-s358><alert.informieren><de> Wir werden Sie über alle Änderungen informieren, indem wir das Datum "Zuletzt aktualisiert" dieser Nutzungsbedingungen aktualisieren, und Sie verzichten auf jegliches Recht, über jede dieser Änderungen gesondert informiert zu werden.
<G-vec00332-002-s359><alert.informieren><en> Please enter your email so we can alert you when the Hoodie Baoding in is back in stock.
<G-vec00332-002-s359><alert.informieren><de> Bitte gib Deine E-Mail ein, sodass wir Dich informieren können, wenn Kapuzensweatshirt Baoding in wieder lieferbar ist.
