<G-vec00571-001-s228><cast.gießen><en> Like the other bronze copies, it was modelled by Pietro Galli at the beginning of the 1820s and cast in bronze by Wilhelm Hopfgarten.
<G-vec00571-001-s228><cast.gießen><de> Die Bronzekopie wurde wie die übrigen Miniaturen erst in den 1820er Jahren von Pietro Galli modelliert und von Wilhelm Hopfgarten in Bronze gegossen.
<G-vec00571-001-s229><cast.gießen><en> His famous female busts are made from plastic and polished marble or cast in bronze.
<G-vec00571-001-s229><cast.gießen><de> Seine berühmten weiblichen Büsten sind aus Kunststoff und poliertem Marmor oder in Bronze gegossen.
<G-vec00571-001-s230><cast.gießen><en> Here is happy new year cast 27+ collection For wishing Your Mom, Dad,Son, Daughter, Brothers, Sisters, Girlfriend, Boy Friend, Grand Parents, Neighbors, And friends.
<G-vec00571-001-s230><cast.gießen><de> Hier ist guten Rutsch ins neue Jahr gegossen 27+ Sammlung für den Wunsch Ihrer Mutter, Papa,Sohn, Tochter, Brüder, Schwestern, Freundin, Boy Friend, Großeltern, Nachbarschaft, Und Freunde.
<G-vec00571-001-s231><cast.gießen><en> The eyes were cast from brass directly in the skull.
<G-vec00571-001-s231><cast.gießen><de> Die Augen wurden aus Messing direkt in den Schädel gegossen.
<G-vec00571-001-s232><cast.gießen><en> Shadows cast by candlelight are a lot less romantic when they make you stub your toe on the corner of your bed.
<G-vec00571-001-s232><cast.gießen><de> Shadows bei Kerzenschein gegossen werden viel weniger romantisch, wenn sie dich Stub Ihre Zehen auf machen die Ecke Ihres Bettes.
<G-vec00571-001-s233><cast.gießen><en> Cast from state-of-the-art materials and machined on CNC equipment for strength and...
<G-vec00571-001-s233><cast.gießen><de> Aus modernen Materialien gegossen und auf CNC-Maschinen bearbeitet, was sie hochbelastbar und...
<G-vec00571-001-s234><cast.gießen><en> The material bell bronze, cast in sand and polished to smoothness, is processed in a very accurate way.
<G-vec00571-001-s234><cast.gießen><de> Das Material der Glockenbronze, in Sand gegossen und weich beschliffen, ist von großer Beständigkeit.
<G-vec00571-001-s235><cast.gießen><en> Now the world's first jazz bell has been cast.
<G-vec00571-001-s235><cast.gießen><de> Die erste Jazz-Glocke wurde jetzt gegossen.
<G-vec00571-001-s236><cast.gießen><en> And he made the Sea of cast bronze, ten cubits from one brim to the other; it was completely round. Its height was five cubits, and a line of thirty cubits measured its circumference.
<G-vec00571-001-s236><cast.gießen><de> Und er machte das Meer, gegossen, zehn Ellen von seinem [einen] Rand bis zu seinem [anderen] Rand, ringsum rund und fünf Ellen seine Höhe; und eine Meßschnur von dreißig Ellen umspannte es ringsherum.
<G-vec00571-001-s237><cast.gießen><en> The bulls were cast in two rows in one piece with the Sea.
<G-vec00571-001-s237><cast.gießen><de> Sie umschlossen das Meer ringsum, zwei Reihen von Gewinden, in einem Guß mit ihm gegossen.
<G-vec00571-001-s238><cast.gießen><en> She auditioned and was cast in My Little Girl (1986), a low-budget film co-written and directed by Connie Kaiserman.
<G-vec00571-001-s238><cast.gießen><de> Sie tanzte und wurde in mein kleines Mädchen gegossen (1986), ein Low-Budget-Film Co-geschrieben und unter der Regie von Connie Kaiserman.
<G-vec00571-001-s239><cast.gießen><en> Assemble wax patterns: Multiple wax patterns can be created and assembled into one large pattern to be cast in one batch pour.
<G-vec00571-001-s239><cast.gießen><de> Wachsmuster zusammenstellen: Mehrere Wachsmuster können Geschaffen und zu einem großen Muster zusammengebaut werden, um in einem Bour-Gour gegossen zu werden.
<G-vec00571-001-s240><cast.gießen><en> Inspired by the rustic mountain setting, cast insulating concrete was chosen for the outer walls, lending the volume an authentic feeling of immediacy.
<G-vec00571-001-s240><cast.gießen><de> Inspiriert vom rauen Bergumfeld wurden die Außenwände aus Dämmbeton gegossen, welche dem Baukörper eine authentische Direktheit verleihen.
<G-vec00571-001-s241><cast.gießen><en> This bell was cast on the occasion of visit of the Holy Father Pope Francis to Sarajevo and Catholics of Bosnia and Herzegovina on 6. 6.
<G-vec00571-001-s241><cast.gießen><de> Gegossen wurde die Glocke aus Anlass des Besuches des Heiligen Vaters Papst Franziskus den Katholiken von Bosnien und Herzegowina und Sarajevo, am 06.06.2015.
<G-vec00571-001-s242><cast.gießen><en> The image is in the subduing Mara posture, cast by laser beams on the Khao Chi Chan cliff.
<G-vec00571-001-s242><cast.gießen><de> Das Bild ist in der Unterwerfung Mara Haltung, gegossen von Laserstrahlen auf der Khao Chi Chan Klippe.
<G-vec00571-001-s243><cast.gießen><en> On the inner surface of the case cast stand for the horizontal and guides for vertical PCB mounting.
<G-vec00571-001-s243><cast.gießen><de> Die innere Oberfläche des Körpers gegossen stehen für die horizontale und vertikale Führungen für Leiterplatten-Montage.
<G-vec00571-001-s244><cast.gießen><en> Suitcase The Star of David is a recurring element in Lurie's works and emerges in all possible forms: cast in concrete, scratched or painted onto the canvas, stuck on, sewed, and burned into the screen.
<G-vec00571-001-s244><cast.gießen><de> Suitcase Davidsterne sind im Werk Luries ein stets wiederkehrendes Element, das in allen möglichen Formen auftaucht: in Beton gegossen, auf die Leinwand geritzt oder gemalt, aufgeklebt, genäht und in die Bildfläche gebrannt.
<G-vec00571-001-s245><cast.gießen><en> Cast in sheet form whilst still molten soften,it is rolled and the side wings are formed to create a U shaped profile.
<G-vec00571-001-s245><cast.gießen><de> In Blattform gegossen, während noch geschmolzenes weiches, es ist rol led und die Seitenflügel sind gebildet, um ein U-förmiges Profil zu schaffen.
<G-vec00571-001-s246><cast.gießen><en> In early 2006, Zimmer was cast as Brianna, the competitive law undergrad, in the ABC crime/drama series In Justice.
<G-vec00571-001-s246><cast.gießen><de> In früh 2006, Zimmer wurde als Brianna gegossen, das Wettbewerbsrecht under, in der ABC-Kriminalität / Drama-Serie In Justice.
<G-vec00571-001-s304><cast.werfen><en> Competition for the leading role was very intense and Lee only got to know he was cast from the newspapers.
<G-vec00571-001-s304><cast.werfen><de> Der Wettbewerb um die führende Rolle war sehr intensiv und Lee bekam nur zu wissen, dass er aus den Zeitungen geworfen wurde.
<G-vec00571-001-s305><cast.werfen><en> So you should always keep an eye be cast on the latest developments.
<G-vec00571-001-s305><cast.werfen><de> Deshalb sollte immer ein Auge auf die aktuellsten Entwicklungen geworfen werden.
<G-vec00571-001-s306><cast.werfen><en> 15 And they went after them unto the Jordan: and, lo, all the way was full of garments and vessels, which the Syrians had cast away in their haste.
<G-vec00571-001-s306><cast.werfen><de> 15 Und da sie ihnen nachzogen bis an den Jordan, siehe, da lag der Weg voll Kleider und Geräte, welche die Syrer von sich geworfen hatten, da sie eileten.
<G-vec00571-001-s307><cast.werfen><en> If anyone was not found written in the book of life, he was cast into the lake of fire.
<G-vec00571-001-s307><cast.werfen><de> Und so jemand nicht ward gefunden geschrieben in dem Buch des Lebens, der ward geworfen in den feurigen Pfuhl.
<G-vec00571-001-s308><cast.werfen><en> In September 1997, Kingston gained North American television fame after being cast on the long-running medical drama ER.
<G-vec00571-001-s308><cast.werfen><de> Im September 1997, Kingston wurde nordamerikanischen Fernsehen berühmt nach auf dem langwierigen medizinischen Drama ER geworfen.
<G-vec00571-001-s309><cast.werfen><en> 18 and have cast their gods into the fire; for they were no gods, but the work of men’s hands, wood and stone. Therefore they have destroyed them.
<G-vec00571-001-s309><cast.werfen><de> 18 und haben ihre Götter ins Feuer geworfen; denn sie waren nicht Götter, sondern Werke von Menschenhand, Holz und Stein; darum haben sie sie verderbt.
<G-vec00571-001-s310><cast.werfen><en> he hath cast down from heaven unto the earth the beauty of Israel, and hath not remembered his footstool in the day of his anger.
<G-vec00571-001-s310><cast.werfen><de> Er hat die Herrlichkeit Israels vom Himmel auf die Erde geworfen; er hat nicht gedacht an seinen Fußschemel am Tage seines Zorns.
<G-vec00571-001-s311><cast.werfen><en> That these millions have not been mobilized in action to combat this racist frame-up is the responsibility of the pro-capitalist labor misleaders, who fear calling their members into action to defend their economic interests, much less in defense of blacks, immigrants and others cast off to starve in the streets or locked away in prison hellholes.
<G-vec00571-001-s311><cast.werfen><de> Dass diese Millionen nicht in der Aktion mobilisiert wurden, um dieses rassistische Komplott zu bekämpfen, ist die Verantwortung der prokapitalistischen Irreführer der Arbeiterklasse, die sich sogar davor fürchten, ihre Mitglieder zur Verteidigung ihrer ökonomischen Interessen aufzurufen, ganz zu schweigen von der Verteidigung von Schwarzen, Immigranten und anderen, die auf die Straße geworfen wurden, so dass sie verhungern, oder die in der Gefängnishölle eingeknastet sind.
<G-vec00571-001-s312><cast.werfen><en> "Finally, he moves from frustration to wrath when he is cast from heaven in a great battle and begins waging war against the ""rest of her offspring,"" a war which he appears to be winning (Rev 13)."
<G-vec00571-001-s312><cast.werfen><de> "Am Ende wandelt sich die Frustration in Zorn, als er in einem großen Kampf aus dem Himmel geworfen wird und Krieg gegen den ""Rest ihrer Nachkommenschaft"" beginnt, ein Krieg, der er zu gewinnen scheint (Offb 13)."
<G-vec00571-001-s313><cast.werfen><en> The king was helpless, and could do nothing but order that Daniel be cast into a den of lions, which was done.
<G-vec00571-001-s313><cast.werfen><de> Der König war hilflos und konnte nichts weiter tun, als anzuordnen, daß Daniel in die Löwengrube geworfen werden sollte, was auch geschah.
<G-vec00571-001-s314><cast.werfen><en> «Did I save them, that they might destroy me?» is «He saved others; he cannot save himself.» Only in two cases are there slight, yet meaningful distortions: «Alea iacta est(o)», «The die is cast», became «… casting (a net into the sea): for they were fishers» (confusion of lat.
<G-vec00571-001-s314><cast.werfen><de> Nur bei zwei sind die gleichwohl leichten Veränderungen sinnentstellend: «Alea iacta est(o)», der Würfel sei geworfen, wurde zu «werfend, denn sie waren Fischer» (Verwechselung von lat.
<G-vec00571-001-s315><cast.werfen><en> 24 And Pilate gave sentence that it should be as they required. 25 And he released unto them him that for sedition and murder was cast into prison, whom they had desired; but he delivered Jesus to their will.
<G-vec00571-001-s315><cast.werfen><de> 23:24 Pilatus aber urteilete, daß ihre Bitte geschähe, 23:25 und ließ den los, der um Aufruhrs und Mords willen war ins Gefängnis geworfen, um welchen sie baten; aber Jesum übergab er ihrem Willen.
<G-vec00571-001-s316><cast.werfen><en> 17 Of a truth, Jehovah, the kings of Assyria have laid waste the nations and their lands, 18 and have cast their gods into the fire; for they were no gods, but the work of men's hands, wood and stone; therefore they have destroyed them.
<G-vec00571-001-s316><cast.werfen><de> 17 Es ist wahr, Herr, die Könige von Assyrien haben die Völker und ihre Länder verwüstet 18 und haben ihre Götter ins Feuer geworfen; denn sie waren nicht Götter, sondern Werke von Menschenhand, Holz und Stein; darum haben sie sie verderbt.
<G-vec00571-001-s317><cast.werfen><en> 25 And he released to them him that for sedition and murder had been cast into prison, whom they had desired; but he delivered Jesus to their will.
<G-vec00571-001-s317><cast.werfen><de> 25 und ließ den los, der um Aufruhrs und Mords willen war ins Gefängnis geworfen, um welchen sie baten; aber JEsum übergab er ihrem Willen.
<G-vec00571-001-s318><cast.werfen><en> The caboclos use mainly the tarrafa (cast net), the arpão (a type of hand-thrown harpoon), rede, and special basket traps.
<G-vec00571-001-s318><cast.werfen><de> Der caboclo fängt überwiegend mit der tarrafa (Wurfnetz), dem arpão (eine Art Harpune, die mit der Hand geworfen wird), mit rede (Zugnetzen), und mit speziellen Fischreusen.
<G-vec00571-001-s319><cast.werfen><en> 2007-11-13 22:16:19 - The new heaven and new earth Now that Satan, all of his fallen angels and all of unsaved humanity have been cast into the Lake of Fire and Brimstone, there is only one thing left.
<G-vec00571-001-s319><cast.werfen><de> 2007-11-13 22:16:19 - Der neue Himmel und die neue Masse Nun da Satan, alle seine gefallenen Engel und die ganze unsaved Menschlichkeit in den See des Feuers und des Brimstone geworfen worden sind, gibt es nur eine Sache nach links.
<G-vec00571-001-s320><cast.werfen><en> In Italy and France, it was believed that the bugs living in the house expelled good dreams and cast nightmares, especially to children.
<G-vec00571-001-s320><cast.werfen><de> In Italien und Frankreich glaubte man, dass die im Haus lebenden Käfer gute Träume vertrieben und Albträume geworfen haben, besonders für Kinder.
<G-vec00571-001-s321><cast.werfen><en> 25 And he released unto them him who for murder and sedition, had been cast into prison, whom they had desired; but Jesus he delivered up to their will.
<G-vec00571-001-s321><cast.werfen><de> 25 und ließ den los, der um Aufruhrs und Mordes willen war ins Gefängnis geworfen, um welchen sie baten; aber Jesus übergab er ihrem Willen.
<G-vec00571-001-s322><cast.werfen><en> 27:35 And they crucified him, and parted his garments, casting lots: that it might be fulfilled which was spoken by the prophet, They parted my garments among them, and upon my vesture did they cast lots.
<G-vec00571-001-s322><cast.werfen><de> 27:35 Nachdem sie ihn nun gekreuzigt hatten, teilten sie seine Kleider unter sich und warfen das Los, auf daß erfüllt würde, was durch den Propheten gesagt ist: «Sie haben meine Kleider unter sich geteilt, und über mein Gewand haben sie das Los geworfen.» < 27:36 Und sie saßen daselbst und hüteten ihn.
<G-vec00571-001-s323><cast.gießen><en> The Chinese learned to smelt and cast iron as far back as 2,500 years ago, mastering iron casting some 2,000 years earlier than Europe- ans.
<G-vec00571-001-s323><cast.gießen><de> Die Chinesen lernten schon vor 2.500 Jahren, Eisen zu schmelzen und zu gießen – und somit den Eisen- guss 2.000 Jahre früher als die Europäer.
<G-vec00571-001-s324><cast.gießen><en> Afterwards, he had a bird cast in bronze as a trophy of his victory and endorsement of his declaration.
<G-vec00571-001-s324><cast.gießen><de> Danach ließ er einen solchen Vogel als Trophäe und Bekräftigung seiner Aussage in Bronze gießen.
<G-vec00571-001-s325><cast.gießen><en> If an attachment work is made of non-precious alloys, it is obvious to cast the secondary parts and the cast partial denture together in one piece – the so called one-piece cast. This process saves a lot of time and material.
<G-vec00571-001-s325><cast.gießen><de> Bei der Herstellung einer Geschiebearbeit aus einer EMF-Legierung bietet es sich „förmlich“ an, die Sekundärteile und den Modellguss in einem Stück – dem sogenannten „Einstückguss“ – zu gießen.
<G-vec00571-001-s326><cast.gießen><en> In it, students at Johannes Gutenberg University Mainz (JGU) and the University of Applied Sciences Mainz work together to cast lyrics in new forms.
<G-vec00571-001-s326><cast.gießen><de> Studenten der Johannes Gutenberg-Universität Mainz (JGU) und der Fachhochschule Mainz arbeiten hier zusammen, um Lyrik in neue Formen zu gießen.
<G-vec00571-001-s327><cast.gießen><en> Following various test runs, the manufacturing company decided to cast the columns, measuring 400 mm x 400 mm x 3,000 mm, in their standing position.
<G-vec00571-001-s327><cast.gießen><de> Der Produzent entschied nach verschiedenen Testläufen, die 400 mm x 400 mm x 3.000 mm messenden Pfeiler in aufrechter Position zu gießen.
<G-vec00571-001-s328><cast.gießen><en> 4:17 In the country near the Jordan did the king cast them, in a clay ground between Sochot and Saredatha.
<G-vec00571-001-s328><cast.gießen><de> 4:17 In der Gegend des Jordans ließ sie der König gießen in dicker Erde, zwischen Sukkoth und Zaredatha.
<G-vec00571-001-s329><cast.gießen><en> Suppliers of cast bronze and aluminum products.
<G-vec00571-001-s329><cast.gießen><de> Spezialisiert auf Schmelzen, Umformen und Gießen von Aluminium.
<G-vec00571-001-s330><cast.gießen><en> 26:37 And you shall make for the hanging five pillars of shittim wood, and overlay them with gold, and their hooks shall be of gold: and you shall cast five sockets of brass for them.
<G-vec00571-001-s330><cast.gießen><de> 26:37 Und sollst dem Tuch fünf Säulen machen von Akazienholz, mit Gold überzogen, mit goldene Haken, und sollst ihnen fünf eherne Füße gießen.
<G-vec00571-001-s331><cast.gießen><en> "However, the work has stirred in the population an awareness of its own history and so there is now a plan from the Town Council to cast the piece in cement and to install it permanently as a ""Streetball” court."
<G-vec00571-001-s331><cast.gießen><de> "Das Werk hat jedach in der Bevölkerung ein Bewußtsein für die eigene Historie bewirkt, und so gibt es nun einen Plan vom Magistrat der Stadt, die Arbeit in Beton zu gießen und als ""Streetball""-Feld dauerhaft zu installieren."
<G-vec00571-001-s332><cast.gießen><en> The copper was refined and cast in another oven.
<G-vec00571-001-s332><cast.gießen><de> Das Raffinieren und Gießen des Kupfers wurden in einem anderen Ofen durchgeführt.
<G-vec00571-001-s333><cast.gießen><en> Our team of experts has many years of experience in this industry as well as the required competencies to efficiently cast the requirements into concrete products.
<G-vec00571-001-s333><cast.gießen><de> Unser Team aus Experten verfügt hierbei über langjährige Erfahrung in der Branche sowie den geforderten Kompetenzen um effizient die Anforderungen in konkrete Produkte zu gießen.
<G-vec00571-001-s334><cast.gießen><en> Operation principle of our Vacuum Pressure Casting Machines INDUTHERM machines are suitable to melt and cast metals of high melting temperature.
<G-vec00571-001-s334><cast.gießen><de> Die INDUTHERM-Anlagen sind für das Schmelzen und Gießen von Edelmetallen mit hoher Schmelztemperatur ausgelegt.
<G-vec00571-001-s335><cast.gießen><en> Another comment I have heard several times is: 'And do they cast that, then?’ When I'm clearly carving the stone.
<G-vec00571-001-s335><cast.gießen><de> Noch eine Bemerkung Ich habe schon mehrmals gehört,: „Und sie gießen es über?’ Während ich hacken noch klar Stellung.
<G-vec00571-001-s336><cast.gießen><en> 46 In the plain of the Jordan did the king cast them, in the clay-ground between Succoth and Zaretan.
<G-vec00571-001-s336><cast.gießen><de> 46 In der Gegend des unteren Jordans ließ sie der König gießen in der Gießerei von Adama zwischen Sukkot und Zaretan.
<G-vec00571-001-s337><cast.gießen><en> From the received clay model take off the uniform, cast from plaster the necessary number of sockets and other elements of an ornament and strengthen on a wall.
<G-vec00571-001-s337><cast.gießen><de> Vom bekommenen tönernen Modell nehmen die Form ab, gießen aus dem Gips die nötige Zahl der Steckdosen und anderer Elemente des Ornaments und festigen an der Wand.
<G-vec00571-001-s338><cast.gießen><en> To cast a pig, molten iron was tapped from the opening in the furnace into a mold prepared in a bed of sand as you see in the picture above.
<G-vec00571-001-s338><cast.gießen><de> Um einen Roheisenbarren zu gießen, wird das geschmolzene Eisen nach dem Abstich in eine Gussform geleitet, die, wie auf dem Bild zu sehen ist, in einem Sandbett vorbereitet wurde.
<G-vec00571-001-s339><cast.gießen><en> 17 In the plain of the Jordan did the king cast them, in the clay-ground between Succoth and Zeredathah .
<G-vec00571-001-s339><cast.gießen><de> 17 In der Jordanebene ließ sie der König gießen in lehmiger Erde, zwischen Sukkot und Zeredata .
<G-vec00571-001-s340><cast.gießen><en> The necessary quantity of petals cast by means of the turned out form and attach on noted place.
<G-vec00571-001-s340><cast.gießen><de> Die nötige Zahl der Blumenblätter gießen mit Hilfe der sich ergebenden Form und befestigen auf die bemerkte Stelle.
<G-vec00571-001-s341><cast.gießen><en> We cast our concrete in moulds – this is how we can work with various formworks and achieve interesting surfaces.
<G-vec00571-001-s341><cast.gießen><de> Wir gießen unseren Beton in Formen – so können wir mit diversen Schalungsmaterialien arbeiten und entsprechend interessante Oberflächen erzielen.
<G-vec00571-001-s574><cast.werfen><en> 24:31 These likewise cast lots opposite to their brethren the sons of Aaron in the presence of David the king, and Zadok, and Ahimelech, and the chief of the fathers of the priests and Levites, even the principal fathers opposite to their younger brethren.
<G-vec00571-001-s574><cast.werfen><de> 24:31 Und man warf fÜr sie auch das Los neben ihren BrÜdern, den Kindern Aaron, vor dem König David und Zadok und Ahimelech und vor den Obersten der Vaterhäuser unter den Priestern und Leviten, fÜr den jÜngsten Bruder ebensowohl als fÜr den Obersten in den Vaterhäusern.
<G-vec00571-001-s575><cast.werfen><en> 27:5 And he cast down the pieces of silver in the temple, and departed, and went and hanged himself.
<G-vec00571-001-s575><cast.werfen><de> 27:5 Da warf er die Silberstücke in den Tempel; dann ging er weg und erhängte sich.
<G-vec00571-001-s576><cast.werfen><en> 10 Yet she became an exile; she went into captivity; her infants were dashed in pieces at the head of every street; for her honored men lots were cast, and all her great men were bound in chains.
<G-vec00571-001-s576><cast.werfen><de> 10 Dennoch verfiel auch sie der Verbannung, musste in die Gefangenschaft ziehen; auch ihre Kindlein wurden an allen Straßenecken zerschmettert; man warf über ihre Vor nehmen das Los, und alle ihre Großen wurden mit Ketten gefesselt.
<G-vec00571-001-s577><cast.werfen><en> 42 A poor widow came, and she cast in two small brass coins, {literally, lepta (or widow's mites).
<G-vec00571-001-s577><cast.werfen><de> 42 Doch dann kam eine arme Witwe und warf zwei kleine Kupfermünzen hinein (das entspricht ́etwa ` einem Groschen).
<G-vec00571-001-s578><cast.werfen><en> And it was so, when they came into the midst of the city, that Ishmael the son of Nethaniah slew them, and cast them into the midst of the pit, he, and the men that were with him.
<G-vec00571-001-s578><cast.werfen><de> Und es geschah, als sie in die Stadt hineingekommen waren, da schlachtete sie Ismael, der Sohn des Netanja, [und warf sie] in die Zisterne, er und die Männer, die mit ihm waren.
<G-vec00571-001-s579><cast.werfen><en> and Elijah came up to him and cast his mantle upon him.
<G-vec00571-001-s579><cast.werfen><de> Und Elia ging zu ihm und warf seinen Mantel über ihn.
<G-vec00571-001-s580><cast.werfen><en> 33 Then Saul cast the spear at him to smite him; and Jonathan knew that it was determined by his father to put David to death.
<G-vec00571-001-s580><cast.werfen><de> 33 Da warf (O. schwang) Saul den Speer nach ihm, um ihn zu treffen; und Jonathan erkannte, daß es von seiten seines Vaters beschlossen sei, David zu töten.
<G-vec00571-001-s581><cast.werfen><en> 23 And it happened, when Jehudi had read three or four columns, that the king cut it with the scribe's knife and cast it into the fire that was on the hearth, until all the scroll was consumed in the fire that was on the hearth.
<G-vec00571-001-s581><cast.werfen><de> 23 Als aber Judi drei oder vier Blatt gelesen hatte, zerschnitt er's mit einem Schreibmesser und warf es ins Feuer, das im Kaminherde war, bis das Buch ganz verbrannte im Feuer.
<G-vec00571-001-s582><cast.werfen><en> The city of Potosi, had technology to the mining work in the colony, an example is the Museum Cafe Restaurant Ingenio San Marcos, which illustrates the visitor on their way, the operation of such mills for the benefit of silver, where silver ore cast out, heading to the mint for coinage later.
<G-vec00571-001-s582><cast.werfen><de> Die Stadt Potosi hatten Technologie für die Bergbau-Arbeit in der Kolonie, ist ein Beispiel des Museums Cafe Restaurant Ingenio San Marcos, die dem Besucher zeigt auf ihrem Weg, das dem Betrieb dieser Mühlen zum Nutzen der Silber, wo Silbererz aus, warf Position in die Münze für Münze später.
<G-vec00571-001-s583><cast.werfen><en> A nightlight in the hallway cast ghastly shadows that quicken my core.
<G-vec00571-001-s583><cast.werfen><de> Ein Nachtlicht im Flur warf gruselige Schatten, die meinen Herzschlag beschleunigten.
<G-vec00571-001-s584><cast.werfen><en> And he cast it without fear.
<G-vec00571-001-s584><cast.werfen><de> Und er warf sie ohne Scheu.
<G-vec00571-001-s585><cast.werfen><en> 24 who, having received such a charge, cast them into the inner prison, and secured their feet to the stocks.
<G-vec00571-001-s585><cast.werfen><de> 24 Dieser warf sie auf solchen Befehl hin ins innere Gefängnis und schloss ihre Füße in den Block.
<G-vec00571-001-s586><cast.werfen><en> 3 and cast him into the abyss, and shut it and sealed it over him, that he should not any more deceive the nations until the thousand years were completed; after these things he must be loosed for a little time.
<G-vec00571-001-s586><cast.werfen><de> 3 Und warf ihn in den Abgrund und verschloß ihn und versiegelte oben darauf, daß er nicht verführen sollte die Heiden, bis daß vollendet würden tausend Jahre; und danach muss er los werden eine kleine Zeit.
<G-vec00571-001-s587><cast.werfen><en> It is like a grain of mustard [seed] which a man took and cast into his garden; and it grew and became a great tree, and the birds of heaven lodged in its branches.
<G-vec00571-001-s587><cast.werfen><de> Es ist einem Senfkorn gleich, welches ein Mensch nahm und warf's in seinen Garten; und es wuchs und ward ein großer Baum, und die Vögel des Himmels wohnten unter seinen Zweigen.
<G-vec00571-001-s588><cast.werfen><en> So he cast down his rod, and lo! it was an obvious serpent,
<G-vec00571-001-s588><cast.werfen><de> Da warf er seinen Stock hin, und sogleich war er eine deutliche Schlange.
<G-vec00571-001-s589><cast.werfen><en> 30:19 He hath cast me into the mire, and I am become like dust and ashes.
<G-vec00571-001-s589><cast.werfen><de> 30:19 Er warf mich in den Lehm, / sodass ich Staub und Asche gleiche.
<G-vec00571-001-s590><cast.werfen><en> 24:31 These likewise cast lots even as their brothers the sons of Aaron in the presence of David the king, and Zadok, and Ahimelech, and the heads of the fathers’ households of the priests and of the Levites; the fathers’ households of the chief even as those of his younger brother.
<G-vec00571-001-s590><cast.werfen><de> 24:31 Und man warf für sie auch das Los neben ihren Brüdern, den Kindern Aaron, vor dem Könige David und Zadok und Ahimelech und vor den obersten Vätern unter den Priestern und Leviten, dem kleinsten Bruder ebensowohl als dem Obersten unter den Vätern.
<G-vec00571-001-s591><cast.werfen><en> 6 and cast stones at David, and at all the servants of king David; and all the people and all the mighty men were on his right hand and on his left.
<G-vec00571-001-s591><cast.werfen><de> 6 und warf mit Steinen nach David und nach allen Knechten des Königs David; und alles Volk und alle Helden waren zu seiner Rechten und zu seiner Linken.
<G-vec00571-001-s592><cast.werfen><en> A poor widow came, and she cast in two small brass coins, {literally, lepta (or widow's mites).
<G-vec00571-001-s592><cast.werfen><de> Doch dann kam eine arme Witwe und warf zwei kleine Kupfermünzen hinein (das entspricht ´etwa` einem Groschen).
<G-vec00571-001-s593><cast.werfen><en> 17 They took Absalom and cast him into a deep pit in the forest and erected over him a very great heap of stones .
<G-vec00571-001-s593><cast.werfen><de> 18:17 Und sie nahmen Absalom und warfen ihn in den Wald in eine große Grube und legten einen sehr großen Haufen Steine auf ihn.
<G-vec00571-001-s594><cast.werfen><en> 16:23 And when they had laid many stripes upon them, they cast them into prison, charging the jailer to keep them safely.
<G-vec00571-001-s594><cast.werfen><de> 16:23 Und da sie sie wohl gestäupet hatten, warfen sie sie ins Gefängnis und geboten dem Kerkermeister, daß er sie wohl bewahrete.
<G-vec00571-001-s595><cast.werfen><en> 17 And they took Absalom, and cast him into a great pit in the wood, and raised a very great heap of stones upon him.
<G-vec00571-001-s595><cast.werfen><de> 17 Und sie nahmen Absalom und warfen ihn in eine große Grube im Walde, und errichteten über ihm einen sehr großen Haufen Steine.
<G-vec00571-001-s596><cast.werfen><en> 31 These likewise cast lots even as their brothers the sons of Aaron in the presence of David the king, Zadok, Ahimelech, and the heads of the fathers’ households of the priests and of the Levites; the fathers’ households of the chief even as those of his younger brother.
<G-vec00571-001-s596><cast.werfen><de> 1Ch 24:31 Auch sie warfen Lose, wie ihre Brüder, die Söhne Aarons, vor König David, vor Sadok und Achimelek sowie vor den Familienhäuptern der Priester und Leviten, die Familienhäupter ebenso wie ihre jüngeren Brüder.
<G-vec00571-001-s597><cast.werfen><en> 21 And it came to pass as they were burying a man, that behold, they saw the band, and they cast the man into the sepulchre of Elisha; and the man went [down], and touched the bones of Elisha, and he revived, and stood upon his feet.
<G-vec00571-001-s597><cast.werfen><de> 21 Und es geschah, als sie einen Mann begruben, siehe, da sahen sie die Streifschar, und sie warfen den Mann in das Grab Elisas; und als der Mann hineinkam und die Gebeine Elisas berührte, da wurde er lebendig und erhob sich auf seine Füße.
<G-vec00571-001-s598><cast.werfen><en> 1:11 In the day that you stood on the other side, in the day that strangers carried away his substance, and foreigners entered into his gates, and cast lots for Jerusalem, even you were like one of them.
<G-vec00571-001-s598><cast.werfen><de> 1:11 An dem Tage, da du gegenüber standest, an dem Tage, da Fremde sein Vermögen hinwegführten, und Ausländer zu seinen Toren einzogen und über Jerusalem das Los warfen, da warst auch du wie einer von ihnen.
<G-vec00571-001-s599><cast.werfen><en> Then for Zechariah his son, a wise counselor, they cast lots; and his lot came out northward.
<G-vec00571-001-s599><cast.werfen><de> Und sie warfen Lose für seinen Sohn Sekarja, der ein verständiger Ratgeber war; und sein Los kam heraus gegen Norden.
<G-vec00571-001-s600><cast.werfen><en> 9:26 But they were disobedient, and rebelled against thee, and cast thy law behind their backs, and slew thy prophets who testified against them to turn them to thee, and they wrought great provocations.
<G-vec00571-001-s600><cast.werfen><de> 9:26 Aber sie wurden widerspenstig und empörten sich gegen dich, und warfen dein Gesetz hinter ihren Rücken; und sie ermordeten deine Propheten, welche wider sie zeugten, um sie zu dir zurückzuführen; und sie verübten große Schmähungen.
<G-vec00571-001-s601><cast.werfen><en> 38:6 Then took they Jeremiah, and cast him into the dungeon of Malchiah the son of Hammelech, that was in the court of the prison: and they let down Jeremiah with cords.
<G-vec00571-001-s601><cast.werfen><de> 38:6 Da nahmen sie Jeremia und warfen ihn in die Grube Malchias, des Sohns Hamelechs, die am Vorhofe des Gefängnisses war, und ließen ihn an Seilen hinab in die Grube, da nicht Wasser, sondern Schlamm war.
<G-vec00571-001-s602><cast.werfen><en> We cast anchor at the mouth of the Ambracian Bay, or, as it is now, called, the Gulf of ARTA.
<G-vec00571-001-s602><cast.werfen><de> Wir warfen Anker an der Öffnung der Ambracian Bucht oder, wie sie jetzt ist, benannt, der Golf von ARTA.
<G-vec00571-001-s603><cast.werfen><en> So they cast, and now they were not able to draw it in because of the multitude of fish.
<G-vec00571-001-s603><cast.werfen><de> Da warfen sie es aus und konnten's nicht mehr ziehen wegen der Menge der Fische.
<G-vec00571-001-s604><cast.werfen><en> 26 “Nevertheless they were disobedient, and rebelled against you, cast your law behind their back, killed your prophets that testified against them to turn them again to you, and they committed awful blasphemies.
<G-vec00571-001-s604><cast.werfen><de> 26 Aber sie wurden ungehorsam und widerstrebten dir und warfen dein Gesetz hinter sich zurück und erwürgten deine Propheten, die ihnen zeugten, daß sie sollten sich zu dir bekehren, und taten große Lästerungen.
<G-vec00571-001-s605><cast.werfen><en> 24 H3947 And they took H7993 him, and cast H953 him into a pit: H953 and the pit H7386 was empty, H3808 there was no H4325 water in it.
<G-vec00571-001-s605><cast.werfen><de> 24 H3947 und nahmen H7993 ihn und warfen H953 ihn in die Grube H953; aber die Grube H7386 war leer H4325 und kein Wasser darin.
<G-vec00571-001-s606><cast.werfen><en> All heads, save Ethan's, turned and cast shocked looks at Giles's outburst.
<G-vec00571-001-s606><cast.werfen><de> Alle Köpfe außer Ethans drehten sich und warfen scharfe Blicke auf Giles wegen dessen plötzlichem Ausbruch.
<G-vec00571-001-s607><cast.werfen><en> And again he sent a third; and they, having wounded him also, cast [him] out.
<G-vec00571-001-s607><cast.werfen><de> Und er fuhr fort und sandte einen dritten; sie aber verwundeten auch diesen und warfen ihn hinaus.
<G-vec00571-001-s608><cast.werfen><en> And they caught him, and cast him out of the vineyard, and slew him.
<G-vec00571-001-s608><cast.werfen><de> Und sie nahmen ihn, warfen ihn zum Weinberg hinaus und töteten ihn.
<G-vec00571-001-s609><cast.werfen><en> Overturning these things, they cast them into the torrent Kidron.
<G-vec00571-001-s609><cast.werfen><de> Auch alle Räucheraltäre beseitigten sie, dann warfen sie sie in den Kidronbach.
<G-vec00571-001-s610><cast.werfen><en> When they cast a glance on the scooter, they will easily notice the logo and will regard this company is trend-following.
<G-vec00571-001-s610><cast.werfen><de> Als einen Blick auf die Roller warfen sie werden leicht feststellen, das Logo und betrachten dies Unternehmen ist Trendfolge-.
<G-vec00571-001-s611><cast.werfen><en> 8 And they cast lots, ward against ward, as well the small as the great, the teacher as the scholar.
<G-vec00571-001-s611><cast.werfen><de> 8 Und sie warfen Lose um [ihren] Dienst, der Kleine genauso wie der Große, der Meister mit dem Schüler.
<G-vec00571-001-s612><cast.werfen><en> 26 But he answered and said, It is not meet to take the children's bread, and to cast it to dogs.
<G-vec00571-001-s612><cast.werfen><de> 26 Aber er antwortete und sprach: Es ist nicht recht, daß man den Kindern ihr Brot nehme und werfe es vor die Hunde.
<G-vec00571-001-s613><cast.werfen><en> I cast my sedge and he grabs it without hesitation.
<G-vec00571-001-s613><cast.werfen><de> Ich werfe meine Sedge und die Äsche schluckt sie ohne zu zögern.
<G-vec00571-001-s614><cast.werfen><en> """Without effort, I cast God's light."
<G-vec00571-001-s614><cast.werfen><de> Völlig ohne Anstrengung werfe ich Gottes Licht aus.
<G-vec00571-001-s615><cast.werfen><en> While they clambered up the little construction, I took out the camera and cast a last glance at this sloping church and graveyard...
<G-vec00571-001-s615><cast.werfen><de> Währenddessen klettern sie in das kleine Gebäude und ich nehme meinen Fotoapparat heraus und werfe einen letzten Blick auf diese Kirche und diesen hügeligen Friedhof...
<G-vec00571-001-s616><cast.werfen><en> But Jesus said unto her, Let the children first be filled: for it is not meet to take the children's bread, and to cast it unto the dogs.
<G-vec00571-001-s616><cast.werfen><de> Jesus aber sprach zu ihr: LaÃ zuvor die Kinder satt werden; es ist nicht fein, daÃ man der Kinder Brot nehme und werfe es vor die Hunde.
<G-vec00571-001-s617><cast.werfen><en> 7 So when they continued asking him, he raised himself, and said to them, He that is without sin among you, let him first cast a stone at her.
<G-vec00571-001-s617><cast.werfen><de> 7 Als sie nun anhielten, ihn zu fragen, richtete er sich auf und sprach zu ihnen: Wer unter euch ohne Sünde ist, der werfe den ersten Stein auf sie.
<G-vec00571-001-s618><cast.werfen><en> 27 But Jesus said to her, Let the children first be satisfied: for it is not meet to take the children's bread, and to cast it to the dogs.
<G-vec00571-001-s618><cast.werfen><de> 27 Jesus aber sprach zu ihr: Laß zuvor die Kinder satt werden; es ist nicht fein, daß man der Kinder Brot nehme und werfe es vor die Hunde.
<G-vec00571-001-s619><cast.werfen><en> The Biblical passage “Let him who is without sin cast the first stone” may be cited here. Regardless, Luis Trenker was a man of inspiring energy, who with his stories and movies about life in the mountains captivated almost the whole world.
<G-vec00571-001-s619><cast.werfen><de> Hier sei das Bibelwort zitiert: „Wer ohne Schuld ist werfe den ersten Stein!“ Unabhängig davon war Luis Trenker ein Mensch voll begeisternder Energie, der mit seinen Erzählungen und Filmen vom Leben in den Bergen fast die ganze Welt in seinen Bann zog.
<G-vec00571-001-s620><cast.werfen><en> 58 When thou goest with thine adversary to the magistrate, as thou art in the way, give diligence that thou mayest be delivered from him; lest he hale thee to the judge, and the judge deliver thee to the officer, and the officer cast thee into prison.
<G-vec00571-001-s620><cast.werfen><de> 58 Denn wenn du mit deinem Gegner zum Gericht gehst, so bemühe dich auf dem Wege, von ihm loszukommen, damit er nicht etwa dich vor den Richter ziehe, und der Richter überantworte dich dem Gerichtsdiener, und der Gerichtsdiener werfe dich ins Gefängnis.
<G-vec00571-001-s621><cast.werfen><en> But Jesus said unto her, Let the children first be filled: for it is not meet to take the children’s bread, and to cast it unto the dogs.
<G-vec00571-001-s621><cast.werfen><de> Jesus aber sprach zu ihr: Laß zuvor die Kinder satt werden; es ist nicht fein, daß man der Kinder Brot nehme und werfe es vor die Hunde.
<G-vec00571-001-s622><cast.werfen><en> 26 Who answering, said: It is not good to take the bread of the children, and to cast it to the dogs.
<G-vec00571-001-s622><cast.werfen><de> 26 Aber er antwortete und sprach: Es ist nicht fein, daß man den Kindern ihr Brot nehme und werfe es vor die Hunde.
<G-vec00571-001-s623><cast.werfen><en> 22 Behold, I cast her into a bed, and those that commit adultery with her into great tribulation, unless they repent of her works,
<G-vec00571-001-s623><cast.werfen><de> 22 Siehe, ich werfe sie in ein Bett und die, welche Ehebruch mit ihr treiben, in große Drangsal, wenn sie nicht Buße tun von ihren Werken.
<G-vec00571-001-s624><cast.werfen><en> Those who are envious and mischievous, who are the lowest among men, I perpetually cast into the ocean of material existence, into various demoniac species of life.
<G-vec00571-001-s624><cast.werfen><de> Die Neidischen und Boshaften, die Niedrigsten unter den Menschen, werfe Ich unaufhörlich in den Ozean des materiellen Daseins, in die verschiedenen dämonischen Arten des Lebens.
<G-vec00571-001-s625><cast.werfen><en> 2:22 Behold, I will cast her into a bed, and them that commit adultery with her into great tribulation, except they repent of their deeds.
<G-vec00571-001-s625><cast.werfen><de> 2:22 Siehe, ich werfe sie auf ein Bett und die, welche mit ihr ehebrechen, in große Trübsal, wenn sie nicht Buße tun von ihren Werken.
<G-vec00571-001-s626><cast.werfen><en> 2:24 But to you I say, the rest who [are] in Thyatira, as many as have not this doctrine, who have not known the depths of Satan, as they say, I do not cast upon you any other burden; 2:25 but what ye have hold fast till I shall come.
<G-vec00571-001-s626><cast.werfen><de> 24 Euch aber sage ich, den übrigen in Thyatira, allen, die diese Lehre nicht haben, welche die Tiefen des Satans, wie sie es nennen, nicht erkannt haben: Ich werfe keine andere Last auf euch; 25 doch was ihr habt, haltet fest, bis ich komme.
<G-vec00571-001-s627><cast.werfen><en> When thou goest with thine adversary to the magistrate, as thou art in the way, give diligence that thou mayest be delivered from him; lest he hale thee to the judge, and the judge deliver thee to the officer, and the officer cast thee into prison.
<G-vec00571-001-s627><cast.werfen><de> So du aber mit deinem Widersacher vor den Fürsten gehst, so tu Fleiß auf dem Wege, das du ihn los werdest, auf daß er nicht etwa dich vor den Richter ziehe, und der Richter überantworte dich dem Stockmeister, und der Stockmeister werfe dich ins Gefängnis.
<G-vec00571-001-s628><cast.werfen><en> And when the men were risen up, to go to mark out the land, Josue commanded them, saying: Go round the land and mark it out, and return to me: that I may cast lots for you before the Lord in Silo.
<G-vec00571-001-s628><cast.werfen><de> Da machten sich die Männer auf, daß sie hingingen; und Josua gebot ihnen, da sie hin wollten gehen, das Land aufzuschreiben, und sprach: Gehet hin und durchwandelt das Land und schreibt es auf und kommt wieder zu mir, daß ich euch hier das Los werfe vor dem HERRN zu Silo.
<G-vec00571-001-s629><cast.werfen><en> 7 But when they continued asking him, he lifted himself up and said to them, Let him that is without sin among you first cast the stone at her.
<G-vec00571-001-s629><cast.werfen><de> 7 Als sie aber fortfuhren, ihn zu fragen, richtete er sich auf und sprach zu ihnen: Wer von euch ohne Sünde ist, werfe als erster einen Stein auf sie.
<G-vec00571-001-s631><cast.werfen><en> So when you see a vase Medicis cast on a property, you think it is an ancient pot, while often it is only a matter of reproduction.
<G-vec00571-001-s631><cast.werfen><de> Also, wenn Sie eine Vase sehen Medicis auf einem Grundstück werfen, denken Sie, es ist ein alter Topf, während es oft nur eine Frage der Reproduktion ist.
<G-vec00571-001-s632><cast.werfen><en> The reproach which he has endeavored to cast upon Jehovah rests wholly upon himself.
<G-vec00571-001-s632><cast.werfen><de> Der Vorwurf, den er auf Jehovah zu werfen suchte, ruht völlig auf ihm selbst.
<G-vec00571-001-s633><cast.werfen><en> ★ Supports casting picture(including .gif) from any website, just long press on the picture, select a device to cast.
<G-vec00571-001-s633><cast.werfen><de> ★ Unterstützt Casting Bild(einschließlich .gif) von jeder Website, nur so lange drücken Sie auf das Bild, wählen, eine Vorrichtung zu werfen.
<G-vec00571-001-s634><cast.werfen><en> Just press play button, select your device to cast and enjoy your content.
<G-vec00571-001-s634><cast.werfen><de> Drücken Sie einfach auf Play-Taste, wählen Sie Ihr Gerät zu werfen und genießen Sie Ihre Inhalte.
<G-vec00571-001-s635><cast.werfen><en> Anything that could cast a shadow is excluded.
<G-vec00571-001-s635><cast.werfen><de> Alles was einen Schatten werfen könnte ist ausgeschlossen.
<G-vec00571-001-s636><cast.werfen><en> In fly-casting, the first thing is to learn how to get the rod to cast the weight of fly.
<G-vec00571-001-s636><cast.werfen><de> Im Fliegengußteil ist die erste Sache, zu erlernen, wie man die Stange erhält, um das Gewicht der Fliege zu werfen.
<G-vec00571-001-s637><cast.werfen><en> Objects with a spiritual colour do not cast a shadow: In the gross colours a single colour has various shades from faint to dark.
<G-vec00571-001-s637><cast.werfen><de> Gegenstände mit feinstofflicher Farbe werfen keine Schatten: In der grobstofflichen Welt hat eine Farbe verschiedene Schattierungen, von hell bis dunkel.
<G-vec00571-001-s638><cast.werfen><en> Each hand is basically cast a dart, they vote in numbers is the game of numbers.
<G-vec00571-001-s638><cast.werfen><de> Grundsätzlich jeder Spieler beginnt durch das Werfen der Abnäher und die Nummer, die sie getroffen wird ihre Zahl für das Spiel.
<G-vec00571-001-s639><cast.werfen><en> He climbed up the roof to cast a huge chunk of rock upon Muhammad.
<G-vec00571-001-s639><cast.werfen><de> Er stieg auf das Dach, um einen großen Steinbrocken auf Muhammad zu werfen.
<G-vec00571-001-s640><cast.werfen><en> "But now we suggest you first to cast a glance on the Site ""Virtual show"""
<G-vec00571-001-s640><cast.werfen><de> "Aber jetzt empfehlen wir Ihnen erst einmal den Blick auf unsere Seite ""virtueller Rundgang"" zu werfen."
<G-vec00571-001-s641><cast.werfen><en> Approximately 35,000 different anglers and boaters cast nearly 650,000 votes to support their favorite fishing and boating locations.
<G-vec00571-001-s641><cast.werfen><de> Etwa 35,000 verschiedene Angler und Segler werfen fast 650,000 Stimmen ihre Lieblings Angeln und Bootfahren Standorten zu unterstützen.
<G-vec00571-001-s642><cast.werfen><en> A small shadow cast by fruit trees and shrubs will not be a hindrance.
<G-vec00571-001-s642><cast.werfen><de> Ein kleiner Schatten werfen von Obstbäumen und Sträuchern wird kein Hindernis sein.
<G-vec00571-001-s643><cast.werfen><en> 9 Now the pit in which Ishmael cast all the dead bodies of the men whom he had killed, by the side of Gedaliah (the same was who which Asa the king had made for fear of Baasha king of Israel), Ishmael the son of Nethaniah filled it with those who were killed.
<G-vec00571-001-s643><cast.werfen><de> 9 Doch die Zisterne, in die Ismael die Leichen aller dieser Männer werfen ließ, die er um des Gedalja willen hat erschlagen, war die Zisterne, die der König Asa gen Baësa, Israels König, einst gegraben hatte.
<G-vec00571-001-s644><cast.werfen><en> The sun is set and low clouds in the west cast long shadows into the twilight sky.
<G-vec00571-001-s644><cast.werfen><de> Die Sonne ist untergegangen und tiefstehende Wolken im Westen werfen lange Schatten in den Dämmerungshimmel.
<G-vec00571-001-s645><cast.werfen><en> Other observations are needed to cast more light on this question.
<G-vec00571-001-s645><cast.werfen><de> Andere Beobachtungen werden gebraucht, um mehr Licht auf diese Frage zu werfen.
<G-vec00571-001-s646><cast.werfen><en> There is so little actual footage, that this could cast suspicion upon the content of Sonic Advance...which was actually a nice solid platformer for the GBA.
<G-vec00571-001-s646><cast.werfen><de> Es gibt so wenig tatsächliche Gesamtlänge, diese dieses könnte Misstrauen nach dem Inhalt des Sonic Fortschritts werfen…, der wirklich ein nettes festes platformer für das GBA war.
<G-vec00571-001-s647><cast.werfen><en> Others, though, cast the latest revisions in a more radical light.
<G-vec00571-001-s647><cast.werfen><de> Andere, obwohl, werfen die jüngsten Revisionen in einer radikaleren Licht.
<G-vec00571-001-s648><cast.werfen><en> Ex 1, 22 And Pharaoh charged all his people, saying, Every son that is born all of you shall cast into the river, and every daughter all of you shall keep alive.
<G-vec00571-001-s648><cast.werfen><de> Ex 1, 22 Da gebot der Pharao all seinem Volke und sprach: Jeden Sohn, der geboren wird, sollt ihr in den Strom werfen, jede Tochter aber sollt ihr leben lassen.
<G-vec00571-001-s649><cast.werfen><en> "Na'ilah replied with fury, ""You are wrong, and are laying a false blame. Before uttering anything about my father you should have cast a glance on the features of your father."
<G-vec00571-001-s649><cast.werfen><de> "Naila antwortete zornig: ""Du hast Unrecht und äußerst eine falsche Beschuldigung.Bevor du irgendetwas über meinen Vater sagst, solltest du vielleicht mal einen Blick auf die Eigenschaften deines Vaters werfen."
<G-vec00571-001-s650><cast.werfen><en> 22 Cast thy burden upon the LORD, and he shall sustain thee: he shall never suffer the righteous to be moved.
<G-vec00571-001-s650><cast.werfen><de> 22 Wirf dein Anliegen auf den HERRN; der wird dich versorgen und wird den Gerechten nicht ewiglich in Unruhe lassen.
<G-vec00571-001-s651><cast.werfen><en> 9 And if your eye causes you to sin, pluck it out and cast it from you.
<G-vec00571-001-s651><cast.werfen><de> 9 Und wenn dich dein Auge zum Abfall verführt, reiß es aus und wirf's von dir.
<G-vec00571-001-s652><cast.werfen><en> The ship cast off and after 40 minutes we were on the spot, near a lovely beach.
<G-vec00571-001-s652><cast.werfen><de> Das Schiff ab und wirf wir nach 40 Minuten an Ort und Stelle waren, nahe einem schönen Strand.
<G-vec00571-001-s653><cast.werfen><en> "Jesus said to him, ""Therefore the sons are exempt. 27 But, lest we cause them to stumble, go to the sea, and cast a hook, and take up the first fish that comes up. When you have opened its mouth, you will find a stater coin. Take that, and give it to them for me and you."""
<G-vec00571-001-s653><cast.werfen><de> 27 Auf daß aber wir sie nicht ärgern, so gehe hin an das Meer und wirf die Angel, und den ersten Fisch, der herauffährt, den nimm; und wenn du seinen Mund auftust, wirst du einen Stater finden; den nimm und gib ihnen für mich und dich.
<G-vec00571-001-s654><cast.werfen><en> 1 Cast your bread on the waters;for you shall find it after many days.
<G-vec00571-001-s654><cast.werfen><de> 1 Wirf dein Brot hin auf die Fläche der Wasser, denn nach vielen Tagen wirst du es finden.
<G-vec00571-001-s655><cast.werfen><en> """ 9 Lk 4, 9 And he brought him to Jerusalem, and he set him on the parapet of the temple, and he said to him: ""If you are the Son of God, cast yourself down from here. 10 Lk 4, 10 For it is written that he has given his Angels charge over you, so that they may guard you, 11 Lk 4, 11 and so that they may take you into their hands, lest perhaps you may hurt your foot against a stone."""
<G-vec00571-001-s655><cast.werfen><de> "9 Lk 4, 9 Und er führte ihn nach Jerusalem und stellte ihn auf die Zinne des Tempels und sprach zu ihm: Wenn du Gottes Sohn bist, so wirf dich von hier hinab; 10 Lk 4, 10 denn es steht geschrieben: ""Er wird seinen Engeln über dir befehlen, daß sie dich bewahren; 11 Lk 4, 11 und sie werden dich auf den Händen tragen, damit du nicht etwa deinen Fuß an einen Stein stoßest""."
<G-vec00571-001-s656><cast.werfen><en> So now take him, and cast him into the field, according to the word of the Lord.
<G-vec00571-001-s656><cast.werfen><de> So nimm nun und wirf ihn auf den Acker nach dem Wort des HERRN.
<G-vec00571-001-s657><cast.werfen><en> So if your hand or your foot leads you to sin, cut it off and cast it away from you.
<G-vec00571-001-s657><cast.werfen><de> Wenn aber deine Hand oder dein Fuß dich ärgert, so haue ihn ab und wirf ihn von dir.
<G-vec00571-001-s658><cast.werfen><en> Cast your burden on the Lord, and He shall sustain you: He shall never suffer the righteous to be moved.... but if we sincerely want to follow God, whatever the difficulties may be, He promises that He will never forsake us.
<G-vec00571-001-s658><cast.werfen><de> Wirf dein Anliegen auf den HERRN; der wird dich versorgen und wird den Gerechten in Ewigkeit nicht wanken lassen.... aber wenn wir aufrichtig Gott folgen wollen, egal welche Schwierigkeiten auch auftauchen, dann verspricht er, uns niemals zu vergessen.
<G-vec00571-001-s660><cast.werfen><en> Cast your eye on it, and all that you like will multiply itself.
<G-vec00571-001-s660><cast.werfen><de> Wirf dein Auge auf sie, und alles, was du magst, wird sich von alleine vermehren.
<G-vec00571-001-s661><cast.werfen><en> "21 So Jesus answered and said to them, ""Assuredly, I say to you, if you have faith and do not doubt, you will not only do what was done to the fig tree, but also if you say to this mountain, 'Be removed and be cast into the sea,' it will be done."
<G-vec00571-001-s661><cast.werfen><de> 21 Jesus aber antwortete und sprach zu ihnen: Wahrlich, ich sage euch: Wenn ihr Glauben habt und nicht zweifelt, so werdet ihr nicht allein Taten wie die mit dem Feigenbaum tun, sondern, wenn ihr zu diesem Berge sagt: Heb dich und wirf dich ins Mee r, so wird's geschehen.
<G-vec00571-001-s662><cast.werfen><en> "Cast Yourself down and everybody will say: ""This is something very wonderful!"", and You will have all the people in Jerusalem rushing to You."
<G-vec00571-001-s662><cast.werfen><de> Wirf dich hinunter, und jedermann wird sagen: «Das ist etwas äußerst Wunderbares!», und alle Leute in Jerusalem werden zu dir herauseilen.
<G-vec00571-001-s663><cast.werfen><en> Psalms 55:22 Cast thy burden upon the LORD, and he shall sustain thee: he shall never suffer the righteous to be moved.
<G-vec00571-001-s663><cast.werfen><de> Psalter 55:22 Wirf dein Anliegen auf den HERRN; der wird dich versorgen und wird den Gerechten in Ewigkeit nicht wanken lassen.
<G-vec00571-001-s664><cast.werfen><en> Jesus saith unto him, Then are the children free. Notwithstanding, lest we should offend them, go thou to the sea, and cast an hook, and take up the fish that first cometh up; and when thou hast opened his mouth, thou shalt find a piece of money: that take, and give unto them for me and thee.
<G-vec00571-001-s664><cast.werfen><de> Auf dass aber wir sie nicht aergern, so gehe hin an das Meer und wirf die Angel, und den ersten Fisch, der herauffaehrt, den nimm; und wenn du seinen Mund auftust, wirst du einen Stater finden; den nimm und gib ihnen für mich und dich.
<G-vec00571-001-s665><cast.werfen><en> 9 “When Pharaoh will say to you, ‘Show signs,’ you shall say to Aaron, ‘Take your staff, and cast it down before Pharaoh, and it will be turned into a snake.’ ”
<G-vec00571-001-s665><cast.werfen><de> 9 Wenn Pharao zu euch sagen wird: Beweist eure Wunder, so sollst du zu Aaron sagen: Nimm deinen Stab und wirf ihn vor Pharao, daß er zur Schlange werde.
<G-vec00571-001-s666><cast.werfen><en> """If your right eye to sin and cast it from you: fact you should lose one of your members, rather than your whole body be thrown into hell."
<G-vec00571-001-s666><cast.werfen><de> """Wenn Sie das rechte Auge zur Sünde und wirf es von dir: Tatsächlich sollten Sie eines deiner Glieder verloren, und nicht dein ganzer Leib in die Hölle geworfen werden."
<G-vec00571-001-s667><cast.werfen><en> Cast out the bondwoman and her son: for the son of the bondwoman shall not be heir with the son of the freewoman.
<G-vec00571-001-s667><cast.werfen><de> Wirf die Magd und ihren Sohn: der Sohn der Magd soll nicht erben mit dem Sohn des Freien.
<G-vec00571-001-s668><cast.werfen><en> "27 Nevertheless, lest we offend them, go to the sea, cast in a hook, and take the fish that comes up first. And when you have opened its mouth, you will find a piece of money; take that and give it to them for Me and you. """
<G-vec00571-001-s668><cast.werfen><de> 27 Damit wir ihnen aber keinen Anstoß geben, geh hin an den See und wirf die Angel aus, und den ersten Fisch, der heraufkommt, den nimm; und wenn du sein Maul aufmachst, wirst du ein Zweigroschenstück finden; das nimm und gib's ihnen für mich und dich.
<G-vec00571-001-s669><cast.werfen><en> In certain cultures, where one can’t even pronounce or remember a foreign name (you need to be exposed to a language before you can memorize the names; this is why Taiwanese or other friends will often do us the exaggerated favour of choosing western names for themselves to make it easier for us to identify them…), the translator will cast a big shadow over the author and “possess” him/her in a way.
<G-vec00571-001-s669><cast.werfen><de> In bestimmten Kulturen, in denen ein fremder Name weder aussprechbar noch erinnerbar ist (man muss einer Sprache ausgesetzt sein, ehe man sich die Namen einprägt; deshalb tun uns TaiwanesInnen oder andere FreundInnen oft den übertriebenen Gefallen, sich westliche Namen zu geben, um uns die Identifikation zu erleichtern …), wirft die ÜbersetzerIn einen großen Schatten auf die AutorIn und nimmt sie/ihn in gewisser Weise „in Besitz“.
<G-vec00571-001-s670><cast.werfen><en> 6 If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00571-001-s670><cast.werfen><de> 6 Wenn ein Mann nicht in mir bleibt, der wird weggeworfen wie eine Rebe und verdorrt, und man sammelt sie und wirft sie ins Feuer, und sie sind verbrannt.
<G-vec00571-001-s671><cast.werfen><en> This forgetting is a dark shadow cast by plenty, a nightmare for some that constructs misinformation and fear about insanity, violence and victims.
<G-vec00571-001-s671><cast.werfen><de> Dieses Vergessen wirft einen dunklen Schatten, ein Alptraum für manche, aus dem Falschinformation und Angst vor dem Wahnsinn, der Gewalt und den Opfern entstehen.
<G-vec00571-001-s672><cast.werfen><en> The stresses of life also cast you in the direction of the pleasures of life, as well as its mysteries.
<G-vec00571-001-s672><cast.werfen><de> Der Stress des Lebens wirft Dich auch in die Richtung der Vergnügungen des Lebens, wie auch seiner Geheimnisse.
<G-vec00571-001-s673><cast.werfen><en> "6 ""If anyone does not abide in Me, he is thrown away as a branch and dries up; and they gather them, and cast them into the fire and they are burned."
<G-vec00571-001-s673><cast.werfen><de> 6Wenn jemand nicht in mir bleibt, so wird er weggeworfen wie das Rebschoß und verdorrt; und solche sammelt man und wirft sie ins Feuer, und sie brennen.
<G-vec00571-001-s674><cast.werfen><en> At the same time, light is cast on the Ed Ruscha's own work, and the thinking and decisions that lie behind it.
<G-vec00571-001-s674><cast.werfen><de> Gleichzeitig wirft die Präsentation Licht auf Ed Ruschas eigenes Schaffen sowie die ihm zugrundeliegenden Gedanken und Entscheidungen.
<G-vec00571-001-s675><cast.werfen><en> When a finger or an object touches the screen, multiple shadows are cast out at different angles.
<G-vec00571-001-s675><cast.werfen><de> Sobald ein Finger oder ein Gegenstand den Bildschirm berührt, wirft er mehrere Schatten in verschiedene Richtungen.
<G-vec00571-001-s676><cast.werfen><en> Her bed and her dining-room table were her studio; the shadows that the lamp cast on the paper and canvases showed her the way.
<G-vec00571-001-s676><cast.werfen><de> Das Bett und der Esstisch sind ihr Studio, die Schatten, die das flackernde Licht der Lampe auf das Papier und die Leinwände wirft, weisen ihr den Weg.
<G-vec00571-001-s677><cast.werfen><en> For it does not cast its light downwards in one single bundled ray – as could be expected – but very gently through the fine slits at the bottom of the luminaire body, too.
<G-vec00571-001-s677><cast.werfen><de> Denn sie wirft ihr Licht nicht – wie es den Eindruck haben könnte – in einem einzigen gebündelten Strahl nach unten, sondern ganz sanft auch durch die feinen Schlitze am unteren Ende des Leuchtenkörpers.
<G-vec00571-001-s678><cast.werfen><en> He declared that God does not cast anyone into hell.
<G-vec00571-001-s678><cast.werfen><de> Er sagte, dass Gott niemanden in die Hölle wirft.
<G-vec00571-001-s679><cast.werfen><en> It arises out of the observation of the imperfections which appear in the shadow cast by a finiteˆ universeˆ of things and beings as such a cosmos obscures the living light of the universal expression of the eternalˆ realities of the Infinite One.
<G-vec00571-001-s679><cast.werfen><de> Er geht aus der Beobachtung der Unvollkommenheiten hervor, die im Schatten, den ein endliches Universum von Dingen und Wesen wirft, auftreten; denn ein solcher Kosmos verdunkelt das lebendige Licht des universalen Ausdrucks der ewigen Realitäten des Unendlichen Einen.
<G-vec00571-001-s680><cast.werfen><en> It wants to dilute the population of Europe and to replace it, to cast aside our culture, our way of life and everything which separates and distinguishes us Europeans from the other peoples of the world.
<G-vec00571-001-s680><cast.werfen><de> Es will die Bevölkerung Europas verdünnen, will sie austauschen, Brüssel wirft unsere Kultur, unsere Lebensform und alles das, was uns Europäer von den anderen Völkern der Welt unterscheidet, ihnen vor die Füße.
<G-vec00571-001-s681><cast.werfen><en> < 15:6 If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00571-001-s681><cast.werfen><de> < 15:6 Wenn jemand nicht in mir bleibt, so wird er weggeworfen wie das Rebschoß und verdorrt; und solche sammelt man und wirft sie ins Feuer, und sie brennen.
<G-vec00571-001-s682><cast.werfen><en> Your talent should be lit by the third light in such a manner so there is no shadow cast upon the background.
<G-vec00571-001-s682><cast.werfen><de> Dein Darsteller sollte von der dritten Leuchte so beleuchtet werden, dass er keinen Schatten auf den Hintergrund wirft.
<G-vec00571-001-s683><cast.werfen><en> "General Izquierdo apparently concluded that ""the International has spread its black wings to cast its nefarious shadow over the most remote lands."""
<G-vec00571-001-s683><cast.werfen><de> Benedict Anderson zufolge meinte der damalige Gouverneur der Philippinen, General Izquierdos, dass »die Internationale ihre schwarzen Flügel ausgebreitet hat und ihre schändlichen Schatten über die abgelegensten Länder wirft«.
<G-vec00571-001-s684><cast.werfen><en> Left with only a decaying infrastructure, the effects of the autocratic regime lasting from 1946 until 1989 still cast their long shadow over the Romanian countryside.
<G-vec00571-001-s684><cast.werfen><de> Das von 1946 bis 1989 herrschende autokratische Regime hat lediglich eine zerfallende Infrastruktur hinterlassen und wirft nach wie vor dunkle Schatten über das Land.
<G-vec00571-001-s685><cast.werfen><en> When the new ruling class has ensured power and disarmed the proletariat and its allies, then they cast their old skin that is not any longer needed to oppress and exploit the proletariat openly and lead the counter-revolution brutally against the resistance of the workers, peasants and soldiers.
<G-vec00571-001-s685><cast.werfen><de> Hat dann die neue herrschende Sozialbourgeoisie ihre Macht gesichert und das Proletariat und seine Verbündeten entmachtet, wirft sie die unbrauchbar gewordene, alte Haut ab und richtet ganz offen ihre Organe der Klassenherrschaft gegen den Widerstand der Arbeiter und anderer Werktätigen, zerstört sie schrittweise die sozialistischen Errungenschaften und verbreitet bürgerliches Bewusstsein in der Arbeiterklasse.
<G-vec00571-001-s686><cast.werfen><en> Jn 15:6 - If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00571-001-s686><cast.werfen><de> Jn 15:6 - Wenn jemand nicht in mir bleibt, so wird er hinausgeworfen wie die Rebe und verdorrt; und man sammelt sie und wirft sie ins Feuer, und sie verbrennen.
<G-vec00571-001-s687><cast.werfen><en> Aplomb LED is opened at both ends with the result that its warm white light is stylishly cast up and down onto the wall.
<G-vec00571-001-s687><cast.werfen><de> Aplomb LED ist nach oben und unten geöffnet, wodurch ihr warmweißes Licht ein stilvolles Up- und Downlight an die Wand wirft.
<G-vec00819-002-s488><cast.hinauswerfen><en> John 15:6: If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00819-002-s488><cast.hinauswerfen><de> 6 Wenn jemand nicht in mir bleibt, so wird er hinausgeworfen wie die Rebe und verdorrt4; und man sammelt sie und wirft sie ins FeuerFeuer, und sie verbrennen.
<G-vec00819-002-s489><cast.hinauswerfen><en> 19 He shall be buried with the burial of an ass, rotten and cast forth without the gates of Jerusalem.
<G-vec00819-002-s489><cast.hinauswerfen><de> 19Er soll wie ein Esel begraben werden, fortgeschleift und hinausgeworfen vor die Tore Jerusalems.
<G-vec00819-002-s490><cast.hinauswerfen><en> 19 He shall be buried with the burial of an ass, rotten and cast forth without the gates of Jerusalem.
<G-vec00819-002-s490><cast.hinauswerfen><de> 19 Er soll wie ein Esel begraben werden, zerschleift und hinausgeworfen vor die Tore Jerusalems.
<G-vec00819-002-s491><cast.hinauswerfen><en> The sons of the kingdom will be cast out into the outer darkness; in that place there will be weeping and gnashing of teeth.
<G-vec00819-002-s491><cast.hinauswerfen><de> Aber die Söhne des Reiches werden hinausgeworfen werden in die äußere Finsternis: da wird das Weinen und das Zähneknirschen sein.
<G-vec00819-002-s492><cast.hinauswerfen><en> It is then good for nothing, but to be cast out and trodden under the feet of men.
<G-vec00819-002-s492><cast.hinauswerfen><de> Es taugt zu nichts mehr, als hinausgeworfen und von den Menschen zertreten zu werden.
<G-vec00819-002-s493><cast.hinauswerfen><en> 28There shall be the weeping and the gnashing of teeth, when ye shall see Abraham and Isaac and Jacob and all the prophets in the kingdom of God, but yourselves cast out.
<G-vec00819-002-s493><cast.hinauswerfen><de> 28Da wird sein das Weinen und das Zähneknirschen, wenn ihr sehen werdet Abraham und Isaak und Jakob und alle Propheten im Reiche Gottes, euch aber draußen hinausgeworfen.
<G-vec00819-002-s494><cast.hinauswerfen><en> And having cast him forth out of the vineyard, they killed [him].
<G-vec00819-002-s494><cast.hinauswerfen><de> Und als sie ihn aus dem Weinberg hinausgeworfen hatten, töteten sie ihn.
<G-vec00819-002-s495><cast.hinauswerfen><en> 31 (CPDV) Now is the judgment of the world. Now will the prince of this world be cast out.
<G-vec00819-002-s495><cast.hinauswerfen><de> 31 (ELB) Jetzt ist das Gericht dieser Welt; jetzt wird der Fürst dieser Welt hinausgeworfen werden.
<G-vec00819-002-s496><cast.hinauswerfen><en> It is then good for nothing, but to be cast out and trodden under the feet of men.
<G-vec00819-002-s496><cast.hinauswerfen><de> Es taugt zu nichts mehr, als dass es hinausgeworfen und von den Leuten zertreten wird.
<G-vec00819-002-s498><cast.hinauswerfen><en> 9 And that great dragon was cast out, that old serpent, who is called the devil and Satan, who seduceth the whole world; and he was cast unto the earth, and his angels were thrown down with him.
<G-vec00819-002-s498><cast.hinauswerfen><de> 9Und es wurde hinausgeworfen der große Drache, die alte Schlange, die da heißt: Teufel und Satan, der die ganze Welt verführt, und er wurde auf die Erde geworfen, und seine Engel wurden mit ihm dahin geworfen.
<G-vec00819-002-s499><cast.hinauswerfen><en> 11 And I say to you, that many shall come from the east and the west, and shall sit down with Abraham, and Isaac, and Jacob in the kingdom of heaven. 12 But the children of the kingdom shall be cast out into utter darkness: there shall be weeping and gnashing of teeth.
<G-vec00819-002-s499><cast.hinauswerfen><de> 11 Ich sage euch aber, daß viele von Osten und Westen kommen und mit Abraham und Isaak und Jakob zu Tische liegen werden in dem Reiche der Himmel, 12 aber die Söhne des Reiches werden hinausgeworfen werden in die äußere Finsternis: da wird sein das Weinen und das Zähneknirschen.
<G-vec00819-002-s500><cast.hinauswerfen><en> The purpose of thus “sitting down” with the Ancient Worthies in the kingdom is revealed by Jesus’ further statement that the “children of the kingdom” would be “cast out.”
<G-vec00819-002-s500><cast.hinauswerfen><de> Die Verwendung dieses Ausdrucks - „zu Tische liegen“ mit den Alttestamentlichen Überwindern - wird durch Jesu weitere Erklärung verständlich, dass die „Söhne des Reiches“ „hinausgeworfen“ werden.
<G-vec00819-002-s501><cast.hinauswerfen><en> 30 Therefore thus saith the LORD of Jehoiakim king of Judah; He shall have none to sit upon the throne of David: and his dead body shall be cast out in the day to the heat, and in the night to the frost.
<G-vec00819-002-s501><cast.hinauswerfen><de> 30 Darum - so spricht der HERR über Jojakim, den König von Juda: Er wird keinen Nachkommen mehr haben, der auf dem Thron Davids sitzt, und sein Leichnam soll hinausgeworfen werden in die Hitze des Tags und die Kälte der Nacht.
<G-vec00819-002-s502><cast.hinauswerfen><en> If a man abides not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00819-002-s502><cast.hinauswerfen><de> 6 Wenn jemand nicht in mir bleibt, so wird er hinausgeworfen wie die Rebe und verdorrt; und man sammelt sie und wirft sie ins Feuer, und sie verbrennen.
<G-vec00819-002-s503><cast.hinauswerfen><en> 11I say to you that many will come from east and west, and recline at the table with Abraham, Isaac and Jacob in the kingdom of heaven; 12but the sons of the kingdom will be cast out into the outer darkness; in that place there will be weeping and gnashing of teeth."
<G-vec00819-002-s503><cast.hinauswerfen><de> 11Ich sage euch aber, daß viele von Osten und Westen kommen und mit Abraham und Isaak und Jakob zu Tische liegen werden in dem Reiche der Himmel, 12aber die Söhne des Reiches werden hinausgeworfen werden in die äußere Finsternis: da wird sein das Weinen und das Zähneknirschen.
<G-vec00819-002-s504><cast.hinauswerfen><en> nkjv@John:12:31 @ Now is the judgment of this world; now the ruler of this world will be cast out.
<G-vec00819-002-s504><cast.hinauswerfen><de> Jetzt wird Gericht gehalten über diese Welt; jetzt wird der Herrscher dieser Welt hinausgeworfen werden.
<G-vec00819-002-s505><cast.hinauswerfen><en> 6 If a man does not abide in me, he is cast forth as a branch and withers; and the branches are gathered, thrown into the fire and burned.
<G-vec00819-002-s505><cast.hinauswerfen><de> 6 Wenn einer nicht in mir bleibt, so wird er hinausgeworfen wie die Ranke, die verdorrt, und man sammelt sie und wirft sie ins Feuer, da brennt sie.
<G-vec00819-002-s506><cast.hinauswerfen><en> 11 And I say unto you, That many shall come from the east and west, and shall sit down with Abraham, and Isaac, and Jacob, in the kingdom of heaven. 12 But the children of the kingdom shall be cast out into outer darkness: there shall be weeping and gnashing of teeth.
<G-vec00819-002-s506><cast.hinauswerfen><de> 11 Ich sage euch: Viele werden von Osten und Westen kommen und mit Abraham, Isaak und Jakob im Himmelreich zu Tisch sitzen; 12 die aber, für die das Reich bestimmt war, werden hinausgeworfen in die äußerste Finsternis; dort werden sie heulen und mit den Zähnen knirschen.
<G-vec00819-002-s580><cast.verwerfen><en> 6 But if ye shall turn away from following me, ye or your children, and not keep my commandments and my statutes which I have set before you, but shall go and serve other gods, and worship them; 7 then will I cut off Israel out of the land which I have given them; and this house, which I have hallowed for my name, will I cast out of my sight; and Israel shall be a proverb and a byword among all peoples.
<G-vec00819-002-s580><cast.verwerfen><de> 6 Werdet ihr aber euch von mir abwenden, ihr und eure Kinder, und nicht halten meine Gebote und Rechte, die ich euch vorgelegt habe, und hingehen und andern Göttern dienen und sie anbeten: 7 so werde ich Israel ausrotten von dem Lande, das ich ihnen gegeben habe; und das Haus, das ich geheiligt habe meinem Namen, will ich verwerfen von meinem Angesicht; und Israel wird ein Sprichwort und eine Fabel sein unter allen Völkern.
<G-vec00819-002-s581><cast.verwerfen><en> Jeremiah 31, verse 37 Thus says the LORD: If heaven above can be measured, and the foundations of the earth searched out beneath, then will I also cast off all the seed of Israel for all that they have done, says the LORD.
<G-vec00819-002-s581><cast.verwerfen><de> Jeremia 31, Vers 37 So spricht der HERR: Wenn der Himmel oben gemessen werden kann und die Grundfesten der Erde unten erforscht werden können, dann will ich auch die ganze Nachkommenschaft Israels verwerfen wegen all dessen, was sie getan haben, spricht der HERR.
<G-vec00819-002-s582><cast.verwerfen><en> And the LORD said, I will remove Judah also out of my sight, as I have removed Israel, and will cast off this city Jerusalem which I have chosen, and the house of which I said, My name shall be there.
<G-vec00819-002-s582><cast.verwerfen><de> Und der HERR sprach: Ich will Juda auch von meinem Angesicht tun, wie ich Israel weggetan habe, und will diese Stadt verwerfen, die ich erwählt hatte, Jerusalem, und das Haus, davon ich gesagt habe: Mein Namen soll daselbst sein.
<G-vec00819-002-s583><cast.verwerfen><en> Verses 37-40 – “Thus saith the Lord; If heaven above can be measured, and the foundations of the earth searched out beneath, I will also cast off all the seed of Israel for all that they have done, saith the Lord.
<G-vec00819-002-s583><cast.verwerfen><de> 37 So spricht der HERR: Wenn man den Himmel oben kann messen und den Grund der Erde erforschen, so will ich auch verwerfen den ganzen Samen Israels um alles, was sie tun, spricht der HERR.
<G-vec00819-002-s584><cast.verwerfen><en> 31:37 Thus saith the LORD; If heaven above can be measured, n and the foundations of the earth searched out beneath, I will also cast off all the seed of Israel for all that they have done, saith the LORD.
<G-vec00819-002-s584><cast.verwerfen><de> 37 So spricht der HERR: Wenn die Himmel oben gemessen und die Grundfesten der Erde unten erforscht werden können, dann will ich auch die ganze Nachkommenschaft Israels verwerfen wegen all dessen, was sie getan haben, spricht der HERR.
<G-vec00819-002-s585><cast.verwerfen><en> 19But if ye turn away, and forsake my statutes and my commandments, which I have set before you, and shall go and serve other gods, and worship them; 20Then will I pluck them up by the roots out of my land which I have given them; and this house, which I have sanctified for my name, will I cast out of my sight, and will make it to be a proverb and a byword among all nations.
<G-vec00819-002-s585><cast.verwerfen><de> 19Werdet ihr euch aber abkehren und meine Rechte und Gebote, die ich euch vorgelegt habe, verlassen und hingehen und andern Göttern dienen und sie anbeten, 20so werde ich Israel ausreißen aus meinem Lande, das ich ihnen gegeben habe, und dies Haus, das ich meinem Namen geheiligt habe, werde ich von meinem Angesicht verwerfen und werde es zum Hohn machen und zum Spott unter allen Völkern.
<G-vec00819-002-s586><cast.verwerfen><en> 31:37 Thus saith the Lord: If the heavens above can be measured, and the foundations of the earth searched out beneath, I also will cast away all the seed of Israel, for all that they have done, saith the Lord.
<G-vec00819-002-s586><cast.verwerfen><de> 31:37 So spricht der HERR: Wenn man den Himmel oben kann messen und den Grund der Erde erforschen, so will ich auch verwerfen den ganzen Samen Israels um alles, das sie tun, spricht der HERR.
<G-vec00819-002-s587><cast.verwerfen><en> 7 Then will I cut off Israel out of the land which I have given them; and this house, which I have hallowed for my name, will I cast out of my sight; and Israel shall be a proverb and a byword among all people:
<G-vec00819-002-s587><cast.verwerfen><de> 7 so werde ich IsraelIsrael ausrotten von dem Lande, das ich ihnen gegeben habe; und das Haus, das ich geheiligt habe meinem Namen, will ich verwerfen von meinem Angesicht; und IsraelIsrael wird ein Sprichwort und eine Fabel sein unter allen Völkern.
<G-vec00819-002-s588><cast.verwerfen><en> I will take away Israel from the face of the land which I have given them; and the temple which I have sanctified to my name, I will cast out of my sight; and Israel shall be a proverb, and a byword among all people.
<G-vec00819-002-s588><cast.verwerfen><de> 7so werde ich Israel ausrotten aus dem Lande, das ich ihnen gegeben habe, und das Haus, das ich meinem Namen geheiligt habe, will ich verwerfen von meinem Angesicht; und Israel wird ein Spott und Hohn sein unter allen Völkern.
<G-vec00819-002-s591><cast.verwerfen><en> 7:20 I will uproot you from my land, which I gave to you, and from this house, which I sanctified to my name, and I will cast it away from before my face, and I will deliver it to be a parable and an example for all the peoples.
<G-vec00819-002-s591><cast.verwerfen><de> 20 so werde ich Israel ausreißen aus meinem Lande, das ich ihnen gegeben habe, und dies Haus, das ich meinem Namen geheiligt habe, werde ich von meinem Angesicht verwerfen und werde es zum Hohn machen und zum Spott unter allen Völkern.
<G-vec00819-002-s593><cast.verwerfen><en> 007:019 But if you turn away, and forsake my statutes and my commandments which I have set before you, and shall go and serve other gods, and worship them; 007:020 then will I pluck them up by the roots out of my land which I have given them; and this house, which I have made holy for my name, will I cast out of my sight, and I will make it a proverb and a byword among all peoples.
<G-vec00819-002-s593><cast.verwerfen><de> 19 Wenn ihr euch aber von mir abwendet, meine Gebote und Satzungen, zu denen ich euch verpflichtet habe, nicht haltet, sondern anderen Göttern dient und sie anbetet, 20 werde ich Israel aus dem Land, das ich ihm gegeben habe, ausrotten und den Tempel, den ich meinem Namen geweiht habe, von meinem Angesicht verwerfen, und ihn zum Hohn und Spott machen bei allen Völkern.
<G-vec00819-002-s300><cast.werfen><en> 6:7 (6:8) All the presidents of the kingdom, the prefects and the satraps, the ministers and the governors, have consulted together that the king should establish a statute, and make a strong interdict, that whosoever shall ask a petition of any god or man for thirty days, save of thee, O king, he shall be cast into the den of lions.
<G-vec00819-002-s300><cast.werfen><de> 6:8 Alle Minister des Königreichs, die Statthalter und Satrapen, die Staatsräte und Verwalter haben sich beraten, daß der König eine Verordnung erlassen und ein Verbot bestätigen solle, daß jeder, der innerhalb von dreißig Tagen an irgendeinen Gott oder Menschen eine Bitte richtet außer an dich, o König, in die Löwengrube geworfen werden soll.
<G-vec00819-002-s301><cast.werfen><en> 53 They have cut off my life in the dungeon, and have cast a stone on me.
<G-vec00819-002-s301><cast.werfen><de> 53 Sie haben mein Leben in der Grube zunichte gemacht und Steine auf mich geworfen.
<G-vec00819-002-s302><cast.werfen><en> 24For Haman the Agagite, the son of Hammedatha, the enemy of all the Jews, had plotted against the Jews to destroy them, and had cast Pur (that is, cast lots), to crush and to destroy them.
<G-vec00819-002-s302><cast.werfen><de> 24Denn Haman, der Sohn Hammedathas, der Agagiter, der Widersacher aller Juden, hatte gegen die Juden den Anschlag ersonnen, sie umzubringen, und hatte das Pur, das ist das Los, geworfen, um sie zu vertilgen und sie umzubringen.
<G-vec00819-002-s303><cast.werfen><en> Revelation 20:10: 20:10 And the devil that deceived them was cast into the lake of fire and brimstone, where the beast and the false prophet are, and shall be tormented day and night for ever and ever.
<G-vec00819-002-s303><cast.werfen><de> Offenbarung 20:10 „Und der Teufel, der sie verführte, wurde geworfen in den Pfuhl von Feuer und Schwefel, wo auch das Tier und der falsche Prophet waren; und sie werden gequält werden Tag und Nacht, von Ewigkeit zu Ewigkeit.“ Erinnern Sie sich daran, wenn jemand zu Ihnen sagt, dass Sie zu diesem Platz (Hölle) gehen sollen.
<G-vec00819-002-s304><cast.werfen><en> 19.20 And the beast was taken, and with him the false prophet that wrought miracles before him, with which he deceived them that had received the mark of the beast, and them that worshipped his image. These both were cast chair.
<G-vec00819-002-s304><cast.werfen><de> 19:20 Und das Tier ward gegriffen und mit ihm der falsche Prophet, der die Zeichen tat vor ihm, durch welche er verführte, die das Malzeichen des Tiers nahmen und die das Bild des Tiers anbeteten; lebendig wurden diese beiden in den feurigen Pfuhl geworfen, der mit Schwefel brannte.
<G-vec00819-002-s305><cast.werfen><en> 19 Every tree which does not bring forth Righteous fruit is cut down, and cast into the fire.
<G-vec00819-002-s305><cast.werfen><de> 19 Jeder Baum, der keine guten Früchte hervorbringt, wird umgehauen und ins Feuer geworfen.
<G-vec00819-002-s306><cast.werfen><en> Some rules indicate using only one die; some rules indicate using the two numbers cast by a player and their opponent.
<G-vec00819-002-s306><cast.werfen><de> Einige Richtlinien zeigen mit nur einem Würfel an; einige Richtlinien zeigen mit den zwei Zahlen an, die von einem Spieler und von ihrem Konkurrenten geworfen werden.
<G-vec00819-002-s307><cast.werfen><en> 10and now also, the axe unto the root of the trees is laid, every tree therefore not bearing good fruit is hewn down, and to fire is cast.
<G-vec00819-002-s307><cast.werfen><de> 10 Schon ist aber die Axt an die Wurzel der Bäume gelegt; jeder Baum nun, der nicht gute Frucht bringt, wird abgehauen und ins Feuer geworfen.
<G-vec00819-002-s308><cast.werfen><en> For it is expedient for thee that one of thy members should perish, rather than that thy whole body be cast into hell.
<G-vec00819-002-s308><cast.werfen><de> Es ist besser für dich, daß eins deiner Glieder verderbe und nicht der ganze Leib in die Hölle geworfen werde.
<G-vec00819-002-s309><cast.werfen><en> Revelation 12/13 And when the dragon saw that he was cast unto the earth, he persecuted the woman which brought forth the man child.
<G-vec00819-002-s309><cast.werfen><de> Offenbarung 12/13 Und als der Drache sah, daß er auf die Erde geworfen war, verfolgte er das Weib, welches das männliche Kind geboren hatte.
<G-vec00819-002-s310><cast.werfen><en> and whoever doesn't fall down and worships shall the same hour be cast into the midst of a burning fiery furnace.
<G-vec00819-002-s310><cast.werfen><de> 6Wer aber dann nicht niederfällt und anbetet, der soll sofort in den glühenden Ofen geworfen werden.
<G-vec00819-002-s311><cast.werfen><en> otherwise, you shall be instantly cast into the white-hot furnace;
<G-vec00819-002-s311><cast.werfen><de> Wenn aber nicht, werdet ihr sofort in den glühenden Ofen geworfen.
<G-vec00819-002-s312><cast.werfen><en> 19 He hath cast me into the mire, and I am become like dust and ashes.
<G-vec00819-002-s312><cast.werfen><de> 19 Man hat mich in den Dreck geworfen, daß ich gleich bin dem Staub und der Asche.
<G-vec00819-002-s313><cast.werfen><en> Now the king was sitting in the Gate of Benjamin; 8and Ebed-melech went out from the king's palace and spoke to the king, saying, 9"My lord the king, these men have acted wickedly in all that they have done to Jeremiah the prophet whom they have cast into the cistern; and he will die right where he is because of the famine, for there is no more bread in the city."
<G-vec00819-002-s313><cast.werfen><de> 8Und Ebedmelech ging aus dem Hause des Königs hinaus und redete zum König und sprach: 9Mein Herr König, diese Männer haben übel gehandelt in allem, was sie dem Propheten Jeremia getan, den sie in die Grube geworfen haben; er muss ja da, wo er ist, vor Hunger sterben, denn es ist kein Brot mehr in der Stadt.
<G-vec00819-002-s314><cast.werfen><en> REV 20:10 and the Devil, who is leading them astray, was cast into the lake of fire and brimstone, where `are' the beast and the false prophet, and they shall be tormented day and night -- to the ages of the ages.
<G-vec00819-002-s314><cast.werfen><de> 10 Und der Teufel, der sie verführte, ward geworfen in den feurigen Pfuhl und Schwefel, da auch das Tier und der falsche Prophet war; und sie werden gequält werden Tag und Nacht von Ewigkeit zu Ewigkeit.
<G-vec00819-002-s315><cast.werfen><en> He was cast into prison for a crime he did not commit.
<G-vec00819-002-s315><cast.werfen><de> Er wurde für ein Verbrechen, das er nicht begangen hatte, ins Gefängnis geworfen.
<G-vec00819-002-s316><cast.werfen><en> Mark Selzer, forecaster at the Met Office, told MailOnline: 'It's hard to be completely sure from a picture, but it's likely this [sight] is due to a phenomenon known as crepuscular rays - or sunbeams - being cast from over the horizon.
<G-vec00819-002-s316><cast.werfen><de> Mark Selzer, Meteorologe im Met Büro, sagte zu MailOnline: "Es ist schwierig, sich mit einem Bild vollkommen sicher zu sein, doch dies [die Sichtung] wird wahrscheinlich durch ein Phänomen verursacht, das als krepuskulare Strahlen - oder Sonnenstrahlen, die über den Horizont geworfen werden - bekannt ist.
<G-vec00819-002-s317><cast.werfen><en> The poem eventually received the title 'Gefangen im Licht' ('Caught in Light'); the light in question is that cast by language, in which the poet feels herself trapped.
<G-vec00819-002-s317><cast.werfen><de> Das Gedicht erhielt daher den Titel 'Gefangen im Licht', wobei das Licht von der Sprache selbst geworfen wird, in der sich die Dichterin gefangen fühlt.
<G-vec00819-002-s318><cast.werfen><en> It is not simply a human body being cast into the lake of fire; it is a human’s body, soul, and spirit.
<G-vec00819-002-s318><cast.werfen><de> Es geht nicht nur darum, daß ein menschlicher Körper in eine Feuersee geworfen wird, sondern es geht um den Körper, die Seele und den Geist eines Menschen.
<G-vec00819-002-s595><cast.werfen><en> 19 And the LORD turned a mighty strong west wind, which took away the locusts and cast them into the Red Sea;
<G-vec00819-002-s595><cast.werfen><de> 19 Da wendete der Herr den Wind um, dass er sehr stark aus dem Westen wehte und die Heuschrecken aufhob und sie ins Schilfmeer warf, sodass an allen Orten Ägyptens nicht eine übrig blieb.
<G-vec00819-002-s596><cast.werfen><en> I will cast terror into the hearts of those who have disbelieved, so strike them over the necks, and smite over all their fingers and toes.'"
<G-vec00819-002-s596><cast.werfen><de> Sure 33, Vers 26: Und Er veranlasste diejenigen vom Volke der Schrift, die ihnen halfen, von ihren Kastellen herabzusteigen, und warf Schrecken in ihre Herzen.
<G-vec00819-002-s597><cast.werfen><en> And he cast down the pieces of silver in the temple, and departed, and went and hanged himself.
<G-vec00819-002-s597><cast.werfen><de> Flauto Tenor Und er warf die Silberlinge in den Tempel, hub sich davon, ging hin und erhängete sich selbst.
<G-vec00819-002-s598><cast.werfen><en> The morning sun had cast a strip on the eastern horizon Continue reading Photo Project: Dancing Great Woodlark – a welcome sign for spring
<G-vec00819-002-s598><cast.werfen><de> Die Morgensonne warf schon einen Streifen über den östlichen Horizont, als ich mich dem Versteck näherte.
<G-vec00819-002-s599><cast.werfen><en> Now the leaders of the people lived in Jerusalem, but the rest of the people cast lots to bring one out of ten to live in Jerusalem, the holy city, while nine-tenths remained in the other cities.
<G-vec00819-002-s599><cast.werfen><de> Und die Obersten des Volks nahmen ihren Wohnsitz in Jerusalem; das übrige Volk warf das Los, um je einen von zehn hineinzubringen, daß er in Jerusalem, der heiligen Stadt, wohne, die übrigen neun Zehntel aber in den Landstädten.
<G-vec00819-002-s600><cast.werfen><en> And they spread a garment, and did cast therein every man the earrings of his prey.
<G-vec00819-002-s600><cast.werfen><de> Und sie breiteten ein Kleid aus, und ein jeder warf einen Nasenring von der Beute darauf.
<G-vec00819-002-s601><cast.werfen><en> The sun was cast its last golden rays over the city of Zurich, single rain drops did fall from a few clouds.
<G-vec00819-002-s601><cast.werfen><de> Die Sonne warf ihre letzten goldenen Strahlen über die Stadt Zürich, aus einigen Wolken fielen ein paar vereinzelte Regentropfen.
<G-vec00819-002-s602><cast.werfen><en> 12:4 and his tail draws the third part of the stars of the heaven; and he cast them to the earth.
<G-vec00819-002-s602><cast.werfen><de> 12:4 und sein Schwanz zieht den dritten Teil der Sterne des Himmels mit sich fort; und er warf sie auf die Erde.
<G-vec00819-002-s603><cast.werfen><en> So they gave it me then I cast it into the fire, and there came out this calf.
<G-vec00819-002-s603><cast.werfen><de> Sie rissen es sich ab und gaben es mir, und ich warf es ins Feuer, und dieses Kalb ging hervor.
<G-vec00819-002-s604><cast.werfen><en> Am Then the bird cast down a dress, the like of which had never been seen for splendour and brilliancy, and slippers that were of gold. golden.
<G-vec00819-002-s604><cast.werfen><de> Nun warf ihm der Vogel ein Kleid herab, das war so prächtig und glänzend, wie es noch keins gehabt hatte, und die Pantoffeln waren ganz golden.
<G-vec00819-002-s605><cast.werfen><en> 30and he would not, but having gone away, he cast him into prison, till he might pay that which was owing.
<G-vec00819-002-s605><cast.werfen><de> 30 Er aber wollte nicht, sondern ging hin und warf ihn ins Gefängnis, bis er die Schuld bezahlt habe.
<G-vec00819-002-s606><cast.werfen><en> And I took the thirty [pieces] of silver, and cast them unto the potter, in the house of Jehovah.
<G-vec00819-002-s606><cast.werfen><de> Und ich nahm die dreißig Silbersekel und warf sie in das Haus Jehovas, dem Töpfer hin.
<G-vec00819-002-s607><cast.werfen><en> 16:6 and cast stones at David, and at all the servants of king David; and all the people and all the mighty men were on his right hand and on his left.
<G-vec00819-002-s607><cast.werfen><de> 16:6 und warf mit Steinen nach David und nach allen Knechten des Königs David; und alles Volk und alle Helden waren zu seiner Rechten und zu seiner Linken.
<G-vec00819-002-s608><cast.werfen><en> 12For each man cast down his staff, and they became serpents. But Aaron's staff swallowed up their staffs.
<G-vec00819-002-s608><cast.werfen><de> 12Ein jeder warf seinen Stab hin, da wurden Schlangen daraus; aber Aarons Stab verschlang ihre Stäbe.
<G-vec00819-002-s609><cast.werfen><en> Her young children also were dashed in pieces at the head of all the streets, and they cast lots for her honorable men, and all her great men were bound in chains.
<G-vec00819-002-s609><cast.werfen><de> Ihre Kinder sind auf allen Gassen zerschmettert worden, und um ihre Edlen warf man das Los, und alle ihre Gewaltigen wurden in Ketten und Fesseln gelegt.
<G-vec00819-002-s610><cast.werfen><en> The German economic wonder cast its shadow on Austria.
<G-vec00819-002-s610><cast.werfen><de> Das deutsche Wirtschaftswunder warf seine Schatten auch nach Österreich.
<G-vec00819-002-s611><cast.werfen><en> As the lighting conditions were not perfect on that day, and as we were there at noon, the sun was very hard and cast hard shadows.
<G-vec00819-002-s611><cast.werfen><de> Da die Lichtverhältnisse an diesem Tag nicht perfekt waren und wir am Mittag dort waren, war das Sonnenlicht sehr hart und warf Schlagschatten.
<G-vec00819-002-s612><cast.werfen><en> While he was still speaking, behold, a bright cloud cast a shadow over them, then from the cloud came a voice that said, "This is my beloved Son, with whom I am well pleased; listen to him."
<G-vec00819-002-s612><cast.werfen><de> Noch während er redete, warf eine leuchtende Wolke ihren Schatten auf sie, und aus der Wolke rief eine Stimme: Das ist mein geliebter Sohn, an dem ich Gefallen gefunden habe; auf ihn sollt ihr hören.
<G-vec00819-002-s613><cast.werfen><en> And it was so, when they came into the midst of the city, that Ishmael the son of Nethaniah killed them, and cast them into the midst of a pit, he, and the men that were with him.
<G-vec00819-002-s613><cast.werfen><de> 7 Und es geschah, als sie in die Stadt hineingekommen waren, da schlachtete sie Ismael, der Sohn des Netanja, [und warf sie] in die Zisterne, er und die Männer, die mit ihm waren.
<G-vec00819-002-s614><cast.werfen><en> 38:6 Then took they Jeremiah, and cast him into the dungeon of Malchijah the king’s son, that was in the court of the guard: and they let down Jeremiah with cords.
<G-vec00819-002-s614><cast.werfen><de> Jer 38:6 Da ergriffen sie den Jeremias und warfen ihn in die Zisterne des Prinzen Malkija, die sich im Wachthof befand; an Stricken ließ man den Jeremias hinunter; in der Zisterne gab es kein Wasser, sondern nur Schlamm.
<G-vec00819-002-s615><cast.werfen><en> 26 But they were disobedient, and rebelled against thee, and cast thy law behind their backs, and slew thy prophets who testified against them to turn them to thee, and they wrought great provocations.
<G-vec00819-002-s615><cast.werfen><de> 26Aber sie wurden widerspenstig und empörten sich gegen dich, und warfen dein Gesetz hinter ihren Rücken; und sie ermordeten deine Propheten, welche wider sie zeugten, um sie zu dir zurückzuführen; und sie verübten große Schmähungen.
<G-vec00819-002-s616><cast.werfen><en> And they cast lots, the small as well as the great, according to the house of their fathers, for every gate.
<G-vec00819-002-s616><cast.werfen><de> 13 Und sie warfen Lose nach ihren Vaterhäusern, ob klein, ob groß, für jedes Tor.
<G-vec00819-002-s617><cast.werfen><en> His eyes cast blessing wherever they fell.
<G-vec00819-002-s617><cast.werfen><de> Seine Augen warfen Segen, wohin sie fielen.
<G-vec00819-002-s618><cast.werfen><en> They answered him, No. 6 And he said unto them, Cast the net on the right side of the ship, and ye shall find. They cast therefore, and now they were not able to draw it for the multitude of fishes.
<G-vec00819-002-s618><cast.werfen><de> Er aber sprach zu ihnen: Werfet das Netz zur Rechten des Schiffs, so werdet ihr finden; Da warfen sie, und konnten's nicht mehr ziehen vor der Menge der Fische.
<G-vec00819-002-s619><cast.werfen><en> 11In the day of thy standing over-against, In the day of strangers taking captive his force, And foreigners have entered his gates, And for Jerusalem have cast a lot, Even thou [art] as one of them!
<G-vec00819-002-s619><cast.werfen><de> 11 An dem Tag, als du abseits standest, an dem Tag, als Fremde sein Heer gefangen wegführten und Ausländer in seine Tore kamen und über Jerusalem das Los warfen, da warst auch du wie einer von ihnen.
<G-vec00819-002-s620><cast.werfen><en> 11 From the day that you stood in opposition to him, in the days when foreigners were taking captive his forces, and strangers entered into his gates, and cast lots on Jerusalem, you also were as one of them.
<G-vec00819-002-s620><cast.werfen><de> 11 An dem Tage, da du gegenüber standest, an dem Tage, da Fremde sein Vermögen hinwegführten, und Ausländer zu seinen Toren einzogen und über Jerusalem das Los warfen, da warst auch du wie einer von ihnen.
<G-vec00819-002-s621><cast.werfen><en> Sk 16:23 - And when they had inflicted many scourges on them, they cast them into prison, instructing the guard to watch them diligently.
<G-vec00819-002-s621><cast.werfen><de> Sk 16:23 - Und als sie ihnen viele Schläge gegeben hatten, warfen sie sie ins Gefängnis und befahlen dem Kerkermeister, sie sicher zu verwahren.
<G-vec00819-002-s622><cast.werfen><en> 37:24 and they took him and cast him into the pit; now the pit was empty -- there was no water in it.
<G-vec00819-002-s622><cast.werfen><de> 37:24 und nahmen ihn und warfen ihn in eine Grube; aber dieselbige Grube war leer und kein Wasser drinnen.
<G-vec00819-002-s623><cast.werfen><en> 2Samuel 20:22 Then the woman went unto all the people in her wisdom. And they cut off the head of Sheba the son of Bichri, and cast it out to Joab.
<G-vec00819-002-s623><cast.werfen><de> Und das Weib kam zu dem ganzen Volke mit ihrer Klugheit; und sie hieben Scheba, dem Sohne Bikris, den Kopf ab und warfen ihn Joab zu.
<G-vec00819-002-s624><cast.werfen><en> And the robbers from Moab came into the land in the same year. 21 2Kr 13, 21 But certain ones who were burying a man saw the robbers, and they cast the dead body into the sepulcher of Elisha.
<G-vec00819-002-s624><cast.werfen><de> 21 2Kr 13, 21 Und es geschah, als sie einen Mann begruben, siehe, da sahen sie die Streifschar, und sie warfen den Mann in das Grab Elisas; und als der Mann hineinkam und die Gebeine Elisas berührte, da wurde er lebendig und erhob sich auf seine Füße.
<G-vec00819-002-s625><cast.werfen><en> And they cast lots, dividing up His garments among themselves.
<G-vec00819-002-s625><cast.werfen><de> Sie aber verteilten seine Kleider und warfen das Los darüber.
<G-vec00819-002-s626><cast.werfen><en> Then the mariners were afraid, and cried every man unto his god, and cast forth the wares that were in the ship into the sea, to lighten it of them.
<G-vec00819-002-s626><cast.werfen><de> Da fürchteten sich die Schiffsleute und schrien, jeder zu seinem Gott; und sie warfen die Geräte, die im Schiff waren, ins Meer, um es dadurch zu erleichtern.
<G-vec00819-002-s627><cast.werfen><en> And they took Jonas, and cast him into the sea, and the sea ceased from raging.
<G-vec00819-002-s627><cast.werfen><de> Dann nahmen sie Jona und warfen ihn ins Meer und das Meer hörte auf zu toben.
<G-vec00819-002-s628><cast.werfen><en> A shadow was cast over Andy's career in 1995 by his two defeats against a South African fighter previously unknown to him up till then.
<G-vec00819-002-s628><cast.werfen><de> Einen Schatten auf Andys Karriere warfen 1995 die zwei Niederlagen gegen einen ihm bis anhin unbekannten Kämpfer aus Südafrika.
<G-vec00819-002-s629><cast.werfen><en> Dividing his garments among them, they cast lots.
<G-vec00819-002-s629><cast.werfen><de> Und sie teilten seine Kleider und warfen das Los darum.
<G-vec00819-002-s631><cast.werfen><en> [14] And they arose and took away the altars that were in Jerusalem, and all the altars for incense took they away, and cast them into the brook Kidron.
<G-vec00819-002-s631><cast.werfen><de> 14 Und sie machten sich auf, und schafften die Altäre weg, die zu Jerusalem waren, und alle Rauchaltäre schafften sie weg, und warfen sie in den Bach Kidron.
<G-vec00819-002-s632><cast.werfen><en> They cast lots for their offices, all alike, as well the small as the great, the teacher as the scholar.
<G-vec00819-002-s632><cast.werfen><de> Und sie warfen das Los über ihre Ämter zugleich, dem Jüngeren wie dem Älteren, dem Lehrer wie dem Schüler.
<G-vec00819-002-s633><cast.werfen><en> 7So when they continued asking him, he lifted up himself, and said unto them, He that is without sin among you, let him first cast a stone at her. 8And again he stooped down, and wrote on the ground.
<G-vec00819-002-s633><cast.werfen><de> Als sie aber ihre Frage an ihn mehrfach wiederholten, richtete er sich auf und sagte zu ihnen: »Wer unter euch ohne Sünde ist, werfe den ersten Stein auf sie!« Hierauf bückte er sich aufs neue und schrieb auf dem Erdboden weiter.
<G-vec00819-002-s634><cast.werfen><en> 22Behold, I do cast her into a bed, and them that commit adultery with her into great tribulation, except they repent of her works.
<G-vec00819-002-s634><cast.werfen><de> 22Siehe, ich werfe sie in ein Bett und die, welche Ehebruch mit ihr treiben, in große Drangsal, wenn sie nicht Buße tun von ihren Werken.
<G-vec00819-002-s635><cast.werfen><en> 16 And he shall take away its crop with the feathers thereof, and cast it beside the altar on the east part, in the place of the ashes.
<G-vec00819-002-s635><cast.werfen><de> 16 Und er trenne ihren Kropf mit seinem Unrat ab und werfe ihn neben den Altar gegen Osten, an den Ort der Fettasche.
<G-vec00819-002-s636><cast.werfen><en> Indeed I will cast her into a sickbed, and those who commit adultery with her into great tribulation, unless they repent of their deeds.
<G-vec00819-002-s636><cast.werfen><de> 22Siehe, ich werfe sie auf ein Bett und die, welche mit ihr ehebrechen, in große Trübsal, wenn sie nicht Buße tun von ihren Werken.
<G-vec00819-002-s637><cast.werfen><en> 16 and he shall take away its crop with the filth thereof, and cast it beside the altar on the east part, in the place of the ashes:
<G-vec00819-002-s637><cast.werfen><de> 16 Und er trenne ihren Kropf mit seinem Inhalt ab und werfe ihn neben den Altar nach Osten, an den Ort der Fettasche.
<G-vec00819-002-s639><cast.werfen><en> 7:27 But Jesus said to her, Let the children first be satisfied: for it is not meet to take the children's bread, and to cast [it] to the dogs.
<G-vec00819-002-s639><cast.werfen><de> 27 Jesus aber sprach zu ihr: Lass zuvor die Kinder satt werden; es ist nicht recht, dass man den Kindern das Brot wegnehme und werfe es vor die Hunde.
<G-vec00819-002-s640><cast.werfen><en> 23) And when the priests demanded that he speak, he said, Let him who has no sin stand forth and be the first to cast a stone at her.
<G-vec00819-002-s640><cast.werfen><de> Joh 8,7 Als sie nun anhielten, ihn zu fragen, richtete er sich auf und sprach zu ihnen: Wer unter euch ohne Sünde ist, der werfe den ersten Stein auf sie.
<G-vec00819-002-s641><cast.werfen><en> Who answering, said: It is not good to take the bread of the children, and to cast it to the dogs.
<G-vec00819-002-s641><cast.werfen><de> Aber er antwortete und sprach: Es ist nicht fein, daß man den Kindern ihr Brot nehme und werfe es vor die Hunde.
<G-vec00819-002-s642><cast.werfen><en> I cast close to the steeply sloping banks; 10 cm are ideal.
<G-vec00819-002-s642><cast.werfen><de> Ich werfe immer knapp ans steil abfallende Ufer; optimal sind 10 cm.
<G-vec00819-002-s643><cast.werfen><en> And the men arose, and went away: and Joshua charged them that went to describe the land, saying, Go and walk through the land, and describe it, and come again to me, that I may here cast lots for you before the LORD in Shiloh.
<G-vec00819-002-s643><cast.werfen><de> Da machten sich die Maenner auf, dass sie hingingen; und Josua gebot ihnen, da sie hin wollten gehen, das Land aufzuschreiben, und sprach: Gehet hin und durchwandelt das Land und schreibt es auf und kommt wieder zu mir, dass ich euch hier das Los werfe vor dem HERRN zu Silo.
<G-vec00819-002-s644><cast.werfen><en> 7 and when they continued asking him, having bent himself back, he said unto them, 'The sinless of you -- let him first cast the stone at her;'
<G-vec00819-002-s644><cast.werfen><de> Als sie nun anhielten, ihn zu fragen, richtete er sich auf und sprach zu ihnen: Wer unter euch ohne Sünde ist, der werfe den ersten Stein auf sie.
<G-vec00819-002-s646><cast.werfen><en> Description: Cast your line into a frozen blue lake for your chance to hook some big cash in our freshest new game, Lucky Angler.
<G-vec00819-002-s646><cast.werfen><de> Description: Werfe deine Angel in den kühlen blauen See und ziehe einige saftige Gewinne an Land bei unserem neuen Spiel, Lucky Angler.
<G-vec00819-002-s647><cast.werfen><en> Humbly I cast myself before the revelations of Thy mercy, confessing that Thou art God, no God is there but Thee, and that Thou art incomparable, hast no partner and naught is there like Thee.
<G-vec00819-002-s647><cast.werfen><de> Demütig werfe ich mich nieder vor den Offenbarungen Deines Erbarmens und bekenne, daß Du Gott bist, daß es keinen Gott gibt außer Dir, daß Du unvergleichlich bist, keinen Gefährten und nichts Deinesgleichen hast.
<G-vec00819-002-s648><cast.werfen><en> But when they continued asking him, he lifted up himself, and said unto them, He that is without sin among you, let him first cast a stone at her.
<G-vec00819-002-s648><cast.werfen><de> Als sie aber fortfuhren, ihn zu fragen, richtete er sich auf und sprach zu ihnen: Wer von euch ohne Sünde ist, werfe zuerst den Stein auf sie.
<G-vec00819-002-s649><cast.werfen><en> So when they continued asking him, he lifted up himself, and said unto them, He that is without sin among you, let him first cast a stone at her.
<G-vec00819-002-s649><cast.werfen><de> 7Als sie nun fortfuhren, ihn zu fragen, richtete er sich auf und sprach zu ihnen: bWer unter euch ohne Sünde ist, der werfe den ersten Stein auf sie.
<G-vec00819-002-s650><cast.werfen><en> I cast a glance at the map: Basquiat’s grave is marked, but is at the other end of the park. I set off to find it.
<G-vec00819-002-s650><cast.werfen><de> Ich werfe einen Blick auf die Karte: Basquiats Grab ist eingezeichnet, befindet sich allerdings am anderen Ende des Parks.Ich mache mich auf den Weg.
<G-vec00819-002-s652><cast.werfen><en> Having suffered Me to be cast into the prison, Thou didst turn it into a garden of Paradise for Me and caused it to become a chamber of the court of everlasting fellowship.
<G-vec00819-002-s652><cast.werfen><de> Nachdem Du erlaubtest, Mich in dieses Gefängnis zu werfen, hast Du es für Mich in einen Paradiesgarten verwandelt und bewirkt, daß es ein Gemach am Hofe ewiger Gemeinschaft werde.
<G-vec00819-002-s653><cast.werfen><en> Or simply cast a curious glance at the unusual artwork which is on display on the premises at hide[m].
<G-vec00819-002-s653><cast.werfen><de> Oder Sie werfen einfach nur einen neugierigen Blick auf die außergewöhnliche Kunst, die in den Räumlichkeiten von hide[m] ausgestellt wird.
<G-vec00819-002-s654><cast.werfen><en> The hands of a user illuminated by bright film lamps cast shadows of various densities to activate the sensors of the Theramidi device and the voice archive which it controls.
<G-vec00819-002-s654><cast.werfen><de> Die Hände eines Benützers/einer Benützerin werfen im Licht von zwei sehr hellen Filmscheinwerfern Schatten unterschiedlicher Stärke, von denen die Sensoren des Theramidis und dadurch die Klangwelten eines digitalen Stimmarchivs aktiviert werden.
<G-vec00819-002-s655><cast.werfen><en> Thanks to extremely powerful x-ray equipment it was possible to cast a glance through the wall of the silo.
<G-vec00819-002-s655><cast.werfen><de> Dank eines extrem starken Röntgengerätes wurde es möglich, einen Blick durch die Silowand hindurch zu werfen.
<G-vec00819-002-s656><cast.werfen><en> 17:2 It were better for him that a millstone were hanged about his neck, and he cast into the sea, than that he should offend one of these little ones.
<G-vec00819-002-s656><cast.werfen><de> 17:2 Es wäre besser für ihn, man würde ihn mit einem Mühlstein um den Hals ins Meer werfen, als dass er einen von diesen Kleinen zum Bösen verführt.
<G-vec00819-002-s657><cast.werfen><en> Thus the shadow cast by both hands against the wall surprisingly shows the peace sign.
<G-vec00819-002-s657><cast.werfen><de> Erstaunlicherweise ergibt der Schatten, den diese beiden Hände an die Wand werfen, das „Peace“-Zeichen.
<G-vec00819-002-s658><cast.werfen><en> 32:4 And I will leave thee upon the land, I will cast thee forth upon the open field, and will cause all the birds of the heavens to settle upon thee, and I will satisfy the beasts of the whole earth with thee.
<G-vec00819-002-s658><cast.werfen><de> 32:4 Und ich werde dich auf das Land werfen, werde dich auf das freie Feld schleudern; und ich werde machen, daß alle Vögel des Himmels sich auf dir niederlassen und die Tiere der ganzen Erde sich von dir sättigen.
<G-vec00819-002-s659><cast.werfen><en> Enjoy the sun and experience fun in the water at Strandbad Duin, play a game of soccer on the panna court, or cast a line at one of the various fishing spots.
<G-vec00819-002-s659><cast.werfen><de> Genießen Sie die Sonne und erleben Sie Spaß im Wasser im Strandbad Duin, spielen Sie ein Fußballspiel auf dem Panna-Platz oder werfen Sie eine Schnur an einem der verschiedenen Angelplätze.
<G-vec00819-002-s660><cast.werfen><en> As people search the Internet, they cast a “shadow” of their wishes and fears, and give clues about what they intend to do.
<G-vec00819-002-s660><cast.werfen><de> Indem Menschen im Internet suchen, werfen sie einen „Schatten“ ihrer Wünsche und Ängste, und geben Aufschluss über ihre Handlungsintentionen.
<G-vec00819-002-s662><cast.werfen><en> And then did this fellow steward fall down before the chief steward and, beseeching him, said: ‘Only have patience with me, and I will presently be able to pay you.’ But the chief steward would not show mercy to his fellow steward but rather had him cast in prison until he should pay his debt.
<G-vec00819-002-s662><cast.werfen><de> Da fiel der Mitverwalter vor dem Hauptverwalter zu Boden und bat ihn inständig mit den Worten: ‚Hab nur Geduld mit mir, und ich werde bald imstande sein, dir alles zu bezahlen.‘ Aber der Hauptverwalter war nicht gewillt, gegen seinen Mitverwalter Milde walten zu lassen, sondern ließ ihn bis zur Tilgung seiner Schulden ins Gefängnis werfen.
<G-vec00819-002-s663><cast.werfen><en> You can cast spells on the people who blocks in the way and then transform them into food.
<G-vec00819-002-s663><cast.werfen><de> Sie können Zauber auf die Menschen werfen, die Blöcke in den Weg und dann in Essen verwandeln.
<G-vec00819-002-s664><cast.werfen><en> [16] And he shall pluck away his crop with his feathers, and cast it beside the altar on the east part, by the place of the ashes:
<G-vec00819-002-s664><cast.werfen><de> 16 Und den Kropf samt den Federn soll er wegnehmen und östlich vom Altar auf den Aschenhaufen werfen.
<G-vec00819-002-s665><cast.werfen><en> You just load some chum into the feeder and cast it to the desired spots.
<G-vec00819-002-s665><cast.werfen><de> Sie laden einfach einen Kumpel in die Zuführung und werfen ihn an die gewünschten Stellen.
<G-vec00819-002-s666><cast.werfen><en> And the »gentleman farmers« do not stop before trees and bushes that stand at the edge of their fields and may cast a slight shadow over them.
<G-vec00819-002-s666><cast.werfen><de> Auch vor Bäumen und Sträuchern, die am Rand ihrer Felder stehen und eventuell einen geringen Schatten auf diese werfen, machen die Herren keinen Halt.
<G-vec00819-002-s667><cast.werfen><en> This party had passed through the hard school of illegal action, its class will had been developed in the stress of conflict, it had won and trained its comrades in suffering and deprivation. The very hardness of the school evolved admirable workers, whose task it is to transform and conquer the world. In order to gain a clear idea of how this party has been formed, let us cast a glance at the main features of its development.
<G-vec00819-002-s667><cast.werfen><de> Die Partei, die durch die harte Schule der illegalen Arbeit gegangen war, die im Pulverkampfe ihren Klassenwillen gestählt, in Qualen, Entbehrungen und Leiden ihre Söhne genährt und herangezogen und die Arbeiterrecken auf den Plan gestellt hatte, denen es vorbehalten blieb, die ganze Welt umzugestalten und zu erobern... Zum Verständnis dessen, wie eine solche Partei entstehen konnte, muss man einen flüchtigen Blick auf gewisse Grundzüge ihrer Entwicklung werfen.
<G-vec00819-002-s668><cast.werfen><en> 9And in the great day of judgment let him be cast into the fire.
<G-vec00819-002-s668><cast.werfen><de> 9 Und am großen Tag der Abrechnung lass ihn ins Feuer werfen.
<G-vec00819-002-s669><cast.werfen><en> So these celestial bodies cast their shadows out into the vastness of interplanetary space.
<G-vec00819-002-s669><cast.werfen><de> So werfen diese Himmelskörper ihre Schatten hinaus in die Weiten des interplanetaren Raums.
<G-vec00819-002-s670><cast.werfen><en> We add the sausage and cast the mixture onto the pan preheated with a splash of oil.
<G-vec00819-002-s670><cast.werfen><de> Fügen Sie die Salchichon und werfen Sie die Mischung auf vorgewärmte Pfanne mit etwas Öl.
<G-vec00819-002-s671><cast.werfen><en> [22] And Reuben said unto them, Shed no blood, but cast him into this pit that is in the wilderness, and lay no hand upon him; that he might rid him out of their hands, to deliver him to his father again.
<G-vec00819-002-s671><cast.werfen><de> 22 Und Ruben sprach zu ihnen: Vergießet doch nicht Blut, werfet ihn in diese Grube, die in der Wüste ist; aber die Hand leget nicht an ihn; damit er ihn rettete aus ihrer Hand und ihn zurückbrächte zu seinem Vater.
<G-vec00819-002-s672><cast.werfen><en> Cast not away therefore your confidence, which hath great recompence of reward.
<G-vec00819-002-s672><cast.werfen><de> Werfet euer Vertrauen nicht weg, welches eine große Belohnung hat.
<G-vec00819-002-s673><cast.werfen><en> 12 And he said unto them, Take me up, and cast me forth into the sea: so shall the sea be calm around you; for I know well that because of me is this great tempest upon you.
<G-vec00819-002-s673><cast.werfen><de> ELB1905(i) 12 Und er sprach zu ihnen: Nehmet mich und werfet mich ins Meer, so wird das Meer sich gegen euch beruhigen; denn ich weiß, daß dieser große Sturm um meinetwillen über euch gekommen ist.
<G-vec00819-002-s675><cast.werfen><en> Give not that which is holy unto the dogs, neither cast all of you your pearls before swine, lest they trample them under their feet, and return and rend you.
<G-vec00819-002-s675><cast.werfen><de> Gebet nicht das Heilige den Hunden; werfet auch nicht eure Perlen vor die Schweine, damit sie dieselben nicht etwa mit ihren Füßen zertreten und sich umwenden und euch zerreißen.
<G-vec00819-002-s676><cast.werfen><en> VERSE 6: "And he said unto them, Cast the net on the right side of the ship, and ye shall find.
<G-vec00819-002-s676><cast.werfen><de> 6 Er aber sprach zu ihnen: Werfet das Netz zur Rechten des Schiffs, so werdet ihr finden.
<G-vec00819-002-s678><cast.werfen><en> 20:7 I said to them, Cast away every man the abominations of his eyes, and don’t defile yourselves with the idols of Egypt; I am Yahweh your God.
<G-vec00819-002-s678><cast.werfen><de> 20:7 Und ich sprach zu ihnen: Werfet ein jeder die Scheusale seiner Augen weg, und verunreiniget euch nicht mit den Götzen Ägyptens; ich bin Jehova, euer Gott.
<G-vec00819-002-s679><cast.werfen><en> 10:36) In the preceding verse the apostle wrote, “Cast not away therefore your confidence, which hath great recompence of reward.” (vs. 35) There is the danger of losing our confidence in the Lord and in the Truth if we fail to wait patiently upon him.
<G-vec00819-002-s679><cast.werfen><de> (Hebräer 10:36) Im vorhergehenden Vers schrieb der Apostel: „Werfet nun eure Zuversicht nicht weg, die eine große Belohnung hat.” Es besteht die Gefahr, daß wir unser Vertrauen in den Herrn und die Wahrheit verlieren, wenn wir nicht geduldig auf ihn warten.
<G-vec00819-002-s680><cast.werfen><en> Jon 1, 12 And he said unto them, Take me up, and cast me forth into the sea; so shall the sea be calm unto you: for I know that for my sake this great tempest is upon you.
<G-vec00819-002-s680><cast.werfen><de> Jon 1, 12 Und er sprach zu ihnen: Nehmet mich und werfet mich ins Meer, so wird das Meer sich gegen euch beruhigen; denn ich weiß, daß dieser große Sturm um meinetwillen über euch gekommen ist.
<G-vec00819-002-s681><cast.werfen><en> And he said to them, Cast the net at the right side of the ship and ye will find.
<G-vec00819-002-s681><cast.werfen><de> Er aber sprach zu ihnen: Werfet das Netz zur Rechten des Schiffs, so werdet ihr finden.
<G-vec00819-002-s682><cast.werfen><en> Mt 22:13 - Then said the king to the servants, Bind him hand and foot, and take him away, and cast him into outer darkness; there shall be weeping and gnashing of teeth.
<G-vec00819-002-s682><cast.werfen><de> Mt 22:13 - Da sprach der König zu den Dienern: Bindet ihm Füße und Hände, nehmet ihn und werfet ihn hinaus in die äußere Finsternis: da wird sein das Weinen und das Zähneknirschen.
<G-vec00819-002-s683><cast.werfen><en> Jonah 1:12-15 And he said to them, Take me up and cast me forth into the sea, so will the sea be calm to you*. For I know that for my sake this great tempest is upon you*.
<G-vec00819-002-s683><cast.werfen><de> Jonah 1:12-15 Und er sprach zu ihnen: Nehmet mich und werfet mich ins Meer, so wird das Meer sich gegen euch beruhigen; denn ich weiß, daß dieser große Sturm um meinetwillen über euch gekommen ist.
<G-vec00819-002-s684><cast.werfen><en> He said to them, “Cast the net to the right side of the ship, and you will find some.”
<G-vec00819-002-s684><cast.werfen><de> Er aber sprach zu ihnen: Werfet das Netz auf der rechten Seite des Schiffes aus, und ihr werdet finden.
<G-vec00819-002-s686><cast.werfen><en> 7 all your care having cast upon Him, because He careth for you.
<G-vec00819-002-s686><cast.werfen><de> 7 Alle Sorge werfet auf ihn; denn er sorgt für euch.
<G-vec00819-002-s687><cast.werfen><en> “And He said unto them, Cast the net on the right side of the ship, and ye shall find” (John 21:6).
<G-vec00819-002-s687><cast.werfen><de> 21:6 Er aber sprach zu ihnen: Werfet das Netz zur Rechten des Schiffs, so werdet ihr finden.
<G-vec00819-002-s688><cast.werfen><en> Cast out the fears that paralyze you, so that you don’t become young mummies.
<G-vec00819-002-s688><cast.werfen><de> Werft die Ängste, die euch lähmen, über Bord, damit ihr euch nicht in jugendliche Mumien verwandelt.
<G-vec00819-002-s689><cast.werfen><en> 7:6 ¶ Give not that which is holy unto the dogs, neither cast ye your pearls before swine, lest they trample them under their feet, and turn again and rend you.
<G-vec00819-002-s689><cast.werfen><de> 6 Gebt das Heilige nicht den Hunden und werft eure Perlen nicht vor die Säue, damit diese sie nicht mit ihren Füßen zertreten und [jene] sich nicht umwenden und euch zerreißen.
<G-vec00819-002-s690><cast.werfen><en> (6)Give not that which is holy to the dogs, nor cast your pearls before the swine; lest they trample them with their feet, and turn and rend you.
<G-vec00819-002-s690><cast.werfen><de> 6 Gebt das Heilige nicht den Hunden, und werft eure Perlen nicht den Schweinen vor, damit sie sie nicht mit ihren Füßen zertreten, sich umwenden und euch zerreißen.
<G-vec00819-002-s691><cast.werfen><en> 22 And Reu Ben says to them, Pour no blood, but cast him into this well in the wilderness and spread no hand on him!
<G-vec00819-002-s691><cast.werfen><de> 22 Und weiter sprach Ruben zu ihnen: Vergießt nicht Blut, sondern werft ihn in die Grube, die in der Wüste ist, und legt die Hand nicht an ihn.
<G-vec00819-002-s692><cast.werfen><en> Any shadow of sin that you cast at all will immediately block your path to heaven.
<G-vec00819-002-s692><cast.werfen><de> Jeder sündige Schatten, den ihr werft, wird unweigerlich euren Eintritt in den Himmel blockieren.
<G-vec00819-002-s693><cast.werfen><en> Cast away, O people, the things ye have composed with the pen of your idle fancies and vain imaginings.
<G-vec00819-002-s693><cast.werfen><de> Werft weg, o ihr Geistlichen alle, was ihr mit den Federn eures eitlen Wahns und leeren Trugs zusammengeschrieben habt.
<G-vec00819-002-s694><cast.werfen><en> 22 And Pharaoh charged all his people, saying, Every son that is born ye shall cast into the river, and Accordance 11 Starter Collection
<G-vec00819-002-s694><cast.werfen><de> 22 Da gebot der Pharao seinem ganzen Volk und sprach: Alle Söhne, die geboren werden, werft in den Nil, aber alle Töchter lasst leben.
<G-vec00819-002-s695><cast.werfen><en> Cast them away unto such as may desire them, and fasten your eyes upon this most holy and effulgent Vision.
<G-vec00819-002-s695><cast.werfen><de> Werft sie weg für jene, die nach ihnen verlangen, und richtet euere Augen fest auf diese heiligste, diese strahlendste Schau.
<G-vec00819-002-s696><cast.werfen><en> Jesus Christ said to them, «Cast the net on the right side of the boat, and you will find some.»
<G-vec00819-002-s696><cast.werfen><de> 6 Er aber sprach zu ihnen: Werft das Netz zur Rechten des Bootes aus, so werdet ihr etwas finden.
<G-vec00819-002-s697><cast.werfen><en> He shall strengthen your heart.” “Cast your burden on the Lord, and he shall sustain you.
<G-vec00819-002-s697><cast.werfen><de> Er wird euer Herz stärken.‘ ‚Werft eure Bürde auf den Herrn, und er wird euch stützen.
<G-vec00819-002-s698><cast.werfen><en> “Cast not away therefore your boldness, which hath great recompense of reward” (Heb.
<G-vec00819-002-s698><cast.werfen><de> «Werft euer Vertrauen nicht weg, das eine große Belohnung hat» (Hebr.
<G-vec00819-002-s699><cast.werfen><en> Cast away, O people, the things ye have composed with the pen of your idle fancies and vain imaginings.
<G-vec00819-002-s699><cast.werfen><de> Werft weg, o ihr Menschen, was ihr mit der Feder eurer eitlen Vorstellungen und leeren Einbildungen zusammengeschrieben habt.
<G-vec00819-002-s700><cast.werfen><en> 12 And he said to them, Take me up, and cast me forth into the sea, so shall the sea be calm to you. For I know that for my sake this great tempest is upon you.
<G-vec00819-002-s700><cast.werfen><de> 12 Und er sprach zu ihnen: Nehmt mich und werft mich ins MeerMeer, so wird das MeerMeer sich gegen euch beruhigen; denn ich weiß, dass dieser große Sturm um meinetwillen über euch gekommen ist.
<G-vec00819-002-s701><cast.werfen><en> Cast away these false doctrines, stop committing fornication with the harlot.
<G-vec00819-002-s701><cast.werfen><de> Werft diese falschen Lehren weg, hört auf, Unzucht zu begehen mit der Hure.
<G-vec00819-002-s702><cast.werfen><en> 22And Pharaoh charged all his people, saying, Every son that is born ye shall cast into the river, and every daughter ye shall save alive.
<G-vec00819-002-s702><cast.werfen><de> 22 Da gebot der Pharao seinem ganzen Volk und sprach: Alle Söhne, die geboren werden, werft in den Nil, aber alle Töchter laßt leben.
<G-vec00819-002-s703><cast.werfen><en> They answered him, No. 6 And he said to them, Cast the net on the right side of the boat, and ye will find.
<G-vec00819-002-s703><cast.werfen><de> Sie antworteten ihm: Nein.Er aber sagte zu ihnen: Werft das Netz auf der rechten Seite des Bootes aus, und ihr werdet etwas fangen.
<G-vec00819-002-s704><cast.werfen><en> "Then the king said to the servants, 'Bind him hand and foot, take him away, and cast him into outer darkness; there will be weeping and gnashing of teeth.'
<G-vec00819-002-s704><cast.werfen><de> 13 Da sprach der König zu den Dienern: Bindet ihm Füße und Hände, und werft ihn hinaus in die äußere Finsternis: da wird das Weinen und das Zähneknirschen sein.
<G-vec00819-002-s705><cast.werfen><en> 6 Give not that which is holy to the dogs, nor cast your pearls before the swine, lest they trample them with their feet, and turning round rend you.
<G-vec00819-002-s705><cast.werfen><de> Gebt das Heilige nicht den Hunden und werft eure Perlen nicht vor die Säue, damit diese sie nicht mit ihren Füßen zertreten und [jene] sich nicht umwenden und euch zerreißen.
<G-vec00819-002-s706><cast.werfen><en> 35 Cast not away therefore your boldness, which hath great recompense of reward.
<G-vec00819-002-s706><cast.werfen><de> 35Darum werft euer Vertrauen nicht weg, welches eine große Belohnung hat.
<G-vec00819-002-s726><cast.werfen><en> If your hand or your foot causes you to stumble, cut it off, and cast it from you.
<G-vec00819-002-s726><cast.werfen><de> 8 Wenn aber deine Hand oder dein Fuß dich verführt, so hau sie ab und wirf sie von dir.
<G-vec00819-002-s727><cast.werfen><en> But so we don’t upset them needlessly, go down to the lake, cast a hook, and pull in the first fish that bites.
<G-vec00819-002-s727><cast.werfen><de> 27Damit wir ihnen aber keinen Anstoß geben, geh an den See und wirf die Angel aus.
<G-vec00819-002-s730><cast.werfen><en> 29Cut off thine hair, O Jerusalem, and cast it away, and take up a lamentation on high places; for the Lord hath rejected and forsaken the generation of his wrath.
<G-vec00819-002-s730><cast.werfen><de> 29Schere deinen Haarschmuck und wirf ihn weg, und erhebe ein Klagelied auf den kahlen Höhen: denn Jehova hat das Geschlecht seines Grimmes verworfen und verstoßen.
<G-vec00819-002-s731><cast.werfen><en> Vs 23: "For assuredly, I say to you, whoever says to this mountain, 'Be removed and be cast into the sea,' and does not doubt in his heart, but believes that those things he says will be done, he will have whatever he says."
<G-vec00819-002-s731><cast.werfen><de> 23Wahrlich, ich sage euch: Wer zu diesem Berge spräche: Heb dich und wirf dich ins Meer!, und zweifelte nicht in seinem Herzen, sondern glaubte, dass geschehen werde, was er sagt, so wird's ihm geschehen.
<G-vec00819-002-s732><cast.werfen><en> 30 And if thy right hand offend thee, cut if off, and cast it from thee: for it is profitable for thee that one of thy members should perish, and not that thy whole body should be cast into hell.
<G-vec00819-002-s732><cast.werfen><de> 30 Und wenn deine rechte Hand dir Anlaß zur Sünde gibt, so hau sie ab und wirf sie von dir; denn es ist dir besser, daß eins deiner Glieder umkommt und nicht dein ganzer Leib in die Hölle geworfen wird.
<G-vec00819-002-s733><cast.werfen><en> 29 If your right eye causes you to stumble, pluck it out and cast it from you. For it is profitable for you that one of your members should perish, than for your whole body to be cast into Gehenna.
<G-vec00819-002-s733><cast.werfen><de> 29 Wenn aber dein rechtes Auge dir Anlaß zur Sünde gibt, so reiß es aus und wirf es von dir; denn es ist dir besser, daß eins deiner Glieder umkommt und nicht dein ganzer Leib in die Hölle geworfen wird.
<G-vec00819-002-s734><cast.werfen><en> [O] Nut, cast thyself upon thy son the Osiris Pepi.
<G-vec00819-002-s734><cast.werfen><de> [O] Nut, wirf dich auf dein Sohn des Osiris Pepi.
<G-vec00819-002-s735><cast.werfen><en> 8 So if your hand or your foot leads you to sin, cut it off and cast it away from you.
<G-vec00819-002-s735><cast.werfen><de> 8Wenn aber deine Hand oder dein Fuß dich ärgert, so haue ihn ab und wirf ihn von dir.
<G-vec00819-002-s737><cast.werfen><en> 27But, lest we cause them to stumble, go thou to the sea, and cast a hook, and take up the fish that first cometh up; and when thou hast opened his mouth, thou shalt find a shekel: that take, and give unto them for me and thee.
<G-vec00819-002-s737><cast.werfen><de> ELO Matthew 17:27 Auf daß wir ihnen aber kein Ärgernis geben, geh an den See, wirf eine Angel aus und nimm den ersten Fisch, der heraufkommt, tue seinen Mund auf, und du wirst einen Stater finden; den nimm und gib ihnen für mich und dich.
<G-vec00819-002-s738><cast.werfen><en> 25 Then said Jehu to Bidkar his captain, Take up, and cast him in the portion of the field of Naboth the Jezreelite: for remember how that, when I and thou rode together after Ahab his father, the LORD laid this burden upon him;
<G-vec00819-002-s738><cast.werfen><de> 25 Und er sprach zu Bidkar, seinem Anführer: Nimm ihn und wirf ihn auf das Grundstück Naboths, des Jisreeliters.
<G-vec00819-002-s739><cast.werfen><en> 6Again the Lord said to Raphael, Bind Azazyel hand and foot; cast him into darkness; and opening the desert which is in Dudael, cast him in there.
<G-vec00819-002-s739><cast.werfen><de> 6 Ein Herr sagte zu Raphael: "Herr Azazil, mit deiner Hand und deinem Fuß, wirf ihn in die Dunkelheit und öffne die Wüste, die in Doda ist, wirf sie dorthin.
<G-vec00819-002-s740><cast.werfen><en> ¶ Wherefore cut off thine hair, and cast it away, take up a complaint in the whole land: for the LORD shall cast away, and scatter the people, that he is displeased withal.
<G-vec00819-002-s740><cast.werfen><de> 29Schneide deine Haare ab und wirf sie von dir und heule kläglich auf den Höhen; denn der HERR hat dies Geschlecht, über das er zornig ist, verworfen und verstoßen.
<G-vec00819-002-s741><cast.werfen><en> 27 Notwithstanding, lest we should offend them, go thou to the sea, and cast an hook, and take up the fish that first cometh up; and when thou hast opened his mouth, thou shalt find a piece of money: that take, and give unto them for me and thee.
<G-vec00819-002-s741><cast.werfen><de> 27 Damit wir ihnen aber keinen Anstoß geben, geh hin an das Meer und wirf die Angel aus, und den ersten Fisch, der heraufkommt, den nimm; und wenn du sein Maul aufmachst, wirst du ein Zweigroschenstück finden; das nimm und gib's ihnen für mich und dich.
<G-vec00819-002-s742><cast.werfen><en> c And if your right hand causes you to stumble, cut it off, and cast it from you (30a).
<G-vec00819-002-s742><cast.werfen><de> 33 Wenn dich deine rechte Hand zum Abfall verführt, so hau sie ab und wirf sie von dir.
<G-vec00819-002-s743><cast.werfen><en> [18:9]And if your eye offends you, pluck it out and cast it from you.
<G-vec00819-002-s743><cast.werfen><de> 9 Und wenn dein Auge dich zur Sünde verführt, dann reiß es aus und wirf es von dir.
<G-vec00819-002-s744><cast.werfen><en> And he said to him: Cast thy garment about thee and follow me,
<G-vec00819-002-s744><cast.werfen><de> Und er spricht zu ihm: Wirf dein Oberkleid um und folge mir.
<G-vec00819-002-s745><cast.werfen><en> The sight and the clarity of the light that does not cast a shadow makes use of the eye when necessary in order to show ‘that what is’.
<G-vec00819-002-s745><cast.werfen><de> Das Sehen und die Helligkeit des Lichts, welches keinen Schatten wirft, macht bei Bedarf Gebrauch vom Auge, um „das, was ist“ auszustrahlen.
<G-vec00819-002-s746><cast.werfen><en> Choose from reef fishing or shark fishing, and your captain provides instructions on how to properly cast.
<G-vec00819-002-s746><cast.werfen><de> Wählen Sie zwischen Riffangeln oder Haiangeln und Ihr Kapitän gibt Anweisungen, wie man richtig wirft.
<G-vec00819-002-s748><cast.werfen><en> This candle is made of natural waxes, that help to cast a bold flickering light.
<G-vec00819-002-s748><cast.werfen><de> Diese Kerze besteht aus natürlichen Wachsen und wirft ein kräftig flackerndes Licht.
<G-vec00819-002-s749><cast.werfen><en> John 15:6: If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00819-002-s749><cast.werfen><de> 6 Wenn jemand nicht in mir bleibt, so wird er hinausgeworfen wie die Rebe und verdorrt4; und man sammelt sie und wirft sie ins FeuerFeuer, und sie verbrennen.
<G-vec00819-002-s750><cast.werfen><en> 2Behold, the Lord hath a mighty and strong one, which as a tempest of hail and a destroying storm, as a flood of mighty waters overflowing, shall cast down to the earth with the hand.
<G-vec00819-002-s750><cast.werfen><de> 2Siehe, ein Starker und Mächtiger vom HERRN wie ein Hagelsturm, wie ein schädliches Wetter, wie ein Wassersturm, der mächtig einreißt, wirft sie zu Boden mit Gewalt, 3daß die prächtige Krone der Trunkenen von Ephraim mit Füßen zertreten wird.
<G-vec00819-002-s751><cast.werfen><en> Fitted with light bulbs at their core, the forms cast geometric shadows onto the ceilings and surroundings.
<G-vec00819-002-s751><cast.werfen><de> Das Licht in der Mitte der Körper wirft geometrische Schatten an die Umgebung.
<G-vec00819-002-s752><cast.werfen><en> The weakening outlook for the U.S. does cast some doubt on how long the Fed can continue its hiking path, though—a view backed by the rates market, which after the September meeting is now pricing in only two more Fed hikes (in December and March).
<G-vec00819-002-s752><cast.werfen><de> Der schwächer werdende Ausblick für die USA wirft jedoch Zweifel auf, wie lange die US-Notenbank (Fed) ihren Zinserhöhungskurs weiterverfolgen kann – eine Ansicht, die auch der Zinsmarkt teilt, der nach der Fed-Sitzung im September nur noch zwei weitere Zinserhöhungen (im Dezember und März) einpreist.
<G-vec00819-002-s753><cast.werfen><en> Since there has so far been no fundamental differentiation between businesses' short and medium-term outlook, the coronavirus crisis is set to cast a long shadow over the German economy.
<G-vec00819-002-s753><cast.werfen><de> Die Corona-Krise wirft einen langen Schatten auf die deutsche Wirtschaft, denn es zeigt sich bislang jedenfalls keine fundamentale Differenzierung zwischen den kurz- und mittelfristigen Erwartungen der Unternehmen.
<G-vec00819-002-s754><cast.werfen><en> If anyone does not abide in Me, he is thrown away as a branch and dries up; and they gather them, and cast them into the fire and they are burned.”
<G-vec00819-002-s754><cast.werfen><de> Wenn jemand nicht in mir bleibt, so wird er weggeworfen wie die Rebe und verdorrt; und solche sammelt man und wirft sie ins Feuer, und sie brennen.
<G-vec00819-002-s756><cast.werfen><en> 15:6 if any one may not remain in me, he was cast forth without as the branch, and was withered, and they gather them, and cast to fire, and they are burned;
<G-vec00819-002-s756><cast.werfen><de> 15:6 Wer nicht in mir bleibet, der wird weggeworfen wie eine Rebe und verdorret, und man sammelt sie und wirft sie ins Feuer, und muss brennen.
<G-vec00819-002-s757><cast.werfen><en> Alexander explains, “If we have a character standing in the key light, he’ll actually cast a shadow into the dust, smoke or fire.
<G-vec00819-002-s757><cast.werfen><de> Tim Alexander erklärt: „Wenn eine Figur im Hauptlicht steht, wirft sie einen Schatten in den Rauch, Staub oder ins Feuer.
<G-vec00819-002-s758><cast.werfen><en> The band moves to the countryside, builds up their own studio in the nowhere and cast all sketches aside.
<G-vec00819-002-s758><cast.werfen><de> Die Band zieht aufs Land, baut sich ihr eigenes Studio im Nirgendwo und wirft alle Skizzen über den Haufen.
<G-vec00819-002-s759><cast.werfen><en> In winter things often cast shadows, which are like cut-outs.
<G-vec00819-002-s759><cast.werfen><de> Sie wirft den Schatten eines Wohnblocks an der Stader Straße auf die Wand des Nachbarblocks.
<G-vec00819-002-s761><cast.werfen><en> If use tube light for reading, it probably cast a shade.
<G-vec00819-002-s761><cast.werfen><de> Wenn Sie zum Lesen Röhrenlicht verwenden, wirft es wahrscheinlich einen Schatten.
<G-vec00819-002-s762><cast.werfen><en> If a man abides not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.
<G-vec00819-002-s762><cast.werfen><de> 6 Wenn jemand nicht in mir bleibt, so wird er hinausgeworfen wie die Rebe und verdorrt; und man sammelt sie und wirft sie ins Feuer, und sie verbrennen.
