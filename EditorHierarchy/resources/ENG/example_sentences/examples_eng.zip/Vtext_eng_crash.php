<G-vec00639-002-s130><crash.abstürzen><en> • Fixed some more causes of potential crashes and improved crash reporting.
<G-vec00639-002-s130><crash.abstürzen><de> • Behoben: Weitere Gründe für potenzielle Abstürze sowie verbessertes Berichten von Abstürzen.
<G-vec00639-002-s131><crash.abstürzen><en> This design philosophy produces word processing programs that are big, slow, drain system resources, crash often, and in some cases are unable to produce the document the user requires.
<G-vec00639-002-s131><crash.abstürzen><de> Dieses Konzept führt zu Textverarbeitungsprogrammen, die sehr kompliziert und langsam sind, große Rechner-Resourcen benötigen, oft abstürzen und häufig nicht in der Lage sind, das Dokument so zu erzeugen, wie der Autor es sich eigentlich wünscht.
<G-vec00639-002-s132><crash.abstürzen><en> In practical terms, the more reliable your drive is, the less likely it is to crash.
<G-vec00639-002-s132><crash.abstürzen><de> Ganz konkret bedeutet das: Je zuverlässiger Ihr Laufwerk ist, desto niedriger ist die Wahrscheinlichkeit von Abstürzen.
<G-vec00639-002-s133><crash.abstürzen><en> Fixes a bug that can lead in certain situations the results display to crash the app.
<G-vec00639-002-s133><crash.abstürzen><de> Behebt einen Fehler der bei bestimmten Konstellationen der Ergebnisanzeige zu Abstürzen der App führen kann.
<G-vec00639-002-s134><crash.abstürzen><en> The application could crash when the library tab was openend in the preferences panel.
<G-vec00639-002-s134><crash.abstürzen><de> Die Anwendung konnte abstürzen, wenn der Bibliotheks-Tab in den Programmeinstellungen geöffnet wurde.
<G-vec00639-002-s135><crash.abstürzen><en> Just because you don't race like a pro doesn't mean you can't crash like one.
<G-vec00639-002-s135><crash.abstürzen><de> Nur weil du nicht wie ein Profi fährst, heißt das nicht, dass du nicht wie einer abstürzen kannst.
<G-vec00639-002-s136><crash.abstürzen><en> What you play today will crash, it will have slowdowns, installation issues and other problems.
<G-vec00639-002-s136><crash.abstürzen><de> Was wir heute zu sehen bekommen, wird Abstürzen, wird teilweise langsam laufen, Installations- und andere Probleme haben.
<G-vec00639-002-s137><crash.abstürzen><en> Addressed potential issues where the application could be exposed to Out-of-Bounds Read/Indexing or Heap Overflow vulnerability and crash if users were using 3D Plugin Beta.
<G-vec00639-002-s137><crash.abstürzen><de> Behandelt ein potenzielles Problem, durch das die Anwendung der Schwachstelle Out-of-Bounds Read/Indexing oder Heap Overflow ausgesetzt werden und abstürzen könnte, falls Benutzer 3D Plugin Beta verwenden.
<G-vec00639-002-s138><crash.abstürzen><en> ftpd CVE-ID: CVE-2006-4403 Available for: Mac OS X v10.3.9 Impact: When FTP Access is enabled, unauthorized users may determine account name validity Description: When attempting to authenticate a valid user, the FTP server may crash during a failed login attempt.
<G-vec00639-002-s138><crash.abstürzen><de> Verfügbar für: Mac OS X 10.3.9 Auswirkung: Wenn FTP-Zugang aktiviert ist, können nicht-autorisierte Benutzer die Validität des Account-Namens bestimmen Beschreibung: Beim Versuch, einen gültigen Beutzer zu authentifizieren, könnte der FTP-Server während eines fehlgeschlagenen Anmeldeversuchs abstürzen.
<G-vec00639-002-s139><crash.abstürzen><en> Occasional crash of MBAMService when upgrading from version 1.75 of Malwarebytes Anti-Malware should no longer occur
<G-vec00639-002-s139><crash.abstürzen><de> Es kommt nicht mehr zu gelegentlichen Abstürzen von MBAMService, wenn ein Upgrade von der Version 1.75 von Malwarebytes Anti-Malware durchgeführt wird.
<G-vec00639-002-s140><crash.abstürzen><en> Cons: Can crash at times.
<G-vec00639-002-s140><crash.abstürzen><de> Contra: Kann manchmal abstürzen.
<G-vec00639-002-s141><crash.abstürzen><en> In the event that you experience a critical error (one which causes your game client to crash to your desktop), it is possible that your data archive is corrupted.
<G-vec00639-002-s141><crash.abstürzen><de> Wenn ein kritischer Fehler auftritt (ein Fehler, der euren Spiel-Client abstürzen lässt), ist möglicherweise euer Datenarchiv beschädigt.
<G-vec00639-002-s142><crash.abstürzen><en> v7.1.1 * Resolved an issue that could cause a crash when interacting with card images on an opponent’s turn.
<G-vec00639-002-s142><crash.abstürzen><de> v7.1.1 * Es wurde ein Fehler behoben, durch den es bei Interaktionen mit Kartenbildern während des gegnerischen Spielzuges zu Abstürzen kommen konnte.
<G-vec00639-002-s143><crash.abstürzen><en> Spell Catcher X version 10.3.6 works around a crash using the Look Up window if Safari 5.0 is installed.
<G-vec00639-002-s143><crash.abstürzen><de> Spell Catcher X Version 10.3.6 umgeht einen Fehler, der Spell Catcher abstürzen ließ, sobald das Fenster Nachschlagen aufgerufen wurde, falls Safari 5.0 installiert ist.
<G-vec00639-002-s144><crash.abstürzen><en> Of course, no operating system is perfect, and people who tell you that theirs can never ever crash are lying.
<G-vec00639-002-s144><crash.abstürzen><de> Natürlich ist kein Betriebssystem perfekt, und Leute, die dir erzählen, ihr Betriebssystem könne niemals abstürzen, lügen.
<G-vec00639-002-s145><crash.abstürzen><en> It looked as if the object would crash.
<G-vec00639-002-s145><crash.abstürzen><de> Es sah aus, als würde das Objekt abstürzen.
<G-vec00639-002-s146><crash.abstürzen><en> [Fixed] Issue where double-clicking on an Excel document to open it from File Explorer would crash Microsoft Excel.
<G-vec00639-002-s146><crash.abstürzen><de> [Fixed] Problem, bei dem Doppelklick auf ein Excel-Dokument aus dem Datei-Explorer zu öffnen, würde abstürzen Microsoft Excel.
<G-vec00639-002-s147><crash.abstürzen><en> Addressed potential issues where the application could be exposed to Type Confusion Remote Code Execution vulnerability and crash.
<G-vec00639-002-s147><crash.abstürzen><de> Behebung potentieller Probleme, bei denen die Anwendung einer „Type Confusion Remote Code Execution“-Schwachstelle ausgesetzt sein und abstürzen könnte.
<G-vec00639-002-s148><crash.abstürzen><en> Some games require that the phone time be consistent with the server time, or they may crash.
<G-vec00639-002-s148><crash.abstürzen><de> Manche Spiele erfordern, dass die Uhrzeit am Telefon mit der Serverzeit übereinstimmt, da sie sonst abstürzen können.
<G-vec00639-002-s149><crash.abstürzen><en> Some customer feedback PhoneRescue may crash or freeze occasionally.
<G-vec00639-002-s149><crash.abstürzen><de> Wir erhalten manchmal Feedback von den Kunden, dass PhoneRescue gelegentlich abstürzt oder einfriert ist.
<G-vec00639-002-s150><crash.abstürzen><en> + Network State: To determine whether or not you are connected to the Internet so the game doesn't crash while trying to connect.
<G-vec00639-002-s150><crash.abstürzen><de> + Network State: Um festzustellen, ob Sie mit dem Internet verbunden sind, so dass das Spiel nicht abstürzt, beim Versuch zu verbinden.
<G-vec00639-002-s151><crash.abstürzen><en> In some files, the system might be corrupted due to the improper shutting down of the computer or system crash.
<G-vec00639-002-s151><crash.abstürzen><de> Wiederherstellung der RAW-Partition In einigen Dateien ist das System möglicherweise beschädigt, weil der Computer nicht ordnungsgemäß heruntergefahren wurde oder das System abstürzt.
<G-vec00639-002-s152><crash.abstürzen><en> Timing is of the essence for if you do not withdraw quick enough, you lose the wager as the rate will most likely ‘crash’, hence the name CSGO Crash. CSGO Poker
<G-vec00639-002-s152><crash.abstürzen><de> Das Timing ist von entscheidender Bedeutung, denn wenn Sie nicht schnell genug aussteigen, verlieren Sie den Einsatz, da die Rate höchstwahrscheinlich abstürzt – oder eben crasht – daher der Name CS:GO-Crash.
<G-vec00639-002-s153><crash.abstürzen><en> Even though following above mentioned tips and tricks, still there are chances of Operating System to crash and may results in loss of data.
<G-vec00639-002-s153><crash.abstürzen><de> Trotz der oben genannten Tipps und Tricks besteht immer noch die Gefahr, dass das Betriebssystem abstürzt und Daten verloren gehen können.
<G-vec00639-002-s154><crash.abstürzen><en> Microsoft does not follow this specification. Due to this oversite it is possible to cause Outlook 2000 to consume an unreasonably high amount of CPU time, or to completely crash.
<G-vec00639-002-s154><crash.abstürzen><de> Microsoft hält sich nicht an diese Spezifikation und demnach ist es möglich, dass Outlook 2000 bei langen Einträgen sehr viel CPU-Zeit braucht oder gleich vollständig abstürzt.
<G-vec00639-002-s155><crash.abstürzen><en> If you get the same crash message when you try to start in Safe Mode, follow the section on Firefox not starting in Safe Mode.
<G-vec00639-002-s155><crash.abstürzen><de> Wenn Firefox im Abgesicherten Modus startet, testen Sie bitte, ob Firefox auch im Abgesicherten Modus abstürzt.
<G-vec00639-002-s156><crash.abstürzen><en> In very rare cases an extension update might cause your Joomla website to partly/fully crash.
<G-vec00639-002-s156><crash.abstürzen><de> In sehr seltenen Fällen kann ein Erweiterungs-Update dazu führen, dass Ihre Joomla-Webseite teilweise oder vollständig abstürzt.
<G-vec00639-002-s157><crash.abstürzen><en> You may need to turn the switch to the OFF position occasionally should your computer crash and you cannot shut it down using the soft switch.
<G-vec00639-002-s157><crash.abstürzen><de> Wenn Ihr PC abstürzt und Sie ihn nicht mithilfe dieses Schalters abschalten können, bringen Sie den Hauptschalter in die Position AUS (O).
<G-vec00639-002-s158><crash.abstürzen><en> Rooted Users: If you use a utility to revoke permissions, Wifi Fixer will crash.
<G-vec00639-002-s158><crash.abstürzen><de> Verwurzelt-Benutzer: Wenn Sie ein Dienstprogramm verwenden, um Berechtigungen zu widerrufen, Wifi Fixer abstürzt.
<G-vec00639-002-s159><crash.abstürzen><en> graves de virus: Severe virus attack is one of the main factor which causes hard drive to crash.
<G-vec00639-002-s159><crash.abstürzen><de> Schwere Virenbefall: Schwere Virenbefall ist eine der Hauptfaktor, der die Festplatte abstürzt.
<G-vec00639-002-s160><crash.abstürzen><en> Check to see if the crash happens in Safe Mode If updating software didn't work or if Firefox crashes on startup, use the steps below to test whether the crash happens in Firefox Safe Mode or not and then follow the instructions in the recommended articles.
<G-vec00639-002-s160><crash.abstürzen><de> Prüfen Sie, ob Firefox auch im Abgesicherten Modus abstürzt Wenn das Aktualisieren von Programmen nicht funktioniert hat oder wenn Firefox beim Starten abstürzt, führen Sie folgende Schritte aus, um zu sehen, ob der Absturz auch im Abgesicherten Modus von Firefox auftritt oder nicht.
<G-vec00639-002-s161><crash.abstürzen><en> Acclaimed writer Dave Justus (Fables: The Wolf Among Us) weaves a gripping interactive story through the aftermath of a crash landing on an alien moon.
<G-vec00639-002-s161><crash.abstürzen><de> Der bekannte Autor Dave Justus (Fables: The Wolf Among Us) erzählt eine spannende, interaktive Geschichte über einen Wissenschaftler, der mit einem Raumschiff auf einem fremden Planeten abstürzt.
<G-vec00639-002-s162><crash.abstürzen><en> It works quite well on old systems, but it has been known to crash upon being installed in new systems.
<G-vec00639-002-s162><crash.abstürzen><de> Es funktioniert recht gut auf alten Systemen, aber es ist bekannt, dass es bei der Installation in neuen Systemen abstürzt.
<G-vec00639-002-s163><crash.abstürzen><en> It allows remote attackers to cause a Denial-of-Service (crash) via certain crafted requests.
<G-vec00639-002-s163><crash.abstürzen><de> Angreifer können über das Netzwerk einen Denial-of-Service auslösen, indem sie spezielle Anfragen an den Server richten, wodurch die Applikation abstürzt.
<G-vec00639-002-s164><crash.abstürzen><en> Certain core files should not be deleted or modified, if you do it could cause your entire computer to crash, causing major damage to your hard drive and computer, because it might be a root file that your computer withdrawals information from to perform tasks.
<G-vec00639-002-s164><crash.abstürzen><de> Bestimmte Core-Dateien sollten nicht gelöscht oder verändert werden; wenn du dies tust, könnte dies dazu führen, dass dein Computer abstürzt und größere Schäden an der Festplatte und am Computer verursacht, da es eine Root-Datei sein könnte, aus der dein Computer Daten zieht, um Dinge auszuführen.
<G-vec00639-002-s388><crash.abstürzen><en> • Adding more than 100 stations in Creative mode will no longer crash.
<G-vec00639-002-s388><crash.abstürzen><de> • Das Hinzufügen von mehr als 100 Stationen im Kreativmodus stürzt nicht länger ab.
<G-vec00639-002-s389><crash.abstürzen><en> If you rise too high with the glider, you go into tailspin, crash and are at the ground again with the bike.
<G-vec00639-002-s389><crash.abstürzen><de> Steigt man mit dem Gleiter zu hoch, kommt man ins trudeln, stürzt ab und befindet sich wieder am Bike am Boden.
<G-vec00639-002-s390><crash.abstürzen><en> When running a failover pair of DHCP servers, the peer names need to be consistent, otherwise DHCP will crash.
<G-vec00639-002-s390><crash.abstürzen><de> Beim Betrieb eines Ausfall-Übergabepaars von DHCP-Servern müssen die Namen der Partner konsistent sein, andernfalls stürzt DHCP ab.
<G-vec00639-002-s391><crash.abstürzen><en> Mining usually takes up to 100% of system resources, and thus it becomes unstable, virtually unusable (it barely responds), is likely to crash.
<G-vec00639-002-s391><crash.abstürzen><de> Das Problem ist, dass das Schürfen in der Regel bis zu 100% der Systemressourcen beansprucht, weshalb es instabil (System stürzt sehr wahrscheinlich ab) und praktisch unbrauchbar (es reagiert kaum) wird.
<G-vec00639-002-s392><crash.abstürzen><en> In the GroupWise Linux client, if you display a Web page that includes Flash content, and if you have Adobe Flash Player 9 installed in your Web browser, the GroupWise Linux client might crash.
<G-vec00639-002-s392><crash.abstürzen><de> Wenn Sie auf dem GroupWise-Linux-Client eine Webseite mit Flash-Inhalt anzeigen und Adobe Flash Player 9 in Ihrem Webbrowser installiert ist, stürzt der GroupWise-Linux-Client eventuell ab.
<G-vec00639-002-s393><crash.abstürzen><en> In other situations it makes my game just crash.
<G-vec00639-002-s393><crash.abstürzen><de> In anderen Situationen stürzt mein Spiel einfach ab.
<G-vec00639-002-s394><crash.abstürzen><en> Typing Japanese characters at the end of a line where the text flows to the next line causes FrameMaker to crash.
<G-vec00639-002-s394><crash.abstürzen><de> Bei der Eingabe von japanischen Zeichen am Ende einer Zeile, wobei der Text in die nächste Zeile fließt, stürzt FrameMaker ab.
<G-vec00639-002-s395><crash.abstürzen><en> You can activate a part of the codebits of an enemy, but never all, because the level is going to crash instead of loading, if you want to start it.
<G-vec00639-002-s395><crash.abstürzen><de> Bei Gegnern kann man auch verschiedene Codebits aktivieren, man sollte aber nie alle aktivieren, denn dann stürzt das Level bereits bei dem Laden ab.
<G-vec00639-002-s396><crash.abstürzen><en> If you manage to break into the Evaluate toolbar while it is executing a typed in script, you can no longer crash Spike2 by attempting to step or run to cursor.
<G-vec00639-002-s396><crash.abstürzen><de> Gelingt das Eindringen in die Evaluate-Symbolleiste, während sie ein eingegebenes Skript ausführt, so stürzt Spike2 jetzt nicht mehr ab, wenn versucht wird, zum Cursor zu gehen.
<G-vec00639-002-s397><crash.abstürzen><en> This release is known to crash after (in the original boxed version) you would normally have to switch CDs.
<G-vec00639-002-s397><crash.abstürzen><de> Diese Version stürzt ab, nachdem du (in der originalen Box-Version) normalerweise die CDs wechseln müsstest.
<G-vec00639-002-s398><crash.abstürzen><en> Illustrator crashes during or after launch. Specifically, using an input device (for example, a mouse, stylus, tablet device, or others) causes the application to crash immediately.
<G-vec00639-002-s398><crash.abstürzen><de> Illustrator stürzt beim oder nach dem Start ab.Insbesondere unter Verwendung eines Eingabegeräts (zum Beispiel mit einer Maus, einem Stift, Tablet oder anderen Geräten) stürzt die Anwendung kurz nach dem Start ab.
<G-vec00639-002-s399><crash.abstürzen><en> If you use videos created from other devices, the app might crash.
<G-vec00639-002-s399><crash.abstürzen><de> Wenn Sie Videos verwenden, die mit anderen Geräten erstellt wurden, stürzt die App möglicherweise ab.
<G-vec00639-002-s312><crash.krachen><en> With a big crash they both came down to the ground, accompanied by a loud growl and cackle that ended abruptly.
<G-vec00639-002-s312><crash.krachen><de> Mit lautem Krachen stürzten sie beide zu Boden, begleitet von einem lauten Knurren und Gackern, das aber abrupt aufhörte.
<G-vec00639-002-s313><crash.krachen><en> The flying stones hit the troll’s catapults with a powerful crash.
<G-vec00639-002-s313><crash.krachen><de> Die zurückfliegenden Steine schlugen mit einem mächtigen Krachen in die Katapulte der Trolle.
<G-vec00639-002-s314><crash.krachen><en> Silver bells tinkle and jingle; golden bells rhyme and chime; brazen bells clang and crash and roar in warning; iron bells toll and moan and groan in despair.
<G-vec00639-002-s314><crash.krachen><de> Silberne Glocken klingeln und klingeln; goldene Glocken Reim und Glockenspiel; schamlose Glocken klirren und krachen und brüllen in Warnung; Eisenglocken läuten und stöhnen und stöhnen verzweifelt.
<G-vec00639-002-s315><crash.krachen><en> With a loud crash, the castle’s main tower collapsed.
<G-vec00639-002-s315><crash.krachen><de> Mit einem lauten Krachen stürzte der Burgturm ein.
<G-vec00639-002-s316><crash.krachen><en> I was scared I was going to crash into one of those souls, or energies.
<G-vec00639-002-s316><crash.krachen><de> Ich befürchtete dass ich in eine dieser Seelen oder Energien krachen würde.
<G-vec00639-002-s317><crash.krachen><en> In the surroundings of the municipality of Yaiza, we find places of extraordinary natural beauty: El Golfo, whose name is due to the shellfish that used to live in its waters, is the cone of the volcano that has in its interior a green coloured lagoon; Los Hervideros, caves over which the waves of the sea crash with such force that they seem to boil; and Las Salinas del Janubio - in the past, the most important source of income on the island - that is now in the process of being regenerated.
<G-vec00639-002-s317><crash.krachen><de> Im Umlan von Yaiza finden wir Landschaften von außerordentlicher Schoenheit: El Golfo, desen Name von den Schalentieren stammt, die in dieser Gegend vorkommen, ist der vulkanische Kegel, der in seinem Inneren eine gruene Lagune birgt; Los Hervideros, Hoehlen in die die Wellen mit socher Wucht krachen, das die See zu kochen scheint; und die Salinen von Janubio, die in der Vergangenheit die wichtigste Einkommenquelle der Insel darstellte, befindet sich jetzt in los Remedios.
<G-vec00639-002-s318><crash.krachen><en> This calm spell was suddenly replaced by a turmoil in which the whistle of the gusts of wind and the crash of the waves against the hull of my boat announced the imminence of a furious storm.
<G-vec00639-002-s318><crash.krachen><de> Dieser ruhige Zauber wurde durch einen Sturm gebrochen, in dem das Pfeifen der Windböen und das Krachen der Wellen gegen den Rumpf meines Bootes den drohenden Sturm ankündigten.
<G-vec00639-002-s319><crash.krachen><en> 3 - 4 ft. waves crash on the sandy beach and rocks.
<G-vec00639-002-s319><crash.krachen><de> Aufkommende Fluten waschen den am Strand liegenden Seetang, hohe Wellen krachen gegen die Felsen.
<G-vec00639-002-s320><crash.krachen><en> Rivals make mistakes and crash into surroundings, bigger vehicles will bully smaller ones, who in turn try to avoid being crushed.
<G-vec00639-002-s320><crash.krachen><de> Deine Gegner machen Fahrfehler und krachen in die Umgebung, und größere Fahrzeuge drängen kleinere ab, die zusehen müssen, dass sie nicht unter die Räder kommen.
<G-vec00639-002-s321><crash.krachen><en> The sailors considered even a mermaid to be a bad sign, just flashed on the horizon - they believed that after that their ship would certainly be doomed to crash.
<G-vec00639-002-s321><crash.krachen><de> Die Matrosen betrachteten sogar eine Meerjungfrau als ein schlechtes Zeichen, das nur am Horizont aufblitzte - sie glaubten, dass danach ihr Schiff dazu verdammt sein würde zu krachen.
<G-vec00639-002-s322><crash.krachen><en> Whether for the bike park or the local mountain - 180mm of travel offer enough reserve to let it crash neatly.
<G-vec00639-002-s322><crash.krachen><de> Egal ob für den Bikepark oder den heimischen Berg - 180mm Federweg bieten genug Reserve, um es ordentlich krachen zu lassen.
<G-vec00639-002-s323><crash.krachen><en> In the end they both crash directly into the cabin of the forest police.
<G-vec00639-002-s323><crash.krachen><de> Am Ende krachen beide genau in die Hütte der Forstpolizei.
<G-vec00639-002-s324><crash.krachen><en> 10 “On that day,” declares the Lord, “a cry will be heard from the Fish Gate, a wail from the Second Quarter, a loud crash from the hills.
<G-vec00639-002-s324><crash.krachen><de> 10 An jenem Tag, spricht der HERR, wird ein Geschrei vom Fischtor her erschallen und ein Geheul vom zweiten Stadtteil her und ein großes Krachen von den Hügeln her.
<G-vec00639-002-s325><crash.krachen><en> Two men arriving from Holland break through a customs check and crash into a patrol car as they flee.
<G-vec00639-002-s325><crash.krachen><de> Zwei aus Holland einreisende Männer durchbrechen eine Zollkontrolle und krachen auf ihrer Flucht in einen Streifenwagen.
<G-vec00639-002-s326><crash.krachen><en> All these are the best assets to let it crash with the Mugello.
<G-vec00639-002-s326><crash.krachen><de> All dies sind also beste Anlagen, um es mit der Mugello auch mal krachen zu lassen.
