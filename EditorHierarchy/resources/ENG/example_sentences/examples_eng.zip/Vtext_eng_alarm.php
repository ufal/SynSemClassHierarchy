<G-vec00547-001-s057><alarm.auslösen><en> The function should be a demand detector to set an alarm in time if the hopper gets empty and more material should be filled in.
<G-vec00547-001-s057><alarm.auslösen><de> Die Funktion sollte ein Bedarfsdetektor sein, um rechtzeitig einen Alarm auszulösen, wenn der Behälter leer ist und mehr Material eingefüllt werden sollte.
<G-vec00547-001-s058><alarm.auslösen><en> But even if it is located close to the bottom of the uterus, doctors are not in a hurry to sound the alarm, as with the course of pregnancy it can rise.
<G-vec00547-001-s058><alarm.auslösen><de> Aber selbst wenn es sich in der Nähe des Uterusbodens befindet, haben Ärzte keine Eile, den Alarm auszulösen, da sie mit dem Verlauf der Schwangerschaft ansteigen können.
<G-vec00547-001-s059><alarm.auslösen><en> Don't hesitate to release an alarm, even if the situation seems not that critical.
<G-vec00547-001-s059><alarm.auslösen><de> Zögern Sie nicht, einen Alarm auszulösen, auch wenn die Lage noch nicht so kritisch erscheint.
<G-vec00547-001-s060><alarm.auslösen><en> However, if there are no seals in the mammary gland and no discharge from the nipples, you should not worry about it: the fact is that pain is characteristic of the last stages of tumor development, but if there were no complaints before, then there is no need to sound the alarm .
<G-vec00547-001-s060><alarm.auslösen><de> Wenn es jedoch keine Versiegelungen in der Brustdrüse und keinen Ausfluss aus den Brustwarzen gibt, sollten Sie sich darüber keine Sorgen machen: Tatsache ist, dass der Schmerz für die letzten Stadien der Tumorentwicklung charakteristisch ist, aber wenn vorher keine Beschwerden aufgetreten sind Es ist nicht nötig, den Alarm auszulösen.
<G-vec00547-001-s061><alarm.auslösen><en> There are waste material collecting boxes in five stations sim card punching equipment, with detecting sensors to make alarm if it will be full.
<G-vec00547-001-s061><alarm.auslösen><de> In fünf Stationen gibt es Abfallsammelboxen für Kartenausstanzungen, bei denen Sensoren erkannt werden, um Alarm auszulösen, wenn er voll ist.
<G-vec00547-001-s062><alarm.auslösen><en> These attacks by internal and external reaction would have been sufficient to sound the alarm and make Allende reflect.
<G-vec00547-001-s062><alarm.auslösen><de> All diese Angriffe durch die innere und äußere Reaktion hätten genügt, um Alarm auszulösen und hätten Allende wachrütteln müssen.
<G-vec00547-001-s063><alarm.auslösen><en> But if the mark on the scales for some unknown reason, stubbornly creeps up, then it is worth sounding the alarm.
<G-vec00547-001-s063><alarm.auslösen><de> Wenn jedoch die Markierung auf der Waage aus irgendeinem unbekannten Grund hartnäckig nach oben kriecht, lohnt es sich, den Alarm auszulösen.
<G-vec00547-001-s064><alarm.auslösen><en> Don't hesitate to release an alarm - even if the situation seems not that critical to you.
<G-vec00547-001-s064><alarm.auslösen><de> Scheuen Sie sich nicht, einen Alarm auszulösen - selbst wenn aus Ihrer Sicht die Situation noch nicht sehr kritisch erscheint.
<G-vec00547-001-s065><alarm.auslösen><en> But if the mark on the scales, for some unknown reason, stubbornly creeps upwards, then it is worth sounding the alarm.
<G-vec00547-001-s065><alarm.auslösen><de> Wenn jedoch die Markierung auf der Waage aus einem unbekannten Grund hartnäckig auftaucht, lohnt es sich, den Alarm auszulösen.
<G-vec00547-001-s066><alarm.auslösen><en> TheST341 (O2) Deficiency Detector is designed specifically to alarm when oxygen levels deviate from the ambient value of 20.9%.
<G-vec00547-001-s066><alarm.auslösen><de> Der ST340 Sauerstoffmangeldetektor wurde speziell dafür konzipiert, einen Alarm auszulösen, wenn die Sauerstoffwerte vom Umgebungswert von 20,9 % abweichen.
<G-vec00547-001-s067><alarm.auslösen><en> With a one-time decrease in blood pressure to the level of 90 to 80, it is not necessary to sound the alarm and set yourself a diagnosis.
<G-vec00547-001-s067><alarm.auslösen><de> Bei einem einmaligen Blutdruckabfall auf 90 bis 80 ist es nicht erforderlich, einen Alarm auszulösen und eine Diagnose zu stellen.
<G-vec00547-001-s068><alarm.auslösen><en> Solutions from Siemens are built to detect fires as early as possible, to alarm and activate the preprogrammed control functions.
<G-vec00547-001-s068><alarm.auslösen><de> Die Lösungen von Siemens sind darauf ausgelegt, Brände so früh wie möglich zu erkennen, Alarm auszulösen und die vorprogrammierten Steuerfunktionen zu aktivieren.
<G-vec00761-002-s184><alarm.alarmieren><en> Whilst there is the threat of a violent attack, it is important that the alarm is sounded as quickly as possible within a building or campus.
<G-vec00761-002-s184><alarm.alarmieren><de> Amok-Sicherheit Amok-Sicherheit Während einer Amok-Bedrohung ist es wichtig, dass innerhalb eines Gebäudes oder Campus so schnell als möglich alarmiert wird.
<G-vec00761-002-s185><alarm.alarmieren><en> With an inspecting device, will alarm and stop the machine automatically if the wire dropping improperly.
<G-vec00761-002-s185><alarm.alarmieren><de> Bei einem Inspektionsgerät wird die Maschine automatisch alarmiert und angehalten, wenn der Draht nicht ordnungsgemäß abfällt.
<G-vec00761-002-s186><alarm.alarmieren><en> In practical application, this means that an alarm is issued immediately when a camera is rotated, for example so that employees could be "observed" at their workstation.
<G-vec00761-002-s186><alarm.alarmieren><de> In der Anwendung bedeutet das, es wird sofort alarmiert, wenn eine Kamera verdreht wird, zum Beispiel so dass Mitarbeiter an Ihrem Arbeitsplatz „observiert“ werden könnten.
<G-vec00761-002-s187><alarm.alarmieren><en> This contrast does not alarm the fish of any size.
<G-vec00761-002-s187><alarm.alarmieren><de> Dieser Kontrast alarmiert den Fisch in keiner Größe.
<G-vec00761-002-s188><alarm.alarmieren><en> This means that the camera always keeps an eye on the essentials and only triggers an alarm for security-relevant events.
<G-vec00761-002-s188><alarm.alarmieren><de> So behält die Kamera stets das Wesentliche im Blick und alarmiert nur bei sicherheitsrelevanten Ereignissen.
<G-vec00761-002-s189><alarm.alarmieren><en> The alarm system is a simple, cheap and particularly effective way of raising an alarm/message.
<G-vec00761-002-s189><alarm.alarmieren><de> Das Alarmsystem ist eine einfache, preisgünstige und besonders effektive Art und Weise, alarmiert zu werden.
<G-vec00761-002-s190><alarm.alarmieren><en> The machine would alarm with sound and light signal when detecting specific objects; baggage screening machine
<G-vec00761-002-s190><alarm.alarmieren><de> Merkmal Das Gerät alarmiert beim Erkennen bestimmter Objekte mit einem Ton- und Lichtsignal.
<G-vec00761-002-s191><alarm.alarmieren><en> The monitor can monitor up to 34 wheels, and triggers an alarm if tyre air pressure drops.
<G-vec00761-002-s191><alarm.alarmieren><de> Der Monitor kann bis zu 34 Räder überwachen und alarmiert bei Abfallen des Reifendrucks.
<G-vec00761-002-s192><alarm.alarmieren><en> The lamp displays a color status LED indicates the current lighting mode and alarm with red light at a low battery level.
<G-vec00761-002-s192><alarm.alarmieren><de> Die Lampe zeigt über eine farbige Status LED den aktuellen Leuchtmodus an und alarmiert mit roten Licht bei einem niedrigen Akkustand.
<G-vec00761-002-s193><alarm.alarmieren><en> When in late September Turkish President Recep Tayyip Erdogan criticised the Treaty of Lausanne, which established the borders of modern Turkey, the neighbouring states reacted with alarm.
<G-vec00761-002-s193><alarm.alarmieren><de> Als der türkische Präsident Recep Tayyip Erdoğan Ende September Kritik am Vertrag von Lausanne äußerte, in dem die Grenzen der modernen Türkei festgelegt worden sind, waren die Nachbarn alarmiert.
<G-vec00761-002-s194><alarm.alarmieren><en> The camera is further protected with shock detection, a capability that sends an alarm to personnel during attempted vandalism.
<G-vec00761-002-s194><alarm.alarmieren><de> Die Kamera ist außerdem mit einer Schock-Erkennung ausgestattet, die das Personal im Falle eines Vandalismusversuchs alarmiert.
<G-vec00761-002-s195><alarm.alarmieren><en> I had felt discomfort in that area in recent weeks, and with some alarm she said that I should come back for a more invasive cleaning as soon as possible, along with coming in more frequently for regular cleanings.
<G-vec00761-002-s195><alarm.alarmieren><de> Die Stelle hatte sich seit ein paar Wochen schmerzhaft angefühlt, und die Frau sagte alarmiert, dass ich sobald wie möglich eine Tiefenreinigung benötigte und danach häufiger zur normalen Reinigung kommen müsse.
<G-vec00761-002-s196><alarm.alarmieren><en> “He didn’t hit you, right?“ Don asked in alarm and his hands were looking for injuries.
<G-vec00761-002-s196><alarm.alarmieren><de> “Er hat dich nicht etwa doch getroffen, oder?“, fragte Don alarmiert und seine Hände suchten nach Verletzungen.
<G-vec00761-002-s197><alarm.alarmieren><en> The European Union is among those viewing these developments with alarm.
<G-vec00761-002-s197><alarm.alarmieren><de> Auch die Europäische Union ist alarmiert.
<G-vec00761-002-s198><alarm.alarmieren><en> The recipient is sent an alarm message to notify them as soon as the document has been uploaded to the Adarvo server.
<G-vec00761-002-s198><alarm.alarmieren><de> Die Empfänger werden alarmiert, sobald das Dokument auf den Adarvo-Server hochgeladen wurde.
<G-vec00761-002-s199><alarm.alarmieren><en> The smoke alarm alerts you with an audible signal in the event of a fire and automatically triggers an emergency call.
<G-vec00761-002-s199><alarm.alarmieren><de> Der Rauchmelder alarmiert Sie im Brandfall mit einem akustischen Signal und löst automatisch einen Anruf aus.
<G-vec00761-002-s200><alarm.alarmieren><en> Such high energy consumption and the resulting air pollution have set alarm bells ringing in government quarters.
<G-vec00761-002-s200><alarm.alarmieren><de> Der hohe Energieverbrauch und die damit verbundene Luftverschmutzung haben die chinesische Regierung alarmiert.
<G-vec00761-002-s201><alarm.alarmieren><en> A window appears on its screen showing the Beacon number and ID parallel to an audible high frequency alarm – now, the crew is immediately informed about the case of emergency.
<G-vec00761-002-s201><alarm.alarmieren><de> Sofort erscheint auf seinem Bildschirm ein Hinweis mit Senderkennung und ID, begleitet von einem Hochfrequenzton — die Crew ist sofort alarmiert (siehe kleines Bild rechts).
<G-vec00761-002-s202><alarm.alarmieren><en> Beginning at 35 ppm the instrument gives off an alarm sound, the interval between them becomes shorter as the concentration increases and the tone is emitted as a permanent warning sound above 200 ppm.
<G-vec00761-002-s202><alarm.alarmieren><de> Ab 35 ppm alarmiert Sie das Gerät zudem mit einem Ton, dessen Intervall sich bei steigender Konzentration verkürzt und der ab 200 ppm als permanenter Warnton ausgegeben wird.
