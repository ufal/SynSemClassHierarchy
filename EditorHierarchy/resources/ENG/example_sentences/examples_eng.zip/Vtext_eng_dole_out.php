<G-vec00209-003-s059><dole_out.verschenken><en> 1970s The Morse family starts to dole out generous samples to its customers.
<G-vec00209-003-s059><dole_out.verschenken><de> 1970s Die Morse Familie beginnt großzügig Proben an ihre Kunden zu verschenken.
<G-vec00209-003-s018><dole_out.weitermachen><en> If he says something mean and you look visibly upset, then he'll only be encouraged to dole out more of the same.
<G-vec00209-003-s018><dole_out.weitermachen><de> Wenn er etwas Gemeines sagt und man dir ansieht, dass dich das aufregt, wird ihn das nur dazu anstacheln weiterzumachen.
