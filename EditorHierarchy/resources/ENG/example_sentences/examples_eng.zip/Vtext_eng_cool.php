<G-vec00463-002-s019><cool.abkühlen><en> That may cool your Surface down.
<G-vec00463-002-s019><cool.abkühlen><de> Möglicherweise wird das Surface hierdurch abgekühlt.
<G-vec00463-002-s020><cool.abkühlen><en> Make sure that the appliance is cool before you touch it.
<G-vec00463-002-s020><cool.abkühlen><de> Vergewissern Sie sich, dass das Gerät abgekühlt ist, bevor Sie es anfassen.
<G-vec00463-002-s021><cool.abkühlen><en> Iran continues to arm the terrorist organizations despite its cool relations with Hamas.
<G-vec00463-002-s021><cool.abkühlen><de> Der Iran bewaffnet die Terrororganisationen auch weiterhin, obwohl sich seine Beziehungen mit der Hamas stark abgekühlt haben.
<G-vec00463-002-s022><cool.abkühlen><en> Once the iron is cool, empty the water tank.
<G-vec00463-002-s022><cool.abkühlen><de> Sobald das Bügeleisen abgekühlt ist, leeren Sie den Wassertank.
<G-vec00463-002-s023><cool.abkühlen><en> Now wait for your radiators to cool down - depending on your home, this may take an hour or so, but it is important for the next step.
<G-vec00463-002-s023><cool.abkühlen><de> Warte nun bis deine Heizkörper abgekühlt sind - je nach Gebäudeeigenschaften kann dies eine Stunde oder sogar mehr dauern - aber es ist wichtig für den nächsten Schritt.
<G-vec00463-002-s024><cool.abkühlen><en> Snow / Ice Room / Frigidarium – dry and cold room intended to cool the body.
<G-vec00463-002-s024><cool.abkühlen><de> Schnee- / Eiszimmer / Frigidarium – ein trockener, kalter Raum, in dem man bleibt bis der Körper abgekühlt wird.
<G-vec00463-002-s025><cool.abkühlen><en> When the appliance is cool again, an acoustic signal sounds and the door unlocks.
<G-vec00463-002-s025><cool.abkühlen><de> Sobald das Gerät abgekühlt ist, ertönt ein akustisches Signal, und die Backofentür wird entriegelt.
<G-vec00463-002-s026><cool.abkühlen><en> The more advanced model comes with an automatic refrigeration system and variable temperature controls that can be set to cool the drinks to any temperature between 7 and 12 degrees Celsius.
<G-vec00463-002-s026><cool.abkühlen><de> Das erweiterte Modell ist mit einem automatischen Kühlsystem und variablen Temperaturreglern ausgestattet, mit denen die Getränke auf jede Temperatur zwischen sieben und 12 °C abgekühlt werden können.
<G-vec00463-002-s027><cool.abkühlen><en> If you are using chocolate decorations, allow the ganache to cool down a bit. Otherwise your decorations will melt.
<G-vec00463-002-s027><cool.abkühlen><de> Wenn man Schokodekoration verwendet, sollte man vielleicht warten bis die Ganache etwas abgekühlt ist, sonst schmilzt die Deko.
<G-vec00463-002-s028><cool.abkühlen><en> The sheet must remain in the correct shape until it is completely cool and hard again.
<G-vec00463-002-s028><cool.abkühlen><de> Die Platte muss in der richtigen Form bleiben, bis sie wieder vollständig abgekühlt und hart ist.
<G-vec00463-002-s029><cool.abkühlen><en> Following stirring for 2 hours at room temperature, the mixture was allowed to cool to room temperature, water was added, the product was extracted into toluene, and the organic layer was washed sequentially with water and a saturated aqueous solution of sodium chloride before being dried over anhydrous sodium sulfate.
<G-vec00463-002-s029><cool.abkühlen><de> Nach dem Rühren für 2 Stunden bei Raumtemperatur wurde das Gemisch auf Raumtemperatur abgekühlt, Wasser wurde zugegeben, das Produkt wurde in Toluol extrahiert, und die organische Schicht wurde nacheinander gewaschen mit Wasser und gesättigter wässriger Lösung an Natriumchlorid, bevor es über wasserfreiem Natriumsulfat getrocknet wurde.
<G-vec00463-002-s030><cool.abkühlen><en> Wait for the machine to cool down before you touch the internal parts of the machine.
<G-vec00463-002-s030><cool.abkühlen><de> Warten Sie, bis sich das Gerät abgekühlt hat, bevor Sie Teile im Inneren des Gerätes berühren.
<G-vec00463-002-s031><cool.abkühlen><en> Let yourself completely dry and let your body cool down before you put clothes on, or you may immediately start sweating.
<G-vec00463-002-s031><cool.abkühlen><de> Achte darauf, dass dein Körper vollkommen trocken ist und du dich ein wenig abgekühlt hast, bevor du dich anziehst, da du sonst sofort wieder beginnen würdest zu schwitzen.
<G-vec00463-002-s032><cool.abkühlen><en> When the mixture is cool, add the eggs and the breadcrumbs until you can shape it.
<G-vec00463-002-s032><cool.abkühlen><de> Sobald die Mischung abgekühlt ist, die Eier und Paniermehl unterrühren bis ein formbarer Teig entsteht.
<G-vec00463-002-s033><cool.abkühlen><en> In this refrigerator ash remains can cool off to a temperature that is safe and acceptable for further processing.
<G-vec00463-002-s033><cool.abkühlen><de> In dieser Abkühleinheit kann die Asche auf eine für die weitere Verarbeitung akzeptable Temperatur abgekühlt werden.
<G-vec00463-002-s034><cool.abkühlen><en> Get proactive with prospects and move then from ‘cool’ to ‘qualified’ through instant engagement, information and advice via real-time messaging.
<G-vec00463-002-s034><cool.abkühlen><de> Gehen Sie proaktiv mit Interessenten um und lassen Sie ‘abgekühlt’ zu ‘qualifiziert’ werden durch sofortige Ansprache, Informationsweitergabe und Beratung durch Echtzeit-Nachrichten.
<G-vec00463-002-s035><cool.abkühlen><en> For working operations in which materials have a high temperature, it is necessary to let them cool down first.
<G-vec00463-002-s035><cool.abkühlen><de> Für Arbeitsvorgänge, bei denen die Materialien eine hohe Temperatur haben, müssen sie zuerst abgekühlt werden.
<G-vec00463-002-s036><cool.abkühlen><en> If this happens, wait for the projector's internal components to cool down.
<G-vec00463-002-s036><cool.abkühlen><de> Warten Sie in einem derartigen Fall, bis die internen Komponenten abgekühlt sind.
<G-vec00463-002-s037><cool.abkühlen><en> Then, the mash is smeared on a plate and allowed to cool off for about 30 minutes.
<G-vec00463-002-s037><cool.abkühlen><de> Sodann wird der Jahressuppenbrei auf einen Teller gestrichen und abgekühlt, was etwa 30 Minuten dauert.
<G-vec00733-002-s038><cool.abkühlen><en> ▼ Add, emulsify and leave to cool in refrigerator.
<G-vec00733-002-s038><cool.abkühlen><de> Ein anderes Produkt Hinzufügen, emulgieren und im Kühlschrank abkühlen lassen.
<G-vec00733-002-s039><cool.abkühlen><en> Pout into a heat-proof container and let cool.
<G-vec00733-002-s039><cool.abkühlen><de> Etwas abkühlen lassen und auf die Creme streichen.
<G-vec00733-002-s040><cool.abkühlen><en> This conflict depleted the finances of the a Lasco family, caused the relationship between John a Lasco and the pacifist Erasmus to cool down, and ended his church career in Poland.
<G-vec00733-002-s040><cool.abkühlen><de> Dieser Konflikt zehrte stark an den Finanzen der Familie a Lasco, ließ Johannes a Lascos persönliche Beziehung zu dem pazifistisch gesonnenen Erasmus abkühlen und beendete seine kirchliche Karriere in Polen.
<G-vec00733-002-s041><cool.abkühlen><en> Fill it into a bowl and let it cool to slightly above lukewarm.
<G-vec00733-002-s041><cool.abkühlen><de> Dann in eine Schüssel füllen und auf etwas mehr als Handwärme abkühlen lassen.
<G-vec00733-002-s042><cool.abkühlen><en> Heat everything to 80° in the bain-marie and then let cool.
<G-vec00733-002-s042><cool.abkühlen><de> Dann im Wasserbad auf 80° erhitzen und abkühlen lassen.
<G-vec00733-002-s043><cool.abkühlen><en> Our brakes still needed to cool down.
<G-vec00733-002-s043><cool.abkühlen><de> Außerdem mussten unsere Bremsen immer noch abkühlen.
<G-vec00733-002-s044><cool.abkühlen><en> Remove from heat and let the sweets cool completely, they fall apart easily while warm.
<G-vec00733-002-s044><cool.abkühlen><de> Nach dem Dämpfen von der Hitze nehmen, und erstmal im Dampftopf offen abkühlen lassen.
<G-vec00733-002-s045><cool.abkühlen><en> Allow the mixture to cool down to a comfortable and drinkable temperature.
<G-vec00733-002-s045><cool.abkühlen><de> Lasse die Mischung auf eine angenehme und trinkbare Temperatur abkühlen.
<G-vec00733-002-s046><cool.abkühlen><en> When done, remove and let cool.
<G-vec00733-002-s046><cool.abkühlen><de> Nach der Garzeit herausnehmen und abkühlen lassen.
<G-vec00733-002-s047><cool.abkühlen><en> Let the cake cool completely before frosting.
<G-vec00733-002-s047><cool.abkühlen><de> Lasse den Kuchen vollkommen abkühlen, bevor du ihn glasierst.
<G-vec00733-002-s048><cool.abkühlen><en> Paper shredders need to cool down after a while, to prevent overheating.
<G-vec00733-002-s048><cool.abkühlen><de> Aktenvernichter müssen sich nach einer Weile abkühlen, um ein Überhitzen zu verhindern.
<G-vec00733-002-s049><cool.abkühlen><en> Turn the unit off and let it cool down for 15 minutes.
<G-vec00733-002-s049><cool.abkühlen><de> Schalten Sie das Gerät aus und lassen Sie es 15 Minuten abkühlen.
<G-vec00733-002-s050><cool.abkühlen><en> From here there is only a few steps to the pool, where you can cool down on a hot summer day.
<G-vec00733-002-s050><cool.abkühlen><de> Von hier sind es nur ein paar Schritte zum Pool, wo Sie sich an einem heißen Sommertag abkühlen können.
<G-vec00733-002-s051><cool.abkühlen><en> This process ensures that, especially taking into account its weight, this kind of fireplace has a considerable heat storage capacity, and it also allows the temperature of exiting flue gases to cool down to a safe level.
<G-vec00733-002-s051><cool.abkühlen><de> Diese Lösung bietet eine für die Masse des Speicherofens große Speicherwärmemenge und lässt die zum Schornstein strömenden Rauchgase auf einen unbedenklichen Wert abkühlen.
<G-vec00733-002-s052><cool.abkühlen><en> Take out of the oven, let cool down some time in the tins, then remove and let cool down completely on a wire rack.
<G-vec00733-002-s052><cool.abkühlen><de> Aus dem Ofen nehmen, in den Formen etwas abkühlen lassen und dann herausnehmen und auf einem Kuchengitter komplett auskühlen lassen.
<G-vec00733-002-s053><cool.abkühlen><en> Let cool slightly before serving.
<G-vec00733-002-s053><cool.abkühlen><de> Etwas abkühlen lassen.
<G-vec00733-002-s054><cool.abkühlen><en> And water can be added anytime - before, during or after an ironing session - without having to wait for the iron to cool down.
<G-vec00733-002-s054><cool.abkühlen><de> Es kann jederzeit Wasser nachgefüllt werden – vor, beim oder nach dem Bügeln –, ohne dass das Bügeleisen vorher abkühlen muss.
<G-vec00733-002-s055><cool.abkühlen><en> Leave to cool down completely under the blanket.
<G-vec00733-002-s055><cool.abkühlen><de> Vollständig unter der Decke abkühlen lassen.
<G-vec00733-002-s056><cool.abkühlen><en> Mix chocolate & cream until the whole chocolate is completely melted, then place the chocolate ganache in the fridge to cool down.
<G-vec00733-002-s056><cool.abkühlen><de> Schokolade & Sahne verrühren bis die Schokolade komplett geschmolzen ist, die Schokoladenganache anschließend zum Abkühlen in den Kühlschrank stellen.
<G-vec00733-002-s076><cool.abkühlen><en> Remove and set aside to cool slightly.
<G-vec00733-002-s076><cool.abkühlen><de> Beiseite stellen, um etwas abzukühlen.
<G-vec00733-002-s077><cool.abkühlen><en> Afterwards, take a sunbath on the lawn, a popular gathering spot for Berliners and tourists alike, and literally cool off in the shadow of history.
<G-vec00733-002-s077><cool.abkühlen><de> Im Anschluss lädt der Rasen vor dem Reichstag zu einem Sonnenbad oder dazu, sich buchstäblich im Schatten der Geschichte abzukühlen.
<G-vec00733-002-s078><cool.abkühlen><en> Pool was always available and ready to cool off after returning from tour.
<G-vec00733-002-s078><cool.abkühlen><de> Pool war immer verfügbar und bereit, um sich abzukühlen nach der Rückkehr aus der Tourenplanung.
<G-vec00733-002-s079><cool.abkühlen><en> On a hot summer day, this is exactly the place to cool down.
<G-vec00733-002-s079><cool.abkühlen><de> An einem heissen Sommertag ist das genau der richtige Ort, um sich abzukühlen.
<G-vec00733-002-s080><cool.abkühlen><en> The procedure in this steps will heat the drill bit’s face up, so getting a cup of cold water readily available by your side to dip the tip of the drill bit into is advisable to cool it off.
<G-vec00733-002-s080><cool.abkühlen><de> Das Verfahren in diesen Schritten wird die Vorderseite des Bohrers aufwärmen, so dass es ratsam ist, eine Tasse kaltes Wasser an Ihrer Seite zur Verfügung zu haben, um die Spitze des Bohrers einzubringen, um es abzukühlen.
<G-vec00733-002-s081><cool.abkühlen><en> Then they are put to one side to cool before being refried in hotter oil until bien croustillantes – crisp and golden on the outside.
<G-vec00733-002-s081><cool.abkühlen><de> Anschließend werden sie zur Seite gestellt, um abzukühlen, bevor sie in noch heißerem Öl noch einmal frittiert werden, bis sie bien croustillantes sind – außen knusprig und goldfarben.
<G-vec00733-002-s082><cool.abkühlen><en> The temperatures are quite ok but the dogs are happy to find places to cool themselves down.
<G-vec00733-002-s082><cool.abkühlen><de> Die Temperaturen sind am Morgen recht gut, dafür allerdings suchen die Hunde jede Gelegenheit um sich abzukühlen.
<G-vec00733-002-s083><cool.abkühlen><en> The villa has a swimming pool which is the perfect way to cool off when the sun gets a bit too hot as well as a garden.
<G-vec00733-002-s083><cool.abkühlen><de> Die Villa verfügt über einen Swimmingpool, das ist der perfekte Weg, um sich abzukühlen, wenn die Sonne ein bisschen zu heiß wird, sowie einen Garten.
<G-vec00733-002-s084><cool.abkühlen><en> Thus, being veg is the fastest way to cool the planet.
<G-vec00733-002-s084><cool.abkühlen><de> Daher ist, vegan zu leben, der schnellste Weg, den Planeten abzukühlen.
<G-vec00733-002-s085><cool.abkühlen><en> The bath water is really hot and you can also take a cold shower to cool off afterward.
<G-vec00733-002-s085><cool.abkühlen><de> Das Badewasser ist sehr heiß und man kann auch eine kalte Dusche nehmen, um sich danach abzukühlen.
<G-vec00733-002-s086><cool.abkühlen><en> This was more than a mere attempt to keep cool.
<G-vec00733-002-s086><cool.abkühlen><de> Es ging nicht bloß um einen Versuch, sich abzukühlen.
<G-vec00733-002-s087><cool.abkühlen><en> We frequently had to stop to fill up cooling liquid and to cool down the hot engine.
<G-vec00733-002-s087><cool.abkühlen><de> Permanent mussten wir anhalten, um Kühlflüssigkeit nachzufüllen und den heißgelaufenen Motor abzukühlen.
<G-vec00733-002-s088><cool.abkühlen><en> Wipe the oven floor with a damp cloth (keep one fit for this purpose) to slightly cool it
<G-vec00733-002-s088><cool.abkühlen><de> Wischen Sie anschließend den Ofenboden mit einem dafür geeigneten feuchten Tuch ab, um ihn leicht abzukühlen.
<G-vec00733-002-s089><cool.abkühlen><en> Good reception, great breakfast and a lovely terrace to cool off.
<G-vec00733-002-s089><cool.abkühlen><de> Guter Empfang, gutes Frühstück und eine schöne Terrasse, um sich abzukühlen.
<G-vec00733-002-s090><cool.abkühlen><en> Firstly, especially in the summer time, water is excellent to cool off your dog and secondly, water, as is known, makes it easier to exercise and makes your own weight lighter.
<G-vec00733-002-s090><cool.abkühlen><de> Zum einen ist Wasser gerade im Sommer hervorragend geeignet, um Ihren Hund abzukühlen und zum anderen werden Bewegungen und auch das eigene Körpergewicht im Wasser bekanntermaßen erleichtert.
<G-vec00733-002-s091><cool.abkühlen><en> In the past, researchers have tried to cool solids to very low temperatures, leaving the atoms almost frozen.
<G-vec00733-002-s091><cool.abkühlen><de> Deshalb haben Forscher in der Vergangenheit versucht, Festkörper auf sehr niedrige Temperaturen abzukühlen.
<G-vec00733-002-s092><cool.abkühlen><en> After sex, you can take a shower to cool off.
<G-vec00733-002-s092><cool.abkühlen><de> Nach dem Sex kann man natürlich duschen um abzukühlen.
<G-vec00733-002-s093><cool.abkühlen><en> The perfect place to cool off with a bath without even having to leave the hotel.
<G-vec00733-002-s093><cool.abkühlen><de> Der perfekte Ort, um sich mit einem Bad abzukühlen, ohne das Hotel verlassen zu müssen.
<G-vec00733-002-s094><cool.abkühlen><en> During the summer months many take to the local swimming pools to cool off and enjoy time with family and friends.
<G-vec00733-002-s094><cool.abkühlen><de> Während der Sommermonate gehen viele in die örtlichen Schwimmbäder, um sich abzukühlen und Zeit mit Familie und Freunden zu verbringen.
<G-vec00733-002-s114><cool.auskühlen><en> Remove from the heat and leave to cool.
<G-vec00733-002-s114><cool.auskühlen><de> Herausnehmen und auskühlen lassen.
<G-vec00733-002-s115><cool.auskühlen><en> Mousse: (1) Gently heat 200 g of the base recipe, (2) soften 5 g of gelatin in cold water, (3) mix in a bowl and (4) allow to cool.
<G-vec00733-002-s115><cool.auskühlen><de> Mousse: (1) 200 g Grundmasse erwärmen, (2) zwei Blatt Gelatin in kaltem Wasser einweichen, ausdrücken, (3) in die Grundmasse einrühren und (4) auskühlen lassen.
<G-vec00733-002-s116><cool.auskühlen><en> The basketball sweater keeps you nicely warm so your muscles won’t cool too quickly.
<G-vec00733-002-s116><cool.auskühlen><de> Die Basketballsweater halten dich schön warm, damit deine Muskeln nicht zu schnell auskühlen.
<G-vec00733-002-s117><cool.auskühlen><en> Take out of the oven, let cool down some time in the tins, then remove and let cool down completely on a wire rack.
<G-vec00733-002-s117><cool.auskühlen><de> Aus dem Ofen nehmen, in den Formen etwas abkühlen lassen und dann herausnehmen und auf einem Kuchengitter komplett auskühlen lassen.
<G-vec00733-002-s118><cool.auskühlen><en> Let cool completely, then cut in half and fill with pastry cream and fruit preserve or jam.
<G-vec00733-002-s118><cool.auskühlen><de> Lass sie komplett auskühlen, schneide sie dann halb durch und fülle sie mit Hilfe eines Spritzbeutels mit der Crème und Marmelade.
<G-vec00733-002-s119><cool.auskühlen><en> f After using, place the power tool down in a secure manner and allow it to cool down completely before packing it away.
<G-vec00733-002-s119><cool.auskühlen><de> f Legen Sie das Elektrowerkzeug nach Ge- brauch sicher ab und lassen Sie es vollstän- dig auskühlen, bevor Sie es wegpacken.
<G-vec00733-002-s120><cool.auskühlen><en> Let the cinnamon rolls cool briefly and mix the ingredients for the frosting in the meantime.
<G-vec00733-002-s120><cool.auskühlen><de> Die Zimtschnecken hinterher kurz auskühlen lassen und in der Zwischenzeit die Zutaten für das Frosting verrühren.
<G-vec00733-002-s121><cool.auskühlen><en> Roll up the roll while it is still hot and let it cool down.
<G-vec00733-002-s121><cool.auskühlen><de> Die Rolle noch heiß mit dem Backpapier einrollen und auskühlen lassen.
<G-vec00733-002-s122><cool.auskühlen><en> Allow to cool slightly and blend smooth using an immersion blender.
<G-vec00733-002-s122><cool.auskühlen><de> Etwas auskühlen lassen und mit einem Stabmixer fein pürieren.
<G-vec00733-002-s123><cool.auskühlen><en> Let slightly cool and sprinkle with powdered sugar.
<G-vec00733-002-s123><cool.auskühlen><de> Leicht auskühlen lassen und nach Belieben mit Staubzucker bestreuen.
<G-vec00733-002-s124><cool.auskühlen><en> Take out and allow them to cool off for 2 min. on the tray, then put them onto a cooling rack.
<G-vec00733-002-s124><cool.auskühlen><de> * Herausnehmen und erst noch zwei Minuten auf dem Bleck, dann auf einem Kuchengitter auskühlen lassen.
<G-vec00733-002-s125><cool.auskühlen><en> Remove from the pan, allow to cool.
<G-vec00733-002-s125><cool.auskühlen><de> Aus der Form lösen, auskühlen lassen.
<G-vec00733-002-s126><cool.auskühlen><en> Let cool completely in pans on wire racks.
<G-vec00733-002-s126><cool.auskühlen><de> Auskühlen lassen und in 3 Böden teilen.
<G-vec00733-002-s127><cool.auskühlen><en> Allow base to cool after baking.
<G-vec00733-002-s127><cool.auskühlen><de> Nach dem Backen auskühlen lassen.
<G-vec00733-002-s128><cool.auskühlen><en> Let the bottom cool down.
<G-vec00733-002-s128><cool.auskühlen><de> Den Boden etwas auskühlen lassen.
<G-vec00733-002-s129><cool.auskühlen><en> Method: Boil the water and leave to cool.
<G-vec00733-002-s129><cool.auskühlen><de> Wasser aufkochen und auskühlen lassen.
<G-vec00733-002-s130><cool.auskühlen><en> Remove the loaves from the oven, cool for 10 minutes in the cardboard pans, before carefully removing the cardboard and leaving the cakes to fully cool (for best results chill in the refrigerator overnight).
<G-vec00733-002-s130><cool.auskühlen><de> Brot aus dem Ofen nehmen, 10 Minuten in den Förmchen abkühlen lassen, diese stürzen und das Brot vollständig auskühlen lassen (am besten über Nacht im Kühlschrank).
<G-vec00733-002-s131><cool.auskühlen><en> Try to avoid the Cool down or slow down at least by you wear the Smartphone close to the body, for example, in the inside pockets of coat and jacket – and the Smartphone is not in the coat or jacket pockets on the outside carry.
<G-vec00733-002-s131><cool.auskühlen><de> Versuchen Sie das Auskühlen zu vermeiden oder zumindest zu verlangsamen, indem Sie das Smartphone eng am Körper tragen, beispielsweise in den Innentaschen von Mantel und Jacke – und das Smartphone nicht in den Mantel- oder Jackenaußentaschen transportieren.
<G-vec00733-002-s132><cool.auskühlen><en> Let your hair cool back down.
<G-vec00733-002-s132><cool.auskühlen><de> Lasse dein Haar auskühlen.
