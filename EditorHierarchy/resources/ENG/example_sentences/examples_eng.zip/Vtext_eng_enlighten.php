<G-vec00531-002-s033><enlighten.aufklären><en> Since it is designed to enlighten, a lamp must first and foremost to be functional.
<G-vec00531-002-s033><enlighten.aufklären><de> Da es aufklären soll, muss eine Lampe in erster Linie funktional sein.
<G-vec00531-002-s042><enlighten.aufzeigen><en> In collaboration with your IT team, we will test your systems, enlighten its vulnerability and train your staff.
<G-vec00531-002-s042><enlighten.aufzeigen><de> In Zusammenarbeit mit Ihrem IT-Team, werden wir Ihre Systeme testen, seine Verwundbarkeit aufzeigen und Ihre Mitarbeiter schulen.
<G-vec00531-002-s054><enlighten.beleuchten><en> Rotating art exhibitions, ranging from paintings and tapestries to ceramics, enlighten visitors while exploring themes such as culture, identity, and power.
<G-vec00531-002-s054><enlighten.beleuchten><de> Wechselnde Kunstausstellungen, die von Gemälden und Wandteppichen bis hin zu Keramik reichen, beleuchten die Themen wie Kultur, Identität und Macht.
<G-vec00531-002-s140><enlighten.bringen><en> The qualified herb specialist is delighted to enlighten people on the effects of healing plants and herbs.
<G-vec00531-002-s140><enlighten.bringen><de> Die ausgebildete Kräuterfachfrau freut sich, den Menschen die Wirkung der Heilpflanzen und Kräuter näher zu bringen.
<G-vec00531-002-s067><enlighten.entdecken><en> We must not only sow ideas but also expose truths and enlighten the world about the immense hypocrisy of the West.
<G-vec00531-002-s067><enlighten.entdecken><de> Man muss nicht nur Ideen säen, sondern auch Wahrheiten entdecken.
<G-vec00531-002-s128><enlighten.entzünden><en> As far back as our ancestors knew the custom to enlighten a light or even a fire in the middle of the darkest, he longest of all nights and to bring green branches inside their homes in the middle of winter as a symbol for the life isn’t over, isn’t “dead” in the dark winter, but that it only draws breath for the fresh start in the spring.
<G-vec00531-002-s128><enlighten.entzünden><de> Schon unsere Vorfahren kannten den Brauch, mitten in der dunkelsten, der längsten Nacht des Jahres ein Licht oder gar ein Feuer zu entzünden und sich mitten im Winter grüne Zweige in die Wohnung zu holen als Symbol dafür, dass das Leben auch mitten im dunklen Winter nicht zu Ende, nicht „tot“ ist, sondern dass das Leben weitergeht, dass es nur Luft holt für den Neubeginn im Frühjahr.
<G-vec00531-002-s068><enlighten.erhellen><en> Defiantly, she raised her chin: “If you can’t deal with ridicule, then enlighten me.
<G-vec00531-002-s068><enlighten.erhellen><de> Störrisch reckte sie das Kinn vor: "Wenn du Spott nicht erträgst, erhelle mich.
<G-vec00531-002-s126><enlighten.erkennen><en> They are not well organized and do not enlighten to the seriousness of their actions.
<G-vec00531-002-s126><enlighten.erkennen><de> Sie handeln nicht gewissenhaft und erkennen die Ernsthaftigkeit ihres Handelns nicht.
<G-vec00531-002-s138><enlighten.erleuchten><en> So Father, I pray that you will enlighten our minds with these words.
<G-vec00531-002-s138><enlighten.erleuchten><de> So lieber Vater, ich bitte, daß du unser Verständnis erleuchtest.
<G-vec00531-002-s124><enlighten.erzählen><en> If not, enlighten us about yer previous positions.
<G-vec00531-002-s124><enlighten.erzählen><de> Wenn nicht, erzähle uns, was du vorher getrieben hast.
<G-vec00531-002-s040><enlighten.geben><en> If this is his serious will, he will recognise the truth and his work will begin.... to enlighten his fellow human beings as well.
<G-vec00531-002-s040><enlighten.geben><de> Ist dies sein ernster Wille, dann erkennt er die Wahrheit, und nun setzt auch seine Arbeit ein.... auch dem Mitmenschen Aufklärung zu geben.
<G-vec00531-002-s041><enlighten.geben><en> These few will take their worldly knowledge across with them as well and from there they will also be able to enlighten those people in regards to worldly questions who think like them by acknowledging God.... but this will only seldom be the case.
<G-vec00531-002-s041><enlighten.geben><de> (5.4.1965) Diese wenigen werden auch ihr Weltwissen mit hinübernehmen und wieder von dort aus auch in weltlichen Fragen den Menschen Aufklärung geben können, die nun genauso denken, daß sie Gott anerkennen.... was aber nur selten der Fall sein wird.
<G-vec00531-002-s078><enlighten.gewinnen><en> When I corrected myself and truly practiced cultivation, I was able to enlighten more while studying the Fa and could even participate in the morning exercises.
<G-vec00531-002-s078><enlighten.gewinnen><de> Als ich mich korrigierte und mich wirklich kultivierte, konnte ich beim Fa-Lernen weitere Erkenntnisse gewinnen und konnte sogar bei den Morgenübungen mitmachen.
<G-vec00531-002-s131><enlighten.klären><en> Enlighten your peasant brothers, banish ignorance from the villages, call on the peasant poor to support the workers of town and country in their glorious struggle.
<G-vec00531-002-s131><enlighten.klären><de> Klärt eure Brüder, die Bauern, auf: vertreibt die Finsternis aus dem Dorf, ruft die Dorfarmut auf, die Arbeiter in Stadt und Land in ihrem ruhmvollen Kampf zu unterstützen.
<G-vec00531-002-s123><enlighten.kommen><en> I knew I should try to enlighten to this myself.
<G-vec00531-002-s123><enlighten.kommen><de> Da wusste ich, dass ich selbst zur Erleuchtung kommen sollte.
<G-vec00531-002-s133><enlighten.leisten><en> But in its role as a platform for a functional and knowledgebased exchange between experts, stakeholder and political decision-makers on a European level, the Intergroup can enlighten the situation, close some knowledge gaps and develop constructive solution concepts, if necessary with legislative impacts.
<G-vec00531-002-s133><enlighten.leisten><de> Als Plattform für einen sachlichen und auf Fachwissen basierenden Austausch zwischen Experten, Betroffenen und politischen Entscheidungsträgern auf europäischer Ebene kann sie aber einen Beitrag zum besseren Verständnis der Situation leisten, Wissenslücken schließen und konstruktive Lösungskonzepte, gegebenenfalls mit gesetzgeberischer Wirkung, entwickeln.
<G-vec00531-002-s135><enlighten.leuchten><en> 11 And you did cleave the sea before them, and they passed through the midst of the sea on dry land; and you did cast into the deep them that were about to pursue them, as a stone in the mighty water. 12 And you guided them by day by a pillar of cloud, and by night by a pillar of fire, to enlighten for them the way wherein they should walk.
<G-vec00531-002-s135><enlighten.leuchten><de> 11 Und hast das Meer vor ihnen zerrissen, daß sie mitten im Meer trocken hindurchgingen, und ihre Verfolger in die Tiefe geworfen wie Steine in mächtige Wasser 12 und sie geführt des Tages in einer Wolkensäule und des Nachts in einer Feuersäule, ihnen zu leuchten auf dem Weg, den sie zogen.
<G-vec00531-002-s136><enlighten.machen><en> But olive oil is not more needed to enlighten the dark or to massage the muscles as the Greek and Roman athletes have done.
<G-vec00531-002-s136><enlighten.machen><de> Aber Olivenöl wird nicht mehr benötigt um Licht zu machen oder die Muskeln zu massieren, wie es die griechischen und römischen Athleten getan haben.
<G-vec00531-002-s137><enlighten.werfen><en> And in his preface to this book, de Martonne adds his voice to Romanian protests, he says ‘It is not too late to enlighten public opinion about Dobruja.
<G-vec00531-002-s137><enlighten.werfen><de> Im Vorwort zum Buch befürwortet De Martonne mit einer starken Stimme die Position Rumäniens mit den Worten: ‚Es ist noch nicht zu spät, ein Licht auf die Situation der rumänischen Region Dobrudscha zu werfen und die Öffentlichkeit darüber richtig zu informieren.
<G-vec00531-002-s056><enlighten.überprüfen><en> Do not hesitate any longer to widen your boundaries or to enlighten your own Workforce.
<G-vec00531-002-s056><enlighten.überprüfen><de> Zögern Sie also nicht, Ihre Grenzen zu erweitern oder Ihren Bestand an eigenen Arbeitskräften zu überprüfen.
