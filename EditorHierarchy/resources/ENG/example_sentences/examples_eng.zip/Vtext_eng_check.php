<G-vec00090-002-s152><check.checken><en> Just download the application, sign in using your Feedly account and observe how the program synchronizes them so you can check the news without opening your browser.
<G-vec00090-002-s152><check.checken><de> Einfach die App downloaden, registrieren mit dem Feedly Account und beobachten, wie das Programm sie synchronisiert, so dass man die News checken kann, ohne den Browser zu öffnen.
<G-vec00090-002-s153><check.checken><en> We had to stop very often to check the map.
<G-vec00090-002-s153><check.checken><de> Wir mussten immer wieder anhalten und die Karte checken.
<G-vec00090-002-s154><check.checken><en> Our forecast updates every 3 hours and enable you to check the weather forecast for the next 14 days in Ischgl.
<G-vec00090-002-s154><check.checken><de> Unsere Vorhersage wird alle 3 Stunden aktualisiert und ermöglicht es den Wetterbericht der nächsten 14 Tage für Waitakerezu checken.
<G-vec00090-002-s155><check.checken><en> They design and write code, they layout screens, they debug, they integrate, and they check things into the source code control repository.
<G-vec00090-002-s155><check.checken><de> Sie designen und schreiben Code, entwerfen Benutzerschnittstellen, sie debuggen, sie integrieren und checken alles in ein Repository ein.
<G-vec00090-002-s156><check.checken><en> Our forecast updates every 3 hours and enable you to check the weather forecast for the next 14 days in Marseille.
<G-vec00090-002-s156><check.checken><de> Unsere Vorhersage wird alle 3 Stunden aktualisiert und ermöglicht es den Wetterbericht der nächsten 14 Tage für Salamancazu checken.
<G-vec00090-002-s157><check.checken><en> Surf the internet and check your e-mails using the free Wi-Fi internet connection in the Hotel Orion’s lobby.
<G-vec00090-002-s157><check.checken><de> In der Lobby des Hotel Orion können Sie mit kostenfreiem WLAN im Internet surfen und Ihre E-Mails checken.
<G-vec00090-002-s158><check.checken><en> To rule out a software bug, I took both programs to check the situation in the 19m.
<G-vec00090-002-s158><check.checken><de> Um einen Softwarefehler auszuschließen, nahm ich beide Programme um die Situation im 19m zu checken.
<G-vec00090-002-s159><check.checken><en> Here you will be able to check on your health and any injuries you've sustained, as well as bandage limbs and administer other medical treatment.
<G-vec00090-002-s159><check.checken><de> Hier kannst du deine Gesundheit und alle deine davongetragenen Verletzungen checken, Extremitaeten bandagieren sowie anderweitige medizinische Versorgung durchfuehren.
<G-vec00090-002-s160><check.checken><en> Our forecast updates every 3 hours and enable you to check the weather forecast for the next 14 days in Malta.
<G-vec00090-002-s160><check.checken><de> Unsere Vorhersage wird alle 3 Stunden aktualisiert und ermöglicht es den Wetterbericht der nächsten 14 Tage für Slowenienzu checken.
<G-vec00090-002-s161><check.checken><en> You can check trip duration and compare ticekt prices on the Zurich Airport - Montreux route.
<G-vec00090-002-s161><check.checken><de> Sie können bei uns alle verfügbaren Fahrten von Lausanne nach Zürich Flughafen und wieder zurück einsehen, Preise checken und die Reisezeiten vergleichen.
<G-vec00090-002-s162><check.checken><en> Our forecast updates every 3 hours and enable you to check the weather forecast for the next 14 days in France.
<G-vec00090-002-s162><check.checken><de> Unsere Vorhersage wird alle 3 Stunden aktualisiert und ermöglicht es den Wetterbericht der nächsten 14 Tage für Frankreichzu checken.
<G-vec00090-002-s163><check.checken><en> With this app, you don’t even need to log onto your Instagram account to check out new photos, like a photo, and more.
<G-vec00090-002-s163><check.checken><de> Mit dieser App müssen Sie sich nicht einmal auf Ihrem Instagram-Konto anmelden, um neue Fotos und mehr zu checken.
<G-vec00090-002-s164><check.checken><en> We wish farewell to the horses and the crew before returning to Ulaanbaatar, where we check in to a hotel of choice.
<G-vec00090-002-s164><check.checken><de> Wir nehmen Abschied von der Crew und den Pferden, fahren zurück nach Ulaanbaatar und checken in einem Hotel unserer Wahl ein.
<G-vec00090-002-s165><check.checken><en> It has thus become possible to ask the device for directions, check email, spend time playing video games or simply surf the Internet.
<G-vec00090-002-s165><check.checken><de> Somit ist es möglich geworden, in den unterschiedlichsten Situationen das eigene Smartphone nach dem Weg zu fragen, E-Mails zu checken, die Zeit mit Computerspielen zu verbringen oder einfach nur im Internet herum zu surfen.
<G-vec00090-002-s166><check.checken><en> We used the day to become acclimatised and to check our equipment.
<G-vec00090-002-s166><check.checken><de> Wir haben den Tag heute benutzt um uns zu akklimatisieren und das Equipment zu checken.
<G-vec00090-002-s167><check.checken><en> Authors check their chapter in and out and log the status of their work.
<G-vec00090-002-s167><check.checken><de> Die AutorInnen checken ihre Kapitel ein und aus und setzen den Status ihrer Arbeit.
<G-vec00090-002-s168><check.checken><en> You can also work in your holidays. There are many holiday jobs, part-time or full-time jobs for students, which you can do without any problems (check your visa if you are a foreigner).
<G-vec00090-002-s168><check.checken><de> In den Ferien gibt es auch ganz viele Jobs für Studenten: Ferienjobs oder Teil –oder Vollzeit Jobs, die man ohne Problem machen kann (wenn du Ausländer bist, muss du dein Visum checken).
<G-vec00090-002-s169><check.checken><en> Our staff will check you in, assign you a parking space and help you transfer your luggage to the shuttle bus.
<G-vec00090-002-s169><check.checken><de> Unsere Mitarbeiter checken dich ein, weisen dir einen Parkplatz zu, helfen dir mit dem Umladen deines Gepäcks in den Shuttlebus.
<G-vec00090-002-s170><check.checken><en> After disembarking the ship in Bergen, you will fly to Oslo and check in to your hotel.
<G-vec00090-002-s170><check.checken><de> Wenn Sie in Bergen von Bord gehen, fliegen Sie nach Oslo und checken in Ihrem Hotel ein, das fußläufig von der Busstation entfernt liegt.
<G-vec00090-002-s171><check.checken><en> Check the latest news from Kraków.
<G-vec00090-002-s171><check.checken><de> Checken Sie die aktuellsten Neuigkeiten aus Krakau.
<G-vec00090-002-s172><check.checken><en> Do NOT check this on a public computer, like in an internet cafe.
<G-vec00090-002-s172><check.checken><de> Checken Sie nicht dies auf einem öffentlichen Computer, wie ein Internetcafé.
<G-vec00090-002-s173><check.checken><en> Check the shipping time and costs by country.
<G-vec00090-002-s173><check.checken><de> Checken Sie Versand Zeiten und Kosten nach andere Ländern.
<G-vec00090-002-s174><check.checken><en> Check in for your flight on your iPhone. Download your boarding pass to Passbook/Wallet on your iPhone through the British Airways app.
<G-vec00090-002-s174><check.checken><de> Checken Sie einfach ein und greifen Sie über die British Airways Mobile App oder über unsere Website auf Ihre Bordkarte zu, bevor Sie den Flughafen erreichen.
<G-vec00090-002-s175><check.checken><en> On the designated day, pack your luggage for the both of you and check in first.
<G-vec00090-002-s175><check.checken><de> Packen Sie am geplanten Termin das Gepäck für Sie beide und checken Sie als Erster ein.
<G-vec00090-002-s176><check.checken><en> Check the position of your URL, check the position. With ranking-spy, you have a tool that does this for you.
<G-vec00090-002-s176><check.checken><de> Checken Sie die Position Ihrer URL, prüfen Sie den Positionsverlauf.Mit ranking-spy haben Sie ein Tool, das dies für Sie erledigt.
<G-vec00090-002-s177><check.checken><en> Checking in online is not possible if the first flight of your journey (out- or inbound) is with Saudia: please check in at the airport.
<G-vec00090-002-s177><check.checken><de> Das Online-Check-in ist nicht möglich, wenn der erste Flug Ihrer Reise (Hin- oder Rückflug) mit Saudia ist: Bitte checken Sie am Flughafen ein.
<G-vec00090-002-s178><check.checken><en> Please try again later or check in at the airport.
<G-vec00090-002-s178><check.checken><de> Versuchen Sie es später erneut oder checken Sie am Flughafen ein.
<G-vec00090-002-s179><check.checken><en> Photos If the current ski conditions in Český Jiřetín are not ideal, check out out the tables below. We suggest the nearest resorts where you may find better ski conditions based on our extensive snow forecast and snow report database.
<G-vec00090-002-s179><check.checken><de> Resort Beurteilungen (1) Fotos Wenn die aktuellen Bedingungen in Sípark Mátraszentistván nicht ideal sind, checken Sie die Tabelle unten: Wir empfehlen Ihnen die naechstliegenden Skigebiete mit besseren Skibedingungen basierend auf unseren umfassenden Schneevorhersagen und Schneeberichts-Datenbanken.
<G-vec00090-002-s180><check.checken><en> Simply check in online and pick your favourite out of a wide range of newspapers to enjoy on the day of your flight.
<G-vec00090-002-s180><check.checken><de> Checken Sie einfach online ein und wählen Sie Ihre bevorzugte Zeitung aus der Titelliste am Tag Ihres Fluges aus.
<G-vec00090-002-s181><check.checken><en> Connecting trains Check timetables in real time for your connecting trains.
<G-vec00090-002-s181><check.checken><de> Checken Sie die Abfahrtszeiten Ihrer Anschlusszüge in Echtzeit.
<G-vec00090-002-s182><check.checken><en> If the current ski conditions in Laqlouq are not ideal, check out out the tables below. We suggest the nearest resorts where you may find better ski conditions based on our extensive snow forecast and snow report database.
<G-vec00090-002-s182><check.checken><de> Wenn die aktuellen Bedingungen in Hintertux nicht ideal sind, checken Sie die Tabelle unten: Wir empfehlen Ihnen die naechstliegenden Skigebiete mit besseren Skibedingungen basierend auf unseren umfassenden Schneevorhersagen und Schneeberichts-Datenbanken.
<G-vec00090-002-s183><check.checken><en> If the current ski conditions in Popova Shapka are not ideal, check out out the tables below. We suggest the nearest resorts where you may find better ski conditions based on our extensive snow forecast and snow report database.
<G-vec00090-002-s183><check.checken><de> Wenn die aktuellen Bedingungen in Alpbachtal nicht ideal sind, checken Sie die Tabelle unten: Wir empfehlen Ihnen die naechstliegenden Skigebiete mit besseren Skibedingungen basierend auf unseren umfassenden Schneevorhersagen und Schneeberichts-Datenbanken.
<G-vec00090-002-s184><check.checken><en> When travelling with a pet, please check in for your flight at our check-in desk instead of using the self-service channels.
<G-vec00090-002-s184><check.checken><de> Wenn Sie mit einem Haustier reisen, checken Sie für Ihren Flug bitte an unserem Check-In-Schalter ein, anstatt die Selbstbedienungsoptionen zu nutzen.
<G-vec00090-002-s185><check.checken><en> Check in at a dedicated counter.
<G-vec00090-002-s185><check.checken><de> Checken Sie an einem eigenen Schalter ein.
<G-vec00090-002-s186><check.checken><en> Check on your business, keep tabs on employees, or review footages anytime from anywhere.
<G-vec00090-002-s186><check.checken><de> Checken Sie Ihr Geschäft, behalten Sie die Mitarbeiter im Auge oder geben Sie die Videos überall und jederzeit wieder.
<G-vec00090-002-s187><check.checken><en> If the current ski conditions in Mt Olympus are not ideal, check out out the tables below. We suggest the nearest resorts where you may find better ski conditions based on our extensive snow forecast and snow report database.
<G-vec00090-002-s187><check.checken><de> Wenn die aktuellen Bedingungen in Fiss nicht ideal sind, checken Sie die Tabelle unten: Wir empfehlen Ihnen die naechstliegenden Skigebiete mit besseren Skibedingungen basierend auf unseren umfassenden Schneevorhersagen und Schneeberichts-Datenbanken.
<G-vec00090-002-s188><check.checken><en> Check in at Fleming's Hotel Zurich and get in weekend mood with a party set, incl. a bottle of Prosecco.
<G-vec00090-002-s188><check.checken><de> Checken Sie ein im Fleming's Hotel Zürich und stimmen Sie sich mit einem Party-Set inklusive einer Flasche Prosecco auf Ihr Wochenende ein.
<G-vec00090-002-s189><check.checken><en> Check in and relax at family-friendly Novotel Newcastle Airport hotel, just 12 minutes drive to the city centre and 5 minutes from the Airport.
<G-vec00090-002-s189><check.checken><de> Checken Sie ein, und entspannen Sie im familienfreundlichen Novotel Newcastle Airport nur 12 Autominuten vom Stadtzentrum und 5 Minuten vom Flughafen entfernt.
<G-vec00090-002-s342><check.kontrollieren><en> Independent of the file format, the document is checked for its suitability for the translation workflow, i.e., we check whether the document is cleanly segmented, that there are no line breaks, etc.
<G-vec00090-002-s342><check.kontrollieren><de> Unabhängig vom Dateiformat wird das Dokument auf seine Eignung für den Übersetzungsworkflow geprüft, d.h. wir kontrollieren, ob das Dokument sauber segmentiert ist, dass keine Absatzumbrüche mitten in Sätzen vorhanden sind etc..
<G-vec00090-002-s343><check.kontrollieren><en> Working temples tend to charge no fees and there are often no officials to check that dress is appropriate.
<G-vec00090-002-s343><check.kontrollieren><de> Noch im Gebrauch befindliche Tempel verlangen normalerweise ebenfalls keinen Eintritt, und nur selten ist Personal vor Ort, das die korrekte Kleidung der Besucher kontrollieren würde.
<G-vec00090-002-s344><check.kontrollieren><en> Now it is possible for businesses to check in on their employees, address their concerns and solve their problems.
<G-vec00090-002-s344><check.kontrollieren><de> Jetzt ist es für Unternehmen möglich, ihre Mitarbeiter zu kontrollieren, auf ihre Bedenken einzugehen und ihre Probleme zu lösen.
<G-vec00090-002-s345><check.kontrollieren><en> The system offers an adequate possibility to check whether various materials are immunological inert, properly depyrogenated or cleaned.
<G-vec00090-002-s345><check.kontrollieren><de> Eine adäquate Möglichkeit wird damit geboten, um zu kontrollieren, ob verschiedene Materialien immunologisch inaktiv, ausreichend depyrogenisiert oder gesäubert sind.
<G-vec00090-002-s346><check.kontrollieren><en> Therefore it is important to check the welded connections.
<G-vec00090-002-s346><check.kontrollieren><de> Daher ist es wichtig, die geschweißten Verbindungen zu kontrollieren.
<G-vec00090-002-s347><check.kontrollieren><en> We check our content carefully, but do not assume any liability for the content of external links.
<G-vec00090-002-s347><check.kontrollieren><de> Wir kontrollieren unsere Inhalte sorgfältig, übernehmen jedoch keinerlei Haftung für die Inhalte externer Links.
<G-vec00090-002-s348><check.kontrollieren><en> The Belinka Oil Paraffin does not form a protective film on the surface, so it is recommended to check and renovate oiled surfaces.
<G-vec00090-002-s348><check.kontrollieren><de> Das Belinka Oil Paraffin bildet keinen Schutzfilm auf der Oberfläche, weshalb empfohlen wird, geölte Oberflächen regelmäßig zu kontrollieren und zu behandeln.
<G-vec00090-002-s349><check.kontrollieren><en> It is recommended to visually check in the chapter of results whether the modified spring meets all necessary checks, including a possible check of loading of the fixing eye [6].
<G-vec00090-002-s349><check.kontrollieren><de> Es wird empfohlen, im Ergebniskapitel visuell zu kontrollieren, ob die angepasste Feder allen nötigen Kontrollen genügt, einschließlich einer eventuellen Kontrolle der Beanspruchung der Aufhängeöse [6].
<G-vec00090-002-s350><check.kontrollieren><en> They check another, it's light. It
<G-vec00090-002-s350><check.kontrollieren><de> Sie kontrollieren eine andere, sie ist leicht.
<G-vec00090-002-s351><check.kontrollieren><en> However the HAEHNE GmbH has absolutely no influence on the contents of the linked sites and can not continuously check them.
<G-vec00090-002-s351><check.kontrollieren><de> Die HAEHNE GmbH hat jedoch keinerlei Einfluss auf die Inhalte der verknüpften Seiten und kann diese nicht fortlaufend kontrollieren.
<G-vec00090-002-s352><check.kontrollieren><en> ●Before you start sewing, make sure you turn the handwheel toward you (counterclockwise) to check that the needle does not hit the presser foot.
<G-vec00090-002-s352><check.kontrollieren><de> •Drehen Sie das Handrad zur Vorderseite der Maschine, um zu kontrollieren, dass die Nadel den Nähfuß nicht berührt.
<G-vec00090-002-s353><check.kontrollieren><en> The employer’s representative has the right to check the use of sick leave at any time and on time off covered by the sick leave period.
<G-vec00090-002-s353><check.kontrollieren><de> Der Vertreter des Arbeitgebers hat jederzeit das Recht, die Nutzung des Krankenscheins sowie an arbeitsfreien Tagen, die vom Krankenschein erfasst sind, zu kontrollieren.
<G-vec00090-002-s354><check.kontrollieren><en> We can also check the piping and installation diagrams (P&ID’s) supplied during the work, so that you have the current as-built information available immediately after completion.
<G-vec00090-002-s354><check.kontrollieren><de> Darüber hinaus können wir während der Durchführung der Arbeiten die angelieferten P&IDs kontrollieren, sodass Sie danach sofort über die aktuellen Bestandsinformationen verfügen.
<G-vec00090-002-s355><check.kontrollieren><en> Heinrich Environnement has selected for you a range of equipment that is quick and easy to use and allows you to measure the different physico-chemical analysis parameters you need in no time at all, as well to check very simply the pressures and flows in your system. .
<G-vec00090-002-s355><check.kontrollieren><de> Heinrich Environnement hat für Sie ein Sortiment anwenderfreundlicher Produkte zusammengestellt; damit können Sie im Handumdrehen die gewünschten physikalisch-chemischen Parameter analysieren, und die Druckwerte und Durchsatzmengen in Ihrem Netz kontrollieren.
<G-vec00090-002-s356><check.kontrollieren><en> It is advisable to check the guelder-rose for any dead or damaged branches after a severe winter.
<G-vec00090-002-s356><check.kontrollieren><de> Nach einem strengen Winter ist es anzuraten, die Gelderländer Rose auf eventuelle abgestorbene und beschädigte Zweige zu kontrollieren.
<G-vec00090-002-s357><check.kontrollieren><en> But it was also remarkable that the two clerks (one at the left and the other at the right desk), which check passports very carefully, at the same time did not recognise that we had mixed up our flight tickets, which because of that did not fit to the passports at all.
<G-vec00090-002-s357><check.kontrollieren><de> Bemerkenswert war aber auch, dass gleich 2 Beamtinnen (die im linken und die im rechten Schalter), welche die Pässe genauestens kontrollieren, zur selben Zeit nicht bemerkt hatten, dass wir unsere Flugtickes vertauscht hatten, die somit gar nicht zum Pass passten.
<G-vec00090-002-s358><check.kontrollieren><en> Check chain clamping during the sharpening process.
<G-vec00090-002-s358><check.kontrollieren><de> Kettenklemmung während des Schärfvorgangs kontrollieren.
<G-vec00090-002-s359><check.kontrollieren><en> From lane departure warning and distance warning systems to hill start assist and reversing cameras, manoeuvring systems and apps that allow users to check tank levels and control the light, the integration of driver assistance and smart home systems is becoming an all-pervasive trend in the industry.
<G-vec00090-002-s359><check.kontrollieren><de> Von Spurhalteassistenten, Abstandswarnern und Berganfahrhilfen bis hin zu Rückfahrkameras, Rangiersystemen und Apps, die es erlauben, Füllstände zu kontrollieren und das Licht zu steuern: Die Integration von Fahrassistenz- und Smart-Home-Systemen wird immer mehr zum Trend der Branche.
<G-vec00090-002-s360><check.kontrollieren><en> We used advanced quality testing stands to check the quality of our products.
<G-vec00090-002-s360><check.kontrollieren><de> Wir kontrollieren die Qualität unserer Produkte mit modernen Qualitätsprüfständen.
<G-vec00090-002-s361><check.kontrollieren><en> Please check your spam-filter.
<G-vec00090-002-s361><check.kontrollieren><de> Bitte kontrollieren Sie Ihr Spamfilter.
<G-vec00090-002-s362><check.kontrollieren><en> Check the spam folder.
<G-vec00090-002-s362><check.kontrollieren><de> Kontrollieren Sie in Ihrem Spam-Ordner.
<G-vec00090-002-s363><check.kontrollieren><en> THE UNIT IS TOO NOISY: Check whether the unit is sitting on a level sur face.
<G-vec00090-002-s363><check.kontrollieren><de> DIE ANLAGE IST ZU LAUT: Kontrollieren Sie, ob die Anlage auf einer ebenen Fläche steht.
<G-vec00090-002-s364><check.kontrollieren><en> It there is no obvious loss of pressure, check the inflation pressure of all of the tires at a gas station and set these to the recommended value if necessary.
<G-vec00090-002-s364><check.kontrollieren><de> Lässt sich kein offensichtlicher Luftverlust feststellen, kontrollieren Sie den Druck auf allen Reifen an einer Tankstelle und passen Sie diese gegebenenfalls auf die vorgegebenen Werte an.
<G-vec00090-002-s365><check.kontrollieren><en> Check whether water has penetrated here.
<G-vec00090-002-s365><check.kontrollieren><de> Kontrollieren Sie, ob auch hier Wasser eingedrungen ist.
<G-vec00090-002-s366><check.kontrollieren><en> Check the results of your link builder.
<G-vec00090-002-s366><check.kontrollieren><de> Kontrollieren Sie die Ergebnisse Ihrer Link Builder.
<G-vec00090-002-s367><check.kontrollieren><en> Check the spelling.
<G-vec00090-002-s367><check.kontrollieren><de> Kontrollieren Sie die Rechtschreibung.
<G-vec00090-002-s368><check.kontrollieren><en> If you require insurance for damage while parked, check the conditions.
<G-vec00090-002-s368><check.kontrollieren><de> Falls Sie eine Parkschadenversicherung wünschen: Kontrollieren Sie die Bedingungen.
<G-vec00090-002-s369><check.kontrollieren><en> If you merely wish to check a spring designed using the design calculation in chapter [3], transfer the data on the designed spring to the calculation using the button in row [10.1].
<G-vec00090-002-s369><check.kontrollieren><de> Wenn Sie sich nur die, mittels der Entwurfsberechnung im Kapitel [3] entworfene Feder kontrollieren wollen, übertragen Sie die Angaben über die entworfene Feder in die Berechnung durch Drücken der Schaltfläche in der Zeile [10.1].
<G-vec00090-002-s370><check.kontrollieren><en> Please also check your spam folder, because unfortunately often answers from us end up there. Contact Form
<G-vec00090-002-s370><check.kontrollieren><de> Bitte kontrollieren Sie auch Ihren Spam Ordner da leider oft Antworten von uns dort landen.
<G-vec00090-002-s371><check.kontrollieren><en> In addition, check the protocols and the configuration.
<G-vec00090-002-s371><check.kontrollieren><de> Kontrollieren Sie auch die Protokolle und die Konfiguration.
<G-vec00090-002-s372><check.kontrollieren><en> If the screen is not sent after you perform the above steps, disconnect the USB cable and check the calculator setup.
<G-vec00090-002-s372><check.kontrollieren><de> Trennen Sie das USB-Kabel ab und kontrollieren Sie das Setup des Rechners.
<G-vec00090-002-s373><check.kontrollieren><en> Basic safety guidelines To ensure safe handling of the appliance, follow the safety guidelines set out below ■ Prior to use, check the appliance for visible, external damage.
<G-vec00090-002-s373><check.kontrollieren><de> Grundlegende Sicherheitshinweise Beachten Sie für einen sicheren Umgang mit dem Gerät die folgenden Sicherheitshinweise: ■ Kontrollieren Sie das Gerät vor der Verwendung auf äußere sichtbare Schäden.
<G-vec00090-002-s374><check.kontrollieren><en> Save energy at the press of a button. Check your usage remotely and switch off the energy guzzlers.
<G-vec00090-002-s374><check.kontrollieren><de> Sparen Sie Energie mit nur einem Tastendruck Kontrollieren Sie per Fernzugriff Ihren Energieverbrauch und schalten Sie Stromfresser aus.
<G-vec00090-002-s375><check.kontrollieren><en> After you have imported an Audio File hit "Play" and check if you can hear the playback.
<G-vec00090-002-s375><check.kontrollieren><de> Nachdem Sie die Datei importiert haben und diese im Projekt liegt, klicken Sie auf Play und kontrollieren Sie ob Sie die Wiedergabe hören können.
<G-vec00090-002-s376><check.kontrollieren><en> Check the High / Low price before attempting to trade.
<G-vec00090-002-s376><check.kontrollieren><de> Kontrollieren Sie den High/Low Preis bevor Sie anfangen zu handeln,.
<G-vec00090-002-s377><check.kontrollieren><en> Before mounting the tire on the rim, check that the inflation valve functions properly.
<G-vec00090-002-s377><check.kontrollieren><de> Bevor Sie den Reifen auf die Felge ziehen, kontrollieren Sie die korrekte Funktion des Ventils.
<G-vec00090-002-s378><check.kontrollieren><en> Please check the accessories on completeness.
<G-vec00090-002-s378><check.kontrollieren><de> Bitte kontrollieren Sie das mitgelieferte Zubehör auf Vollständigkeit.
<G-vec00090-002-s379><check.kontrollieren><en> To find out, which rooms and periods the offers apply to, please check our online-booking portal.
<G-vec00090-002-s379><check.kontrollieren><de> Bitte kontrollieren Sie in unserem Online-Buchungsportal, auf welche Zimmertypen sich die Angebote beziehen und in welchem Zeitraum diese gültig sind.
<G-vec00090-002-s418><check.prüfen><en> In addition to that, check that your coaxial cable is connected to the cable outlet or to the “Cable In” outlet on the back of the modem.
<G-vec00090-002-s418><check.prüfen><de> Prüfe außerdem, dass dein Koaxkabel mit der Kabeldose oder dem "Kabel ein"-Ausgang auf der Rückseite des Modems verbunden ist.
<G-vec00090-002-s419><check.prüfen><en> Check the node that you selected to be your cork again for holes.
<G-vec00090-002-s419><check.prüfen><de> Prüfe den Knoten, den du als Pfropfen ausgewählt hast, noch einmal auf Löcher.
<G-vec00090-002-s420><check.prüfen><en> Check that all app permissions and the overlay permissions are activated and that your phone is not in power saving mode.
<G-vec00090-002-s420><check.prüfen><de> Prüfe, dass alle Berechtigungen aktiviert sind und dass dein Handy nicht im Energiesparmodus ist.
<G-vec00090-002-s421><check.prüfen><en> So please check your dispatch emails to see if any of your items will be arriving separately.
<G-vec00090-002-s421><check.prüfen><de> Prüfe deshalb Deine Versandbestätigungs Emails, um zu sehen, ob einige Deiner Artikel separat versendet wurden.
<G-vec00090-002-s422><check.prüfen><en> Check the label for your TVs HDMI port if you're not sure which input to select.
<G-vec00090-002-s422><check.prüfen><de> Prüfe die Beschriftung am HDMI-Anschluss deines TVs, wenn du dir nicht sicher bist, welchen Eingang du wählen sollst.
<G-vec00090-002-s423><check.prüfen><en> Please check your inbox and spam folder to confirm your subscription.
<G-vec00090-002-s423><check.prüfen><de> Prüfe deinen Posteingang oder Spam-Ordner, um dein Abonnement zu bestätigen.
<G-vec00090-002-s424><check.prüfen><en> 11 Check for updates periodically.
<G-vec00090-002-s424><check.prüfen><de> 11 Prüfe regelmäßig auf Updates.
<G-vec00090-002-s425><check.prüfen><en> Click Log in Check the email associated with your account
<G-vec00090-002-s425><check.prüfen><de> Klicke auf Anmelden Prüfe das E-Mail-Konto, das mit dem Konto verbunden ist.
<G-vec00090-002-s426><check.prüfen><en> If you can't restore it, check your receipt at the Appstore again. 10.
<G-vec00090-002-s426><check.prüfen><de> Wenn du den Kauf nicht wiederherstellen kannst, prüfe noch einmal deine Quittung aus dem App Store.
<G-vec00090-002-s427><check.prüfen><en> Check your credit score.
<G-vec00090-002-s427><check.prüfen><de> Prüfe deine Bonitätsbeurteilung.
<G-vec00090-002-s428><check.prüfen><en> Please check if you spelled the name correctly.
<G-vec00090-002-s428><check.prüfen><de> Prüfe bitte ob der Name richtig geschrieben ist.
<G-vec00090-002-s429><check.prüfen><en> Check your car for damage and take pictures to document the car’s condition post-trip.
<G-vec00090-002-s429><check.prüfen><de> Prüfe das Auto auf Schäden und mache Fotos, die den Zustand Deines Autos am Ende der Fahrt dokumentieren.
<G-vec00090-002-s430><check.prüfen><en> Don’t miss this brilliant display of nature’s very best Check the booking availability by choosing a date. See More
<G-vec00090-002-s430><check.prüfen><de> Sichere dir einen einmaligen Sommerurlaub im Land aus Feuer und Eis und prüfe die Verfügbarkeit, indem du ein Datum wählst.
<G-vec00090-002-s431><check.prüfen><en> Check your browser.
<G-vec00090-002-s431><check.prüfen><de> Prüfe deinen Browser.
<G-vec00090-002-s432><check.prüfen><en> Check trademark rights: Check if the name you want is already a registered trademark or if the name is already used by another provider.
<G-vec00090-002-s432><check.prüfen><de> Markenrechte prüfen: Prüfe, ob der von Dir gewünschte Name bereits eine registrierte Marke ist oder ob der Name bereits von einem anderen Anbieter verwendet wird.
<G-vec00090-002-s433><check.prüfen><en> Just click the “Check your system now” button on the landing page to start the compatibility test.
<G-vec00090-002-s433><check.prüfen><de> Wähle dazu einfach den Button „Prüfe jetzt dein System“ auf der Landingpage, um den Kompatibilitätstest zu starten.
<G-vec00090-002-s434><check.prüfen><en> While you have the About This Mac window open, check what version of OS X your Mac is running.
<G-vec00090-002-s434><check.prüfen><de> Prüfe bei geöffnetem Fenster „Über diesen Mac“, welche OS X Version auf deinem Mac läuft.
<G-vec00090-002-s435><check.prüfen><en> Check first if you install the latest version of your OS.
<G-vec00090-002-s435><check.prüfen><de> Prüfe zuerst, ob Du die neueste Version des Betriebssystems installiert hast.
<G-vec00090-002-s436><check.prüfen><en> 'Test-step' nodes represent the individual test-steps of a 'Test-case' like 'Open window' or 'Check calculation'.
<G-vec00090-002-s436><check.prüfen><de> 'Testschritt' Knoten repräsentieren individuelle Testschritte eines 'Testfall' Knotens, wie 'Öffne das Fenster' oder 'Prüfe Berechnung'.
<G-vec00090-002-s437><check.prüfen><en> You should find there the most important technical data Sanofi-aventis Lantus SoloSTAR - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s437><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Toshiba 65L9300U - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s438><check.prüfen><en> In addition, if you perform offline backups, there is no process for validating the checksum on each page of the database so you cannot detect corruptions and check the integrity of the database.
<G-vec00090-002-s438><check.prüfen><de> Außerdem gibt es bei Offline-Sicherungen keine Möglichkeit zur Überprüfung der Prüfsumme auf jeder Seite der Datenbank, so dass Sie weder Fehler erkennen noch die Integrität der Datenbank prüfen können.
<G-vec00090-002-s439><check.prüfen><en> You should find there the most important technical data Sony SS-ZX70DVD - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s439><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Curtis RCD909 - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s440><check.prüfen><en> Prick potatoes with a wooden skewer to check whether they are cooked.
<G-vec00090-002-s440><check.prüfen><de> Kartoffeln mit einem Holzspieß einstechen, um zu prüfen ob sie gar sind.
<G-vec00090-002-s441><check.prüfen><en> Before each use, consumers should check their brush for damage such as loose bristles.
<G-vec00090-002-s441><check.prüfen><de> Vor jedem Gebrauch sollten Verbraucher ihre Bürsten auf Schäden, wie zum Beispiel lose Borsten, prüfen.
<G-vec00090-002-s442><check.prüfen><en> We check your concept concerning feasibility and budget, create detailed plans and take care of the smooth implementation. Event technology
<G-vec00090-002-s442><check.prüfen><de> Wir prüfen Ihr Konzept in Bezug auf Machbarkeit und Budget, erstellen Detailpläne und kümmern uns um die reibungslose Umsetzung.
<G-vec00090-002-s443><check.prüfen><en> You should find there the most important technical data Honeywell T8195B - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s443><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Lifebreath 1200DDPOOL - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s444><check.prüfen><en> You should find there the most important technical data Whirlpool SF216LXSQ - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s444><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für GE ZEU769BC - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s445><check.prüfen><en> You should find there the most important technical data Sony VAIO MUSIC CLIP MC-P10 - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s445><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Mitsubishi Electronics PEH-P10 - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s446><check.prüfen><en> In case you wish to make a booking for one of these please contact Bungalow.Net in advance in order to check the availability with the owner.
<G-vec00090-002-s446><check.prüfen><de> Falls Sie eine Reservierung für eine dieser Perioden machen möchten, kontaktieren Sie bitte Bungalow.Net im Voraus, um die Verfügbarkeit mit dem Eigentümer zu prüfen.
<G-vec00090-002-s447><check.prüfen><en> You should find there the most important technical data Intel EE110EM - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s447><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Intel EE110EM - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s448><check.prüfen><en> Using it for the first time it is good to check whether the .PROTO file opened in the application can be read by us and opens in a way that allows us to use it.
<G-vec00090-002-s448><check.prüfen><de> Es wäre gut, beim ersten Mal zu prüfen, ob die in der Applikation geöffnete .PROTO-Datei für uns lesbar ist und sich auf eine Weise öffnen lässt, die uns eine leichte Bedienung ermöglicht.
<G-vec00090-002-s449><check.prüfen><en> You should find there the most important technical data Sony AC VF50 - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s449><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Sanyo UPF383456L - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s450><check.prüfen><en> This allows you to check the temperature at the probes location from wherever you currently are.
<G-vec00090-002-s450><check.prüfen><de> So können Sie auch von unterwegs jederzeit die Temperatur am Sensorstandpunkt prüfen.
<G-vec00090-002-s451><check.prüfen><en> You should find there the most important technical data Whirlpool W10200357B - thus you can check whether the hardware meets your expectations.
<G-vec00090-002-s451><check.prüfen><de> Dort finden Sie die wichtigsten technischen Daten für Hotpoint RGB530DEPBB - auf diese Weise prüfen Sie, ob das Gerät Ihren Wünschen entspricht.
<G-vec00090-002-s452><check.prüfen><en> Double-click the message to check the status of the query.
<G-vec00090-002-s452><check.prüfen><de> Doppelklicken Sie auf die Meldung, um den Status der Abfrage zu prüfen.
<G-vec00090-002-s453><check.prüfen><en> 5.5 CROWDIFY.NET shall check the identity of the Project Initiator as well as the project submission, and shall then, at its own discretion, either approve the project, send it back for improvement or reject it.
<G-vec00090-002-s453><check.prüfen><de> 5.5 CROWDIFY.NET wird die Identität des Projektinitianten sowie die Projekteingabe prüfen und das Projekt anschließend nach eigenem Ermessen freigeben, zur Verbesserung zurückweisen oder ablehnen.
<G-vec00090-002-s454><check.prüfen><en> An API monitor may check a single response or make several requests to test entire user scenarios.
<G-vec00090-002-s454><check.prüfen><de> Ein API-Prüfobjekt kann eine einzelne Antwort prüfen oder mehrere Anfragen stellen, um komplette Nutzerszenarien zu testen.
<G-vec00090-002-s455><check.prüfen><en> If desired, you can click Check now to check your email addresses against known security breaches.
<G-vec00090-002-s455><check.prüfen><de> Optional können Sie unten im Abschnitt „Detaillierte Statistik“ auf Jetzt prüfen klicken, um Ihre E-Mail-Adressen auf bekannte Sicherheitsverletzungen zu überprüfen.
<G-vec00090-002-s456><check.prüfen><en> Six, do not forget – air fares from Vaxjo vary significantly depending on the date, so always check the fares for at least several neighboring dates.
<G-vec00090-002-s456><check.prüfen><de> Sechstens, bitte nicht vergessen, dass Ticketpreise bedeutend je nach dem Datum variieren, deswegen ist es eine gute Idee wenigstens einige Nachbardaten zu prüfen, ob es da gute Preise gibt.
<G-vec00090-002-s457><check.prüfen><en> Five, do not forget – air fares from Air Transport International vary significantly depending on the date, so always check the fares for at least several neighboring dates.
<G-vec00090-002-s457><check.prüfen><de> Sechstens, bitte nicht vergessen, dass Ticketpreise von Air Toulouse International bedeutend je nach dem Datum variieren, deswegen ist es eine gute Idee wenigstens einige Nachbardaten zu prüfen, ob es da gute Preise gibt.
<G-vec00090-002-s461><check.prüfen><en> It is the responsibility of each customer to regularly check the House Rules, Terms and Conditions and Privacy & Cookies Policy for updates.
<G-vec00090-002-s461><check.prüfen><de> Jeder Kunde ist dafür verantwortlich, regelmäßig zu prüfen, ob eine Aktualisierung der Hausregeln, Geschäftsbedingungen und Datenschutz- und Cookies-Richtlinie vorliegt.
<G-vec00090-002-s466><check.prüfen><en> Five, do not forget – air fares from Air Canada vary significantly depending on the date, so always check the fares for at least several neighboring dates.
<G-vec00090-002-s466><check.prüfen><de> Sechstens, bitte nicht vergessen, dass Ticketpreise von Air Canada bedeutend je nach dem Datum variieren, deswegen ist es eine gute Idee wenigstens einige Nachbardaten zu prüfen, ob es da gute Preise gibt.
<G-vec00090-002-s469><check.prüfen><en> Six, do not forget – air fares for Montenegro — Bosnia Herzegovina vary significantly depending on the date, so always check the fares from Montenegro to Bosnia Herzegovina for at least several neighboring dates. 14.
<G-vec00090-002-s469><check.prüfen><de> Sechstens, bitte nicht vergessen, dass Ticketpreise für Montenegro — Bosnien und Herzegowina bedeutend je nach dem Datum variieren, deswegen ist es eine gute Idee wenigstens einige Nachbardaten prüfen, ob es gute Preise da gibt.
<G-vec00090-002-s470><check.prüfen><en> Six, do not forget – air fares for Albania — Romania vary significantly depending on the date, so always check the fares from Albania to Romania for at least several neighboring dates.
<G-vec00090-002-s470><check.prüfen><de> Sechstens, bitte nicht vergessen, dass Ticketpreise für Albanien — Rumanien bedeutend je nach dem Datum variieren, deswegen ist es eine gute Idee wenigstens einige Nachbardaten prüfen, ob es gute Preise da gibt.
<G-vec00090-002-s475><check.prüfen><en> valid Check VIN number: ZFA14600008859368 and learn more about the history of this vehicle.
<G-vec00090-002-s475><check.prüfen><de> valid Prüfen Sie die Fahrgestellnummer: ZFA16900000107371 und erfahren Sie mehr über den Schadenverlauf des Fahrzeuges.
<G-vec00090-002-s476><check.prüfen><en> If you have not found a program that will perform direct conversion, check what conversions for the PSPIMAGE file are available.
<G-vec00090-002-s476><check.prüfen><de> Wenn Sie kein Programm gefunden haben, das eine direkte Konvertierung durchführt, prüfen Sie, welche Konvertierungen für die Datei EPS zugänglich sind.
<G-vec00090-002-s477><check.prüfen><en> If the download still fails to run, check whether your anti-virus software is not blocking the connection to the manufacturer server of the Asus M4A78-EM EPU-4 Engine Utility 1.00.22 diver.
<G-vec00090-002-s477><check.prüfen><de> Wenn das Downloaden immer noch nicht gestartet ist, prüfen Sie ob keins Ihrer Antivirusprogramme die Verbindung zum Server des Produzenten des Treibers Asus M4N72-E EPU-4 Engine Utility 1.00.22 blockiert.
<G-vec00090-002-s478><check.prüfen><en> Please turn it on or check if you have another program set to block cookies.
<G-vec00090-002-s478><check.prüfen><de> Bitte ändern Sie diese Einstellung, sodass er Cookies zulässt oder prüfen Sie, ob Sie ein anderes Programm aktiviert haben, das Cookies blockiert.
<G-vec00090-002-s479><check.prüfen><en> Check VIN number: 4YTD26R2XHN202354 and learn more about the history of this vehicle.
<G-vec00090-002-s479><check.prüfen><de> Prüfen Sie die Fahrgestellnummer: 4YTDT29824FB45274 und erfahren Sie mehr über den Schadenverlauf des Fahrzeuges.
<G-vec00090-002-s480><check.prüfen><en> No battery voltage: check the voltage of your 12 V battery.
<G-vec00090-002-s480><check.prüfen><de> Fehlende Batteriespannung: Prüfen Sie die Spannung Ihrer 12 Volt Batterie.
<G-vec00090-002-s481><check.prüfen><en> Check the list and fulfill your vacation while staying in our Villas is Istria.
<G-vec00090-002-s481><check.prüfen><de> Prüfen Sie das Verzeichnis, um Ihr Urlaubserlebnis abzurunden, während Sie unsere Villen in Istrien bewohnen.
<G-vec00090-002-s482><check.prüfen><en> We are happy to check if this is possible in your case.
<G-vec00090-002-s482><check.prüfen><de> Gerne prüfen wir für Sie, ob dies in Ihrem Fall möglich ist.
<G-vec00090-002-s483><check.prüfen><en> Visit our online shop to check if Tensentype XingKai is also for typefaces, fonts and webfonts
<G-vec00090-002-s483><check.prüfen><de> Besuchen Sie unseren Online-Shop und prüfen Sie dort, ob die Hiroshige auch als Webfont verfügbar ist.
<G-vec00090-002-s484><check.prüfen><en> If you have not found a program that will perform direct conversion, check what conversions for the ASHDISC file are available.
<G-vec00090-002-s484><check.prüfen><de> Wenn Sie kein Programm gefunden haben, das eine direkte Konvertierung durchführt, prüfen Sie, welche Konvertierungen für die Datei ASHDISC zugänglich sind.
<G-vec00090-002-s485><check.prüfen><en> Reset your console and check if you're still getting the Additional Authentication Needed error after the next startup sequence is done.
<G-vec00090-002-s485><check.prüfen><de> Setzen Sie Ihre Konsole zurück und prüfen Sie, ob nach Abschluss der nächsten Startsequenz immer noch der Fehler Zusätzliche Authentifizierung erforderlich angezeigt wird.
<G-vec00090-002-s486><check.prüfen><en> To check availability in our hotel without obligation
<G-vec00090-002-s486><check.prüfen><de> Prüfen Sie unverbindlich die Verfügbarkeit unseres Hauses.
<G-vec00090-002-s487><check.prüfen><en> Check, therefore, whether thepH factor lies under 7, before you addZink-PCA as a pure powder or as awatery solution to the product.
<G-vec00090-002-s487><check.prüfen><de> Prüfen Sie deshalb, ob der pH-Wert unter 7 liegt, bevor Sie Zink-PCA als reines Pulver oder als wässrige Lösung zum Produkt hinzufügen.
<G-vec00090-002-s488><check.prüfen><en> Check the source code for the published page.
<G-vec00090-002-s488><check.prüfen><de> Prüfen Sie den Quellcode der veröffentlichten Seite.
<G-vec00090-002-s489><check.prüfen><en> Answers On the last page of the ordering process (“Check your Order”) you can enter a different shipping address.
<G-vec00090-002-s489><check.prüfen><de> Innerhalb des Bestellvorgangs haben Sie auf der letzten Seite "Prüfen Sie Ihre Bestellung" die Möglichkeit eine von der Rechnungsadresse abweichende Lieferadresse anzugeben.
<G-vec00090-002-s490><check.prüfen><en> Check our current prices for flights from Washington DC to Biloxi.
<G-vec00090-002-s490><check.prüfen><de> Prüfen Sie unsere aktuellen Preise für Flüge von Köln zu Antalya.
<G-vec00090-002-s491><check.prüfen><en> Next, check whether the mandate is valid.
<G-vec00090-002-s491><check.prüfen><de> Prüfen Sie anschließend, ob das Mandat gültig ist.
<G-vec00090-002-s492><check.prüfen><en> Check whether the e-mail has been placed in the Spam folder.
<G-vec00090-002-s492><check.prüfen><de> Prüfen Sie, ob die E-Mail möglicherweise in den Spam-Ordner verschoben wurde.
<G-vec00090-002-s493><check.prüfen><en> To make sure that the order is correct, remember to check the content of the confirmation.
<G-vec00090-002-s493><check.prüfen><de> Prüfen Sie stets, dass der Inhalt des Pakets den in der Bestellbestätigung angegebenen Produkten entspricht.
<G-vec00090-002-s627><check.prüfen><en> If you already have gINT installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the gINT).
<G-vec00090-002-s627><check.prüfen><de> Wenn Sie PowerFlip schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm PowerFlip öffnen kann).
<G-vec00090-002-s628><check.prüfen><en> If you already have Backup Plus installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Backup Plus).
<G-vec00090-002-s628><check.prüfen><de> Wenn Sie Backup Plus schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Backup Plus öffnen kann).
<G-vec00090-002-s629><check.prüfen><en> If you already have Adapter installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Adapter).
<G-vec00090-002-s629><check.prüfen><de> Wenn Sie Adapter schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Adapter öffnen kann).
<G-vec00090-002-s630><check.prüfen><en> You can use your wireless utility to check the network name (SSID) of the router you’re connected to.
<G-vec00090-002-s630><check.prüfen><de> Mit demWireless-Dienstprogrammkönnen Sie den Netzwerknamen (SSID) des Routers prüfen, mit dem Sie verbunden sind.
<G-vec00090-002-s631><check.prüfen><en> If you already have Microsoft Windows Update installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Microsoft Windows Update).
<G-vec00090-002-s631><check.prüfen><de> Wenn Sie Microsoft Windows Server schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Microsoft Windows Server öffnen kann).
<G-vec00090-002-s632><check.prüfen><en> Solution Update your applications to the latest versions by following one of the instructions below. From the “Help” tab of Foxit Reader, Foxit Enterprise Reader, or Foxit PhantomPDF, go to “Check for Update” and update to the latest version.
<G-vec00090-002-s632><check.prüfen><de> Führen Sie einen der folgenden Schritte durch: Verwenden Sie die Option „Auf Aktualisierung prüfen“ im Menü „Hilfe“ von Foxit Reader, Foxit Enterprise Reader oder Foxit PhantomPDF, um auf die aktuelle Version von Foxit Reader 6.2.1, Foxit Enterprise Reader 6.2.1 oder Foxit PhantomPDF 6.2.1 zu aktualisieren.
<G-vec00090-002-s633><check.prüfen><en> If you already have Manga Reader installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Manga Reader).
<G-vec00090-002-s633><check.prüfen><de> Wenn Sie Sky Ebook Reader schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Sky Ebook Reader öffnen kann).
<G-vec00090-002-s634><check.prüfen><en> If you already have Keynote for iOS installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Keynote for iOS).
<G-vec00090-002-s634><check.prüfen><de> Wenn Sie Keynote for iOS schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Keynote for iOS öffnen kann).
<G-vec00090-002-s635><check.prüfen><en> If you already have yBook installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the yBook).
<G-vec00090-002-s635><check.prüfen><de> Wenn Sie Saints Row 2 schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Saints Row 2 öffnen kann).
<G-vec00090-002-s636><check.prüfen><en> To check room availability at the Hotel Alius Rome go directly to the Real Time Live Bookings page.
<G-vec00090-002-s636><check.prüfen><de> Wenn Sie die Verfügbarkeit der Zimmer im Hotel Alius Rom prüfen wollen, gehen Sie direkt zur Echtzeit-Buchungsseite.
<G-vec00090-002-s637><check.prüfen><en> If you already have VSD Viewer installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the VSD Viewer).
<G-vec00090-002-s637><check.prüfen><de> Wenn Sie eDrawings Viewer schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm eDrawings Viewer öffnen kann).
<G-vec00090-002-s638><check.prüfen><en> If you already have Audio Overload installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Audio Overload).
<G-vec00090-002-s638><check.prüfen><de> Wenn Sie Audio player schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Audio player öffnen kann).
<G-vec00090-002-s639><check.prüfen><en> If you already have EarthTime installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the EarthTime).
<G-vec00090-002-s639><check.prüfen><de> Wenn Sie EarthTime schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm EarthTime öffnen kann).
<G-vec00090-002-s640><check.prüfen><en> If you already have GTA IV installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the GTA IV).
<G-vec00090-002-s640><check.prüfen><de> Wenn Sie Chankast schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Chankast öffnen kann).
<G-vec00090-002-s641><check.prüfen><en> If you already have Embroidermodder 1 installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Embroidermodder 1).
<G-vec00090-002-s641><check.prüfen><de> Wenn Sie Embroidermodder 1 schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Embroidermodder 1 öffnen kann).
<G-vec00090-002-s642><check.prüfen><en> You can check by looking at the 'Apply Rule Set' dropdown menu on the Creative tab.
<G-vec00090-002-s642><check.prüfen><de> Das können Sie prüfen, indem Sie in das Dropdown-Menü "Regelsatz anwenden" auf dem Tab "Motiv" schauen.
<G-vec00090-002-s643><check.prüfen><en> If you already have Bean installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Bean).
<G-vec00090-002-s643><check.prüfen><de> Wenn Sie MixPad schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm MixPad öffnen kann).
<G-vec00090-002-s644><check.prüfen><en> If you already have Battery installed on your computer, you can check which file extensions it supports and look for the data you need in this specific format (or to what format you should convert the data so that you can open them in the Battery).
<G-vec00090-002-s644><check.prüfen><de> Wenn Sie Battery schon auf Ihrem Computer installiert haben, dann können Sie prüfen, welche Dateiendungen es bedient und notwendige Daten in genau diesem Format suchen (oder sie in ein solches Format konvertieren, so, damit man sie in dem Programm Battery öffnen kann).
<G-vec00090-002-s645><check.prüfen><en> It's important to check motorcycle oil at regular intervals in order to maintain your bike's performance and safety.
<G-vec00090-002-s645><check.prüfen><de> Um die Leistungsfähigkeit und Sicherheit Ihres Motorrads zu erhalten, müssen Sie in regelmäßigen Abständen den Ölstand prüfen.
<G-vec00090-002-s209><check.überprüfen><en> !Xóõ Indonesian Bajau!Xóõ Indonesian Please write word or phrase you want to check in the text box on the left.
<G-vec00090-002-s209><check.überprüfen><de> Mit der Nutzung unserer Dienste erklären Sie sich damit einverstanden, Bitte schreiben Sie das Wort oder die Phrase, die Sie überprüfen möchten in das Textfeld auf der linken Seite.
<G-vec00090-002-s210><check.überprüfen><en> The information sources you must check are listed under step 4.
<G-vec00090-002-s210><check.überprüfen><de> Die Informationsquellen, die Sie überprüfen müssen, sind unter Schritt 4 aufgeführt.
<G-vec00090-002-s211><check.überprüfen><en> !Xóõ - Erre!Xóõ - or phrase you want to check in the text box on the left.
<G-vec00090-002-s211><check.überprüfen><de> !O!ung Bitte schreiben Sie das Wort oder die Phrase, die Sie überprüfen möchten in das Textfeld auf der linken Seite.
<G-vec00090-002-s214><check.überprüfen><en> **Please contact me, the Host, if you have questions and before booking to check availability.
<G-vec00090-002-s214><check.überprüfen><de> ** Bitte kontaktieren Sie mich, der Host, wenn Sie Fragen haben und vor der Buchung, um die Verfügbarkeit zu überprüfen.
<G-vec00090-002-s216><check.überprüfen><en> Full-time merchants and those natural persons or legal entities of equal legal standing must check the goods or service immediately on delivery.
<G-vec00090-002-s216><check.überprüfen><de> Vollkaufleute und ihnen rechtlich gleichgestellte natürliche oder juristische Personen haben die Ware oder die Leistung bei Anlieferung sofort zu überprüfen.
<G-vec00090-002-s218><check.überprüfen><en> Alternatively, it's also smart to always check the items found by Quick Scan.
<G-vec00090-002-s218><check.überprüfen><de> Alternativ ist es auch klug, immer die vom Schnell-Scan (Quick-Scan) gefundenen Elemente zu überprüfen.
<G-vec00090-002-s219><check.überprüfen><en> Nayar Cora dictionary. Please write word or phrase you want to check in the text box on the left.
<G-vec00090-002-s219><check.überprüfen><de> Mit der Nutzung unserer Dienste erklären Sie sich damit Bitte schreiben Sie das Wort oder die Phrase, die Sie überprüfen möchten in das Textfeld auf der linken Seite.
<G-vec00090-002-s220><check.überprüfen><en> By detecting the relative positions of the four corners of the die, you can check alignment as well as the stroke.
<G-vec00090-002-s220><check.überprüfen><de> Durch Erfassen der relativen Position der vier Ecken des Werkzeugs können Sie sowohl die Ausrichtung als auch den Hub überprüfen.
<G-vec00090-002-s221><check.überprüfen><en> You can track the shipment via the web or ways you want to check.
<G-vec00090-002-s221><check.überprüfen><de> Sie können den Versand über das Netz oder die Weisen aufspüren, die Sie überprüfen möchten.
<G-vec00090-002-s222><check.überprüfen><en> If you pay using PayPal and you’ve recently changed payment methods then you may want to check the “source of funding” setting for the subscription inside your PayPal account.
<G-vec00090-002-s222><check.überprüfen><de> Wenn Du bezahlst, um PayPal zu benutzen und Du vor kurzem die Zahlungsmethode geändert hast, dann solltest Du vielleicht die Einstellungen bei “Verfügbare Zahlungsquelle festlegen” für die Bezahlung des Abonnement-Paketes in Deinem PayPal-Konto überprüfen.
<G-vec00090-002-s223><check.überprüfen><en> Please write word or phrase you want to check in the text box on the left. add translationRecent changes
<G-vec00090-002-s223><check.überprüfen><de> //Gana Bankan Tey Bitte schreiben Sie das Wort oder die Phrase, die Sie überprüfen möchten in das Textfeld auf der linken Seite.
<G-vec00090-002-s224><check.überprüfen><en> Give customers TrueSizer and they can receive .EMB files instantly by email, check designs in TrueView and give immediate feedback.
<G-vec00090-002-s224><check.überprüfen><de> Mit TrueSizer können Ihre Kunden .EMB-Dateien sofort per E-Mail erhalten, die Designs in TrueView überprüfen und direkt Rückmeldung geben.
<G-vec00090-002-s227><check.überprüfen><en> By using our services, you agree Please write word or phrase you want to check in the text box on the left.
<G-vec00090-002-s227><check.überprüfen><de> //Ani - Bitte schreiben Sie das Wort oder die Phrase, die Sie überprüfen möchten in das Textfeld auf der linken Seite.
<G-vec00090-002-s646><check.überprüfen><en> Setting the Test Tone Use the Test Tone feature to check the speaker connections.
<G-vec00090-002-s646><check.überprüfen><de> Einstellen des Testtons Verwenden Sie die Testton-Funktion, um die Lautsprecheranschlüsse zu überprüfen.
<G-vec00090-002-s647><check.überprüfen><en> Our Number Checker can check your ticket against EuroJackpot draws for the past year.
<G-vec00090-002-s647><check.überprüfen><de> Mit unserem Zahlen-Checker können Sie Ihren Spielschein für die EuroJackpot-Ziehungen des letzten Jahres überprüfen.
<G-vec00090-002-s648><check.überprüfen><en> This will show exactly how the cut will look as well as enable you to check dimensions.
<G-vec00090-002-s648><check.überprüfen><de> So erkennen Sie genau, wie der Schnitt aussehen wird, und Sie können die Abmessungen überprüfen.
<G-vec00090-002-s649><check.überprüfen><en> If no connection objects exist for the new replica member, use the Check Replication Topology command in Dssite.msc to force KCC to build the necessary automatic connection objects (press F5 to refresh the view afterwards).
<G-vec00090-002-s649><check.überprüfen><de> Wenn keine Verbindungsobjekte für den neuen Replikationspartner bestehen, verwenden Sie den Befehl Replikationstopologie überprüfen in der Datei "Dssite.msc", um die Konsistenzprüfung zu veranlassen, die notwendigen automatischen Verbindungsobjekte zu erstellen.
<G-vec00090-002-s650><check.überprüfen><en> You are expected to check this page from time to time to take notice of any changes we made, as they are binding on you.
<G-vec00090-002-s650><check.überprüfen><de> Es wird erwartet, dass Sie diese Seite bisweilen überprüfen, um vorgenommene Änderungen zur Kenntnis zu nehmen, weil diese Sie rechtlich verpflichten.
<G-vec00090-002-s651><check.überprüfen><en> You might have to check the Web or with your ISP to see what these settings are.
<G-vec00090-002-s651><check.überprüfen><de> Möglicherweise müssen Sie das Web oder Ihren ISP überprüfen, um festzustellen, wie diese Einstellungen lauten.
<G-vec00090-002-s652><check.überprüfen><en> This signals name servers across the internet to check every 300 seconds whether you updated this DNS record.
<G-vec00090-002-s652><check.überprüfen><de> Dadurch wird den Namensservern im gesamten Internet signalisiert, dass sie alle 300 Sekunden (oder 5 Minuten) überprüfen sollen, ob Sie diese DNS-Datensätze aktualisiert haben.
<G-vec00090-002-s653><check.überprüfen><en> Program packages, special offers, please check the cancellation policy described in conditions! Child policy
<G-vec00090-002-s653><check.überprüfen><de> Im Falle der Auswahl von Programmpaketen und besonderen Angeboten bitten wir Sie, die darin niedergeschriebenen Stornierungskonditionen zu überprüfen.
<G-vec00090-002-s654><check.überprüfen><en> To resolve this problem, disable the Check for publisher’s certificate revocation setting on the server that you are upgrading. 1.
<G-vec00090-002-s654><check.überprüfen><de> Um dieses Problem zu umgehen und die Installationsdauer zu verkürzen, deaktivieren Sie die Option Auf gesperrte Zertifikate von Herausgebern überprüfen auf dem Server, für den das Upgrade ausgeführt wird.
<G-vec00090-002-s655><check.überprüfen><en> Also, order software drivers and recovery disks, check status on orders for drivers and disks, and find product manuals End of content Philippines
<G-vec00090-002-s655><check.überprüfen><de> Sie können auch Softwaretreiber und CDs zur Wiederherstellung bestellen, den Status von Aufträgen für Treiber und CDs überprüfen und nach Produkthandbüchern suchen.
<G-vec00090-002-s656><check.überprüfen><en> Please check the address for the page you were trying to reach.
<G-vec00090-002-s656><check.überprüfen><de> Falls Sie die Adresse selbst eingegeben haben, bitte überprüfen Sie die Schreibweise.
<G-vec00090-002-s657><check.überprüfen><en> We often perform product and technology evaluations or show cases for the customers to check the technology suitability for the planned projects.
<G-vec00090-002-s657><check.überprüfen><de> Diese vertrauensvolle Partnerschaft führt dazu, dass wir für sie häufig Produkt- und Technologie-Evaluierungen durchführen oder in Show Cases die Tauglichkeit für kundenindividuelle Einsatzzwecke überprüfen.
<G-vec00090-002-s658><check.überprüfen><en> To check your Monitor user type, log in to the Monitor, click Tools » User Settings, and review the User Type setting.
<G-vec00090-002-s658><check.überprüfen><de> Wenn Sie Ihren Monitor-Benutzertyp überprüfen möchten, melden Sie sich beim Monitor an, klicken Sie auf Extras » Benutzereinstellungen und überprüfen Sie die Einstellung Benutzertyp.
<G-vec00090-002-s659><check.überprüfen><en> Click on Test Settings to check synchronization configuration and the results returned by the IceWarp Server without any changes to the MailStore Server user database being actually committed.
<G-vec00090-002-s659><check.überprüfen><de> Mit Klick auf Sync testen können Sie die Synchronisierungseinstellungen und das vom IceWarp Server zurückgelieferte Ergebnis überprüfen, ohne dass Änderungen an der MailStore Server-Benutzerdatenbank durchgeführt werden.
<G-vec00090-002-s660><check.überprüfen><en> Use the validator to check thousands of XML or JSON documents.
<G-vec00090-002-s660><check.überprüfen><de> Benützen Sie den Validator um tausende von XML oder JSON Dokumenten zu überprüfen.
<G-vec00090-002-s661><check.überprüfen><en> The idea is: use the same tools as the crackers do, to check the vulnerabilities of your network (or machine).
<G-vec00090-002-s661><check.überprüfen><de> Die Idee ist: benutze dieselben Werkzeuge, wie sie die Cracker benutzen, um die Verwundbarkeiten deines Netzwerkes (deiner Maschine) zu überprüfen.
<G-vec00090-002-s662><check.überprüfen><en> He was collecting units to check on them, and he picked up seven at once.
<G-vec00090-002-s662><check.überprüfen><de> Er sammelte die Geräte ein, um sie zu überprüfen und trug sieben von ihnen auf einmal.
<G-vec00090-002-s663><check.überprüfen><en> Feel free to check them all out.
<G-vec00090-002-s663><check.überprüfen><de> Fühlen Sie sich frei, um Sie alle zu überprüfen.
<G-vec00090-002-s664><check.überprüfen><en> This online tool can check your iOS version.
<G-vec00090-002-s664><check.überprüfen><de> Dieses Online-Tool können Sie Ihre iOS-Version überprüfen.
<G-vec00090-002-s741><check.überprüfen><en> Check your inbox for messages from Deezer.
<G-vec00090-002-s741><check.überprüfen><de> Überprüfe deinen Posteingang auf Nachrichten von Deezer.
<G-vec00090-002-s742><check.überprüfen><en> Step #2: Check the links on those web pages to identify dead or broken links: Next, we have to check if there are broken links in any of these resources that Google already ranks in their top 10.
<G-vec00090-002-s742><check.überprüfen><de> Schritt #2: Überprüfe die Links auf diesen Webseiten, um tote oder defekte Verlinkungen zu identifizieren: Als Nächstes musst Du die defekten Links in allen Ressoucen überprüfen, die Google in den Top 10 auflistet.
<G-vec00090-002-s743><check.überprüfen><en> Please check these Terms of Sale periodically for those changes.
<G-vec00090-002-s743><check.überprüfen><de> Überprüfe diese Verkaufsbedingungen regelmäßig auf Änderungen.
<G-vec00090-002-s744><check.überprüfen><en> Check to see if someone's voice changes, or if they suddenly change their body language.
<G-vec00090-002-s744><check.überprüfen><de> Überprüfe, ob jemand seine Stimme ändert, oder ob sich plötzlich die Körpersprache ändert.
<G-vec00090-002-s745><check.überprüfen><en> Come back to the spot after about 3 days to check it.
<G-vec00090-002-s745><check.überprüfen><de> Überprüfe die Stelle nach etwa 3 Tagen.
<G-vec00090-002-s746><check.überprüfen><en> Then check if your website is still fully functioning.
<G-vec00090-002-s746><check.überprüfen><de> Überprüfe dann, ob Deine Webseite noch fehlerfrei funktioniert.
<G-vec00090-002-s747><check.überprüfen><en> Check your statements.
<G-vec00090-002-s747><check.überprüfen><de> Überprüfe deine Aussagen.
<G-vec00090-002-s748><check.überprüfen><en> Check your answer:The train is already moving quicker than the cars.
<G-vec00090-002-s748><check.überprüfen><de> Überprüfe deine Antwort:Der Zug fährt schon schneller als die Autos.
<G-vec00090-002-s749><check.überprüfen><en> Check it now for free!
<G-vec00090-002-s749><check.überprüfen><de> Überprüfe es jetzt kostenlos.
<G-vec00090-002-s750><check.überprüfen><en> Check spacing, character errors and/or spelling mistakes.
<G-vec00090-002-s750><check.überprüfen><de> Überprüfe Abstand, Zeichenfehler und/oder Rechtschreibfehler.
<G-vec00090-002-s751><check.überprüfen><en> Check the soil's drainage by digging a hole and filling it with water.
<G-vec00090-002-s751><check.überprüfen><de> Überprüfe die Entwässerung des Bodens, indem du ein Loch gräbst und es mit Wasser füllst.
<G-vec00090-002-s752><check.überprüfen><en> Check the parents' papers to make sure both dogs have hip certification from the Orthopedic Foundation for Animals as well as registration from either the Canine Eye Registry Foundation or a current annual eye clearance from a veterinary ophthalmologist.
<G-vec00090-002-s752><check.überprüfen><de> Überprüfe die Papiere der Eltern und stelle sicher, dass beide Eltern eine Bescheinigung besitzen, die garantiert, dass sie nicht an Hüft-Dysplasie leiden und außerdem ein Nachweis über eine Augenuntersuchung von einem Fachtierarzt vorliegt.
<G-vec00090-002-s753><check.überprüfen><en> Check that there is no numbness, throbbing, color change, or loss of sensation in either finger after the taping.
<G-vec00090-002-s753><check.überprüfen><de> Überprüfe nach dem Verkleben, dass keine Taubheit, Klopfen, Veränderungen der Hautfarbe an den Fingern oder der Verlust des Empfindungsvermögens in keinem der Finger auftritt.
<G-vec00090-002-s754><check.überprüfen><en> Check your dog's ears weekly.
<G-vec00090-002-s754><check.überprüfen><de> Überprüfe die Ohren deines Hundes wöchentlich.
<G-vec00090-002-s755><check.überprüfen><en> Check each tire.
<G-vec00090-002-s755><check.überprüfen><de> Überprüfe jeden Reifen.
<G-vec00090-002-s756><check.überprüfen><en> Check your document.
<G-vec00090-002-s756><check.überprüfen><de> Überprüfe dein Ausweisdokument.
<G-vec00090-002-s757><check.überprüfen><en> Check with your child whether they are comfortable with the content they are posting being seen by everyone they know and whether it might embarrass them at a later stage. 5.
<G-vec00090-002-s757><check.überprüfen><de> Überprüfe zusammen mit deinem Kind, ob es mit dem Inhalt, welchen es dort hineinschreibt, zufrieden ist, zumal es von allen gesehen werden kann und ob, eventuell auch zu einem späteren Zeitpunkt, jemand damit verletzen könnte.
<G-vec00090-002-s758><check.überprüfen><en> First, check your spam or junk mail folders to see if the receipt ended up there.
<G-vec00090-002-s758><check.überprüfen><de> Überprüfe als erstes deine Spam-Ordner, um zu schauen, ob die Beleg-E-Mail vielleicht dort gelandet ist.
<G-vec00090-002-s759><check.überprüfen><en> Always check the labels of your products to make sure they are free from unsustainable palm oil.
<G-vec00090-002-s759><check.überprüfen><de> Überprüfe immer die Etiketten deiner Produkte um sicherzustellen, dass sie zumindest aus nachhaltigem Palmöl hergestellt sind.
<G-vec00090-002-s760><check.überprüfen><en> Check your PC and network for all kinds of issues in just one easy click.
<G-vec00090-002-s760><check.überprüfen><de> Überprüfen Sie PC und Netzwerk in nur einem Klick auf alle Arten von Problemen.
<G-vec00090-002-s761><check.überprüfen><en> First, please check your junk mail.
<G-vec00090-002-s761><check.überprüfen><de> Überprüfen Sie bitte zuerst Ihre Spam-E-Mails.
<G-vec00090-002-s762><check.überprüfen><en> Indication The SIC "Easy Handle" for abutments is a depth gauge to check correct pilot drilling and is used as well for fitting the SIC abutments.
<G-vec00090-002-s762><check.überprüfen><de> Indikation Der SIC "Easy-Handle" für Aufbauten ist Tiefenmesslehre zum Überprüfen der korrekten Pilotbohrung und wird auch beim Eingliedern von SIC Aufbauten verwendet.
<G-vec00090-002-s763><check.überprüfen><en> Check whether the light barrier is still correctly positioned.
<G-vec00090-002-s763><check.überprüfen><de> Überprüfen, ob die Lichtschranke immer noch korrekt positioniert ist.
<G-vec00090-002-s764><check.überprüfen><en> Touch screen to select model, change spot welding parameters, check errors, monitor spot welding graphs, parts counters, etc.
<G-vec00090-002-s764><check.überprüfen><de> Touch-Bildschirm für die Auswahl des Modells, Änderungen der Schweißparameter Punkt für Punkt, Überprüfen von Fehlern, Anzeige von Schweißgrafiken Punkt für Punkt, Teilezähler, etc.
<G-vec00090-002-s765><check.überprüfen><en> Pro'sKit MT-7028 Network Toner Probe Kit Audio Network Check Line Tester Tracker Networking, Datacom, Audio / Video, TV Cable
<G-vec00090-002-s765><check.überprüfen><de> Pro'sKit MT-7028 Netzwerk Toner Sonde Kit Audio Netzwerk Überprüfen Linie Tester Tracker Networking, Datacom, Audio/Video, TV Ka...
<G-vec00090-002-s766><check.überprüfen><en> Please check in the design editor and in the shopping cart if the backside is blank or if there is a pattern.
<G-vec00090-002-s766><check.überprüfen><de> Überprüfen Sie bitte im Designeditor und im Warenkorb, ob die Rückseite leer ist oder sich dort ein Muster befindet.
<G-vec00090-002-s767><check.überprüfen><en> Windows: See Check your hard disk for errors.
<G-vec00090-002-s767><check.überprüfen><de> Windows: Siehe Überprüfen eines Laufwerks auf Fehler.
<G-vec00090-002-s768><check.überprüfen><en> Therefore, the first step in planning your trip to Machu Picchu is to check the availability of Machu Picchu tickets in real time and make sure you can actually visit Machu Picchu on the date(s) you want.
<G-vec00090-002-s768><check.überprüfen><de> Daher ist der erste Schritt bei der Planung Ihrer Reise nach Machu Picchu das Überprüfen der Verfügbarkeit von Machu Picchu Tickets in Echtzeit und sicherzustellen, dass Sie Machu Picchu tatsächlich zum gewünschten Datum besuchen können.
<G-vec00090-002-s769><check.überprüfen><en> Once all required numbers have been selected, scroll to the bottom of the view and tap the ‘Check’ button.
<G-vec00090-002-s769><check.überprüfen><de> Wenn Sie alle erforderlichen Zahlen ausgewählt haben, scrollen Sie zum unteren Rand der Ansicht und tippen Sie auf 'Überprüfen'.
<G-vec00090-002-s770><check.überprüfen><en> You should also check the volume level in the sound mixer and adjust it if necessary.
<G-vec00090-002-s770><check.überprüfen><de> Überprüfen Sie auch den eingestellten Lautstärkepegel im Sound-Mixer und korrigieren Sie gegebenenfalls.
<G-vec00090-002-s771><check.überprüfen><en> Please check the spelling of the resource you were trying to access and try again.
<G-vec00090-002-s771><check.überprüfen><de> Überprüfen Sie die Pfad- und Dateiangabe der angeforderten Ressource.
<G-vec00090-002-s772><check.überprüfen><en> 2Merge and check code into a GitHub repository for continuous integration.
<G-vec00090-002-s772><check.überprüfen><de> 2Mergen und Überprüfen von Code in einem GitHub-Repository für Continuous Integration.
<G-vec00090-002-s773><check.überprüfen><en> Check to see that the power supply has not become disconnected from the scanner or unplugged from the power source.
<G-vec00090-002-s773><check.überprüfen><de> Überprüfen Sie, ob die Netzteilkabel am Scanner oder an der Stromquelle abgezogen wurden.
<G-vec00090-002-s774><check.überprüfen><en> Check you 3D glasses type and choose the corresponding 3D setting modes from Red/Cyan, Blue/Yellow, Interleaved, Side by Side.
<G-vec00090-002-s774><check.überprüfen><de> Überprüfen Sie welche Art von 3D Brille Sie besitzen und wählen Sie dann die entsprechende 3D Einstellung aus: Rot/Türkis, Blau/Gelb, Überlappend, Nebeneinander.
<G-vec00090-002-s775><check.überprüfen><en> Check yourself many, many times in the mirror, Ask your partner (numerous times),?
<G-vec00090-002-s775><check.überprüfen><de> Überprüfen Sie sich viele, viele Male im Spiegel, fragen Sie Ihren Partner (zahlre...
<G-vec00090-002-s776><check.überprüfen><en> Note To verify that you have installed this update, you can open any Microsoft Office 2008 application to check the version number.
<G-vec00090-002-s776><check.überprüfen><de> Überprüfen Sie, ob Sie dieses Update bereits installiert haben, indem Sie eine beliebige Microsoft Office 2008-Anwendung (z.
<G-vec00090-002-s777><check.überprüfen><en> You can check this by entering "!Admin" into the ingame chat.
<G-vec00090-002-s777><check.überprüfen><de> Überprüfen könnt ihr dies, indem ihr "!admin" in den Ingame-Chat eingebt.
<G-vec00090-002-s778><check.überprüfen><en> Automatic Graphics Driver Updater - Check updates and receive notifications about new graphic card drivers.
<G-vec00090-002-s778><check.überprüfen><de> Automatic Graphics Driver Updater - Überprüfen Updates und erhalten Benachrichtigungen über neue Grafikkartentreiber.
<G-vec00090-002-s779><check.überprüfen><en> · Check to make sure the files Opengl32.dll and Glu32.dll are in your Windows\System folder (Winnt\System32).
<G-vec00090-002-s779><check.überprüfen><de> · Überprüfen Sie, ob sich die Dateien Opengl32.dll and Glu32.dll unter Ihrem Verzeichnis Windows\System (Winnt\System32) befinden.
<G-vec00090-002-s780><check.überprüfen><en> Check the cursor speed under general mouse settings of your PC.
<G-vec00090-002-s780><check.überprüfen><de> Überprüfen Sie die Cursorgeschwindigkeit unter den allgemeinen Mauseinstellungen auf Ihrem PC.
<G-vec00090-002-s781><check.überprüfen><en> Advice Check your oil level on a regular basis and top-up if necessary.
<G-vec00090-002-s781><check.überprüfen><de> Überprüfen Sie den Ölstand regelmäßig etwa alle 1.000 km und füllen Sie gegebenenfalls Motoröl nach.
<G-vec00090-002-s782><check.überprüfen><en> Using the same address (URL) check the pages downloaded for the issuer of the certificate and validity of same.
<G-vec00090-002-s782><check.überprüfen><de> Überprüfen Sie unter derselben Adresse (URL) der Seiten, die bestätigt werden sollen, den Aussteller und die Gültigkeit des Zertifikats.
<G-vec00090-002-s783><check.überprüfen><en> Check that the product is connected correctly with a cable.
<G-vec00090-002-s783><check.überprüfen><de> Überprüfen Sie, ob das Gerät korrekt über ein Kabel angeschlossen ist.
<G-vec00090-002-s784><check.überprüfen><en> Check the drainage system and non-return valve in the cellar.
<G-vec00090-002-s784><check.überprüfen><de> Überprüfen Sie Hausentwässerungsanlagen und Rückstauklappen im Keller.
<G-vec00090-002-s785><check.überprüfen><en> A: Check if the resolution and frequency set for the computer video card falls in the range supported by the LCD Display.
<G-vec00090-002-s785><check.überprüfen><de> Überprüfen Sie, ob die Auflösung und Frequenz des PCs sowie der Grafikkarte auf einen mit dem Gerät kompatiblen Bereich eingestellt sind.
<G-vec00090-002-s786><check.überprüfen><en> CAUTION: • Always check the direction of rotation before operation.
<G-vec00090-002-s786><check.überprüfen><de> ACHTUNG: • Überprüfen Sie vor jedem Betrieb immer die Drehrichtung.
<G-vec00090-002-s787><check.überprüfen><en> Check all the settings again in the same order.
<G-vec00090-002-s787><check.überprüfen><de> Überprüfen Sie alle Einstellungen nochmals in gleicher Reihenfolge.
<G-vec00090-002-s788><check.überprüfen><en> We have not been able to check your site, be sure to place the file in the root directory of your site verify_trustscam_com_2f6500c7461aabb43bcc3cedc80fb4ff.html and try again.
<G-vec00090-002-s788><check.überprüfen><de> Überprüfen Sie die Website Wir wurden nicht in der Lage, Ihre Website zu überprüfen, müssen Sie die Datei im Stammverzeichnis Ihrer Website verify_trustscam_com_2f6500c7461aabb43bcc3cedc80fb4ff.html und versuchen Sie es erneut.
<G-vec00090-002-s789><check.überprüfen><en> Check the player or music streaming settings on your Bluetooth device.
<G-vec00090-002-s789><check.überprüfen><de> Überprüfen Sie die Wiedergabe- oder Musik-Streaming-Einstellungen Ihres Bluetooth-Geräts.
<G-vec00090-002-s790><check.überprüfen><en> Please check whether you are breeding immuno-modified animals and consult your respective animal welfare office regarding further steps.
<G-vec00090-002-s790><check.überprüfen><de> Überprüfen Sie daher, ob Sie immunmodifizierte Tiere züchten und klären Sie mit ihrem Tierschutzbeauftragten das weitere Vorgehen ab.
<G-vec00090-002-s791><check.überprüfen><en> Check the conditions to avoid confusion before you deposit.
<G-vec00090-002-s791><check.überprüfen><de> Überprüfen Sie die Bedingungen, um Verwechslungen zu vermeiden.
<G-vec00090-002-s792><check.überprüfen><en> Always ensure You check the minimum check-in time for your flight.
<G-vec00090-002-s792><check.überprüfen><de> Überprüfen Sie bei jedem Flug die Meldeschlusszeiten für den Check-in.
<G-vec00090-002-s793><check.überprüfen><en> 2 Check whether the contact of each position of the tap changer is good;
<G-vec00090-002-s793><check.überprüfen><de> 2 Überprüfen Sie, ob der Kontakt jeder Position des Stufenschalters gut ist.
<G-vec00090-002-s794><check.überprüfen><en> Check all of the Gay Place in Lijiang City and its surrounding area.
<G-vec00090-002-s794><check.überprüfen><de> Überprüfen Sie alle Gay Treffpunkt in Lijiang und Umgebung.
<G-vec00090-002-s795><check.überprüfen><en> Check my feedback for other satisfied customers.
<G-vec00090-002-s795><check.überprüfen><de> Überprüfen Sie mein Feedback auf anderen zufriedenen Kunden.
<G-vec00090-002-s796><check.überprüfen><en> Check if there is a folder ‘FontDatabase’ in %appdata%.
<G-vec00090-002-s796><check.überprüfen><de> Überprüfen Sie, ob in %appdata% der Ordner „FontDatabase“ vorhanden ist.
<G-vec00090-002-s797><check.überprüfen><en> Check garden swings and slides.
<G-vec00090-002-s797><check.überprüfen><de> Überprüfen Sie regelmäßig Gartenschaukeln und Rutschen.
<G-vec00090-002-s817><check.überprüfen><en> Solution: Disable your software firewall and also check if your router is blocking VPN connections.
<G-vec00090-002-s817><check.überprüfen><de> Lösung: Deaktiviere deine Software-Firewall, und überprüfe auch ob in deinem Router VPN-Verbindungen nicht blockiert sind.
<G-vec00090-002-s818><check.überprüfen><en> Use the left mouse click on the frog until the red glove appears and check the direction you want to sent the frog and release.
<G-vec00090-002-s818><check.überprüfen><de> Klicke mit der linken Maustaste auf den Frosch, bis der rote Handschuh erscheint und überprüfe die Richtung, in die der Frosch geschickt werden soll.
<G-vec00090-002-s819><check.überprüfen><en> The first thing I do is to check if the body has taken on the energetic pattern of the abuser.
<G-vec00090-002-s819><check.überprüfen><de> Zunächst überprüfe ich, ob der Körper das Energiemuster des Mißbrauchers übernommen hat.
<G-vec00090-002-s820><check.überprüfen><en> I check the message and it’s from Anastasia.
<G-vec00090-002-s820><check.überprüfen><de> Ich überprüfe den Absender und es ist Anastasia.
<G-vec00090-002-s821><check.überprüfen><en> Accept or check out your privacy settings here.
<G-vec00090-002-s821><check.überprüfen><de> Akzeptieren oder überprüfe deine Datenschutz-Einstellungen hier.
<G-vec00090-002-s822><check.überprüfen><en> If you do not receive the email, please check your spam folder.
<G-vec00090-002-s822><check.überprüfen><de> Solltest du diese E-Mail nicht erhalten, dann überprüfe bitte deinen Spam-Ordner.
<G-vec00090-002-s823><check.überprüfen><en> Hello, I'm not live right now but check out my video.
<G-vec00090-002-s823><check.überprüfen><de> Hallo, ich bin in diesem Augenblick nicht live, aber überprüfe mein Video unten.
<G-vec00090-002-s824><check.überprüfen><en> Please check, if your application is complete.
<G-vec00090-002-s824><check.überprüfen><de> Bitte überprüfe, ob Deine Bewerbung vollständig ist.
<G-vec00090-002-s825><check.überprüfen><en> Browse the Applications menu again and check what you've got installed so far.
<G-vec00090-002-s825><check.überprüfen><de> Durchsuche erneut das Applications Menü und überprüfe was Du bis jetzt installiert hast.
<G-vec00090-002-s826><check.überprüfen><en> Therefore all my works are unique, I check them.
<G-vec00090-002-s826><check.überprüfen><de> Deshalb sind alle meine Werke einzigartig, ich überprüfe sie.
<G-vec00090-002-s827><check.überprüfen><en> From time to time I check on the Google ranking of this blog for popular search terms.
<G-vec00090-002-s827><check.überprüfen><de> Von Zeit zu Zeit überprüfe ich das Google Ranking dieses Blogs für populäre Suchbegriffe.
<G-vec00090-002-s828><check.überprüfen><en> I will check it for you before sending the sample.
<G-vec00090-002-s828><check.überprüfen><de> Ich überprüfe sie auf Ihnen, bevor ich die Probe sende.
<G-vec00090-002-s829><check.überprüfen><en> Thanks, I will check Walmart.
<G-vec00090-002-s829><check.überprüfen><de> Dank, überprüfe ich Walmart.
<G-vec00090-002-s830><check.überprüfen><en> I also check whether the light on the objects in the showcases and the posters on the wall is not too bright.
<G-vec00090-002-s830><check.überprüfen><de> Außerdem überprüfe ich, ob die Lichtintensität auf den Objekten in den Vitrinen und den Plakaten an den Wänden nicht zu hoch ist.
<G-vec00090-002-s831><check.überprüfen><en> 0–422 Please check your email inbox and confirm your registration.
<G-vec00090-002-s831><check.überprüfen><de> Bitte überprüfe dein E-Mail Postfach und bestätige deine Anmeldung.
<G-vec00090-002-s832><check.überprüfen><en> Please, check the four-digit number 1030 (before the regional code, or ECE in this case), in the same place on your Navi System sat nav.
<G-vec00090-002-s832><check.überprüfen><de> Bitte überprüfe die vierstellige Ziffer (vor dem regionalen Code, hier ECE) im gleichen Bereich der Einstellungen deines Navigationssystems.
<G-vec00090-002-s833><check.überprüfen><en> Tap on “About Phone” and check which operating system your phone is running.
<G-vec00090-002-s833><check.überprüfen><de> Tippe auf „über das Telefon“ und überprüfe, welches Betriebssystem auf deinem Telefon läuft.
<G-vec00090-002-s834><check.überprüfen><en> For example, if my OneDrive or Office Online accounts aren’t responding, I check the Microsoft service status website.
<G-vec00090-002-s834><check.überprüfen><de> Wenn beispielsweise meine OneDrive- oder Office Online-Konten nicht antworten, überprüfe ich die Dienststatus-Website von Microsoft.
<G-vec00090-002-s835><check.überprüfen><en> I rarely check my email on this convincingly I ask you.
<G-vec00090-002-s835><check.überprüfen><de> Ich überprüfe meine E-Mail nur selten überzeugend, frage ich Sie.
<G-vec00090-002-s836><check.überprüfen><en> Whenever weather conditions change, Corralco Mountain & Ski Resort snow conditions will change too, so it is important to check the time and date of the Corralco Mountain & Ski Resort snow report and to guess what effect the weather will have had on snow quality between then and now.
<G-vec00090-002-s836><check.überprüfen><de> Wenn Wetterbedingungen sich ändern, werden sich auch die Schnebedingungen in Thredbo ändern, so ist es wichtig, die Zeit und das Datum des Berichtes für Thredbo zu überprüfen und zu erraten, welche Auswirkungen das Wetter auf die Schnee Qualität zwischen damals und heute haben wird.
<G-vec00090-002-s837><check.überprüfen><en> Please add your dates to check the availability at Maison Vintage Chambre d'Hôtes, Carcassonne
<G-vec00090-002-s837><check.überprüfen><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im Ocean Blue Hostel, Miami Beach zu überprüfen.
<G-vec00090-002-s838><check.überprüfen><en> In addition to checking the Cerro Catedral snow report we recommend that you check the snow forecasts found in the menu at the top of the page along with our ski resort guide.
<G-vec00090-002-s838><check.überprüfen><de> Außerdem ist es empfohlen, neben dem Schigebiet Dachstein Glacier auch den Schneebericht zu überprüfen, welches am Anfang der Seite zu finden ist.
<G-vec00090-002-s839><check.überprüfen><en> We recommend you to check list of installed programs and search for Web Updater entry or other unknown and suspicious programs.
<G-vec00090-002-s839><check.überprüfen><de> Wir empfehlen Ihnen, die Liste der installierten Programme zu überprüfen und nach Web Updater -Eintrag oder anderen unbekannten und verdächtigen Programmen zu suchen.
<G-vec00090-002-s840><check.überprüfen><en> Please refer to the below section "How to check cookies" for details on how to withdraw your consent.
<G-vec00090-002-s840><check.überprüfen><de> Einzelheiten zur Rücknahme der Einwilligung finden Sie im Abschnitt "Wie sind die Cookies zu überprüfen“.
<G-vec00090-002-s841><check.überprüfen><en> 1 Use free online applications that don't require subscriptions or sign-ups to check electronic documents.
<G-vec00090-002-s841><check.überprüfen><de> 1 Nutze kostenlose Onlinedienste, die keine Anmeldung erfordern, um elektronische Dokumente zu überprüfen.
<G-vec00090-002-s842><check.überprüfen><en> The direct connection between your trademarks and your domains allows you to develop and check your individual domain and trademark strategy internally or with the help of external experts.
<G-vec00090-002-s842><check.überprüfen><de> Die direkte Verbindung zwischen Ihren Marken und Ihren Domains lässt Sie intern oder unter Zuhilfenahme externer Experten Ihre individuelle Domains- und Markenstrategie entwickeln und überprüfen.
<G-vec00090-002-s843><check.überprüfen><en> “The machine requires less maintenance as it has no engine – we don't need to check the engine oil and coolant every day or refill fuel.
<G-vec00090-002-s843><check.überprüfen><de> Wir müssen weder Motoröl noch Kühlflüssigkeit überprüfen oder Treibstoff nachfüllen – wir laden die Maschine einfach über Nacht auf.
<G-vec00090-002-s844><check.überprüfen><en> So I can check who's bumping and what.
<G-vec00090-002-s844><check.überprüfen><de> So kann ich überprüfen, wer arbeitet und was.
<G-vec00090-002-s845><check.überprüfen><en> Therefor it is important to check every booking.
<G-vec00090-002-s845><check.überprüfen><de> Aus diesem Grund ist es äußerst wichtig, jede einzelne Buchung zu überprüfen.
<G-vec00090-002-s846><check.überprüfen><en> It is therefore extremely important to regularly check the state they are in, especially if the brake discs of your RAV are not provided with a wear contact, which tells you when it is time to replace them.
<G-vec00090-002-s846><check.überprüfen><de> Wir raten Ihnen daher, den Verschleiß dieser Teile regelmäßig zu überprüfen, vor allem wenn die Bremsscheiben vorne Ihres RAV keine Verschleißwarnanzeiger enthalten, die angeben, wann Ihre Scheiben gewechselt werden sollten.
<G-vec00090-002-s847><check.überprüfen><en> If you're visiting Aduana Square, Cartagena with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00090-002-s847><check.überprüfen><de> Wenn Sie Plaza de la Aduana mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00090-002-s848><check.überprüfen><en> After you click Submit, we’ll automatically check the meta tag and claim your website.
<G-vec00090-002-s848><check.überprüfen><de> Wenn du auf „Absenden“ klickst, überprüfen wir das Meta-Tag automatisch und verifizieren deine Webseite.
<G-vec00090-002-s849><check.überprüfen><en> Ardell Directions: Check fit: Align band with natural lash line to check fit.
<G-vec00090-002-s849><check.überprüfen><de> Ardell Anwendung: Passform überprüfen: Das Wimpernband auf die natürlichen Wimpern legen.
<G-vec00090-002-s850><check.überprüfen><en> Let check and optimize your Wi-Fi.
<G-vec00090-002-s850><check.überprüfen><de> Lassen Sie Ihr WLAN überprüfen und optimieren.
<G-vec00090-002-s851><check.überprüfen><en> As for the volume, I will check it out because I never heard of a similar complaint.
<G-vec00090-002-s851><check.überprüfen><de> Ich werde auch das Volumen überprüfen, da ich noch keine derartigen Beschwerden hatte.
<G-vec00090-002-s852><check.überprüfen><en> Please add your dates to check the availability at ibis Dubai Mall of the Emirates Hotel, Dubai
<G-vec00090-002-s852><check.überprüfen><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im ibis Melbourne Little Bourke Street, Melbourne zu überprüfen.
<G-vec00090-002-s853><check.überprüfen><en> If you're visiting Queenscliff Beach, Manly with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00090-002-s853><check.überprüfen><de> Wenn Sie Queenscliff Beach mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00090-002-s854><check.überprüfen><en> You should always check your local declination from a trusted source before you start navigating.
<G-vec00090-002-s854><check.überprüfen><de> Bevor Sie mit dem Navigieren beginnen, sollten Sie die Deklination vor Ort immer überprüfen.
<G-vec00090-002-s855><check.überprüfen><en> In order to avoid misuse, staff at registration offices and private companies have to be able to check both quickly and reliably whether the documents presented are genuine or not.
<G-vec00090-002-s855><check.überprüfen><de> Auch Mitarbeiter in Meldestellen und vielen Unternehmen müssen – um Missbrauch zu vermeiden – vorgelegte Ausweisdokumente schnell und zuverlässig darauf überprüfen können, ob sie echt oder gefälscht sind.
<G-vec00090-002-s856><check.überprüfen><en> If your used Durango Truck comes with plastic and sintered brass ring type bearings, check the shafts that run in them for wear.
<G-vec00090-002-s856><check.überprüfen><de> Wenn Ihr HSP Monster Truck kommt mit Kunststoff-und Messingring Sinterlagern, überprüfen Sie die Antriebswellen auf Verschleiß.
<G-vec00090-002-s857><check.überprüfen><en> Choose the type of road (with or without highway), avoid toll roads, select the means of travel (car, public transit, cycling, walking), check the traffic situation on the road from Valley, NE to Alum Rock, CA.
<G-vec00090-002-s857><check.überprüfen><de> Wählen Sie den Typ der Straße (mit oder ohne Autobahn), Mautstraßen vermeiden, wählen Sie das Verkehrsmittel (Auto, öffentlichen Verkehrsmitteln, Fahrradfahren, Reise zu Fuß), überprüfen Sie die Verkehrssituation auf der Straße von Elk Creek, NE nach Guadalupe, CA.
<G-vec00090-002-s858><check.überprüfen><en> Please check my other listings if you wish to reserve just a room.
<G-vec00090-002-s858><check.überprüfen><de> Bitte überprüfen Sie meine anderen Angebote, wenn Sie nur ein Zimmer reservieren möchten.
<G-vec00090-002-s859><check.überprüfen><en> To see if your unit has the ability to connect to the Internet, check the specifications or supplied operations guide.
<G-vec00090-002-s859><check.überprüfen><de> Um zu erfahren, ob Ihr Gerät über die in dieser Lösung angesprochenen Funktionen verfügt, überprüfen Sie die Spezifikationen oder die Bedienungsanleitung.
<G-vec00090-002-s860><check.überprüfen><en> Please check them or write us to LifeMiles Support.
<G-vec00090-002-s860><check.überprüfen><de> Bitte überprüfen Sie diese oder schreiben Sie an den LifeMiles-Support.
<G-vec00090-002-s861><check.überprüfen><en> If you’re using an external microphone, check that its plugged in.
<G-vec00090-002-s861><check.überprüfen><de> Falls Sie ein externes Mikrofon verwenden, überprüfen Sie, ob es eingesteckt ist.
<G-vec00090-002-s862><check.überprüfen><en> Please check that your room is clean.
<G-vec00090-002-s862><check.überprüfen><de> Bitte überprüfen Sie, dass Ihr Zimmer ist sauber.
<G-vec00090-002-s863><check.überprüfen><en> Please check your input in the highlighted fields.
<G-vec00090-002-s863><check.überprüfen><de> Bitte überprüfen Sie Ihre Eingaben in den markierten Feldern.
<G-vec00090-002-s864><check.überprüfen><en> If your used Traxxas model comes with plastic and sintered brass ring type bearings, check the shafts that run in them for wear.
<G-vec00090-002-s864><check.überprüfen><de> Wenn Ihr Durango model kommt mit Kunststoff-und Messingring Sinterlagern, überprüfen Sie die Antriebswellen auf Verschleiß.
<G-vec00090-002-s865><check.überprüfen><en> Please check whether the email has been sent to the spam folder of your mailbox.
<G-vec00090-002-s865><check.überprüfen><de> Bitte überprüfen Sie, ob die E-Mail im Spam-Ordner Ihres Mail-Postfaches abgelegt wurde.
<G-vec00090-002-s866><check.überprüfen><en> X * We weren't able to post your message, please check the highlighted fields and try again.
<G-vec00090-002-s866><check.überprüfen><de> Verkäufer Head Kontaktieren X * Ihre Anfrage kann nicht verschickt werden, bitte überprüfen Sie die markierten Eingabefelder.
<G-vec00090-002-s867><check.überprüfen><en> If your used MCD Buggy comes with plastic and sintered brass ring type bearings, check the shafts that run in them for wear.
<G-vec00090-002-s867><check.überprüfen><de> Wenn Ihr Kyosho Truck kommt mit Kunststoff-und Messingring Sinterlagern, überprüfen Sie die Antriebswellen auf Verschleiß.
<G-vec00090-002-s868><check.überprüfen><en> Please check your entry and try again.
<G-vec00090-002-s868><check.überprüfen><de> Bitte überprüfen Sie Ihre Eingabe und versuchen Sie es erneut.
<G-vec00090-002-s869><check.überprüfen><en> If your used Nichimo model comes with plastic and sintered brass ring type bearings, check the shafts that run in them for wear.
<G-vec00090-002-s869><check.überprüfen><de> Wenn Ihr Intech model kommt mit Kunststoff-und Messingring Sinterlagern, überprüfen Sie die Antriebswellen auf Verschleiß.
<G-vec00090-002-s870><check.überprüfen><en> Please check straight away, and before leaving the plane, that the contents of the bag containing your items corresponds with your order.
<G-vec00090-002-s870><check.überprüfen><de> Bitte überprüfen Sie unverzüglich, noch vor Verlassen des Flugzeugs, dass der Inhalt der ausgehändigten Warentüte mit Ihrer Bestellung übereinstimmt.
<G-vec00090-002-s871><check.überprüfen><en> If your used Traxxas Truck comes with plastic and sintered brass ring type bearings, check the shafts that run in them for wear.
<G-vec00090-002-s871><check.überprüfen><de> Wenn Ihr MCD Monster Truck kommt mit Kunststoff-und Messingring Sinterlagern, überprüfen Sie die Antriebswellen auf Verschleiß.
<G-vec00090-002-s872><check.überprüfen><en> Choose the type of road (with or without highway), avoid toll roads, select the means of travel (car, public transit, cycling, walking), check the traffic situation.
<G-vec00090-002-s872><check.überprüfen><de> Wählen Sie den Typ der Straße (mit oder ohne Autobahn), Mautstraßen vermeiden, wählen Sie das Verkehrsmittel (Auto, öffentlichen Verkehrsmitteln, Radfahren, Fuß), überprüfen Sie die Verkehrslage zu Los Ranchitos, CA.
<G-vec00090-002-s873><check.überprüfen><en> Please check the Albania ferry timetable via the booking engine of our website in order to find all possible routes from Durres and to compare all ferry operators.
<G-vec00090-002-s873><check.überprüfen><de> Bitte überprüfen Sie den Albanien Fahrplan über die Buchungsmaschine unserer Website, um alle möglichen Routen zu finden und alle Reedereien zu vergleichen.
<G-vec00090-002-s874><check.überprüfen><en> The Quick Check tests foundational skills in reading and listening.
<G-vec00090-002-s874><check.überprüfen><de> Der Kurztest überprüft grundlegende Fähigkeiten in den Bereichen Lese- und Hörverständnis.
<G-vec00090-002-s875><check.überprüfen><en> Please note that for reservations that are not paid in advance, the property will check your credit card prior to arrival in order to ensure your booking.
<G-vec00090-002-s875><check.überprüfen><de> Bitte beachten Sie, dass bei nicht im Voraus bezahlten Buchungen Ihre Kreditkarte von der Unterkunft als Buchungsgarantie überprüft wird.
<G-vec00090-002-s876><check.überprüfen><en> Once you have submitted the form, Skype will check your group details and contact you to confirm your request.
<G-vec00090-002-s876><check.überprüfen><de> Nachdem Sie das Formular übermittelt haben, überprüft Skype die Gruppendetails und setzt sich mit Ihnen in Verbindung, um die Anfrage zu bestätigen.
<G-vec00090-002-s877><check.überprüfen><en> Due to differing hardware designs, the new NAS will automatically check if a firmware update is required before system migration.
<G-vec00090-002-s877><check.überprüfen><de> Aufgrund unterschiedlicher Hardwarekonfigurationen überprüft das neue NAS automatisch, ob vor der Systemmigration eine Firmware-Aktualisierung erforderlich ist.
<G-vec00090-002-s878><check.überprüfen><en> K&P does not constantly check the contents of the linked websites.
<G-vec00090-002-s878><check.überprüfen><de> K&P Computer überprüft die Inhalte der verlinkten Webseiten nicht ständig.
<G-vec00090-002-s879><check.überprüfen><en> If you bet with a betting exchange, you should check the exact commission rules.
<G-vec00090-002-s879><check.überprüfen><de> Beim Wetten an Wettbörsen sollten immer die exakten Kommissionsrichtlinien überprüft werden.
<G-vec00090-002-s880><check.überprüfen><en> OG has an API function to check access to an entity which is in a group "context".
<G-vec00090-002-s880><check.überprüfen><de> OG verfügt über eine API Funktion, welche den Zugang zu einer Instanz in einem Gruppen Kontext überprüft.
<G-vec00090-002-s881><check.überprüfen><en> If you need to know how to check serial ports in the Windows operating system, you will find there are no native tools to perform this task.
<G-vec00090-002-s881><check.überprüfen><de> Wenn Sie wissen müssen, wie serielle Schnittstellen im Windows-Betriebssystem überprüft werden, finden Sie keine nativen Tools, um diese Aufgabe auszuführen.
<G-vec00090-002-s882><check.überprüfen><en> According to your and our interest in data security we continuously check and adjust our security measures in order to achieve a higher protection standard.
<G-vec00090-002-s882><check.überprüfen><de> Unserem und Ihrem Interesse an Datensicherheit entsprechend werden diese Sicherungsmaßnahmen laufend überprüft und angepasst, um einen höheren Schutzstandard zu erreichen.
<G-vec00090-002-s883><check.überprüfen><en> Our system check determines the bandwidth of your Internet connection.
<G-vec00090-002-s883><check.überprüfen><de> Unser Systemcheck überprüft die Bandbreite und damit die Qualität Ihrer Internetverbindung.
<G-vec00090-002-s884><check.überprüfen><en> The author uses the data of an empirical investigation in 2004 consisting of interviews with people in the street (N = 1 492) to check if this problematic situation is still existing.
<G-vec00090-002-s884><check.überprüfen><de> Anhand der Befunde einer im Jahr 2004 durchgeführten Passantenbefragung (N = 1 492) wird überprüft, ob dies nach wie vor ein Hemmfaktor für die Innenstadtentwicklung darstellt.
<G-vec00090-002-s885><check.überprüfen><en> Your Credit Card Data will be encrypted and securely transmitted with the purpose of a validity check.
<G-vec00090-002-s885><check.überprüfen><de> Ihre Kreditkartendaten werden verschlüsselt und unter strengen Sicherheitsmassnahmen auf ihre Gültigkeit und Bonität überprüft.
<G-vec00090-002-s886><check.überprüfen><en> Here you can check the information again.
<G-vec00090-002-s886><check.überprüfen><de> Hier können die Angaben nochmal überprüft werden.
<G-vec00090-002-s887><check.überprüfen><en> At the same time, it is necessary to check the consistency of the products.
<G-vec00090-002-s887><check.überprüfen><de> Gleichzeitig muss die Konsistenz der Produkte überprüft werden.
<G-vec00090-002-s888><check.überprüfen><en> These will check the amount of blood cells (white blood cells, red blood cells and platelets) in your body to see if Afinitor is having an unwanted effect on these cells.
<G-vec00090-002-s888><check.überprüfen><de> Dabei wird überprüft, wie viele Blutzellen (weiße Blutkörperchen, rote Blutkörperchen und Blutplättchen) sich in Ihrem Körper befinden, um festzustellen, ob Afinitor auf diese Zellen eine unerwünschte Wirkung hat.
<G-vec00090-002-s889><check.überprüfen><en> That is why we have undertaken a voluntary technical evaluation process of our HardWood Clip fastening system® in order to check and vouch for its compliance with regulations and standards in force in France and Belgium, which guarantee the construction of a stable and perennial structure.
<G-vec00090-002-s889><check.überprüfen><de> Deshalb haben wir auf freiwilliger Basis ein technisches Bewertungsverfahren unseres Befestigungssystems HardWood Clip® eingeführt, das die Einhaltung der Vorschriften und Anforderungen der in Frankreich und Belgien gültigen Normen überprüft und bescheinigt, die die Konstruktion eines stabilen und langlebigen Bauwerks garantieren.
<G-vec00090-002-s890><check.überprüfen><en> These commands check the instance document for duplicate facts and report any found duplicates in the Messages window.
<G-vec00090-002-s890><check.überprüfen><de> Mit diesen Befehlen wird das Instanzdokument auf doppelt vorhandene Facts überprüft und gefundene Duplikate werden im Fenster "Meldungen" aufgelistet.
<G-vec00090-002-s891><check.überprüfen><en> When you log into the Router’s advanced interface, the Router will perform a check to see if new firmware is available.
<G-vec00090-002-s891><check.überprüfen><de> Wenn Sie sich an der Webgestützten Erweiterten Benutzeroberfläche des Routers anmelden, überprüft der Router, ob neue Firmware verfügbar ist.
<G-vec00090-002-s892><check.überprüfen><en> Where an operator or an aircraft operator is not able to obtain such approval in time, the verifier shall check whether the approach used by the operator or aircraft operator to complete the missing data ensures that the emissions are not underestimated and that this approach does not lead to material misstatements.
<G-vec00090-002-s892><check.überprüfen><de> Kann ein Anlagen- oder Luftfahrzeugbetreiber diese Genehmigung nicht rechtzeitig einholen, so überprüft die Prüfstelle, ob das vom Anlagen- oder Luftfahrzeugbetreiber verwendete Konzept zur Ergänzung fehlender Daten gewährleistet, dass die Emissionen nicht zu niedrig veranschlagt werden, und dass dieses Konzept nicht zu wesentlichen Falschangaben führt.
