<G-vec00637-002-s006><crouch_down.beugen><en> 13 "God will not turn back His anger; Beneath Him crouch the helpers of Rahab.
<G-vec00637-002-s006><crouch_down.beugen><de> 13 Gott wendet seinen Zorn nicht ab, unter ihn beugten sich die Helfer Rahabs.
<G-vec00637-002-s009><crouch_down.bücken><en> The side street in which we lived in is characterized by humpy cobblestones and the low crossbeam at the end of the street where those bigger than me have to crouch in order to pass it.
<G-vec00637-002-s009><crouch_down.bücken><de> Unsere Gasse zeichnet sich auch durch die Pflastersteine aus, die so richtig schön buckelig sind, und am Einstieg in die Gasse gibt es einen niedrigen Querbalken, unter dem sich Menschen, die größer sind als ich bücken müssen.
<G-vec00637-002-s019><crouch_down.ducken><en> Press Arrow up to jump and Arrow down to crouch.
<G-vec00637-002-s019><crouch_down.ducken><de> Drücke Pfeil runter zum Ducken und Pfeil rauf zum Springen.
<G-vec00637-002-s020><crouch_down.ducken><en> This suspension will also allow it to go into the “crouch” mode, increasing its camouflage factor and aiming time at the expense of mobility and viewrange.
<G-vec00637-002-s020><crouch_down.ducken><de> Dank dieser Funktion wird sich der Panzer auch "ducken" können und damit den Tarnfaktor und die Zielzeit auf Kosten von Mobilität und Sichtweite erhöhen.
<G-vec00637-002-s021><crouch_down.ducken><en> Crouch or you do not twist your torso.
<G-vec00637-002-s021><crouch_down.ducken><de> Ducken oder verdrehen Sie nicht den Oberkörper.
<G-vec00637-002-s022><crouch_down.ducken><en> Up and Down Arrow keys to climb up and down the ropes and crouch.
<G-vec00637-002-s022><crouch_down.ducken><de> Auf und ab die Pfeiltasten, zum auf und ab die Seile zu klettern und sich zu ducken.
<G-vec00637-002-s023><crouch_down.ducken><en> Crouch on the SQUAT and sticks you in the chest then her mÃ ¼ sstet be left of the crate.
<G-vec00637-002-s023><crouch_down.ducken><de> Duckt euch auf die HOCKE und klebt euch an die kiste dann müsstet ihr links von der kiste sein.
<G-vec00637-002-s024><crouch_down.ducken><en> Crouch down and lick the hands which feed you.
<G-vec00637-002-s024><crouch_down.ducken><de> Duckt Euch und leckt die Hände, die Euch füttern.
<G-vec00637-002-s042><crouch_down.ducken><en> The shower is made rather small man, if you're big on 1,70m, you have to crouch.
<G-vec00637-002-s042><crouch_down.ducken><de> Die Dusche ist eher für kleine Menschen gemacht, wenn man über 1,70m gross ist, muss man sich ducken.
<G-vec00637-002-s033><crouch_down.gehen><en> When shooting puddle reflections, you’ll get the best results if you crouch down and shoot from a low angle.
<G-vec00637-002-s033><crouch_down.gehen><de> Beim Fotografieren von Pfützenspiegelungen erhalten Sie die besten Ergebnisse, wenn Sie in die Hocke gehen und von einem tiefen Winkel aus Fotos machen.
<G-vec00637-002-s028><crouch_down.hocken><en> First, a red gate, then a blue one and it's off into the crouch.
<G-vec00637-002-s028><crouch_down.hocken><de> Zuerst ein rotes Tor, dann ein blaues und ab in die Hocke.
<G-vec00637-002-s029><crouch_down.hocken><en> In this trick, wakeboarders crouch down and catapult themselves up with the board and then land on the water again as elegantly as possible.
<G-vec00637-002-s029><crouch_down.hocken><de> Bei diesem Trick geht der Fahrer in die Hocke und katapultiert sich mit dem Brett hoch, um dann wieder (möglichst elegant) auf dem Wasser zu landen.
<G-vec00637-002-s030><crouch_down.hocken><en> FLB members crouch, trace the lines of the body, examine the interior, compare details, and tap the lightweight construction components.
<G-vec00637-002-s030><crouch_down.hocken><de> Die FLB-Mitglieder gehen in die Hocke, peilen an den Karosserielinien entlang, erkunden den Innenraum, vergleichen Details und tippen auf die Leichtbauscheiben.
<G-vec00637-002-s031><crouch_down.hocken><en> Slide down into a crouch, getting so that your knees are at a 90-degree angle.
<G-vec00637-002-s031><crouch_down.hocken><de> Rutsche in eine Hocke hinunter, so dass sich deine Knie in einem 90-Grad-Winkel befinden.
<G-vec00637-002-s032><crouch_down.hocken><en> From standing crouch down and place your hands on the floor, shoulder-width apart.
<G-vec00637-002-s032><crouch_down.hocken><de> Hocke dich hin und setze deine Hände vor dir auf dem Boden ab.
<G-vec00637-002-s034><crouch_down.hocken><en> Made with the cel-shading technique along the lines of Borderlands, Rico looks like a classic FPS: the controls are in fact the same as all the games of the genre and, as usual, you can crouch or make a slip while you run.
<G-vec00637-002-s034><crouch_down.hocken><de> Hergestellt mit der Cel-Shading-Technik entlang der Linien von Borderlands, Rico sieht aus wie ein klassischer FPS: Die Bedienelemente sind in der Tat die gleichen wie bei allen anderen Genres, und wie üblich können Sie sich beim Laufen hocken oder ausrutschen.
<G-vec00637-002-s035><crouch_down.hocken><en> Regularly using spray ArthroNEO for joints pain you can return to an active lifestyle, easy to walk, run, crouch or even jump.
<G-vec00637-002-s035><crouch_down.hocken><de> Regelmäßig mit spray ArthroNEO gegen Gelenkschmerzen können Sie zu einem aktiven Lebensstil zurückkehren, einfach zu laufen, zu laufen, zu hocken oder sogar zu springen.
<G-vec00637-002-s027><crouch_down.kauern><en> This restricted the freedom of movement so that the prisoners could not stretch themselves out, but could only crouch.
<G-vec00637-002-s027><crouch_down.kauern><de> Dadurch war die Bewegungsfreiheit so eingeschränkt, dass die Gefangenen sich nicht ausstrecken, sondern nur gekrümmt kauern konnten.
<G-vec00637-002-s037><crouch_down.kauern><en> They crouch on the truck beds, their uniforms torn, their bazookas rusty and their eyes red and swollen from drinking Primus beer.
<G-vec00637-002-s037><crouch_down.kauern><de> Sie kauern auf den Ladeflächen, ihre Uniformen sind zerrissen, ihre Panzerfäuste rostig, die Augen rötlich verschwollen vom Primus-Bier.
<G-vec00637-002-s042><crouch_down.sich_ducken><en> The shower is made rather small man, if you're big on 1,70m, you have to crouch.
<G-vec00637-002-s042><crouch_down.sich_ducken><de> Die Dusche ist eher für kleine Menschen gemacht, wenn man über 1,70m gross ist, muss man sich ducken.
