<G-vec00599-002-s019><crumble.abbröckeln><en> The walls are damp in many places, causing the color to crumble at certain areas.
<G-vec00599-002-s019><crumble.abbröckeln><de> Die Wände sind an vielen Stellen feucht, wodurch auch die Farbe zum Teil abbröckelt.
<G-vec00599-002-s020><crumble.abbröckeln><en> This gloss is of course not creamy at all, but other long lasting lipssticks neither are and with most other long lasting lip sticks you will have to re-moist them with a special balm or gloss so that they won’t dry out and crumble.
<G-vec00599-002-s020><crumble.abbröckeln><de> Der Gloss ist natürlich nicht cremig, aber das sind andere langanhaltende Lippenstifte auch nicht und müssen sogar oft mit einem beiliegenden Gloss nachgefettet werden damit die Farbe nicht abbröckelt.
<G-vec00599-002-s023><crumble.belassen><en> They will crumble again if the Europeans in Libya fail to move beyond arguing over the ‘cake’.
<G-vec00599-002-s023><crumble.belassen><de> Und sie wird wieder scheitern, wenn die Europäer es dabei belassen, sich um den libyschen Kuchen zu zanken.
<G-vec00599-002-s024><crumble.beschichten><en> In this delicious twist on the favorite cinnamon oatmeal raisin cookie, an oatmeal cookie crust is layered with a tangy buttermilk custard, sweet rum raisin sauce and a crunchy oat crumble.
<G-vec00599-002-s024><crumble.beschichten><de> In dieser köstlichen Variante der beliebten Zimt-Haferflocken-Rosinen-Guetzli wird ein Haferflockenguetzli-Boden mit einer würzigen Buttermilch-Eiercreme, einer süssen Rum-Rosinen-Sauce und einem knusprigen Haferflockenstreusel beschichtet.
<G-vec00599-002-s025><crumble.besiegen><en> When the police had to abandon their attempts to prevent demonstrations in sheer impotence in 1910, that was a first sign of the state’s coercive powers beginning to crumble away; and the content of revolution consists in the total destruction of these powers.
<G-vec00599-002-s025><crumble.besiegen><de> Aber auch die heutigen Aktionen, die einfachen Straßendemonstrationen, zeitigen schon im kleinen Maßstab diese Wirkung; als die Polizei 1910 machtlos den Versuch aufgeben musste, die Demonstrationen zu verhindern, bedeutete das eine erste Abbröckelung der Macht der Staatsgewalt, die völlig zu besiegen den Inhalt der Revolution bildet.
<G-vec00599-002-s046><crumble.bröckeln><en> A screen grinder is a handy alternative to cut or crumble the marijuana and other herbs.
<G-vec00599-002-s046><crumble.bröckeln><de> Ein Siebgrinder ist eine praktische Alternative zum Bröckeln oder Verkrümeln von Marihuana und anderen Kräutern.
<G-vec00599-002-s051><crumble.bröseln><en> This is when the leaf material looks pretty dried out, but it does not crumble.
<G-vec00599-002-s051><crumble.bröseln><de> Das ist der Fall, wenn das Blattmaterial ziemlich trocken aussieht, aber nicht bröselt.
<G-vec00599-002-s067><crumble.eingehen><en> This long and intense preparation period is desperately needed if you do not want to completely crumble before this “most extreme experience in the Alps”.
<G-vec00599-002-s067><crumble.eingehen><de> Diese lange und intensive Vorbereitungsphase ist auch bitter notwendig, wenn man bei der „extremsten Erfahrung in den Alpen“ nicht komplett eingehen will.
<G-vec00599-002-s071><crumble.einstürzen><en> And that’s when the building starts to crumble.
<G-vec00599-002-s071><crumble.einstürzen><de> Und genau in dem Moment beginnt das Gebäude einzustürzen.
<G-vec00599-002-s072><crumble.erzittern><en> Earthquakes are causing cities around the world to crumble!
<G-vec00599-002-s072><crumble.erzittern><de> Erdbeben lassen in der ganzen Welt Städte erzittern.
<G-vec00599-002-s074><crumble.knacken><en> The Islamic doctrine is expected to gradually creep into everyday life and Fortress Europe will crumble from within.
<G-vec00599-002-s074><crumble.knacken><de> Die islamische Doktrin soll sich allmählich in den Alltag einschleichen und die Festung Europa von Innen knacken.
<G-vec00599-002-s076><crumble.krümeln><en> Afterwards crumble the feta cheese over it and the rosemary twigs.
<G-vec00599-002-s076><crumble.krümeln><de> Anschließend den Feta-Käse darüber krümeln und Rosmarin darüber geben.
<G-vec00599-002-s077><crumble.krümeln><en> Then crumble the goat’s cheese over the omelette and place a lid over the pan.
<G-vec00599-002-s077><crumble.krümeln><de> Anschließend den Ziegenkäse auf das Omelett krümeln, einen Deckel auf die Pfanne setzen.
<G-vec00599-002-s097><crumble.streuseln><en> Fill the filling into the baking form, place the red currants on top and cover with the remaining crumble.
<G-vec00599-002-s097><crumble.streuseln><de> Die Quarkmasse in die Springform füllen, die Johannisbeeren darauf verteilen und mit den restlichen Streuseln bedecken.
<G-vec00599-002-s098><crumble.streuseln><en> Reducing the oil: For a low-fat variation, use only half of the specified oil and combine it directly with the “crumble” and half of the grated apples.
<G-vec00599-002-s098><crumble.streuseln><de> Öl reduzieren: Für eine fettarme Variante verwenden Sie nur die Hälfte des angegebenen Öls und vermengen dieses direkt mit den "Streuseln" und der Hälfte der geriebenen Äpfel.
<G-vec00599-002-s090><crumble.verfeinern><en> You can also add lemon zest, cinnamon or cocoa to your crumble.
<G-vec00599-002-s090><crumble.verfeinern><de> Du kannst Deine Streusel zusätzlich mit Zitronenschale, Zimt oder Kakao verfeinern.
<G-vec00599-002-s100><crumble.verkrümeln><en> Around the house there was enough space to play, to crumble with a deck chair and a book in a quiet corner or to hop in the pool.
<G-vec00599-002-s100><crumble.verkrümeln><de> Um das Haus gab es genug Platz zum Spielen, sich mit dem Liegestuhl und einem Buch in eine ruhige Ecke verkrümeln zu können oder in den Pool zu hüpfen.
<G-vec00599-002-s101><crumble.verkrümeln><en> Lucia and Alex are very hospitable and relaxed when you want company, you are welcome at the dinner table, but you can also crumble in the quiet room.
<G-vec00599-002-s101><crumble.verkrümeln><de> Lucia und Alex sind sehr gastfreundlich und entspannt, wenn man Gesellschaft möchte, ist man am Esstisch willkommen, man kann sich aber auch in das ruhige Zimmer verkrümeln.
<G-vec00599-002-s102><crumble.wegbröckeln><en> As the fungal infection worsens, it can cause nail discoloration and nails that become thick with pieces that crumble away.
<G-vec00599-002-s102><crumble.wegbröckeln><de> Mit der Verschlimmerung der Pilzinfektion können sich Nägel verschieben oder dick werden und Stücke davon wegbröckeln.
<G-vec00599-002-s104><crumble.zerbrechen><en> In the end, the couple feels that they have to learn from these experiences so that their relationship does not crumble; they accept their needs in their normal everyday life the best they can.
<G-vec00599-002-s104><crumble.zerbrechen><de> Am Ende spürt das Ehepaar, wie beide aus diesen Erfahrungen lernen müssen, damit ihre Beziehung nicht zerbricht, sie akzeptieren ihre Bedürfnisse so gut es geht in ihrem normalen Alltag.
<G-vec00599-002-s119><crumble.zerbröckeln><en> Tablets should be pressed so that they do not crumble, but not hard enough not to let them dissolve quickly in the stomach.
<G-vec00599-002-s119><crumble.zerbröckeln><de> Tabletten müssen so hart gepresst sein, dass sie nicht zerbröckeln, aber nicht härter, als dass sie im Magen aufgelöst werden.
<G-vec00599-002-s136><crumble.zerbröseln><en> We need the rock of valid truth, which doesn’t crumble and break. We need the tight grip of conviction with which we hold fast to truth.
<G-vec00599-002-s136><crumble.zerbröseln><de> Wir brauchen den Felsen gültiger Wahrheit, der nicht zerbröselt und zerbricht, und wir brauchen den festen Griff der Überzeugung, mit dem wir uns an dieser Wahrheit festhalten.
<G-vec00599-002-s149><crumble.zerfallen><en> In this case, they either block the print heads partially, whereby the printed model does not reach the necessary strength, meaning, the model already crumble in the printing chamber.
<G-vec00599-002-s149><crumble.zerfallen><de> Dabei verstopfen sie die Druckköpfe entweder teilweise, wodurch das gedruckte Modell nicht die nötige Festigkeit erreicht, d.h. es zerfällt bereits im Druckraum.
<G-vec00599-002-s150><crumble.zerkleinern><en> To make this protein cheesecake you crumble the cookies first.
<G-vec00599-002-s150><crumble.zerkleinern><de> Um diesen Protein-Käsekuchen zuzubereiten, zerkleinern Sie zuerst die Kekse.
<G-vec00599-002-s151><crumble.zerkleinern><en> Our Puppy dry food is very easy to crumble/blend thanks to a residual moisture content of 18% and the puppies are quite keen on the resulting small pieces.
<G-vec00599-002-s151><crumble.zerkleinern><de> Unsere Puppy-Trockennahrung lässt sich aufgrund der Restfeuchte von 18 % sehr gut zerkleinern und die kleinen Stücke werden in dieser Form gerne von den Welpen angenommen.
<G-vec00599-002-s152><crumble.zerkleinern><en> Tom’s „Best blackberries cream cheese cake“, ingeniously delicious fresh and great in taste, this cake is made quickly and with little ingredients .. recipe Fresh blackberries, 3-4 hands full powdered sugar cream Cream cheese, 220 g Quark (40%), 180 g 4 sheets of gelatine Agave syrup or mulberry syrup ground Butter biscuits about 8-10 pieces Butter, melted 100 g Crumble the biscuits, mix the crumbled biscuits with the melted butter, add the mass to a springform pan which we have lined with baking paper, press firmly to the ground and then refrigerate in the fridge 2 hands of fresh blackberries with some powdered sugar and mulberries syrup or agave syrup to process a must.
<G-vec00599-002-s152><crumble.zerkleinern><de> „Best Brombeeren Frischkäse Torte“, genial lecker frisch und super im Geschmack, diese Torte ist schnell gemacht und mit wenig Zutaten herzustellen .. #ChaosKitchen51 #Baking #Recipes Rezept Frische Kekse ca 8-10 Stück Butter, geschmolzen 100 g Kekse zerkleinern, die zerkrümelten Kekse mit der geschmolzenen Butter vermengen, diese Masse anschließen in einer Springform welche wir mit Backpapier ausgelegt haben, fest an den Boden drücken und dann im Kühlschrank kalt stellen..45Min 2 Hände frische Brombeeren mit etwas Puderzucker und Maulbeeren Sirup oder AgavenDicksaft zu einem Muss verarbeiten.
<G-vec00599-002-s073><crumble.zerkrümeln><en> In another mixing bowl, crumble the gingerbread.
<G-vec00599-002-s073><crumble.zerkrümeln><de> In einer anderen Schüssel das Honigbrot zerkrümeln.
<G-vec00599-002-s158><crumble.zerstampfen><en> Crumble the finished soup and season with nutmeg, salt and pepper.
<G-vec00599-002-s158><crumble.zerstampfen><de> Die fertige Suppe zerstampfen und mit Muskat, Salz und Pfeffer abschmecken.
<G-vec00599-002-s160><crumble.zusammenbrechen><en> A popular stereotype - the world may crumble, money lose value, and diamonds will be more expensive.
<G-vec00599-002-s160><crumble.zusammenbrechen><de> Ein beliebtes Vorurteil - die Welt zusammenbrechen, das Geld an Wert verlieren, und Diamanten wird teurer.
<G-vec00599-002-s161><crumble.zusammenbrechen><en> When our old foundations crumble, it's time to build new ones.
<G-vec00599-002-s161><crumble.zusammenbrechen><de> Wenn unsere alten Fundamente zusammenbrechen ist es an der Zeit, neue zu bauen.
<G-vec00599-002-s162><crumble.zusammenbrechen><en> When our old foundations crumble, it is time to build new ones.
<G-vec00599-002-s162><crumble.zusammenbrechen><de> Wenn unsere alten Fundamente zusammenbrechen, ist es an der Zeit neue zu bauen.
<G-vec00599-002-s163><crumble.zusammenbrechen><en> But even more than that, many will crumble in despair because things will be reversed on them so quickly.
<G-vec00599-002-s163><crumble.zusammenbrechen><de> Aber noch mehr als das, Viele werden verzweifelt zusammenbrechen, da die Dinge so schnell umgedreht und auf sie zurückfallen werden.
<G-vec00599-002-s164><crumble.zusammenfallen><en> When his body did not crumble in the flames, an executioner stabbed him with a dagger.
<G-vec00599-002-s164><crumble.zusammenfallen><de> Als sein Leib im Feuer nicht zusammenfiel hat ein Scharfrichter ihn mit einem Messer erstochen.
