<G-vec00198-002-s019><break_off.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00198-002-s019><break_off.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00198-002-s020><break_off.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00198-002-s020><break_off.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00198-002-s021><break_off.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00198-002-s021><break_off.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00198-002-s022><break_off.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00198-002-s022><break_off.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00198-002-s023><break_off.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00198-002-s023><break_off.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00198-002-s024><break_off.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00198-002-s024><break_off.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00198-002-s025><break_off.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00198-002-s025><break_off.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00198-002-s026><break_off.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00198-002-s026><break_off.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00198-002-s027><break_off.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00198-002-s027><break_off.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00198-002-s028><break_off.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00198-002-s028><break_off.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00198-002-s029><break_off.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00198-002-s029><break_off.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00198-002-s030><break_off.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00198-002-s030><break_off.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00198-002-s031><break_off.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00198-002-s031><break_off.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00198-002-s032><break_off.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00198-002-s032><break_off.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00198-002-s033><break_off.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00198-002-s033><break_off.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00198-002-s034><break_off.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00198-002-s034><break_off.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00198-002-s035><break_off.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00198-002-s035><break_off.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00198-002-s036><break_off.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00198-002-s036><break_off.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00198-002-s037><break_off.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00198-002-s037><break_off.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
