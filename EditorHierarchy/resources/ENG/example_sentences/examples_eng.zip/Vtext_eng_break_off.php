<G-vec00198-002-s019><break_off.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00198-002-s019><break_off.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00198-002-s020><break_off.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00198-002-s020><break_off.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00198-002-s021><break_off.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00198-002-s021><break_off.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00198-002-s022><break_off.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00198-002-s022><break_off.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00198-002-s023><break_off.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00198-002-s023><break_off.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00198-002-s024><break_off.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00198-002-s024><break_off.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00198-002-s025><break_off.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00198-002-s025><break_off.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00198-002-s026><break_off.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00198-002-s026><break_off.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00198-002-s027><break_off.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00198-002-s027><break_off.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00198-002-s028><break_off.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00198-002-s028><break_off.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00198-002-s029><break_off.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00198-002-s029><break_off.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00198-002-s030><break_off.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00198-002-s030><break_off.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00198-002-s031><break_off.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00198-002-s031><break_off.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00198-002-s032><break_off.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00198-002-s032><break_off.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00198-002-s033><break_off.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00198-002-s033><break_off.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00198-002-s034><break_off.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00198-002-s034><break_off.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00198-002-s035><break_off.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00198-002-s035><break_off.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00198-002-s036><break_off.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00198-002-s036><break_off.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00198-002-s037><break_off.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00198-002-s037><break_off.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00681-002-s152><break_off.(sich)_brechen><en> They remain in the jaw covered by bone (referred to as impaction) or break through only partially (partial impaction).
<G-vec00681-002-s152><break_off.(sich)_brechen><de> Sie verbleiben entweder vom Knochen bedeckt im Kiefer (Retention) oder brechen teilweise durch (Teilretention).
<G-vec00681-002-s153><break_off.(sich)_brechen><en> Those who are not ready or who resist, are put through the painful process of breaking, for „bend or break” is the keynote of the Aquarian energy.
<G-vec00681-002-s153><break_off.(sich)_brechen><de> Wer nicht dazu geneigt ist oder gar widersteht, macht den schmerzhaften Prozess durch, gebrochen zu werden, denn „biegen oder brechen“ ist die Schlüsselnote der Wassermann-Energie.
<G-vec00681-002-s154><break_off.(sich)_brechen><en> You cared about us, trust us, and we will not break our promise.
<G-vec00681-002-s154><break_off.(sich)_brechen><de> Sie sorgen sich um uns, vertrauen uns und so werden wir unser Versprechen nicht brechen.
<G-vec00681-002-s155><break_off.(sich)_brechen><en> When you damage a carbon fiber part, it could break or it could conceal damage from the naked eye.
<G-vec00681-002-s155><break_off.(sich)_brechen><de> Wenn du ein Carbonfaser-Teil beschädigst, könnte es brechen oder die Beschädigung nicht auf den ersten Blick zu erkennen sein.
<G-vec00681-002-s156><break_off.(sich)_brechen><en> Behold, thou shalt sleep with thy fathers; and this people will rise up, and go a whoring after the gods of the strangers of the land, whither they go to be among them, and will forsake me, and break my covenant which I have made with them.
<G-vec00681-002-s156><break_off.(sich)_brechen><de> 31,16 Und der HERR sprach zu Mose: Siehe, du wirst schlafen bei deinen Vätern, und dies Volk wird sich erheben und nachlaufen den fremden Göttern des Landes, in das sie kommen, und wird mich verlassen und den Bund brechen, den ich mit ihm geschlossen habe.
<G-vec00681-002-s157><break_off.(sich)_brechen><en> It’s well known that there are a series of potential limitations of CRISPR that can cause what we call “off-target effects”—where basically in addition to breaking what you want to break, it can break something else in your genome.
<G-vec00681-002-s157><break_off.(sich)_brechen><de> Es ist bekannt, dass es eine Reihe von möglichen Einschränkungen von CRISPR gibt, die das verursachen können, was wir "Off-Target-Effekte" nennen - wo es im Grunde genommen nicht nur das, was man brechen will, sondern auch etwas anderes in seinem Genom brechen kann.
<G-vec00681-002-s159><break_off.(sich)_brechen><en> The attempt is not to break Burt’s record, but to appreciate his legacy.
<G-vec00681-002-s159><break_off.(sich)_brechen><de> Der Versuch geht nicht darum, Burts Rekord zu brechen, sondern darum sein Erbe zu würdigen.
<G-vec00681-002-s160><break_off.(sich)_brechen><en> The impact hammers conduct energy into the component and break up the core.
<G-vec00681-002-s160><break_off.(sich)_brechen><de> Die Schlaghämmer leiten die Energie in das Bauteil und brechen den Kern.
<G-vec00681-002-s161><break_off.(sich)_brechen><en> Attach a glass needle onto the microinjector and use your forceps to break the tip of the needle to the desired width.
<G-vec00681-002-s161><break_off.(sich)_brechen><de> Bringen Sie ein Glas Nadel auf die Mikroinjektor und nutzen Sie Ihre Zange an der Spitze der Nadel auf die gewünschte Breite zu brechen.
<G-vec00681-002-s162><break_off.(sich)_brechen><en> It signals that the installation of a package will “break” another package (or particular versions of it).
<G-vec00681-002-s162><break_off.(sich)_brechen><de> Sie deutet darauf hin, dass die Installation eines Paketes ein anderes Paket (oder bestimmte Versionen davon) „brechen“ wird.
<G-vec00681-002-s163><break_off.(sich)_brechen><en> Do not crush, chew, or break the tablet.
<G-vec00681-002-s163><break_off.(sich)_brechen><de> Zerquetschen Sie es, kauen Sie es, oder brechen Sie die Pillen nicht.
<G-vec00681-002-s164><break_off.(sich)_brechen><en> Hamas spokesman Hazem Qassem said that with the approach of the first anniversary of the “return marches,” the Palestinian people were planning to break [into Israeli territory] with the “million-man march” on Land Day to stress the main objectives of the marches.
<G-vec00681-002-s164><break_off.(sich)_brechen><de> Hazem Kassem, ein Sprecher im Namen der Hamas, sagte, dass das palästinensische Volk vor dem ersten Jahrestag der “Prozessionen” vorhatte, anlässlich des “Tag der Erde” mit der “Prozession der Millionen” an Land zu brechen, um die Hauptziele der “Prozessionen der großen Rückkehr” zu erfüllen.
<G-vec00681-002-s165><break_off.(sich)_brechen><en> At the same time, the hammer energy introduced into the component is used to break up the core sand in the component, so this can subsequently be shaken out.
<G-vec00681-002-s165><break_off.(sich)_brechen><de> Zeitgleich wird die in das Bauteil eingebrachte Hammerenergie dazu verwendet, den Kernsand im Bauteil zu brechen, um diesen anschließend herausrütteln zu können.
<G-vec00681-002-s166><break_off.(sich)_brechen><en> It is organized in more or less radical Marxist movements, determined to break all spiritual resistance by the power of violence.
<G-vec00681-002-s166><break_off.(sich)_brechen><de> Sie ist in mehr oder minder radikalmarxistischen Bewegungen zusammengefaßt, entschlossen, jeden geistigen Widerstand durch die Macht der Gewalt zu brechen.
<G-vec00681-002-s167><break_off.(sich)_brechen><en> Wotan tells him that he comes only to watch, since he cannot, as Alberich reminds him, break his agreement with Fafner, who had been given the ring and other treasure in return for the release of the goddess Freia.
<G-vec00681-002-s167><break_off.(sich)_brechen><de> Nur zu schauen sei er gekommen, antwortet Wotan, nicht zu schaffen – und Alberich erinnert seinerseits daran, daß er den Vertrag mit Fafner nicht brechen dürfe, der ja den Ring und den gesamten Schatz als Bezahlung für die Errichtung Walhalls und die Freilassung der Göttin Freia erhalten habe.
<G-vec00681-002-s168><break_off.(sich)_brechen><en> We hope to avoid a new break of the wireline by running it a little bit slower.
<G-vec00681-002-s168><break_off.(sich)_brechen><de> Wir hoffen ein neues Brechen des Bohrkabels durch langsameres Bohren verhindern zu können.
<G-vec00681-002-s169><break_off.(sich)_brechen><en> He would do anything, anything, to break what he calls the superstition of the Cross.
<G-vec00681-002-s169><break_off.(sich)_brechen><de> Er würde alles tun, alles, um das zu brechen, was er den Aberglauben des Kreuzes nennt.
<G-vec00681-002-s170><break_off.(sich)_brechen><en> Do not crush, chew, break, or open an extended-release capsule.
<G-vec00681-002-s170><break_off.(sich)_brechen><de> Zerquetschen Sie nicht, kauen Sie, brechen Sie, oder öffnen Sie eine Kapsel der verlängerten Ausgabe.
<G-vec00681-002-s171><break_off.(sich)_brechen><en> HSL break the body fat shops within your cells.
<G-vec00681-002-s171><break_off.(sich)_brechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00681-002-s172><break_off.(sich)_brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00681-002-s172><break_off.(sich)_brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00681-002-s173><break_off.(sich)_brechen><en> Q Right – but you don’t break his nose.
<G-vec00681-002-s173><break_off.(sich)_brechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00681-002-s174><break_off.(sich)_brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00681-002-s174><break_off.(sich)_brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00681-002-s175><break_off.(sich)_brechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00681-002-s175><break_off.(sich)_brechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00681-002-s176><break_off.(sich)_brechen><en> The part could break without warning (see figure 80).
<G-vec00681-002-s176><break_off.(sich)_brechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00681-002-s177><break_off.(sich)_brechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00681-002-s177><break_off.(sich)_brechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00681-002-s178><break_off.(sich)_brechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00681-002-s178><break_off.(sich)_brechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00681-002-s179><break_off.(sich)_brechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00681-002-s179><break_off.(sich)_brechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00681-002-s180><break_off.(sich)_brechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00681-002-s180><break_off.(sich)_brechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00681-002-s181><break_off.(sich)_brechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00681-002-s181><break_off.(sich)_brechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00681-002-s182><break_off.(sich)_brechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00681-002-s182><break_off.(sich)_brechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00681-002-s183><break_off.(sich)_brechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00681-002-s183><break_off.(sich)_brechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00681-002-s184><break_off.(sich)_brechen><en> HSL break the fat stores within your cells.
<G-vec00681-002-s184><break_off.(sich)_brechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00681-002-s185><break_off.(sich)_brechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00681-002-s185><break_off.(sich)_brechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00681-002-s186><break_off.(sich)_brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00681-002-s186><break_off.(sich)_brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00681-002-s187><break_off.(sich)_brechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00681-002-s187><break_off.(sich)_brechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00681-002-s188><break_off.(sich)_brechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00681-002-s188><break_off.(sich)_brechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00681-002-s189><break_off.(sich)_brechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
<G-vec00681-002-s189><break_off.(sich)_brechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00681-002-s038><break_off.aufbrechen><en> We needed to break it up, without breaking it.
<G-vec00681-002-s038><break_off.aufbrechen><de> Wir mussten sie aufbrechen, ohne sie zu zerbrechen.
<G-vec00681-002-s039><break_off.aufbrechen><en> Ralf Heinrich, a headmaster, states, “Music can be used to break down an awful lot of barriers and some topics, which are serious, can be given a very different impetus.
<G-vec00681-002-s039><break_off.aufbrechen><de> Ralf Heinrich, Schulleiter, erklärt: „Mit Musik kann man wirklich vieles aufbrechen und auch manche Themen, die ernst sind, kann man mit ganz anderem Schwung versehen.
<G-vec00681-002-s040><break_off.aufbrechen><en> So to make it easier for companies and the humans that work there, some of the standards group have issued further guidelines that break the huge list of controls into more achievable goals.
<G-vec00681-002-s040><break_off.aufbrechen><de> Um es Unternehmen und ihren Mitarbeitern einfacher zu machen, haben einige der Normungsgremien weitere Richtlinien herausgegeben, die die riesige Liste der Kontrollen in erreichbare Ziele aufbrechen.
<G-vec00681-002-s041><break_off.aufbrechen><en> The inviting café with a sun terrace guarantees a successful start to the day, before active holidaymakers break into the numerous adventures of the region.
<G-vec00681-002-s041><break_off.aufbrechen><de> Das einladende Café mit Sonnenterrasse garantiert einen gelungenen Start in den Tag, bevor aktive Urlauber in die zahlreichen Abenteuer der Region aufbrechen.
<G-vec00681-002-s042><break_off.aufbrechen><en> So it happens that people break up.
<G-vec00681-002-s042><break_off.aufbrechen><de> So kommt es, dass Menschen Aufbrechen.
<G-vec00681-002-s043><break_off.aufbrechen><en> The new online postal codes are valid as pioneers for the “Internet of things” and are to break open the shortage of IP addresses for the connection of PCs and cell phones to the data net.
<G-vec00681-002-s043><break_off.aufbrechen><de> Die neuen Online-Postleitzahlen gelten als Wegbereiter für das „Internet der Dinge“ und sollen die Knappheit an IP-Adressen für den Anschluss von PCs und Handys an das Datennetz aufbrechen.
<G-vec00681-002-s044><break_off.aufbrechen><en> To break open the binding of the wheel of rebirth depends mainly on our being earnest and intent: That's what will clear our way. This is why living beings don't want to touch that binding, don't want to break it open.
<G-vec00681-002-s044><break_off.aufbrechen><de> Die Bindung an das Rad der Wiedergeburt aufzubrechen hängt hauptsächlich von unserer Ernsthaftigkeit und Entschlossenheit ab: Das ist es nämlich, was uns den Weg frei macht und warum auch die Lebewesen diese Bindung nicht anrühren und nicht aufbrechen wollen.
<G-vec00681-002-s045><break_off.aufbrechen><en> To help get the formatting correct, TortoiseSVN presents edit dialogs for some particular properties which show the possible values or break the property into its individual components.
<G-vec00681-002-s045><break_off.aufbrechen><de> Um Ihnen die Formatierung zu vereinfachen, stellt TortoiseSVN Dialoge für einige Eigenschaften zur Verfügung, die die Auswahlmöglichkeiten anzeigen oder die Eigenschaft in ihre individuellen Komponenten aufbrechen.
<G-vec00681-002-s046><break_off.aufbrechen><en> They yelled that they would break in if we refused to open the door.
<G-vec00681-002-s046><break_off.aufbrechen><de> Sie schrien, dass sie die Tür aufbrechen würden, wenn wir nicht öffneten.
<G-vec00681-002-s047><break_off.aufbrechen><en> The intention behind it was always to break up the familiar and stimulate the positive charge of (public) space and a lasting memory for the community.
<G-vec00681-002-s047><break_off.aufbrechen><de> Die Intention dahinter blieb immer das Aufbrechen von Bekanntem, die positive Aufladung des (öffentlichen) Raums sowie eine bleibende Erinnerung an das gemeinschaftliche Zusammenarbeiten zu erschaffen.
<G-vec00681-002-s048><break_off.aufbrechen><en> On the basis of the spectra, which correspond to the individual images of a film, it can thus be revealed – essentially in slow motion – how the iron complex deforms under pulsed laser illumination over several stages, the bonds break up and finally the radical is formed.
<G-vec00681-002-s048><break_off.aufbrechen><de> Anhand der Spektren – die den Einzelbildern eines Films entsprechen – lässt sich deshalb gleichsam in Zeitlupe nachweisen, wie sich der Eisenkomplex unter Laserbeschuss über mehrere Stufen verformt, die Bindungen aufbrechen und schließlich das Radikal entsteht.
<G-vec00681-002-s049><break_off.aufbrechen><en> Even if you are in a state of denial, you can see that there are issues and at least some part of you is gearing up for the break up.
<G-vec00681-002-s049><break_off.aufbrechen><de> Auch wenn Sie in einem Zustand der Verleugnung sind, können Sie sehen, dass es Fragen gibt, und zumindest einige Teil von euch rüstet sich für das Aufbrechen.
<G-vec00681-002-s050><break_off.aufbrechen><en> You also want to break up the old potting soil before using it, as it can get dry and compacted over time.
<G-vec00681-002-s050><break_off.aufbrechen><de> Sie möchten auch die alte Blumenerde aufbrechen, bevor Sie sie verwenden, da sie mit der Zeit trocken und verdichtet werden kann.
<G-vec00681-002-s051><break_off.aufbrechen><en> “Sam, is there a way to break the bond?”
<G-vec00681-002-s051><break_off.aufbrechen><de> „Sam, kann man die Bindung aufbrechen?“ fragte ich.
<G-vec00681-002-s052><break_off.aufbrechen><en> On the same day Cut the eggs lightly in the middle with a serrated knife and break them into two halves.
<G-vec00681-002-s052><break_off.aufbrechen><de> Am Tag: Die Eier mit einem Sägemesser leicht mittig anschneiden und in zwei Hälften aufbrechen.
<G-vec00681-002-s053><break_off.aufbrechen><en> When there is enough humidity in the air, wind can break the balls of water particles and thus create ions.
<G-vec00681-002-s053><break_off.aufbrechen><de> Wenn es genug Luftfeuchtigkeit gibt, kann Wind die Ballungen von Wasser-Partikel aufbrechen und so Ionen erzeugen.
<G-vec00681-002-s054><break_off.aufbrechen><en> Much of the paint is applied using stencils that break up the images into layers.
<G-vec00681-002-s054><break_off.aufbrechen><de> Ein großer Teil des Bildes wird mit Hilfe von Schablonen angelegt, die das Bild in Schichten aufbrechen.
<G-vec00681-002-s055><break_off.aufbrechen><en> Cellulose enzymes first have to break down the material and process it.
<G-vec00681-002-s055><break_off.aufbrechen><de> Zellulasen müssen das Material erst „aufbrechen“ und aufbereiten.
<G-vec00681-002-s056><break_off.aufbrechen><en> THE WIND CAN GET WILD IN CAPE TOWN AND WILL BREAK THE DOOR OPEN WHEN THAT HAPPENS.
<G-vec00681-002-s056><break_off.aufbrechen><de> Der Wind kann WILD IN KAPSTADT auftanken und die Tür aufbrechen, wenn das passiert.
<G-vec00681-002-s076><break_off.aufbrechen><en> They pressed hard on the man Lot, and drew near to break the door.
<G-vec00681-002-s076><break_off.aufbrechen><de> Sie setzten dem Mann, nämlich Lot, arg zu und waren schon dabei, die Tür aufzubrechen.
<G-vec00681-002-s077><break_off.aufbrechen><en> It is extremely hard to break these habitual roles, and it requires courage and a conscious knowledge of who you are, why you are here and what you have to offer to humanity as a whole.
<G-vec00681-002-s077><break_off.aufbrechen><de> Es ist äußerst hart, diese gewohnheitsmäßigen Rollen aufzubrechen und es erfordert Mut und bewusstes Wissen darüber, wer ihr seid, warum ihr hier seid und was ihr in die Menschheit als Ganzes einbringen müsst.
<G-vec00681-002-s078><break_off.aufbrechen><en> Lemon is found to be very effective as it helps to break up the mucus causing phlegm in your throat.
<G-vec00681-002-s078><break_off.aufbrechen><de> Zitrone hat sich als sehr effektiv erwiesen, da sie dazu beiträgt, den Schleim aufzubrechen, der Schleim im Hals verursacht.
<G-vec00681-002-s079><break_off.aufbrechen><en> Melt enthalpies are a simple example of endothermic processes, since one usually has to give heat work in a system in order to break up its solid crystal structure and convert it into a liquid phase with molecules that move freely relative to one another.
<G-vec00681-002-s079><break_off.aufbrechen><de> Schmelzenthalpien sind dabei ein einfaches Beispiel für endotherme Vorgänge, da man meistens Wärmearbeit in ein System geben muss, um dessen feste Kristallstruktur aufzubrechen und es in eine flüssige Phase mit frei gegeneinander beweglichen Molekülen zu überführen.
<G-vec00681-002-s080><break_off.aufbrechen><en> Undoubtedly, it often happened like this, or similarly, in many parts of the world, because when we look at her work books, we sense her joy in visual ideas and her desire to break off to new horizons within the artistic arrangement.
<G-vec00681-002-s080><break_off.aufbrechen><de> So oder ähnlich wird es wohl oft gewesen sein, an vielen Orten dieser Welt, denn schaut man sich ihre Arbeitsbücher an, dann spürt man im künstlerischen Arrangement ihre Freude an visuellen Ideen und ihre Lust, zu neuen Horizonten aufzubrechen.
<G-vec00681-002-s081><break_off.aufbrechen><en> Find a way to break the seal, enter the cave, and learn what happened all those years ago.
<G-vec00681-002-s081><break_off.aufbrechen><de> Findet einen Weg, das Siegel aufzubrechen, betretet die Höhle und findet heraus, was vor all den Jahren geschah.
<G-vec00681-002-s083><break_off.aufbrechen><en> Since students are storing higher valued/desired items in their lockers such as cell phones, music devices, tablets, computers & more, thieves have more of a reason to try to shim a lock to break in.
<G-vec00681-002-s083><break_off.aufbrechen><de> Da Schüler ihre wertvolleren/geliebten Dinge in ihren Schließfächern unterbringen - wie Handys, Musikgeräte, Tablets, Computer und mehr - haben Diebe noch mehr Gründe, zu versuchen, ein Schloss aufzuhebeln um es aufzubrechen.
<G-vec00681-002-s084><break_off.aufbrechen><en> The only thing art actually does is break the patterns and habits of perception.
<G-vec00681-002-s084><break_off.aufbrechen><de> Das einzige, was Kunst macht, ist doch, Wahrnehmungsmuster und -gewohnheiten aufzubrechen.
<G-vec00681-002-s086><break_off.aufbrechen><en> Indeed, one of the objectives of Julien\’s oeuvre is to break down the barriers which exist between different artistic disciplines by uniting them in an exponential dialogue.
<G-vec00681-002-s086><break_off.aufbrechen><de> So zielt Julien in seiner Arbeit unter anderem tatsächlich darauf ab, Grenzen zwischen künstlerischen Disziplinen aufzubrechen, indem er sie in einem exponentiellen Dialog vereint.
<G-vec00681-002-s087><break_off.aufbrechen><en> After three years, the attempt to break Google's browser dominance seems to have failed.
<G-vec00681-002-s087><break_off.aufbrechen><de> Nach drei Jahren scheint der Versuch Googles Browser-Dominanz aufzubrechen als gescheitert zu gelten.
<G-vec00681-002-s088><break_off.aufbrechen><en> Use design elements like icons, imagery, collaging, or even just color-coded text to break up your info and make it fun to read.
<G-vec00681-002-s088><break_off.aufbrechen><de> Verwenden Sie Designelemente wie Symbole, Bilder, Collagen oder sogar einfach nur farbcodierten Text, um Ihre Informationen aufzubrechen und sie so unterhaltsam zu gestalten.
<G-vec00681-002-s089><break_off.aufbrechen><en> The Schirn program focuses on themes, discourses and trends of relevance to art and cultural history from a contemporary perspective. Its goal is to introduce new points of view and break away from traditional modes of reception.
<G-vec00681-002-s089><break_off.aufbrechen><de> Das Programm der Schirn richtet seinen Fokus auf kunst- und kulturhistorische Themen, Diskurse und Trends aus der Perspektive der unmittelbaren Gegenwart, mit dem Ziel, neue Sichtweisen zu eröffnen und tradierte Rezeptionsmuster aufzubrechen.
<G-vec00681-002-s090><break_off.aufbrechen><en> At a certain point, most ambitious language learners will start reading books, watching movies or listening to the radio to “break out” of the constraints of the classic classroom.
<G-vec00681-002-s090><break_off.aufbrechen><de> Ab einem gewissen Zeitpunkt fangen die meisten Sprachlernenden an, Bücher zu lesen, Filme zu schauen oder dem Radio zuzuhören, um die Grenzen des klassischen Klassenzimmers aufzubrechen.
<G-vec00681-002-s091><break_off.aufbrechen><en> He often invites the viewer to become the players in his artistic cosmos to break viewing habits and to acquire the new reality.
<G-vec00681-002-s091><break_off.aufbrechen><de> Oftmals lädt Izumi die Betrachter dazu ein, zu Mitspielern in seinem künstlerischen Kosmos zu werden, Sehgewohnheiten aufzubrechen und sich die Wirklichkeit neu anzueignen.
<G-vec00681-002-s092><break_off.aufbrechen><en> The working class family is the more difficult point to break because it is the support of the worker, but as worker, and for that reason the support of capital.
<G-vec00681-002-s092><break_off.aufbrechen><de> Die Arbeiterfamilie ist am schwierigsten aufzubrechen, da sie die Stütze des Arbeiters als Arbeiter und deshalb die Stütze des Kapitals ist.
<G-vec00681-002-s093><break_off.aufbrechen><en> Be careful, players will sometimes stay pat with the intention of getting you to break a made hand.
<G-vec00681-002-s093><break_off.aufbrechen><de> Seien Sie jedoch vorsichtig: Einige Spieler werden manchmal absichtlich keine Karte ziehen, um Sie dazu zu bringen, eine fertige Hand aufzubrechen.
<G-vec00681-002-s094><break_off.aufbrechen><en> In different ways he develops works in public space which try to catch the attention of the spectator and to break the monotony of the streets and the routine of city life.
<G-vec00681-002-s094><break_off.aufbrechen><de> In den vielfältigen und unterschiedlichen Arbeiten, die er realisiert hat, versucht er, die Aufmerksamkeit der Betrachter zu gewinnen, um unsere eingespielte Wahrnehmung von Stadt und urbanem Raum aufzubrechen.
<G-vec00681-002-s095><break_off.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00681-002-s095><break_off.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00681-002-s096><break_off.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00681-002-s096><break_off.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00681-002-s097><break_off.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00681-002-s097><break_off.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00681-002-s098><break_off.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00681-002-s098><break_off.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00681-002-s099><break_off.ausbrechen><en> He could not break free
<G-vec00681-002-s099><break_off.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00681-002-s100><break_off.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00681-002-s100><break_off.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00681-002-s101><break_off.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00681-002-s101><break_off.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00681-002-s102><break_off.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00681-002-s102><break_off.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00681-002-s103><break_off.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00681-002-s103><break_off.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00681-002-s104><break_off.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00681-002-s104><break_off.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00681-002-s105><break_off.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00681-002-s105><break_off.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00681-002-s106><break_off.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00681-002-s106><break_off.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00681-002-s107><break_off.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00681-002-s107><break_off.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00681-002-s108><break_off.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00681-002-s108><break_off.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00681-002-s109><break_off.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00681-002-s109><break_off.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00681-002-s110><break_off.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00681-002-s110><break_off.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00681-002-s111><break_off.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00681-002-s111><break_off.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00681-002-s112><break_off.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00681-002-s112><break_off.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00681-002-s113><break_off.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00681-002-s113><break_off.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00681-002-s152><break_off.brechen><en> They remain in the jaw covered by bone (referred to as impaction) or break through only partially (partial impaction).
<G-vec00681-002-s152><break_off.brechen><de> Sie verbleiben entweder vom Knochen bedeckt im Kiefer (Retention) oder brechen teilweise durch (Teilretention).
<G-vec00681-002-s153><break_off.brechen><en> Those who are not ready or who resist, are put through the painful process of breaking, for „bend or break” is the keynote of the Aquarian energy.
<G-vec00681-002-s153><break_off.brechen><de> Wer nicht dazu geneigt ist oder gar widersteht, macht den schmerzhaften Prozess durch, gebrochen zu werden, denn „biegen oder brechen“ ist die Schlüsselnote der Wassermann-Energie.
<G-vec00681-002-s154><break_off.brechen><en> You cared about us, trust us, and we will not break our promise.
<G-vec00681-002-s154><break_off.brechen><de> Sie sorgen sich um uns, vertrauen uns und so werden wir unser Versprechen nicht brechen.
<G-vec00681-002-s155><break_off.brechen><en> When you damage a carbon fiber part, it could break or it could conceal damage from the naked eye.
<G-vec00681-002-s155><break_off.brechen><de> Wenn du ein Carbonfaser-Teil beschädigst, könnte es brechen oder die Beschädigung nicht auf den ersten Blick zu erkennen sein.
<G-vec00681-002-s156><break_off.brechen><en> Behold, thou shalt sleep with thy fathers; and this people will rise up, and go a whoring after the gods of the strangers of the land, whither they go to be among them, and will forsake me, and break my covenant which I have made with them.
<G-vec00681-002-s156><break_off.brechen><de> 31,16 Und der HERR sprach zu Mose: Siehe, du wirst schlafen bei deinen Vätern, und dies Volk wird sich erheben und nachlaufen den fremden Göttern des Landes, in das sie kommen, und wird mich verlassen und den Bund brechen, den ich mit ihm geschlossen habe.
<G-vec00681-002-s157><break_off.brechen><en> It’s well known that there are a series of potential limitations of CRISPR that can cause what we call “off-target effects”—where basically in addition to breaking what you want to break, it can break something else in your genome.
<G-vec00681-002-s157><break_off.brechen><de> Es ist bekannt, dass es eine Reihe von möglichen Einschränkungen von CRISPR gibt, die das verursachen können, was wir "Off-Target-Effekte" nennen - wo es im Grunde genommen nicht nur das, was man brechen will, sondern auch etwas anderes in seinem Genom brechen kann.
<G-vec00681-002-s159><break_off.brechen><en> The attempt is not to break Burt’s record, but to appreciate his legacy.
<G-vec00681-002-s159><break_off.brechen><de> Der Versuch geht nicht darum, Burts Rekord zu brechen, sondern darum sein Erbe zu würdigen.
<G-vec00681-002-s160><break_off.brechen><en> The impact hammers conduct energy into the component and break up the core.
<G-vec00681-002-s160><break_off.brechen><de> Die Schlaghämmer leiten die Energie in das Bauteil und brechen den Kern.
<G-vec00681-002-s161><break_off.brechen><en> Attach a glass needle onto the microinjector and use your forceps to break the tip of the needle to the desired width.
<G-vec00681-002-s161><break_off.brechen><de> Bringen Sie ein Glas Nadel auf die Mikroinjektor und nutzen Sie Ihre Zange an der Spitze der Nadel auf die gewünschte Breite zu brechen.
<G-vec00681-002-s162><break_off.brechen><en> It signals that the installation of a package will “break” another package (or particular versions of it).
<G-vec00681-002-s162><break_off.brechen><de> Sie deutet darauf hin, dass die Installation eines Paketes ein anderes Paket (oder bestimmte Versionen davon) „brechen“ wird.
<G-vec00681-002-s163><break_off.brechen><en> Do not crush, chew, or break the tablet.
<G-vec00681-002-s163><break_off.brechen><de> Zerquetschen Sie es, kauen Sie es, oder brechen Sie die Pillen nicht.
<G-vec00681-002-s164><break_off.brechen><en> Hamas spokesman Hazem Qassem said that with the approach of the first anniversary of the “return marches,” the Palestinian people were planning to break [into Israeli territory] with the “million-man march” on Land Day to stress the main objectives of the marches.
<G-vec00681-002-s164><break_off.brechen><de> Hazem Kassem, ein Sprecher im Namen der Hamas, sagte, dass das palästinensische Volk vor dem ersten Jahrestag der “Prozessionen” vorhatte, anlässlich des “Tag der Erde” mit der “Prozession der Millionen” an Land zu brechen, um die Hauptziele der “Prozessionen der großen Rückkehr” zu erfüllen.
<G-vec00681-002-s165><break_off.brechen><en> At the same time, the hammer energy introduced into the component is used to break up the core sand in the component, so this can subsequently be shaken out.
<G-vec00681-002-s165><break_off.brechen><de> Zeitgleich wird die in das Bauteil eingebrachte Hammerenergie dazu verwendet, den Kernsand im Bauteil zu brechen, um diesen anschließend herausrütteln zu können.
<G-vec00681-002-s166><break_off.brechen><en> It is organized in more or less radical Marxist movements, determined to break all spiritual resistance by the power of violence.
<G-vec00681-002-s166><break_off.brechen><de> Sie ist in mehr oder minder radikalmarxistischen Bewegungen zusammengefaßt, entschlossen, jeden geistigen Widerstand durch die Macht der Gewalt zu brechen.
<G-vec00681-002-s167><break_off.brechen><en> Wotan tells him that he comes only to watch, since he cannot, as Alberich reminds him, break his agreement with Fafner, who had been given the ring and other treasure in return for the release of the goddess Freia.
<G-vec00681-002-s167><break_off.brechen><de> Nur zu schauen sei er gekommen, antwortet Wotan, nicht zu schaffen – und Alberich erinnert seinerseits daran, daß er den Vertrag mit Fafner nicht brechen dürfe, der ja den Ring und den gesamten Schatz als Bezahlung für die Errichtung Walhalls und die Freilassung der Göttin Freia erhalten habe.
<G-vec00681-002-s168><break_off.brechen><en> We hope to avoid a new break of the wireline by running it a little bit slower.
<G-vec00681-002-s168><break_off.brechen><de> Wir hoffen ein neues Brechen des Bohrkabels durch langsameres Bohren verhindern zu können.
<G-vec00681-002-s169><break_off.brechen><en> He would do anything, anything, to break what he calls the superstition of the Cross.
<G-vec00681-002-s169><break_off.brechen><de> Er würde alles tun, alles, um das zu brechen, was er den Aberglauben des Kreuzes nennt.
<G-vec00681-002-s170><break_off.brechen><en> Do not crush, chew, break, or open an extended-release capsule.
<G-vec00681-002-s170><break_off.brechen><de> Zerquetschen Sie nicht, kauen Sie, brechen Sie, oder öffnen Sie eine Kapsel der verlängerten Ausgabe.
<G-vec00681-002-s171><break_off.brechen><en> HSL break the body fat shops within your cells.
<G-vec00681-002-s171><break_off.brechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00681-002-s172><break_off.brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00681-002-s172><break_off.brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00681-002-s173><break_off.brechen><en> Q Right – but you don’t break his nose.
<G-vec00681-002-s173><break_off.brechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00681-002-s174><break_off.brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00681-002-s174><break_off.brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00681-002-s175><break_off.brechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00681-002-s175><break_off.brechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00681-002-s176><break_off.brechen><en> The part could break without warning (see figure 80).
<G-vec00681-002-s176><break_off.brechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00681-002-s177><break_off.brechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00681-002-s177><break_off.brechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00681-002-s178><break_off.brechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00681-002-s178><break_off.brechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00681-002-s179><break_off.brechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00681-002-s179><break_off.brechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00681-002-s180><break_off.brechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00681-002-s180><break_off.brechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00681-002-s181><break_off.brechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00681-002-s181><break_off.brechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00681-002-s182><break_off.brechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00681-002-s182><break_off.brechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00681-002-s183><break_off.brechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00681-002-s183><break_off.brechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00681-002-s184><break_off.brechen><en> HSL break the fat stores within your cells.
<G-vec00681-002-s184><break_off.brechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00681-002-s185><break_off.brechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00681-002-s185><break_off.brechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00681-002-s186><break_off.brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00681-002-s186><break_off.brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00681-002-s187><break_off.brechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00681-002-s187><break_off.brechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00681-002-s188><break_off.brechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00681-002-s188><break_off.brechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00681-002-s189><break_off.brechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
<G-vec00681-002-s189><break_off.brechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00681-002-s209><break_off.durchbrechen><en> 24 And Jehovah said unto him, Go, get thee down; and thou shalt come up, thou, and Aaron with thee: but let not the priests and the people break through to come up unto Jehovah, lest he break forth upon them.
<G-vec00681-002-s209><break_off.durchbrechen><de> 24Und der HERR sprach zu ihm: Geh hin, steig hinab und komm wieder herauf, du und Aaron mit dir; aber die Priester und das Volk sollen nicht durchbrechen, dass sie hinaufsteigen zu dem HERRN, damit er sie nicht zerschmettere.
<G-vec00681-002-s210><break_off.durchbrechen><en> The steps help break what I might call the "public language barrier" so that the source of one's own thinking is found and spoken from.
<G-vec00681-002-s210><break_off.durchbrechen><de> Die Schritte helfen zu durchbrechen, was ich die "allgemeine öffentliche Sprachbarriere" nennen würde, damit die Quelle des eigenen Denkens gefunden und daraus gesprochen wird.
<G-vec00681-002-s211><break_off.durchbrechen><en> The aim is to develop a platform for internal and external “visionaries”, start-ups and free thinkers, in order to break the daily work routine and come up with fresh new ideas.
<G-vec00681-002-s211><break_off.durchbrechen><de> Das Ziel ist es, eine Plattform für interne und externe „Visionäre“, Startups und Freigeister zu schaffen, um den Arbeitsalltag zu durchbrechen und für frischen Wind zu sorgen.
<G-vec00681-002-s212><break_off.durchbrechen><en> Eye-catching advertisement Place your advertisement conspicuously in the search results list and break the user's searching habits.
<G-vec00681-002-s212><break_off.durchbrechen><de> Platzieren Sie Ihr Inserat auffällig in der Suchergebnisliste und durchbrechen Sie die Nutzergewohnheit der Suchenden.
<G-vec00681-002-s213><break_off.durchbrechen><en> Use madness to break through the enemies.
<G-vec00681-002-s213><break_off.durchbrechen><de> Verwenden Sie Wahnsinn, um die Feinde durchbrechen.
<G-vec00681-002-s214><break_off.durchbrechen><en> Uninvited visitors come up against an almost insuperable resistancethe trying to break through one of our doors.
<G-vec00681-002-s214><break_off.durchbrechen><de> Ungebetene Besucher stoßen schon bei dem Versuch, eine unserer Türen zu durchbrechen auf nahezu unüberwindbaren Widerstand.
<G-vec00681-002-s215><break_off.durchbrechen><en> 19:24 And the LORD said unto him, Away, get you down, and you shall come up, you, and Aaron with you: but let not the priests and the people break through to come up unto the LORD, lest he break forth upon them.
<G-vec00681-002-s215><break_off.durchbrechen><de> 24 Und der HERR sprach zu ihm: Geh hin, steig hinab und komm wieder herauf, du und Aaron mit dir; aber die Priester und das Volk sollen nicht durchbrechen, daß sie hinaufsteigen zu dem HERRN, damit er sie nicht zerschmettere.
<G-vec00681-002-s216><break_off.durchbrechen><en> We envision to break social and physical poverty of any rural Indian by several ways.
<G-vec00681-002-s216><break_off.durchbrechen><de> Wir beabsichtigen, die soziale und physische Armut eines jeden ländlichen Indianers auf verschiedene Weise zu durchbrechen.
<G-vec00681-002-s217><break_off.durchbrechen><en> However, cunning enemies want to break the race placing everywhere numerous obstacles.
<G-vec00681-002-s217><break_off.durchbrechen><de> Schlaue Gegner wollen jedoch das Rennen durchbrechen und stellen überall zahlreiche Hindernisse auf.
<G-vec00681-002-s218><break_off.durchbrechen><en> It is an attempt to break through the borders of the ordinary, known and profane in a search for bliss and freedom, but still knowing this is only a (beautiful) illusion.
<G-vec00681-002-s218><break_off.durchbrechen><de> Es ist ein Versuch die Grenzen des Gewöhnlichen, Bekannten, Profanen zu durchbrechen, auf der Suche nach Glückseligkeit und Freiheit, jedoch mit dem Wissen, dass dies nur eine (schöne) Illusion ist.
<G-vec00681-002-s219><break_off.durchbrechen><en> Actually, nothing would improve. Those people could never break through the stage of illness healing and health maintenance, that is, the level of harnessing qi.
<G-vec00681-002-s219><break_off.durchbrechen><de> In Wirklichkeit kann nichts erhöht werden, er kann nie die Ebene der Krankheitsbeseitigung und Gesundheitserhaltung, also des Übens des Qi durchbrechen.
<G-vec00681-002-s220><break_off.durchbrechen><en> The product and packaging have to break through these routines whilst nevertheless docking on to consumers’ existing expectations and needs.
<G-vec00681-002-s220><break_off.durchbrechen><de> Produkt und Verpackung müssen diese Routinen durchbrechen, gleichzeitig aber dann doch wieder an bestehende Erwartungen und Bedürfnisse der Konsumenten andocken.
<G-vec00681-002-s221><break_off.durchbrechen><en> Micah 2:13: “… 13 The One who breaks open the way will go up before them; they will break through the gate and go out.
<G-vec00681-002-s221><break_off.durchbrechen><de> Micha 2,13: 13 Er wird als ein Durchbrecher vor ihnen heraufziehen; sie werden durchbrechen und durchs Tor hinausziehen, und ihr König wird vor ihnen hergehen und der HERR an ihrer Spitze.
<G-vec00681-002-s222><break_off.durchbrechen><en> The cover of the forest was dense, though the sun still tried to break through, speckling the ground in patches.
<G-vec00681-002-s222><break_off.durchbrechen><de> Die Decke des Waldes war dicht, obwohl die Sonne immer noch versuchte zu durchbrechen und den Boden in Flecken zu sprießen.
<G-vec00681-002-s223><break_off.durchbrechen><en> Together with our European partners, we will therefore consider incentives to help encourage Asmara to finally break this logic, which has resulted in major human rights violations.
<G-vec00681-002-s223><break_off.durchbrechen><de> Deshalb werden wir uns gemeinsam mit unseren europäischen Partnern Gedanken über Anreize gegenüber Asmara machen, die helfen sollen, um diese Logik, die in ganz erheblichen Menschenrechtsverletzungen endet, endlich zu durchbrechen.
<G-vec00681-002-s224><break_off.durchbrechen><en> Whether you’re just getting over a breakup or trying to break negative relationship patterns, there may come a time when you simply don’t want to fall in love.
<G-vec00681-002-s224><break_off.durchbrechen><de> Es wird eine Zeit geben, in der du dich einfach nicht verlieben willst, beispielsweise weil du gerade eine Trennung verarbeitest oder negative Beziehungsmuster durchbrechen willst.
<G-vec00681-002-s225><break_off.durchbrechen><en> The traditional doctrine may be more solid and hard to break down than I think.
<G-vec00681-002-s225><break_off.durchbrechen><de> Die traditionelle Lehre scheint doch fester etabliert und schwieriger zu durchbrechen zu sein, als mir lieb ist.
<G-vec00681-002-s226><break_off.durchbrechen><en> Fight against child exploitation – Tdh fights against the sexual exploitation of children by putting into place reception centres, in order to help young girls and boys emancipate themselves and break the chains of exploitation.
<G-vec00681-002-s226><break_off.durchbrechen><de> Kampf gegen die Ausbeutung der Kinder – Tdh bekämpft die sexuelle Ausbeutung von Kindern, indem sich die Organisation gegen die Empfangszentren auflehnt und Mädchen und Jungen dabei hilft, die Emanzipation zu erreichen um somit die Ausbeutungskette zu durchbrechen.
<G-vec00681-002-s227><break_off.durchbrechen><en> We cordially invite you to break the taboos of the „foul" language and to rethink the meaning of the offensive words that became a part of our everydayness.
<G-vec00681-002-s227><break_off.durchbrechen><de> Wir laden Sie herzlich ein, die Tabus der "schmutzigen" Sprache zu durchbrechen und ihre Bedeutung in unserem alltäglichen Sprachgebrauch neu zu überdenken.
<G-vec00681-002-s304><break_off.lösen><en> At the University of St. Gallen, we have always taught students to break away from a pure model perspective, to factor in the underlying assumptions and to even question those assumptions.
<G-vec00681-002-s304><break_off.lösen><de> An der Universität St. Gallen bringen wir den Studenten seit jeher bei, sich von der reinen Modelloptik zu lösen, die zugrundeliegenden Annahmen einzubeziehen – und auch zu hinterfragen.
<G-vec00681-002-s305><break_off.lösen><en> We systematically enable you to break free of conventional patterns of thinking and expand your perspective on your business
<G-vec00681-002-s305><break_off.lösen><de> Wir ermöglichen Ihnen auf systematische Weise, sich von konventionellen Denkmustern zu lösen und eine völlig neue Perspektive auf Ihr Geschäft einzunehmen.
<G-vec00681-002-s306><break_off.lösen><en> (4) The provider reserves the right to break away from the obligation to fulfill the contract, if the goods are to be delivered by his supplier to the date of delivery and the delivery remains undone entirely or partially.
<G-vec00681-002-s306><break_off.lösen><de> (4) Der Anbieter behält sich vor, sich von der Verpflichtung zur Erfüllung des Vertrages zu lösen, wenn die Ware durch einen Lieferanten zum Tag der Auslieferung anzuliefern ist und die Anlieferung ganz oder teilweise unterbleibt.
<G-vec00681-002-s307><break_off.lösen><en> Press the card in at several points if necessary to break up the adhesive behind the battery.
<G-vec00681-002-s307><break_off.lösen><de> Drücke die Karte weiter rein, um den ganzen Kleber zu lösen.
<G-vec00681-002-s308><break_off.lösen><en> If God holds us, there's no power that can break His hold...none.
<G-vec00681-002-s308><break_off.lösen><de> Wenn Gott uns in seiner Hand hält, gibt es keine Kraft, die diesen Griff lösen kann... keine.
<G-vec00681-002-s309><break_off.lösen><en> The oils in peanut butter will break down many adhesives.
<G-vec00681-002-s309><break_off.lösen><de> Die Öle in Erdnussbutter, ob du es glaubst oder nicht, lösen viele Klebstoffe.
<G-vec00681-002-s310><break_off.lösen><en> In addition, deformation of the sleeve during the closing process causes any incrustations inside the sleeve to break away.
<G-vec00681-002-s310><break_off.lösen><de> Zudem lösen sich Verkrustungen am Inneren der Manschette während des Schließvorgangs durch die Verformung.
<G-vec00681-002-s311><break_off.lösen><en> It comes from knowing that you have achieved your goals, and have been able to break your bonds with the earthly links that no longer serve you.
<G-vec00681-002-s311><break_off.lösen><de> Das kommt so – aus dem Wissen heraus, dass ihr eure Ziele erreicht habt und fähig gewesen seid, eure Bindung an irdische Verknüpfungen zu lösen, die euch nicht länger dienlich sind.
<G-vec00681-002-s312><break_off.lösen><en> The light is the go-ahead for the process: The electrons are stimulated, break away from their atoms and become free movable.
<G-vec00681-002-s312><break_off.lösen><de> Das Licht ist der Startschuss für den Prozess: Die Elektronen werden angeregt, lösen sich von ihren Atomen und werden frei beweglich.
<G-vec00681-002-s313><break_off.lösen><en> Seek to break away from it; make yourselves free of that, what is your ruin; you have overcome hard matter already a long time ago – do not let yourselves be anew captured by it, but seek to become free of all form.
<G-vec00681-002-s313><break_off.lösen><de> Suchet euch zu lösen von ihr, machet euch frei von dem, was euer Verderben ist, Ihr habt die harte Materie schon vor langer Zeit überwunden - lasset euch nicht von ihr aufs neue gefangennehmen, sondern suchet frei zu werden von jeglicher Form.
<G-vec00681-002-s314><break_off.lösen><en> - Urging them to dismantle paramilitary groups and break their links with the security forces in line with repeated United Nations human rights recommendations.
<G-vec00681-002-s314><break_off.lösen><de> - Bitte lösen Sie paramilitärische Gruppen auf und lösen Sie deren Verbindungen zu den Sicherheitskräften, wie es die Vereinten Nationen in ihren Empfehlungen zum Schutz der Menschenrechte mehrfach ausgesprochen haben.
<G-vec00681-002-s315><break_off.lösen><en> Similarly, pieces of the plaque can break off and travel through the bloodstream and block an artery elsewhere.
<G-vec00681-002-s315><break_off.lösen><de> In ähnlicher Weise können sich Plaquefragmente lösen und auf ihrem Weg durch den Blutstrom eine Arterie an einer anderen Stelle blockieren.
<G-vec00681-002-s316><break_off.lösen><en> As of Gods and Monsters, Caroline and Alaric break off their engagement being Caroline still wants to be with Stefan.
<G-vec00681-002-s316><break_off.lösen><de> In Götter und Monster lösen Caroline und Alaric ihre Verlobung auf, weil Caroline immer noch Gefühle für Stefan hat.
<G-vec00681-002-s317><break_off.lösen><en> They were so caught up in the lust of the moment, to break from it is painfully annoying.
<G-vec00681-002-s317><break_off.lösen><de> Sie waren so in der Lust des Augenblicks gefangen, sich davon zu lösen war schmerzlich und lästig.
<G-vec00681-002-s318><break_off.lösen><en> Break away from static patterns and rigid layout thinking.
<G-vec00681-002-s318><break_off.lösen><de> Lösen Sie sich von statischen Mustern und starrem Layout-Denken.
<G-vec00681-002-s319><break_off.lösen><en> Only then man fashions himself so that he is suitable to work for me and my kingdom that he therefore can accomplish real vineyard work, without respect for persons and for class to put the same aim before the eyes of fellowmen and to bring them so far through enlightenment about me myself that they carry out at themselves the same – to again break away from the earthly world and to take up the fight against matter.
<G-vec00681-002-s319><break_off.lösen><de> Dann erst gestaltet sich der Mensch selbst so, daß er tauglich ist, für Mich und Mein Reich zu arbeiten, daß er also rechte Weinbergsarbeit verrichten kann, ohne Ansehen der Person und des Standes den Mitmenschen das gleiche Ziel vor Augen zu stellen und sie durch Aufklärungen über Mich Selbst so weit zu bringen, daß sie an sich selbst das gleiche vollziehen - wieder sich zu lösen von der irdischen Welt und den Kampf gegen die Materie aufzunehmen.
<G-vec00681-002-s320><break_off.lösen><en> The Scorpions break up shortly, but founder and guitarist Rudolf Schenker has already found a good sideline.
<G-vec00681-002-s320><break_off.lösen><de> Die Scorpions lösen sich demnächst auf, doch Band-Gründer Rudolf Schenker hat schon eine gute Nebenbeschäftigung gefunden.
<G-vec00681-002-s321><break_off.lösen><en> Once you've listened to AVEC's sounds, it's hard to break away from them.
<G-vec00681-002-s321><break_off.lösen><de> Hat man AVECs Klängen einmal gelauscht, kann man sich nur mehr schwer davon lösen.
<G-vec00681-002-s322><break_off.lösen><en> CAUSE During normal braking small particles of the rotor surface break off.
<G-vec00681-002-s322><break_off.lösen><de> URSACHE Beim normalen Bremsvorgang lösen sich Metallpartikel von der Bremsscheibe.
<G-vec00681-002-s570><break_off.zerbrechen><en> Let them understand how much it will cost them if they want to break us.
<G-vec00681-002-s570><break_off.zerbrechen><de> Sollen sie begreifen, wieviel es sie kostet, wenn sie uns zerbrechen wollen.
<G-vec00681-002-s571><break_off.zerbrechen><en> It's good to develop a sense of dispassion and disenchantment for the body, to develop a sense of samvega, so that when it breaks down we don't break down, too.
<G-vec00681-002-s571><break_off.zerbrechen><de> Es ist gut, einen gewissen Gleichmut, eine gewisse Ernüchterung gegenüber dem Körper zu entwickeln, ein Gefühl von Samvega zu entwickeln, so dass wir, wenn er zerbricht, nicht auch zerbrechen.
<G-vec00681-002-s572><break_off.zerbrechen><en> And it shall come to pass at that day, that I will break the bow of Israel, in the valley of Jezreel.
<G-vec00681-002-s572><break_off.zerbrechen><de> Und es wird geschehen an jenem Tage, da werde ich den Bogen Israels zerbrechen im Tale Jisreel.
<G-vec00681-002-s573><break_off.zerbrechen><en> And it shall come to pass at that day, that I will break the bow of Israel, in the valley of Jezreel.”
<G-vec00681-002-s573><break_off.zerbrechen><de> 5 Zur selben Zeit will ich den Bogen Israels zerbrechen im Tal Jesreel.
<G-vec00681-002-s574><break_off.zerbrechen><en> If the artificial eye should break, please keep as many fragments as possible as a template for a new production.
<G-vec00681-002-s574><break_off.zerbrechen><de> Sollte das künstliche Auge einmal zerbrechen, dann heben Sie bitte möglichst alle Bruchstücke als Vorlage für eine Neuanfertigung auf.
<G-vec00681-002-s575><break_off.zerbrechen><en> Titanium heaters are virtually unbreakable, they will not shatter if they are knocked while the element is hot, but if they are dropped from a height then they can break up.
<G-vec00681-002-s575><break_off.zerbrechen><de> Titanheizer sind praktisch unverwüstlich, sie zerbrechen nicht wenn sie einen Schlag erhalten während das Heizelement noch heiß ist, allerdings bedeutet das nicht, dass sie nicht zerbrechen können, wenn sie aus einer größeren Höhe fallen gelassen werden.
<G-vec00681-002-s576><break_off.zerbrechen><en> 6 You shall break it in pieces and pour oil on it; it is a grain offering.
<G-vec00681-002-s576><break_off.zerbrechen><de> 6 du sollst es in Stücke zerbrechen und Öl darauf gießen: es ist ein Speisopfer.
<G-vec00681-002-s577><break_off.zerbrechen><en> The change from crystalline to amorphous, referred to as reset herein, is generally a higher current operation, which includes a short high current density pulse to melt or break down the crystalline structure, after which the phase change material cools quickly, quenching the phase change process and allowing at least a portion of the phase change structure to stabilize in the amorphous state.
<G-vec00681-002-s577><break_off.zerbrechen><de> Die Änderung von kristallin zu amorph, die hierin als Zurücksetzung bezeichnet wird, findet im Allgemeinen bei starkem Strom statt und schließt einen kurzen Impuls hoher Stromdichte ein, um die Kristallstruktur zu zerschmelzen oder zu zerbrechen, wonach das Phasenänderungsmaterial schnell abkühlt, wobei der Phasenänderungsprozess gequencht wird, was ermöglicht, dass zumindest ein Teil der Phasenänderungsstruktur sich im amorphen Zustand stabilisiert.
<G-vec00681-002-s578><break_off.zerbrechen><en> Lots of relationships break down because of the stress of the social background.
<G-vec00681-002-s578><break_off.zerbrechen><de> Viele Beziehungen würden zerbrechen durch den Stress des Milieus.
<G-vec00681-002-s579><break_off.zerbrechen><en> 10 "Then you are to break the jar in the sight of the men who accompany you 11 and say to them, 'Thus says the LORD of hosts, "Just so will I break this people and this city, even as one breaks a potter's vessel, which cannot again be repaired; and they will bury in Topheth because there is no other place for burial.
<G-vec00681-002-s579><break_off.zerbrechen><de> 10 Und du sollst den Krug vor den Augen der Männer zerbrechen, die mit dir gegangen sind, 11 und zu ihnen sagen: So spricht der HERR der Heerscharen: Ebenso werde ich dieses Volk und diese Stadt zerbrechen, wie man ein Gefäß des Töpfers zerbricht, das nicht wiederhergestellt werden kann.
<G-vec00681-002-s581><break_off.zerbrechen><en> 20 A bruised reed shall he not break, and smoking flax shall he not quench, till he send forth judgment unto victory.
<G-vec00681-002-s581><break_off.zerbrechen><de> Matthaeus 12.20 20 A geknickte Rohr wird er nicht zerbrechen, und den glimmenden Docht wird er nicht auslöschen, bis er Sendest Urteil zum Sieg.
<G-vec00681-002-s582><break_off.zerbrechen><en> Luminaires in sports halls needs to be impact resistant so they do not break when balls hit them.
<G-vec00681-002-s582><break_off.zerbrechen><de> Die Leuchten in Sporthallen müssen schlagfest sein, damit sie nicht zerbrechen, wenn sie von Bällen getroffen werden.
<G-vec00681-002-s583><break_off.zerbrechen><en> *) In gas-fracking, chemicals and water are pressed with high pressure into deeply-lying strata of rock containing gases, in order to break them up and extract the gas contained.
<G-vec00681-002-s583><break_off.zerbrechen><de> *) Beim Gas-Fracking werden Chemie und Wasser unter hohem Druck in zum Teil tief liegende gashaltige Gesteinsschichten, gepresst, um sie zu zerbrechen und das darin enthaltene Gase zu fördern.
<G-vec00681-002-s584><break_off.zerbrechen><en> The beautifully crafted figure is made of artificial stone and should not necessarily fall to the ground, otherwise it can break.
<G-vec00681-002-s584><break_off.zerbrechen><de> Die toll gearbeitete Figur ist aus Kunststein hergestellt und sollte nicht unbedingt auf den Boden fallen, da sie sonst zerbrechen kann.
<G-vec00681-002-s585><break_off.zerbrechen><en> The military vehicles will crack and break up on impact with incoming projectiles.
<G-vec00681-002-s585><break_off.zerbrechen><de> Die Militärfahrzeuge werden beim Aufprall von Geschosse knacken und zerbrechen.
<G-vec00681-002-s586><break_off.zerbrechen><en> Jonah 1:4-5 “Then the LORD sent a great wind on the sea, and such a violent storm arose that the ship threatened to break up.
<G-vec00681-002-s586><break_off.zerbrechen><de> Da ließ der HERR einen großen Wind aufs Meer kommen, und es erhob sich ein großes Ungewitter auf dem Meer, daß man meinte, das Schiff würde zerbrechen.
<G-vec00681-002-s587><break_off.zerbrechen><en> The current economic upswing could break down due to the high level of debt worldwide.
<G-vec00681-002-s587><break_off.zerbrechen><de> An der weltweit hohen Verschuldung könnte der gegenwärtige Konjunkturaufschwung zerbrechen.
<G-vec00681-002-s588><break_off.zerbrechen><en> In one house shall it be eaten; thou shalt not carry forth any of the flesh abroad out of the house; neither shall ye break a bone thereof.
<G-vec00681-002-s588><break_off.zerbrechen><de> 46 In einem Hause soll man's essen; ihr sollt nichts von seinem Fleisch hinaus vor das Haus tragen und sollt kein Bein an ihm zerbrechen.
