<G-vec00681-002-s031><crack.(sich)_brechen><en> Therefore, the ball-pressing portion is formed with a sharply pointed shape which is liable to intervene rotation of the ball and scratch or crack an external surface of the ball.
<G-vec00681-002-s031><crack.(sich)_brechen><de> Daher wird der Kugelanpressabschnitt mit einer zugespitzten Form ausgebildet, die dazu neigt, zwischen die Drehung der Kugel zu kommen und eine Außenfläche der Kugel zu kratzen oder brechen.
<G-vec00681-002-s032><crack.(sich)_brechen><en> His performances crack open the creative process and with it the urgency of the issues that lie at the core of Mroué’s concern, namely the meaning of the body on stage as a metaphor for the agency of an individual in society, culture, a political system and a state.
<G-vec00681-002-s032><crack.(sich)_brechen><de> Seine Performances brechen den kreativen Prozess auf und machen damit die Themen eindringlich bewusst, die Mroué besonders am Herzen liegen, speziell die Bedeutung des Körpers auf der Bühne als einer Metapher für das Agieren eines Individuums in der Gesellschaft, der Kultur, einem politischen System und einem Staat.
<G-vec00681-002-s033><crack.(sich)_brechen><en> Importantly, this is the first time that researchers have observed solidification cracking in steel and sheds new light on why the alloy may crack during the process.
<G-vec00681-002-s033><crack.(sich)_brechen><de> Wesentlich ist dabei, dass die Bildung von Erstarrungsrissen in Stahl hier erstmals von Forschern beobachtet wurde, die so feststellen konnten, warum die Legierung bei diesem Vorgang brechen kann.
<G-vec00681-002-s034><crack.(sich)_brechen><en> Unlike real wood and stone, it won't splinter, warp or crack.
<G-vec00681-002-s034><crack.(sich)_brechen><de> Im Gegensatz zu echtem Holz oder Stein, splittern, verziehen oder brechen unsere Böden nicht.
<G-vec00681-002-s035><crack.(sich)_brechen><en> The ink remains flexible after printing so that it does not crack when the printed material bends or stretches.
<G-vec00681-002-s035><crack.(sich)_brechen><de> Die Tinte bleibt flexibel und kann folglich nicht brechen, wenn das Material gebogen oder gedehnt wird.
<G-vec00681-002-s036><crack.(sich)_brechen><en> Under the press washer, it is necessary to drill a hole so that the sheets do not crack.
<G-vec00681-002-s036><crack.(sich)_brechen><de> Unter dem Presswäscher muss ein Loch gebohrt werden, damit die Bleche nicht brechen.
<G-vec00681-002-s037><crack.(sich)_brechen><en> Based on a performed analysis, our engineers predict the kind of environment where the phone will withstand a drop without damage or where the glass might rather crack.
<G-vec00681-002-s037><crack.(sich)_brechen><de> Auf Grund einer durchgeführten Analyse können unsere Ingenieure die Art der Umgebung, in der das Telefon einen Sturz unbeschadet übersteht oder wo das Glas eher brechen wird, prognostizieren.
<G-vec00681-002-s038><crack.(sich)_brechen><en> My titanium wrench can crack a rusted nut from a bolt as easily as it can crush skulls.
<G-vec00681-002-s038><crack.(sich)_brechen><de> Mein Titan Schraubenschlüssel kann ebenso leicht eine Mutter aus einem Bolzen brechen, als auch Schädel aufbrechen.
<G-vec00681-002-s039><crack.(sich)_brechen><en> In our conversations we tried to crack the code of this enigma.
<G-vec00681-002-s039><crack.(sich)_brechen><de> Bei unseren Konversationen versuchten wir, den Code dieses Rätsels zu brechen.
<G-vec00681-002-s040><crack.(sich)_brechen><en> Like diamonds, topaz is a very hard stone but it is likely to crack from a violent impact.
<G-vec00681-002-s040><crack.(sich)_brechen><de> Ebenso wie der Diamant ist der Topas ein sehr harter Stein, der jedoch bei heftigen Stößen brechen kann.
<G-vec00681-002-s041><crack.(sich)_brechen><en> Made from a soft, flexible rubber compound that will not curl, crack or harden even in sub-zero temperatures.
<G-vec00681-002-s041><crack.(sich)_brechen><de> Die Matten werden aus einer weichen, flexiblen Gummimischung hergestellt, die selbst bei Minusgraden die Form bewahrt und nicht bricht oder hart wird.
<G-vec00681-002-s042><crack.(sich)_brechen><en> It can be rolled well, does not crack when rolled and can be used with rolling machine.
<G-vec00681-002-s042><crack.(sich)_brechen><de> Sie lässt sich auch mit der Maschine leicht ausrollen, und bricht beim Ausrollen nicht.
<G-vec00681-002-s043><crack.(sich)_brechen><en> This makes it an ideal material type for this application as it will not crack or split.
<G-vec00681-002-s043><crack.(sich)_brechen><de> Das macht es zu einem idealen Materialtypen für diesen Anwendungsfall, da es weder bricht noch sich spaltet.
<G-vec00681-002-s044><crack.(sich)_brechen><en> Avoid bringing the blow-dryer too close to the leather as this can cause it to crack or chip.
<G-vec00681-002-s044><crack.(sich)_brechen><de> Bringe den Föhn nicht zu nah an das Leder heran, da das dazu führen könnte, dass das Leder bricht oder abplatzt.
<G-vec00681-002-s022><crack.aufbrechen><en> The reason for these conditions is the male hormone called testosterone secreted by oocytes that are unable to crack in the ovary and accumulate.
<G-vec00681-002-s022><crack.aufbrechen><de> Der Grund für diese Situationen ist das männliche Hormon Testosteron, das freigesetzt wird, während die Eierstöcke, die nicht aufbrechen konnten sich beim Warten ansammeln.
<G-vec00681-002-s023><crack.aufbrechen><en> Also Chlorella's cell wall is indigestible for us and so commercial growers must crack this cell wall using some type of process.
<G-vec00681-002-s023><crack.aufbrechen><de> Außerdem ist die Zellwand der Chlorella für uns unverdaulich, so daß kommerzielle Züchter die Zellwand mit Hilfe eines bestimmten Verfahrens aufbrechen müssen.
<G-vec00681-002-s024><crack.aufbrechen><en> However, you’ll have to adjust it as you work so you can crack it all the way around.
<G-vec00681-002-s024><crack.aufbrechen><de> Du musst ihre Position allerdings beim Arbeiten anpassen, so dass du sie rundherum aufbrechen kannst.
<G-vec00681-002-s025><crack.aufbrechen><en> The baby can then crack—or pip—the end of the egg near its head to wiggle free.
<G-vec00681-002-s025><crack.aufbrechen><de> Anschließend kann das Baby-Chamäleon die Schale über seinem Kopf aufbrechen oder anpicken, um sich zu befreien.
<G-vec00681-002-s026><crack.aufbrechen><en> "[...] victims of Zyklon B gassings aren't greenish (they are pinkish-reddish), and there is no reason for the corpses to crack and for their skin to come off.
<G-vec00681-002-s026><crack.aufbrechen><de> "[...] Opfer von Zyklon B-Vergasungen sind nicht grünlich (sie sind rosa-rötlich), und es gibt keinen Grund, warum die Leichen aufbrechen und sich ihre Haut abpellen sollte.
<G-vec00681-002-s027><crack.aufbrechen><en> In order to extract this natural gas, water pressure has to be used to crack open the rock.
<G-vec00681-002-s027><crack.aufbrechen><de> Um dieses Erdgas zu fördern, muss man das Gestein mit Wasserdruck „aufbrechen“.
<G-vec00681-002-s031><crack.brechen><en> Therefore, the ball-pressing portion is formed with a sharply pointed shape which is liable to intervene rotation of the ball and scratch or crack an external surface of the ball.
<G-vec00681-002-s031><crack.brechen><de> Daher wird der Kugelanpressabschnitt mit einer zugespitzten Form ausgebildet, die dazu neigt, zwischen die Drehung der Kugel zu kommen und eine Außenfläche der Kugel zu kratzen oder brechen.
<G-vec00681-002-s032><crack.brechen><en> His performances crack open the creative process and with it the urgency of the issues that lie at the core of Mroué’s concern, namely the meaning of the body on stage as a metaphor for the agency of an individual in society, culture, a political system and a state.
<G-vec00681-002-s032><crack.brechen><de> Seine Performances brechen den kreativen Prozess auf und machen damit die Themen eindringlich bewusst, die Mroué besonders am Herzen liegen, speziell die Bedeutung des Körpers auf der Bühne als einer Metapher für das Agieren eines Individuums in der Gesellschaft, der Kultur, einem politischen System und einem Staat.
<G-vec00681-002-s033><crack.brechen><en> Importantly, this is the first time that researchers have observed solidification cracking in steel and sheds new light on why the alloy may crack during the process.
<G-vec00681-002-s033><crack.brechen><de> Wesentlich ist dabei, dass die Bildung von Erstarrungsrissen in Stahl hier erstmals von Forschern beobachtet wurde, die so feststellen konnten, warum die Legierung bei diesem Vorgang brechen kann.
<G-vec00681-002-s034><crack.brechen><en> Unlike real wood and stone, it won't splinter, warp or crack.
<G-vec00681-002-s034><crack.brechen><de> Im Gegensatz zu echtem Holz oder Stein, splittern, verziehen oder brechen unsere Böden nicht.
<G-vec00681-002-s035><crack.brechen><en> The ink remains flexible after printing so that it does not crack when the printed material bends or stretches.
<G-vec00681-002-s035><crack.brechen><de> Die Tinte bleibt flexibel und kann folglich nicht brechen, wenn das Material gebogen oder gedehnt wird.
<G-vec00681-002-s036><crack.brechen><en> Under the press washer, it is necessary to drill a hole so that the sheets do not crack.
<G-vec00681-002-s036><crack.brechen><de> Unter dem Presswäscher muss ein Loch gebohrt werden, damit die Bleche nicht brechen.
<G-vec00681-002-s037><crack.brechen><en> Based on a performed analysis, our engineers predict the kind of environment where the phone will withstand a drop without damage or where the glass might rather crack.
<G-vec00681-002-s037><crack.brechen><de> Auf Grund einer durchgeführten Analyse können unsere Ingenieure die Art der Umgebung, in der das Telefon einen Sturz unbeschadet übersteht oder wo das Glas eher brechen wird, prognostizieren.
<G-vec00681-002-s038><crack.brechen><en> My titanium wrench can crack a rusted nut from a bolt as easily as it can crush skulls.
<G-vec00681-002-s038><crack.brechen><de> Mein Titan Schraubenschlüssel kann ebenso leicht eine Mutter aus einem Bolzen brechen, als auch Schädel aufbrechen.
<G-vec00681-002-s039><crack.brechen><en> In our conversations we tried to crack the code of this enigma.
<G-vec00681-002-s039><crack.brechen><de> Bei unseren Konversationen versuchten wir, den Code dieses Rätsels zu brechen.
<G-vec00681-002-s040><crack.brechen><en> Like diamonds, topaz is a very hard stone but it is likely to crack from a violent impact.
<G-vec00681-002-s040><crack.brechen><de> Ebenso wie der Diamant ist der Topas ein sehr harter Stein, der jedoch bei heftigen Stößen brechen kann.
<G-vec00681-002-s041><crack.brechen><en> Made from a soft, flexible rubber compound that will not curl, crack or harden even in sub-zero temperatures.
<G-vec00681-002-s041><crack.brechen><de> Die Matten werden aus einer weichen, flexiblen Gummimischung hergestellt, die selbst bei Minusgraden die Form bewahrt und nicht bricht oder hart wird.
<G-vec00681-002-s042><crack.brechen><en> It can be rolled well, does not crack when rolled and can be used with rolling machine.
<G-vec00681-002-s042><crack.brechen><de> Sie lässt sich auch mit der Maschine leicht ausrollen, und bricht beim Ausrollen nicht.
<G-vec00681-002-s043><crack.brechen><en> This makes it an ideal material type for this application as it will not crack or split.
<G-vec00681-002-s043><crack.brechen><de> Das macht es zu einem idealen Materialtypen für diesen Anwendungsfall, da es weder bricht noch sich spaltet.
<G-vec00681-002-s044><crack.brechen><en> Avoid bringing the blow-dryer too close to the leather as this can cause it to crack or chip.
<G-vec00681-002-s044><crack.brechen><de> Bringe den Föhn nicht zu nah an das Leder heran, da das dazu führen könnte, dass das Leder bricht oder abplatzt.
<G-vec00681-002-s079><crack.knacken><en> Find a pattern and crack the code with NSA CryptoChallenge.
<G-vec00681-002-s079><crack.knacken><de> Finden Sie ein Muster und knacken Sie den Code mit NSA CryptoChallenge.
<G-vec00681-002-s080><crack.knacken><en> Sliding design is much easier to crack than stationary, so you still need to think through additional protection against hacking.
<G-vec00681-002-s080><crack.knacken><de> Schiebe-Design ist viel einfacher zu knacken als stationär, so dass Sie noch durch zusätzlichen Schutz gegen Hacking denken müssen.
<G-vec00681-002-s081><crack.knacken><en> Only smart gamers can crack it.
<G-vec00681-002-s081><crack.knacken><de> Nur intelligente Spieler knacken können es.
<G-vec00681-002-s082><crack.knacken><en> Short passwords are easy to crack, long ones are hard to remember.
<G-vec00681-002-s082><crack.knacken><de> Kurze Passwörter sind schnell zu knacken, lange wiederum schwer zu merken.
<G-vec00681-002-s083><crack.knacken><en> If I could crack the Hummingbird code, I could get my websites to kill it in the SERPs.
<G-vec00681-002-s083><crack.knacken><de> Wenn ich den Hummingbird-Code knacken könnte, könnte ich meine Webseiten in den SERPs ganz nach oben katapultieren.
<G-vec00681-002-s084><crack.knacken><en> Nevertheless, English and Polish code-analysts managed to crack German radio messages several times, which had a great impact on the war.
<G-vec00681-002-s084><crack.knacken><de> Trotzdem schafften es polnische und britische Kryptoanalytiker immer wieder, Funksprüche der Deutschen zu knacken, was den Kriegsverlauf entscheidend beeinflusste.
<G-vec00681-002-s085><crack.knacken><en> The substrate, made of fiberglass roofing tissue, is not easy to crack, ageing and rot.
<G-vec00681-002-s085><crack.knacken><de> Das Substrat, das aus Glasfaser-Dachgewebe besteht, ist nicht leicht zu knacken, zu altern und zu verrotten.
<G-vec00681-002-s086><crack.knacken><en> After all, each person was once a charming baby with no less charming heels, but for some reason, in a few decades (and even earlier), the heels cease not to be touched, but simply to please, because they begin to crack.
<G-vec00681-002-s086><crack.knacken><de> Schließlich war jede Person einmal ein bezauberndes Baby mit nicht weniger charmanten Fersen, aber aus irgendeinem Grund, in ein paar Jahrzehnten (und noch früher), hören die Fersen auf, nicht berührt zu werden, sondern einfach zu gefallen, weil sie anfangen zu knacken.
<G-vec00681-002-s087><crack.knacken><en> The military vehicles will crack and break up on impact with incoming projectiles.
<G-vec00681-002-s087><crack.knacken><de> Die Militärfahrzeuge werden beim Aufprall von Geschosse knacken und zerbrechen.
<G-vec00681-002-s088><crack.knacken><en> Here it was clear early on that this would be one very tough nut to crack for the SECUINFRA Eight.
<G-vec00681-002-s088><crack.knacken><de> Hier war früh klar: Diese Nuss wird für den SECUINFRA-Achter schwer zu knacken sein.
<G-vec00681-002-s089><crack.knacken><en> The prototype they've come up with to crack this particularly hard nut is a system with three modules: one to crush, another to separate the shell from the nut and another to extract the walnut oil.
<G-vec00681-002-s089><crack.knacken><de> Der Nussknacker mit Pedalpower Der Prototyp zum Knacken der harten Nuss ist ein System mit drei Modulen: Eins zum Zerkleinern, eins zum Separieren von Schale und Nussfrucht und eins zum Pressen des Walnussöls.
<G-vec00681-002-s090><crack.knacken><en> Hack any wireless network and crack the passwords.
<G-vec00681-002-s090><crack.knacken><de> Zerhacken Sie jedes drahtlose Netz und knacken Sie die Kennwörter.
<G-vec00681-002-s091><crack.knacken><en> If they can crack Spain, then they will move on to Italy – and then it will really escalate into a colossal mess for the euro as an alternative to the dollar.
<G-vec00681-002-s091><crack.knacken><de> Wenn sie Spanien knacken können, dann werden sie sich nach Italien bewegen – und dann wird es wirklich in ein kolossales Chaos für den Euro als Alternative zum Dollar eskalieren.
<G-vec00681-002-s092><crack.knacken><en> Through the misty air we heard the short, dry crack of a pistol.
<G-vec00681-002-s092><crack.knacken><de> In der trüben Luft erklang ein kurzes, trockenes Knacken.
<G-vec00681-002-s093><crack.knacken><en> Casey’s laptop was found in her car – but the East specialists are not able to crack the password.
<G-vec00681-002-s093><crack.knacken><de> Casey´s Laptop wurde in ihrem Auto gefunden – doch es gelingt den Ost-Spezialisten nicht das Passwort zu knacken.
<G-vec00681-002-s094><crack.knacken><en> Visually very deterrent but relatively easy to crack.
<G-vec00681-002-s094><crack.knacken><de> Optisch sehr Abschreckend aber relativ leicht zu knacken.
<G-vec00681-002-s095><crack.knacken><en> It’s a lucrative scam: hackers crack into the IT system of a company and get a precise look at the employee structure and communication channels.
<G-vec00681-002-s095><crack.knacken><de> Es ist eine einträgliche Masche: Hacker knacken die EDV einer Firma und schauen sich Mitarbeiterstruktur und Kommunikationswege genau an.
<G-vec00681-002-s096><crack.knacken><en> Special scanning protection hampers attempts to crack the code through tampering.
<G-vec00681-002-s096><crack.knacken><de> Ein spezieller Abtastschutz erschwert dabei das Knacken des Zahlencodes durch Manipulationen.
<G-vec00681-002-s097><crack.knacken><en> You can see how much you will get if you crack the jackpot, in the display in the above field under ‘Jackpot’. Top Log in
<G-vec00681-002-s097><crack.knacken><de> Wie viel Sie bekommen, falls Sie den Jackpot knacken, können Sie der Einblendung im Spielfeld oben unter „Jackpot“ entnehmen.
<G-vec00681-002-s107><crack.platzen><en> Fuel cold as ice may cause the crack of lines or the damage of safety valves: The Challenger Catastrophe of Grand Prix scheduled.
<G-vec00681-002-s107><crack.platzen><de> Eiskalter Sprit lässt unter Umständen Leitungen platzen, Dichtungen zerstören und Rückschlagsventile wirkungslos werden: Die Challenger-Katastrophe des Grand Prix vorprogrammiert.
<G-vec00681-002-s108><crack.platzen><en> "let me look at the egg which won't crack," said the old duck."
<G-vec00681-002-s108><crack.platzen><de> »Lass mich das Ei sehen, welches nicht platzen will!« sagte die Alte.
<G-vec00681-002-s109><crack.platzen><en> When the egg is warmed up, the air inside the shell starts to expand and its higher pressure could crack the shell.
<G-vec00681-002-s109><crack.platzen><de> Oder folgendes machen: Wenn die Eier erhitzt sind, beginnt sich die Luft im Inneren der Schale zu erweitern und das Ei kann platzen.
<G-vec00681-002-s110><crack.platzen><en> Do not place bottled and canned drinks in the freezer as they ■ may crack when frozen.
<G-vec00681-002-s110><crack.platzen><de> Lassen Sie Getränke in Flaschen und in Dosen nicht im ■ Gefrierfach, da diese beim Einfrieren platzen können.
<G-vec00681-002-s111><crack.reißen><en> This item is a set 100% Brand New Aftermarket Motorcycle Full Fairing Kit,and ALL fairings Pre-Drilled,which have good elasticity and not easily crack or melt.
<G-vec00681-002-s111><crack.reißen><de> Dieser Artikel ist ein Satz aus 100% brandneuen Aftermarket Motorcycle Full Verkleidungskits und ALLEN Verkleidungen Vorgebohrt,welche eine gute Elastizität haben und nicht leicht reißen oder schmelzen.
<G-vec00681-002-s112><crack.reißen><en> When mounting the mobile doors to the plasterboard wall, one should always consider the weight of the doors themselves, so it does not turn out that the wall will crack during use.
<G-vec00681-002-s112><crack.reißen><de> Bei der Montage der fahrbaren Türen an die Wand aus Gipskarton sollte man auch immer das Gewicht der Türen selbst in Erwägung ziehen, sodass es sich nicht herausstellt, dass die Wand während des Gebrauches von dem Übergewicht anfängt zu reißen.
<G-vec00681-002-s113><crack.reißen><en> For a long time of operation of turbo, its body can crack or deform.
<G-vec00681-002-s113><crack.reißen><de> Für eine lange Betriebszeit der Turbine kann ihr Körper reißen oder sich verformen.
<G-vec00681-002-s114><crack.reißen><en> It is quite dense and does not cause stickiness, unlike its cheap competitors, which can crack and tear during tension.
<G-vec00681-002-s114><crack.reißen><de> Es ist ziemlich dicht und verursacht keine Klebrigkeit, im Gegensatz zu seinen billigen Konkurrenten, die bei Spannung reißen und reißen können.
<G-vec00681-002-s115><crack.reißen><en> If during a screening process a crack occurs in the mesh or the machine has to cope with too much product, the online particle measuring device JEL Horus ensures early detecting of the problem, hence avoiding high consequential costs.
<G-vec00681-002-s115><crack.reißen><de> Sollte beim Siebprozess das Siebgewebe reißen oder die Maschine mit zu viel Produkt zu kämpfen haben, sorgt die Online-Partikelmessung der JEL Horus für ein frühzeitiges Erkennen des Problems und damit zur Vermeidung von eventuell hohen Folgekosten.
<G-vec00681-002-s116><crack.reißen><en> It will never crack and will not get dirty for a long time.
<G-vec00681-002-s116><crack.reißen><de> Es wird niemals reißen und wird lange Zeit nicht schmutzig.
<G-vec00681-002-s117><crack.reißen><en> It will crack if subjected to very sudden and radical temperature fluctuations, or if it is dropped.
<G-vec00681-002-s117><crack.reißen><de> Es wird reißen, wenn es sehr plötzlichen und radikalen Temperaturschwankungen ausgesetzt wird, oder wenn es fallen gelassen wird.
<G-vec00681-002-s118><crack.reißen><en> As the most vulnerable part of the bearing, the rubber component is likely to become brittle and crack under excessive strain.
<G-vec00681-002-s118><crack.reißen><de> Das besonders anfällige Gummi in den Lagern kann dabei leicht brüchig werden und reißen.
<G-vec00681-002-s119><crack.reißen><en> If it is a little wet, the jar can crack from the temperature drop.
<G-vec00681-002-s119><crack.reißen><de> Wenn es ein wenig nass ist, kann das Glas durch den Temperaturabfall reißen.
<G-vec00681-002-s120><crack.reißen><en> Unlike Apple Bee’s LWC, this means that the material can crack quickly.
<G-vec00681-002-s120><crack.reißen><de> Dies hat zur Folge, ganz im Gegensatz zum LWC von Apple Bee, dass das Material schnell reißen kann.
<G-vec00681-002-s121><crack.reißen><en> Because of its tendency to crack and its irregular growth, olive wood requires the most attention from our turner.
<G-vec00681-002-s121><crack.reißen><de> Wegen seiner Neigung zum Reißen und zum unregelmäßigen Wuchs verlangt das Olivenholz von unserer Drechslerin die meiste Zuwendung.
<G-vec00681-002-s122><crack.reißen><en> At the international Formnext trade fair in Frankfurt, the high-tech company will demonstrate how the TruPrint 5000, preheated to 500 degrees Celsius, prints high-carbon steel or titanium alloy components that don’t crack or severely warp.
<G-vec00681-002-s122><crack.reißen><de> Auf der internationalen Fachmesse Formnext in Frankfurt präsentiert das Hochtechnologieunternehmen, wie die TruPrint 5000 mit einer Vorheizung von 500 Grad Bauteile aus Stahl mit hohem Kohlenstoffanteil oder Titanlegierungen druckt, ohne dass sie reißen oder sich stark verziehen.
<G-vec00681-002-s123><crack.reißen><en> According to document (2b) direct application of paint on the previous coating has the unexceptional effect of causing the coated surface to shrink and crack, because the solvent of the top coating penetrates and loosens the previous coating.
<G-vec00681-002-s123><crack.reißen><de> Gemäß dieser Entgegenhaltung führt die direkte Aufbringung von Farbe auf die alte Farbschicht häufig zum Schrumpfen und Reißen der neuen Schicht, weil das darin enthaltene Lösungsmittel in die alte Schicht eindringt und sie ablöst.
<G-vec00681-002-s124><crack.reißen><en> Because of these additional components, gouache lightens upon drying, and it can even crack if deposited too thickly.
<G-vec00681-002-s124><crack.reißen><de> Durch diese zusätzlichen Bestandteile hellt sich die Gouache beim Trocknen auf und kann sogar reißen, wenn sie zu dick aufgetragen wird.
<G-vec00681-002-s125><crack.reißen><en> H229 Container is under pressure: May crack when heated.
<G-vec00681-002-s125><crack.reißen><de> H229 Behälter steht unter Druck: Kann beim Erhitzen reißen.
<G-vec00681-002-s126><crack.reißen><en> However, if clayeys are found on the site, then such a foundation is not recommended, since it can crack or even burst.
<G-vec00681-002-s126><crack.reißen><de> Wenn jedoch Tonerden auf der Baustelle gefunden werden, wird eine solche Grundlage nicht empfohlen, da sie reißen oder sogar platzen kann.
<G-vec00681-002-s127><crack.reißen><en> The sun will burn and the ground will crack.
<G-vec00681-002-s127><crack.reißen><de> Die Sonne wird brennen und der Boden wird reißen.
<G-vec00681-002-s128><crack.reißen><en> Some seals will slowly dry out and crack over time due to exposure to extreme hot and cold temperatures.
<G-vec00681-002-s128><crack.reißen><de> Manche Dichtungen trocknen wegen der extrem heißen und kalten Temperaturen, denen sie ausgesetzt sind, langsam aus und reißen mit der Zeit.
<G-vec00681-002-s129><crack.reißen><en> This is an uncontrolled and unwanted crack.
<G-vec00681-002-s129><crack.reißen><de> Ein unkontrolliertes und ungewolltes Reißen.
<G-vec00681-002-s130><crack.reißen><en> It will no longer absorb water, is dimensionally stable, and will no longer crack.
<G-vec00681-002-s130><crack.reißen><de> Er nimmt kaum noch Wasser auf, das heißt, er ist formstabil und reißt nicht mehr.
<G-vec00681-002-s131><crack.reißen><en> Our fibre cement doesn’t crack, swell or warp like wood or some vinyl.
<G-vec00681-002-s131><crack.reißen><de> Anders als Holz oder manche Vinyle reißt, schwillt und verzieht sich unser Faserzement nicht.
<G-vec00681-002-s132><crack.reißen><en> So part of the users choose to use steel as the material for the body of the tool because it is tougher and will not crack or shatter, with tungsten carbide saw tips being brazing on to the body.
<G-vec00681-002-s132><crack.reißen><de> So wählt ein Teil der Anwender Stahl als Material für den Körper des Werkzeugs, weil es zäher ist und nicht reißt oder zerbricht, wobei die Hartmetallsäge Spitzen an den Körper gelötet werden.
<G-vec00681-002-s133><crack.reißen><en> This material has a soft fabric surface, so it won't crack when washed.
<G-vec00681-002-s133><crack.reißen><de> Dieses Material hat eine weiche Stoffoberfläche, so dass es beim Waschen nicht reißt.
<G-vec00681-002-s134><crack.reißen><en> Aspen lining does not crack, easily processed and performs well in high humidity conditions.
<G-vec00681-002-s134><crack.reißen><de> Das Espenprofil reißt nicht, lässt sich leicht verarbeiten und funktioniert gut beim Einsatz in Umgebung mit hoher Luftfeuchtigkeit.
<G-vec00681-002-s135><crack.reißen><en> Heating should be done gradually, sending a stream of hot air slightly to the side, so that the display glass does not crack.
<G-vec00681-002-s135><crack.reißen><de> Die Erwärmung sollte schrittweise erfolgen, indem ein heißer Luftstrom leicht zur Seite geschickt wird, damit das Displayglas nicht reißt.
<G-vec00681-002-s136><crack.reißen><en> The dry ice will harden and then crack the adhesive.
<G-vec00681-002-s136><crack.reißen><de> Das Trockeneis erhärtet und reißt den Klebstoff dann auf.
<G-vec00681-002-s137><crack.reißen><en> Acrylic sealant does not crack, even if the gap widens to 200% of its original width.
<G-vec00681-002-s137><crack.reißen><de> Acryldichtstoff reißt nicht, auch wenn sich der Spalt auf 200% seiner ursprünglichen Breite verbreitert.
<G-vec00681-002-s138><crack.reißen><en> If the blade was tightly stretched when sawing, it will be overstretched when cooling and consequently crack quicker.
<G-vec00681-002-s138><crack.reißen><de> War das Blatt beim Sägen straff gespannt, wird es beim Erkalten überdehnt und reißt dadurch früher.
<G-vec00681-002-s139><crack.reißen><en> Both can ruin the nail polish and cause it to crack when it dries.
<G-vec00681-002-s139><crack.reißen><de> Beides kann deinen Nagellack ruinieren und bewirken, dass er reißt, wenn er trocknet.
<G-vec00681-002-s140><crack.reißen><en> This ointment will also keep your scrape moist so it won’t crack and get worse when you move around.
<G-vec00681-002-s140><crack.reißen><de> Diese Salbe hält die Wunde außerdem feucht, so dass sie nicht reißt und schlimmer wird, wenn du dich bewegst.
<G-vec00681-002-s141><crack.reißen><en> He can be sarcastic at times and loves to crack a joke, but he knows his scrap and works hard too.
<G-vec00681-002-s141><crack.reißen><de> Er kann schon mal sarkastisch sein und reißt gern Witze, aber er kennt seinen Schrott und arbeitet auch fleißig.
<G-vec00681-002-s142><crack.reißen><en> Especially with older, worn out gears you risk a crack of chain, if you try forcibly to ascend too high slopes.
<G-vec00681-002-s142><crack.reißen><de> Insbesondere bei älteren verschlissenen Schaltungen reißt die Kette, wenn man mit Gewalt versucht, zu hohe Steigungen raufzufahren.
<G-vec00681-002-s286><crack.zerbrechen><en> They are equipped with brown, tempered glass that is very difficult to scratch or crack.
<G-vec00681-002-s286><crack.zerbrechen><de> Sie ist mit braunen, gehärteten Sonnenbrillengläsern ausgestattet, die sehr schwer zu zerkratzen oder zerbrechen sind.
<G-vec00681-002-s287><crack.zerbrechen><en> Do not chew up, crack or smash the tablets because this can eliminate the protective effect of the alimentary canal covering.
<G-vec00681-002-s287><crack.zerbrechen><de> Zerkauen, zerbrechen oder zerschlagen Sie die Tabletten nicht, da dies die schützende Wirkung der Abdeckung des Verdauungskanals beseitigen kann.
<G-vec00681-002-s288><crack.zerbrechen><en> After all the effort you put into your cheesecake, don't let it crack when you take it out of the pan.
<G-vec00681-002-s288><crack.zerbrechen><de> Nach der ganzen Arbeit, die du dir mit deinem Käsekuchen gemacht hast, sollte er nicht zerbrechen, wenn du ihn aus der Form hebst.
<G-vec00903-002-s028><crack.aufschlagen><en> Being able to crack an egg is a handy kitchen skill.
<G-vec00903-002-s028><crack.aufschlagen><de> Ein Ei aufschlagen können erweist sich in der Küche als praktische Fähigkeit.
<G-vec00903-002-s029><crack.aufschlagen><en> Crack the egg gently all over its surface, then peel away the shell under running water.
<G-vec00903-002-s029><crack.aufschlagen><de> Das Ei vorsichtig über die gesamte Oberfläche aufschlagen, dann die Schale unter fließendem Wasser abziehen.
<G-vec00903-002-s030><crack.aufschlagen><en> To poach an egg, first crack an egg into a small bowl.
<G-vec00903-002-s030><crack.aufschlagen><de> Ein Ei aufschlagen, in eine kleine Auflaufform, kleine Schüssel oder eine Suppenkelle geben.
<G-vec00903-002-s098><crack.lösen><en> You have exactly 60 minutes in order to crack all the quizzes and escape the room.
<G-vec00903-002-s098><crack.lösen><de> Du hast genau 60 Minuten Zeit, um alle Rätsel zu lösen und die Zimmertür zu öffnen.
<G-vec00903-002-s099><crack.lösen><en> Now they don't have to just crack the case - they have to figure out if they can have a mature relationship.
<G-vec00903-002-s099><crack.lösen><de> Sie müssen jetzt nicht mehr nur einfach den Fall lösen, sie müssen herausfinden, ob sie in der Lage sind, eine reife Freundschaft wie Erwachsene zu führen.
<G-vec00903-002-s100><crack.lösen><en> Now they don't have to just crack the case - they have to figure out if they can have a mature relationship.
<G-vec00903-002-s100><crack.lösen><de> Sie müssen jetzt nicht mehr nur einfach den Fall lösen, sie müssen herausfinden, ob sie in der Lage sind, eine reife, erwachsene Freundschaft zu führen.
<G-vec00903-002-s101><crack.lösen><en> Collect the things needed to forge the enigmatic Velvet Keys and crack the case.
<G-vec00903-002-s101><crack.lösen><de> Sammle alle Gegenstände, die Du benötigst, um den rätselhaften Samtschlüssel zu schmieden und den Fall zu lösen.
<G-vec00903-002-s257><crack.spalten><en> The storm blew stronger and stronger, but the duckling noticed that one hinge had come loose and the door hung so crooked that he could squeeze through the crack into the room, and that's just what he did.
<G-vec00903-002-s257><crack.spalten><de> Da bemerkte es, daß die Tür aus der einen Angel gegangen war und so schief hing, daß es durch die Spalte in die Stube hineinschlüpfen konnte, und das tat es.
<G-vec00903-002-s258><crack.spalten><en> If there are a hidden blemish, vice or any other crack coming from the manufacturer and not from the conveyor, we commit ourselves changing the object in the measurement of stocks available.
<G-vec00903-002-s258><crack.spalten><de> Wenn es einen Schönheitsfehler, einen verheimlichten Fehler oder jede andere Spalte gibt, die aus dem Hersteller und nicht aus dem Transportunternehmer stammt, verpflichten wir uns, den Gegenstand in der Maßnahme der verfügbaren Bestände zu wechseln.
<G-vec00903-002-s259><crack.spalten><en> A certa altura, Once during the long evening one side door and then the other door was opened just a tiny crack and quickly closed again. Someone presumably needed to come in but had then thought better of it.
<G-vec00903-002-s259><crack.spalten><de> Einmal während des langen Abends wurde die eine Seitentüre und einmal die andere bis zu einer kleinen Spalte geöffnet und rasch wieder geschlossen; jemand hatte wohl das Bedürfnis hereinzukommen, aber auch wieder zuviele Bedenken.
<G-vec00903-002-s262><crack.spalten><en> The sea’s waters make such a great show while the babe is nailed in her crack with pubic haircut.
<G-vec00903-002-s262><crack.spalten><de> Das Wasser des Meeres macht solch eine großartige Show während dieses Babe in ihrer Spalte mit einem Schaamhaarschnitt genagelt wird.
<G-vec00903-002-s263><crack.spalten><en> She is driven crazy having the crack licked and rubbed by this white man.
<G-vec00903-002-s263><crack.spalten><de> Sie wird verrückt davon, als ihre Spalte von diesem weißen Mann geleckt und gerubbelt wird.
<G-vec00903-002-s264><crack.spalten><en> She has the crack licked and fucked with man’s tongue from behind.
<G-vec00903-002-s264><crack.spalten><de> Ihre Spalte wird geleckt und von hinten mit der Zunge des Mannes gefickt.
<G-vec00903-002-s265><crack.spalten><en> Otherwise the nail hammered into a face groove of a lath, gets to a crack between boards that reduces durability of fastening of a parquet.
<G-vec00903-002-s265><crack.spalten><de> Andernfalls gerät der Nagel, der in den Stirnfalz der Leiste eingeschlagen wird, in die Spalte zwischen den Brettern, dass die Haltbarkeit der Befestigung des Parketts verringert.
<G-vec00903-002-s266><crack.spalten><en> Looking at the shape of the rock, it could have been opened out from the same crack as the previous cave, but by this point in the dive I don’t want to follow the crack back down past an overhang to check my suspicion.
<G-vec00903-002-s266><crack.spalten><de> Wenn ich mir die Form der Felsen anschaue, könnte sich diese Höhle aus derselben Spalte wie die vorherige öffnen, aber an diesem Punkt des Tauchgangs will ich der Spalte nicht nach unten, entlang eines Überhangs, folgen, um meine Neugierde zu befriedigen.
<G-vec00903-002-s268><crack.spalten><en> Block ten was located near block eleven, the so-called bunker where thousands of executions had taken place, which I could once observe through the crack of some wooden boards.
<G-vec00903-002-s268><crack.spalten><de> Block zehn (10) befand sich neben Block 11, der sogenannte Bunker, wo Tausend von Exekutionen stattfanden, die ich oftmals durch die Spalte einiger Holzbretter sehen konnte.
<G-vec00903-002-s269><crack.spalten><en> Diana rides the man’s mouth with her fish taco while Giselle rides his dick with her crack.
<G-vec00903-002-s269><crack.spalten><de> Diana reitet den Mund des Mannes mit ihrer Muschi, während Giselle seinen Schawnz mit ihrer Spalte reitet.
