<G-vec00060-001-s276><comment.kommentieren><en> Comment on the dreams of Joseph and the Pharaoh.
<G-vec00060-001-s276><comment.kommentieren><de> Kommentiere die Träume Josefs und des Pharaons.
<G-vec00060-001-s277><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment. Related posts
<G-vec00060-001-s277><comment.kommentieren><de> Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00060-001-s278><comment.kommentieren><en> Simply select the rows concerned, right-click and select the menu item Comment Selected (or using [Ctrl + Alt + .
<G-vec00060-001-s278><comment.kommentieren><de> Wählen Sie einfach die betroffenen Zeile aus und wählen Sie dann den Rechtsklickmenüpunkt Kommentiere Ausgewähltes (oder [Strg + Alt + .
<G-vec00060-001-s279><comment.kommentieren><en> How to gain trusted links with comments: Don’t comment spam.
<G-vec00060-001-s279><comment.kommentieren><de> Wie Du hochwertige Links mit Hilfe von Kommentaren generierst: Kommentiere keinen Spam.
<G-vec00060-001-s280><comment.kommentieren><en> I can't comment on the results of individual institutions.
<G-vec00060-001-s280><comment.kommentieren><de> Die Ergebnisse einzelner Institute kommentiere ich nicht.
<G-vec00060-001-s281><comment.kommentieren><en> Put a comment below. If I feel it's important I will write a new topic or add it to the FAQ.
<G-vec00060-001-s281><comment.kommentieren><de> Kommentiere auf der Unterseite wo es dazugehört, falls ich es sinnvoll halte ergaenze ich es oder schreib eine weitere Anleitung.
<G-vec00060-001-s282><comment.kommentieren><en> So I look at my children and I try not to comment.
<G-vec00060-001-s282><comment.kommentieren><de> Meine Ableitung: Ich kommentiere so was nicht.
<G-vec00060-001-s283><comment.kommentieren><en> - Comment on translations of other users and receive feedback on your translations - this will improve your knowledge and help others to improve.
<G-vec00060-001-s283><comment.kommentieren><de> - Kommentiere Übersetzungen anderer Nutzer und erhalte Feedback zu deinen Übersetzungen – dies wird deine Fähigkeiten und die der anderen verbessern.
<G-vec00060-001-s284><comment.kommentieren><en> Don't tweet or comment about your job or your colleagues in your social media accounts.
<G-vec00060-001-s284><comment.kommentieren><de> Tweete oder kommentiere in deinen Social Media Accounts nicht über deinen Job oder deine Kollegen.
<G-vec00060-001-s285><comment.kommentieren><en> When appropriate, comment on and like her posts on Instagram, Facebook, Twitter, etc.
<G-vec00060-001-s285><comment.kommentieren><de> Kommentiere oder like ihre Posts auf Instagram, Facebook, Twitter, etc., wenn es passt.
<G-vec00060-001-s286><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment. More products
<G-vec00060-001-s286><comment.kommentieren><de> Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00060-001-s287><comment.kommentieren><en> - WATCH amazing covers, like, comment and interact with other singers.
<G-vec00060-001-s287><comment.kommentieren><de> - ANSEHEN: Sieh dir großartige Cover-Songs an, like, kommentiere und interagiere mit anderen Sängerinnen und Sängern.
<G-vec00060-001-s288><comment.kommentieren><en> Take pictures, share on social media and comment on the blog to make this campaign the talk of your town.
<G-vec00060-001-s288><comment.kommentieren><de> Mache Bilder, teile auf Social Media und kommentiere auf dem Blog um diese Kampagne zum Stadtgespräch zu machen.
<G-vec00060-001-s289><comment.kommentieren><en> 2007-11-13 22:16:19 - Stopping yourself I read on a bulletin board a traders comment that on his first outing trading the E-Mini S&P 500 he lost on each of his trades.
<G-vec00060-001-s289><comment.kommentieren><de> 2007-11-13 22:16:19 - Stoppen Ich las auf einem Anschlagbrett, das Händler ist, kommentiere das seinen ersten Outing, der das EMini-S&P handelt, 500, die er auf jedem seines Handels verlor.
<G-vec00060-001-s290><comment.kommentieren><en> To comment you need to log in.
<G-vec00060-001-s290><comment.kommentieren><de> Zum Kommentieren müssen Sie sich einloggen.
<G-vec00060-001-s291><comment.kommentieren><en> regardless of whether you follow them or not unless they have a private account, you are able to comment and link their content.
<G-vec00060-001-s291><comment.kommentieren><de> unabhängig davon, ob Sie ihnen folgen oder nicht, wenn sie nicht über ein eigenes Konto haben, Sie sind in der Lage zu kommentieren und ihre Inhalte verknüpfen.
<G-vec00060-001-s292><comment.kommentieren><en> Absolutely! 😃💛👍 Log in to like or comment.
<G-vec00060-001-s292><comment.kommentieren><de> Melde dich an, um mit „Gefällt mir“ zu markieren oder zu kommentieren.
<G-vec00060-001-s293><comment.kommentieren><en> The oldest children in primary education can execute tasks on their own, they can reflect on what they are doing, they can comment on earlier solutions and preset solutions, and from there on look at new constructions.
<G-vec00060-001-s293><comment.kommentieren><de> Die ältesten Kinder im Primarbereich können Aufgaben selbständig lösen, sie können darüber reflektieren, was sie tun und frühere oder vorgegebene Lösungen kommentieren und sich dann neuen Konstruktionen zuwenden.
<G-vec00060-001-s294><comment.kommentieren><en> Comment out the old line; you can always switch back to it if you prefer it.
<G-vec00060-001-s294><comment.kommentieren><de> Kommentieren Sie die alte Zeile aus, damit diese notfalls wieder benutzt werden kann.
<G-vec00060-001-s295><comment.kommentieren><en> More and more content is being produced, which invites its audience to share, like and comment on it.
<G-vec00060-001-s295><comment.kommentieren><de> Es wird immer mehr Content produziert, der zum Teilen, Liken und Kommentieren einlädt.
<G-vec00060-001-s296><comment.kommentieren><en> As a result of this collection, an evaluation report together with specific recommendations in terms of usability is available and there is a possibility for a broader public to comment on the results.
<G-vec00060-001-s296><comment.kommentieren><de> Als Ergebnis dieser Sammlung wird ein Evaluationsbericht mit konkreten Empfehlungen in Bezug auf Benutzerfreundlichkeit zur Verfügung gestellt und es besteht für ein breiteres Publikum die Möglichkeit, diese Ergebnisse zu kommentieren.
<G-vec00060-001-s297><comment.kommentieren><en> While it is not Microsoft policy to comment on unannounced products, it is important to the Help Team to release a general purpose Help engine as soon as possible.
<G-vec00060-001-s297><comment.kommentieren><de> Weil es nicht Microsoft's Politik ist, unangekündigte Produkte zu kommentieren, ist es für das Help Team wichtig, eine Universalhilfemaschine sobald wie möglich freizugeben.
<G-vec00060-001-s298><comment.kommentieren><en> "Even without looking at the code, the ""comment"" and ""share"" features don't work."
<G-vec00060-001-s298><comment.kommentieren><de> "Und ohne sich den Code genauer anzusehen, stellt man fest, dass ""Kommentieren"" und ""Teilen"" nicht funktionieren."
<G-vec00060-001-s299><comment.kommentieren><en> localwise.sfbay 😉 Log in to like or comment.
<G-vec00060-001-s299><comment.kommentieren><de> Melde dich an, um mit „Gefällt mir“ zu markieren oder zu kommentieren.
<G-vec00060-001-s300><comment.kommentieren><en> Markus Götz and Stefan Kretzschmar comment.
<G-vec00060-001-s300><comment.kommentieren><de> Markus Götz und Stefan Kretzschmar kommentieren.
<G-vec00060-001-s301><comment.kommentieren><en> He visited several literary cafés in Tirana to meet with young writers, to get to know their works and to comment on them together with the authors.
<G-vec00060-001-s301><comment.kommentieren><de> Dazu traf er sich in Literaturcafés mit jungen albanischen Schriftstellerinnen und Schriftstellern, um deren Werke kennenzulernen sie mit ihnen gemeinsam zu kommentieren.
<G-vec00060-001-s302><comment.kommentieren><en> If you think you are, What is this “dizuha” – can not read and did not comment on, After all, you will “the hand does not pull”.
<G-vec00060-001-s302><comment.kommentieren><de> Wenn Sie der Meinung sind, dass Sie, Direkthilfe “dizuha” – kann nicht lesen und nicht kommentieren, Schließlich werden Sie “die Hand nicht ziehen.”.
<G-vec00060-001-s303><comment.kommentieren><en> The company has yet to comment on the story.
<G-vec00060-001-s303><comment.kommentieren><de> Das Unternehmen muss die Geschichte noch kommentieren.
<G-vec00060-001-s304><comment.kommentieren><en> SOULFLY – comment on new album's guest...
<G-vec00060-001-s304><comment.kommentieren><de> SOULFLY – kommentieren Gast-Beiträge auf...
<G-vec00060-001-s305><comment.kommentieren><en> From this you are able to comment on each image.
<G-vec00060-001-s305><comment.kommentieren><de> Damit haben Sie die Möglichkeit jedes einzelne Bild zu kommentieren.
<G-vec00060-001-s306><comment.kommentieren><en> The entire community may comment reports and ask questions.
<G-vec00060-001-s306><comment.kommentieren><de> Die gesamte Community darf Berichte kommentieren und Fragen stellen.
<G-vec00060-001-s307><comment.kommentieren><en> Please log in or register in order to comment this medium.
<G-vec00060-001-s307><comment.kommentieren><de> Bitte registriere dich oder logge dich ein, um dieses Medium zu kommentieren.
<G-vec00060-001-s308><comment.kommentieren><en> I just wanted to comment on the letter from Ortiz.
<G-vec00060-001-s308><comment.kommentieren><de> Ich wollte nur von Ortiz auf den Brief kommentieren.
<G-vec00060-001-s309><comment.kommentieren><en> A short time ago, I wrote a comment about the call for a regulation of managerial income.
<G-vec00060-001-s309><comment.kommentieren><de> Vor kurzem habe ich die Forderung kommentiert, die Einkommen von Managern zu begrenzen.
<G-vec00060-001-s310><comment.kommentieren><en> But as some recent headlines demonstrate, it has already generated antagonistic questioning and pejorative comment.
<G-vec00060-001-s310><comment.kommentieren><de> Wie einige kürzlich erschienene Schlagzeilen zeigen, wird die Synthetische Biologie bereits kritisch hinterfragt und negativ kommentiert.
<G-vec00060-001-s311><comment.kommentieren><en> Just tell us in a comment which videos you like the best.
<G-vec00060-001-s311><comment.kommentieren><de> Kommentiert einfach, welche Videos euch am besten gefallen.
<G-vec00060-001-s312><comment.kommentieren><en> S + A compose a text detailing their hypotheses, ideas, concepts and interpretations with regard to the Trespassing project, which will be continuously updated and posted on the internal web platform for comment by all participants.
<G-vec00060-001-s312><comment.kommentieren><de> S + A schreiben einen Text zu ihren Hypothesen, Ideen, Konzepten, Interpretationen zum Trespassing Projekt, der fortlaufend auf der internen Web-Plattform abgelegt wird, und von allen TeilnehmerInnen kommentiert werden kann.
<G-vec00060-001-s313><comment.kommentieren><en> In keeping with the standard of our discipline, he speaks the language of the country, has access to the important players and to the voice of the people who comment on their actions, undertakes careful risk assessments, organises his security himself and has repeatedly returned safely from regions that most people have never heard of or whose names conjure up feelings of dread.
<G-vec00060-001-s313><comment.kommentieren><de> Er spricht, wie es dem Standard unseres Faches entspricht, die Sprache des Landes, hat Zugang zu den wichtigen Akteuren ebenso wie zu der Stimme des Volkes, die deren Aktionen kommentiert, nimmt sorgfältige Risikoeinschätzungen vor, organisiert seine Sicherheit selber und ist aus Gegenden, von denen die meisten nie oder nur mit Grauen gehört haben, immer wieder heil zurückgekommen.
<G-vec00060-001-s314><comment.kommentieren><en> He is still able to comment in a passionate way on the orientation of the bike industry towards more naked/custom/retro models and how that trend has helped push bikes closer to the mainstream.
<G-vec00060-001-s314><comment.kommentieren><de> Er kommentiert gerne und leidenschaftlich, wie sich die Motorradindustrie Naked-/Custom-/Retro-Modellen zuwendet und wie dieser Trend hilft, Motorräder weiter in den Mainstream zu rücken.
<G-vec00060-001-s315><comment.kommentieren><en> Bourriaud began his study of by comparing the specific sociability produced in the places of art (the ability to comment on and discuss work 'live' in its presence) to what he deems to be the individual, private spaces of consumption produced by theatre, cinema and literature.
<G-vec00060-001-s315><comment.kommentieren><de> Zu Beginn seiner Untersuchung verglich Bourriaud das spezifische gesellschaftliche Vermögen, das an den Orten der Kunst erzeugt wird (Arbeiten können 'live' in ihrer Gegenwart kommentiert und diskutiert werden), mit den – seiner Ansicht nach – individuellen und privaten Räumen des Konsums, wie sie das Theater, Kino oder die Literatur produziert.
<G-vec00060-001-s316><comment.kommentieren><en> As rapidly as possible, constitutional committee circulates draft Palestinian constitution, based on strong parliamentary democracy and cabinet with empowered prime minister, for public comment/debate.
<G-vec00060-001-s316><comment.kommentieren><de> Der Verfassungsausschuss verteilt schnellstmöglich den Entwurf der palästinensischen Verfassung, der auf einer starken parlamentarischen Demokratie und einem Kabinett mit einem entscheidungsbefugten Premierminister basiert, so dass er öffentlich kommentiert/debattiert werden kann.
<G-vec00060-001-s317><comment.kommentieren><en> Instructor will comment and give advice on the runway you have selected.
<G-vec00060-001-s317><comment.kommentieren><de> Ausbilder kommentiert und gibt Rat auf der Laufbahn, die Sie vorgewählt haben.
<G-vec00060-001-s318><comment.kommentieren><en> Users can comment on their contributions, spawning lively discussions.
<G-vec00060-001-s318><comment.kommentieren><de> Ihre Beiträge können von den Usern kommentiert werden, sodass sich auf Grundlage der eingestellten Texte lebendige Diskussionen entwickeln.
<G-vec00060-001-s319><comment.kommentieren><en> Hearings go even that Anna with the boyfriend plans a wedding, but the singer still did not comment on this information in any way.
<G-vec00060-001-s319><comment.kommentieren><de> Es gehen sogar die Gerüchte, dass Anna mit dem Partner die Hochzeit plant, aber die Sängerin noch hat diese Informationen auf keine Weise kommentiert.
<G-vec00060-001-s320><comment.kommentieren><en> "The reports of many interviews are ended with OSI comment, ""Interview not useful."
<G-vec00060-001-s320><comment.kommentieren><de> Die Berichte vieler dieser Vernehmungen werden am Ende vom OSI wie folgt kommentiert: »Vernehmungen nicht brauchbar.
<G-vec00060-001-s321><comment.kommentieren><en> Users can now comment on and debate a wide range of topics.
<G-vec00060-001-s321><comment.kommentieren><de> Viele Themen können jetzt kommentiert und diskutiert werden.
<G-vec00060-001-s322><comment.kommentieren><en> The installation is also an ironic comment on the modern art scene, in which curators, art critics, gallery owners and collectors are constantly chasing the new, and even artists are obliged to be perpetually ‘innovative’ in order to survive in the art market.
<G-vec00060-001-s322><comment.kommentieren><de> Die Installation kommentiert ironisch auch die moderne Kunstszene: Kuratoren, Kunstkritiker, Galeriebesitzer und Sammler hetzen ständig dem Neuen hinterher und auch Künstler müssen ununterbrochen ‚innovativ‘ sein, um auf dem Kunstmarkt bestehen zu können.
<G-vec00060-001-s323><comment.kommentieren><en> The author is unknown, I prefer to believe, It was some guy who has seen something that he liked it and it was around to comment.
<G-vec00060-001-s323><comment.kommentieren><de> Sein Autor ist unbekannt ich es vorziehen, zu glauben,, dass einige Personen, die es etwas, was er mochte und kommentiert aus gesehen hat.
<G-vec00060-001-s324><comment.kommentieren><en> That Microsoft is highlighted as a positive example for the use of patents doesnīt need further comment in the times of the antitrust trial.
<G-vec00060-001-s324><comment.kommentieren><de> Daß die Firma Microsoft als leuchtendes Positivbeispiel für den Sinn von Patenten angeführt wird, muss in diesem Zusammenhang angesichts des Prozesses wegen Monopolbildung nicht mehr kommentiert werden.
<G-vec00060-001-s325><comment.kommentieren><en> """Many of our proposals have been taken over into the Regulation"", was one comment by BfR President, Professor Dr. Dr. Andreas Hensel on the new legislation."
<G-vec00060-001-s325><comment.kommentieren><de> """Viele unserer Vorschläge sind in die Verordnung eingeflossen"", kommentiert der Präsident des BfR, Professor Dr. Dr. Andreas Hensel, das neue Gesetz."
<G-vec00060-001-s326><comment.kommentieren><en> "In this performance he will comment and expand Jandl’s ""unique"" voice from tape recordings, actually being an instrument in itself, with trombone and piano as well as with vocals, electronics and toys to a thrilling intelligent, moving-witty acoustic dialogue: a sounding roller coaster through Ernst Jandl’s tongue-in-cheek meaningful sound worlds."
<G-vec00060-001-s326><comment.kommentieren><de> "In dieser Performance kommentiert und erweitert er Jandls ""unvelwechserbare"", vom Band kommende Stimme, die ja schon für sich genommen ein Musikinstrument darstellt, mit der Posaune und am Klavier sowie mit Vocals, Electronics und Toys zu einem aufregend intelligenten, bewegend-witzigen akustischen Dialog: eine klingende Berg- und Talfahrt durch Ernst Jandls augenzwinkernd-tiefsinnige Hörwelten."
<G-vec00060-001-s327><comment.kommentieren><en> For their applications, the new jury members had to write a review of Michael Haneke's film Das weiße Band, comment on the role of German cinema In the international context, and talk about both their own personal preferences in film and their cultural commitments.
<G-vec00060-001-s327><comment.kommentieren><de> Zur Bewerbung gehörte das Verfassen einer Filmkritik zum Film Das weiße Band von Michael Haneke, die Rolle des deutschen Films auf internationaler Ebene musste kommentiert, persönliche Filmvorlieben und kulturelles Engagement erläutert werden.
<G-vec00060-001-s362><comment.nehmen><en> For example, would She comment on and take sides between competing Church groups, one could easily suspect that the messages were being influenced by an interested party.
<G-vec00060-001-s362><comment.nehmen><de> Würde sie zwischen konkurrierenden kirchlichen Gruppen parteilich Stellung nehmen, käme außerdem leicht der Verdacht auf, dass die Botschaften von interessierter Seite beeinflusst wären.
<G-vec00060-001-s363><comment.nehmen><en> I will not comment on (2).
<G-vec00060-001-s363><comment.nehmen><de> Zu (2) nehme ich nicht Stellung.
<G-vec00060-001-s364><comment.nehmen><en> 2 The higher education institution or other institution within the higher education sector shall comment on the report of the group of experts and of the accreditation agency's accreditation proposal.
<G-vec00060-001-s364><comment.nehmen><de> 2 Die Hochschule oder die andere Institution des Hochschulbereichs nimmt zum Bericht der Gutachtergruppe und zum Akkreditierungsantrag der Akkreditierungsagentur Stellung.
<G-vec00060-001-s365><comment.nehmen><en> "What he didn't comment on was the fact that in the case of the ""promotion"" of technicians to specialists, BAT has ""declared"" that these would be management positions (no law obliges them to do so)."
<G-vec00060-001-s365><comment.nehmen><de> "Keine Stellung nahm er ferner dazu, dass BAT im Fall der ""Beförderung"" von Technikern zu Spezialisten ""erklärte"", dies seien nunmehr Managementpositionen (zu einer solchen Erklärung ist das Unternehmen durch kein Gesetz verpflichtet)."
<G-vec00060-001-s366><comment.nehmen><en> The respondent (patent proprietor) did not comment on the request for remittal to the department of first instance.
<G-vec00060-001-s366><comment.nehmen><de> Der Beschwerdegegner (Patentinhaber) hat zu dem Antrag der Zurückverweisung an die erste Instanz nicht Stellung genommen.
<G-vec00060-001-s367><comment.nehmen><en> As regards Claim 5, the appellant asserts that, in the only communication sent, the examiner failed to comment on that claim, an omission which is contrary to Article 96(2) and Rule 51(3) EPC and which also justifies reimbursement of the appeal fee.
<G-vec00060-001-s367><comment.nehmen><de> Sie behauptet ferner, der Prüfer habe im ersten und einzigen Bescheid entgegen Artikel 96(2) und Regel 51(3) EPÜ nicht zum Gegenstand des Anspruchs 5 Stellung genommen, was ebenfalls die Rückzahlung der Beschwerdegebühr rechtfertige.
<G-vec00060-001-s368><comment.nehmen><en> They do not comment on the formal aspects of a particular discipline but only on the way it functions and on esthetic value judgements.
<G-vec00060-001-s368><comment.nehmen><de> Sie nehmen nicht zu den formalen Aspekten einer bestimmten Disziplin Stellung, sondern nur zu deren Funktionsweise sowie zu ästhetischen Werturteilen.
<G-vec00060-001-s369><comment.nehmen><en> A decision to maintain the patent in amended form may be delivered only when the patent proprietor has approved the new text on the basis of which the opposition division intends to maintain the patent and the opponent has had sufficient opportunity to comment on the proposed new text.
<G-vec00060-001-s369><comment.nehmen><de> Die Entscheidung über die Aufrechterhaltung des Patents in geändertem Umfang darf erst ergehen, wenn das Einverständnis des Patentinhabers zu der neuen Fassung vorliegt, auf deren Grundlage die Einspruchsabteilung das Patent aufrechtzuerhalten beabsichtigt, und der Einsprechende in angemessener Weise Gelegenheit gehabt hat, zu dieser Fassung Stellung zu nehmen.
<G-vec00060-001-s370><comment.nehmen><en> Speaking at various occasions, members of the Bundesbank's Executive Board, including Deputy President Claudia M Buch, regularly comment on issues relating to the financial and monetary system.
<G-vec00060-001-s370><comment.nehmen><de> Mitglieder des Vorstandes der Bundesbank, darunter Vizepräsidentin Claudia M. Buch, nehmen bei verschiedenen Anlässen regelmäßig Stellung zu Fragestellungen des Finanz- und Währungssystems.
<G-vec00060-001-s371><comment.nehmen><en> In this series, I will comment on the written feedback I received after my presentation. Also, I will answer the online questions asked by students I had no time to amply reply to during said presentation
<G-vec00060-001-s371><comment.nehmen><de> In dieser Artikelserie nehme ich Stellung zum schriftlichen Feedback, welches mich nach dem Vortrag erreicht hat und beantworte die von Studenten gestellten Online-Fragen, die ich in meinem Vortrag nicht ausführlich behandeln konnte.
<G-vec00060-001-s372><comment.nehmen><en> names and addresses of specialist colleagues in Germany who are able to comment on the application.
<G-vec00060-001-s372><comment.nehmen><de> Namen und Adressen von Fachkollegen in Deutschland, die zum Antrag Stellung nehmen können.
<G-vec00060-001-s373><comment.nehmen><en> 4.2 All observations meeting the formal requirements will be considered by the examining or opposition division, which will then comment on their relevance in its next substantive communication to the parties to the proceedings.
<G-vec00060-001-s373><comment.nehmen><de> 4.2 Die Prüfungs- oder Einspruchsabteilung prüft alle Einwendungen, die die Formerfordernisse erfüllen, und nimmt im nächsten sachlichen Prüfungsbescheid an die Verfahrensbeteiligten zu deren Relevanz Stellung.
<G-vec00060-001-s374><comment.nehmen><en> I will gladly comment on your concern from a physiotherapist’s perspective.
<G-vec00060-001-s374><comment.nehmen><de> gerne nehme ich aus physiotherapeutischer Sicht Stellung zu Ihrem Anliegen.
<G-vec00060-001-s375><comment.nehmen><en> In CooperationIn the Democracy Lectures, prominent intellectuals comment on key issues and challenges of our time.
<G-vec00060-001-s375><comment.nehmen><de> In KooperationIn den Democracy Lectures nehmen herausragende Intellektuelle Stellung zu zentralen Fragen und Herausforderungen der heutigen Zeit.
<G-vec00060-001-s376><comment.nehmen><en> "What he didn't comment on was the fact that in the case of the ""promotion"" of the sales staff, the company sought and claims to have obtained from the Director General of Industrial Relations special authorisation to change the status of sales staff from employee to management."
<G-vec00060-001-s376><comment.nehmen><de> "Und schließlich nahm er keine Stellung dazu, dass im Fall der ""Beförderung"" des Verkaufspersonals das Unternehmen vom Generaldirektor für Arbeitsbeziehungen die Sondergenehmigung beantragt und angeblich auch erhalten hat, den Status dieses Personals in Managementpersonal zu ändern."
<G-vec00060-001-s377><comment.nehmen><en> 3.2 For all applications it is an important principle under the EPC that the question whether or not an application complies with the substantive requirements of the EPC is to be decided on the text finally submitted or agreed by the applicant after any objections have been drawn to his attention and he has been afforded an opportunity to comment and also an opportunity to overcome the objection by means of an amendment.
<G-vec00060-001-s377><comment.nehmen><de> 3.2 Für alle Anmeldungen gilt nach dem EPÜ als wichtiger Grundsatz, dass die Frage, ob eine Anmeldung die materiellrechtlichen Erfordernisse des EPÜ erfüllt, anhand der Fassung zu entscheiden ist, die der Anmelder abschließend vorgelegt oder gebilligt hat, nachdem ihm Einwände zur Kenntnis gebracht wurden und er Gelegenheit hatte, dazu Stellung zu nehmen und die Einwände gegebenenfalls durch Änderungen auszuräumen.
<G-vec00060-001-s378><comment.nehmen><en> In case you have any questions, feel free to comment below so that we can help you get rid of the A-Secure 2015 malware. How to remove A-Secure 2015
<G-vec00060-001-s378><comment.nehmen><de> Falls Sie irgendwelche Fragen haben, zögern Sie nicht, unten Stellung zu nehmen, so dass loswerden können wir Ihnen die A-Secure 2015 Malware.
<G-vec00060-001-s379><comment.nehmen><en> Oral proceedings, on the other hand, generally afford the parties an adequate opportunity to comment on a proposal to maintain the European patent in the amended form.
<G-vec00060-001-s379><comment.nehmen><de> In einem Verfahren mit mündlicher Verhandlung besteht dagegen diese unabweisbare Notwendigkeit nicht generell, da die Parteien in der mündlichen Verhandlung ausreichend Gelegen heit haben, zu einem Vorschlag der Aufrechterhaltung des europäischen Patents in geändertem Umfang Stellung zu nehmen.
<G-vec00060-001-s380><comment.nehmen><en> Thus the appellant had been surprised by the board's new line of argument on inventive step in its written decision, on which it had not had an opportunity to comment.
<G-vec00060-001-s380><comment.nehmen><de> Der Beschwerdeführer wurde von der Argumentation in der Entscheidung überrascht und konnte zu dieser neuen Argumentation der Beschwerdekammer zur erfinderischen Tätigkeit nicht Stellung nehmen.
<G-vec00060-001-s381><comment.nehmen><en> Additionally, the Company undertakes no obligation to comment on the expectations of, or statements made by, third parties in respect of the matters discussed above.
<G-vec00060-001-s381><comment.nehmen><de> Darüber hinaus ist das Unternehmen nicht verpflichtet, zu den Erwartungen oder Aussagen Dritter in Bezug auf die oben genannten Sachverhalte Stellung zu nehmen.
<G-vec00060-001-s382><comment.nehmen><en> If the request for examination has been filed before the European search report has been transmitted to the applicant, the European Patent Office shall invite the applicant to indicate, within a period to be specified, whether he wishes to proceed further with the application, and shall give him the opportunity to comment on the search report and to amend, where appropriate, the description, claims and drawings.
<G-vec00060-001-s382><comment.nehmen><de> Wird der Prüfungsantrag gestellt, bevor dem Anmelder der europäische Recherchenbericht übermittelt worden ist, so fordert das Europäische Patentamt den Anmelder auf, innerhalb einer zu bestimmenden Frist zu erklären, ob er die Anmeldung aufrechterhält, und gibt ihm Gelegenheit, zu dem Recherchenbericht Stellung zu nehmen und gegebenenfalls die Beschreibung, die Patentansprüche und die Zeichnungen zu ändern.
<G-vec00060-001-s383><comment.nehmen><en> A decision to maintain the patent in amended form may be delivered only when the patent proprietor has approved the text in which the Opposition Division proposes to maintain the patent and the opponent has had sufficient opportunity to comment on the proposed new text.
<G-vec00060-001-s383><comment.nehmen><de> Die Entscheidung über die Aufrechterhaltung des Patents in geändertem Umfang darf erst ergehen, wenn das Einverständnis des Patentinhabers zu der Fassung vorliegt, in der die Einspruchsabteilung das Patent aufrechtzuerhalten beabsichtigt, und der Einsprechende in angemessener Weise Gelegenheit gehabt hat, zu dieser Fassung Stellung zu nehmen.
<G-vec00060-001-s384><comment.nehmen><en> The fact that the Appellant was given no opportunity to comment on these rejecting arguments also constituted a substantial procedural violation.
<G-vec00060-001-s384><comment.nehmen><de> Auch die Tatsache, daß die Beschwerdeführerin keine Gelegenheit gehabt habe, zu diesen ablehnenden Äußerungen Stellung zu nehmen, stelle einen wesentlichen Verfahrensmangel dar.
<G-vec00060-001-s385><comment.nehmen><en> If the request does not seem obviously inadmissible or unfounded, the court shall give the opposing party the opportunity to comment orally or in writing.
<G-vec00060-001-s385><comment.nehmen><de> Erscheint das Gesuch nicht offensichtlich unzulässig oder offensichtlich unbegründet, so gibt das Gericht der Gegenpartei Gelegenheit, mündlich oder schriftlich Stellung zu nehmen.
<G-vec00060-001-s386><comment.nehmen><en> Consequently, it was under no obligation to comment on the patentability of claims 1 to 6.
<G-vec00060-001-s386><comment.nehmen><de> Die Prüfungsabteilung war mithin nicht verpflichtet, zur Patentierbarkeit der Ansprüche 1 bis 6 Stellung zu nehmen.
<G-vec00060-001-s387><comment.nehmen><en> In this consultative document the Group invites all parties interested in and concerned with company law in Europe to comment on the issues specified in the mandate of the Group.
<G-vec00060-001-s387><comment.nehmen><de> Im vorliegenden Konsultationspapier lädt die Gruppe alle am europäischen Gesellschaftsrecht Interessierten und vom europäischen Gesellschaftsrecht Betroffenen ein, zu den in ihrem Mandat genannten Themenkreisen Stellung zu nehmen.
<G-vec00060-001-s388><comment.nehmen><en> Anyone can comment on a proposal to restrict a substance.
<G-vec00060-001-s388><comment.nehmen><de> Jeder kann zu einem Vorschlag zur Beschränkung eines Stoffs Stellung zu nehmen.
<G-vec00060-001-s389><comment.nehmen><en> 6.1 The applicant may comment in writing on the reply to the request within two weeks after its receipt.
<G-vec00060-001-s389><comment.nehmen><de> 6.1 Der Antragsteller kann innerhalb von zwei Wochen nach Empfang der Antragserwiderung schriftlich Stellung nehmen.
<G-vec00060-001-s390><comment.nehmen><en> Consequently, the Board feels obliged to comment on this case.
<G-vec00060-001-s390><comment.nehmen><de> Infolgedessen sieht sich die Kammer veranlaßt, zu diesem Fall Stellung zu nehmen.
<G-vec00060-001-s391><comment.nehmen><en> The high-quality examination practice of the EPO, together with the rights of third parties to comment on and challenge the Office's decisions, ensures that only those applications which meet the requirements of the EPC are granted.
<G-vec00060-001-s391><comment.nehmen><de> Die qualitativ hochwertige Prüfungspraxis des EPA - ergänzt durch das Recht Dritter, zu den Entscheidungen Stellung zu nehmen oder sie anzufechten - gewährleistet, dass Patente nur auf Anmeldungen erteilt werden, die den Erfordernissen des EPÜ genügen.
<G-vec00060-001-s392><comment.nehmen><en> """We welcome the fact that BaFin is now taking action - "" because, despite repeated written requests by the STP, the ""Deutsche Bank"" was not prepared to comment on the allegations"", said the STP's expert on questions regarding Asia, Ulrich Delius, on Monday."
<G-vec00060-001-s392><comment.nehmen><de> """Wir begrüßen es, dass die BaFin nun aktiv geworden ist, denn trotz mehrmaliger schriftlicher Anfragen war die Deutsche Bank gegenüber der GfbV nicht bereit, zu den Anschuldigungen Stellung zu nehmen"", sagte der GfbV-Asienreferent Ulrich Delius am Montag."
<G-vec00060-001-s393><comment.nehmen><en> The EU Youth Dialogue aims to enable young people from different backgrounds to comment on political decisions at EU level.
<G-vec00060-001-s393><comment.nehmen><de> Über den EU-Jugenddialog sollen junge Menschen mit unterschiedlichem Hintergrund zu politischen Entscheidungen auf EU-Ebene Stellung nehmen können.
<G-vec00060-001-s394><comment.nehmen><en> Opponents have to be given sufficient time to analyse, comment on and/or object to these documents.
<G-vec00060-001-s394><comment.nehmen><de> Den Einsprechenden ist ausreichend Zeit einzuräumen, um diese Unterlagen zu analysieren, Stellung zu nehmen und/oder Einwendungen zu erheben.
<G-vec00060-001-s395><comment.nehmen><en> The social aspect is also carried through into the manual trading functions, with each financial instrument offering the ability for users to comment, or view and respond to comments from others.
<G-vec00060-001-s395><comment.nehmen><de> Der soziale Aspekt wird auch durch in die manuelle Handelsfunktionen, mit jedem Finanzinstrument bietet Benutzern die Möglichkeit, Stellung zu nehmen, oder sehen und reagieren auf die Kommentare von anderen getragen.
<G-vec00060-001-s396><comment.nehmen><en> 10.1 The applicant may comment in writing on the reply to the request within three weeks after its receipt.
<G-vec00060-001-s396><comment.nehmen><de> 10.1 Der Antragsteller kann innerhalb von drei Wochen nach Empfang der Antragserwiderung schriftlich dazu Stellung nehmen.
<G-vec00060-001-s397><comment.nehmen><en> The WG draws up a committee draft (CD), which the national standards bodies have to comment on within three months.
<G-vec00060-001-s397><comment.nehmen><de> Die WG erarbeitet einen Entwurf (CD), zu dem die nationalen Normungsorganisationen innerhalb von drei Monaten Stellung nehmen müssen.
<G-vec00060-001-s417><comment.sich_äußern><en> The Enlarged Board stated that discrepancies between a board's provisional opinion as expressed in a communication preparing oral proceedings and its analysis in its final decision did not constitute a fundamental procedural defect in the absence of other verifiable circumstances showing that it was impossible for the parties to comment on the points mentioned as requiring discussion.
<G-vec00060-001-s417><comment.sich_äußern><de> Die Große Beschwerdekammer stellte fest, dass kein schwerwiegender Verfahrensmangel vorliegt, wenn es zwischen einer vorläufigen Auffassung, die in einem Bescheid zur Vorbereitung einer mündlichen Verhandlung vor einer Beschwerdekammer zum Ausdruck gebracht wird, und der endgültigen, in der Entscheidung der Beschwerdekammer festgehaltenen Analyse Abweichungen gibt, sofern nicht andere Umstände überprüft werden, denen zufolge die Verfahrensbeteiligten nicht in der Lage waren, sich zu den Punkten zu äußern, die als Gegenstand der Debatte angekündigt waren.
<G-vec00060-001-s418><comment.sich_äußern><en> It is sufficient if the parties have been given the opportunity to comment on the material issues of relevance, for example, to the material passage of a citation.
<G-vec00060-001-s418><comment.sich_äußern><de> Es genügt, wenn die Parteien die Gelegenheit erhalten haben, sich zu den entscheidungserheblichen Gesichtspunkten zu äußern, zum Beispiel zu einer entscheidungserheblichen Passage einer Entgegenhaltung.
<G-vec00060-001-s419><comment.sich_äußern><en> It is unable to comment on the specific allegations against those arrested, or on the ongoing proceedings.
<G-vec00060-001-s419><comment.sich_äußern><de> Er kann sich zu den konkreten Vorwürfen gegenüber den verhafteten Personen und zum laufenden Verfahren nicht weiter äußern.
<G-vec00060-001-s420><comment.sich_äußern><en> The Alliance does not want to comment on this request.
<G-vec00060-001-s420><comment.sich_äußern><de> Dazu äußern will sich das Bündnis auf Anfrage nicht.
<G-vec00060-001-s421><comment.sich_äußern><en> 3 Â It shall give any private claimant the opportunity to comment on the application made by the public prosecutor and on his or her civil claim.
<G-vec00060-001-s421><comment.sich_äußern><de> 3 Es gibt der Privatklägerschaft Gelegenheit, sich zum Antrag der Staatsanwaltschaft und zu ihrer Zivilklage zu äußern.
<G-vec00060-001-s422><comment.sich_äußern><en> First Global undertakes no obligation to comment on analyses, expectations or statements made by third-parties in respect of First Global, its securities, or financial or operating results (as applicable).
<G-vec00060-001-s422><comment.sich_äußern><de> First Global ist nicht verpflichtet, sich zu den Analysen, Erwartungen oder Aussagen Dritter in Bezug auf First Global, seine Wertpapiere oder gegebenenfalls Finanz- oder Betriebsergebnisse zu äußern.
<G-vec00060-001-s423><comment.sich_äußern><en> Monsanto was asked to comment on its nomination for an Angry Mermaid Award but did not respond.
<G-vec00060-001-s423><comment.sich_äußern><de> Monsanto wurde gebeten, sich zur Nominierung zum Angry Mermaid Award zu äußern, antwortete aber nicht.
<G-vec00060-001-s424><comment.sich_äußern><en> It feels premature, even misplaced to comment on whether McQueen’s feature films complement his artistic work or stand entirely apart from them.
<G-vec00060-001-s424><comment.sich_äußern><de> Es ist verfrüht, sogar unangebracht, sich zu der Frage zu äußern, ob McQueens Spielfilme seine künstlerische Arbeit ergänzen oder vollkommen losgelöst von ihr zu betrachten sind.
<G-vec00060-001-s425><comment.sich_äußern><en> On the contrary, oral proceedings enjoyed the same status as written proceedings and were intended to allow the parties concerned to comment on all aspects of a case.
<G-vec00060-001-s425><comment.sich_äußern><de> Vielmehr solle die mündliche Verhandlung genauso wie das schriftliche Verfahren den Beteiligten die Möglichkeit geben, sich zu allen Streitpunkten zu äußern.
<G-vec00060-001-s426><comment.sich_äußern><en> I know this blog right now and not repress me to comment on it.
<G-vec00060-001-s426><comment.sich_äußern><de> Ich weiß, dieses Blog schon jetzt und nicht unterdrücken mich dazu zu äußern.
<G-vec00060-001-s427><comment.sich_äußern><en> Further, the parties were invited to comment on the possibility of remittal to the first instance since the subject-matter of independent claim 8 had not been examined by the Opposition Division. VI.
<G-vec00060-001-s427><comment.sich_äußern><de> Außerdem forderte sie die Beteiligten auf, sich zur Möglichkeit einer Zurückverweisung an die erste Instanz zu äußern, weil der Gegenstand des unabhängigen Anspruchs 8 von der Einspruchsabteilung nicht geprüft worden sei.
<G-vec00060-001-s428><comment.sich_äußern><en> In point 6 of the same decision, the Enlarged Board explicitly declined to comment on the exclusion of essentially biological processes.
<G-vec00060-001-s428><comment.sich_äußern><de> Unter Nummer 6 der Entscheidung habe die Große Kammer sogar ausdrücklich davon Abstand genommen, sich zum Patentierbarkeitsausschluss von im Wesentlichen biologischen Verfahren zu äußern.
<G-vec00060-001-s429><comment.sich_äußern><en> In a statement to the criticism of the Vatican Secretariat of State and of the president of the US Conference of Catholic Bishops (USCCB) has been explicitly stated that Amnesty International does not endorse a general right to abortion, nor wanted the organization to comment on the question of whether abortions are ethically justifiable or not.
<G-vec00060-001-s429><comment.sich_äußern><de> In einer Erklärung auf die Kritiken des Vatikanischen Staatssekretariats und des Präsidenten der US-Amerikanischen Bischofskoferenz (USCCB) wurde ausdrücklich festgehalten, Amnesty International befürworte weder ein allgemeines Recht auf Abtreibung noch wolle sich die Organisation zur Frage äußern, ob Abtreibungen ethisch vertretbar seien oder nicht.
<G-vec00060-001-s430><comment.sich_äußern><en> The Board may, on its own initiative or at the written, reasoned request of the President of the European Patent Office, invite him to comment in writing or orally on questions of general interest which arise in the course of proceedings pending before it.
<G-vec00060-001-s430><comment.sich_äußern><de> Die Kammer kann den Präsidenten des Europäischen Patentamts von Amts wegen oder auf dessen schriftlichen, begründeten Antrag auffordern, sich zu Fragen von allgemeinem Interesse, die sich im Rahmen eines vor der Kammer anhängigen Verfahrens stellen, schriftlich oder mündlich zu äußern.
<G-vec00060-001-s431><comment.sich_äußern><en> 113 EPC 1973 by changing its provisional opinion after the oral proceedings without giving the appellants an opportunity to comment on the grounds, which had not been stated before, on which the contested decision was based.
<G-vec00060-001-s431><comment.sich_äußern><de> 113 EPÜ 1973 verstoßen hatte, als sie ihre vorläufige Meinung nach der mündlichen Verhandlung änderte, ohne dass er sich zu den Gründen, auf die sich erst die angefochtene Entscheidung stützte, äußern konnte.
<G-vec00060-001-s432><comment.sich_äußern><en> These are issues of discrimination, racialism, minorities and identity, which she finds she has an urge and responsibility to comment on in her art works.
<G-vec00060-001-s432><comment.sich_äußern><de> Es sind Themen wie Diskriminierung, Rassismus, Minderheiten und Identität, bei denen sie das Verlangen und die Verantwortung empfindet, sich in ihren Werken dazu zu äußern.
<G-vec00060-001-s433><comment.sich_äußern><en> It's usually experts who comment on pregnancy, birth, parenthood.
<G-vec00060-001-s433><comment.sich_äußern><de> Über Schwangerschaft, Geburt und Elternsein äußern sich in der Regel Fachleute.
<G-vec00060-001-s434><comment.sich_äußern><en> Regarding the procedure to be followed for applying jurisdictional measures in response to requests as described by the Legal Board, the question arises of whether all the EPC rules governing normal proceedings before the boards of appeal must be applied; this concerns in particular the right of other parties to comment on the requests, the observation of minimum time limits or the right to request oral proceedings.
<G-vec00060-001-s434><comment.sich_äußern><de> Was das Verfahren für die gerichtliche Behandlung von Anträgen der von der Juristischen Beschwerdekammer umschriebenen Art betrifft, stellt sich die Frage, ob dabei alle auf die ordnungsgemäßen Verfahren vor den Beschwerdekammern anwendbaren Regeln des EPÜ, insbesondere solche, die das Recht der anderen Beteiligten, sich zu den Anträgen zu äußern, die Einhaltung der Mindestfristen oder auch das Recht auf eine mündliche Verhandlung betreffen, angewendet werden müssen.
<G-vec00060-001-s435><comment.sich_äußern><en> The version of the list published in December has been object of a hearing; however, drugs have been removed from the list afterwards, a fact on which the companies concerned were not able to comment.
<G-vec00060-001-s435><comment.sich_äußern><de> Die im Dezember veröffentlichte Version der Liste sei Gegenstand einer Anhörung gewesen, doch seien danach noch Arzneimittel von der Liste entfernt worden, zu denen sich die betroffenen Firmen nicht mehr hätten äußern können.
<G-vec00161-002-s070><comment.abgeben><en> For clear anodized rails enter "CA" in the comment.
<G-vec00161-002-s070><comment.abgeben><de> Für klar eloxierte Schienen geben Sie bitte "CA" in der Bemerkung an.
<G-vec00161-002-s071><comment.abgeben><en> Catch a woman's eye while commuting home on public transportation and make an amusing comment about something relevant, then introduce yourself.
<G-vec00161-002-s071><comment.abgeben><de> Mache eine Frau während der Heimfahrt in öffentlichen Verkehrsmitteln auf dich aufmerksam, indem du eine lustige Bemerkung über etwas Relevantes machst und dich dann vorstellst.
<G-vec00161-002-s072><comment.abgeben><en> The query or comment about which you would like us to contact you.
<G-vec00161-002-s072><comment.abgeben><de> Die Frage oder Bemerkung, bezüglich derer Sie Kontakt mit uns aufnehmen möchten.
<G-vec00161-002-s073><comment.abgeben><en> "We struggled with several names, but somebody made the comment to me that my parents gave me a beautiful name.
<G-vec00161-002-s073><comment.abgeben><de> "Wir dachten über einige Namen nach, aber irgendjemand ließ mir gegenüber die Bemerkung fallen, dass meine Eltern mir einen schönen Namen gegeben haben.
<G-vec00161-002-s074><comment.abgeben><en> Simply post your question or comment, and we’ll respond as quickly as possible.
<G-vec00161-002-s074><comment.abgeben><de> Posten Sie eine Frage oder Bemerkung - wir antworten rasch.
<G-vec00161-002-s075><comment.abgeben><en> Furthermore, your customer can write a comment in notes and choose the delivery method when ordering. Your customer can choose between pick up or delivery.
<G-vec00161-002-s075><comment.abgeben><de> Weiterhin kann Ihr Kunde eine Bemerkung schreiben und bei der Bestellung Abholung/Lieferung wählen (kann auch deaktiviert werden).
<G-vec00161-002-s076><comment.abgeben><en> The name Led Zeppelin only occurred to them later after a derogatory comment by fellow musicians.
<G-vec00161-002-s076><comment.abgeben><de> Der Name Led Zeppelin fiel ihnen erst später ein, nach einer abfälligen Bemerkung eines Musiker-Kollegen.
<G-vec00161-002-s077><comment.abgeben><en> And when someone does speak, then it’s often as a catcall on the street, as a comment at work, always following the lines of the patriarchy from top to bottom.
<G-vec00161-002-s077><comment.abgeben><de> Und wenn gesprochen wird, dann oft als Zuruf auf der Straße, als Bemerkung auf der Arbeit, stets den Linien des Patriarchats von oben nach unten folgend.
<G-vec00161-002-s078><comment.abgeben><en> Polly Angell recalled a comment by Joseph Smith as he saw them working. He said: “The sisters are always first and foremost in all good works.
<G-vec00161-002-s078><comment.abgeben><de> Polly Angell erinnerte sich an eine Bemerkung von Joseph Smith, der sagte, als er sie arbeiten sah: „Die Schwestern sind immer die Ersten und allen voran bei allen guten Werken.
<G-vec00161-002-s079><comment.abgeben><en> In the illustration of the “Faithful and Discreet Slave” it is interesting to note the comment made in Luke 12: 43-45; “Happy is THAT slave, if his master on arriving finds him doing so!
<G-vec00161-002-s079><comment.abgeben><de> n der Veranschaulichung vom „treuen und verständigen Sklaven“ ist es interessant, auf die Bemerkung in Lukas 12:43-45 zu achten: „Glücklich ist JENER Sklave, wenn ihn sein Herr bei der Ankunft so tuend findet.
<G-vec00161-002-s080><comment.abgeben><en> Sound Port x, the frequency and duration calculations can be found in the listing as a comment.
<G-vec00161-002-s080><comment.abgeben><de> Sound Port x, Tonhöhe, Tonlänge Die Berechnung steht im Listing als Bemerkung.
<G-vec00161-002-s081><comment.abgeben><en> But it was only the manufacturer's comment that made K. realise what dangers that could lead to.
<G-vec00161-002-s081><comment.abgeben><de> Die Gefahren aber, die das zur Folge haben könnte, hatte er erst durch die Bemerkung des Fabrikanten erkannt.
<G-vec00161-002-s082><comment.abgeben><en> This inversion of the old military sense of honor is echoed in the Buddha’s comment that better than victory in battle over a thousand-thousand men is victory over one person: yourself.
<G-vec00161-002-s082><comment.abgeben><de> Diese Umkehr des alten millitärischen Sinn für Ehre, wird in Buddhas Bemerkung wiedergegeben, daß besser als der Sieg im Kampf gegenüber abertausende Männer, dee Sieg über eine einzelne Person ist: sich selbst.
<G-vec00161-002-s083><comment.abgeben><en> A comment can be entered.
<G-vec00161-002-s083><comment.abgeben><de> Es kann eine Bemerkung eingegeben werden.
<G-vec00161-002-s084><comment.abgeben><en> Main negative comment is that mattress on bed in need of replacement.
<G-vec00161-002-s084><comment.abgeben><de> Main negative Bemerkung ist, dass Matratze auf dem Bett ersetzt werden muss.
<G-vec00161-002-s085><comment.abgeben><en> The odd smile and the comment of, “Where will I put these up?” Not as complaint but just as rueful admission from a man whose interiors were full of shelves holding books in four or five languages.
<G-vec00161-002-s085><comment.abgeben><de> Dazu das schiefe Lächeln und die fragende Bemerkung: „Wo hänge ich die nur hin?“ Nicht als Klage gemeint, sondern als reumütiges Eingeständnis eines Mannes, in dessen Wohnung überall Regale bis obenhin mit Büchern in vier oder fünf Sprachen gefüllt waren.
<G-vec00161-002-s086><comment.abgeben><en> Comment: To detect this case a appropriate and efficient detection-strategy must be elaborated
<G-vec00161-002-s086><comment.abgeben><de> Bemerkung: Für die Erkennung dieses Falles muss noch eine geeignete und effiziente Erkennungsstrategie ausgearbeitet werden.
<G-vec00161-002-s087><comment.abgeben><en> The most important comment is as follows:
<G-vec00161-002-s087><comment.abgeben><de> Die grundsätzlichste Bemerkung ist wie folgt.
<G-vec00161-002-s088><comment.abgeben><en> replied to that last comment merely by embracing Leni and drawing her towards him, she lay her head quietly on his shoulder.
<G-vec00161-002-s088><comment.abgeben><de> K. Auf die letzte Bemerkung antwortete K. nur damit, daß er Leni umfaßte und an sich zog, sie lehnte still den Kopf an seine Schulter.
<G-vec00161-002-s144><comment.abgeben><en> A rep for Ben Stiller was not immediately available for comment.
<G-vec00161-002-s144><comment.abgeben><de> Ein Sprecher von Ben Stiller stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s145><comment.abgeben><en> A rep for Alain Souchon was not immediately available for comment.
<G-vec00161-002-s145><comment.abgeben><de> Ein Sprecher von Pedro Almodóvar stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s146><comment.abgeben><en> We didn’t get one Like or comment.
<G-vec00161-002-s146><comment.abgeben><de> Weder ein Like noch ein Kommentar.
<G-vec00161-002-s147><comment.abgeben><en> A rep for Hozier was not immediately available for comment.
<G-vec00161-002-s147><comment.abgeben><de> Ein Sprecher von Quincy Jones stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s148><comment.abgeben><en> A rep for Alexandre Jardin was not immediately available for comment.
<G-vec00161-002-s148><comment.abgeben><de> Ein Sprecher von Alexandre Jardin stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s149><comment.abgeben><en> A rep for Harry Lennix was not immediately available for comment.
<G-vec00161-002-s149><comment.abgeben><de> Ein Sprecher von Harry Lennix stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s150><comment.abgeben><en> A rep for Jan Smithers was not immediately available for comment.
<G-vec00161-002-s150><comment.abgeben><de> Ein Sprecher von Cristine Reyes stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s151><comment.abgeben><en> A rep for Agnès Jaoui was not immediately available for comment.
<G-vec00161-002-s151><comment.abgeben><de> Ein Sprecher von Agnès Jaoui stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s152><comment.abgeben><en> A rep for Claire Chazal was not immediately available for comment.
<G-vec00161-002-s152><comment.abgeben><de> Ein Sprecher von Malgosia Bela stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s153><comment.abgeben><en> A rep for Eric Clapton was not immediately available for comment.
<G-vec00161-002-s153><comment.abgeben><de> Ein Sprecher von Alain Souchon stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s154><comment.abgeben><en> A rep for Ben Shapiro was not immediately available for comment.
<G-vec00161-002-s154><comment.abgeben><de> Ein Sprecher von Ben Shapiro stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s156><comment.abgeben><en> Before you submit a questions or comment, please consider the following: If you have a medical emergency, contact your local doctor, or your local Accident & Emergency room.
<G-vec00161-002-s156><comment.abgeben><de> Bitte beachten Sie die folgenden Hinweise, bevor Sie eine Frage oder ein Kommentar übermitteln: Bei medizinischen Notfällen kontaktieren Sie bitte den Notdienst oder Ihren Hausarzt.
<G-vec00161-002-s157><comment.abgeben><en> Sorry, no comment on anything, I'm reliving the fond memory of when there were no open racists in the German government.
<G-vec00161-002-s157><comment.abgeben><de> Sorry, kaum ein Kommentar, ich schwelge in Erinnerung an eine Zeit, in der keine offenen Rassisten im Bundestag waren.
<G-vec00161-002-s158><comment.abgeben><en> As a bonus, the author of the original article will appreciate your inbound link to his/her blog and may even comment on your interpretation. Win win.
<G-vec00161-002-s158><comment.abgeben><de> Anschließend freut sich der Verfasser des ursprünglichen Artikels, dass Sie zu seinem Blog verlinken, und vielleicht gibt er auch noch einen Kommentar zu Ihrer Interpretation ab – eine echte Win-Win-Situation.
<G-vec00161-002-s159><comment.abgeben><en> None of the porn spammers could be reached for comment.
<G-vec00161-002-s159><comment.abgeben><de> Keiner der Porno-Spammer war für einen Kommentar zu erreichen.
<G-vec00161-002-s160><comment.abgeben><en> In 1968, when Stanley Kubrick was asked to comment on the metaphysical significance of 2001: A Space Odyssey, he replied: “It’s not a message I ever intended to convey in words. 2001 is a nonverbal experience….
<G-vec00161-002-s160><comment.abgeben><de> Im Jahr 1968, als Stanley Kubrick um einen Kommentar zur metaphysischen Bedeutung des Films 2001: Odyssee im Weltraum gebeten wurde, antwortete er: "Ich wollte die Botschaft des Films niemals in Worte fassen.
<G-vec00161-002-s161><comment.abgeben><en> When you post a comment on our website, you may be agreeing to have your name, email address and website stored in cookies.
<G-vec00161-002-s161><comment.abgeben><de> Wenn Sie einen Kommentar auf unserer Website schreiben, kann das eine Einwilligung sein, Ihren Namen, E-Mail-Adresse und Website in Cookies zu speichern.
<G-vec00161-002-s162><comment.abgeben><en> In our discussions, during which each of my opposite numbers told me how much they appreciated Israel’s liberal democracy, I was asked to comment on the current situation.
<G-vec00161-002-s162><comment.abgeben><de> Im Verlauf der Diskussionen, in denen jeder meiner Gesprächspartner mir beteuerte, wie sehr er die freie Demokratie in Israel schätze, baten sie mich um einen Kommentar zur gegenwärtigen Lage.
<G-vec00161-002-s163><comment.abgeben><en> When you send a tweet, you can get a retweet or comment from a follower and, over time, build trust.
<G-vec00161-002-s163><comment.abgeben><de> Wenn Du einen Tweet versendest, kannst Du einen Retweet oder einen Kommentar von einem Follower erhalten und so mit der Zeit Vertrauen aufbauen.
<G-vec00161-002-s164><comment.abgeben><en> And who wants to sew a sugar-sweet tutu for his little daughter, granddaughter, niece or cousin has to write a comment beneath this post until tomorrow morning 8 CET!
<G-vec00161-002-s164><comment.abgeben><de> Und wer für seine kleine Tochter, Enkeltochter, Nichte oder Cousine ein zuckersüßes Röckchen nähen möchte, der sollte jetzt unter diesem Beitrag schnell bis morgen früh einen Kommentar schreiben und ein weiteres Mal feste die Daumen drücken.
<G-vec00161-002-s165><comment.abgeben><en> Subscribing to Comments On our website, we may offer you the opportunity to subscribe to subsequent comments about an article which you intend to comment on.
<G-vec00161-002-s165><comment.abgeben><de> Wir bieten Ihnen auf unserer Seite die Möglichkeit, nachfolgende Kommentare zu einem Beitrag, zu dem Sie im Begriff sind, einen Kommentar zu verfassen, zu abonnieren.
<G-vec00161-002-s166><comment.abgeben><en> ENGLISH: Only registered users with an OPEN ID can comment every theme. Those who have profiles in Google and Yahoo are registered users by default.
<G-vec00161-002-s166><comment.abgeben><de> DEUTSCH: Nur registrierte Benutzer mit OPEN ID dürfen einen Kommentar schreiben.Alle die bei Google oder Yahoo ein Konto haben, sind automatisch registrierte Benutzer.
<G-vec00161-002-s167><comment.abgeben><en> His photographs do not only document buildings, but comment on them, as it were.
<G-vec00161-002-s167><comment.abgeben><de> Seine Aufnahmen geben über ihren dokumentarischen Wert hinaus gleichsam einen Kommentar über das fotografierte Bauwerk.
<G-vec00161-002-s168><comment.abgeben><en> We could not reach Alejandra for comment.
<G-vec00161-002-s168><comment.abgeben><de> TMZ konnte Alejandra für einen Kommentar nicht erreichen.
<G-vec00161-002-s169><comment.abgeben><en> 8.2 To other users of our service, if you include personal information in a review, post, comment or other public action on our service.
<G-vec00161-002-s169><comment.abgeben><de> 9.2 An andere Nutzer unseres Dienstes, wenn du persönliche Informationen in eine Rezension, einen Beitrag, einen Kommentar oder eine andere öffentliche Aktion zu unserem Dienst einbringst.
<G-vec00161-002-s170><comment.abgeben><en> Share our Twitter, Facebook or Instagram pages and leave a review or comment.
<G-vec00161-002-s170><comment.abgeben><de> Teilen Sie unsere Twitter, Facebook or Instagram Seiten und hinterlassen Sie eine Rezension oder einen Kommentar.
<G-vec00161-002-s171><comment.abgeben><en> Thanks for the comment.
<G-vec00161-002-s171><comment.abgeben><de> Vielen Dank für einen Kommentar.
<G-vec00161-002-s172><comment.abgeben><en> admin comment, just log in and view the post's comments.
<G-vec00161-002-s172><comment.abgeben><de> Um einen Kommentar zu löschen, melden Sie sich an und lassen Sie die Kommentare zum jeweiligen Beitrag anzeigen.
<G-vec00161-002-s173><comment.abgeben><en> Q – Would you care to comment about the specialty entry, especially the dogs who might have racing blood behind them.
<G-vec00161-002-s173><comment.abgeben><de> F: Wärst Du so freundlich und gibst uns einen Kommentar zu den gemeldeten Hunden auf der Specialty, besonders zu den Hunden, die möglicherweise Rennblut tragen.
<G-vec00161-002-s174><comment.abgeben><en> We are pleased to provide an update on the activities at our La Preciosa silver-gold deposit and to comment on expected developments for the upcoming months.
<G-vec00161-002-s174><comment.abgeben><de> Wir freuen uns, ein Update zu den Aktivitäten bei unserer Silber-Gold-Lagerstätte La Preciosa und einen Kommentar zu den zu erwartenden Entwicklungen in den kommenden Monaten zu veröffentlichen.
<G-vec00161-002-s175><comment.abgeben><en> 2nd way: save the publication without hashtags, copy the group of 30 hashtags and insert them into the comment under your post.
<G-vec00161-002-s175><comment.abgeben><de> Variante 2: Speichern Sie den Eintrag ohne Hashtags, kopieren Sie die Gruppe von 30 Hashtags und fügen Sie sie als einen Kommentar unter ihren Eintrag.
<G-vec00161-002-s176><comment.abgeben><en> The German chancellor’s office declined to comment, and while many now believe the photograph’s association with Merkel to be a hoax, there’s plenty of reason to think that Merkel, who grew up in a small East German town north of Berlin, came of age frolicking in the nude.
<G-vec00161-002-s176><comment.abgeben><de> Das Kanzleramt lehnte einen Kommentar ab, und während viele nun glauben, die Verbindung des Bildes zu Merkel sei eine Intrige, gibt es genug Gründe, zu denken, dass Merkel, die in einer ostdeutschen Kleinstadt nördlich von Berlin aufwuchs, habe sich vor Jahren nackt vergnügt.
<G-vec00161-002-s177><comment.abgeben><en> The email address you provide will be saved but will not be published along with your comment.
<G-vec00161-002-s177><comment.abgeben><de> Die angegebene E-Mail-Adresse wird gespeichert, jedoch nicht mit dem Kommentar veröffentlicht.
<G-vec00161-002-s178><comment.abgeben><en> If you have not chosen the anonymous mode, your name and surname will be published along with your comment on our website.
<G-vec00161-002-s178><comment.abgeben><de> Wenn Sie keine anonyme Anzeige ausgewählt haben, werden Ihr Vor- und Nachname mit Ihrem Kommentar auf unserer Website veröffentlicht.
<G-vec00161-002-s179><comment.abgeben><en> PinkSaint placed a comment in the guestbook.
<G-vec00161-002-s179><comment.abgeben><de> JoshDun hat einen neuen Kommentar ins Gästebuch geschrieben.
<G-vec00161-002-s180><comment.abgeben><en> Join in the discussion and leave a comment.
<G-vec00161-002-s180><comment.abgeben><de> Nehmen Sie an der Diskussion teil und hinterlassen Sie einen Kommentar.
<G-vec00161-002-s181><comment.abgeben><en> Swipe right repeatedly until you hear "New comment, button," and double-tap the screen.
<G-vec00161-002-s181><comment.abgeben><de> Streifen nach rechts wiederholt, bis Sie hören "Neuer Kommentar, Schaltfläche" und Doppeltippen Sie auf dem Bildschirm.
<G-vec00161-002-s182><comment.abgeben><en> Summary: Average user rating of Windows Explorer.exe: based on 1 vote with 1 user comment.
<G-vec00161-002-s182><comment.abgeben><de> Zusammenfassung: Durchschnittliche Bewertung von Windows Explorer.exe: basierend auf 1 Bewertung mit 1 Kommentar.
<G-vec00161-002-s183><comment.abgeben><en> Comment below this article, stating how many differences you found and tell us in your comment, why you would like to learn English, especially in London.
<G-vec00161-002-s183><comment.abgeben><de> Schreiben Sie uns einfach die Anzahl der Unterschiede als Kommentar unter diesen Artikel und verraten Sie uns in Ihrem Kommentar ebenso, warum Sie gerade in London Englisch lernen möchten.
<G-vec00161-002-s184><comment.abgeben><en> Summary: Average user rating of GetWordNT.dll: based on 1 vote with 1 user comment.
<G-vec00161-002-s184><comment.abgeben><de> Benutzer-Zusammenfassung: Durchschnittliche Bewertung von GetWordNT.dll: basierend auf 1 Bewertung mit 1 Kommentar.
<G-vec00161-002-s185><comment.abgeben><en> You can see the comment we just created here in the admin panel as well, and it is from here that you can delete it if you want.
<G-vec00161-002-s185><comment.abgeben><de> Sie können den Kommentar, den wir gerade erstellt haben, auch hier im Admin-Panel sehen, und von hier aus können Sie ihn löschen, wenn Sie möchten.
<G-vec00161-002-s186><comment.abgeben><en> A customer wrote the following comment on Trusted Shops: The car was delivered a little late and was also picked up a bit late, but it was acceptable.
<G-vec00161-002-s186><comment.abgeben><de> Ein Kunde schrieb folgenden Kommentar auf Trusted Shops: Der Wagen wurde etwas verspätet geliefert und auch bei der Abholung war die Pünktlichkeit nicht sehr gut, aber es war im vertretbaren Rahmen.
<G-vec00161-002-s187><comment.abgeben><en> The top most recent post links to the most recent comment on a thread that’s been going since May of 2017 and it only has 50 or so comments, most of which aren’t even pics.
<G-vec00161-002-s187><comment.abgeben><de> Die neuesten Top-Post-Links zum neuesten Kommentar zu einem Thema, das seit Mai 2017 läuft und nur etwa 50 Kommentare hat, von denen die meisten nicht einmal Bilder sind.
<G-vec00161-002-s188><comment.abgeben><en> More about Lime Pink: Comments about Lime Pink You know the stone Lime Pink well or have a question about Lime Pink, then post a comment here.
<G-vec00161-002-s188><comment.abgeben><de> Kommentare über Mooser Muschelkalk Rotbank Sie kennen den Naturstein Mooser Muschelkalk Rotbank gut, oder Sie haben Fragen zu Mooser Muschelkalk Rotbank, dann schreiben Sie einen Kommentar.
<G-vec00161-002-s189><comment.abgeben><en> If you’d like to publish dates and events, write a comment on THIS PAGE or contact us at libertad-patishtan@riseup.net.
<G-vec00161-002-s189><comment.abgeben><de> Wenn ihr die Termine eurer Veranstaltungen veröffentlichen wolllt schreibt uns einen Kommentar oder kontaktiert uns unter libertad-patishtan@riseup.net.
<G-vec00161-002-s190><comment.abgeben><en> Your comment does not have to deal with a publication as a whole, but can rather highlight individual chapters or aspects.
<G-vec00161-002-s190><comment.abgeben><de> Ihr Kommentar muss nicht das Werk als Ganzes behandeln, sondern darf gern fragmenthaften Charakter haben und nur einzelne Kapitel oder Aspekte einer Publikation beleuchten.
<G-vec00161-002-s191><comment.abgeben><en> Summary: Average user rating of avciman.exe: based on 3 votes with 1 user comment.
<G-vec00161-002-s191><comment.abgeben><de> Mitglieder Zusammenfassung: Durchschnittliche Bewertung von avciman.exe: basierend auf 3 Bewertungen mit 1 Kommentar.
<G-vec00161-002-s192><comment.abgeben><en> A WordPress Commenter 2019Hi, this is a comment.
<G-vec00161-002-s192><comment.abgeben><de> 15 March 2019 Hallo, dies ist ein Kommentar.
<G-vec00161-002-s193><comment.abgeben><en> That has been a complaint of the responsible persons in their comment to the Facility Safety Report 2018 .
<G-vec00161-002-s193><comment.abgeben><de> Das bemängeln die Verantwortlichen in ihrem Kommentar zum Anlagensicherheits-Report 2018 .
<G-vec00161-002-s194><comment.abgeben><en> Comment I agree to the terms and conditions laid out in the Privacy Policy
<G-vec00161-002-s194><comment.abgeben><de> Kommentar Hiermit stimme ich den Bedingungen und Ausführungen der Datenschutzerklärung zu.
<G-vec00161-002-s195><comment.abgeben><en> Updated: You should log in to write a comment.
<G-vec00161-002-s195><comment.abgeben><de> Du musst Dich anmelden, um einen Kommentar zu verfassen..
<G-vec00161-002-s196><comment.abgeben><en> start learning You must sign in to write a comment
<G-vec00161-002-s196><comment.abgeben><de> Sie müssen eingeloggt sein, um einen Kommentar zu schreiben.
<G-vec00161-002-s197><comment.abgeben><en> WordPress Comment Write a comment
<G-vec00161-002-s197><comment.abgeben><de> Hi, das ist ein Kommentar.
<G-vec00161-002-s198><comment.abgeben><en> Please write a comment
<G-vec00161-002-s198><comment.abgeben><de> Kommentar schreiben.
<G-vec00161-002-s200><comment.abgeben><en> Bilo je Post your comment
<G-vec00161-002-s200><comment.abgeben><de> Deinen Kommentar veröffentlichen.
<G-vec00161-002-s203><comment.abgeben><en> Comment Notify me of followup comments via e-mail
<G-vec00161-002-s203><comment.abgeben><de> Kommentar Benachrichtige mich über nachfolgende Kommentare via E-Mail.
<G-vec00161-002-s205><comment.abgeben><en> Login Create an account to leave a comment
<G-vec00161-002-s205><comment.abgeben><de> Nur Mitglieder können ein Kommentar hinterlassen.
<G-vec00161-002-s207><comment.abgeben><en> Therefore, please, write a comment
<G-vec00161-002-s207><comment.abgeben><de> Schreiben Sie also einen Kommentar.
<G-vec00161-002-s208><comment.abgeben><en> Comments You need to be logged in as a Club Rubi member to leave a comment
<G-vec00161-002-s208><comment.abgeben><de> Kommentare Sie müssen als RUBI Club Mitglied eingeloggt sein, um einen Kommentar zu hinterlassen.
<G-vec00161-002-s210><comment.abgeben><en> L'Autre ChoseHigh for leaving a comment
<G-vec00161-002-s210><comment.abgeben><de> Geben Sie bitte einen Kommentar ein.
<G-vec00161-002-s212><comment.abgeben><en> Information after a comment was added or changed in a circular Circular created
<G-vec00161-002-s212><comment.abgeben><de> Informationstext, wenn ein Kommentar in einem eigenen Umlauf hinzugefügt oder geändert wurde.
<G-vec00161-002-s213><comment.abgeben><en> Be the first to comment on this look. sign In
<G-vec00161-002-s213><comment.abgeben><de> Seien Sie die erste Person, die zu dieser Look einen Kommentar schreibt.
<G-vec00161-002-s215><comment.abgeben><en> When you interact with the plug-ins like pressing the Like button or leaving a comment, the corresponding information is sent directly from your browser and stored on Facebook.
<G-vec00161-002-s215><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s216><comment.abgeben><en> If you interact with the plugins, for example by clicking “Like”, or entering a comment, the corresponding information is transmitted from your browser directly to Facebook and stored by it.
<G-vec00161-002-s216><comment.abgeben><de> Wenn Nutzer mit den Social Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s217><comment.abgeben><en> If you interact with plugins, e.g. by clicking the so-called “Share” button or by entering a comment, this information will be sent directly to Facebook and stored there.
<G-vec00161-002-s217><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den “Gefällt mir” Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s218><comment.abgeben><en> Should you interact with the plugins, for example by clicking on the “Like” button or by posting a comment, your browser will transfer the corresponding information directly to Facebook and it will be stored there. Please access Facebook's Data Use Policy site to obtain further information on the purposes pursued by Facebook in collecting data, the scope in which it does so, as well as the further processing and use of such data; the policy also addresses your rights in this regard and the settings you may select to protect your privacy.
<G-vec00161-002-s218><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den "Gefällt mir" Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.Zweck und Umfang der Datenerhebung und die weitere Verarbeitung und Nutzung der Daten durch Facebook sowie Ihre diesbezüglichen Rechte und Einstellungsmöglichkeiten zum Schutz Ihrer Privatssphäre entnehmen Sie bitte den Datenschutzhinweisen von Facebook.
<G-vec00161-002-s220><comment.abgeben><en> If you interact with the plugins, for example by clicking the 'Like' button or by posting a comment, the information you give is then sent directly to Facebook and saved there.
<G-vec00161-002-s220><comment.abgeben><de> Sofern Sie mit den Plugins interagieren, zum Beispiel den Like-Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s221><comment.abgeben><en> If you interact with the plugins, for example, the "Pin it" button press or make a comment, this information is also transmitted directly to a server of options and stored there.
<G-vec00161-002-s221><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den „Pin it“-Button betätigen oder einen Kommentar abgeben, wird diese Information ebenfalls direkt an einen Server von Pinterest übermittelt und dort gespeichert.
<G-vec00161-002-s222><comment.abgeben><en> When users interact with the plugins, e.g. by activating the Like button or sharing a comment, then this information is transferred from your browser directly to Facebook and saved there.
<G-vec00161-002-s222><comment.abgeben><de> Wenn Nutzer mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s226><comment.abgeben><en> If you make a comment, we continue to store your IP address, which we delete after one week.
<G-vec00161-002-s226><comment.abgeben><de> Wenn Sie einen Kommentar abgeben, speichern wir weiterhin Ihre IP-Adresse, die wir nach sechs Monaten löschen.
<G-vec00161-002-s228><comment.abgeben><en> When users interact with the plugins, for example in confirming the “like” symbol or add a comment, then this is information is sent from the user’s device directly to Facebook and is stored there.
<G-vec00161-002-s228><comment.abgeben><de> Wenn Nutzer mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Gerät direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s229><comment.abgeben><en> When you interact with the plugins, for example by clicking "Like" or by posting a comment, the information is sent to your Facebook account, where it will be stored.
<G-vec00161-002-s229><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den „Gefällt mir“-Button betätigen oder einen Kommentar abgeben, wird diese Information ebenfalls direkt an einen Server von Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s230><comment.abgeben><en> If you interact with the plug-ins (eg to leave a comment), the corresponding information is also transmitted directly to a server of the social media service and stored there.
<G-vec00161-002-s230><comment.abgeben><de> Wenn Sie mit den Plug-Ins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s232><comment.abgeben><en> If you interact with the plug-ins e.g. press the ‘like’ button or leave a comment, the relevant information from your browser is delivered directly to Facebook and stored there. Even if you are not a member of Facebook, it is still possible that Facebook finds out and stores it.
<G-vec00161-002-s232><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.Falls Sie kein Mitglied von Facebook sind, besteht trotzdem die Möglichkeit, dass Facebook Ihre IP-Adresse in Erfahrung bringt und speichert.
<G-vec00161-002-s307><comment.abgeben><en> Commentaires When you leave a comment on our website, the data entered in the comment form, but also your IP address and the user agent of your browser are collected to help us detect unwanted comments.
<G-vec00161-002-s307><comment.abgeben><de> Wenn Besucher Kommentare auf der Website schreiben, sammeln wir die Daten, die im Kommentar-Formular angezeigt werden, außerdem die IP-Adresse des Besuchers und den User-Agent-String (damit wird der Browser identifiziert), um die Erkennung von Spam zu unterstützen.
<G-vec00161-002-s308><comment.abgeben><en> If a User leaves a comment in the blog or other posts their IP-adress will be stored.
<G-vec00161-002-s308><comment.abgeben><de> Wenn Nutzer Kommentare im Blog oder sonstige Beiträge hinterlassen, werden ihre IP-Adressen gespeichert.
<G-vec00161-002-s309><comment.abgeben><en> Previous Next → Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s309><comment.abgeben><de> Kommentare sind geschlossen, aber Sie können ein Trackback hinterlassen: Trackback-URL.
<G-vec00161-002-s310><comment.abgeben><en> Once a call is finished, it’s you can set the Call Result in amoCRM and add extra comment before it logs under the lead profile.
<G-vec00161-002-s310><comment.abgeben><de> Sobald Sie ein Telefonat beendet haben, können Sie sich die Ergebnisse in amoCRM anschauen und zusätzliche Kommentare hinzufügen.
<G-vec00161-002-s311><comment.abgeben><en> Submit No Comment Yet.
<G-vec00161-002-s311><comment.abgeben><de> Es gibt noch keine Kommentare.
<G-vec00161-002-s312><comment.abgeben><en> +msgstr "Modul comment groups, and users can (optionally) edit their last comment, assuming no others have been posted since.
<G-vec00161-002-s312><comment.abgeben><de> +msgstr "Ein Administrator kann Kommentarberechtigungen für Benutzergruppen vergeben und Benutzer können (optional) ihre letzten Kommentare bearbeiten, solange niemand anderes diese beantwortet hat.
<G-vec00161-002-s313><comment.abgeben><en> Please, post a comment and let us know what you think about the topic.
<G-vec00161-002-s313><comment.abgeben><de> Bitte schreiben Sie Kommentare und lassen Sie uns wissen, was Sie über dieses Thema denken.
<G-vec00161-002-s314><comment.abgeben><en> Next → Related Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s314><comment.abgeben><de> Kommentare sind geschlossen, aber du kannst ein Trackback hinterlassen: Trackback URL.
<G-vec00161-002-s315><comment.abgeben><en> He declined further comment on her health status Friday.
<G-vec00161-002-s315><comment.abgeben><de> Er verneinte am Freitag weitere Kommentare über ihren Gesundheitszustand zu geben.
<G-vec00161-002-s316><comment.abgeben><en> By default, a statistical query will calculate the COUNT expression (and thus the comment count and category count in the above example).
<G-vec00161-002-s316><comment.abgeben><de> Standardmäßig wird eine statistische Abfrage unter Verwendung von COUNT durchgeführt (was in obigem Beispiel für die Ermittlung der Anzahl der Kommentare und Kategorien der Fall ist).
<G-vec00161-002-s317><comment.abgeben><en> Hille handed out her quirky cards on the Berlin U-Bahn, slipping them in to ticket machines, provoking comment and conversation.
<G-vec00161-002-s317><comment.abgeben><de> Hille hat ihre skurrilen Karten in der Berliner U-Bahn verteilt und sie in Fahrkartenautomaten gesteckt, womit sie Kommentare und Gespräche provozierte.
<G-vec00161-002-s318><comment.abgeben><en> In ambiguous cases, stewards will evaluate the responses and will refer a decision back to the local community for their comment and review.
<G-vec00161-002-s318><comment.abgeben><de> Im Zweifelsfall werden wir die Antworten prüfen und eine Entscheidung zurück zur lokalen Gemeinschaft geben, um dort Kommentare und eine Prüfung zu verlangen.
<G-vec00161-002-s319><comment.abgeben><en> Text from a "#" character until the end of the line is a comment, and is ignored.
<G-vec00161-002-s319><comment.abgeben><de> Kommentare werden durch »#« eingeleitet; sämtlicher Text vom »#« bis zum Zeilenende wird ignoriert.
<G-vec00161-002-s320><comment.abgeben><en> After all, search spiders won’t write a comment, subscribe to your list or buy your product.
<G-vec00161-002-s320><comment.abgeben><de> Search Spiders schreiben schließlich keine Kommentare, melden sich nicht bei Deiner Liste an und kaufen Dein Produkt nicht.
<G-vec00161-002-s321><comment.abgeben><en> In “Who Can Comment,” select Registered User to turn on commenting with OpenID and other accounts.
<G-vec00161-002-s321><comment.abgeben><de> Wählen Sie unter "Wer darf Kommentare erstellen" die Option Registrierte Nutzer aus, um Kommentare über OpenID und andere Konten zu aktivieren.
<G-vec00161-002-s322><comment.abgeben><en> The Schwarze Botin featured academic texts, essays, literary pieces, poems and collages, as well as ironic and satirical comment.
<G-vec00161-002-s322><comment.abgeben><de> Die Schwarze Botin versammelte wissenschaftliche Aufsätze, Essays, literarische Texte und Gedichte, Collagen, Glossen und satirische Kommentare.
<G-vec00161-002-s323><comment.abgeben><en> Visio Services lets users comment across a wide group without requiring that each user have a copy of the client.
<G-vec00161-002-s323><comment.abgeben><de> Visio Services ermöglicht Benutzern Kommentare für eine große Gruppe, ohne dass jeder Benutzer eine Version des Clients haben muss.
<G-vec00161-002-s324><comment.abgeben><en> That is why those of us who grew up in the Communist society refuse to listen to any negative comment about the CCP.
<G-vec00161-002-s324><comment.abgeben><de> Aus diesem Grunde lehnen es viele in der kommunistischen Gesellschaft Chinas aufgewachsene ab, irgendwelche negativen Kommentare über die KPC zur Kenntnis zu nehmen.
<G-vec00161-002-s325><comment.abgeben><en> - any picture, video or audio file as well as any comment linking to any picture, video or audio file whose legal status we deem questionable, in particular regarding intellectual property Managing Director)
<G-vec00161-002-s325><comment.abgeben><de> - Bilder, Video- oder Audiodateien sowie Kommentare, die zu Bildern, Video- oder Audiodateien verlinken, deren Rechtslage, insbesondere hinsichtlich der Rechte des geistigen Eigentums, fragwürdig erscheint.
<G-vec00161-002-s326><comment.abgeben><en> Now: If you would like to know something - anything - related to painting miniatures, please drop your question in the comment section below.
<G-vec00161-002-s326><comment.abgeben><de> Also: Wenn ihr zur Figurenmalerei etwas wissen wollt - was auch immer - hinterlasst eure Frage in den Kommentaren unten.
<G-vec00161-002-s327><comment.abgeben><en> In addition to the rights applicable to any Submission, when you post comments or reviews to the site, you also grant Artisoo.com the right to use the name that you submit with any review, comment, or other Content, if any, in connection with such review, comment, or other content.
<G-vec00161-002-s327><comment.abgeben><de> Neben der gültigen Rechte für irgendeine Submission, wenn Sie Kommentare oder Bewertungen auf der Webseite posten, geben Sie Artisoo.com auch das Recht, den Namen mit den Besprechungen, Kommentaren oder anderen Inhalten zu nutzen, wenn überhaupt, in Verbindung mit solchen Besprechungen, Kommentaren oder anderen Inhalten.
<G-vec00161-002-s329><comment.abgeben><en> To ask questions or comment about the Website or these Terms of Use, contact us at: Coalesse_Concierge@coalesse.com or via our toll-free number: 1-866-645-6952.
<G-vec00161-002-s329><comment.abgeben><de> Bei Fragen oder Kommentaren zu der Internetseite oder diesen Nutzungsbedingungen kontaktieren Sie uns unter: Coalesse_Concierge@coalesse.com oder über unsere gebührenfreie Rufnummer: 1-866-645-6952.
<G-vec00161-002-s330><comment.abgeben><en> Twitter: If you got a Twitter account, you can enter your Twitter name (with or without the @, doesn't matter) which will then be displayed next to any comment (including old ones) that contain the same e-mail address.
<G-vec00161-002-s330><comment.abgeben><de> Twitter: Wenn du einen Twitter-Account hast, kannst du im entsprechenden Feld deinen Twitter-Namen eingeben (egal ob mit oder ohne dem @), der dann bei allen (auch älteren) Kommentaren, die dieselbe E-Mail-Adresse enthalten, angezeigt wird.
<G-vec00161-002-s331><comment.abgeben><en> If, as a data subject, you leave a comment on one of our blogs, this comment, as well as information about the time the comment was posted and your user name (pseudonym), will be saved and published.
<G-vec00161-002-s331><comment.abgeben><de> Hinterlassen Sie einen Kommentar in unserem Blog, werden neben den von der betroffenen Person hinterlassenen Kommentaren auch Angaben zum Zeitpunkt der Kommentareingabe sowie zu dem von der betroffenen Person gewählten Nutzernamen (Pseudonym) gespeichert und veröffentlicht.
<G-vec00161-002-s332><comment.abgeben><en> Have thoughts on the Google Pixel 2? drop us a comment below!
<G-vec00161-002-s332><comment.abgeben><de> Teile deine Gedanken zum Google Pixel 2 in den Kommentaren.
<G-vec00161-002-s333><comment.abgeben><en> ComeOn Sportsbook customer support service is always friendly and ready to assist you with any problem, comment or question that you might have.
<G-vec00161-002-s333><comment.abgeben><de> Der Kundendienst von ComeOn Sportsbook ist immer freundlich und hilft Ihnen bei Problemen, Kommentaren oder Fragen.
<G-vec00161-002-s334><comment.abgeben><en> >> Now, if you have anymore questions. I am more than happy to answer them via the comment section.
<G-vec00161-002-s334><comment.abgeben><de> >> Wenn ihr noch eine offene Frage habt, beantworte ich diese natürlich gerne in den Kommentaren.
<G-vec00161-002-s335><comment.abgeben><en> The dissident faction has made similar dismissive remarks—which begs the question as to why they would even bother to comment if the SEP and the ideas for which it fights were so unimportant.
<G-vec00161-002-s335><comment.abgeben><de> Die Frage stellt sich, warum sie sich überhaupt zu Kommentaren bemühen, wenn doch die SEP und die Ideen, für die sie kämpft, so unwichtig sind.
<G-vec00161-002-s336><comment.abgeben><en> If you have any enquiry, comment or concern, or would like to comment on our use of personal information, you can email the El Corte Inglés Group Data Protection Officer at delegado.protecciondatos@elcorteingles.es
<G-vec00161-002-s336><comment.abgeben><de> Bei Rückfragen, Hinweisen, Kommentaren oder Vorschlägen zu unserer Nutzung personenbezogener Daten können Sie eine E-Mail an den Datenschutzbeauftragen der Gruppe El Corte Inglés (delegado.protecciondatos@elcorteingles.es) senden.
<G-vec00161-002-s337><comment.abgeben><en> Don’t forget to link your awesome creations here in the comment section.
<G-vec00161-002-s337><comment.abgeben><de> Und jetzt Vergesst nicht eure wunderbaren Werke hier in den Kommentaren zu verlinken.
<G-vec00161-002-s338><comment.abgeben><en> Tell us what you think in the comment section below.
<G-vec00161-002-s338><comment.abgeben><de> Sag es uns in den Kommentaren.
<G-vec00161-002-s339><comment.abgeben><en> December or March - please comment below the article)
<G-vec00161-002-s339><comment.abgeben><de> Dezember oder März - bitte in den Kommentaren vermerken.
<G-vec00161-002-s340><comment.abgeben><en> In languages with single line comment, you can’t use it to minify the code as everything after the first comment would be commented out.
<G-vec00161-002-s340><comment.abgeben><de> Bei Sprachen mit einzeiligen Kommentaren, die in vielen Programmiersprachen mit zwei Slashes beginnen, kann der Quellcode so einfach natürlich nicht minimiert werden, da alles nach dem ersten einzeiligen Kommentar auch auskommentiert werden würde.
<G-vec00161-002-s341><comment.abgeben><en> Said phishing pages were set up to appear to belong to local news outlets, and were really convincing – right down to the fake comment sections, containing fake posts by famous local personalities.
<G-vec00161-002-s341><comment.abgeben><de> Diese Phishing-Seiten wurden so eingerichtet, dass sie den lokalen Nachrichtenagenturen gehören, und waren wirklich überzeugend - bis hin zu den gefälschten Kommentaren, die gefälschte Beiträge berühmter lokaler Persönlichkeiten enthielten.
<G-vec00161-002-s342><comment.abgeben><en> If you have any additional questions about Fellowships please leave them in the comment section. We will answer them!
<G-vec00161-002-s342><comment.abgeben><de> Falls Ihr noch weitere Fragen zu den Gemeinschaften habt, fragt uns in den Kommentaren, wir beantworten eure brennendsten Themen.
<G-vec00161-002-s343><comment.abgeben><en> The winner will also be announced within the giveaway post comment section.
<G-vec00161-002-s343><comment.abgeben><de> Der Gewinner wird auch in den Kommentaren des Gewinnspiel Posts angekündigt.
<G-vec00161-002-s344><comment.abgeben><en> We process your personal data in order to be able to defend ourselves against liability claims by third parties, if we publish an unlawful comment.
<G-vec00161-002-s344><comment.abgeben><de> Wir verarbeiten Ihre personenbezogenen Daten, um uns im Falle einer Veröffentlichung von rechtswidrigen Kommentaren gegen Haftungsansprüche Dritter verteidigen zu können.
<G-vec00161-002-s489><comment.abgeben><en> 4. Where the reporting Member State, taking into account considerations expressed by the other Member States concerned, finds that the application does not concern an aspect covered by Part I of the assessment report or that the application dossier is not complete, it shall inform the sponsor thereof through the EU portal and shall set a maximum of 10 days for the sponsor to comment on the application or to complete the application dossier through the EU portal.
<G-vec00161-002-s489><comment.abgeben><de> (4) Stellt der berichterstattende Mitgliedstaat unter Berücksichtigung der von den anderen betroffenen Mitgliedstaaten vorgebrachten Anmerkungen fest, dass der Antrag keinen in Teil I des Bewertungsberichts behandelten Aspekt betrifft oder dass das Antragsdossier unvollständig ist, teilt er dies dem Sponsor über das EU-Portal mit und setzt ihm eine Frist von höchstens zehn Tagen zur Stellungnahme zum Antrag oder zur Ergänzung des Antragsdossiers über das EU-Portal.
<G-vec00161-002-s490><comment.abgeben><en> Alibaba Group and Tencent, two other Chinese Internet giants with music streaming services, did not respond to a request for comment.
<G-vec00161-002-s490><comment.abgeben><de> Auch die großen Internetkonzerne Alibaba Group und Tencent, die ebenfalls Musikstreaming-Dienste in China anbieten, waren zu keiner Stellungnahme bereit.
<G-vec00161-002-s491><comment.abgeben><en> The Ombud for Equal Treatment drafted a letter to the manager of the disco as well as the manager of the security company, in which she described the incident, informed on the legal provisions of the Equal Treatment Act and requested them to comment on the incident.
<G-vec00161-002-s491><comment.abgeben><de> Die Gleichbehandlungsanwältin verfasst zunächst ein Schreiben an den Geschäftsführer der Diskothek sowie den Geschäftsführer des Security-Unternehmens, wobei sie den Vorfall schildert, auf die rechtlichen Bestimmungen des Geichbehandlungsgesetzes verweist und um Stellungnahme zu dem Vorfall ersucht.
<G-vec00161-002-s492><comment.abgeben><en> The working group opens its comment letter on the IASB's ED/2013/6 Leases by expressly stating that the concepts developed fit well into the world of Islamic accounting and prominent Sharia'a scholars commend the IASB for the proposals.
<G-vec00161-002-s492><comment.abgeben><de> Die Arbeitsgruppe eröffnet ihre Stellungnahme zum IASB-Entwurf ED/2013/6 Leasingverhältnisse damit, dass sie ausdrücklich darauf hinweist, dass die entwickelten Konzepte gut in die Welt islamischer Bilanzierung passen und dass herausragende Scharia'a-Gelehrte den IASB für dessen Vorschläge loben.
<G-vec00161-002-s493><comment.abgeben><en> 4. Where the Commission intends to make the implementation of certain standards and/or specifications compulsory, it shall publish a notice in the Official Journal of the European Communities and invite public comment by all parties concerned.
<G-vec00161-002-s493><comment.abgeben><de> „(4) Beabsichtigt die Kommission, die Anwendung bestimmter Normen und/oder Spezifikationen verbindlich vorzuschreiben, so veröffentlicht sie eine Bekanntmachung im Amtsblatt der Europäischen Union und fordert alle Beteiligten zur Stellungnahme auf.
<G-vec00161-002-s494><comment.abgeben><en> Within this framework we will, if possible, develop suggestions to solve your problem, which we will then present you to comment or decide.
<G-vec00161-002-s494><comment.abgeben><de> In diesem Rahmen werden, wenn möglich, Vorschläge zur Lösung Ihres Anliegens entwickelt, die Ihnen anschließend zur Stellungnahme oder Entscheidung vorgelegt werden.
<G-vec00161-002-s495><comment.abgeben><en> We will inform the supplier in advance of the content and scope of the recall measures to be implemented and give the supplier the opportunity to comment, provided this is possible and reasonable.
<G-vec00161-002-s495><comment.abgeben><de> Über Inhalt und Umfang etwaiger Rückrufmaßnahmen wird uns der Besteller – soweit möglich und zumutbar – vorab unterrichten und uns Gelegenheit zur Stellungnahme geben.
<G-vec00161-002-s496><comment.abgeben><en> In a comment to the German Embassy JNF stresses that it does not discriminate in any way against Arab applicants.
<G-vec00161-002-s496><comment.abgeben><de> In einer Stellungnahme gegenüber der Deutschen Botschaft unterstreicht der JNF, dass er in keiner Weise gegenüber arabischen Antragstellern diskriminiere.
<G-vec00161-002-s497><comment.abgeben><en> A spokesperson for the Hungarian permanent representation to the EU declined to comment and said the government is still examining the court ruling.
<G-vec00161-002-s497><comment.abgeben><de> Ein Sprecher der ständigen Vertretung Ungarns bei der EU verweigerte die Stellungnahme und sagte, die Regierung prüfe derzeit noch das Gerichtsurteil.
<G-vec00161-002-s498><comment.abgeben><en> 30 Jul 2010 Deloitte's IFRS Global Office has submitted a letter of comment to the IASB on Discussion paper DP/2010/1 'Extractive Activities'.
<G-vec00161-002-s498><comment.abgeben><de> Das IFRS Global Office von Deloitte hat gegenüber der IFRS-Stiftung eine Stellungnahme zum vorgeschlagenen Handbuch für den Konsultationsprozess eingereicht, das im Mai 2012 zwecks öffentlicher Stellungnahme herausgegeben wurde.
<G-vec00161-002-s499><comment.abgeben><en> The Buyer has to prove his claim (best with photo documentation) and the Seller is asked to comment the situation.
<G-vec00161-002-s499><comment.abgeben><de> Es ist wichtig, dass der Käufer die Richtigkeit seiner Reklamation beweist, am besten durch Fotodokumentation, und die Verkäufer zur Stellungnahme fordert.
<G-vec00161-002-s500><comment.abgeben><en> The research protocol must be submitted for consideration, comment, guidance and approval to a research ethics committee before the study begins.
<G-vec00161-002-s500><comment.abgeben><de> Das Studienprotokoll ist vor Studienbeginn zur Beratung, Stellungnahme, Orientierung und Zustimmung einer Forschungsethik-Kommission vorzulegen.
<G-vec00161-002-s501><comment.abgeben><en> This comment supports a proposed exemption for noncommercial remix videos that do not infringe copyright.
<G-vec00161-002-s501><comment.abgeben><de> Diese Stellungnahme stützt den Vorschlag, eine Ausnahme für nicht tkommerzielle Remix-Videos einzurichten, die nicht gegen das Urheberrecht verstoßen.
<G-vec00161-002-s502><comment.abgeben><en> We will inform the supplier about the content and scope of any recall measures - as far as possible and reasonable - and provide supplier with an opportunity to comment.
<G-vec00161-002-s502><comment.abgeben><de> Über Inhalt und Umfang der durchzuführenden Rückrufmaßnahmen werden wir den Lieferanten – soweit möglich und zumutbar – unterrichten und ihm Gelegenheit zur Stellungnahme geben.
<G-vec00161-002-s503><comment.abgeben><en> We are not trying to keep the poor out of the picture," he said. There was no immediate comment from ADB.
<G-vec00161-002-s503><comment.abgeben><de> Wir versuchen doch nicht die Armut aus dem Bild auszugrenzen.“ Die ADB konnte nicht zu einer Stellungnahme gewonnen werden.
<G-vec00161-002-s504><comment.abgeben><en> A spokeswoman for Kutcher hasn't return messages seeking comment. Comments Michigan's Best
<G-vec00161-002-s504><comment.abgeben><de> Eine Sprecherin Kutchers reagierte zunächst nicht auf eine Anfrage nach einer Stellungnahme.
<G-vec00161-002-s505><comment.abgeben><en> There was no immediate comment on the Iranian allegations by the CIA or U.S. officials.
<G-vec00161-002-s505><comment.abgeben><de> Es gab keine sofortige Stellungnahme zu den iranischen Vorwürfen der CIA oder von US-Beamten.
<G-vec00161-002-s506><comment.abgeben><en> You do not have permission to comment.
<G-vec00161-002-s506><comment.abgeben><de> Sie haben keine Berechtigung zur Stellungnahme.
<G-vec00161-002-s507><comment.abgeben><en> We will inform the supplier of the content and scope of the recall actions to be applied, where possible and reasonable, and give him the opportunity to comment on this. 9.
<G-vec00161-002-s507><comment.abgeben><de> Über Umfang und Inhalt der durchzuführenden Maßnahmen werden wir den Lieferanten – soweit möglich und zumutbar – unterrichten und ihm Gelegenheit zur Stellungnahme geben.
<G-vec00161-002-s508><comment.abgeben><en> Monsanto did not respond to multiple requests for comment.
<G-vec00161-002-s508><comment.abgeben><de> Monsanto reagierte nicht auf viele Bitten um Stellungnahmen.
<G-vec00161-002-s509><comment.abgeben><en> — Unless otherwise specified, interested parties should not submit new factual information after the deadline to comment on the provisional disclosure or the information document at provisional stage.
<G-vec00161-002-s509><comment.abgeben><de> Sofern nichts anderes bestimmt ist, sollten interessierte Parteien nach Ablauf der Frist für Stellungnahmen zur vorläufigen Unterrichtung oder zum Informationspapier im vorläufigen Stadium keine neuen Sachinformationen vorlegen.
<G-vec00161-002-s510><comment.abgeben><en> Oak Tree officials did not respond to several requests seeking comment in person and by phone.
<G-vec00161-002-s510><comment.abgeben><de> Funktionäre von Oak Tree antworteten nicht auf mehrere persönliche und telefonische Anfragen zu Stellungnahmen.
<G-vec00161-002-s511><comment.abgeben><en> The Company has responded to all the subsequent production orders and comment letters in a timely manner.
<G-vec00161-002-s511><comment.abgeben><de> Das Unternehmen hat auf alle weiteren Herausgabeanordnungen und Stellungnahmen rechtzeitig geantwortet.
<G-vec00161-002-s512><comment.abgeben><en> The Board noted the need to present comment letter feedback to the Advisory Council to understand their reactions to the feedback received.
<G-vec00161-002-s512><comment.abgeben><de> Der Board führte die Notwendigkeit an, die Ergebnisse aus den Stellungnahmen dem Standardbeirat vorzulegen und deren Reaktion auf die erhaltenen Eingaben zu verstehen.
<G-vec00161-002-s513><comment.abgeben><en> Deloitte's IFRS Global Office has submitted two letter of comment to the IFRS Interpretations Committee on (1) Tentative agenda decision: IAS 1 Presentation of Financial Statements and IAS 12 Income Taxes – Presentation of payments of non-income taxes and (2) Tentative agenda decision: IAS 12 Income Taxes – Accounting for market value uplifts introduced by a new tax regime.
<G-vec00161-002-s513><comment.abgeben><de> 15.05.2012 Das IFRS Global Office von Deloitte hat beim IFRS Interpretations Committee zwei Stellungnahmen zu (1) der vorläufigen Agendaentscheidung in Bezug auf IAS 1 und IAS 12 – Darstellung von Zahlungen von Steuern, die keine Ertragsteuern sind, und (2) der vorläufigen Agendaentscheidung in Bezug auf IAS 12 – Bilanzierung von Marktwerterhöhungen aufgrund eines neuen Steuerregimes eingereicht.
<G-vec00161-002-s514><comment.abgeben><en> After the deadline for the comment has expired, a decision can then be made on the application.
<G-vec00161-002-s514><comment.abgeben><de> Nach Ablauf der Frist für die Stellungnahmen entscheidet sie abschließend über den Antrag und informiert die antragstellende Person schriftlich über das Ergebnis.
<G-vec00161-002-s515><comment.abgeben><en> However, the lack of any formal comment letters was noted.
<G-vec00161-002-s515><comment.abgeben><de> Allerdings wurde das Fehlen jeglicher formeller Stellungnahmen thematisiert.
<G-vec00161-002-s516><comment.abgeben><en> The Commission is considering the establishment of a European Advisory Group that would consist of decision makers, scientists and representatives of civil society organisations and would comment on the work of a number of working groups acting under the aegis of the Commission.
<G-vec00161-002-s516><comment.abgeben><de> Sie plant die Einsetzung eines europäischen Beirats aus Entscheidungsträgern, Wissenschaftlern und Vertretern der Organisationen der Zivilgesellschaft, der die Aufgabe haben wird, Stellungnahmen zu den Arbeiten verschiedener, unter der Schirmherrschaft der Kommission tätiger Arbeitsgruppen abzugeben.
<G-vec00161-002-s517><comment.abgeben><en> Any comment on the sample selection must be received within 3 days of the date of notification of the sample decision.
<G-vec00161-002-s517><comment.abgeben><de> Stellungnahmen zur Stichprobenauswahl müssen binnen 3 Tagen nach Bekanntgabe der Entscheidung über die Stichprobe eingehen.
<G-vec00161-002-s518><comment.abgeben><en> Deloitte's IFRS Global Office has submitted a letter of comment to the SME Implementation Group on its Third batch of SME Implementation Group questions and answer documents.
<G-vec00161-002-s518><comment.abgeben><de> Deloitte-Stellungnahmen zu vorläufigen Agendaentscheidungen 23.02.2011 Das IFRS Global Office von Deloitte hat Stellungnahmen zu zwei vorläufigen Agendaentscheidungen des IFRS Interpretations Committee eingereicht.
<G-vec00161-002-s519><comment.abgeben><en> 27 Jan 2012 The staff presented an analysis of the comment letters received on the Board's exposure draft 'Government Loans (Proposed amendment to IFRS 1)' published in October 2011.
<G-vec00161-002-s519><comment.abgeben><de> Der Stab stellte eine Auswertung der zum im Oktober 2011 veröffentlichten Entwurf 'Darlehen der öffentlichen Hand (Vorgeschlagene Änderungen an IFRS 1)' erhaltenen Stellungnahmen vor.
<G-vec00161-002-s520><comment.abgeben><en> c. The Staff Manager will take all Constituency/Stakeholder Group Statements, Public Comment Statements, and other information and compile (and post on the Comment Site) an Initial Report within fifty (50) calendar days after initiation of the PDP.
<G-vec00161-002-s520><comment.abgeben><de> c. Der Staff Manager nimmt alle Erklärungen der Bezirke/Interessengruppen, Erklärungen öffentlicher Stellungnahmen und andere Informationen und stellt diese innerhalb von fünfzig (50) Kalendertagen nach der Initiierung des PDP in einem anfänglichen Bericht zusammen (und veröffentlicht diesen Bericht auf der Website für Stellungnahmen, der Comment Site).
<G-vec00161-002-s521><comment.abgeben><en> 23 Jul 2013 The Board discussed feedback from outreach activities, field work, and comment letters on the proposals in Exposure Draft 'Financial Instruments: Expected Credit Losses' as well as constituents’ feedback on the FASB impairment proposals.
<G-vec00161-002-s521><comment.abgeben><de> Die Boards erörterten die Rückmeldungen aus den Erkundigungsaktivitäten, den Feldtests aund den Stellungnahmen auf die Vorschläge aus dem Standardentwurf ED/2013/3 'Finanzinstrumente: Erwartete Kreditausfälle' sowie den Rückmeldungen der Adressaten auf die Wertminderungsvorschläge des FASB.
<G-vec00161-002-s402><comment.kommentieren><en> Every time I read "Displays your 're not a robot", when writing a comment, I consider hard whether I shouldn't click X directly.
<G-vec00161-002-s402><comment.kommentieren><de> Jedes Mal wenn ich kommentiere und dieses "Zeigt das Ihr kein Roboter seid", lese, überlege ich schwer, ob ich nicht schon direkt auf X klicken soll.
<G-vec00161-002-s403><comment.kommentieren><en> Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s403><comment.kommentieren><de> Interessante Perspektiven Kommentiere oder hinterlasse ein Trackback: Trackback-URL.
<G-vec00161-002-s405><comment.kommentieren><en> Comment about the weather, ask them about their weekend (or plans for the upcoming weekend), and be genuinely curious about their response.
<G-vec00161-002-s405><comment.kommentieren><de> Kommentiere das Wetter, frage nach dem letzten Wochenende (oder Plänen für das kommende) und zeige aufrichtiges Interesse an der Antwort.
<G-vec00161-002-s406><comment.kommentieren><en> Comment Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s406><comment.kommentieren><de> Website Comment Speichere meine Daten im Browser für das nächste Mal, wenn ich kommentiere.
<G-vec00161-002-s407><comment.kommentieren><en> Comment, tell, discuss what is painted in the book.
<G-vec00161-002-s407><comment.kommentieren><de> Kommentiere, erzähle, diskutiere, was im Buch gemalt ist.
<G-vec00161-002-s408><comment.kommentieren><en> Simply LIKE our Facebook page, SHARE our Game of the Week or Exclusive Slot Facebook post and comment with your Royal Panda username to be in with a chance to win 30 free spins for that week’s slot.
<G-vec00161-002-s408><comment.kommentieren><de> LIKE einfach unsere Facebook-Seite, TEILE unseren Facebook-Post zum Spiel der Woche oder dem exklusiven Spielautomaten und kommentiere mit deinem Benutzernamen, um die Chance zu haben, 30 Free Spins für den Automaten der Woche zu gewinnen.
<G-vec00161-002-s409><comment.kommentieren><en> Related Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s409><comment.kommentieren><de> Hummer mit Linguine – Kommentiere oder hinterlasse ein Trackback: Trackback-URL.
<G-vec00161-002-s410><comment.kommentieren><en> If you like this post, like it, share it, comment on it.
<G-vec00161-002-s410><comment.kommentieren><de> Wenn Dir dieser Post gefallen hat, teile ihn oder kommentiere.
<G-vec00161-002-s412><comment.kommentieren><en> Comment on Products, J!NX Pix, Trivia, and/or J!NX Blogs.
<G-vec00161-002-s412><comment.kommentieren><de> Kommentiere Produkte, J!NX-Fotos, Quizwettbewerbe und/oder J!NX-Blogs .
<G-vec00161-002-s414><comment.kommentieren><en> Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s414><comment.kommentieren><de> Über Kommentiere oder hinterlasse ein Trackback: Trackback-URL.
<G-vec00161-002-s415><comment.kommentieren><en> Consecutively, I focus on my social media channels and look at new uploads from Instagrammers, thank my followers for their lovely comments and comment or like back – this makes me really relax my mind and it is great fun for me.
<G-vec00161-002-s415><comment.kommentieren><de> Anschlie├čend widme ich mich meinen Social Media Kan├Ąlen und schaue mir neue Bilder von Instagrammern an, bedanke mich bei den lieben Kommentaren und kommentiere/like zur├╝ck – hier kann ich so richtig abschalten und hab sehr viel Spa├č dabei.
<G-vec00161-002-s417><comment.kommentieren><en> I and my colleagues very often comment cult issues on the national TV, giving more information about each cult.
<G-vec00161-002-s417><comment.kommentieren><de> Ich und meine Kollegen kommentieren sehr oft im nationalen Fernsehen Sektenfragen und verbreiteten mehr Informationen über jede Sekte.
<G-vec00161-002-s418><comment.kommentieren><en> I won’t comment on that.
<G-vec00161-002-s418><comment.kommentieren><de> Das werde ich nicht kommentieren.
<G-vec00161-002-s419><comment.kommentieren><en> For example, for one of the operation we call recordings, we used and display the actions at stake during the recording: working on a part, repeating and listening, have a comment, replay a part etc.
<G-vec00161-002-s419><comment.kommentieren><de> Stattdessen stellten wir beispielsweise ein Verfahren aus, das wir „Aufnahme“ nennen und benutzten die Handlungen, die hierfür gebraucht werden: an einem Ausschnitt arbeiten, wiederholen und zuhören, kommentieren, erneut spielen und so weiter.
<G-vec00161-002-s420><comment.kommentieren><en> The first 10 people who comment on this journal will get a free sketch.
<G-vec00161-002-s420><comment.kommentieren><de> Die ersten 10 Leute die hier kommentieren, bekommen eine freie Skizze.
<G-vec00161-002-s421><comment.kommentieren><en> It lets you edit, annotate, mark up, and comment on your PDF.
<G-vec00161-002-s421><comment.kommentieren><de> Sie können das PDF bearbeiten, mit Anmerkungen versehen, markieren und kommentieren.
<G-vec00161-002-s422><comment.kommentieren><en> If you operate a blog, comment on a blog, post material to the Website, post links on the Website, or otherwise make (or allow any third party to make) material available by means of the Website (any such material, "Content"), You are entirely responsible for the content of, and any harm resulting from, that Content.
<G-vec00161-002-s422><comment.kommentieren><de> Wenn Sie einen Beitrag kommentieren, Material oder Links auf dieser Website veröffentlichen oder anderweitig Material über diese Website zur Verfügung stellen oder Dritte dazu berechtigen, sind Sie für den Inhalt und den aus diesem Inhalt resultierenden Schaden in vollem Umfang verantwortlich.
<G-vec00161-002-s423><comment.kommentieren><en> So other PB users can rate and comment your project... Thanks
<G-vec00161-002-s423><comment.kommentieren><de> Damit können andere PB-Anwender Ihr Projekt bewerten und kommentieren...
<G-vec00161-002-s424><comment.kommentieren><en> And it is best to comment only on people who own a car "Suzuki-Liana".
<G-vec00161-002-s424><comment.kommentieren><de> Und es ist am besten, nur Leute zu kommentieren, die ein Auto "Suzuki-Liana" besitzen.
<G-vec00161-002-s425><comment.kommentieren><en> Analyze, comment, overlay and assess embedded data of LIBERO PDF reports.
<G-vec00161-002-s425><comment.kommentieren><de> Eingebettete Daten von LIBERO PDF-Berichte beurteilen, analysieren, kommentieren und überlagern.
<G-vec00161-002-s426><comment.kommentieren><en> A series of workshops provides them with the opportunity to study and comment on artistic content as well as forms of presentation and mediation.
<G-vec00161-002-s426><comment.kommentieren><de> In einer Reihe von Workshops untersuchen sie Inhalte, Präsentations- und Vermittlungsformen und kommentieren diese.
<G-vec00161-002-s427><comment.kommentieren><en> It is permissible to use the work of another author in one’s own work if it is to write about it, in other words, to evaluate this material, to comment on it, or to compare it.
<G-vec00161-002-s427><comment.kommentieren><de> Zulässig ist die Übernahme einer fremden Arbeit in die eigene Arbeit, um darüber zu schreiben, dieses Material also auszuwerten, zu kommentieren, zu beurteilen und zu vergleichen.
<G-vec00161-002-s428><comment.kommentieren><en> Not comment either.
<G-vec00161-002-s428><comment.kommentieren><de> Auch nicht zu kommentieren.
<G-vec00161-002-s429><comment.kommentieren><en> To leave your comment or to rate this app, please login or register. Perfect
<G-vec00161-002-s429><comment.kommentieren><de> Wenn Sie diese App kommentieren oder bewerten möchten, melden Sie sich bitte an, oder registrieren Sie sich..
<G-vec00161-002-s430><comment.kommentieren><en> When a wiki is used as a platform to collect and evaluate ideas, its real strength can be brought to bear by granting access to as many employees as possible, who can then comment on, add to and evaluate the ideas.
<G-vec00161-002-s430><comment.kommentieren><de> Wird das Wiki als Plattform zur Sammlung und Bewertung von Ideen genutzt, kann es insbesondere dann seine Stärken voll ausspielen, wenn es vielen Mitarbeitern zugänglich ist und diese die Möglichkeit haben, die Ideen zu kommentieren, zu ergänzen und selbst zu bewerten.
<G-vec00161-002-s431><comment.kommentieren><en> They love it when their chat buddies comment on their masturbation techniques and give them tips on how to improve their performance.
<G-vec00161-002-s431><comment.kommentieren><de> Sie lieben es, wenn ihre Chat-Freunde ihre Masturbationstechniken kommentieren und ihnen Tipps geben, um ihre Performance zu verbessern.
<G-vec00161-002-s432><comment.kommentieren><en> Be Obstfan are invited to evaluate the benefits to comment on the trees and to enrich photos.
<G-vec00161-002-s432><comment.kommentieren><de> Sie als Obstfan sind eingeladen, die Früchte zu bewerten, die Bäume zu kommentieren und um Fotos anzureichern.
<G-vec00161-002-s433><comment.kommentieren><en> The Group is not permitted to comment on whether A1 Telekom Austria Group is planning and sees a need to participate and acquire spectrum in the abovementioned procedures.
<G-vec00161-002-s433><comment.kommentieren><de> Ob die A1 Telekom Austria Group plant oder die Notwendigkeit sieht, sich an den oben genannten Prozes-sen zu beteiligen und Frequenzen zu erwerben, darf die Gruppe nicht kommentieren.
<G-vec00161-002-s434><comment.kommentieren><en> In his String Quartet Vermeulen appears to give a musical comment on dodecaphony by creating a large number of twelve-tone melodies that are never presented in inversion or in retrograde.
<G-vec00161-002-s434><comment.kommentieren><de> Deshalb scheint Vermeulen in seinem Streichquartett mittels seiner persönlichen Sprache die Dodekaphonie zu kommentieren: er entwirft zahlreiche Zwölftonmelodien, die aber nirgendwo weder in Umkehrung noch in Krebsgang erscheinen.
<G-vec00161-002-s435><comment.kommentieren><en> You can comment the parks and upload photos.
<G-vec00161-002-s435><comment.kommentieren><de> Du kannst die Hundewälder kommentieren und beurteilen.
<G-vec00161-002-s436><comment.kommentieren><en> In mirroring a media-filtered pop culture, Sachs uses his installation to comment on the everyday insanity of America's media reality with its violence and its car chase scenes, providing an up-to-date commentary on the failure of European Modernism in the process.
<G-vec00161-002-s436><comment.kommentieren><de> Im Spiegel einer durch die Medien gefilterten Popkultur kommentiert Sachs in der Installation den täglichen Wahn der von Gewalt und Autoverfolgungsjagden gekennzeichneten Medienrealität Amerikas und liefert ganz nebenbei einen zeitgemäßen Kommentar zum Scheitern der europäischen Moderne.
<G-vec00161-002-s437><comment.kommentieren><en> Right on the challengeblog you can win a great voucher (your comment or inlinkz use on each blog is required and have created something).
<G-vec00161-002-s437><comment.kommentieren><de> Bei SFC direkt könnt ihr einen tollen Gutschein gewinnen (Voraussetzung: Ihr habt auf jeden Blog kommentiert / Inlinkz benutzt und etwas gebastelt).
<G-vec00161-002-s438><comment.kommentieren><en> To share your wonderful wraps and rolls, simply comment with your photo on any Kitchen Stories recipe or this article.
<G-vec00161-002-s438><comment.kommentieren><de> Um eure gewickelten und aufgerollten Kreationen zu teilen, kommentiert einfach ein Kitchen Stories Rezept oder diesen Artikel mit eurem Foto.
<G-vec00161-002-s439><comment.kommentieren><en> This website allows visitors to comment on the content.
<G-vec00161-002-s439><comment.kommentieren><de> Auf dieser Webseite können Beiträge kommentiert werden.
<G-vec00161-002-s440><comment.kommentieren><en> Treading a fine and virtuosic line between design, craft and art, the Copenhagen-based creative’s work is, among other things, an expression of pure material joy and a comment on the, often compromised, value of fast-paced production.
<G-vec00161-002-s440><comment.kommentieren><de> Der Kopenhagener Kreativkopf, der sich auf einem schmalen Grat zwischen Design, Handwerk und Kunst bewegt, bringt in seiner Arbeit unter anderem die pure Freude am Werkstoff zum Ausdruck und kommentiert damit auch den oftmals kompromittierten Wert von massenproduzierter Ware.
<G-vec00161-002-s441><comment.kommentieren><en> Follow my Instagram: @gregory_van_w, like and share the current picture and comment underneath, as you can do on Facebook!
<G-vec00161-002-s441><comment.kommentieren><de> Folgt meiner Instagramseite @gregory_van_w, liked und teilt das aktuelle Blogpost-Foto und kommentiert wie oben beschrieben.
<G-vec00161-002-s442><comment.kommentieren><en> In addition, following a comment of TechRadar, the keyboard features a new and larger island style with significantly bigger keys and more spacing between each key.
<G-vec00161-002-s442><comment.kommentieren><de> Zudem kommentiert TechRadar, dass die Tastatur über ein neues und größeres Isolationsdesign mit deutlich größeren Tasten und mehr Tastenzwischenraum verfügt.
<G-vec00161-002-s443><comment.kommentieren><en> Less You don’t have to leave Word to contact people who comment on a Word 2013 document.
<G-vec00161-002-s443><comment.kommentieren><de> Weniger Sie müssen Word nicht verlassen, um Personen zu kontaktieren, die ein Word 2013-Dokument kommentiert haben.
<G-vec00161-002-s444><comment.kommentieren><en> Tap the post you don't want people to comment on.
<G-vec00161-002-s444><comment.kommentieren><de> Tippen Sie auf den Beitrag, den Sie kommentiert haben.
<G-vec00161-002-s445><comment.kommentieren><en> If you want to improve the turnout of your Q&A session, you might choose to offer a prize to one of the people who comment and ask you a question.
<G-vec00161-002-s445><comment.kommentieren><de> Wenn Du die Beteiligung an Deiner Frage-und-Antwort-Runde verbessern möchtest, könntest Du einen Preis unter den Leuten verlosen, die kommentiert und eine Frage gestellt haben.
<G-vec00161-002-s446><comment.kommentieren><en> YouTube is a video portal that allows you to watch, rate, comment and self-upload video clips for free.
<G-vec00161-002-s446><comment.kommentieren><de> Bei YouTube handelt es sich um ein Videoportal, auf dem kostenlos Videoclips angesehen, bewertet, kommentiert und selbst hochgeladen werden können.
<G-vec00161-002-s447><comment.kommentieren><en> You can comment on the manual re-evaluation of individual inspection features and the global tolerance status.
<G-vec00161-002-s447><comment.kommentieren><de> Die manuellen Nachbewertungen einzelner Prüfmerkmale und des globalen Tolerierungsstatus können kommentiert werden.
<G-vec00161-002-s448><comment.kommentieren><en> This is only the second time in seven years that someone has made a comment about the curtains, both times during the height of summer and the long days - a time when you do not want heavier fabric, because it is so hot.
<G-vec00161-002-s448><comment.kommentieren><de> Dies ist erst das zweite Mal in sieben Jahren, dass jemand die Vorhänge kommentiert, beide Male während des Hochsommers und der langen Tage - einer Zeit, wenn man keinen dickeren Stoff will, weil es so heiß ist.
<G-vec00161-002-s449><comment.kommentieren><en> Heiko Schiffer said that his rounds use the word “practical constraint” to comment a situation when there are so many goods on an action space that a player spontaneously defects from the originally planned move.
<G-vec00161-002-s449><comment.kommentieren><de> Heiko Schiffer meinte, dass in seinen Runden mit dem Wort „Sachzwänge“ kommentiert wird, wenn auf einem Aktionsfeld so viele Waren liegen, dass vom geplanten Spielzug spontan abgewichen wird.
<G-vec00161-002-s450><comment.kommentieren><en> No need to comment on this one.
<G-vec00161-002-s450><comment.kommentieren><de> Das muss nicht kommentiert werden.
<G-vec00161-002-s451><comment.kommentieren><en> The account allows you to build a library of favorites, rate and comment on content, and the option to download clips in a variety of formats.
<G-vec00161-002-s451><comment.kommentieren><de> Das Konto ermöglicht dir eine Favoritenbibliothek aufzubauen, bewertet und kommentiert nach Inhalt, und die Option Clips in einer Vielfalt von Formaten downzuloaden.
<G-vec00161-002-s452><comment.kommentieren><en> People share articles, express their opinions through them, and often comment on each other’s posts.
<G-vec00161-002-s452><comment.kommentieren><de> Dort teilt man Artikel, sagt seine Meinung und kommentiert einander oft.
<G-vec00161-002-s453><comment.kommentieren><en> Former Dimmu Borgir and current Borknagar/Arcturus member ICS Vortex has checked in to comment as follows about the tour: "Susperia and ICS Vortex are taking Rendezvous Point out for a melodic metal ride covering four winter weekends around Norway.
<G-vec00161-002-s453><comment.kommentieren><de> Ex-Dimmu Borgir und aktuell Borknagar/Arcturus Mitglied ICS Vortex kommentiert wie folgt: "Susperia und ICS Vortex werden Rendezvous Point auf eine Melodic Metal-Reise mitnehmen, welche vier Winterwochenenden in Norwegen umfassen wird.
<G-vec00161-002-s454><comment.kommentieren><en> Pierino doesn’t mind the camera, because he likes to comment on what he experiences.
<G-vec00161-002-s454><comment.kommentieren><de> Pierino lässt sich von der Kamera nicht stören, denn er kommentiert gern, was er erlebt.
<G-vec00161-002-s522><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s522><comment.kommentieren><de> No Mail * Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s523><comment.kommentieren><en> Website Save my name, email, and site URL in my browser for next time I post a comment.
<G-vec00161-002-s523><comment.kommentieren><de> E-mail Website Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s524><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s524><comment.kommentieren><de> BUCHUNG Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s525><comment.kommentieren><en> Website Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s525><comment.kommentieren><de> Der Pulli Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s526><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s526><comment.kommentieren><de> E-Mail-Adresse * Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s527><comment.kommentieren><en> Website Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s527><comment.kommentieren><de> Name E-Mail-Adresse Website Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s528><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s528><comment.kommentieren><de> I Mail * Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s529><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s529><comment.kommentieren><de> Enter your name or Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s530><comment.kommentieren><en> Please enter your email address here Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s530><comment.kommentieren><de> Please enter your name Speichere meinen Namen, E-Mail-Adresse und Website in diesem Browser für das nächste Mal, wenn ich wieder kommentiere.
<G-vec00161-002-s531><comment.kommentieren><en> my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s531><comment.kommentieren><de> E-Mail * Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s533><comment.kommentieren><en> ← OLPC-Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s533><comment.kommentieren><de> E-Mail * Website Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s534><comment.kommentieren><en> Website Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s534><comment.kommentieren><de> A Mail * Website Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s535><comment.kommentieren><en> E-Mail* Website Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s535><comment.kommentieren><de> E-Mail-Adresse* Webseite Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s536><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s536><comment.kommentieren><de> So verhinderst du, dass dein Mac Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s537><comment.kommentieren><en> Email * Website Save my name, e-mail, and website in this browser for the next time I comment.
<G-vec00161-002-s537><comment.kommentieren><de> E–Mail* Webseite: Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s538><comment.kommentieren><en> Save my name and email in this browser for the next time I comment. Publish You Might Also Enjoy:
<G-vec00161-002-s538><comment.kommentieren><de> Tags:Afrika Rundreisen, Asia Reisen, Indien Meinen Namen und E-Mail in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s539><comment.kommentieren><en> Reply Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s539><comment.kommentieren><de> Kommentare Cancel Reply Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s540><comment.kommentieren><en> Save my name, email, and website in this browser for the next time I comment.
<G-vec00161-002-s540><comment.kommentieren><de> Deine Meinen Namen, E-Mail und Website in diesem Browser speichern, bis ich wieder kommentiere.
<G-vec00161-002-s541><comment.sich_äußern><en> The NSA has declined to comment on operational details but insists that it has not violated the law.
<G-vec00161-002-s541><comment.sich_äußern><de> Die NSA will sich, wie üblich, zu operativen Details nicht äußern, beteuert aber, dass man sich strikt an die Gesetze halte.
<G-vec00161-002-s542><comment.sich_äußern><en> The same applies to Koelnmesse, who are likewise not willing to comment on the proceedings - which are, incidentally, just one case among some 700 public procurement infringement proceedings.
<G-vec00161-002-s542><comment.sich_äußern><de> Gleiches gilt für die Koelnmesse, die sich zu dem Verfahren - übrigens eines von rund 700 Vergaberechtsverfahren in den EU-Mitgliedstaaten - ebenfalls nicht äußern will.
<G-vec00161-002-s546><comment.sich_äußern><en> UBS declined to comment.
<G-vec00161-002-s546><comment.sich_äußern><de> Ein UBS-Sprecher wollte sich nicht äußern.
<G-vec00161-002-s547><comment.sich_äußern><en> Furthermore, the Bundesbank itself would have to comment on this.
<G-vec00161-002-s547><comment.sich_äußern><de> Im Übrigen müsste sich dazu die Bundesbank selbst äußern.
<G-vec00161-002-s548><comment.sich_äußern><en> In her view, the reporting gave a distorted picture of Muslims as they generally did not have the chance to comment on these events.
<G-vec00161-002-s548><comment.sich_äußern><de> Die Berichterstattung über diese Ereignisse führte in ihren Augen zu einem verzerrten Bild über Muslime, weil diese nicht die Möglichkeit erhalten hätten, sich zu den Geschehnissen zu äußern.
<G-vec00161-002-s549><comment.sich_äußern><en> There was no answer from Moscow, but Hilmar L.’s lawyer said via telephone that his client would not comment on the case.
<G-vec00161-002-s549><comment.sich_äußern><de> Aus Moskau kam keine Antwort, aber Hilmar L.s Anwalt erklärt telefonisch, dass sich sein Mandant nicht zu der Sache äußern werde.
<G-vec00161-002-s550><comment.sich_äußern><en> Who already had colonoscopy knows what preparations are necessary and I do not want to comment further about it.
<G-vec00161-002-s550><comment.sich_äußern><de> Wer bereits Darmspiegelung hatte, weiß, welche Vorbereitungen erforderlich sind und ich möchte mich nicht weiter darüber äußern.
<G-vec00161-002-s551><comment.sich_äußern><en> EgyptDivers.com may ask customers to comment on all aspects of the Services, and may post such reviews on the Site.
<G-vec00161-002-s551><comment.sich_äußern><de> EgyptDivers.com kann Kunden bitten, sich zu allen Aspekten der Services zu äußern, und solche Reviews auf der Site veröffentlichen.
<G-vec00161-002-s552><comment.sich_äußern><en> Please comment on what you think about this.
<G-vec00161-002-s552><comment.sich_äußern><de> Bitte äußern Sie sich, was Sie darüber denken.
<G-vec00161-002-s553><comment.sich_äußern><en> The owner must be given the possibility in each case to comment on the situation and may appeal against the police’s decision.
<G-vec00161-002-s553><comment.sich_äußern><de> Der Besitzer muss in jedem Fall die Möglichkeit erhalten, sich zum Sachverhalt zu äußern und kann Klage gegen die Entscheidung der Polizei einlegen.
<G-vec00161-002-s554><comment.sich_äußern><en> People across the EU will then have three months to comment.
<G-vec00161-002-s554><comment.sich_äußern><de> EU-weit werden die Bürgerinnen und Bürger dann drei Monate Zeit haben, sich dazu zu äußern.
<G-vec00161-002-s555><comment.sich_äußern><en> A Commission spokesman did not want to comment on this.
<G-vec00161-002-s555><comment.sich_äußern><de> Ein Sprecher der Kommission wollte sich dazu nicht äußern.
<G-vec00161-002-s556><comment.sich_äußern><en> Mr Alessi, who lives in Palm Beach, declined to comment when approached by The Sun.
<G-vec00161-002-s556><comment.sich_äußern><de> Herr Alessi, der in Palm Beach lebt, lehnte es ab, sich zu äußern, als er von The Sun angesprochen wurde.
<G-vec00161-002-s557><comment.sich_äußern><en> And an official at the royal palace declined to comment.
<G-vec00161-002-s557><comment.sich_äußern><de> Das Königshaus wollte sich dazu zunächst nicht äußern.
<G-vec00161-002-s558><comment.sich_äußern><en> The company will not further comment any details.
<G-vec00161-002-s558><comment.sich_äußern><de> Das Unternehmen wird sich zu weiteren Einzelheiten nicht äußern.
<G-vec00161-002-s559><comment.sich_äußern><en> But the newly filed tests raised an admissibility issue: whether they merely helped the appellant to overcome the board's objection – which R 16/13 had said it could comment on – or whether they went further and would thus extend the subject-matter of the resumed proceedings beyond that specified in the petition for review decided on in R 16/13.
<G-vec00161-002-s559><comment.sich_äußern><de> In Bezug auf die Zulassung der neu eingereichten Vergleichsversuche stellte sich allerdings die Frage, ob diese nur die Entgegnung zum Einwand der Kammer stützten, zu dem sich der Beschwerdeführer gemäß der Entscheidung R 16/13 äußern können sollte, oder ob sie darüber hinausgingen und so den Gegenstand des wiedereröffneten Verfahrens erweiterte, wie er durch den Antrag auf Überprüfung und die gestützt darauf ergangene Entscheidung R 16/13 vorgegeben ist.
<G-vec00161-002-s541><comment.äußern><en> The NSA has declined to comment on operational details but insists that it has not violated the law.
<G-vec00161-002-s541><comment.äußern><de> Die NSA will sich, wie üblich, zu operativen Details nicht äußern, beteuert aber, dass man sich strikt an die Gesetze halte.
<G-vec00161-002-s542><comment.äußern><en> The same applies to Koelnmesse, who are likewise not willing to comment on the proceedings - which are, incidentally, just one case among some 700 public procurement infringement proceedings.
<G-vec00161-002-s542><comment.äußern><de> Gleiches gilt für die Koelnmesse, die sich zu dem Verfahren - übrigens eines von rund 700 Vergaberechtsverfahren in den EU-Mitgliedstaaten - ebenfalls nicht äußern will.
<G-vec00161-002-s543><comment.äußern><en> Regarding the procedure to be followed for applying jurisdictional measures in response to requests as described by the Legal Board, the question arises of whether all the EPC rules governing normal proceedings before the boards of appeal must be applied; this concerns in particular the right of other parties to comment on the requests, the observation of minimum time limits or the right to request oral proceedings.
<G-vec00161-002-s543><comment.äußern><de> Was das Verfahren für die gerichtliche Behandlung von Anträgen der von der Juristischen Beschwerdekammer umschriebenen Art betrifft, stellt sich die Frage, ob dabei alle auf die ordnungsgemäßen Verfahren vor den Beschwerdekammern anwendbaren Regeln des EPÜ, insbesondere solche, die das Recht der anderen Beteiligten, sich zu den Anträgen zu äußern, die Einhaltung der Mindestfristen oder auch das Recht auf eine mündliche Verhandlung betreffen, angewendet werden müssen.
<G-vec00161-002-s544><comment.äußern><en> The Alliance does not want to comment on this request.
<G-vec00161-002-s544><comment.äußern><de> Dazu äußern will sich das Bündnis auf Anfrage nicht.
<G-vec00161-002-s545><comment.äußern><en> The Board may, on its own initiative or at the written, reasoned request of the President of the European Patent Office, invite him to comment in writing or orally on questions of general interest which arise in the course of proceedings pending before it.
<G-vec00161-002-s545><comment.äußern><de> Die Kammer kann den Präsidenten des Europäischen Patentamts von Amts wegen oder auf dessen schriftlichen, begründeten Antrag auffordern, sich zu Fragen von allgemeinem Interesse, die sich im Rahmen eines vor der Kammer anhängigen Verfahrens stellen, schriftlich oder mündlich zu äußern.
<G-vec00161-002-s546><comment.äußern><en> UBS declined to comment.
<G-vec00161-002-s546><comment.äußern><de> Ein UBS-Sprecher wollte sich nicht äußern.
<G-vec00161-002-s547><comment.äußern><en> Furthermore, the Bundesbank itself would have to comment on this.
<G-vec00161-002-s547><comment.äußern><de> Im Übrigen müsste sich dazu die Bundesbank selbst äußern.
<G-vec00161-002-s548><comment.äußern><en> In her view, the reporting gave a distorted picture of Muslims as they generally did not have the chance to comment on these events.
<G-vec00161-002-s548><comment.äußern><de> Die Berichterstattung über diese Ereignisse führte in ihren Augen zu einem verzerrten Bild über Muslime, weil diese nicht die Möglichkeit erhalten hätten, sich zu den Geschehnissen zu äußern.
<G-vec00161-002-s549><comment.äußern><en> There was no answer from Moscow, but Hilmar L.’s lawyer said via telephone that his client would not comment on the case.
<G-vec00161-002-s549><comment.äußern><de> Aus Moskau kam keine Antwort, aber Hilmar L.s Anwalt erklärt telefonisch, dass sich sein Mandant nicht zu der Sache äußern werde.
<G-vec00161-002-s550><comment.äußern><en> Who already had colonoscopy knows what preparations are necessary and I do not want to comment further about it.
<G-vec00161-002-s550><comment.äußern><de> Wer bereits Darmspiegelung hatte, weiß, welche Vorbereitungen erforderlich sind und ich möchte mich nicht weiter darüber äußern.
<G-vec00161-002-s551><comment.äußern><en> EgyptDivers.com may ask customers to comment on all aspects of the Services, and may post such reviews on the Site.
<G-vec00161-002-s551><comment.äußern><de> EgyptDivers.com kann Kunden bitten, sich zu allen Aspekten der Services zu äußern, und solche Reviews auf der Site veröffentlichen.
<G-vec00161-002-s552><comment.äußern><en> Please comment on what you think about this.
<G-vec00161-002-s552><comment.äußern><de> Bitte äußern Sie sich, was Sie darüber denken.
<G-vec00161-002-s553><comment.äußern><en> The owner must be given the possibility in each case to comment on the situation and may appeal against the police’s decision.
<G-vec00161-002-s553><comment.äußern><de> Der Besitzer muss in jedem Fall die Möglichkeit erhalten, sich zum Sachverhalt zu äußern und kann Klage gegen die Entscheidung der Polizei einlegen.
<G-vec00161-002-s554><comment.äußern><en> People across the EU will then have three months to comment.
<G-vec00161-002-s554><comment.äußern><de> EU-weit werden die Bürgerinnen und Bürger dann drei Monate Zeit haben, sich dazu zu äußern.
<G-vec00161-002-s555><comment.äußern><en> A Commission spokesman did not want to comment on this.
<G-vec00161-002-s555><comment.äußern><de> Ein Sprecher der Kommission wollte sich dazu nicht äußern.
<G-vec00161-002-s556><comment.äußern><en> Mr Alessi, who lives in Palm Beach, declined to comment when approached by The Sun.
<G-vec00161-002-s556><comment.äußern><de> Herr Alessi, der in Palm Beach lebt, lehnte es ab, sich zu äußern, als er von The Sun angesprochen wurde.
<G-vec00161-002-s557><comment.äußern><en> And an official at the royal palace declined to comment.
<G-vec00161-002-s557><comment.äußern><de> Das Königshaus wollte sich dazu zunächst nicht äußern.
<G-vec00161-002-s558><comment.äußern><en> The company will not further comment any details.
<G-vec00161-002-s558><comment.äußern><de> Das Unternehmen wird sich zu weiteren Einzelheiten nicht äußern.
<G-vec00161-002-s559><comment.äußern><en> But the newly filed tests raised an admissibility issue: whether they merely helped the appellant to overcome the board's objection – which R 16/13 had said it could comment on – or whether they went further and would thus extend the subject-matter of the resumed proceedings beyond that specified in the petition for review decided on in R 16/13.
<G-vec00161-002-s559><comment.äußern><de> In Bezug auf die Zulassung der neu eingereichten Vergleichsversuche stellte sich allerdings die Frage, ob diese nur die Entgegnung zum Einwand der Kammer stützten, zu dem sich der Beschwerdeführer gemäß der Entscheidung R 16/13 äußern können sollte, oder ob sie darüber hinausgingen und so den Gegenstand des wiedereröffneten Verfahrens erweiterte, wie er durch den Antrag auf Überprüfung und die gestützt darauf ergangene Entscheidung R 16/13 vorgegeben ist.
<G-vec00994-002-s474><comment.(sich)_nehmen><en> A decision to maintain the patent in amended form may be delivered only when the patent proprietor has approved the text in which the Opposition Division proposes to maintain the patent and the opponent has had sufficient opportunity to comment on the proposed new text.
<G-vec00994-002-s474><comment.(sich)_nehmen><de> Die Entscheidung über die Aufrechterhaltung des Patents in geändertem Umfang darf erst ergehen, wenn das Einverständnis des Patentinhabers zu der Fassung vorliegt, in der die Einspruchsabteilung das Patent aufrechtzuerhalten beabsichtigt, und der Einsprechende in angemessener Weise Gelegenheit gehabt hat, zu dieser Fassung Stellung zu nehmen.
<G-vec00994-002-s475><comment.(sich)_nehmen><en> The bank declined to comment on this.
<G-vec00994-002-s475><comment.(sich)_nehmen><de> Dazu wollte die Bank nicht öffentlich Stellung nehmen.
<G-vec00994-002-s476><comment.(sich)_nehmen><en> The ECJ was not required to comment on the question as to when an invoice needs to be corrected.
<G-vec00994-002-s476><comment.(sich)_nehmen><de> Der EuGH musste zur Frage des Zeitpunkts, bis zu dem eine Rechnungsberichtigung zu erfolgen hat, nicht Stellung nehmen.
<G-vec00994-002-s477><comment.(sich)_nehmen><en> Even under the revised provision of 2013, the Academic Senate is merely permitted to comment on this appointment.
<G-vec00994-002-s477><comment.(sich)_nehmen><de> Der Senat kann zu der Bestellung auch nach der 2013 neu gefassten Regelung nur Stellung nehmen.
<G-vec00994-002-s478><comment.(sich)_nehmen><en> Each seminar participant will have an opportunity to comment briefly on the video tutorial of his or her choice and to answer guests’ questions.
<G-vec00994-002-s478><comment.(sich)_nehmen><de> Jede/r SeminarteilnehmerIn wird Gelegenheit haben, kurz Stellung zum Video-Tutorial seiner/ihrer Wahl zu nehmen und Fragen der Gäste zu beantworten.
<G-vec00994-002-s479><comment.(sich)_nehmen><en> It would not be appropriate to comment on individual cases."
<G-vec00994-002-s479><comment.(sich)_nehmen><de> Allerdings sei es nicht angemessen, zu individuellen Strafverfahren Stellung zu nehmen.
<G-vec00994-002-s480><comment.(sich)_nehmen><en> As we are sure you realize, because of the need for maintaining confidentiality on matters of this nature, we cannot comment on the details of any specific case, including your father's.
<G-vec00994-002-s480><comment.(sich)_nehmen><de> Da es notwendig ist, in Dingen wie diesen die Vertraulichkeit zu wahren, sind wir sicher, dass Du verstehst, dass wir bei keinem Fall, auch nicht bei dem Deines Vaters, zu Einzelheiten Stellung nehmen können.
<G-vec00994-002-s481><comment.(sich)_nehmen><en> After the European Court of Justice (ECJ) had in the meantime commented on the relevant questions in the much publicized VALE decision, the OLG in Nuremberg had the opportunity to comment on such transaction again.
<G-vec00994-002-s481><comment.(sich)_nehmen><de> Nachdem zwischenzeitlich der EuGH im Rahmen der vielbeachteten VALE-Entscheidung zu den einschlägigen Fragen Stellung genommen hatte, hatte das OLG Nürnberg nunmehr mit einer jüngst veröffentlichten Entscheidung aus dem Jahre 2013 erneut Gelegenheit, zur grenzüberschreitenden Sitzverlegung Stellung zu nehmen.
<G-vec00994-002-s482><comment.(sich)_nehmen><en> Feel free to comment on existing bugs or ideas - we will use the amount of discussion on bugs and ideas to help determine their priority.
<G-vec00994-002-s482><comment.(sich)_nehmen><de> Fühlen Sie sich frei, zu bestehenden Fehlern oder Ideen Stellung zu nehmen - wir werden die Menge der Diskussion über Fehler und Ideen nutzen, um ihre Priorität zu bestimmen.
<G-vec00994-002-s483><comment.(sich)_nehmen><en> 6.1 The applicant may comment in writing on the reply to the request within two weeks after its receipt.
<G-vec00994-002-s483><comment.(sich)_nehmen><de> 6.1 Der Antragsteller kann innerhalb von zwei Wochen nach Empfang der Antragserwiderung schriftlich Stellung nehmen.
<G-vec00994-002-s484><comment.(sich)_nehmen><en> RT reached out to the company about the matter, but Lufthansa declined to comment.
<G-vec00994-002-s484><comment.(sich)_nehmen><de> RT wandte sich in dieser Angelegenheit an das Unternehmen, die Lufthansa weigerte sich jedoch, gegenwärtig dazu Stellung zu nehmen.
<G-vec00994-002-s485><comment.(sich)_nehmen><en> The written notice should allow the economic operator to comment on all relevant aspects of the intended decision restricting access to the market.
<G-vec00994-002-s485><comment.(sich)_nehmen><de> Der Wirtschaftsteilnehmer sollte anhand der schriftlichen Mitteilung zu allen relevanten Aspekten der beabsichtigten Entscheidung, den Marktzugang zu beschränken, Stellung nehmen können.
<G-vec00994-002-s486><comment.(sich)_nehmen><en> // On one page per day I can comment on my day.
<G-vec00994-002-s486><comment.(sich)_nehmen><de> // Jeweils auf einer Seite kann man zu seinem Tag Stellung nehmen.
<G-vec00994-002-s487><comment.(sich)_nehmen><en> 4a. The European Data Protection Board shall, where appropriate, consult interested parties and give them the opportunity to comment within a reasonable period.
<G-vec00994-002-s487><comment.(sich)_nehmen><de> (4) Der Ausschuss konsultiert gegebenenfalls interessierte Kreise und gibt ihnen Gelegenheit, innerhalb einer angemessenen Frist Stellung zu nehmen.
<G-vec00994-002-s488><comment.(sich)_nehmen><en> In such case we can comment on the correctness.
<G-vec00994-002-s488><comment.(sich)_nehmen><de> Diesfalls können wir zu deren Richtigkeit Stellung nehmen.
<G-vec00994-002-s234><comment.hinterlassen><en> [[We invite you to ask questions or give your opinion about this project by adding a comment.
<G-vec00994-002-s234><comment.hinterlassen><de> Wir laden Sie ein, Fragen zu stellen oder Ihre Meinung zu diesem Projekt abzugeben, indem Sie einen Kommentar hinterlassen.
<G-vec00994-002-s235><comment.hinterlassen><en> If you run into any issues or questions why not drop our expert customer service a note or live chat, or leave a comment below?
<G-vec00994-002-s235><comment.hinterlassen><de> Wenn Sie auf Probleme oder Fragen stoßen, können Sie unserem Experten-Kundendienst eine Notiz oder einen Live-Chat überlassen oder einen Kommentar hinterlassen.
<G-vec00994-002-s236><comment.hinterlassen><en> In addition to those four answers test persons can also add a comment on their previous minute of game play and praise or criticize the game experience.
<G-vec00994-002-s236><comment.hinterlassen><de> Neben den vier Fragen kann der Proband einen Kommentar zur letzten Spielminute hinterlassen.
<G-vec00994-002-s237><comment.hinterlassen><en> Jerrymazza only discloses logged in user and commenter IP addresses under the same circumstances that it uses and discloses personally-identifying information as described below, except that commenter IP addresses and email addresses are visible and disclosed to the administrators of the blog/site where the comment was left. Gathering of Personally-Identifying Information
<G-vec00994-002-s237><comment.hinterlassen><de> Branding Brands gibt eingeloggte Benutzer- und Kommentator-IP-Adressen nur unter den gleichen Umständen weiter, unter denen sie personenbezogene Informationen wie unten beschrieben verwendet und weitergibt, mit der Ausnahme, dass die IP-Adressen und E-Mail-Adressen der Kommentatoren sichtbar sind und den Administratoren des Blogs/der Website, auf der der Kommentar hinterlassen wurde, mitgeteilt werden.
<G-vec00994-002-s238><comment.hinterlassen><en> If you post a comment on our site, you will be asked to save your name, e-mail address and website in cookies.
<G-vec00994-002-s238><comment.hinterlassen><de> Wenn Sie einen Kommentar auf unserer Website hinterlassen, können Sie der Speicherung Ihres Namens, Ihrer E-Mail-Adresse und Ihrer Website in Form von Cookies zustimmen.
<G-vec00994-002-s239><comment.hinterlassen><en> Add a comment Click here to cancel reply.
<G-vec00994-002-s239><comment.hinterlassen><de> Kommentar hinterlassen Hier klicken, um die Antwort abzubrechen.
<G-vec00994-002-s240><comment.hinterlassen><en> You must be logged in to post a comment.
<G-vec00994-002-s240><comment.hinterlassen><de> Dort hast du die Möglichkeit einen Kommentar zu hinterlassen.
<G-vec00994-002-s241><comment.hinterlassen><en> This comment has been deleted by the user.
<G-vec00994-002-s241><comment.hinterlassen><de> Es wurde noch kein Kommentar hinterlassen.
<G-vec00994-002-s242><comment.hinterlassen><en> When a comment is added on the Adblock Plus blog an email address can optionally be specified.
<G-vec00994-002-s242><comment.hinterlassen><de> Wenn ein Kommentar im Adblock Plus-Blog hinterlassen wird, kann eine E-Mail-Adresse optional angegben werden.
<G-vec00994-002-s243><comment.hinterlassen><en> Share your thoughts with us by leaving a comment below.
<G-vec00994-002-s243><comment.hinterlassen><de> Teilen Sie uns Ihre Meinung mit, indem Sie einen Kommentar hinterlassen.
<G-vec00994-002-s244><comment.hinterlassen><en> Customers can also provide a comment if they want.
<G-vec00994-002-s244><comment.hinterlassen><de> Auf Wunsch können Kunden auch einen Kommentar hinterlassen.
<G-vec00994-002-s245><comment.hinterlassen><en> New task type ‘Call’ – you can add client’s number, set time and include a comment.
<G-vec00994-002-s245><comment.hinterlassen><de> Ein neuer Aufgabentyp "Anrufen" - Sie können eine Kundennummer hinzufügen, die Uhrzeit einstellen und einen Kommentar hinterlassen.
<G-vec00994-002-s246><comment.hinterlassen><en> Information that comes from interacting with the Google+ plugins (by clicking on the “+1” button or by leaving a comment) will be directly transferred to and stored by Google.
<G-vec00994-002-s246><comment.hinterlassen><de> Die Informationen, die sich aus der Interaktion mit den Plugins von Google+ ergeben (indem Sie auf die Schaltfläche "+1" klicken oder einen Kommentar hinterlassen), werden direkt übertragen und von Google gespeichert.
<G-vec00994-002-s247><comment.hinterlassen><en> You must be logged in to post a comment.
<G-vec00994-002-s247><comment.hinterlassen><de> Du musst eingeloggt sein um einen Kommentar hinterlassen zu können.
<G-vec00994-002-s248><comment.hinterlassen><en> Logis Hostellerie This customer has ranked the hotel without leaving any comment.
<G-vec00994-002-s248><comment.hinterlassen><de> Der Hotelgast hat das Hotel beurteilt ohne einen Kommentar hinterlassen zu haben.
<G-vec00994-002-s249><comment.hinterlassen><en> You must be logged in to post a comment.
<G-vec00994-002-s249><comment.hinterlassen><de> Du musst eingeloggt sein um einen Kommentar zu hinterlassen.
<G-vec00994-002-s250><comment.hinterlassen><en> And I would be more than happy, if you choose to spread some love in the comment section of my blog.
<G-vec00994-002-s250><comment.hinterlassen><de> Und ich wäre mehr als glücklich, wenn Ihr Euch dazu aufraffen könntet ab und zu mal einen lieben Kommentar auf meinem Blog zu hinterlassen.
<G-vec00994-002-s252><comment.hinterlassen><en> 3.Please contact us before you leaving the negative or neutral comment so that we can solve the problem in the best way.
<G-vec00994-002-s252><comment.hinterlassen><de> 3.Bitte kontaktieren Sie uns, bevor Sie den negativen oder neutralen Kommentar hinterlassen, damit wir das Problem auf die beste Weise lösen können.
<G-vec00994-002-s475><comment.nehmen><en> The bank declined to comment on this.
<G-vec00994-002-s475><comment.nehmen><de> Dazu wollte die Bank nicht öffentlich Stellung nehmen.
<G-vec00994-002-s476><comment.nehmen><en> The ECJ was not required to comment on the question as to when an invoice needs to be corrected.
<G-vec00994-002-s476><comment.nehmen><de> Der EuGH musste zur Frage des Zeitpunkts, bis zu dem eine Rechnungsberichtigung zu erfolgen hat, nicht Stellung nehmen.
<G-vec00994-002-s477><comment.nehmen><en> Even under the revised provision of 2013, the Academic Senate is merely permitted to comment on this appointment.
<G-vec00994-002-s477><comment.nehmen><de> Der Senat kann zu der Bestellung auch nach der 2013 neu gefassten Regelung nur Stellung nehmen.
<G-vec00994-002-s478><comment.nehmen><en> Each seminar participant will have an opportunity to comment briefly on the video tutorial of his or her choice and to answer guests’ questions.
<G-vec00994-002-s478><comment.nehmen><de> Jede/r SeminarteilnehmerIn wird Gelegenheit haben, kurz Stellung zum Video-Tutorial seiner/ihrer Wahl zu nehmen und Fragen der Gäste zu beantworten.
<G-vec00994-002-s479><comment.nehmen><en> It would not be appropriate to comment on individual cases."
<G-vec00994-002-s479><comment.nehmen><de> Allerdings sei es nicht angemessen, zu individuellen Strafverfahren Stellung zu nehmen.
<G-vec00994-002-s480><comment.nehmen><en> As we are sure you realize, because of the need for maintaining confidentiality on matters of this nature, we cannot comment on the details of any specific case, including your father's.
<G-vec00994-002-s480><comment.nehmen><de> Da es notwendig ist, in Dingen wie diesen die Vertraulichkeit zu wahren, sind wir sicher, dass Du verstehst, dass wir bei keinem Fall, auch nicht bei dem Deines Vaters, zu Einzelheiten Stellung nehmen können.
<G-vec00994-002-s481><comment.nehmen><en> After the European Court of Justice (ECJ) had in the meantime commented on the relevant questions in the much publicized VALE decision, the OLG in Nuremberg had the opportunity to comment on such transaction again.
<G-vec00994-002-s481><comment.nehmen><de> Nachdem zwischenzeitlich der EuGH im Rahmen der vielbeachteten VALE-Entscheidung zu den einschlägigen Fragen Stellung genommen hatte, hatte das OLG Nürnberg nunmehr mit einer jüngst veröffentlichten Entscheidung aus dem Jahre 2013 erneut Gelegenheit, zur grenzüberschreitenden Sitzverlegung Stellung zu nehmen.
<G-vec00994-002-s482><comment.nehmen><en> Feel free to comment on existing bugs or ideas - we will use the amount of discussion on bugs and ideas to help determine their priority.
<G-vec00994-002-s482><comment.nehmen><de> Fühlen Sie sich frei, zu bestehenden Fehlern oder Ideen Stellung zu nehmen - wir werden die Menge der Diskussion über Fehler und Ideen nutzen, um ihre Priorität zu bestimmen.
<G-vec00994-002-s484><comment.nehmen><en> RT reached out to the company about the matter, but Lufthansa declined to comment.
<G-vec00994-002-s484><comment.nehmen><de> RT wandte sich in dieser Angelegenheit an das Unternehmen, die Lufthansa weigerte sich jedoch, gegenwärtig dazu Stellung zu nehmen.
<G-vec00994-002-s485><comment.nehmen><en> The written notice should allow the economic operator to comment on all relevant aspects of the intended decision restricting access to the market.
<G-vec00994-002-s485><comment.nehmen><de> Der Wirtschaftsteilnehmer sollte anhand der schriftlichen Mitteilung zu allen relevanten Aspekten der beabsichtigten Entscheidung, den Marktzugang zu beschränken, Stellung nehmen können.
<G-vec00994-002-s486><comment.nehmen><en> // On one page per day I can comment on my day.
<G-vec00994-002-s486><comment.nehmen><de> // Jeweils auf einer Seite kann man zu seinem Tag Stellung nehmen.
<G-vec00994-002-s487><comment.nehmen><en> 4a. The European Data Protection Board shall, where appropriate, consult interested parties and give them the opportunity to comment within a reasonable period.
<G-vec00994-002-s487><comment.nehmen><de> (4) Der Ausschuss konsultiert gegebenenfalls interessierte Kreise und gibt ihnen Gelegenheit, innerhalb einer angemessenen Frist Stellung zu nehmen.
<G-vec00994-002-s488><comment.nehmen><en> In such case we can comment on the correctness.
<G-vec00994-002-s488><comment.nehmen><de> Diesfalls können wir zu deren Richtigkeit Stellung nehmen.
<G-vec00994-002-s253><comment.schreiben><en> Log in to enter a comment through a free account or register if you are not a member.
<G-vec00994-002-s253><comment.schreiben><de> Identifizieren Sie sich um über ein kostenloses Konto einen Kommentar zu schreiben, oder registrieren Sie sich, wenn Sie noch nicht Mitglied sind.
<G-vec00994-002-s254><comment.schreiben><en> Also, if you don’t feel really inspired for your “ice breaking” approach, you can simply look at their profile pictures and make a comment about these pictures.
<G-vec00994-002-s254><comment.schreiben><de> Wenn Sie sich nicht wirklich für Ihren Eisbrecher-Ansatz inspiriert fühlen, können Sie sich einfach die Profilbilder ansehen und einen Kommentar zu denen schreiben.
<G-vec00994-002-s255><comment.schreiben><en> Leave comment and suggestions.
<G-vec00994-002-s255><comment.schreiben><de> Kommentar schreiben und Anregungen.
<G-vec00994-002-s256><comment.schreiben><en> If a diagram element is selected while you are writing a comment, the comment will be attached to the corresponding element.
<G-vec00994-002-s256><comment.schreiben><de> Hinweis Wenn ein Diagramm-Element ausgewählt wird, während Sie einen Kommentar schreiben, wird der Kommentar an das entsprechende Element angehängt.
<G-vec00994-002-s257><comment.schreiben><en> logged in to post a comment.
<G-vec00994-002-s257><comment.schreiben><de> Sie müssen eingeloggt sein um einen Kommentar schreiben.
<G-vec00994-002-s258><comment.schreiben><en> The next time you download a material, you will be able to give it a Reference and Comment.
<G-vec00994-002-s258><comment.schreiben><de> Wenn du danach etwas herunterlädst, kannst du eine Referenz und einen Kommentar zu jedem Download schreiben.
<G-vec00994-002-s259><comment.schreiben><en> Haus Studio. Post a comment or leave a trackback: Trackback URL.
<G-vec00994-002-s259><comment.schreiben><de> Du kannst einen Kommentar schreiben, oder einen Trackback auf deiner Seite einrichten.
<G-vec00994-002-s260><comment.schreiben><en> If you have any questions or further observations please feel free to leave a comment.
<G-vec00994-002-s260><comment.schreiben><de> Wer Fragen und Ergänzungen hat, kann gerne einen Kommentar schreiben.
<G-vec00994-002-s261><comment.schreiben><en> If you elect to comment or engage with our content via third-party social media websites, you authorize Aon to have access to certain social media profile information.
<G-vec00994-002-s261><comment.schreiben><de> Wenn Sie einen Kommentar schreiben oder unsere Inhalte auf Social-Media-Websites Dritter verwenden, ermächtigen Sie Aon den Zugriff auf bestimmte Social-Media-Profilinformationen.
<G-vec00994-002-s262><comment.schreiben><en> Leave a comment Submit Comment Sign up to our newsletter
<G-vec00994-002-s262><comment.schreiben><de> 1 Kommentar Melde Dich an, um einen Kommentar zu schreiben.
<G-vec00994-002-s263><comment.schreiben><en> If you have any questions or remarks just leave a comment below.
<G-vec00994-002-s263><comment.schreiben><de> Falls du irgendwelche Fragen oder Anmerkungen hast, kannst du unten einen Kommentar schreiben.
<G-vec00994-002-s264><comment.schreiben><en> All Photography 9 Comments Sign in to leave a comment.
<G-vec00994-002-s264><comment.schreiben><de> Alle Fotografie 1 Kommentar Melde Dich an, um einen Kommentar zu schreiben.
<G-vec00994-002-s265><comment.schreiben><en> As always, if you’d like to leave a comment, please reply to this email or leave a comment below if you read the blog.
<G-vec00994-002-s265><comment.schreiben><de> Wie immer, wenn Sie einen Kommentar schreiben wollen, antworten Sie auf diese E-Mail, oder schreiben sie einen Kommentar hier drunter, wenn Sie das Blog lesen.
<G-vec00994-002-s266><comment.schreiben><en> Please log in to add your comment.
<G-vec00994-002-s266><comment.schreiben><de> Sie müssen sich anmelden um ein Kommentar zu schreiben.
<G-vec00994-002-s267><comment.schreiben><en> Once the product is purchased, you will be able to leave a comment..
<G-vec00994-002-s267><comment.schreiben><de> Sobald das Produkt gekauft wird, werden Sie in der Lage sein, um einen Kommentar zu schreiben.
<G-vec00994-002-s268><comment.schreiben><en> Enter your comment here...
<G-vec00994-002-s268><comment.schreiben><de> Einen Kommentar schreiben...
<G-vec00994-002-s269><comment.schreiben><en> It’s as easy as going on your salon page to that particular section and post a comment.
<G-vec00994-002-s269><comment.schreiben><de> Es ist so einfach, wie auf der Salonseite einen Kommentar zu einem Post zu schreiben.
<G-vec00994-002-s270><comment.schreiben><en> All Prints 6 Comments Sign in to leave a comment.
<G-vec00994-002-s270><comment.schreiben><de> Alle Druckgrafik 9 Kommentare Melde Dich an, um einen Kommentar zu schreiben.
<G-vec00994-002-s271><comment.schreiben><en> 1 comment Sign in to leave a comment.
<G-vec00994-002-s271><comment.schreiben><de> Fujifilm Melde Dich an, um einen Kommentar zu schreiben.
