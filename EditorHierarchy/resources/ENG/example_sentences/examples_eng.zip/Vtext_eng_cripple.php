<G-vec00656-002-s047><cripple.ausbremsen><en> Neither the fear of trade wars nor the actual slowdown in trade flows was serious enough to cripple global economic activity.
<G-vec00656-002-s047><cripple.ausbremsen><de> Weder die Angst vor Handelskriegen noch die aktuelle Verlangsamung der Handelsströme reichten aus, um die globale Wirtschaftsaktivität auszubremsen.
<G-vec00656-002-s012><cripple.behindern><en> As you are already planning for parties and dinners with your relatives, friends and benefactors for Christmas, recall to mind the instructions given to you by Jesus with regards to holding a banquet inviting the poor, the cripple, the lame and the blind who are unable to give you back anything.
<G-vec00656-002-s012><cripple.behindern><de> Da ihr bereits Pläne schmiedet für Partys und Essen mit euren Verwandten, Freunden und Wohltätern zu Weihnachten, denkt auch an die Anweisungen die Jesus euch gab in Bezug auf das Halten eines Festmahles: ladet die Armen, die Behinderten, die Lahmen und Blinden ein, die euch nichts vergelten können.
<G-vec00656-002-s013><cripple.beschädigen><en> Impedance mismatches between signal sources, loads, and the traces that connect them can ruin signal integrity and cripple your PCB.
<G-vec00656-002-s013><cripple.beschädigen><de> Unstimmigkeiten bei der Impedanz zwischen Signalquellen, Lasten und den Leiterbahnen, an denen sie angeschlossen sind, können die Signalintegrität beeinträchtigen und die Leiterplatte beschädigen.
<G-vec00656-002-s022><cripple.einschränken><en> Without proper forethought for storage, it’s a move that could cripple his creativity.
<G-vec00656-002-s022><cripple.einschränken><de> Ohne eine richtige Planung des Speicherbedarfs könnte dieser Schritt seine Kreativität einschränken.
<G-vec00656-002-s024><cripple.lahmlegen><en> If it finds its way into the switch cabinets, for example, this dust could cripple the electronics.
<G-vec00656-002-s024><cripple.lahmlegen><de> Setzt der sich zum Beispiel in den Schaltschränken ab, könnte er die Elektronik lahmlegen.
<G-vec00656-002-s025><cripple.lahmlegen><en> A power failure or gas leak can cripple entire cities.
<G-vec00656-002-s025><cripple.lahmlegen><de> Ein Strom- oder Gasausfall kann ganze Städte lahmlegen.
<G-vec00656-002-s039><cripple.lahmlegen><en> There is a very high possibility that it will be a geopolitical event to cripple America.
<G-vec00656-002-s039><cripple.lahmlegen><de> Es besteht eine sehr große Chance, dass es ein geopolitisches Ereignis geben könnte, um Amerika lahmzulegen.
<G-vec00656-002-s040><cripple.lahmlegen><en> If such platforms wish, they can cripple those who dissent from their ideological orthodoxy.
<G-vec00656-002-s040><cripple.lahmlegen><de> Wenn solche Plattformen es wünschen, können sie diejenigen lahm legen, die von ihrer ideologischen Orthodoxie abweichen.
<G-vec00656-002-s041><cripple.lahmlegen><en> High speed, high frequency, and low power devices are all susceptible to various signal integrity issues that can cripple your PCB.
<G-vec00656-002-s041><cripple.lahmlegen><de> Geräte mit hoher Geschwindigkeit, hoher Frequenz und niedriger Leistungsaufnahme sind anfällig für diverse Probleme bei der Signalintegrität, die Ihre Leiterplatte lahmlegen können.
<G-vec00656-002-s042><cripple.lahmlegen><en> Artillery Strike: In dire moments it's crucial to take out or cripple dug-in vehicles.
<G-vec00656-002-s042><cripple.lahmlegen><de> Artillerieschlag: In kritischen Situationen ist es wichtig, eingegrabene Fahrzeuge auszuschalten oder lahmzulegen.
<G-vec00656-002-s043><cripple.lahmlegen><en> They infect computers, damage hard drives and cripple programs, costing money, time and causing a great deal of stress and frustration.
<G-vec00656-002-s043><cripple.lahmlegen><de> Sie infizieren Computer, beschädigen Festplatten und legen Programme lahm, was Geld und Zeit kostet, sowie eine jede Menge Stress und Frustration verursacht.
<G-vec00656-002-s044><cripple.lähmen><en> And very often we think that we treat the illness at home... And actually just cripple their health.
<G-vec00656-002-s044><cripple.lähmen><de> Und sehr oft denken wir, dass wir die Krankheit zu Hause behandeln... und wirklich nur ihre Gesundheit lähmen.
<G-vec00656-002-s045><cripple.lähmen><en> We will explore the fears that we carry inside and begin to learn how to embrace them so they don’t cripple us and limit our lives.
<G-vec00656-002-s045><cripple.lähmen><de> Wir erforschen die Ängste, die wir in uns tragen und beginnen diese annehmen zu lernen, damit sie uns nicht lähmen und unser Leben einschränken.
<G-vec00656-002-s046><cripple.lähmen><en> It weakens people's resistance: fear can cripple.
<G-vec00656-002-s046><cripple.lähmen><de> Sie schwächt die Widerstandskraft, denn Angst lähmt.
