<G-vec00880-002-s019><awake.aufwachen><en> 32 Now Peter and those who were with him were overcome with sleep: but when they were fully awake, they saw his glory and the two men who were with him.
<G-vec00880-002-s019><awake.aufwachen><de> Petrus aber und die mit ihm waren, waren beschwert vom Schlaf; als sie aber völlig aufgewacht waren, sahen sie seine Herrlichkeit und die zwei Männer, die bei ihm standen.
<G-vec00880-002-s020><awake.aufwachen><en> That day the operating room nurses came in when they heard I was awake.
<G-vec00880-002-s020><awake.aufwachen><de> An diesem Tag kamen die OP-Schwestern herein, als sie hörten, daß ich aufgewacht wäre.
<G-vec00880-002-s021><awake.aufwachen><en> The dashboard shows how long you slept and how often you were awake.
<G-vec00880-002-s021><awake.aufwachen><de> Im Dashboard erkennen Sie, wie lange Sie geschlafen haben und wie oft Sie aufgewacht sind.
<G-vec00880-002-s022><awake.aufwachen><en> Day 2, awake refreshed in Aguas Calientes then explore more of Machu Picchu during a guided tour before heading back to Cusco.
<G-vec00880-002-s022><awake.aufwachen><de> Tag 2, aufgewacht in Aguas Calientes, dann erkunden Sie Machu Picchu während einer geführten Tour bevor Sie zurück nach Cusco fahren.
<G-vec00880-002-s023><awake.aufwachen><en> The rest was spent when the bats were awake.
<G-vec00880-002-s023><awake.aufwachen><de> Und danach wenn die Fledermäuse aufgewacht waren.
<G-vec00880-002-s024><awake.aufwachen><en> 32Now Peter and they that were with him were heavy with sleep: but when they were fully awake, they saw his glory, and the two men that stood with him.
<G-vec00880-002-s024><awake.aufwachen><de> 32Petrus aber und die mit ihm waren, waren beschwert vom Schlaf; als sie aber völlig aufgewacht waren, sahen sie seine Herrlichkeit und die zwei Männer, welche bei ihm standen.
<G-vec00880-002-s025><awake.aufwachen><en> I myself will awake right early.
<G-vec00880-002-s025><awake.aufwachen><de> Frühe wille ich aufwachen.
<G-vec00880-002-s026><awake.aufwachen><en> The framework of references that we cling to when we awake in the night, drenched with sweat because we have forgotten who we are.
<G-vec00880-002-s026><awake.aufwachen><de> Das Gerüst, an das wir uns klammern, wenn wir in der Nacht schweißgebadet aufwachen, weil wir vergessen hatten, wer wir sind.
<G-vec00880-002-s027><awake.aufwachen><en> Before the others awake we break our camp and hike on.
<G-vec00880-002-s027><awake.aufwachen><de> Bevor die anderen Leute aufwachen brechen wir unsere Zelte ab und laufen los.
<G-vec00880-002-s028><awake.aufwachen><en> 2 Many of those who sleep in the dust of the earth shall awake, some to everlasting life, and some to shame and everlasting contempt.
<G-vec00880-002-s028><awake.aufwachen><de> Und viele von denen, die im Staub der Erde schlafen, werden aufwachen: die einen zu ewigem Leben und die anderen zur Schande, zu ewigem Abscheu.
<G-vec00880-002-s029><awake.aufwachen><en> And – what we should consider: If he was to awake at all, he would be a 100 % invalide.
<G-vec00880-002-s029><awake.aufwachen><de> Und - so gab er uns zu bedenken: Wenn er überhaupt wieder aufwachen könnte, dann würde er mit Sicherheit ein 100 %er Pflegefall werden.
<G-vec00880-002-s030><awake.aufwachen><en> Take a position that will allow you to feign sleep (or quickly hide) if they awake.
<G-vec00880-002-s030><awake.aufwachen><de> Begib dich selbst in eine Position, die es dir erlaubt, dich schlafend zu stellen (oder dich schnell zu verstecken), sollte die Person aufwachen.
<G-vec00880-002-s031><awake.aufwachen><en> Today, taking pills for or against whatever – to gain or lose weight, to go to sleep or stay awake, to calm down or to work around the clock – has become the norm.
<G-vec00880-002-s031><awake.aufwachen><de> Denn Pillen für oder gegen alles Mögliche zu nehmen ist heute normal geworden: zum Zu- oder Abnehmen, Einschlafen oder Aufwachen, um sich zu beruhigen oder noch eine Nacht durchzuarbeiten.
<G-vec00880-002-s032><awake.aufwachen><en> Daniel 12:2 says, “Multitudes who sleep in the dust of the earth will awake: some to everlasting life, others to shame and everlasting contempt.” Similarly, Jesus Himself said that the wicked “will go away to eternal punishment, but the righteous to eternal life” (Matthew 25:46).
<G-vec00880-002-s032><awake.aufwachen><de> Daniel 12,2 sagt: “Und viele, die unter der Erde schlafen liegen, werden aufwachen, die einen zum ewigen Leben, die andern zu ewiger Schmach und Schande.“ Ähnlich hat Jesus selbst über die Ungläubigen gesagt: „Und sie werden hingehen: diese zur ewigen Strafe, aber die Gerechten in das ewige Leben“ (Matthäus 25,46).
<G-vec00880-002-s033><awake.aufwachen><en> 2 Many of those who sleep in the dust of the earth[bk] shall awake, some to everlasting life, and some to shame and everlasting contempt.
<G-vec00880-002-s033><awake.aufwachen><de> 2 Und viele von denen, die im Staub der Erde schlafen, werden aufwachen; die einen zum ewigen Leben, die anderen zur ewigen Schmach und Schande.
<G-vec00880-002-s034><awake.aufwachen><en> The patient must learn to stop clenching the jaw and grinding the teeth when awake.
<G-vec00880-002-s034><awake.aufwachen><de> Der Patient muss lernen, mit dem Pressen des Kiefers und Knirschen der Zähne beim Aufwachen aufzuhören.
<G-vec00880-002-s035><awake.aufwachen><en> The second and main thing to be said is that it is now time for all Germans to awake from an understandable sleep.
<G-vec00880-002-s035><awake.aufwachen><de> Zweitens und am wichtigsten: Es ist an der Zeit für alle Deutschen, dass sie aus einem verständlichen Schlaf aufwachen.
<G-vec00880-002-s036><awake.aufwachen><en> They that sleep in the earth will awake and shout for joy; for thy dew is a dew of sparkling light, and the earth will bring those long dead to birth again.”
<G-vec00880-002-s036><awake.aufwachen><de> Die da schlafen, auf der Erde, werden aufwachen und jubeln; Denn dein Tau ist ein Tau des funkelnden Licht, und die Erde wird die schon lange tot zur Welt zurückbringen "(Jesaja 26: 19).
<G-vec00880-002-s037><awake.aufwachen><en> Although tents are one of the oldest types of dwellings, even today people still enjoy tucking themselves away in tents, yurts and tepees, to awake in the morning surrounded by nature. Nowadays, you don’t have to sacrifice luxury and comfort for the sake of mobility.
<G-vec00880-002-s037><awake.aufwachen><de> Zwar ist das Zelt eine der ältesten Behausungsarten, doch auch heute verkriecht der Mensch sich noch gern in Zelten, Jurten und Tipis, um morgens nach dem Aufwachen gleich mitten in der Natur zu stehen.
<G-vec00880-002-s038><awake.aufwachen><en> When you awake, a sweet and savoury breakfast awaits you. You can look forward to our croissants, pies, plum cake and pastries, but also meats, cheeses and fruit.
<G-vec00880-002-s038><awake.aufwachen><de> Beim Aufwachen erwartet Sie das leckere Frühstücksbuffetmit süßen und herzhaften Köstlichkeiten: Brioches, verschiedene Mürbeteigtorten, Plumcakesund Gebäck sowie Wurstwaren, Käse und Obst.
<G-vec00880-002-s039><awake.aufwachen><en> Multitudes who sleep in the dust of the earth will awake: some to everlasting life, others to shame and everlasting contempt.
<G-vec00880-002-s039><awake.aufwachen><de> Und viele, die unter der Erde schlafen liegen, werden aufwachen, die einen zum ewigen Leben, die andern zu ewiger Schmach und Schande.
<G-vec00880-002-s040><awake.aufwachen><en> Everything around us is turned off, we’re in a different, quiet world and when we awake there is a big surprise … and happiness, humility, gratitude. Flow.
<G-vec00880-002-s040><awake.aufwachen><de> Alles um uns herum ist ausgeschaltet, wir befinden uns in einer anderen, ruhigen Welt, und wenn wir aufwachen, gibt es eine großes Staunen … und Glück, Demut, Dankbarkeit.
<G-vec00880-002-s041><awake.aufwachen><en> And many of them that sleep in the dust of the earth shall awake, some to everlasting life, and some to shame, to everlasting contempt.
<G-vec00880-002-s041><awake.aufwachen><de> Und viele von denen, die im Staub der Erde schlafen, werden aufwachen; die einen zum ewigen Leben, die anderen zur ewigen Schmach und Schande.
<G-vec00880-002-s042><awake.aufwachen><en> 2 And many of them that sleepe in the dust of the earth, shall awake, some to euerlasting life, and some to shame and perpetuall contempt.
<G-vec00880-002-s042><awake.aufwachen><de> 2 Und viele von denen, die im Staub der Erde schlafen, werden aufwachen: die einen zu ewigem Leben und die anderen zur Schande, zu ewigem Abscheu.
<G-vec00880-002-s043><awake.aufwachen><en> This next film again is just brilliant and I hope American people awake from their mental illness.
<G-vec00880-002-s043><awake.aufwachen><de> Dieser nächste Film ist wieder einfach brillant und ich hoffe, dass die Menschen Amerikas aus ihrer mentalen Krankheit aufwachen.
<G-vec00880-002-s044><awake.aufwachen><en> When you awake, make a beeline for My will and refuse to be steered off course.
<G-vec00880-002-s044><awake.aufwachen><de> Wenn ihr aufwacht, kommt schnurstracks zu Mir und sucht Meinen Willen und lehnt ab, vom Kurs weggezogen zu werden.
<G-vec00880-002-s045><awake.aufwachen><en> “Many of you are lying in beds of condemnation, from the time you awake and become conscious to the very moment you drop off to sleep.
<G-vec00880-002-s045><awake.aufwachen><de> “Viele von euch liegen in Betten der Verurteilung, von dem Zeitpunkt, wo ihr aufwacht und zu Bewusstsein kommt bis zu dem Augenblick, wo ihr ins Bett fällt, um zu schlafen.
<G-vec00880-002-s046><awake.aufwachen><en> And when it´s awake again, everything returns.
<G-vec00880-002-s046><awake.aufwachen><de> Und wenn es aufwacht, kommt alles wieder.
<G-vec00880-002-s133><awake.aufwachen><en> Do not take this supplement in the evening given that it could remain you awake via the night.
<G-vec00880-002-s133><awake.aufwachen><de> Nehmen Sie diese Ergänzung am Abend nicht, weil es Sie die ganze Nacht hindurch wach halten kann.
<G-vec00880-002-s143><awake.aufwachen><en> The forgetfulness of the waking consciousness for dreams is evidently only the counter- part of the fact already mentioned, that the dream (almost) never takes over successive memories from the waking state, but only certain details of these memories which it tears away from the habitual psychic connections in which they are re- called while we are awake.
<G-vec00880-002-s143><awake.aufwachen><de> Die Vergeßlichkeit der Träume für das wache Bewußtsein ist augenscheinlich nur das Gegenstück zu der früher erwähnten Tatsache, daß der Traum (fast) nie geordnete Erinnerungen aus dem Wachleben, sondern nur Einzelheiten aus demselben übernimmt, die er aus ihren gewohnten psychischen Verbindungen reißt, in denen sie im Wachen erinnert werden.
<G-vec00880-002-s144><awake.aufwachen><en> Regarding this, he confessed to us that a dream drove him to this conclusion, a dream that had been so certain and so clear that it seemed he was awake and not sleeping at all.
<G-vec00880-002-s144><awake.aufwachen><de> Hierauf gestand er uns, daß ihn ein Traum herauf an diese Stelle treibe, ein Traum, der so klar, bestimmt und deutlich gewesen sei, als ob er im Wachen, nicht aber im Schlafe stattgefunden habe.
<G-vec00880-002-s161><awake.aufwachen><en> They were awake long before the first rooster began to crow and have been busy setting up their market stands since before daybreak.
<G-vec00880-002-s161><awake.aufwachen><de> Sie waren schon lange vor dem ersten Hahnenschrei wach und haben noch vor Tagesanbruch ihre Marktstände aufgebaut.
<G-vec00880-002-s162><awake.aufwachen><en> Shinji was awake for several minutes, yet he had no intention to get up.
<G-vec00880-002-s162><awake.aufwachen><de> Shinji war schon seit einigen Minuten wach, doch er hatte nicht die Absicht schon aufzustehen.
<G-vec00880-002-s163><awake.aufwachen><en> [GGJ 10.178.5] When he came back, the disciples were also awake, and also the supreme judicial city officer and the 2 Pharisees Dismas and Barnabas stood already at the door of the inn and wanted to come in. Also I was already at the door with My followers, the innkeeper and his son to climb the Mountain of Moses.
<G-vec00880-002-s163><awake.aufwachen><de> [GEJ 10.178.5] Als er zurückkam, waren auch die Jünger schon wach, und der Oberstadtrichter und die beiden Pharisäer Dismas und Barnabas standen auch schon vor der Tür der Herberge und wollten eintreten; aber Ich war auch schon bei der Tür, um mit den Meinen, dem Wirte und seinem Sohne den Berg Mosis zu besteigen.
<G-vec00880-002-s167><awake.aufwachen><en> I do not go in this article into the details, but first I had to get into a state by accompanying the physical body into a deep relaxation, so that it falls asleep and I remain bravely awake.
<G-vec00880-002-s167><awake.aufwachen><de> Ich gehe in diesem Artikel nicht detailliert darauf ein, aber zuerst einmal musste ich in einen Zustand gelangen, indem ich den physischen Körper in eine Tiefenentspannung begleite, sodass er einschläft und ich brav wach bleibe.
<G-vec00880-002-s168><awake.aufwachen><en> The maintenance of wakefulness test is used to determine how well people can remain awake while sitting in a quiet room.
<G-vec00880-002-s168><awake.aufwachen><de> Der Multiple Wachbleibetest wird durchgeführt, um festzustellen, wie gut Menschen im Sitzen in einem ruhigen Raum wach bleiben können.
<G-vec00880-002-s169><awake.aufwachen><en> Your baby doesn't stay awake for more than 30 minutes at a time.
<G-vec00880-002-s169><awake.aufwachen><de> Ihr Baby ist nie länger als 30 Minuten wach.
<G-vec00880-002-s170><awake.aufwachen><en> GPS,WiFi localization,WiFi,BT,APN,NFC,Airplane,Tethering,Brightness,Screen time-out,Stay awake,Flashlight,Ringer,Vibrate,Synchro,Background data,Debug,Unknown sources,Reboot,etc
<G-vec00880-002-s170><awake.aufwachen><de> Bildschirmzeitüberschreitung, Wach bleiben, Taschenlampe, Wecker, Vibrationsalarm, Synchro, Hintergrunddaten, Debug, Unbekannte Quellen, Neustart usw.
<G-vec00880-002-s171><awake.aufwachen><en> The goal of keeping awake the memory of Salzburg’s nature, history, art and cultural history since the foundation of the Salzburg Museum in 1834 has also led to the collecting of objects from the applied arts and cultural history.
<G-vec00880-002-s171><awake.aufwachen><de> Das Ziel, die Erinnerung an Salzburgs Natur, Geschichte, Kunst- und Kulturgeschichte wach zu halten, führte seit der Gründung des Salzburg Museum im Jahr 1834 auch zum Sammeln kunstgewerblicher und kulturhistorischer Gegenstände.
<G-vec00880-002-s172><awake.aufwachen><en> All cards are designed to increase the awareness - to be awake in everyday life.
<G-vec00880-002-s172><awake.aufwachen><de> Alle Karten sind darauf ausgerichtet, die Bewusstheit zu erhöhen - wach auch im Alltag zu sein.
<G-vec00880-002-s174><awake.aufwachen><en> For example, “I” exist only when I am awake.
<G-vec00880-002-s174><awake.aufwachen><de> Zum Beispiel, “Ich” existiert nur, wenn ich wach bin.
<G-vec00880-002-s175><awake.aufwachen><en> Even Jerome and MiBi are awake again.
<G-vec00880-002-s175><awake.aufwachen><de> Sogar Jerome und MiBi sind wieder wach.
<G-vec00880-002-s176><awake.aufwachen><en> The first night I slept with two duvets, robes and pajamas, socks, and I am more awake 'times in the night.
<G-vec00880-002-s176><awake.aufwachen><de> Die erste Nacht schlief ich mit zwei Bettdecken, Bademäntel und Schlafanzüge, Socken, und ich bin mehr wach 'mal in der Nacht.
<G-vec00880-002-s177><awake.aufwachen><en> The music flows through the soul, the body follows the music, the mind is awake and relaxed, this creates the mysterious “flow” that makes us forget space and time.
<G-vec00880-002-s177><awake.aufwachen><de> Die Musik fließt durch die Seele, der Körper folgt der Musik, der Geist ist wach und entspannt, so entsteht der geheimnisvolle „Flow“, der uns Raum und Zeit vergessen lässt.
<G-vec00880-002-s178><awake.aufwachen><en> Believing makes numb but you must be awake.
<G-vec00880-002-s178><awake.aufwachen><de> Glauben schläfert ein und ihr sollt wach sein.
<G-vec00880-002-s180><awake.aufwachen><en> Those of you who are awake and aware are going through very difficult times.
<G-vec00880-002-s180><awake.aufwachen><de> Diejenigen von euch, die wach und bewusst sind, machen sehr schwierige Zeiten durch.
<G-vec00880-002-s181><awake.aufwachen><en> You’ll always know if your child is sleeping or awake, whether you’re at the office or right in the backyard.
<G-vec00880-002-s181><awake.aufwachen><de> Sie werden jederzeit wissen, ob Ihr Kind schläft oder wach ist, egal, ob Sie gerade im Büro oder im Garten sind.
<G-vec00880-002-s182><awake.aufwachen><en> Afterward, I felt very awake and concentrated when I was studying the Fa.
<G-vec00880-002-s182><awake.aufwachen><de> Hinterher fühlte ich mich sehr wach und konzentriert, wenn ich das Fa lernte.
<G-vec00880-002-s183><awake.aufwachen><en> Even after the event was over and I had much time to reflect, I still felt as if I was full awake and totally aware of my surroundings during the experience.
<G-vec00880-002-s183><awake.aufwachen><de> Sogar nachdem das Ereignis vorüber war und ich viel Zeit hatte darüber nachzudenken, fühlte ich dennoch als wäre ich, während des Erlebnisses vollständig wach, und mir meiner Umgebung total bewusst gewesen.
<G-vec00880-002-s184><awake.aufwachen><en> But since I’m already awake I can really take the opportunity to write and alongside feed my sarcasm a little bit.
<G-vec00880-002-s184><awake.aufwachen><de> Gut, wo ich schon mal wach bin, kann ich tatsächlich die Gelegenheit nutzen und schreiben und nebenher etwas meinem Sarkasmus frönen.
<G-vec00880-002-s185><awake.aufwachen><en> If your treasure is only in the half sleep, simply say that you are quite awake and have to go out.
<G-vec00880-002-s185><awake.aufwachen><de> Wenn dein Schatz nur noch im Halbschlaf ist, sag einfach, dass du schon wach bist und raus musst.
<G-vec00880-002-s186><awake.aufwachen><en> In the film GODOT says: “How do you know, you are awake?” Perhaps we are all dreamers who are waiting to awake.
<G-vec00880-002-s186><awake.aufwachen><de> GODOT sagt im Film: „Woher weißt du, dass du wach bist?“ Vielleicht sind wir alle Träumer, die darauf warten, aufzuwachen.
<G-vec00880-002-s187><awake.aufwachen><en> Fatigue may mean many things, that you need more rest, that there is something you don't want to look at, that you are giving out more energy than you take in, that you are not wide awake, that something needs attention.
<G-vec00880-002-s187><awake.aufwachen><de> Erschöpfung kann viele Dinge bedeuten: dass du mehr Ruhe brauchst, dass es etwas gibt, was du dir nicht anschaust, dass du mehr Energie hinaus gibst, als du herein nimmst, dass du nicht ganz wach bist, dass etwas deine Aufmerksamkeit benötigt.
<G-vec00880-002-s188><awake.aufwachen><en> I grab her shoulders and shake her awake.
<G-vec00880-002-s188><awake.aufwachen><de> Ich greife nach ihren Schultern und versuche sie wach zu rütteln.
<G-vec00880-002-s189><awake.aufwachen><en> See, I have called you to awake these seven times; yea, even ten times shall it be spoken through My prophets.
<G-vec00880-002-s189><awake.aufwachen><de> Seht, Ich habe euch 7 Mal gerufen, um euch wach zu rütteln; ja sogar 10 Mal soll es gesprochen werden durch Meine Propheten.
<G-vec00880-002-s190><awake.aufwachen><en> Other issues can include difficulty finding and maintaining relationships on such an unusual schedule, shopping when the stores are open, and being awake for early appointments with repair people and doctors.
<G-vec00880-002-s190><awake.aufwachen><de> Weitere Probleme können die Schwierigkeit einschließen einen Partner zu finden und die Beziehung zu solch unüblichen Zeiten weiterzuführen, das Einkaufen wenn die Geschäfte offen sind, sowie wach sein für frühe Termine mit Handwerkern und Ärzten.
<G-vec00880-002-s191><awake.aufwachen><en> Your circadian rhythms are heavily influenced by your biological clock. This biological clock is found in the brain and it’s what makes you hungry every day around the same time, what controls your body temperature, and what makes you feel tired and awake again.
<G-vec00880-002-s191><awake.aufwachen><de> Zusätzlich wird Ihr Tagesrhythmus stark durch Ihre biologische Uhr beeinflusst Diese Uhr befindet sich im Gehirn und ist verantwortlich dafür, dass man jeden Tag in etwa zur gleichen Zeit Hunger verspürt, sie kontrolliert die Körpertemperatur und lässt uns müde oder wach sein.
<G-vec00880-002-s192><awake.aufwachen><en> This is another important chance for us, to stay awake, in LIGHT for more tolerance.
<G-vec00880-002-s192><awake.aufwachen><de> Er ist eine weitere wichtige Chance für uns, wach zu sein und für mehr Toleranz zu kämpfen.
<G-vec00880-002-s193><awake.aufwachen><en> Being awake comes with a price.
<G-vec00880-002-s193><awake.aufwachen><de> Wach sein ist mit einem Preis verbunden.
<G-vec00880-002-s196><awake.aufwachen><en> Now its a tremendous thing to cycle around this beautiful city and see, beyond all doubt, that it's Amsterdam that flies by while 'I' am this awake unmoving stillness.
<G-vec00880-002-s196><awake.aufwachen><de> Jetzt ist es eine unglaubliche Sache, mit dem Fahrrad durch diese schöne Stadt zu fahren und ohne jeden Zweifel zu sehen, dass Amsterdam vorbeifliegt, während „ich“ diese wache, unbewegte Ruhe bin.
<G-vec00880-002-s197><awake.aufwachen><en> Awake, shake, and put on His strength.
<G-vec00880-002-s197><awake.aufwachen><de> Wache auf, schüttle dich und zieh Seine Kraft an.
<G-vec00880-002-s198><awake.aufwachen><en> Like two awake persons among all others sleeping, Mika and Shinji are looking into the daily grey truth of the working class: A society of young Japanese adults, who almost don’t have a perspective, who are only functioning instead of living and don’t have dreams anymore.
<G-vec00880-002-s198><awake.aufwachen><de> Wie zwei Wache unter allen anderen, die schlafen, sehen Mika und Shinji in die tägliche graue Wahrheit der Arbeiterklasse: Eine Gesellschaft von jungen japanischen Erwachsenen, die kaum eine Perspektive haben, die nur noch funktionieren statt zu leben und keine Träume haben.
<G-vec00880-002-s199><awake.aufwachen><en> On account of his numerical advantage, the favourable terrain, the scythed chariots, war elephants and fighting power, Darius was very sure of victory, but the Persians feared a night attack by the Macedonians and therefore ordered all men to remain awake, in order to be prepared for an attack.
<G-vec00880-002-s199><awake.aufwachen><de> Durch seine Überzahl, den Geländevorteil, Sichelwagen, Kampfelefanten und die starke Kampfkraft fühlte sich Dareios äußerst siegessicher, doch die Perser befürchteten einen Nachtangriff der Makedonen und befahlen deshalb allen Männern, Wache zu halten, um gegen einen Angriff gewappnet zu sein.
<G-vec00880-002-s200><awake.aufwachen><en> We can walk along a road and at the same time talk to another being without having to give the movement of our legs any particular awake, day-conscious attention.
<G-vec00880-002-s200><awake.aufwachen><de> Wir können einen Weg entlang gehen und gleichzeitig mit einem anderen Wesen reden, ohne daß wir der Bewegung unserer Beine irgendeine besondere wache, tagesbewußte Aufmerksamkeit schenken müßten.
<G-vec00880-002-s201><awake.aufwachen><en> I am sometimes awake for very short times, but cannot pull myself together enough to get up and out of bed.
<G-vec00880-002-s201><awake.aufwachen><de> Ich wache immer auf, aber kann mich nicht zusammenreißen und aufstehen.
<G-vec00880-002-s202><awake.aufwachen><en> Kissed by warm sunbeams I awake and see my home for the next 3 days in daylight for the first time.
<G-vec00880-002-s202><awake.aufwachen><de> Von Sonnenstrahlen geküsst wache ich auf und sehe meine Zuhause für die nächsten 3 Tage zum ersten Mal bei Tageslicht.
<G-vec00880-002-s203><awake.aufwachen><en> The result: radiant, wide-awake eyes.
<G-vec00880-002-s203><awake.aufwachen><de> Ergebnis: strahlende und wache Augen.
<G-vec00880-002-s204><awake.aufwachen><en> Further pressure measurements were performed on awake animals.
<G-vec00880-002-s204><awake.aufwachen><de> Weitere Druckbestimmungen wurden am wachen Tier vorgenommen.
<G-vec00880-002-s205><awake.aufwachen><en> Be sure of this: if the master of the house had known the hour of night when the thief was coming, he would have stayed awake and not let his house be broken into.
<G-vec00880-002-s205><awake.aufwachen><de> Das sollt ihr aber wissen: Wenn der Hausvater wüßte, welche Stunde der Dieb kommen wollte, so würde er ja wachen und nicht in sein Haus brechen lassen.
<G-vec00880-002-s206><awake.aufwachen><en> So then let us not sleep, as others do, but let us keep awake and be Thessalonians 5:6 | ESV
<G-vec00880-002-s206><awake.aufwachen><de> So lasst uns nun nicht schlafen wie die andern, sondern lasst uns wachen und nüchtern sein.
<G-vec00880-002-s207><awake.aufwachen><en> We were all somewhere between awake and dreaming, between history, memory, and nowhere.
<G-vec00880-002-s207><awake.aufwachen><de> Wir waren alle irgendwie zwischen Wachen und Träumen, zwischen Geschichte, Erinnerung und nirgendwo.
<G-vec00880-002-s208><awake.aufwachen><en> Glide on skin tightener for wide awake eyes.
<G-vec00880-002-s208><awake.aufwachen><de> Tragen Sie den Haufstraffer für weite, Augen mit einem wachen Blick auf.
<G-vec00880-002-s209><awake.aufwachen><en> We would like Lou to be used as a recreational or therapy horse for knowledgeable people who enjoy their awake intelligence and their Pedigree
<G-vec00880-002-s209><awake.aufwachen><de> Wir wünschen uns für Lou eine Verwendung als Freizeit- oder Therapiepferd bei fachkundigen Menschen, die Freude an ihrer wachen Intelligenz und ihrem liebenswerten Charakter haben.
<G-vec00880-002-s210><awake.aufwachen><en> Agni Yoga often speaks about the importance of giving our life a harmonious rhythm: Life and death, sleeping and being awake, sowing and harvesting, activity and contemplation, thinking and acting, spiritual and physical work – again and again we see: A healthy life requires that we give all aspects of our existence equal weight.
<G-vec00880-002-s210><awake.aufwachen><de> Agni Yoga spricht an vielen Stellen von der Wichtigkeit, unserem Leben einen harmonischen Rhythmus zu geben: Leben und Tod, Schlafen und Wachen, Säen und Ernten, Aktivität und Kontemplation, Denken und Handeln, geistige Arbeit und physisches Wirken – überall sehen wir: Ein gesundes Leben hängt davon ab, dass wir allen Aspekten unseres Daseins gleichermaßen und gleichgewichtig Ausdruck verleihen.
<G-vec00880-002-s211><awake.aufwachen><en> If a mother suddenly senses or sees in her mind's eye, whether it is in a dream or an awake state, that her son who lives in America is in grave danger, it is because the son in the dangerous situation has thought so strongly about his mother, that this concentration of thought just like radio waves comes into contact with the mother's "radio receiver", which because of her love for her son is highly receptive.
<G-vec00880-002-s211><awake.aufwachen><de> Wenn eine Mutter plötzlich spürt oder vor sich sieht, sei es nun im Traum oder im wachen Zustand, daß sich ihr Sohn, der in Amerika lebt, in großer Gefahr befindet, so liegt das daran, daß der Sohn in der Gefahrensituation so stark an seine Mutter gedacht hat, daß diese Gedankenkonzentration, so wie Radiowellen, den „Empfangsapparat“ der Mutter getroffen hat, der aufgrund ihrer Liebe zu dem Sohn in hohem Maße empfänglich dafür ist.
<G-vec00880-002-s212><awake.aufwachen><en> Yet these beings of light will time and again try to influence people into establishing the connection with the spiritual world in an awake, conscious state, they will enlighten them about the 'working of the spirit' in a person and aim to encourage them to enter into heartfelt contact with Me, which will enable them to receive profound knowledge which cannot be conveyed to earth in a psychic way.... in a state of trance.
<G-vec00880-002-s212><awake.aufwachen><de> Doch diese Lichtwesen werden immer wieder die Menschen zu bestimmen suchen, die Verbindung mit der geistigen Welt im wachen, bewußten Zustand herzustellen, sie werden sie über das "Wirken des Geistes" im Menschen aufklären und sie anzuregen suchen, mit Mir Selbst in innigen Kontakt zu treten, um dann ein tiefes Wissen entgegennehmen zu können, das auf medialem Wege.... in unbewußtem Zustand.... nicht zur Erde geleitet werden kann.
<G-vec00880-002-s213><awake.aufwachen><en> In his "Music for Moving Lamps", Floris Vanhoof is less interested in the scientific aspect of an experimental arrangement than in seeking poetic meaning: Much like the experience at the theater when the lights go out while the stage is adapted, we awake each day to a new situation.
<G-vec00880-002-s213><awake.aufwachen><de> Floris Vanhoof ist mit seinem „Music For Moving Lamps“ weniger an einem wissenschaftlichen Aspekt einer Versuchsanordnung interessiert, sondern um eine poetische Bedeutung bemüht: Wie im Theater wenn die Lichter ausgehen und die Bühne umgebaut wird, wachen wir jeden Tag in einer neuen Situation auf.
<G-vec00880-002-s214><awake.aufwachen><en> The large, awake eyes and distinctive auricles are always in motion, its whiskers vibrate – these are restless animals with wakeful senses.
<G-vec00880-002-s214><awake.aufwachen><de> Die großen, wachen Augen und auffälligen Ohrmuscheln sind stets in Bewegung, die Schnurrhaare vibrieren – es sind sinneswache, ruhelose Tiere.
<G-vec00880-002-s215><awake.aufwachen><en> We invite you to check out a really beautiful piece of writing from a woman who opens the discussion on what the realm of current and future possibilities looks from an awake and feminine point of view.
<G-vec00880-002-s215><awake.aufwachen><de> Wir laden euch ein, ein wirklich wunderschönes Schriftstück von einer Frau zu lesen, die das Gespräch darüber eröffnet wie das Reich der derzeitigen und künftigen Möglichkeiten von einem wachen und femininen Blickwinkel aussieht.
<G-vec00880-002-s216><awake.aufwachen><en> 10 who died for us so that whether we are awake or asleep we might live with him.
<G-vec00880-002-s216><awake.aufwachen><de> 10 Er ist für uns gestorben, damit wir vereint mit ihm leben, ob wir nun wachen oder schlafen.
<G-vec00880-002-s218><awake.aufwachen><en> Using a rodent model of severe SCI, we will image the simultaneous activity of large populations of neurons within NSC grafts and adjacent host spinal cord in awake, behaving animals; this will allow us to understand how signals are transmitted into and across NSC grafts on a large scale.
<G-vec00880-002-s218><awake.aufwachen><de> An einem Modell für schwere Querschnittslähmung soll die gleichzeitige Aktivität einer großen Anzahl an Nervenzellen innerhalb des Transplantats und dem angrenzenden Wirtsgewebe in wachen Tieren beobachtet werden; das soll es ermöglichen, zu verstehen, wie Signale in NSC-Transplantate und darüber hinaus übertragen werden.
<G-vec00880-002-s219><awake.aufwachen><en> 9 For God's purpose for us is not wrath, but salvation through our Lord Jesus Christ, 10 Who was put to death for us, so that, awake or sleeping, we may have a part in his life.
<G-vec00880-002-s219><awake.aufwachen><de> 9 Denn Gott hat uns nicht gesetzt zum Zorn, sondern die Seligkeit zu besitzen durch unsern HERRN Jesus Christus, 10 der für uns alle gestorben ist, auf daß, wir wachen oder schlafen, wir zugleich mit ihm leben sollen.
<G-vec00880-002-s221><awake.aufwachen><en> 43 “But know one thing, that if the householder had known in what watch the thief was coming, he would have kept awake and not allowed his house to be broken into.
<G-vec00880-002-s221><awake.aufwachen><de> 43 Das sollt ihr aber wissen: Wenn der Hausvater wüßte, welche Stunde der Dieb kommen wollte, so würde er ja wachen und nicht in sein Haus brechen lassen.
<G-vec00880-002-s222><awake.aufwachen><en> Modern techniques do enable minimal damage to healthy tissue surrounding the tumour (dyeing techniques, computer-supported operations, operations on patients who are awake).
<G-vec00880-002-s222><awake.aufwachen><de> Moderne Techniken ermöglichen aber inzwischen eine minimale Schädigung des tumorumgebenden gesunden Gewebes (Färbetechniken, Computer-gestützte Operation, Operation am wachen Patienten).
<G-vec00880-002-s255><awake.aufwachen><en> Labour together with one another; strive in company together; run together; suffer together; sleep together; and awake together as the stewards and associates and servants of God.
<G-vec00880-002-s255><awake.aufwachen><de> Müht euch miteinander, kämpft gemeinsam, lauft gemeinsam, leidet gemeinsam, schlaft und wacht gemeinsam als Verwalter Gottes, seine Hausgenossen und Diener.
<G-vec00880-002-s256><awake.aufwachen><en> We see a panorama of sleep that, in its totality and exclusiveness, has become scary: everybody is asleep, nobody is awake, nobody moving.
<G-vec00880-002-s256><awake.aufwachen><de> Wir sehen ein Panorama des Schlafs, das total und in dieser vollkommenen Ausschliesslichkeit unheimlich geworden ist: Alles schläft, keiner wacht, keine bewegt sich.
<G-vec00880-002-s257><awake.aufwachen><en> In the mouth closed still awake, just to slowly.
<G-vec00880-002-s257><awake.aufwachen><de> Am Gaumen noch immer verschlossen, wacht gerade erst langsam auf.
<G-vec00880-002-s258><awake.aufwachen><en> Blessed is the one who stays awake and keeps his clothes, so that he will not walk about naked.
<G-vec00880-002-s258><awake.aufwachen><de> Glückselig, der wacht und seine Kleider bewahrt, damit er nicht nackt umhergehe.
<G-vec00880-002-s259><awake.aufwachen><en> Every step that you take, this great Eye is awake,
<G-vec00880-002-s259><awake.aufwachen><de> Jeder Schritt, den Sie nehmen, denn das große Auge wacht.
<G-vec00880-002-s282><awake.aufwachen><en> I lay awake most of that night, and by noon the next day every bone in my body ached.
<G-vec00880-002-s282><awake.aufwachen><de> In dieser Nacht lag ich die meiste Zeit wach und am nächsten Mittag taten mir alle Knochen weh.
<G-vec00880-002-s283><awake.aufwachen><en> Laying awake on a hot summer night listening to their insistent droning is bad enough, so you need not add any further inconvenience to the equation.
<G-vec00880-002-s283><awake.aufwachen><de> An einer heißen Sommernacht die ganze Zeit wach zu liegen und dem ständigen Summen der Mücken zuhören zu müssen, ist schon schlimm genug, also müssen Sie sich nicht noch mehr Unannehmlichkeiten aussetzen.
<G-vec00880-002-s068><awake.erwachen><en> And a modern radio clock will take care that you awake softly in time at the next morning.
<G-vec00880-002-s068><awake.erwachen><de> Und ein digitaler Radiowecker sorgt dafür, dass Sie pünktlich am Morgen erwachen.
<G-vec00880-002-s069><awake.erwachen><en> Short periods of arousal are normal, the hedgehogs awake, remain in their nests and soon go back into hibernation.
<G-vec00880-002-s069><awake.erwachen><de> Kurze Unterbrechungen sind normal, die Igel erwachen, bleiben im Nest und schlafen bald weiter.
<G-vec00880-002-s070><awake.erwachen><en> Awake to sunlight flooding into the suite through panoramic windows, intensifying the Alpine colors: snow white, sky blue, meadow green.
<G-vec00880-002-s070><awake.erwachen><de> Erwachen Sie bei Sonnenschein, der durch die Panoramafenster in die Suite scheint und die Farben der Alpen intensiviert: Schneeweiß, Himmelblau und Wiesengrün.
<G-vec00880-002-s071><awake.erwachen><en> Now, I do not mean that if you awake in the morning this will influence decisively the cycle of the universe.
<G-vec00880-002-s071><awake.erwachen><de> Gut, damit meine ich nicht, dass euer Erwachen am frühen Morgen den Zyklus des Universum maßgebend beeinflussen wird.
<G-vec00880-002-s072><awake.erwachen><en> As they open, the powers and possibilities of the inner being also are aroused in us; we awake first to a larger consciousness and then to a cosmic consciousness; we are no longer little separate personalities with limited lives but centres of a universal action and in direct contact with cosmic forces.
<G-vec00880-002-s072><awake.erwachen><de> In dem Maß, wie sie sich öffnen, werden auch die Mächte und Möglichkeiten des inneren Wesens in uns erweckt; zunächst erwachen wir zu einem größeren und dann zu einem kosmischen Bewusstsein; wir sind nicht länger mehr kleine, gesonderte Persönlichkeiten mit begrenztem Leben, sondern Zentren eines universalen Wirkens und in direktem Kontakt mit kosmischen Kräften.
<G-vec00880-002-s073><awake.erwachen><en> In the beginning of february it gets warmer outside and the insects awake in the nest.
<G-vec00880-002-s073><awake.erwachen><de> Anfang Februar wird es draußen langsam wärmer und die Insekten erwachen im Nest.
<G-vec00880-002-s074><awake.erwachen><en> If you want a true mastery and transformation of the vital movements, it can be done only on condition you allow your psychic being, the soul in you, to awake fully, to establish its rule and opening all to the permanent touch of the Divine Shakti, impose its own way of pure devotion, whole-hearted aspiration and complete uncompromising urge to all that is divine on the mind and heart and vital nature.
<G-vec00880-002-s074><awake.erwachen><de> Wenn du die wahre Beherrschung und Umwandlung der vitalen Bewegungen willst, kann es nur unter der Bedingung geschehen, dass du deinem seelischen Wesen, der Seele in dir erlaubst, voll zu erwachen, ihre Herrschaft zu errichten und alle Wesensteile der dauernden Berührung durch die Göttliche sakti zu öffnen und ihnen den ihr [der Seele] eigenen Weg der reinen Hingabe aufzuerlegen, sowie auf das Mental, das Herz und die vitale Natur mit rückhaltlosem Streben und vollständigem, unnachgiebigem Verlangen nach allem, was göttlich ist, einzuwirken.
<G-vec00880-002-s075><awake.erwachen><en> The earth will awake anew in this time.
<G-vec00880-002-s075><awake.erwachen><de> Die Erde wird in dieser Zeit neu erwachen.
<G-vec00880-002-s076><awake.erwachen><en> Age-old resting volcanos will awake to new activity and negatively affect the entire world climate.
<G-vec00880-002-s076><awake.erwachen><de> Uralt ruhende Vulkane werden zu neuer Aktivität erwachen und das gesamte Weltklima negativ beeinflussen.
<G-vec00880-002-s077><awake.erwachen><en> Yet one fateful morning, you awake to find that your father has defied the Overseer and left the comfort and security afforded by Vault 101 for reasons unknown.
<G-vec00880-002-s077><awake.erwachen><de> Doch als wir eines schicksalhaften Morgens erwachen, müssen wir feststellen, dass unser Vater sich dem Aufseher widersetzt und den Komfort und die Sicherheit von Vault 101 aus unbekanntem Grund verlassen hat.
<G-vec00880-002-s078><awake.erwachen><en> Around three weeks later, the mighty pear trees in the rolling hills of the Mostviertel awake and put on their oppulent white blooms.
<G-vec00880-002-s078><awake.erwachen><de> Etwa 3 Wochen später erwachen die mächtigen Birnbäume des Mostviertler Hügellandes und setzen Ihre weiße Blütenpracht an.
<G-vec00880-002-s079><awake.erwachen><en> The fresh warm milk at the breakfast table and delicious honey from the herbs and flowers of our surrounding mountain meadows - here soul and spirit awake anew.
<G-vec00880-002-s079><awake.erwachen><de> Die frische warme Milch am Frühstückstisch und köstlicher Honig aus den Kräutern und Blumen unserer umliegenden Bergwiesen – hier erwachen Seele und Geist von neuem.
<G-vec00880-002-s080><awake.erwachen><en> A solitary skipper, whose name we will never know, is jolted awake when his yacht collides with a container in the middle of the ocean.
<G-vec00880-002-s080><awake.erwachen><de> Ein unsanftes Erwachen erlebt der einsame Skipper, dessen Namen wir nie erfahren werden, als seine Yacht mitten auf offener See mit einem Container kollidiert.
<G-vec00880-002-s081><awake.erwachen><en> Awake early to experience the train make its way from Wong Po along a wooden trestle viaduct beside a towering cliff.
<G-vec00880-002-s081><awake.erwachen><de> Erwachen Sie früh um mitzuerleben, wie der Zug seinen Weg von Wong Po entlang eines Holzviaduktes neben hoch aufragenden Klippen macht.
<G-vec00880-002-s082><awake.erwachen><en> Let the dragon awake and experience as a knight what it means when his fire spread to the whole roller and burns until the end of the free games.
<G-vec00880-002-s082><awake.erwachen><de> Lass den Drachen erwachen und erlebe als Ritter was es heißt, wenn sich sein Feuer auf die ganze Walze ausbreitet und bis zum Ende der Freispiele lodert.
<G-vec00880-002-s083><awake.erwachen><en> You awake to the soft rush of the sea and to the faint rustle of the stalks swaying in the wind on the wheat-field.
<G-vec00880-002-s083><awake.erwachen><de> Sie erwachen durch das seichte Rauschen des Meeres und durch das leise Knistern der Halme, die sich auf dem Weizenfeld sanft im Wind wiegen.
<G-vec00880-002-s084><awake.erwachen><en> To help you awake refreshed, the Radisson Blu hotels of Finland developed the Blu Dreams experience featuring our Magic Bed.
<G-vec00880-002-s084><awake.erwachen><de> Damit Sie erfrischt erwachen, haben die Radisson Blu Hotels in Finnland das Blu-Dreams-Erlebnis mit unserem Magic Bed entwickelt.
<G-vec00880-002-s085><awake.erwachen><en> 14:12 So man lieth down, and riseth not: till the heavens shall be no more, they shall not awake, nor be raised out of their sleep.
<G-vec00880-002-s085><awake.erwachen><de> 14:12 so legt der Mensch sich hin und steht nicht wieder auf; bis die Himmel nicht mehr sind, erwachen sie nicht und werden nicht aufgeweckt aus ihrem Schlafe.
<G-vec00880-002-s086><awake.erwachen><en> You slowly awake in a dark, damp room.
<G-vec00880-002-s086><awake.erwachen><de> Du erwachst langsam in einem dunklen, feuchtkalten Raum.
<G-vec00880-002-s087><awake.erwachen><en> You awake from a strange dream to find gingerbread men trashing your home.
<G-vec00880-002-s087><awake.erwachen><de> Du erwachst aus einem merkwürdigen Traum und Lebkuchenmänner zerstören gerade Dein Zuhause.
<G-vec00880-002-s088><awake.erwachen><en> The condition you describe in your work means that the inner being is awake and that there is now the double consciousness.
<G-vec00880-002-s088><awake.erwachen><de> Der von dir beschriebene Zustand während deiner Arbeit bedeutet, dass das innere Wesen erwacht ist und es nun ein doppeltes Bewusstsein gibt.
<G-vec00880-002-s089><awake.erwachen><en> China was at last awake.
<G-vec00880-002-s089><awake.erwachen><de> China war schließlich erwacht.
<G-vec00880-002-s090><awake.erwachen><en> But if the psychic is awake, then there is not this danger; one finds one's true being in place of the ego.
<G-vec00880-002-s090><awake.erwachen><de> Aber wenn die Seele erwacht ist, besteht diese Gefahr nicht; man findet an Stelle des Egos sein wahres Wesen.
<G-vec00880-002-s091><awake.erwachen><en> Their cry has been; “Awake, arise and stop not, until the goal is reached.” All the ten Singh Gurus, from Guru Nanak down to Guru Gobind Singh, placed before the Indian society the ideal of a Sikh (a true disciple), and of a Khalsa (the pure one) who render selfless service to humanity born of genuine love for mankind.
<G-vec00880-002-s091><awake.erwachen><de> Ihre Mahnung war stets: »Erwacht, erhebt euch und ruhet nicht, bis das Ziel erreicht ist.« Alle zehn Gurus, angefangen bei Guru Nanak bis zu Guru Gobind Singh, nannten dem indischen Volk das Ideal eines Sikh (eines wahren Schülers) und eines Khalsa (eines Reinen), den selbstlosen Dienst an der Menschheit, der aus wirklicher Liebe für alle Menschen geboren ist; denn dies bildet die Grundlage des geistigen Lebens und belebt das im Menschen ruhende spirituelle Sehnen, indem es ihn allmählich von der Engstirnigkeit und dem falschen Stolz befreit.
<G-vec00880-002-s092><awake.erwachen><en> The district Santa Catalina is getting awake.
<G-vec00880-002-s092><awake.erwachen><de> Das Viertel Santa Catalina erwacht.
<G-vec00880-002-s093><awake.erwachen><en> So it's 11/11/11 - I awake early, realise the date and feel deeply inspired to write.
<G-vec00880-002-s093><awake.erwachen><de> 11.11.11 - ich bin früh erwacht, werde mir des Datums bewusst und fühle mich tief inspiriert zu schreiben.
<G-vec00880-002-s094><awake.erwachen><en> When it is awake, it begins to take hold of the rest of the being, to influence it and change it so that all may become the true expression of the inner soul.
<G-vec00880-002-s094><awake.erwachen><de> Sobald es erwacht ist, beginnt es, das übrige Wesen zu ergreifen, zu beeinflussen und zu wandeln, so dass alles zum wahren Ausdruck der inneren Seele werden kann.
<G-vec00880-002-s095><awake.erwachen><en> AWAKE, AWAKE, AWAKE to the fact that compassion includes being brutally honest, looking everyone in the eye and always searching for the purest truth, which is not possible without discovering the deepest lie.
<G-vec00880-002-s095><awake.erwachen><de> ERWACHT, ERWACHT, ERWACHT zu der Tatsache, daß Mitgefühl zeigen heißt, brutal ehrlich zu sein, jedem in die Augen zu blicken und immer nach der reinsten Wahrheit zu suchen, was nicht möglich ist, ohne die tiefste Lüge aufzudecken.
<G-vec00880-002-s098><awake.erwachen><en> When man is fully awake to the fact that he is all powerful, and learns to believe in himself and his ability to take back this power, then everything on Earth will change for the better.
<G-vec00880-002-s098><awake.erwachen><de> Wenn der Mensch ganz der Tatsache gegenüber erwacht ist, dass er allmächtig ist und lernt, an sich selbst zu glauben, und an die Fähigkeit zur Rücknahme dieser Macht, dann wird sich alles auf der Erde zum Besseren verändern.
<G-vec00880-002-s099><awake.erwachen><en> Even though he is only awake a few hours per day, Itt makes her heart flutter.
<G-vec00880-002-s099><awake.erwachen><de> Obwohl Itt jeden Tag nur für ein paar Stunden erwacht, bekommt sie wegen ihm Herzklopfen.
<G-vec00880-002-s100><awake.erwachen><en> Our wolves, who have been equipped with radio transmitters, have been photographed during tagging and the animals are not fully awake after being sedated.
<G-vec00880-002-s100><awake.erwachen><de> Unsere Wölfe, die mit Senderhalsbändern ausgestattet wurden, wurden während des Besenderns fotografiert, nachdem die Tiere noch nicht ganz erwacht waren aus der Narkose.
<G-vec00880-002-s101><awake.erwachen><en> The fascinate nature around the “Alpe di Siusi” awake.
<G-vec00880-002-s101><awake.erwachen><de> Die faszinierende Natur rund um der Seiser Alm erwacht.
