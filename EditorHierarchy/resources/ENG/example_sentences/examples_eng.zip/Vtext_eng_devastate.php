<G-vec00389-002-s016><devastate.erschüttern><en> This does not mean that disappointments and loss do not devastate, but we believe that he walks through those moments with us.
<G-vec00389-002-s016><devastate.erschüttern><de> Das heißt nicht, dass Enttäuschungen und Verlust nicht tief erschüttern könnten.
<G-vec00389-002-s007><devastate.erwägen><en> As a superpower, the U.S. may have wanted to launch a pre-emptive strike to devastate North Korea.
<G-vec00389-002-s007><devastate.erwägen><de> Als Supermacht könnten die USA einen Präventivschlag gegen Nordkorea erwägen.
<G-vec00389-002-s014><devastate.schädigen><en> Downtime can have serious results which can devastate your business.
<G-vec00389-002-s014><devastate.schädigen><de> Ausfallzeiten können ernsthafte Folgen haben, die Ihr Geschäft stark schädigen können.
<G-vec00389-002-s008><devastate.vernichten><en> These storms can reach winds of 300 mph (480 km/h), and can devastate neighborhoods and towns in minutes.
<G-vec00389-002-s008><devastate.vernichten><de> Diese Stürme können Windgeschwindigkeiten von 300 Meilen pro Stunde erreichen, sie können ganze Nachbarschaften und Städte innerhalb von Minuten vernichten.
<G-vec00389-002-s030><devastate.verwüsten><en> In war, you become a hero when you devastate.
<G-vec00389-002-s030><devastate.verwüsten><de> Im Krieg wirst du zum Helden, wenn du verwüstest.
<G-vec00389-002-s015><devastate.zerstören><en> The Belo Monte dam, if built, would devastate a vast area of the Amazon rainforest, upon which thousands of tribal people depend for their survival.
<G-vec00389-002-s015><devastate.zerstören><de> Der Belo Monte Staudamm würde große Teile des Amazonas-Regenwaldes zerstören, auf den Tausende Indigene angewiesen sind.
