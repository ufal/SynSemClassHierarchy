<G-vec01192-002-s008><belittle.herabsetzen><en> Metas should not abuse their influence by using tactics that are meant to belittle or demean another editor.
<G-vec01192-002-s008><belittle.herabsetzen><de> Sie sollten diesen Einfluss nicht missbrauchen, indem sie Taktiken verwenden, die andere Editoren herabsetzen oder erniedrigen.
<G-vec01192-002-s009><belittle.herabsetzen><en> In doing so, however, they must be careful not to neglect the practice of the essence of their religion, not to disturb others by their own religious practices, and not to condemn or belittle other faiths.
<G-vec01192-002-s009><belittle.herabsetzen><de> Dabei müssen sie jedoch darauf achten, dass sie die Praxis der Essenz ihrer Religion nicht vernachlässigen, dass sie andere durch ihre religiösen Praktiken nicht stören und andere Glaubensrichtungen nicht verdammen oder herabsetzen.
<G-vec01192-002-s010><belittle.herabsetzen><en> But it is bad and wrong if at the same time the press does not expose those who belittle the importance of the collective farms and the state farms and who fail to see that the task of improving small and middle individual peasant farms must be supplemented in practice by the task of expanding the construction of collective and state farms.
<G-vec01192-002-s010><belittle.herabsetzen><de> Nicht gut und falsch ist es aber, wenn man nicht gleichzeitig diejenigen entlarvt, die die Bedeutung der Kollektiv- und Sowjetwirtschaften herabsetzen und nicht sehen, dass die Aufgabe, die individuelle kleine und mittlere Bauernwirtschaft zu heben, praktisch durch die Aufgabe ergänzt werden muss, den Aufbau der Kollektiv- und Sowjetwirtschaften zu verstärken.
<G-vec01192-002-s011><belittle.herabsetzen><en> If we belittle the mind in favour of the heart it's only because we haven't evolved to the point where we understand what it means to think with the heart.
<G-vec01192-002-s011><belittle.herabsetzen><de> Wenn wir den Gedanken zugunsten des Herzens herabsetzten, dann ist dies nur deshalb, weil wir uns noch nicht bis zu dem Punkt entwickelt haben, wo wir verstehen was es bedeutet, mit dem Herzen zu denken.
<G-vec01192-002-s012><belittle.herabsetzen><en> “Keep away from people who try to belittle your ambitions.
<G-vec01192-002-s012><belittle.herabsetzen><de> “Halte dich fern von denjenigen, die versuchen, deinen Ehrgeiz herabzusetzen.
<G-vec01192-002-s013><belittle.herabsetzen><en> Not ignorance caused that what is full of light to be arrogant against God, because it stood in highest knowledge, and exactly this knowledge was, because all-embracing, cause for its arrogance, and that is why its arrogance was a sin against God of greatest importance, because the creatures of God sought to belittle their creator, the highest and most perfect being, because they no longer acknowledged him.
<G-vec01192-002-s013><belittle.herabsetzen><de> Nicht Unkenntnis veranlaßte das Lichtvolle zur Überheblichkeit gegen Gott, denn es stand in höchstem Wissen, und eben dieses Wissen war, weil alles umfassend, Anlaß zu seiner Überheblichkeit, und darum war seine Überheblichkeit eine Sünde gegen Gott von größter Bedeutung, denn es suchten die Geschöpfe Gottes ihren Schöpfer, das höchste und vollkommenste Wesen, herabzusetzen, denn sie erkannten Ihn nicht mehr an.
<G-vec01192-002-s014><belittle.herabsetzen><en> She seemed to belittle science and promote non-science.
<G-vec01192-002-s014><belittle.herabsetzen><de> Sie schien Wissenschaft herabzusetzen und Unwissenschaftlichkeit anzupreisen.
<G-vec01192-002-s031><belittle.herabsetzen><en> He either ignores it, or, if he does not do this, he tries to belittle the manner and degree of its influence where and whenever he can.
<G-vec01192-002-s031><belittle.herabsetzen><de> Er sieht über sie hinweg, oder er sucht wenigstens die Art und das Maß ihres Einflusses herabzusetzen, wo und wie er kann.
<G-vec01192-002-s015><belittle.kleinmachen><en> If a sociopath knows your plans ahead of time, he or she might use that knowledge to harass, belittle, discourage or humiliate you.
<G-vec01192-002-s015><belittle.kleinmachen><de> Wenn ein Soziopath deine Pläne im voraus kennt, wird er dieses Wissen nutzen, um dich zu schikanieren, klein zu machen, zu entmutigen oder dich zu demütigen.
<G-vec01192-002-s019><belittle.schlechtmachen><en> If past heroes and modern champions of positive thinking can have such bouts, I need not let the Accuser belittle me just because I am appallingly negative at times.
<G-vec01192-002-s019><belittle.schlechtmachen><de> Wenn vergangene Helden und jetzige Champions des positiven Denkens solche Perioden haben können, brauche ich mich nicht vom Ankläger schlecht machen lassen, nur weil ich manchmal entsetzlich negativ sein kann.
<G-vec01192-002-s020><belittle.schlechtmachen><en> At every moment you have choice, to belittle or to encourage.
<G-vec01192-002-s020><belittle.schlechtmachen><de> In jedem Augenblick hast du eine Wahl, schlecht zu machen oder zu ermutigen.
<G-vec01192-002-s021><belittle.schlechtmachen><en> Many times people ask questions out of curiosity and not because they want to belittle your faith.
<G-vec01192-002-s021><belittle.schlechtmachen><de> Oft stellen Menschen Fragen aus Neugier und nicht weil sie unseren Glauben schlechtmachen wollen.
<G-vec01192-002-s022><belittle.schlechtmachen><en> Their friends would belittle them and mock them if they got religion.
<G-vec01192-002-s022><belittle.schlechtmachen><de> Ihre Freunde würden sie schlechtmachen und sie verspotten, wenn sie religiös würden.
<G-vec01192-002-s023><belittle.schlechtmachen><en> Such a strong movement to belittle anything that is remotely of Me.
<G-vec01192-002-s023><belittle.schlechtmachen><de> Solch eine starke Bewegung alles schlechtzumachen, das nur im Entferntesten von Mir ist.
<G-vec01192-002-s016><belittle.schmälern><en> He does not belittle her, minimize her contributions to the family, or expect her to do what God has given him to do.
<G-vec01192-002-s016><belittle.schmälern><de> Er macht sie nicht klein, schmälert ihren Beitrag zur Familie oder erwartet, dass sie das tut, was Gott von ihm erwartet.
<G-vec01192-002-s024><belittle.schmälern><en> But this shouldn’t belittle the potential KINGS AT CRIME carries.
<G-vec01192-002-s024><belittle.schmälern><de> Das soll allerdings das Potential von KINGS AT CRIME nicht schmälern.
<G-vec01192-002-s025><belittle.schmälern><en> But do not let her humiliate herself too much, and try not to belittle her.
<G-vec01192-002-s025><belittle.schmälern><de> Aber lass sie sich nicht zu sehr erniedrigen und versuche sie nicht zu schmälern.
<G-vec01192-002-s026><belittle.schmälern><en> Let no one, while this System is still in its infancy, misconceive its character, belittle its significance or misrepresent its purpose.
<G-vec01192-002-s026><belittle.schmälern><de> Niemand möge, solange dieses System noch in seinen Kinderschuhen steckt, seinen Charakter mißverstehen, seine Bedeutung schmälern oder sein Ziel mißdeuten.
<G-vec01192-002-s027><belittle.schmälern><en> And so we ask you do not belittle but you embrace all those things that keep you healthy and fit.
<G-vec01192-002-s027><belittle.schmälern><de> Und so bitten wir euch, schmälert sie nicht, aber umarmt all jene Dinge, die euch gesund und fit halten.
