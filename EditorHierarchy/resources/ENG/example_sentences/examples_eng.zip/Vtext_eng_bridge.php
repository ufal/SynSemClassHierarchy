<G-vec00279-002-s095><bridge.brücken><en> Crowne Plaza that a long walk and calm conversation are an incredible combination if you want to build a bridge.
<G-vec00279-002-s095><bridge.brücken><de> Ich habe die Erfahrung gemacht, dass ein langer Spaziergang und ein ruhiges Gespräch unschlagbar sind, wenn Sie Brücken bauen wollen.
<G-vec00279-002-s096><bridge.brücken><en> IPS e.max ZirCAD zirconium oxide is used to create high-strength frameworks, primarily for bridge restorations.
<G-vec00279-002-s096><bridge.brücken><de> Aus dem Zirkoniumoxid IPS e.max ZirCAD entstehen hochfeste Gerüste, die vor allem bei der Herstellung von Brücken zum Einsatz kommen.
<G-vec00279-002-s097><bridge.brücken><en> It is a communication body built on poles, which is built by contrast to bridge (to overcome the obstacle represented by valleys and rivers), where given the nature of the terrain was impossible or too costly to build communication on the ground.
<G-vec00279-002-s097><bridge.brücken><de> Es handelt sich um einen Verkehrsweg, der auf Säulen errichtet ist und im Unterschied zu Brücken (deren Zweck die Überwindung eines Hindernisses in Gestalt eines Tals oder Flusses ist) an solchen Orten gebaut wird, wo es im Hinblick auf den Charakter des Geländes unmöglich oder zu kostenschwer wäre, den Verkehrsweg ebenerdig zu führen.
<G-vec00279-002-s098><bridge.brücken><en> Plečnik's best known works include the National and University Library building, the Ljubljanica river embankments and bridges, the most notable among the latter being the Triple Bridge and the Cobblers' Bridge, the Central Market, the Križanke Summer Theatre, the Bežigrad Stadium, the funeral home at the Žale cemetery, and the Church of St. Michael in the Marshes.
<G-vec00279-002-s098><bridge.brücken><de> Zu seinen besten Werken zählen die National- und Universitätsbibliothek, die Gestaltung der Flussufer der Ljubljanica, ganz besonders auch die Drei Brücken (Tromostovje) und die Schusterbrücke (die Totenkapellen am Friedhof Žale sowie die St.-Michaels-Kirche im Laibacher Moor.
<G-vec00279-002-s099><bridge.brücken><en> Apart from protecting the building structure of the bridge, an additional product, Protectosil® SC CONCENTRATE, has also been applied to keep the surfaces of the bridge clean.
<G-vec00279-002-s099><bridge.brücken><de> Um die Oberflächen der Brücken sauber zu halten, wurde darüber hinaus Protectosil® SC CONCENTRATE alsweiteres Produkt angewendet.
<G-vec00279-002-s100><bridge.brücken><en> Before implantation, a fixed bridge could only be prepared if the last tooth in the row was not missing, because that tooth provided the stability of the bridge.
<G-vec00279-002-s100><bridge.brücken><de> In früheren Zeiten, ohne Implantologie, konnten festsitzende Brücken nur dann eingesetzt werden, wenn ein hinterer Zahn vorhanden war, der der Konstruktion Stabilität verlieh.
<G-vec00279-002-s101><bridge.brücken><en> Müller / Mackert: The American computer scientist Ray Kurzweil claims, with the application of information technology and biotechnology, we will be able to build the first bridge to immortality in fifteen years.
<G-vec00279-002-s101><bridge.brücken><de> Müller/Mackert:Ray Kurzweil behauptet, dass wir mittels Informationstechnologie und Biotechnik in der Lage sein werden, in 15 Jahren die ersten Brücken in die Unsterblichkeit zu bauen.
<G-vec00279-002-s102><bridge.brücken><en> Fat dots: Bridge builder - help a couple of fat dots safely cross the bridge and not fall into the abyss.
<G-vec00279-002-s102><bridge.brücken><de> In Fat Dots: Bridge Builder hilfst du einem Paar praller Bälle Brücken zu passieren und nicht in den Abgrund herabzufallen.
<G-vec00279-002-s103><bridge.brücken><en> The Links Bridge is a two-lane beam bridge connecting the center of Little Haiti on Vice City Mainland to the Leaf Links golf course located on Vice City Beach in Vice City.
<G-vec00279-002-s103><bridge.brücken><de> Die Links Bridge ist eine zweispurige Autobrücke aus Grand Theft Auto: Vice City und Grand Theft Auto: Vice City Stories, die zusammen mit anderen Brücken das Mainland mit Vice Beach verbindet.
<G-vec00279-002-s105><bridge.brücken><en> Reviews With a stay at Aparthotel Adagio access Strasbourg Petite France, you'll be centrally located in Strasbourg, within a 10-minute drive of Covered Bridge and Zenith Strasbourg.
<G-vec00279-002-s105><bridge.brücken><de> Holiday Inn Express Strasbourg - Centre besticht durch eine zentrale Lage in Straßburg, eine 5-minütige Fahrt von Gedeckte Brücken und 8 Minuten von Musée Alsacien entfernt.
<G-vec00279-002-s106><bridge.brücken><en> .. and more than one narrow bridge.
<G-vec00279-002-s106><bridge.brücken><de> .. und immer wieder über kleine Brücken.
<G-vec00279-002-s107><bridge.brücken><en> Individual Lab Box No matter if it is a single crown, a small bridge or a complete denture - present your masterpiece in one of our new “Individual Lab Boxes”.
<G-vec00279-002-s107><bridge.brücken><de> Kontaktanfrage Individual Lab Box – personalisierte Laborbox Egal ob Einzelkronen, kleine Brücken oder Totalprothesen – präsentieren Sie Ihre Meisterwerke in unseren neuen „Individual Lab Boxen“.
<G-vec00279-002-s108><bridge.brücken><en> The Wuhan Yangtze River Bridge, the first bridge over the Yangtze, was built in 1957.
<G-vec00279-002-s108><bridge.brücken><de> Wegen seiner Breite wird der Fluss von teilweise recht imposanten Brücken überspannt, unter anderem der Runyang-Brücke oder der Wuhan First Bridge.
<G-vec00279-002-s109><bridge.brücken><en> And we bridge the gap.
<G-vec00279-002-s109><bridge.brücken><de> Und wir bauen Brücken.
<G-vec00279-002-s110><bridge.brücken><en> The wide band under the bust keeps everything securely in place so that you can confidently do a bridge or a headstand.
<G-vec00279-002-s110><bridge.brücken><de> Das breite Band unter dem Busen sorgt für sicheren Halt, also kannst du Brücken machen oder dich auf den Kopf stellen.
<G-vec00279-002-s111><bridge.brücken><en> Dental implants don't sacrifice the quality of your adjacent teeth like a bridge does because neighboring teeth are not altered to support the implant.
<G-vec00279-002-s111><bridge.brücken><de> Zahn-Einsparung: Zahnimplantate nicht opfern die Struktur Ihrer benachbarten Zähne wie Brücken, weil Nachbarzähne nicht verändert werden, um das Implantat zu unterstützen.
<G-vec00279-002-s112><bridge.brücken><en> The stairs and bridge system offers an exciting climb on a former mining dump.
<G-vec00279-002-s112><bridge.brücken><de> Mehrere Treppenanlagen und Brücken ermöglichen einen spannenden Aufstieg auf die ehemalige Halde.
<G-vec00279-002-s113><bridge.brücken><en> It is also possible to bridge P2 and P3 and get both, Power and DCC from the tracks.
<G-vec00279-002-s113><bridge.brücken><de> Es ist auch möglich P2 und P3 zu brücken und Power und DCC vom Gleisanschluss zu beziehen.
<G-vec00279-002-s171><bridge.entfernen><en> Featuring free WiFi and an outdoor swimming pool, Hector Suites offers accommodation in Willemstad, 2.4 km from Queen Emma Bridge.
<G-vec00279-002-s171><bridge.entfernen><de> Mit kostenfreiem WLAN und einem Außenpool erwarten Sie die Hector Suites in Willemstad, 2,4 km von der Königin-Emma-Brücke entfernt.
<G-vec00279-002-s172><bridge.entfernen><en> The Residence Bologna is located in the heart of Prague's Old Town, just 400 metres from Charles Bridge.
<G-vec00279-002-s172><bridge.entfernen><de> Das Hotel Bristol liegt im Herzen von Salzburg, nur wenige Schritte vom Schloss Mirabell und Mozarts Geburtshaus entfernt.
<G-vec00279-002-s173><bridge.entfernen><en> Situated 400 metres from Charles Bridge in Prague, this apartment features free WiFi.
<G-vec00279-002-s173><bridge.entfernen><de> Dieses Apartment in Prag liegt 400 m vom Wenzelsplatz entfernt.
<G-vec00279-002-s174><bridge.entfernen><en> Operating a 24-hour front desk, Grand Mahkota Hotel Pontianak is located a 5-drive from the famous Kapuas Bridge.
<G-vec00279-002-s174><bridge.entfernen><de> Das Grand Mahkota Hotel Pontianak bietet eine 24-Stunden-Rezeption und liegt 5 Fahrminuten von der berühmten Kapuas-Brücke entfernt.
<G-vec00279-002-s175><bridge.entfernen><en> The Sea Pearl is also within a few minutes driving distance of shopping opportunities as well as the Cape Coral bridge towards Fort Myers for countless activities.
<G-vec00279-002-s175><bridge.entfernen><de> Das Sea Pearl ist nur wenige Minuten Fahrzeit von den vielfältigen Einkaufsmöglichkeiten und Ausflugszielen entfernt.
<G-vec00279-002-s176><bridge.entfernen><en> Warumi Bridge is 6 km from Guest House Kichi, while Kourijima Bridge is 7 km away.
<G-vec00279-002-s176><bridge.entfernen><de> Das Schloss Nakijin Gusuku liegt 1,6 km vom Apartment entfernt und die Warumi-Brücke erreichen Sie nach 6 km.
<G-vec00279-002-s177><bridge.entfernen><en> Unforgettable nights and days will be spent at Hotel Tvrz Orlice, a medieval mansion on the Nerudova 41 - Four-star hotel in an historic town house situated in the center of Prague, right on the \"Royal Route\" in close vicinity of the main entrance gate to Prague Castle and minutes from Charles Bridge.
<G-vec00279-002-s177><bridge.entfernen><de> Hotel Red Lion House (Red Lion) - Nerudova 41 - Vier-Sterne-Hotel in einem historischen Stadthaus im Zentrum von Prag, direkt an der \"Königsweg\" in unmittelbarer Nähe des Haupteingang der Prager Burg und nur wenige Minuten von der Karlsbrücke entfernt.
<G-vec00279-002-s178><bridge.entfernen><en> Enjoy the unique oldtown view across the river Elbe. Situated in the city center, surrounded by Bellevue gardens all famous sights are just a short walk over the Augustus Bridge.
<G-vec00279-002-s178><bridge.entfernen><de> Direkt im Zentrum, umgeben von romantischen Bellevue-Gärten, sind Frauenkirche, Semperoper, das Grüne Gewölbe und der Zwinger nur einen bequemen Spaziergang über die Augustusbrücke vom The Westin Bellevue Hotel Dresden entfernt.
<G-vec00279-002-s179><bridge.entfernen><en> Hotel Mandarin Oriental is located only a few minutes’ walk away from Charles Bridge in a carefully renovated D...
<G-vec00279-002-s179><bridge.entfernen><de> Von den Fenstern des Fünf-Sterne-Hotels Augustine, Mandarin Oriental liegt ein paar Minuten zu Fuß von der Karlsbrücke entfernt.
<G-vec00279-002-s180><bridge.entfernen><en> Providing a terrace and a shared lounge, Bianca Cappello House is set in Venice, not far from Ca' d'Oro and Rialto Bridge.
<G-vec00279-002-s180><bridge.entfernen><de> Mit einer Terrasse und einer Gemeinschaftslounge erwartet Sie das Bianca Cappello House in Venedig, nicht weit vom Palast Ca' d'Oro und der Rialtobrücke entfernt.
<G-vec00279-002-s181><bridge.entfernen><en> This self-catering studio apartment is 5 km from the Golden Gate Bridge.
<G-vec00279-002-s181><bridge.entfernen><de> Ein Eingang zum Golden Gate State Park liegt nur 100 m vom Motel entfernt.
<G-vec00279-002-s182><bridge.entfernen><en> Casa Duende del Tajo Offering 3 terraces with stunning views of the Puente Nuevo Bridge and the Tajo River, Casa Duende del Tajo is located in Ronda.
<G-vec00279-002-s182><bridge.entfernen><de> Mit einer herrlichen Aussicht auf Rondas Stierkampfarena liegt das Hotel Hermanos Macias nur 200 Meter von der berühmten Brücke Puente Nuevo entfernt und bietet Ihnen ein traditionelles andalusisches Restaurant mit Sitzgelegenheiten im Freien.
<G-vec00279-002-s183><bridge.entfernen><en> Located in Prague, 400 metres from the Old Town Square, 900 metres from Charles Bridge and 500 metres from the Old Town Hall with the Orloj Astronomical Clock, Apartment Court offers free WiFi.
<G-vec00279-002-s183><bridge.entfernen><de> In bester Lage, nur 200 Meter von der Karlsbrücke entfernt, bietet Ihnen das Hotel Liliova Prague Old Town elegante, klimatisierte Zimmer und ein typisch tschechisches Restaurant.
<G-vec00279-002-s184><bridge.entfernen><en> Situated in the Asian side of Istanbul, Asia Princess Hotel is only a 5-minute drive from Fatih Sultan Mehmet Bridge.
<G-vec00279-002-s184><bridge.entfernen><de> Das Asia Princess Hotel liegt auf der asiatischen Seite von Istanbul, nur eine 5-minütige Fahrt von der Fatih Sultan Mehmet-Brücke entfernt.
<G-vec00279-002-s185><bridge.entfernen><en> Located 1.1 km from Trang Tien Bridge, Hotel La Perle offers accommodation amidst the hustle and bustle of Hue.
<G-vec00279-002-s185><bridge.entfernen><de> Das Hotel La Perle liegt 1,1 km von der Trang-Tien-Brücke entfernt inmitten des lebhaften Trubels von Hue.
<G-vec00279-002-s186><bridge.entfernen><en> Sungai Petani is 36 km from PENANG BRIDGE SEAVIEW RESORT, while George Town is 5 km from the property.
<G-vec00279-002-s186><bridge.entfernen><de> Sungai Petani liegt 35 km vom Batu Ferringhi Beach Apartment entfernt, und von George Town trennen Sie 11 km.
<G-vec00279-002-s187><bridge.entfernen><en> Set 500 metres from Santa Maria del Fiore Cathedral, Guelfa Number Five offers air-conditioned accommodation in Florence, a 10-minute walk from both Piazza della Signoria square and Ponte Vecchio bridge.
<G-vec00279-002-s187><bridge.entfernen><de> Das Guelfa Number Five bietet klimatisierte Unterkünfte in Florenz, nur 500 m von der Kathedrale Santa Maria del Fiore, 10 Gehminuten von der Piazza della Signoria und der Bogenbrücke Ponte Vecchio entfernt.
<G-vec00279-002-s188><bridge.entfernen><en> This apartment is 3.3 mi (5.2 km) from Sky Garden and 3.3 mi (5.4 km) from London Bridge.
<G-vec00279-002-s188><bridge.entfernen><de> Dieses Apartment mit 4 Sternen ist 5,2 km von The O2 Arena und 7,3 km von The Shard entfernt.
<G-vec00279-002-s189><bridge.entfernen><en> The unit is 300 metres from Charles Bridge.
<G-vec00279-002-s189><bridge.entfernen><de> Sie wohnen 2 Gehminuten von der Karlsbrücke entfernt...
<G-vec00279-002-s266><bridge.überbrücken><en> This is the way in which we bridge the gap, share in what another person feels and does, and what it is like to be that person."
<G-vec00279-002-s266><bridge.überbrücken><de> Auf diese Weise überbrücken wir Kluften, nehmen daran teil, was andere fühlen und tun, und erfahren, wie es ist, diese Person zu sein.
<G-vec00279-002-s267><bridge.überbrücken><en> The basic communicative function of media is to bridge space and time. This changes interaction in a systematic way.
<G-vec00279-002-s267><bridge.überbrücken><de> Die grundlegende kommunikative Funktion von Medien, Raum und Zeit zu überbrücken, verändert Interaktion in systematischer Weise.
<G-vec00279-002-s268><bridge.überbrücken><en> At Ferratum, we aim to bridge the gap between the lives people dream and the lives people lead, to help dreams become a reality, and make the impossible, possible.
<G-vec00279-002-s268><bridge.überbrücken><de> Wir bei Ferratum möchten die Kluft zwischen dem Leben, das die Menschen träumen, und dem Leben, das die Menschen führen, überbrücken, damit Träume Realität werden und das scheinbar Unmögliche möglich wird.
<G-vec00279-002-s269><bridge.überbrücken><en> eXporter is the add on module which primarily helps bridge the gap between data source and computer aided engineering (CAE) software.
<G-vec00279-002-s269><bridge.überbrücken><de> eXporter ist das Add-on-Modul, das in erster Linie hilft, die Kluft zwischen Total Materia und computer aided engineering (CAE)-Software zu überbrücken.
<G-vec00279-002-s270><bridge.überbrücken><en> Intermediate lifts helped to bridge the differences in height between the blast furnaces.
<G-vec00279-002-s270><bridge.überbrücken><de> Zwischenaufzüge halfen dabei, die Höhenunterschiede zwischen den Hochöfen zu überbrücken.
<G-vec00279-002-s271><bridge.überbrücken><en> Also, if you need to bridge a short term bottleneck in your production, we are here for you.
<G-vec00279-002-s271><bridge.überbrücken><de> Auch wenn Sie nur einen kurzfristigen Engpass in Ihrer Produktion überbrücken wollen, sind wir für Sie da.
<G-vec00279-002-s272><bridge.überbrücken><en> There can be a considerable gap between aspirations and reality, a gap that you as a lecturer cannot bridge.
<G-vec00279-002-s272><bridge.überbrücken><de> Zwischen Anspruch und Wirklichkeit besteht manchmal eine recht große Lücke, die Sie als Dozent*in nicht überbrücken können.
<G-vec00279-002-s273><bridge.überbrücken><en> The results also hint at the potential of different visual representations to bridge the gap between everyday and more scientific modes of expression.
<G-vec00279-002-s273><bridge.überbrücken><de> Die Ergebnisse deuten auch auf das Potenzial der unterschiedlichen visuellen Darstellungen, die Lücke zwischen Alltags-und mehr wissenschaftliche Ausdrucksweise zu überbrücken.
<G-vec00279-002-s274><bridge.überbrücken><en> With our global network of collaborating transportation companies we can bridge the gap between your company and the rest of the world.
<G-vec00279-002-s274><bridge.überbrücken><de> Durch unsere globale Zusammenarbeit mit verschiedenen Partnern überbrücken wir die Distanz zwischen ihren Gütern und den weltweiten Absatzmärkten.
<G-vec00279-002-s275><bridge.überbrücken><en> Chinese smartphone gamers skew to supporting local publishers, so those looking to enter their market should focus on thorough localization and local partnerships to bridge these Western cultural differences.
<G-vec00279-002-s275><bridge.überbrücken><de> Wer in diesem Markt Fuß fassen möchte, muss sich auf gründliche Lokalisierung und Partnerschaften vor Ort fokussieren, um diese Unterschiede zur westlichen Kultur zu überbrücken.
<G-vec00279-002-s276><bridge.überbrücken><en> One of the locomotive's most interesting features is its Last Mile function that offers new logistical concepts by enabling the locomotive to easily bridge non-electrified track sections often found in ports or freight terminals.
<G-vec00279-002-s276><bridge.überbrücken><de> Eine der interessantesten neuen Funktionen der Lokomotive ist ihre Funktion auf der?letzten Meile", die neue logistische Konzepte anbietet, indem sie es der Lokomotive ermöglicht, nicht-elektrifizierte Streckenabschnitte, die man häufig in Häfen oder in Frachtterminals vorfindet, auf einfache Weise zu überbrücken.
<G-vec00279-002-s277><bridge.überbrücken><en> The military parade in Nis was also a spectacular demonstration of the efforts made by Serbian authorities to bridge the political and historical gap between Belgrade's alliances with Russia and the West.
<G-vec00279-002-s277><bridge.überbrücken><de> Im Zeichen Russlands Die Militärparade in Niš war ein Paradebeispiel für die Versuche der serbischen Staatsführung, den politisch-historischen Zwiespalt zu überbrücken, in den sie das Land hineinmanövriert hat.
<G-vec00279-002-s278><bridge.überbrücken><en> ELLS also gives scientists a chance to work with teachers, helping to bridge the widening gap between research and schools.
<G-vec00279-002-s278><bridge.überbrücken><de> ELLS eröffnet Forschern die Möglichkeit, mit Lehrern zu arbeiten und somit die zunehmend größer werdende Kluft zwischen Forschung und Schulen zu überbrücken.
<G-vec00279-002-s279><bridge.überbrücken><en> Taking a degree serve a multitude of purposes for different students: they are sometimes used to bridge the gap between different phases of academic study, or to provide additional professional training and qualifications.
<G-vec00279-002-s279><bridge.überbrücken><de> Verschiedene Studierende haben auch verschiedene Gründe dafür einen Sommerkurs zu belegen: manchmal dient es dazu, die Lücke zwischen verschiedenen Studienphasen zu überbrücken oder zusätzliche Ausbildung und Qualifikationen zu erhalten.
<G-vec00279-002-s280><bridge.überbrücken><en> Project Things is a framework of software and services that can bridge the communication gap between connected devices by giving “things” URLs on the web.
<G-vec00279-002-s280><bridge.überbrücken><de> Project Things ist ein Framework aus Software und Diensten, das die Kommunikationslücke zwischen den vernetzten Geräten überbrücken kann, indem es URLs für vernetzte Geräte bereitstellt.
<G-vec00279-002-s281><bridge.überbrücken><en> Enterprises and households take out loans in different US states during an economic downturn to bridge a slump in earnings.
<G-vec00279-002-s281><bridge.überbrücken><de> In Abschwungphasen nehmen Unternehmen und private Haushalte in verschiedenen US-Bundesstaaten Kredite auf, um Einkommenseinbrüche zu überbrücken.
<G-vec00279-002-s282><bridge.überbrücken><en> For decades, IofC led major campaigns to bridge gaps between management and labour all over Western Europe, in Brazil, Japan, New Zealand, Canada and the United States.
<G-vec00279-002-s282><bridge.überbrücken><de> Jahrzehntelang führte IofC bedeutende Kampagnen durch, um die Kluft zwischen Arbeitgebern und Arbeitnehmern in Deutschland, England und den USA zu überbrücken.
<G-vec00279-002-s283><bridge.überbrücken><en> It was through Binga’s voice, which reconstructed for me that day of performances, miles away from all art centers, that I learned about Lai’s determination to “bridge the gap” with the help of a poetic gesture, in finding an accessible language for a context where Italian was hardly spoken and illiteracy was still quite common.
<G-vec00279-002-s283><bridge.überbrücken><de> Und durch Bingas Stimme, die mir jenen Tag voller Performances weitab von allen Kunstzentren vergegenwärtigte, erfuhr ich von Lais Entschlossenheit, mithilfe einer poetischen Geste die „Kluft zu überbrücken“ und für einen Kontext, wo Italienisch kaum gesprochen wurde und Analphabetismus noch recht verbreitet war, eine für alle zugängliche Sprache zu finden.
<G-vec00279-002-s284><bridge.überbrücken><en> In order to bridge the gap, scientists at Australian research center CSIRO have used graphene to create a simple filtration system that allows water molecules to pass through nanochannels on a membrane’s surface while stopping pollutants with larger molecules.
<G-vec00279-002-s284><bridge.überbrücken><de> Um diese Kluft zu überbrücken, haben Wissenschaftler am australischen Forschungszentrum CSIRO mit Hilfe von Graphen ein einfaches Filtersystem entwickelt, bei dem Wassermoleküle durch Nanokanäle auf der Oberfläche einer Membran dringen können, nicht aber aus größeren Molekülen bestehende Schadstoffe.
