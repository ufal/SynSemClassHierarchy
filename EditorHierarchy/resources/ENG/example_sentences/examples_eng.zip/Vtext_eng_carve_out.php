<G-vec00956-002-s074><carve_out.entragen><en> If you are using a plastic shovel then take a knife and carve off the burr on the end of the shovel.
<G-vec00956-002-s074><carve_out.entragen><de> Wenn du eine Kunststoffschaufel hast, nimm ein Messer und entgrate die Kanten am Ende der Schaufel.
<G-vec00956-002-s077><carve_out.erlangen><en> We focus on IT markets where we can carve out a leading position.
<G-vec00956-002-s077><carve_out.erlangen><de> Wir fokussieren uns auf IT-Märkte, in denen wir eine führende Position erlangen können.
<G-vec00956-002-s078><carve_out.erringen><en> Even the fall of a state into despotism does not justify armed intervention from outside; it is primarily for the members of a society themselves to restore their political freedoms or else carve out a new political order.
<G-vec00956-002-s078><carve_out.erringen><de> Selbst Rückfälle in die Despotie rechtfertigen nicht als solche ein bewaffnetes Eingreifen von außen; es muss vorrangig Sache der Mitglieder eines Gemeinwesens selber bleiben, ihre politischen Freiheiten wiederherzustellen oder in einer veränderten politischen Ordnung zu erringen.
<G-vec00956-002-s085><carve_out.gewinnen><en> Carve out more time for your business and yourself while your campaigns are continuously optimized for sales and profitability.
<G-vec00956-002-s085><carve_out.gewinnen><de> Gewinnen Sie mehr Zeit für Ihr Business und für sich selber während Ihre Kampagnen kontinuierlich auf Absatz und Profitabilität optimiert werden.
<G-vec00956-002-s086><carve_out.gewinnen><en> Well, one strategy is to get ahead of the speed by getting things done faster and smarter, to carve out time for prioritized activities.
<G-vec00956-002-s086><carve_out.gewinnen><de> Nun, eine Möglichkeit besteht darin, Dinge schneller und smarter zu erledigen, um Zeit für vorrangige Aktivitäten zu gewinnen.
