<G-vec00603-002-s076><can.können><en> GageMax can also measure unknown curves and freeforms via active scanning.
<G-vec00603-002-s076><can.können><de> Aktiv scannend kann GageMax auch unbekannte Kurven und Freiformen messen.
<G-vec00603-002-s077><can.können><en> As is the case with a remote function, he can similarly intervene - not physically on the car, of course, but in a real-time dialog and by adding annotations to stills/videos, which are then shown in the mechanic's field of vision.
<G-vec00603-002-s077><can.können><de> Ähnlich einer Remote-Funktion kann er eingreifen – nicht am Auto versteht sich, doch im Echtzeit-Dialog und mit Maßnahmen wie Markierungen in Standbildern/Videos, die im Gesichtsfeld des Mechanikers eingeblendet werden.
<G-vec00603-002-s078><can.können><en> If you are logged into Facebook, Facebook can attribute the visit to our website to your Facebook account.
<G-vec00603-002-s078><can.können><de> Sind Sie bei Facebook eingeloggt, kann Facebook den Besuch unserer Website Ihrem Facebook-Konto direkt zuordnen.
<G-vec00603-002-s079><can.können><en> The length of smooth newts can reach ten centimetres.
<G-vec00603-002-s079><can.können><de> Die Länge der Teichmolche kann zehn Zentimeter erreichen.
<G-vec00603-002-s080><can.können><en> I can deal with most situations likely to arise whilst travelling in an area where the language is spoken.
<G-vec00603-002-s080><can.können><de> Ich kann die meisten Situationen bewältigen, denen man auf Reisen im Sprachgebiet begegnet.
<G-vec00603-002-s081><can.können><en> If you can’t live without them, you won’t be happy with the Pixel 2 XL.
<G-vec00603-002-s081><can.können><de> Wer darauf nicht verzichten kann, wird mit dem Pixel 2 XL nicht glücklich.
<G-vec00603-002-s082><can.können><en> Website: Ippikos Omilos Pegasus EGVUS, the Equestrian Club of Ierapetra is a friendly place where everyone can ride for fun or take private lessons with a certified instructor.
<G-vec00603-002-s082><can.können><de> EGVUS, der Reiterclub von Ierapetra ist ein freundlicher Ort, an dem jeder an einem Schnupperreiten teilnehmen oder auch Privatreitstunden mit einem zertifizierten Reitlehrer nehmen kann.
<G-vec00603-002-s083><can.können><en> Depending on what type of silicone you are using it can take anywhere from 75 minutes to overnight to cure.
<G-vec00603-002-s083><can.können><de> Abhängig vom Silikontyp kann das Aushärten 75 Minuten bis hin zu einem halben Tag benötigen.
<G-vec00603-002-s084><can.können><en> That means it can be used without any time limitation for the purchased major version.
<G-vec00603-002-s084><can.können><de> D.h. sie kann ohne Laufzeitbeschränkung für die gekaufte Hauptversion genutzt werden.
<G-vec00603-002-s085><can.können><en> A separate seating area with 2 comfortable chairs can be used as nursing and reading corner.
<G-vec00603-002-s085><can.können><de> Eine separate Sitzecke mit 2 bequemen Sesseln kann als Still- und Leseecke genutzt werden.
<G-vec00603-002-s086><can.können><en> As a group, the Food Recovery Network is extremely active and influential, but members emphasized that even just one person can still make a difference.
<G-vec00603-002-s086><can.können><de> Als eine Gruppe ist das Food Recovery Network äußerst aktiv und einflussreich, aber die Mitglieder betonten, dass jede einzelne Person einen Unterschied machen kann.
<G-vec00603-002-s087><can.können><en> Your baby can rest and play safely and comfortably in the baby bouncer, while you get a chance to take a shower, unload the dishwasher or simply take five.
<G-vec00603-002-s087><can.können><de> Dein Baby kann in der Babywippe sicher und bequem spielen, während du beruhigt eine Dusche nehmen, die Geschirrspülmaschine ausladen oder für einen Moment verschnaufen kannst.
<G-vec00603-002-s088><can.können><en> Plug-ins: Audacity can be customized by the addition of plug-ins.
<G-vec00603-002-s088><can.können><de> Plug-ins: Audacity kann durch zusätzliche Plug-ins angepasst werden.
<G-vec00603-002-s089><can.können><en> To open files with the XN extension you can use the whole range of available software.
<G-vec00603-002-s089><can.können><de> Für das Öffnen der Dateien mit der Dateiendung XN kann man eine ganze Vielfalt zugänglicher Softwares nutzen.
<G-vec00603-002-s090><can.können><en> Tip: Your travel agent can help you plan an Easter Pilgrimage to the Holy Land.
<G-vec00603-002-s090><can.können><de> Tipp: Ihr Reisebüro kann Ihnen bei der Planung Ihrer österlichen Pilgerreise ins Heilige Land behilflich sein.
<G-vec00603-002-s091><can.können><en> This favour can be deepened into strong customer relationships.
<G-vec00603-002-s091><can.können><de> Dies kann sich in starke Kundenbeziehungen vertiefen.
<G-vec00603-002-s092><can.können><en> In other words, the player can change the order in which numbers are set in the sequence.
<G-vec00603-002-s092><can.können><de> Der Spieler kann die Reihenfolge angeben, in der die Karten aus dem Deck ausgewählt werden.
<G-vec00603-002-s093><can.können><en> A gift or a compliment" can be used for personal and commercial purposes according to the conditions of the purchased Royalty-free license.
<G-vec00603-002-s093><can.können><de> Ein Geschenk oder ein Kompliment" kann für persönliche und kommerzielle Zwecke gemäß den Bedingungen der erworbenen abgabefreien (royalty-free) Lizenz verwendet werden.
<G-vec00603-002-s094><can.können><en> A prediction, which is of spiritual content and is to prompt a change, can be believed at any time, and a prophet of this kind is not to be rejected or not heard.
<G-vec00603-002-s094><can.können><de> Einer Voraussage, die geistigen Inhalts ist und eine Wandlung anregen soll, kann jederzeit Glauben geschenkt werden, und ein Prophet dieser Art soll nicht verworfen oder überhört werden.
<G-vec00603-002-s095><can.können><en> Can you save all mankind...
<G-vec00603-002-s095><can.können><de> Kannst du die ganze Menschheit retten...
<G-vec00603-002-s096><can.können><en> With a map, ideas for tours and a good fika at hand you can enjoy unique experiences in the middle of nature.
<G-vec00603-002-s096><can.können><de> Mit einer Karte, Tourenvorschlägen und einem guten Fika kannst du einzigartige Erlebnisse inmitten der Natur genießen.
<G-vec00603-002-s097><can.können><en> Updated With Chromecast you can stream Chrome directly from your browser to your TV.
<G-vec00603-002-s097><can.können><de> Aktualisiert Mit Chromecast kannst du direkt von deinem Browser Chrome auf deinen Fernseher streamen.
<G-vec00603-002-s098><can.können><en> If you want him to stay in love with you, then you can't just let him worship you.
<G-vec00603-002-s098><can.können><de> Wenn er dich auch weiterhin lieben soll, dann kannst du dich nicht einfach nur anbeten lassen.
<G-vec00603-002-s099><can.können><en> You can adjust Numbrs access to your camera in your phone's settings at any time.
<G-vec00603-002-s099><can.können><de> Du kannst diese Funktion jederzeit in den Einstellungen deines Smartphones ändern.
<G-vec00603-002-s100><can.können><en> In this interactive adult game you can touch her breasts, play with her pussy, and many other scissors game.
<G-vec00603-002-s100><can.können><de> In diesem interaktiven Spiel kannst du ihre Titten angrabschen, mit ihrer Muschi spielen u.v.m, um die tolle Brünette zu befriedigen.
<G-vec00603-002-s101><can.können><en> At the CAVV (shop in Heeten), you can order coveralls, and then we'll make sure they'll be ready for you in the right size and colour.
<G-vec00603-002-s101><can.können><de> Bei CAVV (Geschäft in Heeten) kannst Du einen Overall bestellen und wir werden sicher gehen, dass dieser in der richtigen Farbe und Größe für Dich bei Deiner Ankunft bereit steht.
<G-vec00603-002-s102><can.können><en> If your neighbor at the café is constantly looking at his watch, you can predict that he's waiting for someone.
<G-vec00603-002-s102><can.können><de> Falls dein Nachbar im Café ununterbrochen auf seine Uhr sieht, kannst du vorhersagen, dass er auf jemanden wartet.
<G-vec00603-002-s103><can.können><en> With our audits you get important KPIs of your website and can directly suggest changes to your team for improvement.
<G-vec00603-002-s103><can.können><de> Mit unseren Audits erhälst Du wichtige KPIs Deiner Webseite und kannst direkt Deinem Team Änderungen zur Verbesserung vorschlagen.
<G-vec00603-002-s104><can.können><en> "You can't leave him like that.
<G-vec00603-002-s104><can.können><de> "Du kannst ihn doch nicht so zurück lassen.
<G-vec00603-002-s105><can.können><en> Since you have absolutely everything from God – physically and spiritually – you can fearlessly dedicate yourself to your neighbour.
<G-vec00603-002-s105><can.können><de> Da du absolut alles von Gott hast – leiblich so wie geistlich – kannst du dich furchtlos deinem Nächsten widmen.
<G-vec00603-002-s106><can.können><en> You can now save time spent logging in by connecting your WordPress.com account to Land Design Landscaping.
<G-vec00603-002-s106><can.können><de> Du kannst beim Anmelden Zeit sparen, indem Du Dein WordPress.com-Konto mit Atelier & Werbeagentur verbindest.
<G-vec00603-002-s107><can.können><en> Since it is an action figure, you can change the position and posture of the horror clown at any time.
<G-vec00603-002-s107><can.können><de> Da es sich um eine Actionfigur handelt, kannst du die Position und Körperhaltung des Horror Clowns jederzeit verändern.
<G-vec00603-002-s108><can.können><en> Besides Malaysian Grand Prix results you can follow 5000+ competitions from 30+ sports around the world on FlashScore.ae.
<G-vec00603-002-s108><can.können><de> Neben Malaysian Grand Prix Ergebnissen kannst du 5000+ Wettbewerben aus 30 Sportarten weltweit auf FlashScore.de verfolgen.
<G-vec00603-002-s109><can.können><en> If you don't find one you like, there are tea party hat kits to make your own hat that can also be purchased online.
<G-vec00603-002-s109><can.können><de> Wenn du keinen findest, der dir gefällt, dann gibt es Sets für Teeparty-Hüte, aus denen du deinen eigenen Hut machen kannst.
<G-vec00603-002-s110><can.können><en> You can’t even read.
<G-vec00603-002-s110><can.können><de> Du kannst doch gar nicht lesen.
<G-vec00603-002-s111><can.können><en> No, but you can dismantle and rebuild using the same plan.
<G-vec00603-002-s111><can.können><de> Nein, du kannst sie aber abbauen und sie mit dem gleichen Bauplan an anderer Stelle wieder aufbauen.
<G-vec00603-002-s112><can.können><en> You can also design your flyer with images much smaller than the recommended sizes and place them Of course not.
<G-vec00603-002-s112><can.können><de> Du kannst Deine Fotokarten auch mit Bildern gestalten, die deutlich kleiner sind als die empfohlenen Größen und diese an beliebigen Stellen auf den Fotokarten platzieren.
<G-vec00603-002-s113><can.können><en> Remember that the fabric is stretchy and you can always make it a little wider if you need to.
<G-vec00603-002-s113><can.können><de> Denke daran, dass der Stoff dehnbar ist und du ihn zur Not immer noch etwas weiter machen kannst.
<G-vec00603-002-s114><can.können><en> These cognitive biases are mental short-cuts that can serve us well in everyday life but are unhelpful when it comes to investment.
<G-vec00603-002-s114><can.können><de> Diese kognitiven Verzerrungen sind mentale Abkürzungen, die uns im Alltag viele Vorteile bescheren können, bei Anlageentscheidungen hingegen alles andere als dienlich sind.
<G-vec00603-002-s115><can.können><en> You can then re-use the same local files within your development or testing VM environments without having to download them or sync them into source code repositories first.
<G-vec00603-002-s115><can.können><de> Anschließend können Sie dieselben lokalen Dateien in den Entwicklungs- oder Testumgebungen der VM wiederverwenden, ohne sie zuerst herunterladen oder mit Code-Repositorys für den Quellcode synchronisieren zu müssen.
<G-vec00603-002-s116><can.können><en> With our iPhone X battery kit you can easily change the battery of your iPhone.
<G-vec00603-002-s116><can.können><de> Mit diesem Akku-Set von GIGA Fixxoo können Sie schnell & einfach den Akku ihres iPhone x tauschen.
<G-vec00603-002-s117><can.können><en> On this page you can completely free to download User's Manual Crown Boiler CWD083.
<G-vec00603-002-s117><can.können><de> Auf dieser Seite können Sie komplett kostenlos herunterladen Handbuch Crown Boiler CWI138.
<G-vec00603-002-s118><can.können><en> Israeli residents can register here
<G-vec00603-002-s118><can.können><de> Anwohner von Israel können sich hier registrieren.
<G-vec00603-002-s119><can.können><en> Thus, measures such as initial work experience placement, supporting young entrepreneurs in starting a business, and high-quality education and training can be promoted.
<G-vec00603-002-s119><can.können><de> So können Maßnahmen, wie die Vermittlung erster Arbeitserfahrungen, Unterstützung junger Unternehmer bei der Unternehmensgründung oder hochwertige Aus- und Weiterbildung gefördert werden.
<G-vec00603-002-s120><can.können><en> It is located at the highest point of the lake and from there you can admire a wide view of the lake and the surrounding mountains.
<G-vec00603-002-s120><can.können><de> Es befindet sich auf dem höchsten Punkt des Sees und von dort können Sie einen weiten Blick auf den See und die umliegenden Berge bewundern.
<G-vec00603-002-s121><can.können><en> Some solutions even allow you to create self-service Web portals where standard users can pick and choose the software they want to install.
<G-vec00603-002-s121><can.können><de> Einige Lösungen ermöglichen Ihnen sogar die Erstellung von benutzerverantwortlichen Webportalen, in denen Standardbenutzer die zu installierende Software selbst auswählen können.
<G-vec00603-002-s122><can.können><en> Well, all our apartments have a patio where you can read a book or sip a cool drink while enjoying the calm and tranquillity of our garden.
<G-vec00603-002-s122><can.können><de> Alle unsere Wohnungen verfügen über eine Terrasse or Patio, wo Sie ein Buch lesen oder einen kühlen Drink trinken können während Sie die Ruhe in unserem Garten genießen.
<G-vec00603-002-s123><can.können><en> You can use the search form to rent a car at John Glenn Columbus International Airport (CMH) Enterprise.
<G-vec00603-002-s123><can.können><de> Sie können das Suchformular verwenden, um ein Auto bei John Glenn Columbus Internationaler Flughafen (CMH) Enterprise zu mieten.
<G-vec00603-002-s124><can.können><en> You can free download PDF manuals for KX W482 Yamaha Cassette Player.
<G-vec00603-002-s124><can.können><de> Sie können Handbücher in PDF kostenlos herunterladen für CT/KXF-W Kenwood Kassettenspieler.
<G-vec00603-002-s125><can.können><en> Additional conditions or those differing from these General Conditions may not be to the consumer’s detriment and shall be laid down in writing or in such a manner that the consumer can store them in an accessible manner on a sustainable data carrier.
<G-vec00603-002-s125><can.können><de> Bestimmungen, die von den vorliegenden Allgemeinen Geschäftsbedingungen abweichen oder diese ergänzen, dürfen nicht zum Nachteil des Verbrauchers gereichen und müssen schriftlich oder so festgelegt werden, dass sie auf einem dauerhaften Datenträger auf den der Verbraucher Zugriff hat, gespeichert werden können.
<G-vec00603-002-s126><can.können><en> You can prepare simple meals in your kitchen.
<G-vec00603-002-s126><can.können><de> In Ihrer Küche können Sie sich einfache Mahlzeiten zubereiten.
<G-vec00603-002-s127><can.können><en> In online stores, products can not be touched, for this reason, all possible data is needed, such as: contact information, return policy, etc.
<G-vec00603-002-s127><can.können><de> In Online-Shops können Produkte nicht angefasst werden, daher werden alle möglichen Daten benötigt, wie zB: Kontaktinformationen, Rückgaberecht, etc.
<G-vec00603-002-s128><can.können><en> With a BlueChimney fan you can therefore light the fire in the wood-burning stove without worrying about smoke in the living room or next door.
<G-vec00603-002-s128><can.können><de> Deshalb können Sie mit dem BlueChimney Rauchsauger Ihren Kamin nutzen, ohne sich um die Rauchbelästigung für Sie und Ihre Nachbarn zu sorgen.
<G-vec00603-002-s129><can.können><en> Every business and merchant can connect customers to the Capripay system and generate additional income by earning Cashback on the purchases of their customers from other businesses & merchants that offer Capripay as a unique payment method to their customers and business partners.
<G-vec00603-002-s129><can.können><de> Jedes Unternehmen und Händler können Kunden mit dem Capripay-System verbinden und zusätzliche Einnahmen erzielen, indem sie Cashback auf die Einkäufe ihrer Kunden von anderen Unternehmen und Händlern erwirtschaften, die Capripay als Zahlungsmethode für ihre Kunden anbieten.
<G-vec00603-002-s130><can.können><en> You can´t ask for a more stunning and interesting view both by day and by night.
<G-vec00603-002-s130><can.können><de> Sie können keine atemberaubendere und interessantere Aussicht verlangen, sowohl tagsüber wie auch nachts.
<G-vec00603-002-s131><can.können><en> Transfer from the airport, iron, DVD player, Sony Playstation 3, baby cot and high chair can be ordered for an extra fee.
<G-vec00603-002-s131><can.können><de> Transfer vom Flughafen, Bügeleisen, DVD-Player, Sony Playstation 3, Babybett und Hochstuhl können gegen eine zusätzliche Gebühr bestellt werden.
<G-vec00603-002-s132><can.können><en> This will be your free lifetime membership to Camsola, meaning you can come back any time you want.
<G-vec00603-002-s132><can.können><de> Dies wird Ihre lebenslange kostenlose Mitgliedschaft bei Camsola sein, was bedeutet, dass Sie jederzeit zurückkommen können.
<G-vec00603-002-s133><can.können><en> Plus, you can switch back at any time if you change your mind.
<G-vec00603-002-s133><can.können><de> Außerdem könnt ihr jederzeit wieder zurückwechseln, falls ihr eure Meinung ändern solltet.
<G-vec00603-002-s134><can.können><en> It will help you to read this book: it is pocket-sized, so you can take it with you.
<G-vec00603-002-s134><can.können><de> Dieses Buch zu lesen wird euch helfen: es ist ein Taschenbuch, ihr könnt es bei euch tragen.
<G-vec00603-002-s135><can.können><en> In a few clicks you can easily search, compare and book your Gisborne accommodation by clicking directly through to the hotel or travel agent website.
<G-vec00603-002-s135><can.können><de> Mit nur wenigen Klicks könnt ihr eure Unterkunft in Saint John suchen, vergleichen und buchen, indem ihr direkt zur Hotel- oder Reiseanbieter-Website weitergeleitet werdet.
<G-vec00603-002-s136><can.können><en> As of right now, you can read all the exciting articles in our app or on the Design & Innovation Award Website. Enjoy reading
<G-vec00603-002-s136><can.können><de> All diese und viele weitere spannende Artikel könnt ihr ab sofort über unsere interaktive App auf eurem Tablet oder Smartphone oder auf der Design & Innovation Award Website lesen.
<G-vec00603-002-s137><can.können><en> And as you are reading this post right now, you can be sure that this recipe rocked my kitchen.
<G-vec00603-002-s137><can.können><de> Da es dieses Rezept bis auf meinen Blog geschafft hat, könnt Ihr Euch sicher sein, dass es sich lohnt und nachvollziehbar ist.
<G-vec00603-002-s138><can.können><en> Provide the ticket reference code or your email address, follow the buttons to direct yourself to the right place, and provide a brief explanation: everything is organised so you can help us to help you more efficiently.
<G-vec00603-002-s138><can.können><de> Bitte gebt euren Ticket-Referenzcode oder eure E-Mail-Adresse an, klickt euch durch die nächsten Schritte und erklärt uns kurz worum es geht: Es ist also alles organisiert, damit ihr uns helfen könnt, euch besser zu helfen.
<G-vec00603-002-s139><can.können><en> You can easily slip an extra portion of protein into your diet: Stir a few tablespoons of watered lupine seeds in soups, or add nuts and seeds as the perfect topping for granola bowls, salads or smoothies.
<G-vec00603-002-s139><can.können><de> Eine Extraportion Protein könnt ihr in euren Speiseplan ganz einfach integrieren: Ein paar Esslöffel Lupinensamen lassen sich gut gewässert in Suppen mitkochen, während Nüsse und Samen das perfekte Topping für Müslis, Salate oder Smoothies abgeben.
<G-vec00603-002-s140><can.können><en> Lieutenant Pierce - What my lord means to say is that we understand, if you can't leave your work.
<G-vec00603-002-s140><can.können><de> Lieutenant Pierce - Was mein Sith-Lord damit sagen will, ist, dass wir es verstehen, wenn Ihr Eure Arbeit nicht im Stich lassen könnt.
<G-vec00603-002-s141><can.können><en> You can see a picture at my Master System Set, which I am renewing entirely at the moment.
<G-vec00603-002-s141><can.können><de> Das Foto dazu könnt Ihr im Master System Set finden, das ich aktuell vollständig überarbeite.
<G-vec00603-002-s142><can.können><en> So we hope that you can enjoy this place and feel the power of the sea.
<G-vec00603-002-s142><can.können><de> So hoffen wir, dass auch ihr diesen Ort genießen könnt und die Kraft des Meeres spürt.
<G-vec00603-002-s143><can.können><en> If you are based in Germany, you can fly with KLM from almost any airport just to Aruba.
<G-vec00603-002-s143><can.können><de> Wenn ihr in Deutschland ansässig seid, könnt ihr mit KLM von fast jedem Flughafen aus einfach nach Aruba fliegen.
<G-vec00603-002-s144><can.können><en> And for all the cat's moms and daddies who are also sad because they have lost their velvet paws, we have set up a guestbook, where you can leave your "paw's prints".
<G-vec00603-002-s144><can.können><de> Und für alle Katzenmamis und Katzendaddys, die ebenfalls traurig sind, weil sie ihr Samtpfötchen verloren haben, haben wir ein Gästebuch eingerichtet, wo ihr Pfötchenabdrücke hinterlassen könnt.
<G-vec00603-002-s145><can.können><en> Our Early Access launch build does have a specific endpoint in terms of how far into the Underworld you can go, and you won’t be able to get to the end of the story just yet -- we’ll be saving that for when we’re finished.
<G-vec00603-002-s145><can.können><de> Die Version für den Early Access hat einen bestimmten Endpunkt, wie weit ihr in die Unterwelt vordringen könnt, damit ihr das Ende der Geschichte noch nicht erreicht – das verwahren wir so lange, bis wir fertig sind.
<G-vec00603-002-s146><can.können><en> You will earn points during each round that can be used to purchase weapons from the Loadout menu (PC: L key, Console: Map key(System menu/Touch pad)).
<G-vec00603-002-s146><can.können><de> In jeder Runde verdient ihr euch Punkte, mit denen Ihr im Ausstattungsmenü (PC: L-Taste / Konsole: Map-Taste(Systemmenü/Touchpad)) Waffen kaufen könnt.
<G-vec00603-002-s147><can.können><en> Of course you can also see when the staff is giving the dogs food.
<G-vec00603-002-s147><can.können><de> Außerdem könnt ihr sehen, wie die Hunde Nachmittags mit den Resten von den Hotels gefüttert werden.
<G-vec00603-002-s148><can.können><en> By going to Settings and selecting Storage space, you can access the list.
<G-vec00603-002-s148><can.können><de> In den Einstellungen könnt Ihr unter Speicher auf die entsprechende Liste zugreifen.
<G-vec00603-002-s149><can.können><en> Then you can try to find a translator – the buttons can help you with that.
<G-vec00603-002-s149><can.können><de> Dann könnt ihr versuchen eine*n Übersetzer*in zu finden – die Buttons helfen euch dabei.
<G-vec00603-002-s150><can.können><en> You can only do this outside the pool.
<G-vec00603-002-s150><can.können><de> Ihr könnt das nur außerhalb des Pools tun.
<G-vec00603-002-s151><can.können><en> The exact wording of the association's purpose you can read in the attached Statute.
<G-vec00603-002-s151><can.können><de> Den genauen Wortlaut des Vereinszwecks könnt ihr auch in der angehängten Satzung nachlesen.
