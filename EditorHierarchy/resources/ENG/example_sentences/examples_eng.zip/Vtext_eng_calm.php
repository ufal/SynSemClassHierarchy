<G-vec00536-002-s038><calm.beruhigen><en> So calm down, stop thinking negative and empower yourself.
<G-vec00536-002-s038><calm.beruhigen><de> Also beruhige dich, hör auf negativ zu denken und bestärke dich selbst.
<G-vec00536-002-s039><calm.beruhigen><en> Calm yourself, I beseech you, I conjure you—the wound is slight.
<G-vec00536-002-s039><calm.beruhigen><de> Beruhige Dich, Herrin, ich bitte, ich beschwöre Dich...
<G-vec00536-002-s040><calm.beruhigen><en> Calm yourself with meditation.
<G-vec00536-002-s040><calm.beruhigen><de> Beruhige dich mit Meditation.
<G-vec00536-002-s041><calm.beruhigen><en> First of all, calm down and try to discuss the situation with the boss.
<G-vec00536-002-s041><calm.beruhigen><de> Beruhige dich zuerst und versuche die Situation mit dem Chef zu besprechen.
<G-vec00536-002-s042><calm.beruhigen><en> Calm yourself and have a copy of Yodot PPT Repair program installed in your Windows computer that can mend corrupted PowerPoint presentation effectively.
<G-vec00536-002-s042><calm.beruhigen><de> Beruhige dich und habe eine Kopie von Yodot PPT Repair-Programm in deinem Windows-Computer installiert, die eine beschädigte PowerPoint-Präsentation effektiv verbessern kann.
<G-vec00536-002-s043><calm.beruhigen><en> Calm the horse.
<G-vec00536-002-s043><calm.beruhigen><de> Beruhige das Pferd.
<G-vec00536-002-s044><calm.beruhigen><en> Depression, lack of energy, constant dissatisfaction, tension, rapid heart beat, feeling of numbness in my left hand, nervousness, and a little more aggressive attitude towards others, this I was made aware of more and more by my loved ones – calm down or you'll get sick.
<G-vec00536-002-s044><calm.beruhigen><de> Depression, Energiemangel, ständige Unzufriedenheit, Spannung, schneller Herzschlag, Taubheitsgefühl in der linken Hand, Nervosität, und ein wenig mehr aggressiver Haltung gegenüber anderen, dessen ich mehr und mehr von meinen Lieben bewusst gemacht worden bin, - beruhige dich oder du wirst krank werden.
<G-vec00536-002-s045><calm.beruhigen><en> Just do everything in your power, and calm down, "- says Tanya Remer Altman, MD.
<G-vec00536-002-s045><calm.beruhigen><de> Mach einfach alles in deiner Macht, und beruhige dich ", sagt Tanya Remer Altman, MD.
<G-vec00536-002-s046><calm.beruhigen><en> LOCKE: Calm down.
<G-vec00536-002-s046><calm.beruhigen><de> Locke: Beruhige dich.
<G-vec00536-002-s047><calm.beruhigen><en> Description Soothe and calm stressed, damaged skin with the Ananda Antioxidant-Rich Gentle Toner from organic experts Antipodes.
<G-vec00536-002-s047><calm.beruhigen><de> Beschreibung Beruhige gestresste, geschädigte Haut mit dem Ananda Antioxidant-Rich Gentle Toner von den organischen Experten von Antipodes.
<G-vec00536-002-s048><calm.beruhigen><en> Try to relax and calm down, with your hands on your chest.
<G-vec00536-002-s048><calm.beruhigen><de> Versuche dich zu entspannen und beruhige dich mit deinen Händen auf deiner Brust.
<G-vec00536-002-s049><calm.beruhigen><en> Please calm down a bit.
<G-vec00536-002-s049><calm.beruhigen><de> Bitte beruhige dich ein wenig.
<G-vec00536-002-s050><calm.beruhigen><en> Then Aunt Larisa would say severely: "Vitya, calm down!"
<G-vec00536-002-s050><calm.beruhigen><de> Tante Larisa sagte in so einem Moment immer: “Witja, beruhige dich!“.
<G-vec00536-002-s051><calm.beruhigen><en> As evening comes, mother drinks once, twice and again, raving, yelling, cursing men and father locks his study door while I entreat her: please calm down, once, twice and again.
<G-vec00536-002-s051><calm.beruhigen><de> Der Abend kommt, Mutter trinkt einmal, zweimal und wieder, wütet, brüllt, verflucht die Männer, während Vater sich in sein Zimmer schließt und ich zu ihr flehe: beruhige dich doch, einmal, zweimal und wieder.
<G-vec00536-002-s052><calm.beruhigen><en> Calm down and wait for the summer.
<G-vec00536-002-s052><calm.beruhigen><de> Beruhige dich und warte auf den Sommer.
<G-vec00536-002-s053><calm.beruhigen><en> Calm upset passengers, repair stuck doors, sell tickets correctly, and extend the ramp for wheel chair passengers in a timely manner.
<G-vec00536-002-s053><calm.beruhigen><de> Beruhige aufgebrachte Fahrgäste, repariere klemmende Türen, gib korrekt die Tickets aus und fahre die Rampe rechtzeitig für Rollstuhlfahrer aus.
<G-vec00536-002-s054><calm.beruhigen><en> If you have something against your brother, against your sister, go.... First pray, calm your soul, and then go and say to him, to her: I do not agree with this... you have done a bad thing...”.
<G-vec00536-002-s054><calm.beruhigen><de> Wenn du etwas gegen deinen Bruder, deine Schwester hast, dann geh hin… Bete erst einmal, beruhige dich, und dann geh hin und rede mit ihm oder mit ihr: »Ich bin damit nicht einverstanden… du hast Unrecht getan …«.
<G-vec00536-002-s241><calm.bewahren><en> A month later a New York Times correspondent wrote from Shanghai, “The Red troops began putting up posters in Chinese instructing the populace to be calm and assuring them they had nothing to fear.”
<G-vec00536-002-s241><calm.bewahren><de> Einen Monat später berichtete ein Korrespondent der New York Times aus Shanghai: Durch Plakate in Chinesisch forderte die Rote Armee die Bevölkerung auf, Ruhe zu bewahren, und versicherte ihr, sie habe nichts zu befürchten.
<G-vec00536-002-s242><calm.bewahren><en> A willingness to communicate, foreign language skills, a good grasp of the situation and the ability to remain calm even in stressful situations round off the requirements profile.
<G-vec00536-002-s242><calm.bewahren><de> Kommunikationsfreude, Fremdsprachenkenntnisse, eine gute Auffassungsgabe und die Fähigkeit, auch in stressigen Situationen die Ruhe zu bewahren, runden das Anforderungsprofil ab.
<G-vec00536-002-s243><calm.bewahren><en> Important: stay calm.
<G-vec00536-002-s243><calm.bewahren><de> Aber bei allem: Ruhe bewahren.
<G-vec00536-002-s244><calm.bewahren><en> Remaining calm is key.
<G-vec00536-002-s244><calm.bewahren><de> Ruhe bewahren ist der Schlüssel.
<G-vec00536-002-s245><calm.bewahren><en> Yet this is not a rehearsal, THIS IS FOR REAL and with unexpected or surprising events always possible, AND/ALTHOUGH CMAton at the steering wheel to adjust where necessary, I need to point out that remaining calm and balanced and well rested, as advised before, is the way to go.
<G-vec00536-002-s245><calm.bewahren><de> Jedoch ist dies keine Übung, DIES IST ECHT, und daher sind unerwartete und überraschende Ereignisse immer möglich, UND/OBWOHL CMAton am Steuerrad steht, um Anpassungen vorzunehmen wo nötig, muss Ich darauf hinweisen, daß - wie schon früher angeraten - der richtige Weg darin besteht, Ruhe zu bewahren, ausgeglichen zu bleiben und gut ausgeruht zu sein.
<G-vec00536-002-s246><calm.bewahren><en> But that's another thing that I have learnt – to remain calm, hear the other person out, reflect and then react.
<G-vec00536-002-s246><calm.bewahren><de> Aber auch das ist eine Sache, die ich gelernt habe: die Ruhe zu bewahren, andere ausreden zu lassen, nachzudenken und dann zu reagieren.
<G-vec00536-002-s247><calm.bewahren><en> The government tried not to raise the alarm and called on the population to ‘stay calm' and ‘quietly focus on their normal activities'.
<G-vec00536-002-s247><calm.bewahren><de> Die Regierung will Panik verhindern und ruft die Bevölkerung dazu auf, „Ruhe zu bewahren“ und „in Ruhe ihren gewohnten Tätigkeiten“ nachzugehen.
<G-vec00536-002-s248><calm.bewahren><en> The municipality has worked closely with religious leaders to calm the streets.
<G-vec00536-002-s248><calm.bewahren><de> Die Kommune hat dabei eng mit den religiösen Führern kooperiert, um die Ruhe auf den Straßen zu bewahren.
<G-vec00536-002-s249><calm.bewahren><en> Diaphragmatic breathing, like meditation, has been proven to reduce anxiety and stress and induce calm.
<G-vec00536-002-s249><calm.bewahren><de> Zwerchfellatmung, wie bei der Meditation, hat sich bewährt, wenn es darum geht, Angst und Stress zu reduzieren und Ruhe zu bewahren.
<G-vec00536-002-s250><calm.bewahren><en> It is not easy at the present time to remain calm, to observe calmly, judge calmly, speak
<G-vec00536-002-s250><calm.bewahren><de> Es ist nicht leicht, in diesen Tagen Ruhe bewahren: ruhig sehen, ruhig urteilen, ruhig reden.
<G-vec00536-002-s251><calm.bewahren><en> In the meantime, e-commerce companies must remain calm.
<G-vec00536-002-s251><calm.bewahren><de> In der Zwischenzeit gilt es für E-Commerce Unternehmen die Ruhe zu bewahren.
<G-vec00536-002-s252><calm.bewahren><en> Fortunately, there are a number of ways to help deal with the disappointment and stress and stay calm.
<G-vec00536-002-s252><calm.bewahren><de> Glücklicherweise gibt es eine Reihe von Möglichkeiten, die helfen mit der Enttäuschung und dem Stress umzugehen und Ruhe zu bewahren.
<G-vec00536-002-s222><calm.ruhen><en> Greenery, calm, and authenticity are the key words of this charming 3 star chalet located in the Ardennes, in the province of Namur, about ten kilometres from Durbuy.
<G-vec00536-002-s222><calm.ruhen><de> Grünes Ambiente, Ruhe, Authentizität… Das sind die Schlüsselworte, mit denen man dieses charmante, in der Provinz Namur in den Ardennen gelegene 3-Sterne-Chalet beschreiben kann.
<G-vec00536-002-s223><calm.ruhen><en> For Baumeister, the Gilgamesh epic in particular became the ultimate parable of human life, of the struggle with and victory over danger, of the attempt to escape defeat through eternal life, but also of the stoic calm to come to terms with his fate.
<G-vec00536-002-s223><calm.ruhen><de> Insbesondere das Gilgamesch-Epos wurde für ihn zum Gleichnis menschlichen Lebens schlechthin, für den Kampf und den Sieg über die Gefahr, für den Versuch, dem Niedergang durch ewiges Leben zu entgehen, aber auch für die stoische Ruhe, sich in sein Schicksal zu fügen.
<G-vec00536-002-s224><calm.ruhen><en> Fully embodying coolness and modernity, it radiates effortless simplicity and calm.
<G-vec00536-002-s224><calm.ruhen><de> Es verkörpert Coolness und Modernität, strahlt aber gleichzeitig natürliche Schlichtheit und Ruhe aus.
<G-vec00536-002-s225><calm.ruhen><en> We would smile and laugh together when the tranquil tune came back after the climax—the peace and calm after the storm.
<G-vec00536-002-s225><calm.ruhen><de> Zusammen saßen wir froh da und lachten, als nach dem Höhepunkt die beruhigende Melodie zurückkehrte – der Friede und die Ruhe nach dem Sturm.
<G-vec00536-002-s226><calm.ruhen><en> Treat yourself to some time out in a uniquely rural setting and discover ethereal connections in an oasis of calm.
<G-vec00536-002-s226><calm.ruhen><de> Gönnen Sie sich eine kleine Auszeit in einzigartiger Landschaft und erfahren Sie die Verbindung mit den feinstofflichen Welten in einer Oase der Ruhe.
<G-vec00536-002-s227><calm.ruhen><en> The sycamore map is considered a symbol of wholeness and is an impressive survivor who shows us through his way of life the mastery of calm, serenity and confidence.
<G-vec00536-002-s227><calm.ruhen><de> Der Bergahorn gilt als Symbol der Ganzheit und ist ein eindrucksvoller Überlebenskünstler, der uns durch seine Lebensweise die Meisterschaft der Ruhe, Gelassenheit und Zuversicht zeigt.
<G-vec00536-002-s228><calm.ruhen><en> I exude an engaging calm and enchant every man with my being.
<G-vec00536-002-s228><calm.ruhen><de> Ich strahle eine einnehmende Ruhe aus und verzaubere jeden Mann mit meinem Wesen.
<G-vec00536-002-s229><calm.ruhen><en> This superb residence leaves one feeling luxuriantly suspended in time, in an all-embracing calm and serenity that permeates the warm Moroccan air surrounding this extraordinary ryad.
<G-vec00536-002-s229><calm.ruhen><de> Diese luxuriöse Residenz, geradezu die Verkörperung marokkanischer Grazie und Gastfreundschaft, verleiht ihren Gästen das Gefühl von Zeit- und Schwerelosigkeit, in einer allumfassenden Ruhe und Heiterkeit, die diesen außergewöhnlichen Riad so selbstverständlich durchzieht wie die warme marokkanische Luft.
<G-vec00536-002-s230><calm.ruhen><en> They were days of calm and relaxation in a village atmosphere and an ideal setting for walking, photography, food and drink leisurely.
<G-vec00536-002-s230><calm.ruhen><de> Es waren Tage der Ruhe und Entspannung in einer ländlichen Atmosphäre und ein idealer Ort zum Wandern, Fotografie, Essen und Trinken gemächlich.
<G-vec00536-002-s231><calm.ruhen><en> Air conditioning and calm are very valuable.
<G-vec00536-002-s231><calm.ruhen><de> Klimaanlage und Ruhe sind sehr wertvoll.
<G-vec00536-002-s232><calm.ruhen><en> Positioned right in the centre of Norddorf, here you can enjoy calm, a bracing climate, the indiviual character of the buildings and a light and varied cuisine.
<G-vec00536-002-s232><calm.ruhen><de> Im Ortskern von Norddorf genießen Sie die Ruhe und das Reizklima, das individuelle Ambiente der einzelnen Häuser sowie die leichte und abwechslungsreiche Küche.
<G-vec00536-002-s233><calm.ruhen><en> We had music until 11am and calm returned. Turkey Add to selection
<G-vec00536-002-s233><calm.ruhen><de> Wir hatten Musik bis 11 Uhr und dann kehrte die Ruhe zurück.
<G-vec00536-002-s234><calm.ruhen><en> Keep calm, breathe deeply and love Moritz.
<G-vec00536-002-s234><calm.ruhen><de> Bewahre die Ruhe, atme tief durch und liebe Moritz.
<G-vec00536-002-s235><calm.ruhen><en> Ground floor apartment of a detached house with a children's games, with calm, with shops nearby, between Saint-Claude and Oyonnax.
<G-vec00536-002-s235><calm.ruhen><de> Wohnung im Erdgeschoss eines Einfamilienhauses mit einem Kinderspielen, mit Ruhe, mit Geschäften in der Nähe, zwischen Saint-Claude und Oyonnax.
<G-vec00536-002-s236><calm.ruhen><en> Here, the energy of metropolitan Berlin meets the calm of Tiergarten and the idyllic peacefulness of the River Spree’s banks.
<G-vec00536-002-s236><calm.ruhen><de> Hier trifft die Energie der Metropole Berlin auf die Ruhe des Tiergartens und die Idylle der Spreeufer.
<G-vec00536-002-s237><calm.ruhen><en> His calm and comfort will ensure you a successful holiday.
<G-vec00536-002-s237><calm.ruhen><de> Seine Ruhe und Komfort sorgen für einen gelungenen Urlaub.
<G-vec00536-002-s238><calm.ruhen><en> This sport requires skill, calm and a shot of adrenaline that makes it highly addictive.
<G-vec00536-002-s238><calm.ruhen><de> Er erfordert Sachkenntnis, Ruhe und eine gewisse Dosis Adrenalin, die süchtig macht.
<G-vec00536-002-s239><calm.ruhen><en> In our house there is much calm and tranquility thanks to the neighborhood in which we live.
<G-vec00536-002-s239><calm.ruhen><de> In unserem Haus gibt es viel Ruhe und Beschaulichkeit dank der Nachbarschaft in der wir leben.
<G-vec00536-002-s240><calm.ruhen><en> It is with joy that they welcome you in the calm and serenity of their guest rooms for long walks in the country craftsmen, abbeys and castles.
<G-vec00536-002-s240><calm.ruhen><de> Mit Freude begrüßen sie Sie in der Ruhe und Gelassenheit ihrer Zimmer für lange Spaziergänge in den Land Handwerkern, Abteien und Burgen.
<G-vec00536-002-s418><calm.stillen><en> As a calm and peaceful corner in the bustling city, Holiday Inn Express Shanghai Putuo is located in central Puxi along Su Zhou River, a 10-minute stroll from Longde Road Subway Station (Line 11).
<G-vec00536-002-s418><calm.stillen><de> Beschreibung In einem stillen, ruhigen Winkel im Zentrum der geschäftigen Stadt begrüßt Sie das Holiday Inn Express Shanghai Putuo in Puxi am Fluss Su Zhou.
<G-vec00536-002-s419><calm.stillen><en> Because of the calm sea and the peace around one, one could concentrate all the more on the sky with its millions of shades of grey.
<G-vec00536-002-s419><calm.stillen><de> Wegen der stillen See und der Ruhe um einen herum konnte man sich um so mehr auf den Himmel mit seinen Millionen von Schattierungen von Grau konzentrieren.
<G-vec00536-002-s420><calm.stillen><en> Horse trekking, tennis and fishing await those who instead of thrills prefer the calm tranquillity of a lake or the gentle rocking of a horse.
<G-vec00536-002-s420><calm.stillen><de> Für ruhigere Gemüter, die den Rücken eines Pferdes oder einen stillen See dem Adrenalinkitzel vorziehen, gibt es die Gelegenheit zum Reiten, Tennisspielen und Angeln.
<G-vec00536-002-s421><calm.stillen><en> Great suns spurted fire about, splendid fireflies flew into the blue air, and everything was reflected in the clear, calm sea beneath.
<G-vec00536-002-s421><calm.stillen><de> Große Sonnen sprühten herum, prächtige Feuerfische flogen in die blaue Luft, und alles glänzte in der klaren, stillen See wieder.
<G-vec00536-002-s422><calm.stillen><en> The hotel offering three-star services, is located in the calm and quiet part of the town, however, it is still close to the town centre.
<G-vec00536-002-s422><calm.stillen><de> Das Hotel mit drei Sterne Dienstleistungen liegt im stillen und ruhigen Teil der Stadt, ist aber dennoch nahe des Stadtzentrums.
<G-vec00536-002-s423><calm.stillen><en> It features a daily breakfast buffet, a large beer garden, and a calm rose garden out back.
<G-vec00536-002-s423><calm.stillen><de> Freuen Sie sich auf ein tägliches Frühstücksbuffet, einen großen Biergarten und einen stillen Rosengarten hinter dem Haus.
<G-vec00536-002-s424><calm.stillen><en> The Ferndale (after a novel by J. Conrad) is a ship that gets lost in the calm distance of the sea, no longer able to navigate, and, then being pushed on by the wind of a powerful storm, reaches its goal, almost sailing blind … This literary image describes a process for the artist that is documented in the many paintings in this catalogue.
<G-vec00536-002-s424><calm.stillen><de> Die Ferndale (nach einem Roman von J. Conrad) ist ein Schiff, das sich in den stillen Weiten des Meeres verliert, zu keiner Navigation mehr fähig und plötzlich, nach einem schwarzen Sturm vom Wind getragen, sein Ziel fast blind erreicht... Dieses literarische Bild beschreibt für die Künstlerin den eigenen Schaffensprozess, der in diesem Katalog bilderreich dokumentiert wird.
<G-vec00536-002-s425><calm.stillen><en> Explore the ruins of old San Jose de Gracia and enjoy the calm waters where flocks of migrating ducks from Canada gather year after year, seeking the warm waters of the dam.
<G-vec00536-002-s425><calm.stillen><de> Machen Sie sich auf den Weg und erkunden Sie die Ruinen des alten San José de Gracia; lassen Sie sich vom stillen Wasser tragen, auf dem Schwärme kanadischer Enten spielen, die Jahr für Jahr bis zu den warmen Gewässern des Staudamms ziehen.
<G-vec00536-002-s426><calm.stillen><en> The return journey takes us alongside the calm waters of the Gulf of Kalloni.
<G-vec00536-002-s426><calm.stillen><de> Der Rückweg führt uns entlang am stillen Wasser des Golfs von Kalloni.
<G-vec00536-002-s427><calm.stillen><en> Man cannot know himself save through meditation, through a deep dive into the calm chambers of the heart and a direct glance at the mirror of life within.
<G-vec00536-002-s427><calm.stillen><de> Der Mensch kann sich nur durch Meditation, durch tiefes Eintauchen in die stillen Regionen des Herzens und einen direkten Blick auf den Spiegel des Lebens im Innern wirklich selbst erkennen.
<G-vec00536-002-s428><calm.stillen><en> Known for being narrow, for its cliffs and fine sand, for its thick pine forests and calm waters and as a perfect anchoring spot.
<G-vec00536-002-s428><calm.stillen><de> Bekannt durch seine Enge, für seine Felswände,seinen feinen weissen Sand, seinen dichten Pinienwald, seine stillen Gewässer und seine traumhaften Ankerplätze.
<G-vec00536-002-s429><calm.stillen><en> Beginners can try out their first experiences in a boat on calm water in the headrace flowing through the camp. Map
<G-vec00536-002-s429><calm.stillen><de> Dabei können Anfänger ihre ersten Ruderversuche auf dem stillen Wasser eines Mühlgrabens unternehmen, der direkt den Campingplatz durchfließt.
<G-vec00536-002-s430><calm.stillen><en> This calm film is concerned with the last things in life, the confrontation with the end.
<G-vec00536-002-s430><calm.stillen><de> In diesem stillen Film geht es um die letzten Dinge, um die Konfrontation mit dem Ende.
<G-vec00536-002-s431><calm.stillen><en> It contrasts and unites the triumphant hymn to victory and a calm prayer for peace.
<G-vec00536-002-s431><calm.stillen><de> Das Werk kontrastiert und verbindet eine triumphale Siegeshymne mit einem stillen Friedensgebet.
<G-vec00536-002-s432><calm.stillen><en> To calm the feeling of hunger kefir is better to drink slowly with small sips or eat a teaspoon.
<G-vec00536-002-s432><calm.stillen><de> Um das Gefühl von Hunger zu stillen, ist Kefir besser, langsam mit kleinen Schlucken zu trinken oder einen Teelöffel zu essen.
<G-vec00536-002-s433><calm.stillen><en> The shine in the Abode resembles the state of calm and warm delicate morning sunlight.
<G-vec00536-002-s433><calm.stillen><de> Die Leuchtkraft ähnelt hier dem Zustand eines stillen und warmen, zärtlichen Morgenlichts der Sonne.
<G-vec00536-002-s434><calm.stillen><en> Let yourself be seduced by the beautiful, twisty road that leads to the lakes and which will slowly reveal a beautiful countryside made up of calm waters, unimaginable green carpets and mountain peaks which all seem to be almost within reach.
<G-vec00536-002-s434><calm.stillen><de> Lassen Sie sich von dem schönen, kurvigen Weg verführen, der zu diesen Seen führt und der Ihnen nach und nach eine faszinierende Landschaft aus stillen Gewässern, unvorstellbar grünen Teppichen und einem Dach aus prächtigen Gipfeln fast in greifbarer Nähe enthüllen wird.
