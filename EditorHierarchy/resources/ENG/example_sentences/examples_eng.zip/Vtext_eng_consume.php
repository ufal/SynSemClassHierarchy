<G-vec00476-001-s009><consume.aufnehmen><en> Directions for use Feed between 8 and 17°C water temperature, but only as much as the fish can consume within a short time.
<G-vec00476-001-s009><consume.aufnehmen><de> Gebrauchsinformation FÃ1⁄4ttern Sie zwischen 8 und 17 °C, nur so viel, wie die Fische in kurzer Zeit aufnehmen.
<G-vec00476-001-s010><consume.aufnehmen><en> Feeding recommendation Tetra Pond Colour Sticks: Feed 2-3 times a day as much as the fish can consume within a few minutes.
<G-vec00476-001-s010><consume.aufnehmen><de> Fütterungsempfehlung Tetra Pond Colour Sticks: Füttern Sie mindestens 2 bis 3 Mal täglich nur so viel, wie Ihre Fische innerhalb weniger Minuten aufnehmen können.
<G-vec00476-001-s011><consume.aufnehmen><en> This is because with the water that you consume, the infectious, painful mucus is released and your mucous membranes can regenerate once again.
<G-vec00476-001-s011><consume.aufnehmen><de> Denn durch das Wasser, das Sie aufnehmen, wird der infektiöse, schmerzende Schleim gelöst, und auch die Schleimhäute können sich wieder regenerieren.
<G-vec00476-001-s012><consume.aufnehmen><en> Directions for use Feed below 12°C water temperature, but only as much as the fish can consume within a short time.
<G-vec00476-001-s012><consume.aufnehmen><de> Gebrauchsinformation FÃ1⁄4ttern Sie unter 12 °C, nur so viel, wie die Fische in kurzer Zeit aufnehmen.
<G-vec00476-001-s013><consume.aufnehmen><en> The body can also consume something unhealthy, that is, nourishment which still contains too many immature spiritual substances.... which then might not only bother the body but also the soul.... and manifest itself in the form of diseases....
<G-vec00476-001-s013><consume.aufnehmen><de> Es kann der Körper auch Ihm-Unzuträgliches aufnehmen, d.h. eine Kost, die noch im Übermaß unausgereiftes Geistiges birgt.... das nun sowohl den Körper als auch die Seele bedrängen kann.... was sich in Form von Krankheiten auswirkt....
<G-vec00476-001-s014><consume.aufnehmen><en> Problems arise when you consume a large amount of sugar.
<G-vec00476-001-s014><consume.aufnehmen><de> Probleme entstehen, wenn Sie große Mengen von Zucker aufnehmen.
<G-vec00476-001-s015><consume.aufnehmen><en> Since our role models are to a great extent shaped by what we consume in the media, we decided this would be a good approach.
<G-vec00476-001-s015><consume.aufnehmen><de> Da unsere Rollenbilder ja ganz stark von dem besetzt sind, was wir über die Medien aufnehmen, haben wir hier einen Ansatzpunkt gesehen.
<G-vec00476-001-s016><consume.aufnehmen><en> The components from BARTEC, which consume a total of 1.7 megawatts of power, are used in a wide range of areas.
<G-vec00476-001-s016><consume.aufnehmen><de> Die BARTEC-Komponenten, die zusammen 1,7 Megawatt Leistung aufnehmen, finden sich an den unterschiedlichsten Einsatzorten.
<G-vec00476-001-s017><consume.aufnehmen><en> Recommended feeding for Tetra Malawi Flakes:Feed the fish several times a day with only as much food as the fish can consume within a few minutes.
<G-vec00476-001-s017><consume.aufnehmen><de> Fütterungsempfehlung Tetra Malawi Flakes: Füttern Sie mehrmals täglich so viel, wie die Fische innerhalb weniger Minuten aufnehmen können.
<G-vec00476-001-s074><consume.fressen><en> The animals consume a great deal of the algae, digest and then excrete them.
<G-vec00476-001-s074><consume.fressen><de> Die Tiere fressen einen Großteil der Algen weg, verdauen diese und scheiden entsprechend viele Kotpartikel aus.
<G-vec00476-001-s075><consume.fressen><en> Insects live in highly organised social colonies with defined roles; they can build structures and ‘cities’ or consume and destroy everything in their wake.
<G-vec00476-001-s075><consume.fressen><de> Insekten leben in hoch organisierten sozialen Verbänden mit definierten Rollen; sie können Strukturen bilden und „Städte“ bauen, oder alles fressen und zerstören, was ihnen in den Weg kommt.
<G-vec00476-001-s076><consume.fressen><en> The young caterpillars preferably consume flowers or at least young shoots.
<G-vec00476-001-s076><consume.fressen><de> Die Jungraupen fressen gerne an Blüten oder zumindest Jungtrieben.
<G-vec00476-001-s077><consume.fressen><en> Feeding Recommendations: Feed daily as much as the animals can consume within 10 minutes.
<G-vec00476-001-s077><consume.fressen><de> Fütterungsempfehlung: Füttern Sie täglich soviel, wie die Tiere in 10 Minuten fressen können.
<G-vec00476-001-s078><consume.fressen><en> This particular variety of herring will gather in busy harbors to feed on the small sea creatures which consume the waste dumped from ships.
<G-vec00476-001-s078><consume.fressen><de> Diese Heringsart findet sich in Häfen wieder, um sich von den kleinen Meereskreaturen zu ernähren, die den Abfall von Schiffen fressen.
<G-vec00476-001-s079><consume.fressen><en> 14 But if ye will not hearken unto me, and will not do all these commandments; 15 And if ye shall despise my statutes, or if your soul abhor my judgments, so that ye will not do all my commandments, but that ye break my covenant: 16 I also will do this unto you; I will even appoint over you terror, consumption, and the burning ague, that shall consume the eyes, and cause sorrow of heart: and ye shall sow your seed in vain, for your enemies shall eat it.
<G-vec00476-001-s079><consume.fressen><de> 14 Werdet ihr aber mir nicht gehorchen und nicht tun diese Gebote alle, 15 und werdet meine Satzungen verachten, und eure SeeLE meine Rechte verwerfen, daß ihr nicht tut alLE meine Gebote, und werdet meinen Bund lassen anstehen, 16 so will ich euch auch solches tun:Ich will euch heimsuchen mit Schrecken, Schwulst und Fieber, daß euch die Angesichte verfallen und der Leib verschmachte; ihr sollt umsonst euren Samen säen, und eure Feinde sollen ihn fressen.
<G-vec00476-001-s080><consume.fressen><en> 42 Locusts shall consume all your trees and the produce of your land.
<G-vec00476-001-s080><consume.fressen><de> 42 Alle deine Bäume und Früchte deines Landes wird das Ungeziefer fressen.
<G-vec00476-001-s081><consume.fressen><en> Fish lovers say that all the kilos of fish the cormorants now consume would otherwise be available for the fisheries.
<G-vec00476-001-s081><consume.fressen><de> Die Fischliebhaber sagen, dass die Kilos Fisch, die die Kormorane jetzt fressen, ansonsten der Fischerei zur Verfügung stehen würden.
<G-vec00476-001-s082><consume.fressen><en> €10,95 Shirakura Ebi Dama soft are soft pads that are easier to consume for shrimp than the standard Shirakura Ebi Dama.
<G-vec00476-001-s082><consume.fressen><de> €10,95 Shirakura Ebi Dama soft sind weiche Pads, die für Garnelen einfacher zu fressen sind als die Standard Pads.
<G-vec00476-001-s091><consume.konsumieren><en> In addition to funding prominent British scientists, Coca-Cola also paid £4.8 million to the European Hydration Institute, a research foundation which recommended people to consume sport and soft drinks of the kind the company sells.
<G-vec00476-001-s091><consume.konsumieren><de> Neben der Finanzierung prominenter britischer Wissenschaftler zahlte Coca-Cola auch 4,8 Millionen Pfund an das European Hydration Institute, eine Forschungsstiftung, die den Konsum von Sport- und Erfrischungsgetränken, wie sie das Unternehmen verkauft, empfiehlt.
<G-vec00476-001-s092><consume.konsumieren><en> It can consume royal jelly throughout the year and cycles advantageous to cures (1 to 2 months) are fall and spring.
<G-vec00476-001-s092><consume.konsumieren><de> Man kann der Konsum von Gelee Royal das ganze Jahr, und die Zeiten für den Kuren (1 bis 2 Monate) sind im Herbst und Frühjahr.
<G-vec00476-001-s093><consume.konsumieren><en> He does not buy products tested on animals or containing unnecessary chemicals, and tries to consume in moderation.
<G-vec00476-001-s093><consume.konsumieren><de> Er kauft keine Produkte, die an Tieren getestet werden oder unnötige Chemikalien enthalten und versucht seinen Konsum einzuschränken.
<G-vec00476-001-s094><consume.konsumieren><en> The term ‘food system’ covers all the processes and the infrastructure we have established to produce and consume food.
<G-vec00476-001-s094><consume.konsumieren><de> "Mit dem Begriff „Nahrungsmittelsystem"" werden alle Prozesse und die Infrastruktur zusammengefasst, die wir für Herstellung und Konsum von Nahrungsmitteln geschaffen haben."
<G-vec00476-001-s095><consume.konsumieren><en> """Where the inclination to save is still very strong but weakening slightly, willingness to consume increases somewhat,"" says Bruckbauer."
<G-vec00476-001-s095><consume.konsumieren><de> """Bei weiterhin sehr hoher, aber leicht sinkender Sparneigung nimmt doch die Bereitschaft zum Konsum etwas zu"", sagt Bruckbauer."
<G-vec00476-001-s096><consume.konsumieren><en> Cocaine, MDMA, and lower potency stimulants such as dexamphetamine, could also be available at licensed premises like pubs or coffee shops, where members buy things to consume on site.
<G-vec00476-001-s096><consume.konsumieren><de> Kokain, MDMA und weniger Potente Stimulantien wie das ADHS-Mittel Dexamphetamin könnten man auch an lizenzierten Orte nach dem Modell niederländischer Coffeeshops verkaufen, wo Vereins- oder Clubmitglieder Substanzen zum Konsum vor Ort erstehen.
<G-vec00476-001-s097><consume.konsumieren><en> I began to consume heroin and cocaine early in 1993, shooting heroine regularly.
<G-vec00476-001-s097><consume.konsumieren><de> Mit dem Konsum von Heroin und Kokain begann ich Anfang 1993, wobei ich Heroin regelmäßig spritzte.
<G-vec00476-001-s098><consume.konsumieren><en> Tourists might be more inclined to purchase edibles over raw cannabis because they are less conspicuous and easier to consume.
<G-vec00476-001-s098><consume.konsumieren><de> Touristen könnten dazu tendieren, eher essbare Produkte zu kaufen als puren Cannabis, da ihr Konsum weniger auffällig und einfacher ist.
<G-vec00476-001-s099><consume.konsumieren><en> Precautions Before taking Thorazine tell your doctor about all the conditions you may have, especially if you are pregnant, planning to become pregnant or breastfeeding, if you are taking any medicines prescribed and not prescribed, herbal products or dietary supplement, if you have allergies to medicines, food, etc, if you have history of heart problems, blood problems, high blood pressure, liver problems such as cirrhosis, kidney problems, seizures or epilepsy, Parkinson disease, enlarged prostate gland, Reye syndrome, alcohol abuse or if you consume more than 3 alcoholic drinks per day, if you have lung infections, asthma and other lung problems, glaucoma, increased pressure in the eyes or if you are have a risk of glaucoma.
<G-vec00476-001-s099><consume.konsumieren><de> Vorsichtsmaßnahmen Bevor Sie mit der Einnahme von Thorazine beginnen, informieren Sie Ihren Arzt über sämtliche Zustände, die Sie haben können, besonders falls Sie schwanger sind, eine Schwangerschaft planen oder sich in der Stillzeit befinden; verschreibungspflichtige oder rezeptfreie Medikamente, pflanzliche Produkte oder Nahrungsergänzungsmittel einnehmen; allergisch auf Medikamente, Nahrungsmittel und so weiter reagieren, solche Erkrankungen in der Anamnese haben wie Herz- oder Blutprobleme, Bluthochdruck, Leberprobleme wie Leberzirrhose, Nierenerkrankungen, Krampfanfälle oder Epilepsie, die Parkinson-Krankheit, eine vergrößerte Prostata, das Reye-Syndrom, Alkoholmissbrauch oder der Konsum von mehr als drei alkoholischen Getränken pro Tag, Lungeninfektionen, Asthma und andere Lungenerkrankungen, Glaukom, erhöhter Druck in den Augen oder falls Sie ein Risiko von Glaukom haben.
<G-vec00476-001-s100><consume.konsumieren><en> Consume organic vegetables and fruits daily.
<G-vec00476-001-s100><consume.konsumieren><de> Konsumiere täglich biologisch angebautes Gemüse und Obst.
<G-vec00476-001-s101><consume.konsumieren><en> I consume this tablet for 3 months.
<G-vec00476-001-s101><consume.konsumieren><de> Ich konsumiere diese Tablette für 3 Monate.
<G-vec00476-001-s102><consume.konsumieren><en> I consume this product for 3 months.
<G-vec00476-001-s102><consume.konsumieren><de> Ich konsumiere diese Kapsel für 3 Monate.
<G-vec00476-001-s103><consume.konsumieren><en> But I consume very little of Berlin’s cultural offerings.
<G-vec00476-001-s103><consume.konsumieren><de> Aber von dem kulturellen Angebot Berlins konsumiere ich kaum etwas.
<G-vec00476-001-s104><consume.konsumieren><en> Do not consume tea tree oil, as it is toxic.
<G-vec00476-001-s104><consume.konsumieren><de> Konsumiere Teebaumöl nicht oral, weil es giftig ist.
<G-vec00476-001-s105><consume.konsumieren><en> Do not consume magic truffles if you are on medication or in combination with alcohol.
<G-vec00476-001-s105><consume.konsumieren><de> Konsumiere keine magischen Trüffel wenn Du auf Medikamenten bist oder in Kombination mit Alkohol.
<G-vec00476-001-s106><consume.konsumieren><en> Consume more vitamin E. Vitamin E is an antioxidant that protects body tissue from damage caused by bacteria and viruses.
<G-vec00476-001-s106><consume.konsumieren><de> Konsumiere mehr Vitamin E. Vitamin E ist ein Antioxidans, das den Körper vor Schäden durch Bakterien und Viren schützt.
<G-vec00476-001-s107><consume.konsumieren><en> It is really basic to consume Fish Oil.
<G-vec00476-001-s107><consume.konsumieren><de> Es ist wirklich grundlegende zu konsumieren Fish Oil .
<G-vec00476-001-s108><consume.konsumieren><en> Naturally the food you consume is an important aspect of your ayurvedic treatment and lifestyle.
<G-vec00476-001-s108><consume.konsumieren><de> NatÃ1⁄4rlich ist das Essen, das Sie konsumieren, ein wichtiger Aspekt Ihrer ayurvedischen Behandlung und Ihres Lebensstils.
<G-vec00476-001-s109><consume.konsumieren><en> Fish Oil supplements are the most effective technique to increase the intake of these essential compounds, without the responsibility to consume lots of fishes.
<G-vec00476-001-s109><consume.konsumieren><de> Fish Oil Tabletten sind der effektivste Weg, um die Aufnahme dieser entscheidenden Verbindungen zu steigern, ohne die Verantwortung mehr Fische zu konsumieren.
<G-vec00476-001-s110><consume.konsumieren><en> An average person should consume about 3000-5000 units per day.
<G-vec00476-001-s110><consume.konsumieren><de> Eine durchschnittliche Person sollte etwa 3000-5000 Einheiten pro Tag konsumieren.
<G-vec00476-001-s111><consume.konsumieren><en> In this way, we can offer our viewers fascinating content that they can consume on their choice of platform – either linearly or digitally.
<G-vec00476-001-s111><consume.konsumieren><de> Unseren Zuschauern bieten wir so faszinierende Inhalte, die sie plattformunabhängig sowohl linear als auch digital konsumieren können.
<G-vec00476-001-s112><consume.konsumieren><en> This means that you should regularly consume Oolong, should never be exaggerated and drinking liters and liters each day.
<G-vec00476-001-s112><consume.konsumieren><de> Dies bedeutet, dass, während Sie sollten regelmäßig Oolong-Tee zu konsumieren, sollten Sie niemals übertreibe und trinken Liter und Liter jeden Tag.
<G-vec00476-001-s113><consume.konsumieren><en> If you experience the impotence, you ought to consume some herbal pills to boost your testosterone degree.
<G-vec00476-001-s113><consume.konsumieren><de> Wenn Sie die Erektionsstörung auftreten, sollten Sie einige natürliche Kapseln konsumieren, um Ihren Testosteron Grad zu erhöhen.
<G-vec00476-001-s114><consume.konsumieren><en> It is very important to consume the raw water quality, the bacteria are destroyed by boiling, evaporation occurs free chlorine and organic matter, but chlorine, part of the organic compounds when heated turns into a poison, gradually accumulate in the body.
<G-vec00476-001-s114><consume.konsumieren><de> Es ist sehr wichtig, die Rohwasserqualität zu konsumieren, werden die Bakterien durch Kochen zerstört, tritt Verdunstung freies Chlor und organischem Material, aber Chlor, ein Teil der organischen Verbindungen, wenn sie erhitzt wird zum Gift, allmählich im Körper anreichern.
<G-vec00476-001-s115><consume.konsumieren><en> As zombies they 'consume' the (hi)story, the characters, and the roles ascribed to them.
<G-vec00476-001-s115><consume.konsumieren><de> "Als Zombies ""konsumieren"" sie die Geschichte, die Figuren, und die ihnen zugeschriebenen Rollen."
<G-vec00476-001-s116><consume.konsumieren><en> You should not consume cold drinks and junk food in excess if you wish to solve the problem of hair loss completely.
<G-vec00476-001-s116><consume.konsumieren><de> Sie sollten nicht konsumiert kalten Getränken und Junk-Food mehr, wenn Sie das Problem des Haarausfalls lösen wollen vollständig aus.
<G-vec00476-001-s117><consume.konsumieren><en> It always gives us the feeling that the whole post is constructed for the the reader to buy and consume and for the blogger to make cash – which is entirely missing the ‘inspiration’ point.
<G-vec00476-001-s117><consume.konsumieren><de> Uns vermittelt es stets das Gefühl, als sei der ganze Beitrag darauf ausgelegt, dass der Leser konsumiert und der Blogger kassiert – wir empfinden diese mit Links und Hinweisen zugeknallten Mode Posts daher am Thema ‚Inspiration‘ im Endeffekt völlig vorbei geschossen.
<G-vec00476-001-s118><consume.konsumieren><en> As for the prices are all displayed with the utmost transparency, no price is hidden and everyone is free to decide whether to consume or not.
<G-vec00476-001-s118><consume.konsumieren><de> Die Preise werden alle mit größter Transparenz angezeigt, kein Preis ist versteckt und jeder kann entscheiden, ob er konsumiert oder nicht.
<G-vec00476-001-s119><consume.konsumieren><en> D. 2) If the local Ordinary may permit a priest who finds himself in the same condition, to celebrate Mass, even alone, communicating by “intinction,” provided that the faithful who assist at the Mass consume the consecrated wine that remains.
<G-vec00476-001-s119><consume.konsumieren><de> "Frage 2) Ob der Ortsordinarius einem Priester mit demselben Problem erlauben kann, auch allein die Messe zu feiern und dabei die Kommunion durch ""Intinktion"" zu empfangen, wenn nur ein Gläubiger, der an der Messe teilnimmt, das, was vom konsekrierten Wein verbleibt, konsumiert."
<G-vec00476-001-s120><consume.konsumieren><en> It is possible to consume coca tea in the hotels and restaurants, even in the Western embassies in Bolivia.
<G-vec00476-001-s120><consume.konsumieren><de> Kokatee kann in Hotels und Restaurants konsumiert werden, selbst in den westlichen Botschaften in Bolivien.
<G-vec00476-001-s121><consume.konsumieren><en> You cannot import, export or consume drugs and narcotics; explosives; objects, photos, literature or any other pornographic item; animals, plants and their parts designated as a protected or endangered species.
<G-vec00476-001-s121><consume.konsumieren><de> Drogen und Rauschmittel, Sprengkörper, pornografische Schriften, Objekte, Fotos oder sonstige Artikel, Tiere, Pflanzen und Teile davon, die von bedrohten oder geschützten Arten stammen dürfen weder importiert noch exportiert oder konsumiert werden.
<G-vec00476-001-s122><consume.konsumieren><en> If the consume soft drinks regularly, he should stop this habit before surgery.
<G-vec00476-001-s122><consume.konsumieren><de> Wenn man regelmäßig kohlensäurehaltige Getränke konsumiert, sollte er diese Gewohnheit zu stoppen, bevor die Operation.
<G-vec00476-001-s123><consume.konsumieren><en> "The Prophet said to his retinue: ""Do not consume this food. It is poisoned."
<G-vec00476-001-s123><consume.konsumieren><de> Der Prophet sagte zu seinen Gefährten: “Konsumiert dieses Eßen nicht, es ist vergiftet”.
<G-vec00476-001-s124><consume.konsumieren><en> It is of course true that the worker himself does not consume the product which he himself has directly produced; but his product does bear within it a quality which all goods socially produced have in common: the average social labour-time required for its production.
<G-vec00476-001-s124><consume.konsumieren><de> Wohl konsumiert der Arbeiter nicht direkt das durch ihn selbst hergestellte Produkt; aber sein Produkt trägt etwas in sich, das alle gesellschaftlichen Güter gemeinsam haben: die gesellschaftlich notwendige Arbeitszeit, die ihre Herstellung kostete.
<G-vec00476-001-s179><consume.verbrauchen><en> In the next 10 to 15 years, the countries of North Africa will consume the vast majority of the electricity they generate.
<G-vec00476-001-s179><consume.verbrauchen><de> In den nächsten 10-15 Jahren werden die nordafrikanischen Länder den größten Anteil des Stroms selbst verbrauchen.
<G-vec00476-001-s180><consume.verbrauchen><en> Rather, it boosts the degree of satiation (satisfaction you get from food), making it less complicated to consume food much less.
<G-vec00476-001-s180><consume.verbrauchen><de> Vielmehr steigert es den Grad der Sättigung (Zufriedenheit, die Sie aus der Nahrung), so dass es weniger kompliziert Essen viel weniger zu verbrauchen.
<G-vec00476-001-s181><consume.verbrauchen><en> Synthetic stop premature ejaculation options may be difficult for your body to consume so with natural solutions you should have the ability to fully absorb the elements to enhance your intimate objectives.
<G-vec00476-001-s181><consume.verbrauchen><de> Synthetische Stop vorzeitige Ejakulation Optionen kann schwierig sein, für Ihren Körper zu tun mit natürlichen Lösungen verbrauchen, sollten Sie die Möglichkeit, die Elemente, um Ihre Ziele zu verbessern intime vollständig zu absorbieren.
<G-vec00476-001-s182><consume.verbrauchen><en> Lots of of the minerals you consume are missing due to sweat, in particular for the period of exercise routines, so it happens to be more critical than ever to assure that you simply get ample mineral dietary supplements for muscle building, and on the right periods.
<G-vec00476-001-s182><consume.verbrauchen><de> Viele der Mineralien, die Sie verbrauchen werden für den Zeitraum der Ausübung Routinen fehlen aufgrund von Schweiß, insbesondere, so kommt es wichtiger denn je, um sicherzustellen, dass Sie einfach zu bekommen reichlich Mineralnahrungsergänzungsmitteln für den Muskelaufbau zu sein und auf die richtigen Zeiträume .
<G-vec00476-001-s183><consume.verbrauchen><en> # Learn how to make dieting and eliminate the extra pounds, the body needs to consume fewer calories and provide more energy.
<G-vec00476-001-s183><consume.verbrauchen><de> Erfahren Sie, wie Diäten machen und die Beseitigung der überflüssigen Pfunde, muss der Körper weniger Kalorien zu verbrauchen und mehr Energie liefern.
<G-vec00476-001-s184><consume.verbrauchen><en> 20 percent of the world population consume 80 percent of the resources and are responsible for 80 percent of climate-damaging emissions.
<G-vec00476-001-s184><consume.verbrauchen><de> 20 Prozent der Weltbevölkerung verbrauchen 80 Prozent der Ressourcen und sind für 80 Prozent der klimaschädlichen Emissionen verantwortlich.
<G-vec00476-001-s185><consume.verbrauchen><en> For best results, do not consume food or protein shakes 1 hour after taking Anadraulic State.
<G-vec00476-001-s185><consume.verbrauchen><de> Für beste Ergebnisse, nicht verbrauchen Lebensmittel-oder Protein-Shakes 1 Stunde nach Einnahme Anadraulic Staat.
<G-vec00476-001-s186><consume.verbrauchen><en> LED spotlight consume only a minimum amount of power and are in use even under installed.
<G-vec00476-001-s186><consume.verbrauchen><de> Â LED-Strahler verbrauchen nur einen minimalen Anteil an Strom und liegen im Verbrauch sogar unter Energiesparleuchten.
<G-vec00476-001-s187><consume.verbrauchen><en> In other words, the 8 million people living in Switzerland consume as much resources as the 850 million inhabitants of the poorest countries.
<G-vec00476-001-s187><consume.verbrauchen><de> Oder anders gesagt, die acht Millionen in der Schweiz lebenden Menschen verbrauchen so viel Ressourcen wie die 850 Millionen EinwohnerInnen der ärmsten Länder.
<G-vec00476-001-s197><consume.verbrauchen><en> The basic of losing weight is simple; consume less calories than you burn.
<G-vec00476-001-s197><consume.verbrauchen><de> Das grundlegende des Schlussen Gewichts ist einfach; verbrauchen Sie weniger Kalorien als Sie Brand.
<G-vec00476-001-s198><consume.verbrauchen><en> Consume more water every day to prevent acid reflux.
<G-vec00476-001-s198><consume.verbrauchen><de> Verbrauchen Sie mehr Wasser jeden Tag, um Sodbrennen zu vermeiden.
<G-vec00476-001-s199><consume.verbrauchen><en> Consume a very small dose .
<G-vec00476-001-s199><consume.verbrauchen><de> Verbrauchen Sie eine sehr kleine Dosis.
<G-vec00476-001-s200><consume.verbrauchen><en> Consume 3 pills with water about 15 minutes after training.
<G-vec00476-001-s200><consume.verbrauchen><de> Verbrauchen Sie 3 Tabletten mit Wasser etwa 15 Minuten nach dem Training.
<G-vec00476-001-s201><consume.verbrauchen><en> Consume more live food.
<G-vec00476-001-s201><consume.verbrauchen><de> Verbrauchen Sie mehr Lebendfutter.
<G-vec00476-001-s202><consume.verbrauchen><en> Consume one pill 3 times daily with water roughly 30-45 mins before workout.
<G-vec00476-001-s202><consume.verbrauchen><de> Verbrauchen Sie eine Pille 3-mal täglich mit Wasser etwa 30 bis 45 Minuten vor dem Training.
<G-vec00476-001-s203><consume.verbrauchen><en> Consume daily dose of fiber.
<G-vec00476-001-s203><consume.verbrauchen><de> Verbrauchen Sie Ihre tägliche Dosis der Faser.
<G-vec00476-001-s204><consume.verbrauchen><en> Also consume flowers and fruits.
<G-vec00476-001-s204><consume.verbrauchen><de> Auch verbrauchen Sie, Blüten und Früchten.
<G-vec00476-001-s205><consume.verbrauchen><en> Consume one pill 3 times daily with water around 30-45 mins prior to exercise.
<G-vec00476-001-s205><consume.verbrauchen><de> Verbrauchen Sie eine Pille 3-mal täglich mit Wasser etwa 30-45 Minuten vor dem Training.
<G-vec00476-001-s206><consume.verbrauchen><en> Seen over the year this heater does not consume more electricity than the smaller model (it takes a shorter time to heat the water), but often does not fit into the aquarium lengthwise.
<G-vec00476-001-s206><consume.verbrauchen><de> Dieser verbraucht im Jahresdurchschnitt nicht mehr als das kleinere Modell (benötigt eine geringe Zeit für die Erhitzung des Wassers), passt aber häufig in der Länge nicht in das Aquarium.
<G-vec00476-001-s207><consume.verbrauchen><en> The power management ensures that on-board systems do not consume more electrical power than the alternator can supply, and thus maintains the maximum possible battery power level.
<G-vec00476-001-s207><consume.verbrauchen><de> Es regelt, dass nicht mehr elektrische Energie verbraucht als erzeugt wird und sorgt dadurch für einen optimalen Ladezustand der Batterie.
<G-vec00476-001-s208><consume.verbrauchen><en> An attacker can send a relatively small XML document that, when the entities are resolved, will consume extreme amounts of memory on the target system.
<G-vec00476-001-s208><consume.verbrauchen><de> Ein Angreifer kann so mithilfe eines verhältnismäßig kleinen XML-Dokuments erreichen, dass bei der Expansion der Entitäten extreme Mengen an Arbeitsspeicher auf dem Zielsystem verbraucht werden.
<G-vec00476-001-s209><consume.verbrauchen><en> This equipment may be unpleasant for the very first usage but it will consume 2-3 weeks for you to gain regular with this equipment.
<G-vec00476-001-s209><consume.verbrauchen><de> Dieses Gerät könnte für die erste Nutzung unruhig sein, aber es wird sicherlich 2-3 Wochen verbraucht für Sie mit diesem Gerät regelmäßig zu erhalten.
<G-vec00476-001-s210><consume.verbrauchen><en> This appliance could be unpleasant for the very first use however it will consume 2-3 weeks for you to obtain habitual with this equipment.
<G-vec00476-001-s210><consume.verbrauchen><de> Dieses Gerät könnte zum ersten Einsatz unangenehm sein aber es wird 2-3 Wochen verbraucht für Sie mit diesem Gerät gewöhnlichen zu erhalten.
<G-vec00476-001-s211><consume.verbrauchen><en> """And then shall be revealed the wicked one, whom the Lord shall consume with the spirit of His mouth, and shall destroy with the brightness of His coming: even him whose coming is after the working of Satan, with all power, and signs, and lying wonders, and with all deceivableness of unrighteousness in them that perish"" (Tertullian."
<G-vec00476-001-s211><consume.verbrauchen><de> """Und dann wird das gemeine aufgedeckt, das der Lord mit dem Geist seines Munds verbraucht, und zerstört mit der Helligkeit seines Kommens: sogar er, wer Kommen nachdem die Funktion von Satan, mit aller Energie und Zeichen und liegenwunder und mit allem deceivableness von Unrighteousness in ihnen ist, die"" umkommen (Tertullian."
<G-vec00476-001-s212><consume.verbrauchen><en> The 4-piece PvP healing set bonus has been modified to make Consumption no longer consume health when used with a stack of Force Surge, rather than restore 3% of max health over 6 seconds after use.
<G-vec00476-001-s212><consume.verbrauchen><de> Der 4-teilige PvP-Heilungs-Setbonus wurde verändert, damit Verbrauch keine Gesundheit mehr verbraucht, wenn es mit einem Stapel von Machtwoge verwendet wird, sondern stattdessen nach der Verwendung 3% der maximalen Gesundheit über 6 Sekunden wiederherstellt.
<G-vec00476-001-s213><consume.verbrauchen><en> The principle is also ideally suited to achieving cable redundancy when connecting Base Devices, and does not consume time slots or router switching capacity.
<G-vec00476-001-s213><consume.verbrauchen><de> Das Prinzip eignet sich auch hervorragend, um eine Kabelredundanz im Anschluss der Basisgeräte zu realisieren, bei der keinerlei Zeitschlitze oder Schaltkapazität des Routers verbraucht werden.
<G-vec00476-001-s214><consume.verbrauchen><en> Regardless of how quickly you will eventually lose the extra weight, just remember there are two things to focus on: How many calories you consume, how many calories you burn with exercise.
<G-vec00476-001-s214><consume.verbrauchen><de> Egal wie schnell Sie am Ende Ihrer zusätzliches Gewicht zu verlieren, nur nicht vergessen, es gibt zwei Dinge auf Folgendes konzentrieren: wie viele Kalorien man verbraucht und wie viele Kalorien verbrennen Sie durch Bewegung.
<G-vec00476-001-s222><consume.verschlingen><en> Completely unstructured experiments without a concrete application case can quickly lead to a situation where such projects consume incredible amounts of money.
<G-vec00476-001-s222><consume.verschlingen><de> Gänzlich unstrukturierte Experimente ohne konkreten Anwendungsfall können schnell dazu führen, dass solche Projekte Unmengen an Geldern verschlingen.
<G-vec00476-001-s223><consume.verschlingen><en> The Greek now looks round at the sun and notices to his and his daughter's terror that there is only a very narrow edge left of the sun, rises from his seat and thunders a curse up to the evil dragon that is now threatening to totally consume the sun.
<G-vec00476-001-s223><consume.verschlingen><de> Der Grieche sieht sich nun nach der Sonne um und bemerkt zu seinem und seiner Tochter Entsetzen, dass von der Sonne nur noch ein ganz schmaler Rand übrig ist, erhebt sich von seinem Sitze und donnert einen Fluch dem bösen Drachen empor, der die Sonne nun total zu verschlingen drohe.
<G-vec00476-001-s224><consume.verschlingen><en> I had an intense fear the light would consume me if I looked away and I was in absolute awe of what I was seeing.
<G-vec00476-001-s224><consume.verschlingen><de> Ich hatte eine intensive Furcht das Licht würde mich verschlingen wenn ich wegschauen würde und war in absoluter Ehrfurcht vor dem was ich sah.
<G-vec00476-001-s225><consume.verschlingen><en> For all the money Trump's new missile defense system will consume, the primary mechanism for ensuring that no missiles reach the United States in the event of war is the threat to destroy the entire landmass of a potential opponent with nuclear weapons.
<G-vec00476-001-s225><consume.verschlingen><de> Bei allem Geld, das Trumps neue Raketenabwehrsysteme verschlingen, werden im Kriegsfall hauptsächlich deshalb keine Raketen die USA erreichen, weil das Land jedes potenziellen Gegners sofort atomar zerstört werden wird.
<G-vec00476-001-s226><consume.verschlingen><en> PC workstations are expensive and can consume up to 50 percent of the IT budget at some companies.
<G-vec00476-001-s226><consume.verschlingen><de> PC-Arbeitsplätze sind teuer und verschlingen in manchen Unternehmen bis zu 50 Prozent der IT-Budgets.
<G-vec00476-001-s227><consume.verschlingen><en> That leaves only the development of two-stroke engines, but it seems to slowly consume all resources.
<G-vec00476-001-s227><consume.verschlingen><de> Bleibt nur die Entwicklung von Zweitaktmotoren, aber die scheint so langsam die letzten Mittel zu verschlingen.
<G-vec00476-001-s228><consume.verschlingen><en> The words of a wise man's mouth win him favor, but the lips of a fool consume him.
<G-vec00476-001-s228><consume.verschlingen><de> Die Worte aus dem Munde des Weisen bringen ihm Gunst; aber des Narren Lippen verschlingen ihn selbst.
<G-vec00476-001-s229><consume.verschlingen><en> Unfortunately, this creature needed a lot of fresh bodies to consume... so it started killing any kinds of life to regain strength, flesh and power.
<G-vec00476-001-s229><consume.verschlingen><de> Unglücklicherweise benötigt diese wieder erweckte Kreatur ständig frisches Leben, welches sie verschlingen muss, um Stärke zu gewinnen... darum begann Devon damit, sämtliche Formen von Leben zu töten, um es zu absorbieren.
<G-vec00476-001-s230><consume.vertilgen><en> But the judgment shall be set, and they shall take away his dominion, to consume and to destroy it to the end.
<G-vec00476-001-s230><consume.vertilgen><de> Aber das Gericht wird sich setzen und ihm die Herrschaft wegnehmen, um sie endgültig zu vertilgen und zu vernichten.
<G-vec00476-001-s231><consume.vertilgen><en> And then water and fire (symbols of the ardent faith and zeal of the Apostles of the End of Times) will purge the earth and consume all the works of men’s pride and all will be renewed.
<G-vec00476-001-s231><consume.vertilgen><de> Dann werden Wasser und Feuer (der Glaube und der Eifer der Apostel der letzten Zeiten) die Erde reinigen und alle Werke des menschlichen Hochmuts vertilgen und alles wird erneuert werden.
<G-vec00476-001-s232><consume.vertilgen><en> If I were to go up into the middle of you for one moment, I would consume you.
<G-vec00476-001-s232><consume.vertilgen><de> Wo ich nur einen Augenblick mit dir hinaufzöge, würde ich dich vertilgen.
<G-vec00476-001-s233><consume.vertilgen><en> You may not consume them at once, lest the animals of the field increase on you.
<G-vec00476-001-s233><consume.vertilgen><de> Du darfst sie aber nicht zu rasch vertilgen, sonst wüchse über dich das Wild des Feldes.
<G-vec00476-001-s234><consume.vertilgen><en> 16 Thou shalt consume all the people, which the Lord thy God will deliver to thee.
<G-vec00476-001-s234><consume.vertilgen><de> 16 Du wirst alle Völker vertilgen, die der HERR, dein Gott, dir geben wird.
<G-vec00476-001-s235><consume.vertilgen><en> 11 The Lord shall be terrible upon them, and shall consume all the gods of the earth: and they shall adore him every man from his own place, all the islands of the Gentiles.
<G-vec00476-001-s235><consume.vertilgen><de> 11 Heilig wird über ihnen der HERR sein; denn er wird alle Götter auf Erden vertilgen, und es sollen ihn anbeten alle Inseln der Heiden, ein jeder an seiner Stätte.
<G-vec00476-001-s236><consume.vertilgen><en> Then the Water and the Fire (the faith and zeal of the Apostles of the End of Times) will purge the earth and consume all the works of men's pride and all will be renewed.
<G-vec00476-001-s236><consume.vertilgen><de> Dann werden Wasser und Feuer (der Glaube und der Eifer der Apostel der letzten Zeiten) die Erde reinigen und alle Werke des menschlichen Hochmuts vertilgen und alles wird erneuert werden.
<G-vec00476-001-s237><consume.vertilgen><en> The village mandarin himself took on the responsibility of my meals, and every lunch time and evening I was taken in a sort of procession to him, where I had to consume his boiled chickens, ducks, and pork roasts.
<G-vec00476-001-s237><consume.vertilgen><de> Der Dorfmandarin selbst übernahm die Sorge für meinen Tisch, und jeden Mittag und jeden Abend wurde ich in einer Art Procession zu ihm geleitet, wo ich seine gesottenen Hühner und Enten und Ferkelbraten zu vertilgen hatte.
<G-vec00476-001-s238><consume.vertilgen><en> 26 But the judgment shall be set, and they shall take away his dominion, to consume and to destroy it to the end.
<G-vec00476-001-s238><consume.vertilgen><de> 26 Aber das Gericht wird sich setzen und ihm die Gewalt wegnehmen, sie endgültig vertilgen und vernichten.
<G-vec00476-001-s248><consume.verzehren><en> Oh, if only the earth would open up or fire would fall from heaven and consume the evil.
<G-vec00476-001-s248><consume.verzehren><de> Ach, würde sich doch die Erde auftun oder Feuer vom Himmel fallen und das Böse verzehren.
<G-vec00476-001-s249><consume.verzehren><en> "Eventually these temptations ""hatch"" to become the sin maggots that that consume us from within."
<G-vec00476-001-s249><consume.verzehren><de> "Irgendwann ""schlüpfen"" aus diesen Versuchungen ""Maden"" der Sünde, die uns von innen heraus verzehren."
<G-vec00476-001-s250><consume.verzehren><en> And yet it can only be offered what it had acquired for itself on earth, it cannot be moved into blissful realms to which it had never aspired nor can it be given light because this would consume the soul due to its immature state.
<G-vec00476-001-s250><consume.verzehren><de> Und doch kann ihr nur das geboten werden, was sie sich erworben hat auf Erden, sie kann nicht in glückselige Sphären versetzt werden, die sie niemals anstrebte, und ihr kann auch kein Licht geschenkt werden, weil dieses sie verzehren würde in ihrem unreifen Zustand.
<G-vec00476-001-s251><consume.verzehren><en> BgVV, therefore, recommends that children in principle should not consume AFA algae products. It is recommended that adults restrict their consumption of AFA algae products.
<G-vec00476-001-s251><consume.verzehren><de> Das BgVV rät deshalb, dass Kinder AFA-Algenprodukte grundsätzlich nicht verzehren sollten Erwachsenen wird eine Einschränkung des Konsums von AFA-Algenprodukten empfohlen.
<G-vec00476-001-s252><consume.verzehren><en> Trying to consume her mouth, my tongue darts into hers.
<G-vec00476-001-s252><consume.verzehren><de> Ich versuche, ihren Mund zu verzehren, meine Zunge schnellt in ihren Mund hinein.
<G-vec00476-001-s253><consume.verzehren><en> All drinks that you consume during your trip on board ship will be booked to your cabin and only billed at the end of the week.
<G-vec00476-001-s253><consume.verzehren><de> Alle Getränke, die Sie während der Reise an Bord verzehren, werden auf Ihre Kabine gebucht und erst am Ende der Woche abgerechnet.
<G-vec00476-001-s254><consume.verzehren><en> The flames of my Mercy consume me.
<G-vec00476-001-s254><consume.verzehren><de> Die Flammen meines Erbarmens verzehren mich.
<G-vec00476-001-s255><consume.verzehren><en> Instead of the Lord’s Supper, which we celebrate as a memorial meal in line with the Lord’s command, they have introduced an occult magical Transubstatiation, in which the believers allegedly consume the body of Christ.
<G-vec00476-001-s255><consume.verzehren><de> Sie hat statt dem Abendmahl, welches wir nach dem Gebot des Herrn als Gedächtnismahl feiern sollen, eine okkulte Zauberwandlung eingeführt, bei der die Gläubigen angeblich den Leib Christi verzehren.
<G-vec00476-001-s256><consume.verzehren><en> """Still He let the light shine more and more brightly through eternities, for He reasoned that thereby the light would consume and weaken itself, allowing Him to be again fully strengthened in His nature."
<G-vec00476-001-s256><consume.verzehren><de> Dennoch aber ließ Er das Licht Ewigkeiten hindurch heller und heller leuchten, da Er also bedachte, als müsse sich dadurch das Licht verzehren und somit schwächen vor Ihm, auf dass Er in Seiner Wesenheit daraus vollends wieder erstarke.
<G-vec00476-001-s257><consume.verbrauchen><en> During slaughter the Salmonella from infected animals can migrate to the meat and then constitute an infection risk for the people who consume the meat and meat products.
<G-vec00476-001-s257><consume.verbrauchen><de> Bei der Schlachtung können die Salmonellen von infizierten Tieren auf das Fleisch gelangen und ein Infektionsrisiko für den Menschen darstellen, der das Fleisch und daraus hergestellte Produkte verzehrt.
<G-vec00476-001-s258><consume.verbrauchen><en> It is very important for your patient to consume all the fat in the stock and off the bones as these fats are essential for the healing process.
<G-vec00476-001-s258><consume.verbrauchen><de> Es ist sehr wichtig, dass der Patient die ganzen Fette im Sud und von den Knochen verzehrt, denn diese Fette sind für den Heilungsprozess von wesentlicher Bedeutung.
<G-vec00476-001-s259><consume.verbrauchen><en> Both A and B consume new labor-power in the second period of 5 weeks and expend a new capital of 500 p. st. for the payment of this labor-power.
<G-vec00476-001-s259><consume.verbrauchen><de> Sub A wie sub B wird in der zweiten Periode von 5 Wochen neue Arbeitskraft verzehrt und ein neues Kapital von 500 £ in Zahlung dieser Arbeitskraft verausgabt.
<G-vec00476-001-s260><consume.verbrauchen><en> Nobody knows exactly how much it is safe to consume, or how often.
<G-vec00476-001-s260><consume.verbrauchen><de> Niemand weiß genau, wie viel davon ist unbedenklich verzehrt werden, oder wie oft.
<G-vec00476-001-s261><consume.verbrauchen><en> The feeding pattern is often quite striking as the larvae do not consume the whole leaves.
<G-vec00476-001-s261><consume.verbrauchen><de> Die Fraßspuren sind oft recht auffällig, da die Blätter nicht ganz verzehrt werden.
<G-vec00476-001-s262><consume.verbrauchen><en> 49:27 And I will kindle a fire in the wall of Damascus, and it shall consume the palaces of Ben-hadad.
<G-vec00476-001-s262><consume.verbrauchen><de> 49:27 Ich lege Feuer an die Mauer von Damaskus; / es verzehrt die Paläste Ben-Hadads.
<G-vec00476-002-s038><consume.aufnehmen><en> Amino acids are the building blocks of the proteins we have to consume every day through food in order for our bodies to function well.
<G-vec00476-002-s038><consume.aufnehmen><de> Aminosäuren Aminosäuren sind die Bausteine der Eiweiße, die wir über die Nahrung täglich aufnehmen müssen, damit unser Körper optimal funktioniert.
<G-vec00476-002-s040><consume.aufnehmen><en> The ADI is a toxicological reference value that indicates how much glyphosate we can consume daily (for our entire lives) with food, without any effect on our body.
<G-vec00476-002-s040><consume.aufnehmen><de> Die akzeptable tägliche Aufnahmemenge ist ein toxikologischer Referenzwert, der angibt, wie viel Glyphosat wir täglich (unser Leben lang) mit der Nahrung aufnehmen dürfen, ohne dass dies Auswirkungen auf unseren Körper hat.
<G-vec00476-002-s041><consume.aufnehmen><en> It may help to calculate how many calories you need to consume to lose weight before you get started.
<G-vec00476-002-s041><consume.aufnehmen><de> Es hilft sicher zu berechnen, wie viele Kalorien du aufnehmen darfst, damit du abnimmst.
<G-vec00476-002-s042><consume.aufnehmen><en> I really like the taste of these fruit pouches, and at the same time it allows me to consume the optimal amount of carbohydrates for my needs.
<G-vec00476-002-s042><consume.aufnehmen><de> Die Obstbeutel schmecken mir wirklich gut und ich kann gleichzeitig die für mich optimale Menge an Kohlenhydraten aufnehmen.
<G-vec00476-002-s043><consume.aufnehmen><en> The temperature of the food or water you consume is not a factor in regard to the impression of a thought since it is only the Akasha you are working with.
<G-vec00476-002-s043><consume.aufnehmen><de> Die Temperatur der Speise oder des Wassers das Sie aufnehmen ist nicht ausschlaggebend für das Anhaengen der Gedanken, da Sie nur mit dem Akasha arbeiten.
<G-vec00476-002-s044><consume.aufnehmen><en> Due to its properties, oilcake can bring tremendous health benefits, as a result of which it can consume even moderate amounts of allergies.
<G-vec00476-002-s044><consume.aufnehmen><de> Ölkuchen kann aufgrund seiner Eigenschaften enorme gesundheitliche Vorteile mit sich bringen, so dass er auch geringe Mengen an Allergien aufnehmen kann.
<G-vec00476-002-s045><consume.aufnehmen><en> When you are thirsty; you can consume only a limited quantity of water.
<G-vec00476-002-s045><consume.aufnehmen><de> Wenn du durstig bist, kannst du nur eine begrenzte Menge an Wasser aufnehmen.
<G-vec00476-002-s302><consume.verschlingen><en> Possibly the most important is your ability to consume others - you can absorb their intelligence, abilities, weapons and physical form in matter of seconds.
<G-vec00476-002-s302><consume.verschlingen><de> Die wichtigste deiner Fähigkeiten besteht darin, andere zu verschlingen - das heißt, du absorbierst in Sekundenschnelle ihr Wissen, ihr Können, ihre Waffen und ihre physische Form.
<G-vec00476-002-s303><consume.verschlingen><en> Finding new ways to grow the economy will only consume what is left of our wealth.
<G-vec00476-002-s303><consume.verschlingen><de> Finden wir neue Wege, die Wirtschaft zum Wachsen zu bringen, wird das den Rest verschlingen, der vom Reichtum noch übrig ist.
<G-vec00476-002-s305><consume.verschlingen><en> Economic cycles can have a big impact on the environment and consume large amounts of energy.
<G-vec00476-002-s305><consume.verschlingen><de> Wirtschaftszyklen können große Auswirkungen auf die Umwelt haben und große Mengen Energie verschlingen.
<G-vec00476-002-s306><consume.verschlingen><en> Smite your enemies with magical storms, melt their armour, sap their fighting spirit or bolster your own forces with devastating spells that split the sky and consume the battlefield.
<G-vec00476-002-s306><consume.verschlingen><de> Zerschmettere deine Feinde mit magischen Stürmen, lass ihre Rüstung schmelzen, raube ihren Kampfesmut oder stärke deine eigenen Truppen mit vernichtenden Zaubern, die den Himmel zerfetzen und das Schlachtfeld verschlingen.
<G-vec00476-002-s308><consume.verschlingen><en> In the frozen northern wastes, a sinister blight has awoken and now stands ready to consume everything in its path.
<G-vec00476-002-s308><consume.verschlingen><de> In den gefrorenen Weiten des Nordens ist eine finstere Plage erwacht und schickt sich nun an, alles zu verschlingen, was ihr in die Quere kommt.
<G-vec00886-002-s115><consume.konsumieren><en> Do not consume with less than the recommended amount of water or if you are prone to dehydration or are subjected to extremely hot temperatures.
<G-vec00886-002-s115><consume.konsumieren><de> Konsumiere dieses Produkt nicht mit weniger als der empfohlenen Menge an Wasser, wenn Du Anfällig für eine Dehydration bist, oder wenn Du extremer Hitze ausgesetzt bist.
<G-vec00886-002-s116><consume.konsumieren><en> Mix each scoop with 300-400 ml of cold water (to desired sweetness) and consume immediately.
<G-vec00886-002-s116><consume.konsumieren><de> Mische jeden Löffel mit 300-400 ml kaltem Wasser und konsumiere diesen direkt.
<G-vec00886-002-s117><consume.konsumieren><en> Consume Italian media.
<G-vec00886-002-s117><consume.konsumieren><de> Konsumiere italienische Medien.
<G-vec00886-002-s118><consume.konsumieren><en> Only consume ecstasy when you feel comfortable with the people and the environment around you.
<G-vec00886-002-s118><consume.konsumieren><de> Konsumiere Ecstasy nur, wenn Du Dich mit den Menschen und in Deiner Umgebung wohl fühlst.
<G-vec00886-002-s119><consume.konsumieren><en> Suggested Use Mix 50g (1 ¾ scoops) with 500ml water and consume before and/or during exercise.
<G-vec00886-002-s119><consume.konsumieren><de> Mische 50g (1 ¾ Messlöffel) mit 500ml Wasser und konsumiere diesen Shake vor und/oder während dem Training.
<G-vec00886-002-s120><consume.konsumieren><en> Consume ½ a litre of ISOTON energy drink one hour before the race begins.
<G-vec00886-002-s120><consume.konsumieren><de> Konsumiere 1 Stunde vor dem Start ½ Liter ISOTON Energiedrink.
<G-vec00886-002-s121><consume.konsumieren><en> Vegan and vegetarian-friendly Suggested Use Consume 2 capsules daily.
<G-vec00886-002-s121><consume.konsumieren><de> Empfohlene Verwendung Konsumiere 2 Kapseln täglich am besten mit einer Mahlzeit.
<G-vec00886-002-s122><consume.konsumieren><en> Suggested Use Consume 1 softgel daily.
<G-vec00886-002-s122><consume.konsumieren><de> Konsumiere 1 Softgel täglich mit einer Mahlzeit.
<G-vec00886-002-s123><consume.konsumieren><en> Consume ginger in the form of a raw root, powder, or capsule.
<G-vec00886-002-s123><consume.konsumieren><de> Konsumiere Ingwer als rohe Wurzel, Pulver oder in Form von Kapseln.
<G-vec00886-002-s124><consume.konsumieren><en> They are a mirror image of the “beautiful new world” of consumption: I consume, therefore I am.
<G-vec00886-002-s124><consume.konsumieren><de> Sie spiegeln die „schöne neue Welt“ des Konsums: Ich konsumiere, also bin ich.
<G-vec00886-002-s125><consume.konsumieren><en> I consume this tablet for 3 months.
<G-vec00886-002-s125><consume.konsumieren><de> Ich konsumiere diese Ergänzung für 3 Monate.
<G-vec00886-002-s126><consume.konsumieren><en> Consume 1 Softgel daily.
<G-vec00886-002-s126><consume.konsumieren><de> Konsumiere 1 Softgel täglich.
<G-vec00886-002-s127><consume.konsumieren><en> Consume 4 capsules, 1-2 times daily.
<G-vec00886-002-s127><consume.konsumieren><de> Konsumiere 4 Kapseln, 1-2x täglich.
<G-vec00886-002-s128><consume.konsumieren><en> Consume lean protein.
<G-vec00886-002-s128><consume.konsumieren><de> Konsumiere mageres Eiweiß.
<G-vec00886-002-s130><consume.konsumieren><en> You could also prefer to consume the capsule after exercise with your meal.
<G-vec00886-002-s130><consume.konsumieren><de> Sie könnten auch vorziehen, die Kapsel nach dem Training mit dem Essen zu konsumieren.
<G-vec00886-002-s131><consume.konsumieren><en> According to Wikipedia, about 80% of the Dutch population consume liquorice, 14% of which regularly.
<G-vec00886-002-s131><consume.konsumieren><de> Laut Wikipedia konsumieren etwa 80% der niederländischen Bevölkerung Lakritze, 14% davon regelmäßig.
<G-vec00886-002-s132><consume.konsumieren><en> They simply make egg whites quicker and easier to consume.
<G-vec00886-002-s132><consume.konsumieren><de> Diese Proteinshakes machen es einfacher und schneller Eiweiß zu konsumieren.
<G-vec00886-002-s133><consume.konsumieren><en> The new listen function is also a great way for users on the go or multitaskers to more easily consume heise online news.
<G-vec00886-002-s133><consume.konsumieren><de> Die neue Vorlesefunktion ist auch eine gute Möglichkeit für die Nutzer die unterwegs sind oder Multitasker, die damit die Inhalte der Heise Online News leichter konsumieren können.
<G-vec00886-002-s134><consume.konsumieren><en> You could also decide to consume the tablet after workout with your meal.
<G-vec00886-002-s134><consume.konsumieren><de> Sie können auch entscheiden, die Tablette nach dem Training mit Ihrem Teller zu konsumieren.
<G-vec00886-002-s135><consume.konsumieren><en> "Enlightening", "revealing" and "criticising" are long since incorporated and exploited as that welcome extra something in the soup of pseudo-democracy, easy to consume, doesn’t attack anybody, doesn’t sweep away a single doctor.
<G-vec00886-002-s135><consume.konsumieren><de> "Aufklärung", "Enthüllung" und "Kritik" sind längst eingeplant und nutzbar gemacht als Salz in der Scheindemokratie-Suppe, leicht zu konsumieren, greift niemanden an, fegt keinen einzigen Arzt weg.
<G-vec00886-002-s136><consume.konsumieren><en> PhenQ is extremely basic to consume.
<G-vec00886-002-s136><consume.konsumieren><de> PhenQ ist sehr einfach zu konsumieren.
<G-vec00886-002-s137><consume.konsumieren><en> But for this, they need to give up any alcoholic beverages and do not consume alcohol even in the smallest amounts "on holidays", since people who have abused alcohol in the past lower their tolerance for alcohol.
<G-vec00886-002-s137><consume.konsumieren><de> Dafür müssen sie jedoch auf alkoholische Getränke verzichten und auch in den geringsten Mengen "im Urlaub" keinen Alkohol konsumieren, da Menschen, die Alkohol in der Vergangenheit missbraucht haben, ihre Alkoholtoleranz senken.
<G-vec00886-002-s138><consume.konsumieren><en> The capital stock grows if humans do not completely consume their income but save parts of it and offer it for investment.
<G-vec00886-002-s138><consume.konsumieren><de> Der Kapitalstock wächst, wenn Menschen ihr Einkommen nicht vollständig konsumieren, sondern in Teilen sparen und für Investitionen bereitstellen.
<G-vec00886-002-s139><consume.konsumieren><en> In addition to geographic distance producers must also overcome the cultural distance to countries that traditionally consume little or no wine and whose marketing structure often differs fundamentally from previous markets.
<G-vec00886-002-s139><consume.konsumieren><de> Neben der geografischen Entfernung müssen die Produzenten auch die kulturelle Distanz zu Ländern überwinden, die traditionell keinen oder wenig Wein konsumieren und deren Vermarktungsstruktur sich oft grundlegend von bisherigen Märkten unterscheidet.
<G-vec00886-002-s140><consume.konsumieren><en> The commodities, the spectacles, consume him; he uses up living energy in passive admiration; he is consumed by things.
<G-vec00886-002-s140><consume.konsumieren><de> Die Waren, die Spektakel konsumieren ihn; er benutzt auflebende Energie für passive Bewunderung; er wird von Dingen konsumiert.
<G-vec00886-002-s141><consume.konsumieren><en> To live and consume consciously, to always try to do one’s best in the area we feel most connected with.
<G-vec00886-002-s141><consume.konsumieren><de> Bewusst zu leben und zu konsumieren, um immer zu versuchen das eigene Beste in jeder Situation und jedem Bereich zu geben.
<G-vec00886-002-s142><consume.konsumieren><en> Japanese national production will decline, but at the same time, Japanese consumption will be significantly lower, elderly people consume less than people in their middle ages.
<G-vec00886-002-s142><consume.konsumieren><de> 3)Das japanische Nationalprodukt wird zurückgehen, aber genauso wird der japanische Konsum wesentlich niedriger sein, da die älteren Leute weniger als die im mittleren Alter konsumieren.
<G-vec00886-002-s143><consume.konsumieren><en> If you have actually recognized this product, you will certainly be surer to consume it.
<G-vec00886-002-s143><consume.konsumieren><de> Wenn Sie diesen Artikel tatsächlich erkannt haben, werden Sie sicherer sein, es zu konsumieren.
<G-vec00886-002-s144><consume.konsumieren><en> Your vitamin – Mineral Guide helps to understand the importance of vitamins and minerals in proper functioning of our body.- The application covers all macro and micro vitamins and minerals our body requires.- Learn why should you consume vitamins/ minerals?- Know which food provides what nutrients.- Learn about the symptoms and deficiency diseases...
<G-vec00886-002-s144><consume.konsumieren><de> Ihr Vitamin - Mineral Guide hilft, die Bedeutung von Vitaminen und Mineralien im reibungslosen Funktionieren unseres Körpers zu verstehen.- Die Anwendung umfasst alle Makro-und Mikro-Vitamine und Mineralien, die unser Körper erfordert.- Erfahren Sie, warum sollten Sie Vitamine / Mineralien konsumieren?- wissen, welche Nahrung welche Nährstoffe liefern.- Erfahren Sie mehr über die...
<G-vec00886-002-s145><consume.konsumieren><en> It is recommended that individuals should consume 1 pill in the morning with breakfast and also 1 product after lunch.
<G-vec00886-002-s145><consume.konsumieren><de> Es wird empfohlen, dass die Verbraucher sollten 1 Tablette am Morgen mit einem Frühstück konsumieren und auch 1 Beilage nach dem Mittagessen.
<G-vec00886-002-s146><consume.konsumieren><en> You could keep by acquiring the product and also attempt to consume it.
<G-vec00886-002-s146><consume.konsumieren><de> Sie können durch den Kauf das Einzelteil zu halten und auch versuchen, es zu konsumieren.
<G-vec00886-002-s147><consume.konsumieren><en> This can be difficult for many, as there are no easy ways to consume concentrates without sophisticated glass and hardware.
<G-vec00886-002-s147><consume.konsumieren><de> Dies stellt sich für viele als schwierig heraus, da es nicht einfach ist, ohne aufwändige Glaswaren und Geräte Konzentrate zu konsumieren.
<G-vec00886-002-s148><consume.konsumieren><en> Next to it, a mini ceramic pipe in the shape of a cigarette that will allow you to consume pure water quickly and discreetly.
<G-vec00886-002-s148><consume.konsumieren><de> Daneben eine Mini-Keramikpfeife in Form einer Zigarette, mit der Sie schnell und diskret reines Wasser konsumieren können.
<G-vec00886-002-s149><consume.konsumieren><en> By lowering the amount of protein you consume you are decreasing your kidneys' workload.
<G-vec00886-002-s149><consume.konsumieren><de> Durch die Senkung der Proteinmenge, die du konsumierst, verminderst du die Arbeitsbelastung für deine Nieren.
<G-vec00886-002-s150><consume.konsumieren><en> If you do consume raw oysters, avoid eating oysters cultivated during the summer months, as the waters from which they are produced will have higher chances of carrying bacteria.
<G-vec00886-002-s150><consume.konsumieren><de> Wenn du rohe Austern konsumierst, vermeide Austern zu essen, die während der Sommermonate kultiviert wurden, weil die Wahrscheinlichkeit größer ist, dass das Wasser, in dem sie gezüchtet wurden, die Bakterien enthält.
<G-vec00886-002-s151><consume.konsumieren><en> This will help you stay hydrated and ensure that you do not consume more than the sensible guidelines suggest.
<G-vec00886-002-s151><consume.konsumieren><de> Dies hilft dir hydriert zu bleiben und stellt sicher, dass du nicht mehr konsumierst, als die vernünftigen Richtlinien empfehlen.
<G-vec00886-002-s152><consume.konsumieren><en> Find a product you consume every day, talk about it to others, then reap the financial rewards.
<G-vec00886-002-s152><consume.konsumieren><de> Finde ein Produkt, welches du jeden Tag konsumierst, rede darüber mit anderen und erkläre über die finanziellen Möglichkeiten.
<G-vec00886-002-s153><consume.konsumieren><en> You will not lose the kilos you do not consume. They will automatically be added to your kilos of the next season.
<G-vec00886-002-s153><consume.konsumieren><de> Die Kilos, die du nicht konsumierst, gehen nicht verloren, sondern automatisch für die nächste Saison gutgeschrieben.
<G-vec00886-002-s154><consume.konsumieren><en> It is not just the amount of shrooms or truffles that you consume that can impact the strength of your trip.
<G-vec00886-002-s154><consume.konsumieren><de> Es ist nicht nur die Menge an Pilzen oder Trüffeln, die Du konsumierst, die die Stärke Deines Trips beeinflussen kann.
<G-vec00886-002-s155><consume.konsumieren><en> As for its effects, once you consume it, you will not be able to stay still.
<G-vec00886-002-s155><consume.konsumieren><de> Was seine Wirkung betrifft, so werden Sie, wenn Sie es einmal konsumiert haben, nicht mehr stillhalten können.
<G-vec00886-002-s156><consume.konsumieren><en> However, when it comes to the mass medicines that most people consume – and 67% of the medicines consumed in Europe are generic medicines – they’re very inexpensive, in fact, and amongst the lowest prices in the world.
<G-vec00886-002-s156><consume.konsumieren><de> Wenn es um Massenmedikamente geht, die von dem Großteil der Bevölkerung konsumiert wird – 67% der in Europa konsumierten Medikamente sind Generika -, sind sie tatsächlich sehr preiswert und gehören zu den niedrigsten Preisen der Welt.
<G-vec00886-002-s158><consume.konsumieren><en> The first of these interpretations offers wisdom on how to consume the pleasures of immediate, personal experience when you'd rather they not change; the second, on how to produce change when you want it.
<G-vec00886-002-s158><consume.konsumieren><de> Die erste dieser Interpretationen gibt weisen Rat, wie die Freuden der unmittelbaren, persönlichen Erfahrung konsumiert werden sollen, wenn wir es lieber hätten, dass sie sich nicht ändern; die zweite darüber, wie man Veränderung bewirkt, wenn man sie haben möchte.
<G-vec00886-002-s159><consume.konsumieren><en> In many cases this raises the question of how many kilocalories people actually consume during the holidays and how they can survive without a higher weight gain.
<G-vec00886-002-s159><consume.konsumieren><de> Vielfach stellt sich dabei die Frage wie viele Kilokalorien eigentlich an den Feiertagen konsumiert werden und wie man sie ohne größere Gewichtszunahme überstehen kann.
<G-vec00886-002-s160><consume.konsumieren><en> This effect can only be triggered once before the Daily will consume AP.
<G-vec00886-002-s160><consume.konsumieren><de> Dieser Effekt kann nur einmal ausgelöst werden, bevor die AP konsumiert werden.
<G-vec00886-002-s162><consume.konsumieren><en> 21.02.2005 The Wyoming Senate on Monday approved a bill that would establish a penalty for anyone hosting a party where minors consume alcohol or illegal drugs.
<G-vec00886-002-s162><consume.konsumieren><de> 21.02.2005 Der Senat von Wyoming, USA, hat ein Gesetz genehmigt, das unter Strafe stellt, eine Party zu beherbergen, an der Alkohol oder illegale Drogen von Minderjährigen konsumiert werden.
<G-vec00886-002-s163><consume.konsumieren><en> Apart from fish, crustaceans and bivalves, people also consume algae and jellyfish.
<G-vec00886-002-s163><consume.konsumieren><de> Konsumiert werden neben Fischen, Krebsen und Mu-scheln auch Algen und Quallen.
<G-vec00886-002-s164><consume.konsumieren><en> During the healing phase, the patient may not smoke or consume alcohol.
<G-vec00886-002-s164><consume.konsumieren><de> Während der Heilungsphase darf nicht geraucht und kein Alkohol konsumiert werden.
<G-vec00886-002-s165><consume.konsumieren><en> I'm hyperactive and used to consume indica strains due to their powerful relaxing effect, but since I'm a father I don't sleep that much and I am usually pretty tired; that's why I now prefer sativa varieties.
<G-vec00886-002-s165><consume.konsumieren><de> Ich bin hyperaktiv und habe früher nur Indica-Varietäten aufgrund der starken entspannenden Wirkung konsumiert, aber seitdem ich Vater bin, schlafe ich nicht allzu viel und bin ziemlich müde, weswegen ich jetzt Sativa-Varietäten vorziehe.
<G-vec00886-002-s166><consume.konsumieren><en> If you have taken advantage of the summer to grow outdoors, you must have already harvested your plants and dried your precious green treasure, now having succulent and fragrant flowers that you can consume in many ways, like using this special ingredient in your recipes.
<G-vec00886-002-s166><consume.konsumieren><de> Sollten Sie den Sommer genutzt haben, um draußen anzubauen, haben Sie Ihre geschätzte grüne Materie sicherlich schon geerntet und getrocknet, sodass Sie köstliche und aromatische Blüten in Ihrem Besitz haben, die auf viele verschiedene Weisen konsumiert werden können – warum nicht auch als Zutat in Ihren Rezepten.
<G-vec00886-002-s167><consume.konsumieren><en> If your child is in this age group consume breast milk, it is not a hindrance to a new phase in the transition to the unfamiliar food, and even considered a "plus" for his health.
<G-vec00886-002-s167><consume.konsumieren><de> Wenn Ihr Kind in diesem Alten Muttermilch konsumiert, ist es kein Hindernis für eine neue Phase im Übergang zu dem ungewohnten Essen und sogar ein „Plus“ für seine Gesundheit.
<G-vec00886-002-s168><consume.konsumieren><en> This number doubles the national average, which indicates that 13% of US adults are consumers of the plant, and it is almost three times higher than in Alabama, Mississippi or Iowa, where only 8% consume.
<G-vec00886-002-s168><consume.konsumieren><de> Diese Zahl ist doppelt so hoch wie der nationale Durchschnitt, wo 13% der erwachsenen US-Amerikaner Marihuana konsumieren, und dreimal so hoch wie in den Staaten Alabama, Mississippi oder Iowa, wo nur 8% der Bevölkerung Marihuana konsumiert.
<G-vec00886-002-s169><consume.konsumieren><en> Vitamin B17, which is the amygdalin compound, is a naturally occurring compound found in many plant based foods people consume.
<G-vec00886-002-s169><consume.konsumieren><de> Vitamin B17, die Amygdalin-Verbindung, ist eine natürlich vorkommende Verbindung, die in vielen pflanzlichen Nahrungsmitteln gefunden wird, die von Menschen konsumiert werden.
<G-vec00886-002-s170><consume.konsumieren><en> It is ideal to consume it uncooked: in breakfasts, salads, as an aperitif before the food and even to taste with friends.
<G-vec00886-002-s170><consume.konsumieren><de> Ideal wird es ungekocht konsumiert: Frühstücke, Salate, als Aperitif vor dem Essen und sogar, um mit den Freunden zu verkosten.
<G-vec00886-002-s171><consume.konsumieren><en> At this temperature, the yeast will consume the sugar and begin to ferment, creating carbon dioxide.
<G-vec00886-002-s171><consume.konsumieren><de> Bei dieser Temperatur konsumiert die Hefe den Zucker und beginnt zu fermentieren, wobei Kohlendioxyd entsteht.
<G-vec00886-002-s172><consume.konsumieren><en> If you consume a lot here, you may get the wrong result with a drug test.
<G-vec00886-002-s172><consume.konsumieren><de> Wer hier viel konsumiert, kann ein falsches Ergebnis bei einem Drogentest als Resultat bekommen.
<G-vec00886-002-s173><consume.konsumieren><en> The guests can rest their feet on these poles, which makes it easier for them to stand longer and to consume more drinks.
<G-vec00886-002-s173><consume.konsumieren><de> Damit wird es leichter, für längere Zeit zu stehen, wodurch übrigens auch mehr Getränke konsumiert werden können.
<G-vec00886-002-s264><consume.verbrauchen><en> Eldritch Units These Units consume half the Food of their normal counterparts.
<G-vec00886-002-s264><consume.verbrauchen><de> Gespenstereinheiten Diese Einheiten verbrauchen nur halb so viele Lebensmittel wie ihre regulären Gegenstücke.
<G-vec00886-002-s265><consume.verbrauchen><en> Applying a mark during targeting mode will consume 15 energy.
<G-vec00886-002-s265><consume.verbrauchen><de> Das Anwenden einer Marke während des Ziel-Modus wird 15 Energie verbrauchen.
<G-vec00886-002-s266><consume.verbrauchen><en> They consume nearly 40 percent of our total energy and 68 percent of our electricity while emitting 38 percent of CO2 into the atmosphere annually.
<G-vec00886-002-s266><consume.verbrauchen><de> Sie verbrauchen fast 40 Prozent unserer gesamten Energie und 68 Prozent unserer Elektrizität, während sie jährlich 38 Prozent CO2 in die Atmosphäre abgeben.
<G-vec00886-002-s267><consume.verbrauchen><en> It rather means that these places can theoretically produce more renewable electricity than they consume but have to import power at certain times of the day or year.
<G-vec00886-002-s267><consume.verbrauchen><de> Es bedeutet eher, dass die Orte rechnerisch zwar mehr regenerativ erzeugten Strom produzieren können, als sie selbst verbrauchen, aber zu manchen Tages- oder Jahreszeiten doch auf Strom-Importe angewiesen sind.
<G-vec00886-002-s268><consume.verbrauchen><en> This is quite important, since customers need to recognize the info prior to they consume them.
<G-vec00886-002-s268><consume.verbrauchen><de> Dies ist sehr wichtig, da die Verbraucher müssen die Details kennen, bevor sie sie verbrauchen.
<G-vec00886-002-s269><consume.verbrauchen><en> While the threat of Forskolin in pregnant as well as breastfeeding females is unknowned, so they must not consume it.
<G-vec00886-002-s269><consume.verbrauchen><de> Während die Bedrohung durch Forskolin bei schwangeren sowie stillende Frauen Unknowned ist, so dass sie es nicht verbrauchen müssen.
<G-vec00886-002-s270><consume.verbrauchen><en> You see, we now only buy as much of anything as we really consume. I mean, we no longer need to throw anything away.
<G-vec00886-002-s270><consume.verbrauchen><de> Wir haben nämlich festgestellt, dass wir nur noch so viel einkaufen, wie wir auch verbrauchen, also nichts mehr wegschmeißen müssen.
<G-vec00886-002-s271><consume.verbrauchen><en> Consume lots of citrus fruits which are high in vitamin C and fantastic for your health.
<G-vec00886-002-s271><consume.verbrauchen><de> Verbrauchen Sie attraktive Angebote von Zitrusfrüchten, die reich an Vitamin C und auch fantastisch für Ihre Gesundheit sind.
<G-vec00886-002-s272><consume.verbrauchen><en> Consume bunches of citrus fruits which are high in vitamin C and also fantastic for your wellness.
<G-vec00886-002-s272><consume.verbrauchen><de> Verbrauchen Sie attraktive Angebote von Zitrusfrüchten, die reich an Vitamin C und ideal für Ihr Wohlbefinden sind.
<G-vec00886-002-s273><consume.verbrauchen><en> All the forms of energy used that consume or convert a certain initial product, which does not self-renew, are called non-renewable: in the case of oil, we use oil until the resource ends (within a few years).
<G-vec00886-002-s273><consume.verbrauchen><de> Alle verwendeten Energieformen, die ein bestimmtes Ausgangsprodukt verbrauchen oder umwandeln, das sich nicht selbst erneuert, werden als nicht erneuerbar bezeichnet: Bei Öl verwenden wir Öl bis zum Ende der Ressource (innerhalb weniger Jahre).
<G-vec00886-002-s274><consume.verbrauchen><en> The principle is simple: An engine which is not running cannot consume fuel.
<G-vec00886-002-s274><consume.verbrauchen><de> Das Prinzip ist einfach: Ein Motor, der nicht läuft, kann keinen Sprit verbrauchen.
<G-vec00886-002-s275><consume.verbrauchen><en> An FTP user can exploit this flaw to make the process vsftpd consume excessive CPU time when a request with a specially crafted file name pattern occurs.
<G-vec00886-002-s275><consume.verbrauchen><de> Ein FTP-Benutzer kann diesen Fehler ausnutzen, um den Prozess vsftpd übermäßig viel CPU-Zeit verbrauchen zu lassen wenn bei einer Anfrage ein speziell gestaltetes Dateinamenmuster auftritt.
<G-vec00886-002-s276><consume.verbrauchen><en> Rajko Braunschweig from SILL GmbH explains this development in our audio feature: “They have a long lifespan, consume very little energy, require almost no maintenance – and can generate all sorts of different colour temperatures from white to colourful light.”
<G-vec00886-002-s276><consume.verbrauchen><de> Rajko Braunschweig von der SILL GmbH erläutert in unserem Audiobeitrag, warum: „Sie haben eine hohe Lebensdauer, verbrauchen wenig Strom, erfordern kaum Wartung – und können Licht von weiß bis bunt in den unterschiedlichsten Farbtemperaturen erzeugen“.
<G-vec00886-002-s277><consume.verbrauchen><en> Once prepared, it is recommended to consume the bottle in half an hour.
<G-vec00886-002-s277><consume.verbrauchen><de> Einmal hergestellt, wird empfohlen, um die Flasche in einer halben Stunde zu verbrauchen.
<G-vec00886-002-s278><consume.verbrauchen><en> However, bigger, freely swimming fish consume more energy while swimming and therefore must be fed regularly.
<G-vec00886-002-s278><consume.verbrauchen><de> Größere, frei schwimmende Fische dagegen verbrauchen mehr Energie beim Schwimmen und benötigen deshalb regel- mäßige Fütterung.
<G-vec00886-002-s279><consume.verbrauchen><en> Consume great deals of citrus fruits which are high in vitamin C and fantastic for your wellness.
<G-vec00886-002-s279><consume.verbrauchen><de> Verbrauchen Trauben von Zitrusfrüchte, die reich an Vitamin C und auch wunderbar für Ihre Gesundheit sind.
<G-vec00886-002-s280><consume.verbrauchen><en> LED lights provide the same amount of lighting to the working area as standard lights, yet they consume little more than one third of the energy.
<G-vec00886-002-s280><consume.verbrauchen><de> LED-Kranleuchten bieten den gleichen Ausleuchtungsgrad für den Arbeitsbereich wie die Standardbeleuchtung, verbrauchen dabei aber nur wenig mehr als ein Drittel der Energie.
<G-vec00886-002-s281><consume.verbrauchen><en> After opening store cool at + 3 °C to + 7 °C and consume immediately.
<G-vec00886-002-s281><consume.verbrauchen><de> Nach dem Öffnen kühl bei +3°C bis +7°C lagern und alsbald verbrauchen.
<G-vec00886-002-s282><consume.verbrauchen><en> Do not consume PhenQ during the evening or prior to bed due to the caffeine materials.
<G-vec00886-002-s282><consume.verbrauchen><de> Sie nicht verbrauchen PhenQ im Laufe des Abends oder vor dem Schlafengehen als Folge der Coffein-Komponenten.
<G-vec00886-002-s283><consume.verbrauchen><en> The plant will then be in the resting position and will consume considerably less energy.
<G-vec00886-002-s283><consume.verbrauchen><de> Die Pflanze befindet sich dann in der Ruheposition und verbraucht deutlich weniger Energie.
<G-vec00886-002-s284><consume.verbrauchen><en> A photovoltaic system on the roof produces solar energy, which the Zoo can consume directly, without feeding it into the grid. More information
<G-vec00886-002-s284><consume.verbrauchen><de> Ein auf dem Dach installiertes Photovoltaiksystem erzeugt Solarenergie, die vom Zoo ohne vorherige Einspeisung in das Stromnetz direkt verbraucht werden kann.
<G-vec00886-002-s285><consume.verbrauchen><en> To prevent one of your subdomain to consume too much of your own quotas, you can assign individual limits to each subdomain.
<G-vec00886-002-s285><consume.verbrauchen><de> Um zu vermeiden, dass eine Ihrer Subdomains zu viel Ihrer eigenen Quoten verbraucht, können Sie jeder einzelnen Subdomain Einschränkungen zuordnen.
<G-vec00886-002-s286><consume.verbrauchen><en> New constructions will have to take this into account. Those in which the air conditioning (in the sense of heating as well as cooling) will consume too much energy will be ignored by users and simply heavily taxed by the authorities, which will issue ever increasingly exacting standards.
<G-vec00886-002-s286><consume.verbrauchen><de> Die Bauweisen werden dies berücksichtigen müssen, und die Gebäude, deren Klimatisierung (im Sinn von Heizung wie Kühlung) zu viel Energie verbraucht, werden von den Nutzern gemieden oder von den Behörden, die immer strengere Normen herausgeben, hoch besteuert.
<G-vec00886-002-s287><consume.verbrauchen><en> Besides electricity, we also consume steam.
<G-vec00886-002-s287><consume.verbrauchen><de> Neben Strom wird auch Dampf verbraucht.
<G-vec00886-002-s288><consume.verbrauchen><en> Consume 1 Combination Point upon use.
<G-vec00886-002-s288><consume.verbrauchen><de> -1 Kombinationspunkt wird verbraucht.
<G-vec00886-002-s289><consume.verbrauchen><en> A 230V linear appliance operated at 240V will consume approximately 9% more energy than necessary.
<G-vec00886-002-s289><consume.verbrauchen><de> Ein lineares Gerät 230V, das an 240V bearbeitet wird, verbraucht ungefähr 9% weitere Energie als notwendig.
<G-vec00886-002-s290><consume.verbrauchen><en> This television is designed to consume less energy.
<G-vec00886-002-s290><consume.verbrauchen><de> Dieses TV-Gerät wurde so konstruiert, dass es weniger Energie verbraucht.
<G-vec00886-002-s291><consume.verbrauchen><en> By defrosting the fridge, you will have to think a few days in advance about what food you still have to consume.
<G-vec00886-002-s291><consume.verbrauchen><de> Durch das Abtauen des Kühlschranks, musst du ein paar Tage vorher intensiv darüber nachdenken, welche Lebensmittel du noch zu verbraucht hast.
<G-vec00886-002-s292><consume.verbrauchen><en> The result will be a plus energy building, which means that the office complex will not consume more energy than before despite the roughly one hundred new workplaces and large conference area.
<G-vec00886-002-s292><consume.verbrauchen><de> Jetzt entsteht ein Plus-Energie-Gebäude, so dass auf dem Gelände trotz etwa einhundert neuer Arbeitsplätze und einem großem Konferenzbereich nicht mehr Energie verbraucht wird als vorher.
<G-vec00886-002-s293><consume.verbrauchen><en> The majority of property owners are unaware of how much energy their buildings consume.
<G-vec00886-002-s293><consume.verbrauchen><de> Nur die wenigsten Immobilieneigentümer wissen, wie viel Energie ihr Gebäude verbraucht.
<G-vec00886-002-s294><consume.verbrauchen><en> Just keep in mind that those application will consume system resources and memory every time you boot your Mac.
<G-vec00886-002-s294><consume.verbrauchen><de> Denken Sie daran, dass diese Anwendung bei jedem Start Ihres Mac Systemressourcen und Speicher verbraucht.
<G-vec00886-002-s295><consume.verbrauchen><en> Pranic living is about releasing and strengthening a natural inner resource so that the human system needs to consume less of the world’s resources.
<G-vec00886-002-s295><consume.verbrauchen><de> Pranaernährung ist die Fähigkeit, aus der universellen Lebenskraft alle Nährstoffe, freizusetzen und zu stärken, damit das menschliche System weniger von den Ressourcen der Welt verbraucht.
<G-vec00886-002-s296><consume.verbrauchen><en> An SPLD is very similar to a Complex PLD (CPLD), but an SPLD will have less IO pins and programmable elements, consume less power, and will often require a special programming device to configure, but programming methods are proprietary and may vary by manufacturer.
<G-vec00886-002-s296><consume.verbrauchen><de> Ein SPLD ist einem komplexen PLD (CPLD) sehr ähnlich, ein SPLD hat jedoch weniger IO-Stifte und programmierbare Elemente, verbraucht weniger Strom und erfordert oft eine spezielles Programmier-Bauteil zum Konfigurieren, die Programmiermethoden sind jedoch geschützt und können je nach Hersteller abweichen.
<G-vec00886-002-s297><consume.verbrauchen><en> Try to avoid using the air conditioner in stop-and-go city driving as it causes the engine to work hard and consume more fuel.
<G-vec00886-002-s297><consume.verbrauchen><de> Versuche, ohne Klimaanlage bei Stop-and-Go-Stadtfahren zu fahren, da der Motor mit einer Klimaanlage schwerer arbeiten muss und mehr Kraftstoff verbraucht.
<G-vec00886-002-s298><consume.verbrauchen><en> Under normal movement, the muscle can consume 60-70 joule energy per second, but under high frequency movement, the muscles can consume 4000-3000 joule Energy per second.
<G-vec00886-002-s298><consume.verbrauchen><de> Bei normaler Bewegungen verbraucht der Muskel 60-70 Joule Energie pro Sekunde, aber unter hochfrequenten Bewegungen können die Muskeln 4000-3000 Joule Energie pro Sekunde verbrauchen.
<G-vec00886-002-s299><consume.verbrauchen><en> Note: make sure you have enough battery to support the scanning since it may take a while and consume more battery.
<G-vec00886-002-s299><consume.verbrauchen><de> Hinweis: Stellen Sie sicher, dass Sie genügend Batterie haben, um das Scannen zu unterstützen, da es eine Weile dauern kann und mehr Batterie verbraucht.
<G-vec00886-002-s300><consume.verbrauchen><en> - This mode is active only when the unlock screen is visible, does not consume the battery.
<G-vec00886-002-s300><consume.verbrauchen><de> - Dieser Modus ist nur bei sichtbarem Entsperr-Bildschirm aktiv und verbraucht keine zusätzliche Energie.
<G-vec00886-002-s301><consume.verbrauchen><en> The charger will consume almost no power in this state.
<G-vec00886-002-s301><consume.verbrauchen><de> In diesem Zustand verbraucht das Ladegerät fast keinen Strom.
<G-vec00886-002-s309><consume.verwenden><en> To be more precise, I had to consume the remaining berries and milk.
<G-vec00886-002-s309><consume.verwenden><de> Um genauer zu sein, musste ich die über gebliebenen Beeren und die Milch verwenden.
<G-vec00886-002-s310><consume.verwenden><en> It is suggested you consume any kind of molasses preferably in the morning to sweeten cereals, juices, shakes, teas or other drinks.
<G-vec00886-002-s310><consume.verwenden><de> Es wird vorgeschlagen, sie verwenden jede Art von Melasse, vorzugsweise am Morgen zum süßen Getreide, Säfte, Shakes, Tee oder andere Getränke.
<G-vec00886-002-s311><consume.verwenden><en> Talk with your doctor about amount of liquids you should consume.
<G-vec00886-002-s311><consume.verwenden><de> Beraten Sie sich mit Ihrem Arzt bezüglich der Menge von Flüssigkeit, die Sie verwenden müssen.
<G-vec00886-002-s312><consume.verwenden><en> Ideally, opening up the archive shouldn’t just mean having regular opening hours and a website, it should entail an active search for users, an open invitation for individuals to consume the material.
<G-vec00886-002-s312><consume.verwenden><de> Idealerweise sollte die Öffnung des Archivs nicht nur bedeuten, lediglich reguläre Öffnungszeiten und eine Website anzubieten, sondern es sollte auch eine aktive Suche nach Nutzern, eine offene Einladung an Personen enthalten, das Material zu verwenden.
<G-vec00886-002-s313><consume.verwenden><en> The weight value is a number that specifies the amount of remaining space each view should consume, relative to the amount consumed by sibling views.
<G-vec00886-002-s313><consume.verwenden><de> Der weight-Wert ist eine Zahl, welche festlegt, wie viel verfügbaren Platz jedes View verwenden soll, relativ zu der Menge die andere Views verwenden.
<G-vec00886-002-s314><consume.verwenden><en> Once opened, keep refrigerated and consume within 24 hours.
<G-vec00886-002-s314><consume.verwenden><de> Offene Ampulle speichern Sie in dem Kühlschrank und verwenden Sie innerhalb von 24 Stunden.
<G-vec00886-002-s315><consume.verwenden><en> Consume a more powerful Weapon to boost the Attack value of this Weapon.
<G-vec00886-002-s315><consume.verwenden><de> Beim Verwenden der Zielvorrichtung dieser Waffe bleibt das Radar aktiv.
<G-vec00886-002-s316><consume.verwenden><en> Adobe Dimension uses multi-threading and can consume as much computing power as is available on your computer.
<G-vec00886-002-s316><consume.verwenden><de> Adobe Dimension verwendet Multithreading und kann so viel Rechenleistung verwenden, wie auf Ihrem Computer vorhanden ist.
<G-vec00886-002-s317><consume.verwenden><en> We’ve also introduced a powerful presentation mode for published maps and our interactive map export to ensure anyone can easily consume the content that you carefully created for distribution.
<G-vec00886-002-s317><consume.verwenden><de> Außerdem haben wir einen leistungsstarken Präsentationsmodus für veröffentlichte Maps und unseren interaktiven Maps-Export eingeführt, um sicherzustellen, dass jeder den Inhalt, den Sie zuvor sorgfältig für die Verteilung erstellt haben, problemlos verwenden kann.
<G-vec00886-002-s318><consume.verwenden><en> Powers may only consume stacks of Empowered granted by their Divine versions and you may only have 3 stacks of Empowered for each power.
<G-vec00886-002-s318><consume.verwenden><de> Kräfte können ausschließlich Stapel verwenden, die durch ihre Göttliche Version erzeugt wurden, und pro Kraft können maximal 3 Stapel Verstärkt angesammelt werden.
<G-vec01004-002-s174><consume.(sich)_nehmen><en> SUPER FOOD allows us to consume enough nutrients for good functioning of the body.
<G-vec01004-002-s174><consume.(sich)_nehmen><de> SUPER LEBENSMITTEL ermöglichen uns, dass wir genügend Nährstoffe für die gute Funktion des Organismus zu sich nehmen.
<G-vec01004-002-s175><consume.(sich)_nehmen><en> Instead, one should try to consume a mixture of tocopherols, as close as possible to a mixture found in foods…
<G-vec01004-002-s175><consume.(sich)_nehmen><de> Stattdessen solltest Du versuchen, eine Mischung unterschiedlicher Tocopherole zu Dir zu nehmen, die sich so nahe wie möglich an der Mischung befindet, die man in der Nahrung vorfindet...
<G-vec01004-002-s176><consume.(sich)_nehmen><en> We take some breakfast and coffee along to consume while admiring the fabulous sunrise.
<G-vec01004-002-s176><consume.(sich)_nehmen><de> Wir nehmen ein kleines Frühstück und Kaffee mit, um diese während des zauberhaften Sonnenaufgangs zu uns zu nehmen.
<G-vec01004-002-s177><consume.(sich)_nehmen><en> Each piece of food or drink that we consume has its own vibration.
<G-vec01004-002-s177><consume.(sich)_nehmen><de> Jedes kleine Stück Essen, jedes Getränk, daß wir zu uns nehmen, hat seine eigene Schwingung.
<G-vec01004-002-s178><consume.(sich)_nehmen><en> That’s because the Bovis value also dictates how healthy the food that we consume is.
<G-vec01004-002-s178><consume.(sich)_nehmen><de> Dieser Wert gibt nämlich auch an, ob die Nahrung, die wir zu uns nehmen, auch wirklich gesund ist.
<G-vec01004-002-s179><consume.(sich)_nehmen><en> This supplement will certainly excellent to consume due to the fact that it has many advantages.
<G-vec01004-002-s179><consume.(sich)_nehmen><de> Dieser Zuschlag wird ausgezeichnet aufgrund der Tatsache zu nehmen, dass sie einen Großteil der Vorteile hat.
<G-vec01004-002-s180><consume.(sich)_nehmen><en> In order to get the full effect of Moringa, you should additionally consume Moringa tea, as some ingredients need warmth to become bioavailable.
<G-vec01004-002-s180><consume.(sich)_nehmen><de> Um die volle Wirkung von Moringa zu erhalten, sollten Sie zusätzlich Moringa-Tee zu sich nehmen, da einige Inhaltsstoffe Wärme benötigen um bioverfügbar zu werden.
<G-vec01004-002-s181><consume.(sich)_nehmen><en> This way, you can still get to enjoy the food without having to consume too many calories.
<G-vec01004-002-s181><consume.(sich)_nehmen><de> So kannst du das Essen genießen ohne zu viele Kalorien zu dir zu nehmen.
<G-vec01004-002-s182><consume.(sich)_nehmen><en> Consume 3 tablets with water around 15 minutes after training.
<G-vec01004-002-s182><consume.(sich)_nehmen><de> Nehmen Sie 3 Tabletten mit Wasser etwa 15 Minuten nach dem Training.
<G-vec01004-002-s183><consume.(sich)_nehmen><en> To lose weight, you need to consume fewer calories than you burn.
<G-vec01004-002-s183><consume.(sich)_nehmen><de> Damit du Gewicht verlierst, musst du weniger Kalorien zu dir nehmen als du verbrauchst.
<G-vec01004-002-s184><consume.(sich)_nehmen><en> To begin utilizing this solution, merely consume two (2) tablets in the morning and also one (1) in the mid-day.
<G-vec01004-002-s184><consume.(sich)_nehmen><de> Zunächst mit dieser Formel, nehmen Sie nur zwei (2) Pillen in den frühen Morgenstunden und auch ein (1) am Nachmittag.
<G-vec01004-002-s185><consume.(sich)_nehmen><en> This implies that a bottle of PhenQ will last about 1 month when you consume this product frequently.
<G-vec01004-002-s185><consume.(sich)_nehmen><de> Dies zeigt an, dass ein Behälter von PhenQ dauern wird über 1 Monat, wenn Sie diese Kapsel nehmen regelmäßig.
<G-vec01004-002-s186><consume.(sich)_nehmen><en> On training days, consume 30-45 minutes prior to training.
<G-vec01004-002-s186><consume.(sich)_nehmen><de> An Trainingstagen nehmen Sie 30-45 Minuten vor dem Training.
<G-vec01004-002-s187><consume.(sich)_nehmen><en> Eat smarter and achieve your health goals by keeping track of the calories you consume and burn.
<G-vec01004-002-s187><consume.(sich)_nehmen><de> Essen Sie gesünder und erreichen Sie Ihre Gesundheitsziele, indem Sie alle Kalorien, die Sie zu sich nehmen und verbrennen, im Blick haben.
<G-vec01004-002-s188><consume.(sich)_nehmen><en> Advanced Appetite Suppress is a natural weight loss supplement that promotes weight loss effectively and naturally. We normally consume too many calories, especially in the Western world.
<G-vec01004-002-s188><consume.(sich)_nehmen><de> In der westlichen Welt nehmen wir in der Regel zu viele Kalorien zu uns, wodurch viele unter uns mit Übergewicht zu kämpfen haben, etwas, das man außerdem schwer wieder loswird.
<G-vec01004-002-s189><consume.(sich)_nehmen><en> Since aspartame can increase obesity and may even cause the metabolic syndrome that affects 48 million Americans, there is no reason to ever consume this product.
<G-vec01004-002-s189><consume.(sich)_nehmen><de> Da Aspartam Übergewicht erhöhen und möglicherweise sogar das metabolische Syndrom verursachen kann, an dem 48 Millionen Amerikaner leiden, gibt es keinen Grund, dieses Produkt jemals zu sich zu nehmen.
<G-vec01004-002-s190><consume.(sich)_nehmen><en> On the market today there are tons of medical supplies, which you can consume.
<G-vec01004-002-s190><consume.(sich)_nehmen><de> In dem heutigen Markt gibt es Tonnen von Gesundheits-Produkte zur Verfügung, die Sie zu sich nehmen kann.
<G-vec01004-002-s191><consume.(sich)_nehmen><en> Special crafted packets sent to the listening TCP port of certain NNM processes can cause either a memory leak or the daemon processes to consume excessive CPU ressources.
<G-vec01004-002-s191><consume.(sich)_nehmen><de> Speziell aufgebaute Pakete, welche zu einem Listen-TCP-Port bestimmter NNM Prozesse geschickt werden, können entweder ein Speicherleck erzeugen oder den Prozess dazu bringen, außergewöhnlich viele CPU-Ressourcen in Anspruch zu nehmen.
<G-vec01004-002-s192><consume.(sich)_nehmen><en> Consume 1 - 3 servings daily with or before each meal.
<G-vec01004-002-s192><consume.(sich)_nehmen><de> Nehmen Sie 1-3 Portionen täglich, vor oder mit jedem Mahlzeit.
<G-vec01004-002-s193><consume.(sich)_nehmen><en> Consume 4–6 capsules (one serving) with a large glass of water or juice.
<G-vec01004-002-s193><consume.(sich)_nehmen><de> Nimm 4–6 Kapseln (eine Portion) mit einem großen Glas Wasser oder Saft ein.
<G-vec01004-002-s194><consume.(sich)_nehmen><en> Directions: Consume up to 3 sachets per 60 minutes during exercise as required.
<G-vec01004-002-s194><consume.(sich)_nehmen><de> Anweisung: Nimm nach Bedarf alle 60 Minuten während des Trainings bis zu 3 Beutel.
<G-vec01004-002-s195><consume.(sich)_nehmen><en> Consume vitamins that are essential to hair health.
<G-vec01004-002-s195><consume.(sich)_nehmen><de> Nimm Vitamine zu dir, die essenziell für Haar sind.
<G-vec01004-002-s196><consume.(sich)_nehmen><en> Consume 500 calories per day less than you need - get to understand calories and the amount each food and drink contain so you can adjust if you need to.
<G-vec01004-002-s196><consume.(sich)_nehmen><de> Nimm jeden Tag 500 Kalorien mehr zu dir als du brauchst – Versuche zu verstehen wie viele Kalorien verschiedene Nahrungsmittel und Getränke enthalten, um die Kalorienzufuhr entsprechend anzupassen.
<G-vec01004-002-s197><consume.(sich)_nehmen><en> USE: Consume 2-3 grams of protein per kilogram of body weight per day by combining high-protein foods with supplements.
<G-vec01004-002-s197><consume.(sich)_nehmen><de> ANWENDUNG: Nimm idealerweise täglich 2-3 g Proteine pro Kilogramm an Körpergewicht durch Kombination von proteinhaltiger Nahrung und Ergänzungsmitteln zu dir.
<G-vec01004-002-s198><consume.(sich)_nehmen><en> Consume 1-3 gels per hour to deliver approximately 60 grams of carbohydrate and maximize carbohydrate utilization rates.
<G-vec01004-002-s198><consume.(sich)_nehmen><de> Nimm während eines Ausdauertrainings 1 bis 3 Gele pro Stunde zu dir, um die Ausnutzungsraten für die Kohlenhydrate zu maximieren.
<G-vec01004-002-s199><consume.(sich)_nehmen><en> Suggested Use: Consume up to 3 sachets per 60 minutes during exercise as required.
<G-vec01004-002-s199><consume.(sich)_nehmen><de> Empfohlene Anwendung: Nimm nach Bedarf alle 60 Minuten während des Trainings bis zu 3 Beutel.
<G-vec01004-002-s200><consume.(sich)_nehmen><en> Consume healthy foods and do not skip meals.
<G-vec01004-002-s200><consume.(sich)_nehmen><de> Nimm gesunde Nahrungsmittel zu dir und lass auf keinen Fall Mahlzeiten aus.
<G-vec01004-002-s201><consume.(sich)_nehmen><en> Water, Carotene) . Directions: Consume up to 3 sachets per 60 minutes during exercise as required.
<G-vec01004-002-s201><consume.(sich)_nehmen><de> Wasser, Maltodextrin (Maisstärke), Natürliches Aroma, Geliermittel (Anweisung: Nimm nach Bedarf alle 60 Minuten während des Trainings bis zu 3 Beutel.
<G-vec01004-002-s202><consume.(sich)_nehmen><en> It doesn't matter when you take your creatine; whether you consume it in the morning or at night, it will have the same effect on your body.
<G-vec01004-002-s202><consume.(sich)_nehmen><de> Es ist nicht wichtig, wann du das Kreatin nimmst, ob du es morgens oder abends zu dir nimmst, hat den gleichen Effekt für deinen Körper.
<G-vec01004-002-s203><consume.(sich)_nehmen><en> If you do not consume enough hydrating fluids each day, you run the risk of being dehydrated.
<G-vec01004-002-s203><consume.(sich)_nehmen><de> Wenn du täglich nicht genügend hydrierende Flüssigkeiten zu dir nimmst, dann läufst du Gefahr, zu dehydrieren.
<G-vec01004-002-s204><consume.(sich)_nehmen><en> You might also discover useful information about your daily habits and a reality check about how many calories you actually consume.
<G-vec01004-002-s204><consume.(sich)_nehmen><de> Dies könnte dir auch nützliche Einblicke in deine Essgewohnheiten liefern und dir die Augen dafür öffnen, wie viele Kalorien du tatsächlich zu dir nimmst.
<G-vec01004-002-s205><consume.(sich)_nehmen><en> Having a wide variety of foods from food groups will allow you to consume a variety of different nutrients.
<G-vec01004-002-s205><consume.(sich)_nehmen><de> Auf diese Weise sorgst du dafür, dass du viele verschiedene Nährstoffe zu dir nimmst.
<G-vec01004-002-s206><consume.(sich)_nehmen><en> Increase the amount omega-3 fatty acid you consume but decrease omega-6 fats.
<G-vec01004-002-s206><consume.(sich)_nehmen><de> Erhöhe die Menge an Omega-3-Fettsäuren die du zu dir nimmst, aber reduziere Omega-6-Fette.
<G-vec01004-002-s207><consume.(sich)_nehmen><en> A balanced diet means that you consume foods from each food group most, if not every day.
<G-vec01004-002-s207><consume.(sich)_nehmen><de> Eine ausgewogene Ernährung heißt, dass du möglichst täglich Nahrung aus allen Lebensmittelgruppen zu dir nimmst.
<G-vec01004-002-s174><consume.nehmen><en> SUPER FOOD allows us to consume enough nutrients for good functioning of the body.
<G-vec01004-002-s174><consume.nehmen><de> SUPER LEBENSMITTEL ermöglichen uns, dass wir genügend Nährstoffe für die gute Funktion des Organismus zu sich nehmen.
<G-vec01004-002-s175><consume.nehmen><en> Instead, one should try to consume a mixture of tocopherols, as close as possible to a mixture found in foods…
<G-vec01004-002-s175><consume.nehmen><de> Stattdessen solltest Du versuchen, eine Mischung unterschiedlicher Tocopherole zu Dir zu nehmen, die sich so nahe wie möglich an der Mischung befindet, die man in der Nahrung vorfindet...
<G-vec01004-002-s176><consume.nehmen><en> We take some breakfast and coffee along to consume while admiring the fabulous sunrise.
<G-vec01004-002-s176><consume.nehmen><de> Wir nehmen ein kleines Frühstück und Kaffee mit, um diese während des zauberhaften Sonnenaufgangs zu uns zu nehmen.
<G-vec01004-002-s177><consume.nehmen><en> Each piece of food or drink that we consume has its own vibration.
<G-vec01004-002-s177><consume.nehmen><de> Jedes kleine Stück Essen, jedes Getränk, daß wir zu uns nehmen, hat seine eigene Schwingung.
<G-vec01004-002-s178><consume.nehmen><en> That’s because the Bovis value also dictates how healthy the food that we consume is.
<G-vec01004-002-s178><consume.nehmen><de> Dieser Wert gibt nämlich auch an, ob die Nahrung, die wir zu uns nehmen, auch wirklich gesund ist.
<G-vec01004-002-s179><consume.nehmen><en> This supplement will certainly excellent to consume due to the fact that it has many advantages.
<G-vec01004-002-s179><consume.nehmen><de> Dieser Zuschlag wird ausgezeichnet aufgrund der Tatsache zu nehmen, dass sie einen Großteil der Vorteile hat.
<G-vec01004-002-s180><consume.nehmen><en> In order to get the full effect of Moringa, you should additionally consume Moringa tea, as some ingredients need warmth to become bioavailable.
<G-vec01004-002-s180><consume.nehmen><de> Um die volle Wirkung von Moringa zu erhalten, sollten Sie zusätzlich Moringa-Tee zu sich nehmen, da einige Inhaltsstoffe Wärme benötigen um bioverfügbar zu werden.
<G-vec01004-002-s181><consume.nehmen><en> This way, you can still get to enjoy the food without having to consume too many calories.
<G-vec01004-002-s181><consume.nehmen><de> So kannst du das Essen genießen ohne zu viele Kalorien zu dir zu nehmen.
<G-vec01004-002-s182><consume.nehmen><en> Consume 3 tablets with water around 15 minutes after training.
<G-vec01004-002-s182><consume.nehmen><de> Nehmen Sie 3 Tabletten mit Wasser etwa 15 Minuten nach dem Training.
<G-vec01004-002-s183><consume.nehmen><en> To lose weight, you need to consume fewer calories than you burn.
<G-vec01004-002-s183><consume.nehmen><de> Damit du Gewicht verlierst, musst du weniger Kalorien zu dir nehmen als du verbrauchst.
<G-vec01004-002-s184><consume.nehmen><en> To begin utilizing this solution, merely consume two (2) tablets in the morning and also one (1) in the mid-day.
<G-vec01004-002-s184><consume.nehmen><de> Zunächst mit dieser Formel, nehmen Sie nur zwei (2) Pillen in den frühen Morgenstunden und auch ein (1) am Nachmittag.
<G-vec01004-002-s185><consume.nehmen><en> This implies that a bottle of PhenQ will last about 1 month when you consume this product frequently.
<G-vec01004-002-s185><consume.nehmen><de> Dies zeigt an, dass ein Behälter von PhenQ dauern wird über 1 Monat, wenn Sie diese Kapsel nehmen regelmäßig.
<G-vec01004-002-s186><consume.nehmen><en> On training days, consume 30-45 minutes prior to training.
<G-vec01004-002-s186><consume.nehmen><de> An Trainingstagen nehmen Sie 30-45 Minuten vor dem Training.
<G-vec01004-002-s187><consume.nehmen><en> Eat smarter and achieve your health goals by keeping track of the calories you consume and burn.
<G-vec01004-002-s187><consume.nehmen><de> Essen Sie gesünder und erreichen Sie Ihre Gesundheitsziele, indem Sie alle Kalorien, die Sie zu sich nehmen und verbrennen, im Blick haben.
<G-vec01004-002-s188><consume.nehmen><en> Advanced Appetite Suppress is a natural weight loss supplement that promotes weight loss effectively and naturally. We normally consume too many calories, especially in the Western world.
<G-vec01004-002-s188><consume.nehmen><de> In der westlichen Welt nehmen wir in der Regel zu viele Kalorien zu uns, wodurch viele unter uns mit Übergewicht zu kämpfen haben, etwas, das man außerdem schwer wieder loswird.
<G-vec01004-002-s189><consume.nehmen><en> Since aspartame can increase obesity and may even cause the metabolic syndrome that affects 48 million Americans, there is no reason to ever consume this product.
<G-vec01004-002-s189><consume.nehmen><de> Da Aspartam Übergewicht erhöhen und möglicherweise sogar das metabolische Syndrom verursachen kann, an dem 48 Millionen Amerikaner leiden, gibt es keinen Grund, dieses Produkt jemals zu sich zu nehmen.
<G-vec01004-002-s190><consume.nehmen><en> On the market today there are tons of medical supplies, which you can consume.
<G-vec01004-002-s190><consume.nehmen><de> In dem heutigen Markt gibt es Tonnen von Gesundheits-Produkte zur Verfügung, die Sie zu sich nehmen kann.
<G-vec01004-002-s191><consume.nehmen><en> Special crafted packets sent to the listening TCP port of certain NNM processes can cause either a memory leak or the daemon processes to consume excessive CPU ressources.
<G-vec01004-002-s191><consume.nehmen><de> Speziell aufgebaute Pakete, welche zu einem Listen-TCP-Port bestimmter NNM Prozesse geschickt werden, können entweder ein Speicherleck erzeugen oder den Prozess dazu bringen, außergewöhnlich viele CPU-Ressourcen in Anspruch zu nehmen.
<G-vec01004-002-s192><consume.nehmen><en> Consume 1 - 3 servings daily with or before each meal.
<G-vec01004-002-s192><consume.nehmen><de> Nehmen Sie 1-3 Portionen täglich, vor oder mit jedem Mahlzeit.
<G-vec01004-002-s193><consume.nehmen><en> Consume 4–6 capsules (one serving) with a large glass of water or juice.
<G-vec01004-002-s193><consume.nehmen><de> Nimm 4–6 Kapseln (eine Portion) mit einem großen Glas Wasser oder Saft ein.
<G-vec01004-002-s194><consume.nehmen><en> Directions: Consume up to 3 sachets per 60 minutes during exercise as required.
<G-vec01004-002-s194><consume.nehmen><de> Anweisung: Nimm nach Bedarf alle 60 Minuten während des Trainings bis zu 3 Beutel.
<G-vec01004-002-s195><consume.nehmen><en> Consume vitamins that are essential to hair health.
<G-vec01004-002-s195><consume.nehmen><de> Nimm Vitamine zu dir, die essenziell für Haar sind.
<G-vec01004-002-s196><consume.nehmen><en> Consume 500 calories per day less than you need - get to understand calories and the amount each food and drink contain so you can adjust if you need to.
<G-vec01004-002-s196><consume.nehmen><de> Nimm jeden Tag 500 Kalorien mehr zu dir als du brauchst – Versuche zu verstehen wie viele Kalorien verschiedene Nahrungsmittel und Getränke enthalten, um die Kalorienzufuhr entsprechend anzupassen.
<G-vec01004-002-s197><consume.nehmen><en> USE: Consume 2-3 grams of protein per kilogram of body weight per day by combining high-protein foods with supplements.
<G-vec01004-002-s197><consume.nehmen><de> ANWENDUNG: Nimm idealerweise täglich 2-3 g Proteine pro Kilogramm an Körpergewicht durch Kombination von proteinhaltiger Nahrung und Ergänzungsmitteln zu dir.
<G-vec01004-002-s198><consume.nehmen><en> Consume 1-3 gels per hour to deliver approximately 60 grams of carbohydrate and maximize carbohydrate utilization rates.
<G-vec01004-002-s198><consume.nehmen><de> Nimm während eines Ausdauertrainings 1 bis 3 Gele pro Stunde zu dir, um die Ausnutzungsraten für die Kohlenhydrate zu maximieren.
<G-vec01004-002-s199><consume.nehmen><en> Suggested Use: Consume up to 3 sachets per 60 minutes during exercise as required.
<G-vec01004-002-s199><consume.nehmen><de> Empfohlene Anwendung: Nimm nach Bedarf alle 60 Minuten während des Trainings bis zu 3 Beutel.
<G-vec01004-002-s200><consume.nehmen><en> Consume healthy foods and do not skip meals.
<G-vec01004-002-s200><consume.nehmen><de> Nimm gesunde Nahrungsmittel zu dir und lass auf keinen Fall Mahlzeiten aus.
<G-vec01004-002-s201><consume.nehmen><en> Water, Carotene) . Directions: Consume up to 3 sachets per 60 minutes during exercise as required.
<G-vec01004-002-s201><consume.nehmen><de> Wasser, Maltodextrin (Maisstärke), Natürliches Aroma, Geliermittel (Anweisung: Nimm nach Bedarf alle 60 Minuten während des Trainings bis zu 3 Beutel.
<G-vec01004-002-s202><consume.nehmen><en> It doesn't matter when you take your creatine; whether you consume it in the morning or at night, it will have the same effect on your body.
<G-vec01004-002-s202><consume.nehmen><de> Es ist nicht wichtig, wann du das Kreatin nimmst, ob du es morgens oder abends zu dir nimmst, hat den gleichen Effekt für deinen Körper.
<G-vec01004-002-s203><consume.nehmen><en> If you do not consume enough hydrating fluids each day, you run the risk of being dehydrated.
<G-vec01004-002-s203><consume.nehmen><de> Wenn du täglich nicht genügend hydrierende Flüssigkeiten zu dir nimmst, dann läufst du Gefahr, zu dehydrieren.
<G-vec01004-002-s204><consume.nehmen><en> You might also discover useful information about your daily habits and a reality check about how many calories you actually consume.
<G-vec01004-002-s204><consume.nehmen><de> Dies könnte dir auch nützliche Einblicke in deine Essgewohnheiten liefern und dir die Augen dafür öffnen, wie viele Kalorien du tatsächlich zu dir nimmst.
<G-vec01004-002-s205><consume.nehmen><en> Having a wide variety of foods from food groups will allow you to consume a variety of different nutrients.
<G-vec01004-002-s205><consume.nehmen><de> Auf diese Weise sorgst du dafür, dass du viele verschiedene Nährstoffe zu dir nimmst.
<G-vec01004-002-s206><consume.nehmen><en> Increase the amount omega-3 fatty acid you consume but decrease omega-6 fats.
<G-vec01004-002-s206><consume.nehmen><de> Erhöhe die Menge an Omega-3-Fettsäuren die du zu dir nimmst, aber reduziere Omega-6-Fette.
<G-vec01004-002-s207><consume.nehmen><en> A balanced diet means that you consume foods from each food group most, if not every day.
<G-vec01004-002-s207><consume.nehmen><de> Eine ausgewogene Ernährung heißt, dass du möglichst täglich Nahrung aus allen Lebensmittelgruppen zu dir nimmst.
