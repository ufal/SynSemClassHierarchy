<G-vec00365-002-s056><assassinate.ausschalten><en> Assassinate 50 politicians.
<G-vec00365-002-s056><assassinate.ausschalten><de> Schalte 50 Politiker aus.
<G-vec00365-002-s042><assassinate.ermorden><en> But when an informant reveals a plot to assassinate the German Chancellor, Decker is assigned to protect the chancellor and kill the assassin.
<G-vec00365-002-s042><assassinate.ermorden><de> Aber als ein Informant eine Verschwörung aufdeckt, nach der die deutsche Bundeskanzlerin ermordet werden soll, wird Decker beauftragt, die Kanzlerin zu beschützen und den Attentäter auszuschalten.
<G-vec00365-002-s055><assassinate.töten><en> Eventually the Legion sniper will enter a crouch and approach the edge of the tower, at which point he will successfully assassinate Kimball.
<G-vec00365-002-s055><assassinate.töten><de> Schließlich wird der Legionsscharfschütze in die Hocke gehen und auf den Rand des Turms zugehen und den Präsidenten erfolgreich töten.
<G-vec00365-002-s062><assassinate.umbringen><en> Having returned to its teammates’ side, the tree spirit had already raised its guard against this thief who could burrow through the ground to assassinate her opponents.
<G-vec00365-002-s062><assassinate.umbringen><de> Der Baumgeist, der an die Seite seiner Teamkameraden zurückgekehrt war, hatte bereits seine Verteidigung gegen diese Diebin aufgestellt, die sich durch den Boden graben konnte, um ihre Widersacher umzubringen.
<G-vec00365-002-s063><assassinate.verteidigen><en> They do not always assassinate kings and princes.
<G-vec00365-002-s063><assassinate.verteidigen><de> Und sie verteidigen sich nicht.
