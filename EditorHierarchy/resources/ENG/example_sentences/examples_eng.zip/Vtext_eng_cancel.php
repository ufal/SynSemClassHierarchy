<G-vec00198-002-s038><cancel.abbestellen><en> You can also cancel the newsletter when you are logged in under MY USER ACCOUNT “General subscription”.
<G-vec00198-002-s038><cancel.abbestellen><de> Den Newsletter können Sie auch im eingeloggten Zustand unter MEIN BENUTZERKONTO „Allgemeines Abonnement“ abbestellen.
<G-vec00198-002-s039><cancel.abbestellen><en> Of course, you can cancel your subscription at any time.
<G-vec00198-002-s039><cancel.abbestellen><de> Sie können den Aboservice jederzeit wieder abbestellen.
<G-vec00198-002-s040><cancel.abbestellen><en> Furthermore, you can also cancel the newsletter directly on the website.
<G-vec00198-002-s040><cancel.abbestellen><de> Des Weiteren können Sie den Newsletter auch direkt auf der Website abbestellen.
<G-vec00198-002-s041><cancel.abbestellen><en> You can cancel the newsletter at any time by clicking the link included in every newsletter, or by sending an email to the data controller named above.
<G-vec00198-002-s041><cancel.abbestellen><de> Sie können den Newsletter jederzeit über den dafür vorgesehenen Link im Newsletter oder durch entsprechende Nachricht an den eingangs genannten Verantwortlichen abbestellen.
<G-vec00198-002-s042><cancel.abbestellen><en> You can cancel the newsletter anytime free of charge.
<G-vec00198-002-s042><cancel.abbestellen><de> Sie können den Newsletter jederzeit kostenlos abbestellen.
<G-vec00198-002-s043><cancel.abbestellen><en> There you will find information on how you can cancel your comment subscription at any time.
<G-vec00198-002-s043><cancel.abbestellen><de> Darin werden Sie Hinweise finden, wie Sie das Kommentarabonnement jederzeit wieder abbestellen können.
<G-vec00198-002-s044><cancel.abbestellen><en> You can cancel the notifications at any time by clicking on the link in the email.
<G-vec00198-002-s044><cancel.abbestellen><de> Die Benachrichtigungen können Sie jederzeit abbestellen, indem Sie auf den in der E-Mail enthaltenen Link klicken.
<G-vec00198-002-s045><cancel.abbestellen><en> Users may cancel comment subscriptions at any time.
<G-vec00198-002-s045><cancel.abbestellen><de> Nutzer können laufende Kommentarabonnements jederzeit abbestellen.
<G-vec00198-002-s046><cancel.abbestellen><en> Attendees who cancel a confirmed enrollment less than ten business days before the class and fail to provide a qualified replacement to fill the enrollment will be billed for one hundred percent of the full tuition fee.
<G-vec00198-002-s046><cancel.abbestellen><de> Kursteilnehmern, die eine bestätigte Reservierung weniger als zehn Werktage vor dem Kurs abbestellen und keine Austauschperson zum Füllen des Kurses haben, werden 100 Prozent der vollen Kursgebühr in Rechnung gestellt.
<G-vec00198-002-s047><cancel.abbestellen><en> You can cancel this service again via the newsletter at any time you want.
<G-vec00198-002-s047><cancel.abbestellen><de> Diesen Dienst können Sie jederzeit über den Newsletter wieder abbestellen.
<G-vec00198-002-s048><cancel.abbestellen><en> All plans are monthly plans and you can cancel anytime if you do not wish to continue.
<G-vec00198-002-s048><cancel.abbestellen><de> Alle Pläne sind Monatspläne, die Sie jederzeit abbestellen können wenn Sie es wünschen.
<G-vec00198-002-s049><cancel.abbestellen><en> If you wish to cancel your subscription to the newsletter, you can either send us an e-mail, or carry out cancellation by using the respective link at the end of the newsletter or by clicking here.
<G-vec00198-002-s049><cancel.abbestellen><de> Wenn Sie den abonnierten Newsletter abbestellen möchten, so können Sie uns entweder eine E-Mail zusenden oder über einen Link am Ende des Newsletters eine Stornierung vornehmen oder hier klicken.
<G-vec00198-002-s050><cancel.abbestellen><en> If you confirm, we will use your e-mail address to automatically send you e-mails until you cancel the e-mail service.
<G-vec00198-002-s050><cancel.abbestellen><de> Sofern Sie bestätigen, nutzen wir Ihre E-Mail-Adresse so lange zum Mailversand, bis Sie den Mail Service abbestellen.
<G-vec00198-002-s051><cancel.abbestellen><en> You can revoke your consent regarding the transmission of a newsletter at any time and cancel to the respective subscription.
<G-vec00198-002-s051><cancel.abbestellen><de> Ihre Einwilligung in die Übersendung eines Newsletters können Sie jederzeit widerrufen und das jeweilige Abonnement abbestellen.
<G-vec00198-002-s052><cancel.abbestellen><en> The tenant may cancel or alter his/her agreement 45 days before arrival at the latest.
<G-vec00198-002-s052><cancel.abbestellen><de> Abbestellung / Änderungen Der Mieter kann bis spätestens 45 Tage vor Ankunft abbestellen oder seinen Aufenthalt ändern.
<G-vec00198-002-s053><cancel.abbestellen><en> You can cancel the Newsletter free of charge at any time via the link provided.
<G-vec00198-002-s053><cancel.abbestellen><de> Den Newsletter können Sie jederzeit kostenfrei über den im Newsletter angegebenen Link abbestellen.
<G-vec00198-002-s054><cancel.abbestellen><en> You can cancel a subscription at any time.
<G-vec00198-002-s054><cancel.abbestellen><de> Sie können ein Abonnement jederzeit abbestellen.
<G-vec00198-002-s055><cancel.abbestellen><en> (5) You may withdraw your consent to receive the newsletter and cancel the newsletter at any time.
<G-vec00198-002-s055><cancel.abbestellen><de> (5) Ihre Einwilligung in die Übersendung des Newsletters können Sie jederzeit widerrufen und den Newsletter abbestellen.
<G-vec00198-002-s056><cancel.abbestellen><en> Then you just have to write your name into the correspondenting field and press the "Cancel"-Button to cancel receiving our Newsletter.
<G-vec00198-002-s056><cancel.abbestellen><de> Zum Abmelden brauchen Sie nur noch Ihren Namen in das entsprechende Feld eingeben und auf die "Abbestellen"-Schaltfläche klicken.
<G-vec00198-002-s057><cancel.abbrechen><en> This will cancel the transfer and your Offerings will be lost.
<G-vec00198-002-s057><cancel.abbrechen><de> Dies wird den Transfer abbrechen und eure Credits sind verloren.
<G-vec00198-002-s058><cancel.abbrechen><en> Click the Cancel button to exit the characterization mode.
<G-vec00198-002-s058><cancel.abbrechen><de> Klicken Sie den Abbrechen Butto, um den Charakterisierungsmodus zu verlassen.
<G-vec00198-002-s059><cancel.abbrechen><en> You can click Cancel to cancel the effect from being applied on the clip.
<G-vec00198-002-s059><cancel.abbrechen><de> Sie können auf „Abbrechen“ klicken, um die Anwendung des Effekts auf den Clip abzubrechen.
<G-vec00198-002-s060><cancel.abbrechen><en> In the download window, click Cancel.
<G-vec00198-002-s060><cancel.abbrechen><de> Klicken Sie im Uploadfenster auf Abbrechen.
<G-vec00198-002-s061><cancel.abbrechen><en> To cancel linking to the source file, and retain the audio track in all instances of the offline clip, click Cancel.
<G-vec00198-002-s061><cancel.abbrechen><de> Um die Verknüpfung mit der Quelldatei abzubrechen und die Audiospur in allen Instanzen des Offlineclips beizubehalten, klicken Sie auf „Abbrechen“.
<G-vec00198-002-s062><cancel.abbrechen><en> What you can do is to: change your mind and your vote or cancel your vote.
<G-vec00198-002-s062><cancel.abbrechen><de> Stattdessen können Sie Ihre Meinung und Bewertung ändern oder Ihre Neubewertung abbrechen.
<G-vec00198-002-s063><cancel.abbrechen><en> Press F9 and select the Cancel button.
<G-vec00198-002-s063><cancel.abbrechen><de> Sie drücken F9 und klicken auf "Abbrechen".
<G-vec00198-002-s064><cancel.abbrechen><en> The ordering process you can cancel at any time or [order or purchase-BUTTONS] by clicking the button to complete.
<G-vec00198-002-s064><cancel.abbrechen><de> Den Bestellvorgang können Sie jederzeit abbrechen oder durch Anklicken des Buttons [BESTELLEN oder KAUFEN-BUTTONS] abschließen.
<G-vec00198-002-s065><cancel.abbrechen><en> If you do not select Pair (by allowing a timeout) or you select Cancel, pairing will not proceed and you will need to select Pair Phone again on the ELEMNT BOLT.
<G-vec00198-002-s065><cancel.abbrechen><de> Wenn Sie „Synchronisieren“ nicht auswählen (indem Sie nicht innerhalb einer bestimmten Zeit reagieren) oder „Abbrechen“ wählen, wird die Synchronisierung nicht durchgeführt und Sie müssen „Telefon synchronisieren“ in ELEMNT erneut auswählen.
<G-vec00198-002-s066><cancel.abbrechen><en> Submit or Cancel Customers who bought this product also bought:
<G-vec00198-002-s066><cancel.abbrechen><de> Abbrechen Kunden, die diesen Artikel gekauft haben, kauften auch...
<G-vec00198-002-s067><cancel.abbrechen><en> Before submitting the order, the customer can always change and view the data, as wall as using the bbrowser function “back” to return to the shopping cart or cancel the entire order process.
<G-vec00198-002-s067><cancel.abbrechen><de> Vor Abschicken der Bestellung kann der Kunde die Daten jederzeit ändern und einsehen sowie mithilfe der Browserfunktion „zurück“ zum Warenkorb zurückgehen oder den Bestellvorgang insgesamt abbrechen.
<G-vec00198-002-s068><cancel.abbrechen><en> You can cancel at any time by pressing the Escape (Esc) key.
<G-vec00198-002-s068><cancel.abbrechen><de> Sie können sie jederzeit abbrechen, indem Sie die Esc-Taste drücken.
<G-vec00198-002-s069><cancel.abbrechen><en> Repeat steps 5 through 6 if you want to cancel other print jobs.
<G-vec00198-002-s069><cancel.abbrechen><de> Wiederholen Sie Schritt 5 bis 6, wenn Sie weitere Druckaufträge abbrechen möchten.
<G-vec00198-002-s070><cancel.abbrechen><en> Apply and Cancel buttons for filters were still displayed even when there were no items to select in the filter.
<G-vec00198-002-s070><cancel.abbrechen><de> Die Schaltflächen „Anwenden und Abbrechen“ für Filter wurden weiterhin angezeigt, auch wenn im Filter keine Elemente ausgewählt waren.
<G-vec00198-002-s071><cancel.abbrechen><en> Cancel: Return to the SMS interface.
<G-vec00198-002-s071><cancel.abbrechen><de> Abbrechen: Kehren Sie zurück zum SMS-Interface.
<G-vec00198-002-s072><cancel.abbrechen><en> •To cancel the washing programme in progress or a delay start in progress.
<G-vec00198-002-s072><cancel.abbrechen><de> •Zum Abbrechen des laufenden Spülprogramms oder einer laufenden Zeitvorwahl.
<G-vec00198-002-s073><cancel.abbrechen><en> Click "Issue Refund" to finish or "Cancel" to restart.
<G-vec00198-002-s073><cancel.abbrechen><de> Klicken Sie auf "Rückerstattung erteilen" (Vorgang abschließen) oder "Abbrechen" (neu versuchen).
<G-vec00198-002-s074><cancel.abbrechen><en> In case there is any problem, you can cancel the download process and reload it again.
<G-vec00198-002-s074><cancel.abbrechen><de> Falls es Probleme gibt, können Sie den Download-Vorgang abbrechen und erneut laden.
<G-vec00198-002-s075><cancel.abbrechen><en> String "Cancel" in cancel button now includes the sign-in page.
<G-vec00198-002-s075><cancel.abbrechen><de> Die Zeichenfolge „Abbrechen“ in der Taste zum Abbrechen ist nun auch auf der Anmeldeseite vorhanden.
<G-vec00198-002-s092><cancel.abbrechen><en> Players can either click the ‘Start’ button to spin the reels manually, or choose ‘Autoplay’ to leave the machine to its own devices until they either cancel the feature or run out of credits.
<G-vec00198-002-s092><cancel.abbrechen><de> Die Spieler können entweder den Knopf „Start” drücken, um die Walzen handbetätigt zu drehen, oder „Autoplay” auswählen, um die Maschine allein zu arbeiten lassen, bis das Feature abgebrochen wird oder bis es kein Spielgeld mehr gibt.
<G-vec00198-002-s093><cancel.abbrechen><en> Using Divine Shield or Blessing of Protection on yourself will cancel this effect. Adaptation Adaptation
<G-vec00198-002-s093><cancel.abbrechen><de> Wenn Ihr 'Gottesschild' oder 'Segen des Schutzes' auf Euch selbst wirkt, wird dieser Effekt abgebrochen.
<G-vec00198-002-s094><cancel.abbrechen><en> For example, the user will see the same visuals to let them know what was activated and again when they successfully cancel the activation if they change their mind.
<G-vec00198-002-s094><cancel.abbrechen><de> Beispielsweise werden dieselben visuellen Signale angezeigt, wenn ein Steuerelement aktiviert wird, um dessen Art anzugeben, und wenn die Aktivierung abgebrochen wird, falls der Benutzer es sich anders überlegt.
<G-vec00198-002-s095><cancel.abbrechen><en> When the user presses "Cancel" or closes the dialog then the drive is prepared for safe removal or it's media is ejected.
<G-vec00198-002-s095><cancel.abbrechen><de> Wenn die Passwortabfrage abgebrochen wird, wird das Laufwerk "sicher entfernt" oder dessen Datenträger ausgeworfen.
<G-vec00198-002-s096><cancel.abbrechen><en> Cancel After activating the button (during the copy process) the request "Do you really want to cancel the operation?" is shown.
<G-vec00198-002-s096><cancel.abbrechen><de> Abbruch Nach Aktivierung der Schaltfläche " " (während des Verschiebevorgangs) erscheint eine Abfrage, ob der Verschiebevorgang wirklich abgebrochen werden soll.
<G-vec00198-002-s097><cancel.abbrechen><en> From the queue window, select the job you want to cancel.
<G-vec00198-002-s097><cancel.abbrechen><de> Klicken Sie im Warteschlangenfenster auf den Druckauftrag, der abgebrochen werden soll.
<G-vec00198-002-s098><cancel.abbrechen><en> To prevent the loop of confirmation dialog boxes, select a new capture process rather than the current capture process and cancel the wizard.
<G-vec00198-002-s098><cancel.abbrechen><de> Um eine endlose Schleife der „Bestätigung“-Dialogfelder zu vermeiden, kann anstatt des aktuellen Kapselungsvorgangs ein neuer Kapselungsvorgang ausgewählt und der Assistent abgebrochen werden.
<G-vec00198-002-s099><cancel.abbrechen><en> You can cancel your subscription at any time.
<G-vec00198-002-s099><cancel.abbrechen><de> Ein Abonnement kann jederzeit abgebrochen werden.
<G-vec00198-002-s100><cancel.abbrechen><en> Press again to cancel the timer recording function.
<G-vec00198-002-s100><cancel.abbrechen><de> Durch erneutes Drücken wird die Timer-Aufzeichnung abgebrochen.
<G-vec00198-002-s101><cancel.abbrechen><en> Priest Bug Fixes Players will no longer prematurely cancel a channeled spell when clicking on the Lightwell.
<G-vec00198-002-s101><cancel.abbrechen><de> Das Kanalisieren von Zaubern wird nicht mehr vorzeitig abgebrochen, wenn ein Spieler auf den Lichtbrunnen klickt.
<G-vec00198-002-s102><cancel.abbrechen><en> If any user wants to cancel his/her ride before it is started then he/she can click on cancel ride button .
<G-vec00198-002-s102><cancel.abbrechen><de> Fahrt abgebrochen Wenn der Nutzer noch vor Antritt die Fahrt abbrechen will, kann er/sie auf den Fahrt abgebrochen Button klicken.
<G-vec00198-002-s152><cancel.abbrechen><en> Metoshop reserves the right to cancel or terminate the Contest at any time without notice and without giving reasons. 2.
<G-vec00198-002-s152><cancel.abbrechen><de> Der Veranstalter behält sich vor, das Gewinnspiel zu jedem Zeitpunkt ohne Vorankündigung und ohne Angabe von Gründen abzubrechen oder zu beenden.
<G-vec00198-002-s153><cancel.abbrechen><en> Desire to cancel one's renewal must be announced per email to info@nvrm.ch.
<G-vec00198-002-s153><cancel.abbrechen><de> Der Wunsch, die Erneuerung abzubrechen, muss per E-Mail an info@nvrm.ch bekannt gegeben werden.
<G-vec00198-002-s156><cancel.abbrechen><en> Right to Cancel: PokerStars Live, together with the organising casino in which the Event will be held, reserve the right to cancel or alter any Event or Tournament at our sole and absolute discretion.
<G-vec00198-002-s156><cancel.abbrechen><de> Recht auf Abbruch: PokerStars Live, gemeinsam mit dem veranstaltenden Casino, in dem das Event stattfindet, behält sich das Recht vor, jegliches Event oder Turnier nach unserem alleinigen und uneingeschränkten Ermessen abzubrechen oder zu ändern.
<G-vec00198-002-s157><cancel.abbrechen><en> At any point on the journey, the customer can decide to cancel and exit – for whatever reason.
<G-vec00198-002-s157><cancel.abbrechen><de> An jedem beliebigen Punkt der Journey kann sich der Kunde entscheiden, abzubrechen und auszusteigen – aus welchem Grund auch immer.
<G-vec00198-002-s158><cancel.abbrechen><en> Before submitting the order you have the opportunity to review all information again, to change - this also via the "back" function of your Internet browser - or cancel the purchase.
<G-vec00198-002-s158><cancel.abbrechen><de> Vor Absenden der Bestellung haben Sie die Möglichkeit, alle Angaben nochmals zu überprüfen, zu ändern – dies auch über die "Zurück"-Funktion Ihres Internetbrowsers – oder den Kauf abzubrechen.
<G-vec00198-002-s159><cancel.abbrechen><en> A perfect argument to cancel all debate: those who criticize do it only because they don’t do anything and are afraid.
<G-vec00198-002-s159><cancel.abbrechen><de> Ein perfektes Argument um jede Debatte abzubrechen: Diejenigen, die kritisieren, tun es nur, weil sie nichts tun und Angst haben.
<G-vec00198-002-s160><cancel.abbrechen><en> highheelscrush.com is entitled at its sole discretion to cancel the campaign; the participants agree that they shall not be entitled to any compensation in case of cancellation.
<G-vec00198-002-s160><cancel.abbrechen><de> EroDolls.com ist dazu berechtigt, nach eigenem Ermessen die Kampagne abzubrechen und die Teilnehmer erklären sich damit einverstanden, dass sie im Falle eines Abbruchs der Kampagne kein Anrecht auf Schadenersatz haben.
<G-vec00198-002-s161><cancel.abbrechen><en> smutcam.com is entitled at its sole discretion to cancel the campaign; the participants agree that they shall not be entitled to any compensation in case of cancellation.
<G-vec00198-002-s161><cancel.abbrechen><de> smutcam.com ist dazu berechtigt, nach eigenem Ermessen die Kampagne abzubrechen und die Teilnehmer erklären sich damit einverstanden, dass sie im Falle eines Abbruchs der Kampagne kein Anrecht auf Schadenersatz haben.
<G-vec00198-002-s162><cancel.abbrechen><en> Toluna reserves the right to cancel, suspend and/or modify the sweepstakes if fraud, technical failures or any other factors beyond the reasonable control of Toluna may impair the integrity of the sweepstakes.
<G-vec00198-002-s162><cancel.abbrechen><de> Toluna behält sich das Recht vor, die Verlosungen abzubrechen, zeitweise auszusetzen und/oder zu ändern, wenn Betrug, technische Fehler oder andere Faktoren, die jenseits der Kontrolle von Toluna liegen, die Integrität der Verlosungen beeinträchtigen könnten.
<G-vec00198-002-s163><cancel.abbrechen><en> To cancel the sending of an active registration confirmation (in Sending status), select the registration confirmation from the list and then click Cancel.
<G-vec00198-002-s163><cancel.abbrechen><de> Um den Versand einer aktiven Anmeldebestätigung (im Status Senden) abzubrechen, wählen Sie diese in der Liste aus und klicken Sie anschließend auf Abbrechen.
<G-vec00198-002-s164><cancel.abbrechen><en> To pause or cancel transcoding, use the corresponding buttons in the progress bar.
<G-vec00198-002-s164><cancel.abbrechen><de> Um die Codierung anzuhalten oder abzubrechen, klicken Sie auf die entsprechenden Schaltflächen in der Fortschrittsleiste.
<G-vec00198-002-s165><cancel.abbrechen><en> Post comment Click here to cancel reply.
<G-vec00198-002-s165><cancel.abbrechen><de> Hinterlasse ein Kommentar Klicke hier um den Kommentar abzubrechen.
<G-vec00198-002-s166><cancel.abbrechen><en> To cancel this registration, simply hit the 'back' button on your browser
<G-vec00198-002-s166><cancel.abbrechen><de> Um diese Registration abzubrechen, klick bitte einfach auf den "Zurück" Button deines Browsers.
<G-vec00198-002-s167><cancel.abbrechen><en> Leave a Comment Click here to cancel reply.
<G-vec00198-002-s167><cancel.abbrechen><de> Hier klicken, um die Antwort abzubrechen.
<G-vec00198-002-s168><cancel.abbrechen><en> To cancel a print job in progress, select the desired job in the Name list and click Delete.
<G-vec00198-002-s168><cancel.abbrechen><de> Um einen aktuellen Druckauftrag abzubrechen, wählen Sie den gewünschten Auftrag in der Liste Name aus, und klicken Sie anschließend auf Löschen (Delete).
<G-vec00198-002-s169><cancel.abbrechen><en> In order to stop or cancel communication, you should use eject in Mac system and in Windows use Safe remove option that is located at right most corner of the taskbar.
<G-vec00198-002-s169><cancel.abbrechen><de> Um die Kommunikation zu stoppen oder abzubrechen, sollten Sie im Mac-System auswerfen und in Windows die Option zum sicheren Entfernen verwenden, die sich in der rechten Ecke der Taskleiste befindet.
<G-vec00198-002-s170><cancel.abbrechen><en> To cancel all tasks that are scheduled on the local computer, type at /delete, and then press ENTER.
<G-vec00198-002-s170><cancel.abbrechen><de> Um alle Vorgänge abzubrechen, die auf dem lokalen Computer geplant sind, geben Sie at/deleteund drücken Sie die EINGABETASTE.
<G-vec00198-002-s172><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s172><cancel.abbrechen><de> Einen Kommentar hinterlassen Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s174><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s174><cancel.abbrechen><de> Schreibe einen Kommentar Hier klicken, um die Antwort abzubrechen.
<G-vec00198-002-s175><cancel.abbrechen><en> Leave a Reply Click here to cancel reply
<G-vec00198-002-s175><cancel.abbrechen><de> Leave a Reply Hier klicken, um die Antwort abzubrechen.
<G-vec00198-002-s176><cancel.abbrechen><en> Leave your thought Click here to cancel the reply
<G-vec00198-002-s176><cancel.abbrechen><de> Comments Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s177><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s177><cancel.abbrechen><de> Hinterlasse eine Antwort Hier klicken, um das Kommentieren abzubrechen.
<G-vec00198-002-s178><cancel.abbrechen><en> 777 reserves the right to cancel this promotion at any time and without prior notice
<G-vec00198-002-s178><cancel.abbrechen><de> 777 behält sich das Recht vor, diese Aktion jederzeit ohne vorherige Ankündigung abzubrechen.
<G-vec00198-002-s179><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s179><cancel.abbrechen><de> Online: Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s180><cancel.abbrechen><en> Leave a reply Click here to cancel the reply
<G-vec00198-002-s180><cancel.abbrechen><de> Schreibe einen Kommentar Hier klicken, um das Kommentieren abzubrechen.
<G-vec00198-002-s181><cancel.abbrechen><en> Leave Comment Click here to cancel the reply
<G-vec00198-002-s181><cancel.abbrechen><de> Leave a Comment Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s182><cancel.abbrechen><en> Comment Leave a reply Click here to cancel the reply
<G-vec00198-002-s182><cancel.abbrechen><de> Hinterlasse einen Kommentar Hier klicken, um das Antworten abzubrechen.
<G-vec00198-002-s122><cancel.absagen><en> Should a teacher cancel for whatever reason, the event organizer reserves the right to find a replacement teacher.
<G-vec00198-002-s122><cancel.absagen><de> Der Veranstalter behält sich das Recht vor, bei Absage eines Trainers aus welchem Grund auch immer einen Ersatz zu organisieren.
<G-vec00198-002-s123><cancel.absagen><en> If I get sick and have to cancel, then even more people are disappointed.
<G-vec00198-002-s123><cancel.absagen><de> Wenn ich krank werde und absage, dann sind noch viel mehr Leute enttäuscht.
<G-vec00198-002-s124><cancel.absagen><en> - If you cancel your confirmed booking, the Caparra payment is always retained as a cancellation fee.
<G-vec00198-002-s124><cancel.absagen><de> - Bei Absage einer festen Buchung wird die Caparra-Zahlung immer als Stornogebühr rückbehalten.
<G-vec00198-002-s125><cancel.absagen><en> ■ When you cancel during the last week before you arrive we will invoice you 90 % of the cost of your booking, on early departure 100%.
<G-vec00198-002-s125><cancel.absagen><de> ■ Bei einer Absage innerhalb der letzten Woche vor Anreise stellen wir Ihnen 90% des Reisepreises in Rechnung, bei vorzeitiger Abreise 100%.
<G-vec00198-002-s126><cancel.absagen><en> We reserve the right to cancel at short notice in the event of insufficient participants.
<G-vec00198-002-s126><cancel.absagen><de> Wir behalten uns eine kurzfristige Absage bei zu geringer Teilnehmerzahl vor.
<G-vec00198-002-s127><cancel.absagen><en> If you have any questions regarding how to use "Last Minute Cancel," go to "FAQs Related To This Card" for clarification on its usage.
<G-vec00198-002-s127><cancel.absagen><de> Wenn Sie Fragen zur Verwendung von "Absage in letzter Minute" haben, gehen Sie zu "Häufig gestellte Fragen (FAQs) zu dieser Karte" zur Erläuterung der Verwendung.
<G-vec00198-002-s128><cancel.absagen><en> The Future Forum wouldn´t have the quality and vitality expected, so we have decided to cancel!
<G-vec00198-002-s128><cancel.absagen><de> Das Zukunftsforum könnte nicht in der gewohnten Qualität und Lebendigkeit stattfinden, daher haben wir uns zur Absage entschlossen.
<G-vec00198-002-s129><cancel.absagen><en> Should you cancel within the last 7 days before holiday start, or in case of non-arrival, late arrival or early departure, we will charge you the total amount for the entire stay period you booked
<G-vec00198-002-s129><cancel.absagen><de> Bei einer Absage innerhalb der letzten 7 Tage vor Urlaubsantritt, bei Nichtanreise, verspäteter Anreise oder vorzeitiger Abreise wird die Gesamtsumme für die gesamte gebuchte Zeit in Rechnung gestellt.
<G-vec00198-002-s130><cancel.absagen><en> If you cancel more than 4 weeks before the arrival date are no room charges.
<G-vec00198-002-s130><cancel.absagen><de> Bei Absage von mehr als 4 Wochen vor dem Anreisetermin fallen keine Gebühren an.
<G-vec00198-002-s131><cancel.absagen><en> We will also charge vouchers that your clients used in case you cancel your participation How to manage redeemed vouchers
<G-vec00198-002-s131><cancel.absagen><de> Von Ihren Kunden genutzte Gutscheine berechnen wir auch im Falle der Absage Ihrer Messebeteiligung.
<G-vec00198-002-s132><cancel.absagen><en> The same conditions apply if a voucher has been used to pay in advance for an appointment that you then cancel or postpone, i.e. the value of the voucher will be reduces accordingly. Meeting your needs
<G-vec00198-002-s132><cancel.absagen><de> Bei einer Absage oder Verschiebung des Termins für die eine Vorauszahlung in Form eines Gutscheines getätigt wurde, gelten dieselben Bedingungen, d.h. der Gutscheinwert wird entsprechend gemindert.
<G-vec00198-002-s133><cancel.absagen><en> You can schedule, update, cancel and start meetings directly from a contact page in Salesforce.
<G-vec00198-002-s133><cancel.absagen><de> Sie können Meetings direkt über eine Kontaktseite in Salesforce planen, aktualisieren, absagen und starten.
<G-vec00198-002-s134><cancel.absagen><en> RailAway AG may cancel the charter booking in the event of force majeure or circumstances making it impossible, very difficult or dangerous to complete the trip.
<G-vec00198-002-s134><cancel.absagen><de> Bei Vorliegen höherer Gewalt oder Umständen, welche die Durchführung verunmöglichen, erheblich erschweren oder gefährden, kann RailAway AG die Reise absagen.
<G-vec00198-002-s135><cancel.absagen><en> We had to cancel the rest of the tour.
<G-vec00198-002-s135><cancel.absagen><de> Da mussten wir den Rest der Tour absagen.
<G-vec00198-002-s136><cancel.absagen><en> If there are not enough registrations received 14 days before the start of the training, LOYTEC can cancel the training.
<G-vec00198-002-s136><cancel.absagen><de> Liegen bis 14 Tage vor Trainingsbeginn nicht genügend verbindliche Anmeldungen vor, kann LOYTEC das Training absagen.
<G-vec00198-002-s137><cancel.absagen><en> If you wish to cancel, please let us know as soon as possible because there is a fine of 300 euros for late cancellations (less than five hours before the appointment).
<G-vec00198-002-s137><cancel.absagen><de> Sollten Sie absagen wollen, bitte lassen Sie es uns baldmöglichst wissen, da es eine 300 Euro Gebühr für verspätete Absagte gibt (weniger als 5 Stunden vor dem Date).
<G-vec00198-002-s138><cancel.absagen><en> Even as researchers we are currently experiencing a change in China: although just a few years ago we looked to the future with a certain optimism as regards a growing freedom of opinion, a number of colleagues are now finding that archives are shut in their face, field research is becoming impossible, and interview partners cancel appointments out of fear.
<G-vec00198-002-s138><cancel.absagen><de> Auch als Forschende erleben wir derzeit einen Wandel in China: Während wir vor ein paar Jahren noch mit einem gewissen Optimismus in die Zukunft sahen, was eine wachsende Meinungsfreiheit angeht, so erleben eine Reihe von Kolleginnen und Kollegen nun, dass ihnen die Archive vor der Nase zugemacht werden, Feldforschung unmöglich wird und Interviewpartnerinnen und -partner aus Angst Termine absagen.
<G-vec00198-002-s139><cancel.absagen><en> If you ever need to cancel an appointment, I ask you to do so with 48 hours notice.
<G-vec00198-002-s139><cancel.absagen><de> Falls Sie einmal absagen müssen, tun Sie das bitte 48 Stunden vorher.
<G-vec00198-002-s140><cancel.absagen><en> You can cancel your reservations 7 days before the pick up date and in that case there is no cancellation fee.
<G-vec00198-002-s140><cancel.absagen><de> Sie können Ihre Reservation bis 7 Tage vor der Abgabe ohne Stormierungsgebühren absagen.
<G-vec00198-002-s141><cancel.absagen><en> Under normal circumstances, you’d cancel your girlfriend and you on a different day stall.
<G-vec00198-002-s141><cancel.absagen><de> Unter normalen Umständen würdest du deiner Freundin absagen und sie auf einen anderen Tag vertrösten.
<G-vec00198-002-s142><cancel.absagen><en> You can cancel some or all sessions in a webinar at any time.
<G-vec00198-002-s142><cancel.absagen><de> Sie können einige oder alle Sitzungen eines Webinars jederzeit absagen.
<G-vec00198-002-s143><cancel.absagen><en> Due to health reasons I had to cancel my trip to London to visit my daughter, Maya, and subsequently, Berlin.
<G-vec00198-002-s143><cancel.absagen><de> Aufgrund von Gesundheitsproblemen musste ich meine Reise nach London, wo ich meine Tochter Maya besuchen wollte, absagen und deshalb auch meine Reise nach Berlin.
<G-vec00198-002-s144><cancel.absagen><en> A week before, I’d had to cancel band practice.
<G-vec00198-002-s144><cancel.absagen><de> Eine Woche vorher musste ich die Bandprobe absagen.
<G-vec00198-002-s145><cancel.absagen><en> If the lifts are unable to run due to a storm then we have to cancel your booking.
<G-vec00198-002-s145><cancel.absagen><de> Können die Bergbahnen ihren Betrieb wegen Sturm definitiv nicht aufrechterhalten, müssen wir die Übernachtung absagen.
<G-vec00198-002-s146><cancel.absagen><en> Now aged 93, and on the advice of his Master, he regrets that he has to cancel his overseas tours for the time being.
<G-vec00198-002-s146><cancel.absagen><de> Daher muss er auf Anraten seines Meisters seine Auslandsreisen absagen.
<G-vec00198-002-s147><cancel.absagen><en> If a class does not have the minimum number of participants required, our institution may reduce the number of lessons per week or cancel the course all together.
<G-vec00198-002-s147><cancel.absagen><de> Wird die Mindestteilnehmerzahl des Gruppenkurses unterschritten, darf unser Institut wegen der erhöhten Effektivität des Kurses die Wochenstundenzahl reduzieren oder den betreffenden Kurs insgesamt absagen.
<G-vec00198-002-s148><cancel.absagen><en> Cancel events You can cancel an event that you previously created and send participants an email informing them about the cancelation.
<G-vec00198-002-s148><cancel.absagen><de> Absagen von Veranstaltungen Sie können eine zuvor erstellte Veranstaltung absagen und den Teilnehmern eine E-Mail-Benachrichtigung über die Absage senden.
<G-vec00198-002-s150><cancel.absagen><en> If you cancel before 7 days, we’ll return the deposit.
<G-vec00198-002-s150><cancel.absagen><de> Wenn Sie vor 7 Tagen absagen, erhalten Sie die Kaution zurück.
<G-vec00198-002-s151><cancel.absagen><en> Crossing over to the British Isles, the bad weather has been a problem for several festivals - the sadest affair was the Continental Ceilidh in Scotland, that suffered that much that the organisers had to cancel some concerts.
<G-vec00198-002-s151><cancel.absagen><de> Die Festivals der britischen Inseln wurden vom schlechten Wetter stark beeinträchtigt - die traurigste Angelegenheit dort wurde die Continental Ceilidh in Schottland, bei der das Wetter und die niedrigen Besucherzahlen zu Absagen von Konzerten führen musste.
<G-vec00198-002-s183><cancel.absagen><en> Due to the situation caused by the typhoon, it was considered in advance to cancel at short notice the event.
<G-vec00198-002-s183><cancel.absagen><de> Aufgrund der durch den Taifun verursachten Lage war im Vorfeld überlegt worden, die Veranstaltung kurzfristig noch abzusagen.
<G-vec00198-002-s184><cancel.absagen><en> After a long and intense night with the public opinion and despite the fact that there is nothing unlawful going on, as connfirmed to the RMV by the offce of public order, the police and the Federal Offce for the Protection of the Constitution, we are forced to cancel the appearance of Peste Noire because of the public’s demand.
<G-vec00198-002-s184><cancel.absagen><de> Nach sehr langem und intensivem Ringen mit der öffentlichen Meinung und trotz der rechtlichen Unbedenklichkeit, die dem RMV von Ordnungsamt, Polizei und dem Verfassungsschutz bestätigt wurde, wurden wir gezwungen den Auftritt von PESTE NOIRE abzusagen.
<G-vec00198-002-s185><cancel.absagen><en> We reserve the right to cancel the course at short notice if there are not enough participants registered.
<G-vec00198-002-s185><cancel.absagen><de> Wir behalten uns vor den Kurs kurzfristig abzusagen, sollten sich nicht genügend Teilnehmer anmelden.
<G-vec00198-002-s186><cancel.absagen><en> To prevent the spread of this highly contagious infectious disease we are forced to cancel the June show.
<G-vec00198-002-s186><cancel.absagen><de> Um eine Verbreitung dieser sehr ansteckenden Infektionskrankheit zu vermeiden sehen wir uns gezwungen, die June Show abzusagen.
<G-vec00198-002-s187><cancel.absagen><en> Should this minimum not be reached up to 4 weeks before the start of the workshop, we reserve the right to cancel the course.
<G-vec00198-002-s187><cancel.absagen><de> Sollte diese bis 4 Wochen vor Beginn des Kurses nicht erreicht sein, behalten wir uns vor, den Kurs abzusagen.
<G-vec00198-002-s188><cancel.absagen><en> Scheduling this time with family in advance will make it hard to cancel at the last minute and helps set that time in stone.
<G-vec00198-002-s188><cancel.absagen><de> Zeiträume für Familie im Voraus festzulegen wird es schwer machen, in letzter Minute abzusagen und hilft dabei, diese Zeit felsenfest zu bestimmen.
<G-vec00198-002-s189><cancel.absagen><en> The Parents Association reserves the right to cancel a course should this number not be achieved.
<G-vec00198-002-s189><cancel.absagen><de> Die Elternvereinigung behält sich das Recht vor, einen Kurs deswegen abzusagen.
<G-vec00198-002-s190><cancel.absagen><en> We would therefore ask that in the event of any inability to attend that you cancel at least 6 hours beforehand.
<G-vec00198-002-s190><cancel.absagen><de> Wir bitten Sie daher, Termine im Falle einer Verhinderung mindestens 6 Stunden vorher abzusagen.
<G-vec00198-002-s191><cancel.absagen><en> The company reserves the right to amend or cancel the tour depending on weather conditions.
<G-vec00198-002-s191><cancel.absagen><de> Der Anbieter hält sich das Recht vor, die Tour je nach Wetterbedingungen zu ändern oder abzusagen.
<G-vec00198-002-s192><cancel.absagen><en> The organizer has the right to cancel an event due to low number of exhibitors.
<G-vec00198-002-s192><cancel.absagen><de> Der Veranstalter hat das Recht eine Veranstaltung aufgrund zu geringer Ausstellerbeteiligung abzusagen.
<G-vec00198-002-s193><cancel.absagen><en> Allegedly Hitler threatened to cancel the Olympic Games.
<G-vec00198-002-s193><cancel.absagen><de> Angeblich drohte Hitler, die Olympischen Spiele abzusagen.
<G-vec00198-002-s194><cancel.absagen><en> Cosa Travel is entitled to cancel your trip if you give justified reason through acts or omissions.
<G-vec00198-002-s194><cancel.absagen><de> Cosa Travel ist berechtigt, Ihre Reise abzusagen, wenn Sie durch Handlungen oder Unterlassungen dazu berechtigten Anlass geben.
<G-vec00198-002-s195><cancel.absagen><en> Since the respondent had requested oral proceedings only in case a decision to dismiss the appeal could not be made having regard to the written submissions of the parties, the board would then have been able to cancel the oral proceedings.
<G-vec00198-002-s195><cancel.absagen><de> Da der Beschwerdegegner eine mündliche Verhandlung nur für den Fall beantragt hatte, daß die Beschwerde nicht aufgrund der Schriftsätze der Beteiligten zurückgewiesen werden könne, wäre die Kammer dann in der Lage gewesen, die mündliche Verhandlung abzusagen.
<G-vec00198-002-s196><cancel.absagen><en> > INTERSPIRO reserves the right to cancel seminars which are not occupied or seminars for important reasons.
<G-vec00198-002-s196><cancel.absagen><de> > INTERSPIRO behält sich das Recht vor nicht besetzte Seminare oder Seminare aus wichtigem Grunde abzusagen.
<G-vec00198-002-s197><cancel.absagen><en> In the event that one or more participants do not comply with the above mentioned requirements, the guide - for safety reasons - reserves the right to cancel or interrupt the tour at any time.
<G-vec00198-002-s197><cancel.absagen><de> Im Falle, dass einer oder mehrere Teilnehmer die oben genannten Anforderungen nicht erfüllen, behält sich der Führer aus Sicherheitsgründen das Recht vor, die Tour jederzeit abzusagen oder zu unterbrechen.
<G-vec00198-002-s198><cancel.absagen><en> Should this price increase exceed the10% threshold than the customer has the right to cancel the tour/event without any obligation to pay a cancellation charge, provided this is done in writing and within 8 days after our price increase announcement.
<G-vec00198-002-s198><cancel.absagen><de> Sollte eine derartige Preiserhöhung 10% übersteigen, ist der Kunde berechtigt, die Reise/Veranstaltung abzusagen, ohne dass ihm dafür eine Stornierungsgebühr entsteht, vorausgesetzt, die Absage erfolgt schriftlich und geht innerhalb von 8 Tagen nachdem wir die Preiserhöhung bekanntgegeben haben bei uns ein.
<G-vec00198-002-s199><cancel.absagen><en> Taking into account our right to deny you the Profile verification and/or to cancel it in case of detection of any discrepancies and also with due regard for our notifications of all the corresponding dates, the actuality of your account status some time after the expiration of your Profile verification is the subject of reasonable concern for you and your counterparties.
<G-vec00198-002-s199><cancel.absagen><de> Unter Berücksichtigung des Rechts Ihnen die Profilprüfung zu verweigern und/oder diese im Falle von Nichtübereinstimmungen abzusagen, sowie unter Berücksichtigung der Veröffentlichung von uns aller entsprechenden Daten, stellt sich die Aktualität des Zustands der Glaubwürdigkeit Ihres Benutzerkontos nach Ablauf einiger Zeit nach der Profilprüfung — als Gegenstand zur angemessenen Sorge für Sie und Ihre Partner dar.
<G-vec00198-002-s200><cancel.absagen><en> It was not easy for us to cancel the exhibition, but the health and protection of our employees, customers, suppliers and their families is our top priority and is very close to our hearts.
<G-vec00198-002-s200><cancel.absagen><de> Es fiel uns nicht leicht, die Messe abzusagen, doch die Gesundheit und der Schutz unserer Mitarbeiter, Kunden, Lieferanten und deren Angehörigen hat oberste Priorität und liegt uns sehr am Herzen.
<G-vec00198-002-s201><cancel.absagen><en> We kindly ask everyone expecting visitors from risk areas to cancel those stays.
<G-vec00198-002-s201><cancel.absagen><de> Wir bitten alle, die Besucher*innen aus Risikogebieten erwarten, den Gastaufenthalt abzusagen.
<G-vec00198-002-s202><cancel.annullieren><en> After this period, we have the right, at our discretion, to deliver the goods or to cancel the order and to demand a cancellation fee of 15% of the gross order value, which is not subject to the judicial reduction.
<G-vec00198-002-s202><cancel.annullieren><de> Nach Ablauf dieser Frist steht uns das Recht zu, nach unserer Wahl die Ware zu liefern, oder den Auftrag zu annullieren und eine dem richterlichen Mäßigungsrecht nicht unterliegende Stornogebühr in Höhe von 15 % des Bruttoauftragswert zu fordern.
<G-vec00198-002-s203><cancel.annullieren><en> On the rare occasions when Art of Bicycle Trips must cancel a trip, all tour payments received to date will be refunded, which constitutes full settlement.
<G-vec00198-002-s203><cancel.annullieren><de> Sollte der seltene Fall eintreffen, dass ABT eine Reise annullieren muss, erhalten alle Teilnehmer, die getätigten Zahlungen vollständig zurückerstattet.
<G-vec00198-002-s204><cancel.annullieren><en> They achieve success because they become a bit like Galgalta ve Eynaim and cancel their AHP.
<G-vec00198-002-s204><cancel.annullieren><de> Sie haben Erfolg da sie ein kleines Stück von Galgalta ve Eynaim erhalten und ihre AHaP annullieren.
<G-vec00198-002-s205><cancel.annullieren><en> Default will cancel all changes in the settings.
<G-vec00198-002-s205><cancel.annullieren><de> Default wird alle Änderungen in den Einstellungen annullieren.
<G-vec00198-002-s206><cancel.annullieren><en> You can cancel your group visit up to seven days before the planned date.
<G-vec00198-002-s206><cancel.annullieren><de> Sie können Ihren Besuch bis zu sieben Tage vor dem geplanten Datum annullieren.
<G-vec00198-002-s207><cancel.annullieren><en> The Hotel reserves the right to cancel bookings made on a declined credit card.
<G-vec00198-002-s207><cancel.annullieren><de> Das Hotel behält sich das Recht vor, Reservierungen, die mit einer abgelehnten Kreditkarte erfolgten, zu annullieren.
<G-vec00198-002-s208><cancel.annullieren><en> If clauses 171 or 172 are breached, Stakers reserves the right to close the said Account immediately and to cancel payment on any gain.
<G-vec00198-002-s208><cancel.annullieren><de> Falls die Abschnitte 171 und 172 verstoßen werden, behält sich Stakers das Recht vor, das Konto sofort zu schließen und die Zahlungen bei jedem Gewinn zu annullieren.
<G-vec00198-002-s209><cancel.annullieren><en> You are entitled to access information concerning you, rectify it were it to be erroneous, cancel it or object to its being processed via the provided email.
<G-vec00198-002-s209><cancel.annullieren><de> Sie haben das Recht, mittels der erwähnten Email Adresse, auf Ihre Daten zuzugreifen, diese bei Fehlern zu korrigieren, zu annullieren oder sich deren Verarbeitung zu widersetzen.
<G-vec00198-002-s210><cancel.annullieren><en> Should it be impossible to contact the Buyer due to the provision of false, incorrect or inaccurate data, and despite the Seller’s attempts to determine the data, the Seller shall be entitled to cancel the Order.
<G-vec00198-002-s210><cancel.annullieren><de> Sollte die Kontaktaufnahme mit dem Käufer wegen der Angabe unechter, falscher oder ungenauer Daten nicht möglich sein, ist der Verkäufer berechtigt, die Bestellung zu annullieren.
<G-vec00198-002-s211><cancel.annullieren><en> You may turn off the auto-renewal of subscriptions through your Account Settings, however you are not able to cancel the current subscription during its active period.
<G-vec00198-002-s211><cancel.annullieren><de> Sie können die Automobilerneuerung von Subskriptionen durch Ihre Account Einstellungen abstellen, gleichwohl Sie nicht in der Lage sind, die gegenwärtige Subskription während seiner aktiven Periode zu annullieren.
<G-vec00198-002-s212><cancel.annullieren><en> In the event of nonacceptance of the alternative on behalf of the customer or cancellation on behalf of the Sardinia Agency of the contract for force majeure causes (war, natural disasters, impracticability of housing for fires or serious motivations), the Sardinia Agency can cancel the contract while refunding the sum paid at the moment of cancellation, without the customer being able to ask for later requests of compensation.
<G-vec00198-002-s212><cancel.annullieren><de> Bei nicht Annahme der Alternative seitens des Kunden oder der Annullierung seitens der Agentur Sardinia des Vertrags für Ursachen mit höherer Gewalt (Krieg, Naturkatastrophen, Unausführbarkeit der Wohnung für Feuer oder ernste Motivierungen), kann die Sardinia Agentur den Vertrag annullieren, indem sie die Summe bewandert am Moment der Annullierung zurückgibt, ohne daß der Kunde spätere Entschädigungsanträge verlangen kann.
<G-vec00198-002-s213><cancel.annullieren><en> The client can request the cancellation of the payment or can cancel it from their own PayPal account.
<G-vec00198-002-s213><cancel.annullieren><de> Der Kunde kann die Stornierung des Einzugsvertrages verlangen oder ihn von seinem PayPal-Konto annullieren.
<G-vec00198-002-s214><cancel.annullieren><en> We reserve the right to amend or cancel this promotion, at any time and without notice, if we have reason to believe that is being abused or is not able to run as planned.
<G-vec00198-002-s214><cancel.annullieren><de> Wir behalten das Recht vor, eine Eintragung aus der Promotion auszuschließen, die Promotion zu ändern oder zu annullieren, wenn wir die Meinung haben, dass die Promotion missbraucht wird oder nicht nach Plan läuft.
<G-vec00198-002-s215><cancel.annullieren><en> When the souls unite within Malchut and are willing to cancel themselves in order to merge into one point in relation to Yesod, which is also one point – one against another, then we can receive the Light of Correction and the Light of Fulfillment from Yesod.
<G-vec00198-002-s215><cancel.annullieren><de> Wenn sich die Seelen innerhalb Malchuts vereinigen und bereit sind, sich zu annullieren, um zu einem Punkt in Bezug auf Jessod zu verschmelzen, einer gegenüber dem andern, dann können wir das Licht der Korrektur und das Licht der Erfüllung von Jessod empfangen.
<G-vec00198-002-s216><cancel.annullieren><en> Having confirmed the registration, All About Football reserves the right to cancel the event if the respective minimum number of participants required for the implementation of events is not reached.
<G-vec00198-002-s216><cancel.annullieren><de> Nach erfolgter Buchungsbestätigung behält sich "All About Football" das Recht vor, die Veranstaltung zu annullieren, wenn die jeweiligen Mindestteilnehmerzahlen der Veranstaltungen nicht erreicht werden.
<G-vec00198-002-s217><cancel.annullieren><en> If you have guaranteed your room reservation with a credit card, but wish to cancel, we would ask you to do so by 14:00 (2pm) on the day of arrival stated in the booking.
<G-vec00198-002-s217><cancel.annullieren><de> Wenn Sie Ihre Reservierung mittels Kreditkarte garantiert haben und die reservierte Leistung nicht beziehen können/wollen, bitten wir Sie, die Reservierung bis spätestens 24 Uhr vor dem Ankunftstag zu annullieren.
<G-vec00198-002-s218><cancel.annullieren><en> Any bookmaker can cancel such a bet based on their rules.
<G-vec00198-002-s218><cancel.annullieren><de> Jedes Wettbüro darf nach seinen eigenen Regeln einen solchen Wetteinsatz annullieren.
<G-vec00198-002-s219><cancel.annullieren><en> After the payment deadline WGSH has - after an initial call - the right to cancel the order of your choice or 1% interest per month plus EUR 25,00 to calculate dunning charge.
<G-vec00198-002-s219><cancel.annullieren><de> Nach Ablauf der Zahlungsfrist ist WGSH - nach einmaliger Mahnung - berechtigt, nach Wahl die Bestellung zu annullieren oder 1% Verzugszinsen pro Monat zuzüglich EUR 25,-- Mahngebühr zu berechnen.
<G-vec00198-002-s220><cancel.annullieren><en> If you want to, you can also cancel this queued refund, by clicking on "Cancel".
<G-vec00198-002-s220><cancel.annullieren><de> Wenn Sie möchten, können Sie die Rückerstattung auch annullieren, indem Sie auf "Abbrechen" klicken.
<G-vec00198-002-s221><cancel.annullieren><en> The spiritual world can become revealed to us practically only on the condition that we entirely cancel our egoism according to the level of our current degree.
<G-vec00198-002-s221><cancel.annullieren><de> Die spirituelle Welt kann sich in uns praktisch nur unter der Bedingung enthüllen, dass wir unseren Egoismus entsprechend der Höhe unserer momentanen Stufe vollkommen annulliert haben.
<G-vec00198-002-s222><cancel.annullieren><en> If the Customer does not wish to disclose these documents, he/she may cancel his/her order without charge.
<G-vec00198-002-s222><cancel.annullieren><de> Wenn der Kunde damit nicht einverstanden ist, kann die Bestellung (ohne zusätzliche Gebühren) annulliert werden.
<G-vec00198-002-s223><cancel.annullieren><en> It details how to cancel the account, and whether bandwidth is limited or not.
<G-vec00198-002-s223><cancel.annullieren><de> Es Details, wie man das Konto annulliert und ob bandwith oder nicht begrenzt ist.
<G-vec00198-002-s224><cancel.annullieren><en> Once an Order is triggered, you may not cancel or amend the Order unless we expressly agree to such cancellation or amendment.
<G-vec00198-002-s224><cancel.annullieren><de> Sobald eine Order ausgelöst ist kann diese von Ihnen nicht annulliert oder modifiziert werden, es sei denn, dass wir ausdrücklich der Annullierung oder Modifizierung zugestimmt haben.
<G-vec00198-002-s225><cancel.annullieren><en> If, following a notification from a parent, guardian or discovery by other means, a child under sixteen has been improperly registered on our site by using false information; we will cancel the child’s account and delete the child’s personal information from our records.
<G-vec00198-002-s225><cancel.annullieren><de> Sofern Eltern oder ein gesetzlicher Vertreter darüber informiert werden oder auf andere Art Kenntnis davon erhalten, dass ein Kind unter 16 Jahren mithilfe falscher Angaben irrtümlicherweise auf dieser Website registriert wurde, wird das Konto des Kindes annulliert und die persönlichen Daten des Kindes werden aus unserem System gelöscht.
<G-vec00198-002-s226><cancel.annullieren><en> 7 Automatic Reset Functions: after you swap the card, during the specific time (the system is 10s), if you didn’t pass the turnstile, the system will cancel your authority automatically to pass the gate, (reset time is 1~60s you can adjust it what time is suit for you).
<G-vec00198-002-s226><cancel.annullieren><de> 7 Funktionen des automatischen Zurücksetzens: nachdem Sie die Karte austauschen, während des spezifischen Zeitpunktes (das System ist 10s), wenn Sie nicht das Drehkreuz führten, annulliert das System Ihre Berechtigung automatisch, um das Tor zu führen, (Zurückstellenzeit ist 1~60s, das Sie es justieren können, wann Klage für Sie ist).
<G-vec00198-002-s227><cancel.annullieren><en> If the reserved pitch plus will not be occupied by the client on the day of arrival or at the latest on the following day before 12 o’clock, the contract will be cancel automatically and the total down payment will be withheld if the client doesn’t inform us before in written form.
<G-vec00198-002-s227><cancel.annullieren><de> Sollte der gebuchte Stellplatz durch den Kunden am Anreisetag oder am Tag darauf bis spätestens 12:00 Uhr nicht belegt werden, wird der Vertrag automatisch annulliert und die gesamte Anzahlung einbehalten wenn keine vorherige schriftliche Informierung von Seiten des Kunden erfolgt.
<G-vec00198-002-s228><cancel.annullieren><en> Should the other party terminate or cancel the agreement, it shall owe the user a payment, to be determined by the latter.
<G-vec00198-002-s228><cancel.annullieren><de> Wenn die Gegenpartei den Vertrag kündigt oder annulliert, ist sie dem Benutzer eine von diesem näher zu bestimmende Vergütung schuldig.
<G-vec00198-002-s229><cancel.annullieren><en> You can modify the number of commanded products or cancel the order of a product there.
<G-vec00198-002-s229><cancel.annullieren><de> Ausserdem, kann die Anzahl der bestellten Produkte modifiziert oder Annulliert werden.
<G-vec00198-002-s230><cancel.annullieren><en> If this happens, the chief polling officer will take the unfolded ballot, immediately cancel and destroy it, and invite the voter to vote again.
<G-vec00198-002-s230><cancel.annullieren><de> Tut er es doch, nimmt der Vorsitzende den auseinandergefalteten Zettel entgegen, annulliert und zerstört ihn und fordert den Wähler auf, erneut zu wählen.
<G-vec00198-002-s231><cancel.annullieren><en> turnstile will cancel this passing right.
<G-vec00198-002-s231><cancel.annullieren><de> Drehkreuz annulliert dieses überschreitene Recht.
<G-vec00198-002-s232><cancel.annullieren><en> If you wish to cancel the option you have selected, press the key again. (The pilot light will go off).
<G-vec00198-002-s232><cancel.annullieren><de> Eine einmal gewählte Option kann annulliert werden, indem die Taste erneut gedrückt wird (die Anzeigeleuchte erlischt dann).
<G-vec00198-002-s233><cancel.aufheben><en> When using the count in live blackjack play the player simply eliminates pairs of cards that offset or cancel one another.
<G-vec00198-002-s233><cancel.aufheben><de> Bei der Anwendung in einem Live-Blackjackspiel, eliminiert der Spieler ganz einfach die Kartenpaare, die sich gegenseitig aufheben.
<G-vec00198-002-s234><cancel.aufheben><en> While dragging, you can cancel the selection by clicking the right button before releasing the middle or left mouse button.
<G-vec00198-002-s234><cancel.aufheben><de> Beim Ziehen der Maus können Sie die Auswahl aufheben, indem Sie vor dem Loslassen der mittleren oder linken Maustaste mit der rechten Maustaste klicken.
<G-vec00198-002-s235><cancel.aufheben><en> Beyond the ridiculous thing of formality (two articles of the same bill to cancel one another) it is also a practical matter.
<G-vec00198-002-s235><cancel.aufheben><de> Jenseits der lächerlichen Sache der Formalität (zwei Artikel der gleichen Rechnung, die sich gegenseitig aufheben) ist es auch eine praktische Angelegenheit.
<G-vec00198-002-s236><cancel.aufheben><en> Train yourself to recognize cards that cancel each other, for instance: a negative card cancels out a positive.
<G-vec00198-002-s236><cancel.aufheben><de> Üben Sie sich darin, Karten zu erkennen, die einander aufheben, wie zum Beispiel: eine negative Karte hebt eine positive Karte auf.
<G-vec00198-002-s237><cancel.aufheben><en> Only eventconcepts GmbH establishes or is advised by others that a concrete offer, to which it has provided a link, causes a civil or criminal liability, shall it cancel the reference to this offer as far as this is technically possible and reasonable therefor.
<G-vec00198-002-s237><cancel.aufheben><de> Erst wenn die eventconcepts GmbH feststellt oder von anderen darauf hingewiesen wird, dass ein konkretes Angebot, zu dem sie einen Link bereitgestellt hat, eine zivil- oder strafrechtliche Verantwortlichkeit auslöst, wird sie den Verweis auf dieses Angebot aufheben, soweit ihr dies technisch möglich und zumutbar ist.
<G-vec00198-002-s238><cancel.aufheben><en> The right to make public ends when you remove a content from a particular service or cancel the provision of public access.
<G-vec00198-002-s238><cancel.aufheben><de> Das Recht der öffentlichen Zugänglichmachung endet mit dem Zeitpunkt, in dem Sie einen eingestellten Inhalt aus einem bestimmten Dienst entfernen oder die Bestimmung der öffentlichen Zugänglichmachung aufheben.
<G-vec00198-002-s239><cancel.aufheben><en> If Michael Bauer International notices or is informed about that an explicit offer where CMichael Bauer International has referred to may cause a liability after civil or penal law, CONIAS Risk Intelligence will cancel the link to that offer or service.
<G-vec00198-002-s239><cancel.aufheben><de> Wenn die Michael Bauer International GmbH feststellt oder von anderen darauf hingewiesen wird, dass ein konkretes Angebot, zu dem Michael Bauer International GmbH einen Link bereitgestellt hat, eine zivil- oder strafrechtliche Verantwortlichkeit auslöst, wird Michael Bauer International GmbH den Verweis aud diese Angebot aufheben.
<G-vec00198-002-s240><cancel.aufheben><en> Spellbook Studio may, in its sole discretion, cease to provide any or all of the services offered in connection with Spellbook (including access to the System and any or all features or components of the Website), terminate the ToS, close all Accounts and cancel all of the rights granted to you under the ToS.
<G-vec00198-002-s240><cancel.aufheben><de> Eaton kann nach eigenem Ermessen die Bereitstellung von jeglichen oder allen Diensten in Verbindung mit dem Smart Home Controller einstellen (einschließlich des Fernzugriffs auf das System und einigen oder allen Funktionen oder Komponenten der Software), den EULA kündigen oder alle Rechte aus diesem EULA aufheben.
<G-vec00198-002-s241><cancel.aufheben><en> After saying that the "deviations" from value, which are found in the prices of production, cancel each other, he adds the remark that "in capitalist production as a whole the general law maintains itself as the governing tendency, for the most part only in a very complex and approximate manner as the constantly changing average of perpetual fluctuations."
<G-vec00198-002-s241><cancel.aufheben><de> Nachdem er davon gesprochen hat, daß "die Abweichungen vom Werte, die in den Produktionspreisen stecken, sich gegeneinander aufheben", fügt er nämlich die Bemerkung an, daß das allgemeine Gesetz sich bei der ganzen kapitalistischen Produktion "überhaupt immer nur in einer sehr verwickelten und annähernden Weise, als ein festzustellender Durchschnitt ewiger Schwankungen, als die beherrschende Tendenz durchsetzt".
<G-vec00198-002-s242><cancel.aufheben><en> In a well-balanced, stable trace environment, the induced currents should cancel each other out to eliminate crosstalk.
<G-vec00198-002-s242><cancel.aufheben><de> In einer ausgeglichenen, stabilen Spurumgebung sollten sich die induzierten Ströme gegenseitig aufheben, um ein Übersprechen zu vermeiden.
<G-vec00198-002-s243><cancel.aufheben><en> The counter-mass forces of a balancing unit is opposite to the first beam deflector in an oscillating and / or moved linearly, so that the forces and torques resulting from the movement of the first beam deflector and the counterweight cancel each other out as far as possible.
<G-vec00198-002-s243><cancel.aufheben><de> Dabei wird die Gegenmasse einer Kräfteausgleichseinheit entgegengesetzt zum ersten Strahlumlenker oszillierend und/oder linear bewegt, so dass die bei der Bewegung des ersten Strahlumlenkers und der Gegenmasse entstehenden Kräfte und Drehmomente sich nach Möglichkeit gegenseitig aufheben.
<G-vec00198-002-s244><cancel.aufheben><en> The emitted noise is abated by a series of passages and chambers lined with roving fiberglass insulation and/or resonating chambers harmonically tuned to cause destructive interference, wherein opposite sound waves cancel each other out.
<G-vec00198-002-s244><cancel.aufheben><de> Das abgestrahlte Geräusch wird durch eine Reihe von Durchgängen und Kammern, die mit umlaufender Glasfaserisolierung und / oder Resonanzkammern ausgekleidet sind, die harmonisch abgestimmt sind, um eine destruktive Interferenz zu bewirken, wobei sich entgegengesetzte Schallwellen gegenseitig aufheben, ausgekleidet .
<G-vec00198-002-s245><cancel.aufheben><en> Where it shall establish, or where its attention shall be drawn by others to the fact that a concrete offer to which it shall have provided a link raises an issue in respect of responsibility under civil or criminal law, it shall cancel the link to said offer.
<G-vec00198-002-s245><cancel.aufheben><de> Wenn er feststellt oder von anderen darauf hingewiesen wird, dass ein konkretes Angebot, zu dem er einen Link bereitgestellt hat, eine zivil- oder strafrechtliche Verantwortlichkeit auslöst, wird er den Verweis auf dieses Angebot aufheben.
<G-vec00198-002-s246><cancel.aufheben><en> This would not result in losses of many millions or billions of dollars that would all the savings that are caused by these "new" office automation cancel.
<G-vec00198-002-s246><cancel.aufheben><de> Das würde auch nicht zu Verlusten von vielen Millionen oder Milliarden Dollar führen, die alle die Einsparungen, die durch diese „neuartige„ Büroautomatisierungstechnik hervorgerufen werden, aufheben würden.
<G-vec00198-002-s247><cancel.aufheben><en> Only Liberty International spol s.r.o establishes or is advised by others that a concrete offer, to which it has provided a link, causes a civil or criminal liability, shall it cancel the reference to this offer as far as this is technically possible and reasonable therefor.
<G-vec00198-002-s247><cancel.aufheben><de> Erst wenn sie feststellt oder von Dritten darauf hingewiesen wird, daß ein konkretes Angebot, zu dem sie einen externen Link bereitgestellt hat, eine zivil- oder strafrechtliche Verantwortlichkeit auslöst, wird sie den Verweis auf dieses Angebot aufheben, soweit ihm dies technisch möglich und zumutbar ist.
<G-vec00198-002-s248><cancel.aufheben><en> This includes the placement of art in public space, cancel the international artists, the boundaries between museum and outdoor.
<G-vec00198-002-s248><cancel.aufheben><de> Dazu gehört die Vermittlung von Kunst im öffentlichen Raum, mit der internationale Künstler die Grenzen zwischen Museum und Außenbereich aufheben.
<G-vec00198-002-s249><cancel.aufheben><en> You can cancel selection with a second click on the roof plane.
<G-vec00198-002-s249><cancel.aufheben><de> Sie können eine Auswahl aufheben, wenn Sie ein zweites Mal in die Dachfläche klicken.
<G-vec00198-002-s250><cancel.aufheben><en> If you want to cancel the connection between Facebook and our apps, please log in to Facebook and make the necessary changes in your profile settings.
<G-vec00198-002-s250><cancel.aufheben><de> Möchten Sie die Verbindung von Facebook zu unseren Apps aufheben, melden Sie sich bitte bei Facebook an und stellen dort die erforderlichen Änderungen in Ihrem Profil ein.
<G-vec00198-002-s251><cancel.aufheben><en> If the fulfilment of our contractual duties is made impossible or extremely difficult through circumstances for which we are not responsible – acts of god in particular – we can cancel the contract completely or partly or demand execution at a later date, without entitling the supplier to file any claims against us.
<G-vec00198-002-s251><cancel.aufheben><de> Wenn uns infolge von Umständen, die wir nicht zu vertreten haben - insbesondere durch höhere Gewalt - die Erfüllung unserer Vertragsverpflichtungen unmöglich oder wesentlich erschwert wird, können wir den Vertrag ganz oder teilweise aufheben oder die Ausführung zu einem späteren Termin verlangen, ohne dass dem Lieferanten hieraus irgendwelche Ansprüche gegen uns zustehen.
<G-vec00198-002-s252><cancel.aufheben><en> Captain Charity may cancel, amend or modify any promotion, competition, bonus or special offer by publishing the amended or modified terms or notice of cancellation on the relevant internet page of the promotion, competition or special offer.
<G-vec00198-002-s252><cancel.aufheben><de> Captain Charity behält sich das Recht vor, durch die Veröffentlichung angepasster oder veränderter Bedingungen oder die Bekanntgabe der Rücknahme auf der dazugehörigen Webseite für eine Aktion, einen Wettbewerb oder ein Sonderangebot, alle Aktionen, Wettbewerbe, Boni oder Sonderangebote abzuändern, anzupassen oder aufzuheben.
<G-vec00198-002-s253><cancel.aufheben><en> Press this button again to cancel this function.
<G-vec00198-002-s253><cancel.aufheben><de> Drücken Sie diese Taste erneut, um diese Funktion wieder aufzuheben.
<G-vec00198-002-s254><cancel.aufheben><en> Ralph Lauren reserves the right to refuse or cancel any person's registration for this Site, remove any person from this Site or prohibit any person from using this Site for any reason whatsoever.
<G-vec00198-002-s254><cancel.aufheben><de> CCS behält sich das Recht vor, aus beliebigem Grund die Registrierung einer Person für diese Website zu verweigern oder aufzuheben, eine Person von dieser Website zu entfernen oder einer Person die Nutzung dieser Website zu verbieten.
<G-vec00198-002-s255><cancel.aufheben><en> In case of improper use of special conditions of Islamic account the company reserves the right to cancel the status of Islamic account and credit/debit SWAP for the corresponding period.
<G-vec00198-002-s255><cancel.aufheben><de> Im Falle beliebiger Missbräuche von den speziellen Bedingungen der islamischen Konten behält die Gesellschaft das Recht, den Status des islamischen Kontos aufzuheben, sowie SWAPs für die entsprechende Periode anzurechnen/abzunehmen.
<G-vec00198-002-s256><cancel.aufheben><en> The Company reserves the right to cancel the “All Inclusive” scheme in the event of non-observance of these rules.
<G-vec00198-002-s256><cancel.aufheben><de> Das Unternehmen behält sich das Recht vor, das „All Inclusive“-Angebot im Falle der Nichteinhaltung dieser Regeln aufzuheben.
<G-vec00198-002-s257><cancel.aufheben><en> Furthermore, we reserve the right to transfer your personal data to third parties without your consent, if necessary, in order to defend ourselves against attacks which constitute criminal offenses, or which are likely to impair or cancel the functionality of our website.
<G-vec00198-002-s257><cancel.aufheben><de> Weiterhin behalten wir uns das Recht vor, Ihre personenbezogenen Daten auch ohne Ihr Einverständnis an Dritte zu übermitteln, wenn dies nötig sein sollte, um uns gegen Angriffe zu wehren, die Straftatbestände darstellen oder die geeignet sind, die Funktionsfähigkeit unseres Webangebots zu beeinträchtigen oder aufzuheben.
<G-vec00198-002-s258><cancel.aufheben><en> 6. webbabe_ws reserves the right to remove, modify or cancel this bonus at any time at its own discretion.
<G-vec00198-002-s258><cancel.aufheben><de> 6. webbabe_ws behält sich das Recht vor, nach eigenem Ermessen diesen Bonus zu entfernen, zu verändern oder aufzuheben.
<G-vec00198-002-s259><cancel.aufheben><en> British Airways reserves the right to cancel or amend without notice the terms of this promotion and any tickets or vouchers issued free or at promotional prices in the event of major catastrophe, war, earthquake or any actual anticipated or alleged breach of any applicable law or regulation or any other circumstances beyond the reasonable control of British Airways.
<G-vec00198-002-s259><cancel.aufheben><de> British Airways behält sich das Recht vor, die Bedingungen dieses Aktionsangebots und jegliche Tickets oder Gutscheine, die kostenlos oder zu Aktionspreisen ausgegeben wurden, im Falle eines schwerwiegenden Katastrophenereignisses, bei Krieg, Erdbeben oder bei tatsächlicher erwarteter oder vermuteter Verletzung geltender Gesetze oder Vorschriften oder im Falle von Umständen, auf die British Airways keinen Einfluss hat, ohne Vorankündigung zu ändern oder aufzuheben.
<G-vec00198-002-s260><cancel.aufheben><en> Acts of God of all kinds, interruptions of operations and other exceptional circumstances in our factory or that of a subcontractor shall entitle us to cancel delivery obligations in whole or in part, or to postpone delivery periods without the ordering party being entitled to any claims to performance, or to damage claims, except in cases of gross negligence or willful intent.
<G-vec00198-002-s260><cancel.aufheben><de> Höhere Gewalt jeder Art, Betriebsstörungen und sonstige außergewöhnliche Umstände im eigenen Werk oder dem des Unterlieferanten berechtigen, die Lieferverpflichtung ganz oder teilweise aufzuheben oder die Lieferzeiten hinauszuschieben, ohne dass dem Besteller irgendwelche Ansprüche auf Erfüllung oder Schadenersatz, außer bei grober Fahrlässigkeit oder Vorsatz.
<G-vec00198-002-s261><cancel.aufheben><en> This is without prejudice to any legal regulations to cancel or block access to certain information.
<G-vec00198-002-s261><cancel.aufheben><de> Dies gilt unbeschadet allfälliger gesetzlicher Vorschriften, den Zugang zu bestimmten Informationen aufzuheben oder zu blockieren.
<G-vec00198-002-s262><cancel.aufheben><en> If you find yourself going on 2-3 dates with the same person, it is time to cancel any other romantic plans and stop searching for new dates.
<G-vec00198-002-s262><cancel.aufheben><de> Wenn du zwei bis drei Dates mit derselben Person hattest, dann ist es an der Zeit, andere romantische Pläne aufzuheben und nicht nach weiteren Dates zu suchen.
<G-vec00198-002-s263><cancel.aufheben><en> We were able to reach an agreement with the participating insurers, provided the policy is free of damages, to cancel your charter package at the beginning and to refund you the entire premium.
<G-vec00198-002-s263><cancel.aufheben><de> Antwort: Wir konnten bei den beteiligten Versicherern erreichen, sofern die Police schadenfrei ist, Ihr Charterpaket per Beginn aufzuheben und Ihnen die gesamte Prämie zurückzuerstatten.
<G-vec00198-002-s264><cancel.aufheben><en> (11) Tipbet reserves the right to refuse and/or cancel Services at its own discretion where the services are illegal to use.
<G-vec00198-002-s264><cancel.aufheben><de> (11) Tipbet behält sich das Recht vor, Dienste nach eigenem Ermessen zu verweigern oder aufzuheben, wenn ihre Benutzung illegal ist.
<G-vec00198-002-s265><cancel.aufheben><en> THE COMPANY reserves the right to modify, at any time, and without advance notice, the presentation and configuration of the website and of the content and services included therein, and to limit or cancel the general terms and conditions applicable to the website.
<G-vec00198-002-s265><cancel.aufheben><de> Das UNTERNEHMEN behält sich das Recht vor, die Präsentation und Konfiguration der Website, ihrer Inhalte und der darin enthaltenen Dienstleistungen jederzeit und ohne Vorankündigung zu ändern und die für die Website geltenden NUTZUNGSBEDINGUNGEN einzuschränken oder aufzuheben.
<G-vec00198-002-s266><cancel.aufheben><en> The buyer acknowledges that delivery delays of up to two months do not entitle him to refuse acceptance of the ordered goods, to cancel the contract, to claim damages or to reclaim the purchase price.
<G-vec00198-002-s266><cancel.aufheben><de> Der Käufer nimmt zur Kenntnis, dass ihn Lieferverzögerungen bis zu zwei Monaten nicht berechtigen, die Annahme der bestellten Ware zu verweigern, den Vertrag aufzuheben, Schadenersatz zu stellen oder den Kaufpreis zurückzufordern.
<G-vec00198-002-s267><cancel.aufheben><en> With a specially developed technique, Godly tries to cancel the brush stroke and thus to create structures in such a way that they give the impression of being created through erosions, weathering or other tectonic events.
<G-vec00198-002-s267><cancel.aufheben><de> Mit einer eigens entwickelten Technik versucht Godly den Pinselstrich aufzuheben und so Strukturen zu schaffen, die den Eindruck erwecken, durch Erosionen, Witterungseinflüsse oder durch andere tektonische Ereignisse entstanden zu sein.
<G-vec00198-002-s268><cancel.aufheben><en> Norwegian Cruise Line reserves the right to cancel or withdraw this offer at any time.
<G-vec00198-002-s268><cancel.aufheben><de> Norwegian Cruise Line behält sich das Recht vor, dieses Angebot jederzeit aufzuheben oder zurückzuziehen.
<G-vec00198-002-s269><cancel.aufheben><en> Time and space seem to cancel each other out.
<G-vec00198-002-s269><cancel.aufheben><de> Zeiten und Räume scheinen sich aufzuheben.
<G-vec00198-002-s270><cancel.aufheben><en> Click here to change your selection or cancel your agreement.
<G-vec00198-002-s270><cancel.aufheben><de> Klicken Sie hier um Ihre Auswahl zu ändern oder Ihre Zustimmung aufzuheben.
<G-vec00198-002-s358><cancel.aufheben><en> Addition and subtraction does not occur, the deeds do not cancel each other out.
<G-vec00198-002-s358><cancel.aufheben><de> Addition und Subtraktion treten nicht auf, die Taten heben sich nicht gegenseitig auf.
<G-vec00198-002-s359><cancel.aufheben><en> Cancel the selection to discover other Splendid Hotel
<G-vec00198-002-s359><cancel.aufheben><de> Heben Sie die Auswahl wieder auf, um andere Unterkünfte zu entdecken.
<G-vec00198-002-s360><cancel.aufheben><en> The two opposing sound waves cancel out each other, resulting in “silence”.
<G-vec00198-002-s360><cancel.aufheben><de> Die beiden entgegengesetzten Schallwellen heben sich gegenseitig auf, was zu “Stille” führt.
<G-vec00198-002-s361><cancel.aufheben><en> If they in turn cancel each other out, it means that the spectral mismatch factor is approximately equal to one (this representation is only for illustrative purposes and is not a mathematical description).
<G-vec00198-002-s361><cancel.aufheben><de> Heben sie sich wiederum auf, ist es ein Indiz dafür, dass der spektrale Fehlanpassungskorrekturfaktor nahe eins sein wird (diese Darstellung dient nur zur Veranschaulichung und ist keine mathematische Beschreibung).
<G-vec00198-002-s362><cancel.aufheben><en> Coloured lines intersect, complement, hold one another, cancel each other out.
<G-vec00198-002-s362><cancel.aufheben><de> Farbige Linien überschneiden, ergänzen, halten sich, heben sich auf.
<G-vec00198-002-s363><cancel.aufheben><en> The deviations from value expressed in the production price cancel each other, so that for the total capital the sum of the production prices equals the total value.
<G-vec00198-002-s363><cancel.aufheben><de> Die in den Produktionspreisen ausgedrückten Abweichungen vom Wert heben sich gegeneinander auf, so daß für das Gesamtkapital alle Produktionspreise gleich dem Gesamtwert sind.
<G-vec00198-002-s364><cancel.aufheben><en> If you no longer wish to receive the data processing described here, please cancel the connection of your user profile to our Facebook page by using the functions "I no longer like this page" and/or "No longer subscribe to this page". DE
<G-vec00198-002-s364><cancel.aufheben><de> Wenn Sie die hier beschriebenen Datenverarbeitungen zukünftig nicht mehr wünschen, dann heben Sie bitte durch Nutzung der Funktionen „Diese Seite gefällt mir nicht mehr“ und/oder „Diese Seite nicht mehr abonnieren“ die Verbindung Ihres Benutzer-Profils zu unserer Seite auf.
<G-vec00198-002-s366><cancel.aufheben><en> This means that those cards cancel each other out.
<G-vec00198-002-s366><cancel.aufheben><de> Diese Karten heben sich also gegenseitig auf.
<G-vec00198-002-s369><cancel.aufheben><en> If the Commission decides not to approve the new active substance, the competent authorities which granted the provisional authorisation or the Commission shall cancel that authorisation.
<G-vec00198-002-s369><cancel.aufheben><de> Entscheidet die Kommission, den neuen Wirkstoff nicht zu genehmigen, so heben die zuständigen Behörden, die die vorläufige Zulassung erteilt haben, oder die Kommission die Zulassung auf.
<G-vec00198-002-s271><cancel.auflösen><en> Thus, if at any time “Armas” requires a fee for portions of the “Service” that are now free, “Armas” will give you advance notice of such fees and the opportunity to cancel your account before such charges are imposed.
<G-vec00198-002-s271><cancel.auflösen><de> Sollte ARMAS Gebühren für Teile des Service verlangen, die heute frei zugaenglich sind, erhalten Sie eine Nachricht von ARMAS und die Möglichkeit, Ihren Account aufzulösen, bevor diese Gebühren zum Tragen kommen.
<G-vec00198-002-s272><cancel.auflösen><en> Without prejudice to all other rights, DASSY is entitled, in case of arrears in payment, to suspend the (further) performance of any agreement with the customer (even if the failure to pay relates to another contractual relationship) and to cancel the agreement(s).
<G-vec00198-002-s272><cancel.auflösen><de> Bei nicht rechtzeitiger Zahlung ist DASSY unbeschadet aller anderen Rechte berechtigt, die (weitere) Erfüllung jedes mit dem Kunden geschlossenen Vertrages auszusetzen (auch wenn die Nichtzahlung sich auf ein anderes Vertragsverhältnis bezieht) und den/die Vertrag/Verträge aufzulösen.
<G-vec00198-002-s273><cancel.auflösen><en> The customer then has the right to cancel the order free of charge and has right to a potential damage claim.
<G-vec00198-002-s273><cancel.auflösen><de> Der Verbraucher hat in diesem Fall das Recht, den Vertrag ohne Kosten zu aufzulösen und hat gegebenenfalls Anspruch auf Schadenersatz.
<G-vec00198-002-s274><cancel.auflösen><en> As a user you have the ability to cancel your registration at any time.
<G-vec00198-002-s274><cancel.auflösen><de> Als Nutzer haben sie jederzeit die Möglichkeit, die Registrierung aufzulösen.
<G-vec00198-002-s275><cancel.auflösen><en> If the payment is not made on time the organizer has the right to cancel the contract and charge the annulment costs according to point 3.
<G-vec00198-002-s275><cancel.auflösen><de> Sollte die Zahlung nicht fristgemäss eingegangen sein, behält sich der Anbieter das Recht vor, den Vertrag aufzulösen und die unter Punkt 3 aufgelisteten Annulationskosten in Rechnung zu stellen.
<G-vec00198-002-s276><cancel.auflösen><en> 1. When purchasing products the consumer has the possibility to cancel the agreement without reasons during 14 days.
<G-vec00198-002-s276><cancel.auflösen><de> Beim Kauf von Produkten hat der Verbraucher die Möglichkeit, den Vertrag für 14 Tage ohne Angabe von Gründen aufzulösen.
<G-vec00198-002-s277><cancel.auflösen><en> Should one of the reasons stated in clause 6.2. have existed for more than two months, the Supplier, as well as the Customer, shall be entitled to cancel the Contract by unilaterally announcing such cancellation in writing.
<G-vec00198-002-s277><cancel.auflösen><de> Dauert einer der in Punkt 6.2. genannten Gründe länger als zwei Monate, so sind sowohl der Lieferant als auch der Kunde berechtigt, durch einseitige schriftliche Erklärung den Vertrag aufzulösen.
<G-vec00198-002-s278><cancel.auflösen><en> Furthermore, you have the option to cancel your registration at any time by deleting the registered user account yourself through the account settings or letting us know that you want your registered user account deleted.
<G-vec00198-002-s278><cancel.auflösen><de> Zudem haben Sie jederzeit die Möglichkeit, Ihre Registrierung aufzulösen, indem Sie den registrieren Nutzer-Account in Ihren Account-Einstellungen eigenhändig löschen oder uns mitteilen, dass Sie eine Löschung Ihres registrierten Nutzer-Accounts wünschen.
<G-vec00198-002-s280><cancel.auflösen><en> Pixmac has the right to modify or cancel the affiliate program as well as to change its current terms and conditions without any prior notice.
<G-vec00198-002-s280><cancel.auflösen><de> Pixmac hat das Recht, das Partnerprogramm zu ändern oder aufzulösen, sowie auch die gegenwärtigen Vertragsbedingungen zu ändern, und das ohne vorherige Bekanntgabe.
<G-vec00198-002-s281><cancel.auflösen><en> 13 Cancellation clause The vendor has the right to cancel the order if the customer doesn't execute his obligations.
<G-vec00198-002-s281><cancel.auflösen><de> Artikel 1: Der Vermieter hat das Recht, den Vertrag bei Nichterfüllung einer seiner Pflichten durch den Käufer aufzulösen.
<G-vec00198-002-s282><cancel.auflösen><en> YOU ACKNOWLEDGE AND AGREE THAT IF YOU HAVE NOT PAID ANYTHING TO DISRUPTOR BEAM DURING SUCH TIME PERIOD, YOUR SOLE REMEDY (AND DISRUPTOR BEAM’S EXCLUSIVE LIABILITY) FOR ANY DISPUTE WITH DISRUPTOR BEAM IS TO STOP USING THE SERVICE AND TO CANCEL YOUR ACCOUNT.
<G-vec00198-002-s282><cancel.auflösen><de> Sie erkennen an und stimmen zu dass, sofern Sie während der besagten Zeit nichts an DISRUPTOR BEAM gezahlt haben, Ihr einziges Rechtsmittel (und der einzige Fall von Haftbarkeit für DISRUPTOR BEAM) für einen beliebigen Streit mit DISRUPTOR BEAM darin besteht, die Nutzung der LEISTUNG zu beenden und IHR KONTO aufzulösen.
<G-vec00198-002-s284><cancel.beenden><en> (iv) Where you have the right to cancel and want to cancel the Agreement you must write to our customer service team at Wienerbergstraße 11/12 A, 1100 Wien, Austria ensuring that your letter reaches us before the expiry of your right to cancel.
<G-vec00198-002-s284><cancel.beenden><de> (iv) Sie haben das Recht die Vereinbarung zu beenden, jedoch müssen Sie dafür unserem Kundendienst in der Wienerbergstraße 11/12 A, 1100 Wien, Österreich schreiben und Ihr Brief muss vor Ablauf Ihres Widerrufsrecht bei uns ankommen.
<G-vec00198-002-s285><cancel.beenden><en> Unibet reserves the rights to change or cancel the bonus at any time.
<G-vec00198-002-s285><cancel.beenden><de> Unibet behält sich das Recht vor, den Bonus jederzeit zu ändern oder zu beenden.
<G-vec00198-002-s286><cancel.beenden><en> HP reserves the right to modify or cancel this offer at any moment.
<G-vec00198-002-s286><cancel.beenden><de> HP behält sich das Recht vor, das Programm jederzeit zu überarbeiten oder zu beenden.
<G-vec00198-002-s287><cancel.beenden><en> Clicking on details will expand the window.As in the "Subscriptions window" you can renew right now, hold, cancel, or change the
<G-vec00198-002-s287><cancel.beenden><de> Wie im "Abonnements"-Fenster könnt Ihr hier Euer aktuelles Abonnement verlängern, pausieren, beenden oder ändern.
<G-vec00198-002-s288><cancel.beenden><en> You can easily upgrade, downgrade, or cancel your plan when your needs change.
<G-vec00198-002-s288><cancel.beenden><de> Sie können den Plan problemlos heraufstufen, herabstufen oder beenden, wenn sich Ihre Anforderungen ändern.
<G-vec00198-002-s289><cancel.beenden><en> D BC A GUIDE (p. 23) B Stop C Play/Pause toggles as you touch it D Rewind/Fast forward x To cancel Easy Handycam operation Press EASY C again. disappears from the screen D. x Adjustable menu settings during Easy Handycam operation Touch to display adjustable menu settings.
<G-vec00198-002-s289><cancel.beenden><de> HLFE D BC A HLFE (S. 23) B Stopp C Wechsel zwischen Wiedergabe und Pause bei Beruhrung der Taste D Zuruckspulen/Vorwartsspulen x So beenden Sie den Easy Handycam-Modus Drucken Sie erneut EASY C. wird im Bildschirm ausgeblendet D. x Im Menuoptionen aufzurufen.
<G-vec00198-002-s290><cancel.beenden><en> We will only automatically renew it if you have not told us you want to cancel.
<G-vec00198-002-s290><cancel.beenden><de> Wir erneuern sie nur dann, wenn du uns nicht zuvor mitgeteilt hast, dass du deine Mitgliedschaft beenden möchtest.
<G-vec00198-002-s291><cancel.beenden><en> b. the Consumer has the authority to cancel the contract before the day on which the price increase starts. 5.
<G-vec00198-002-s291><cancel.beenden><de> b. der Kunde hat das Recht, den Vertrag, ab dem Tag an dem die Preiserhöhung in Kraft tritt, zu beenden.
<G-vec00198-002-s292><cancel.beenden><en> You can change or cancel your Tip at any time.
<G-vec00198-002-s292><cancel.beenden><de> Ich kannst deinen Tip jederzeit ändern oder beenden.
<G-vec00198-002-s293><cancel.beenden><en> You can cancel your subscription at any time.
<G-vec00198-002-s293><cancel.beenden><de> Sie können Ihr Abonnement jederzeit beenden.
<G-vec00198-002-s294><cancel.beenden><en> N26 has the right to cancel the referral program at any time.
<G-vec00198-002-s294><cancel.beenden><de> N26 hat das Recht, das Empfehlungsprogramm jederzeit zu beenden.
<G-vec00198-002-s295><cancel.beenden><en> If you wish to cancel your membership, please contact 4mycams Customer Service by email or by visiting the Online Support Chat.
<G-vec00198-002-s295><cancel.beenden><de> Wenn Sie Ihre Mitgliedschaft beenden möchten, kontakieren Sie einfach die Mitarbeiter von 4mycams per Email oder besuchen Sie den Online Hilfe Chat.
<G-vec00198-002-s296><cancel.beenden><en> Click Cancel Subscription to cancel your subscription.
<G-vec00198-002-s296><cancel.beenden><de> Klicken Sie auf "Abonnement kündigen", um Ihr Abonnement zu beenden.
<G-vec00198-002-s297><cancel.beenden><en> You can cancel the order procedure any time by closing the browser window completely.
<G-vec00198-002-s297><cancel.beenden><de> Den Bestellprozess können Sie auch jederzeit durch Schließen des Browser-Fensters komplett beenden.
<G-vec00198-002-s298><cancel.beenden><en> 11.6 These Terms, including any terms, conditions and policies expressly referenced herein, shall constitute the complete understanding and agreement between you and us, and shall supersede and cancel any prior or contemporaneous understandings and agreements, except as expressly provided otherwise by Ancestry.
<G-vec00198-002-s298><cancel.beenden><de> Großherzogtum Luxemburg 11.6 Diese AGB, einschließlich aller Bedingungen, Bestimmungen und Richtlinien, auf die ausdrücklich Bezug genommen wird, stellen die gesamte Vereinbarung zwischenIhnen und uns dar und ersetzen und beenden alle früheren oder gegenwärtigen Vereinbarungen, sofern Ancestry nicht ausdrücklich etwas anderes bestimmt hat.
<G-vec00198-002-s299><cancel.beenden><en> We reserve the right to cancel this auction early if this unit sells locally from my store.
<G-vec00198-002-s299><cancel.beenden><de> Darüber hinaus behalten wir uns das Recht vor, eine Auktion vorzeitig zu beenden, wenn das Element lokal verkauft wird.
<G-vec00198-002-s300><cancel.beenden><en> Insufficient tip for the chosen change or cancel your Tip at any time.
<G-vec00198-002-s300><cancel.beenden><de> Du kannst deinen Tip jederzeit ändern oder beenden.
<G-vec00198-002-s301><cancel.beenden><en> When you cancel your Premium Spotify account, the consequences are pretty clear.
<G-vec00198-002-s301><cancel.beenden><de> Wenn Sie Ihren Premium Spotify Account beenden sind die Konsequenzen ziemlich klar.
<G-vec00198-002-s302><cancel.beenden><en> Note: To cancel your connection you don't have to wait until the connection process ends.
<G-vec00198-002-s302><cancel.beenden><de> Hinweis: Um deine Verbindung zu beenden, ist es nicht notwendig, den Verbindungsprozess abzuwarten.
<G-vec00198-002-s322><cancel.einstellen><en> The author explicitly reserves the right to change, supplement or delete parts of the site or the whole offer or to temporarily or finally cancel the publication without prior notice.
<G-vec00198-002-s322><cancel.einstellen><de> Der Autor behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00198-002-s324><cancel.einstellen><en> In the future, the second challenge will be to cancel the subsidy.
<G-vec00198-002-s324><cancel.einstellen><de> Die zweite Herausforderung wird in Zukunft darin bestehen, die Subvention einzustellen.
<G-vec00198-002-s325><cancel.einstellen><en> 2.2 Taiji Forum reserves the right to restrict or to cancel services for the user at any time as well as the right to exclude individual users from the use of services of the website.
<G-vec00198-002-s325><cancel.einstellen><de> 2.2 Taiji Forum hat zu jeder Zeit das Recht, die Leistungen für den Nutzer einzuschränken oder einzustellen sowie einzelne Nutzer von der Nutzung der Internetseiten auszuschließen.
<G-vec00198-002-s326><cancel.einstellen><en> We reserve the right to refuse service, terminate accounts, remove or edit content, or cancel orders in the exercise of our sole discretion. Links
<G-vec00198-002-s326><cancel.einstellen><de> 3.4 Änderung der Web Services: Wir behalten uns das Recht vor unsere Web Services oder unsere Inhalte von Zeit zu Zeit ohne vorherige Ankündigung zu verbessern, zu überarbeiten, zu berichtigen, abzuändern, oder einzustellen.
<G-vec00198-002-s327><cancel.einstellen><en> EPAG reserves the right to cancel the provision of the above-mentioned services for specific domains in reasonable cases and in its sole discretion.
<G-vec00198-002-s327><cancel.einstellen><de> EPAG behält sich das Recht vor, die Bereitstellung der vorstehend erwähnten Services für bestimmte Domains in angemessenen Fällen und nach eigenem Ermessen einzustellen.
<G-vec00198-002-s329><cancel.einstellen><en> Them reserves the right to change or cancel their offer at any time.
<G-vec00198-002-s329><cancel.einstellen><de> Sie behält sich das Recht vor, ihr Angebot jederzeit zu ändern oder einzustellen.
<G-vec00198-002-s330><cancel.einstellen><en> United Internet AG reserves the right to cancel the program at any time.
<G-vec00198-002-s330><cancel.einstellen><de> Die United Internet AG behält sich das Recht vor, das Programm jederzeit einzustellen.
<G-vec00198-002-s331><cancel.einstellen><en> The service uses cookies – small text files sent to the internaut’s computer in order to identify it in a way necessary to simplify or cancel a given operation.
<G-vec00198-002-s331><cancel.einstellen><de> Das Service verwendet Cookies d.h. kleine Textdateien, die auf den Computer des Anwenders geschickt werden, und die den Computer identifizieren, um eine Operation zu vereinfachen oder einzustellen.
<G-vec00198-002-s332><cancel.einstellen><en> The author explicitly reserves the right to change, supplement or delete either individual elements of the website or the entire website without prior notice, or to temporarily or permanently cancel publication of the content.
<G-vec00198-002-s332><cancel.einstellen><de> Die Urheber behalten es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00198-002-s333><cancel.einstellen><en> Rent4All reserves the right to cancel this guarantee at any time.
<G-vec00198-002-s333><cancel.einstellen><de> Rent4All behält sich das Recht vor, diese Garantie jederzeit einzustellen.
<G-vec00198-002-s334><cancel.einstellen><en> The operator reserves the right to continue developing the game or to change it at any time or cancel its operation without stating a reason.
<G-vec00198-002-s334><cancel.einstellen><de> Der Betreiber behält sich vor, das Spiel jederzeit weiterzuentwickeln, zu verändern oder den Betrieb ohne Angabe von Gründen einzustellen.
<G-vec00198-002-s336><cancel.einstellen><en> Soccer Challenge reserves the right to change or cancel partially or completely, temporarily or permanently, the availability of an offer, without giving special notification.
<G-vec00198-002-s336><cancel.einstellen><de> Soccer Challenge behält sich vor, Teile des Angebots oder das Angebot als Ganzes ohne gesonderte Ankündigung zu verändern oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00198-002-s337><cancel.einstellen><en> The Company reserves the right at its discretion with or without notice to review, change, amend or cancel the plan at any time.
<G-vec00198-002-s337><cancel.einstellen><de> Das Unternehmen behält sich das Recht vor, den Plan nach eigenem Ermessen und ohne Vorankündigung zur prüfen, zu ändern, zu ergänzen oder einzustellen.
<G-vec00198-002-s338><cancel.einstellen><en> TPA Albania is entitled at any time and without prior notice to suspend or cancel permanently individual services or the totality of the service provided through this website.
<G-vec00198-002-s338><cancel.einstellen><de> TPA ist berechtigt, jederzeit – auch ohne Vorankündigung – sowohl einzelne Dienste als auch das gesamte unter der Website abrufbare Internetangebot vorübergehend aber auch dauerhaft einzustellen.
<G-vec00198-002-s339><cancel.kündigen><en> The data subject can at any time cancel delivery of a white paper and delete the profile which has been set up.
<G-vec00198-002-s339><cancel.kündigen><de> Der Bezug des Whitepapers kann durch den betroffenen Nutzer jederzeit gekündigt und das angelegte Profil gelöscht werden.
<G-vec00198-002-s340><cancel.kündigen><en> Once you cancel your account, we permanently delete all your data from our servers.
<G-vec00198-002-s340><cancel.kündigen><de> Sobald Sie Ihren Account gekündigt haben, löschen wir all Ihre Daten von unseren Servern unwiderruflich.
<G-vec00198-002-s341><cancel.kündigen><en> You cannot cancel the current subscription during the active subscription period.
<G-vec00198-002-s341><cancel.kündigen><de> Das aktuelle Abonnement kann während des aktuellen Abo-Zeitraums nicht gekündigt werden.
<G-vec00198-002-s342><cancel.kündigen><en> After you cancel the Office 365 for home subscription, the full Microsoft apps that they previously downloaded may go into reduced functionality mode unless the Office 365 for business subscription you chose also has the full Microsoft apps.
<G-vec00198-002-s342><cancel.kündigen><de> Nachdem Sie das Office 365 Home-Abonnement gekündigt haben, wechseln die zuvor heruntergeladenen Vollversionen von Microsoft-Anwendungen in den Modus mit eingeschränkter Funktionalität, sofern das von Ihnen ausgewählte Office 365 Business-Abonnement nicht über Vollversionen der Microsoft-Anwendungen verfügt.
<G-vec00198-002-s343><cancel.kündigen><en> You will not be able to cancel the subscription once activated.
<G-vec00198-002-s343><cancel.kündigen><de> Das Abonnement kann nicht gekündigt werden, sobald es aktiviert ist.
<G-vec00198-002-s344><cancel.kündigen><en> These incentives are no longer applicable should a subscription customer cancel, then choose to re-subscribe at a later date.
<G-vec00198-002-s344><cancel.kündigen><de> Es besteht kein Anspruch auf einen Preisvorteil mehr, wenn das Abonnement gekündigt und zu einem späteren Zeitpunkt erneut abgeschlossen wird.
<G-vec00198-002-s345><cancel.kündigen><en> You can cancel your subscription at any time so that your subscription will expire on your next payment due date.
<G-vec00198-002-s345><cancel.kündigen><de> Das Abonnement kann jederzeit gekündigt werden, sodass das Abonnement dann am nächsten Zahlungsfälligkeitsdatum abläuft.
<G-vec00198-002-s346><cancel.kündigen><en> The primary account holder must cancel all accounts through their account.
<G-vec00198-002-s346><cancel.kündigen><de> Alle Konten müssen vom Hauptkontoinhaber über sein Konto gekündigt werden.
<G-vec00198-002-s347><cancel.kündigen><en> Subscribers can cancel their subscriptions to the newsletter at any time by withdrawing their consent.
<G-vec00198-002-s347><cancel.kündigen><de> Das Abonnement des Newsletters kann durch den betroffenen Nutzer jederzeit gekündigt werden.
<G-vec00198-002-s349><cancel.kündigen><en> Users can cancel the newsletter subscription at any time.
<G-vec00198-002-s349><cancel.kündigen><de> Das Abonnement des Newsletters kann durch den Nutzer jederzeit gekündigt werden.
<G-vec00198-002-s350><cancel.kündigen><en> If users have only registered for the newsletter and then cancel the subscription, their personal data will be erased.
<G-vec00198-002-s350><cancel.kündigen><de> Wenn die Nutzer sich nur zum Newsletter angemeldet und diese Anmeldung gekündigt haben, werden ihre personenbezogenen Daten gelöscht.
<G-vec00198-002-s351><cancel.kündigen><en> If your data should be displayed publicly in the Whois directory again you can cancel the domain privacy.
<G-vec00198-002-s351><cancel.kündigen><de> Sollen Ihre Daten wieder öffentlich im Whois-Verzeichnis angezeigt werden, kann der Domaindatenschutz gekündigt werden.
<G-vec00198-002-s353><cancel.kündigen><en> A user can cancel their PlayStation®Plus membership at any time so that their subscription will expire on their next payment due date.
<G-vec00198-002-s353><cancel.kündigen><de> Die Mitgliedschaft kann jederzeit gekündigt werden, sodass die Mitgliedschaft dann am Ende des jeweils aktuellen Quartals abläuft.
<G-vec00198-002-s355><cancel.kündigen><en> When you cancel your subscription, you will continue to have the same access and benefits of your subscription for the remainder of the current billing month.
<G-vec00198-002-s355><cancel.kündigen><de> Wenn Sie Ihr Abonnement gekündigt haben, bleiben Ihnen der Zugriff und die Vorteile Ihres Abonnements noch während des verbleibenden Abrechnungsmonats erhalten.
<G-vec00198-002-s356><cancel.kündigen><en> Membership is free and you can cancel it at any time via "My Page".
<G-vec00198-002-s356><cancel.kündigen><de> Die Mitgliedschaft ist kostenlos und kann jederzeit auf „Meine Seite” gekündigt werden.
<G-vec00198-002-s371><cancel.kündigen><en> If the Subscriber would like to oppose the processing of personal data by Live Sex Chat Queef Cams, he/she is entitled to cancel his/her account on Live Sex Chat Queef Cams at any time as described above.
<G-vec00198-002-s371><cancel.kündigen><de> Wenn der Abonnent der Verarbeitung der persönlichen Daten durch Live Sex Chat Queef Cams widersprechen möchte, hat er/sie jederzeit das Recht, sein/ihr Konto bei Live Sex Chat Queef Cams wie zuvor beschrieben zu kündigen.
<G-vec00198-002-s372><cancel.kündigen><en> After the first year we will renew your contract automatically for another year at the then-current standard annual price (currently at $359.88), unless you cancel.
<G-vec00198-002-s372><cancel.kündigen><de> Danach verlängert sich das Abo automatisch für ein weiteres Jahr zum dann geltenden regulären Abo-Preis (derzeit € 359,75 pro Jahr), es sei denn, Sie kündigen das Abo.
<G-vec00198-002-s373><cancel.kündigen><en> If the Subscriber would like to oppose the processing of personal data by Red Cams Free Porno Chat Online, he/she is entitled to cancel his/her account on Red Cams Free Porno Chat Online at any time as described above.
<G-vec00198-002-s373><cancel.kündigen><de> Wenn der Abonnent der Verarbeitung der persönlichen Daten durch RedCams Free Sex Chat Online Girls widersprechen möchte, hat er/sie jederzeit das Recht, sein/ihr Konto bei RedCams Free Sex Chat Online Girls wie zuvor beschrieben zu kündigen.
<G-vec00198-002-s374><cancel.kündigen><en> But there is nothing in the agreement which says that you must cancel it, if it is not respected.
<G-vec00198-002-s374><cancel.kündigen><de> Aber im Abkommen steht nirgends, dass man es kündigen müsse, wenn es nicht eingehalten wird.
<G-vec00198-002-s375><cancel.kündigen><en> Until receipt of this acceptance has not been confirmed, the consumer may cancel the agreement.
<G-vec00198-002-s375><cancel.kündigen><de> Solange der Unternehmer die Annahme nicht bestätigt hat, kann der Verbraucher den Vertrag kündigen.
<G-vec00198-002-s376><cancel.kündigen><en> To cancel your existing cam2cam SMS text messaging service simply click the "Cancel SMS Notifications" link after the phone number input box located on the "My Account" page in the "My Favorite cam2cams" section.
<G-vec00198-002-s376><cancel.kündigen><de> Wenn du deinen SMS-Benachrichtigungsdienst bei cam2cam wieder kündigen möchtest, klickst du einfach auf den Link "SMS-Benachrichtigungen kündigen"; diesen Link findest du beim Telefonnummereingabefeld im "Meine Performer-Favoriten"-Bereich auf der "Ihr Konto"-Seite .
<G-vec00198-002-s377><cancel.kündigen><en> Unless otherwise agreed by Autodesk, if You do not purchase a renewal for Your Support prior to expiration of the Term or if You cancel Your automatic renewal, this Support Agreement and Your entitlement to receive Support Benefits will automatically expire.
<G-vec00198-002-s377><cancel.kündigen><de> Wenn Sie vor Ende der Vertragslaufzeit keine Verlängerung Ihres Supports erwerben oder wenn Sie die automatische Verlängerung kündigen, läuft dieser Support-Vertrag und Ihre Berechtigung, Support-Leistungen zu erhalten automatisch ab, sofern nichts Anderes mit Autodesk vereinbart wurde.
<G-vec00198-002-s378><cancel.kündigen><en> For example, if you purchased a three-month subscription and then choose to cancel it after one month, the subscription will remain active until the end of the three month period.
<G-vec00198-002-s378><cancel.kündigen><de> Wenn Sie beispielsweise ein 3-Monatsabonnement erwerben und es dann kündigen, bleibt das Abonnement bis zum Ablauf des dreimonatigen Zeitraums aktiv.
<G-vec00198-002-s379><cancel.kündigen><en> Every member may cancel membership at the end of any month.
<G-vec00198-002-s379><cancel.kündigen><de> Jedes Mitglied kann die Mitgliedschaft zum Ende des Monats kündigen.
<G-vec00198-002-s380><cancel.kündigen><en> Cenarion Information Systems GmbH reserves the right to cancel your subscriptions in the same way without any particular reason.
<G-vec00198-002-s380><cancel.kündigen><de> Cenarion Information Systems GmbH behält sich das Recht vor, Ihre Abonnements ohne Grund jederzeit auf genau die gleiche Weise zu kündigen.
<G-vec00198-002-s381><cancel.kündigen><en> If the Subscriber would like to oppose the processing of personal data by video chat, he/she is entitled to cancel his/her account on video chat at any time as described above.
<G-vec00198-002-s381><cancel.kündigen><de> Wenn der Abonnent der Verarbeitung der persönlichen Daten durch Rept cams widersprechen möchte, hat er/sie jederzeit das Recht, sein/ihr Konto bei Rept cams wie zuvor beschrieben zu kündigen.
<G-vec00198-002-s382><cancel.kündigen><en> 5.2 If you cancel your membership any points left in your account will expire.
<G-vec00198-002-s382><cancel.kündigen><de> 5.2 Wenn Sie Ihre Mitgliedschaft kündigen, verfallen etwaige auf dem Account verbleibende Punkte.
<G-vec00198-002-s383><cancel.kündigen><en> Tap Cancel Trial or Cancel Subscription.
<G-vec00198-002-s383><cancel.kündigen><de> Tippen Sie auf Testversion kündigen oder Abonnement kündigen.
<G-vec00198-002-s385><cancel.kündigen><en> The consumer can cancel an agreement that has been concluded for an indefinite period of time at any time with due observance of the agreed termination rules and a notice period of at most one month.
<G-vec00198-002-s385><cancel.kündigen><de> Der Verbraucher kann einen auf unbestimmte Zeit geschlossenen Vertrag jederzeit unter Beachtung der vereinbarten Kündigungsregeln und einer Kündigungsfrist von höchstens einem Monat kündigen.
<G-vec00198-002-s386><cancel.kündigen><en> Here it goes on automatically and I have to cancel it if I don’t want the subscription any longer.
<G-vec00198-002-s386><cancel.kündigen><de> Hier erneuert es sich automatisch und man muss kündigen, wenn man das Abo nicht mehr möchte.
<G-vec00198-002-s387><cancel.kündigen><en> At anytime the customer can cancel his " liberty " subscription by going to his Sarbacane account or by contacting the customer service at unsubscribe@sarbacane.com.
<G-vec00198-002-s387><cancel.kündigen><de> Der Kunde kann sein "Freiheit" Abo jederzeit kündigen beim Einloggen in das Sarbacane Konto oder beim Kontaktieren des Kundendienstes unter unsubscribe@sarbacane.com.
<G-vec00198-002-s388><cancel.kündigen><en> If the Subscriber would like to oppose the processing of personal data by Beautiful Sexy Free, he/she is entitled to cancel his/her account on Beautiful Sexy Free at any time as described above.
<G-vec00198-002-s388><cancel.kündigen><de> Wenn der Abonnent der Verarbeitung der persönlichen Daten durch Sex Webkamera widersprechen möchte, hat er/sie jederzeit das Recht, sein/ihr Konto bei Sex Webkamera wie zuvor beschrieben zu kündigen.
<G-vec00198-002-s389><cancel.kündigen><en> Customer shall cancel the LLOM subscription if he/she does not want to incur in the renewal of the feature.
<G-vec00198-002-s389><cancel.kündigen><de> Der Kunde kann die Festnetznummer kündigen, wenn er diese in der nächsten Laufzeit nicht mehr nutzen möchte.
<G-vec00198-002-s409><cancel.löschen><en> That means you can no longer set up, change or cancel direct debits via your bank.
<G-vec00198-002-s409><cancel.löschen><de> Daher können Sie eine Lastschrift nicht mehr bei der Bank eröffnen, ändern oder löschen.
<G-vec00198-002-s410><cancel.löschen><en> In order to cancel existing recurring donations please write us a short email: support@betterplace.org.
<G-vec00198-002-s410><cancel.löschen><de> Um eine eingerichtete Dauerspende zu löschen, schicke uns bitte einfach eine kurze Mail an support@betterplace.org.
<G-vec00198-002-s411><cancel.löschen><en> If you want to cancel your My Account, please contact us.
<G-vec00198-002-s411><cancel.löschen><de> Wenn Sie Ihren Account löschen möchten, kontaktieren Sie uns.
<G-vec00198-002-s412><cancel.löschen><en> To cancel one of the computer readings individually, select the required function and press the RESET button -A- for at least one second.
<G-vec00198-002-s412><cancel.löschen><de> Um einen aktuellen Wert des Bordcomputers zu löschen, wählen Sie die gewünschte Funktion und drücken Sie die Taste RESET -A- mindestens eine Sekunde lang.
<G-vec00198-002-s413><cancel.löschen><en> We reserve the right to cancel and/or void granted Reward Points in case of misconduct or fraudulent behavior.
<G-vec00198-002-s413><cancel.löschen><de> Wir behalten uns das Recht vor, zugesprochene Treuepunkte im Fall von Missbrauch und/oder Betrug zu löschen.
<G-vec00198-002-s414><cancel.löschen><en> The author explicitly reserves the right to modify, complement or cancel parts of pages or the entire offer without prior notice, or stop publication temporarily or altogether.
<G-vec00198-002-s414><cancel.löschen><de> Der Autor behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00198-002-s415><cancel.löschen><en> The provider has the right to cancel the registration of the user even without giving a reason.
<G-vec00198-002-s415><cancel.löschen><de> Der Anbieter hat das Recht, die Registrierung des Benutzers zu löschen, auch ohne Angabe von Gründen.
<G-vec00198-002-s416><cancel.löschen><en> So then you cancel your account, but continue to get emails, asking you to reactivate the service and recommend it to friends.
<G-vec00198-002-s416><cancel.löschen><de> Sie löschen also Ihren Account, können jedoch die Firma nicht davon abbringen, Ihnen weiter E-Mails zu schicken, Sie zu fragen, ob Sie den Account nicht doch wiederherstellen wollen oder den Service Ihren Freunden weiterempfehlen möchten.
<G-vec00198-002-s417><cancel.löschen><en> Any "discontinuity" in a coaxial cable can reflect specific frequency signals, causing them to cancel.
<G-vec00198-002-s417><cancel.löschen><de> Jede mögliche "Unstimmigkeit" in einem Koaxialkabel kann die spezifischen Frequenzsignale reflektieren und sie zum Löschen verursachen.
<G-vec00198-002-s418><cancel.löschen><en> Modifying the programme To change a programme which is running, first cancel it by turning the programme selector dial to “O”.
<G-vec00198-002-s418><cancel.löschen><de> Programmänderung Zum Ändern eines laufenden Programms zunächst das Programm löschen, indem Sie den Programmwähler auf die Position “O” drehen.
<G-vec00198-002-s419><cancel.löschen><en> he / she can "cancel" the "residence status" currently held by the foreigner.
<G-vec00198-002-s419><cancel.löschen><de> Es ist möglich, den "Aufenthaltsstatus" eines Ausländers zu "löschen".
<G-vec00198-002-s420><cancel.löschen><en> Domain holder acknowledges and accepts that PSI-USA as accredited registrar shall implement the UDRP decision and cancel or transfer the domain to a third person according to the decision unless domain holder proves within 10 days after their information that he has commenced a lawsuit at a competent court to clarify the right to use the domain.
<G-vec00198-002-s420><cancel.löschen><de> Der Domain-Inhaber erkennt weiter an, dass PSI-USA als zugelassener Registrar verpflichtet ist, gemäß einem entsprechenden Schiedsspruch im Verfahren nach den UDRP die Domain zu löschen oder an einen Dritten zu übertragen, sofern nicht der Domain-Inhaber PSI-USA gegenüber binnen 10 Tagen ab Zugang des Schiedsspruchs nachweist, das er gegen den obsiegenden Gegner des Schiedsverfahrens vor einem staatlichen Gericht Klage wegen der Zulässigkeit der Domain erhoben hat.
<G-vec00198-002-s421><cancel.löschen><en> The customer can cancel his account at avocado.lu at any time by a written request to Avocado SA.
<G-vec00198-002-s421><cancel.löschen><de> Der Kunde kann sein Konto auf avocado.lu jederzeit durch einen schriftlichen Antrag an Avocado SA löschen.
<G-vec00198-002-s422><cancel.löschen><en> Reservation EIS and the Registry CNNIC reserve the right to refuse, cancel or to transfer registrations at their own discretion as far as this is required in order to maintain the proper activity of the Registry, to comply with legal or government regulations, on the order of the public prosecutor's office, in compliance with the above-mentioned rules or to avoid any civil or penal liability of EIS or the Registry CNNIC or their employees.
<G-vec00198-002-s422><cancel.löschen><de> Vorbehalt EIS und die Registry CNNIC behalten sich vor, Registrierungen nach eigenem Ermessen zurückzuweisen, zu löschen oder zu übertragen, sofern dies zur Aufrechterhaltung des ordnungsgemäßen Betriebs der Registry, zur Einhaltung gesetzlicher oder behördlicher Vorschriften, auf staatsanwaltliche Anordnung, im Rahmen der oben genannten Regelungen oder zur Vermeidung einer zivil- oder strafrechtlichen Haftung von EIS oder die Registry CNNIC oder deren Mitarbeitern erforderlich ist.
<G-vec00198-002-s425><cancel.löschen><en> Besides, you can close or cancel the alike data of browser add-ons like Flash cookies by changing its setting or visiting other manufactures’websites.
<G-vec00198-002-s425><cancel.löschen><de> Außerdem können Sie ähnliche Daten von Browser-Add-ons wie Flash-Cookies schließen oder löschen, indem Sie die Einstellungen ändern oder die Websites anderer Hersteller besuchen.
<G-vec00198-002-s426><cancel.löschen><en> Bug fixed: [-]Program crashed when click "Cancel" during Previewing or Publishing the tour.
<G-vec00198-002-s426><cancel.löschen><de> Bug beheben: [-] Die Software beim Anklicken von “Löschen” abstürzt, wenn der Rundgang vorgeschaut oder veröffentlicht wird.
<G-vec00198-002-s427><cancel.löschen><en> The monitoring technologies may be of permanent (i.e. the files will remain on your computer or device till you cancel them) or session character (i.e. the files will remain till browser closing).
<G-vec00198-002-s427><cancel.löschen><de> Überwachungstechnologien können persistent (d.h. Dateien bleiben auf Ihrem Computer oder Gerät, bis Sie sie löschen) oder sitzungsbezogen sein (d.h. Dateien bleiben nur so lange erhalten, bis Sie Ihren Browser schließen).
<G-vec00198-002-s523><cancel.stornieren><en> If you cancel your order and payment has been taken from you, we will refund you the full amount you have paid as soon as possible.
<G-vec00198-002-s523><cancel.stornieren><de> Wenn Sie Ihre Bestellung stornieren und wir bereits die Zahlung an uns veranlasst haben, werden wir Ihnen die von Ihnen gezahlte Summe in voller Höhe sobald wie möglich zurückerstatten.
<G-vec00198-002-s524><cancel.stornieren><en> The cardholder has the right to cancel an unauthorised credit card payment by reversing the transaction.
<G-vec00198-002-s524><cancel.stornieren><de> Der Karteninhaber hat sehr wohl das Recht, dass er eine unberechtigte Kreditkartenzahlung durch Rückbuchung wieder stornieren kann.
<G-vec00198-002-s525><cancel.stornieren><en> If you wish to cancel your booking then please contact us with the following form.
<G-vec00198-002-s525><cancel.stornieren><de> Wenn Sie eine Buchung stornieren möchten, können Sie uns über folgendes Formular kontaktieren.
<G-vec00198-002-s526><cancel.stornieren><en> Allowing customers to cancel with no penalties and providing a best price guarantee are two ways that companies are tackling this issue.
<G-vec00198-002-s526><cancel.stornieren><de> Viele Unternehmen ermöglichen es Nutzern aus diesem Grund, Buchungen gebührenfrei zu stornieren, und bieten eine Bestpreisgarantie an.
<G-vec00198-002-s527><cancel.stornieren><en> By clicking 'Register', 'Connect with Facebook' or 'Connect with Google', you confirm that you accept the Terms and Conditions fee if you cancel the booking at least 4 days before check-in by 12 noon CET (Central European Time).
<G-vec00198-002-s527><cancel.stornieren><de> Durch Klicken auf „Registrieren“, „Mit Facebook anmelden“ oder „Mit Google anmelden“ Sie bekommen den Buchungsbetrag abzüglich der Stornierungsgebühr zurückerstattet, wenn Sie die Buchung mindestens 4 Tage vor dem geplanten Check-in bis 12 Uhr mittags MEZ (Mitteleuropäische Zeit) stornieren.
<G-vec00198-002-s528><cancel.stornieren><en> If you change your mind and want to cancel your order before the receipt of goods, it might be possible to cancel if your order has not been sent out yet.
<G-vec00198-002-s528><cancel.stornieren><de> Wenn du vor dem Erhalt deiner Ware deine Bestellung stornieren möchtest, dann ist dies nur möglich, wenn sich dein Paket noch nicht auf dem Postweg befindet.
<G-vec00198-002-s529><cancel.stornieren><en> Find the order that you want to cancel.
<G-vec00198-002-s529><cancel.stornieren><de> Suche nach der Bestellung, die du stornieren möchtest.
<G-vec00198-002-s530><cancel.stornieren><en> You can change or cancel your reservation by contacting us by email.
<G-vec00198-002-s530><cancel.stornieren><de> Sie können Ihre Reservierung ändern oder stornieren, indem Sie uns per E-Mail kontaktieren.
<G-vec00198-002-s531><cancel.stornieren><en> Unfortunately, after receipt of the Shipping Confirmation email, you will not be able to cancel your order.
<G-vec00198-002-s531><cancel.stornieren><de> Leider können Sie Ihre Bestellung nach dem Eingang der Versandbestätigung nicht mehr stornieren.
<G-vec00198-002-s532><cancel.stornieren><en> We reserve the right to cancel such reservations without refund.
<G-vec00198-002-s532><cancel.stornieren><de> Wir behalten uns das Recht vor, solche Reservierungen ohne Rückerstattung zu stornieren.
<G-vec00198-002-s533><cancel.stornieren><en> You may cancel the booking free of charge 24 hours before the start of the rental time, in this case, the money will be returned to your account in full.
<G-vec00198-002-s533><cancel.stornieren><de> Der Gesamtmietpreis ist zu zahlen, wenn Sie versuchen, ab dem Zeitpunkt des Mietbeginns zu stornieren.
<G-vec00198-002-s534><cancel.stornieren><en> In the booking confirmation email, click on the "Cancel reservation" link that will show you your online reservation.
<G-vec00198-002-s534><cancel.stornieren><de> Klicke in der Buchungsbestätigungs-E-Mail auf den Link "Reservierung stornieren", um deine Online-Reservierung anzuzeigen.
<G-vec00198-002-s535><cancel.stornieren><en> If you cancel your order for a fragrance or nail polish item and return the item(s) using any other collection or postal service, you will be required to pay the costs of returning the item(s).
<G-vec00198-002-s535><cancel.stornieren><de> Wenn Sie die Bestellung eines Duft- oder Nail Polish-Artikels stornieren, müssen Sie die Kosten für die Rückgabe der Artikel selbst übernehmen.
<G-vec00198-002-s536><cancel.stornieren><en> If you plan to check-in after 9:00 p.m., please notify us so we do not cancel your reservation.
<G-vec00198-002-s536><cancel.stornieren><de> Wenn Sie nach 21:00 Uhr anreisen möchten, teilen Sie uns bitte, damit wir nicht Ihre Reservierung stornieren.
<G-vec00198-002-s537><cancel.stornieren><en> This means that Hairback may refuse to accept, or may cancel, any order, whether or not it has been confirmed, without liability to you or any third party.
<G-vec00198-002-s537><cancel.stornieren><de> Hairback kann die Bestellung jederzeit verweigern oder auch ohne Haftung Ihnen oder Dritten gegenüber stornieren - selbst wenn diese bereits bestätigt wurde.
<G-vec00198-002-s538><cancel.stornieren><en> We reserve the right to cancel the reservation and refund all monies paid, but this of course will be without any liability to you.
<G-vec00198-002-s538><cancel.stornieren><de> Wir behalten uns das Recht vor, die Buchung zu stornieren und alle Zahlungen zurückzuerstatten, selbstverständlich ohne dass dies ihrerseits irgendeine Verantwortung mit sich bringt.
<G-vec00198-002-s539><cancel.stornieren><en> You can cancel your reservation for free until 7 days before your arrival.
<G-vec00198-002-s539><cancel.stornieren><de> Sie können Ihre Reservierung bis 7 tage vor Ihrer Ankunft kostenlos stornieren.
<G-vec00198-002-s540><cancel.stornieren><en> Where permitted by the fare conditions corresponding to a particular fare basis, a Contact Person may change and/or cancel BlueBiz Tickets via the BlueBiz Service Desk prior to the flight’s departure.
<G-vec00198-002-s540><cancel.stornieren><de> Sofern die Tarifbedingungen einer bestimmten Buchungsklasse dies erlauben, kann die Kontaktperson Prämientickets vor Reiseantritt über den BlueBiz Service Desk umbuchen und/oder stornieren.
<G-vec00198-002-s541><cancel.stornieren><en> Acne Studios always reserves the right to cancel any order prior to our acceptance of the order.
<G-vec00198-002-s541><cancel.stornieren><de> Acne Studios behält sich immer das Recht vor, jede Bestellung vor unserer Annahme der Bestellung zu stornieren.
<G-vec00198-002-s542><cancel.stornieren><en> If you cancel your holiday, we will charge you the cancellation costs according to our conditions.
<G-vec00198-002-s542><cancel.stornieren><de> Wenn du deine Reise stornierst, stellen wir dir eine Stornierungsgebühr in Rechnung (mehr Informationen dazu findest du weiter unten).
<G-vec00198-002-s543><cancel.stornieren><en> If you cancel your booking up to 28 days before the start date, you will receive 80% of the total amount back.
<G-vec00198-002-s543><cancel.stornieren><de> Wenn du deine Buchung bis zu 28 Tage vor dem Starttermin stornierst, erhältst du 80% des Gesamtbetrages zurück.
<G-vec00198-002-s544><cancel.stornieren><en> If you don’t cancel the deletion, your account and all your training data will be deleted permanently after six months.
<G-vec00198-002-s544><cancel.stornieren><de> Wenn du die Löschung nicht stornierst, werden dein Konto und alle deine Trainingsdaten nach sechs Monaten endgültig gelöscht.
<G-vec00198-002-s545><cancel.stornieren><en> If you cancel and the Workshop is otherwise filled, we will refund you the full amount you have paid towards the tuition, minus a $300 service charge.
<G-vec00198-002-s545><cancel.stornieren><de> Wenn du stornierst und der Workshop trotzdem voll ausgebucht ist, erstatten wir dir den kompletten Betrag für deine Teilnahme abzüglich einer Bearbeitungsgebühr von $300 zurück.
<G-vec00198-002-s546><cancel.stornieren><en> If you cancel or modify your reservation up to 7 days before the arrival date the establishment will charge only the paid deposit.
<G-vec00198-002-s546><cancel.stornieren><de> Wenn du die Buchung bis zu 7 Tage vor dem Anreisetag stornierst oder änderst, wird die Anzahlung für die Unterkunft einbehalten.
<G-vec00198-002-s547><cancel.stornieren><en> As a seller, if you're unable to complete a transaction, we encourage you to notify the buyer via Etsy Conversations and cancel the transaction.
<G-vec00198-002-s547><cancel.stornieren><de> Wenn du eine Bestellung nicht ausführen kannst, solltest du den Käufer über Nachrichten auf Etsy benachrichtigen, bevor du die Transaktion stornierst.
<G-vec00198-002-s548><cancel.stornieren><en> But depending on the time you cancel a cancellation fee may apply.
<G-vec00198-002-s548><cancel.stornieren><de> Aber abhängig von der Zeit zu der du stornierst, könnte eine Stornogebühr anfallen.
<G-vec00198-002-s549><cancel.stornieren><en> You will be refunded half of the booking amount if you cancel the booking at least 7 days before check-in (by 12 noon, local time).
<G-vec00198-002-s549><cancel.stornieren><de> Du bekommst die Hälfte des Buchungsbetrages abzüglich der Wimdu-Stornierungsgebühr zurückerstattet, wenn du die Buchung mindestens 7 Tage vor Check-in (12 Uhr mittags, Ortszeit) stornierst.
<G-vec00198-002-s550><cancel.stornieren><en> You will be refunded the booking amount if you cancel the booking at least 4 days before check-in (by 12 noon, local time).
<G-vec00198-002-s550><cancel.stornieren><de> Du bekommst den Buchungsbetrag abzüglich der Wimdu-Stornierungsgebühr zurückerstattet, wenn du die Buchung mindestens 4 Tage vor Check-in (12 Uhr mittags, Ortszeit) stornierst.
<G-vec00198-002-s551><cancel.stornieren><en> If you cancel the order, no ship will be built; the parts will remain in storage.
<G-vec00198-002-s551><cancel.stornieren><de> Wenn du den Auftrag stornierst, wird kein Schiff gebaut; die Raumschiffteile bleiben im Lager.
<G-vec00198-002-s552><cancel.stornieren><en> And we’ll email to confirm if you fully or partially cancel your order.
<G-vec00198-002-s552><cancel.stornieren><de> Und wir senden dir eine E-Mail, wenn du deine Bestellung komplett oder teilweise stornierst.
<G-vec00198-002-s553><cancel.stornieren><en> If you cancel afterwards or do not show up, the fee will be completely charged.
<G-vec00198-002-s553><cancel.stornieren><de> Falls Du später stornierst oder nicht erscheinst wird die Sitzungsgebühr wie üblich vollständig in Rechnung gestellt.
<G-vec00198-002-s554><cancel.stornieren><en> You will be refunded half of the total price minus the Wimdu cancellation fee if you cancel the booking at least 7 days before check-in (by 12 noon, local time).
<G-vec00198-002-s554><cancel.stornieren><de> Beispiel: Freitag Freitag 12:00Uhr Du bekommst den Buchungsbetrag zur Hälfte zurückerstattet, wenn du die Buchung mindestens 7 Tage vor Check-in (12 Uhr mittags, Ortszeit) stornierst.
<G-vec00198-002-s555><cancel.stornieren><en> This means that if you cancel your ticket within 24 hours, you get your money back.
<G-vec00198-002-s555><cancel.stornieren><de> Das bedeutet, dass Du Dein Geld zurückbekommst, wenn Du Dein Ticket innerhalb von 24 Stunden stornierst.
<G-vec00198-002-s556><cancel.stornieren><en> If you cancel a reservation as a host, an automatic review appears on your listing indicating that a reservation was canceled.
<G-vec00198-002-s556><cancel.stornieren><de> Wenn Du eine Reservierung als Gastgeber stornierst, wird automatisch eine Bewertung auf Deinem Inserat erscheinen, welche auf die Stornierung hinweist.
<G-vec00198-002-s557><cancel.stornieren><en> If the owner does not cancel his Card Club, the subscruption will be automatically renewed for a year.
<G-vec00198-002-s557><cancel.stornieren><de> Wenn der Besitzer seinen Card Club nicht storniert, wird die Vertragsunterzeichnung automatisch um ein Jahr verlängert.
<G-vec00198-002-s558><cancel.stornieren><en> You may cancel a booked session with at least 24 hours’ notice.
<G-vec00198-002-s558><cancel.stornieren><de> Eine gebuchte Sitzung kann mindestens 24 Stunden im Voraus storniert werden.
<G-vec00198-002-s559><cancel.stornieren><en> Please note that the property will cancel the reservation if you do not arrive by 6 p.m. and do not warn the property about your late arrival.
<G-vec00198-002-s559><cancel.stornieren><de> Bitte beachten Sie, dass die Unterkunft Ihre Buchung storniert, falls Sie nicht bis 18:00 Uhr eintreffen und keine späte Anreise vereinbart wurde.
<G-vec00198-002-s560><cancel.stornieren><en> If ticket was purchased using Bonus points (50% or 100%), bonus points are non-refundable. To cancel journey is possible:
<G-vec00198-002-s560><cancel.stornieren><de> Wenn man die Fahrkarten storniert, die mit 50% oder 100% von den gesammelten Bonuspunkten gekauft wurden, so werden die Bonuspunkten nicht zurückerstattet.
<G-vec00198-002-s561><cancel.stornieren><en> The scammer will ask you to transfer the cash difference back tom him, will cancel the cheque after a few days and thus, recall the money.
<G-vec00198-002-s561><cancel.stornieren><de> Der Betrüger wird Sie bitten, ihm die Differenz zurück zu überweisen, storniert den Scheck anschließend nach einigen Tagen und ruft so das Geld zurück.
<G-vec00198-002-s562><cancel.stornieren><en> Group Booking Policy: For bookings of 5 rooms or more. Group bookings can cancel free of charge 4 weeks before arrival, after that they must pay 100%.
<G-vec00198-002-s562><cancel.stornieren><de> Richtlinien für Gruppenbuchungen: Bei Buchungen von 5 Zimmern oder mehr können Gruppenbuchungen kostenlos 4 Wochen vor der Ankunft storniert werden; nach diesem Zeitraum wird 100% des Buchungsbetrags fällig.
<G-vec00198-002-s563><cancel.stornieren><en> Ctrip cannot guarantee ticket availability or cancel or modify tickets after issue.
<G-vec00198-002-s563><cancel.stornieren><de> Bereits ausgestellte Tickets können nicht von Ctrip abgeändert oder storniert werden.
<G-vec00198-002-s564><cancel.stornieren><en> This will cancel the original booking and send them an email with a gift card for the value or their bookings.
<G-vec00198-002-s564><cancel.stornieren><de> Hierdurch wird die ursprüngliche Buchung storniert und eine E-Mail mit einer Geschenkkarte für den Wert der ursprünglichen Buchungen versendet.
<G-vec00198-002-s565><cancel.stornieren><en> If you are unable to use your room and fail to cancel your reservation, or if you do not claim the room by the specified time, Choice will not credit your account with the points that you redeemed for that room.
<G-vec00198-002-s565><cancel.stornieren><de> Wenn Sie Ihr Zimmer nicht in Anspruch nehmen und Ihre Reservierung nicht bis zum vereinbarten Zeitpunkt storniert haben, oder wenn Sie Ihr Zimmer bis zur angegebenen Zeit nicht in Anspruch nehmen, erhalten Sie die für dieses Zimmer eingelösten Punkte nicht wieder von Choice gutgeschrieben.
<G-vec00198-002-s566><cancel.stornieren><en> Lenovo will contact you and cancel your order if the product becomes unavailable or if there was a pricing or typographic error.
<G-vec00198-002-s566><cancel.stornieren><de> Falls ein Produkt nicht mehr verfügbar oder ein Preis- oder Tippfehler aufgetreten ist, nimmt Digital River Kontakt zu Ihnen auf und storniert Ihre Bestellung.
<G-vec00198-002-s567><cancel.stornieren><en> An information portal with facts about the ski area, webcams and events along with an area for members enhances the convenience – you can call up your own statistics and history at any time, change or cancel your orders.
<G-vec00198-002-s567><cancel.stornieren><de> Ein Info-Portal mit Fakten zum Skigebiet, Webcams und Events sowie ein Member-Bereich ergänzen den Komfort: Eigene Statistiken und Historien können jederzeit ganz bequem abgerufen, Bestellungen geändert oder storniert werden.
<G-vec00198-002-s568><cancel.stornieren><en> As long as your order has not been dispatched, it is also possible to completely cancel the order.
<G-vec00198-002-s568><cancel.stornieren><de> Solange eine Bestellung noch nicht versandt wurde, kann diese auch komplett storniert werden.
<G-vec00198-002-s569><cancel.stornieren><en> In the event that a customer does not arrive or does not cancel on time, the hotel has the option of charging a cancellation fee against the credit card.
<G-vec00198-002-s569><cancel.stornieren><de> Für den Fall, dass der Kunde nicht anreist oder nicht rechtzeitig storniert, hat das Hotel damit die Möglichkeit, die Kreditkarte mit einer Stornierungsgebühr zu belasten.
<G-vec00198-002-s570><cancel.stornieren><en> Please be advised that you are not able to change or cancel the booking without losing the full deposit.
<G-vec00198-002-s570><cancel.stornieren><de> Bitte beachten Sie, dass die Buchung nicht geändert oder storniert werden kann ohne den vollen Betrag zu verlieren.
<G-vec00198-002-s571><cancel.stornieren><en> In the unlikely event that we are to cancel your booking we will notify you and we will provide a full refund.
<G-vec00198-002-s571><cancel.stornieren><de> In dem unwahrscheinlichen Fall, dass Ihre Buchung storniert werden muss, informieren wir Sie, und Sie erhalten eine volle Erstattung.
<G-vec00198-002-s572><cancel.stornieren><en> If a guest does not cancel and does not turn up, they will receive no refund.
<G-vec00198-002-s572><cancel.stornieren><de> Wenn ein Gast nicht storniert und nicht erscheint, wird keine Rückerstattung gewährt.
<G-vec00198-002-s573><cancel.stornieren><en> FBDi Chairman of the board, Georg Steinberger: „Under normal circumstances a book-to-bill rate of 1.16 for the year would indicate a solid growth in 2018. But, as some customers postpone or cancel their orders depending on shortage and availability, there is a possibility for a small disillusion throughout the year.
<G-vec00198-002-s573><cancel.stornieren><de> FBDi-Vorstandsvorsitzender Georg Steinberger: „Eine Jahres-Book-to-Bill-Rate von 1,16 würde unter normalen Umständen auf ein recht ansehnliches Wachstum in 2018 schließen lassen, da aber Aufträge von Kunden je nach Knappheitssituation und Verfügbarkeits-Entwicklung gern auch verschoben oder storniert werden, könnte es im Jahresverlauf eine kleine Ernüchterung geben.
<G-vec00198-002-s574><cancel.stornieren><en> In general it is possible to cancel regular bookings free of charge up to 24 hours before your arrival.
<G-vec00198-002-s574><cancel.stornieren><de> Generell können reguläre Buchungen bei uns bis 24 Stunden vor der Anreise kostenfrei storniert werden.
<G-vec00198-002-s575><cancel.stornieren><en> Using the cancellation function it is now possible to "cancel" articles that have already been posted.
<G-vec00198-002-s575><cancel.stornieren><de> Mit der Storno Funktion können jetzt schon gebuchte Artikel 'storniert' werden.
<G-vec00198-002-s709><cancel.stornieren><en> If as a consequence of Force Majeure, CARIBBEAN TRAVEL NETWORK N.V. is obliged to curtail, alter or cancel a booking and/or any services agreed, the partner and/or client/customer shall not be entitled to claim compensation for any loss arising as a consequence of the said curtailment, alteration or cancellation.
<G-vec00198-002-s709><cancel.stornieren><de> HÖHERE GEWALT Wenn sich CARIBBEAN TRAVEL NETWORK N.V. auf Grund von höherer Gewalt gezwungen sehen sollte, eine Buchung oder einen vereinbarten Service einzuschränken, zu verändern oder zu stornieren, wird der Geschäftspartner oder Kunde kein Recht haben, für die durch die erwähnten Einschränkungen, Veränderungen oder Stornierungen hervorgerufenen Schäden eine Entschädigung zu fordern.
<G-vec00198-002-s710><cancel.stornieren><en> Cancellation policy When you place your order via the oinomelos.com e-shop, you may cancel your order within 24 hours.
<G-vec00198-002-s710><cancel.stornieren><de> Wenn Sie Ihre Bestellung über den Online-Shop oinomelos.com aufgeben, haben Sie die Möglichkeit, Ihre Bestellung am selben Tag zu stornieren, an dem Sie die Bestellung aufgegeben haben.
<G-vec00198-002-s711><cancel.stornieren><en> 3.3.2 The User can however, solely in those instances and under the conditions defined in Article 4 and Article 5 of these GCS, or in the event of Force Majeure, change or cancel an order or booking made on the Site.
<G-vec00198-002-s711><cancel.stornieren><de> 3.3.2 Dennoch hat der Nutzer die Möglichkeit, unter den in Artikel 4 und Artikel 5 der vorliegenden AGB beschriebenen Voraussetzungen und Bedingungen oder im Falle einer Höheren Gewalt, eine auf der Site abgeschlossene Bestellung oder Reservierung abzuändern oder zu stornieren.
<G-vec00198-002-s712><cancel.stornieren><en> GoDaddy reserves the right to deny use of any offer and/or cancel products purchased using any offer if the offer is abused or used fraudulently, as determined by GoDaddy in its sole discretion.
<G-vec00198-002-s712><cancel.stornieren><de> GoDaddy behält sich das Recht vor, nach seinem alleinigem Ermessen Kunden die Nutzung dieses Angebots zu versagen und/oder über dieses Angebot erworbene Produkte zu stornieren, wenn das Angebot in missbräuchlicher oder betrügerischer Weise genutzt wird.
<G-vec00198-002-s713><cancel.stornieren><en> Natrul Health Group, LLC reserves the right to refuse or cancel any such orders whether or not the order has been confirmed and your credit card charged.
<G-vec00198-002-s713><cancel.stornieren><de> Balsam Hill LLC behält sich vor, diese Bestellungen zu stornieren oder deren Bearbeitung zu verweigern, unabhängig davon, ob die Bestellung bestätigt und Ihre Kreditkarte bereits belastet wurde.
<G-vec00198-002-s714><cancel.stornieren><en> In case a different price applies, you can cancel your reservation (within 24 hours) without any charge.
<G-vec00198-002-s714><cancel.stornieren><de> Falls ein anderer Preis zutreffend ist, dann gibt es die Möglichkeit um innerhalb von 24 Stunden gebührenfrei zu stornieren.
<G-vec00198-002-s715><cancel.stornieren><en> 6) The Client may cancel an Order if it has not been executed yet, within 6 hours as of placing the Order (by phone or e-mail.
<G-vec00198-002-s715><cancel.stornieren><de> 6) Es besteht die Möglichkeit die Bestellung durch den Kunden zu stornieren, wenn die Bestellung noch nicht realisiert wurde, 6 Stunden ab dem Eingang der Bestellung (telefonisch oder per E-mail).
<G-vec00198-002-s716><cancel.stornieren><en> In such cases you will be contacted and informed about this, giving you the opportunity to either wait for more stock, cancel the item/order or order another item.
<G-vec00198-002-s716><cancel.stornieren><de> In solchen Fällen kontaktieren und informieren wir Sie, so dass Sie die Möglichkeit haben, entweder zu warten, bis der Artikel wieder erhältlich ist, die Bestellung zu stornieren oder einen anderen zu kaufen.
<G-vec00198-002-s717><cancel.stornieren><en> The order will of course still be active in the system, but we recommend that you cancel the booking or credit voucher, and contact the end customer directly to clarify payment.
<G-vec00198-002-s717><cancel.stornieren><de> Die Bestellung ist dann natürlich noch aktiv im System, aber wir empfehlen dir die Buchung oder den Gutschein zu stornieren und den Endkunden direkt zu kontaktieren, um die Zahlung zu klären.
<G-vec00198-002-s718><cancel.stornieren><en> In such a case please cancel your reservation and make a new one.
<G-vec00198-002-s718><cancel.stornieren><de> Bei solchen Fällen bitten wir Sie Ihre Buchung zu stornieren und eine neue Reservation vorzunehmen.
<G-vec00198-002-s719><cancel.stornieren><en> We reserve the right to refuse or cancel your order at any time for certain reasons including but not limited to: product or service availability, errors in the description or price of the product or service, error in your order or other reasons.
<G-vec00198-002-s719><cancel.stornieren><de> Wir behalten uns das Recht vor, Ihre Bestellung jederzeit aus bestimmten Gründen einschließlich, aber nicht beschränkt auf: Produkt- oder Serviceverfügbarkeit, Irrtümer bei der Beschreibung oder dem Preis des Produktes oder der Dienstleistung, Fehler in Ihrer Bestellung oder aus anderen Gründen abzulehnen oder zu stornieren.
<G-vec00198-002-s720><cancel.stornieren><en> 5.3 In case of delay of payment by the buyer, DT Swiss is also entitled to suspend or cancel all further orders by the buyer.
<G-vec00198-002-s720><cancel.stornieren><de> 5.3 Bei Zahlungsverzug des Käufers ist DT Swiss außerdem berechtigt, die Ausführung aller weiteren Bestellungen des Käufers aufzuschieben oder zu stornieren.
<G-vec00198-002-s721><cancel.stornieren><en> The Customer may modify or cancel his or her order;
<G-vec00198-002-s721><cancel.stornieren><de> Der Kunde hat die Möglichkeit, die Bestellung abzuändern oder zu stornieren.
<G-vec00198-002-s722><cancel.stornieren><en> Fully automated booking procedures, with real time availability, immediate on-line confirmations with the ability to create, modify or cancel bookings.
<G-vec00198-002-s722><cancel.stornieren><de> Vollautomatische Buchungsprozedur, mit Echtzeit Verfügbarkeit, sofortige online Bestätigungen und die Möglichkeit Buchungen zu ermöglichen, zu ändern oder zu stornieren.
<G-vec00198-002-s595><cancel.streichen><en> As commercial airlines cancel flights around the world due to the coronavirus outbreak, leisure and business travelers increasingly end up with private jet companies.
<G-vec00198-002-s595><cancel.streichen><de> Da kommerzielle Fluggesellschaften wegen des Coronavirus-Ausbruchs Flüge in der ganzen Welt streichen, enden Freizeit- und Geschäftsreisende immer öfter bei Privatjet-Firmen.
<G-vec00198-002-s596><cancel.streichen><en> Notwithstanding any other rights (whether deriving from statutory or other provisions), Juvalia shall reserve the right to cancel your order and/or deny you the access to the Juvalia website if you are in breach of these Terms and Conditions of Use.
<G-vec00198-002-s596><cancel.streichen><de> Unbeschadet sonstiger Rechte (unabhängig davon, ob sie auf Gesetz oder sonstigen Vorschriften beruhen) behält sich Juvalia das Recht vor, Ihre Bestellungen zu streichen und/oder Ihnen den Zugriff auf Juvalia-Website zu untersagen, wenn Sie gegen diese Nutzungsbedingungen verstoßen haben.
<G-vec00198-002-s597><cancel.streichen><en> If you have not paid for the Ticket prior to specified ticketing time limit, as advised by us or the travel agency which issued the Ticket we may cancel your reservation.
<G-vec00198-002-s597><cancel.streichen><de> Wenn Sie den Flugpreis nicht bis zu dem mit uns oder dem Flugschein austellenden Reisebüro vereinbarten Zeitpunkt bezahlt haben, so können wir Ihre Flugbuchung streichen.
<G-vec00198-002-s598><cancel.streichen><en> So they decided to cancel all exit options and bring students to arms.
<G-vec00198-002-s598><cancel.streichen><de> Deshalb entschieden sie, alle Ausweichmöglichkeiten zu streichen und die Studenten zu den Waffen zu bringen.
<G-vec00198-002-s599><cancel.streichen><en> The safety measures were rather severe and as one of these measures they wanted to cancel our protest.
<G-vec00198-002-s599><cancel.streichen><de> Die Sicherheitsvorkehrungen waren sehr streng und eine der ersten Vorkehrungen war, dass sie unseren Protest streichen wollten.
<G-vec00198-002-s600><cancel.streichen><en> If you don’t take your outbound flight, without advising us in advance, or fail to cancel the flight before the Check-In Deadline, we will cancel your return or onward reservations.
<G-vec00198-002-s600><cancel.streichen><de> Treten Sie einen Flug nicht an, ohne uns dies im Voraus anzuzeigen, oder stornieren Sie einen Flug nicht vor Ende der Meldeschlusszeit, so streichen wir Ihre Buchungen für Rück- oder Weiterflüge.
<G-vec00198-002-s601><cancel.streichen><en> But since my last visit in May, we had to cancel this project.
<G-vec00198-002-s601><cancel.streichen><de> Doch seit meinem letzten Besuch im Mai, mussten wir dieses Projekt streichen.
<G-vec00198-002-s602><cancel.streichen><en> We reserve the right to cancel your reservations if you do not meet the Check-in deadlines indicated.
<G-vec00198-002-s602><cancel.streichen><de> Wir behalten uns vor, Ihre Buchungen zu streichen, wenn Sie den angegebenen Meldeschluss nicht einhalten.
<G-vec00198-002-s603><cancel.streichen><en> If a reconfirmation is required and you fail to do so, we may cancel your onward or return flight reservations.
<G-vec00198-002-s603><cancel.streichen><de> Wenn eine Rückbestätigung verlangt wird und Sie diese unterlassen, können wir Ihre Buchungen für die Weiterreise streichen.
<G-vec00198-002-s604><cancel.streichen><en> In case this is not met, we reserve the right to cancel the reservation.
<G-vec00198-002-s604><cancel.streichen><de> Falls dies nicht erfolgt, sind wir berechtigt die Buchung zu streichen.
<G-vec00198-002-s605><cancel.streichen><en> If the track doesn't hold, we will leave it at one downhill training and cancel the second training run", Waldner concludes.
<G-vec00198-002-s605><cancel.streichen><de> Sollte die Piste nicht halten, belassen wir es bei einem Abfahrtstraining und streichen den zweiten Trainingslauf“, so Waldner abschließend.
<G-vec00198-002-s606><cancel.streichen><en> Incredibly disappointing that Mayor Geisel has decided to cancel the "Max Stern: From Dusseldorf to Montreal" exhibition scheduled to open in February.
<G-vec00198-002-s606><cancel.streichen><de> Unglaublich enttäuschend, dass Bürgermeister Geisel beschlossen hat, die im Februar eröffnete Ausstellung "Max Stern: Von Düsseldorf nach Montreal" zu streichen.
<G-vec00198-002-s607><cancel.streichen><en> To cancel them would lead to a 40 percent reduction of greenhouse gas emissions that are necessary to reach the goal of limiting global warming to two degrees.
<G-vec00198-002-s607><cancel.streichen><de> Sie zu streichen, das brächte 40 Prozent der Reduktion von Treibhausgas-Emissionen, die nötig seien zur Erreichung des Ziels einer Begrenzung der globalen Erwärmung auf zwei Grad.
<G-vec00198-002-s608><cancel.streichen><en> In order to guarantee the safety of the athletes the organization of Bordairrace has the right to cancel the 20% flight rule when weather forecasts are unfavourable.
<G-vec00198-002-s608><cancel.streichen><de> Die Wettbewerbsleitung behält es sich vor, den 20% Fluganteil, um die Sicherheit des Bewerbes zu gewährleisten, teils oder ganz zu streichen.
<G-vec00198-002-s609><cancel.streichen><en> But if you do advise us in advance that you will not be taking the initial flight concerned, we will not cancel any subsequent flight reservations.
<G-vec00198-002-s609><cancel.streichen><de> Wenn Sie uns jedoch im Voraus benachrichtigen, streichen wir Ihre nachfolgenden Flugbuchungen nicht.
<G-vec00198-002-s610><cancel.streichen><en> If you do not appear at your gate on time, we reserve the right to cancel your booking.
<G-vec00198-002-s610><cancel.streichen><de> Sofern Sie nicht rechtzeitig zum Einstieg erscheinen, sind wir berechtigt, Ihre Buchung zu streichen.
<G-vec00198-002-s611><cancel.streichen><en> But in recent weeks he has hinted he wants to cut social benefits paid to foreign EU nationals in Britain and to cancel the EU guideline on working hours.
<G-vec00198-002-s611><cancel.streichen><de> In den vergangenen Wochen hatte er aber angedeutet, unter anderem die Sozialleistungen von EU-Migranten beschneiden zu wollen und die EU-Arbeitszeitrichtlinie zu streichen.
<G-vec00198-002-s612><cancel.streichen><en> That's why, in this case here, it is rather luck, that the first band is forced to cancel their stint due to illness of the frontman.
<G-vec00198-002-s612><cancel.streichen><de> Deshalb ist es, so wie hier allemal fast so was wie ein Glücksfall, dass der erste Anheizer wegen Krankheit, die Segel streichen musste.
<G-vec00198-002-s613><cancel.streichen><en> 10.3 If you do not appear at the gate punctually, Lufthansa is entitled to cancel your booking.
<G-vec00198-002-s613><cancel.streichen><de> 10.3 Sofern Sie nicht rechtzeitig zum Einsteigen erscheinen, ist Lufthansa berechtigt, Ihre Buchung zu streichen.
<G-vec00198-002-s633><cancel.widerrufen><en> Right to cancel You have the right to cancel the contract within 14 days without giving any reason.
<G-vec00198-002-s633><cancel.widerrufen><de> Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gruenden diesen Vertrag zu widerrufen.
<G-vec00198-002-s634><cancel.widerrufen><en> You have the right to cancel this contract within 1 month without giving any reason.
<G-vec00198-002-s634><cancel.widerrufen><de> Sie haben das Recht, binnen vierzehn Tagen ohne Angaben von Gründen diesen Vertrag zu widerrufen.
<G-vec00198-002-s635><cancel.widerrufen><en> If you cancel this contract, we shall refund to you any payments received from you, including delivery costs (with the exception of any additional costs incurred by you choosing a type of delivery other than the standard, cheapest delivery offered by us), immediately and at the latest within fourteen days from the day on which we receive notification of your cancellation of this contract.
<G-vec00198-002-s635><cancel.widerrufen><de> Wenn Sie diesen Vertrag widerrufen, haben ich Ihnen alle Zahlungen, die ich von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lieferung als die von mir angebotene, günstigste Standardlieferung gewählt haben), unverzüglich und spätestens binnen 14 Tage ab dem Tag zurückzuzahlen, an dem die Mitteilung über Ihren Widerruf dieses Vertrags bei mir eingegangen ist.
<G-vec00198-002-s636><cancel.widerrufen><en> Please cancel your order in writing or by e-mail.
<G-vec00198-002-s636><cancel.widerrufen><de> Bitte widerrufen Sie hierzu Ihre Bestellung schriftlich oder per E-Mail.
<G-vec00198-002-s637><cancel.widerrufen><en> (If you want to cancel the contract, please complete this form and send it back.)
<G-vec00198-002-s637><cancel.widerrufen><de> Wenn Sie den Vertrag widerrufen wollen, dann füllen Sie bitte dieses Formular aus und senden es zurück.
<G-vec00198-002-s638><cancel.widerrufen><en> If you cancel this contract, we have to immediately refund all payments received from you, including delivery costs (with the exception of any additional costs incurred due to your having chosen a different type of delivery than the cost-effective standard delivery that we offer). This must be done no later than within fourteen days from the date when we receive your notice of cancellation.
<G-vec00198-002-s638><cancel.widerrufen><de> Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lieferung als die von uns angebotene, günstigste Standardlieferung gewählt haben), unverzüglich und spätestens binnen vierzehn Tagen ab dem Tag zurückzuzahlen, an dem die Mitteilung über Ihren Widerruf dieses Vertrags bei uns eingegangen ist.
<G-vec00198-002-s639><cancel.widerrufen><en> If you cancel this contract, we shall reimburse to you all payments received from you, including the costs of delivery (with the exception of the supplementary costs resulting from your choice of a type of delivery other than the least expensive type of standard delivery offered by us), without undue delay and in any event not later than 14 days from the day on which we are informed about your decision to cancel this contract.
<G-vec00198-002-s639><cancel.widerrufen><de> Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lie-ferung als die von uns angebotene, günstigste Standardlieferung gewählt ha-ben) unverzüglich und spätestens in 14 Tagen ab dem Tag zurückzuzahlen, an dem die Mitteilung über den Widerruf dieses Vertrags bei uns eingegangen ist.
<G-vec00198-002-s640><cancel.widerrufen><en> (2) In the event that our orders are not confirmed within eight days of submission specifying a binding delivery date, we reserve the right to cancel the order without any obligation on our part.
<G-vec00198-002-s640><cancel.widerrufen><de> (2) Für den Fall, dass unsere Bestellungen nicht innerhalb von 8 Tagen nach Zugang unter verbindlicher Angabe des Liefertermins bestätigt werden, behalten wir uns vor die Bestellung ohne Verpflichtung für uns zu widerrufen.
<G-vec00198-002-s641><cancel.widerrufen><en> Soon after the meeting, the king took a unilateral decision to cancel all adopted decisions on it, and the next meeting, the deputies have been placed in the social class.
<G-vec00198-002-s641><cancel.widerrufen><de> Bald nach dem Treffen hat der König eine einseitige Entscheidung getroffen, um alle angenommenen Entscheidungen darüber zu widerrufen, und das folgende Treffen, die Abgeordneten sind in die soziale Klasse gelegt worden.
<G-vec00198-002-s644><cancel.widerrufen><en> Effects of cancellation If you cancel this contract, we will reimburse to you all payments received from you, including the costs of delivery (except for the supplementary costs arising if you chose a type of delivery other than the least expensive type of standard delivery offered by us).
<G-vec00198-002-s644><cancel.widerrufen><de> Wenn Sie diesen Vertrag widerrufen, haben ich Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lieferung als die von uns angebotene, günstigste Standardlieferung gewählt haben), unverzüglich und spätestens binnen vierzehn Tagen ab dem Tag zurückzuzahlen, an dem die Mitteilung über Ihren Widerruf dieses Vertrags bei uns eingegangen ist.
<G-vec00198-002-s645><cancel.widerrufen><en> For example, users living in the European Union have the right to cancel their Paid Account subscriptions within 14 days of signing up for, upgrading to or renewing a Paid Account.
<G-vec00198-002-s645><cancel.widerrufen><de> Nutzer mit Wohnsitz in der EU sind beispielsweise berechtigt, Abos zahlungspflichtiger Konten innerhalb von 14 Tagen nach der Registrierung, dem Upgrade oder der Verlängerung zu widerrufen.
<G-vec00198-002-s646><cancel.widerrufen><en> EFFECTS OF CANCELLATION If you cancel this contract, I will reimburse to you all payments received from you, including the costs of delivery (except for the supplementary costs arising if you chose a type of delivery other than the least expensive type of standard delivery offered by us).
<G-vec00198-002-s646><cancel.widerrufen><de> Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschließlich der Lieferkosten (mit Ausnahme der zusätzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lieferung als die von uns angebotene, gewählt haben), unverzüglich und spätestens binnen 14 Tagen ab dem Tag zurückzahlen, an dem die Mitteilung über Ihren Widerruf dieses Vertrags bei uns eingegangen ist.
<G-vec00198-002-s647><cancel.widerrufen><en> If, however, the right of cancellation should arise in exceptional circumstances, the following applies to consumers within the meaning set out at § 13 of the German Civil Code: You have the right, within fourteen days, to cancel this contract without specifying any reason.
<G-vec00198-002-s647><cancel.widerrufen><de> Sollte ausnahmsweise doch ein Widerrufsrecht bestehen, gilt für Verbraucher im Sinne des § 13 BGB folgendes: Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen.
<G-vec00198-002-s648><cancel.widerrufen><en> You can cancel partly or completely your permit for data storage at any time and use of your data.
<G-vec00198-002-s648><cancel.widerrufen><de> Sie können Ihre Einwilligung zur Datenspeicherung und Datenverwendung jederzeit teilweise oder vollständig widerrufen.
<G-vec00198-002-s649><cancel.widerrufen><en> - The Casinos Management retains the right to terminate accounts, confiscate winnings and to discontinue or cancel all promotions at any time, for any reason whatsoever and without prior notice.
<G-vec00198-002-s649><cancel.widerrufen><de> - Casino 8118 behält sich das Recht vor, jederzeit und aus jedem Grund, ohne vorherige Anweisung Konten aufzulösen, Gewinne einzuziehen und sämtliche Angebote einzustellen oder zu widerrufen.
<G-vec00198-002-s650><cancel.widerrufen><en> You can cancel your newsletter subscription at any time for free, of course, and be deleted from the list.
<G-vec00198-002-s650><cancel.widerrufen><de> Selbstverständlich können Sie das Newsletter-Abonnement jederzeit kostenfrei widerrufen und sich aus der Liste austragen.
<G-vec00198-002-s651><cancel.widerrufen><en> You are entitled to cancel your contract within fourteen days without stating reasons.
<G-vec00198-002-s651><cancel.widerrufen><de> Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen.
