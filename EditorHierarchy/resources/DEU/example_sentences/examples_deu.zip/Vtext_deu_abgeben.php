<G-vec00060-001-s019><release.abgeben><de> Abhängig von der Temperatur ist die Umgebungsluft in der Lage, einen bestimmten Wasseranteil zu absorbieren und kann die Feuchtigkeit auch wieder an die Umgebung abgeben.
<G-vec00060-001-s019><release.abgeben><en> Depending on the temperature, ambient air is able to absorb a certain percentage of water and it can also release its humidity to the environment.
<G-vec00060-001-s020><release.abgeben><de> Das hängt davon ab, ob wir weiter so viel CO2 in die Atmosphäre abgeben wie bisher.
<G-vec00060-001-s020><release.abgeben><en> That depends on whether we continue to release as much CO2 into the atmosphere as we are doing now.
<G-vec00060-001-s021><release.abgeben><de> Die Merinowolle kann große Mengen Wasserdampf aufnehmen und wieder abgeben (besser als Kunstfaser).
<G-vec00060-001-s021><release.abgeben><en> Merino wool can absorb and release large quantities of moisture (better than synthetic fibers).
<G-vec00060-001-s022><release.abgeben><de> Hinzu kommt, dass die Kathoden bei starker Erhitzuung Sauerstoff abgeben können und somit der Brand ohne externe Luftzufuhr aufrechterhalten werden kann.
<G-vec00060-001-s022><release.abgeben><en> Also, the cathode can release oxygen under severe heat and hence the fire can be maintained without an external air supply.
<G-vec00060-001-s023><release.abgeben><de> Massive, freiliegende Gebäudeteile fungieren als Wärmepuffer – sie können tagsüber Wärme aufnehmen und diese während der Nacht wieder abgeben.
<G-vec00060-001-s023><release.abgeben><en> Solid, exposed building components function as heat buffers – they can absorb heat during the day and then release it again at night.
<G-vec00060-001-s024><release.abgeben><de> In Kontakt mit Wasser können diese Flächen Nickel in erheblichem Umfang an das Wasser abgeben.
<G-vec00060-001-s024><release.abgeben><en> In contact with water, these surfaces can release nickel in a significant amount into water.
<G-vec00060-001-s025><release.abgeben><de> Mit freundlicher Genehmigung von NASA / JPL / University of Arizona Um in ihren normalen Zustand zurückzukehren, müssen die Atome entweder chemische Reaktionen eingehen oder die Energie, die sie gerade aufgenommen haben in Form von Licht abgeben.
<G-vec00060-001-s025><release.abgeben><en> Image courtesy of NASA / JPL / University of Arizona To return to their normal state, they must either undergo chemical reactions or release the energy they have just absorbed as light.
<G-vec00060-001-s026><release.abgeben><de> Leif muss von seinem deutlichen Plus für RZE im August einen Teil wieder abgeben (RZE 118).
<G-vec00060-001-s026><release.abgeben><en> Leif has to release a part of his clear plus for RZE in August to now 118.
<G-vec00060-001-s027><release.abgeben><de> Nickelelektroden sind allerdings keine gute Wahl, weil sie während der Elektrolyse Nickelionen in die Lösung abgeben.
<G-vec00060-001-s027><release.abgeben><en> Nickel electrodes are not suitable, because they corrode and release nickel ions into the solution.
<G-vec00060-001-s028><release.abgeben><de> In diesem Fall würde die elektroDünnbettheizung nur 10 Watt/m² an den Wohnraum abgeben.
<G-vec00060-001-s028><release.abgeben><en> In this case the floor heating would only release 10 Watt/m² into the room.
<G-vec00060-001-s029><release.abgeben><de> Akustische Sonden, die bei Anregung mit periodisch moduliertem, monochromatischem Licht aufgenommene Energie in Wärme umwandeln und diese an ihre Umgebung abgeben, wurden in Pflegebefilmungen inkludiert.
<G-vec00060-001-s029><release.abgeben><en> Acoustic probes which, when excited with periodically modulated monochromatic light, convert absorbed energy into heat and release it into their environment, were included in floorcare coatings.
<G-vec00060-001-s030><release.abgeben><de> Geldschätze, welche sich an den verschiedensten Punkten anhäufen, bilden Sammelbecken, welche bald Geld aufnehmen, bald wieder abgeben und so Störungen im Zirkulationsprozeß ausgleichen.
<G-vec00060-001-s030><release.abgeben><en> Hoards of money which accumulate in the most diverse places form conduits which serve now to absorb, now to release money, thus neutralising disturbances in the process of circulation.
<G-vec00060-001-s031><release.abgeben><de> Auch der Nachweis, dass die Kapseln, wenn nötig, aber auch nur dann die Heilmittel für Defekte in einem Lack abgeben, ist nicht gerade simpel.
<G-vec00060-001-s031><release.abgeben><en> Moreover, it is not exactly easy to prove that the capsules only release the remedy for healing the defects in a coating when necessary.
<G-vec00060-001-s032><release.abgeben><de> Dieser kann überschüssige Nährstoffe aufnehmen und bei Bedarf wieder abgeben.
<G-vec00060-001-s032><release.abgeben><en> Is capable of storing excess nutrients, to release them again when needed.
<G-vec00060-001-s033><release.abgeben><de> Die Werte sind repräsentativ für eine größere Region: Sie zeigen, wie die Pflanzen im Umkreis von vielen hundert Kilometern im Laufe eines Jahres Kohlendioxid aufnehmen und wieder abgeben.
<G-vec00060-001-s033><release.abgeben><en> The values are representative for a larger region: they show how the plants within a radius of many hundred kilometers take up carbon dioxide and release it again over the course of a year.
<G-vec00060-001-s034><release.abgeben><de> Damit eignet sich Tencel optimal für sensible Haut.Tencel-Fasern können durch ihre besondere Struktur 50% mehr Feuchtigkeit aufnehmen und abgeben als Baumwolle.
<G-vec00060-001-s034><release.abgeben><en> This means Tencel is particularly suitable for sensitive skin. Tencel fibres, with their distinctive structure, can absorb and release 50% more moisture than cotton.
<G-vec00060-001-s035><release.abgeben><de> Nach dieser Nutzung werden die Elektronenpakete zum Linearbeschleuniger zurückgeleitet, wo sie nahezu ihre gesamte restliche Energie abgeben.
<G-vec00060-001-s035><release.abgeben><en> After use, the electron bunches are directed back to the superconducting linear accelerator, where they release almost all their remaining energy.
<G-vec00060-001-s036><release.abgeben><de> Seine Blätter und Stängel können Wasser speichern und bei Bedarf abgeben – eine Fähigkeit, die reifer Haut zugutekommt.
<G-vec00060-001-s036><release.abgeben><en> Its leaves and stem can store water and release it if necessary – a skill that greatly benefits mature skin.
<G-vec00060-001-s037><release.abgeben><de> Im Speichel der Stinkwanze gibt es Gift, das sie am Ende der Mahlzeit in die Pflanzen abgeben.
<G-vec00060-001-s037><release.abgeben><en> In the saliva of the stink bug, there is poison that they release into the plants at the end of the meal.
<G-vec00120-001-s015><concede.abgeben><de> Die Mitgliedsstaaten sind zögerlich, Mittel an die EU abzugeben, besonders in der gegenwärtigen ökonomischen Krise.
<G-vec00120-001-s015><concede.abgeben><en> Member states are reluctant to concede their resources to the EU, especially during the current economic crisis.
<G-vec00120-001-s064><concede.abgeben><de> Andererseits könnten gedemütigte Demokraten eher bereit sein, genug Boden an die andere Seite für die vorstehend erwähnten Infrastrukturpläne abzugeben.
<G-vec00120-001-s064><concede.abgeben><en> On the other, humbled Democrats may be more willing to concede enough ground to the other side for the aforementioned infrastructure plan to get off the ground.
<G-vec00078-001-s248><vote.abgeben><de> Theoretisch sind Araber berechtigt, bei den Gemeindewahlen ihre Stimme abzugeben, aber nur wenige taten dies – aus denselben Gründen.
<G-vec00078-001-s248><vote.abgeben><en> In theory, Arabs are entitled to vote in municipal elections, but only a handful do so, for the same reasons.
<G-vec00078-001-s249><vote.abgeben><de> ist dazu eingeladen, eine Stimme abzugeben.
<G-vec00078-001-s249><vote.abgeben><en> is invited to cast their vote.
<G-vec00078-001-s250><vote.abgeben><de> Am Eröffnungswochenende ist das Publikum eingeladen, seine Stimme für das Werk eines Künstlers oder einer Künstlerin unter 35 Jahren abzugeben.
<G-vec00078-001-s250><vote.abgeben><en> On the opening weekend the audience is invited to vote for an artistic position by an artist under the age of 35.
<G-vec00078-001-s251><vote.abgeben><de> Der Vorsitzende kam zur Erkenntnis, dass Pala nicht die Anforderungen erfüllt, um bei der Versammlung seine Stimme abzugeben.
<G-vec00078-001-s251><vote.abgeben><en> The Chair ruled that Pala had not met the requirements to vote at the meeting.
<G-vec00078-001-s252><vote.abgeben><de> Um Ihre Stimme abzugeben, geben Sie bitte Ihre E-Mail-Adresse ein und klicken auf den Bestätigungslink, der Ihnen per E-Mail zugesandt wird.
<G-vec00078-001-s252><vote.abgeben><en> To cast your vote, please enter your email address and click on the verification link that will be sent to you via email.
<G-vec00078-001-s253><vote.abgeben><de> Wenn Sie ein registrierter CDI-Inhaber sind und planen, an der Versammlung teilzunehmen und Ihre Stimme persönlich abzugeben, müssen Sie im Stimmabgabeformular IHREN NAMEN als Vollmachtausübender angeben und das Stimmabgabeformular zurücksenden.
<G-vec00078-001-s253><vote.abgeben><en> If you are a registered holder of a CDI and you plan to attend and vote in person at the Meeting, you must provide YOUR NAME as the Proxy appointee on the voting form and return the voting form as directed.
<G-vec00078-001-s254><vote.abgeben><de> "Bei den griechischen Wahlen haben unsere Genossen von der Trotzkistischen Gruppe Griechenlands dazu aufgerufen, ""keine Stimme für Syriza"" abzugeben, und der Kommunistischen Partei kritische Unterstützung gegeben, die in Opposition zur EU und allen Pro-EU-Parteien einschließlich Syrizas auftrat."
<G-vec00078-001-s254><vote.abgeben><en> "In the Greek elections, our comrades of the Trotskyist Group of Greece called for ""no vote to Syriza"" and gave critical support to the Communist Party, which stood in opposition to the EU and all pro-EU parties, including Syriza."
<G-vec00078-001-s255><vote.abgeben><de> Finnlands offizielles Girlpower-Emoji: 1906 wurde Finnland zum ersten Land der Welt, das ein Gesetz verabschiedete, welches Frauen gestattete, nicht nur ihre Stimme abzugeben, sondern auch für die Wahlen zu kandidieren.
<G-vec00078-001-s255><vote.abgeben><en> Finland's official Girl Power emoji: In 1906, Finland became the first country in the world to pass a law that allowed women both to vote and to run for election.
<G-vec00078-001-s256><vote.abgeben><de> Der interaktive Teil des Experiments ermöglicht es, eine Stimme in jedem Wahlsystem abzugeben.
<G-vec00078-001-s256><vote.abgeben><en> The interactive part of the website allows to cast a vote under each electoral system.
<G-vec00078-001-s257><vote.abgeben><de> Finnland wurde 1906 das erste Land der Welt, das Frauen volle politische Rechte zugestand und ein Gesetz verabschiedete, welches Frauen gestattete, sowohl ihre Stimme abzugeben als auch zu kandidieren.
<G-vec00078-001-s257><vote.abgeben><en> In 1906, Finland became the first country in the world to award women full political rights, passing a law that allowed women both to vote and to run for election.
<G-vec00078-001-s258><vote.abgeben><de> Arbeitnehmer der regionalen Wahlkommission wollen den Wählern nicht nur die Möglichkeit geben, eine Stimme abzugeben, sondern auch die Atmosphäre eines echten Festes zu spüren.
<G-vec00078-001-s258><vote.abgeben><en> Workers of the precinct election commissions intend to provide voters with not only the opportunity to cast a vote, but also to feel the atmosphere of a real holiday.
<G-vec00078-001-s259><vote.abgeben><de> Um dem vorzubeugen, ist es wichtig die eigene Stimme abzugeben.
<G-vec00078-001-s259><vote.abgeben><en> To prevent this, it is important to cast your vote.
<G-vec00078-001-s260><vote.abgeben><de> Im spezifi schen Fall, wo bei einer Abstimmung Briefwahlkarten teilnehmen, werden Vollmachten nicht zur Wahl zugelassen, weil ja jedes Mitglied die Möglichkeit hatte, seine persönliche Stimme durch die Briefwahl abzugeben.
<G-vec00078-001-s260><vote.abgeben><en> In the specific case where a ballot includes postal votes, proxies are not admitted to participate, since every member has had the possibility of casting his personal postal vote.
<G-vec00078-001-s261><vote.abgeben><de> Nur 87 Personen, von denen einige bestochen waren (von 1800 Einwohnern) hatten die Gelegenheit, ihre Stimme abzugeben, und das nur zustimmend.
<G-vec00078-001-s261><vote.abgeben><en> Only 87 people, some of whom were bribed (out of 1800 residents) had an opportunity to cast a vote, by applause only.
<G-vec00078-001-s262><vote.abgeben><de> Am Triennale Eröffnungswochenende war das Publikum eingeladen, seine Stimme für das Werk eines Künstlers oder einer Künstlerin unter 35 Jahren abzugeben.
<G-vec00078-001-s262><vote.abgeben><en> During the opening weekend (Thu, June 3 - Sat, June 5) the public is invited to vote for the work of an artist under 35 years.
<G-vec00078-001-s263><vote.abgeben><de> Den Finnen wurde das schon früh bewusst: Finnland war 1906 das erste Land der Welt, das ein Gesetz verabschiedete, welches Frauen gestattete, sowohl ihre Stimme abzugeben als auch gewählt zu werden.
<G-vec00078-001-s263><vote.abgeben><en> Finns noticed this early; in 1906 Finland became the first country in the world to pass a law that allowed women both to vote and to run for election.
<G-vec00301-002-s197><rectify.abgeben><de> Sie können Ihr Recht auf Korrektur ausüben, indem Sie eine ergänzende Erklärung an die für die Verarbeitung Verantwortliche abgeben.
<G-vec00301-002-s197><rectify.abgeben><en> You can exercise your right to rectify by providing an additional declaration to the Data Controller.
<G-vec00311-002-s142><vow.abgeben><de> Lionel ging in die Politik und wurde sechs Mal in London gewählt, ohne den obligatorischen Schwur auf den christlichen Glauben abzugeben, sodass er jedes Mal geblockt wurde.
<G-vec00311-002-s142><vow.abgeben><en> Lionel went into politics and was elected six times in London without making the obligatory vow on the Christian faith, so that he was blocked each time.
<G-vec00380-002-s009><abdicate.abgeben><de> 1567 Mary, Königin der Schotten, wird gezwungen, den Thron abzugeben.
<G-vec00380-002-s009><abdicate.abgeben><en> 1567 Mary, Queen of Scots, is forced to abdicate the throne.
<G-vec00380-002-s166><dispense.abgeben><de> [0023] Die "Subjective Logic" ermöglicht es einem Experten eine Bewertung sehr intuitiv als eine "Subjective Opinion" mit Hilfe eines Opinion-Dreiecks abzugeben.
<G-vec00380-002-s166><dispense.abgeben><en> Die „Subjective Logic" The "Subjective Logic" allows an Expert Be ¬ valuation very intuitive as a "Subjective Opinion" dispense with the aid of an Opinion triangle.
<G-vec00497-002-s049><cede.abgeben><de> So sehr Unternehmen ihre Macht genießen, so freudig werden sie Macht abgeben und überlassen uns Dinge auf unsere Art zu tun, wenn ihnen das hilft mehr von unserem Geld zu bekommen.
<G-vec00497-002-s049><cede.abgeben><en> As much as businesses enjoy having power, they will happily cede power and let us have things our way if it helps them get even more of our money.
<G-vec00497-002-s019><leave.abgeben><de> Wir raten deshalb dazu, diese nicht mitzubringen, da die Schlangen an der Garderobe, wo man diese abgeben kann, sehr lang sind.
<G-vec00497-002-s019><leave.abgeben><en> We advisable not to take them with you as the queues to leave them in the cloakroom are very long.
<G-vec00497-002-s020><leave.abgeben><de> Kunden, die dieses Produkt gekauft haben, dürfen eine Bewertung abgeben.
<G-vec00497-002-s020><leave.abgeben><en> Only logged in customers who have purchased this product may leave a review.
<G-vec00497-002-s021><leave.abgeben><de> Sie können Ihr Gepäck schon früher bei uns abgeben.
<G-vec00497-002-s021><leave.abgeben><en> It is possible to leave your luggage with us before this time, we will be
<G-vec00497-002-s022><leave.abgeben><de> In zwei Tauschschränken auf dem Festivalgelände konnten die Besucher*innen Gegenstände abgeben und andere Dinge wieder mitnehmen.
<G-vec00497-002-s022><leave.abgeben><en> “Swap lockers” will be installed on the festival grounds, where visitors can leave toys, books and clothing – and find new treasures to take away with them.
<G-vec00497-002-s023><leave.abgeben><de> Bevor Sie eine Bewertung abgeben müssen wir wissen, wer Sie sind.
<G-vec00497-002-s023><leave.abgeben><en> Before you leave feedback, we need to know who you are.
<G-vec00497-002-s024><leave.abgeben><de> Die Heiligen Frauen wollten ihr heiliges Leben und den ihnen gehörenden Planeten Erde nicht so billig abgeben.
<G-vec00497-002-s024><leave.abgeben><en> The holy women did not want to leave so cheap their holy lives and their associated planet earth.
<G-vec00497-002-s025><leave.abgeben><de> Abends bequem die Ski direkt bei uns abgeben und am nächsten Morgen mit frischem Service ins sportliche Vergnügen starten.
<G-vec00497-002-s025><leave.abgeben><en> You can leave your skis directly with us in the evening and start the next morning with a fresh serviced ski.
<G-vec00497-002-s026><leave.abgeben><de> In den Eingangsbereichen finden Sie Schließfächer – Mäntel, Jacken oder Gepäckstücke können Sie an den Garderoben gegen eine Gebühr von EUR 2 abgeben.
<G-vec00497-002-s026><leave.abgeben><en> You can find lockers in the entrance areas – you can leave coats, jackets or items of luggage in the cloakrooms for a fee of EUR 2.
<G-vec00497-002-s027><leave.abgeben><de> Sie können Ihre Post auch dort abgeben.
<G-vec00497-002-s027><leave.abgeben><en> You can also leave your post there to have it sent anywhere in the world.
<G-vec00497-002-s028><leave.abgeben><de> Diese Leser können anschließend wertvolle Bewertungen zu Cover und Inhalt abgeben und Weiterempfehlungen für Deine Veröffentlichung aussprechen.
<G-vec00497-002-s028><leave.abgeben><en> Afterwards, those readers can leave a valuable review on your cover and content and respectively give a recommendation for your eBook.
<G-vec00497-002-s029><leave.abgeben><de> Zurück in der Botschaft warteten wir wieder eine Weile und durften dann unsere Anträge abgeben.
<G-vec00497-002-s029><leave.abgeben><en> Back at the embassy we waited a while again and then were allowed to leave our applications.
<G-vec00497-002-s030><leave.abgeben><de> Besucher-Personen, die nicht auf dem Campingplatz registriert sind, müssen in der Rezeption ein Dokument abgeben, den Namen der Person die Sie besuchen und die Nummer der Parzelle angeben.
<G-vec00497-002-s030><leave.abgeben><en> Visitors – Any person who is not checked-in to the campsite must leave their ID at reception and give the name and pitch number (if known) of the person they are visiting.
<G-vec00497-002-s031><leave.abgeben><de> Wenn Sie einen Kommentar zur Musik von Alexa Junge, Elvis Aaron Presley (auch bekannt als Elvis Presley), Judy Kuhn auf dieser Seite abgeben möchten, klicken Sie auf den Tab "Kundenrezensionen".
<G-vec00497-002-s031><leave.abgeben><en> If you would like to leave a review of the Joel McNeely sheet music on this page, then please click on the tab "Comments". Do you want to tell the world how great this track is?
<G-vec00497-002-s032><leave.abgeben><de> Es wäre sehr gut, wenn ihr neben Inlinkz auch einen Kommentar abgeben würdet.
<G-vec00497-002-s032><leave.abgeben><en> Vanni your blog. It would be great, if you leave a
<G-vec00497-002-s033><leave.abgeben><de> MDF-Holz wird einen Geruch ähnlich wie das gerösteste Brot abgeben, aber es wird nicht brennen.
<G-vec00497-002-s033><leave.abgeben><en> MDF Wood will just leave a similar smell of toast bread but it won’t burn.
<G-vec00497-002-s034><leave.abgeben><de> Ehemalige Gäste können nach Check-Out eine anonyme Bewertung beim unserem Hotel abgeben.
<G-vec00497-002-s034><leave.abgeben><en> Former guests can leave an anonymous review after check-out at our hotel.
<G-vec00497-002-s035><leave.abgeben><de> Der Schüler soll zwei Studientagebücher haben, damit er eines dem Lehrer abgeben und in dem anderen weiterarbeiten kann.
<G-vec00497-002-s035><leave.abgeben><en> Students should have two scripture study journals so they can leave one with their teacher and continue working in the other.
<G-vec00497-002-s036><leave.abgeben><de> Wenn Sie einen Kommentar zur Musik von African-American Spiritual auf dieser Seite abgeben möchten, klicken Sie auf den Tab "Kundenrezensionen".
<G-vec00497-002-s036><leave.abgeben><en> If you would like to leave a review of the African-American Spiritual sheet music on this page, then please click on the tab "Comments".
<G-vec00497-002-s037><leave.abgeben><de> Diese Strandtücher können Sie am Abreisetag an der Rezeption wieder abgeben.
<G-vec00497-002-s037><leave.abgeben><en> You can conveniently return the towels to reception on the day you leave.
<G-vec00555-002-s021><expel.abgeben><de> Der Ziegel hat durch sein Gefüge, das viele kleine Kapillaren (Poren) beinhaltet, die Eigenschaft Wasser sehr schnell abzugeben.
<G-vec00555-002-s021><expel.abgeben><en> No mould growth Brick has the ability to quickly expel water because it contains many small pores.
<G-vec00560-002-s019><leave_out.abgeben><de> Wir raten deshalb dazu, diese nicht mitzubringen, da die Schlangen an der Garderobe, wo man diese abgeben kann, sehr lang sind.
<G-vec00560-002-s019><leave_out.abgeben><en> We advisable not to take them with you as the queues to leave them in the cloakroom are very long.
<G-vec00560-002-s020><leave_out.abgeben><de> Kunden, die dieses Produkt gekauft haben, dürfen eine Bewertung abgeben.
<G-vec00560-002-s020><leave_out.abgeben><en> Only logged in customers who have purchased this product may leave a review.
<G-vec00560-002-s021><leave_out.abgeben><de> Sie können Ihr Gepäck schon früher bei uns abgeben.
<G-vec00560-002-s021><leave_out.abgeben><en> It is possible to leave your luggage with us before this time, we will be
<G-vec00560-002-s022><leave_out.abgeben><de> In zwei Tauschschränken auf dem Festivalgelände konnten die Besucher*innen Gegenstände abgeben und andere Dinge wieder mitnehmen.
<G-vec00560-002-s022><leave_out.abgeben><en> “Swap lockers” will be installed on the festival grounds, where visitors can leave toys, books and clothing – and find new treasures to take away with them.
<G-vec00560-002-s023><leave_out.abgeben><de> Bevor Sie eine Bewertung abgeben müssen wir wissen, wer Sie sind.
<G-vec00560-002-s023><leave_out.abgeben><en> Before you leave feedback, we need to know who you are.
<G-vec00560-002-s024><leave_out.abgeben><de> Die Heiligen Frauen wollten ihr heiliges Leben und den ihnen gehörenden Planeten Erde nicht so billig abgeben.
<G-vec00560-002-s024><leave_out.abgeben><en> The holy women did not want to leave so cheap their holy lives and their associated planet earth.
<G-vec00560-002-s025><leave_out.abgeben><de> Abends bequem die Ski direkt bei uns abgeben und am nächsten Morgen mit frischem Service ins sportliche Vergnügen starten.
<G-vec00560-002-s025><leave_out.abgeben><en> You can leave your skis directly with us in the evening and start the next morning with a fresh serviced ski.
<G-vec00560-002-s026><leave_out.abgeben><de> In den Eingangsbereichen finden Sie Schließfächer – Mäntel, Jacken oder Gepäckstücke können Sie an den Garderoben gegen eine Gebühr von EUR 2 abgeben.
<G-vec00560-002-s026><leave_out.abgeben><en> You can find lockers in the entrance areas – you can leave coats, jackets or items of luggage in the cloakrooms for a fee of EUR 2.
<G-vec00560-002-s027><leave_out.abgeben><de> Sie können Ihre Post auch dort abgeben.
<G-vec00560-002-s027><leave_out.abgeben><en> You can also leave your post there to have it sent anywhere in the world.
<G-vec00560-002-s028><leave_out.abgeben><de> Diese Leser können anschließend wertvolle Bewertungen zu Cover und Inhalt abgeben und Weiterempfehlungen für Deine Veröffentlichung aussprechen.
<G-vec00560-002-s028><leave_out.abgeben><en> Afterwards, those readers can leave a valuable review on your cover and content and respectively give a recommendation for your eBook.
<G-vec00560-002-s029><leave_out.abgeben><de> Zurück in der Botschaft warteten wir wieder eine Weile und durften dann unsere Anträge abgeben.
<G-vec00560-002-s029><leave_out.abgeben><en> Back at the embassy we waited a while again and then were allowed to leave our applications.
<G-vec00560-002-s030><leave_out.abgeben><de> Besucher-Personen, die nicht auf dem Campingplatz registriert sind, müssen in der Rezeption ein Dokument abgeben, den Namen der Person die Sie besuchen und die Nummer der Parzelle angeben.
<G-vec00560-002-s030><leave_out.abgeben><en> Visitors – Any person who is not checked-in to the campsite must leave their ID at reception and give the name and pitch number (if known) of the person they are visiting.
<G-vec00560-002-s031><leave_out.abgeben><de> Wenn Sie einen Kommentar zur Musik von Alexa Junge, Elvis Aaron Presley (auch bekannt als Elvis Presley), Judy Kuhn auf dieser Seite abgeben möchten, klicken Sie auf den Tab "Kundenrezensionen".
<G-vec00560-002-s031><leave_out.abgeben><en> If you would like to leave a review of the Joel McNeely sheet music on this page, then please click on the tab "Comments". Do you want to tell the world how great this track is?
<G-vec00560-002-s032><leave_out.abgeben><de> Es wäre sehr gut, wenn ihr neben Inlinkz auch einen Kommentar abgeben würdet.
<G-vec00560-002-s032><leave_out.abgeben><en> Vanni your blog. It would be great, if you leave a
<G-vec00560-002-s033><leave_out.abgeben><de> MDF-Holz wird einen Geruch ähnlich wie das gerösteste Brot abgeben, aber es wird nicht brennen.
<G-vec00560-002-s033><leave_out.abgeben><en> MDF Wood will just leave a similar smell of toast bread but it won’t burn.
<G-vec00560-002-s034><leave_out.abgeben><de> Ehemalige Gäste können nach Check-Out eine anonyme Bewertung beim unserem Hotel abgeben.
<G-vec00560-002-s034><leave_out.abgeben><en> Former guests can leave an anonymous review after check-out at our hotel.
<G-vec00560-002-s035><leave_out.abgeben><de> Der Schüler soll zwei Studientagebücher haben, damit er eines dem Lehrer abgeben und in dem anderen weiterarbeiten kann.
<G-vec00560-002-s035><leave_out.abgeben><en> Students should have two scripture study journals so they can leave one with their teacher and continue working in the other.
<G-vec00560-002-s036><leave_out.abgeben><de> Wenn Sie einen Kommentar zur Musik von African-American Spiritual auf dieser Seite abgeben möchten, klicken Sie auf den Tab "Kundenrezensionen".
<G-vec00560-002-s036><leave_out.abgeben><en> If you would like to leave a review of the African-American Spiritual sheet music on this page, then please click on the tab "Comments".
<G-vec00560-002-s037><leave_out.abgeben><de> Diese Strandtücher können Sie am Abreisetag an der Rezeption wieder abgeben.
<G-vec00560-002-s037><leave_out.abgeben><en> You can conveniently return the towels to reception on the day you leave.
<G-vec00020-002-s275><vote.abgeben><de> Auch ohne Mitgliederversammlung können Beschlüsse gefasst werden, wenn die Mehrheit der Vereinsmitglieder ihre Zustimmung zu dem Beschluss schriftlich erklärt und ihre Stimme zu Händen des Vorstands abgeben.
<G-vec00020-002-s275><vote.abgeben><en> Even without General Assembly resolutions may be passed if the majority of the club members expressed their approval of the decision in writing and cast their vote for the attention of the Board.
<G-vec00020-002-s276><vote.abgeben><de> „Der PRS-Parteivorsitzende rief jedoch die Bürger und vor allem an diejenigen, die ihre Stimme nicht abgeben konnten, zu öffentlichen Protestkundgebungen auf“, so Pater Sciocco.
<G-vec00020-002-s276><vote.abgeben><en> The head of the PRS appealed to the people,calling those who were unable to vote to take to the streets in protest ” Father Sciocco told Fides.
<G-vec00020-002-s277><vote.abgeben><de> Man kann sich beliebig oft mit dem Kennwort am Online-Wahlsystem anmelden, aber nur eine Stimme verbindlich abgeben.
<G-vec00020-002-s277><vote.abgeben><en> The voter can log into the online voting system with the ID and password combination any number of times - but can only cast one valid vote.
<G-vec00020-002-s278><vote.abgeben><de> Für alle, die ihre Stimme abgeben, gibt es die Möglichkeit, eine Reise nach Wien mit zwei Übernachtungen für 2 Personen in einem 4-Sterne-Hotel inklusive Frühstück und einem Welcome-Package zu gewinnen.
<G-vec00020-002-s278><vote.abgeben><en> If you vote for your favourite film you could win a trip for two to Vienna in a 4-star hotel incl. breakfast as well as a welcome package by the Vienna Tourism Board.
<G-vec00020-002-s279><vote.abgeben><de> Demzufolge würden in einigen Stadtteilen New Yorks gezielt Bürger in Bussen von Wahllokal zu Wahllokal gefahren, damit sie ihre Stimme mehrfach abgeben können.
<G-vec00020-002-s279><vote.abgeben><en> Therefore in some district of New York citizens would purposefully be driven from polling station to polling station so that they can cast their vote several times.
<G-vec00020-002-s280><vote.abgeben><de> Per Streaming kann man sich die nominierten Videos einen Monat lang ansehen und seine Stimme abgeben.
<G-vec00020-002-s280><vote.abgeben><en> Each year, the nominated videos can be viewed for one month and users can vote for the best clip.
<G-vec00020-002-s281><vote.abgeben><de> Vertrauen dieser Art ist schwer zu verdienen, und SoftSwiss schätzt die Unterstützung aller, die ihre Stimme abgeben.
<G-vec00020-002-s281><vote.abgeben><en> Trust of this kind is hard to earn and SoftSwiss appreciates the support of everyone who cast their vote.
<G-vec00020-002-s282><vote.abgeben><de> Danach kannst Du ohne Benutzerkonto Deine Stimme abgeben.
<G-vec00020-002-s282><vote.abgeben><en> After that you can vote without an user account.
<G-vec00020-002-s283><vote.abgeben><de> Wenn Sie beim Vermittler ein Stimmabgabeformular abgeben, auf dem nicht IHR NAME als Vollmachtausübender angegeben ist, können Sie bei der Versammlung keine Stimme abgeben – auch dann nicht, wenn Sie persönlich anwesend sind.
<G-vec00020-002-s283><vote.abgeben><en> If you do not return the voting form to the Intermediary with YOUR NAME as the Appointee, you cannot vote your shares at the Meeting, even if you are present in person. CDI HOLDERS
<G-vec00020-002-s284><vote.abgeben><de> Dann kannst Du auch im Landkreis Göttingen Deine Stimme für die Piratenpartei abgeben.
<G-vec00020-002-s284><vote.abgeben><en> Then you can vote Pirate Party in the district of Göttingen.
<G-vec00020-002-s285><vote.abgeben><de> Jeder Aktionär kann persönlich an der Generalversammlung teilnehmen und seine Stimme abgeben oder sich durch einen anderen stimmberechtigten Aktionär mittels schriftlicher Vollmacht oder durch den unabhängigen Stimmrechtsvertreter vertreten lassen.
<G-vec00020-002-s285><vote.abgeben><en> Each shareholder may attend the General Meeting in person and vote, or be represented by another shareholder with voting rights by means of written power of attorney, or be represented by the independent proxy.
<G-vec00020-002-s286><vote.abgeben><de> Denn egal wie lange sie schon fern der Heimat sind, sie dürfen immer noch ihre Stimme abgeben.
<G-vec00020-002-s286><vote.abgeben><en> After all, no matter how long they have been away, they are still entitled to cast their vote.
<G-vec00159-002-s386><assess.abgeben><de> Im Alarmfall schalten sich diese vordefinierten Szenen automatisch auf und bieten die relevanten Informationen zur Einschätzung der Lage.
<G-vec00159-002-s386><assess.abgeben><en> In the event of an alarm, these predefined scenes turn on automatically and provide the relevant information to assess the situation.
<G-vec00159-002-s387><assess.abgeben><de> Dieses Dokument ist für Entwickler und Architekten gedacht, die nach betriebs- und architekturbezogenen Richtlinien von AWS zur Einschätzung der Betriebsbereitschaft ihrer Anwendung suchen.
<G-vec00159-002-s387><assess.abgeben><en> This paper is targeted at developers and architects who are looking for operational and architectural guidance from AWS to help assess their application's operational readiness.
<G-vec00159-002-s388><assess.abgeben><de> Bei PatientInnen mit funktioneller Mitralklappeninsuffizienz gibt es seit Jahren einen kardiologischen ExpertInnenstreit um die Bestimmung des Schweregrads und damit um die Einschätzung, wann eine Operation an der Klappe unbedingt notwendig ist.
<G-vec00159-002-s388><assess.abgeben><en> For years now, cardiology experts have been arguing about how to determine the degree of severity in patients with functional mitral regurgitation and, hence, to assess when it is necessary to operate on the valve.
<G-vec00159-002-s389><assess.abgeben><de> Das erleichtert Arbeitgebern die Einschätzung der ausländischen Berufsqualifikation und erhöht die Chancen der Migrantinnen und Migranten auf dem deutschen Arbeitsmarkt.
<G-vec00159-002-s389><assess.abgeben><en> This will make it easier for employers to assess the foreign vocational qualification and will increase the opportunities for migrants on the German employment market.
<G-vec00159-002-s390><assess.abgeben><de> Um dem Markt eine Einschätzung der Umsatzentwicklung aller entsprechenden Aktivitäten des Konzerns zu ermöglichen, wurden die Umsätze der bestehenden Aktivitäten, der neu erworbenen Gesellschaften idealo und wallstreet online sowie der ab dem dritten Quartal 2007 zu konsolidierenden Tochtergesellschaften zanox (quotal zu 60 Prozent) und auFeminin auf Basis ungeprüfter Finanzinformationen rückwirkend ermittelt.
<G-vec00159-002-s390><assess.abgeben><en> To make it possible for the market to assess the revenues trend of all the group’s corresponding operations, the revenues of existing operations, of the newly acquired companies idealo and wallstreet online, and of the subsidiaries that will be consolidated in Q3 2007 – zanox (60 percent pro rata) and auFeminin – are being shown retroactively based on unaudited financial information.
<G-vec00159-002-s391><assess.abgeben><de> Zur Einschätzung der Versorgungslage in der Bevölkerung können im Serum gemessene Folatkonzentrationen herangezogen werden.
<G-vec00159-002-s391><assess.abgeben><en> Serum folate concentrations can be used to assess a population’s folate status.
<G-vec00159-002-s392><assess.abgeben><de> Zusätzlich werden die Marktkenner um eine Einschätzung der Ertragslage in 13 deutschen Branchen gebeten.
<G-vec00159-002-s392><assess.abgeben><en> Furthermore, financial market experts are to assess the profit situation of 13 German industry branches.
<G-vec00159-002-s393><assess.abgeben><de> Eine Kampagne für besseren Zugang wird 2014 zur Einschätzung der derzeitigen von Patienten erfahrenen Schwierigkeiten für den Zugang zu Medizinprodukten und medizinischer Versorgung und zur Förderung von gezielten Lösungen gestartet.
<G-vec00159-002-s393><assess.abgeben><en> An Access Campaign will be launched in 2014 to assess the difficulties patients currently experience in getting medicines and medical care and to promote targeted solutions.
<G-vec00159-002-s394><assess.abgeben><de> Die Ziele dieser Studie waren im Einzelnen: (1) Die Analyse der Nährstoffverfügbarkeit und -limitierung in der polygonalen Tundra, (2) die Quantifizierung anorganischen Stickstoffs im permanent gefrorenen und im saisonal aufgetauten Bereich verschiedener Böden der sibirischen Arktis, (3) die Abschätzung der potentiellen Stickstofffreisetzungsraten aus diesen Böden durch das Auftauen des Permafrosts, sowie (4) die Einschätzung der Veränderungen mikrobiellen Wachstums, der mikrobiellern Respiration und der Stickstoffverfügbarkeit unter erhöhten Temperaturen durch die Inkubation eines arktischen Bodenprofils.
<G-vec00159-002-s394><assess.abgeben><en> The objectives of this study were in detail: (1) To analyze availability and limitation of nutrients in the soil-vegetation system of an arctic polygonal tundra landscape, (2) to quantify pools of inorganic nitrogen within the perennially frozen ground and the active layer of different soils in the Siberian arctic, (3) to give an estimate of potential annual nitrogen release rates in the course of climate change, and (4) to assess the changes of microbial growth, microbial respiration and nitrogen availability in arctic soils in response to increased temperatures by a soil incubation study.
<G-vec00159-002-s395><assess.abgeben><de> Die Fortschrittsberichte helfen Patienten und Therapeuten bei der Einschätzung der Effektivität der Therapie.
<G-vec00159-002-s395><assess.abgeben><en> The progress reports help both the patient and Therapist assess the effectiveness of the therapy undertaken.
<G-vec00159-002-s396><assess.abgeben><de> Ohne sie keine Färsen, keine Unterkünfte, keine Tests in Natura in den Betrieben zur Einschätzung der eigenen Kenntnisse.
<G-vec00159-002-s396><assess.abgeben><en> Without them, no heifer, no accommodation, no scale test in farm to assess the knowledge.
<G-vec00159-002-s397><assess.abgeben><de> Das erschwert nicht nur die Einschätzung der Lage im Land - zuverlässige Informationen aus Libyen sind rar.
<G-vec00159-002-s397><assess.abgeben><en> That doesn't just make it harder to assess the situation in Libya -- reliable information is in short supply.
<G-vec00159-002-s398><assess.abgeben><de> Die zweite Eigenschaft, die uns auffiel, war die gelungene Visualisierung, die den Operatoren zu einer schnellen Einschätzung und Lokalisierung eventueller Problembereiche verhilft.“ Darüber hinaus interessierte sich Schrank für das rollengestützte Zugriffsmodell.
<G-vec00159-002-s398><assess.abgeben><en> The second feature we noted was the successful visualisation which helps the operators to quickly assess and localise possible problem areas.” In addition, Schrank was interested in the role-based access model.
<G-vec00159-002-s399><assess.abgeben><de> Es gilt hier, Horizonte zu erweitern, Impulse zu geben und die Möglichkeit einer Einschätzung zu bekommen.
<G-vec00159-002-s399><assess.abgeben><en> Key here is to broaden horizons, generate stimuli and to get a chance to assess this approach.
<G-vec00159-002-s400><assess.abgeben><de> Um das Verständnis über die thermische Dynamik von Getreidepflanzen bei höheren Temperaturen weiterzuentwickeln und eine Einschätzung über Interaktionen von Genotyp, Umwelt und Management (G×U×M) zu erhalten, ist es beabsichtigt, Pflanztermine zu variieren: von der gewohnten Pflanzungszeit im Dezember zu dichteren Intervallen zwischen April und Juni.
<G-vec00159-002-s400><assess.abgeben><en> To refine the understanding of thermal response of cereal grains at higher temperatures and assess Genotype by Environment by Management (G×E×M) interactions, it is intended to stagger planting dates, from the normal cropping season in December, to be in closer intervals during the April-June time frame.
<G-vec00159-002-s401><assess.abgeben><de> Dabei gilt es zunächst, eine Einschätzung der aktuellen Bedrohungslage durch Spionage zu gewinnen und deren Hauptträger und die mit ihnen in Kontakt stehenden Zielpersonen zu identifizieren.
<G-vec00159-002-s401><assess.abgeben><en> First, it is important to assess the current threat emanating from espionage and to identify the main perpetrators and the target persons in contact with them.
<G-vec00159-002-s402><assess.abgeben><de> Informationen zur Einschätzung der Zahl der in der Gruppe benötigten Server finden Sie unter Planen der StoreFront-Bereitstellung im Abschnitt Skalierbarkeit.
<G-vec00159-002-s402><assess.abgeben><en> See the Scalability section of Plan your Storefront deployment to assess how many servers you need in your group.
<G-vec00159-002-s403><assess.abgeben><de> Hier kommen fest angestellte fremdsprachige Profiler und eigene Übersetzer zur unmittelbaren Sichtnahme, Einschätzung und beglaubigten Übersetzung der Bildungs- und Qualifikationsnachweise zum Einsatz.
<G-vec00159-002-s403><assess.abgeben><en> In-house foreign-language profilers and translators view, assess and translate (certified) the educational und qualification certificates.
<G-vec00159-002-s404><assess.abgeben><de> Email Pinterest HbA1c: Eine wichtige Messgröße für die Qualität des Diabetesmanagements sind die durchschnittlichen Blutzuckerwerte der vergangenen zwei bis drei Monate zur Einschätzung der Blutzuckereinstellung.
<G-vec00159-002-s404><assess.abgeben><en> Email Pinterest HbA1c: an important measure of how effectively diabetes can be managed using a measure of the amount of glucose that has attached itself to each red blood cell over the preceding 2-3 months to assess the level of diabetes control.
<G-vec00159-002-s202><estimate.abgeben><de> Aktive latente Steuern auf Verlustvorträge und Zinsvorträge werden grundsätzlich auf Basis der Einschätzung der zukünftigen Realisierbarkeit der steuerlichen Vorteile bilanziert, d. h., wenn mit ausreichenden steuerlichen Erträgen oder Minderbelastungen zu rechnen ist.
<G-vec00159-002-s202><estimate.abgeben><en> Deferred tax assets on tax loss carryforwards and interest carryforwards are recognised on the basis of an estimate of the future recoverability of the tax benefit, i.e. an assumption as to whether sufficient taxable income or tax relief will be available against which the carryforwards can be utilised.
<G-vec00159-002-s203><estimate.abgeben><de> Um eine erste Einschätzung der technischen Machbarkeit für Ihre Fragestellung vornehmen zu können, schreiben Sie doch bitte einige Eckdaten in unser Kontaktformular und schicken es uns zu.
<G-vec00159-002-s203><estimate.abgeben><en> To allow us to initially estimate the technical feasibility of your request, please fill in some reference values in our contact form and send it to us.
<G-vec00159-002-s204><estimate.abgeben><de> Ermittelt werden fernerhin objektive Kriterien zur Einschätzung der Belastung von Tieren im Tierversuch.
<G-vec00159-002-s204><estimate.abgeben><en> Objective criteria are also determined to estimate the distress to which animals are exposed during experiments.
<G-vec00159-002-s205><estimate.abgeben><de> Nach Einschätzung der Internationalen Energieagentur soll sich der Bedarf in den Jahren 2008 bis 2035 nahezu erdoppeln.
<G-vec00159-002-s205><estimate.abgeben><en> According to an estimate by the International Energy Agency, demand is set to nearly double between 2008 and 2035.
<G-vec00159-002-s206><estimate.abgeben><de> Diese Einschätzung erstaunt – denn in den vergangenen Monaten hatte es immer wieder Schlagzeilen über Vor- und Ausfälle während der Demonstrationen gegeben.
<G-vec00159-002-s206><estimate.abgeben><en> This estimate is surprising because in the past few months, had it again and again in headlines about Before – and failures during the demonstrations given.
<G-vec00159-002-s207><estimate.abgeben><de> Es erleichtert dem Empfänger die Einschätzung des Risikopotenzials, in dem es zentrale Aspekte der Risikobewertung zusammenfasst: betroffene Zielgruppen, Schweregrad und Wahrscheinlichkeit einer gesundheitlichen Beeinträchtigung, die Qualität der Datenlage sowie die Handlungsmöglichkeiten.
<G-vec00159-002-s207><estimate.abgeben><en> It makes it easier for the recipient to estimate the potential risks by summarising essential aspects of the risk assessment, such as the affected target groups, degree of severity and likelihood of a health impairment, quality of the data and available courses of action.
<G-vec00159-002-s208><estimate.abgeben><de> Bis ganze Bauteile beschichtet werden können, dauert es nach Einschätzung des Experten noch eineinhalb bis zwei Jahre.
<G-vec00159-002-s208><estimate.abgeben><en> Experts estimate that it will be another one and a half to two years before whole components can be coated.
<G-vec00159-002-s209><estimate.abgeben><de> Die Einschätzung, dass die anderen „99%“ im wesentlichen gemeinsame Interessen haben, ist eine ziemliche Übertreibung – weil es Millionen von Polizisten, Gefängniswärtnern, Offizieren des Militärs, Managern und anderen einschließen würde, deren materielle Interessen eng mit der herrschenden Elite verbunden sind.
<G-vec00159-002-s209><estimate.abgeben><en> The estimate that the other “99%” have essentially common interests is a considerable exaggeration—because this would include millions of cops, screws, military officers, managers and others whose material interests bind them closely to the ruling elite.
<G-vec00159-002-s210><estimate.abgeben><de> Dies führt zu einer optimistischen Einschätzung der Wirksamkeit nach 6 Monaten von 65% und einer Worst-Case-Schätzung von 47% (für den Fall, dass alle neun nichtgetesteten Patienten Non-Responder waren).
<G-vec00159-002-s210><estimate.abgeben><en> These results are an optimistic estimate of efficacy after 6 months of 65% and a worst-case estimate of 47% (this is when all 9 patients who did not respond/cooperate are considered as ‘non-responders’).
<G-vec00159-002-s211><estimate.abgeben><de> Sie sind die schnellste, einfachste und wirtschaftlichste Lösung zur Einschätzung der Qualität und Stärke von Beton.
<G-vec00159-002-s211><estimate.abgeben><en> It is the quickest, simplest and least expensive method to obtain an estimate of the quality and strength of the concrete.
<G-vec00159-002-s212><estimate.abgeben><de> Unsere Software berechnet eine Einschätzung darüber, wie viel Inhalt in Ihrem Dokument wahrscheinlich plagiiert wurde, und erstellt darauf basierend einen vollständigen Bericht.
<G-vec00159-002-s212><estimate.abgeben><en> Our software calculates an estimate of how much content within your document has been plagiarized and generates a full report based on that.
<G-vec00159-002-s213><estimate.abgeben><de> Aus diesem Grund wurde eine einfache praxisnahe Methode entwickelt, die Anlagenbetreibern eine schnelle und kostengünstige Einschätzung der Gefahr einer Schaumbildung im Biogasreaktor ermöglicht.
<G-vec00159-002-s213><estimate.abgeben><en> To meet this need, a simple, practical method has been developed that allows plant operators to estimate the risk of foam formation in a biogas reactor in a quick and cost-effective manner.
<G-vec00159-002-s214><estimate.abgeben><de> "Nach meiner Einschätzung hat der innenpolitische Umgang mit dem Rechtspopulismus von Anfang an die falsche Richtung eingeschlagen.
<G-vec00159-002-s214><estimate.abgeben><en> In my estimate, domestic politicians mishandled right-wing populism from the start.
<G-vec00159-002-s215><estimate.abgeben><de> Es gibt Ihnen eine Einschätzung der Hand, die das Gebot abgegeben hat.
<G-vec00159-002-s215><estimate.abgeben><en> It gives you an estimate of the hand which made a higher bid.
<G-vec00159-002-s216><estimate.abgeben><de> Anhand vorliegender Ergebnisse kann nun eine deutlich bessere Einschätzung des postoperativen Outcome erfolgen.
<G-vec00159-002-s216><estimate.abgeben><en> Regarding these results it is possible now to estimate the postoperative outcome in a better way.
<G-vec00159-002-s217><estimate.abgeben><de> Diese und andere Methoden der SEB zur Steuerung, Einschätzung und Bewertung ihrer Risiken, wie Value-at-Risk-Analysen (VAR), basieren zum Teil auf historischem Marktverhalten.
<G-vec00159-002-s217><estimate.abgeben><en> Some of these and other methods used by SEB to manage, estimate and measure risk, such as value-at-risk (VaR) analyses, are based on historic market behaviour.
<G-vec00159-002-s218><estimate.abgeben><de> Wir bewerten Ihre Immobilie mit einer realistischen Einschätzung und ermitteln Optimierungspotenziale.
<G-vec00159-002-s218><estimate.abgeben><en> We will appraise your property with a realistic estimate and identify areas in need of improvement.
<G-vec00159-002-s219><estimate.abgeben><de> KONE Quick Traffic gibt Architekten und Planern die Möglichkeit, anhand einer Vielzahl verschiedener Gebäudeparameter eine erste Einschätzung der benötigten Anzahl von Personenaufzügen für ein Bauvorhaben vorzunehmen.
<G-vec00159-002-s219><estimate.abgeben><en> KONE Quick Traffic A quick and easy way to get an initial estimate of the number of elevators required for a project, based on a range of different building parameters.
<G-vec00159-002-s220><estimate.abgeben><de> Um jedoch zu gewährleisten, dass die vorgeschlagene Einschätzung richtig ist, raten wir Ihnen, dass Sie uns vor Ort besuchen.
<G-vec00159-002-s220><estimate.abgeben><en> However, to ensure that the proposed estimate is correct, we suggest visiting us on-site.
<G-vec00159-002-s437><estimate.abgeben><de> Zusätzlich zu den bei Fire Lake North lagernden abgeleiteten Mineralressourcen ist schätzungsweise zwischen 140 und 175 Millionen Tonnen zusätzliches Mineralisierungsmaterial vorhanden, für das keine Probenwerte vorliegen und damit auch keine Schätzung der Erzgehalte möglich ist.
<G-vec00159-002-s437><estimate.abgeben><en> In addition to the Inferred Mineral Resources identified at Fire Lake North, it is estimated that between 140 million to 175 million tonnes of additional “mineralized material” is present for which no sampling data is available to estimate grade.
<G-vec00159-002-s438><estimate.abgeben><de> Die überarbeitete und verbesserte zweite Ausgabe des Buchs ist eine unschätzbare Hilfe bei der Aufwandschätzung von Softwareprojekten - gleichgültig ob eine schnelle Schätzung für eine Machbarkeitsstudie oder eine detaillierte Schätzung für ein Angebot benötigt wird.
<G-vec00159-002-s438><estimate.abgeben><en> Whether you are looking for a quick indicative estimate for a feasibility report, a detailed estimate for a quotation or capital expenditure request, or a way to standardise and formalise your quoting, this book will prove to be invaluable.
<G-vec00159-002-s440><estimate.abgeben><de> Diese ergänzen jene, die in GoIP Global Inc.s Pressemitteilungen, öffentlichen Anträgen und Aussagen des Managements von GoIP Global Inc. beschrieben werden, einschließlich, jedoch nicht darauf beschränkt, GoIP Global Inc.s Schätzung der Hinlänglichkeit seiner bestehenden Kapitalressourcen, GoIP Global Inc.s Fähigkeit, zusätzliches Kapital zur Finanzierung zukünftiger Betriebe aufzubringen, GoIP Global Inc.s Fähigkeit, seine bestehende Verschuldung zu begleichen, Ungewissheiten in Zusammenhang mit der Schätzung von Marktmöglichkeiten sowie der Unterzeichnung von Verträgen, die GoIP Global Inc.s Fähigkeiten entsprechen.
<G-vec00159-002-s440><estimate.abgeben><en> In addition to those discussed in GoIP Global, Inc.'s press releases, public filings, and statements by GoIP Global, Inc.'s management, including, but not limited to, GoIP Global, Inc.'s estimate of the sufficiency of its existing capital resources, GoIP Global, Inc.'s ability to raise additional capital to fund future operations, GoIP Global, Inc.'s ability to repay its existing indebtedness, the uncertainties involved in estimating market opportunities and, in identifying contracts which match GoIP Global, Inc.'s capability to be awarded contracts.
<G-vec00159-002-s441><estimate.abgeben><de> Bitte beachten Sie, dass jede Schätzung vor dem Erreichen der Küste nicht genau sein kann und die endgültigen Verluste wesentlich unterschiedlich sein können.
<G-vec00159-002-s441><estimate.abgeben><en> Please note that any estimate prior to landfall cannot be accurate and ultimate losses might be substantially different. Event details
<G-vec00159-002-s442><estimate.abgeben><de> Eine Punkteschätzung an sich könnte ein guter Anfang sein, um über die Grundgesamtheit nachzudenken (es ist eine erste gute Schätzung), aber eine Punkteschätzung liefert keine Informationen darüber, wie "gut" diese Schätzung ist - sie berücksichtigt nicht die Unsicherheit.
<G-vec00159-002-s442><estimate.abgeben><en> A point estimate by itself might be a good start to think about the total population (it is a first good guess), but a point estimate does not provide any information how “good” this estimate is – it does not take uncretainty into account.
<G-vec00159-002-s443><estimate.abgeben><de> Nachdem der eine Wundt die Schätzung der tierischen Intelligenz auf ihr richtiges Niveau herabgeführt hat, brauchten wir jetzt einen zweiten, der unsere Neigung, uns selber ungeheuer zu überschätzen, aufdeckte.
<G-vec00159-002-s443><estimate.abgeben><en> One Wundt having reduced the estimate of animal intelligence to its right level, we should need a second to expose our tendency to overrate enormously our own importance.
<G-vec00159-002-s444><estimate.abgeben><de> Einer stellt eine niedrige Schätzung dar, und einer ist eine hohe Schätzung.
<G-vec00159-002-s444><estimate.abgeben><en> One is a low estimate, and one is a high estimate.
<G-vec00159-002-s445><estimate.abgeben><de> Die Schätzung von Mineralressourcen könnte erheblich von umwelttechnischen, genehmigungsbezogenen, rechtlichen, steuerrechtlichen, soziopolitischen, marketingbezogenen oder anderen relevanten Faktoren abhängig sein.
<G-vec00159-002-s445><estimate.abgeben><en> The estimate of mineral resources may be materially affected by environmental permitting, legal, title, taxation, sociopolitical, marketing or other relevant issues.
<G-vec00159-002-s446><estimate.abgeben><de> Die Preise auf Skyscanner beinhalten immer eine Schätzung aller zu zahlender Gebühren.
<G-vec00159-002-s446><estimate.abgeben><en> Prices displayed on Skyscanner always include an estimate of all charges that must be paid.
<G-vec00159-002-s447><estimate.abgeben><de> Die Schätzung könnte auch erheblich von globalen Wirtschaftsbedingungen beeinflusst werden, wie etwa vom Preis für Gold und Silber oder vom Preis für Öl und andere Rohstoffe, die bei der Produktion von Gold und Silber benötigt werden.
<G-vec00159-002-s447><estimate.abgeben><en> The estimate may also be materially affected by global economic conditions such as the price of gold and silver, the price of oil and other commodities utilized in the production of gold and silver.
<G-vec00159-002-s448><estimate.abgeben><de> Suchergebnisse schätzen Diese Option liefert eine Schätzung der Gesamtgröße und -anzahl der Objekte, die von der Suche auf der Grundlage der angegebenen Kriterien zurückgegeben werden.
<G-vec00159-002-s448><estimate.abgeben><en> Estimate search results This option returns an estimate of the total size and number of items that will be returned by the search based on the criteria you specified.
<G-vec00159-002-s449><estimate.abgeben><de> Die Studie ergab, dass zu viel Fett um die Taille ein ebenso zuverlässiger Indikator für das Adipositas-bedingte Krebsrisiko sein kann wie der Body-Mass-Index (BMI), eine Schätzung des Körperfettanteils auf Grundlage von Gewicht und Körpergröße.
<G-vec00159-002-s449><estimate.abgeben><en> The study revealed that too much fat around the waist is as good an indicator of obesity-related cancer risk as body mass index (BMI), which is an estimate of body fat based on weight and height.
<G-vec00159-002-s450><estimate.abgeben><de> Das englische 5 Pfund Stück 1839 „Una and the Lion“ (Los 2030) brachte CHF 170‘000.- bei einer Schätzung von CHF 100‘000.- Die ganze Auktion 25 erreichte ein Ergebnis von CHF 3‘700‘850.- etwa 40% über der Schätzung.
<G-vec00159-002-s450><estimate.abgeben><en> The English 5 Pounds 1839 “Una and the Lion” (lot 2030) realised CHF 170’000.- at an estimate of CHF 100’000.-. The whole auction 25 achieved CHF 3’700’850.-, about 40% above estimate.
<G-vec00159-002-s452><estimate.abgeben><de> Mit diesem Tool können Sie die Schätzung Ihres Mining-Gewinns für verschiedene Kryptowährungen und Algorithmen berechnen.
<G-vec00159-002-s452><estimate.abgeben><en> Using this tool you will be able to calculate the estimate of your mining profit for various cryptocurrency and algorithm.
<G-vec00159-002-s453><estimate.abgeben><de> In den letzten Tagen haben wir gesehen, wie die Hauptproduzenten ausgedehnte Schließungen ihrer Minen und Mühlen angekündigt haben, was nach unserer Schätzung das weltweite Uranproduktionsvolumen um über 50% reduziert hat.
<G-vec00159-002-s453><estimate.abgeben><en> In recent days we have seen the major producers announce extended closures of their mines and mills which we estimate has reduced global uranium production volumes by over 50%.
<G-vec00159-002-s454><estimate.abgeben><de> In ihrer raumgreifenden Art ist sie eine mehr als respektable Erscheinung und führt mit einer Schätzung von € 300.000-400.000 den Bereich der Skulpturen an.
<G-vec00159-002-s454><estimate.abgeben><en> The spacious work with its stunning presence leads the sculpture section with an estimate of € 300,000-400,000.
<G-vec00159-002-s455><estimate.abgeben><de> Hierfür können verschiedene Methoden verwendet werden, SKF empfiehlt jedoch die folgende Methode zur möglichst genauen Schätzung bei Hochgenauigkeitslagern der Reihe „Super-Precision Bearings“.
<G-vec00159-002-s455><estimate.abgeben><en> Various methods can be used, however, SKF recommends the following to assist in making the best estimate for super-precision bearings.
<G-vec00159-002-s456><estimate.abgeben><de> Nach Schätzungen der EU ist bereits bei den Stromverbräuchen eine Senkung von mindestens 50 Prozent realistisch.
<G-vec00159-002-s456><estimate.abgeben><en> According to a realistic estimate by the EU, virtualization slashes power consumption by 50 percent or more.
<G-vec00159-002-s457><estimate.abgeben><de> Was die Anzahl der in Süddeutschland lebenden Tschechen angeht, müssen wir uns mit Schätzungen zufriedengeben.
<G-vec00159-002-s457><estimate.abgeben><en> Regarding the number of Czechs living in southern Germany, we must be satisfied with an estimate.
<G-vec00159-002-s458><estimate.abgeben><de> Nach Schätzungen der Vereinten Nationen bringt jeder Dollar für die Aufforstung ganze USD 2,50 zusätzlich an lokalem Einkommen und Nutzen.
<G-vec00159-002-s458><estimate.abgeben><en> The United Nations estimate that for every dollar spent on reforestation, USD 2.50 is generated in local downstream income and benefits.
<G-vec00159-002-s459><estimate.abgeben><de> Alle Schätzungen darüber, wie viel Affiliates durch die Bewerbung unseres Produkts verdienen können, sind nur Schätzungen und keine Garantie.
<G-vec00159-002-s459><estimate.abgeben><en> Any estimates of how much affiliates can make by promoting our product is just an estimate and not a guarantee.
<G-vec00159-002-s460><estimate.abgeben><de> Die Schätzungen werden Beiträge der jüngsten Entdeckungen in den Zonen Zoe, Martina, Carla und Esperanza-Nini beinhalten.
<G-vec00159-002-s460><estimate.abgeben><en> The estimate will include contributions from recent discoveries at the Zoe, Martina, Carla, and Esperanza-Nini zones.
<G-vec00159-002-s461><estimate.abgeben><de> (1) Die Angaben über die Reparaturfristen beruhen auf Schätzungen und sind daher nicht verbindlich.
<G-vec00159-002-s461><estimate.abgeben><en> (1) The turnaround indicated for any repair is only an estimate and is therefore not binding.
<G-vec00159-002-s462><estimate.abgeben><de> EFRAG unterstützt im Wesentlichen die Vorschläge des IASB, empfiehlt aber die Entwicklung einiger zusätzlicher erläuternden Beispiele, um die Unterscheidung zwischen Rechnungslegungsmethoden und rechnungslegungsbezogenen Schätzungen weiter zu verdeutlichen.
<G-vec00159-002-s462><estimate.abgeben><en> EFRAG supports the IASB proposals; however, EFRAG recommends the development of some more illustrative examples in order to further clarify the distinction between an accounting policy and an accounting estimate.
<G-vec00159-002-s463><estimate.abgeben><de> “Nach Schätzungen ist in rund 58.000 Fällen im Norden (rund ein Viertel der Bevölkerung) eine Frau für das Familienoberhaupt”.
<G-vec00159-002-s463><estimate.abgeben><en> "According to one estimate, 58,000 households in the north, accounting for a quarter of the population, are headed by women".
<G-vec00159-002-s464><estimate.abgeben><de> Es gibt keine exakten empirischen Daten über den Gesamtumsatz des globalen Kunstmarktes, nach Schätzungen von Experten hatte er 2011 ein Volumen von rund 46 Milliarden Dollar – eine Steigerung von über 60 Prozent innerhalb von zwei Jahren.
<G-vec00159-002-s464><estimate.abgeben><en> There is no exact empirical data on the total profits of the global art market, but experts estimate a sales volume of around forty-six billion dollars in 2011—an increase of over sixty percent in two years.
<G-vec00159-002-s465><estimate.abgeben><de> Nach offiziellen Schätzungen wurden 50.000 muslimische Frauen in Indien und 33.000 Hindu und Sikh Frauen in Pakistan verschleppt.
<G-vec00159-002-s465><estimate.abgeben><en> The official estimate of the number of abducted women was placed at 50,000 Muslim women in India and 33,000 Hindu and Sikh women in Pakistan.
<G-vec00159-002-s466><estimate.abgeben><de> Zählungen in den 70er Jahren zeigten, dass der Bestand der Gorillas seit den ersten Schätzungen von Schaller stark abgenommen hatte.
<G-vec00159-002-s466><estimate.abgeben><en> Censuses during the 1970s showed that the gorilla population had declined since Schaller's estimate.
<G-vec00159-002-s467><estimate.abgeben><de> Nach Schätzungen von Experten entstehen deutschen Tankstellen durch diese Delikte jährlich ein Schaden von rund 200 Millionen Euro.
<G-vec00159-002-s467><estimate.abgeben><en> Experts estimate that, due to these crimes, German petrol stations suffer damages in the amount of approximately 200 million euros every year.
<G-vec00159-002-s468><estimate.abgeben><de> Du kannst im Internet Kalorienrechner finden, die dir detaillierte Schätzungen bieten können.
<G-vec00159-002-s468><estimate.abgeben><en> You can find calorie calculators online that will provide a detailed estimate.
<G-vec00159-002-s469><estimate.abgeben><de> Die drei Hauptziele dieser Arbeit waren i) die Unterschiede zwischen den Observatorien hinsichtlich Vegetationszusammensetzung, Pflanzendiversitat und Standortfaktoren auf unterschiedlichen Skalenebenen herauszufinden und vor dem Hintergrund unterschiedlicher Beweidungsintensitaten zu bewerten, ii) Schätzungen fur die Gesamtartenvielfalt jedes der Observatorien abzugeben unter der Anwendung und im Vergleich dreier verschiedener Extrapolationsmethoden, die gewöhnlich in der Biodiversitätsforschung Verwendung finden (Art-Areal-Beziehung = SAR, Art-Stichproben-Beziehung = SSR, sowie nicht-parametrische Vielfaltschätzverfahren) und iii) den Einfluss des Zeitaufwands auf den Grad der Vollständigkeit von floristischen Bestandsaufnahmen auf dem Maßstab von einem Hektar zu testen.
<G-vec00159-002-s469><estimate.abgeben><en> The study had three major goals: i) to identify differences between the Observatories at different spatial scales regarding plant diversity, vegetation composition, and site conditions and to evaluate them with respect to the differing grazing intensities; ii) to give an estimate of the total plant species richness of each Observatory by applying and comparing three different extrapolation methods commonly used in biodiversity research (species-area relationships = SARs; species-sampling relationships = SSRs; non-parametric richness estimators); and iii) to test the influence of time effort on the degree of completeness of floristic inventories at the 1-ha scale.
<G-vec00159-002-s470><estimate.abgeben><de> 3 Keine qualifizierte Person hat ausreichende Arbeiten durchgeführt, um die historische Mineralressourcenschätzung als aktuelle Mineralressourcenschätzung zu klassifizieren, weshalb Gold Lion die Schätzungen nicht als aktuelle Mineralressource gemäß National Instrument 43-101 behandelt.
<G-vec00159-002-s470><estimate.abgeben><en> 3A Qualified Person has not performed sufficient work to classify the historic mineral resource estimate as a current mineral resource estimate, and Gold Lion is not treating the estimate as a current NI 43-101 compliant mineral resource.
<G-vec00161-002-s070><comment.abgeben><de> Für klar eloxierte Schienen geben Sie bitte "CA" in der Bemerkung an.
<G-vec00161-002-s070><comment.abgeben><en> For clear anodized rails enter "CA" in the comment.
<G-vec00161-002-s071><comment.abgeben><de> Mache eine Frau während der Heimfahrt in öffentlichen Verkehrsmitteln auf dich aufmerksam, indem du eine lustige Bemerkung über etwas Relevantes machst und dich dann vorstellst.
<G-vec00161-002-s071><comment.abgeben><en> Catch a woman's eye while commuting home on public transportation and make an amusing comment about something relevant, then introduce yourself.
<G-vec00161-002-s072><comment.abgeben><de> Die Frage oder Bemerkung, bezüglich derer Sie Kontakt mit uns aufnehmen möchten.
<G-vec00161-002-s072><comment.abgeben><en> The query or comment about which you would like us to contact you.
<G-vec00161-002-s073><comment.abgeben><de> "Wir dachten über einige Namen nach, aber irgendjemand ließ mir gegenüber die Bemerkung fallen, dass meine Eltern mir einen schönen Namen gegeben haben.
<G-vec00161-002-s073><comment.abgeben><en> "We struggled with several names, but somebody made the comment to me that my parents gave me a beautiful name.
<G-vec00161-002-s074><comment.abgeben><de> Posten Sie eine Frage oder Bemerkung - wir antworten rasch.
<G-vec00161-002-s074><comment.abgeben><en> Simply post your question or comment, and we’ll respond as quickly as possible.
<G-vec00161-002-s075><comment.abgeben><de> Weiterhin kann Ihr Kunde eine Bemerkung schreiben und bei der Bestellung Abholung/Lieferung wählen (kann auch deaktiviert werden).
<G-vec00161-002-s075><comment.abgeben><en> Furthermore, your customer can write a comment in notes and choose the delivery method when ordering. Your customer can choose between pick up or delivery.
<G-vec00161-002-s076><comment.abgeben><de> Der Name Led Zeppelin fiel ihnen erst später ein, nach einer abfälligen Bemerkung eines Musiker-Kollegen.
<G-vec00161-002-s076><comment.abgeben><en> The name Led Zeppelin only occurred to them later after a derogatory comment by fellow musicians.
<G-vec00161-002-s077><comment.abgeben><de> Und wenn gesprochen wird, dann oft als Zuruf auf der Straße, als Bemerkung auf der Arbeit, stets den Linien des Patriarchats von oben nach unten folgend.
<G-vec00161-002-s077><comment.abgeben><en> And when someone does speak, then it’s often as a catcall on the street, as a comment at work, always following the lines of the patriarchy from top to bottom.
<G-vec00161-002-s078><comment.abgeben><de> Polly Angell erinnerte sich an eine Bemerkung von Joseph Smith, der sagte, als er sie arbeiten sah: „Die Schwestern sind immer die Ersten und allen voran bei allen guten Werken.
<G-vec00161-002-s078><comment.abgeben><en> Polly Angell recalled a comment by Joseph Smith as he saw them working. He said: “The sisters are always first and foremost in all good works.
<G-vec00161-002-s079><comment.abgeben><de> n der Veranschaulichung vom „treuen und verständigen Sklaven“ ist es interessant, auf die Bemerkung in Lukas 12:43-45 zu achten: „Glücklich ist JENER Sklave, wenn ihn sein Herr bei der Ankunft so tuend findet.
<G-vec00161-002-s079><comment.abgeben><en> In the illustration of the “Faithful and Discreet Slave” it is interesting to note the comment made in Luke 12: 43-45; “Happy is THAT slave, if his master on arriving finds him doing so!
<G-vec00161-002-s080><comment.abgeben><de> Sound Port x, Tonhöhe, Tonlänge Die Berechnung steht im Listing als Bemerkung.
<G-vec00161-002-s080><comment.abgeben><en> Sound Port x, the frequency and duration calculations can be found in the listing as a comment.
<G-vec00161-002-s081><comment.abgeben><de> Die Gefahren aber, die das zur Folge haben könnte, hatte er erst durch die Bemerkung des Fabrikanten erkannt.
<G-vec00161-002-s081><comment.abgeben><en> But it was only the manufacturer's comment that made K. realise what dangers that could lead to.
<G-vec00161-002-s082><comment.abgeben><de> Diese Umkehr des alten millitärischen Sinn für Ehre, wird in Buddhas Bemerkung wiedergegeben, daß besser als der Sieg im Kampf gegenüber abertausende Männer, dee Sieg über eine einzelne Person ist: sich selbst.
<G-vec00161-002-s082><comment.abgeben><en> This inversion of the old military sense of honor is echoed in the Buddha’s comment that better than victory in battle over a thousand-thousand men is victory over one person: yourself.
<G-vec00161-002-s083><comment.abgeben><de> Es kann eine Bemerkung eingegeben werden.
<G-vec00161-002-s083><comment.abgeben><en> A comment can be entered.
<G-vec00161-002-s084><comment.abgeben><de> Main negative Bemerkung ist, dass Matratze auf dem Bett ersetzt werden muss.
<G-vec00161-002-s084><comment.abgeben><en> Main negative comment is that mattress on bed in need of replacement.
<G-vec00161-002-s085><comment.abgeben><de> Dazu das schiefe Lächeln und die fragende Bemerkung: „Wo hänge ich die nur hin?“ Nicht als Klage gemeint, sondern als reumütiges Eingeständnis eines Mannes, in dessen Wohnung überall Regale bis obenhin mit Büchern in vier oder fünf Sprachen gefüllt waren.
<G-vec00161-002-s085><comment.abgeben><en> The odd smile and the comment of, “Where will I put these up?” Not as complaint but just as rueful admission from a man whose interiors were full of shelves holding books in four or five languages.
<G-vec00161-002-s086><comment.abgeben><de> Bemerkung: Für die Erkennung dieses Falles muss noch eine geeignete und effiziente Erkennungsstrategie ausgearbeitet werden.
<G-vec00161-002-s086><comment.abgeben><en> Comment: To detect this case a appropriate and efficient detection-strategy must be elaborated
<G-vec00161-002-s087><comment.abgeben><de> Die grundsätzlichste Bemerkung ist wie folgt.
<G-vec00161-002-s087><comment.abgeben><en> The most important comment is as follows:
<G-vec00161-002-s088><comment.abgeben><de> K. Auf die letzte Bemerkung antwortete K. nur damit, daß er Leni umfaßte und an sich zog, sie lehnte still den Kopf an seine Schulter.
<G-vec00161-002-s088><comment.abgeben><en> replied to that last comment merely by embracing Leni and drawing her towards him, she lay her head quietly on his shoulder.
<G-vec00161-002-s144><comment.abgeben><de> Ein Sprecher von Ben Stiller stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s144><comment.abgeben><en> A rep for Ben Stiller was not immediately available for comment.
<G-vec00161-002-s145><comment.abgeben><de> Ein Sprecher von Pedro Almodóvar stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s145><comment.abgeben><en> A rep for Alain Souchon was not immediately available for comment.
<G-vec00161-002-s146><comment.abgeben><de> Weder ein Like noch ein Kommentar.
<G-vec00161-002-s146><comment.abgeben><en> We didn’t get one Like or comment.
<G-vec00161-002-s147><comment.abgeben><de> Ein Sprecher von Quincy Jones stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s147><comment.abgeben><en> A rep for Hozier was not immediately available for comment.
<G-vec00161-002-s148><comment.abgeben><de> Ein Sprecher von Alexandre Jardin stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s148><comment.abgeben><en> A rep for Alexandre Jardin was not immediately available for comment.
<G-vec00161-002-s149><comment.abgeben><de> Ein Sprecher von Harry Lennix stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s149><comment.abgeben><en> A rep for Harry Lennix was not immediately available for comment.
<G-vec00161-002-s150><comment.abgeben><de> Ein Sprecher von Cristine Reyes stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s150><comment.abgeben><en> A rep for Jan Smithers was not immediately available for comment.
<G-vec00161-002-s151><comment.abgeben><de> Ein Sprecher von Agnès Jaoui stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s151><comment.abgeben><en> A rep for Agnès Jaoui was not immediately available for comment.
<G-vec00161-002-s152><comment.abgeben><de> Ein Sprecher von Malgosia Bela stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s152><comment.abgeben><en> A rep for Claire Chazal was not immediately available for comment.
<G-vec00161-002-s153><comment.abgeben><de> Ein Sprecher von Alain Souchon stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s153><comment.abgeben><en> A rep for Eric Clapton was not immediately available for comment.
<G-vec00161-002-s154><comment.abgeben><de> Ein Sprecher von Ben Shapiro stand nicht sofort für ein Kommentar zur Verfügung.
<G-vec00161-002-s154><comment.abgeben><en> A rep for Ben Shapiro was not immediately available for comment.
<G-vec00161-002-s156><comment.abgeben><de> Bitte beachten Sie die folgenden Hinweise, bevor Sie eine Frage oder ein Kommentar übermitteln: Bei medizinischen Notfällen kontaktieren Sie bitte den Notdienst oder Ihren Hausarzt.
<G-vec00161-002-s156><comment.abgeben><en> Before you submit a questions or comment, please consider the following: If you have a medical emergency, contact your local doctor, or your local Accident & Emergency room.
<G-vec00161-002-s157><comment.abgeben><de> Sorry, kaum ein Kommentar, ich schwelge in Erinnerung an eine Zeit, in der keine offenen Rassisten im Bundestag waren.
<G-vec00161-002-s157><comment.abgeben><en> Sorry, no comment on anything, I'm reliving the fond memory of when there were no open racists in the German government.
<G-vec00161-002-s158><comment.abgeben><de> Anschließend freut sich der Verfasser des ursprünglichen Artikels, dass Sie zu seinem Blog verlinken, und vielleicht gibt er auch noch einen Kommentar zu Ihrer Interpretation ab – eine echte Win-Win-Situation.
<G-vec00161-002-s158><comment.abgeben><en> As a bonus, the author of the original article will appreciate your inbound link to his/her blog and may even comment on your interpretation. Win win.
<G-vec00161-002-s159><comment.abgeben><de> Keiner der Porno-Spammer war für einen Kommentar zu erreichen.
<G-vec00161-002-s159><comment.abgeben><en> None of the porn spammers could be reached for comment.
<G-vec00161-002-s160><comment.abgeben><de> Im Jahr 1968, als Stanley Kubrick um einen Kommentar zur metaphysischen Bedeutung des Films 2001: Odyssee im Weltraum gebeten wurde, antwortete er: "Ich wollte die Botschaft des Films niemals in Worte fassen.
<G-vec00161-002-s160><comment.abgeben><en> In 1968, when Stanley Kubrick was asked to comment on the metaphysical significance of 2001: A Space Odyssey, he replied: “It’s not a message I ever intended to convey in words. 2001 is a nonverbal experience….
<G-vec00161-002-s161><comment.abgeben><de> Wenn Sie einen Kommentar auf unserer Website schreiben, kann das eine Einwilligung sein, Ihren Namen, E-Mail-Adresse und Website in Cookies zu speichern.
<G-vec00161-002-s161><comment.abgeben><en> When you post a comment on our website, you may be agreeing to have your name, email address and website stored in cookies.
<G-vec00161-002-s162><comment.abgeben><de> Im Verlauf der Diskussionen, in denen jeder meiner Gesprächspartner mir beteuerte, wie sehr er die freie Demokratie in Israel schätze, baten sie mich um einen Kommentar zur gegenwärtigen Lage.
<G-vec00161-002-s162><comment.abgeben><en> In our discussions, during which each of my opposite numbers told me how much they appreciated Israel’s liberal democracy, I was asked to comment on the current situation.
<G-vec00161-002-s163><comment.abgeben><de> Wenn Du einen Tweet versendest, kannst Du einen Retweet oder einen Kommentar von einem Follower erhalten und so mit der Zeit Vertrauen aufbauen.
<G-vec00161-002-s163><comment.abgeben><en> When you send a tweet, you can get a retweet or comment from a follower and, over time, build trust.
<G-vec00161-002-s164><comment.abgeben><de> Und wer für seine kleine Tochter, Enkeltochter, Nichte oder Cousine ein zuckersüßes Röckchen nähen möchte, der sollte jetzt unter diesem Beitrag schnell bis morgen früh einen Kommentar schreiben und ein weiteres Mal feste die Daumen drücken.
<G-vec00161-002-s164><comment.abgeben><en> And who wants to sew a sugar-sweet tutu for his little daughter, granddaughter, niece or cousin has to write a comment beneath this post until tomorrow morning 8 CET!
<G-vec00161-002-s165><comment.abgeben><de> Wir bieten Ihnen auf unserer Seite die Möglichkeit, nachfolgende Kommentare zu einem Beitrag, zu dem Sie im Begriff sind, einen Kommentar zu verfassen, zu abonnieren.
<G-vec00161-002-s165><comment.abgeben><en> Subscribing to Comments On our website, we may offer you the opportunity to subscribe to subsequent comments about an article which you intend to comment on.
<G-vec00161-002-s166><comment.abgeben><de> DEUTSCH: Nur registrierte Benutzer mit OPEN ID dürfen einen Kommentar schreiben.Alle die bei Google oder Yahoo ein Konto haben, sind automatisch registrierte Benutzer.
<G-vec00161-002-s166><comment.abgeben><en> ENGLISH: Only registered users with an OPEN ID can comment every theme. Those who have profiles in Google and Yahoo are registered users by default.
<G-vec00161-002-s167><comment.abgeben><de> Seine Aufnahmen geben über ihren dokumentarischen Wert hinaus gleichsam einen Kommentar über das fotografierte Bauwerk.
<G-vec00161-002-s167><comment.abgeben><en> His photographs do not only document buildings, but comment on them, as it were.
<G-vec00161-002-s168><comment.abgeben><de> TMZ konnte Alejandra für einen Kommentar nicht erreichen.
<G-vec00161-002-s168><comment.abgeben><en> We could not reach Alejandra for comment.
<G-vec00161-002-s169><comment.abgeben><de> 9.2 An andere Nutzer unseres Dienstes, wenn du persönliche Informationen in eine Rezension, einen Beitrag, einen Kommentar oder eine andere öffentliche Aktion zu unserem Dienst einbringst.
<G-vec00161-002-s169><comment.abgeben><en> 8.2 To other users of our service, if you include personal information in a review, post, comment or other public action on our service.
<G-vec00161-002-s170><comment.abgeben><de> Teilen Sie unsere Twitter, Facebook or Instagram Seiten und hinterlassen Sie eine Rezension oder einen Kommentar.
<G-vec00161-002-s170><comment.abgeben><en> Share our Twitter, Facebook or Instagram pages and leave a review or comment.
<G-vec00161-002-s171><comment.abgeben><de> Vielen Dank für einen Kommentar.
<G-vec00161-002-s171><comment.abgeben><en> Thanks for the comment.
<G-vec00161-002-s172><comment.abgeben><de> Um einen Kommentar zu löschen, melden Sie sich an und lassen Sie die Kommentare zum jeweiligen Beitrag anzeigen.
<G-vec00161-002-s172><comment.abgeben><en> admin comment, just log in and view the post's comments.
<G-vec00161-002-s173><comment.abgeben><de> F: Wärst Du so freundlich und gibst uns einen Kommentar zu den gemeldeten Hunden auf der Specialty, besonders zu den Hunden, die möglicherweise Rennblut tragen.
<G-vec00161-002-s173><comment.abgeben><en> Q – Would you care to comment about the specialty entry, especially the dogs who might have racing blood behind them.
<G-vec00161-002-s174><comment.abgeben><de> Wir freuen uns, ein Update zu den Aktivitäten bei unserer Silber-Gold-Lagerstätte La Preciosa und einen Kommentar zu den zu erwartenden Entwicklungen in den kommenden Monaten zu veröffentlichen.
<G-vec00161-002-s174><comment.abgeben><en> We are pleased to provide an update on the activities at our La Preciosa silver-gold deposit and to comment on expected developments for the upcoming months.
<G-vec00161-002-s175><comment.abgeben><de> Variante 2: Speichern Sie den Eintrag ohne Hashtags, kopieren Sie die Gruppe von 30 Hashtags und fügen Sie sie als einen Kommentar unter ihren Eintrag.
<G-vec00161-002-s175><comment.abgeben><en> 2nd way: save the publication without hashtags, copy the group of 30 hashtags and insert them into the comment under your post.
<G-vec00161-002-s176><comment.abgeben><de> Das Kanzleramt lehnte einen Kommentar ab, und während viele nun glauben, die Verbindung des Bildes zu Merkel sei eine Intrige, gibt es genug Gründe, zu denken, dass Merkel, die in einer ostdeutschen Kleinstadt nördlich von Berlin aufwuchs, habe sich vor Jahren nackt vergnügt.
<G-vec00161-002-s176><comment.abgeben><en> The German chancellor’s office declined to comment, and while many now believe the photograph’s association with Merkel to be a hoax, there’s plenty of reason to think that Merkel, who grew up in a small East German town north of Berlin, came of age frolicking in the nude.
<G-vec00161-002-s177><comment.abgeben><de> Die angegebene E-Mail-Adresse wird gespeichert, jedoch nicht mit dem Kommentar veröffentlicht.
<G-vec00161-002-s177><comment.abgeben><en> The email address you provide will be saved but will not be published along with your comment.
<G-vec00161-002-s178><comment.abgeben><de> Wenn Sie keine anonyme Anzeige ausgewählt haben, werden Ihr Vor- und Nachname mit Ihrem Kommentar auf unserer Website veröffentlicht.
<G-vec00161-002-s178><comment.abgeben><en> If you have not chosen the anonymous mode, your name and surname will be published along with your comment on our website.
<G-vec00161-002-s179><comment.abgeben><de> JoshDun hat einen neuen Kommentar ins Gästebuch geschrieben.
<G-vec00161-002-s179><comment.abgeben><en> PinkSaint placed a comment in the guestbook.
<G-vec00161-002-s180><comment.abgeben><de> Nehmen Sie an der Diskussion teil und hinterlassen Sie einen Kommentar.
<G-vec00161-002-s180><comment.abgeben><en> Join in the discussion and leave a comment.
<G-vec00161-002-s181><comment.abgeben><de> Streifen nach rechts wiederholt, bis Sie hören "Neuer Kommentar, Schaltfläche" und Doppeltippen Sie auf dem Bildschirm.
<G-vec00161-002-s181><comment.abgeben><en> Swipe right repeatedly until you hear "New comment, button," and double-tap the screen.
<G-vec00161-002-s182><comment.abgeben><de> Zusammenfassung: Durchschnittliche Bewertung von Windows Explorer.exe: basierend auf 1 Bewertung mit 1 Kommentar.
<G-vec00161-002-s182><comment.abgeben><en> Summary: Average user rating of Windows Explorer.exe: based on 1 vote with 1 user comment.
<G-vec00161-002-s183><comment.abgeben><de> Schreiben Sie uns einfach die Anzahl der Unterschiede als Kommentar unter diesen Artikel und verraten Sie uns in Ihrem Kommentar ebenso, warum Sie gerade in London Englisch lernen möchten.
<G-vec00161-002-s183><comment.abgeben><en> Comment below this article, stating how many differences you found and tell us in your comment, why you would like to learn English, especially in London.
<G-vec00161-002-s184><comment.abgeben><de> Benutzer-Zusammenfassung: Durchschnittliche Bewertung von GetWordNT.dll: basierend auf 1 Bewertung mit 1 Kommentar.
<G-vec00161-002-s184><comment.abgeben><en> Summary: Average user rating of GetWordNT.dll: based on 1 vote with 1 user comment.
<G-vec00161-002-s185><comment.abgeben><de> Sie können den Kommentar, den wir gerade erstellt haben, auch hier im Admin-Panel sehen, und von hier aus können Sie ihn löschen, wenn Sie möchten.
<G-vec00161-002-s185><comment.abgeben><en> You can see the comment we just created here in the admin panel as well, and it is from here that you can delete it if you want.
<G-vec00161-002-s186><comment.abgeben><de> Ein Kunde schrieb folgenden Kommentar auf Trusted Shops: Der Wagen wurde etwas verspätet geliefert und auch bei der Abholung war die Pünktlichkeit nicht sehr gut, aber es war im vertretbaren Rahmen.
<G-vec00161-002-s186><comment.abgeben><en> A customer wrote the following comment on Trusted Shops: The car was delivered a little late and was also picked up a bit late, but it was acceptable.
<G-vec00161-002-s187><comment.abgeben><de> Die neuesten Top-Post-Links zum neuesten Kommentar zu einem Thema, das seit Mai 2017 läuft und nur etwa 50 Kommentare hat, von denen die meisten nicht einmal Bilder sind.
<G-vec00161-002-s187><comment.abgeben><en> The top most recent post links to the most recent comment on a thread that’s been going since May of 2017 and it only has 50 or so comments, most of which aren’t even pics.
<G-vec00161-002-s188><comment.abgeben><de> Kommentare über Mooser Muschelkalk Rotbank Sie kennen den Naturstein Mooser Muschelkalk Rotbank gut, oder Sie haben Fragen zu Mooser Muschelkalk Rotbank, dann schreiben Sie einen Kommentar.
<G-vec00161-002-s188><comment.abgeben><en> More about Lime Pink: Comments about Lime Pink You know the stone Lime Pink well or have a question about Lime Pink, then post a comment here.
<G-vec00161-002-s189><comment.abgeben><de> Wenn ihr die Termine eurer Veranstaltungen veröffentlichen wolllt schreibt uns einen Kommentar oder kontaktiert uns unter libertad-patishtan@riseup.net.
<G-vec00161-002-s189><comment.abgeben><en> If you’d like to publish dates and events, write a comment on THIS PAGE or contact us at libertad-patishtan@riseup.net.
<G-vec00161-002-s190><comment.abgeben><de> Ihr Kommentar muss nicht das Werk als Ganzes behandeln, sondern darf gern fragmenthaften Charakter haben und nur einzelne Kapitel oder Aspekte einer Publikation beleuchten.
<G-vec00161-002-s190><comment.abgeben><en> Your comment does not have to deal with a publication as a whole, but can rather highlight individual chapters or aspects.
<G-vec00161-002-s191><comment.abgeben><de> Mitglieder Zusammenfassung: Durchschnittliche Bewertung von avciman.exe: basierend auf 3 Bewertungen mit 1 Kommentar.
<G-vec00161-002-s191><comment.abgeben><en> Summary: Average user rating of avciman.exe: based on 3 votes with 1 user comment.
<G-vec00161-002-s192><comment.abgeben><de> 15 March 2019 Hallo, dies ist ein Kommentar.
<G-vec00161-002-s192><comment.abgeben><en> A WordPress Commenter 2019Hi, this is a comment.
<G-vec00161-002-s193><comment.abgeben><de> Das bemängeln die Verantwortlichen in ihrem Kommentar zum Anlagensicherheits-Report 2018 .
<G-vec00161-002-s193><comment.abgeben><en> That has been a complaint of the responsible persons in their comment to the Facility Safety Report 2018 .
<G-vec00161-002-s194><comment.abgeben><de> Kommentar Hiermit stimme ich den Bedingungen und Ausführungen der Datenschutzerklärung zu.
<G-vec00161-002-s194><comment.abgeben><en> Comment I agree to the terms and conditions laid out in the Privacy Policy
<G-vec00161-002-s195><comment.abgeben><de> Du musst Dich anmelden, um einen Kommentar zu verfassen..
<G-vec00161-002-s195><comment.abgeben><en> Updated: You should log in to write a comment.
<G-vec00161-002-s196><comment.abgeben><de> Sie müssen eingeloggt sein, um einen Kommentar zu schreiben.
<G-vec00161-002-s196><comment.abgeben><en> start learning You must sign in to write a comment
<G-vec00161-002-s197><comment.abgeben><de> Hi, das ist ein Kommentar.
<G-vec00161-002-s197><comment.abgeben><en> WordPress Comment Write a comment
<G-vec00161-002-s198><comment.abgeben><de> Kommentar schreiben.
<G-vec00161-002-s198><comment.abgeben><en> Please write a comment
<G-vec00161-002-s200><comment.abgeben><de> Deinen Kommentar veröffentlichen.
<G-vec00161-002-s200><comment.abgeben><en> Bilo je Post your comment
<G-vec00161-002-s203><comment.abgeben><de> Kommentar Benachrichtige mich über nachfolgende Kommentare via E-Mail.
<G-vec00161-002-s203><comment.abgeben><en> Comment Notify me of followup comments via e-mail
<G-vec00161-002-s205><comment.abgeben><de> Nur Mitglieder können ein Kommentar hinterlassen.
<G-vec00161-002-s205><comment.abgeben><en> Login Create an account to leave a comment
<G-vec00161-002-s207><comment.abgeben><de> Schreiben Sie also einen Kommentar.
<G-vec00161-002-s207><comment.abgeben><en> Therefore, please, write a comment
<G-vec00161-002-s208><comment.abgeben><de> Kommentare Sie müssen als RUBI Club Mitglied eingeloggt sein, um einen Kommentar zu hinterlassen.
<G-vec00161-002-s208><comment.abgeben><en> Comments You need to be logged in as a Club Rubi member to leave a comment
<G-vec00161-002-s210><comment.abgeben><de> Geben Sie bitte einen Kommentar ein.
<G-vec00161-002-s210><comment.abgeben><en> L'Autre ChoseHigh for leaving a comment
<G-vec00161-002-s212><comment.abgeben><de> Informationstext, wenn ein Kommentar in einem eigenen Umlauf hinzugefügt oder geändert wurde.
<G-vec00161-002-s212><comment.abgeben><en> Information after a comment was added or changed in a circular Circular created
<G-vec00161-002-s213><comment.abgeben><de> Seien Sie die erste Person, die zu dieser Look einen Kommentar schreibt.
<G-vec00161-002-s213><comment.abgeben><en> Be the first to comment on this look. sign In
<G-vec00161-002-s215><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s215><comment.abgeben><en> When you interact with the plug-ins like pressing the Like button or leaving a comment, the corresponding information is sent directly from your browser and stored on Facebook.
<G-vec00161-002-s216><comment.abgeben><de> Wenn Nutzer mit den Social Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s216><comment.abgeben><en> If you interact with the plugins, for example by clicking “Like”, or entering a comment, the corresponding information is transmitted from your browser directly to Facebook and stored by it.
<G-vec00161-002-s217><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den “Gefällt mir” Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s217><comment.abgeben><en> If you interact with plugins, e.g. by clicking the so-called “Share” button or by entering a comment, this information will be sent directly to Facebook and stored there.
<G-vec00161-002-s218><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den "Gefällt mir" Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.Zweck und Umfang der Datenerhebung und die weitere Verarbeitung und Nutzung der Daten durch Facebook sowie Ihre diesbezüglichen Rechte und Einstellungsmöglichkeiten zum Schutz Ihrer Privatssphäre entnehmen Sie bitte den Datenschutzhinweisen von Facebook.
<G-vec00161-002-s218><comment.abgeben><en> Should you interact with the plugins, for example by clicking on the “Like” button or by posting a comment, your browser will transfer the corresponding information directly to Facebook and it will be stored there. Please access Facebook's Data Use Policy site to obtain further information on the purposes pursued by Facebook in collecting data, the scope in which it does so, as well as the further processing and use of such data; the policy also addresses your rights in this regard and the settings you may select to protect your privacy.
<G-vec00161-002-s220><comment.abgeben><de> Sofern Sie mit den Plugins interagieren, zum Beispiel den Like-Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s220><comment.abgeben><en> If you interact with the plugins, for example by clicking the 'Like' button or by posting a comment, the information you give is then sent directly to Facebook and saved there.
<G-vec00161-002-s221><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den „Pin it“-Button betätigen oder einen Kommentar abgeben, wird diese Information ebenfalls direkt an einen Server von Pinterest übermittelt und dort gespeichert.
<G-vec00161-002-s221><comment.abgeben><en> If you interact with the plugins, for example, the "Pin it" button press or make a comment, this information is also transmitted directly to a server of options and stored there.
<G-vec00161-002-s222><comment.abgeben><de> Wenn Nutzer mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s222><comment.abgeben><en> When users interact with the plugins, e.g. by activating the Like button or sharing a comment, then this information is transferred from your browser directly to Facebook and saved there.
<G-vec00161-002-s226><comment.abgeben><de> Wenn Sie einen Kommentar abgeben, speichern wir weiterhin Ihre IP-Adresse, die wir nach sechs Monaten löschen.
<G-vec00161-002-s226><comment.abgeben><en> If you make a comment, we continue to store your IP address, which we delete after one week.
<G-vec00161-002-s228><comment.abgeben><de> Wenn Nutzer mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Gerät direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s228><comment.abgeben><en> When users interact with the plugins, for example in confirming the “like” symbol or add a comment, then this is information is sent from the user’s device directly to Facebook and is stored there.
<G-vec00161-002-s229><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den „Gefällt mir“-Button betätigen oder einen Kommentar abgeben, wird diese Information ebenfalls direkt an einen Server von Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s229><comment.abgeben><en> When you interact with the plugins, for example by clicking "Like" or by posting a comment, the information is sent to your Facebook account, where it will be stored.
<G-vec00161-002-s230><comment.abgeben><de> Wenn Sie mit den Plug-Ins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.
<G-vec00161-002-s230><comment.abgeben><en> If you interact with the plug-ins (eg to leave a comment), the corresponding information is also transmitted directly to a server of the social media service and stored there.
<G-vec00161-002-s232><comment.abgeben><de> Wenn Sie mit den Plugins interagieren, zum Beispiel den Like Button betätigen oder einen Kommentar abgeben, wird die entsprechende Information von Ihrem Browser direkt an Facebook übermittelt und dort gespeichert.Falls Sie kein Mitglied von Facebook sind, besteht trotzdem die Möglichkeit, dass Facebook Ihre IP-Adresse in Erfahrung bringt und speichert.
<G-vec00161-002-s232><comment.abgeben><en> If you interact with the plug-ins e.g. press the ‘like’ button or leave a comment, the relevant information from your browser is delivered directly to Facebook and stored there. Even if you are not a member of Facebook, it is still possible that Facebook finds out and stores it.
<G-vec00161-002-s307><comment.abgeben><de> Wenn Besucher Kommentare auf der Website schreiben, sammeln wir die Daten, die im Kommentar-Formular angezeigt werden, außerdem die IP-Adresse des Besuchers und den User-Agent-String (damit wird der Browser identifiziert), um die Erkennung von Spam zu unterstützen.
<G-vec00161-002-s307><comment.abgeben><en> Commentaires When you leave a comment on our website, the data entered in the comment form, but also your IP address and the user agent of your browser are collected to help us detect unwanted comments.
<G-vec00161-002-s308><comment.abgeben><de> Wenn Nutzer Kommentare im Blog oder sonstige Beiträge hinterlassen, werden ihre IP-Adressen gespeichert.
<G-vec00161-002-s308><comment.abgeben><en> If a User leaves a comment in the blog or other posts their IP-adress will be stored.
<G-vec00161-002-s309><comment.abgeben><de> Kommentare sind geschlossen, aber Sie können ein Trackback hinterlassen: Trackback-URL.
<G-vec00161-002-s309><comment.abgeben><en> Previous Next → Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s310><comment.abgeben><de> Sobald Sie ein Telefonat beendet haben, können Sie sich die Ergebnisse in amoCRM anschauen und zusätzliche Kommentare hinzufügen.
<G-vec00161-002-s310><comment.abgeben><en> Once a call is finished, it’s you can set the Call Result in amoCRM and add extra comment before it logs under the lead profile.
<G-vec00161-002-s311><comment.abgeben><de> Es gibt noch keine Kommentare.
<G-vec00161-002-s311><comment.abgeben><en> Submit No Comment Yet.
<G-vec00161-002-s312><comment.abgeben><de> +msgstr "Ein Administrator kann Kommentarberechtigungen für Benutzergruppen vergeben und Benutzer können (optional) ihre letzten Kommentare bearbeiten, solange niemand anderes diese beantwortet hat.
<G-vec00161-002-s312><comment.abgeben><en> +msgstr "Modul comment groups, and users can (optionally) edit their last comment, assuming no others have been posted since.
<G-vec00161-002-s313><comment.abgeben><de> Bitte schreiben Sie Kommentare und lassen Sie uns wissen, was Sie über dieses Thema denken.
<G-vec00161-002-s313><comment.abgeben><en> Please, post a comment and let us know what you think about the topic.
<G-vec00161-002-s314><comment.abgeben><de> Kommentare sind geschlossen, aber du kannst ein Trackback hinterlassen: Trackback URL.
<G-vec00161-002-s314><comment.abgeben><en> Next → Related Post a comment or leave a trackback: Trackback URL.
<G-vec00161-002-s315><comment.abgeben><de> Er verneinte am Freitag weitere Kommentare über ihren Gesundheitszustand zu geben.
<G-vec00161-002-s315><comment.abgeben><en> He declined further comment on her health status Friday.
<G-vec00161-002-s316><comment.abgeben><de> Standardmäßig wird eine statistische Abfrage unter Verwendung von COUNT durchgeführt (was in obigem Beispiel für die Ermittlung der Anzahl der Kommentare und Kategorien der Fall ist).
<G-vec00161-002-s316><comment.abgeben><en> By default, a statistical query will calculate the COUNT expression (and thus the comment count and category count in the above example).
<G-vec00161-002-s317><comment.abgeben><de> Hille hat ihre skurrilen Karten in der Berliner U-Bahn verteilt und sie in Fahrkartenautomaten gesteckt, womit sie Kommentare und Gespräche provozierte.
<G-vec00161-002-s317><comment.abgeben><en> Hille handed out her quirky cards on the Berlin U-Bahn, slipping them in to ticket machines, provoking comment and conversation.
<G-vec00161-002-s318><comment.abgeben><de> Im Zweifelsfall werden wir die Antworten prüfen und eine Entscheidung zurück zur lokalen Gemeinschaft geben, um dort Kommentare und eine Prüfung zu verlangen.
<G-vec00161-002-s318><comment.abgeben><en> In ambiguous cases, stewards will evaluate the responses and will refer a decision back to the local community for their comment and review.
<G-vec00161-002-s319><comment.abgeben><de> Kommentare werden durch »#« eingeleitet; sämtlicher Text vom »#« bis zum Zeilenende wird ignoriert.
<G-vec00161-002-s319><comment.abgeben><en> Text from a "#" character until the end of the line is a comment, and is ignored.
<G-vec00161-002-s320><comment.abgeben><de> Search Spiders schreiben schließlich keine Kommentare, melden sich nicht bei Deiner Liste an und kaufen Dein Produkt nicht.
<G-vec00161-002-s320><comment.abgeben><en> After all, search spiders won’t write a comment, subscribe to your list or buy your product.
<G-vec00161-002-s321><comment.abgeben><de> Wählen Sie unter "Wer darf Kommentare erstellen" die Option Registrierte Nutzer aus, um Kommentare über OpenID und andere Konten zu aktivieren.
<G-vec00161-002-s321><comment.abgeben><en> In “Who Can Comment,” select Registered User to turn on commenting with OpenID and other accounts.
<G-vec00161-002-s322><comment.abgeben><de> Die Schwarze Botin versammelte wissenschaftliche Aufsätze, Essays, literarische Texte und Gedichte, Collagen, Glossen und satirische Kommentare.
<G-vec00161-002-s322><comment.abgeben><en> The Schwarze Botin featured academic texts, essays, literary pieces, poems and collages, as well as ironic and satirical comment.
<G-vec00161-002-s323><comment.abgeben><de> Visio Services ermöglicht Benutzern Kommentare für eine große Gruppe, ohne dass jeder Benutzer eine Version des Clients haben muss.
<G-vec00161-002-s323><comment.abgeben><en> Visio Services lets users comment across a wide group without requiring that each user have a copy of the client.
<G-vec00161-002-s324><comment.abgeben><de> Aus diesem Grunde lehnen es viele in der kommunistischen Gesellschaft Chinas aufgewachsene ab, irgendwelche negativen Kommentare über die KPC zur Kenntnis zu nehmen.
<G-vec00161-002-s324><comment.abgeben><en> That is why those of us who grew up in the Communist society refuse to listen to any negative comment about the CCP.
<G-vec00161-002-s325><comment.abgeben><de> - Bilder, Video- oder Audiodateien sowie Kommentare, die zu Bildern, Video- oder Audiodateien verlinken, deren Rechtslage, insbesondere hinsichtlich der Rechte des geistigen Eigentums, fragwürdig erscheint.
<G-vec00161-002-s325><comment.abgeben><en> - any picture, video or audio file as well as any comment linking to any picture, video or audio file whose legal status we deem questionable, in particular regarding intellectual property Managing Director)
<G-vec00161-002-s326><comment.abgeben><de> Also: Wenn ihr zur Figurenmalerei etwas wissen wollt - was auch immer - hinterlasst eure Frage in den Kommentaren unten.
<G-vec00161-002-s326><comment.abgeben><en> Now: If you would like to know something - anything - related to painting miniatures, please drop your question in the comment section below.
<G-vec00161-002-s327><comment.abgeben><de> Neben der gültigen Rechte für irgendeine Submission, wenn Sie Kommentare oder Bewertungen auf der Webseite posten, geben Sie Artisoo.com auch das Recht, den Namen mit den Besprechungen, Kommentaren oder anderen Inhalten zu nutzen, wenn überhaupt, in Verbindung mit solchen Besprechungen, Kommentaren oder anderen Inhalten.
<G-vec00161-002-s327><comment.abgeben><en> In addition to the rights applicable to any Submission, when you post comments or reviews to the site, you also grant Artisoo.com the right to use the name that you submit with any review, comment, or other Content, if any, in connection with such review, comment, or other content.
<G-vec00161-002-s329><comment.abgeben><de> Bei Fragen oder Kommentaren zu der Internetseite oder diesen Nutzungsbedingungen kontaktieren Sie uns unter: Coalesse_Concierge@coalesse.com oder über unsere gebührenfreie Rufnummer: 1-866-645-6952.
<G-vec00161-002-s329><comment.abgeben><en> To ask questions or comment about the Website or these Terms of Use, contact us at: Coalesse_Concierge@coalesse.com or via our toll-free number: 1-866-645-6952.
<G-vec00161-002-s330><comment.abgeben><de> Twitter: Wenn du einen Twitter-Account hast, kannst du im entsprechenden Feld deinen Twitter-Namen eingeben (egal ob mit oder ohne dem @), der dann bei allen (auch älteren) Kommentaren, die dieselbe E-Mail-Adresse enthalten, angezeigt wird.
<G-vec00161-002-s330><comment.abgeben><en> Twitter: If you got a Twitter account, you can enter your Twitter name (with or without the @, doesn't matter) which will then be displayed next to any comment (including old ones) that contain the same e-mail address.
<G-vec00161-002-s331><comment.abgeben><de> Hinterlassen Sie einen Kommentar in unserem Blog, werden neben den von der betroffenen Person hinterlassenen Kommentaren auch Angaben zum Zeitpunkt der Kommentareingabe sowie zu dem von der betroffenen Person gewählten Nutzernamen (Pseudonym) gespeichert und veröffentlicht.
<G-vec00161-002-s331><comment.abgeben><en> If, as a data subject, you leave a comment on one of our blogs, this comment, as well as information about the time the comment was posted and your user name (pseudonym), will be saved and published.
<G-vec00161-002-s332><comment.abgeben><de> Teile deine Gedanken zum Google Pixel 2 in den Kommentaren.
<G-vec00161-002-s332><comment.abgeben><en> Have thoughts on the Google Pixel 2? drop us a comment below!
<G-vec00161-002-s333><comment.abgeben><de> Der Kundendienst von ComeOn Sportsbook ist immer freundlich und hilft Ihnen bei Problemen, Kommentaren oder Fragen.
<G-vec00161-002-s333><comment.abgeben><en> ComeOn Sportsbook customer support service is always friendly and ready to assist you with any problem, comment or question that you might have.
<G-vec00161-002-s334><comment.abgeben><de> >> Wenn ihr noch eine offene Frage habt, beantworte ich diese natürlich gerne in den Kommentaren.
<G-vec00161-002-s334><comment.abgeben><en> >> Now, if you have anymore questions. I am more than happy to answer them via the comment section.
<G-vec00161-002-s335><comment.abgeben><de> Die Frage stellt sich, warum sie sich überhaupt zu Kommentaren bemühen, wenn doch die SEP und die Ideen, für die sie kämpft, so unwichtig sind.
<G-vec00161-002-s335><comment.abgeben><en> The dissident faction has made similar dismissive remarks—which begs the question as to why they would even bother to comment if the SEP and the ideas for which it fights were so unimportant.
<G-vec00161-002-s336><comment.abgeben><de> Bei Rückfragen, Hinweisen, Kommentaren oder Vorschlägen zu unserer Nutzung personenbezogener Daten können Sie eine E-Mail an den Datenschutzbeauftragen der Gruppe El Corte Inglés (delegado.protecciondatos@elcorteingles.es) senden.
<G-vec00161-002-s336><comment.abgeben><en> If you have any enquiry, comment or concern, or would like to comment on our use of personal information, you can email the El Corte Inglés Group Data Protection Officer at delegado.protecciondatos@elcorteingles.es
<G-vec00161-002-s337><comment.abgeben><de> Und jetzt Vergesst nicht eure wunderbaren Werke hier in den Kommentaren zu verlinken.
<G-vec00161-002-s337><comment.abgeben><en> Don’t forget to link your awesome creations here in the comment section.
<G-vec00161-002-s338><comment.abgeben><de> Sag es uns in den Kommentaren.
<G-vec00161-002-s338><comment.abgeben><en> Tell us what you think in the comment section below.
<G-vec00161-002-s339><comment.abgeben><de> Dezember oder März - bitte in den Kommentaren vermerken.
<G-vec00161-002-s339><comment.abgeben><en> December or March - please comment below the article)
<G-vec00161-002-s340><comment.abgeben><de> Bei Sprachen mit einzeiligen Kommentaren, die in vielen Programmiersprachen mit zwei Slashes beginnen, kann der Quellcode so einfach natürlich nicht minimiert werden, da alles nach dem ersten einzeiligen Kommentar auch auskommentiert werden würde.
<G-vec00161-002-s340><comment.abgeben><en> In languages with single line comment, you can’t use it to minify the code as everything after the first comment would be commented out.
<G-vec00161-002-s341><comment.abgeben><de> Diese Phishing-Seiten wurden so eingerichtet, dass sie den lokalen Nachrichtenagenturen gehören, und waren wirklich überzeugend - bis hin zu den gefälschten Kommentaren, die gefälschte Beiträge berühmter lokaler Persönlichkeiten enthielten.
<G-vec00161-002-s341><comment.abgeben><en> Said phishing pages were set up to appear to belong to local news outlets, and were really convincing – right down to the fake comment sections, containing fake posts by famous local personalities.
<G-vec00161-002-s342><comment.abgeben><de> Falls Ihr noch weitere Fragen zu den Gemeinschaften habt, fragt uns in den Kommentaren, wir beantworten eure brennendsten Themen.
<G-vec00161-002-s342><comment.abgeben><en> If you have any additional questions about Fellowships please leave them in the comment section. We will answer them!
<G-vec00161-002-s343><comment.abgeben><de> Der Gewinner wird auch in den Kommentaren des Gewinnspiel Posts angekündigt.
<G-vec00161-002-s343><comment.abgeben><en> The winner will also be announced within the giveaway post comment section.
<G-vec00161-002-s344><comment.abgeben><de> Wir verarbeiten Ihre personenbezogenen Daten, um uns im Falle einer Veröffentlichung von rechtswidrigen Kommentaren gegen Haftungsansprüche Dritter verteidigen zu können.
<G-vec00161-002-s344><comment.abgeben><en> We process your personal data in order to be able to defend ourselves against liability claims by third parties, if we publish an unlawful comment.
<G-vec00161-002-s489><comment.abgeben><de> (4) Stellt der berichterstattende Mitgliedstaat unter Berücksichtigung der von den anderen betroffenen Mitgliedstaaten vorgebrachten Anmerkungen fest, dass der Antrag keinen in Teil I des Bewertungsberichts behandelten Aspekt betrifft oder dass das Antragsdossier unvollständig ist, teilt er dies dem Sponsor über das EU-Portal mit und setzt ihm eine Frist von höchstens zehn Tagen zur Stellungnahme zum Antrag oder zur Ergänzung des Antragsdossiers über das EU-Portal.
<G-vec00161-002-s489><comment.abgeben><en> 4. Where the reporting Member State, taking into account considerations expressed by the other Member States concerned, finds that the application does not concern an aspect covered by Part I of the assessment report or that the application dossier is not complete, it shall inform the sponsor thereof through the EU portal and shall set a maximum of 10 days for the sponsor to comment on the application or to complete the application dossier through the EU portal.
<G-vec00161-002-s490><comment.abgeben><de> Auch die großen Internetkonzerne Alibaba Group und Tencent, die ebenfalls Musikstreaming-Dienste in China anbieten, waren zu keiner Stellungnahme bereit.
<G-vec00161-002-s490><comment.abgeben><en> Alibaba Group and Tencent, two other Chinese Internet giants with music streaming services, did not respond to a request for comment.
<G-vec00161-002-s491><comment.abgeben><de> Die Gleichbehandlungsanwältin verfasst zunächst ein Schreiben an den Geschäftsführer der Diskothek sowie den Geschäftsführer des Security-Unternehmens, wobei sie den Vorfall schildert, auf die rechtlichen Bestimmungen des Geichbehandlungsgesetzes verweist und um Stellungnahme zu dem Vorfall ersucht.
<G-vec00161-002-s491><comment.abgeben><en> The Ombud for Equal Treatment drafted a letter to the manager of the disco as well as the manager of the security company, in which she described the incident, informed on the legal provisions of the Equal Treatment Act and requested them to comment on the incident.
<G-vec00161-002-s492><comment.abgeben><de> Die Arbeitsgruppe eröffnet ihre Stellungnahme zum IASB-Entwurf ED/2013/6 Leasingverhältnisse damit, dass sie ausdrücklich darauf hinweist, dass die entwickelten Konzepte gut in die Welt islamischer Bilanzierung passen und dass herausragende Scharia'a-Gelehrte den IASB für dessen Vorschläge loben.
<G-vec00161-002-s492><comment.abgeben><en> The working group opens its comment letter on the IASB's ED/2013/6 Leases by expressly stating that the concepts developed fit well into the world of Islamic accounting and prominent Sharia'a scholars commend the IASB for the proposals.
<G-vec00161-002-s493><comment.abgeben><de> „(4) Beabsichtigt die Kommission, die Anwendung bestimmter Normen und/oder Spezifikationen verbindlich vorzuschreiben, so veröffentlicht sie eine Bekanntmachung im Amtsblatt der Europäischen Union und fordert alle Beteiligten zur Stellungnahme auf.
<G-vec00161-002-s493><comment.abgeben><en> 4. Where the Commission intends to make the implementation of certain standards and/or specifications compulsory, it shall publish a notice in the Official Journal of the European Communities and invite public comment by all parties concerned.
<G-vec00161-002-s494><comment.abgeben><de> In diesem Rahmen werden, wenn möglich, Vorschläge zur Lösung Ihres Anliegens entwickelt, die Ihnen anschließend zur Stellungnahme oder Entscheidung vorgelegt werden.
<G-vec00161-002-s494><comment.abgeben><en> Within this framework we will, if possible, develop suggestions to solve your problem, which we will then present you to comment or decide.
<G-vec00161-002-s495><comment.abgeben><de> Über Inhalt und Umfang etwaiger Rückrufmaßnahmen wird uns der Besteller – soweit möglich und zumutbar – vorab unterrichten und uns Gelegenheit zur Stellungnahme geben.
<G-vec00161-002-s495><comment.abgeben><en> We will inform the supplier in advance of the content and scope of the recall measures to be implemented and give the supplier the opportunity to comment, provided this is possible and reasonable.
<G-vec00161-002-s496><comment.abgeben><de> In einer Stellungnahme gegenüber der Deutschen Botschaft unterstreicht der JNF, dass er in keiner Weise gegenüber arabischen Antragstellern diskriminiere.
<G-vec00161-002-s496><comment.abgeben><en> In a comment to the German Embassy JNF stresses that it does not discriminate in any way against Arab applicants.
<G-vec00161-002-s497><comment.abgeben><de> Ein Sprecher der ständigen Vertretung Ungarns bei der EU verweigerte die Stellungnahme und sagte, die Regierung prüfe derzeit noch das Gerichtsurteil.
<G-vec00161-002-s497><comment.abgeben><en> A spokesperson for the Hungarian permanent representation to the EU declined to comment and said the government is still examining the court ruling.
<G-vec00161-002-s498><comment.abgeben><de> Das IFRS Global Office von Deloitte hat gegenüber der IFRS-Stiftung eine Stellungnahme zum vorgeschlagenen Handbuch für den Konsultationsprozess eingereicht, das im Mai 2012 zwecks öffentlicher Stellungnahme herausgegeben wurde.
<G-vec00161-002-s498><comment.abgeben><en> 30 Jul 2010 Deloitte's IFRS Global Office has submitted a letter of comment to the IASB on Discussion paper DP/2010/1 'Extractive Activities'.
<G-vec00161-002-s499><comment.abgeben><de> Es ist wichtig, dass der Käufer die Richtigkeit seiner Reklamation beweist, am besten durch Fotodokumentation, und die Verkäufer zur Stellungnahme fordert.
<G-vec00161-002-s499><comment.abgeben><en> The Buyer has to prove his claim (best with photo documentation) and the Seller is asked to comment the situation.
<G-vec00161-002-s500><comment.abgeben><de> Das Studienprotokoll ist vor Studienbeginn zur Beratung, Stellungnahme, Orientierung und Zustimmung einer Forschungsethik-Kommission vorzulegen.
<G-vec00161-002-s500><comment.abgeben><en> The research protocol must be submitted for consideration, comment, guidance and approval to a research ethics committee before the study begins.
<G-vec00161-002-s501><comment.abgeben><de> Diese Stellungnahme stützt den Vorschlag, eine Ausnahme für nicht tkommerzielle Remix-Videos einzurichten, die nicht gegen das Urheberrecht verstoßen.
<G-vec00161-002-s501><comment.abgeben><en> This comment supports a proposed exemption for noncommercial remix videos that do not infringe copyright.
<G-vec00161-002-s502><comment.abgeben><de> Über Inhalt und Umfang der durchzuführenden Rückrufmaßnahmen werden wir den Lieferanten – soweit möglich und zumutbar – unterrichten und ihm Gelegenheit zur Stellungnahme geben.
<G-vec00161-002-s502><comment.abgeben><en> We will inform the supplier about the content and scope of any recall measures - as far as possible and reasonable - and provide supplier with an opportunity to comment.
<G-vec00161-002-s503><comment.abgeben><de> Wir versuchen doch nicht die Armut aus dem Bild auszugrenzen.“ Die ADB konnte nicht zu einer Stellungnahme gewonnen werden.
<G-vec00161-002-s503><comment.abgeben><en> We are not trying to keep the poor out of the picture," he said. There was no immediate comment from ADB.
<G-vec00161-002-s504><comment.abgeben><de> Eine Sprecherin Kutchers reagierte zunächst nicht auf eine Anfrage nach einer Stellungnahme.
<G-vec00161-002-s504><comment.abgeben><en> A spokeswoman for Kutcher hasn't return messages seeking comment. Comments Michigan's Best
<G-vec00161-002-s505><comment.abgeben><de> Es gab keine sofortige Stellungnahme zu den iranischen Vorwürfen der CIA oder von US-Beamten.
<G-vec00161-002-s505><comment.abgeben><en> There was no immediate comment on the Iranian allegations by the CIA or U.S. officials.
<G-vec00161-002-s506><comment.abgeben><de> Sie haben keine Berechtigung zur Stellungnahme.
<G-vec00161-002-s506><comment.abgeben><en> You do not have permission to comment.
<G-vec00161-002-s507><comment.abgeben><de> Über Umfang und Inhalt der durchzuführenden Maßnahmen werden wir den Lieferanten – soweit möglich und zumutbar – unterrichten und ihm Gelegenheit zur Stellungnahme geben.
<G-vec00161-002-s507><comment.abgeben><en> We will inform the supplier of the content and scope of the recall actions to be applied, where possible and reasonable, and give him the opportunity to comment on this. 9.
<G-vec00161-002-s508><comment.abgeben><de> Monsanto reagierte nicht auf viele Bitten um Stellungnahmen.
<G-vec00161-002-s508><comment.abgeben><en> Monsanto did not respond to multiple requests for comment.
<G-vec00161-002-s509><comment.abgeben><de> Sofern nichts anderes bestimmt ist, sollten interessierte Parteien nach Ablauf der Frist für Stellungnahmen zur vorläufigen Unterrichtung oder zum Informationspapier im vorläufigen Stadium keine neuen Sachinformationen vorlegen.
<G-vec00161-002-s509><comment.abgeben><en> — Unless otherwise specified, interested parties should not submit new factual information after the deadline to comment on the provisional disclosure or the information document at provisional stage.
<G-vec00161-002-s510><comment.abgeben><de> Funktionäre von Oak Tree antworteten nicht auf mehrere persönliche und telefonische Anfragen zu Stellungnahmen.
<G-vec00161-002-s510><comment.abgeben><en> Oak Tree officials did not respond to several requests seeking comment in person and by phone.
<G-vec00161-002-s511><comment.abgeben><de> Das Unternehmen hat auf alle weiteren Herausgabeanordnungen und Stellungnahmen rechtzeitig geantwortet.
<G-vec00161-002-s511><comment.abgeben><en> The Company has responded to all the subsequent production orders and comment letters in a timely manner.
<G-vec00161-002-s512><comment.abgeben><de> Der Board führte die Notwendigkeit an, die Ergebnisse aus den Stellungnahmen dem Standardbeirat vorzulegen und deren Reaktion auf die erhaltenen Eingaben zu verstehen.
<G-vec00161-002-s512><comment.abgeben><en> The Board noted the need to present comment letter feedback to the Advisory Council to understand their reactions to the feedback received.
<G-vec00161-002-s513><comment.abgeben><de> 15.05.2012 Das IFRS Global Office von Deloitte hat beim IFRS Interpretations Committee zwei Stellungnahmen zu (1) der vorläufigen Agendaentscheidung in Bezug auf IAS 1 und IAS 12 – Darstellung von Zahlungen von Steuern, die keine Ertragsteuern sind, und (2) der vorläufigen Agendaentscheidung in Bezug auf IAS 12 – Bilanzierung von Marktwerterhöhungen aufgrund eines neuen Steuerregimes eingereicht.
<G-vec00161-002-s513><comment.abgeben><en> Deloitte's IFRS Global Office has submitted two letter of comment to the IFRS Interpretations Committee on (1) Tentative agenda decision: IAS 1 Presentation of Financial Statements and IAS 12 Income Taxes – Presentation of payments of non-income taxes and (2) Tentative agenda decision: IAS 12 Income Taxes – Accounting for market value uplifts introduced by a new tax regime.
<G-vec00161-002-s514><comment.abgeben><de> Nach Ablauf der Frist für die Stellungnahmen entscheidet sie abschließend über den Antrag und informiert die antragstellende Person schriftlich über das Ergebnis.
<G-vec00161-002-s514><comment.abgeben><en> After the deadline for the comment has expired, a decision can then be made on the application.
<G-vec00161-002-s515><comment.abgeben><de> Allerdings wurde das Fehlen jeglicher formeller Stellungnahmen thematisiert.
<G-vec00161-002-s515><comment.abgeben><en> However, the lack of any formal comment letters was noted.
<G-vec00161-002-s516><comment.abgeben><de> Sie plant die Einsetzung eines europäischen Beirats aus Entscheidungsträgern, Wissenschaftlern und Vertretern der Organisationen der Zivilgesellschaft, der die Aufgabe haben wird, Stellungnahmen zu den Arbeiten verschiedener, unter der Schirmherrschaft der Kommission tätiger Arbeitsgruppen abzugeben.
<G-vec00161-002-s516><comment.abgeben><en> The Commission is considering the establishment of a European Advisory Group that would consist of decision makers, scientists and representatives of civil society organisations and would comment on the work of a number of working groups acting under the aegis of the Commission.
<G-vec00161-002-s517><comment.abgeben><de> Stellungnahmen zur Stichprobenauswahl müssen binnen 3 Tagen nach Bekanntgabe der Entscheidung über die Stichprobe eingehen.
<G-vec00161-002-s517><comment.abgeben><en> Any comment on the sample selection must be received within 3 days of the date of notification of the sample decision.
<G-vec00161-002-s518><comment.abgeben><de> Deloitte-Stellungnahmen zu vorläufigen Agendaentscheidungen 23.02.2011 Das IFRS Global Office von Deloitte hat Stellungnahmen zu zwei vorläufigen Agendaentscheidungen des IFRS Interpretations Committee eingereicht.
<G-vec00161-002-s518><comment.abgeben><en> Deloitte's IFRS Global Office has submitted a letter of comment to the SME Implementation Group on its Third batch of SME Implementation Group questions and answer documents.
<G-vec00161-002-s519><comment.abgeben><de> Der Stab stellte eine Auswertung der zum im Oktober 2011 veröffentlichten Entwurf 'Darlehen der öffentlichen Hand (Vorgeschlagene Änderungen an IFRS 1)' erhaltenen Stellungnahmen vor.
<G-vec00161-002-s519><comment.abgeben><en> 27 Jan 2012 The staff presented an analysis of the comment letters received on the Board's exposure draft 'Government Loans (Proposed amendment to IFRS 1)' published in October 2011.
<G-vec00161-002-s520><comment.abgeben><de> c. Der Staff Manager nimmt alle Erklärungen der Bezirke/Interessengruppen, Erklärungen öffentlicher Stellungnahmen und andere Informationen und stellt diese innerhalb von fünfzig (50) Kalendertagen nach der Initiierung des PDP in einem anfänglichen Bericht zusammen (und veröffentlicht diesen Bericht auf der Website für Stellungnahmen, der Comment Site).
<G-vec00161-002-s520><comment.abgeben><en> c. The Staff Manager will take all Constituency/Stakeholder Group Statements, Public Comment Statements, and other information and compile (and post on the Comment Site) an Initial Report within fifty (50) calendar days after initiation of the PDP.
<G-vec00161-002-s521><comment.abgeben><de> Die Boards erörterten die Rückmeldungen aus den Erkundigungsaktivitäten, den Feldtests aund den Stellungnahmen auf die Vorschläge aus dem Standardentwurf ED/2013/3 'Finanzinstrumente: Erwartete Kreditausfälle' sowie den Rückmeldungen der Adressaten auf die Wertminderungsvorschläge des FASB.
<G-vec00161-002-s521><comment.abgeben><en> 23 Jul 2013 The Board discussed feedback from outreach activities, field work, and comment letters on the proposals in Exposure Draft 'Financial Instruments: Expected Credit Losses' as well as constituents’ feedback on the FASB impairment proposals.
<G-vec00739-002-s025><surrender.abgeben><de> Der „Wert“ des Tauschmittels ging so schnell zurück, daß diejenigen, die etwas zu verkaufen hatten, ihre Ware nicht mehr gegen Geld abgeben wollten.
<G-vec00739-002-s025><surrender.abgeben><en> The value of the currency fell so rapidly that those who had something to sell no longer wished to surrender their wares against money.
<G-vec00739-002-s026><surrender.abgeben><de> Jiang Renzheng wurde bedroht, daß er wieder zurück ins Zwangsarbeitslager gebracht werden würde, wenn er nicht seinen Paß abgeben würde.
<G-vec00739-002-s026><surrender.abgeben><en> Jiang was threatened that he would be taken back to the labour camp if he would not surrender his passport.
<G-vec00739-002-s027><surrender.abgeben><de> Wenn die Einschiffung in Havanna, Kuba erfolgt, werden Sie Ihre Touristenkarte abgeben müssen, sobald das Schiff Santiago de Cuba erreicht.
<G-vec00739-002-s027><surrender.abgeben><en> If you embark in Havana, Cuba, you will need to surrender your tourist card when we stop in Santiago de Cuba.
<G-vec00739-002-s028><surrender.abgeben><de> Gefragt sind neue, horizontale Kulturtechniken der Führung, die Kontrolle abgeben, um Engagement und Eigenverantwortung zu ernten.
<G-vec00739-002-s028><surrender.abgeben><en> What is needed are new, horizontal techniques of leadership that surrender control in order to harvest engagement and personal responsibility.
<G-vec00739-002-s035><surrender.abgeben><de> Die kurzfristige Überlebensfähigkeit des Euros hängt davon ab, wie viel Souveränität die nationalen Regierungen bereit sind abzugeben.
<G-vec00739-002-s035><surrender.abgeben><en> The immediate viability of the euro is directly proportional to the amount of sovereignty national governments are prepared to surrender.
<G-vec00739-002-s036><surrender.abgeben><de> Durch automatisierte Geschäftsprozesse steigern Sie Ihre Produktivität im Unternehmen, aber ohne die Kontrolle über Daten und Prozesse abzugeben.
<G-vec00739-002-s036><surrender.abgeben><en> Thanks to automated business processes, you can increase the productivity of your company without having to surrender control of data and processes.
<G-vec00739-002-s037><surrender.abgeben><de> Die Beamten schlugen diejenigen Personen heftig, die sich weigerten, ihre privaten Gegenstände abzugeben.
<G-vec00739-002-s037><surrender.abgeben><en> Officers severely beat several participants who refused to surrender their private belongings.
<G-vec00942-002-s019><relinquish.abgeben><de> Das Wohlfahrtsamt stellte Ferdinand im Dezember 1936 Zahlungen in Aussicht, sollte er seinen Gewerbeschein als Schneider abgeben.
<G-vec00942-002-s019><relinquish.abgeben><en> In Dec. 1936, the welfare office held out the prospect of payments to Ferdinand, should he relinquish his trade license as a tailor.
<G-vec00942-002-s024><relinquish.abgeben><de> Rechtsanwalt Walter Eßer, während der letzten Jahrzehnte eine der herausragenden Anwaltspersönlichkeiten der Region und darüber hinaus, hat sich mit 66 Jahren entschlossen, die unternehmerische Verantwortung abzugeben.
<G-vec00942-002-s024><relinquish.abgeben><en> Walter Eßer has been one of the most outstanding lawyers in the region and beyond during the last several decades and, now at 66 years old, has decided to relinquish his corporate responsibilities.
<G-vec00942-002-s025><relinquish.abgeben><de> Dies zeigt den bestehenden Unwillen, nicht der „Völker“, und nicht der „Staaten“, sondern ganz spezifisch der Exekutive der Mitgliedstaaten, Kontrolle abzugeben.
<G-vec00942-002-s025><relinquish.abgeben><en> This reflects the ongoing unwillingness not of “the people”, not of “states”, but more specifically of executive branch of governments to relinquish control.
<G-vec00942-002-s026><relinquish.abgeben><de> Beide haben vielmehr auch die Eigenthümlichkeit gemein, daß sie alle anderen Klassen der Gesellschaft sich zu Feinden machen, nicht nur die Ausgebeuteten, sondern auch die Ausbeuter, die so viel von ihrem Raube an den obersten aller Ausbeuter abzugeben haben und die voll Gier nach dessen Schätzen blicken.
<G-vec00942-002-s026><relinquish.abgeben><en> Both have, in common, the faculty of exciting the enmity of all other ranks of society – not only of the exploited classes, but also of the exploiters. Both are compelled to relinquish much of their spoils to the greatest of all exploiters, and both view the treasures of the latter with eager, covetous eye.
<G-vec00942-002-s027><relinquish.abgeben><de> Private Investoren sind äußerst zurückhaltend damit die Kontrolle an öffentliche Stellen abzugeben, da sie befürchten, dass diese politischem Einfluss ausgesetzt sind und möglicherweise nicht nach kaufmännischen Gesichtspunkten investieren.
<G-vec00942-002-s027><relinquish.abgeben><en> Private investors are extremely hesitant to relinquish control to public entities, owing to fears that public bodies can be swayed by political influence and may not invest on commercial terms.
<G-vec00942-002-s059><relinquish.abgeben><de> Er fordert den aktuellen Primärserver auf, das Eigentum der Datenbank abzugeben.
<G-vec00942-002-s059><relinquish.abgeben><en> It then asks the current primary server to relinquish ownership of the database.
<G-vec00942-002-s065><relinquish.abgeben><de> Insbesondere Konzernen falle es schwer, Kontrolle abzugeben.
<G-vec00942-002-s065><relinquish.abgeben><en> Corporations find it particularly difficult to relinquish control.
<G-vec00942-002-s100><relinquish.abgeben><de> Der Mut, der Natur das Ruder zu überlassen und die Kontrolle abzugeben, schöpft sich aus dem tiefen Vertrauen in die Kraft der Natur.
<G-vec00942-002-s100><relinquish.abgeben><en> Having the courage to pass the reigns to Mother Nature and relinquish control derives from the deep-seated trust in her power.
