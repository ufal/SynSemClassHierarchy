<G-vec00899-002-s160><fasten.anknoten><de> Knotet das andere Ende des Dochts an einen Schaschlikspieß und legt den Spieß quer über das Gefäß, sodass der Docht gerade im Gefäß hängt.
<G-vec00899-002-s160><fasten.anknoten><en> Fasten the other end of the candle wick with a piece of shashlik skewer and lay the skewer across the vessel in order to make sure the wick is straight inside the candle.
