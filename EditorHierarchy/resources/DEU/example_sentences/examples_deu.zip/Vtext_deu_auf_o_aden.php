<G-vec00272-001-s114><charge.auföaden><de> Die mobile Ladestation für die Spark ist in der Lage bis zu drei Spark Intelligent Flight Batteries unterwegs aufzuladen.
<G-vec00272-001-s114><charge.auföaden><en> The Spark Portable Charging Station is designed to wirelessly charge up to three Spark Intelligent Flight Batteries on the go.
<G-vec00272-001-s115><charge.auföaden><de> "Die Basis wird ""Starkiller"" genannt, weil sie buchstäblich den Sternen die Energie entzieht, um ihre Kanone aufzuladen."
<G-vec00272-001-s115><charge.auföaden><en> The base is called “Starkiller” because it literally drains the power from stars to charge its cannon.
<G-vec00272-001-s116><charge.auföaden><de> Wenn man allerdings bedenkt, wie selbstverständlich es inzwischen geworden ist, etwa Smartphones über Nacht aufzuladen, ist der Ladezyklus quasi kein Argument mehr gegen eMobility im Nutzfahrzeugbereich.
<G-vec00272-001-s116><charge.auföaden><en> However, if you consider how natural it has become to charge smartphones overnight, for example, the charging cycle is practically no longer an argument to be made against e-mobility in the commercial vehicle sector.
<G-vec00272-001-s117><charge.auföaden><de> Das Power Bank Vidvie mit einer Kapazität von 8000 mAh ist aus hochwertigen Materialien gefertigt, um den Akku Ihres Smartphones schnell aufzuladen, es ist sogar mit einer Schnellladetechnologie ausgestattet.
<G-vec00272-001-s117><charge.auföaden><en> The Power Bank Vidvie with a capacity of 8000 mAh is manufactured with high quality materials to quickly charge the battery of your smartphone, it is, in fact, equipped with a fast charging technology.
<G-vec00272-001-s118><charge.auföaden><de> Ihr eigenes Fahrrad Sie bedeckten Ställe und auch die Batterie aufzuladen, wenn nötig.
<G-vec00272-001-s118><charge.auföaden><en> Your own bike you covered stables and also charge the battery if necessary.
<G-vec00272-001-s119><charge.auföaden><de> Besitzer von Elektroautos sind herzlich eingeladen, in unserem Resort essen zu gehen und in der Zwischenzeit ihr Fahrzeug aufzuladen.
<G-vec00272-001-s119><charge.auföaden><en> Electric car owners are encouraged to stop by our resort and charge their car while dining.
<G-vec00272-001-s120><charge.auföaden><de> Mit einem USB-C-Kabel und genügend Strom, um Ihr Handy schnell und einfach aufzuladen, können Sie sicher sein, dass dieses Autoladegerät mit Ihrem Motorola One kompatibel ist.
<G-vec00272-001-s120><charge.auföaden><en> Featuring a USB-C cable and enough power to charge your phone quickly and easily, you can be certain that this car charger is compatible with your Motorola One.
<G-vec00272-001-s121><charge.auföaden><de> Sie können auch ein Ladekabel an den USB-C-Anschluss anschließen, um Ihr MacBook aufzuladen.
<G-vec00272-001-s121><charge.auföaden><en> You can also connect a charging cable to the USB-C port to charge your MacBook.
<G-vec00272-001-s122><charge.auföaden><de> Mit diesem Qualitätskabel können Sie Ihr Motorola One an Ihren Laptop oder Desktop anschließen, um Ihr Telefon aufzuladen und gleichzeitig Daten auszutauschen / zu synchronisieren.
<G-vec00272-001-s122><charge.auföaden><en> This quality cable allows you to connect your Motorola Moto G6 to your laptop or desktop, in order to charge your phone and exchange / sync data simultaneously.
<G-vec00272-001-s123><charge.auföaden><de> Du solltest die Batterie eventuell über Nacht langsam aufladen, um sie voll aufzuladen, falls sie einige Zeit leer war.
<G-vec00272-001-s123><charge.auföaden><en> You may want to leave the battery slow charging overnight to fully charge it if it has been dead for some time.
<G-vec00272-001-s124><charge.auföaden><de> Sie sollten auch versuchen, auf Preise Ihres Konkurrenten zu sein, einen vorhandenen Photographen ist zu unterschneiden eine Wahl, aber zu vernachlässigen, Ihre Fähigkeiten zu bewerten und genug nicht aufzuladen, um Ihre overheads zu umfassen ist eine andere Angelegenheit völlig.
<G-vec00272-001-s124><charge.auföaden><en> You should also try to be on top of your competitor's prices, to undercut an existing photographer is one choice, but to neglect to value your skills and not charge enough to cover your overheads is another matter entirely.
<G-vec00272-001-s125><charge.auföaden><de> Er konzentrierte sich mit Hilfe seltener Techniken der Energiemodulation, um sich auf das höchste Niveau aufzuladen.
<G-vec00272-001-s125><charge.auföaden><en> He concentrated and used extremely rare techniques of energy modification to charge himself to full power.
<G-vec00272-001-s126><charge.auföaden><de> Also, wenn Sie einen Akkuschrauber wählen, dann, bevor Sie anfangen zu arbeiten, müssen Sie es aufzuladen.
<G-vec00272-001-s126><charge.auföaden><en> So, if you choose a cordless screwdriver, then before you start working, you need to charge it.
<G-vec00272-001-s127><charge.auföaden><de> Bruno Munari dachte bei den tragbaren Kunstwerken an die Möglichkeit, ein Hotelzimmer oder einen anderen anonymen Ort zu individualisieren und mit Kultur aufzuladen.
<G-vec00272-001-s127><charge.auföaden><en> With his portable sculptures, Bruno Munari opened up the possibility to personalize a hotel room or any other anonymous place and thus charge it with culture.
<G-vec00272-001-s128><charge.auföaden><de> So könnten in den Zeltstoff eingearbeitete, gedruckte Solarpanels Energie spenden - für Lampen (möglicherweise auch in gedruckter Form in den Zeltstoff integriert), den Kocher, oder um das Handy aufzuladen.
<G-vec00272-001-s128><charge.auföaden><en> Printed solar panels could be incorporated into the tent fabric and save energy – for lamps (possibly also printed into the tent fabric), the cooker and to charge mobile phones.
<G-vec00272-001-s129><charge.auföaden><de> AC Dynamo -Ladegerät: Winding der Dynamo Kurbel können Handy, MP3, iPod und eingebauter wiederaufladbarer Akku aufzuladen.
<G-vec00272-001-s129><charge.auföaden><en> AC dynamo charger: Winding the dynamo crank can charge mobile phone, MP3, iPod and installed rechargeable battery.
<G-vec00272-001-s130><charge.auföaden><de> Obwohl die meisten Bars werden Sie für größere Teile wie Sandwiches aufzuladen, vielen Tapas in den südlichen Regionen des Landes kommen kostenlos bei der Bestellung ein Getränk.
<G-vec00272-001-s130><charge.auföaden><en> Though most bars will charge you for larger portions such as sandwiches, many tapas in the southern regions of the country come free when ordering a drink.
<G-vec00272-001-s131><charge.auföaden><de> Deshalb ist es besser, die Bemühungen auf die Firma aufzuladen, wo Sie sich entschieden haben, das Leinen zu erwerben.
<G-vec00272-001-s131><charge.auföaden><en> Therefore it is better to charge with efforts firm where you have decided to get a cloth.
<G-vec00272-001-s132><charge.auföaden><de> Mehr Informationen Induktives Laden Induktives Laden bietet eine einfache und bequeme Methode um mobile Geräte aufzuladen.
<G-vec00272-001-s132><charge.auföaden><en> Inductive Charging Wireless charging is proving to be a popular and convenient way to charge mobile devices.
