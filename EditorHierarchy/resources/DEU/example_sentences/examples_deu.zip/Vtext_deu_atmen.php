<G-vec01019-002-s042><breathe.atmen><de> Ich atme jetzt mehr am Instrument.
<G-vec01019-002-s042><breathe.atmen><en> I breathe more at the instrument.
<G-vec01019-002-s043><breathe.atmen><de> Bewahre die Ruhe, atme tief durch und liebe Moritz.
<G-vec01019-002-s043><breathe.atmen><en> Keep calm, breathe deeply and love Moritz.
<G-vec01019-002-s044><breathe.atmen><de> Atme die klare, reine Bergluft ein und genießen die imposante Landschaft rund um Dich herum.
<G-vec01019-002-s044><breathe.atmen><en> Breathe in the clear, pure mountain air and enjoy the impressive landscape all around you.
<G-vec01019-002-s045><breathe.atmen><de> Atme ganz tief und regelmäßig.
<G-vec01019-002-s045><breathe.atmen><en> Breathe deeply and evenly.
<G-vec01019-002-s046><breathe.atmen><de> Ich Atme ein, Ich Atme aus.
<G-vec01019-002-s046><breathe.atmen><en> Just to breathe in, Just to breathe out
<G-vec01019-002-s047><breathe.atmen><de> Wenn Du Dir Deiner Gefühle nicht sicher bist, schliesse deine Augen einfach für einen Moment, atme in dein Herz und dann wirst Du es wissen.
<G-vec01019-002-s047><breathe.atmen><en> If you’re not clear about your feelings, you just close your eyes for a moment, breathe into your heart, and you’ll know.
<G-vec01019-002-s048><breathe.atmen><de> Atme beim Reinigen deiner Zunge durch die Nase, um Würgen zu vermeiden.
<G-vec01019-002-s048><breathe.atmen><en> If you usually breathe through your mouth, breathe through your nose when cleaning your tongue to help avoid gagging.
<G-vec01019-002-s049><breathe.atmen><de> Atme durch deine Nase.
<G-vec01019-002-s049><breathe.atmen><en> Breathe through your nose.
<G-vec01019-002-s050><breathe.atmen><de> Ich lebe, ich bin lebendig und ich atme, also ist Luft überall.
<G-vec01019-002-s050><breathe.atmen><en> I am alive. I breathe, so the air is everywhere.
<G-vec01019-002-s051><breathe.atmen><de> Atme 4 Sekunden lang ein, halte die Luft 4 Sekunden an und atme dann 4 Sekunden aus.
<G-vec01019-002-s051><breathe.atmen><en> Breathe in for 4 seconds, hold for 4 seconds, and then breathe out for 4 seconds.
<G-vec01019-002-s052><breathe.atmen><de> Also atme einfach.
<G-vec01019-002-s052><breathe.atmen><en> So, just breathe.
<G-vec01019-002-s053><breathe.atmen><de> Atme durch die Nase ein und durch den Mund aus.
<G-vec01019-002-s053><breathe.atmen><en> Breathe in through the nose and out through the mouth.
<G-vec01019-002-s054><breathe.atmen><de> Wenn und wie ich sehe, dass ich dabei bin, an einer Emotion teilzunehmen, stoppe ich mich und atme.
<G-vec01019-002-s054><breathe.atmen><en> I commit to stop and breathe when and as I see myself trying to swipe away the hurt.
<G-vec01019-002-s055><breathe.atmen><de> Entspann dich, atme, einen Panda umarmen.“ Dies sollten meine letzten Gedanken sein; ich musste an meinen glücklichsten Moment denken.
<G-vec01019-002-s055><breathe.atmen><en> Relax, breathe, hugging a panda.’ These might be my last thoughts; I needed to think about my happiest moment.
<G-vec01019-002-s056><breathe.atmen><de> Ärger zu überwinden Atme im Rhythmus der Atemkugel um die innere Ruhe schnell wiederherzustellen.
<G-vec01019-002-s056><breathe.atmen><en> Beat anger Breathe in the rhythm of the Breath Ball to quickly return to peace of mind.
<G-vec01019-002-s057><breathe.atmen><de> Es tut nur weh wenn ich lache oder atme.
<G-vec01019-002-s057><breathe.atmen><en> Hurts only when I laugh or breathe.
<G-vec01019-002-s058><breathe.atmen><de> Es ist übertrieben, aber ich atme so leise wie möglich, um keine Aufmerksamkeit auf mich zu lenken.
<G-vec01019-002-s058><breathe.atmen><en> It’s over the top, but I breathe as quietly as possible so as not to attract any attention.
<G-vec01019-002-s059><breathe.atmen><de> Shon kam mit einer Tüte angelaufen und sagte:” Hier, atme hier rein “, während ich weiterhin sagte, daß ich ausraste.
<G-vec01019-002-s059><breathe.atmen><en> Shon came running in with a bag and said “Here, breathe into this!” As I am still freaking saying “OMG OMG… I am freaking out!”
<G-vec01019-002-s060><breathe.atmen><de> Relax im Hängesessel, atme den Duft von Naturkräuteraufgüssen ein oder schaue dem Tanz der Flammen in der Feuerschale zu.
<G-vec01019-002-s060><breathe.atmen><en> Relax in a hanging chair, breathe in the fragrances of natural herb infusions... or just sit and watch the flames as they dance in the brazier.
<G-vec01019-002-s061><breathe.atmen><de> Stelle dich aufrecht hin und atme tief ein und aus.
<G-vec01019-002-s061><breathe.atmen><en> Stand tall and breathe deeply.
<G-vec01019-002-s062><breathe.atmen><de> Atme ein und dann aus, ohne deine Brust zu bewegen.
<G-vec01019-002-s062><breathe.atmen><en> Breathe in and exhale, while holding your chest steady.
<G-vec01019-002-s064><breathe.atmen><de> Atme ein, hebe den rechten Arm und drehe Dich ausatmend nach rechts rüber.
<G-vec01019-002-s064><breathe.atmen><en> Breathe in, lift your right arm and then rotate and lean to the right as your exhale.
<G-vec01019-002-s065><breathe.atmen><de> Atme tief und gleichmäßig ein.
<G-vec01019-002-s065><breathe.atmen><en> Breathe deeply and evenly.
<G-vec01019-002-s066><breathe.atmen><de> Wenn du nachts eine Panikattacke bekommst, geh durch dein Zimmer und atme tief ein und aus.
<G-vec01019-002-s066><breathe.atmen><en> If you panic late at night, pace around the room and breathe in and out deeply.
<G-vec01019-002-s067><breathe.atmen><de> - Atme tief ein und aus.
<G-vec01019-002-s067><breathe.atmen><en> - Breathe in and out deeply.
<G-vec01019-002-s068><breathe.atmen><de> Atme ein, wenn du zur Ausgangsposition zurückkehrst.
<G-vec01019-002-s068><breathe.atmen><en> Breathe in when returning to the start.
<G-vec01019-002-s069><breathe.atmen><de> Halte diese Verbindung und atme tief und ruhig ein.
<G-vec01019-002-s069><breathe.atmen><en> Keep this connection and breathe deeply and calmly.
<G-vec01019-002-s070><breathe.atmen><de> Atme ein und Du vollführst eine chemische Reaktion.
<G-vec01019-002-s070><breathe.atmen><en> Breathe in and you perform a chemical reaction.
<G-vec01019-002-s071><breathe.atmen><de> Atme während des Anspannens durch die Nase ein und während des Entspannens durch den Mund aus, während du jeden Teil deiner Arme nacheinander entspannst.
<G-vec01019-002-s071><breathe.atmen><en> As you relax each part of your arms in succession, remember to breathe in through your nose when tensing and out through your mouth as you relax.
<G-vec01019-002-s072><breathe.atmen><de> Atme Liebe ein und atme Liebe aus.
<G-vec01019-002-s072><breathe.atmen><en> Breathe in love and breathe out love.
<G-vec01019-002-s073><breathe.atmen><de> Spüre und atme die Energie ein, die von den Tausenden Menschen ausgeht, die sich tagtäglich zu den Rhythmen der besten DJs bewegen.
<G-vec01019-002-s073><breathe.atmen><en> Feel and breathe the energy of thousands of people dancing to the music of the world’s best DJs every night.
<G-vec01019-002-s074><breathe.atmen><de> Anstatt Ärger und Bestürztheit einzuatmen, atme Meine Liebe ein.
<G-vec01019-002-s074><breathe.atmen><en> Instead of breathing in anger and dismay, breathe in My love.
<G-vec01019-002-s075><breathe.atmen><de> Mit der Markteinführung des brandneuen XC90 vollführte Volvo dann einen Quantensprung hinsichtlich der Luft, die wir im Fahrzeug atmen.
<G-vec01019-002-s075><breathe.atmen><en> With the release of the all-new XC90 Volvo took a big step forwards regarding the quality of air we can expect to breathe in our cars.
<G-vec01019-002-s076><breathe.atmen><de> Noch heute beherbergt nahezu jede pflanzliche, tierische und menschliche Zelle mit ihren winzigen Energiekraftwerken, den Mitochondrien, die Nachfahren früherer bakterieller Symbionten – ohne Mitochondrien könnten wir nicht atmen.
<G-vec01019-002-s076><breathe.atmen><en> Today, almost all plant, animal and human cells, with their minute energy power plants, the mitochondria, still contain the descendents of earlier bacterial symbionts – without mitochondria, we would not be able to breathe.
<G-vec01019-002-s077><breathe.atmen><de> Sie hat gesagt, daß sie atmen könnte.
<G-vec01019-002-s077><breathe.atmen><en> She said she could breathe.
<G-vec01019-002-s078><breathe.atmen><de> Junge Tropfenschildkröten sind ziemlich schlechte Schwimmer, ich würde eine Wassertiefe von 5 cm (2 Zoll) oder weniger empfehlen, damit sie auf dem Boden stehen können und ohne Schwierigkeiten die Oberfläche zum atmen erreichen können.
<G-vec01019-002-s078><breathe.atmen><en> Hatchling Spotted turtles are fairly poor swimmers, I would suggest a water depth of 2 inches (5 cm) or less to allow them to “stand” on the bottom and reach the surface to breathe without difficulty.
<G-vec01019-002-s079><breathe.atmen><de> Einer der größten Vorteile des Yin Yoga ist, dass Sie Zeit zum Betrachten, Atmen und das Gefühl der körperlichen, energetischen, und mentalen Ebenen deines Seins haben.
<G-vec01019-002-s079><breathe.atmen><en> One of the greatest benefits of Yin yoga is that you are given time to contemplate, breathe, and feel the physical, energetic, and mental layers of your being.
<G-vec01019-002-s080><breathe.atmen><de> Basierend auf den Drehbüchern, beginnen unsere Filme durch ihre ästhetischen Bilder, den taktvollen Einsatz von Musik und den feinfühligen Schnitt zu atmen.
<G-vec01019-002-s080><breathe.atmen><en> Based on the scripts, our films begin to breathe because of aesthetic pictures, the tactful use of music and the sensitive cut.
<G-vec01019-002-s081><breathe.atmen><de> HELCOR ist es möglich ohne Verwendung von Folien oder anderen Hilfsmitteln seine Leder atmen zu lassen.
<G-vec01019-002-s081><breathe.atmen><en> HELCOR enables the leathers to breathe without using foils or other auxiliary means.
<G-vec01019-002-s082><breathe.atmen><de> In der Mitte zwischen den Nieten sind kleine eingefasste Löcher die es deiner Haut ermöglicht zu atmen.
<G-vec01019-002-s082><breathe.atmen><en> All along the bracelet are little holes that allow your skin to breathe.
<G-vec01019-002-s083><breathe.atmen><de> Es muss zugänglich für jedermann sein genau wie die Luft zum atmen.
<G-vec01019-002-s083><breathe.atmen><en> It has to be accessible for everybody just like the air to breathe.
<G-vec01019-002-s084><breathe.atmen><de> Und vielleicht atmen Sie jetzt auf, weil Sie gar nicht so viel Geld ausgeben müssen, wie Sie befürchtet hatten.
<G-vec01019-002-s084><breathe.atmen><en> And perhaps you can now breathe a sigh of relief, because you don’t need to spend as much money as you had feared beforehand.
<G-vec01019-002-s085><breathe.atmen><de> Ich sprang weiter rauf und runter bis ich irgendwann aus dem Loch sprang und in Wasser welche mir nicht über den Kopf ging und wo ich normal atmen konnte.
<G-vec01019-002-s085><breathe.atmen><en> I continued bobbing up and down until I eventually bounced out of the hole and into water which was not above my head and where I could breathe normally.
<G-vec01019-002-s086><breathe.atmen><de> In manchen Delfingruppen bleiben beispielsweise kleine Gruppen von Delfinen an der Seite von verletzten oder kranken Tieren und unterstützen sie, wenn es notwendig ist, sogar dabei, an die Wasseroberfläche zu gelangen, um zu atmen.
<G-vec01019-002-s086><breathe.atmen><en> In some dolphin societies, for example, groups will stay with injured or sick individuals, even physically supporting them to the surface if necessary so that they can breathe.
<G-vec01019-002-s087><breathe.atmen><de> Das bedeutet, dass sich die Muskulatur der Bronchien entspannt und das Atmen leichter fällt.
<G-vec01019-002-s087><breathe.atmen><en> This means that it relaxes the muscles of the bronchial tubes and thus makes it easier to breathe.
<G-vec01019-002-s088><breathe.atmen><de> Mein Herz würde immer noch schlagen, ich könnte immer noch lachen wenn ich wollte, ich würde immer noch atmen – Ich wäre immer noch am Leben und es würde weitergehen.
<G-vec01019-002-s088><breathe.atmen><en> My heart would still beat, I could still smile if I wanted to, I would still breathe – I would still be alive and life would go on.
<G-vec01019-002-s089><breathe.atmen><de> Wenn Sie den Kopf Ihres Babys ruhen, um zu schlafen, möchten Sie leicht atmen, wissend, dass sie sicher sind und in ihrem eigenen Bett klingen.
<G-vec01019-002-s089><breathe.atmen><en> When you rest your baby's head down to sleep you want to breathe easy knowing they are safe and sound in their own bed.
<G-vec01019-002-s090><breathe.atmen><de> Wenn Ihre Nase verstopft ist, zieht sich beim Atmen das Gewebe im Rachenraum zusammen und es bilden sich Luftverwirbelungen, die den Rachenbereich in Vibrationen versetzen und zu Schnarchgeräuschen führen.
<G-vec01019-002-s090><breathe.atmen><en> If your nose is congested, the tissue in the pharynx constricts when you breathe and causes air turbulence to form, this results in the tissues in the throat vibrating and thus snoring.
<G-vec01019-002-s091><breathe.atmen><de> Die Luft, die Sie atmen, ist echt und die umgebende Natur gibt denen, die hierher kommen, um die Gerichte der Farm zu kosten, ein Gefühl des Wohlbefindens.
<G-vec01019-002-s091><breathe.atmen><en> The air you breathe is genuine and the surrounding nature gives a feeling of well-being to those who come here to savour the agritourisms’ dishes.
<G-vec01019-002-s092><breathe.atmen><de> Das Phänomen namens Leben existiert nur solange wir atmen.
<G-vec01019-002-s092><breathe.atmen><en> The fact called life exists as much as we breathe.
<G-vec01019-002-s093><breathe.atmen><de> Ich hustete Blut und fühlte mich als könne ich nicht richtig atmen.
<G-vec01019-002-s093><breathe.atmen><en> I was coughing up blood and feeling like I couldn't breathe right.
<G-vec01019-002-s094><breathe.atmen><de> Mach dir keine Sorgen um mich, mir geht es gut, wenn ich atmen kann.
<G-vec01019-002-s094><breathe.atmen><en> Don't you worry about me I'll be fine if I can breathe
<G-vec01019-002-s095><breathe.atmen><de> So schwer, zu atmen.
<G-vec01019-002-s095><breathe.atmen><en> So hard to breathe
<G-vec01019-002-s096><breathe.atmen><de> Alles was ich tun wollte ist, dass ich atmen möchte.
<G-vec01019-002-s096><breathe.atmen><en> All I want to do is I want to breathe
<G-vec01019-002-s097><breathe.atmen><de> Verbessert Ihre Luftqualität durch Analyse der Luft, die Sie atmen.
<G-vec01019-002-s097><breathe.atmen><en> Improves Your Air Quality By Responding To The Air You Breathe
<G-vec01019-002-s098><breathe.atmen><de> Ich kann nicht atmen.
<G-vec01019-002-s098><breathe.atmen><en> I cannot breathe
<G-vec01019-002-s099><breathe.atmen><de> Und statt zu sterben habe ich zu atmen gelernt.
<G-vec01019-002-s099><breathe.atmen><en> And instead of dying, I've learnt to breathe
<G-vec01019-002-s100><breathe.atmen><de> Diese Qualität gilt es zu erhalten, denn nur in einem Milieu der Leichtigkeit und Luftigkeit kann Kunst atmen.
<G-vec01019-002-s100><breathe.atmen><en> This quality is to be conserved, for art can only breathe in a milieu of lightness of the 21er Haus
<G-vec01019-002-s101><breathe.atmen><de> Vielleicht, wenn ich einschlafe, werde ich nicht richtig, richtig, richtig atmen.
<G-vec01019-002-s101><breathe.atmen><en> Maybe if I fall asleep, I won't breathe right, right, right
<G-vec01019-002-s102><breathe.atmen><de> Tipp: Wir atmen jeden Tag 20.000 Liter Luft ein.
<G-vec01019-002-s102><breathe.atmen><en> Hint: We breathe 20,000 liters of air every day.
<G-vec01019-002-s103><breathe.atmen><de> Wenn Sie vollständig ausgeatmet haben, atmen Sie erst wieder ein, wenn Sie das Bedürfnis dazu verspüren.
<G-vec01019-002-s103><breathe.atmen><en> Once you have fully exhaled, do not breathe again until you feel the need to do so.
<G-vec01019-002-s104><breathe.atmen><de> Sie atmen Materie ein - hauptsächlich Stickstoff und Sauerstoff in der Luft.
<G-vec01019-002-s104><breathe.atmen><en> You breathe matter - primarily nitrogen and oxygen in the air.
<G-vec01019-002-s105><breathe.atmen><de> Patienten sitzen in einer Stahlkammer unter ständiger Beobachtung der Vitalfunktionen (Blutdruck, Herzschlag, Atmung) und atmen über Schläuche Sauerstoff ein, was das Kohlenmonoxid aus dem Blut verdrängt.
<G-vec01019-002-s105><breathe.atmen><en> This involves patients sitting in a steel chamber while all vital functions are constantly monitored (blood pressure, heart rate, breathing) and breathe in oxygen via a hose, which removes the carbon monoxide in the blood.
<G-vec01019-002-s106><breathe.atmen><de> Das Obermaterial schützt, während der Fuß atmen kann und sich frei anfühlt.
<G-vec01019-002-s106><breathe.atmen><en> Engineered mesh on the upper protects while allowing the foot to breathe and flex freely.
<G-vec01019-002-s107><breathe.atmen><de> Wir empfehlen Ihnen, dass Sie die gründlich gereinigten Oberflächen mit qualitativ hochwertigen Mitteln schützen (imprägnieren), damit die Oberfläche atmen kann.
<G-vec01019-002-s107><breathe.atmen><en> Once the surfaces have been thoroughly cleaned, we recommend that you protect them with a quality product that will allow the surface to breathe.
<G-vec01019-002-s108><breathe.atmen><de> Die Membran besteht aus Poren (1,4 Milliarden Poren pro Quadratzentimeter), die 20.000 mal kleiner sind als ein Wassertropfen, aber 700 mal größer als ein Wasserdampfmolekül, sodass kein Wasser eindringen, die Haut aber atmen kann.
<G-vec01019-002-s108><breathe.atmen><en> The membrane is formed by pores (over 9 billion pores per square inch) which are 20,000 times smaller than a drop of water, but 700 times larger than a water vapour molecule preventing water penetration and helping the skin breathe.
<G-vec01019-002-s109><breathe.atmen><de> Es ist ein idyllischer Ort, an dem man die einzigartige Küstenlandschaft genießen und salzige Meeresluft zu atmen kann, ohne auf den Luxus oder zahlreichen Freizeitangebote der „New Golden Mile“ verzichten zu müssen.
<G-vec01019-002-s109><breathe.atmen><en> It is an idyllic place where you can enjoy the unique coastal scenery and breathe salty sea air without having to forgo the luxury or numerous leisure activities of the “New Golden Mile”.
<G-vec01019-002-s110><breathe.atmen><de> Der Gestank in diesen Zellen ist so schlimm, dass man kaum atmen kann.
<G-vec01019-002-s110><breathe.atmen><en> The stench in the small cell is so bad that it is difficult to breathe.
<G-vec01019-002-s111><breathe.atmen><de> Wählen Sie kunststofffreie Binden und Tampons, mit denen Ihre Haut atmen kann, und senken Sie dabei gleichzeitig die Verschmutzung durch Kunststoffe.
<G-vec01019-002-s111><breathe.atmen><en> Choosing plastic free pads and tampons lets intimate skin breathe and cuts out plastic pollution.
<G-vec01019-002-s112><breathe.atmen><de> Da Computer nicht atmen kann, werden Hörer öfters vom Gefühl der Erstickung gestört, denn sie erwarten, dass der Sprecher einatmet, und das passiert nicht.
<G-vec01019-002-s112><breathe.atmen><en> As computers don't breathe, human listeners get disturbed by a suffocating feeling, expecting the speaker to breathe in, which never happens.
<G-vec01019-002-s113><breathe.atmen><de> Die Atmosphäre ist zu dünn, um dort atmen zu können, und hat eine andere Zusammensetzung.
<G-vec01019-002-s113><breathe.atmen><en> The atmosphere is too thin to breathe and has a different composition.
<G-vec01019-002-s114><breathe.atmen><de> Eine hohe Sauerstoffdurchlässigkeit trägt dazu bei, dass die Augen atmen können und gesund bleiben.
<G-vec01019-002-s114><breathe.atmen><en> High oxygen permeability helps the eyes to breathe and keep healthy.
<G-vec01019-002-s115><breathe.atmen><de> SnoreBlock-Schnarchtabletten versorgen die Zellen mit Sauerstoff, sodass Sie ohne Probleme atmen können, während der Körper nicht nach zusätzlichen Sauerstoffquellen suchen muss.
<G-vec01019-002-s115><breathe.atmen><en> SnoreBlock snoring tablets also oxygenate the cells, making you breathe without any problems, while the body does not need to look for additional oxygen resources.
<G-vec01019-002-s116><breathe.atmen><de> Mehr info Diese Halbsohlen aus Leder sind an der Unterseite gepolstert und wurden perforiert, damit der Schuh und Ihr Fuß atmen können.
<G-vec01019-002-s116><breathe.atmen><en> Crafted in leather, these full insoles are padded on the underside and perforated to allow for the shoe and foot to breathe.
<G-vec01019-002-s117><breathe.atmen><de> Ich verwende meist keine Tamponaden, so dass Sie unmittelbar nach der Nasenkorrektur durch die Nase atmen können.
<G-vec01019-002-s117><breathe.atmen><en> I usually do not use packings inside your nose so it will be possible for you to breathe right after surgery.
<G-vec01019-002-s118><breathe.atmen><de> Gib darauf Acht, nicht zu viele Schichten aufzutragen, denn deine Haut muss atmen können.
<G-vec01019-002-s118><breathe.atmen><en> Be careful not to add too many layers – your skin needs to breathe.
<G-vec01019-002-s119><breathe.atmen><de> Atmen Sie beim Biken die klare Bergluft, erfrischen Sie sich in den Gasteiner Thermen und erleben Sie in Ihrem Sommerurlaub in Dorfgastein die alpine Idylle dieses herrlichen Fleckens im Salzburger Land.
<G-vec01019-002-s119><breathe.atmen><en> Breathe in the fresh mountain air while biking, take a refreshing dip in the thermal springs of Gastein and enjoy your summer holiday in idyllic alpine style in Dorfgastein - a lovely part of Salzburg.
<G-vec01019-002-s120><breathe.atmen><de> Nehmen Sie sich Zeit für sich, atmen Sie die frische Bergluft ein und genießen Sie Tage frei von Hektik.
<G-vec01019-002-s120><breathe.atmen><en> Take time for yourself, breathe in the fresh mountain air and enjoy your days off the beaten track.
<G-vec01019-002-s121><breathe.atmen><de> 5)Atmen Sie normal durch das Mundstück ein und aus.
<G-vec01019-002-s121><breathe.atmen><en> 5)Breathe normally (inhale and exhale) through the mouthpiece.
<G-vec01019-002-s122><breathe.atmen><de> Genießen Sie die Ursprünglichkeit und Gastlichkeit, lassen Sie sich leiten auf den Pfaden und Wegen, atmen Sie die Luft unserer Wälder, Weinberge und Ebenen, bestaunen Sie die Flora unserer fischreichen Flüsse und flanieren Sie in unseren jahrhundertealten Straßen...
<G-vec01019-002-s122><breathe.atmen><en> Take to the lanes and trails of our warm-hearted and authentic region, breathe in the air of our forests, vineyards and plains, admire the flora and abundant fish of our rivers, and stroll down our ancient streets.
<G-vec01019-002-s123><breathe.atmen><de> Atmen Sie den Unterschied Die 2000er Serie ist mit 3 intelligenten Voreinstellungen ausgestattet, bei denen Sie zwischen folgenden Modi wählen können: Allgemeiner Modus, Allergie, Bakterien und Viren.
<G-vec01019-002-s123><breathe.atmen><en> Breathe the difference The 2000 Series is engineered with 3 smart presettings that you can choose from: Pollution, Allergen, and Bacteria & Virus modes.
<G-vec01019-002-s124><breathe.atmen><de> Atmen Sie die frische Luft und lauschen Sie den Geräuschen des Waldes.
<G-vec01019-002-s124><breathe.atmen><en> Breathe fresh air and listen to the sounds of the forest.
<G-vec01019-002-s125><breathe.atmen><de> Atmen Sie auf diese Weise im Moment des Beginns von Kämpfen ein, dazwischen können Sie wie gewohnt atmen.
<G-vec01019-002-s125><breathe.atmen><en> Breathe in this way at the moment of onset of fights, in between you can breathe as usual.
<G-vec01019-002-s126><breathe.atmen><de> Genießen Sie den Blick über die Wellen, atmen Sie die salzige Luft und lernen Sie die kulinarischen Köstlichkeiten der Region kennen.
<G-vec01019-002-s126><breathe.atmen><en> Enjoy the view over the waves, breathe in the salty air and get to know the culinary delicacies of the region.
<G-vec01019-002-s127><breathe.atmen><de> Atmen Sie frischen Sauerstoff und spüren Sie, dass auch Ihr Körper ein Naturkörper ist, und somit ein Teil der Natur.
<G-vec01019-002-s127><breathe.atmen><en> Breathe fresh oxygen and feel that your body is a nature-body and thus, a part of nature.
<G-vec01019-002-s128><breathe.atmen><de> Atmen Sie frische Bergluft ein, tanken Sie Kraft und erleben Sie wahre Erholung im einzigartigen Zusammenspiel mit der Natur.
<G-vec01019-002-s128><breathe.atmen><en> Breathe in the fresh mountain air, refuel and experience real relaxation in its unique interplay with nature.
<G-vec01019-002-s129><breathe.atmen><de> Spüren Sie und atmen Sie sich wieder in Ihren Körper.
<G-vec01019-002-s129><breathe.atmen><en> Feel and breathe back into your body.
<G-vec01019-002-s130><breathe.atmen><de> Atmen Sie die besondere Atmosphäre dieses über 500 Jahre alten Kulturortes ein.
<G-vec01019-002-s130><breathe.atmen><en> Breathe in the special atmosphere of this over 500 years old cultural place.
<G-vec01019-002-s131><breathe.atmen><de> Entspannung pur – atmen Sie die Bergluft ein, vergessen Sie den Alltag und lassen Sie sich auf einen Vormittag in der Natur ein.
<G-vec01019-002-s131><breathe.atmen><en> Pure relaxation – breathe the mountain air, forget your everyday life and enjoy a morning in the fresh nature.
<G-vec01019-002-s132><breathe.atmen><de> Atmen Sie die frische Luft, genießen Sie das Panorama der Bergwelt und laufen Sie los.
<G-vec01019-002-s132><breathe.atmen><en> Breathe the fresh air, enjoy the panorama of the mountains and run to your heart’s content!
<G-vec01019-002-s133><breathe.atmen><de> Atmen Sie einfach mal durch und lassen Sie die heimelig-warme Atmosphäre des Backsteinhauses auf sich wirken.
<G-vec01019-002-s133><breathe.atmen><en> Breathe through just and let the cozy-warm atmosphere of the brick house on you.
<G-vec01019-002-s134><breathe.atmen><de> Atmen Sie den Duft von Jasmin ein, lassen Sie sich vom milden Klima und dem Gesang der Vögel wiegen, entspannen Sie sich bei einem Buch oder einem leckeren Aperitif, genießen Sie Momente des Wohlbefindens in unserem Wellnesscenter.
<G-vec01019-002-s134><breathe.atmen><en> Breathe in the scent of jasmine, let yourself be lulled by the mild climate and the singing of birds, relax with a book or a tasty aperitif, enjoy moments of well-being in our wellness center.
<G-vec01019-002-s135><breathe.atmen><de> Atmen Sie die unverfälschte Bergluft von einem der drei Balkone.
<G-vec01019-002-s135><breathe.atmen><en> Breathe the pure mountain air from one of the three balconies.
<G-vec01019-002-s136><breathe.atmen><de> Atmen Sie NICHT in den Inhalator.
<G-vec01019-002-s136><breathe.atmen><en> Do NOT breathe into the inhaler.
<G-vec01019-002-s137><breathe.atmen><de> Atmen Sie auf dem Weg nach oben, und atmen Sie auf dem Weg nach unten.
<G-vec01019-002-s137><breathe.atmen><en> Breathe out on the road, and breathe on the way down.
<G-vec01019-002-s138><breathe.atmen><de> Ganz casual in einem weichen Flanell-Hemd, Zip Hoodie und Dark Denim Jeans atmest Du die klare, kühle Luft und blickst noch einmal hinüber zur Freiheitsstatue, dann wird es Zeit, die Sachen zu packen.
<G-vec01019-002-s138><breathe.atmen><en> Casually dressed in a soft flannel shirt, a zip-up hoodie and dark denim jeans you breathe in the cool clear air and take a last look at the Statue of Liberty, then it's time to pack your things.
<G-vec01019-002-s139><breathe.atmen><de> Obgleich niemand ohne zu atmen überleben kann, ist es möglich, dass du gestresst und übermüdet wirst, weil du nicht richtig atmest.
<G-vec01019-002-s139><breathe.atmen><en> Although no one can survive without breathing, you may be allowing yourself to become stressed out and overly tired by failing to breathe properly.
<G-vec01019-002-s140><breathe.atmen><de> Hier kannst du durchatmen, hier wirst du umsorgt, verwöhnt und gebraucht, hier atmest du Luft von magischen Kräutern und bekommst Beauty-Pflege als Willkommensgruß.
<G-vec01019-002-s140><breathe.atmen><en> This is where you can breathe deeply, where you will be looked after and indulged, where you are needed. You breathe air filled with magical herbs and are greeted with beauty treatments as a welcome.
<G-vec01019-002-s141><breathe.atmen><de> Sei dankbar für die Luft die du atmest, die Lebensmittel die dich ernähren, das ruhige zu Hause in dem du leben darfst, die Sonne die deinen Tag erhellt.
<G-vec01019-002-s141><breathe.atmen><en> {Be thankful for the air you breathe, the food that nourishes you, the quiet home you live in, the sunshine that brightens up your day.
<G-vec01019-002-s142><breathe.atmen><de> Halte die Stirn und deinen Oberkopf leicht unter Wasser, während du atmest.
<G-vec01019-002-s142><breathe.atmen><en> Keep your forehead and the crown of your head slightly submerged while you breathe.
<G-vec01019-002-s143><breathe.atmen><de> So atmest du leichter, läufst schonender und trainierst effizienter.
<G-vec01019-002-s143><breathe.atmen><en> This means you breathe easier, run smoother and train more effectively.
<G-vec01019-002-s144><breathe.atmen><de> Oder auf molekularer Ebene: Die Sauerstoffmoleküle die du atmest wurden schon von ganz anderen Menschen geatmet.
<G-vec01019-002-s144><breathe.atmen><en> Or at a molecular level: the oxygen molecules you breathe have already been breathed by other people.
<G-vec01019-002-s145><breathe.atmen><de> Du atmest tief ein, und du atmest aus der Spitze deiner Lungen leicht aus.
<G-vec01019-002-s145><breathe.atmen><en> You breathe in deeply, and you breathe out lightly from the top of your lungs.
<G-vec01019-002-s147><breathe.atmen><de> Zweite Stufe – mit dem Mundstück, durch das du atmest.
<G-vec01019-002-s147><breathe.atmen><en> Second stage – Mouthpiece you breathe from.
<G-vec01019-002-s148><breathe.atmen><de> Beim "gleichmäßigen Atmen", atmest du mit gleicher Geschwindigkeit ein und aus.
<G-vec01019-002-s148><breathe.atmen><en> "Equal breathing" is where you breathe slowly in and out at an even rate.
<G-vec01019-002-s149><breathe.atmen><de> Wählst Du alkyliertes Benzin, reduziert sich die Verbrennung und Du atmest saubere Luft.
<G-vec01019-002-s149><breathe.atmen><en> However, if you choose alkylated gasoline, the combustion is much smaller and you breathe cleaner air.
<G-vec01019-002-s150><breathe.atmen><de> Wolle atmet, anders als Kunstfaser.
<G-vec01019-002-s150><breathe.atmen><en> Wool breathe, unlike synthetic fiber.
<G-vec01019-002-s151><breathe.atmen><de> Doch wenn er kommt, empfangt ihn mit weit offenem Herzen und atmet tief.
<G-vec01019-002-s151><breathe.atmen><en> Yet when it comes, receive it with an open heart and breathe deeply.
<G-vec01019-002-s152><breathe.atmen><de> Heisse Füße entstehen, wenn die Hitze im Schuh gestaut wird, was bei unbeweglich Schuhen und schlechtem Schuhmaterial, das nicht atmet, auftreten kann.
<G-vec01019-002-s152><breathe.atmen><en> Hot feet arise when heat accumulates within the shoe, which can happen with immobile shoes of poor material that does not breathe.
<G-vec01019-002-s153><breathe.atmen><de> Die Campagnolo Produktionsstätte ist ein Ort, an dem man den Duft der Arbeit atmet, wo die Erfahrung jedes einzelnen Arbeitnehmers noch viel zählt, wo Tradition und Wissen noch weitergegeben werden.
<G-vec01019-002-s153><breathe.atmen><en> The Campagnolo factory is somewhere you breathe work, where the experience of each individual worker still counts for so much, where tradition and knowhow are still handed down.
<G-vec01019-002-s154><breathe.atmen><de> Vertrauen Sie darauf, dass Ihr Körper auch beim Joggen automatisch richtig und genug atmet.
<G-vec01019-002-s154><breathe.atmen><en> Trust that your body will automatically breathe correctly and adequately while you're jogging.
<G-vec01019-002-s155><breathe.atmen><de> Darum sagen wir euch, um zu verstehen wie ihr mit ihr arbeiten könnt, entspannt euch, atmet, seid geduldig und eicht euch langsam auf die neue Energie ein, die nicht ganz so stark gegendrückt.
<G-vec01019-002-s155><breathe.atmen><en> So we say to you, relax, breathe, be patient, and recalibrate slowly to a new energy that doesn't push back quite as hard so you'll know how to operate within it.
<G-vec01019-002-s156><breathe.atmen><de> Atmet in diesem Bewusstsein euren irdischen Geist hinaus in den Kosmos und den göttlichen Geist hinein in den Körper.
<G-vec01019-002-s156><breathe.atmen><en> In this consciousness breathe your earthly spirit out into the cosmos and the divine spirit into the body.
<G-vec01019-002-s157><breathe.atmen><de> Atmet bewusst mitten in extremen Umständen.
<G-vec01019-002-s157><breathe.atmen><en> Breathe consciously in the midst of extreme circumstances.
<G-vec01019-002-s158><breathe.atmen><de> Man wacht auf mit der Sonne, atmet pure und frischeste Berg- und Waldluft, schmeißt den Kocher an und brüht erstmal einen leckern Kaffee.
<G-vec01019-002-s158><breathe.atmen><en> You wake up with the sun, breathe pure and fresh mountain and forest air, start the cooker and brew a delicious coffee.
<G-vec01019-002-s159><breathe.atmen><de> Wenn ihr ein Gefühl innerer Fülle entwickeln könnt, dadurch wie ihr atmet, dann bleibt der Geist gesättigt, gleichgültig in welcher Situation ihr euch auch befindet.
<G-vec01019-002-s159><breathe.atmen><en> When you can develop a sense of inner fullness simply by the way you breathe, the mind can stay nourished no matter what the situation.
<G-vec01019-002-s160><breathe.atmen><de> Sie ist die Luft, die sie für die Entwicklung einer politischen Bewegung atmet.
<G-vec01019-002-s160><breathe.atmen><en> It is the air they breathe for the development of a political movement.
<G-vec01019-002-s161><breathe.atmen><de> Atmet die frische Bergluft ein und geniesst einfach nur die Natur, von der ihr umgeben seid, während ihr hier seid.
<G-vec01019-002-s161><breathe.atmen><en> Breathe in the fresh mountain air and just simply enjoy the nature you're surrounded by while you're here.
<G-vec01019-002-s162><breathe.atmen><de> Ein Mensch der Schmerzen hat, atmet flach und ist nicht gerade gut gelaunt und entspannt.
<G-vec01019-002-s162><breathe.atmen><en> A human in pain will breathe shallow, he is in a bad mood and tensions aggravate.
<G-vec01019-002-s163><breathe.atmen><de> Der wasserdichte Stoff muss so beschaffen sein, dass Feuchtigkeit beim Verdunsten durchgelassen wird oder 'atmet'; andernfalls kann unser Schweiß nicht verdunsten, was dazu führt, dass wir überhitzen und nass vom Kondenswasser werden.
<G-vec01019-002-s163><breathe.atmen><en> The waterproof fabric must allow moisture vapour to pass through it, or 'breathe'; otherwise our sweat cannot evaporate, causing us to overheat and get wet from condensation.
<G-vec01019-002-s164><breathe.atmen><de> Mit dem Propheten Jesaja können wir heute sagen: Das Volk, das mitten im Smog wandelt, atmet, lebt, es sieht ein helles Licht, spürt einen Hauch frischer Luft.
<G-vec01019-002-s164><breathe.atmen><en> Together with the prophet Isaiah, we can say: The people who walk, breathe and live in the midst of smog, have seen a great light, have experienced a breath of fresh air.
<G-vec01019-002-s165><breathe.atmen><de> Bei den mexikanischen Revillagigedo-Inseln bringt ein weiblicher Buckelwal seinem Kalb bei, wie man atmet und seinen Auftrieb kontrolliert.
<G-vec01019-002-s165><breathe.atmen><en> In Mexico's Revillagigedo Islands, a humpback whale mother teachers her calf how to breathe and control its buoyancy.
<G-vec01019-002-s166><breathe.atmen><de> Ein Komfortappartement geeignet für anspruchsvolle Klienten atmet Geschichte und Luxus.
<G-vec01019-002-s166><breathe.atmen><en> A luxurious suite ideal for demanding clients where you can breathe history and luxury.
<G-vec01019-002-s167><breathe.atmen><de> Nasaler Stau kann durch allergische Rhinitis häufig verursacht werden und macht es schwierig, damit das Kind, besonders während der Nacht atmet, als sie schlafen.
<G-vec01019-002-s167><breathe.atmen><en> Nasal congestion can often be caused by allergic rhinitis and makes it difficult for the child to breathe, particularly during the night when they are sleeping.
<G-vec01019-002-s168><breathe.atmen><de> Sie will nicht, dass er Atmet.
<G-vec01019-002-s168><breathe.atmen><en> She doesn?t want him to breathe anymore.
<G-vec01019-002-s356><breathe.atmen><de> Ob familiengerechte 3-Zimmer-Wohnungen mit Terrasse oder großzügige 4-Zimmer-Eigentumswohnungen mit privatem Garten, die aktuellen Neubau-Immobilienprojekte im Rhein Main Gebiet bieten allen Familienmitgliedern viel Luft zum Atmen und attraktiven Wohnkomfort im Grünen.
<G-vec01019-002-s356><breathe.atmen><en> Current newly constructed properties in the Rhine-Main area offer all family members room to breathe and attractive living space within nature, regardless if you are looking for a family-friendly three-bedroom apartment with terrace or spacious four-bedroom condominium with private garden. read more ›
<G-vec01019-002-s357><breathe.atmen><de> Weil Lea etwas lernen muss und ihre Freizeit somit nicht richtig genießen kann, darf Richie das auch nicht.Er muss sich gerade auf das Bett legen und ihr mit dem Gesicht als Sitzkissen dienen.Mit ihrer gelben Hot Pants setzt sich auf sein Gesicht und schlägt auf seinem Oberkörper ihr Buch auf.So muss er die ganze Zeit über liegen bleiben, während sie auf ihm oben ihre Unterlagen durchgeht.Er darf keine Luft atmen, sich nicht bewegen und ihr als Ablage für ihr Buch dienen.Dann steht Lea auf und und setzt sich umgedreht auf ihm, weil sie gelichzeitig auch noch Fernsehen will.Die Füße auf dem Bett stehend, verlagert sie ihr ganzes Gewicht auf ihren Arsch, den sie Richie aufs Gesicht drückt.Dann überschlägt sie auch noch kess ihre Beine und sitzt auf seinem Gesicht, wie auf einem Stuhl.
<G-vec01019-002-s357><breathe.atmen><en> Because Lea must learn something and her leisure time can not enjoy therefore correctly, Richie may not this either; He must put himself just on the bed and serve her as a floor cushion with the face; Sets itself yellow Hot Pants with hers on its face and her book hits its upper part of the body; So it must about be left all the time while it is going through its documents on it above; It may not breathe air, not move and serve it as a filing for her book; Then Lea gets up and and sits down turned over on him because she wants television gel self early, too; She the feet on the bed stationarily, shifted pushes her whole weight on her arse, the Richie on the face; She then estimates saucily her legs, too and sits on his face like on a chair.
<G-vec01019-002-s358><breathe.atmen><de> Robben müssen auch Luft atmen, deshalb sind Ölteppiche gefährlich für tauchende Tiere.
<G-vec01019-002-s358><breathe.atmen><en> Seals must also breathe air, because of this oil patches are dangerous for diving animals.
<G-vec01019-002-s359><breathe.atmen><de> Benutze die aufsteigende Luft aus den Röhren um zu Atmen.
<G-vec01019-002-s359><breathe.atmen><en> Use the bubbling pipes to breathe.
<G-vec01019-002-s364><breathe.atmen><de> Im Winter in der Wohnung manchmal einfach nicht mehr atmen.
<G-vec01019-002-s364><breathe.atmen><en> In winter the apartment sometimes just to breathe.
<G-vec01019-002-s365><breathe.atmen><de> Sie verbiegt dir langsam den Rücken, bis du nicht mehr atmen kannst.
<G-vec01019-002-s365><breathe.atmen><en> It slowly bends your back until you can't breathe.
<G-vec01019-002-s366><breathe.atmen><de> Ich sitze auf seinem Gesicht und drücke es tief in meinen Arsch, so dass er nicht mehr atmen kann.
<G-vec01019-002-s366><breathe.atmen><en> I sits on his face and pressed it deep into my ass that he can not breathe.
<G-vec01019-002-s367><breathe.atmen><de> Ich verstand nicht was mit mir passierte, aber plötzlich war alles blockiert, ich konnte nicht mehr atmen, und ein großes Rasseln kam aus meinem Hals anstelle von Luft, wie man normalerweise ausatmet.
<G-vec01019-002-s367><breathe.atmen><en> I didn't understand what was happening to me, but suddenly everything was blocked, I couldn't breathe, and a great rattle came out of my throat instead of air, the way one would normally exhale.
<G-vec01019-002-s395><breathe.atmen><de> Wir bringen die Luft zum atmen, wir bringen voran und dabei wehen wir dem einen oder anderen auch mal ins Gesicht.
<G-vec01019-002-s395><breathe.atmen><en> We let the air breathe, we move forward and from time to time we will blow into someone’s face.
<G-vec01019-002-s396><breathe.atmen><de> Während dieser Zeit drückte mir ein Polizist die Kehle zu und nahm mir die Luft zum atmen.
<G-vec01019-002-s396><breathe.atmen><en> During this time a policeman throttled me and the air took away from me to this breathe.
<G-vec01019-002-s397><breathe.atmen><de> Herrin Jane prügelt es schon aus ihm heraus und nimmt ihm die Luft zum atmen.
<G-vec01019-002-s397><breathe.atmen><en> Mistress Jane beats it out of him and takes the air from him so he can't breathe.
<G-vec01019-002-s398><breathe.atmen><de> Dieser Grundstoff des Lebens ist für uns nicht weniger wichtig als die Luft zum Atmen - und doch nicht selten stark verunreinigt.
<G-vec01019-002-s398><breathe.atmen><en> This basic element of life has no lesser importance to us than the air we breathe – and yet it is often heavily polluted.
<G-vec01019-002-s399><breathe.atmen><de> Luft zum Atmen Eine weitere innovative neue Funktion für saubere Innenluft in Volvo Fahrzeugen ist die ferngesteuerte Innenraumbelüftung.
<G-vec01019-002-s399><breathe.atmen><en> The air that we breathe Another new innovation in Volvo Cars’ mission to provide a clean in-car environment is remote cabin ventilation.
<G-vec01019-002-s042><breathe_out.atmen><de> Ich atme jetzt mehr am Instrument.
<G-vec01019-002-s042><breathe_out.atmen><en> I breathe more at the instrument.
<G-vec01019-002-s043><breathe_out.atmen><de> Bewahre die Ruhe, atme tief durch und liebe Moritz.
<G-vec01019-002-s043><breathe_out.atmen><en> Keep calm, breathe deeply and love Moritz.
<G-vec01019-002-s044><breathe_out.atmen><de> Atme die klare, reine Bergluft ein und genießen die imposante Landschaft rund um Dich herum.
<G-vec01019-002-s044><breathe_out.atmen><en> Breathe in the clear, pure mountain air and enjoy the impressive landscape all around you.
<G-vec01019-002-s045><breathe_out.atmen><de> Atme ganz tief und regelmäßig.
<G-vec01019-002-s045><breathe_out.atmen><en> Breathe deeply and evenly.
<G-vec01019-002-s046><breathe_out.atmen><de> Ich Atme ein, Ich Atme aus.
<G-vec01019-002-s046><breathe_out.atmen><en> Just to breathe in, Just to breathe out
<G-vec01019-002-s047><breathe_out.atmen><de> Wenn Du Dir Deiner Gefühle nicht sicher bist, schliesse deine Augen einfach für einen Moment, atme in dein Herz und dann wirst Du es wissen.
<G-vec01019-002-s047><breathe_out.atmen><en> If you’re not clear about your feelings, you just close your eyes for a moment, breathe into your heart, and you’ll know.
<G-vec01019-002-s048><breathe_out.atmen><de> Atme beim Reinigen deiner Zunge durch die Nase, um Würgen zu vermeiden.
<G-vec01019-002-s048><breathe_out.atmen><en> If you usually breathe through your mouth, breathe through your nose when cleaning your tongue to help avoid gagging.
<G-vec01019-002-s049><breathe_out.atmen><de> Atme durch deine Nase.
<G-vec01019-002-s049><breathe_out.atmen><en> Breathe through your nose.
<G-vec01019-002-s050><breathe_out.atmen><de> Ich lebe, ich bin lebendig und ich atme, also ist Luft überall.
<G-vec01019-002-s050><breathe_out.atmen><en> I am alive. I breathe, so the air is everywhere.
<G-vec01019-002-s051><breathe_out.atmen><de> Atme 4 Sekunden lang ein, halte die Luft 4 Sekunden an und atme dann 4 Sekunden aus.
<G-vec01019-002-s051><breathe_out.atmen><en> Breathe in for 4 seconds, hold for 4 seconds, and then breathe out for 4 seconds.
<G-vec01019-002-s052><breathe_out.atmen><de> Also atme einfach.
<G-vec01019-002-s052><breathe_out.atmen><en> So, just breathe.
<G-vec01019-002-s053><breathe_out.atmen><de> Atme durch die Nase ein und durch den Mund aus.
<G-vec01019-002-s053><breathe_out.atmen><en> Breathe in through the nose and out through the mouth.
<G-vec01019-002-s054><breathe_out.atmen><de> Wenn und wie ich sehe, dass ich dabei bin, an einer Emotion teilzunehmen, stoppe ich mich und atme.
<G-vec01019-002-s054><breathe_out.atmen><en> I commit to stop and breathe when and as I see myself trying to swipe away the hurt.
<G-vec01019-002-s055><breathe_out.atmen><de> Entspann dich, atme, einen Panda umarmen.“ Dies sollten meine letzten Gedanken sein; ich musste an meinen glücklichsten Moment denken.
<G-vec01019-002-s055><breathe_out.atmen><en> Relax, breathe, hugging a panda.’ These might be my last thoughts; I needed to think about my happiest moment.
<G-vec01019-002-s056><breathe_out.atmen><de> Ärger zu überwinden Atme im Rhythmus der Atemkugel um die innere Ruhe schnell wiederherzustellen.
<G-vec01019-002-s056><breathe_out.atmen><en> Beat anger Breathe in the rhythm of the Breath Ball to quickly return to peace of mind.
<G-vec01019-002-s057><breathe_out.atmen><de> Es tut nur weh wenn ich lache oder atme.
<G-vec01019-002-s057><breathe_out.atmen><en> Hurts only when I laugh or breathe.
<G-vec01019-002-s058><breathe_out.atmen><de> Es ist übertrieben, aber ich atme so leise wie möglich, um keine Aufmerksamkeit auf mich zu lenken.
<G-vec01019-002-s058><breathe_out.atmen><en> It’s over the top, but I breathe as quietly as possible so as not to attract any attention.
<G-vec01019-002-s059><breathe_out.atmen><de> Shon kam mit einer Tüte angelaufen und sagte:” Hier, atme hier rein “, während ich weiterhin sagte, daß ich ausraste.
<G-vec01019-002-s059><breathe_out.atmen><en> Shon came running in with a bag and said “Here, breathe into this!” As I am still freaking saying “OMG OMG… I am freaking out!”
<G-vec01019-002-s060><breathe_out.atmen><de> Relax im Hängesessel, atme den Duft von Naturkräuteraufgüssen ein oder schaue dem Tanz der Flammen in der Feuerschale zu.
<G-vec01019-002-s060><breathe_out.atmen><en> Relax in a hanging chair, breathe in the fragrances of natural herb infusions... or just sit and watch the flames as they dance in the brazier.
<G-vec01019-002-s061><breathe_out.atmen><de> Stelle dich aufrecht hin und atme tief ein und aus.
<G-vec01019-002-s061><breathe_out.atmen><en> Stand tall and breathe deeply.
<G-vec01019-002-s062><breathe_out.atmen><de> Atme ein und dann aus, ohne deine Brust zu bewegen.
<G-vec01019-002-s062><breathe_out.atmen><en> Breathe in and exhale, while holding your chest steady.
<G-vec01019-002-s064><breathe_out.atmen><de> Atme ein, hebe den rechten Arm und drehe Dich ausatmend nach rechts rüber.
<G-vec01019-002-s064><breathe_out.atmen><en> Breathe in, lift your right arm and then rotate and lean to the right as your exhale.
<G-vec01019-002-s065><breathe_out.atmen><de> Atme tief und gleichmäßig ein.
<G-vec01019-002-s065><breathe_out.atmen><en> Breathe deeply and evenly.
<G-vec01019-002-s066><breathe_out.atmen><de> Wenn du nachts eine Panikattacke bekommst, geh durch dein Zimmer und atme tief ein und aus.
<G-vec01019-002-s066><breathe_out.atmen><en> If you panic late at night, pace around the room and breathe in and out deeply.
<G-vec01019-002-s067><breathe_out.atmen><de> - Atme tief ein und aus.
<G-vec01019-002-s067><breathe_out.atmen><en> - Breathe in and out deeply.
<G-vec01019-002-s068><breathe_out.atmen><de> Atme ein, wenn du zur Ausgangsposition zurückkehrst.
<G-vec01019-002-s068><breathe_out.atmen><en> Breathe in when returning to the start.
<G-vec01019-002-s069><breathe_out.atmen><de> Halte diese Verbindung und atme tief und ruhig ein.
<G-vec01019-002-s069><breathe_out.atmen><en> Keep this connection and breathe deeply and calmly.
<G-vec01019-002-s070><breathe_out.atmen><de> Atme ein und Du vollführst eine chemische Reaktion.
<G-vec01019-002-s070><breathe_out.atmen><en> Breathe in and you perform a chemical reaction.
<G-vec01019-002-s071><breathe_out.atmen><de> Atme während des Anspannens durch die Nase ein und während des Entspannens durch den Mund aus, während du jeden Teil deiner Arme nacheinander entspannst.
<G-vec01019-002-s071><breathe_out.atmen><en> As you relax each part of your arms in succession, remember to breathe in through your nose when tensing and out through your mouth as you relax.
<G-vec01019-002-s072><breathe_out.atmen><de> Atme Liebe ein und atme Liebe aus.
<G-vec01019-002-s072><breathe_out.atmen><en> Breathe in love and breathe out love.
<G-vec01019-002-s073><breathe_out.atmen><de> Spüre und atme die Energie ein, die von den Tausenden Menschen ausgeht, die sich tagtäglich zu den Rhythmen der besten DJs bewegen.
<G-vec01019-002-s073><breathe_out.atmen><en> Feel and breathe the energy of thousands of people dancing to the music of the world’s best DJs every night.
<G-vec01019-002-s074><breathe_out.atmen><de> Anstatt Ärger und Bestürztheit einzuatmen, atme Meine Liebe ein.
<G-vec01019-002-s074><breathe_out.atmen><en> Instead of breathing in anger and dismay, breathe in My love.
<G-vec01019-002-s075><breathe_out.atmen><de> Mit der Markteinführung des brandneuen XC90 vollführte Volvo dann einen Quantensprung hinsichtlich der Luft, die wir im Fahrzeug atmen.
<G-vec01019-002-s075><breathe_out.atmen><en> With the release of the all-new XC90 Volvo took a big step forwards regarding the quality of air we can expect to breathe in our cars.
<G-vec01019-002-s076><breathe_out.atmen><de> Noch heute beherbergt nahezu jede pflanzliche, tierische und menschliche Zelle mit ihren winzigen Energiekraftwerken, den Mitochondrien, die Nachfahren früherer bakterieller Symbionten – ohne Mitochondrien könnten wir nicht atmen.
<G-vec01019-002-s076><breathe_out.atmen><en> Today, almost all plant, animal and human cells, with their minute energy power plants, the mitochondria, still contain the descendents of earlier bacterial symbionts – without mitochondria, we would not be able to breathe.
<G-vec01019-002-s077><breathe_out.atmen><de> Sie hat gesagt, daß sie atmen könnte.
<G-vec01019-002-s077><breathe_out.atmen><en> She said she could breathe.
<G-vec01019-002-s078><breathe_out.atmen><de> Junge Tropfenschildkröten sind ziemlich schlechte Schwimmer, ich würde eine Wassertiefe von 5 cm (2 Zoll) oder weniger empfehlen, damit sie auf dem Boden stehen können und ohne Schwierigkeiten die Oberfläche zum atmen erreichen können.
<G-vec01019-002-s078><breathe_out.atmen><en> Hatchling Spotted turtles are fairly poor swimmers, I would suggest a water depth of 2 inches (5 cm) or less to allow them to “stand” on the bottom and reach the surface to breathe without difficulty.
<G-vec01019-002-s079><breathe_out.atmen><de> Einer der größten Vorteile des Yin Yoga ist, dass Sie Zeit zum Betrachten, Atmen und das Gefühl der körperlichen, energetischen, und mentalen Ebenen deines Seins haben.
<G-vec01019-002-s079><breathe_out.atmen><en> One of the greatest benefits of Yin yoga is that you are given time to contemplate, breathe, and feel the physical, energetic, and mental layers of your being.
<G-vec01019-002-s080><breathe_out.atmen><de> Basierend auf den Drehbüchern, beginnen unsere Filme durch ihre ästhetischen Bilder, den taktvollen Einsatz von Musik und den feinfühligen Schnitt zu atmen.
<G-vec01019-002-s080><breathe_out.atmen><en> Based on the scripts, our films begin to breathe because of aesthetic pictures, the tactful use of music and the sensitive cut.
<G-vec01019-002-s081><breathe_out.atmen><de> HELCOR ist es möglich ohne Verwendung von Folien oder anderen Hilfsmitteln seine Leder atmen zu lassen.
<G-vec01019-002-s081><breathe_out.atmen><en> HELCOR enables the leathers to breathe without using foils or other auxiliary means.
<G-vec01019-002-s082><breathe_out.atmen><de> In der Mitte zwischen den Nieten sind kleine eingefasste Löcher die es deiner Haut ermöglicht zu atmen.
<G-vec01019-002-s082><breathe_out.atmen><en> All along the bracelet are little holes that allow your skin to breathe.
<G-vec01019-002-s083><breathe_out.atmen><de> Es muss zugänglich für jedermann sein genau wie die Luft zum atmen.
<G-vec01019-002-s083><breathe_out.atmen><en> It has to be accessible for everybody just like the air to breathe.
<G-vec01019-002-s084><breathe_out.atmen><de> Und vielleicht atmen Sie jetzt auf, weil Sie gar nicht so viel Geld ausgeben müssen, wie Sie befürchtet hatten.
<G-vec01019-002-s084><breathe_out.atmen><en> And perhaps you can now breathe a sigh of relief, because you don’t need to spend as much money as you had feared beforehand.
<G-vec01019-002-s085><breathe_out.atmen><de> Ich sprang weiter rauf und runter bis ich irgendwann aus dem Loch sprang und in Wasser welche mir nicht über den Kopf ging und wo ich normal atmen konnte.
<G-vec01019-002-s085><breathe_out.atmen><en> I continued bobbing up and down until I eventually bounced out of the hole and into water which was not above my head and where I could breathe normally.
<G-vec01019-002-s086><breathe_out.atmen><de> In manchen Delfingruppen bleiben beispielsweise kleine Gruppen von Delfinen an der Seite von verletzten oder kranken Tieren und unterstützen sie, wenn es notwendig ist, sogar dabei, an die Wasseroberfläche zu gelangen, um zu atmen.
<G-vec01019-002-s086><breathe_out.atmen><en> In some dolphin societies, for example, groups will stay with injured or sick individuals, even physically supporting them to the surface if necessary so that they can breathe.
<G-vec01019-002-s087><breathe_out.atmen><de> Das bedeutet, dass sich die Muskulatur der Bronchien entspannt und das Atmen leichter fällt.
<G-vec01019-002-s087><breathe_out.atmen><en> This means that it relaxes the muscles of the bronchial tubes and thus makes it easier to breathe.
<G-vec01019-002-s088><breathe_out.atmen><de> Mein Herz würde immer noch schlagen, ich könnte immer noch lachen wenn ich wollte, ich würde immer noch atmen – Ich wäre immer noch am Leben und es würde weitergehen.
<G-vec01019-002-s088><breathe_out.atmen><en> My heart would still beat, I could still smile if I wanted to, I would still breathe – I would still be alive and life would go on.
<G-vec01019-002-s089><breathe_out.atmen><de> Wenn Sie den Kopf Ihres Babys ruhen, um zu schlafen, möchten Sie leicht atmen, wissend, dass sie sicher sind und in ihrem eigenen Bett klingen.
<G-vec01019-002-s089><breathe_out.atmen><en> When you rest your baby's head down to sleep you want to breathe easy knowing they are safe and sound in their own bed.
<G-vec01019-002-s090><breathe_out.atmen><de> Wenn Ihre Nase verstopft ist, zieht sich beim Atmen das Gewebe im Rachenraum zusammen und es bilden sich Luftverwirbelungen, die den Rachenbereich in Vibrationen versetzen und zu Schnarchgeräuschen führen.
<G-vec01019-002-s090><breathe_out.atmen><en> If your nose is congested, the tissue in the pharynx constricts when you breathe and causes air turbulence to form, this results in the tissues in the throat vibrating and thus snoring.
<G-vec01019-002-s091><breathe_out.atmen><de> Die Luft, die Sie atmen, ist echt und die umgebende Natur gibt denen, die hierher kommen, um die Gerichte der Farm zu kosten, ein Gefühl des Wohlbefindens.
<G-vec01019-002-s091><breathe_out.atmen><en> The air you breathe is genuine and the surrounding nature gives a feeling of well-being to those who come here to savour the agritourisms’ dishes.
<G-vec01019-002-s092><breathe_out.atmen><de> Das Phänomen namens Leben existiert nur solange wir atmen.
<G-vec01019-002-s092><breathe_out.atmen><en> The fact called life exists as much as we breathe.
<G-vec01019-002-s093><breathe_out.atmen><de> Ich hustete Blut und fühlte mich als könne ich nicht richtig atmen.
<G-vec01019-002-s093><breathe_out.atmen><en> I was coughing up blood and feeling like I couldn't breathe right.
<G-vec01019-002-s094><breathe_out.atmen><de> Mach dir keine Sorgen um mich, mir geht es gut, wenn ich atmen kann.
<G-vec01019-002-s094><breathe_out.atmen><en> Don't you worry about me I'll be fine if I can breathe
<G-vec01019-002-s095><breathe_out.atmen><de> So schwer, zu atmen.
<G-vec01019-002-s095><breathe_out.atmen><en> So hard to breathe
<G-vec01019-002-s096><breathe_out.atmen><de> Alles was ich tun wollte ist, dass ich atmen möchte.
<G-vec01019-002-s096><breathe_out.atmen><en> All I want to do is I want to breathe
<G-vec01019-002-s097><breathe_out.atmen><de> Verbessert Ihre Luftqualität durch Analyse der Luft, die Sie atmen.
<G-vec01019-002-s097><breathe_out.atmen><en> Improves Your Air Quality By Responding To The Air You Breathe
<G-vec01019-002-s098><breathe_out.atmen><de> Ich kann nicht atmen.
<G-vec01019-002-s098><breathe_out.atmen><en> I cannot breathe
<G-vec01019-002-s099><breathe_out.atmen><de> Und statt zu sterben habe ich zu atmen gelernt.
<G-vec01019-002-s099><breathe_out.atmen><en> And instead of dying, I've learnt to breathe
<G-vec01019-002-s100><breathe_out.atmen><de> Diese Qualität gilt es zu erhalten, denn nur in einem Milieu der Leichtigkeit und Luftigkeit kann Kunst atmen.
<G-vec01019-002-s100><breathe_out.atmen><en> This quality is to be conserved, for art can only breathe in a milieu of lightness of the 21er Haus
<G-vec01019-002-s101><breathe_out.atmen><de> Vielleicht, wenn ich einschlafe, werde ich nicht richtig, richtig, richtig atmen.
<G-vec01019-002-s101><breathe_out.atmen><en> Maybe if I fall asleep, I won't breathe right, right, right
<G-vec01019-002-s102><breathe_out.atmen><de> Tipp: Wir atmen jeden Tag 20.000 Liter Luft ein.
<G-vec01019-002-s102><breathe_out.atmen><en> Hint: We breathe 20,000 liters of air every day.
<G-vec01019-002-s103><breathe_out.atmen><de> Wenn Sie vollständig ausgeatmet haben, atmen Sie erst wieder ein, wenn Sie das Bedürfnis dazu verspüren.
<G-vec01019-002-s103><breathe_out.atmen><en> Once you have fully exhaled, do not breathe again until you feel the need to do so.
<G-vec01019-002-s104><breathe_out.atmen><de> Sie atmen Materie ein - hauptsächlich Stickstoff und Sauerstoff in der Luft.
<G-vec01019-002-s104><breathe_out.atmen><en> You breathe matter - primarily nitrogen and oxygen in the air.
<G-vec01019-002-s105><breathe_out.atmen><de> Patienten sitzen in einer Stahlkammer unter ständiger Beobachtung der Vitalfunktionen (Blutdruck, Herzschlag, Atmung) und atmen über Schläuche Sauerstoff ein, was das Kohlenmonoxid aus dem Blut verdrängt.
<G-vec01019-002-s105><breathe_out.atmen><en> This involves patients sitting in a steel chamber while all vital functions are constantly monitored (blood pressure, heart rate, breathing) and breathe in oxygen via a hose, which removes the carbon monoxide in the blood.
<G-vec01019-002-s106><breathe_out.atmen><de> Das Obermaterial schützt, während der Fuß atmen kann und sich frei anfühlt.
<G-vec01019-002-s106><breathe_out.atmen><en> Engineered mesh on the upper protects while allowing the foot to breathe and flex freely.
<G-vec01019-002-s107><breathe_out.atmen><de> Wir empfehlen Ihnen, dass Sie die gründlich gereinigten Oberflächen mit qualitativ hochwertigen Mitteln schützen (imprägnieren), damit die Oberfläche atmen kann.
<G-vec01019-002-s107><breathe_out.atmen><en> Once the surfaces have been thoroughly cleaned, we recommend that you protect them with a quality product that will allow the surface to breathe.
<G-vec01019-002-s108><breathe_out.atmen><de> Die Membran besteht aus Poren (1,4 Milliarden Poren pro Quadratzentimeter), die 20.000 mal kleiner sind als ein Wassertropfen, aber 700 mal größer als ein Wasserdampfmolekül, sodass kein Wasser eindringen, die Haut aber atmen kann.
<G-vec01019-002-s108><breathe_out.atmen><en> The membrane is formed by pores (over 9 billion pores per square inch) which are 20,000 times smaller than a drop of water, but 700 times larger than a water vapour molecule preventing water penetration and helping the skin breathe.
<G-vec01019-002-s109><breathe_out.atmen><de> Es ist ein idyllischer Ort, an dem man die einzigartige Küstenlandschaft genießen und salzige Meeresluft zu atmen kann, ohne auf den Luxus oder zahlreichen Freizeitangebote der „New Golden Mile“ verzichten zu müssen.
<G-vec01019-002-s109><breathe_out.atmen><en> It is an idyllic place where you can enjoy the unique coastal scenery and breathe salty sea air without having to forgo the luxury or numerous leisure activities of the “New Golden Mile”.
<G-vec01019-002-s110><breathe_out.atmen><de> Der Gestank in diesen Zellen ist so schlimm, dass man kaum atmen kann.
<G-vec01019-002-s110><breathe_out.atmen><en> The stench in the small cell is so bad that it is difficult to breathe.
<G-vec01019-002-s111><breathe_out.atmen><de> Wählen Sie kunststofffreie Binden und Tampons, mit denen Ihre Haut atmen kann, und senken Sie dabei gleichzeitig die Verschmutzung durch Kunststoffe.
<G-vec01019-002-s111><breathe_out.atmen><en> Choosing plastic free pads and tampons lets intimate skin breathe and cuts out plastic pollution.
<G-vec01019-002-s112><breathe_out.atmen><de> Da Computer nicht atmen kann, werden Hörer öfters vom Gefühl der Erstickung gestört, denn sie erwarten, dass der Sprecher einatmet, und das passiert nicht.
<G-vec01019-002-s112><breathe_out.atmen><en> As computers don't breathe, human listeners get disturbed by a suffocating feeling, expecting the speaker to breathe in, which never happens.
<G-vec01019-002-s113><breathe_out.atmen><de> Die Atmosphäre ist zu dünn, um dort atmen zu können, und hat eine andere Zusammensetzung.
<G-vec01019-002-s113><breathe_out.atmen><en> The atmosphere is too thin to breathe and has a different composition.
<G-vec01019-002-s114><breathe_out.atmen><de> Eine hohe Sauerstoffdurchlässigkeit trägt dazu bei, dass die Augen atmen können und gesund bleiben.
<G-vec01019-002-s114><breathe_out.atmen><en> High oxygen permeability helps the eyes to breathe and keep healthy.
<G-vec01019-002-s115><breathe_out.atmen><de> SnoreBlock-Schnarchtabletten versorgen die Zellen mit Sauerstoff, sodass Sie ohne Probleme atmen können, während der Körper nicht nach zusätzlichen Sauerstoffquellen suchen muss.
<G-vec01019-002-s115><breathe_out.atmen><en> SnoreBlock snoring tablets also oxygenate the cells, making you breathe without any problems, while the body does not need to look for additional oxygen resources.
<G-vec01019-002-s116><breathe_out.atmen><de> Mehr info Diese Halbsohlen aus Leder sind an der Unterseite gepolstert und wurden perforiert, damit der Schuh und Ihr Fuß atmen können.
<G-vec01019-002-s116><breathe_out.atmen><en> Crafted in leather, these full insoles are padded on the underside and perforated to allow for the shoe and foot to breathe.
<G-vec01019-002-s117><breathe_out.atmen><de> Ich verwende meist keine Tamponaden, so dass Sie unmittelbar nach der Nasenkorrektur durch die Nase atmen können.
<G-vec01019-002-s117><breathe_out.atmen><en> I usually do not use packings inside your nose so it will be possible for you to breathe right after surgery.
<G-vec01019-002-s118><breathe_out.atmen><de> Gib darauf Acht, nicht zu viele Schichten aufzutragen, denn deine Haut muss atmen können.
<G-vec01019-002-s118><breathe_out.atmen><en> Be careful not to add too many layers – your skin needs to breathe.
<G-vec01019-002-s119><breathe_out.atmen><de> Atmen Sie beim Biken die klare Bergluft, erfrischen Sie sich in den Gasteiner Thermen und erleben Sie in Ihrem Sommerurlaub in Dorfgastein die alpine Idylle dieses herrlichen Fleckens im Salzburger Land.
<G-vec01019-002-s119><breathe_out.atmen><en> Breathe in the fresh mountain air while biking, take a refreshing dip in the thermal springs of Gastein and enjoy your summer holiday in idyllic alpine style in Dorfgastein - a lovely part of Salzburg.
<G-vec01019-002-s120><breathe_out.atmen><de> Nehmen Sie sich Zeit für sich, atmen Sie die frische Bergluft ein und genießen Sie Tage frei von Hektik.
<G-vec01019-002-s120><breathe_out.atmen><en> Take time for yourself, breathe in the fresh mountain air and enjoy your days off the beaten track.
<G-vec01019-002-s121><breathe_out.atmen><de> 5)Atmen Sie normal durch das Mundstück ein und aus.
<G-vec01019-002-s121><breathe_out.atmen><en> 5)Breathe normally (inhale and exhale) through the mouthpiece.
<G-vec01019-002-s122><breathe_out.atmen><de> Genießen Sie die Ursprünglichkeit und Gastlichkeit, lassen Sie sich leiten auf den Pfaden und Wegen, atmen Sie die Luft unserer Wälder, Weinberge und Ebenen, bestaunen Sie die Flora unserer fischreichen Flüsse und flanieren Sie in unseren jahrhundertealten Straßen...
<G-vec01019-002-s122><breathe_out.atmen><en> Take to the lanes and trails of our warm-hearted and authentic region, breathe in the air of our forests, vineyards and plains, admire the flora and abundant fish of our rivers, and stroll down our ancient streets.
<G-vec01019-002-s123><breathe_out.atmen><de> Atmen Sie den Unterschied Die 2000er Serie ist mit 3 intelligenten Voreinstellungen ausgestattet, bei denen Sie zwischen folgenden Modi wählen können: Allgemeiner Modus, Allergie, Bakterien und Viren.
<G-vec01019-002-s123><breathe_out.atmen><en> Breathe the difference The 2000 Series is engineered with 3 smart presettings that you can choose from: Pollution, Allergen, and Bacteria & Virus modes.
<G-vec01019-002-s124><breathe_out.atmen><de> Atmen Sie die frische Luft und lauschen Sie den Geräuschen des Waldes.
<G-vec01019-002-s124><breathe_out.atmen><en> Breathe fresh air and listen to the sounds of the forest.
<G-vec01019-002-s125><breathe_out.atmen><de> Atmen Sie auf diese Weise im Moment des Beginns von Kämpfen ein, dazwischen können Sie wie gewohnt atmen.
<G-vec01019-002-s125><breathe_out.atmen><en> Breathe in this way at the moment of onset of fights, in between you can breathe as usual.
<G-vec01019-002-s126><breathe_out.atmen><de> Genießen Sie den Blick über die Wellen, atmen Sie die salzige Luft und lernen Sie die kulinarischen Köstlichkeiten der Region kennen.
<G-vec01019-002-s126><breathe_out.atmen><en> Enjoy the view over the waves, breathe in the salty air and get to know the culinary delicacies of the region.
<G-vec01019-002-s127><breathe_out.atmen><de> Atmen Sie frischen Sauerstoff und spüren Sie, dass auch Ihr Körper ein Naturkörper ist, und somit ein Teil der Natur.
<G-vec01019-002-s127><breathe_out.atmen><en> Breathe fresh oxygen and feel that your body is a nature-body and thus, a part of nature.
<G-vec01019-002-s128><breathe_out.atmen><de> Atmen Sie frische Bergluft ein, tanken Sie Kraft und erleben Sie wahre Erholung im einzigartigen Zusammenspiel mit der Natur.
<G-vec01019-002-s128><breathe_out.atmen><en> Breathe in the fresh mountain air, refuel and experience real relaxation in its unique interplay with nature.
<G-vec01019-002-s129><breathe_out.atmen><de> Spüren Sie und atmen Sie sich wieder in Ihren Körper.
<G-vec01019-002-s129><breathe_out.atmen><en> Feel and breathe back into your body.
<G-vec01019-002-s130><breathe_out.atmen><de> Atmen Sie die besondere Atmosphäre dieses über 500 Jahre alten Kulturortes ein.
<G-vec01019-002-s130><breathe_out.atmen><en> Breathe in the special atmosphere of this over 500 years old cultural place.
<G-vec01019-002-s131><breathe_out.atmen><de> Entspannung pur – atmen Sie die Bergluft ein, vergessen Sie den Alltag und lassen Sie sich auf einen Vormittag in der Natur ein.
<G-vec01019-002-s131><breathe_out.atmen><en> Pure relaxation – breathe the mountain air, forget your everyday life and enjoy a morning in the fresh nature.
<G-vec01019-002-s132><breathe_out.atmen><de> Atmen Sie die frische Luft, genießen Sie das Panorama der Bergwelt und laufen Sie los.
<G-vec01019-002-s132><breathe_out.atmen><en> Breathe the fresh air, enjoy the panorama of the mountains and run to your heart’s content!
<G-vec01019-002-s133><breathe_out.atmen><de> Atmen Sie einfach mal durch und lassen Sie die heimelig-warme Atmosphäre des Backsteinhauses auf sich wirken.
<G-vec01019-002-s133><breathe_out.atmen><en> Breathe through just and let the cozy-warm atmosphere of the brick house on you.
<G-vec01019-002-s134><breathe_out.atmen><de> Atmen Sie den Duft von Jasmin ein, lassen Sie sich vom milden Klima und dem Gesang der Vögel wiegen, entspannen Sie sich bei einem Buch oder einem leckeren Aperitif, genießen Sie Momente des Wohlbefindens in unserem Wellnesscenter.
<G-vec01019-002-s134><breathe_out.atmen><en> Breathe in the scent of jasmine, let yourself be lulled by the mild climate and the singing of birds, relax with a book or a tasty aperitif, enjoy moments of well-being in our wellness center.
<G-vec01019-002-s135><breathe_out.atmen><de> Atmen Sie die unverfälschte Bergluft von einem der drei Balkone.
<G-vec01019-002-s135><breathe_out.atmen><en> Breathe the pure mountain air from one of the three balconies.
<G-vec01019-002-s136><breathe_out.atmen><de> Atmen Sie NICHT in den Inhalator.
<G-vec01019-002-s136><breathe_out.atmen><en> Do NOT breathe into the inhaler.
<G-vec01019-002-s137><breathe_out.atmen><de> Atmen Sie auf dem Weg nach oben, und atmen Sie auf dem Weg nach unten.
<G-vec01019-002-s137><breathe_out.atmen><en> Breathe out on the road, and breathe on the way down.
<G-vec01019-002-s138><breathe_out.atmen><de> Ganz casual in einem weichen Flanell-Hemd, Zip Hoodie und Dark Denim Jeans atmest Du die klare, kühle Luft und blickst noch einmal hinüber zur Freiheitsstatue, dann wird es Zeit, die Sachen zu packen.
<G-vec01019-002-s138><breathe_out.atmen><en> Casually dressed in a soft flannel shirt, a zip-up hoodie and dark denim jeans you breathe in the cool clear air and take a last look at the Statue of Liberty, then it's time to pack your things.
<G-vec01019-002-s139><breathe_out.atmen><de> Obgleich niemand ohne zu atmen überleben kann, ist es möglich, dass du gestresst und übermüdet wirst, weil du nicht richtig atmest.
<G-vec01019-002-s139><breathe_out.atmen><en> Although no one can survive without breathing, you may be allowing yourself to become stressed out and overly tired by failing to breathe properly.
<G-vec01019-002-s140><breathe_out.atmen><de> Hier kannst du durchatmen, hier wirst du umsorgt, verwöhnt und gebraucht, hier atmest du Luft von magischen Kräutern und bekommst Beauty-Pflege als Willkommensgruß.
<G-vec01019-002-s140><breathe_out.atmen><en> This is where you can breathe deeply, where you will be looked after and indulged, where you are needed. You breathe air filled with magical herbs and are greeted with beauty treatments as a welcome.
<G-vec01019-002-s141><breathe_out.atmen><de> Sei dankbar für die Luft die du atmest, die Lebensmittel die dich ernähren, das ruhige zu Hause in dem du leben darfst, die Sonne die deinen Tag erhellt.
<G-vec01019-002-s141><breathe_out.atmen><en> {Be thankful for the air you breathe, the food that nourishes you, the quiet home you live in, the sunshine that brightens up your day.
<G-vec01019-002-s142><breathe_out.atmen><de> Halte die Stirn und deinen Oberkopf leicht unter Wasser, während du atmest.
<G-vec01019-002-s142><breathe_out.atmen><en> Keep your forehead and the crown of your head slightly submerged while you breathe.
<G-vec01019-002-s143><breathe_out.atmen><de> So atmest du leichter, läufst schonender und trainierst effizienter.
<G-vec01019-002-s143><breathe_out.atmen><en> This means you breathe easier, run smoother and train more effectively.
<G-vec01019-002-s144><breathe_out.atmen><de> Oder auf molekularer Ebene: Die Sauerstoffmoleküle die du atmest wurden schon von ganz anderen Menschen geatmet.
<G-vec01019-002-s144><breathe_out.atmen><en> Or at a molecular level: the oxygen molecules you breathe have already been breathed by other people.
<G-vec01019-002-s145><breathe_out.atmen><de> Du atmest tief ein, und du atmest aus der Spitze deiner Lungen leicht aus.
<G-vec01019-002-s145><breathe_out.atmen><en> You breathe in deeply, and you breathe out lightly from the top of your lungs.
<G-vec01019-002-s147><breathe_out.atmen><de> Zweite Stufe – mit dem Mundstück, durch das du atmest.
<G-vec01019-002-s147><breathe_out.atmen><en> Second stage – Mouthpiece you breathe from.
<G-vec01019-002-s148><breathe_out.atmen><de> Beim "gleichmäßigen Atmen", atmest du mit gleicher Geschwindigkeit ein und aus.
<G-vec01019-002-s148><breathe_out.atmen><en> "Equal breathing" is where you breathe slowly in and out at an even rate.
<G-vec01019-002-s149><breathe_out.atmen><de> Wählst Du alkyliertes Benzin, reduziert sich die Verbrennung und Du atmest saubere Luft.
<G-vec01019-002-s149><breathe_out.atmen><en> However, if you choose alkylated gasoline, the combustion is much smaller and you breathe cleaner air.
<G-vec01019-002-s150><breathe_out.atmen><de> Wolle atmet, anders als Kunstfaser.
<G-vec01019-002-s150><breathe_out.atmen><en> Wool breathe, unlike synthetic fiber.
<G-vec01019-002-s151><breathe_out.atmen><de> Doch wenn er kommt, empfangt ihn mit weit offenem Herzen und atmet tief.
<G-vec01019-002-s151><breathe_out.atmen><en> Yet when it comes, receive it with an open heart and breathe deeply.
<G-vec01019-002-s152><breathe_out.atmen><de> Heisse Füße entstehen, wenn die Hitze im Schuh gestaut wird, was bei unbeweglich Schuhen und schlechtem Schuhmaterial, das nicht atmet, auftreten kann.
<G-vec01019-002-s152><breathe_out.atmen><en> Hot feet arise when heat accumulates within the shoe, which can happen with immobile shoes of poor material that does not breathe.
<G-vec01019-002-s153><breathe_out.atmen><de> Die Campagnolo Produktionsstätte ist ein Ort, an dem man den Duft der Arbeit atmet, wo die Erfahrung jedes einzelnen Arbeitnehmers noch viel zählt, wo Tradition und Wissen noch weitergegeben werden.
<G-vec01019-002-s153><breathe_out.atmen><en> The Campagnolo factory is somewhere you breathe work, where the experience of each individual worker still counts for so much, where tradition and knowhow are still handed down.
<G-vec01019-002-s154><breathe_out.atmen><de> Vertrauen Sie darauf, dass Ihr Körper auch beim Joggen automatisch richtig und genug atmet.
<G-vec01019-002-s154><breathe_out.atmen><en> Trust that your body will automatically breathe correctly and adequately while you're jogging.
<G-vec01019-002-s155><breathe_out.atmen><de> Darum sagen wir euch, um zu verstehen wie ihr mit ihr arbeiten könnt, entspannt euch, atmet, seid geduldig und eicht euch langsam auf die neue Energie ein, die nicht ganz so stark gegendrückt.
<G-vec01019-002-s155><breathe_out.atmen><en> So we say to you, relax, breathe, be patient, and recalibrate slowly to a new energy that doesn't push back quite as hard so you'll know how to operate within it.
<G-vec01019-002-s156><breathe_out.atmen><de> Atmet in diesem Bewusstsein euren irdischen Geist hinaus in den Kosmos und den göttlichen Geist hinein in den Körper.
<G-vec01019-002-s156><breathe_out.atmen><en> In this consciousness breathe your earthly spirit out into the cosmos and the divine spirit into the body.
<G-vec01019-002-s157><breathe_out.atmen><de> Atmet bewusst mitten in extremen Umständen.
<G-vec01019-002-s157><breathe_out.atmen><en> Breathe consciously in the midst of extreme circumstances.
<G-vec01019-002-s158><breathe_out.atmen><de> Man wacht auf mit der Sonne, atmet pure und frischeste Berg- und Waldluft, schmeißt den Kocher an und brüht erstmal einen leckern Kaffee.
<G-vec01019-002-s158><breathe_out.atmen><en> You wake up with the sun, breathe pure and fresh mountain and forest air, start the cooker and brew a delicious coffee.
<G-vec01019-002-s159><breathe_out.atmen><de> Wenn ihr ein Gefühl innerer Fülle entwickeln könnt, dadurch wie ihr atmet, dann bleibt der Geist gesättigt, gleichgültig in welcher Situation ihr euch auch befindet.
<G-vec01019-002-s159><breathe_out.atmen><en> When you can develop a sense of inner fullness simply by the way you breathe, the mind can stay nourished no matter what the situation.
<G-vec01019-002-s160><breathe_out.atmen><de> Sie ist die Luft, die sie für die Entwicklung einer politischen Bewegung atmet.
<G-vec01019-002-s160><breathe_out.atmen><en> It is the air they breathe for the development of a political movement.
<G-vec01019-002-s161><breathe_out.atmen><de> Atmet die frische Bergluft ein und geniesst einfach nur die Natur, von der ihr umgeben seid, während ihr hier seid.
<G-vec01019-002-s161><breathe_out.atmen><en> Breathe in the fresh mountain air and just simply enjoy the nature you're surrounded by while you're here.
<G-vec01019-002-s162><breathe_out.atmen><de> Ein Mensch der Schmerzen hat, atmet flach und ist nicht gerade gut gelaunt und entspannt.
<G-vec01019-002-s162><breathe_out.atmen><en> A human in pain will breathe shallow, he is in a bad mood and tensions aggravate.
<G-vec01019-002-s163><breathe_out.atmen><de> Der wasserdichte Stoff muss so beschaffen sein, dass Feuchtigkeit beim Verdunsten durchgelassen wird oder 'atmet'; andernfalls kann unser Schweiß nicht verdunsten, was dazu führt, dass wir überhitzen und nass vom Kondenswasser werden.
<G-vec01019-002-s163><breathe_out.atmen><en> The waterproof fabric must allow moisture vapour to pass through it, or 'breathe'; otherwise our sweat cannot evaporate, causing us to overheat and get wet from condensation.
<G-vec01019-002-s164><breathe_out.atmen><de> Mit dem Propheten Jesaja können wir heute sagen: Das Volk, das mitten im Smog wandelt, atmet, lebt, es sieht ein helles Licht, spürt einen Hauch frischer Luft.
<G-vec01019-002-s164><breathe_out.atmen><en> Together with the prophet Isaiah, we can say: The people who walk, breathe and live in the midst of smog, have seen a great light, have experienced a breath of fresh air.
<G-vec01019-002-s165><breathe_out.atmen><de> Bei den mexikanischen Revillagigedo-Inseln bringt ein weiblicher Buckelwal seinem Kalb bei, wie man atmet und seinen Auftrieb kontrolliert.
<G-vec01019-002-s165><breathe_out.atmen><en> In Mexico's Revillagigedo Islands, a humpback whale mother teachers her calf how to breathe and control its buoyancy.
<G-vec01019-002-s166><breathe_out.atmen><de> Ein Komfortappartement geeignet für anspruchsvolle Klienten atmet Geschichte und Luxus.
<G-vec01019-002-s166><breathe_out.atmen><en> A luxurious suite ideal for demanding clients where you can breathe history and luxury.
<G-vec01019-002-s167><breathe_out.atmen><de> Nasaler Stau kann durch allergische Rhinitis häufig verursacht werden und macht es schwierig, damit das Kind, besonders während der Nacht atmet, als sie schlafen.
<G-vec01019-002-s167><breathe_out.atmen><en> Nasal congestion can often be caused by allergic rhinitis and makes it difficult for the child to breathe, particularly during the night when they are sleeping.
<G-vec01019-002-s168><breathe_out.atmen><de> Sie will nicht, dass er Atmet.
<G-vec01019-002-s168><breathe_out.atmen><en> She doesn?t want him to breathe anymore.
<G-vec01019-002-s299><breathe_out.atmen><de> Wir haben die Teilnehmenden gelehrt, die Luft als Licht einzuatmen, das Wasser, Nahrung und die Sonne als Licht und Liebe aufzunehmen.
<G-vec01019-002-s299><breathe_out.atmen><en> Participants were taught to breathe in air, drink water, eat food, and take in the sun as love and light.
<G-vec01019-002-s300><breathe_out.atmen><de> Home > Herzinsuffizienz verstehen > Wenn Sie an einer Lungenerkrankung leiden, haben Sie möglicherweise Schwierigkeiten, genügend Sauerstoff einzuatmen oder genügend Kohlendioxid abzuatmen.
<G-vec01019-002-s300><breathe_out.atmen><en> If you have lung disease, you may find it difficult to breathe in enough oxygen or breath out enough carbon dioxide.
<G-vec01019-002-s301><breathe_out.atmen><de> Ganz zu schweigen von dem Unbehagen derer, die gezwungen sind, Küchengerüche einzuatmen.
<G-vec01019-002-s301><breathe_out.atmen><en> Not to mention the discomfort of those who live, forced to breathe kitchen odors.
<G-vec01019-002-s302><breathe_out.atmen><de> Samahita Retreat ist speziell eingerichtet, um Ihnen zu helfen, Ihr Potential freizusetzen, Ihre Energie zu steigern, Ihre Vitalität zu verbessern und Ihnen zu helfen, in ein neues Leben einzuatmen.
<G-vec01019-002-s302><breathe_out.atmen><en> Samahita Retreat is purposely set up to help you unlock your potential, increase your energy, recover and enhance your vitality, to breathe into a new life.
<G-vec01019-002-s303><breathe_out.atmen><de> Die hinabstürzenden Wassermassen tosen, rauschen und brausen - ein faszinierendes Naturschauspiel, um zu staunen, entlang der Wasserfälle langsam hinaufzusteigen bis zur obersten Fallstufe, die Gischt auf der eigenen Haut zu fühlen, die Wasserfallluft einzuatmen und die unbändige Kraft der Natur zu spüren.
<G-vec01019-002-s303><breathe_out.atmen><en> Huge waves of water are falling thunderous down in the valley basin, roaring and rustling - discover a fascinating natural spectacle on the way to the top and feel the spray, breathe the waterfall air, sense the power of nature.
<G-vec01019-002-s304><breathe_out.atmen><de> Unser Gast hat so die Möglichkeit, direkt im Terrain die kostbaren Denkmäler „zu berühren“ und die Atmosphäre, den "Genius loci", einzuatmen.
<G-vec01019-002-s304><breathe_out.atmen><en> Thus, our client has the opportunity not only to “touch” the precious monuments directly in the field, but also to “breathe” the local atmosphere and explore the “genius loci”.
<G-vec01019-002-s305><breathe_out.atmen><de> Ich war sehr erschöpft von dem Traum, und meine Stimmer war immer noch „heiser“ von all diesen Keuchern, wie ich versuchte, das Wasser nicht einzuatmen.
<G-vec01019-002-s305><breathe_out.atmen><en> I was very groggy from the dream, and my voice still 'froggy' from all the rasping, as I had tried not to breathe the water.
<G-vec01019-002-s356><breathe_out.atmen><de> Ob familiengerechte 3-Zimmer-Wohnungen mit Terrasse oder großzügige 4-Zimmer-Eigentumswohnungen mit privatem Garten, die aktuellen Neubau-Immobilienprojekte im Rhein Main Gebiet bieten allen Familienmitgliedern viel Luft zum Atmen und attraktiven Wohnkomfort im Grünen.
<G-vec01019-002-s356><breathe_out.atmen><en> Current newly constructed properties in the Rhine-Main area offer all family members room to breathe and attractive living space within nature, regardless if you are looking for a family-friendly three-bedroom apartment with terrace or spacious four-bedroom condominium with private garden. read more ›
<G-vec01019-002-s357><breathe_out.atmen><de> Weil Lea etwas lernen muss und ihre Freizeit somit nicht richtig genießen kann, darf Richie das auch nicht.Er muss sich gerade auf das Bett legen und ihr mit dem Gesicht als Sitzkissen dienen.Mit ihrer gelben Hot Pants setzt sich auf sein Gesicht und schlägt auf seinem Oberkörper ihr Buch auf.So muss er die ganze Zeit über liegen bleiben, während sie auf ihm oben ihre Unterlagen durchgeht.Er darf keine Luft atmen, sich nicht bewegen und ihr als Ablage für ihr Buch dienen.Dann steht Lea auf und und setzt sich umgedreht auf ihm, weil sie gelichzeitig auch noch Fernsehen will.Die Füße auf dem Bett stehend, verlagert sie ihr ganzes Gewicht auf ihren Arsch, den sie Richie aufs Gesicht drückt.Dann überschlägt sie auch noch kess ihre Beine und sitzt auf seinem Gesicht, wie auf einem Stuhl.
<G-vec01019-002-s357><breathe_out.atmen><en> Because Lea must learn something and her leisure time can not enjoy therefore correctly, Richie may not this either; He must put himself just on the bed and serve her as a floor cushion with the face; Sets itself yellow Hot Pants with hers on its face and her book hits its upper part of the body; So it must about be left all the time while it is going through its documents on it above; It may not breathe air, not move and serve it as a filing for her book; Then Lea gets up and and sits down turned over on him because she wants television gel self early, too; She the feet on the bed stationarily, shifted pushes her whole weight on her arse, the Richie on the face; She then estimates saucily her legs, too and sits on his face like on a chair.
<G-vec01019-002-s358><breathe_out.atmen><de> Robben müssen auch Luft atmen, deshalb sind Ölteppiche gefährlich für tauchende Tiere.
<G-vec01019-002-s358><breathe_out.atmen><en> Seals must also breathe air, because of this oil patches are dangerous for diving animals.
<G-vec01019-002-s359><breathe_out.atmen><de> Benutze die aufsteigende Luft aus den Röhren um zu Atmen.
<G-vec01019-002-s359><breathe_out.atmen><en> Use the bubbling pipes to breathe.
<G-vec01019-002-s364><breathe_out.atmen><de> Im Winter in der Wohnung manchmal einfach nicht mehr atmen.
<G-vec01019-002-s364><breathe_out.atmen><en> In winter the apartment sometimes just to breathe.
<G-vec01019-002-s365><breathe_out.atmen><de> Sie verbiegt dir langsam den Rücken, bis du nicht mehr atmen kannst.
<G-vec01019-002-s365><breathe_out.atmen><en> It slowly bends your back until you can't breathe.
<G-vec01019-002-s366><breathe_out.atmen><de> Ich sitze auf seinem Gesicht und drücke es tief in meinen Arsch, so dass er nicht mehr atmen kann.
<G-vec01019-002-s366><breathe_out.atmen><en> I sits on his face and pressed it deep into my ass that he can not breathe.
<G-vec01019-002-s367><breathe_out.atmen><de> Ich verstand nicht was mit mir passierte, aber plötzlich war alles blockiert, ich konnte nicht mehr atmen, und ein großes Rasseln kam aus meinem Hals anstelle von Luft, wie man normalerweise ausatmet.
<G-vec01019-002-s367><breathe_out.atmen><en> I didn't understand what was happening to me, but suddenly everything was blocked, I couldn't breathe, and a great rattle came out of my throat instead of air, the way one would normally exhale.
<G-vec01019-002-s395><breathe_out.atmen><de> Wir bringen die Luft zum atmen, wir bringen voran und dabei wehen wir dem einen oder anderen auch mal ins Gesicht.
<G-vec01019-002-s395><breathe_out.atmen><en> We let the air breathe, we move forward and from time to time we will blow into someone’s face.
<G-vec01019-002-s396><breathe_out.atmen><de> Während dieser Zeit drückte mir ein Polizist die Kehle zu und nahm mir die Luft zum atmen.
<G-vec01019-002-s396><breathe_out.atmen><en> During this time a policeman throttled me and the air took away from me to this breathe.
<G-vec01019-002-s397><breathe_out.atmen><de> Herrin Jane prügelt es schon aus ihm heraus und nimmt ihm die Luft zum atmen.
<G-vec01019-002-s397><breathe_out.atmen><en> Mistress Jane beats it out of him and takes the air from him so he can't breathe.
<G-vec01019-002-s398><breathe_out.atmen><de> Dieser Grundstoff des Lebens ist für uns nicht weniger wichtig als die Luft zum Atmen - und doch nicht selten stark verunreinigt.
<G-vec01019-002-s398><breathe_out.atmen><en> This basic element of life has no lesser importance to us than the air we breathe – and yet it is often heavily polluted.
<G-vec01019-002-s399><breathe_out.atmen><de> Luft zum Atmen Eine weitere innovative neue Funktion für saubere Innenluft in Volvo Fahrzeugen ist die ferngesteuerte Innenraumbelüftung.
<G-vec01019-002-s399><breathe_out.atmen><en> The air that we breathe Another new innovation in Volvo Cars’ mission to provide a clean in-car environment is remote cabin ventilation.
