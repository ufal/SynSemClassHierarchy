<G-vec00298-002-s205><swell.abschwellen><de> Die Entzündungen schwellen ab, und das Ganze ist nun auch erträglich.
<G-vec00298-002-s205><swell.abschwellen><en> The inflammations swell and the whole thing is now bearable.
