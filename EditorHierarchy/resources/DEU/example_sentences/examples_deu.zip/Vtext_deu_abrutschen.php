<G-vec00734-002-s019><slip.abrutschen><de> Bei Zugbelastung ziehen sie sich fester zusammen, so daß Gewichte nicht abrutschen.
<G-vec00734-002-s019><slip.abrutschen><en> During tensile load they pull together more firmly, so that weights do not slip.
<G-vec00734-002-s020><slip.abrutschen><de> Da man öfter auch mal das Gesäß nach oben nimmt und nicht selten an seiner Grenze trainiert, muss eine optimale Kraftübertragung gewährleistet sein und natürlich darf man auch nicht abrutschen.
<G-vec00734-002-s020><slip.abrutschen><en> As you often lift up your buttocks and train at your limits, optimal power transmission must be ensured and of course, you don’t want to slip off.
<G-vec00734-002-s021><slip.abrutschen><de> Zertifikate: BSCI, Sedex, ISO9001/14001, FSC, FDA, LFGB Ergonomisch geformter, abgerundeter PAKKA WOOD-Griff mit Kupferniete, um ein Abrutschen zu verhindern und ein angenehmes Halten zu gewährleisten.
<G-vec00734-002-s021><slip.abrutschen><en> Certificate: BSCI, Sedex, ISO9001/14001, FSC, FDA, LFGB Ergonomically designed rounded PAKKA WOOD Handle with copper rivet to prevent slip and create comfortable holding High quality 67 layer Damascus steel for precision beauty and strength Handmade HRC 62 Rockwell hardness 100 Quality Control 12 Degrees...
<G-vec00734-002-s022><slip.abrutschen><de> An beiden Seiten dieser Gratwanderung könnte sie abrutschen.
<G-vec00734-002-s022><slip.abrutschen><en> She could slip on both sides of this balancing act.
<G-vec00734-002-s023><slip.abrutschen><de> Diese Verfolgung des grundlegenden Gewissens der Menschheit macht die chinesische Gesellschaft noch korrupter und läßt ihre Moral noch weiter abrutschen.
<G-vec00734-002-s023><slip.abrutschen><en> This persecution of humanity's most basic conscience makes the Chinese society more corrupt and its moral standards slip further.
<G-vec00734-002-s024><slip.abrutschen><de> Um ein Abrutschen der Hände zu vermeiden, verfügt das PUKY ZL 16-1 Alu Kinderfahrrad Capt'n Sharky über Sicherheitsgriffe.
<G-vec00734-002-s024><slip.abrutschen><en> The Puky Play bicycle Capt'n Sharky has safety grips in order to avoid that hands slip off.
<G-vec00734-002-s025><slip.abrutschen><de> Es ist einleuchtend, dass gerahmte Dias oder lose Positive, die auf einer schrägen, glatten Glasplatte liegen, abrutschen können.
<G-vec00734-002-s025><slip.abrutschen><en> It is obvious that mounted slides or single positives that are placed on a sloping, smooth glass panel are likely to slip.
<G-vec00734-002-s026><slip.abrutschen><de> Insbesondere wenn die Schultergurte von der Schulter abrutschen oder der Beckengurt über den Bauch verläuft, kann es bei einem Crash zu gefährlich hohen Belastungen kommen.
<G-vec00734-002-s026><slip.abrutschen><en> In particular, if the shoulder strap slip off the shoulder or the lap belt runs over the stomach, it may result in dangerously high pressures in the event of a crash.
<G-vec00734-002-s027><slip.abrutschen><de> 1963 brach der Mount Agung aus und ließ das inzwischen geplünderte und zerfallene Schiff am Strand abrutschen.
<G-vec00734-002-s027><slip.abrutschen><en> 1963 Mount Agung erupted and let slip the now plundered and ruined boat down the beach into the sea.
<G-vec00734-002-s028><slip.abrutschen><de> Vielleicht hat nicht alles seinen zugewiesenen Platz wie in einem Büro, oder wenn Sie versuchen, in demselben Raum zu arbeiten, in dem Sie essen, schlafen oder sich entspannen, können die Dinge von uns abrutschen.
<G-vec00734-002-s028><slip.abrutschen><en> Maybe everything doesn’t have its assigned space in the same way that it does in an office, or maybe trying to work in the same room you eat, sleep or relax means things slip away from us.
<G-vec00734-002-s029><slip.abrutschen><de> Achten Sie darauf, dass das Gerät beim Transport und im Betrieb einen festen Stand aufweist und nicht herabfallen, abrutschen oder umkippen kann.
<G-vec00734-002-s029><slip.abrutschen><en> Make sure that during transport and in use the instrument has a proper stand and does not fall, slip or turn over because persons could be injured.
<G-vec00734-002-s030><slip.abrutschen><de> Dies führt zu einem Abrutschen der Nachfrage und einem darauffolgenden Preisrückgang.
<G-vec00734-002-s030><slip.abrutschen><en> This results in a slip in demand and a subsequent drop in price.
<G-vec00734-002-s031><slip.abrutschen><de> Zugantrieb durch Trommelmotor, kein Abrutschen des Bands.
<G-vec00734-002-s031><slip.abrutschen><en> Pulling drive by drum motor, no belt slip.
<G-vec00734-002-s032><slip.abrutschen><de> CC passt sich eng an jedes Gefälle oder jeden Schnitt an und reduziert oder eliminiert das Eindringen von Wasser für Oberflächenabflussregen, und reduziert so das Risiko von Abrutschen und Versagen der Böschung.
<G-vec00734-002-s032><slip.abrutschen><en> Water Management - The flexibility of CC allows the material to closely follow the profile of any slope or cutting, reducing or eliminating water ingress and mitigating the risk of deep slip and failure.
<G-vec00734-002-s033><slip.abrutschen><de> Durch den Ring am Ende des Griffes kann man nicht vom Griff abrutschen und das Messer liegt sicher in der Hand.
<G-vec00734-002-s033><slip.abrutschen><en> Through the ring at the end of the handle can not slip off the handle you.
<G-vec00734-002-s034><slip.abrutschen><de> Das habe ich hauptsächlich gemacht, da ich befürchtet habe dass ich, wenn ich abrutschen sollte den Helm beschädigen könnte.
<G-vec00734-002-s034><slip.abrutschen><en> This was mainly done because I feared that a slip with the saw blade would damage the helmet.
<G-vec00735-002-s019><slip_in.abrutschen><de> Bei Zugbelastung ziehen sie sich fester zusammen, so daß Gewichte nicht abrutschen.
<G-vec00735-002-s019><slip_in.abrutschen><en> During tensile load they pull together more firmly, so that weights do not slip.
<G-vec00735-002-s020><slip_in.abrutschen><de> Da man öfter auch mal das Gesäß nach oben nimmt und nicht selten an seiner Grenze trainiert, muss eine optimale Kraftübertragung gewährleistet sein und natürlich darf man auch nicht abrutschen.
<G-vec00735-002-s020><slip_in.abrutschen><en> As you often lift up your buttocks and train at your limits, optimal power transmission must be ensured and of course, you don’t want to slip off.
<G-vec00735-002-s021><slip_in.abrutschen><de> Zertifikate: BSCI, Sedex, ISO9001/14001, FSC, FDA, LFGB Ergonomisch geformter, abgerundeter PAKKA WOOD-Griff mit Kupferniete, um ein Abrutschen zu verhindern und ein angenehmes Halten zu gewährleisten.
<G-vec00735-002-s021><slip_in.abrutschen><en> Certificate: BSCI, Sedex, ISO9001/14001, FSC, FDA, LFGB Ergonomically designed rounded PAKKA WOOD Handle with copper rivet to prevent slip and create comfortable holding High quality 67 layer Damascus steel for precision beauty and strength Handmade HRC 62 Rockwell hardness 100 Quality Control 12 Degrees...
<G-vec00735-002-s022><slip_in.abrutschen><de> An beiden Seiten dieser Gratwanderung könnte sie abrutschen.
<G-vec00735-002-s022><slip_in.abrutschen><en> She could slip on both sides of this balancing act.
<G-vec00735-002-s023><slip_in.abrutschen><de> Diese Verfolgung des grundlegenden Gewissens der Menschheit macht die chinesische Gesellschaft noch korrupter und läßt ihre Moral noch weiter abrutschen.
<G-vec00735-002-s023><slip_in.abrutschen><en> This persecution of humanity's most basic conscience makes the Chinese society more corrupt and its moral standards slip further.
<G-vec00735-002-s024><slip_in.abrutschen><de> Um ein Abrutschen der Hände zu vermeiden, verfügt das PUKY ZL 16-1 Alu Kinderfahrrad Capt'n Sharky über Sicherheitsgriffe.
<G-vec00735-002-s024><slip_in.abrutschen><en> The Puky Play bicycle Capt'n Sharky has safety grips in order to avoid that hands slip off.
<G-vec00735-002-s025><slip_in.abrutschen><de> Es ist einleuchtend, dass gerahmte Dias oder lose Positive, die auf einer schrägen, glatten Glasplatte liegen, abrutschen können.
<G-vec00735-002-s025><slip_in.abrutschen><en> It is obvious that mounted slides or single positives that are placed on a sloping, smooth glass panel are likely to slip.
<G-vec00735-002-s026><slip_in.abrutschen><de> Insbesondere wenn die Schultergurte von der Schulter abrutschen oder der Beckengurt über den Bauch verläuft, kann es bei einem Crash zu gefährlich hohen Belastungen kommen.
<G-vec00735-002-s026><slip_in.abrutschen><en> In particular, if the shoulder strap slip off the shoulder or the lap belt runs over the stomach, it may result in dangerously high pressures in the event of a crash.
<G-vec00735-002-s027><slip_in.abrutschen><de> 1963 brach der Mount Agung aus und ließ das inzwischen geplünderte und zerfallene Schiff am Strand abrutschen.
<G-vec00735-002-s027><slip_in.abrutschen><en> 1963 Mount Agung erupted and let slip the now plundered and ruined boat down the beach into the sea.
<G-vec00735-002-s028><slip_in.abrutschen><de> Vielleicht hat nicht alles seinen zugewiesenen Platz wie in einem Büro, oder wenn Sie versuchen, in demselben Raum zu arbeiten, in dem Sie essen, schlafen oder sich entspannen, können die Dinge von uns abrutschen.
<G-vec00735-002-s028><slip_in.abrutschen><en> Maybe everything doesn’t have its assigned space in the same way that it does in an office, or maybe trying to work in the same room you eat, sleep or relax means things slip away from us.
<G-vec00735-002-s029><slip_in.abrutschen><de> Achten Sie darauf, dass das Gerät beim Transport und im Betrieb einen festen Stand aufweist und nicht herabfallen, abrutschen oder umkippen kann.
<G-vec00735-002-s029><slip_in.abrutschen><en> Make sure that during transport and in use the instrument has a proper stand and does not fall, slip or turn over because persons could be injured.
<G-vec00735-002-s030><slip_in.abrutschen><de> Dies führt zu einem Abrutschen der Nachfrage und einem darauffolgenden Preisrückgang.
<G-vec00735-002-s030><slip_in.abrutschen><en> This results in a slip in demand and a subsequent drop in price.
<G-vec00735-002-s031><slip_in.abrutschen><de> Zugantrieb durch Trommelmotor, kein Abrutschen des Bands.
<G-vec00735-002-s031><slip_in.abrutschen><en> Pulling drive by drum motor, no belt slip.
<G-vec00735-002-s032><slip_in.abrutschen><de> CC passt sich eng an jedes Gefälle oder jeden Schnitt an und reduziert oder eliminiert das Eindringen von Wasser für Oberflächenabflussregen, und reduziert so das Risiko von Abrutschen und Versagen der Böschung.
<G-vec00735-002-s032><slip_in.abrutschen><en> Water Management - The flexibility of CC allows the material to closely follow the profile of any slope or cutting, reducing or eliminating water ingress and mitigating the risk of deep slip and failure.
<G-vec00735-002-s033><slip_in.abrutschen><de> Durch den Ring am Ende des Griffes kann man nicht vom Griff abrutschen und das Messer liegt sicher in der Hand.
<G-vec00735-002-s033><slip_in.abrutschen><en> Through the ring at the end of the handle can not slip off the handle you.
<G-vec00735-002-s034><slip_in.abrutschen><de> Das habe ich hauptsächlich gemacht, da ich befürchtet habe dass ich, wenn ich abrutschen sollte den Helm beschädigen könnte.
<G-vec00735-002-s034><slip_in.abrutschen><en> This was mainly done because I feared that a slip with the saw blade would damage the helmet.
