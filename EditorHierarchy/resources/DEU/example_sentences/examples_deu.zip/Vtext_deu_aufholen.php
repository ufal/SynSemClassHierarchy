<G-vec00185-001-s037><catch.aufholen><de> Irgendwann, und dem restlichen Russland ist beginnend mit der Hauptstadt, aber immer noch das aufholen ist langsamer und es gibt noch einen Unterschied.
<G-vec00185-001-s037><catch.aufholen><en> At some point, and the rest of Russia is beginning to catch up with the capital, but still this is slower and there is still a difference.
<G-vec00185-001-s038><catch.aufholen><de> """Nach der bevorstehenden EU-Erweiterung werden Rumänien und Bulgarien sicher rasch aufholen."
<G-vec00185-001-s038><catch.aufholen><en> """Following the forthcoming EU enlargement, I expect Romania and Bulgaria to catch up quickly."
<G-vec00185-001-s039><catch.aufholen><de> Wenn man wie der 25-Jährige aber schon so lange und so weit seiner Zeit voraus ist, dann kann man die Konkurrenz ganz zurückgelehnt auch mal etwas aufholen lassen – und mit einer kleinen EP wie dieser trotzdem vorlegen.
<G-vec00185-001-s039><catch.aufholen><en> But when someone is so far ahead of his time, and always has been, as it's the case with the 25-year-old rapper, it's alright to lean back and allow the competitors to catch up – and at the same time, he still defends his grounds, like with this little EP.
<G-vec00185-001-s040><catch.aufholen><de> Um anhaltendes Chaos zu vermeiden, und die Wirtschaft weiter wachsen zu lassen, sendete die Regierung von Panama einen Hilferuf aus, um schnelle, zuverlässige, kostengünstige Stromversorgung auf Zeit zu finden, bis das dauerhafte Energienetz aufholen konnte.
<G-vec00185-001-s040><catch.aufholen><en> To avoid the ongoing havoc and keep the economy growing, the Panamanian Government sent out an SOS to find quick, reliable, cost-effective interim power until the permanent energy grid could catch up.
<G-vec00185-001-s041><catch.aufholen><de> Über kurz oder lang werden die Digitalkameras hier sicher aufholen, zumal bei Digitalkameras ja im Gegensatz zu der eher konservativen Scanner-Industrie erheblich in Forschung und Entwicklung investiert wird.
<G-vec00185-001-s041><catch.aufholen><en> Sooner or later digital cameras will catch up, since there is a lot of research and development spended in digital cameras compared to scanners. in one point the photographing method is leading: The speed is significantly higher compared to a classic scan.
<G-vec00185-001-s042><catch.aufholen><de> Das Unternehmen geht davon aus, im zweiten Halbjahr bei der Leistung aufholen zu können und dass sich damit auch das Ergebnis besser entwickelt.
<G-vec00185-001-s042><catch.aufholen><en> The company expects to catch up with revenues in the second half of the year and that the earnings will also be better.
<G-vec00185-001-s043><catch.aufholen><de> Aber das Bewusstsein kann mit einem Ruck aufholen – das ist die wahre Bedeutung einer Revolution.
<G-vec00185-001-s043><catch.aufholen><en> But consciousness can catch up with a bang. That is the real meaning of a revolution.
<G-vec00185-001-s044><catch.aufholen><de> Sonos blieb konsequent auf Kurs und setzte auf Systeme und Technologien der nächsten Generation in der Überzeugung, dass die Verbraucher aufholen würden.
<G-vec00185-001-s044><catch.aufholen><en> Sonos determinedly stayed the course, making key bets on next-generation systems and technologies with the conviction that consumers would catch up.
<G-vec00185-001-s045><catch.aufholen><de> Das dritte Viertel konnten die Gäste mit 20:18 knapp für sich entscheiden, aber nicht entscheidend aufholen.
<G-vec00185-001-s045><catch.aufholen><en> The guests were able to win the third quarter with 20:18, but did not catch up decisively.
<G-vec00185-001-s046><catch.aufholen><de> Wenn die Hypothek wird, früher oder spГ¤ter BГ¤nde der regionalen Markt aufholen Hauptstadt Indikatoren und der Markt wird es sehr attraktiv, und daher hart umkГ¤mpft.
<G-vec00185-001-s046><catch.aufholen><en> If the mortgage will, sooner or later volumes of the regional market will catch up capital indicators, and the market it will be very attractive, and therefore highly competitive.
<G-vec00185-001-s047><catch.aufholen><de> Man schaut, wie sich die anderen kultiviert haben und wie wir selbst aufholen können.
<G-vec00185-001-s047><catch.aufholen><en> Seeing how others cultivate, we should figure out how we can catch up.
<G-vec00185-001-s048><catch.aufholen><de> Wir müssen etwas aufholen.
<G-vec00185-001-s048><catch.aufholen><en> We need to catch up a bit.
<G-vec00185-001-s049><catch.aufholen><de> Einer der Hauptgründe war, war es unvergesslich die Fähigkeit, auf dem Boot für eine schöne Fahrt zu gehen und eine ganze Reihe von Schwarzbarsch aufholen.
<G-vec00185-001-s049><catch.aufholen><en> One of the main reasons it was unforgettable was the ability to go out for a nice ride on the boat and catch up a whole bunch of smallmouth bass.
<G-vec00185-001-s050><catch.aufholen><de> Nicht nur im Bereich IT, sondern besonders auch im Bereich Nachhaltigkeit muss der Handel noch weiter aufholen - zu viele Einsparmöglichkeiten und Ressourcen sparende Potenziale liegen hier brach.
<G-vec00185-001-s050><catch.aufholen><en> Retail still needs to catch up in the IT sector, but also in terms of sustainability – huge potential savings in money and resources are laying idle here.
<G-vec00185-001-s051><catch.aufholen><de> Der deutschsprachige Münzhandel stellt traditionell einen großen Teil der Aussteller auf der New York International, wobei in den letzten Jahren vor allem Spanien und Italien aufholen.
<G-vec00185-001-s051><catch.aufholen><en> The German coin trade by tradition makes up a large part of the exhibitors at the New York International, although Italy and Spain in particular have started to catch up in recent years.
<G-vec00185-001-s052><catch.aufholen><de> Harrison war aber schneller und konnte schon 1,4 Sekunden aufholen.
<G-vec00185-001-s052><catch.aufholen><en> Harrison was faster and was able to catch up for 1.4 seconds.
<G-vec00185-001-s053><catch.aufholen><de> Gehen Sie den Hügel hinunter und Hilfe Scooby aufholen shaggy.
<G-vec00185-001-s053><catch.aufholen><en> Go down the hill and help Scooby catch up with shaggy.
<G-vec00185-001-s054><catch.aufholen><de> Wie Intel Low-Power-Chips kommen in mehr Geräte, mehr App-Hersteller werden für sie optimieren, und die großen Spieler (die machen die begehrtesten Anwendungen) werden wahrscheinlich schnell aufholen.
<G-vec00185-001-s054><catch.aufholen><en> As Intel low-power chips appear in more devices, more app producers will optimize for them, and the big players (who make the most desirable apps) are likely to catch up quickly.
<G-vec00185-001-s055><catch.aufholen><de> Es war gut, sich über die neuesten Marketing-Trends kennen 2018 werde mit den genannten Trends aufholen unser sowie unser Kundengeschäft zu einer völlig anderen Dimension wachsen überhaupt.
<G-vec00185-001-s055><catch.aufholen><en> It was good to know about the latest marketing trends in 2018 will catch up with the listed trends to grow our as well as our clients business to a totally different dimension at all.
<G-vec00185-001-s075><catch.aufholen><de> Ich fürchte auch in der kommenden Welle, in der es noch mehr um Daten geht und die unter KI/AI subsumiert ist, wird es uns schwer fallen die Rückstände aufzuholen.
<G-vec00185-001-s075><catch.aufholen><en> I’m also afraid that in the coming wave, which is even more about data and which is subsumed under AI, it will be difficult for us to catch up.
<G-vec00185-001-s076><catch.aufholen><de> Dann zurück zur Arbeit, um wieder aufzuholen.
<G-vec00185-001-s076><catch.aufholen><en> Then back to work to catch up.
<G-vec00185-001-s077><catch.aufholen><de> Tolle Software:Was mich begeistert hat, nachdem ich nach der Stilllegung der Seite zurückgekommen bin, war, dass ihre Software immer noch die beste war, sogar nachdem die Konkurrenz 16 Monate hatte um aufzuholen.
<G-vec00185-001-s077><catch.aufholen><en> Great Software: What amazed me when I got back after the shutdown is that their software is still the best, even after giving rivals 16 months to catch up.
<G-vec00185-001-s078><catch.aufholen><de> Falun Gong-Praktizierende bemühen sich sehr, mit dem Prozess der Fa-Berichtigung Schritt zu halten oder aufzuholen.
<G-vec00185-001-s078><catch.aufholen><en> Falun Gong practitioners are trying hard to maintain or catch up with the progress of the Fa-rectification.
<G-vec00185-001-s079><catch.aufholen><de> Verärgert über mich und diese Verwechslung fuhr ich wieder hinaus auf die Strecke mit dem Ziel, die verloren gegangene Zeit wieder aufzuholen.
<G-vec00185-001-s079><catch.aufholen><en> Angry about that me and that confusion i drove again out on the track with the aim to catch up the lost time.
<G-vec00185-001-s080><catch.aufholen><de> Vielmehr verlangsamt das Topping den vertikalen Wuchs und ermöglicht so den Seitenzweigen aufzuholen, während zwei neue Haupt-Colas entstehen.
<G-vec00185-001-s080><catch.aufholen><en> Rather topping slows vertical growth down allowing side branches to catch up while two new top colas are emerging.
<G-vec00185-001-s081><catch.aufholen><de> "Buch, mit 324%, sie das Unmögliche Wette, um aufzuholen und übertreffen die 315% ige Erhöhung der Goldpreis in Dollar verwaltet, ist der Euro das letzte Gold "", mit einer kleine ""183%."
<G-vec00185-001-s081><catch.aufholen><en> It managed the impossible bet to catch up and surpass the 315% increase in the gold price in dollars.
<G-vec00185-001-s082><catch.aufholen><de> Halten Sie auf den Pinguin, um ihn aufzuholen und hüpfen sie nach oben, bis er das Eis bricht und landet erfolgreich.
<G-vec00185-001-s082><catch.aufholen><en> Keep clicking on the penguin so as to catch it up and bounce it upwards until it breaks the ice and lands successfully.
<G-vec00185-001-s083><catch.aufholen><de> Also lassen Sie sich eine Tour um den Ecwid Speicher, um aufzuholen mit dem Updates der letzten drei Monate.
<G-vec00185-001-s083><catch.aufholen><en> So let's take a tour around your Ecwid store to catch up with the updates of the last three months.
<G-vec00185-001-s084><catch.aufholen><de> Zusammengefasst: Renzi ist im Nachteil, aber behält die Möglichkeit aufzuholen.
<G-vec00185-001-s084><catch.aufholen><en> In summary: Renzi is at a disadvantage, but retains the opportunity to catch up.
<G-vec00185-001-s085><catch.aufholen><de> Die Männer, die überfordert, um aufzuholen den richtigen Artikel sind häufig fallen für Ihre gefälschte Produkte, die aus billigen Zutaten und ineffizient Formel erstellt werden.
<G-vec00185-001-s085><catch.aufholen><en> The males who’re overwhelmed to catch up the proper item frequently drop for your bogus products which are created up of cheap ingredients and inefficient formula.
<G-vec00185-001-s086><catch.aufholen><de> Und die meisten von ihnen nur ein neues Telefon kaufen, um mit der neuesten Mode, um aufzuholen oder zeigen ihre Treue zu einem bestimmten Marke, wie Apple oder Samsung.
<G-vec00185-001-s086><catch.aufholen><en> And most of them just buy a new phone in order to catch up with the latest fashion or show their loyalty to some particular brand, like Apple or Samsung.
<G-vec00185-001-s087><catch.aufholen><de> "Bei der aktuellen Rate würde es 15 Jahre dauern, aufzuholen,"" schließt Ludovic Subran."
<G-vec00185-001-s087><catch.aufholen><en> "At the current rate, it would take 15 years to catch up,"" concludes Ludovic Subran."
<G-vec00185-001-s088><catch.aufholen><de> In Wahrheit, ich erwartet hatte, Geld zu erhalten, die mich auf die Hypothek aufzuholen erlauben würde und Zahlungen wieder aufzunehmen.
<G-vec00185-001-s088><catch.aufholen><en> In truth, I had been expecting to receive money that would allow me to catch up on the mortgage and resume payments.
<G-vec00185-001-s089><catch.aufholen><de> "Verdoppeln Sie sich ""nicht hinauf"" die Dosis aufzuholen."
<G-vec00185-001-s089><catch.aufholen><en> "Do not ""double-up"" the dose to catch up."
<G-vec00185-001-s090><catch.aufholen><de> Nach dem ›Big Bang‹ der REWE Deutschland war es auch für die REWE DORTMUND an der Zeit, aufzuholen.
<G-vec00185-001-s090><catch.aufholen><en> After the 'Big Bang' at REWE Germany, it was now time for REWE DORTMUND to catch up.
<G-vec00185-001-s091><catch.aufholen><de> Beide Objekte in dem, mit dem anderen aufzuholen beschleunigt fliegen schnell und hoch, einer von ihnen.
<G-vec00185-001-s091><catch.aufholen><en> Both objects where flying fast and high, one of them sped up as to catch up with the other.
<G-vec00185-001-s092><catch.aufholen><de> Sobald du Mir verschrieben bist, hast du nicht aufzuholen.
<G-vec00185-001-s092><catch.aufholen><en> When you are committed to Me, you do not have to catch up.
<G-vec00185-001-s093><catch.aufholen><de> Ich plane, mein Verlobter dort im Juli, weil ich war so begeistert von den Familien, die dort arbeiten, und ich will, dass sie erleben, was ich durchgemacht habe, und ich kann nicht warten, um aufzuholen mit meinen alten Freunden wieder berührt.
<G-vec00185-001-s093><catch.aufholen><en> I am planning to take my fiance there in July because i was so touched by the families that work there and I want her to experience what I went through and I can't wait to catch up with my old friends again. Love this place!
<G-vec00280-002-s022><overtake.aufholen><de> Das versucht auch BOINCstats, sie scheinen sich mit #22 nicht zufrieden zu geben und versuchen aufzuholen.
<G-vec00280-002-s022><overtake.aufholen><en> BOINCstats are already trying to do this as they don’t seem to be satisfied with #22 and are attempting to overtake.
<G-vec00689-002-s055><catch_on.aufholen><de> Die Top 16 – 20 % aus unserem Markt verstehen was Nachhaltigkeit ist, die Nachzügler müssen schnell aufholen, wenn der Wendepunkt für Nachhaltigkeit erreicht ist.
<G-vec00689-002-s055><catch_on.aufholen><en> The top 16-20% of our market are getting sustainability, for the laggards, you will have to play a catch up game when the tipping point for sustainability is reached.
<G-vec00689-002-s056><catch_on.aufholen><de> Es mag sein, du kannst nicht aufholen.
<G-vec00689-002-s056><catch_on.aufholen><en> Maybe you cannot catch up.
<G-vec00689-002-s057><catch_on.aufholen><de> Wir sind in unserer Situation, weil unser Motorhersteller die neue Technologie wahrscheinlich unterschätzt hat – und auch kaum aufholen kann.
<G-vec00689-002-s057><catch_on.aufholen><en> We are in our position because the regulations are very complicated and Renault has probably underestimated the new technology and it is difficult to catch up now.
<G-vec00689-002-s058><catch_on.aufholen><de> Dies führt dann zu mehr als 4 neuen Trieben, während die Seitenäste aufholen können, was wiederum zu größeren Blüten an den Enden dieser Zweige führt.
<G-vec00689-002-s058><catch_on.aufholen><en> This gives rise to 4+ new shoots, while lateral branches have time to catch up, which in turn produces larger main buds on the ends of these branches.
<G-vec00689-002-s059><catch_on.aufholen><de> Jeder der beiden Spieler kann “ aufholen” oder “ zuruckfallen” um dem jeweils anderen Spieler gleichzukommen.
<G-vec00689-002-s059><catch_on.aufholen><en> Either player can “catch up” or “fall back” to match the other player.
<G-vec00689-002-s060><catch_on.aufholen><de> Langfristig muss Europa natürlich auch im Bereich Finanzierungssummen aufholen.
<G-vec00689-002-s060><catch_on.aufholen><en> On the long term, of course, Europe will also need to catch up with regard to the volume of financing.
<G-vec00689-002-s061><catch_on.aufholen><de> Wir müssen etwas aufholen.
<G-vec00689-002-s061><catch_on.aufholen><en> We need to catch up a bit.
<G-vec00689-002-s062><catch_on.aufholen><de> Wenn ich schon sehr nass bin ohne den geringsten Widerstand, werde ich deinen Freund akzeptieren... buchstäblich in jeder Position, wir fangen klassisch an, dann renne ich nach einem Hund, ich werde aufholen, wenn du dich hinlegst..., vergiss nicht, mich lange zu treffen.
<G-vec00689-002-s062><catch_on.aufholen><en> When I am already very wet without the slightest resistance, I will accept your friend... literally in every position, we start classically, then from the back, I will run for a dog, I will catch up when you lie down..., do not forget to meet me for a long time.
<G-vec00689-002-s063><catch_on.aufholen><de> Und auch in punkto Tarife, Kundenbetreuung und Angebote konnte Österreichs drittgrößtes Kommunikationsunternehmen in der Kundengunst stark aufholen.
<G-vec00689-002-s063><catch_on.aufholen><en> And also where tariffs, customer care and offers are concerned, the third largest communications company of Austria has been able to markedly catch up.
<G-vec00689-002-s064><catch_on.aufholen><de> Nichtsdestotrotz gibt es Elemente, wo deutsche Universitäten aufholen können, beispielsweise in der Gewichtung von Lehrinhalten.
<G-vec00689-002-s064><catch_on.aufholen><en> Nevertheless there are aspects where German universities can catch up, for example in weighting of course content.
<G-vec00689-002-s065><catch_on.aufholen><de> Das kann die Veröffentlichung des Entwurfs oder Internetstandards um viele Monate (manchmal sogar Jahre) verzögern, während die anderen Dokumente aufholen.
<G-vec00689-002-s065><catch_on.aufholen><en> This can also delay the publication of the Draft or Internet standard by many months (sometimes even years) while the other documents catch up.
<G-vec00689-002-s066><catch_on.aufholen><de> Aber ich bin sicher, dass wir in der Rückrunde aufholen können.
<G-vec00689-002-s066><catch_on.aufholen><en> Still, I’m sure we can catch up in the second half of the season.
<G-vec00689-002-s067><catch_on.aufholen><de> Alles darüber hinaus ist ein Aufholen dessen, was ich in den ersten Tagen durch Familienfeiern nicht geschafft habe.
<G-vec00689-002-s067><catch_on.aufholen><en> All rows above are my try to catch up with my loss of scheduled knitting that happened at the first two days while being on birthday parties with the family.
<G-vec00689-002-s068><catch_on.aufholen><de> Wifi und Samsung Smart TV mit iPlayer Aufholen und DVD-Player.
<G-vec00689-002-s068><catch_on.aufholen><en> Wifi and Samsung Smart TV with iPlayer catch up and DVD player.
<G-vec00689-002-s069><catch_on.aufholen><de> Hauptgrund dafür ist, dass ein Fondsmanager zuerst rund 1% an Performance aufholen muss, bis er nur überhaupt seine eigenen jährlichen Kosten gedeckt hat.
<G-vec00689-002-s069><catch_on.aufholen><en> The main reason for this is that a fund manager first has to catch up around 1% of performance until he has only covered his own annual costs.
<G-vec00689-002-s070><catch_on.aufholen><de> So reagieren häufig Mittelständler und Konzerne, die erst jahrelang gezögert haben und dann knallhart aufholen wollen.
<G-vec00689-002-s070><catch_on.aufholen><en> This is a common reaction of SMEs and corporations who have hesitated for years and then want to catch up all at once.
<G-vec00689-002-s071><catch_on.aufholen><de> Kinder können Entwicklungsrückstände in der motorischen Leistungsfähigkeit nur schwer aufholen, die Unterschiede in der Fitness verfestigen sich über die Zeit.
<G-vec00689-002-s071><catch_on.aufholen><en> For children having deficiencies in motor skills, it is very difficult to catch up. Differences in fitness substantiate with time.
<G-vec00689-002-s072><catch_on.aufholen><de> Ich musste zwar in den meisten Fächern im Vergleich zu meinen Mitschülern aufholen, aber das war leichter als ich gedacht hatte.
<G-vec00689-002-s072><catch_on.aufholen><en> Even though I had to catch up with the other students in most of my subjects, it was easier than I had expected.
<G-vec00689-002-s073><catch_on.aufholen><de> Weil ich so ein extremer Spätzünder bin, mache ich mir Sorgen, dass ich nicht mehr aufholen kann.
<G-vec00689-002-s073><catch_on.aufholen><en> Since I am such an incredibly late bloomer, I have a fear that I won't be able to catch up to everyone else.
<G-vec00689-002-s093><catch_on.aufholen><de> Insofern bedanke ich mich im Namen des Krone Teams und verspreche allen Wählern, dass wir auch in den kommenden zwölf Monaten alles daran setzen werden, die Spitzenposition bei den Curtainsidern zu verteidigen und in den anderen Kategorien weiter aufzuholen.
<G-vec00689-002-s093><catch_on.aufholen><en> In this respect, I would like to thank you on behalf of the Krone team and promise all voters that we will continue to do everything in our power over the next twelve months to defend our leading position among curtainsiders and to catch up further in the other categories.
<G-vec00689-002-s094><catch_on.aufholen><de> Während unserer Nachmittagsbesprechung am ersten Tag erkannte ich, dass wir bereits weit gereist waren und dass es für jeden, der später kam, schwierig sein würde dies aufzuholen.
<G-vec00689-002-s094><catch_on.aufholen><en> By the middle of our afternoon session on our first day, I realized that we had already traveled very far and it would be difficult for anyone arriving late to catch up.
<G-vec00689-002-s095><catch_on.aufholen><de> Das Tutorial ist aus der Perspektive eines Anfängers geschrieben, und Sie sollten in der Lage sein, ohne viel Mühe aufzuholen.
<G-vec00689-002-s095><catch_on.aufholen><en> The tutorial is written from a beginner's perspective, and you should be able to catch up without much trouble.
<G-vec00689-002-s096><catch_on.aufholen><de> Für die Ukraine wird #13 wohl auch das Endergebnis sein zu langsam um aufzuholen und zu schnell, um zu verlieren.
<G-vec00689-002-s096><catch_on.aufholen><en> For Ukraine, #13 will most likely be their end result, too slow to catch up and too fast to lose.
<G-vec00689-002-s097><catch_on.aufholen><de> Ich hatte elf Jahre verlorenes Wissen aufzuholen.
<G-vec00689-002-s097><catch_on.aufholen><en> I had eleven lost years of knowledge to catch up.
<G-vec00689-002-s098><catch_on.aufholen><de> Wenn du in letzter Zeit keine Briefe oder handgeschriebenen Nachrichten geschrieben hast, ist diese Woche perfekt, um es aufzuholen, denn es ist "An dich denken Woche", die Leute dazu bringen sollte, eine Welle von Liebe, Fürsorge und Glück durch das Senden von Grußkarten zu erzeugen.
<G-vec00689-002-s098><catch_on.aufholen><en> If you have not written any letter or handwritten messages lately, this week is perfect to catch up as it is "Thinking of You Week" that should inspire people to create a wave of love, caring and happiness by sending greeting cards.
<G-vec00689-002-s099><catch_on.aufholen><de> Zusammengefasst: Renzi ist im Nachteil, aber behält die Möglichkeit aufzuholen.
<G-vec00689-002-s099><catch_on.aufholen><en> In summary: Renzi is at a disadvantage, but retains the opportunity to catch up.
<G-vec00689-002-s100><catch_on.aufholen><de> Der Ort, um sich zu treffen, aufzuholen, Gerichte aus allen Ecken der Welt zu essen, Getränke zu trinken, sich zu entspannen, ein Buch zu lesen, Musik zu hören, zu arbeiten, zu verabreden oder die Zeit zu vergessen.
<G-vec00689-002-s100><catch_on.aufholen><en> The place to meet, catch up, eat dishes from all corners of the globe, drink drinks, relax, read a book, listen to (live) music, work, date or forget about time.
<G-vec00689-002-s101><catch_on.aufholen><de> Wir haben uns zum Ziel gesetzt, dabei zu helfen, diesen Forschungsrückstand von fast 100 Jahren aufzuholen.
<G-vec00689-002-s101><catch_on.aufholen><en> We have set ourselves on helping to catch up on this research backlog of almost 100 years.
<G-vec00689-002-s102><catch_on.aufholen><de> Wir haben am Anfang etwas Glück und eine sehr gute Strategie gehabt, um die zwei Runden aufzuholen.
<G-vec00689-002-s102><catch_on.aufholen><en> We had some good luck and a very good strategy early on to catch back the two laps.
<G-vec00689-002-s103><catch_on.aufholen><de> Vermeide es, Gegenstände zu benutzen, um aufzuholen.
<G-vec00689-002-s103><catch_on.aufholen><en> Avoid using items to catch up.
<G-vec00689-002-s104><catch_on.aufholen><de> Als Vollzeit-Mama hatte ich keine Zeit selbst vernünftig zu essen, also aß ich einfach die Reste der Kinder über den Tag verteilt und dann, wenn sie im Bett lagen, kochte ich eine große Mahlzeit für mich und meinen Mann – meine Portionsgrößen hätten wahrscheinlich mindestens für zwei Personen ausgereicht, aber ich dachte mir, da ich am Tag nichts Richtiges gegessen hatte, war es okay am Abend etwas mehr zu essen und aufzuholen.
<G-vec00689-002-s104><catch_on.aufholen><en> Being a full time Mum I didn’t have time to eat properly myself, so I just ate their leftovers during the day and then once they’d gone to bed I’d cook a big meal for me and my husband – my portion sizes could probably have fed at least two people, but I figured seeing as I hadn’t eaten properly during the day it was ok to catch up by eating more in the evening.
<G-vec00689-002-s105><catch_on.aufholen><de> Bevor Sie versuchen, den Betrag "aufzuholen", müssen Sie sicherstellen, dass es wirklich notwendig ist.
<G-vec00689-002-s105><catch_on.aufholen><en> Before trying to "catch up" the amount, you need to make sure that it is really necessary.
<G-vec00689-002-s106><catch_on.aufholen><de> Somit haben diese keine Chance, aufzuholen.
<G-vec00689-002-s106><catch_on.aufholen><en> Therefore they don't have a chance to catch up.
<G-vec00689-002-s107><catch_on.aufholen><de> Sie mussten die Entwicklung fortsetzen und schließlich die Produktivität steigern, um den Rückstand gegenüber dem vorherigen Anbieter aufzuholen; schließlich mussten sie sowohl Backend- als auch Frontend-Bereiche der Lösung entwickeln.
<G-vec00689-002-s107><catch_on.aufholen><en> They needed to continue development and eventually increase productivity to catch up with a backlog remaining after the previous vendor; after all, they still needed to develop both backend and frontend parts of the solution.
<G-vec00689-002-s108><catch_on.aufholen><de> Es ist ein Fakt, dass junge Menschen, die für lange Zeit vom Arbeitsmarkt ausgeschlossen sind, benachteiligt im „Während-der-Arbeit-Lernen“ sind und somit Defizite haben, ohne Möglichkeit diese aufzuholen.
<G-vec00689-002-s108><catch_on.aufholen><en> It's a fact that young people excluded from the labour force for long periods are deprived of on-the-job learning leaving them with a skills deficit that they will never able to catch up.
<G-vec00689-002-s109><catch_on.aufholen><de> Während dies ein Weg ist, all die zeitraubenden und mühsamen Anstrengungen zu überspringen, die Sie ins Spiel stecken müssen, nur um aufzuholen, könnte Sie sich mit dieser Methode Online-Betrugsstellen aussetzen.
<G-vec00689-002-s109><catch_on.aufholen><en> While this is one way to skip all the time-consuming and painstaking effort you have to put into the game just to catch up, using this method could expose you to online scam sites.
<G-vec00689-002-s110><catch_on.aufholen><de> Ich weiß, dass Tage beschäftigt sein können und es keine Zeit gibt, aufzuholen.
<G-vec00689-002-s110><catch_on.aufholen><en> I know days can be busy and there is no time to catch up.
<G-vec00689-002-s111><catch_on.aufholen><de> Während sich die Qualität der Finanzwerte US-amerikanischer und europäischer Unternehmen in letzter Zeit verschlechtert hat, begannen die japanischen Unternehmen, die immer im Rückstand waren, aufzuholen.
<G-vec00689-002-s111><catch_on.aufholen><en> While the quality of financials in US and European companies deteriorated recently, the Japanese companies, which have been always lagging behind, started to catch up.
<G-vec01001-002-s055><catch_up.aufholen><de> Die Top 16 – 20 % aus unserem Markt verstehen was Nachhaltigkeit ist, die Nachzügler müssen schnell aufholen, wenn der Wendepunkt für Nachhaltigkeit erreicht ist.
<G-vec01001-002-s055><catch_up.aufholen><en> The top 16-20% of our market are getting sustainability, for the laggards, you will have to play a catch up game when the tipping point for sustainability is reached.
<G-vec01001-002-s056><catch_up.aufholen><de> Es mag sein, du kannst nicht aufholen.
<G-vec01001-002-s056><catch_up.aufholen><en> Maybe you cannot catch up.
<G-vec01001-002-s057><catch_up.aufholen><de> Wir sind in unserer Situation, weil unser Motorhersteller die neue Technologie wahrscheinlich unterschätzt hat – und auch kaum aufholen kann.
<G-vec01001-002-s057><catch_up.aufholen><en> We are in our position because the regulations are very complicated and Renault has probably underestimated the new technology and it is difficult to catch up now.
<G-vec01001-002-s058><catch_up.aufholen><de> Dies führt dann zu mehr als 4 neuen Trieben, während die Seitenäste aufholen können, was wiederum zu größeren Blüten an den Enden dieser Zweige führt.
<G-vec01001-002-s058><catch_up.aufholen><en> This gives rise to 4+ new shoots, while lateral branches have time to catch up, which in turn produces larger main buds on the ends of these branches.
<G-vec01001-002-s059><catch_up.aufholen><de> Jeder der beiden Spieler kann “ aufholen” oder “ zuruckfallen” um dem jeweils anderen Spieler gleichzukommen.
<G-vec01001-002-s059><catch_up.aufholen><en> Either player can “catch up” or “fall back” to match the other player.
<G-vec01001-002-s060><catch_up.aufholen><de> Langfristig muss Europa natürlich auch im Bereich Finanzierungssummen aufholen.
<G-vec01001-002-s060><catch_up.aufholen><en> On the long term, of course, Europe will also need to catch up with regard to the volume of financing.
<G-vec01001-002-s061><catch_up.aufholen><de> Wir müssen etwas aufholen.
<G-vec01001-002-s061><catch_up.aufholen><en> We need to catch up a bit.
<G-vec01001-002-s062><catch_up.aufholen><de> Wenn ich schon sehr nass bin ohne den geringsten Widerstand, werde ich deinen Freund akzeptieren... buchstäblich in jeder Position, wir fangen klassisch an, dann renne ich nach einem Hund, ich werde aufholen, wenn du dich hinlegst..., vergiss nicht, mich lange zu treffen.
<G-vec01001-002-s062><catch_up.aufholen><en> When I am already very wet without the slightest resistance, I will accept your friend... literally in every position, we start classically, then from the back, I will run for a dog, I will catch up when you lie down..., do not forget to meet me for a long time.
<G-vec01001-002-s063><catch_up.aufholen><de> Und auch in punkto Tarife, Kundenbetreuung und Angebote konnte Österreichs drittgrößtes Kommunikationsunternehmen in der Kundengunst stark aufholen.
<G-vec01001-002-s063><catch_up.aufholen><en> And also where tariffs, customer care and offers are concerned, the third largest communications company of Austria has been able to markedly catch up.
<G-vec01001-002-s064><catch_up.aufholen><de> Nichtsdestotrotz gibt es Elemente, wo deutsche Universitäten aufholen können, beispielsweise in der Gewichtung von Lehrinhalten.
<G-vec01001-002-s064><catch_up.aufholen><en> Nevertheless there are aspects where German universities can catch up, for example in weighting of course content.
<G-vec01001-002-s065><catch_up.aufholen><de> Das kann die Veröffentlichung des Entwurfs oder Internetstandards um viele Monate (manchmal sogar Jahre) verzögern, während die anderen Dokumente aufholen.
<G-vec01001-002-s065><catch_up.aufholen><en> This can also delay the publication of the Draft or Internet standard by many months (sometimes even years) while the other documents catch up.
<G-vec01001-002-s066><catch_up.aufholen><de> Aber ich bin sicher, dass wir in der Rückrunde aufholen können.
<G-vec01001-002-s066><catch_up.aufholen><en> Still, I’m sure we can catch up in the second half of the season.
<G-vec01001-002-s067><catch_up.aufholen><de> Alles darüber hinaus ist ein Aufholen dessen, was ich in den ersten Tagen durch Familienfeiern nicht geschafft habe.
<G-vec01001-002-s067><catch_up.aufholen><en> All rows above are my try to catch up with my loss of scheduled knitting that happened at the first two days while being on birthday parties with the family.
<G-vec01001-002-s068><catch_up.aufholen><de> Wifi und Samsung Smart TV mit iPlayer Aufholen und DVD-Player.
<G-vec01001-002-s068><catch_up.aufholen><en> Wifi and Samsung Smart TV with iPlayer catch up and DVD player.
<G-vec01001-002-s069><catch_up.aufholen><de> Hauptgrund dafür ist, dass ein Fondsmanager zuerst rund 1% an Performance aufholen muss, bis er nur überhaupt seine eigenen jährlichen Kosten gedeckt hat.
<G-vec01001-002-s069><catch_up.aufholen><en> The main reason for this is that a fund manager first has to catch up around 1% of performance until he has only covered his own annual costs.
<G-vec01001-002-s070><catch_up.aufholen><de> So reagieren häufig Mittelständler und Konzerne, die erst jahrelang gezögert haben und dann knallhart aufholen wollen.
<G-vec01001-002-s070><catch_up.aufholen><en> This is a common reaction of SMEs and corporations who have hesitated for years and then want to catch up all at once.
<G-vec01001-002-s071><catch_up.aufholen><de> Kinder können Entwicklungsrückstände in der motorischen Leistungsfähigkeit nur schwer aufholen, die Unterschiede in der Fitness verfestigen sich über die Zeit.
<G-vec01001-002-s071><catch_up.aufholen><en> For children having deficiencies in motor skills, it is very difficult to catch up. Differences in fitness substantiate with time.
<G-vec01001-002-s072><catch_up.aufholen><de> Ich musste zwar in den meisten Fächern im Vergleich zu meinen Mitschülern aufholen, aber das war leichter als ich gedacht hatte.
<G-vec01001-002-s072><catch_up.aufholen><en> Even though I had to catch up with the other students in most of my subjects, it was easier than I had expected.
<G-vec01001-002-s073><catch_up.aufholen><de> Weil ich so ein extremer Spätzünder bin, mache ich mir Sorgen, dass ich nicht mehr aufholen kann.
<G-vec01001-002-s073><catch_up.aufholen><en> Since I am such an incredibly late bloomer, I have a fear that I won't be able to catch up to everyone else.
<G-vec01001-002-s093><catch_up.aufholen><de> Insofern bedanke ich mich im Namen des Krone Teams und verspreche allen Wählern, dass wir auch in den kommenden zwölf Monaten alles daran setzen werden, die Spitzenposition bei den Curtainsidern zu verteidigen und in den anderen Kategorien weiter aufzuholen.
<G-vec01001-002-s093><catch_up.aufholen><en> In this respect, I would like to thank you on behalf of the Krone team and promise all voters that we will continue to do everything in our power over the next twelve months to defend our leading position among curtainsiders and to catch up further in the other categories.
<G-vec01001-002-s094><catch_up.aufholen><de> Während unserer Nachmittagsbesprechung am ersten Tag erkannte ich, dass wir bereits weit gereist waren und dass es für jeden, der später kam, schwierig sein würde dies aufzuholen.
<G-vec01001-002-s094><catch_up.aufholen><en> By the middle of our afternoon session on our first day, I realized that we had already traveled very far and it would be difficult for anyone arriving late to catch up.
<G-vec01001-002-s095><catch_up.aufholen><de> Das Tutorial ist aus der Perspektive eines Anfängers geschrieben, und Sie sollten in der Lage sein, ohne viel Mühe aufzuholen.
<G-vec01001-002-s095><catch_up.aufholen><en> The tutorial is written from a beginner's perspective, and you should be able to catch up without much trouble.
<G-vec01001-002-s096><catch_up.aufholen><de> Für die Ukraine wird #13 wohl auch das Endergebnis sein zu langsam um aufzuholen und zu schnell, um zu verlieren.
<G-vec01001-002-s096><catch_up.aufholen><en> For Ukraine, #13 will most likely be their end result, too slow to catch up and too fast to lose.
<G-vec01001-002-s097><catch_up.aufholen><de> Ich hatte elf Jahre verlorenes Wissen aufzuholen.
<G-vec01001-002-s097><catch_up.aufholen><en> I had eleven lost years of knowledge to catch up.
<G-vec01001-002-s098><catch_up.aufholen><de> Wenn du in letzter Zeit keine Briefe oder handgeschriebenen Nachrichten geschrieben hast, ist diese Woche perfekt, um es aufzuholen, denn es ist "An dich denken Woche", die Leute dazu bringen sollte, eine Welle von Liebe, Fürsorge und Glück durch das Senden von Grußkarten zu erzeugen.
<G-vec01001-002-s098><catch_up.aufholen><en> If you have not written any letter or handwritten messages lately, this week is perfect to catch up as it is "Thinking of You Week" that should inspire people to create a wave of love, caring and happiness by sending greeting cards.
<G-vec01001-002-s099><catch_up.aufholen><de> Zusammengefasst: Renzi ist im Nachteil, aber behält die Möglichkeit aufzuholen.
<G-vec01001-002-s099><catch_up.aufholen><en> In summary: Renzi is at a disadvantage, but retains the opportunity to catch up.
<G-vec01001-002-s100><catch_up.aufholen><de> Der Ort, um sich zu treffen, aufzuholen, Gerichte aus allen Ecken der Welt zu essen, Getränke zu trinken, sich zu entspannen, ein Buch zu lesen, Musik zu hören, zu arbeiten, zu verabreden oder die Zeit zu vergessen.
<G-vec01001-002-s100><catch_up.aufholen><en> The place to meet, catch up, eat dishes from all corners of the globe, drink drinks, relax, read a book, listen to (live) music, work, date or forget about time.
<G-vec01001-002-s101><catch_up.aufholen><de> Wir haben uns zum Ziel gesetzt, dabei zu helfen, diesen Forschungsrückstand von fast 100 Jahren aufzuholen.
<G-vec01001-002-s101><catch_up.aufholen><en> We have set ourselves on helping to catch up on this research backlog of almost 100 years.
<G-vec01001-002-s102><catch_up.aufholen><de> Wir haben am Anfang etwas Glück und eine sehr gute Strategie gehabt, um die zwei Runden aufzuholen.
<G-vec01001-002-s102><catch_up.aufholen><en> We had some good luck and a very good strategy early on to catch back the two laps.
<G-vec01001-002-s103><catch_up.aufholen><de> Vermeide es, Gegenstände zu benutzen, um aufzuholen.
<G-vec01001-002-s103><catch_up.aufholen><en> Avoid using items to catch up.
<G-vec01001-002-s104><catch_up.aufholen><de> Als Vollzeit-Mama hatte ich keine Zeit selbst vernünftig zu essen, also aß ich einfach die Reste der Kinder über den Tag verteilt und dann, wenn sie im Bett lagen, kochte ich eine große Mahlzeit für mich und meinen Mann – meine Portionsgrößen hätten wahrscheinlich mindestens für zwei Personen ausgereicht, aber ich dachte mir, da ich am Tag nichts Richtiges gegessen hatte, war es okay am Abend etwas mehr zu essen und aufzuholen.
<G-vec01001-002-s104><catch_up.aufholen><en> Being a full time Mum I didn’t have time to eat properly myself, so I just ate their leftovers during the day and then once they’d gone to bed I’d cook a big meal for me and my husband – my portion sizes could probably have fed at least two people, but I figured seeing as I hadn’t eaten properly during the day it was ok to catch up by eating more in the evening.
<G-vec01001-002-s105><catch_up.aufholen><de> Bevor Sie versuchen, den Betrag "aufzuholen", müssen Sie sicherstellen, dass es wirklich notwendig ist.
<G-vec01001-002-s105><catch_up.aufholen><en> Before trying to "catch up" the amount, you need to make sure that it is really necessary.
<G-vec01001-002-s106><catch_up.aufholen><de> Somit haben diese keine Chance, aufzuholen.
<G-vec01001-002-s106><catch_up.aufholen><en> Therefore they don't have a chance to catch up.
<G-vec01001-002-s107><catch_up.aufholen><de> Sie mussten die Entwicklung fortsetzen und schließlich die Produktivität steigern, um den Rückstand gegenüber dem vorherigen Anbieter aufzuholen; schließlich mussten sie sowohl Backend- als auch Frontend-Bereiche der Lösung entwickeln.
<G-vec01001-002-s107><catch_up.aufholen><en> They needed to continue development and eventually increase productivity to catch up with a backlog remaining after the previous vendor; after all, they still needed to develop both backend and frontend parts of the solution.
<G-vec01001-002-s108><catch_up.aufholen><de> Es ist ein Fakt, dass junge Menschen, die für lange Zeit vom Arbeitsmarkt ausgeschlossen sind, benachteiligt im „Während-der-Arbeit-Lernen“ sind und somit Defizite haben, ohne Möglichkeit diese aufzuholen.
<G-vec01001-002-s108><catch_up.aufholen><en> It's a fact that young people excluded from the labour force for long periods are deprived of on-the-job learning leaving them with a skills deficit that they will never able to catch up.
<G-vec01001-002-s109><catch_up.aufholen><de> Während dies ein Weg ist, all die zeitraubenden und mühsamen Anstrengungen zu überspringen, die Sie ins Spiel stecken müssen, nur um aufzuholen, könnte Sie sich mit dieser Methode Online-Betrugsstellen aussetzen.
<G-vec01001-002-s109><catch_up.aufholen><en> While this is one way to skip all the time-consuming and painstaking effort you have to put into the game just to catch up, using this method could expose you to online scam sites.
<G-vec01001-002-s110><catch_up.aufholen><de> Ich weiß, dass Tage beschäftigt sein können und es keine Zeit gibt, aufzuholen.
<G-vec01001-002-s110><catch_up.aufholen><en> I know days can be busy and there is no time to catch up.
<G-vec01001-002-s111><catch_up.aufholen><de> Während sich die Qualität der Finanzwerte US-amerikanischer und europäischer Unternehmen in letzter Zeit verschlechtert hat, begannen die japanischen Unternehmen, die immer im Rückstand waren, aufzuholen.
<G-vec01001-002-s111><catch_up.aufholen><en> While the quality of financials in US and European companies deteriorated recently, the Japanese companies, which have been always lagging behind, started to catch up.
<G-vec01017-002-s561><catch_up.aufholen><de> Überdies ergibt sich, dass die USA und deren Verbündeten den Radikalen und Extremisten die Möglichkeit gewähren wollen, um Atem zu holen, ihre Reihen wiederherzustellen, das Blutvergießen auf syrischem Boden zu verlängern und damit eine politische Regulierung zu erschweren.
<G-vec01017-002-s561><catch_up.aufholen><en> To all appearances, the United States and its allies want to give radicals and extremists a chance to catch their breath and restore their ranks in order to prolong bloodshed on the Syrian territory and thus hinder political settlement.
<G-vec01017-002-s562><catch_up.aufholen><de> Doch die anderen Regionen holen auf: Vier von zehn europäischen Führungskräften (41 %) und etwa die Hälfte der Befragten aus der Asia-Pacific-Region sowie aus Lateinamerika (jeweils 49 %) geben an, ihre CEOs seien heute öfter bereit mit den Medien zu kommunizieren als noch vor einigen Jahren.
<G-vec01017-002-s562><catch_up.aufholen><en> However, these regions may soon catch up: Four in 10 European executives (41 percent) and approximately half of Asia Pacific executives (49 percent) and Latin American executives (49 percent) report that their CEOs are more willing to talk with the news media today than they were several years ago.
<G-vec01017-002-s563><catch_up.aufholen><de> Das bedeutet Rudern bei maximaler Intensität in kurzen Phasen, gefolgt von Erholungsphasen, um Luft zu holen und sich auf die nächste intensive Runde vorzubereiten.
<G-vec01017-002-s563><catch_up.aufholen><en> Rowing at maximum intensity for short periods, using recovery phases to catch your breath and prepare for the next intense round.
<G-vec01017-002-s564><catch_up.aufholen><de> Keuchend beugte er sich vor, seine Hände auf seine Knien gestützt, um Luft zu holen.
<G-vec01017-002-s564><catch_up.aufholen><en> Heavily panting he bent down, his hands on his knees to catch his breath.
<G-vec01017-002-s565><catch_up.aufholen><de> Die Mitbewerber holen ständig auf und der Kernmarkt wird enger.
<G-vec01017-002-s565><catch_up.aufholen><en> Competitors catch up and the market gets tighter.
<G-vec01017-002-s566><catch_up.aufholen><de> Wir können die Umstände nicht beherrschen; ganz gleich, wie sehr wir uns anstrengen, ein aufrechtes Leben zu führen und dem richtigen Pfad zu folgen: trotz allem geschehen diese Dinge, die Schatten holen uns ein, und die Zeit läßt uns hinter sich, ein zerbrochenes Abbild all dessen, was wir jemals zu sein hofften.
<G-vec01017-002-s566><catch_up.aufholen><en> We do not have control of circumstances; no matter how hard we try to lead a good life and follow the right path: things still happen, the shadows catch up with us, and time leaves us behind, a shattered image of all we'd ever hoped to be.
<G-vec01017-002-s567><catch_up.aufholen><de> Dann werdet ihr möglicherweise von der Wahrheit geradezu „überflutet“ werden und kaum noch Zeit haben, „Atem zu holen“.
<G-vec01017-002-s567><catch_up.aufholen><en> Then it is possible that it will come flooding out and you will hardly have time to catch your breath.
<G-vec01017-002-s568><catch_up.aufholen><de> So kann es gehen, wenn ein Bild sich immer weiter verändern will und zwischendurch eine längere Rast macht um Atem zu holen und sich zu entfalten….dann komme ich daher, nehme es so, wie es ist, mache ein feines Foto und daraus wunderschöne neue Bilder, die sich jetzt sogar um Tassen schmiegen dürfen.
<G-vec01017-002-s568><catch_up.aufholen><en> Only with Habibiflo! So it can go when an image will be changed continuously and between makes a longer rest to catch his breath and to unfold …. Then I come along, take it as it is, make a fine photo and beautiful new images which now even may nestle cups.
<G-vec01017-002-s569><catch_up.aufholen><de> Diesen Morgen haben wir jedoch beschlossen zunächst etwas Schlaf nach zu holen.
<G-vec01017-002-s569><catch_up.aufholen><en> That morning though, we just headed out a few meters to catch up with some sleep.
<G-vec01017-002-s570><catch_up.aufholen><de> Das Spiel packt Sie so, dass Sie sogar vergessen aufzutauchen um Luft zu holen.
<G-vec01017-002-s570><catch_up.aufholen><en> The game grabs you so much you even forget to come up to the surface to catch your breath!
<G-vec01017-002-s571><catch_up.aufholen><de> Nach einer 11-tägigen Wirbelwindtour durch das Land brauchte unsere Gruppe ein paar Tage, um Luft zu holen.
<G-vec01017-002-s571><catch_up.aufholen><en> After an 11 day whirlwind tour of the country, our group needed a few days to catch our breath.
<G-vec01017-002-s572><catch_up.aufholen><de> „Phantasie und Wirklichkeit holen sich nicht ein.“ (Manfred Hinrich, dt.
<G-vec01017-002-s572><catch_up.aufholen><en> “Fantasy and reality do not catch up.”
<G-vec01017-002-s573><catch_up.aufholen><de> Die Fahrgeschäfte können zwar aufregend sein, aber wenn Sie Atem holen und eine Pause von der Aufregung einlegen möchten, werfen Sie einen Blick in den Model Shop, wo neue Ideen für LEGO-Displays im Park geboren werden.
<G-vec01017-002-s573><catch_up.aufholen><en> While the rides can be exhilarating, if you’re looking to catch your breath and take a break from the excitement, take a peek inside the Model Shop, where new ideas for park LEGO displays are born.
<G-vec01017-002-s574><catch_up.aufholen><de> Einmal saß ein Affe am Strand des Meeres und versuchte, die Fische aus dem Wasser zu holen.
<G-vec01017-002-s574><catch_up.aufholen><en> One time a monkey was sitting on the beach and tried to catch fish out of the water.
<G-vec01017-002-s575><catch_up.aufholen><de> Am nächsten Tag holen wir sie ein, trinken gemeinsam einen Tee, fahren weiter und sehen sie nie wieder...
<G-vec01017-002-s575><catch_up.aufholen><en> We catch them up the next day and drink some tea together, ride on and never see them again...
<G-vec01017-002-s576><catch_up.aufholen><de> Das heißt, humorvoller grindiger Punk, chaotischer Hardcore und ne ordentliche Schippe Death Metal aus den guten Anfangstagen derselben, bieten eine gute Grundlage um die Nachbarschaft zu verwüsten und sich die Bullen an die Haustür zu holen.
<G-vec01017-002-s576><catch_up.aufholen><en> That means, humorous, grinding punk, chaotic hardcore and a proper dash of death metal from the early days, offering the perfect basis to devastate the neighborhood and to catch the cops.
<G-vec01017-002-s577><catch_up.aufholen><de> Da ja Jerry jetzt fast fünf Wochen nicht in Deutschland war, und ich allein nichts zustande gebracht habe, gibt es natürlich viel nach zu holen.
<G-vec01017-002-s577><catch_up.aufholen><en> Now that Jerry haven’t been in Germany for five weeks, and I haven’t been able to do anything for the blog alone, there is a lot to catch up.
