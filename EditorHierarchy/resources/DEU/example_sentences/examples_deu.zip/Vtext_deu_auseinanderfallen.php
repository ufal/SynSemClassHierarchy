<G-vec00599-002-s024><disintegrate.auseinanderfallen><de> Falls Putin jedoch scheitern sollte, werde Russland auseinanderfallen.
<G-vec00599-002-s024><disintegrate.auseinanderfallen><en> If Putin fails, however, Russia will disintegrate.
<G-vec00786-002-s021><deteriorate.auseinanderfallen><de> Es ist besonders unvorstellbar, dass das Wirtschaftssystem so schnell auseinander fallen kann.
<G-vec00786-002-s021><deteriorate.auseinanderfallen><en> Specifically, it is unimaginable that the economic system can deteriorate so rapidly!
<G-vec00849-002-s033><diverge.auseinanderfallen><de> Zusammenfassung In der Literatur zum Themenkomplex „Rassismus“ fällt auf, daß historische, ökonomische, sowie politische Analysen des Phänomens und die Theorien zur Verfasstheit des „rassistischen Subjekts“ auseinanderfallen oder häufig unvermittelt nebeneinander stehen.
<G-vec00849-002-s033><diverge.auseinanderfallen><en> Summary In the literature on „racism“ it is striking that historic, economic and political analyses of this phenomenon on the one side and theories on the constitution of the „racist subject“ on the other diverge or often coexist rather unmediated.
