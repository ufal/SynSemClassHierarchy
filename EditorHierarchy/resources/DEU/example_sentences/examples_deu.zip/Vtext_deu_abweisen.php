<G-vec00555-002-s051><dismiss.abweisen><de> 45 Die Kommission beantragt, – die Klage abzuweisen; – der Klägerin die Kosten aufzuerlegen.
<G-vec00555-002-s051><dismiss.abweisen><en> 37 The Commission contends that the Court should: – dismiss the action; – order the applicants to pay the costs.
<G-vec00555-002-s052><dismiss.abweisen><de> Mit der vom Berufungsgericht zugelassenen Revision verfolgt der Beklagte seinen Antrag, die Klage abzuweisen, weiter.
<G-vec00555-002-s052><dismiss.abweisen><en> With the appeal approved by the Court of Appeal, the defendant continues to pursue its claim to dismiss the action.
<G-vec00555-002-s053><dismiss.abweisen><de> Bei unsinnigen Eingaben, beispielsweise die Eingabe eines Textes in ein Datumsfeld, ist es angemessen, diese Eingabe abzuweisen.
<G-vec00555-002-s053><dismiss.abweisen><en> Nonsensical input, for example, the input of text in a date field, it is appropriate to dismiss this entry.
<G-vec00555-002-s054><dismiss.abweisen><de> Diese Charakteristik wird nicht an ausgebildete Einheiten vergeben, weshalb es unklug sein mag, Freiwillige abzuweisen oder unsinnigerweise in den sicheren Tod zu schicken.
<G-vec00555-002-s054><dismiss.abweisen><en> This trait is never given to recruited units, so it may be unwise to dismiss such units or to send them to a foolish death.
<G-vec00050-002-s060><reject.abweisen><de> Durch den Spam-Filter können E-Mails abgewiesen werden, wenn diese durch bestimmte Merkmale fälschlich als Spam identifiziert wurden.
<G-vec00050-002-s060><reject.abweisen><en> The spam filter can reject e-mails if they have been identified as spam by certain features.
<G-vec00050-002-s061><reject.abweisen><de> Es ist möglich Ihren Browser durch Modifikation der Browser Einstellungen oder Referenzen so zu konfigurieren, dass Cookies abgewiesen werden.
<G-vec00050-002-s061><reject.abweisen><en> It is possible to configure your browser to reject cookies by modifying the browser settings or references.
<G-vec00050-002-s062><reject.abweisen><de> Kurz vor dem 10-jährigen Geburtstag des Alpenschutzartikels wird somit eine Aushöhlung des Alpenschutzes deutlich abgewiesen: Das Schweizer Volk will – im Gegensatz zu einer Mehrheit des Parlaments – nichts von einer zweiten Gotthardröhre wissen.
<G-vec00050-002-s062><reject.abweisen><en> Shortly before the 10th anniversary of the constitutional article for the protection of the Alps, the Swiss thus clearly reject an undermining of the protection of the Alps.
<G-vec00050-002-s063><reject.abweisen><de> Internet-Browser, bei denen JavaScript ausgeschaltet ist, werden dann abgewiesen.
<G-vec00050-002-s063><reject.abweisen><en> These pages reject browsers where JavaScript is deactivated.
<G-vec00050-002-s065><reject.abweisen><de> Sofern du das bevorzugst, kannst du deinen Browser normalerweise so einstellen, dass Cookies entfernt oder abgewiesen werden.
<G-vec00050-002-s065><reject.abweisen><en> If you prefer, you can usually choose to set your browser to remove or reject browser cookies.
<G-vec00050-002-s134><reject.abweisen><de> In der Regel wird Ihnen in der Menüleiste Ihres Webbrowsers über die Hilfe-Funktion angezeigt, wie Sie neue Cookies abweisen und bereits erhaltene löschen können.
<G-vec00050-002-s134><reject.abweisen><en> Usually it will appear in the menu bar of your web browser via the help function, how to reject new cookies and delete already received cookies.
<G-vec00050-002-s135><reject.abweisen><de> Sie müssen bewusst die höheren Ströme herbeiziehen und die niederen abweisen.
<G-vec00050-002-s135><reject.abweisen><en> You must consciously attract the higher currents and reject the lower ones.
<G-vec00050-002-s136><reject.abweisen><de> Bitte beachte aber, dass, wenn du dich für das Entfernen oder Abweisen von Cookies entscheidest, dies Einfluss haben kann auf die Verfügbarkeit oder Funktionalität unserer Dienste.
<G-vec00050-002-s136><reject.abweisen><en> Please note that if you choose to remove or reject cookies, this could affect the availability and functionality of our Services.
<G-vec00050-002-s137><reject.abweisen><de> Und er wird stets abweisen, was ihm von unlauterer geistiger Seite vermittelt werden möchte, denn es ist der Geist aus Gott, der in ihm wirket.
<G-vec00050-002-s137><reject.abweisen><en> And he will always reject what might be imparted to him from a dishonest spiritual side because it is the spirit out of God which has an effect in him.
<G-vec00050-002-s138><reject.abweisen><de> Bis zu 300 Stunden Stand-by (2) Anruf aus, den Anruf annehmen, den Anruf abweisen,den Anruf auflegen.
<G-vec00050-002-s138><reject.abweisen><en> Up to 300 hours standby Call out, call answer, call reject, call hang up.
<G-vec00050-002-s139><reject.abweisen><de> Shafer: Ich wusste, dass die Verteidigung Tierversuche abweisen würden, weil sie nicht auf Menschen angewendet werden können, genau wie Dr White es tat, mit den Tierversuchen zu Propofol im Urin.
<G-vec00050-002-s139><reject.abweisen><en> Dr. Steve Shafer: I knew that the defense would reject animal studies as not applying to humans, just as Paul White did when asked about animal studies of propofol in urine.
<G-vec00050-002-s140><reject.abweisen><de> Ihr seid erheblich im Vorteil gegenüber den Menschen, die nichts von Mir wissen, weil sie nichts aus Meiner Hand entgegennehmen wollen, die Meine Boten abweisen mit dem Gnadengeschenk von Mir, denen kein Licht leuchten kann, weil sie ihm entfliehen, und die darum auch Mich Selbst nicht erkennen lernen und denen das Erdenleben ein Leerlauf ist und bleiben wird, weil es finster ist in ihnen.
<G-vec00050-002-s140><reject.abweisen><en> You are considerably in advantage to those men, who know nothing about me, because they want to receive nothing from my hand, who reject my messengers with the gift of favour from me, to whom no light can shine, because they flee from it, and who for that reason also do not learn to get to know me myself and to whom earth life is and will remain idleness, because it is dark in them.
<G-vec00050-002-s141><reject.abweisen><de> Lehnet nicht ungeprüft ab, sondern bedenket, daß ihr ja eine große Gnadengabe abweisen könntet, und prüfet also daraufhin, was euch angeboten wird.
<G-vec00050-002-s141><reject.abweisen><en> Don't reject it without examination but bear in mind that you might well reject a great gift of grace, and therefore examine what you are offered.
<G-vec00050-002-s142><reject.abweisen><de> Wenn Sie ein Smartphone über Bluetooth mit Ihrem SPC Crow verbinden, können Sie Anrufe abweisen und entgegennehmen.
<G-vec00050-002-s142><reject.abweisen><en> If you connect a smartphone to your SPC Crow via Bluetooth, you can answer and reject calls.
<G-vec00050-002-s143><reject.abweisen><de> Sagen Sie "YES" zu beantworten und "NO" zum Abweisen von Anrufen (Für den normalen Gebrauch, bitte sprechen deutlich und laut).
<G-vec00050-002-s143><reject.abweisen><en> Feature: (Connect Two Devices at the Same Time)Say "Yes" to answer and "No" to reject calls(For normal use, please speak out clearly and loudly).
<G-vec00050-002-s144><reject.abweisen><de> Durch die Veränderung deiner Browser-Voreinstellungen kannst du die Annahme sämtlicher Cookies zulassen, dich informieren lassen, wenn ein Cookie gesetzt wird, oder sämtliche Cookies abweisen.
<G-vec00050-002-s144><reject.abweisen><en> By changing the preferences of your browser, the user can choose to accept all cookies, to be notified before accepting a cookie or to reject all cookies.
<G-vec00050-002-s145><reject.abweisen><de> Sie können ein Lied von Anfang an noch einmal hören, zu einem anderen Lied wechseln, pausieren oder jemanden anrufen, die letzte Nummer, die Sie angerufen hat, abweisen oder zurückrufen.
<G-vec00050-002-s145><reject.abweisen><en> You can listen to the same track again from the start, skip to another, pause or make a call, reject calls or call back the last number to phone you.
<G-vec00050-002-s146><reject.abweisen><de> Wenn niemand mehr rechnen wird mit einer Umgestaltung der Erde, wenn die Menschen jede Belehrung darüber abweisen, wenn sie nur rein irdisch und materiell alles Geschehen betrachten und den göttlichen Schöpfer unbeachtet lassen, d.h. jeden Zusammenhang des Schicksals der Menschen mit einem göttlichen Willen verneinen.... dann ist die Stunde nicht mehr fern, denn dann ist die Menschheit in dem Reifegrad angelangt, der das Ende bedingt.
<G-vec00050-002-s146><reject.abweisen><en> When no-one anticipates the transformation of earth any longer, when people reject all relevant information, when they look at all events from an entirely earthly and material point of view and ignore the divine Creator, i.e. when they negate every connection between humanity's fate and divine will.... then the hour is not far, because then humanity has reached the degree of maturity which causes the end.
<G-vec00050-002-s147><reject.abweisen><de> 6:26 Da ward der König sehr betrübt; doch um des Eides und um derer willen, die mit ihm zu Tische saßen, wollte er sie nicht abweisen.
<G-vec00050-002-s147><reject.abweisen><en> 6:26 And the king was exceeding sorry; but for the sake of his oaths, and of them that sat at meat, he would not reject her.
<G-vec00050-002-s148><reject.abweisen><de> Wenn besagte Anfrage offensichtlich unbegründet oder übermäßig ist oder wenn rechtmäßige Gründe für die Abweisung besagter Anfrage vorliegen, kann Prisma eine Anfrage abweisen und eine angemessene Vergütung für die Erfüllung einer Anfrage fordern.
<G-vec00050-002-s148><reject.abweisen><en> Prisma may reject a request, or obtain reasonable compensation for fulfilling a request, if said request is clearly unfounded or excessive or if there is a legitimate reason for rejecting the request.
<G-vec00050-002-s149><reject.abweisen><de> Denn obwohl sie ein körpereigener Stoff ist, würde die obere Hautschicht sie wie einen Eindringling abweisen.
<G-vec00050-002-s149><reject.abweisen><en> Even though it is an endogenous substance, the upper skin layer would reject it like an invader.
<G-vec00050-002-s150><reject.abweisen><de> Außerdem können Sie mit nur einem Knopfdruck auf das Fitness Armband jeden Anruf abweisen.
<G-vec00050-002-s150><reject.abweisen><en> Furthermore, you can also reject any call just at the touch of a button of the fitness wristband.
<G-vec00050-002-s171><reject.abweisen><de> Um einen Anruf zu beenden oder abzuweisen, drücken Sie auf die Beendigungstaste.
<G-vec00050-002-s171><reject.abweisen><en> Answer or reject a call To answer a call, press the call key.
<G-vec00050-002-s172><reject.abweisen><de> Wenn Ihre Browser konfiguriert sind, um Cookies abzuweisen, kann es zudem der Fall sein, dass Ihre Wahl der Opt-out-Optionen auf den Websites von DAA oder NAI nicht wirksam ist.
<G-vec00050-002-s172><reject.abweisen><en> Also, if your browsers are configured to reject Cookies when you opt out on the DAA or NAI websites, your opt out may not be effective.
<G-vec00050-002-s173><reject.abweisen><de> Die Praxis der rumänischen Gerichte besteht darin, die Restitutionsfälle abzuweisen, wobei sie sie bis zur endgültigen Regelung der Ansprüche durch die lokalen Behörden, welche im Rahmen der oben erwähnten restriktiven Bedingungen zu lösen sind, für verfrüht erklären.
<G-vec00050-002-s173><reject.abweisen><en> The practice of the Romanian courts is that they reject the restitution claims, declaring them premature pending final settlement of the claims by the local authorities which have to be solved under the restrictive conditions mentioned above.
<G-vec00050-002-s174><reject.abweisen><de> Sie können alternativ auch drücken, um den Anruf direkt abzuweisen.
<G-vec00050-002-s174><reject.abweisen><en> Alternatively, press to reject the call directly. 2.
<G-vec00050-002-s175><reject.abweisen><de> Clipper hat das Recht, einen Auftrag bis kurz vor Lieferung abzuweisen, wenn der Vorverkauf des betreffenden Dessins zu gering ist, oder wenn keine zufriedenstellende Kreditauskunft über den Kunde vorliegt.
<G-vec00050-002-s175><reject.abweisen><en> Clipper shall be entitled to reject any order up to the time of delivery in case of inadequate sales of the design ordered or if satisfactory credit information about the customer cannot be obtained.
<G-vec00050-002-s176><reject.abweisen><de> Eine ungemein irrige Annahme ist es, das geschriebene Wort Gottes für abgeschlossen zu halten und jegliche göttlichen Offenbarungen als Machwerk böser Kräfte abzuweisen.
<G-vec00050-002-s176><reject.abweisen><en> It is a serious mistake to assume that God's Word is completed and to reject every divine revelation as fabrication of evil forces.
<G-vec00050-002-s177><reject.abweisen><de> –Halten Sie während des Klingelns die Taste „Rufannahme/ Beenden“ gedrückt, um einen eingehenden Anruf abzuweisen..
<G-vec00050-002-s177><reject.abweisen><en> -Press and hold the Answer/End button when the phone rings to reject an incoming call..
<G-vec00050-002-s178><reject.abweisen><de> Und die Entscheidung, welche Information aufzunehmen oder abzuweisen ist, welches Gen zu aktivieren oder stillzulegen ist, trifft unsere INNERE EINSTELLUNG.
<G-vec00050-002-s178><reject.abweisen><en> The decision to accept or reject information, to activate a gene or shut it down, is prompted by our ATTITUDE.
<G-vec00050-002-s179><reject.abweisen><de> Der Besitzer ist berechtigt, die überzähligen Personen abzuweisen oder einen Aufpreis zu berechnen.
<G-vec00050-002-s179><reject.abweisen><en> The owner is entitled to reject the surplus people or compute a surcharge.
<G-vec00050-002-s180><reject.abweisen><de> Aufgrund der regulatorischen Erfordernisse ist das Unternehmen berechtigt, sämtliche Kreditkartenzahlungen aus Regionen mit hohem Risiko abzuweisen.
<G-vec00050-002-s180><reject.abweisen><en> Due to regulatory requirements, the Company has the right to reject any credit card payments coming from high-risk regions.
<G-vec00050-002-s398><reject.abweisen><de> Dabei weisen wir die Idee ab, daß das Glauben an Gott unlogisch ist.
<G-vec00050-002-s398><reject.abweisen><en> At the same time, we reject the idea that belief in God is illogical.
<G-vec00050-002-s399><reject.abweisen><de> Die sehr feinen, gleichmäßigen und leicht zu reinigenden Fugenoberflächen bieten einen Abperleffekt und weisen Wasser sowie Schmutzpartikel ab.
<G-vec00050-002-s399><reject.abweisen><en> The very fine, smooth and easy to clean joint surfaces offer a lotus effect and reject water and dirt.
<G-vec00050-002-s400><reject.abweisen><de> Filter wie INCLUDES oder PHP sind gleich oben im Core-Handler implementiert und weisen deshalb Requests mit PATH_INFO ab.
<G-vec00050-002-s400><reject.abweisen><en> Filters such as INCLUDES or PHP are implemented on top of the core handler, and therefore reject requests with PATH_INFO.
<G-vec00050-002-s401><reject.abweisen><de> Mithin stehen Kritik und Masse auf derselben Basis: beide kämpfen gegen den Egoismus, beide weisen ihn von sich ab, und schieben ihn einander zu.
<G-vec00050-002-s401><reject.abweisen><en> Therefore criticism and the masses stand on the same basis: both fight against egoism, both reject it for themselves and shift the blame for it to the other.
