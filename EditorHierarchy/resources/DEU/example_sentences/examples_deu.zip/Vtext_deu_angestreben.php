<G-vec00256-002-s038><aim.angestreben><de> Der Kommandant der Küstenwache machte hingegen deutlich, was durch die Zusammenarbeit eigentlich angestrebt wird: der „Kampf gegen irreguläre Migration“ – also Geflüchtete daran zu hindern, über die Ägäis auf die griechischen Inseln zu gelangen.
<G-vec00256-002-s038><aim.angestreben><en> The commander of the coast guard made clear, however, what the actual aim of the cooperation is: “the fight against irregular migration” – which means preventing refugees from getting to the Greek islands via the Aegean.
<G-vec00256-002-s039><aim.angestreben><de> Des Weiteren wurde angestrebt, dass sich die neue Handling-Lösung innerhalb einer Schicht mehrmals mit wenigen Handgriffen von der einen auf die andere Kartongröße umrüsten lässt – und das möglichst schnell und einfach.
<G-vec00256-002-s039><aim.angestreben><en> In addition, the aim was to find a new handling solution that could be converted from one box size to another several times in one shift in just a few steps – as quickly and easily as possible.
<G-vec00256-002-s040><aim.angestreben><de> Zuerst wird die Auflösung der Phase angestrebt.
<G-vec00256-002-s040><aim.angestreben><en> 1) The initial aim is to dissolve the phase.
<G-vec00256-002-s041><aim.angestreben><de> Angestrebt wird eine deutliche Erhöhung des Anteils von Frauen in Forschung und Lehre.
<G-vec00256-002-s041><aim.angestreben><en> The aim is to significantly increase the proportion of women in research and teaching.
<G-vec00256-002-s042><aim.angestreben><de> Die Anwendung eines pulmonalarterien Banding (PAB) ist heute eher als Ausnahme anzusehen, da – wenn immer möglich – eine primäre Korrektur angestrebt wird.
<G-vec00256-002-s042><aim.angestreben><en> Pulmonary Artery Banding Indication The application of pulmonary artery banding (PAB) is today the exception since, whenever possible, primary correction is the preferred aim.
<G-vec00256-002-s043><aim.angestreben><de> Zu diesem Zeitpunkt wurde angestrebt, das Observatorium Ende 2001 in Betrieb zu nehmen.
<G-vec00256-002-s043><aim.angestreben><en> At this time, the aim was for the observatory to be operational by the end of 2001.
<G-vec00256-002-s044><aim.angestreben><de> Ferner wird auch eine bessere Abstimmung der Innovationstätigkeit im Energiebereich auf nationaler, regionaler und lokaler Ebene im Hinblick auf die Schaffung einer gemeinsamen strategischen Agenda zu den energiepolitischen Prioritäten angestrebt.
<G-vec00256-002-s044><aim.angestreben><en> It will also aim to better align innovation activities in the field of energy at national, regional and local level with a view to setting up a joint strategic agenda on energy priorities.
<G-vec00256-002-s045><aim.angestreben><de> Aktuell wird der Erhalt der Geschützten Geografischen Angabe (IGP oder GGA) «Absinthe du Val-de-Travers» für dieses Regionalprodukt angestrebt.
<G-vec00256-002-s045><aim.angestreben><en> Their current aim is to obtain the PGI "Absinthe du Val-de-Travers" for this local product.
<G-vec00256-002-s046><aim.angestreben><de> Dabei wird eine möglichst vollständige Erfassung aller Umweltwirkungen angestrebt, damit allfällige Verschiebungen von Umweltbelastungen erkannt werden können.
<G-vec00256-002-s046><aim.angestreben><en> Here we aim for as complete a recording of all environmental impacts as possible, so that any shifts in the latter can be recognised.
<G-vec00256-002-s047><aim.angestreben><de> Im Rahmen der EU-Politik zur Bekämpfung des Menschenhandels sollte ein speziell auf die Rechte des Kindes ausgerichtetes Konzept angestrebt werden, das sich auf weltweit anerkannte Prinzipien stützt.
<G-vec00256-002-s047><aim.angestreben><en> The EU’s policy in this area should aim for a child’s rights approach based on internationally recognised principles.
<G-vec00256-002-s048><aim.angestreben><de> Sie alle zeichnen sich durch Leichtigkeit und Tragbarkeit aus, und bei den anspruchsvollsten Designs wird ein Höchstmaß an Ergonomie angestrebt.
<G-vec00256-002-s048><aim.angestreben><en> All of them share lightness and portability, and in the most sophisticated designs all aim at a level of ergonomics…
<G-vec00256-002-s049><aim.angestreben><de> Da immer ein möglichst energiearmer Zustand angestrebt wird, ist eine Minimierung der Grenzflächenenergie angestrebt, also eine Minimierung der spezifischen Oberfläche, was zu Kornwachstum führt.
<G-vec00256-002-s049><aim.angestreben><en> As the aim is to maintain a state of the lowest possible energy at all times, a minimisation of the interface energy (i.e. a minimised specific surface area) is desirable, which will encourage grain growth.
<G-vec00256-002-s050><aim.angestreben><de> Angestrebt ist die Verwendung von Bauteilen der Trockenkupplung.
<G-vec00256-002-s050><aim.angestreben><en> The aim is to use the components of a dry clutch.
<G-vec00256-002-s051><aim.angestreben><de> Angestrebt wird der Lückenschluss im Wirtschaftsraum zwischen den Büros in Linz und Basel.
<G-vec00256-002-s051><aim.angestreben><en> The aim is to close the gap in the economic area between the offices in Linz and Basel.
<G-vec00256-002-s052><aim.angestreben><de> Angestrebt wird eine möglichst große Bandbreite.
<G-vec00256-002-s052><aim.angestreben><en> The aim is to build as large a bandwidth as possible.
<G-vec00256-002-s053><aim.angestreben><de> Mit Blick auf das Jahr 2050 wird angestrebt, den Stromverbrauch gegenüber 2008 absolut um 25 % zu reduzieren und den Bruttostromverbrauch zu maximal 20 % aus fossilen Energieträgern zu decken.
<G-vec00256-002-s053><aim.angestreben><en> The aim for 2050 is to reduce electricity consumption by 25% in absolute terms (from 2008) and to cover a maximum of 20% of gross electricity consumption from fossil fuels.
<G-vec00256-002-s054><aim.angestreben><de> Die deutsche Entwicklungspolitik orientiert sich dabei an den Grundsätzen der sozialen und ökologischen Marktwirtschaft: Neben guten wirtschaftlichen, politischen und sozialen Lebensbedingungen für die Menschen wird auch die langfristige Sicherung der natürlichen Lebensgrundlagen angestrebt.
<G-vec00256-002-s054><aim.angestreben><en> German development policy takes its lead from the principles of the social and ecological market economy. As well as ensuring sound economic, political and social living conditions for the population, measures aim to conserve the natural resource base on which life depends for the generations to come.
<G-vec00256-002-s055><aim.angestreben><de> Als Ergebnis werden fundiert ausgebildete TechnikerInnen / FacharbeiterInnen angestrebt, die im Bereich thermische Sanierung von Gebäuden sowohl praktisches als auch theoretisches Wissen aufweisen.
<G-vec00256-002-s055><aim.angestreben><en> Aim of the courses is to have well-trained engineers and technicians with practical and theoretical knowledge in the field of thermal renovation of buildings.
<G-vec00256-002-s056><aim.angestreben><de> Eine Fortsetzung des Forschungsprojektes im Rahmen einer Masterthesis wird angestrebt.
<G-vec00256-002-s056><aim.angestreben><en> The aim is to continue the research project in the scope of the master thesis.
