<G-vec00840-002-s054><wash.abwaschen><de> Wenn der Scheibenwischer den Regen nicht gut abwaschen kann, besteht große Gefahr für Ihre Fahrsicherheit.
<G-vec00840-002-s054><wash.abwaschen><en> If the wiper can not well wash off the rain, it will bring great danger to your driving safety.
<G-vec00840-002-s055><wash.abwaschen><de> Mit viel Wasser abwaschen.
<G-vec00840-002-s055><wash.abwaschen><en> Wash it down with plenty of water.
<G-vec00840-002-s056><wash.abwaschen><de> Abwaschen muss man zwar von Hand, aber das ist kein Problem, weil: Man hat ja Zeit.
<G-vec00840-002-s056><wash.abwaschen><en> Wash one must indeed by hand, but this is not a problem because: You have plenty of time.
<G-vec00840-002-s057><wash.abwaschen><de> Mich ekelte vor diesem Ort, von dem weder Wasser noch der Lauf der Jahre das Blut abwaschen konnten.
<G-vec00840-002-s057><wash.abwaschen><en> I abhorred that place from which neither water nor years could wash the blood off.
<G-vec00840-002-s058><wash.abwaschen><de> Nach der Verwendung mit warmem Seifenwasser abwaschen.
<G-vec00840-002-s058><wash.abwaschen><en> After use wash off with warm soapy water.
<G-vec00840-002-s059><wash.abwaschen><de> Eine Außendusche sorgt dafür, dass Sie vor dem Baden das Sonnenöl und danach das Salz abwaschen können.
<G-vec00840-002-s059><wash.abwaschen><en> A shower by the pool allows you to wash off the sun oil before bathing and the slight salt afterwards.
<G-vec00840-002-s060><wash.abwaschen><de> 10 bis 15 Minuten einwirken lassen und dann mit lauwarmem Wasser abwaschen oder einem feuchten Tuch oder Kosmetikschwamm abnehmen.
<G-vec00840-002-s060><wash.abwaschen><en> Allow to soak for 10 to 15 minutes and then wash off with lukewarm water or remove using a moist cloth or a cosmetic sponge.
<G-vec00840-002-s061><wash.abwaschen><de> Auf die Karte ihres älteren Bruders schrieb sie, daß sie einmal für ihn das Geschirr abwaschen wollte.
<G-vec00840-002-s061><wash.abwaschen><en> On her older brother’s card, she wrote that she would wash the dishes one night when it was his turn.
<G-vec00840-002-s062><wash.abwaschen><de> Wenn plötzlich Symptome auftreten, die Sie alarmieren: Rötung, brennendes Gefühl, sollten Sie sofort die Creme abwaschen und Ihren Arzt aufsuchen.
<G-vec00840-002-s062><wash.abwaschen><en> If suddenly there were symptoms that alarmed you: redness, burning sensation, should immediately to wash off the cream and contact your doctor.
<G-vec00840-002-s063><wash.abwaschen><de> Beachten Sie, dass das Wasser zwischen 29 ° C und 32 ° C liegt und in das Meer fließt, wodurch eine warme Bademöglichkeit und Schlammbäder entstehen, in denen Sie Ihre Haut bedecken, trocknen lassen und anschließend abwaschen können, um die therapeutischen Eigenschaften zu maximieren.
<G-vec00840-002-s063><wash.abwaschen><en> Take note that the water is around 29oC to 32oC and it flows into the sea creating a warm bathing opportunity and mud baths that you can cover your skin, let dry and then wash off for maximizing its therapeutic properties. Poyraz Bay
<G-vec00840-002-s064><wash.abwaschen><de> Wenn ein Mensch nach einem Besuch auf der Toilette die Hygienevorschriften nicht beachtet und sich nicht mit Handseife abwaschen lässt, ist die Wahrscheinlichkeit, Lebensmittel zu infizieren, sehr hoch.
<G-vec00840-002-s064><wash.abwaschen><en> If after a visit to the toilet a person does not observe the rules of hygiene and does not wash with hand soap, the probability of infecting food is very high.
<G-vec00840-002-s065><wash.abwaschen><de> Nach dem Bad werden Sie auf einen Futon gelegt und bekommen ein reinigendes, natürliches Ganzkörper-Zuckerpeeling und ein wiederholtes Abwaschen in der Badewanne.
<G-vec00840-002-s065><wash.abwaschen><en> After the bath you will be laid on a futon and you will receive gentle, fragrant sugar scrub all over your body, which you will wash down again in rose bath.
<G-vec00840-002-s066><wash.abwaschen><de> Bei Berührung mit der Haut mit Wasser und Seife abwaschen.
<G-vec00840-002-s066><wash.abwaschen><en> Thoroughly wash skin with soap and water.
<G-vec00840-002-s067><wash.abwaschen><de> Mit viel Wasser oder Wasser und Seife abwaschen.
<G-vec00840-002-s067><wash.abwaschen><en> Wash off with soap and plenty of water.
<G-vec00840-002-s068><wash.abwaschen><de> 9.Und Eingeweide und Fußstücke soll man mit Wasser abwaschen, und der Priester lasse das alles in Dampf aufgehen auf dem Altar, als Ganzopfer, ein Feueropfer des Wohlgeruchs für HaSchem.
<G-vec00840-002-s068><wash.abwaschen><en> 9 But his inwards and his legs shall he wash in water: and the priest shall burn all on the altar, to be a burnt sacrifice, an offering made by fire, of a sweet savour unto the LORD.
<G-vec00840-002-s069><wash.abwaschen><de> Vor dem ersten Gebrauch: Das Kochgeschirr in heißem Wasser mit einer milden Seife oder einem milden Spülmittel abwaschen.
<G-vec00840-002-s069><wash.abwaschen><en> Before first use, wash your new cookware in hot water with a mild soap or dish detergent.
<G-vec00840-002-s070><wash.abwaschen><de> Sofort mit Wasser und Seife abwaschen und gut nachspülen.
<G-vec00840-002-s070><wash.abwaschen><en> Wash off immediately with soap and water and rinse thoroughly.
<G-vec00840-002-s071><wash.abwaschen><de> Bei Berührung mit Batterieflüssigkeit sofort mit Wasser und Seife abwaschen.
<G-vec00840-002-s071><wash.abwaschen><en> In case of contact with battery acid wash it off immediately with soap and water.
<G-vec00840-002-s072><wash.abwaschen><de> Jetzt kann man das Salz abwaschen und den Fisch auf das Gitter des Räuchergeräts legen.
<G-vec00840-002-s072><wash.abwaschen><en> Now wash off the salt and layer the fish on the lattice.
<G-vec00840-002-s073><wash.abwaschen><de> Wenn es soweit ist, haben Sie etwas Zeit, um zu duschen, saubere Kleidung anzuziehen, Nägel zu schneiden und den Lack abzuwaschen (eine Maniküre verhindert, dass Sie sich um das Baby kümmern).
<G-vec00840-002-s073><wash.abwaschen><en> When it comes, you will have a little time to take a shower, put on clean clothes, cut your nails and wash off the varnish (a manicure will stop you from taking care of the baby).
<G-vec00840-002-s074><wash.abwaschen><de> Die Hornhaut nochmals mit Rubbelcreme massieren und die Füße wieder ins Becken stellen, um abgestorbene Haut einfach abzuwaschen.
<G-vec00840-002-s074><wash.abwaschen><en> Massage callouses again with a Smoothing Scrub Cream, and replace feet in the basin to easily wash off any dead skin.
<G-vec00840-002-s075><wash.abwaschen><de> Einfach abzuwaschen.
<G-vec00840-002-s075><wash.abwaschen><en> Easy to wash off.
<G-vec00840-002-s076><wash.abwaschen><de> Wir bitten Sie, gebrauchtes Geschirr abzuwaschen und den Müll selbst zu entsorgen.
<G-vec00840-002-s076><wash.abwaschen><en> We ask you to wash used dishes and to dispose your garbage.
<G-vec00840-002-s077><wash.abwaschen><de> Die lange schreibt nämlich, und die kurze spritzt Wasser aus, um das Blut abzuwaschen und die Schrift immer klar zu erhalten.
<G-vec00840-002-s077><wash.abwaschen><en> The long one inscribes, and the short one squirts water out to wash away the blood and keep the inscription always clear.
<G-vec00840-002-s078><wash.abwaschen><de> Weiter empfehlen wir, die Handschuhe immer gut zu lüften, nicht feucht oder nass zu verpacken und Schmutz regelmäßig mit einem feuchten Tuch abzuwaschen.
<G-vec00840-002-s078><wash.abwaschen><en> Further, we recommend gloves to be properly ventilated, avoid packing them if damp or wet, and regularly wash dirt away with a damp cloth.
<G-vec00840-002-s079><wash.abwaschen><de> Wenn zu Hause ein Säugling warmes Wasser hat, ist es am besten, es abzuwaschen, um die Urinreste von der Haut (4-6 mal am Tag) und nach der Defäkation zu entfernen; manchmal ist es genug einfaches sauberes Wasser, manchmal müssen Sie Babyseife oder Gel benutzen.
<G-vec00840-002-s079><wash.abwaschen><en> At home, if there is warm water in a nursing baby, it is best to wash it off to remove the remains of urine from the skin (4-6 times a day) and after defecation; sometimes it is enough simple clean water, sometimes you have to use baby soap or gel.
<G-vec00840-002-s080><wash.abwaschen><de> Verzweifeln Sie nicht, wenn die erste Annäherung nicht zugelassen hat, die Flecke von der Haut abzuwaschen.
<G-vec00840-002-s080><wash.abwaschen><en> Do not despair if the first approach has not allowed to wash off the stains from the skin.
<G-vec00840-002-s081><wash.abwaschen><de> Um eine Maske abzuwaschen folgt mit der Anwendung von Shampoo, zum Spülen der Haare nach dem Waschen ist es gut, mit einem Zitronensaft Wasser angesäuert zu verwenden.
<G-vec00840-002-s081><wash.abwaschen><en> To wash off a mask follows with application of shampoo, for rinsing hair after washing it is good to use acidified with a lemon juice water.
<G-vec00840-002-s082><wash.abwaschen><de> All das Gerede, das man braucht, um sich in Lumpen zu kleiden, das Make-up abzuwaschen und nicht in die Augen zu fallen, lässt die Gewissensberater auf dem Gewissen.
<G-vec00840-002-s082><wash.abwaschen><en> All the talk that you need to dress in rags, wash off the makeup and not fall into anyone's eyes leave the conscience advisers on your conscience.
<G-vec00840-002-s083><wash.abwaschen><de> Die Ballen hat unbegrenzte WIFI, eine Waschmaschine, einen Fernseher mit Flachbildschirm, DVD-Player, DVD, s, Bücher, zusätzliche Decken, Ventilatoren, Gas und elektrische Heizung, einige Spiele und eine gute, starke, heiße Dusche, das Salz und Sand abzuwaschen nach einem Tag am Strand oder einer Wanderung in den regen Wald.
<G-vec00840-002-s083><wash.abwaschen><en> The Bales has unlimited WIFI, a washing machine, flat screen TV, DVD player, DVD,s, books, extra blankets, fans, gas and electric heating, some games and a good, strong, hot shower to wash off the salt and sand after a day at the beach or a hike in the rain forest.
<G-vec00840-002-s084><wash.abwaschen><de> Der Fehler/die Schwäche/die Unzulänglichkeit ist, dass man zu faul war, um das Geschirr abzuwaschen und es über Nacht in der Spüle hat stehen lassen.
<G-vec00840-002-s084><wash.abwaschen><en> The mistake / shortcoming is that one felt lazy to wash the dishes and had left them in the sink overnight.
<G-vec00840-002-s085><wash.abwaschen><de> YAHUSHUA wurde als makelloses heiliges Lamm gegeben um die Sünden der Menschen abzuwaschen; und genau diese Menschen, die das Blut beanspruchen, diese tun sündhafte Abscheulichkeiten, das Böse ist hinter dem Schweinestall.
<G-vec00840-002-s085><wash.abwaschen><en> YAHUSHUA was given as a flawless sacrificial lamb to wash away the sins of man; and yet now these people who claimed that blood, now do sinful abominations, even evil behind the pulpits.
<G-vec00840-002-s086><wash.abwaschen><de> In der restlichen Zeit kann das Baby mit Gemüse, Fleischpüree oder Brei (je nach Alter) gefüttert werden, wobei jedes Mal angeboten wird, die ausgedrückte Milch abzuwaschen.
<G-vec00840-002-s086><wash.abwaschen><en> In the rest of the time the baby can be given vegetable, meat puree or porridge (depending on the age), each time offering to wash down their expressed milk.
<G-vec00840-002-s087><wash.abwaschen><de> Die offensichtlichste Lösung ist, das Salz mit reinem Wasser abzuwaschen.
<G-vec00840-002-s087><wash.abwaschen><en> The most obvious solution is to wash away the salt by using pure water.
<G-vec00840-002-s088><wash.abwaschen><de> Vergessen Sie nicht, alle Cremereste von den Händen abzuwaschen.
<G-vec00840-002-s088><wash.abwaschen><en> Don't forget to wash any cream off your hands.
<G-vec00840-002-s089><wash.abwaschen><de> In diesem Fall wird das Öl für etwa eine halbe Stunde von der Haut erwärmt und geschmiert, danach ist es notwendig, alles mit warmem Wasser abzuwaschen.
<G-vec00840-002-s089><wash.abwaschen><en> In this case, the oil is heated and lubricated by the skin for about half an hour, after which it is necessary to wash everything off with the help of warm water.
<G-vec00840-002-s090><wash.abwaschen><de> Als sie kicherten und den fremden Mann verstohlen ansahen, unterhielten sie sich fröhlich und der Prinz hörte, dass die Mädchen das Wasser für die letzte Waschungszeremonie von Manora nahmen, um den Makel des menschlichen Kontakts abzuwaschen.
<G-vec00840-002-s090><wash.abwaschen><en> As they giggled and glanced surreptitiously at the strange man, they chatted gaily amongst themselves and the prince overheard that the maidens were taking the water for the final ablution ceremony of Manora to wash away the taint of human contact.
<G-vec00840-002-s091><wash.abwaschen><de> Es ist notwendig, nach dem Entfernen des Pfropfens mit Mitteln, die einen neutralen pH-Wert enthalten, abzuwaschen.
<G-vec00840-002-s091><wash.abwaschen><en> It is necessary to wash off after the removal of the plug with means containing a neutral pH level.
<G-vec00923-002-s054><wash_away.abwaschen><de> Wenn der Scheibenwischer den Regen nicht gut abwaschen kann, besteht große Gefahr für Ihre Fahrsicherheit.
<G-vec00923-002-s054><wash_away.abwaschen><en> If the wiper can not well wash off the rain, it will bring great danger to your driving safety.
<G-vec00923-002-s055><wash_away.abwaschen><de> Mit viel Wasser abwaschen.
<G-vec00923-002-s055><wash_away.abwaschen><en> Wash it down with plenty of water.
<G-vec00923-002-s056><wash_away.abwaschen><de> Abwaschen muss man zwar von Hand, aber das ist kein Problem, weil: Man hat ja Zeit.
<G-vec00923-002-s056><wash_away.abwaschen><en> Wash one must indeed by hand, but this is not a problem because: You have plenty of time.
<G-vec00923-002-s057><wash_away.abwaschen><de> Mich ekelte vor diesem Ort, von dem weder Wasser noch der Lauf der Jahre das Blut abwaschen konnten.
<G-vec00923-002-s057><wash_away.abwaschen><en> I abhorred that place from which neither water nor years could wash the blood off.
<G-vec00923-002-s058><wash_away.abwaschen><de> Nach der Verwendung mit warmem Seifenwasser abwaschen.
<G-vec00923-002-s058><wash_away.abwaschen><en> After use wash off with warm soapy water.
<G-vec00923-002-s059><wash_away.abwaschen><de> Eine Außendusche sorgt dafür, dass Sie vor dem Baden das Sonnenöl und danach das Salz abwaschen können.
<G-vec00923-002-s059><wash_away.abwaschen><en> A shower by the pool allows you to wash off the sun oil before bathing and the slight salt afterwards.
<G-vec00923-002-s060><wash_away.abwaschen><de> 10 bis 15 Minuten einwirken lassen und dann mit lauwarmem Wasser abwaschen oder einem feuchten Tuch oder Kosmetikschwamm abnehmen.
<G-vec00923-002-s060><wash_away.abwaschen><en> Allow to soak for 10 to 15 minutes and then wash off with lukewarm water or remove using a moist cloth or a cosmetic sponge.
<G-vec00923-002-s061><wash_away.abwaschen><de> Auf die Karte ihres älteren Bruders schrieb sie, daß sie einmal für ihn das Geschirr abwaschen wollte.
<G-vec00923-002-s061><wash_away.abwaschen><en> On her older brother’s card, she wrote that she would wash the dishes one night when it was his turn.
<G-vec00923-002-s062><wash_away.abwaschen><de> Wenn plötzlich Symptome auftreten, die Sie alarmieren: Rötung, brennendes Gefühl, sollten Sie sofort die Creme abwaschen und Ihren Arzt aufsuchen.
<G-vec00923-002-s062><wash_away.abwaschen><en> If suddenly there were symptoms that alarmed you: redness, burning sensation, should immediately to wash off the cream and contact your doctor.
<G-vec00923-002-s063><wash_away.abwaschen><de> Beachten Sie, dass das Wasser zwischen 29 ° C und 32 ° C liegt und in das Meer fließt, wodurch eine warme Bademöglichkeit und Schlammbäder entstehen, in denen Sie Ihre Haut bedecken, trocknen lassen und anschließend abwaschen können, um die therapeutischen Eigenschaften zu maximieren.
<G-vec00923-002-s063><wash_away.abwaschen><en> Take note that the water is around 29oC to 32oC and it flows into the sea creating a warm bathing opportunity and mud baths that you can cover your skin, let dry and then wash off for maximizing its therapeutic properties. Poyraz Bay
<G-vec00923-002-s064><wash_away.abwaschen><de> Wenn ein Mensch nach einem Besuch auf der Toilette die Hygienevorschriften nicht beachtet und sich nicht mit Handseife abwaschen lässt, ist die Wahrscheinlichkeit, Lebensmittel zu infizieren, sehr hoch.
<G-vec00923-002-s064><wash_away.abwaschen><en> If after a visit to the toilet a person does not observe the rules of hygiene and does not wash with hand soap, the probability of infecting food is very high.
<G-vec00923-002-s065><wash_away.abwaschen><de> Nach dem Bad werden Sie auf einen Futon gelegt und bekommen ein reinigendes, natürliches Ganzkörper-Zuckerpeeling und ein wiederholtes Abwaschen in der Badewanne.
<G-vec00923-002-s065><wash_away.abwaschen><en> After the bath you will be laid on a futon and you will receive gentle, fragrant sugar scrub all over your body, which you will wash down again in rose bath.
<G-vec00923-002-s066><wash_away.abwaschen><de> Bei Berührung mit der Haut mit Wasser und Seife abwaschen.
<G-vec00923-002-s066><wash_away.abwaschen><en> Thoroughly wash skin with soap and water.
<G-vec00923-002-s067><wash_away.abwaschen><de> Mit viel Wasser oder Wasser und Seife abwaschen.
<G-vec00923-002-s067><wash_away.abwaschen><en> Wash off with soap and plenty of water.
<G-vec00923-002-s068><wash_away.abwaschen><de> 9.Und Eingeweide und Fußstücke soll man mit Wasser abwaschen, und der Priester lasse das alles in Dampf aufgehen auf dem Altar, als Ganzopfer, ein Feueropfer des Wohlgeruchs für HaSchem.
<G-vec00923-002-s068><wash_away.abwaschen><en> 9 But his inwards and his legs shall he wash in water: and the priest shall burn all on the altar, to be a burnt sacrifice, an offering made by fire, of a sweet savour unto the LORD.
<G-vec00923-002-s069><wash_away.abwaschen><de> Vor dem ersten Gebrauch: Das Kochgeschirr in heißem Wasser mit einer milden Seife oder einem milden Spülmittel abwaschen.
<G-vec00923-002-s069><wash_away.abwaschen><en> Before first use, wash your new cookware in hot water with a mild soap or dish detergent.
<G-vec00923-002-s070><wash_away.abwaschen><de> Sofort mit Wasser und Seife abwaschen und gut nachspülen.
<G-vec00923-002-s070><wash_away.abwaschen><en> Wash off immediately with soap and water and rinse thoroughly.
<G-vec00923-002-s071><wash_away.abwaschen><de> Bei Berührung mit Batterieflüssigkeit sofort mit Wasser und Seife abwaschen.
<G-vec00923-002-s071><wash_away.abwaschen><en> In case of contact with battery acid wash it off immediately with soap and water.
<G-vec00923-002-s072><wash_away.abwaschen><de> Jetzt kann man das Salz abwaschen und den Fisch auf das Gitter des Räuchergeräts legen.
<G-vec00923-002-s072><wash_away.abwaschen><en> Now wash off the salt and layer the fish on the lattice.
