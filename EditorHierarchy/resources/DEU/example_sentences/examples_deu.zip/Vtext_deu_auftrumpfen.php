<G-vec00418-002-s026><crow.auftrumpfen><de> Auftrumpfen kann das Notebook auch mit seinen umfangreichen Sicherheitsfeatures wie Fingerprint Reader, TPM-Chip und SmartCard Reader.
<G-vec00418-002-s026><crow.auftrumpfen><en> The notebook computer can crow also with his extensive security features like Fingerprint reader, TPM chip and SmartCard reader.
