<G-vec00847-002-s069><drain.abgießen><de> Kartoffeln abgießen, kurz ausdampfen lassen.
<G-vec00847-002-s069><drain.abgießen><en> Drain potatoes and allow the steam to evaporate.
<G-vec00847-002-s070><drain.abgießen><de> Sobald die Kartoffeln und der Spargel gar sind, jeweils das Wasser abgießen und sofort mit der Avocado-Hollandaise servieren.
<G-vec00847-002-s070><drain.abgießen><en> Once the asparagus and potatoes are ready, drain the water and serve immediately with the avocado hollandaise.
<G-vec00847-002-s071><drain.abgießen><de> In leicht gesalzenem Wasser 2 - 3 Minuten ankochen, bis er fest ist, dann abgießen.
<G-vec00847-002-s071><drain.abgießen><en> Parboil the tofu in lightly salted water for 2-3 minutes until firm, then drain.
<G-vec00847-002-s072><drain.abgießen><de> Die Kartoffeln abgießen.
<G-vec00847-002-s072><drain.abgießen><en> Drain the potatoes.
<G-vec00847-002-s073><drain.abgießen><de> In der Zwischenzeit die Spaghetti kochen und abgießen.
<G-vec00847-002-s073><drain.abgießen><en> Boil the fettuccine until cooked, remove and drain.
<G-vec00847-002-s074><drain.abgießen><de> Die Zubereitung der Füllung: Den Weizen vom Kochwasser abgießen, wieder in die Kasserolle geben, die Milch darübergießen und zwei Zitronenschalen, eine Prise Zimt, einen Esslöffel Zucker und eine Prise Salz zugeben.
<G-vec00847-002-s074><drain.abgießen><en> Prepare the filling: drain the wheat from its cooking water, replace it in the casserole dish, pour the milk over it and add two pieces of lemon zest, a pinch of cinnamon, one tablespoon of sugar and a pinch of salt.
<G-vec00847-002-s075><drain.abgießen><de> Das Fett in eine hitzebeständige Schüssel abgießen.
<G-vec00847-002-s075><drain.abgießen><en> Drain the oil from the pan.
<G-vec00847-002-s076><drain.abgießen><de> Rote Bete in kochendem Salzwasser 40-45 Minuten garen, abgießen und in kaltem Wasser auskühlen lassen.
<G-vec00847-002-s076><drain.abgießen><en> Preparation: Cook beetroots in boiling salt water for 40-45 minutes, drain and let cool in cold water.
<G-vec00847-002-s077><drain.abgießen><de> Die Mungbohnensprossen hinzugeben und die Bouillon sofort abgießen.
<G-vec00847-002-s077><drain.abgießen><en> Add the bean sprouts and immediately drain the vegetables.
<G-vec00847-002-s078><drain.abgießen><de> Die Ananasstückchen abgießen.
<G-vec00847-002-s078><drain.abgießen><en> Drain the pineapples.
<G-vec00847-002-s079><drain.abgießen><de> Nudeln abgießen und zu den Kirschen in die Pfanne geben und eindicken lassen.
<G-vec00847-002-s079><drain.abgießen><en> Drain the pasta and add to the cherries in the pan and let it thicken.
<G-vec00847-002-s080><drain.abgießen><de> Abgießen und abkühlen lassen.
<G-vec00847-002-s080><drain.abgießen><en> Drain; let cool.
<G-vec00847-002-s081><drain.abgießen><de> Anschließend in eine Schüssel mit eiskaltem Wasser geben, abgießen und die blanchierten Wirsingblätter in dünne Streifen schneiden.
<G-vec00847-002-s081><drain.abgießen><en> Transfer to a bowl with ice cold water, then drain the cabbage leaves and thinly slice.
<G-vec00847-002-s082><drain.abgießen><de> Am nächsten Tag den Sirup aus einer Schüssel abgießen, aufkochen, die Aprikosen hineingießen und für einen weiteren Tag stehen lassen.
<G-vec00847-002-s082><drain.abgießen><en> The next day, drain the syrup from a bowl, boil it, pour in the apricots and let it stand for another day.
<G-vec00847-002-s083><drain.abgießen><de> Abgießen und auf der Ofenplatte abdampfen lassen, bis eine dickflüssige schwarze Masse, etwa von der Konsistenz von Honig entsteht.
<G-vec00847-002-s083><drain.abgießen><en> Drain it and let the water evaporate on the stove until the black substance is thick like honey.
<G-vec00847-002-s084><drain.abgießen><de> Abgießen und pürieren und mit Salz, Pfeffer und etwas Zitronensaft abschmecken.
<G-vec00847-002-s084><drain.abgießen><en> Drain and mash and season with salt, pepper and a little lemon juice.
<G-vec00847-002-s085><drain.abgießen><de> Die fertig gegarten Kartoffeln abgießen, 5 Minuten in einem Sieb ausdampfen lassen und noch warm zum Salat geben.
<G-vec00847-002-s085><drain.abgießen><en> Drain the potatoes when cooked, then allow them to steam in a colander for 5 minutes.
<G-vec00847-002-s086><drain.abgießen><de> Abgießen, etwas Nudelwasser auffangen und beiseitestellen.
<G-vec00847-002-s086><drain.abgießen><en> Drain, save some pasta water, and set aside.
<G-vec00847-002-s087><drain.abgießen><de> Gut abgießen, etwas auskühlen lassen und die Schale entfernen.
<G-vec00847-002-s087><drain.abgießen><en> Drain well, let them cool down a bit and remove the skin.
<G-vec00847-002-s454><drain.abgießen><de> Gieße die Ananas ab (aber schütte das Wasser nicht weg, es wäre schade um all die Nährstoffe, du kannst es entweder trinken oder weiterverwenden) Gib alle Zutaten außer die Haferflocken in den Mixer und blende auf Höchstgeschwindigkeit.
<G-vec00847-002-s454><drain.abgießen><en> Drain the pineapple (but keep the water, we don’t want to waste all the nutrients! You can just drink it or use it for your oatmeal or sth like that) Add all ingredients except for the oats into your blender and blend them on highspeed.
<G-vec00847-002-s455><drain.abgießen><de> Gieße die Haferflocken gut ab.
<G-vec00847-002-s455><drain.abgießen><en> Drain the oats well.
<G-vec00847-002-s456><drain.abgießen><de> Für die gerade angefertigte Menge Reis, gieße das Wasser ab und serviere den Reis, sollte er deinen Vorstellungen entsprechen.
<G-vec00847-002-s456><drain.abgießen><en> For the current batch of rice, drain the water and serve if the rice texture suits your preferences.
<G-vec00847-002-s457><drain.abgießen><de> Gieße die Eier ab.
<G-vec00847-002-s457><drain.abgießen><en> Drain the eggs.
<G-vec00847-002-s458><drain.abgießen><de> Öffne die Dose und gieße die Flüssigkeit von den Früchten ab.
<G-vec00847-002-s458><drain.abgießen><en> Open the can, and drain the liquid from the fruit.
