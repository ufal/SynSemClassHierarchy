<G-vec00418-001-s019><boast.angeben><de> Wenn es allein durch meine gute Beziehung zum Heiligen Geist Gottes möglich wäre, bis zum Ende treu zu bleiben, dann kann ich darüber angeben, wie ich es geschafft habe auf Kurs zu bleiben und am Glauben festzuhalten.
<G-vec00418-001-s019><boast.angeben><en> If by my cooperation with the Spirit of God I remain faithful to the end, I can boast (a little) about how I was able to stay the course and finish the race.
<G-vec00418-001-s020><boast.angeben><de> Wir wollen ja nicht angeben, aber wenn es um Orte zum Besuchen geht, hat Schottland einiges zu bieten.
<G-vec00418-001-s020><boast.angeben><en> We don't like to boast, but when it comes to places to visit, Scotland has some mighty fine options indeed.
<G-vec00418-001-s021><boast.angeben><de> Wir sollen nicht angeben; wenn wir angeben wollen, denn über die Herrlichkeit von Gott.
<G-vec00418-001-s021><boast.angeben><en> We are not to boast about ourselves; if we want to boast, then we are to proclaim the glories of God.
<G-vec00418-001-s023><boast.angeben><de> """Also, kein Mensch kann vor Mir angeben."
<G-vec00418-001-s023><boast.angeben><en> """So, no man may boast before Me."
<G-vec00418-001-s004><brag.angeben><de> Nicht weil sie angeben wollen, sondern weil sie eine tiefe Verbindung herstellen wollen, indem sie ihren Prozess und ihren Weg offen mit Ihnen teilen.
<G-vec00418-001-s004><brag.angeben><en> It's not because they want to brag. It's because they want to connect deeply with you, by sharing their process and journey openly.
<G-vec00418-001-s005><brag.angeben><de> Sie können angeben, bluffen und den Kunden bloßstellen.
<G-vec00418-001-s005><brag.angeben><en> They can brag, bluff and embarrass.
<G-vec00060-001-s062><declare.angeben><de> Der folgende Code zeigt, wie wir die Beziehung für die User - und Post -Klasse angeben.
<G-vec00060-001-s062><declare.angeben><en> The following code shows how we declare the relationships for the User and Post classes.
<G-vec00060-001-s063><declare.angeben><de> Beim Abonnieren musst du nur einmal angeben, wo auf deinem Computer die Folgen gespeichert werden sollen.
<G-vec00060-001-s063><declare.angeben><en> This way you have to declare where you want to save the episodes on your computer just once.
<G-vec00060-001-s064><declare.angeben><de> Wenn sie öffentlich tätig werden wollen, dann werden sie angeben müssen, von wem sie Geld erhalten, wie viel sie erhalten und warum sie es bekommen.
<G-vec00060-001-s064><declare.angeben><en> If they want to continue their public activities, then they must declare who they receive funding from, how much they have received, and why they have received it.
<G-vec00060-001-s065><declare.angeben><de> Mit dem System ABAX 2 müssen Sie nicht alle Funktionen sofort angeben.
<G-vec00060-001-s065><declare.angeben><en> With the ABAX 2 system you donot have to declare all the functions at once.
<G-vec00060-001-s066><declare.angeben><de> Kommission untersucht die EBA, ob Finanzunterneh­ men, die angeben, dass sie ihre Tätigkeiten im Einklang mit den Grundsätzen des islamischen Bankwesens aus­ üben, hinreichend von den Bestimmungen dieser Richtlinie und der Verordnung [vom Amt für Ver­ öffentlichungen einzufügen] erfasst werden.
<G-vec00060-001-s066><declare.angeben><en> Upon receiving a mandate from the Commission, EBA shall explore whether financial sector entities which declare that they carry out their activities in accordance with Islamic banking principles are adequately covered by the provisions of this Directive and Regulation [inserted by OP].
<G-vec00060-001-s067><declare.angeben><de> Wegen der Euroeinführung werden die Gesellschaften auch ihre Satzungen ändern müssen und in diesen den Nennwert der Aktien sowie das Stammkapital in Euro angeben müssen.
<G-vec00060-001-s067><declare.angeben><en> Because of euro adoption, companies must also change their statues and declare their share capital and the nominal value of their shares in euro.
<G-vec00060-001-s068><declare.angeben><de> Anmerkung: Leider kann ich hierzu keine Quelle angeben, da ich mir vor vielen Jahren nur den Text notiert hatte.
<G-vec00060-001-s068><declare.angeben><en> Comment: Unfortunately I can declare no source to this since I had written down only the text many years ago.
<G-vec00060-001-s069><declare.angeben><de> Hier müssen Sie die Feldnamen angeben, wie sie vom Identity Provider gesandt wurden.
<G-vec00060-001-s069><declare.angeben><en> Here, you need to declare the fields names as they are sent by the identity provider.
<G-vec00078-001-s068><declare.angeben><de> Anmerkung: Leider kann ich hierzu keine Quelle angeben, da ich mir vor vielen Jahren nur den Text notiert hatte.
<G-vec00078-001-s068><declare.angeben><en> Comment: Unfortunately I can declare no source to this since I had written down only the text many years ago.
<G-vec00060-001-s089><indicate.angeben><de> Mit einem Template und einem Profil kann die IT-Abteilung exakt angeben, wie ein Konto angelegt oder geändert werden soll.
<G-vec00060-001-s089><indicate.angeben><en> Using the template and profile, the systems administration department can indicate exactly how an account must be created.
<G-vec00060-001-s090><indicate.angeben><de> Jede Benennung durch einen Vertragsstaat oder der Vorsitzende führt den Namen angeben, Anschrift und Nationalität des designee, und enthält eine Erklärung seiner Qualifikationen, insbesondere in Bezug auf seine Kompetenz in den Bereichen Recht, Handel, Industrie und Finanzen.
<G-vec00060-001-s090><indicate.angeben><en> Each designation made by a Contracting State or by the Chairman shall indicate the name, address and nationality of the designee, and include a statement of his qualifications, with particular reference to his competence in the fields of law, commerce, industry and finance.
<G-vec00060-001-s091><indicate.angeben><de> wenn die Option für rekursive Durchsuchung von E-Mail-Dateien in Unterordner anzumerken, dass aktiviert ist, es ist genug, um einfach den Pfad zum Stammordner der E-Mail-Datenbank angeben.
<G-vec00060-001-s091><indicate.angeben><en> Note that if the option for recursive searching of e-mail files in subfolders is enabled, it is enough to simply indicate the path to the root folder of the e-mail database.
<G-vec00060-001-s092><indicate.angeben><de> Die Quellen angeben, die Aristonoa, als aristokratischer Abstammung und loyal im mazedonischen Zoll.
<G-vec00060-001-s092><indicate.angeben><en> The sources indicate the Aristonoa, as aristocratic descent and loyal in Macedonian customs.
<G-vec00060-001-s093><indicate.angeben><de> Dann bitte Folgendes angeben “KUKU 2013.......
<G-vec00060-001-s093><indicate.angeben><en> Please indicate the following: “KUKU 2013.......
<G-vec00060-001-s094><indicate.angeben><de> Die Genauigkeit des Datums ist wichtig, weil die Prologe Antimarcioni historischen Aufzeichnungen sind, die angeben, wie die frühe Kirche, hatte gerade einen Hauch von Ketzerei und Verwirrung sein inspiriert, sofort bereitgestellten Texte.
<G-vec00060-001-s094><indicate.angeben><en> The accuracy of the data is very important because the Prologues are antimarcioni historical records that indicate how the early Church, just had hints of heresy and confusion on the texts considered inspired provided immediately.
<G-vec00060-001-s095><indicate.angeben><de> "Schließlich kannst du etwas ""Wackelgeschwindigkeit"" angeben."
<G-vec00060-001-s095><indicate.angeben><en> Finally you can indicate some amount of wiggling of the speed.
<G-vec00060-001-s096><indicate.angeben><de> Niemand kann einen vernünftigen Grund angeben, weshalb in ähnlicher Weise eine Maschine – dieses Gerät mit selbständiger Bewegung, mit einem gewissen Eigenleben – nicht schön sein könnte.
<G-vec00060-001-s096><indicate.angeben><en> Nobody can indicate a good reason why in a similar way a machine - this device with an independent movement, with a certain independent existence - could be not beautiful as well.
<G-vec00060-001-s097><indicate.angeben><de> Du kannst tatsächlich angeben, wie dies passieren muss.
<G-vec00060-001-s097><indicate.angeben><en> You can actually indicate how this must happen.
<G-vec00060-001-s098><indicate.angeben><de> Auf dem Anmeldeformular können Sie die bevorzugten Tage und Uhrzeiten angeben, die zur Festlegung der späteren Unterrichtszeiten während der Probestunde benötigt werden.
<G-vec00060-001-s098><indicate.angeben><en> On the registration form, you can indicate your preferred day and time of the session to coincide with the teacher's availability.
<G-vec00060-001-s099><indicate.angeben><de> Eine Fehlermeldung kann ebenfalls angeben, dass ein Fehler aufgetreten ist.
<G-vec00060-001-s099><indicate.angeben><en> An error message may also indicate that an error has been encountered.
<G-vec00060-001-s100><indicate.angeben><de> Der Kunde muss die gewünschte Zahlungsart angeben.
<G-vec00060-001-s100><indicate.angeben><en> • Lastly, the Customer must also indicate the selected method of payment.
<G-vec00060-001-s101><indicate.angeben><de> Weil die Zunge nur angeben kann Textur und unterscheiden zwischen süß, sauer, bitter, salzig und umami das meiste, was als den Geschmackssinn wahrgenommen wird tatsächlich von Geruch abgeleitet.
<G-vec00060-001-s101><indicate.angeben><en> Because the tongue can only indicate texture and differentiate between sweet, sour, bitter, salty, and umami most of what is perceived as the sense of taste is actually derived from smell.
<G-vec00060-001-s102><indicate.angeben><de> Ein Affe muss eine klassische Gedächtnisaufgabe lösen: dem Tier werden kurz hintereinander zwei Bilder gezeigt und es muss angeben, ob das zweite Bild dem ersten entspricht oder nicht.
<G-vec00060-001-s102><indicate.angeben><en> A monkey has to carry out a classic memory task: the animal is shown two consecutive images and then has to indicate whether the second image was the same as the first one.
<G-vec00060-001-s103><indicate.angeben><de> Diese Fotos und Illustrationen sollen dem Benutzer die Kategorie der Unterkunft oder das Maß des Komforts angeben und begründen keine darüber hinausgehende Verpflichtung.
<G-vec00060-001-s103><indicate.angeben><en> The purpose of these photos and illustrations is to indicate the category of accommodation or the degree of comfort to the User and may not be the source of any commitment beyond this purpose.
<G-vec00060-001-s104><indicate.angeben><de> Des Weiteren kann der Anmelder auf eine Aufforderung nach Regel 62a hin Argumente gegen die Feststellungen in der Aufforderung einreichen und als Hauptantrag eine vollständige Recherche der eingereichten Ansprüche beantragen sowie in einem Hilfsantrag für den Fall, dass der Prüfer nicht überzeugt sein sollte, die zu recherchierenden unabhängigen Ansprüche angeben (siehe auch H‑III, 3.2).
<G-vec00060-001-s104><indicate.angeben><en> Furthermore, the applicant may, in reply to an invitation under Rule 62a, file arguments against the findings in the invitation requesting as a main request that the claims as filed be completely searched and as an auxiliary request, in case the examiner is not convinced, indicate the independent claims to be searched (see also H‑III, 3.2).
<G-vec00060-001-s105><indicate.angeben><de> Möchtest Du Dein Testgerät zurücksenden, musst Du dies im Abschlussfragebogen, welcher Dir zum Kampagnen-Ende zur Verfügung gestellt wird, zwingend angeben.
<G-vec00060-001-s105><indicate.angeben><en> Return your device. Should you wish to do so, you must indicate it in the end survey communicated at the end of the campaign.
<G-vec00060-001-s106><indicate.angeben><de> Sie sollten angeben, ob generell Placebos eingesetzt würden.
<G-vec00060-001-s106><indicate.angeben><en> They were to indicate whether placebos are generally used.
<G-vec00060-001-s107><indicate.angeben><de> Die Protokoll müssen angeben, welche Sender(laufen einen Multiplikator) machte jedes QSO.
<G-vec00060-001-s107><indicate.angeben><en> The log must indicate which transmitter(run a multiplier) made each QSO.
<G-vec00060-001-s057><specify.angeben><de> In diesem Fall können Sie beim Erstellen eines Maschinenkatalogs die auf den Maschinen installierte VDA-Version angeben.
<G-vec00060-001-s057><specify.angeben><en> In this scenario, when you create a machine catalog, you can specify the VDA version installed on the machines.
<G-vec00060-001-s058><specify.angeben><de> Zudem können Sie angeben, ob die MIF-Dokumente, die Sie in Across bearbeiten, mit einer FrameMaker-Version erstellt wurden, bei der das Problem mit der Darstellung von Zacute und tcaron behoben ist (ab Version 7.2).
<G-vec00060-001-s058><specify.angeben><en> Furthermore, you can specify whether the MIF documents you edit in Across were created with a FrameMaker version in which the Zacute/tcaron display problem has been resolved (from version 7.2).
<G-vec00060-001-s059><specify.angeben><de> Wenn Sie die NDR-Überprüfung aktivieren, müssen Sie einen NDR-Überprüfung aktivieren angeben (eine Zeichenfolge mit mindestens 8 Zeichen, ähnlich einer Passphrase).
<G-vec00060-001-s059><specify.angeben><en> When you Enable NDR check, you must specify Signature seed (a string of at least 8 characters, something like a passphrase).
<G-vec00060-001-s060><specify.angeben><de> Das Schlimmste ist, dass man den Prozess nicht verlassen kann nur laufen - Sie kann es immer noch kontrollieren müssen und manuell die nächste Mailbox für die Konvertierung auswählen und das Ziel angeben PST Datei als auch.
<G-vec00060-001-s060><specify.angeben><en> The worst thing is that you can’t leave the process just running – you still have to control it and manually pick the next mailbox for conversion and specify the target PST file as well.
<G-vec00060-001-s061><specify.angeben><de> Du musst möglicherweise den Videotextsprachcode für dein Land angeben.
<G-vec00060-001-s061><specify.angeben><en> You might need to specify the teletext language code for your country.
<G-vec00060-001-s062><specify.angeben><de> In einem Fragebogen sollten diese unter anderem ihre politischen Positionen bezüglich Fracking und ihre Kontakte zu anderen Akteuren angeben sowie deren Einfluss beurteilen.
<G-vec00060-001-s062><specify.angeben><en> In a survey, these actors were asked to indicate their policy positions with regard to fracking and to specify their relations with and assess the influence of other actors.
<G-vec00060-001-s063><specify.angeben><de> 3° und 4° Bett -10%; Preise für Kinder auf Anfrage per Email, je nach Anzahl der Familienmitglieder (Angeben: Anzahl derErwachsene, anzahl der kinder, Geburtsdatum und Skifahrer Detail).
<G-vec00060-001-s063><specify.angeben><en> Prices for children upon request by email according to families (specify number of adults, number of children, date of birth and detail skiers).
<G-vec00060-001-s064><specify.angeben><de> "Außerdem wurde das Disk-Tools-Menü erweitert: * ""Freien Speicher extrahieren"" durchläuft das gegenwärtig geöffnete Laufwerk und sammelt alle unbenutzte Cluster in einer Zieldatei, die Sie angeben."
<G-vec00060-001-s064><specify.angeben><en> Besides, the Disk Tools menu has been extended: * Gather Free Space traverses the currently open logical drive and gathers all unused clusters into a destination file you specify.
<G-vec00060-001-s065><specify.angeben><de> Durch das Abonnieren von Ereignissen können Sie jedoch die Ereignisse weiterleiten, eine Aktion angeben, mit der auf die Ereignisse reagiert wird, und das Abonnement abbrechen.
<G-vec00060-001-s065><specify.angeben><en> However, subscribing lets you forward the events, specify an action to respond to the events, and cancel the subscription.
<G-vec00060-001-s066><specify.angeben><de> Wenn Sie eine Datenbank auf einem Remoteserver erstellen, sollten Sie die Spezifikation des Remoteservers angeben.
<G-vec00060-001-s066><specify.angeben><en> If you create a database on a remote server, you should specify the remote server specification.
<G-vec00060-001-s067><specify.angeben><de> Zeilenhöhe Wenn Sie eine feste Zeilenhöhe angeben, muss diese größer als die Schriftgröße sein, andernfalls laufen die Zeilen ineinander.
<G-vec00060-001-s067><specify.angeben><en> Line height If you specify a fixed line height, enter a line height larger than the font size or lines of text will overlap.
<G-vec00060-001-s068><specify.angeben><de> Wenn Sie die cephx-Authentifizierung nutzen, müssen Sie außerdem ein Geheimnis angeben.
<G-vec00060-001-s068><specify.angeben><en> If you use cephx authentication, you also need to specify a secret.
<G-vec00060-001-s069><specify.angeben><de> Wenn Sie beispielsweise angeben, dass die Regel nur auf RAS-Verbindungen angewendet werden soll, stimmen nur diese Verbindungen mit der Regel überein.
<G-vec00060-001-s069><specify.angeben><en> For example, if you specify that a rule to be applied only to remote access connections, then only these connections will match the rule.
<G-vec00060-001-s070><specify.angeben><de> Mitglieder Ihres Skype Manager können ebenfalls die Währung angeben, die sie...
<G-vec00060-001-s070><specify.angeben><en> Members of your Skype Manager can also specify the currency they want to use.If...
<G-vec00060-001-s071><specify.angeben><de> Sie können auch Befehlszeilenparameter mit EXE-Dateien angeben.
<G-vec00060-001-s071><specify.angeben><en> You can also specify command-line parameters with .exe files.
<G-vec00060-001-s072><specify.angeben><de> Hotel pick-up und drop-off zur Verfügung gestellt, bitte angeben.
<G-vec00060-001-s072><specify.angeben><en> Hotel pick up and drop off provided, please specify.
<G-vec00060-001-s073><specify.angeben><de> Vor dem Kauf eines Staubsaugers Bosch BSGL 32 383 angeben, alle Optionen, Ausstattung, Aussehen und Garantie vom Verkäufer.
<G-vec00060-001-s073><specify.angeben><en> Before buying a vacuum cleaner Bosch BSGL 32 383 specify all your options, equipment, appearance and warranty from the seller.
<G-vec00060-001-s074><specify.angeben><de> Wenn Sie eine von dieser Rechnungsadresse abweichende Lieferanschrift angeben wollen, können Sie dies im nächsten Schritt des Bestellvorgangs tun, wenn die angegebene Rechnungsadresse der Versandadresse entspricht, wird dieser Schritt übersprungen.
<G-vec00060-001-s074><specify.angeben><en> Fields marked with * must be filled in. If you want to specify a shipping address that is different from the billing address, you can do so in the next step of the ordering process. If the specified shipping address matches the billing address, this step is skipped.
<G-vec00060-001-s075><specify.angeben><de> Wenn Sie diesen Parameter angeben, kann sich der Benutzer mehrfach mit seinem Benutzer-Account anmelden.
<G-vec00060-001-s075><specify.angeben><en> If you specify this parameter, the user can login multiple times with his/her user account.
<G-vec00060-001-s076><specify.angeben><de> Wenn Sie eine Fehlerklasse und eine von deren abgeleiteten Klassen angeben, platzieren Sie den Catch-Block für die abgeleitete Klasse vor dem Catch-Block für die allgemeine Klasse.
<G-vec00060-001-s076><specify.angeben><en> If you specify an error class and one of its derived classes, place the Catch block for the derived class before the Catch block for the general class.
<G-vec00060-001-s077><specify.angeben><de> Die Java-Datei müssen wir auch im Makefile mit MURL_ANDROID_JAVA_FILES angeben, damit sie beim Build-Vorgang berücksichtigt wird.
<G-vec00060-001-s077><specify.angeben><en> To add the Java file to the build process we need to specify it in the Makefile with MURL_ANDROID_JAVA_FILES.
<G-vec00060-001-s078><specify.angeben><de> In dem Geteilte Zellen Dialog, überprüfen Sie die Aufteilung Art Sie brauchen, und klicken Sie dann auf Breite angeben Option, und geben Sie die Länge, die Sie teilen möchten, in das nächste Textfeld ein.
<G-vec00060-001-s078><specify.angeben><en> In the Split Cells dialog, check the split Type you need, and then click Specify width option, and type the length you want to split based on into the next textbox.
<G-vec00060-001-s079><specify.angeben><de> Sie können eine Zeichenkette angeben, mit dem Sie den Benutzer zur Eingabe auffordern.
<G-vec00060-001-s079><specify.angeben><en> You may specify a string with which to prompt the user.
<G-vec00060-001-s080><specify.angeben><de> Wenn Sie ein vielfältiges Inventar, Sie können weitere Kosten angeben, indem Sie pro Produkt Versand Fracht Einrichtung und eine Kosten für jeden Posten einrichten.
<G-vec00060-001-s080><specify.angeben><en> If you have a diverse inventory, you can further specify costs by setting up shipping freight per product and set up a cost for each item.
<G-vec00060-001-s081><specify.angeben><de> "Wenn Sie möchten, um importierten E-Mails zu einem neuen eigenständigen sparen PST Datei, verwenden die "" Save .PST "", Um seine Position angeben und starten Sie den Vorgang."
<G-vec00060-001-s081><specify.angeben><en> If you would like to save imported emails to a new standalone PST file, use the “ Save .PST ” button to specify its location and start the process.
<G-vec00060-001-s082><specify.angeben><de> Somit muss der Mitarbeiter keinen Benutzernamen oder ein Passwort angeben, dennoch erreichen Sie eine hohe Sicherheit.
<G-vec00060-001-s082><specify.angeben><en> In this way, the employee does not have to specify a user name or a password but a high level of security is achieved.
<G-vec00060-001-s083><specify.angeben><de> In den Einstellungen können Sie die Anzahl der FPS angeben geradlinig Abhängigkeit Entladen Sie den Akku.
<G-vec00060-001-s083><specify.angeben><en> In the settings you can specify the number of FPS is rectilinear dependence discharge the battery.
<G-vec00060-001-s084><specify.angeben><de> Spinn verbindet, um einen Begleiter iOS – / Android-app über Wi-Fi, so können die Benutzer angeben, wie Sie wollen Ihren Kaffee getan, oder planen Sie eine Tasse vor der Zeit, obwohl dies kann auch direkt aus der Maschine oder durch Alexa Sprachbefehle.
<G-vec00060-001-s084><specify.angeben><en> Spinn connects to a companion iOS / Android app over Wi-Fi so users can specify how they want their coffee done, or schedule a cup ahead of time, although this can also be done directly from the machine or through Alexa voice commands.
<G-vec00060-001-s085><specify.angeben><de> Falls Sie die Anzeigenserver-URL auf Playerebene angeben möchten, finden Sie Informationen hierzu unter Zuweisen der Anzeigenserver-URL auf Playerebene über das Werbemodul.
<G-vec00060-001-s085><specify.angeben><en> However, if you want to specify the Ad Server URL at the player level, see Assigning the Ad Server URL at the Player Level from Advertising Module.
<G-vec00060-001-s086><specify.angeben><de> mVPN-Tunnelausschlussliste: Wenn Sie den Micro-VPN-Zugriff aktivieren, können Sie die Domänen angeben, die Sie aus den Micro-VPN-Richtlinien ausschließen möchten.
<G-vec00060-001-s086><specify.angeben><en> mVPN tunnel exclusion list: If you enable micro VPN access, you can specify the domains to exclude from the micro VPN policies.
<G-vec00060-001-s087><specify.angeben><de> Falls Sie eine bestimmte Spielkennung angeben möchten, finden Sie diese in ~/.minetest/games/ .
<G-vec00060-001-s087><specify.angeben><en> If you want to specify a specific game ID, the game ID choices are located in /Minetest/games/ .
<G-vec00060-001-s088><specify.angeben><de> Wenn Sie keinen Wert angeben, verbleiben Faxe so lange im Archiv, bis sie manuell gelöscht werden.
<G-vec00060-001-s088><specify.angeben><en> If you do not specify a value, faxes will remain in the archive until deleted manually.
<G-vec00060-001-s089><specify.angeben><de> Wenn Sie ein alternatives Verzeichnis angeben möchten, kopieren Sie bitte alle Daten aus dem Verzeichnis wwwroot im estos MetaDirectory Installationsverzeichnis.
<G-vec00060-001-s089><specify.angeben><en> If you want to specify an alternative directory, copy all data from the wwwroot directory to the estos MetaDirectory installation directory.
<G-vec00060-001-s090><specify.angeben><de> Auf dieser Seite des Assistenten können Sie weitere Optionen angeben, bevor Sie das Zusammenführen starten.
<G-vec00060-001-s090><specify.angeben><en> This page of the wizard lets you specify advanced options, before starting the merge process.
<G-vec00060-001-s108><indicate.angeben><de> Tagout-Apparate sind so anzubringen, dass deutlich angegeben ist, dass das Bedienen oder Umschalten der energieisolierenden Vorrichtung von der „sicheren“ oder „Aus“-Stellung in eine andere Stellung untersagt ist.
<G-vec00060-001-s108><indicate.angeben><en> "Tagout devices, where used, shall be affixed in such a manner as will clearly indicate that the operation or movement of energy isolating devices from the ""safe"" or ""off"" position is prohibited."
<G-vec00060-001-s109><indicate.angeben><de> Allerdings können auch bei nichtökologischen Erzeugnissen Zutaten ökologischen Ursprungs angegeben werden, dies jedoch ausschließlich auf der Zutatenliste.
<G-vec00060-001-s109><indicate.angeben><en> But non-organic products will be entitled to indicate organic ingredients on the ingredients list only.
<G-vec00060-001-s110><indicate.angeben><de> Dort können auch Momente angegeben werden, die nach Ansicht der Person selbst zu hohen Tonometerzahlen führen können.
<G-vec00060-001-s110><indicate.angeben><en> It is also possible to indicate moments there, which, in the opinion of the person himself, could contribute to high numbers on the tonometer.
<G-vec00060-001-s111><indicate.angeben><de> Ihr habt angegeben, dass das etwas damit zu tun hatte, dass Ark und ich nun letztendlich zusammen sind, und die ersten Phasen einer gewissen großen Bestimmung an ihren Platz fallen würden.
<G-vec00060-001-s111><indicate.angeben><en> You did indicate that this had something to do with the fact that Ark and I were together, finally, and the beginning stages of some grand destiny were falling into place.
<G-vec00060-001-s112><indicate.angeben><de> Auf der Website werden die Verkaufspreise jeden Produkts und die Art der Berechnung des Gesamtpreises des Kaufs klar und deutlich angegeben.
<G-vec00060-001-s112><indicate.angeben><en> The Site shall clearly indicate the Selling Prices for each product and the way to calculate the total price of the purchase.
<G-vec00060-001-s113><indicate.angeben><de> - Falls Geräte auch von anderen Richtlinien erfasst werden, die andere Aspekte behandeln und in denen die CE-Konformitätskennzeichnung vorgesehen ist, wird mit dieser Kennzeichnung angegeben, daß auch von der Konformität dieser Geräte mit den Bestimmungen dieser anderen Richtlinien auszugehen ist.
<G-vec00060-001-s113><indicate.angeben><en> - Where apparatus is the subject of other Directives covering other aspects and which also provide for the CE conformity marking, the latter shall indicate that the appliances are also presumed to conform to those other Directives.
<G-vec00060-001-s114><indicate.angeben><de> Entwertung: Die Karte muss in den öffentlichen Verkehrsmitteln bei jeder Fahrt entwertet werden (der Bestimmungsort muss nicht angegeben werden).
<G-vec00060-001-s114><indicate.angeben><en> How to use the card: Use your card like a ticket every time you use public transport (you need not indicate your destination).
<G-vec00060-001-s115><indicate.angeben><de> Darin ist ein Richtwert für Uran von 15 Mikrogramm pro Liter angegeben.
<G-vec00060-001-s115><indicate.angeben><en> They indicate a guideline value for uranium of 15 microgram per litre.
<G-vec00060-001-s116><indicate.angeben><de> In der Zusammenfassung D1a von D1 sei nicht angegeben, wie die erste Cursorposition zustandekomme, d. h., ob sie durch die Berührung des Tastfelds mit dem Finger oder als Ergebnis eines bereits auf dem Bildschirm vorhandenen Cursors erzeugt werde, der vom Finger zu einer neuen Position verschoben werden müsse.
<G-vec00060-001-s116><indicate.angeben><en> The abstract D1a, which related to D1, did not indicate how the cursor position was initially generated, whether it was generated when the finger touched the touch panel or as a result of a cursor already on a screen which had to be dragged to a new position by the finger.
<G-vec00060-001-s117><indicate.angeben><de> Um den Wert einer noch austehenden Zahlungsfolge bestimmen zu können muss eine Vergleichsrendite angegeben werden, die alternativ mit dem Kapital erzielt werden könnte.
<G-vec00060-001-s117><indicate.angeben><en> To determine the value of a sequence of pending payments you need to indicate a comparison net yield, which could be obtained alternatively with the capital.
<G-vec00060-001-s118><indicate.angeben><de> In Fällen, in denen die Reproduktion einer vorhergehenden Genehmigung bedarf, trifft die zuvor angegebene allgemeine Erlaubnis nicht zu und klare Angaben bezüglich der Einschränkungen müssen angegeben werden.
<G-vec00060-001-s118><indicate.angeben><en> Where prior permission is required to reproduce information, such permission excludes the aforementioned general permission and must clearly indicate any restrictions on its use.
<G-vec00060-001-s119><indicate.angeben><de> Unsere hier angegeben Preise verstehen sich als Endpreise inkl.
<G-vec00060-001-s119><indicate.angeben><en> The prices we indicate are the final prices including value added tax.
<G-vec00060-001-s120><indicate.angeben><de> Online-Anmeldung: Bei der Anmeldung muss die genaue Teilnehmerzahl angegeben werden (Studenten, Dozenten und eventuelle Begleitpersonen) .
<G-vec00060-001-s120><indicate.angeben><en> Online booking: upon booking it is necessary to indicate the precise number of members in the group (students, teachers and any other accompanying visitors).
<G-vec00060-001-s121><indicate.angeben><de> "Im Befehl wird mit dem Dollarzeichen ($) eine Variable angegeben, und mit dem Zuweisungsoperator (=) wird das Ergebnis des Befehls ""Get-Service"" der neu erstellten Variablen zugewiesen."
<G-vec00060-001-s121><indicate.angeben><en> The command uses a dollar sign ($) to indicate a variable and the assignment operator (=) to assign the result of the Get-Service command to the newly created variable.
<G-vec00060-001-s122><indicate.angeben><de> "Wenn die Alarmzentrale in CID kommuniziert es kommuniziert bei 2300Hz und eine schnellere Kommunikation (höhere Baudrate) ""[was führen kann die Alarmzentrale mehrmals die Wahlwiederholung und gegebenenfalls eine fehlgeschlagene Verbindung angegeben]."
<G-vec00060-001-s122><indicate.angeben><en> "When the alarm panel communicates in CID it is communicating at 2300Hz and is a faster communication (higher baud rate)"" [which can cause the alarm panel to redial several times and possibly indicate a failed connection]."
<G-vec00060-001-s123><indicate.angeben><de> Daher muss angegeben werden, was genau es bestätigen soll.
<G-vec00060-001-s123><indicate.angeben><en> Therefore, it is necessary to indicate what exactly it should confirm.
<G-vec00060-001-s124><indicate.angeben><de> In der Datenschutzerklärung wird immer das späteste Datum der Änderung angegeben.
<G-vec00060-001-s124><indicate.angeben><en> The privacy policy will always indicate the latest date of the change.
<G-vec00060-001-s125><indicate.angeben><de> "Im Fall von ""polling"" eines akkreditierten Journalisten, der ein Telefax senden will, ist dieser gebeten, bei der Telefax-Nummer des Presseamtes des Heiligen Stuhls anrufen zu lassen, die ihm vom beauftragten Personal angegeben wird und dabei die Uhrzeit für den Anruf vom Faxgerät des Empfängers anzugeben."
<G-vec00060-001-s125><indicate.angeben><en> In the case of “polling”, the accredited journalist who intends to send a telefax is asked to have the destined receiver call the telefax number of the Holy See Press Office (the reception personnel will indicate the telephone number and the hour in which the receiving end should place the call).
<G-vec00060-001-s126><indicate.angeben><de> Wenn dies nach billigem Ermessen nicht möglich ist, wird der Unternehmer – bevor der Fernabsatzvertrag zustande kommt – angegeben, auf welche Weise die AGB bei dem Unternehmer einzusehen sind und diese auf Anfrage des Verbrauchers schnellstmöglich kostenlos zugeschickt werden.
<G-vec00060-001-s126><indicate.angeben><en> made available to the consumer. If this is not reasonably possible, the trader will indicate, before the distance contract is concluded, in what way the general terms and conditions are available for inspection at the trader’s premises and that they will be sent free of charge to the consumer, as
<G-vec00060-001-s091><specify.angeben><de> Wenn die chinesische Website nicht angegeben wird, welcher die Hersteller Ihre Tablette nicht Kauf sollte.
<G-vec00060-001-s091><specify.angeben><en> If the Chinese site does not specify what the manufacturer of your tablet you should not buy it.
<G-vec00060-001-s092><specify.angeben><de> Sie braucht drei Werte, die auf #t (wahr) oder #f (falsch) gestellt werden können, womit angegeben wird, ob die Taktnummer an der entsprechenden Stelle sichtbar ist.
<G-vec00060-001-s092><specify.angeben><en> This takes three values which may be set to #t or #f to specify whether the corresponding bar number is visible or not.
<G-vec00060-001-s093><specify.angeben><de> Dabei wird der Port mit dem Port-Parameter angeben, und das Konto eines Benutzers mit der Berechtigung zum Herstellen einer Verbindung mit dem Remotecomputer wird mit dem Credential-Parameter angegeben.
<G-vec00060-001-s093><specify.angeben><en> It uses the Port parameter to specify the port and the Credential parameter to specify the account of a user with permission to connect to the remote computer.
<G-vec00060-001-s094><specify.angeben><de> Ihre Registrierung und/oder Verwendung des Benutzerkontos setzt Ihr Verständnis dessen voraus, dass wir auf natürliche Weise die vorhandenen Daten über Ihre Firma (die wir von Ihnen, sowie aus anderen legitimen Quellen erhalten haben) mit den Daten, die von Ihnen im Benutzerkonto angegeben worden sind, vergleichen können.
<G-vec00060-001-s094><specify.angeben><en> When you register and/or use an account it implies your understanding that we can naturally compare the data about your firm that we have (received from you as well as from other legal sources) with the data that you specify in your account.
<G-vec00060-001-s095><specify.angeben><de> Ein Sprecher hat nicht angegeben, welche Art von Portal ist, verklagt zu werden.
<G-vec00060-001-s095><specify.angeben><en> A spokesman did not specify what kind of portal is being sued.
<G-vec00060-001-s096><specify.angeben><de> Sehr viele Kunden von HelloFresh haben dafür einen sicheren Abstellort angegeben (zum Beispiel die hauseigene Garage).
<G-vec00060-001-s096><specify.angeben><en> For this purpose many HelloFresh customers specify a secure place to deposit their food box (for example in the garage).
<G-vec00060-001-s097><specify.angeben><de> Außerdem kann der spezielle Wert default angegeben werden, um die schlichte, hartkodierte Nachricht des Apache zu verwenden.
<G-vec00060-001-s097><specify.angeben><en> Additionally, the special value default can be used to specify Apache's simple hardcoded message.
<G-vec00060-001-s098><specify.angeben><de> Aus diesem Grund muss in einem Broschürenlayout auch die Anzahl der Bogen mit angegeben werden, da diese den zu berücksichtigenden Bundzuwachs beeinflusst.
<G-vec00060-001-s098><specify.angeben><en> Consequently, a book layout must also specify the number of sheets in each saddle because the number of sheets in each saddle affects the amount of creep that needs to be accounted for.
<G-vec00060-001-s099><specify.angeben><de> Wenn ein höherer Verschlüsselungsgrad auf dem Server oder Benutzergerät eingestellt ist, können Einstellungen überschrieben werden, die Sie für veröffentlichte Ressourcen angegeben haben.
<G-vec00060-001-s099><specify.angeben><en> If a higher priority encryption level is set on either a server or user device, settings you specify for published resources can be overridden.
<G-vec00060-001-s100><specify.angeben><de> Durch Hinzufügen eines Index ist der Benutzer in der Lage, durch Auswählen aus einer Liste von Schlüsselwörtern, die Sie angegeben haben, nach Hilfe zu suchen.
<G-vec00060-001-s100><specify.angeben><en> By adding a Index, the user will be able to search for help by selecting from a list of keywords that you specify.
<G-vec00060-001-s101><specify.angeben><de> Das Laufwerk wird mit dem PSDrive-Parameter angegeben.
<G-vec00060-001-s101><specify.angeben><en> It uses the PSDrive parameter to specify the drive.
<G-vec00060-001-s102><specify.angeben><de> Im Falle, dass Sie ein ausländischer Kunde sind, muss das Zielland angegeben werden, da zum Preis die Versandkosten und eventuelle Zollgebühren hinzugefügt werden.
<G-vec00060-001-s102><specify.angeben><en> If you are a foreign customer, you should specify the destination country because the price will be raised by the cost of transportation and any customs charges.
<G-vec00060-001-s103><specify.angeben><de> Achten Sie darauf, dass Sie sowohl beim Einlesen als auch beim Erstellen eines Dumps immer einen einzigen Zeichensatz per SET NAMES angegeben haben.
<G-vec00060-001-s103><specify.angeben><en> Make sure that you always use SET NAMES to specify a single character set both when reading and generating dumps.
<G-vec00060-001-s104><specify.angeben><de> Sie hat nicht angegeben was die genaue fließt der Malware-Entwickler gemacht hatte aber gezeigt, dass die Opfer entschlüsseln über können 70% ihrer gesperrten Dateien selbst.
<G-vec00060-001-s104><specify.angeben><en> They did not specify the exact flows the malware developers had made but revealed that victims can decrypt over 70% of their locked files themselves.
<G-vec00060-001-s105><specify.angeben><de> Falls der Quelllizenzserver im Netzwerk nicht verfügbar ist, muss neben dem Betriebssystem, unter dem der Lizenzserver ausgeführt wird, auch die Lizenzserver-ID für den Quelllizenzserver angegeben werden.
<G-vec00060-001-s105><specify.angeben><en> If the source license server is not available on the network, you need to specify the operating system that the source license server is running and provide the license server ID for the source license server.
<G-vec00060-001-s106><specify.angeben><de> Bei mount_msdosfs (8) können jetzt mit -D die MS-DOS Codepage und mit -L der lokale Zeichensatz angegeben werden, um die Dateinamen umzuwandeln.
<G-vec00060-001-s106><specify.angeben><en> The mount_msdosfs (8) utility now supports a -D option to specify MS-DOS codepages and a -L option to specify local character sets. They are used to convert character sets of filenames.
<G-vec00060-001-s107><specify.angeben><de> Die Skriptinstallation kann IP-, TCP/IP-, LPR- und UNC-Netzwerkanschlüsse erstellen, je nachdem, welchen Protokollwert Sie angegeben haben.
<G-vec00060-001-s107><specify.angeben><en> Script Install can create IP, TCP/IP, LPR, and UNC network ports according to the protocol value you specify.
<G-vec00060-001-s108><specify.angeben><de> Mit dem Name-Parameter wird die Ablaufverfolgungsquelle angegeben, mit dem Option-Parameter werden die ExecutionFlow-Ablaufverfolgungsereignisse ausgewählt, und mit dem PSHost-Parameter wird der Listener des Windows PowerShell-Hosts ausgewählt, der die Ausgabe an die Konsole sendet.
<G-vec00060-001-s108><specify.angeben><en> It uses the Name parameter to specify the trace source, the Option parameter to select the ExecutionFlow trace events, and the PSHost parameter to select the Windows PowerShell host listener, which sends the output to the console.
<G-vec00060-001-s109><specify.angeben><de> Falls für einige Eingabekanäle nichts angegeben ist, wird 0 angenommen.
<G-vec00060-001-s109><specify.angeben><en> If you do not specify any numbers for some input channels, 0 is assumed.
<G-vec00060-001-s110><specify.angeben><de> Bei mountd (8) kann mit der neuen Option -p ein fester Port angegeben werden, der dann im Regelsatz einer Firewall genutzt werden kann.
<G-vec00060-001-s110><specify.angeben><en> mountd (8) now supports the -p option, which allows users to specify a known port for use in firewall rulesets.
<G-vec00060-001-s111><specify.angeben><de> Dies öffnet den Dialog in dem die vollständige Adresse angegeben werden kann.
<G-vec00060-001-s111><specify.angeben><en> This will open the Location Dialog where you can specify the full address.
<G-vec00060-001-s112><specify.angeben><de> Für alle Abschätzung können feste Modellparameter oder Grenzwerte für freie Parameter angegeben werden.
<G-vec00060-001-s112><specify.angeben><en> For all estimations, you can designate fixed model parameters and specify bounds for free parameters.
<G-vec00060-001-s113><specify.angeben><de> Über diese Option unter 'Optionen > Verzeichnisse' kann ein Verzeichnis für Album-Cover angegeben werden, das beim Hinzufügen von Album-Covern angezeigt wird.
<G-vec00060-001-s113><specify.angeben><en> With this option located at 'Options > Directories' you can specify a default directory that is displayed when adding cover art.
<G-vec00060-001-s114><specify.angeben><de> Bei einer Verbindung zwischen zwei NT Rechnern muss diese Nummer nicht einmal angegeben werden.
<G-vec00060-001-s114><specify.angeben><en> If you connect two NT machines you don't even have to specify this number.
<G-vec00060-001-s115><specify.angeben><de> Optional kann angegeben werden, nach welchem Kapitel mit dem Abspielen aufgehört werden soll (Standard: 1).
<G-vec00060-001-s115><specify.angeben><en> Specify which chapter to start playing at. Optionally specify which chapter to end playing at (default: 1).
<G-vec00060-001-s116><specify.angeben><de> Hinzufügen: Öffnet das Dialogfeld Hinzufügen eines Skripts, in dem zusätzlich zu verwendende Skripts angegeben werden können.
<G-vec00060-001-s116><specify.angeben><en> Add: Opens the Add a Script dialog box, where you can specify any additional scripts to use.
<G-vec00060-001-s117><specify.angeben><de> Relative Pfadnamen können mit Sonderzeichen angegeben werden.
<G-vec00060-001-s117><specify.angeben><en> You can specify relative path names by using special characters.
<G-vec00060-001-s118><specify.angeben><de> Für den Index oder Primärschlüssel können nicht mehr als %1 Spaltennamen angegeben werden (%2 Spalten wurden angegeben).
<G-vec00060-001-s118><specify.angeben><en> Cannot specify more than %1 column names for index or primary key (%2 columns specified)
<G-vec00060-001-s119><specify.angeben><de> Darüber hinaus können Adressen angegeben werden, die nicht geprüft werden sollen.
<G-vec00060-001-s119><specify.angeben><en> Furthermore, it allows user to specify addresses, which should be excluded from checking.
<G-vec00060-001-s120><specify.angeben><de> Standardmäßig muss kein Benutzername und Passwort angegeben werden, da der integrierte HTTP-Server keine Authentifizierung erfordert.
<G-vec00060-001-s120><specify.angeben><en> By default, there is no need to specify a username or password, because the integrated HTTP server requires no authentication.
<G-vec00060-001-s121><specify.angeben><de> Bei ftpd (8) kann jetzt mit der neuen Option -P angegeben werden, auf welchem Port eingehende Verbindungen erwartet werden sollen.
<G-vec00060-001-s121><specify.angeben><en> ftpd (8) now supports a -P option to specify a port on which to listen in daemon mode.
<G-vec00060-001-s122><specify.angeben><de> Die Verzeichnisse können relativ oder absolut angegeben werden.
<G-vec00060-001-s122><specify.angeben><en> You can specify the directories in a relative or absolute way.
<G-vec00060-001-s123><specify.angeben><de> Hier kann nur eine Gruppe angegeben werden.
<G-vec00060-001-s123><specify.angeben><en> You may only specify a single group here.
<G-vec00060-001-s124><specify.angeben><de> Als Benutzername muss SYSDBA oder der Eigner angegeben werden.
<G-vec00060-001-s124><specify.angeben><en> Only the SYSDBA or the database owner may specify the sweep interval.
<G-vec00060-001-s125><specify.angeben><de> Wenn das LCD-Modul nicht in ein Unterverzeichnis von /lib/modules (siehe oben) kopiert wurde, muss der gesamte Pfad zum Modul angegeben werden.
<G-vec00060-001-s125><specify.angeben><en> If you did not copy the LCD module into a subdirectory of /lib/modules (see above) you would have to specify the full path instead.
<G-vec00060-001-s126><specify.angeben><de> Bei watch (8) kann das verwendete snp (4) Gerät jetzt mit der Option -f angegeben werden.
<G-vec00060-001-s126><specify.angeben><en> watch (8) now takes a -f option to specify a snp (4) device to use.
<G-vec00060-001-s127><specify.angeben><de> Beim Erstellen einer Shell auf einem Computer können die zu verwendenden Anmeldeinformationen vom Clientcomputer angegeben werden.
<G-vec00060-001-s127><specify.angeben><en> The client computer can specify the credentials to use when creating a shell on a computer.
<G-vec00060-001-s128><specify.angeben><de> Lösungsmethoden Evolver arbeitet mit sechs verschiedenen Lösungsmethoden, die angegeben werden können, um die optimale Kombination von anpassbaren Zellen zu finden.
<G-vec00060-001-s128><specify.angeben><en> Solving Methods Evolver uses six different solving methods that you can specify to find the optimal combination of adjustable cells.
<G-vec00060-001-s129><specify.angeben><de> So werden beispielsweise die von Ihnen in einem Kontakt-Formular getätigten Eingaben an einen internen Ansprechpartner weitergeleitet, bei der „Weiterempfehlen“-Funktion eine E-Mail unter Mitteilung Ihrer E-Mail-Adresse an den von Ihnen benannten Empfänger geschickt, beim Bestellen von Dokumenten das Dokument an die von Ihnen angegebene Adresse versandt.
<G-vec00060-001-s129><specify.angeben><en> For example, the entries you make in a contact form are forwarded to an internal contact person; when you use the “Recommend” function, an email including your email address is sent to the recipient nominated by you; when ordering documents (e.g. manuals), the document is sent to the address you specify.
<G-vec00060-001-s130><specify.angeben><de> Es zeigt Dir die Organic Keywords, für die Deine Konkurrenz rankt, und verrät Dir auch das Ads-Keyword für jede angegebene Seite.
<G-vec00060-001-s130><specify.angeben><en> It shows you the organic keywords that your competitors are ranking for and also reveals the ads keyword for any site that you specify.
<G-vec00060-001-s131><specify.angeben><de> PowerShell: Ändert die Systemzeit auf dem Computer in die von Ihnen angegebene Zeit.
<G-vec00060-001-s131><specify.angeben><en> PowerShell: Changes the system time on the computer to a time that you specify.
<G-vec00060-001-s132><specify.angeben><de> Dies entspricht der folgenden Option auf der Windows-Benutzeroberfläche: Nur von Benutzern angegebene Dateien und Programme sind offline verfügbar.
<G-vec00060-001-s132><specify.angeben><en> Corresponds to the following option in the Windows interface: Only the files and programs that users specify are available offline.
<G-vec00060-001-s133><specify.angeben><de> Notieren Sie sich das angegebene Attribut.
<G-vec00060-001-s133><specify.angeben><en> Make a note of the attribute that you specify.
<G-vec00060-001-s134><specify.angeben><de> "Also, ""Alle Stufen"" muss nur dann gewählt werden, wenn Sie zusätzliche Begrenzungen haben, in den URL-Filtern, zum Beispiel, begrenzen Sie das Herunterladen auf ""Starthost"", in diesem Fall wird die ganze angegebene Website heruntergeladen."
<G-vec00060-001-s134><specify.angeben><en> "Thus, ""All levels"" should be selected only when you have specified restrictions in the URL filters, for example, limit downloading to the ""Start host"", in this case the entire website you specify will be downloaded"
<G-vec00060-001-s135><specify.angeben><de> Die von Ihnen angegebene Position wird auf alle Register im Auftrag angewendet.
<G-vec00060-001-s135><specify.angeben><en> The position you specify applies to all the tabs in the job.
<G-vec00060-001-s136><specify.angeben><de> npm install module_name Es ist egal, welches Betriebssystem Sie haben; Der obige Befehl installiert das von Ihnen angegebene Modul anstelle von module_name .
<G-vec00060-001-s136><specify.angeben><en> npm install module_name It doesn't matter what OS you have; the above command will install the module you specify in place of module_name .
<G-vec00060-001-s137><specify.angeben><de> Professional Rezeption leitet die eingehenden Anruf oder Mail an die von Ihnen angegebene Adresse, ohne Einmischung oder charakteristische komutatornyh Signale lesen und präzise Antwort auf eine Anfrage oder Nachfrage, die zuvor von Ihrem Anweisungen empfangen werden, machen einen Bericht über die Termine und die Art der eingehenden Nachrichten an Sie gerichtet.
<G-vec00060-001-s137><specify.angeben><en> Professional receptionist forwards the incoming call or mail to the address you specify, without any interference or characteristic komutatornyh signals will be literate and accurate response to a request or demand, previously received from your instructions, make a report on the dates and nature of incoming messages addressed to you.
<G-vec00060-001-s138><specify.angeben><de> Hinweis: Die von Ihnen angegebene Konto für die Rückzahlung muss gleich das Konto, dessen Zahlung an Lucky Buddha tat.
<G-vec00060-001-s138><specify.angeben><en> Note: the account you specify for the repayment must be equal to the account whose payment to Lucky Buddha did.
<G-vec00060-001-s139><specify.angeben><de> Dem SOLID L, kann man immer vertrauen, dass die genaue angegebene Menge an Material über den genauen Teil der Straße verteilt werden.
<G-vec00060-001-s139><specify.angeben><en> With SOLID L, you can always rely that the exact amount of material will be spread on the exact part of the road you specify.
<G-vec00060-001-s140><specify.angeben><de> Für die angegebene Uhrzeit wird die Ortszeit auf dem Webserver verwendet.
<G-vec00060-001-s140><specify.angeben><en> The time that you specify uses the local time on the Web server.
<G-vec00060-001-s141><specify.angeben><de> Die Software enthält eine verschlüsselte Datei, die – je nach gewählter Lizenz – entweder an eine von Ihnen angegebene Domain oder IP Adresse gebunden wird.
<G-vec00060-001-s141><specify.angeben><en> The Software holds an encrypted file which will be locked to a Domain name respectively an IP address you specify.
<G-vec00060-001-s142><specify.angeben><de> Hinweis: Die angegebene Größe muss exakt mit der tatsächlichen Größe des eingelegten Mediums/Papiers übereinstimmen.
<G-vec00060-001-s142><specify.angeben><en> Note: The size you specify must match the actual paper size.
<G-vec00060-001-s143><specify.angeben><de> Von Ihnen angegebene Programme oder Skripts sollten ohne Benutzereingabe auskommen.
<G-vec00060-001-s143><specify.angeben><en> Programs or scripts that you specify should not require user input.
<G-vec00060-001-s144><specify.angeben><de> Wenn für einen Upload die Standardeinstellung von 12 Stunden oder der für die Einstellung Überprüfung auf nicht abgeschlossene Aufträge alle angegebene Wert überschritten ist, wird der Upload vom BITS-Server automatisch abgebrochen, und unvollständige Dateiinhalte werden gelöscht.
<G-vec00060-001-s144><specify.angeben><en> BITS Server checks for and deletes incomplete upload jobs that have timed out. If an upload exceeds the default setting of 12 hours, or the value you specify in the Scan for incomplete jobs every setting, BITS Server automatically cancels the upload and deletes any partial file contents.
<G-vec00060-001-s145><specify.angeben><de> Wenn Sie nicht auf die sekundäre Administrator-E-Mail-Adresse zugreifen können, können Sie Ihre Domain-Inhaberschaft bestätigen und die Anweisungen zum Zurücksetzen an eine andere von Ihnen angegebene E-Mail-Adresse senden lassen.
<G-vec00060-001-s145><specify.angeben><en> If you don't have access to the secondary administrator email address, you can verify your domain ownership and have the reset instructions sent to another email address that you specify.
<G-vec00060-001-s146><specify.angeben><de> SUBSTRING Dieser Operator wählt Dokumente, indem die angegebene Abfragezeichenfolge mit einem beliebigen Teil der Zeichenfolge in einem bestimmten Dokumentfeld verglichen wird.
<G-vec00060-001-s146><specify.angeben><en> Selects documents by matching the query string that you specify with any portion of the strings in a specific document field.
<G-vec00060-001-s147><specify.angeben><de> Sendet alle Fehler, die vom Prozess generiert werden, in eine von Ihnen angegebene Datei.
<G-vec00060-001-s147><specify.angeben><en> Sends any errors generated by the process to a file that you specify.
<G-vec00060-001-s148><specify.angeben><de> Anders als der format-Filter erlaubt dieser jeden Farbraum auÃÂer dem von dir angegebenen.
<G-vec00060-001-s148><specify.angeben><en> Unlike the format filter, this will allow any colorspace except the one you specify.
<G-vec00060-001-s149><specify.angeben><de> Die von Ihnen angegebenen Daten werden nur für diesen Zweck verwendet.
<G-vec00060-001-s149><specify.angeben><en> The data you specify is used only for this purpose.
<G-vec00060-001-s150><specify.angeben><de> Beim Workflow „ Endgröße = Auf Basis des Maskenrahmens “ bewirken Sie durch das Aktivieren der Option „ Randanschnitt “, dass die Schnittmarken um einen von Ihnen angegebenen Wert in den Bereich des gedruckten Seiteninhalts hinein verschoben werden, sodass der gedruckte Inhalt nach dem Schneiden bis unmittelbar an die Blattkante heranreicht.
<G-vec00060-001-s150><specify.angeben><en> For the Crop Box finish size workflow, the Bleeds option moves the trim marks into the image by the amount you specify to ensure that the printed area extends beyond the edge of the trimmed sheet.
<G-vec00060-001-s151><specify.angeben><de> ACCRUE Dieser Operator wählt Dokumente, die mindestens eines der angegebenen Suchelemente enthalten.
<G-vec00060-001-s151><specify.angeben><en> Selects documents that include at least one of the search elements that you specify.
<G-vec00060-001-s152><specify.angeben><de> Der SiteRemote 3 Client (oder höher) richtet mit Hilfe der hier angegebenen Verbindungsdaten eine permanente Verbindung ein, die erst wieder beim Herunterfahren des Rechners abgebaut wird.
<G-vec00060-001-s152><specify.angeben><en> SiteRemote 3 Client (or higher) uses the connection data you specify here to set up a permanent connection which will not be disconnected until the computer is shut down.
<G-vec00060-001-s153><specify.angeben><de> Während des Discoveryvorgangs kontaktieren die Cloud Connectors den Citrix XenApp Remoting Service auf dem von Ihnen angegebenen XenApp-Server.
<G-vec00060-001-s153><specify.angeben><en> During the discovery process, the Cloud Connectors contact the Citrix XenApp Remoting Service on the XenApp server you specify.
<G-vec00060-001-s154><specify.angeben><de> Die RAR-Dateien werden jetzt in dem von Ihnen angegebenen Ordner gespeichert.
<G-vec00060-001-s154><specify.angeben><en> The RAR files will now save to the folder that you specify.
<G-vec00060-001-s155><specify.angeben><de> Jede gespeicherte Abfrage besteht aus den ausgewählten Abfragekriterien sowie den angegebenen angepassten Sortier- und Spalteninformationen.
<G-vec00060-001-s155><specify.angeben><en> Each saved query consists of the query criteria that you select, as well as the customized sorting and column information that you specify.
<G-vec00060-001-s156><specify.angeben><de> Dieser Operator wählt Dokumente, die alle angegebenen Suchelemente enthalten.
<G-vec00060-001-s156><specify.angeben><en> Selects documents that contain all the search elements that you specify.
<G-vec00060-001-s157><specify.angeben><de> 4 Klicken OK um es zu schließen und zu dem von Ihnen angegebenen Verzeichnis zu gehen, um die exportierten Bilder anzuzeigen.
<G-vec00060-001-s157><specify.angeben><en> 4. Click OK to close it, and go to the directory you specify to view the exported pictures.
<G-vec00060-001-s158><specify.angeben><de> Auf einem Netzwerkrichtlinienserver mit mehreren installierten Netzwerkadaptern können Sie den Netzwerkrichtlinienserver so konfigurieren, dass RADIUS-Datenverkehr nur auf von Ihnen angegebenen Netzwerkadaptern gesendet und empfangen wird.
<G-vec00060-001-s158><specify.angeben><en> On an NPS server that has multiple network adapters installed, you might want to configure NPS to send and receive RADIUS traffic only on the adapters you specify.
<G-vec00060-001-s159><specify.angeben><de> Bei Verwendung des Format-Parameters ruft Windows PowerShell nur die Eigenschaften des DateTime-Objekts ab, die zum Anzeigen des Datums in dem von Ihnen angegebenen Format erforderlich sind.
<G-vec00060-001-s159><specify.angeben><en> When you use the Format parameter, Windows PowerShell retrieves only the properties of the DateTime object that it needs to display the date in the format that you specify.
<G-vec00060-001-s160><specify.angeben><de> 3.2 Die Einhaltung der von uns angegebenen Lieferzeit setzt die Abklärung aller technischer Fragen sowie die rechtzeitige und ordnungsgemäße Erfüllung der Verpflichtungen des Bestellers voraus.
<G-vec00060-001-s160><specify.angeben><en> 3.2 Compliance with the delivery time we specify shall require clarification of all technical issues and the Customer‘s due and proper satisfaction of obligations.
<G-vec00060-001-s161><specify.angeben><de> Konfigurieren Sie beispielsweise bei Verwendung von AWS Regeln für die VPC-Sicherheitsgruppe, sodass Maschinen in der VPC nur den von Ihnen angegebenen IP-Adressen zugänglich sind.
<G-vec00060-001-s161><specify.angeben><en> For example, when using AWS, ensure the VPC's security group has the appropriate rules configured so that machines in the VPC are accessible only to the IP addresses you specify
<G-vec00060-001-s162><specify.angeben><de> Die neue Medien-API-Methode find_modified_videos gibt Videos zurück, die während eines angegebenen Zeitraums geändert wurden.
<G-vec00060-001-s162><specify.angeben><en> A new Media API method, find_modified_videos, returns videos that have been modified during the time span you specify.
<G-vec00060-001-s163><specify.angeben><de> Bei Verwendung des UFormat-Parameters ruft Windows PowerShell nur die Eigenschaften des DateTime-Objekts ab, die zum Anzeigen des Datums in dem von Ihnen angegebenen Format erforderlich sind.
<G-vec00060-001-s163><specify.angeben><en> When you use the UFormat parameter, Windows PowerShell retrieves only the properties of the DateTime object that it needs to display the date in the format that you specify.
<G-vec00060-001-s164><specify.angeben><de> Teillieferungen sind innerhalb der von uns angegebenen Lieferfristen zulässig, soweit sich Nachteile für den Gebrauch daraus nicht ergeben.
<G-vec00060-001-s164><specify.angeben><en> Partial deliveries are permissible within the delivery periods we specify providing these do not result in disadvantages for use.
<G-vec00060-001-s165><specify.angeben><de> Mit dem Dialogfeld Zertifikate suchen können Sie basierend auf von Ihnen angegebenen Kriterien nach Zertifikaten suchen.
<G-vec00060-001-s165><specify.angeben><en> The Find Certificates dialog box allows you to locate certificates based on criteria that you specify.
<G-vec00060-001-s166><specify.angeben><de> Wenn Sie diese Einstellung aktivieren, werden die in dieser Einstellung angegebenen Befehle von Windows blockiert und nicht an das TPM im Computer geleitet.
<G-vec00060-001-s166><specify.angeben><en> If you enable this policy setting, Windows will block the commands you specify in this setting from being sent to the TPM on the computer.
<G-vec00060-001-s084><declare.angeben><de> Dynamische Variablen: Sie können dieses Menü verwenden, um den Typ der dynamischen Variablen anzugeben (siehe Dynamische Variablen).
<G-vec00060-001-s084><declare.angeben><en> Dynamic variables: you can use this menu to declare the type of dynamic variables (see Dynamic variables).
<G-vec00060-001-s085><declare.angeben><de> Es ist somit nicht mehr obligatorisch anzugeben, welches Pferd in welcher Prüfung geht.
<G-vec00060-001-s085><declare.angeben><en> It is no longer compulsory to declare which horse starts in which phase of the competition.
<G-vec00060-001-s086><declare.angeben><de> Sie sind jedoch verpflichtet, diese Mieteinnahme bei Ihrer Steuererklärung anzugeben.
<G-vec00060-001-s086><declare.angeben><en> You are however, obligated to declare the revenue from renting the home on your tax return.
<G-vec00060-001-s087><declare.angeben><de> Aber der stellvertretende Vorsitzende versäumte diesen Interessenkonflikt in der obligatorischen jährlichen Offenlegungserklärung anzugeben.
<G-vec00060-001-s087><declare.angeben><en> But the vice-chair also does not declare this interest in the mandatory annual disclosure statement.
<G-vec00060-001-s088><declare.angeben><de> Unter bestimmten Umständen ist es durchaus sinnvoll, den Vertragsnamen direkt anzugeben.
<G-vec00060-001-s088><declare.angeben><en> It makes sense to declare contract name directly under certain circumstances.
<G-vec00060-001-s089><declare.angeben><de> ME Wenn solche Werke, ob in privatem oder in öffentlichem Besitz, öffentlich in Museen ausgestellt werden, sollte die jeweilige Institution unmittelbar verpflichtet sein, die Herkunft der Werke anzugeben.
<G-vec00060-001-s089><declare.angeben><en> ME Whether privately or publicly owned, when such works go on public display in museums, the respective institution should be immediately obliged to declare the work's origins.
<G-vec00060-001-s219><indicate.angeben><de> In diesem Fall hat er zusätzlich Namen und Anschrift des Vertretenen anzugeben.
<G-vec00060-001-s219><indicate.angeben><en> In this case, he must also indicate the name and address of the party he is representing.
<G-vec00060-001-s220><indicate.angeben><de> Artikel 8- Personen und Organisationen haben bei der Antragstellung im Gouvernement zur Einholung einer Erlaubnis für private Sicherheitsdienstleistung anzugeben, wie dieser Dienst ausgeführt wird, wie viel Personal eingestellt wird, welche Waffen in welcher Anzahl benötigt werden.
<G-vec00060-001-s220><indicate.angeben><en> Article 8- At their application to be made to the governorship for private security permit, the persons and institutions shall indicate the subject of the private security service, the method of performance of the private security, with maximum how many personnel will be used to perform the service, the amount and nature of the required weapons and equipment if any.
<G-vec00060-001-s221><indicate.angeben><de> Wann immer Sie gefragt werden ein Formular auf dieser Webseite auszufüllen, halten Sie ausschau nach einem Kästchen, das Sie anklicken können, um anzugeben, dass Sie nicht möchten, dass die Daten von jemanden zu Werbezwecken genutzt werden sollen.
<G-vec00060-001-s221><indicate.angeben><en> whenever you are asked to fill in a form on the website, look for the box that you can click to indicate that you do not want the information to be used by anybody for direct marketing purposes
<G-vec00060-001-s222><indicate.angeben><de> Um von diesem Angebot zu profitieren, vergessen Sie nicht, den folgenden Verweis, bei der Bestellung, anzugeben: Dept M.
<G-vec00060-001-s222><indicate.angeben><en> To take advantage of this offer please indicate the following reference: Dept M.
<G-vec00060-001-s223><indicate.angeben><de> In dem vom Bittsteller zu unterfertigenden Dispensgesuch sind außer Namen und allgemeinen Lebensdaten auch zumindest in Umrissen die Tatsachen und Argumente anzugeben, auf die der Bittsteller sein Ansuchen stützt.
<G-vec00060-001-s223><indicate.angeben><en> The signed petition must indicate the petitioner’s name, general information about him and at least in general the facts and arguments on which his petition is based.
<G-vec00060-001-s224><indicate.angeben><de> Der Hersteller hat die Betriebsbedingungen der Maschine während des Meßvorgangs sowie die angewendeten Meßverfahren anzugeben.
<G-vec00060-001-s224><indicate.angeben><en> The manufacturer must indicate the operating conditions of the machinery during measurement and which methods were used for taking the measurements;
<G-vec00060-001-s225><indicate.angeben><de> Beides gleichzeitig anzugeben macht ja keinen Sinn.
<G-vec00060-001-s225><indicate.angeben><en> Both to indicate at the same time makes no sense.
<G-vec00060-001-s226><indicate.angeben><de> Liegen die Voraussetzungen für die Inanspruchnahme einer Priorität vor und will der Anmelder die Priorität beanspru-chen, so ist in dem vorgesehenen Feld anzugeben, aus welcher Voranmeldung oder Schaustellung des Gegenstandes die beanspruchte Priorität hergeleitet wird.
<G-vec00060-001-s226><indicate.angeben><en> If the requirements for claiming priority are met, and if the applicant wishes to claim priority, he shall indicate in the appropriate box on which earlier application or exhibition the priority is based.
<G-vec00060-001-s227><indicate.angeben><de> Es ist Möglich anzugeben, dass das Lade-Bild transparent sein soll.
<G-vec00060-001-s227><indicate.angeben><en> It is possible to indicate that the loading image must be transparent.
<G-vec00060-001-s228><indicate.angeben><de> Dafür hat sie eine eigene Lehre, ein Lehrgebäude aufgestellt, das es ihr ermöglicht, die soziale Wirklichkeit zu analysieren, sie zu beurteilen und Richtlinien für eine gerechte Lösung der daraus entstehenden Probleme anzugeben.
<G-vec00060-001-s228><indicate.angeben><en> She formulates a genuine doctrine for these situations, a corpus which enables her to analyze social realities, to make judgments about them and to indicate directions to be taken for the just resolution of the problems involved.
<G-vec00060-001-s229><indicate.angeben><de> Geschützte Trennstriche werden in Wortzusammensetzungen verwendet, um anzugeben, dass beide Wörter zusammen mit dem Trennstrich als ein einziges Wort behandelt werden sollen, wenn der Text-Editor eine Trennung vornehmen möchte.
<G-vec00060-001-s229><indicate.angeben><en> Non-breaking hyphens are used in compound words to indicate that both words and the hyphen should be treated as a single word when the text editor is forming lines.
<G-vec00060-001-s230><indicate.angeben><de> Auf einigen IKRK-Formularen, zum Beispiel beim Formular für Online-Spenden, werden Sie aufgefordert anzugeben, ob Sie Informationen über das IKRK per E-Mail erhalten möchten.
<G-vec00060-001-s230><indicate.angeben><en> On some ICRC forms, such as that for online donations, you are invited to indicate whether you are interested in receiving information via e-mail about the ICRC.
<G-vec00060-001-s231><indicate.angeben><de> Manche Leute vergessen beim Kreditantrag beispielsweise die Einnahmen ihres Nebenjobs anzugeben.
<G-vec00060-001-s231><indicate.angeben><en> Some people forget to indicate at the loan application, e.g. the income of their part-time job .
<G-vec00060-001-s232><indicate.angeben><de> DE 0031: Dieses Datenelement wird benutzt, um anzugeben, ob eine Bestätigung gefordert wird.
<G-vec00060-001-s232><indicate.angeben><en> DE 0031: This data element is used to indicate whether an acknowledgement to the interchange is required or not.
<G-vec00060-001-s233><indicate.angeben><de> Bei Verwendung anderer Maßeinheiten in Abbildungen und Tabellen sind die Umrechnungsfaktoren in der Legende anzugeben.
<G-vec00060-001-s233><indicate.angeben><en> If other units of measure are used in figures and tables, please indicate the conversion factors in the legend.
<G-vec00060-001-s234><indicate.angeben><de> """Wir haben zudem in neue Schallpegelmessgeräte investiert, welche es uns ermöglichen, den Geräuschpegel unserer Ventilatoren anzugeben, was hinsichtlich der Umweltverträglichkeit immer öfter erforderlich ist."
<G-vec00060-001-s234><indicate.angeben><en> """We have also invested in new sound level measuring equipment that now allows us to indicate the noise level of our fans, which is an increasing requirement in relation to environmental compatibility."
<G-vec00060-001-s235><indicate.angeben><de> Obwohl wir unsere Kunden normalerweise nicht anrufen, bitten wir Sie, Ihre korrekte Telefonnummer anzugeben, damit Ihre Bestellung von Address Verification System nicht abgelehnt wird.
<G-vec00060-001-s235><indicate.angeben><en> Though we do not call to our clients generally, we ask you to indicate your correct telephone number for the Address Verification System not to cancel your order.
<G-vec00060-001-s236><indicate.angeben><de> Die Eingabeaufforderung wird auch geändert, um anzugeben, dass die Steuerung beim Debugger liegt.
<G-vec00060-001-s236><indicate.angeben><en> The command prompt also changes to indicate that the debugger has control.
<G-vec00060-001-s237><indicate.angeben><de> Um ein Ziel anzugeben.
<G-vec00060-001-s237><indicate.angeben><en> to indicate destination
<G-vec00060-001-s167><specify.angeben><de> Auswählen einer Anzeigenquelle, um anzugeben, wohin der Player die Anzeigenanforderungen senden soll.
<G-vec00060-001-s167><specify.angeben><en> Set the Ad Source to specify where the player should send its ad requests.
<G-vec00060-001-s168><specify.angeben><de> Dann in der Fügen Sie Arbeitsmappeninformationen ein Dialog, überprüfen Sie die Informationen, die Sie einfügen möchten aus Abschnitt Informationen, dann gehen Sie, um den Ort anzugeben, die Sie einfügen möchten, können Sie Zellen, Fußzeile (linke Fußzeile, mittlere Fußzeile, rechte Fußzeile) oder Kopfzeile (linke Kopfzeile, zentrale Kopfzeile, rechte Überschrift).
<G-vec00060-001-s168><specify.angeben><en> Then in the Insert Workbook Information dialog, check the information you want to insert from Information section, then go to specify the location you want to insert to, you can choose cells, footer (left footer, centre footer, right footer) or header (left header, centre header, right header).
<G-vec00060-001-s169><specify.angeben><de> Abhängig vom gewählten Zahlungssystem werden Sie möglicherweise aufgefordert, auf der nächsten Seite einige zusätzliche Informationen anzugeben, um einen Auszahlungsantrag stellen zu können.
<G-vec00060-001-s169><specify.angeben><en> After that, there will be the second step of the depositing procedure, where you may be asked to specify some additional information according to the requirements of the chosen payment system.
<G-vec00060-001-s170><specify.angeben><de> Wenn E-Mail-Adresse und externe ID nicht in der Logout-URL übergeben werden sollen, bitten Sie Ihren Zendesk-Administrator, in der Admin-Oberfläche im Feld Remote-Logout-URL leere Parameter anzugeben.
<G-vec00060-001-s170><specify.angeben><en> If you prefer not to receive email and external id information in the sign-out URL, ask your Zendesk admin to specify blank parameters in the Remote logout URL field in the admin interface.
<G-vec00060-001-s171><specify.angeben><de> Klicken Sie hier, um den vollständigen Pfad und den Dateinamen für die Fußzeilendatei zu suchen und anzugeben.
<G-vec00060-001-s171><specify.angeben><en> Click to locate and specify the full path and file name for your footer file.
<G-vec00060-001-s172><specify.angeben><de> 1, 2, 3... geeignete Stelle für medizinische Notfallversorgung vom Hersteller /Lieferanten anzugeben.
<G-vec00060-001-s172><specify.angeben><en> 1, 2, 3 …Manufacturer/supplier to specify the appropriate source of emergency medical advice.
<G-vec00060-001-s173><specify.angeben><de> Das Ziel des Kurses ist es, Ingenieure mit Fähigkeiten, Fertigkeiten und Einstellungen, die an der Lösung der Probleme mit den Produkten, Verfahren und Dienstleistungen verbunden sind, wie zu trainieren: Design, Entwicklung und integrierte Systeme von Menschen, Material, Ausrüstung und Informationen zu verwalten; Verwendung aus erworbenen Kenntnisse Ressourcen und Fähigkeiten in der Grundlagenforschung zusammen mit den Prinzipien und Methoden der technischen Analyse und Design, um anzugeben, vorherzusagen und zu bewerten, um die Ergebnisse aus diesen Systemen erhalten werden.
<G-vec00060-001-s173><specify.angeben><en> The aim of the course is to train engineers with abilities, skills and attitudes appropriate to the solution of problems associated with the products, processes and services, such as: design, develop and manage integrated systems of people, materials, equipment and information; Using up resources acquired from knowledge and skills in basic sciences together with the principles and methods of engineering analysis and design to specify, predict and evaluate the results to be obtained from these systems.
<G-vec00060-001-s174><specify.angeben><de> Verwenden Sie die Option Alle Programme, und wählen Sie dann die Registerkarte Programme und Dienste im Dialogfeld Eigenschaften von Firewallregel aus, um einen Dienst in einer Firewallregel anzugeben.
<G-vec00060-001-s174><specify.angeben><en> To specify a service in a firewall rule, use the All programs option, and then select the Programs and Services tab on the Firewall Rule Properties dialog box.
<G-vec00060-001-s175><specify.angeben><de> Ein findiger Flash Profi hat jedoch Abhilfe geschaffen und das kostenlose Tool „UniLauncher“ programmiert, welches ermöglicht, den absoluten oder relativen Pfad zu einem Dokument innerhalb einer INI-Datei anzugeben und somit die Dokumente in einer eigene Ordnerstruktur unterhalb des CD-Root Ordners abzulegen.
<G-vec00060-001-s175><specify.angeben><en> "Fortunately, an Adobe Flash Professional developer has created a tool called ""UniLauncher"", which allows to specify an absolute or relative path to a document within an INI file and so store the document in an own separate folder structure below the CD root folder."
<G-vec00060-001-s176><specify.angeben><de> Ja Ich begegnete einigen Wesen die mich kannten, und umgekehrt, und ich hatte ein Gefühl dass wie einander seit tausenden von Jahren gekannt hatten, aber ich bin nicht fähig ihre Namen anzugeben.
<G-vec00060-001-s176><specify.angeben><en> Yes I encountered some beings who knew me, and the other way around, and I had a feeling that we had known each other for thousands of years, but I am not able to specify their names.
<G-vec00060-001-s177><specify.angeben><de> Unsere Kunden sind nicht verpflichtet anzugeben, wo die Texte veröffentlicht werden.
<G-vec00060-001-s177><specify.angeben><en> Customers are in no way obliged to specify where texts will be published.
<G-vec00060-001-s178><specify.angeben><de> Anzugeben sind die Arbeitgeber-und Arbeitnehmerbeiträge Namen, das Startdatum des Vertrags, der zu verrichtenden Arbeit und die Vergütung im Gegenzug bezahlt werden.
<G-vec00060-001-s178><specify.angeben><en> It should specify the employer's and employee's names, the start date of the contract, the work to be performed and the remuneration to be paid in return.
<G-vec00060-001-s179><specify.angeben><de> Wählen Sie Netzwerk verwendet ein anderes VLAN zur Authentifizierung mit Computer- und Benutzeranmeldeinformationen aus, um anzugeben, dass Drahtloscomputer beim Start in einem virtuellen LAN (VLAN) platziert werden und dann nach der Anmeldung des Benutzers beim Computer in ein anderes Netzwerk übertragen werden.
<G-vec00060-001-s179><specify.angeben><en> To specify that wireless computers are placed on one virtual local area network (VLAN) at startup, and then transitioned to a different network after the user logs on to the computer, select This network uses different VLAN for authentication with machine and user credentials.
<G-vec00060-001-s180><specify.angeben><de> In der IPv6-Welt ist es aber durchaus üblich, die vollständige IP-Adresse anzugeben und mit /nn anzugeben, wieviele Bits davon zum Präfix des Subnetzes gehören.
<G-vec00060-001-s180><specify.angeben><en> In the IPv6 world, it is but common, to specify the full IP address and / nn to specify, How many bits of them belong to the prefix of the subnet.
<G-vec00060-001-s182><specify.angeben><de> Sie können die Schnittstelle Application Cache (AppCache) verwenden, um Ressourcen anzugeben, die der Browser zwischenspeichern und fÃ1⁄4r Offline-Benutzer verfÃ1⁄4gbar machen soll.
<G-vec00060-001-s182><specify.angeben><en> You can use the Application Cache (AppCache) interface to specify resources that the browser should cache and make available to offline users.
<G-vec00060-001-s183><specify.angeben><de> Sie können eine Wochenendnummer auswählen, um anzugeben, welche Wochentage als Wochenenden betrachtet werden, oder dieses Argument ignorieren, um Samstag und Sonntag standardmäßig als Wochenenden zu verwenden.
<G-vec00060-001-s183><specify.angeben><en> You can choose a weekend number to specify which days of the week are considered as weekends, or ignore this argument to take Saturday and Sunday as weekends by default.
<G-vec00060-001-s184><specify.angeben><de> Wenn Sie in einem Hotel außerhalb des angegebenen Bereichs untergebracht sind, senden Sie uns bitte eine E-Mail mit Ihrer Hotel- und Zimmernummer, um sich mit Ihnen in Verbindung zu setzen und den Abholort oder den geeigneten Treffpunkt anzugeben.
<G-vec00060-001-s184><specify.angeben><en> If you are accommodated in a hotel beyond the designated area, please send us an e-mail, with your hotel and room number, to contact you and specify the pick-up place or convenient meeting point.
<G-vec00060-001-s185><specify.angeben><de> Der Grund, warum dieses Anforderung für Latex akzeptabel ist, ist, dass TeX eine Fazilität enthält, die ermöglicht Dateinamen wie Datei ‚Bar‘ verwenden, wenn die Datei ‚Fu‘ angefordert wird anzugeben.
<G-vec00060-001-s185><specify.angeben><en> The reason this requirement is acceptable for LaTeX is that TeX has a facility to allow you to map file names, to specify “use file bar when file foo is requested”.
<G-vec00418-001-s012><brag.angeben><de> Nur wenige Hotels in Dubai können damit angeben, das Burj Al Arab im Hinterhof zu haben.
<G-vec00418-001-s012><brag.angeben><en> Few hotels in Dubai can brag they have the Burj Al Arab in their backyard.
<G-vec00418-001-s013><brag.angeben><de> Er sagte, dass es absurd sei, damit anzugeben, ein großer Yogi-Praktizierender einer bestimmten Buddha-Gestalt zu sein, wenn alles, was man tut oder getan hat, lediglich ein kurzes Retreat dazu mit ein paar hunderttausend Rezitationen der relevanten Mantras ist.
<G-vec00418-001-s013><brag.angeben><en> He said it was absurd to brag about being a great yogi practitioner of a certain Buddha-figure when all one is doing or has done is its short retreat by reciting the relevant mantras a couple hundred thousand times.
<G-vec00060-001-s667><indicate.angeben><de> Bitte geben Sie zudem an, an welchem Tag Sie in den Carolus Thermen waren und in welchem Bereich Sie Ihren Gegenstand vergessen haben.
<G-vec00060-001-s667><indicate.angeben><en> Please also indicate, on which day you visited the Carolus Thermen and in which area you forgot your things.
<G-vec00060-001-s668><indicate.angeben><de> B. in Formularen), geben wir immer an, ob die betreffenden Angaben verpflichtend sind (z.
<G-vec00060-001-s668><indicate.angeben><en> in forms), we will indicate whether the provision of such data is mandatory (e.g.
<G-vec00060-001-s669><indicate.angeben><de> Bitte geben Sie an, ob sie 2 Einzelbetten oder 1 Doppelbett bevorzugen.
<G-vec00060-001-s669><indicate.angeben><en> Guests are kindly asked to indicate whether they prefer 2 single beds or 1 double bed.
<G-vec00060-001-s670><indicate.angeben><de> grau Pflegehinweise: Die angeführten Pflegesymbole geben nicht die empfohlene sondern die maximal zulässige Behandlungsstufe für die jeweiligen Textilien an.
<G-vec00060-001-s670><indicate.angeben><en> Â grey Care Instructions: The care symbols do not indicate the recommended treatment but the maximum permissible level for the respective fabrics.
<G-vec00060-001-s671><indicate.angeben><de> "Die Informationsgesuche geben an, die in den letzten monaten bekommen wir haben, dass das Know-how viel erfordert ist"", das erworben wir haben."
<G-vec00060-001-s671><indicate.angeben><en> "The demands for information that we have received in recent months indicate that the know-how-how that we have acquired is a lot demanded""."
<G-vec00060-001-s672><indicate.angeben><de> marineblau Pflegehinweise: Die angeführten Pflegesymbole geben nicht die empfohlene sondern die maximal zulässige Behandlungsstufe für die jeweiligen Textilien an.
<G-vec00060-001-s672><indicate.angeben><en> Care Instructions: The care symbols do not indicate the recommended treatment but the maximum permissible level for the respective fabrics.
<G-vec00060-001-s673><indicate.angeben><de> Geben Sie im Dialogfeld Controller hinzufügen oder Controller bearbeiten einen Namen ein, über den Sie die Bereitstellung identifizieren können, und geben Sie an, ob die Ressourcen, die Sie im Store verfügbar machen möchten, von XenDesktop, XenApp oder AppController bereitgestellt werden.
<G-vec00060-001-s673><indicate.angeben><en> In the Add Controller or Edit Controller dialog box, specify a name that will help you to identify the deployment and indicate whether the resources that you want to make available in the store are provided by XenDesktop, XenApp, or AppController.
<G-vec00060-001-s674><indicate.angeben><de> Positive Werte geben an, dass die Anfrage erfolgreich war, aber weitere Informationen in res/return_code/@message enthalten sind.
<G-vec00060-001-s674><indicate.angeben><en> Positive values indicate that the request succeeded with additional information, contained in res/return_code/@message as well.
<G-vec00060-001-s675><indicate.angeben><de> Eckige Klammern geben ein impliziertes OR an.
<G-vec00060-001-s675><indicate.angeben><en> Square brackets indicate an implied OR.
<G-vec00060-001-s676><indicate.angeben><de> In der Elektronischen Zeitschriftenbibliothek (EZB) geben gelb/rote Ampeln an, dass nur ein Teil der erschienenen Jahrgänge im Volltext zugänglich sind.
<G-vec00060-001-s676><indicate.angeben><en> In the Electronic Journals Library (EZB), yellow/red lights indicate that only some of the published volumes are accessible as full texts.
<G-vec00060-001-s677><indicate.angeben><de> Wenn Sie lokalen Speicher auf dem Hypervisor wählen, geben Sie an, ob Sie persönliche Daten (persönliche vDisks) im freigegebenen Speicher verwalten möchten.
<G-vec00060-001-s677><indicate.angeben><en> If you choose storage local to the hypervisor, indicate if you want to manage personal data (personal vDisks) on shared storage.
<G-vec00060-001-s678><indicate.angeben><de> Die neuen Akzente in der Außenpolitik, namentlich das Embargo gegen Gaza zu lockern und wieder diplomatische Beziehungen zum Iran aufzunehmen, geben die Bewegungsrichtung an.
<G-vec00060-001-s678><indicate.angeben><en> The first new accents in foreign policy, namely to soften the embargo on Gaza and to resume ties with Tehran, indicate a clear direction.
<G-vec00060-001-s679><indicate.angeben><de> Bitte geben Sie an, ob Sie sich als Teilnehmer*in oder Beobachter*in anmelden möchten.
<G-vec00060-001-s679><indicate.angeben><en> Please indicate whether you would like to register as a participant or observer.
<G-vec00060-001-s680><indicate.angeben><de> Wählen Sie die Farbe aus und geben Sie es in der Observierung des Warenkorbs an.
<G-vec00060-001-s680><indicate.angeben><en> Choose the color and indicate it in the comments of the shopping cart.
<G-vec00060-001-s681><indicate.angeben><de> Weiße Balken geben an, dass der Oregon noch Daten sammelt.
<G-vec00060-001-s681><indicate.angeben><en> White bars indicate that the Oregon is still collecting data.
<G-vec00060-001-s682><indicate.angeben><de> Geben Sie hierzu unter dem Menüpunkt Sources | Add Directory den Namen der Dateien ein und geben Sie an, in welchem Verzeichnis sie sich befinden.
<G-vec00060-001-s682><indicate.angeben><en> Select the menu item: Sources | Add Directory, enter the name of the group of files, and indicate the directory in which the dbx files are located.
<G-vec00060-001-s683><indicate.angeben><de> Kontaktieren Sie uns bitte über den Kundenservice und geben Sie an, was Sie suchen.
<G-vec00060-001-s683><indicate.angeben><en> please contact us via customer service and indicate what you are looking for.
<G-vec00060-001-s684><indicate.angeben><de> Geben Sie diese in dieser Form vor Ihrer Ankunft an.
<G-vec00060-001-s684><indicate.angeben><en> Indicate this in this form before your arrival.
<G-vec00060-001-s685><indicate.angeben><de> Daher geben die Produkte bereits die Größen an, die sie nach dem Waschen erhalten.
<G-vec00060-001-s685><indicate.angeben><en> Therefore, the products already indicate the sizes that they will acquire after washing.
<G-vec00060-001-s481><specify.angeben><de> Hersteller kerzenzentrierter Artikel geben oft den Typ und / oder die Größe der Kerze an, die empfohlen wird.
<G-vec00060-001-s481><specify.angeben><en> Manufacturers of candle-centric items often specify the type and/or size of candle that is recommended.
<G-vec00060-001-s482><specify.angeben><de> Die Dienstleister geben bei der Buchung an, wie viele Paletten sie anliefern.
<G-vec00060-001-s482><specify.angeben><en> When booking, the service providers specify how many pallets they deliver.
<G-vec00060-001-s483><specify.angeben><de> displayWidth Breite_in_Pixeln displayHeight Höhe_in_Pixeln displayGeometry Breite xHöhe geben den rechteckigen Bereich an, in dem die Wiedergabe dargestellt werden soll.
<G-vec00060-001-s483><specify.angeben><en> displayWidth width_in_pixels displayHeight height_in_pixels displayGeometry width xheight specify the rectangular area, in which the playback is displayed.
<G-vec00060-001-s484><specify.angeben><de> Dazu rufen Sie get_comment_meta auf und geben die Kommentar-ID und den MetaschlÃ1⁄4ssel an.
<G-vec00060-001-s484><specify.angeben><en> To do this, you would make a call to get_comment_meta and you'd specify the comment ID and the meta key.
<G-vec00060-001-s485><specify.angeben><de> Über diesen Eintrag geben Sie den Konnektivitäts-Status Ihres Gerätes mit dem Internet an.
<G-vec00060-001-s485><specify.angeben><en> Using this entry, you specify the connectivity status of your device to the Internet.
<G-vec00060-001-s486><specify.angeben><de> Bitte geben Sie Packstück-Nummer an.
<G-vec00060-001-s486><specify.angeben><en> Please specify the serial no.
<G-vec00060-001-s487><specify.angeben><de> VORSICHT: Wenn Sie einen Kreuzschlitzschraubendreher benötigen, geben Sie dies bitte an.
<G-vec00060-001-s487><specify.angeben><en> CAUTION: If you require a Phillips screwdriver, please specify.
<G-vec00060-001-s488><specify.angeben><de> Geben Sie im Dialogfeld Arbeitsblätter kombinieren - Schritt 3 von 3 die Kombinationsregel nach Bedarf an und klicken Sie auf Fertigstellung klicken.
<G-vec00060-001-s488><specify.angeben><en> In the Combine Worksheets - Step 3 of 3 dialog box, please specify the combination rule as you need, and click the Finish button.
<G-vec00060-001-s489><specify.angeben><de> Bitte geben Sie einen Drucker an und klicken Sie auf Drucken Taste.
<G-vec00060-001-s489><specify.angeben><en> Please specify a printer, and click the Print button.
<G-vec00060-001-s490><specify.angeben><de> In diesem Schritt geben Sie an, ob Sie nur externen Benutzerzugriff oder nur internen Benutzerzugriff auf Ihre Site über Citrix Workspace erlauben.
<G-vec00060-001-s490><specify.angeben><en> In this step, you specify whether you want to allow only external user access or internal-only access to your Site through Citrix Workspace.
<G-vec00060-001-s491><specify.angeben><de> Geben Sie beim Drucken einer Kalibrierungsseite für die Nachkalibrierung die Messmethode, das Messfeldlayout und die Papierquelle an.
<G-vec00060-001-s491><specify.angeben><en> When you print a calibration page for recalibration, specify the measurement method, patch set, and paper source.
<G-vec00060-001-s492><specify.angeben><de> Bitte geben Sie in ihrer Bestellung ihre gültige email Adresse an.
<G-vec00060-001-s492><specify.angeben><en> Please specify a valid email address in your order.
<G-vec00060-001-s493><specify.angeben><de> Bitte geben Sie bei Ihrer Buchung Ihre bevorzugte Bettenart an.
<G-vec00060-001-s493><specify.angeben><en> Please specify bed preference when booking.
<G-vec00060-001-s494><specify.angeben><de> Name Bitte geben Sie Ihren vollständigen Namen an.
<G-vec00060-001-s494><specify.angeben><en> Mr. Name Please specify your full name.
<G-vec00060-001-s495><specify.angeben><de> Auf der Editiermaske geben Sie ein oder zwei Ausgangsprodukte und ein oder zwei Endprodukte an.
<G-vec00060-001-s495><specify.angeben><en> On the edit mask you specify one or two source products and one or two end products.
<G-vec00060-001-s496><specify.angeben><de> "%%vskip 12pt %%text Im Gegensatz zu Quelle a), geben die Quellen b) und c) auch unzweideutig die Akzidentien %%text (""musica ficta"") an."
<G-vec00060-001-s496><specify.angeben><en> "%%vskip 12pt %%text In contrast to source a), the sources b) and c) also specify uniquely the accidentals (""musica ficta"")."
<G-vec00060-001-s497><specify.angeben><de> Als digitale Signatur verwenden: Geben Sie an, ob das Zertifikat als digitale Signatur verwendet werden soll.
<G-vec00060-001-s497><specify.angeben><en> Use as digital signature: Specify whether you want the certificate to be used as a digital signature.
<G-vec00060-001-s498><specify.angeben><de> Routing-Tag: Geben Sie hier das Routing-Tag des Netzes an, zu dem die Loopback-Adresse gehört.
<G-vec00060-001-s498><specify.angeben><en> Routing tag: Here you specify the routing tag of the network that the loopback address belongs to.
<G-vec00060-001-s499><specify.angeben><de> Diese Werte geben an, ob CredSSP als Client oder als Server deaktiviert werden soll.
<G-vec00060-001-s499><specify.angeben><en> These values specify whether CredSSP should be disabled as a client or as a server.
<G-vec00060-001-s703><indicate.angeben><de> Gut zu wissen: Der Hersteller gibt auf der Verpackung eventuell noch die gerundeten Maße an.
<G-vec00060-001-s703><indicate.angeben><en> Good to know: The manufacturer may also indicate the rounded dimensions on the packaging.
<G-vec00060-001-s704><indicate.angeben><de> Die Kommission setzt eine angemessene Frist, bis zu deren Ablauf der/die Zulassungsinhaber weitere Informationen vorlegen kann/können, die für eine Überprüfung erforderlich sind, und sie gibt an, bis wann sie eine Entscheidung nach Artikel 64 treffen wird.
<G-vec00060-001-s704><indicate.angeben><en> The Commission shall set a reasonable deadline by which the holder(s) of the authorisation may submit further information necessary for the review and indicate by when it will take a decision in accordance with Article 64.
<G-vec00060-001-s705><indicate.angeben><de> "Nicht genug,- hat das Professor Senn erklärt,- weil die Achtung auf dem Übergang von den Waren von der Straße zu der Eisenbahn gibt die sehr wichtige soziale und umwelt- Ersparnis an: die minori Kosten von den Zwischenfällen und dem Stau von dem Verkehr assommano zu 600 Millionen Euro, jen für die Luftverschmutzung und die Emissionen von CO2 von ungefähr 300 Millionen Euro,""."
<G-vec00060-001-s705><indicate.angeben><en> "Not enough - it has explained professor Senn - because the esteem on the passage of the goods from the road to the railroad indicate important social and environmental savings a lot: the smaller costs from incidents and congestion of the traffic emerge to 600 million euros, those for the air pollution and the emissions of co2 of approximately 300 million euros""."
<G-vec00060-001-s706><indicate.angeben><de> Der Wert 'Kurve' gibt an, wie sehr der Himmel gekrümmt sein soll (kann entweder positiv oder negativ sein).
<G-vec00060-001-s706><indicate.angeben><en> The curve value indicate how much the sky should be curved (can be either negative or positive).
<G-vec00060-001-s707><indicate.angeben><de> Wenn aktiviert, gibt der Chronographen -12-Stunden-Zähler 1/10 Sekunden bis zu 30 Minuten an, bei 6 Stunden ist der 30-Minuten-Zähler und das 9-Stunden-Zifferblatt bis zu 10 Stunden.
<G-vec00060-001-s707><indicate.angeben><en> When activated, the chronograph 12-hour counter indicate 1/10 seconds up to 30 minutes, at 6-hour is the 30 minute counter, and 9-hour sub dial indicate up to 10 hours.
<G-vec00060-001-s708><indicate.angeben><de> Reichen die Informationen nicht aus, um zu entscheiden, ob ein Stoff für einen bestimmten Endpunkt eingestuft werden sollte, so gibt der Registrant die von ihm daraufhin getroffene Maßnahme oder Entscheidung an und begründet sie.
<G-vec00060-001-s708><indicate.angeben><en> If the information is inadequate to decide whether a substance should be classified for a particular end-point, the registrant shall indicate and justify the action or decision he has taken as a result.
<G-vec00060-001-s709><indicate.angeben><de> Bei der Einholung des Einverständnisses gibt das zuständige Gericht oder die zuständige Behörde die ungefähre Höhe der Kosten an, die durch dieses Verfahren entstehen.
<G-vec00060-001-s709><indicate.angeben><en> When seeking such consent, the competent court or authority shall indicate the approximate costs which would result from this procedure.
<G-vec00060-001-s710><indicate.angeben><de> Dabei gibt es die Stelle der Auslassung und die Zahl der ausgelassenen Wörter an und stellt auf Antrag eine Abschrift der ausgelassenen Stellen zur Verfügung.
<G-vec00060-001-s710><indicate.angeben><en> It shall indicate the place and number of words omitted, and shall furnish, upon request, a copy of the passages omitted.
<G-vec00060-001-s711><indicate.angeben><de> Im Vorwort gibt er sehr präzise seine Quellen an, was im Mittelalter absolut nicht üblich war.
<G-vec00060-001-s711><indicate.angeben><en> In the premise he is careful to indicate his sources, something that was not usual in the Middle Ages.
<G-vec00060-001-s712><indicate.angeben><de> Die Gebrauchsanweisung gibt deutlich an, bei welchem Druck Enap angewendet wird.
<G-vec00060-001-s712><indicate.angeben><en> The instructions for use clearly indicate at which pressure Enap is applied.
<G-vec00060-001-s713><indicate.angeben><de> Die Anzahl der Verbindungen gibt an, wie viele Geräte Sie gleichzeitig in Ihrem VPN-Abonnement schützen können.
<G-vec00060-001-s713><indicate.angeben><en> The number of connections indicate how many devices you can simultaneously protect on your VPN subscription.
<G-vec00060-001-s714><indicate.angeben><de> In einer anderen Aufstellung gibt die offizielle Statistik für 1933 mehr als 860.000 Administratoren und Spezialisten an für die Sowjetwirtschaft insgesamt, davon in der Industrie über 480.000, im Transportwesen über 100.000, in der Landwirtschaft 93.000, im Handel 25.000.
<G-vec00060-001-s714><indicate.angeben><en> In another cross-section the official statistics indicate for 1933 more than 860,000 administrators and specialists in the whole Soviet economy – in industry over 480,000, in transport over 100,000, in agriculture 93,000, in commerce 25,000.
<G-vec00060-001-s715><indicate.angeben><de> (5) Unterliegen die Maschinen anderen Gemeinschaftsrichtlinien über andere Aspekte, so gibt das EG-Zeichen des Artikels 10 in diesen Fällen an, daß die Maschinen auch den Anforderungen dieser anderen Richtlinien entsprechen.
<G-vec00060-001-s715><indicate.angeben><en> Where the machinery is subject to other Community Directives concerning other aspects, the EC mark referred to in Article 10 shall indicate in these cases that the machinery also fulfils the requirements of the other Directives.
<G-vec00060-001-s716><indicate.angeben><de> Bei der Einholung des Einverständnisses des Europäischen Patentamts gibt das zuständige Gericht oder die zuständige Behörde die ungefähre Höhe der Kosten an, die durch dieses Verfahren entstehen.
<G-vec00060-001-s716><indicate.angeben><en> When seeking the consent of the European Patent Office, the competent authority shall indicate the approximate costs which would result from this procedure.
<G-vec00060-001-s717><indicate.angeben><de> Er gibt an, welche für ihn jeweils die höchste und welche die niedrigste Präferenz hat.
<G-vec00060-001-s717><indicate.angeben><en> They indicate in each case which level has the highest and which one has the lowest preference.
<G-vec00060-001-s718><indicate.angeben><de> Anders die Alumni und Studenten selbst, die ein heterogenes Bild skizzieren: Ein Drittel gibt zwar Mobilität als wichtig an, ein anderes Drittel sucht durchaus Ortsbindung.
<G-vec00060-001-s718><indicate.angeben><en> The alumni and students, by contrast, paint a heterogeneous picture: while one third indicate that mobility is important, another third are keen to stay in one place.
<G-vec00060-001-s620><specify.angeben><de> Dieser Abschnitt beschreibt, wie Sie Vorschub-Daten und nicht graphisch darstellbare Zeichen in DNC-Max angeben können.
<G-vec00060-001-s620><specify.angeben><en> This section describes how to specify feed data and non-printable characters in DNC-Max.
<G-vec00060-001-s621><specify.angeben><de> HTML-Interpretation: Wenn Sie einen zufälligen String angeben wollen, mÃ1⁄4ssen Sie ihn in die doppelte AnfÃ1⁄4hrungszeichen einschließen und htmlspecialchars() auf den gesamten Wert anwenden.
<G-vec00060-001-s621><specify.angeben><en> In order to specify a random string, you must include it in double quotes, and htmlspecialchars() the whole value.
<G-vec00060-001-s622><specify.angeben><de> Daher können Sie in der Bedeutung die Kostenrechnungsaufteilung erfassen, wobei Sie die Höhe der Beträge als Prozentwerte für die Aufteilung angeben.
<G-vec00060-001-s622><specify.angeben><en> You can therefore enter the cost allocation in the explanation and specify the amounts as percentage values for the allocation.
<G-vec00060-001-s623><specify.angeben><de> Schritt-für-Schritt-Anleitungen zur Verwendung der Ordnerumleitung finden Sie unter Angeben des Speicherorts der Ordner in einem Benutzerprofil.
<G-vec00060-001-s623><specify.angeben><en> For step-by-step information about how to use folder redirection, see Specify the Location of Folders in a User Profile.
<G-vec00060-001-s624><specify.angeben><de> HTML-Interpretation: Wenn Sie einen zufälligen String angeben wollen, müssen Sie ihn in die doppelte Anführungszeichen einschließen und htmlspecialchars() auf den gesamten Wert anwenden.
<G-vec00060-001-s624><specify.angeben><en> In order to specify a random string, you must include it in double quotes, and htmlspecialchars() the whole value.
<G-vec00060-001-s625><specify.angeben><de> Nachdem Sie Ihre Subdomäne als Alias Ihrer Standard-Zendesk-Adresse eingerichtet haben, müssen Sie die neue Adresse in Ihrer Instanz von Zendesk Support angeben.
<G-vec00060-001-s625><specify.angeben><en> After making your subdomain an alias of your default Zendesk address, you need to specify the new address in your instance of Zendesk Support.
<G-vec00060-001-s626><specify.angeben><de> So stellen Sie sicher, um herauszufinden, was Sie und Ihr Mann Blut (vergessen Sie nicht die Art und Rh angeben).
<G-vec00060-001-s626><specify.angeben><en> So make sure to find out what you and your husband's blood (do not forget to specify the type and Rh).
<G-vec00060-001-s627><specify.angeben><de> Lassen Sie die angeben.
<G-vec00060-001-s627><specify.angeben><en> Allow’s specify.
<G-vec00060-001-s628><specify.angeben><de> Achten Sie darauf, dass Sie diese Option nach dem „ --- “ angeben, so dass diese Option auch in die Bootloader-Konfiguration des installierten Systems kopiert wird (falls vom Bootloader-Installer unterstützt).
<G-vec00060-001-s628><specify.angeben><en> Be sure to specify this option after “ --- ”, so that it is copied into the bootloader configuration for the installed system (if supported by the installer for the bootloader).
<G-vec00060-001-s629><specify.angeben><de> Im unteren Teil des Rücksendeformulars, das dem Paket beiliegt, können Sie angeben, warum Sie den Artikel umtauschen möchten und welchen Artikel Sie stattdessen erhalten möchten.
<G-vec00060-001-s629><specify.angeben><en> In the lower part of the return form that is included with your package, you can specify why and to what you want the product exchanged.
<G-vec00060-001-s630><specify.angeben><de> Hier können Sie die für Sie ihre gewünschten Themengebiete angeben.
<G-vec00060-001-s630><specify.angeben><en> Mobile phone Here you can specify your desired topics.
<G-vec00060-001-s631><specify.angeben><de> Notieren Sie das SQL Server-Kontokennwort, das Sie bei der XenMobile Server-Installation angeben.
<G-vec00060-001-s631><specify.angeben><en> Record the SQL server account password that you specify during XenMobile Server installation.
<G-vec00060-001-s632><specify.angeben><de> Die Nutzer Award Tasten-Rekorder für Mac können Sie angeben, eine Liste der computer-Nutzer, will er überwachen.
<G-vec00060-001-s632><specify.angeben><en> The user of Award Keylogger for Mac can specify a list of computer users he wants to monitor.
<G-vec00060-001-s633><specify.angeben><de> Füllen Sie das Formular aus, wobei Sie die Art der Anfrage angeben (Handel, Einkauf, Verwaltung, Marketing), und unsere entsprechende Abteilung wird Ihnen so schnell wie möglich antworten.
<G-vec00060-001-s633><specify.angeben><en> Fill the form below and specify your type of request (commercial, purchase, administration, marketing), we will come reply you soon.
<G-vec00060-001-s634><specify.angeben><de> Nachdem Sie diese Option ausgewählt haben, können Sie angeben, ob die Seitenquelle über HTTP/FTP, REST oder SOAP abgerufen wird (siehe Abbildung unten).
<G-vec00060-001-s634><specify.angeben><en> After you select this option you can specify whether the page source will be obtained using HTTP/FTP, REST, or SOAP (see screenshot below).
<G-vec00060-001-s635><specify.angeben><de> Mit den optionalen Klauseln FIRSTNAME, MIDDLENAME und LASTNAME können Sie weitere Benutzereigenschaften wie den Vornamen der Person, den Vornamen und den Nachnamen angeben.
<G-vec00060-001-s635><specify.angeben><en> The optional FIRSTNAME, MIDDLENAME and LASTNAME clauses can be used to specify additional user properties, such as the person's first name, middle name and last name, respectively.
<G-vec00060-001-s636><specify.angeben><de> Soundtrack beschlossen, ubernehmen die kostenlose Lizenz, mussen Sie nur den Namen des Kunstlers angeben mussen.
<G-vec00060-001-s636><specify.angeben><en> It was decided to take free license soundtrack, where was required to specify only the name of the artist.
<G-vec00060-001-s637><specify.angeben><de> Wenn es bei einem Fahrzeugmodell verschiedene Dachvarianten gibt, müssen Sie auch den Dachtyp Ihres Autos angeben.
<G-vec00060-001-s637><specify.angeben><en> Where a car model has several roof variations you will need to specify the roof type of your specific car as well.
<G-vec00060-001-s638><specify.angeben><de> Wählen Sie auf der Seite Zieltyp angeben die Option Sicherung auf einem freigegebenen Netzwerkorder erstellen aus.
<G-vec00060-001-s638><specify.angeben><en> On the Specify Destination Type page, select Back up to a shared network folder.
<G-vec00060-001-s639><specify.angeben><de> Wenn Sie die Option –field verwenden, brauchen Sie keine OPF-Datei anzugeben.
<G-vec00060-001-s639><specify.angeben><en> If you use the –field option, there is no need to specify an OPF file.
<G-vec00060-001-s640><specify.angeben><de> Verwenden Sie Menüs und Schaltflächen unterhalb des Felds „Text“, um Textattribute wie Schriftart, Größe, Ausrichtung und Textrotation anzugeben.
<G-vec00060-001-s640><specify.angeben><en> Use menus and buttons below the Text field to specify text attributes such as font, size, alignment, and text rotation.
<G-vec00060-001-s641><specify.angeben><de> Bitte Vergessen Sie nicht, die Größe Ihres Logos in Pixel anzugeben, und für einen Ausdruck guter Qualität nehmen Sie bitte ein Bild von wenigstens 150 DPI.
<G-vec00060-001-s641><specify.angeben><en> Do not forget to specify the size of your logo in pixel and for a good printing quality, please take an image of at least 150 DPI.
<G-vec00060-001-s642><specify.angeben><de> Verwenden Sie dieses Feld, um die Anfrage für das Verzeichnis der FTP-Übertragungen anzugeben.
<G-vec00060-001-s642><specify.angeben><en> Use this field to specify the request directory for FTP transfers.
<G-vec00060-001-s643><specify.angeben><de> In dieser Erklärung hat sie die Artikel oder Absätze des Teils II der Charta anzugeben, die sie für die in der Erklärung bezeichneten Hoheitsgebiete als bindend anerkennt.
<G-vec00060-001-s643><specify.angeben><en> It shall specify in the declaration the articles or paragraphs of Part II of the Charter which it accepts as binding in respect of the territories named in the declaration.
<G-vec00060-001-s644><specify.angeben><de> Verwenden Sie diese Seite, um eine IP-Adresse, ein Subnetz oder einen IP-Adressbereich anzugeben.
<G-vec00060-001-s644><specify.angeben><en> Use this page to specify an IP address, a subnet, or a range of IP addresses.
<G-vec00060-001-s645><specify.angeben><de> Verwenden Sie das href -Attribut, um die Ziel-URL anzugeben.
<G-vec00060-001-s645><specify.angeben><en> Use the href attribute to specify the target URL.
<G-vec00060-001-s646><specify.angeben><de> Verwenden Sie die Registerkarte Bereich, um eine IP-Adresse, ein Subnetz oder einen IP-Adressbereich anzugeben.
<G-vec00060-001-s646><specify.angeben><en> Use the Scope tab to specify an IP address, a subnet, or a range of IP addresses.
<G-vec00060-001-s647><specify.angeben><de> Verwenden Sie diese Liste, um die GPO-Ausschlussverzeichnisse anzugeben, ohne sie manuell ausfüllen zu müssen.
<G-vec00060-001-s647><specify.angeben><en> Use this policy to specify GPO exclusion directories without having to fill them in manually.
<G-vec00060-001-s648><specify.angeben><de> Verwenden Sie das folgende Verfahren, um den Remotedesktop-Lizenzierungsmodus für den Server mit dem Host für Remotedesktopsitzungen mithilfe der Konfiguration des Hosts für Remotedesktopsitzungen anzugeben.
<G-vec00060-001-s648><specify.angeben><en> Use the following procedure to specify the Remote Desktop licensing mode for the RD Session Host server by using Remote Desktop Session Host Configuration.
<G-vec00060-001-s649><specify.angeben><de> Sie können jedoch auch das cfmodule-Tag mit dem Attribut template verwenden, um den absoluten Pfad des benutzerdefinierten Tags anzugeben.
<G-vec00060-001-s649><specify.angeben><en> Or, use the cfmodule tag with the template attribute to specify the absolute path to the custom tag.
<G-vec00060-001-s650><specify.angeben><de> Geben Sie einen definierten Namen ein, um den Ausgangspunkt für die Suche anzugeben.
<G-vec00060-001-s650><specify.angeben><en> Type a distinguished name to specify where the search starts.
<G-vec00060-001-s651><specify.angeben><de> Verwenden Sie das folgende Verfahren, um einen Lizenzserver anzugeben, der vom Server mit dem Host für Remotedesktopsitzungen verwendet wird.
<G-vec00060-001-s651><specify.angeben><en> Use the following procedure to specify a license server for the RD Session Host server to use by using the Remote Desktop Session Host Configuration tool.
<G-vec00060-001-s652><specify.angeben><de> Sollte das Projekt mehr als einen Datensatz enthalten, dann werden Sie gebeten anzugeben, welcher davon benutzt werden soll.
<G-vec00060-001-s652><specify.angeben><en> If the project contains more than one Data Set, you are asked to specify which one is to be used.
<G-vec00060-001-s653><specify.angeben><de> Verwenden Sie den Path-Parameter, um die Datei anzugeben.
<G-vec00060-001-s653><specify.angeben><en> Use the Path parameter to specify the file.
<G-vec00418-001-s078><brag.angeben><de> Wenn sich in Ihren Gebinde eine Lösung, Säure, Lauge oder ähnliches befindet, so können Sie in diesen Feldern angeben welche Konzentration die Lösung hat und was das Lösungsmittel ist.
<G-vec00418-001-s078><brag.angeben><en> If in your bundle is a solution, acid, lye or the similar, you can brag in these fields which concentration the solution has and what is the solvent.
<G-vec00218-002-s019><enter.angeben><de> Wenn Sie auf der Website der SBB (Schweizerische Bundesbahnen) Ihren Abfahrtsort und Zielort angeben, wird Ihnen nicht nur die beste Verbindung angezeigt, sondern auch der Fahrpreis.
<G-vec00218-002-s019><enter.angeben><en> If you enter your departure point and destination on the website of Swiss Federal Railways (SBB), you'll be shown the best connection as well as the fare.
<G-vec00218-002-s020><enter.angeben><de> Der Auschecken-Dialog Wenn Sie einen Ordnernamen angeben, der noch nicht existiert, wird dieser Ordner angelegt.
<G-vec00218-002-s020><enter.angeben><en> If you enter a folder name that does not yet exist, then a directory with that name is created.
<G-vec00218-002-s021><enter.angeben><de> Damit die App brauchbare Daten liefert, muss man zuerst Gewicht und Körpergröße angeben.
<G-vec00218-002-s021><enter.angeben><en> To use the app correctly, you'll first have to enter your weight and height.
<G-vec00218-002-s022><enter.angeben><de> Sie müssen lediglich Ihre Forderung einreichen, die Daten Ihres Fluges angeben und sich entspannt zurücklehnen, während wir den Rest für Sie erledigen.
<G-vec00218-002-s022><enter.angeben><en> We take the burden from you and simplify the process. All you need to do is enter your flight details in our easy-to-use compensation checker and we’ll take care of the rest.
<G-vec00218-002-s023><enter.angeben><de> Dazu müssen Sie in der Regel weitere personenbezogene Daten angeben, die wir zur Erbringung der jeweiligen Leistung nutzen und für die zuvor genannten Grundsätze zur Datenverarbeitung gelten.
<G-vec00218-002-s023><enter.angeben><en> Therefore you have to enter further personal data which will be needed for the respective service.
<G-vec00218-002-s024><enter.angeben><de> Die Seite auf der Sie die Daten für Ihre Zahlung angeben ist 100% sicher.
<G-vec00218-002-s024><enter.angeben><en> The payment page on which you enter your card details is entirely secure.
<G-vec00218-002-s025><enter.angeben><de> Als angemeldeter Benutzer müssen Sie nicht jedes Mal Ihre persönlichen Daten angeben, sondern Sie können sich vor oder im Rahmen einer Bestellung einfach mit Ihrer E-Mail-Adresse und dem von Ihnen bei Registrierung frei gewählten Passwort in Ihrem Kundenkonto anmelden.
<G-vec00218-002-s025><enter.angeben><en> With a customer account you must not enter your personal data every time you use our online shop, but you may log on to your customer account before or during an order with your e-mail address and the password, which you have chosen during the registration process.
<G-vec00218-002-s026><enter.angeben><de> Solltest du das Wirtschaftsgut aber über einen kürzeren Zeitraum nutzen und du kannst dies auch nachweisen, so darfst du auch eine kürzere Nutzungsdauer angeben.
<G-vec00218-002-s026><enter.angeben><en> Should you use the asset over a shorter period and you can prove this, then you are allowed to enter a shorter service life.
<G-vec00218-002-s027><enter.angeben><de> Dazu müssen Sie in der Regel weitere personenbezogene Daten angeben, die wir zur Erbringung der jeweiligen Leistung nutzen und für die die zuvor genannten Grundsätze zur Datenverarbeitung gelten.
<G-vec00218-002-s027><enter.angeben><en> As a rule this requires that you enter further personal data which we then use in order to provide the respective service for which the above named regulations on data processing are valid.
<G-vec00218-002-s028><enter.angeben><de> Bitte eine Zeit in üblicher Form angeben und die gewünschte Einheit zur Ausgabe auswählen.
<G-vec00218-002-s028><enter.angeben><en> Please enter a time in common format and choose the unit for the output.
<G-vec00218-002-s029><enter.angeben><de> Wählen Sie auf der Seite Delivery Controller, wie Sie die Adressen der installierten Controller angeben möchten.
<G-vec00218-002-s029><enter.angeben><en> On the Delivery Controller page, choose how you want to enter the addresses of installed Controllers.
<G-vec00218-002-s030><enter.angeben><de> Am Ende der Fahrt wird der Fahrpreis automatisch von der Kreditkarte abgebucht, deren Daten der Nutzer bei seiner Anmeldung zu der App angeben muss.
<G-vec00218-002-s030><enter.angeben><en> Once the trip has been completed, the fare is automatically charged to the bank card which the user is required to enter when signing up to the application.
<G-vec00218-002-s031><enter.angeben><de> In der Adresszeile können Sie die URL des Projektarchivs sowie die Revision, die Sie betrachten wollen, angeben.
<G-vec00218-002-s031><enter.angeben><en> At the top of the Repository Browser Window you can enter the URL of the repository and the revision you want to browse.
<G-vec00218-002-s032><enter.angeben><de> Im Bestellformular können Sie als «Anzahl × CHF 20.-» angeben, wie hoch der Gutscheinbetrag sein soll; es wird ein Gutschein über den Gesamtbetrag zugestellt (min.
<G-vec00218-002-s032><enter.angeben><en> When buying a voucher, the total amount will be multiples of CHF 20 which you have to enter on the order form as «number × CHF 20».
<G-vec00218-002-s033><enter.angeben><de> Wenn Sie eigene Texte angeben möchten, klicken Sie bei Eigene Texte angeben auf Ja, wodurch sich weitere Felder und eine Übersicht an Platzhaltern für Ihren individuellen Zahlungsplan-Text öffnen.
<G-vec00218-002-s033><enter.angeben><en> If you want to enter your own texts, click Yes for Enter your own texts, which will open additional fields and an overview of placeholders for your individual payment plan text.
<G-vec00218-002-s035><enter.angeben><de> Zusätzlich müssen Sie hier nur noch die SID der Instanz angeben und die Version der Datenbank, auf dem sich diese Instanz befindet.
<G-vec00218-002-s035><enter.angeben><en> Additionally, here you only need to enter the instance's SID and the version of the database on which the instance is located.
<G-vec00218-002-s036><enter.angeben><de> Je nach Dienstepaket müssen Sie zur Identifikation noch den exakten Kilometerstand angeben oder erhalten einen 8-stelligen Registrierungscode, welchen Sie im Navigationssystem Ihres Fahrzeugs eingeben müssen.
<G-vec00218-002-s036><enter.angeben><en> Depending on the service bundle, you may have to enter the exact mileage (km) to identify your vehicle. Otherwise, you will receive an 8-digit registration code that you will have to enter into the navigation system of your vehicle.
<G-vec00218-002-s037><enter.angeben><de> Dazu legt der User ein Nutzerprofil an (E-Mail und Passwort) an, zusätzlich kann man aber auch eine Anrede und seinen vollständigen Namen angeben.
<G-vec00218-002-s037><enter.angeben><en> For this purpose, the user creates a user profile (e-mail and password), but the user can also enter a title and/or his or her full name.
<G-vec00301-002-s171><address.angeben><de> Um sich für den Newsletter anzumelden, reicht es aus, wenn Sie Ihre E-Mailadresse angeben.
<G-vec00301-002-s171><address.angeben><en> To register for the newsletter it is sufficient to enter your e-mail address.
<G-vec00301-002-s172><address.angeben><de> Anmeldedaten: Um sich für den Newsletter anzumelden, reicht es aus, wenn Sie Ihre E-Mailadresse angeben.
<G-vec00301-002-s172><address.angeben><en> Subscription data: To subscribe to the newsletter, all you have to do is enter your e-mail address.
<G-vec00301-002-s173><address.angeben><de> Wenn Sie eine Verbindung mit einem sicheren Server herstellen, müssen Sie die Portnummer in der Serveradresse angeben.
<G-vec00301-002-s173><address.angeben><en> If you’re connecting to a secure server you must enter the server address according to the following syntax:
<G-vec00301-002-s174><address.angeben><de> Wenn die von Ihnen angegebene IP-Adresse einem virtuellen Azure-Computer zugewiesen ist, sollten Sie sicherstellen, dass Sie die private IP-Adresse und nicht die öffentliche IP-Adresse angeben, die dem virtuellen Computer zugewiesen ist.Sicherheitsregeln werden verarbeitet, nachdem Azure die öffentliche IP-Adresse in eine private IP-Adresse für Eingangssicherheitsregeln übersetzt und bevor Azure eine private IP-Adresse in eine öffentliche IP-Adresse für Ausgangsregeln übersetzt rules.
<G-vec00301-002-s174><address.angeben><en> Unless necessary, you should never manually set the IP address of a network interface within the virtual machine's operating system. Warning If the IPv4 address set as the primary IP address of a network interface within a virtual machine's operating system is ever different than the private IPv4 address assigned to the primary IP configuration of the primary network interface attached to a virtual machine within Azure, you lose connectivity to the virtual machine.
<G-vec00301-002-s175><address.angeben><de> - In unseren Kontaktformularen können Sie wählen, dass Sie Ihre E-Mail-Adresse nicht angeben.
<G-vec00301-002-s175><address.angeben><en> - In our contact forms, you can choose to do not provide your email address.
<G-vec00301-002-s177><address.angeben><de> Um unseren Newsletter zu abonnieren, müssen Nutzer ihre E-Mail-Adresse angeben.
<G-vec00301-002-s177><address.angeben><en> In order to subscribe to our news bulletin, users provide their email address.
<G-vec00301-002-s178><address.angeben><de> Zur Registrierung müssen Sie Ihre Kontaktdaten und möglicherweise Rechnungsinformationen (wie Name, Adresse, Telefonnummer und E-Mail-Adresse) angeben.
<G-vec00301-002-s178><address.angeben><en> During registration you are required to give your contact and possibly billing information (such as name, address, phone number and email address).
<G-vec00301-002-s179><address.angeben><de> Bezüglich der Datenerfassung wird angegeben, dass CostMin die Nutzer überwacht, um den Service zu verbessern, die Qualität des Browser-Plugins zu erhöhen und ihnen periodische E-Mails anbietet, wenn sie ihre E-Mail-Adressen angeben.
<G-vec00301-002-s179><address.angeben><en> As to the data collection, it is claimed that CostMin monitors users in order to improve the service, enhance the quality of the browser plug-in, and provide them with periodic emails if they provide their email address.
<G-vec00301-002-s180><address.angeben><de> Um die E-Mail-Funktionalität nutzen zu können, müssen Sie lediglich Ihre E-Mail-Adresse angeben.
<G-vec00301-002-s180><address.angeben><en> To be able to use the e-mail function, you simply have to enter your e-mail address.
<G-vec00301-002-s182><address.angeben><de> Achten Sie also darauf, dass Sie eine korrekte E-Mail-Adresse angeben.
<G-vec00301-002-s182><address.angeben><en> So be sure to enter a valid email address.
<G-vec00301-002-s183><address.angeben><de> Sollten sie beispielsweise nicht die Emailadresse Ihres Kunden bei der Geschenkoption angeben, kann es sehr langwierig sein, diesen Fehler wieder zu korrigieren.
<G-vec00301-002-s183><address.angeben><en> If you don't use your customer's email address in the gift option for instance it may take a long time before it can be fixed.
<G-vec00301-002-s184><address.angeben><de> Nun kannst du deine Versandadresse angeben und die Versand- und Zahlungsweise auswählen.
<G-vec00301-002-s184><address.angeben><en> you can now enter your delivery address and select delivery and payment options.
<G-vec00301-002-s185><address.angeben><de> Dabei müssen Sie einen Wohnsitz angeben.
<G-vec00301-002-s185><address.angeben><en> You must give a permanent address there.
<G-vec00301-002-s186><address.angeben><de> Haben Sie uns in diesem Zusammenhang Ihre E-Mail-Adresse angeben, willigen Sie zudem ein, dass wir Ihnen Schulforum-Informationen per E-Mail zusenden und dafür Ihre E-Mail-Adresse verarbeiten dürfen.
<G-vec00301-002-s186><address.angeben><en> If you have provided us with your email address in this connection, then you have also consented to having us send you the School Forum information via email and having us process your email address for that purpose.
<G-vec00301-002-s187><address.angeben><de> Dazu musst du unter anderem deine E-Mail-Adresse angeben.
<G-vec00301-002-s187><address.angeben><en> Among other things, you must provide your e-mail address.
<G-vec00301-002-s188><address.angeben><de> Hier können Sie gegebenenfalls eine abweichende Lieferadresse angeben.
<G-vec00301-002-s188><address.angeben><en> You can enter a different delivery address here if necessary.
<G-vec00301-002-s189><address.angeben><de> Um diesen Dienst zu abonnieren, müssen Sie Ihre E-Mail-Adresse angeben.
<G-vec00301-002-s189><address.angeben><en> Subscribe Enter your email address to receive notifications when there are new posts
<G-vec00322-002-s076><specify.angeben><de> Wir arbeiten an der Möglichkeit, die Anzahl der Kinder und Erwachsenen bei Ihrer Flugsuche auf TripAdvisor angeben zu können.
<G-vec00322-002-s076><specify.angeben><en> We are working on the ability to specify number of children and adults during your flight search on TripAdvisor.
<G-vec00322-002-s077><specify.angeben><de> Jeder Bericht kann ein Konfigurationsdialogfeld aufweisen, in dem die Benutzer verschiedene Parameter für den Bericht angeben können.
<G-vec00322-002-s077><specify.angeben><en> Every report can have a configuration dialog, allowing the user to specify various parameters for the report.
<G-vec00322-002-s078><specify.angeben><de> Um nach einem Ausbruch ein Kursziel angeben zu können, addiert man die breiteste Stelle zum Ausbruchskurs hinzu.
<G-vec00322-002-s078><specify.angeben><en> To specify a target market price of an explosion, adding to the widest added to the breakout market price.
<G-vec00322-002-s079><specify.angeben><de> Öffnet das Dialogfeld Arbeitsverzeichnis für Befehl, in dem Sie das Verzeichnis angeben können, in dem der Befehl ausgeführt werden soll.
<G-vec00322-002-s079><specify.angeben><en> Opens the Command Working Directory dialog box, which enables you to specify the directory in which the command should run.
<G-vec00322-002-s080><specify.angeben><de> Beachten Sie, dass Sie keinen öffentlichen Ordner angeben können, da der PST-Importdienst das Importieren von PST-Dateien in öffentliche Ordner nicht unterstützt.
<G-vec00322-002-s080><specify.angeben><en> Note that you can't specify a public folder because the PST Import Service doesn't support importing PST files to public folders.
<G-vec00322-002-s081><specify.angeben><de> Da Benutzer angeben können, was sie suchen, müssen sie sich nicht länger durch eine Reihe von Bildschirmen klicken, um den gewünschten Einkauf aufzurufen.
<G-vec00322-002-s081><specify.angeben><en> By giving people the ability to specify what they are looking, it eliminates the need for having to navigate a series of screens to reach their intended purchase.
<G-vec00322-002-s082><specify.angeben><de> ColdFusion umfasst Quantifizierer für die minimale Übereinstimmung, mit denen Sie eine Übereinstimmung mit der kleinsten Zeichenfolge angeben können.
<G-vec00322-002-s082><specify.angeben><en> ColdFusion includes minimal-matching quantifiers that let you specify to match on the smallest string.
<G-vec00322-002-s083><specify.angeben><de> Um dieses Problem zu vermeiden, bietet Google das Tag "REL CANONICAL" an, mit dem Sie angeben können, welche URL als bevorzugte Version der Seite betrachtet werden soll.
<G-vec00322-002-s083><specify.angeben><en> To avoid this problem, Google provides the “REL CANONICAL” tag which allows you to specify which URL should be regarded as the preferred version of the page, thereby preventing any duplicate content issues.
<G-vec00322-002-s084><specify.angeben><de> Erweiterungen der START DATABASE-Anweisung Die Anweisung START DATABASE unterstützt nun eine DIRECTORY-Klausel, mit der Sie das Verzeichnis angeben können, in dem sich die DBSpace-Dateien der Datenbank befinden.
<G-vec00322-002-s084><specify.angeben><en> START DATABASE statement enhancement The START DATABASE statement now supports a DIRECTORY clause that lets you specify the directory where the database's dbspace files are located.
<G-vec00322-002-s085><specify.angeben><de> In weiteren Versuchsreihen und numerischen Simulationen werden einfließende Faktoren auf das Tragverhalten der Verklebung, wie etwa Geometrie, klimatische Einwirkungen, Langzeitbelastung und Herstellungsprozess untersucht, um Belastbarkeit und Dimensionierungsgrößen für die praktische Anwendung angeben zu können.
<G-vec00322-002-s085><specify.angeben><en> In further series of tests and numerical simulations, influencing factors on the performance of the adhesive bond such as geometry, climatic impact, long-term load and production process are being determined to specify the load bearing properties and dimensioning for practical application.
<G-vec00322-002-s086><specify.angeben><de> Wenn Sie in der Liste „Informationen zum Remote-Modul“ ein Remote-Modul auswählen und auf diese Schaltfläche klicken, wird der Dialog „Dateinamen angeben“ angezeigt, in dem Sie einen Dateinamen zuweisen und einen Zielordner angeben können.
<G-vec00322-002-s086><specify.angeben><en> By selecting a Remote Unit from the Remote Unit Info list and pressing this button "Specify File Name" dialog will appear in which it is possible to assign a file name and specify a destination folder.
<G-vec00418-002-s007><brag.angeben><de> In der Branche Content Marketing gehören Copyblogger, HubSpot und diese Seite (ohne angeben zu wollen) zu den autoritären Webseiten.
<G-vec00418-002-s007><brag.angeben><en> For example, in content marketing, some of the big names are Copyblogger, HubSpot, and this site (not to brag).
<G-vec00488-002-s028><declare.angeben><de> Bei der Einschiffung muss angegeben werden, ob das Fahrzeug mit einer Kraftstoffanlage für Methan oder LPG ausgestattet ist.
<G-vec00488-002-s028><declare.angeben><en> At the time of embarkation, it is obligatory to declare whether the accompanied vehicle is equipped with a methane or LPG fuelling system.
<G-vec00488-002-s029><declare.angeben><de> Anorganische Stoffe, oder Asche, ist ein Rechtsbegriff, der für jedes Tierfutter auf dem Etikett angegeben werden muss.
<G-vec00488-002-s029><declare.angeben><en> INORGANIC MATTER ‘Inorganic matter’ is a legal term that all pet foods are required to declare on the label.
<G-vec00488-002-s030><declare.angeben><de> Für jede zusätzliche Information, im Bezug auf die Handhabung Ihrer persönlicher Daten, unter anderem der Beteiligung an Beta-Tests, empfehlen wir Ihnen unseren Absatz über das "Privatleben" zu lesen, der ein wesentlicher Teil dieser Bedingungen ist, die Sie wie angegeben gelesen und akzeptiert zu haben.
<G-vec00488-002-s030><declare.angeben><en> For any additional information concerning the treatment of personal information, notably during the participation in Beta-tests, we recommend you to read our section on the respect for the «private life», which is an integral part of the present conditions and that you expressly declare to have read and accepted.
<G-vec00488-002-s031><declare.angeben><de> Über diesen Parameter wird der Name des Druckers angegeben, auf den die Druckausgabe des PDF-Dokuments erfolgen soll.
<G-vec00488-002-s031><declare.angeben><en> This parameter is used to declare the name of the printer that should be used to print the PDF document.
<G-vec00488-002-s030><designate.angeben><de> Durch Einleiten und Senden der Zahlungen über den Dienst ernennen Sie GoDaddy zu Ihrem Vermittler zum Erhalt der Zahlungen in Ihrem Auftrag und zur Übertragung an den von Ihnen angegebenen Empfänger.
<G-vec00488-002-s030><designate.angeben><en> By initiating and sending payments through the Services, you appoint GoDaddy as your agent to receive the funds on your behalf and transfer them to the recipient you designate.
<G-vec00488-002-s031><designate.angeben><de> Fügt im für die digitale Unterschrift bestimmten Feld (sofern vorhanden) oder an der von Ihnen angegebenen Stelle eine zertifizierte Signatur ein.
<G-vec00488-002-s031><designate.angeben><en> Places a certified signature in either an exiting digital signature field (if available) or in the location you designate.
<G-vec00557-002-s038><provide.angeben><de> Um eine Bestellung zu senden, müssen Sie den Inhalt der Bestimmungen akzeptieren, persönliche Daten angeben, die als obligatorisch gekennzeichnet sind, und auf die Schaltfläche "Ich bestelle und bezahle" klicken.
<G-vec00557-002-s038><provide.angeben><en> In order to send an Order, it is necessary to accept the content of the Regulations, provide personal data marked as mandatory and press the "I am ordering and paying" button.
<G-vec00557-002-s039><provide.angeben><de> Wenn der Kunde die Angabe einer Bestellnummer auf der Rechnung von Staffbase wünscht, muss er die Bestellnummer unverzüglich angeben.
<G-vec00557-002-s039><provide.angeben><en> If Customer requires a Purchase Order number referenced on Staffbase’s invoice, Customer must promptly provide the Purchase Order number.
<G-vec00557-002-s040><provide.angeben><de> Sie müssen beim Check-in die Informationen auf Ihrem Nummernschild angeben und erhalten eine Parkerlaubnis, die während des Parkens an der Unterkunft auf dem Armaturenbrett ausliegen muss.
<G-vec00557-002-s040><provide.angeben><en> Guests are required to provide their license plate information at check-in and they will be issued a parking permit to be displayed on the dashboard while parked on the premises.
<G-vec00557-002-s041><provide.angeben><de> Daten zu Geboten, Käufen oder Verkäufen, die Sie bei einer Transaktion angeben.
<G-vec00557-002-s041><provide.angeben><en> Data regarding bids, purchases, or sales that you provide in a transaction.
<G-vec00557-002-s042><provide.angeben><de> Bei der Registrierung für unseren Login-Bereich müssen Sie personenbezogene Daten angeben.
<G-vec00557-002-s042><provide.angeben><en> When you register for our log-in area, you must provide personal data.
<G-vec00557-002-s043><provide.angeben><de> Dies umfasst Informationen, die Sie angeben, wenn Sie sich für die Nutzung unserer Website registrieren, unsere Dienste abonnieren, Einzahlungen, Wetten oder Auszahlungen auf unserer Website vornehmen, an Chat-Rooms teilnehmen, Boni oder andere auf unserer Website verfügbare Werbeaktionen akzeptieren, jegliche eingereichte Due-Diligence-Dokumente und wenn Sie ein Problem melden oder sich bei uns beschweren.
<G-vec00557-002-s043><provide.angeben><en> This includes information you provide when you register to use our site, subscribe to our service, participate in discussion boards or other social media functions on our site and when you report a problem with our site.
<G-vec00557-002-s044><provide.angeben><de> Wenn Sie uns Anfragen über das Kontaktformular senden, werden Ihre Angaben auf dem Anfrageformular einschließlich der Kontaktdaten, die Sie auf dem Formular angeben, von uns für die Bearbeitung Ihrer Anfrage und für Folgeanfragen gespeichert.
<G-vec00557-002-s044><provide.angeben><en> If you send us inquiries using the contact form, your details on the inquiry form including the contact data you provide on the form will be stored by us in order to process your inquiry and for the purpose of follow-on inquiries.
<G-vec00557-002-s045><provide.angeben><de> Alle persönlichen Informationen, die Sie angeben (Name, Adresse, Telefon, E-Mail-Adresse, Kreditkartennummer), werden als vertraulich betrachtet und unterliegen keiner Offenlegung.
<G-vec00557-002-s045><provide.angeben><en> Any personal information you provide (name, address, phone, e-mail address, credit card number) is considered confidential and is not subject to disclosure.
<G-vec00557-002-s046><provide.angeben><de> Mind & Motion wird die Informationen, die Sie in diesem Formular angeben, dazu verwenden, mit Ihnen in Kontakt zu bleiben und Ihnen Updates und Marketing-Informationen zu übermitteln.
<G-vec00557-002-s046><provide.angeben><en> HTML Plain-text Marketing Permissions We will use the information you provide on this form to be in touch with you and to provide updates and marketing.
<G-vec00557-002-s047><provide.angeben><de> (1) Wenn Sie eine Buchung über unsere Webseite vornehmen möchten, ist es für den Vertragsabschluss erforderlich, dass Sie Ihre persönlichen Daten angeben, die wir für die Abwicklung Ihrer Buchung benötigen.
<G-vec00557-002-s047><provide.angeben><en> (1) If you wish to place an order in our Web shop, it is necessary for you to provide your personal data, which we need to process your order, in order to enter into a contract.
<G-vec00557-002-s048><provide.angeben><de> Zusätzlich zu dem Skriptblock, der die für die einzelnen Eingabeobjekte auszuführenden Vorgänge beschreibt, können Sie zwei weitere Skriptblöcke angeben.
<G-vec00557-002-s048><provide.angeben><en> In addition to using the script block that describes the operations to be carried out on each input object, you can provide two additional script blocks.
<G-vec00557-002-s049><provide.angeben><de> Münchner Verlagsgruppe GmbH wird die Informationen, die Sie in diesem Formular angeben, dazu verwenden, mit Ihnen in Kontakt zu bleiben und Ihnen Updates und Marketing-Informationen zu übermitteln.
<G-vec00557-002-s049><provide.angeben><en> Marketing Permissions Intentional Families will use the information you provide on this form to be in touch with you and to provide updates and marketing.
<G-vec00557-002-s050><provide.angeben><de> Dies schließt Informationen ein, die Sie angeben, wenn Sie sich für die Nutzung unserer Website registrieren, nach einem Produkt suchen, eine Bestellung auf unserer Website aufgeben, an snkrstyles.com teilnehmen, an einem Wettbewerb, einer Werbeaktion oder einer Umfrage teilnehmen und wenn Sie ein Problem mit unserer Website melden.
<G-vec00557-002-s050><provide.angeben><en> This includes information you provide when you register to use our site, subscribe to our service, participate in discussion boards or other social media functions on our site, enter a promotion or survey, during the course of any other activity commonly carried out on our site and when you report a problem with our site.
<G-vec00557-002-s051><provide.angeben><de> Für einige Services kann es jedoch erforderlich sein, dass Sie persönliche Daten angeben.
<G-vec00557-002-s051><provide.angeben><en> However, some services offered on the Site may require you to provide us with Personal Data.
<G-vec00557-002-s052><provide.angeben><de> Dein vollständiger Name muss dabei nicht angeben werden, aber du kannst, wenn du möchtest.
<G-vec00557-002-s052><provide.angeben><en> You do not need to provide your full name, but you may if you wish.
<G-vec00557-002-s053><provide.angeben><de> Hierbei wird der Grundsatz der Datensparsamkeit und Datenvermeidung beachtet, indem Sie nur die Daten angeben müssen, die wir zwingend zur Kontaktaufnahme von Ihnen benötigen.
<G-vec00557-002-s053><provide.angeben><en> Here, the principle of data economy and data avoidance will be applied, meaning that you will only need to provide such data as are absolutely necessary to contact you.
<G-vec00557-002-s054><provide.angeben><de> Dazu müssen Sie weitere Daten angeben, die wir zur Erbringung der jeweiligen Leistung nutzen und für welche die zuvor genannten Grundsätze zur Datenverarbeitung gelten.
<G-vec00557-002-s054><provide.angeben><en> For this purpose, you must provide further data, which we would use to provide the respective service and for which the aforementioned data processing principles apply
<G-vec00557-002-s055><provide.angeben><de> Gut Hügle wird die Informationen, die Sie in diesem Formular angeben, dazu verwenden, mit Ihnen in Kontakt zu bleiben und Ihnen Updates und Marketing-Informationen zu übermitteln.
<G-vec00557-002-s055><provide.angeben><en> Sounds of Revolution will use the information you provide on this form to be in touch with you and to provide updates and marketing.
<G-vec00557-002-s056><provide.angeben><de> Sie können nur Werte für Eigenschaften der Entität angeben.
<G-vec00557-002-s056><provide.angeben><en> You can only provide values for properties of that Entity.
<G-vec00141-002-s074><indicate.angeben><de> Wir müssen also echte Holarchien zusammengesetzter Individuen entwickeln und für jede Ebene das Umfeld (oder soziale Holon) angeben, an dem die individuellen Holons teilhaben und von dessen Existenz ihre eigene Existenz abhängt.
<G-vec00141-002-s074><indicate.angeben><en> What is necessary, then, is to construct a series of true holarchies of compound individuals and then indicate, at the same level of organization, the type of environment (or social holon) in which the individual holon is a participant [member] (and on whose existence the individual holon depends).
<G-vec00141-002-s076><indicate.angeben><de> In dieser Schaltfläche müssen wir nach Erstellen der Vereinigung/Differenz/Schnittmenge angeben, dass diese Menge verwendet werden muss.
<G-vec00141-002-s076><indicate.angeben><en> In this button here, after we have created the union that creates a 3rd set, we must indicate the particular set that needs to be used.
<G-vec00141-002-s077><indicate.angeben><de> Ein Verkäufer kann einen bestimmten Minimumkurs angeben, für den er ein bestimmtes Finanzinstrument, wie zum Beispiel Lehman-Zertifikate, zu verkaufen bereit ist.
<G-vec00141-002-s077><indicate.angeben><en> The investor can indicate a minimum price for which he would like to sell certain distressed investments products - such as Lehman Brothers.
<G-vec00141-002-s078><indicate.angeben><de> Restaurant 200 m zum Rand des Marina oder in Chalon: Ich werde gerne angeben.
<G-vec00141-002-s078><indicate.angeben><en> Restaurant 200 m to the edge of the marina, or in Chalon: I will gladly indicate.
<G-vec00141-002-s079><indicate.angeben><de> Es bestätigt auch die Richtigkeit der Produktetiketten NOW Foods, was bestätigt, dass die Etiketten Produkt Inhaltsstoffe bei den beworbenen Dosierungen und Potenzen genau angeben.
<G-vec00141-002-s079><indicate.angeben><en> It also attests to the accuracy of NOW Foods product labels, confirming that labels accurately indicate product ingredients at the advertised dosages and potencies.
<G-vec00141-002-s080><indicate.angeben><de> Es gibt einen Grund, warum wir bei jeder der zehn Arten angeben, ob es sich um Indica- oder Sativa-dominante Cannabis-Stämme handelt.
<G-vec00141-002-s080><indicate.angeben><en> There is a reason why we indicate at each of the ten species whether they are indica or sativa dominant strains of cannabis.
<G-vec00141-002-s081><indicate.angeben><de> b) Ursprungszeugnis (1-fach) erforderlich; bei deutschen Waren als Ursprungsland angeben: „Switzerland“ oder „……………… (European Union)“ oder nur „European Union“.
<G-vec00141-002-s081><indicate.angeben><en> b) Certificate of origin (one copy) required; as the origin, indicate “Swiss” in the case of Swiss goods, or “European Union” for goods originating from UE.
<G-vec00141-002-s082><indicate.angeben><de> In einem Fragebogen mit ausschlie√ülich geschlossenem Antwortformat konnten die Probanden anhand der jeweils verwendeten Antwortskala ihre Zustimmung oder Ablehnung des jeweiligen Iteminhaltes angeben.
<G-vec00141-002-s082><indicate.angeben><en> In a questionnaire using a closed response format, subjects used a response scale to indicate their agreement or disagreement with each item's contents.
<G-vec00141-002-s083><indicate.angeben><de> Um den Ausstoß von Treibhausgasen zu ermitteln, muss der Anwender lediglich den Ladehafen/Abflughafen und das Ziel angeben.
<G-vec00141-002-s083><indicate.angeben><en> To determine greenhouse gas emissions the user has just to indicate the loading port and the destination.
<G-vec00141-002-s084><indicate.angeben><de> Diese Befehle haben eine Registerkarte Unterteilung, worin Sie angeben können, wenn Sie Spalten für die Segmente erstellen wollen, indem Sie die Segmente auswählen, die Sie bekommen wollen.
<G-vec00141-002-s084><indicate.angeben><en> These commands have a section Subdivision within which it is possible to indicate to create the columns for the segments, selecting the segments to be obtained.
<G-vec00141-002-s085><indicate.angeben><de> Bei der Einbindung von Bild-, Video-, Ton- und/oder Dokumenten auf unserer Webseite werden wir bei externen Quellen stets den Urheber angeben, außer dieser ist bereits innerhalb der Quelle deutlich vom Urheber selbst kenntlich gemacht.
<G-vec00141-002-s085><indicate.angeben><en> With the integration of image, video, sound and documents on our website we will always indicate the copyright/author of the external source, except the identity is already made evident within the source by the author himself.
<G-vec00141-002-s086><indicate.angeben><de> Dann können Sie dies am Check-in-Schalter angeben.
<G-vec00141-002-s086><indicate.angeben><en> Then you can indicate this at the check-in desk.
<G-vec00141-002-s087><indicate.angeben><de> Direkt nach der Registrierung bekommst Du per E-Mail einen Gutscheincode gesendet, Diesen bitte im Rahmen Deiner ersten Bestellung angeben und am Ende reduziert sich der Rechnungsbetrag um 10,- Euro.
<G-vec00141-002-s087><indicate.angeben><en> Immediately after registration you will receive a coupon code via e-mail. Please indicate this as part of your first order and at the end the invoice amount will be reduced by 10, - Euro.
<G-vec00141-002-s088><indicate.angeben><de> Da die Anzahl der biochemischen Marker groß genug ist, wird der Arzt bei der Analyse angeben, welche Parameter in Abhängigkeit von den Merkmalen des Schwangerschaftsverlaufs und dem Vorliegen von Begleiterkrankungen bestimmt werden sollten.
<G-vec00141-002-s088><indicate.angeben><en> Since the number of biochemical markers is large enough, when referring to the analysis the doctor will indicate which parameters should be determined depending on the characteristics of the course of pregnancy and the presence of concomitant diseases.
<G-vec00141-002-s089><indicate.angeben><de> In diesem Modul kann der Administrator angeben, von welchen XXImo–Mobilitätsdiensten der Mitarbeiter Gebrauch machen darf.
<G-vec00141-002-s089><indicate.angeben><en> Within this module, the administrator can indicate which XXImo mobility options the employee will be entitled to use.
<G-vec00141-002-s090><indicate.angeben><de> Der Bewerber muss gegenüber dem Prüfer angeben, welche Überprüfungen und Aufgaben er ausführt, und die Funkeinrichtungen benennen.
<G-vec00141-002-s090><indicate.angeben><en> Applicants shall indicate to the examiner the checks and duties carried out, including the identification of radio facilities.
<G-vec00141-002-s091><indicate.angeben><de> Wahlweise auch 1 1/8" (28,58mm) oder 1 1/4" (31,75mm) Bei Bestellung - Durchmesser bitte mit angeben.
<G-vec00141-002-s091><indicate.angeben><en> Optional also 1 1/8" (28,58mm) or 1 1/4" (31,74mm) When ordering - Please indicate Diameter
<G-vec00141-002-s092><indicate.angeben><de> [...] Variablennamen mit der Funktion 'Text ersetzen', wobei Sie bei 'Suchen nach' das alte und bei 'Ersetzen durch' das neue Postfix angeben.
<G-vec00141-002-s092><indicate.angeben><en> [...] using the 'Replace Text' function and indicate the new postfix in the 'Replace with' field and the old in the 'Search for' field.
<G-vec00141-002-s093><indicate.angeben><de> Mit Pip bezeichnet man die Masseinheit, in welcher absolute Änderungen im Kurs eines Währungspaares angegeben werden.
<G-vec00141-002-s093><indicate.angeben><en> The term pip denotes a unit of measurement used to indicate changes in exchange rates of currency pairs.
<G-vec00141-002-s094><indicate.angeben><de> Die Zahl auf der linken Seite wird angegeben, wie viele Stücke übrig sind.
<G-vec00141-002-s094><indicate.angeben><en> The number on the left pane will indicate how many pieces are left.
<G-vec00141-002-s095><indicate.angeben><de> Darüber hinaus sollen in dem Plan die möglichen vorbereitenden Maßnahmen angegeben sein, die seitens des Schiffes ergriffen werden können, damit eine schnelle Reaktion auf die Anweisungen erfolgen kann, die an das Schiff gegebenenfalls von den Stellen erteilt werden, die bei Gefahrenstufe 3 auf ein sicherheitsrelevantes Ereignis oder ein drohendes sicherheitsrelevantes Ereignis reagieren.
<G-vec00141-002-s095><indicate.angeben><en> Furthermore, the plan should indicate the possible preparatory actions the ship could take to allow prompt response to the instructions that may be issued to the ship by those responding at security level 3 to a security incident or threat thereof.
<G-vec00141-002-s096><indicate.angeben><de> Mindestens einmal pro Jahr muss auf oder mit der Stromrechnung angegeben werden, aus welchen Energieträgern der Strom produziert wurde und ob dies in der Schweiz oder im Ausland erfolgt ist.
<G-vec00141-002-s096><indicate.angeben><en> At least once a year, electricity supply companies are required to indicate – either on, or together with an electricity bill – the source from which their electricity has been produced, and whether it was produced in Switzerland or abroad.
<G-vec00141-002-s097><indicate.angeben><de> (3) Falls die Waagen auch von anderen Richtlinien erfasst werden, die andere Aspekte behandeln und in denen die CE-Konformitätskennzeichnung vorgesehen ist, wird mit dieser Kennzeichnung angegeben, dass auch von der Konformität dieser Waagen mit den Bestimmungen dieser anderen Richtlinien auszugehen ist.
<G-vec00141-002-s097><indicate.angeben><en> The certificate shall be supplied with the fitting. 5. Where the appliances are covered by other Directives dealing with other aspects and specifying the affixing of the CE marking, the latter shall indicate that the appliances are also presumed to conform to the provisions of those Directives.
<G-vec00141-002-s098><indicate.angeben><de> An den Rändern ist angegeben, welche Buchstaben in welcher Zeile, Spalte und Diagonale stehen müssen.
<G-vec00141-002-s098><indicate.angeben><en> The letters at the borders indicate which letter has to be in which row, column and diagonal.
<G-vec00141-002-s099><indicate.angeben><de> Der Sensor ist kompakt und mit einem Satz LEDs ausgestattet, die den Status des Instrumentes angegeben.
<G-vec00141-002-s099><indicate.angeben><en> A set of LED’s indicate the status of the instrument so operation is possible without observing the control unit.
<G-vec00141-002-s100><indicate.angeben><de> Auf den Etiketten ist mit dem Text „Verbrauchen vor“ (’Weg op’) deutlich angegeben, wann ein geöffnetes Produkt weggeworfen werden muss, ausgehend von einer maximalen Haltbarkeit von drei Tagen.
<G-vec00141-002-s100><indicate.angeben><en> The labels with the text ‘Use by’ (‘Weg op’) indicate very clearly the day on which an opened product must be thrown away, on the basis of a maximum shelf life of three days.
<G-vec00141-002-s101><indicate.angeben><de> Bei der Anmeldung muss die genaue Teilnehmerzahl angegeben werden (Studenten, Dozenten und eventuelle Begleitpersonen).
<G-vec00141-002-s101><indicate.angeben><en> Upon booking it is necessary to indicate the precise number of members in the group (students, teachers and any other accompanying visitors).
<G-vec00141-002-s102><indicate.angeben><de> Um diese Überprüfung zu vereinfachen, ist in der Datenschutzerklärung das Datum ihrer Aktualisierung angegeben.
<G-vec00141-002-s102><indicate.angeben><en> In order to facilitate such verification, the privacy statement shall indicate the date of its update.
<G-vec00141-002-s103><indicate.angeben><de> Im Befehl wird mit dem Independent-Parameter angegeben, dass diese Transaktion kein Abonnent der aktiven Transaktion ist.
<G-vec00141-002-s103><indicate.angeben><en> The command uses the Independent parameter to indicate that this transaction is not a subscriber to the active transaction.
<G-vec00141-002-s105><indicate.angeben><de> Nur Fehler protokollieren Mit dieser Option werden ausschließlich Ereignisse in die Protokolldateien geschrieben, mit denen Fehlerbedingungen angegeben werden.
<G-vec00141-002-s105><indicate.angeben><en> Log errors only. This option writes only events that indicate error conditions to the log files.
<G-vec00141-002-s106><indicate.angeben><de> Beim Antrag auf Briefwahl muss kein Grund angegeben werden, warum das Wahllokal am Wahltag nicht aufgesucht werden kann.
<G-vec00141-002-s106><indicate.angeben><en> Voters applying to vote by post do not have to indicate a reason why they will not be able to go to the polling station on election day.
<G-vec00141-002-s107><indicate.angeben><de> Auf der offiziellen Website von St. George’s Castle ist die Zeit der Sitzungen nicht angegeben.
<G-vec00141-002-s107><indicate.angeben><en> The official website of the Sao Jorge Castle does not indicate the time of the sessions.
<G-vec00141-002-s108><indicate.angeben><de> Bei der Bewerbung von 090x Rufnummern muss unmissverständlich angegeben werden, dass sich der Preis auf Anrufe ab Festnetz bezieht.
<G-vec00141-002-s108><indicate.angeben><en> Advertisements for 090x numbers must indicate unambiguously that the cost refers to fixed line call rates.
<G-vec00141-002-s109><indicate.angeben><de> In den Beschreibungen der verschiedenen Unterkünfte ist angegeben, ob Haustiere erlaubt sind.
<G-vec00141-002-s109><indicate.angeben><en> The descriptions of the various accommodations indicate whether or not pets are allowed.
<G-vec00141-002-s110><indicate.angeben><de> Auf dieser Seite wird angegeben, ob dein Testvideo verarbeitet wird, es sich in der Warteschlange des Prüfungsteams befindet oder das Feedback fertig ist.
<G-vec00141-002-s110><indicate.angeben><en> On the page it will indicate if your test video is processing, if it’s in the review team’s queue for review, or if feedback for your video is ready.
<G-vec00141-002-s111><indicate.angeben><de> Wenn Sie Inhalte posten oder Informationsmaterial übermitteln, gewähren Sie, sofern nicht anders von uns angegeben, dem Unternehmen und seinen Partnern ein nicht ausschließliches, gebührenfreies, dauerhaftes, unwiderrufliches und vollständig unterlizenzierbares Recht auf die Verwendung, Vervielfältigung, Änderung, Anpassung, Veröffentlichung, Übersetzung, Verteilung und weltweite Anzeige dieser Inhalte in beliebigen Medien sowie auf die Erstellung von abgeleiteten Werken aus diesen Inhalten.
<G-vec00141-002-s111><indicate.angeben><en> If you do post content or submit material, and unless we indicate otherwise, you grant Cyclone Diesel Performance and its associates a nonexclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such content throughout the world in any media.
<G-vec00141-002-s131><indicate.angeben><de> Auf einige Anweisungstitel folgt ein Indikator in eckigen Klammern, der angibt, wo die Anweisung benutzt werden kann.
<G-vec00141-002-s131><indicate.angeben><en> Some statement titles are followed by an indicator in square brackets that indicate where the statement can be used.
<G-vec00141-002-s132><indicate.angeben><de> Tugenden der Gerechtigkeit: Die Beschreibung der Fertigkeit wurde aktualisiert, damit sie die korrekte Anzahl von Attacken angibt, die nötig sind, um diese Fertigkeit auszulösen.
<G-vec00141-002-s132><indicate.angeben><en> Virtue of Justice: Updated the skill facts to indicate the number of attacks required to trigger this skill.
<G-vec00141-002-s133><indicate.angeben><de> Wenn in der Zukunft spezielle Abteilungen der Seite, die spezifische Verarbeitungssoperationen einschließen, konfiguriert werden, so wird es der Besitzer sein, der geeignete Informationen angibt und von Zeit zu Zeit die Verpflichtungen erfüllt, die durch die Gesetzgebung oder durch die Autorität für den Schutz von persönlichen Daten angestrebt werden.
<G-vec00141-002-s133><indicate.angeben><en> If in the future special sections of the site involving specific treatment operations are configured, it will be the Holder to indicate appropriate information and to fulfil from time to time the obligations envisaged by legislation or by the Authority for the protection of personal data.
<G-vec00141-002-s134><indicate.angeben><de> Beim Ziehen bewegt sich zwischen den Seiten oder Dokumenten eine blaue Leiste, die die aktuelle Position angibt.
<G-vec00141-002-s134><indicate.angeben><en> As you drag, a blue bar moves between pages or documents to indicate the current position.
<G-vec00141-002-s135><indicate.angeben><de> Der Wert true gibt an, dass ein expliziter Ort in der Vorlage angegeben ist; der Wert false gibt an, dass die Vorlage kein spezifisches Verweisziel für die Anmerkung angibt.
<G-vec00141-002-s135><indicate.angeben><en> The value true indicates that such an explicit location is indicated in the copy text; the value false indicates that the copy text does not indicate a specific place of attachment for the note.
<G-vec00141-002-s136><indicate.angeben><de> Ein Multiplikator ist ein Zeichen, das angibt, wie oft eine vorhergehende Entität wiederholt werden kann.
<G-vec00141-002-s136><indicate.angeben><en> A multiplier is a sign that indicate how many times a preceding entity can be repeated.
<G-vec00141-002-s137><indicate.angeben><de> Wenn Sie amerikanisches Laubholz kaufen, egal ob direkt aus den USA oder von einem Vertriebsbüro, dann müssen Sie unbedingt das Sortierklassen-System des NHLA (National Hardwood Lumber Association) verstehen, das auch die Holzausnutzung je nach Verwendungszweck angibt, um Missverständnissen durch zu unspezifische Vorgaben oder auch die Zahlung von zu hohen Preisen vorzubeugen.
<G-vec00141-002-s137><indicate.angeben><en> GRADES If you are sourcing American hardwood lumber, either directly from the USA or from distributors, it is absolutely essential to understand the NHLA (National Hardwood Lumber Association) grading principles, which indicate yield for specific purposes, to avoid overpaying or underspecifying.
<G-vec00141-002-s138><indicate.angeben><de> Auch wenn die Hälfte der EU-Bürger angibt, zusätzlich zu ihrer Muttersprache einer weitere Sprache zu beherrschen, so sagt nur ein geringer Anteil von sich, eine Unterhaltung in zwei Fremdsprachen führen zu können.
<G-vec00141-002-s138><indicate.angeben><en> Even though more than a half of EU citizens say that they could speak another language in addition to their mother tongue, only a small percentage of Europeans indicate that they are able to hold a conversation in two foreign languages.
<G-vec00141-002-s139><indicate.angeben><de> Beim Erstellen einer E-Mail kann ein Secure Mail-Benutzer eine Markierung auswählen, die die Klassifizierungsebene der E-Mail angibt (siehe Abbildungen unten).
<G-vec00141-002-s139><indicate.angeben><en> When composing an email, a Secure Mail user can select a marking to indicate the classification level of the email, as shown in the following images.
<G-vec00141-002-s140><indicate.angeben><de> Bei der Umrechnung der Währungen, deren Kurs die Tschechische Nationalbank (CNB) in ihren Kurszetteln nicht angibt, aber die können als Tarifwährung in den internationalen Eisenbahnbeförderungen vorkommen, wendet die OPT bei der Verrechnung mit den Verfrachtern bei diesen Währungen das Verhältnis ihrer Kurse zu EUR an, die ihre Zentralbanken verkünden.
<G-vec00141-002-s140><indicate.angeben><en> Note for customers: During the conversion of the currencies, whose course the Czech National Bank (CNB) does not indicate in its market tickets, but those ones can occur as a tariff currency in the international railway transports, the OPT uses the ratio of their courses to EUR during the settlement with the customers, that their central banks announce.
<G-vec00141-002-s141><indicate.angeben><de> Nach vielen Studien konnte die National Sleep Foundation in den Vereinigten Staaten einen Kriterienkatalog veröffentlichen, der angibt, ob man gut geschlafen hat: Wenn du weniger als 30 Minuten gebraucht hast, um einzuschlafen, du nicht mehr als einmal aufgewacht und dabei nicht länger als 20 Minuten benötigt hast, um wieder einzuschlafen, oder du kein einziges Mal in der Nacht aufgewacht bist und du 85 Prozent der Ruhezeit im Tiefschlaf verbracht hast.
<G-vec00141-002-s141><indicate.angeben><en> This allowed them to publish a list of criteria that indicate that you had a good night's sleep: it took you less than 30 minutes to fall asleep, you didn't wake up more than once, and if you did wake up in the middle of the night, you didn't stay awake for more than 20 minutes, and you were in a deep sleep 85% of time you spent in bed.
<G-vec00141-002-s142><indicate.angeben><de> Verwenden Sie dies zur Angabe eines alternativen, gerätespezifischen Parameters, der den abzugrenzenden Rechner angibt.
<G-vec00141-002-s142><indicate.angeben><en> Use this to specify an alternate, device-specific parameter that should indicate the machine to be fenced.
<G-vec00141-002-s143><indicate.angeben><de> pH: Eine Skala, die die Säure oder basischen Eigenschaften einer Lösung angibt.
<G-vec00141-002-s143><indicate.angeben><en> pH: A scale to indicate the acidity or alkalinity of a solution.
<G-vec00141-002-s144><indicate.angeben><de> Achte darauf, dass du auch alles andere zur Hand hast, was die Färbeanleitung angibt.
<G-vec00141-002-s144><indicate.angeben><en> Make sure to have on hand anything else the dye instructions indicate.
<G-vec00141-002-s145><indicate.angeben><de> Wenn AEM ungültige Zeichen ermittelt, wird das Feld hervorgehoben und es wird eine Meldung mit einer Erklärung angezeigt, die angibt, welche Zeichen entfernt/ersetzt werden müssen.
<G-vec00141-002-s145><indicate.angeben><en> When AEM detects invalid characters the field will be highlighted with an explanatory message available to indicate the characters that need removing/replacing. Huomautus:
<G-vec00141-002-s146><indicate.angeben><de> IP steht für "Internet Protokoll" und ist im Grunde nur eine Zahl, die den Standort eines Computers oder anderer Geräte in einem Netzwerk angibt.
<G-vec00141-002-s146><indicate.angeben><en> Well, IP stands for ‘Internet Protocol’ and is basically a number used to indicate the location of a computer or other devices on a network.
<G-vec00141-002-s207><indicate.angeben><de> Sie enthält eine Bestellnummer, die in allen nachfolgenden Kommunikationen mit KIKO anzugeben ist.
<G-vec00141-002-s207><indicate.angeben><en> This confirmation message will indicate an "Order Number," to be used in all subsequent communications with KIKO.
<G-vec00141-002-s208><indicate.angeben><de> So ist es beispielsweise unabdingbar, seine Identität offenzulegen, einen Kundendienst anzugeben und eine über das Internet getätigte Bestellung umgehend zu bestätigen.
<G-vec00141-002-s208><indicate.angeben><en> It will for example be required to disclose his identity, to indicate a customer service and to immediately confirm an order placed online.
<G-vec00141-002-s209><indicate.angeben><de> Stimpack-Infotexte wurden aktualisiert, um anzugeben, dass sie 8 Stunden lang halten.
<G-vec00141-002-s209><indicate.angeben><en> Stimpack tooltips have been updated to indicate that they persist for 8 hours.
<G-vec00141-002-s211><indicate.angeben><de> Verwendet man ökonomische Szenarien im Rahmen eines sogenannten stochastischen Modells, so wird gefordert, den sogenannten besten Schätzwert anzugeben.
<G-vec00141-002-s211><indicate.angeben><en> If economic scenarios are used within the framework of a so-called stochastic model, it is necessary to indicate the so-called best estimate.
<G-vec00141-002-s212><indicate.angeben><de> Im Frachtbrief ist die Eingangsstelle bei Komax anzugeben.
<G-vec00141-002-s212><indicate.angeben><en> The waybill must indicate the place of receipt at Komax.
<G-vec00141-002-s213><indicate.angeben><de> Der Teilnehmer braucht sich nur einmal via Internet anzumelden, die gewünschte Bestellmenge und den voraussichtlichen Lieferzeitraum anzugeben und die Daten zu bestätigen.
<G-vec00141-002-s213><indicate.angeben><en> The participant needs to announce itself only once via Internet to indicate the desired order quantity and the prospective delivery period and confirm the data.
<G-vec00141-002-s214><indicate.angeben><de> Das Symbol in der Bibliothek geändert wird, um anzugeben, dass die Datei ausgecheckt ist.
<G-vec00141-002-s214><indicate.angeben><en> Its icon in the library changes to indicate that the file is checked out .
<G-vec00141-002-s215><indicate.angeben><de> Vergessen Sie nicht, bei der Überweisung Name und Vorname der betreffenden Person anzugeben.
<G-vec00141-002-s215><indicate.angeben><en> Please do not forget to indicate the full name of the person in question.
<G-vec00141-002-s217><indicate.angeben><de> Alle haben ihre Vor- und Nachteile, und wir haben unser Bestes getan, um sie in der Vergleichstabelle anzugeben, damit Sie selbst entscheiden können, was Sie wählen möchten.
<G-vec00141-002-s217><indicate.angeben><en> All of them have their advantages and disadvantages, and we have tried our best to indicate them in the comparison table for your own convenience to decide what to choose.
<G-vec00141-002-s218><indicate.angeben><de> Außerdem ist das Aktenzeichen und der Anmeldetag der Patentanmeldung anzugeben.
<G-vec00141-002-s218><indicate.angeben><en> Furthermore, you must indicate the file number and the date of filing of the patent application.
<G-vec00141-002-s219><indicate.angeben><de> Ich möchte es mir hier allerdings sparen die Abmessungen explizit anzugeben.
<G-vec00141-002-s219><indicate.angeben><en> I would like to however save up here to indicate the measurements explicitly.
<G-vec00141-002-s220><indicate.angeben><de> Es ist besser, als Lieferungsadresse die Adresse anzugeben, wo sich der Adressat oder jemand anderer vorassichtlich zur Lieferungszeit aufhält.
<G-vec00141-002-s220><indicate.angeben><en> Shipping address should be the address indicate where the buyer or other transferee person at the likely time.
<G-vec00141-002-s221><indicate.angeben><de> Denke daran, positive und negative Zahlen zu verwenden, um die Richtung der Koordinaten anzugeben.
<G-vec00141-002-s221><indicate.angeben><en> Remember to use positive and negative numbers to indicate the direction of coordinates.
<G-vec00141-002-s222><indicate.angeben><de> Angesichts dieser positiven Entwicklungen, die sich in den Meldungen an das Schnellwarnsystem für Lebens- und Futtermittel niederschlagen, ist die Verpflichtung, den Gewichtsprozentsatz aller Einzelfuttermittel in Mischfuttermitteln in der Kennzeichnung anzugeben, fortan nicht mehr notwendig, um ein hohes Maß an Futtermittelsicherheit und damit ein hohes Maß an Schutz der öffentlichen Gesundheit zu gewährleisten.
<G-vec00141-002-s222><indicate.angeben><en> In light of these positive achievements, mirrored in the notifications to the Rapid Alert System for Food and Feed (RASFF), the obligation to indicate the percentage by weight of all feed materials incorporated in compound feed on the labelling is no longer necessary for the purpose of ensuring a high level of feed safety and thus a high level of protection of public health.
<G-vec00141-002-s223><indicate.angeben><de> Um spezielle Annehmlichkeiten für Männer und Frauen vorzubereiten, werden die Gäste gebeten, das Geschlecht jedes Gastes anzugeben, der im Zimmer im Sonderwunsch bei der Buchung wohnt.
<G-vec00141-002-s223><indicate.angeben><en> In order to prepare special amenities for men and women, guests are kindly requested to indicate the gender of each guest staying in the room in the Special Requests box when booking.
<G-vec00141-002-s224><indicate.angeben><de> Ein ausgeklügeltes System wurde erfunden, um "Routen" im Untergrund anzugeben durch Kreuzungen und Numerierungen.
<G-vec00141-002-s224><indicate.angeben><en> An ingenious system was invented to indicate "routes" underground, by assigning numbers to intersections .
<G-vec00141-002-s225><indicate.angeben><de> Es kann in der Form -L Bezeichnung oder -U UUID vorliegen, um das Gerät anhand der Bezeichnung oder UUID anzugeben.
<G-vec00141-002-s225><indicate.angeben><en> It may be of the form -L label or -U uuid to indicate a device by label or uuid.
<G-vec00141-002-s561><indicate.angeben><de> Die Prozentsätze geben die Rendite einer ETC-Investition an, gemessen ab drei verschiedenen Zeitpunkten.
<G-vec00141-002-s561><indicate.angeben><en> The percentages indicate the return on an investment in ETC, measured from three different moments in time.
<G-vec00141-002-s562><indicate.angeben><de> Die dezente Stickerei Dragonfly auf der Vorderseite ist das Symbol für Qualität, durch das Sie Ihrer Umgebung klar signalisieren, dass Sie sich nur mit der besten Gym Kleidung zufrieden geben.
<G-vec00141-002-s562><indicate.angeben><en> Decent Dragonfly embroidery on the front is a symbol of premium quality fintess clothing by which you indicate to others that you want only the best.
<G-vec00141-002-s563><indicate.angeben><de> Bitte, geben Sie Ihre Diät, Laktose- oder Glutenunverträglichkeit im Voraus an, damit wir Ihnen zum Frühstück und Abendessen eine große Auswahl an Speisen bereitstellen können.
<G-vec00141-002-s563><indicate.angeben><en> Please indicate your diet, lactose or gluten sensitivity in advance, so that we can provide you with a wide variety of foods during your stay in the course of breakfasts and dinners, from the meals suitable for you.
<G-vec00141-002-s564><indicate.angeben><de> CASTLE MALTING®: Zur Preisanfrage hinzufügen WAIMEA /NZ (Bitte geben Sie genaue Menge und die gewünschte Verpackungsart für die Sie interessierenen Artikel an.
<G-vec00141-002-s564><indicate.angeben><en> CASTLE MALTING®: Add to price request NELSON SAUVIN /NZ (Please indicate the exact quantity and the preferred packaging for the products you are interested in.
<G-vec00141-002-s565><indicate.angeben><de> CASTLE MALTING®: Zur Bestellung hinzufügen PACIFIC GEM BIO /NZ (Bitte geben Sie genaue Menge und die gewünschte Verpackungsart für die Sie interessierenen Artikel an.
<G-vec00141-002-s565><indicate.angeben><en> CASTLE MALTING®: Add to price request PACIFIC GEM /NZ (Please indicate the exact quantity and the preferred packaging for the products you are interested in.
<G-vec00141-002-s566><indicate.angeben><de> Die Mehrheit der Mitglieder geben künftige Themen an, in denen die geschlechtsspezifische Dimension bei verschiedenen Tätigkeiten des Ausschusses, zum Beispiel im Rahmen von Berichten (zu denen auch Durchführungsberichte gehören), Anhörungen, Studien, des Haushaltsverfahrens und des jährlichen Entlastungsverfahrens, berücksichtigt wird.
<G-vec00141-002-s566><indicate.angeben><en> A majority of Members indicate future themes where the gender dimension is taken into account in various actions taken by the committee such as reports (including implementation reports), hearings, studies, budgetary procedure, annual discharge procedure.
<G-vec00141-002-s567><indicate.angeben><de> Wir geben keine idealen theoretischen Werte an, sondern in der Praxis tatsächlich erzielbare Leistungsdaten nach Abzug aller Verluste.
<G-vec00141-002-s567><indicate.angeben><en> We don’t indicate any ideal theoretic values, but the performance data which can be reached in practice after deduction of all losses.
<G-vec00141-002-s568><indicate.angeben><de> Suchen Sie bequem Ihren Gastgeber: Geben Sie einfach den Ort ein, oder den Namen der Unterkunft.
<G-vec00141-002-s568><indicate.angeben><en> Your service supplier Find your service supplier easily: Simply indicate name of accommodation.
<G-vec00141-002-s569><indicate.angeben><de> Die Zahlen zwischen den Zeilen geben die Operationen an, wie die Zahlen der nächsten Zeile berechnet werden; jede Operation muss genau einmal verwendet werden.
<G-vec00141-002-s569><indicate.angeben><en> ➋ The operator-number-pairs between the lines indicate the operations how the numbers in the line below are calculated from the numbers in the line above, not necessarily in the right order.
<G-vec00141-002-s570><indicate.angeben><de> Wir benachrichtigen Sie über einen Hinweis auf unserer Website und/oder Ihrem Gerät im Voraus über jegliche wesentliche Änderungen unserer Datenschutzhinweise und geben oben im Hinweis an, wann dieser zuletzt aktualisiert wurde.
<G-vec00141-002-s570><indicate.angeben><en> We will post a notice on our website and/or your device to notify you of significant changes to our Privacy Notice and indicate at the top of the notice when it was most recently updated.
<G-vec00141-002-s571><indicate.angeben><de> (2) Die öffentlichen Auftraggeber geben in der Auftragsbekanntmachung oder in der Aufforderung zur Interessensbestätigung an, ob Angebote nur für ein Los oder für mehrere oder alle Lose eingereicht werden können.
<G-vec00141-002-s571><indicate.angeben><en> Contracting entities shall indicate, in the contract notice, in the invitation to confirm interest, or, where the means of calling for competition is a notice on the existence of a qualification system, in the invitation to tender or to negotiate, whether tenders may be submitted for one, for several or for all of the lots.
<G-vec00141-002-s572><indicate.angeben><de> Servale geben die Grenzen ihres Territoriums an durch Urin zu spritzen.
<G-vec00141-002-s572><indicate.angeben><en> Servals indicate the boundaries of their territory by spraying with urine.
<G-vec00141-002-s573><indicate.angeben><de> Betreuung der Auswertung und/oder Mikroverfilmung von mehr als 600.000 Akten aus der NS-Zeit und Nachkriegszeit, die Aufschluß geben über die Verfolgung und Ermordung der europäischen Juden.
<G-vec00141-002-s573><indicate.angeben><en> Support the evaluation and microfilming of more than 600,000 records from the Nazi era and postwar period, which indicate the persecution and murder of European Jewry.
<G-vec00141-002-s574><indicate.angeben><de> Die Zahlen der GDWS geben einen Rückgang von 16,4 % für das ganze Jahr 2018 an.
<G-vec00141-002-s574><indicate.angeben><en> Figures from the GDWS indicate -16.4 % for the total year 2018.
<G-vec00141-002-s575><indicate.angeben><de> (1) Die Genehmigung für das Inverkehrbringen kann mit der Verpflichtung des Inhabers der Genehmigung für das Inverkehrbringen verbunden werden, auf dem Behältnis und/oder der äußeren Umhüllung und der Packungsbeilage, wenn Letztere gefordert wird, weitere wichtige Hinweise für die Sicherheit und den Gesundheitsschutz zu geben, einschließlich der besonderen Vorsichtsmaßnahmen bei der Verwendung und anderer Warnungen, die sich aus den klinischen und pharmakologischen Prüfungen gemäß Artikel 12 Absatz 3 Buchstabe j) und Artikel 13 Absatz 1 oder aus der praktischen Erfahrung mit dem Tierarzneimittel, nachdem es auf dem Markt angeboten wurde, ergeben.
<G-vec00141-002-s575><indicate.angeben><en> 1. The marketing authorization may require the holder to indicate on the container and/or the outer wrapping and the package insert, where the latter is required, other particulars essential for safety or health protection, including any special precautions relating to use and any other warnings resulting from the clinical and pharmacological trials prescribed in Articles 12(3)(j) and 13(1) or from experience gained during the use of the veterinary medicinal product once it has been marketed.
<G-vec00141-002-s576><indicate.angeben><de> Die Zahlen geben Standorte der Nächte.
<G-vec00141-002-s576><indicate.angeben><en> The numbers indicate locations of nights.
<G-vec00141-002-s577><indicate.angeben><de> Personen, die zufrieden sind mit ihrer sozialen Unterstützung, sind physisch und psychisch gesünder, berichten über weniger Schmerzen, können besser mit belastenden Lebenssituationen umgehen und geben eine höhere Lebenszufriedenheit an.
<G-vec00141-002-s577><indicate.angeben><en> People who are satisfied with the social support they receive, are physically and mentally healthier, report less pain, are coping better with burdening life situations and indicate a higher degree of life satisfaction.
<G-vec00141-002-s578><indicate.angeben><de> Bei Fragen zu Ihrer Bestellung geben Sie bitte die entsprechende Rechnungsnummer an.
<G-vec00141-002-s578><indicate.angeben><en> For questions about your order, please indicate the corresponding invoice number. Categories
<G-vec00141-002-s579><indicate.angeben><de> CASTLE MALTING®: Zur Preisanfrage hinzufügen HALLERTAUER MITTELFRUH BIO /DE (Hopfen: HALLERTAUER MITTELFRUH BIO /DE (Bitte geben Sie genaue Menge und die gewünschte Verpackungsart für die Sie interessierenen Artikel an.
<G-vec00141-002-s579><indicate.angeben><en> CASTLE MALTING®: Add to price request HALLERTAUER BLANC /DE (Please indicate the exact quantity and the preferred packaging for the products you are interested in.
<G-vec00141-002-s580><indicate.angeben><de> Geben Sie auf der Seite Virtuelle Maschinen die Anzahl der virtuellen CPUs und die Anzahl von Kernen pro vCPU an.
<G-vec00141-002-s580><indicate.angeben><en> On the Virtual Machines page, indicate the number of virtual CPUs and the number of cores per vCPU.
<G-vec00141-002-s581><indicate.angeben><de> Die Zahlen geben an wie oft die leuchtenden Kacheln im Raster platziert werden müssen.
<G-vec00141-002-s581><indicate.angeben><en> The numbers indicate how many tiles you have to place.
<G-vec00141-002-s582><indicate.angeben><de> Um dies zu tun, geben Sie in Ihrem Administrationsbereich das PayPal-Konto der Organisation an, die Sie unterstützen wollen, an Stelle Ihres persönlichen PayPal-Kontos.
<G-vec00141-002-s582><indicate.angeben><en> To do so, go to your admin panel and indicate the PayPal account of the organization you're supporting instead of your personal account. Members' Area
<G-vec00141-002-s583><indicate.angeben><de> Bei Initiativbewerbungen geben Sie bitte an, für welche Einsatzbereiche Sie sich interessieren und warum.
<G-vec00141-002-s583><indicate.angeben><en> In case of speculative applications, please indicate the area of work you are interested in and why.
<G-vec00141-002-s584><indicate.angeben><de> Im Übertragungstitel geben wir Daten wie Vor- und Nachname, Name der Entität und Datum aus dem Antrag an.
<G-vec00141-002-s584><indicate.angeben><en> In the transfer title, we indicate data such as first and last name, name of the entity and date from the application.
<G-vec00141-002-s585><indicate.angeben><de> Mit der Teilnahme an einer mündlichen oder schriftlichen Prüfung geben Sie an, dass Sie prüfungsfähig sind.
<G-vec00141-002-s585><indicate.angeben><en> By participating in an oral or written exam, you indicate that you are auditable.
<G-vec00141-002-s586><indicate.angeben><de> Bitte geben Sie eine Telefonnnummer oder E-Mail-Adresse für allfällige Rückfragen an.
<G-vec00141-002-s586><indicate.angeben><en> Please also indicate a phone number for any further inquiries.
<G-vec00141-002-s587><indicate.angeben><de> Bitte geben Sie auf dem Anmeldeformular Ihr Kreditkarteninstitut, Ihre Kreditkartennummer, das Gültigkeitsdatum und den Karteninhaber an.
<G-vec00141-002-s587><indicate.angeben><en> Please indicate on the registration form your credit card organisation, credit card number, expiry date and name of card holder.
<G-vec00141-002-s588><indicate.angeben><de> Knapp 70 Prozent geben an, dass aktuell keine wichtigen Benefits fehlen.
<G-vec00141-002-s588><indicate.angeben><en> Nearly 70 percent indicate that no important benefits are missing at present.
<G-vec00141-002-s589><indicate.angeben><de> * Die Abmessungssymbole N und V3 geben die Größe des Freiraums für den Nietkopf während der Montage an.
<G-vec00141-002-s589><indicate.angeben><en> and V3 indicate the clearance dimensions for the rivet head during mounting.
<G-vec00141-002-s590><indicate.angeben><de> Die Ziehpunkte geben an, dass eine Form oder ein Objekt markiert wurde.
<G-vec00141-002-s590><indicate.angeben><en> Sizing handles indicate that a shape or object has been selected.
<G-vec00141-002-s591><indicate.angeben><de> Damit Sie im Falle einer Kursauslastung dennoch möglichst einen Ihrer bevorzugten Workshops besuchen können, geben Sie bitte bei der Anmeldung jeweils Ihre erste und zweite Präferenz für jeden Workshop an.
<G-vec00141-002-s591><indicate.angeben><en> To provide you with one of your preferred workshops also in the case of a high number of applications, we kindly ask you to indicate your first and second preferences for each workshop when you apply.
<G-vec00141-002-s592><indicate.angeben><de> Bitte geben Sie hier die Rechnungsinformationen an.
<G-vec00141-002-s592><indicate.angeben><en> Please indicate billing information here.
<G-vec00141-002-s593><indicate.angeben><de> In diesem Blog finden Sie Ratschläge zum Lackieren oder Antifouling Ihres Bootes, Produktinformationen und wir geben an, welche zusätzlichen Materialien Sie benötigen.
<G-vec00141-002-s593><indicate.angeben><en> In this blog you will find advice for painting and applying antifouling to your boat. You will find product information and we indicate which additional materials you need.
<G-vec00141-002-s594><indicate.angeben><de> Diese Warnmeldungen geben an, dass das physische Medium für das Gerät geändert wurde.
<G-vec00141-002-s594><indicate.angeben><en> These alert messages indicate that the physical media has changed for the device.
<G-vec00141-002-s595><indicate.angeben><de> Bitte geben Sie Ihre Präferenz im Feld für besondere Anfragen bei Ihrer Reservierung an.
<G-vec00141-002-s595><indicate.angeben><en> Please indicate your preference in the Special Requests field during your reservation process.
<G-vec00141-002-s596><indicate.angeben><de> (6) Die Mitgliedstaaten erteilen der Kommission (Eurostat) alle von ihr gewünschten Auskünfte bezüglich Organisation und Methodik der Erhebung und geben insbesondere die Kriterien für die Gestaltung und den Umfang der Stichprobe an.
<G-vec00141-002-s596><indicate.angeben><en> Member States shall provide the Commission (Eurostat) with whatever information is required concerning the organisation and methodology of the survey, and in particular, they shall indicate the criteria adopted for the design and size of the sample.
<G-vec00141-002-s597><indicate.angeben><de> Wenn Sie Eintrittskarten für PortAventura als Geschenk anbieten möchten, geben Sie bitte den Namen der Person, die in den Park gehen wird, beim Kauf der Tickets an.
<G-vec00141-002-s597><indicate.angeben><en> If you wish to offer tickets to PortAventura as a gift, please indicate the name of the person who will go to the Park when purchasing the ticket online.
<G-vec00141-002-s599><indicate.angeben><de> Geben Sie Personalisierung Text in Ihre "Nachricht an Verkäufer".
<G-vec00141-002-s599><indicate.angeben><en> Indicate personalized text in "Message to Seller."
<G-vec00141-002-s600><indicate.angeben><de> News Bitte geben sie bei der Überweisung ihre Bestellnummer an, diese erhalten sie mit der Bestellmail.
<G-vec00141-002-s600><indicate.angeben><en> News Please indicate on your transfer the order number, that you receive with the order email.
<G-vec00141-002-s601><indicate.angeben><de> Bitte geben Sie Ihre persönlichen Anforderungen, wie Farben, Pakete, Wert der Deklaration usw., anDHgate's Nachricht, wenn Sie an uns zahlen.
<G-vec00141-002-s601><indicate.angeben><en> Please indicate your personal requirement, such as colors, packages, value of declaration etc, at DHgate's message when you pay to us.
<G-vec00141-002-s602><indicate.angeben><de> Wenn Sie auf dem Steckbrief des Restaurants sind, klicken Sie auf « Bewerten », geben Sie Ihre allgemeine Zufriedenheit an (Note 20/20), fügen Sie Ihr Kommentar hinzu.
<G-vec00141-002-s602><indicate.angeben><en> Once you are on the restaurant's page, click on “Write a review” and indicate your overall satisfaction with a grade and enter your comments.
<G-vec00141-002-s603><indicate.angeben><de> Geben Sie in diesem Abschnitt die Daten an, die erforderlich sind, um Sie erneut zu kontaktieren.
<G-vec00141-002-s603><indicate.angeben><en> Indicate in this section the data necessary to contact you again.
<G-vec00141-002-s604><indicate.angeben><de> Wenn die Daten in einer Hierarchie von Elementen innerhalb anderer Elemente angeordnet sind, geben Sie ein untergeordnetes Element mit einem umgekehrten Schrägstrich (\) an.
<G-vec00141-002-s604><indicate.angeben><en> If the data is arranged in a hierarchy of items within items, use a backslash (\) to indicate a child item.
<G-vec00141-002-s605><indicate.angeben><de> 1- Geben Sie den Titel des Albums und nur der Titel des Albums.
<G-vec00141-002-s605><indicate.angeben><en> 1- Indicate the title of your album and only the title of the album.
<G-vec00141-002-s606><indicate.angeben><de> Geben Sie auch Ihre bevorzugte Marke und Technik an.
<G-vec00141-002-s606><indicate.angeben><en> Also indicate your favourite brand and Talens Bruynzeel Sakura
<G-vec00141-002-s607><indicate.angeben><de> Benötigen Sie eine Größe, die wir nicht anbieten, Bitte wählen Sie "Benutzerdefiniert" und geben Sie die Maße an der Kasse.
<G-vec00141-002-s607><indicate.angeben><en> If you need a size that we do not offer please select "custom" and then indicate the measurements at checkout.
<G-vec00141-002-s608><indicate.angeben><de> DAS PRODUKT KONNTE NICHT IN DEN WARENKORB GELEGT WERDEN Bitte geben Sie die Anzahl und spezifischen Bedingungen für jedes Produkt an, das Sie Ihrem Warenkorb hinzufügen möchten.
<G-vec00141-002-s608><indicate.angeben><en> IT HAS NOT BEEN POSSIBLE TO ADD THE PRODUCT TO THE CART Please indicate the number of units and specific conditions The building it self was amazing to see.
<G-vec00141-002-s609><indicate.angeben><de> Schritt 2: Geben Sie auf dem Auswahlbildschirm die Anzahl der Discs an, die aufgenommen werden sollen.
<G-vec00141-002-s609><indicate.angeben><en> Step 2: from the selection screen, indicate the number of discs to be recorded.
<G-vec00141-002-s610><indicate.angeben><de> Geben Sie uns die Maße in Milimeter.
<G-vec00141-002-s610><indicate.angeben><en> The measures have to indicate us in millimeters.
<G-vec00141-002-s611><indicate.angeben><de> Geben Sie den Preis des Produktes auf dem Markt.
<G-vec00141-002-s611><indicate.angeben><en> Indicate the price of the product on the market.
<G-vec00141-002-s612><indicate.angeben><de> Geben Sie den Einzahlungsbetrag an, wählen Sie „NETELLER“ aus, und nachfolgend die Währung der Überweisung und die Account-Nummer im Zahlungssystem (bei Einzahlungen geben Sie bitte Ihre Sicherheits-ID ein).
<G-vec00141-002-s612><indicate.angeben><en> Indicate the deposit amount, select "NETELLER" and the transfer currency, and specify the payment system account number (if depositing funds, indicate your Secure ID).
<G-vec00141-002-s613><indicate.angeben><de> Geben Sie den Zielort, um die geschätzten Versandpreis zu berechnen.
<G-vec00141-002-s613><indicate.angeben><en> Indicate the destination to calculate the estimated shipping price.
<G-vec00141-002-s614><indicate.angeben><de> Verknüpfungen mit Ihren anderen Präsenzen auf Internet: geben Sie die Links zu Ihren Social Network-Portalen an; teilen Sie easy-CV auf den Formularen mit, verwenden Sie ein Widget oder nutzen Sie die Facebook- Anwendung.
<G-vec00141-002-s614><indicate.angeben><en> Build bridges with your other presences on Internet: indicate the links towards the social networks which you use; on your network forms indicate easy-CV or use a widget or the Facebook application.
<G-vec00141-002-s615><indicate.angeben><de> Bitte geben Sie Ihren Namen, Ihre E-Mail an und schreiben eine Nachricht, wir melden uns so bald wie möglich zurück.
<G-vec00141-002-s615><indicate.angeben><en> Please necessarily indicate your name, email and a message text, we will reply you as soon as possible.
<G-vec00141-002-s616><indicate.angeben><de> Geben Sie unter „Preflight-Profil“ an, ob Sie das im Menü „Profil verwenden“ angegebene Profil oder das im jeweiligen Dokument eingebettete Profil verwenden möchten.
<G-vec00141-002-s616><indicate.angeben><en> Under Preflight Profile, indicate whether you want to use the profile specified in the Use Profile menu or the embedded profile of each document.
<G-vec00141-002-s617><indicate.angeben><de> Bitte geben Sie den Namen eines ordnungsgemäß bevollmächtigten Vertreters oder (Zoll-)Agents, der im Namen des Antragstellers handelt, an, falls der Antrag nicht vom Antragsteller eingereicht wird.
<G-vec00141-002-s617><indicate.angeben><en> Please indicate the name of a duly authorised representative or (customs) agent acting on behalf of the applicant, if the application is not presented by the applicant.
<G-vec00141-002-s629><indicate.angeben><de> Ein Dreieckssymbol neben der Spaltenüberschrift gibt an, nach welcher Spalte gegenwärtig sortiert wird.
<G-vec00141-002-s629><indicate.angeben><en> A triangle icon next to the column heading indicate which column is currently used to sort.
<G-vec00141-002-s630><indicate.angeben><de> Wenn dies vernünftigerweise nicht möglich ist, gibt der Unternehmer an, auf welche Art und Weise die Allgemeinen Geschäftsbedingungen eingesehen werden können und dass sie auf Verlangen kostenlos versandt werden, bevor der Fernvertrag geschlossen wird.
<G-vec00141-002-s630><indicate.angeben><en> If this is reasonably impossible, the Entrepreneur shall indicate in what way the General Terms and conditions can be inspected and that they will be sent free of charge if so requested, before the distant contract is concluded.
<G-vec00141-002-s631><indicate.angeben><de> Einer der jüngsten Berichte gibt an, dass Handlaser hauptsächlich grün (in fast 95% der Fälle) im Gegensatz zu rot sind[xi].
<G-vec00141-002-s631><indicate.angeben><en> Reports indicate that illuminations by handheld lasers are primarily green (91%) in color.
<G-vec00141-002-s632><indicate.angeben><de> Bei der Bekanntgabe der Preise gibt der Dienstleister den Steuersatz (MwSt., IFA) der Preise an, der gesetzlich geregelt ist.
<G-vec00141-002-s632><indicate.angeben><en> When announcing the prices, the Service Provider shall indicate the rate of the tax (VAT, IFA) of the prices, which is governed by law.
<G-vec00141-002-s633><indicate.angeben><de> Sie gibt in jedem einzelnen Fall an, ob die betreffende Person die deutsche Staatsangehörigkeit besitzt.
<G-vec00141-002-s633><indicate.angeben><en> It shall indicate in each individual case whether the relevant person has German citizenship.
<G-vec00141-002-s634><indicate.angeben><de> Der MID gibt die für die manuelle Verifizierung verschiedener Identitäten zuständige Behörde in der Identitätsbestätigungsdatei an.
<G-vec00141-002-s634><indicate.angeben><en> The MID shall indicate the authority responsible for the manual verification of different identities in the identity confirmation file.
<G-vec00141-002-s635><indicate.angeben><de> Ein Umschalter gibt an, ob die Seite in der Seitennavigation ein- oder ausgeblendet sein soll.
<G-vec00141-002-s635><indicate.angeben><en> A toggle switch to indicate whether the page is shown or hidden in the page navigation.
<G-vec00141-002-s636><indicate.angeben><de> Eine Bildschirmanzeige gibt an, welche Tasten gedrückt werden müssen, um die Kraftanzeige zu füllen.
<G-vec00141-002-s636><indicate.angeben><en> An on-screen prompt will indicate which keys to bash in order to fill the power gauge.
<G-vec00141-002-s637><indicate.angeben><de> Sie gibt den Zeitraum Ihres Forschungsaufenthaltes an.
<G-vec00141-002-s637><indicate.angeben><en> indicate the time period of your research visit and
<G-vec00141-002-s638><indicate.angeben><de> Die Kurzinfo von „Pirschen“ gibt nun korrekt an, dass Gejagte Monster 2 Sekunden lang festgehalten werden.
<G-vec00141-002-s638><indicate.angeben><en> Tooltip updated to indicate that Hunted monsters are rooted for 2 seconds. Nocturne Shroud of Darkness
<G-vec00141-002-s639><indicate.angeben><de> Die ausstellende Behörde gibt hier die Gültigkeitsdauer des FRTD an.
<G-vec00141-002-s639><indicate.angeben><en> The issuing authority shall indicate here the period of validity of the FRTD.
<G-vec00141-002-s640><indicate.angeben><de> 2 Die Liste gibt für jedes Land die zuständige Behörde sowie die anerkannten Zertifizierungsstellen an.
<G-vec00141-002-s640><indicate.angeben><en> 2 The list shall indicate for each country the competent authority and the recognised certification bodies.
<G-vec00141-002-s641><indicate.angeben><de> Nur ein sehr kleiner Anteil von 6 Prozent der Studierenden gibt an, gar keinen Sport zu treiben.
<G-vec00141-002-s641><indicate.angeben><en> Only a very small proportion of students, namely 6 per cent, indicate that they do not engage in any sporting activities at all.
<G-vec00791-002-s006><misrepresent.angeben><de> Hierzu zählt auch, wenn Sie Content mit Bezug zu politischen und sozialen Themen oder Belangen von öffentlichem Interesse an Nutzer in einem anderen Land richten und dabei Ihr Herkunftsland oder andere wichtige Informationen zu Ihrer Person falsch angeben oder verbergen.
<G-vec00791-002-s006><misrepresent.angeben><en> This includes directing content about politics, social issues, or matters of public concern to users in a country other than your own, if you misrepresent or conceal your country of origin or other material details about yourself.
<G-vec00981-002-s097><withhold.angeben><de> In diesen Fällen ist es Ihnen eventuell nicht möglich, auf bestimmte Teile der Site zuzugreifen und wir können Ihre Anfrage eventuell nicht beantworten, wenn Sie nicht alle von uns verlangten personenbezogenen Daten angeben.
<G-vec00981-002-s097><withhold.angeben><en> In these situations, if you choose to withhold any personal data requested by us, it may not be possible for you to gain access to certain parts of the websites and for us to respond to your query.
<G-vec01009-002-s033><cite.angeben><de> Benutzer des JBDGM müssen die ursprüngliche Quelle angeben, einschließlich der Namen des Autors, JBDGM als erste Quelle der Veröffentlichung, Jahr der Veröffentlichung, Bandnummer und DOI (falls verfügbar).
<G-vec01009-002-s033><cite.angeben><en> Users (redistributors) of EJOP are required to cite the original source, including the author's names, EJOP as the initial source of publication, year of publication, volume number and DOI (if available).
<G-vec01009-002-s034><cite.angeben><de> Es spielt keine Rolle, ob wir dafür eine Quelle angeben, denn ein kurzer Besuch im Lebensmittelgeschäft reicht aus, um alle verarbeiteten Lebensmittel mit Zucker und die mit Salz gefüllten Konserven zu sehen.
<G-vec01009-002-s034><cite.angeben><en> It does not even matter if we cite a source for this one since a short trip to the grocery store is enough for you to see all the processed foods filled with sugar and canned goods filled with salt.
<G-vec01009-002-s120><cite.angeben><de> Die stenotope, hygrophile und gramineicole Art lebt am Ästigen Igelkolben (Sparganium erectum) und am Breitblättrigen Rohrkolben (Typha latifolia), einige Autoren geben auch Seggen (Carex) an.
<G-vec01009-002-s120><cite.angeben><en> The stenotopic, hygrophilous and graminicolous species lives on simplestem bur-reed (Sparganium erectum) and on common bulrush (Typha latifolia), some authors also cite sedges (Carex) as host plant.
<G-vec01009-002-s121><cite.angeben><de> Bitte geben Sie immer Kundennummer, Rechnungsnummer und Grund der Rücksendung an.
<G-vec01009-002-s121><cite.angeben><en> Please always cite your customer number, invoice number and reason for returning the product.
<G-vec01009-002-s122><cite.angeben><de> Bitte geben Sie jeder Verwendung unseres Bildmaterials folgende Quellenangabe an: „Foto: Messe München“, danke sehr.
<G-vec01009-002-s122><cite.angeben><en> Please cite the following source every time you use our images: “Photo: Messe München.” Thank you. Save the date
<G-vec01009-002-s068><quote.angeben><de> o sicherstellen, dass sie bei der Buchung oder beim Check-in ihre Privilege Club Mitgliedsnummer angeben.
<G-vec01009-002-s068><quote.angeben><en> o Ensure they quote their Privilege Club number at the time of booking or check-in.
<G-vec01009-002-s069><quote.angeben><de> Sie können auch anrufen, die Nummer des Tickets angeben und ein Gerät für eine bestimmte Zeit reservieren.
<G-vec01009-002-s069><quote.angeben><en> You can also call and quote the number on your ticket to reserve a device for a specific time.
<G-vec01009-002-s070><quote.angeben><de> Sie können einen speziellen Rabattcode, die sogenannte “CDP Nummer” angeben, wenn Sie bei Hertz anmieten, die Sie, falls Sie dafür teilnahmeberechtigt sind, zu den Sonderrabatten oder Vorteilen berechtigt, die wir eventuell mit dem sponsernden Unternehmen, Verband, Kreditkartenunternehmen oder Reiseclub (CDP Sponsor) ausgehandelt haben.
<G-vec01009-002-s070><quote.angeben><en> You may quote a special discount code, called a “CDP number”, when you rent with Hertz, entitling you to the special rate or benefits we may have negotiated with your company, association, credit card company or travel club (the “CDP Sponsor”).
<G-vec01009-002-s071><quote.angeben><de> Gewisse Angebote auf der Website der GL Zürich können Sie nur nutzen, wenn Sie persönliche Daten angeben.
<G-vec01009-002-s071><quote.angeben><en> Certain offers on GL Zürich’s website can only be utilised if you quote personal data.
<G-vec01009-002-s072><quote.angeben><de> Das Senden der Zeichnung mit den Maßen ist der erste Schritt zum Angeben oder Erstellen eines Musters.
<G-vec01009-002-s072><quote.angeben><en> Sending the drawing with dimensions to us is the first step to quote or make sample.
<G-vec01009-002-s073><quote.angeben><de> Darüber hinaus müssen alle Fluggesellschaften, die von, nach oder innerhalb der USA fliegen, alle Gepäck- und Sonderpostengebühren zum Zeitpunkt des Flugtarifangebots angeben.
<G-vec01009-002-s073><quote.angeben><en> Additionally, all airlines traveling from, to, or within the United States are required to specify all baggage and special item charges at the time of passenger fare quote.
<G-vec01009-002-s074><quote.angeben><de> Links auf das Internet-Portal der made-in-germany.com AG sind nur im Rahmen des gesetzlich Zulässigen erlaubt und müssen die made-in-germany.com AG als Quelle angeben; insbesondere Framing-Techniken sind nicht erlaubt.
<G-vec01009-002-s074><quote.angeben><en> Links to the made-in-germany.com AG website are only permitted within the framework of what is lawful and must quote made-in-germany.com AG as the source; framing, in particular, is not permitted.
<G-vec01009-002-s075><quote.angeben><de> Bei Büchern, Artikeln und den meisten schriftlichen Arbeiten musst du den Nachnamen des Autors, sowie die Seitennummer oder -nummern angeben, aus denen das Zitat stammt.
<G-vec01009-002-s075><quote.angeben><en> For books, articles, and most written works, you need to provide the last name of the author and the page number or page range the quote or citation was pulled from.
<G-vec01009-002-s076><quote.angeben><de> Die Art des aufgetretenen Fehlers oder Problems – bitte die vollständige Fehlermeldung angeben.
<G-vec01009-002-s076><quote.angeben><en> The type of error or problem you have encountered - please quote the complete error message.
<G-vec01009-002-s220><quote.angeben><de> Wir geben die bedeutsamsten Auszüge des von diesem Zeugen gelieferten Berichts wieder; für das in diesem Abschnitt behandelte Thema sind sie ungemein aufschlußreich.
<G-vec01009-002-s220><quote.angeben><en> We shall quote the most significant excerpts of the report supplied by this witness; they are immensely revealing where our current subject is concerned:4
<G-vec01009-002-s221><quote.angeben><de> Immer wieder geben die Hersteller von UV-Schutztextilien statt des UPF auch an, wie viel Prozent der UV-Strahlung von ihren Produkten zurückgehalten werden.
<G-vec01009-002-s221><quote.angeben><en> Instead of the UPF, the manufacturers of UV protection textiles often quote what percentage of the UV radiation is blocked by their products.
<G-vec01009-002-s222><quote.angeben><de> ● Bitte geben Sie bei Buchung oder Check-in unbedingt Ihre Privilege Club Mitgliedsnummer an, damit die Bonus Qmiles nach der Reise automatisch gutgeschrieben werden.
<G-vec01009-002-s222><quote.angeben><en> To be eligible for Bonus Qmiles, members need to ensure they quote their Privilege Club number at the time of booking or check-in so that bonus Qmiles can be credited automatically after travelling.
<G-vec01009-002-s223><quote.angeben><de> Wir geben den Text dieses historisch sehr bedeutsamen, doch niemals veröffentlichten und anscheinend auch der polnischen Geschichtsschreibung unbekannten Dokuments im folgenden wieder.
<G-vec01009-002-s223><quote.angeben><en> In the following we shall quote the text of this historically very significant, yet to date unpublished document, which seems to be unknown even in Polish historiography.
<G-vec01009-002-s224><quote.angeben><de> Viele Lieferanten geben die teureren oder preiswerteren Preise an.
<G-vec01009-002-s224><quote.angeben><en> A lot of suppliers quote more expensive or cheaper prices.
<G-vec01009-002-s225><quote.angeben><de> Dann geben wir Ihnen den Gesamtbetrag inklusive Versandkosten an.
<G-vec01009-002-s225><quote.angeben><en> Then we'll quote you total amount including shipping charge.
<G-vec01009-002-s226><quote.angeben><de> Die quantitative Auswertung soll stoffbezogen erfolgen, d.h., bitte geben Sie die Ergebnisse nicht als Toluoläquivalent an.
<G-vec01009-002-s226><quote.angeben><en> The quantitative evaluation should be based on the substance, so please do not quote the results as toluene equivalent.
<G-vec01009-002-s227><quote.angeben><de> - Royal Skies Mitglieder geben bei der Reservierung bitte Ihre Mitgliedsnummer an und legen Ihre Mitgliedskarte bei der Anmietung in der Hertz Vermietstation vor.
<G-vec01009-002-s227><quote.angeben><en> Royal Skies Members are required to quote their membership number when placing a reservation and show their membership card at the Hertz rental counter during vehicle pick up.
<G-vec01009-002-s228><quote.angeben><de> Bestätigen Sie die Probendaten, geben den Preis, und senden Proben per Kurier möglicherweise schnell .
<G-vec01009-002-s228><quote.angeben><en> Confirm the sampling data, quote the price, and send samples by courier possibly quickly.
<G-vec01009-002-s229><quote.angeben><de> Geben Sie bei Ihrer Reservierung oder beim Check-in bitte unbedingt Ihre Mitgliedsnummer an, um sich Ihr Recht auf die Bonus Qmiles zu sichern.
<G-vec01009-002-s229><quote.angeben><en> Please ensure you quote your membership number at the time of reservation or check-in so that your Qmiles will be credited once you have enrolled.
<G-vec01009-002-s230><quote.angeben><de> Bitte geben Sie bei der Buchung die Kartennummer Ihres Vielfliegerprogramms an und legen Sie beim Einchecken Ihre Karte vor.
<G-vec01009-002-s230><quote.angeben><en> Please quote your airline membership program card number at the time of booking and present your card when checking-in
<G-vec01009-002-s231><quote.angeben><de> Bitte geben Sie alle Vor- und Nachnamen genauso an, wie sie in Ihrem Reisepass stehen.
<G-vec01009-002-s231><quote.angeben><en> Please ensure that you quote your last name and first name exactly as stated in your passport.
<G-vec01009-002-s232><quote.angeben><de> Die Analysten geben die Preise für monokristalline Wafer außerhalb Chinas mit gut 0,40 US-Dollar pro Stück an.
<G-vec01009-002-s232><quote.angeben><en> The analysts quote prices for monocrystalline wafers outside of China at just over US$0.40 apiece.
<G-vec01009-002-s233><quote.angeben><de> Geben Sie bei der Reservierung Ihre Sixt Card Nummer* durch.
<G-vec01009-002-s233><quote.angeben><en> Just quote your Sixt Card number or the number of your credit card.
<G-vec01009-002-s234><quote.angeben><de> 2018-01-16 - Guten Morgen, Bitte geben Sie Ihren besten Preis für die Lieferung und Lieferung der Artikel 1 bis 3 der beigefügten Liste an.
<G-vec01009-002-s234><quote.angeben><en> 2018-01-16 - Good morning, Please quote your best price for the supply and delivery of items 1 THROUGH 3 of attached list.
<G-vec01009-002-s235><quote.angeben><de> London HINWEIS: Bitte geben Sie die eFC Ref Nr: 1103384 als Referenz bei Ihrer Bewerbung an.
<G-vec01009-002-s235><quote.angeben><en> London Note: Please quote eFC Ref: 1103384 when applying for this job.
<G-vec01009-002-s236><quote.angeben><de> Geben Sie einfach Ihre eigenen Preise auf.
<G-vec01009-002-s236><quote.angeben><en> Easily quote your own rates and yield.
<G-vec01009-002-s237><quote.angeben><de> Bitte geben Sie Ihre Mitgliedsnummer an, wenn Sie Ihren Flug buchen, und weisen Sie beim Check-in Ihre Emirates Skywards-Karte vor.
<G-vec01009-002-s237><quote.angeben><en> Please quote your membership number when booking your flight, and present your Emirates Skywards card at check-in.
<G-vec01009-002-s238><quote.angeben><de> Geben Sie bei postalischer Bewerbung in der Betreffzeile immer die Kennziffer der gewünschten Position an, die Sie in jeder unserer Ausschreibungen finden (Print- und Online-Medien, Homepage).
<G-vec01009-002-s238><quote.angeben><en> Quote the reference number of the position you are applying for in the subject line. All of our job advertisements have a reference number (print and online media, homepage).
<G-vec01009-002-s239><quote.angeben><de> HINWEIS: Bitte geben Sie die eFC Ref Nr: 1100942 als Referenz bei Ihrer Bewerbung an.
<G-vec01009-002-s239><quote.angeben><en> Marketing 6 Note: Please quote eFC Ref: 1102821 when applying for this job.
<G-vec01009-002-s240><quote.angeben><de> Bitte geben Sie bei der Buchung des Aufenthalts direkt in einem der teilnehmenden Hotels oder über die Reservierungszentrale (Europa: +800 1800 1800, USA und Kanada: 1 800 424 6835, Japan 0120 455 655, Nahost und Afrika +971 44 29 05 28) den Buchungscode „Wochenendreisen“ an.
<G-vec01009-002-s240><quote.angeben><en> Please quote ‘7 Day Winter Sale Weekend Escapes’ when booking directly at a participating hotel or via our Central Reservation Office (European Countries: +800 1800 1800, United States and Canada: 1 800 424 6835, Japan 0120 455 655, Middle East and Africa +971 44 29 05 28).
