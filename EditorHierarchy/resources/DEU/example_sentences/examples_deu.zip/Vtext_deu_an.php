<G-vec00403-002-s052><pull.an><de> F * Die Zahl gibt die Anzahl der benötigten Seilzugklappenhalter an.
<G-vec00403-002-s052><pull.an><en> F * The specified number refers to the number of required flap stays with pull cable.
<G-vec00403-002-s053><pull.an><de> Der Vermieter hat verlangt das wenn wir vom Strand kommen und nasse Badesachen an haben diese noch unten auszuziehen und aufzuhängen und dann erst nach oben zu unserem Apartment zu gehen.
<G-vec00403-002-s053><pull.an><en> The landlord has requested that when we come from the beach and wet bathing have to pull these still down and hang up and then go up to our apartment.
<G-vec00403-002-s054><pull.an><de> Bei kontrolliertem Freifall Seilzug an der Trommel 6,5 bis 325 kN.
<G-vec00403-002-s054><pull.an><en> Controlled free fall application, line pull 6,5 kN to 325 kN.
<G-vec00403-002-s055><pull.an><de> Das Material zieht nicht an den Haaren.
<G-vec00403-002-s055><pull.an><en> Material does not pull the hair.
<G-vec00403-002-s056><pull.an><de> Die Band lehnt sich oft in nur einer Komposition gleichzeitig an GARY NUMAN, THE KINKS oder obskuren Prog an.
<G-vec00403-002-s056><pull.an><en> Gardens & Villa may simultaneously pull from Gary Numan, The Kinks and odder prog within one composition.
<G-vec00403-002-s057><pull.an><de> Nun ist es an der Zeit, wieder die himmlischen Vorhänge zurückzuziehen und das Licht zu dämpfen.
<G-vec00403-002-s057><pull.an><en> Now it’s time to pull back the heavenly curtains and dim the lights.
<G-vec00403-002-s058><pull.an><de> Das Sein selbst wirft den Menschen in die Bahn dieses Fortrisses, der ihn über ihn selbst hinweg als den Ausrückenden an das Sein zwingt, um dieses ins Werk zu setzen und damit das Seiende im Ganzen offenzuhalten.
<G-vec00403-002-s058><pull.an><en> Being itself throws humans onto the track of this pull which compels them to surpass themselves as those who move out toward being in order to set it up in a work and thus to keep the totality of beings open.
<G-vec00403-002-s059><pull.an><de> Santoros grossformatige Photographie “Pulleys” (2016) spielt auf den metaphorischen Subtext der ‘pulley’ (Flaschenzug) an, bei der Vermittlung und Politik als eine Kombination strategischer Stoss- und Ziehkräften verstanden wird.
<G-vec00403-002-s059><pull.an><en> Santoro’s large scale photographic work “Pulleys” (2016) alludes to the metaphorical subtext of the pulley in which mediatisation and politics are seen as a combination of push and pull forces, usually of a strategic nature.
<G-vec00403-002-s060><pull.an><de> Während beim bedarfsgesteuerten System der Push-Charakter im Vordergrund steht, zeichnen sich verbrauchsgesteuerte Systeme durch einen Pull-Charakter aus: Das Material, das an den Produktiveinheiten benötigt wird, wird in einem dezidierten Prozess geplant.
<G-vec00403-002-s060><pull.an><en> In the needs-based system, the push character is critical. In consumption-based systems, the pull character is decisive: The material needed by the production units is planned in a clearly defined process.
<G-vec00403-002-s061><pull.an><de> Hebe den Akku an der Kante an, die dem Logic Board am nächsten ist, und entferne ihn aus dem Gehäuse.
<G-vec00403-002-s061><pull.an><en> Menú Use the attached plastic pull tab to remove the battery from the upper case.
<G-vec00403-002-s062><pull.an><de> Jemand sagte mir, ich würde durch viele Unannehmlichkeiten gehen, nur um einen Schwindel an den Haaren herbeizuziehen.
<G-vec00403-002-s062><pull.an><en> Someone told me that I was going through a lot of trouble to pull a hoax.
<G-vec00403-002-s063><pull.an><de> Wenn du an einem neuen SRAM-Bremshebel ziehst, merkst du den Unterschied sofortdenn er hat einen kürzeren Leerweg und eine optimierte Betätigung der Bremsbeläge.
<G-vec00403-002-s063><pull.an><en> When you pull a new SRAM brake lever, you immediately notice the difference because it has a shorter free travel and an optimised actuation of the brake pads.
<G-vec00403-002-s064><pull.an><de> Unterhalb des Dorfes Disentis halte ich an einer Stelle an, wo der Fluss über kleine Felsbrocken rauscht.
<G-vec00403-002-s064><pull.an><en> I pull over next to the river tumbling over small boulders just below the town of Disentis.
<G-vec00403-002-s065><pull.an><de> Es liegt nur an dem letzten steileren Stück vor dem Kloster, Zoodochou Pigis, welches sich auf einer Höhe von 300 Metern befindet, was diese Wanderstecke über die "Einfach"-Stufe hinaus setzt.
<G-vec00403-002-s065><pull.an><en> Easy-moderate. It is only the final pull up the hill to the monastery, Zoodochou Pigis, perched at an altitude of 300 m. which lifts this walk to just above the "easy" grade.
<G-vec00403-002-s066><pull.an><de> Immer, wenn ein Pferd des Getüts Al Shaqab im Ring war, sah man an seinem Gesicht, ob es gewann oder verlor.
<G-vec00403-002-s066><pull.an><en> Anytime an Al Shaqab horse was in the ring his expression told you exactly what happened – he laughed or pull faces in disbelief.
<G-vec00403-002-s067><pull.an><de> Die Felgen überzeugen mit einer leichten und hochfesten Aluminiumlegierung, die Spline-Naben offerieren für mehr Stabilität die Straight-Pull-Technologie, kaltgeschmiedete Double-Butted-Speichen (im Mittelteil dünner als an den Enden) ergänzen den Reigen und sorgen für mehr Steifigkeit und Gewichtsersparnis.
<G-vec00403-002-s067><pull.an><en> The rims stand out for a lightweight, high-strength aluminium alloy; the Spline hubs feature the Straight Pull technology for improved stability; cold forged double butted spokes (with a thinner middle section) complement the selection and offer more stiffness and weight reduction.
<G-vec00403-002-s068><pull.an><de> Unfassbar, was die Jungs an Backflip-Variationen auf Lager hatten: beispielsweise ein Handstand beim Rückwärtssalto, Rollover- und Superman-Backflip.
<G-vec00403-002-s068><pull.an><en> It’s unbelievable the backflip variations these guys can pull off. For example, a handstand in a backflip, plus rollover and superman backflips.
<G-vec00403-002-s069><pull.an><de> Langarm-das Women's Streaker Long Sleeve an und du bist bereit für den nächsten Lauf.
<G-vec00403-002-s069><pull.an><en> Pull on the men's Streaker Long Sleeve and you're ready to run.
<G-vec00403-002-s070><pull.an><de> Und weil die Gefahr bestand, dass darunter dann jede einzelne Arbeit, aber auch der Gesamtentwurf von 'Okkupation' an Ausdruckskraft verlieren könnte, bot die WochenKlausur ihren Rücktritt an.
<G-vec00403-002-s070><pull.an><en> And since this might have meant that not only the expressiveness of every single artwork would have suffered under this circumstance, but also the expressiveness of the entire concept of 'Okkupation', WochenKlausur offered to pull out.
