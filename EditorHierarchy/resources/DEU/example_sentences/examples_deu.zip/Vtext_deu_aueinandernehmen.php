<G-vec00903-002-s037><disassemble.aueinandernehmen><de> Sie dürfen den Akku nicht aufstechen, verbrennen, auseinander nehmen oder Temperaturen über 65 °C aussetzen.
<G-vec00903-002-s037><disassemble.aueinandernehmen><en> Do not puncture, incinerate, disassemble, or expose the battery to temperatures above 65 °C (149 °F).
<G-vec00903-002-s038><disassemble.aueinandernehmen><de> Um die Gemüseauswahl haben sich mehrere stabile Mythen gebildet, von denen wir die wichtigsten jetzt auseinander nehmen.
<G-vec00903-002-s038><disassemble.aueinandernehmen><en> Around the selection of vegetables, several stable myths have formed, the most important of which we now disassemble.
