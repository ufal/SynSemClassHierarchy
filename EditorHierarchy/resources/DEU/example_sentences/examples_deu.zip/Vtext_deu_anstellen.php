<G-vec00384-001-s229><inquire.anstellen><de> Die Behörden sagten seiner Familie, dass Herr Peng durch eine Krankheit starb, und es wurde Ihnen angebotenen, dass die Begräbnis Kosten übernommen werden, wenn sie nicht weiter über die Ursache seines Todes Nachforschungen anstellen würden.
<G-vec00384-001-s229><inquire.anstellen><en> Authorities told family members that Mr. Peng died of an illness and were offered funeral expenses if they agreed to not inquire further into the cause of his death.
<G-vec00384-001-s230><inquire.anstellen><de> Ich muss diese Geschichte noch ein wenig rekonstruieren und einige Nachforschungen über Angaben und Daten anstellen.
<G-vec00384-001-s230><inquire.anstellen><en> I have to reconstruct that story a bit, inquire about some facts and dates.
<G-vec00228-002-s021><recruit.anstellen><de> Wenn man ein bestimmtes Ergebnis will, aber sich die Fähigkeiten dafür nicht erst aneignen will, kann man andere anstellen, einem zu helfen.
<G-vec00228-002-s021><recruit.anstellen><en> If you want a certain result but don’t want to acquire the skills to get that result, you can recruit others to help you.
<G-vec00228-002-s022><recruit.anstellen><de> Rund 20 Leute wird er anstellen, alle aus verschiedenen Disziplinen.
<G-vec00228-002-s022><recruit.anstellen><en> He plans to recruit around 20 people from multiple disciplines.
<G-vec00351-002-s133><issue.anstellen><de> Datenschutzerklädem Gestz über die Erlöseevidenz ist der Verkäufer dazu verpflichtet, dem Käufer eine Rechnung auszustellen.
<G-vec00351-002-s133><issue.anstellen><en> The seller is obliged to issue a receipt to the buyer under the Act on Sales Records.
<G-vec00351-002-s134><issue.anstellen><de> Er forderte Peking auf, sofort einen neuen Pass für Wang auszustellen sowie ihm zu erlauben, ohne eine weitere Einmischung China zu verlassen und zu seiner Familie in die USA zu reisen.
<G-vec00351-002-s134><issue.anstellen><en> He demanded Beijing to immediately issue Mr. Wang his passport and allow him to leave China to reunite with his family in the U.S. without any interference.
<G-vec00351-002-s135><issue.anstellen><de> „Gemäß dem Gesetz über die Umsatzerfassung ist der Verkäufer verpflichtet dem Käufer eine Rechnung auszustellen.
<G-vec00351-002-s135><issue.anstellen><en> “Pursuant to the Act on Registration of Sales, the salesperson is obliged to issue a receipt to the buyer.
<G-vec00351-002-s136><issue.anstellen><de> In den folgenden Teilen dieser Artikelreihe beleuchten wir vier verschiedene Use Cases, wie der FAS-Server in die Infrastruktur eingefügt und autorisiert wird um bei Bedarf SmartCard-Zertifikate auszustellen, mit denen die User an ihrer Citrix HDX-Session angemeldet werden, als würden sie über eine SmartCard verfügen.
<G-vec00351-002-s136><issue.anstellen><en> In the following articles of this series, we examine four different use cases, how the FAS server is inserted into the infrastructure and authorized to issue smart card certificates if required, with which the user logs on to his Citrix HDX session as if he had a smart card.
<G-vec00351-002-s137><issue.anstellen><de> Gemäß dem Gesetz über Umsatzevidenz ist der Verkäufer verpflichtet, dem Käufer eine Quittung auszustellen.
<G-vec00351-002-s137><issue.anstellen><en> As provided in the Sales Records Act, the seller is required to issue a receipt to the buyer.
<G-vec00351-002-s138><issue.anstellen><de> Die Waschanlage wurde auf SQAS Cleaning, geprüft und ist berechtigt das ECD (European Cleaning Document) auszustellen.
<G-vec00351-002-s138><issue.anstellen><en> Tank cleaning has been SQAS Cleaning tested and is authorised to issue ECD (European Cleaning Document)
<G-vec00351-002-s139><issue.anstellen><de> Aber machen Sie sich keine Sorgen, Sie werden den Sicherungsschein nicht benötigen!Seit 1994 sind Reiseveranstalter in Deutschland gesetzlich dazu verpflichtet, eine Insolvenzversicherung abzuschließen und Ihren Kunden einen Reisesicherungsschein für Pauschalreisen auszustellen.
<G-vec00351-002-s139><issue.anstellen><en> But do not worry, you will not need the security certificate! Since 1994 tour operators in Germany are required by law to take out a bankruptcy insurance and issue a travel insurance for package tours to their customers.
<G-vec00351-002-s140><issue.anstellen><de> Nach Auskunft palästinensischer Menschenrechtsverteidiger und -anwälte ist ein palästinensischer Gouverneur oder hochrangiger Beamter ermächtigt, jederzeit aus beliebigen Gründen einen Haftbefehl gegen jeden Palästinenser auszustellen.
<G-vec00351-002-s140><issue.anstellen><en> According to Palestinian human rights advocates and lawyers, a Palestinian governor or senior official is authorized to issue arrest warrants against any Palestinian for any reason.
<G-vec00351-002-s141><issue.anstellen><de> Sie dürfen sich auch nicht aufgrund der Behinderung oder der eingeschränkten Mobilität von Personen weigern, eine Buchung vorzunehmen, einen Fahrschein auszustellen oder die Personen an Bord des Fahrzeugs zu nehmen.
<G-vec00351-002-s141><issue.anstellen><en> They also are not allowed to refuse making bookings or issue tickets or remove the person from board of a vehicle due to a passenger's disability or due to his reduced mobility.
<G-vec00351-002-s142><issue.anstellen><de> Stammzertifizierungsstellen und untergeordnete Zertifizierungsstellen werden verwendet, um Zertifikate für Benutzer, Computer und Dienste auszustellen und um die Gültigkeit von Zertifikaten zu verwalten.
<G-vec00351-002-s142><issue.anstellen><en> Root and subordinate CAs are used to issue certificates to users, computers, and services, and to manage certificate validity. Web Enrollment
<G-vec00351-002-s143><issue.anstellen><de> Da Sie bei Spenden unter 200, 00 € den Kontoauszug als Spendenbeleg verwenden können, sind wir hier verpflichtet, auch die Spendenbescheinigung auf den Namen des Kontoinhabers auszustellen.
<G-vec00351-002-s143><issue.anstellen><en> Because donations of less than 200 euros can use a bank account statement to document the donation, we are obligated to issue the donation receipt in the account holder's name.
<G-vec00351-002-s144><issue.anstellen><de> Ich beabsichtigte, sie dort zu besuchen, doch die Regierung weigerte sich, mir einen Pass auszustellen.
<G-vec00351-002-s144><issue.anstellen><en> I planned to visit her there, but the government refused to issue me a passport.
<G-vec00351-002-s145><issue.anstellen><de> GlobalSigns ePKI-Lösung bietet Organisationen aller Größen die Plattform und Prozesse, um Digitale IDs auszustellen, mit denen sie im schnellen elektronischen Handel sowohl in internen als auch den oft unsicheren externen Netzwerken wettbewerbsfähig bleiben können, während sie immer noch die Anforderungen an die in SOX dargelegte Rechenschaftspflicht der Führungskräfte erfüllen.
<G-vec00351-002-s145><issue.anstellen><en> GlobalSign’s ePKI solution provides organisations of all sizes with the platform and processes to issue Digital IDs to allow them to stay competitive with fast electronic commerce within both internal and often unsecure external networks, while still meeting the executive accountability requirements set forth by SOX.
<G-vec00351-002-s146><issue.anstellen><de> Der bekannteste von ihnen war Raoul Wallenberg, der 1944 nach Budapest gesandt wurde, um Pässe und Visa für Juden mit Verbindung nach Schweden auszustellen.
<G-vec00351-002-s146><issue.anstellen><en> The most famous of them was Raoul Wallenberg, who was seconded to Budapest in 1944 to issue passports and visas for Jews with links to Sweden.
<G-vec00351-002-s147><issue.anstellen><de> Interline-Partnerschaften ermöglichen es zwei oder mehr Fluggesellschaften, im Namen der anderen Fluggesellschaften Tickets auszustellen, wobei der Airline-Code der anderen Fluggesellschaft beibehalten wird.
<G-vec00351-002-s147><issue.anstellen><en> An interline partnership allows two or more airlines to issue tickets on behalf of each other, while retaining the designator code of the other airline.
<G-vec00351-002-s148><issue.anstellen><de> Joseph M. Schenck musste sich ebenfalls an den Zahlungen beteiligen und machte den Fehler, eine der Zahlungen mit seinem persönlichen Check auszustellen.
<G-vec00351-002-s148><issue.anstellen><en> Joseph M. Schenck also had to take part at the payments but made the mistake to issue a personal check for one of these payments.
<G-vec00351-002-s149><issue.anstellen><de> Die Kommission gelangte zu dem Schluss, dass die Behörden des Vereinigten Königreichs in der Tat die EU-Vorschrift, Aufenthaltsgenehmigungen innerhalb von sechs Monaten nach Antragstellung auszustellen, nicht einhielten.
<G-vec00351-002-s149><issue.anstellen><en> The Commission concluded that the United Kingdom authorities were indeed not complying with the EU rule to issue residence cards within six months of application.
<G-vec00351-002-s150><issue.anstellen><de> Wir behalten uns vor pro Familienname nur einen Gutschein auszustellen (auch bei mehreren reservierten Zimmer), sofern die reservierten Zimmer am selben Tag anreisen.
<G-vec00351-002-s150><issue.anstellen><en> We reserve the right to issue only one voucher per family name (even if more than oneroom is reserved) if the reserved rooms arrive on the same day.
<G-vec00351-002-s151><issue.anstellen><de> Experteer ist berechtigt nach eigenem Ermessen die Rechnungen in elektronischer Form auszustellen und per E-Mail zu versenden.
<G-vec00351-002-s151><issue.anstellen><en> Experteer is entitled to issue invoices in electronic form at its discretion, and to send them via e-mail.
<G-vec00369-002-s019><employ.anstellen><de> Der Besteller darf bis zu einer Frist von zwei Jahren nach Ende der Vertragsbeziehungen zwischen uns und dem Besteller keinen Mitarbeiter von uns mittelbar oder unmittelbar abwerben, anstellen oder sonst wie beschäftigen oder mit diesem in Kontakt treten, es sei denn, der Mitarbeiter ist bereits seit 6 Monaten als Mitarbeiter von uns ausgeschieden oder wir haben vorher unsere Einwilligung (§ 183 BGB) zur Einstellung des Mitarbeiters gegeben.
<G-vec00369-002-s019><employ.anstellen><en> 16. Recruitment Restriction The Buyer may not directly or indirectly recruit, employ or otherwise engage or contact any of our employees up to two years from the end of the contract between us and the Buyer, except where the contract of employment with such employee has been terminated for at least 6 months or where we have given our prior consent to such employment in accordance with section 183 of the German Civil Code (BGB).
<G-vec00369-002-s020><employ.anstellen><de> Sie können ein Supportteam anstellen und trainieren oder es an eine Dritte Partei abgeben – denn es gibt viele Unternehmen, die Kundenservice zu einem niedrigen Preis anbieten.
<G-vec00369-002-s020><employ.anstellen><en> You can employ and train a support team or you can outsource it to a 3rd party because there are many companies out there which provide Customer Support for low prices.
<G-vec00369-002-s021><employ.anstellen><de> Wenn Sie eine Kinderbetreuungseinrichtung anstellen, sprechen Sie mit ihnen darüber, welche Speisen und Getränke sie servieren und wie viel Bewegung die Kinder bekommen.
<G-vec00369-002-s021><employ.anstellen><en> If you employ a child care provider, talk to them about what kind of food and drinks they serve and how much exercise the children get.
<G-vec00369-002-s022><employ.anstellen><de> Angesichts solch weniger Möglichkeiten glaubt Gregoire Crettaz vom SEM, die größte Hoffnung für das tunesische Praktikanten-Abkommen sei die Vernetzung mit tunesischen Unternehmen, die in der Schweiz tätig seien und Landsleute anstellen möchten, wie auch mit Schweizer Unternehmen, die mit Tunesien Geschäfte machen.
<G-vec00369-002-s022><employ.anstellen><en> Amid such sparse possibilities, Crettaz believes the best hope for the Tunisian internship agreement lies in connecting with Tunisians running businesses in Switzerland who are looking to employ some of their fellow countrymen, as well as with Swiss companies that do business in Tunisia.
<G-vec00369-002-s019><staff.anstellen><de> Die Lage des Campingplatz, das Preisleistungsverhältnis und generell die freundlichen Angestellten haben uns sehr gefallen.
<G-vec00369-002-s019><staff.anstellen><en> Our favourite little campsite in France! We love the swimming pool, the location & the very friendly staff.
<G-vec00369-002-s020><staff.anstellen><de> Als ich am nächsten Morgen zum Flughafen musste, half mir einer der Angestellten mit dem Koffer und begleitete mich.
<G-vec00369-002-s020><staff.anstellen><en> When I went to the airport in the morning, one of the staff helped me with my suitcase and brought me to the airport.
<G-vec00369-002-s021><staff.anstellen><de> Arbeiten bei Proact Wir sind kein herkömmliches Unternehmen und unsere Mitarbeiter sind keine herkömmlichen Angestellten – sie sind das Fundament, auf dem alle Aspekte unserer proaktiven Kultur und unseres branchenführenden Fachwissens aufbauen.
<G-vec00369-002-s021><staff.anstellen><en> We are no ordinary company, and our people are no ordinary members of staff – they are the foundation upon which every aspect of our proactive culture and our industry-leading expertise is built and thrives.
<G-vec00369-002-s022><staff.anstellen><de> Die Angestellten sind nett und hilfsbereit.
<G-vec00369-002-s022><staff.anstellen><en> The staff was very nice...More
<G-vec00369-002-s023><staff.anstellen><de> 7.3 Soweit die Haftung von Schletter ausgeschlossen oder beschränkt ist, gilt dies auch für die persönliche Haftung von Angestellten, Arbeitnehmer, Mitarbeitern, Vertretern und Erfüllungsgehilfen von Schletter.
<G-vec00369-002-s023><staff.anstellen><en> 7.3 To the extent to which the liability of Schletter is excluded or limited, this shall also apply to the personal liability of staff, workers, employees, representatives and vicarious agents of Schletter.
<G-vec00369-002-s024><staff.anstellen><de> Die Angestellten waren alle sehr freundlich und fast alle sprechen sehr gut Englisch.
<G-vec00369-002-s024><staff.anstellen><en> The staff was all friendly and almost all spoke pretty good English.
<G-vec00369-002-s025><staff.anstellen><de> Das Zimmer war gut und die Angestellten waren super, nichts, was Sie fragten, war ihnen zu viel Mühe.
<G-vec00369-002-s025><staff.anstellen><en> The room was good and the hotel staff were amazing, nothing you asked was too much trouble for them.
<G-vec00369-002-s026><staff.anstellen><de> Die Durchschnittsbewertung des Gehalts durch die Angestellten ist gut bis sehr gut.
<G-vec00369-002-s026><staff.anstellen><en> The average rating of the content by the staff is good to very good.
<G-vec00369-002-s027><staff.anstellen><de> Die Zimmer waren sauber, die Angestellten sehr freundlich.
<G-vec00369-002-s027><staff.anstellen><en> Especially the very friendly and polite staff.
<G-vec00369-002-s028><staff.anstellen><de> Ein syrischer Friseur (23) randaliert in seiner alten Arbeitsstätte, pöbelt die Angestellten an, greift den Vater (62) seines ehemaligen Arbeitgebers mit einem Messer vor einem Imbiss an und sticht auf ihn ein.
<G-vec00369-002-s028><staff.anstellen><en> A Syrian barber (23) rioting in his old workplace, mobbing the staff, stabbing the father (62) of his former employer with a knife in front of a snack and stabbing him.
<G-vec00369-002-s029><staff.anstellen><de> Wenn es um die Beendigung von Verträgen mit Arbeitnehmern, leitenden Angestellten, Geschäftsführern oder Vorständen geht, beraten und vertreten wir Sie und bereiten Abmahnungen und Kündigungen sowie etwaige Gesellschafterbeschlüsse vor.
<G-vec00369-002-s029><staff.anstellen><en> We counsel and represent you concerning the termination of contracts with employees, executive staff, managing directors or management board members. In this matter we will prepare warnings and notices of dismissals as well as the respective company resolutions.
<G-vec00369-002-s030><staff.anstellen><de> Von Anfang an bekamen wir nichts als Gegenleistung von allen Angestellten an Benza.
<G-vec00369-002-s030><staff.anstellen><en> From the outset we received nothing but consideration from all the staff at Benza.
<G-vec00369-002-s031><staff.anstellen><de> Deswegen ist der Kundenservice von 20.00 bis 22.00 Uhr geschlossen, damit unsere Servicemitarbeiter zusammen mit den anderen Angestellten des Unternehmens an der Party teilnehmen können.
<G-vec00369-002-s031><staff.anstellen><en> Because of this, Customer Service will be closed between 12pm - 2pm MST so that our representatives can attend the party with the rest of the corporate staff. Please plan accordingly to accommodate for this closure.
<G-vec00369-002-s032><staff.anstellen><de> Alle anderen Angestellten waren auch erstklassig.
<G-vec00369-002-s032><staff.anstellen><en> All other staff were also top notch.
<G-vec00369-002-s033><staff.anstellen><de> Später werden Sie dann auch unsere freundlichen Angestellten treffen, die unsere Bungalows und das Doppelhaus sauber halten und Ihnen am Morgen das Frühstück servieren.
<G-vec00369-002-s033><staff.anstellen><en> While waiting for us you may meet one of our friendly staff, who not only keep Guci Guesthouses spotlessly clean but will also prepare and serve your breakfast in the morning.
<G-vec00369-002-s034><staff.anstellen><de> Die BFH bietet Ihren Angestellten Sprachkurse und eintägige Workshops an.
<G-vec00369-002-s034><staff.anstellen><en> The BFH offers language courses and one-day workshops for its staff.
<G-vec00369-002-s035><staff.anstellen><de> Die Angestellten sind sehr freundlich und hilfsbereit.
<G-vec00369-002-s035><staff.anstellen><en> The staff is too job overloading and slow service.
<G-vec00369-002-s036><staff.anstellen><de> Die Angestellten waren sehr nett und das Zimmer war wie angekündigt.
<G-vec00369-002-s036><staff.anstellen><en> The staff were very nice and the room was as advertised.
<G-vec00369-002-s037><staff.anstellen><de> Ma'am Lucia und alle ihre Angestellten waren sehr zuvorkommend.
<G-vec00369-002-s037><staff.anstellen><en> Ma'am Lucia and all her staff was very accommodating.
<G-vec00484-002-s020><tuck_away.anstellen><de> Trage Schuhe, aus denen du herausschlüpfen kannst, ohne dich zu bücken oder öffne deine Schuhbänder bereits bevor du dich anstellst.
<G-vec00484-002-s020><tuck_away.anstellen><en> Wear shoes that you can slip off without bending down or undo your laces before getting in line and tuck them into your shoe.
