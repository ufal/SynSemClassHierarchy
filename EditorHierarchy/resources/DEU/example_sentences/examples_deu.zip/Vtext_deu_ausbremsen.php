<G-vec00389-002-s055><thwart.ausbremsen><de> Effektive Klimaaktionen sind die Lösungen, die Ungerechtigkeit an der Wurzel packen und die vorherrschende Erzählungen von “Sicherheit” ausbremsen.
<G-vec00389-002-s055><thwart.ausbremsen><en> Effective climate actions are those solutions that address root causes of injustice and thwart the dominant narratives of “security”.
<G-vec00656-002-s047><cripple.ausbremsen><de> Weder die Angst vor Handelskriegen noch die aktuelle Verlangsamung der Handelsströme reichten aus, um die globale Wirtschaftsaktivität auszubremsen.
<G-vec00656-002-s047><cripple.ausbremsen><en> Neither the fear of trade wars nor the actual slowdown in trade flows was serious enough to cripple global economic activity.
