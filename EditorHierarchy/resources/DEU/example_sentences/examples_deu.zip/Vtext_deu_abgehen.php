<G-vec00380-002-s036><dispense.abgehen><de> Mündliche Abreden, einschließlich der Abrede, von der Schriftform abzugehen, sind wirkungslos.
<G-vec00380-002-s036><dispense.abgehen><en> Oral agreements, including an agreement to dispense with the written form, shall not be effective.
