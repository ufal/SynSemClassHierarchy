<G-vec00380-002-s036><unload.abladen><de> Unglücklicherweise machen sie es auch schwieriger das Gepäck auf- und abzuladen.
<G-vec00380-002-s036><unload.abladen><en> Unfortunately, they also make it harder to load and unload some cargo.
<G-vec01156-002-s021><unload.abladen><de> Schwere Güter kannst du mit dem Brückenkran auf die Fahrzeuge laden oder von den Fahrzeugen abladen.
<G-vec01156-002-s021><unload.abladen><en> Heavy goods you can with the bridge crane load on the vehicles or unload from vehicles .
<G-vec01156-002-s022><unload.abladen><de> Jeder Spieler steht in seinem Zug vor der Wahl, entweder eines der Boote zu beladen oder es zu einer Baustelle zu entsenden, wo dann alle der Reihe nach ihre eigenen Steine abladen und verbauen.
<G-vec01156-002-s022><unload.abladen><en> On their turn, each player has the choice of either loading up one of the boats or sending a boat to a building site, where all players, in order, unload their stones and use them to build.
<G-vec01156-002-s023><unload.abladen><de> Abladen von Paletten mit vollen gasflaschen.
<G-vec01156-002-s023><unload.abladen><en> Unload of pallets with filled bottles.
<G-vec01156-002-s024><unload.abladen><de> Der Trigger beim Holzankauf wurde erhöht, sodass man das Holz nicht erst abladen muss.
<G-vec01156-002-s024><unload.abladen><en> The trigger when buying wood was increased, so that one does not have to unload the timber only.
<G-vec01156-002-s025><unload.abladen><de> Wenn einer Tour zu viele Paletten zugewiesen worden sind, muss ich die Paletten, die die Transportkapazität des Fahrzeuges überschreiten, abladen und eine neue Tour zusammenstellen.
<G-vec01156-002-s025><unload.abladen><en> If too many pallets are allocated to a trip, I have to "unload" the pallets that exceed a truck's transport capacity and reconfigure the trip.
<G-vec01156-002-s026><unload.abladen><de> Natürlich sind Gäste mit ungewöhnlichen Fahrzeugen immer ein Magnet für Neugierige, darum verwunderte es nicht, dass bei der Ankunft das Abladen der Ausrüstung bereits von Zuschauern begleitet wurde.
<G-vec01156-002-s026><unload.abladen><en> Needless to say, guests with unusual vehicles always act as a magnet for inquisitive people, so it is no wonder when it arrived there were already a few spectators on hand to watch them unload the equipment.
<G-vec01156-002-s027><unload.abladen><de> Um weiterzukommen, mussten sie die Zeitungen abladen und zwischenlagern.
<G-vec01156-002-s027><unload.abladen><en> In order to move forward, they had to unload the newspapers and put them somewhere.
<G-vec01156-002-s030><unload.abladen><de> Ihr solltet daher darauf achten gerade und gleichmäßig in das Silo abzuladen damit sich keine zu hohen Berge aufschichten.
<G-vec01156-002-s030><unload.abladen><en> You should therefore take care to unload straight and evenly into the silo so that no too steep heaps stack up.
<G-vec01156-002-s031><unload.abladen><de> Der Versuch, ihn im Sozialamt, im Altenheim oder an einer Autobahnraststätte abzuladen, scheitert - und so tingelt der schlagfertige Xaver nach und nach durch alle Wohnungen und bringt dabei die Familien, Partnerschaften und Berufe seiner Kinder ganz gehörig durcheinander.
<G-vec01156-002-s031><unload.abladen><en> The attempt to unload him at the social welfare office, in a retirement home or at a motorway rest stop fails - and so the punchy Xaver gradually runs through all the apartments, confusing the families, partnerships and professions of his children.
<G-vec01156-002-s032><unload.abladen><de> Bei der Ankunft auf dem Frachter hilft er dabei, Mayhew abzuladen.
<G-vec01156-002-s032><unload.abladen><en> Upon the return of the helicopter to the freighter, Lacour helped unload the injured Mayhew.
<G-vec01156-002-s033><unload.abladen><de> Besucher werden in den Sand gegrabene Kanäle erkennen, möglicherweise von antiken Schiffen, die auf Grund liefen, um ihre Waren an der Küste der Insel abzuladen.
<G-vec01156-002-s033><unload.abladen><en> Visitors will be able to discern channels dug into the sand, possibly from the ancient ships that ran aground to unload their wares on the shores of the island.
<G-vec01156-002-s034><unload.abladen><de> Fakten und Schnellbefestigung, mit der das Auf- und Abladen des Fahrrads erleichtert wird.
<G-vec01156-002-s034><unload.abladen><en> Facts and advantages Lock included Quick-fit which makes it easy to unload and load the bicycle
<G-vec01156-002-s035><unload.abladen><de> Sie sind leicht zu montieren und erfordern ein minimales Anheben der Fahrräder beim Auf- und Abladen.
<G-vec01156-002-s035><unload.abladen><en> They are easy to mount and require minimal lifting of bikes to load and unload.
<G-vec01156-002-s037><unload.abladen><de> Es ist eine Möglichkeit den Kopf aufzuräumen und seine Gedanken abzuladen.
<G-vec01156-002-s037><unload.abladen><en> It's a way to clear your head and unload your thoughts.
<G-vec01156-002-s087><unload.abladen><de> Es gibt keine Möglichkeit, Gepäck oder Anhänger an den Campingflächen abzuladen.
<G-vec01156-002-s087><unload.abladen><en> There is no opportunity to unload your luggage or trailer at the campsite.
<G-vec01156-002-s095><unload.abladen><de> Man kann dort auch jeweils alles abladen, es landet dann am Haupthof in den Silos und Lagern.
<G-vec01156-002-s095><unload.abladen><en> They also each unload everything, then it ends up on the main courtyard in the silos and warehouses.
<G-vec01156-002-s172><unload.abladen><de> Den Busch- und Baumschnitt können Sie mit dem Kistendrehgerät mit passendem Abfallcontainer sicher und rückstandlos verfahren und abladen.
<G-vec01156-002-s172><unload.abladen><en> You can safely move and unload bush and tree cuttings with the crate rotating unit with the matching waste container without leaving anything behind.
<G-vec01156-002-s173><unload.abladen><de> Weil ich den Lastwagen nicht bis in unseren Hof fahren konnte, musste ich den Schutt im Hof unseres Nachbarn abladen und dann zu uns herüber transportieren.
<G-vec01156-002-s173><unload.abladen><en> Since I couldn't get the truck all the way to our yard, I had to unload it in our neighbor's yard, and then move it over to ours.
