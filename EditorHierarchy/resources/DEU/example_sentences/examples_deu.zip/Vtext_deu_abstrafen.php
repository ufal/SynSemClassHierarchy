<G-vec00484-002-s014><penalize.abstrafen><de> Im April 2015 begann Google in den Suchergebnissen (SERPs), nicht-mobile optimierte Webseiten abzustrafen, sie also schlechter zu ranken.
<G-vec00484-002-s014><penalize.abstrafen><en> In April 2015 Google began to penalize websites which were not optimized for use on mobile devices in search results (SERP’s), giving them a worse ranking.
