<G-vec01183-002-s046><disgust.anekeln><de> Liliana blickte angeekelt weg.
<G-vec01183-002-s046><disgust.anekeln><en> Liliana looked away in disgust.
