<G-vec00789-002-s204><stain.abfärben><de> Das Filmblut trocknet im Gegensatz zu herkömmlichen Kunstblut schnell an und ist nach dem Trocknen wasserfest und färbt nicht ab.
<G-vec00789-002-s204><stain.abfärben><en> Unlike conventional fake blood, the fake blood dries up quickly and is waterproof after drying and does not stain.
<G-vec00789-002-s205><stain.abfärben><de> Es ist säurefrei, besitzt eine hohe Farbstabilität, färbt nicht ab und ist recyclebar.
<G-vec00789-002-s205><stain.abfärben><en> It is acid-free, has a high color stability, does not stain and is recyclable.
