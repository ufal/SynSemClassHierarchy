<G-vec00386-002-s190><upgrade.aufrüsten><de> Lange Zeit habe ich gezögert, von Windows 7 auf Windows 10 aufzurüsten, weil ich starke Zweifel hatte, dass Microsoft wirklich etwas verbessert hat.
<G-vec00386-002-s190><upgrade.aufrüsten><en> A long time I therefore hesitated, to upgrade from Windows 7 to Windows 10, because I had strong doubts, if Microsoft had really improved.
<G-vec00386-002-s191><upgrade.aufrüsten><de> Da die ACA-1221ec bereits in der Grundversion 9 MB FastMem mitbringt und reine Speichererweiterungen mit 8 MB in der Regel bereits mehr kosten, gibt es eigentlich keinen Grund mehr, Ihren Amiga 1200 nicht sofort aufzurüsten.
<G-vec00386-002-s191><upgrade.aufrüsten><en> Since it offers 9 MB RAM right from the start and mere 8 MB expansion cards are usually more expensive than the ACA-1221, there's hardly any excuse left not to upgrade your Amiga right away.
<G-vec00386-002-s192><upgrade.aufrüsten><de> QNAP bietet verschiedene budgetfreundliche Lösungen, um Ihre Netzwerkumgebung auf 10GbE aufzurüsten.
<G-vec00386-002-s192><upgrade.aufrüsten><en> QNAP provides various budget-friendly solutions to help upgrade your network environment to 10GbE.
<G-vec00386-002-s193><upgrade.aufrüsten><de> Sammelt Ressourcen und erforscht neue Technologien, um eure Kriegsmaschienerie anzufeuern und aufzurüsten.
<G-vec00386-002-s193><upgrade.aufrüsten><en> Harvest resources and research new technologies to fuel and upgrade your machinery of war.
<G-vec00386-002-s194><upgrade.aufrüsten><de> Für jeden toten Feind, wirst Du Goldmünzen erhalten, die Dir helfen werden, Deine bestehenden Türme aufzurüsten oder neue Türme zu bauen.
<G-vec00386-002-s194><upgrade.aufrüsten><en> With each dead enemy, you will receive gold coins which help you upgrade your tower or buy new, more functional one.
<G-vec00386-002-s195><upgrade.aufrüsten><de> Dora Bee noch heute aus und genieße den Spaß, während du dich bemühst, alle Gegenstände im Spiel freizuschalten und aufzurüsten.
<G-vec00386-002-s195><upgrade.aufrüsten><en> Try Dora Bee Sting Doctor today and enjoy the fun as you strive to unlock and upgrade all of the in game items.
<G-vec00386-002-s196><upgrade.aufrüsten><de> Schon früher in diesem Sommer, wurde die Zugangsstrasse auf das Elizabeth Goldvorkommen ausgebaut, um das Explorationslager aufzurüsten.
<G-vec00386-002-s196><upgrade.aufrüsten><en> In July 2010, the access road into the Elizabeth project was improved to allow for the exploration camp upgrade.
<G-vec00386-002-s197><upgrade.aufrüsten><de> Im Großen und Ganzen ist es billiger, gemeinsame Karten aufzurüsten und nur Gold auf die Karten auszugeben, die du oft benutzt hast, denn das sind die, die bei dir bleiben werden.
<G-vec00386-002-s197><upgrade.aufrüsten><en> On the whole, it is cheaper to upgrade common cards and only spend gold on the cards that you use often because these are the ones that will stay with you.
<G-vec00386-002-s198><upgrade.aufrüsten><de> 1Eine Möglichkeit, eine Konsole aufzurüsten, ist die Installation einer SSD, aber bei einigen Geräten erlischt dadurch möglicherweise die Garantie des Geräts.
<G-vec00386-002-s198><upgrade.aufrüsten><en> 1One way to upgrade a console is to install an SSD, but, with some devices, this may void the device’s warranty.
<G-vec00386-002-s199><upgrade.aufrüsten><de> Trotz dieser Zwischenfälle halten die EU und die Nato an ihren Plänen fest, die libysche Küstenwache aufzurüsten und als Söldnertruppe für die Flüchtlingsabwehr zu nutzen.
<G-vec00386-002-s199><upgrade.aufrüsten><en> Nonetheless, the EU and NATO are sticking to their plans to upgrade the Libyan coast guard and use it as a mercenary force against refugees.
<G-vec00386-002-s200><upgrade.aufrüsten><de> Im Gegensatz zu damals verfügen Fahrräder zwar noch heute über die größtenteils gleichen Sicherheitsvorkehrungen, aber während Ende der 1970er ein Trinkflaschenhalter noch als Gadget durchging, haben heutige Radler die Möglichkeit, ihren Drahtesel mit zahlreichen weiteren Gimmicks aufzurüsten.
<G-vec00386-002-s200><upgrade.aufrüsten><en> Unlike back then, present-day bikes may largely have the same safety features, but while a drink bottle holder was considered a gadget at the end of the 1970s, today's cyclists have the opportunity to upgrade their bikes with many other gimmicks.
<G-vec00386-002-s201><upgrade.aufrüsten><de> Ihre Einnahmen nutzen die Seeräuberbanden auch um aufzurüsten; sie kaufen moderne Waffen, bessere Motoren und schnellere Boote.
<G-vec00386-002-s201><upgrade.aufrüsten><en> The pirate gangs also use their income to upgrade; they buy modern weapons, better engines and faster boats.
<G-vec00386-002-s202><upgrade.aufrüsten><de> Diese Website dokumentiert ein Projekt, einen alten Amiga 600 bis zum Maximum aufzurüsten.
<G-vec00386-002-s202><upgrade.aufrüsten><en> This site tells the story of me and a friend of mine trying to upgrade an Amiga 600 to the max.
<G-vec00386-002-s203><upgrade.aufrüsten><de> Im Einklang mit der Eltima Upgrade-Politik steht allen Eltima-Kunden ein Rabatt von 50% zu (des Preises, der auf der Webseite angegeben ist), um auf die neueste Version des gekauften Produktes aufzurüsten.
<G-vec00386-002-s203><upgrade.aufrüsten><en> According to Eltima Upgrade Policy, all Eltima clients are eligible to 50% discount (off the price indicated on our website) to upgrade to the newest release of the purchased product.
<G-vec00386-002-s204><upgrade.aufrüsten><de> Es hat Zugang zur Hauptstraße und die Fähigkeit, neue Fußböden zu entwickeln oder aufzurüsten.
<G-vec00386-002-s204><upgrade.aufrüsten><en> It has access to the main road and the ability to develop or upgrade new floors.
<G-vec00386-002-s205><upgrade.aufrüsten><de> Zwischen Kämpfe, besichtigen Sie den Shop, um Ihre Waffen aufzurüsten, bitten Sie den Skills Master, Ihre Fähigkeiten zu verbessern und wechseln Sie Ihr Outfit, indem Sie mit dem Ninja Master sprechen.
<G-vec00386-002-s205><upgrade.aufrüsten><en> Between fights, visit the shop to upgrade your weapons, ask the Skills Master to upgrade your skills, and change your outfit by talking to the Ninja Master.
<G-vec00386-002-s206><upgrade.aufrüsten><de> OVH Lösungen bieten Villeroy & Boch den nötigen Spielraum, um seine IT-Umgebung effizient und kosteneffektiv aufzurüsten und den Anforderungen aller Kunden gerecht zu werden, egal ob diese per Smartphone, Tablet oder Computer einkaufen.
<G-vec00386-002-s206><upgrade.aufrüsten><en> OVH’s solutions also provide Villeroy & Boch with the freedom to upgrade its digital environment in an efficient, cost-effective way, in order to continue to meet the needs of all customers, whether they are shopping on their mobile phones, tablets, or computers.
<G-vec00386-002-s207><upgrade.aufrüsten><de> Wenn Sie ein Erwachsener sind und weiterhin spielen werden, werden Sie sie über Jahre verwenden bevor die Technologie Sie dazu zwingt aufzurüsten.
<G-vec00386-002-s207><upgrade.aufrüsten><en> If you are an adult and will continue to play, you will use them for years before the technology forces you to upgrade.
<G-vec00386-002-s208><upgrade.aufrüsten><de> In der Rubrik Lines finden Sie spezielle Bänder um Ihr eigenes Slackline-Set zusammen zu stellen oder Ihr bereits vorhandenes Set durch eine neue Line aufzurüsten.
<G-vec00386-002-s208><upgrade.aufrüsten><en> Advanced (4) category Lines you will find special ribbons to create your own slackline set or upgrade your existing set with a new line.
<G-vec00752-002-s005><rearm.aufrüsten><de> Gleichzeitig zögerten sie, Deutschland wieder aufzurüsten.
<G-vec00752-002-s005><rearm.aufrüsten><en> At the same time, the US hesitated to rearm Germany.
