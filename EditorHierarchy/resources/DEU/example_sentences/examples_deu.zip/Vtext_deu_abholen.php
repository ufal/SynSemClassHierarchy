<G-vec00169-001-s019><collect.abholen><de> Ich wollte unsere Karten für die Sylvesterfeier abholen.
<G-vec00169-001-s019><collect.abholen><en> I wanted to collect our tickets for the New Years Eve party.
<G-vec00169-001-s020><collect.abholen><de> Wenn Sie mit Ihrem fahrzeug unzufrieren sind, sprechen Sie mit dem Anbieter vor Ort, wenn sie das Auto abholen.
<G-vec00169-001-s020><collect.abholen><en> If you are unhappy with your vehicle, speak to the local supplier when you collect your car.
<G-vec00169-001-s021><collect.abholen><de> Das Abholen oder Anmelden ist auch durch eine/n Bevollmächtigte/n möglich (Vollmacht, Kopie des Ausweises oder eine Kopie der Blue Card sind notwendig).
<G-vec00169-001-s021><collect.abholen><en> It is also possible to authorize someone to collect the decision letter and to do the exam registration (authorization letter, copy of ID card or copy of Blue Card required).
<G-vec00169-001-s022><collect.abholen><de> Die Tafel unterhält vier Fahrzeuge, mit denen Fahrerteams Lebensmittel an fünf Tagen die Woche bei kooperationsbereiten Firmen abholen.
<G-vec00169-001-s022><collect.abholen><en> The Tafel maintains four vehicles, each with teams of drivers that collect food from cooperating companies five days a week.
<G-vec00169-001-s023><collect.abholen><de> Umgekehrt müssen alle Mitarbeiter, die ein Paket verschicken wollen, den Pförtner anrufen, der das Paket am Arbeitsplatz abholen lässt und am Tor an einen bestellten Kurier übergibt.
<G-vec00169-001-s023><collect.abholen><en> The other way around, all employees, wanting to send a packet, have to inform the porter, which has to collect the packet at the workstation place and which will hand over the packet to the ordered courier at the gate.
<G-vec00169-001-s024><collect.abholen><de> Außerhalb der Öffnungszeiten Da nicht alle Autovermietungen 24 Stunden in St. Maarten geöffnet sind, können Sie Ihr Auto noch vor oder nach der Öffnungszeiten abholen.
<G-vec00169-001-s024><collect.abholen><en> Out of hours As not all car rental companies are open 24 hours at St Maarten, you will still be able to collect your car before or after opening hours.
<G-vec00169-001-s025><collect.abholen><de> Wir suchen die Medien für Sie heraus und Sie können sie in der Regel wenige Stunden danach abholen.
<G-vec00169-001-s025><collect.abholen><en> We find the media for you, and you can usually collect them a few hours later.
<G-vec00169-001-s026><collect.abholen><de> Vermerken Sie beim Beantragen Ihrer Karte klar und deutlich, dass Sie die Karte in Ihrer KBC Bank abholen wollen.
<G-vec00169-001-s026><collect.abholen><en> In that case, clearly indicate when applying for your card that you want to collect it in person from your KBC branch.
<G-vec00169-001-s027><collect.abholen><de> Wenn Sie nach Tschechische Republik reisen, kann Sie unser Fahrer abholen und Sie können Ihren Urlaub in Tschechische Republik sofort beginnen.
<G-vec00169-001-s027><collect.abholen><en> When traveling to Czech Republic you can have one of our drivers collect you and start your holidays in Czech Republic straight away.
<G-vec00169-001-s028><collect.abholen><de> Zur Zeit der Weinlese schickte er seine Boten zu den Pächtern, um den Ertrag abholen zu lassen.
<G-vec00169-001-s028><collect.abholen><en> When the harvest time approached, he sent his servants to the tenants to collect his fruit.
<G-vec00169-001-s029><collect.abholen><de> Die Schlüssel können Sie ab 15:00 Uhr in der Murray Street 34 abholen.
<G-vec00169-001-s029><collect.abholen><en> You can collect your keys from 34 Murray Street, after 15:00.
<G-vec00169-001-s030><collect.abholen><de> Da nicht alle Autovermieter 24 Stunden in Fort Lauderdale geöffnet sind, können Sie Ihr Auto noch vor oder nach der Öffnungszeiten abholen.
<G-vec00169-001-s030><collect.abholen><en> As not all car rental companies are open 24 hours at Fort Lauderdale, you will still be able to collect your car before or after opening hours.
<G-vec00169-001-s031><collect.abholen><de> Wenn Sie gebeten haben, die Produkte aus unseren Geschäften abzuholen, dürfen Sie sie jederzeit bei uns abholen, während der Öffnungszeiten der jeweiligen Shops.
<G-vec00169-001-s031><collect.abholen><en> If you have asked to collect the products from our stores, you can collect them from us at any time during the opening hours of the particular store.
<G-vec00169-001-s032><collect.abholen><de> Die bestellte Ware können Sie persönlich in unserem Werk abholen oder wir senden Ihnen diese bis ins Haus.
<G-vec00169-001-s032><collect.abholen><en> You may collect the ordered goods either in person in our plant or we will deliver them directly to the house.
<G-vec00169-001-s033><collect.abholen><de> "Wenn du aus Dänemark, Schweden oder Norwegen bestellst, kannst du „Im Store abholen"" als Versandmethode wählen."
<G-vec00169-001-s033><collect.abholen><en> When purchasing from Denmark or Sweden, you’re able to choose “Collect in Store” as a shipping method.
<G-vec00169-001-s034><collect.abholen><de> Bei der Ankunft können Kunden ihre Schusswaffen am Schusswaffenschalter abholen.
<G-vec00169-001-s034><collect.abholen><en> Upon arrival customers can proceed to the Firearm Desk to collect firearms.
<G-vec00169-001-s035><collect.abholen><de> Sie können Ihren Pass mit dem Visum per Kurierdienst an Ihre Privat- oder Geschäftsadresse in Österreich zustellen lassen (Premium Hauslieferung) oder sie bei DPD Wien City Hub (Selbst-Abholung) abholen.
<G-vec00169-001-s035><collect.abholen><en> You may choose to have your passport and visa returned to your home/business address in Austria via courier service (Premium Home Delivery) or collect them from the DPD City Hub (Pickup).
<G-vec00169-001-s036><collect.abholen><de> Bei internationalen Flügen müssen die Gäste ihr Gepäck abholen und am ersten Einreiseort den Zoll passieren.
<G-vec00169-001-s036><collect.abholen><en> For international flights, guests will have to collect their baggage and clear Customs at the first port of entry.
<G-vec00169-001-s037><collect.abholen><de> Selbstverständlich ist es ebenfalls möglich, die Waren direkt bei uns abholen.
<G-vec00169-001-s037><collect.abholen><en> Off course, it is possible to collect your order from our warehouse.
<G-vec00169-001-s019><fetch.abholen><de> Nun wollte ich Victor unbedingt mitteilen, dass er den Ring abholen sollte.
<G-vec00169-001-s019><fetch.abholen><en> Now I urgently wanted to tell Victor that he should fetch the ring.
<G-vec00169-001-s020><fetch.abholen><de> Selbst wenn wir am Wochenenden Teile benötigen, können wir sie aus Petershagen abholen.
<G-vec00169-001-s020><fetch.abholen><en> Even if we need parts at the weekend we can go and fetch them from Petershagen.
<G-vec00169-001-s021><fetch.abholen><de> Wir können Sie mit dem Auto vom Bahnhof oder Busbahnhof abholen.
<G-vec00169-001-s021><fetch.abholen><en> We can fetch you by car from the train station or bus station.
<G-vec00169-001-s022><fetch.abholen><de> Der Teufel sagte: “Setz dich, ich will dich waschen, kämmen, schnippen, die Haare und Nägel schneiden und die Augen auswischen,” und als er mit ihm fertig war, gab er ihm den Ranzen wieder voll Kehrdreck und sprach: “Geh hin und sage dem Wirt, er sollte dir dein Gold wieder herausgeben, sonst wollt ich kommen und ihn abholen, und er sollte an deinem Platz das Feuer schüren.” Hans ging hinauf und sprach zum Wirt: “Du hast mein Gold gestohlen, gibst du’s nicht wieder, so kommst du in die Hölle an meinen Platz und sollst aussehen so greulich wie ich.” Da gab ihm der Wirt das Gold und noch mehr dazu und bat ihn, nur still davon zu sein; und Hans war nun ein reicher Mann.
<G-vec00169-001-s022><fetch.abholen><en> The Devil said, “Seat yourself, I will wash, comb, and trim you, cut your hair and nails, and wash your eyes for you,” and when he had done with him, he gave him the knapsack back again full of sweepings, and said, “Go and tell the landlord that he must return you your money, or else I will come and fetch him, and he shall poke the fire in your place.” Hans went up and said to the landlord, “Thou hast stolen my money; if thou dost not return it, thou shalt go down to hell in my place, and wilt look as horrible as I.” Then the landlord gave him the money, and more besides, only begging him to keep it secret, and Hans was now a rich man.
<G-vec00169-001-s023><fetch.abholen><de> Ich kann die Visa von Steve und mir erst einen Tag vor Abflug vom Japanischen Konsulat in Düsseldorf abholen.
<G-vec00169-001-s023><fetch.abholen><en> I can fetch the visas for Steve and myself from the Japanese consulate in Dusseldorf just one day before take-off.
<G-vec00169-001-s024><fetch.abholen><de> Auf dem Luftweg muss der Kunde die Waren vom Flughafen abholen.
<G-vec00169-001-s024><fetch.abholen><en> By air, customer needs to fetch the goods from airport.
<G-vec00169-001-s025><fetch.abholen><de> Ich soll dich abholen“, sagte Günter leicht säuerlich.
<G-vec00169-001-s025><fetch.abholen><en> “Mother sent me to fetch you,” Günther said in a slightly acerbic tone.
<G-vec00169-001-s026><fetch.abholen><de> 2 Klicken Sie auf Log-Dateien abholen .
<G-vec00169-001-s026><fetch.abholen><en> 2 Click Fetch the log files .
<G-vec00169-001-s027><fetch.abholen><de> Die nächste, angrenzende Komponente kann von dort den Bus abholen.
<G-vec00169-001-s027><fetch.abholen><en> The next adjacent component may fetch the bus from this point.
<G-vec00169-001-s028><fetch.abholen><de> Der Beamte ist argwöhnisch geworden und hat die Polizei angerufen, und später musste ich die drei mit meinem Auto von der Wache abholen.
<G-vec00169-001-s028><fetch.abholen><en> The clerk became suspicious and called the police, and later I had to fetch the three girls from the police station in my car.
<G-vec00169-001-s029><fetch.abholen><de> Besonders bequem: Die Halter können ihr Fahrzeug nach der Nachrüstung inklusive der grünen Plakette abholen, so dass die Eintragung direkt mit übernommen wird.
<G-vec00169-001-s029><fetch.abholen><en> Especially comfortable: The holder can fetch their vehicle after the retrofit, including the green plaque, so that the registration is taken over directly.
<G-vec00169-001-s030><fetch.abholen><de> IMAP kann sowohl Nachrichten auf einem entfernten Server speichern als auch von dort abholen.
<G-vec00169-001-s030><fetch.abholen><en> IMAP can store messages on a remote server as well as fetch them.
<G-vec00169-001-s031><fetch.abholen><de> Dort wo sie gerade sind, werden sie die Engel des Herrn abholen, sie verwandeln, also „überkleiden”, wie es Paulus auch in 2Kor 5,4 formuliert, und mit sich fortnehmen, dem Herrn in den Wolken entgegen.
<G-vec00169-001-s031><fetch.abholen><en> Right where they are, the angels will fetch them and transform them, or “clothe” them, as Paul also puts it in 2Cor 5,4, and take them to meet the Lord in the clouds.
<G-vec00169-001-s024><reclaim.abholen><de> Die Taxis befinden sich an den Terminals 1, 2A, 2C, 2D, 2E, 2F, 3 und 2G bei den Ausgängen, wo Sie Ihr Gepäck abholen.
<G-vec00169-001-s024><reclaim.abholen><en> The taxi services are located at terminals 1, 2A, 2C, 2D, 2E, 2F, 3 and 2G at the exits of the baggage reclaim areas.
<G-vec00169-001-s025><reclaim.abholen><de> Man kann diese Gegenstände abholen, indem man mit dem NPC spricht.
<G-vec00169-001-s025><reclaim.abholen><en> Players will be able to reclaim these items by speaking to the NPC.
<G-vec00169-001-s057><collect.abholen><de> Sie haben zwei britische Depots, und Sie können entscheiden, Ihre Bestellung von ihnen abzuholen, wenn Sie lokal sind, sie sind in Bolton und Aylesbury.
<G-vec00169-001-s057><collect.abholen><en> They have two UK depots, and you can opt to collect your order from them if you are local, they are in Bolton and Aylesbury.
<G-vec00169-001-s059><collect.abholen><de> Es ist höchste Zeit, dass sie kommen kann, um ihn abzuholen.
<G-vec00169-001-s059><collect.abholen><en> It is high time that she was able to come and collect it.
<G-vec00169-001-s060><collect.abholen><de> Der Kunde verfügt über eine Frist von 15 Tagen ab dem Datum der Lieferung in der Boutique, um seine Bestellung abzuholen.
<G-vec00169-001-s060><collect.abholen><en> The Customer has 15 days from the in-store delivery date to collect their parcel.
<G-vec00169-001-s061><collect.abholen><de> Da er seine Eltern über seine finanzielle Situation und ihre Folgen anscheinend im Unklaren gelassen hatte, waren Theodor und Else Daltrop umso bestürzter, als sie eines Tages erfuhren, dass ihr Sohn völlig orientierungslos beim Betteln auf der Straße aufgegriffen worden war, und sie aufgefordert wurden, ihn umgehend abzuholen.
<G-vec00169-001-s061><collect.abholen><en> Since apparently he had left his parents in the dark about his financial situation and its effects, Theodor and Else Daltrop were all the more dismayed to find out one day that their son had been picked up, completely disoriented while begging on the street, and to find themselves requested to collect him immediately.
<G-vec00169-001-s062><collect.abholen><de> Die Praktizierenden dürfen ihre Zelle nicht verlassen, um sich notwendige Dinge zu holen, ihre Wäsche abzuholen oder in den Lagerraum zu gehen, um Kleidung zu bekommen.
<G-vec00169-001-s062><collect.abholen><en> Practitioners are not allowed to leave the cell to fetch any necessities, collect their laundry, nor are they allowed to go to the store room to get their clothing.
<G-vec00169-001-s063><collect.abholen><de> Unser Chauffeur wird den Flug verfolgen um euch rechtzeitig abzuholen.
<G-vec00169-001-s063><collect.abholen><en> Our chauffeur will collect you with a personalised sign.
<G-vec00169-001-s064><collect.abholen><de> Sie haben auf all unseren Campingplätzen die Möglichkeit jeden Morgen gegen Vorbestellung frisches Brot und Croissants an der Rezeption abzuholen.
<G-vec00169-001-s064><collect.abholen><en> Every morning, you can also collect your bread and croissants at reception (upon order) on all our sites.
<G-vec00169-001-s065><collect.abholen><de> In Berlin gehst du zur Gepäckausgabe, um dein Gepäck wie gewohnt abzuholen.
<G-vec00169-001-s065><collect.abholen><en> At Berlin, proceed to baggage reclaim to collect your bags as normal.
<G-vec00169-001-s066><collect.abholen><de> (5) Bei ungewöhnlichem Wetter wie Hagel und starkem Wind sollten sofort Schutzmaßnahmen ergriffen werden, um die Geräte im Lager abzuholen.
<G-vec00169-001-s066><collect.abholen><en> (5) In case of abnormal weather such as hail and squally winds, protective measures should be taken immediately to collect the equipment into the warehouse.
<G-vec00169-001-s067><collect.abholen><de> Avis/Budget bietet auch die Möglichkeit für Kunden an, die Mietwagen von Terminal 2 abzuholen.
<G-vec00169-001-s067><collect.abholen><en> Avis/Budget also offer a facility for customers to collect their rental cars from Terminal 2.
<G-vec00169-001-s068><collect.abholen><de> Sie haben 7 Tage Zeit, sie dort abzuholen.
<G-vec00169-001-s068><collect.abholen><en> Please collect it within 7 days.
<G-vec00169-001-s069><collect.abholen><de> In diesem Fall verfügen Sie über 10 Werktage ab Eingang Ihres Pakets im Postamt, um es abzuholen.
<G-vec00169-001-s069><collect.abholen><en> You will then have 10 working days, from when your order arrives at the post office, to collect it.
<G-vec00169-001-s070><collect.abholen><de> Dieses Zurückbehaltungsrecht besteht selbstverständlich dann nicht, wenn er selbst angeboten hat, die Ware beim Verbraucher abzuholen.
<G-vec00169-001-s070><collect.abholen><en> Of course, this right of retention does not apply if he himself has offered to collect the goods from the consumer.
<G-vec00169-001-s071><collect.abholen><de> Soweit der Lieferant nach den Bestimmungen der Verpackungsordnung verpflichtet ist, Verpackungen zurückzunehmen, hat er sie auf seine Kosten bei dem Besteller abzuholen.
<G-vec00169-001-s071><collect.abholen><en> Where, according to the provisions of the packaging legislation, the supplier is required to take back the packaging, it must collect this from the customer at its own cost.
<G-vec00169-001-s072><collect.abholen><de> Um das Gepäck abzuholen, muss der Fluggast den entsprechenden Gepäckschein, den er beim Check-in erhalten hat, vorweisen.
<G-vec00169-001-s072><collect.abholen><en> To collect his baggage, the Passenger should show the corresponding Baggage Check delivered to him at check-in.
<G-vec00169-001-s073><collect.abholen><de> Wir möchten Sie außerdem daran erinnern, dass Sie ab der Landung eine Stunde Zeit haben, um Ihr Gepäcke abzuholen und den Schalter zu erreichen, der auf dem Terravision-Gutschein angegeben ist.
<G-vec00169-001-s073><collect.abholen><en> We also remind you that, from the landing time, you will have an hour to collect your luggage and reach the desk mentioned on the Terravision Voucher.
<G-vec00169-001-s074><collect.abholen><de> Der Kunde ist verpflichtet, die Lieferung innerhalb 30 Tagen nach Erhalt der Mitteilung über die Verfügbarkeit am Lager der Produkte zu genehmigen oder abzuholen.
<G-vec00169-001-s074><collect.abholen><en> Customers are asked to authorize shipment or to collect the supply directly at our warehouse within 30 days from the communication of availability.
<G-vec00169-001-s075><collect.abholen><de> Ein INWB-Connector für die Compliance-Adressprüfung kann dieses Attribut auswerten, um Nachrichten in diesem Verzeichnis abzuholen oder abzulegen.
<G-vec00169-001-s075><collect.abholen><en> An INWB connector for the compliance address verification can analyze this attribute in order to collect messages from or store messages in this directory.
<G-vec00169-001-s052><fetch.abholen><de> -Luft, Dauert es ungefähr 4-5 Tage, um den Zielflughafen erhalten, müssen Sie die Waren selbst abzuholen.
<G-vec00169-001-s052><fetch.abholen><en> -Air, it will take about 4-5 days to get to destination airport, you need to fetch goods by yourself.
<G-vec00169-001-s053><fetch.abholen><de> Jedes der 5 Zentren ist in einer großen Stadt gelegen, so dass die Einzelhändler nicht allzu weit fahren müssen, um die Ware abzuholen.
<G-vec00169-001-s053><fetch.abholen><en> Each of the 5 centers is located in a big city, so that the retailers do not need to drive too far to fetch the goods.
<G-vec00169-001-s054><fetch.abholen><de> Das Mädchen aber sitzt im Dorf und lauert und lauert und meint, er komme, sie abzuholen, es kommt aber keiner.
<G-vec00169-001-s054><fetch.abholen><en> But the maiden sat in the village and watched and watched, and thought he would come and fetch her, but no one came.
<G-vec00169-001-s055><fetch.abholen><de> Dieser Häftling berichtet, wie Boger in Krankenhausblock des Stammlagers Auschwitz erschien, um einen Häftling abzuholen, der gerade eine Operation an der Blase hinter sich hatte und eine weitere Operation an der Prostata vor sich hatte.
<G-vec00169-001-s055><fetch.abholen><en> This prisoner reported how Boger came into the infirmary quarters of the main camp of Auschwitz to fetch a prisoner who had just undergone bladder surgery and was scheduled to have prostate surgery.
<G-vec00169-001-s056><fetch.abholen><de> Er bekommt den Job und reist mit Tick, Trick und Track nach Grönland, um eine Kiste Eis abzuholen.
<G-vec00169-001-s056><fetch.abholen><en> He gets the job and travels to the Arctic with Huey, Dewey and Louie to fetch a box of ice.
<G-vec00169-001-s119><reclaim.abholen><de> "Sollten allerdings die Kürzel 'JFK' darauf geschrieben stehen, folgen Sie bitte den gelben Schildern ""Arrivals/Baggage reclaim"" (Ankunft/Gepäckausgabe), um Ihr Gepäck abzuholen und es wie gewöhnlich für Ihren Anschlussflug einzuchecken."
<G-vec00169-001-s119><reclaim.abholen><en> If your baggage tag shows 'JFK', please follow the signs for 'Arrivals/Baggage reclaim' to collect your bags and check it in again as normal for your connecting flight.
<G-vec00169-001-s188><reclaim.abholen><de> Der Gast wird nicht verpflichtet sein, die Einwanderung nach Hongkong zu passieren oder sein Gepäck wieder abzuholen.
<G-vec00169-001-s188><reclaim.abholen><en> Guest will not be required to clear Hong Kong immigration or reclaim their bags.
<G-vec00298-002-s118><augment.abholen><de> Steigern Sie mit KI die menschliche Kreativität und kognitive Fähigkeiten, um Kunden dort abzuholen, wo sie sich befinden.
<G-vec00298-002-s118><augment.abholen><en> Augment human ingenuity with AI and cognitive capabilities to meet customers where they are.
<G-vec00355-002-s028><fetch.abholen><de> Als sie den Springer nach zwei Stunden abholten und auf eine Bahre legten, sah ich, wie Springer den Kopf noch ein klein wenig hob.
<G-vec00355-002-s028><fetch.abholen><en> When they came to fetch Springer two hours later, and put him on a stretcher, I saw him trying to raise his head slightly.
<G-vec00380-002-s020><unload.abholen><de> Nachfolgend bezahlen Sie an den Schaffner eine einmalige Aufbewahrungsgebühr für die Verwahrung während der Beförderung im Gepäckwagen und Sie erhalten einen Beleg über die Bezahlung (im Fall eines Kinderwagens erhalten Sie einen Beleg über eine unentgeltliche Verwahrung) mit einem Aufkleber mit dem Namen des Bahnhofes der Ausgabe (in dem Sie den hinterlegten Gegenstand im Zug abholen werden).
<G-vec00380-002-s020><unload.abholen><en> Next, you will pay the conductor the one-off storage fee for the luggage storage during transport service, and you will receive a payment receipt (in the case of a children’s pram, you will receive a receipt for free storage) marked with a sticker bearing the name of the station of release (where you will come to the train to unload the stored item).
<G-vec00536-002-s012><quell.abholen><de> Die verfahrene, chaotische und frustrierende Lage heute ist insofern der Erfolg der Angriffe rechtspopulistischer Hasardeure und zugleich das Versagen demokratischer Kräfte, die in mehr oder weniger großen Schritten auf diese Kräfte zugingen, um die populistische Revolte zu dämpfen und „abzuholen“, statt ihr entgegenzutreten.
<G-vec00536-002-s012><quell.abholen><en> The muddled, chaotic and frustrating situation in which the UK finds itself today is the result of onslaughts by right-wing populist opportunists and the failure of democratic forces, which to various extents moved in the direction of the populists in an attempt to quell and 'appropriate' the populist revolt, rather than countering it.
<G-vec00708-002-s038><pick_up.abholen><de> Anderenfalls ist die Rücksendung für Sie kostenfrei.Nicht paketversandfähige Waren werden bei Ihnen abgeholt.
<G-vec00708-002-s038><pick_up.abholen><en> Otherwise, the return is free for you. Not parcel things do you pick.
<G-vec00708-002-s039><pick_up.abholen><de> Ich habe beauftragt, dass meine Rücksendung abgeholt wird, wurde aber von keinem Mitarbeiter kontaktiert.
<G-vec00708-002-s039><pick_up.abholen><en> I have requested to arrange a pick up for my returns, but no one contacted me.
<G-vec00708-002-s040><pick_up.abholen><de> Morgens werden Sie an der Rezeption Ihres Hotels in Dahab abgeholt und .anschließend fahren wir zu einem Beduinendorf.
<G-vec00708-002-s040><pick_up.abholen><en> In the morning we will pick you up at the reception of your hotel in Dahab and you will travel to a Bedouin village.
<G-vec00708-002-s041><pick_up.abholen><de> Den fertigen Stoff habe ich wieder mit dem Auto abgeholt (80 km weit) und die Arbeit der Blaudruckerin bezahlt.
<G-vec00708-002-s041><pick_up.abholen><en> I again pick up the finished cloth by car (80 km away), and pay for her work.
<G-vec00708-002-s042><pick_up.abholen><de> Bald findet sie den Eigentümer des Autos, mit dem der Käufer die Waffen abgeholt hat.
<G-vec00708-002-s042><pick_up.abholen><en> Before too long, she finds the owner of the car that was used by the buyer to pick up the weapons.
<G-vec00708-002-s043><pick_up.abholen><de> In Ausnahmefällen können anhand einer Vollmacht die Schlüssel auch von einem Dritten abgeholt werden.
<G-vec00708-002-s043><pick_up.abholen><en> In exceptional cases, a third party may pick up the keys if they have a power of attorney.
<G-vec00708-002-s044><pick_up.abholen><de> Sobald Sie bereit sind um abgeholt zu werden gehen Sie einfach zum Meeting Meeting Point in der Ankunftsebene im Terminal.
<G-vec00708-002-s044><pick_up.abholen><en> To be Once you’re ready to pick, you simply go to the meeting Meeting Point in the Arrivals level in the terminal.
<G-vec00708-002-s045><pick_up.abholen><de> Abgeholt werdet Ihr morgens mit unserem Bus direkt vom Hotel.
<G-vec00708-002-s045><pick_up.abholen><en> We will pick you up in the morning in our eye-catching customised bus.
<G-vec00708-002-s046><pick_up.abholen><de> Wenn ich fertig bin werde ich abgeholt und nach Kastrup in Dänemark gefahren.
<G-vec00708-002-s046><pick_up.abholen><en> A car will pick me up when I’m done and drive me to Kastrup in Denmark.
<G-vec00708-002-s047><pick_up.abholen><de> Da die Banken in den besetzten Gebieten seit Mitte 2014 nicht mehr arbeiteten, wurde das Gehalt monatlich vom Schulleiter im Bildungsministerium der „Republik“ abgeholt und anschließend in bar an alle Lehrer der Schule verteilt.
<G-vec00708-002-s047><pick_up.abholen><en> Since the banks were no longer operating from summer 2014, the school director had to pick up the salaries each month at the “Republic’s” Ministry of Education and then hand them out to the schools’ teachers in cash.
<G-vec00708-002-s048><pick_up.abholen><de> Sie werden von Ihrem Hotel in Windhoek abgeholt und zurück gebracht.
<G-vec00708-002-s048><pick_up.abholen><en> HORSEBACK RIDING Including pick up and drop off at your hotel in Windhoek.
<G-vec00708-002-s049><pick_up.abholen><de> Nachdem wir Sie vom Hotel abgeholt haben, fahren wir zum Ägyptischen Museum der Antiquitäten, das weltweit die größte, kostbarste und seltenste Sammlung echter Artefakte beheimatet, über 250.000 Stücke sind ausgestellt, die teilweise bis 5000 Jahre zurückdatieren; eine Ausstellung der Schatzsammlung des Königs Tutankhamun ist inbegriffen.
<G-vec00708-002-s049><pick_up.abholen><en> We will pick you up from your hotel for visiting the Egyptian museum of Antiquities, which houses the world’s largest, most precious, and rare collection of genuine artifacts, over 250,000 pieces are displayed, dating back to 5000 years including an exhibit of the treasure collection of king Tutankhamen.
<G-vec00708-002-s050><pick_up.abholen><de> Reisegruppen können auch in Rauris wieder abgeholt werden.
<G-vec00708-002-s050><pick_up.abholen><en> It is also possible to pick up tour groups in Rauris itself.
<G-vec00708-002-s051><pick_up.abholen><de> Der Tag ist endlich gekommen, als sie abgeholt werden konnte.
<G-vec00708-002-s051><pick_up.abholen><en> The day has finally arrived and we could go pick her up.
<G-vec00708-002-s052><pick_up.abholen><de> Wenn Sie uns mitteilen, woher Sie kommen, können wir auch die Ortsbehörde anrufen, damit Sie abgeholt werden“, behaupteten sie.
<G-vec00708-002-s052><pick_up.abholen><en> If you tell us where you are from, we can also call the local authorities to pick you up,” they claimed.
<G-vec00708-002-s053><pick_up.abholen><de> Die meisten Bilder stammen vom vierten Tag, denn den fünften Tag haben wir zum shoppen genutzt und am sechsten Tag haben wir unseren Mietwagen abgeholt um nach Virginia Beach zu fahren.
<G-vec00708-002-s053><pick_up.abholen><en> The most pictures show day 4 because we used day 5 to do some shopping and day 6 to pick up our rental car to drive to Virginia Beach.
<G-vec00708-002-s054><pick_up.abholen><de> Berüchtigt ist letzterer allerdings auch für Abfallberge, die Anwohner hier lagern, bis sie von Müllkarren abgeholt werden.
<G-vec00708-002-s054><pick_up.abholen><en> This market, however, is also notorious for piles of rubbish deposited by the residents for garbage carts to pick up.
<G-vec00708-002-s055><pick_up.abholen><de> Fundsachen können die ganze nächste Woche im Fundbüro abgeholt werden.
<G-vec00708-002-s055><pick_up.abholen><en> All next week it will be possible to pick up anything lost at the hill.
<G-vec00708-002-s056><pick_up.abholen><de> Sie werden vom Flughafen/Bahnhof von Ihrem Betreuungsstudenten abgeholt, der Sie nach Brandenburg begleiten wird.
<G-vec00708-002-s056><pick_up.abholen><en> Please assist us by providing your arrival details so that our student mentors can pick you up from the airport or train station and accompany you to Brandenburg.
<G-vec00708-002-s057><pick_up.abholen><de> Erkunden Sie die Hauptstadt der Algarve, wenn Sie ein Auto bei Europcar, Ihrer Autovermietung in Faro, abholen.
<G-vec00708-002-s057><pick_up.abholen><en> Explore the capital of the Algarve when you pick up a car hire in Faro from Europcar.
<G-vec00708-002-s058><pick_up.abholen><de> Das gilt auch für die Gäste, die wir von anderen Hotels zum Tauchen abholen.
<G-vec00708-002-s058><pick_up.abholen><en> This also applies to the guests we pick up from other hotels for diving.
<G-vec00708-002-s059><pick_up.abholen><de> Während dieser Zeit können die Studierenden die für ihr Projekt notwendige Ausrüstung abholen und zurückbringen.
<G-vec00708-002-s059><pick_up.abholen><en> During this time the students can pick up the equipment they need for their projects and also bring back the tools they no longer need.
<G-vec00708-002-s060><pick_up.abholen><de> Auf jeden Fall abholen etwas Neues - eine schwierige Aufgabe.
<G-vec00708-002-s060><pick_up.abholen><en> In any case, pick up something new - a difficult task.
<G-vec00708-002-s061><pick_up.abholen><de> Diese App, mit dem Unternehmen verbunden, welches diese abholen wird, macht es leicht, Materialabfälle direkt über den Bildschirm des Xerox-MFP zu entsorgen.
<G-vec00708-002-s061><pick_up.abholen><en> This app, connected to the company which will pick them up, makes it easy to get rid of waste consumables right at the screen of the Xerox MFP.
<G-vec00708-002-s062><pick_up.abholen><de> Durch die Nutzung kleiner und großer Flughäfen in Europa können Sie so nah wie möglich an Ihrem Endziel landen und Ihr Luxusauto abholen.
<G-vec00708-002-s062><pick_up.abholen><en> By using small and large airports in Europe, you will be able to land as close as possible to your final destination and pick up your luxury car.
<G-vec00708-002-s063><pick_up.abholen><de> Bitte lassen Sie es uns wissen, von wo Sie anreisen, damit wir Ihnen bei Bedarf mit der Reiseplanung behilflich sein können und wissen, wo wir Sie für den Transfer an den Flughafen abholen können.
<G-vec00708-002-s063><pick_up.abholen><en> Please let us know where you will be traveling from so we can help you make arrangements if you like and know where to pick you up for the transfer to the airport.
<G-vec00708-002-s064><pick_up.abholen><de> Kleine Gebühr für Flughafen abholen.
<G-vec00708-002-s064><pick_up.abholen><en> Small charge for airport pick up.
<G-vec00708-002-s065><pick_up.abholen><de> In manchen Fällen werden wir Sie, nach Vorankündigung, bitten, beim Abholen der Schläger Ihre Kreditkarte vorzuzeigen.
<G-vec00708-002-s065><pick_up.abholen><en> We may, with advance notice, require you to produce your credit card on pick up of clubs if necessary.
<G-vec00708-002-s066><pick_up.abholen><de> Sie können ihre Reservierung im Januar vornehmen und das Auto im Juli abholen, ganz ohne Extrakosten.
<G-vec00708-002-s066><pick_up.abholen><en> You can make your booking in January and pick the car up in July, with no extra charges involved.
<G-vec00708-002-s067><pick_up.abholen><de> Flughafen abholen oder absetzen (mit dem Auto) auf Anfrage erhältlich.
<G-vec00708-002-s067><pick_up.abholen><en> Airport pick up or drop off (by car) available on request.
<G-vec00708-002-s068><pick_up.abholen><de> So können Sie leicht Namen für Schildkröten für Jungen und Namen für die Schildkröten Ihrer Mädchen abholen.
<G-vec00708-002-s068><pick_up.abholen><en> Thus, you can easily pick up names for turtles for boys, and names for your girls' turtles.
<G-vec00708-002-s069><pick_up.abholen><de> Autovermietungen, die alle Kosten auflisten, keine versteckten Gebühren und kostenlose Änderungen/ Vertragsbeendigungen bis zu 24 Stunden bevor Sie Ihr Auto eigentlich abholen sollten.
<G-vec00708-002-s069><pick_up.abholen><en> We can offer car hire where every cost is included, no hidden fees and free cancellations/amendments up to 24 hours before you are supposed to pick up the car.
<G-vec00708-002-s070><pick_up.abholen><de> Die ich in Frankreich abholen wollte, die aber dann größer war als ausgeschrieben und leider doch nicht in unseren VW Bus passte.
<G-vec00708-002-s070><pick_up.abholen><en> Which I wanted to pick up in France, but it didn’t fit into our VW Bus because it was bigger than specified.
<G-vec00708-002-s071><pick_up.abholen><de> Egal, wo in der Schweiz Sie Ihr Fahrzeug abholen, mit der Buchung eines günstigen Mietwagens können Sie sicher sein, dass Sie alle Schätze dieses atemberaubenden Ortes nach Herzenslust erkunden können.
<G-vec00708-002-s071><pick_up.abholen><en> No matter which one of the nation’s major centres pick up your vehicle from, booking a cheap car rental in Switzerland will ensure that you can explore all the gems of this breathtaking place to your heart’s content.
<G-vec00708-002-s072><pick_up.abholen><de> Liebe Unterstützende, Nachdem ich Anfangs Woche ein Telefonat von der Imkerei Soland bekommen habe, konnte ich gestern die 100kg Blütenhonig für den Hung abholen.
<G-vec00708-002-s072><pick_up.abholen><en> After I got a phone call from the Apiary Soland at the beginning of the week, I was able to pick up the 100kg multiflower honey for the Hung yesterday.
<G-vec00708-002-s073><pick_up.abholen><de> Positiver Effekt für den Autofahrer: Er kann nach kurzer Wartezeit mit dem eigenen Auto weiterfahren, statt es in den Folgetagen abholen und in der Zwischenzeit auf eine kostspielige Alternative ausweichen zu müssen.
<G-vec00708-002-s073><pick_up.abholen><en> The benefit for drivers is that they can get back in their car and drive off after just a brief wait, with no need to come back to pick it up the next day and no need for a costly alternative in the meantime.
<G-vec00708-002-s074><pick_up.abholen><de> Wir können Ihnen ein Taxi oder ein 4 WD oder ein Minibus reservieren, der Sie wo Sie wollen abholen wird, in Marrakech oder Ouarzazate.
<G-vec00708-002-s074><pick_up.abholen><en> We can also reserve a taxi for you, a 4X4 or a minibus, that will pick you up anywhere in Marrakech or Ouarzazate.
<G-vec00708-002-s075><pick_up.abholen><de> Mit 17 muss man Angela von der Schule abholen.
<G-vec00708-002-s075><pick_up.abholen><en> At 17 you have to pick up Angela from school.
<G-vec00708-002-s095><pick_up.abholen><de> Umso wichtiger ist eine Kommunikationsstrategie, die Ihre Kunden genau da abholt, wo sie sich durchschnittlich 2-3 Stunden täglich aufhalten: auf Facebook, Instagram, Twitter und Co.
<G-vec00708-002-s095><pick_up.abholen><en> Therefor it is essential for your communication strategy in order to pick your customers up, where they spend 2-3 hours a day: on Facebook, Instagram, Twitter and Co.
<G-vec00708-002-s096><pick_up.abholen><de> Als der Taxifahrer meinte, er hätte schon jemanden im Riad angerufen, der uns abholt, dachte ich zuerst, dass der Flug wohl doch einige Spuren hinterlassen haben muss.
<G-vec00708-002-s096><pick_up.abholen><en> When our cab driver told us, that he already called somebody from the Riad to pick us up, my first thought was, that maybe the flight must have left some traces on our faces.
<G-vec00708-002-s097><pick_up.abholen><de> Du kannst Deinen Hund auf dem Weg zur Arbeit beim Sitter zu Hause absetzen oder mit Deinem örtlichen Sitter in Esch an der Alzette absprechen, dass er Deinen Hund abholt und nach Hause bringt.
<G-vec00708-002-s097><pick_up.abholen><en> You can drop your dog off at the sitter’s home on the way to work or organise with your local Dudley Pawshake sitter to pick up and drop off your dog each time.
<G-vec00708-002-s098><pick_up.abholen><de> Sie können auch bestimmen, dass der Empfänger die Sendung am Flughafen abholt.
<G-vec00708-002-s098><pick_up.abholen><en> You can also choose to have the recipient pick up the shipment from the airport.
<G-vec00708-002-s099><pick_up.abholen><de> Es ist für unser Team und unsere Arbeit wichtig, dass Ihr die Kinder pünktlich bringt und abholt.
<G-vec00708-002-s099><pick_up.abholen><en> It is important for our team and our work that you drop and pick up your children on time.
<G-vec00708-002-s100><pick_up.abholen><de> Die Startnummer nennt Ihr uns bitte wenn Ihr vor Ort Eure Startunterlagen abholt.
<G-vec00708-002-s100><pick_up.abholen><en> The start number you call us please when you pick up your starting documents locally.
<G-vec00708-002-s101><pick_up.abholen><de> Fangen Sie Ihre Reise mit einem komfortvollen Auto, das Sie gerade vom Flughafen abholt.
<G-vec00708-002-s101><pick_up.abholen><en> Start your journey in a comfortable car that will pick you up right at the airport.
<G-vec00708-002-s102><pick_up.abholen><de> Wenn du möchtest, dass der Babysitter dein Kind von der Schule abholt, solltest du den Babysitter zuerst den Lehrern und anderen Eltern an der Schule vorstellen.
<G-vec00708-002-s102><pick_up.abholen><en> If you want your babysitter to pick your child up from school, you'll need to introduce the babysitter to your child's teachers, and the other parents at school first.
<G-vec00708-002-s103><pick_up.abholen><de> Dein Abenteuer startet entweder am Flughafen Keflavík oder in Reykjavík, wo dich dein Guide abholt.
<G-vec00708-002-s103><pick_up.abholen><en> Your adventure starts at either Keflavík Airport or Reykjavík city, where your guide will pick you up.
<G-vec00708-002-s104><pick_up.abholen><de> Es müssen Vereinbarungen darüber getroffen werden, welches Elternteil das Kind jeden Tag abholt und in die Tagesstätte bringt.
<G-vec00708-002-s104><pick_up.abholen><en> Arrangements need to be made regarding which parent will drop off and pick up the child each day.
<G-vec00708-002-s105><pick_up.abholen><de> Stellen Sie sicher, dass die Spedition diese Dokumente und einen CMR-Frachtbrief dabei hat, wenn sie das Fahrzeug abholt.
<G-vec00708-002-s105><pick_up.abholen><en> Make sure the transport company has these documents and a CMR with them when they pick up the vehicle.
<G-vec00708-002-s106><pick_up.abholen><de> Falls du möchtest das der Babysitter dein Kind von der Schule abholt solltest du den Babysitter zuerst den Eltern und Lehrern von der Schule vorstellen.
<G-vec00708-002-s106><pick_up.abholen><en> If you want your babysitter to pick your child up from school, you'll need to introduce the babysitter to your child's teachers and the other parents at school first.
<G-vec00708-002-s107><pick_up.abholen><de> Unser Tipp: Minimieren Sie die Rampenkontakte im eigenen Unternehmen, indem Sie Ihre Sendungen für den Paketdienst einfach unserem Fahrzeug mitgeben, welches Ihre Stückgutsendungen abholt.
<G-vec00708-002-s107><pick_up.abholen><en> Minimise the number of ramp contacts in-house by simply giving your consignments to our vehicle when it comes to pick up your goods.
<G-vec00708-002-s108><pick_up.abholen><de> Du kannst Deinen Hund auf dem Weg zur Arbeit beim Sitter zu Hause absetzen oder mit Deinem örtlichen Sitter in Stadtbezirk 1 absprechen, dass er Deinen Hund abholt und nach Hause bringt.
<G-vec00708-002-s108><pick_up.abholen><en> You can drop your dog off at the sitter’s home on the way to work or organise with your local District Bellevue Pawshake sitter to pick up and drop off your dog each time.
<G-vec00708-002-s109><pick_up.abholen><de> Mir bleiben einige Stunden hier in den Strassen von Colombo bevor man mich abholt.
<G-vec00708-002-s109><pick_up.abholen><en> I had a couple of hours in the streets of Colombo before someone came to pick me up.
<G-vec00708-002-s110><pick_up.abholen><de> Zusätzlich zum Shuttledienst können Sie auch unser Hotel-Taxi buchen, das Sie zum Ausgangspunkt Ihrer Mountainbike-Touren bringt und wieder abholt.
<G-vec00708-002-s110><pick_up.abholen><en> In addition to the shuttle service you can also book our hotel taxi that will take you to the starting point of your mountain bike tours and then pick you up again.
<G-vec00708-002-s112><pick_up.abholen><de> Bitte hole es in dem genannten Zeitraum mit dieser Benachrichtigung ab oder beauftrage jemanden, der es für Dich abholt (mit Vollmacht).
<G-vec00708-002-s112><pick_up.abholen><en> We ask you to pick up your order in this given time period (you'd best bring along the notification of delivery) or ask someone else to pick it up for you (with a letter of authorization!).
<G-vec00708-002-s113><pick_up.abholen><de> Du kannst Deinen Hund auf dem Weg zur Arbeit beim Sitter zu Hause absetzen oder mit Deinem örtlichen Sitter in Bonheiden absprechen, dass er Deinen Hund abholt und nach Hause bringt.
<G-vec00708-002-s113><pick_up.abholen><en> You can drop your dog off at the sitter’s home on the way to work or organise with your local Burnside Pawshake sitter to pick up and drop off your dog each time.
<G-vec00708-002-s133><pick_up.abholen><de> Um Ihren Mietwagen am Mietpunkt in Kalmar abzuholen, müssen Sie unseren Bestätigungsbeleg, Ihren Führerschein und eine gültige Kreditkarte vorlegen.
<G-vec00708-002-s133><pick_up.abholen><en> To pick up your car at the rental point in Friedrichshafen, you need to provide our confirmation voucher, your driving license and a valid credit card.
<G-vec00708-002-s134><pick_up.abholen><de> Um die Aufenthaltsgenehmigung abzuholen wird kein Termin benötigt.
<G-vec00708-002-s134><pick_up.abholen><en> It is not necessary to make an appointment to pick up the residence permit.
<G-vec00708-002-s135><pick_up.abholen><de> Wir bieten Ihnen jedoch die Möglichkeit, Ihre Bestellung an einen UPS Access Point Ihrer Wahl liefern zu lassen und dort abzuholen.
<G-vec00708-002-s135><pick_up.abholen><en> However, you may have your order shipped to a UPS Access Point of your choice, where you can pick it up.
<G-vec00708-002-s136><pick_up.abholen><de> Als sein Arbeitgeber kam, um ihn abzuholen, konnte er fliehen und tauchte unter.
<G-vec00708-002-s136><pick_up.abholen><en> When his employer came to pick him up, he escaped and went into hiding.
<G-vec00708-002-s137><pick_up.abholen><de> Kein Problem, geben Sie uns Ihre Ankunftszeit am Bahnhof bekannt und wir kommen um Sie abzuholen...
<G-vec00708-002-s137><pick_up.abholen><en> No problem, let us know what time you'll be arriving at the train station and we'll come and pick you up.
<G-vec00708-002-s138><pick_up.abholen><de> Oder Sie können Ihren Kurier anrufen, um in unserem Büro abzuholen.
<G-vec00708-002-s138><pick_up.abholen><en> Or you can call your courier to pick up at our office.
<G-vec00708-002-s139><pick_up.abholen><de> Ich erklärte mich bereit, in zwei Wochen wiederzukommen, den Land Rover abzuholen und ihn dann zurück nach Sydney zu fahren.
<G-vec00708-002-s139><pick_up.abholen><en> I agreed to come back in two weeks and pick up the Land Rover and then drive it back to Sydney.
<G-vec00708-002-s140><pick_up.abholen><de> Mit Ton und Manna fuhr Kees nach Antwerpen um das Auto abzuholen.
<G-vec00708-002-s140><pick_up.abholen><en> On February 21 we could pick up the car Antwerp in Belgium.
<G-vec00708-002-s141><pick_up.abholen><de> Um das Mietauto außerhalb der Öffnungszeiten abzuholen, muss ein Antrag an die Autovermietung gestellt werden.
<G-vec00708-002-s141><pick_up.abholen><en> To pick up your car outside opening hours a special request has to be send to the rental company.
<G-vec00708-002-s142><pick_up.abholen><de> Um Ihren Mietwagen am Mietpunkt in Chur abzuholen, müssen Sie unseren Bestätigungsbeleg, Ihren Führerschein und eine gültige Kreditkarte vorlegen.
<G-vec00708-002-s142><pick_up.abholen><en> To pick up your car at the rental point in Hungary, you need to provide our confirmation voucher, your driving license and a valid credit card.
<G-vec00708-002-s143><pick_up.abholen><de> Ausleihe mit Versand der Steigeisen: Haben Sie nicht die Möglichkeit die Steigeisen bei uns im Laden abzuholen, schicken wir Ihnen die Steigeisen gerne auch per Post zu.
<G-vec00708-002-s143><pick_up.abholen><en> Loan with shipping of crampons: Did not the ability to pick up the crampons in our store, we will send you the crampons gladly by post.
<G-vec00708-002-s144><pick_up.abholen><de> Mit dieser Lösung verschaffen Händler ihren Kunden die Flexibilität, Produkte auf ihre jeweils bevorzugte Weise zu kaufen, zu bestellen, zu reservieren, abzuholen und zurückzugeben.
<G-vec00708-002-s144><pick_up.abholen><en> With this solution, retailers give their customers the flexibility to buy, order, reserve, pick up and return products in the way that works best for them.
<G-vec00708-002-s145><pick_up.abholen><de> Um Ihren Mietwagen am Mietpunkt in Kiruna abzuholen, müssen Sie unseren Bestätigungsbeleg, Ihren Führerschein und eine gültige Kreditkarte vorlegen.
<G-vec00708-002-s145><pick_up.abholen><en> To pick up your car at the rental point in Libya, you need to provide our confirmation voucher, your driving license and a valid credit card.
<G-vec00708-002-s146><pick_up.abholen><de> Carla war sehr freundlich, sogar angeboten, mich abzuholen am Bahnhof.
<G-vec00708-002-s146><pick_up.abholen><en> Carla was very kind, even offered to pick me up at the train station.
<G-vec00708-002-s147><pick_up.abholen><de> Ich habe Ihr Zimmer betreten, aber nur, wenn Sie mich darum gebeten haben, um die Miete abzuholen.
<G-vec00708-002-s147><pick_up.abholen><en> I did enter your room, but only when you asked me to do so to pick up the rent.
<G-vec00708-002-s148><pick_up.abholen><de> Ende des Jahres 2000 ging er zusammen mit Polizeibeamten nach Peking, um wegen des Appellierens festgenommene Falun Gong-Praktizierende abzuholen.
<G-vec00708-002-s148><pick_up.abholen><en> At the end of 2000, he went to Beijing with police officers to pick up Falun Gong practitioners arrested there for appealing.
<G-vec00708-002-s149><pick_up.abholen><de> Um Ihren Mietwagen am Mietpunkt in Norrkoping abzuholen, müssen Sie unseren Bestätigungsbeleg, Ihren Führerschein und eine gültige Kreditkarte vorlegen.
<G-vec00708-002-s149><pick_up.abholen><en> To pick up your car at the rental point in Djibouti, you need to provide our confirmation voucher, your driving license and a valid credit card.
<G-vec00708-002-s150><pick_up.abholen><de> Nutzen Sie Geo Targeting und Retargeting, um Ihre Kunden optimal abzuholen.
<G-vec00708-002-s150><pick_up.abholen><en> Use Geo Targeting and Retargeting to optimally pick up your customers.
<G-vec00708-002-s151><pick_up.abholen><de> "Gewisse Leute denken, dass es nur eine Formalität ist, heute hierher zu kommen, um einen Pass abzuholen und dann wieder zu gehen.
<G-vec00708-002-s151><pick_up.abholen><en> “Some people think it is just a formality to come along and pick up a passport today and then leave.
<G-vec00708-002-s529><pick_up.abholen><de> Gerne holen wir euch von eurer Urlaubsdestination im gesamten Bezirk Neusiedl am See ab und bringen euch zu uns zur Betriebsbesichtigung & Weinverkostung.
<G-vec00708-002-s529><pick_up.abholen><en> We will be happy to pick you up from your vacation destination in the entire district of Neusiedl am See and bring you to our winery for a tour and wine tasting.
<G-vec00708-002-s530><pick_up.abholen><de> Wenn Sie mit Ihrer Matratze nicht zufrieden sind, holen wir sie bei Ihnen ab.
<G-vec00708-002-s530><pick_up.abholen><en> If you are not satisfied, with your mattress, we will come pick it up.
<G-vec00708-002-s531><pick_up.abholen><de> Viele Gastgeber holen ihre Gäste auf Wunsch von den Bahnhöfen ab.
<G-vec00708-002-s531><pick_up.abholen><en> Many hosts offer to pick up their guests from the train stations.
<G-vec00708-002-s532><pick_up.abholen><de> Rund ein Drittel davon holen im Werk in regelmäßigen Abständen zu festgelegten Zeitpunkten Ware ab.
<G-vec00708-002-s532><pick_up.abholen><en> Around a third of the vehicles pick up goods at set times and at regular intervals.
<G-vec00708-002-s533><pick_up.abholen><de> Wir holen das Produkt kostenlos bei der ursprünglichen Lieferadresse (innerhalb der Sonos-Serviceregion) ab und erstatten den vollen Kaufpreis zurück.
<G-vec00708-002-s533><pick_up.abholen><en> We will pick up the product free of cost at the original delivery address (in the Sonos Service Region) and refund the full purchase price.
<G-vec00708-002-s534><pick_up.abholen><de> Serviceabgabestation Geben Sie Ihre Ski oder Snowboard gleich im Shop Idalp zum Service und holen Sie Ihre Skiausrüstung am nächsten Morgen wieder ab, um direkt auf die Piste zu starten.
<G-vec00708-002-s534><pick_up.abholen><en> Drop off your skis or snowboard for servicing at the Idalp shop. The next morning your equipment will be ready for you to pick up and you can hit the slopes straight away.
<G-vec00708-002-s535><pick_up.abholen><de> Wir holen Sie vom Hotel oder von der Adresse ab, die Sie uns in Athen oder Piräus geben.
<G-vec00708-002-s535><pick_up.abholen><en> - We can pick you up from your hotel or address you give us, in Athens or Piraeus.
<G-vec00708-002-s536><pick_up.abholen><de> Etwa sechzig anerkannte belgische Einrichtungen holen bei unseren Erzeugergenossenschaften regelmäßig Obst und Gemüse ab - bis zu 150 kg pro Person und pro Jahr.
<G-vec00708-002-s536><pick_up.abholen><en> Some sixty recognised bodies in Belgium can come and pick up products from our producers' cooperatives, up to 150 kilograms per person per year.
<G-vec00708-002-s537><pick_up.abholen><de> Die Pflücker holen die Oliven von Hand oder mit Rüttelstäben von den Bäumen, dann geht es ab in die Ölmühle.
<G-vec00708-002-s537><pick_up.abholen><en> The pickers pick the olives from the trees by hand or with shaking sticks, then the olives they are taken to the oil mill.
<G-vec00708-002-s538><pick_up.abholen><de> Wir holen Sie von Ihrem Hotel in Reykjavík oder einem nahegelegenen Treffpunkt ab.
<G-vec00708-002-s538><pick_up.abholen><en> We pick you up from your hotel or a nearby meeting point in Reykjavik.
<G-vec00708-002-s539><pick_up.abholen><de> Wir holen unsere Gäste (gegen Voranmeldung) kostenlos vom Bahnhof Bad Mitterndorf ab.
<G-vec00708-002-s539><pick_up.abholen><en> We are glad to pick up our guests (with advance notice) free of charge from the train station in Bad Mitterndorf.
<G-vec00708-002-s540><pick_up.abholen><de> Wir holen Sie vom Flughafen ab und bieten Unterbringung mit Halbpension (mit Tee, Kaffee, Tischwein, Bier, Wasser und Softdrinks – Cocktails und Longdrinks auf Wunsch gegen Bezahlung) oder B&B an.
<G-vec00708-002-s540><pick_up.abholen><en> We pick up from the airport and provide accommodation either half board (with tea, coffee, table wine, beer, soft drinks and water – cocktails and spirits available to purchase) or bed and breakfast.
<G-vec00708-002-s541><pick_up.abholen><de> Falls Sie mit Zug, Bus oder Flugzeug anreisen, holen wir Sie gerne ab.
<G-vec00708-002-s541><pick_up.abholen><en> If you arrive by train, bus or plane, we will be happy to pick you up.
<G-vec00708-002-s542><pick_up.abholen><de> Auf dem Weg zur Höhlen holen wir noch zwei alternative Mädels aus den USA ab.
<G-vec00708-002-s542><pick_up.abholen><en> We pick up some alternative girls from the USA and are heading to the caves.
<G-vec00708-002-s543><pick_up.abholen><de> Wenn Sie China das erste Mal besuchen, holen wir Sie gerne vom Flughafen ab und schicken Sie zum Hotel.
<G-vec00708-002-s543><pick_up.abholen><en> If it is your first time visit China, we would like to pick up you from the airport and send you to the hotel.
<G-vec00708-002-s544><pick_up.abholen><de> - Bahnhofstransfer: Bei der Bahnanreise bringen/holen wir unsere Gäste bei Bedarf vom Bahnhof ab.
<G-vec00708-002-s544><pick_up.abholen><en> - Station Transfer: If the train arrival / we pick up our guests from the station if required.
<G-vec00708-002-s545><pick_up.abholen><de> Wenn Du mit dem Zug kommst, holen wir dich gerne vom Bahnhof in Schladming ab.
<G-vec00708-002-s545><pick_up.abholen><en> If you come by train, we will gladly pick you up at the station in Schladming.
<G-vec00708-002-s546><pick_up.abholen><de> Sie holen dich sogar am Hafen ab.
<G-vec00708-002-s546><pick_up.abholen><en> They’ll even pick you up at the port.
<G-vec00708-002-s547><pick_up.abholen><de> Wir holen Sie von dem Flughafen in Denpasar ab und nach Ihrem Aufenthalt bringen wir Sie wieder zum Flughafen zurück.
<G-vec00708-002-s547><pick_up.abholen><en> They will pick you up at the airport in Denpasar and also give you a lift back to the airport.
<G-vec00708-002-s586><pick_up.abholen><de> Nach Ihrer Ankunft unser Fahrer holt Sie vom Flughafen Budapest ab und fährt mit Ihrem privaten Transfer zu Ihrer Unterkunft.
<G-vec00708-002-s586><pick_up.abholen><en> After your arrival our driver will pick you up from the Budapest Airport for your free private transfer to your accommodation.
<G-vec00708-002-s587><pick_up.abholen><de> Unser Taxianbieter vor Ort holt Sie gerne zu jeder Uhrzeit ab.
<G-vec00708-002-s587><pick_up.abholen><en> Our local taxi provider will happily pick you up at any given time.
<G-vec00708-002-s588><pick_up.abholen><de> Der Fahrer holt Sie jeweils in der Ankunftshalle mit einem Namensschild ab.
<G-vec00708-002-s588><pick_up.abholen><en> The driver will pick you up in the arrivals hall with a name sign.
<G-vec00708-002-s589><pick_up.abholen><de> Unsere Gemeinschaft holt sie an der Peripherie ab, und lädt sie ein.
<G-vec00708-002-s589><pick_up.abholen><en> Our community will pick them up on the periphery and invite them.
<G-vec00708-002-s590><pick_up.abholen><de> Dann wähle unsere Transportvariante der Shuttle Transfers: Bei dieser Option holt Dich unser Fahrer zu festgelegten Zeiten in der Lobby Deines Hotels ab und bringt Dich gemeinsam mit weiteren Gästen zu Deiner nächsten Destination, und dort auch gleich direkt in das von uns bestätigte Hotel.
<G-vec00708-002-s590><pick_up.abholen><en> If so, you should choose our shuttle transfers. With this option, our driver will pick you up at a set time in the lobby of your hotel, and will drive you, together with other guests, to your next destination directly to your confirmed hotel.
<G-vec00708-002-s591><pick_up.abholen><de> Der Fan bestellt und bezahlt sein Essen und seine Getränke bequem vom Platz und holt seine Bestellung dann am Kiosk ab.
<G-vec00708-002-s591><pick_up.abholen><en> The fans order and pay for their food and drinks conveniently from their seats and then pick up their order at the kiosk.
<G-vec00708-002-s592><pick_up.abholen><de> Unser Kurier holt das Paket an der von Ihnen angegeben Adresse ab und stellt es an die ausgewählte Adresse in den USA zu.
<G-vec00708-002-s592><pick_up.abholen><en> Our courier will pick up the package at given address and deliver it to your chosen destination in the USA.
<G-vec00708-002-s593><pick_up.abholen><de> Also: Schlaft Euch im gemütlichen großen Bett aus, holt Eure frischen Brötchen ab und stärkt Euch mit einem gemütlichen Frühstück in Eurem Appartement.
<G-vec00708-002-s593><pick_up.abholen><en> So: Sleep in the cozy big bed, pick up your fresh bread and strengthen you with a cozy breakfast in your apartment.
<G-vec00708-002-s594><pick_up.abholen><de> Unser freundliche(r) Guide holt Sie von Ihrer Unterkunft ab.
<G-vec00708-002-s594><pick_up.abholen><en> Our lovely guide will pick you up in your accommodation.
<G-vec00708-002-s595><pick_up.abholen><de> Für beide Touren holt das Unternehmen Sie von Ihrer Unterkunft in Cradle Mountain ab.
<G-vec00708-002-s595><pick_up.abholen><en> For both tours, the company will pick you up from your Cradle Mountain accommodation.
<G-vec00708-002-s596><pick_up.abholen><de> Um den Ausflug noch angenehmer zu gestalten, holt Beautiful Tours Sie direkt in Ihrem Stadthotel ab und bringt Sie nach der Tour wieder zum Hotel zurück.
<G-vec00708-002-s596><pick_up.abholen><en> For your convenience, Beautiful Tours will pick you up from your hotel in the city and return you to your hotel after the tour.
<G-vec00708-002-s597><pick_up.abholen><de> Der MINI der Zukunft ist stets verfügbar, er holt seinen Fahrer völlig automatisiert an gewünschter Stelle ab und stellt sich ganz auf ihn ein.
<G-vec00708-002-s597><pick_up.abholen><en> The MINI of the future will be available 24/7 - fully automated, so that it can pick up its driver from their desired location, tailored precisely to their own taste.
<G-vec00708-002-s598><pick_up.abholen><de> • Transfer oder “Pick-up” Service für individuelle Aufenthalte: AIL Malaga holt Sie am Flughafen ab und bringt Sie zu Ihrer Unterkunft.
<G-vec00708-002-s598><pick_up.abholen><en> • Transfer or “Pick –up” Service for Individual Stays: AIL Malaga can pick you up at the airport and bring you to your accommodation.
<G-vec00708-002-s599><pick_up.abholen><de> Unser Repräsentant holt Sie an der Rezeption ab und bringt Sie zurück zum Flughafen zu Ihrer Abreise.
<G-vec00708-002-s599><pick_up.abholen><en> Our representative will pick you up at the reception to transfer you back to Cairo International Airport for your final departure.
<G-vec00708-002-s600><pick_up.abholen><de> Betten, Sonnenliegen und Reservierungen zum Mittagessen oder Spa Behandlungen sind besser im Voraus zu reservieren, gern holt man Sie dann auch mit dem Abholservice von Ihrer Luxusyacht ab.
<G-vec00708-002-s600><pick_up.abholen><en> Beds, sun loungers and reservations for lunch or spa treatments are better to book in advance, you will be happy to be pick you up with the pick-up service from your luxury yacht.
<G-vec00708-002-s601><pick_up.abholen><de> Gerne holt dich dein Instruktor bei ganztägigen Buchungen im Hotel ab.
<G-vec00708-002-s601><pick_up.abholen><en> If you book a full day course, your snowboard instructor will be happy to pick you up at your hotel.
<G-vec00708-002-s602><pick_up.abholen><de> Ein Skishuttle holt Sie vor der Unterkunft ab und bringt Sie direkt zum Skigebiet Alpe di Siusi.
<G-vec00708-002-s602><pick_up.abholen><en> A ski shuttle bus will pick you up outside the property and take you directly to the Alpe di Siusi ski area.
<G-vec00708-002-s603><pick_up.abholen><de> Am frühen Nachmittag holt unser Fahrer Sie vom Ihrem Hotel ab.
<G-vec00708-002-s603><pick_up.abholen><en> In the early afternoon our driver will pick you up from your hotel.
<G-vec00708-002-s604><pick_up.abholen><de> Der Besitzer holt dich auch am Flughafen ab, bringt dich in dein Zimmer und kocht einheimische Gerichte für dich.
<G-vec00708-002-s604><pick_up.abholen><en> The owner will also pick you up at the airport, bring you back to your room, and cook local dishes for you.
<G-vec01164-002-s510><pick_up.abholen><de> Sie holen Ihr Fahrzeug an der Sixt-Station ab.
<G-vec01164-002-s510><pick_up.abholen><en> You pick up your car at the Sixt branch.
<G-vec01164-002-s511><pick_up.abholen><de> Wir holen Sie direkt am Ausgang Ihres Schiffes am Hafen von Port Said ab; Sie erkennen unseren Fahrer an einem Schild mit Ihrem Namen in seiner Hand.
<G-vec01164-002-s511><pick_up.abholen><en> Day 01: We will pick you up directly from the exit door of your cruise; you will recognize our driver by a sign with your name in his hand.
<G-vec01164-002-s512><pick_up.abholen><de> Nach ausgedehnten Partystreifzügen durch das legendäre Nachtleben Obertauerns holen Sie die zuverlässigen FREUDENHAUS Taxifahrer ab und bringen Sie wieder zurück in Ihr gemütliches Hotel.
<G-vec01164-002-s512><pick_up.abholen><en> After a long night enjoying Obertauern’s legendary nightlife, let a dependable FREUENDHAUS taxi driver pick you up and take you safely to your comfortable hotel.
<G-vec01164-002-s513><pick_up.abholen><de> Mushroom Rock – Wir holen Sie direkt am Eingang Ihres Hotels ab; Sie erkennen unseren Fahrer an einem Schild mit Ihrem Namen in seiner Hand.
<G-vec01164-002-s513><pick_up.abholen><en> We will pick you up directly from the entrance door of your hotel in Sharm El Sheikh; you will recognize our driver by a sign with your name in his hand.
<G-vec01164-002-s514><pick_up.abholen><de> Wir holen Sie in Ihrer Unterkunft in Cairs ab.
<G-vec01164-002-s514><pick_up.abholen><en> We will pick you up in your accommodation in Cairs.
<G-vec01164-002-s515><pick_up.abholen><de> Während der Carrier-Fahrt kann der Staplerfahrer eine weitere Palette holen, am Kanalanfang absetzen, die nächste Einlagerung starten und ein neues Arbeitsspiel beginnen.
<G-vec01164-002-s515><pick_up.abholen><en> Meanwhile the operator can pick up another pallet to be stored, position it at the start of the channel and initiate the next item of storage. Efficient co-operation
<G-vec01164-002-s516><pick_up.abholen><de> Sie reisen bequem und ohne Stress mit der Bahn an, wir holen Sie vom Bahnhof ab und bringen Sie direkt zu ihrem Unterkunftsbetrieb in Werfenweng.
<G-vec01164-002-s516><pick_up.abholen><en> You take a comfortable, stress-free train trip and we pick you up at the station and take you directly to your lodging in Werfenweng.
<G-vec01164-002-s517><pick_up.abholen><de> Wir holen Sie am Bilbao Flughafen, den Bahnhof oder Busbahnhof.
<G-vec01164-002-s517><pick_up.abholen><en> We pick up at Bilbao International airport, Train station, or Bus station.
<G-vec01164-002-s518><pick_up.abholen><de> Holen Sie sich Produkte direkt aus dem Garten und entdecken Sie die einfachen Freuden der Zubereitung und des Verzehrs frisch geernteter Zutaten in einer der Boutique-Kochschulen Tasmaniens.
<G-vec01164-002-s518><pick_up.abholen><en> Pick your produce straight from the garden and rediscover the simple pleasures of preparing and eating freshly harvested ingredients at one of Tasmania’s boutique cooking schools.
<G-vec01164-002-s519><pick_up.abholen><de> Stöbern Sie in ihrem modischen Schrank und holen entsprechende Kleider, Tops und Böden.
<G-vec01164-002-s519><pick_up.abholen><en> Rummage in her fashionable closet and pick appropriate dresses, tops and bottoms.
<G-vec01164-002-s520><pick_up.abholen><de> Transfer: Wir holen Sie von jedem Hotel in Dahab ab und bringen sie zu den Tauchplätzen / Häfen und wieder zurück ins Hotel.
<G-vec01164-002-s520><pick_up.abholen><en> Transfer: We will pick you up and bring you back to any hotel in Dahab and to the dive sites/harbours.
<G-vec01164-002-s521><pick_up.abholen><de> Vor einer Stunde hat er drei Freunde losgeschickt, die einen neuen Kasten holen sollen, aber sie sind nirgends zu sehen.
<G-vec01164-002-s521><pick_up.abholen><en> An hour earlier, he had dispatched three friends to pick up another case, but they were nowhere in sight.
<G-vec01164-002-s522><pick_up.abholen><de> Wir holen Sie daher ohne Mehrkosten von Ihrer Unterkunft auf Madeira ab und bringen Sie am Ende wieder dorthin zurück (in den Bereichen Funchal, Garajau, Caniço, Santa Cruz und Machico).
<G-vec01164-002-s522><pick_up.abholen><en> Without any extra costs we will pick you up from your lodging on Madeira and afterwards take you back as well (this applies to Funchal, Garajau, Caniço, Santa Cruz and Machico; other locations on request).
<G-vec01164-002-s523><pick_up.abholen><de> Unsere ersten Zwischenergebnisse zeigen, dass sieben von zehn Personen pünktlich zur Klinik gehen, um einen Nachschub an Medikamenten zu holen.
<G-vec01164-002-s523><pick_up.abholen><en> Our first interim results show that with this intervention seven in ten people report to the clinic on schedule to pick up their next round of medications.
<G-vec01164-002-s524><pick_up.abholen><de> Wir holen die Austern und erfahren Sie mehr über Meeres Delikatesse in einem ganz besonderen und einzigartigen Ort in Bohuslän.
<G-vec01164-002-s524><pick_up.abholen><en> We pick oysters and learn more about this delicacy at a very special and unique place in Bohuslän.
<G-vec01164-002-s525><pick_up.abholen><de> Es ist nur notwendig, zu einem Arzt zu gehen und die Medizin zu holen, die je nach Dosis und Art des Hormons zu Ihnen passt.
<G-vec01164-002-s525><pick_up.abholen><en> It's just necessary to come to a doctor and pick up that medicine, which, according to the dose and type of hormone, will suit you.
<G-vec01164-002-s526><pick_up.abholen><de> Der Garten ist sehr schön und es ist ein Vergnügen, frische Orangen und Grapefruits im Februar zu holen.
<G-vec01164-002-s526><pick_up.abholen><en> The garden is lovely and its a pleasure to pick fresh oranges and grapefruits in February.
<G-vec01164-002-s527><pick_up.abholen><de> Beschreibung: Schüler, Studenten, Jetzt holen eine Eintrittskarte in den besten Universitäten in Europa, Kanada und den USA Genießen Sie das Ende der akademischen, beruflichen Integration réuissie in unserem Partner-Unternehmen der Welt.
<G-vec01164-002-s527><pick_up.abholen><en> --- CHOOSE ---Description: Students, Students, Now pick an admission in the best universities in Europe, Canada and USA Enjoy the end of the academic, professional integration réuissie in our partner company in the world.
<G-vec01164-002-s528><pick_up.abholen><de> John war so freundlich, uns zu holen, als wir ankamen.
<G-vec01164-002-s528><pick_up.abholen><en> John was kind enough to pick us up when we arrived.
<G-vec01164-002-s548><pick_up.abholen><de> So einfach holen Sie sich den Käfer-Chromstyle an Ihr Auto.
<G-vec01164-002-s548><pick_up.abholen><en> So easy to pick up the beetle-chrome style to your car.
<G-vec01164-002-s549><pick_up.abholen><de> Holen Sie sich Ihren Leih-Schlitten bei Sport Schultes und Sport Lentsch und starten Sie mit der ganzen Familie und mit Freunden ins lustige Wintervergnügen.
<G-vec01164-002-s549><pick_up.abholen><en> Pick up your rental toboggan at Sport Schultes and Sport Lentsch, and set off for entertaining wintertime fun with the whole family and your friends.
<G-vec01164-002-s550><pick_up.abholen><de> Holen Sie sich Ihren Skipass gleich bei der Ankunft im Sporthotel Auriga an der Rezeption ab, verstauen Sie Ihr Equipment im Skikeller mit persönlichem Spind und kosten Sie das Skigebiet am Arlberg von der ersten bis zur letzten Urlaubsminute voll aus.
<G-vec01164-002-s550><pick_up.abholen><en> Pick up your ski pass at reception right upon arriving at the sports hotel Auriga, store your equipment in the ski cellar with your personal locker and savour the ski region on the Arlberg from the first to the last minute of your holiday.
<G-vec01164-002-s551><pick_up.abholen><de> Holen Sie sich Ihre Schere und machen Sie sich bereit, einige erstaunliche Designs für ihre Verjüngungskur zu machen.
<G-vec01164-002-s551><pick_up.abholen><en> Pick up your scissors and get ready to make some amazing designs for her makeover.
<G-vec01164-002-s552><pick_up.abholen><de> Wenn Sie Liepaja per Zug oder Bus erreichen, holen wir Sie gerne vom zentralen Bus/Zugbahnhof ab und bringen Sie auch wieder zurück.
<G-vec01164-002-s552><pick_up.abholen><en> If you come to Liepaja by public transport we offer to pick you up at the Liepaja Bus Station or Railway Station.
<G-vec01164-002-s553><pick_up.abholen><de> Die Kunden holen ihren fertigen Einkauf im Ladenlokal ab, oder sie lassen ihn sich vom Lebensmittel-Lieferservice am gleichen Tag nach Hause bringen.
<G-vec01164-002-s553><pick_up.abholen><en> Customers either pick up their shopping from the outlet or have their shopping home-delivered the same day via the food delivery service.
<G-vec01164-002-s554><pick_up.abholen><de> Holen Sie sich einfach ein biometrisches Armband im neuen Porto Sani Fitnessstudio und es kann losgehen.
<G-vec01164-002-s554><pick_up.abholen><en> Simply pick up a biometric wristband at the new Porto Sani gym and off you go.
<G-vec01164-002-s555><pick_up.abholen><de> Holen Sie sich noch heute Ihr Anmeldeformular in einer der an Shell CLUBSMART teilnehmenden Shell Stationen ab.
<G-vec01164-002-s555><pick_up.abholen><en> Simply pick up your registration form today in any participating Shell station who offers Shell CLUBSMART.
<G-vec01164-002-s556><pick_up.abholen><de> Holen Sie sich Snacks und Getränke in unserem Verkaufsgeschäft, oder erkunden Sie die hübschen Restaurants der Umgebung mit mexikanischer und amerikanischer Küche sowie Cajun-Gerichten.
<G-vec01164-002-s556><pick_up.abholen><en> Pick up snacks and beverages from our sundry shop and venture out to the area to enjoy Mexican, Cajun, and American food at your leisure.
<G-vec01164-002-s557><pick_up.abholen><de> Holen Sie sich ein Auto vom Flughafen und fahren Sie sich für die Dauer Ihres Urlaubs.
<G-vec01164-002-s557><pick_up.abholen><en> Pick up a car from the airport and drive yourself for the duration of your holiday.
<G-vec01164-002-s558><pick_up.abholen><de> Holen Sie sich Ihr persönliches Exemplar bei einer unserer kommenden Veranstaltungen, blättern Sie in der Online-Version oder downloaden Sie den XiGuide als PDF.
<G-vec01164-002-s558><pick_up.abholen><en> Don’t forget to pick up your personal copy at one of our upcoming events, browse through the online version or download the XiGuide as a PDF.
<G-vec01164-002-s559><pick_up.abholen><de> Holen Sie sich einen persönlichen Cool tour Paß ab, sammeln Sie Stempel der einzelnen Ausstellungen des Nationalmuseums und der Nationalgalerie in Prag und gewinnen Sie attraktive Preise.
<G-vec01164-002-s559><pick_up.abholen><en> Pick up your personal Cool Tour Pass and collect stamps of individual exhibitions of the National Museum and the National Gallery in Prague, and win exciting prizes.
<G-vec01164-002-s560><pick_up.abholen><de> Holen Sie sich das perfekte Souvenir aus Bali während dieser 5-stündigen Shopping-Exkursion zu einigen der besten Galerien, Workshops und Aufführungsräumen der Insel.
<G-vec01164-002-s560><pick_up.abholen><en> Pick up the perfect Bali souvenir during this 5-hour shopping-themed excursion to some of the island’s top galleries, workshops, and performance spaces.
<G-vec01164-002-s561><pick_up.abholen><de> Sobald Sie im Abflugbereich des Flughafens sind, holen Sie sich ein US-Zollformular und füllen es aus.
<G-vec01164-002-s561><pick_up.abholen><en> Once you're in the airport departure area, pick up and fill in a U.S. Customs form.
<G-vec01164-002-s562><pick_up.abholen><de> Holen Sie sich ein T-Shirt mit Kanji-Schriftzeichen, einen traditionellen Fächer, eine Maske oder eine Kokeshi-Puppe aus Holz – einzigartige Erinnerungen an Ihre Tokyo-Reise – und genießen Sie traditionelle Snacks und Süßigkeiten, die direkt vor Ihren Augen gebacken werden.
<G-vec01164-002-s562><pick_up.abholen><en> Pick up a T-shirt adorned with kanji characters or a traditional fan, a mask or a wooden kokeshi doll—some distinctive reminders of your Tokyo trip—and fill up on traditional snacks and sweets baked right in front of you.
<G-vec01164-002-s563><pick_up.abholen><de> Bestellen Sie unterwegs Ihr Produkt und holen Sie es in einer Filiale Ihrer Wahl ab.
<G-vec01164-002-s563><pick_up.abholen><en> Order your product go and pick it up at a branch of your choice from.
<G-vec01164-002-s564><pick_up.abholen><de> Sammeln Sie Info-Materialien für Ihr kommendes Reiseziel oder Ihre nächste Aktivität, holen Sie sich einen kostenlosen Reiseführer, und geben Sie Ihren Kindern Broschüren vom California Welcome Center zum Durchblättern.
<G-vec01164-002-s564><pick_up.abholen><en> Load up on materials for your next destination or activity, pick up a free California Visitor’s Guide, and give your kids brochures to peruse at one of the state’s California Welcome Centers.
<G-vec01164-002-s565><pick_up.abholen><de> Häufige Bingo-Enthusiasten hatten ein besseres Gehirn, Speicher und eine viel größere Fähigkeit zu holen Daten aus der Welt um sie herum.
<G-vec01164-002-s565><pick_up.abholen><en> Regular bingo players had a better brain speed, memory and a much higher ability to pick up info from their surroundings.
<G-vec01164-002-s566><pick_up.abholen><de> Lassen Sie sich Ihre Bestellung lecker und schnell nach Hause liefern oder holen Sie sie in unserem Store selbst ab.
<G-vec01164-002-s566><pick_up.abholen><en> Catch your order tasty and delivered quickly to your home or pick them in our store itself.
<G-vec01164-002-s567><pick_up.abholen><de> Man kann selbst anreisen oder aber von Luang Prabang aus starten (der Anbieter holt einen dort vom Hostel / Hotel ab).
<G-vec01164-002-s567><pick_up.abholen><en> It’s possible to get there on your own or with the company from Luang Prabang (they pick you up at your hostel / hotel in Luang Prabang).
<G-vec01164-002-s568><pick_up.abholen><de> Verwalter Hilde führt Sie durch das Haus, kümmert sich um den Transport vom und zum Flughafen und holt Ihnen die ersten Einkäufe, wenn Sie möchten.
<G-vec01164-002-s568><pick_up.abholen><en> Administrator Hilde will show you around the house, take care of the first supermarket shopping, pick you up at the airport (and take you back on departure day), if you so desire.
<G-vec01164-002-s569><pick_up.abholen><de> Premier Yoga Holidays holt Sie vom Flughafen ab.
<G-vec01164-002-s569><pick_up.abholen><en> Premier Yoga Holidays will pick you up from the airport between 10:00 and 22:00.
<G-vec01164-002-s570><pick_up.abholen><de> Der Fahrer Ihres Shuttles oder der Chauffeur Ihrer Limousine holt Sie im Hotel oder auch am Flughafen mit Namensschild ab und begleitet Sie auf Wunsch bis zum Schalter.
<G-vec01164-002-s570><pick_up.abholen><en> The driver of your shuttle or chauffeur of your limousine will pick you up from your hotel in Dusseldorf or greet you at the airport with your name displayed on a sign.
<G-vec01164-002-s571><pick_up.abholen><de> Jeden Vormittag holt dich ein Bus an einer Haltestelle in der Nähe deiner Gastfamilie ab und bringt dich zur Schule oder zu den organisierten Aktivitäten.
<G-vec01164-002-s571><pick_up.abholen><en> Each morning, the bus will pick you up at a bus stop near your host family's home and take you to the school or to the activity's venue.
<G-vec01164-002-s572><pick_up.abholen><de> Den Führer holt Sie um 8.00 Uhr von ihrem Hotel in Cochabamba ab in einem 4x4 Auto um sich auf eine beeindruckende Reise nach Torotoro, nördlich von Potosí, zu begeben.
<G-vec01164-002-s572><pick_up.abholen><en> The guide will pick you up from your hostal or hotel in Cochabamba around 8.00 hrs. to undertake the impressive trip in 4x4 vehicle to Torotoro, north of Potosí.
<G-vec01164-002-s573><pick_up.abholen><de> Gerne holt sie unser Portier gratis mit dem Elektrowagen zwischen 8 und 20 Uhr am Bahnhof Zermatt ab.
<G-vec01164-002-s573><pick_up.abholen><en> Our porter will be happy to pick you up free of charge at the Zermatt railway station between 8 am and 8 pm. Version II
<G-vec01164-002-s574><pick_up.abholen><de> Unsere Mitarbeiter von der Lodge holt Sie am Kreisverkehr.
<G-vec01164-002-s574><pick_up.abholen><en> Our staff from the Lodge will pick you up at the Roundabout.
<G-vec01164-002-s575><pick_up.abholen><de> Sie ruft für uns unseren Kontaktmann an und dieser holt uns ab.
<G-vec01164-002-s575><pick_up.abholen><en> He tells her that we should wait and that he will pick us up.
<G-vec01164-002-s576><pick_up.abholen><de> Wenn Sie möchten, holt Ihre Gastfamilie Sie vom Flughafen ab.
<G-vec01164-002-s576><pick_up.abholen><en> If you wish, your host family will pick you up from the airport at an extra fee of $ 20.
<G-vec01164-002-s577><pick_up.abholen><de> Danach holt Sie Ihr Guide zu einer halbtägigen Sightseeingtour durch Hoi An ab.
<G-vec01164-002-s577><pick_up.abholen><en> Our driver will pick you up at the airport, then transfer you to Hoi An ancient town.
<G-vec01164-002-s578><pick_up.abholen><de> Privatunterricht: Ihr Skilehrer holt Sie in Ihrem Hotel ab, das Tages-Programm wird ganz Ihren Wünschen und Erwartungen angepasst.
<G-vec01164-002-s578><pick_up.abholen><en> Private lessons: Your instructor will pick you up at your hotel, the day program will be adapted to your wishes and expectations.
<G-vec01164-002-s579><pick_up.abholen><de> Ihr Chauffeur holt Sie ab und bringt Sie in Komfort zu Ihrem Hotel, Ihrer Besprechung oder wohin Sie auch möchten.
<G-vec01164-002-s579><pick_up.abholen><en> Your driver will pick you up wherever you like and will take you in comfort to your hotel or directly to your meeting.
<G-vec01164-002-s580><pick_up.abholen><de> Erneut holt Sie morgens ein Taxi von Ihrem Hotel ab, um zum Pico Birigoyo zu gelangen, ein alter Vulkankegel auf etwa 1.800 Metern Höhe, der sich im Erholungsgebiet El Pilar befindet.
<G-vec01164-002-s580><pick_up.abholen><en> Once again, in the morning, a taxi will pick you up at your hotel to go to Pico Birigoyo, an ancient volcanic cone located at an altitude of about 1,800 metres above sea level, which is to be found in the El Pilar recreational area.
<G-vec01164-002-s581><pick_up.abholen><de> Und falls Sie mit dem Flugzeug anreisen, holt Sie unser Shuttle direkt am Flughafen Catania ab.
<G-vec01164-002-s581><pick_up.abholen><en> In the event that you arrive by plane, our shuttle service will pick you up directly at Catania airport.
<G-vec01164-002-s582><pick_up.abholen><de> Unser Fahrradtaxi bringt Sie zu den schönsten Fahrradwegen Südtirols und holt sie am Ende Ihrer Tour wieder ab.
<G-vec01164-002-s582><pick_up.abholen><en> Our bike taxi accompanies you to the starting points of the best bicycle routes in South Tyrol and comes to pick you up when your excursion is over.
<G-vec01164-002-s583><pick_up.abholen><de> Unser kostenloser Shuttle Service holt euch rund um Cala Ratjada ab.
<G-vec01164-002-s583><pick_up.abholen><en> We pick you up for free around Cala Ratjada.
<G-vec01164-002-s584><pick_up.abholen><de> Zum Mittag kommen nur wenige, daher packen wir das Essen ein und der/die Sanitäter/in kommt vorbei und holt das Essen ab.
<G-vec01164-002-s584><pick_up.abholen><en> Only a few come for lunch so we pack the food and the medic will come and pick it up.
<G-vec01164-002-s585><pick_up.abholen><de> Ihr Reiseleiter und Führer holt Sie morgens vom Flughafen oder von Ihrem Hotel ab und begleitet Sie auf der dreistündigen Fahrt zur Lodge im Schnellboot.
<G-vec01164-002-s585><pick_up.abholen><en> Your guide will pick you up from the airport or your hotel in the morning and accompany you on the three-hour journey in speedboat to the lodge.
