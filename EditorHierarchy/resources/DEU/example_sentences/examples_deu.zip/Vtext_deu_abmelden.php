<G-vec00297-002-s049><opt.abmelden><de> Abmeldung – In jeder Werbe- oder Angebots-E-Mail, die Sie von uns erhalten, ist ein „Unsubscribe'-Hyperlink enthalten, den Sie verwenden können, wenn Sie sich „abmelden' und nicht länger E-Mails von uns erhalten möchten.
<G-vec00297-002-s049><opt.abmelden><en> In each and every email that we send to you, there is an ‘unsubscribe’ hyperlink, which you may you use if you wish to ‘opt out’ of and stop receiving email communications from us.
<G-vec00297-002-s050><opt.abmelden><de> Wann immer Sie sich von einem Newsletter abmelden können.
<G-vec00297-002-s050><opt.abmelden><en> You can opt out of our newsletter whenever you like.
<G-vec00297-002-s051><opt.abmelden><de> Ich verstehe, dass ich mich jederzeit abmelden kann.
<G-vec00297-002-s051><opt.abmelden><en> I understand I can opt out at any time.
<G-vec00297-002-s052><opt.abmelden><de> Wenn Sie sich von Google Analytics abmelden möchten, können Sie das Add-on für Ihren Browser hier herunterladen und installieren.
<G-vec00297-002-s052><opt.abmelden><en> If you want to opt out of Google Analytics, you can download and install the add-on for your web browser here.
<G-vec00297-002-s053><opt.abmelden><de> Weil diese Hinweise Ihre Vertragsbeziehung mit Claris betreffen, können Sie sich von diesen Mitteilungen nicht abmelden.
<G-vec00297-002-s053><opt.abmelden><en> Because this information is important to your interaction with Claris, you may not opt out of receiving these communications.
<G-vec00297-002-s054><opt.abmelden><de> Wenn Sie die E-Mail-Nachricht nicht mehr haben, können Sie sich jederzeit ganz einfach abmelden, indem Sie hier klicken.
<G-vec00297-002-s054><opt.abmelden><en> If you no longer have the email message, you can easily opt out any time by clicking here.
<G-vec00297-002-s055><opt.abmelden><de> Wenn Sie Ihre Meinung ändern und erneut abmelden möchten, können Sie dies jederzeit tun, indem Sie den "unsubscribe" Link unten in jedem Newsletter anklicken und den bereitgestellten Informationen folgen.
<G-vec00297-002-s055><opt.abmelden><en> If you change your mind and wish to opt out again, you may do so at any time by clicking the "unsubscribe" link at the bottom of any newsletter and then following the instructions provided.
<G-vec00297-002-s056><opt.abmelden><de> Mit der Einwilligung bestätige ich, dass ich den AGB von Amara zustimme, und ich verstehe, dass ich mich jederzeit abmelden kann.
<G-vec00297-002-s056><opt.abmelden><en> By opting in I agree to Amara's terms and conditions and understand I can opt out at any time. Sign up
<G-vec00297-002-s057><opt.abmelden><de> Ich denke, sie halten ein einigermaßen hohes Niveau, aber es geht auch um die Tatsache, dass ich mich von den Leuten, die ich kenne, abmelden werde mir nichts geben.
<G-vec00297-002-s057><opt.abmelden><en> I think they keep a reasonably high level, but it's also about the fact that I opt out of the people I know will not give me anything.
<G-vec00297-002-s058><opt.abmelden><de> Wenn Spieler solche Direktmarketing-Daten nicht erhalten möchten, können diese beim Kundendienst abbestellt werden (oder über das Mr Green Spielerkonto abmelden).
<G-vec00297-002-s058><opt.abmelden><en> If you do not wish to receive such direct marketing data, you may opt out of such service (please log in to your Mr Green account / edit profile in order to opt out).
<G-vec00369-002-s057><sign.abmelden><de> Um sich auszuloggen genügt es den Link "Abmelden" oben auf jeder beliebigen Seite anzuklicken.
<G-vec00369-002-s057><sign.abmelden><en> Logging Out To log out click the "Sign Out" link at the top of the screen from any page.
<G-vec00369-002-s058><sign.abmelden><de> Wählen Sie Ihren iMessage-Account, und klicken Sie anschließend auf "Abmelden".
<G-vec00369-002-s058><sign.abmelden><en> Select your iMessage account, then click Sign Out.
<G-vec00369-002-s059><sign.abmelden><de> Wählen Sie Auf allen anderen Computern oder Geräten abmelden.
<G-vec00369-002-s059><sign.abmelden><en> Select Sign me out of all other computers or devices.
<G-vec00369-002-s060><sign.abmelden><de> Klicken Sie im Aktivierungsfenster auf die E-Mail-Adresse des Accounts und wählen Sie Abmelden.
<G-vec00369-002-s060><sign.abmelden><en> Click on the account email address in the activation window and select Sign Out.
<G-vec00369-002-s061><sign.abmelden><de> Abmelden Sie können uns helfen, indem Sie die Informationen über die Münzen ergänzen.
<G-vec00369-002-s061><sign.abmelden><en> Sign out You can help the project contributing data you know about the coins.
<G-vec00369-002-s062><sign.abmelden><de> Beim Facebook-Konto abmelden Klicken Sie auf die Schaltfläche Facebook in Bing Bar.
<G-vec00369-002-s062><sign.abmelden><en> Sign out of your Facebook account On Bing Bar, click the Facebook Chat button .
<G-vec00369-002-s063><sign.abmelden><de> Die Einwilligung zur Nutzung meiner E-Mail-Adresse kann von meiner Seite aus durch Anklicken des Links "Abmelden" am Ende des Newsletters jederzeit widerrufen werden.
<G-vec00369-002-s063><sign.abmelden><en> This acceptance for usage of my E-Mail address can be taken back from my side at any time in the future through clicking on the "sign off" link at the end of the newsletter.
<G-vec00369-002-s064><sign.abmelden><de> Klicken Sie unten im Fenster der SurveyMonkey-App auf Abmelden.
<G-vec00369-002-s064><sign.abmelden><en> Click Sign Out from the bottom of the SurveyMonkey app window.
<G-vec00369-002-s065><sign.abmelden><de> Sie können auch Abmelden mit der Maus klicken, oder Sie drücken Alt A (für „abmelden“).
<G-vec00369-002-s065><sign.abmelden><en> You can also click Sign out with the mouse, of course, or press Alt S (for “sign out”).
<G-vec00369-002-s067><sign.abmelden><de> Die ArbeiterInnen müssen also den ganzen Tag das Headset auf dem Kopf haben oder sich immer abmelden, wenn sie mal plauschen oder aufs Klo wollen.
<G-vec00369-002-s067><sign.abmelden><en> Thus, the workers have to have the headset on their heads all day or sign off every time they want to chat or go to the loo.
<G-vec00369-002-s068><sign.abmelden><de> Abmelden Hier sehen Sie eine komplette Übersicht über den Inhalt des Warenkorbs.
<G-vec00369-002-s068><sign.abmelden><en> Login Sign Out Here you can find a full overview of the cart’s contents.
<G-vec00369-002-s069><sign.abmelden><de> Wenn Sie auf dem Computer andere Websites besuchen möchten, klicken Sie auf Abmelden, und schließen Sie nach jeder Sitzung alle Browserfenster.
<G-vec00369-002-s069><sign.abmelden><en> Even if you plan to continue using the computer to visit other Web sites, click Sign out and close all browser windows after every session.
<G-vec00369-002-s070><sign.abmelden><de> Wenn du automatisch beim PSN angemeldet wirst, sobald du dich mit deinem lokalen Benutzerkonto anmeldest, wähl [Abmelden] aus, um zur Option [Anmelden] zu gelangen.
<G-vec00369-002-s070><sign.abmelden><en> If you are automatically signed in to PSN when you select your local user, select [Sign Out] to see the [Sign In] option.
<G-vec00369-002-s071><sign.abmelden><de> Wählen Sie im nächsten Bildschirmfenster in der linken unteren Ecke die Option Abmelden aus.
<G-vec00369-002-s071><sign.abmelden><en> Select Sign out in the lower-left corner of the next screen.
<G-vec00369-002-s072><sign.abmelden><de> Klicken Sie auf Allgemein und dann auf Abmelden.
<G-vec00369-002-s072><sign.abmelden><en> Click General and then click Sign Out.
<G-vec00369-002-s073><sign.abmelden><de> Wenn Sie die Schaltfläche "Anmelden" nicht sehen, klicken Sie auf Ihr Bild oder Ihre E-Mail-Adresse und dann auf Abmelden.
<G-vec00369-002-s073><sign.abmelden><en> If you don’t see the "Sign in" button, click your photo or email address, then click Sign out.
<G-vec00369-002-s074><sign.abmelden><de> Unter „Abmelden“ sehen Sie die eMail-Adresse, mit der Sie sich bei Ihrer Kobo-Bücher-App angemeldet haben.
<G-vec00369-002-s074><sign.abmelden><en> Under 'Sign Out', you'll see the email address that's signed in to the Kobo Books app.
<G-vec00369-002-s075><sign.abmelden><de> Sie müssen das Konto auf einem Computer oder einem anderen Gerät abmelden, um mit Ihrem aktuellen Smartphone darauf zuzugreifen.
<G-vec00369-002-s075><sign.abmelden><en> You have to sign out the from account on a computer or another device to access it on your current smartphone.
<G-vec00239-003-s057><sign_up.abmelden><de> Um sich auszuloggen genügt es den Link "Abmelden" oben auf jeder beliebigen Seite anzuklicken.
<G-vec00239-003-s057><sign_up.abmelden><en> Logging Out To log out click the "Sign Out" link at the top of the screen from any page.
<G-vec00239-003-s058><sign_up.abmelden><de> Wählen Sie Ihren iMessage-Account, und klicken Sie anschließend auf "Abmelden".
<G-vec00239-003-s058><sign_up.abmelden><en> Select your iMessage account, then click Sign Out.
<G-vec00239-003-s059><sign_up.abmelden><de> Wählen Sie Auf allen anderen Computern oder Geräten abmelden.
<G-vec00239-003-s059><sign_up.abmelden><en> Select Sign me out of all other computers or devices.
<G-vec00239-003-s060><sign_up.abmelden><de> Klicken Sie im Aktivierungsfenster auf die E-Mail-Adresse des Accounts und wählen Sie Abmelden.
<G-vec00239-003-s060><sign_up.abmelden><en> Click on the account email address in the activation window and select Sign Out.
<G-vec00239-003-s061><sign_up.abmelden><de> Abmelden Sie können uns helfen, indem Sie die Informationen über die Münzen ergänzen.
<G-vec00239-003-s061><sign_up.abmelden><en> Sign out You can help the project contributing data you know about the coins.
<G-vec00239-003-s062><sign_up.abmelden><de> Beim Facebook-Konto abmelden Klicken Sie auf die Schaltfläche Facebook in Bing Bar.
<G-vec00239-003-s062><sign_up.abmelden><en> Sign out of your Facebook account On Bing Bar, click the Facebook Chat button .
<G-vec00239-003-s063><sign_up.abmelden><de> Die Einwilligung zur Nutzung meiner E-Mail-Adresse kann von meiner Seite aus durch Anklicken des Links "Abmelden" am Ende des Newsletters jederzeit widerrufen werden.
<G-vec00239-003-s063><sign_up.abmelden><en> This acceptance for usage of my E-Mail address can be taken back from my side at any time in the future through clicking on the "sign off" link at the end of the newsletter.
<G-vec00239-003-s064><sign_up.abmelden><de> Klicken Sie unten im Fenster der SurveyMonkey-App auf Abmelden.
<G-vec00239-003-s064><sign_up.abmelden><en> Click Sign Out from the bottom of the SurveyMonkey app window.
<G-vec00239-003-s065><sign_up.abmelden><de> Sie können auch Abmelden mit der Maus klicken, oder Sie drücken Alt A (für „abmelden“).
<G-vec00239-003-s065><sign_up.abmelden><en> You can also click Sign out with the mouse, of course, or press Alt S (for “sign out”).
<G-vec00239-003-s067><sign_up.abmelden><de> Die ArbeiterInnen müssen also den ganzen Tag das Headset auf dem Kopf haben oder sich immer abmelden, wenn sie mal plauschen oder aufs Klo wollen.
<G-vec00239-003-s067><sign_up.abmelden><en> Thus, the workers have to have the headset on their heads all day or sign off every time they want to chat or go to the loo.
<G-vec00239-003-s068><sign_up.abmelden><de> Abmelden Hier sehen Sie eine komplette Übersicht über den Inhalt des Warenkorbs.
<G-vec00239-003-s068><sign_up.abmelden><en> Login Sign Out Here you can find a full overview of the cart’s contents.
<G-vec00239-003-s069><sign_up.abmelden><de> Wenn Sie auf dem Computer andere Websites besuchen möchten, klicken Sie auf Abmelden, und schließen Sie nach jeder Sitzung alle Browserfenster.
<G-vec00239-003-s069><sign_up.abmelden><en> Even if you plan to continue using the computer to visit other Web sites, click Sign out and close all browser windows after every session.
<G-vec00239-003-s070><sign_up.abmelden><de> Wenn du automatisch beim PSN angemeldet wirst, sobald du dich mit deinem lokalen Benutzerkonto anmeldest, wähl [Abmelden] aus, um zur Option [Anmelden] zu gelangen.
<G-vec00239-003-s070><sign_up.abmelden><en> If you are automatically signed in to PSN when you select your local user, select [Sign Out] to see the [Sign In] option.
<G-vec00239-003-s071><sign_up.abmelden><de> Wählen Sie im nächsten Bildschirmfenster in der linken unteren Ecke die Option Abmelden aus.
<G-vec00239-003-s071><sign_up.abmelden><en> Select Sign out in the lower-left corner of the next screen.
<G-vec00239-003-s072><sign_up.abmelden><de> Klicken Sie auf Allgemein und dann auf Abmelden.
<G-vec00239-003-s072><sign_up.abmelden><en> Click General and then click Sign Out.
<G-vec00239-003-s073><sign_up.abmelden><de> Wenn Sie die Schaltfläche "Anmelden" nicht sehen, klicken Sie auf Ihr Bild oder Ihre E-Mail-Adresse und dann auf Abmelden.
<G-vec00239-003-s073><sign_up.abmelden><en> If you don’t see the "Sign in" button, click your photo or email address, then click Sign out.
<G-vec00239-003-s074><sign_up.abmelden><de> Unter „Abmelden“ sehen Sie die eMail-Adresse, mit der Sie sich bei Ihrer Kobo-Bücher-App angemeldet haben.
<G-vec00239-003-s074><sign_up.abmelden><en> Under 'Sign Out', you'll see the email address that's signed in to the Kobo Books app.
<G-vec00239-003-s075><sign_up.abmelden><de> Sie müssen das Konto auf einem Computer oder einem anderen Gerät abmelden, um mit Ihrem aktuellen Smartphone darauf zuzugreifen.
<G-vec00239-003-s075><sign_up.abmelden><en> You have to sign out the from account on a computer or another device to access it on your current smartphone.
<G-vec00507-002-s019><log.abmelden><de> Um dich nach dem Gebrauch von GotCourts als Admin korrekt abzumelden, musst du lediglich ganz oben rechts im Hauptmenü mit dem Mauszeiger über deinen Admin-Namen fahren und dort die Option „Abmelden“ auswählen.
<G-vec00507-002-s019><log.abmelden><en> Follow To correctly sign out as an admin after you have used GotCourts, you simply need to move the mouse pointer to your admin name on the main menu in the upper right corner and choose the option „Log Out“.
<G-vec00507-002-s020><log.abmelden><de> Sobald Sie Session-Cookies abmelden, werden gelöscht.
<G-vec00507-002-s020><log.abmelden><en> Once you log off session cookies are deleted.
<G-vec00507-002-s021><log.abmelden><de> Zum Schluss kann der Lehrer die Schüler einfach von den geteilten iPads abmelden und diese für die nächste Klasse vorbereiten.
<G-vec00507-002-s021><log.abmelden><en> Once students are done, the teacher can easily log them out to prepare each Shared iPad for the next class.
<G-vec00507-002-s022><log.abmelden><de> Scrollen Sie auf Ihrer Profilseite nach unten, tippen Sie auf Abmelden und versuchen Sie erneut, sich anzumelden.
<G-vec00507-002-s022><log.abmelden><en> Scroll down on your profile page and tap Log Out and try to sign in again.
<G-vec00507-002-s023><log.abmelden><de> Korrektes Beenden Beenden Sie die E-Service-Sitzung korrekt über die dafür vorgesehene Funktion/Schaltfläche "Abmelden".
<G-vec00507-002-s023><log.abmelden><en> Close down your E-Services session in a secure manner by using the relevant function/button "Log off".
<G-vec00507-002-s024><log.abmelden><de> Auto Shutdown - Fahrpläne für Ihren Computer abmelden, Standby, Hibernate, oder Herunterfahren zu einer bestimmten Zeit..
<G-vec00507-002-s024><log.abmelden><en> Auto Shutdown - Schedules your computer for log off, standby, hibernate, or shutdown at a certain time..
<G-vec00507-002-s025><log.abmelden><de> Klicke hier, um Anweisungen zum Abmelden zu erhalten.
<G-vec00507-002-s025><log.abmelden><en> Click here for instructions on how to log out
<G-vec00507-002-s026><log.abmelden><de> Wenn ein anderer Prozess die gleiche Sperre wie picadm.sys hat, können sich Benutzer nicht von der Sitzung abmelden und die Sitzung bleibt im getrennten Zustand.
<G-vec00507-002-s026><log.abmelden><en> If another process holds the same lock as picadm.sys, users cannot log off from the session and the session remains in a disconnected state.
<G-vec00507-002-s027><log.abmelden><de> Klicken Sie im Abschnitt Konten und Berechtigungen auf Alle Mitarbeiterkonten abmelden.
<G-vec00507-002-s027><log.abmelden><en> In the Accounts and permissions section, click Log out all staff accounts.
<G-vec00507-002-s028><log.abmelden><de> Wollen Sie dies verhindern müssen Sie sich vor dem Klick auf den „Pin it“-Button von Ihrem Pinterest-Account abmelden.
<G-vec00507-002-s028><log.abmelden><en> You want to avoid this you before clicking on the button “pin” it from your Pinterest account log off.
<G-vec00507-002-s029><log.abmelden><de> Wenn Sie eine grafische Arbeitsplatz-Umgebung nutzen, gibt es dort für gewöhnlich eine Menüoption " Abmelden", die es Ihnen erlaubt, das System herunterzufahren (oder neu zu starten).
<G-vec00507-002-s029><log.abmelden><en> If you run a desktop environment, there is usually an option to "log out" available from the application menu that allows you to shutdown (or reboot) the system.
<G-vec00507-002-s030><log.abmelden><de> Wenn Sie eine grafische Arbeitsplatz-Umgebung nutzen, gibt es dort für gewöhnlich eine Menüoption „Abmelden“, die es Ihnen erlaubt, das System herunterzufahren (oder neu zu starten).
<G-vec00507-002-s030><log.abmelden><en> If you run a desktop environment, there is usually an option to “log out” available from the application menu that allows you to shutdown (or reboot) the system.
<G-vec00507-002-s031><log.abmelden><de> Wenn Sie die Sitzung beenden und sich vom Onlinebanking abmelden, sollte die Benachrichtigung oben auf dem Bildschirm automatisch geschlossen werden.
<G-vec00507-002-s031><log.abmelden><en> When you log out of your online banking session, the notification at the top of your computer screen should close automatically.
<G-vec00507-002-s032><log.abmelden><de> Wenn Sie einen anderen Benutzer von einer Sitzung abmelden möchten, müssen Sie über die Berechtigung Vollzugriff verfügen.
<G-vec00507-002-s032><log.abmelden><en> To log off another user from a session, you must have Full Control permission.
<G-vec00507-002-s033><log.abmelden><de> Klicken Sie zum Abmelden vom System auf Start, den Pfeil neben der Schaltflache Herunterfahren und dann auf Abmelden.
<G-vec00507-002-s033><log.abmelden><en> To log off your system, click Start, the arrow next to the Lock button, and Log Off.
<G-vec00507-002-s035><log.abmelden><de> Wenn Sie die Moodle Mobile App bereits benutzen, müssen Sie sich bei allen Websites abmelden, die das Plugin Moodle Mobile - Zusatzfeatures neu benutzen.
<G-vec00507-002-s035><log.abmelden><en> If you are currently using the Moodle Mobile app, you will need to log out of all your sites in order for the app to detect the new service.
<G-vec00507-002-s036><log.abmelden><de> Power Apps - Herunterfahren, Abmelden, und das System neu starten.
<G-vec00507-002-s036><log.abmelden><en> Power Apps - Shut down, log off, and restart your system.
<G-vec00507-002-s037><log.abmelden><de> Den Zugriff auf dein altes Konto kannst du durch folgende Schritte wiederherstellen: Tippe die Option „Abmelden“ in Menü-Optionen an, dann klicke den Button „Benutzerwechsel“ in der unteren linken Ende des Bildschirms an und wähle schließlich die mit deinem Konto verbundene Anmeldungsmethode.
<G-vec00507-002-s037><log.abmelden><en> You can regain access to your old account by tapping Log Out from the Options Menu, then the Change User button in the lower left corner of the screen, and selecting the login method associated with your account.
<G-vec00942-002-s022><resign.abmelden><de> Wir speichern die personenbezogenen Daten unserer Newsletter-Abonnenten oder Personen, die dem Erhalt unserer Marketinginhalte zugestimmt haben, bis sich diese abmelden.
<G-vec00942-002-s022><resign.abmelden><en> We’ll store the Personal Data of our newsletter subscribers or persons who have agreed to receive marketing content from us until they resign.
<G-vec00942-002-s023><resign.abmelden><de> Sie können sich jederzeit wieder abmelden.
<G-vec00942-002-s023><resign.abmelden><en> You can resign from your newsletter subscription at any time.
