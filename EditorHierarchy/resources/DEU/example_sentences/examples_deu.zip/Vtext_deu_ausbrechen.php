<G-vec00097-001-s011><erupt.ausbrechen><de> All die Pyrotechnik am Fourth of July zusammengenommen kann es nicht mit der explosiven Kraft aufnehmen, mit der diese Esten ausbrechen, wenn sie einstimmig singen.
<G-vec00097-001-s011><erupt.ausbrechen><en> All the pyrotechnics on The Fourth of July put together can't match the explosive power these Estonians erupt with when they sing in unison.
<G-vec00097-001-s015><erupt.ausbrechen><de> Der Vater sagt: „All eure Krankheiten werden ausbrechen.
<G-vec00097-001-s015><erupt.ausbrechen><en> The Father says: All your sickness will erupt.
<G-vec00097-001-s016><erupt.ausbrechen><de> Die Empörung gegen Zia ul-Huq und gleichzeitig die Symphatiebekundung für Chomeini könnten aber in Pakistan auch ohne die Intervention der Sowjets ausbrechen.
<G-vec00097-001-s016><erupt.ausbrechen><en> However, in Pakistan the anger against Zia-ul-Haq, accompanied by sympathy for Khomeini, might erupt even without the intervention of the Soviets.
<G-vec00097-001-s017><erupt.ausbrechen><de> Sakurajima: Yunohira LookoutDer Aufstieg zum Sakurajimagipfel ist streng verboten, weil der Vulkan jederzeit ausbrechen kann.
<G-vec00097-001-s017><erupt.ausbrechen><en> Sakurajima: Yunohira LookoutThe ascent to Sakurajima top is strictly forbidden, since the volcano may always erupt with strong blasts.
<G-vec00097-001-s018><erupt.ausbrechen><de> 4., Januar 2010 zwei neue Öffnungen, die später in eine Spalte zusammengeführt entlang der tektonischen Trend des Gipfelbereichs eröffnete seine westlichen Krater ausgerichtet und damit begonnen, große Mengen an Schwefeldioxid und gelegentliche Felsmaterial Asche ausbrechen.
<G-vec00097-001-s018><erupt.ausbrechen><en> On Jan 4, 2010, two new vents that later merged into a fissure aligned along the tectonic trend of the summit area opened in its western crater and started to erupt large amounts of sulphur dioxide gas and occasional lithic ash.
<G-vec00097-001-s019><erupt.ausbrechen><de> Allerdings sollten die Zähne richtig und vollständig ausbrechen.
<G-vec00097-001-s019><erupt.ausbrechen><en> However, the teeth should erupt properly and fully.
<G-vec00097-001-s020><erupt.ausbrechen><de> Angst kommt von Enge und wirkt wie ein explosiver Bodensatz, der jederzeit als Wut, Haß, Eifersucht, Sadismus und nackte Gewalt ausbrechen kann.
<G-vec00097-001-s020><erupt.ausbrechen><en> Fear comes from constriction and acts like an explosive residue which can erupt at any time as anger, hatred, jealousy, sadism and unconcealed violence.
<G-vec00097-001-s021><erupt.ausbrechen><de> Nord-Amerika zieht diagonal, eine Situation, die bald ausbrechen wird, was Beben und sinkenden Boden und Desaster in fast jedem Unionsstaat (US-Bundesstaat) kreiert.
<G-vec00097-001-s021><erupt.ausbrechen><en> N America pulls diagonally, a situation that will soon erupt creating quakes and sinking ground and disaster in almost every State of the Union.
<G-vec00097-001-s022><erupt.ausbrechen><de> Der erste Zahn Ihres Babys kann als einer ausbrechen oder mit einem anderen gepaart werden.
<G-vec00097-001-s022><erupt.ausbrechen><en> The first tooth of your baby can erupt as one, or paired with another.
<G-vec00097-001-s023><erupt.ausbrechen><de> Wir dürfen nicht passiv warten, bis Krisen ausbrechen, sondern müssen die Ursachen für politische Gewalt bei den Wurzeln angehen.
<G-vec00097-001-s023><erupt.ausbrechen><en> We must not wait passively for crises to erupt, but tackle the root causes of political violence.
<G-vec00097-001-s024><erupt.ausbrechen><de> Dabei dient Flamenco ihnen als Ausgangspunkt, von dem sie in Jazz, Fusion und Weltmusik ausbrechen.
<G-vec00097-001-s024><erupt.ausbrechen><en> Flamenco serves as their base, from which they erupt into jazz, fusion and world music.
<G-vec00097-001-s025><erupt.ausbrechen><de> Wenn wir erst einmal CMEs verstanden haben, können wir anfangen, Vorhersagen darüber zu treffen, welche magnetischen Strukturen ausbrechen und welche schließlich den größten Effekt auf der Erde hervorrufen.
<G-vec00097-001-s025><erupt.ausbrechen><en> Once we understand why CMEs occur, we can start to predict which magnetic structures will erupt and eventually which ones will have the greatest effect on Earth.
<G-vec00097-001-s026><erupt.ausbrechen><de> Wir können nicht genau wissen, wo und in welcher Form die neuen sozialen Konflikte ausbrechen werden, ob sie sich als dauerhaft erweisen und verallgemeinern werden.
<G-vec00097-001-s026><erupt.ausbrechen><en> We can't know exactly where these new social conflicts will erupt, or in what form; whether they will take hold and become generalised.
<G-vec00097-001-s027><erupt.ausbrechen><de> Es kann also ein Cialis Cost 20mg und ein Öl vorher ausbrechen und die Ergebnisse ablenken.
<G-vec00097-001-s027><erupt.ausbrechen><en> So it may erupt a Cialis Cost 20mg and a oil before and distract out the results.
<G-vec00097-001-s028><erupt.ausbrechen><de> Die böse Meere ausbrechen in diesem gewaltigen Sturm Blitze.
<G-vec00097-001-s028><erupt.ausbrechen><en> The angry seas erupt in this formidable Lightning Storm.
<G-vec00097-001-s029><erupt.ausbrechen><de> Weisheitszahn fängt an, ausbrechen oder am Ende der Adoleszenz, oder nach 20 Jahren.Zu diesem Zeitpunkt erfährt eine Person, die Schmerzempfindung, die unerträglich werden kann.Also nicht wider Besuch beim Zahnarzt - finden Sie es bei den erst...
<G-vec00097-001-s029><erupt.ausbrechen><en> wisdom tooth begins to erupt or at the end of adolescence, or after 20 years.At this time a person experiences the sensation of pain, which can become unbearable.So do not resist visiting the dentist - refer to it at the first sign of pain.An...
<G-vec00097-001-s030><erupt.ausbrechen><de> Bagana weiterhin kleine Asche Explosionen von Zeit zu Zeit ausbrechen produzieren Asche Federn, die 2.4-3 km Höhe steigen und werden von der Darwin-VAAC überwacht.
<G-vec00097-001-s030><erupt.ausbrechen><en> Bagana continues to erupt small ash explosions from time to time, producing ash plumes that rise to 2.4-3 km altitude and are monitored by the Darwin VAAC.
<G-vec00097-001-s031><erupt.ausbrechen><de> Zwei dieser Kegel, Mawenzi und Shira, sind nicht mehr aktiv und gelten nach wissenschaftlichen Erkenntnissen als erloschen, während der höchste, Kibo, inaktiv ist und noch einmal ausbrechen könnte.
<G-vec00097-001-s031><erupt.ausbrechen><en> Two of these cones, the Mawenzi and Shira, are no longer active and are scientifically proven to be extinct, while the highest one, Kibo, is dormant and might erupt once.
<G-vec00097-001-s032><erupt.ausbrechen><de> Akne ist eine infektiöse entzündliche Hauterkrankung, die zuerst während Teenager ausbricht und kann weiterhin jahrelang sogar im Erwachsenenalter ausbrechen.
<G-vec00097-001-s032><erupt.ausbrechen><en> Acne is an infectious inflammatory skin condition that first erupts during teenage and may continue to erupt for years even during adulthood.
<G-vec00097-001-s033><erupt.ausbrechen><de> Diese Seite zeigt heisse Quellen, die (normalerweise) nicht ausbrechen.
<G-vec00097-001-s033><erupt.ausbrechen><en> This page is about the beauty of hot springs which do not (usually) erupt.
<G-vec00097-001-s034><erupt.ausbrechen><de> Niemand kann in die Zukunft sehen und vorhersagen, wann und wo welche Krise ausbricht.
<G-vec00097-001-s034><erupt.ausbrechen><en> No one can see into the future; no one can predict what crises will erupt when and where.
<G-vec00097-001-s035><erupt.ausbrechen><de> Je nachdem, wie lange wir darauf warten mussten, dass der Old Faithful ausbricht, ergibt sich vielleicht die Möglichkeit zu einem kurzen Rundgang um das Upper Geyser Basin.
<G-vec00097-001-s035><erupt.ausbrechen><en> Depending on how long we had to wait for Old Faithful to erupt, there may possibly be an opportunity for a short walk around the Upper Geyser Basin.
<G-vec00097-001-s036><erupt.ausbrechen><de> Das Establishment weiß, er ist da, aber sie fürchten das Chaos, das ausbricht, wenn es die Massen erfahren.
<G-vec00097-001-s036><erupt.ausbrechen><en> The establishment knows it is there but fears the chaos that will erupt if the populace knows.
<G-vec00097-001-s041><erupt.ausbrechen><de> Die Leidenschaft, die endlich ausgebrochen war.
<G-vec00097-001-s041><erupt.ausbrechen><en> The passion that was finally able to erupt.
<G-vec00097-001-s042><erupt.ausbrechen><de> In diesem Straßendschungel brodelt ein Vulkan, der kurz davor ist auszubrechen.
<G-vec00097-001-s042><erupt.ausbrechen><en> In this street jungle a volcano is seething that is about to erupt any moment.
<G-vec00097-001-s043><erupt.ausbrechen><de> Nur die Hitlerschen Narren können nicht begreifen, dass nicht nur das europäische Hinterland, sondern auch das deutsche Hinterland der deutschen Truppen einen Vulkan darstellt, bereit auszubrechen und die Hitlerschen Abenteurer zu begraben.
<G-vec00097-001-s043><erupt.ausbrechen><en> Only the Hitlerite fools fail to understand that not only the European rear but also the German rear of the German troops represents a volcano which is ready to erupt and overwhelm the Hitlerite adventurers.
<G-vec00097-001-s044><erupt.ausbrechen><de> Seine Software macht coole Grafiken und wenn Unterbrechungen auszubrechen, den letzten Spin ist abgeschlossen, und Sie können ganz einfach überprüfen die Geschichte.
<G-vec00097-001-s044><erupt.ausbrechen><en> Its software renders cool graphics and when disconnections erupt, the last spin is completed and you can easily check the history.
<G-vec00097-001-s045><erupt.ausbrechen><de> Plötzlich schien die Welt auszubrechen, mit einem enormen Getöse und einem strahlenden Lichtblitz, so hell wie die Sonne.
<G-vec00097-001-s045><erupt.ausbrechen><en> Suddenly, the world seemed to erupt with a tremendous roar and a brilliant flash of light, bright as the sun.
<G-vec00097-001-s049><erupt.ausbrechen><de> Kontroversen über Halal-Essen brechen in Kantinen aus, über Gebete auf öffentlichen Straßen, während Karikaturen regelmäßig den Islam verspotten.
<G-vec00097-001-s049><erupt.ausbrechen><en> Disputes erupt over Halal foods in cafeterias, prayers in the street, while cartoons regularly lampoon Islam.
<G-vec00097-001-s050><erupt.ausbrechen><de> Auf der Erde brechen immer noch Vulkane aus und es ist selbstverständlich, dass ähnliche Aktivitäten auf dem Mond erwartet werden.
<G-vec00097-001-s050><erupt.ausbrechen><en> Volcanoes still erupt on the Earth, and it is natural to expect similar activity on the moon.
<G-vec00097-001-s051><erupt.ausbrechen><de> Wo Affen Ihre Balkonsäulen klettern, als ob sie Bäume waren, nisten sich in den Ecken der Korridore, als wären sie Klippen, Granitfelsen brechen in die gewundenen weißen Gehwege aus.
<G-vec00097-001-s051><erupt.ausbrechen><en> Where monkeys climb your balcony pillars as if they were trees, swifts nest in the corners of corridors as if they were cliffs, granite crags erupt into the sinuous white walkways.
<G-vec00097-001-s052><erupt.ausbrechen><de> Die beiden Vulkane Katla und Hekla brechen aus und gefährden den Erfolg der Reise.
<G-vec00097-001-s052><erupt.ausbrechen><en> When the twin volcanos Katla and Hekla erupt, the success of the voyage hangs in the balance.
<G-vec00097-001-s053><erupt.ausbrechen><de> Blasen brechen aus und hinterlassen an ihrer Stelle Erosion.
<G-vec00097-001-s053><erupt.ausbrechen><en> Bubbles erupt, leaving in their place erosion.
<G-vec00097-001-s067><erupt.ausbrechen><de> "Der Zweck der ""Black History"" ist die Weiße in ihren historischen Schuld zu erinnern und von Natur aus verhaßt Verhalten droht erneut ausbrechen zu jeder Zeit."
<G-vec00097-001-s067><erupt.ausbrechen><en> "The purpose of ""black history"" is to remind whites of their historical guilt and their innately hateful behavior threatening to re-erupt at any time."
<G-vec00097-001-s082><erupt.ausbrechen><de> Sie können nicht anders, sie müssen immer wieder in die Anbetung des heiligen Gottes ausbrechen.
<G-vec00097-001-s082><erupt.ausbrechen><en> They have no choice but to erupt again and again with worshiping of the holy God.
<G-vec00097-001-s092><erupt.ausbrechen><de> Die berechtigte Wut der Tamilen über die seit Jahrzehnten fest verwurzelte Diskriminierung wird unweigerlich in neuen Formen wieder ausbrechen.
<G-vec00097-001-s092><erupt.ausbrechen><en> The legitimate grievances and anger felt by Tamils over decades of entrenched discrimination will inevitably erupt in new forms.
<G-vec00218-002-s095><break.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00218-002-s095><break.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00218-002-s096><break.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00218-002-s096><break.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00218-002-s097><break.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00218-002-s097><break.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00218-002-s098><break.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00218-002-s098><break.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00218-002-s099><break.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00218-002-s099><break.ausbrechen><en> He could not break free
<G-vec00218-002-s100><break.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00218-002-s100><break.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00218-002-s101><break.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00218-002-s101><break.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00218-002-s102><break.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00218-002-s102><break.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00218-002-s103><break.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00218-002-s103><break.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00218-002-s104><break.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00218-002-s104><break.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00218-002-s105><break.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00218-002-s105><break.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00218-002-s106><break.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00218-002-s106><break.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00218-002-s107><break.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00218-002-s107><break.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00218-002-s108><break.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00218-002-s108><break.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00218-002-s109><break.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00218-002-s109><break.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00218-002-s110><break.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00218-002-s110><break.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00218-002-s111><break.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00218-002-s111><break.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00218-002-s112><break.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00218-002-s112><break.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00218-002-s113><break.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00218-002-s113><break.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00296-003-s095><break_down.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00296-003-s095><break_down.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00296-003-s096><break_down.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00296-003-s096><break_down.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00296-003-s097><break_down.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00296-003-s097><break_down.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00296-003-s098><break_down.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00296-003-s098><break_down.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00296-003-s099><break_down.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00296-003-s099><break_down.ausbrechen><en> He could not break free
<G-vec00296-003-s100><break_down.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00296-003-s100><break_down.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00296-003-s101><break_down.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00296-003-s101><break_down.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00296-003-s102><break_down.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00296-003-s102><break_down.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00296-003-s103><break_down.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00296-003-s103><break_down.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00296-003-s104><break_down.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00296-003-s104><break_down.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00296-003-s105><break_down.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00296-003-s105><break_down.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00296-003-s106><break_down.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00296-003-s106><break_down.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00296-003-s107><break_down.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00296-003-s107><break_down.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00296-003-s108><break_down.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00296-003-s108><break_down.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00296-003-s109><break_down.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00296-003-s109><break_down.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00296-003-s110><break_down.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00296-003-s110><break_down.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00296-003-s111><break_down.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00296-003-s111><break_down.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00296-003-s112><break_down.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00296-003-s112><break_down.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00296-003-s113><break_down.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00296-003-s113><break_down.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00599-002-s095><break_up.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00599-002-s095><break_up.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00599-002-s096><break_up.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00599-002-s096><break_up.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00599-002-s097><break_up.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00599-002-s097><break_up.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00599-002-s098><break_up.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00599-002-s098><break_up.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00599-002-s099><break_up.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00599-002-s099><break_up.ausbrechen><en> He could not break free
<G-vec00599-002-s100><break_up.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00599-002-s100><break_up.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00599-002-s101><break_up.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00599-002-s101><break_up.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00599-002-s102><break_up.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00599-002-s102><break_up.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00599-002-s103><break_up.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00599-002-s103><break_up.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00599-002-s104><break_up.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00599-002-s104><break_up.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00599-002-s105><break_up.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00599-002-s105><break_up.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00599-002-s106><break_up.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00599-002-s106><break_up.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00599-002-s107><break_up.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00599-002-s107><break_up.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00599-002-s108><break_up.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00599-002-s108><break_up.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00599-002-s109><break_up.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00599-002-s109><break_up.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00599-002-s110><break_up.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00599-002-s110><break_up.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00599-002-s111><break_up.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00599-002-s111><break_up.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00599-002-s112><break_up.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00599-002-s112><break_up.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00599-002-s113><break_up.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00599-002-s113><break_up.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00018-002-s024><erupt.ausbrechen><de> Sie versuchen herauszufinden, welche Zähne besonders schmerzhaft ausbrechen können, und sie versuchen, sich möglichst auf das zukünftige Ereignis vorzubereiten.
<G-vec00018-002-s024><erupt.ausbrechen><en> They are trying to find out exactly which teeth can erupt especially painful, and they are trying to prepare as much as possible for the future event.
<G-vec00018-002-s026><erupt.ausbrechen><de> Von Quetzal weiß ich, dass die Vulkane Vesuv, Ätna und Stromboli in kommender Zeit sehr aktiv werden sollen, wobei der Vesuv dann ausbrechen soll, wenn der Dritte Weltkrieg kommt.
<G-vec00018-002-s026><erupt.ausbrechen><en> Billy: I know from Quetzal that the volcanoes Vesuvius, Etna, and Stromboli should become very active in the coming time, and Vesuvius should erupt when the Third World War comes.
<G-vec00018-002-s027><erupt.ausbrechen><de> Besonders aufregend wird es, wenn mehrere Vulkane auf deinem Screen ausbrechen.
<G-vec00018-002-s027><erupt.ausbrechen><en> The excitement will increase further if several volcanos erupt on the screen.
<G-vec00018-002-s028><erupt.ausbrechen><de> Wir sagen euch nochmals, was wir euch zuvor gesagt haben: Auch Chile ist damit noch nicht durch, denn es gibt dort einen oder zwei Vulkane, die wirklich ausbrechen möchten.
<G-vec00018-002-s028><erupt.ausbrechen><en> We again say to you what we have said before: Chile has not seen the end of it either, for there's a volcano or two there that really want to erupt.
<G-vec00018-002-s029><erupt.ausbrechen><de> Wir hatten zum Beispiel einen Workshop zu Geologie – wie man einen Vulkan bauen und ausbrechen lassen kann – und einen zu Astronomie, den die Kinder sehr faszinierend fanden.
<G-vec00018-002-s029><erupt.ausbrechen><en> For example, we had a workshop on biology – how to build a volcano and make it erupt – and one on astronomy that the kids found fascinating.
<G-vec00018-002-s031><erupt.ausbrechen><de> In den letzten Tagen mussten bewaffnete Auseinandersetzungen ausbrechen, einerseits wegen der unerbittlichen und verstärkten Offensiven der AFP, auf der anderen Seite, wegen der Anstrengungen der NPA die Interessen des Volkes aktiv zu verteidigen.
<G-vec00018-002-s031><erupt.ausbrechen><en> Armed skirmishes over the past days were bound to erupt in the face of relentless and heightened AFP offensives, on the one hand, and efforts of the NPA to actively defend the people’s interests, on the other.
<G-vec00018-002-s032><erupt.ausbrechen><de> Machen Sie einen Spaziergang rund um die Pools und sehen Sie den mächtigen Geysir Strokkur ausbrechen und alle paar Minuten hoch in die Luft schießen.
<G-vec00018-002-s032><erupt.ausbrechen><en> Walk around the pools and see the mighty Strokkur geyser erupt, shooting high into the air every few minutes.
<G-vec00018-002-s033><erupt.ausbrechen><de> Ihr Interesse an den Schattenseiten menschlichen Handelns ist dadurch bedingt, daß die Gesellschaft antisoziale oder "böse" menschliche Impulse und Verhaltensweisen unterdrückt, die eines Tages bei manchen Menschen um so heftiger ausbrechen.
<G-vec00018-002-s033><erupt.ausbrechen><en> Their interest in the dark sides of human behaviour can be put down to the supression by society of anti-social and "evil" human impulses and behaviour, which then in some human beings erupt even more violently.
<G-vec00018-002-s034><erupt.ausbrechen><de> Nur die in sich selbst verliebten Hitlerschen Narren übersehen, dass die "Neuordnung in Europa" und die berüchtigte "Grundlage" dieser Ordnung einen Vulkan darstellt, der jeden Augenblick ausbrechen und das imperialistische deutsche Kartenhaus begraben kann.
<G-vec00018-002-s034><erupt.ausbrechen><en> Only the self-admiring Hitlerite fools fail to see that the "new order" in Europe and the infamous "basis" of this order represent a volcano which is ready to erupt at any moment and overwhelm the German imperialist house of cards.
<G-vec00018-002-s036><erupt.ausbrechen><de> Solange dies anhält, wird er nicht ausbrechen.
<G-vec00018-002-s036><erupt.ausbrechen><en> As long as this is sustained, it won’t erupt.
<G-vec00018-002-s038><erupt.ausbrechen><de> Die Killer-Sporen wird ein Ende der Welt setzen, wenn Sie es ihnen ermöglichen, ausbrechen.
<G-vec00018-002-s038><erupt.ausbrechen><en> The killer spores will put an end to the world if you allow them to erupt.
<G-vec00018-002-s039><erupt.ausbrechen><de> Beobachten Sie die Schwänze der sexy Hula-Girls aus Hawaii, die mit Sperma ausbrechen wie ein Vulkan.
<G-vec00018-002-s039><erupt.ausbrechen><en> Watch the dicks of sexy hula girls from Hawaii erupt with cum like a volcano.
<G-vec00018-002-s040><erupt.ausbrechen><de> Mit diesen politischen Entwicklungen und früheren historischen Tendenzen scheint ein neuer Putschversuch wie es sein muss eine Unvermeidbarkeit, die darauf wartet ausbrechen zu können.
<G-vec00018-002-s040><erupt.ausbrechen><en> With these political developments and previous historical tendencies, a new coup attempt seems like it must have been an inevitability waiting to erupt.
<G-vec00018-002-s043><erupt.ausbrechen><de> Beobachten Sie, wie Strokkur alle paar Minuten bis zu 30 Meter hoch ausbricht.
<G-vec00018-002-s043><erupt.ausbrechen><en> Watch Strokkur erupt every few minutes up to 30 meters high.
<G-vec00018-002-s050><erupt.ausbrechen><de> Einige Berge entstehen dadurch, dass Vulkane immer wieder ausbrechen, und andere, wenn zwei tektonische Platten der Erdkruste zusammenstoßen.
<G-vec00018-002-s050><erupt.ausbrechen><en> Some mountains form when volcanoes erupt over and over again, others when two tectonic plates of the Earth’s crust collide.
<G-vec00018-002-s067><erupt.ausbrechen><de> In Starhawk tauchst du mitten hinein in spektakuläre Science-Fiction-Kämpfe, während grelle Explosionen und Laserfeuer rings um die gigantischen Schiffe und Raumstationen ausbrechen.
<G-vec00018-002-s067><erupt.ausbrechen><en> Starhawk immerses you in its spectacular sci-fi combat as dazzling explosions and laser fire erupt around the gigantic ships and space bases.
<G-vec00018-002-s050><flare_up.ausbrechen><de> Wenn nicht auch die Ursachen eines Konfliktes beseitigt werden, kann er immer wieder ausbrechen.
<G-vec00018-002-s050><flare_up.ausbrechen><en> Unless the underlying causes of the conflict are eliminated, violence can flare up again at any time.
<G-vec00681-002-s095><break_off.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00681-002-s095><break_off.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00681-002-s096><break_off.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00681-002-s096><break_off.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00681-002-s097><break_off.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00681-002-s097><break_off.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00681-002-s098><break_off.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00681-002-s098><break_off.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00681-002-s099><break_off.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00681-002-s099><break_off.ausbrechen><en> He could not break free
<G-vec00681-002-s100><break_off.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00681-002-s100><break_off.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00681-002-s101><break_off.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00681-002-s101><break_off.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00681-002-s102><break_off.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00681-002-s102><break_off.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00681-002-s103><break_off.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00681-002-s103><break_off.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00681-002-s104><break_off.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00681-002-s104><break_off.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00681-002-s105><break_off.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00681-002-s105><break_off.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00681-002-s106><break_off.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00681-002-s106><break_off.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00681-002-s107><break_off.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00681-002-s107><break_off.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00681-002-s108><break_off.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00681-002-s108><break_off.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00681-002-s109><break_off.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00681-002-s109><break_off.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00681-002-s110><break_off.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00681-002-s110><break_off.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00681-002-s111><break_off.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00681-002-s111><break_off.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00681-002-s112><break_off.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00681-002-s112><break_off.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00681-002-s113><break_off.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00681-002-s113><break_off.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00864-002-s087><panic.ausbrechen><de> So lag ich da und versuchte nicht in Panik auszubrechen.
<G-vec00864-002-s087><panic.ausbrechen><en> I was just lying there trying not to panic.
<G-vec00864-002-s088><panic.ausbrechen><de> Während ich Lolidragon weiter und weiter wegrennen sah, begann ich in Panik auszubrechen.
<G-vec00864-002-s088><panic.ausbrechen><en> As I watched Lolidragon run further and further away, I began to panic.
<G-vec00864-002-s089><panic.ausbrechen><de> Die Dorfbewohner beginnen in Panik auszubrechen und die Wachen haben einen sehr entschlossenen Ausdruck in ihren Augen, als sie sich ihren zwei Gefangenen nähern.
<G-vec00864-002-s089><panic.ausbrechen><en> The villagers are beginning to panic and the guards have a desperate look in their eyes as they close in on their two prisoners.
<G-vec00867-002-s101><burst.ausbrechen><de> Die Dämmerung brach Finish ist eine intelligente Ästhetik für dieses high-Performance-Paket.
<G-vec00867-002-s101><burst.ausbrechen><en> The Twilight Burst finish is a smart aesthetic for this high performance pack.
<G-vec00867-002-s102><burst.ausbrechen><de> Als ich es das erste Mal hörte, brach es sofort in Tränen aus.
<G-vec00867-002-s102><burst.ausbrechen><en> When I first heard it, immediately burst into tears.
<G-vec00867-002-s103><burst.ausbrechen><de> Eine erwachsene, ernsthafte Frau, ein führender Arbeiter, brach einfach in Tränen aus und schluchzte wie ein Kind.
<G-vec00867-002-s103><burst.ausbrechen><en> An adult serious woman, a leading worker, simply burst into tears and sobbed like a child.
<G-vec00867-002-s104><burst.ausbrechen><de> Läßt er dich jetzt besser schlafen?« Ciaire brach fast in Tränen aus.
<G-vec00867-002-s104><burst.ausbrechen><en> Sleeping better for you now?” Claire almost burst into tears.
<G-vec00867-002-s105><burst.ausbrechen><de> Sky Raketen brach über den Times Square.
<G-vec00867-002-s105><burst.ausbrechen><en> Sky rockets burst over Times Square.
<G-vec00867-002-s106><burst.ausbrechen><de> Cecil Gant brach während des Zweiten Weltkriegs mit dem, was der Autor Arnold Shaw als den ersten R&B-Hit betrachtet, I Wonder, die Geschichte eines einsamen Soldaten, der sein Mädchen zu Hause vermisst.
<G-vec00867-002-s106><burst.ausbrechen><en> Cecil Gant burst upon the scene during World War II with what author Arnold Shaw considers the first R&B hit, I Wonder, the story of a lonely soldier missing his girl back home.
<G-vec00867-002-s107><burst.ausbrechen><de> Sie brach durch die Glastür in den Regen und schaute auf den Parkplatz.
<G-vec00867-002-s107><burst.ausbrechen><en> She burst through the glass doors into the rain, looking around the parking lot.
<G-vec00867-002-s108><burst.ausbrechen><de> Als dieses gesagt war, schluchzte Yodhajiva und brach in Tränen aus.
<G-vec00867-002-s108><burst.ausbrechen><en> When this was said, Yodhajiva the headman sobbed & burst into tears.
<G-vec00867-002-s109><burst.ausbrechen><de> Die beiden erblickten sich einander mit starren Augen, dann brach der erste Militär in häßliches Lachen aus aber ließ Simon frei und ging hin, um Platz zu nehmen.
<G-vec00867-002-s109><burst.ausbrechen><en> The two looked at each other with hard eyes, then the first soldier burst in laughter, a nasty laughter, and let Simon go, going to sit to a table.
<G-vec00867-002-s110><burst.ausbrechen><de> Sigarda brach – von Blut und Eingeweiden bedeckt wie bei einer grausigen Geburt – aus der Brust ihrer Schwestern heraus und stürzte auf den Platz unter ihnen.
<G-vec00867-002-s110><burst.ausbrechen><en> Sigarda burst out of her sisters' chest smeared with blood and ichor, like an abhorrent birth, and crashed to the ground in the plaza below.
<G-vec00867-002-s111><burst.ausbrechen><de> Aus der Spitze seines Zauberstabs brach die silberne Hirschkuh hervor: Sie landete auf dem Boden des Büros, sprang mit einem Satz durch den Raum und rauschte aus dem Fenster.
<G-vec00867-002-s111><burst.ausbrechen><en> From the tip of his wand burst the silver doe: she landed on the office floor, bounded across the office and soared out of the window.
<G-vec00867-002-s112><burst.ausbrechen><de> “Ich kann es nicht schaden, sie-s-ee!” – Plangent Schrei brach aus meiner Kehle, und ich fühlte mich völlig erschöpft.
<G-vec00867-002-s112><burst.ausbrechen><en> “I can not hurt-she-s-ee!” – Plangent cry burst from my throat, and I felt complete exhaustion.
<G-vec00867-002-s113><burst.ausbrechen><de> Dann brach die neue Wirklichkeit aus, das Paradies öffnete seine Pforten, und alles kam ganz anders.
<G-vec00867-002-s113><burst.ausbrechen><en> Then the new reality burst forth; paradise opened its gates, and everything was different than expected.
<G-vec00867-002-s114><burst.ausbrechen><de> Baard schlotterten die Knie, er setzte sich an das Fußende des Bettes und brach in heftiges Weinen aus.
<G-vec00867-002-s114><burst.ausbrechen><en> Baard trembled in all his limbs, he sat down on the bed foot, and burst into tears.
<G-vec00867-002-s115><burst.ausbrechen><de> Ich brach fast in Tränen aus, als ich ihn näher und näher kommen sah ….Er ist ein so schöner Bär.
<G-vec00867-002-s115><burst.ausbrechen><en> I almost burst into tears when I saw him coming closer and closer….He’s such a beautiful bear.
<G-vec00867-002-s116><burst.ausbrechen><de> Gebäude wurden zerstört, und ein Damm brach zusammen und überflutete die Stadt weiter.
<G-vec00867-002-s116><burst.ausbrechen><en> Buildings were destroyed, and a dam burst, further inundating the town.
<G-vec00867-002-s117><burst.ausbrechen><de> Das am ganzen Körper mit Hells Angels und Schlangen Tattoos tätowierte Unikat brach in lautes Lachen aus, als es den Schriftzug auf Brians Motorradjacke sah.
<G-vec00867-002-s117><burst.ausbrechen><en> The unique copy, who was tattooed all over his body with Hells Angels and snake images burst out laughing when he saw the writing on Brian’s motorcycle jacket.
<G-vec00867-002-s118><burst.ausbrechen><de> Tante Petunia brach in Tränen aus und drückte ihren Sohn an die Brust, während Harry unter den Tisch abtauchte, damit sie sein Lachen nicht sehen konnten.
<G-vec00867-002-s118><burst.ausbrechen><en> Aunt Petunia burst into tears and hugged her son, while Harry ducked under the table so they wouldn’t see him laughing.
<G-vec00867-002-s119><burst.ausbrechen><de> Als ich Dan von Mark 7 beim letzten Videotelefonat mein Patent gezeigt habe, brach er in Tränen aus und zeigte es sofort seinen Konstrukteuren.
<G-vec00867-002-s119><burst.ausbrechen><en> — When I showed my patent to Mark 7 on the last video call, he burst into tears and immediately showed it to his designers.
<G-vec00867-002-s120><burst.ausbrechen><de> Wir brachen in Tränen aus.
<G-vec00867-002-s120><burst.ausbrechen><en> We just burst into tears.
<G-vec00867-002-s121><burst.ausbrechen><de> Ihre Freundinnen brachen in schallendes Gelächter aus, denn statt des üblichen Glockenspiels hörte sie sich selbst, ihr Stöhnen von wenigen Augenblicken zuvor, ihr Betteln und Winseln, als sie nebenan gefickt wurde.
<G-vec00867-002-s121><burst.ausbrechen><en> Her friends burst into raucous laughter since it didn’t play the usual bell sound but her own moaning from moments ago, her begging and whimpering while she was getting fucked next door.
<G-vec00867-002-s122><burst.ausbrechen><de> Wilde Wölfe brachen durchs Tor.
<G-vec00867-002-s122><burst.ausbrechen><en> Wild wolves burst through the gate.
<G-vec00867-002-s123><burst.ausbrechen><de> Mapuhi verschaffte seinen Gefühlen Luft, indem er ihr kräftig eins aufs Ohr gab, so dass sie zurücktaumelte; Tefara und Nauri brachen in Tränen aus und machten ihm weiter Vorhaltungen, wie Frauen eben so sind.
<G-vec00867-002-s123><burst.ausbrechen><en> Mapuhi relieved his feelings by sending her reeling from a box on the ear; while Tefara and Nauri burst into tears and continued to upbraid him after the manner of women. Diebe.
<G-vec00867-002-s124><burst.ausbrechen><de> Nach 14 Tagen brachen die Wunden am Gesäß auf und eiterten durch vier Monate.
<G-vec00867-002-s124><burst.ausbrechen><en> 14 days later the wounds on my buttocks burst open and for four weeks were in a festering condition.
<G-vec00867-002-s125><burst.ausbrechen><de> Deiche brachen, Menschen wurden getötet und der Schaden war groß.
<G-vec00867-002-s125><burst.ausbrechen><en> Dykes burst, people were killed and the damage was huge.
<G-vec00867-002-s126><burst.ausbrechen><de> Als Verteidiger der Stadt eine unattraktive Brühe schmeckten, brachen sie so viel Energie und sie begannen, die Angriffe von Feinden mit solch einer Wut zu schlagen, dass die Feinde verwirrt und zurückgezogen wurden.
<G-vec00867-002-s126><burst.ausbrechen><en> When defenders of the city tasted unattractive broth, they so much burst of energy and they started to beat off the attacks of enemies with such a rage, that the enemies got confused and retreated.
<G-vec00867-002-s127><burst.ausbrechen><de> Diese Verhaltensweisen wurden tief vergraben - und später brechen sie um so stärker aus.
<G-vec00867-002-s127><burst.ausbrechen><en> Those habits were buried deep down -- and later they burst out even stronger.
<G-vec00867-002-s128><burst.ausbrechen><de> Eingeengte Bildformate brechen auf, gebogene und gekrümmte Flächen dehnen sich in den Raum aus und transzendieren zu Installationen und skulpturalen Formen.
<G-vec00867-002-s128><burst.ausbrechen><en> Constricted image formats burst open, curved and contorted surfaces expand space and transcend into installations and sculptural shapes.
<G-vec00867-002-s129><burst.ausbrechen><de> Bei Temperaturen unter dem Nullpunkt können Rohre brechen und damit beträchtliche Schäden und Ausfälle hervorrufen.
<G-vec00867-002-s129><burst.ausbrechen><en> When pipes are exposed to subzero temperatures they can burst, leading to considerable damage and disruption.
<G-vec00867-002-s130><burst.ausbrechen><de> Sie schauen nach einer Möglichkeit, sich ganz auszudrücken, frei zu brechen aus ihrer selbst auferlegten Lethargie, wild und ungehindert wie der Wind zu rennen, über den Planeten zu fegen und andauernde Änderungen zu bringen, aber es fehlt noch ein Schlüsselelement.
<G-vec00867-002-s130><burst.ausbrechen><en> They are looking for a method to fully express themselves, to burst free from their self-imposed lethargy, to run like the wind wild and unhindered, to sweep across the planet bringing lasting change, but some key element is missing.
<G-vec00867-002-s131><burst.ausbrechen><de> Der ultrakurze, hochenergetische Lichtimpuls bricht die in der zweiten Hautschicht eingelagerten Farbpartikel der Tattoo-Tinte auf.
<G-vec00867-002-s131><burst.ausbrechen><en> The ultra quick, high-power light impulses burst the colour pigments of the tattoo ink which are stored in the second skin layer.
<G-vec00867-002-s132><burst.ausbrechen><de> PAUL (bricht in Gelächter aus): Nein, nein.
<G-vec00867-002-s132><burst.ausbrechen><en> PAUL: (burst into laughter)No, no.
<G-vec00867-002-s133><burst.ausbrechen><de> Nicht zufällig bricht die Revolution gerade in Paris aus, in jenem katholischen Frankreich, älteste Tochter der Kirche, in der die gallikanischen und königlichen Werkzeuge des Kampfes gegen Rom geschmiedet wurden, das zugleich aber auch im Herzen des römischen Katholizismus war.
<G-vec00867-002-s133><burst.ausbrechen><en> It is no accident that the Revolution burst out precisely in Paris, in that Catholic France, eldest daughter of the Church, in which had been forged the Gallican and royal weapons of the struggle against Rome, but which was in the meantime close to the heart of Catholic Rome.
<G-vec00867-002-s024><weep.ausbrechen><de> Will ich in Tränen ausbrechen.
<G-vec00867-002-s024><weep.ausbrechen><en> I want to weep my tears.
