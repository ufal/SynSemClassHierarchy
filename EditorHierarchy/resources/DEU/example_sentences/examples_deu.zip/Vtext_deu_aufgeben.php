<G-vec00407-001-s057><fold.aufgeben><de> """Blaze"" ist eine garantierte, schnelle Aktion beim Online Poker, da Sie sofort an einem neuen Tisch platziert werden, sobald Sie die Hand, die Sie gerade gespielt haben, aufgeben oder vervollständigen."
<G-vec00407-001-s057><fold.aufgeben><en> """Blaze"" is guaranteed to be high speed online poker action, as you will be instantly moved to a new table as soon as you fold/complete the hand you have just played."
<G-vec00407-001-s058><fold.aufgeben><de> Klicken Sie entweder “Aufgeben” oder “Zeigen” .
<G-vec00407-001-s058><fold.aufgeben><en> Click on either Fold or Call button.
<G-vec00407-001-s059><fold.aufgeben><de> Wenn Sie werfen(klicken Sie den Aufgeben Knopf), verlieren Sie Ihren Einsatz und diese Spielrunde ist für Sie beendet.
<G-vec00407-001-s059><fold.aufgeben><en> If you fold (click on Fold button), you will lose your ante and this game round is over for you.
<G-vec00407-001-s060><fold.aufgeben><de> Ein Spieler, der zögert, bleibt im Spiel: es ist für ihn zum Aufgeben zu spät.
<G-vec00407-001-s060><fold.aufgeben><en> A player who hesitates has stayed in: it is too late for her to fold.
<G-vec00407-001-s061><fold.aufgeben><de> Wenn die anderen aufgeben, hat man nichts verloren, und jeder, der im Spiel bleibt, verliert einen Extrapunkt.
<G-vec00407-001-s061><fold.aufgeben><en> If the others fold you have lost nothing, and if anyone stays in it costs them an extra point.
<G-vec00407-001-s062><fold.aufgeben><de> Wenn Sie Aufgeben, verlieren Sie auch Ihre Paar Plus Wette, falls Sie eine gesetzt haben.
<G-vec00407-001-s062><fold.aufgeben><en> If you fold, you also lose your Pair Plus Bet, if one was made.
<G-vec00499-001-s019><give.aufgeben><de> Wir werden jetzt nicht aufgeben.
<G-vec00499-001-s019><give.aufgeben><en> We will not give up on this.
<G-vec00499-001-s020><give.aufgeben><de> "Sicher wird Arizona nicht, die leicht aufgeben., und es ist nicht ausgeschlossen, dass sie bekommen, spielen die Karte ""Sie sollten dort in meinem Sitz im Flugzeug, die abgestürzt gewesen sind""."
<G-vec00499-001-s020><give.aufgeben><en> "Arizona certainly will not give up so easily, and it is not excluded that they get to play the card of ""you had to be there in my seat on the plane that crashed""."
<G-vec00499-001-s021><give.aufgeben><de> Der Künstler mag krank werden oder seine Arbeit aufgeben.
<G-vec00499-001-s021><give.aufgeben><en> The artist may become ill or give up his work.
<G-vec00499-001-s022><give.aufgeben><de> Der wichtigste Faktor, warum Sie diese EaseQut Bewertung lesen ist, dass Sie wissen möchten, ob es Sie mit dem Rauchen oder anderweitig aufgeben zu unterstützen führt.
<G-vec00499-001-s022><give.aufgeben><en> The main factor why you read this EaseQut Review is that you would like to know if it performs to assist you give up smoking or otherwise.
<G-vec00499-001-s023><give.aufgeben><de> Wenn wir diesem Warnlicht nicht gefolgt sind und doch das Negative ausgesprochen haben, sollten wir daraufhin nicht aufgeben.
<G-vec00499-001-s023><give.aufgeben><en> And when we did not follow this warning signal and still said the wrong words, we should not give up.
<G-vec00499-001-s024><give.aufgeben><de> Aber mehrfach musste ich aufgeben.
<G-vec00499-001-s024><give.aufgeben><en> But I had to give up several times.
<G-vec00499-001-s025><give.aufgeben><de> Je länger diese Richtung dauert, je entschiedener sie wird, um so schwieriger wird die Wendung, um so mehr nähert sich der Augenblick, wo er die Schlacht aufgeben muss.
<G-vec00499-001-s025><give.aufgeben><en> The longer this direction continues, the more decided it becomes, so much the more difficult will be the turning, so much the nearer the moment when he must give up the battle.
<G-vec00499-001-s026><give.aufgeben><de> Wenn bereits eine Nissan GT-R eine große Maschine in der Lage Gesicht zu konkurrieren gegen den besten supercars Markt zu Angesicht, Stellen Sie sich vor, wenn wir aufgeben 2.000 CV Macht und legte es auf Vollgas.
<G-vec00499-001-s026><give.aufgeben><en> If already a Nissan GT-R is a great machine able to compete face to face against the best supercars market, Imagine if we give up 2.000 CV's power and put it to full throttle.
<G-vec00499-001-s027><give.aufgeben><de> Wir sind die ideale Lösung für diejenigen, die das Meer lieben und nicht die Ruhe und die Farben der sizilianischen Landschaft aufgeben wollen.
<G-vec00499-001-s027><give.aufgeben><en> We are the ideal solution for those who love the sea and do not want to give up the tranquility and colors of the Sicilian countryside.
<G-vec00499-001-s028><give.aufgeben><de> In jenem Jahr arbeitete Herbert Cohen noch gegen geringe Bezahlung als Mitgliedswerber beim Jüdischen Hilfswerk, doch auch diese Tätigkeit musste er im November 1938 aufgeben.
<G-vec00499-001-s028><give.aufgeben><en> In that year Herbert was earning a small income soliciting memberships for the Jewish Relief Agency, but he had to give up this job in November 1938.
<G-vec00499-001-s029><give.aufgeben><de> In seiner Filmtrilogie von 2014 breitet Magdy seine Geschichten weiter aus:The Dent (Die Delle) erzählt vom Fortschrittsglauben der Bewohner einer Kleinstadt, die im Wettbewerb um die Ausrichtung der Olympischen Spiele jeden Maßstab verlieren, sich auf irrationale und maßlose Weise präsentieren und schlussendlich aufgeben müssen.
<G-vec00499-001-s029><give.aufgeben><en> In his film trilogy from 2014, the artist extends his stories.The Dent tells of the belief in progress of the residents of a small city who seem to have lost all sense of proportion in a competition to host the Olympic Games and present themselves in an irrational and excessive way, and ultimately have to give up.
<G-vec00499-001-s030><give.aufgeben><de> Stündlich fragte die Polizistin Ko Na, ob sie den Widerstand aufgeben würden, aber die Praktizierenden weigerten sich.
<G-vec00499-001-s030><give.aufgeben><en> Policewoman Ko Na checked to see if they would give up every hour, but the practitioners refused.
<G-vec00499-001-s031><give.aufgeben><de> Ich will das Vergnügen, mit dir intime Gespräche zu führen nicht aufgeben, nur weil du einen Gatten hast.
<G-vec00499-001-s031><give.aufgeben><en> I do not want to give up the joy of intimate talks with you simply because you have a husband.
<G-vec00499-001-s032><give.aufgeben><de> Aber das Wichtigste, was in diesem Fall würde das sein, was die schrecklichsten Gedanken oder Sie besuchen, keine Panik und aufgeben.
<G-vec00499-001-s032><give.aufgeben><en> But the most important thing in this case, no matter what the worst thoughts or visit you do not need to panic and give up.
<G-vec00499-001-s033><give.aufgeben><de> Das Leben ist für diese Individuen irgendwann einfach unerträglich schwer und mühsam geworden und alles gute Zureden hilft nichts, um diesen Fakt zu ändern, sodass man irgendwann auch als Zuschauer gewillt ist, Byeong-woo zu verzeihen, sollte er aufgeben.
<G-vec00499-001-s033><give.aufgeben><en> Life has simply become unbearable and extremely tiresome for those individuals at some point and all the well-intented talking doesn't change anything about that fact, so that eventually even the viewer would be willing to forgive Byeong-woo should he decide to give up.
<G-vec00499-001-s034><give.aufgeben><de> Das Timeline Layout selbst scheint in einer Realitäts- freien Zone entworfen zu sein, wo alle mobile Geräte 851 Pixel Bilder anzeigen können, währen offensichtlich die Tatsache ignoriert wurden das die meisten Smartphone Benutzer gezwungen werden, horizontal hin und her zu blättern, bis Sie es aufgeben und frustriert die Seite verlassen.
<G-vec00499-001-s034><give.aufgeben><en> The Timeline layout itself seems to have been designed in a reality-free zone where all mobile devices can display 851 pixel images while blatantly ignoring the fact that most smartphone users will be forced to horizontally scroll back and forth until they give up and leave in frustration.
<G-vec00499-001-s035><give.aufgeben><de> Menschen, die in harten Zeiten nicht einfach aufgeben, sich kümmern um die Familie und das Gemeinwesen, die glauben, die Hoffnung und Trost suchen und manchmal bei Freunden, manchmal im Whiskey finden.
<G-vec00499-001-s035><give.aufgeben><en> People who do not simply give up in hard times, take care of the family and the community, who believe, search for hope and consolation and sometimes find them with friends and sometimes with whiskey.
<G-vec00499-001-s036><give.aufgeben><de> Es wäre verrückt, es zu versuchen, ich würde aufgeben.
<G-vec00499-001-s036><give.aufgeben><en> It would be crazy to do it then, I would give up.
<G-vec00499-001-s037><give.aufgeben><de> Sie vermittelt den Eindruck, dass wir alles aufgeben und in einer Höhle leben sollten.
<G-vec00499-001-s037><give.aufgeben><en> It tends to give the impression that we should give up everything and go live in a cave.
<G-vec00499-001-s038><give.aufgeben><de> Sofort setzte ihn Lai Baohua, der Leiter der Abteilung, unter Druck, Falun Gong aufzugeben.
<G-vec00499-001-s038><give.aufgeben><en> Right away, Lai Baohua, chief of the division, pressured him to give up Falun Gong.
<G-vec00499-001-s039><give.aufgeben><de> Das andere Extrem ist, wenn Leute dich dazu anhalten, jede Erwartung der Kontrolle gegenüber allem aufzugeben.
<G-vec00499-001-s039><give.aufgeben><en> The other extreme is when other people encourage you to give up exerting any control over anything at all.
<G-vec00499-001-s040><give.aufgeben><de> Im Jahr 2014 schienen sie ihr Ziel aufzugeben und unterstützten anarchistische Gruppen um zu randalieren und das Land zu destabilisieren, das sind die Guarimbas[4].
<G-vec00499-001-s040><give.aufgeben><en> In 2014, they seemed to give up their goal and supported anarchist groups to vandalize and destabilize the country, it is the Guarimba[4].
<G-vec00499-001-s041><give.aufgeben><de> Um mich zu zwingen, das Praktizieren von Falun Gong aufzugeben, beauftragten Polizisten Gefangene, mich zu überwachen.
<G-vec00499-001-s041><give.aufgeben><en> To force me to give up practising Falun Gong, officers ordered convicts to monitor me.
<G-vec00499-001-s042><give.aufgeben><de> Vermutlich ist ein großer Teil des Vitals unfähig, seine Haltung zu ändern und seine Launen aufzugeben oder seine Art und Weise, etwas zu empfangen; sonst könnten diese Depressionen nicht so akut sein.
<G-vec00499-001-s042><give.aufgeben><en> There must be a large part of it unable to change its position and give up its moods or its way of receiving things; otherwise these depressions could not be so acute.
<G-vec00499-001-s043><give.aufgeben><de> Wichtiger noch ist die angebliche Weigerung jener Fremden, sich der französischen Kultur vollständig zu assimilieren (was auch den Gesinnungswandel mit sich bringen würde, soupe au cochon zu essen), mit anderen Worten, ihre Weigerung, einen Teil ihrer Identität aufzugeben, um im Gegenzug in die französische Gesellschaft integriert oder ihr assimiliert (also von ihr absorbiert) zu werden.
<G-vec00499-001-s043><give.aufgeben><en> Even more crucial is the alleged refusal of those foreigners to fully assimilate into French culture (this would also entail conversion to the eating of soupe au cochon), in other words, to give up a part of their identity in return for becoming integrated or assimilated (namely absorbed) within French society.
<G-vec00499-001-s044><give.aufgeben><de> Das Gefängnis hält seit August 2010 intensive Gehirnwäsche-Sitzungen ab, um die Kontrolle über die Falun Gong-Praktizierenden zu intensivieren und zu versuchen, sie zu zwingen, ihren Glauben an Faluln Gong aufzugeben.
<G-vec00499-001-s044><give.aufgeben><en> The prison has been holding brainwashing sessions since August 2010 to intensify control over the Falun Gong practitioners and to try to force them to give up their belief.
<G-vec00499-001-s045><give.aufgeben><de> es gibt zuerst die Wette, die durch die kommunistische Partei unternommen wurde, den Werten der Vergangenheit treu zu bleiben, und die es nicht schafft, sich wieder in Frage zu stellen, das heißt die Priorität aufzugeben, die der gemeinsamen Eigenschaft eingeräumt wurde, um zu wagen, die gemeinsame Eigenschaft zu restaurieren und der lokalen Demokratie eine Stelle zu gewähren, die so den Mythos der Diktatur der Partei und den Zentralismus des Staates beendet.
<G-vec00499-001-s045><give.aufgeben><en> there is initially the bet undertaken by the Communist Party to remain faithful to the values of last and which is not able to be called into question, i.e. to give up the priority granted to the collective ownership to dare to restore the common property and to grant a place to the local democracy, putting thus fine at the myth dictatorship of the party and the centralism of the state.
<G-vec00499-001-s046><give.aufgeben><de> Als ihre 89 Jahre alte Mutter starb, durfte sie sie nicht ein letztes Mal besuchen, weil sie sich weigerte, ihren Glauben aufzugeben.
<G-vec00499-001-s046><give.aufgeben><en> When her 89-year old mother was dying, she was not allowed to visit her for the last time because she refused to give up her belief.
<G-vec00499-001-s047><give.aufgeben><de> Frau Jin und Herr Liu wurden wiederholt verfolgt, weil sie sich weigerten, ihren Glauben an Falun Gong aufzugeben.
<G-vec00499-001-s047><give.aufgeben><en> Ms. Jin and Mr. Liu have been repeatedly persecuted because they refuse to give up their belief in Falun Gong.
<G-vec00499-001-s048><give.aufgeben><de> Im Zwangsarbeitslager erlitt Zhao Ming oft Misshandlungen einschließlich Folter, Misshandlungen mit Elektroschockgeräten, harte Zwangsarbeit usw.. Außerdem erlitt er auch verschiedene Arten von geistiger Misshandlungen, wie die Versuche ihn durch Gehirnwäsche dazu zu zwingen, seinen Glauben an Falun Gong aufzugeben.
<G-vec00499-001-s048><give.aufgeben><en> In the labour camp, Ming frequently suffered maltreatment, including cruel torture, abuse with electric batons, forced hard labour and so on. At the same time, he also endured different kinds of spiritual abuse, such as the brainwashing attempts to force him to give up his belief in Falun Dafa.
<G-vec00499-001-s049><give.aufgeben><de> Wang Yaling wurde Zeugin, wie eine andere Praktizierende, Yang Chunfang aus der Stadt Jinzhou, bis zur Behinderung zusammen geschlagen wurde, weil sie sich weigerte, ihren Glauben aufzugeben.
<G-vec00499-001-s049><give.aufgeben><en> She witnessed another practitioner, Yang Chunfang from Jinzhou City, who was beaten to disability for refusing to give up her belief.
<G-vec00499-001-s050><give.aufgeben><de> Und um auf den Zweiten Weltkrieg zurückzukommen, genau damit haben sich die Denker und Schriftsteller damals eigentlich auseinandergesetzt – mit dieser Unterscheidung zwischen einem kulturellen System des metaphorischen Austauschs auf der einen Seite, also einem hyperrealen, kapitalistischen Raum, in dem alles gegen Geld ausgetauscht werden kann, das wiederum gegen alles andere ausgetauscht werden kann; und auf der anderen Seite einem Raum, in dem Menschen mobilisiert und motiviert werden, sich für den Krieg zu opfern, ihr Geld, ihre Zeit, sogar ihr Leben aufzugeben.
<G-vec00499-001-s050><give.aufgeben><en> And actually, to go back to WWII, thinkers and writers then were grappling with this, too – this distinction between, on the one hand, a cultural system of metaphoric exchange, a hyperreal, capitalist space where anything can be exchanged for money, which can be exchanged for anything else; and, on the other hand, a space that was being mobilized to motivate people to sacrifice for war, to give up money, time, even their lives.
<G-vec00499-001-s051><give.aufgeben><de> Während seiner Reise in die Türkei verkündete der russische Präsident Wladimir Putin die Entscheidung das South-Stream-Pipeline Projekt aufzugeben, zu Gunsten einer neuen, in die Türkei umgeleiteten Route.
<G-vec00499-001-s051><give.aufgeben><en> During his trip to Turkey Russian President Vladimir Putin announced the decision to give up the South Stream pipeline project in favor of a new route redirected to Turkey.
<G-vec00499-001-s052><give.aufgeben><de> Was seid ihr bereit aufzugeben für Mein Königreich und für die tiefe, innere Freude, die ihr fühlen werdet in Meinem Willen, mit Mir zu arbeiten und Seelen zu erretten.
<G-vec00499-001-s052><give.aufgeben><en> What are you willing to give up for the sake of My Kingdom and the deep inner joy you will feel in My will, working with Me to save souls.
<G-vec00499-001-s053><give.aufgeben><de> Es war einfach aufzugeben.
<G-vec00499-001-s053><give.aufgeben><en> It was easy to give it away.
<G-vec00499-001-s054><give.aufgeben><de> Nachdem wir bereits eine Veranstaltung geplant für den Sonntagmorgen, die mich von den Scheck halten bei 10, eher als einen guten Service gehalten, zog ich, nicht aufzugeben.
<G-vec00499-001-s054><give.aufgeben><en> Having already planned an event for the Sunday morning that kept me from keeping the check out at 10, rather than give a good service, I preferred not to give up.
<G-vec00499-001-s055><give.aufgeben><de> Weil sie sich weigerte, das Praktizieren von Falun Gong aufzugeben, wurde sie bis März 2005 nicht entlassen.
<G-vec00499-001-s055><give.aufgeben><en> Because Ms. Liang refused to give up her practice of Falun Gong, she was not released until March 2005.
<G-vec00499-001-s056><give.aufgeben><de> Das Wichtigste ist es, nicht aufzugeben und mit euren Nachbarn (Königen und Statthaltern) zu sprechen, um euch bei der Entscheidung zu helfen, welchem Königreich ihr angehören möchtet.
<G-vec00499-001-s056><give.aufgeben><en> The most important thing is don’t give up, but talk to your neighbors (kings and governors) to help you decide what kingdom you would like to join.
<G-vec00376-002-s042><discontinue.aufgeben><de> Hieraus ergeben sich die folgenden Konsequenzen: Unternehmen, die eine Hauptniederlassung in Großbritannien haben, können nicht mehr über den Europäischen Pass tätig werden, müssen die Aktivität also entweder aufgeben (Fall 1), ihre Tätigkeit als Zweigstelle eines Drittstaats fortsetzen (Fall 2) oder eine erlaubnistragende Tochtergesellschaft in einem Mitgliedstaat (Fall 3) nutzen.
<G-vec00376-002-s042><discontinue.aufgeben><en> This will have the following consequences: Companies having their principal establishment in the UK will no longer be able to operate via the European passport and thus will have to either discontinue the activity (case 1), continue their activity as a branch of a third country (case 2), or use a subsidiary in a Member State holding the required authorisation (case 3).
<G-vec00376-002-s043><discontinue.aufgeben><de> FANUC kann die Website in beliebigen Punkten – einschließlich der Verfügbarkeit von Funktionen der Website – jederzeit einstellen, ändern, aussetzen oder aufgeben.
<G-vec00376-002-s043><discontinue.aufgeben><en> FANUC may terminate, change, suspend or discontinue any aspect of the Website, including the availability of any features of the Website, at any time.
<G-vec00382-002-s038><give.aufgeben><de> Die Wärter im Zwangsarbeitslager folterten sie, entzogen ihr den Schlaf, sperrten sie in Einzelhaft und verweigerten ihr die Toilettenbenutzung, um sie zu zwingen, Falun Gong aufzugeben.
<G-vec00382-002-s038><give.aufgeben><en> Guards at the forced labour camp have tortured her to try to get her to give up Falun Gong, subjecting her to sleep deprivation, solitary confinement, and denying her use of the toilet.
<G-vec00382-002-s039><give.aufgeben><de> In der Zeit als ich mit Melina trainieren konnte habe ich gelernt auch nach einem Misserfolg nicht aufzugeben.
<G-vec00382-002-s039><give.aufgeben><en> In the time when I trained with Melina I learned to never give up even after a failure.
<G-vec00382-002-s040><give.aufgeben><de> Daher erscheint es in einer Zeit, in der eine größtmögliche Effizienz angestrebt wird, nicht sinnvoll, die Bienenzucht aufzugeben, wenn der Kosten-Nutzen-Faktor beweist, wie unklug eine solche Entscheidung ist.
<G-vec00382-002-s040><give.aufgeben><en> Therefore, at a time when all kinds of efficiency are being sought, it does not appear to make sense to give up the activity when the cost/benefit ratio shows how foolish such a decision is.
<G-vec00382-002-s041><give.aufgeben><de> Der Zweck der Folter war, sie und andere Praktizierende zu zwingen, ihren Glauben an Falun Dafa aufzugeben.
<G-vec00382-002-s041><give.aufgeben><en> The purpose of the torture was to coerce her and other practitioners to give up their Falun Gong practice.
<G-vec00382-002-s042><give.aufgeben><de> Der unwiderstehliche optimistische Schwung, mit dem Kinder ihre imaginären Spielräume erbauen und verwandeln, entspricht der Vitalität der universellen Botschaft, die dieses Märchen zum Ausdruck bringt: Der Wille niemals aufzugeben ist es, mit dem Hänsel und Gretel das gute Ende ihrer Geschichte selbst herbeiführen.
<G-vec00382-002-s042><give.aufgeben><en> The children’s optimistic verve while constructing and transforming imaginary spaces proves to be similar to the vitality of the fairy tale’s universal message: The will never to give up always leads to an happy end. The result is a poetic spectacle which will capture the hearts – not only of children.
<G-vec00382-002-s043><give.aufgeben><de> Der Film erzählt die Geschichte einer Gruppe Fabrikarbeiter, die ihre Jobs verlieren aber sich weigern aufzugeben.
<G-vec00382-002-s043><give.aufgeben><en> The film tells the story of a group of Portuguese factory workers who are losing their jobs but don't give in.
<G-vec00382-002-s044><give.aufgeben><de> Und dazu müssen sie lernen, sich selbst Ziele zu setzen, Verantwortung zu übernehmen und auch bei Rückschlägen nicht aufzugeben.
<G-vec00382-002-s044><give.aufgeben><en> Therefore they have to learn to set goals for themselves, take over responsibility and to not give up while they experience a rebound.
<G-vec00382-002-s045><give.aufgeben><de> Sie hielten an, um sich die Stelltafeln durchzulesen, welche die Foltermethoden darstellen, die verwendet werden, um die Falun Gong Praktizierenden dazu zu zwingen, ihren Glauben aufzugeben.
<G-vec00382-002-s045><give.aufgeben><en> Passers-by stopped to read the display boards exposing the methods of torture in cruel attempts to force Falun Gong practitioners to give up their beliefs.
<G-vec00382-002-s046><give.aufgeben><de> Sie sind nicht bereit, ihr sündiges Leben aufzugeben.
<G-vec00382-002-s046><give.aufgeben><en> They are not ready to give up their lives of sin, so they forget.
<G-vec00382-002-s047><give.aufgeben><de> Manchmal, wenn wir überall um uns Mühen, Schwierigkeiten und Unrecht sehen, sind wir versucht aufzugeben.
<G-vec00382-002-s047><give.aufgeben><en> Sometimes, when we see the troubles, difficulties and wrongs all around us, we are tempted to give up.
<G-vec00382-002-s048><give.aufgeben><de> Doch stellte ich fest, dass zu dem Zeitpunkt, da ich das Ende des vierten Kapitels erreichte, dass es nötig wurde, die Sache aufzugeben.
<G-vec00382-002-s048><give.aufgeben><en> But I found that by the time I reached the end of the fourth chapter, it was necessary to give it up.
<G-vec00382-002-s049><give.aufgeben><de> Wenn man manchmal seine Ziele nicht sofort erreicht, ist es wichtig dran zu bleiben und nicht aufzugeben.
<G-vec00382-002-s049><give.aufgeben><en> Sometimes when you do not reach your goals right away, it’s important to stay tuned and not give up.
<G-vec00382-002-s050><give.aufgeben><de> Sie wusste, dass sie auserwählt war, ihren Sohn eines Tages aufzugeben, um die Menschheit zu erlösen.
<G-vec00382-002-s050><give.aufgeben><en> She knew she was chosen to give her Son up someday to redeem mankind.
<G-vec00382-002-s051><give.aufgeben><de> Bilals Herr ließ ihn auf dem brennenden Sand liegen und ließ große Felsenplatten auf seine Brust legen, aber er weigerte sich, seinen neuen Glauben aufzugeben.
<G-vec00382-002-s051><give.aufgeben><en> Bilal’s master would make him lie on burning sand and have large slabs of rock placed on his chest, but he refused to give up his new faith.
<G-vec00382-002-s052><give.aufgeben><de> Diese Motivation, nie aufzugeben und Grenzen zu verschieben, möchte Denise Schindler weitergeben.
<G-vec00382-002-s052><give.aufgeben><en> Her motivation to never give up and push the limits is something she would like to pass on to others.
<G-vec00382-002-s053><give.aufgeben><de> In den Komitees und Zirkeln kann man Leute antreffen, die sich sogar in das Spezialstudium irgendeines Zweiges der Eisenproduktion vertiefen, aber man kann fast keine Beispiele anführen, daß Mitglieder der Organisationen (die, wie es oft der Fall ist, gezwungen sind, aus diesem oder jenem Grunde die praktische Arbeit aufzugeben) sich speziell mit dem Sammeln von Material über irgendeine aktuelle Frage unseres sozialen und politischen Lebens befaßten, die zu einer sozialdemokratischen Arbeit in anderen Schichten der Bevölkerung Anlaß geben könnte.
<G-vec00382-002-s053><give.aufgeben><en> In the committees and study circles, one can meet people who are immersed in the study even of some special branch of the metal industry; but one can hardly ever find members of organisations (obliged, as often happens, for some reason or other to give up practical work) who are especially engaged in gathering material on some pressing question of social and political life in our country which could serve as a means for conducting Social-Democratic work among other strata of the population.
<G-vec00382-002-s054><give.aufgeben><de> Bereitschaft, Widerstände aufzugeben und sich auf den Fluss des Lebens einzustimmen.
<G-vec00382-002-s054><give.aufgeben><en> being willing to give up resistance and to attune with the flow of life
<G-vec00382-002-s055><give.aufgeben><de> Die Menschen heutzutage neigen dazu, diesen großartigen Kultivierungsweg angesichts der grausamen Verfolgung aufzugeben, noch bevor sie durch das Praktizieren körperlich und geistig profitiert haben, weil sie nicht standhaft an diese aufrichtige Kultivierungspraxis glauben.
<G-vec00382-002-s055><give.aufgeben><en> Before really benefiting from the cultivation practice physically and spiritually, without having steadfast belief in the righteous cultivation practice, people nowadays tend to give up this great cultivation way in the face of material benefits and the cruel persecution.
<G-vec00382-002-s056><give.aufgeben><de> Jetzt ist nicht die Zeit, um aufzugeben.
<G-vec00382-002-s056><give.aufgeben><en> This is not the time to give up.
<G-vec00497-002-s038><give_up.aufgeben><de> Die Wärter im Zwangsarbeitslager folterten sie, entzogen ihr den Schlaf, sperrten sie in Einzelhaft und verweigerten ihr die Toilettenbenutzung, um sie zu zwingen, Falun Gong aufzugeben.
<G-vec00497-002-s038><give_up.aufgeben><en> Guards at the forced labour camp have tortured her to try to get her to give up Falun Gong, subjecting her to sleep deprivation, solitary confinement, and denying her use of the toilet.
<G-vec00497-002-s039><give_up.aufgeben><de> In der Zeit als ich mit Melina trainieren konnte habe ich gelernt auch nach einem Misserfolg nicht aufzugeben.
<G-vec00497-002-s039><give_up.aufgeben><en> In the time when I trained with Melina I learned to never give up even after a failure.
<G-vec00497-002-s040><give_up.aufgeben><de> Daher erscheint es in einer Zeit, in der eine größtmögliche Effizienz angestrebt wird, nicht sinnvoll, die Bienenzucht aufzugeben, wenn der Kosten-Nutzen-Faktor beweist, wie unklug eine solche Entscheidung ist.
<G-vec00497-002-s040><give_up.aufgeben><en> Therefore, at a time when all kinds of efficiency are being sought, it does not appear to make sense to give up the activity when the cost/benefit ratio shows how foolish such a decision is.
<G-vec00497-002-s041><give_up.aufgeben><de> Der Zweck der Folter war, sie und andere Praktizierende zu zwingen, ihren Glauben an Falun Dafa aufzugeben.
<G-vec00497-002-s041><give_up.aufgeben><en> The purpose of the torture was to coerce her and other practitioners to give up their Falun Gong practice.
<G-vec00497-002-s042><give_up.aufgeben><de> Der unwiderstehliche optimistische Schwung, mit dem Kinder ihre imaginären Spielräume erbauen und verwandeln, entspricht der Vitalität der universellen Botschaft, die dieses Märchen zum Ausdruck bringt: Der Wille niemals aufzugeben ist es, mit dem Hänsel und Gretel das gute Ende ihrer Geschichte selbst herbeiführen.
<G-vec00497-002-s042><give_up.aufgeben><en> The children’s optimistic verve while constructing and transforming imaginary spaces proves to be similar to the vitality of the fairy tale’s universal message: The will never to give up always leads to an happy end. The result is a poetic spectacle which will capture the hearts – not only of children.
<G-vec00497-002-s043><give_up.aufgeben><de> Der Film erzählt die Geschichte einer Gruppe Fabrikarbeiter, die ihre Jobs verlieren aber sich weigern aufzugeben.
<G-vec00497-002-s043><give_up.aufgeben><en> The film tells the story of a group of Portuguese factory workers who are losing their jobs but don't give in.
<G-vec00497-002-s044><give_up.aufgeben><de> Und dazu müssen sie lernen, sich selbst Ziele zu setzen, Verantwortung zu übernehmen und auch bei Rückschlägen nicht aufzugeben.
<G-vec00497-002-s044><give_up.aufgeben><en> Therefore they have to learn to set goals for themselves, take over responsibility and to not give up while they experience a rebound.
<G-vec00497-002-s045><give_up.aufgeben><de> Sie hielten an, um sich die Stelltafeln durchzulesen, welche die Foltermethoden darstellen, die verwendet werden, um die Falun Gong Praktizierenden dazu zu zwingen, ihren Glauben aufzugeben.
<G-vec00497-002-s045><give_up.aufgeben><en> Passers-by stopped to read the display boards exposing the methods of torture in cruel attempts to force Falun Gong practitioners to give up their beliefs.
<G-vec00497-002-s046><give_up.aufgeben><de> Sie sind nicht bereit, ihr sündiges Leben aufzugeben.
<G-vec00497-002-s046><give_up.aufgeben><en> They are not ready to give up their lives of sin, so they forget.
<G-vec00497-002-s047><give_up.aufgeben><de> Manchmal, wenn wir überall um uns Mühen, Schwierigkeiten und Unrecht sehen, sind wir versucht aufzugeben.
<G-vec00497-002-s047><give_up.aufgeben><en> Sometimes, when we see the troubles, difficulties and wrongs all around us, we are tempted to give up.
<G-vec00497-002-s048><give_up.aufgeben><de> Doch stellte ich fest, dass zu dem Zeitpunkt, da ich das Ende des vierten Kapitels erreichte, dass es nötig wurde, die Sache aufzugeben.
<G-vec00497-002-s048><give_up.aufgeben><en> But I found that by the time I reached the end of the fourth chapter, it was necessary to give it up.
<G-vec00497-002-s049><give_up.aufgeben><de> Wenn man manchmal seine Ziele nicht sofort erreicht, ist es wichtig dran zu bleiben und nicht aufzugeben.
<G-vec00497-002-s049><give_up.aufgeben><en> Sometimes when you do not reach your goals right away, it’s important to stay tuned and not give up.
<G-vec00497-002-s050><give_up.aufgeben><de> Sie wusste, dass sie auserwählt war, ihren Sohn eines Tages aufzugeben, um die Menschheit zu erlösen.
<G-vec00497-002-s050><give_up.aufgeben><en> She knew she was chosen to give her Son up someday to redeem mankind.
<G-vec00497-002-s051><give_up.aufgeben><de> Bilals Herr ließ ihn auf dem brennenden Sand liegen und ließ große Felsenplatten auf seine Brust legen, aber er weigerte sich, seinen neuen Glauben aufzugeben.
<G-vec00497-002-s051><give_up.aufgeben><en> Bilal’s master would make him lie on burning sand and have large slabs of rock placed on his chest, but he refused to give up his new faith.
<G-vec00497-002-s052><give_up.aufgeben><de> Diese Motivation, nie aufzugeben und Grenzen zu verschieben, möchte Denise Schindler weitergeben.
<G-vec00497-002-s052><give_up.aufgeben><en> Her motivation to never give up and push the limits is something she would like to pass on to others.
<G-vec00497-002-s053><give_up.aufgeben><de> In den Komitees und Zirkeln kann man Leute antreffen, die sich sogar in das Spezialstudium irgendeines Zweiges der Eisenproduktion vertiefen, aber man kann fast keine Beispiele anführen, daß Mitglieder der Organisationen (die, wie es oft der Fall ist, gezwungen sind, aus diesem oder jenem Grunde die praktische Arbeit aufzugeben) sich speziell mit dem Sammeln von Material über irgendeine aktuelle Frage unseres sozialen und politischen Lebens befaßten, die zu einer sozialdemokratischen Arbeit in anderen Schichten der Bevölkerung Anlaß geben könnte.
<G-vec00497-002-s053><give_up.aufgeben><en> In the committees and study circles, one can meet people who are immersed in the study even of some special branch of the metal industry; but one can hardly ever find members of organisations (obliged, as often happens, for some reason or other to give up practical work) who are especially engaged in gathering material on some pressing question of social and political life in our country which could serve as a means for conducting Social-Democratic work among other strata of the population.
<G-vec00497-002-s054><give_up.aufgeben><de> Bereitschaft, Widerstände aufzugeben und sich auf den Fluss des Lebens einzustimmen.
<G-vec00497-002-s054><give_up.aufgeben><en> being willing to give up resistance and to attune with the flow of life
<G-vec00497-002-s055><give_up.aufgeben><de> Die Menschen heutzutage neigen dazu, diesen großartigen Kultivierungsweg angesichts der grausamen Verfolgung aufzugeben, noch bevor sie durch das Praktizieren körperlich und geistig profitiert haben, weil sie nicht standhaft an diese aufrichtige Kultivierungspraxis glauben.
<G-vec00497-002-s055><give_up.aufgeben><en> Before really benefiting from the cultivation practice physically and spiritually, without having steadfast belief in the righteous cultivation practice, people nowadays tend to give up this great cultivation way in the face of material benefits and the cruel persecution.
<G-vec00497-002-s056><give_up.aufgeben><de> Jetzt ist nicht die Zeit, um aufzugeben.
<G-vec00497-002-s056><give_up.aufgeben><en> This is not the time to give up.
<G-vec00519-002-s028><peg.aufgeben><de> Als die SNB die Bindung aufgab, gab es keinen Markt bis unter 0,88, und der Broker konnte die Stop-Loss-Aufträge nicht ausführen.
<G-vec00519-002-s028><peg.aufgeben><en> When the SNB dropped the peg, there was no market to be found all the way to below 0.88, and the broker could not execute the stop loss orders.
<G-vec00739-002-s019><give_in.aufgeben><de> Wenn wir beide nicht pendeln wollten, müsste eine(r) von uns den Beruf aufgeben; das aber kommt nicht in Frage.
<G-vec00739-002-s019><give_in.aufgeben><en> If we don't want both of us to have to commute, one of us will have to give up their job, but that’s out of the question.
<G-vec00739-002-s020><give_in.aufgeben><de> Zwar sei er in Deutschland gut integriert und müsste eine sichere Arbeitsstelle und ein geregeltes Einkommen aufgeben.
<G-vec00739-002-s020><give_in.aufgeben><en> To be sure, he is well integrated in Germany and would have to give up a steady job and a regular income.
<G-vec00739-002-s021><give_in.aufgeben><de> Ich glaube aber, vielen ist gar nicht bewusst, was sie mit diesem Schritt aufgeben würden.
<G-vec00739-002-s021><give_in.aufgeben><en> But I believe many indies are not aware of what they would give up with this step.
<G-vec00739-002-s022><give_in.aufgeben><de> Wie auch immer, das ist nicht der Punkt, denn die Tatsache ist: Es existiert nichts zum Aufgeben.
<G-vec00739-002-s022><give_in.aufgeben><en> Anyway, that's not the point, for the fact is: there is nothing to give up.
<G-vec00739-002-s023><give_in.aufgeben><de> Also könnte man sie aufgeben.
<G-vec00739-002-s023><give_in.aufgeben><en> Okay, mister, I give up.
<G-vec00739-002-s024><give_in.aufgeben><de> Dann mussten die Praktizierenden Erklärungen unterschreiben, dass sie das Praktizieren von Falun Gong aufgeben würden und während der Olympischen Spiele nicht hinausgehen würden.
<G-vec00739-002-s024><give_in.aufgeben><en> Practitioners then had to write a guarantee statement promising that they would give up practising Falun Gong, and they would not go out during the Olympics.
<G-vec00739-002-s025><give_in.aufgeben><de> Und der Priester, an den sie versprochen wurde, wird sie nicht so leicht aufgeben und erklärt den Drachen den Krieg.
<G-vec00739-002-s025><give_in.aufgeben><en> And the priest that had laid claim to her at the College will not give her up so easily.
<G-vec00739-002-s026><give_in.aufgeben><de> Wangs Frau wurde auch in ein Arbeitslager gesandt, weil sie Falun Gong nicht aufgeben wollte.
<G-vec00739-002-s026><give_in.aufgeben><en> Wang's wife also was sent to a forced labour camp because she would not give up Falun Gong.
<G-vec00739-002-s027><give_in.aufgeben><de> Alle Gedanken drehen sich nur um das eine, WEITER MACHEN und NIEMALS aufgeben.
<G-vec00739-002-s027><give_in.aufgeben><en> All of your thoughts spinn around one thing, GO ON and NEVER give up.
<G-vec00739-002-s028><give_in.aufgeben><de> Bei uns spricht der langjährige Red-Bull-Junior über seine spezielle Beziehung zu Österreich, eine Traum-Rennstrecke in Salzburg, die außergewöhnliche Beziehung zu seinem Teamkollegen und warum er die Formel E nie für ein Formel 1-Comeback aufgeben würde.
<G-vec00739-002-s028><give_in.aufgeben><en> The long-term Red Bull Junior talks to us about his special relationship with Austria, a dream race circuit in Salzburg, the exceptional relationship with his team colleague, and why he would never give up Formula E for a Formula One comeback.
<G-vec00739-002-s029><give_in.aufgeben><de> Konvertiten müssen um ihr Leben fürchten.“ Die mehr als 1,5 Millionen Kuchi-Nomaden mussten aufgrund des Krieges ihre Herden aufgeben und sich ansiedeln.
<G-vec00739-002-s029><give_in.aufgeben><en> Converts will have to fear for their lives." Due to the war, the more than 1.5 million Kuchi nomads had to give up their herds and settle.
<G-vec00739-002-s030><give_in.aufgeben><de> Die Kosten und Konsequenzen des Kampfes für den Sturz und die Revolution bedeuten nicht, dass wir aufgeben sollten.
<G-vec00739-002-s030><give_in.aufgeben><en> The costs and consequences of the struggle for the overthrow and revolution do not mean that we should give up.
<G-vec00739-002-s031><give_in.aufgeben><de> Vorsatz: Ich will heute etwas aufgeben, das die Aufmerksamkeit einschränkt, die ich meinem Ehepartner, meiner Familie oder meinen Freunden gebe.
<G-vec00739-002-s031><give_in.aufgeben><en> Resolution:I will give up something today that diminishes the attention that I give to my spouse, family or friends.
<G-vec00739-002-s032><give_in.aufgeben><de> Der finanzielle Schaden kann also sehr groß sein, wenn Elektrogeräte unerwartet den Geist aufgeben, dabei kann der Schutz so einfach, preiswert und kinderleicht sein.
<G-vec00739-002-s032><give_in.aufgeben><en> Hence, the financial damage can be very great when electric appliances unexpectedly give out; at the same time, the protection can be so simple, affordable and easy.
<G-vec00739-002-s033><give_in.aufgeben><de> Doch aufgeben will sie nicht.
<G-vec00739-002-s033><give_in.aufgeben><en> She refuses, however, to give up.
<G-vec00739-002-s034><give_in.aufgeben><de> Die Sozialdemokraten werden ihren Kampf gegen jene, die alles Gute in Europa zerstören wollen, nicht aufgeben.
<G-vec00739-002-s034><give_in.aufgeben><en> Socialists and Democrats will not give up on fighting against those who want to break all that is good in Europe.
<G-vec00739-002-s035><give_in.aufgeben><de> Magische Praktiken wurden toleriert, weil man glaubte, das die Menschen sie mit der Zeit auf natürliche Weise aufgeben würden, wenn sie wirkliche Christen geworden waren.
<G-vec00739-002-s035><give_in.aufgeben><en> Magical practices were tolerated because it was felt that the people would give them up naturally over time once they had become truly Christian.
<G-vec00739-002-s036><give_in.aufgeben><de> Da, wenn Sie einem Baby eine Flasche geben, wird er sicherlich die Brust aufgeben.
<G-vec00739-002-s036><give_in.aufgeben><en> Since, if you give a baby a bottle, he will certainly give up the breast.
<G-vec00739-002-s037><give_in.aufgeben><de> Es erschien mir als ob ich nie mein Ziel erreichen würde und ich wollte schon aufgeben und umkehren.
<G-vec00739-002-s037><give_in.aufgeben><en> It seemed to me as if I would never reach my goal and I soon wanted to give up and turn back.
<G-vec00739-002-s038><give_in.aufgeben><de> Die Wärter im Zwangsarbeitslager folterten sie, entzogen ihr den Schlaf, sperrten sie in Einzelhaft und verweigerten ihr die Toilettenbenutzung, um sie zu zwingen, Falun Gong aufzugeben.
<G-vec00739-002-s038><give_in.aufgeben><en> Guards at the forced labour camp have tortured her to try to get her to give up Falun Gong, subjecting her to sleep deprivation, solitary confinement, and denying her use of the toilet.
<G-vec00739-002-s039><give_in.aufgeben><de> In der Zeit als ich mit Melina trainieren konnte habe ich gelernt auch nach einem Misserfolg nicht aufzugeben.
<G-vec00739-002-s039><give_in.aufgeben><en> In the time when I trained with Melina I learned to never give up even after a failure.
<G-vec00739-002-s040><give_in.aufgeben><de> Daher erscheint es in einer Zeit, in der eine größtmögliche Effizienz angestrebt wird, nicht sinnvoll, die Bienenzucht aufzugeben, wenn der Kosten-Nutzen-Faktor beweist, wie unklug eine solche Entscheidung ist.
<G-vec00739-002-s040><give_in.aufgeben><en> Therefore, at a time when all kinds of efficiency are being sought, it does not appear to make sense to give up the activity when the cost/benefit ratio shows how foolish such a decision is.
<G-vec00739-002-s041><give_in.aufgeben><de> Der Zweck der Folter war, sie und andere Praktizierende zu zwingen, ihren Glauben an Falun Dafa aufzugeben.
<G-vec00739-002-s041><give_in.aufgeben><en> The purpose of the torture was to coerce her and other practitioners to give up their Falun Gong practice.
<G-vec00739-002-s042><give_in.aufgeben><de> Der unwiderstehliche optimistische Schwung, mit dem Kinder ihre imaginären Spielräume erbauen und verwandeln, entspricht der Vitalität der universellen Botschaft, die dieses Märchen zum Ausdruck bringt: Der Wille niemals aufzugeben ist es, mit dem Hänsel und Gretel das gute Ende ihrer Geschichte selbst herbeiführen.
<G-vec00739-002-s042><give_in.aufgeben><en> The children’s optimistic verve while constructing and transforming imaginary spaces proves to be similar to the vitality of the fairy tale’s universal message: The will never to give up always leads to an happy end. The result is a poetic spectacle which will capture the hearts – not only of children.
<G-vec00739-002-s043><give_in.aufgeben><de> Der Film erzählt die Geschichte einer Gruppe Fabrikarbeiter, die ihre Jobs verlieren aber sich weigern aufzugeben.
<G-vec00739-002-s043><give_in.aufgeben><en> The film tells the story of a group of Portuguese factory workers who are losing their jobs but don't give in.
<G-vec00739-002-s044><give_in.aufgeben><de> Und dazu müssen sie lernen, sich selbst Ziele zu setzen, Verantwortung zu übernehmen und auch bei Rückschlägen nicht aufzugeben.
<G-vec00739-002-s044><give_in.aufgeben><en> Therefore they have to learn to set goals for themselves, take over responsibility and to not give up while they experience a rebound.
<G-vec00739-002-s045><give_in.aufgeben><de> Sie hielten an, um sich die Stelltafeln durchzulesen, welche die Foltermethoden darstellen, die verwendet werden, um die Falun Gong Praktizierenden dazu zu zwingen, ihren Glauben aufzugeben.
<G-vec00739-002-s045><give_in.aufgeben><en> Passers-by stopped to read the display boards exposing the methods of torture in cruel attempts to force Falun Gong practitioners to give up their beliefs.
<G-vec00739-002-s046><give_in.aufgeben><de> Sie sind nicht bereit, ihr sündiges Leben aufzugeben.
<G-vec00739-002-s046><give_in.aufgeben><en> They are not ready to give up their lives of sin, so they forget.
<G-vec00739-002-s047><give_in.aufgeben><de> Manchmal, wenn wir überall um uns Mühen, Schwierigkeiten und Unrecht sehen, sind wir versucht aufzugeben.
<G-vec00739-002-s047><give_in.aufgeben><en> Sometimes, when we see the troubles, difficulties and wrongs all around us, we are tempted to give up.
<G-vec00739-002-s048><give_in.aufgeben><de> Doch stellte ich fest, dass zu dem Zeitpunkt, da ich das Ende des vierten Kapitels erreichte, dass es nötig wurde, die Sache aufzugeben.
<G-vec00739-002-s048><give_in.aufgeben><en> But I found that by the time I reached the end of the fourth chapter, it was necessary to give it up.
<G-vec00739-002-s049><give_in.aufgeben><de> Wenn man manchmal seine Ziele nicht sofort erreicht, ist es wichtig dran zu bleiben und nicht aufzugeben.
<G-vec00739-002-s049><give_in.aufgeben><en> Sometimes when you do not reach your goals right away, it’s important to stay tuned and not give up.
<G-vec00739-002-s050><give_in.aufgeben><de> Sie wusste, dass sie auserwählt war, ihren Sohn eines Tages aufzugeben, um die Menschheit zu erlösen.
<G-vec00739-002-s050><give_in.aufgeben><en> She knew she was chosen to give her Son up someday to redeem mankind.
<G-vec00739-002-s051><give_in.aufgeben><de> Bilals Herr ließ ihn auf dem brennenden Sand liegen und ließ große Felsenplatten auf seine Brust legen, aber er weigerte sich, seinen neuen Glauben aufzugeben.
<G-vec00739-002-s051><give_in.aufgeben><en> Bilal’s master would make him lie on burning sand and have large slabs of rock placed on his chest, but he refused to give up his new faith.
<G-vec00739-002-s052><give_in.aufgeben><de> Diese Motivation, nie aufzugeben und Grenzen zu verschieben, möchte Denise Schindler weitergeben.
<G-vec00739-002-s052><give_in.aufgeben><en> Her motivation to never give up and push the limits is something she would like to pass on to others.
<G-vec00739-002-s053><give_in.aufgeben><de> In den Komitees und Zirkeln kann man Leute antreffen, die sich sogar in das Spezialstudium irgendeines Zweiges der Eisenproduktion vertiefen, aber man kann fast keine Beispiele anführen, daß Mitglieder der Organisationen (die, wie es oft der Fall ist, gezwungen sind, aus diesem oder jenem Grunde die praktische Arbeit aufzugeben) sich speziell mit dem Sammeln von Material über irgendeine aktuelle Frage unseres sozialen und politischen Lebens befaßten, die zu einer sozialdemokratischen Arbeit in anderen Schichten der Bevölkerung Anlaß geben könnte.
<G-vec00739-002-s053><give_in.aufgeben><en> In the committees and study circles, one can meet people who are immersed in the study even of some special branch of the metal industry; but one can hardly ever find members of organisations (obliged, as often happens, for some reason or other to give up practical work) who are especially engaged in gathering material on some pressing question of social and political life in our country which could serve as a means for conducting Social-Democratic work among other strata of the population.
<G-vec00739-002-s054><give_in.aufgeben><de> Bereitschaft, Widerstände aufzugeben und sich auf den Fluss des Lebens einzustimmen.
<G-vec00739-002-s054><give_in.aufgeben><en> being willing to give up resistance and to attune with the flow of life
<G-vec00739-002-s055><give_in.aufgeben><de> Die Menschen heutzutage neigen dazu, diesen großartigen Kultivierungsweg angesichts der grausamen Verfolgung aufzugeben, noch bevor sie durch das Praktizieren körperlich und geistig profitiert haben, weil sie nicht standhaft an diese aufrichtige Kultivierungspraxis glauben.
<G-vec00739-002-s055><give_in.aufgeben><en> Before really benefiting from the cultivation practice physically and spiritually, without having steadfast belief in the righteous cultivation practice, people nowadays tend to give up this great cultivation way in the face of material benefits and the cruel persecution.
<G-vec00739-002-s056><give_in.aufgeben><de> Jetzt ist nicht die Zeit, um aufzugeben.
<G-vec00739-002-s056><give_in.aufgeben><en> This is not the time to give up.
<G-vec00739-002-s050><surrender.aufgeben><de> Giddianhi, der Gadiantonführer, verlangt, daß Lachoneus und die Nephiten sich und ihre Länder aufgeben—Lachoneus bestimmt Gidgiddoni zum obersten Hauptmann der Heere—Die Nephiten sammeln sich im Land Zarahemla und Überfluß, um sich zu verteidigen.
<G-vec00739-002-s050><surrender.aufgeben><en> Giddianhi, the Gadianton leader, demands that Lachoneus and the Nephites surrender themselves and their lands—Lachoneus appoints Gidgiddoni as chief captain of the armies—The Nephites assemble in Zarahemla and Bountiful to defend themselves. About A.D. 16–18.
<G-vec00739-002-s051><surrender.aufgeben><de> Es erscheint ein Button auf dem Bildschirm mit der Aufschrift AUFGEBEN.
<G-vec00739-002-s051><surrender.aufgeben><en> There will be a button on the screen which says SURRENDER.
<G-vec00739-002-s052><surrender.aufgeben><de> Das bedeutet, du kannst das Ego nicht aufgeben, wenn du unbewusst bist und du kannst es nicht aufgeben, wenn du bewusst bist.
<G-vec00739-002-s052><surrender.aufgeben><en> So you cannot surrender when you are unaware and you cannot surrender when you are aware.
<G-vec00739-002-s053><surrender.aufgeben><de> Bei harten Summen wie 12, 13 oder 14 sollte man niemals aufgeben.
<G-vec00739-002-s053><surrender.aufgeben><en> You should never surrender hard totals of 12, 13, or 14.
<G-vec00739-002-s054><surrender.aufgeben><de> Währenddessen greift Mako Ming-Hua an, die ihre Wasserpeischen verliert, doch sie will nicht aufgeben und springt in ein unterirdisches Wasserbecken, in welches Mako ihr aber folgt.
<G-vec00739-002-s054><surrender.aufgeben><en> Having caught her without water at last, Mako urges the waterbender to give up; unwilling to surrender, Ming-Hua jumps into a hole in the earth beneath them.
<G-vec00739-002-s055><surrender.aufgeben><de> Wenn der Händler eine 10 oder ein Ass hält und Sie haben insgesamt 15 oder 16 mit 10 oder 9, sollten Sie aufgeben.
<G-vec00739-002-s055><surrender.aufgeben><en> If the dealer is holding a 10 or an ace and you have a total of 15 or 16 with a 10 or 9, you should surrender.
<G-vec00739-002-s056><surrender.aufgeben><de> Der Ministerpräsident Arsenij Jacenjuk fiel mit Drohungen über die Donezker und Lugansker Aufständischen her und forderte ihr sofortiges Aufgeben, wobei er auf die Genfer Vereinbarung verwies, in deren Rahmen „Russland gezwungen war, den Extremismus zu verurteilen“.
<G-vec00739-002-s056><surrender.aufgeben><en> Premier Arseny Yatsenyuk heaped threats onto the Donetsk and Lugansk rebels, demanding their immediate surrender and referring to the Geneva agreement, in the framework of which “Russia was forced to condemn extremism.”
<G-vec00739-002-s057><surrender.aufgeben><de> * Spätes Aufgeben – Sie können erst aufgeben, nachdem der Dealer geprüft hat, ob er ein Blackjack hat und nur, wenn er kein Blackjack hat.
<G-vec00739-002-s057><surrender.aufgeben><en> Late Surrender: Surrender allowed after the dealer has checked for blackjack, if he does not have blackjack the player loses half his/her bet.
<G-vec00739-002-s058><surrender.aufgeben><de> Wenn Sie aufgeben, verlieren Sie die Hälfte des Wetteinsatzes, was bedeutet, dass Sie immerhin die andere Hälfte behalten können.
<G-vec00739-002-s058><surrender.aufgeben><en> When you surrender, you lose half the bet, which means you still get to keep half of it.
<G-vec00739-002-s059><surrender.aufgeben><de> Dann verringert sich auch ihr Widerstand gegen die Hilfe, die ihr im jenseitigen Reich immer wieder geboten wird, und Aufgeben des Widerstandes ist schon beginnender Aufstieg, denn jeder Regung einer solchen Seele wird Rechnung getragen und ihr ein kleines Licht geschenkt, das sie beglückt und ihr Verlangen danach vergrößert.
<G-vec00739-002-s059><surrender.aufgeben><en> This is also decreasing its rejection of accepting the help which it is repeatedly offered in the realm of the beyond, and its surrender of opposition is the beginning of progress, for every inclination of such a soul is taken into account and it is bestowed with a small light, which makes it happy and increases its desire for it.
<G-vec00739-002-s060><surrender.aufgeben><de> Ist man der Meinung, der Croupier hat das bessere Blatt, kann man aussteigen, indem man auf den „Aussteigen“- oder „Aufgeben“-Button auf dem Bildschirm klickt.
<G-vec00739-002-s060><surrender.aufgeben><en> If you think your hand is worse than the dealer's, you can fold by clicking on the 'Fold' or 'Surrender' button on your screen.
<G-vec00739-002-s061><surrender.aufgeben><de> Hat der Dealer eine Blackjack-Hand, so ist das Aufgeben nicht mehr möglich.
<G-vec00739-002-s061><surrender.aufgeben><en> If the dealer has a blackjack hand, then surrender is not available.
<G-vec00739-002-s062><surrender.aufgeben><de> It 's so ermüdend und so deprimierend, aber Sie don ' t aufgeben wollen.
<G-vec00739-002-s062><surrender.aufgeben><en> It is so tiring and so depressing, but you do not want to surrender.
<G-vec00739-002-s063><surrender.aufgeben><de> Man kann sich nur vorstellen, wie brutal dieses Terrain sein muss, wenn ein fünfmaliger Guinness-Weltrekordhalter, der zweimal den Atlantik überquerte und Ausdauer-Herausforderungen wie das Durchfahren der Gobi Wüste absolvierte, in der frühen Phase der Wanderung aufgeben musste.
<G-vec00739-002-s063><surrender.aufgeben><en> It can only be imagined how brutal this terrain must be, when a 5 times Guinness World Record holder who rowed across the Atlantic twice and completed endurance challenges such as running through Gobi desert, had to surrender in the early stage of the trek.
<G-vec00739-002-s064><surrender.aufgeben><de> Von Mäusen und Menschen war weder eine Themenausstellung, noch eine Ausstellung mit These, sondern stellte Fragen über Geburt und Verlust, Sterben und Aufgeben, Trauer und Nostalgie.
<G-vec00739-002-s064><surrender.aufgeben><en> Of Mice and Men was neither a thematic exhibition nor an exhibition that followed a certain thesis but rather posed larger questions about Birth and Loss, Death and Surrender, Sorrow and Nostalgia.
<G-vec00739-002-s065><surrender.aufgeben><de> [Aufgeben zählt nicht].
<G-vec00739-002-s065><surrender.aufgeben><en> [Surrender doesn't count].
<G-vec00739-002-s066><surrender.aufgeben><de> Am Ende der 60 Sekunden, wenn 70% des Teams dem Aufgeben nicht zugestimmt haben, scheitert das Votum und kann für drei Minuten nicht mehr initiiert werden.
<G-vec00739-002-s066><surrender.aufgeben><en> At the end of the 60 seconds, if 70% of the team has not agreed to surrender, the vote fails and cannot be initiated again for three minutes.
<G-vec00739-002-s067><surrender.aufgeben><de> Aufgeben: Wenn Ihre Gesamtpunkte genannt werden, können Sie das Spiel für den Rest der Runde einstellen und die Hälfte Ihres Einsatzes aufgeben.
<G-vec00739-002-s067><surrender.aufgeben><en> Surrender As your point total is announced, you can choose to discontinue play of your hand for that round and surrender half of your bet amount.
<G-vec00739-002-s068><surrender.aufgeben><de> Sie können bei Vegas Single Deck Blackjack Gold jedoch nicht aufgeben.
<G-vec00739-002-s068><surrender.aufgeben><en> However, you can’t surrender in Vegas Single Deck Blackjack Gold.
<G-vec00739-002-s069><surrender.aufgeben><de> Deshalb nicht die Hände bewegen, wenn du aufgeben willst.
<G-vec00739-002-s069><surrender.aufgeben><en> Therefore, do not move your hands if you intend to surrender.
<G-vec00739-002-s070><surrender.aufgeben><de> Stelle in einem Live-Casino immer sicher, dass du Augenkontakt mit dem Dealer herstellst und laut und deutlich sprichst, wann immer du aufgeben willst.
<G-vec00739-002-s070><surrender.aufgeben><en> In live casino play, always make sure you make eye contact with the dealer and speak in a loud, clear voice whenever you surrender.
<G-vec00739-002-s071><surrender.aufgeben><de> Die Sklaverei war für Amerika zu profitabel, um aufgegeben zu werden.
<G-vec00739-002-s071><surrender.aufgeben><en> Slavery was just too profitable for it to surrender.
<G-vec00739-002-s072><surrender.aufgeben><de> Wenn Schlüsselpunkte in Port Battles im realen Leben erreicht wurden, haben die Türme und Forts schlussendlich aufgegeben.
<G-vec00739-002-s072><surrender.aufgeben><en> Removed - Tower requirements. If you controlled key points in real world port battle towers and forts would eventually surrender.
<G-vec00739-002-s073><surrender.aufgeben><de> Dennoch, wie Benjamin Franklin es einmal sagte, “wer die Freiheit für die Sicherheit aufgibt, wird weder das Eine verdienen, noch das Andere haben”.
<G-vec00739-002-s073><surrender.aufgeben><en> Yet, as Benjamin Franklin once said, “those who surrender freedom for security will not have, nor do they deserve, either one.”
<G-vec00739-002-s074><surrender.aufgeben><de> Man gewinnt indem man entweder die letzte Stadt seines Kontrahenten erobert, oder indem dieser aufgibt.
<G-vec00739-002-s074><surrender.aufgeben><en> You either win by capturing the enemy’s last city or they surrender.
<G-vec00739-002-s075><surrender.aufgeben><de> Der Machtkampf bei Volkswagen eskalierte über das Wochenende, als ein Riss zwischen den Familien Porsche und Piëch auftauchte, die den Carmaker und seinen Chef kontrollierten, dass er nicht beabsichtige, seine Position aufzugeben.
<G-vec00739-002-s075><surrender.aufgeben><en> The power struggle at Volkswagen escalated over the weekend, as a rift emerged between the Porsche and Piëch families that control the carmaker and its chief executive signalled he does not intend to surrender his position.
<G-vec00739-002-s076><surrender.aufgeben><de> So wurde wieder mit den USA verhandelt – sehr zum Ärger der dänischen Nationalisten, die es verwerflich fanden, dieses letzte Zeugnis der einstigen dänischen Großmacht auch noch aufzugeben.
<G-vec00739-002-s076><surrender.aufgeben><en> Negotiations with the USA were resumed – much to the disgust of the Danish nationalists who thought it reprehensible to surrender this last testimony to the former Danish major power.
<G-vec00739-002-s077><surrender.aufgeben><de> Wahrscheinlich gibt es auch einen Widerstreit zwischen Kontrollbedürfnis und der Sehnsucht danach, die Kontrolle aufzugeben.
<G-vec00739-002-s077><surrender.aufgeben><en> There is also likely to be a struggle to find a balance between needing to be in control and longing to surrender control.
<G-vec00739-002-s078><surrender.aufgeben><de> Es war ihre absolute Weigerung aufzugeben, die ihn besiegt hat.
<G-vec00739-002-s078><surrender.aufgeben><en> "It was your absolute refusal to surrender which defeated him.
<G-vec00739-002-s079><surrender.aufgeben><de> Sie werden sich schämen, vor Ablauf der Frist aufzugeben.
<G-vec00739-002-s079><surrender.aufgeben><en> You will be ashamed to surrender before the deadline.
<G-vec00739-002-s080><surrender.aufgeben><de> Wir verpflichten uns, die uns nach den vorstehenden Bestimmungen zustehenden Sicherheiten nach Wahl des Kunden aufzugeben, soweit sie die ausstehenden Forderungen um 20% übersteigen.
<G-vec00739-002-s080><surrender.aufgeben><en> We commit ourselves to surrender the securities granted us under the above provisions at the customer’s request if they exceed the outstanding claims by 20%.
<G-vec00739-002-s081><surrender.aufgeben><de> Aufzugeben und die Hälfte des Einsatzes zu verlieren (der Surrender Knopf).
<G-vec00739-002-s081><surrender.aufgeben><en> surrender, ending the game and losing one half of the bet (the "Surrender" button)
<G-vec00942-002-s088><abandon.aufgeben><de> Wenn Sie Punktlichter aufgeben möchten, ersetzen Sie sie besser durch flache Decken oder kompakte Wandlampen.
<G-vec00942-002-s088><abandon.aufgeben><en> If you want to abandon point lights, then replace them better with flat ceiling or compact sconces.
<G-vec00942-002-s089><abandon.aufgeben><de> Lee erklärte vor der Versammlung, dass die unabhängige Gewerkschaftsbewegung den Kampf für Demokratie nicht auf Druck der Zentralregierung und der Hongkonger Verwaltung aufgeben werde.
<G-vec00942-002-s089><abandon.aufgeben><en> Lee told the rally that the independent labour movement would not yield to pressure from the central government and the Hong Kong administration to abandon the struggle for democracy.
<G-vec00942-002-s090><abandon.aufgeben><de> Es erscheint mir so falsch, dass wir diese Frauen und ihre Familien aufgeben, wenn sie am dringendsten sind.
<G-vec00942-002-s090><abandon.aufgeben><en> It seems so wrong to me that we abandon these women and their families when they are in greatest need.
<G-vec00942-002-s091><abandon.aufgeben><de> Die weiße Farbe sollte wahrscheinlich die wichtigste Farbe in der Farbpalette für enge Räume sein, aber Sie müssen die hellen Entscheidungen in Ihrem kleinen Badezimmer nicht völlig aufgeben.
<G-vec00942-002-s091><abandon.aufgeben><en> White color should probably be the main one in the palette of shades for tight spaces, but you do not have to completely abandon the bright decisions in your small bathroom.
<G-vec00942-002-s092><abandon.aufgeben><de> Wir haben darüber berichtet, wie gefährliche Ideen sich in gefährlichen Zeiten, in denen die Menschen in Panik geraten und jede Vernunft aufgeben, ausbreiten können.
<G-vec00942-002-s092><abandon.aufgeben><en> We’ve talked about how dangerous ideas have a tendency of spreading in dangerous times, when people panic and abandon all reason.
<G-vec00942-002-s093><abandon.aufgeben><de> Stellen Sie sich einmal vor, wie viele Museen geschlossen werden müssten, wie viele Musikgruppen zum Schweigen gebracht; Galileo oder Darwin hätten ihre Forschungen aufgeben müssen und Monty Python hätte nicht Das Leben des Brian drehen können.
<G-vec00942-002-s093><abandon.aufgeben><en> Imagine how many museums it would be necessary to close, how many musical groups it would be necessary to silence; Galileo and Darwin would have had to abandon their research, and Monty Python would not have been able to film The Life of Brian.
<G-vec00942-002-s094><abandon.aufgeben><de> Wenn der Elitetheoretiker deshalb die Haltung des wissenschaftlichen Beobachters aufgeben muss, der bloß vorhersagt, dass die Masse der Bevölkerung immer weiter untätig bleiben wird, wenn er mit der entgegengesetzten Wirklichkeit einer revolutionären Masse konfrontiert ist, die droht, die Machtstrukturen zu stürzen, zögert er typischerweise nicht, sich auf eine ganz andere Schiene zu begeben: Er denunziert die Einmischung der Massen von unten als das Übel an sich.
<G-vec00942-002-s094><abandon.aufgeben><en> When the elitist theorist therefore has to abandon the posture of the scientific observer who is merely predicting that the mass of people will always continue quiescent, when he is faced with the opposite reality of a revolutionary mass threatening to subvert the structure of power, he is typically not behindhand in switching over to an entirely different track: denouncing mass intervention from below as evil in itself.
<G-vec00942-002-s095><abandon.aufgeben><de> Wir haben die Weisheit, die versteht, was Festhalten am Selbst ist, wie es uns schadet und wie wir es aufgeben.
<G-vec00942-002-s095><abandon.aufgeben><en> We have the wisdom that understands what self-grasping is, how it harms us and how to abandon it.
<G-vec00942-002-s096><abandon.aufgeben><de> Kein Baustil, keine Designschule kann dieses Material nicht aufgeben.
<G-vec00942-002-s096><abandon.aufgeben><en> No architectural style, no design school can not abandon this material.
<G-vec00942-002-s097><abandon.aufgeben><de> Das offensichtlichste Beispiel ist an dieser Stelle Mnuchins Forderung, dass China seinen Plan „Made in China 2025“ aufgeben müsse.
<G-vec00942-002-s097><abandon.aufgeben><en> Here, the most obvious example is Mnuchin’s demand that China abandon its “Made in China 2025” plan.
<G-vec00942-002-s098><abandon.aufgeben><de> Das Bad selbst kann eine Ecke sein, die zu einer sogenannten Kompromisslösung wird, wenn der Besitzer lange gewohnheitsmäßige und langweilige Formen aufgeben will.
<G-vec00942-002-s098><abandon.aufgeben><en> The bathroom itself can be corner, which will become a so-called compromise solution, if the owner wants to abandon long-habitual and boring forms.
<G-vec00942-002-s099><abandon.aufgeben><de> Die meisten Freie-Software-Entwickler würden solch einen Plan angesichts der Aussicht eines massenhaften Wechsels zu einer korrigierten Version von jemandem anderen aufgeben.
<G-vec00942-002-s099><abandon.aufgeben><en> msgid "" "Most free software developers would abandon such a plan given the prospect " "of a mass switch to someone else's corrected version.
<G-vec00942-002-s100><abandon.aufgeben><de> Das erklärt, warum Wölfe gelegentlich lebende, sich wehrende Kinder wegtragen, warum sie nicht unbedingt ihren Hunger stillen an den Menschen, die sie getötet haben, sondern sie aufgeben, genauso wie sie es getöteten Füchsen machen, und sie nur verlassen, auch warum Verletzungen an einer attackierten Person manchmal überraschend leicht ist, wenn man die Stärke eines Wolfskiefers betrachtet und seine potentielle Scherenkraft (CV).
<G-vec00942-002-s100><abandon.aufgeben><en> This explains why wolves on occasion carry away living, resisting children, why they do not invariably feed on the humans they killed, but may abandon such just as they may kill foxes and just leave them, and why injuries to an attacked person may at times be surprisingly light, granted the strength of a wolf’s jaw and its potential shearing power [3].
<G-vec00942-002-s101><abandon.aufgeben><de> Wenn Sie die Übersetzung aus irgendeinem Grund aufgeben, aktualisieren Sie bitte ebenfalls Ihren Eintrag im Plan, um dies anzuzeigen.
<G-vec00942-002-s101><abandon.aufgeben><en> Equally, if you abandon the translation work for any reason, please update your entry in the plan to show this.
<G-vec00942-002-s102><abandon.aufgeben><de> Es steht damit, wie mit einer andern Arbeit, die Du aufgeben kannst, wenn Dir die Lust dazu abgeht.
<G-vec00942-002-s102><abandon.aufgeben><en> It goes with this, as with any other work, which you can abandon when the desire for it abandons you.
<G-vec00942-002-s103><abandon.aufgeben><de> Sie sollten alles aufgeben, denn eine gute Figur wird keine Spur hinterlassen.
<G-vec00942-002-s103><abandon.aufgeben><en> You should abandon everything, as a good figure will not remain a trace.
<G-vec00942-002-s104><abandon.aufgeben><de> Sie werden sich elend fühlen und den Plan aufgeben.
<G-vec00942-002-s104><abandon.aufgeben><en> This will make you feel unhappy and will abandon the plan.
<G-vec00942-002-s105><abandon.aufgeben><de> Deutschland und die Europäische Union sollten jegliche höfliche Selbstbeschränkung in der öffentlichen Bewertung dieser US-Regierung aufgeben.
<G-vec00942-002-s105><abandon.aufgeben><en> Germany and the European Union should abandon polite self-restraint when dealing publicly with Trump and his government.
<G-vec00942-002-s106><abandon.aufgeben><de> Aber ich werde nicht aufgeben, jetzt strick ich erst mal Socken und dann probier ich es noch einmal.
<G-vec00942-002-s106><abandon.aufgeben><en> But I will not abandon, at first I will knit some socks and then I will give it another try.
<G-vec00942-002-s107><abandon.aufgeben><de> Die Alternative Angriff oder Abschreckung ist nämlich eine Scheinalternative: Wenn Iran seine nuklearen Pläne nicht aufgibt, sind womöglich nach einem Angriff „Containment“ und „Deterrence“ erst recht nötig – vielleicht auf Jahrzehnte.
<G-vec00942-002-s107><abandon.aufgeben><en> In fact, the supposed choice between ‘attack’ and ‘deterrence’ is a false choice: if Iran does not abandon its nuclear plans, ‘containment’ and ‘deterrence’ will be all the more needed after an attack – maybe for decades.
<G-vec00942-002-s108><abandon.aufgeben><de> Aus so komplexen und vielschichtigen Materialien wie es eben diese Massenpsychologie ist, ist es unmöglich, solche kurz reagierende Antworten zu generieren, so geschieht es oft, dass man bei aller Schätzung Brochs diese Intention wieder schnell aufgibt.
<G-vec00942-002-s108><abandon.aufgeben><en> From so complex and multiple materials, such as just this mass psychology, it is just impossible to generate such shortly reacting answers, so it happens often that, by all appreciation of Broch, we rapidly abandon again this intention.
<G-vec00942-002-s109><abandon.aufgeben><de> Wer auch nur eine Sache aufgibt, die heilig ist, dessen Verstand verfinstert sich (siehe LuB 84:54), und wenn er nicht umkehrt, wird ihm selbst das Licht genommen werden, das er empfangen hat (siehe LuB 1:33).
<G-vec00942-002-s109><abandon.aufgeben><en> Those who choose to abandon even one sacred thing will have their minds darkened (see D&C 84:54), and unless they repent, the light they have shall be taken from them (see D&C 1:33).
<G-vec00942-002-s110><abandon.aufgeben><de> Adam Montanaro, Sprecher des in New York gegründeten Falun Dafa Informationszentrums, erklärt zu der Praxis der Zwangsernährung: "Dem Gefängnis - Personal ist angeordnet worden, jeden Falun Gong Praktizierenden in Hungerstreik zwangsweise zu ernähren - um ihn am Leben zu halten in der Hoffnung, dass er durch die Verlängerung seiner Qualen vielleicht doch schließlich genötigt werden könnte, seinen Glauben aufzugeben.
<G-vec00942-002-s110><abandon.aufgeben><en> Adam Montanaro, spokesperson for the New York based Falun Dafa Information Center, remarked on the practice of forced-feeding: "The prison guards are ordered to force-feed any Falun Gong practitioners on hunger strikes - to keep them alive in the hopes that, by prolonging their torture, they may be eventually coerced to abandon their beliefs. This policy is horrifying.
<G-vec00942-002-s111><abandon.aufgeben><de> Wählen Sie nicht zu sperrige Lampen, es ist wünschenswert, sie vollständig aufzugeben.
<G-vec00942-002-s111><abandon.aufgeben><en> Choose not too bulky lamps, it is desirable to completely abandon them.
<G-vec00942-002-s112><abandon.aufgeben><de> Um dies zu tun, können Sie einen Standplatz für den Monitor abnehmbar zu machen, oder sogar, sie aufzugeben.
<G-vec00942-002-s112><abandon.aufgeben><en> To do this, you can make a stand for the monitor removable, or even to abandon it.
<G-vec00942-002-s113><abandon.aufgeben><de> Peter Martin hat eine Schwäche: Er hat hohe Ideale und ist selten bereit, sie aufzugeben.
<G-vec00942-002-s113><abandon.aufgeben><en> Peter Martin has a weakness: he has high ideals and is seldom prepared to abandon them.
<G-vec00942-002-s114><abandon.aufgeben><de> Aber wenn du dich wieder beruhigt hast und dann darüber nachdenkst, wirst du einsehen, daß dich keine meiner Handlungen dazu verpflichten wird, die Mathematik aufzugeben.
<G-vec00942-002-s114><abandon.aufgeben><en> But if you think about it when you're calmer, you'll see that nothing I have done is going to oblige you to abandon mathematics. Nothing!
<G-vec00942-002-s115><abandon.aufgeben><de> Amnesty International berichtete 2001, dass die chinesische Regierung versucht Falun Gong mit drei Strategien niederzuschlagen: Die Anwendung von Gewalt gegenüber Falun Gong-Praktizierenden, die ihren Glauben nicht aufgeben wollen; Gehirnwäsche, um alle bekannten Praktizierenden zu zwingen Falun Gong aufzugeben und zu verleumden; und eine Medienkampagne um die öffentliche Meinung gegen Falun Gong zu richten.
<G-vec00942-002-s115><abandon.aufgeben><en> Amnesty International reported in 2001 that the Chinese Government had adopted three strategies to crush Falun Gong: violence against practitioners who refuse to renounce their beliefs; brainwashing to force all known practitioners to abandon and denounce Falun Gong; and a media campaign to turn public opinion against Falun Gong.
<G-vec00942-002-s116><abandon.aufgeben><de> Ich fordere Sie dringend dazu auf, die erst kürzlich erworbenen Öl- Konzessionen in den von indigenen Völkern bewohnten ecuadorianischen Regenwaldgebieten nicht zu nutzen und die umstrittenen Projekte aufzugeben.
<G-vec00942-002-s116><abandon.aufgeben><en> I urge you not to use the recently-acquired oil concessions in the Ecuadorian rainforest inhabited by indigenous peoples and to abandon these controversial projects.
<G-vec00942-002-s117><abandon.aufgeben><de> Oft ist es ungerechtfertigt einen Plan, angesichts eines kleineren Dämpfers, verfrüht aufzugeben.
<G-vec00942-002-s117><abandon.aufgeben><en> It’s often unwarranted to abandon a plan prematurely in the face of a minor setback.
<G-vec00942-002-s118><abandon.aufgeben><de> Das Landwirtschaftsministerium der Russischen Föderation hat unter Berücksichtigung der Position von Tierschutzorganisationen beschlossen, die ursprüngliche Idee einer Teilgenehmigung für Jagd auf den baikalischen Seehund aufzugeben und ein vollständiges Verbot zu erhalten.
<G-vec00942-002-s118><abandon.aufgeben><en> The Ministry of Agriculture of the Russian Federation, taking into consideration of the position of public and animal protection organizations, has taken the decision to abandon the original idea of partial authorization for hunting the Baikal seal and to preserve the total ban on it.
<G-vec00942-002-s119><abandon.aufgeben><de> Der Diener, der mit der Tat beauftragt war, konnte sich aber nicht dazu bringen, das Kind aufzugeben; er gab das Baby einem Hirten, der ihn zum König und Königin von Korinth brachte.
<G-vec00942-002-s119><abandon.aufgeben><en> However, the servant charged with the act couldn’t bring himself to abandon the child; he gave the baby to a shepherd who brought him to the king and queen of Corinth.
<G-vec00942-002-s120><abandon.aufgeben><de> Alles in allem erfordert es eine unerschütterliche Energie – eine konstante Energie, so (unbeugsame Geste) – und gleichzeitig eine totale Bescheidenheit, die bereit ist, ALLES aufzugeben, denn alles, was existiert, ist nichts im Vergleich zu dem, was sein soll.
<G-vec00942-002-s120><abandon.aufgeben><en> It's tough. It takes both an unflinching energy – a constant energy, like this (inflexible gesture) – and at the same time, a perfect humility ready to abandon EVERYTHING, because all that is is nothing in comparison with what must be.
<G-vec00942-002-s121><abandon.aufgeben><de> Weil die Weltgesundheitsorganisation empfohlen hat, die Verwendung des Medikaments bei Kindern unter 5 Jahren aufzugeben.
<G-vec00942-002-s121><abandon.aufgeben><en> Because the World Health Organization recommended to abandon the use of the drug in children under 5 years.
<G-vec00942-002-s122><abandon.aufgeben><de> Während Russland auf der Krim vollendete Tatsachen schafft, sind die Mitgliedstaaten der EU nicht bereit, ihre Beschwichtigungspolitik aufzugeben.
<G-vec00942-002-s122><abandon.aufgeben><en> Despite the nearing Russian fait accompli in Crimea, EU member states are not willing to abandon their policy of appeasement.
<G-vec00942-002-s123><abandon.aufgeben><de> Wenn einer der Clients in die Datei schreibt, werden alle anderen Clients benachrichtigt, ihre Oplocks aufzugeben und ihre Zwischenspeicher zu löschen.
<G-vec00942-002-s123><abandon.aufgeben><en> Should one of the clients write to the file, all the other clients will be asked to abandon their Oplocks, and to empty their caches.
<G-vec00942-002-s124><abandon.aufgeben><de> Aber die jetzigen „Guten“ unter den Römern setzten ihm nur die sittliche Forderung entgegen, nicht ihren Willen; sie seufzten darüber, daß ihr Kaiser nicht der Sittlichkeit huldige wie sie: sie selber blieben „sittliche Untertanen“, bis endlich Einer den Mut fand, die „sittliche, gehorsame Untertänigkeit“ aufzugeben.
<G-vec00942-002-s124><abandon.aufgeben><en> But the contemporary “good” among the Romans only opposed moral demands to him, not their wills; they sighed that their emperor did not pay homage to morality like they did: they themselves remained “moral subjects” until one finally found the courage to abandon “moral, obedient subjection.”
<G-vec00942-002-s125><abandon.aufgeben><de> Seit drei Jahren haben Präsident Trump und sein CIA-Direktor und damaliger Außenminister Mike Pompeo versucht, den Imperialismus ihres Landes aufzugeben und ihn durch eine Wirtschaftsstrategie zu ersetzen.
<G-vec00942-002-s125><abandon.aufgeben><en> For the past three years, President Trump and his CIA director and then Secretary of State Mike Pompeo have been trying to abandon their country’s imperialism and replace it with an economic strategy.
<G-vec00942-002-s126><abandon.aufgeben><de> Wir sind anscheinend noch nicht bereit, unsere masochistischen Einsatzregeln aufzugeben, die das Volk des Feindes höher bewerten als unser eigenes.
<G-vec00942-002-s126><abandon.aufgeben><en> We are apparently not ready to abandon our masochistic rules of engagement, which privilege the enemy's people over our own.
<G-vec00942-002-s127><abandon.aufgeben><de> Unglücklicherweise zwang ihn ein Unfall während eines Wettkampfs in Linz, die schnellen Zweiräder aufzugeben.
<G-vec00942-002-s127><abandon.aufgeben><en> Unfortunately, during a competition at Linz, an accident forced him to abandon motorbikes.
<G-vec00942-002-s128><abandon.aufgeben><de> In dieser Hinsicht wird es offensichtlich, dass es keinen Sinn macht, Fette vollständig aufzugeben, aber es ist wert, ihre Aufnahme auf die normale Menge zu reduzieren.
<G-vec00942-002-s128><abandon.aufgeben><en> In this regard, it becomes obvious that it makes no sense to completely abandon fats, but it is worth reducing their intake to the normal amount.
<G-vec00942-002-s143><abandon.aufgeben><de> Die chinesische Botschaft versucht, mich dazu zu zwingen, Falun Gong aufzugeben, indem sie meinen Paß zurückhält.
<G-vec00942-002-s143><abandon.aufgeben><en> The Chinese Embassy tried to force me to abandon Falun Gong by with holding my passport.
<G-vec00942-002-s144><abandon.aufgeben><de> Wenn Euch meine Botschaft erreicht, bedeutet das, dass der Hungerstreik weitergeht und Israel beschlossen hat, darauf mit Hetze, Isolationshaft der Hungerstreikenden und Repression reagiert, in der trügerischen Hoffnung, dass uns das dazu bringen wird unseren heiligen Kampf und unsere legitimen Forderungen aufzugeben.
<G-vec00942-002-s144><abandon.aufgeben><en> If my letter reaches you that would mean the hunger strike is ongoing and Israel has decided to respond it through incitement, solitary confinement of hunger strikers and repression, with the illusion that this will make us abandon our sacred struggle and our legitimate demands.
<G-vec00942-002-s164><abandon.aufgeben><de> Vielleicht geben wir manchmal die Hoffnung auf für Palästina, Kosovo, Nord-Irland, Ruanda, Tschetschenien, Zimbabwe oder Sierra Leone.
<G-vec00942-002-s164><abandon.aufgeben><en> We may sometimes abandon hope for Palestine, for Kosovo, for Northern Ireland, for Rwanda, for Chechnya, for Zimbabwe, for Sierra Leone.
<G-vec00942-002-s165><abandon.aufgeben><de> Sie geben ihre Adressen auf, sobald die Spammer sie unbenutzbar machen.
<G-vec00942-002-s165><abandon.aufgeben><en> They abandon their mail address, as soon as the spammers make it unusable.
<G-vec00942-002-s166><abandon.aufgeben><de> Und so geraten sie in Verwirrung und Widerspruch, und schließlich geben sie das Ganze auf.
<G-vec00942-002-s166><abandon.aufgeben><en> And they get into confusion and contradiction, and then they abandon the whole thing.
<G-vec00942-002-s020><forfeit.aufgeben><de> Nach Rang 21 im ersten Lauf, musste er im Zweiten leider vorzeitig aufgeben.
<G-vec00942-002-s020><forfeit.aufgeben><en> After achieving 21st place at the first race he unfortunately had to forfeit the second prematurely.
<G-vec00942-002-s021><forfeit.aufgeben><de> Jeder Spieler, der dabei erwischt wird, absichtlich ein Online-Spiel vor dem eigentlichen Ende zu verlassen, verzögernde Taktiken zu nutzen, um andere zum Aufgeben zu bringen oder beleidigende oder obszöne Worte verwendet, riskiert durch alleinige Entscheidung seitens Days of Wonder: Das Blockieren seines Online-Kontos, das Rücksetzen seines Rangs und/oder die permanente Entfernung der Privilegien des Spielers.
<G-vec00942-002-s021><forfeit.aufgeben><en> Any player found voluntarily quitting an online game before its normal completion, using stalling tactics to induce others to forfeit, or using foul or obscene language, will face, at Days of Wonder's sole discretion: the freezing of their online account, resetting of their ranking and/or permanent removal of player privileges.
<G-vec00942-002-s022><forfeit.aufgeben><de> Surrender: Sie können aufgeben, wenn Sie denken, dass Sie verlieren werden.
<G-vec00942-002-s022><forfeit.aufgeben><en> Surrender: You can forfeit half your bet if you think you’re going to lose
<G-vec00942-002-s023><forfeit.aufgeben><de> Johns Hinterrad sprang von der Felge und er musste aufgeben.
<G-vec00942-002-s023><forfeit.aufgeben><en> John’s back wheel fell off the rim and he had to forfeit the race.
<G-vec00942-002-s043><forfeit.aufgeben><de> Wächter - Zerstörer Als zusätzliche Kosten für das Laden von Bogenschütze muss der Konzern eine Agenda aufgeben.
<G-vec00942-002-s043><forfeit.aufgeben><en> Sentry - Destroyer As an additional cost to rez Archer, the Corp must forfeit an agenda.
<G-vec00942-002-s026><forsake.aufgeben><de> Ihr könnt nicht in einer distanzierten Welt leben und die materielle Welt aufgeben, um ErLEUCHTung zu erlangen.
<G-vec00942-002-s026><forsake.aufgeben><en> You cannot live in a detached world and forsake the material world in order to attain en-Lighten-ment.
<G-vec00942-002-s027><forsake.aufgeben><de> Ich werde dich nie verlassen und aufgeben, meine Liebe.
<G-vec00942-002-s027><forsake.aufgeben><en> I will never leave you or forsake you, My love.
<G-vec00942-002-s028><forsake.aufgeben><de> Wir müssen die atheistische Weltlichkeit entschieden aufgeben und dürfen nicht einmal auf einen solchen Trend zutreiben.
<G-vec00942-002-s028><forsake.aufgeben><en> We must staunchly forsake atheistic secularism and not even drift toward such a trend.
<G-vec00942-002-s029><forsake.aufgeben><de> Ich spreche nicht von würdig gemacht werden gemäß Meinem Opfer, akzeptiert zu sein in Dem Geliebten, aber von der Würdigkeit, die von Jenen gezeigt wird, die ihr Leben in dieser Welt aufgeben, damit sie ihr Leben in Mir finden können… Welches das ewige Leben ist.
<G-vec00942-002-s029><forsake.aufgeben><en> I speak not of being made worthy according to My sacrifice, being accepted in The Beloved, but of the worthiness shown by those who forsake their lives in this world, that they might find their life in Me… Which is life eternal.
<G-vec00942-002-s030><forsake.aufgeben><de> Ruggieros größte Nummer—die auch oft in Händels eigenen Aufführungen als Zugabe gesungen wurde—ist „Verdi prati“, eine Sarabande in E-Dur von einer schmerzvollen nostalgischen Süße, in der er sich von den visuellen (und damit erotischen) Reizen verabschiedet, die er aufgeben muss.
<G-vec00942-002-s030><forsake.aufgeben><en> Ruggiero’s greatest number—and one often encored in Handel’s own performances—is ‘Verdi prati’, an E major sarabande of aching nostalgic sweetness in which he bids a lingering farewell to the visual, and by implication the erotic, delights he must forsake.
<G-vec00942-002-s031><forsake.aufgeben><de> Obwohl es unangemessen ist, den Wunsch aufzugeben, dass eine derartige Person glücklich sein und die Ursachen des Glücks besitzen möge, begehen wir eine Hauptübertretung, wenn wir uns ihnen gegenüber liebevoll verhalten oder liebevoll mit ihnen sprechen.
<G-vec00942-002-s031><forsake.aufgeben><en> Although it is inappropriate to forsake the wish for such persons to be happy and have the causes for happiness, we commit a root downfall by acting or speaking lovingly toward them.
<G-vec00942-002-s032><forsake.aufgeben><de> Sowie sie sich ihm enthüllt, so ist er auch bereit, alles dafür aufzugeben.
<G-vec00942-002-s032><forsake.aufgeben><en> The instant it reveals itself to him however, he is certainly ready to forsake everything for its sake.
<G-vec00942-002-s033><forsake.aufgeben><de> Sie sind in der Lage, ihren Körper zu unterdrücken und ihr Fleisch aufzugeben.
<G-vec00942-002-s033><forsake.aufgeben><en> They are able to subdue their body and forsake their flesh.
<G-vec00942-002-s034><forsake.aufgeben><de> Wohlmeinende Leute sind jetzt wie damals allzu gerne bereit, den „Wahrheitsteil“ von der Anbetung „im Geist und in Wahrheit“ aufzugeben.
<G-vec00942-002-s034><forsake.aufgeben><en> Well-intentioned people are now as they were then all too willing to forsake the "truth" part of worshipping "in Spirit and in Truth."
<G-vec00942-002-s047><forsake.aufgeben><de> Jesus befiehlt uns unsere Gemeinschaft miteinander nicht aufzugeben, sondern diese Zeit dazu zu nutzen uns gegenseitig zu Liebe und guten Werken zu ermutigen (Hebräer 10,24-25).
<G-vec00942-002-s047><forsake.aufgeben><en> Jesus commands us not to forsake the assembling of ourselves together but to use that time for encouraging one another in love and good works (Hebrews 10:24).
<G-vec00942-002-s042><relinquish.aufgeben><de> Dennoch konnte ich mich einfach nicht dazu überwinden zu sagen, dass ich die Position aufgeben würde und dass Roland stattdessen meinen Platz einnehmen sollte.
<G-vec00942-002-s042><relinquish.aufgeben><en> Even so, I just couldn’t bring myself to say that I would relinquish the position and that I would like Roland to take my place instead.
<G-vec00942-002-s043><relinquish.aufgeben><de> Agenda Setting ist ein Königsrecht, wir sollten es nicht einfach aufgeben.
<G-vec00942-002-s043><relinquish.aufgeben><en> Agenda setting is a royal privilege; we shouldn’t simply relinquish it.
<G-vec00942-002-s044><relinquish.aufgeben><de> Bald vier Jahrhunderte Freiheit, Selbstbestimmung und Reichsunmittelbarkeit sollten wir Bremer jedenfalls nicht einfach so aufgeben.
<G-vec00942-002-s044><relinquish.aufgeben><en> The people of Bremen shouldn’t simply relinquish almost four centuries of freedom, self‑determination and imperial immediacy.
<G-vec00942-002-s045><relinquish.aufgeben><de> Das ist sein diesbezüglich vorgegebenes schöpferisch-natürliches Recht, durch das er ausnahmslos selbst bestimmt, was er tun und lassen und was er weitertun oder aufgeben will.
<G-vec00942-002-s045><relinquish.aufgeben><en> This is his/her pre-given creational-natural right in this respect, through which he/she, without exception, determines himself/herself what he/she wants to do and allow and what he/she wants to continue to do or relinquish.
<G-vec00942-002-s046><relinquish.aufgeben><de> Die jüngsten Aktionen von Donald Trump beweisen, dass er sein Amt nicht einfach und kampflos aufgeben wird.
<G-vec00942-002-s046><relinquish.aufgeben><en> Donald Trump’s recent actions prove that he will not relinquish his office easily and without a fight.
<G-vec00942-002-s047><relinquish.aufgeben><de> Unter den früheren Gruppenzugehörigkeiten, welche Beigetretene häufig aufgeben, sind ihre Familien (Stahelski, 2004: 33).
<G-vec00942-002-s047><relinquish.aufgeben><en> Among previous group affiliations that joiners frequently relinquish are their families (Stahelski, 2004:33).
<G-vec00942-002-s048><relinquish.aufgeben><de> Auf der einen Seite darf die Kunst nie ihren Selbstwert aufgeben, sich von kulturpolitischen Strukturen abhängig machen und muss sich auf ihre immanente Stärke und Unabhängigkeit besinnen.
<G-vec00942-002-s048><relinquish.aufgeben><en> On the one hand, art must never relinquish its intrinsic worth by letting itself become dependent on culturo-political structures; it must always remember the strength and independence it has in its own right.
<G-vec00942-002-s049><relinquish.aufgeben><de> Das Ändern der Behörden des Präsidenten, ist dem Ändern der Verfassung unterworfen; der Präsident kann nicht seine Behörden einfach aufgeben, er hat das Grundrecht dazu nicht.
<G-vec00942-002-s049><relinquish.aufgeben><en> Changing the authorities of the president is subject to changing the constitution; the president cannot just relinquish his authorities, he doesn’t have the constitutional right.
<G-vec00942-002-s050><relinquish.aufgeben><de> Sie müssen Hypothekendarlehen oder andere Schulden auf das Eigentum, das Sie aufgeben und alle Schulden auf dem Ersatzeigentum betrachten.
<G-vec00942-002-s050><relinquish.aufgeben><en> You must consider mortgage loans or other debt on the property you relinquish, and any debt on the replacement property.
<G-vec00942-002-s051><relinquish.aufgeben><de> Auch nach der dritten Zerstörung, keiner Zerstörung des Tempels, haben wir nicht aufgegeben.
<G-vec00942-002-s051><relinquish.aufgeben><en> Even after the third destruction – not of the Temple this time – we did not relinquish our bond.
<G-vec00942-002-s052><relinquish.aufgeben><de> Hotelzimmer in Deutschland werden immer kleiner und effizienter – ohne ihr stylisches Design aufzugeben.
<G-vec00942-002-s052><relinquish.aufgeben><en> Hotel rooms in Germany are becoming increasingly smaller and more efficient, without having to relinquish their stylish design standards.
<G-vec00942-002-s053><relinquish.aufgeben><de> „Die Regierung der Vereinigten Staaten hat ihre Bereitschaft angekündigt, das Vetorecht gegen eine Nation aufzugeben, die die geplanten Atomkraftkontrollen verletzt.
<G-vec00942-002-s053><relinquish.aufgeben><en> „The United States Government has announced its willingness to relinquish the right to veto collective action against a nation violating the projected atomic energy controls.
<G-vec00942-002-s054><relinquish.aufgeben><de> Der einzige Ausweg aus diesem Mummenschanz ist, das Ego aufzugeben – indem wir die Wahre Göttliche Liebe finden, empfangen und unser Leben in Einklang mit Ihr bringen.
<G-vec00942-002-s054><relinquish.aufgeben><en> And the only way "out" of this mummery is to relinquish ego — by finding, receiving, and conforming ourselves to the Divine True Love.
<G-vec00942-002-s060><relinquish.aufgeben><de> Nein, es ist das Aufgeben der belle peinture in einer Art malerischem Orgasmus.
<G-vec00942-002-s060><relinquish.aufgeben><en> No, it is to relinquish the belle peinture in a kind of orgasm of painting.
<G-vec00942-002-s067><renounce.aufgeben><de> Dass sie verstehen, dass wir unsere Gesellschaft perfektionieren, an die Aktualität anpassen, wozu auch unsere Beziehungen zu den Vereinigten Staaten gehören, die ganz klar definiert sind, die wir gerne wie mit jedem anderen Land der Welt normalisieren möchten, aber dass es Prinzipien gibt, die wir niemals aufgeben.
<G-vec00942-002-s067><renounce.aufgeben><en> So they understand that we are perfecting our society, adjusting ourselves to the current times, including our relations with the United States, which are very well defined and we hope to normalize, like those with any other country in the world, but there are principles that we will never renounce.
<G-vec00942-002-s068><renounce.aufgeben><de> Sie müssen ihre bestehende Staatsbürgerschaft aufgeben, ihre Russischkenntnisse nachweisen und eine Bittschrift von der Armeeführung einholen, aber es ist keine Aufenthaltsgenehmigung erforderlich.
<G-vec00942-002-s068><renounce.aufgeben><en> They must renounce their existing citizenship, prove their knowledge of Russian and obtain a petition from the army's leadership, but no residency permit is needed.
<G-vec00942-002-s069><renounce.aufgeben><de> Bei dieser Entmutigung und Abnahme seiner Truppen musste Witichis den Gedanken, die Stadt mit Sturm zu nehmen, aufgeben und seine letzte Hoffnung—er verhehlte sich ihre Schwäche nicht—bestand in der Möglichkeit, der Mangel werde den Feind zur Übergabe zwingen.
<G-vec00942-002-s069><renounce.aufgeben><en> In consequence of this discouragement and the decimation of his troops, Witichis was obliged to renounce the idea of taking the city by storm, and his last hope—he did not conceal from himself its weakness—lay in the possibility that famine would force the enemy to capitulate.
<G-vec00942-002-s070><renounce.aufgeben><de> Mein Herzenswunsch ist es, dass sie ihr Leben in der Dunkelheit aufgeben und ans Licht kommen, um wieder hergestellt zu werden in der Fülle, die Ich für sie bei der Zeugung beabsichtigt hatte.
<G-vec00942-002-s070><renounce.aufgeben><en> And My heart for them is that they renounce their lives in the darkness, and come into the Light to be restored to the fullness I intended for them at conception.
<G-vec00942-002-s071><renounce.aufgeben><de> Ich werde nicht aufgeben.
<G-vec00942-002-s071><renounce.aufgeben><en> I will not renounce.
<G-vec00942-002-s072><renounce.aufgeben><de> Wenn Praktizierende innerhalb eines Monats ihren Glauben an Falun Gong nicht aufgeben, kommen sie in Einzelhaft mit verriegelten Fenstern und verschlossenen Türen.
<G-vec00942-002-s072><renounce.aufgeben><en> If practitioners refuse to renounce their belief in Falun Gong after one month, they will be locked in solitary confinement with the window and door closed.
<G-vec00942-002-s073><renounce.aufgeben><de> Kuba wird niemals seine Souveränität oder den von seinem Volk frei gewählten Weg zum Aufbau eines gerechteren und effizienten, gedeihenden und nachhaltigen Sozialismus aufgeben.
<G-vec00942-002-s073><renounce.aufgeben><en> Cuba will never renounce its sovereignty, or the path freely chosen by its people to build a more just, efficient, prosperous and sustainable socialism.
<G-vec00942-002-s074><renounce.aufgeben><de> Um nach Hause und in das Königreich des Goldenen Zeitalters zu gehen, müsst ihr nämlich euren alten Körper aufgeben.
<G-vec00942-002-s074><renounce.aufgeben><en> This is because, in order to go home and to the golden-aged kingdom, you have to renounce your old body.
<G-vec00942-002-s075><renounce.aufgeben><de> Als die Polizei dann irgendwann feststellte, dass sie ihren Glauben nicht aufgeben würde, schickten sie Frau Liu zur „Umerziehung“ zurück ins Jiangshuiquan-Zwangsarbeitslager.
<G-vec00942-002-s075><renounce.aufgeben><en> Sometime after, the police saw that she still wouldn’t renounce her faith, so they sent her back to Jiangshuiquan Forced Labour Camp to have collaborators try to "transform" her.
<G-vec00942-002-s076><renounce.aufgeben><de> Er muss jeden Fall mit sicherem Wissen behandeln und darf niemals einen Fall verlassen oder aufgeben.
<G-vec00942-002-s076><renounce.aufgeben><en> he must treat each case with sure knowledge and never must abandon or renounce any case;
<G-vec00942-002-s077><renounce.aufgeben><de> Die Übeltäter schrien sie an: „Wenn du das Abschreiben nicht fertig kriegst, musst du Falun Dafa aufgeben!“ Ich schloss einmal einen Kompromiss mit ihnen ab.
<G-vec00942-002-s077><renounce.aufgeben><en> The evildoers would shout at them, "If you fail to finish copying them, you must renounce Falun Gong!" I had compromised with the evildoers before.
<G-vec00942-002-s078><renounce.aufgeben><de> Es ist sehr wohl möglich, dass im heutigen China niemand glauben würde, dass jemand nur dafür eingesperrt wird, weil er ein guter Mensch sein und seinen Glauben nicht aufgeben will.
<G-vec00942-002-s078><renounce.aufgeben><en> It is very possible that in present-day China no one would believe that someone would be detained merely for wanting to be a good person and for not wanting to renounce ones beliefs.
<G-vec00942-002-s079><renounce.aufgeben><de> Ihre Familie wurde auseinandergerissen, als ihr Mann Herr Chen Chengyong ermordet wurde, während er sich in Polizeigewahrsam befand, da er seinen Glauben an und seine Unterstützung für Falun Gong nicht aufgeben wollte.
<G-vec00942-002-s079><renounce.aufgeben><en> Her family fell apart when her husband Mr Chen Chengyong was killed while in police custody because he didn’t renounce his belief and support for Falun Gong.
<G-vec00942-002-s080><renounce.aufgeben><de> Ihn aufgeben und aktiv vertrauen, dass Du diese Prüfung nutzt für das Königreich.
<G-vec00942-002-s080><renounce.aufgeben><en> Renounce him and actively trust that You are using this trial for the Kingdom.
<G-vec00942-002-s081><renounce.aufgeben><de> Sie drohten mir und forderten, dass ich meinen Glauben aufgeben solle, was ich ablehnte.
<G-vec00942-002-s081><renounce.aufgeben><en> They threatened me and demanded that I renounce my belief, which I refused.
<G-vec00942-002-s082><renounce.aufgeben><de> Amnesty International berichtete 2001, dass die chinesische Regierung versucht Falun Gong mit drei Strategien niederzuschlagen: Die Anwendung von Gewalt gegenüber Falun Gong-Praktizierenden, die ihren Glauben nicht aufgeben wollen; Gehirnwäsche, um alle bekannten Praktizierenden zu zwingen Falun Gong aufzugeben und zu verleumden; und eine Medienkampagne um die öffentliche Meinung gegen Falun Gong zu richten.
<G-vec00942-002-s082><renounce.aufgeben><en> Amnesty International reported in 2001 that the Chinese Government had adopted three strategies to crush Falun Gong: violence against practitioners who refuse to renounce their beliefs; brainwashing to force all known practitioners to abandon and denounce Falun Gong; and a media campaign to turn public opinion against Falun Gong.
<G-vec00942-002-s083><renounce.aufgeben><de> Jedoch erleben Praktizierende, die ihren Glauben nicht aufgeben wollen, oft mehr als nur Gehirnwäschen und seelische Misshandlung.
<G-vec00942-002-s083><renounce.aufgeben><en> However, unyielding practitioners who refused to renounce their belief often face more than just forced brainwashing and psychological abuse.
<G-vec00942-002-s085><renounce.aufgeben><de> Er brachte Kleidung und Essen, aber er durfte seine Frau nicht sehen, weil sie es weiterhin ablehnte, Falun Gong aufzugeben.
<G-vec00942-002-s085><renounce.aufgeben><en> He brought clothes and food, but was not allowed to see his wife due to her refusal to renounce Falun Gong.
<G-vec00942-002-s086><renounce.aufgeben><de> 2004 verurteilte man sie zu neun Jahren Gefängnis, als sie sich weigerte, Falun Gong aufzugeben.
<G-vec00942-002-s086><renounce.aufgeben><en> She was sentenced to a 9-year prison term in 2004 for refusing to renounce Falun Gong.
<G-vec00942-002-s087><renounce.aufgeben><de> Bereits im März 2000 war er zu dreieinhalb Jahren Zwangsarbeit verurteilt worden, weil er sich geweigert hatte, Falun Gong aufzugeben.
<G-vec00942-002-s087><renounce.aufgeben><en> Back in March of 2000 he was sentenced to three and a half years of forced labour for refusing to renounce Falun Gong.
<G-vec00942-002-s088><renounce.aufgeben><de> Wenngleich viele ihre frühere Berechnung der prophetischen Zeitangaben fahren ließen und die Richtigkeit der darauf gegründeten Bewegung verneinten, so waren andere doch nicht willens, Punkte des Glaubens und der Erfahrung aufzugeben, welche durch die Heilige Schrift und das Zeugnis des Geistes Gottes unterstützt wurden.
<G-vec00942-002-s088><renounce.aufgeben><en> Though many abandoned their former reckoning of the prophetic periods and denied the correctness of the movement based thereon, others were unwilling to renounce points of faith and experience that were sustained by the Scriptures and by the witness of the Spirit of God.
<G-vec00942-002-s089><renounce.aufgeben><de> Ohne biblische Beweise konnten sie nicht einwilligen, den Standpunkt aufzugeben, den sie durch ernstes, andächtiges Forschen in der Heiligen Schrift mit vom Geiste Gottes erleuchteten Sinnen und von seiner lebendigen Kraft brennenden Herzen erreicht hatten; einen Standpunkt, welcher den scharfsinnigsten Beurteilungen und den bittersten Anfeindungen volkstümlicher religiöser Lehren und weltweiser Männer widerstanden hatte, und welcher vor den vereinten Anstrengungen der Gelehrsamkeit und der Beredsamkeit und den Witzen und Spötteleien derer von achtbarer sowohl als auch von niedriger Gesinnung fest und unerschüttert geblieben war.
<G-vec00942-002-s089><renounce.aufgeben><en> They could not consent, without Bible evidence, to renounce positions which had been reached through earnest, prayerful study of the Scriptures, by minds enlightened by the Spirit of God and hearts burning with its living power; positions which had withstood the most searching criticisms and the most bitter opposition of popular religious teachers and worldly-wise men, and which had stood firm against the combined forces of learning and eloquence, and the taunts and revilings alike of the honorable and the base.
<G-vec00942-002-s090><renounce.aufgeben><de> Trotzdem ließen die Gefängnisbeamten Frau Guan nicht zur medizinischen Behandlung frei, weil sie sich weigerte, ihren Glauben an Falun Gong aufzugeben.
<G-vec00942-002-s090><renounce.aufgeben><en> Nevertheless, prison officials did not allow Ms. Guan to be released for medical treatment because she refused to renounce her belief in Falun Gong.
<G-vec00942-002-s091><renounce.aufgeben><de> Die Behörden hatten es auf ihn abgesehen, weil er sich geweigert hatte, Falun Gong aufzugeben.
<G-vec00942-002-s091><renounce.aufgeben><en> The authorities targeted Mr. Tian because he refused to renounce Falun Gong, a spiritual discipline being persecuted by the Chinese communist regime.
<G-vec00942-002-s092><renounce.aufgeben><de> Zu einem anderen Beispiel: Der Wärter Fan Yasheng verbrannte Herr Zhou Changhe`s Bart und Kinn mit einem Feuerzeug und wollte dadurch Her Zhou zwingen, Falun Gong aufzugeben.
<G-vec00942-002-s092><renounce.aufgeben><en> In another example, guard Fan Yasheng burned Mr. Zhou Changhe's beard and chin with a lighter when he was trying to force Mr. Zhou to renounce Falun Gong.
<G-vec00942-002-s093><renounce.aufgeben><de> Yang weigerte sich, Falun Gong aufzugeben und wurde Ende 2017 heimlich zu drei Jahren Gefängnis verurteilt.
<G-vec00942-002-s093><renounce.aufgeben><en> Mr. Yang refused to renounce Falun Gong and was secretly sentenced to three years in prison in late 2017.
<G-vec00942-002-s094><renounce.aufgeben><de> Da sie sich weigerte, ihren Glauben an Wahrhaftigkeit, Barmherzigkeit und Nachsicht aufzugeben, wurde sie interniert.
<G-vec00942-002-s094><renounce.aufgeben><en> She refused to renounce her belief in Truthfulness-Compassion-Forbearance, and was thus detained.
<G-vec00942-002-s095><renounce.aufgeben><de> Aber es ist nicht einfach, die Macht ganz aufzugeben, nachdem man sie fast ein Vierteljahrhundert lang auf totalitäre Weise ausgeübt hat.
<G-vec00942-002-s095><renounce.aufgeben><en> But it is not easy to renounce absolute power absolutely, after wielding it for nearly a quarter of a century, in a totalitarian fashion.
<G-vec00942-002-s096><renounce.aufgeben><de> Er musste schwere Arbeit verrichten und wurde oft geschlagen, weil er sich weigerte, Falun Gong aufzugeben.
<G-vec00942-002-s096><renounce.aufgeben><en> He was forced to perform heavy labour and beaten many times because he refused to renounce Falun Gong.
<G-vec00942-002-s097><renounce.aufgeben><de> Als Huang sich der Forderung der Behörden, Falun Gong aufzugeben, verweigerte, befahlen die Wärter den Gefangenen, ihn wiederholt mit Schraubenschlüssel zu schlagen.
<G-vec00942-002-s097><renounce.aufgeben><en> When Mr. Huang refused to renounce Falun Gong at the authorities' demands, guards ordered inmates to hit him repeatedly with wrenches.
<G-vec00942-002-s098><renounce.aufgeben><de> Sie fügten ihm enorme Schmerzen zu und versuchten, ihn dazu zu bringen, Falun Gong aufzugeben.
<G-vec00942-002-s098><renounce.aufgeben><en> They caused him excruciating pain, trying to force him to give in and renounce Falun Gong.
<G-vec00942-002-s099><renounce.aufgeben><de> Dann sagte mir der Dämon, ich solle die Kraft in ihr sehen und beobachten, die sie dazu drängt, aufzugeben und nicht zu gehen.
<G-vec00942-002-s099><renounce.aufgeben><en> Then, the demon said to me, look and observe the power inside her pressuring her to renounce and not to go.
<G-vec00942-002-s100><renounce.aufgeben><de> Im Zuge des Versuchs der Kommunistischen Partei Chinas (KPCh), ihn zu zwingen, seinen Glauben aufzugeben, musste er schwere Arbeit verrichten und Videos zur Gehirnwäsche anschauen.
<G-vec00942-002-s100><renounce.aufgeben><en> He was forced to do heavy labour and watch brainwashing videos as part of the Chinese Communist Party's attempt to force him to renounce his belief.
<G-vec00942-002-s101><renounce.aufgeben><de> Hier fand eine strategische Instrumentalisierung des Critical Whiteness Diskurses auf eine dogmatische Art statt, die von Menschen gefordert hat, ihre Fähigkeit autonom zu reflektieren aufzugeben und stattdessen einem sogenannten politisch korrekten Dogma zu folgen.
<G-vec00942-002-s101><renounce.aufgeben><en> This has been a strategical instrumentalization of the critical whiteness discourse in a dogmatic manner which required people to renounce their ability to autonomously reflect but instead to follow a so-called politically correct dogma.
<G-vec00942-002-s102><renounce.aufgeben><de> Praktizierende, die es ablehnen, Falun Gong aufzugeben, werden streng überwacht und daran gehindert, mit anderen zu sprechen.
<G-vec00942-002-s102><renounce.aufgeben><en> Practitioners who refuse to renounce Falun Gong are closely watched and prevented from talking to others.
<G-vec00942-002-s103><renounce.aufgeben><de> Wenn die Praktizierenden sich weigern, Falun Gong aufzugeben, werden sie gezwungen auf einem Stock aus Holz oder auf einem schmalen Brett aus Holz zu sitzen, was verursacht, dass ihre Gesäße innerhalb von zwei Tagen aufgescheuert sind.
<G-vec00942-002-s103><renounce.aufgeben><en> If the practitioners refuse to renounce Falun Gong, they will be forced to sit on a wooden stick or narrow wooden board, which will cause their buttocks to be rubbed raw within 2 days.
<G-vec00942-002-s104><renounce.aufgeben><de> „Viele meiner Mitpraktizierenden wurden in Arbeitslager gesteckt, äußerst brutal gefoltert und gezwungen, ihren Glauben aufzugeben“, sagte Frau Zhang gegenüber einem Übersetzer.
<G-vec00942-002-s104><renounce.aufgeben><en> "A lot of my fellow practitioners were sent to labour camps and brutally, brutally tortured and forced to renounce their beliefs," Ms. Zhang said through a translator.
<G-vec00942-002-s105><renounce.aufgeben><de> Da meine Eltern nicht bereit waren, ihre Kultivierung aufzugeben, wurden sie zu Opfern der Verfolgung durch die Kommunistische Partei Chinas.
<G-vec00942-002-s105><renounce.aufgeben><en> As my parents refused to renounce the cultivation, they became the focus of the Chinese Communist Party's persecution of Falun Gong practitioners.
<G-vec00942-002-s115><renounce.aufgeben><de> Zwei Insassen wurden ausgewählt, um mich rund um die Uhr zu überwachen und mich dazu zu bringen, das Praktizieren von Falun Gong aufzugeben.
<G-vec00942-002-s115><renounce.aufgeben><en> Two inmates were assigned to monitor me around the clock to try to make me renounce Falun Gong.
<G-vec00942-002-s116><renounce.aufgeben><de> Das oben abgedruckte Zitat ist ein Auszug aus dem Bericht der Praktizierenden Frau Wang Yuhuan aus Changchun, die von der Polizei gefoltert wurde, indem man ihr die Armgelenke ausrenkte, um sie dazu zu bringen, ihren Glauben aufzugeben.
<G-vec00942-002-s116><renounce.aufgeben><en> Above is an excerpt from Changchun practitioner Ms. Wang Yuhuan’s account of how the police dislocated her arms to try to make her renounce her belief.
<G-vec00942-002-s120><renounce.aufgeben><de> Doch Herr Li weigerte sich, Falun Gong aufzugeben.
<G-vec00942-002-s120><renounce.aufgeben><en> Mr. Li refused to renounce Falun Gong.
<G-vec00942-002-s147><renounce.aufgeben><de> Weil er es ablehnte, eine Garantie-Erklärung [Falun Gong aufzugeben] zu unterzeichnen, wurde er zu zwei Jahren Gefängnis verurteilt.
<G-vec00942-002-s147><renounce.aufgeben><en> He was sentenced to two years in prison after refusing to sign a guarantee statement to renounce practising Falun Gong.
<G-vec00942-002-s148><renounce.aufgeben><de> Sie geben jedes Zuhause auf, jedes Zuhause, wie Schwäne, die von einem See abheben.
<G-vec00942-002-s148><renounce.aufgeben><en> They renounce every home, every home, like swans taking off from a lake.
<G-vec00942-002-s153><renounce.aufgeben><de> Indes sagte ich mir, dass, falls die KPC wirklich Falun Gong verbietet, ich würde es nicht aufgeben.
<G-vec00942-002-s153><renounce.aufgeben><en> I said to myself that if the CCP indeed banned Falun Gong, I would not renounce it.
<G-vec00942-002-s159><renounce.aufgeben><de> Diejenigen, die sich standhaft weigerten, ihren Glauben nicht aufzugeben, sperrte man für längere Zeit in Einzelhaft, ihnen wurde die Nutzung der Toilette verweigert und sie wurden gezwungen, mehr als 20 Stunden pro Tag auf einem kleinen Kunststoffstuhl zu sitzen.
<G-vec00942-002-s159><renounce.aufgeben><en> Those who refused to renounce their belief were kept in solitary confinement for long periods of time, denied use of the toilet, and forced to sit on a small plastic stool for over 20 hours a day.
<G-vec00942-002-s249><renounce.aufgeben><de> Praktizierende zeigten verschiedene Foltermethoden, die gegen die Praktizierenden in chinesischen Gefängnissen und Zwangsarbeitslagern verwendet werden, um sie dazu zu zwingen, ihren Glauben an Falun Gong aufzugeben.
<G-vec00942-002-s249><renounce.aufgeben><en> Practitioners demonstrated several torture methods used against Falun Gong practitioners in Chinese jails and labour camps to force them to renounce their belief in Falun Gong.
<G-vec00942-002-s029><resign.aufgeben><de> Eine halbe Stunde lang dachte ich, dass ich aufgeben werde, weil mein Remisangebot nicht angenommen wurde, denn es sah so hoffnungslos aus.
<G-vec00942-002-s029><resign.aufgeben><en> For half an hour I actually thought since my draw offer was not taken I will just resign, because it looked completely hopeless.
<G-vec00942-002-s030><resign.aufgeben><de> In dem Auswahlfeld rechts neben der Zuganzeige können Sie zwischen "normaler Zug", "Remis anbieten" und "aufgeben" wählen.
<G-vec00942-002-s030><resign.aufgeben><en> The selection box to the right of the move display allows you to choose between "Normal move", "Offer draw" or "Resign".
<G-vec00942-002-s031><resign.aufgeben><de> Hr, Florian Riegler, der seine Position als Kassenwart aufgrund hoher Arbeits- belastung aufgeben wird, wurde für seine Arbeit gewürdigt und mit einem Geschenk verabschiedet.
<G-vec00942-002-s031><resign.aufgeben><en> Mr, Florian Riegler, who will resign from his post of treasurer due to his increased workload, was prized for his outstanding performance and disbanded with a present.
<G-vec00942-002-s032><resign.aufgeben><de> Alle Vorzeichen sprechen von einer düsteren Zeit nach der Wahl, gleichgültig, ob Conté den Wahltag noch erlebt oder in absehbarer Zeit danach das Amt aufgeben muss.
<G-vec00942-002-s032><resign.aufgeben><en> All signs point to a bleak time following the election, regardless of whether Conté lives to experience election day or has to resign soon after the election.
<G-vec00942-002-s033><resign.aufgeben><de> Im Auftrag Gottes fordere ich, dass die Priester, vom Gott als „Bestie“ bezeichnet, die Lehren über die Sachen Gottes aufgeben.
<G-vec00942-002-s033><resign.aufgeben><en> Upon the order of God I demand that the Priests referred to by God as the Beast resign from teachings concerning the matters of God.
<G-vec00942-002-s071><waive.aufgeben><de> Das sieht man klar im Evangelium: Ein junger Mann entfernte sich um seinen Reichtum nicht aufzugeben, während mein Sohn ihn liebte.
<G-vec00942-002-s071><waive.aufgeben><en> This is clearly seen in the Gospel: A young man leaves in order to not waive the wealth, while My Son loved him.
