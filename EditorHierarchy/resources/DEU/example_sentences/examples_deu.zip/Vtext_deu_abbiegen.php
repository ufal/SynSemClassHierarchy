<G-vec00057-001-s038><turn.abbiegen><de> Nach 2.5 Km rechts abbiegen, Richtung Nizza Monferrato (19.5 Km).
<G-vec00057-001-s038><turn.abbiegen><en> After 2.5 Km, turn right in the direction of Nizza Monferrato (Km. 19.5).
<G-vec00057-001-s039><turn.abbiegen><de> Abbiegen Richtung Ockelbo Straße 303. dann Richtung Zentrum und dann an der Kirche vorbei und biegen Sie die erste Straße rechts auf Åmotvägen gegen Rönnåsen.
<G-vec00057-001-s039><turn.abbiegen><en> Turn towards Ockelbo road 303rd Drive then towards the center and then past the church and turn first right on Åmotvägen against Rönnåsen.
<G-vec00057-001-s040><turn.abbiegen><de> Bei die Kreuzung-Straße zu erreichen; rechts abbiegen.
<G-vec00057-001-s040><turn.abbiegen><en> When reaching the crossing road; turn right.
<G-vec00057-001-s041><turn.abbiegen><de> "Am ""Doppel M"" rechts abbiegen in die Alte Messe und 400 m geradeaus bis zum Pantheon."
<G-vec00057-001-s041><turn.abbiegen><en> "Turn right at the ""double M""-sign and go straight for 400 m till you reach the Pantheon."
<G-vec00057-001-s042><turn.abbiegen><de> Im Jahr 1916 bauten wir rechts abbiegen.
<G-vec00057-001-s042><turn.abbiegen><en> In 1916, we built the right turn.
<G-vec00057-001-s043><turn.abbiegen><de> An der Kirche rechts abbiegen und Via Lamarmora nehmen.
<G-vec00057-001-s043><turn.abbiegen><en> At the church turn right and take Via Lamarmora.
<G-vec00057-001-s044><turn.abbiegen><de> Am Ende des König-George Street rechts abbiegen in die Randall Street und weiter einen Block bis zur ersten Ampel, die die Schnittmenge von Randall und Prince George Street ist.
<G-vec00057-001-s044><turn.abbiegen><en> At the end of King George Street make a right turn onto Randall Street and continue one block to the first traffic light, which is the intersection of Randall Street and Prince George Street.
<G-vec00057-001-s045><turn.abbiegen><de> Von Livigno nehmen wir den Passo del Foscagno und gelangen so nach Bormio, wo wir Richtung Umbrailpass/Stilfserjoch abbiegen.
<G-vec00057-001-s045><turn.abbiegen><en> From Livigno we take the Passo del Foscagno and come to Bormio, where we will turn to Umbrailpass/Stilfserjoch.
<G-vec00057-001-s046><turn.abbiegen><de> Gleich danach nach links abbiegen und der Straße folgen.
<G-vec00057-001-s046><turn.abbiegen><en> Turn left shortly afterwards and follow the road.
<G-vec00057-001-s047><turn.abbiegen><de> An den Häusern, rechts abbiegen und dann, höher, weiter in Richtung Les Grangeols.
<G-vec00057-001-s047><turn.abbiegen><en> At the houses, turn right and then, higher up, continue towards Les Grangeols.
<G-vec00057-001-s048><turn.abbiegen><de> (4 km) bis ins Stadtgebiet - 300m nach der Shell-Tankstelle an der großen Ampelkreuzung rechts abbiegen (Ausschilderung Hotelroute), nach 700 m rechts abbiegen und der Ausschilderung Parkhotel folgen.
<G-vec00057-001-s048><turn.abbiegen><en> (4 km) into the town - Turn right 300 m after the Shell gas station at the major traffic light intersection (Hotel route sign), after 700 m turn right and follow signs for the Parkhotel.
<G-vec00057-001-s049><turn.abbiegen><de> An der dritten Ampel rechts abbiegen Richtung Furtwangen/Kurgebiet/Polizei.
<G-vec00057-001-s049><turn.abbiegen><en> At the third traffic lights, turn right towards Furtwangen/Kurgebiet/Polizei.
<G-vec00057-001-s050><turn.abbiegen><de> Richtung Novigrad - Tar: An der Kreuzung bei der Tankstelle rechts zu Lanterna abbiegen.
<G-vec00057-001-s050><turn.abbiegen><en> Novigrad - Tar direction: Turn right at the intersection towards Lanterna at the petrol station.
<G-vec00057-001-s051><turn.abbiegen><de> Sie erreichen eine Kreuzung, an der Sie Rechts auf eine Asphaltstraße abbiegen, die Sie zum Restaurant führt.
<G-vec00057-001-s051><turn.abbiegen><en> You will reach a crossroads where you will turn right onto an asphalt road that will take you to a restaurant.
<G-vec00057-001-s052><turn.abbiegen><de> Wenn Sie links abbiegen, kommen Sie zur Anlegestelle der Spree – gut geeignet für eine Kaffeepause.
<G-vec00057-001-s052><turn.abbiegen><en> If you turn left, you will come to the pier on the Spree, a fine spot for a coffee break.
<G-vec00057-001-s053><turn.abbiegen><de> Vor der Brücke der Mühle, am Kreisverkehr links abbiegen.
<G-vec00057-001-s053><turn.abbiegen><en> Before the paper mill bridge, at the roundabout turn left.
<G-vec00057-001-s054><turn.abbiegen><de> Der Weg führt uns zum Dorf Koti, wo wir rechts abbiegen und bis nach Grčevje und weiter auf der Straße vorbei an der Fischzucht und der Grotte Beceletova jama (Denkmal des Volksbefreiungskampfes NOB) nach Stari grad gelangen.
<G-vec00057-001-s054><turn.abbiegen><en> We cross the stream over the footbridge and afterwards turn left and continue our path towards the Lešnica stream. The trail leads us to the village of Koti, where we turn right and go to Grčevja.
<G-vec00057-001-s055><turn.abbiegen><de> Anfahrt ParkgarageÂ - Wenn Sie sich auf der Hodzovo namestie neben dem Crowne Plaza befinden biegen Sie nach rechts ab auf die Straße Postova – dann die erste links abbiegen in die Vysoka – nach ein paar Metern können Sie unsere Garageneinfahrt sehen und in dieser parken.
<G-vec00057-001-s055><turn.abbiegen><en> Directions Parking garage Hotel Bratislava Â - If you are on the Hodzovo namestie next to the Crowne Plaza turn right onto Postova Street – then the first left into Vysoka – after a few meters you will be able to turn right into our garage.
<G-vec00057-001-s056><turn.abbiegen><de> B7 in Bahnhofstraße abbiegen und dieser folgen- Am Schild Bahngelände, Anlieger fre` vorbeifahren dann noch ca 250m bis zum Alten Bahnhof.
<G-vec00057-001-s056><turn.abbiegen><en> B7 turn into Bahnhofstrasse and the following sign on railway land, riparian fre` pass still 250m to the old railway station.
<G-vec00245-003-s133><turn_up.abbiegen><de> Oben angekommen, biegen Sie bitte rechts ab und gehen 400 Meter geradeaus die Mainzer Landstraße entlang bis zum FBC-Hochhaus, das sich auf der rechten Seite befindet.
<G-vec00245-003-s133><turn_up.abbiegen><en> After arriving upstairs please turn right and walk along the Mainzer Landstraße, after only 400 meters you will find the FBC-Skyscraper on the right side.
<G-vec00245-003-s134><turn_up.abbiegen><de> Anfahrtsbeschreibung Mit dem Auto: Vom Flughafen, Boulevard Mohamed Bouazizi, nehmen Sie die RN8 in Richtung Tunis, biegen rechts in die Avenue Cyrus Legrand ab, nehmen die zweite Ausfahrt rechts zur Rue de Syrie, biegen rechts in die Rue de l'Inde ab und fahren weiter bis zur Avenue Mohamed V. Bahnlinie 2: Bahnhof Nelson Mandela (0,20 km).
<G-vec00245-003-s134><turn_up.abbiegen><en> Directions By car: From the airport, Boulevard Mohamed Bouazizi, take RN8 toward Tunis, turn right toward Avenue Cyrus Legrand, take the second right toward Rue de Syrie, turn right onto Rue de l'Inde and continue until you reach Avenue Mohamed V. Tunis-Carthage Airport (4.3 miles [7 km]), outdoor parking (paying)
<G-vec00245-003-s136><turn_up.abbiegen><de> Beim Passieren unter dem Dolder biegen Sie rechts ab und Sie sind in der RUE DES REMPARTS, das etwa 100 Meter ist unser Zuhause" Le Coeur des Remparts" auf der rechten Seite an der Hausnummer 26.
<G-vec00245-003-s136><turn_up.abbiegen><en> As soon as you pass under the Dolder you turn right and you are in the RUE DES REMPARTS where is located about 100 meters or house " Le Coeur des Remparts" on your right at number 26.
<G-vec00245-003-s137><turn_up.abbiegen><de> Sie biegen ab nach Ponte a Poppi, dann fahren Sie hoch in das alte Dorf Poppi.
<G-vec00245-003-s137><turn_up.abbiegen><en> There you turn left at the main intersection and go up to the old town of Poppi.
<G-vec00245-003-s138><turn_up.abbiegen><de> Fahren Sie auf der Greens Road geradeaus und biegen Sie nach links zum BEST WESTERN PREMIER Ashton Suites ab.
<G-vec00245-003-s138><turn_up.abbiegen><en> Go straight on Greens Road and make a left turn into the BEST WESTERN PREMIER Ashton Suites.
<G-vec00245-003-s139><turn_up.abbiegen><de> Biegen Sie rechts ab und nach 2 km erreichen Sie Volastra.
<G-vec00245-003-s139><turn_up.abbiegen><en> There you should turn right and after two Km. you will reach Volastra.
<G-vec00245-003-s140><turn_up.abbiegen><de> Während Sie dem Weg weiter folgen, biegen Sie nach rechts ab, bis Sie zur Cisterna-Bucht ankommen, wobei wir Ihnen empfehlen, hier einen Parkplatz zu finden.
<G-vec00245-003-s140><turn_up.abbiegen><en> Following tha path, you have to turn right until you reach Cisterna Bay, where we suggest that you find a parking place.
<G-vec00245-003-s141><turn_up.abbiegen><de> Biegen Sie an der Heard Street links ab (91 Meter).
<G-vec00245-003-s141><turn_up.abbiegen><en> Please turn left at the Heard Street 91 meters.
<G-vec00245-003-s142><turn_up.abbiegen><de> Um Mühlbach, Meransen und Vals zu erreichen, biegen Sie vor dem Tunnel rechts ab.
<G-vec00245-003-s142><turn_up.abbiegen><en> To reach Mühlbach, Meransen and Vals, you turn right before the tunnel.
<G-vec00245-003-s143><turn_up.abbiegen><de> Fahren Sie weiter geradeaus, und biegen Sie links ab an der dritten Kreuzung nach der Verkehrsampel auf die White Avenue.
<G-vec00245-003-s143><turn_up.abbiegen><en> Continue to drive straight and make a left turn at the third junction after the traffic light onto White Avenue.
<G-vec00245-003-s144><turn_up.abbiegen><de> Halten Sie sich danach erst Richtung Lüben, dann auf der Straße Richtung Waldhof und biegen schließlich nach einem Einzelgehöft ("Waldhof") in den Wald ab.
<G-vec00245-003-s144><turn_up.abbiegen><en> Then head toward Lüben. Then take the road to Waldhof and turn into the forest right after you pass a farm called Waldhof.
<G-vec00245-003-s145><turn_up.abbiegen><de> Aus Richtung Süden, Ausfahrt Firenze Sud und folgen den Schildern nach Liberty Square, Fortezza da Basso, das Ende der Viale Lavagnini Sie ziehen vorbei und biegen rund um den Park-Festung und weiter geradeaus unter der Eisenbahnbrücke hindurch, vorbei an der Brücke und nach der zweiten Ampel halten Sie die linke, in die Via Guido Monaco geben, an deren Ende biegen Sie rechts ab und Sie kommen nach 50 Metern.
<G-vec00245-003-s145><turn_up.abbiegen><en> Direction from South, exit Firenze Sud and follow signs to Liberty Square, Fortezza da Basso, the end of Viale Lavagnini you pull over and turn around the park's Fortress and continue straight under the railway bridge, past the bridge and after the second traffic light, keep the left, enter in Via Guido Monaco, at the end of which you turn right and you
<G-vec00245-003-s146><turn_up.abbiegen><de> Von den Taxiständen kommend, gehen Sie an den gelben DHL-Postfächern vorbei und biegen links in den Mittelgang mit den Schließfächern ab.
<G-vec00245-003-s146><turn_up.abbiegen><en> Coming from the main entrance please enter the central station and turn left before the escalator you will find us in front if the luggage lockers.
<G-vec00245-003-s147><turn_up.abbiegen><de> Unmittelbar nach der Kirche biegen Sie links ab und fahren die Straße hoch bis zum Haus Christine (befindet sich auf der linken Seite).
<G-vec00245-003-s147><turn_up.abbiegen><en> Right after the church, make a left turn and continue driving until you see Hause Christine (on the left hand side).
<G-vec00245-003-s148><turn_up.abbiegen><de> Im Ausgang der Ortschaft biegen wir links in den Wald ab und folgen dem neu angelegten Mullerthal Trail (Zeichenwechsel).
<G-vec00245-003-s148><turn_up.abbiegen><en> At the end of the village we turn left to enter the forest and follow the new Mullerthal Trail (sign change).
<G-vec00245-003-s149><turn_up.abbiegen><de> In Poysdorf angekommen fahren Sie die B7 weiter Richtung Drasenhofen und biegen am Ortsende links ab.
<G-vec00245-003-s149><turn_up.abbiegen><en> Drive through Poysdorf on the B7 direction to Drasenhofen and turn left at the end of the town.
<G-vec00245-003-s150><turn_up.abbiegen><de> Dort biegen Sie rechts ab und folgen dem Fahrweg bis zum Bauernhof Greidern und weiter in Richtung Seestüberl bis Sie wieder zurück zum Ausgangspunkt am Ostufer ankommen.
<G-vec00245-003-s150><turn_up.abbiegen><en> Here you turn right and follow the road to the farm Greidern and continue towards Seestüberl until you arrive the starting point again.
<G-vec00245-003-s151><turn_up.abbiegen><de> In Bad Ischl Nord biegen wir Richtung Ebensee / Gmunden ab.
<G-vec00245-003-s151><turn_up.abbiegen><en> In Bad Ischl, we turn north towards Ebensee / Gmunden.
<G-vec00309-003-s133><turn_out.abbiegen><de> Oben angekommen, biegen Sie bitte rechts ab und gehen 400 Meter geradeaus die Mainzer Landstraße entlang bis zum FBC-Hochhaus, das sich auf der rechten Seite befindet.
<G-vec00309-003-s133><turn_out.abbiegen><en> After arriving upstairs please turn right and walk along the Mainzer Landstraße, after only 400 meters you will find the FBC-Skyscraper on the right side.
<G-vec00309-003-s134><turn_out.abbiegen><de> Anfahrtsbeschreibung Mit dem Auto: Vom Flughafen, Boulevard Mohamed Bouazizi, nehmen Sie die RN8 in Richtung Tunis, biegen rechts in die Avenue Cyrus Legrand ab, nehmen die zweite Ausfahrt rechts zur Rue de Syrie, biegen rechts in die Rue de l'Inde ab und fahren weiter bis zur Avenue Mohamed V. Bahnlinie 2: Bahnhof Nelson Mandela (0,20 km).
<G-vec00309-003-s134><turn_out.abbiegen><en> Directions By car: From the airport, Boulevard Mohamed Bouazizi, take RN8 toward Tunis, turn right toward Avenue Cyrus Legrand, take the second right toward Rue de Syrie, turn right onto Rue de l'Inde and continue until you reach Avenue Mohamed V. Tunis-Carthage Airport (4.3 miles [7 km]), outdoor parking (paying)
<G-vec00309-003-s136><turn_out.abbiegen><de> Beim Passieren unter dem Dolder biegen Sie rechts ab und Sie sind in der RUE DES REMPARTS, das etwa 100 Meter ist unser Zuhause" Le Coeur des Remparts" auf der rechten Seite an der Hausnummer 26.
<G-vec00309-003-s136><turn_out.abbiegen><en> As soon as you pass under the Dolder you turn right and you are in the RUE DES REMPARTS where is located about 100 meters or house " Le Coeur des Remparts" on your right at number 26.
<G-vec00309-003-s137><turn_out.abbiegen><de> Sie biegen ab nach Ponte a Poppi, dann fahren Sie hoch in das alte Dorf Poppi.
<G-vec00309-003-s137><turn_out.abbiegen><en> There you turn left at the main intersection and go up to the old town of Poppi.
<G-vec00309-003-s138><turn_out.abbiegen><de> Fahren Sie auf der Greens Road geradeaus und biegen Sie nach links zum BEST WESTERN PREMIER Ashton Suites ab.
<G-vec00309-003-s138><turn_out.abbiegen><en> Go straight on Greens Road and make a left turn into the BEST WESTERN PREMIER Ashton Suites.
<G-vec00309-003-s139><turn_out.abbiegen><de> Biegen Sie rechts ab und nach 2 km erreichen Sie Volastra.
<G-vec00309-003-s139><turn_out.abbiegen><en> There you should turn right and after two Km. you will reach Volastra.
<G-vec00309-003-s140><turn_out.abbiegen><de> Während Sie dem Weg weiter folgen, biegen Sie nach rechts ab, bis Sie zur Cisterna-Bucht ankommen, wobei wir Ihnen empfehlen, hier einen Parkplatz zu finden.
<G-vec00309-003-s140><turn_out.abbiegen><en> Following tha path, you have to turn right until you reach Cisterna Bay, where we suggest that you find a parking place.
<G-vec00309-003-s141><turn_out.abbiegen><de> Biegen Sie an der Heard Street links ab (91 Meter).
<G-vec00309-003-s141><turn_out.abbiegen><en> Please turn left at the Heard Street 91 meters.
<G-vec00309-003-s142><turn_out.abbiegen><de> Um Mühlbach, Meransen und Vals zu erreichen, biegen Sie vor dem Tunnel rechts ab.
<G-vec00309-003-s142><turn_out.abbiegen><en> To reach Mühlbach, Meransen and Vals, you turn right before the tunnel.
<G-vec00309-003-s143><turn_out.abbiegen><de> Fahren Sie weiter geradeaus, und biegen Sie links ab an der dritten Kreuzung nach der Verkehrsampel auf die White Avenue.
<G-vec00309-003-s143><turn_out.abbiegen><en> Continue to drive straight and make a left turn at the third junction after the traffic light onto White Avenue.
<G-vec00309-003-s144><turn_out.abbiegen><de> Halten Sie sich danach erst Richtung Lüben, dann auf der Straße Richtung Waldhof und biegen schließlich nach einem Einzelgehöft ("Waldhof") in den Wald ab.
<G-vec00309-003-s144><turn_out.abbiegen><en> Then head toward Lüben. Then take the road to Waldhof and turn into the forest right after you pass a farm called Waldhof.
<G-vec00309-003-s145><turn_out.abbiegen><de> Aus Richtung Süden, Ausfahrt Firenze Sud und folgen den Schildern nach Liberty Square, Fortezza da Basso, das Ende der Viale Lavagnini Sie ziehen vorbei und biegen rund um den Park-Festung und weiter geradeaus unter der Eisenbahnbrücke hindurch, vorbei an der Brücke und nach der zweiten Ampel halten Sie die linke, in die Via Guido Monaco geben, an deren Ende biegen Sie rechts ab und Sie kommen nach 50 Metern.
<G-vec00309-003-s145><turn_out.abbiegen><en> Direction from South, exit Firenze Sud and follow signs to Liberty Square, Fortezza da Basso, the end of Viale Lavagnini you pull over and turn around the park's Fortress and continue straight under the railway bridge, past the bridge and after the second traffic light, keep the left, enter in Via Guido Monaco, at the end of which you turn right and you
<G-vec00309-003-s146><turn_out.abbiegen><de> Von den Taxiständen kommend, gehen Sie an den gelben DHL-Postfächern vorbei und biegen links in den Mittelgang mit den Schließfächern ab.
<G-vec00309-003-s146><turn_out.abbiegen><en> Coming from the main entrance please enter the central station and turn left before the escalator you will find us in front if the luggage lockers.
<G-vec00309-003-s147><turn_out.abbiegen><de> Unmittelbar nach der Kirche biegen Sie links ab und fahren die Straße hoch bis zum Haus Christine (befindet sich auf der linken Seite).
<G-vec00309-003-s147><turn_out.abbiegen><en> Right after the church, make a left turn and continue driving until you see Hause Christine (on the left hand side).
<G-vec00309-003-s148><turn_out.abbiegen><de> Im Ausgang der Ortschaft biegen wir links in den Wald ab und folgen dem neu angelegten Mullerthal Trail (Zeichenwechsel).
<G-vec00309-003-s148><turn_out.abbiegen><en> At the end of the village we turn left to enter the forest and follow the new Mullerthal Trail (sign change).
<G-vec00309-003-s149><turn_out.abbiegen><de> In Poysdorf angekommen fahren Sie die B7 weiter Richtung Drasenhofen und biegen am Ortsende links ab.
<G-vec00309-003-s149><turn_out.abbiegen><en> Drive through Poysdorf on the B7 direction to Drasenhofen and turn left at the end of the town.
<G-vec00309-003-s150><turn_out.abbiegen><de> Dort biegen Sie rechts ab und folgen dem Fahrweg bis zum Bauernhof Greidern und weiter in Richtung Seestüberl bis Sie wieder zurück zum Ausgangspunkt am Ostufer ankommen.
<G-vec00309-003-s150><turn_out.abbiegen><en> Here you turn right and follow the road to the farm Greidern and continue towards Seestüberl until you arrive the starting point again.
<G-vec00309-003-s151><turn_out.abbiegen><de> In Bad Ischl Nord biegen wir Richtung Ebensee / Gmunden ab.
<G-vec00309-003-s151><turn_out.abbiegen><en> In Bad Ischl, we turn north towards Ebensee / Gmunden.
<G-vec00931-002-s038><turn.abbiegen><de> Von der Stadtmitte: von Spektrum N ° 3 bis Kőbánya-Kispest Trum Station, nach Flugzeug-Bus zum "Flugzeug D-Port" genannt Bushaltestelle nach gehen über die Gleise und es gibt eine kleine Straße, und am Ende der Straße gibt es ein großes Gebäude namens "Hertz" und dort rechts abbiegen, fahren 100m bis zum Hotel.
<G-vec00931-002-s038><turn.abbiegen><en> Hrana do tja From city center: by trum N°3 to Kőbánya-Kispest Trum Station, after airplane bus to„ airplane D port” named busstop after go across the railway and there are a little street, and at the end of street there a big building named „Hertz” and there turn right, go 100m to the hotel.
<G-vec00931-002-s039><turn.abbiegen><de> A52 Richtung Düsseldorf bis Autobahnkreuz Düsseldorf-Nord, dann auf die A44 Richtung Flughafen, Ausfahrt Stockum Messe, an der Ampel links abbiegen auf die B8 Richtung Zentrum.
<G-vec00931-002-s039><turn.abbiegen><en> Take A52 direction Düsseldorf until motorway crossing North. Continue on A44 direction Airport, exit Stockum Messe and then turn left at the traffic light onto B5 direction Zentrum (centrum).
<G-vec00931-002-s040><turn.abbiegen><de> Am Ende der Provinzstraße, rechts abbiegen, über die Brücke über den Tagliamento-Fluss fahren, die Ortschaft Latisana durchqueren und auf der Staatsstraße SS 14 bis zur Autobahnzufahrt fahren.
<G-vec00931-002-s040><turn.abbiegen><en> At the end of the county road, turn right, cross the bridge on the river Tagliamento, pass the town of Latisana and go to the highway toll booth along the Statale SS 14 (trunk road).
<G-vec00931-002-s041><turn.abbiegen><de> An der Hauptstrasse rechts Richtung Beckenried fahren, 70 m nach Seehotel Sternen scharf rechts abbiegen Richtung "Oberdorf".
<G-vec00931-002-s041><turn.abbiegen><en> On the main road turn right, direction Beckenried. 70 m after the Seehotel Sternen, take a sharp right turn, direction "Oberdorf".
<G-vec00931-002-s042><turn.abbiegen><de> Am Ende der Straße links abbiegen.
<G-vec00931-002-s042><turn.abbiegen><en> At the end of the street turn left.
<G-vec00931-002-s043><turn.abbiegen><de> Sie werden auf E6 abbiegen Richtung Lysekil Smögen County Road 162 etwa 10 Meilen nördlich von Munkedal fahren.
<G-vec00931-002-s043><turn.abbiegen><en> You will drive on E6 turn towards Lysekil Smögen County Road 162 about 10 miles north of Munkedal.
<G-vec00931-002-s044><turn.abbiegen><de> Rechts abbiegen auf die Goethestraße.
<G-vec00931-002-s044><turn.abbiegen><en> Turn right onto Flushing Avenue.
<G-vec00931-002-s045><turn.abbiegen><de> In den nächsten Gang rechts abbiegen.
<G-vec00931-002-s045><turn.abbiegen><en> Turn into the next passage on the right.
<G-vec00931-002-s048><turn.abbiegen><de> Die Dame im Fahrzeug möchte gerade in ihre Straße abbiegen, als sie und ihre Tochter beschließen, für uns den Umweg bis nach Colmar zu fahren.
<G-vec00931-002-s048><turn.abbiegen><en> The lady in the car was just about to turn into her carpark, when she and her daughter decide to make a detour for us, back to Colmar.
<G-vec00931-002-s049><turn.abbiegen><de> An der Kreuzung (nach KVK Chantier Naval) links abbiegen.
<G-vec00931-002-s049><turn.abbiegen><en> At 800m, turn left at the junction (after KVK Chantier Naval).
<G-vec00931-002-s050><turn.abbiegen><de> An der Ampel ins Hinterland abbiegen und den CP-Schildern folgen.
<G-vec00931-002-s050><turn.abbiegen><en> At traffic lights turn inland and follow signs. Don't use SatNav.
<G-vec00931-002-s051><turn.abbiegen><de> Nach der Bahnunterführung rechts abbiegen in Richtung Alt-Toblach, dem Stoneman-Zeichen folgend geht es weiter in das Silvestertal, an der Enzianhütte vorbei zur Silvesteralm(1.800).
<G-vec00931-002-s051><turn.abbiegen><en> After the railway underpass turn right towards Dobbiaco Alta, following the Stoneman sign continue into the Silvestro Valley, passing the Rifugio Genziana up to the Malga S. Silvestro hut (1,800).
<G-vec00931-002-s052><turn.abbiegen><de> An der achteckigen Kapelle, genannt Horne -Kapelle, auf der langen Straße links abbiegen, dann am Ende der Straße biegen Sie rechts in die Rue de Dunkerque.
<G-vec00931-002-s052><turn.abbiegen><en> At the octagonal chapel, called Horne Chapel, turn left on to the long street, then, at the bottom of the street, turn right on to Rue de Dunkerque.
<G-vec00931-002-s054><turn.abbiegen><de> Schritt nach rechts, Schritt nach links abbiegen - das beste System für die Platzierung von Elementen im Dreieck.
<G-vec00931-002-s054><turn.abbiegen><en> Step right, step left, turn - the best scheme for the placement of elements in the triangle.
<G-vec00931-002-s055><turn.abbiegen><de> Nach der Ortstafel Sebi rechts abbiegen Richtung Buchberg.
<G-vec00931-002-s055><turn.abbiegen><en> After the village sign Sebi turn right in direction Buchberg.
<G-vec00931-002-s056><turn.abbiegen><de> Bei der Ausfahrt links in B37/B33 Richtung Freiburg/Schaffhausen/Donaueschingen abbiegen, nach 9 km die Auffahrt B31 nach Freiburg/Titisee-Neustadt nehmen, rechts abbiegen auf die B31.
<G-vec00931-002-s056><turn.abbiegen><en> At the exit turn left in direction B37/B33 Freiburg/Schaffhausen/Donaueschingen, after 9km take the B31 to Freiburg/Titisee-Neustadt, turn right onto the B31.
<G-vec00931-002-s133><turn.abbiegen><de> Oben angekommen, biegen Sie bitte rechts ab und gehen 400 Meter geradeaus die Mainzer Landstraße entlang bis zum FBC-Hochhaus, das sich auf der rechten Seite befindet.
<G-vec00931-002-s133><turn.abbiegen><en> After arriving upstairs please turn right and walk along the Mainzer Landstraße, after only 400 meters you will find the FBC-Skyscraper on the right side.
<G-vec00931-002-s134><turn.abbiegen><de> Anfahrtsbeschreibung Mit dem Auto: Vom Flughafen, Boulevard Mohamed Bouazizi, nehmen Sie die RN8 in Richtung Tunis, biegen rechts in die Avenue Cyrus Legrand ab, nehmen die zweite Ausfahrt rechts zur Rue de Syrie, biegen rechts in die Rue de l'Inde ab und fahren weiter bis zur Avenue Mohamed V. Bahnlinie 2: Bahnhof Nelson Mandela (0,20 km).
<G-vec00931-002-s134><turn.abbiegen><en> Directions By car: From the airport, Boulevard Mohamed Bouazizi, take RN8 toward Tunis, turn right toward Avenue Cyrus Legrand, take the second right toward Rue de Syrie, turn right onto Rue de l'Inde and continue until you reach Avenue Mohamed V. Tunis-Carthage Airport (4.3 miles [7 km]), outdoor parking (paying)
<G-vec00931-002-s136><turn.abbiegen><de> Beim Passieren unter dem Dolder biegen Sie rechts ab und Sie sind in der RUE DES REMPARTS, das etwa 100 Meter ist unser Zuhause" Le Coeur des Remparts" auf der rechten Seite an der Hausnummer 26.
<G-vec00931-002-s136><turn.abbiegen><en> As soon as you pass under the Dolder you turn right and you are in the RUE DES REMPARTS where is located about 100 meters or house " Le Coeur des Remparts" on your right at number 26.
<G-vec00931-002-s137><turn.abbiegen><de> Sie biegen ab nach Ponte a Poppi, dann fahren Sie hoch in das alte Dorf Poppi.
<G-vec00931-002-s137><turn.abbiegen><en> There you turn left at the main intersection and go up to the old town of Poppi.
<G-vec00931-002-s138><turn.abbiegen><de> Fahren Sie auf der Greens Road geradeaus und biegen Sie nach links zum BEST WESTERN PREMIER Ashton Suites ab.
<G-vec00931-002-s138><turn.abbiegen><en> Go straight on Greens Road and make a left turn into the BEST WESTERN PREMIER Ashton Suites.
<G-vec00931-002-s139><turn.abbiegen><de> Biegen Sie rechts ab und nach 2 km erreichen Sie Volastra.
<G-vec00931-002-s139><turn.abbiegen><en> There you should turn right and after two Km. you will reach Volastra.
<G-vec00931-002-s140><turn.abbiegen><de> Während Sie dem Weg weiter folgen, biegen Sie nach rechts ab, bis Sie zur Cisterna-Bucht ankommen, wobei wir Ihnen empfehlen, hier einen Parkplatz zu finden.
<G-vec00931-002-s140><turn.abbiegen><en> Following tha path, you have to turn right until you reach Cisterna Bay, where we suggest that you find a parking place.
<G-vec00931-002-s141><turn.abbiegen><de> Biegen Sie an der Heard Street links ab (91 Meter).
<G-vec00931-002-s141><turn.abbiegen><en> Please turn left at the Heard Street 91 meters.
<G-vec00931-002-s142><turn.abbiegen><de> Um Mühlbach, Meransen und Vals zu erreichen, biegen Sie vor dem Tunnel rechts ab.
<G-vec00931-002-s142><turn.abbiegen><en> To reach Mühlbach, Meransen and Vals, you turn right before the tunnel.
<G-vec00931-002-s143><turn.abbiegen><de> Fahren Sie weiter geradeaus, und biegen Sie links ab an der dritten Kreuzung nach der Verkehrsampel auf die White Avenue.
<G-vec00931-002-s143><turn.abbiegen><en> Continue to drive straight and make a left turn at the third junction after the traffic light onto White Avenue.
<G-vec00931-002-s144><turn.abbiegen><de> Halten Sie sich danach erst Richtung Lüben, dann auf der Straße Richtung Waldhof und biegen schließlich nach einem Einzelgehöft ("Waldhof") in den Wald ab.
<G-vec00931-002-s144><turn.abbiegen><en> Then head toward Lüben. Then take the road to Waldhof and turn into the forest right after you pass a farm called Waldhof.
<G-vec00931-002-s145><turn.abbiegen><de> Aus Richtung Süden, Ausfahrt Firenze Sud und folgen den Schildern nach Liberty Square, Fortezza da Basso, das Ende der Viale Lavagnini Sie ziehen vorbei und biegen rund um den Park-Festung und weiter geradeaus unter der Eisenbahnbrücke hindurch, vorbei an der Brücke und nach der zweiten Ampel halten Sie die linke, in die Via Guido Monaco geben, an deren Ende biegen Sie rechts ab und Sie kommen nach 50 Metern.
<G-vec00931-002-s145><turn.abbiegen><en> Direction from South, exit Firenze Sud and follow signs to Liberty Square, Fortezza da Basso, the end of Viale Lavagnini you pull over and turn around the park's Fortress and continue straight under the railway bridge, past the bridge and after the second traffic light, keep the left, enter in Via Guido Monaco, at the end of which you turn right and you
<G-vec00931-002-s146><turn.abbiegen><de> Von den Taxiständen kommend, gehen Sie an den gelben DHL-Postfächern vorbei und biegen links in den Mittelgang mit den Schließfächern ab.
<G-vec00931-002-s146><turn.abbiegen><en> Coming from the main entrance please enter the central station and turn left before the escalator you will find us in front if the luggage lockers.
<G-vec00931-002-s147><turn.abbiegen><de> Unmittelbar nach der Kirche biegen Sie links ab und fahren die Straße hoch bis zum Haus Christine (befindet sich auf der linken Seite).
<G-vec00931-002-s147><turn.abbiegen><en> Right after the church, make a left turn and continue driving until you see Hause Christine (on the left hand side).
<G-vec00931-002-s148><turn.abbiegen><de> Im Ausgang der Ortschaft biegen wir links in den Wald ab und folgen dem neu angelegten Mullerthal Trail (Zeichenwechsel).
<G-vec00931-002-s148><turn.abbiegen><en> At the end of the village we turn left to enter the forest and follow the new Mullerthal Trail (sign change).
<G-vec00931-002-s149><turn.abbiegen><de> In Poysdorf angekommen fahren Sie die B7 weiter Richtung Drasenhofen und biegen am Ortsende links ab.
<G-vec00931-002-s149><turn.abbiegen><en> Drive through Poysdorf on the B7 direction to Drasenhofen and turn left at the end of the town.
<G-vec00931-002-s150><turn.abbiegen><de> Dort biegen Sie rechts ab und folgen dem Fahrweg bis zum Bauernhof Greidern und weiter in Richtung Seestüberl bis Sie wieder zurück zum Ausgangspunkt am Ostufer ankommen.
<G-vec00931-002-s150><turn.abbiegen><en> Here you turn right and follow the road to the farm Greidern and continue towards Seestüberl until you arrive the starting point again.
<G-vec00931-002-s151><turn.abbiegen><de> In Bad Ischl Nord biegen wir Richtung Ebensee / Gmunden ab.
<G-vec00931-002-s151><turn.abbiegen><en> In Bad Ischl, we turn north towards Ebensee / Gmunden.
<G-vec00931-002-s038><turn_on.abbiegen><de> Von der Stadtmitte: von Spektrum N ° 3 bis Kőbánya-Kispest Trum Station, nach Flugzeug-Bus zum "Flugzeug D-Port" genannt Bushaltestelle nach gehen über die Gleise und es gibt eine kleine Straße, und am Ende der Straße gibt es ein großes Gebäude namens "Hertz" und dort rechts abbiegen, fahren 100m bis zum Hotel.
<G-vec00931-002-s038><turn_on.abbiegen><en> Hrana do tja From city center: by trum N°3 to Kőbánya-Kispest Trum Station, after airplane bus to„ airplane D port” named busstop after go across the railway and there are a little street, and at the end of street there a big building named „Hertz” and there turn right, go 100m to the hotel.
<G-vec00931-002-s039><turn_on.abbiegen><de> A52 Richtung Düsseldorf bis Autobahnkreuz Düsseldorf-Nord, dann auf die A44 Richtung Flughafen, Ausfahrt Stockum Messe, an der Ampel links abbiegen auf die B8 Richtung Zentrum.
<G-vec00931-002-s039><turn_on.abbiegen><en> Take A52 direction Düsseldorf until motorway crossing North. Continue on A44 direction Airport, exit Stockum Messe and then turn left at the traffic light onto B5 direction Zentrum (centrum).
<G-vec00931-002-s040><turn_on.abbiegen><de> Am Ende der Provinzstraße, rechts abbiegen, über die Brücke über den Tagliamento-Fluss fahren, die Ortschaft Latisana durchqueren und auf der Staatsstraße SS 14 bis zur Autobahnzufahrt fahren.
<G-vec00931-002-s040><turn_on.abbiegen><en> At the end of the county road, turn right, cross the bridge on the river Tagliamento, pass the town of Latisana and go to the highway toll booth along the Statale SS 14 (trunk road).
<G-vec00931-002-s041><turn_on.abbiegen><de> An der Hauptstrasse rechts Richtung Beckenried fahren, 70 m nach Seehotel Sternen scharf rechts abbiegen Richtung "Oberdorf".
<G-vec00931-002-s041><turn_on.abbiegen><en> On the main road turn right, direction Beckenried. 70 m after the Seehotel Sternen, take a sharp right turn, direction "Oberdorf".
<G-vec00931-002-s042><turn_on.abbiegen><de> Am Ende der Straße links abbiegen.
<G-vec00931-002-s042><turn_on.abbiegen><en> At the end of the street turn left.
<G-vec00931-002-s043><turn_on.abbiegen><de> Sie werden auf E6 abbiegen Richtung Lysekil Smögen County Road 162 etwa 10 Meilen nördlich von Munkedal fahren.
<G-vec00931-002-s043><turn_on.abbiegen><en> You will drive on E6 turn towards Lysekil Smögen County Road 162 about 10 miles north of Munkedal.
<G-vec00931-002-s044><turn_on.abbiegen><de> Rechts abbiegen auf die Goethestraße.
<G-vec00931-002-s044><turn_on.abbiegen><en> Turn right onto Flushing Avenue.
<G-vec00931-002-s045><turn_on.abbiegen><de> In den nächsten Gang rechts abbiegen.
<G-vec00931-002-s045><turn_on.abbiegen><en> Turn into the next passage on the right.
<G-vec00931-002-s046><turn_on.abbiegen><de> (4 km) bis ins Stadtgebiet - 300m nach der Shell-Tankstelle an der großen Ampelkreuzung rechts abbiegen (Ausschilderung Hotelroute), nach 700 m rechts abbiegen und der Ausschilderung Parkhotel folgen.
<G-vec00931-002-s046><turn_on.abbiegen><en> (4 km) into the town - Turn right 300 m after the Shell gas station at the major traffic light intersection (Hotel route sign), after 700 m turn right and follow signs for the Parkhotel.
<G-vec00931-002-s048><turn_on.abbiegen><de> Die Dame im Fahrzeug möchte gerade in ihre Straße abbiegen, als sie und ihre Tochter beschließen, für uns den Umweg bis nach Colmar zu fahren.
<G-vec00931-002-s048><turn_on.abbiegen><en> The lady in the car was just about to turn into her carpark, when she and her daughter decide to make a detour for us, back to Colmar.
<G-vec00931-002-s049><turn_on.abbiegen><de> An der Kreuzung (nach KVK Chantier Naval) links abbiegen.
<G-vec00931-002-s049><turn_on.abbiegen><en> At 800m, turn left at the junction (after KVK Chantier Naval).
<G-vec00931-002-s050><turn_on.abbiegen><de> An der Ampel ins Hinterland abbiegen und den CP-Schildern folgen.
<G-vec00931-002-s050><turn_on.abbiegen><en> At traffic lights turn inland and follow signs. Don't use SatNav.
<G-vec00931-002-s051><turn_on.abbiegen><de> Nach der Bahnunterführung rechts abbiegen in Richtung Alt-Toblach, dem Stoneman-Zeichen folgend geht es weiter in das Silvestertal, an der Enzianhütte vorbei zur Silvesteralm(1.800).
<G-vec00931-002-s051><turn_on.abbiegen><en> After the railway underpass turn right towards Dobbiaco Alta, following the Stoneman sign continue into the Silvestro Valley, passing the Rifugio Genziana up to the Malga S. Silvestro hut (1,800).
<G-vec00931-002-s052><turn_on.abbiegen><de> An der achteckigen Kapelle, genannt Horne -Kapelle, auf der langen Straße links abbiegen, dann am Ende der Straße biegen Sie rechts in die Rue de Dunkerque.
<G-vec00931-002-s052><turn_on.abbiegen><en> At the octagonal chapel, called Horne Chapel, turn left on to the long street, then, at the bottom of the street, turn right on to Rue de Dunkerque.
<G-vec00931-002-s054><turn_on.abbiegen><de> Schritt nach rechts, Schritt nach links abbiegen - das beste System für die Platzierung von Elementen im Dreieck.
<G-vec00931-002-s054><turn_on.abbiegen><en> Step right, step left, turn - the best scheme for the placement of elements in the triangle.
<G-vec00931-002-s055><turn_on.abbiegen><de> Nach der Ortstafel Sebi rechts abbiegen Richtung Buchberg.
<G-vec00931-002-s055><turn_on.abbiegen><en> After the village sign Sebi turn right in direction Buchberg.
<G-vec00931-002-s056><turn_on.abbiegen><de> Bei der Ausfahrt links in B37/B33 Richtung Freiburg/Schaffhausen/Donaueschingen abbiegen, nach 9 km die Auffahrt B31 nach Freiburg/Titisee-Neustadt nehmen, rechts abbiegen auf die B31.
<G-vec00931-002-s056><turn_on.abbiegen><en> At the exit turn left in direction B37/B33 Freiburg/Schaffhausen/Donaueschingen, after 9km take the B31 to Freiburg/Titisee-Neustadt, turn right onto the B31.
<G-vec00931-002-s133><turn_on.abbiegen><de> Oben angekommen, biegen Sie bitte rechts ab und gehen 400 Meter geradeaus die Mainzer Landstraße entlang bis zum FBC-Hochhaus, das sich auf der rechten Seite befindet.
<G-vec00931-002-s133><turn_on.abbiegen><en> After arriving upstairs please turn right and walk along the Mainzer Landstraße, after only 400 meters you will find the FBC-Skyscraper on the right side.
<G-vec00931-002-s134><turn_on.abbiegen><de> Anfahrtsbeschreibung Mit dem Auto: Vom Flughafen, Boulevard Mohamed Bouazizi, nehmen Sie die RN8 in Richtung Tunis, biegen rechts in die Avenue Cyrus Legrand ab, nehmen die zweite Ausfahrt rechts zur Rue de Syrie, biegen rechts in die Rue de l'Inde ab und fahren weiter bis zur Avenue Mohamed V. Bahnlinie 2: Bahnhof Nelson Mandela (0,20 km).
<G-vec00931-002-s134><turn_on.abbiegen><en> Directions By car: From the airport, Boulevard Mohamed Bouazizi, take RN8 toward Tunis, turn right toward Avenue Cyrus Legrand, take the second right toward Rue de Syrie, turn right onto Rue de l'Inde and continue until you reach Avenue Mohamed V. Tunis-Carthage Airport (4.3 miles [7 km]), outdoor parking (paying)
<G-vec00931-002-s136><turn_on.abbiegen><de> Beim Passieren unter dem Dolder biegen Sie rechts ab und Sie sind in der RUE DES REMPARTS, das etwa 100 Meter ist unser Zuhause" Le Coeur des Remparts" auf der rechten Seite an der Hausnummer 26.
<G-vec00931-002-s136><turn_on.abbiegen><en> As soon as you pass under the Dolder you turn right and you are in the RUE DES REMPARTS where is located about 100 meters or house " Le Coeur des Remparts" on your right at number 26.
<G-vec00931-002-s137><turn_on.abbiegen><de> Sie biegen ab nach Ponte a Poppi, dann fahren Sie hoch in das alte Dorf Poppi.
<G-vec00931-002-s137><turn_on.abbiegen><en> There you turn left at the main intersection and go up to the old town of Poppi.
<G-vec00931-002-s138><turn_on.abbiegen><de> Fahren Sie auf der Greens Road geradeaus und biegen Sie nach links zum BEST WESTERN PREMIER Ashton Suites ab.
<G-vec00931-002-s138><turn_on.abbiegen><en> Go straight on Greens Road and make a left turn into the BEST WESTERN PREMIER Ashton Suites.
<G-vec00931-002-s139><turn_on.abbiegen><de> Biegen Sie rechts ab und nach 2 km erreichen Sie Volastra.
<G-vec00931-002-s139><turn_on.abbiegen><en> There you should turn right and after two Km. you will reach Volastra.
<G-vec00931-002-s140><turn_on.abbiegen><de> Während Sie dem Weg weiter folgen, biegen Sie nach rechts ab, bis Sie zur Cisterna-Bucht ankommen, wobei wir Ihnen empfehlen, hier einen Parkplatz zu finden.
<G-vec00931-002-s140><turn_on.abbiegen><en> Following tha path, you have to turn right until you reach Cisterna Bay, where we suggest that you find a parking place.
<G-vec00931-002-s141><turn_on.abbiegen><de> Biegen Sie an der Heard Street links ab (91 Meter).
<G-vec00931-002-s141><turn_on.abbiegen><en> Please turn left at the Heard Street 91 meters.
<G-vec00931-002-s142><turn_on.abbiegen><de> Um Mühlbach, Meransen und Vals zu erreichen, biegen Sie vor dem Tunnel rechts ab.
<G-vec00931-002-s142><turn_on.abbiegen><en> To reach Mühlbach, Meransen and Vals, you turn right before the tunnel.
<G-vec00931-002-s143><turn_on.abbiegen><de> Fahren Sie weiter geradeaus, und biegen Sie links ab an der dritten Kreuzung nach der Verkehrsampel auf die White Avenue.
<G-vec00931-002-s143><turn_on.abbiegen><en> Continue to drive straight and make a left turn at the third junction after the traffic light onto White Avenue.
<G-vec00931-002-s144><turn_on.abbiegen><de> Halten Sie sich danach erst Richtung Lüben, dann auf der Straße Richtung Waldhof und biegen schließlich nach einem Einzelgehöft ("Waldhof") in den Wald ab.
<G-vec00931-002-s144><turn_on.abbiegen><en> Then head toward Lüben. Then take the road to Waldhof and turn into the forest right after you pass a farm called Waldhof.
<G-vec00931-002-s145><turn_on.abbiegen><de> Aus Richtung Süden, Ausfahrt Firenze Sud und folgen den Schildern nach Liberty Square, Fortezza da Basso, das Ende der Viale Lavagnini Sie ziehen vorbei und biegen rund um den Park-Festung und weiter geradeaus unter der Eisenbahnbrücke hindurch, vorbei an der Brücke und nach der zweiten Ampel halten Sie die linke, in die Via Guido Monaco geben, an deren Ende biegen Sie rechts ab und Sie kommen nach 50 Metern.
<G-vec00931-002-s145><turn_on.abbiegen><en> Direction from South, exit Firenze Sud and follow signs to Liberty Square, Fortezza da Basso, the end of Viale Lavagnini you pull over and turn around the park's Fortress and continue straight under the railway bridge, past the bridge and after the second traffic light, keep the left, enter in Via Guido Monaco, at the end of which you turn right and you
<G-vec00931-002-s146><turn_on.abbiegen><de> Von den Taxiständen kommend, gehen Sie an den gelben DHL-Postfächern vorbei und biegen links in den Mittelgang mit den Schließfächern ab.
<G-vec00931-002-s146><turn_on.abbiegen><en> Coming from the main entrance please enter the central station and turn left before the escalator you will find us in front if the luggage lockers.
<G-vec00931-002-s147><turn_on.abbiegen><de> Unmittelbar nach der Kirche biegen Sie links ab und fahren die Straße hoch bis zum Haus Christine (befindet sich auf der linken Seite).
<G-vec00931-002-s147><turn_on.abbiegen><en> Right after the church, make a left turn and continue driving until you see Hause Christine (on the left hand side).
<G-vec00931-002-s148><turn_on.abbiegen><de> Im Ausgang der Ortschaft biegen wir links in den Wald ab und folgen dem neu angelegten Mullerthal Trail (Zeichenwechsel).
<G-vec00931-002-s148><turn_on.abbiegen><en> At the end of the village we turn left to enter the forest and follow the new Mullerthal Trail (sign change).
<G-vec00931-002-s149><turn_on.abbiegen><de> In Poysdorf angekommen fahren Sie die B7 weiter Richtung Drasenhofen und biegen am Ortsende links ab.
<G-vec00931-002-s149><turn_on.abbiegen><en> Drive through Poysdorf on the B7 direction to Drasenhofen and turn left at the end of the town.
<G-vec00931-002-s150><turn_on.abbiegen><de> Dort biegen Sie rechts ab und folgen dem Fahrweg bis zum Bauernhof Greidern und weiter in Richtung Seestüberl bis Sie wieder zurück zum Ausgangspunkt am Ostufer ankommen.
<G-vec00931-002-s150><turn_on.abbiegen><en> Here you turn right and follow the road to the farm Greidern and continue towards Seestüberl until you arrive the starting point again.
<G-vec00931-002-s151><turn_on.abbiegen><de> In Bad Ischl Nord biegen wir Richtung Ebensee / Gmunden ab.
<G-vec00931-002-s151><turn_on.abbiegen><en> In Bad Ischl, we turn north towards Ebensee / Gmunden.
