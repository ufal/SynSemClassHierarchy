<G-vec00595-002-s228><purge.anzuzeigen><de> Klicken Sie auf Ja, wenn Sie dazu aufgefordert werden, um Ihr Element wiederherzustellen und in Ihrem Vault anzuzeigen.
<G-vec00595-002-s228><purge.anzuzeigen><en> When prompted, click Yes to delete your item permanently. Purge multiple deleted items
