<G-vec00265-002-s023><infringe.antasten><de> Und doch bleibt es jeder Seele freigestellt, davon Gebrauch zu machen, weil Ich ihr einen freien Willen gegeben habe, den Ich niemals antasten werde.
<G-vec00265-002-s023><infringe.antasten><en> And yet it remains up to every soul to make use of it, because it has received free will from Me, which I will never infringe upon.
