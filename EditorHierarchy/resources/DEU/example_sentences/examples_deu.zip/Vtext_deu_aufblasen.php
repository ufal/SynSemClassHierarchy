<G-vec00634-002-s023><inflate.aufblasen><de> Ein Nebeneffekt: Mehr Leistung des Turbos kommt im Motor an, da sich diese Schläuche, im Gegensatz zum Original, nicht aufblasen.
<G-vec00634-002-s023><inflate.aufblasen><en> A secondary effect: The turbocharged power is generated in the engine, since these hoses, unlike the original, do not inflate.
<G-vec00634-002-s024><inflate.aufblasen><de> Jede Einheit läuft von einem Hochleistungs-, Konstantstromgebläse (im Preis enthalten) und dauert weniger als 30 Sekunden zum Aufblasen.
<G-vec00634-002-s024><inflate.aufblasen><en> Each unit runs from a high output, constant flow blower (included in price) and takes less than 30 seconds to inflate.
<G-vec00634-002-s025><inflate.aufblasen><de> Der Schildkröte Schwimmring 160cm ist eine Schildkröte zum Aufblasen.
<G-vec00634-002-s025><inflate.aufblasen><en> The turtle swimming ring 160cm is a turtle to inflate.
<G-vec00634-002-s026><inflate.aufblasen><de> Platypus-Flaschen können Sie trocknen, indem Sie sie leicht aufblasen und dann aufrecht und offen stehen lassen, bis das Wasser verdampft ist.
<G-vec00634-002-s026><inflate.aufblasen><en> Platypus bottles can be dried by blowing a little air into them to inflate, then letting them stand upright and uncapped until the water evaporates.
<G-vec00634-002-s027><inflate.aufblasen><de> Die NeoAir Mikropumpe ist eine kompakte und doch leistungsstarke, batteriebetriebene Pumpe zum Aufblasen von Therm-a-Rest Matten mit WingLock- oder TwinLock-Ventil.
<G-vec00634-002-s027><inflate.aufblasen><en> The NeoAir Micro Pump is a compact and powerful electronic pump to inflate your Therm-a-Rest pad with a WingLock or TwinLock valve.
<G-vec00634-002-s028><inflate.aufblasen><de> Den Frosch aufblasen, Spielfreie Puzzle Spiele online.
<G-vec00634-002-s028><inflate.aufblasen><en> Inflate the Frog, play free Puzzle games online.
<G-vec00634-002-s029><inflate.aufblasen><de> Schließt einen Lüftermotor mit ein, der den Wasserpark in nur 3 Minuten für schnelle Einrichtung leicht aufblasen kann.
<G-vec00634-002-s029><inflate.aufblasen><en> Includes a blower motor that can easily inflate the water park in as little as 3 minutes for fast setup.
<G-vec00634-002-s030><inflate.aufblasen><de> Dieses Verfahren zum Aufblasen des TAI-Katheterballons ist das sicherste für Patienten mit Rückenmarksverletzung.
<G-vec00634-002-s030><inflate.aufblasen><en> This is the safest way to inflate the catheter balloon in patients with spinal cord injury.
<G-vec00634-002-s032><inflate.aufblasen><de> Das Kostüm zum Aufblasen ist eine tolle Alternative zu klassischen Kostümen.
<G-vec00634-002-s032><inflate.aufblasen><en> The costume to inflate is a great alternative to classic costumes.
<G-vec00634-002-s033><inflate.aufblasen><de> Du kannst Restube jederzeit auch mit dem Mund aufblasen.
<G-vec00634-002-s033><inflate.aufblasen><en> You can also inflate Restube with your mouth anytime.
<G-vec00634-002-s034><inflate.aufblasen><de> Hier kommt Fehlverhalten ins Spiel, wenn das Management die Gewinne aufblasen möchte.
<G-vec00634-002-s034><inflate.aufblasen><en> This is where misconduct comes into play when management wants to inflate profits.
<G-vec00634-002-s035><inflate.aufblasen><de> Die Kombination des Philipps-Systems mit dem NCER-PD-Ansatz soll es möglich machen, die Menschen vor den Folgen eines Sturzes zu schützen – zum Beispiel indem sich spezielle Hüft-Airbags aufblasen, kurz bevor es zum Sturz kommt.
<G-vec00634-002-s035><inflate.aufblasen><en> Combining the Phillips system with the NCER-PD approach should make it possible to prevent people from hurting themselves when they fall – for example by having special hip airbags inflate immediately before the fall.
<G-vec00634-002-s036><inflate.aufblasen><de> Diese Remote Control Inflatable Love Lounger ist die erste portable aufblasbare Sex Maschine - einfach aufblasen, schnallen Sie sich an.
<G-vec00634-002-s036><inflate.aufblasen><en> The Remote Control Inflatable Love Lounger is the first ever portable inflatable sex machine--just inflate it, strap yourself in, push the remote, and get ready for a wild ride!
<G-vec00634-002-s037><inflate.aufblasen><de> Weniger Luftverlust bedeutet weniger Aufblasen.
<G-vec00634-002-s037><inflate.aufblasen><en> Less air loss means having to inflate less.
<G-vec00634-002-s038><inflate.aufblasen><de> Die Luftkissen-Druckentlastungsmatratze bietet eine komfortable Stützfläche, deren Zellen sich gemäß den etablierten alternierenden Prinzipien sanft aufblasen und entleeren.
<G-vec00634-002-s038><inflate.aufblasen><en> The air cushion Pressure Relief Mattress offers a comfortable support surface whose cells gently inflate and deflate in accordance with established alternating principles.
<G-vec00634-002-s039><inflate.aufblasen><de> 3.Type: konstante Schlagart, müssen Sie sie ständig aufblasen, indem Sie Verbindungsstrom des Gebläses verwenden, soll er sehr schnell aufgestellt werden und heruntergenommen werden.
<G-vec00634-002-s039><inflate.aufblasen><en> 3.Type:constant blowing type, you need to inflate it constantly by using blower connecting electricity, It is very fast to be put up and taken down .
<G-vec00634-002-s040><inflate.aufblasen><de> Einfach aufblasen und kann durch den Mund aufgeblasen werden oder mittels einer Pumpe.
<G-vec00634-002-s040><inflate.aufblasen><en> Easy inflate and can be inflated by mouth or using a pump.
<G-vec00634-002-s041><inflate.aufblasen><de> So kannst Du sie einfach in nur einer Minute aufblasen.
<G-vec00634-002-s041><inflate.aufblasen><en> Thus, you can easily inflate it in just one minute.
<G-vec00634-002-s042><inflate.aufblasen><de> Beschreibung Die elektrische Luftpumpe BRAVO 230/1000 ist Ihr idealer Helfer besonders dann, wenn Sie oft und mehrere Boote aufblasen möchten.
<G-vec00634-002-s042><inflate.aufblasen><en> Description The electrical pump BRAVO 230/1000 is an ideal assistant, particularly if you inflate often and multiple boats.
<G-vec00634-002-s062><inflate.aufblasen><de> Auf der einen Seite gewinnen Sie eine Oase des Wohlbefindens bei den Grünen, auf der anderen Seite, um den Wert der Immobilie aufzublasen.
<G-vec00634-002-s062><inflate.aufblasen><en> On the one hand you gain an oasis of well-being among the greenery, on the other hand to inflate the value of the property.
<G-vec00634-002-s063><inflate.aufblasen><de> A: Es ist keine Ölpest, Silikonöl an der Wand der 4500 psi Handpumpe, Silikonöl soll die Dichtung schützen, während die tragbare Inflation-PCP-Pumpe schmiert, leichter aufzublasen.
<G-vec00634-002-s063><inflate.aufblasen><en> A: It is not oil spills, silicone oil on the wall of the 4500 psi hand pump, silicone oil is to protect the seal, meanwhile lubricate portable Inflation Pcp Pump, more easily to inflate.
<G-vec00634-002-s064><inflate.aufblasen><de> Mit dem vertieften FrühlingsLuftventil ist es einfach, die Maßeinheit in weniger als 10 Minuten schnell aufzublasen und zu entlüften.
<G-vec00634-002-s064><inflate.aufblasen><en> With the recessed spring air valve, it’s easy to rapidly inflate and deflate the unit in less than 10 minutes.
<G-vec00634-002-s065><inflate.aufblasen><de> Setzen Sie einfach die Handpumpe ein und drücken Sie sie zusammen, um den Stöpsel bis zur gewünschten Fülle aufzublasen.
<G-vec00634-002-s065><inflate.aufblasen><en> Simply insert and squeeze the hand pump to inflate the plug to your desired fullness.
<G-vec00634-002-s066><inflate.aufblasen><de> Ihre Inbetriebnahme ist außerdem gar nicht kompliziert - es genügt nur, das Schiff auszupacken, aufzublasen, die Sitze zu befestigen, und Sie sind bereit aufzubrechen.
<G-vec00634-002-s066><inflate.aufblasen><en> Not to mention, it’s not at all difficult to prepare them for water – all you need to do is unpack the kayak, inflate it, affix the seats and you’re ready to go!
<G-vec00634-002-s067><inflate.aufblasen><de> 2, mit den Gebläsen, zum es costantly aufzublasen.
<G-vec00634-002-s067><inflate.aufblasen><en> 2, with blowers to inflate it costantly .
<G-vec00634-002-s068><inflate.aufblasen><de> Ihre beiden Kinder, jetzt vier und zwei Jahre alt, haben Luftballons gefunden, die sie jetzt trotz der Warnung ihrer Mutter versuchen aufzublasen.
<G-vec00634-002-s068><inflate.aufblasen><en> Their two children, now aged two and four, have found balloons they try to inflate, despite the warnings of their mother, who tries to pass them felt-tip pens and paper available at the Aquarius’ shelter instead.
<G-vec00634-002-s069><inflate.aufblasen><de> Während des Eingriffs bläst das Kind durch jedes Nasenloch in eine Düse, um einen Ballon aufzublasen.
<G-vec00634-002-s069><inflate.aufblasen><en> During the treatment, the child blows through each nostril into a nozzle to inflate the balloon.
<G-vec00634-002-s070><inflate.aufblasen><de> Argon wird auch im technischen Tauchsport aufgrund seiner nichtreaktiven, hitze-isolierenden Eigenschaften genutzt um den Trockenanzug aufzublasen.
<G-vec00634-002-s070><inflate.aufblasen><en> Argon is also used in technical SCUBA diving to inflate the drysuit, due to its nonreactive, heat isolating effect.
<G-vec00634-002-s071><inflate.aufblasen><de> Dieser professionelle Gummiball ist perfekt, um Volleyball oder Beach-Volleyball mit Ihren Freunden zu spielen und wird mit einer Luftpumpe geliefert, um ihn schnell und unkompliziert aufzublasen.
<G-vec00634-002-s071><inflate.aufblasen><en> This professional rubber ball is perfect for playing volleyball or beach volleyball with your friends, and comes with an air pump to inflate it easily and in no time.
<G-vec00634-002-s072><inflate.aufblasen><de> Die Bevölkerung der Stadt erreicht eine Million in den frühen 1960er Jahren und blieb in den 1970er Jahren aufzublasen.
<G-vec00634-002-s072><inflate.aufblasen><en> The city's population reached one million in the early 1960s and continued to inflate during the 1970s.
<G-vec00634-002-s073><inflate.aufblasen><de> Deshalb war es in so einer aufrichtigen Umgebung schwer, mein Ego aufzublasen.
<G-vec00634-002-s073><inflate.aufblasen><en> It was hard to inflate my ego in this righteous environment.
<G-vec00634-002-s082><inflate.aufblasen><de> Ihr Pilot gibt Ihnen eine vollständige Sicherheitsunterweisung und dann können Sie beim Aufblasen des Ballons helfen.
<G-vec00634-002-s082><inflate.aufblasen><en> You will then meet your Pilot and be given a full safety briefing; you can get involved and help inflate the balloon!
<G-vec00634-002-s112><inflate.aufblasen><de> Diese wiederaufladbare Luftpumpe benötigt nur 70 Sekunden, um sich aufzublasen, effektiv aufzublasen und zu entleeren, weniger Zeit zu warten und Ihr Abenteuer oder Ihre Entspannung zu genießen.,[Sicher und komfortabel] - Die drahtlose elektrische Schnellluftpumpe von Pumteck ist sicher und spart Zeit, da sie ohne Fieber und mit einer Oberflächentemperatur von weniger als 40 ° kontinuierlich arbeiten kann.
<G-vec00634-002-s112><inflate.aufblasen><en> This Rechargeable air pump only need 70s to inflate, effective inflating and deflating, wait less time and enjoy your adventure or relaxation.,[Safe & Comfortable]- The Pumteck Wireless Electric Fast Air Pump is safe and save your time, which can work continually without fever and the surface temperature less than 40°.
<G-vec00634-002-s114><inflate.aufblasen><de> Da das Sitzteil nicht aufblasbar ist konnte ich die Matte einfach an diesem Ende nehmen und mir über die Schulter werfen und musste sie nicht immer wieder auf ein Neues aufblasen.
<G-vec00634-002-s114><inflate.aufblasen><en> Since the seat part is not inflatable I could just take the mat at this end and throw me over his shoulder and did not need to inflate again to a new one.
<G-vec00634-002-s126><inflate.aufblasen><de> Wir empfehlen Ihnen, zum Aufblasen dieses Produkts eine elektrische Pumpe zu verwenden (nicht im Lieferumfang enthalten).
<G-vec00634-002-s126><inflate.aufblasen><en> Please note: We advise you use an electric pump to inflate this product (not included).
