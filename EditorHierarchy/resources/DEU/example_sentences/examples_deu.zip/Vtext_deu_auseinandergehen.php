<G-vec00849-002-s030><diverge.auseinandergehen><de> Und doch führt das Schicksal sie zusammen, lässt sie ihre Wege kreuzen und wieder auseinander gehen.
<G-vec00849-002-s030><diverge.auseinandergehen><en> Yet the fate brings them together, lets their paths cross and diverge again.
<G-vec00849-002-s046><diverge.auseinandergehen><de> Zu diesem Thema gehen die Meinungen auseinander und manchmal sogar diametral entgegengesetzt.
<G-vec00849-002-s046><diverge.auseinandergehen><en> Authoritative opinions on this issue diverge, and sometimes even diametrically opposed.
