<G-vec00243-002-s036><concern.anliegen><de> Zusätzlich ist es ein besonderes Anliegen der GALERIE Supper, den künstlerischen Nachwuchs der Kunstakademie Karlsruhe jährlich mit einer kuratierten Gruppenausstellung zu fördern.
<G-vec00243-002-s036><concern.anliegen><en> In addition it is the gallery´s special concern to promote qualified young talents of the Kunstakademie Karlsruhe in an annual curated exhibition.
<G-vec00243-002-s037><concern.anliegen><de> Ihr Anliegen Ich interessiere mich für ihr Produkt Copper Tape.
<G-vec00243-002-s037><concern.anliegen><en> Your Concern I am interested in your following product Copper Tape.
<G-vec00243-002-s038><concern.anliegen><de> Das Thema Fachkräftesicherung ist und bleibt für die meisten Betriebe ein zentrales Anliegen.
<G-vec00243-002-s038><concern.anliegen><en> The theme of skilled workers remains a major concern for most businesses.
<G-vec00243-002-s039><concern.anliegen><de> Die Vereinbarkeit von Beruf und Familie ist Herrenknecht ein wichtiges Anliegen.
<G-vec00243-002-s039><concern.anliegen><en> The compatibility of professional and private lives is an important concern for Herrenknecht.
<G-vec00243-002-s040><concern.anliegen><de> Das Thema „Tracking“ und „den Gast verstehen“ ist uns ein besonderes Anliegen.
<G-vec00243-002-s040><concern.anliegen><en> The topic “tracking” and “understanding the guest” is of particular concern to us.
<G-vec00243-002-s041><concern.anliegen><de> BAYER (SCHWEIZ) AG ist sich darüber bewusst, dass Ihnen der Schutz Ihrer Privatsphäre bei der Benutzung unserer Websites ein wichtiges Anliegen ist.
<G-vec00243-002-s041><concern.anliegen><en> Privacy Statement Bayer is aware that the security of your private information from the use of our website is an important concern.
<G-vec00243-002-s042><concern.anliegen><de> Um Ihr Anliegen schnellstmöglich bearbeiten und eine zügige Abwicklung realisieren zu können, bitten wir Sie, unbedingt das nachfolgend beschriebene Prozedere zu beachten.
<G-vec00243-002-s042><concern.anliegen><en> Please make sure to follow the procedure described below so that we can address your concern as quickly as possible.
<G-vec00243-002-s043><concern.anliegen><de> SwissPSI.ch – der Wohlstand, Souveränität und Unabhängigkeit der Schweiz ist unser Anliegen.
<G-vec00243-002-s043><concern.anliegen><en> SwissPSI.ch – the Prosperity, Sovereignty and Independence of Switzerland is our concern.
<G-vec00243-002-s044><concern.anliegen><de> Der Schutz der personenbezogenen Daten unserer Nutzer ist für uns ein zentrales Anliegen.
<G-vec00243-002-s044><concern.anliegen><en> The protection of the personal data of our users is a primary concern for us.
<G-vec00243-002-s045><concern.anliegen><de> Im Einklang mit den Grundsätzen des Wohlfahrtstaates zielt dieses Anliegen auf den Kampf gegen Armut, die Einbeziehung kultureller Unterschiede und ihre Grenzen sowie den Stellenwert von Mobilität und Immigrantenarbeit in der Wirtschaft ab.
<G-vec00243-002-s045><concern.anliegen><en> This concern is in keeping with welfare state principles oriented toward the fight against poverty, the inclusion of cultural differences and its limits, and the place of mobility and immigrant labour in the economy.
<G-vec00243-002-s046><concern.anliegen><de> Ein weiteres wichtiges Anliegen für Eltern ist, dass die Registrierungsrichtlinie von Tumblr keine Altersgrenze hat, die weniger als 13 beträgt, die jeder Jugendliche direkt mit einer E-Mail-Adresse beitreten kann.
<G-vec00243-002-s046><concern.anliegen><en> Another major concern for parents is that Tumblr’s registration policy has no age limit less than 13 that any teen can join directly using an email address.
<G-vec00243-002-s047><concern.anliegen><de> Der Schutz Ihrer persönlichen Daten ist uns nicht erst seit dem Inkrafttreten der Datenschutzgrundverordnung ein besonderes Anliegen.
<G-vec00243-002-s047><concern.anliegen><en> The protection of your personal data is, and has always been a matter of particular concern to us, and not just since the reinforcement of the data protection regulation.
<G-vec00243-002-s048><concern.anliegen><de> Zentrales Anliegen ist es, den Schüler/innen positive Zugänge zu der Vielfalt kultureller Identitäten in unserer Gesellschaft zu vermitteln.
<G-vec00243-002-s048><concern.anliegen><en> The central concern is to convey to pupils positive approaches to the diversity of cultural identities in our society.
<G-vec00243-002-s049><concern.anliegen><de> Persönliche Interessen und Fähigkeiten mit den wachsenden Anforderungen einer modernen Arbeitswelt zu kombinieren, ist ein wichtiges Anliegen der gesamten H&F-Unternehmensgruppe.
<G-vec00243-002-s049><concern.anliegen><en> It is H&F's utmost concern to combine personal interests and abilities with the growing requests of a modern working environment.
<G-vec00243-002-s050><concern.anliegen><de> Im Rahmen des interreligiösen Sommerkurses, der vom Ökumenischen Rat der Kirchen (ÖRK) gefördert wird, will sich diese Gruppe gemeinsam für die Bewahrung der Schöpfung engagieren, ein Anliegen, das ihrer Meinung nach allen Glaubenstraditionen gemein ist.
<G-vec00243-002-s050><concern.anliegen><en> As part of an interfaith summer course sponsored by the World Council of Churches (WCC), this community wants to work for the protection of creation – a concern they say is common to all faith traditions.
<G-vec00243-002-s051><concern.anliegen><de> Ein weiteres Anliegen, das nicht von dem Abkommen angesprochen, aber in Kopenhagen viel diskutiert wurde, ist der Zusammenhang von Landwirtschaft und Klimawandel.
<G-vec00243-002-s051><concern.anliegen><en> Another concern which has not been addressed by the Accord, but which was very much discussed in Copenhagen, is the link between agriculture and climate.
<G-vec00243-002-s052><concern.anliegen><de> Ein wichtiges Anliegen ist es, das Unternehmen durch gemischte Management-Teams und mehr personelle Vielfalt auf der Führungsebene weiter zu stärken und Leitungsfunktionen vor allem für Frauen attraktiver zu machen.
<G-vec00243-002-s052><concern.anliegen><en> One important concern is to strengthen the Company further by means of mixed management teams and increased staff di- versity at the management level, especially by making managerial positions more attractive for women.
<G-vec00243-002-s053><concern.anliegen><de> Gesundheit ist ein großes Anliegen auf der ganzen Welt und das ist in unserem Projekt nicht anders.
<G-vec00243-002-s053><concern.anliegen><en> Good health is a big concern all over the world and this is no different in our project.
<G-vec00243-002-s054><concern.anliegen><de> Wir werden versuchen, Ihr Anliegen so bald wie möglich zu einem erfolgreichen Abschluss zu bringen.
<G-vec00243-002-s054><concern.anliegen><en> We will try to bring your concern to a successful conclusion as quickly as possible.
<G-vec00256-002-s057><aim.anliegen><de> Das primäre Anliegen dieses Studienganges besteht - neben der produktiven Umsetzung der internationalen, interkulturellen Anregungen des gemeinsamen Studienverlaufs der binationalen Studierendengruppe- insbesondere in der Vermittlung analytischer Fähigkeiten zur konsequenten Verknüpfung von Theorie und Empirie an den Schnittstellen von Kultur- und Sozialwissenschaften.
<G-vec00256-002-s057><aim.anliegen><en> The main aim of this degree course, in addition to the practical implementation of the international intercultural recommendations of a joint curriculum for the binational group of students, lies especially in the development of analytical skills and the consistent combination of theory and empiricism at the interface of culture and social studies.
<G-vec00256-002-s058><aim.anliegen><de> Konsequente Qualitätssicherung in der Produktion und sämtlichen Prozessen im Unternehmen ist uns ein zentrales Anliegen und Verpflichtung.
<G-vec00256-002-s058><aim.anliegen><en> Consistent quality assurance in the production and all processes in the company is our central aim and responsibility.
<G-vec00256-002-s059><aim.anliegen><de> Anliegen des Beitrags ist es, die biografieanalytischen Potenziale der Begriffe Identität und Habitus zu diskutieren und ihre Genese anhand der Biografien von ehemaligen Internatsschüler*innen nachzuvollziehen.
<G-vec00256-002-s059><aim.anliegen><en> Abstract The aim of the article is to discuss the biographical analysis potential of the terms identity and habitus and to understand their genesis on the base of the biographies of former boarders.
<G-vec00256-002-s060><aim.anliegen><de> Diese Website folgt Beuys’ Anliegen, seine Kunst einem breiten Publikum zugänglich zu machen.
<G-vec00256-002-s060><aim.anliegen><en> This website is intended to support Beuys’s aim of making art available to a large audience.
<G-vec00256-002-s061><aim.anliegen><de> Wir haben diese brandneue Website mit dem Anliegen konzipiert, unsere sich vergrößernde Auswahl an europäischen Städtereisezielen unter ein Dach zu bringen.
<G-vec00256-002-s061><aim.anliegen><en> We designed this brand new website with the aim of bringing together our expanding range of European city break destinations under one roof.
<G-vec00256-002-s062><aim.anliegen><de> Ein besonderes Anliegen des BMWZ ist darüber hinaus die Ausbildung und Förderung des wissenschaftlichen Nachwuchses.
<G-vec00256-002-s062><aim.anliegen><en> A special aim of the BMWZ is the education of young scientists.
<G-vec00256-002-s063><aim.anliegen><de> Als erfahrener Dreikämpfer und Yogalehrer ist es sein Anliegen, das Potenzial zu erschließen, das in jedem Einzelnen steckt.
<G-vec00256-002-s063><aim.anliegen><en> As an experienced triathlete and Yoga teacher, he has made it his aim to unfold everyone’s individual potential.
<G-vec00256-002-s064><aim.anliegen><de> Kommunikativ werden – Ein unmittelbares Anliegen unserer Demonstration ist die direkte Kommunikation mit den Frankfurter Bürger_innen und die Aufklärung der interessierten Öffentlichkeit über die Inhalte und Ziele unseres Protestes und Widerstands gegen die aktuelle Krisenpolitik.
<G-vec00256-002-s064><aim.anliegen><en> Engage! An immediate aim of our demonstration is to communicate directly with Frankfurt ́s citizens and to inform the public about the nature and goals of our protest and resistance against the current crisis politics.
<G-vec00256-002-s065><aim.anliegen><de> In diesem Jahr sind unsere festliche Eucharistiefeier und daran anschließend die herkömmliche Prozession, die von diesem Platz hier nach Santa Maria Maggiore führen wird, mit einem besonderen Anliegen verbunden: sie wollen ein einmütiges, tief bekümmertes Flehen um den Frieden sein.
<G-vec00256-002-s065><aim.anliegen><en> This year our solemn celebration and, in a while, the traditional procession which will take us from this square to St Mary Major have a specific aim: they are meant as a heartfelt and unanimous prayer for peace.
<G-vec00256-002-s066><aim.anliegen><de> Ihr Anliegen ist die Analyse und (Selbst-)Kritik moderner, kapitalistischer Gesellschaften.
<G-vec00256-002-s066><aim.anliegen><en> Its aim is the analysis and (self-)critique of modern, capitalist societies.
<G-vec00256-002-s067><aim.anliegen><de> Es ist unser Anliegen, im Rahmen des Emergenza-Programms attraktive Auftrittsmöglichkeiten zu schaffen und wir freuen uns sehr über die Plattform, die uns die Musikmesse für das Emergenza Eurofinale zur Verfügung stellt.
<G-vec00256-002-s067><aim.anliegen><en> “The number of professional gigs open to young groups of musicians is declining continuously and, within the framework of the Emergenza programme, our aim is to create attractive opportunities to show what they can do. Hence, we are very pleased about the platform that Musikmesse is making available for the Emergenza Euro Finals.
<G-vec00256-002-s068><aim.anliegen><de> Auch die Berücksichtigung aktueller Herausforderungen wie Energiewende, Klimawandel und demografische Aspekte sind ein wesentliches Anliegen des Projekts.
<G-vec00256-002-s068><aim.anliegen><en> One important aim of the project also includes placing emphasis on current challenges such as energy turnaround, climate change and demographic aspects.
<G-vec00256-002-s069><aim.anliegen><de> Diese sinnvoll in die Produktion zu integrieren und ihnen ein artgerechtes Leben zu ermöglichen ist unser Anliegen.
<G-vec00256-002-s069><aim.anliegen><en> Their meaningful integration into production while facilitating a life true to their essence is our aim.
<G-vec00256-002-s070><aim.anliegen><de> Verpackungen Unser Anliegen: Verpackungsmaterial reduzieren und optimieren, um Ressourcen zu schonen.
<G-vec00256-002-s070><aim.anliegen><en> Packaging Our aim: reducing and optimizing packaging material to save resources.
<G-vec00256-002-s071><aim.anliegen><de> Das Anliegen unseres Festivals, aufregendes internationales Theater nach Leipzig zu holen, entspricht der Weltoffenheit dieser Stadt mit ihrer Universität, Messe und großen Kulturtradition in der Mitte Europas.
<G-vec00256-002-s071><aim.anliegen><en> The aim of our festival, namely to bring exciting international theatre to Leipzig, corresponds with this city's cosmopolitan attitude; with its university, trade fair, and great cultural tradition embodied in Europe's heartland.
<G-vec00256-002-s072><aim.anliegen><de> Es ist das Anliegen von Vienna Economic Forum zur regionalen wirtschaftlichen Entwicklung der ganzen Region Süd-Ost-Europa zielführend beizutragen.
<G-vec00256-002-s072><aim.anliegen><en> It is the aim of Vienna Economic Forum to contribute to the regional economic development of the entire region of South-Eastern Europe.
<G-vec00256-002-s073><aim.anliegen><de> Doch bei aller Ironie ist Paiks tieferes Anliegen eine Übertragung von Cages musikalischer Arbeit mit Zufallsfaktoren auf die Bildkünste, zu deren Begründung er bis auf die physikalischen Eigenschaften des Elektrons zurückgeht: »INDETERMINISMUS und VARIABILITÄT sind die extrem UNTERENTWICKELTEN Parameter in der optischen Kunst, obwohl dies das zentrale Phänomen der Musik während der letztenzehn Jahre gewesen ist.« [24] Ausdrücklich fordert Paik somit die Übertragung von kompositorischen Prinzipien der Musik auf die Bildkünste.
<G-vec00256-002-s073><aim.anliegen><en> But despite all the irony, Paik's true aim is to transfer Cage's musical work with random factors to the pictorial arts. To justify this, he goes back to the physical qualities of the electron: «INDETERMINISM and VARIABILITY is the very UNDERDEVELOPED parameter in optical art, although this has been the central problem in music for the last ten years.»
<G-vec00256-002-s074><aim.anliegen><de> Ein Anliegen dieser Gruppe von Experten ist es, das EFSUMB Board über effektive und wirksame Methoden für den alltäglichen Gebrauch zu beraten und Empfehlungen zu den technischen Aspekten im EFSUMB by-law 9, Teil 11.6.
<G-vec00256-002-s074><aim.anliegen><en> It is the aim of this group of experts to advise the EFSUMB Board of effective and efficacious methods for routine use and to make recommendations regarding the technical aspects of EFSUMB by-law 9, parts 11.6.
<G-vec00256-002-s075><aim.anliegen><de> Gemeinsam mit zehn Musiker/innen des Solistenensembles Kaleidoskop erprobte sie eine neue Art der Interaktion zwischen Performern und Publikum mit dem Anliegen, neben Oper und Konzert ein neues Format für musikalisches Erleben zu entwickeln.
<G-vec00256-002-s075><aim.anliegen><en> Together with ten musicians of the soloist ensemble Kaleidoskop, she tested a new type of interaction between the performers and the audience with the aim of developing a new format for musical experience besides opera and concert performances.
<G-vec00272-002-s114><request.anliegen><de> Einige Eltern verstanden auch das Anliegen nicht richtig: es galt nicht, die Kinder "abzuliefern" - "belustigen" zu lassen und anschließend wieder mitzunehmen.
<G-vec00272-002-s114><request.anliegen><en> Some parents also did not understand the request correctly: it was not a matter of " delivering" the children - "of letting "amuse" and of taking afterwards again.
<G-vec00272-002-s115><request.anliegen><de> Gerne bespreche ich mit Ihnen Ihr Anliegen per E-mail, Telefon oder persönlich.
<G-vec00272-002-s115><request.anliegen><en> I will be glad to discuss your request via e-mail, phone or personally.
<G-vec00272-002-s116><request.anliegen><de> Schreiben Sie uns über das Kontaktformular, damit wir Ihnen bei Ihrem Anliegen behilflich sein können.
<G-vec00272-002-s116><request.anliegen><en> Write to us using the contact form so that we can help you with your request.
<G-vec00272-002-s117><request.anliegen><de> Ihnen wird dann der zuständige einheitliche Ansprechpartner, an den Sie sich mit Ihrem Anliegen wenden können, angezeigt.
<G-vec00272-002-s117><request.anliegen><en> The system will then display the responsible single point of contact, who you can contact with your request.
<G-vec00272-002-s118><request.anliegen><de> Ich helfe Ihnen den richtigen Ansprechpartner für Ihr Anliegen finden.
<G-vec00272-002-s118><request.anliegen><en> I will help you to find the right contact person for your request.
<G-vec00272-002-s119><request.anliegen><de> Um auf Ihr Anliegen schnell reagieren zu können, benötigen wir einige Angaben.
<G-vec00272-002-s119><request.anliegen><en> In order to be able to react quickly to your request, we need some information.
<G-vec00272-002-s120><request.anliegen><de> Manuela Unterleitner vom Gemeindeverband für Abfallbeseitigung in der Region Tulln wandte sich mit einem besonderen Anliegen an das SoPro-Entwickler-Team: Für die Mitarbeiter des Verbandes wünschte sie sich einheitliche Anstecker mit dem Logo des GVA Tulln, und das Ganze sollte natürlich ganz im Sinne des Abfallverbands aus Restmaterialien gefertigt werden.
<G-vec00272-002-s120><request.anliegen><en> Manuela Unterleitner from the Municipal Waste Association in the region of Tulln addressed the SoPro developer team with a special request: She wished uniform clip badges showing the logo of the Tulln Waste Association for the members of this association, and they should be produced, consistent with the waste association, of residual materials.
<G-vec00272-002-s121><request.anliegen><de> Egal ob Fragen, Wünsche, Anregungen, Kritik oder Lob - einfach her damit, wir kümmern uns gerne um dein Anliegen.
<G-vec00272-002-s121><request.anliegen><en> No matter if questions, requests, suggestions, complaints or praise - just let us know. We'll be happy to answer your request.
<G-vec00272-002-s122><request.anliegen><de> Die zur Verfügung gestellten Daten sind zur Bearbeitung Ihrer Anliegen erforderlich und werden nur zur Bearbeitung Ihrer Anliegen im Einklang mit den gesetzlichen Bestimmungen und nicht für andere Zwecke verwendet.
<G-vec00272-002-s122><request.anliegen><en> The data provided is necessary to process your request and will only be used to work on your request in accordance with legal requirements and not for other purposes.
<G-vec00272-002-s124><request.anliegen><de> Unsere Druckvorstufe bringt über 35 Jahre an Erfahrung mit und kann für jedes Problem oder Anliegen eine Lösung finden.
<G-vec00272-002-s124><request.anliegen><en> Our prepress has over 35 years of experience and can find a solution to any problem or request.
<G-vec00272-002-s125><request.anliegen><de> Sollten Sie sich direkt an uns wenden, versuchen wir Ihr Anliegen bestmöglich zu unterstützen.
<G-vec00272-002-s125><request.anliegen><en> Should you contact us directly, we will try to support your request in the best possible way.
<G-vec00272-002-s126><request.anliegen><de> Wenden Sie sich mit Ihrem Anliegen bitte an die unten angegebenen Kontaktdaten.
<G-vec00272-002-s126><request.anliegen><en> Please contact us with your request using the contact details below.
<G-vec00272-002-s127><request.anliegen><de> Soweit es sich hierbei um Angaben zu Kommunikationskanälen (beispielsweise E-Mail-Adresse, Telefonnummer) handelt, willigen Sie zudem ein, dass wir Sie gegebenenfalls auch über diesen Kommunikationskanal kontaktieren, um Ihr Anliegen zu beantworten.
<G-vec00272-002-s127><request.anliegen><en> If this information relates to communication channels (e.g. your email address or telephone number), you are also consenting to the fact that we may, if necessary, contact you using these communication channels to respond to your request.
<G-vec00272-002-s128><request.anliegen><de> Ihr Anliegen wird demnach von einem kompetenten Mitarbeiter bearbeitet und Sie erhalten wunschgemäß eine Antwort per Rückruf oder Email.
<G-vec00272-002-s128><request.anliegen><en> Your request will therefore be processed by a competent employee and you will receive an answer by callback or email.
<G-vec00272-002-s129><request.anliegen><de> Zum Beispiel helfen uns die Angabe von PLZ und Land dabei, Ihr Anliegen schnellstmöglich an den richtigen Ansprechpartner in Ihrer Region weiterzuleiten.
<G-vec00272-002-s129><request.anliegen><en> For example, the post code and country help us to forward your request as quickly as possible to the right contact person in your region.
<G-vec00272-002-s130><request.anliegen><de> E-Mail* Deine Anfrage* Bitte teile uns die Details zu deinem Anliegen mit.
<G-vec00272-002-s130><request.anliegen><en> Email* Your Request* Please enter the details of your request.
<G-vec00272-002-s131><request.anliegen><de> Beschreiben Sie mir Ihre Anliegen und ich erarbeite Ihnen eine Online-Präsenz, die perfekt auf Sie zugeschnitten ist.
<G-vec00272-002-s131><request.anliegen><en> You describe your request and I will develop your individual online presence.
<G-vec00272-002-s132><request.anliegen><de> Falls Sie ein solches Restrisiko ausschließen möchten, brechen Sie den Vorgang ab und teilen Sie uns Ihr Anliegen auf einem anderen Kanal mit.
<G-vec00272-002-s132><request.anliegen><en> If you want to exclude such a residual risk, cancel the process and tell us your request on a different channel.
<G-vec00351-002-s038><issue.anliegen><de> Wenn das Programm zu eng zu werden droht, bitten wir eventuell darum, Vorschläge mit passenden anderen Beiträgen zu kombinieren, damit möglichst alle die Chance haben, ihre Anliegen einzubringen.
<G-vec00351-002-s038><issue.anliegen><en> Should the program become too full, we may ask contributors to combine issues where possible to ensure that as many people as possible have the chance to have their issue included.
<G-vec00351-002-s039><issue.anliegen><de> Öffentliche Sicherheit ist ein wichtiges Anliegen für Behörden auf allen Ebenen.
<G-vec00351-002-s039><issue.anliegen><en> Public safety and security is an important issue for governments at all levels.
<G-vec00351-002-s040><issue.anliegen><de> Der Schutz Ihrer Privatsphäre bei der Verarbeitung persönlicher Daten ist für uns ein wichtiges Anliegen.
<G-vec00351-002-s040><issue.anliegen><en> Protecting your privacy when processing your personal data is an important issue for us.
<G-vec00351-002-s041><issue.anliegen><de> Ohne diese Daten kann Ihr per Kontaktformular übermitteltes Anliegen nicht bearbeitet werden.
<G-vec00351-002-s041><issue.anliegen><en> Without this data the issue you mention in the contact form cannot be processed.
<G-vec00351-002-s042><issue.anliegen><de> Wenn Sie ein persönliches Anliegen im Zusammenhang mit dem Kauf oder Verkauf Ihrer hochwertigen Immobilie oder Ihres Bauträgerprojektes auf Mallorca, Ibiza oder auf dem spanischen Festland haben, so zögern Sie bitte nicht uns auf direktem Wege zu kontaktieren.
<G-vec00351-002-s042><issue.anliegen><en> If you have a personal issue in connection with the pur- chase or sale of your high-quality property or your build- ing contractor project on Mallorca, Ibiza or on the Spanish mainland, please do not hesitate to contact us directly.
<G-vec00351-002-s043><issue.anliegen><de> Wenn du ein kritisches oder dringendes Anliegen hast, welches nicht von einem “Feedback”-Thema behandelt wird, nimm über die Mitarbeiter-Seite mit uns Kontakt auf.
<G-vec00351-002-s043><issue.anliegen><en> If there’s a critical or urgent issue that can’t be handled by a meta topic or flag, contact us via the staff page.
<G-vec00351-002-s044><issue.anliegen><de> Wegen des Vorhandenseins von Östrogen kann Wassereinlagerungen auch ein Anliegen sein.
<G-vec00351-002-s044><issue.anliegen><en> As a result of the existence of oestrogen, water retention can also be an issue.
<G-vec00351-002-s045><issue.anliegen><de> Bei Anliegen oder Beschwerden zum Datenschutz auf den Mozy Websites bitten wir Sie, das Anliegen zunächst mit Mozy direkt zu klären, indem Sie uns eine E-Mail an folgende Adresse privacy@mozy.com senden.
<G-vec00351-002-s045><issue.anliegen><en> If you have a dispute or complaint about privacy on a Mozy website, we kindly ask that you attempt first to resolve the issue directly with Mozy by emailing privacy@mozy.com.
<G-vec00351-002-s046><issue.anliegen><de> Was mit einem Anliegen passiert, wenn es übermittelt wird, hängt davon ab, wer es geschrieben hat.
<G-vec00351-002-s046><issue.anliegen><en> What happens to an issue when it is first reported depends on who reported it.
<G-vec00351-002-s047><issue.anliegen><de> Uns ist die Wahrung Ihrer Privatsphäre bei der Verarbeitung persönlicher Daten ein wichtiges Anliegen.
<G-vec00351-002-s047><issue.anliegen><en> Protecting your privacy while processing your personal data is an important issue for us.
<G-vec00351-002-s048><issue.anliegen><de> Beschreiben Sie kurz Ihr Anliegen und wir melden uns bei Ihnen schnellstmöglich.
<G-vec00351-002-s048><issue.anliegen><en> * Describe your issue Send message We'll get back to you as soon as possible.
<G-vec00351-002-s049><issue.anliegen><de> Whitepaper – Ein Dokument, das als Bericht oder als Leitfaden für ein komplexes Anliegen dient.
<G-vec00351-002-s049><issue.anliegen><en> Whitepaper – A document which serves as a report or guide to a complex issue.
<G-vec00351-002-s050><issue.anliegen><de> Das Ziel: Möglichst viele Mitglieder der Universität tauschen sich über ein gemeinsames Thema oder Anliegen aus.
<G-vec00351-002-s050><issue.anliegen><en> The goal: the exchange between many members of the university about one topic or issue.
<G-vec00351-002-s052><issue.anliegen><de> Ticket senden Senden Sie uns Ihr Anliegen und unser Kundenservice Team wird sich umgehend mit Ihnen in Verbindung setzen.
<G-vec00351-002-s052><issue.anliegen><en> Send us your issue and our Customer Support Team will get back to you right away.
<G-vec00351-002-s053><issue.anliegen><de> - Destinationsmanagement (Inbound-Dienstleistungen, Zielgruppenkonzepte, erste Eindrücke und die Behandlung individueller Anliegen, Prozessmanagement bei Ankunft und Abreise).
<G-vec00351-002-s053><issue.anliegen><en> - Destination management (inbound services, special interest portfolio of products, impression and issue management, arrival and departure services)
<G-vec00351-002-s054><issue.anliegen><de> Diesen Monat lade ich euch dazu ein, schamanisch zu diesem Anliegen / zu dieser Frage zu reisen oder zu meditieren.
<G-vec00351-002-s054><issue.anliegen><en> This month I invite you to journey or to meditate on this issue/question.
<G-vec00351-002-s056><issue.anliegen><de> Für ERGO ist Umweltschutz seit vielen Jahren ein wichtiges Anliegen.
<G-vec00351-002-s056><issue.anliegen><en> Environmental protection has been an important issue at ERGO for many years.
